(() => {
'use strict';

/* ================= Допоміжне ================= */
const KEY = 'zyuzya.v1';
const $ = (s, r = document) => r.querySelector(s);
const p2 = n => String(n).padStart(2, '0');
const iso = d => d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate());
const today = () => iso(new Date());
const addDays = (n, from = new Date()) => { const d = new Date(from); d.setDate(d.getDate() + n); return d; };
const fmtDate = s => { if (!s) return ''; const [y, m, d] = s.split('-'); return d + '.' + m + '.' + y; };
const fmtShort = s => { if (!s) return ''; const [, m, d] = s.split('-'); return d + '.' + m; };
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const parseNum = s => { const n = parseFloat(String(s).replace(/\s/g, '').replace(',', '.')); return isFinite(n) ? n : NaN; };
const shuffle = a => { a = [...a]; for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
const cap = s => s.charAt(0).toUpperCase() + s.slice(1);
const weekStart = () => { const d = new Date(); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); return iso(d); };
const DAY = 86400000;

/* ================= Дані ================= */
const EXP_CATS = ['Їжа', 'Транспорт', 'Розваги', 'Одяг', 'Зв’язок', 'Здоров’я', 'Навчання', 'Накопичення', 'Інше'];
const INC_CATS = ['Зарплата', 'Підробіток', 'Подарунок', 'Кишенькові', 'Повернення з цілі', 'Інше'];
const CUSTOM = 'Свої';
const GYM = [
  ['Груди', ['Жим штанги лежачи', 'Жим гантелей лежачи', 'Жим штанги на похилій лаві', 'Жим гантелей на похилій лаві', 'Жим на лаві головою вниз', 'Розведення гантелей лежачи', 'Розведення гантелей на похилій лаві', 'Зведення рук у кросовері', 'Зведення рук у тренажері «метелик»', 'Жим у тренажері для грудей', 'Пуловер з гантеллю']],
  ['Спина', ['Станова тяга', 'Тяга верхнього блока до грудей', 'Тяга верхнього блока вузьким хватом', 'Тяга нижнього блока до пояса', 'Тяга штанги в нахилі', 'Тяга гантелі однією рукою', 'Тяга Т-грифа', 'Тяга в тренажері', 'Гравітрон', 'Пуловер на блоці', 'Гіперекстензія', 'Шраги зі штангою', 'Шраги з гантелями']],
  ['Плечі', ['Жим штанги стоячи', 'Жим гантелей сидячи', 'Жим Арнольда', 'Жим у тренажері для плечей', 'Махи гантелей убік', 'Махи гантелей перед собою', 'Махи в нахилі на задню дельту', 'Махи убік у блоці', 'Тяга штанги до підборіддя', 'Тяга канату до обличчя', 'Зворотні розведення в тренажері']],
  ['Біцепс', ['Підйом штанги на біцепс', 'Підйом EZ-грифа', 'Підйом гантелей на біцепс', 'Молотки', 'Підйом на лаві Скотта', 'Концентрований підйом', 'Підйом гантелей на похилій лаві', 'Згинання рук на нижньому блоці']],
  ['Трицепс', ['Французький жим лежачи', 'Жим штанги вузьким хватом', 'Розгинання рук на верхньому блоці', 'Розгинання з канатом', 'Розгинання гантелі з-за голови', 'Розгинання рук у нахилі', 'Зворотні віджимання від лави', 'Бруси в тренажері']],
  ['Ноги', ['Присідання зі штангою', 'Фронтальні присідання', 'Присідання з гантеллю', 'Присідання сумо', 'Жим ногами', 'Гакк-присідання', 'Випади з гантелями', 'Болгарські спліт-присідання', 'Вихід на тумбу', 'Розгинання ніг у тренажері', 'Згинання ніг лежачи', 'Згинання ніг сидячи', 'Румунська тяга', 'Сідничний місток', 'Зведення ніг у тренажері', 'Розведення ніг у тренажері', 'Відведення ноги в блоці']],
  ['Литки', ['Підйом на носки стоячи', 'Підйом на носки сидячи', 'Підйом на носки в жимі ногами']],
  ['Прес', ['Скручування на лаві', 'Скручування на блоці', 'Підйом ніг у висі', 'Підйом колін у висі', 'Підйом ніг лежачи', 'Ролик для преса', 'Російські скручування', 'Бокові скручування', 'Скручування на римському стільці']],
  ['Передпліччя', ['Згинання зап’ястя зі штангою', 'Розгинання зап’ястя зі штангою', 'Зворотний підйом штанги', 'Прогулянка фермера']],
  ['Все тіло', ['Взяття штанги на груди', 'Ривок гирі', 'Мах гирі', 'Турецький підйом', 'Берпі', 'Тяга сумо']],
  ['Кардіо', ['Бігова доріжка', 'Велотренажер', 'Орбітрек', 'Гребний тренажер', 'Степпер', 'Скакалка']]
];
const grpOf = ex => { for (const [g, l] of GYM) if (l.includes(ex)) return g; return CUSTOM; };
const customEx = () => [...new Set(S.work.map(w => w.ex).filter(e => grpOf(e) === CUSTOM))];
const exList = g => (g === CUSTOM ? customEx() : ((GYM.find(x => x[0] === g) || [0, []])[1]));
const THEMES = { vio: ['Фіолет', '#9061f9', '#a3e635'], lime: ['Салат', '#a3e635', '#9061f9'], pink: ['Рожевий', '#ec4899', '#a3e635'] };
const HAB_PRESETS = { water: ['Вода', 'count', 8, 'скл.'], sleep: ['Сон', 'count', 8, 'год'], walk: ['Прогулянка', 'check', 1, ''], warm: ['Зарядка', 'check', 1, ''], read: ['Читання', 'check', 1, ''], sugar: ['Без цукру', 'check', 1, ''] };
const TPL_BUILTIN = [
  ['b1', 'Груди + трицепс', [['Жим штанги лежачи', 4, 8], ['Жим гантелей на похилій лаві', 3, 10], ['Розведення гантелей лежачи', 3, 12], ['Зведення рук у кросовері', 3, 12], ['Французький жим лежачи', 3, 10], ['Розгинання рук на верхньому блоці', 3, 12]]],
  ['b2', 'Спина + біцепс', [['Станова тяга', 3, 6], ['Тяга верхнього блока до грудей', 4, 10], ['Тяга штанги в нахилі', 3, 8], ['Тяга нижнього блока до пояса', 3, 10], ['Підйом штанги на біцепс', 3, 10], ['Молотки', 3, 12]]],
  ['b3', 'Ноги', [['Присідання зі штангою', 4, 8], ['Жим ногами', 3, 12], ['Румунська тяга', 3, 10], ['Розгинання ніг у тренажері', 3, 12], ['Згинання ніг лежачи', 3, 12], ['Підйом на носки стоячи', 4, 15]]],
  ['b4', 'Плечі + прес', [['Жим штанги стоячи', 4, 8], ['Жим гантелей сидячи', 3, 10], ['Махи гантелей убік', 4, 12], ['Махи в нахилі на задню дельту', 3, 12], ['Тяга канату до обличчя', 3, 15], ['Підйом ніг у висі', 3, 12], ['Скручування на блоці', 3, 15]]],
  ['b5', 'Все тіло (для початку)', [['Присідання зі штангою', 3, 10], ['Жим гантелей лежачи', 3, 10], ['Тяга верхнього блока до грудей', 3, 10], ['Жим гантелей сидячи', 3, 10], ['Підйом гантелей на біцепс', 2, 12], ['Розгинання рук на верхньому блоці', 2, 12], ['Скручування на лаві', 3, 15]]]
].map(([id, name, it]) => ({ id, name, builtin: true, items: it.map(([ex, sets, reps]) => ({ ex, sets, reps })) }));
const GOAL_KINDS = { moto: ['Мотоцикл', 'bike'], phone: ['Телефон', 'phone'], other: ['Інша ціль', 'star'] };
const PRIO = { 0: ['Високий', 'red'], 1: ['Середній', 'vio'], 2: ['Низький', 'grn'] };

function defaults() {
  return { v: 2, name: '', cur: '₴', tx: [], goals: [], work: [], tasks: [], habits: [], tpls: [], weight: [], wGoal: 0, theme: 'vio', daily: { tasks: 3, workout: 1 }, lastBackup: null, welcomed: false };
}
function migrate(o) {
  const d = defaults(); const s = { ...d, ...o };
  s.daily = { ...d.daily, ...(o.daily || {}) }; delete s.daily.words;
  ['tx', 'goals', 'work', 'tasks', 'habits', 'tpls', 'weight'].forEach(k => { if (!Array.isArray(s[k])) s[k] = d[k]; });
  ['words', 'lessons', 'revByDay'].forEach(k => delete s[k]);
  if (!THEMES[s.theme]) s.theme = 'vio';
  s.habits.forEach(h => { if (!h.log || typeof h.log !== 'object') h.log = {}; h.type = h.type === 'count' ? 'count' : 'check'; h.goal = Math.min(99, Math.max(1, Math.trunc(+h.goal || 1))); h.unit = h.unit || ''; if (!Array.isArray(h.rem)) h.rem = []; for (const k of Object.keys(h.log)) h.log[k] = Math.min(h.goal, Math.max(0, Math.trunc(+h.log[k] || 0))); });
  s.wGoal = +s.wGoal > 0 ? +s.wGoal : 0;
  const t0 = today();
  s.tasks.forEach(t => {
    if (!t.date) t.date = t.done ? (t.doneAt || iso(new Date(t.ts || Date.now()))) : t0;
    delete t.due;
    if (typeof t.time !== 'string') t.time = '';
    if (!(t.prio in PRIO)) t.prio = 1;
  });
  return s;
}
function load() {
  let raw = null;
  try { raw = localStorage.getItem(KEY); if (raw) return migrate(JSON.parse(raw)); }
  catch (e) { try { if (raw) localStorage.setItem(KEY + '.corrupt', raw); } catch (_) {} }
  return defaults();
}
let S = load();
const applyTheme = () => { document.documentElement.dataset.theme = S.theme; };
applyTheme();
function save() {
  try { localStorage.setItem(KEY, JSON.stringify(S)); }
  catch (e) { toast('Не вдалося зберегти: немає місця в пам’яті'); }
}

/* ================= Іконки ================= */
const IC = {
  home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/>',
  wallet: '<path d="M3 7a2 2 0 0 1 2-2h13v4"/><path d="M3 7v11a2 2 0 0 0 2 2h14a1 1 0 0 0 1-1v-9a1 1 0 0 0-1-1H5a2 2 0 0 1-2-2z"/><circle cx="16" cy="14" r="1.2"/>',
  target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
  dumbbell: '<path d="M6 6v12M18 6v12M3 9v6M21 9v6M6 12h12"/>',
  more: '<circle cx="5" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="19" cy="12" r="1.6"/>',
  book: '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20V3H6.5A2.5 2.5 0 0 0 4 5.5z"/><path d="M6.5 17v4H20"/>',
  check: '<path d="M5 12l5 5L20 7"/>',
  checksq: '<rect x="3" y="3" width="18" height="18" rx="4"/><path d="M8 12l3 3 5-6"/>',
  sliders: '<path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
  volume: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 9a4 4 0 0 1 0 6M18.5 6.5a8 8 0 0 1 0 11"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
  up: '<path d="M12 19V5M6 11l6-6 6 6"/>',
  down: '<path d="M12 5v14M6 13l6 6 6-6"/>',
  download: '<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>',
  upload: '<path d="M12 16V5M7 10l5-5 5 5M5 20h14"/>',
  bike: '<circle cx="6" cy="16" r="3.5"/><circle cx="18" cy="16" r="3.5"/><path d="M6 16l3-6h5l4 6M9 10L8 7H6M14 10l-1-3h3"/>',
  phone: '<rect x="7" y="2" width="10" height="20" rx="2.5"/><path d="M11 18h2"/>',
  flame: '<path d="M12 3c1 4 5 5 5 10a5 5 0 0 1-10 0c0-2 1-3 2-4 0 2 1 3 2 3 0-3-1-6 1-9z"/>',
  repeat: '<path d="M4 11V9a3 3 0 0 1 3-3h12l-3-3M20 13v2a3 3 0 0 1-3 3H5l3 3"/>',
  cap: '<path d="M2 9l10-5 10 5-10 5z"/><path d="M6 11v5c3 2.5 9 2.5 12 0v-5"/>',
  list: '<path d="M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01"/>',
  star: '<path d="M12 3l2.6 5.6 6.1.7-4.5 4.2 1.2 6L12 16.5 6.6 19.5l1.2-6L3.3 9.3l6.1-.7z"/>',
  calendar: '<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M3 10h18M8 3v4M16 3v4"/>',
  chevron: '<path d="M9 6l6 6-6 6"/>',
  back: '<path d="M15 6l-6 6 6 6"/>',
  share: '<circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="6" r="2.5"/><circle cx="18" cy="18" r="2.5"/><path d="M8.2 10.8l7.6-3.6M8.2 13.2l7.6 3.6"/>',
  inbox: '<path d="M3 13l3-8h12l3 8v6H3z"/><path d="M3 13h5l1 3h6l1-3h5"/>',
  scale: '<rect x="3" y="3" width="18" height="18" rx="4"/><path d="M8 10a4 4 0 0 1 8 0"/><path d="M12 10l2-2"/>',
  minus: '<path d="M5 12h14"/>',
  bell: '<path d="M6 9a6 6 0 0 1 12 0c0 6 2 7 2 7H4s2-1 2-7"/><path d="M10 20a2 2 0 0 0 4 0"/>'
};
const ICON = (n, s = 22) => `<svg class="ic" width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${IC[n] || ''}</svg>`;

function ring(p, size = 100, sw = 10) {
  const r = (size - sw) / 2, c = 2 * Math.PI * r, h = size / 2;
  return `<svg class="ring" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" style="--c:${c}" role="img" aria-label="${Math.round(p * 100)}%">
  <defs><linearGradient id="rg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" style="stop-color:var(--vio2)"/><stop offset="1" style="stop-color:var(--grn)"/></linearGradient></defs>
  <circle cx="${h}" cy="${h}" r="${r}" fill="none" stroke="#241f38" stroke-width="${sw}"/>
  <circle class="rp" cx="${h}" cy="${h}" r="${r}" fill="none" stroke="url(#rg)" stroke-width="${sw}" stroke-linecap="round" stroke-dasharray="${c}" stroke-dashoffset="${c * (1 - p)}" transform="rotate(-90 ${h} ${h})"/>
  <text x="${h}" y="${h + 6}" text-anchor="middle" fill="#ece9f6" font-size="${size * 0.22}" font-weight="800" font-family="system-ui">${Math.round(p * 100)}%</text></svg>`;
}
const bar = (p, cls = '') => `<div class="bar ${cls}"><i style="width:${Math.max(0, Math.min(100, p))}%"></i></div>`;
const money = n => (Math.round(n * 100) / 100).toLocaleString('uk-UA') + ' ' + S.cur;
const fld = (label, inner) => `<label class="fld"><span>${label}</span>${inner}</label>`;
const opts = (arr, sel) => arr.map(x => `<option ${x === sel ? 'selected' : ''}>${esc(x)}</option>`).join('');
const empty = (icon, text) => `<div class="empty">${ICON(icon, 36)}<div>${text}</div></div>`;

/* ================= Тости та шторки ================= */
let toastT;
function toast(msg) {
  const t = $('#toast'); t.textContent = msg; t.classList.add('show');
  clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), 2400);
}
const stack = [];
function openSheet(title, html) {
  const ov = document.createElement('div'); ov.className = 'ov';
  ov.innerHTML = `<div class="sheet" role="dialog" aria-label="${esc(title)}"><div class="grab"></div><div class="sh-head"><h3>${esc(title)}</h3><button class="icon-btn" data-act="closeTop" aria-label="Закрити">${ICON('x', 20)}</button></div>${html}</div>`;
  ov.addEventListener('click', e => { if (e.target === ov) closeTop(); });
  document.body.appendChild(ov); stack.push(ov);
  history.pushState({ tab: ui.tab, sheet: stack.length }, '');
  requestAnimationFrame(() => requestAnimationFrame(() => ov.classList.add('in')));
  return ov;
}
function removeTop() {
  const ov = stack.pop(); if (!ov) return;
  ov.classList.remove('in'); setTimeout(() => ov.remove(), 260);
}
const closeTop = () => { if (stack.length) history.go(-1); };
const closeAll = () => { if (stack.length) history.go(-stack.length); };

function openForm({ title, body, submit = 'Зберегти', onSubmit, del }) {
  const html = `<form class="sheet-body" autocomplete="off">${body}<div class="row gap"><button class="btn primary grow" type="submit">${submit}</button>${del ? `<button class="btn danger" type="button" data-form-del aria-label="Видалити">${ICON('trash', 20)}</button>` : ''}</div></form>`;
  const el = openSheet(title, html);
  const f = $('form', el);
  f.addEventListener('submit', e => {
    e.preventDefault();
    const fd = Object.fromEntries(new FormData(f));
    if (onSubmit(fd, f) !== false) closeAll();
  });
  if (del) $('[data-form-del]', el).onclick = () => confirmBox(del.text, del.fn);
  return el;
}
function confirmBox(text, fn, label = 'Так, видалити') {
  const el = openSheet('Підтвердження', `<p style="margin:0 0 16px">${esc(text)}</p><div class="row gap"><button class="btn grow" data-act="closeTop">Скасувати</button><button class="btn danger grow" id="cfy">${label}</button></div>`);
  $('#cfy', el).onclick = () => { fn(); closeAll(); };
}

/* ================= Стан інтерфейсу ================= */
const ui = { tab: 'home', anim: true, q: {}, f: { fin: 'all', task: 'today' }, exSel: null, calOff: 0, day: iso(new Date()) };
const TITLES = { home: 'Зюзя', fin: 'Фінанси', goals: 'Мої цілі', train: 'Тренування', more: 'Ще', tasks: 'Завдання', habits: 'Звички', cal: 'Календар', body: 'Вага тіла', settings: 'Налаштування' };
const NAV = [['home', 'home', 'Головна'], ['fin', 'wallet', 'Фінанси'], ['goals', 'target', 'Цілі'], ['train', 'dumbbell', 'Тренування'], ['more', 'more', 'Ще']];
const navOf = t => (['tasks', 'habits', 'cal', 'body', 'settings'].includes(t) ? 'more' : t);

/* ================= Обчислення ================= */
const balance = () => S.tx.reduce((a, t) => a + (t.type === 'in' ? t.amt : -t.amt), 0);
const goalPct = g => (g.target > 0 ? Math.min(100, Math.floor(g.saved / g.target * 100)) : 0);
function daily() {
  const t = today();
  const g = [
    { name: 'Завдання', icon: 'checksq', tab: 'tasks', done: S.tasks.filter(x => x.doneAt === t).length, target: +S.daily.tasks || 0 },
    { name: 'Тренування', icon: 'dumbbell', tab: 'train', done: S.work.filter(w => w.date === t).length, target: +S.daily.workout || 0 }
  ];
  if (S.habits.length) g.push({ name: 'Звички', icon: 'flame', tab: 'habits', done: hDoneToday(), target: S.habits.length });
  const act = g.filter(x => x.target > 0);
  const p = act.length ? act.reduce((a, x) => a + Math.min(1, x.done / x.target), 0) / act.length : 0;
  return { g, p };
}
function streak() {
  const days = new Set(S.work.map(w => w.date)); let n = 0, d = new Date();
  if (!days.has(iso(d))) d = addDays(-1, d);
  while (days.has(iso(d))) { n++; d = addDays(-1, d); }
  return n;
}
/* ================= Екрани ================= */
const views = {}, lists = {};

/* ---- Головна ---- */
views.home = () => {
  const D = daily(), h = new Date().getHours();
  const hello = h < 5 ? 'Доброї ночі' : h < 12 ? 'Доброго ранку' : h < 18 ? 'Доброго дня' : 'Добрий вечір';
  const date = cap(new Date().toLocaleDateString('uk-UA', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }));
  const weekDays = new Set(S.work.filter(w => w.date >= weekStart()).map(w => w.date)).size;
  const activeTasks = S.tasks.filter(t => !t.done && t.date === today()).length;
  const mExp = S.tx.filter(t => t.type === 'out' && t.date.startsWith(today().slice(0, 7))).reduce((a, t) => a + t.amt, 0);
  const goals = S.goals.slice().sort((a, b) => goalPct(b) - goalPct(a)).slice(0, 2);
  const st = streak();
  return `
  <div class="card hero">
    <div class="muted" style="font-size:13px">${esc(date)}</div>
    <div style="font-size:22px;font-weight:800;margin:2px 0 14px">${hello}${S.name ? ', ' + esc(S.name) : ''}!</div>
    <div class="row gap">
      ${ring(D.p, 104, 11)}
      <div class="grow">
        <div style="font-weight:700">Цілі на день</div>
        ${D.g.map(x => x.target > 0 ? `<div class="gline" data-act="go" data-t="${x.tab}">${ICON(x.icon, 18)}<div class="bar"><i style="width:${Math.min(100, x.done / x.target * 100)}%"></i></div><small>${x.done}/${x.target}</small></div>` : '').join('') || '<div class="sub">Увімкни цілі в налаштуваннях</div>'}
      </div>
    </div>
  </div>
  <div class="grid2 mb">
    <div class="card tile c2" data-act="go" data-t="fin"><div class="l">${ICON('wallet', 16)} Баланс</div><div class="v ${balance() < 0 ? 'red' : ''}">${money(balance())}</div></div>
    <div class="card tile c1" data-act="go" data-t="tasks"><div class="l">${ICON('checksq', 16)} Завдань на сьогодні</div><div class="v">${activeTasks}</div></div>
    <div class="card tile c3" data-act="go" data-t="train"><div class="l">${ICON('flame', 16)} Тренувань за тиждень</div><div class="v">${weekDays}${st > 1 ? `<span class="sub" style="font-size:12px;font-weight:600"> · серія ${st} дн.</span>` : ''}</div></div>
    <div class="card tile c4" data-act="go" data-t="fin"><div class="l">${ICON('down', 16)} Витрати за місяць</div><div class="v">${money(mExp)}</div></div>
  </div>
  ${habsHome()}
  <h2>Швидкі дії</h2>
  <div class="grid2 mb">
    <button class="btn" data-act="addTx" data-type="out">${ICON('down', 20)} Витрата</button>
    <button class="btn" data-act="addTx" data-type="in">${ICON('up', 20)} Дохід</button>
    <button class="btn" data-act="addWork">${ICON('dumbbell', 20)} Тренування</button>
    <button class="btn" data-act="addTask">${ICON('checksq', 20)} Завдання</button>
  </div>
  <h2>Мої цілі</h2>
  ${goals.length ? goals.map(g => goalCard(g, true)).join('') : `<div class="card empty">${ICON('target', 34)}<div>Ще немає цілей накопичення</div><button class="btn primary sm" style="margin-top:12px" data-act="addGoal">Створити ціль</button></div>`}`;
};

/* ---- Фінанси ---- */
views.fin = () => {
  const m = today().slice(0, 7); let inc = 0, exp = 0; const cats = {};
  S.tx.forEach(t => { if (t.date.startsWith(m)) { if (t.type === 'in') inc += t.amt; else { exp += t.amt; cats[t.cat] = (cats[t.cat] || 0) + t.amt; } } });
  const bal = balance(), top = Object.entries(cats).sort((a, b) => b[1] - a[1]);
  const mon = cap(new Date().toLocaleDateString('uk-UA', { month: 'long', year: 'numeric' }));
  const f = ui.f.fin;
  return `
  <div class="card hero">
    <div class="muted" style="font-size:13px">Грошей зараз</div>
    <div class="big ${bal < 0 ? 'red' : ''}">${money(bal)}</div>
    <div class="grid2" style="margin-top:12px">
      <div><div class="sub">Доходи, ${mon}</div><b class="grn">+${money(inc)}</b></div>
      <div><div class="sub">Витрати, ${mon}</div><b class="red">−${money(exp)}</b></div>
    </div>
  </div>
  <div class="grid2 mb">
    <button class="btn green" data-act="addTx" data-type="in">${ICON('plus', 20)} Дохід</button>
    <button class="btn primary" data-act="addTx" data-type="out">${ICON('plus', 20)} Витрата</button>
  </div>
  ${top.length ? `<h2>Витрати за категоріями</h2><div class="card">${top.map(([c, v]) => `<div style="margin-bottom:12px"><div class="row between" style="margin-bottom:6px"><span>${esc(c)}</span><b>${money(v)}</b></div>${bar(v / exp * 100)}</div>`).join('').replace(/margin-bottom:12px"><div class="row between"(?![\s\S]*margin-bottom:12px)/, '"><div class="row between"')}</div>` : ''}
  <h2>Історія операцій</h2>
  <div class="search">${ICON('search', 20)}<input data-q="fin" type="search" placeholder="Пошук за категорією, нотаткою, сумою" value="${esc(ui.q.fin || '')}"></div>
  <div class="chips">${[['all', 'Усі'], ['in', 'Доходи'], ['out', 'Витрати']].map(([k, l]) => `<button class="chip ${f === k ? 'on' : ''}" data-act="chip" data-g="fin" data-v="${k}">${l}</button>`).join('')}</div>
  <div id="list">${lists.fin()}</div>`;
};
lists.fin = () => {
  const q = (ui.q.fin || '').toLowerCase().trim(), f = ui.f.fin;
  const arr = S.tx.filter(t => (f === 'all' || t.type === f) && (!q || (t.cat + ' ' + t.note + ' ' + t.amt + ' ' + fmtDate(t.date)).toLowerCase().includes(q)))
    .sort((a, b) => b.date.localeCompare(a.date) || (b.ts || 0) - (a.ts || 0));
  if (!arr.length) return empty('inbox', S.tx.length ? 'Нічого не знайдено' : 'Операцій ще немає. Додай першу!');
  return arr.slice(0, 200).map(t => `<div class="item" data-act="editTx" data-id="${t.id}">
    <div class="badge ${t.type}">${ICON(t.type === 'in' ? 'up' : 'down', 20)}</div>
    <div class="grow"><b>${esc(t.cat)}</b><div class="sub">${esc(t.note || '')}${t.note ? ' · ' : ''}${fmtDate(t.date)}</div></div>
    <div class="amt ${t.type === 'in' ? 'grn' : 'red'}">${t.type === 'in' ? '+' : '−'}${money(t.amt)}</div></div>`).join('') + (arr.length > 200 ? '<div class="sub" style="text-align:center">Показано 200 останніх. Уточни пошук.</div>' : '');
};
function txSheet(type, id) {
  const t = id ? S.tx.find(x => x.id === id) : null; if (t) type = t.type;
  const body = `
    <div class="seg mb"><label><input type="radio" name="type" value="out" ${type === 'out' ? 'checked' : ''}><span>Витрата</span></label><label><input type="radio" name="type" value="in" ${type === 'in' ? 'checked' : ''}><span>Дохід</span></label></div>
    ${fld('Сума (' + S.cur + ')', `<input name="amt" inputmode="decimal" placeholder="0" required value="${t ? t.amt : ''}">`)}
    ${fld('Категорія', `<select name="cat">${opts(type === 'in' ? INC_CATS : EXP_CATS, t && t.cat)}</select>`)}
    ${fld('Нотатка', `<input name="note" maxlength="80" placeholder="Необов’язково" value="${esc(t ? t.note : '')}">`)}
    ${fld('Дата', `<input type="date" name="date" required value="${t ? t.date : today()}">`)}`;
  const el = openForm({
    title: t ? 'Редагувати операцію' : (type === 'in' ? 'Новий дохід' : 'Нова витрата'), body,
    onSubmit: fd => {
      const amt = parseNum(fd.amt);
      if (!(amt > 0)) { toast('Введи суму більше нуля'); return false; }
      const o = { type: fd.type, amt, cat: fd.cat, note: (fd.note || '').trim(), date: fd.date || today() };
      if (t) Object.assign(t, o); else S.tx.push({ id: uid(), ts: Date.now(), ...o });
      save(); render(); toast(t ? 'Збережено' : 'Операцію додано');
    },
    del: t && { text: 'Видалити цю операцію?', fn: () => { S.tx = S.tx.filter(x => x.id !== t.id); save(); render(); toast('Видалено'); } }
  });
  el.querySelectorAll('input[name=type]').forEach(r => r.addEventListener('change', () => {
    const sel = $('select[name=cat]', el); sel.innerHTML = opts(r.value === 'in' ? INC_CATS : EXP_CATS);
  }));
}

/* ---- Цілі ---- */
function goalCard(g, compact) {
  const p = goalPct(g), left = Math.max(0, g.target - g.saved), icon = (GOAL_KINDS[g.kind] || GOAL_KINDS.other)[1];
  return `<div class="card">
    <div class="row gap"><div class="badge">${ICON(icon, 22)}</div>
      <div class="grow"><b style="font-size:17px">${esc(g.name)}</b><div class="sub">${money(g.saved)} з ${money(g.target)}</div></div>
      <div style="font-size:22px;font-weight:800" class="${p >= 100 ? 'grn' : 'vio'}">${p}%</div></div>
    <div style="margin:14px 0 8px">${bar(p)}</div>
    <div class="row between sub"><span>${p >= 100 ? 'Ціль досягнуто!' : 'Залишилось ' + money(left)}</span><span>${p}% виконано</span></div>
    ${compact ? '' : `<div class="row gap" style="margin-top:14px"><button class="btn green grow" data-act="goalMoney" data-id="${g.id}">${ICON('plus', 18)} Рух коштів</button><button class="btn" data-act="editGoal" data-id="${g.id}" aria-label="Редагувати">${ICON('edit', 18)}</button></div>
    ${(g.log || []).length ? `<div class="sub" style="margin-top:12px">${g.log.slice(-3).reverse().map(l => `${fmtShort(l.date)}: ${l.amt > 0 ? '+' : '−'}${money(Math.abs(l.amt))}`).join(' · ')}</div>` : ''}`}
  </div>`;
}
views.goals = () => `
  <button class="btn primary block mb" data-act="addGoal">${ICON('plus', 20)} Нова ціль</button>
  ${S.goals.length ? S.goals.map(g => goalCard(g)).join('') : `<div class="card empty">${ICON('target', 36)}<div>Додай мрію: мотоцикл, телефон чи щось своє. Я рахуватиму прогрес.</div></div>`}`;
function goalSheet(id) {
  const g = id ? S.goals.find(x => x.id === id) : null; const kind = g ? g.kind : 'moto';
  const body = `
    ${fld('Тип', `<select name="kind">${Object.entries(GOAL_KINDS).map(([k, v]) => `<option value="${k}" ${k === kind ? 'selected' : ''}>${v[0]}</option>`).join('')}</select>`)}
    ${fld('Назва', `<input name="name" maxlength="40" required value="${esc(g ? g.name : GOAL_KINDS.moto[0])}">`)}
    ${fld('Цільова сума (' + S.cur + ')', `<input name="target" inputmode="decimal" required value="${g ? g.target : ''}" placeholder="Наприклад, 80000">`)}
    ${fld('Вже накопичено (' + S.cur + ')', `<input name="saved" inputmode="decimal" value="${g ? g.saved : 0}">`)}`;
  const el = openForm({
    title: g ? 'Редагувати ціль' : 'Нова ціль', body,
    onSubmit: fd => {
      const target = parseNum(fd.target), saved = fd.saved === '' ? 0 : parseNum(fd.saved);
      if (!(target > 0)) { toast('Введи цільову суму'); return false; }
      if (!(saved >= 0)) { toast('Накопичено: введи число'); return false; }
      const o = { kind: fd.kind, name: fd.name.trim() || GOAL_KINDS[fd.kind][0], target, saved };
      if (g) Object.assign(g, o); else S.goals.push({ id: uid(), log: [], ...o });
      save(); render(); toast('Збережено');
    },
    del: g && { text: 'Видалити ціль «' + g.name + '»?', fn: () => { S.goals = S.goals.filter(x => x.id !== g.id); save(); render(); toast('Ціль видалено'); } }
  });
  const kindSel = $('select[name=kind]', el), nameIn = $('input[name=name]', el);
  kindSel.addEventListener('change', () => {
    const defs = Object.values(GOAL_KINDS).map(v => v[0]);
    if (!nameIn.value.trim() || defs.includes(nameIn.value.trim())) nameIn.value = GOAL_KINDS[kindSel.value][0];
  });
}
function goalMoneySheet(id) {
  const g = S.goals.find(x => x.id === id); if (!g) return;
  openForm({
    title: g.name + ': рух коштів',
    body: `<div class="seg mb"><label><input type="radio" name="dir" value="add" checked><span>Поповнити</span></label><label><input type="radio" name="dir" value="sub"><span>Зняти</span></label></div>
    ${fld('Сума (' + S.cur + ')', `<input name="amt" inputmode="decimal" required placeholder="0">`)}
    <label class="row gap mb" style="cursor:pointer"><input type="checkbox" name="mirror" checked style="width:20px;height:20px"><span>Показати у фінансах (витрата / дохід)</span></label>`,
    submit: 'Підтвердити',
    onSubmit: fd => {
      const amt = parseNum(fd.amt);
      if (!(amt > 0)) { toast('Введи суму більше нуля'); return false; }
      const sub = fd.dir === 'sub';
      if (sub && amt > g.saved) { toast('На цілі лише ' + money(g.saved)); return false; }
      g.saved += sub ? -amt : amt;
      (g.log = g.log || []).push({ date: today(), amt: sub ? -amt : amt });
      if (fd.mirror) S.tx.push({ id: uid(), ts: Date.now(), type: sub ? 'in' : 'out', amt, cat: sub ? 'Повернення з цілі' : 'Накопичення', note: g.name, date: today() });
      save(); render(); toast(goalPct(g) >= 100 ? 'Ціль досягнуто! Вітаю!' : 'Збережено');
    }
  });
}

/* ---- Тренування ---- */
const exNames = () => [...new Set([...PRESET_EX, ...S.work.map(w => w.ex)])];
views.train = () => {
  const used = [...new Set(S.work.slice().sort((a, b) => b.date.localeCompare(a.date) || (b.ts || 0) - (a.ts || 0)).map(w => w.ex))];
  if (!ui.exSel || !used.includes(ui.exSel)) ui.exSel = used[0] || null;
  const days = new Set(S.work.map(w => w.date)).size, wk = new Set(S.work.filter(w => w.date >= weekStart()).map(w => w.date)).size;
  return `
  <div class="grid2 mb">
    <div class="card tile" style="cursor:default"><div class="l">${ICON('flame', 16)} Серія днів</div><div class="v">${streak()}</div></div>
    <div class="card tile" style="cursor:default"><div class="l">${ICON('calendar', 16)} Цього тижня</div><div class="v">${wk}<span class="sub" style="font-size:14px"> / всього ${days}</span></div></div>
  </div>
  <div class="grid2 mb"><button class="btn primary" data-act="addWork">${ICON('plus', 20)} Записати</button><button class="btn" data-act="tplList">${ICON('list', 20)} Шаблони</button></div>
  ${ui.exSel ? progressCard(ui.exSel, used) : ''}
  <h2>Історія</h2>
  <div class="search">${ICON('search', 20)}<input data-q="train" type="search" placeholder="Пошук вправи або групи м’язів" value="${esc(ui.q.train || '')}"></div>
  <div id="list">${lists.train()}</div>`;
};
function progressCard(ex, used) {
  const by = {}; S.work.filter(w => w.ex === ex).forEach(w => { by[w.date] = (by[w.date] || 0) + w.sets * w.reps; });
  const ds = Object.keys(by).sort().slice(-8), vals = ds.map(d => by[d]), mx = Math.max(...vals, 1);
  const all = S.work.filter(w => w.ex === ex), rec = Math.max(...all.map(w => w.reps)), tot = all.reduce((a, w) => a + w.sets * w.reps, 0);
  let diff = '';
  if (vals.length > 1 && vals[vals.length - 2] > 0) { const d = Math.round((vals[vals.length - 1] / vals[vals.length - 2] - 1) * 100); diff = `<span class="pill ${d >= 0 ? 'grn' : 'red'}">${d >= 0 ? '+' : ''}${d}% до попереднього</span>`; }
  const W = 300, H = 120, bw = Math.min(26, (W - 10) / ds.length - 8);
  const svg = ds.map((d, i) => {
    const x = 10 + i * ((W - 20) / ds.length) + ((W - 20) / ds.length - bw) / 2, h = Math.max(4, vals[i] / mx * 78), y = 96 - h;
    return `<rect class="b" x="${x}" y="${y}" width="${bw}" height="${h}" rx="6" style="fill:${i === ds.length - 1 ? 'var(--grn)' : 'var(--vio)'};animation-delay:${i * 60}ms"/>
    <text x="${x + bw / 2}" y="${y - 5}" text-anchor="middle" fill="#ece9f6" font-size="10" font-weight="700">${vals[i]}</text>
    <text x="${x + bw / 2}" y="112" text-anchor="middle" fill="#8d87a6" font-size="9">${fmtShort(d)}</text>`;
  }).join('');
  return `<div class="card"><div class="row between mb"><h3>Прогрес</h3><select data-chg="exSel" style="width:auto;min-height:38px;padding:6px 10px">${opts(used, ex)}</select></div>
    <svg class="chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Обсяг за тренування">${svg}</svg>
    <div class="sub" style="margin:6px 0 10px">Обсяг (підходи × повторення) за останні тренування</div>
    <div class="row wrap gap"><span class="pill vio">Рекорд: ${rec} повт.</span><span class="pill">Усього: ${tot}</span>${diff}</div></div>`;
}
lists.train = () => {
  const q = (ui.q.train || '').toLowerCase().trim();
  const arr = S.work.filter(w => !q || (w.ex + ' ' + grpOf(w.ex) + ' ' + (w.note || '')).toLowerCase().includes(q)).sort((a, b) => b.date.localeCompare(a.date) || (b.ts || 0) - (a.ts || 0));
  if (!arr.length) return empty('dumbbell', S.work.length ? 'Нічого не знайдено' : 'Записів ще немає. Додай перше тренування!');
  let last = '', out = '';
  arr.slice(0, 200).forEach(w => {
    if (w.date !== last) { last = w.date; out += `<div class="dgroup">${w.date === today() ? 'Сьогодні' : fmtDate(w.date)}</div>`; }
    out += `<div class="item" data-act="editWork" data-id="${w.id}"><div class="badge lime">${ICON('dumbbell', 20)}</div>
      <div class="grow"><b>${esc(w.ex)}</b><div class="sub">${esc(grpOf(w.ex))}${w.note ? ' · ' + esc(w.note) : ''}</div></div>
      <div class="amt">${w.sets} × ${w.reps}${w.weight ? `<div class="sub" style="text-align:right">${w.weight} кг</div>` : ''}</div></div>`;
  });
  return out;
};
function workSheet(id) {
  const w = id ? S.work.find(x => x.id === id) : null;
  const groups = [...GYM.map(g => g[0]), CUSTOM];
  const g0 = w ? grpOf(w.ex) : (ui.exSel ? grpOf(ui.exSel) : GYM[0][0]);
  const ex0 = w ? w.ex : (ui.exSel || '');
  const exOpts = (g, sel) => exList(g).map(x => `<option value="${esc(x)}" ${x === sel ? 'selected' : ''}>${esc(x)}</option>`).join('') + '<option value="__new">＋ Своя вправа…</option>';
  const body = `
    ${fld('Група м’язів', `<select name="grp">${groups.map(g => `<option ${g === g0 ? 'selected' : ''}>${esc(g)}</option>`).join('')}</select>`)}
    ${fld('Вправа', `<select name="exs">${exOpts(g0, ex0)}</select>`)}
    <div id="exnew" hidden>${fld('Назва своєї вправи', `<input name="exc" maxlength="40" placeholder="Наприклад, Жим Сміта">`)}</div>
    <div class="grid2">${fld('Підходи', `<input name="sets" type="number" inputmode="numeric" min="1" max="99" required value="${w ? w.sets : 3}">`)}${fld('Повторення / сек.', `<input name="reps" type="number" inputmode="numeric" min="1" max="9999" required value="${w ? w.reps : ''}">`)}</div>
    <div class="grid2">${fld('Вага, кг (необов’язково)', `<input name="weight" inputmode="decimal" value="${w && w.weight ? w.weight : ''}">`)}${fld('Дата', `<input type="date" name="date" required value="${w ? w.date : today()}">`)}</div>
    ${fld('Нотатка', `<input name="note" maxlength="80" value="${esc(w ? w.note : '')}" placeholder="Необов’язково">`)}`;
  const el = openForm({
    title: w ? 'Редагувати запис' : 'Нове тренування', body,
    onSubmit: fd => {
      const ex = (fd.exs === '__new' ? (fd.exc || '') : fd.exs).trim();
      const sets = parseInt(fd.sets, 10), reps = parseInt(fd.reps, 10), weight = fd.weight ? parseNum(fd.weight) : 0;
      if (!ex) { toast('Введи назву вправи'); return false; }
      if (!(sets > 0) || !(reps > 0)) { toast('Вкажи підходи та повторення'); return false; }
      if (fd.weight && !(weight >= 0)) { toast('Вага: введи число'); return false; }
      const o = { ex, sets, reps, weight: weight || 0, date: fd.date || today(), note: (fd.note || '').trim() };
      if (w) Object.assign(w, o); else S.work.push({ id: uid(), ts: Date.now(), ...o });
      ui.exSel = o.ex; save(); render(); toast(w ? 'Збережено' : 'Тренування записано');
    },
    del: w && { text: 'Видалити цей запис?', fn: () => { S.work = S.work.filter(x => x.id !== w.id); save(); render(); toast('Видалено'); } }
  });
  const gs = $('select[name=grp]', el), es = $('select[name=exs]', el), nw = $('#exnew', el);
  const sync = () => { nw.hidden = es.value !== '__new'; };
  gs.addEventListener('change', () => { es.innerHTML = exOpts(gs.value, ''); sync(); });
  es.addEventListener('change', sync); sync();
}

/* ---- Завдання ---- */
const hhmm = () => { const d = new Date(); return p2(d.getHours()) + ':' + p2(d.getMinutes()); };
const notifState = () => (!('Notification' in window) ? 'unsupported' : Notification.permission);
function notifBanner() {
  const need = S.tasks.some(t => t.time && !t.done && t.date === today()) || S.habits.some(h => h.rem && h.rem.length), st = notifState();
  if (!need || st === 'granted' || st === 'unsupported') return '';
  return `<div class="card note"><div class="row gap">${ICON('bell', 22)}<div class="grow sub" style="color:var(--tx)">${st === 'denied' ? 'Сповіщення заблоковано. Дозволь їх для цього сайту в налаштуваннях Chrome.' : 'Щоб нагадування приходили на екран, дозволь сповіщення.'}</div>${st === 'default' ? '<button class="btn sm primary" data-act="askNotif">Дозволити</button>' : ''}</div></div>`;
}
views.tasks = () => {
  const f = ui.f.task, hist = S.tasks.some(t => t.date < today());
  return `<form id="qa" class="qa"><input name="t" maxlength="200" placeholder="Завдання на сьогодні…" autocomplete="off"><input class="qt" type="time" name="tm" aria-label="Час нагадування"><button class="btn primary" type="submit" aria-label="Додати" style="padding:0 16px">${ICON('plus', 22)}</button></form>
  ${notifBanner()}
  <div class="search">${ICON('search', 20)}<input data-q="task" type="search" placeholder="Пошук завдань" value="${esc(ui.q.task || '')}"></div>
  <div class="chips">${[['today', 'Сьогодні'], ['hist', 'Історія']].map(([k, l]) => `<button class="chip ${f === k ? 'on' : ''}" data-act="chip" data-g="task" data-v="${k}">${l}</button>`).join('')}${f === 'hist' && hist ? '<button class="chip" data-act="clearHist">Очистити історію</button>' : ''}</div>
  ${f === 'today' ? '<div class="sub mb" style="padding:0 4px">Завдання діють один день. Що не встиг, потрапить в історію. Час справа від назви: нагадування.</div>' : ''}
  <div id="list">${lists.tasks()}</div>`;
};
function taskRow(t, t0, now) {
  const past = t.date < t0;
  const tm = t.time ? `<span class="pill ${!t.done && !past && t.time <= now ? 'red' : 'vio'}">${ICON('bell', 11)} ${t.time}</span>` : '';
  const st = past ? (t.done ? '<span class="pill grn">Виконано</span>' : '<span class="pill red">Не виконано</span>') : '';
  const check = t.done
    ? `<span class="check on" role="img" aria-label="Завдання виконано">${ICON('check', 16)}</span>`
    : `<button class="check" data-act="toggleTask" data-id="${t.id}" aria-label="Позначити виконаним"></button>`;
  return `<div class="item p${t.prio} ${t.done ? 'done' : ''}">${check}
    <div class="grow" data-act="editTask" data-id="${t.id}"><div class="tt">${esc(t.title)}</div><div class="row gap wrap" style="margin-top:4px">${tm}${st}<span class="pill ${PRIO[t.prio][1]}">${PRIO[t.prio][0]}</span></div></div>
    ${past && !t.done ? `<button class="btn sm" data-act="moveToday" data-id="${t.id}">На сьогодні</button>` : `<button class="icon-btn" data-act="editTask" data-id="${t.id}" aria-label="Редагувати">${ICON('edit', 20)}</button>`}</div>`;
}
lists.tasks = () => {
  const q = (ui.q.task || '').toLowerCase().trim(), f = ui.f.task, t0 = today(), now = hhmm();
  const match = t => !q || t.title.toLowerCase().includes(q);
  if (f === 'today') {
    const arr = S.tasks.filter(t => t.date === t0 && match(t))
      .sort((a, b) => (+!!a.done) - (+!!b.done) || (a.time || '99').localeCompare(b.time || '99') || a.prio - b.prio || a.ts - b.ts);
    if (!arr.length) return empty('checksq', S.tasks.some(t => t.date === t0) ? 'Нічого не знайдено' : 'На сьогодні справ немає. Додай першу вище!');
    return arr.map(t => taskRow(t, t0, now)).join('');
  }
  const arr = S.tasks.filter(t => t.date < t0 && match(t)).sort((a, b) => b.date.localeCompare(a.date) || a.ts - b.ts).slice(0, 150);
  if (!arr.length) return empty('inbox', S.tasks.some(t => t.date < t0) ? 'Нічого не знайдено' : 'Історія порожня');
  let last = '', out = '';
  arr.forEach(t => {
    if (t.date !== last) { last = t.date; out += `<div class="dgroup">${t.date === iso(addDays(-1)) ? 'Вчора' : fmtDate(t.date)}</div>`; }
    out += taskRow(t, t0, now);
  });
  return out;
};
/* повертає true, якщо час уже минув і нагадування не спрацює */
function setReminder(t, time) {
  t.time = time || ''; t.notified = false;
  if (!t.time) return false;
  ensureNotifPerm();
  if (t.date === today() && t.time <= hhmm()) { t.notified = true; return true; }
  return false;
}
function taskSheet(id) {
  const t = id ? S.tasks.find(x => x.id === id) : null;
  openForm({
    title: t ? 'Редагувати завдання' : 'Нове завдання',
    body: fld('Що зробити', `<input name="title" required maxlength="200" value="${esc(t ? t.title : '')}">`)
      + `<div class="grid2">${fld('Нагадування о', `<input type="time" name="time" value="${t && t.time ? t.time : ''}">`)}${fld('Важливість', `<select name="prio">${Object.entries(PRIO).map(([k, v]) => `<option value="${k}" ${(t ? t.prio : 1) == k ? 'selected' : ''}>${v[0]}</option>`).join('')}</select>`)}</div>
      <div class="sub mb">Завдання діє лише сьогодні. Час можна не вказувати.</div>`,
    onSubmit: fd => {
      if (!fd.title.trim()) { toast('Введи назву завдання'); return false; }
      let passed = false;
      if (t) {
        t.title = fd.title.trim(); t.prio = +fd.prio;
        if ((fd.time || '') !== t.time) passed = setReminder(t, fd.time);
      } else {
        const n = { id: uid(), ts: Date.now(), title: fd.title.trim(), date: today(), time: '', prio: +fd.prio, done: false, notified: false };
        passed = setReminder(n, fd.time); S.tasks.push(n);
      }
      save(); render(); toast(passed ? 'Цей час уже минув, нагадування не спрацює' : 'Збережено');
    },
    del: t && { text: 'Видалити це завдання?', fn: () => { S.tasks = S.tasks.filter(x => x.id !== t.id); save(); render(); toast('Видалено'); } }
  });
}

/* ---- Нагадування ---- */
function ensureNotifPerm() {
  if (notifState() !== 'default') return;
  try { Notification.requestPermission().then(() => { if (ui.tab === 'tasks' || ui.tab === 'settings') render(); }); } catch (e) {}
}
function sysNotify(t) {
  const opt = { body: t.title, icon: 'icon-192.png', badge: 'icon-192.png', tag: 'task-' + t.id, vibrate: [250, 120, 250], requireInteraction: true };
  const title = 'Зюзя · ' + t.time;
  const fallback = () => { try { new Notification(title, opt); } catch (e) {} };
  if (navigator.serviceWorker && navigator.serviceWorker.getRegistration)
    navigator.serviceWorker.getRegistration().then(reg => { if (reg) reg.showNotification(title, opt); else fallback(); }).catch(fallback);
  else fallback();
}
function remSheet(t) {
  const h = t.hid ? S.habits.find(x => x.id === t.hid) : null;
  const act = h ? (h.type === 'count'
    ? `<button class="btn green grow" data-act="habInc" data-id="${h.id}" data-n="1" data-close="1">+1 ${esc(h.unit)}</button>`
    : `<button class="btn green grow" data-act="habToggle" data-id="${h.id}" data-d="${today()}" data-close="1">Зроблено</button>`)
    : `<button class="btn green grow" data-act="remDone" data-id="${t.id}">Виконано</button>`;
  openSheet(h ? 'Звичка' : 'Нагадування', `<div style="text-align:center;padding:6px 0 18px">${ICON(h ? 'flame' : 'bell', 38)}<div class="vio" style="font-weight:800;margin-top:6px">${t.time}</div><div style="font-size:21px;font-weight:800;margin-top:6px">${esc(t.title)}</div></div>
    <div class="row gap"><button class="btn grow" data-act="closeTop">Пізніше</button>${act}</div>`);
}
function deliver(t) {
  if (document.visibilityState === 'visible') {
    try { navigator.vibrate && navigator.vibrate([250, 120, 250]); } catch (e) {}
    if (stack.length) toast('Нагадування ' + t.time + ': ' + t.title); else remSheet(t);
    return true;
  }
  if (notifState() === 'granted') { sysNotify(t); return true; }
  return false;
}
function checkReminders() {
  const t0 = today(), now = hhmm(); let changed = false;
  S.tasks.forEach(t => {
    if (t.done || t.notified || !t.time || t.date !== t0 || t.time > now) return;
    if (deliver(t)) { t.notified = true; changed = true; }
  });
  S.habits.forEach(h => {
    if (!h.rem || !h.rem.length || hDone(h, t0)) return;
    if (!h.rf || h.rf.d !== t0) h.rf = { d: t0, t: [] };
    const due = h.rem.filter(x => x <= now && !h.rf.t.includes(x));
    if (!due.length) return;
    const last = due[due.length - 1];
    if (deliver({ id: h.id + last, hid: h.id, time: last, title: h.name })) { h.rf.t.push(...due); changed = true; }
  });
  if (changed) save();
}
function setHabRem(h, times) {
  h.rem = [...new Set(times.filter(Boolean))].sort();
  h.rf = { d: today(), t: h.rem.filter(x => x <= hhmm()) };
  if (h.rem.length) ensureNotifPerm();
  return h.rf.t.length > 0;
}
function dayTick() {
  if (ui.day !== today()) { ui.day = today(); if (!stack.length) { ui.anim = true; render(); } }
  checkReminders();
}

/* ---- Шаблони тренувань ---- */
const allTpls = () => [...S.tpls, ...TPL_BUILTIN];
const lastW = ex => { const a = S.work.filter(w => w.ex === ex && w.weight).sort((x, y) => y.date.localeCompare(x.date) || (y.ts || 0) - (x.ts || 0)); return a[0] ? a[0].weight : ''; };
function tplList() {
  const row = t => `<div class="item" data-act="tplStart" data-id="${t.id}"><div class="badge lime">${ICON('dumbbell', 20)}</div><div class="grow"><b>${esc(t.name)}</b><div class="sub">Вправ: ${t.items.length}</div></div>${t.builtin ? `<button class="icon-btn" data-act="tplCopy" data-id="${t.id}" aria-label="Копіювати в мої">${ICON('plus', 20)}</button>` : `<button class="icon-btn" data-act="tplEdit" data-id="${t.id}" aria-label="Редагувати">${ICON('edit', 20)}</button>`}</div>`;
  openSheet('Шаблони тренувань', `<button class="btn primary block mb" data-act="tplNew">${ICON('plus', 20)} Новий шаблон</button>${S.tpls.length ? '<div class="dgroup">Мої</div>' + S.tpls.map(row).join('') : ''}<div class="dgroup">Готові (плюс: копія в мої)</div>${TPL_BUILTIN.map(row).join('')}`);
}
function tplStart(id) {
  const t = allTpls().find(x => x.id === id); if (!t) return;
  const rows = t.items.map((it, i) => `<div class="card" style="padding:12px"><label class="row gap" style="cursor:pointer"><input type="checkbox" name="on${i}" checked style="width:20px;height:20px"><b class="grow">${esc(it.ex)}</b></label>
    <div class="grid3" style="margin-top:8px"><input name="s${i}" type="number" inputmode="numeric" min="1" max="99" value="${it.sets}" aria-label="Підходи"><input name="r${i}" type="number" inputmode="numeric" min="1" max="9999" value="${it.reps}" aria-label="Повторення"><input name="w${i}" inputmode="decimal" value="${lastW(it.ex)}" placeholder="кг" aria-label="Вага"></div></div>`).join('');
  openForm({
    title: t.name, submit: 'Записати тренування',
    body: `<div class="sub mb">У полях: підходи, повторення, вага (кг). Зніми галочку з вправи, яку пропускаєш.</div>${rows}`,
    onSubmit: fd => {
      let n = 0; const date = today();
      t.items.forEach((it, i) => {
        if (!fd['on' + i]) return;
        const sets = parseInt(fd['s' + i], 10), reps = parseInt(fd['r' + i], 10), w = fd['w' + i] ? parseNum(fd['w' + i]) : 0;
        if (!(sets > 0) || !(reps > 0)) return;
        S.work.push({ id: uid(), ts: Date.now() + i, ex: it.ex, sets, reps, weight: w > 0 ? w : 0, date, note: t.name }); n++;
      });
      if (!n) { toast('Немає вправ для запису'); return false; }
      ui.exSel = t.items[0].ex; save(); render(); toast('Записано вправ: ' + n);
    }
  });
}
function tplBuilder(id, seed) {
  const t = id ? S.tpls.find(x => x.id === id) : null, src = t || seed || { name: '', items: [] };
  const draft = { items: src.items.map(i => ({ ...i })) }, groups = [...GYM.map(g => g[0]), CUSTOM];
  const list = () => draft.items.length ? draft.items.map((it, i) => `<div class="row gap mb"><b class="grow" style="font-size:14px">${esc(it.ex)}</b><input class="mini" data-ti="${i}" data-tf="sets" type="number" inputmode="numeric" min="1" max="99" value="${it.sets}" aria-label="Підходи"><span class="muted">×</span><input class="mini" data-ti="${i}" data-tf="reps" type="number" inputmode="numeric" min="1" max="9999" value="${it.reps}" aria-label="Повторення"><button type="button" class="icon-btn" data-tdel="${i}" aria-label="Прибрати">${ICON('x', 18)}</button></div>`).join('') : '<div class="sub mb">Додай вправи нижче.</div>';
  const exOpts = g => exList(g).map(x => `<option>${esc(x)}</option>`).join('') || '<option value="">Немає вправ</option>';
  const el = openForm({
    title: t ? 'Редагувати шаблон' : 'Новий шаблон',
    body: `${fld('Назва шаблону', `<input name="name" required maxlength="40" value="${esc(src.name)}" placeholder="Наприклад, День ніг">`)}<div id="tbi">${list()}</div>
      <div class="dgroup">Додати вправу</div>
      <div class="grid2">${fld('Група', `<select id="tbg">${groups.map(g => `<option>${esc(g)}</option>`).join('')}</select>`)}${fld('Вправа', `<select id="tbe">${exOpts(groups[0])}</select>`)}</div>
      <button type="button" class="btn block mb" id="tba">${ICON('plus', 18)} Додати до шаблону</button>`,
    onSubmit: fd => {
      const name = fd.name.trim();
      if (!name) { toast('Введи назву шаблону'); return false; }
      if (!draft.items.length) { toast('Додай хоча б одну вправу'); return false; }
      const items = draft.items.map(i => ({ ex: i.ex, sets: Math.max(1, parseInt(i.sets, 10) || 3), reps: Math.max(1, parseInt(i.reps, 10) || 10) }));
      if (t) { t.name = name; t.items = items; } else S.tpls.push({ id: uid(), name, items });
      save(); toast('Шаблон збережено');
    },
    del: t && { text: 'Видалити шаблон «' + t.name + '»?', fn: () => { S.tpls = S.tpls.filter(x => x.id !== t.id); save(); toast('Видалено'); } }
  });
  const refresh = () => { $('#tbi', el).innerHTML = list(); }, ge = $('#tbg', el), ee = $('#tbe', el);
  ge.addEventListener('change', () => { ee.innerHTML = exOpts(ge.value); });
  $('#tba', el).addEventListener('click', () => { if (!ee.value) { toast('Спочатку обери вправу'); return; } draft.items.push({ ex: ee.value, sets: 3, reps: 10 }); refresh(); });
  el.addEventListener('input', e => { const i = e.target.dataset.ti; if (i !== undefined) draft.items[+i][e.target.dataset.tf] = e.target.value; });
  el.addEventListener('click', e => { const b = e.target.closest('[data-tdel]'); if (b) { draft.items.splice(+b.dataset.tdel, 1); refresh(); } });
}

/* ---- Звички ---- */
const hVal = (h, d) => +h.log[d] || 0;
const hDone = (h, d) => hVal(h, d) >= h.goal;
const hDoneToday = () => S.habits.filter(h => hDone(h, today())).length;
function hStreak(h) {
  let n = 0, d = new Date();
  if (!hDone(h, iso(d))) d = addDays(-1, d);
  while (hDone(h, iso(d))) { n++; d = addDays(-1, d); }
  return n;
}
function hBest(h) {
  const ds = Object.keys(h.log).filter(k => hDone(h, k)).sort(); let best = 0, cur = 0, prev = null;
  for (const k of ds) { cur = prev && iso(addDays(1, new Date(prev + 'T00:00:00'))) === k ? cur + 1 : 1; best = Math.max(best, cur); prev = k; }
  return best;
}
function hCtl(h) {
  const d = today(), v = hVal(h, d);
  if (h.type === 'check') return hDone(h, d)
    ? `<span class="check on" role="img" aria-label="Звичку виконано" style="width:34px;height:34px;border-radius:11px">${ICON('check', 20)}</span>`
    : `<button class="check" style="width:34px;height:34px;border-radius:11px" data-act="habToggle" data-id="${h.id}" data-d="${d}" aria-label="Позначити виконаним"></button>`;
  return `<div class="step"><b class="${hDone(h, d) ? 'grn' : ''}">${Math.min(v, h.goal)}/${h.goal} <span class="sub">${esc(h.unit)}</span></b><button class="icon-btn" ${v >= h.goal ? 'disabled title="Норму вже виконано"' : ''} data-act="habInc" data-id="${h.id}" data-n="1" aria-label="Додати ${esc(h.unit)}">${ICON('plus', 20)}</button></div>`;
}
function habsHome() {
  if (!S.habits.length) return `<div class="item" data-act="go" data-t="habits"><div class="badge lime">${ICON('flame', 20)}</div><div class="grow"><b>Звички</b><div class="sub">Вода, сон, зарядка. Додай і рахуй серії днів</div></div>${ICON('chevron', 20)}</div>`;
  return `<h2>Звички сьогодні</h2>` + S.habits.slice(0, 5).map(h => { const st = hStreak(h); return `<div class="item" data-act="go" data-t="habits"><div class="badge lime">${ICON('flame', 20)}</div><div class="grow"><b>${esc(h.name)}</b><div class="sub">${st ? `<span class="fire">Серія ${st} дн.</span>` : 'Серії поки немає'}</div></div>${hCtl(h)}</div>`; }).join('');
}
views.habits = () => {
  const wd = ['нд', 'пн', 'вт', 'ср', 'чт', 'пт', 'сб'], days = Array.from({ length: 7 }, (_, i) => addDays(i - 6));
  const have = new Set(S.habits.map(h => h.name.toLowerCase()));
  const presets = Object.entries(HAB_PRESETS).filter(([, p]) => !have.has(p[0].toLowerCase()));
  return `<button class="btn primary block mb" data-act="addHab">${ICON('plus', 20)} Нова звичка</button>
  ${notifBanner()}
  ${presets.length ? `<div class="chips">${presets.map(([k, p]) => `<button class="chip" data-act="habPreset" data-v="${k}">＋ ${p[0]}</button>`).join('')}</div>` : ''}
  ${S.habits.length ? S.habits.map(h => { const st = hStreak(h), bs = hBest(h); return `<div class="card"><div class="row gap"><div class="badge lime">${ICON('flame', 22)}</div>
    <div class="grow"><b style="font-size:17px">${esc(h.name)}</b><div class="sub">${st ? `<span class="fire">Серія ${st} дн.</span>` : 'Серії поки немає'} · рекорд ${bs}${h.rem && h.rem.length ? ` <span class="pill vio">${ICON('bell', 11)} ${h.rem.join(' · ')}</span>` : ''}</div></div>${hCtl(h)}<button class="icon-btn" data-act="editHab" data-id="${h.id}" aria-label="Редагувати">${ICON('edit', 20)}</button></div>
    <div class="wk" style="margin-top:14px">${days.map(d => { const k = iso(d); return `<button class="${hDone(h, k) ? 'on' : ''} ${k === today() ? 'today' : ''}" data-act="habToggle" data-id="${h.id}" data-d="${k}"><i>${hDone(h, k) ? ICON('check', 14) : ''}</i>${wd[d.getDay()]}</button>`; }).join('')}</div></div>`; }).join('')
    : `<div class="card empty">${ICON('flame', 36)}<div>Додай звичку: воду, сон, зарядку. Кожен день без пропуску збільшує серію.</div></div>`}`;
};
function habSheet(id) {
  const h = id ? S.habits.find(x => x.id === id) : null, cnt = h && h.type === 'count';
  const el = openForm({
    title: h ? 'Редагувати звичку' : 'Нова звичка',
    body: fld('Назва', `<input name="name" required maxlength="30" value="${esc(h ? h.name : '')}" placeholder="Наприклад, Вода">`)
      + fld('Тип', `<select name="type"><option value="check" ${cnt ? '' : 'selected'}>Зробив / не зробив</option><option value="count" ${cnt ? 'selected' : ''}>Лічильник (склянки, години…)</option></select>`)
      + `<div id="hcnt" hidden><div class="grid2">${fld('Норма на день', `<input name="goal" type="number" inputmode="numeric" min="1" max="99" value="${cnt ? h.goal : 8}">`)}${fld('Одиниця', `<input name="unit" maxlength="8" value="${esc(cnt ? h.unit : 'скл.')}" placeholder="скл.">`)}</div></div>`
      + `<div class="sub" style="font-weight:700;margin-bottom:6px">Нагадування (до 3 разів на день)</div><div class="grid3">${[0, 1, 2].map(i => `<input type="time" name="rt${i}" value="${(h && h.rem && h.rem[i]) || ''}" aria-label="Час ${i + 1}">`).join('')}</div><div class="sub mb" style="margin-top:6px">Якщо норму вже виконано, нагадування не приходить.</div>`,
    onSubmit: fd => {
      const name = fd.name.trim(); if (!name) { toast('Введи назву звички'); return false; }
      const type = fd.type === 'count' ? 'count' : 'check', goal = type === 'count' ? Math.max(1, parseInt(fd.goal, 10) || 1) : 1, unit = type === 'count' ? (fd.unit || '').trim() : '';
      const times = [0, 1, 2].map(i => fd['rt' + i]).filter(Boolean); let passed = false;
      if (h) { Object.assign(h, { name, type, goal, unit }); for (const k of Object.keys(h.log || {})) h.log[k] = Math.min(goal, Math.max(0, Math.trunc(+h.log[k] || 0))); if (JSON.stringify([...new Set(times)].sort()) !== JSON.stringify(h.rem || [])) passed = setHabRem(h, times); }
      else { const n = { id: uid(), name, type, goal, unit, log: {}, rem: [], rf: null }; passed = setHabRem(n, times); S.habits.push(n); }
      save(); render(); toast(passed ? 'Частина часу вже минула: ті нагадування сьогодні не спрацюють' : 'Збережено');
    },
    del: h && { text: 'Видалити звичку «' + h.name + '»? Серія пропаде.', fn: () => { S.habits = S.habits.filter(x => x.id !== h.id); save(); render(); toast('Видалено'); } }
  });
  const ty = $('select[name=type]', el), c = $('#hcnt', el), sync = () => { c.hidden = ty.value !== 'count'; };
  ty.addEventListener('change', sync); sync();
}

/* ---- Календар ---- */
const WD = ['пн', 'вт', 'ср', 'чт', 'пт', 'сб', 'нд'];
function dayInfo(k) {
  return { work: S.work.filter(w => w.date === k), tasks: S.tasks.filter(t => t.date === k), hd: S.habits.filter(h => hDone(h, k)).length,
    spent: S.tx.filter(t => t.date === k && t.type === 'out').reduce((a, t) => a + t.amt, 0), kg: (S.weight.find(x => x.date === k) || {}).kg };
}
views.cal = () => {
  const now = new Date(), base = new Date(now.getFullYear(), now.getMonth() + ui.calOff, 1);
  const y = base.getFullYear(), m = base.getMonth(), first = (base.getDay() + 6) % 7, dim = new Date(y, m + 1, 0).getDate(), t0 = today();
  let wDays = 0, hSum = 0, hN = 0, cells = '';
  for (let i = 0; i < first; i++) cells += '<div></div>';
  for (let d = 1; d <= dim; d++) {
    const k = y + '-' + p2(m + 1) + '-' + p2(d), inf = dayInfo(k), nh = S.habits.length;
    const dots = (inf.work.length ? '<u class="dw"></u>' : '') + (nh && inf.hd ? `<u class="${inf.hd === nh ? 'dh' : 'dp'}"></u>` : '') + (inf.tasks.some(t => t.done) ? '<u class="dt"></u>' : '');
    if (inf.work.length) wDays++;
    if (nh && k <= t0) { hN++; hSum += inf.hd / nh; }
    cells += `<button class="cd ${k === t0 ? 'today' : ''}" data-act="calDay" data-d="${k}"><span>${d}</span><div class="dots2">${dots}</div></button>`;
  }
  const title = cap(base.toLocaleDateString('uk-UA', { month: 'long', year: 'numeric' }));
  return `<div class="row between mb"><button class="icon-btn" data-act="calNav" data-n="-1" aria-label="Попередній місяць">${ICON('back', 24)}</button><h3>${esc(title)}</h3><button class="icon-btn" data-act="calNav" data-n="1" aria-label="Наступний місяць">${ICON('chevron', 24)}</button></div>
  <div class="card"><div class="cal">${WD.map(x => `<small>${x}</small>`).join('')}${cells}</div>
    <div class="row wrap gap" style="margin-top:12px"><span class="sub"><u class="dw"></u> тренування</span><span class="sub"><u class="dh"></u> усі звички</span><span class="sub"><u class="dp"></u> частково</span><span class="sub"><u class="dt"></u> завдання</span></div></div>
  <div class="grid2"><div class="card tile c3" style="cursor:default"><div class="l">${ICON('dumbbell', 16)} Днів із тренуванням</div><div class="v">${wDays}</div></div>
    <div class="card tile c1" style="cursor:default"><div class="l">${ICON('flame', 16)} Звички за місяць</div><div class="v">${hN ? Math.round(hSum / hN * 100) + '%' : '—'}</div></div></div>`;
};
function calSheet(k) {
  const inf = dayInfo(k), sec = (t, h) => (h ? `<div class="dgroup">${t}</div>${h}` : '');
  const work = inf.work.map(w => `<div class="row between" style="margin-bottom:6px;gap:10px"><span>${esc(w.ex)}</span><b style="white-space:nowrap">${w.sets} × ${w.reps}${w.weight ? ' · ' + w.weight + ' кг' : ''}</b></div>`).join('');
  const hab = S.habits.map(h => `<div class="row between" style="margin-bottom:6px"><span>${esc(h.name)}</span><b class="${hDone(h, k) ? 'grn' : 'muted'}">${h.type === 'count' ? hVal(h, k) + '/' + h.goal + ' ' + esc(h.unit) : (hDone(h, k) ? 'Так' : 'Ні')}</b></div>`).join('');
  const tsk = inf.tasks.map(t => `<div class="row between" style="margin-bottom:6px;gap:10px"><span>${esc(t.title)}</span><span class="pill ${t.done ? 'grn' : 'red'}">${t.done ? 'Виконано' : 'Не виконано'}</span></div>`).join('');
  const html = sec('Тренування', work) + sec('Звички', hab) + sec('Завдання', tsk) + sec('Вага', inf.kg ? `<b>${fmtKg(inf.kg)}</b>` : '') + sec('Витрати', inf.spent ? `<b>${money(inf.spent)}</b>` : '');
  openSheet(k === today() ? 'Сьогодні' : fmtDate(k), html || '<div class="empty">Цього дня записів немає</div>');
}

/* ---- Вага тіла ---- */
const wSorted = () => S.weight.slice().sort((a, b) => a.date.localeCompare(b.date));
const fmtKg = n => (Math.round(n * 10) / 10).toLocaleString('uk-UA') + ' кг';
function wChart(ws) {
  if (ws.length < 2) return '<div class="sub" style="padding:8px 0">Додай ще одне вимірювання, і з’явиться графік.</div>';
  const W = 300, H = 150, L = 34, R = 10, T = 14, B = 22, vals = ws.map(x => x.kg).concat(S.wGoal > 0 ? [S.wGoal] : []);
  let mn = Math.min(...vals), mx = Math.max(...vals); const lo = mn, hi = mx;
  if (mx - mn < 1) { mn -= .5; mx += .5; } const pad = (mx - mn) * .15; mn -= pad; mx += pad;
  const ms = d => new Date(d + 'T00:00:00').getTime(), t0 = ms(ws[0].date), span = Math.max(1, ms(ws[ws.length - 1].date) - t0);
  const X = d => L + (ms(d) - t0) / span * (W - L - R), Y = v => T + (1 - (v - mn) / (mx - mn)) * (H - T - B);
  const pts = ws.map(x => X(x.date).toFixed(1) + ',' + Y(x.kg).toFixed(1));
  const area = `M${X(ws[0].date).toFixed(1)},${H - B} L${pts.join(' L')} L${X(ws[ws.length - 1].date).toFixed(1)},${H - B} Z`;
  const goal = S.wGoal > 0 ? `<line x1="${L}" x2="${W - R}" y1="${Y(S.wGoal).toFixed(1)}" y2="${Y(S.wGoal).toFixed(1)}" stroke="#a3e635" stroke-dasharray="4 4" stroke-width="1.5"/>` : '';
  const tx = (x, y, t, a = 'end') => `<text x="${x}" y="${y}" text-anchor="${a}" fill="#9a92b8" font-size="9">${t}</text>`;
  return `<svg class="chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Графік ваги"><defs><linearGradient id="wg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:var(--vio);stop-opacity:.45"/><stop offset="1" style="stop-color:var(--vio);stop-opacity:0"/></linearGradient></defs>
    <path d="${area}" fill="url(#wg)"/>${goal}<polyline points="${pts.join(' ')}" fill="none" style="stroke:var(--vio2)" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"/>
    ${ws.map(x => `<circle cx="${X(x.date).toFixed(1)}" cy="${Y(x.kg).toFixed(1)}" r="3.5" style="fill:var(--vio2)"/>`).join('')}
    ${tx(L - 5, Y(hi) + 3, Math.round(hi * 10) / 10)}${tx(L - 5, Y(lo) + 3, Math.round(lo * 10) / 10)}${tx(L, H - 6, fmtShort(ws[0].date), 'start')}${tx(W - R, H - 6, fmtShort(ws[ws.length - 1].date))}</svg>`;
}
views.body = () => {
  const ws = wSorted(), last = ws[ws.length - 1];
  const d30 = iso(addDays(-30)), base = ws.filter(x => x.date <= d30).pop() || ws[0];
  const diff = last && base && base !== last ? last.kg - base.kg : null;
  const dtxt = diff === null ? '—' : (diff > 0 ? '+' : diff < 0 ? '−' : '') + fmtKg(Math.abs(diff));
  const left = last && S.wGoal > 0 ? last.kg - S.wGoal : null;
  const hist = ws.slice().reverse().slice(0, 100).map((x, i, a) => {
    const prev = a[i + 1], dd = prev ? x.kg - prev.kg : 0;
    return `<div class="item" data-act="editWeight" data-id="${x.id}"><div class="badge lime">${ICON('scale', 20)}</div><div class="grow"><b>${fmtKg(x.kg)}</b><div class="sub">${fmtDate(x.date)}</div></div>${prev && dd ? `<span class="pill ${dd > 0 ? 'red' : 'grn'}">${dd > 0 ? '+' : '−'}${(Math.round(Math.abs(dd) * 10) / 10).toLocaleString('uk-UA')}</span>` : ''}</div>`;
  }).join('');
  return `<div class="grid2 mb"><div class="card tile c3" style="cursor:default"><div class="l">${ICON('scale', 16)} Зараз</div><div class="v">${last ? fmtKg(last.kg) : '—'}</div></div>
    <div class="card tile c1" style="cursor:default"><div class="l">${ICON('calendar', 16)} За 30 днів</div><div class="v">${dtxt}</div></div></div>
  <button class="btn primary block mb" data-act="addWeight">${ICON('plus', 20)} Записати вагу</button>
  <div class="card"><div class="row between mb"><h3>Динаміка</h3><button class="btn sm" data-act="weightGoal">${ICON('target', 16)} ${S.wGoal > 0 ? 'Ціль ' + fmtKg(S.wGoal) : 'Задати ціль'}</button></div>${wChart(ws.slice(-30))}
    ${left !== null ? `<div class="sub" style="margin-top:8px">${Math.abs(left) < .05 ? 'Ціль досягнуто!' : (left > 0 ? 'До цілі ще скинути ' : 'До цілі ще набрати ') + fmtKg(Math.abs(left))}</div>` : ''}</div>
  <h2>Історія</h2>${hist || empty('scale', 'Вимірювань ще немає. Запиши першу вагу!')}`;
};
function weightSheet(id) {
  const w = id ? S.weight.find(x => x.id === id) : null, ws = wSorted(), lastKg = ws.length ? ws[ws.length - 1].kg : '';
  openForm({
    title: w ? 'Редагувати вагу' : 'Нове вимірювання',
    body: fld('Вага, кг', `<input name="kg" inputmode="decimal" required placeholder="0" value="${w ? w.kg : lastKg}">`) + fld('Дата', `<input type="date" name="date" required value="${w ? w.date : today()}">`),
    onSubmit: fd => {
      const kg = parseNum(fd.kg);
      if (!(kg >= 20 && kg <= 400)) { toast('Введи вагу від 20 до 400 кг'); return false; }
      const date = fd.date || today(), same = S.weight.find(x => x.date === date && (!w || x.id !== w.id));
      if (w) { w.kg = kg; w.date = date; if (same) S.weight = S.weight.filter(x => x !== same); }
      else if (same) same.kg = kg; else S.weight.push({ id: uid(), date, kg });
      save(); render(); toast('Збережено');
    },
    del: w && { text: 'Видалити це вимірювання?', fn: () => { S.weight = S.weight.filter(x => x.id !== w.id); save(); render(); toast('Видалено'); } }
  });
}
function goalWeightSheet() {
  openForm({
    title: 'Цільова вага', body: fld('Бажана вага, кг (порожньо: без цілі)', `<input name="g" inputmode="decimal" placeholder="Наприклад, 75" value="${S.wGoal || ''}">`),
    onSubmit: fd => { const g = fd.g.trim() === '' ? 0 : parseNum(fd.g); if (!(g === 0 || (g >= 20 && g <= 400))) { toast('Введи число від 20 до 400'); return false; } S.wGoal = g; save(); render(); toast('Збережено'); }
  });
}

/* ---- Ще ---- */
views.more = () => {
  const link = (t, ic, title, sub) => `<div class="item" data-act="go" data-t="${t}"><div class="badge">${ICON(ic, 22)}</div><div class="grow"><b>${title}</b><div class="sub">${sub}</div></div>${ICON('chevron', 20)}</div>`;
  return link('cal', 'calendar', 'Календар', 'Тренування, звички й завдання за місяць')
    + link('body', 'scale', 'Вага тіла', S.weight.length ? 'Зараз ' + fmtKg(wSorted().pop().kg) : 'Графік і ціль')
    + link('habits', 'flame', 'Звички', S.habits.length ? `Сьогодні: ${hDoneToday()} з ${S.habits.length}` : 'Вода, сон, серії днів')
    + link('tasks', 'checksq', 'Завдання', `На сьогодні: ${S.tasks.filter(t => !t.done && t.date === today()).length}`)
    + link('settings', 'sliders', 'Налаштування', 'Ім’я, нагадування, резервна копія');
};

/* ---- Налаштування ---- */
let installEvt = null;
views.settings = () => {
  const lb = S.lastBackup ? new Date(S.lastBackup).toLocaleString('uk-UA') : 'ще не робилась';
  const ns = notifState();
  const nTxt = ns === 'granted' ? 'Сповіщення дозволені.' : ns === 'denied' ? 'Сповіщення заблоковані. Дозволь їх для цього сайту в налаштуваннях Chrome.' : ns === 'unsupported' ? 'На цьому пристрої сповіщення недоступні.' : 'Сповіщення ще не дозволені.';
  return `<form id="setf" class="card">
    ${fld('Твоє ім’я', `<input name="name" maxlength="30" value="${esc(S.name)}" placeholder="Як до тебе звертатись?">`)}
    ${fld('Валюта', `<select name="cur">${opts(['₴', '$', '€'], S.cur)}</select>`)}
    <div class="sub mb" style="font-weight:700">Цілі на день</div>
    <div class="grid2">${fld('Завдань', `<input name="d_tasks" type="number" inputmode="numeric" min="0" max="99" value="${S.daily.tasks}">`)}${fld('Записів тренувань', `<input name="d_work" type="number" inputmode="numeric" min="0" max="99" value="${S.daily.workout}">`)}</div>
    <button class="btn primary block" type="submit">Зберегти</button></form>
  <h2>Тема кольору</h2>
  <div class="card"><div class="row" style="justify-content:space-around">${Object.entries(THEMES).map(([k, [n, c1, c2]]) => `<button class="swb" data-act="setTheme" data-v="${k}" aria-label="${n}" aria-pressed="${S.theme === k}"><span class="sw ${S.theme === k ? 'on' : ''}" style="background:linear-gradient(135deg,${c1},${c2})"></span>${n}</button>`).join('')}</div></div>
  <h2>Нагадування</h2>
  <div class="card"><div class="sub mb">${nTxt} Нагадування перевіряються, поки Зюзя відкрита або працює у фоні. Браузерна версія не може гарантувати точні сповіщення після примусового закриття чи зупинки Android; для цього потрібен нативний Android-модуль або серверні push-сповіщення.</div>
    <div class="grid2"><button class="btn green" data-act="askNotif">${ICON('bell', 20)} Дозволити</button><button class="btn" data-act="testNotif">Перевірити</button></div></div>
  <h2>Резервна копія</h2>
  <div class="card"><div class="sub mb">Остання копія: ${lb}. Файл можна зберегти в «Завантаження» або надіслати собі, щоб відновити дані на новому телефоні.</div>
    <div class="grid2"><button class="btn green" data-act="export">${ICON('download', 20)} Зберегти</button><button class="btn" data-act="import">${ICON('upload', 20)} Відновити</button></div>
    ${navigator.share ? `<button class="btn block" style="margin-top:10px" data-act="shareBackup">${ICON('share', 20)} Поділитися копією</button>` : ''}</div>
  <h2>Застосунок</h2>
  <div class="card">${installEvt ? `<button class="btn primary block mb" data-act="install">Встановити на екран</button>` : `<div class="sub mb">Щоб встановити: у Chrome натисни ⋮ → «Встановити застосунок» або «Додати на головний екран».</div>`}
    <div class="sub">Усі дані зберігаються лише на цьому пристрої. Реєстрація не потрібна. Версія 4.1</div>
    <button class="btn danger block" style="margin-top:12px" data-act="reset">Видалити всі дані</button></div>`;
};
function backupObj() { return { app: 'zyuzya', version: 1, exported: new Date().toISOString(), data: S }; }
function backupFile() {
  const name = `zyuzya-backup-${today()}.json`;
  return new File([JSON.stringify(backupObj(), null, 2)], name, { type: 'application/json' });
}
function exportBackup() {
  try {
    const f = backupFile(), url = URL.createObjectURL(f), a = document.createElement('a');
    a.href = url; a.download = f.name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
    S.lastBackup = Date.now(); save(); render(); toast('Копію збережено: ' + f.name);
  } catch (e) { toast('Не вдалося створити копію'); }
}
async function shareBackup() {
  try {
    const f = backupFile();
    if (navigator.canShare && navigator.canShare({ files: [f] })) { await navigator.share({ files: [f], title: 'Копія Зюзя' }); S.lastBackup = Date.now(); save(); render(); }
    else exportBackup();
  } catch (e) { if (e && e.name !== 'AbortError') toast('Не вдалося поділитися'); }
}
function importBackup(file) {
  const r = new FileReader();
  r.onload = () => {
    try {
      const o = JSON.parse(r.result);
      if (!o || o.app !== 'zyuzya' || !o.data || typeof o.data !== 'object') throw new Error('bad');
      confirmBox('Замінити всі поточні дані даними з копії?', () => { S = migrate(o.data); applyTheme(); save(); render(); toast('Дані відновлено'); }, 'Так, відновити');
    } catch (e) { toast('Це не файл копії «Зюзя»'); }
  };
  r.onerror = () => toast('Не вдалося прочитати файл');
  r.readAsText(file);
}

/* ================= Рендер і навігація ================= */
function render() {
  const v = $('#view'), y = window.scrollY;
  v.className = ui.anim ? 'anim' : '';
  v.innerHTML = views[ui.tab]();
  if (ui.anim) { window.scrollTo(0, 0); ui.anim = false; } else window.scrollTo(0, y);
  $('#ttl').textContent = TITLES[ui.tab];
  const nv = navOf(ui.tab);
  $('#nav').innerHTML = NAV.map(([t, ic, l]) => `<button class="${t === nv ? 'on' : ''}" data-act="go" data-t="${t}" aria-label="${l}" ${t === nv ? 'aria-current="page"' : ''}>${ICON(ic, 24)}<span>${l}</span></button>`).join('');
  if (ui.refocus) { ui.refocus = false; const i = $('#qa input'); if (i) i.focus(); }
}
function go(t) {
  if (t === ui.tab) return;
  ui.tab = t; ui.anim = true; if (t === 'cal') ui.calOff = 0;
  history.pushState({ tab: t, sheet: 0 }, ''); render();
}
window.addEventListener('popstate', e => {
  const target = (e.state && e.state.sheet) || 0;
  if (stack.length > target) { while (stack.length > target) removeTop(); return; }
  const t = (e.state && e.state.tab) || 'home';
  if (t !== ui.tab) { ui.tab = t; ui.anim = true; render(); }
});

/* ================= События ================= */
const actions = {
  go: d => go(d.t),
  noop: () => {},
  closeTop,
  chip: d => { ui.f[d.g] = d.v; render(); },
  addTx: d => txSheet(d.type), editTx: d => txSheet(null, d.id),
  addGoal: () => goalSheet(), editGoal: d => goalSheet(d.id), goalMoney: d => goalMoneySheet(d.id),
  addWork: () => workSheet(), editWork: d => workSheet(d.id),
  addTask: () => taskSheet(), editTask: d => taskSheet(d.id),
  toggleTask: d => { const t = S.tasks.find(x => x.id === d.id); if (!t || t.done) return; t.done = true; t.doneAt = today(); save(); render(); toast('Завдання виконано'); },
  setTheme: d => { if (!THEMES[d.v]) return; S.theme = d.v; applyTheme(); save(); render(); },
  tplList, tplStart: d => tplStart(d.id), tplNew: () => tplBuilder(), tplEdit: d => tplBuilder(d.id),
  tplCopy: d => { const t = TPL_BUILTIN.find(x => x.id === d.id); if (t) tplBuilder(null, { name: t.name + ' (мій)', items: t.items }); },
  calDay: d => calSheet(d.d), calNav: d => { ui.calOff += +d.n; render(); },
  addWeight: () => weightSheet(), editWeight: d => weightSheet(d.id), weightGoal: goalWeightSheet,
  addHab: () => habSheet(), editHab: d => habSheet(d.id),
  habPreset: d => { const p = HAB_PRESETS[d.v]; if (!p) return; S.habits.push({ id: uid(), name: p[0], type: p[1], goal: p[2], unit: p[3], log: {} }); save(); render(); toast('Звичку додано'); },
  habToggle: d => { const h = S.habits.find(x => x.id === d.id); if (!h || hDone(h, d.d)) return; h.log[d.d] = h.goal; save(); render(); if (d.close) closeTop(); toast('Звичку виконано'); },
  habInc: d => { const h = S.habits.find(x => x.id === d.id); if (!h || h.type !== 'count') return; const k = today(), current = Math.min(h.goal, hVal(h, k)); if (current >= h.goal) { toast('Норму вже виконано'); return; } const v = Math.min(h.goal, current + 1); h.log[k] = v; save(); render(); if (v >= h.goal) toast('Норму виконано!'); else toast('Додано 1 ' + (h.unit || 'од.')); if (d.close) closeTop(); },
  moveToday: d => { const t = S.tasks.find(x => x.id === d.id); if (!t) return; t.date = today(); t.done = false; t.doneAt = ''; if (t.time) setReminder(t, t.time); save(); render(); toast('Перенесено на сьогодні'); },
  clearHist: () => confirmBox('Видалити всю історію завдань?', () => { S.tasks = S.tasks.filter(t => t.date >= today()); save(); render(); toast('Історію очищено'); }),
  remDone: d => { const t = S.tasks.find(x => x.id === d.id); if (t) { t.done = true; t.doneAt = today(); save(); } closeTop(); render(); },
  askNotif: () => {
    const st = notifState();
    if (st === 'unsupported') toast('Сповіщення недоступні на цьому пристрої');
    else if (st === 'denied') toast('Заблоковано: Chrome → ⋮ → Налаштування сайту → Сповіщення');
    else if (st === 'granted') toast('Сповіщення вже дозволені');
    else ensureNotifPerm();
  },
  testNotif: () => {
    if (notifState() !== 'granted') { toast('Спочатку дозволь сповіщення'); return; }
    toast('Згорни застосунок: за 5 секунд прийде сповіщення');
    setTimeout(() => sysNotify({ id: 'test', time: hhmm(), title: 'Тестове нагадування. Усе працює!' }), 5000);
  },
  export: exportBackup, shareBackup,
  import: () => { const i = $('#imp'); i.value = ''; i.click(); },
  reset: () => confirmBox('Видалити ВСІ дані назавжди? Спершу зроби резервну копію.', () => { S = defaults(); S.welcomed = true; applyTheme(); save(); ui.tab = 'home'; ui.anim = true; render(); toast('Дані видалено'); }, 'Так, видалити все'),
  install: async () => { if (!installEvt) return; installEvt.prompt(); try { await installEvt.userChoice; } catch (e) {} installEvt = null; render(); }
};
const chg = { exSel: v => { ui.exSel = v; render(); } };
const refreshList = () => { const l = $('#list'); if (!l) return; const fn = lists[ui.tab]; if (fn) l.innerHTML = fn(); };

document.addEventListener('click', e => {
  const el = e.target.closest('[data-act]'); if (!el) return;
  const fn = actions[el.dataset.act]; if (fn) fn(el.dataset, el);
});
document.addEventListener('input', e => {
  const q = e.target.dataset && e.target.dataset.q;
  if (q) { ui.q[q] = e.target.value; refreshList(); }
});
document.addEventListener('change', e => {
  const c = e.target.dataset && e.target.dataset.chg; if (c && chg[c]) chg[c](e.target.value);
});
document.addEventListener('submit', e => {
  const f = e.target;
  if (f.id === 'qa') {
    e.preventDefault(); const v = f.elements.t.value.trim();
    if (!v) { toast('Введи назву завдання'); return; }
    const n = { id: uid(), ts: Date.now(), title: v, date: today(), time: '', prio: 1, done: false, notified: false };
    const passed = setReminder(n, f.elements.tm.value); S.tasks.push(n);
    ui.refocus = true; ui.f.task = 'today'; save(); render();
    if (passed) toast('Цей час уже минув, нагадування не спрацює');
  } else if (f.id === 'setf') {
    e.preventDefault(); const fd = Object.fromEntries(new FormData(f)), n = k => Math.max(0, parseInt(fd[k], 10) || 0);
    S.name = fd.name.trim(); S.cur = fd.cur; S.daily = { tasks: n('d_tasks'), workout: n('d_work') };
    save(); render(); toast('Налаштування збережено');
  }
});
$('#imp').addEventListener('change', e => { const f = e.target.files && e.target.files[0]; if (f) importBackup(f); });
window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); installEvt = e; if (ui.tab === 'settings' && !stack.length) render(); });
window.addEventListener('appinstalled', () => { installEvt = null; toast('Застосунок встановлено'); });
$('#gear').innerHTML = ICON('sliders', 22);

/* ================= Запуск ================= */
function welcome() {
  const el = openForm({
    title: 'Ласкаво просимо до «Зюзя»', submit: 'Почати',
    body: `<p class="sub" style="margin:0 0 14px">Усе зберігається лише на твоєму телефоні. Реєстрація не потрібна. Як до тебе звертатись?</p>${fld('Ім’я', `<input name="name" maxlength="30" placeholder="Наприклад, Віталій">`)}`,
    onSubmit: fd => { S.name = (fd.name || '').trim(); S.welcomed = true; save(); render(); }
  });
  // закриття без збереження теж запам’ятовуємо
  el.addEventListener('click', e => { if (e.target === el) { S.welcomed = true; save(); } });
}
history.replaceState({ tab: 'home', sheet: 0 }, '');
render();
if (!S.welcomed) setTimeout(() => { S.welcomed = true; save(); welcome(); }, 350);
setInterval(dayTick, 15000);
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') dayTick(); });
window.addEventListener('focus', dayTick);
setTimeout(dayTick, 900);
if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(() => {});
if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) navigator.serviceWorker.register('sw.js').catch(() => {});
})();
