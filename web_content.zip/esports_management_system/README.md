# GG Arena — Esports Management System

**Diploma Semester 5 Mini Project**  
**Technology:** HTML, CSS and JavaScript  
**Project type:** Front-end web application using browser local storage

## 1. Project overview

GG Arena is a beginner-friendly esports tournament management website. It provides one dashboard to manage tournaments, teams, players, match fixtures and team rankings. The design uses a dark gaming theme with neon purple, cyan and green accents, plus a custom cyber-gaming background image.

This version runs entirely in a web browser. It does not need a server or database installation. Data created through the forms is stored in the browser's `localStorage`.

## 2. Modules

1. **Dashboard** — summary cards and upcoming tournaments (recent activity removed).
2. **Tournament management** — create, edit, delete, search and filter tournaments.
3. **Team and player management** — register teams, choose a game, set player count and record wins.
4. **Match management** — schedule matches, edit fixtures, record scores and delete matches.
5. **Leaderboard** — rank teams by wins and calculate demo points (wins × 100).

## 3. Software requirements

- Windows, macOS or Linux computer
- Modern browser (Google Chrome, Microsoft Edge or Firefox)
- A text editor such as Visual Studio Code (optional)

No internet connection, framework, package installation or database server is required after the files are available.

## 4. How to run the project

1. Extract `esports_management_system.zip` to a folder.
2. Open the extracted `esports_management_system` folder.
3. Double-click `index.html`, or right-click it and select **Open with** your browser.
4. Use the left navigation to visit each module.
5. Use **Create tournament**, **Register team** and **Add match** to test the forms.
6. Record a match result to see scores and the leaderboard update.
7. Refresh the page; data should remain saved in the same browser.

**Recommended:** Open the folder in Visual Studio Code and use the Live Server extension if you already have it installed. Live Server is optional.

## 5. Project folder structure

```text
esports_management_system/
├── index.html     # Page structure and forms
├── style.css      # Dark theme, layout and responsive styling
├── script.js      # Sample data, app logic, CRUD and localStorage
├── assets/
│   └── gaming-background.png  # Neon esports background image
└── README.md      # Setup instructions and documentation
```

## 6. How the project works

- `index.html` creates the navigation, dashboard, data tables, tournament cards and modal forms.
- `style.css` styles the interface and adapts the layout to smaller screens.
- `script.js` renders the sample data, validates forms, handles add/edit/delete actions and refreshes the page sections.
- Browser `localStorage` stores teams, tournaments and matches as JSON strings.

### Data objects (simplified)

- **Team:** `id`, `name`, `tag`, `game`, `players`, `wins`, `status`
- **Tournament:** `id`, `name`, `game`, `date`, `prize`, `teams`, `status`
- **Match:** `id`, `team1`, `team2`, `game`, `date`, `score1`, `score2`, `status`

## 7. Testing checklist

- [ ] Dashboard loads without errors.
- [ ] Add a team and confirm it appears in the team list.
- [ ] Search for a team by name or game.
- [ ] Add a tournament and test the status filter.
- [ ] Add a match and record a result.
- [ ] Confirm completed match scores appear in the match list.
- [ ] Confirm the leaderboard updates after a winning result.
- [ ] Refresh the browser and confirm saved data remains.
- [ ] Test the menu on a narrow/mobile screen.

## 8. Current limitations

- This is a **front-end educational prototype**, not a production tournament platform.
- Data is saved only in the current browser profile; it is not shared between devices.
- There is no real login, online database, payment system, live game API or real-time multiplayer functionality.
- Dashboard activity and some overview values are sample/demo content.
- Match result submission increments the winning team's wins. Editing a previously completed match does not reverse or recalculate earlier wins automatically.
- Since there is no backend, this app should not be used for sensitive or official data.

## 9. Future scope

- Add a backend using PHP/Node.js and a MySQL database.
- Add admin and player login with secure authentication.
- Support team rosters and individual player profiles.
- Add bracket generation and automatic fixture scheduling.
- Add tournament registrations, notifications and downloadable reports.
- Add APIs for live scores and match statistics.

## 10. Viva questions with short answers

**Q1. What is an Esports Management System?**  
It is an application to organize esports teams, tournaments, matches and rankings.

**Q2. Which technologies are used?**  
HTML for structure, CSS for design and JavaScript for application logic.

**Q3. What is localStorage?**  
It is browser storage that keeps key-value data after a page refresh.

**Q4. Is this project connected to a database?**  
No. This version uses localStorage. A backend and database can be added in a future version.

**Q5. What is CRUD?**  
Create, Read, Update and Delete — the basic operations used to manage records.

**Q6. What is the purpose of the leaderboard?**  
It sorts registered teams by their recorded tournament wins and shows demo points.

**Q7. What are the main modules?**  
Dashboard, tournament management, teams and players, matches and leaderboard.

**Q8. What can be improved in future?**  
A secure login system, server-side database, player profiles, automated brackets and live score integration.

## 11. Conclusion

The GG Arena mini project demonstrates how HTML, CSS and JavaScript can be used to build a responsive esports management interface. It introduces basic data management, search and filtering, form validation, browser storage and dynamic rendering. It is suitable as a starting point for a Diploma Semester 5 mini project and can be extended with a backend database in future.

## Tournament scoring rules
- Added a **Rules & Points** page in the sidebar.
- Each tournament can configure elimination points per kill, first-place/position points, and a win bonus when creating or editing it.
- Tournament cards display the configured scoring values.
- Example default values are 1 point per elimination, 12 position points for first place, and 5 bonus points for a win. These are sample settings and can be edited per tournament.
