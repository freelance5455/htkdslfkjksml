const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

const seedTeams = [
  {id:1,name:"Cyber Wolves",tag:"CW",game:"Valorant",players:5,playerNames:["Aarav Patel","Rohan Shah","Dev Mehta","Jay Joshi","Kunal Desai"],wins:12,status:"Active"},
  {id:2,name:"Alpha Squad",tag:"AS",game:"BGMI",players:4,playerNames:["Dhruv Shah","Aman Patel","Yash Trivedi","Ravi Parmar"],wins:9,status:"Active"},
  {id:3,name:"Team Phoenix",tag:"TP",game:"Valorant",players:5,playerNames:["Krish Patel","Nirav Shah","Parth Dave","Mihir Joshi","Om Shah"],wins:8,status:"Active"},
  {id:4,name:"Neon Ninjas",tag:"NN",game:"Free Fire",players:4,playerNames:["Vivek Solanki","Harsh Patel","Manav Shah","Sahil Rana"],wins:7,status:"Active"},
  {id:5,name:"Shadow Reapers",tag:"SR",game:"BGMI",players:4,wins:6,status:"Active"},
  {id:6,name:"Pixel Raiders",tag:"PR",game:"Free Fire",players:4,wins:5,status:"Active"},
  {id:7,name:"Storm Breakers",tag:"SB",game:"Valorant",players:5,wins:4,status:"Active"},
  {id:8,name:"Frostbyte",tag:"FB",game:"BGMI",players:4,wins:3,status:"Active"}
];
const seedTournaments = [
  {id:1,name:"Neon Clash Championship",game:"Valorant",date:"2026-11-02",prize:"₹10,000",teams:16,status:"Registration Open",icon:"⚡",cover:"",eliminationPoints:1,positionPoints:12,winPoints:5},
  {id:2,name:"Battle Royale Cup",game:"BGMI",date:"2026-11-08",prize:"₹7,500",teams:24,status:"Upcoming",icon:"🎯",cover:"cover-orange",eliminationPoints:1,positionPoints:12,winPoints:5},
  {id:3,name:"Free Fire Friday",game:"Free Fire",date:"2026-11-14",prize:"₹5,000",teams:12,status:"Registration Open",icon:"🔥",cover:"cover-cyan",eliminationPoints:1,positionPoints:12,winPoints:5},
  {id:4,name:"Winter Showdown",game:"Valorant",date:"2026-10-01",prize:"₹15,000",teams:16,status:"Completed",icon:"❄",cover:"cover-blue",eliminationPoints:1,positionPoints:12,winPoints:5}
];
const seedMatches = [
  {id:1,team1:"Cyber Wolves",team2:"Alpha Squad",game:"Valorant",date:"2026-10-20",score1:2,score2:1,status:"Completed"},
  {id:2,team1:"Team Phoenix",team2:"Neon Ninjas",game:"Valorant",date:"2026-10-22",score1:null,score2:null,status:"Scheduled"},
  {id:3,team1:"Shadow Reapers",team2:"Frostbyte",game:"BGMI",date:"2026-10-24",score1:null,score2:null,status:"Scheduled"},
  {id:4,team1:"Alpha Squad",team2:"Pixel Raiders",game:"BGMI",date:"2026-10-15",score1:3,score2:2,status:"Completed"}
];
function loadData(key, fallback) {
  try { const saved = localStorage.getItem(key); return saved ? JSON.parse(saved) : fallback; }
  catch (error) { return fallback; }
}
let teams = loadData("ggArenaTeams", seedTeams);
let tournaments = loadData("ggArenaTournaments", seedTournaments);
let matches = loadData("ggArenaMatches", seedMatches);
let tournamentJoins = loadData("ggArenaTournamentJoins", {});
let leaderboardGame = "All Games";
let nextId = Math.max(0, ...teams.map(x=>x.id), ...tournaments.map(x=>x.id), ...matches.map(x=>x.id)) + 1;
let modalType = "";
let toastTimer;

function saveData() {
  localStorage.setItem("ggArenaTeams", JSON.stringify(teams));
  localStorage.setItem("ggArenaTournaments", JSON.stringify(tournaments));
  localStorage.setItem("ggArenaMatches", JSON.stringify(matches));
  localStorage.setItem("ggArenaTournamentJoins", JSON.stringify(tournamentJoins));
}
function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function niceDate(date) {
  if (!date) return "TBD";
  const d = new Date(date + "T00:00:00");
  return Number.isNaN(d.getTime()) ? esc(date) : d.toLocaleDateString("en-IN",{day:"numeric",month:"short",year:"numeric"});
}
function statusClass(status) {
  if (status === "Registration Open" || status === "Active") return "open";
  if (status === "Completed") return "completed";
  return "upcoming";
}
function showToast(message) {
  const toast = $("#toast");
  toast.textContent = message; toast.classList.add("show");
  clearTimeout(toastTimer); toastTimer = setTimeout(()=>toast.classList.remove("show"), 2600);
}
function navigate(page) {
  $$(".page").forEach(p=>p.classList.remove("active"));
  const target = document.getElementById(page+"Page");
  if (target) target.classList.add("active");
  $$(".nav-link").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
  $("#pageCrumb").textContent = page.charAt(0).toUpperCase()+page.slice(1);
  $("#sidebar").classList.remove("open");
  window.scrollTo({top:0,behavior:"smooth"});
}
$$(".nav-link").forEach(btn=>btn.addEventListener("click",()=>navigate(btn.dataset.page)));
$$("[data-goto]").forEach(btn=>btn.addEventListener("click",()=>navigate(btn.dataset.goto)));
$("#menuBtn").addEventListener("click",()=>$("#sidebar").classList.toggle("open"));

function renderStats() {
  $("#statTeams").textContent = String(teams.length).padStart(2,"0");
  $("#statTournaments").textContent = String(tournaments.length).padStart(2,"0");
  $("#statMatches").textContent = String(matches.filter(m=>m.status==="Completed").length + 12).padStart(2,"0");
  $("#statPlayers").textContent = String(teams.reduce((sum,t)=>sum+Number(t.players||0),0));
  $("#teamCount").textContent = `${teams.length} REGISTERED TEAMS`;
}
function renderUpcoming() {
  const items = [...tournaments].filter(t=>t.status!=="Completed").sort((a,b)=>a.date.localeCompare(b.date)).slice(0,3);
  $("#upcomingList").innerHTML = items.length ? items.map(t=>`
    <div class="upcoming-item"><div class="game-badge">${esc(t.icon||"🏆")}</div><div class="upcoming-info"><b>${esc(t.name)}</b><small>${esc(t.game)} · ${niceDate(t.date)}</small></div><span class="status ${statusClass(t.status)}">${esc(t.status==="Registration Open"?"Open":t.status)}</span></div>
  `).join("") : `<div class="empty-state">No upcoming tournaments yet. Create one to get started.</div>`;
}
function renderTournaments() {
  const q = $("#tournamentSearch").value.toLowerCase();
  const filter = $("#tournamentFilter").value;
  const items = tournaments.filter(t=>(t.name+" "+t.game).toLowerCase().includes(q) && (filter==="all"||t.status===filter));
  $("#tournamentGrid").innerHTML = items.length ? items.map(t=>`
    <article class="tournament-card"><div class="tournament-cover ${esc(t.cover||"")}"><span class="cover-icon">${esc(t.icon||"🏆")}</span><span class="cover-game">${esc(t.game.toUpperCase())}</span></div><div class="tournament-body"><span class="status ${statusClass(t.status)}">${esc(t.status)}</span><h3 style="margin-top:11px">${esc(t.name)}</h3><p>${esc(t.game)} tournament · Season 05</p><div class="tournament-meta"><div><small>START DATE</small><b>${niceDate(t.date)}</b></div><div><small>PRIZE POOL</small><b>${esc(t.prize||"Not set")}</b></div><div><small>TEAM SLOTS</small><b>${esc(t.teams)} teams</b></div><div><small>FORMAT</small><b>Knockout</b></div><div><small>ELIMINATION POINTS</small><b>${Number(t.eliminationPoints??1)} / kill</b></div><div><small>POSITION POINTS</small><b>${Number(t.positionPoints??12)} / placement</b></div><div><small>WIN POINTS</small><b>${Number(t.winPoints??5)} bonus</b></div></div><div class="card-footer"><button class="small-btn" data-join-tournament="${t.id}" ${t.status==="Completed"?"disabled":""}>${(tournamentJoins[t.id]||[]).length?"Join another team":"Join tournament"}</button><button class="row-action" data-edit-tournament="${t.id}">Edit</button><button class="delete-btn" data-delete-tournament="${t.id}">Delete</button></div><div class="registered-teams"><small class="join-count">REGISTERED TEAMS (${(tournamentJoins[t.id]||[]).length})</small>${(tournamentJoins[t.id]||[]).length ? (tournamentJoins[t.id]||[]).map(j=>`<div class="registered-team-row"><span class="team-logo">${esc((j.teamName||"T").slice(0,2).toUpperCase())}</span><span><b>${esc(j.teamName)}</b><small>${esc(j.game||t.game)} · Registered</small></span></div>`).join("") : `<small class="no-registered-teams">No teams registered yet.</small>`}</div></div></article>
  `).join("") : `<div class="empty-state">No tournaments found. Try another search or add a tournament.</div>`;
}
function renderTeams() {
  const q = $("#teamSearch").value.toLowerCase();
  const items = teams.filter(t=>(t.name+" "+t.game).toLowerCase().includes(q));
  $("#teamTable").innerHTML = items.map(t=>`<tr><td><div class="team-cell"><span class="team-logo">${esc(t.tag||t.name.slice(0,2).toUpperCase())}</span><span><b><button class="team-name-btn" data-view-team="${t.id}">${esc(t.name)}</button></b><small>Team ID: GG-${String(t.id).padStart(3,"0")}</small></span></div></td><td>${esc(t.game)}</td><td>${esc(t.players)} players</td><td><b>${esc(t.wins)}</b></td><td><span class="status ${statusClass(t.status)}">${esc(t.status)}</span></td><td><button class="row-action" data-view-team="${t.id}">Players</button> <button class="row-action" data-edit-team="${t.id}">Edit</button> <button class="delete-btn" data-delete-team="${t.id}">Delete</button></td></tr>`).join("") || `<tr><td colspan="6"><div class="empty-state">No teams found.</div></td></tr>`;
}
function renderMatches() {
  const q = $("#matchSearch").value.toLowerCase();
  const filter = $("#matchFilter").value;
  const items = matches.filter(m=>(m.team1+" "+m.team2+" "+m.game+" "+(m.tournamentName||"")).toLowerCase().includes(q)&&(filter==="all"||m.status===filter));
  $("#matchTable").innerHTML = items.map(m=>`<tr><td><div class="matchup"><b>${esc(m.team1)}</b><span class="versus">VS</span><b>${esc(m.team2)}</b></div><small style="color:#68738a;display:block;margin-top:5px">Match #${String(m.id).padStart(3,"0")}</small></td><td>${esc(m.game)}<small style="display:block;color:#68738a;margin-top:5px">${esc(m.tournamentName||"Friendly match")}</small></td><td>${niceDate(m.date)}${m.time?`<small style="display:block;color:#8c95aa;margin-top:4px">${esc(m.time)}</small>`:""}</td><td class="score">${m.status==="Completed"?`${esc(m.score1)} : ${esc(m.score2)}<small style="display:block;color:#8c95aa;margin-top:4px">Points: ${Number(m.points1||0)} : ${Number(m.points2||0)}</small>`:m.status==="Live"?`${esc(m.score1??0)} : ${esc(m.score2??0)}<small style="display:block;color:#65e6a5;margin-top:4px">LIVE SCORE</small>`:"— : —"}</td><td><span class="status ${statusClass(m.status)}">${esc(m.status)}</span></td><td>${m.status==="Completed"?`<button class="row-action" data-edit-match="${m.id}">Edit</button> <button class="delete-btn" data-delete-match="${m.id}">Delete</button>`:`<button class="row-action" data-result-match="${m.id}">${m.status==="Live"?"Update score":"Record score"}</button> <button class="row-action" data-edit-match="${m.id}">Edit</button> <button class="delete-btn" data-delete-match="${m.id}">Delete</button>`}</td></tr>`).join("") || `<tr><td colspan="6"><div class="empty-state">No matches found. Add a match to create a fixture.</div></td></tr>`;
}
function renderLeaderboard() {
  const games = ["All Games", ...new Set(teams.map(t=>t.game))];
  const select = $("#leaderboardGame");
  if (select) { select.innerHTML = games.map(g=>`<option ${g===leaderboardGame?"selected":""}>${esc(g)}</option>`).join(""); }
  const filtered = teams.filter(t=>leaderboardGame==="All Games"||t.game===leaderboardGame);
  const sorted = [...filtered].sort((a,b)=>Number(b.wins)-Number(a.wins));
  const podiumOrder = [sorted[1],sorted[0],sorted[2]].filter(Boolean);
  $("#podium").innerHTML = podiumOrder.map((t,i)=>{const rank = i===0?2:i===1?1:3;return `<article class="podium-card ${rank===1?"first":""}"><div class="podium-rank">${rank===1?"👑":rank===2?"🥈":"🥉"}</div><div class="podium-logo">${esc(t.tag||t.name.slice(0,2).toUpperCase())}</div><h3>${esc(t.name)}</h3><p>${esc(t.game)}</p><strong>${esc(t.wins)}</strong><small>TOURNAMENT WINS</small></article>`}).join("") || `<div class="empty-state">No teams in this game yet.</div>`;
  $("#leaderboardTable").innerHTML = sorted.map((t,i)=>`<tr><td><b style="color:${i===0?"#f4c86c":"#b9c2d5"}">#${i+1}</b></td><td><div class="team-cell"><span class="team-logo">${esc(t.tag||t.name.slice(0,2).toUpperCase())}</span><b><button class="team-name-btn" data-view-team="${t.id}">${esc(t.name)}</button></b></div></td><td>${esc(t.game)}</td><td>${esc(t.wins)}</td><td class="score">${Number(t.points??Number(t.wins)*100)}</td></tr>`).join("") || `<tr><td colspan="5">No teams registered yet.</td></tr>`;
}
function showTeamPlayers(id) {
  const team=teams.find(t=>t.id===id); if(!team)return;
  const names=team.playerNames||Array.from({length:Number(team.players)||0},(_,i)=>`Player ${i+1}`);
  modalType="teamDetails";
  $("#modalTitle").textContent=`${team.name} · Team Players`;
  $("#modalFields").innerHTML=`<div class="team-detail-summary"><span class="team-logo">${esc(team.tag||team.name.slice(0,2).toUpperCase())}</span><div><b>${esc(team.game)}</b><small>${names.length} player(s) · ${esc(team.status)}</small></div></div><div class="player-list">${names.map((n,i)=>`<div class="player-row"><span class="player-number">${i+1}</span><div><b>${esc(n)}</b><small>${i===0?"Team Captain":"Team Player"}</small></div></div>`).join("")||"No players added yet."}</div><button type="button" class="primary-btn" data-edit-team="${team.id}">Edit team / players</button>`;
  $("#modalForm").dataset.mode="teamDetails"; $("#modalForm").dataset.id=String(id);
  $("#modalForm").querySelector(".modal-actions").style.display="none";
  $("#modalBackdrop").classList.add("show"); $("#modalBackdrop").setAttribute("aria-hidden","false");
}
function renderAll() { renderStats(); renderUpcoming(); renderTournaments(); renderTeams(); renderMatches(); renderLeaderboard(); }

const gameOptions = ["Valorant","BGMI","Free Fire","Counter-Strike 2","Other"];
function field(name,label,type="text",value="",options=null,full=false,required=true) {
  const safeValue = esc(value);
  let input = "";
  if (type==="select") input = `<select name="${name}" ${required?"required":""}>${options.map(o=>`<option ${o===value?"selected":""}>${esc(o)}</option>`).join("")}</select>`;
  else input = `<input name="${name}" type="${type}" value="${safeValue}" ${required?"required":""} ${type==="number"?'min="0"':""}/>`;
  return `<div class="form-field ${full?"full":""}"><label for="field-${name}">${label}</label>${input.replace(`name="${name}"`,`name="${name}" id="field-${name}"`)}</div>`;
}
function openModal(type, id=null, extra={}) {
  modalType = type;
  const existing = id===null ? null : (type==="team"?teams:type==="tournament"?tournaments:matches).find(x=>x.id===id);
  const data = {...(existing||{}),...extra};
  const isEdit = !!existing;
  const titles = {team:isEdit?"Edit team":"Register a team",tournament:isEdit?"Edit tournament":"Create a tournament",match:isEdit?"Edit match":"Add a match",result:"Record match result"};
  $("#modalTitle").textContent = titles[type] || "Record match result";
  let html = "";
  if(type==="team") {
    html = field("name","Team name","text",data.name||"",null,true)+field("tag","Team short tag","text",data.tag||"")+field("game","Game","select",data.game||gameOptions[0],gameOptions)+field("players","Number of players","number",data.players??5)+`<div class="form-field full"><label for="field-playerNames">Player names (one per line)</label><textarea name="playerNames" id="field-playerNames" rows="5" placeholder="Player 1&#10;Player 2">${esc((data.playerNames||[]).join("\n"))}</textarea></div>`+field("wins","Tournament wins","number",data.wins??0)+field("status","Status","select",data.status||"Active",["Active","Inactive"]);
  } else if(type==="tournament") {
    html = field("name","Tournament name","text",data.name||"",null,true)+field("game","Game","select",data.game||gameOptions[0],gameOptions)+field("date","Start date","date",data.date||"2026-11-20")+field("prize","Prize pool","text",data.prize||"₹0")+field("teams","Team slots","number",data.teams??16)+field("eliminationPoints","Elimination points per kill","number",data.eliminationPoints??1)+field("positionPoints","Position points (1st place)","number",data.positionPoints??12)+field("winPoints","Win bonus points","number",data.winPoints??5)+field("status","Status","select",data.status||"Registration Open",["Registration Open","Upcoming","Completed"])+field("icon","Card icon (emoji)","text",data.icon||"🏆")+field("cover","Card colour","select",data.cover||"",["","cover-cyan","cover-orange","cover-blue"]);
  } else {
    const teamsNames = teams.map(t=>t.name);
    const teamOpts = teamsNames.length?teamsNames:["No teams registered"];
    const tournamentOpts = ["Friendly match",...tournaments.map(t=>t.name)];
    const scoreMode = type==="result" || (type==="match" && ["Completed","Live"].includes(data.status));
    html = field("team1","Team 1","select",data.team1||teamOpts[0],teamOpts)+field("team2","Team 2","select",data.team2||teamOpts[Math.min(1,teamOpts.length-1)],teamOpts)+field("game","Game","select",data.game||gameOptions[0],gameOptions)+field("tournamentName","Tournament","select",data.tournamentName||tournamentOpts[0],tournamentOpts)+field("date","Match date","date",data.date||"2026-11-20")+field("time","Match time","time",data.time||"18:00");
    if(scoreMode) html += field("score1","Team 1 score / kills","number",data.score1??0)+field("score2","Team 2 score / kills","number",data.score2??0)+field("placement1","Team 1 placement (1 = first)","number",data.placement1??1)+field("placement2","Team 2 placement (1 = first)","number",data.placement2??2);
    if(type==="match") html += field("status","Status","select",data.status||"Scheduled",["Scheduled","Live","Completed"]);
  }
  $("#modalFields").innerHTML = html;
  $("#modalForm").querySelector(".modal-actions").style.display="flex";
  $("#modalBackdrop").classList.add("show");
  $("#modalBackdrop").setAttribute("aria-hidden","false");
  $("#modalForm").dataset.id = id===null?"":String(id);
  $("#modalForm").dataset.mode = type;
}
function closeModal() { $("#modalBackdrop").classList.remove("show"); $("#modalBackdrop").setAttribute("aria-hidden","true"); }
$("#closeModal").addEventListener("click",closeModal);
$("#cancelModal").addEventListener("click",closeModal);
$("#modalBackdrop").addEventListener("click",e=>{if(e.target===$("#modalBackdrop"))closeModal();});
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeModal();});

$("#modalForm").addEventListener("submit",e=>{
  e.preventDefault();
  const form = new FormData(e.currentTarget);
  const data = Object.fromEntries(form.entries());
  const mode = e.currentTarget.dataset.mode;
  const id = e.currentTarget.dataset.id ? Number(e.currentTarget.dataset.id) : null;
  if(mode==="join") { const tid=Number(id); const t=tournaments.find(x=>x.id===tid); const team=teams.find(x=>x.name===data.teamName); if(!t||!team){showToast("Please select a valid team.");return;} if(!tournamentJoins[tid])tournamentJoins[tid]=[]; if(tournamentJoins[tid].some(x=>x.teamId===team.id)){showToast("This team already joined this tournament.");return;} if(tournamentJoins[tid].length>=Number(t.teams)){showToast("Tournament is full.");return;} tournamentJoins[tid].push({teamId:team.id,teamName:team.name,game:team.game,registeredAt:new Date().toISOString()}); saveData();renderAll();closeModal();showToast(`${team.name} joined ${t.name}!`);return;}
  if((mode==="match"||mode==="result") && data.team1===data.team2) { showToast("Choose two different teams."); return; }
  if(mode==="team") {
    data.players=Number(data.players); data.wins=Number(data.wins); data.tag=(data.tag||data.name.slice(0,2)).toUpperCase(); data.playerNames=String(data.playerNames||"").split(/\n|,/).map(n=>n.trim()).filter(Boolean).slice(0,data.players); while(data.playerNames.length<data.players)data.playerNames.push(`Player ${data.playerNames.length+1}`);
    if(id) teams=teams.map(t=>t.id===id?{...t,...data}:t); else { teams.push({id:nextId++,...data}); }
    showToast(id?"Team updated successfully.":"Team registered successfully.");
  } else if(mode==="tournament") {
    data.teams=Number(data.teams); data.eliminationPoints=Number(data.eliminationPoints??1); data.positionPoints=Number(data.positionPoints??12); data.winPoints=Number(data.winPoints??5);
    if(id) tournaments=tournaments.map(t=>t.id===id?{...t,...data}:t); else tournaments.push({id:nextId++,...data});
    showToast(id?"Tournament updated.":"Tournament created successfully.");
  } else {
    if(mode==="result" || data.status==="Completed" || data.status==="Live") {
      data.score1=Number(data.score1??0); data.score2=Number(data.score2??0);
      data.placement1=Number(data.placement1??(data.score1>=data.score2?1:2)); data.placement2=Number(data.placement2??(data.score2>data.score1?1:2));
    } else { data.score1=null; data.score2=null; data.points1=0; data.points2=0; data.status="Scheduled"; }
    const oldMatch=id?matches.find(m=>m.id===id):null;
    if(data.status==="Completed") {
      const tournament=tournaments.find(t=>t.name===data.tournamentName);
      const elim=Number(tournament?.eliminationPoints??1), pos=Number(tournament?.positionPoints??12), win=Number(tournament?.winPoints??5);
      data.points1=Number(data.score1||0)*elim+(Number(data.placement1)===1?pos:0)+(Number(data.score1)>Number(data.score2)?win:0);
      data.points2=Number(data.score2||0)*elim+(Number(data.placement2)===1?pos:0)+(Number(data.score2)>Number(data.score1)?win:0);
      const winner=data.score1===data.score2?null:data.score1>data.score2?data.team1:data.team2;
      if(winner && (!oldMatch || oldMatch.status!=="Completed")) teams=teams.map(t=>t.name===winner?{...t,wins:Number(t.wins)+1,points:Number(t.points||0)+(winner===data.team1?data.points1:data.points2)}:t);
    } else if(data.status==="Live") { data.points1=0; data.points2=0; }
    if(id) matches=matches.map(m=>m.id===id?{...m,...data}:m); else matches.push({id:nextId++,...data});
    showToast(data.status==="Completed"?"Result saved and points calculated.":data.status==="Live"?"Match marked live.":"Match scheduled successfully.");
  }
  saveData(); renderAll(); closeModal();
});
function deleteItem(type,id) {
  if(!confirm("Are you sure you want to delete this item?")) return;
  if(type==="team") teams=teams.filter(t=>t.id!==id);
  if(type==="tournament") tournaments=tournaments.filter(t=>t.id!==id);
  if(type==="match") matches=matches.filter(m=>m.id!==id);
  saveData();renderAll();showToast("Item deleted.");
}
$("#addTeamBtn").addEventListener("click",()=>openModal("team"));
$("#addTournamentBtn").addEventListener("click",()=>openModal("tournament"));
$("#quickAddTournament").addEventListener("click",()=>openModal("tournament"));
$("#addMatchBtn").addEventListener("click",()=>openModal("match"));
$("#tournamentSearch").addEventListener("input",renderTournaments);
$("#tournamentFilter").addEventListener("change",renderTournaments);
$("#teamSearch").addEventListener("input",renderTeams);
$("#matchSearch").addEventListener("input",renderMatches);
$("#matchFilter").addEventListener("change",renderMatches);
$("#leaderboardGame")?.addEventListener("change",e=>{leaderboardGame=e.target.value;renderLeaderboard();});

document.addEventListener("click",e=>{
  const b=e.target.closest("button"); if(!b)return;
  if(b.dataset.viewTeam) showTeamPlayers(Number(b.dataset.viewTeam));
  if(b.dataset.joinTournament) { const t=tournaments.find(x=>x.id===Number(b.dataset.joinTournament)); if(t){const eligible=teams.filter(x=>x.game===t.game); if(!eligible.length){showToast(`First register a ${t.game} team.`);} else {openModal("join",t.id,{tournamentId:t.id}); const opts=eligible.map(x=>x.name); $("#modalTitle").textContent=`Join ${t.name}`; $("#modalFields").innerHTML=field("teamName","Select your team","select",opts[0],opts,true)+`<p class="muted full">Game: ${esc(t.game)} · ${esc(t.prize||"Prize not set")}</p>`; $("#modalForm").dataset.mode="join"; $("#modalForm").dataset.id=String(t.id);}}}
  if(b.dataset.editTeam) openModal("team",Number(b.dataset.editTeam));
  if(b.dataset.deleteTeam) deleteItem("team",Number(b.dataset.deleteTeam));
  if(b.dataset.editTournament) openModal("tournament",Number(b.dataset.editTournament));
  if(b.dataset.deleteTournament) deleteItem("tournament",Number(b.dataset.deleteTournament));
  if(b.dataset.editMatch) openModal("match",Number(b.dataset.editMatch));
  if(b.dataset.deleteMatch) deleteItem("match",Number(b.dataset.deleteMatch));
  if(b.dataset.resultMatch) {
    const m=matches.find(x=>x.id===Number(b.dataset.resultMatch));
    if(m) openModal("result",m.id,{...m,status:"Completed",score1:m.score1??0,score2:m.score2??0,placement1:m.placement1??1,placement2:m.placement2??2});
  }
});
renderAll();
