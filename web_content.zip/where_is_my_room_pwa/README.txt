WHERE IS MY ROOM — INSTALLABLE WEB APP (PWA)

FILES
- index.html: your app
- manifest.json: install metadata
- sw.js: basic offline app-shell caching

HOW TO INSTALL ON ANDROID
1. Upload these files to an HTTPS website (for example, a static hosting service).
2. Open the website in Chrome on your Android phone.
3. Open the browser menu (⋮) and choose "Install app" or "Add to Home screen".
4. Follow the prompts.

HOW TO USE ON PC
1. Open the HTTPS website in Chrome or Edge.
2. Use the install icon in the address bar, or browser menu > Install app.

IMPORTANT
- PWA installation requires HTTPS or localhost; opening index.html directly as a file will not install it.
- The Firebase database is not configured. Shared listings will not work until you add your Firebase project configuration and secure database/storage rules.
- This package does not contain a signed Android APK. If you specifically need an APK, it must be built separately using Android tooling or a trusted PWA-to-Android wrapper.
- Offline caching is basic; external fonts, Tailwind CDN, Firebase, and remote videos/photos still require internet.
