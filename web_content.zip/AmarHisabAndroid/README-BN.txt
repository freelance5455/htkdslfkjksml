আমার হিসাব — Android APK প্রজেক্ট

এই ফোল্ডারটি APK নয়; এটি Android Studio প্রজেক্ট, যেটি থেকে APK build করা যাবে।

কী আছে:
- app/src/main/assets/index.html : বর্তমান আমার হিসাব ওয়েব অ্যাপ
- MainActivity.java : Android WebView wrapper
- Gradle configuration ও Android manifest

APK বানানোর উপায় (কম্পিউটার প্রয়োজন):
1. Android Studio ইনস্টল করুন।
2. Android Studio-তে এই AmarHisabAndroid ফোল্ডারটি Open করুন।
3. Gradle sync সম্পন্ন হতে দিন; প্রয়োজন হলে Android SDK Platform 35 ইনস্টল করুন।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
5. তৈরি APK সাধারণত app/build/outputs/apk/debug/app-debug.apk-এ থাকবে।

গুরুত্বপূর্ণ:
- এই পরিবেশে Android SDK/Gradle build চালিয়ে APK কম্পাইল করা হয়নি। তাই এই ZIP-কে APK হিসেবে ইনস্টল করা যাবে না।
- ডেটা এই অ্যাপের স্থানীয় WebView storage-এ থাকে। অ্যাপের ডেটা মুছে ফেললে বা অ্যাপ আনইনস্টল করলে ডেটা হারাতে পারে।
- JSON ব্যাকআপ/রিস্টোর বাটন WebView-এ আলাদা পরীক্ষা করা দরকার; প্রয়োজন হলে Android file picker/download handling যোগ করতে হবে।
- এটি ব্যক্তিগত ব্যবহারের প্রাথমিক প্রজেক্ট; প্রকাশের আগে পরীক্ষা ও নিরাপত্তা যাচাই করুন।
