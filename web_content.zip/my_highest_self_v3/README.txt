LUMI — POTPUNO NA SRPSKOM

Ovo je veb-aplikacija prilagođena telefonima (PWA).
- Radi u pregledaču na Androidu i iPhone-u.
- Za dodavanje na početni ekran potrebna je HTTPS adresa/hosting.
- iPhone: otvori u Safariju, izaberi Deljenje > Dodaj na početni ekran.
- Android: otvori u Chrome-u, meni > Instaliraj aplikaciju / Dodaj na početni ekran.
- Ne može da iskače preko Instagrama na iPhone-u; ova verzija ne detektuje Instagram ni na Androidu.
- Podaci se čuvaju lokalno u pregledaču i ne sinhronizuju se automatski između uređaja.
- Lumi koristi ugrađene odgovore, ne povezani AI model.
- ZIP nije APK i ne instalira se direktno kao Android aplikacija.
