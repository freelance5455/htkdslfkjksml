MY HIGHEST SELF V3 — daily Lumi reminders
The daily reminder cycles through 365 distinct combinations of supportive, direct messages based on calendar day of year.
This web/PWA prototype cannot detect Instagram use or display a floating overlay on top of other apps. For that, a native Android app with user-granted special permissions is required.
The reminder appears inside this app when opened. It does not monitor app usage.
Host files on free HTTPS static hosting (e.g. GitHub Pages), then open on Android Chrome and choose Install app / Add to Home screen.
The companion uses built-in messages, not a connected AI. No AI can guarantee 100% accuracy.
