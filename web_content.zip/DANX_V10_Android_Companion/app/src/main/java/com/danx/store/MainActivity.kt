package com.danx.store

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var pendingCountry: String = "VPN"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(DanxBridge(), "DanxAndroid")
        setContentView(web)
        web.loadUrl("file:///android_asset/danx_store.html")
    }

    inner class DanxBridge {
        @JavascriptInterface
        fun launchMlbbWithFloating() {
            runOnUiThread {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity,
                        "Izinkan DANX tampil di atas aplikasi lain, lalu tekan LOG TO MLBB lagi.",
                        Toast.LENGTH_LONG).show()
                    startActivityForResult(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")), 401
                    )
                    return@runOnUiThread
                }
                FloatingService.start(this@MainActivity)
                launchGame()
            }
        }

        @JavascriptInterface
        fun requestVpnConsent(country: String) {
            runOnUiThread {
                pendingCountry = country
                val prepare = VpnService.prepare(this@MainActivity)
                if (prepare != null) {
                    startActivityForResult(prepare, 402)
                } else {
                    Toast.makeText(this@MainActivity,
                        "Izin VPN sudah pernah diberikan. Profil server $pendingCountry belum dikonfigurasi; VPN belum tersambung.",
                        Toast.LENGTH_LONG).show()
                }
            }
        }

        @JavascriptInterface
        fun disconnectVpn() {
            runOnUiThread {
                stopService(Intent(this@MainActivity, DanxVpnService::class.java))
                Toast.makeText(this@MainActivity, "Permintaan disconnect diterima.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun launchGame() {
        val game = packageManager.getLaunchIntentForPackage("com.mobile.legends")
        if (game != null) startActivity(game)
        else Toast.makeText(this, "Mobile Legends tidak ditemukan di perangkat.", Toast.LENGTH_LONG).show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 401) {
            if (Settings.canDrawOverlays(this)) {
                FloatingService.start(this)
                launchGame()
            } else {
                Toast.makeText(this, "Izin Floating Window belum diberikan.", Toast.LENGTH_LONG).show()
            }
        } else if (requestCode == 402) {
            if (resultCode == RESULT_OK) {
                Toast.makeText(this,
                    "Izin VPN Android disetujui. Server $pendingCountry belum dikonfigurasi, jadi VPN belum dapat menyambung.",
                    Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Permintaan VPN dibatalkan.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
