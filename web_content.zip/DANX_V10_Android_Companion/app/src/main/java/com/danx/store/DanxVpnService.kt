package com.danx.store

import android.net.VpnService
import android.content.Intent
import android.os.IBinder

/**
 * Placeholder service declaration for Android's VPN consent flow.
 * No tunnel is created: a real VPN needs an operator-provided server endpoint,
 * authentication, routing and DNS configuration.
 */
class DanxVpnService : VpnService() {
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        stopSelf()
        return START_NOT_STICKY
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
