package com.danx.store

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class FloatingService : Service() {
    companion object {
        fun start(context: Context) {
            val i = Intent(context, FloatingService::class.java)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i)
        }
    }

    private lateinit var wm: WindowManager
    private var root: View? = null
    private var params: WindowManager.LayoutParams? = null
    private var expanded = false
    private var downX = 0
    private var downY = 0
    private var startX = 0
    private var startY = 0

    override fun onCreate() {
        super.onCreate()
        startForeground(81, notification())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    private fun notification(): Notification {
        val channel = "danx_float"
        if (Build.VERSION.SDK_INT >= 26) {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(NotificationChannel(channel, "DANX Floating", NotificationManager.IMPORTANCE_LOW))
        }
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channel) else Notification.Builder(this)
        return b.setContentTitle("DANX Floating aktif")
            .setContentText("Ketuk logo DX untuk membuka Rank Booster.")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true).build()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun shape(color: Int, radius: Int, stroke: Int = Color.TRANSPARENT) =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat(); if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke) }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color); gravity = Gravity.CENTER
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }

    private fun showBubble() {
        remove()
        expanded = false
        val bubble = text("DX", 17f, Color.WHITE, true).apply {
            background = shape(Color.rgb(55, 75, 224), 50, Color.rgb(32, 213, 138))
            elevation = dp(8).toFloat()
            setOnTouchListener(drag { showPanel() })
        }
        attach(bubble, dp(58), dp(58))
    }

    private fun showPanel() {
        remove()
        expanded = true
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = shape(Color.rgb(255, 255, 255), 18, Color.rgb(75, 94, 226))
            elevation = dp(12).toFloat()
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = text("DANX STORE", 14f, Color.rgb(36, 50, 74), true)
        title.gravity = Gravity.CENTER_VERTICAL or Gravity.START
        head.addView(title, LinearLayout.LayoutParams(0, dp(40), 1f))
        val min = text("—", 20f, Color.rgb(50, 70, 190), true).apply {
            background = shape(Color.rgb(239, 242, 255), 10)
            setOnClickListener { showBubble() }
        }
        head.addView(min, LinearLayout.LayoutParams(dp(42), dp(38)))
        head.setOnTouchListener(drag(null))
        box.addView(head)

        val names = listOf("ENEMY NOOB", "AUTO BOT", "FAST MATCHING", "TIM PRO", "ANTI DETECT")
        names.forEach { name ->
            var enabled = false
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = shape(Color.rgb(245, 247, 252), 11)
                setPadding(dp(8), dp(4), dp(8), dp(4))
            }
            val label = text(name, 11f, Color.rgb(36, 50, 74), true)
            label.gravity = Gravity.CENTER_VERTICAL or Gravity.START
            row.addView(label, LinearLayout.LayoutParams(0, dp(42), 1f))
            val toggle = text("OFF", 10f, Color.WHITE, true).apply {
                background = shape(Color.rgb(160, 170, 185), 20)
            }
            row.addView(toggle, LinearLayout.LayoutParams(dp(55), dp(30)))
            row.setOnClickListener {
                enabled = !enabled
                toggle.text = if (enabled) "ON" else "OFF"
                toggle.background = shape(if (enabled) Color.rgb(32, 190, 128) else Color.rgb(160, 170, 185), 20)
            }
            val lp = LinearLayout.LayoutParams(dp(250), dp(48))
            lp.topMargin = dp(7)
            box.addView(row, lp)
        }

        val close = text("CLOSE", 12f, Color.WHITE, true).apply {
            background = shape(Color.rgb(75, 85, 210), 10)
            setOnClickListener { stopSelf() }
        }
        val cp = LinearLayout.LayoutParams(dp(250), dp(40))
        cp.topMargin = dp(9)
        box.addView(close, cp)
        attach(box, dp(274), dp(330))
    }

    private fun drag(tap: (() -> Unit)?): View.OnTouchListener = View.OnTouchListener { view, event ->
        val p = params ?: return@OnTouchListener false
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.rawX.toInt(); downY = event.rawY.toInt()
                startX = p.x; startY = p.y; true
            }
            MotionEvent.ACTION_MOVE -> {
                p.x = startX + event.rawX.toInt() - downX
                p.y = startY + event.rawY.toInt() - downY
                try { wm.updateViewLayout(view, p) } catch (_: Exception) {}
                true
            }
            MotionEvent.ACTION_UP -> {
                val dx = event.rawX.toInt() - downX; val dy = event.rawY.toInt() - downY
                if (kotlin.math.abs(dx) < dp(8) && kotlin.math.abs(dy) < dp(8)) tap?.invoke()
                true
            }
            else -> false
        }
    }

    private fun attach(view: View, w: Int, h: Int) {
        root = view
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        params = WindowManager.LayoutParams(w, h, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = dp(14); y = dp(180)
        }
        wm.addView(view, params)
    }

    private fun remove() {
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_NOT_STICKY
    override fun onDestroy() { remove(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
