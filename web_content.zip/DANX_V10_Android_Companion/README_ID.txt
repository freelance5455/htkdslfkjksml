DANX STORE V10 - ANDROID COMPANION

Isi ZIP:
- Panel DANX V10 asli sebagai asset lokal.
- Floating Window native Android dengan bubble DX.
- LOG TO MLBB meminta izin "Tampil di atas aplikasi lain", menampilkan bubble DX,
  lalu mencoba membuka Mobile Legends.
- Panel mini berwarna senada dengan DANX: ENEMY NOOB, AUTO BOT,
  FAST MATCHING, TIM PRO, ANTI DETECT, dan tombol CLOSE.
- CONNECT VPN memanggil dialog persetujuan VPN sistem Android.

PENTING TENTANG VPN:
Dialog pada screenshot adalah dialog persetujuan Android, bukan koneksi VPN.
ZIP ini dapat meminta izin tersebut, tetapi BELUM dapat membuat tunnel VPN
yang benar-benar memperbaiki ping. Untuk VPN nyata dibutuhkan server VPN aktif
untuk tiap negara (endpoint, protokol, autentikasi, DNS/routing) atau integrasi
dengan penyedia VPN. Tidak ada server/akun VPN yang disertakan, jadi aplikasi
secara sengaja tidak berpura-pura sudah tersambung. Nilai ms di panel adalah
contoh visual, bukan ping terukur.

RANK BOOSTER:
Switch pada floating panel adalah kontrol tampilan UI. Tidak mengubah rank,
matchmaking, file game, anti-cheat, atau memberi keuntungan kompetitif.

CARA BUILD:
1. Buka folder project di Android Studio.
2. Tunggu Gradle sync selesai.
3. Pilih Build > Build APK(s).
4. Instal APK hasil build di Android.
5. Buka DANX STORE dan tekan LOG TO MLBB.
6. Izinkan "Tampil di atas aplikasi lain", kembali ke panel, lalu tekan lagi.
7. Untuk VPN, pilih lokasi lalu CONNECT; Android akan menampilkan persetujuan
   VPN. Koneksi belum aktif sampai server VPN yang valid dikonfigurasi.

Package Mobile Legends yang dipanggil: com.mobile.legends.
Jika versi game di perangkat menggunakan package berbeda, sesuaikan di
MainActivity.kt.


PERBAIKAN PREMIUM KEY:
- Key Center kini menyimpan 1.000 key ke localStorage browser (334 key 7 hari,
  333 key 2 bulan, 333 key permanen).
- Key yang dibuat di Key Center dapat dipakai pada layar login di browser/
  perangkat yang sama. Masa aktif mulai dihitung saat pertama kali digunakan.
- Key lokal tidak tersinkron antarperangkat dan bukan sistem penjualan aman.
  Untuk menjual key lintas perangkat, wajib memakai backend/database dan
  validasi server; jangan mengandalkan localStorage.
- Kunci admin awal panel tetap: DANX-DEMO-2026. Kode rahasia Key Center: 2011-23.

CATATAN:
- VPN tetap belum dapat menyambung ke internet karena belum ada endpoint/server
  VPN dan kredensial untuk 15 negara. Jangan menganggap izin VPN Android sebagai
  koneksi VPN aktif. Masukkan konfigurasi resmi dari provider/server untuk
  implementasi tunnel yang benar.
