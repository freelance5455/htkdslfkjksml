# MR-KHORASANI v1.6.3 — UI Interaction Fix

- Added resilient V1.5 event binding so one missing handler cannot stop subsequent bindings.
- Added Android/WebView-safe delegated click bridge for navigation, toolbar, party/item import/export, warehouse management, documents, backups and core V1.5 actions.
- Mobile sidebar now closes after selecting any navigation item, including dynamically added V1.5 menu entries.
- Added touch-safe/pointer-safe button CSS for Android WebView.
- Existing Excel import/export and storage fixes are preserved.
