
// NEXUS AI — POLLINATIONS + CHAT HISTORY + MARKDOWN + LATEX

const $ = id => document.getElementById(id);

const chat = $("chat");
const input = $("message");
const sendBtn = $("sendBtn");
const status = $("modeStatus");

const APP_KEY = "pk_WFojrsjaeuFPnr54";
const API_URL = "https://gen.pollinations.ai/v1/chat/completions";
const MODEL = "openai/gpt-5.4-nano";
const STORAGE_KEY = "nexus_ai_chats_v1";

const SYSTEM_PROMPT = `
Ты NEXUS AI — интеллектуальный помощник.
Отвечай на русском языке.
Объясняй понятно, помогай с программированием,
учёбой и другими вопросами.

Математика:
- Используй LaTeX для математических формул.
- Для формул внутри текста используй \\( ... \\).
- Для отдельных формул используй \\[ ... \\].
- Не выводи команды LaTeX без специальных скобок.
- На простые математические вопросы отвечай кратко.

Используй Markdown для оформления ответов.
`;

let pollinationsKey = null;
let busy = false;
let chats = loadChats();
let currentChatId = chats[0]?.id || null;

// Загрузка KaTeX

function loadKatex() {
    return new Promise((resolve, reject) => {
        if (window.renderMathInElement) {
            resolve();
            return;
        }

        const css = document.createElement("link");
        css.rel = "stylesheet";
        css.href =
            "https://cdn.jsdelivr.net/npm/katex@0.16.22/dist/katex.min.css";

        document.head.appendChild(css);

        function loadScript(url) {
            return new Promise((res, rej) => {
                const script = document.createElement("script");
                script.src = url;
                script.onload = res;
                script.onerror = rej;
                document.head.appendChild(script);
            });
        }

        loadScript(
            "https://cdn.jsdelivr.net/npm/katex@0.16.22/dist/katex.min.js"
        )
        .then(() => loadScript(
            "https://cdn.jsdelivr.net/npm/katex@0.16.22/dist/contrib/auto-render.min.js"
        ))
        .then(resolve)
        .catch(reject);
    });
}

const katexPromise = loadKatex();

function applyMath(element) {
    katexPromise.then(() => {
        if (!element.isConnected) return;

        window.renderMathInElement(element, {
            delimiters: [
                { left: "$$", right: "$$", display: true },
                { left: "\\[", right: "\\]", display: true },
                { left: "\\(", right: "\\)", display: false }
            ],
            throwOnError: false,
            strict: "ignore"
        });
    }).catch(error => {
        console.warn("KaTeX не загрузился:", error);
    });
}

// История чатов

function makeId() {
    return Date.now().toString(36) +
        Math.random().toString(36).slice(2, 8);
}

function loadChats() {
    try {
        const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
        return Array.isArray(saved) ? saved : [];
    } catch {
        return [];
    }
}

function saveChats() {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(chats));
    } catch (error) {
        console.error("Не удалось сохранить чаты:", error);
        setStatus("Ошибка сохранения истории");
    }
}

function getCurrentChat() {
    return chats.find(item => item.id === currentChatId);
}

function createChat() {
    const item = {
        id: makeId(),
        title: "Новый чат",
        messages: [],
        updatedAt: Date.now()
    };

    chats.unshift(item);
    currentChatId = item.id;

    saveChats();
    renderChat();
    renderSidebar();
}

function setStatus(text) {
    if (status) status.textContent = text;
}

// Markdown и HTML

function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, char => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[char]);
}

function renderMarkdown(source) {
    let text = escapeHTML(source);

    const codeBlocks = [];
    const mathBlocks = [];

    // Сначала защищаем блоки кода

    text = text.replace(
        /```([a-zA-Z0-9_-]*)\n?([\s\S]*?)```/g,
        (_, language, code) => {
            const index = codeBlocks.length;

            codeBlocks.push(
                `<pre><code>${code.trimEnd()}</code></pre>`
            );

            return `%%CODEBLOCK${index}%%`;
        }
    );

    // Защищаем формулы с явными разделителями

    function saveMath(formula, display) {
        const index = mathBlocks.length;

        mathBlocks.push({
            formula,
            display
        });

        return `%%MATHBLOCK${index}%%`;
    }

    text = text.replace(
        /\\\[([\s\S]*?)\\\]/g,
        (_, formula) => saveMath(formula, true)
    );

    text = text.replace(
        /\\\(([\s\S]*?)\\\)/g,
        (_, formula) => saveMath(formula, false)
    );

    text = text.replace(
        /\$\$([\s\S]*?)\$\$/g,
        (_, formula) => saveMath(formula, true)
    );

    // Распознаём отдельные формулы без скобок LaTeX

    text = text.replace(
        /^([^\n]*\\(?:times|cdot|div|frac|sqrt|pi|pm|neq|leq|geq|approx|infty|sum|prod|rightarrow|left|right)[^\n]*)$/gm,
        (_, formula) => saveMath(formula, true)
    );

    // Обычный Markdown

    text = text.replace(
        /`([^`\n]+)`/g,
        "<code>$1</code>"
    );

    text = text.replace(/^### (.+)$/gm, "<h3>$1</h3>");
    text = text.replace(/^## (.+)$/gm, "<h2>$1</h2>");
    text = text.replace(/^# (.+)$/gm, "<h1>$1</h1>");

    text = text.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
    text = text.replace(/\*(.+?)\*/g, "<em>$1</em>");
    text = text.replace(/~~(.+?)~~/g, "<del>$1</del>");

    const lines = text.split("\n");
    const output = [];

    let inList = false;
    let listType = "";

    function closeList() {
        if (inList) {
            output.push(
                listType === "ol" ? "</ol>" : "</ul>"
            );

            inList = false;
            listType = "";
        }
    }

    for (const line of lines) {
        const unordered = line.match(/^\s*[-*]\s+(.+)/);
        const ordered = line.match(/^\s*\d+\.\s+(.+)/);

        if (unordered || ordered) {
            const type = unordered ? "ul" : "ol";

            if (!inList || listType !== type) {
                closeList();

                output.push(
                    type === "ol" ? "<ol>" : "<ul>"
                );

                inList = true;
                listType = type;
            }

            output.push(
                `<li>${(unordered || ordered)[1]}</li>`
            );

            continue;
        }

        closeList();

        if (!line.trim()) {
            output.push("");
        } else if (
            /^%%(?:CODEBLOCK|MATHBLOCK)\d+%%$/.test(line.trim())
        ) {
            output.push(line.trim());
        } else {
            output.push(`<p>${line}</p>`);
        }
    }

    closeList();

    let html = output.join("\n");

    // Возвращаем блоки кода

    html = html.replace(
        /%%CODEBLOCK(\d+)%%/g,
        (_, index) => codeBlocks[Number(index)] || ""
    );

    // Возвращаем математические формулы

    html = html.replace(
        /%%MATHBLOCK(\d+)%%/g,
        (_, index) => {
            const math = mathBlocks[Number(index)];

            if (!math) return "";

            if (math.display) {
                return `\\[${math.formula}\\]`;
            }

            return `\\(${math.formula}\\)`;
        }
    );

    return html;
}

// Сообщения

function addMessage(role, text, shouldSave = true) {
    const el = document.createElement("div");

    el.className =
        `message ${role === "user" ? "user" : "bot"}`;

    const content = document.createElement("div");
    content.className = "message-content";

    if (role === "user") {
        content.textContent = text;
    } else {
        content.innerHTML = renderMarkdown(text);
        applyMath(content);
    }

    el.appendChild(content);
    chat.appendChild(el);

    const welcome = $("welcome");

    if (welcome) welcome.style.display = "none";

    chat.scrollTop = chat.scrollHeight;

    if (shouldSave) {
        const item = getCurrentChat();

        if (item) {
            item.messages.push({
                role,
                content: text
            });

            item.updatedAt = Date.now();

            if (
                role === "user" &&
                item.title === "Новый чат"
            ) {
                item.title = text.slice(0, 32) +
                    (text.length > 32 ? "…" : "");
            }

            saveChats();
            renderSidebar();
        }
    }
}

function renderChat() {
    const item = getCurrentChat();

    chat.querySelectorAll(".message").forEach(
        el => el.remove()
    );

    const welcome = $("welcome");

    if (!item || !item.messages.length) {
        if (welcome) welcome.style.display = "flex";
        return;
    }

    if (welcome) welcome.style.display = "none";

    for (const message of item.messages) {
        addMessage(
            message.role,
            message.content,
            false
        );
    }

    chat.scrollTop = chat.scrollHeight;
}

// Боковое меню и история

function renderSidebar() {
    const container = $("history");
    if (!container) return;

    container.replaceChildren();

    for (const item of chats) {
        const row = document.createElement("div");
        row.className = "history-item";

        if (item.id === currentChatId) {
            row.classList.add("selected");
        }

        const openBtn = document.createElement("button");
        openBtn.className = "history-open";
        openBtn.textContent = item.title || "Новый чат";
        openBtn.title = item.title || "Новый чат";

        openBtn.addEventListener("click", () => {
            currentChatId = item.id;
            renderChat();
            renderSidebar();
            closeSidebar();
        });

        const actions = document.createElement("div");
        actions.className = "history-actions";

        const renameBtn = document.createElement("button");
        renameBtn.className = "history-action";
        renameBtn.textContent = "✎";
        renameBtn.title = "Переименовать";

        renameBtn.addEventListener("click", () => {
            const title = prompt(
                "Новое название чата:",
                item.title
            );

            if (title && title.trim()) {
                item.title = title.trim().slice(0, 60);
                saveChats();
                renderSidebar();
            }
        });

        const deleteBtn = document.createElement("button");
        deleteBtn.className = "history-action delete";
        deleteBtn.textContent = "×";
        deleteBtn.title = "Удалить чат";

        deleteBtn.addEventListener("click", () => {
            if (!confirm(
                `Удалить чат «${item.title}»?`
            )) return;

            chats = chats.filter(
                chatItem => chatItem.id !== item.id
            );

            if (currentChatId === item.id) {
                currentChatId = chats[0]?.id || null;
            }

            if (!currentChatId) {
                createChat();
            } else {
                saveChats();
                renderChat();
                renderSidebar();
            }
        });

        actions.append(renameBtn, deleteBtn);
        row.append(openBtn, actions);
        container.appendChild(row);
    }
}

function openSidebar() {
    $("sidebar")?.classList.add("open");
    $("overlay")?.classList.add("show");
}

function closeSidebar() {
    $("sidebar")?.classList.remove("open");
    $("overlay")?.classList.remove("show");
}

// Pollinations Connect

async function initPollinationsConnect() {
    try {
        if (!customElements.get("polli-connect")) {
            const script = document.createElement("script");

            script.src =
                "https://cdn.jsdelivr.net/npm/@pollinations/ui@0.1.0-alpha.20/dist/connect.js";

            script.defer = true;

            await new Promise((resolve, reject) => {
                script.onload = resolve;
                script.onerror = reject;
                document.head.appendChild(script);
            });
        }

        await customElements.whenDefined("polli-connect");

        const wrapper = document.createElement("div");
        wrapper.className = "connect-wrapper";

        const connect = document.createElement("polli-connect");

        connect.setAttribute("app-key", APP_KEY);
        connect.setAttribute("budget", "1");
        connect.setAttribute("expiry", "1");
        connect.setAttribute("models", MODEL);
        connect.setAttribute("hide-buy-pollen", "");

        connect.addEventListener("change", () => {
            pollinationsKey = connect.apiKey || null;

            setStatus(
                pollinationsKey
                    ? "CLOUD AI — подключено"
                    : "CLOUD AI — не подключено"
            );
        });

        wrapper.appendChild(connect);

        if (status) {
            status.insertAdjacentElement(
                "afterend",
                wrapper
            );
        } else {
            document.querySelector(".mode-switch")
                ?.insertAdjacentElement(
                    "afterend",
                    wrapper
                );
        }

        pollinationsKey = connect.apiKey || null;

        setStatus(
            pollinationsKey
                ? "CLOUD AI — подключено"
                : "CLOUD AI — нажми Connect"
        );

    } catch (error) {
        console.error("Pollinations Connect:", error);
        setStatus("CLOUD AI — ошибка подключения");
    }
}

// Запрос к AI

async function askAI() {
    if (busy || !input) return;

    const text = input.value.trim();
    if (!text) return;

    if (!pollinationsKey) {
        addMessage(
            "assistant",
            "Сначала подключи Pollinations через кнопку Connect."
        );
        return;
    }

    if (!currentChatId) createChat();

    const item = getCurrentChat();

    input.value = "";
    input.style.height = "auto";

    addMessage("user", text);

    busy = true;

    if (sendBtn) sendBtn.disabled = true;

    setStatus("CLOUD AI — думает...");

    try {
        const response = await fetch(API_URL, {
            method: "POST",

            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${pollinationsKey}`
            },

            body: JSON.stringify({
                model: MODEL,

                messages: [
                    {
                        role: "system",
                        content: SYSTEM_PROMPT
                    },

                    ...item.messages.slice(-20)
                ]
            })
        });

        const data = await response.json().catch(
            () => ({})
        );

        if (!response.ok) {
            throw new Error(
                data?.error?.message ||
                `Ошибка сервера: ${response.status}`
            );
        }

        const answer =
            data?.choices?.[0]?.message?.content;

        if (!answer) {
            throw new Error(
                "Сервер не вернул ответ."
            );
        }

        addMessage("assistant", answer);

        setStatus("CLOUD AI — онлайн");

    } catch (error) {
        console.error("NEXUS AI:", error);

        addMessage(
            "assistant",
            "Не удалось получить ответ.\n" +
            (error.message || String(error))
        );

        setStatus("CLOUD AI — ошибка подключения");

    } finally {
        busy = false;

        if (sendBtn) sendBtn.disabled = false;

        input.focus();
    }
}

// Кнопки приложения

sendBtn?.addEventListener("click", askAI);

input?.addEventListener("keydown", event => {
    if (
        event.key === "Enter" &&
        !event.shiftKey
    ) {
        event.preventDefault();
        askAI();
    }
});

input?.addEventListener("input", () => {
    input.style.height = "auto";

    input.style.height =
        Math.min(input.scrollHeight, 110) + "px";
});

$("newChat")?.addEventListener(
    "click",
    createChat
);

$("sidebarNewChat")?.addEventListener("click", () => {
    createChat();
    closeSidebar();
});

$("menuBtn")?.addEventListener(
    "click",
    openSidebar
);

$("closeMenu")?.addEventListener(
    "click",
    closeSidebar
);

$("overlay")?.addEventListener(
    "click",
    closeSidebar
);

$("localMode")?.style.setProperty(
    "display",
    "none"
);

$("cloudMode")?.classList.add("active");

// Кнопки-подсказки

document.querySelectorAll(".suggestion").forEach(
    button => {
        button.addEventListener("click", () => {
            input.value = button.textContent
                .replace(/^[^\p{L}\p{N}]+/u, "")
                .trim();

            input.focus();

            input.dispatchEvent(
                new Event("input")
            );
        });
    }
);

// Запуск

if (!chats.length) {
    createChat();
} else {
    renderChat();
    renderSidebar();
}

setStatus("CLOUD AI — загружается");

initPollinationsConnect();

console.log("NEXUS AI запущен");


