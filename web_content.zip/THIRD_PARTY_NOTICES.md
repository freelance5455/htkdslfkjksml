# Avisos de terceros — Pulguita IA v1.1

## Kivy
Kivy es una dependencia de terceros utilizada para ejecutar la aplicación y construir la interfaz Android.
Licencia: MIT (para versiones modernas de Kivy).

Sitio oficial:
https://kivy.org/

## PyJNIus
PyJNIus es una dependencia de terceros utilizada para acceder a APIs Java/Android desde Python.
Licencia: MIT.

Repositorio oficial:
https://github.com/kivy/pyjnius

## Python
Python es el runtime utilizado por la aplicación durante la construcción/ejecución correspondiente.
Su licencia y avisos se distribuyen con el entorno de Python utilizado.

## Servicios web
El núcleo v1.1 no incorpora código de Wikipedia, Google, OpenAI ni otro proveedor de IA.
La interfaz de búsqueda web está desacoplada y puede recibir una fuente externa en el futuro.

## Datos lingüísticos
La base lingüística incluida en esta versión es una base compacta escrita para Pulguita y no pretende ser una copia de un diccionario comercial.
