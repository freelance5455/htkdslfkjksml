THE LAST SIGNAL - Android WebView project

المشروع يغلّف ملف HTML الأصلي داخل تطبيق Android مستقل.

طريقة إخراج APK:
1) افتح Android Studio.
2) اختر Open ثم اختر مجلد the-last-signal-android بعد فك الضغط.
3) انتظر Gradle Sync ونزّل Android SDK Platform 35 إذا طلبه Android Studio.
4) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
5) ستجد الملف عادةً في app/build/outputs/apk/debug/app-debug.apk

ملاحظات:
- يحتاج التطبيق اتصال إنترنت لتحميل مكتبة Three.js من CDN كما في ملف HTML الأصلي.
- تم تفعيل JavaScript وDOM Storage حتى تعمل التفاعلات وحفظ التقدم.
- لا يحتوي هذا التسليم على APK مبني؛ إنه مشروع Android جاهز للبناء في Android Studio.
