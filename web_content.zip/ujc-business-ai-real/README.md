# UJC Business AI — Real Backend Starter

This is a runnable starter project, not a hosted production service. It includes:
- Account registration/login with bcrypt password hashing and session cookies
- Per-user data isolation for orders, inventory, and sales/expenses
- SQLite database stored on the server
- Server-side Gemini API proxy (the API key is never sent to the browser)
- JSON backup download

## Run locally
Requires Node.js 20 or newer.

1. Extract this ZIP.
2. Copy `.env.example` to `.env`.
3. Set a long, random `SESSION_SECRET`.
4. Optionally set `GEMINI_API_KEY` and `GEMINI_MODEL` in `.env`.
5. In the project folder run:
   `npm install`
   `npm start`
6. Open `http://localhost:3000`.

## Important
- Without `GEMINI_API_KEY`, accounts and business records work but AI returns a setup message.
- API keys and usage quotas depend on your AI provider account and current terms.
- This starter uses SQLite, which is suitable for a small single-server prototype. Some hosting platforms have ephemeral filesystems; configure persistent storage or a managed database before deployment.
- `express-session` uses its default in-memory store here. Replace it with a persistent session store before production deployment.
- Deploy behind HTTPS and set `COOKIE_SECURE=true`.
- Set a unique, strong `SESSION_SECRET`; never commit `.env` to a public repository.
- Add automated backups, email verification, password reset, CSRF protections appropriate to your deployment, monitoring, and a privacy policy before handling real customer information.
- Do not collect payment card numbers or bank passwords in this app.
- No actual WhatsApp messaging, courier API, banking integration, or APK build is included.
