require("dotenv").config();
const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);
if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.includes("replace-this")) {
  console.warn("WARNING: Set a unique SESSION_SECRET in .env before using this beyond local testing.");
}
const db = new Database(process.env.DB_PATH || "ujc-business.sqlite");
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  customer TEXT NOT NULL, item TEXT NOT NULL, amount REAL NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'New', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL, qty INTEGER NOT NULL DEFAULT 0, min_qty INTEGER NOT NULL DEFAULT 5,
  unit_cost REAL NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS finance (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL CHECK(kind IN ('sale','expense')), description TEXT NOT NULL,
  amount REAL NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);
app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "200kb" }));
app.use(session({
  name: "ujc.sid",
  secret: process.env.SESSION_SECRET || "local-development-only-secret-change-me",
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.COOKIE_SECURE === "true", maxAge: 1000*60*60*8 }
}));
app.use("/api/", rateLimit({ windowMs: 15*60*1000, limit: 180, standardHeaders: "draft-7", legacyHeaders: false }));
app.use(express.static(path.join(__dirname, "public")));

const emailOk = s => typeof s === "string" && s.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s);
const textOk = (s, max=500) => typeof s === "string" && s.trim().length > 0 && s.length <= max;
const numOk = n => typeof n === "number" && Number.isFinite(n) && n >= 0;
const currentUser = req => req.session.user || null;
function auth(req,res,next){ if(!currentUser(req)) return res.status(401).json({error:"Please log in first."}); next(); }

app.post("/api/register", rateLimit({windowMs:60*60*1000,limit:10}), async (req,res)=>{
  const email = String(req.body.email||"").trim().toLowerCase(), password = req.body.password;
  if(!emailOk(email) || typeof password!=="string" || password.length<10 || password.length>128)
    return res.status(400).json({error:"Enter a valid email and a password of 10–128 characters."});
  try {
    const hash = await bcrypt.hash(password, 12);
    const info = db.prepare("INSERT INTO users(email,password_hash) VALUES(?,?)").run(email,hash);
    req.session.user = {id:Number(info.lastInsertRowid), email};
    res.json({user:req.session.user});
  } catch(e) { res.status(409).json({error:"That email may already be registered."}); }
});
app.post("/api/login", rateLimit({windowMs:15*60*1000,limit:10}), async (req,res)=>{
  const email=String(req.body.email||"").trim().toLowerCase(), password=req.body.password;
  const user=db.prepare("SELECT * FROM users WHERE email=?").get(email);
  if(!user || typeof password!=="string" || !(await bcrypt.compare(password,user.password_hash)))
    return res.status(401).json({error:"Email or password is incorrect."});
  req.session.regenerate(err=>{
    if(err) return res.status(500).json({error:"Could not start session."});
    req.session.user={id:user.id,email:user.email};
    res.json({user:req.session.user});
  });
});
app.post("/api/logout",(req,res)=>req.session.destroy(()=>{res.clearCookie("ujc.sid");res.json({ok:true});}));
app.get("/api/me",(req,res)=>res.json({user:currentUser(req)}));

app.get("/api/data",auth,(req,res)=>{
  const id=currentUser(req).id;
  res.json({
    orders:db.prepare("SELECT id,customer,item,amount,status,created_at FROM orders WHERE user_id=? ORDER BY id DESC").all(id),
    products:db.prepare("SELECT id,name,qty,min_qty,unit_cost FROM products WHERE user_id=? ORDER BY id DESC").all(id),
    finance:db.prepare("SELECT id,kind,description,amount,created_at FROM finance WHERE user_id=? ORDER BY id DESC").all(id)
  });
});

app.post("/api/orders",auth,(req,res)=>{
  const {customer,item,status="New"}=req.body, amount=Number(req.body.amount);
  const allowed=["New","Processing","Shipped","Delivered","Cancelled"];
  if(!textOk(customer,160)||!textOk(item,500)||!numOk(amount)||!allowed.includes(status)) return res.status(400).json({error:"Check order fields."});
  const x=db.prepare("INSERT INTO orders(user_id,customer,item,amount,status) VALUES(?,?,?,?,?)").run(currentUser(req).id,customer.trim(),item.trim(),amount,status);
  res.json({id:Number(x.lastInsertRowid)});
});
app.patch("/api/orders/:id",auth,(req,res)=>{
  const {customer,item,status}=req.body, amount=Number(req.body.amount), id=Number(req.params.id);
  const allowed=["New","Processing","Shipped","Delivered","Cancelled"];
  if(!Number.isInteger(id)||!textOk(customer,160)||!textOk(item,500)||!numOk(amount)||!allowed.includes(status)) return res.status(400).json({error:"Check order fields."});
  const x=db.prepare("UPDATE orders SET customer=?,item=?,amount=?,status=? WHERE id=? AND user_id=?").run(customer.trim(),item.trim(),amount,status,id,currentUser(req).id);
  res.json({updated:x.changes===1});
});
app.delete("/api/orders/:id",auth,(req,res)=>{const x=db.prepare("DELETE FROM orders WHERE id=? AND user_id=?").run(Number(req.params.id),currentUser(req).id);res.json({deleted:x.changes===1});});

app.post("/api/products",auth,(req,res)=>{
  const {name}=req.body, qty=Number(req.body.qty), min=Number(req.body.min_qty), unit=Number(req.body.unit_cost||0);
  if(!textOk(name,180)||!Number.isInteger(qty)||qty<0||!Number.isInteger(min)||min<0||!numOk(unit)) return res.status(400).json({error:"Check product fields."});
  const x=db.prepare("INSERT INTO products(user_id,name,qty,min_qty,unit_cost) VALUES(?,?,?,?,?)").run(currentUser(req).id,name.trim(),qty,min,unit);
  res.json({id:Number(x.lastInsertRowid)});
});
app.patch("/api/products/:id",auth,(req,res)=>{
  const {name}=req.body, qty=Number(req.body.qty), min=Number(req.body.min_qty), unit=Number(req.body.unit_cost||0), id=Number(req.params.id);
  if(!Number.isInteger(id)||!textOk(name,180)||!Number.isInteger(qty)||qty<0||!Number.isInteger(min)||min<0||!numOk(unit)) return res.status(400).json({error:"Check product fields."});
  const x=db.prepare("UPDATE products SET name=?,qty=?,min_qty=?,unit_cost=? WHERE id=? AND user_id=?").run(name.trim(),qty,min,unit,id,currentUser(req).id);
  res.json({updated:x.changes===1});
});
app.delete("/api/products/:id",auth,(req,res)=>{const x=db.prepare("DELETE FROM products WHERE id=? AND user_id=?").run(Number(req.params.id),currentUser(req).id);res.json({deleted:x.changes===1});});

app.post("/api/finance",auth,(req,res)=>{
  const {kind,description}=req.body, amount=Number(req.body.amount);
  if(!["sale","expense"].includes(kind)||!textOk(description,300)||!numOk(amount)) return res.status(400).json({error:"Check finance fields."});
  const x=db.prepare("INSERT INTO finance(user_id,kind,description,amount) VALUES(?,?,?,?)").run(currentUser(req).id,kind,description.trim(),amount);
  res.json({id:Number(x.lastInsertRowid)});
});
app.delete("/api/finance/:id",auth,(req,res)=>{const x=db.prepare("DELETE FROM finance WHERE id=? AND user_id=?").run(Number(req.params.id),currentUser(req).id);res.json({deleted:x.changes===1});});

app.post("/api/ai",auth,async(req,res)=>{
  const prompt=req.body.prompt;
  if(!textOk(prompt,6000)) return res.status(400).json({error:"Enter a prompt (max 6000 characters)."});
  if(!process.env.GEMINI_API_KEY) return res.status(503).json({error:"AI is not configured yet. Add GEMINI_API_KEY to the server environment."});
  const model=process.env.GEMINI_MODEL||"gemini-2.5-flash";
  try{
    const response=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`,{
      method:"POST",headers:{"Content-Type":"application/json","x-goog-api-key":process.env.GEMINI_API_KEY},
      body:JSON.stringify({contents:[{parts:[{text:prompt}]}],generationConfig:{temperature:0.4,maxOutputTokens:900}})
    });
    const data=await response.json();
    if(!response.ok) return res.status(502).json({error:data.error?.message||"AI provider request failed."});
    res.json({text:data.candidates?.[0]?.content?.parts?.map(p=>p.text||"").join("\n")||"No response text."});
  }catch(e){res.status(502).json({error:"Could not reach the AI provider. Check server internet access."});}
});
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`UJC Business AI running on http://localhost:${PORT}`));

