onAppReady(() => applyFilterStateToInputs(getFilterState()));
