onAppReady(() => renderHistory('historyBox'));
