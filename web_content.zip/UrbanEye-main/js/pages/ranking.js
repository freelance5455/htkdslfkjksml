onAppReady(() => window.UrbanRanking?.init());
