KS MOBILE REPAIR — MASTER PROJECT BUNDLE
========================================
यह एक ही ZIP में उपलब्ध संयुक्त प्रोजेक्ट पैकेज है। इसमें Android WebView source,
विस्तृत Shopping/Admin UI और Firebase online-backend starter शामिल हैं।

आपकी तय की हुई बातें:
- App/Shop: KS Mobile Repair; customer shopping: KS Shopping
- Blue + White + Orange professional design
- केवल ONLINE संचालन; Offline mode नहीं
- Admin और Staff access customer screen से private
- Admin में Repairing Parts का icon 🪛 और Cash का icon 💰
- Admin Chat में Customer/Staff नाम या User ID दिखे; मोबाइल नंबर Chat UI में न दिखे
- 5–6 banner photos, 1 second auto slider
- Staff की संख्या पर hard-coded सीमा नहीं
- Customer catalogue; online checkout/payment/delivery नहीं

फोल्डर:
01-Android-Project/       Android Studio WebView project source
02-Web-UI/                Shopping और Admin UI starter
03-Online-Backend-Starter/ Firebase/Firestore starter और Cloud Functions

महत्वपूर्ण स्थिति — अभी APK या production-ready app नहीं:
- यह source bundle है, install करने योग्य APK नहीं।
- Firebase project बनाकर config, Authentication, Firestore, Storage और rules
  को पूरा configure/deploy/test करना बाकी है।
- OTP/Google account linking, वास्तविक Chat, role permissions, secure admin/staff
  login, data saving, billing/stock/payroll calculations और reports का production
  integration बाकी है।
- Android Studio में build/sign और असली Android device पर testing जरूरी है।
- जब तक backend सुरक्षा और परीक्षण पूरा न हो, असली ग्राहक/दुकान का डेटा न डालें।

Android Studio: 01-Android-Project खोलें। Web UI preview के लिए
02-Web-UI/web/index.html खोलें। Backend starter की अलग README पढ़ें।
