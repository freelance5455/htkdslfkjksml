KS MOBILE REPAIR — ONLINE BACKEND STARTER
=========================================
यह Firebase आधारित Backend starter है, deployed/चलता हुआ server नहीं।

क्या शामिल है:
- Firestore security rules का शुरुआती role-based ढाँचा
- Public customer catalogue के लिए active products और banners read
- Admin-only product/banner writes
- Admin-only Cloud Function से Staff account बनाना
- Staff active/disable करने की Admin function
- Firestore collections का शुरुआती ढाँचा

जरूरी setup (किसी भरोसेमंद developer/अभिभावक की मदद से):
1. Firebase project बनाएं और Authentication में Email/Password तथा Google/Phone providers configure करें।
2. Firebase CLI से project initialize करें; .firebaserc.example को .firebaserc बनाकर अपना Project ID डालें।
3. Firestore Database और Storage को enable करें।
4. Admin UID को trusted Firebase Admin SDK environment से users/{uid} में role='admin', active=true दें। यह काम public app से कभी न करें।
5. Firestore Rules deploy और Cloud Functions deploy करें।
6. Android/Web app में Firebase config जोड़ें और सभी screens को वास्तविक Firestore/Auth calls से wire करें।
7. Security Rules को Emulator Suite में test करें और production security review कराएँ।

सुरक्षा नोट:
- Admin account या role client-side form से न बनाएं।
- Password, API secrets या service-account key APK/ZIP में न रखें।
- Rules इस starter का प्रारंभिक ढाँचा हैं; deploy करने से पहले पूरा review और tests जरूरी हैं।
- अभी OTP/Google customer login, image upload Storage rules, chat moderation, stock transaction atomicity,
  invoice PDF, payroll logic, reports और data migration implement नहीं हैं।
- इसमें कोई real customer/business data न डालें; यह production-ready नहीं है।
