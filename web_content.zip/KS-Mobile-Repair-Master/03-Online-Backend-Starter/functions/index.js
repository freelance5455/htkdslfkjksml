const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");
const { getAuth } = require("firebase-admin/auth");

initializeApp();
const db = getFirestore();

// Admin-only staff creation. Admin role must be assigned by trusted project owner
// using Firebase Admin SDK; never from a public client.
exports.createStaff = onCall(async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Login required");
  const caller = await db.doc(`users/${request.auth.uid}`).get();
  if (!caller.exists || caller.data().role !== "admin" || caller.data().active !== true) {
    throw new HttpsError("permission-denied", "Admin access required");
  }
  const { email, password, name, phone, salary } = request.data || {};
  if (!email || !password || !name || !phone) {
    throw new HttpsError("invalid-argument", "Name, phone, email and password required");
  }
  if (String(password).length < 10) {
    throw new HttpsError("invalid-argument", "Use a password of at least 10 characters");
  }
  const user = await getAuth().createUser({ email, password, displayName: name });
  await db.doc(`users/${user.uid}`).set({
    name, phone, email, role: "staff", active: true,
    createdAt: FieldValue.serverTimestamp(), createdBy: request.auth.uid
  });
  await db.doc(`staffPrivate/${user.uid}`).set({
    salary: Number(salary || 0), advances: 0, payments: [],
    leaveRecords: [], rating: null, notes: "", updatedAt: FieldValue.serverTimestamp()
  });
  return { uid: user.uid, message: "Staff account created" };
});

exports.setStaffActive = onCall(async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Login required");
  const caller = await db.doc(`users/${request.auth.uid}`).get();
  if (!caller.exists || caller.data().role !== "admin" || caller.data().active !== true) {
    throw new HttpsError("permission-denied", "Admin access required");
  }
  const { uid, active } = request.data || {};
  if (!uid || typeof active !== "boolean") throw new HttpsError("invalid-argument", "uid and active required");
  await db.doc(`users/${uid}`).update({ active, updatedAt: FieldValue.serverTimestamp() });
  return { ok: true };
});
