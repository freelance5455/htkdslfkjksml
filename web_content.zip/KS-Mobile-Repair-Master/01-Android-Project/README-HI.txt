KS MOBILE REPAIR — ANDROID PROJECT STARTER

यह Android WebView project है। इसमें पहले बनाया गया KS Mobile Repair + KS Shopping front-end assets शामिल है।

ध्यान दें:
- यह अभी APK नहीं है; source project है।
- Android Studio या GitHub Actions से debug APK build किया जा सकता है।
- GitHub Actions workflow .github/workflows/android-apk.yml में दिया है।
- इसे GitHub repository में upload/push करें; Actions tab में workflow run करें; सफल होने पर Artifacts से APK प्राप्त होगा।
- इस build में demo/local browser storage है। Login secure नहीं, OTP/Gmail auth, cloud database, live chat, multi-device sync और पूर्ण repairing/billing modules production-ready नहीं हैं।
- Debug APK सिर्फ परीक्षण के लिए है; Play Store के लिए signed release AAB, privacy policy, app signing, testing और Play Console प्रक्रिया अलग है।
- कृपया वास्तविक ग्राहक/स्टाफ का निजी डेटा इस demo में न डालें।

Mobile-only build outline:
1. GitHub पर नया repository बनाएं।
2. इस ZIP को extract करके इसकी सभी files repository में upload करें।
3. GitHub Actions tab खोलकर Build KS Mobile Repair APK workflow चलाएं।
4. Run पूरा होने पर workflow Artifacts से APK download करें।
