// State variables
let currentQuestions = [];
let currentIndex = 0;
let scoreCorrect = 0;
let scoreWrong = 0;
let timerInterval = null;
let timeLeft = 60;

const harakaLabels = {
    'رفض': { name: 'ضمة (رفع)', color: 'bg-emerald-100 text-emerald-800' },
    'نصب': { name: 'فتحة (نصب)', color: 'bg-blue-100 text-blue-800' },
    'جر': { name: 'كسرة (جر)', color: 'bg-amber-100 text-amber-800' },
    'سكون': { name: 'سكون', color: 'bg-purple-100 text-purple-800' }
};

function startSession() {
    // Shuffle and pick 20 words
    if (typeof ALL_WORDS === 'undefined' || ALL_WORDS.length === 0) {
        alert('لم يتم العثور على قاعدة البيانات للكلمات!');
        return;
    }
    
    const shuffled = [...ALL_WORDS].sort(() => 0.5 - Math.random());
    currentQuestions = shuffled.slice(0, 20);
    currentIndex = 0;
    scoreCorrect = 0;
    scoreWrong = 0;

    document.getElementById('screen-welcome').classList.add('hidden');
    document.getElementById('screen-results').classList.add('hidden');
    document.getElementById('screen-quiz').classList.remove('hidden');
    document.getElementById('session-badge').classList.remove('hidden');

    loadQuestion();
}

function loadQuestion() {
    if (currentIndex >= 20) {
        endSession();
        return;
    }

    // Update UI numbers
    document.getElementById('current-q-num').innerText = currentIndex + 1;
    const progressPercent = ((currentIndex + 1) / 20) * 100;
    document.getElementById('progress-bar').style.width = progressPercent + '%';

    const q = currentQuestions[currentIndex];
    document.getElementById('word-container').innerText = q.word;

    // Haraka badge
    const tag = document.getElementById('haraka-tag');
    const info = harakaLabels[q.type] || { name: q.type, color: 'bg-slate-100 text-slate-800' };
    tag.innerText = info.name;
    tag.className = `px-3 py-1 rounded-lg text-xs font-bold ${info.color}`;

    // Reset and start timer (60 seconds)
    clearInterval(timerInterval);
    timeLeft = 60;
    document.getElementById('timer-display').innerText = timeLeft;
    
    timerInterval = setInterval(() => {
        timeLeft--;
        document.getElementById('timer-display').innerText = timeLeft;
        if (timeLeft <= 0) {
            clearInterval(timerInterval);
            // Time out counted as wrong
            answerQuestion(false);
        }
    }, 1000);
}

function answerQuestion(isCorrect) {
    clearInterval(timerInterval);
    if (isCorrect) {
        scoreCorrect++;
    } else {
        scoreWrong++;
    }

    currentIndex++;
    loadQuestion();
}

function endSession() {
    clearInterval(timerInterval);
    document.getElementById('screen-quiz').classList.add('hidden');
    document.getElementById('session-badge').classList.add('hidden');
    document.getElementById('screen-results').classList.remove('hidden');

    document.getElementById('res-correct').innerText = scoreCorrect;
    document.getElementById('res-wrong').innerText = scoreWrong;
    
    const percentage = Math.round((scoreCorrect / 20) * 100);
    document.getElementById('res-percent').innerText = percentage + '%';

    let feedback = "محاولة ممتازة! واصل التدرب لتصبح بطل القراءة.";
    if (percentage >= 90) {
        feedback = "أداء رائع جداً! أنت عبقري في القراءة والتشكيل 🌟";
    } else if (percentage >= 75) {
        feedback = "أداء ممتاز ومتقن! استمر هكذا 👍";
    } else if (percentage >= 50) {
        feedback = "جيد جداً، يمكنك تحسين النتيجة بمزيد من التدريب 📚";
    }
    document.getElementById('res-feedback').innerText = feedback;
}

function restartSession() {
    document.getElementById('screen-results').classList.add('hidden');
    document.getElementById('screen-welcome').classList.remove('hidden');
}
