package com.astra.ai

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import java.io.File
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var transcript: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var status: TextView
    private var llm: LlmInference? = null
    private val worker = Executors.newSingleThreadExecutor()
    private val modelFileName = "astra_model.task"
    private val pickModelCode = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        addMessage("ASTRA", "Olá! Sou o ASTRA AI v0.2. Importe um modelo MediaPipe compatível (.task) para começar. A inferência acontece localmente neste aparelho.")
        refreshModelStatus()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(12))
            setBackgroundColor(Color.rgb(16, 17, 26))
        }
        val heading = TextView(this).apply {
            text = "✦ ASTRA AI  /  v0.2"
            textSize = 22f
            setTextColor(Color.rgb(225, 222, 255))
            setPadding(0, 0, 0, dp(4))
        }
        status = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.rgb(170, 172, 195))
            setPadding(0, 0, 0, dp(10))
        }
        val importButton = Button(this).apply {
            text = "Importar modelo .task"
            setOnClickListener { pickModel() }
        }
        scroll = ScrollView(this).apply { isFillViewport = true }
        transcript = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(10), 0, dp(10))
        }
        scroll.addView(transcript)
        val composer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        input = EditText(this).apply {
            hint = "Mensagem para o ASTRA…"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setSingleLine(false)
            minLines = 1
            maxLines = 4
            setBackgroundColor(Color.rgb(34, 35, 50))
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        val send = Button(this).apply {
            text = "Enviar"
            setOnClickListener { sendMessage() }
        }
        composer.addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        composer.addView(send)
        root.addView(heading)
        root.addView(status)
        root.addView(importButton)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(composer)
        setContentView(root)
    }

    private fun pickModel() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_TITLE, "Selecione um modelo MediaPipe .task")
        }
        startActivityForResult(intent, pickModelCode)
    }

    @Deprecated("Uses the platform document picker for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickModelCode || resultCode != Activity.RESULT_OK) return
        val uri: Uri = data?.data ?: return
        try {
            val destination = File(filesDir, modelFileName)
            contentResolver.openInputStream(uri).use { source ->
                requireNotNull(source) { "Não foi possível abrir o arquivo selecionado." }
                destination.outputStream().use { target -> source.copyTo(target) }
            }
            initializeModel(destination)
        } catch (e: Exception) {
            addMessage("ASTRA", "Falha ao importar o arquivo: ${e.localizedMessage ?: "erro desconhecido"}")
        }
    }

    private fun initializeModel(file: File) {
        status.text = "Carregando modelo local…"
        worker.execute {
            try {
                llm?.close()
                val options = LlmInference.LlmInferenceOptions.builder()
                    .setModelPath(file.absolutePath)
                    .setMaxTokens(512)
                    .build()
                val loaded = LlmInference.createFromOptions(this, options)
                runOnUiThread {
                    llm = loaded
                    status.text = "Modelo carregado · offline/local"
                    addMessage("ASTRA", "Modelo importado. Pode mandar sua mensagem!")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Modelo não carregado"
                    addMessage("ASTRA", "Não consegui carregar esse modelo. Use um .task compatível com MediaPipe LLM Inference e com a memória do aparelho. Detalhe: ${e.localizedMessage ?: "erro desconhecido"}")
                }
            }
        }
    }

    private fun sendMessage() {
        val prompt = input.text.toString().trim()
        if (prompt.isEmpty()) return
        input.setText("")
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(input.windowToken, 0)
        addMessage("Você", prompt)
        val engine = llm
        if (engine == null) {
            addMessage("ASTRA", "Importe primeiro um modelo .task compatível usando o botão acima.")
            return
        }
        status.text = "Pensando localmente…"
        worker.execute {
            try {
                val response = engine.generateResponse(prompt)
                runOnUiThread {
                    addMessage("ASTRA", response)
                    status.text = "Modelo carregado · offline/local"
                }
            } catch (e: Exception) {
                runOnUiThread {
                    addMessage("ASTRA", "Erro durante a geração: ${e.localizedMessage ?: "erro desconhecido"}")
                    status.text = "Erro de inferência"
                }
            }
        }
    }

    private fun refreshModelStatus() {
        val file = File(filesDir, modelFileName)
        status.text = if (file.exists()) "Modelo encontrado · toque em importar para carregar novamente" else "Sem modelo · importe um arquivo .task compatível"
    }

    private fun addMessage(sender: String, message: String) {
        val bubble = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(9), dp(12), dp(9))
            setBackgroundColor(if (sender == "Você") Color.rgb(47, 43, 78) else Color.rgb(31, 33, 47))
        }
        val label = TextView(this).apply {
            text = sender
            textSize = 12f
            setTextColor(Color.rgb(174, 164, 255))
        }
        val body = TextView(this).apply {
            text = message
            textSize = 15f
            setTextColor(Color.rgb(239, 239, 247))
            setPadding(0, dp(3), 0, 0)
        }
        bubble.addView(label)
        bubble.addView(body)
        val params = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) }
        transcript.addView(bubble, params)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        llm?.close()
        worker.shutdown()
        super.onDestroy()
    }
}
