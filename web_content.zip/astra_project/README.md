# ASTRA AI v0.2 — Android + MediaPipe (local)

Kotlin Android starter project for a local chat UI using MediaPipe LLM Inference. It has a document-picker button to import a `.task` model, copies it to app-private storage, and runs prompts through the local model. The manifest intentionally has **no `INTERNET` permission** and the app does not call a remote API.

## Build requirements
- Android Studio with JDK 17
- Android SDK Platform 35
- Gradle 8.9+ / Android Gradle Plugin 8.7.3 (Android Studio can configure the wrapper)
- A device/emulator meeting the selected model's requirements

## Build APK
Open this folder in Android Studio, let Gradle sync, then run `assembleDebug`. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Import a model
Launch ASTRA AI and tap **Importar modelo .task**. Select a model file that is specifically compatible with MediaPipe's Android LLM Inference task. The file is copied to private app storage as `astra_model.task`. A random `.task` file is not necessarily compatible; model architecture, quantization, memory requirements, and MediaPipe compatibility matter.

## Important limitations
- This ZIP contains the Android source project, **not** a model file and not a prebuilt APK.
- The project is a starter implementation; the Android build has not been executed in this environment. Dependency/API compatibility must be verified by Gradle sync/build in Android Studio.
- MediaPipe LLM Inference availability and API status can change; if the dependency/API is unavailable in your environment, the inference adapter may need migration to LiteRT-LM.
- The chat currently sends each message as a prompt; it does not yet assemble a persistent multi-turn conversation context.
- No internet permission is declared. Gradle still needs network access on the development computer to download dependencies during build.

## Interface HTML
O projeto inclui `index.html` na raiz e em `app/src/main/assets/index.html`. A página é uma interface web complementar; a inferência MediaPipe permanece na implementação Android/Kotlin. O HTML sozinho não executa inferência do modelo.
