
/* V17: resilient GST/item dropdowns; preserve selections after save/re-render. */
(function(){
  const $=id=>document.getElementById(id);
  const defaults=[0,5,12,18,28];
  function normalizedRates(){
    if(!Array.isArray(db.taxRates))db.taxRates=[];
    const seen=new Set();
    db.taxRates=db.taxRates.filter(x=>x&&Number.isFinite(Number(x.rate))&&Number(x.rate)>=0&&Number(x.rate)<=100&&!seen.has(Number(x.rate))&&seen.add(Number(x.rate)));
    if(!db.taxRates.some(x=>x.enabled)){
      defaults.forEach(rate=>{let x=db.taxRates.find(t=>Number(t.rate)===rate);if(x)x.enabled=true;else db.taxRates.push({id:Date.now()+rate,rate,enabled:true});});
    }
    return db.taxRates.filter(x=>x.enabled).sort((a,b)=>Number(a.rate)-Number(b.rate));
  }
  window.taxOptions=function(selected=18){
    const rates=normalizedRates();
    const wanted=Number(selected);
    if(!rates.some(x=>Number(x.rate)===wanted)){
      const all=db.taxRates.find(x=>Number(x.rate)===wanted);
      if(all){all.enabled=true;}
      else db.taxRates.push({id:Date.now()+Math.random(),rate:wanted,enabled:true});
    }
    return db.taxRates.filter(x=>x.enabled).sort((a,b)=>Number(a.rate)-Number(b.rate)).map(x=>'<option value="'+Number(x.rate)+'" '+(Number(x.rate)===wanted?'selected':'')+'>'+Number(x.rate)+'%</option>').join('');
  };
  const originalRenderAdvanced=window.renderAdvanced;
  if(typeof originalRenderAdvanced==='function')window.renderAdvanced=function(){
    const oldB=$('bGst')?.value,oldP=$('puGst')?.value,oldItems=['bItemSelect','puItemSelect','sItemSelect'].map(id=>$(id)?.value);
    const out=originalRenderAdvanced.apply(this,arguments);
    [['bGst',oldB],['puGst',oldP]].forEach(([id,val])=>{const e=$(id);if(!e)return;const wanted=val!==undefined&&val!==''?Number(val):18;e.innerHTML=window.taxOptions(wanted);if([...e.options].some(o=>Number(o.value)===wanted))e.value=String(wanted);});
    ['bItemSelect','puItemSelect','sItemSelect'].forEach((id,i)=>{const e=$(id),v=oldItems[i];if(e&&v&&[...e.options].some(o=>o.value===v))e.value=v;});
    const ei=$('ewInvoice');if(ei){const v=ei.value;ei.innerHTML='<option value="">Select invoice</option>'+db.bills.slice().reverse().map(x=>'<option value="'+x.id+'">'+String(x.no||'Invoice')+' • '+String(x.item||'')+'</option>').join('');if(v&&[...ei.options].some(o=>o.value===v))ei.value=v;}
    return out;
  };
  const originalAddTaxRate=window.addTaxRate;
  window.addTaxRate=function(){
    const el=$('newTaxRate'),raw=(el?.value||'').trim(),rate=Number(raw);
    if(raw===''||!Number.isFinite(rate)||rate<0||rate>100){alert('GST rate 0 se 100 ke beech valid number mein enter karein.');return;}
    const status=$('newTaxStatus')?.value==='1';let x=db.taxRates.find(t=>Number(t.rate)===rate);
    if(x)x.enabled=status;else db.taxRates.push({id:Date.now()+Math.random(),rate,enabled:status});
    if(!db.taxRates.some(t=>t.enabled))db.taxRates.find(t=>Number(t.rate)===rate).enabled=true;
    save();if(el)el.value='';
  };
  // Never let an empty GST menu survive startup or an older saved configuration.
  document.addEventListener('DOMContentLoaded',()=>{try{normalizedRates();window.renderAdvanced?.();window.previewSale?.();}catch(e){console.error('Billing dropdown initialization:',e);}});
  try{normalizedRates();}catch(e){console.error(e);}
})();
