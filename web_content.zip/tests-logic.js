// بيئة وهمية بسيطة لتشغيل منطق الألعاب بدون متصفح
const fakeEl=()=>({style:{},classList:{add(){},remove(){},toggle(){}},addEventListener(){},getContext:()=>new Proxy({},{get:(t,k)=>k in t?t[k]:(()=>({})),set:(t,k,v)=>(t[k]=v,true)}),getBoundingClientRect:()=>({left:0,top:0,width:480,height:480}),matches:()=>false,setAttribute(){},dataset:{},value:'',textContent:'',innerHTML:'',select(){},closest(){return null}});
const els={};global.document={getElementById:id=>els[id]||(els[id]=fakeEl()),addEventListener(){},querySelectorAll(){return []},visibilityState:'visible',hidden:false,createElement:()=>fakeEl()};
global.localStorage={getItem:()=>null,setItem(){}};global.window=global;
global.requestAnimationFrame=()=>0;global.cancelAnimationFrame=()=>{};global.setInterval=()=>0;global.setTimeout=()=>0;
global.navigator={};global.RTCPeerConnection=function(){};global.confirm=()=>true;global.performance={now:()=>0};
global.btoa=b=>Buffer.from(b,'binary').toString('base64');global.atob=s=>Buffer.from(s,'base64').toString('binary');
global.TextEncoder=require('util').TextEncoder;global.TextDecoder=require('util').TextDecoder;
const src=require('fs').readFileSync('/tmp/ph.js','utf8')+`
;globalThis.__T={Puzzle,Snake,TTT,Pong,Breakout,Target,codec,lineOf,solvedP,SN,CW,GAMES};`;
require('vm').runInThisContext(src);
const T=globalThis.__T; let fails=0; const ok=(c,m)=>{console.log((c?'PASS ':'FAIL ')+m); if(!c)fails++};
const ctxAll={active:[0,1,2],held:()=>false,anyHeld:()=>false,connected:()=>false,name:p=>'لاعب '+(p+1)};

// 1) Puzzle: scramble solvable & moves
for(let k=0;k<50;k++){const P=new T.Puzzle(); ok(P.t.slice().sort().join()==='0,1,2,3,4,5,6,7,8' && !T.solvedP(P.t),'puzzle scramble valid #'+k) ; if(k>2)break}
{const P=new T.Puzzle(); P.t=[1,2,3,4,5,6,7,0,8]; P.b=7; P.cur=8; P.input(0,'x',true); ok(P.t.join()==='1,2,3,4,5,6,7,8,0'&&P.over,'puzzle solves with one slide');}
{const P=new T.Puzzle(); P.t=[1,2,3,4,5,6,7,0,8]; P.b=7; P.cur=7; P.input(0,'right',true); ok(P.cur===8,'puzzle cursor moves'); P.input(0,'x',true); ok(P.moves===1 && P.t[7]===8 && P.t[8]===0,'puzzle slides tile into blank'); }

// 2) TTT
{const G=new T.TTT(); const seq=[[0,0],[1,3],[0,1],[1,4],[0,2]]; // X wins top row
 // place using cursor/explicit
 G.cur=[0,0]; G.place(0); G.place(3); G.place(1); G.place(4); G.place(2); ok(G.over&&G.win&&G.wins[0]===1,'TTT X wins top row');}
{const G=new T.TTT(); G.place(0); G.place(1); G.place(2); ok(!G.over && G.turn===1 && G.b[2]==='X','TTT alternates turns (X,O,X -> O)');}
{const G=new T.TTT(); G.input(1,'x',true); ok(G.b.every(v=>v===''),'TTT ignores non-turn player');}

// 3) Snake
{const G=new T.Snake(ctxAll); G.s[0].body=[[5,5],[4,5],[3,5]]; G.s[0].dir=[1,0]; G.s[0].next=[1,0]; G.food=[[6,5]]; G.step(); ok(G.s[0].score===10&&G.s[0].body.length===4,'snake eats food & grows');}
{const G=new T.Snake({active:[0]}); G.s[0].body=[[0,5],[1,5],[2,5]]; G.s[0].dir=[-1,0]; G.s[0].next=[-1,0]; G.step(); ok(!G.s[0].alive&&G.over,'snake dies on wall');}
{const G=new T.Snake({active:[0]}); G.s[0].next=[0,-1]; G.s[0].dir=[1,0]; G.input(0,'left',true); ok(G.s[0].next[0]===0 || G.s[0].next[0]===-1, 'snake reverse guard runs');}
{const G=new T.Snake({active:[0,1]}); G.s[0].body=[[5,5],[4,5],[3,5]];G.s[0].dir=[1,0];G.s[0].next=[1,0];G.s[1].body=[[9,10],[10,10],[11,10]];G.s[1].dir=[-1,0];G.s[1].next=[-1,0];G.food=[[20,0]];G.step(); ok(G.s[0].alive,'two snakes ok when not colliding');}
{const G=new T.Snake({active:[0,1]}); G.s[0].body=[[5,5],[4,5],[3,5]];G.s[0].dir=[1,0];G.s[0].next=[1,0];G.s[1].body=[[7,5],[8,5],[9,5]];G.s[1].dir=[-1,0];G.s[1].next=[-1,0];G.food=[[20,0]];G.step(); ok(!G.s[0].alive&&!G.s[1].alive,'head-on collision kills both');}

// 4) Pong scoring
{const G=new T.Pong(ctxAll); G.L=100; G.bx=5; G.by=240; G.vx=-200; G.vy=0; G.update(0.02); ok(G.rs===0 || G.ls===0 ,'pong ball handled (miss or hit)'); }
{const G=new T.Pong({...ctxAll,connected:()=>true}); G.L=400; G.bx=5; G.by=20; G.vx=-300; G.vy=0; G.update(0.1); ok(G.rs===1,'pong: missed paddle gives point to right');}

// 5) Breakout: brick destroyed, lives
{const G=new T.Breakout(); G.att=false; G.bx=100; G.by=60; G.vx=0; G.vy=-100; G.update(0.05); ok(G.pts>=0,'breakout updates without crash'); const before=G.bricks.filter(b=>b.on).length; G.bx=G.bricks[0].x+20; G.by=G.bricks[0].y+9; G.vx=0; G.vy=-50; G.update(0.001); ok(G.bricks.filter(b=>b.on).length<before,'breakout brick removed on hit');}
{const G=new T.Breakout(); G.att=false; G.bx=240; G.by=486; G.vx=0; G.vy=100; G.update(0.02); ok(G.lives===2&&G.att,'breakout lose life & re-park');}

// 6) Target hit
{const G=new T.Target(ctxAll); const t=G.tgt; G.cur[0]=t; G.input(0,'x',true); ok(G.pts[0]===1,'target: correct hit scores'); }
{const G=new T.Target(ctxAll); const wrong=(G.tgt+1)%9; G.cur[0]=wrong; G.input(0,'x',true); ok(G.pts[0]===0&&G.lock[0]>0,'target: wrong press locks');}
{const G=new T.Target(ctxAll); G.update(31); ok(G.over,'target ends after 30s');}

// 7) Code round-trip
{const o={t:'offer',sdp:'v=0\r\no=- 1 2 IN IP4 0.0.0.0\r\nأحمد'}; const e=T.codec.enc(o); ok(e.startsWith('PH1.')&&JSON.stringify(T.codec.dec(e))===JSON.stringify(o),'pairing code round-trip (UTF-8 safe)');}

// all games: draw runs without throwing
const fakeG=new Proxy({},{get:(t,k)=>k==='measureText'?()=>({width:1}):(typeof k==='string'&&['fillRect','clearRect','beginPath','arc','fill','stroke','moveTo','lineTo','strokeRect','fillText','roundRect','rect','setLineDash'].includes(k)?()=>{}:t[k]),set:(t,k,v)=>(t[k]=v,true)});
for(const [id,g] of Object.entries(T.GAMES)){ try{const I=new g.cls(ctxAll); for(let i=0;i<120;i++){I.update(1/60); I.draw(fakeG)} ok(true,'game runs 2s: '+id)}catch(e){ok(false,id+': '+e.message)} }
console.log(fails?`\n${fails} FAIL`:'\nALL OK');
