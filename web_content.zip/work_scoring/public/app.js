'use strict';
const socket = io();
let role = null, state = null;
const $ = id => document.getElementById(id);
const emit = action => socket.emit('action', action);
const roles = {J1:'Juri 1',J2:'Juri 2',J3:'Juri 3',IP:'Hakim (IP)',TD:'Technical Delegate'};
const criteria = [
  ['near_ko','Ancaman hampir KO (Aim to K.O.)'],
  ['aim_finish','Upaya penyelesaian / kuncian (Aim to Finish)'],
  ['damage','Dampak serangan (Damage)'],
  ['combinations','Kombinasi serangan efektif'],
  ['ground_control','Penguasaan bawah (Ground Control)'],
  ['takedowns','Bantingan (Takedown)'],
  ['effective_aggression','Agresivitas yang efektif']
];
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt = seconds => `${String(Math.floor(Math.max(0,seconds)/60)).padStart(2,'0')}:${String(Math.max(0,seconds)%60).padStart(2,'0')}`;

$('criteriaInputs').innerHTML = criteria.map(([key,label]) => `<div class="criterion"><b>${esc(label)}</b><select data-criterion="${key}"><option value="red">Merah lebih unggul</option><option value="blue">Biru lebih unggul</option><option value="even">Seimbang</option></select></div>`).join('');
$('loginBtn').addEventListener('click', () => {
  $('loginError').textContent = '';
  socket.emit('login',{username:$('username').value.trim(),pin:$('pin').value.trim()});
});
$('pin').addEventListener('keydown',e=>{if(e.key==='Enter')$('loginBtn').click()});
$('username').addEventListener('keydown',e=>{if(e.key==='Enter')$('pin').focus()});
socket.on('login-error', message => {$('loginError').textContent=message;$('pin').focus()});
socket.on('login-ok', data => {
  role=data.role;
  $('login').hidden=true; $('app').hidden=false;
  $('roleLabel').textContent=data.label.toUpperCase();
  $('panelTitle').innerHTML = `${esc(data.label.toUpperCase())} <span>• PANEL PERTANDINGAN</span>`;
  render();
});
socket.on('state', data => {state=data;render()});
socket.on('timer', timer => {if(state){state.timer=timer;$('timer').textContent=fmt(timer.remaining)}});
$('logout').addEventListener('click',()=>location.reload());
document.querySelectorAll('[data-action]').forEach(button=>button.addEventListener('click',()=>emit({type:button.dataset.action})));
$('submitCard').addEventListener('click',()=>{
  if(!state || state.decision.locked)return;
  const values={}; document.querySelectorAll('[data-criterion]').forEach(el=>values[el.dataset.criterion]=el.value);
  emit({type:'judge-card',criteria:values,verdict:$('judgeVerdict').value,note:$('judgeNote').value});
});
$('saveBout').addEventListener('click',()=>emit({type:'bout',data:{number:$('fNumber').value,category:$('fCategory').value,className:$('fClass').value,redName:$('fRed').value,redTeam:$('fRedTeam').value,blueName:$('fBlue').value,blueTeam:$('fBlueTeam').value,rounds:$('fRounds').value,roundSeconds:$('fRoundSeconds').value,restSeconds:$('fRestSeconds').value}}));
$('redWin').addEventListener('click',()=>decide('MERAH'));
$('blueWin').addEventListener('click',()=>decide('BIRU'));
$('draw').addEventListener('click',()=>decide('SERI / NO CONTEST'));
function decide(winner){if(confirm(`Tetapkan hasil pertandingan: ${winner}?`))emit({type:'decision',winner,method:$('method').value,note:$('decisionNote').value})}
$('unlock').addEventListener('click',()=>{if(confirm('Buka kembali kunci penilaian?'))emit({type:'unlock'})});
$('resetMatch').addEventListener('click',()=>{if(confirm('Reset seluruh nilai, kartu juri, dan timer pertandingan ini?'))emit({type:'reset-match'})});
function makeJudgeTable(){
 const labels=criteria.map(x=>x[1]);
 const rows=['J1','J2','J3'].map(key=>{const card=state.judgeCards?.[key];return `<tr><td>${roles[key]}</td>${criteria.map(([id])=>`<td>${card?({red:'MERAH',blue:'BIRU',even:'SEIMBANG'}[card.criteria?.[id]]||'—'):'MENUNGGU'}</td>`).join('')}<td>${card?esc(({red:'MERAH',blue:'BIRU',draw:'SERI'}[card.verdict]||card.verdict)):'—'}</td><td>${card?new Date(card.submittedAt).toLocaleTimeString('id-ID'):'—'}</td></tr>`}).join('');
 return `<div class="table-wrap"><table><thead><tr><th>JURI</th>${labels.map(x=>`<th>${esc(x)}</th>`).join('')}<th>KEPUTUSAN</th><th>UPDATE</th></tr></thead><tbody>${rows}</tbody></table></div>`;
}
function render(){
 if(!state||!role)return;
 const b=state.bout,t=state.timer||{};
 $('boutNo').textContent=b.number; $('classInfo').textContent=`${b.category} • ${b.className}`;
 $('roundInfo').textContent=`${b.round} / ${b.rounds}`; $('roundBig').textContent=`RONDE ${b.round} / ${b.rounds}`;
 $('statusInfo').textContent=b.status; $('redName').textContent=b.redName; $('redTeam').textContent=b.redTeam;
 $('blueName').textContent=b.blueName; $('blueTeam').textContent=b.blueTeam; $('timer').textContent=fmt(t.remaining||0);
 $('clockNote').textContent=t.running?'PERTANDINGAN BERJALAN':`TIMER DIKENDALIKAN ${role==='IP'?'HAKIM':'HAKIM (IP)'}`;
 const isJudge=['J1','J2','J3'].includes(role),isIP=role==='IP',isTD=role==='TD';
 $('judgePanel').hidden=!isJudge; $('ipPanel').hidden=!isIP; $('tdPanel').hidden=!isTD; $('timerControls').hidden=!isIP;
 if(isJudge){
   const card=state.judgeCards?.[role];
   if(card){document.querySelectorAll('[data-criterion]').forEach(el=>el.value=card.criteria?.[el.dataset.criterion]||'even');$('judgeVerdict').value=card.verdict||'draw';$('judgeNote').value=card.note||'';}
   $('judgeSubmitted').textContent=card?`Kartu terakhir tersimpan ${new Date(card.submittedAt).toLocaleString('id-ID')}. Anda dapat mengubah nilai dan mengirim ulang selama input belum dikunci.`:'Belum ada kartu penilaian. Isi seluruh kriteria lalu kirim.';
   $('submitCard').textContent=card?'SIMPAN PERUBAHAN NILAI':'KIRIM KARTU PENILAIAN';
   $('submitCard').disabled=!!state.decision.locked;
   document.querySelectorAll('[data-criterion],#judgeVerdict,#judgeNote').forEach(el=>el.disabled=!!state.decision.locked);
 }
 if(isIP){
   const fields={fNumber:b.number,fCategory:b.category,fClass:b.className,fRed:b.redName,fRedTeam:b.redTeam,fBlue:b.blueName,fBlueTeam:b.blueTeam,fRounds:b.rounds,fRoundSeconds:b.roundSeconds,fRestSeconds:b.restSeconds};
   Object.entries(fields).forEach(([id,value])=>{if(document.activeElement!==$(id))$(id).value=value});
   $('judgeTable').innerHTML=makeJudgeTable();
   $('redWin').disabled=$('blueWin').disabled=$('draw').disabled=!!state.decision.locked;
 }
 if(isTD)$('tdSummary').innerHTML=makeJudgeTable()+`<p class="muted">Hasil akhir: <b>${esc(state.decision.winner||'Belum ditetapkan')}</b> • ${esc(state.decision.method||'—')} • Status input: ${state.decision.locked?'DIKUNCI':'TERBUKA'}</p>`;
 const cards=['J1','J2','J3'].map(k=>({key:k,card:state.judgeCards?.[k]}));
 $('redScore').textContent=cards.filter(x=>x.card?.verdict==='red').length;
 $('blueScore').textContent=cards.filter(x=>x.card?.verdict==='blue').length;
 $('summaryTable').innerHTML=makeJudgeTable();
 $('lockState').textContent=state.decision.locked?'HASIL DIKUNCI':'INPUT TERBUKA';
 $('winnerBanner').hidden=!state.decision.locked;
 $('winnerBanner').textContent=state.decision.locked?`HASIL AKHIR: ${state.decision.winner} • ${state.decision.method||''}${state.decision.note?' • '+state.decision.note:''}`:'';
 $('history').innerHTML=(state.history||[]).slice(0,25).map(item=>`<div class="logrow"><span>${esc(item.text)}</span><time>${new Date(item.at).toLocaleTimeString('id-ID')}</time></div>`).join('');
}
