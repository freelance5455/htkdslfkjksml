# PORPROV VII BANTEN 2026 – IBCA MMA Digital Scoring

Aplikasi penilaian pertandingan berbasis web untuk lima akun petugas. Mendukung pembaruan data real-time ant perangkat melalui Socket.IO.

## Menjalankan aplikasi

**Persyaratan:** Node.js 18 atau lebih baru.

1. Ekstrak ZIP ke komputer yang akan menjadi server.
2. Pastikan komputer terhubung ke jaringan yang sama dengan perangkat petugas.
3. Buka terminal pada folder aplikasi, lalu jalankan:

   ```bash
   npm install
   npm start
   ```

4. Buka `http://localhost:3000` pada komputer server.
5. Perangkat lain pada Wi-Fi/LAN yang sama membuka `http://IP-KOMPUTER-SERVER:3000`.

File `public/index.html` adalah halaman HTML aplikasi. Untuk fungsi login, sinkronisasi real-time, dan penyimpanan bersama, aplikasi harus dijalankan melalui server Node.js; jangan membuka file HTML dengan klik ganda.

## Akun petugas

| Username | PIN | Hak akses |
|---|---:|---|
| Juri 1 | 101778 | Input dan ubah kartu penilaian Juri 1 |
| Juri 2 | 285935 | Input dan ubah kartu penilaian Juri 2 |
| Juri 3 | 306927 | Input dan ubah kartu penilaian Juri 3 |
| Hakim (IP) | 550513 | Identitas pertandingan, timer, rekap, keputusan, reset |
| TD | 736592 | Monitoring read-only |

Username tidak peka huruf besar/kecil. PIN dapat diubah melalui environment variable `PIN_J1`, `PIN_J2`, `PIN_J3`, `PIN_IP`, dan `PIN_TD`.

## Alur penggunaan

- Setiap petugas membuka alamat server yang sama lalu login dengan username dan PIN masing-masing.
- Juri memilih atlet yang lebih unggul pada tujuh kriteria, menentukan keputusan akhir, menambahkan catatan bila perlu, lalu mengirim kartu.
- Sebelum hasil dikunci, juri dapat mengubah nilai dan mengirim ulang kartu. Kartu terbaru menggantikan kartu sebelumnya.
- Hakim mengisi identitas pertandingan, mengatur jumlah ronde/durasi/istirahat, mengendalikan timer, memantau kartu, lalu menetapkan hasil.
- TD melihat rekap dan status tanpa fasilitas perubahan.

## Penyimpanan dan catatan

Data disimpan pada `data.json` di komputer server. Lakukan backup berkala. Untuk akses melalui internet, deploy ke hosting/VPS yang mendukung Node.js, WebSocket/Socket.IO, dan penyimpanan persisten; gunakan HTTPS serta pengamanan akses yang sesuai.

**Penting:** prototipe ini perlu diuji dan disesuaikan dengan Technical Handbook/peraturan pertandingan IBCA MMA Porprov yang disahkan sebelum digunakan dalam pertandingan resmi. Otoritas penilaian, kriteria, metode keputusan, durasi, dan prosedur koreksi harus disepakati panitia/Technical Delegate.
