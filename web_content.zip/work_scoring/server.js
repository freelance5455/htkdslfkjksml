const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const fs = require("fs");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;
const DATA = path.join(__dirname, "data.json");

const defaultState = {
  event: "PORPROV VII BANTEN 2026",
  sport: "IBCA MMA",
  bout: { number: "1", category: "Kelas Tanding", className: "—", round: 1, rounds: 3, roundSeconds: 180, restSeconds: 60, status: "READY", redName: "ATLET MERAH", redTeam: "PERGURUAN MERAH", redCity: "KABUPATEN / KOTA", blueName: "ATLET BIRU", blueTeam: "PERGURUAN BIRU", blueCity: "KABUPATEN / KOTA" },
  timer: { running: false, mode: "ROUND", remaining: 180, endsAt: null },
  scores: {
    J1: { red: 0, blue: 0, events: [] },
    J2: { red: 0, blue: 0, events: [] },
    J3: { red: 0, blue: 0, events: [] }
  },
  penalties: [],
  judgeCards: { J1: null, J2: null, J3: null },
  decision: { winner: null, method: null, note: "", locked: false },
  history: [{ at: new Date().toISOString(), text: "Sistem siap digunakan." }]
};
let state;
try { state = JSON.parse(fs.readFileSync(DATA, "utf8")); } catch { state = defaultState; }

const roles = {
  J1: { username: "Juri 1", pin: process.env.PIN_J1 || "101778", label: "Juri 1" },
  J2: { username: "Juri 2", pin: process.env.PIN_J2 || "285935", label: "Juri 2" },
  J3: { username: "Juri 3", pin: process.env.PIN_J3 || "306927", label: "Juri 3" },
  IP: { username: "Hakim (IP)", pin: process.env.PIN_IP || "550513", label: "Hakim (IP)" },
  TD: { username: "TD", pin: process.env.PIN_TD || "736592", label: "Technical Delegate" }
};
function save() { fs.writeFileSync(DATA, JSON.stringify(state, null, 2)); }
function log(text) {
  state.history.unshift({ at: new Date().toISOString(), text });
  state.history = state.history.slice(0, 80);
}
function publish() { save(); io.emit("state", state); }
function auth(socket, role) { return socket.data.role === role; }
function judge(role) { return ["J1","J2","J3"].includes(role); }
function remaining() {
  if (!state.timer.running || !state.timer.endsAt) return state.timer.remaining;
  return Math.max(0, Math.ceil((state.timer.endsAt - Date.now()) / 1000));
}
setInterval(() => {
  if (state.timer.running) {
    state.timer.remaining = remaining();
    if (state.timer.remaining <= 0) {
      state.timer.running = false;
      state.timer.endsAt = null;
      state.bout.status = "TIME UP";
      log("Waktu ronde berakhir.");
      publish();
    } else io.emit("timer", state.timer);
  }
}, 250);

app.use(express.static(path.join(__dirname, "public")));
app.get("/health", (_, res) => res.json({ ok: true, app: "PORPROV IBCA MMA Scoring" }));

io.on("connection", socket => {
  socket.emit("state", state);
  socket.on("login", ({ username, pin }) => {
    const role = Object.keys(roles).find(k => roles[k].username.toLowerCase() === String(username || "").trim().toLowerCase());
    if (!role || roles[role].pin !== String(pin)) return socket.emit("login-error", "Username atau PIN tidak sesuai.");
    socket.data.role = role;
    socket.emit("login-ok", { role, label: roles[role].label });
    socket.emit("state", state);
  });
  socket.on("action", (a = {}) => {
    const role = socket.data.role;
    if (!role) return;
    if (a.type === "judge-card" && judge(role) && !state.decision.locked) {
      const allowed = ["near_ko","aim_finish","damage","combinations","ground_control","takedowns","effective_aggression"];
      const card = {};
      allowed.forEach(k => { card[k] = ["red","blue","even"].includes(a.criteria && a.criteria[k]) ? a.criteria[k] : "even"; });
      const verdict = ["red","blue","draw"].includes(a.verdict) ? a.verdict : "draw";
      state.judgeCards[role] = { criteria: card, verdict, note: String(a.note || "").slice(0,250), submittedAt: new Date().toISOString() };
      log(`${roles[role].label} mengirim kartu penilaian dan keputusan independen.`);
      publish();
    }
    if (a.type === "score" && judge(role) && !state.decision.locked) {
      const side = a.side === "blue" ? "blue" : "red";
      const points = Math.max(-10, Math.min(10, Number(a.points) || 0));
      state.scores[role][side] += points;
      state.scores[role].events.push({ at: new Date().toISOString(), side, points, label: String(a.label || "Penilaian").slice(0,50), round: state.bout.round });
      log(`${roles[role].label}: ${side === "red" ? "Merah" : "Biru"} ${points > 0 ? "+" : ""}${points} (${a.label || "Penilaian"}).`);
      publish();
    }
    if (a.type === "undo" && judge(role) && !state.decision.locked) {
      const ev = state.scores[role].events.pop();
      if (ev) { state.scores[role][ev.side] -= ev.points; log(`${roles[role].label} membatalkan penilaian terakhir.`); publish(); }
    }
    if (role === "IP") {
      if (a.type === "bout") {
        const fields = ["number","category","className","redName","redTeam","redCity","blueName","blueTeam","blueCity"];
        fields.forEach(k => { if (a.data && a.data[k] !== undefined) state.bout[k] = String(a.data[k]).slice(0,100); });
        if (a.data && Number(a.data.roundSeconds) > 0) state.bout.roundSeconds = Math.min(600, Math.max(30, Number(a.data.roundSeconds)));
        if (a.data && Number(a.data.restSeconds) >= 0) state.bout.restSeconds = Math.min(300, Math.max(0, Number(a.data.restSeconds)));
        if (a.data && Number(a.data.rounds) > 0) state.bout.rounds = Math.min(5, Math.max(1, Number(a.data.rounds)));
        state.timer.remaining = state.bout.roundSeconds;
        log("Hakim memperbarui identitas dan konfigurasi durasi pertandingan."); publish();
      }
      if (a.type === "timer-start" && !state.timer.running) {
        if (state.timer.remaining <= 0) state.timer.remaining = state.bout.roundSeconds;
        state.timer.running = true; state.timer.endsAt = Date.now() + state.timer.remaining * 1000;
        state.bout.status = "RUNNING"; log("Timer dijalankan oleh Hakim."); publish();
      }
      if (a.type === "timer-pause") {
        state.timer.remaining = remaining(); state.timer.running = false; state.timer.endsAt = null;
        state.bout.status = "PAUSED"; log("Timer dijeda oleh Hakim."); publish();
      }
      if (a.type === "timer-reset") {
        state.timer.running = false; state.timer.endsAt = null; state.timer.remaining = state.bout.roundSeconds;
        state.bout.status = "READY"; log("Timer direset."); publish();
      }
      if (a.type === "next-round") {
        state.timer.running = false; state.timer.endsAt = null;
        state.bout.round = Math.min(state.bout.rounds, state.bout.round + 1);
        state.timer.remaining = state.bout.roundSeconds; state.bout.status = "READY";
        log(`Masuk ronde ${state.bout.round}.`); publish();
      }
      if (a.type === "penalty") {
        const side = a.side === "blue" ? "blue" : "red";
        const points = Math.max(0, Math.min(10, Number(a.points) || 0));
        state.penalties.push({ side, points, label: String(a.label || "Pengurangan").slice(0,50), at: new Date().toISOString() });
        log(`Hakim mencatat pengurangan ${points} poin untuk ${side}.`); publish();
      }
      if (a.type === "decision") {
        state.decision = { winner: a.winner || null, method: String(a.method || "Keputusan Juri"), note: String(a.note || "").slice(0,200), locked: true };
        state.timer.running = false; state.timer.endsAt = null; state.bout.status = "SELESAI";
        log(`Hasil ditetapkan: ${state.decision.winner || "BELUM DITENTUKAN"}.`); publish();
      }
      if (a.type === "unlock") {
        state.decision.locked = false; state.decision.winner = null; state.decision.method = null;
        state.bout.status = "READY"; log("Hakim membuka kembali input nilai."); publish();
      }
      if (a.type === "reset-match") {
        state.scores = { J1:{red:0,blue:0,events:[]}, J2:{red:0,blue:0,events:[]}, J3:{red:0,blue:0,events:[]} };
        state.penalties = []; state.judgeCards = { J1:null, J2:null, J3:null }; state.decision = { winner:null, method:null, note:"", locked:false };
        state.timer = { running:false, mode:"ROUND", remaining:state.bout.roundSeconds, endsAt:null };
        state.bout.round = 1; state.bout.status = "READY";
        log("Pertandingan direset oleh Hakim."); publish();
      }
    }
  });
});
server.listen(PORT, "0.0.0.0", () => console.log(`IBCA MMA scoring running on ${PORT}`));
