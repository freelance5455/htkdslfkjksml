GAME KERETA API - PROYEK ANDROID

ZIP ini berisi proyek sumber Android Studio dan game HTML offline.
APK belum dikompilasi di sini.

MEMBUAT APK:
1. Instal Android Studio di komputer.
2. Ekstrak ZIP, lalu buka folder GameKeretaApiAndroid di Android Studio.
3. Tunggu Gradle Sync dan pasang Android SDK yang diminta.
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug biasanya ada di app/build/outputs/apk/debug/app-debug.apk.
6. Pindahkan APK ke HP Android dan izinkan pemasangan dari sumber tersebut
   bila Android meminta izin.

Game dapat dimainkan offline dan tidak meminta izin internet.
