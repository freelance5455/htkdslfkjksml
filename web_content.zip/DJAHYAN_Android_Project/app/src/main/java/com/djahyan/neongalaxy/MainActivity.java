package com.djahyan.neongalaxy;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class MainActivity extends Activity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(1024,1024);
        WebView w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        w.setOverScrollMode(View.OVER_SCROLL_NEVER);
        w.setBackgroundColor(0xFF02030B);
        setContentView(w);
        w.loadUrl("file:///android_asset/game.html");
    }
    @Override public void onBackPressed() { }
}
