DJAHYAN — Neon Galaxy Pro
Pwojè Android lokal pou jwèt la.

Baz jwèt la: V2.2 fourni pa itilizatè a.
Non app la: DJAHYAN
Package: com.djahyan.neongalaxy

Pou konstwi APK nan Android Studio:
Build > Build APK(s)
APK debug: app/build/outputs/apk/debug/app-debug.apk
