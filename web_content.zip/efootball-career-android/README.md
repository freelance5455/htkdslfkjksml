# eFootball Career Android project

This Android Studio project wraps the existing eFootball Career web app in a landscape Android WebView.

## Build an APK on Windows
1. Install Android Studio from https://developer.android.com/studio
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the extracted `efootball-career-android` folder.
4. Allow Android Studio to install/sync the required Gradle and Android SDK components.
5. From the menu choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. When finished, click **locate** in the notification. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfer that APK to your Android phone and open it to install. If Android asks, allow installation from that source.

This is a buildable project source, not a precompiled APK. It requires Android Studio/Android SDK to compile. The app features are limited to the current web-app build; it does not add missing career features.
