# eFootball Carrer Android project

This is an Android Studio/Gradle project source package, NOT a compiled APK. It bundles all local assets, including the required `data.js` file. The WebView entry point is `file:///android_asset/index.html` and JavaScript/local storage are enabled.

To compile it, use Android Studio with Android SDK and Gradle installed, open this folder as a project, wait for Gradle sync, then Build > Build APK(s). The resulting APK is created by the Android build system; this archive itself cannot be installed.
