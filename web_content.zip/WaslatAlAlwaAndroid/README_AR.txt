مشروع تطبيق وصولات العلوة للأندرويد

مهم:
- هذا مشروع Android Studio، وليس ملف APK مبنياً بعد.
- يحتوي نسخة HTML المعدلة التي حُذفت منها عبارتا اسم المكتب والعلامة المائية.
- التخزين الحالي في HTML يعتمد على localStorage داخل الجهاز. هذا المشروع لا يربطه تلقائياً بـ Supabase ولا يضيف مزامنة سحابية.

طريقة استخراج APK:
1) ثبّت Android Studio على الكمبيوتر.
2) فك ضغط هذا الملف.
3) من Android Studio اختر Open وافتح مجلد WaslatAlAlwaAndroid.
4) انتظر Gradle Sync واكتمال تنزيل مكونات Android المطلوبة.
5) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
6) بعد نجاح البناء يظهر خيار Locate للوصول إلى app-debug.apk.

اسم التطبيق: وصولات العلوة
معرّف التطبيق: com.waslat.alalwa
أقل إصدار أندرويد: Android 6.0 (API 23)
