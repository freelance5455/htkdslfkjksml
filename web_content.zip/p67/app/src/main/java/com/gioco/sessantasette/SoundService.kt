package com.gioco.sessantasette

import android.app.*
import android.content.Intent
import android.media.MediaPlayer
import android.net.wifi.WifiManager
import android.os.*
import okhttp3.*
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class SoundService : Service() {
  private val client = OkHttpClient.Builder().pingInterval(10, TimeUnit.SECONDS).build()
  private val h = Handler(Looper.getMainLooper())
  private var mp: MediaPlayer? = null
  private var ws: WebSocket? = null
  private var room: String? = null
  private var alive = true
  private var lock: WifiManager.WifiLock? = null
  private val sounds = intArrayOf(R.raw.suono1, R.raw.suono2, R.raw.suono3, R.raw.suono4, R.raw.suono5)

  override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
    val r = i?.getStringExtra("room")
    if (r != null) room = r
    getSystemService(NotificationManager::class.java).createNotificationChannel(
      NotificationChannel("g", "67", NotificationManager.IMPORTANCE_LOW))
    startForeground(1, Notification.Builder(this, "g")
      .setContentTitle("67").setContentText("Collegato alla stanza " + (room ?: ""))
      .setSmallIcon(android.R.drawable.ic_media_play).build())
    if (room == null) { stopSelf(); return START_NOT_STICKY }
    @Suppress("DEPRECATION")
    lock = (applicationContext.getSystemService(WIFI_SERVICE) as WifiManager)
      .createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "67").apply { acquire() }
    alive = true
    connect()
    return START_STICKY
  }

  private fun connect() {
    if (!alive) return
    ws?.cancel()
    ws = client.newWebSocket(Request.Builder().url(Config.SERVER).build(),
      object : WebSocketListener() {
        override fun onOpen(w: WebSocket, r: Response) {
          w.send(JSONObject().put("t", "join").put("room", room).toString())
        }
        override fun onMessage(w: WebSocket, t: String) {
          val d = JSONObject(t)
          when (d.getString("t")) {
            "play" -> h.post {
              mp?.release(); mp = null
              val n = d.getInt("n")
              if (n in 0..4) mp = MediaPlayer.create(this@SoundService, sounds[n])?.apply { start() }
            }
            "err", "closed" -> { alive = false; stopSelf() }
          }
        }
        override fun onFailure(w: WebSocket, e: Throwable, r: Response?) { retry() }
        override fun onClosed(w: WebSocket, c: Int, r: String) { retry() }
      })
  }

  private fun retry() { if (alive) h.postDelayed({ connect() }, 3000) }

  override fun onDestroy() {
    alive = false
    ws?.cancel(); mp?.release(); lock?.release()
    super.onDestroy()
  }
  override fun onBind(i: Intent?): IBinder? = null
}
