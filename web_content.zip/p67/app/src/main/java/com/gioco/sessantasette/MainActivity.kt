package com.gioco.sessantasette

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*
import okhttp3.*
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
  private val client = OkHttpClient.Builder().pingInterval(10, TimeUnit.SECONDS).build()
  private var ws: WebSocket? = null
  private var counter: TextView? = null
  private lateinit var root: LinearLayout

  override fun onCreate(b: Bundle?) {
    super.onCreate(b)
    if (Build.VERSION.SDK_INT >= 33)
      requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    root = LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL
      setPadding(40, 100, 40, 40)
    }
    setContentView(ScrollView(this).apply { addView(root) })
    home()
  }

  private fun btn(t: String, f: () -> Unit) = Button(this).apply {
    text = t; textSize = 20f; setOnClickListener { f() }
  }
  private fun txt(t: String, s: Float = 18f) = TextView(this).apply {
    text = t; textSize = s; gravity = Gravity.CENTER; setPadding(0, 20, 0, 20)
  }
  private fun screen(vararg v: View) { root.removeAllViews(); v.forEach { root.addView(it) } }

  private fun home() {
    ws?.close(1000, null); ws = null
    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    screen(txt("67", 72f), btn("Crea stanza") { ask(true) },
      btn("Entra in una stanza") { ask(false) })
  }

  private fun ask(host: Boolean) {
    val e = EditText(this).apply {
      hint = "Nome stanza"; textSize = 22f; inputType = InputType.TYPE_CLASS_TEXT
    }
    val m = txt("")
    screen(txt(if (host) "Scegli il nome della stanza" else "Nome della stanza", 22f), e,
      btn("Avanti") {
        val name = e.text.toString().trim()
        if (name.isEmpty()) m.text = "Scrivi un nome" else connect(host, name, m)
      }, m, btn("Indietro") { home() })
  }

  private fun connect(host: Boolean, name: String, m: TextView) {
    m.text = "Collegamento..."
    ws = client.newWebSocket(Request.Builder().url(Config.SERVER).build(),
      object : WebSocketListener() {
        override fun onOpen(w: WebSocket, r: Response) {
          w.send(JSONObject().put("t", if (host) "create" else "join").put("room", name).toString())
        }
        override fun onMessage(w: WebSocket, text: String) {
          val d = JSONObject(text)
          runOnUiThread {
            when (d.getString("t")) {
              "err" -> { m.text = d.getString("msg"); w.close(1000, null) }
              "count" -> counter?.text = "Giocatori: " + d.getInt("n")
              "ok" -> if (host) panel(w, name) else {
                w.close(1000, null)
                startForegroundService(Intent(this@MainActivity, SoundService::class.java)
                  .putExtra("room", name))
                joined(name)
              }
            }
          }
        }
        override fun onFailure(w: WebSocket, t: Throwable, r: Response?) {
          runOnUiThread { m.text = "Impossibile collegarsi. Sei sulla rete giusta?" }
        }
      })
  }

  private fun panel(w: WebSocket, name: String) {
    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    counter = txt("Giocatori: 0")
    val v = mutableListOf<View>(txt("Stanza: $name", 26f), counter!!)
    for (i in 1..5) v.add(btn("Suono $i") {
      w.send(JSONObject().put("t", "play").put("n", i - 1).toString())
    })
    v.add(btn("Stop") { w.send(JSONObject().put("t", "play").put("n", -1).toString()) })
    v.add(btn("Chiudi stanza") { home() })
    screen(*v.toTypedArray())
  }

  private fun joined(name: String) {
    screen(txt("Sei nella stanza $name", 24f),
      txt("Puoi chiudere l'app: i suoni arrivano lo stesso."),
      btn("Esci") { stopService(Intent(this, SoundService::class.java)); home() })
  }
}
