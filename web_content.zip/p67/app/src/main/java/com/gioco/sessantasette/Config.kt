package com.gioco.sessantasette

object Config {
  // Metti qui l'indirizzo che ti da' Render, con wss:// davanti e senza / finale
  const val SERVER = "wss://CAMBIA-MI.onrender.com"
}
