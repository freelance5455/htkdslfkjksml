const express = require('express'), http = require('http'), WebSocket = require('ws');
const app = express(); app.use(express.static('public'));
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });
const rooms = {};
const send = (c, o) => { if (c && c.readyState === 1) c.send(JSON.stringify(o)); };
const count = r => send(r.host, { t: 'count', n: r.members.size });
wss.on('connection', ws => {
  ws.on('message', m => {
    let d; try { d = JSON.parse(m); } catch { return; }
    const k = String(d.room || '').toLowerCase();
    if (d.t === 'create') {
      if (rooms[k]) return send(ws, { t: 'err', msg: 'Nome già usato' });
      rooms[k] = { host: ws, members: new Set() }; ws.room = k; ws.role = 'host';
      send(ws, { t: 'ok' });
    } else if (d.t === 'join') {
      const r = rooms[k];
      if (!r) return send(ws, { t: 'err', msg: 'Stanza non trovata' });
      r.members.add(ws); ws.room = k; ws.role = 'guest';
      send(ws, { t: 'ok' }); count(r);
    } else if (d.t === 'play' && ws.role === 'host') {
      rooms[ws.room].members.forEach(c => send(c, { t: 'play', n: d.n }));
    }
  });
  ws.on('close', () => {
    const r = rooms[ws.room]; if (!r) return;
    if (ws.role === 'host') { r.members.forEach(c => send(c, { t: 'closed' })); delete rooms[ws.room]; }
    else { r.members.delete(ws); count(r); }
  });
});
server.listen(process.env.PORT || 3000, '0.0.0.0');
