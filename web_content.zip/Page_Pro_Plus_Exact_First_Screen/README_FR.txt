PAGE PRO+ — ÉCRAN D’ACCUEIL EXACT

Cette version utilise la capture fournie comme fond de l’écran d’accueil afin que l’apparence soit la plus fidèle possible à la capture.

Fichiers:
- index.html : application HTML
- reference-screen.png : capture de référence utilisée pour l’écran
- page-pro-logo.jpg : logo fourni

Pour convertir en APK avec votre outil HTML → APK : utilisez index.html comme page d’entrée et gardez reference-screen.png dans le même dossier.

Le champ mot de passe possède un bouton invisible au-dessus de l’œil pour afficher/masquer le mot de passe.
