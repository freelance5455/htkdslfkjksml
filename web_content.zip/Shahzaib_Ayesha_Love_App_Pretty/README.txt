Shahzaib Ayesha Love App
- Upload this COMPLETE ZIP to an HTML/ZIP-to-APK converter.
- Keep index.html and the assets folder together.
- Includes your couple photo, Shahzaib portrait (if available), Islamabad artwork (if available), Urdu love poetry, dua and interactive surprise button.
- The app contains no engagement/mangni references.
- Urdu font uses Noto Nastaliq Urdu/Amiri when internet is available; fallback fonts are included.
