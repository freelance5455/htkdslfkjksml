--[[
    Vortex Key System Module (VORTEX_SCRIPTS_KEY)
    Integrated with Vortex Script Studio
]]

local KeySystem = {}
KeySystem.Key = "Vortex_Secret_Key_2026"

function KeySystem:Verify(inputKey)
    return inputKey == self.Key
end

return KeySystem
