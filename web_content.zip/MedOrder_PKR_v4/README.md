# MedOrder PKR v4

Offline-first HTML/PWA medical-store order taker, catalog and invoice maker.

## Included
- Product catalog with categories
- Product photos and selection feedback
- Product discount percentages and net pricing
- Order-level percentage and fixed discounts
- PKR invoices
- Real PDF download using the built-in PDF generator
- Print invoice
- Customer/store records and order history
- Backup/restore with clear file-selection status
- Local-first storage
- Google Drive automatic-backup-ready integration

## Google Drive
The app keeps local data as the primary copy. v4 includes a Google Drive OAuth/Drive API integration path. Enter your own Google OAuth Client ID in Settings and use Connect Google Drive. Automatic backup can then upload `MedOrder-PKR-AutoBackup.json` when online.

For a final Android APK, configure OAuth according to the Android wrapper (Capacitor/native WebView) and do not place a Google client secret in the HTML. The Google Drive API is never required for normal offline operation.

## Run
Serve this folder from a local web server for full PWA behavior. Opening the HTML directly is useful for basic UI testing, but service-worker and OAuth behavior may require a secure/local web origin.
