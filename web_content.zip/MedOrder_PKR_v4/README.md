# MedOrder PKR v5 — repaired PWA source

This ZIP is the web-app source (HTML/CSS/JavaScript + PWA service worker), **not an Android APK project**. It can be hosted on HTTPS and installed from Chrome using **Add to Home screen / Install app**.

## Repairs in v5
- Fixed order preview so percentage and fixed discounts match the final invoice calculation.
- Improved file download handling for invoices and JSON backups (visible browser download action; check the Android Downloads folder).
- Made PDF text ASCII-safe so PDF byte offsets and document structure remain valid even when business/customer/product names contain Urdu or other non-ASCII characters. Non-ASCII characters are transliterated/replaced in this basic PDF generator.
- Added a storage-save error message when local browser storage is full or unavailable.
- Bumped the service-worker cache version so Chrome does not keep using the older cached files.

## Important Android / download limitation
A web app packaged inside an arbitrary WebView APK cannot reliably save to Android shared storage unless the Android wrapper implements downloads (Android DownloadManager or the Storage Access Framework) and grants the appropriate handling. This ZIP does not contain the Android Studio/Capacitor wrapper, Gradle project, signing configuration, or APK build files. Therefore this source repair alone cannot rebuild or patch the installed APK.

For reliable local PDF saving in a native APK, the Android wrapper must expose a download/share bridge or handle WebView download requests. Until then, run the app from HTTPS in Chrome or use the Android share sheet when available.

## Google Drive backup
Google Drive is separate from Google Chrome backup. The app's Drive integration requires a valid Google Cloud OAuth Web client ID, enabled Google Drive API, authorized HTTPS origin, and consent-screen setup. A packaged Android app normally needs Android OAuth configuration/package name/SHA-1 or a native Google sign-in implementation; entering a Web client ID alone does not configure an APK. Automatic backups from a web page are best-effort while the app is open/online; Android background scheduling requires native WorkManager integration.

## First run
1. Host this folder on an HTTPS website.
2. Open the website in Chrome on Android.
3. Use Chrome menu → **Install app** or **Add to Home screen**.
4. Set your business name, phone and address; remove demo products/customers and add your own.
5. Test one invoice and one JSON backup before entering real business data.

## Data safety
Data is stored in that browser/app's local storage. Clearing app data, uninstalling the APK, or some WebView updates may erase it. Export a JSON backup regularly and keep a second copy in Google Drive or another storage provider. Do not rely on a single device copy.
