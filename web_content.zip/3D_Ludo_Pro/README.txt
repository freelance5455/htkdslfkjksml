3D Ludo Pro — Android phone starter project

Files:
- index.html: Three.js 3D Ludo prototype

Run:
1. Extract the ZIP on your Android phone.
2. Open index.html with an editor such as Acode.
3. Use its Preview/Run feature if available. Internet is required because Three.js loads from a CDN.
4. For more reliable testing, upload index.html to a static host such as GitHub Pages or Netlify, then open that URL in Chrome.

APK:
This ZIP is a web game, not an APK. To make an APK, package the hosted web app with a trusted WebView/PWA-to-APK service or a mobile Android IDE that supports WebView projects. Test permissions, offline behavior, and the APK before installing. Never upload private keys or account passwords to third-party builders.

Prototype notes:
This is a playable visual prototype, not a fully rules-complete commercial Ludo game. The path, home lanes, safe squares, exact win rules, sound, and robust CPU strategy need refinement before publishing.
