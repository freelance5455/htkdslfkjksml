const V="mgrs-v9",SHELL=["./","./index.html","./manifest.json","./icon.svg"];
const LJ="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js",LC="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css";
const ALT={};ALT[LJ]=["https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.js","https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"];ALT[LC]=["https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.css","https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"];
async function grab(c,key){const tries=[key].concat(ALT[key]||[]);for(const u of tries){try{const r=await fetch(u,{mode:"cors"});if(r&&r.ok){await c.put(key,r);return true}}catch(e){}}return false}
self.addEventListener("install",e=>{e.waitUntil((async()=>{const c=await caches.open(V);await Promise.all(SHELL.map(u=>c.add(u).catch(()=>{})));await grab(c,LJ);await grab(c,LC);await self.skipWaiting()})())});
self.addEventListener("activate",e=>{e.waitUntil((async()=>{for(const k of await caches.keys())if(k!==V)await caches.delete(k);await self.clients.claim()})())});
self.addEventListener("fetch",e=>{const r=e.request;if(r.method!=="GET")return;const u=new URL(r.url);
 if(r.mode==="navigate"){e.respondWith((async()=>{const c=await caches.open(V),m=(await c.match("./index.html"))||(await c.match("./")),net=fetch(r).then(n=>{if(n&&n.ok)c.put("./index.html",n.clone()).catch(()=>{});return n}).catch(()=>null);
  if(!m){const n=await net;return n||Response.error()}
  const n=await Promise.race([net,new Promise(res=>setTimeout(()=>res(null),3500))]);e.waitUntil(net);return n&&n.ok?n:m})());return}
 if(u.origin===location.origin||r.url===LJ||r.url===LC){e.respondWith((async()=>{const c=await caches.open(V),m=await c.match(r,{ignoreSearch:true});if(m)return m;try{const n=await fetch(r);if(n&&n.ok)c.put(r,n.clone()).catch(()=>{});return n}catch(err){return Response.error()}})())}});
