MGRS Global Explorer V3 Pro - حزمة PWA
=====================================
الملفات: index.html  sw.js  manifest.json  icon.svg

التشغيل (مهم):
1) لا تفتح index.html من معاينة تطبيق Claude ولا مباشرة من الملفات؛ المعاينة تحجب صور الخرائط.
2) ارفع المجلد كاملاً على استضافة HTTPS مجانية:
   - Netlify Drop: https://app.netlify.com/drop  (اسحب المجلد)
   - أو GitHub Pages
3) افتح الرابط في Safari/Chrome. من القائمة: "إضافة إلى الشاشة الرئيسية".
4) للعمل دون اتصال: قرّب الخريطة على المنطقة ثم زر "حفظ المنطقة دون اتصال".

GPS يحتاج HTTPS وإذن الموقع.
