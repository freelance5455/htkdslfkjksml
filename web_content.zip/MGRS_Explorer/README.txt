MGRS Global Explorer V3 Pro
===========================
الملفات: index.html (التطبيق كاملاً في ملف واحد) + sw.js + manifest.json + icon.svg (اختيارية لـ PWA)

التشغيل:
1) ارفع المجلد على استضافة HTTPS (Netlify Drop / GitHub Pages) وافتحه في Safari/Chrome.
   لا تفتحه من معاينة Claude؛ المعاينة تحجب صور الخرائط.
2) خرائط Google (Satellite / Hybrid): تبويب "طبقات" ← أدخل مفتاح Google API ← "تفعيل Google".
   - من Google Cloud فعّل: Map Tiles API + الفوترة.
   - قيّد المفتاح بنطاق موقعك (HTTP referrers).
   - المفتاح يُحفظ في متصفحك فقط.
   - شروط Google تمنع تخزين بلاطاتها دون اتصال؛ الحفظ دون اتصال متاح للطبقات الأخرى فقط.
   بدون مفتاح يعمل التطبيق بخرائط CARTO/OSM/Esri.
3) الجلسات تُحفظ تلقائياً في المتصفح (localStorage) لكل جلسة على حدة.
