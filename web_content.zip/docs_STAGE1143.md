# CPLS V2 — Stage 1143

## Sample Cadence Monitor
- Adds a cadence-quality check over accepted Futures price samples.
- Detects unusually irregular sample intervals without inventing missing samples.
- Keeps gap, freshness and low-sampling warnings separate from cadence irregularity.
- Preserves candle integrity/merge, live continuity, zoom/pan and native snapshot validation.

Source ZIP stage only; APK build not performed.
