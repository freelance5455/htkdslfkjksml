# -*- coding: utf-8 -*-
"""
اختبار المرحلة الأولى لتطبيق فحصتي (Chromium بدون واجهة + محاكاة لإضافات Capacitor).
التشغيل:  خادم ثابت يخدم المجلد الذي يحوي  app -> www  و  orig (النسخة الأصلية)  و seed.html
          python3 tests/phase1_test.py  [BASE=http://localhost:8101] [ORIG=http://localhost:8102/orig]
"""
import json, os, sys
from playwright.sync_api import sync_playwright

BASE = os.environ.get('BASE', 'http://localhost:8101')
ORIG = os.environ.get('ORIG', 'http://localhost:8102/orig')
RES = []
ERRORS = []


def check(name, cond, detail=''):
    RES.append((name, bool(cond), str(detail)))
    print(('PASS  ' if cond else 'FAIL  ') + name + ('' if cond else '   <<< ' + str(detail)))


MOCK = """
window.Capacitor={isNativePlatform:()=>true,Plugins:{PdfMaker:{htmlToPdf:async()=>({valid:true,size:2048,path:'/tmp/x.pdf'}),openPdf:async()=>{},saveToDownloads:async()=>({location:'x'})}},registerPlugin:n=>null};
"""

with sync_playwright() as pw:
    br = pw.chromium.launch()
    ctx = br.new_context(viewport={'width': 390, 'height': 800})
    ctx.add_init_script(MOCK)
    page = ctx.new_page()
    page.on('pageerror', lambda e: ERRORS.append('pageerror: ' + str(e)))
    page.on('console', lambda m: ERRORS.append('console.error: ' + m.text) if m.type == 'error' else None)

    def settle(ms=300):
        page.wait_for_timeout(ms)

    def click(sel):
        page.click(sel)
        settle()

    def ev(js, arg=None):
        return page.evaluate(js, arg) if arg is not None else page.evaluate(js)

    def dlg(i):
        page.click('[data-dlg="%d"]' % i)
        settle()

    def toast_text():
        return ev("document.querySelector('#toast').textContent")

    def app_text():
        return ev("document.querySelector('#app').innerText")

    # ------------------------------------------------------------------ 0) seed v1 DB
    page.goto(BASE + '/seed.html')
    n = ev('seed()')
    check('0.1 زرع قاعدة قديمة (الإصدار 1) بخمسة فحوصات', n == 5)
    before = ev("""()=>new Promise(res=>{const r=indexedDB.open('fahsati');r.onsuccess=()=>{const d=r.result;const out={v:d.version,stores:[...d.objectStoreNames]};
      const t=d.transaction('inspections');t.objectStore('inspections').getAll().onsuccess=e=>{out.ins=e.target.result;d.close();res(out)}}})""")
    check('0.2 الإصدار قبل الترقية = 1 ولا يوجد مخزن notes', before['v'] == 1 and 'notes' not in before['stores'])

    # ------------------------------------------------------------------ 1) migration
    page.goto(BASE + '/app/index.html')
    settle(700)
    after = ev("""()=>new Promise(res=>{const r=indexedDB.open('fahsati');r.onsuccess=()=>{const d=r.result;const out={v:d.version,stores:[...d.objectStoreNames]};
      const t=d.transaction(['inspections','clients','cars','settings']);const o={};
      let n=0;['inspections','clients','cars','settings'].forEach(s=>t.objectStore(s).getAll().onsuccess=e=>{o[s]=e.target.result;if(++n===4){out.data=o;d.close();res(out)}})}})""")
    check('1.1 الترقية إلى الإصدار 2 وإضافة مخزن notes', after['v'] == 2 and 'notes' in after['stores'], after['stores'])
    check('1.2 بقاء كل المخازن القديمة', all(s in after['stores'] for s in ['clients', 'cars', 'inspections', 'photos', 'reminders', 'settings']))
    same = json.dumps(sorted(before['ins'], key=lambda x: x['id']), sort_keys=True) == json.dumps(sorted(after['data']['inspections'], key=lambda x: x['id']), sort_keys=True)
    check('1.3 الفحوصات القديمة بعد الترقية مطابقة حرفيًا لما قبلها (5 فحوصات)', same and len(after['data']['inspections']) == 5)
    check('1.4 العملاء والسيارات والإعدادات سليمة', len(after['data']['clients']) == 2 and len(after['data']['cars']) == 2 and after['data']['settings'][0]['value'] == 'مركز الاختبار')
    check('1.5 التطبيق يرسم الشاشة الرئيسية بلا أخطاء', 'فحصتي' in app_text() and len(ERRORS) == 0, ERRORS)

    # ------------------------------------------------------------------ 2) pure helpers
    r = ev("""()=>({
      v1:vinKey(' wvw zzz 1jz3 w386752 '), v2:vinKey('WVWZZZ1JZ3W386752'), v3:vinKey('WVW\\u00a0ZZZ\\u200b1JZ3\\tW386752\\n'),
      v4:vinKey('١٢٣abc'), v5:vinKey(''), v6:vinKey(null),
      odd1:vinOdd(vinKey('WVWZZZ1JZ3W386752')), odd2:vinOdd(vinKey('ABC123')), odd3:vinOdd(''),
      n1:normAr('تَسْرِيبُ زَيتِ المُحَرِّك'), n2:normAr('تسريب زيت المحرّك'), n3:normAr('إأآ ى ة'),
      s_same:similarity(normAr('تسريب زيت المحرك'),normAr('تسريب زيت المحرّك')),
      s_part:similarity(normAr('تسريب زيت'),normAr('تسريب زيت المحرك من الغطاء')),
      s_typo:similarity(normAr('تسريب زيت المحرك'),normAr('تسريب زيت المحرك من الغطاء العلوي')),
      s_diff:similarity(normAr('تسريب زيت المحرك'),normAr('تآكل تيل الفرامل الأمامي')),
      s_ya:similarity(normAr('تسريب زيت المحرك'),normAr('تسريب زيت المحرك'.replace('ة','ه')))
    })""")
    check('2.1 vinKey يزيل المسافات (عادية/غير منقسمة/حروف خفية/تبويب) ويحوّل لأحرف كبيرة', r['v1'] == r['v2'] == r['v3'] == 'WVWZZZ1JZ3W386752', r)
    check('2.2 vinKey يحوّل الأرقام العربية ويتعامل مع الفارغ وnull', r['v4'] == '123ABC' and r['v5'] == '' and r['v6'] == '', r)
    check('2.3 vinOdd: 17 خانة صحيحة لا تُنبَّه، والقصير يُنبَّه، والفارغ لا', (not r['odd1']) and r['odd2'] and (not r['odd3']), r)
    check('2.4 normAr يتجاهل التشكيل ويوحّد الألف والياء والتاء المربوطة', r['n1'] == r['n2'] == 'تسريب زيت المحرك' and r['n3'] == 'ااا ي ه', r)
    check('2.5 التشابه: متطابق=1، جزئي مرتفع، مختلف منخفض', r['s_same'] == 1 and r['s_part'] >= 0.6 and r['s_typo'] >= 0.5 and r['s_diff'] < 0.35, r)

    # ------------------------------------------------------------------ 3) notes screen CRUD
    click('[data-act="goNotes"]')
    check('3.1 فتح شاشة مكتبة الملاحظات وتظهر عبارة «سجلات هذا التطبيق فقط»', 'سجلات هذا التطبيق فقط' in app_text() and 'المكتبة فارغة' in app_text())

    def add_note(text, sec=''):
        click('[data-act="noteAdd"]')
        page.fill('#nTxt', text)
        if sec:
            page.select_option('#nSecSel', sec)
        click('[data-act="saveNote"]')

    add_note('تسريب زيت المحرك من الغطاء', 'المحرك')
    add_note('تآكل تيل الفرامل الأمامي', 'الفرامل')
    add_note('صوت غير طبيعي عند التسارع', 'المحرك')
    add_note('يحتاج فحص بالكمبيوتر')  # عام
    notes = ev("dbAll('notes')")
    check('3.2 إضافة 4 ملاحظات وحفظها في IndexedDB', len(notes) == 4 and all(n.get('createdAt') and n.get('updatedAt') for n in notes))
    check('3.3 تظهر الملاحظات في القائمة مع «استُخدمت في 0 فحص معتمد»', app_text().count('استُخدمت في 0 فحص معتمد') == 4, app_text()[:300])
    # duplicate (diacritics + same section) rejected
    click('[data-act="noteAdd"]')
    page.fill('#nTxt', 'تَسريب زيت المُحرّك من الغطاء')
    page.select_option('#nSecSel', 'المحرك')
    click('[data-act="saveNote"]')
    check('3.4 منع تكرار ملاحظة (حتى مع اختلاف التشكيل) في نفس القسم', 'موجودة بالفعل' in ev("document.querySelector('#nfErr').textContent") and len(ev("dbAll('notes')")) == 4)
    page.fill('#nTxt', '   ')
    click('[data-act="saveNote"]')
    check('3.5 رفض نص فارغ', 'اكتب نص الملاحظة' in ev("document.querySelector('#nfErr').textContent"))
    click('[data-act="closeNoteSheet"]')
    # edit
    nid = [n['id'] for n in ev("dbAll('notes')") if n['text'].startswith('صوت')][0]
    click('[data-act="noteEdit"][data-id="%s"]' % nid)
    page.fill('#nTxt', 'صوت غير طبيعي عند التسارع أو الدوران')
    click('[data-act="saveNote"]')
    e = ev("dbGet('notes','%s')" % nid)
    check('3.6 تعديل ملاحظة يحفظ النص الجديد ويحدّث updatedAt ويحافظ على المعرّف', e['text'].endswith('أو الدوران') and e['updatedAt'] >= e['createdAt'])
    # search
    page.fill('#nq', 'كمبيوتر')
    settle(400)
    check('3.7 البحث في الملاحظات', app_text().count('استُخدمت في') == 1 and 'بالكمبيوتر' in app_text())
    page.fill('#nq', '')
    settle(400)
    page.select_option('#nSec', 'الفرامل')
    settle(400)
    check('3.8 التصفية حسب القسم الفني', app_text().count('استُخدمت في') == 1 and 'تيل الفرامل' in app_text())
    page.select_option('#nSec', '__gen')
    settle(400)
    check('3.9 التصفية على «عام»', app_text().count('استُخدمت في') == 1 and 'بالكمبيوتر' in app_text())
    page.select_option('#nSec', '')
    settle(300)
    # delete
    nid2 = [n['id'] for n in ev("dbAll('notes')") if n['text'].startswith('يحتاج')][0]
    click('[data-act="noteDel"][data-id="%s"]' % nid2)
    dlg(0)
    check('3.10 إلغاء الحذف لا يحذف', len(ev("dbAll('notes')")) == 4)
    click('[data-act="noteDel"][data-id="%s"]' % nid2)
    dlg(1)
    check('3.11 الحذف بعد التأكيد', len(ev("dbAll('notes')")) == 3 and ev("dbGet('notes','%s')" % nid2) is None)
    # threshold
    page.fill('#nThr', '0')
    click('[data-act="saveThr"]')
    check('3.12 رفض حد غير صالح (0)', 'عددًا صحيحًا' in ev("document.querySelector('#nErr').textContent"))
    page.fill('#nThr', '2')
    click('[data-act="saveThr"]')
    check('3.13 حفظ حد «عيب شائع» = 2 وبقاؤه في الإعدادات', ev('getThr()') == 2)

    # ------------------------------------------------------------------ 4) usage counting + suggestions via real inspection flow
    # Seed usage: old inspections have no noteRefs, so usage must still be 0 (history untouched)
    nu = ev('notesWithUses().then(x=>x.uses)')
    check('4.1 الفحوصات القديمة (بنصوص مشابهة بلا ربط) لا تُحتسب كاستخدامات', sum(nu.values()) == 0, nu)

    ev("goTab('home')")
    settle()
    click('[data-act="newIns"]')

    def fill_form(name, phone, plate, vin, brand='تويوتا', model='كورولا'):
        page.fill('#fName', name)
        page.fill('#fPhone', phone)
        page.fill('#fBrand', brand)
        page.fill('#fModel', model)
        page.fill('#fPlate', plate)
        page.fill('#fVin', vin)
        click('[data-act="saveForm"]')

    fill_form('عميل جديد', '٠١٠٩٩٩٨٨٧٧٦', 'ن م ل 1', 'ZZZ1JZ3W3867521A ')  # 16 chars -> odd VIN dialog
    check('4.2 رقم شاسيه غير قياسي يعرض تنبيه تأكيد (ولا يمنع)', 'لا يطابق الصيغة القياسية' in ev("document.querySelector('#dlg').innerText"))
    dlg(0)  # edit number -> stays on form
    check('4.3 «تعديل الرقم» يبقي المستخدم على النموذج دون حفظ', ev("document.querySelector('#fVin')!=null") and len(ev("dbAll('inspections')")) == 5)
    page.fill('#fVin', '1HGCM82633A004352')
    click('[data-act="saveForm"]')
    check('4.4 إنشاء الفحص بعد رقم شاسيه صحيح', len(ev("dbAll('inspections')")) == 6 and 'ZZZ' not in ev("INS.car.vin"))
    check('4.5 رقم الهاتف العربي طُبِّع واللوحة/الشاسيه كما كُتبت', ev("INS.client.phone") == '01099988776' and ev("INS.car.vin") == '1HGCM82633A004352')
    insid = ev('INS.id')

    def open_item(section_idx, item_idx, enter_section=True):
        if enter_section:
            click('[data-act="openSec"][data-i="%d"]' % section_idx)
        page.locator('[data-act="openItem"]').nth(item_idx).click()
        settle()

    open_item(0, 0)  # المحرك
    box = lambda: ev("document.querySelector('#sugBox').innerText")
    check('4.6 عند فتح البند بلا نص: اقتراحات من نفس القسم فقط', 'تسريب زيت المحرك من الغطاء' in box() and 'تيل الفرامل' not in box(), box())
    page.fill('#iNotes', 'تسريب زيت')
    settle(500)
    sug = ev("[...document.querySelectorAll('#sugBox .sugi')].map(x=>x.innerText)")
    check('4.7 اقتراح فوري لملاحظة مشابهة أثناء الكتابة', sug and 'تسريب زيت المحرك من الغطاء' in sug[0], sug)
    check('4.8 لا تُضاف الملاحظة للنص تلقائيًا', ev("document.querySelector('#iNotes').value") == 'تسريب زيت' and ev("INS.items[0].notes") == 'تسريب زيت')
    check('4.9 عبارة «إحصاءات من سجلات هذا التطبيق فقط» تظهر في الاقتراحات', 'سجلات هذا التطبيق فقط' in box())
    # unrelated query from another section should not show with low similarity
    page.fill('#iNotes', 'تيل الفرامل')
    settle(500)
    sug2 = ev("[...document.querySelectorAll('#sugBox .sugi')].map(x=>x.innerText)")
    check('4.10 ملاحظة من قسم آخر تظهر فقط عند تشابه عالٍ (≥0.5) وبعلامة القسم', any('من قسم «الفرامل»' in x for x in sug2), sug2)
    page.fill('#iNotes', 'تسريب زيت')
    settle(500)
    page.click('#sugBox .sugi >> nth=0')
    settle(400)
    check('4.11 اختيار المهندس يضيف النص ويربط الملاحظة (noteRefs)', ev("document.querySelector('#iNotes').value") == 'تسريب زيت المحرك من الغطاء' and len(ev("INS.items[0].noteRefs")) == 1)
    # type custom text, save into library
    click('[data-act="closeSheet"]')
    open_item(0, 1, False)
    page.fill('#iNotes', 'صوت طقطقة من السير')
    click('[data-act="saveNoteLib"]')
    check('4.12 حفظ ملاحظة جديدة في المكتبة من شاشة البند', len(ev("dbAll('notes')")) == 4 and ev("INS.items[1].noteRefs.length") == 1)
    click('[data-act="saveNoteLib"]')
    check('4.13 حفظ نفس الملاحظة مرة ثانية لا يكرّرها', len(ev("dbAll('notes')")) == 4)
    click('[data-act="setSt"][data-k="follow"]')
    click('[data-act="closeSheet"]')
    # item 0 status
    open_item(0, 0, False)
    click('[data-act="setSt"][data-k="repair"]')
    click('[data-act="closeSheet"]')
    # draft: usage stays 0
    ev('flushSave()')
    nu = ev('notesWithUses().then(x=>x.uses)')
    check('4.14 المسودة لا تُحتسب كاستخدام', sum(nu.values()) == 0, nu)
    # approve
    click('[data-act="back"]')
    click('[data-act="toSummary"]')
    click('[data-act="finish"]')
    dlg(1)  # confirm unchecked items
    settle(600)
    st = ev("dbGet('inspections','%s')" % insid)
    check('4.15 اعتماد الفحص (بمحاكاة PDF) ينجح', st['status'] == 'complete', st['status'])
    nu = ev('notesWithUses().then(x=>x.uses)')
    uses_total = sorted(nu.values())
    check('4.16 الاستخدام يُحتسب عند الاعتماد فقط (ملاحظتان بعدّاد 1 لكل منهما)', uses_total == [1, 1], nu)

    # reopen + re-approve -> no double counting
    click('[data-act="reopen"]')
    dlg(1)
    nu = ev('notesWithUses().then(x=>x.uses)')
    check('4.17 إعادة الفتح كمسودة تُسقط الاحتساب مؤقتًا', sum(nu.values()) == 0, nu)
    click('[data-act="toSummary"]')
    click('[data-act="finish"]')
    dlg(1)
    settle(600)
    nu = ev('notesWithUses().then(x=>x.uses)')
    check('4.18 إعادة الاعتماد لا تضاعف العدّاد', sorted(nu.values()) == [1, 1], nu)

    # second inspection reusing the same note, then remove text before approval
    ev("goTab('home')")
    settle()
    click('[data-act="newIns"]')
    fill_form('عميل ثانٍ', '01077665544', 'ك ك ك 9', '')
    open_item(0, 0)
    page.fill('#iNotes', 'تسريب زيت')
    settle(500)
    page.click('#sugBox .sugi >> nth=0')
    settle(300)
    click('[data-act="setSt"][data-k="repair"]')
    click('[data-act="closeSheet"]')
    open_item(0, 1, False)
    page.fill('#iNotes', 'صوت طقطقة من السير')
    settle(400)
    page.click('#sugBox .sugi >> nth=0')  # attach, then user deletes the text
    settle(300)
    page.fill('#iNotes', '')  # engineer deletes the note text
    settle(300)
    click('[data-act="closeSheet"]')
    click('[data-act="back"]')
    click('[data-act="toSummary"]')
    click('[data-act="finish"]')
    dlg(1)
    settle(600)
    nu = ev('notesWithUses().then(x=>x)')
    byText = {n['text']: nu['uses'].get(n['id'], 0) for n in nu['notes']}
    check('4.19 عدّاد الملاحظة المعتمدة مرتين = 2', byText['تسريب زيت المحرك من الغطاء'] == 2, byText)
    check('4.20 ملاحظة حُذف نصها قبل الاعتماد لا تُحتسب (يبقى 1)', byText['صوت طقطقة من السير'] == 1, byText)

    # common-defect badge at threshold 2
    ev("goTab('home')")
    settle()
    click('[data-act="goNotes"]')
    txt = app_text()
    check('4.21 علامة «عيب شائع» تظهر عند بلوغ الحد (2) وبنفس نص «سجلاتك»', txt.count('عيب شائع في سجلاتك') == 1, txt.count('عيب شائع في سجلاتك'))
    page.select_option('#nFlt', 'common')
    settle(400)
    check('4.22 تصفية «عيوب شائعة فقط»', app_text().count('استُخدمت في') == 1)
    page.select_option('#nFlt', 'unused')
    settle(400)
    check('4.23 تصفية «غير مستخدمة»', app_text().count('استُخدمت في') == 2, app_text().count('استُخدمت في'))
    page.select_option('#nFlt', '')
    page.fill('#nThr', '3')
    click('[data-act="saveThr"]')
    check('4.24 رفع الحد إلى 3 يُخفي العلامة (قابل للتعديل)', app_text().count('عيب شائع في سجلاتك') == 0)
    page.fill('#nThr', '2')
    click('[data-act="saveThr"]')

    # suggestion ranking by usage (same similarity, different uses)
    ranked = ev("""notesWithUses().then(({notes,uses})=>rankNotes(notes,uses,'',  'المحرك').map(x=>[x.n.text,x.u]))""")
    check('4.25 الترتيب بلا نص: الأعلى استخدامًا أولًا ضمن القسم', ranked and ranked[0][0] == 'تسريب زيت المحرك من الغطاء' and ranked[0][1] == 2, ranked)

    # old report text intact + not changed by library
    old = ev("dbGet('inspections','i1')")
    check('4.26 نصوص الفحص القديم لم تتغير ولم تُضف لها noteRefs', old['items'][0]['notes'] == 'تسريب زيت المحرك من الغطاء' and 'noteRefs' not in old['items'][0] and old['finalNotes'] == 'ملاحظة نهائية قديمة')
    ev("dbGet('inspections','i1').then(i=>{window.__i1=i})")
    settle(100)
    html_new = ev("buildHtml(window.__i1,[],'مركز','مهندس')")

    # ------------------------------------------------------------------ 5) VIN search
    ev("goTab('home')")
    settle()
    click('[data-act="goSearch"]')
    check('5.1 شاشة البحث تفتح وتطلب إدخالًا', 'اكتب رقم الشاسيه' in app_text())

    def search(q):
        page.fill('#hq', q)
        settle(500)
        return ev("document.querySelector('#hlist').innerText"), ev("[...document.querySelectorAll('#hlist [data-act=openIns]')].map(x=>x.dataset.id)"), ev("[...document.querySelectorAll('#hlist [data-act=openVeh]')].map(x=>x.dataset.vin)")

    t, ids, vins = search('WVWZZZ1JZ3W386752')
    check('5.2 البحث بالرقم الكامل: سيارة واحدة وفحصان (المكتوب بمسافات والمكتوب بدونها)', vins == ['WVWZZZ1JZ3W386752'] and sorted(ids) == ['i1', 'i3'], (vins, ids))
    t, ids, vins = search('  wvw zzz 1jz3 w386752  ')
    check('5.3 البحث بأحرف صغيرة ومسافات: نفس النتيجة', vins == ['WVWZZZ1JZ3W386752'] and sorted(ids) == ['i1', 'i3'], (vins, ids))
    t, ids, vins = search('386752')
    check('5.4 البحث بآخر 6 خانات', vins == ['WVWZZZ1JZ3W386752'] and sorted(ids) == ['i1', 'i3'], (vins, ids))
    t, ids, vins = search('١٢٣٤')
    check('5.5 رقم عربي قصير (4 خانات) لا يطابق شاسيه خطأ', 'WVWZZZ1JZ3W386752' not in vins)
    t, ids, vins = search('01012345678')
    check('5.6 البحث برقم الهاتف ما زال يعمل (فحوصات العميل أحمد فقط)', sorted(ids) == ['i1', 'i2', 'i3'] and vins == [], (ids, vins))
    t, ids, vins = search('٠١٠١٢٣٤٥٦٧٨')
    check('5.7 البحث برقم الهاتف بأرقام عربية', sorted(ids) == ['i1', 'i2', 'i3'], ids)
    t, ids, vins = search('أ ب ج 1234')
    check('5.8 البحث برقم اللوحة ما زال يعمل (يشمل السجل القديم بلا شاسيه)', sorted(ids) == ['i1', 'i2', 'i3'], ids)
    t, ids, vins = search('أبج1234')
    check('5.9 البحث باللوحة بدون مسافات', sorted(ids) == ['i1', 'i2', 'i3'], ids)
    t, ids, vins = search('JTDBR32E720012345')
    check('5.10 سيارة أخرى: لا اختلاط (فحص واحد i4 فقط)', vins == ['JTDBR32E720012345'] and ids == ['i4'], (vins, ids))
    t, ids, vins = search('هيونداي')
    check('5.11 البحث بالماركة ما زال يعمل', ids == ['i4'], ids)
    t, ids, vins = search('غير موجود 999')
    check('5.12 لا نتائج', ids == [] and 'لا توجد نتائج' in t)

    # vehicle profile
    search('WVWZZZ1JZ3W386752')
    page.click('#hlist [data-act=openVeh]')
    settle(500)
    cards = ev("[...document.querySelectorAll('#app [data-act=openIns]')].map(x=>x.dataset.id)")
    txt = app_text()
    check('5.13 ملف السيارة يعرض كل فحوصاتها الاثنين بترتيب الأحدث أولًا (i3 ثم i1)', cards[:2] == ['i3', 'i1'], cards)
    check('5.14 ملف السيارة يعرض بيانات السيارة (VIN الأصلي، الماركة، اللوحة، العداد الأحدث)', 'WVWZZZ1JZ3W386752' in txt.replace(' ', '') and 'تويوتا' in txt and 'أ ب ج 1234' in txt and '95000' in txt, txt[:300])
    check('5.15 السجل القديم بلا شاسيه (نفس اللوحة) يظهر منفصلًا كاقتراح غير مدمج', cards == ['i3', 'i1', 'i2'] and 'لم تُدمج تلقائيًا' in txt, cards)
    check('5.16 تنبيه «كُتب الرقم بصيغ مختلفة» للمسافات', 'بصيغ مختلفة' in txt)
    click('[data-act="vehOrder"]')
    cards2 = ev("[...document.querySelectorAll('#app [data-act=openIns]')].map(x=>x.dataset.id)")
    check('5.17 عكس الترتيب: الأقدم أولًا (i1 ثم i3)', cards2[:2] == ['i1', 'i3'], cards2)
    raw = ev("dbAll('inspections')")
    rawvins = {i['id']: i['car']['vin'] for i in raw}
    check('5.18 الرقم الأصلي المخزّن لم يُعدّل (المسافات محفوظة كما كُتبت)', rawvins['i3'] == 'WVW ZZZ 1JZ3 W386752' and rawvins['i1'] == 'WVWZZZ1JZ3W386752' and rawvins['i2'] == '')
    # open completed inspection report from profile
    page.click('#app [data-act=openIns][data-id="i1"]')
    settle(500)
    check('5.19 فتح تقرير فحص مكتمل من ملف السيارة', 'التقرير' in app_text() or 'فحص مكتمل' in app_text())

    # history screen also searches VIN
    ev("goTab('history')")
    settle()
    page.fill('#hq', 'jtdbr32e720012345')
    settle(500)
    ids = ev("[...document.querySelectorAll('#hlist [data-act=openIns]')].map(x=>x.dataset.id)")
    check('5.21 شاشة السجل تدعم البحث بالشاسيه أيضًا', ids == ['i4'], ids)

    # ------------------------------------------------------------------ 6) saveForm car matching
    ev("goTab('home')")
    settle()

    def cars():
        return ev("dbAll('cars')")

    n0 = len(cars())
    # same client A, same VIN written with spaces -> same car record (no new car)
    click('[data-act="newIns"]')
    fill_form('أحمد', '01012345678', 'أ ب ج 1234', 'wvw zzz 1jz3 w386752')
    n1 = len(cars())
    check('6.1 نفس العميل ونفس الشاسيه (مع مسافات/حالة) = نفس سجل السيارة', n1 == n0, (n0, n1))
    vin_a = [c for c in cars() if c['id'] == 'carA'][0]['vin']
    check('6.2 سجل السيارة يحمل الشاسيه ولا يُمسح', vin_a.replace(' ', '').upper() == 'WVWZZZ1JZ3W386752', vin_a)
    ev("goTab('home')")
    settle()
    # same client, same plate, DIFFERENT vin -> separate car
    click('[data-act="newIns"]')
    fill_form('أحمد', '01012345678', 'أ ب ج 1234', 'JT2AE86S3E0012345')
    n2 = len(cars())
    check('6.3 نفس العميل ونفس اللوحة بشاسيه مختلف = سيارة منفصلة (منع الخلط)', n2 == n1 + 1 and 'منفصلة' in toast_text(), (n1, n2, toast_text()))
    check('6.4 سيارة A لم يُعدَّل شاسيهها بسبب السيارة الجديدة', [c for c in cars() if c['id'] == 'carA'][0]['vin'].replace(' ', '') == 'WVWZZZ1JZ3W386752')
    ev("goTab('home')")
    settle()
    # same client, same plate as carA, NO vin -> prompt; choose "no" -> VIN not erased & inspection has empty vin
    click('[data-act="newIns"]')
    fill_form('أحمد', '01012345678', 'أ ب ج 1234', '')
    prompt_ok = 'مسجلة سابقًا برقم شاسيه' in ev("document.querySelector('#dlg').innerText")
    dlg(0)
    check('6.5 لوحة معروفة بشاسيه + إدخال بلا شاسيه: سؤال صريح للمهندس', prompt_ok)
    check('6.6 اختيار «لا» يترك شاسيه الفحص فارغًا ولا يمسح شاسيه السيارة', ev("INS.car.vin") == '' and [c for c in cars() if c['id'] == 'carA'][0]['vin'] != '')
    ev("goTab('home')")
    settle()
    click('[data-act="newIns"]')
    fill_form('أحمد', '01012345678', 'أ ب ج 1234', '')
    dlg(1)
    check('6.7 اختيار «نعم» يستخدم الشاسيه المعروف للفحص الجديد', ev("INS.car.vin") != '' and ev("vinKey(INS.car.vin)") == 'WVWZZZ1JZ3W386752')
    ev("goTab('home')")
    settle()
    # legacy: new client without VIN works as before
    click('[data-act="newIns"]')
    fill_form('بدون شاسيه', '01155556666', 'ل ل ل 3', '')
    check('6.8 فحص جديد بلا شاسيه يعمل كما كان (دعم السجلات بلا VIN)', ev("INS.car.vin") == '' and ev("INS.status") == 'draft')
    ev("goTab('home')")
    settle()
    # prevSel prefill carries VIN raw
    click('[data-act="newIns"]')
    opts = ev("[...document.querySelectorAll('#prevSel option')].length")
    check('6.9 قائمة «إعادة فحص سيارة سابقة» تعمل ولا تدمج سيارتين بنفس اللوحة وشاسيه مختلف', opts >= 6, opts)
    click('[data-act="back"]')

    # ------------------------------------------------------------------ 7) backup / restore
    bk = ev("buildBackup().then(b=>JSON.parse(b.json))")
    check('7.1 النسخة الاحتياطية تتضمن مخزن notes ومخطط 2', 'notes' in bk['stores'] and bk['dbSchema'] == 2 and bk['counts']['notes'] == len(bk['data']['notes']) and bk['appVersion'] == '1.1.0')
    ok = ev("""(async()=>{const b=await buildBackup();const o=JSON.parse(b.json);const v=validateBackup(o);if(v.err)return 'err:'+v.err;
       const hd={};o.stores.forEach(x=>hd[x]=v.d[x]);return (await sha256(JSON.stringify(hd)))===o.sha256})()""")
    check('7.2 فحص البصمة للنسخة الجديدة يطابق', ok is True, ok)
    # old-format v2 backup (6 stores, no notes) must still verify and restore without wiping notes
    old_bk = ev("""(async()=>{const S=['clients','cars','inspections','photos','reminders','settings'];const d={};for(const s of S)d[s]=await dbAll(s);
        const str=JSON.stringify(d);return JSON.stringify({app:'fahsati',version:2,appVersion:'1.0.2',dbSchema:1,stores:S,exportedAt:new Date().toISOString(),counts:Object.fromEntries(S.map(k=>[k,d[k].length])),sha256:await sha256(str),data:d})})()""")
    notes_before = len(ev("dbAll('notes')"))
    ev("window.__oldbk=%s" % json.dumps(old_bk))
    r = ev("""(async()=>{const o=JSON.parse(window.__oldbk);const v=validateBackup(o);if(v.err)return v.err;
       const hd={};(Array.isArray(o.stores)?o.stores:[]).forEach(x=>hd[x]=v.d[x]);const h=await sha256(JSON.stringify(hd));return {sha:h===o.sha256,hadNotes:v.hadNotes}})()""")
    check('7.3 نسخة قديمة (بدون notes) تجتاز التحقق من البصمة ولا تُرفض', r == {'sha': True, 'hadNotes': False}, r)
    # real restore in replace mode through UI using file input
    ev("goTab('settings')")
    settle()
    open('/tmp/oldbk.json', 'w', encoding='utf-8').write(old_bk)
    page.set_input_files('#bkFile', '/tmp/oldbk.json')
    settle(600)
    click('[data-dlg="2"]')  # replace
    click('[data-dlg="1"]')  # confirm replace
    settle(800)
    check('7.4 استبدال من نسخة قديمة: الفحوصات تعود لحالتها، والمكتبة الحالية لا تُمسح', len(ev("dbAll('notes')")) == notes_before, (notes_before, len(ev("dbAll('notes')"))))
    # new backup replace restores notes too
    new_bk = ev("buildBackup().then(b=>b.json)")
    open('/tmp/newbk.json', 'w', encoding='utf-8').write(new_bk)
    ev("dbAll('notes').then(ns=>Promise.all(ns.map(n=>dbDel('notes',n.id))))")
    check('7.5 (تمهيد) مسح المكتبة', len(ev("dbAll('notes')")) == 0)
    ev("goTab('settings')")
    settle()
    page.set_input_files('#bkFile', '/tmp/newbk.json')
    settle(600)
    click('[data-dlg="1"]')  # merge
    settle(800)
    check('7.6 دمج نسخة جديدة يعيد الملاحظات المفقودة', len(ev("dbAll('notes')")) == notes_before, len(ev("dbAll('notes')")))

    # ------------------------------------------------------------------ 8) persistence after reload
    cnt_n = len(ev("dbAll('notes')"))
    thr = ev('getThr()')
    page.reload()
    settle(800)
    check('8.1 الملاحظات والحد المحفوظ يبقيان بعد إعادة تحميل التطبيق', len(ev("dbAll('notes')")) == cnt_n and ev('getThr()') == thr == 2, (cnt_n, thr))
    uses_after = ev('notesWithUses().then(x=>x.uses)')
    check('8.2 العدّادات تُعاد حسابها صحيحة بعد إعادة التحميل', 2 in uses_after.values(), uses_after)

    # ------------------------------------------------------------------ 9) old report html identical to original app
    p2 = ctx.new_page()
    p2.goto(ORIG + '/index.html')
    p2.wait_for_timeout(800)
    p2.evaluate("window.__i1=%s" % json.dumps(ev("dbGet('inspections','i1')")))
    html_old = p2.evaluate("buildHtml(window.__i1,[],'مركز','مهندس')")
    check('9.1 HTML التقرير القديم من الكود الجديد مطابق حرفيًا لمخرجات الكود الأصلي', html_old == html_new and len(html_old) > 1000, (len(html_old), len(html_new)))
    p2.close()

    check('10.1 لا أخطاء JavaScript أثناء كل الاختبارات', len([e for e in ERRORS if 'favicon' not in e]) == 0, ERRORS[:5])
    br.close()

passed = sum(1 for _, ok, _ in RES if ok)
print('\n==== %d/%d passed ====' % (passed, len(RES)))
with open(os.path.join(os.path.dirname(__file__), 'phase1_results.txt'), 'w', encoding='utf-8') as f:
    for name, ok, d in RES:
        f.write(('PASS  ' if ok else 'FAIL  ') + name + ('' if ok else '   <<< ' + d) + '\n')
    f.write('\n%d/%d passed\n' % (passed, len(RES)))
sys.exit(0 if passed == len(RES) else 1)
