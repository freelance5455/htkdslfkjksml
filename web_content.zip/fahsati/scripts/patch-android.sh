#!/usr/bin/env bash
set -e
J=android/app/src/main/java
mkdir -p $J/com/fahsati/app $J/android/print android/app/src/main/res/xml
cp native/MainActivity.java native/PdfMakerPlugin.java $J/com/fahsati/app/
cp native/PdfPrinter.java $J/android/print/PdfPrinter.java
cp native/file_paths.xml android/app/src/main/res/xml/file_paths.xml
M=android/app/src/main/AndroidManifest.xml
grep -q POST_NOTIFICATIONS $M || sed -i 's#</manifest>#    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />\n</manifest>#' $M
S=android/app/src/main/res/values/strings.xml
sed -i 's#<string name="app_name">[^<]*</string>#<string name="app_name">فحصتي</string>#; s#<string name="title_activity_main">[^<]*</string>#<string name="title_activity_main">فحصتي</string>#' $S
echo patched
