package android.print;

import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import java.io.File;

/** Must live in android.print: LayoutResultCallback/WriteResultCallback constructors are package-private. */
public class PdfPrinter {
    public interface Callback { void onDone(boolean ok, String error); }

    public static void print(final PrintDocumentAdapter adapter, final File out, final Callback cb) {
        PrintAttributes attrs = new PrintAttributes.Builder()
            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
            .setResolution(new PrintAttributes.Resolution("pdf", "pdf", 300, 300))
            .setMinMargins(new PrintAttributes.Margins(300, 300, 300, 300))
            .build();
        adapter.onLayout(null, attrs, new CancellationSignal(), new PrintDocumentAdapter.LayoutResultCallback() {
            @Override public void onLayoutFinished(PrintDocumentInfo info, boolean changed) {
                try {
                    final ParcelFileDescriptor fd = ParcelFileDescriptor.open(out,
                        ParcelFileDescriptor.MODE_READ_WRITE | ParcelFileDescriptor.MODE_CREATE | ParcelFileDescriptor.MODE_TRUNCATE);
                    adapter.onWrite(new PageRange[]{PageRange.ALL_PAGES}, fd, new CancellationSignal(),
                        new PrintDocumentAdapter.WriteResultCallback() {
                            @Override public void onWriteFinished(PageRange[] pages) {
                                try { fd.close(); } catch (Exception ignored) {}
                                cb.onDone(true, null);
                            }
                            @Override public void onWriteFailed(CharSequence error) {
                                try { fd.close(); } catch (Exception ignored) {}
                                cb.onDone(false, String.valueOf(error));
                            }
                        });
                } catch (Exception e) { cb.onDone(false, e.getMessage()); }
            }
            @Override public void onLayoutFailed(CharSequence error) { cb.onDone(false, String.valueOf(error)); }
        }, null);
    }
}
