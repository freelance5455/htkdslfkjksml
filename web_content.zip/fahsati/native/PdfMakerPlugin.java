package com.fahsati.app;

import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.print.PdfPrinter;
import android.print.PrintDocumentAdapter;
import android.provider.MediaStore;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.core.content.FileProvider;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.*;
import java.util.concurrent.atomic.AtomicBoolean;

@CapacitorPlugin(name = "PdfMaker")
public class PdfMakerPlugin extends Plugin {

    @PluginMethod
    public void htmlToPdf(final PluginCall call) {
        final String html = call.getString("html");
        final String name = new File(call.getString("fileName", "report.pdf")).getName();
        if (html == null) { call.reject("no html"); return; }
        // Guarantees the call is settled exactly once and the WebView is released (no endless spinner in JS).
        final AtomicBoolean settled = new AtomicBoolean(false);
        final Handler main = new Handler(Looper.getMainLooper());
        final WebView[] holder = new WebView[1];
        final Runnable[] timeoutRef = new Runnable[1];
        final Runnable cleanup = () -> {
            if (timeoutRef[0] != null) main.removeCallbacks(timeoutRef[0]);
            WebView w = holder[0];
            if (w != null) { try { w.destroy(); } catch (Exception ignored) {} holder[0] = null; }
        };
        timeoutRef[0] = () -> {
            if (settled.compareAndSet(false, true)) { cleanup.run(); call.reject("PDF timeout"); }
        };
        getActivity().runOnUiThread(() -> {
            try {
                main.postDelayed(timeoutRef[0], 45000);
                final WebView wv = new WebView(getContext());
                holder[0] = wv;
                wv.getSettings().setJavaScriptEnabled(false);
                wv.setWebViewClient(new WebViewClient() {
                    boolean started = false;
                    @Override public void onPageFinished(final WebView v, String url) {
                        if (started) return;
                        started = true;
                        v.postDelayed(() -> {
                            try {
                                final File out = new File(getContext().getCacheDir(), name);
                                PrintDocumentAdapter ad = v.createPrintDocumentAdapter("fahsati");
                                PdfPrinter.print(ad, out, (ok, err) -> {
                                    if (!settled.compareAndSet(false, true)) return;
                                    boolean valid = ok && isPdf(out);
                                    cleanup.run();
                                    if (!ok) { call.reject("PDF failed: " + err); return; }
                                    JSObject r = new JSObject();
                                    r.put("path", out.getAbsolutePath());
                                    r.put("size", out.length());
                                    r.put("valid", valid);
                                    call.resolve(r);
                                });
                            } catch (Exception e) {
                                if (settled.compareAndSet(false, true)) { cleanup.run(); call.reject("PDF error: " + e.getMessage()); }
                            }
                        }, 800);
                    }
                });
                wv.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
            } catch (Exception e) {
                if (settled.compareAndSet(false, true)) { cleanup.run(); call.reject("PDF error: " + e.getMessage()); }
            }
        });
    }

    private boolean isPdf(File f) {
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] b = new byte[4];
            return in.read(b) == 4 && b[0] == '%' && b[1] == 'P' && b[2] == 'D' && b[3] == 'F';
        } catch (Exception e) { return false; }
    }

    @PluginMethod
    public void openPdf(PluginCall call) {
        try {
            File f = new File(call.getString("path", ""));
            if (!f.exists()) { call.reject("file missing"); return; }
            Uri uri = FileProvider.getUriForFile(getContext(), getContext().getPackageName() + ".fileprovider", f);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, "application/pdf");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) { call.reject("no viewer: " + e.getMessage()); }
    }

    /** Copies a cache file to Downloads/Fahsati (Android 10+) or app external files dir (older). */
    @PluginMethod
    public void saveToDownloads(PluginCall call) {
        try {
            File src = new File(call.getString("path", ""));
            String name = new File(call.getString("name", src.getName())).getName();
            String mime = call.getString("mime", "application/pdf");
            if (!src.exists() || src.length() == 0) { call.reject("source missing"); return; }
            String where; long written;
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Fahsati");
                Uri u = getContext().getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (u == null) { call.reject("insert failed"); return; }
                try (InputStream in = new FileInputStream(src); OutputStream out = getContext().getContentResolver().openOutputStream(u)) {
                    written = copy(in, out);
                }
                where = "Download/Fahsati/" + name;
            } else {
                File dir = getContext().getExternalFilesDir(null);
                File dst = new File(dir, name);
                try (InputStream in = new FileInputStream(src); OutputStream out = new FileOutputStream(dst)) { written = copy(in, out); }
                where = dst.getAbsolutePath();
            }
            if (written != src.length()) { call.reject("incomplete copy"); return; }
            JSObject r = new JSObject(); r.put("location", where); r.put("size", written);
            call.resolve(r);
        } catch (Exception e) { call.reject("save failed: " + e.getMessage()); }
    }


    /** Opens URL outside WebView via Android Intent. Prefer WhatsApp package when applicable. */
    @PluginMethod
    public void openUrl(PluginCall call) {
        try {
            String url = call.getString("url", "");
            if (url == null || url.length() == 0) { call.reject("no url"); return; }
            Uri uri = Uri.parse(url);
            boolean opened = false;
            Exception last = null;
            // 1) WhatsApp consumer
            try {
                Intent i = new Intent(Intent.ACTION_VIEW, uri);
                i.setPackage("com.whatsapp");
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(i);
                opened = true;
            } catch (Exception e) { last = e; }
            // 2) WhatsApp Business
            if (!opened) {
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW, uri);
                    i.setPackage("com.whatsapp.w4b");
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    getContext().startActivity(i);
                    opened = true;
                } catch (Exception e) { last = e; }
            }
            // 3) Any handler (browser / chooser) — still outside WebView
            if (!opened) {
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW, uri);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    Intent chooser = Intent.createChooser(i, "Open");
                    chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    getContext().startActivity(chooser);
                    opened = true;
                } catch (Exception e) { last = e; }
            }
            if (!opened) {
                call.reject("open failed: " + (last != null ? last.getMessage() : "no handler"));
                return;
            }
            JSObject r = new JSObject();
            r.put("ok", true);
            call.resolve(r);
        } catch (Exception e) {
            call.reject("open failed: " + e.getMessage());
        }
    }

    private long copy(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[16384]; int n; long t = 0;
        while ((n = in.read(buf)) > 0) { out.write(buf, 0, n); t += n; }
        out.flush(); return t;
    }
}
