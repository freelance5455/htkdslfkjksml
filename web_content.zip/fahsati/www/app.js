'use strict';
/* ===== فحصتي — Fahsati ===== */
const $=s=>document.querySelector(s);
const PL={};
const P=n=>{if(PL[n])return PL[n];const C=window.Capacitor;if(!C)return null;PL[n]=(C.Plugins&&C.Plugins[n])||(C.registerPlugin?C.registerPlugin(n):null);return PL[n]};
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,8);
const ST={none:['لم يتم الفحص','#667085'],ok:['سليم','#16A36A'],follow:['يحتاج متابعة','#F59E0B'],repair:['يحتاج إصلاح','#DC2626']};
const PRI={urgent:'عاجل',soon:'قريبًا',periodic:'متابعة دورية'};
const CREDIT_PHONE='01271323579';
const TEMPLATE=[
{n:'المحرك',i:['صوت المحرك وثبات الدوران','تسريب زيت المحرك','حالة السيور','قواعد (وسائد) المحرك','دخان العادم','أداء التشغيل والتسارع']},
{n:'ناقل الحركة والفتيس',i:['نعومة تغيير السرعات','زيت ناقل الحركة (المستوى واللون)','تسريب ناقل الحركة','القابض (الدبرياج)','أعمدة الدوران والمفاصل']},
{n:'الفرامل',i:['تيل الفرامل الأمامي','تيل الفرامل الخلفي','الأقراص والطنابير','زيت الفرامل','فرامل اليد','خراطيم وخطوط الفرامل']},
{n:'العفشة والتوجيه',i:['المساعدات الأمامية','المساعدات الخلفية','المقصات والمفاصل (الروتيلات)','وصلات التوجيه والدركسيون','الجلب والكاوتش','زيت وخراطيم الباور','ضبط الزوايا']},
{n:'نظام التبريد',i:['مستوى سائل التبريد','تسريب الردياتير والخراطيم','مروحة التبريد','طلمبة المياه','غطاء الردياتير والثرموستات']},
{n:'الكهرباء والبطارية',i:['حالة البطارية','أقطاب البطارية','الدينامو (الشحن)','الاستارتر (المارش)','لمبات التحذير بالتابلوه','الفيوزات والتوصيلات']},
{n:'التكييف',i:['برودة التكييف','الكمبروسر','مروحة التكييف','فلتر الكابينة','تسريب غاز أو زيت التكييف']},
{n:'الإطارات والعجلات',i:['عمق الفرم الأمامي','عمق الفرم الخلفي','ضغط الهواء','الجنوط','الإطار الاحتياطي والعدة','انتظام التآكل']},
{n:'الزيوت والسوائل والتسريبات',i:['زيت المحرك','سائل التبريد','زيت الفرامل','زيت الباور','ماء المساحات','تسريبات أسفل السيارة']},
{n:'الهيكل والطلاء',i:['حالة الطلاء','علامات صدمات أو لحام','الصدأ','الزجاج','المرايات','الأبواب والأقفال','الشاسيه من الأسفل']},
{n:'الإضاءة والإشارات',i:['الإضاءة الأمامية','الإضاءة الخلفية وفرامل','إشارات الانعطاف','لمبات الرجوع والضباب','لمبات الطوارئ']},
{n:'أنظمة السلامة',i:['أحزمة الأمان','الوسائد الهوائية (لمبة التحذير)','نظام ABS','الكلاكس','المساعحات (المساحات)','قفل الأطفال']}];
TEMPLATE[11].i[4]='المساحات';

/* ---------- DB (IndexedDB, persistent) ---------- */
let db;
function openDB(){return new Promise((res,rej)=>{const r=indexedDB.open('fahsati',1);
r.onupgradeneeded=()=>{const d=r.result;['clients','cars','inspections','reminders'].forEach(n=>d.createObjectStore(n,{keyPath:'id'}));
d.createObjectStore('photos',{keyPath:'id'}).createIndex('insp','inspectionId');d.createObjectStore('settings',{keyPath:'key'})};
r.onsuccess=()=>{db=r.result;res()};r.onerror=()=>rej(r.error)})}
const tx=(s,m,f)=>new Promise((res,rej)=>{const t=db.transaction(s,m);let out;const rq=f(t.objectStore(s));if(rq)rq.onsuccess=()=>{out=rq.result};t.oncomplete=()=>res(out);t.onerror=()=>rej(t.error);t.onabort=()=>rej(t.error||new Error('abort'))});
const dbPut=(s,v)=>tx(s,'readwrite',o=>o.put(v));
const dbGet=(s,k)=>tx(s,'readonly',o=>o.get(k));
const dbAll=s=>tx(s,'readonly',o=>o.getAll());
const dbDel=(s,k)=>tx(s,'readwrite',o=>o.delete(k));
const photosOf=id=>tx('photos','readonly',o=>o.index('insp').getAll(id));
async function getSet(k,d){const r=await dbGet('settings',k);return r?r.value:d}
const setSet=(k,v)=>dbPut('settings',{key:k,value:v});
async function delInspection(id){const ph=await photosOf(id);
await new Promise((res,rej)=>{const t=db.transaction(['photos','inspections'],'readwrite');ph.forEach(p=>t.objectStore('photos').delete(p.id));t.objectStore('inspections').delete(id);t.oncomplete=res;t.onerror=()=>rej(t.error)})}

/* ---------- helpers ---------- */
const normD=s=>String(s||'').replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d));
function validPhone(p){const x=normD(p).replace(/[\s\-()]/g,'');return /^(\+?20|0)?1[0125]\d{8}$/.test(x)||/^\+\d{8,15}$/.test(x)||/^0\d{8,10}$/.test(x)}
function fmt(t){try{return new Date(t).toLocaleString('ar-u-nu-latn',{dateStyle:'medium',timeStyle:'short'})}catch(e){return new Date(t).toLocaleString()}}
const cnt=items=>{const c={ok:0,follow:0,repair:0,none:0};items.forEach(i=>c[i.status]++);return c};
const badge=k=>`<span class="badge" style="--c:${ST[k][1]}">${ST[k][0]}</span>`;
let tT;function toast(m,k){const t=$('#toast');t.textContent=m;t.className=k||'';t.style.display='block';clearTimeout(tT);tT=setTimeout(()=>t.style.display='none',3200)}
const load=on=>$('#load').classList.toggle('on',on);
let busy=false;
const once=fn=>async(...a)=>{if(busy)return;busy=true;load(true);try{return await fn(...a)}catch(e){console.error(e);toast('حدث خطأ: '+(e&&e.message||e),'err')}finally{busy=false;load(false)}};
function dialog(html,btns){return new Promise(res=>{const d=$('#dlg');d.innerHTML=`<div class="dbox">${html}<div class="row" style="margin-top:10px">${btns.map((b,i)=>`<button class="btn ${b.cls||''}" data-dlg="${i}">${b.t}</button>`).join('')}</div></div>`;d.classList.add('on');
d.onclick=e=>{const b=e.target.closest('[data-dlg]');if(!b)return;d.classList.remove('on');d.innerHTML='';res(btns[+b.dataset.dlg].v)}})}
const confirmD=(m,ok='نعم، متابعة')=>dialog(`<p style="line-height:1.9">${esc(m)}</p>`,[{t:'إلغاء',v:false},{t:ok,v:true,cls:'danger'}]);
const openSheet=h=>{const s=$('#sheet');s.innerHTML=`<div class="sheet">${h}</div>`;s.classList.add('on')};
const closeSheetEl=()=>{$('#sheet').classList.remove('on');$('#sheet').innerHTML=''};
function topBar(title,sub,back){return `<div class="top">${back?'<button class="back" data-act="back">رجوع ›</button>':''}<h1>${esc(title)}</h1>${sub?`<p>${esc(sub)}</p>`:''}</div>`}
const carLine=i=>[i.car.brand,i.car.model,i.car.year].filter(Boolean).join(' ');
function insCard(i){const c=cnt(i.items);return `<button class="glass item" data-act="openIns" data-id="${i.id}"><div><div class="t">${esc(i.client.name||'بدون اسم')} — ${esc(i.car.plate||'بدون لوحة')}</div><div class="s">${esc(carLine(i))} · ${esc(i.client.phone)}</div><div class="s">${fmt(i.date)}${c.repair+c.follow?` · ⚠ ${c.repair+c.follow} بند للمتابعة/الإصلاح`:''}</div></div><span class="badge" style="--c:${i.status==='complete'?'#246BFD':'#667085'}">${i.status==='complete'?'مكتمل':'مسودة'}</span></button>`}

/* ---------- state & navigation ---------- */
let INS=null,PH=[],stack=[{v:'home',p:{}}],saveT=null,CURI=null,PDFS={};
const VIEWS={};
function updateNav(){const v=stack[stack.length-1].v;const tabs={home:'home',history:'history',reminders:'reminders',settings:'settings'};
document.querySelectorAll('#nav button').forEach(b=>b.classList.toggle('on',b.dataset.t===tabs[v]));
const full=['form','check','section','summary','report','remForm','credits'].includes(v);document.body.classList.toggle('hidenav',full)}
async function render(){const t=stack[stack.length-1];const h=await VIEWS[t.v](t.p||{});$('#app').innerHTML=h;$('#app').scrollTop=0;updateNav()}
const go=async(v,p)=>{await flushSave();stack.push({v,p:p||{}});await render()};
const goTab=async v=>{await flushSave();stack=[{v,p:{}}];await render()};
const rep=async(v,p)=>{stack[stack.length-1]={v,p:p||{}};await render()};
const back=async()=>{await flushSave();if(stack.length>1)stack.pop();await render()};

/* ---------- autosave ---------- */
function ind(m){const e=$('#saveInd');if(e)e.textContent=m}
function scheduleSave(){clearTimeout(saveT);ind('جارٍ الحفظ…');saveT=setTimeout(()=>saveIns(),400)}
async function saveIns(){clearTimeout(saveT);saveT=null;if(!INS)return true;INS.updatedAt=Date.now();
try{await dbPut('inspections',INS);ind('تم الحفظ تلقائيًا ✓');return true}catch(e){ind('تعذر الحفظ');toast('تعذر الحفظ: '+(e.message||'تحقق من مساحة التخزين'),'err');return false}}
async function flushSave(){if(saveT)await saveIns()}
async function loadIns(id){const i=await dbGet('inspections',id);if(!i)throw new Error('السجل غير موجود');INS=i;PH=await photosOf(id)}

/* ---------- views ---------- */
VIEWS.home=async()=>{const all=(await dbAll('inspections')).sort((a,b)=>b.date-a.date);
const done=all.filter(i=>i.status==='complete').length,dr=all.length-done,fl=all.filter(i=>i.items.some(x=>x.status==='follow'||x.status==='repair')).length;
return `${topBar('فحصتي','فحص السيارات وتقارير الصيانة')}
<div class="grid3"><div class="glass stat"><b>${done}</b><span>مكتملة</span></div><div class="glass stat"><b>${dr}</b><span>غير مكتملة</span></div><div class="glass stat"><b>${fl}</b><span>تحتاج متابعة</span></div></div>
<div class="pad"><button class="btn primary big" data-act="newIns">+ فحص سيارة جديدة</button>
<div class="row"><button class="btn" data-act="tab" data-t="history">سجل الفحوصات</button><button class="btn" data-act="tab" data-t="reminders">التذكيرات</button><button class="btn" data-act="tab" data-t="settings">الإعدادات</button></div>
<h2>أحدث الفحوصات</h2>${all.length?all.slice(0,8).map(insCard).join(''):'<div class="glass empty">لا توجد فحوصات بعد. ابدأ بـ «فحص سيارة جديدة».</div>'}</div>`};

VIEWS.form=async(p)=>{const all=(await dbAll('inspections')).sort((a,b)=>b.date-a.date);const seen={};const opts=[];
all.forEach(i=>{const k=i.client.phone+'|'+(i.car.plate||i.car.model);if(!seen[k]){seen[k]=1;opts.push(i)}});
window.__prev=opts;const f=p.prefill||{client:{},car:{}};const c=f.client||{},k=f.car||{};
const inp=(id,l,v,ex='')=>`<label>${l}</label><input id="${id}" value="${esc(v||'')}" ${ex}>`;
return `${topBar('فحص سيارة جديدة','بيانات العميل والسيارة',true)}<div class="pad">
${opts.length?`<div class="glass card"><label>إعادة فحص سيارة سابقة (اختياري)</label><select id="prevSel"><option value="">— اختر من السجلات —</option>${opts.map((i,n)=>`<option value="${n}">${esc(i.client.name)} — ${esc(carLine(i))} — ${esc(i.car.plate)}</option>`).join('')}</select><div class="note">تُملأ البيانات المعروفة ويمكن تعديلها، ويُنشأ فحص جديد مستقل دون المساس بالتقارير القديمة.</div></div>`:''}
<div class="glass card"><b>بيانات العميل</b>${inp('fName','اسم العميل',c.name)}${inp('fPhone','رقم هاتف العميل *',c.phone,'type="tel" inputmode="tel"')}<label>ملاحظات أولية</label><textarea id="fNotes">${esc(c.notes||'')}</textarea></div>
<div class="glass card"><b>بيانات السيارة</b>${inp('fBrand','ماركة السيارة',k.brand)}${inp('fModel','موديل السيارة',k.model)}${inp('fYear','سنة الصنع',k.year,'inputmode="numeric"')}${inp('fPlate','رقم اللوحة',k.plate)}${inp('fKm','قراءة العداد (كم)',k.km,'inputmode="numeric"')}${inp('fVin','رقم الشاسيه VIN',k.vin,'dir="ltr"')}</div>
<div id="fErr" class="err"></div>
<button class="btn primary big" data-act="saveForm">بدء الفحص</button></div>`};

const secStats=si=>{const it=INS.items.filter(x=>x.section===si);const c=cnt(it);return{it,c,done:it.length-c.none}};
VIEWS.check=async()=>{const c=cnt(INS.items),tot=INS.items.length,done=tot-c.none;
return `${topBar(INS.client.name||'فحص','',true)}<div class="pad"><div class="glass card"><b>${esc(carLine(INS))} — ${esc(INS.car.plate)}</b><div class="note">${esc(INS.client.phone)} · ${fmt(INS.date)}</div>
<div class="bar"><i style="width:${tot?done/tot*100:0}%"></i></div><div class="note">تم فحص ${done} من ${tot} بند</div><div id="saveInd" class="ind">محفوظ كمسودة</div></div>
${INS.sections.map((n,si)=>{const s=secStats(si);return `<button class="glass item" data-act="openSec" data-i="${si}"><div><div class="t">${esc(n)}</div><div class="s">${s.done}/${s.it.length} · <span style="color:#16A36A">${s.c.ok} سليم</span> · <span style="color:#F59E0B">${s.c.follow} متابعة</span> · <span style="color:#DC2626">${s.c.repair} إصلاح</span></div></div><span>›</span></button>`}).join('')}
<div class="row"><button class="btn" data-act="saveDraft">حفظ كمسودة</button><button class="btn primary" data-act="toSummary">ملخص وإنهاء</button></div></div>`};

VIEWS.section=async(p)=>{const si=p.i,it=INS.items.filter(x=>x.section===si);
return `${topBar(INS.sections[si],INS.client.name,true)}<div class="pad"><div id="saveInd" class="ind"></div>
${it.map(x=>{const n=PH.filter(q=>q.itemId===x.id).length;return `<button class="glass item" data-act="openItem" data-id="${x.id}"><div><div class="t">${esc(x.name)}${x.custom?' <span class="tag">مخصص</span>':''}</div><div class="s">${n?'📷 '+n+' ':''}${x.notes?esc(x.notes.slice(0,40)):''}</div></div>${badge(x.status)}</button>`}).join('')}
<button class="btn" data-act="addItem" data-i="${si}">+ إضافة بند مخصص</button></div>`};

VIEWS.summary=async()=>{const c=cnt(INS.items);const imp=INS.items.filter(x=>x.status==='follow'||x.status==='repair');const un=INS.items.filter(x=>x.status==='none');
return `${topBar('ملخص الفحص',INS.client.name,true)}<div class="pad"><div id="saveInd" class="ind"></div>
<div class="grid3" style="margin:0 0 12px"><div class="glass stat"><b style="color:#16A36A">${c.ok}</b><span>سليم</span></div><div class="glass stat"><b style="color:#F59E0B">${c.follow}</b><span>متابعة</span></div><div class="glass stat"><b style="color:#DC2626">${c.repair}</b><span>إصلاح</span></div></div>
<div class="glass stat" style="margin-bottom:12px"><b style="color:#667085">${c.none}</b><span>لم يتم فحصها</span></div>
${un.length?`<div class="warn"><b>بنود لم يتم فحصها (${un.length}):</b><br>${un.map(x=>esc(INS.sections[x.section]+' ← '+x.name)).join('<br>')}</div>`:''}
<h2>الملاحظات المهمة</h2>${imp.length?imp.map(x=>`<div class="glass card"><div class="t"><b>${esc(x.name)}</b> ${badge(x.status)}</div><div class="note">${esc(INS.sections[x.section])}${x.loc?' · الموضع: '+esc(x.loc):''}</div>${x.notes?`<div>${esc(x.notes)}</div>`:''}<div class="pgrid">${PH.filter(q=>q.itemId===x.id).map(q=>`<img class="full" style="height:100px;object-fit:cover" src="${q.data}">`).join('')}</div></div>`).join(''):'<div class="glass empty">لا توجد بنود مسجلة للمتابعة أو الإصلاح.</div>'}
<h2>التوصيات (يحددها المهندس)</h2><div class="glass card">${INS.recs.map(r=>`<div style="display:flex;justify-content:space-between;gap:8px;margin-bottom:8px"><div><span class="tag">${PRI[r.priority]}</span> ${esc(r.text)}</div><button class="x" data-act="delRec" data-id="${r.id}">✕</button></div>`).join('')||'<div class="note">لا توجد توصيات.</div>'}
<label>توصية جديدة</label><textarea id="recT" style="min-height:60px"></textarea><label>الأولوية</label><select id="recP"><option value="urgent">عاجل</option><option value="soon" selected>قريبًا</option><option value="periodic">متابعة دورية</option></select><button class="btn" data-act="addRec">+ إضافة توصية</button></div>
<label>الملاحظات النهائية</label><textarea id="finalN">${esc(INS.finalNotes||'')}</textarea>
<div class="note" style="margin-top:8px">التطبيق لا يشخّص الأعطال ولا يصدر حكمًا على صلاحية السيارة؛ كل ما يظهر هو ما سجّله المهندس.</div>
<div class="row"><button class="btn" data-act="saveDraft">حفظ كمسودة</button><button class="btn primary" data-act="finish">اعتماد وإنشاء التقرير</button></div></div>`};

VIEWS.report=async()=>{const c=cnt(INS.items);const pdf=PDFS[INS.id];
return `${topBar('التقرير',INS.status==='complete'?'فحص مكتمل':'مسودة',true)}<div class="pad">
<div class="glass card"><b>${esc(INS.client.name)}</b> · ${esc(INS.client.phone)}<div class="note">${esc(carLine(INS))} · لوحة: ${esc(INS.car.plate)} · ${fmt(INS.date)}</div>
<div style="margin-top:8px">${badge('ok')} ${c.ok} ${badge('follow')} ${c.follow} ${badge('repair')} ${c.repair} ${badge('none')} ${c.none}</div></div>
${INS.status!=='complete'?'<div class="warn">هذه مسودة وليست تقريرًا نهائيًا.</div>':''}
<button class="btn primary" data-act="mkPdf">إنشاء التقرير (PDF)</button>
<div class="row"><button class="btn" data-act="prevPdf">معاينة PDF</button><button class="btn" data-act="savePdf">حفظ PDF</button></div>
<button class="btn" data-act="sharePdf">مشاركة التقرير</button>
<div class="note" id="pdfInfo">${pdf?`آخر ملف: ${esc(pdf.name)} (${Math.round(pdf.size/1024)} ك.ب)`:'لم يُنشأ ملف PDF بعد.'}</div>
<h2>إجراءات</h2>
${INS.status==='complete'?'<button class="btn" data-act="reopen">تعديل الفحص (إعادته كمسودة)</button>':'<button class="btn" data-act="resume">استكمال الفحص</button>'}
<button class="btn" data-act="reNew">فحص جديد لنفس السيارة</button><button class="btn" data-act="remFor">+ تذكير مرتبط بهذا التقرير</button>
<button class="btn danger" data-act="delIns">حذف هذا الفحص</button>
<h2>تفاصيل البنود المسجلة</h2>${INS.items.filter(x=>x.status!=='none'||x.notes||PH.some(q=>q.itemId===x.id)).map(x=>`<div class="glass card"><b>${esc(x.name)}</b> ${badge(x.status)}<div class="note">${esc(INS.sections[x.section])}</div>${x.loc?`<div>الموضع: ${esc(x.loc)}</div>`:''}${x.notes?`<div>${esc(x.notes)}</div>`:''}<div class="pgrid">${PH.filter(q=>q.itemId===x.id).map(q=>`<img class="full" style="height:100px;object-fit:cover" src="${q.data}">`).join('')}</div></div>`).join('')||'<div class="glass empty">لا توجد بنود مسجلة.</div>'}</div>`};

VIEWS.history=async(p)=>{const q=normD(p.q||'').toLowerCase().trim();let all=(await dbAll('inspections')).sort((a,b)=>b.date-a.date);
if(q)all=all.filter(i=>[i.client.name,i.client.phone,i.car.plate,i.car.brand,i.car.model].some(v=>normD(v||'').toLowerCase().includes(q)));
return `${topBar('سجل الفحوصات',all.length+' سجل')}<div class="pad"><input id="hq" placeholder="بحث: هاتف، اسم، لوحة، ماركة، موديل" value="${esc(p.q||'')}"><div id="hlist" style="margin-top:12px">${all.map(insCard).join('')||'<div class="glass empty">لا توجد نتائج.</div>'}</div></div>`};

const remStat=r=>r.canceled?'canceled':(new Date(r.at)<new Date()?'over':'up');
function remCard(r){const s=remStat(r);return `<div class="glass card"><div class="t"><b>${esc(r.reason)}</b> ${s==='over'?'<span class="badge" style="--c:#DC2626">متأخر</span>':s==='canceled'?'<span class="badge">ملغى</span>':''}</div><div class="note">${fmt(r.at)}${r.label?' · '+esc(r.label):''}</div>
<div class="row"><button class="btn" data-act="remEdit" data-id="${r.id}">تعديل</button>${s!=='canceled'?`<button class="btn" data-act="remCancel" data-id="${r.id}">إلغاء التذكير</button>`:''}<button class="btn danger" data-act="remDel" data-id="${r.id}">حذف</button></div></div>`}
VIEWS.reminders=async()=>{const all=(await dbAll('reminders')).sort((a,b)=>new Date(a.at)-new Date(b.at));
const g=s=>all.filter(r=>remStat(r)===s);
return `${topBar('التذكيرات',all.length+' تذكير')}<div class="pad"><button class="btn primary" data-act="remNew">+ تذكير جديد</button>
<h2>متأخرة</h2>${g('over').map(remCard).join('')||'<div class="note">لا يوجد.</div>'}<h2>قادمة</h2>${g('up').map(remCard).join('')||'<div class="note">لا يوجد.</div>'}<h2>ملغاة</h2>${g('canceled').map(remCard).join('')||'<div class="note">لا يوجد.</div>'}
<div class="note">الإشعارات تعتمد على أذونات النظام وقيود البطارية؛ قائمة التذكيرات هنا تبقى محفوظة حتى لو لم يظهر الإشعار، ولا يوجد ضمان لوصوله.</div></div>`};

VIEWS.remForm=async(p)=>{const r=p.r||{};const all=(await dbAll('inspections')).sort((a,b)=>b.date-a.date);
const d=r.at?new Date(new Date(r.at)-new Date(r.at).getTimezoneOffset()*60000).toISOString().slice(0,16):'';
return `${topBar(r.id?'تعديل التذكير':'تذكير جديد','',true)}<div class="pad"><div class="glass card">
<label>العميل / السيارة / التقرير (اختياري)</label><select id="rIns"><option value="">— بدون ربط —</option>${all.map(i=>`<option value="${i.id}" ${r.inspectionId===i.id||p.insId===i.id?'selected':''}>${esc(i.client.name)} — ${esc(carLine(i))} — ${esc(i.car.plate)} (${fmt(i.date)})</option>`).join('')}</select>
<label>سبب التذكير *</label><textarea id="rWhy">${esc(r.reason||'')}</textarea><label>التاريخ والوقت *</label><input type="datetime-local" id="rAt" value="${d}">
<div id="rErr" class="err"></div></div><button class="btn primary big" data-act="remSave" data-id="${r.id||''}">حفظ التذكير</button></div>`};

VIEWS.settings=async()=>{const s={c:await getSet('center',''),e:await getSet('engineer',''),b:await getSet('lastBackup',null)};
return `${topBar('الإعدادات')}<div class="pad"><div class="glass card"><label>اسم مركز الصيانة</label><input id="sCenter" value="${esc(s.c)}"><label>اسم المهندس (اختياري)</label><input id="sEng" value="${esc(s.e)}"><button class="btn primary" data-act="saveSettings">حفظ الإعدادات</button></div>
<h2>التذكيرات والإشعارات</h2><div class="glass card"><button class="btn" data-act="tab" data-t="reminders">إدارة التذكيرات</button><button class="btn" data-act="notifPerm">طلب إذن الإشعارات / فحص حالته</button></div>
<h2>النسخ الاحتياطي</h2><div class="glass card"><div class="note">آخر نسخة احتياطية: ${s.b?fmt(s.b):'لا توجد'}</div><div class="warn">البيانات محفوظة محليًا على هذا الجهاز فقط. فقدان الهاتف أو حذف التطبيق قد يؤدي إلى فقدانها إن لم توجد نسخة احتياطية صالحة.</div>
<button class="btn" data-act="exportBk">تصدير نسخة احتياطية</button><button class="btn" data-act="restoreBk">استعادة نسخة احتياطية</button><input type="file" id="bkFile" accept=".json,application/json" style="display:none"></div>
<h2>عن التطبيق</h2><div class="glass card"><div class="note">فحصتي — الإصدار 1.0.0<br>يعمل دون إنترنت ويحفظ بياناته محليًا. لا يشخّص الأعطال؛ المهندس هو المسؤول عن تحديد الحالة والتوصيات.</div><button class="btn" data-act="credits">حقوق التطبيق</button></div></div>`};

VIEWS.credits=async()=>`${topBar('حقوق التطبيق','',true)}<div class="pad"><div class="glass credit"><h3>APP CREDITS</h3><div class="sub">Designed by</div><div class="nm">Hamo Atef</div><div class="sub" style="margin-top:6px">MA Graphic Designer</div>
<div style="margin:18px 0 6px">للتواصل:</div><div id="cPhone" style="font-size:22px;font-weight:800;direction:ltr">${CREDIT_PHONE}</div>
<button class="btn primary" data-act="copyPhone">نسخ الرقم</button><a class="btn" style="text-decoration:none;text-align:center" href="tel:${CREDIT_PHONE}">اتصال</a>
<hr style="border:0;border-top:1px solid #dbe3f2;margin:18px 0"><div>فحصتي — تطبيق فحص السيارات</div><div style="direction:ltr;color:#667085;margin-top:6px">© 2026 Hamo Atef. All Rights Reserved.</div></div><button class="btn" data-act="back">رجوع</button></div>`;

/* ---------- photos ---------- */
async function toDataUrl(src,max=1280){const blob=src.startsWith('data:')?await (await fetch(src)).blob():await (await fetch(src)).blob();
const bmp=await createImageBitmap(blob);const sc=Math.min(1,max/Math.max(bmp.width,bmp.height));const cv=document.createElement('canvas');cv.width=Math.round(bmp.width*sc);cv.height=Math.round(bmp.height*sc);
cv.getContext('2d').drawImage(bmp,0,0,cv.width,cv.height);return cv.toDataURL('image/jpeg',0.72)}
async function addPhotos(src,replaceId){const Cam=P('Camera');if(!Cam){toast('الكاميرا متاحة على أندرويد فقط','err');return}
let urls=[];
try{if(src==='camera'){const r=await Cam.getPhoto({quality:70,width:1280,allowEditing:false,resultType:'dataUrl',source:'CAMERA'});urls=[await toDataUrl(r.dataUrl)]}
else{const r=await Cam.pickImages({quality:70,width:1280,limit:replaceId?1:10});for(const p of r.photos)urls.push(await toDataUrl(p.webPath))}}
catch(e){const m=String(e&&e.message||e);if(/cancel/i.test(m))return;if(/permission|denied/i.test(m)){toast('تم رفض إذن الكاميرا/الصور. فعّله من إعدادات الهاتف','err');return}toast('تعذر الحصول على الصورة: '+m,'err');return}
if(!urls.length)return;
const ok=await dialog(`<b>معاينة قبل الحفظ</b><div class="pgrid" style="margin-top:10px">${urls.map(u=>`<img class="full" style="height:110px;object-fit:cover" src="${u}">`).join('')}</div>`,[{t:'إلغاء',v:false},{t:'حفظ',v:true,cls:'primary'}]);
if(!ok)return;
const added=[];try{for(const u of urls){const rec={id:uid(),inspectionId:INS.id,itemId:CURI,data:u,t:Date.now()};await dbPut('photos',rec);added.push(rec)}}
catch(e){toast('تعذر حفظ الصورة: '+(e.message||'مساحة التخزين غير كافية'),'err');return}
PH.push(...added);if(replaceId){await dbDel('photos',replaceId);PH=PH.filter(p=>p.id!==replaceId)}
toast('تم حفظ الصورة','ok');itemSheet(CURI)}

function itemSheet(id){const it=INS.items.find(x=>x.id===id);if(!it)return;CURI=id;const ph=PH.filter(p=>p.itemId===id);
openSheet(`<div class="sh-h"><b>${esc(it.name)}</b><button class="x" data-act="closeSheet">✕</button></div>
${it.custom?`<label>اسم البند</label><input id="iName" value="${esc(it.name)}">`:''}
<label>الحالة</label><div class="chips">${Object.keys(ST).map(k=>`<button class="chip ${it.status===k?'on':''}" style="--c:${ST[k][1]}" data-act="setSt" data-k="${k}">${ST[k][0]}</button>`).join('')}</div>
<label>موضع المشكلة</label><input id="iLoc" value="${esc(it.loc)}"><label>الملاحظات</label><textarea id="iNotes">${esc(it.notes)}</textarea>
<label>الصور (${ph.length})</label><div class="pgrid">${ph.map(p=>`<div class="ph"><img src="${p.data}" data-act="viewPh" data-id="${p.id}"><div><button data-act="repPh" data-id="${p.id}">استبدال</button><button data-act="delPh" data-id="${p.id}">حذف</button></div></div>`).join('')}</div>
<div class="row"><button class="btn" data-act="addCam">📷 كاميرا</button><button class="btn" data-act="addGal">🖼️ المعرض</button></div>
${it.custom?'<button class="btn danger" data-act="delItem">حذف البند</button>':''}<button class="btn primary" data-act="closeSheet">تم</button><div id="saveInd" class="ind"></div>`)}

/* ---------- PDF ---------- */
const dLines=s=>esc(s).replace(/\n/g,'<br>');
function buildHtml(i,ph,center,eng){const c=cnt(i.items);
const sec=i.sections.map((n,si)=>{const it=i.items.filter(x=>x.section===si);return `<h3>${esc(n)}</h3>${it.map(x=>{const pp=ph.filter(q=>q.itemId===x.id);return `<div class="it"><div class="h"><span>${esc(x.name)}</span><b style="color:${ST[x.status][1]}">● ${ST[x.status][0]}</b></div>${x.loc?`<div class="m">موضع المشكلة: ${esc(x.loc)}</div>`:''}${x.notes?`<div class="m">${dLines(x.notes)}</div>`:''}${pp.length?`<div class="ps">${pp.map(q=>`<img src="${q.data}">`).join('')}</div>`:''}</div>`}).join('')}`}).join('');
const un=i.items.filter(x=>x.status==='none');
return `<!DOCTYPE html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><style>
body{font-family:'Noto Naskh Arabic','Noto Sans Arabic','Droid Arabic Naskh',sans-serif;direction:rtl;font-size:12px;color:#101828;margin:0;padding:4px;line-height:1.7}
.hd{background:#101828;color:#fff;padding:12px 16px;border-radius:10px}.hd h1{margin:0;font-size:22px}.hd div{color:#c9d6f2}
table{width:100%;border-collapse:collapse;margin:10px 0}td{border:1px solid #dbe3f2;padding:5px 8px}td.k{background:#f4f7fb;width:28%;font-weight:bold}
h2{color:#246BFD;border-bottom:2px solid #246BFD;margin:16px 0 6px;font-size:15px}h3{background:#f4f7fb;padding:4px 8px;margin:12px 0 4px;font-size:13px;border-right:4px solid #246BFD}
.it{border-bottom:1px solid #e4e9f2;padding:5px 2px;page-break-inside:avoid}.h{display:flex;justify-content:space-between}.m{color:#475467;font-size:11.5px}
.ps img{width:46%;max-height:170px;object-fit:contain;margin:3px;border:1px solid #dbe3f2}.sm span{margin-left:14px;font-weight:bold}.ft{margin-top:20px;border-top:1px solid #999;padding-top:6px}
</style></head><body>
<div class="hd"><h1>فحصتي — تقرير فحص سيارة</h1>${center?`<div>${esc(center)}</div>`:''}</div>
<table><tr><td class="k">العميل</td><td>${esc(i.client.name)}</td><td class="k">الهاتف</td><td dir="ltr" style="text-align:right">${esc(i.client.phone)}</td></tr>
<tr><td class="k">الماركة والموديل</td><td>${esc([i.car.brand,i.car.model].filter(Boolean).join(' '))}</td><td class="k">سنة الصنع</td><td>${esc(i.car.year)}</td></tr>
<tr><td class="k">رقم اللوحة</td><td>${esc(i.car.plate)}</td><td class="k">قراءة العداد</td><td>${esc(i.car.km)}${i.car.km?' كم':''}</td></tr>
<tr><td class="k">رقم الشاسيه</td><td dir="ltr" style="text-align:right">${esc(i.car.vin)}</td><td class="k">تاريخ الفحص</td><td>${fmt(i.date)}</td></tr>
${eng?`<tr><td class="k">المهندس</td><td colspan="3">${esc(eng)}</td></tr>`:''}${i.client.notes?`<tr><td class="k">ملاحظات أولية</td><td colspan="3">${dLines(i.client.notes)}</td></tr>`:''}</table>
<h2>ملخص النتائج</h2><div class="sm"><span style="color:#16A36A">سليم: ${c.ok}</span><span style="color:#F59E0B">يحتاج متابعة: ${c.follow}</span><span style="color:#DC2626">يحتاج إصلاح: ${c.repair}</span><span style="color:#667085">لم يتم الفحص: ${c.none}</span></div>
${i.status!=='complete'?'<p style="color:#DC2626">تنبيه: هذه مسودة وليست تقريرًا نهائيًا.</p>':''}
<h2>تفاصيل الفحص</h2>${sec}
<h2>التوصيات</h2>${i.recs.length?i.recs.map(r=>`<div class="it"><b>[${PRI[r.priority]}]</b> ${dLines(r.text)}</div>`).join(''):'<div class="m">لا توجد توصيات مسجلة.</div>'}
<h2>البنود التي لم يتم فحصها</h2>${un.length?un.map(x=>`<div class="m">• ${esc(i.sections[x.section])} — ${esc(x.name)}</div>`).join(''):'<div class="m">لا توجد.</div>'}
<h2>الملاحظات النهائية</h2><div>${i.finalNotes?dLines(i.finalNotes):'—'}</div>
<div class="ft">هذا التقرير يعرض ما سجّله المهندس فقط ولا يمثل حكمًا آليًا على صلاحية السيارة للطريق.${eng?`<br><b>المهندس: ${esc(eng)}</b>`:''}</div></body></html>`}
const pdfName=i=>{const s=x=>String(x||'').replace(/[^\w\u0600-\u06FF-]+/g,'_').replace(/^_+|_+$/g,'');return `Fahsati_${s(i.car.plate)||'car'}_${new Date(i.date).toISOString().slice(0,10)}_${i.id.slice(-4)}.pdf`};
async function ensurePdf(force){await flushSave();const old=PDFS[INS.id];if(old&&!force&&old.t>(INS.updatedAt||0))return old;
const M=P('PdfMaker');if(!M||!(window.Capacitor&&Capacitor.isNativePlatform&&Capacitor.isNativePlatform()))throw new Error('إنشاء PDF متاح على أندرويد فقط');
const html=buildHtml(INS,PH,await getSet('center',''),await getSet('engineer',''));const name=pdfName(INS);
const r=await M.htmlToPdf({html,fileName:name});if(!r||!r.valid||!(r.size>0))throw new Error('الملف الناتج غير صالح');
PDFS[INS.id]={path:r.path,name,size:r.size,t:Date.now()};const e=$('#pdfInfo');if(e)e.textContent=`آخر ملف: ${name} (${Math.round(r.size/1024)} ك.ب)`;return PDFS[INS.id]}

/* ---------- reminders ---------- */
async function nextNid(){const n=(await getSet('nid',1000))+1;await setSet('nid',n);return n}
async function schedule(r){const LN=P('LocalNotifications');if(!LN||r.canceled||new Date(r.at)<=new Date())return false;
try{let p=await LN.checkPermissions();if(p.display!=='granted')p=await LN.requestPermissions();if(p.display!=='granted')return false;
await LN.schedule({notifications:[{id:r.nid,title:'فحصتي — تذكير',body:r.reason,schedule:{at:new Date(r.at),allowWhileIdle:true}}]});return true}catch(e){console.warn(e);return false}}
async function unschedule(r){try{const LN=P('LocalNotifications');if(LN&&r.nid)await LN.cancel({notifications:[{id:r.nid}]})}catch(e){}}

/* ---------- backup ---------- */
async function buildBackup(){const d={};for(const s of ['clients','cars','inspections','photos','reminders','settings'])d[s]=await dbAll(s);return JSON.stringify({app:'fahsati',version:1,exportedAt:new Date().toISOString(),counts:Object.fromEntries(Object.keys(d).map(k=>[k,d[k].length])),data:d})}

/* ---------- actions ---------- */
const ACT={};
ACT.tab=(d)=>goTab(d.t);
ACT.back=()=>back();
ACT.newIns=()=>go('form',{});
ACT.openIns=once(async d=>{await loadIns(d.id);await go(INS.status==='complete'?'report':'check')});
ACT.saveForm=once(async()=>{const v=id=>($('#'+id).value||'').trim();const e=$('#fErr');const phone=normD(v('fPhone'));
if(!phone){e.textContent='رقم هاتف العميل مطلوب قبل الحفظ.';e.className='err on';return}
if(!validPhone(phone)){e.textContent='رقم الهاتف غير صحيح. أدخل رقمًا مصريًا مثل 01012345678 أو رقمًا دوليًا يبدأ بـ +.';e.className='err on';return}
e.className='err';const client={name:v('fName'),phone,notes:v('fNotes')},car={brand:v('fBrand'),model:v('fModel'),year:normD(v('fYear')),plate:v('fPlate'),km:normD(v('fKm')),vin:v('fVin')};
const clients=await dbAll('clients');let cl=clients.find(c=>c.phone===phone);if(!cl)cl={id:uid(),created:Date.now()};cl.phone=phone;if(client.name)cl.name=client.name;await dbPut('clients',cl);
const cars=await dbAll('cars');let ca=cars.find(c=>c.clientId===cl.id&&(car.plate?c.plate===car.plate:(!c.plate&&c.brand===car.brand&&c.model===car.model)));if(!ca)ca={id:uid(),clientId:cl.id};Object.assign(ca,car);await dbPut('cars',ca);
const items=[];TEMPLATE.forEach((s,si)=>s.i.forEach((n,ii)=>items.push({id:`s${si}i${ii}`,section:si,name:n,status:'none',notes:'',loc:'',custom:false})));
INS={id:uid(),clientId:cl.id,carId:ca.id,client,car,date:Date.now(),status:'draft',sections:TEMPLATE.map(s=>s.n),items,recs:[],finalNotes:'',updatedAt:Date.now()};PH=[];
await dbPut('inspections',INS);toast('تم إنشاء الفحص وحفظه كمسودة','ok');await rep('check')});
ACT.openSec=d=>go('section',{i:+d.i});
ACT.openItem=d=>itemSheet(d.id);
ACT.closeSheet=async()=>{await flushSave();closeSheetEl();await render()};
ACT.setSt=d=>{const it=INS.items.find(x=>x.id===CURI);it.status=d.k;scheduleSave();itemSheet(CURI)};
ACT.addCam=once(()=>addPhotos('camera'));ACT.addGal=once(()=>addPhotos('gallery'));
ACT.repPh=once(async d=>{const ok=await confirmD('سيتم استبدال هذه الصورة بصورة جديدة بعد اختيارها. متابعة؟');if(ok)await addPhotos('camera',d.id)});
ACT.delPh=async d=>{if(!await confirmD('هل تريد حذف هذه الصورة؟','حذف'))return;await dbDel('photos',d.id);PH=PH.filter(p=>p.id!==d.id);itemSheet(CURI)};
ACT.viewPh=d=>{const p=PH.find(x=>x.id===d.id);dialog(`<img class="full" src="${p.data}">`,[{t:'إغلاق',v:1}])};
ACT.addItem=async d=>{const n=await new Promise(res=>{$('#dlg').innerHTML=`<div class="dbox"><b>بند مخصص جديد</b><input id="nn" placeholder="اسم البند" style="margin-top:10px"><div class="row" style="margin-top:10px"><button class="btn" id="nc">إلغاء</button><button class="btn primary" id="no">إضافة</button></div></div>`;$('#dlg').classList.add('on');const c=v=>{$('#dlg').classList.remove('on');$('#dlg').innerHTML='';res(v)};$('#dlg').onclick=null;$('#nc').onclick=()=>c(null);$('#no').onclick=()=>c($('#nn').value.trim())});
if(!n)return;INS.items.push({id:'c'+uid(),section:+d.i,name:n,status:'none',notes:'',loc:'',custom:true});if(!await saveIns())return;await render()};
ACT.delItem=async()=>{if(!await confirmD('حذف هذا البند المخصص وصوره؟','حذف'))return;for(const p of PH.filter(p=>p.itemId===CURI))await dbDel('photos',p.id);PH=PH.filter(p=>p.itemId!==CURI);INS.items=INS.items.filter(x=>x.id!==CURI);await saveIns();closeSheetEl();await render()};
ACT.saveDraft=once(async()=>{if(!await saveIns())return;const chk=await dbGet('inspections',INS.id);if(!chk){toast('تعذر التأكد من الحفظ','err');return}toast('تم حفظ المسودة','ok');await goTab('home')});
ACT.toSummary=()=>go('summary');
ACT.addRec=async()=>{const t=$('#recT').value.trim();if(!t){toast('اكتب نص التوصية أولًا','err');return}INS.finalNotes=$('#finalN').value;INS.recs.push({id:uid(),text:t,priority:$('#recP').value});if(await saveIns())await render()};
ACT.delRec=async d=>{INS.finalNotes=$('#finalN').value;INS.recs=INS.recs.filter(r=>r.id!==d.id);if(await saveIns())await render()};
ACT.finish=once(async()=>{INS.finalNotes=$('#finalN').value;const un=INS.items.filter(x=>x.status==='none').length;
if(un&&!await confirmD(`يوجد ${un} بند لم يتم فحصه وسيظهر في التقرير كـ «لم يتم الفحص». هل تريد الاعتماد؟`,'اعتماد'))return;
INS.status='complete';INS.completedAt=Date.now();if(!await saveIns()){INS.status='draft';return}toast('تم اعتماد الفحص','ok');stack=[{v:'home',p:{}}];await go('report')});
ACT.resume=async()=>rep('check');
ACT.reopen=async()=>{if(!await confirmD('سيعود الفحص إلى مسودة للتعديل، ثم يلزم اعتماده من جديد. متابعة؟'))return;INS.status='draft';delete PDFS[INS.id];await saveIns();await rep('check')};
ACT.reNew=()=>go('form',{prefill:{client:{...INS.client,notes:''},car:{...INS.car,km:''}}});
ACT.delIns=once(async()=>{if(!await confirmD('سيتم حذف الفحص وجميع صوره نهائيًا. هل أنت متأكد؟','حذف نهائي'))return;await delInspection(INS.id);INS=null;PH=[];toast('تم الحذف','ok');await goTab('history')});
ACT.mkPdf=once(async()=>{const p=await ensurePdf(true);toast('تم إنشاء ملف PDF بنجاح','ok')});
ACT.prevPdf=once(async()=>{const p=await ensurePdf();try{await P('PdfMaker').openPdf({path:p.path})}catch(e){toast('لا يوجد تطبيق لعرض PDF على الجهاز. استخدم المشاركة أو الحفظ.','err')}});
ACT.savePdf=once(async()=>{const p=await ensurePdf();const r=await P('PdfMaker').saveToDownloads({path:p.path,name:p.name,mime:'application/pdf'});toast('تم حفظ الملف في: '+r.location,'ok')});
ACT.sharePdf=once(async()=>{const p=await ensurePdf();await P('Share').share({title:'تقرير فحص سيارة',dialogTitle:'مشاركة التقرير',files:['file://'+p.path]})});
ACT.remNew=()=>go('remForm',{});
ACT.remFor=()=>go('remForm',{insId:INS.id});
ACT.remEdit=async d=>go('remForm',{r:await dbGet('reminders',d.id)});
ACT.remSave=once(async d=>{const why=$('#rWhy').value.trim(),at=$('#rAt').value,e=$('#rErr');if(!why||!at){e.textContent='اكتب سبب التذكير وحدد التاريخ والوقت.';e.className='err on';return}
const iid=$('#rIns').value;const ins=iid?await dbGet('inspections',iid):null;const old=d.id?await dbGet('reminders',d.id):null;
const r=Object.assign(old||{id:uid(),nid:await nextNid()},{reason:why,at:new Date(at).toISOString(),canceled:false,inspectionId:iid||null,label:ins?`${ins.client.name} — ${carLine(ins)} ${ins.car.plate}`:''});
if(old)await unschedule(old);await dbPut('reminders',r);const s=await schedule(r);
toast(s?'تم حفظ التذكير وجدولة الإشعار':'تم حفظ التذكير داخل التطبيق (لم تُجدول إشعارات النظام: الإذن غير ممنوح أو الوقت مضى)',s?'ok':'');await back()});
ACT.remCancel=async d=>{if(!await confirmD('إلغاء هذا التذكير؟','إلغاء التذكير'))return;const r=await dbGet('reminders',d.id);r.canceled=true;await unschedule(r);await dbPut('reminders',r);await render()};
ACT.remDel=async d=>{if(!await confirmD('حذف هذا التذكير نهائيًا؟','حذف'))return;const r=await dbGet('reminders',d.id);await unschedule(r);await dbDel('reminders',d.id);await render()};
ACT.saveSettings=once(async()=>{await setSet('center',$('#sCenter').value.trim());await setSet('engineer',$('#sEng').value.trim());const c=await getSet('center','');if(c!==$('#sCenter').value.trim())throw new Error('لم يتم الحفظ');toast('تم حفظ الإعدادات','ok')});
ACT.notifPerm=once(async()=>{const LN=P('LocalNotifications');if(!LN){toast('الإشعارات متاحة على أندرويد فقط','err');return}let p=await LN.checkPermissions();if(p.display!=='granted')p=await LN.requestPermissions();
toast(p.display==='granted'?'إذن الإشعارات ممنوح (لا يضمن النظام وصول كل إشعار)':'إذن الإشعارات غير ممنوح. التذكيرات تبقى ظاهرة داخل التطبيق فقط.',p.display==='granted'?'ok':'err')});
ACT.credits=()=>go('credits');
ACT.copyPhone=async()=>{try{const C=P('Clipboard');if(C&&window.Capacitor&&Capacitor.isNativePlatform())await C.write({string:CREDIT_PHONE});else await navigator.clipboard.writeText(CREDIT_PHONE);toast('تم نسخ الرقم '+CREDIT_PHONE,'ok')}catch(e){toast('تعذر نسخ الرقم','err')}};
ACT.exportBk=once(async()=>{const json=await buildBackup();const name=`Fahsati_backup_${new Date().toISOString().slice(0,19).replace(/[:T]/g,'-')}.json`;
const FS=P('Filesystem');await FS.writeFile({path:name,data:json,directory:'CACHE',encoding:'utf8'});
const st=await FS.stat({path:name,directory:'CACHE'});if(!st||!(st.size>=json.length))throw new Error('التصدير غير مكتمل');
const u=await FS.getUri({path:name,directory:'CACHE'});const abs=u.uri.replace('file://','');
let loc='';try{const r=await P('PdfMaker').saveToDownloads({path:abs,name,mime:'application/json'});loc=r.location}catch(e){}
await setSet('lastBackup',Date.now());toast('تم تصدير النسخة'+(loc?' إلى '+loc:''),'ok');
try{await P('Share').share({title:'نسخة فحصتي الاحتياطية',files:[u.uri]})}catch(e){}await render()});
ACT.restoreBk=()=>$('#bkFile').click();
async function doRestore(file){let o;try{o=JSON.parse(await file.text())}catch(e){toast('الملف تالف أو ليس نسخة احتياطية صالحة','err');return}
if(!o||o.app!=='fahsati'||o.version!==1||!o.data||!Array.isArray(o.data.inspections)){toast('ملف غير متوافق مع فحصتي','err');return}
const d=o.data,pids=new Set((d.photos||[]).map(p=>p.id));const bad=(d.photos||[]).filter(p=>!p.data||!p.data.startsWith('data:')).length;
const orphan=(d.photos||[]).filter(p=>!d.inspections.some(i=>i.id===p.inspectionId)).length;
const ok=await dialog(`<b>استعادة نسخة احتياطية</b><p style="line-height:1.9">سيتم <b>دمج</b> البيانات: تُضاف السجلات غير الموجودة فقط ولا يُحذف أو يُستبدل شيء من البيانات الحالية.<br>في الملف: ${d.inspections.length} فحص، ${(d.photos||[]).length} صورة، ${(d.reminders||[]).length} تذكير.${bad||orphan?`<br><span style="color:#DC2626">تنبيه: ${bad} صورة تالفة و${orphan} بلا فحص مرتبط ولن تُستعاد.</span>`:''}</p>`,[{t:'إلغاء',v:false},{t:'دمج',v:true,cls:'primary'}]);if(!ok)return;
busy=true;load(true);try{let add=0;for(const s of ['clients','cars','inspections','photos','reminders']){const ex=new Set((await dbAll(s)).map(x=>x.id));for(const r of (d[s]||[])){if(ex.has(r.id))continue;if(s==='photos'&&(!r.data||!d.inspections.some(i=>i.id===r.inspectionId)))continue;await dbPut(s,r);add++}}
for(const r of await dbAll('reminders'))if(!r.canceled)await schedule(r);
toast(`تمت الاستعادة: أُضيف ${add} سجل`,'ok');await render()}catch(e){toast('فشلت الاستعادة: '+e.message,'err')}finally{busy=false;load(false)}}

/* ---------- events ---------- */
document.addEventListener('click',e=>{const el=e.target.closest('[data-act]');if(!el)return;const f=ACT[el.dataset.act];if(f)Promise.resolve(f(el.dataset,el)).catch(er=>toast('حدث خطأ: '+er.message,'err'))});
document.addEventListener('input',e=>{const t=e.target;if(!INS)return;const it=INS.items.find(x=>x.id===CURI);
if(t.id==='iNotes'&&it){it.notes=t.value;scheduleSave()}else if(t.id==='iLoc'&&it){it.loc=t.value;scheduleSave()}else if(t.id==='iName'&&it){it.name=t.value||it.name;scheduleSave()}
else if(t.id==='finalN'){INS.finalNotes=t.value;scheduleSave()}});
document.addEventListener('input',e=>{if(e.target.id==='hq'){clearTimeout(window.__hq);const v=e.target.value;window.__hq=setTimeout(async()=>{const cur=stack[stack.length-1];cur.p={q:v};const h=await VIEWS.history(cur.p);const tmp=document.createElement('div');tmp.innerHTML=h;$('#hlist').innerHTML=tmp.querySelector('#hlist').innerHTML},200)}});
document.addEventListener('change',e=>{if(e.target.id==='prevSel'){const i=window.__prev[+e.target.value];if(!i)return;const set=(id,v)=>$('#'+id).value=v||'';set('fName',i.client.name);set('fPhone',i.client.phone);set('fBrand',i.car.brand);set('fModel',i.car.model);set('fYear',i.car.year);set('fPlate',i.car.plate);set('fVin',i.car.vin);set('fKm','')}
if(e.target.id==='bkFile'&&e.target.files[0]){const f=e.target.files[0];e.target.value='';doRestore(f)}});

/* ---------- init ---------- */
(async function(){try{await openDB();if(navigator.storage&&navigator.storage.persist)navigator.storage.persist().catch(()=>{});
for(const r of await dbAll('reminders'))if(!r.canceled&&new Date(r.at)>new Date())schedule(r);
const A=P('App');if(A&&A.addListener)A.addListener('backButton',async()=>{if($('#dlg').classList.contains('on'))return;if($('#sheet').classList.contains('on')){await ACT.closeSheet();return}
if(stack.length>1)await back();else A.exitApp()});
await render()}catch(e){document.body.innerHTML='<div style="padding:30px;font-family:sans-serif;direction:rtl">تعذر فتح قاعدة البيانات المحلية: '+esc(e.message)+'</div>'}})();
