'use strict';
/* ===== فحصتي — Fahsati ===== */
const $=s=>document.querySelector(s);
const PL={};
const P=n=>{if(PL[n])return PL[n];const C=window.Capacitor;if(!C)return null;PL[n]=(C.Plugins&&C.Plugins[n])||(C.registerPlugin?C.registerPlugin(n):null);return PL[n]};
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,8);
const ST={none:['لم يتم الفحص','#7A847C'],ok:['سليم','#3DDC84'],follow:['يحتاج متابعة','#F5A524'],repair:['يحتاج إصلاح','#FF5C5C']};
const TST={not_started:['لم يبدأ الإصلاح','#7A847C'],in_progress:['جارٍ الإصلاح','#F5A524'],done:['تم الإصلاح','#3DDC84'],recheck:['يحتاج إعادة فحص','#B8F34A']};
const tBadge=k=>`<span class="badge" style="--c:${TST[k]?TST[k][1]:'#7A847C'}">${TST[k]?TST[k][0]:k}</span>`;
const PRI={urgent:'عاجل',soon:'قريبًا',periodic:'متابعة دورية'};
const CREDIT_PHONE='01271323579';
const TEMPLATE=[
{n:'المحرك',i:['صوت المحرك وثبات الدوران','تسريب زيت المحرك','حالة السيور','قواعد (وسائد) المحرك','دخان العادم','أداء التشغيل والتسارع']},
{n:'ناقل الحركة والفتيس',i:['نعومة تغيير السرعات','زيت ناقل الحركة (المستوى واللون)','تسريب ناقل الحركة','القابض (الدبرياج)','أعمدة الدوران والمفاصل']},
{n:'الفرامل',i:['تيل الفرامل الأمامي','تيل الفرامل الخلفي','الأقراص والطنابير','زيت الفرامل','فرامل اليد','خراطيم وخطوط الفرامل']},
{n:'العفشة والتوجيه',i:['المساعدات الأمامية','المساعدات الخلفية','المقصات والمفاصل (الروتيلات)','وصلات التوجيه والدركسيون','الجلب والكاوتش','زيت وخراطيم الباور','ضبط الزوايا']},
{n:'نظام التبريد',i:['مستوى سائل التبريد','تسريب الردياتير والخراطيم','مروحة التبريد','طلمبة المياه','غطاء الردياتير والثرموستات']},
{n:'الكهرباء والبطارية',i:['حالة البطارية','أقطاب البطارية','الدينامو (الشحن)','الاستارتر (المارش)','لمبات التحذير بالتابلوه','الفيوزات والتوصيلات']},
{n:'التكييف',i:['برودة التكييف','الكمبروسر','مروحة التكييف','فلتر الكابينة','تسريب غاز أو زيت التكييف']},
{n:'الإطارات والعجلات',i:['عمق الفرم الأمامي','عمق الفرم الخلفي','ضغط الهواء','الجنوط','الإطار الاحتياطي والعدة','انتظام التآكل']},
{n:'الزيوت والسوائل والتسريبات',i:['زيت المحرك','سائل التبريد','زيت الفرامل','زيت الباور','ماء المساحات','تسريبات أسفل السيارة']},
{n:'الهيكل والطلاء',i:['حالة الطلاء','علامات صدمات أو لحام','الصدأ','الزجاج','المرايات','الأبواب والأقفال','الشاسيه من الأسفل']},
{n:'الإضاءة والإشارات',i:['الإضاءة الأمامية','الإضاءة الخلفية وفرامل','إشارات الانعطاف','لمبات الرجوع والضباب','لمبات الطوارئ']},
{n:'أنظمة السلامة',i:['أحزمة الأمان','الوسائد الهوائية (لمبة التحذير)','نظام ABS','الكلاكس','المساعحات (المساحات)','قفل الأطفال']}];
TEMPLATE[11].i[4]='المساحات';

/* ---------- DB (IndexedDB, persistent) ---------- */
let db;
function openDB(){return new Promise((res,rej)=>{const r=indexedDB.open('fahsati',3);
/* ترقية آمنة: تضيف المخازن الناقصة فقط دون المساس بأي سجل قائم */
r.onupgradeneeded=()=>{const d=r.result;['clients','cars','inspections','reminders'].forEach(n=>{if(!d.objectStoreNames.contains(n))d.createObjectStore(n,{keyPath:'id'})});
if(!d.objectStoreNames.contains('photos'))d.createObjectStore('photos',{keyPath:'id'}).createIndex('insp','inspectionId');
if(!d.objectStoreNames.contains('settings'))d.createObjectStore('settings',{keyPath:'key'});
if(!d.objectStoreNames.contains('notes'))d.createObjectStore('notes',{keyPath:'id'});
if(!d.objectStoreNames.contains('tasks'))d.createObjectStore('tasks',{keyPath:'id'})};
r.onsuccess=()=>{db=r.result;db.onversionchange=()=>db.close();res()};r.onerror=()=>rej(r.error)})}
const tx=(s,m,f)=>new Promise((res,rej)=>{const t=db.transaction(s,m);let out;const rq=f(t.objectStore(s));if(rq)rq.onsuccess=()=>{out=rq.result};t.oncomplete=()=>res(out);t.onerror=()=>rej(t.error);t.onabort=()=>rej(t.error||new Error('abort'))});
const dbPut=(s,v)=>tx(s,'readwrite',o=>o.put(v));
const dbGet=(s,k)=>tx(s,'readonly',o=>o.get(k));
const dbAll=s=>tx(s,'readonly',o=>o.getAll());
const dbDel=(s,k)=>tx(s,'readwrite',o=>o.delete(k));
const photosOf=id=>tx('photos','readonly',o=>o.index('insp').getAll(id));
async function getSet(k,d){const r=await dbGet('settings',k);return r?r.value:d}
const setSet=(k,v)=>dbPut('settings',{key:k,value:v});
async function delInspection(id){const ph=await photosOf(id);
await new Promise((res,rej)=>{const t=db.transaction(['photos','inspections'],'readwrite');ph.forEach(p=>t.objectStore('photos').delete(p.id));t.objectStore('inspections').delete(id);t.oncomplete=res;t.onerror=()=>rej(t.error)})}

/* ---------- helpers ---------- */
const normD=s=>String(s||'').replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d));
/* رقم الشاسيه: مفتاح مطابقة فقط (بلا مسافات/حروف خفية، أحرف كبيرة، أرقام لاتينية). الرقم الأصلي يُحفظ كما كُتب دون تعديل. */
const vinKey=v=>normD(v).replace(/[\s\u00a0\u200b-\u200f\u202a-\u202e\u2060\ufeff]+/g,'').toUpperCase();
const vinOdd=k=>!!k&&!/^[A-HJ-NPR-Z0-9]{17}$/.test(k);
const insVin=i=>vinKey(i&&i.car&&i.car.vin);
const plateKey=v=>normD(v).replace(/\s+/g,'').toLowerCase();
/* تطبيع النص العربي للمقارنة فقط (التشكيل، الألف، الياء، التاء المربوطة، الأرقام) */
const normAr=s=>normD(s).toLowerCase().replace(/[\u064B-\u065F\u0670\u0640]/g,'').replace(/[\u060C\u061B\u061F]/g,' ').replace(/[إأآٱ]/g,'ا').replace(/ى/g,'ي').replace(/ة/g,'ه').replace(/ؤ/g,'و').replace(/ئ/g,'ي').replace(/[^\u0600-\u06FFa-z0-9\s]/g,' ').replace(/\s+/g,' ').trim();
function bigrams(t){t=t.replace(/\s/g,'');const o=new Map();for(let i=0;i<t.length-1;i++){const g=t.substr(i,2);o.set(g,(o.get(g)||0)+1)}return o}
function dice(a,b){const A=bigrams(a),B=bigrams(b);let na=0,nb=0,m=0;A.forEach(v=>na+=v);B.forEach(v=>nb+=v);if(!na||!nb)return 0;A.forEach((v,g)=>{if(B.has(g))m+=Math.min(v,B.get(g))});return 2*m/(na+nb)}
/* q وt نصان مطبّعان؛ الناتج بين 0 و1 */
function similarity(q,t){if(!q||!t)return 0;if(q===t)return 1;let s=0;
 if(t.includes(q)||q.includes(t))s=0.6+0.4*Math.min(q.length,t.length)/Math.max(q.length,t.length);
 const qt=q.split(' ').filter(x=>x.length>1),tt=t.split(' ').filter(x=>x.length>1);
 if(qt.length&&tt.length){let m=0;qt.forEach(w=>{if(tt.some(x=>x===w||(w.length>=3&&x.length>=3&&(x.startsWith(w)||w.startsWith(x)))))m++});s=Math.max(s,0.7*(m/qt.length)+0.3*(m/tt.length))}
 return Math.max(s,dice(q,t))}
function validPhone(p){const x=normD(p).replace(/[\s\-()]/g,'');return /^(\+?20|0)?1[0125]\d{8}$/.test(x)||/^\+\d{8,15}$/.test(x)||/^0\d{8,10}$/.test(x)}
function fmt(t){try{return new Date(t).toLocaleString('ar-u-nu-latn',{dateStyle:'medium',timeStyle:'short'})}catch(e){return new Date(t).toLocaleString()}}
const cnt=items=>{const c={ok:0,follow:0,repair:0,none:0};items.forEach(i=>c[i.status]++);return c};
const badge=k=>`<span class="badge" style="--c:${ST[k][1]}">${ST[k][0]}</span>`;
let tT;function toast(m,k){const t=$('#toast');t.textContent=m;t.className=k||'';t.style.display='block';clearTimeout(tT);tT=setTimeout(()=>t.style.display='none',k==='err'?7000:3200)}
const load=on=>$('#load').classList.toggle('on',on);
const withTimeout=(p,ms,msg)=>{let t;return Promise.race([Promise.resolve(p),new Promise((_,rej)=>{t=setTimeout(()=>rej(new Error(msg||'انتهت مهلة العملية')),ms)})]).finally(()=>clearTimeout(t))};
let busy=false;
const once=fn=>async(...a)=>{if(busy)return;busy=true;load(true);try{return await fn(...a)}catch(e){console.error(e);toast('حدث خطأ: '+(e&&e.message||e),'err')}finally{busy=false;load(false)}};
let _dlgRes=null;
function dialog(html,btns){return new Promise(res=>{const d=$('#dlg');const ld=$('#load'),wasLoading=ld.classList.contains('on');if(wasLoading)ld.classList.remove('on');
const finish=v=>{_dlgRes=null;d.classList.remove('on');d.innerHTML='';if(wasLoading)ld.classList.add('on');res(v)};
_dlgRes=finish;
d.innerHTML=`<div class="dbox">${html}<div class="row" style="margin-top:10px">${btns.map((b,i)=>`<button class="btn ${b.cls||''}" data-dlg="${i}">${b.t}</button>`).join('')}</div></div>`;d.classList.add('on');
d.onclick=e=>{const b=e.target.closest('[data-dlg]');if(!b)return;finish(btns[+b.dataset.dlg].v)}})}
function dismissDlg(v=false){if(_dlgRes){_dlgRes(v);return true}const d=$('#dlg');if(d&&d.classList.contains('on')){d.classList.remove('on');d.innerHTML='';return true}return false}
const confirmD=(m,ok='نعم، متابعة')=>dialog(`<p style="line-height:1.9">${esc(m)}</p>`,[{t:'إلغاء',v:false},{t:ok,v:true,cls:'danger'}]);
const openSheet=h=>{const s=$('#sheet');s.innerHTML=`<div class="sheet">${h}</div>`;s.classList.add('on')};
const closeSheetEl=()=>{$('#sheet').classList.remove('on');$('#sheet').innerHTML=''};
function topBar(title,sub,back){return `<div class="top">${back?'<button class="back" data-act="back">رجوع ›</button>':''}<h1>${esc(title)}</h1>${sub?`<p>${esc(sub)}</p>`:''}</div>`}
const carLine=i=>[i.car.brand,i.car.model,i.car.year].filter(Boolean).join(' ');
function insCard(i){const c=cnt(i.items);return `<button class="glass item" data-act="openIns" data-id="${i.id}"><div><div class="t">${esc(i.client.name||'بدون اسم')} — ${esc(i.car.plate||'بدون لوحة')}</div><div class="s">${esc(carLine(i))} · ${esc(i.client.phone)}</div>${i.car.vin?`<div class="s" dir="ltr" style="text-align:right">VIN: ${esc(i.car.vin)}</div>`:''}<div class="s">${fmt(i.date)}${c.repair+c.follow?` · ⚠ ${c.repair+c.follow} بند للمتابعة/الإصلاح`:''}</div></div><span class="badge" style="--c:${i.status==='complete'?'#B8F34A':'#7A847C'}">${i.status==='complete'?'مكتمل':'مسودة'}</span></button>`}

/* ---------- مكتبة الملاحظات (محلية دائمة في مخزن notes) ---------- */
const COMMON_DEF=5;
async function getThr(){const v=Math.floor(+await getSet('commonThreshold',COMMON_DEF));return v>=1?v:COMMON_DEF}
/* الاستخدامات تُحسب من الفحوصات المعتمدة (status=complete) فقط، مرة واحدة لكل فحص: لا تتأثر بالمسودات ولا بإعادة الفتح والاعتماد */
async function notesWithUses(){const [notes,ins]=await Promise.all([dbAll('notes'),dbAll('inspections')]);const uses={};
 ins.forEach(i=>{if(i.status!=='complete')return;const seen=new Set();(i.items||[]).forEach(x=>(x.noteRefs||[]).forEach(r=>{if(r&&r.id)seen.add(r.id)}));seen.forEach(id=>uses[id]=(uses[id]||0)+1)});
 return{notes,uses}}
function rankNotes(notes,uses,query,secName){const q=normAr(query),typed=q.length>=2;const maxU=Math.max(1,...notes.map(n=>uses[n.id]||0));const out=[];
 for(const n of notes){const nn=normAr(n.text),u=uses[n.id]||0,sameSec=n.section===secName,gen=!n.section;
  const sim=typed?similarity(q,nn):0;
  if(typed){if(sim<(sameSec||gen?0.35:0.5))continue}else if(!sameSec&&!gen)continue;
  const secB=sameSec?1:gen?0.5:0,useN=Math.log(1+u)/Math.log(1+maxU);
  out.push({n,u,sim,score:typed?0.6*sim+0.25*secB+0.15*useN:0.5*secB+0.5*useN})}
 return out.sort((a,b)=>b.score-a.score||b.u-a.u||(b.n.updatedAt||0)-(a.n.updatedAt||0))}
function sanitizeRefs(it,noteMap){if(!Array.isArray(it.noteRefs))return;const nt=normAr(it.notes||'');
 it.noteRefs=it.noteRefs.filter(r=>r&&r.id&&noteMap.has(r.id)&&nt&&nt.includes(normAr(r.t||noteMap.get(r.id).text)))}

const SRC_NOTE='إحصاءات من سجلات هذا التطبيق فقط على هذا الجهاز، وليست إحصاءات عامة عن السيارات أو الأعطال.';

/* ---------- مهام الإصلاح (tasks) — لا تُعدّل التقارير الأصلية ---------- */
function localDayBounds(ts){
  const d=ts?new Date(ts):new Date();
  const start=new Date(d.getFullYear(),d.getMonth(),d.getDate()).getTime();
  return{start,end:start+86400000-1};
}
function isSameLocalDay(ts,ref){const a=localDayBounds(ts),b=localDayBounds(ref);return a.start===b.start}
function taskFromItem(ins,item){
  return{
    id:uid(),
    inspectionId:ins.id,
    itemId:item.id,
    itemName:item.name,
    sectionName:ins.sections[item.section]||'',
    itemStatus:item.status, /* repair | follow — مرجع فقط */
    client:{name:ins.client.name||'',phone:ins.client.phone||''},
    car:{brand:ins.car.brand||'',model:ins.car.model||'',year:ins.car.year||'',plate:ins.car.plate||'',vin:ins.car.vin||''},
    status:'not_started',
    notes:'',
    dueAt:null,
    nid:null,
    createdAt:Date.now(),
    updatedAt:Date.now()
  };
}
async function existingTaskKeys(){
  const all=await dbAll('tasks');
  const s=new Set();
  all.forEach(t=>s.add(t.inspectionId+'|'+t.itemId));
  return s;
}
function taskSearchMatch(t,raw){
  const q=normD(raw).toLowerCase().trim();if(!q)return true;
  const qc=q.replace(/\s+/g,''),qk=vinKey(raw);
  const phone=normD(t.client.phone||'').toLowerCase();
  const plate=normD(t.car.plate||'').toLowerCase().replace(/\s+/g,'');
  const vin=vinKey(t.car.vin||'');
  const name=normD(t.client.name||'').toLowerCase();
  const item=normD(t.itemName||'').toLowerCase();
  if(phone.includes(q)||name.includes(q)||item.includes(q))return true;
  if(plate&&(plate.includes(qc)||qc.includes(plate)))return true;
  if(vin&&qk&&(vin===qk||(qk.length>=4&&vin.includes(qk))))return true;
  return false;
}
function taskDueStat(t){
  if(!t.dueAt||t.status==='done')return 'none';
  const now=Date.now(),at=new Date(t.dueAt).getTime();
  if(at<now)return 'over';
  return 'up';
}
async function scheduleTask(t){
  const LN=P('LocalNotifications');
  if(!LN||!t.dueAt||t.status==='done')return false;
  const at=new Date(t.dueAt);
  if(at<=new Date())return false;
  try{
    let p=await LN.checkPermissions();
    if(p.display!=='granted')p=await LN.requestPermissions();
    if(p.display!=='granted')return false;
    const nid=t.nid||(Math.abs(parseInt(t.id.replace(/\D/g,'').slice(-8),36)%2000000000)+100000);
    t.nid=nid;
    await LN.schedule({notifications:[{id:nid,title:'فحصتي — موعد إصلاح',body:(t.itemName||'')+' · '+(t.client.name||'')+' · '+(t.car.plate||''),schedule:{at:at,allowWhileIdle:true}}]});
    return true;
  }catch(e){console.warn(e);return false}
}
async function unscheduleTask(t){
  try{const LN=P('LocalNotifications');if(LN&&t.nid)await LN.cancel({notifications:[{id:t.nid}]})}catch(e){}
}
async function dailyStats(){
  const now=Date.now(),{start,end}=localDayBounds(now);
  const [allIns,allTasks]=await Promise.all([dbAll('inspections'),dbAll('tasks')]);
  const createdToday=allIns.filter(i=>i.date>=start&&i.date<=end);
  const completedToday=allIns.filter(i=>i.status==='complete'&&i.completedAt&&i.completedAt>=start&&i.completedAt<=end);
  const drafts=allIns.filter(i=>i.status!=='complete');
  const pendingTasks=allTasks.filter(t=>t.status!=='done');
  const carsPending=new Set(pendingTasks.map(t=>vinKey(t.car.vin)||plateKey(t.car.plate)||t.car.plate||t.id));
  const repairsDoneToday=allTasks.filter(t=>t.status==='done'&&t.updatedAt>=start&&t.updatedAt<=end);
  const dueFollow=allTasks.filter(t=>t.dueAt&&t.status!=='done'&&isSameLocalDay(t.dueAt,now));
  const overdue=allTasks.filter(t=>taskDueStat(t)==='over');
  const needComplete=allIns.filter(i=>i.status!=='complete'&&(i.items||[]).some(x=>x.status==='none'));
  return{
    createdToday:createdToday.length,
    completedToday:completedToday.length,
    drafts:drafts.length,
    carsPending:carsPending.size,
    repairsDoneToday:repairsDoneToday.length,
    dueFollow:dueFollow.length,
    overdue:overdue.length,
    needComplete:needComplete.length,
    lists:{
      createdToday,completedToday,drafts,pendingTasks,repairsDoneToday,dueFollow,overdue,needComplete
    }
  };
}


/* ---------- state & navigation ---------- */
let INS=null,PH=[],stack=[{v:'home',p:{}}],saveT=null,CURI=null,PDFS={};
const VIEWS={};
function updateNav(){const v=stack[stack.length-1].v;const tabs={home:'home',history:'history',search:'history',vehicle:'history',reminders:'reminders',settings:'settings',tasks:'home',taskForm:'home',dashList:'home'};
document.querySelectorAll('#nav button').forEach(b=>b.classList.toggle('on',b.dataset.t===tabs[v]));
const full=['form','check','section','summary','report','remForm','credits','taskForm','dashList'].includes(v);document.body.classList.toggle('hidenav',full)}
async function render(){const t=stack[stack.length-1];const h=await VIEWS[t.v](t.p||{});$('#app').innerHTML=h;$('#app').scrollTop=0;updateNav()}
const go=async(v,p)=>{await flushSave();stack.push({v,p:p||{}});await render()};
const goTab=async v=>{await flushSave();stack=[{v,p:{}}];await render()};
const rep=async(v,p)=>{stack[stack.length-1]={v,p:p||{}};await render()};
const back=async()=>{await flushSave();if(stack.length>1)stack.pop();await render()};

/* ---------- autosave ---------- */
function ind(m){const e=$('#saveInd');if(e)e.textContent=m}
function scheduleSave(){clearTimeout(saveT);ind('جارٍ الحفظ…');saveT=setTimeout(()=>saveIns(),400)}
async function saveIns(){clearTimeout(saveT);saveT=null;if(!INS)return true;INS.updatedAt=Date.now();
try{await dbPut('inspections',INS);ind('تم الحفظ تلقائيًا ✓');return true}catch(e){ind('تعذر الحفظ');toast('تعذر الحفظ: '+(e.message||'تحقق من مساحة التخزين'),'err');return false}}
async function flushSave(){if(saveT)await saveIns()}
async function loadIns(id){const i=await dbGet('inspections',id);if(!i)throw new Error('السجل غير موجود');INS=i;PH=await photosOf(id)}

/* ---------- views ---------- */
VIEWS.home=async()=>{const all=(await dbAll('inspections')).sort((a,b)=>b.date-a.date);
const ds=await dailyStats();
const st=(k,n,l,c)=>`<button class="glass stat" data-act="dashList" data-k="${k}" style="cursor:pointer"><b style="${c?`color:${c}`:''}">${n}</b><span>${l}</span></button>`;
return `${topBar('فحصتي','فحص السيارات وتقارير الصيانة')}
<div class="pad"><h2 style="margin-top:0">ملخص اليوم</h2>
<div class="grid3">${st('createdToday',ds.createdToday,'فحوصات اليوم','')}${st('completedToday',ds.completedToday,'مكتملة اليوم','#3DDC84')}${st('drafts',ds.drafts,'مسودات','#7A847C')}</div>
<div class="grid3">${st('carsPending',ds.carsPending,'سيارات بإصلاح معلّق','#F5A524')}${st('repairsDoneToday',ds.repairsDoneToday,'إصلاحات اكتملت اليوم','#3DDC84')}${st('dueFollow',ds.dueFollow,'مواعيد متابعة اليوم','#B8F34A')}</div>
<div class="grid3">${st('overdue',ds.overdue,'إصلاحات متأخرة','#FF5C5C')}${st('needComplete',ds.needComplete,'فحوصات تحتاج استكمال','#7A847C')}<div class="glass stat" style="visibility:hidden"><b>—</b><span>—</span></div></div>
<button class="btn primary big" data-act="newIns">+ فحص سيارة جديدة</button>
<div class="row"><button class="btn" data-act="goTasks">🔧 مهام الإصلاح</button><button class="btn" data-act="goSearch">🔎 بحث</button></div>
<div class="row"><button class="btn" data-act="goNotes">📚 مكتبة الملاحظات</button><button class="btn" data-act="tab" data-t="reminders">التذكيرات</button><button class="btn" data-act="tab" data-t="settings">الإعدادات</button></div>
<h2>أحدث الفحوصات</h2>${all.length?all.slice(0,8).map(insCard).join(''):'<div class="glass empty">لا توجد فحوصات بعد. ابدأ بـ «فحص سيارة جديدة».</div>'}</div>`};

VIEWS.form=async(p)=>{const all=(await dbAll('inspections')).sort((a,b)=>b.date-a.date);const seen={};const opts=[];
all.forEach(i=>{const k=i.client.phone+'|'+(insVin(i)||(i.car.plate||i.car.model));if(!seen[k]){seen[k]=1;opts.push(i)}});
window.__prev=opts;const f=p.prefill||{client:{},car:{}};const c=f.client||{},k=f.car||{};
const inp=(id,l,v,ex='')=>`<label>${l}</label><input id="${id}" value="${esc(v||'')}" ${ex}>`;
return `${topBar('فحص سيارة جديدة','بيانات العميل والسيارة',true)}<div class="pad">
${opts.length?`<div class="glass card"><label>إعادة فحص سيارة سابقة (اختياري)</label><select id="prevSel"><option value="">— اختر من السجلات —</option>${opts.map((i,n)=>`<option value="${n}">${esc(i.client.name)} — ${esc(carLine(i))} — ${esc(i.car.plate)}</option>`).join('')}</select><div class="note">تُملأ البيانات المعروفة ويمكن تعديلها، ويُنشأ فحص جديد مستقل دون المساس بالتقارير القديمة.</div></div>`:''}
<div class="glass card"><b>بيانات العميل</b>${inp('fName','اسم العميل',c.name)}${inp('fPhone','رقم هاتف العميل *',c.phone,'type="tel" inputmode="tel"')}<label>ملاحظات أولية</label><textarea id="fNotes">${esc(c.notes||'')}</textarea></div>
<div class="glass card"><b>بيانات السيارة</b>${inp('fBrand','ماركة السيارة',k.brand)}${inp('fModel','موديل السيارة',k.model)}${inp('fYear','سنة الصنع',k.year,'inputmode="numeric"')}${inp('fPlate','رقم اللوحة',k.plate)}${inp('fKm','قراءة العداد (كم)',k.km,'inputmode="numeric"')}${inp('fVin','رقم الشاسيه VIN',k.vin,'dir="ltr" autocapitalize="characters" autocomplete="off"')}<div class="note">يُحفظ الرقم كما تكتبه تمامًا؛ المسافات لا تؤثر على البحث ولا على ربط فحوصات السيارة.</div></div>
<div id="fErr" class="err"></div>
<button class="btn primary big" data-act="saveForm">بدء الفحص</button></div>`};

const secStats=si=>{const it=INS.items.filter(x=>x.section===si);const c=cnt(it);return{it,c,done:it.length-c.none}};
VIEWS.check=async()=>{const c=cnt(INS.items),tot=INS.items.length,done=tot-c.none;
return `${topBar(INS.client.name||'فحص','',true)}<div class="pad"><div class="glass card"><b>${esc(carLine(INS))} — ${esc(INS.car.plate)}</b><div class="note">${esc(INS.client.phone)} · ${fmt(INS.date)}</div>
<div class="bar"><i style="width:${tot?done/tot*100:0}%"></i></div><div class="note">تم فحص ${done} من ${tot} بند</div><div id="saveInd" class="ind">محفوظ كمسودة</div></div>
${INS.sections.map((n,si)=>{const s=secStats(si);return `<button class="glass item" data-act="openSec" data-i="${si}"><div><div class="t">${esc(n)}</div><div class="s">${s.done}/${s.it.length} · <span style="color:#3DDC84">${s.c.ok} سليم</span> · <span style="color:#F5A524">${s.c.follow} متابعة</span> · <span style="color:#FF5C5C">${s.c.repair} إصلاح</span></div></div><span>›</span></button>`}).join('')}
<div class="row"><button class="btn" data-act="saveDraft">حفظ كمسودة</button><button class="btn primary" data-act="toSummary">ملخص وإنهاء</button></div></div>`};

VIEWS.section=async(p)=>{const si=p.i,it=INS.items.filter(x=>x.section===si);
const unset=it.filter(x=>x.status==='none').length;
return `${topBar(INS.sections[si],INS.client.name,true)}<div class="pad"><div id="saveInd" class="ind"></div>
${unset?`<button class="btn primary" data-act="markSecOk" data-i="${si}" style="margin-bottom:10px">✓ تحديد كل القسم سليم (${unset} بند غير محدد)</button>`:`<div class="note" style="margin-bottom:10px">لا توجد بنود غير محددة في هذا القسم.</div>`}
${it.map(x=>{const n=PH.filter(q=>q.itemId===x.id).length;return `<button class="glass item" data-act="openItem" data-id="${x.id}"><div><div class="t">${esc(x.name)}${x.custom?' <span class="tag">مخصص</span>':''}</div><div class="s">${n?'📷 '+n+' ':''}${x.notes?esc(x.notes.slice(0,40)):''}</div></div>${badge(x.status)}</button>`}).join('')}
<button class="btn" data-act="addItem" data-i="${si}">+ إضافة بند مخصص</button></div>`};

VIEWS.summary=async()=>{const c=cnt(INS.items);const imp=INS.items.filter(x=>x.status==='follow'||x.status==='repair');const un=INS.items.filter(x=>x.status==='none');
return `${topBar('ملخص الفحص',INS.client.name,true)}<div class="pad"><div id="saveInd" class="ind"></div>
<div class="grid3" style="margin:0 0 12px"><div class="glass stat"><b style="color:#3DDC84">${c.ok}</b><span>سليم</span></div><div class="glass stat"><b style="color:#F5A524">${c.follow}</b><span>متابعة</span></div><div class="glass stat"><b style="color:#FF5C5C">${c.repair}</b><span>إصلاح</span></div></div>
<div class="glass stat" style="margin-bottom:12px"><b style="color:#7A847C">${c.none}</b><span>لم يتم فحصها</span></div>
${un.length?`<div class="warn"><b>بنود لم يتم فحصها (${un.length}):</b><br>${un.map(x=>esc(INS.sections[x.section]+' ← '+x.name)).join('<br>')}</div>`:''}
<h2>الملاحظات المهمة</h2>${imp.length?imp.map(x=>`<div class="glass card"><div class="t"><b>${esc(x.name)}</b> ${badge(x.status)}</div><div class="note">${esc(INS.sections[x.section])}${x.loc?' · الموضع: '+esc(x.loc):''}</div>${x.notes?`<div>${esc(x.notes)}</div>`:''}<div class="pgrid">${PH.filter(q=>q.itemId===x.id).map(q=>`<img class="full" style="height:100px;object-fit:cover" src="${q.data}">`).join('')}</div><button class="btn" style="margin-top:8px" data-act="makeTask" data-item="${x.id}">+ تحويل إلى مهمة إصلاح</button></div>`).join(''):'<div class="glass empty">لا توجد بنود مسجلة للمتابعة أو الإصلاح.</div>'}
${imp.length?`<button class="btn primary" data-act="makeTasksAll">+ تحويل كل بنود المتابعة/الإصلاح إلى مهام</button>`:''}
<h2>التوصيات (يحددها المهندس)</h2><div class="glass card">${INS.recs.map(r=>`<div style="display:flex;justify-content:space-between;gap:8px;margin-bottom:8px"><div><span class="tag">${PRI[r.priority]}</span> ${esc(r.text)}</div><button class="x" data-act="delRec" data-id="${r.id}">✕</button></div>`).join('')||'<div class="note">لا توجد توصيات.</div>'}
<label>توصية جديدة</label><textarea id="recT" style="min-height:60px"></textarea><label>الأولوية</label><select id="recP"><option value="urgent">عاجل</option><option value="soon" selected>قريبًا</option><option value="periodic">متابعة دورية</option></select><button class="btn" data-act="addRec">+ إضافة توصية</button></div>
<label>الملاحظات النهائية</label><textarea id="finalN">${esc(INS.finalNotes||'')}</textarea>
<div class="note" style="margin-top:8px">التطبيق لا يشخّص الأعطال ولا يصدر حكمًا على صلاحية السيارة؛ كل ما يظهر هو ما سجّله المهندس.</div>
<div class="row"><button class="btn" data-act="saveDraft">حفظ كمسودة</button><button class="btn primary" data-act="finish">اعتماد وإنشاء التقرير</button></div></div>`};

VIEWS.report=async()=>{const c=cnt(INS.items);const pdf=PDFS[INS.id];
return `${topBar('التقرير',INS.status==='complete'?'فحص مكتمل':'مسودة',true)}<div class="pad">
<div class="glass card"><b>${esc(INS.client.name)}</b> · ${esc(INS.client.phone)}<div class="note">${esc(carLine(INS))} · لوحة: ${esc(INS.car.plate)} · ${fmt(INS.date)}</div>
<div style="margin-top:8px">${badge('ok')} ${c.ok} ${badge('follow')} ${c.follow} ${badge('repair')} ${c.repair} ${badge('none')} ${c.none}</div></div>
${INS.status!=='complete'?'<div class="warn">هذه مسودة وليست تقريرًا نهائيًا.</div>':''}
<button class="btn primary" data-act="mkPdf">إنشاء التقرير (PDF)</button>
<div class="row"><button class="btn" data-act="prevPdf">معاينة PDF</button><button class="btn" data-act="savePdf">حفظ PDF</button></div>
<button class="btn" data-act="sharePdf">مشاركة التقرير</button>
<div class="note" id="pdfInfo">${pdf?`آخر ملف: ${esc(pdf.name)} (${Math.round(pdf.size/1024)} ك.ب)`:'لم يُنشأ ملف PDF بعد.'}</div>
<h2>إجراءات</h2>
${INS.status==='complete'?'<button class="btn" data-act="reopen">تعديل الفحص (إعادته كمسودة)</button>':'<button class="btn" data-act="resume">استكمال الفحص</button>'}
<button class="btn" data-act="reNew">فحص جديد لنفس السيارة</button><button class="btn" data-act="remFor">+ تذكير مرتبط بهذا التقرير</button>
<button class="btn danger" data-act="delIns">حذف هذا الفحص</button>
<h2>تفاصيل البنود المسجلة</h2>${INS.items.filter(x=>x.status!=='none'||x.notes||PH.some(q=>q.itemId===x.id)).map(x=>`<div class="glass card"><b>${esc(x.name)}</b> ${badge(x.status)}<div class="note">${esc(INS.sections[x.section])}</div>${x.loc?`<div>الموضع: ${esc(x.loc)}</div>`:''}${x.notes?`<div>${esc(x.notes)}</div>`:''}<div class="pgrid">${PH.filter(q=>q.itemId===x.id).map(q=>`<img class="full" style="height:100px;object-fit:cover" src="${q.data}">`).join('')}</div></div>`).join('')||'<div class="glass empty">لا توجد بنود مسجلة.</div>'}</div>`};

/* بحث موحد: اسم/هاتف/لوحة/ماركة/موديل/رقم الشاسيه (VIN). مطابقة VIN تتجاهل المسافات والحالة دون تعديل الرقم المحفوظ */
function searchIns(all,raw){const q=normD(raw).toLowerCase().trim(),qc=q.replace(/\s+/g,''),qk=vinKey(raw);const list=[],groups=new Map();
 all.forEach(i=>{const vk=insVin(i);
  const txt=[i.client.name,i.client.phone,i.car.plate,i.car.brand,i.car.model].some(v=>{const t=normD(v||'').toLowerCase();return t.includes(q)||(qc&&t.replace(/\s+/g,'').includes(qc))});
  const vh=!!vk&&qk.length>=4&&(vk===qk||(!/^\d{9,}$/.test(qk)&&vk.includes(qk)));
  if(!txt&&!vh)return;list.push(i);
  if(vh){const g=groups.get(vk)||{key:vk,n:0,latest:i};g.n++;if(i.date>g.latest.date)g.latest=i;groups.set(vk,g)}});
 return{list,groups:[...groups.values()].sort((a,b)=>b.latest.date-a.latest.date)}}
function vinGroupsHtml(gs){return gs.length?`<h2>سيارات مطابقة لرقم الشاسيه</h2>${gs.map(g=>`<button class="glass item" data-act="openVeh" data-vin="${esc(g.key)}"><div><div class="t" dir="ltr" style="text-align:right">🚗 ${esc(g.latest.car.vin)}</div><div class="s">${esc(carLine(g.latest))} · ${esc(g.latest.car.plate||'بدون لوحة')}</div><div class="s">${g.n} فحص · آخر فحص ${fmt(g.latest.date)}</div></div><span>›</span></button>`).join('')}<h2>الفحوصات المطابقة</h2>`:''}
async function searchScreen(p,title,isSearch){const raw=p.q||'';let all=(await dbAll('inspections')).sort((a,b)=>b.date-a.date);let list=all,groups=[];
 if(raw.trim()){const r=searchIns(all,raw);list=r.list;groups=r.groups}else if(isSearch)list=[];
 const empty=isSearch&&!raw.trim()?'<div class="glass empty">اكتب رقم الشاسيه أو اللوحة أو الهاتف أو الاسم للبحث.</div>':'<div class="glass empty">لا توجد نتائج.</div>';
 return `${topBar(title,isSearch?'':list.length+' سجل',isSearch)}<div class="pad"><input id="hq" placeholder="بحث: رقم الشاسيه، هاتف، لوحة، اسم، ماركة، موديل" value="${esc(raw)}" autocomplete="off"><div id="hlist" style="margin-top:12px">${vinGroupsHtml(groups)}${list.map(insCard).join('')||empty}</div></div>`}
VIEWS.history=p=>searchScreen(p,'سجل الفحوصات',false);
VIEWS.search=p=>searchScreen(p,'بحث',true);

/* ملف السيارة: كل فحوصات رقم شاسيه واحد (مطابقة تامة بعد إزالة المسافات) مرتبة بالتاريخ */
VIEWS.vehicle=async p=>{const key=p.vin,all=await dbAll('inspections');const mine=all.filter(i=>insVin(i)===key).sort((a,b)=>p.asc?a.date-b.date:b.date-a.date);
 if(!mine.length)return `${topBar('ملف السيارة','',true)}<div class="pad"><div class="glass empty">لا توجد فحوصات لهذا الرقم.</div></div>`;
 const latest=mine.reduce((a,b)=>b.date>a.date?b:a),done=mine.filter(i=>i.status==='complete').length;
 const raws=[...new Set(mine.map(i=>i.car.vin))],owners=new Map();mine.forEach(i=>{const k=i.client.phone||i.client.name;if(!owners.has(k))owners.set(k,i.client)});
 const plates=new Set(mine.map(i=>plateKey(i.car.plate)).filter(Boolean));const mineIds=new Set(mine.map(i=>i.id));
 const legacy=plates.size?all.filter(i=>!insVin(i)&&!mineIds.has(i.id)&&plates.has(plateKey(i.car.plate))).sort((a,b)=>b.date-a.date):[];
 const km=mine.filter(i=>i.car.km).sort((a,b)=>b.date-a.date)[0];
 return `${topBar('ملف السيارة',carLine(latest),true)}<div class="pad"><div class="glass card"><div class="t" dir="ltr" style="text-align:right"><b>VIN: ${esc(latest.car.vin)}</b></div>
<div class="note">${esc(carLine(latest))}${latest.car.plate?' · لوحة: '+esc(latest.car.plate):''}${km?' · آخر عداد مسجل: '+esc(km.car.km)+' كم':''}</div>
<div class="note">${mine.length} فحص (${done} معتمد، ${mine.length-done} مسودة)${raws.length>1?' · كُتب الرقم بصيغ مختلفة (مسافات) ودُمجت لأنها نفس الرقم':''}</div>
<div class="note">${[...owners.values()].map(c=>esc((c.name||'بدون اسم')+' — '+(c.phone||''))).join('<br>')}</div>${owners.size>1?'<div class="warn">تنبيه: هذا الرقم مسجل باسم أكثر من عميل. راجع الأسماء للتأكد من صحة الرقم.</div>':''}</div>
<button class="btn" data-act="vehOrder" data-vin="${esc(key)}" data-asc="${p.asc?1:''}">الترتيب: ${p.asc?'الأقدم أولًا':'الأحدث أولًا'} (اضغط للعكس)</button>
<h2>الفحوصات والتقارير</h2>${mine.map(insCard).join('')}
${legacy.length?`<h2>سجلات قديمة بدون رقم شاسيه بنفس اللوحة</h2><div class="warn">لم تُدمج تلقائيًا لأن غياب الرقم لا يثبت أنها نفس السيارة. افتحها وتحقق بنفسك.</div>${legacy.map(insCard).join('')}`:''}</div>`};

const remStat=r=>r.canceled?'canceled':(new Date(r.at)<new Date()?'over':'up');
function remCard(r){const s=remStat(r);return `<div class="glass card"><div class="t"><b>${esc(r.reason)}</b> ${s==='over'?'<span class="badge" style="--c:#FF5C5C">متأخر</span>':s==='canceled'?'<span class="badge">ملغى</span>':''}</div><div class="note">${fmt(r.at)}${r.label?' · '+esc(r.label):''}</div>
<div class="row"><button class="btn" data-act="remEdit" data-id="${r.id}">تعديل</button>${s!=='canceled'?`<button class="btn" data-act="remCancel" data-id="${r.id}">إلغاء التذكير</button>`:''}<button class="btn danger" data-act="remDel" data-id="${r.id}">حذف</button></div></div>`}
VIEWS.reminders=async()=>{const all=(await dbAll('reminders')).sort((a,b)=>new Date(a.at)-new Date(b.at));
const g=s=>all.filter(r=>remStat(r)===s);
return `${topBar('التذكيرات',all.length+' تذكير')}<div class="pad"><button class="btn primary" data-act="remNew">+ تذكير جديد</button>
<h2>متأخرة</h2>${g('over').map(remCard).join('')||'<div class="note">لا يوجد.</div>'}<h2>قادمة</h2>${g('up').map(remCard).join('')||'<div class="note">لا يوجد.</div>'}<h2>ملغاة</h2>${g('canceled').map(remCard).join('')||'<div class="note">لا يوجد.</div>'}
<div class="note">الإشعارات تعتمد على أذونات النظام وقيود البطارية؛ قائمة التذكيرات هنا تبقى محفوظة حتى لو لم يظهر الإشعار، ولا يوجد ضمان لوصوله.</div></div>`};

VIEWS.remForm=async(p)=>{const r=p.r||{};const all=(await dbAll('inspections')).sort((a,b)=>b.date-a.date);
const d=r.at?new Date(new Date(r.at)-new Date(r.at).getTimezoneOffset()*60000).toISOString().slice(0,16):'';
return `${topBar(r.id?'تعديل التذكير':'تذكير جديد','',true)}<div class="pad"><div class="glass card">
<label>العميل / السيارة / التقرير (اختياري)</label><select id="rIns"><option value="">— بدون ربط —</option>${all.map(i=>`<option value="${i.id}" ${r.inspectionId===i.id||p.insId===i.id?'selected':''}>${esc(i.client.name)} — ${esc(carLine(i))} — ${esc(i.car.plate)} (${fmt(i.date)})</option>`).join('')}</select>
<label>سبب التذكير *</label><textarea id="rWhy">${esc(r.reason||'')}</textarea><label>التاريخ والوقت *</label><input type="datetime-local" id="rAt" value="${d}">
<div id="rErr" class="err"></div></div><button class="btn primary big" data-act="remSave" data-id="${r.id||''}">حفظ التذكير</button></div>`};


/* ---------- مهام الإصلاح ---------- */
function taskCard(t){
  const ds=taskDueStat(t);
  const due=t.dueAt?fmt(new Date(t.dueAt).getTime()):'بدون موعد';
  return `<button class="glass item" data-act="openTask" data-id="${t.id}"><div><div class="t">${esc(t.itemName)} ${tBadge(t.status)}</div>
<div class="s">${esc(t.client.name||'—')} · ${esc(t.car.plate||'بدون لوحة')} · ${esc([t.car.brand,t.car.model].filter(Boolean).join(' '))}</div>
${t.car.vin?`<div class="s" dir="ltr" style="text-align:right">VIN: ${esc(t.car.vin)}</div>`:''}
<div class="s">${esc(t.sectionName||'')} · الموعد: ${due}${ds==='over'?' · <span style="color:#FF5C5C">متأخر</span>':ds==='up'?' · قادم':''}</div>
</div><span>›</span></button>`;
}
VIEWS.tasks=async p=>{
  p=p||{};const q=p.q||'',st=p.st||'',df=p.df||'';
  let all=(await dbAll('tasks')).sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0));
  if(q.trim())all=all.filter(t=>taskSearchMatch(t,q));
  if(st)all=all.filter(t=>t.status===st);
  if(df==='over')all=all.filter(t=>taskDueStat(t)==='over');
  else if(df==='up')all=all.filter(t=>taskDueStat(t)==='up');
  else if(df==='today'){const now=Date.now();all=all.filter(t=>t.dueAt&&isSameLocalDay(t.dueAt,now)&&t.status!=='done')}
  const over=all.filter(t=>taskDueStat(t)==='over');
  const up=all.filter(t=>taskDueStat(t)==='up');
  const rest=all.filter(t=>taskDueStat(t)==='none');
  const stOpts=Object.keys(TST).map(k=>`<option value="${k}" ${st===k?'selected':''}>${TST[k][0]}</option>`).join('');
  return `${topBar('مهام الإصلاح',all.length+' مهمة',true)}<div class="pad">
<input id="tq" placeholder="بحث: هاتف، لوحة، شاسيه، اسم، بند" value="${esc(q)}" autocomplete="off">
<div class="row" style="margin-top:8px">
<select id="tSt"><option value="">كل الحالات</option>${stOpts}</select>
<select id="tDf"><option value="">كل المواعيد</option><option value="over" ${df==='over'?'selected':''}>متأخرة</option><option value="up" ${df==='up'?'selected':''}>قادمة</option><option value="today" ${df==='today'?'selected':''}>مواعيد اليوم</option></select>
</div>
${over.length?`<h2>متأخرة (${over.length})</h2>${over.map(taskCard).join('')}`:''}
${up.length?`<h2>قادمة (${up.length})</h2>${up.map(taskCard).join('')}`:''}
${rest.length?`<h2>${over.length||up.length?'أخرى':'المهام'} (${rest.length})</h2>${rest.map(taskCard).join('')}`:''}
${!all.length?'<div class="glass empty">لا توجد مهام مطابقة. تُنشأ المهام من بنود «يحتاج إصلاح» أو «يحتاج متابعة» في ملخص الفحص.</div>':''}
</div>`;
};
VIEWS.taskForm=async p=>{
  const t=p.t||await dbGet('tasks',p.id);if(!t)return `${topBar('مهمة','',true)}<div class="pad"><div class="glass empty">المهمة غير موجودة.</div></div>`;
  const d=t.dueAt?new Date(new Date(t.dueAt)-new Date(t.dueAt).getTimezoneOffset()*60000).toISOString().slice(0,16):'';
  const chips=Object.keys(TST).map(k=>`<button class="chip ${t.status===k?'on':''}" style="--c:${TST[k][1]}" data-act="taskSetSt" data-k="${k}" data-id="${t.id}">${TST[k][0]}</button>`).join('');
  return `${topBar('تفاصيل المهمة','',true)}<div class="pad"><div class="glass card">
<div class="t"><b>${esc(t.itemName)}</b> ${tBadge(t.status)}</div>
<div class="note">${esc(t.sectionName||'')} · حالة البند الأصلية: ${ST[t.itemStatus]?ST[t.itemStatus][0]:esc(t.itemStatus||'')}</div>
<div class="note">${esc(t.client.name||'—')} · ${esc(t.client.phone||'')} · ${esc(t.car.plate||'بدون لوحة')}</div>
${t.car.vin?`<div class="note" dir="ltr" style="text-align:right">VIN: ${esc(t.car.vin)}</div>`:''}
<div class="note">الفحص المرتبط: ${fmt(t.createdAt)}</div>
<label>حالة المهمة</label><div class="chips">${chips}</div>
<label>ملاحظات الإصلاح</label><textarea id="taskNotes">${esc(t.notes||'')}</textarea>
<label>موعد المتابعة / الإصلاح</label><input type="datetime-local" id="taskDue" value="${d}">
<div class="note">تغيير حالة المهمة لا يعدّل التقرير الأصلي للفحص.</div>
</div>
<button class="btn primary big" data-act="taskSave" data-id="${t.id}">حفظ المهمة</button>
<div class="row"><button class="btn" data-act="openIns" data-id="${t.inspectionId}">فتح الفحص الأصلي</button><button class="btn danger" data-act="taskDel" data-id="${t.id}">حذف المهمة</button></div>
</div>`;
};
VIEWS.dashList=async p=>{
  const k=p.k||'';
  const ds=await dailyStats();
  const titles={createdToday:'فحوصات منشأة اليوم',completedToday:'فحوصات مكتملة اليوم',drafts:'المسودات',carsPending:'سيارات بإصلاحات معلّقة',repairsDoneToday:'إصلاحات اكتملت اليوم',dueFollow:'مواعيد متابعة اليوم',overdue:'إصلاحات متأخرة',needComplete:'فحوصات تحتاج استكمالًا'};
  const title=titles[k]||'القائمة';
  let html='';
  if(['createdToday','completedToday','drafts','needComplete'].includes(k)){
    const list=ds.lists[k]||[];
    html=list.length?list.sort((a,b)=>b.date-a.date).map(insCard).join(''):'<div class="glass empty">لا سجلات.</div>';
  }else if(['repairsDoneToday','dueFollow','overdue'].includes(k)){
    const list=ds.lists[k]||[];
    html=list.length?list.map(taskCard).join(''):'<div class="glass empty">لا سجلات.</div>';
  }else if(k==='carsPending'){
    const list=ds.lists.pendingTasks||[];
    html=list.length?list.map(taskCard).join(''):'<div class="glass empty">لا سجلات.</div>';
  }else html='<div class="glass empty">غير متاح.</div>';
  return `${topBar(title,'',true)}<div class="pad">${html}</div>`;
};

/* ---------- شاشة مكتبة الملاحظات ---------- */
const SEC_NAMES=()=>TEMPLATE.map(t=>t.n);
function notesListHtml(notes,uses,thr,p){const q=normAr(p.q||''),sec=p.sec||'',flt=p.flt||'';
 let L=notes.filter(n=>(!sec||(sec==='__gen'?!n.section:n.section===sec))&&(!q||normAr(n.text).includes(q)||similarity(q,normAr(n.text))>=0.5));
 if(flt==='common')L=L.filter(n=>(uses[n.id]||0)>=thr);else if(flt==='unused')L=L.filter(n=>!(uses[n.id]||0));
 L.sort((a,b)=>(uses[b.id]||0)-(uses[a.id]||0)||(b.updatedAt||0)-(a.updatedAt||0));
 if(!L.length)return `<div class="glass empty">${notes.length?'لا توجد ملاحظات مطابقة.':'المكتبة فارغة. أضف ملاحظة أو احفظها من شاشة البند أثناء الفحص.'}</div>`;
 return L.map(n=>{const u=uses[n.id]||0,common=u>=thr;return `<div class="glass card"><div class="t">${esc(n.text).replace(/\n/g,'<br>')}</div>
<div class="note">القسم: ${esc(n.section||'عام (كل الأقسام)')} · استُخدمت في ${u} فحص معتمد ${common?'<span class="badge" style="--c:#FF5C5C">⚠ عيب شائع في سجلاتك</span>':''}</div>
<div class="row"><button class="btn" data-act="noteEdit" data-id="${n.id}">تعديل</button><button class="btn danger" data-act="noteDel" data-id="${n.id}">حذف</button></div></div>`}).join('')}
VIEWS.notes=async p=>{const {notes,uses}=await notesWithUses(),thr=await getThr();p.q=p.q||'';
 return `${topBar('مكتبة الملاحظات',notes.length+' ملاحظة',true)}<div class="pad">
<div class="warn">${esc(SRC_NOTE)} تُحسب الاستخدامات عند اعتماد الفحص فقط، ولا تُضاف أي ملاحظة للتقرير إلا باختيارك.</div>
<button class="btn primary" data-act="noteAdd">+ إضافة ملاحظة</button>
<input id="nq" placeholder="بحث في الملاحظات" value="${esc(p.q)}" autocomplete="off">
<div class="row"><div><label>القسم الفني</label><select id="nSec"><option value="">الكل</option><option value="__gen" ${p.sec==='__gen'?'selected':''}>عام</option>${SEC_NAMES().map(n=>`<option ${p.sec===n?'selected':''}>${esc(n)}</option>`).join('')}</select></div>
<div><label>التصفية</label><select id="nFlt"><option value="">الكل</option><option value="common" ${p.flt==='common'?'selected':''}>عيوب شائعة فقط</option><option value="unused" ${p.flt==='unused'?'selected':''}>غير مستخدمة</option></select></div></div>
<div id="nlist" style="margin-top:12px">${notesListHtml(notes,uses,thr,p)}</div>
<h2>حد «عيب شائع»</h2><div class="glass card"><label>تظهر العلامة عندما يبلغ عدد الاستخدامات هذا الحد أو أكثر</label><input id="nThr" type="number" inputmode="numeric" min="1" max="9999" value="${thr}"><button class="btn" data-act="saveThr">حفظ الحد</button><div id="nErr" class="err"></div></div></div>`};

VIEWS.settings=async()=>{const s={c:await getSet('center',''),e:await getSet('engineer',''),b:await getSet('lastBackup',null)};
return `${topBar('الإعدادات')}<div class="pad"><div class="glass card"><label>اسم مركز الصيانة</label><input id="sCenter" value="${esc(s.c)}"><label>اسم المهندس (اختياري)</label><input id="sEng" value="${esc(s.e)}"><button class="btn primary" data-act="saveSettings">حفظ الإعدادات</button></div>
<h2>التذكيرات والإشعارات</h2><div class="glass card"><button class="btn" data-act="goNotes">مكتبة الملاحظات والعيوب</button><button class="btn" data-act="tab" data-t="reminders">إدارة التذكيرات</button><button class="btn" data-act="notifPerm">طلب إذن الإشعارات / فحص حالته</button></div>
<h2>النسخ الاحتياطي</h2><div class="glass card"><div class="note">آخر نسخة احتياطية: ${s.b?fmt(s.b):'لا توجد'}</div><div class="warn">البيانات محفوظة محليًا على هذا الجهاز فقط. فقدان الهاتف أو حذف التطبيق قد يؤدي إلى فقدانها إن لم توجد نسخة احتياطية صالحة.</div>
<button class="btn" data-act="exportBk">تصدير نسخة احتياطية</button><button class="btn" data-act="restoreBk">استعادة نسخة احتياطية</button><input type="file" id="bkFile" accept=".json,application/json" style="display:none"></div>
<h2>عن التطبيق</h2><div class="glass card"><div class="note">فحصتي — الإصدار ${APP_VER}<br>يعمل دون إنترنت ويحفظ بياناته محليًا. لا يشخّص الأعطال؛ المهندس هو المسؤول عن تحديد الحالة والتوصيات.</div><button class="btn" data-act="credits">حقوق التطبيق</button></div></div>`};

VIEWS.credits=async()=>{const yr=new Date().getFullYear();
return `${topBar('حقوق التطبيق','',true)}
<div class="pad credits-page">
  <div class="cr-hero glass">
    <div class="cr-logo" aria-hidden="true">🚗</div>
    <div class="cr-app">فحصتي</div>
    <div class="cr-tag">تطبيق متخصص في فحص السيارات وتنظيم تقارير الحالة الفنية</div>
    <div class="cr-ver">الإصدار ${APP_VER}</div>
  </div>

  <div class="cr-card glass">
    <div class="cr-kicker">APP CREDITS</div>
    <div class="cr-label">Designed by</div>
    <div class="cr-name">Hamo Atef</div>
    <div class="cr-role">MA Graphic Designer</div>
    <div class="cr-divider"></div>
    <div class="cr-label">للتواصل</div>
    <div class="cr-phone" id="cPhone" dir="ltr">${CREDIT_PHONE}</div>
    <div class="cr-actions">
      <button class="btn primary cr-wa" data-act="waOpen">
        <span class="cr-wa-ico" aria-hidden="true"><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.435 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg></span>
        واتساب للشكاوى والاقتراحات
      </button>
      <button class="btn" data-act="copyPhone">نسخ رقم التواصل</button>
    </div>
  </div>

  <div class="cr-card glass cr-info">
    <div class="cr-info-row"><span>الاسم</span><b>فحصتي</b></div>
    <div class="cr-info-row"><span>الوصف</span><b>فحص السيارات وتقارير الحالة الفنية</b></div>
    <div class="cr-info-row"><span>التشغيل</span><b>محلي بالكامل — دون إنترنت</b></div>
    <div class="cr-info-row"><span>المسؤولية</span><b>المهندس يحدد الحالة والتوصيات</b></div>
  </div>

  <div class="cr-foot">
    <div>جميع الحقوق محفوظة © فحصتي ${yr}</div>
    <div class="cr-foot-en" dir="ltr">© ${yr} Hamo Atef. All Rights Reserved.</div>
  </div>
</div>`};

/* ---------- photos ---------- */
async function toDataUrl(src,max=1280){const blob=src.startsWith('data:')?await (await fetch(src)).blob():await (await fetch(src)).blob();
const bmp=await createImageBitmap(blob);const sc=Math.min(1,max/Math.max(bmp.width,bmp.height));const cv=document.createElement('canvas');cv.width=Math.round(bmp.width*sc);cv.height=Math.round(bmp.height*sc);
cv.getContext('2d').drawImage(bmp,0,0,cv.width,cv.height);return cv.toDataURL('image/jpeg',0.72)}
async function addPhotos(src,replaceId){const Cam=P('Camera');if(!Cam){toast('الكاميرا متاحة على أندرويد فقط','err');return}
let urls=[];
try{if(src==='camera'){const r=await Cam.getPhoto({quality:70,width:1280,allowEditing:false,resultType:'dataUrl',source:'CAMERA'});urls=[await toDataUrl(r.dataUrl)]}
else{const r=await Cam.pickImages({quality:70,width:1280,limit:replaceId?1:10});for(const p of r.photos)urls.push(await toDataUrl(p.webPath))}}
catch(e){const m=String(e&&e.message||e);if(/cancel/i.test(m))return;if(/permission|denied/i.test(m)){toast('تم رفض إذن الكاميرا/الصور. فعّله من إعدادات الهاتف','err');return}toast('تعذر الحصول على الصورة: '+m,'err');return}
if(!urls.length)return;
const ok=await dialog(`<b>معاينة قبل الحفظ</b><div class="pgrid" style="margin-top:10px">${urls.map(u=>`<img class="full" style="height:110px;object-fit:cover" src="${u}">`).join('')}</div>`,[{t:'إلغاء',v:false},{t:'حفظ',v:true,cls:'primary'}]);
if(!ok)return;
const added=[];try{for(const u of urls){const rec={id:uid(),inspectionId:INS.id,itemId:CURI,data:u,t:Date.now()};await dbPut('photos',rec);added.push(rec)}}
catch(e){toast('تعذر حفظ الصورة: '+(e.message||'مساحة التخزين غير كافية'),'err');return}
PH.push(...added);if(replaceId){await dbDel('photos',replaceId);PH=PH.filter(p=>p.id!==replaceId)}
toast('تم حفظ الصورة','ok');itemSheet(CURI)}

function itemSheet(id){const it=INS.items.find(x=>x.id===id);if(!it)return;CURI=id;const ph=PH.filter(p=>p.itemId===id);
openSheet(`<div class="sh-h"><b>${esc(it.name)}</b><button class="x" data-act="closeSheet">✕</button></div>
${it.custom?`<label>اسم البند</label><input id="iName" value="${esc(it.name)}">`:''}
<label>الحالة</label><div class="chips">${Object.keys(ST).map(k=>`<button class="chip ${it.status===k?'on':''}" style="--c:${ST[k][1]}" data-act="setSt" data-k="${k}">${ST[k][0]}</button>`).join('')}</div>
<label>موضع المشكلة</label><input id="iLoc" value="${esc(it.loc)}"><label>الملاحظات</label><textarea id="iNotes">${esc(it.notes)}</textarea>
<div id="sugBox" class="sug"></div><button class="btn" data-act="saveNoteLib">💾 حفظ هذه الملاحظة في المكتبة</button>
<label>الصور (${ph.length})</label><div class="pgrid">${ph.map(p=>`<div class="ph"><img src="${p.data}" data-act="viewPh" data-id="${p.id}"><div><button data-act="repPh" data-id="${p.id}">استبدال</button><button data-act="delPh" data-id="${p.id}">حذف</button></div></div>`).join('')}</div>
<div class="row"><button class="btn" data-act="addCam">📷 كاميرا</button><button class="btn" data-act="addGal">🖼️ المعرض</button></div>
${it.custom?'<button class="btn danger" data-act="delItem">حذف البند</button>':''}<button class="btn primary" data-act="closeSheet">تم</button><div id="saveInd" class="ind"></div>`);refreshSug()}

/* اقتراحات الملاحظات المشابهة: حسب القسم الفني + التشابه + عدد الاستخدامات. لا شيء يُضاف إلا بضغط المهندس */
let SUGSEQ=0,sugT=null;
async function refreshSug(){const seq=++SUGSEQ;if(!INS||!$('#sugBox'))return;const it=INS.items.find(x=>x.id===CURI);if(!it)return;
 const {notes,uses}=await notesWithUses(),thr=await getThr();if(seq!==SUGSEQ||!$('#sugBox'))return;
 const ta=$('#iNotes'),cur=ta?ta.value:it.notes,cn=normAr(cur);const taken=new Set((it.noteRefs||[]).filter(r=>cn.includes(normAr(r.t||''))).map(r=>r.id));
 const r=rankNotes(notes,uses,cur,INS.sections[it.section]).filter(x=>!taken.has(x.n.id)).slice(0,5);
 $('#sugBox').innerHTML=!notes.length?'<div class="note">لا توجد ملاحظات محفوظة بعد. اكتب ملاحظة ثم احفظها في المكتبة لتظهر كاقتراح لاحقًا.</div>'
  :r.length?`<div class="note"><b>اقتراحات من مكتبتك</b> — اضغط لإضافة الملاحظة (لن تُضاف دون اختيارك)</div>${r.map(x=>`<button class="sugi" data-act="useNote" data-id="${x.n.id}"><span>${esc(x.n.text.length>110?x.n.text.slice(0,110)+'…':x.n.text)}</span><small>${x.u} استخدام${x.u>=thr?' <b class="hot">⚠ عيب شائع</b>':''}${x.n.section&&x.n.section!==INS.sections[it.section]?' · من قسم «'+esc(x.n.section)+'»':''}</small></button>`).join('')}<div class="note">${esc(SRC_NOTE)}</div>`
  :'<div class="note">لا توجد ملاحظات مشابهة في المكتبة.</div>'}

/* ---------- PDF ---------- */
const dLines=s=>esc(s).replace(/\n/g,'<br>');
function buildHtml(i,ph,center,eng){const c=cnt(i.items);
const sec=i.sections.map((n,si)=>{const it=i.items.filter(x=>x.section===si);return `<h3>${esc(n)}</h3>${it.map(x=>{const pp=ph.filter(q=>q.itemId===x.id);return `<div class="it"><div class="h"><span>${esc(x.name)}</span><b style="color:${ST[x.status][1]}">● ${ST[x.status][0]}</b></div>${x.loc?`<div class="m">موضع المشكلة: ${esc(x.loc)}</div>`:''}${x.notes?`<div class="m">${dLines(x.notes)}</div>`:''}${pp.length?`<div class="ps">${pp.map(q=>`<img src="${q.data}">`).join('')}</div>`:''}</div>`}).join('')}`}).join('');
const un=i.items.filter(x=>x.status==='none');
return `<!DOCTYPE html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><style>
body{font-family:'Noto Naskh Arabic','Noto Sans Arabic','Droid Arabic Naskh',sans-serif;direction:rtl;font-size:12px;color:#101828;margin:0;padding:4px;line-height:1.7}
.hd{background:#101828;color:#fff;padding:12px 16px;border-radius:10px}.hd h1{margin:0;font-size:22px}.hd div{color:#c9d6f2}
table{width:100%;border-collapse:collapse;margin:10px 0}td{border:1px solid #dbe3f2;padding:5px 8px}td.k{background:#f4f7fb;width:28%;font-weight:bold}
h2{color:#246BFD;border-bottom:2px solid #246BFD;margin:16px 0 6px;font-size:15px}h3{background:#f4f7fb;padding:4px 8px;margin:12px 0 4px;font-size:13px;border-right:4px solid #246BFD}
.it{border-bottom:1px solid #e4e9f2;padding:5px 2px;page-break-inside:avoid}.h{display:flex;justify-content:space-between}.m{color:#475467;font-size:11.5px}
.ps img{width:46%;max-height:170px;object-fit:contain;margin:3px;border:1px solid #dbe3f2}.sm span{margin-left:14px;font-weight:bold}.ft{margin-top:20px;border-top:1px solid #999;padding-top:6px}
</style></head><body>
<div class="hd"><h1>فحصتي — تقرير فحص سيارة</h1>${center?`<div>${esc(center)}</div>`:''}</div>
<table><tr><td class="k">العميل</td><td>${esc(i.client.name)}</td><td class="k">الهاتف</td><td dir="ltr" style="text-align:right">${esc(i.client.phone)}</td></tr>
<tr><td class="k">الماركة والموديل</td><td>${esc([i.car.brand,i.car.model].filter(Boolean).join(' '))}</td><td class="k">سنة الصنع</td><td>${esc(i.car.year)}</td></tr>
<tr><td class="k">رقم اللوحة</td><td>${esc(i.car.plate)}</td><td class="k">قراءة العداد</td><td>${esc(i.car.km)}${i.car.km?' كم':''}</td></tr>
<tr><td class="k">رقم الشاسيه</td><td dir="ltr" style="text-align:right">${esc(i.car.vin)}</td><td class="k">تاريخ الفحص</td><td>${fmt(i.date)}</td></tr>
${eng?`<tr><td class="k">المهندس</td><td colspan="3">${esc(eng)}</td></tr>`:''}${i.client.notes?`<tr><td class="k">ملاحظات أولية</td><td colspan="3">${dLines(i.client.notes)}</td></tr>`:''}</table>
<h2>ملخص النتائج</h2><div class="sm"><span style="color:#3DDC84">سليم: ${c.ok}</span><span style="color:#F5A524">يحتاج متابعة: ${c.follow}</span><span style="color:#FF5C5C">يحتاج إصلاح: ${c.repair}</span><span style="color:#7A847C">لم يتم الفحص: ${c.none}</span></div>
${i.status!=='complete'?'<p style="color:#FF5C5C">تنبيه: هذه مسودة وليست تقريرًا نهائيًا.</p>':''}
<h2>تفاصيل الفحص</h2>${sec}
<h2>التوصيات</h2>${i.recs.length?i.recs.map(r=>`<div class="it"><b>[${PRI[r.priority]}]</b> ${dLines(r.text)}</div>`).join(''):'<div class="m">لا توجد توصيات مسجلة.</div>'}
<h2>البنود التي لم يتم فحصها</h2>${un.length?un.map(x=>`<div class="m">• ${esc(i.sections[x.section])} — ${esc(x.name)}</div>`).join(''):'<div class="m">لا توجد.</div>'}
<h2>الملاحظات النهائية</h2><div>${i.finalNotes?dLines(i.finalNotes):'—'}</div>
<div class="ft">هذا التقرير يعرض ما سجّله المهندس فقط ولا يمثل حكمًا آليًا على صلاحية السيارة للطريق.${eng?`<br><b>المهندس: ${esc(eng)}</b>`:''}</div></body></html>`}
const pdfName=i=>{const s=x=>String(x||'').replace(/[^\w\u0600-\u06FF-]+/g,'_').replace(/^_+|_+$/g,'');return `Fahsati_${s(i.car.plate)||'car'}_${new Date(i.date).toISOString().slice(0,10)}_${i.id.slice(-4)}.pdf`};
async function ensurePdf(force){await flushSave();const old=PDFS[INS.id];if(old&&!force&&old.t>(INS.updatedAt||0))return old;
const M=P('PdfMaker');if(!M||!(window.Capacitor&&Capacitor.isNativePlatform&&Capacitor.isNativePlatform()))throw new Error('إنشاء PDF متاح على أندرويد فقط');
const html=buildHtml(INS,PH,await getSet('center',''),await getSet('engineer',''));const name=pdfName(INS);
const r=await withTimeout(M.htmlToPdf({html,fileName:name}),60000,'انتهت مهلة إنشاء PDF (60 ثانية). حاول مرة أخرى.');if(!r||!r.valid||!(r.size>0))throw new Error('الملف الناتج غير صالح');
PDFS[INS.id]={path:r.path,name,size:r.size,t:Date.now()};const e=$('#pdfInfo');if(e)e.textContent=`آخر ملف: ${name} (${Math.round(r.size/1024)} ك.ب)`;return PDFS[INS.id]}

/* ---------- reminders ---------- */
async function nextNid(){const n=(await getSet('nid',1000))+1;await setSet('nid',n);return n}
async function schedule(r){const LN=P('LocalNotifications');if(!LN||r.canceled||new Date(r.at)<=new Date())return false;
try{let p=await LN.checkPermissions();if(p.display!=='granted')p=await LN.requestPermissions();if(p.display!=='granted')return false;
await LN.schedule({notifications:[{id:r.nid,title:'فحصتي — تذكير',body:r.reason,schedule:{at:new Date(r.at),allowWhileIdle:true}}]});return true}catch(e){console.warn(e);return false}}
async function unschedule(r){try{const LN=P('LocalNotifications');if(LN&&r.nid)await LN.cancel({notifications:[{id:r.nid}]})}catch(e){}}

/* ---------- backup ---------- */
const BK_STORES=['clients','cars','inspections','photos','reminders','settings','notes','tasks'];
const APP_VER='1.4.4',DB_SCHEMA=3;
async function sha256(str){try{if(window.crypto&&crypto.subtle){const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(str));return Array.from(new Uint8Array(b)).map(x=>x.toString(16).padStart(2,'0')).join('')}}catch(e){}return ''}
async function buildBackup(){const d={};for(const s of BK_STORES)d[s]=await dbAll(s);
const dataStr=JSON.stringify(d);
return {json:JSON.stringify({app:'fahsati',version:3,appVersion:APP_VER,dbSchema:DB_SCHEMA,stores:BK_STORES,exportedAt:new Date().toISOString(),counts:Object.fromEntries(BK_STORES.map(k=>[k,d[k].length])),sha256:await sha256(dataStr),data:d}),counts:Object.fromEntries(BK_STORES.map(k=>[k,d[k].length]))}}
function validateBackup(o){
 if(!o||typeof o!=='object'||o.app!=='fahsati')return{err:'الملف ليس نسخة احتياطية من فحصتي'};
 if(o.version!==1&&o.version!==2&&o.version!==3)return{err:'إصدار النسخة غير مدعوم ('+o.version+')'};
 const d=o.data;if(!d||typeof d!=='object')return{err:'بيانات النسخة مفقودة'};const hadNotes=Array.isArray(d.notes);const hadTasks=Array.isArray(d.tasks);
 for(const s of BK_STORES){if(d[s]===undefined)d[s]=[];if(!Array.isArray(d[s]))return{err:'قسم «'+s+'» تالف في الملف'}}
 for(const s of BK_STORES){const kp=s==='settings'?'key':'id';if(d[s].some(r=>!r||r[kp]==null))return{err:'يوجد سجل بلا معرّف في قسم «'+s+'»'}}
 if(d.inspections.some(i=>!i.client||!i.car||!Array.isArray(i.items)||!Array.isArray(i.sections)))return{err:'يوجد فحص ناقص البيانات في الملف'};
 const ids=new Set(d.inspections.map(i=>i.id));
 const badPh=d.photos.filter(p=>!p.data||typeof p.data!=='string'||!p.data.startsWith('data:')).length;
 const orphan=d.photos.filter(p=>!ids.has(p.inspectionId)).length;
 if(o.version===2&&o.counts){for(const s of BK_STORES)if(o.counts[s]!==undefined&&o.counts[s]!==d[s].length)return{err:'عدد السجلات في «'+s+'» لا يطابق المسجّل في الملف (الملف ناقص أو مقطوع)'}}
 return{d,badPh,orphan,hadNotes,hadTasks}}
async function writeBackupFile(FS,name,json){
 const CH=700000;let first=true;
 for(let k=0;k<json.length;k+=CH){const part=json.slice(k,k+CH);
  if(first){await withTimeout(FS.writeFile({path:name,data:part,directory:'CACHE',encoding:'utf8'}),60000,'انتهت مهلة كتابة الملف');first=false}
  else await withTimeout(FS.appendFile({path:name,data:part,directory:'CACHE',encoding:'utf8'}),60000,'انتهت مهلة كتابة الملف')}
 const st=await FS.stat({path:name,directory:'CACHE'});const bytes=new TextEncoder().encode(json).length;
 if(!st||Number(st.size)!==bytes)throw new Error('حجم الملف المكتوب ('+(st&&st.size)+') لا يطابق المتوقع ('+bytes+')');
 return bytes}
function bkErr(e){const m=String(e&&e.message||e);if(/ENOSPC|space|quota/i.test(m))return'مساحة التخزين غير كافية';if(/permission|denied|EACCES/i.test(m))return'لا توجد صلاحية للكتابة: '+m;return m}

/* ---------- actions ---------- */
const ACT={};
ACT.tab=(d)=>goTab(d.t);
ACT.back=()=>back();
ACT.newIns=()=>go('form',{});
ACT.openIns=once(async d=>{await loadIns(d.id);await go(INS.status==='complete'?'report':'check')});
ACT.saveForm=once(async()=>{const v=id=>($('#'+id).value||'').trim();const e=$('#fErr');const phone=normD(v('fPhone'));
if(!phone){e.textContent='رقم هاتف العميل مطلوب قبل الحفظ.';e.className='err on';return}
if(!validPhone(phone)){e.textContent='رقم الهاتف غير صحيح. أدخل رقمًا مصريًا مثل 01012345678 أو رقمًا دوليًا يبدأ بـ +.';e.className='err on';return}
e.className='err';const rawVin=$('#fVin').value;const vk=vinKey(rawVin);
if(vinOdd(vk)&&!await dialog(`<p style="line-height:1.9">رقم الشاسيه «<span dir="ltr">${esc(vk)}</span>» لا يطابق الصيغة القياسية (17 خانة من الأحرف والأرقام دون I وO وQ). قد يكون ذلك صحيحًا لبعض السيارات. هل تريد حفظه كما كُتب؟</p>`,[{t:'تعديل الرقم',v:false},{t:'حفظ كما هو',v:true,cls:'primary'}]))return;
const client={name:v('fName'),phone,notes:v('fNotes')},car={brand:v('fBrand'),model:v('fModel'),year:normD(v('fYear')),plate:v('fPlate'),km:normD(v('fKm')),vin:vk?rawVin:''};
const clients=await dbAll('clients');let cl=clients.find(c=>c.phone===phone);if(!cl)cl={id:uid(),created:Date.now()};cl.phone=phone;if(client.name)cl.name=client.name;await dbPut('clients',cl);
const cars=await dbAll('cars');let ca=null,note='';
if(vk)ca=cars.find(c=>c.clientId===cl.id&&vinKey(c.vin)===vk)||null;
if(!ca){const byPlate=c=>c.clientId===cl.id&&(car.plate?c.plate===car.plate:(!c.plate&&c.brand===car.brand&&c.model===car.model));
 const cand=cars.find(byPlate);
 if(cand){const cv=vinKey(cand.vin);
  if(vk&&cv&&cv!==vk)note='نفس اللوحة مسجلة لسيارة برقم شاسيه مختلف، فتم التعامل معها كسيارة منفصلة.';
  else{ca=cand;if(!vk&&cv){const use=await dialog(`<p style="line-height:1.9">هذه اللوحة مسجلة سابقًا برقم شاسيه <b dir="ltr">${esc(cand.vin)}</b>. هل هذه هي نفس السيارة وتريد استخدام الرقم في هذا الفحص؟</p>`,[{t:'لا، اتركه فارغًا',v:false},{t:'نعم، نفس السيارة',v:true,cls:'primary'}]);if(use)car.vin=cand.vin}}}}
if(!ca)ca={id:uid(),clientId:cl.id};
const upd={...car};if(!vinKey(upd.vin)||vinKey(ca.vin)===vinKey(upd.vin))delete upd.vin;/* لا يُمسح الشاسيه ولا يُعاد كتابة الرقم الأصلي بصيغة أخرى لنفس الرقم */Object.assign(ca,upd);await dbPut('cars',ca);
const items=[];TEMPLATE.forEach((s,si)=>s.i.forEach((n,ii)=>items.push({id:`s${si}i${ii}`,section:si,name:n,status:'none',notes:'',loc:'',custom:false})));
INS={id:uid(),clientId:cl.id,carId:ca.id,client,car,date:Date.now(),status:'draft',sections:TEMPLATE.map(s=>s.n),items,recs:[],finalNotes:'',updatedAt:Date.now()};PH=[];
await dbPut('inspections',INS);toast('تم إنشاء الفحص وحفظه كمسودة'+(note?' — '+note:''),'ok');await rep('check')});
ACT.openSec=d=>go('section',{i:+d.i});
ACT.openItem=d=>itemSheet(d.id);
ACT.closeSheet=async()=>{await flushSave();closeSheetEl();await render()};
ACT.setSt=d=>{const it=INS.items.find(x=>x.id===CURI);it.status=d.k;scheduleSave();itemSheet(CURI)};
/* تحديد كل القسم سليم: فقط البنود ذات status=none في القسم الحالي؛ لا تمس الملاحظات/الصور/الحالات المسجّلة */
let _secUndo=null,_secUndoT=null;
ACT.markSecOk=once(async d=>{
  if(!INS)return;const si=+d.i;
  const targets=INS.items.filter(x=>x.section===si&&x.status==='none');
  if(!targets.length){toast('لا توجد بنود غير محددة في هذا القسم','err');return}
  if(!await confirmD(`سيتم تعيين ${targets.length} بندًا غير محدد كـ «سليم» في قسم «${INS.sections[si]}». البنود التي لها حالة مسجّلة (سليم/متابعة/إصلاح) وملاحظاتها وصورها لن تتغيّر. متابعة؟`,'تحديد كسليم'))return;
  const prev=targets.map(x=>({id:x.id,status:x.status}));
  targets.forEach(x=>{x.status='ok'});
  if(!await saveIns()){prev.forEach(p=>{const it=INS.items.find(x=>x.id===p.id);if(it)it.status=p.status});toast('تعذر الحفظ','err');return}
  _secUndo={si,prev,ts:Date.now()};
  clearTimeout(_secUndoT);_secUndoT=setTimeout(()=>{_secUndo=null},15000);
  toast(`تم تعيين ${targets.length} بندًا كسليم. اضغط «تراجع» خلال 15 ثانية إن أردت.`, 'ok');
  await render();
  /* زر تراجع مؤقت في أعلى القائمة إن أمكن */
  const pad=$('.pad');if(pad&&_secUndo){const u=document.createElement('button');u.className='btn';u.style.cssText='margin-bottom:10px;border-color:#F5A524';u.textContent='↩ تراجع عن تحديد القسم سليم';u.dataset.act='undoMarkSec';pad.insertBefore(u,pad.firstChild)}
});
ACT.undoMarkSec=once(async()=>{
  if(!_secUndo||!INS){toast('لا يوجد تراجع متاح','err');return}
  const {prev}=_secUndo;_secUndo=null;clearTimeout(_secUndoT);
  prev.forEach(p=>{const it=INS.items.find(x=>x.id===p.id);if(it)it.status=p.status});
  if(!await saveIns()){toast('تعذر التراجع','err');return}
  toast('تم التراجع','ok');await render()
});
ACT.addCam=once(()=>addPhotos('camera'));ACT.addGal=once(()=>addPhotos('gallery'));
ACT.repPh=once(async d=>{const ok=await confirmD('سيتم استبدال هذه الصورة بصورة جديدة بعد اختيارها. متابعة؟');if(ok)await addPhotos('camera',d.id)});
ACT.delPh=async d=>{if(!await confirmD('هل تريد حذف هذه الصورة؟','حذف'))return;await dbDel('photos',d.id);PH=PH.filter(p=>p.id!==d.id);itemSheet(CURI)};
ACT.viewPh=d=>{const p=PH.find(x=>x.id===d.id);dialog(`<img class="full" src="${p.data}">`,[{t:'إغلاق',v:1}])};
ACT.addItem=async d=>{const n=await new Promise(res=>{$('#dlg').innerHTML=`<div class="dbox"><b>بند مخصص جديد</b><input id="nn" placeholder="اسم البند" style="margin-top:10px"><div class="row" style="margin-top:10px"><button class="btn" id="nc">إلغاء</button><button class="btn primary" id="no">إضافة</button></div></div>`;$('#dlg').classList.add('on');const fin=v=>{_dlgRes=null;$('#dlg').classList.remove('on');$('#dlg').innerHTML='';res(v)};_dlgRes=fin;$('#dlg').onclick=null;$('#nc').onclick=()=>fin(null);$('#no').onclick=()=>fin($('#nn').value.trim())});
if(!n)return;INS.items.push({id:'c'+uid(),section:+d.i,name:n,status:'none',notes:'',loc:'',custom:true});if(!await saveIns())return;await render()};
ACT.delItem=async()=>{if(!await confirmD('حذف هذا البند المخصص وصوره؟','حذف'))return;for(const p of PH.filter(p=>p.itemId===CURI))await dbDel('photos',p.id);PH=PH.filter(p=>p.itemId!==CURI);INS.items=INS.items.filter(x=>x.id!==CURI);await saveIns();closeSheetEl();await render()};
ACT.saveDraft=once(async()=>{if(!await saveIns())return;const chk=await dbGet('inspections',INS.id);if(!chk){toast('تعذر التأكد من الحفظ','err');return}toast('تم حفظ المسودة','ok');await goTab('home')});
ACT.toSummary=()=>go('summary');
ACT.addRec=async()=>{const t=$('#recT').value.trim();if(!t){toast('اكتب نص التوصية أولًا','err');return}INS.finalNotes=$('#finalN').value;INS.recs.push({id:uid(),text:t,priority:$('#recP').value});if(await saveIns())await render()};
ACT.delRec=async d=>{INS.finalNotes=$('#finalN').value;INS.recs=INS.recs.filter(r=>r.id!==d.id);if(await saveIns())await render()};
ACT.finish=once(async()=>{if(INS.status==='complete'&&PDFS[INS.id]){await go('report');return}
INS.finalNotes=$('#finalN')?$('#finalN').value:INS.finalNotes;const un=INS.items.filter(x=>x.status==='none').length;
if(un&&!await confirmD(`يوجد ${un} بند لم يتم فحصه وسيظهر في التقرير كـ «لم يتم الفحص». هل تريد الاعتماد؟`,'اعتماد'))return;
const prev={status:INS.status,completedAt:INS.completedAt};
{const nm=new Map((await dbAll('notes')).map(n=>[n.id,n]));INS.items.forEach(x=>sanitizeRefs(x,nm))}
INS.status='complete';INS.completedAt=Date.now();
try{
 if(!await saveIns())throw new Error('تعذر حفظ الفحص');
 const chk=await dbGet('inspections',INS.id);if(!chk||chk.status!=='complete')throw new Error('تعذر التأكد من حفظ الفحص');
 await ensurePdf(true);
}catch(e){
 console.error(e);INS.status=prev.status;INS.completedAt=prev.completedAt;await saveIns();delete PDFS[INS.id];
 toast('لم يكتمل الاعتماد: '+(e&&e.message||e)+' — بيانات الفحص محفوظة كمسودة ويمكنك المحاولة مرة أخرى.','err');return}
toast('تم اعتماد الفحص وإنشاء التقرير','ok');stack=[{v:'home',p:{}}];await go('report')});
ACT.resume=async()=>rep('check');
ACT.reopen=async()=>{if(!await confirmD('سيعود الفحص إلى مسودة للتعديل، ثم يلزم اعتماده من جديد. متابعة؟'))return;INS.status='draft';delete PDFS[INS.id];await saveIns();await rep('check')};
ACT.reNew=()=>go('form',{prefill:{client:{...INS.client,notes:''},car:{...INS.car,km:''}}});
ACT.delIns=once(async()=>{if(!await confirmD('سيتم حذف الفحص وجميع صوره نهائيًا. هل أنت متأكد؟','حذف نهائي'))return;await delInspection(INS.id);INS=null;PH=[];toast('تم الحذف','ok');await goTab('history')});
ACT.mkPdf=once(async()=>{const p=await ensurePdf(true);toast('تم إنشاء ملف PDF بنجاح','ok')});
ACT.prevPdf=once(async()=>{const p=await ensurePdf();try{await P('PdfMaker').openPdf({path:p.path})}catch(e){toast('لا يوجد تطبيق لعرض PDF على الجهاز. استخدم المشاركة أو الحفظ.','err')}});
ACT.savePdf=once(async()=>{const p=await ensurePdf();const r=await P('PdfMaker').saveToDownloads({path:p.path,name:p.name,mime:'application/pdf'});toast('تم حفظ الملف في: '+r.location,'ok')});
ACT.sharePdf=once(async()=>{const p=await ensurePdf();await P('Share').share({title:'تقرير فحص سيارة',dialogTitle:'مشاركة التقرير',files:['file://'+p.path]})});
ACT.remNew=()=>go('remForm',{});
ACT.remFor=()=>go('remForm',{insId:INS.id});
ACT.remEdit=async d=>go('remForm',{r:await dbGet('reminders',d.id)});
ACT.remSave=once(async d=>{const why=$('#rWhy').value.trim(),at=$('#rAt').value,e=$('#rErr');if(!why||!at){e.textContent='اكتب سبب التذكير وحدد التاريخ والوقت.';e.className='err on';return}
const iid=$('#rIns').value;const ins=iid?await dbGet('inspections',iid):null;const old=d.id?await dbGet('reminders',d.id):null;
const r=Object.assign(old||{id:uid(),nid:await nextNid()},{reason:why,at:new Date(at).toISOString(),canceled:false,inspectionId:iid||null,label:ins?`${ins.client.name} — ${carLine(ins)} ${ins.car.plate}`:''});
if(old)await unschedule(old);await dbPut('reminders',r);const s=await schedule(r);
toast(s?'تم حفظ التذكير وجدولة الإشعار':'تم حفظ التذكير داخل التطبيق (لم تُجدول إشعارات النظام: الإذن غير ممنوح أو الوقت مضى)',s?'ok':'');await back()});
ACT.remCancel=async d=>{if(!await confirmD('إلغاء هذا التذكير؟','إلغاء التذكير'))return;const r=await dbGet('reminders',d.id);r.canceled=true;await unschedule(r);await dbPut('reminders',r);await render()};
ACT.remDel=async d=>{if(!await confirmD('حذف هذا التذكير نهائيًا؟','حذف'))return;const r=await dbGet('reminders',d.id);await unschedule(r);await dbDel('reminders',d.id);await render()};
ACT.saveSettings=once(async()=>{await setSet('center',$('#sCenter').value.trim());await setSet('engineer',$('#sEng').value.trim());const c=await getSet('center','');if(c!==$('#sCenter').value.trim())throw new Error('لم يتم الحفظ');toast('تم حفظ الإعدادات','ok')});
ACT.notifPerm=once(async()=>{const LN=P('LocalNotifications');if(!LN){toast('الإشعارات متاحة على أندرويد فقط','err');return}let p=await LN.checkPermissions();if(p.display!=='granted')p=await LN.requestPermissions();
toast(p.display==='granted'?'إذن الإشعارات ممنوح (لا يضمن النظام وصول كل إشعار)':'إذن الإشعارات غير ممنوح. التذكيرات تبقى ظاهرة داخل التطبيق فقط.',p.display==='granted'?'ok':'err')});

/* ---------- أفعال: البحث وملف السيارة ---------- */
ACT.goSearch=async()=>{await go('search',{});setTimeout(()=>{const h=$('#hq');if(h)h.focus()},60)};
ACT.openVeh=d=>go('vehicle',{vin:d.vin});
ACT.vehOrder=d=>rep('vehicle',{vin:d.vin,asc:!d.asc});

/* ---------- أفعال: مكتبة الملاحظات ---------- */
ACT.goNotes=()=>go('notes',{});
ACT.goTasks=()=>go('tasks',{});
ACT.dashList=d=>go('dashList',{k:d.k});
ACT.openTask=async d=>{const t=await dbGet('tasks',d.id);if(!t){toast('المهمة غير موجودة','err');return}await go('taskForm',{t})};
ACT.taskSetSt=async d=>{const t=await dbGet('tasks',d.id);if(!t)return;t.status=d.k;t.updatedAt=Date.now();
  if(t.status==='done')await unscheduleTask(t);
  await dbPut('tasks',t);await rep('taskForm',{t});toast('تم تحديث الحالة','ok')};
ACT.taskSave=once(async d=>{const t=await dbGet('tasks',d.id);if(!t){toast('المهمة غير موجودة','err');return}
  t.notes=($('#taskNotes')&&$('#taskNotes').value)||'';
  const dv=$('#taskDue')&&$('#taskDue').value;
  const prevDue=t.dueAt;t.dueAt=dv?new Date(dv).getTime():null;t.updatedAt=Date.now();
  if(prevDue!==t.dueAt||t.status==='done'){await unscheduleTask(t);t.nid=null}
  if(t.dueAt&&t.status!=='done'){const ok=await scheduleTask(t);if(!ok)toast('حُفظ الموعد. تأكد من إذن الإشعارات لتصلك التذكيرات.','err')}
  await dbPut('tasks',t);toast('تم حفظ المهمة','ok');await back()});
ACT.taskDel=async d=>{if(!await confirmD('حذف هذه المهمة نهائيًا؟ (لا يؤثر على التقرير الأصلي)','حذف'))return;
  const t=await dbGet('tasks',d.id);if(t)await unscheduleTask(t);await dbDel('tasks',d.id);toast('تم الحذف','ok');await back()};
ACT.makeTask=once(async d=>{if(!INS)return;const it=INS.items.find(x=>x.id===d.item);if(!it)return;
  if(it.status!=='repair'&&it.status!=='follow'){toast('المهمة تُنشأ لبنود يحتاج إصلاح أو متابعة فقط','err');return}
  const keys=await existingTaskKeys();const key=INS.id+'|'+it.id;
  if(keys.has(key)){toast('توجد مهمة مسبقة لهذا البند','err');return}
  const t=taskFromItem(INS,it);await dbPut('tasks',t);toast('تم إنشاء مهمة الإصلاح','ok');await render()});
ACT.makeTasksAll=once(async()=>{if(!INS)return;
  const imp=INS.items.filter(x=>x.status==='repair'||x.status==='follow');
  if(!imp.length){toast('لا توجد بنود','err');return}
  const keys=await existingTaskKeys();let n=0;
  for(const it of imp){const key=INS.id+'|'+it.id;if(keys.has(key))continue;const t=taskFromItem(INS,it);await dbPut('tasks',t);keys.add(key);n++}
  toast(n?`تم إنشاء ${n} مهمة`:'كل البنود لها مهام مسبقة','ok');await render()});

const noteForm=(n)=>`<div class="sh-h"><b>${n?'تعديل ملاحظة':'ملاحظة جديدة'}</b><button class="x" data-act="closeNoteSheet">✕</button></div>
<label>نص الملاحظة *</label><textarea id="nTxt" style="min-height:110px">${esc(n?n.text:'')}</textarea>
<label>القسم الفني</label><select id="nSecSel"><option value="">عام (كل الأقسام)</option>${SEC_NAMES().map(x=>`<option ${n&&n.section===x?'selected':''}>${esc(x)}</option>`).join('')}</select>
<div id="nfErr" class="err"></div><button class="btn primary" data-act="saveNote" data-id="${n?n.id:''}">حفظ</button>`;
ACT.noteAdd=()=>{const cur=stack[stack.length-1].p||{};openSheet(noteForm(null));if(cur.sec&&cur.sec!=='__gen')$('#nSecSel').value=cur.sec};
ACT.noteEdit=async d=>{const n=await dbGet('notes',d.id);if(n)openSheet(noteForm(n))};
ACT.closeNoteSheet=async()=>{closeSheetEl();await render()};
ACT.saveNote=async d=>{const t=($('#nTxt').value||'').trim(),sec=$('#nSecSel').value,e=$('#nfErr');
 if(!t){e.textContent='اكتب نص الملاحظة.';e.className='err on';return}
 if(t.length>500){e.textContent='النص طويل (الحد 500 حرف).';e.className='err on';return}
 const all=await dbAll('notes'),nt=normAr(t);
 if(all.some(n=>n.id!==d.id&&(n.section||'')===sec&&normAr(n.text)===nt)){e.textContent='هذه الملاحظة موجودة بالفعل في نفس القسم.';e.className='err on';return}
 const old=d.id?await dbGet('notes',d.id):null;
 const rec=Object.assign(old||{id:uid(),createdAt:Date.now()},{text:t,section:sec,updatedAt:Date.now()});await dbPut('notes',rec);
 const chk=await dbGet('notes',rec.id);if(!chk||chk.text!==t){toast('تعذر التأكد من الحفظ','err');return}
 toast(old?'تم تعديل الملاحظة':'تمت إضافة الملاحظة','ok');closeSheetEl();await render()};
ACT.noteDel=async d=>{const n=await dbGet('notes',d.id);if(!n)return;const {uses}=await notesWithUses();const u=uses[n.id]||0;
 if(!await confirmD(`حذف هذه الملاحظة من المكتبة؟${u?` استُخدمت في ${u} فحص معتمد؛ ستبقى نصوص تلك التقارير كما هي، لكن يختفي عدّاد استخداماتها.`:''}`,'حذف'))return;
 await dbDel('notes',d.id);toast('تم حذف الملاحظة','ok');await render()};
ACT.saveThr=async()=>{const e=$('#nErr'),v=$('#nThr').value.trim();const n=Number(normD(v));
 if(!/^\d+$/.test(normD(v))||n<1||n>9999){e.textContent='أدخل عددًا صحيحًا بين 1 و9999.';e.className='err on';return}
 e.className='err';await setSet('commonThreshold',n);if(await getThr()!==n){toast('لم يتم الحفظ','err');return}toast('تم حفظ الحد: '+n,'ok');await render()};
/* من شاشة البند */
ACT.useNote=async d=>{const it=INS&&INS.items.find(x=>x.id===CURI),n=await dbGet('notes',d.id);if(!it||!n)return;
 const ta=$('#iNotes'),cur=ta?ta.value:it.notes,cn=normAr(cur),nn=normAr(n.text);let nv;
 if(!cur.trim()||(nn.includes(cn)&&cn.length<nn.length))nv=n.text;else if(cn.includes(nn))nv=cur;else nv=cur.replace(/\s+$/,'')+'\n'+n.text;
 it.notes=nv;if(ta)ta.value=nv;it.noteRefs=(it.noteRefs||[]).filter(r=>r.id!==n.id).concat({id:n.id,t:n.text});scheduleSave();refreshSug();toast('أُضيفت الملاحظة','ok')};
ACT.saveNoteLib=async()=>{const it=INS&&INS.items.find(x=>x.id===CURI);if(!it)return;const ta=$('#iNotes'),t=((ta?ta.value:it.notes)||'').trim();
 if(!t){toast('اكتب الملاحظة أولًا','err');return}if(t.length>500){toast('النص أطول من 500 حرف؛ اختصره قبل الحفظ في المكتبة','err');return}
 const sec=INS.sections[it.section],all=await dbAll('notes'),nt=normAr(t);let n=all.find(x=>(x.section||'')===sec&&normAr(x.text)===nt);
 if(n)toast('الملاحظة موجودة في المكتبة بالفعل','ok');else{n={id:uid(),text:t,section:sec,createdAt:Date.now(),updatedAt:Date.now()};await dbPut('notes',n);if(!await dbGet('notes',n.id)){toast('تعذر الحفظ','err');return}toast('تم الحفظ في المكتبة','ok')}
 it.noteRefs=(it.noteRefs||[]).filter(r=>r.id!==n.id).concat({id:n.id,t:n.text});scheduleSave();refreshSug()};
ACT.credits=()=>go('credits');
const WA_PHONE='201271323579';
const WA_URL='https://wa.me/'+WA_PHONE;
ACT.waOpen=async()=>{
  /*
   * لا نحمّل wa.me داخل WebView إطلاقًا:
   * السيرفر يحوّل إلى whatsapp:// فيظهر net::ERR_UNKNOWN_URL_SCHEME.
   * الفتح يتم فقط عبر Intent أصلي خارج WebView.
   */
  const isNative=!!(window.Capacitor&&Capacitor.isNativePlatform&&Capacitor.isNativePlatform());
  if(isNative){
    try{
      const M=P('PdfMaker');
      if(M&&M.openUrl){
        await M.openUrl({url:WA_URL});
        toast('جاري فتح واتساب…','ok');
        return;
      }
      throw new Error('openUrl غير متاح — أعد بناء APK');
    }catch(e){
      console.warn(e);
      try{
        const C=P('Clipboard');
        if(C)await C.write({string:WA_URL});
        else if(navigator.clipboard)await navigator.clipboard.writeText(WA_URL);
      }catch(_){}
      toast('تعذر فتح واتساب من التطبيق. تأكد أن واتساب مثبّت، أو انسخ الرقم: '+CREDIT_PHONE+' — وإن استمر الخطأ أعد تثبيت نسخة APK محدّثة.','err');
      return;
    }
  }
  /* متصفح عادي (تطوير): فتح في نافذة جديدة فقط */
  try{
    const w=window.open(WA_URL,'_blank','noopener,noreferrer');
    if(w){toast('جاري فتح واتساب…','ok');return}
  }catch(e){}
  try{
    if(navigator.clipboard)await navigator.clipboard.writeText(WA_URL);
    toast('تم نسخ رابط واتساب. الصقه في المتصفح. الرقم: '+CREDIT_PHONE,'err');
  }catch(e){
    toast('الرقم: '+CREDIT_PHONE+' | '+WA_URL,'err');
  }
};
ACT.copyPhone=async()=>{try{const C=P('Clipboard');if(C&&window.Capacitor&&Capacitor.isNativePlatform())await C.write({string:CREDIT_PHONE});else await navigator.clipboard.writeText(CREDIT_PHONE);toast('تم نسخ الرقم '+CREDIT_PHONE,'ok')}catch(e){toast('تعذر نسخ الرقم','err')}};
ACT.exportBk=once(async()=>{
 const FS=P('Filesystem');if(!FS||!(window.Capacitor&&Capacitor.isNativePlatform&&Capacitor.isNativePlatform()))throw new Error('النسخ الاحتياطي متاح على أندرويد فقط');
 await flushSave();const {json,counts}=await buildBackup();
 const name=`Fahsati_backup_${new Date().toISOString().slice(0,19).replace(/[:T]/g,'-')}.json`;
 let bytes;try{bytes=await writeBackupFile(FS,name,json)}catch(e){throw new Error('فشل إنشاء ملف النسخة: '+bkErr(e))}
 const u=await FS.getUri({path:name,directory:'CACHE'});const abs=decodeURIComponent(u.uri.replace('file://',''));
 let loc='',saveErr='';try{const r=await withTimeout(P('PdfMaker').saveToDownloads({path:abs,name,mime:'application/json'}),30000,'انتهت مهلة الحفظ');loc=r.location}catch(e){saveErr=bkErr(e)}
 const sum=`${counts.inspections} فحص، ${counts.photos} صورة، ${counts.clients} عميل، ${counts.reminders} تذكير، ${counts.tasks||0} مهمة`;
 if(loc){await setSet('lastBackup',Date.now());toast(`تم حفظ النسخة (${sum}) في: ${loc}`,'ok')}
 else toast('تعذر الحفظ في التنزيلات ('+saveErr+'). اختر مكانًا من نافذة المشاركة التالية.','err');
 try{await P('Share').share({title:'نسخة فحصتي الاحتياطية',dialogTitle:'اختر مكان حفظ/مشاركة النسخة',files:[u.uri]});if(!loc)await setSet('lastBackup',Date.now())}catch(e){if(!loc&&!/cancel/i.test(String(e&&e.message||e)))throw new Error('لم تُحفظ النسخة: '+bkErr(e))}
 await render()});
ACT.restoreBk=()=>$('#bkFile').click();
const runTx=(stores,body)=>new Promise((res,rej)=>{const t=db.transaction(stores,'readwrite');let failed=null;t.oncomplete=()=>res();t.onabort=()=>rej(failed||t.error||new Error('أُلغيت العملية'));try{body(t)}catch(e){failed=e;try{t.abort()}catch(_){}}});
async function countsNow(){const c={};for(const s of BK_STORES)c[s]=(await dbAll(s)).length;return c}
async function doRestore(file){
 let o;try{o=JSON.parse(await file.text())}catch(e){toast('الملف تالف أو ليس نسخة احتياطية صالحة','err');return}
 const v=validateBackup(o);if(v.err){toast(v.err,'err');return}
 if((o.version===2||o.version===3)&&o.sha256){const hd={};const stores=Array.isArray(o.stores)?o.stores:BK_STORES.filter(x=>x!=='notes'&&x!=='tasks');stores.forEach(x=>{hd[x]=v.d[x]});const h=await sha256(JSON.stringify(hd));if(h&&h!==o.sha256){toast('فشل فحص سلامة الملف (البصمة لا تطابق). الملف تالف أو معدّل.','err');return}}
 const d=v.d,before=await countsNow();
 const mode=await dialog(`<b>استعادة نسخة احتياطية</b><p style="line-height:1.9">الملف سليم. تاريخ النسخة: ${esc(fmt(o.exportedAt))}<br>في الملف: ${d.inspections.length} فحص، ${d.photos.length} صورة، ${d.clients.length} عميل، ${d.cars.length} سيارة، ${d.reminders.length} تذكير.<br>الموجود الآن: ${before.inspections} فحص، ${before.photos} صورة.${v.badPh||v.orphan?`<br><span style="color:#FF5C5C">تنبيه: ${v.badPh} صورة تالفة و${v.orphan} بلا فحص مرتبط ولن تُستعاد.</span>`:''}</p><p class="note"><b>دمج:</b> يضيف غير الموجود فقط ولا يحذف شيئًا.<br><b>استبدال:</b> يمسح بيانات الجهاز الحالية ويضع بيانات النسخة (عملية واحدة؛ تُلغى كاملة عند أي فشل).</p>`,[{t:'إلغاء',v:false},{t:'دمج',v:'merge',cls:'primary'},{t:'استبدال',v:'replace',cls:'danger'}]);
 if(!mode)return;
 if(mode==='replace'&&!await confirmD(`سيتم استبدال كل البيانات الحالية (${before.inspections} فحص و${before.photos} صورة) ببيانات النسخة. لا يمكن التراجع. هل أنت متأكد؟`,'استبدال'))return;
 busy=true;load(true);
 try{
  const okPh=r=>r.data&&typeof r.data==='string'&&r.data.startsWith('data:')&&d.inspections.some(i=>i.id===r.inspectionId);
  const data={};for(const s of BK_STORES)data[s]=s==='photos'?d.photos.filter(okPh):d[s];
  const unsched=await dbAll('reminders');
  if(mode==='replace'){
   await runTx(BK_STORES,t=>{BK_STORES.forEach(n=>{if(n==='notes'&&!v.hadNotes)return;/* نسخة قديمة بلا مكتبة */if(n==='tasks'&&!v.hadTasks)return;/* نسخة قديمة بلا مهام */const o2=t.objectStore(n);o2.clear();data[n].forEach(r=>o2.put(r))})});
   for(const r of unsched)await unschedule(r)}
  else{
   const ex={};for(const s of BK_STORES)ex[s]=new Set((await dbAll(s)).map(x=>x[s==='settings'?'key':'id']));
   await runTx(BK_STORES,t=>{BK_STORES.forEach(n=>{const kp=n==='settings'?'key':'id';data[n].forEach(r=>{if(!ex[n].has(r[kp]))t.objectStore(n).put(r)})})})}
  // verification: every restorable record must exist now
  const after=await countsNow();
  for(const s of BK_STORES){const kp=s==='settings'?'key':'id';const have=new Set((await dbAll(s)).map(x=>x[kp]));const miss=data[s].filter(r=>!have.has(r[kp])).length;if(miss)throw new Error(`فشل التحقق: ${miss} سجل مفقود في «${s}»`);
   if(mode==='replace'&&!(s==='notes'&&!v.hadNotes)&&after[s]!==data[s].length)throw new Error(`فشل التحقق: عدد «${s}» (${after[s]}) لا يطابق الملف (${data[s].length})`)}
  const photoIds=new Set((await dbAll('inspections')).map(i=>i.id));if((await dbAll('photos')).some(p=>!photoIds.has(p.inspectionId)))throw new Error('فشل التحقق: توجد صور غير مرتبطة بفحصها');
  for(const r of await dbAll('reminders'))if(!r.canceled)await schedule(r);
  PDFS={};toast(`تمت الاستعادة (${mode==='replace'?'استبدال':'دمج'}) وتم التحقق: ${after.inspections} فحص، ${after.photos} صورة، ${after.clients} عميل، ${after.reminders} تذكير`,'ok');await render()
 }catch(e){toast('فشلت الاستعادة: '+bkErr(e)+(mode==='replace'?' — لم تتغير بياناتك الحالية.':''),'err')}
 finally{busy=false;load(false)}}

/* ---------- events ---------- */
document.addEventListener('click',e=>{const el=e.target.closest('[data-act]');if(!el)return;const f=ACT[el.dataset.act];if(f)Promise.resolve(f(el.dataset,el)).catch(er=>toast('حدث خطأ: '+er.message,'err'))});
document.addEventListener('input',e=>{const t=e.target;if(!INS)return;const it=INS.items.find(x=>x.id===CURI);
if(t.id==='iNotes'&&it){it.notes=t.value;scheduleSave()}else if(t.id==='iLoc'&&it){it.loc=t.value;scheduleSave()}else if(t.id==='iName'&&it){it.name=t.value||it.name;scheduleSave()}
else if(t.id==='finalN'){INS.finalNotes=t.value;scheduleSave()}});
document.addEventListener('input',e=>{if(e.target.id==='hq'){clearTimeout(window.__hq);const v=e.target.value;window.__hq=setTimeout(async()=>{const cur=stack[stack.length-1];cur.p={q:v};const h=await VIEWS[cur.v](cur.p);const tmp=document.createElement('div');tmp.innerHTML=h;$('#hlist').innerHTML=tmp.querySelector('#hlist').innerHTML},200)}});
async function refreshNotesList(){const cur=stack[stack.length-1];if(cur.v!=='notes'||!$('#nlist'))return;const {notes,uses}=await notesWithUses();$('#nlist').innerHTML=notesListHtml(notes,uses,await getThr(),cur.p)}
document.addEventListener('input',e=>{const id=e.target.id;if(id==='nq'){const cur=stack[stack.length-1];cur.p.q=e.target.value;refreshNotesList()}
 else if(id==='iNotes'){clearTimeout(sugT);sugT=setTimeout(refreshSug,150)}
 else if(id==='tq'){clearTimeout(window.__tq);const v=e.target.value;window.__tq=setTimeout(async()=>{const cur=stack[stack.length-1];if(cur.v!=='tasks')return;cur.p={...cur.p,q:v};await rep('tasks',cur.p)},200)}});
document.addEventListener('change',e=>{const id=e.target.id;if(id==='nSec'||id==='nFlt'){const cur=stack[stack.length-1];cur.p[id==='nSec'?'sec':'flt']=e.target.value;refreshNotesList()}
 else if(id==='tSt'||id==='tDf'){const cur=stack[stack.length-1];if(cur.v!=='tasks')return;cur.p={...cur.p,st:id==='tSt'?e.target.value:cur.p.st||'',df:id==='tDf'?e.target.value:cur.p.df||''};rep('tasks',cur.p)}});
document.addEventListener('change',e=>{if(e.target.id==='prevSel'){const i=window.__prev[+e.target.value];if(!i)return;const set=(id,v)=>$('#'+id).value=v||'';set('fName',i.client.name);set('fPhone',i.client.phone);set('fBrand',i.car.brand);set('fModel',i.car.model);set('fYear',i.car.year);set('fPlate',i.car.plate);set('fVin',i.car.vin);set('fKm','')}
if(e.target.id==='bkFile'&&e.target.files[0]){const f=e.target.files[0];e.target.value='';doRestore(f)}});

/* ---------- init ---------- */
(async function(){try{await openDB();if(navigator.storage&&navigator.storage.persist)navigator.storage.persist().catch(()=>{});
for(const r of await dbAll('reminders'))if(!r.canceled&&new Date(r.at)>new Date())schedule(r);
for(const t of await dbAll('tasks'))if(t.dueAt&&t.status!=='done'&&new Date(t.dueAt)>new Date())scheduleTask(t);
/* زر الرجوع الأصلي / الإيماءة — أولوية: حوار → ورقة → المكدس → تأكيد الخروج */
let _backBusy=false,_exitAsk=false;
async function handleBack(){
  if(_backBusy)return;_backBusy=true;
  try{
    if(dismissDlg(false))return;
    if($('#sheet')&&$('#sheet').classList.contains('on')){await ACT.closeSheet();return}
    if(stack.length>1){await back();return}
    /* الشاشة الرئيسية: لا إغلاق فوري */
    if(_exitAsk){const A=P('App');if(A&&A.exitApp)A.exitApp();return}
    _exitAsk=true;
    const ok=await dialog('<p style="line-height:1.9">هل تريد إغلاق تطبيق فحصتي؟</p>',[{t:'البقاء',v:false},{t:'إغلاق',v:true,cls:'danger'}]);
    _exitAsk=false;
    if(ok){const A=P('App');if(A&&A.exitApp)A.exitApp()}
  }finally{_backBusy=false}
}
const A=P('App');if(A&&A.addListener)A.addListener('backButton',()=>{handleBack()});
await render()}catch(e){document.body.innerHTML='<div style="padding:30px;font-family:sans-serif;direction:rtl;background:#111512;color:#F4F6F1;min-height:100vh">تعذر فتح قاعدة البيانات المحلية: '+esc(e.message)+'</div>'}})();
