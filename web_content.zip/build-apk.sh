#!/usr/bin/env bash
set -e
cd android
gradle assembleDebug
echo "APK generado en android/app/build/outputs/apk/debug/app-debug.apk"
