#!/usr/bin/env bash
# Quick build script for Linux / macOS
chmod +x gradlew
./gradlew assembleDebug
echo "----------------------------------------------------"
echo "Build complete! Your APK is located at:"
echo "app/build/outputs/apk/debug/app-debug.apk"
echo "----------------------------------------------------"
