#!/usr/bin/env bash
# ShieldVPN Android APK Builder Script (via Capacitor)
# Run this on your local machine with Node.js and Android Studio installed

set -e

echo "============================================="
echo "   ShieldVPN - Android APK Build Pipeline   "
echo "============================================="

echo "[1/4] Installing Capacitor dependencies..."
npm install --save @capacitor/core @capacitor/cli @capacitor/android

echo "[2/4] Building web production assets (Vite)..."
npm run build

echo "[3/4] Initializing and syncing Android project..."
if [ ! -d "android" ]; then
  npx cap init "ShieldVPN" "com.shieldvpn.app" --web-dir dist
  npx cap add android
else
  npx cap sync android
fi

echo "[4/4] Opening in Android Studio or compiling debug APK..."
if command -v ./android/gradlew &> /dev/null; then
  cd android
  ./gradlew assembleDebug
  cp app/build/outputs/apk/debug/app-debug.apk ../app-debug.apk
  echo "SUCCESS! APK built at: $(pwd)/../app-debug.apk"
else
  echo "Opening project in Android Studio..."
  npx cap open android
  echo "In Android Studio: Click 'Build' -> 'Build Bundle(s) / APK(s)' -> 'Build APK(s)'"
fi
