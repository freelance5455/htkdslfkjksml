#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
echo "=== Building Mizo_q TikTok Toolkit V6.0 Debug APK ==="
./gradlew :app:testDebugUnitTest :app:assembleDebug
cp app/build/outputs/apk/debug/app-debug.apk ./mizo-q-tiktok-toolkit-v6.apk
echo "Built APK successfully: ./mizo-q-tiktok-toolkit-v6.apk"
