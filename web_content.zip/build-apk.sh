#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
./gradlew :app:assembleDebug
printf '\nAPK created at: app/build/outputs/apk/debug/app-debug.apk\n'
