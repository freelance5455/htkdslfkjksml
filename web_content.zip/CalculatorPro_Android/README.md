# Calculator Pro — Pure Black AMOLED

Offline Android calculator with a pure-black AMOLED interface, scientific functions, memory keys, persistent calculation history, and configurable precision.

## Build an APK

**Recommended for low-spec PCs:** use the included GitHub Actions workflow. Upload the contents of this folder to a GitHub repository. The `Build Calculator Pro APK` workflow runs on every push. Open the successful run under **Actions** and download the `CalculatorPro-AMOLED-APK` artifact.

**Local Windows build:** install JDK 17 and Android SDK Platform 36 / Build Tools 36.0.0, then run `Build-APK.bat`.

**Android Studio:** open this folder, allow Gradle sync, then select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

Output: `app/build/outputs/apk/debug/app-debug.apk`.

The app is fully offline and does not request internet access. The debug APK is for direct installation/testing; Play Store distribution requires a separately signed release build.

See [README_TK.md](README_TK.md) for Turkmen instructions.
