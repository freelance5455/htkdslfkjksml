@echo off
setlocal
cd /d "%~dp0"

set "GRADLE_VERSION=8.13"
set "TOOLS_DIR=%USERPROFILE%\.calculatorpro-tools"
set "GRADLE_HOME_LOCAL=%TOOLS_DIR%\gradle-%GRADLE_VERSION%"
set "GRADLE_EXE=%GRADLE_HOME_LOCAL%\bin\gradle.bat"

if not defined ANDROID_HOME (
  if exist "%LOCALAPPDATA%\Android\Sdk" set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
)
if not defined ANDROID_SDK_ROOT if defined ANDROID_HOME set "ANDROID_SDK_ROOT=%ANDROID_HOME%"

if not defined ANDROID_HOME (
  echo ERROR: Android SDK not found.
  echo Install Android Studio and Android SDK Platform 36 first,
  echo or set ANDROID_HOME to your Android SDK folder.
  pause
  exit /b 1
)

where java >nul 2>nul
if errorlevel 1 (
  echo ERROR: Java not found. Install JDK 17 or Android Studio.
  pause
  exit /b 1
)

if not exist "%GRADLE_EXE%" (
  echo Downloading Gradle %GRADLE_VERSION%...
  if not exist "%TOOLS_DIR%" mkdir "%TOOLS_DIR%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $zip=Join-Path $env:TEMP 'calculatorpro-gradle-8.13-bin.zip'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-8.13-bin.zip' -OutFile $zip; Expand-Archive -Path $zip -DestinationPath '%TOOLS_DIR%' -Force; Remove-Item $zip -Force"
  if errorlevel 1 (
    echo ERROR: Could not download Gradle. Check your internet connection.
    pause
    exit /b 1
  )
)

echo Building Calculator Pro APK...
call "%GRADLE_EXE%" --no-daemon --max-workers=1 :app:assembleDebug
if errorlevel 1 (
  echo.
  echo BUILD FAILED. Check that Android SDK Platform 36 and Build Tools 36.0.0 are installed.
  pause
  exit /b 1
)

echo.
echo APK created at:
echo %CD%\app\build\outputs\apk\debug\app-debug.apk
pause
