# Calculator Pro — Pure Black AMOLED

Calculator Pro-nyň Android üçin taýýar çeşme taslamasy. Programma internetsiz işleýär we WebView arkaly ýerli HTML/CSS/JavaScript interfeýsini görkezýär. Hiç hili internet rugsady soralmaýar.

## Esasy mümkinçilikler

- Pure Black AMOLED dizaýn, aýna görnüşli paneller we düwme animasiýalary
- M+, M−, MR, MC ýat funksiýalary
- Hasaplama taryhy (100-e çenli ýazgy), taryhdan netijäni gaýtadan açmak
- DEG/RAD burç režimleri
- sin, cos, tan, asin, acos, atan
- √x, x², xʸ, log, ln, 10ˣ, eˣ, 1/x, abs, n!, π, e
- Takyklyk sazlamasy: 10 / 12 / 14 san
- Ýerli ýatda saklamak: taryh, ýatdaky san we sazlamalar
- Wibrasiýa ýok
- Android 6.0 (API 23) we has täze wersiýalar üçin

## Hakyky APK almak — GitHub Actions arkaly (maslahat berilýär)

Bu usul APK-ny bulutda ýasaýar; kompýutere Android Studio gurnamak hökman däl.

1. ZIP faýlyny çykaryň.
2. GitHub-da täze boş repository dörediň.
3. ZIP-den çykan `CalculatorPro_Android` bukjasynyň içindäki ähli faýllary repository-niň esasy ýerine ýükläň. `.github` bukjasynyň hem ýüklendigine göz ýetiriň.
4. Faýllary `Commit changes` bilen ýatda saklaň. `Build Calculator Pro APK` workflow awtomatik başlar.
5. Repository-de **Actions** bölümine giriň, iň soňky `Build Calculator Pro APK` işini açyň.
6. Iş üstünlikli tamamlananda aşakdaky **Artifacts** bölüminden `CalculatorPro-AMOLED-APK` faýlyny ýükläň.
7. Ýüklän artifact ZIP-iň içindäki `app-debug.apk` faýlyny Redmi telefonyňyza geçirip guruň.

## Windows-da ýerli kompýuterde APK gurmak

Gerek zatlar: JDK 17, Android SDK Platform 36 we Build Tools 36.0.0. Soňra `Build-APK.bat` faýlyna iki gezek basyň. Skript Gradle 8.13-i göçürip alyp, APK-ny gurmaga synanyşar.

APK şu ýerde döredilýär:

`app\\build\\outputs\\apk\\debug\\app-debug.apk`

## Android Studio arkaly

1. Android Studio-da **Open** saýlaň we şu bukjany açyň.
2. SDK Manager arkaly **Android SDK Platform 36** we **Android SDK Build-Tools 36.0.0** gurnaň.
3. Gradle Sync tamamlanandan soň **Build → Build Bundle(s) / APK(s) → Build APK(s)** saýlaň.
4. APK `app/build/outputs/apk/debug/` bukjasynda bolar.

## Howpsuzlyk we gurnama barada

- Programma hasaplamalar üçin internet ulanmaýar we `INTERNET` rugsady ýok.
- GitHub Actions öndürýän APK — debug görnüşinde gol çekilen, telefona göni gurnamak üçin niýetlenen synag APK-sydyr. Google Play-a çykarmak üçin aýratyn release signing gerek.
- APK gurnalanda Android näbelli çeşmeden gurnama rugsadyny sorap biler. Diňe özüňiziň döreden ýa-da ynanýan APK faýlyňyzy gurnaň.
