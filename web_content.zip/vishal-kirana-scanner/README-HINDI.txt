VISHAL KIRANA - BARCODE BILL SCANNER

FILES:
- index.html : Main app
- start-termux.sh : Starts a local web server on Android (Termux)
- start-windows.bat : Starts a local web server on Windows (Python required)

ANDROID (RECOMMENDED):
1. Extract this ZIP in your phone.
2. Install/open Termux.
3. In Termux, go to the extracted folder. Example:
   cd /sdcard/Download/vishal-kirana-scanner
4. Run:
   python -m http.server 8000 --bind 0.0.0.0
5. Open Chrome and visit:
   http://127.0.0.1:8000
6. Tap "Camera chalu karo" and allow camera permission.

If Termux says python command not found, run:
   pkg update && pkg install python

WINDOWS:
1. Extract ZIP.
2. Double-click start-windows.bat.
3. Open the address shown (usually http://127.0.0.1:8000).

IMPORTANT:
- Camera access normally needs HTTPS or localhost. Opening index.html directly
  from File Manager may block camera scanning; use the local server steps above.
- Barcode reading uses the browser BarcodeDetector when available, otherwise it
  loads ZXing from a CDN, so internet may be needed for that fallback.
- The three sample products shown initially are examples, not a real product database.
- Product names and prices must be added by you after scanning an unknown barcode.
- Saved catalog and bill data are stored in this browser's local storage. Clearing
  browser/site data may erase them. This app does not fetch live product prices.
