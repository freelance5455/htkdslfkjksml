# Pininfarina - App de gestión

App móvil para el negocio **Pininfarina Estético Detallado Automotriz**.

## Cómo instalar en el celular

1. Copia toda la carpeta al teléfono
2. Abre `index.html` con Chrome (Android) o Safari (iPhone)
3. Instala: menú → "Agregar a pantalla de inicio" / "Instalar aplicación"

## Acceso

- Usuario: **admin**
- Contraseña: **1234**

## Pantallas

- Login
- Menú principal (Registrar, Buscar, Clientes, Ventas, Reportes, Usuarios)
- Registro de cliente + vehículo + foto + servicio + pago
- Lista de clientes del día
- Ventas del día con totales
- Detalle de cada servicio (editar, marcar pagado, eliminar)
- Reportes PDF
- Gestión de usuarios

Los datos se guardan en el teléfono. Exporta respaldo desde Reportes.
