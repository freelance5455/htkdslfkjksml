FAST AND FURIOUS ARCADE RACER - Android project
(WebView app. The game lives in app/src/main/assets/index.html)

OPTION A - Android Studio (easiest)
1. Install Android Studio, then File > Open and pick this folder.
2. Let Gradle sync (it downloads what it needs).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK: app/build/outputs/apk/debug/app-debug.apk
5. Copy it to your phone and open it (allow "install unknown apps" when asked).

OPTION B - No install, build in the cloud (GitHub)
1. Create a free GitHub repo and upload everything in this folder.
2. Open the Actions tab > "Build APK" > wait for green.
3. Download "arcade-racer-apk" from the run page and unzip to get app-debug.apk.

To change the game later, edit app/src/main/assets/index.html and rebuild.
