JAMSHEED APK PROJECT

यह आपके दिए हुए JAMSHEED HTML को Android WebView ऐप में पैक करने के लिए तैयार प्रोजेक्ट है।

आसान तरीका:
1. ZIP को Android Studio में खोलें।
2. Gradle sync पूरा होने दें।
3. Build > Build APK(s) चुनें।
4. APK बनकर app/build/outputs/apk/debug/app-debug.apk में मिलेगी।

अगर ऑनलाइन APK builder इस्तेमाल कर रहे हैं, तो app/src/main/assets/index.html आपकी मुख्य web app file है।

नोट: यह project आपकी HTML/JavaScript app को APK shell में चलाता है। Login/server/database जैसी चीजें तभी online काम करेंगी जब उनका backend/API मौजूद हो।
