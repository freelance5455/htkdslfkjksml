# Sastagram (phone mein install hone wala app)

Ye ek PWA hai. Hosting pe daalne ke baad phone mein asli app ki tarah install hota hai,
home screen pe icon aata hai aur full screen khulta hai.

## 1. Online daalo (free, 2 minute)
Install ke liye app ka HTTPS link hona zaroori hai. Sabse aasaan raasta:

1. Is folder (`sastagram-pwa`) ko zip se nikaalo.
2. https://app.netlify.com/drop kholo (free account bana lo).
3. Poora folder page pe drag karke chhod do.
4. Netlify ek link dega, jaise `https://kuch-naam.netlify.app`.

GitHub Pages, Vercel ya Cloudflare Pages bhi chalte hain.

## 2. Phone mein install karo
- **Android (Chrome):** link kholo, upar teen dot menu mein "Install app" ya "Add to Home screen" dabao.
- **iPhone (Safari):** link kholo, Share button dabao, phir "Add to Home Screen".

## Dhyan dene wali baatein
- Likes, comments aur aapke posts sirf us phone mein save hote hain.
- Pehli baar internet chahiye, uske baad app offline bhi khulta hai.
- Naya version daalo to `sw.js` mein `VERSION` ka naam badal do (jaise `sastagram-v2`).
