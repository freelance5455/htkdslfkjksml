EVSL Auto Maintenance Management - Android Studio Project

यह Android APK बनाने के लिए source project है; यह स्वयं APK नहीं है।

APK बनाने के चरण:
1. Computer में Android Studio install करें।
2. इस ZIP को extract करें।
3. Android Studio में EVSL_Android_Project folder खोलें।
4. Gradle sync पूरा होने दें (Android SDK Platform 35 और compatible Gradle/AGP डाउनलोड हो सकते हैं)।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
6. APK app/build/outputs/apk/debug/app-debug.apk में बनेगी।

ध्यान दें: ऐप का maintenance data इस फोन के app/browser storage में रहता है। फोन बदलने या app data clear करने से पहले Backup & Restore से JSON backup डाउनलोड करें।
