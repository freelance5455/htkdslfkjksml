if (sourceVideo.readyState >= HTMLMediaElement.HAVE_METADATA && videoDuration > 0 && isFinite(videoDuration)) {
    // Manually trigger the logic that would happen in onloadedmetadata if it already fired
    sourceVideo.onloadedmetadata();
}