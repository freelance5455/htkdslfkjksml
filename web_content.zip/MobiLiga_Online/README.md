# MobiLiga Moçambique — implementação online inicial

Esta pasta contém uma versão web preparada para ligação a Supabase, mantendo o HTML original em `index-original.html` e a versão corrigida para uso local em `index-local.html`. **Ainda não está publicada nem ligada a um projecto Supabase real.**

## O que já está preparado

- Pesquisa pública de serviços por texto, cidade e categoria.
- Login por telefone com código SMS (OTP) via Supabase Auth.
- Publicação de serviços ligada à base de dados.
- Envio e consulta privada de pedidos entre cliente e profissional.
- Links de WhatsApp com validação básica de números móveis moçambicanos.
- Esquema SQL com Row Level Security (RLS), permissões de proprietário, protecção de destaques, protecção contra pedidos inseridos como já concluídos e registo contabilístico de comissões ao concluir pedidos.
- Tabelas para pedidos de anúncios destacados; a confirmação do pagamento é manual nesta fase.

## Dependências

1. Navegador moderno com JavaScript ES modules.
2. Projecto Supabase (plano Free pode servir para protótipo; os projectos gratuitos podem pausar por inactividade e têm limites). Base de dados PostgreSQL e Supabase Auth.
3. Fornecedor de SMS configurado no Supabase para login por telefone. O envio de SMS não deve ser assumido como gratuito; configure e teste custos/entrega em Moçambique antes de abrir ao público.
4. Alojamento estático HTTPS, por exemplo Cloudflare Pages (plano gratuito para ficheiros estáticos) ou outro equivalente.
5. Git opcional, para fazer deploy através de repositório.

## Configuração

1. Crie um projecto Supabase e guarde a URL e a chave pública (`anon`/publishable) do projecto.
2. Abra `config.js` (ou use `config.example.js` como modelo) e preencha `SUPABASE_URL` e `SUPABASE_ANON_KEY`. Apenas a chave pública `anon`/publishable pode estar no browser; nunca adicione a chave `service_role`.
3. No painel Supabase, active Phone Auth e configure um fornecedor SMS; limite as regiões de SMS ao que realmente precisa. Configure o domínio HTTPS do site em Auth > URL Configuration / Redirect URLs.
4. Execute `supabase/schema.sql` no SQL Editor do projecto. Revise-o primeiro num projecto de teste.
5. Sirva a pasta por HTTP/HTTPS. Não abra `index.html` directamente com `file://`, porque os módulos ES e Auth precisam de uma origem servida. Para testar localmente pode usar `npx serve .` (requer Node.js/npm) e abrir o endereço local mostrado. `localhost` pode não funcionar para OTP de produção; use o domínio autorizado para teste real de SMS.
6. Publique a pasta no Cloudflare Pages ou serviço semelhante. O ficheiro `_headers` define cabeçalhos básicos de segurança. A chave publishable/anon é pública por desenho; a segurança depende das políticas RLS.
7. Antes do lançamento, faça testes com dois números e dois utilizadores separados.

## Administrador, anúncios destacados e comissões

- O destaque não pode ser activado pelo proprietário através do browser: `sponsored_until` está protegido por trigger. A administração pode confirmar manualmente uma ordem de promoção e actualizar `services.sponsored_until` através de um procedimento administrativo seguro.
- O papel de administrador deve ser colocado em `app_metadata.role = "admin"` através de um processo de confiança no painel/servidor; nunca aceite esse papel de dados editáveis pelo utilizador. Não existe painel de administração nesta entrega.
- A taxa inicial de comissão está em `app_settings.commission_rate_percent` (10%). Alterar a taxa via SQL Editor conforme acordo comercial. Quando um pedido passa para `completed` e contém `agreed_amount_mzn`, o trigger regista a comissão. Isso é apenas contabilidade: não cobra, não recebe nem transfere dinheiro.
- Não foi integrado gateway de pagamento, AdSense/SDK de anúncios, M-Pesa, carteira, SMS de notificações nem verificação de identidade. Os destaques são o primeiro formato comercial preparado; os anúncios publicitários e pagamentos automáticos exigem integrações e aprovação de fornecedores.

## Testes mínimos

- [ ] Sem `config.js`, a aplicação explica a configuração pendente sem falhar.
- [ ] URL/chave incorrectas: a autenticação e a base de dados devem mostrar erro, sem apresentar dados falsos.
- [ ] OTP: enviar e confirmar código num domínio autorizado, com SMS provider configurado.
- [ ] Utilizador A publica serviço; aparece em sessão anónima e em utilizador B.
- [ ] Utilizador B envia pedido; A e B conseguem ver o pedido, utilizador C não consegue.
- [ ] A não consegue alterar os serviços de B nem activar destaques gratuitos.
- [ ] Cliente não consegue marcar o próprio pedido como concluído nem alterar as partes.
- [ ] Marcar pedido como concluído pelo profissional com valor acordado gera uma comissão única.
- [ ] Testar números inválidos, mensagens longas, rede desligada e sessão expirada.

## Limitações conhecidas da versão inicial

- Não tem painel de administração, pagamento automático, upload de fotografias, avaliação/reputação, moderação avançada, denúncias ou notificações push.
- Os pedidos podem ser lidos pelo cliente e pelo profissional designado; os telefones de serviço são públicos por decisão de produto e devem ser publicados apenas com consentimento.
- O botão de pedido usa o estado `active` e os serviços carregados na listagem; para catálogo acima de 200 serviços, implementar paginação.
- RLS e SQL precisam de ser testados no seu projecto concreto antes de aceitar dados reais. Não introduza service-role key no browser.

## Criar o primeiro administrador

1. Crie uma conta de teste e confirme o telefone.
2. No SQL Editor do Supabase, obtenha o `id` do utilizador em `auth.users` e atribua o papel de administrador apenas à conta de confiança:

```sql
update auth.users
set raw_app_meta_data = coalesce(raw_app_meta_data, '{}'::jsonb) || '{"role":"admin"}'::jsonb
where id = 'UUID-DO-ADMIN';
```

Substitua `UUID-DO-ADMIN` pelo UUID real. Termine e inicie a sessão novamente para renovar o JWT. Nunca atribua este papel através de `user_metadata` ou de um formulário público. Para operar comercialmente, crie depois um procedimento administrativo auditável para confirmar pagamentos, activar destaques e reconciliar comissões.


## Lista final antes de abrir ao público

- [ ] Criar o projecto Supabase na conta do proprietário da MobiLiga; não partilhar palavras-passe no chat.
- [ ] Preencher `config.js` localmente com URL e chave pública do projecto. A chave `service_role` nunca pode entrar neste pacote nem no browser.
- [ ] Rever e executar `supabase/schema.sql` num projecto de teste. O SQL usa triggers para forçar pedidos novos a começar em `new`, limpar valores de comissão enviados pelo cliente e manter pedidos de destaque como `pending` até confirmação administrativa.
- [ ] Configurar Phone Auth, fornecedor SMS e domínio autorizado; testar entrega em Moçambique e consultar preços do fornecedor.
- [ ] Publicar a pasta `MobiLiga_Online` num alojamento HTTPS. Não é possível publicar pela aplicação sem acesso autorizado à conta de alojamento.
- [ ] Executar `node tests/check-config.mjs`, `node --check app.js` e testes manuais com pelo menos três contas distintas.
- [ ] Testar WhatsApp num Android com WhatsApp instalado e noutro dispositivo sem a aplicação. O link `wa.me` abre o WhatsApp quando disponível; não autentica a conta nem garante que a mensagem foi enviada.
- [ ] Antes de cobrar, definir preços, política de cancelamento, privacidade, moderação, suporte, impostos e reconciliação manual de pagamentos.

## Testes locais

Requer Node.js 18 ou superior para os comandos de verificação. A aplicação depende do SDK Supabase carregado do CDN jsDelivr e de acesso à Internet. Para servir a página localmente, a partir desta pasta execute `npx serve .`; abrir o HTML por `file://` não é um teste válido para módulos e autenticação.
