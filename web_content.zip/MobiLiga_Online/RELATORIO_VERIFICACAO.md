# MobiLiga Moçambique — relatório de verificação

Data: 17/10/2026

## Resultado desta etapa

- Pacote de origem preservado; esta cópia de trabalho foi criada para auditoria.
- `node tests/check-config.mjs`: PASSOU. Confirma presença da página, app, exemplo de configuração e marcadores de funções/regras principais.
- `node --check app.js`: PASSOU. Não foram encontrados erros de sintaxe JavaScript.
- `config.js`: NÃO CONFIGURADO. Contém `https://SEU-PROJECTO.supabase.co` e uma chave de exemplo; não liga a um backend real.
- O `schema.sql` standalone mais recente encontrado na biblioteca foi copiado para esta cópia de trabalho; o pacote original não foi modificado.
- Testes reais de Supabase, SMS/OTP, segurança com várias contas, publicação HTTPS e APK: NÃO EXECUTADOS, porque não há ligação de projeto/credenciais nem ambiente de publicação confirmado.

## Funcionalidades previstas no pacote

- Pesquisa pública de serviços por texto, cidade e categoria.
- Login por telefone com OTP via Supabase Auth.
- Publicação de serviços, pedidos privados e gestão de estados.
- Contacto via WhatsApp para números moçambicanos.
- Pedidos de destaque com confirmação administrativa manual.
- Registo contabilístico de comissão após conclusão elegível; não processa pagamentos.
- Políticas de acesso RLS no SQL.

## Bloqueadores para lançamento público

1. Criar/confirmar o projeto Supabase pertencente ao proprietário e preencher `config.js` apenas com URL e chave pública do projeto.
2. Rever o SQL no projeto de teste antes de executar; confirmar permissões, RLS e funções com utilizadores de teste.
3. Configurar Phone Auth, fornecedor SMS, custos e domínio autorizado.
4. Publicar em alojamento HTTPS e testar em dispositivos reais.
5. Fazer teste ponta a ponta com pelo menos três contas: cliente, profissional e utilizador não relacionado.
6. Definir política de privacidade, consentimento para telefone público, termos, moderação, denúncias, suporte e regras comerciais.
7. A APK Android não está confirmada como compilada; exige processo de empacotamento e teste separado.

## Segurança

- Nunca colocar `service_role` key, passwords ou tokens privados no frontend.
- Não atribuir papel de administrador através de campos editáveis pelo utilizador.
- Não executar migrações na base de dados de produção sem backup e teste prévio.

Este relatório descreve apenas verificações realmente executadas nesta cópia local. Não é certificação de segurança nem prova de funcionamento em produção.
