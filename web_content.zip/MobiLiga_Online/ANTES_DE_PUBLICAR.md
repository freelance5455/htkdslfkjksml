# Lista de lançamento — MobiLiga Moçambique

## A. Configuração
- [ ] Confirmar a conta/projeto Supabase correto.
- [ ] Configurar `SUPABASE_URL` e chave `anon`/publishable real em `config.js`.
- [ ] Confirmar que nenhuma chave `service_role` ou segredo privado está no pacote.
- [ ] Rever `supabase/schema.sql` e executar primeiro em ambiente de teste.
- [ ] Configurar autenticação por telefone, fornecedor SMS e URLs de redirecionamento.

## B. Testes ponta a ponta
- [ ] Login OTP entregue e confirmado em número moçambicano autorizado.
- [ ] Conta A publica serviço; visitante anónimo consegue ver serviço ativo.
- [ ] Conta B cria pedido; A e B veem o pedido e conta C não consegue vê-lo.
- [ ] Conta A não altera nem apaga serviço pertencente a B.
- [ ] Utilizador não consegue ativar gratuitamente um destaque.
- [ ] Cliente não consegue marcar pedido como concluído nem mudar as partes.
- [ ] Conclusão válida gera no máximo uma comissão contabilística.
- [ ] WhatsApp abre com número válido; números inválidos são recusados.
- [ ] Testar sessão expirada, rede desligada e mensagens de erro.

## C. Publicação e operação
- [ ] Publicar somente em HTTPS.
- [ ] Configurar domínio e redirecionamentos autorizados.
- [ ] Definir privacidade, consentimento para exposição do telefone, termos e moderação.
- [ ] Definir política de cancelamento, preços, apoio ao utilizador e tratamento de denúncias.
- [ ] Confirmar backups e processo de recuperação.
- [ ] Testar em Android e computador.
- [ ] APK: compilar, instalar e testar separadamente antes de distribuir.

Não publicar nem cobrar utilizadores até concluir os testes relevantes.
