// Copie este ficheiro para config.js e preencha com os dados PUBLICOS do seu projecto Supabase.
// Nunca coloque a service_role key, passwords, tokens privados ou chaves secretas no browser.
export const SUPABASE_URL = 'https://SEU-PROJECTO.supabase.co';
export const SUPABASE_ANON_KEY = 'SUA_CHAVE_PUBLISHABLE_O_ANON_PUBLICA';
