-- MobiLiga Moçambique — schema inicial Supabase/PostgreSQL
-- Execute no SQL Editor do projecto. Faça primeiro um projecto de teste.
begin;
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  phone text unique,
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, phone)
  values (new.id, new.phone)
  on conflict (id) do update set phone = excluded.phone;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created_mobiliga on auth.users;
create trigger on_auth_user_created_mobiliga after insert on auth.users
for each row execute procedure public.handle_new_user();

create table if not exists public.services (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  person text not null check (char_length(trim(person)) between 2 and 70),
  category text not null check (char_length(category) between 2 and 60),
  city text not null check (char_length(city) between 2 and 60),
  neighborhood text check (neighborhood is null or char_length(neighborhood) <= 70),
  description text not null check (char_length(trim(description)) between 5 and 600),
  price_mzn numeric(12,2) check (price_mzn is null or price_mzn >= 0),
  phone_public text not null check (phone_public ~ '^\+258(82|83|84|85|86|87)[0-9]{7}$'),
  status text not null default 'active' check (status in ('active','paused','removed')),
  sponsored_until timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists services_active_city_category_idx on public.services(status, city, category, created_at desc);
create index if not exists services_owner_idx on public.services(owner_id, created_at desc);

create table if not exists public.service_requests (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references auth.users(id) on delete cascade,
  provider_id uuid not null references auth.users(id) on delete cascade,
  service_id uuid not null references public.services(id) on delete restrict,
  description text not null check (char_length(trim(description)) between 5 and 800),
  city text not null check (char_length(city) between 2 and 60),
  area text check (area is null or char_length(area) <= 70),
  budget_mzn numeric(12,2) check (budget_mzn is null or budget_mzn >= 0),
  agreed_amount_mzn numeric(12,2) check (agreed_amount_mzn is null or agreed_amount_mzn >= 0),
  status text not null default 'new' check (status in ('new','accepted','in_progress','completed','cancelled')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint customer_not_provider check (customer_id <> provider_id)
);
create index if not exists service_requests_customer_idx on public.service_requests(customer_id, created_at desc);
create index if not exists service_requests_provider_idx on public.service_requests(provider_id, created_at desc);

-- Impede que um cliente crie pedidos já concluídos ou falsifique o valor acordado.
create or replace function public.guard_service_request_insert()
returns trigger language plpgsql set search_path = '' as $$
begin
  if auth.uid() is null or new.customer_id is distinct from auth.uid() then
    raise exception 'O cliente do pedido tem de ser a conta autenticada';
  end if;
  if new.customer_id = new.provider_id then
    raise exception 'Não pode pedir um serviço à própria conta';
  end if;
  new.status := 'new';
  new.agreed_amount_mzn := null;
  return new;
end; $$;
drop trigger if exists guard_service_request_insert on public.service_requests;
create trigger guard_service_request_insert before insert on public.service_requests
for each row execute procedure public.guard_service_request_insert();

-- Pedido de destaque: não é pagamento automático. A administração confirma manualmente.
create table if not exists public.promotion_orders (
  id uuid primary key default gen_random_uuid(),
  service_id uuid not null references public.services(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  package_code text not null check (package_code in ('7_days','30_days')),
  amount_mzn numeric(12,2) not null check (amount_mzn > 0),
  payment_reference text,
  status text not null default 'pending' check (status in ('pending','confirmed','rejected','expired')),
  starts_at timestamptz,
  ends_at timestamptz,
  created_at timestamptz not null default now(),
  checked_by uuid references auth.users(id),
  checked_at timestamptz
);
create index if not exists promotion_orders_owner_idx on public.promotion_orders(owner_id, created_at desc);

create or replace function public.is_mobiliga_admin()
returns boolean language sql stable as $$
  select coalesce(auth.jwt() -> 'app_metadata' ->> 'role', '') = 'admin';
$$;

-- O utilizador pode solicitar um destaque, mas não pode declarar pagamento confirmado.
create or replace function public.guard_promotion_order_insert()
returns trigger language plpgsql set search_path = '' as $$
begin
  if not public.is_mobiliga_admin() then
    if auth.uid() is null or new.owner_id is distinct from auth.uid() then
      raise exception 'A ordem deve pertencer à conta autenticada';
    end if;
    new.status := 'pending';
    new.payment_reference := null;
    new.starts_at := null;
    new.ends_at := null;
    new.checked_by := null;
    new.checked_at := null;
  end if;
  return new;
end; $$;
drop trigger if exists guard_promotion_order_insert on public.promotion_orders;
create trigger guard_promotion_order_insert before insert on public.promotion_orders
for each row execute procedure public.guard_promotion_order_insert();

-- Registo contabilístico de comissão; não processa dinheiro nem prova por si só que houve pagamento.
create table if not exists public.commissions (
  id uuid primary key default gen_random_uuid(),
  service_request_id uuid not null unique references public.service_requests(id) on delete restrict,
  provider_id uuid not null references auth.users(id) on delete restrict,
  agreed_amount_mzn numeric(12,2) not null check (agreed_amount_mzn >= 0),
  rate_percent numeric(5,2) not null check (rate_percent between 0 and 100),
  commission_amount_mzn numeric(12,2) not null check (commission_amount_mzn >= 0),
  status text not null default 'pending' check (status in ('pending','paid','waived','disputed')),
  created_at timestamptz not null default now(),
  paid_at timestamptz
);

create table if not exists public.app_settings (
  setting_key text primary key,
  setting_value jsonb not null,
  updated_at timestamptz not null default now()
);
insert into public.app_settings(setting_key, setting_value) values ('commission_rate_percent','10'::jsonb)
on conflict (setting_key) do nothing;

create or replace function public.set_updated_at()
returns trigger language plpgsql as $$ begin new.updated_at = now(); return new; end; $$;
drop trigger if exists services_updated_at on public.services;
create trigger services_updated_at before update on public.services for each row execute procedure public.set_updated_at();
drop trigger if exists service_requests_updated_at on public.service_requests;
create trigger service_requests_updated_at before update on public.service_requests for each row execute procedure public.set_updated_at();

-- Protege o destaque: o proprietário não pode oferecer destaque grátis alterando a coluna.
create or replace function public.protect_sponsored_until()
returns trigger language plpgsql as $$
begin
  if not public.is_mobiliga_admin() then
    if TG_OP = 'INSERT' then
      if new.sponsored_until is not null then raise exception 'Apenas a administração pode activar ou alterar um destaque'; end if;
    elsif new.sponsored_until is distinct from old.sponsored_until then
      raise exception 'Apenas a administração pode activar ou alterar um destaque';
    end if;
  end if;
  return new;
end; $$;
drop trigger if exists protect_service_sponsored_until on public.services;
create trigger protect_service_sponsored_until before insert or update on public.services for each row execute procedure public.protect_sponsored_until();

-- Ao marcar um pedido como concluído, cria um registo de comissão se o valor foi confirmado.
create or replace function public.create_commission_on_completion()
returns trigger language plpgsql security definer set search_path = '' as $$
declare rate numeric(5,2);
begin
  if new.status = 'completed' and old.status is distinct from 'completed' and new.agreed_amount_mzn is not null then
    select (setting_value #>> '{}')::numeric into rate from public.app_settings where setting_key = 'commission_rate_percent';
    rate := coalesce(rate, 10);
    insert into public.commissions(service_request_id, provider_id, agreed_amount_mzn, rate_percent, commission_amount_mzn)
    values (new.id, new.provider_id, new.agreed_amount_mzn, rate, round(new.agreed_amount_mzn * rate / 100, 2))
    on conflict (service_request_id) do nothing;
  end if;
  return new;
end; $$;
drop trigger if exists create_commission_on_completion on public.service_requests;
create trigger create_commission_on_completion after update of status on public.service_requests
for each row execute procedure public.create_commission_on_completion();

-- Impede que o cliente conclua o próprio pedido ou altere a identidade das partes.
create or replace function public.guard_service_request_updates()
returns trigger language plpgsql as $$
begin
  if public.is_mobiliga_admin() then return new; end if;
  if new.customer_id is distinct from old.customer_id or new.provider_id is distinct from old.provider_id or new.service_id is distinct from old.service_id then
    raise exception 'As partes e o serviço do pedido não podem ser alterados';
  end if;
  if new.description is distinct from old.description or new.city is distinct from old.city or new.area is distinct from old.area or new.budget_mzn is distinct from old.budget_mzn then
    raise exception 'Os detalhes do pedido não podem ser alterados após o envio';
  end if;
  if auth.uid() = old.customer_id then
    if new.status is distinct from old.status and not (new.status = 'cancelled' and old.status in ('new','accepted','in_progress')) then raise exception 'O cliente só pode cancelar um pedido ainda aberto'; end if;
    if new.agreed_amount_mzn is distinct from old.agreed_amount_mzn then raise exception 'Só o profissional pode registar o valor acordado'; end if;
  elsif auth.uid() = old.provider_id then
    if new.status is distinct from old.status then
      if not ((old.status = 'new' and new.status in ('accepted','cancelled')) or (old.status = 'accepted' and new.status in ('in_progress','cancelled')) or (old.status = 'in_progress' and new.status in ('completed','cancelled'))) then
        raise exception 'Transição de estado inválida';
      end if;
    end if;
    if old.status = 'completed' and new.agreed_amount_mzn is distinct from old.agreed_amount_mzn then raise exception 'O valor não pode ser alterado depois de concluir o pedido'; end if;
  else
    raise exception 'Sem autorização para alterar este pedido';
  end if;
  return new;
end; $$;
drop trigger if exists guard_service_request_updates on public.service_requests;
create trigger guard_service_request_updates before update on public.service_requests for each row execute procedure public.guard_service_request_updates();

alter table public.profiles enable row level security;
alter table public.services enable row level security;
alter table public.service_requests enable row level security;
alter table public.promotion_orders enable row level security;
alter table public.commissions enable row level security;
alter table public.app_settings enable row level security;

drop policy if exists "profiles read own" on public.profiles;
create policy "profiles read own" on public.profiles for select to authenticated using (id = auth.uid() or public.is_mobiliga_admin());
drop policy if exists "services public active read" on public.services;
create policy "services public active read" on public.services for select to anon, authenticated using (status = 'active' or owner_id = auth.uid() or public.is_mobiliga_admin());
drop policy if exists "services owner insert" on public.services;
create policy "services owner insert" on public.services for insert to authenticated with check (owner_id = auth.uid());
drop policy if exists "services owner update" on public.services;
create policy "services owner update" on public.services for update to authenticated using (owner_id = auth.uid() or public.is_mobiliga_admin()) with check (owner_id = auth.uid() or public.is_mobiliga_admin());
drop policy if exists "services owner delete" on public.services;
create policy "services owner delete" on public.services for delete to authenticated using (owner_id = auth.uid() or public.is_mobiliga_admin());

drop policy if exists "requests parties read" on public.service_requests;
create policy "requests parties read" on public.service_requests for select to authenticated using (customer_id = auth.uid() or provider_id = auth.uid() or public.is_mobiliga_admin());
drop policy if exists "customer create request" on public.service_requests;
create policy "customer create request" on public.service_requests for insert to authenticated with check (customer_id = auth.uid() and provider_id <> auth.uid() and exists (select 1 from public.services s where s.id = service_id and s.owner_id = provider_id and s.status = 'active'));
drop policy if exists "parties update request" on public.service_requests;
create policy "parties update request" on public.service_requests for update to authenticated using (customer_id = auth.uid() or provider_id = auth.uid() or public.is_mobiliga_admin()) with check (customer_id = auth.uid() or provider_id = auth.uid() or public.is_mobiliga_admin());

-- Cada utilizador vê/cria os seus pedidos de destaque; apenas administração confirma pagamentos.
drop policy if exists "promotion owner read" on public.promotion_orders;
create policy "promotion owner read" on public.promotion_orders for select to authenticated using (owner_id = auth.uid() or public.is_mobiliga_admin());
drop policy if exists "promotion owner create" on public.promotion_orders;
create policy "promotion owner create" on public.promotion_orders for insert to authenticated with check (owner_id = auth.uid() and exists(select 1 from public.services s where s.id = service_id and s.owner_id = auth.uid()));
drop policy if exists "promotion admin update" on public.promotion_orders;
create policy "promotion admin update" on public.promotion_orders for update to authenticated using (public.is_mobiliga_admin()) with check (public.is_mobiliga_admin());
drop policy if exists "commissions parties read" on public.commissions;
create policy "commissions parties read" on public.commissions for select to authenticated using (provider_id = auth.uid() or public.is_mobiliga_admin());
drop policy if exists "commissions admin update" on public.commissions;
create policy "commissions admin update" on public.commissions for update to authenticated using (public.is_mobiliga_admin()) with check (public.is_mobiliga_admin());
drop policy if exists "settings admin only" on public.app_settings;
create policy "settings admin only" on public.app_settings for all to authenticated using (public.is_mobiliga_admin()) with check (public.is_mobiliga_admin());

-- Supabase grants: RLS continua a ser aplicada após os grants.
grant usage on schema public to anon, authenticated;
grant select on public.services to anon, authenticated;
grant insert, update, delete on public.services to authenticated;
grant select, insert, update on public.service_requests to authenticated;
grant select on public.profiles to authenticated;
grant select, insert on public.promotion_orders to authenticated;
grant select, update on public.commissions to authenticated;
grant select, insert, update, delete on public.app_settings to authenticated;
commit;
