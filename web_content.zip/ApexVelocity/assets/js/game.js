const UI={show:id=>{document.getElementById("menu").style.display="none";document.getElementById(id).style.display="grid"},back:()=>{document.querySelectorAll(".screen").forEach(x=>x.style.display="none");document.getElementById("menu").style.display="grid"}};
let scene,camera,renderer,car,keys={},running=false,speed=0,heading=0,lap=1,driftScore=0,last=0,progress=0;
const colors=[0x20c8ff,0xff334f,0xffb11b,0x8b5cff];let selected=0;
const $=id=>document.getElementById(id);
function init(){
 scene=new THREE.Scene();scene.background=new THREE.Color(0x07101b);scene.fog=new THREE.FogExp2(0x07101b,.012);
 camera=new THREE.PerspectiveCamera(68,innerWidth/innerHeight,.1,700);
 renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:"high-performance"});renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.setSize(innerWidth,innerHeight);renderer.shadowMap.enabled=true;renderer.toneMapping=THREE.ACESFilmicToneMapping;document.body.prepend(renderer.domElement);
 scene.add(new THREE.HemisphereLight(0x8ec8ff,0x14200f,2.2));let sun=new THREE.DirectionalLight(0xffffff,2.5);sun.position.set(30,55,20);sun.castShadow=true;scene.add(sun);
 let ground=new THREE.Mesh(new THREE.PlaneGeometry(900,900),new THREE.MeshStandardMaterial({color:0x163019,roughness:1}));ground.rotation.x=-Math.PI/2;ground.receiveShadow=true;scene.add(ground);
 makeTrack();car=makeCar(colors[selected]);scene.add(car);
 for(let i=0;i<160;i++){let x=(Math.random()-.5)*300,z=(Math.random()-.5)*300;if(Math.hypot(x,z)<70)continue;let h=3+Math.random()*22;let b=new THREE.Mesh(new THREE.BoxGeometry(3+Math.random()*6,h,3+Math.random()*6),new THREE.MeshStandardMaterial({color:0x0d1720,metalness:.25,roughness:.65}));b.position.set(x,h/2,z);b.castShadow=true;scene.add(b)}
}
const points=[[-95,-35],[-65,-82],[-5,-88],[65,-70],[98,-25],[87,30],[45,70],[-15,80],[-72,55],[-102,5]].map(v=>new THREE.Vector3(v[0],0,v[1]));
let curve;
function makeTrack(){curve=new THREE.CatmullRomCurve3(points,true,"centripetal");let geo=new THREE.TubeGeometry(curve,350,9,10,true),mat=new THREE.MeshStandardMaterial({color:0x20252b,roughness:.8,metalness:.1});let road=new THREE.Mesh(geo,mat);road.scale.y=.025;road.position.y=.08;road.receiveShadow=true;scene.add(road);
 let lineMat=new THREE.MeshBasicMaterial({color:0xf4f0d0});for(let i=0;i<140;i+=2){let a=curve.getPointAt(i/140),b=curve.getPointAt((i+1)/140),mid=a.clone().add(b).multiplyScalar(.5);let q=new THREE.Mesh(new THREE.BoxGeometry(.25,.05,a.distanceTo(b)*.55),lineMat);q.position.copy(mid);q.position.y=.15;q.lookAt(b);scene.add(q)}
}
function makeCar(col){let g=new THREE.Group(),m=new THREE.MeshStandardMaterial({color:col,metalness:.65,roughness:.25});
let body=new THREE.Mesh(new THREE.BoxGeometry(3.3,.75,5.6),m);body.position.y=.72;body.castShadow=true;g.add(body);
let cabin=new THREE.Mesh(new THREE.BoxGeometry(2.5,.8,2.7),new THREE.MeshStandardMaterial({color:0x0b1622,metalness:.8,roughness:.1}));cabin.position.set(0,1.35,-.2);g.add(cabin);
for(let x of[-1.65,1.65])for(let z of[-1.75,1.75]){let w=new THREE.Mesh(new THREE.CylinderGeometry(.55,.55,.45,18),new THREE.MeshStandardMaterial({color:0x080808,roughness:.9}));w.rotation.z=Math.PI/2;w.position.set(x,.5,z);g.add(w)}
let glow=new THREE.PointLight(col,3,14);glow.position.set(0,.8,2.5);g.add(glow);return g}
function nearest(){let best=0,d=1e9;for(let i=0;i<180;i++){let t=i/180,p=curve.getPointAt(t),q=p.distanceTo(car.position);if(q<d){d=q;best=t}}return [best,d]}
const Game={start(){document.getElementById("menu").style.display="none";running=true;speed=0;lap=1;driftScore=0;progress=0;let p=curve.getPointAt(0);car.position.copy(p);car.position.y=.35;let n=curve.getTangentAt(.01);heading=Math.atan2(n.x,n.z);car.rotation.y=heading;last=performance.now();requestAnimationFrame(loop)}};
function loop(t){if(!running)return;requestAnimationFrame(loop);let dt=Math.min(.035,(t-last)/1000);last=t;let gas=keys.gas||keys.w||keys.arrowup,brake=keys.s||keys.arrowdown,steer=(keys.left||keys.a||keys.arrowleft?-1:0)+(keys.right||keys.d||keys.arrowright?1:0),drift=keys.drift||keys.space;
let sens=+document.getElementById("sens").value;speed+=gas?32*dt:0;speed-=brake?50*dt:7*dt;speed=Math.max(0,Math.min(speed,drift?40:34));heading+=steer*(.45+speed*.018)*sens*dt*(drift?1.35:1);
let dir=new THREE.Vector3(Math.sin(heading),0,Math.cos(heading));car.position.addScaledVector(dir,speed*dt);car.rotation.y=heading;car.rotation.z+=(-steer*(drift?.18:.1)-car.rotation.z)*dt*7;
let [np,dist]=nearest();if(dist>12){speed*=.9;car.position.lerp(curve.getPointAt(np),dt*.8)}if(drift&&Math.abs(steer)&&speed>14)driftScore+=Math.round(speed*dt*2);
if(progress>.86&&np<.12){lap++;if(lap>3){running=false;$("result").textContent="Drift score: "+driftScore;$("finish").style.display="grid"}}progress=np;
let target=car.position.clone().add(new THREE.Vector3(-Math.sin(heading)*8,5.2,-Math.cos(heading)*11));camera.position.lerp(target,dt*4);camera.lookAt(car.position.x,car.position.y+1,car.position.z);
$("speed").textContent=Math.round(speed*9);$("lap").textContent=Math.min(lap,3)+"/3";$("drift").textContent=driftScore;renderer.render(scene,camera)}
addEventListener("keydown",e=>{keys[e.key.toLowerCase()]=true});addEventListener("keyup",e=>keys[e.key.toLowerCase()]=false);
document.querySelectorAll("#touch button").forEach(b=>{let k=b.dataset.k;["pointerdown","pointerup","pointerleave","pointercancel"].forEach(ev=>b.addEventListener(ev,e=>{keys[k]=ev==="pointerdown";e.preventDefault()}))});
addEventListener("resize",()=>{if(camera){camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)}});
window.addEventListener("load",()=>{init();let box=$("cars");colors.forEach((c,i)=>{let b=document.createElement("button");b.className="carpick";b.style.background="#"+c.toString(16).padStart(6,"0");b.onclick=()=>{selected=i;scene.remove(car);car=makeCar(c);scene.add(car);UI.back()};box.appendChild(b)});setTimeout(()=>$("boot").remove(),2200)});
