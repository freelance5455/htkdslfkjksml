APEX VELOCITY
Відкрий index.html у браузері або завантаж весь ZIP у HTML-to-APK конвертер.

Структура:
index.html - головний файл
assets/css/style.css - дизайн
assets/js/game.js - 3D гра

Для запуску потрібен інтернет, бо Three.js завантажується з CDN.
Керування: W/стрілка вгору - газ, A/D - поворот, Space - дрифт.
