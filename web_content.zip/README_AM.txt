KOR Training Center – ሁለቱም አፖች + የሰራተኛ Login

ፋይሎች:
- KOR_COR_Supabase.html
- KOR_Android_Supabase.html
- SUPABASE_AUTH_RLS.sql

ማዘጋጀት (አንድ ጊዜ ብቻ):
1) Supabase Dashboard > Authentication > Settings ይግቡ። የአዲስ ሰው ራስ-ምዝገባ (Allow new users to sign up) ያጥፉ።
2) Authentication > Users ውስጥ ለእያንዳንዱ የተፈቀደ ሰራተኛ መለያ ይፍጠሩ። ኢሜይልና ጠንካራ ፓስወርድ ይስጡ።
3) SQL Editor ውስጥ SUPABASE_AUTH_RLS.sql ይክፈቱና ሙሉውን ኮድ Run ያድርጉ።
4) ሁለቱንም HTML ፋይሎች ክፈቱ፤ በተፈጠረው የሰራተኛ ኢሜይልና ፓስወርድ ይግቡ።

ደህንነት:
- የምዝገባ ቁልፍ በአፑ ውስጥ የለም። አድሚን ብቻ በSupabase የሰራተኛ መለያ ይፍጠር።
- RLS ፖሊሲዎቹ በተገቡ ተጠቃሚዎች ላይ ብቻ ንባብ/ማስተካከያ ይፈቅዳሉ። በአንድ Supabase ፕሮጀክት ውስጥ ያሉ ሁሉም ተፈቅደው የገቡ ሰራተኞች የተቋሙን የጋራ ዳታ ያያሉ።
- የተማሪ ዳታ ስለሆነ የanon/public ፖሊሲ አትፍጠሩ፤ service_role key በHTML ውስጥ አታስገቡ።
- ይህ የመግቢያ እና RLS ኮድ ተዘጋጅቷል፤ በእውነተኛ Supabase ላይ የመጨረሻ ሙከራ ግን ከDashboard ቅንብሮች በኋላ ያስፈልጋል።

ማስታወሻ: የአሁኑ ዳታቤዝ ሰንጠረዦች ያልያዙዋቸው የመታወቂያ ፎቶዎች፣ የተጨማሪ የክፍያ ዝርዝሮች ወዘተ ወደ ደመናው አይሄዱም።


የLabour ID / Gender ማስተካከያ:
- KOR_COR አፕ ውስጥ Gender (EF/EM) በእጅ ይመረጣል።
- Labour ID በተለየ መስክ በእጅ ይጻፋል፤ Gender ሲመረጥ አውቶማቲክ አይፈጠርም ወይም አይቀየርም።
- KOR Android አፕ ውስጥ Labour ID በእጅ ይጻፋል፤ EM/EF ቅድመ ቅጥያው ጾታን ይለያል።


የመመዝገቢያ ማስተካከያ:
- Gender በተለየ dropdown በእጅ ይመረጣል።
- Labour ID በተለየ የጽሑፍ መስክ በእጅ ይጻፋል፤ Gender መምረጥ ወይም Labour ID መቀየር ሌላውን አይቀይርም።
- ሁለቱም አፖች ተመሳሳይ የGender ኮድ ይጠቀማሉ: EM = Male, EF = Female.
