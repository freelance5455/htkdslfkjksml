KOR Institute Android Project

ይህ ፕሮጀክት HTML አፕሊኬሽኑን Android WebView ውስጥ ያስኬዳል።

APK ለማውጣት (በGitHub ነፃ የCloud Build መንገድ):
1. ZIP ፋይሉን በWindows 10 PC ላይ Extract All አድርግ።
2. github.com ክፈት፣ በመለያህ ግባ እና New repository ፍጠር። ስሙን KOR-Android-App በል።
3. የተፈታውን የፕሮጀክት ፋይሎች ሁሉ (ከ .github ፎልደር ጋር) ወደ repository አፕሎድ አድርግ። .github የተደበቀ ፎልደር ሊሆን ይችላል፤ እንዳለ አረጋግጥ።
4. አፕሎድ ከጨረስክ Actions ታብ ግባ። Build KOR Android APK workflow ምረጥ እና Run workflow ጫን።
5. ሂደቱ ከተሳካ በኋላ በዚያው Actions ሩጫ ገጽ ታች Artifacts ስር KOR-Institute-debug-APK የሚለውን አውርድ። ZIP ን ክፈት፤ app-debug.apk ውስጡ ይገኛል።
6. APK ወደ Android ስልክህ ላክ፣ ክፈተው እና Install በል። ከተጠየቀ Allow from this source ፍቀድ።

ማስታወሻ:
- ይህ የDebug APK ነው፤ ለመሞከር/ለግል መጠቀም ነው። በዚህ የስራ አካባቢ Android SDK/Gradle ስለሌለ እዚህ APK ተገንብቶ አልተረጋገጠም።
- የካሜራ እና ፋይል ምርጫ ተግባሮች በAndroid ስልክ ላይ መፈተሽ ያስፈልጋል።
- የመተግበሪያው ዳታ በWebView የአካባቢ ማከማቻ ውስጥ ይቀመጣል። አፑን ካጠፋህ ወይም ዳታውን ካጸዳህ መረጃ ሊጠፋ ይችላል፤ ባክአፕ አድርግ።
