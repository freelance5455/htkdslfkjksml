const $ = s => document.querySelector(s);
const fmtSize = b => b > 1e9 ? (b/1e9).toFixed(2)+' GB' : (b/1e6).toFixed(1)+' MB';

$('#themeBtn')?.addEventListener('click', () => {
  const t = document.documentElement.getAttribute('data-bs-theme') === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-bs-theme', t); localStorage.setItem('theme', t);
});

// ---- upload page
if ($('#drop')) {
  let file = null;
  const drop = $('#drop'), input = $('#file');
  const pick = f => {
    if (!f) return;
    if (!/\.(mp4|mov|mkv|avi)$/i.test(f.name)) { alert('Unsupported format. Use MP4, MOV, MKV or AVI.'); return; }
    file = f; $('#picked').classList.remove('d-none');
    $('#fname').textContent = f.name; $('#fsize').textContent = fmtSize(f.size);
    $('#pv').src = URL.createObjectURL(f);
  };
  drop.onclick = () => input.click();
  drop.onkeydown = e => { if (e.key === 'Enter') input.click(); };
  input.onchange = () => pick(input.files[0]);
  ['dragover','dragenter'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('over'); }));
  ['dragleave','drop'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove('over'); }));
  drop.addEventListener('drop', e => pick(e.dataTransfer.files[0]));
  $('#go').onclick = () => {
    if (!file) return;
    const fd = new FormData(); fd.append('video', file); fd.append('language', $('#lang').value);
    const xhr = new XMLHttpRequest(), bar = $('#upBar'), inner = bar.firstElementChild, err = $('#err');
    err.classList.add('d-none'); bar.classList.remove('d-none'); $('#go').disabled = true;
    xhr.upload.onprogress = e => { if (e.lengthComputable) { const p = Math.round(e.loaded/e.total*100); inner.style.width = p+'%'; inner.textContent = p+'%'; } };
    xhr.onload = () => {
      let r = {}; try { r = JSON.parse(xhr.responseText); } catch (_) {}
      if (xhr.status === 200 && r.redirect) location = r.redirect;
      else { err.textContent = r.error || 'Upload failed. Please try again.'; err.classList.remove('d-none'); $('#go').disabled = false; bar.classList.add('d-none'); }
    };
    xhr.onerror = () => { err.textContent = 'Network error during upload. Check your connection.'; err.classList.remove('d-none'); $('#go').disabled = false; };
    xhr.open('POST', '/upload'); xhr.send(fd);
  };
}

// ---- progress polling (processing + export)
const box = $('#box');
if (box) {
  const tick = async () => {
    try {
      const r = await (await fetch(box.dataset.url)).json();
      $('#bar').style.width = r.progress + '%'; $('#bar').textContent = r.progress + '%'; $('#msg').textContent = r.message;
      if (!['queued','processing','exporting'].includes(r.status)) { location = box.dataset.next || location.href; return; }
    } catch (_) {}
    setTimeout(tick, 1500);
  };
  tick();
}

// ---- editor + preview
if (window.SEGS && $('#player')) {
  const segs = window.SEGS, player = $('#player'), sub = $('#sub');
  const style = Object.assign({size: 22, color: '#ffffff', position: 'bottom', bg: 55}, JSON.parse(localStorage.getItem('subStyle') || '{}'));
  const applyStyle = () => {
    localStorage.setItem('subStyle', JSON.stringify(style));
    sub.style.fontSize = (style.size / 288 * player.clientHeight) + 'px';
    sub.style.color = style.color;
    sub.style.top = sub.style.bottom = ''; sub.style.transform = '';
    if (style.position === 'top') sub.style.top = '6%';
    else if (style.position === 'middle') { sub.style.top = '50%'; sub.style.transform = 'translateY(-50%)'; }
    else sub.style.bottom = '8%';
    const s = sub.firstElementChild; if (s) s.style.background = `rgba(0,0,0,${style.bg/100})`;
  };
  const show = () => {
    const t = player.currentTime, i = segs.findIndex(s => t >= s.start && t <= s.end);
    sub.innerHTML = i >= 0 ? '<span></span>' : ''; if (i >= 0) sub.firstElementChild.textContent = segs[i].text;
    applyStyle();
    document.querySelectorAll('.seg').forEach((el, k) => el.classList.toggle('active', k === i));
  };
  player.addEventListener('timeupdate', show); player.addEventListener('seeked', show);
  addEventListener('resize', applyStyle); player.addEventListener('loadedmetadata', applyStyle);

  if ($('#segList')) {
    const list = $('#segList');
    const render = () => {
      list.innerHTML = ''; $('#count').textContent = '(' + segs.length + ')';
      segs.forEach((s, i) => {
        const d = document.createElement('div'); d.className = 'seg';
        d.innerHTML = `<div class="d-flex gap-1 mb-1"><input type="number" step="0.1" min="0" class="form-control form-control-sm" data-k="start"><input type="number" step="0.1" min="0" class="form-control form-control-sm" data-k="end"><button class="btn btn-sm btn-outline-secondary" data-seek title="Play from here"><i class="bi bi-play-fill"></i></button><button class="btn btn-sm btn-outline-danger" data-del title="Delete line"><i class="bi bi-x-lg"></i></button></div><textarea rows="2" class="form-control form-control-sm" data-k="text"></textarea>`;
        d.querySelectorAll('[data-k]').forEach(inp => { inp.value = s[inp.dataset.k]; inp.oninput = () => { s[inp.dataset.k] = inp.dataset.k === 'text' ? inp.value : parseFloat(inp.value); }; });
        d.querySelector('[data-seek]').onclick = () => { player.currentTime = s.start; player.play(); };
        d.querySelector('[data-del]').onclick = () => { segs.splice(i, 1); render(); };
        list.appendChild(d);
      });
    };
    render();
    $('#addSeg').onclick = () => { const t = player.currentTime || 0; segs.push({start: +t.toFixed(1), end: +(t + 2).toFixed(1), text: ''}); segs.sort((a, b) => a.start - b.start); render(); };
    $('#saveSegs').onclick = async e => {
      const msg = $('#saveMsg');
      const r = await fetch(e.target.dataset.url, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({segments: segs})});
      const j = await r.json().catch(() => ({}));
      msg.className = 'small mt-2 ' + (r.ok ? 'text-success' : 'text-danger');
      msg.textContent = r.ok ? 'Saved.' : (j.error || 'Could not save.');
    };
  }

  if ($('#size')) {
    const bind = (id, key, lab) => {
      const el = $('#' + id); el.value = style[key];
      const upd = () => { style[key] = el.type === 'range' ? +el.value : el.value; if (lab) $(lab).textContent = style[key] + (key === 'bg' ? '%' : ''); applyStyle(); };
      el.oninput = el.onchange = upd; upd();
    };
    bind('size', 'size', '#sizeVal'); bind('color', 'color'); bind('position', 'position'); bind('bg', 'bg', '#bgVal');
    sub.innerHTML = '<span></span>'; sub.firstElementChild.textContent = 'தமிழ் வசனங்கள் இப்படி தெரியும்'; applyStyle();
    $('#exportBtn').onclick = async e => {
      e.target.disabled = true;
      const r = await fetch(window.EXPORT_URL, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(style)});
      const j = await r.json().catch(() => ({}));
      if (r.ok) location = j.redirect; else { $('#exErr').textContent = j.error || 'Export failed.'; e.target.disabled = false; }
    };
  }
}
