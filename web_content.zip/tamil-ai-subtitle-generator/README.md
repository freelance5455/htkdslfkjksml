# Tamil AI Subtitle Generator

Upload a video in any language -> Whisper transcribes it -> OpenAI translates to Tamil -> edit, style, preview, and download SRT / VTT / MP4 with burned-in Tamil subtitles.

## Setup
1. Install **FFmpeg** (with libass) and a Tamil font: `sudo apt install ffmpeg fonts-noto-core` (Windows: install ffmpeg, add to PATH, install "Noto Sans Tamil").
2. Create the database: `mysql -u root -p < schema.sql`
3. `python -m venv venv && source venv/bin/activate` (Windows: `venv\Scripts\activate`)
4. `pip install -r requirements.txt`
5. `cp .env.example .env` and fill in `DATABASE_URL`, `OPENAI_API_KEY`, `SECRET_KEY`.
6. `python app.py` then open http://127.0.0.1:5000

## Notes
- WHISPER_MODEL: tiny/base/small/medium/large. Bigger = more accurate but slower (GPU recommended for medium/large).
- Videos spoken in Tamil skip translation.
- Temporary audio files are deleted after processing; deleting a video removes all its files.
- For production use gunicorn + a task queue (Celery/RQ) instead of the built-in background threads.
