CREATE DATABASE IF NOT EXISTS tamil_subtitles CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
-- Tables are created automatically when the app starts.
