import os, re, json, uuid, shutil, subprocess, threading
from pathlib import Path
from datetime import datetime
from dotenv import load_dotenv
from flask import (Flask, render_template, request, redirect, url_for, flash,
                   jsonify, send_file, abort, Response)
from flask_sqlalchemy import SQLAlchemy
from flask_login import (LoginManager, UserMixin, login_user, logout_user,
                         login_required, current_user)
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from sqlalchemy.dialects.mysql import LONGTEXT

load_dotenv()
BASE = Path(__file__).parent
UPLOADS = BASE / "storage" / "uploads"
EXPORTS = BASE / "storage" / "exports"
for p in (UPLOADS, EXPORTS):
    p.mkdir(parents=True, exist_ok=True)
ALLOWED = {"mp4", "mov", "mkv", "avi"}
FONT = os.getenv("TAMIL_FONT", "Noto Sans Tamil")

app = Flask(__name__)
app.config.update(
    SECRET_KEY=os.getenv("SECRET_KEY", "dev-secret-change-me"),
    SQLALCHEMY_DATABASE_URI=os.getenv(
        "DATABASE_URL",
        "mysql+pymysql://root:password@localhost/tamil_subtitles?charset=utf8mb4"),
    MAX_CONTENT_LENGTH=int(os.getenv("MAX_UPLOAD_MB", "2048")) * 1024 * 1024,
)
db = SQLAlchemy(app)
lm = LoginManager(app)
lm.login_view = "login"
lm.login_message = "Please log in to continue."


# ---------------------------------------------------------------- models
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    videos = db.relationship("Video", backref="user", cascade="all, delete-orphan")


class Video(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    title = db.Column(db.String(255))
    stored_name = db.Column(db.String(100))
    language = db.Column(db.String(50))
    status = db.Column(db.String(20), default="queued")  # queued/processing/ready/exporting/exported/failed
    progress = db.Column(db.Integer, default=0)
    message = db.Column(db.String(255), default="Queued")
    error = db.Column(db.Text)
    segments = db.Column(db.Text().with_variant(LONGTEXT(), "mysql"), default="[]")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    @property
    def path(self):
        return UPLOADS / self.stored_name

    @property
    def seg_list(self):
        return json.loads(self.segments or "[]")

    @property
    def export_path(self):
        return EXPORTS / str(self.id) / "output.mp4"


@lm.user_loader
def load_user(uid):
    return db.session.get(User, int(uid))


def own(vid):
    v = db.session.get(Video, vid)
    if not v or v.user_id != current_user.id:
        abort(404)
    return v


# ---------------------------------------------------------------- helpers
def ts(sec, sep=","):
    ms = int(round(max(sec, 0) * 1000))
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return f"{h:02}:{m:02}:{s:02}{sep}{ms:03}"


def to_srt(segs):
    return "\n".join(f"{i}\n{ts(s['start'])} --> {ts(s['end'])}\n{s['text']}\n"
                     for i, s in enumerate(segs, 1))


def to_vtt(segs):
    body = "\n".join(f"{i}\n{ts(s['start'], '.')} --> {ts(s['end'], '.')}\n{s['text']}\n"
                     for i, s in enumerate(segs, 1))
    return "WEBVTT\n\n" + body


def probe_duration(path):
    out = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                          "-of", "default=nw=1:nk=1", str(path)],
                         capture_output=True, text=True)
    try:
        return float(out.stdout.strip())
    except ValueError:
        return 0.0


def upd(v, progress=None, message=None, status=None):
    if progress is not None: v.progress = progress
    if message is not None: v.message = message
    if status is not None: v.status = status
    db.session.commit()


_model, _model_lock, _gpu_lock = None, threading.Lock(), threading.Lock()


def get_whisper():
    global _model
    with _model_lock:
        if _model is None:
            import whisper
            _model = whisper.load_model(os.getenv("WHISPER_MODEL", "small"))
        return _model


def translate_batch(client, texts, src_lang):
    system = ("You are a professional subtitle translator. Translate each line from "
              f"{src_lang} into natural, spoken Tamil (தமிழ்). Keep the meaning, tone and names. "
              "Keep lines short for subtitles. Reply ONLY with JSON: "
              '{"translations": ["...", ...]} with exactly the same number of items, same order.')
    last = None
    for _ in range(3):
        try:
            r = client.chat.completions.create(
                model=os.getenv("TRANSLATE_MODEL", "gpt-4o-mini"),
                response_format={"type": "json_object"}, temperature=0.2,
                messages=[{"role": "system", "content": system},
                          {"role": "user", "content": json.dumps(texts, ensure_ascii=False)}])
            out = json.loads(r.choices[0].message.content)["translations"]
            if len(out) == len(texts):
                return [str(x).strip() for x in out]
            last = "Translation returned a different number of lines."
        except Exception as e:
            last = str(e)
    raise RuntimeError(f"Translation failed: {last}")


def run_pipeline(vid):
    with app.app_context():
        v = db.session.get(Video, vid)
        audio = UPLOADS / f"{v.stored_name}.wav"
        try:
            upd(v, 5, "Extracting audio with FFmpeg…", "processing")
            r = subprocess.run(["ffmpeg", "-y", "-i", str(v.path), "-vn", "-ac", "1",
                                "-ar", "16000", str(audio)], capture_output=True, text=True)
            if r.returncode != 0:
                raise RuntimeError("Could not read audio from this video. Is it a valid file with sound?")
            upd(v, 15, "Loading Whisper speech model…")
            model = get_whisper()
            upd(v, 25, "Detecting language and transcribing speech…")
            lang_opt = (v.language or "auto")
            with _gpu_lock:
                res = model.transcribe(str(audio), fp16=False,
                                       language=None if lang_opt == "auto" else lang_opt)
            code = res.get("language", "en")
            from whisper.tokenizer import LANGUAGES
            lang_name = LANGUAGES.get(code, code).title()
            segs = [{"start": round(s["start"], 3), "end": round(s["end"], 3), "text": s["text"].strip()}
                    for s in res["segments"] if s["text"].strip()]
            if not segs:
                raise RuntimeError("No speech was detected in this video.")
            v.language = lang_name
            upd(v, 55, f"Detected {lang_name}. Translating to Tamil…")
            if code != "ta":
                if not os.getenv("OPENAI_API_KEY"):
                    raise RuntimeError("OPENAI_API_KEY is not set on the server.")
                from openai import OpenAI
                client = OpenAI()
                n = 25
                for i in range(0, len(segs), n):
                    chunk = segs[i:i + n]
                    out = translate_batch(client, [s["text"] for s in chunk], lang_name)
                    for s, t in zip(chunk, out):
                        s["text"] = t
                    upd(v, 55 + int(40 * min(i + n, len(segs)) / len(segs)),
                        f"Translating to Tamil… {min(i + n, len(segs))}/{len(segs)} lines")
            v.segments = json.dumps(segs, ensure_ascii=False)
            upd(v, 100, "Done! Subtitles are ready.", "ready")
        except Exception as e:
            db.session.rollback()
            v = db.session.get(Video, vid)
            v.error = str(e)[:1000]
            upd(v, message="Processing failed", status="failed")
        finally:
            audio.unlink(missing_ok=True)  # delete temporary audio


def clean_style(s):
    s = s or {}
    color = s.get("color", "#ffffff")
    if not re.fullmatch(r"#[0-9a-fA-F]{6}", color): color = "#ffffff"
    pos = s.get("position", "bottom")
    if pos not in ("bottom", "middle", "top"): pos = "bottom"
    return {"size": min(max(int(s.get("size", 22)), 10), 60), "color": color, "position": pos,
            "bg": min(max(int(s.get("bg", 55)), 0), 100)}


def run_export(vid, style):
    with app.app_context():
        v = db.session.get(Video, vid)
        work = EXPORTS / str(v.id)
        try:
            v.error = None
            upd(v, 0, "Rendering subtitles into video…", "exporting")
            work.mkdir(parents=True, exist_ok=True)
            (work / "subs.srt").write_text(to_srt(v.seg_list), encoding="utf-8")
            c = style["color"].lstrip("#")
            bgr = c[4:6] + c[2:4] + c[0:2]
            align = {"bottom": 2, "middle": 5, "top": 8}[style["position"]]
            alpha = f"{round(255 * (1 - style['bg'] / 100)):02X}"
            if style["bg"] > 0:
                box = f"BorderStyle=3,Outline=1,Shadow=0,OutlineColour=&H{alpha}000000,BackColour=&H{alpha}000000"
            else:
                box = "BorderStyle=1,Outline=2,Shadow=0,OutlineColour=&H00000000"
            fs = (f"FontName={FONT},FontSize={style['size']},PrimaryColour=&H00{bgr},"
                  f"Alignment={align},MarginV=24,{box}")
            total = probe_duration(v.path) or 1
            cmd = ["ffmpeg", "-y", "-i", str(v.path.resolve()), "-vf",
                   f"subtitles=subs.srt:force_style='{fs}'", "-c:v", "libx264", "-preset", "veryfast",
                   "-crf", "22", "-c:a", "aac", "-movflags", "+faststart",
                   "-progress", "pipe:1", "-nostats", "output.mp4"]
            with open(work / "ffmpeg.log", "w") as log:
                p = subprocess.Popen(cmd, cwd=work, stdout=subprocess.PIPE, stderr=log, text=True)
                for line in p.stdout:
                    if line.startswith("out_time_us="):
                        try:
                            pr = int(int(line.split("=")[1]) / 1e6 / total * 100)
                            if pr != v.progress: upd(v, min(pr, 99))
                        except ValueError:
                            pass
                p.wait()
            if p.returncode != 0:
                raise RuntimeError("FFmpeg could not render subtitles. Check that FFmpeg has libass and the Tamil font is installed.")
            upd(v, 100, "Export complete", "exported")
        except Exception as e:
            db.session.rollback()
            v = db.session.get(Video, vid)
            v.error = str(e)[:1000]
            upd(v, message="Export failed", status="ready")
        finally:
            (work / "subs.srt").unlink(missing_ok=True)


# ---------------------------------------------------------------- auth
@app.route("/")
def home():
    return render_template("home.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        pw = request.form.get("password", "")
        if not name or not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
            flash("Enter your name and a valid email address.", "danger")
        elif len(pw) < 8:
            flash("Password must be at least 8 characters.", "danger")
        elif User.query.filter_by(email=email).first():
            flash("An account with this email already exists. Try logging in.", "danger")
        else:
            u = User(name=name, email=email, password_hash=generate_password_hash(pw))
            db.session.add(u); db.session.commit()
            login_user(u)
            return redirect(url_for("dashboard"))
    return render_template("auth.html", mode="register")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = User.query.filter_by(email=request.form.get("email", "").strip().lower()).first()
        if u and check_password_hash(u.password_hash, request.form.get("password", "")):
            login_user(u, remember=bool(request.form.get("remember")))
            nxt = request.args.get("next", "")
            return redirect(nxt if nxt.startswith("/") and not nxt.startswith("//") else url_for("dashboard"))
        flash("Incorrect email or password.", "danger")
    return render_template("auth.html", mode="login")


@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("home"))


@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    if request.method == "POST":
        if request.form.get("action") == "password":
            if not check_password_hash(current_user.password_hash, request.form.get("current", "")):
                flash("Current password is incorrect.", "danger")
            elif len(request.form.get("new", "")) < 8:
                flash("New password must be at least 8 characters.", "danger")
            else:
                current_user.password_hash = generate_password_hash(request.form["new"])
                db.session.commit(); flash("Password changed.", "success")
        else:
            name = request.form.get("name", "").strip()
            if name:
                current_user.name = name; db.session.commit(); flash("Profile saved.", "success")
    return render_template("profile.html", count=len(current_user.videos))


# ---------------------------------------------------------------- videos
@app.route("/dashboard")
@login_required
def dashboard():
    vids = Video.query.filter_by(user_id=current_user.id).order_by(Video.created_at.desc()).all()
    return render_template("dashboard.html", vids=vids)


@app.route("/upload", methods=["GET", "POST"])
@login_required
def upload():
    if request.method == "GET":
        return render_template("upload.html", max_mb=app.config["MAX_CONTENT_LENGTH"] // 1048576)
    f = request.files.get("video")
    if not f or not f.filename:
        return jsonify(error="Choose a video file first."), 400
    ext = f.filename.rsplit(".", 1)[-1].lower() if "." in f.filename else ""
    if ext not in ALLOWED:
        return jsonify(error="Unsupported format. Upload MP4, MOV, MKV or AVI."), 400
    stored = f"{uuid.uuid4().hex}.{ext}"
    f.save(UPLOADS / stored)
    v = Video(user_id=current_user.id, title=secure_filename(f.filename) or "video",
              stored_name=stored, language=request.form.get("language", "auto"))
    db.session.add(v); db.session.commit()
    threading.Thread(target=run_pipeline, args=(v.id,), daemon=True).start()
    return jsonify(redirect=url_for("project", vid=v.id, step="processing"))


@app.errorhandler(413)
def too_large(_):
    return jsonify(error=f"File too large. Limit is {app.config['MAX_CONTENT_LENGTH'] // 1048576} MB."), 413


@app.route("/video/<int:vid>/<step>")
@login_required
def project(vid, step):
    v = own(vid)
    if step not in ("processing", "editor", "preview", "download"):
        abort(404)
    if v.status in ("queued", "processing"):
        step = "processing"
    elif step == "processing" and v.status != "failed":
        return redirect(url_for("project", vid=vid, step="editor"))
    return render_template("project.html", v=v, step=step, segs=v.seg_list)


@app.route("/api/video/<int:vid>/status")
@login_required
def status(vid):
    v = own(vid)
    return jsonify(status=v.status, progress=v.progress, message=v.message, error=v.error)


@app.route("/api/video/<int:vid>/segments", methods=["POST"])
@login_required
def save_segments(vid):
    v = own(vid)
    try:
        segs = [{"start": float(s["start"]), "end": float(s["end"]), "text": str(s["text"]).strip()}
                for s in request.get_json()["segments"]]
        if any(s["end"] <= s["start"] for s in segs):
            return jsonify(error="Each subtitle's end time must be after its start time."), 400
    except Exception:
        return jsonify(error="Invalid subtitle data."), 400
    segs.sort(key=lambda s: s["start"])
    v.segments = json.dumps(segs, ensure_ascii=False)
    if v.status == "exported": v.status = "ready"  # old export is outdated
    db.session.commit()
    return jsonify(ok=True)


@app.route("/api/video/<int:vid>/export", methods=["POST"])
@login_required
def export(vid):
    v = own(vid)
    if v.status in ("queued", "processing", "exporting", "failed"):
        return jsonify(error="This video is not ready to export."), 400
    style = clean_style(request.get_json(silent=True))
    threading.Thread(target=run_export, args=(v.id, style), daemon=True).start()
    v.status, v.progress = "exporting", 0
    db.session.commit()
    return jsonify(redirect=url_for("project", vid=vid, step="download"))


@app.route("/files/<int:vid>/<kind>")
@login_required
def files(vid, kind):
    v = own(vid)
    base = os.path.splitext(v.title or "subtitles")[0]
    if kind == "video":
        return send_file(v.path, conditional=True)
    if kind in ("srt", "vtt"):
        text = to_srt(v.seg_list) if kind == "srt" else to_vtt(v.seg_list)
        mime = "application/x-subrip" if kind == "srt" else "text/vtt"
        dl = request.args.get("dl")
        headers = {"Content-Disposition": f'attachment; filename="{base}_tamil.{kind}"'} if dl else {}
        return Response(text, mimetype=mime + "; charset=utf-8", headers=headers)
    if kind == "mp4" and v.export_path.exists():
        return send_file(v.export_path, as_attachment=True, download_name=f"{base}_tamil.mp4")
    abort(404)


@app.route("/video/<int:vid>/delete", methods=["POST"])
@login_required
def delete(vid):
    v = own(vid)
    v.path.unlink(missing_ok=True)
    (UPLOADS / f"{v.stored_name}.wav").unlink(missing_ok=True)
    shutil.rmtree(EXPORTS / str(v.id), ignore_errors=True)
    db.session.delete(v); db.session.commit()
    flash("Video and its subtitles were deleted.", "success")
    return redirect(url_for("dashboard"))


with app.app_context():
    db.create_all()
    # videos stuck mid-processing from a previous run can't resume
    for v in Video.query.filter(Video.status.in_(["queued", "processing", "exporting"])).all():
        v.status, v.error = "failed", "Server restarted during processing. Please upload again."
    db.session.commit()

if __name__ == "__main__":
    app.run(debug=False, host="0.0.0.0", port=5000, threaded=True)
