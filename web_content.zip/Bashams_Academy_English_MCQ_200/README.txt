BASHAM'S ACADEMY ENGLISH MCQs 200
- index.html: 200 MCQs, topic filters, automatic scoring and answer review.
- manifest.json: installable web-app metadata.
- sw.js: offline caching for hosted PWA use.
- icon.svg: app icon.

This ZIP is a web app starter, not an Android APK or Google Play release.
For a cached installable PWA, host the files on HTTPS and open once online.
To publish on Google Play, create a compatible Android App Bundle (.aab) and
complete Play Console registration, testing, disclosures, and review.
