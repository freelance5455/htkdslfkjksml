IRONSTART PRO — ADVANCED WORKOUT TRACKER
========================================

Included:
- 12-week beginner two-dumbbell A/B plan
- Set-by-set completion logging
- Automatic rest timer, pause, skip, and +30 seconds
- Session timer and workout history
- Weight check-ins and progress overview
- CSV export
- Camera-based rep-count estimate for squats, curls, push-ups, and overhead presses
- Local browser storage

HOW TO TEST
1. Extract the ZIP.
2. Open index.html in a modern browser for the basic tracker.
3. For camera tracking, serve it from HTTPS or localhost and allow camera access. The pose model is downloaded from a CDN, so internet is required for Form Coach.
4. Test camera tracking in Chrome before attempting to wrap it as an APK.

IMPORTANT ANDROID WEBVIEW NOTE
Opening a file directly inside an APK/ZIP-to-APK converter may block camera access, JavaScript modules, or external model downloads. The camera feature requires a WebView that grants camera permission, forwards permission requests, and permits the required HTTPS resources. A converter may not expose these settings. If the camera feature fails in the converter, use Chrome or build a proper Android WebView wrapper with camera permission handling.

PRIVACY
Workout and weight data are stored in localStorage on the device/browser. The camera stream is processed in the page; this app code does not upload video. MediaPipe libraries/model are downloaded from Google/JSDelivr when camera tracking starts.

SAFETY
Rep counting is approximate, not a reliable form or injury detector. Use light weights while testing, keep the device stable, and stop if anything hurts. This is a prototype, not a medical device.
