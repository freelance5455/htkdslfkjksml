const pages=[...document.querySelectorAll('.page')];
const navItems=[...document.querySelectorAll('.nav-item')];
function showPage(id){
  pages.forEach(p=>p.classList.toggle('active',p.id===id));
  navItems.forEach(b=>b.classList.toggle('active',b.dataset.page===id));
  document.getElementById('nav').classList.remove('open');
  window.scrollTo({top:0,behavior:'smooth'});
}
navItems.forEach(b=>b.addEventListener('click',()=>showPage(b.dataset.page)));
document.querySelectorAll('[data-go]').forEach(b=>b.addEventListener('click',()=>showPage(b.dataset.go)));
document.getElementById('menuBtn').addEventListener('click',()=>document.getElementById('nav').classList.toggle('open'));

document.getElementById('joinForm').addEventListener('submit',e=>{
  e.preventDefault();
  const data=Object.fromEntries(new FormData(e.target).entries());
  const requests=JSON.parse(localStorage.getItem('ravexis_requests')||'[]');
  requests.push({...data,createdAt:new Date().toISOString()});
  localStorage.setItem('ravexis_requests',JSON.stringify(requests));
  document.getElementById('joinNotice').textContent='Cererea demonstrativă a fost salvată pe acest dispozitiv. Nu a fost trimisă către un administrator.';
  e.target.reset();
});
document.getElementById('loginForm').addEventListener('submit',e=>{
  e.preventDefault();
  document.getElementById('loginNotice').textContent='Autentificarea nu este activată în această versiune demonstrativă.';
});
if('serviceWorker' in navigator && location.protocol.startsWith('http')){
  window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
}
