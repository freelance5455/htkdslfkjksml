# Fast Launcher

A free, lightweight Android launcher project using Kotlin + Jetpack Compose.

Features:
- HOME launcher role
- App drawer
- App search
- Dark/light theme toggle
- Smooth lightweight transitions
- Android 15 target
- No paid SDKs or subscriptions

Open the folder in Android Studio and build/install the app.
To use it as the default launcher, press Home after installation and select Fast Launcher.
