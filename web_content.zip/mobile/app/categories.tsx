import { useCallback, useEffect, useState } from "react";
import { Alert, StyleSheet, Text, View } from "react-native";
import * as Crypto from "expo-crypto";
import { addCategory, deleteCategory, listCategories } from "../src/db/repository";
import type { Category } from "../src/domain/types";
import { t } from "../src/i18n";
import { useFinance } from "../src/shared/MobileProvider";
import { Button, Card, Field, Heading, Page, Pill } from "../src/shared/ui";

const swatches = ["#14836d", "#478e7f", "#557c9b", "#7b8e58", "#826fa6", "#bf765f", "#ba8a42", "#708078"];
const builtInNames: Record<string, "categorySalary" | "categoryOtherIncome" | "categoryHome" | "categoryFood" | "categoryTransport" | "categoryHealth" | "categoryFamily" | "categoryOther"> = {
  "income-salary": "categorySalary", "income-other": "categoryOtherIncome", "expense-home": "categoryHome",
  "expense-food": "categoryFood", "expense-transport": "categoryTransport", "expense-health": "categoryHealth",
  "expense-family": "categoryFamily", "expense-other": "categoryOther",
};

export default function CategoriesScreen() {
  const { language, colors, refresh } = useFinance();
  const [kind, setKind] = useState<"income" | "expense">("expense");
  const [items, setItems] = useState<Category[]>([]);
  const [name, setName] = useState("");
  const [color, setColor] = useState(swatches[0]);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => { setItems(await listCategories(kind)); }, [kind]);
  useEffect(() => { void load().catch(() => setError(t(language, "genericError"))); }, [load, language]);

  const add = async () => {
    const clean = name.trim();
    if (!clean || clean.length > 40) { setError(t(language, "required")); return; }
    if (items.length >= 100) { setError(t(language, "categoryLimit")); return; }
    if (items.some((item) => item.name.trim().toLocaleLowerCase() === clean.toLocaleLowerCase())) { setError(t(language, "categoryDuplicate")); return; }
    setBusy(true); setError("");
    try {
      await addCategory({ id: Crypto.randomUUID(), name: clean, kind, color });
      setName(""); await load(); refresh();
    } catch { setError(t(language, "genericError")); }
    finally { setBusy(false); }
  };
  const remove = (item: Category) => {
    if (item.isDefault) return;
    Alert.alert(t(language, "delete"), t(language, "deleteCategoryConfirm"), [
      { text: t(language, "cancel"), style: "cancel" },
      { text: t(language, "delete"), style: "destructive", onPress: () => {
        setBusy(true); void deleteCategory(item.id).then(async () => { await load(); refresh(); }).catch(() => setError(t(language, "genericError"))).finally(() => setBusy(false));
      } },
    ]);
  };

  return <Page title={t(language, "categoriesTitle")} subtitle={t(language, "customCategories")}>
    <Card>
      <Heading>{t(language, "categoryType")}</Heading>
      <View style={styles.pills}>
        <Pill title={t(language, "income")} selected={kind === "income"} onPress={() => setKind("income")} />
        <Pill title={t(language, "expenses")} selected={kind === "expense"} onPress={() => setKind("expense")} />
      </View>
      <Field label={t(language, "categoryName")} value={name} onChangeText={setName} maxLength={40} returnKeyType="done" />
      <Text style={{ color: colors.inkMuted }}>{t(language, "categoryColor")}</Text>
      <View style={styles.pills}>{swatches.map((swatch) => <Pill key={swatch} title="●" selected={color === swatch} onPress={() => setColor(swatch)} style={{ borderColor: swatch, backgroundColor: color === swatch ? swatch : colors.surface }} />)}</View>
      <Button title={t(language, "addCategory")} onPress={() => void add()} disabled={busy} />
    </Card>
    <Card>
      <Heading>{kind === "income" ? t(language, "income") : t(language, "expenses")}</Heading>
      {items.map((item) => {
        const translated = builtInNames[item.id];
        return <View key={item.id} style={styles.row}>
          <View style={[styles.swatch, { backgroundColor: item.color }]} />
          <Text style={[styles.name, { color: colors.ink }]}>{item.isDefault && translated ? t(language, translated) : item.name}</Text>
          {item.isDefault ? <Text style={{ color: colors.inkMuted, fontSize: 12 }}>{t(language, "default")}</Text> : <Button title={t(language, "delete")} variant="danger" onPress={() => remove(item)} disabled={busy} />}
        </View>;
      })}
    </Card>
    {error ? <Text accessibilityRole="alert" style={{ color: colors.red }}>{error}</Text> : null}
  </Page>;
}
const styles = StyleSheet.create({
  pills: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  row: { flexDirection: "row", alignItems: "center", gap: 10, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: "#dce6df", paddingVertical: 8 },
  swatch: { width: 15, height: 15, borderRadius: 8 }, name: { flex: 1, fontWeight: "700" },
});
