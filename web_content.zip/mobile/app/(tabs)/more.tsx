import { useRouter } from "expo-router";
import { StyleSheet, Text, View } from "react-native";
import { Button, Card, Heading, Page } from "../../src/shared/ui";
import { useFinance } from "../../src/shared/MobileProvider";
import { t } from "../../src/i18n";

const links = [
  { title: "budgets", route: "/budget" as const, subtitle: "budgetLimit" },
  { title: "calendar", route: "/calendar" as const, subtitle: "importantDates" },
  { title: "zakat", route: "/zakat" as const, subtitle: "zakatIntro" },
  { title: "reports", route: "/reports" as const, subtitle: "reportsTitle" },
  { title: "categoriesTitle", route: "/categories" as const, subtitle: "customCategories" },
  { title: "settings", route: "/settings" as const, subtitle: "preferences" },
  { title: "premium", route: "/premium" as const, subtitle: "premiumUnavailable" },
  { title: "backup", route: "/backup" as const, subtitle: "backupUnavailable" },
] as const;

export default function MoreScreen() {
  const router = useRouter();
  const { language, colors } = useFinance();
  return <Page title={t(language, "more")} subtitle={t(language, "offline")}>
    {links.map((item) => <Card key={item.route} style={styles.card}>
      <View style={styles.copy}>
        <Heading>{t(language, item.title)}</Heading>
        <Text style={[styles.subtitle, { color: colors.inkMuted }]}>{t(language, item.subtitle)}</Text>
      </View>
      <Button title={t(language, "continue")} variant="secondary" onPress={() => router.push(item.route)} />
    </Card>)}
  </Page>;
}

const styles = StyleSheet.create({ card: { gap: 12 }, copy: { gap: 2 }, subtitle: { fontSize: 12, lineHeight: 18 } });
