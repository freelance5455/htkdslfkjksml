import { Tabs } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { t } from "../../src/i18n";
import { useFinance } from "../../src/shared/MobileProvider";

const icons = {
  home: "home-outline",
  transactions: "receipt-outline",
  bills: "calendar-outline",
  debts: "swap-horizontal-outline",
  more: "grid-outline",
} as const;

export default function TabsLayout() {
  const { language, colors } = useFinance();
  return <Tabs screenOptions={{
    headerShown: false,
    tabBarActiveTintColor: colors.emerald,
    tabBarInactiveTintColor: colors.inkMuted,
    tabBarStyle: { backgroundColor: colors.surface, borderTopColor: colors.line, height: 66, paddingTop: 7, paddingBottom: 7 },
    tabBarLabelStyle: { fontSize: 10, fontWeight: "700" },
  }}>
    <Tabs.Screen name="index" options={{ title: t(language, "dashboard"), tabBarIcon: ({ color, size }) => <Ionicons name={icons.home} color={typeof color === "string" ? color : colors.inkMuted} size={size} /> }} />
    <Tabs.Screen name="transactions" options={{ title: t(language, "transactions"), tabBarIcon: ({ color, size }) => <Ionicons name={icons.transactions} color={typeof color === "string" ? color : colors.inkMuted} size={size} /> }} />
    <Tabs.Screen name="bills" options={{ title: t(language, "bills"), tabBarIcon: ({ color, size }) => <Ionicons name={icons.bills} color={typeof color === "string" ? color : colors.inkMuted} size={size} /> }} />
    <Tabs.Screen name="debts" options={{ title: t(language, "debts"), tabBarIcon: ({ color, size }) => <Ionicons name={icons.debts} color={typeof color === "string" ? color : colors.inkMuted} size={size} /> }} />
    <Tabs.Screen name="more" options={{ title: t(language, "more"), tabBarIcon: ({ color, size }) => <Ionicons name={icons.more} color={typeof color === "string" ? color : colors.inkMuted} size={size} /> }} />
  </Tabs>;
}
