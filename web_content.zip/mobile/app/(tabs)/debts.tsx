import { useCallback, useState } from "react";
import { Alert, StyleSheet, Text, View } from "react-native";
import { useFocusEffect, useRouter } from "expo-router";
import { daysBetween, toLocalDateKey } from "../../src/domain/dates";
import { currencyDefinitionFor, formatMoney, type CurrencyDefinition } from "../../src/domain/money";
import type { Debt, Repayment } from "../../src/domain/types";
import { deleteDebt, listDebts, listRepayments, readSetting } from "../../src/db/repository";
import { cancelEntityReminders } from "../../src/features/localReminders";
import { localeFor, t } from "../../src/i18n";
import { Button, Card, Heading, Page, Pill } from "../../src/shared/ui";
import { useFinance } from "../../src/shared/MobileProvider";

type DebtRow = Debt & { repaidMinor: string; remainingMinor: string };

export default function DebtsScreen() {
  const router = useRouter();
  const { language, colors, refreshKey } = useFinance();
  const [rows, setRows] = useState<DebtRow[]>([]);
  const [currencies, setCurrencies] = useState<CurrencyDefinition[]>([]);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [history, setHistory] = useState<Repayment[]>([]);
  const [filter, setFilter] = useState<"all" | "lent" | "borrowed">("all");
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    const [debts, customCurrencies] = await Promise.all([listDebts(), readSetting<CurrencyDefinition[]>("customCurrencies", [])]);
    setRows(debts); setCurrencies(customCurrencies); setError("");
  }, []);
  useFocusEffect(useCallback(() => {
    let active = true;
    void load().catch(() => { if (active) setError(t(language, "genericError")); });
    return () => { active = false; };
  }, [load, refreshKey, language]));

  const openHistory = async (debt: DebtRow) => {
    if (expandedId === debt.id) { setExpandedId(null); return; }
    try { setHistory(await listRepayments(debt.id)); setExpandedId(debt.id); }
    catch { setError(t(language, "genericError")); }
  };

  const remove = (debt: DebtRow) => Alert.alert(t(language, "delete"), t(language, "deleteConfirm"), [
    { text: t(language, "cancel"), style: "cancel" },
    { text: t(language, "delete"), style: "destructive", onPress: () => { void deleteDebt(debt.id).then(() => cancelEntityReminders(debt.id)).then(load).catch(() => setError(t(language, "genericError"))); } },
  ]);

  const visible = rows.filter((row) => filter === "all" || row.direction === filter);
  return <Page title={t(language, "debts")} subtitle={t(language, "noDebtsDetail")}>
    <View style={styles.filters}>{(["all", "lent", "borrowed"] as const).map((item) => <Pill key={item} title={item === "all" ? t(language, "filterAll") : t(language, item)} selected={filter === item} onPress={() => setFilter(item)} />)}</View>
    <Button title={`＋ ${t(language, "debts")}`} onPress={() => router.push("/debt/new")} />
    {error ? <Text accessibilityRole="alert" style={{ color: colors.red }}>{error}</Text> : null}
    {visible.length ? <>
      <Heading>{visible.length} · {t(language, "thisMonth")}</Heading>
      {visible.map((debt) => {
        const days = debt.dueDate ? daysBetween(toLocalDateKey(), debt.dueDate) : null;
        const status = days === null ? debt.direction === "lent" ? t(language, "lent") : t(language, "borrowed") : days < 0 ? t(language, "overdue") : days === 0 ? t(language, "todayDue") : `${t(language, "due")} ${debt.dueDate}`;
        return <Card key={debt.id}>
          <View style={styles.top}><View style={{ flex: 1, gap: 3 }}><Text style={[styles.person, { color: colors.ink }]}>{debt.person}{debt.isDemo ? ` · ${t(language, "demo")}` : ""}</Text><Text style={[styles.detail, { color: days !== null && days <= 1 ? colors.amber : colors.inkMuted }]}>{status}{debt.note ? ` · ${debt.note}` : ""}</Text></View><Text style={[styles.remaining, { color: colors.ink }]}>{formatMoney(debt.remainingMinor, currencyDefinitionFor(debt.currency, currencies), localeFor(language))}</Text></View>
          <Text style={[styles.detail, { color: colors.inkMuted }]}>{t(language, "repaid")}: {formatMoney(debt.repaidMinor, currencyDefinitionFor(debt.currency, currencies), localeFor(language))} / {t(language, "principal")}: {formatMoney(debt.principalMinor, currencyDefinitionFor(debt.currency, currencies), localeFor(language))}</Text>
          <View style={styles.actions}><Button title={t(language, "repayPart")} disabled={BigInt(debt.remainingMinor) <= 0n} onPress={() => router.push({ pathname: "/debt/repay", params: { id: debt.id } })} style={styles.action} /><Button title={expandedId === debt.id ? t(language, "cancel") : t(language, "paymentHistory")} variant="secondary" onPress={() => void openHistory(debt)} style={styles.action} /></View>
          <Button title={t(language, "delete")} variant="danger" onPress={() => remove(debt)} style={styles.delete} />
          {expandedId === debt.id ? <View style={styles.history}><Heading>{t(language, "paymentHistory")}</Heading>{history.length ? history.map((payment) => <View key={payment.id} style={styles.historyRow}><Text style={[styles.detail, { color: colors.inkMuted }]}>{payment.dateKey}{payment.note ? ` · ${payment.note}` : ""}</Text><Text style={[styles.detail, { color: colors.ink }]}>{formatMoney(payment.amountMinor, currencyDefinitionFor(debt.currency, currencies), localeFor(language))}</Text></View>) : <Text style={[styles.detail, { color: colors.inkMuted }]}>{t(language, "noRepayments")}</Text>}</View> : null}
        </Card>;
      })}
    </> : <Card><Text style={[styles.person, { color: colors.ink }]}>{t(language, "noDebts")}</Text><Text style={[styles.detail, { color: colors.inkMuted }]}>{t(language, "noDebtsDetail")}</Text></Card>}
  </Page>;
}

const styles = StyleSheet.create({ filters: { flexDirection: "row", gap: 8, flexWrap: "wrap" }, top: { flexDirection: "row", gap: 10, alignItems: "flex-start" }, person: { fontSize: 15, fontWeight: "800" }, remaining: { fontSize: 14, fontWeight: "900" }, detail: { fontSize: 12, lineHeight: 18 }, actions: { flexDirection: "row", gap: 8, marginTop: 5 }, action: { flex: 1, minHeight: 42, paddingHorizontal: 8 }, delete: { minHeight: 38, paddingVertical: 6, alignSelf: "flex-end" }, history: { borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: "#d9e5df", paddingTop: 10, gap: 6 }, historyRow: { flexDirection: "row", justifyContent: "space-between", gap: 10 }, });
