import { useCallback, useState } from "react";
import { Alert, StyleSheet, Text, View } from "react-native";
import { useFocusEffect, useRouter } from "expo-router";
import { daysBetween, toLocalDateKey } from "../../src/domain/dates";
import { currencyDefinitionFor, formatMoney, type CurrencyDefinition } from "../../src/domain/money";
import type { Bill } from "../../src/domain/types";
import { deleteBill, listBills, markBillPaid, readSetting } from "../../src/db/repository";
import { cancelEntityReminders, scheduleEntityReminders } from "../../src/features/localReminders";
import { localeFor, t } from "../../src/i18n";
import { Button, Card, Heading, Page } from "../../src/shared/ui";
import { useFinance } from "../../src/shared/MobileProvider";

export default function BillsScreen() {
  const router = useRouter();
  const { language, colors, refreshKey, refresh } = useFinance();
  const [bills, setBills] = useState<Bill[]>([]);
  const [customCurrencies, setCustomCurrencies] = useState<CurrencyDefinition[]>([]);
  const [error, setError] = useState("");

  useFocusEffect(useCallback(() => {
    let active = true;
    void Promise.all([listBills(), readSetting<CurrencyDefinition[]>("customCurrencies", [])]).then(([items, currencies]) => {
      if (!active) return;
      setBills(items); setCustomCurrencies(currencies); setError("");
    }).catch(() => { if (active) setError(t(language, "genericError")); });
    return () => { active = false; };
  }, [refreshKey, language]));

  const pay = (bill: Bill) => Alert.alert(t(language, "markPaid"), t(language, "markPaidConfirm"), [
    { text: t(language, "cancel"), style: "cancel" },
    { text: t(language, "markPaid"), onPress: () => { void (async () => {
      try {
        await markBillPaid(bill.id);
        const refreshed = await listBills();
        const next = refreshed.find((item) => item.id === bill.id);
        if (next?.isActive && next.reminderOffsets.length) {
          await scheduleEntityReminders({ entityId: next.id, kind: "bill", dueDate: next.nextDueDate, offsets: next.reminderOffsets, language });
        } else {
          await cancelEntityReminders(bill.id);
        }
        setBills(refreshed); await refresh(); setError("");
      } catch { setError(t(language, "genericError")); }
    })(); } },
  ]);

  const remove = (bill: Bill) => Alert.alert(t(language, "delete"), t(language, "deleteConfirm"), [
    { text: t(language, "cancel"), style: "cancel" },
    { text: t(language, "delete"), style: "destructive", onPress: () => { void deleteBill(bill.id).then(() => cancelEntityReminders(bill.id)).then(refresh).catch(() => setError(t(language, "genericError"))); } },
  ]);

  return <Page title={t(language, "bills")} subtitle={t(language, "noBillsDetail")}>
    <Button title={`＋ ${t(language, "addBill")}`} onPress={() => router.push("/bill/new")} />
    {error ? <Text accessibilityRole="alert" style={{ color: colors.red }}>{error}</Text> : null}
    {bills.length ? <>
      <Heading>{t(language, "upcoming")}</Heading>
      {bills.map((bill) => {
        const days = daysBetween(toLocalDateKey(), bill.nextDueDate);
        const state = days < 0 ? t(language, "overdue") : days === 0 ? t(language, "todayDue") : `${t(language, "due")} ${bill.nextDueDate}`;
        return <Card key={bill.id}>
          <View style={styles.head}>
            <View style={{ flex: 1, gap: 4 }}><Text style={[styles.title, { color: colors.ink }]}>{bill.title}{bill.isDemo ? ` · ${t(language, "demo")}` : ""}</Text><Text style={[styles.detail, { color: days <= 1 ? colors.amber : colors.inkMuted }]}>{state} · {bill.recurrence === "none" ? t(language, "noRepeat") : t(language, "recurring")}</Text></View>
            <Text style={[styles.amount, { color: colors.ink }]}>{formatMoney(bill.amountMinor, currencyDefinitionFor(bill.currency, customCurrencies), localeFor(language))}</Text>
          </View>
          <View style={styles.actions}><Button title={t(language, "markPaid")} onPress={() => pay(bill)} style={styles.action} /><Button title={t(language, "editBill")} variant="secondary" onPress={() => router.push({ pathname: "/bill/new", params: { id: bill.id } })} style={styles.action} /><Button title={t(language, "delete")} variant="danger" onPress={() => remove(bill)} style={styles.action} /></View>
        </Card>;
      })}
    </> : <Card><Text style={[styles.title, { color: colors.ink }]}>{t(language, "noBills")}</Text><Text style={[styles.detail, { color: colors.inkMuted }]}>{t(language, "noBillsDetail")}</Text></Card>}
  </Page>;
}

const styles = StyleSheet.create({ head: { flexDirection: "row", alignItems: "flex-start", gap: 10 }, title: { fontSize: 15, fontWeight: "800" }, detail: { fontSize: 12 }, amount: { fontSize: 13, fontWeight: "800" }, actions: { flexDirection: "row", gap: 8, marginTop: 6 }, action: { flex: 1, minHeight: 42, paddingHorizontal: 8 }, });
