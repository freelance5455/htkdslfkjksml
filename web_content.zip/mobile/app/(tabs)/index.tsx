import { useCallback, useState } from "react";
import { ActivityIndicator, Pressable, StyleSheet, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useFocusEffect, useRouter } from "expo-router";
import { formatMoney, currencyDefinitionFor, type CurrencyDefinition } from "../../src/domain/money";
import { toLocalDateKey } from "../../src/domain/dates";
import type { Bill, Debt, MonthlySummary, Transaction } from "../../src/domain/types";
import { listBills, listDebts, listTransactions, monthlySummary, readSetting } from "../../src/db/repository";
import { localeFor, t } from "../../src/i18n";
import { Button, Card, Heading, Page } from "../../src/shared/ui";
import { useFinance } from "../../src/shared/MobileProvider";
import { spacing } from "../../src/theme/tokens";

export default function HomeScreen() {
  const router = useRouter();
  const { language, currency, colors, refreshKey } = useFinance();
  const monthKey = toLocalDateKey().slice(0, 7);
  const [summary, setSummary] = useState<MonthlySummary | null>(null);
  const [recent, setRecent] = useState<Transaction[]>([]);
  const [bills, setBills] = useState<Bill[]>([]);
  const [debts, setDebts] = useState<Array<Debt & { remainingMinor: string }>>([]);
  const [customCurrencies, setCustomCurrencies] = useState<CurrencyDefinition[]>([]);
  const [demo, setDemo] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useFocusEffect(useCallback(() => {
    let active = true;
    void (async () => {
      const [nextSummary, nextRecent, nextBills, nextDebts, custom] = await Promise.all([
        monthlySummary(monthKey, currency), listTransactions({ monthKey, limit: 5 }), listBills(), listDebts(),
        readSetting<CurrencyDefinition[]>("customCurrencies", []),
      ]);
      const hasDemo = nextRecent.some((item) => item.isDemo) || nextBills.some((item) => item.isDemo) || nextDebts.some((item) => item.isDemo);
      if (!active) return;
      setSummary(nextSummary);
      setRecent(nextRecent);
      setBills(nextBills.slice(0, 3));
      setDebts(nextDebts.filter((item) => item.currency === currency).slice(0, 3));
      setCustomCurrencies(custom);
      setDemo(hasDemo);
      setError("");
      setLoading(false);
    })().catch(() => { if (active) { setError(t(language, "genericError")); setLoading(false); } });
    return () => { active = false; };
  }, [monthKey, currency, refreshKey, language]));

  const currencyInfo = currencyDefinitionFor(currency, customCurrencies);
  const locale = localeFor(language);
  const income = BigInt(summary?.incomeMinor ?? "0");
  const expense = BigInt(summary?.expenseMinor ?? "0");
  const max = income > expense ? income : expense;
  const barWidth = (value: bigint) => max === 0n ? "0%" as const : `${Math.max(5, Number(value * 100n / max))}%` as `${number}%`;

  return <Page>
    <View style={styles.topLine}>
      <View style={{ flex: 1 }}><Text style={[styles.overline, { color: colors.emerald }]}>{t(language, "appName")}</Text><Text style={[styles.title, { color: colors.ink }]}>{t(language, "hello")}</Text></View>
      <Pressable accessibilityRole="button" accessibilityLabel={t(language, "settings")} onPress={() => router.push("/settings")} style={[styles.settingsButton, { backgroundColor: colors.surface, borderColor: colors.line }]}><Ionicons name="settings-outline" size={21} color={colors.ink} /></Pressable>
    </View>
    {demo ? <View style={[styles.demoBanner, { backgroundColor: colors.amberSoft }]}><Ionicons name="information-circle-outline" size={18} color={colors.amber} /><Text style={[styles.demoText, { color: colors.amber }]}>{t(language, "sampleBanner")}</Text></View> : null}
    <Card style={[styles.hero, { backgroundColor: colors.emerald, borderColor: colors.emerald }]}>
      <View style={styles.heroHead}><Text style={styles.heroLabel}>{t(language, "thisMonth")} · {monthKey}</Text><Text style={styles.heroCurrency}>{currency}</Text></View>
      <Text style={styles.heroTitle}>{t(language, "balance")}</Text>
      <Text style={styles.heroAmount}>{summary ? formatMoney(summary.balanceMinor, currencyInfo, locale) : "—"}</Text>
      <View style={styles.monthBars}>
        <View style={styles.barRow}><Text style={styles.barLabel}>{t(language, "income")}</Text><View style={styles.barTrack}><View style={[styles.barFill, { width: barWidth(income), backgroundColor: "#ffffff" }]} /></View><Text style={styles.barValue}>{summary ? formatMoney(summary.incomeMinor, currencyInfo, locale) : "—"}</Text></View>
        <View style={styles.barRow}><Text style={styles.barLabel}>{t(language, "expenses")}</Text><View style={styles.barTrack}><View style={[styles.barFill, { width: barWidth(expense), backgroundColor: "#ccece1" }]} /></View><Text style={styles.barValue}>{summary ? formatMoney(summary.expenseMinor, currencyInfo, locale) : "—"}</Text></View>
      </View>
    </Card>
    <Heading>{t(language, "quickAdd")}</Heading>
    <View style={styles.quickRow}>
      <Button title={`＋ ${t(language, "addIncome")}`} onPress={() => router.push({ pathname: "/transaction/new", params: { kind: "income" } })} style={styles.quickButton} />
      <Button title={`＋ ${t(language, "addExpense")}`} variant="secondary" onPress={() => router.push({ pathname: "/transaction/new", params: { kind: "expense" } })} style={styles.quickButton} />
    </View>
    <View style={styles.sectionLine}><Heading>{t(language, "upcoming")}</Heading><Pressable onPress={() => router.push("/(tabs)/bills")}><Text style={{ color: colors.emerald, fontWeight: "800" }}>{t(language, "bills")}</Text></Pressable></View>
    {loading ? <ActivityIndicator color={colors.emerald} /> : error ? <Text style={{ color: colors.red }}>{error}</Text> : bills.length ? bills.map((bill) => <Card key={bill.id} style={styles.rowCard}>
      <View style={styles.rowIcon}><Ionicons name="calendar-outline" size={18} color={colors.emerald} /></View>
      <View style={{ flex: 1 }}><Text style={[styles.rowTitle, { color: colors.ink }]}>{bill.title}</Text><Text style={[styles.rowDetail, { color: colors.inkMuted }]}>{bill.nextDueDate}{bill.isDemo ? ` · ${t(language, "demo")}` : ""}</Text></View>
      <Text style={[styles.rowAmount, { color: colors.ink }]}>{formatMoney(bill.amountMinor, currencyDefinitionFor(bill.currency, customCurrencies), locale)}</Text>
    </Card>) : <Card><Text style={[styles.rowTitle, { color: colors.ink }]}>{t(language, "noBills")}</Text><Text style={[styles.rowDetail, { color: colors.inkMuted }]}>{t(language, "noBillsDetail")}</Text><Button title={t(language, "addBill")} variant="secondary" onPress={() => router.push("/bill/new")} /></Card>}
    <Heading>{t(language, "recentActivity")}</Heading>
    {loading ? null : recent.length ? recent.map((item) => <Card key={item.id} style={styles.rowCard}>
      <View style={[styles.rowIcon, { backgroundColor: item.kind === "income" ? colors.emeraldSoft : colors.amberSoft }]}><Ionicons name={item.kind === "income" ? "arrow-down-outline" : "arrow-up-outline"} size={18} color={item.kind === "income" ? colors.emerald : colors.amber} /></View>
      <View style={{ flex: 1 }}><Text style={[styles.rowTitle, { color: colors.ink }]}>{item.note || t(language, item.kind === "income" ? "income" : "expenses")}</Text><Text style={[styles.rowDetail, { color: colors.inkMuted }]}>{item.dateKey}{item.isDemo ? ` · ${t(language, "demo")}` : ""}</Text></View>
      <Text style={[styles.rowAmount, { color: item.kind === "income" ? colors.emerald : colors.ink }]}>{item.kind === "income" ? "+" : "−"}{formatMoney(item.amountMinor, currencyDefinitionFor(item.currency, customCurrencies), locale)}</Text>
    </Card>) : <Text style={{ color: colors.inkMuted }}>{t(language, "noRecords")}</Text>}
    {debts.length ? <>
      <View style={styles.sectionLine}><Heading>{t(language, "debts")}</Heading><Pressable onPress={() => router.push("/(tabs)/debts")}><Text style={{ color: colors.emerald, fontWeight: "800" }}>{t(language, "more")}</Text></Pressable></View>
      {debts.map((debt) => <Card key={debt.id} style={styles.rowCard}><View style={{ flex: 1 }}><Text style={[styles.rowTitle, { color: colors.ink }]}>{debt.person}</Text><Text style={[styles.rowDetail, { color: colors.inkMuted }]}>{debt.direction === "lent" ? t(language, "lent") : t(language, "borrowed")}{debt.isDemo ? ` · ${t(language, "demo")}` : ""}</Text></View><Text style={[styles.rowAmount, { color: colors.ink }]}>{formatMoney(debt.remainingMinor, currencyDefinitionFor(debt.currency, customCurrencies), locale)}</Text></Card>)}
    </> : null}
  </Page>;
}

const styles = StyleSheet.create({
  topLine: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", gap: 12 }, overline: { fontSize: 12, fontWeight: "900", letterSpacing: 1.2 }, title: { fontSize: 21, fontWeight: "900", marginTop: 4 },
  settingsButton: { width: 44, height: 44, borderWidth: 1, borderRadius: 15, alignItems: "center", justifyContent: "center" },
  demoBanner: { borderRadius: 12, padding: 12, flexDirection: "row", gap: 8, alignItems: "center" }, demoText: { flex: 1, fontSize: 12, lineHeight: 17, fontWeight: "700" },
  hero: { borderRadius: 22, padding: 18, gap: 7 }, heroHead: { flexDirection: "row", justifyContent: "space-between" }, heroLabel: { color: "#d5eee6", fontSize: 12, fontWeight: "700" }, heroCurrency: { color: "#ffffff", fontWeight: "900", fontSize: 13 },
  heroTitle: { color: "#ffffff", fontSize: 14, marginTop: 2 }, heroAmount: { color: "#ffffff", fontSize: 27, fontWeight: "900", fontVariant: ["tabular-nums"] },
  monthBars: { marginTop: 10, gap: 9 }, barRow: { flexDirection: "row", alignItems: "center", gap: 8 }, barLabel: { color: "#eaf5f1", fontSize: 11, width: 54, fontWeight: "700" }, barTrack: { flex: 1, height: 6, borderRadius: 9, backgroundColor: "#ffffff55", overflow: "hidden" }, barFill: { height: 6, borderRadius: 9 }, barValue: { color: "#ffffff", fontSize: 11, fontWeight: "700", width: 90, textAlign: "right" },
  quickRow: { flexDirection: "row", gap: 9 }, quickButton: { flex: 1, minHeight: 46, paddingHorizontal: 8 }, sectionLine: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: spacing.sm },
  rowCard: { flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 12, paddingHorizontal: 12 }, rowIcon: { width: 38, height: 38, borderRadius: 12, alignItems: "center", justifyContent: "center", backgroundColor: "#e3f2ec" }, rowTitle: { fontSize: 14, fontWeight: "800" }, rowDetail: { fontSize: 11, marginTop: 4 }, rowAmount: { fontSize: 12, fontWeight: "800", textAlign: "right", fontVariant: ["tabular-nums"] },
});
