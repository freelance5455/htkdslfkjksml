import { useCallback, useState } from "react";
import { Alert, StyleSheet, Text, View } from "react-native";
import { useFocusEffect, useRouter } from "expo-router";
import { toLocalDateKey } from "../../src/domain/dates";
import { currencyDefinitionFor, formatMoney, type CurrencyDefinition } from "../../src/domain/money";
import type { Transaction } from "../../src/domain/types";
import { deleteTransaction, listTransactions, readSetting } from "../../src/db/repository";
import { localeFor, t } from "../../src/i18n";
import { Button, Card, Field, Heading, Page, Pill } from "../../src/shared/ui";
import { useFinance } from "../../src/shared/MobileProvider";

export default function TransactionsScreen() {
  const router = useRouter();
  const { language, colors, refreshKey, refresh } = useFinance();
  const [monthKey, setMonthKey] = useState(toLocalDateKey().slice(0, 7));
  const [search, setSearch] = useState("");
  const [kind, setKind] = useState<"all" | "income" | "expense">("all");
  const [rows, setRows] = useState<Transaction[]>([]);
  const [customCurrencies, setCustomCurrencies] = useState<CurrencyDefinition[]>([]);
  const [error, setError] = useState("");

  useFocusEffect(useCallback(() => {
    let active = true;
    void Promise.all([
      listTransactions({ kind: kind === "all" ? undefined : kind, monthKey: /^\d{4}-\d{2}$/.test(monthKey) ? monthKey : undefined, search, limit: 300 }),
      readSetting<CurrencyDefinition[]>("customCurrencies", []),
    ]).then(([items, currencies]) => {
      if (!active) return;
      setRows(items);
      setCustomCurrencies(currencies);
      setError("");
    }).catch(() => { if (active) setError(t(language, "genericError")); });
    return () => { active = false; };
  }, [kind, monthKey, search, refreshKey, language]));

  const remove = (item: Transaction) => Alert.alert(t(language, "delete"), t(language, "deleteConfirm"), [
    { text: t(language, "cancel"), style: "cancel" },
    { text: t(language, "delete"), style: "destructive", onPress: () => { void deleteTransaction(item.id).then(refresh).catch(() => setError(t(language, "genericError"))); } },
  ]);

  return <Page title={t(language, "transactions")} subtitle={t(language, "privacyTitle")}>
    <View style={styles.filters}>{(["all", "income", "expense"] as const).map((item) => <Pill key={item} selected={kind === item} title={t(language, item === "all" ? "filterAll" : item === "income" ? "filterIncome" : "filterExpense")} onPress={() => setKind(item)} />)}</View>
    <Field label={t(language, "month")} value={monthKey} onChangeText={setMonthKey} autoCapitalize="none" placeholder="YYYY-MM" />
    <Field label={t(language, "searchHint")} value={search} onChangeText={setSearch} />
    <Button title={`＋ ${t(language, "addRecord")}`} onPress={() => router.push("/transaction/new")} />
    {error ? <Text accessibilityRole="alert" style={{ color: colors.red }}>{error}</Text> : null}
    <Heading>{rows.length ? `${rows.length} · ${monthKey || t(language, "filterAll")}` : t(language, "noTransactions")}</Heading>
    {rows.length ? rows.map((item) => <Card key={item.id} style={styles.item}>
      <View style={{ flex: 1, gap: 4 }}>
        <Text style={[styles.note, { color: colors.ink }]}>{item.note || t(language, item.kind === "income" ? "income" : "expenses")}{item.isDemo ? ` · ${t(language, "demo")}` : ""}</Text>
        <Text style={[styles.date, { color: colors.inkMuted }]}>{item.dateKey} · {item.currency}</Text>
      </View>
      <View style={styles.trailing}>
        <Text style={[styles.amount, { color: item.kind === "income" ? colors.emerald : colors.ink }]}>{item.kind === "income" ? "+" : "−"}{formatMoney(item.amountMinor, currencyDefinitionFor(item.currency, customCurrencies), localeFor(language))}</Text>
        <Button title={t(language, "delete")} variant="danger" onPress={() => remove(item)} style={styles.deleteButton} />
      </View>
    </Card>) : <Card><Text style={{ color: colors.inkMuted }}>{t(language, "noTransactionsDetail")}</Text></Card>}
  </Page>;
}

const styles = StyleSheet.create({ filters: { flexDirection: "row", flexWrap: "wrap", gap: 8 }, item: { flexDirection: "row", gap: 10, alignItems: "center", padding: 12 }, note: { fontSize: 14, fontWeight: "800" }, date: { fontSize: 11 }, trailing: { alignItems: "flex-end", gap: 5 }, amount: { fontSize: 12, fontWeight: "800" }, deleteButton: { minHeight: 32, paddingVertical: 4, paddingHorizontal: 10 }, });
