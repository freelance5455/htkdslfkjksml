import { Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { AppLockOverlay } from "../src/shared/AppLockOverlay";
import { MobileProvider, useFinance } from "../src/shared/MobileProvider";

function RootStack() {
  const { colors } = useFinance();
  return (
    <>
      <StatusBar style={colors.canvas === "#101815" ? "light" : "dark"} />
      <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.canvas } }}>
        <Stack.Screen name="index" />
        <Stack.Screen name="onboarding" />
        <Stack.Screen name="(tabs)" />
        <Stack.Screen name="transaction/new" options={{ presentation: "modal" }} />
        <Stack.Screen name="bill/new" options={{ presentation: "modal" }} />
        <Stack.Screen name="debt/new" options={{ presentation: "modal" }} />
        <Stack.Screen name="debt/repay" options={{ presentation: "modal" }} />
        <Stack.Screen name="budget" />
        <Stack.Screen name="calendar" />
        <Stack.Screen name="zakat" />
        <Stack.Screen name="reports" />
        <Stack.Screen name="settings" />
      </Stack>
      <AppLockOverlay />
    </>
  );
}

export default function RootLayout() {
  return <MobileProvider><RootStack /></MobileProvider>;
}
