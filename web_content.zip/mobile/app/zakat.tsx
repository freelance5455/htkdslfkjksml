import { useEffect, useMemo, useState } from "react";
import { StyleSheet, Text, View } from "react-native";
import { toLocalDateKey, isDateKey } from "../src/domain/dates";
import { currencyDefinitionFor, decimalToMinorUnits, DEFAULT_CURRENCIES, formatMoney, fractionDigitsFor, type CurrencyDefinition } from "../src/domain/money";
import { calculateZakat, gramsToMilliGrams, HANAFI_REFERENCE_NISAB, type ZakatInput } from "../src/domain/zakat";
import { readSetting, writeSetting } from "../src/db/repository";
import { localeFor, t } from "../src/i18n";
import { Button, Card, Field, Heading, Page, Pill } from "../src/shared/ui";
import { useFinance } from "../src/shared/MobileProvider";

type ZakatForm = {
  cash: string; savings: string; goldWeight: string; goldPrice: string; goldValue: string;
  silverWeight: string; silverPrice: string; silverValue: string; inventory: string;
  receivables: string; otherAssets: string; liabilities: string; deductions: string;
  goldNisabGrams: string; silverNisabGrams: string; nisabBasis: "gold" | "silver";
  haulConfirmed: boolean; nisabConfirmed: boolean; calculationDate: string;
};
const gramsFromMilli = (value: string) => {
  const grams = BigInt(value);
  const whole = grams / 1000n;
  const fraction = (grams % 1000n).toString().padStart(3, "0").replace(/0+$/, "");
  return fraction ? `${whole}.${fraction}` : whole.toString();
};
const emptyForm = (): ZakatForm => ({
  cash: "", savings: "", goldWeight: "", goldPrice: "", goldValue: "", silverWeight: "", silverPrice: "", silverValue: "",
  inventory: "", receivables: "", otherAssets: "", liabilities: "", deductions: "",
  goldNisabGrams: gramsFromMilli(HANAFI_REFERENCE_NISAB.goldMilliGrams), silverNisabGrams: gramsFromMilli(HANAFI_REFERENCE_NISAB.silverMilliGrams),
  nisabBasis: "silver", haulConfirmed: false, nisabConfirmed: false, calculationDate: toLocalDateKey(),
});
function buildInput(form: ZakatForm, currency: string, currencies: CurrencyDefinition[]): ZakatInput | null {
  const digits = fractionDigitsFor(currency, currencies);
  const amount = (value: string) => value.trim() ? decimalToMinorUnits(value, digits) : "0";
  const optionalAmount = (value: string) => value.trim() ? decimalToMinorUnits(value, digits) ?? null : undefined;
  const values = [form.cash, form.savings, form.inventory, form.receivables, form.otherAssets, form.liabilities, form.deductions].map(amount);
  if (values.some((value) => value === null)) return null;
  const goldNisab = gramsToMilliGrams(form.goldNisabGrams);
  const silverNisab = gramsToMilliGrams(form.silverNisabGrams);
  if (goldNisab === null || silverNisab === null) return null;
  const goldValue = optionalAmount(form.goldValue), silverValue = optionalAmount(form.silverValue);
  const goldPrice = optionalAmount(form.goldPrice), silverPrice = optionalAmount(form.silverPrice);
  if (goldValue === null || silverValue === null || goldPrice === null || silverPrice === null) return null;
  return {
    currency, currencyFractionDigits: digits,
    cashMinor: values[0]!, bankSavingsMinor: values[1]!,
    goldWeightGrams: form.goldWeight.trim() || undefined, goldPricePerGramMinor: goldPrice, goldValueMinor: goldValue,
    silverWeightGrams: form.silverWeight.trim() || undefined, silverPricePerGramMinor: silverPrice, silverValueMinor: silverValue,
    tradeInventoryMinor: values[2]!, receivablesMinor: values[3]!, otherEligibleAssetsMinor: values[4]!,
    dueLiabilitiesMinor: values[5]!, applicableDeductionsMinor: values[6]!,
    nisabBasis: form.nisabBasis, goldNisabMilliGrams: goldNisab, silverNisabMilliGrams: silverNisab,
    haulConfirmed: form.haulConfirmed, nisabConfirmed: form.nisabConfirmed,
  };
}

export default function ZakatScreen() {
  const { language, currency: homeCurrency, colors } = useFinance();
  const [form, setForm] = useState<ZakatForm>(emptyForm);
  const [currency, setCurrency] = useState(homeCurrency);
  const [customCurrencies, setCustomCurrencies] = useState<CurrencyDefinition[]>([]);
  const [error, setError] = useState("");
  const [saved, setSaved] = useState(false);
  useEffect(() => {
    let active = true;
    void Promise.all([readSetting<Partial<ZakatForm> & { currency?: string }>("zakatProfile", {}), readSetting<CurrencyDefinition[]>("customCurrencies", [])]).then(([profile, custom]) => {
      if (!active) return;
      setForm({ ...emptyForm(), ...profile }); setCurrency(profile.currency ?? homeCurrency); setCustomCurrencies(custom);
    }).catch(() => { if (active) setError(t(language, "genericError")); });
    return () => { active = false; };
  }, [homeCurrency, language]);
  const input = useMemo(() => buildInput(form, currency, customCurrencies), [form, currency, customCurrencies]);
  const result = useMemo(() => { if (!input) return null; try { return calculateZakat(input); } catch { return null; } }, [input]);
  const amountLabel = (value: string) => `${value} · ${currency}`;
  const setField = <K extends keyof ZakatForm>(key: K, value: ZakatForm[K]) => { setForm((current) => ({ ...current, [key]: value })); setSaved(false); };
  const save = async () => {
    if (!isDateKey(form.calculationDate)) { setError(t(language, "invalidDate")); return; }
    if (!input || !result) { setError(t(language, "invalidAmount")); return; }
    try {
      await writeSetting("zakatProfile", { ...form, currency, calculationDate: form.calculationDate, resultStatus: result.status, savedAt: new Date().toISOString() });
      setSaved(true); setError("");
    } catch { setError(t(language, "genericError")); }
  };
  const locale = localeFor(language), currencyInfo = currencyDefinitionFor(currency, customCurrencies);
  const statusKey = result?.status === "needs_price" ? "needsPrice" : result?.status === "below_nisab" ? "belowNisab" : result?.status === "confirm_conditions" ? "confirmConditions" : "estimateAvailable";

  return <Page title={t(language, "zakat")} subtitle={t(language, "zakatIntro")}>
    <Text style={[styles.note, { color: colors.inkMuted }]}>{t(language, "calculationMethod")}. {t(language, "priceUnitsInfo")}</Text>
    <View style={styles.pills}>{[...DEFAULT_CURRENCIES, ...customCurrencies].map((item) => <Pill key={item.code} title={item.code} selected={currency === item.code} onPress={() => { setCurrency(item.code); setSaved(false); }} />)}</View>
    <Card>
      <Heading>{t(language, "zakatAssets")}</Heading>
      <Field label={amountLabel(t(language, "cash"))} value={form.cash} onChangeText={(value) => setField("cash", value)} keyboardType="decimal-pad" />
      <Field label={amountLabel(t(language, "savings"))} value={form.savings} onChangeText={(value) => setField("savings", value)} keyboardType="decimal-pad" />
      <Field label={`${t(language, "goldWeight")} · ${t(language, "goldValue")}`} value={form.goldWeight} onChangeText={(value) => setField("goldWeight", value)} keyboardType="decimal-pad" hint={`${t(language, "goldPrice")}: ${form.goldPrice || "—"} ${currency}/g`} />
      <Field label={amountLabel(t(language, "goldPrice"))} value={form.goldPrice} onChangeText={(value) => setField("goldPrice", value)} keyboardType="decimal-pad" />
      <Field label={amountLabel(t(language, "goldValue"))} value={form.goldValue} onChangeText={(value) => setField("goldValue", value)} keyboardType="decimal-pad" hint={t(language, "goldValue")} />
      <Field label={`${t(language, "silverWeight")} · ${t(language, "silverValue")}`} value={form.silverWeight} onChangeText={(value) => setField("silverWeight", value)} keyboardType="decimal-pad" hint={`${t(language, "silverPrice")}: ${form.silverPrice || "—"} ${currency}/g`} />
      <Field label={amountLabel(t(language, "silverPrice"))} value={form.silverPrice} onChangeText={(value) => setField("silverPrice", value)} keyboardType="decimal-pad" />
      <Field label={amountLabel(t(language, "silverValue"))} value={form.silverValue} onChangeText={(value) => setField("silverValue", value)} keyboardType="decimal-pad" />
      <Field label={amountLabel(t(language, "inventory"))} value={form.inventory} onChangeText={(value) => setField("inventory", value)} keyboardType="decimal-pad" />
      <Field label={amountLabel(t(language, "receivables"))} value={form.receivables} onChangeText={(value) => setField("receivables", value)} keyboardType="decimal-pad" />
      <Field label={amountLabel(t(language, "otherAssets"))} value={form.otherAssets} onChangeText={(value) => setField("otherAssets", value)} keyboardType="decimal-pad" />
    </Card>
    <Card>
      <Heading>{t(language, "zakatLiabilities")}</Heading>
      <Field label={amountLabel(t(language, "liabilities"))} value={form.liabilities} onChangeText={(value) => setField("liabilities", value)} keyboardType="decimal-pad" />
      <Field label={amountLabel(t(language, "deductions"))} value={form.deductions} onChangeText={(value) => setField("deductions", value)} keyboardType="decimal-pad" />
    </Card>
    <Card>
      <Heading>{t(language, "nisabBasis")}</Heading>
      <View style={styles.pills}><Pill title={t(language, "goldWeight")} selected={form.nisabBasis === "gold"} onPress={() => setField("nisabBasis", "gold")} /><Pill title={t(language, "silverWeight")} selected={form.nisabBasis === "silver"} onPress={() => setField("nisabBasis", "silver")} /></View>
      <Field label={t(language, "goldNisab")} value={form.goldNisabGrams} onChangeText={(value) => setField("goldNisabGrams", value)} keyboardType="decimal-pad" hint="87.48 g is an editable Hanafi-oriented starting reference." />
      <Field label={t(language, "silverNisab")} value={form.silverNisabGrams} onChangeText={(value) => setField("silverNisabGrams", value)} keyboardType="decimal-pad" hint="612.35 g is an editable Hanafi-oriented starting reference." />
      <Field label={t(language, "calculationDate")} value={form.calculationDate} onChangeText={(value) => setField("calculationDate", value)} autoCapitalize="none" />
      <Pill title={t(language, "confirmNisab")} selected={form.nisabConfirmed} onPress={() => setField("nisabConfirmed", !form.nisabConfirmed)} />
      <Pill title={t(language, "confirmHaul")} selected={form.haulConfirmed} onPress={() => setField("haulConfirmed", !form.haulConfirmed)} />
    </Card>
    <Card>
      <Heading>{t(language, "calculate")}</Heading>
      {result ? <Text style={[styles.status, { color: result.status === "estimate_available" ? colors.emerald : colors.amber }]}>{t(language, statusKey)}</Text> : <Text style={[styles.status, { color: colors.amber }]}>{t(language, "invalidAmount")}</Text>}
      {result?.status !== "needs_price" && result ? <>
        <ResultRow label={t(language, "zakatAssets")} value={formatMoney(result.grossAssetsMinor, currencyInfo, locale)} />
        <ResultRow label={t(language, "zakatLiabilities")} value={formatMoney(result.liabilitiesAndDeductionsMinor, currencyInfo, locale)} />
        <ResultRow label={t(language, "zakatWealth")} value={formatMoney(result.zakatableWealthMinor, currencyInfo, locale)} />
        {result.selectedNisabValueMinor ? <ResultRow label={t(language, "nisabValue")} value={formatMoney(result.selectedNisabValueMinor, currencyInfo, locale)} /> : null}
        {result.zakatDueMinor ? <ResultRow label={t(language, "payable")} value={formatMoney(result.zakatDueMinor, currencyInfo, locale)} strong /> : null}
      </> : null}
      <Text style={[styles.note, { color: colors.inkMuted }]}>{t(language, "zakatDisclaimer")} {t(language, "estimateOnly")}</Text>
      <Button title={saved ? t(language, "zakatSaved") : t(language, "save")} onPress={() => void save()} />
    </Card>
    {error ? <Text accessibilityRole="alert" style={{ color: colors.red }}>{error}</Text> : null}
  </Page>;
}
function ResultRow({ label, value, strong = false }: { label: string; value: string; strong?: boolean }) {
  const { colors } = useFinance();
  return <View style={styles.resultRow}><Text style={[styles.resultLabel, { color: colors.inkMuted }]}>{label}</Text><Text style={[styles.resultValue, { color: colors.ink, fontWeight: strong ? "900" : "700" }]}>{value}</Text></View>;
}
const styles = StyleSheet.create({ note: { fontSize: 13, lineHeight: 19 }, pills: { flexDirection: "row", flexWrap: "wrap", gap: 8 }, status: { fontSize: 14, fontWeight: "900" }, resultRow: { flexDirection: "row", justifyContent: "space-between", gap: 12 }, resultLabel: { flex: 1, fontSize: 13 }, resultValue: { fontSize: 13 }, });
