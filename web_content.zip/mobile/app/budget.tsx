import { useCallback, useEffect, useState } from "react";
import { Alert, StyleSheet, Text, View } from "react-native";
import * as Crypto from "expo-crypto";
import { addBudget, deleteBudget, listBudgets, listCategories, readSetting } from "../src/db/repository";
import { toLocalDateKey } from "../src/domain/dates";
import { currencyDefinitionFor, decimalToMinorUnits, DEFAULT_CURRENCIES, formatMoney, fractionDigitsFor, type CurrencyDefinition } from "../src/domain/money";
import type { Budget, Category } from "../src/domain/types";
import { localeFor, t } from "../src/i18n";
import { Button, Card, Field, Page, Pill } from "../src/shared/ui";
import { useFinance } from "../src/shared/MobileProvider";

type BudgetRow = Budget & { spentMinor: string };
export default function BudgetScreen() {
  const { language, currency: preferredCurrency, colors, refreshKey, refresh } = useFinance();
  const [monthKey, setMonthKey] = useState(toLocalDateKey().slice(0, 7));
  const [currency, setCurrency] = useState(preferredCurrency);
  const [categoryId, setCategoryId] = useState("");
  const [limit, setLimit] = useState("");
  const [rows, setRows] = useState<BudgetRow[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [customCurrencies, setCustomCurrencies] = useState<CurrencyDefinition[]>([]);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(monthKey)) { setError(t(language, "invalidDate")); return; }
    const [budgets, expenseCategories, customs] = await Promise.all([listBudgets(monthKey, currency), listCategories("expense"), readSetting<CurrencyDefinition[]>("customCurrencies", [])]);
    setRows(budgets); setCategories(expenseCategories); setCustomCurrencies(customs); setCategoryId((value) => value || expenseCategories[0]?.id || ""); setError("");
  }, [monthKey, currency, language]);
  useEffect(() => { void load().catch(() => setError(t(language, "genericError"))); }, [load, refreshKey, language]);

  const save = async () => {
    const amountMinor = decimalToMinorUnits(limit, fractionDigitsFor(currency, customCurrencies));
    if (!categoryId || !/^\d{4}-(0[1-9]|1[0-2])$/.test(monthKey)) { setError(t(language, "invalidDate")); return; }
    if (!amountMinor || BigInt(amountMinor) <= 0n) { setError(t(language, "invalidAmount")); return; }
    setBusy(true); setError("");
    try { await addBudget({ id: Crypto.randomUUID(), monthKey, categoryId, limitMinor: amountMinor, currency }); setLimit(""); await refresh(); await load(); }
    catch { setError(t(language, "genericError")); }
    finally { setBusy(false); }
  };

  const remove = (budget: BudgetRow) => Alert.alert(t(language, "delete"), t(language, "deleteConfirm"), [
    { text: t(language, "cancel"), style: "cancel" },
    { text: t(language, "delete"), style: "destructive", onPress: () => { void deleteBudget(budget.id).then(load).catch(() => setError(t(language, "genericError"))); } },
  ]);

  return <Page title={t(language, "budgets")} subtitle={t(language, "noBudgetsDetail")}>
    <Field label={t(language, "budgetMonth")} value={monthKey} onChangeText={setMonthKey} autoCapitalize="none" placeholder="YYYY-MM" />
    <Text style={[styles.label, { color: colors.ink }]}>{t(language, "currency")}</Text>
    <View style={styles.pills}>{[...DEFAULT_CURRENCIES, ...customCurrencies].map((item) => <Pill key={item.code} title={item.code} selected={currency === item.code} onPress={() => setCurrency(item.code)} />)}</View>
    <Card>
      <Text style={[styles.label, { color: colors.ink }]}>{t(language, "category")}</Text>
      <View style={styles.pills}>{categories.map((item) => <Pill key={item.id} title={item.name} selected={categoryId === item.id} onPress={() => setCategoryId(item.id)} />)}</View>
      <Field label={t(language, "budgetLimit")} value={limit} onChangeText={setLimit} keyboardType="decimal-pad" />
      <Button title={busy ? "…" : t(language, "setBudget")} disabled={busy || !categoryId} onPress={() => void save()} />
    </Card>
    {error ? <Text accessibilityRole="alert" style={{ color: colors.red }}>{error}</Text> : null}
    {rows.length ? rows.map((budget) => {
      const category = categories.find((item) => item.id === budget.categoryId);
      const limitMinor = BigInt(budget.limitMinor), spentMinor = BigInt(budget.spentMinor);
      const percentage = limitMinor > 0n ? Number(spentMinor * 100n / limitMinor) : 0;
      const exceeded = spentMinor > limitMinor;
      return <Card key={budget.id}>
        <View style={styles.row}><Text style={[styles.category, { color: colors.ink }]}>{category?.name ?? budget.categoryId}</Text><Text style={[styles.category, { color: exceeded ? colors.red : colors.emerald }]}>{exceeded ? t(language, "overBudget") : `${Math.min(100, percentage)}%`}</Text></View>
        <View style={[styles.track, { backgroundColor: colors.line }]}><View style={[styles.fill, { width: `${Math.min(100, Math.max(0, percentage))}%`, backgroundColor: exceeded ? colors.red : colors.emerald }]} /></View>
        <Text style={[styles.detail, { color: colors.inkMuted }]}>{t(language, "spent")}: {formatMoney(budget.spentMinor, currencyDefinitionFor(currency, customCurrencies), localeFor(language))} · {t(language, "budgetLimit")}: {formatMoney(budget.limitMinor, currencyDefinitionFor(currency, customCurrencies), localeFor(language))}</Text>
        <Button title={t(language, "delete")} variant="danger" onPress={() => remove(budget)} style={styles.delete} />
      </Card>;
    }) : <Card><Text style={[styles.category, { color: colors.ink }]}>{t(language, "noBudgets")}</Text><Text style={[styles.detail, { color: colors.inkMuted }]}>{t(language, "noBudgetsDetail")}</Text></Card>}
  </Page>;
}
const styles = StyleSheet.create({ label: { fontSize: 13, fontWeight: "800" }, pills: { flexDirection: "row", flexWrap: "wrap", gap: 8 }, row: { flexDirection: "row", justifyContent: "space-between" }, category: { fontSize: 14, fontWeight: "800" }, track: { height: 8, borderRadius: 5, overflow: "hidden" }, fill: { height: 8, borderRadius: 5 }, detail: { fontSize: 12, lineHeight: 18 }, delete: { alignSelf: "flex-end", minHeight: 36, paddingVertical: 5, paddingHorizontal: 12 }, });
