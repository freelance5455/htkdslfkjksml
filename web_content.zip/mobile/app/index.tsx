import { ActivityIndicator, StyleSheet, Text, View } from "react-native";
import { Redirect } from "expo-router";
import { t } from "../src/i18n";
import { useFinance } from "../src/shared/MobileProvider";
import { Page } from "../src/shared/ui";

export default function IndexRoute() {
  const { ready, error, onboardingComplete, language, colors } = useFinance();
  if (error) return <Page title={t(language, "setupError")}><View style={[styles.error, { backgroundColor: colors.redSoft }]}><Text style={[styles.errorText, { color: colors.red }]}>{t(language, "secureBuildRequired")}</Text></View></Page>;
  if (!ready) return <View style={[styles.loading, { backgroundColor: colors.canvas }]}><ActivityIndicator color={colors.emerald} /><Text style={{ color: colors.inkMuted }}>{t(language, "loading")}</Text></View>;
  return onboardingComplete ? <Redirect href="/(tabs)" /> : <Redirect href="/onboarding" />;
}

const styles = StyleSheet.create({
  loading: { flex: 1, alignItems: "center", justifyContent: "center", gap: 12 },
  error: { borderRadius: 16, padding: 18, marginTop: 18 }, errorText: { fontSize: 14, lineHeight: 21 },
});
