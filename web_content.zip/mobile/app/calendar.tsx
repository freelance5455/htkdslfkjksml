import { useCallback, useState } from "react";
import { Alert, StyleSheet, Text, View } from "react-native";
import * as Crypto from "expo-crypto";
import { useFocusEffect } from "expo-router";
import { calendarEventsForMonth, type CalendarEvent } from "../src/domain/calendar";
import { toLocalDateKey, isDateKey } from "../src/domain/dates";
import { nextReminderOccurrence } from "../src/domain/reminders";
import { currencyDefinitionFor, formatMoney, type CurrencyDefinition } from "../src/domain/money";
import { addImportantDate, deleteImportantDate, listBills, listDebts, listImportantDates, readSetting } from "../src/db/repository";
import { cancelEntityReminders, scheduleEntityReminders } from "../src/features/localReminders";
import { localeFor, t } from "../src/i18n";
import { Button, Card, Field, Heading, Page, Pill } from "../src/shared/ui";
import { useFinance } from "../src/shared/MobileProvider";

export default function CalendarScreen() {
  const { language, colors, refreshKey, refresh } = useFinance();
  const [monthKey, setMonthKey] = useState(toLocalDateKey().slice(0, 7));
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [currencies, setCurrencies] = useState<CurrencyDefinition[]>([]);
  const [title, setTitle] = useState("");
  const [dateKey, setDateKey] = useState(toLocalDateKey());
  const [note, setNote] = useState("");
  const [yearly, setYearly] = useState(false);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(monthKey)) { setError(t(language, "invalidDate")); return; }
    const [bills, debts, dates, custom] = await Promise.all([listBills(), listDebts(), listImportantDates(), readSetting<CurrencyDefinition[]>("customCurrencies", [])]);
    setEvents(calendarEventsForMonth({ monthKey, bills, debts, dates })); setCurrencies(custom); setError("");
  }, [monthKey, language]);
  useFocusEffect(useCallback(() => { let active = true; void load().catch(() => { if (active) setError(t(language, "genericError")); }); return () => { active = false; }; }, [load, refreshKey, language]));

  const addDate = async () => {
    if (!title.trim()) { setError(t(language, "required")); return; }
    if (!isDateKey(dateKey)) { setError(t(language, "invalidDate")); return; }
    setError("");
    const id = Crypto.randomUUID();
    try {
      await addImportantDate({ id, title: title.trim(), dateKey, repeatsYearly: yearly, note: note.trim(), isDemo: false, reminderOffsets: [3, 1, 0] });
      const nextDate = nextReminderOccurrence(dateKey, yearly);
      let permitted = true;
      if (nextDate) { try { permitted = await scheduleEntityReminders({ entityId: id, kind: "date", dueDate: nextDate, offsets: [3, 1, 0], language }); } catch { permitted = false; } }
      if (!permitted) Alert.alert(t(language, "reminderPermission"), t(language, "remindersOff"));
      setTitle(""); setNote(""); setYearly(false); await refresh(); await load();
    } catch { setError(t(language, "genericError")); }
  };

  const removeDate = (event: CalendarEvent) => Alert.alert(t(language, "delete"), t(language, "deleteConfirm"), [
    { text: t(language, "cancel"), style: "cancel" },
    { text: t(language, "delete"), style: "destructive", onPress: () => { void deleteImportantDate(event.sourceId).then(() => cancelEntityReminders(event.sourceId)).then(load).catch(() => setError(t(language, "genericError"))); } },
  ]);

  const typeLabel = (event: CalendarEvent) => event.type === "bill" ? t(language, "bills") : event.type === "debt" ? t(language, "debts") : t(language, "importantDates");
  return <Page title={t(language, "calendar")} subtitle={t(language, "noCalendarDetail")}>
    <Field label={t(language, "budgetMonth")} value={monthKey} onChangeText={setMonthKey} autoCapitalize="none" placeholder="YYYY-MM" />
    <Card>
      <Heading>{t(language, "importantDates")}</Heading>
      <Field label={t(language, "dateTitle")} value={title} onChangeText={setTitle} maxLength={80} />
      <Field label={t(language, "date")} value={dateKey} onChangeText={setDateKey} autoCapitalize="none" placeholder="YYYY-MM-DD" />
      <Field label={t(language, "note")} value={note} onChangeText={setNote} maxLength={160} />
      <Pill title={t(language, "repeatYearly")} selected={yearly} onPress={() => setYearly((value) => !value)} />
      <Text style={[styles.note, { color: colors.inkMuted }]}>{t(language, "reminderPermission")}</Text>
      <Button title={t(language, "save")} onPress={() => void addDate()} />
    </Card>
    {error ? <Text accessibilityRole="alert" style={{ color: colors.red }}>{error}</Text> : null}
    {events.length ? <>
      <Heading>{monthKey} · {events.length}</Heading>
      {events.map((event) => <Card key={event.id}>
        <View style={styles.row}><View style={{ flex: 1, gap: 3 }}><Text style={[styles.title, { color: colors.ink }]}>{event.title}{event.isDemo ? ` · ${t(language, "demo")}` : ""}</Text><Text style={[styles.detail, { color: colors.inkMuted }]}>{event.dateKey} · {typeLabel(event)}</Text></View>
          {event.amountMinor && event.currency ? <Text style={[styles.amount, { color: colors.ink }]}>{formatMoney(event.amountMinor, currencyDefinitionFor(event.currency, currencies), localeFor(language))}</Text> : null}</View>
        {event.type === "important" ? <Button title={t(language, "delete")} variant="danger" onPress={() => removeDate(event)} style={styles.delete} /> : null}
      </Card>)}
    </> : <Card><Text style={[styles.title, { color: colors.ink }]}>{t(language, "noCalendar")}</Text><Text style={[styles.detail, { color: colors.inkMuted }]}>{t(language, "noCalendarDetail")}</Text></Card>}
  </Page>;
}
const styles = StyleSheet.create({ row: { flexDirection: "row", gap: 10, alignItems: "center" }, title: { fontSize: 14, fontWeight: "800" }, detail: { fontSize: 12 }, amount: { fontSize: 12, fontWeight: "800" }, note: { fontSize: 12, lineHeight: 18 }, delete: { minHeight: 34, paddingHorizontal: 10, paddingVertical: 4, alignSelf: "flex-end" }, });
