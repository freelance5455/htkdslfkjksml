import { StyleSheet, Text } from "react-native";
import { useRouter } from "expo-router";
import { t } from "../src/i18n";
import { useFinance } from "../src/shared/MobileProvider";
import { Button, Card, Heading, Page } from "../src/shared/ui";

export default function BackupScreen() {
  const router = useRouter();
  const { language, colors } = useFinance();
  return <Page title={t(language, "backup")} subtitle={t(language, "backupStatus")}>
    <Card>
      <Heading>{t(language, "backupUnavailable")}</Heading>
      <Text style={[styles.risk, { color: colors.red }]}>{t(language, "backupRisk")}</Text>
      <Text style={[styles.body, { color: colors.inkMuted }]}>{t(language, "backupNoUpload")}</Text>
      <Button title={t(language, "settings")} variant="secondary" onPress={() => router.push("/settings")} />
    </Card>
    <Card>
      <Heading>{t(language, "author")}</Heading>
      <Text style={[styles.body, { color: colors.inkMuted }]}>{t(language, "backupOwnerSteps")}</Text>
      <Text style={[styles.body, { color: colors.inkMuted }]}>{t(language, "noCloud")}</Text>
    </Card>
  </Page>;
}
const styles = StyleSheet.create({ body: { fontSize: 14, lineHeight: 22 }, risk: { fontSize: 15, fontWeight: "800", lineHeight: 22 } });
