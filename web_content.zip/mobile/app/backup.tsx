import { useState } from "react";
import { Alert, StyleSheet, Text } from "react-native";
import * as DocumentPicker from "expo-document-picker";
import { File, Paths } from "expo-file-system";
import * as Sharing from "expo-sharing";
import { decryptBackupPayload, encryptBackupPayload, BACKUP_MAX_FILE_CHARACTERS, BACKUP_PASSPHRASE_MIN_LENGTH } from "../src/features/backupCrypto";
import { createPortableBackupSnapshot, restorePortableBackupSnapshot } from "../src/db/backupRepository";
import { readSetting } from "../src/db/repository";
import { cancelAllLocalReminders, rescheduleAllLocalReminders } from "../src/features/localReminders";
import { t, type AppLanguage } from "../src/i18n";
import { useFinance, type ThemeMode } from "../src/shared/MobileProvider";
import { Button, Card, Field, Heading, Page } from "../src/shared/ui";

function errorMessage(error: unknown, language: AppLanguage): string {
  const code = error instanceof Error ? error.message : "";
  if (code === "BACKUP_PASSPHRASE_WEAK") return t(language, "backupPasswordWeak");
  if (code === "BACKUP_PASSWORD_OR_FILE_INVALID" || code === "BACKUP_FILE_INVALID" || code === "BACKUP_SCHEMA_UNAVAILABLE") return t(language, "backupWrongPassword");
  if (code === "BACKUP_FILE_TOO_LARGE" || code === "BACKUP_TOO_MANY_RECORDS") return t(language, "backupFileTooLarge");
  return t(language, "genericError");
}

export default function BackupScreen() {
  const { language, currency, themeMode, colors, setLanguage, setCurrency, setThemeMode, refresh } = useFinance();
  const [passphrase, setPassphrase] = useState("");
  const [confirmPassphrase, setConfirmPassphrase] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  const createBackup = async () => {
    if (passphrase.length < BACKUP_PASSPHRASE_MIN_LENGTH) {
      Alert.alert(t(language, "backupPasswordWeak"));
      return;
    }
    if (passphrase !== confirmPassphrase) {
      Alert.alert(t(language, "backupPasswordMismatch"));
      return;
    }
    setBusy(true);
    setMessage("");
    try {
      const snapshot = await createPortableBackupSnapshot();
      const encrypted = await encryptBackupPayload(snapshot, passphrase);
      if (!(await Sharing.isAvailableAsync())) throw new Error("SHARING_UNAVAILABLE");
      const file = new File(Paths.cache, `tolovchi-backup-${Date.now()}.tlvbackup`);
      file.create({ overwrite: true });
      await file.write(encrypted);
      await Sharing.shareAsync(file.uri, {
        mimeType: "application/octet-stream",
        dialogTitle: t(language, "backupCreate"),
      });
      setMessage(t(language, "backupExported"));
    } catch (error) {
      Alert.alert(errorMessage(error, language));
    } finally {
      setPassphrase("");
      setConfirmPassphrase("");
      setBusy(false);
    }
  };

  const restoreFile = async (uri: string) => {
    setBusy(true);
    setMessage("");
    let notificationsCancelled = false;
    try {
      const sourceFile = new File(uri);
      if (sourceFile.size > BACKUP_MAX_FILE_CHARACTERS) throw new Error("BACKUP_FILE_TOO_LARGE");
      const encrypted = await sourceFile.text();
      if (encrypted.length > BACKUP_MAX_FILE_CHARACTERS) throw new Error("BACKUP_FILE_TOO_LARGE");
      const snapshot = await decryptBackupPayload(encrypted, passphrase);
      await cancelAllLocalReminders();
      notificationsCancelled = true;
      await restorePortableBackupSnapshot(snapshot);

      const savedLanguage = await readSetting<string>("language", language);
      const nextLanguage: AppLanguage = savedLanguage === "uz" || savedLanguage === "ru" || savedLanguage === "en" ? savedLanguage : language;
      const savedTheme = await readSetting<string>("themeMode", themeMode);
      const nextTheme: ThemeMode = savedTheme === "light" || savedTheme === "dark" || savedTheme === "system" ? savedTheme : themeMode;
      const savedCurrency = await readSetting<string>("preferredCurrency", currency);
      const nextCurrency = /^[A-Za-z0-9_-]{3,12}$/.test(savedCurrency) ? savedCurrency : currency;
      await setLanguage(nextLanguage);
      await setCurrency(nextCurrency);
      await setThemeMode(nextTheme);
      await rescheduleAllLocalReminders(nextLanguage);
      refresh();
      setMessage(t(nextLanguage, "backupRestored"));
    } catch (error) {
      if (notificationsCancelled) await rescheduleAllLocalReminders(language).catch(() => {});
      Alert.alert(errorMessage(error, language));
    } finally {
      setPassphrase("");
      setConfirmPassphrase("");
      setBusy(false);
    }
  };

  const chooseBackup = async () => {
    if (passphrase.length < BACKUP_PASSPHRASE_MIN_LENGTH) {
      Alert.alert(t(language, "backupPasswordWeak"));
      return;
    }
    try {
      const result = await DocumentPicker.getDocumentAsync({ type: "*/*", copyToCacheDirectory: true });
      if (result.canceled || !result.assets[0]) return;
      const asset = result.assets[0];
      if (asset.size !== undefined && asset.size > BACKUP_MAX_FILE_CHARACTERS) {
        Alert.alert(t(language, "backupFileTooLarge"));
        return;
      }
      Alert.alert(t(language, "backupReplaceConfirmTitle"), `${t(language, "backupReplaceConfirmBody")}\n\n${asset.name.slice(0, 100)}`, [
        { text: t(language, "cancel"), style: "cancel" },
        { text: t(language, "backupRestore"), style: "destructive", onPress: () => void restoreFile(asset.uri) },
      ]);
    } catch (error) {
      Alert.alert(errorMessage(error, language));
    }
  };

  return <Page title={t(language, "backup")} subtitle={t(language, "backupStatus")}>
    <Card>
      <Heading>{t(language, "backupCreate")}</Heading>
      <Text style={[styles.body, { color: colors.inkMuted }]}>{t(language, "backupPasswordHint")}</Text>
      <Field label={t(language, "backupPassphrase")} value={passphrase} onChangeText={setPassphrase} secureTextEntry autoCapitalize="none" autoCorrect={false} maxLength={256} />
      <Field label={t(language, "backupPassphraseConfirm")} value={confirmPassphrase} onChangeText={setConfirmPassphrase} secureTextEntry autoCapitalize="none" autoCorrect={false} maxLength={256} />
      <Button title={t(language, "backupCreate")} onPress={() => void createBackup()} disabled={busy} />
    </Card>
    <Card>
      <Heading>{t(language, "backupRestore")}</Heading>
      <Text style={[styles.body, { color: colors.inkMuted }]}>{t(language, "backupReplaceConfirmBody")}</Text>
      <Button title={t(language, "backupRestore")} variant="secondary" onPress={() => void chooseBackup()} disabled={busy} />
    </Card>
    {busy ? <Text style={[styles.body, { color: colors.inkMuted }]}>{t(language, "backupBusy")}</Text> : null}
    {message ? <Text accessibilityRole="status" style={[styles.message, { color: colors.emerald }]}>{message}</Text> : null}
    <Card>
      <Heading>{t(language, "author")}</Heading>
      <Text style={[styles.body, { color: colors.inkMuted }]}>{t(language, "backupOwnerSteps")}</Text>
      <Text style={[styles.body, { color: colors.red }]}>{t(language, "backupRisk")}</Text>
    </Card>
  </Page>;
}

const styles = StyleSheet.create({ body: { fontSize: 14, lineHeight: 22 }, message: { fontSize: 14, fontWeight: "800", lineHeight: 22 } });
