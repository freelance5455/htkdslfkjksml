import { useState } from "react";
import { Image, StyleSheet, Text, View } from "react-native";
import { useRouter } from "expo-router";
import { Button, Card, Field, Page, Pill } from "../src/shared/ui";
import { useFinance } from "../src/shared/MobileProvider";
import { t, supportedLanguages, type AppLanguage } from "../src/i18n";
import { DEFAULT_CURRENCIES, fractionDigitsFor } from "../src/domain/money";
import { addFictionalSampleData } from "../src/features/sampleData";

const onboardingCurrencies = DEFAULT_CURRENCIES.map((item) => item.code);

export default function OnboardingScreen() {
  const router = useRouter();
  const { language: savedLanguage, currency: savedCurrency, colors, completeOnboarding, createPin } = useFinance();
  const [language, setLanguage] = useState<AppLanguage>(savedLanguage);
  const [currency, setCurrency] = useState(savedCurrency);
  const [pin, setPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const begin = async (withSampleData: boolean) => {
    setError("");
    if ((pin || confirmPin) && (!/^\d{6,12}$/.test(pin) || pin !== confirmPin)) {
      setError(t(language, "onboardingPinError"));
      return;
    }
    setBusy(true);
    try {
      if (pin) await createPin(pin);
      if (withSampleData) await addFictionalSampleData(currency, fractionDigitsFor(currency));
      await completeOnboarding(language, currency);
      router.replace("/(tabs)");
    } catch {
      setError(t(language, "genericError"));
    } finally {
      setBusy(false);
    }
  };

  return <Page title={t(language, "onboardingTitle")} subtitle={t(language, "onboardingSubtitle")}>
    <View style={styles.brandRow}>
      <Image accessibilityLabel={t(language, "appName")} source={require("../assets/images/icon.png")} style={styles.icon} />
      <View style={styles.brandCopy}>
        <Text style={[styles.brandName, { color: colors.ink }]}>{t(language, "appName")}</Text>
        <Text style={[styles.brandSub, { color: colors.inkMuted }]}>{t(language, "offline")}</Text>
      </View>
    </View>
    <Card>
      <Text style={[styles.cardTitle, { color: colors.ink }]}>{t(language, "chooseLanguage")}</Text>
      <View style={styles.pills}>{supportedLanguages.map((item) => <Pill key={item} title={item.toUpperCase()} selected={language === item} onPress={() => setLanguage(item)} />)}</View>
      <Text style={[styles.cardTitle, { color: colors.ink }]}>{t(language, "chooseCurrency")}</Text>
      <View style={styles.pills}>{onboardingCurrencies.map((item) => <Pill key={item} title={item} selected={currency === item} onPress={() => setCurrency(item)} />)}</View>
    </Card>
    <Card>
      <Text style={[styles.cardTitle, { color: colors.ink }]}>{t(language, "pinLabel")}</Text>
      <Text style={[styles.info, { color: colors.inkMuted }]}>{t(language, "pinHint")}</Text>
      <Field label={t(language, "pinNew")} value={pin} onChangeText={(value) => setPin(value.replace(/\D/g, "").slice(0, 12))} keyboardType="number-pad" secureTextEntry autoComplete="off" maxLength={12} />
      <Field label={t(language, "pinCurrent")} value={confirmPin} onChangeText={(value) => setConfirmPin(value.replace(/\D/g, "").slice(0, 12))} keyboardType="number-pad" secureTextEntry autoComplete="off" maxLength={12} />
      <Text style={[styles.info, { color: colors.inkMuted }]}>{t(language, "onboardingStorage")}</Text>
    </Card>
    {error ? <Text accessibilityRole="alert" style={[styles.error, { color: colors.red }]}>{error}</Text> : null}
    <Button title={busy ? "…" : t(language, "startEmpty")} disabled={busy} onPress={() => void begin(false)} />
    <Button title={t(language, "useSample")} variant="secondary" disabled={busy} onPress={() => void begin(true)} />
    <Text style={[styles.disclaimer, { color: colors.inkMuted }]}>{t(language, "sampleWarning")}</Text>
  </Page>;
}

const styles = StyleSheet.create({
  brandRow: { flexDirection: "row", alignItems: "center", gap: 14, marginBottom: 4 }, icon: { width: 54, height: 54, borderRadius: 15 },
  brandCopy: { flex: 1, gap: 2 }, brandName: { fontSize: 18, fontWeight: "900", letterSpacing: 0.2 }, brandSub: { fontSize: 12 },
  cardTitle: { fontSize: 14, fontWeight: "800", marginTop: 3 }, info: { fontSize: 13, lineHeight: 19 }, pills: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  error: { fontSize: 13, lineHeight: 19, fontWeight: "600" }, disclaimer: { fontSize: 12, lineHeight: 17, textAlign: "center", marginHorizontal: 12 },
});
