import { useCallback, useMemo, useState } from "react";
import { Alert, Linking, StyleSheet, Switch, Text, View } from "react-native";
import Constants from "expo-constants";
import { useFocusEffect } from "expo-router";
import { DEFAULT_CURRENCIES, convertMinorUnits, currencyDefinitionFor, decimalToMinorUnits, formatMoney, fractionDigitsFor, type CurrencyDefinition } from "../src/domain/money";
import { toLocalDateKey } from "../src/domain/dates";
import { deleteManualFxRate, findManualFxRate, listManualFxRates, saveManualFxRate, type ManualFxRate } from "../src/db/fxRepository";
import { clearSampleData, countCustomerRecords, deleteAllCustomerRecords, readSetting, writeSetting } from "../src/db/repository";
import { cancelAllLocalReminders, rescheduleAllLocalReminders, setLocalRemindersEnabled } from "../src/features/localReminders";
import { localeFor, t, type AppLanguage } from "../src/i18n";
import type { ThemeMode } from "../src/shared/MobileProvider";
import { useFinance } from "../src/shared/MobileProvider";
import { Button, Card, Field, Heading, Page, Pill } from "../src/shared/ui";

const languages: AppLanguage[] = ["uz", "ru", "en"];
const themes: ThemeMode[] = ["system", "light", "dark"];

export default function SettingsScreen() {
  const { language, currency, themeMode, colors, hasPin, biometricEnabled, setLanguage, setCurrency, setThemeMode, createPin, changePin, removePin, setBiometric, refresh } = useFinance();
  const [customCurrencies, setCustomCurrencies] = useState<CurrencyDefinition[]>([]);
  const [rates, setRates] = useState<ManualFxRate[]>([]);
  const [localReminders, setLocalReminders] = useState(true);
  const [permissionGranted, setPermissionGranted] = useState(false);
  const [customCode, setCustomCode] = useState("");
  const [customName, setCustomName] = useState("");
  const [customSymbol, setCustomSymbol] = useState("");
  const [customDigits, setCustomDigits] = useState("2");
  const [base, setBase] = useState("USD");
  const [quote, setQuote] = useState("UZS");
  const [numerator, setNumerator] = useState("");
  const [denominator, setDenominator] = useState("1");
  const [rateDate, setRateDate] = useState(toLocalDateKey());
  const [convertAmount, setConvertAmount] = useState("1");
  const [converted, setConverted] = useState("");
  const [currentPin, setCurrentPin] = useState("");
  const [newPin, setNewPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");
  const [recordCount, setRecordCount] = useState(0);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const allCurrencies = useMemo(() => [...DEFAULT_CURRENCIES, ...customCurrencies], [customCurrencies]);

  useFocusEffect(useCallback(() => {
    let active = true;
    void Promise.all([readSetting<CurrencyDefinition[]>("customCurrencies", []), readSetting<boolean>("localRemindersEnabled", true), listManualFxRates(), countCustomerRecords()])
      .then(async ([custom, enabled, currentRates, count]) => {
        const { getPermissionsAsync } = await import("expo-notifications");
        const permissions = await getPermissionsAsync();
        if (!active) return;
        setCustomCurrencies(custom); setLocalReminders(enabled); setRates(currentRates); setRecordCount(count); setPermissionGranted(permissions.granted);
      }).catch(() => { if (active) setError(t(language, "genericError")); });
    return () => { active = false; };
  }, [language, refresh]));

  const notify = (text: string) => { setMessage(text); setError(""); };
  const fail = (text = t(language, "genericError")) => { setError(text); setMessage(""); };
  const saveCustomCurrency = async () => {
    const code = customCode.trim().toUpperCase(), digits = Number(customDigits);
    if (!/^[A-Z0-9_-]{3,12}$/.test(code) || !customName.trim() || !customSymbol.trim() || !Number.isInteger(digits) || digits < 0 || digits > 6) { fail(t(language, "invalidAmount")); return; }
    if (allCurrencies.some((item) => item.code === code)) { fail(t(language, "required")); return; }
    const next = [...customCurrencies, { code, name: customName.trim().slice(0, 60), symbol: customSymbol.trim().slice(0, 12), fractionDigits: digits }];
    try { await writeSetting("customCurrencies", next); setCustomCurrencies(next); setCustomCode(""); setCustomName(""); setCustomSymbol(""); setCustomDigits("2"); notify(t(language, "save")); } catch { fail(); }
  };
  const saveRate = async () => {
    try { await saveManualFxRate({ baseCurrency: base, quoteCurrency: quote, numerator, denominator, effectiveDate: rateDate }); setRates(await listManualFxRates()); setNumerator(""); notify(t(language, "saveRate")); }
    catch { fail(t(language, "invalidAmount")); }
  };
  const removeRate = (id: string) => Alert.alert(t(language, "delete"), t(language, "deleteConfirm"), [
    { text: t(language, "cancel"), style: "cancel" },
    { text: t(language, "delete"), style: "destructive", onPress: () => { void deleteManualFxRate(id).then(async () => { setRates(await listManualFxRates()); setConverted(""); }).catch(() => fail()); } },
  ]);
  const convert = async () => {
    const fromDigits = fractionDigitsFor(base, allCurrencies), toDigits = fractionDigitsFor(quote, allCurrencies), amount = decimalToMinorUnits(convertAmount, fromDigits);
    if (amount === null) { fail(t(language, "invalidAmount")); return; }
    try {
      const rate = await findManualFxRate(base, quote, toLocalDateKey());
      if (!rate) { setConverted(""); fail(t(language, "conversionUnavailable")); return; }
      setConverted(formatMoney(convertMinorUnits(amount, fromDigits, toDigits, rate.numerator, rate.denominator), currencyDefinitionFor(quote, customCurrencies), localeFor(language)));
      setError(""); setMessage("");
    } catch { fail(t(language, "conversionUnavailable")); }
  };
  const savePin = async () => {
    if (!/^\d{6,12}$/.test(newPin) || newPin !== confirmPin) { fail(t(language, "invalidAmount")); return; }
    setBusy(true);
    try {
      if (hasPin) { if (!currentPin || !(await changePin(currentPin, newPin))) { fail(t(language, "pinCurrent")); return; } }
      else await createPin(newPin);
      setCurrentPin(""); setNewPin(""); setConfirmPin(""); notify(t(language, "save"));
    } catch (cause) { fail(cause instanceof Error ? cause.message : t(language, "genericError")); }
    finally { setBusy(false); }
  };
  const turnOffPin = () => {
    if (!currentPin) { fail(t(language, "pinCurrent")); return; }
    setBusy(true);
    void removePin(currentPin).then((success) => { if (!success) fail(t(language, "pinCurrent")); else { setCurrentPin(""); setNewPin(""); setConfirmPin(""); notify(t(language, "save")); } }).catch(() => fail()).finally(() => setBusy(false));
  };
  const toggleBiometric = async (enabled: boolean) => { try { await setBiometric(enabled); } catch { fail(t(language, "biometricUnavailable")); } };
  const toggleReminders = async (enabled: boolean) => {
    setBusy(true);
    try { const result = await setLocalRemindersEnabled(enabled, language); if (!result) { fail(t(language, "remindersOff")); return; } setLocalReminders(enabled); setPermissionGranted(enabled); notify(t(language, "save")); }
    catch { fail(t(language, "remindersOff")); } finally { setBusy(false); }
  };
  const rebuildReminders = async () => { setBusy(true); try { await rescheduleAllLocalReminders(language); notify(t(language, "rebuildReminders")); } catch { fail(); } finally { setBusy(false); } };
  const clearExamples = () => Alert.alert(t(language, "deleteDemo"), t(language, "sampleWarning"), [
    { text: t(language, "cancel"), style: "cancel" },
    { text: t(language, "deleteDemo"), style: "destructive", onPress: () => { void (async () => { setBusy(true); try { await cancelAllLocalReminders(); await clearSampleData(); await rescheduleAllLocalReminders(language); refresh(); setRecordCount(await countCustomerRecords()); notify(t(language, "demoCleared")); } catch { fail(); } finally { setBusy(false); } })(); } },
  ]);
  const resetAll = () => Alert.alert(t(language, "resetRecords"), t(language, "resetWarning"), [
    { text: t(language, "cancel"), style: "cancel" },
    { text: t(language, "deleteAll"), style: "destructive", onPress: () => { void (async () => { setBusy(true); try { await cancelAllLocalReminders(); await deleteAllCustomerRecords(); refresh(); setRecordCount(0); notify(t(language, "recordsDeleted")); } catch { fail(); } finally { setBusy(false); } })(); } },
  ]);
  const contactSupport = async () => {
    const email = String(Constants.expoConfig?.extra?.supportEmail ?? "").trim();
    if (!email) { fail(t(language, "supportUnavailable")); return; }
    try { await Linking.openURL(`mailto:${encodeURIComponent(email)}?subject=${encodeURIComponent("TO‘LOVCHI support")}`); } catch { fail(t(language, "supportUnavailable")); }
  };

  return <Page title={t(language, "settings")} subtitle={t(language, "privacyNote")}>
    <Card>
      <Heading>{t(language, "preferences")}</Heading>
      <Text style={{ color: colors.inkMuted }}>{t(language, "language")}</Text>
      <View style={styles.pills}>{languages.map((item) => <Pill key={item} title={item.toUpperCase()} selected={language === item} onPress={() => void setLanguage(item)} />)}</View>
      <Text style={{ color: colors.inkMuted }}>{t(language, "theme")}</Text>
      <View style={styles.pills}>{themes.map((item) => <Pill key={item} title={t(language, item === "system" ? "themeSystem" : item === "light" ? "themeLight" : "themeDark")} selected={themeMode === item} onPress={() => void setThemeMode(item)} />)}</View>
      <Text style={{ color: colors.inkMuted }}>{t(language, "homeCurrency")}</Text>
      <View style={styles.pills}>{allCurrencies.map((item) => <Pill key={item.code} title={item.code} selected={currency === item.code} onPress={() => void setCurrency(item.code)} />)}</View>
      <Text style={[styles.version, { color: colors.inkMuted }]}>{t(language, "version")}: {Constants.expoConfig?.version ?? "1.0.0"}</Text>
    </Card>
    <Card>
      <Heading>{t(language, "customCurrency")}</Heading>
      <Field label={t(language, "currencyCode")} value={customCode} onChangeText={setCustomCode} autoCapitalize="characters" maxLength={12} />
      <Field label={t(language, "currencyName")} value={customName} onChangeText={setCustomName} maxLength={60} />
      <Field label={t(language, "currencySymbol")} value={customSymbol} onChangeText={setCustomSymbol} maxLength={12} />
      <Field label={t(language, "fractionDigits")} value={customDigits} onChangeText={setCustomDigits} keyboardType="number-pad" maxLength={1} />
      <Button title={t(language, "customCurrency")} onPress={() => void saveCustomCurrency()} />
      {customCurrencies.map((item) => <Text key={item.code} style={{ color: colors.ink }}>{item.code} · {item.name} · {item.fractionDigits} {t(language, "fractionDigits")}</Text>)}
    </Card>
    <Card>
      <Heading>{t(language, "manualRates")}</Heading>
      <Text style={[styles.hint, { color: colors.inkMuted }]}>{t(language, "ratesNote")} {t(language, "rateFormat")}</Text>
      <View style={styles.pills}>{allCurrencies.map((item) => <Pill key={`base-${item.code}`} title={item.code} selected={base === item.code} onPress={() => setBase(item.code)} />)}</View>
      <Text style={{ color: colors.inkMuted }}>{t(language, "baseCurrency")}: {base}</Text>
      <View style={styles.pills}>{allCurrencies.filter((item) => item.code !== base).map((item) => <Pill key={`quote-${item.code}`} title={item.code} selected={quote === item.code} onPress={() => setQuote(item.code)} />)}</View>
      <Text style={{ color: colors.inkMuted }}>{t(language, "quoteCurrency")}: {quote}</Text>
      <Field label={t(language, "rateNumerator")} value={numerator} onChangeText={setNumerator} keyboardType="number-pad" />
      <Field label={t(language, "rateDenominator")} value={denominator} onChangeText={setDenominator} keyboardType="number-pad" />
      <Field label={t(language, "effectiveDate")} value={rateDate} onChangeText={setRateDate} />
      <Button title={t(language, "saveRate")} onPress={() => void saveRate()} />
      {rates.map((rate) => <View key={rate.id} style={styles.rateRow}><Text style={[styles.rateText, { color: colors.ink }]}>{rate.baseCurrency} → {rate.quoteCurrency}: {rate.numerator}/{rate.denominator} · {rate.effectiveDate}</Text><Button title={t(language, "delete")} variant="danger" onPress={() => removeRate(rate.id)} /></View>)}
      <Field label={`${t(language, "amount")} (${base})`} value={convertAmount} onChangeText={setConvertAmount} keyboardType="decimal-pad" />
      <Button title={t(language, "conversion")} variant="secondary" onPress={() => void convert()} />
      {converted ? <Text style={[styles.converted, { color: colors.emerald }]}>{converted}</Text> : null}
    </Card>
    <Card>
      <Heading>{t(language, "localRemindersTitle")}</Heading>
      <View style={styles.switchRow}><Text style={[styles.switchLabel, { color: colors.ink }]}>{t(language, "remindersEnabled")}</Text><Switch value={localReminders} onValueChange={(value) => void toggleReminders(value)} disabled={busy} trackColor={{ true: colors.emerald }} /></View>
      <Text style={[styles.hint, { color: colors.inkMuted }]}>{permissionGranted ? t(language, "reminderPermission") : t(language, "remindersOff")}</Text>
      <Button title={t(language, "rebuildReminders")} variant="secondary" onPress={() => void rebuildReminders()} disabled={busy || !localReminders} />
    </Card>
    <Card>
      <Heading>{t(language, "pinSettings")}</Heading><Text style={[styles.hint, { color: colors.inkMuted }]}>{t(language, "lockDelay")}</Text>
      {hasPin ? <Field label={t(language, "pinCurrent")} value={currentPin} onChangeText={setCurrentPin} secureTextEntry keyboardType="number-pad" maxLength={12} /> : null}
      <Field label={t(language, "pinNew")} value={newPin} onChangeText={setNewPin} secureTextEntry keyboardType="number-pad" maxLength={12} />
      <Field label={t(language, "pinNew")} value={confirmPin} onChangeText={setConfirmPin} secureTextEntry keyboardType="number-pad" maxLength={12} />
      <Button title={t(language, hasPin ? "changePin" : "createPin")} onPress={() => void savePin()} disabled={busy} />
      {hasPin ? <><View style={styles.switchRow}><Text style={[styles.switchLabel, { color: colors.ink }]}>{t(language, "biometric")}</Text><Switch value={biometricEnabled} onValueChange={(value) => void toggleBiometric(value)} disabled={busy} trackColor={{ true: colors.emerald }} /></View><Button title={t(language, "removePin")} variant="danger" onPress={turnOffPin} disabled={busy} /></> : null}
    </Card>
    <Card>
      <Heading>{t(language, "privacyTitle")}</Heading><Text style={[styles.hint, { color: colors.inkMuted }]}>{t(language, "privacyBody")} {t(language, "privacyNote")}</Text>
      <Text style={[styles.hint, { color: colors.inkMuted }]}>{t(language, "resetRecords")}: {recordCount}</Text>
      <Button title={t(language, "deleteDemo")} variant="secondary" onPress={clearExamples} disabled={busy} />
      <Button title={t(language, "resetRecords")} variant="danger" onPress={resetAll} disabled={busy} />
    </Card>
    <Card>
      <Heading>{t(language, "support")}</Heading><Text style={[styles.hint, { color: colors.inkMuted }]}>{t(language, "supportUnavailable")}</Text>
      <Button title={t(language, "support")} variant="secondary" onPress={() => void contactSupport()} />
      <Text style={[styles.hint, { color: colors.inkMuted }]}>{t(language, "premiumUnavailable")}</Text>
      <Text style={[styles.hint, { color: colors.inkMuted }]}>{t(language, "adsInfo")}</Text>
      <Text style={[styles.hint, { color: colors.inkMuted }]}>{t(language, "noCloud")}</Text>
    </Card>
    {error ? <Text accessibilityRole="alert" style={{ color: colors.red }}>{error}</Text> : null}
    {message ? <Text style={{ color: colors.emerald, fontWeight: "700" }}>{message}</Text> : null}
  </Page>;
}
const styles = StyleSheet.create({
  pills: { flexDirection: "row", flexWrap: "wrap", gap: 8 }, version: { fontSize: 12, marginTop: 6 }, hint: { fontSize: 12, lineHeight: 18 },
  switchRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 12 }, switchLabel: { flex: 1, fontWeight: "700" },
  rateRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8 }, rateText: { flex: 1, fontSize: 12 }, converted: { fontSize: 18, fontWeight: "900" },
});
