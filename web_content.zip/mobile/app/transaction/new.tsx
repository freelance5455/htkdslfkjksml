import { useEffect, useState } from "react";
import { Alert, StyleSheet, Text, View } from "react-native";
import { Stack, useLocalSearchParams, useRouter } from "expo-router";
import * as Crypto from "expo-crypto";
import { addTransaction, listBudgets, listCategories, readSetting } from "../../src/db/repository";
import { currencyDefinitionFor, decimalToMinorUnits, DEFAULT_CURRENCIES, formatMoney, fractionDigitsFor, type CurrencyDefinition } from "../../src/domain/money";
import { isDateKey, toLocalDateKey } from "../../src/domain/dates";
import type { EntryType } from "../../src/domain/types";
import { localeFor, t } from "../../src/i18n";
import { Button, Card, Field, Page, Pill } from "../../src/shared/ui";
import { useFinance } from "../../src/shared/MobileProvider";

export default function NewTransactionScreen() {
  const router = useRouter();
  const params = useLocalSearchParams<{ kind?: string }>();
  const { language, currency: preferredCurrency, colors, refresh } = useFinance();
  const [kind, setKind] = useState<EntryType>(params.kind === "income" ? "income" : "expense");
  const [currency, setCurrency] = useState(preferredCurrency);
  const [amount, setAmount] = useState("");
  const [categoryId, setCategoryId] = useState("");
  const [dateKey, setDateKey] = useState(toLocalDateKey());
  const [note, setNote] = useState("");
  const [categories, setCategories] = useState<Array<{ id: string; name: string }>>([]);
  const [customCurrencies, setCustomCurrencies] = useState<CurrencyDefinition[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;
    void Promise.all([listCategories(kind), readSetting<CurrencyDefinition[]>("customCurrencies", [])]).then(([items, custom]) => {
      if (!active) return;
      setCategories(items);
      setCategoryId((current) => items.some((item) => item.id === current) ? current : items[0]?.id ?? "");
      setCustomCurrencies(custom);
    }).catch(() => { if (active) setError(t(language, "genericError")); });
    return () => { active = false; };
  }, [kind, language]);

  const availableCurrencies = [...DEFAULT_CURRENCIES, ...customCurrencies];
  const digits = fractionDigitsFor(currency, customCurrencies);
  const save = async () => {
    const amountMinor = decimalToMinorUnits(amount, digits);
    if (!amountMinor || BigInt(amountMinor) <= 0n) { setError(t(language, "invalidAmount")); return; }
    if (!isDateKey(dateKey)) { setError(t(language, "invalidDate")); return; }
    if (!categoryId) { setError(t(language, "required")); return; }
    setBusy(true);
    setError("");
    try {
      await addTransaction({ kind, categoryId, amountMinor, currency, dateKey, note: note.trim(), isDemo: false });
      await refresh();
      if (kind === "expense") {
        const budget = (await listBudgets(dateKey.slice(0, 7), currency)).find((item) => item.categoryId === categoryId);
        if (budget && BigInt(budget.spentMinor) > BigInt(budget.limitMinor)) {
          Alert.alert(t(language, "overBudget"), `${t(language, "spent")}: ${formatMoney(budget.spentMinor, currencyDefinitionFor(currency, customCurrencies), localeFor(language))} · ${t(language, "budgetLimit")}: ${formatMoney(budget.limitMinor, currencyDefinitionFor(currency, customCurrencies), localeFor(language))}`, [{ text: t(language, "continue"), onPress: () => router.back() }]);
          return;
        }
      }
      router.back();
    } catch {
      setError(t(language, "saveFailed"));
    } finally {
      setBusy(false);
    }
  };

  return <Page>
    <Stack.Screen options={{ presentation: "modal" }} />
    <Text style={[styles.title, { color: colors.ink }]}>{t(language, "addRecord")}</Text>
    <View style={styles.row}>{(["income", "expense"] as const).map((item) => <Pill key={item} title={t(language, item === "income" ? "income" : "expenses")} selected={kind === item} onPress={() => setKind(item)} />)}</View>
    <Card>
      <Field label={t(language, "amount")} value={amount} onChangeText={setAmount} keyboardType="decimal-pad" placeholder={digits ? `0.${"0".repeat(digits)}` : "0"} />
      <Text style={[styles.label, { color: colors.ink }]}>{t(language, "currency")}</Text>
      <View style={styles.row}>{availableCurrencies.map((item) => <Pill key={item.code} title={item.code} selected={currency === item.code} onPress={() => setCurrency(item.code)} />)}</View>
      <Text style={[styles.label, { color: colors.ink }]}>{t(language, "category")}</Text>
      <View style={styles.row}>{categories.map((item) => <Pill key={item.id} title={item.name} selected={categoryId === item.id} onPress={() => setCategoryId(item.id)} />)}</View>
      <Field label={t(language, "date")} value={dateKey} onChangeText={setDateKey} autoCapitalize="none" placeholder="YYYY-MM-DD" />
      <Field label={t(language, "note")} value={note} onChangeText={setNote} maxLength={200} />
    </Card>
    {error ? <Text accessibilityRole="alert" style={[styles.error, { color: colors.red }]}>{error}</Text> : null}
    <Button title={busy ? "…" : t(language, "save")} disabled={busy} onPress={() => void save()} />
    <Button title={t(language, "cancel")} variant="secondary" disabled={busy} onPress={() => router.back()} />
  </Page>;
}

const styles = StyleSheet.create({
  title: { fontSize: 22, fontWeight: "900", marginBottom: 6 }, row: { flexDirection: "row", flexWrap: "wrap", gap: 8 }, label: { fontSize: 13, fontWeight: "800" }, error: { fontSize: 13, lineHeight: 18 },
});
