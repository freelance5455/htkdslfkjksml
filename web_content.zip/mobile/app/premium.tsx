import { StyleSheet, Text } from "react-native";
import { t } from "../src/i18n";
import { useFinance } from "../src/shared/MobileProvider";
import { Card, Heading, Page } from "../src/shared/ui";

export default function PremiumScreen() {
  const { language, colors } = useFinance();
  return <Page title={t(language, "premium")} subtitle={t(language, "premiumUnavailable")}>
    <Card>
      <Heading>{t(language, "premiumStatus")}</Heading>
      <Text style={[styles.body, { color: colors.ink }]}>{t(language, "premiumNoCharge")}</Text>
      <Text style={[styles.body, { color: colors.inkMuted }]}>{t(language, "premiumFeatures")}</Text>
    </Card>
    <Card>
      <Heading>{t(language, "author")}</Heading>
      <Text style={[styles.body, { color: colors.inkMuted }]}>{t(language, "premiumOwnerSteps")}</Text>
      <Text style={[styles.body, { color: colors.inkMuted }]}>{t(language, "adsInfo")}</Text>
      <Text style={[styles.body, { color: colors.inkMuted }]}>{t(language, "privacyNote")}</Text>
    </Card>
  </Page>;
}
const styles = StyleSheet.create({ body: { fontSize: 14, lineHeight: 22 } });
