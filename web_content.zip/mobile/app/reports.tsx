import { useCallback, useMemo, useState } from "react";
import { Alert, ScrollView, StyleSheet, Text, View } from "react-native";
import { useFocusEffect } from "expo-router";
import { File, Paths } from "expo-file-system";
import * as Print from "expo-print";
import * as Sharing from "expo-sharing";
import { DEFAULT_CURRENCIES, currencyDefinitionFor, fractionDigitsFor, formatMoney, type CurrencyDefinition } from "../src/domain/money";
import type { MonthlyReport, ReportTransaction } from "../src/domain/reports";
import { getMonthlyReport, getReportTransactions } from "../src/db/reportRepository";
import { readSetting } from "../src/db/repository";
import { localeFor, t } from "../src/i18n";
import { makeMonthlyCsv, makeMonthlyPdfHtml, type ReportLabels } from "../src/features/reportSerialization";
import { Button, Card, Field, Heading, Page, Pill } from "../src/shared/ui";
import { useFinance } from "../src/shared/MobileProvider";
import { toLocalDateKey } from "../src/domain/dates";

export default function ReportsScreen() {
  const { language, currency: defaultCurrency, colors, refreshKey } = useFinance();
  const [month, setMonth] = useState(toLocalDateKey().slice(0, 7));
  const [currency, setCurrency] = useState(defaultCurrency);
  const [customCurrencies, setCustomCurrencies] = useState<CurrencyDefinition[]>([]);
  const [report, setReport] = useState<MonthlyReport | null>(null);
  const [exportRows, setExportRows] = useState<ReportTransaction[]>([]);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useFocusEffect(useCallback(() => {
    let active = true;
    if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(month)) {
      setReport(null);
      return () => { active = false; };
    }
    setBusy(true);
    void Promise.all([
      readSetting<CurrencyDefinition[]>("customCurrencies", []),
      getMonthlyReport(month, currency),
      getReportTransactions(month, currency),
    ]).then(([custom, nextReport, rows]) => {
      if (!active) return;
      setCustomCurrencies(custom);
      setReport(nextReport);
      setExportRows(rows);
      setError("");
    }).catch(() => { if (active) setError(t(language, "genericError")); })
      .finally(() => { if (active) setBusy(false); });
    return () => { active = false; };
  }, [month, currency, refreshKey, language]));

  const currencyInfo = useMemo(() => currencyDefinitionFor(currency, customCurrencies), [currency, customCurrencies]);
  const locale = localeFor(language);
  const formatAmount = (minor: string) => formatMoney(minor, currencyInfo, locale);
  const labels: ReportLabels & { title: string; report: string } = {
    title: t(language, "appName"), report: t(language, "reportsTitle"), month: t(language, "reportMonth"),
    currency: t(language, "currency"), totalIncome: t(language, "income"), totalExpenses: t(language, "expenses"),
    balance: t(language, "balance"), expenseBreakdown: t(language, "expenseBreakdown"), day: t(language, "date"),
    date: t(language, "date"), kind: t(language, "category"), category: t(language, "category"), amount: t(language, "amount"),
    note: t(language, "note"), income: t(language, "income"), expense: t(language, "expenses"),
    demoNotice: t(language, "sampleBanner"), privateNotice: t(language, "exportPrivate"),
  };

  const exportCsv = async () => {
    if (!report) return;
    setBusy(true);
    try {
      const content = makeMonthlyCsv(report, exportRows, currencyInfo.fractionDigits, labels);
      const file = new File(Paths.cache, `tolovchi-${month}-${currency}-${Date.now()}.csv`);
      file.create();
      await file.write(content);
      if (!(await Sharing.isAvailableAsync())) throw new Error("File sharing is unavailable on this device.");
      await Sharing.shareAsync(file.uri, { mimeType: "text/csv", dialogTitle: t(language, "exportCsv") });
    } catch { Alert.alert(t(language, "genericError")); }
    finally { setBusy(false); }
  };
  const exportPdf = async () => {
    if (!report) return;
    setBusy(true);
    try {
      const html = makeMonthlyPdfHtml(report, currencyInfo.fractionDigits, labels, formatAmount);
      const { uri } = await Print.printToFileAsync({ html, margins: { top: 28, right: 24, bottom: 28, left: 24 } });
      if (!(await Sharing.isAvailableAsync())) throw new Error("File sharing is unavailable on this device.");
      await Sharing.shareAsync(uri, { mimeType: "application/pdf", dialogTitle: t(language, "exportPdf") });
    } catch { Alert.alert(t(language, "genericError")); }
    finally { setBusy(false); }
  };

  const maxCategory = report?.categories.reduce((max, item) => BigInt(item.amountMinor) > max ? BigInt(item.amountMinor) : max, 0n) ?? 0n;
  const maxDay = report?.days.reduce((max, item) => BigInt(item.expenseMinor) > max ? BigInt(item.expenseMinor) : max, 0n) ?? 0n;
  const shareableReport = Boolean(report && report.transactionCount > 0);

  return <Page title={t(language, "reportsTitle")} subtitle={t(language, "privacyTitle")}>
    <Field label={t(language, "reportMonth")} value={month} onChangeText={setMonth} autoCapitalize="none" placeholder="YYYY-MM" />
    <Heading>{t(language, "reportCurrency")}</Heading>
    <View style={styles.pills}>{[...DEFAULT_CURRENCIES, ...customCurrencies].map((item) => <Pill key={item.code} title={item.code} selected={currency === item.code} onPress={() => setCurrency(item.code)} />)}</View>
    {error ? <Text accessibilityRole="alert" style={{ color: colors.red }}>{error}</Text> : null}
    {busy ? <Text style={{ color: colors.inkMuted }}>{t(language, "loading")}</Text> : null}
    {report && report.transactionCount > 0 ? <>
      {report.demoCount > 0 ? <Card style={{ backgroundColor: colors.amberSoft }}><Text style={{ color: colors.amber, fontWeight: "800" }}>{t(language, "sampleBanner")}</Text></Card> : null}
      <View style={styles.summary}>
        <SummaryCard label={t(language, "income")} value={formatAmount(report.incomeMinor)} accent={colors.emerald} />
        <SummaryCard label={t(language, "expenses")} value={formatAmount(report.expenseMinor)} accent={colors.red} />
        <SummaryCard label={t(language, "balance")} value={formatAmount(report.balanceMinor)} accent={colors.navy} />
      </View>
      <Card>
        <Heading>{t(language, "expenseBreakdown")}</Heading>
        {report.categories.length ? report.categories.map((item) => {
          const percent = maxCategory > 0n ? Number((BigInt(item.amountMinor) * 100n) / maxCategory) : 0;
          return <View key={item.categoryId ?? "uncategorized"} style={styles.category}>
            <View style={styles.categoryHead}><Text numberOfLines={1} style={[styles.categoryName, { color: colors.ink }]}>{item.categoryName}</Text><Text style={{ color: colors.inkMuted }}>{formatAmount(item.amountMinor)}</Text></View>
            <View style={[styles.track, { backgroundColor: colors.line }]}><View style={[styles.fill, { width: `${percent}%`, backgroundColor: colors.emerald }]} /></View>
          </View>;
        }) : <Text style={{ color: colors.inkMuted }}>{t(language, "noReport")}</Text>}
      </Card>
      <Card>
        <Heading>{t(language, "reportMonth")}</Heading>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chart}>
          {report.days.map((item) => {
            const amount = BigInt(item.expenseMinor);
            const height = amount === 0n ? 3 : maxDay ? Math.max(8, Number((amount * 100n) / maxDay)) : 8;
            return <View key={item.dateKey} style={styles.barCell}>
              <Text style={[styles.barAmount, { color: colors.inkMuted }]}>{amount > 0n ? formatAmount(item.expenseMinor) : ""}</Text>
              <View style={[styles.bar, { height: `${Math.min(100, height)}%`, backgroundColor: amount === 0n ? colors.line : colors.emerald }]} />
              <Text style={[styles.barDate, { color: colors.inkMuted }]}>{item.dateKey.slice(-2)}</Text>
            </View>;
          })}
        </ScrollView>
      </Card>
      <Text style={[styles.note, { color: colors.inkMuted }]}>{t(language, "exportPrivate")}</Text>
      <View style={styles.actions}>
        <Button title={t(language, "exportCsv")} onPress={() => void exportCsv()} disabled={!shareableReport || busy} style={styles.action} />
        <Button title={t(language, "exportPdf")} variant="secondary" onPress={() => void exportPdf()} disabled={!shareableReport || busy} style={styles.action} />
      </View>
    </> : report && !busy ? <Card><Text style={{ color: colors.inkMuted }}>{t(language, "noReport")}</Text></Card> : null}
    <Text style={[styles.note, { color: colors.inkMuted }]}>{t(language, "privacyBody")}</Text>
  </Page>;
}

function SummaryCard({ label, value, accent }: { label: string; value: string; accent: string }) {
  const { colors } = useFinance();
  return <Card style={styles.summaryCard}><Text style={[styles.summaryLabel, { color: colors.inkMuted }]}>{label}</Text><Text numberOfLines={2} style={[styles.summaryValue, { color: accent }]}>{value}</Text></Card>;
}
const styles = StyleSheet.create({
  pills: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  summary: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  summaryCard: { flexGrow: 1, flexBasis: "30%", padding: 12, minWidth: 105 },
  summaryLabel: { fontSize: 12, fontWeight: "700" }, summaryValue: { fontSize: 14, fontWeight: "900", marginTop: 6 },
  category: { gap: 7 }, categoryHead: { flexDirection: "row", justifyContent: "space-between", gap: 10 }, categoryName: { flex: 1, fontSize: 13, fontWeight: "700" },
  track: { height: 7, borderRadius: 99, overflow: "hidden" }, fill: { height: "100%", borderRadius: 99 },
  chart: { flexDirection: "row", alignItems: "flex-end", gap: 7, minHeight: 140, paddingVertical: 8 }, barCell: { width: 40, height: 122, alignItems: "center", justifyContent: "flex-end", gap: 5 },
  bar: { width: 18, minHeight: 3, borderRadius: 9 }, barAmount: { fontSize: 8 }, barDate: { fontSize: 10 }, note: { fontSize: 12, lineHeight: 18 }, actions: { flexDirection: "row", gap: 8 }, action: { flex: 1 },
});
