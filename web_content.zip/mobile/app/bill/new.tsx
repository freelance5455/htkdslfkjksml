import { useEffect, useState } from "react";
import { Alert, StyleSheet, Text, View } from "react-native";
import { Stack, useLocalSearchParams, useRouter } from "expo-router";
import * as Crypto from "expo-crypto";
import { addBill, listBills, listCategories, readSetting, updateBill } from "../../src/db/repository";
import { isDateKey, toLocalDateKey, type Recurrence } from "../../src/domain/dates";
import { decimalToMinorUnits, DEFAULT_CURRENCIES, fractionDigitsFor, minorUnitsToDecimal, type CurrencyDefinition } from "../../src/domain/money";
import { cancelEntityReminders, scheduleEntityReminders } from "../../src/features/localReminders";
import { t } from "../../src/i18n";
import { Button, Card, Field, Page, Pill } from "../../src/shared/ui";
import { useFinance } from "../../src/shared/MobileProvider";

const repeats: Recurrence[] = ["none", "daily", "weekly", "monthly", "yearly"];
const recurrenceKey: Record<Recurrence, "noRepeat" | "everyDay" | "everyWeek" | "everyMonth" | "everyYear"> = {
  none: "noRepeat", daily: "everyDay", weekly: "everyWeek", monthly: "everyMonth", yearly: "everyYear",
};

export default function NewBillScreen() {
  const router = useRouter();
  const params = useLocalSearchParams<{ id?: string }>();
  const editingId = Array.isArray(params.id) ? params.id[0] : params.id;
  const { language, currency: preferredCurrency, colors, refresh } = useFinance();
  const [title, setTitle] = useState("");
  const [amount, setAmount] = useState("");
  const [currency, setCurrency] = useState(preferredCurrency);
  const [dueDate, setDueDate] = useState(toLocalDateKey());
  const [recurrence, setRecurrence] = useState<Recurrence>("monthly");
  const [interval, setInterval] = useState("1");
  const [categoryId, setCategoryId] = useState("");
  const [categories, setCategories] = useState<Array<{ id: string; name: string }>>([]);
  const [customCurrencies, setCustomCurrencies] = useState<CurrencyDefinition[]>([]);
  const [reminderOffsets, setReminderOffsets] = useState<number[]>([3, 1, 0]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;
    void Promise.all([listCategories("expense"), readSetting<CurrencyDefinition[]>("customCurrencies", []), listBills()]).then(([items, custom, bills]) => {
      if (!active) return;
      setCategories(items); setCustomCurrencies(custom);
      const bill = editingId ? bills.find((item) => item.id === editingId) : null;
      if (editingId && !bill) { setError(t(language, "genericError")); return; }
      if (bill) {
        setTitle(bill.title); setAmount(minorUnitsToDecimal(bill.amountMinor, fractionDigitsFor(bill.currency, custom)));
        setCurrency(bill.currency); setDueDate(bill.nextDueDate); setRecurrence(bill.recurrence); setInterval(String(bill.interval));
        setCategoryId(bill.categoryId ?? items[0]?.id ?? ""); setReminderOffsets(bill.reminderOffsets);
      } else setCategoryId(items[0]?.id ?? "");
    }).catch(() => { if (active) setError(t(language, "genericError")); });
    return () => { active = false; };
  }, [language, editingId]);

  const save = async () => {
    const fractionDigits = fractionDigitsFor(currency, customCurrencies);
    const amountMinor = decimalToMinorUnits(amount, fractionDigits);
    if (!title.trim() || !categoryId) { setError(t(language, "required")); return; }
    if (!amountMinor || BigInt(amountMinor) <= 0n) { setError(t(language, "invalidAmount")); return; }
    if (!isDateKey(dueDate)) { setError(t(language, "invalidDate")); return; }
    const intervalNumber = Number(interval);
    if (recurrence !== "none" && (!Number.isInteger(intervalNumber) || intervalNumber < 1 || intervalNumber > 120)) {
      setError(`${t(language, "everyInterval")}: 1–120`); return;
    }
    setBusy(true); setError("");
    const id = editingId ?? Crypto.randomUUID();
    try {
      const billData = { id, title: title.trim(), categoryId, amountMinor, currency, nextDueDate: dueDate, recurrence, interval: recurrence === "none" ? 1 : intervalNumber, anchorDay: Number(dueDate.slice(8, 10)), reminderOffsets: [...reminderOffsets].sort((a, b) => b - a) };
      if (editingId) await updateBill(editingId, billData);
      else await addBill({ ...billData, isDemo: false });
      let scheduled = true;
      if (reminderOffsets.length) {
        try { scheduled = await scheduleEntityReminders({ entityId: id, kind: "bill", dueDate, offsets: reminderOffsets, language }); }
        catch { scheduled = false; }
      } else await cancelEntityReminders(id);
      await refresh();
      if (reminderOffsets.length && !scheduled) Alert.alert(t(language, "reminderPermission"), t(language, "remindersOff"));
      router.back();
    } catch {
      setError(t(language, "saveFailed"));
    } finally { setBusy(false); }
  };

  return <Page>
    <Stack.Screen options={{ presentation: "modal" }} />
    <Text style={[styles.title, { color: colors.ink }]}>{t(language, editingId ? "editBill" : "addBill")}</Text>
    <Card>
      <Field label={t(language, "billTitle")} value={title} onChangeText={setTitle} maxLength={80} />
      <Field label={t(language, "amount")} value={amount} onChangeText={setAmount} keyboardType="decimal-pad" placeholder={fractionDigitsFor(currency, customCurrencies) ? "0.00" : "0"} />
      <Text style={[styles.label, { color: colors.ink }]}>{t(language, "currency")}</Text>
      <View style={styles.pills}>{[...DEFAULT_CURRENCIES, ...customCurrencies].map((item) => <Pill key={item.code} title={item.code} selected={currency === item.code} onPress={() => setCurrency(item.code)} />)}</View>
      <Text style={[styles.label, { color: colors.ink }]}>{t(language, "category")}</Text>
      <View style={styles.pills}>{categories.map((item) => <Pill key={item.id} title={item.name} selected={categoryId === item.id} onPress={() => setCategoryId(item.id)} />)}</View>
      <Field label={t(language, "dueDate")} value={dueDate} onChangeText={setDueDate} autoCapitalize="none" placeholder="YYYY-MM-DD" />
      <Text style={[styles.label, { color: colors.ink }]}>{t(language, "recurrence")}</Text>
      <View style={styles.pills}>{repeats.map((item) => <Pill key={item} title={t(language, recurrenceKey[item])} selected={recurrence === item} onPress={() => setRecurrence(item)} />)}</View>
      {recurrence !== "none" ? <Field label={t(language, "everyInterval")} value={interval} onChangeText={(value) => setInterval(value.replace(/\D/g, "").slice(0, 3))} keyboardType="number-pad" /> : null}
      <Text style={[styles.label, { color: colors.ink }]}>{t(language, "reminderDays")}</Text>
      <View style={styles.pills}>{[3, 1, 0].map((days) => <Pill key={days} title={String(days)} selected={reminderOffsets.includes(days)} onPress={() => setReminderOffsets((current) => current.includes(days) ? current.filter((item) => item !== days) : [...current, days].sort((a, b) => b - a))} />)}</View>
      <Text style={[styles.note, { color: colors.inkMuted }]}>{t(language, "reminderPermission")}</Text>
    </Card>
    {error ? <Text accessibilityRole="alert" style={{ color: colors.red }}>{error}</Text> : null}
    <Button title={busy ? "…" : t(language, "save")} disabled={busy} onPress={() => void save()} />
    <Button title={t(language, "cancel")} variant="secondary" disabled={busy} onPress={() => router.back()} />
  </Page>;
}

const styles = StyleSheet.create({ title: { fontSize: 22, fontWeight: "900" }, label: { fontSize: 13, fontWeight: "800" }, pills: { flexDirection: "row", flexWrap: "wrap", gap: 8 }, note: { fontSize: 12, lineHeight: 18 }, });
