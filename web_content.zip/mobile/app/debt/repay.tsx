import { useEffect, useState } from "react";
import { StyleSheet, Text } from "react-native";
import { Stack, useLocalSearchParams, useRouter } from "expo-router";
import { addRepayment, listDebts, readSetting } from "../../src/db/repository";
import { cancelEntityReminders } from "../../src/features/localReminders";
import { isDateKey, toLocalDateKey } from "../../src/domain/dates";
import { currencyDefinitionFor, decimalToMinorUnits, formatMoney, fractionDigitsFor, type CurrencyDefinition } from "../../src/domain/money";
import type { Debt } from "../../src/domain/types";
import { localeFor, t } from "../../src/i18n";
import { Button, Card, Field, Page } from "../../src/shared/ui";
import { useFinance } from "../../src/shared/MobileProvider";

type DebtRow = Debt & { repaidMinor: string; remainingMinor: string };
export default function RepaymentScreen() {
  const { id: rawId } = useLocalSearchParams<{ id?: string | string[] }>();
  const debtId = Array.isArray(rawId) ? rawId[0] ?? "" : rawId ?? "";
  const router = useRouter();
  const { language, colors, refresh } = useFinance();
  const [debt, setDebt] = useState<DebtRow | null>(null);
  const [currencies, setCurrencies] = useState<CurrencyDefinition[]>([]);
  const [amount, setAmount] = useState("");
  const [dateKey, setDateKey] = useState(toLocalDateKey());
  const [note, setNote] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => { let active = true; void Promise.all([listDebts(), readSetting<CurrencyDefinition[]>("customCurrencies", [])]).then(([rows, custom]) => { if (active) { setDebt(rows.find((item) => item.id === debtId) ?? null); setCurrencies(custom); } }).catch(() => { if (active) setError(t(language, "genericError")); }); return () => { active = false; }; }, [debtId, language]);

  const save = async () => {
    if (!debt) { setError(t(language, "noRecords")); return; }
    const amountMinor = decimalToMinorUnits(amount, fractionDigitsFor(debt.currency, currencies));
    if (!amountMinor || BigInt(amountMinor) <= 0n || BigInt(amountMinor) > BigInt(debt.remainingMinor)) { setError(t(language, "invalidAmount")); return; }
    if (!isDateKey(dateKey)) { setError(t(language, "invalidDate")); return; }
    setBusy(true); setError("");
    try {
      await addRepayment(debt.id, amountMinor, dateKey, note.trim());
      const updatedDebt = (await listDebts()).find((item) => item.id === debt.id);
      if (updatedDebt && BigInt(updatedDebt.remainingMinor) === 0n) await cancelEntityReminders(debt.id);
      await refresh(); router.back();
    }
    catch { setError(t(language, "genericError")); }
    finally { setBusy(false); }
  };

  return <Page>
    <Stack.Screen options={{ presentation: "modal" }} />
    <Text style={[styles.title, { color: colors.ink }]}>{t(language, "repayPart")}</Text>
    {debt ? <Card>
      <Text style={[styles.person, { color: colors.ink }]}>{debt.person} · {debt.currency}</Text>
      <Text style={{ color: colors.inkMuted }}>{t(language, "remaining")}: {formatMoney(debt.remainingMinor, currencyDefinitionFor(debt.currency, currencies), localeFor(language))}</Text>
      <Field label={t(language, "repaymentAmount")} value={amount} onChangeText={setAmount} keyboardType="decimal-pad" />
      <Field label={t(language, "date")} value={dateKey} onChangeText={setDateKey} autoCapitalize="none" placeholder="YYYY-MM-DD" />
      <Field label={t(language, "note")} value={note} onChangeText={setNote} maxLength={160} />
    </Card> : <Card><Text style={{ color: colors.inkMuted }}>{t(language, "noRecords")}</Text></Card>}
    {error ? <Text accessibilityRole="alert" style={{ color: colors.red }}>{error}</Text> : null}
    <Button title={busy ? "…" : t(language, "save")} disabled={busy || !debt} onPress={() => void save()} />
    <Button title={t(language, "cancel")} variant="secondary" onPress={() => router.back()} />
  </Page>;
}
const styles = StyleSheet.create({ title: { fontSize: 22, fontWeight: "900" }, person: { fontSize: 16, fontWeight: "800" }, });
