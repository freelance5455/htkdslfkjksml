import { useEffect, useState } from "react";
import { Alert, StyleSheet, Text, View } from "react-native";
import { Stack, useLocalSearchParams, useRouter } from "expo-router";
import * as Crypto from "expo-crypto";
import { addDebt, listDebts, readSetting, updateDebt } from "../../src/db/repository";
import { isDateKey, toLocalDateKey } from "../../src/domain/dates";
import { decimalToMinorUnits, DEFAULT_CURRENCIES, fractionDigitsFor, minorUnitsToDecimal, type CurrencyDefinition } from "../../src/domain/money";
import type { DebtDirection } from "../../src/domain/types";
import { cancelEntityReminders, scheduleEntityReminders } from "../../src/features/localReminders";
import { t } from "../../src/i18n";
import { Button, Card, Field, Page, Pill } from "../../src/shared/ui";
import { useFinance } from "../../src/shared/MobileProvider";

export default function NewDebtScreen() {
  const router = useRouter();
  const params = useLocalSearchParams<{ id?: string }>();
  const editingId = Array.isArray(params.id) ? params.id[0] : params.id;
  const { language, currency: preferredCurrency, colors, refresh } = useFinance();
  const [direction, setDirection] = useState<DebtDirection>("lent");
  const [person, setPerson] = useState("");
  const [note, setNote] = useState("");
  const [amount, setAmount] = useState("");
  const [currency, setCurrency] = useState(preferredCurrency);
  const [startDate, setStartDate] = useState(toLocalDateKey());
  const [dueDate, setDueDate] = useState("");
  const [reminderOffsets, setReminderOffsets] = useState<number[]>([3, 1, 0]);
  const [repaidMinor, setRepaidMinor] = useState("0");
  const [customCurrencies, setCustomCurrencies] = useState<CurrencyDefinition[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  useEffect(() => {
    let active = true;
    void Promise.all([readSetting<CurrencyDefinition[]>("customCurrencies", []), listDebts()]).then(([items, debts]) => {
      if (!active) return;
      setCustomCurrencies(items);
      if (!editingId) return;
      const debt = debts.find((item) => item.id === editingId);
      if (!debt) { setError(t(language, "genericError")); return; }
      setDirection(debt.direction); setPerson(debt.person); setNote(debt.note); setAmount(minorUnitsToDecimal(debt.principalMinor, fractionDigitsFor(debt.currency, items)));
      setCurrency(debt.currency); setStartDate(debt.startDate); setDueDate(debt.dueDate ?? ""); setReminderOffsets(debt.reminderOffsets); setRepaidMinor(debt.repaidMinor);
    }).catch(() => { if (active) setError(t(language, "genericError")); });
    return () => { active = false; };
  }, [language, editingId]);

  const save = async () => {
    const amountMinor = decimalToMinorUnits(amount, fractionDigitsFor(currency, customCurrencies));
    if (!person.trim()) { setError(t(language, "required")); return; }
    if (!amountMinor || BigInt(amountMinor) <= 0n) { setError(t(language, "invalidAmount")); return; }
    if (!isDateKey(startDate) || (dueDate && !isDateKey(dueDate))) { setError(t(language, "invalidDate")); return; }
    if (dueDate && dueDate < startDate) { setError(t(language, "invalidDate")); return; }
    setBusy(true); setError("");
    const id = editingId ?? Crypto.randomUUID();
    try {
      const debt = { id, direction, person: person.trim(), note: note.trim(), principalMinor: amountMinor, currency, startDate, dueDate: dueDate || null, reminderOffsets: dueDate ? [...reminderOffsets].sort((a, b) => b - a) : [] };
      if (editingId) await updateDebt(editingId, debt);
      else await addDebt({ ...debt, isDemo: false });
      let scheduled = true;
      if (dueDate && reminderOffsets.length && BigInt(amountMinor) > BigInt(repaidMinor)) {
        try { scheduled = await scheduleEntityReminders({ entityId: id, kind: "debt", dueDate, offsets: reminderOffsets, language }); }
        catch { scheduled = false; }
      } else await cancelEntityReminders(id);
      await refresh();
      if (dueDate && reminderOffsets.length && !scheduled) Alert.alert(t(language, "reminderPermission"), t(language, "remindersOff"));
      router.back();
    } catch { setError(t(language, "genericError")); }
    finally { setBusy(false); }
  };

  return <Page>
    <Stack.Screen options={{ presentation: "modal" }} />
    <Text style={[styles.title, { color: colors.ink }]}>{t(language, editingId ? "edit" : "debts")}</Text>
    <Card>
      <Field label={t(language, "counterparty")} value={person} onChangeText={setPerson} maxLength={80} />
      {BigInt(repaidMinor) > 0n ? <Text style={[styles.note, { color: colors.inkMuted }]}>{t(language, "debtEditLocked")}</Text> : <>
        <Text style={[styles.label, { color: colors.ink }]}>{t(language, "debtDirection")}</Text>
        <View style={styles.pills}><Pill title={t(language, "lent")} selected={direction === "lent"} onPress={() => setDirection("lent")} /><Pill title={t(language, "borrowed")} selected={direction === "borrowed"} onPress={() => setDirection("borrowed")} /></View>
        <Field label={t(language, "principal")} value={amount} onChangeText={setAmount} keyboardType="decimal-pad" />
        <Text style={[styles.label, { color: colors.ink }]}>{t(language, "currency")}</Text>
        <View style={styles.pills}>{[...DEFAULT_CURRENCIES, ...customCurrencies].map((item) => <Pill key={item.code} title={item.code} selected={currency === item.code} onPress={() => setCurrency(item.code)} />)}</View>
        <Field label={t(language, "startDate")} value={startDate} onChangeText={setStartDate} autoCapitalize="none" placeholder="YYYY-MM-DD" />
      </>}
      <Field label={t(language, "optionalDueDate")} value={dueDate} onChangeText={setDueDate} autoCapitalize="none" placeholder="YYYY-MM-DD" />
      {dueDate ? <><Text style={[styles.label, { color: colors.ink }]}>{t(language, "reminderDays")}</Text><View style={styles.pills}>{[3, 1, 0].map((days) => <Pill key={days} title={String(days)} selected={reminderOffsets.includes(days)} onPress={() => setReminderOffsets((current) => current.includes(days) ? current.filter((item) => item !== days) : [...current, days].sort((a, b) => b - a))} />)}</View></> : null}
      <Field label={t(language, "note")} value={note} onChangeText={setNote} maxLength={160} />
    </Card>
    {error ? <Text accessibilityRole="alert" style={{ color: colors.red }}>{error}</Text> : null}
    <Button title={busy ? "…" : t(language, "save")} disabled={busy} onPress={() => void save()} />
    <Button title={t(language, "cancel")} variant="secondary" disabled={busy} onPress={() => router.back()} />
  </Page>;
}

const styles = StyleSheet.create({ title: { fontSize: 22, fontWeight: "900" }, label: { fontSize: 13, fontWeight: "800" }, pills: { flexDirection: "row", flexWrap: "wrap", gap: 8 }, note: { fontSize: 12, lineHeight: 18 }, });
