import { useEffect, useState } from "react";
import { Alert, StyleSheet, Text, View } from "react-native";
import { Stack, useRouter } from "expo-router";
import * as Crypto from "expo-crypto";
import { addDebt, readSetting } from "../../src/db/repository";
import { isDateKey, toLocalDateKey } from "../../src/domain/dates";
import { decimalToMinorUnits, DEFAULT_CURRENCIES, fractionDigitsFor, type CurrencyDefinition } from "../../src/domain/money";
import type { DebtDirection } from "../../src/domain/types";
import { scheduleEntityReminders } from "../../src/features/localReminders";
import { t } from "../../src/i18n";
import { Button, Card, Field, Page, Pill } from "../../src/shared/ui";
import { useFinance } from "../../src/shared/MobileProvider";

export default function NewDebtScreen() {
  const router = useRouter();
  const { language, currency: preferredCurrency, colors, refresh } = useFinance();
  const [direction, setDirection] = useState<DebtDirection>("lent");
  const [person, setPerson] = useState("");
  const [note, setNote] = useState("");
  const [amount, setAmount] = useState("");
  const [currency, setCurrency] = useState(preferredCurrency);
  const [startDate, setStartDate] = useState(toLocalDateKey());
  const [dueDate, setDueDate] = useState("");
  const [reminders, setReminders] = useState(true);
  const [customCurrencies, setCustomCurrencies] = useState<CurrencyDefinition[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  useEffect(() => { let active = true; void readSetting<CurrencyDefinition[]>("customCurrencies", []).then((items) => { if (active) setCustomCurrencies(items); }); return () => { active = false; }; }, []);

  const save = async () => {
    const amountMinor = decimalToMinorUnits(amount, fractionDigitsFor(currency, customCurrencies));
    if (!person.trim()) { setError(t(language, "required")); return; }
    if (!amountMinor || BigInt(amountMinor) <= 0n) { setError(t(language, "invalidAmount")); return; }
    if (!isDateKey(startDate) || (dueDate && !isDateKey(dueDate))) { setError(t(language, "invalidDate")); return; }
    if (dueDate && dueDate < startDate) { setError(t(language, "invalidDate")); return; }
    setBusy(true); setError("");
    const id = Crypto.randomUUID();
    try {
      await addDebt({ id, direction, person: person.trim(), note: note.trim(), principalMinor: amountMinor, currency, startDate, dueDate: dueDate || null, reminderOffsets: dueDate && reminders ? [3, 1, 0] : [], isDemo: false });
      let scheduled = true;
      if (dueDate && reminders) {
        try { scheduled = await scheduleEntityReminders({ entityId: id, kind: "debt", dueDate, offsets: [3, 1, 0], language }); }
        catch { scheduled = false; }
      }
      await refresh();
      if (dueDate && reminders && !scheduled) Alert.alert(t(language, "reminderPermission"), t(language, "remindersOff"));
      router.back();
    } catch { setError(t(language, "genericError")); }
    finally { setBusy(false); }
  };

  return <Page>
    <Stack.Screen options={{ presentation: "modal" }} />
    <Text style={[styles.title, { color: colors.ink }]}>{t(language, "debts")}</Text>
    <Card>
      <Text style={[styles.label, { color: colors.ink }]}>{t(language, "debtDirection")}</Text>
      <View style={styles.pills}><Pill title={t(language, "lent")} selected={direction === "lent"} onPress={() => setDirection("lent")} /><Pill title={t(language, "borrowed")} selected={direction === "borrowed"} onPress={() => setDirection("borrowed")} /></View>
      <Field label={t(language, "counterparty")} value={person} onChangeText={setPerson} maxLength={80} />
      <Field label={t(language, "principal")} value={amount} onChangeText={setAmount} keyboardType="decimal-pad" />
      <Text style={[styles.label, { color: colors.ink }]}>{t(language, "currency")}</Text>
      <View style={styles.pills}>{[...DEFAULT_CURRENCIES, ...customCurrencies].map((item) => <Pill key={item.code} title={item.code} selected={currency === item.code} onPress={() => setCurrency(item.code)} />)}</View>
      <Field label={t(language, "startDate")} value={startDate} onChangeText={setStartDate} autoCapitalize="none" placeholder="YYYY-MM-DD" />
      <Field label={t(language, "optionalDueDate")} value={dueDate} onChangeText={setDueDate} autoCapitalize="none" placeholder="YYYY-MM-DD" />
      {dueDate ? <Pill title={`${t(language, "reminderDays")}: 3 / 1 / 0`} selected={reminders} onPress={() => setReminders((value) => !value)} /> : null}
      <Field label={t(language, "note")} value={note} onChangeText={setNote} maxLength={160} />
    </Card>
    {error ? <Text accessibilityRole="alert" style={{ color: colors.red }}>{error}</Text> : null}
    <Button title={busy ? "…" : t(language, "save")} disabled={busy} onPress={() => void save()} />
    <Button title={t(language, "cancel")} variant="secondary" disabled={busy} onPress={() => router.back()} />
  </Page>;
}

const styles = StyleSheet.create({ title: { fontSize: 22, fontWeight: "900" }, label: { fontSize: 13, fontWeight: "800" }, pills: { flexDirection: "row", flexWrap: "wrap", gap: 8 }, });
