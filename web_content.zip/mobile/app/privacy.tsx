import { Text } from "react-native";
import { privacyPolicySections } from "../src/features/legalContent";
import { t } from "../src/i18n";
import { Card, Page } from "../src/shared/ui";
import { useFinance } from "../src/shared/MobileProvider";

export default function PrivacyScreen() {
  const { language, colors } = useFinance();
  return <Page title={t(language, "privacyPolicy")} subtitle={t(language, "legalDraftNotice")}>
    {privacyPolicySections[language].map((paragraph, index) => <Card key={index}><Text style={{ color: colors.ink, fontSize: 14, lineHeight: 21 }}>{paragraph}</Text></Card>)}
  </Page>;
}
