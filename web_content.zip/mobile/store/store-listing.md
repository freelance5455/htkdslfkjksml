# NOMIDMAN TRANS: store listing (draft)

**App name:** NOMIDMAN TRANS
**Short description:** Direct property and vehicle listings. Genuine price, no middleman cost.
**Category:** Business (or Lifestyle)

## Full description (English)
NOMIDMAN TRANS connects owners directly with buyers and renters across Uganda, Tanzania, Rwanda, Kenya, DR Congo and South Sudan.
- Browse plots, houses, commercial premises, hotels, automobiles and other items, with land sizes in m², km², acres and hectares.
- Filter by country, location, category, sale or rent, and price.
- Contact owners by call, WhatsApp or email once you sign in.
- Share any listing by SMS, email, WhatsApp, Facebook, X or Messenger, without signing in.
- Save listings and searches.
- Owners: list your property, boost it to the top, and track views and enquiries.
No middleman fees. The owner keeps the full price.

## Links (must be live before submission)
- Privacy policy: https://nomidtrans.shop/#/privacy
- Terms and conditions: https://nomidtrans.shop/#/terms
- Support: https://nomidtrans.shop/#/help

## Screenshots
Take 4 to 8 phone screenshots: home page, browse, listing with Share open, owner dashboard, subscription plans, and sign-up.

## Data safety (answer carefully)
Collected: name, email, phone number, nationality, ID document number (stored as a protected hash), listing content and photos, payment records. Not sold. Shared only with the payment and messaging providers needed to run the service. Users can close or delete their account, and information is removed 30 days after closure.
