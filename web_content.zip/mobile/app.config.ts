import type { ExpoConfig } from "expo/config";

const androidPackage = process.env.EXPO_PUBLIC_ANDROID_PACKAGE || "uz.tolovchi.app";
const iosBundleIdentifier = process.env.EXPO_PUBLIC_IOS_BUNDLE_ID || "uz.tolovchi.app";
const easProjectId = process.env.EXPO_PUBLIC_EAS_PROJECT_ID;
const plugins: NonNullable<ExpoConfig["plugins"]> = [
  "expo-router",
  ["expo-sqlite", { useSQLCipher: true }],
  "expo-notifications",
  "expo-secure-store",
  "expo-local-authentication",
  "expo-sharing",
  "expo-localization",
  "expo-status-bar",
  "expo-font",
  "expo-dev-client",
];

const config: ExpoConfig = {
  name: "TO‘LOVCHI",
  slug: "tolovchi",
  version: "1.0.0",
  orientation: "portrait",
  scheme: "tolovchi",
  userInterfaceStyle: "automatic",
  icon: "./assets/images/icon.png",
  splash: {
    image: "./assets/images/splash-icon.png",
    resizeMode: "contain",
    backgroundColor: "#f7faf8",
  },
  ios: {
    bundleIdentifier: iosBundleIdentifier,
    supportsTablet: false,
    infoPlist: {
      NSFaceIDUsageDescription: "Unlock your encrypted TO‘LOVCHI ledger on this device.",
    },
  },
  android: {
    package: androidPackage,
    versionCode: 1,
    permissions: ["android.permission.POST_NOTIFICATIONS"],
    adaptiveIcon: {
      foregroundImage: "./assets/images/android-icon-foreground.png",
      backgroundImage: "./assets/images/android-icon-background.png",
      monochromeImage: "./assets/images/android-icon-monochrome.png",
      backgroundColor: "#14836d",
    },
  },
  web: {
    favicon: "./assets/images/favicon.png",
    bundler: "metro",
  },
  plugins,
  updates: { enabled: false },
  extra: {
    ...(easProjectId ? { eas: { projectId: easProjectId } } : {}),
    privacy: { financeDataRemainsOnDevice: true },
  },
};

export default config;
