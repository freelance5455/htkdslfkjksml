import { h, add, html, date, ago, naira, initials, routeForUrl } from "./util.js";
import { api, session, logout, setUser, refreshMe, ApiError } from "./api.js";
import { state, go } from "./state.js";
import { SITE, APP_VERSION } from "./config.js";
import { header, iconBtn, toast, empty, courseCard, field, progressBar, staleNote } from "./ui.js";
import { share, openExternal, platform, isNative } from "./native.js";
import * as IAP from "./iap.js";

const needLogin = (t) => h("div", null, header(t, { back: false }), empty("Sign in", "Sign in to see this.", h("button", { class: "btn", onclick: () => go("/login") }, "Sign in")));
const page = (url) => (e) => { e && e.preventDefault && e.preventDefault(); openExternal(SITE + url); };

// ---------------------------------------------------------------- Activity
export async function activity(_, q) {
  if (!session.user) return needLogin("Activity");
  let kind = q.get("kind") || ""; const root = h("div"), list = h("div"), chips = h("div", { class: "chips" });
  const kinds = [["", "All"], ["announcement", "Announcements"], ["assignment", "Assignments"], ["grade", "Grades"], ["certificate", "Certificates"], ["discussion", "Discussions"]];
  async function load() {
    chips.replaceChildren(...kinds.map(([k, t]) => h("button", { class: "chip" + (kind === k ? " on" : ""), onclick: () => { kind = k; load(); } }, t)));
    const d = await api("/notifications" + (kind ? "?kind=" + kind : "")); setBadge(d.unread);
    list.replaceChildren(d.notifications.length ? h("div", { class: "list card", style: { margin: "0 16px" } }, d.notifications.map(n => h("button", { class: n.read ? "" : "unread", onclick: async () => { if (!n.read) api("/notifications/read", { method: "POST", body: { id: n.id } }).catch(() => {}); const r = n.link ? routeForUrl(SITE + n.link, SITE) : null; if (r) go(r); else { n.read = true; load(); } } },
      h("div", { class: "grow" }, h("div", { style: { fontWeight: n.read ? 400 : 650 } }, n.title), n.body ? h("div", { class: "s" }, n.body) : null, h("div", { class: "s" }, ago(n.created_at)))))) : empty("You're all caught up", "Announcements, payment updates and grades show up here."));
  }
  add(root, h("div", { class: "top" }, h("h1", null, "Activity"), h("button", { class: "btn sm sec2", onclick: async () => { await api("/notifications/read", { method: "POST", body: {} }); load(); } }, "Mark all read")), staleNote(), chips, list);
  await load(); return root;
}
export function setBadge(n) { const b = document.getElementById("badge"); if (!b) return; b.textContent = n > 99 ? "99+" : n; b.hidden = !n; }

// ---------------------------------------------------------------- Profile
export async function profile() {
  const root = h("div"); add(root, h("div", { class: "top" }, h("h1", null, "Profile")));
  const u = session.user;
  if (!u) { add(root, empty("Welcome to Dagba", "Sign in to save your progress and learn on any device.", h("div", null, h("button", { class: "btn", onclick: () => go("/login") }, "Sign in"), h("div", { class: "sp" }), h("button", { class: "btn line", onclick: () => go("/register") }, "Create account"))));
    add(root, menu([["Privacy policy", page("/privacy-policy")], ["Terms and conditions", page("/terms-and-conditions")], ["Contact support", () => go("/support")]])); return root; }
  let me = u; try { me = await (await import("./api.js")).refreshMe(); } catch {}
  add(root, h("div", { class: "wrap", style: { display: "flex", gap: "14px", alignItems: "center" } }, h("div", { class: "avatar" }, initials(me.full_name)), h("div", null, h("h2", null, me.full_name), h("div", { class: "mute" }, me.email))));
  const subs = Object.entries(me.subscriptions || {}).filter(([, v]) => v.active); const nm = { basic: "Academic Basic", advanced: "Academic Advanced", income: "Income Skills" };
  add(root, h("div", { class: "card", style: { margin: "16px", padding: "14px" } }, h("h3", null, "Subscriptions"), subs.length ? subs.map(([k, v]) => h("div", { class: "meta", style: { fontSize: ".9rem", marginTop: "6px" } }, h("span", { class: "pill ok" }, nm[k] || k), " " + (v.lifetime ? "Lifetime" : "until " + date(v.expires_at)))) : h("p", { class: "meta" }, "No active subscription."), h("div", { class: "sp" }), h("button", { class: "btn sec2", onclick: () => go("/plans") }, "Plans & subscriptions")));
  add(root, menu([["Edit profile", () => go("/settings/profile")], ["My certificates", () => go("/certificates")], ["Payments & purchases", () => go("/payments")], ["Security: change password", () => go("/settings/password")]]));
  add(root, menu([["Contact support", () => go("/support")], ["Privacy policy", page("/privacy-policy")], ["Terms and conditions", page("/terms-and-conditions")], ["Refund policy", page("/refund-policy")]]));
  add(root, menu([["Delete account", () => go("/settings/delete")]]), h("div", { class: "wrap" }, h("div", { class: "sp" }), h("button", { class: "btn line", onclick: async () => { await logout(); go("/home"); toast("Signed out."); } }, "Sign out"), h("p", { class: "mute center", style: { fontSize: ".75rem" } }, "Dagba Digital Academy · v" + APP_VERSION), h("div", { class: "sp" })));
  return root;
}
function menu(rows) { return h("div", { class: "list card", style: { margin: "12px 16px" } }, rows.map(([t, fn]) => h("button", { onclick: fn }, h("div", { class: "grow" }, t), h("span", { class: "mute" }, "›")))); }

export async function settingsScreen({ what }) {
  if (!session.user) return needLogin("Settings"); const root = h("div"), msg = h("div", { class: "err", hidden: true }), me = session.user;
  const fail = (e) => { msg.textContent = e.message; msg.hidden = false; };
  if (what === "profile") {
    const n = h("input", { value: me.full_name }), p = h("input", { type: "tel", value: me.phone || "" });
    add(root, header("Edit profile"), field("Full name", n), field("Phone", p), msg, h("div", { class: "wrap" }, h("button", { class: "btn", onclick: async () => { try { const d = await api("/me", { method: "PATCH", body: { full_name: n.value, phone: p.value } }); await setUser(d.user); toast("Saved."); history.back(); } catch (e) { fail(e); } } }, "Save")));
  } else if (what === "password") {
    const a = h("input", { type: "password", autocomplete: "current-password" }), b = h("input", { type: "password", autocomplete: "new-password" });
    add(root, header("Change password"), field("Current password", a), field("New password", b), msg, h("div", { class: "wrap" }, h("button", { class: "btn", onclick: async () => { try { await api("/me/password", { method: "POST", body: { current_password: a.value, new_password: b.value } }); toast("Password changed. Other devices were signed out."); history.back(); } catch (e) { fail(e); } } }, "Update password")));
  } else {
    const pw = h("input", { type: "password", autocomplete: "current-password" });
    add(root, header("Delete account"), h("div", { class: "note" }, "This permanently deletes your personal details and signs you out everywhere. Payment records and issued certificates are kept as required for accounting and verification. This cannot be undone."), field("Enter your password to confirm", pw), msg,
      h("div", { class: "wrap" }, h("button", { class: "btn danger", onclick: async () => { if (!confirm("Delete your account permanently?")) return; try { await api("/me", { method: "DELETE", body: { password: pw.value } }); const { clearSession } = await import("./api.js"); await clearSession(); toast("Your account was deleted."); go("/home"); } catch (e) { fail(e); } } }, "Delete my account")));
  }
  return root;
}

// ---------------------------------------------------------------- Plans / payments / support
export async function plans() {
  if (!session.user) return needLogin("Plans");
  const d = await api("/plans"), root = h("div"); await IAP.init().catch(() => {});
  const nm = { basic: "Academic: Basic", advanced: "Academic: Advanced", income: "Income Skills" };
  add(root, header("Plans & subscriptions"), h("div", { class: "note" }, "Each subscription unlocks only its own area. Academic plans do not unlock Income Skills, and Income Skills does not unlock Academic."));
  if (!d.plans.length) add(root, empty("No plans available", "Check back soon."));
  const buyBtn = (p) => { const pid = `dagba.plan.${p.id}`; const price = IAP.storePrice(pid); return IAP.available() ? h("button", { class: "btn", onclick: async (e) => { e.target.disabled = true; try { if (await IAP.buy(pid)) toast("Processing your purchase…"); } catch (er) { toast(er.message, true); } e.target.disabled = false; } }, "Subscribe" + (price ? " · " + price : "")) : h("div", { class: "meta" }, "Subscribe in the Dagba app on your phone."); };
  for (const p of d.plans) add(root, h("div", { class: "card", style: { margin: "12px 16px", padding: "14px" } }, h("span", { class: "pill" }, nm[p.scope] || p.scope), h("h3", { style: { marginTop: "6px" } }, p.name), p.description ? h("p", { class: "meta" }, p.description) : null, h("p", { class: "meta" }, p.duration_days + " days access"), h("div", { class: "sp" }), buyBtn(p)));
  IAP.onPurchased(r => { if (r.ok) { toast("Subscription active."); refreshMe().then(() => go("/profile")); } else toast(r.message || "Purchase could not be confirmed.", true); });
  if (IAP.available()) add(root, h("div", { class: "wrap" }, h("button", { class: "btn line", onclick: async () => { try { await IAP.restore(); toast("Checking your purchases…"); } catch (e) { toast(e.message, true); } } }, "Restore purchases"), h("div", { class: "sp" }),
    h("button", { class: "btn line", onclick: () => openExternal(platform() === "ios" ? "https://apps.apple.com/account/subscriptions" : "https://play.google.com/store/account/subscriptions") }, "Manage subscriptions in the store")));
  return root;
}
export async function payments() {
  if (!session.user) return needLogin("Payments");
  const d = await api("/my/payments"), root = h("div"); add(root, header("Payments & purchases"));
  const tone = { approved: "ok", pending_verification: "warn", awaiting_payment: "warn", rejected: "warn", refunded: "warn", failed: "warn" };
  add(root, h("div", { class: "modh" }, "Purchases"), d.transactions.length ? h("div", { class: "list" }, d.transactions.map(t => h("div", null, h("div", { class: "grow" }, h("div", null, t.title), h("div", { class: "s" }, date(t.created_at) + " · " + t.amount_label), t.note ? h("div", { class: "s" }, t.note) : null), h("span", { class: "pill " + (tone[t.status] || "") }, t.status.replace(/_/g, " "))))) : empty("No purchases yet", ""));
  add(root, h("div", { class: "modh" }, "Subscriptions"), d.subscriptions.length ? h("div", { class: "list" }, d.subscriptions.map(s => h("div", null, h("div", { class: "grow" }, h("div", null, s.name || "Subscription"), h("div", { class: "s" }, s.expires_at ? "Until " + date(s.expires_at) : "Lifetime")), h("span", { class: "pill " + (s.active ? "ok" : "") }, s.active ? "Active" : "Expired")))) : empty("No subscriptions", ""));
  return root;
}
export async function support() {
  const d = state.config ? state.config.settings : {}, root = h("div"); add(root, header("Support"));
  const rows = []; if (d["contact.email"]) rows.push(["Email " + d["contact.email"], () => openExternal("mailto:" + d["contact.email"]) ]); if (d["contact.whatsapp"]) rows.push(["Chat on WhatsApp", () => openExternal("https://wa.me/" + d["contact.whatsapp"].replace(/\D/g, ""))]);
  rows.push(["Contact form on our website", page("/contact")], ["Frequently asked questions", page("/faq")]);
  add(root, menu(rows.map(([t, f]) => [t, t.startsWith("Email") ? () => { location.href = "mailto:" + d["contact.email"]; } : f]))); return root;
}

// ---------------------------------------------------------------- Articles / paths / faith
export async function articles() {
  const d = await api("/articles"), root = h("div"); add(root, header("Articles"), staleNote());
  add(root, d.articles.length ? h("div", { class: "list card", style: { margin: "0 16px" } }, d.articles.map(a => h("a", { href: "#/article/" + a.slug }, h("div", { class: "grow" }, h("div", { style: { fontWeight: 650 } }, a.title), h("div", { class: "s" }, [a.category, a.author].filter(Boolean).join(" · ")), a.excerpt ? h("div", { class: "s" }, a.excerpt) : null)))) : empty("No articles yet", "")); return root;
}
export async function article({ slug }) {
  const a = (await api("/articles/" + slug)).article, root = h("div");
  add(root, header("Article", { right: iconBtn("share", "Share", () => share({ title: a.title, url: a.share_url })) }), a.image ? h("img", { src: a.image, alt: "", style: { width: "100%" } }) : null, h("div", { class: "wrap" }, h("h1", { style: { marginTop: "14px" } }, a.title), h("p", { class: "meta" }, [a.author, date(a.published_at)].filter(Boolean).join(" · "))));
  const b = html("div", { class: "wrap prose" }, a.body_html); b.addEventListener("click", e => { const l = e.target.closest("a[data-ext]"); if (l) { e.preventDefault(); openExternal(l.href); } }); add(root, b, h("div", { style: { height: "30px" } })); return root;
}
export async function paths() {
  const d = await api("/paths"), root = h("div"); add(root, header("Learning paths"));
  add(root, d.paths.length ? h("div", { class: "list card", style: { margin: "0 16px" } }, d.paths.map(p => h("a", { href: "#/path/" + p.slug }, h("div", { class: "grow" }, h("div", { style: { fontWeight: 650 } }, p.title), h("div", { class: "s" }, p.courses + " courses"), p.summary ? h("div", { class: "s" }, p.summary) : null)))) : empty("No paths yet", "")); return root;
}
export async function path({ slug }) {
  const p = (await api("/paths/" + slug)).path, root = h("div"); add(root, header(p.title), h("div", { class: "wrap" }, p.summary ? h("p", null, p.summary) : null, session.user ? h("div", null, progressBar(p.percent), h("p", { class: "meta" }, p.courses_done + " of " + p.courses_total + " courses completed")) : null));
  const st = { completed: ["ok", "Completed"], in_progress: ["blue", "In progress"], available: ["", "Available"], locked: ["warn", "Locked"] };
  add(root, h("div", { class: "grid", style: { marginTop: "12px" } }, p.steps.map((s, i) => h("div", null, courseCard(s.course), h("div", { style: { padding: "6px 4px" } }, h("span", { class: "pill " + (st[s.state]?.[0] || "") }, (i + 1) + ". " + (st[s.state]?.[1] || "")), s.requires.length ? h("span", { class: "meta" }, " Requires: " + s.requires.join(", ")) : null))))); return root;
}
export async function faith() {
  const d = await api("/faith"), root = h("div"); add(root, header("Faith & Spiritual Growth"));
  add(root, d.topics.length ? h("div", { class: "list card", style: { margin: "0 16px" } }, d.topics.map(t => h("a", { href: "#/faith/" + t.slug }, h("div", { class: "grow" }, h("div", { style: { fontWeight: 650 } }, t.name), h("div", { class: "s" }, t.items + " lessons" + (t.series ? " · " + t.series + " series" : "")), t.description ? h("div", { class: "s" }, t.description) : null)))) : empty("Coming soon", "")); return root;
}
export async function faithTopic({ slug }) {
  const d = await api("/faith/topics/" + slug), root = h("div"); add(root, header(d.topic.name));
  const lab = { open: "", signin: "Sign in", buy: "Paid" }; const icon = { video: "▶", audio: "♪", reading: "☰", study: "✎" };
  add(root, d.items.length ? h("div", { class: "list card", style: { margin: "0 16px" } }, d.items.map(i => h("a", { href: "#/faith-item/" + i.slug }, h("div", { style: { fontSize: "1.3rem", width: "28px" } }, icon[i.kind] || "•"), h("div", { class: "grow" }, h("div", { style: { fontWeight: 600 } }, i.title), h("div", { class: "s" }, [i.series, i.speaker, i.duration_min ? i.duration_min + " min" : null].filter(Boolean).join(" · "))), lab[i.state] ? h("span", { class: "pill warn" }, lab[i.state]) : null))) : empty("No lessons yet", "")); return root;
}
export async function faithItem({ slug }) {
  const i = (await api("/faith/items/" + slug)).item, root = h("div"); add(root, header(i.title, { right: iconBtn("share", "Share", () => share({ title: i.title, url: SITE + "/faith/lesson/" + i.slug })) }));
  if (i.state === "signin") { add(root, empty("Sign in to continue", "This lesson is free for members.", h("button", { class: "btn", onclick: () => go("/login") }, "Sign in"))); return root; }
  if (i.state === "buy") {
    await IAP.init().catch(() => {});
    add(root, empty("This lesson is part of a paid series", i.series || i.topic), ...i.buy.map(b => IAP.available() ? h("div", { class: "wrap" }, h("button", { class: "btn", style: { marginBottom: "10px" }, onclick: async (e) => { e.target.disabled = true; try { if (await IAP.buy(b.product_id)) toast("Processing your purchase…"); } catch (er) { toast(er.message, true); } e.target.disabled = false; } }, "Unlock " + b.title + (IAP.storePrice(b.product_id) ? " · " + IAP.storePrice(b.product_id) : ""))) : h("div", { class: "note" }, "Unlock \"" + b.title + "\" in the Dagba app on your phone.")));
    IAP.onPurchased(r => { if (r.ok) { toast("Unlocked."); location.reload(); } else toast(r.message || "Purchase could not be confirmed.", true); }); return root; }
  if (i.video && i.video.url) add(root, i.video.type === "iframe" ? h("iframe", { class: "video", src: i.video.url, allowfullscreen: true, title: i.title, sandbox: "allow-scripts allow-same-origin allow-presentation" }) : h("video", { class: "video", controls: true, playsinline: true, preload: "metadata", src: i.video.url }));
  if (i.audio && i.audio.url) add(root, h("div", { class: "wrap" }, h("div", { class: "sp" }), h("audio", { controls: true, preload: "metadata", src: i.audio.url, style: { width: "100%" } })));
  add(root, h("div", { class: "wrap" }, h("h2", { style: { marginTop: "14px" } }, i.title), i.scripture ? h("p", { class: "meta" }, i.scripture) : null)); if (i.body_html) { const b = html("div", { class: "wrap prose" }, i.body_html); add(root, b); } return root;
}
