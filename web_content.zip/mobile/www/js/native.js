import { SITE, APP_VERSION } from "./config.js";
import { api, net, session } from "./api.js";
import { routeForUrl, compareVersions } from "./util.js";
// Thin wrappers over Capacitor plugins. Every call degrades gracefully in a desktop browser (development) and when a plugin is missing.
const P = () => (window.Capacitor && window.Capacitor.Plugins) || {};
export const platform = () => (window.Capacitor && window.Capacitor.getPlatform ? window.Capacitor.getPlatform() : "web");
export const isNative = () => platform() !== "web";
export const device = () => ({ platform: platform(), app_version: APP_VERSION, device_name: (navigator.userAgent.match(/\(([^)]+)\)/) || [])[1]?.slice(0, 60) || "" });

export async function initNative({ onRoute, onNetwork, onBack }) {
  const { App, Network, StatusBar, SplashScreen, CapacitorUpdater } = P();
  try { if (CapacitorUpdater) await CapacitorUpdater.notifyAppReady(); } catch {}      // REQUIRED: tells the updater this bundle booted fine, otherwise it rolls back
  try { if (StatusBar) { await StatusBar.setStyle({ style: "LIGHT" }); if (platform() === "android") await StatusBar.setBackgroundColor({ color: "#7236E6" }); } } catch {}
  if (App) {
    App.addListener("appUrlOpen", e => { const r = routeForUrl(e.url, SITE); if (r) onRoute(r); });
    App.addListener("backButton", e => onBack(e));
    try { const l = await App.getLaunchUrl(); if (l && l.url) { const r = routeForUrl(l.url, SITE); if (r) onRoute(r); } } catch {}
  }
  if (Network) {
    try { const s = await Network.getStatus(); net.online = s.connected; onNetwork(s.connected, s.connectionType); } catch {}
    Network.addListener("networkStatusChange", s => { net.online = s.connected; onNetwork(s.connected, s.connectionType); });
  } else { addEventListener("online", () => onNetwork(true)); addEventListener("offline", () => onNetwork(false)); }
  try { if (SplashScreen) await SplashScreen.hide(); } catch {}
}
export function exitApp() { const { App } = P(); if (App) App.exitApp(); }

export async function openExternal(url) {
  if (!/^https:\/\//i.test(url)) return;                                    // never open arbitrary schemes
  const { Browser } = P(); if (Browser) return Browser.open({ url }); window.open(url, "_blank", "noopener");
}
export async function share({ title, text, url }) {
  const { Share } = P();
  try { if (Share) return await Share.share({ title, text, url, dialogTitle: "Share" }); if (navigator.share) return await navigator.share({ title, text, url }); } catch {}
  try { await navigator.clipboard.writeText(url); return "copied"; } catch {}
}

// Push: asks permission after sign-in, registers the device token with the backend, and routes taps to the right screen.
export async function setupPush(onRoute) {
  const { PushNotifications } = P(); if (!PushNotifications || !session.user) return;
  try {
    let perm = await PushNotifications.checkPermissions();
    if (perm.receive === "prompt" || perm.receive === "prompt-with-rationale") perm = await PushNotifications.requestPermissions();
    if (perm.receive !== "granted") return;
    PushNotifications.addListener("registration", t => api("/devices", { method: "POST", body: { token: t.value, platform: platform() } }).catch(() => {}));
    PushNotifications.addListener("pushNotificationActionPerformed", a => { const link = a.notification && a.notification.data && a.notification.data.link; if (link) onRoute(routeForUrl(SITE + link, SITE) || "/activity"); });
    await PushNotifications.register();
  } catch {}
}

// Live (web-layer) updates: only the HTML/CSS/JS in www/ may be replaced; the backend publishes {version,url,sha256}. Native changes always need a store release.
export async function checkLiveUpdate(cfg) {
  const { CapacitorUpdater } = P(); const lu = cfg && cfg.live_update; if (!CapacitorUpdater || !lu || !lu.version || !lu.url) return false;
  if (lu.min_native && compareVersions(APP_VERSION, lu.min_native) < 0) return false;      // this binary is too old for that bundle: needs a store update
  try {
    const cur = await CapacitorUpdater.current(); if (cur && cur.bundle && cur.bundle.version === lu.version) return false;
    const b = await CapacitorUpdater.download({ url: lu.url, version: lu.version, checksum: lu.sha256 || undefined });
    await CapacitorUpdater.next({ id: b.id }); return true;                              // applied on the next app launch (never interrupts a lesson)
  } catch { return false; }
}
