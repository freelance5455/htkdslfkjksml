import { h, naira, mins } from "./util.js";
import { net } from "./api.js";
export const ICON = { back: "M15 18l-6-6 6-6", share: "M4 12v7a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-7M16 6l-4-4-4 4M12 2v14", search: "M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM21 21l-4.3-4.3", check: "M5 12l5 5L20 7", chev: "M9 6l6 6-6 6" };
export function icon(name, cls) { const s = document.createElementNS("http://www.w3.org/2000/svg", "svg"); s.setAttribute("viewBox", "0 0 24 24"); if (cls) s.setAttribute("class", cls); const p = document.createElementNS("http://www.w3.org/2000/svg", "path"); p.setAttribute("d", ICON[name]); s.append(p); return s; }
export const iconBtn = (name, label, onclick, cls = "") => h("button", { class: "iconbtn " + cls, "aria-label": label, onclick }, icon(name));
export function toast(msg, bad) { const t = document.getElementById("toast"); t.textContent = msg; t.className = "toast" + (bad ? " bad" : ""); t.hidden = false; clearTimeout(toast.t); toast.t = setTimeout(() => (t.hidden = true), 3500); }
export function header(title, { back = true, right } = {}) { return h("div", { class: "top" }, back ? iconBtn("back", "Back", () => history.back()) : null, h("h1", null, title), right || null); }
export function skeleton(n = 3) { return h("div", { class: "wrap", "aria-busy": "true" }, Array.from({ length: n }, () => h("div", { class: "skel", style: { height: "92px", margin: "12px 0" } }))); }
export function empty(title, text, action) { return h("div", { class: "empty" }, h("h3", null, title), h("p", null, text), action || null); }
export function errorState(e, retry) { return h("div", { class: "empty" }, h("h3", null, e && e.code === "offline" ? "You're offline" : "Couldn't load this"), h("p", null, e && e.message), retry ? h("button", { class: "btn", onclick: retry }, "Try again") : null); }
export function progressBar(pct) { return h("div", { class: "progress", role: "progressbar", "aria-valuenow": pct, "aria-valuemin": 0, "aria-valuemax": 100 }, h("i", { style: { width: Math.max(0, Math.min(100, pct)) + "%" } })); }
const DIV = { academic: "Academic", income: "Income Skills", professional: "Professional", faith: "Faith" };
export function courseCard(c, { row = false } = {}) {
  const free = c.price_kobo === 0 && !c.purchase;
  return h("a", { class: "card ccard", href: "#/course/" + c.slug },
    h("div", { class: "img", style: c.thumbnail ? { backgroundImage: `url("${c.thumbnail}")` } : {}, role: "img", "aria-label": c.title }),
    h("div", { class: "b" }, h("div", { class: "t" }, c.title),
      h("div", { class: "meta" }, [c.division === "academic" ? (c.level === "advanced" ? "Advanced" : "Basic") : DIV[c.division], c.lessons ? c.lessons + " lessons" : null, mins(c.duration_min) || null].filter(Boolean).join(" · ")),
      c.access ? h("div", { class: "meta" }, h("span", { class: "pill ok" }, "Enrolled")) : h("div", { class: "price" + (free ? " free" : "") }, c.price_label)));
}
export function hrow(title, courses, more) { return courses.length ? h("section", { class: "sec" }, h("div", { class: "hd" }, h("h2", null, title), more ? h("a", { href: more }, "See all") : null), h("div", { class: "hscroll" }, courses.map(c => courseCard(c)))) : null; }
export function field(label, input) { return h("label", { class: "field" }, h("span", null, label), input); }
export function mount(el) { const v = document.getElementById("view"); v.replaceChildren(el); window.scrollTo(0, 0); }
export const staleNote = () => (net.stale ? h("div", { class: "note" }, "Showing saved content. Connect to the internet to refresh.") : null);
export { h, naira };
