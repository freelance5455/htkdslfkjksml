import { h, add, html, mins, date, ago } from "./util.js";
import { api, session, ApiError, net } from "./api.js";
import { go } from "./state.js";
import { SITE } from "./config.js";
import { header, iconBtn, toast, empty, courseCard, progressBar, field, staleNote } from "./ui.js";
import { openExternal, share } from "./native.js";

const needLogin = () => h("div", null, header("My Learning", { back: false }), empty("Sign in to learn", "Your courses, progress and certificates appear here.", h("button", { class: "btn", onclick: () => go("/login") }, "Sign in")));

// ---------------------------------------------------------------- My Learning
export async function learning() {
  if (!session.user) return needLogin();
  const d = await api("/my/learning"); let tab = "progress"; const body = h("div"), tabs = h("div", { class: "tabsbar" });
  const views = {
    progress: () => d.in_progress.length ? h("div", { class: "grid", style: { marginTop: "14px" } }, d.in_progress.map(c => h("div", null, courseCard(c), h("div", { style: { padding: "6px 4px 0" } }, progressBar(c.progress.percent), h("div", { class: "meta" }, c.progress.percent + "% · " + c.progress.done + " of " + c.progress.total + " lessons"))))) : empty("Nothing in progress", "Find a course and start learning today.", h("button", { class: "btn", onclick: () => go("/explore") }, "Browse courses")),
    completed: () => d.completed.length ? h("div", { class: "grid", style: { marginTop: "14px" } }, d.completed.map(c => courseCard(c))) : empty("No completed courses yet", "Finish all lessons to earn your certificate."),
    paths: () => d.paths.length ? h("div", { class: "list card", style: { margin: "14px 16px" } }, d.paths.map(p => h("a", { href: "#/path/" + p.slug }, h("div", { class: "grow" }, h("div", null, p.title), h("div", { class: "s" }, p.courses_done + " of " + p.courses_total + " courses"), h("div", { style: { marginTop: "6px" } }, progressBar(p.percent)))))) : empty("No learning paths started", "Paths group courses into a guided journey.", h("button", { class: "btn", onclick: () => go("/paths") }, "See paths")),
    history: () => d.history.length ? h("div", { class: "list card", style: { margin: "14px 16px" } }, d.history.map(x => h("div", null, h("div", { class: "grow" }, h("div", null, (x.text ? x.text + ": " : "") + (x.title || "")), h("div", { class: "s" }, (x.course || "") + (x.at ? " · " + ago(x.at) : "")))))) : empty("No history yet", ""),
  };
  const draw = () => { tabs.replaceChildren(...[["progress", "In progress"], ["completed", "Completed"], ["paths", "Paths"], ["history", "History"]].map(([k, t]) => h("button", { class: tab === k ? "on" : "", onclick: () => { tab = k; draw(); } }, t))); body.replaceChildren(views[tab]()); };
  draw();
  return h("div", null, header("My Learning", { back: false, right: h("button", { class: "btn sm sec2", onclick: () => go("/certificates") }, d.certificates + " certificate" + (d.certificates === 1 ? "" : "s")) }), staleNote(), tabs, body);
}

// ---------------------------------------------------------------- Course learning view
export async function learn({ slug }) {
  const d = await api("/learn/" + slug), c = d.course; const root = h("div");
  add(root, header(c.title), h("div", { class: "wrap" }, progressBar(d.progress.percent), h("p", { class: "meta" }, d.progress.percent + "% complete · " + d.progress.done + " of " + d.progress.total + " lessons")));
  if (d.resume_lesson_id) add(root, h("div", { class: "wrap" }, h("button", { class: "btn", onclick: () => go("/lesson/" + d.resume_lesson_id) }, d.progress.done ? "Resume learning" : "Start learning")));
  for (const m of d.curriculum) add(root, h("div", null, h("div", { class: "modh" }, m.title), m.lessons.map(l => h("div", { class: "lesson" + (l.done ? " done" : "") + (l.opens_at ? " locked" : ""), onclick: () => l.opens_at ? toast("Opens on " + l.opens_at) : go("/lesson/" + l.id) },
    h("div", { class: "dot" }, l.done ? "✓" : ""), h("div", { style: { flex: 1 } }, h("div", null, l.title), h("div", { class: "meta" }, [l.kind, mins(l.duration_min), l.opens_at ? "Opens " + l.opens_at : null].filter(Boolean).join(" · "))), l.opens_at ? "🔒" : null))));
  if (d.quizzes.length) add(root, h("div", { class: "modh" }, "Quizzes"), h("div", { class: "list" }, d.quizzes.map(z => h("button", { onclick: () => go("/quiz/" + z.id) }, h("div", { class: "grow" }, h("div", null, z.title), h("div", { class: "s" }, "Pass mark " + z.pass_mark + "%" + (z.best_percent != null ? " · Best " + z.best_percent + "%" : ""))), z.passed ? h("span", { class: "pill ok" }, "Passed") : null))));
  if (d.assignments.length) add(root, h("div", { class: "modh" }, "Assignments"), h("div", { class: "list" }, d.assignments.map(a => h("button", { onclick: () => go("/assignment/" + a.id) }, h("div", { class: "grow" }, h("div", null, a.title), h("div", { class: "s" }, a.due_date ? "Due " + a.due_date : "No due date")), a.status ? h("span", { class: "pill " + (a.status === "reviewed" ? "ok" : "blue") }, a.status === "reviewed" ? "Reviewed" : "Submitted") : null))));
  if (d.announcements.length) add(root, h("div", { class: "modh" }, "Announcements"), h("div", { class: "list" }, d.announcements.map(a => h("div", null, h("div", { class: "grow" }, h("div", null, a.title), h("div", { class: "s" }, a.body), h("div", { class: "s" }, ago(a.created_at)))))));
  add(root, h("div", { class: "sp" }), h("div", { class: "wrap" }, h("button", { class: "btn line", onclick: () => go("/discussion/" + slug) }, "Discussion (" + d.discussion_count + ")"), h("div", { class: "sp" }),
    d.certificate.cert_id ? h("button", { class: "btn sec2", onclick: () => go("/certificates") }, "View certificate")
      : h("button", { class: "btn sec2", onclick: async (e) => { e.target.disabled = true; try { await api("/learn/" + slug + "/certificate", { method: "POST" }); toast("Your certificate is ready."); go("/certificates"); } catch (er) { toast(er.message, true); } e.target.disabled = false; } }, "Claim certificate"), d.certificate.reasons && d.certificate.reasons.length && !d.certificate.cert_id ? h("p", { class: "meta" }, d.certificate.reasons.join(" ")) : null), h("div", { style: { height: "30px" } }));
  return root;
}

// ---------------------------------------------------------------- Lesson player
export async function lesson({ id }) {
  const d = await api("/lessons/" + id), l = d.lesson; const root = h("div");
  add(root, header(l.title, { right: iconBtn("share", "Share", () => share({ title: l.title, url: SITE + "/learn/" + l.course_slug })) }));
  let timer, last = 0;
  if (l.video && l.video.type === "file") {
    const v = h("video", { class: "video", controls: true, playsinline: true, preload: "metadata", src: l.video.url, controlslist: "nodownload" });
    v.addEventListener("loadedmetadata", () => { if (l.position_seconds > 5 && l.position_seconds < v.duration - 5) v.currentTime = l.position_seconds; });
    const save = () => { const p = Math.floor(v.currentTime); if (p && p !== last && net.online) { last = p; api("/lessons/" + id + "/progress", { method: "POST", body: { position: p } }).catch(() => {}); } };
    timer = setInterval(() => { if (!document.contains(v)) { clearInterval(timer); return; } if (!v.paused) save(); }, 15000); v.addEventListener("pause", save);
    v.addEventListener("error", () => toast("Video could not play. Check your connection and try again.", true));
    add(root, v);
  } else if (l.video && l.video.type === "iframe") add(root, h("iframe", { class: "video", src: l.video.url, allow: "autoplay; fullscreen; picture-in-picture", allowfullscreen: true, referrerpolicy: "strict-origin-when-cross-origin", title: l.title, sandbox: "allow-scripts allow-same-origin allow-presentation" }));
  else if (l.video && l.video.type === "video") add(root, h("video", { class: "video", controls: true, playsinline: true, preload: "metadata", src: l.video.url }));
  add(root, h("div", { class: "wrap" }, h("div", { class: "sp" }), h("h2", null, l.title), h("p", { class: "meta" }, [l.kind, mins(l.duration_min)].filter(Boolean).join(" · "))));
  if (l.body_html) { const b = html("div", { class: "wrap prose" }, l.body_html); b.addEventListener("click", e => { const a = e.target.closest("a[data-ext]"); if (a) { e.preventDefault(); openExternal(a.href); } }); add(root, b); }
  if (l.resource) add(root, h("div", { class: "wrap" }, h("div", { class: "sp" }), h("button", { class: "btn line", onclick: () => openExternal(l.resource.url) }, "Download: " + l.resource.name)));
  const bar = h("div", { class: "bar" });
  const doneBtn = h("button", { class: "btn" + (l.done ? " sec2" : ""), onclick: async (e) => { if (!l.access || l.access === "preview") { toast("Enrol to track your progress."); return; } e.target.disabled = true; try { const r = await api("/lessons/" + id + "/complete", { method: "POST" }); l.done = true; toast("Lesson complete · " + r.progress.percent + "%"); l.next_id ? go("/lesson/" + l.next_id) : go("/learn/" + l.course_slug); } catch (er) { toast(er.message, true); e.target.disabled = false; } } }, l.done ? (l.next_id ? "Next lesson" : "Finish") : (l.next_id ? "Complete & continue" : "Mark complete"));
  if (l.prev_id) bar.append(h("button", { class: "btn line", style: { flex: ".4" }, onclick: () => go("/lesson/" + l.prev_id) }, "Back")); bar.append(doneBtn);
  add(root, h("div", { class: "wrap" }, h("div", { class: "sp" }), h("button", { class: "btn line", onclick: () => go("/discussion/" + l.course_slug + "?lesson=" + id) }, "Ask a question")), h("div", { style: { height: "80px" } }), bar);
  return root;
}

// ---------------------------------------------------------------- Quiz
export async function quiz({ id }) {
  const d = await api("/quizzes/" + id), z = d.quiz; const root = h("div"), picks = {}, qs = h("div");
  add(root, header(z.title), h("div", { class: "wrap" }, h("p", { class: "meta" }, z.questions.length + " questions · pass mark " + z.pass_mark + "%" + (d.attempts.length ? " · last score " + d.attempts[0].score_percent + "%" : ""))), qs);
  const drawQ = (result) => qs.replaceChildren(...z.questions.map((q, i) => h("div", null, h("div", { class: "wrap", style: { marginTop: "14px", fontWeight: 650 } }, (i + 1) + ". " + q.prompt),
    q.options.map((o, n) => { const rv = result && result.review.find(r => r.question_id === q.id); const cls = rv ? (rv.correct === n + 1 ? " right" : rv.pick === n + 1 ? " wrong" : "") : (picks[q.id] === n + 1 ? " sel" : "");
      return h("div", { class: "opt" + cls, role: "radio", "aria-checked": picks[q.id] === n + 1, onclick: () => { if (result) return; picks[q.id] = n + 1; drawQ(); } }, h("span", null, o)); }),
    result && result.review.find(r => r.question_id === q.id)?.explanation ? h("div", { class: "note" }, result.review.find(r => r.question_id === q.id).explanation) : null)));
  drawQ();
  const submit = h("button", { class: "btn", onclick: async (e) => { if (Object.keys(picks).length < z.questions.length && !confirm("Some questions are unanswered. Submit anyway?")) return; e.target.disabled = true;
    try { const r = await api("/quizzes/" + id + "/submit", { method: "POST", body: { answers: picks } }); drawQ(r); window.scrollTo(0, 0); root.querySelector(".wrap").replaceChildren(h("div", { class: "card", style: { padding: "16px", textAlign: "center" } }, h("h2", null, r.percent + "%"), h("p", null, r.passed ? "Well done, you passed!" : "Not passed yet. Review the answers and try again."))); submit.textContent = "Back to course"; submit.onclick = () => go("/learn/" + z.course_slug); submit.disabled = false; }
    catch (er) { toast(er.message, true); e.target.disabled = false; } } }, "Submit answers");
  add(root, h("div", { style: { height: "80px" } }), h("div", { class: "bar" }, submit));
  return root;
}

// ---------------------------------------------------------------- Assignment (text + file/photo)
export async function assignment({ id }) {
  const d = await api("/assignments/" + id), a = d.assignment, s = d.submission; const root = h("div");
  const body = h("textarea", { placeholder: "Write your answer…", maxlength: 10000 }); body.value = s ? s.body || "" : "";
  const file = h("input", { type: "file", accept: "image/jpeg,image/png,application/pdf" }), msg = h("div", { class: "err", hidden: true }), locked = s && s.status === "reviewed";
  add(root, header(a.title), h("div", { class: "wrap" }, h("p", { style: { whiteSpace: "pre-line" } }, a.instructions || ""), h("p", { class: "meta" }, (a.due_date ? "Due " + a.due_date + " · " : "") + "Max score " + a.max_score)));
  if (s && s.status === "reviewed") add(root, h("div", { class: "note" }, h("strong", null, "Score: " + s.score + "/" + a.max_score), s.feedback ? h("p", null, s.feedback) : null));
  else if (s) add(root, h("div", { class: "note" }, "Submitted " + date(s.submitted_at) + ". You can update your answer until it is reviewed."));
  add(root, field("Your answer", body), field("Attach a photo or PDF (max 8 MB)", file), msg);
  if (s && s.file_name) add(root, h("p", { class: "meta", style: { margin: "0 16px" } }, "Current file: " + s.file_name));
  if (!locked) add(root, h("div", { class: "wrap" }, h("button", { class: "btn", onclick: async (e) => { msg.hidden = true; const f = file.files[0]; if (f && f.size > 8 * 1024 * 1024) { msg.textContent = "That file is larger than 8 MB."; msg.hidden = false; return; }
    const fd = new FormData(); fd.append("body", body.value); if (f) fd.append("file", f); e.target.disabled = true; e.target.textContent = "Uploading…";
    try { await api("/assignments/" + id + "/submit", { method: "POST", form: fd }); toast("Assignment submitted."); go("/learn/" + a.course_slug); } catch (er) { msg.textContent = er.message; msg.hidden = false; e.target.disabled = false; e.target.textContent = "Submit assignment"; } } }, "Submit assignment")));
  return root;
}

// ---------------------------------------------------------------- Discussions
export async function discussion({ slug }, q) {
  const lid = q.get("lesson"); const root = h("div"), list = h("div");
  const load = async () => { const d = await api("/courses/" + slug + "/discussions" + (lid ? "?lesson_id=" + lid : "")); list.replaceChildren(...(d.threads.length ? d.threads.map(t => h("div", { class: "card", style: { margin: "12px 16px", padding: "12px" } }, post(t), t.replies.map(r => h("div", { style: { marginLeft: "14px", paddingLeft: "10px", borderLeft: "2px solid var(--line)", marginTop: "10px" } }, post(r))), h("button", { class: "btn sm sec2", style: { marginTop: "10px" }, onclick: () => reply(t.id) }, "Reply"))) : [empty("No questions yet", "Be the first to ask.")])); };
  const post = (p) => h("div", null, h("div", { style: { fontWeight: 650, fontSize: ".9rem" } }, p.name, p.badge ? h("span", { class: "pill", style: { marginLeft: "6px" } }, p.badge) : null), h("div", { style: { whiteSpace: "pre-line" } }, p.removed ? "This post was removed." : p.body), h("div", { class: "meta" }, ago(p.created_at)));
  const box = h("textarea", { placeholder: "Ask a question or share something helpful…", maxlength: 2000, style: { minHeight: "80px" } });
  const send = async (parent) => { const t = box.value.trim(); if (!t) return; try { await api("/courses/" + slug + "/discussions", { method: "POST", body: { body: t, lesson_id: lid ? +lid : null, parent_id: parent || null } }); box.value = ""; toast("Posted."); await load(); } catch (e) { toast(e.message, true); } };
  const reply = (pid) => { box.focus(); box.placeholder = "Write your reply…"; box.dataset.parent = pid; };
  add(root, header("Discussion"), field("Your question", box), h("div", { class: "wrap" }, h("button", { class: "btn", onclick: () => { const p = box.dataset.parent; box.dataset.parent = ""; send(p ? +p : null); } }, "Post")), list);
  await load(); return root;
}

// ---------------------------------------------------------------- Certificates
export async function certificates() {
  if (!session.user) return needLogin();
  const d = await api("/my/certificates"); const root = h("div"); add(root, header("My certificates"));
  if (!d.certificates.length) { add(root, empty("No certificates yet", "Complete a course to earn your certificate.")); return root; }
  add(root, h("div", { class: "list card", style: { margin: "0 16px" } }, d.certificates.map(c => h("div", null, h("div", { class: "grow" }, h("div", null, c.course_title), h("div", { class: "s" }, "Issued " + date(c.issued_at) + " · " + c.cert_id)),
    h("button", { class: "btn sm", onclick: () => openExternal(c.pdf_url) }, "PDF"), h("button", { class: "btn sm sec2", onclick: () => share({ title: c.course_title, text: "My Dagba Digital Academy certificate", url: c.verify_url }) }, "Share")))));
  return root;
}
