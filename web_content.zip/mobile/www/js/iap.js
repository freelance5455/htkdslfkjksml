import { api } from "./api.js";
import { platform } from "./native.js";
// In-app purchases (Google Play Billing / Apple In-App Purchase) via cordova-plugin-purchase. The phone's store handles payment and shows the price;
// this app forwards the store's proof to POST /store/verify and the SERVER verifies it with Google/Apple before granting any access.
// UNTESTED against live stores (needs developer accounts + sandbox testers): see docs/STORE_BILLING.md for the test checklist.
const CdvPurchase = () => window.CdvPurchase;
let ready = null, products = [], onChange = () => {};

export const available = () => !!CdvPurchase() && (platform() === "android" || platform() === "ios");
export function onPurchased(fn) { onChange = fn; }

export async function init() {
  if (!available()) return false;
  if (ready) return ready;
  ready = (async () => {
    const { store, Platform, ProductType } = CdvPurchase();
    const plat = platform() === "ios" ? Platform.APPLE_APPSTORE : Platform.GOOGLE_PLAY;
    const d = await api("/store/products", { auth: false }); products = d.products;
    store.register(products.map(p => ({ id: p.product_id, type: p.type === "subscription" ? ProductType.PAID_SUBSCRIPTION : ProductType.NON_CONSUMABLE, platform: plat })));
    store.when().approved(async tx => {
      try {
        const body = platform() === "ios" ? { platform: "app_store", transaction_id: tx.transactionId }
          : { platform: "google_play", product_id: tx.products[0].id, purchase_token: (tx.nativePurchase && tx.nativePurchase.purchaseToken) || tx.purchaseToken, kind: products.find(p => p.product_id === tx.products[0].id)?.type === "subscription" ? "subscription" : "product" };
        await api("/store/verify", { method: "POST", body });
        await tx.finish(); onChange({ ok: true });
      } catch (e) { onChange({ ok: false, message: e.message }); }      // not finished: the store keeps the purchase so "Restore" can retry
    });
    await store.initialize([plat]);
    return true;
  })();
  return ready;
}
export function storePrice(productId) {
  const { store } = CdvPurchase() || {}; const p = store && store.get(productId); const o = p && p.getOffer && p.getOffer();
  return o && o.pricingPhases && o.pricingPhases[0] ? o.pricingPhases[0].price : null;      // localized price straight from the store
}
export async function buy(productId) {
  await init(); const { store } = CdvPurchase(); const p = store.get(productId);
  if (!p) throw new Error("This item is not available in the store yet. Please try again later.");
  const offer = p.getOffer(); if (!offer) throw new Error("This item is not available in the store yet.");
  const err = await offer.order(); if (err && err.isError) { if (err.code === CdvPurchase().ErrorCode.PAYMENT_CANCELLED) return false; throw new Error(err.message); }
  return true;
}
export async function restore() { await init(); const { store } = CdvPurchase(); await store.restorePurchases(); }
export const productFor = (type, id) => products.find(p => p.product_id === `dagba.${type}.${id}`);
