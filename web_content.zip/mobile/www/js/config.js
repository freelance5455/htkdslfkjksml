// The ONLY deployment setting in the app. Everything else (courses, prices, banners, text) comes from the backend API.
// Change API_BASE only when the production domain changes; that needs a new store build, so keep it on the permanent domain.
export const API_BASE = globalThis.__DAGBA_API_BASE__ || "https://dagbadigitalacademy.com";      // the override exists only for automated tests
export const SITE = API_BASE;
export const APP_VERSION = "1.0.0";       // keep equal to versionName/CFBundleShortVersionString; compared with /config min_app_version
export const BRAND = "#7236E6";
