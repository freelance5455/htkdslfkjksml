export const state = { config: null, contentVersion: null };
export const go = (path) => { location.hash = "#" + path; };
export const replace = (path) => { history.replaceState(null, "", "#" + path); window.dispatchEvent(new HashChangeEvent("hashchange")); };
