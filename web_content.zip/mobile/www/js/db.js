/* ==========================================================
   NOMIDMAN TRANS CO. LTD — data & business logic
   NOTE: This layer uses localStorage so the site runs fully
   in the browser for testing. In production, move these
   functions to a secure server (see README "Going live").
   ========================================================== */
(function () {
  const CFG = window.EA_CONFIG;
  const KEY = "ea_v1_db";
  const SESSION_KEY = "ea_v1_session";
  const DAY = 86400000;
  const now = () => Date.now();

  /* ---------- storage ---------- */
  function load() {
    try { return JSON.parse(localStorage.getItem(KEY)) || { users: [], listings: [], payments: [] }; }
    catch (e) { return { users: [], listings: [], payments: [] }; }
  }
  function save(d) {
    try { localStorage.setItem(KEY, JSON.stringify(d)); }
    catch (e) { throw new Error("storage_full"); }
  }
  let db = load();
  // Migrate listings saved earlier with the old "BP" code to "GBP"
  db.listings.forEach(l => { if (l.currency === "BP") l.currency = "GBP"; });
  if (!db.log) db.log = []; // admin activity log
  if (!db.referrals) db.referrals = [];
  if (!db.refSeq) db.refSeq = 0;

  /* ---------- crypto: salted PBKDF2 password hashing ---------- */
  const enc = new TextEncoder();
  const toHex = (buf) => [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, "0")).join("");
  function randomSalt() { return toHex(crypto.getRandomValues(new Uint8Array(16))); }
  async function hashPassword(pw, salt) {
    const key = await crypto.subtle.importKey("raw", enc.encode(pw), "PBKDF2", false, ["deriveBits"]);
    const bits = await crypto.subtle.deriveBits(
      { name: "PBKDF2", salt: enc.encode(salt), iterations: 60000, hash: "SHA-256" }, key, 256);
    return toHex(bits);
  }

  /* ---------- validation ---------- */
  const V = {
    phone: (p) => /^\+?[0-9]{9,15}$/.test((p || "").replace(/[\s-]/g, "")),
    email: (e) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e || ""),
    // Mixed characters: upper, lower, digit, symbol, min 8
    password: (p) => (p || "").length >= 8 && /[A-Z]/.test(p) && /[a-z]/.test(p) && /[0-9]/.test(p) && /[^A-Za-z0-9]/.test(p),
    normPhone: (p) => (p || "").replace(/[\s-]/g, ""),
    normEmail: (e) => (e || "").trim().toLowerCase(),
    // Format check for identity document numbers. Returns null if acceptable, else an error key.
    docNumber: (type, raw, country) => {
      const rule = idRule(type, country);
      const s = String(raw || "").replace(/[\s-]/g, "").toUpperCase();
      if (!rule) return "id_invalid_type";
      if (rule.digits && !/^[0-9]+$/.test(s)) return "id_invalid_digits";
      if (!rule.digits && !/^[A-Z0-9]+$/.test(s)) return "id_invalid_chars";
      if (rule.letters) {
        if (!new RegExp(`^[A-Z]{${rule.letters}}[0-9]+$`).test(s)) return "id_invalid_letters";
      }
      if (rule.lengths) {
        if (!rule.lengths.includes(s.length)) return "id_invalid_length";
      } else if (s.length < rule.min || s.length > rule.max) return "id_invalid_length";
      if (/^(.)\1+$/.test(s)) return "id_invalid_repeat";          // whole number is one repeated character
      const ascending = s.split("").every((c, i, a) => i === 0 || (+c) === ((+a[i - 1]) + 1) % 10);
      if (ascending && /^[0-9]+$/.test(s)) return "id_invalid_repeat"; // whole number is a simple run, e.g. 12345678
      return null;
    }
  };

  function idRule(type, country) {
    const r = CFG.idRules[type];
    if (!r) return null;
    if (type === "national_id" || type === "driving_permit" || type === "passport") {
      return r[country] || r.default;   // per-country rule, else default
    }
    return r;
  }
  /* Privacy masking of ID numbers, e.g. "CM1234567XY" -> "CM•••••7XY" */
  function maskId(id) {
    const s = String(id || "").replace(/\s/g, "");
    if (s.length <= 4) return "••••";
    return s.slice(0, 2) + "•".repeat(Math.max(3, s.length - 5)) + s.slice(-3);
  }
  /* Masks phone and email for public display when needed */
  function maskPhone(p) { return p ? p.slice(0, 4) + "•••" + p.slice(-3) : ""; }

  /* ---------- OTP ---------- */
  const otpStore = {}; // { target: { code, exp } } — in production the server holds these
  async function sendOTP(target) {
    const code = String(Math.floor(100000 + Math.random() * 900000));
    otpStore[target] = { code, exp: now() + 5 * 60000 };
    if (!CFG.demoMode) {
      await fetch(CFG.otpEndpoint, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ target }) });
      return { demoCode: null };
    }
    return { demoCode: code }; // demo only: shown in a toast
  }
  async function verifyOTP(target, code) {
    if (!CFG.demoMode) {
      const r = await fetch(CFG.otpVerifyEndpoint, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ target, code }) });
      return (await r.json()).ok === true;
    }
    const rec = otpStore[target];
    if (!rec || rec.exp < now()) return false;
    return rec.code === String(code).trim();
  }

  /* ---------- users & session ---------- */
  function findUserByLogin(id) {
    const e = V.normEmail(id), p = V.normPhone(id);
    return db.users.find(u => (e && u.email === e) || (p && u.phone === p)) || null;
  }
  function publicUser(u) {
    if (!u) return null;
    const { passwordHash, salt, idNumber, ...rest } = u; // never expose secrets
    return rest;
  }
  function currentUser() {
    const id = localStorage.getItem(SESSION_KEY);
    const u = db.users.find(x => x.id === id);
    return u && !u.suspended ? u : null;
  }
  function currentUserPublic() { return publicUser(currentUser()); }

  async function register(f) {
    // f: { firstName,lastName,age,gender,nationality,phone,email,idType,idNumber,role,password,phoneVerified,emailVerified }
    f.phone = V.normPhone(f.phone); f.email = V.normEmail(f.email);
    if (f.role === "owner" && !pendingRegistrationPayment(f.payRef)) throw new Error("payment_required");
    if (db.users.some(u => u.email === f.email || (f.phone && u.phone === f.phone))) throw new Error("exists");
    const salt = randomSalt();
    const user = {
      id: "u_" + Math.random().toString(36).slice(2, 10),
      role: f.role, // "owner" | "customer"
      firstName: f.firstName.trim(), lastName: f.lastName.trim(),
      age: +f.age, gender: f.gender, nationality: f.nationality,
      phone: f.phone, email: f.email,
      phoneVerified: !!f.phoneVerified, emailVerified: !!f.emailVerified,
      idType: f.idType, idMasked: maskId(f.idNumber),
      idNumber: await hashPassword(f.idNumber.replace(/\s/g, "").toUpperCase(), salt), // hashed, never shown
      salt, passwordHash: await hashPassword(f.password, salt),
      registrationPaid: false, subscription: null, saved: [], liked: [], savedSearches: [], verified: false,
      suspended: false, createdAt: now()
    };
    user.acceptedLegal = CFG.legal.version;
    db.users.push(user); save(db);
    if (user.role === "owner") { ensureRefCode(user); recordReferral(f.refCode, user); confirmRegistrationPayment(f.payRef, user.id); }
    localStorage.setItem(SESSION_KEY, user.id);
    return publicUser(user);
  }

  async function login(id, password) {
    const u = findUserByLogin(id);
    // admins must use the two-step admin sign-in (#/zero), never the ordinary Sign In button
    if (!u || u.suspended || u.role === "admin") return null;
    const h = await hashPassword(password, u.salt);
    if (h !== u.passwordHash) return null;
    localStorage.setItem(SESSION_KEY, u.id);
    return publicUser(u);
  }
  function logout() { localStorage.removeItem(SESSION_KEY); }
  // Check password only (no session). Used for two-step admin sign-in.
  async function checkCredentials(id, password) {
    const u = findUserByLogin(id);
    if (!u || u.suspended) return null;
    const h = await hashPassword(password, u.salt);
    return h === u.passwordHash ? publicUser(u) : null;
  }
  function startSession(userId) { localStorage.setItem(SESSION_KEY, userId); }

  async function resetPassword(id, password) {
    const u = findUserByLogin(id);
    if (!u) return false;
    u.salt = randomSalt();
    u.passwordHash = await hashPassword(password, u.salt);
    save(db); return true;
  }
  function userExists(id) { return !!findUserByLogin(id); }

  /* ---------- payments (demo = simulated; production = Flutterwave via backend) ---------- */
  // Flutterwave Inline checkout. The browser only opens the checkout and reports the transaction;
  // the server must verify it with Flutterwave and record the payment before any benefit applies.
  // Loads Flutterwave's checkout script only when a live payment starts (not on every visit)
  function loadFlutterwave() {
    if (typeof FlutterwaveCheckout === "function") return Promise.resolve();
    return new Promise((resolve, reject) => {
      const s = document.createElement("script");
      s.src = "https://checkout.flutterwave.com/v3.js";
      s.onload = () => (typeof FlutterwaveCheckout === "function" ? resolve() : reject(new Error("payment_script")));
      s.onerror = () => reject(new Error("payment_script"));
      document.head.appendChild(s);
    });
  }
  async function payFlutterwave({ amountUGX, purpose, plan, note, listingId }) {
    await loadFlutterwave();
    return new Promise((resolve, reject) => {
      const u = currentUser();
      const txRef = "EA" + Date.now().toString(36).toUpperCase();
      FlutterwaveCheckout({
        public_key: CFG.flutterwave.publicKey,
        tx_ref: txRef,
        amount: amountUGX,
        currency: CFG.flutterwave.currency,
        payment_options: CFG.flutterwave.paymentOptions,
        customer: {
          email: u ? u.email : "guest@e-asset.invalid",
          name: u ? `${u.firstName} ${u.lastName}` : "Guest",
          phonenumber: u ? u.phone : ""
        },
        customizations: { title: "NOMIDMAN TRANS", description: note || purpose },
        callback: async (data) => {
          try {
            const r = await fetch(CFG.flutterwave.verifyEndpoint, {
              method: "POST", headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ transaction_id: data.transaction_id, tx_ref: txRef, purpose, plan, listingId, amountUGX })
            });
            const j = await r.json();
            if (j.ok) resolve({ verified: true, ref: txRef }); else reject(new Error("payment_not_verified"));
          } catch (e) { reject(e); }
        },
        onclose: () => reject(new Error("payment_cancelled"))
      });
    });
  }
  async function pay({ amountUGX, purpose, plan, method, note, listingId, pending, creditUsed }) {
    if (!CFG.demoMode && CFG.paymentProvider === "flutterwave") {
      return payFlutterwave({ amountUGX, purpose, plan, note, listingId });
    }
    const ref = "EA" + Date.now().toString(36).toUpperCase();
    if (!CFG.demoMode) {
      // Production: the server creates the payment and returns a secure checkout URL.
      const r = await fetch(CFG.paymentEndpoint, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amountUGX, purpose, plan, method, userId: currentUser()?.id })
      });
      const data = await r.json();
      if (data.redirect_url) { window.location.href = data.redirect_url; return { pending: true }; }
      if (!data.ok) throw new Error("payment_failed");
      return recordPayment(data.ref || ref, { amountUGX, purpose, plan, method, note, listingId, status: pending ? "pending" : "paid", creditUsed });
    }
    await new Promise(r => setTimeout(r, 1200)); // simulated gateway round-trip
    return recordPayment(ref, { amountUGX, purpose, plan, method, note, listingId, status: pending ? "pending" : "paid", creditUsed });
  }
  function recordPayment(ref, { amountUGX, purpose, plan, method, note, listingId, status, creditUsed }) {
    if (purpose === "boost") {
      const l = db.listings.find(x => x.id === listingId && (!currentUser() || x.ownerId === currentUser().id));
      if (!l) throw new Error("not_found");
      const base = Math.max(now(), l.boostedUntil || 0);
      l.boostedUntil = base + CFG.boost.days * DAY;
      const pb = { id: ref, userId: currentUser().id, country: currentUser().nationality, purpose, plan: "", method,
        amountUGX, note: `boost ${l.title}`, status: "paid", date: now() };
      db.payments.push(pb); save(db); return pb;
    }
    const u = currentUser(); // may be null for anonymous appreciation gifts
    const p = { id: ref, userId: u ? u.id : null, country: u ? u.nationality : "Unknown",
      purpose, plan: plan || "", method, amountUGX, note: note || "", status: status || "paid", date: now() };
    db.payments.push(p);
    if (purpose === "registration" && u && (status || "paid") === "paid") u.registrationPaid = true;
    if (purpose === "subscription" && u) {
      const planObj = CFG.plans[plan];
      const base = u.subscription && u.subscription.plan === plan && u.subscription.expiresAt > now()
        ? u.subscription.expiresAt : now();
      u.subscription = { plan, limit: planObj.limit, expiresAt: base + planObj.days * DAY, startedAt: now() };
    }
    if (purpose === "subscription" && u && creditUsed) { u.credit = Math.max(0, (u.credit || 0) - creditUsed); u.creditUpdatedAt = now(); }
    save(db);
    settleReferrals();
    return p;
  }

  /* ---------- subscription status & listing visibility ---------- */
  // states: "none" | "active" | "expired" (hidden, still on dashboard) | "gone"
  function subState(u) {
    if (!u || !u.subscription) return "none";
    const t = now();
    if (t <= u.subscription.expiresAt) return "active";
    if (t <= u.subscription.expiresAt + CFG.graceDays * DAY) return "expired";
    return "gone";
  }
  function daysLeftBeforeDelete(u) {
    const left = (u.subscription.expiresAt + CFG.graceDays * DAY - now()) / DAY;
    return Math.max(0, Math.ceil(left));
  }
  // Remove listings whose grace period has ended (auto-deletion rule)
  // ---- owner referral codes and credit ----
  function nextRefCode() { db.refSeq = (db.refSeq || 0) + 1; return "NTO-" + String(db.refSeq).padStart(4, "0"); }
  function ensureRefCode(u) { if (u && !u.refCode) u.refCode = nextRefCode(); }
  // Records a referral when a new owner registers with a valid code (no self-referrals)
  function recordReferral(code, newUser) {
    if (!code) return;
    const referrer = db.users.find(u => u.role === "owner" && u.refCode === code);
    if (!referrer || referrer.id === newUser.id) return;
    if (newUser.phone && newUser.phone === referrer.phone) return;
    if (newUser.email && newUser.email === referrer.email) return;
    db.referrals.push({ id: "r_" + Math.random().toString(36).slice(2, 9), referrerId: referrer.id, referredId: newUser.id, status: "pending", createdAt: now() });
    save(db);
  }
  // Credit is released when the referred owner has registered AND completed a subscription plan
  function settleReferrals() {
    let changed = false;
    db.referrals.forEach(r => {
      if (r.status !== "pending") return;
      const referred = db.users.find(x => x.id === r.referredId);
      const referrer = db.users.find(x => x.id === r.referrerId);
      if (!referred || !referrer || referred.role !== "owner") return;
      const subscribed = db.payments.some(p => p.userId === referred.id && p.purpose === "subscription" && p.status === "paid");
      if (!subscribed) return;
      referrer.credit = (creditBalance(referrer) || 0) + CFG.referral.bonusUGX;
      referrer.creditUpdatedAt = now();
      r.status = "credited"; r.creditedAt = now(); changed = true;
    });
    if (changed) save(db);
  }
  // Unused credit lapses after the configured number of months with no use
  function creditBalance(u) {
    if (!u || !u.credit) return 0;
    const expiresAt = (u.creditUpdatedAt || now()) + CFG.referral.expiryMonths * 30 * DAY;
    if (now() > expiresAt) { u.credit = 0; save(db); return 0; }
    return u.credit;
  }
  function creditExpiryDate(u) { return (u.creditUpdatedAt || now()) + CFG.referral.expiryMonths * 30 * DAY; }

  // ---- customer contact verification and upgrade to owner ----
  // Customers can add a phone number later and verify it, then upgrade to owner.
  function updateMyPhone(phone) {
    const u = currentUser(); if (!u) throw new Error("not_signed_in");
    const p = V.normPhone(phone);
    if (!V.phone(p)) throw new Error("phone_invalid");
    if (db.users.some(x => x.id !== u.id && x.phone === p)) throw new Error("exists");
    u.phone = p; u.phoneVerified = false; save(db);
  }
  function markContactVerified(kind) {
    const u = currentUser(); if (!u) return;
    if (kind === "phone") u.phoneVerified = true;
    if (kind === "email") u.emailVerified = true;
    save(db);
    // both contacts verified and the payment is on hold: the upgrade completes automatically
    if (u.phoneVerified && u.emailVerified && u.role === "customer" && heldUpgradePayment()) completeUpgrade();
  }
  // Holds the upgrade fee as a pending payment (only for verified customers)
  async function beginUpgrade(method) {
    const u = currentUser(); if (!u || u.role !== "customer") throw new Error("not_eligible");
    const p = await pay({ amountUGX: CFG.registrationFee, purpose: "registration", method, pending: true });
    u.upgradeRef = p.id; save(db); return p;
  }
  function heldUpgradePayment() {
    const u = currentUser(); if (!u || !u.upgradeRef) return null;
    return db.payments.find(x => x.id === u.upgradeRef && x.status === "pending") || null;
  }
  // Completes the upgrade once the held fee is confirmed (refused if the 24-hour hold has lapsed)
  function completeUpgrade() {
    const u = currentUser(); const p = heldUpgradePayment();
    if (!p) throw new Error("no_held_payment");
    if (now() - p.date > 24 * 60 * 60 * 1000) throw new Error("hold_expired");
    p.status = "paid"; p.userId = u.id;
    u.role = "owner"; u.registrationPaid = true; u.upgradeRef = null; ensureRefCode(u);
    save(db); return u;
  }
  // A held owner registration payment, not yet confirmed
  function pendingRegistrationPayment(ref) {
    return db.payments.find(x => x.id === ref && x.purpose === "registration" && x.status === "pending") || null;
  }
  // Called once the owner's phone and email are both verified
  function confirmRegistrationPayment(ref, userId) {
    const p = pendingRegistrationPayment(ref);
    if (!p) return false;
    p.status = "paid"; p.userId = userId;
    const u = db.users.find(x => x.id === userId);
    if (u) u.registrationPaid = true;
    save(db); return true;
  }
  // Refund rule: a held payment not confirmed within 24 hours is marked for refund
  function releaseStalePendingPayments() {
    let changed = false;
    db.payments.forEach(p => {
      if (p.status === "pending" && now() - p.date > 24 * 60 * 60 * 1000) { p.status = "refund_due"; changed = true; }
    });
    if (changed) save(db);
  }
  function purgeExpired() {
    releaseStalePendingPayments();
    let changed = false;
    db.users.forEach(u => {
      if (u.role === "owner" && subState(u) === "gone") {
        const before = db.listings.length;
        db.listings = db.listings.filter(l => l.ownerId !== u.id);
        if (db.listings.length !== before) changed = true;
      }
    });
    // 30 days after an account is closed, its information is removed (payment amounts are kept, unlinked from the person)
    const before = db.users.length;
    db.users = db.users.filter(u => {
      if (!u.closedAt || now() - u.closedAt < 30 * 24 * 3600 * 1000) return true;
      db.listings = db.listings.filter(l => l.ownerId !== u.id);
      db.payments.forEach(p => { if (p.userId === u.id) p.userId = null; });
      return false;
    });
    if (db.users.length !== before) changed = true;
    if (changed) save(db);
  }
  function isVisible(listing) {
    if (listing.removedByAdmin) return false;
    const owner = db.users.find(u => u.id === listing.ownerId);
    return !!owner && !owner.suspended && subState(owner) === "active";
  }

  /* ---------- listings ---------- */
  function listingsForOwner(ownerId) { return db.listings.filter(l => l.ownerId === ownerId); }
  // Account closure: the owner can close the account, and it can be restored within 30 days
  function closeAccount() { const u = currentUser(); if (!u) return; u.closedAt = now(); save(db); }
  function restoreAccount() { const u = currentUser(); if (!u) return; u.closedAt = null; save(db); }
  function acceptLegal(version) { const u = currentUser(); if (!u) return; u.acceptedLegal = version; save(db); }
  function publicListings() {
    purgeExpired();
    return db.listings.filter(l => { const o = db.users.find(x => x.id === l.ownerId); return isVisible(l) && !(o && o.closedAt); });
  }
  function getListing(id) { return db.listings.find(l => l.id === id) || null; }
  function ownerOf(listing) { const o = db.users.find(u => u.id === listing.ownerId); return publicOwner(o); }
  function publicOwner(o) {
    if (!o) return null;
    return { id: o.id, name: o.firstName + " " + o.lastName, phone: o.phone, email: o.email, idMasked: o.idMasked, verified: !!o.verified };
  }

  function canAddListing(u) {
    if (!u.registrationPaid) return { ok: false, reason: "need_registration" };
    const s = subState(u);
    if (s === "none") return { ok: false, reason: "need_subscription" };
    if (s !== "active") return { ok: false, reason: "limit_reached" };
    const used = listingsForOwner(u.id).length;
    if (used >= u.subscription.limit) return { ok: false, reason: "limit_reached" };
    return { ok: true };
  }

  function saveListing(ownerId, data, editId) {
    const u = db.users.find(x => x.id === ownerId);
    if (!editId) {
      const check = canAddListing(u);
      if (!check.ok) throw new Error(check.reason);
    }
    if ((data.photos || []).length > photoLimitFor(u)) throw new Error("photo_limit");
    if (editId) {
      const l = db.listings.find(x => x.id === editId && x.ownerId === ownerId);
      if (!l) throw new Error("not_found");
      const prev = { ...l };
      Object.assign(l, data, { updatedAt: now() });
      try { save(db); } catch (e) { Object.assign(l, prev); throw e; }
      return l;
    }
    const l = { id: "l_" + Math.random().toString(36).slice(2, 10), ownerId, ...data,
      likes: [], createdAt: now(), updatedAt: now() };
    db.listings.push(l);
    try { save(db); } catch (e) { db.listings = db.listings.filter(x => x !== l); throw e; }
    return l;
  }

  /* ---------- photos ---------- */
  // Max photos allowed by the owner's current plan (0 if no subscription)
  function photoLimitFor(u) {
    if (!u || !u.subscription) return 0;
    const p = CFG.plans[u.subscription.plan];
    return p ? p.photos : 0;
  }
  function loadImage(file) {
    return new Promise((resolve, reject) => {
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.onload = () => { URL.revokeObjectURL(url); resolve(img); };
      img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("photo_read")); };
      img.src = url;
    });
  }
  // Validates type and size, resizes to maxWidth, returns a JPEG data URL
  async function processPhoto(file) {
    const PH = CFG.photos;
    if (!PH.types.includes(file.type)) throw new Error("photo_type");
    if (file.size > PH.maxBytes) throw new Error("photo_size");
    const img = await loadImage(file);
    let scale = Math.min(1, PH.maxWidth / img.width);
    let quality = PH.quality;
    let out = null;
    // Resize and compress until the stored photo is within the 4 MB limit
    for (let attempt = 0; attempt < 12; attempt++) {
      const w = Math.max(1, Math.round(img.width * scale)), h = Math.max(1, Math.round(img.height * scale));
      const canvas = document.createElement("canvas");
      canvas.width = w; canvas.height = h;
      const ctx = canvas.getContext("2d");
      ctx.fillStyle = "#ffffff"; ctx.fillRect(0, 0, w, h); // flatten transparency (PNG/WebP)
      ctx.drawImage(img, 0, 0, w, h);
      out = canvas.toDataURL("image/jpeg", quality);
      const bytes = Math.round((out.length - out.indexOf(",") - 1) * 3 / 4);
      if (bytes <= PH.maxOutBytes) return out;
      if (quality > 0.5) quality -= 0.1; else scale *= 0.85;
    }
    return out; // best effort
  }
  function deleteListing(ownerId, id) {
    db.listings = db.listings.filter(l => !(l.id === id && l.ownerId === ownerId));
    save(db);
  }

  function toggleLike(listingId) {
    const u = currentUser(); if (!u) return null;
    const l = db.listings.find(x => x.id === listingId); if (!l) return null;
    const has = u.liked.includes(listingId);
    u.liked = has ? u.liked.filter(x => x !== listingId) : [...u.liked, listingId];
    l.likes = has ? l.likes.filter(x => x !== u.id) : [...l.likes, u.id];
    save(db); return !has;
  }
  function toggleSave(listingId) {
    const u = currentUser(); if (!u) return null;
    const has = u.saved.includes(listingId);
    u.saved = has ? u.saved.filter(x => x !== listingId) : [...u.saved, listingId];
    save(db); return !has;
  }

  /* ---------- admin ---------- */
  function stats() {
    purgeExpired();
    const owners = db.users.filter(u => u.role === "owner");
    return {
      users: db.users.length,
      owners: owners.length,
      live: db.listings.filter(isVisible).length,
      hidden: db.listings.filter(l => !isVisible(l)).length,
      revenue: db.payments.filter(p => p.status === "paid").reduce((a, p) => a + p.amountUGX, 0)
    };
  }
  // Country for a payment: stored value, else the owner's nationality
  function paymentCountry(p) {
    if (p.country) return p.country;
    const o = db.users.find(u => u.id === p.userId);
    return (o && o.nationality) || "Unknown";
  }
  // Revenue split by subscription type (registration/budget/economy/premium) and by country
  function revenueBreakdown() {
    const byPlan = { registration: { count: 0, ugx: 0 }, budget: { count: 0, ugx: 0 }, economy: { count: 0, ugx: 0 }, premium: { count: 0, ugx: 0 }, gift: { count: 0, ugx: 0 } };
    const byCountry = {};
    db.payments.filter(p => p.status === "paid").forEach(p => {
      const key = p.purpose === "registration" ? "registration" : p.purpose === "gift" ? "gift" : p.plan;
      if (!byPlan[key]) byPlan[key] = { count: 0, ugx: 0 };
      byPlan[key].count++; byPlan[key].ugx += p.amountUGX;
      const c = paymentCountry(p);
      if (!byCountry[c]) byCountry[c] = { registration: 0, budget: 0, economy: 0, premium: 0, gift: 0, total: 0 };
      byCountry[c][key] = (byCountry[c][key] || 0) + p.amountUGX;
      byCountry[c].total += p.amountUGX;
    });
    return { byPlan, byCountry };
  }
  function isBoosted(l) { return !!l.boostedUntil && l.boostedUntil > now(); }
  function logAction(actor, action, target) {
    db.log.push({ ts: now(), actor, action, target });
    if (db.log.length > 500) db.log = db.log.slice(-500);
    save(db);
  }
  function activityLog() { return db.log.slice().reverse(); }
  // Counts a view, never for the listing's own owner
  function recordView(listingId) {
    const l = db.listings.find(x => x.id === listingId); if (!l) return;
    const u = currentUser(); if (u && u.id === l.ownerId) return;
    l.views = (l.views || 0) + 1; save(db);
  }
  function recordContact(listingId) {
    const l = db.listings.find(x => x.id === listingId); if (!l) return;
    l.contactClicks = (l.contactClicks || 0) + 1; save(db);
  }
  function toggleOwnerVerified(id) {
    const u = db.users.find(x => x.id === id && x.role === "owner"); if (!u) return;
    u.verified = !u.verified; logAction("admin", u.verified ? "verify_owner" : "unverify_owner", u.email); save(db);
  }
  function addSavedSearch(name, filters) {
    const u = currentUser(); if (!u) return null;
    const s = { id: "s_" + Math.random().toString(36).slice(2, 8), name, filters, createdAt: now() };
    u.savedSearches = [...(u.savedSearches || []), s]; save(db); return s;
  }
  function removeSavedSearch(id) {
    const u = currentUser(); if (!u) return;
    u.savedSearches = (u.savedSearches || []).filter(s => s.id !== id); save(db);
  }
  function allUsers() { return db.users.map(publicUser); }
  function allListings() { return db.listings; }
  function allPayments() { return db.payments; }
  function setUserSuspended(id, val) { const u = db.users.find(x => x.id === id); if (u) { u.suspended = val; logAction("admin", val ? "suspend_user" : "activate_user", u.email); } }
  function setListingRemoved(id, val) { const l = db.listings.find(x => x.id === id); if (l) { l.removedByAdmin = val; logAction("admin", val ? "remove_listing" : "restore_listing", l.title); } }
  function deleteUser(id) {
    const gone = db.users.find(u => u.id === id);
    if (gone) logAction("admin", "delete_user", gone.email);
    db.users = db.users.filter(u => u.id !== id);
    db.listings = db.listings.filter(l => l.ownerId !== id);
    save(db);
  }

  /* ---------- seed demo data & admin (first run only) ---------- */
  async function seed() {
    if (!db.users.some(u => u.role === "admin")) {
      const salt = randomSalt();
      db.users.push({ id: "admin_1", role: "admin", firstName: "Site", lastName: "Administrator",
        age: 35, gender: "male", nationality: "Uganda", phone: "+256700000001", email: "admin@e-asset.co.ug",
        phoneVerified: true, emailVerified: true, idType: "national_id", idMasked: "CM••••••XYZ",
        idNumber: "", salt, passwordHash: await hashPassword("Admin@EAsset2026", salt),
        registrationPaid: true, subscription: null, saved: [], liked: [], suspended: false, createdAt: now() });
    }
    if (!db.users.some(u => u.role === "owner")) {
      const salt = randomSalt();
      const owner = { id: "owner_demo", role: "owner", verified: true, savedSearches: [], firstName: "Grace", lastName: "Nakato",
        age: 42, gender: "female", nationality: "Uganda", phone: "+256772000111", email: "grace@example.com",
        phoneVerified: true, emailVerified: true, idType: "national_id", idMasked: "CM••••••84Q",
        idNumber: "", salt, passwordHash: await hashPassword("Owner@1234", salt),
        registrationPaid: true, subscription: { plan: "economy", limit: 13, expiresAt: now() + 80 * DAY, startedAt: now() - 11 * DAY },
        saved: [], liked: [], suspended: false, createdAt: now() };
      db.users.push(owner);
      const samples = [
        { category: "plot", listingType: "sale", country: "UGA", location: ["CENTRAL", "KASANDA", "KAMULI", "KAMULI", "KAKINDU"], title: "Titled 2-acre plot near Kamuli town", price: 85000000, currency: "UGX", description: "Freehold titled land, all-weather road access, electricity line 300 m away, ideal for farming or a residential development.", features: ["f_titled", "f_road", "f_elec_access", "f_market", "f_expansion"], payment: ["pt_full", "pt_installment"] },
        { category: "house", listingType: "rent", country: "UGA", location: ["CENTRAL", "KASANDA", "KAMULI", "KAMULI", "KAMULI"], title: "Self-contained double room, fenced compound", price: 350000, currency: "UGX", description: "Clean self-contained double room with tiled floor, borehole water, solar and CCTV. Resident landlord.", features: ["f_double_rooms", "f_self_contained", "f_fenced", "f_solar", "f_camera", "f_water", "f_tiled", "f_resident_landlord"], rent: ["rd_monthly", "rd_quarterly"] },
        { category: "commercial", listingType: "rent", country: "UGA", location: ["CENTRAL", "KASANDA", "KAMULI", "KAMULI", "KAMULI"], title: "Ground-floor shop on the main road", price: 600000, currency: "UGX", description: "Busy ground-floor commercial premises with parking space and reliable electricity.", features: ["f_ground_floor", "f_parking", "f_electricity", "f_cemented"], rent: ["rd_monthly", "rd_yearly"] },
        { category: "auto", listingType: "sale", country: "UGA", location: ["CENTRAL", "KASANDA", "KAMULI", "KAMULI", "KAMULI"], title: "Toyota Premio 2015, logbook available", price: 32000, currency: "USD", description: "Well maintained, insured, tyres in good condition. Price is indicative in USD.", features: ["f_automatic", "f_petrol", "f_logbook", "f_insured"], payment: ["pt_full"] }
      ];
      samples.forEach((s, i) => {
        db.listings.push({ id: "sample_" + i, ownerId: owner.id, category: s.category, listingType: s.listingType,
          country: s.country, location: s.location, title: s.title, description: s.description, price: s.price,
          currency: s.currency, features: s.features, paymentTerms: s.payment || [], rentDurations: s.rent || [],
          likes: [], createdAt: now() - i * DAY, updatedAt: now(), sample: true });
      });
    }
    db.users.forEach(u => { if (u.role === "owner") ensureRefCode(u); });
    save(db);
  }

  window.EA = {
    idRule, pendingRegistrationPayment, creditBalance, creditExpiryDate, closeAccount, restoreAccount, acceptLegal, updateMyPhone, markContactVerified, beginUpgrade, heldUpgradePayment, completeUpgrade,
    V, maskId, maskPhone, sendOTP, verifyOTP, register, login, logout, checkCredentials, startSession, resetPassword, userExists,
    currentUser: currentUserPublic, currentUserRaw: currentUser, findUserByLogin, pay, subState, daysLeftBeforeDelete,
    purgeExpired, publicListings, getListing, ownerOf, listingsForOwner, canAddListing, saveListing,
    isBoosted, activityLog, recordView, recordContact, toggleOwnerVerified, addSavedSearch, removeSavedSearch,
    deleteListing, toggleLike, toggleSave, stats, allUsers, allListings, allPayments,
    setUserSuspended, setListingRemoved, deleteUser, seed, isVisible, paymentCountry, revenueBreakdown, processPhoto, photoLimitFor,
    reload() { db = load(); }
  };
})();
