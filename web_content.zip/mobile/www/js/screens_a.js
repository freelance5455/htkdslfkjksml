import { h, add, naira, debounce, routeForUrl } from "./util.js";
import { api, session, login, register, ApiError } from "./api.js";
import { state, go, replace } from "./state.js";
import { SITE } from "./config.js";
import { header, iconBtn, icon, toast, skeleton, empty, errorState, courseCard, hrow, field, progressBar, staleNote } from "./ui.js";
import { share, openExternal, device, setupPush, isNative } from "./native.js";
import * as IAP from "./iap.js";
import { mins } from "./util.js";

const ext = (url) => openExternal(url);
function ctaGo(url) { const r = routeForUrl(url.startsWith("http") ? url : SITE + url, SITE); if (r) go(r); else ext(url.startsWith("http") ? url : SITE + url); }

// ---------------------------------------------------------------- Home
export async function home() {
  const d = await api("/home"); const root = h("div");
  const name = d.greeting_name;
  add(root, h("div", { class: "hero" }, h("small", null, new Date().getHours() < 12 ? "Good morning" : new Date().getHours() < 17 ? "Good afternoon" : "Good evening"), h("h1", null, name ? name + " 👋" : "Welcome to Dagba")), staleNote());
  add(root, h("div", { class: "sp" }), h("div", { class: "search", onclick: () => go("/explore?focus=1"), role: "search" }, icon("search"), h("input", { placeholder: "Search courses, skills, subjects", readonly: true, "aria-label": "Search courses" })));
  if (d.banners.length) add(root, h("div", { class: "banners", style: { marginTop: "14px" } }, d.banners.map(b => h("div", { class: "banner " + (b.tone || ""), style: b.image ? { backgroundImage: `url("${b.image}")` } : {} },
    b.label ? h("span", { class: "pill" }, b.label) : null, h("h3", null, b.headline), b.description ? h("p", null, b.description) : null, b.cta ? h("button", { class: "btn", onclick: () => ctaGo(b.cta.url) }, b.cta.label) : null))));
  if (d.continue && d.continue.length) add(root, h("section", { class: "sec" }, h("div", { class: "hd" }, h("h2", null, "Continue learning"), h("a", { href: "#/learning" }, "My Learning")),
    h("div", { class: "hscroll" }, d.continue.map(i => h("a", { class: "card ccard", href: "#/lesson/" + i.lesson.id }, h("div", { class: "img", style: i.course.thumbnail ? { backgroundImage: `url("${i.course.thumbnail}")` } : {} }),
      h("div", { class: "b" }, h("div", { class: "t" }, i.course.title), h("div", { class: "meta" }, "Next: " + i.lesson.title), h("div", { style: { marginTop: "8px" } }, progressBar(i.percent)), h("div", { class: "meta" }, i.percent + "% complete")))))));
  add(root, hrow("Featured", d.featured, "#/explore?featured=1"), hrow("Popular courses", d.popular, "#/explore?sort=popular"));
  for (const s of d.sections) add(root, hrow(s.title, s.courses, "#/explore?" + (s.key === "basic" || s.key === "advanced" ? "level=" + s.key : "division=" + s.key)));
  if (d.faith.length) add(root, h("section", { class: "sec" }, h("div", { class: "hd" }, h("h2", null, "Faith & Spiritual Growth"), h("a", { href: "#/faith" }, "See all")),
    h("div", { class: "hscroll" }, d.faith.map(t => h("a", { class: "card ccard", href: "#/faith/" + t.slug, style: { width: "170px" } }, h("div", { class: "img", style: t.image ? { backgroundImage: `url("${t.image}")` } : {} }), h("div", { class: "b" }, h("div", { class: "t" }, t.name), h("div", { class: "meta" }, t.items + " lessons")))))));
  if (d.paths.length) add(root, h("section", { class: "sec" }, h("div", { class: "hd" }, h("h2", null, "Learning paths")), h("div", { class: "list card", style: { margin: "0 16px" } }, d.paths.map(p => h("a", { href: "#/path/" + p.slug }, h("div", { class: "grow" }, h("div", null, p.title), h("div", { class: "s" }, p.courses + " courses")))))));
  if (d.articles.length) add(root, h("section", { class: "sec" }, h("div", { class: "hd" }, h("h2", null, "Articles"), h("a", { href: "#/articles" }, "See all")), h("div", { class: "list card", style: { margin: "0 16px" } }, d.articles.map(a => h("a", { href: "#/article/" + a.slug }, a.image ? h("div", { class: "skel", style: { width: "64px", height: "64px", flex: "none", backgroundImage: `url("${a.image}")`, backgroundSize: "cover", animation: "none" } }) : null, h("div", { class: "grow" }, h("div", null, a.title), h("div", { class: "s" }, a.category || "")))))));
  return root;
}

// ---------------------------------------------------------------- Explore
export async function explore(_, q) {
  const root = h("div"); const f = { q: "", division: q.get("division") || "", level: q.get("level") || "", sort: q.get("sort") || "", category_id: "", free: "", featured: q.get("featured") || "" };
  const input = h("input", { placeholder: "Search courses, skills, subjects", type: "search", "aria-label": "Search courses" });
  const list = h("div"), chips = h("div", { class: "chips" }), subj = h("div", { class: "chips" }); let page = 1, cats = [];
  const opts = [["All", {}], ["Basic", { division: "academic", level: "basic" }], ["Advanced", { division: "academic", level: "advanced" }], ["Income Skills", { division: "income" }], ["Professional", { division: "professional" }], ["Free", { free: "1" }]];
  const isOn = (o) => (o.free ? f.free === "1" : o.division ? f.division === o.division && (o.level ? f.level === o.level : !f.level) : !f.division && !f.level && !f.free);
  const set = (o) => { Object.assign(f, { division: "", level: "", free: "", category_id: "" }, o); drawChips(); run(true); };
  function drawChips() {
    chips.replaceChildren(...opts.map(([t, o]) => h("button", { class: "chip" + (isOn(o) ? " on" : ""), onclick: () => set(o) }, t)));
    const sub = cats.filter(c => (f.level ? c.division === "academic" && c.level === f.level : f.division ? c.division === f.division : false));
    subj.replaceChildren(...sub.map(c => h("button", { class: "chip" + (String(f.category_id) === String(c.id) ? " on" : ""), onclick: () => { f.category_id = String(f.category_id) === String(c.id) ? "" : c.id; drawChips(); run(true); } }, c.name)));
    subj.hidden = !sub.length;
  }
  async function run(reset) {
    if (reset) { page = 1; list.replaceChildren(skeleton(3)); }
    const qs = new URLSearchParams({ page, per_page: 12 }); for (const [k, v] of Object.entries(f)) if (v) qs.set(k, v); input.value.trim() && qs.set("q", input.value.trim());
    try {
      const d = await api("/courses?" + qs); if (reset) list.replaceChildren();
      if (reset && !d.courses.length) { list.append(empty("No courses found", "Try a different search or category.")); return; }
      list.querySelector(".more")?.remove();
      const g = list.querySelector(".grid") || list.appendChild(h("div", { class: "grid" })); d.courses.forEach(c => g.append(courseCard(c)));
      if (d.page < d.pages) list.append(h("div", { class: "wrap more", style: { margin: "14px 0" } }, h("button", { class: "btn line", onclick: () => { page++; run(false); } }, "Load more")));
    } catch (e) { list.replaceChildren(errorState(e, () => run(true))); }
  }
  input.addEventListener("input", debounce(() => run(true), 350));
  add(root, h("div", { class: "top" }, h("h1", null, "Explore")), h("div", { class: "search" }, icon("search"), input), chips, subj, staleNote(), list);
  try { cats = (await api("/categories")).categories; } catch {}
  drawChips(); run(true); if (q.get("focus")) setTimeout(() => input.focus(), 50);
  return root;
}

// ---------------------------------------------------------------- Course detail
export async function course({ slug }) {
  const d = await api("/courses/" + slug), c = d.course; const root = h("div");
  const cover = h("div", { class: "cover", style: c.thumbnail ? { backgroundImage: `url("${c.thumbnail}")` } : {} }, iconBtn("back", "Back", () => history.back()), iconBtn("share", "Share", () => share({ title: c.title, text: c.title + " on Dagba Digital Academy", url: SITE + "/courses/" + c.slug }), "r"));
  add(root, cover, h("div", { class: "wrap" }, h("div", { class: "sp" }), h("div", null, h("span", { class: "pill" }, c.division === "academic" ? (c.level === "advanced" ? "Academic · Advanced" : "Academic · Basic") : { income: "Income Skills", professional: "Professional Development" }[c.division] || ""), c.certificate ? h("span", { class: "pill blue", style: { marginLeft: "6px" } }, "Certificate") : null),
    h("h1", { style: { marginTop: "8px" } }, c.title), c.instructor ? h("p", { class: "mute" }, "By " + c.instructor.name) : null,
    h("p", { class: "meta" }, [c.lessons + " lessons", mins(c.duration_min)].filter(Boolean).join(" · "))));
  let tab = "overview"; const body = h("div"), bar = h("div", { class: "bar" });
  const tabs = h("div", { class: "tabsbar" }); const draw = () => { tabs.replaceChildren(...[["overview", "Overview"], ["curriculum", "Curriculum"]].map(([k, t]) => h("button", { class: tab === k ? "on" : "", onclick: () => { tab = k; draw(); } }, t))); body.replaceChildren(tab === "overview" ? overview() : curriculum()); };
  const overview = () => h("div", { class: "wrap" }, h("p", { style: { whiteSpace: "pre-line" } }, c.description || c.summary || ""),
    c.objectives.length ? h("div", null, h("h3", { style: { margin: "16px 0 6px" } }, "What you'll learn"), h("ul", null, c.objectives.map(o => h("li", null, o)))) : null,
    c.outcomes.length ? h("div", null, h("h3", { style: { margin: "16px 0 6px" } }, "Outcomes"), h("ul", null, c.outcomes.map(o => h("li", null, o)))) : null);
  const curriculum = () => h("div", null, d.course.curriculum.length ? d.course.curriculum.map(m => h("div", null, h("div", { class: "modh" }, m.title), m.lessons.map(l => h("div", { class: "lesson" + (l.locked ? " locked" : ""), onclick: () => l.locked ? toast("Get this course to unlock this lesson.") : (session.user ? go("/lesson/" + l.id) : go("/login")) },
    h("div", { class: "dot" }), h("div", { style: { flex: 1 } }, h("div", null, l.title), h("div", { class: "meta" }, [l.kind, mins(l.duration_min)].filter(Boolean).join(" · "))), l.free_preview && c.access == null ? h("span", { class: "pill ok" }, "Free preview") : l.locked ? "🔒" : null)))) : empty("Lessons coming soon", ""));
  draw(); add(root, tabs, body, h("div", { style: { height: "90px" } }));
  const render = () => {
    bar.replaceChildren();
    if (c.access) bar.append(h("button", { class: "btn", onclick: () => go("/learn/" + c.slug) }, c.access === "preview" ? "Preview course" : "Continue learning"));
    else if (!c.purchase && c.price_kobo === 0) bar.append(h("button", { class: "btn", onclick: () => (session.user ? go("/learn/" + c.slug) : go("/login")) }, "Start free"));
    else {
      const pid = c.purchase ? `dagba.${c.purchase.item_type === "subject" ? "subject" : "course"}.${c.purchase.item_id}` : null;
      const price = pid && IAP.storePrice(pid);
      if (!session.user) bar.append(h("button", { class: "btn", onclick: () => go("/login") }, "Sign in to enrol"));
      else if (IAP.available() && pid) bar.append(h("button", { class: "btn", onclick: async (e) => { e.target.disabled = true; try { if (await IAP.buy(pid)) toast("Processing your purchase…"); } catch (err) { toast(err.message, true); } e.target.disabled = false; } }, `${c.purchase.item_type === "subject" ? "Unlock full subject" : "Enrol"}${price ? " · " + price : ""}`));
      else bar.append(h("div", { class: "note", style: { margin: 0 } }, "Purchases are made in the Dagba app on your phone."));
      if (c.subscription && session.user) bar.append(h("button", { class: "btn sec2", onclick: () => go("/plans") }, "Subscription options"));
    }
  };
  IAP.init().then(render).catch(render); render(); add(root, bar);
  IAP.onPurchased(async r => { if (r.ok) { toast("Purchase complete. Access unlocked."); const n = (await api("/courses/" + slug)).course; Object.assign(c, n); render(); } else toast(r.message || "Purchase could not be confirmed.", true); });
  return root;
}

// ---------------------------------------------------------------- Auth
function authShell(title, sub, ...kids) { return h("div", { class: "wrap", style: { paddingTop: "24px" } }, h("div", { class: "center" }, h("img", { src: "img/logo.png", alt: "", width: 72, height: 72, style: { borderRadius: "18px" } }), h("h1", { style: { marginTop: "12px" } }, title), h("p", { class: "mute" }, sub)), ...kids); }
export async function loginScreen() {
  const email = h("input", { type: "email", autocomplete: "username", inputmode: "email", required: true }), pw = h("input", { type: "password", autocomplete: "current-password", required: true }), msg = h("div", { class: "err", hidden: true });
  const btn = h("button", { class: "btn", type: "button" }, "Sign in");
  const submit = async () => { btn.disabled = true; msg.hidden = true; try { await login(email.value.trim(), pw.value, device()); setupPush(go); history.length > 1 ? history.back() : go("/home"); } catch (e) { msg.textContent = e.message; msg.hidden = false; } btn.disabled = false; };
  btn.onclick = submit; pw.addEventListener("keydown", e => e.key === "Enter" && submit());
  return h("div", null, h("div", { class: "top" }, iconBtn("back", "Back", () => history.back()), h("h1", null, "")), authShell("Welcome back", "Sign in to continue learning", field("Email", email), field("Password", pw), msg, h("div", { class: "wrap" }, btn, h("div", { class: "sp" }), h("button", { class: "btn line", onclick: () => ext(SITE + "/forgot-password") }, "Forgot password?"), h("div", { class: "sp" }), h("p", { class: "center" }, "New here? ", h("a", { href: "#/register" }, "Create an account")))));
}
export async function registerScreen() {
  const name = h("input", { autocomplete: "name", required: true }), email = h("input", { type: "email", autocomplete: "email", inputmode: "email" }), phone = h("input", { type: "tel", autocomplete: "tel" }), pw = h("input", { type: "password", autocomplete: "new-password" }), msg = h("div", { class: "err", hidden: true });
  const btn = h("button", { class: "btn", type: "button" }, "Create account");
  btn.onclick = async () => { btn.disabled = true; msg.hidden = true; try { await register({ full_name: name.value.trim(), email: email.value.trim(), phone: phone.value.trim(), password: pw.value }, device()); setupPush(go); go("/home"); } catch (e) { msg.textContent = e.message; msg.hidden = false; } btn.disabled = false; };
  return h("div", null, h("div", { class: "top" }, iconBtn("back", "Back", () => history.back()), h("h1", null, "")), authShell("Create your account", "Learn at your own pace", field("Full name", name), field("Email", email), field("Phone (optional)", phone), field("Password", pw), h("p", { class: "mute", style: { margin: "0 16px", fontSize: ".8rem" } }, "Use at least 10 characters with a mix of letters and numbers."), msg,
    h("div", { class: "wrap" }, h("div", { class: "sp" }), btn, h("p", { class: "mute center", style: { fontSize: ".8rem" } }, "By continuing you accept our ", h("a", { href: "#", onclick: e => { e.preventDefault(); ext(SITE + "/terms-and-conditions"); } }, "Terms"), " and ", h("a", { href: "#", onclick: e => { e.preventDefault(); ext(SITE + "/privacy-policy"); } }, "Privacy Policy"), "."), h("p", { class: "center" }, "Already registered? ", h("a", { href: "#/login" }, "Sign in")))));
}
