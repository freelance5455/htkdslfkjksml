import { API_BASE, APP_VERSION } from "./config.js";
// Token vault: iOS Keychain / Android Keystore through the secure-storage plugin; localStorage only when running in a desktop browser for development.
const P = () => (window.Capacitor && window.Capacitor.Plugins) || {};
const vault = {
  async get(k) { const s = P().SecureStorage; if (s) { try { const v = await s.get(k); return v == null ? null : String(v); } catch { return null; } } return localStorage.getItem("dev." + k); },
  async set(k, v) { const s = P().SecureStorage; if (s) return s.set(k, v); localStorage.setItem("dev." + k, v); },
  async del(k) { const s = P().SecureStorage; if (s) { try { await s.remove(k); } catch {} return; } localStorage.removeItem("dev." + k); },
};
export const session = { access: null, refresh: null, user: null, listeners: new Set() };
const emit = () => session.listeners.forEach(f => f(session.user));
export async function loadSession() {
  session.access = await vault.get("access"); session.refresh = await vault.get("refresh");
  try { session.user = JSON.parse((await vault.get("user")) || "null"); } catch { session.user = null; }
  return session.user;
}
async function saveTokens(t) { session.access = t.access_token; session.refresh = t.refresh_token; await vault.set("access", t.access_token); await vault.set("refresh", t.refresh_token); }
export async function setUser(u) { session.user = u; await (u ? vault.set("user", JSON.stringify(u)) : vault.del("user")); emit(); }
export async function clearSession() { session.access = session.refresh = null; await vault.del("access"); await vault.del("refresh"); await setUser(null); cache.clearPrivate(); }

export class ApiError extends Error { constructor(msg, status, code) { super(msg); this.status = status; this.code = code; } }
// Response cache for slow/offline networks: GETs are stored per user; a failed request falls back to the last copy (flagged stale).
export const cache = {
  key(path) { return "c1:" + (session.user ? session.user.id : "anon") + ":" + path; },
  get(path) { try { return JSON.parse(localStorage.getItem(this.key(path))); } catch { return null; } },
  put(path, etag, data) { try { localStorage.setItem(this.key(path), JSON.stringify({ etag, data, at: Date.now() })); } catch { this.trim(); } },
  trim() { const ks = Object.keys(localStorage).filter(k => k.startsWith("c1:")); ks.slice(0, Math.ceil(ks.length / 2)).forEach(k => localStorage.removeItem(k)); },
  clearPrivate() { Object.keys(localStorage).filter(k => k.startsWith("c1:") && !k.startsWith("c1:anon:")).forEach(k => localStorage.removeItem(k)); },
};
export const net = { online: true, stale: false };
let refreshing = null;
async function doRefresh() {
  if (!session.refresh) return false;
  if (!refreshing) refreshing = (async () => {
    try {
      const r = await fetch(API_BASE + "/api/v1/auth/refresh", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ refresh_token: session.refresh }) });
      if (r.status === 401) { await clearSession(); return false; }          // refresh token revoked/expired: signed out for real
      if (!r.ok) return false;                                               // server hiccup: keep the session, retry later
      await saveTokens(await r.json()); return true;
    } catch { return false; } finally { setTimeout(() => (refreshing = null), 0); }
  })();
  return refreshing;
}
export async function api(path, { method = "GET", body, form, auth = true, signal } = {}) {
  const headers = { "X-App-Version": APP_VERSION }; let payload;
  if (form) payload = form; else if (body !== undefined) { headers["Content-Type"] = "application/json"; payload = JSON.stringify(body); }
  const cached = method === "GET" ? cache.get(path) : null;
  if (cached && cached.etag) headers["If-None-Match"] = cached.etag;
  const run = () => { if (auth && session.access) headers.Authorization = "Bearer " + session.access; return fetch(API_BASE + "/api/v1" + path, { method, headers, body: payload, signal }); };
  let r;
  try { r = await run(); } catch (e) {
    if (e.name === "AbortError") throw e;
    net.online = false;
    if (cached) { net.stale = true; return cached.data; }                  // offline: show the last copy we have
    throw new ApiError("No internet connection. Check your network and try again.", 0, "offline");
  }
  net.online = true; net.stale = false;
  if (r.status === 401 && auth && session.refresh && await doRefresh()) r = await run();
  if (r.status === 304 && cached) return cached.data;
  let data = null; try { data = await r.json(); } catch {}
  if (!r.ok) {
    if (r.status === 401 && auth) { await clearSession(); }
    throw new ApiError((data && data.error && data.error.message) || "Something went wrong. Please try again.", r.status, data && data.error && data.error.code);
  }
  if (method === "GET") cache.put(path, r.headers.get("ETag"), data);      // ETag (public data) lets the server answer 304; private data is cached for offline reading
  return data;
}
export async function login(email, password, device) { const d = await api("/auth/login", { method: "POST", body: { email, password, ...device }, auth: false }); await saveTokens(d); await setUser(d.user); return d.user; }
export async function register(f, device) { const d = await api("/auth/register", { method: "POST", body: { ...f, ...device }, auth: false }); await saveTokens(d); await setUser(d.user); return d.user; }
export async function logout() { try { await api("/auth/logout", { method: "POST" }); } catch {} await clearSession(); }
export async function refreshMe() { const d = await api("/me"); await setUser(d.user); return d.user; }
