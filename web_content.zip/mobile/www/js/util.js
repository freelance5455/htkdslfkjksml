// Safe DOM helpers: text is ALWAYS set with textContent, never innerHTML (server HTML is only inserted via html() for fields the backend already escaped).
export function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === "class") el.className = v;
    else if (k.startsWith("on") && typeof v === "function") el.addEventListener(k.slice(2), v);
    else if (k === "style" && typeof v === "object") Object.assign(el.style, v);
    else el.setAttribute(k, v === true ? "" : v);
  }
  for (const kid of kids.flat()) { if (kid == null || kid === false) continue; el.append(kid instanceof Node ? kid : document.createTextNode(String(kid))); }
  return el;
}
// Element.append(null) writes the text "null" in real browsers; add() skips empty children.
export function add(el, ...kids) { for (const k of kids.flat()) if (k != null && k !== false) el.append(k); return el; }
export function html(tag, attrs, serverHtml) { const el = h(tag, attrs); el.innerHTML = serverHtml || ""; el.querySelectorAll("a[href]").forEach(a => { a.setAttribute("rel", "noopener nofollow"); a.dataset.ext = "1"; }); return el; }
export const $ = (s, r = document) => r.querySelector(s);
export function naira(kobo) { if (kobo == null) return ""; const n = kobo / 100; return "₦" + n.toLocaleString("en-NG", { minimumFractionDigits: n % 1 ? 2 : 0, maximumFractionDigits: 2 }); }
export function mins(m) { if (!m) return ""; return m < 60 ? `${m} min` : `${Math.floor(m / 60)}h${m % 60 ? " " + (m % 60) + "m" : ""}`; }
export function ago(ts) {
  if (!ts) return ""; const d = new Date(ts.replace(" ", "T") + "Z"), s = (Date.now() - d) / 1000;
  if (s < 60) return "just now"; if (s < 3600) return Math.floor(s / 60) + " min ago"; if (s < 86400) return Math.floor(s / 3600) + " h ago";
  if (s < 604800) return Math.floor(s / 86400) + " d ago"; return d.toLocaleDateString("en-NG", { day: "numeric", month: "short", year: "numeric" });
}
export function date(ts) { return ts ? new Date(ts.replace(" ", "T") + "Z").toLocaleDateString("en-NG", { day: "numeric", month: "short", year: "numeric" }) : ""; }
export function initials(name) { return (name || "?").split(/\s+/).filter(Boolean).slice(0, 2).map(w => w[0].toUpperCase()).join(""); }
export function debounce(fn, ms) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }
// Deep links: https://<site>/courses/x | /blog/x | /learn/x | /faith/lesson/x | /paths/x  ->  in-app route (null = open in the browser)
export function routeForUrl(url, site) {
  let u; try { u = new URL(url); } catch { return null; }
  if (u.origin !== new URL(site).origin) return null;
  const p = u.pathname.replace(/\/+$/, "");
  let m;
  if ((m = p.match(/^\/courses\/([\w-]+)$/))) return "/course/" + m[1];
  if ((m = p.match(/^\/learn\/([\w-]+)$/))) return "/learn/" + m[1];
  if ((m = p.match(/^\/blog\/([\w-]+)$/))) return "/article/" + m[1];
  if ((m = p.match(/^\/paths\/([\w-]+)$/))) return "/path/" + m[1];
  if ((m = p.match(/^\/faith\/lesson\/([\w-]+)$/))) return "/faith-item/" + m[1];
  if ((m = p.match(/^\/faith\/topic\/([\w-]+)$/))) return "/faith/" + m[1];
  if (p === "/student" || p === "") return "/home";
  if (p === "/notifications") return "/activity";
  return null;
}
export function compareVersions(a, b) { const x = String(a || "0").split(".").map(Number), y = String(b || "0").split(".").map(Number); for (let i = 0; i < 3; i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d < 0 ? -1 : 1; } return 0; }
