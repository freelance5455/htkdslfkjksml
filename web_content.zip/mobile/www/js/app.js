import { h, $, compareVersions } from "./util.js";
import { api, loadSession, session, net, ApiError } from "./api.js";
import { state, go } from "./state.js";
import { APP_VERSION, SITE } from "./config.js";
import { mount, skeleton, errorState, empty, toast } from "./ui.js";
import { initNative, exitApp, openExternal, setupPush, checkLiveUpdate, platform } from "./native.js";
import * as A from "./screens_a.js";
import * as B from "./screens_b.js";
import * as C from "./screens_c.js";

// path pattern -> [screen, tab to highlight (null hides the tab bar on detail screens)]
const ROUTES = [
  [/^\/home$/, A.home, "home"], [/^\/explore$/, A.explore, "explore"], [/^\/learning$/, B.learning, "learning"], [/^\/activity$/, C.activity, "activity"], [/^\/profile$/, C.profile, "profile"],
  [/^\/course\/([\w-]+)$/, (p) => A.course({ slug: p[1] }), null], [/^\/login$/, A.loginScreen, null], [/^\/register$/, A.registerScreen, null],
  [/^\/learn\/([\w-]+)$/, (p) => B.learn({ slug: p[1] }), null], [/^\/lesson\/(\d+)$/, (p) => B.lesson({ id: p[1] }), null], [/^\/quiz\/(\d+)$/, (p) => B.quiz({ id: p[1] }), null],
  [/^\/assignment\/(\d+)$/, (p) => B.assignment({ id: p[1] }), null], [/^\/discussion\/([\w-]+)$/, (p, q) => B.discussion({ slug: p[1] }, q), null], [/^\/certificates$/, B.certificates, null],
  [/^\/plans$/, C.plans, null], [/^\/payments$/, C.payments, null], [/^\/support$/, C.support, null], [/^\/settings\/(profile|password|delete)$/, (p) => C.settingsScreen({ what: p[1] }), null],
  [/^\/articles$/, C.articles, null], [/^\/article\/([\w-]+)$/, (p) => C.article({ slug: p[1] }), null], [/^\/paths$/, C.paths, null], [/^\/path\/([\w-]+)$/, (p) => C.path({ slug: p[1] }), null],
  [/^\/faith$/, C.faith, null], [/^\/faith\/([\w-]+)$/, (p) => C.faithTopic({ slug: p[1] }), null], [/^\/faith-item\/([\w-]+)$/, (p) => C.faithItem({ slug: p[1] }), null],
];
const TABS = ["home", "explore", "learning", "activity", "profile"];
let seq = 0;

function blocking(e) {
  if (e instanceof ApiError && e.code === "prelaunch") return h("div", { class: "empty", style: { paddingTop: "30vh" } }, h("h3", null, "We're launching soon"), h("p", null, (state.config && state.config.prelaunch.label) || "Dagba Digital Academy is almost ready."), h("button", { class: "btn", onclick: () => go("/login") }, "Staff sign in"));
  return null;
}
async function render() {
  const my = ++seq; const raw = location.hash.slice(1) || "/home"; const [path, qs] = raw.split("?"); const q = new URLSearchParams(qs || "");
  let hit = null; for (const [re, fn, tab] of ROUTES) { const m = path.match(re); if (m) { hit = { fn, m, tab }; break; } }
  if (!hit) return go("/home");
  const tabs = $("#tabs"), view = $("#view"); tabs.hidden = hit.tab === null; view.className = hit.tab === null ? "notabs" : "";
  tabs.querySelectorAll("a").forEach(a => a.classList.toggle("on", a.dataset.tab === hit.tab));
  mount(h("div", null, skeleton(4)));
  try { const el = await hit.fn(hit.m, q); if (my === seq) { mount(el); if (net.stale) $("#offline").hidden = false; } }
  catch (e) { if (my !== seq) return; if (e && e.status === 401 && !session.user && !["/login", "/register"].includes(path)) { if (hit.tab) { mount(h("div", null, empty("Please sign in", "Sign in to continue.", h("button", { class: "btn", onclick: () => go("/login") }, "Sign in")))); return; } return go("/login"); }
    mount(blocking(e) || errorState(e instanceof ApiError ? e : new ApiError("Something went wrong. Please try again.", 0), () => render())); }
}
function onBack() { const p = (location.hash.slice(1) || "/home").split("?")[0]; if (TABS.some(t => p === "/" + t)) { if (p === "/home") exitApp(); else go("/home"); } else history.back(); }

async function boot() {
  await loadSession();
  await initNative({ onRoute: go, onBack, onNetwork: (on) => { $("#offline").hidden = on; if (on) render(); } });
  addEventListener("hashchange", render);
  // Global click handling: external links from server HTML open in the system browser.
  document.addEventListener("click", e => { const a = e.target.closest("a[data-ext]"); if (a) { e.preventDefault(); openExternal(a.href); } });
  try {
    state.config = await api("/config", { auth: false }); state.contentVersion = state.config.content_version;
    if (compareVersions(APP_VERSION, state.config.min_app_version) < 0) {
      const s = state.config.settings, store = platform() === "ios" ? s["mobile.store_url_ios"] : s["mobile.store_url_android"];
      mount(h("div", { class: "empty", style: { paddingTop: "28vh" } }, h("h3", null, "Update required"), h("p", null, "Please update Dagba Digital Academy to keep learning."), store ? h("button", { class: "btn", onclick: () => openExternal(store) }, "Update now") : null)); return;
    }
    checkLiveUpdate(state.config);
  } catch (e) { /* offline at launch: continue with cached screens */ }
  if (session.user) { setupPush(go); api("/notifications").then(d => C.setBadge(d.unread)).catch(() => {}); }
  if (!location.hash) location.hash = "#/home"; else render();
  // Automatic sync: when the app returns to the foreground, check whether anything changed on the website and refresh the visible screen.
  document.addEventListener("visibilitychange", async () => {
    if (document.visibilityState !== "visible") return;
    try { const d = await api("/content-version", { auth: false }); if (state.contentVersion != null && d.content_version !== state.contentVersion) { state.contentVersion = d.content_version; const p = (location.hash.slice(1) || "/home").split("?")[0]; if (TABS.some(t => p === "/" + t) || p.startsWith("/course/")) render(); } } catch {}
  });
}
boot();
