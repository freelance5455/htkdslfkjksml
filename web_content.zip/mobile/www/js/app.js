/* ==========================================================
   NOMIDMAN TRANS CO. LTD — UI controller (single-page app)
   ========================================================== */
(function () {
  "use strict";
  const C = window.EA_CONFIG, I = window.EA_I18N, GEO = window.GEO, DB = window.EA;
  const DAY = 86400000;

  let lang = localStorage.getItem("ea_lang") || "en";
  // Arabic mode shows Arabic-Indic digits (٠١٢٣٤٥٦٧٨٩) for numbers and prices
  const numLoc = () => (lang === "ar" ? "ar-EG" : "en-US");
  const AR_DIGITS = "٠١٢٣٤٥٦٧٨٩";
  const N = (v) => (lang === "ar" ? String(v).replace(/[0-9]/g, d => AR_DIGITS[+d]) : String(v));
  let theme = localStorage.getItem("ea_theme") || "light";
  let viewCur = localStorage.getItem("ea_cur") || "UGX";
  let F = { cat: "", type: "", country: "", loc: [], min: "", max: "", sort: "new" };

  /* ---------- helpers ---------- */
  let OVR = {}; // content saved by the admin: { lang: { key: text } }
  const t = (k) => {
    const o = OVR[lang] && OVR[lang][k];
    if (o) return o;
    return (I[lang] && I[lang][k] != null) ? I[lang][k] : (I.en[k] != null ? I.en[k] : k);
  };
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const CATS = ["plot", "house", "commercial", "hotel", "auto", "other"];
  const CAT_KEY = { plot: "cat_plot", house: "cat_house", commercial: "cat_commercial", hotel: "cat_hotel", auto: "cat_auto", other: "cat_other" };
  const FEATURES = {
    house: ["f_single_room", "f_double_rooms", "f_more_than_two_rooms", "f_self_contained", "f_non_self_contained", "f_fenced", "f_electricity", "f_solar", "f_camera", "f_water", "f_ceiling", "f_tiled", "f_cemented", "f_flat", "f_resident_landlord"],
    plot: ["f_titled", "f_road", "f_water_access", "f_elec_access", "f_market", "f_expansion"],
    commercial: ["f_ground_floor", "f_parking", "f_electricity", "f_solar", "f_water", "f_fenced", "f_camera", "f_tiled", "f_cemented", "f_ceiling"],
    hotel: ["f_restaurant", "f_parking", "f_pool", "f_wifi", "f_conference", "f_generator", "f_solar", "f_electricity", "f_water", "f_fenced", "f_camera"],
    auto: ["f_automatic", "f_manual", "f_petrol", "f_diesel", "f_hybrid", "f_electric", "f_logbook", "f_insured"],
    other: ["f_fenced", "f_electricity", "f_solar", "f_water", "f_parking", "f_camera", "f_generator"]
  };
  const LEVEL_KEYS = {
    UGA: ["lv_region", "lv_district", "lv_subcounty", "lv_parish", "lv_village"],
    TZA: ["lv_region", "lv_council", "lv_ward", "lv_village"],
    RWA: ["lv_region", "lv_district", "lv_sector", "lv_cell", "lv_village"],
    SSD: ["lv_state", "lv_county", "lv_payam", "lv_boma"],
    KEN: ["lv_province", "lv_county", "lv_constituency", "lv_ward"],
    COD: ["lv_province", "lv_territory", "lv_chiefdom", "lv_grouping", "lv_subquarter"]
  };
  const METHODS = [
    { id: "mtn", name: "MTN MoMo", c: "#FFCB05", fg: "#111" },
    { id: "airtel", name: "Airtel Money", c: "#E40000", fg: "#fff" },
    { id: "orange", name: "Orange Money", c: "#FF7900", fg: "#fff" },
    { id: "mpesa", name: "M-PESA", c: "#00A651", fg: "#fff" },
    { id: "visa", name: "VISA", c: "#1A1F71", fg: "#fff" },
    { id: "mastercard", name: "Mastercard", c: "#EB001B", fg: "#fff" },
    { id: "gpay", name: "Google Pay", c: "#3c4043", fg: "#fff" },
    { id: "bank", name: "Bank transfer", c: "#334155", fg: "#fff" }
  ];
  // Flag emoji for each country (shown in dropdowns)
  const FLAGS = { UGA: "🇺🇬", TZA: "🇹🇿", RWA: "🇷🇼", SSD: "🇸🇸", KEN: "🇰🇪", COD: "🇨🇩" };
  const flagOf = (k) => FLAGS[k] ? FLAGS[k] + " " : "";
  // French and Arabic names for regions, provinces, states and counties (top level only)
  const TOP_TX = {
  "UGA": {
    "CENTRAL": {
      "fr": "Région Centrale",
      "ar": "المنطقة الوسطى"
    },
    "EASTERN": {
      "fr": "Région de l'Est",
      "ar": "المنطقة الشرقية"
    },
    "NORTHERN": {
      "fr": "Région du Nord",
      "ar": "المنطقة الشمالية"
    },
    "WESTERN": {
      "fr": "Région de l'Ouest",
      "ar": "المنطقة الغربية"
    }
  },
  "TZA": {
    "Kusini Pemba": {
      "fr": "Pemba Sud",
      "ar": "بيمبا الجنوبية"
    },
    "Kaskazini Pemba": {
      "fr": "Pemba Nord",
      "ar": "بيمبا الشمالية"
    },
    "DODOMA": {
      "fr": "Dodoma",
      "ar": "دودوما"
    },
    "ARUSHA": {
      "fr": "Arusha",
      "ar": "أروشا"
    },
    "KILIMANJARO": {
      "fr": "Kilimandjaro",
      "ar": "كيليمانجارو"
    },
    "TANGA": {
      "fr": "Tanga",
      "ar": "تانغا"
    },
    "MOROGORO": {
      "fr": "Morogoro",
      "ar": "موروغورو"
    },
    "PWANI": {
      "fr": "Pwani (Côte)",
      "ar": "بواني (الساحل)"
    },
    "DAR ES SALAM": {
      "fr": "Dar es Salaam",
      "ar": "دار السلام"
    },
    "LINDI": {
      "fr": "Lindi",
      "ar": "ليندي"
    },
    "MTWARA": {
      "fr": "Mtwara",
      "ar": "متوارا"
    },
    "RUVUMA": {
      "fr": "Ruvuma",
      "ar": "روفوما"
    },
    "IRINGA": {
      "fr": "Iringa",
      "ar": "إرينغا"
    },
    "MBEYA": {
      "fr": "Mbeya",
      "ar": "مبيا"
    },
    "SINGIDA": {
      "fr": "Singida",
      "ar": "سينغيدا"
    },
    "TABORA": {
      "fr": "Tabora",
      "ar": "تابورا"
    },
    "RUKWA": {
      "fr": "Rukwa",
      "ar": "روكوا"
    },
    "KIGOMA": {
      "fr": "Kigoma",
      "ar": "كيغوما"
    },
    "SHINYANGA": {
      "fr": "Shinyanga",
      "ar": "شينيانغا"
    },
    "KAGERA": {
      "fr": "Kagera",
      "ar": "كاغيرا"
    },
    "MWANZA": {
      "fr": "Mwanza",
      "ar": "موانزا"
    },
    "MARA": {
      "fr": "Mara",
      "ar": "مارا"
    },
    "MANYARA": {
      "fr": "Manyara",
      "ar": "مانيارا"
    },
    "NJOMBE": {
      "fr": "Njombe",
      "ar": "نجومبي"
    },
    "KATAVI": {
      "fr": "Katavi",
      "ar": "كاتافي"
    },
    "SIMIYU": {
      "fr": "Simiyu",
      "ar": "سيميو"
    },
    "GEITA": {
      "fr": "Geita",
      "ar": "غيتا"
    },
    "SONGWE": {
      "fr": "Songwe",
      "ar": "سونغوي"
    },
    "KASKAZINI INGUJA": {
      "fr": "Unguja Nord",
      "ar": "أونغوجا الشمالية"
    },
    "KUSINI UNGUJA": {
      "fr": "Unguja Sud",
      "ar": "أونغوجا الجنوبية"
    },
    "Mjini Magharibi": {
      "fr": "Mjini Magharibi (Zanzibar Ouest)",
      "ar": "مجيني ماغاريبي"
    }
  },
  "RWA": {
    "WESTERN": {
      "fr": "Province de l'Ouest",
      "ar": "المقاطعة الغربية"
    },
    "NORTHERN": {
      "fr": "Province du Nord",
      "ar": "المقاطعة الشمالية"
    },
    "SOUTHERN": {
      "fr": "Province du Sud",
      "ar": "المقاطعة الجنوبية"
    },
    "KIGALI": {
      "fr": "Ville de Kigali",
      "ar": "مدينة كيغالي"
    },
    "EASTERN": {
      "fr": "Province de l'Est",
      "ar": "المقاطعة الشرقية"
    }
  },
  "SSD": {
    "UPPER NILE": {
      "fr": "Haut-Nil",
      "ar": "أعالي النيل"
    },
    "JONGLEI": {
      "fr": "Jonglei",
      "ar": "جونقلي"
    },
    "UNITY": {
      "fr": "Unité",
      "ar": "الوحدة"
    },
    "WARRAP": {
      "fr": "Warrap",
      "ar": "واراب"
    },
    "N.B.G": {
      "fr": "Bahr el-Ghazal Nord",
      "ar": "بحر الغزال الشمالية"
    },
    "W.B.G": {
      "fr": "Bahr el-Ghazal Ouest",
      "ar": "بحر الغزال الغربية"
    },
    "LAKES": {
      "fr": "Lacs",
      "ar": "البحيرات"
    },
    "W.E.S": {
      "fr": "Équatoria Ouest",
      "ar": "إستوائية الغربية"
    },
    "C.E.S": {
      "fr": "Équatoria Centre",
      "ar": "إستوائية الوسطى"
    },
    "E.E.S": {
      "fr": "Équatoria Est",
      "ar": "إستوائية الشرقية"
    }
  },
  "KEN": {
    "Coastal": {
      "fr": "Côte",
      "ar": "الساحل"
    },
    "North Eastern": {
      "fr": "Nord-Est",
      "ar": "الشمال الشرقي"
    },
    "Eastern": {
      "fr": "Est",
      "ar": "الشرق"
    },
    "Central": {
      "fr": "Centre",
      "ar": "الوسط"
    },
    "Rift Valley": {
      "fr": "Vallée du Rift",
      "ar": "وادي ريفت"
    },
    "Western": {
      "fr": "Ouest",
      "ar": "الغرب"
    },
    "Nyanza": {
      "fr": "Nyanza",
      "ar": "نيانزا"
    },
    "Nairobi": {
      "fr": "Nairobi",
      "ar": "نيروبي"
    }
  },
  "COD": {
    "Kongo-Central": { "fr": "Kongo-Central", "ar": "كونغو المركزية" },
    "Kwango": { "fr": "Kwango", "ar": "كوانغو" },
    "Kwilu": { "fr": "Kwilu", "ar": "كويلو" },
    "Lomami": { "fr": "Lomami", "ar": "لوماامي" },
    "Bas-Uélé": {
      "fr": "Bas-Uélé",
      "ar": "باس-ويلي"
    },
    "Équateur": {
      "fr": "Équateur",
      "ar": "إكواتور"
    },
    "Haut-Katanga": {
      "fr": "Haut-Katanga",
      "ar": "هوت-كاتانغا"
    },
    "Haut-Lomami": {
      "fr": "Haut-Lomami",
      "ar": "هوت-لوميامي"
    },
    "Haut-Uélé": {
      "fr": "Haut-Uélé",
      "ar": "هوت-ويلي"
    },
    "Ituri": {
      "fr": "Ituri",
      "ar": "إيتوري"
    },
    "Kasaï": {
      "fr": "Kasaï",
      "ar": "كاساي"
    },
    "Kasaï-Central": {
      "fr": "Kasaï-Central",
      "ar": "كاساي الوسطى"
    },
    "Kasaï-Oriental": {
      "fr": "Kasaï-Oriental",
      "ar": "كاساي الشرقية"
    },
    "Kinshasa": {
      "fr": "Kinshasa",
      "ar": "كينشاسا"
    },
    "Lualaba": {
      "fr": "Lualaba",
      "ar": "لوالابا"
    },
    "Mai-Ndombe": {
      "fr": "Mai-Ndombe",
      "ar": "ماي-ندومبي"
    },
    "Maniema": {
      "fr": "Maniema",
      "ar": "مانييما"
    },
    "Mongala": {
      "fr": "Mongala",
      "ar": "مونغالا"
    },
    "Nord-Ubangi": {
      "fr": "Nord-Ubangi",
      "ar": "أوبانغي الشمالية"
    },
    "North Kivu": {
      "fr": "Nord-Kivu",
      "ar": "كيفو الشمالية"
    },
    "Sankuru": {
      "fr": "Sankuru",
      "ar": "سانكورو"
    },
    "South Kivu": {
      "fr": "Sud-Kivu",
      "ar": "كيفو الجنوبية"
    },
    "Sud-Ubangi": {
      "fr": "Sud-Ubangi",
      "ar": "أوبانغي الجنوبية"
    },
    "Tanganyika": {
      "fr": "Tanganyika",
      "ar": "تانغانيقا"
    },
    "Tshopo": {
      "fr": "Tshopo",
      "ar": "تشوبو"
    },
    "Tshuapa": {
      "fr": "Tshuapa",
      "ar": "تشوابا"
    }
  }
};
  const topName = (country, name) => { const e = TOP_TX[country] && TOP_TX[country][name]; return e ? (e[lang] || name) : name; };
  // French and Arabic text for the demo sample listings (owner-typed listings are shown as entered)
  const SAMPLE_TX = {
    sample_0: {
      fr: { title: "Parcelle titrée de 2 acres près de la ville de Kamuli", description: "Terrain titré en pleine propriété, accès routier toute saison, ligne électrique à 300 m, idéal pour l'agriculture ou un projet résidentiel." },
      ar: { title: "قطعة أرض مسجلة بمساحة 2 فدان قرب مدينة كامولي", description: "أرض بسند ملكية حر، وصول بالطريق في كل الفصول، خط كهرباء على بعد 300 متر، مناسبة للزراعة أو مشروع سكني." }
    },
    sample_1: {
      fr: { title: "Chambre double autonome, compound clôturé", description: "Chambre double autonome propre avec sol carrelé, eau de forage, énergie solaire et vidéosurveillance. Propriétaire résident." },
      ar: { title: "غرفة مزدوجة مستقلة في مجمّع مسوّر", description: "غرفة مزدوجة مستقلة نظيفة بأرضية من البلاط، ومياه من بئر، وطاقة شمسية وكاميرات مراقبة. المالك مقيم." }
    },
    sample_2: {
      fr: { title: "Boutique au rez-de-chaussée sur la route principale", description: "Local commercial animé au rez-de-chaussée, avec places de parking et électricité fiable." },
      ar: { title: "محل تجاري في الطابق الأرضي على الطريق الرئيسي", description: "محل تجاري نشط في الطابق الأرضي مع موقف سيارات وكهرباء موثوقة." }
    },
    sample_3: {
      fr: { title: "Toyota Premio 2015, carte grise disponible", description: "Bien entretenue, assurée, pneus en bon état. Prix indicatif en USD." },
      ar: { title: "تويوتا بريميو 2015، دفتر السيارة متوفر", description: "مصونة جيداً ومؤمّنة، وإطاراتها بحالة جيدة. السعر تقديري بالدولار الأمريكي." }
    }
  };
  // Title/description in the current language (samples only)
  const L = (l, field) => (l.sample && SAMPLE_TX[l.id] && SAMPLE_TX[l.id][lang] && SAMPLE_TX[l.id][lang][field]) || l[field];
  // International dialling codes, set by the country of registration
  const DIAL = { Uganda: "+256", Tanzania: "+255", Rwanda: "+250", "South Sudan": "+211", Kenya: "+254", "DR Congo": "+243" };
  const dialFor = (name) => DIAL[name] || "+";
  // Payment wording follows the edition's payment provider
  const payNoteKey = () => (C.paymentProvider === "flutterwave" ? "pay_secure_flutterwave" : "pay_secure_pesapal");
  const COUNTRY_OPTIONS = Object.keys(GEO).map(k => `<option value="${k}">${flagOf(k)}${esc(GEO[k].name)}</option>`).join("");

  const perUGX = (cur) => (C.currencies[cur] || C.currencies.UGX).perUGX;
  const toUGX = (amt, cur) => amt / perUGX(cur);
  const fromUGX = (ugx, cur) => ugx * perUGX(cur);
  function fmt(amt, cur) {
    const sym = cur === "UGX" ? "UGX" : ((C.currencies[cur] || {}).symbol || cur);
    return sym + " " + Math.round(amt).toLocaleString(numLoc());
  }
  // Amount converted to a currency and rounded for display (charged amounts stay in UGX)
  function localAmountHTML(ugx, cur) {
    if (cur === "UGX") return `<b>${esc(fmt(ugx, "UGX"))}</b>`;
    const raw = fromUGX(ugx, cur);
    const step = raw >= 10000 ? 1000 : raw >= 1000 ? 100 : raw >= 100 ? 10 : raw >= 10 ? 1 : null;
    if (step === null) return `<b>${esc((C.currencies[cur] || {}).symbol || cur)} ${raw.toFixed(2)}</b>`;
    return `<b>${esc(fmt(Math.round(raw / step) * step, cur))}</b>`;
  }
  // Display currency for a registrant's country (South Sudan, Other and unknown: USD)
  function countryCur(nationality) {
    return C.registrationDisplayCurrency[nationality] || C.displayCurrencyDefault;
  }
  // Registration fee in the registrant's country currency
  function regFeeHTML(nationality) {
    return localAmountHTML(C.registrationFee, countryCur(nationality));
  }
  function priceHTML(l) {
    const main = fmt(l.price, l.currency);
    const approx = viewCur !== l.currency
      ? `<small class="approx">≈ ${esc(fmt(fromUGX(toUGX(l.price, l.currency), viewCur), viewCur))} ${t("approx")}</small>` : "";
    return `<span class="price-main">${esc(main)}</span>${approx}`;
  }
  function locLabel(l) {
    const p = l.location || [];
    const last2 = p.map((x, i) => ({ x, i })).slice(-2).reverse()
      .map(({ x, i }) => (i === 0 ? topName(l.country, x.trim()) : x.trim()));
    return [...last2, GEO[l.country] ? GEO[l.country].name : ""].filter(Boolean).join(", ");
  }
  function locPath(l) { return (l.location || []).map((s, i) => (i === 0 ? topName(l.country, s.trim()) : s.trim())).join(" › "); }
  function dateStr(ts) { return new Date(ts).toLocaleDateString(lang === "ar" ? "ar-EG" : (lang === "fr" ? "fr-FR" : "en-GB"), { day: "2-digit", month: "short", year: "numeric" }); }
  function go(h) { if (location.hash === h) route(); else location.hash = h; }

  function toast(msg, sub) {
    const box = $("#toast");
    const el = document.createElement("div");
    el.className = "toast";
    el.innerHTML = `<div>${esc(msg)}</div>${sub ? `<small>${esc(sub)}</small>` : ""}`;
    box.appendChild(el);
    setTimeout(() => el.classList.add("out"), 3800);
    setTimeout(() => el.remove(), 4300);
  }
  function modal(html) {
    const m = $("#modal");
    m.innerHTML = `<div class="modal-card card">${html}</div>`;
    m.hidden = false;
    m.onclick = (e) => { if (e.target === m || e.target.closest("[data-close]")) closeModal(); };
  }
  function closeModal() { const m = $("#modal"); m.hidden = true; m.innerHTML = ""; }

  /* ---------- theme / language ---------- */
  function applyTheme() {
    document.documentElement.setAttribute("data-theme", theme);
  }
  function applyLang() {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
    document.title = "NOMIDMAN TRANS CO. LTD";
  }

  /* ---------- cascading location picker ---------- */
  // Builds Region > District > Sub-county > Parish > Village dropdowns from the Excel data
  function mountLoc(host, country, initial, onChange, anyFirst) {
    const state = { path: (initial || []).slice() };
    function draw() {
      host.innerHTML = "";
      if (!country || !GEO[country]) return;
      const keys = LEVEL_KEYS[country];
      let node = GEO[country].tree;
      for (let lvl = 0; lvl < keys.length; lvl++) {
        const opts = Object.keys(node || {}).sort((a, b) => a.localeCompare(b));
        if (!opts.length) break;
        const wrap = document.createElement("label");
        wrap.className = "loc-field";
        const first = lvl === 0 && anyFirst ? t("all") : t("loc_choose_level");
        wrap.innerHTML = `${esc(t(keys[lvl]))}<select class="input" data-lvl="${lvl}">
          <option value="">${esc(first)}</option>
          ${opts.map(o => `<option value="${esc(o)}" ${state.path[lvl] === o ? "selected" : ""}>${esc(lvl === 0 ? topName(country, o) : o)}</option>`).join("")}
        </select>`;
        host.appendChild(wrap);
        const sel = wrap.querySelector("select");
        sel.onchange = () => {
          state.path = state.path.slice(0, lvl);
          if (sel.value) state.path.push(sel.value);
          draw();
          onChange && onChange(state.path.slice());
        };
        if (!state.path[lvl]) break;
        node = node[state.path[lvl]];
      }
    }
    draw();
    return { get: () => state.path.slice(), reset: () => { state.path = []; draw(); } };
  }

  /* ---------- feature dropdown (multi-select checklist) ---------- */
  // features that carry a short explanation, opened by the (i) button
  const INFO_FEATS = { f_resident_landlord: "info_resident_landlord" };
  const infoBtnHTML = (key) => `<button type="button" class="info-btn" data-info="${key}" aria-label="${esc(t("more_info"))}">i</button>`;
  // the room number box appears only when "More than 2 rooms" is ticked
  const roomsCountHTML = (checked, rooms) => `<input name="roomsCount" type="number" min="3" step="1" class="input rooms-inline" placeholder="${esc(t("rooms_label"))}" value="${rooms || ""}" ${checked ? "" : "hidden"}>`;
  function featureDropdown(cat, selected, rooms) {
    if (cat === "other") {
      // Other Items: no fixed features, just a free writing space
      return `<textarea name="otherFeatures" class="input" rows="4" maxlength="600" placeholder="${esc(t("other_features_hint"))}">${esc((selected || []).join("\n"))}</textarea>`;
    }
    const list = FEATURES[cat] || [];
    const sel = selected || [];
    const count = sel.filter(f => list.includes(f)).length;
    return `<details class="dd" id="featDD">
      <summary class="input">${count ? `${N(count)} ${esc(t("select_items"))}` : esc(t("select_items"))}</summary>
      <div class="dd-list">
        ${list.map(f => `<label class="chk"><input type="checkbox" name="feat" value="${f}" ${sel.includes(f) ? "checked" : ""}> ${esc(t(f))}${INFO_FEATS[f] ? infoBtnHTML(INFO_FEATS[f]) : ""}</label>${f === "f_more_than_two_rooms" ? roomsCountHTML(sel.includes(f), rooms) : ""}`).join("")}
      </div></details>`;
  }

  /* ---------- header / footer ---------- */
  function header() {
    const u = DB.currentUser();
    const isAdmin = u && u.role === "admin";
    return `<header class="topbar"><div class="wrap nav">
      <a class="brand-logo" href="#/"><img class="logo-img" src="assets/logo-mark.svg" alt="NOMIDMAN TRANS logo" width="48" height="48"><span>NOMIDMAN TRANS CO. LTD</span></a>
      <button class="burger" id="burger" aria-label="Menu">☰</button>
      <nav id="mainnav" class="links">
        <a href="#/">${t("nav_home")}</a>
        <a href="#/listings">${t("nav_listings")}</a>
        <a href="#/about">${t("nav_about")}</a>
        ${u && !isAdmin ? `<a href="#/dashboard">${t("nav_dashboard")}</a>` : ""}
        ${isAdmin ? `<a href="#/zero">${t("nav_admin")}</a>` : ""}
      </nav>
      <div class="tools">
        <div class="langs" role="group" aria-label="Language">
          ${["en", "fr", "ar"].map(l => `<button data-lang="${l}" class="${lang === l ? "on" : ""}">${I[l].lang_name}</button>`).join("")}
        </div>
        <button id="themeBtn" class="icon-btn" aria-label="${t(theme === "dark" ? "theme_light" : "theme_dark")}" title="${t(theme === "dark" ? "theme_light" : "theme_dark")}">${theme === "dark" ? "☀" : "☾"}</button>
        ${u
          ? `<button id="logoutBtn" class="btn ghost">${t(isAdmin ? "admin_logout" : "nav_logout")}</button>`
          : `<a class="btn ghost" href="#/login">${t("nav_login")}</a><a class="btn" href="#/register">${t("nav_register")}</a>`}
      </div></div></header>`;
  }
  function footer() {
    return `<footer class="footer"><div class="wrap">
      <p><b>NOMIDMAN TRANS CO. LTD</b> — ${t("footer_about")} · <a href="#/about">${esc(t("nav_about"))}</a> · <a href="#/app">${esc(t("nav_app"))}</a></p>
      <p class="legal-links"><a href="#/privacy">${esc(t("nav_privacy"))}</a> · <a href="#/terms">${esc(t("nav_terms"))}</a> · <a href="#/disclaimer">${esc(t("nav_disclaimer"))}</a></p>
      <div class="office">
        <p><b>${esc(t("main_office"))}</b></p>
        <p>${esc(C.office.address)}</p>
        <p><bdi dir="ltr">${esc(C.office.poBox)}</bdi></p>
        <p>${esc(t("tel_label"))}: <a href="tel:${esc(C.office.phone)}"><bdi dir="ltr">${esc(C.office.phone)}</bdi></a></p>
      </div>
      <p><bdi dir="ltr">${esc(C.supportEmail)}</bdi></p>
      <div class="helpline">
        <h3>${esc(t("help_title"))}</h3>
        <p>${esc(t("help_text"))}</p>
        ${hoursHTML()}
        <p><a class="btn" href="tel:${esc(C.office.phone)}">📞 ${esc(t("help_call"))} <bdi dir="ltr">${esc(C.office.phone)}</bdi></a></p>
      </div>
      <p><button type="button" class="link-btn" id="giftBtn">♥ ${esc(t("gift_btn"))}</button></p>
      <p>© ${new Date().getFullYear()} NOMIDMAN TRANS CO. LTD. ${t("footer_rights")}</p>
    </div></footer>`;
  }
  function demoBar() {
    return "";
  }

  /* ---------- listing cards ---------- */
  function card(l) {
    const u = DB.currentUser();
    const liked = u && u.liked.includes(l.id);
    return `<article class="card listing">
      <a class="cover" href="#/listing/${l.id}" aria-label="${esc(L(l, "title"))}"${l.photos && l.photos.length ? ` style="background:url('${l.photos[0]}') center / cover no-repeat"` : ""}>
        <span class="chip">${esc(t(CAT_KEY[l.category]))}</span>
        <span class="chip alt">${esc(t(l.listingType === "sale" ? "type_sale" : "type_rent"))}</span>
        ${l.sample ? `<span class="chip sample">${esc(t("sample_tag"))}</span>` : ""}
        ${DB.isBoosted(l) ? `<span class="chip featured">★ ${esc(t("featured_badge"))}</span>` : ""}
      </a>
      <div class="body">
        <h3><a href="#/listing/${l.id}">${esc(L(l, "title"))}</a></h3>
        <p class="loc">📍 ${esc(locLabel(l))}</p>
        <p class="price">${priceHTML(l)}</p>
        ${(DB.ownerOf(l) || {}).verified ? `<span class="badge ok">✓ ${esc(t("verified_owner"))}</span>` : ""}
        <div class="row">
          <span class="muted">${liked ? "♥" : "♡"} ${N(l.likes.length)} ${esc(t("views_label"))}</span>
          <a class="btn small" href="#/listing/${l.id}">${esc(t("view"))}</a>
        </div>
      </div></article>`;
  }

  /* ---------- views ---------- */
  function viewHome() {
    const featured = DB.publicListings().sort((a, b) => DB.isBoosted(b) - DB.isBoosted(a)).slice(0, 6);
    const plans = Object.values(C.plans).map(p => `
      <div class="card plan ${p.key === "economy" ? "hot" : ""}">
        <h3>${esc(t(p.name_key))}</h3>
        <p class="plan-price">${localAmountHTML(p.price, viewCur)}<small> ${esc(t("per_91"))}</small></p>
        <p>${esc(t("list_up_to"))} <b>${N(p.limit)}</b> ${esc(t("items"))}</p>
        <button class="btn" data-sub="${p.key}">${esc(t("subscribe"))}</button>
      </div>`).join("");
    return `
      ${noticeHTML()}
      <section class="hero card-glass">
        <div>
          <h1 class="hero-title">${heroLetters(t("hero_title"))}</h1>
          <p class="lead">${esc(t("hero_sub"))}</p>
          <form id="heroSearch" class="search-row">
            <select name="cat" class="input" aria-label="${esc(t("filter_category"))}">
              <option value="">${esc(t("all"))}</option>
              ${CATS.map(k => `<option value="${k}">${esc(t(CAT_KEY[k]))}</option>`).join("")}
            </select>
            <select name="type" class="input" aria-label="${esc(t("filter_type"))}">
              <option value="">${esc(t("filter_type"))}</option>
              <option value="sale">${esc(t("type_sale"))}</option>
              <option value="rent">${esc(t("type_rent"))}</option>
            </select>
            <button class="btn big" type="submit">${esc(t("search_btn"))}</button>
          </form>
        </div>
      </section>
      <section>
        <h2>${esc(t("browse_cat"))}</h2>
        <div class="cat-grid">
          ${CATS.map(k => `<a class="cat-tile card" href="#/listings?cat=${k}"><span>${esc(t(CAT_KEY[k]))}</span></a>`).join("")}
        </div>
      </section>
      <section>
        <div class="row between"><h2>${esc(t("featured"))}</h2>
          <div class="cur-toggle" role="group" aria-label="${esc(t("filter_currency"))}">
            <span class="muted">${esc(t("filter_currency"))}:</span>
            ${Object.keys(C.currencies).map(c => `<button type="button" data-cur="${c}" class="${viewCur === c ? "on" : ""}" aria-pressed="${viewCur === c}">${esc(c)}</button>`).join("")}
          </div></div>
        <p class="muted small-note">${ratesNote()}</p>
        <div class="grid">${featured.length ? featured.map(card).join("") : `<p class="muted">${esc(t("no_results"))}</p>`}</div>
      </section>
      <section>
        <h2>${esc(t("plans_title"))}</h2>
        <div class="plans">${plans}</div>
        <p class="muted small-note">${esc(t("grace_note"))}</p>
      </section>
      <section class="card-glass">
        <h2>${esc(t("how_title"))}</h2>
        <ol class="steps">
          <li>${esc(t("step1"))}</li><li>${esc(t("step2"))}</li><li>${esc(t("step3"))}</li><li>${esc(t("step4"))}</li>
        </ol>
        <p class="muted">${esc(t("offsite_note"))}</p>
      </section>
      <section>
        <h2>${esc(t("payments_title"))}</h2>
        <div class="brands">${METHODS.map(m => `<span class="brand" style="--c:${m.c};--fg:${m.fg}">${esc(m.name)}</span>`).join("")}</div>
        <p class="muted small-note">${esc(t(payNoteKey()))}</p>
      </section>`;
  }
  function bindHome() {
    $("#heroSearch").onsubmit = (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      go(`#/listings?cat=${fd.get("cat")}&type=${fd.get("type")}`);
    };
    $$("[data-sub]").forEach(b => b.onclick = () => subscribeFlow(b.dataset.sub));
    $$("[data-cur]").forEach(b => b.onclick = () => {
      viewCur = b.dataset.cur; localStorage.setItem("ea_cur", viewCur); route();
    });
  }

  function viewListings(query) {
    F.cat = query.get("cat") || F.cat || "";
    F.type = query.get("type") !== null ? (query.get("type") || "") : F.type;
    return `
      <div class="layout">
        <aside class="filters card">
          <h3>${esc(t("filters_title"))}</h3>
          <label>${esc(t("country"))}
            <select id="fCountry" class="input"><option value="">${esc(t("all"))}</option>${COUNTRY_OPTIONS}</select>
          </label>
          <div id="locHost" class="loc-host"></div>
          <label>${esc(t("filter_category"))}
            <select id="fCat" class="input"><option value="">${esc(t("all"))}</option>${CATS.map(k => `<option value="${k}" ${F.cat === k ? "selected" : ""}>${esc(t(CAT_KEY[k]))}</option>`).join("")}</select>
          </label>
          <label>${esc(t("filter_type"))}
            <select id="fType" class="input"><option value="">${esc(t("all"))}</option>
              <option value="sale" ${F.type === "sale" ? "selected" : ""}>${esc(t("type_sale"))}</option>
              <option value="rent" ${F.type === "rent" ? "selected" : ""}>${esc(t("type_rent"))}</option></select>
          </label>
          <div class="grid2">
            <label>${esc(t("filter_min"))}<input id="fMin" type="number" min="0" class="input" value="${esc(F.min)}"></label>
            <label>${esc(t("filter_max"))}<input id="fMax" type="number" min="0" class="input" value="${esc(F.max)}"></label>
          </div>
          <label>${esc(t("filter_currency"))}
            <select id="fCur" class="input">${Object.keys(C.currencies).map(c => `<option value="${c}" ${viewCur === c ? "selected" : ""}>${esc(C.currencies[c].label)}</option>`).join("")}</select>
          </label>
          <label>${esc(t("filter_sort"))}
            <select id="fSort" class="input">
              <option value="new" ${F.sort === "new" ? "selected" : ""}>${esc(t("sort_new"))}</option>
              <option value="low" ${F.sort === "low" ? "selected" : ""}>${esc(t("sort_low"))}</option>
              <option value="high" ${F.sort === "high" ? "selected" : ""}>${esc(t("sort_high"))}</option>
            </select>
          </label>
          <button class="btn ghost" id="fReset">${esc(t("reset"))}</button>
          <button class="btn" id="saveSearch">${esc(t("save_search"))}</button>
        </aside>
        <section>
          <div class="results-bar"><span id="count" class="muted"></span></div>
          <p class="muted small-note">${ratesNote()}</p>
          <div id="grid" class="grid"></div>
        </section>
      </div>`;
  }
  function bindListings() {
    F.country = F.country || $("#fCountry").value;
    $("#fCountry").value = F.country;
    const remountLoc = () => mountLoc($("#locHost"), F.country, F.loc, (p) => { F.loc = p; renderGrid(); }, true);
    remountLoc();
    $("#fCountry").onchange = (e) => {
      F.country = e.target.value; F.loc = [];
      $("#locHost").innerHTML = "";
      remountLoc(); renderGrid();
    };
    $("#fCat").onchange = (e) => { F.cat = e.target.value; renderGrid(); };
    $("#fType").onchange = (e) => { F.type = e.target.value; renderGrid(); };
    $("#fMin").oninput = (e) => { F.min = e.target.value; renderGrid(); };
    $("#fMax").oninput = (e) => { F.max = e.target.value; renderGrid(); };
    $("#fSort").onchange = (e) => { F.sort = e.target.value; renderGrid(); };
    $("#fCur").onchange = (e) => { viewCur = e.target.value; localStorage.setItem("ea_cur", viewCur); renderGrid(); };
    $("#saveSearch").onclick = () => saveSearchModal();
    $("#fReset").onclick = () => { F = { cat: "", type: "", country: "", loc: [], min: "", max: "", sort: "new", veh: "" }; go("#/listings"); };
    renderGrid();
  }
  function filteredListings() {
    let list = DB.publicListings();
    if (F.cat) list = list.filter(l => l.category === F.cat);
    if (F.type) list = list.filter(l => l.listingType === F.type);
    if (F.country) list = list.filter(l => l.country === F.country);
    if (F.loc.length) list = list.filter(l => F.loc.every((v, i) => (l.location || [])[i] === v));
    if (F.min !== "") list = list.filter(l => toUGX(l.price, l.currency) >= toUGX(+F.min, viewCur));
    if (F.max !== "") list = list.filter(l => toUGX(l.price, l.currency) <= toUGX(+F.max, viewCur));
    if (F.sort === "low") list.sort((a, b) => toUGX(a.price, a.currency) - toUGX(b.price, b.currency));
    else if (F.sort === "high") list.sort((a, b) => toUGX(b.price, b.currency) - toUGX(a.price, a.currency));
    else list.sort((a, b) => b.createdAt - a.createdAt);
    return list;
  }
  function renderGrid() {
    const list = filteredListings().sort((a, b) => DB.isBoosted(b) - DB.isBoosted(a));
    $("#count").textContent = `${N(list.length)} ${t("results")}`;
    $("#grid").innerHTML = list.length ? list.map(card).join("") : `<p class="muted empty">${esc(t("no_results"))}</p>`;
  }

  function gallery(l) {
    const ph = l.photos || [];
    const badges = `<span class="chip">${esc(t(CAT_KEY[l.category]))}</span>
      <span class="chip alt">${esc(t(l.listingType === "sale" ? "type_sale" : "type_rent"))}</span>`;
    if (!ph.length) return `<div class="cover big-cover">${badges}</div>`;
    return `<div class="gallery">
      <div class="cover big-cover" id="mainPhoto" style="background:url('${ph[0]}') center / cover no-repeat">${badges}</div>
      ${ph.length > 1 ? `<div class="thumbs">${ph.map((src, i) => `<button type="button" class="thumb ${i === 0 ? "on" : ""}" data-photo="${i}" style="background-image:url('${src}')" aria-label="${i + 1}"></button>`).join("")}</div>` : ""}
    </div>`;
  }
  function bindGallery(l) {
    if (!l || !(l.photos || []).length) return;
    $$("[data-photo]").forEach(b => b.onclick = () => {
      const i = +b.dataset.photo;
      $("#mainPhoto").style.background = `url('${l.photos[i]}') center / cover no-repeat`;
      $$("[data-photo]").forEach(x => x.classList.toggle("on", x === b));
    });
  }
  function viewListingDetail(id) {
    const l = DB.getListing(id);
    const u = DB.currentUser();
    if (!l || (!DB.isVisible(l) && !(u && u.id === l.ownerId))) {
      return `<section class="card"><h2>${esc(t("no_results"))}</h2><a class="btn" href="#/listings">${esc(t("back"))}</a></section>`;
    }
    const owner = DB.ownerOf(l);
    const liked = u && u.liked.includes(l.id);
    const saved = u && u.saved.includes(l.id);
    const terms = (l.listingType === "sale" ? l.paymentTerms : l.rentDurations) || [];
    const contact = u
      ? `<h3>${esc(t("contact_title"))}</h3>
         <p><b>${esc(t("legal_name"))}:</b> ${esc(owner.name)}</p>
         <p><b>${esc(t("phone_label"))}:</b> <bdi dir="ltr">${esc(owner.phone)}</bdi></p>
         <p><b>${esc(t("email_label"))}:</b> <bdi dir="ltr">${esc(owner.email)}</bdi></p>
         ${owner.verified ? `<p><span class="badge ok">✓ ${esc(t("verified_owner"))}</span></p>` : ""}
         <p class="muted small-note">${esc(t("contact_only_verified"))}</p>
         <div class="actions-col">
           <a class="btn big" data-contact href="tel:${esc(owner.phone)}">📞 ${esc(t("call"))}</a>
           <a class="btn ghost big" data-contact href="mailto:${esc(owner.email)}?subject=${encodeURIComponent(l.title)}">✉ ${esc(t("email_btn"))}</a>
           <a class="btn ghost big" data-contact target="_blank" rel="noopener" href="https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(owner.email)}&su=${encodeURIComponent(l.title)}">✉ ${esc(t("email_gmail"))}</a>
           <button type="button" class="btn ghost big" data-copy="${esc(owner.email)}">⧉ ${esc(t("copy_email"))}</button>
           <a class="btn whatsapp big" data-contact target="_blank" rel="noopener" href="${waLink(owner.phone, l.title)}">💬 ${esc(t("whatsapp"))}</a>
         </div>
         <p class="muted small-note">${esc(t("contact_note"))}</p>`
      : `<h3>${esc(t("contact_title"))}</h3><p>${esc(t("contact_login"))}</p>
         <a class="btn big" href="#/login">${esc(t("nav_login"))}</a>`;
    return `
      <div class="detail">
        <article class="card">
          ${gallery(l)}
          <h1>${esc(L(l, "title"))}</h1>
          <p class="loc">📍 ${esc(locPath(l))} — ${esc(GEO[l.country] ? GEO[l.country].name : "")}</p>
          <p class="price big-price">${priceHTML(l)}</p>
          <p>${esc(L(l, "description"))}</p>
          <h3>${esc(t("features"))}</h3>
          ${l.category === "house" && l.rooms ? `<p><b>${esc(t("rooms_count"))}:</b> ${esc(l.rooms)}</p>` : ""}
          ${l.category === "other" && l.featuresText ? `<p class="pre-wrap">${esc(l.featuresText)}</p>` : `<div class="chips">${(l.features || []).map(f => `<span class="chip soft">${esc(t(f))}</span>`).join("") || "—"}</div>`}
          ${terms.length ? `<h3>${esc(t(l.listingType === "sale" ? "payment_terms" : "rent_durations"))}</h3>
            <div class="chips">${terms.map(x => `<span class="chip soft">${esc(t(x))}</span>`).join("")}</div>` : ""}
          <div class="row gap">
            <button class="btn ${liked ? "" : "ghost"}" data-like="${l.id}">${liked ? "♥ " + esc(t("liked")) : "♡ " + esc(t("like"))} (${N(l.likes.length)})</button>
            <button class="btn ${saved ? "" : "ghost"}" data-save="${l.id}">${saved ? "★ " + esc(t("saved")) : "☆ " + esc(t("save"))}</button>
            <button class="btn ghost" data-share="${l.id}">⇪ ${esc(t("share"))}</button>
          </div>
          ${l.category === "auto" && l.vehicle ? vehicleBlockHTML(l.vehicle) : ""}
          ${l.land ? landBlockHTML(l.land) : ""}
          ${shopLinkHTML(l)}
          <p class="muted small-note">${esc(t("listed_on"))}: ${dateStr(l.createdAt)}</p>
        </article>
        <aside class="card contact">${contact}</aside>
      </div>
      ${similarHTML(l)}
      <p class="muted"><a href="#/listings">← ${esc(t("back"))}</a></p>`;
  }
  function bindListingDetail(id) {
    if (!viewedSet.has(id)) { viewedSet.add(id); DB.recordView(id); }
    const shareBtn = $("[data-share]");
    if (shareBtn) shareBtn.onclick = () => openShare(DB.getListing(id));
    $$("[data-contact]").forEach(a => a.onclick = () => DB.recordContact(id));
    $$("[data-copy]").forEach(b => b.onclick = async () => {
      try { await navigator.clipboard.writeText(b.dataset.copy); toast(t("copied"), b.dataset.copy); }
      catch (e) { toast(b.dataset.copy); }
    });
    const like = $("[data-like]"), save = $("[data-save]");
    if (like) like.onclick = () => {
      if (!DB.currentUser()) return go("#/login");
      DB.toggleLike(id); route();
    };
    if (save) save.onclick = () => {
      if (!DB.currentUser()) return go("#/login");
      DB.toggleSave(id); toast(t("listing_saved")); route();
    };
  }

  /* ---------- office hours ---------- */
  // Returns true if the office is open right now (East Africa Time)
  function officeOpenNow() {
    const parts = new Intl.DateTimeFormat("en-GB", { timeZone: C.hours.timezone, weekday: "short", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).formatToParts(new Date());
    const wd = parts.find(p => p.type === "weekday").value;
    const mins = (+parts.find(p => p.type === "hour").value) * 60 + (+parts.find(p => p.type === "minute").value);
    const range = wd === "Sat" ? C.hours.sat : wd === "Sun" ? C.hours.sun : C.hours.mon_fri;
    return !!range && mins >= range[0] * 60 && mins < range[1] * 60;
  }
  function hoursHTML() {
    const h = (r) => (r ? `${fmtHour(r[0])} – ${fmtHour(r[1])}` : t("hours_closed"));
    const fmtHour = (x) => { const hh = Math.floor(x), mm = Math.round((x - hh) * 60); const ampm = hh < 12 ? "AM" : "PM"; const h12 = hh % 12 || 12; return `${h12}:${String(mm).padStart(2, "0")} ${ampm}`; };
    const open = officeOpenNow();
    return `<div class="hours">
      <p><b>${esc(t("hours_title"))}</b> <span class="muted">(${esc(t("hours_tz"))})</span></p>
      <p>${esc(t("hours_weekday"))}: ${esc(h(C.hours.mon_fri))}</p>
      <p>${esc(t("hours_sat"))}: ${esc(h(C.hours.sat))}</p>
      <p>${esc(t("hours_sun"))}: ${esc(t("hours_closed"))}</p>
      <p><span class="badge ${open ? "ok" : "warn"}">${esc(t(open ? "office_open" : "office_closed"))}</span></p>
    </div>`;
  }

  /* ---------- about us ---------- */
  function viewLegal(key) {
    const titles = { privacy: t("nav_privacy"), terms: t("nav_terms"), disclaimer: t("nav_disclaimer") };
    const body = legalText((window.EA_LEGAL && window.EA_LEGAL[key]) || "");
    return `<section class="card legal"><p class="legal-banner">${esc(t("legal_draft_banner"))}</p>
      <h2>${esc(titles[key])}</h2>${body}</section>`;
  }
  function viewGetApp() {
    const A = C.app || {};
    const androidBtn = A.androidUrl
      ? `<a class="btn big" href="${esc(A.androidUrl)}" download>${esc(t("app_android_btn"))}</a>
         <p class="muted small-note">${esc(t("app_version"))}: ${esc(A.version || "—")} · SHA-256: <bdi dir="ltr">${esc(A.androidSha256 || "—")}</bdi></p>`
      : `<button class="btn big" disabled>${esc(t("app_android_btn"))}</button><p class="muted small-note">${esc(t("app_coming_soon"))}</p>`;
    return `<section class="card"><h2>${esc(t("app_title"))}</h2>
      <p>${esc(t("app_intro"))}</p>
      <h3>${esc(t("app_android_title"))}</h3>
      ${androidBtn}
      <ol class="steps"><li>${esc(t("app_android_step1"))}</li><li>${esc(t("app_android_step2"))}</li><li>${esc(t("app_android_step3"))}</li></ol>
      <h3>${esc(t("app_iphone_title"))}</h3>
      <ol class="steps"><li>${esc(t("app_iphone_step1"))}</li><li>${esc(t("app_iphone_step2"))}</li><li>${esc(t("app_iphone_step3"))}</li></ol>
      <p class="muted small-note">${esc(t("app_update_note"))}</p>
    </section>`;
  }
  function viewAbout() {
    return `<section class="card about">
      <h1>${esc(t("about_title"))}</h1>
      <p class="lead">${esc(t("about_p1"))}</p>
      <p>${esc(t("about_p2"))}</p>
      <p>${esc(t("about_p3"))}</p>
      <h2>${esc(t("about_why_title"))}</h2>
      <ul class="why">
        <li><b>${esc(t("why1_t"))}</b> ${esc(t("why1"))}</li>
        <li><b>${esc(t("why2_t"))}</b> ${esc(t("why2"))}</li>
        <li><b>${esc(t("why3_t"))}</b> ${esc(t("why3"))}</li>
        <li><b>${esc(t("why4_t"))}</b> ${esc(t("why4"))}</li>
      </ul>
      <h2>${esc(t("about_contact_title"))}</h2>
      <p>${esc(C.office.address)}<br>${esc(C.office.poBox)}<br>${esc(t("tel_label"))}: <bdi dir="ltr"><a href="tel:${esc(C.office.phone)}">${esc(C.office.phone)}</a></bdi><br><bdi dir="ltr">${esc(C.supportEmail)}</bdi></p>
      <p class="helpline"><b>${esc(t("help_title"))}:</b> ${esc(t("help_text"))} <a href="tel:${esc(C.office.phone)}"><bdi dir="ltr">${esc(C.office.phone)}</bdi></a></p>
      ${hoursHTML()}
      <p><a class="btn big" href="#/listings">${esc(t("nav_listings"))}</a></p>
    </section>`;
  }

  /* ---------- auth views ---------- */
  function viewLogin() {
    return `<section class="auth card">
      <h1>${esc(t("login_title"))}</h1>
      <form id="loginForm" novalidate>
        <label>${esc(t("login_id"))}<input name="id" class="input" autocomplete="username" required></label>
        <label>${esc(t("password"))}<input name="pw" type="password" class="input" autocomplete="current-password" required></label>
        <p id="loginErr" class="error" role="alert"></p>
        <button class="btn big" type="submit">${esc(t("login_btn"))}</button>
      </form>
      <p><a href="#/forgot">${esc(t("forgot_link"))}</a></p>
      <p>${esc(t("no_account"))} <a href="#/register">${esc(t("nav_register"))}</a></p>
    </section>`;
  }
  function bindLogin() {
    $("#loginForm").onsubmit = async (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      const u = await DB.login(String(fd.get("id")).trim(), String(fd.get("pw")));
      if (!u) { $("#loginErr").textContent = t("bad_login"); return; }
      toast("✓ " + u.firstName);
      go(u.role === "admin" ? "#/zero" : "#/dashboard");
    };
  }

  function countryOptions(sel) {
    return Object.keys(GEO).map(k => `<option value="${esc(GEO[k].name)}" ${sel === GEO[k].name ? "selected" : ""}>${flagOf(k)}${esc(GEO[k].name)}</option>`).join("") + `<option value="Other">🌍 Other</option>`;
  }
  function viewRegister() {
    return `<section class="auth card wide">
      <h1>${esc(t("register_title"))}</h1>
      <form id="regForm" novalidate>
        <fieldset class="radio-row"><legend>${esc(t("role"))}</legend>
          <label class="radio-card"><input type="radio" name="role" value="owner" checked> ${esc(t("role_owner"))}<span id="regFeeInline" class="fee-inline"></span></label>
          <label class="radio-card"><input type="radio" name="role" value="customer"> ${esc(t("role_customer"))}</label>
        </fieldset>
        ${refFromUrl ? `<p class="muted">${esc(t("referred_by"))}: <b>${esc(refFromUrl)}</b></p>` : ""}
        <div class="grid2">
          <label>${esc(t("nationality"))}<select name="nationality" class="input">${countryOptions("Uganda")}</select></label>
          <label id="otherNatWrap" hidden>${esc(t("other_nat_label"))}<input name="nationalityOther" class="input" maxlength="60" autocomplete="country-name"></label>
        </div>
        <div class="grid2">
          <label>${esc(t("first_name"))}<input name="firstName" class="input" required></label>
          <label>${esc(t("last_name"))}<input name="lastName" class="input" required></label>
          <label>${esc(t("age"))}<input name="age" type="number" min="18" max="120" class="input" required></label>
          <label>${esc(t("gender"))}<select name="gender" class="input"><option value="male">${esc(t("male"))}</option><option value="female">${esc(t("female"))}</option></select></label>
          <label>${esc(t("id_type"))}<select name="idType" class="input">
            <option value="national_id">${esc(t("national_id"))}</option>
            <option value="driving_permit">${esc(t("driving_permit"))}</option>
            <option value="passport">${esc(t("passport"))}</option>
            <option value="voter_id">${esc(t("voter_id"))}</option></select></label>
          <label class="span2">${esc(t("id_number"))}<input name="idNumber" class="input" autocomplete="off" required>
            <small class="muted">${esc(t("id_format_hint"))}</small>
            <small class="muted" id="idRuleHint"></small>
            <small class="muted">${esc(t("id_stored_masked"))} <span id="idMaskPreview">••••••</span></small></label>
        </div>
        <div id="regPayBox" class="card attention">
          <p id="regPayMsg">${esc(t("reg_pay_first"))}</p>
          <p class="muted small-note">${esc(t("reg_refund_note"))}</p>
          <button type="button" class="btn big" id="regPayBtn">${esc(t("reg_pay_btn"))}</button>
        </div>
        <p id="regCustNote" class="muted" hidden>${esc(t("reg_customer_note"))}</p>
        <div id="otpWrap">
        ${otpBlock("phone", t("phone"), "+256…", "tel")}
        ${otpBlock("email", t("email_addr"), "you@example.com", "email")}
        </div>
        <div class="grid2">
          <label>${esc(t("password"))}<input name="password" type="password" class="input" autocomplete="new-password" required></label>
          <div class="pw-meter" aria-live="polite">
            <div class="pw-bar"><span id="pwFill"></span></div>
            <small id="pwLabel" class="muted"></small>
            <ul class="pw-rules">
              <li data-rule="len">${esc(t("pw_rule_len"))}</li>
              <li data-rule="upper">${esc(t("pw_rule_upper"))}</li>
              <li data-rule="lower">${esc(t("pw_rule_lower"))}</li>
              <li data-rule="digit">${esc(t("pw_rule_digit"))}</li>
              <li data-rule="symbol">${esc(t("pw_rule_symbol"))}</li>
            </ul>
          </div>
          <label>${esc(t("confirm_password"))}<input name="confirm" type="password" class="input" autocomplete="new-password" required></label>
        </div>
        <small class="muted">${esc(t("password_rules"))}</small>
        <label class="chk agree-row"><input type="checkbox" id="regAgree"> ${esc(t("agree_prefix"))} <a href="#/terms">${esc(t("nav_terms"))}</a> · <a href="#/privacy">${esc(t("nav_privacy"))}</a></label>
        <p id="regErr" class="error" role="alert"></p>
        <button class="btn big" type="submit">${esc(t("create_account"))}</button>
      </form>
      <p>${esc(t("have_account"))} <a href="#/login">${esc(t("nav_login"))}</a></p>
    </section>`;
  }
  function otpBlock(kind, label, ph, type) {
    return `<div class="verify-block" data-kind="${kind}">
      <label>${esc(label)}<div class="inline">
        <input name="${kind}" type="${type}" class="input" placeholder="${ph}" required>
        <button type="button" class="btn small" data-send="${kind}">${esc(t("send_otp"))}</button>
      </div></label>
      <div class="inline otp-row" hidden>
        <input class="input otp-input" maxlength="6" inputmode="numeric" placeholder="${esc(t("otp_code"))}">
        <button type="button" class="btn small" data-verify="${kind}">${esc(t("verify"))}</button>
      </div>
      <small class="state muted"></small>
    </div>`;
  }
  function bindRegister() {
    const form = $("#regForm");
    const verified = { phone: false, email: false };
    let regPayRef = null; // reference of the held owner registration payment
    const syncRole = () => {
      const owner = form.role.value === "owner";
      $("#regPayBox").hidden = !owner;
      $("#regCustNote").hidden = owner;
      // contact fields stay visible for everyone; only owners get code buttons, and only after the fee is held
      $$("#otpWrap [data-send]").forEach(b => { b.hidden = !owner; b.disabled = !regPayRef; });
      $$("#otpWrap .otp-row").forEach(r => { if (!owner) r.hidden = true; });
      if (owner && regPayRef) $("#regPayMsg").textContent = t("reg_pay_held");
      if (owner && !regPayRef) $("#regPayMsg").textContent = t("reg_pay_first");
    };
    $$("[name=role]").forEach(r => r.onchange = syncRole);
    $("#regPayBtn").onclick = () => {
      const methods = METHODS.map((m, i) => `<label class="method"><input type="radio" name="hmethod" value="${m.id}" ${i === 0 ? "checked" : ""}><span class="brand" style="--c:${m.c};--fg:${m.fg}">${esc(m.name)}</span></label>`).join("");
      modal(`<h2>${esc(t("reg_pay_btn"))}</h2>
        <p class="big-amount">${esc(t("amount_due"))}: ${regFeeHTML(form.nationality.value)}</p>
        <p class="muted small-note">${esc(t("reg_hold_note"))}</p>
        <div class="methods">${methods}</div>
        <div class="actions"><button class="btn ghost" data-close>${esc(t("cancel"))}</button>
          <button class="btn big" id="holdPay">${esc(t("reg_hold_btn"))}</button></div>`);
      $("#holdPay").onclick = async () => {
        const btn = $("#holdPay"); btn.disabled = true;
        const method = $("input[name=hmethod]:checked").value;
        try {
          const p = await DB.pay({ amountUGX: C.registrationFee, purpose: "registration", method, pending: true });
          regPayRef = p.id; closeModal(); syncRole(); toast(t("reg_pay_held"));
        } catch (e) { btn.disabled = false; toast("Payment could not be held. Please try again."); }
      };
    };
    syncRole();
    const setDial = () => {
      const code = dialFor(form.nationality.value);
      const ph = form.phone;
      if (!ph.value.trim() || ph.value.trim().startsWith("+")) ph.value = code;
      ph.placeholder = code + "…";
    };
    const idHintEl = () => {
      const r = DB.idRule(form.idType.value, form.nationality.value);
      if (!r) return;
      let hint;
      if (r.letters) {
        const lens = (r.lengths || [r.min, r.max]).map(x => N(x)).join(` ${t("id_or")} `);
        hint = t("id_hint_letters").replace("{len}", lens);
      } else if (r.lengths) {
        hint = r.lengths.map(x => N(x)).join(` ${t("id_or")} `) + " " + t("id_chars_word");
      } else if (r.digits) {
        hint = (r.min === r.max ? t("id_hint_digits").replace("{n}", N(r.min)) : t("id_hint_digits_range").replace("{min}", N(r.min)).replace("{max}", N(r.max)));
      } else {
        hint = (r.min === r.max ? t("id_hint_chars").replace("{n}", N(r.min)) : t("id_hint_chars_range").replace("{min}", N(r.min)).replace("{max}", N(r.max)));
      }
      $("#idRuleHint").textContent = `${t("id_expected")}: ${hint}`;
    };
    const otherWrap = () => { $("#otherNatWrap").hidden = form.nationality.value !== "Other"; };
    const feeLine = () => { $("#regFeeInline").innerHTML = regFeeHTML(form.nationality.value); };
    form.nationality.onchange = () => { setDial(); idHintEl(); otherWrap(); feeLine(); };
    feeLine();
    otherWrap();
    form.idType.onchange = idHintEl;
    setDial(); idHintEl();
    const pwInput = form.password;
    const pwUpdate = () => {
      const v = pwInput.value;
      const rules = {
        len: v.length >= 8,
        upper: /[A-Z]/.test(v),
        lower: /[a-z]/.test(v),
        digit: /[0-9]/.test(v),
        symbol: /[^A-Za-z0-9]/.test(v)
      };
      const score = Object.values(rules).filter(Boolean).length;
      document.querySelectorAll(".pw-rules li").forEach(li => li.classList.toggle("ok", !!rules[li.dataset.rule]));
      const level = !v ? 0 : score <= 2 ? 1 : score === 3 ? 2 : score === 4 ? 3 : 4;
      const labels = ["", t("pw_weak"), t("pw_fair"), t("pw_good"), t("pw_strong")];
      const colors = ["", "#b42318", "#b54708", "#2e7d32", "#067647"];
      const fill = $("#pwFill");
      fill.style.width = [0, 25, 50, 75, 100][level] + "%";
      fill.style.background = colors[level];
      $("#pwLabel").textContent = level ? `${t("pw_strength")}: ${labels[level]}` : "";
    };
    pwInput.oninput = pwUpdate;
    pwUpdate();
    form.idNumber.oninput = (e) => {
      const s = e.target.value.replace(/\s/g, "");
      $("#idMaskPreview").textContent = s.length > 4 ? DB.maskId(s) : "••••";
    };
    $$("[data-kind]").forEach(block => {
      const kind = block.dataset.kind;
      const input = block.querySelector(`[name=${kind}]`);
      const state = block.querySelector(".state");
      const row = block.querySelector(".otp-row");
      const norm = () => kind === "phone" ? DB.V.normPhone(input.value) : DB.V.normEmail(input.value);
      input.oninput = () => { verified[kind] = false; state.textContent = ""; row.hidden = true; };
      block.querySelector(`[data-send]`).onclick = async () => {
        if (!regPayRef) return toast(t("reg_pay_first"));
        const v = norm();
        const ok = kind === "phone" ? DB.V.phone(v) : DB.V.email(v);
        if (!ok) { state.textContent = t(kind === "phone" ? "phone_invalid" : "email_invalid"); state.className = "state error"; return; }
        if (DB.userExists(v)) { state.textContent = t("already_exists"); state.className = "state error"; return; }
        const { demoCode } = await DB.sendOTP(v);
        row.hidden = false;
        state.textContent = t("otp_sent"); state.className = "state muted";
        if (demoCode) toast(`${t("verify_code")}: ${demoCode}`);
      };
      block.querySelector(`[data-verify]`).onclick = async () => {
        const code = block.querySelector(".otp-input").value;
        const ok = await DB.verifyOTP(norm(), code);
        verified[kind] = ok;
        state.textContent = ok ? t("otp_verified") : t("otp_invalid");
        state.className = ok ? "state ok" : "state error";
      };
    });
    form.onsubmit = async (e) => {
      e.preventDefault();
      const err = $("#regErr"); err.textContent = "";
      const d = Object.fromEntries(new FormData(form).entries());
      if (!$("#regAgree").checked) return err.textContent = t("agree_required");
      const need = ["firstName", "lastName", "age", "idNumber", "email", "password", "confirm"];
      if (d.role === "owner") need.push("phone");
      if (need.some(k => !String(d[k] || "").trim())) return err.textContent = t("fill_all");
      if (d.nationality === "Other") {
        const typed = String(d.nationalityOther || "").trim();
        if (typed.length < 2) return err.textContent = t("other_nat_required");
        d.nationality = typed;
      }
      const idErr = DB.V.docNumber(d.idType, d.idNumber, d.nationality);
      if (idErr) return err.textContent = t(idErr);
      const phoneDigits = DB.V.normPhone(d.phone);
      const phoneGiven = d.role === "owner" || (phoneDigits.length > 4);
      if (phoneGiven && !DB.V.phone(d.phone)) return err.textContent = t("phone_invalid");
      if (!DB.V.email(d.email)) return err.textContent = t("email_invalid");
      if (+d.age < 18 || +d.age > 120) return err.textContent = t("age_invalid");
      if (d.role === "owner") {
        if (!regPayRef) return err.textContent = t("reg_pay_first");
        if (!verified.phone || !verified.email) return err.textContent = t("need_verify");
      }
      if (!DB.V.password(d.password)) return err.textContent = t("password_weak");
      if (d.password !== d.confirm) return err.textContent = t("password_mismatch");
      try {
        const owner = d.role === "owner";
        const u = await DB.register({ ...d, refCode: refFromUrl, phone: phoneGiven ? DB.V.normPhone(d.phone) : "", email: DB.V.normEmail(d.email), phoneVerified: owner, emailVerified: owner, payRef: regPayRef });
        toast(t("reg_success"));
        go(u.role === "owner" ? "#/dashboard" : "#/listings");
      } catch (ex) { err.textContent = t(ex.message === "payment_required" ? "reg_pay_first" : "already_exists"); }
    };
  }

  function viewForgot() {
    return `<section class="auth card">
      <h1>${esc(t("forgot_title"))}</h1>
      <p class="muted">${esc(t("forgot_hint"))}</p>
      <form id="forgotForm" novalidate>
        <label>${esc(t("login_id"))}<div class="inline">
          <input name="id" class="input" required><button type="button" class="btn small" id="fSend">${esc(t("forgot_send"))}</button></div></label>
        <div class="inline" id="fOtpRow" hidden>
          <input name="code" class="input" maxlength="6" inputmode="numeric" placeholder="${esc(t("otp_code"))}">
          <button type="button" class="btn small" id="fVerify">${esc(t("verify"))}</button></div>
        <div id="fNewRow" hidden>
          <label>${esc(t("password"))}<input name="pw" type="password" class="input" autocomplete="new-password"></label>
          <label>${esc(t("confirm_password"))}<input name="pw2" type="password" class="input" autocomplete="new-password"></label>
          <small class="muted">${esc(t("password_rules"))}</small>
          <button class="btn big" type="submit">${esc(t("reset_btn"))}</button>
        </div>
        <p id="fMsg" class="error" role="alert"></p>
      </form>
    </section>`;
  }
  function bindForgot() {
    let target = null, ok = false;
    $("#fSend").onclick = async () => {
      const v = $("[name=id]").value.trim();
      const isE = DB.V.email(v), isP = DB.V.phone(DB.V.normPhone(v));
      if (!isE && !isP) return $("#fMsg").textContent = t("fill_all");
      const key = isE ? DB.V.normEmail(v) : DB.V.normPhone(v);
      if (!DB.userExists(key)) return $("#fMsg").textContent = t("user_not_found");
      target = key;
      const { demoCode } = await DB.sendOTP(target);
      $("#fOtpRow").hidden = false;
      $("#fMsg").textContent = ""; toast(t("otp_sent"));
      if (demoCode) toast(`${t("verify_code")}: ${demoCode}`);
    };
    $("#fVerify").onclick = async () => {
      ok = await DB.verifyOTP(target, $("[name=code]").value);
      $("#fMsg").textContent = ok ? "" : t("otp_invalid");
      if (ok) $("#fNewRow").hidden = false;
    };
    $("#forgotForm").onsubmit = async (e) => {
      e.preventDefault();
      const pw = $("[name=pw]").value, pw2 = $("[name=pw2]").value;
      if (!ok) return;
      if (!DB.V.password(pw)) return $("#fMsg").textContent = t("password_weak");
      if (pw !== pw2) return $("#fMsg").textContent = t("password_mismatch");
      await DB.resetPassword(target, pw);
      toast(t("reset_success")); go("#/login");
    };
  }

  /* ---------- payments / subscriptions ---------- */
  function openPay(purpose, plan, listingId) {
    const u = DB.currentUser();
    if (!u) { toast(t("not_signed_in")); return go("#/login"); }
    const credit = purpose === "subscription" ? Math.min(DB.creditBalance(DB.currentUserRaw()), purpose === "subscription" ? C.plans[plan].price : 0) : 0;
    const amount = purpose === "registration" ? C.registrationFee : purpose === "boost" ? C.boost.priceUGX : C.plans[plan].price;
    const label = purpose === "registration" ? t("reg_fee_title") : purpose === "boost" ? t("boost_title") : `${t(C.plans[plan].name_key)} · ${t("per_91")}`;
    modal(`<h2>${esc(t("pay_title"))}</h2>
      <p>${esc(label)}</p>
      <p class="big-amount">${esc(t("amount_due"))}: ${purpose === "registration" || purpose === "subscription" ? localAmountHTML(amount - credit, countryCur((DB.currentUser() || {}).nationality)) : `<b>${esc(fmt(amount, "UGX"))}</b>`}</p>
      ${credit ? `<p class="muted small-note">${esc(t("referral_applied")).replace("{amt}", fmt(credit, "UGX"))}</p>` : ""}
      <h3>${esc(t("pay_method"))}</h3>
      <div class="methods">${METHODS.map((m, i) => `
        <label class="method"><input type="radio" name="method" value="${m.id}" ${i === 0 ? "checked" : ""}>
          <span class="brand" style="--c:${m.c};--fg:${m.fg}">${esc(m.name)}</span></label>`).join("")}
      </div>
      <p class="muted small-note">${esc(t(payNoteKey()))}</p>
      <div class="actions">
        <button class="btn ghost" data-close>${esc(t("cancel"))}</button>
        <button class="btn big" id="doPay">${esc(t("pay_now"))}</button>
      </div>`);
    $("#doPay").onclick = async () => {
      const btn = $("#doPay");
      const method = $("input[name=method]:checked").value;
      btn.disabled = true; btn.textContent = t("pay_processing");
      try {
        const r = await DB.pay({ amountUGX: amount - credit, purpose, plan, method, listingId, creditUsed: credit });
        if (r && r.pending) return;
        closeModal(); toast(t("pay_success")); route();
      } catch (e) {
        btn.disabled = false; btn.textContent = t("pay_now");
        toast("Payment could not be completed. Please try again.");
      }
    };
  }
  function subscribeFlow(plan) {
    const u = DB.currentUser();
    if (!u) { toast(t("not_signed_in")); return go("#/login"); }
    if (u.role !== "owner") return toast(t("role_owner"));
    if (!u.registrationPaid) { toast(t("need_registration")); return go("#/dashboard"); }
    openPay("subscription", plan);
  }

  /* ---------- voluntary appreciation gift (no sign-in needed) ---------- */
  function openGift() {
    const G = C.gift;
    const ugxOf = (amt, cur) => Math.round(toUGX(amt, cur));
    modal(`<h2>${esc(t("gift_title"))}</h2>
      <p class="muted">${esc(t("gift_desc").replace("{min}", C.gift.minUGX.toLocaleString(numLoc())).replace("{max}", C.gift.maxUGX.toLocaleString(numLoc())))}</p>
      <div class="grid2">
        <label>${esc(t("gift_amount"))}<input id="giftAmt" type="number" min="1" step="any" class="input" placeholder="5000"></label>
        <label>${esc(t("gift_currency"))}<select id="giftCur" class="input">
          ${Object.keys(C.currencies).map(c => `<option value="${c}" ${c === "UGX" ? "selected" : ""}>${esc(C.currencies[c].label)}</option>`).join("")}
        </select></label>
      </div>
      <p id="giftEquiv" class="big-amount"></p>
      <p id="giftErr" class="error" role="alert"></p>
      <h3>${esc(t("pay_method"))}</h3>
      <div class="methods">${METHODS.map((m, i) => `
        <label class="method"><input type="radio" name="gmethod" value="${m.id}" ${i === 0 ? "checked" : ""}>
          <span class="brand" style="--c:${m.c};--fg:${m.fg}">${esc(m.name)}</span></label>`).join("")}
      </div>
      <p class="muted small-note">${esc(t(payNoteKey()))}</p>
      <div class="actions">
        <button class="btn ghost" data-close>${esc(t("cancel"))}</button>
        <button class="btn big" id="giftSend">${esc(t("gift_send"))}</button>
      </div>`);
    const check = () => {
      const amt = parseFloat($("#giftAmt").value);
      const cur = $("#giftCur").value;
      const eq = amt > 0 ? ugxOf(amt, cur) : 0;
      $("#giftEquiv").textContent = eq ? `${t("gift_equiv")}: ${fmt(eq, "UGX")}` : "";
      const ok = eq >= G.minUGX && eq <= G.maxUGX;
      $("#giftErr").textContent = eq && !ok ? t("gift_range").replace("{min}", G.minUGX.toLocaleString(numLoc())).replace("{max}", G.maxUGX.toLocaleString(numLoc())) : "";
      $("#giftSend").disabled = !ok;
      return { ok, eq, amt, cur };
    };
    $("#giftAmt").oninput = check; $("#giftCur").onchange = check;
    check();
    $("#giftSend").onclick = async () => {
      const { ok, eq, amt, cur } = check();
      if (!ok) return;
      const btn = $("#giftSend");
      const method = $("input[name=gmethod]:checked").value;
      btn.disabled = true; btn.textContent = t("pay_processing");
      try {
        const r = await DB.pay({ amountUGX: eq, purpose: "gift", method, note: `${amt} ${cur}` });
        if (r && r.pending) return;
        closeModal(); toast(t("gift_thanks")); route();
      } catch (e) {
        btn.disabled = false; btn.textContent = t("gift_send");
        toast("Payment could not be completed. Please try again.");
      }
    };
  }

  /* ---------- owner / customer dashboard ---------- */
  function viewDashboard() {
    return viewDashboardInner() + closeAccountCardHTML();
  }
  function viewDashboardInner() {
    const raw = DB.currentUserRaw();
    if (!raw) { toast(t("not_signed_in")); return go("#/login"); }
    if (raw.role === "admin") return go("#/zero");
    const u = DB.currentUser();
    const profile = `<div class="card">
      <h3>${esc(t("dash_welcome"))}, ${esc(u.firstName)}</h3>
      <p><b>${esc(t("legal_name"))}:</b> ${esc(u.firstName)} ${esc(u.lastName)}</p>
      <p><b>${esc(t("id_label"))}:</b> ${esc(t(u.idType))} · ${esc(raw.idMasked)}</p>
      <p><b>${esc(t("phone_label"))}:</b> <bdi dir="ltr">${esc(u.phone)}</bdi> <span class="verified">✓</span></p>
      <p><b>${esc(t("email_label"))}:</b> <bdi dir="ltr">${esc(u.email)}</bdi> <span class="verified">✓</span></p>
    </div>`;
    if (u.role === "customer") {
      const saved = DB.publicListings().filter(l => u.saved.includes(l.id));
      const liked = DB.publicListings().filter(l => u.liked.includes(l.id));
      return `${profile}
        ${upgradeCardHTML(raw)}
        ${savedSearchesHTML(u)}
        <h2>${esc(t("saved_listings"))}</h2>
        <div class="grid">${saved.length ? saved.map(card).join("") : `<p class="muted">${esc(t("no_saved"))}</p>`}</div>
        <h2>${esc(t("liked_listings"))}</h2>
        <div class="grid">${liked.length ? liked.map(card).join("") : `<p class="muted">${esc(t("no_saved"))}</p>`}</div>`;
    }
    // owner
    const st = DB.subState(raw);
    const plan = raw.subscription ? C.plans[raw.subscription.plan] : null;
    const mine = DB.listingsForOwner(raw.id);
    const used = mine.length;
    const limit = raw.subscription ? raw.subscription.limit : 0;
    const exp = raw.subscription ? raw.subscription.expiresAt : 0;
    const daysLeft = Math.max(0, Math.ceil((exp - Date.now()) / DAY));
    const statusTxt = st === "active" ? `${t("status_active")} · ${t("expires_on")} ${dateStr(exp)} (${N(daysLeft)} ${t("days")})`
      : st === "expired" ? `${t("status_hidden")} · ${t("delete_in")} ${DB.daysLeftBeforeDelete(raw)} ${t("days")}`
      : t("need_subscription");
    const canAdd = DB.canAddListing(raw);
    const regCard = `<div class="card ${raw.registrationPaid ? "" : "attention"}">
      <h3>${esc(t("reg_fee_title"))}</h3>
      ${raw.registrationPaid
        ? `<p class="verified">✓ ${esc(t("pay_success"))}</p>`
        : `<p>${esc(t("reg_fee_desc"))}</p><p class="big-amount">${regFeeHTML(raw.nationality)}</p>
           <button class="btn big" id="payReg">${esc(t("pay_reg_fee"))}</button>`}
    </div>`;
    const subCard = `<div class="card">
      <h3>${esc(t("current_plan_title"))}</h3>
      <p><b>${esc(plan ? t(plan.name_key) : "—")}</b></p>
      <p><span>${esc(statusTxt)}</span></p>
      <p>${esc(t("used_of"))} <b>${N(used)}</b> ${esc(t("of"))} <b>${N(limit)}</b> ${esc(t("items"))}</p>
      ${st === "expired" ? `<p class="error">${esc(t("hidden_note"))}</p>` : ""}
      <div class="progress"><span style="width:${limit ? Math.min(100, used / limit * 100) : 0}%"></span></div>
      ${st === "active" || st === "expired" ? `<button class="btn" data-renew="${raw.subscription.plan}">${esc(t("renew"))}</button>` : ""}
      <p class="muted small-note">${esc(t("grace_note"))}</p>
    </div>`;
    const planPick = `<div class="plans">${Object.values(C.plans).map(p => `
      <div class="card plan ${raw.subscription && raw.subscription.plan === p.key ? "hot" : ""}">
        <h3>${esc(t(p.name_key))}</h3>
        <p class="plan-price">${localAmountHTML(p.price, countryCur(raw.nationality))}<small> ${esc(t("per_91"))}</small></p>
        <p>${esc(t("list_up_to"))} <b>${N(p.limit)}</b> ${esc(t("items"))}</p>
        <button class="btn ${raw.subscription && raw.subscription.plan === p.key && st !== "none" ? "ghost" : ""}" data-sub="${p.key}">${esc(t("subscribe"))}</button>
      </div>`).join("")}</div>`;
    const rows = mine.map(l => `<tr>
        <td>${esc(L(l, "title"))}</td>
        <td>${esc(t(CAT_KEY[l.category]))}</td>
        <td>${esc(t(l.listingType === "sale" ? "type_sale" : "type_rent"))}</td>
        <td>${localAmountHTML(toUGX(l.price, l.currency), countryCur(raw.nationality))}</td>
        <td><span class="badge ${st === "active" ? "ok" : "warn"}">${esc(st === "active" ? t("status_active") : t("status_hidden"))}</span></td>
        <td class="small-note">${N(l.views || 0)} ${esc(t("views_label"))} · ${N(l.likes.length)} ♥ · ${N(l.contactClicks || 0)} ${esc(t("contacts"))}</td>
        <td class="nowrap">
          <a class="btn small" href="#/edit/${l.id}">${esc(t("edit"))}</a>
          ${st === "active" ? `<button class="btn small${DB.isBoosted(l) ? " boosted" : ""}" data-boost="${l.id}" title="${esc(t("boost_btn"))}">${esc(t("boost_btn"))}</button>` : ""}
          <button class="btn small danger" data-del="${l.id}">${esc(t("delete"))}</button>
        </td></tr>`).join("");
    return `${profile}
      ${renewBanner(raw, st)}
      <div class="dash-grid">${regCard}${subCard}</div>
      ${referralCardHTML(raw)}
      ${receiptsHTML(raw)}
      <h2>${esc(t("subscription_title"))}</h2>
      ${planPick}
      <div class="row gap between">
        <h2>${esc(t("my_listings"))}</h2>
        ${raw.registrationPaid && st === "active" && canAdd.ok
          ? `<a class="btn big" href="#/new">+ ${esc(t("add_listing"))}</a>`
          : `<span class="muted">${esc(t(canAdd.reason || "need_subscription"))}</span>`}
      </div>
      <div class="table-wrap"><table>
        <thead><tr><th>${esc(t("title"))}</th><th>${esc(t("category"))}</th><th>${esc(t("listing_type"))}</th><th>${esc(t("price_label"))}</th><th>${esc(t("status_active").split(" ")[0])}</th><th>${esc(t("insights"))}</th><th>${esc(t("action"))}</th></tr></thead>
        <tbody>${rows || `<tr><td colspan="6" class="muted">${esc(t("no_rows"))}</td></tr>`}</tbody>
      </table></div>`;
  }
  function bindDashboard() {
    const raw = DB.currentUserRaw();
    bindUpgrade();
    const ca = $("#closeAcct"); if (ca) ca.onclick = () => confirmCloseAccount();
    $$("[data-copy-ref]").forEach(b => b.onclick = async () => { try { await navigator.clipboard.writeText(b.dataset.copyRef); toast(t("copied")); } catch (e) { toast(b.dataset.copyRef); } });
    if (!raw || raw.role !== "owner") return;
    const pr = $("#payReg"); if (pr) pr.onclick = () => openPay("registration");
    $$("[data-sub]").forEach(b => b.onclick = () => subscribeFlow(b.dataset.sub));
    $$("[data-renew]").forEach(b => b.onclick = () => openPay("subscription", b.dataset.renew));
    $$("[data-boost]").forEach(b => b.onclick = () => openPay("boost", null, b.dataset.boost));
    $$("[data-receipt]").forEach(b => b.onclick = () => openReceipt(b.dataset.receipt));
    $$("[data-run]").forEach(b => b.onclick = () => {
      const s = (DB.currentUser().savedSearches || []).find(x => x.id === b.dataset.run);
      if (s) { Object.assign(F, s.filters, { loc: (s.filters.loc || []).slice() }); go("#/listings"); }
    });
    $$("[data-sdel]").forEach(b => b.onclick = () => { DB.removeSavedSearch(b.dataset.sdel); route(); });
    $$("[data-del]").forEach(b => b.onclick = () => {
      if (!confirm("Delete this listing?")) return;
      DB.deleteListing(raw.id, b.dataset.del); toast(t("listing_deleted")); route();
    });
  }

  /* ---------- listing form (add / edit) ---------- */
  function viewListingForm(editId) {
    const raw = DB.currentUserRaw();
    if (!raw) { toast(t("not_signed_in")); go("#/login"); return ""; }
    if (raw.role !== "owner") { toast(t("role_owner")); go("#/dashboard"); return ""; }
    const existing = editId ? DB.getListing(editId) : null;
    if (existing && existing.ownerId !== raw.id) { go("#/dashboard"); return ""; }
    if (!existing) {
      const c = DB.canAddListing(raw);
      if (!c.ok) return `<section class="card"><h2>${esc(t("add_listing"))}</h2><p class="error">${esc(t(c.reason))}</p>
        <a class="btn" href="#/dashboard">${esc(t("nav_dashboard"))}</a></section>`;
    }
    const cat = existing ? existing.category : "house";
    const type = existing ? existing.listingType : "sale";
    const cur = existing ? existing.currency : "UGX";
    const country = existing ? existing.country : "UGA";
    const termsSel = existing ? (type === "sale" ? existing.paymentTerms : existing.rentDurations) : [];
    return `<section class="card form-card">
      <h1>${esc(t(existing ? "edit_listing" : "new_listing"))}</h1>
      <form id="listingForm" novalidate>
        <div class="grid2">
          <label>${esc(t("category"))}<select name="category" class="input" id="lCat">
            ${CATS.map(k => `<option value="${k}" ${cat === k ? "selected" : ""}>${esc(t(CAT_KEY[k]))}</option>`).join("")}</select></label>
          <fieldset class="radio-row"><legend>${esc(t("listing_type"))}</legend>
            <label class="radio-card"><input type="radio" name="listingType" value="sale" ${type === "sale" ? "checked" : ""}> ${esc(t("type_sale"))}</label>
            <label class="radio-card"><input type="radio" name="listingType" value="rent" ${type === "rent" ? "checked" : ""}> ${esc(t("type_rent"))}</label>
          </fieldset>
        </div>
        <div class="grid2">
          <label>${esc(t("country"))}<select name="country" class="input" id="lCountry">
            ${Object.keys(GEO).map(k => `<option value="${k}" ${country === k ? "selected" : ""}>${flagOf(k)}${esc(GEO[k].name)}</option>`).join("")}</select></label>
          <label>${esc(t("price_label"))}<div class="inline">
            <input name="price" type="number" min="1" class="input" value="${existing ? existing.price : ""}" required>
            <select name="currency" class="input">${Object.keys(C.currencies).map(c => `<option value="${c}" ${cur === c ? "selected" : ""}>${esc(c)}</option>`).join("")}</select>
          </div></label>
        </div>
        <h3>${esc(t("location"))}</h3>
        <div id="lLoc" class="loc-host"></div>
        <label>${esc(t("listing_commodity"))}<input name="title" class="input" maxlength="120" value="${existing ? esc(existing.title) : ""}" required></label>
        <label>${esc(t("description"))}<textarea name="description" class="input" rows="4" maxlength="1200">${existing ? esc(existing.description) : ""}</textarea></label>
        <h3>${esc(t("photos"))}</h3>
        <p class="muted small-note" id="photoHint"></p>
        <div id="photoGrid" class="photo-grid"></div>
        <label class="file-label">${esc(t("photo_add"))}
          <input type="file" id="lPhotos" accept="image/jpeg,image/png,image/webp" multiple class="input">
        </label>
        <p id="photoErr" class="error" role="alert"></p>
        <div id="landBox" class="veh-box" ${cat === "plot" ? "" : "hidden"}>
          <h3>${esc(t("land_details"))}</h3>
          <fieldset class="radio-row"><legend>${esc(t("land_type"))}</legend>
            <label class="radio-card"><input type="radio" name="landType" value="customary" ${existing && existing.land && existing.land.type === "customary" ? "checked" : ""}> ${esc(t("land_customary"))}</label>
            <label class="radio-card"><input type="radio" name="landType" value="non_customary" ${existing && existing.land && existing.land.type === "non_customary" ? "checked" : ""}> ${esc(t("land_non_customary"))}</label>
          </fieldset>
          <div class="grid2">
            <label>${esc(t("land_length"))}<input name="landLen" type="number" min="0" step="any" class="input" id="landLen" value="${existing && existing.land ? existing.land.length : ""}"></label>
            <label>${esc(t("land_breadth"))}<input name="landBreadth" type="number" min="0" step="any" class="input" id="landBreadth" value="${existing && existing.land ? existing.land.breadth : ""}"></label>
            <label>${esc(t("land_unit"))}<select name="landUnit" class="input" id="landUnit">
              <option value="m" ${!existing || !existing.land || existing.land.unit !== "km" ? "selected" : ""}>${esc(t("land_unit_m"))}</option>
              <option value="km" ${existing && existing.land && existing.land.unit === "km" ? "selected" : ""}>${esc(t("land_unit_km"))}</option></select></label>
          </div>
          <p id="landArea" class="muted"></p>
        </div>
        <div id="vehBox" class="veh-box" ${cat === "auto" ? "" : "hidden"}>
          <h3>${esc(t("vehicle_details"))}</h3>
          <div class="grid2">
            <label>${esc(t("engine_no"))}<input name="vEngine" class="input" maxlength="40" value="${esc(existing && existing.vehicle ? existing.vehicle.engine : "")}"></label>
            <label>${esc(t("chassis_no"))}<input name="vChassis" class="input" maxlength="40" value="${esc(existing && existing.vehicle ? existing.vehicle.chassis : "")}"></label>
            <label class="span2">${esc(t("plate_no"))}<input name="vPlate" class="input" maxlength="20" value="${esc(existing && existing.vehicle ? existing.vehicle.plate : "")}"></label>
          </div>
        </div>
        <h3>${esc(t("features"))}</h3>
        <div id="lFeat">${featureDropdown(cat, existing ? (existing.featuresText ? [existing.featuresText] : existing.features) : [], existing ? existing.rooms : null)}</div>
        <h3 id="lTermsTitle">${esc(t(type === "sale" ? "payment_terms" : "rent_durations"))}</h3>
        <div id="lTerms" class="chk-row">${termsOptions(type, termsSel)}</div>
        <div id="completeBox" class="card complete-box"></div>
        <p id="lErr" class="error" role="alert"></p>
        <div class="actions">
          <a class="btn ghost" href="#/dashboard">${esc(t("cancel"))}</a>
          <button class="btn big" type="submit">${esc(t("save_listing"))}</button>
        </div>
      </form>
    </section>`;
  }
  function termsOptions(type, sel) {
    const keys = type === "sale" ? ["pt_full", "pt_installment"] : ["rd_daily", "rd_weekly", "rd_monthly", "rd_quarterly", "rd_yearly"];
    return keys.map(k => `<label class="chk"><input type="checkbox" name="terms" value="${k}" ${sel.includes(k) ? "checked" : ""}> ${esc(t(k))}</label>`).join("");
  }
  function bindListingForm(editId) {
    const raw = DB.currentUserRaw();
    if (!raw || raw.role !== "owner") return;
    const existing = editId ? DB.getListing(editId) : null;
    const form = $("#listingForm"); if (!form) return;
    // (i) buttons open an explanation; they never tick the feature box
    form.addEventListener("click", (e) => {
      const b = e.target.closest("[data-info]"); if (!b) return;
      e.preventDefault(); e.stopPropagation();
      modal(`<h2>${esc(t("more_info"))}</h2><p>${esc(t(b.dataset.info))}</p>
        <div class="actions"><button class="btn big" data-close>${esc(t("close"))}</button></div>`);
    });
    const completeItems = () => {
      const cat = form.category.value;
      const val = (n) => { const el = form.querySelector(`[name=${n}]`); return el ? String(el.value || "").trim() : ""; };
      const items = [
        [val("title").length >= 10, t("tip_title")],
        [val("description").length >= 80, t("tip_description")],
        [+val("price") > 0, t("tip_price")],
        cat === "other"
          ? [val("otherFeatures").length >= 20, t("tip_other_text")]
          : [form.querySelectorAll("input[name=feat]:checked").length >= 2, t("tip_features")],
      ];
      if (cat === "plot") items.push([!!landArea(), t("tip_land")]);
      if (cat === "auto") items.push([["vEngine", "vChassis", "vPlate"].every(n => val(n)), t("tip_vehicle")]);
      return items;
    };
    const updateComplete = () => {
      const items = completeItems(); const done = items.filter(i => i[0]).length;
      const pct = Math.round(done / items.length * 100);
      $("#completeBox").innerHTML = `<b>${esc(t("completeness"))}: ${pct}%</b><ul>${items.map(([ok, txt]) => `<li class="${ok ? "ok" : ""}">${ok ? "✓" : "○"} ${esc(txt)}</li>`).join("")}</ul>`;
    };
    form.addEventListener("input", updateComplete);
    form.addEventListener("change", updateComplete);
    form.addEventListener("change", (e) => {
      if (e.target.name !== "feat" || e.target.value !== "f_more_than_two_rooms") return;
      const n = form.querySelector("[name=roomsCount]");
      if (!n) return;
      n.hidden = !e.target.checked;
      if (n.hidden) n.value = ""; else n.focus();
    });
    updateComplete();
    let locH = mountLoc($("#lLoc"), form.country.value, existing ? existing.location : [], () => {}, false);
    const getLoc = () => locH.get();
    form.country.onchange = () => {
      $("#lLoc").innerHTML = "";
      locH = mountLoc($("#lLoc"), form.country.value, [], () => {}, false);
    };
    $("#lCat").onchange = (e) => { $("#lFeat").innerHTML = featureDropdown(e.target.value, []); $("#vehBox").hidden = e.target.value !== "auto"; $("#landBox").hidden = e.target.value !== "plot"; };
    const showArea = () => { const L = landArea(); $("#landArea").textContent = L ? `${t("land_area")}: ${L.value.toLocaleString(numLoc())} ${L.unit} (${areaEquivalents(L.value, L.unit)})` : ""; };
    ["landLen", "landBreadth", "landUnit"].forEach(id => { const el = $("#" + id); if (el) el.oninput = el.onchange = showArea; });
    showArea();
    $$("[name=listingType]").forEach(r => r.onchange = () => {
      $("#lTerms").innerHTML = termsOptions(r.value, []);
      $("#lTermsTitle").textContent = t(r.value === "sale" ? "payment_terms" : "rent_durations");
    });
    // ---- photos (limit set by owner's plan) ----
    const photoLimit = DB.photoLimitFor(raw);
    let photos = existing ? (existing.photos || []).slice() : [];
    const drawPhotos = () => {
      $("#photoHint").textContent = t("photo_hint").replace("{n}", N(photoLimit))
        + ` — ${photos.length}/${photoLimit}`;
      $("#photoGrid").innerHTML = photos.map((src, i) => `
        <div class="photo-item"><img src="${src}" alt="">
          <button type="button" class="btn small danger" data-rmphoto="${i}">${esc(t("remove"))}</button></div>`).join("");
      $$("[data-rmphoto]").forEach(b => b.onclick = () => { photos.splice(+b.dataset.rmphoto, 1); drawPhotos(); });
      $("#lPhotos").disabled = photos.length >= photoLimit;
    };
    drawPhotos();
    $("#lPhotos").onchange = async (e) => {
      const err = $("#photoErr"); err.textContent = "";
      for (const file of Array.from(e.target.files)) {
        if (photos.length >= photoLimit) { err.textContent = t("photo_limit_reached"); break; }
        try { photos.push(await DB.processPhoto(file)); }
        catch (ex) { err.textContent = t(ex.message); }
      }
      e.target.value = "";
      drawPhotos();
    };

    form.onsubmit = (e) => {
      e.preventDefault();
      const err = $("#lErr"); err.textContent = "";
      const fd = new FormData(form);
      const path = getLoc();
      const price = +fd.get("price");
      const title = String(fd.get("title") || "").trim();
      if (!title || !(price > 0)) return err.textContent = t("fill_all");
      if (path.length < 2) return err.textContent = t("loc_choose_level") + " — " + t("lv_district");
      if (fd.get("category") === "house" && $("input[name=feat][value=f_more_than_two_rooms]:checked")) {
        const n = +fd.get("roomsCount");
        if (!(Number.isInteger(n) && n >= 3)) return err.textContent = t("rooms_invalid");
      }
      if (fd.get("category") === "plot") {
        const L = landArea();
        if (!fd.get("landType")) return err.textContent = t("land_type_required");
        if (!L) return err.textContent = t("land_dims_required");
      }
      const type = fd.get("listingType");
      const data = {
        category: fd.get("category"), listingType: type, country: fd.get("country"),
        location: path, title, description: String(fd.get("description") || "").trim(),
        price, currency: fd.get("currency"),
        features: $$("input[name=feat]:checked").map(x => x.value),
        rooms: fd.get("category") === "house" && $("input[name=feat][value=f_more_than_two_rooms]:checked") ? +fd.get("roomsCount") : null,
        featuresText: fd.get("category") === "other" ? String(fd.get("otherFeatures") || "").trim() : "",
        land: fd.get("category") === "plot" ? { type: fd.get("landType"), length: +fd.get("landLen"), breadth: +fd.get("landBreadth"), unit: fd.get("landUnit"), area: landArea().value, areaUnit: landArea().unit } : null,
        vehicle: fd.get("category") === "auto" ? { engine: String(fd.get("vEngine") || "").trim(), chassis: String(fd.get("vChassis") || "").trim(), plate: String(fd.get("vPlate") || "").trim() } : null,
        paymentTerms: type === "sale" ? fd.getAll("terms") : [],
        rentDurations: type === "rent" ? fd.getAll("terms") : [],
        photos
      };
      try {
        DB.saveListing(raw.id, data, editId || null);
        toast(t("listing_saved"));
        go("#/dashboard");
      } catch (ex) {
        const key = ex.message === "photo_limit" ? "photo_limit_save" : ex.message;
        err.textContent = t(key) || t("limit_reached");
      }
    };
  }

  /* ---------- admin ---------- */
  let adminTab = "overview";
  let adminContentLang = null;
  let adminPending = null; // {target, userId} while waiting for the 2FA code
  function viewAdmin() {
    adminPending = null; // a fresh visit always starts at step 1
    const raw = DB.currentUserRaw();
    if (!raw || raw.role !== "admin") {
      return `<section class="auth card">
        <h1>${esc(t("admin_login_title"))}</h1>
        <form id="adminLogin" novalidate>
          <label>${esc(t("login_id"))}<input name="id" class="input" autocomplete="username" required></label>
          <label>${esc(t("password"))}<input name="pw" type="password" class="input" autocomplete="current-password" required></label>
          <div id="adminOtpRow" hidden>
            <p class="muted">🔐 ${esc(t("admin_2fa"))}</p>
            <label>${esc(t("admin_otp_label"))}<input id="adminOtp" class="input otp-input" maxlength="6" inputmode="numeric" autocomplete="one-time-code"></label>
          </div>
          <p id="loginErr" class="error" role="alert"></p>
          <button class="btn big" id="adminSubmit" type="submit">${esc(t("login_btn"))}</button>
        </form>

      </section>`;
    }
    const s = DB.stats();
    const tabs = ["overview", "users", "listings", "payments", "activity", "notice", "legal", "settings", "content"];
    let body = "";
    if (adminTab === "overview") {
      body = widgetChooser() + (adminWidgets().stats ? `<div class="stats">
        <div class="card stat"><span>${esc(t("total_users"))}</span><b>${N(s.users)}</b></div>
        <div class="card stat"><span>${esc(t("owners"))}</span><b>${N(s.owners)}</b></div>
        <div class="card stat"><span>${esc(t("active_listings"))}</span><b>${N(s.live)}</b></div>
        <div class="card stat"><span>${esc(t("hidden_listings"))}</span><b>${N(s.hidden)}</b></div>
        <div class="card stat wide"><span>${esc(t("revenue"))}</span><b>${s.revenue.toLocaleString(numLoc())}</b></div>
      </div>
      <p class="muted">${esc(t("dash_stats"))}: ${esc(dateStr(Date.now()))}</p>` : "") + (adminWidgets().revenue ? revenueSection() : "");
    } else if (adminTab === "users") {
      const rows = DB.allUsers().filter(u => u.role !== "admin").map(u => {
        const st = u.role === "owner" ? DB.subState(DB.findUserByLogin(u.email)) : "—";
        const hay = `${u.firstName} ${u.lastName} ${u.email} ${u.phone} ${u.role} ${u.nationality || ""}`.toLowerCase();
        return `<tr data-search="${esc(hay)}"><td>${esc(u.firstName)} ${esc(u.lastName)}</td><td>${esc(u.role)}</td><td>${esc(u.nationality || "")}</td>
          <td><bdi dir="ltr">${esc(u.phone)}</bdi><br><small><bdi dir="ltr">${esc(u.email)}</bdi></small></td>
          <td>${u.registrationPaid ? "✓" : "—"}</td><td>${esc(st)}</td>
          <td>${u.suspended ? `<span class="badge warn">${esc(t("suspended"))}</span>` : `<span class="badge ok">${esc(t("verified"))}</span>`}</td>
          <td class="nowrap">
            ${u.role === "owner" ? `<button class="btn small" data-verify="${u.id}">${esc(t(u.verified ? "unverify_owner" : "verify_owner"))}</button>` : ""}
            <button class="btn small" data-uact="${u.suspended ? "activate" : "suspend"}" data-uid="${u.id}">${esc(t(u.suspended ? "activate" : "suspend"))}</button>
            <button class="btn small danger" data-udel="${u.id}">${esc(t("delete"))}</button></td></tr>`;
      }).join("");
      body = searchBox("userSearch", t("search_users")) + tableHTML(["Name", "Role", "Nationality", "Contact", "Reg.", "Subscription", "Status", t("action")], rows);
    } else if (adminTab === "listings") {
      const rows = DB.allListings().map(l => {
        const owner = DB.ownerOf(l);
        const hay = `${l.title} ${owner ? owner.name : ""} ${locLabel(l)}`.toLowerCase();
        return `<tr data-search="${esc(hay)}"><td>${esc(l.title)}</td><td>${esc(owner ? owner.name : "—")}</td>
          <td>${esc(locLabel(l))}</td><td>${esc(fmt(l.price, l.currency))}</td>
          <td>${DB.isVisible(l) ? `<span class="badge ok">${esc(t("status_active"))}</span>` : `<span class="badge warn">${esc(t("status_hidden"))}</span>`}</td>
          <td><button class="btn small ${l.removedByAdmin ? "" : "danger"}" data-lact="${l.removedByAdmin ? "restore" : "remove"}" data-lid="${l.id}">${esc(t(l.removedByAdmin ? "activate" : "remove"))}</button></td></tr>`;
      }).join("");
      body = searchBox("listingSearch", t("search_listings")) + tableHTML(["Title", "Owner", "Location", "Price", "Status", t("action")], rows);
    } else if (adminTab === "legal") {
      body = legalForm();
    } else if (adminTab === "notice") {
      body = noticeForm();
    } else if (adminTab === "settings") {
      body = settingsForm();
    } else if (adminTab === "content") {
      body = contentForm();
    } else if (adminTab === "activity") {
      const rows = DB.activityLog().map(e => `<tr><td>${esc(dateStr(e.ts))}</td><td>${esc(e.action)}</td><td>${esc(e.target)}</td></tr>`).join("");
      body = tableHTML([t("time"), t("action"), t("target")], rows);
    } else {
      const rows = DB.allPayments().slice().reverse().map(p => `<tr>
        <td>${esc(p.id)}</td><td>${esc(p.purpose)} ${esc(p.plan)}</td><td>${esc(p.method)}</td>
        <td>${esc(fmt(p.amountUGX, "UGX"))}</td><td>${esc(dateStr(p.date))}</td></tr>`).join("");
      body = tableHTML(["Ref", "Purpose", "Method", "Amount", "Date"], rows)
        + `<button class="btn ghost" id="exportCsv">${esc(t("export_csv"))}</button>`;
    }
    return `<section>
      <h1>${esc(t("admin_title"))}</h1>
      <div class="tabs">${tabs.map(k => `<button class="tab ${adminTab === k ? "on" : ""}" data-tab="${k}">${esc(t(k === "listings" ? "listings_tab" : k))}</button>`).join("")}</div>
      ${body}
    </section>`;
  }
  function revenueSection() {
    const rb = DB.revenueBreakdown();
    const grand = Object.values(rb.byPlan).reduce((a, x) => a + x.ugx, 0);
    const planKeys = ["registration", "budget", "economy", "premium", "gift"];
    const labelOf = (k) => k === "registration" ? t("reg_fee_title") : k === "gift" ? t("gift_label") : t("plan_" + k);
    const planRows = planKeys.map(k => {
      const x = rb.byPlan[k];
      const share = grand ? (x.ugx / grand * 100).toFixed(1) : "0.0";
      return `<tr><td>${esc(labelOf(k))}</td><td>${N(x.count)}</td><td>${x.ugx.toLocaleString(numLoc())}</td><td>${N(share)}%</td></tr>`;
    }).join("");
    const countries = Object.keys(rb.byCountry).sort((a, b) => rb.byCountry[b].total - rb.byCountry[a].total);
    const countryRows = countries.map(c => {
      const x = rb.byCountry[c];
      return `<tr><td>${esc(c)}</td><td>${(x.registration || 0).toLocaleString(numLoc())}</td>
        <td>${(x.budget || 0).toLocaleString(numLoc())}</td><td>${(x.economy || 0).toLocaleString(numLoc())}</td>
        <td>${(x.premium || 0).toLocaleString(numLoc())}</td><td>${(x.gift || 0).toLocaleString(numLoc())}</td><td><b>${x.total.toLocaleString(numLoc())}</b></td></tr>`;
    }).join("");
    const totalsRow = countries.length ? `<tr><td><b>${esc(t("total"))}</b></td>${planKeys.map(k => `<td><b>${rb.byPlan[k].ugx.toLocaleString(numLoc())}</b></td>`).join("")}<td><b>${grand.toLocaleString(numLoc())}</b></td></tr>` : "";
    return `<h2>${esc(t("revenue_by_plan"))}</h2>
      ${tableHTML([t("subscription_type"), t("payments_count"), t("revenue_ugx"), t("share")], planRows)}
      <h2>${esc(t("revenue_by_country"))}</h2>
      <div class="table-wrap"><table><thead><tr>
        <th>${esc(t("country"))}</th><th>${esc(t("reg_fee_title"))}</th><th>${esc(t("plan_budget"))}</th>
        <th>${esc(t("plan_economy"))}</th><th>${esc(t("plan_premium"))}</th><th>${esc(t("gift_label"))}</th><th>${esc(t("total"))}</th>
      </tr></thead><tbody>${countryRows || `<tr><td colspan="7" class="muted">${esc(t("no_rows"))}</td></tr>`}${totalsRow}</tbody></table></div>
      <p class="muted small-note">${esc(t("country_note"))}</p>`;
  }
  function searchBox(id, placeholder) {
    return `<input id="${id}" class="input search-box" type="search" placeholder="${esc(placeholder)}" aria-label="${esc(placeholder)}">`;
  }
  function tableHTML(heads, rows) {
    return `<div class="table-wrap"><table><thead><tr>${heads.map(h => `<th>${esc(h)}</th>`).join("")}</tr></thead>
      <tbody>${rows || `<tr><td colspan="${heads.length}" class="muted">${esc(t("no_rows"))}</td></tr>`}</tbody></table></div>`;
  }
  function bindAdmin() {
    const login = $("#adminLogin");
    if (login) {
      login.onsubmit = async (e) => {
        e.preventDefault();
        const err = $("#loginErr"); err.textContent = "";
        // Step 2: verify the emailed security code, then start the session
        if (adminPending) {
          const code = $("#adminOtp").value;
          const ok = await DB.verifyOTP(adminPending.target, code);
          if (!ok) { err.textContent = t("otp_invalid"); return; }
          DB.startSession(adminPending.userId);
          adminPending = null;
          route();
          return;
        }
        // Step 1: check password, then send a security code (no session yet)
        const fd = new FormData(login);
        const u = await DB.checkCredentials(String(fd.get("id")).trim(), String(fd.get("pw")));
        if (!u || u.role !== "admin") { err.textContent = t("bad_login"); return; }
        const target = DB.V.normEmail(u.email);
        const { demoCode } = await DB.sendOTP(target);
        adminPending = { target, userId: u.id };
        $("#adminOtpRow").hidden = false;
        $("#adminSubmit").textContent = t("admin_verify");
        $("#adminOtp").focus();
        toast(t("admin_code_sent"));
        if (demoCode) toast(`${t("verify_code")}: ${demoCode}`);
      };
      return;
    }
    $$("[data-tab]").forEach(b => b.onclick = () => { adminTab = b.dataset.tab; route(); });
    ["userSearch", "listingSearch"].forEach(id => {
      const box = document.getElementById(id); if (!box) return;
      box.oninput = () => {
        const q = box.value.trim().toLowerCase();
        box.closest("section").querySelectorAll("tbody tr[data-search]").forEach(tr => {
          tr.hidden = !!q && !tr.dataset.search.includes(q);
        });
      };
    });
    $$("[data-verify]").forEach(b => b.onclick = () => { DB.toggleOwnerVerified(b.dataset.verify); route(); });
    bindAdminTools();
    $$("[data-uact]").forEach(b => b.onclick = () => { DB.setUserSuspended(b.dataset.uid, b.dataset.uact === "suspend"); route(); });
    $$("[data-udel]").forEach(b => b.onclick = () => { if (confirm("Delete user and their listings?")) { DB.deleteUser(b.dataset.udel); route(); } });
    $$("[data-lact]").forEach(b => b.onclick = () => { DB.setListingRemoved(b.dataset.lid, b.dataset.lact === "remove"); route(); });
    const ex = $("#exportCsv");
    if (ex) ex.onclick = () => {
      const rows = [["ref", "purpose", "plan", "country", "method", "amountUGX", "date"]]
        .concat(DB.allPayments().map(p => [p.id, p.purpose, p.plan, DB.paymentCountry(p), p.method, p.amountUGX, new Date(p.date).toISOString()]));
      const csv = rows.map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(",")).join("\n");
      const a = document.createElement("a");
      a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
      a.download = "e-asset-payments.csv"; a.click();
    };
  }

  /* ---------- new features: helpers ---------- */
  const viewedSet = new Set();
  function waLink(phone, title) {
    const digits = String(phone || "").replace(/\D/g, "");
    const msg = encodeURIComponent(`Hello, I am interested in "${title}" listed on NOMIDMAN TRANS CO. LTD.`);
    return `https://wa.me/${digits}?text=${msg}`;
  }
  function matchFilters(l, f) {
    if (f.cat && l.category !== f.cat) return false;
    if (f.type && l.listingType !== f.type) return false;
    if (f.country && l.country !== f.country) return false;
    if (f.loc && f.loc.length && !f.loc.every((v, i) => (l.location || [])[i] === v)) return false;
    if (f.min !== "" && f.min != null && toUGX(l.price, l.currency) < toUGX(+f.min, viewCur)) return false;
    if (f.max !== "" && f.max != null && toUGX(l.price, l.currency) > toUGX(+f.max, viewCur)) return false;
    return true;
  }
  function similarHTML(l) {
    const items = DB.publicListings().filter(x => x.id !== l.id && x.category === l.category)
      .sort((a, b) => (b.country === l.country) - (a.country === l.country)).slice(0, 3);
    if (!items.length) return "";
    return `<h2>${esc(t("similar_title"))}</h2><div class="grid">${items.map(card).join("")}</div>`;
  }
  function renewBanner(raw, st) {
    if (st === "active") {
      const days = Math.ceil((raw.subscription.expiresAt - Date.now()) / DAY);
      if (days > 7) return "";
      return `<div class="card attention"><p>${esc(t("renew_soon").replace("{n}", N(days)))}</p>
        <button class="btn" data-renew="${raw.subscription.plan}">${esc(t("renew"))}</button></div>`;
    }
    if (st === "expired") {
      const date = dateStr(raw.subscription.expiresAt + C.graceDays * DAY);
      return `<div class="card attention"><p class="error">${esc(t("renew_expired").replace("{date}", date))}</p>
        <button class="btn" data-renew="${raw.subscription.plan}">${esc(t("renew"))}</button></div>`;
    }
    return "";
  }
  function receiptsHTML(u) {
    const mine = DB.allPayments().filter(p => p.userId === u.id).slice().reverse();
    const rows = mine.map(p => `<tr><td>${esc(dateStr(p.date))}</td>
      <td>${esc(p.purpose === "boost" ? t("boost_btn") : p.purpose === "gift" ? t("gift_label") : p.purpose === "registration" ? t("reg_fee_title") : t("plan_" + p.plan))}</td>
      <td>${localAmountHTML(p.amountUGX, countryCur(u.nationality))}</td>
      <td><button class="btn small" data-receipt="${p.id}">${esc(t("receipt"))}</button></td></tr>`).join("");
    return `<h2>${esc(t("receipts"))}</h2>${tableHTML([t("time"), t("subscription_type"), t("price_label"), t("action")], rows)}`;
  }
  function openReceipt(ref) {
    const p = DB.allPayments().find(x => x.id === ref); if (!p) return;
    const u = DB.currentUserRaw();
    const what = p.purpose === "boost" ? t("boost_btn") : p.purpose === "gift" ? t("gift_label") : p.purpose === "registration" ? t("reg_fee_title") : t(C.plans[p.plan].name_key);
    modal(`<div id="receiptPrint"><img class="receipt-watermark" src="assets/logo.svg" alt=""><img class="receipt-logo" src="assets/logo.svg" alt="NOMIDMAN TRANS logo">
      <h2>${esc(t("receipt_title"))}</h2>
      <p><b>NOMIDMAN TRANS CO. LTD</b><br>${esc(C.office.address)}<br>${esc(C.office.poBox)}<br>${esc(t("tel_label"))}: <bdi dir="ltr">${esc(C.office.phone)}</bdi></p>
      <p><b>${esc(t("receipt_ref"))}:</b> <bdi dir="ltr">${esc(p.id)}</bdi><br><b>${esc(t("time"))}:</b> ${esc(dateStr(p.date))}</p>
      <p><b>${esc(t("legal_name"))}:</b> ${esc(u ? u.firstName + " " + u.lastName : "")}</p>
      <p><b>${esc(what)}:</b> ${localAmountHTML(p.amountUGX, countryCur(u.nationality))}</p>
      <p class="muted small-note">${esc(t("receipt_charged_ugx"))}: ${esc(fmt(p.amountUGX, "UGX"))}</p>
      <p class="muted small-note">${esc(p.method)} · paid</p>
    </div>
    <div class="actions"><button class="btn ghost" data-close>${esc(t("close"))}</button>
      <button class="btn big" id="printReceipt">${esc(t("print"))}</button></div>`);
    $("#printReceipt").onclick = () => window.print();
  }
  /* ---------- customer: verify contacts and upgrade to owner ---------- */
  function verifyLine(kind, value, done) {
    const label = kind === "phone" ? t("phone_label") : t("email_label");
    if (done) return `<p class="verified">✓ ${esc(label)}: ${esc(value)} · ${esc(t("contact_verified"))}</p>`;
    return `<div class="verify-line">
      <p>${esc(label)}: ${esc(value)} · <span class="muted">${esc(t("contact_unverified"))}</span></p>
      <div class="inline"><button class="btn small" data-vsend="${kind}">${esc(t("send_otp"))}</button></div>
      <div class="inline otp-row" hidden><input class="input otp-input" maxlength="6" inputmode="numeric" placeholder="${esc(t("otp_code"))}">
        <button class="btn small" data-vverify="${kind}">${esc(t("verify"))}</button></div>
    </div>`;
  }
  function upgradeCardHTML(raw) {
    if (!DB.heldUpgradePayment()) {
      return `<div class="card"><h3>${esc(t("upgrade_title"))}</h3>
        <p class="muted">${esc(t("upgrade_desc"))}</p>
        <button class="btn big" id="upgradeBtn">${esc(t("upgrade_btn"))}</button></div>`;
    }
    const phoneBlock = raw.phone
      ? verifyLine("phone", raw.phone, raw.phoneVerified)
      : `<div class="inline"><input id="vphone" class="input" placeholder="+256…"><button class="btn small" data-vsave-phone>${esc(t("upgrade_save_phone"))}</button></div>`;
    const emailBlock = verifyLine("email", raw.email, raw.emailVerified);
    return `<div class="card"><h3>${esc(t("upgrade_title"))}</h3>
      <p>${esc(t("upgrade_held"))}</p>
      ${phoneBlock}${emailBlock}</div>`;
  }
  function openUpgradePay() {
    const u = DB.currentUser();
    const methods = METHODS.map((m, i) => `<label class="method"><input type="radio" name="umethod" value="${m.id}" ${i === 0 ? "checked" : ""}><span class="brand" style="--c:${m.c};--fg:${m.fg}">${esc(m.name)}</span></label>`).join("");
    modal(`<h2>${esc(t("upgrade_title"))}</h2>
      <p class="big-amount">${esc(t("amount_due"))}: ${regFeeHTML(u.nationality)}</p>
      <p class="muted small-note">${esc(t("reg_hold_note"))}</p>
      <div class="methods">${methods}</div>
      <div class="actions"><button class="btn ghost" data-close>${esc(t("cancel"))}</button>
        <button class="btn big" id="holdUpgrade">${esc(t("reg_hold_btn"))}</button></div>`);
    $("#holdUpgrade").onclick = async () => {
      const btn = $("#holdUpgrade"); btn.disabled = true;
      try {
        await DB.beginUpgrade($("input[name=umethod]:checked").value);
        closeModal(); toast(t("upgrade_held")); route();
      } catch (e) { btn.disabled = false; toast(t(e.message) || "Could not hold the fee."); }
    };
  }
  function bindUpgrade() {
    const u = DB.currentUserRaw(); if (!u || u.role !== "customer") return;
    $$("[data-run]").forEach(b => b.onclick = () => {
      const s = (DB.currentUser().savedSearches || []).find(x => x.id === b.dataset.run);
      if (s) { Object.assign(F, s.filters, { loc: (s.filters.loc || []).slice() }); go("#/listings"); }
    });
    $$("[data-sdel]").forEach(b => b.onclick = () => { DB.removeSavedSearch(b.dataset.sdel); route(); });
    $$("[data-vsend]").forEach(b => b.onclick = async () => {
      const kind = b.dataset.vsend; const target = kind === "phone" ? u.phone : u.email;
      const { demoCode } = await DB.sendOTP(target);
      b.closest(".verify-line").querySelector(".otp-row").hidden = false;
      if (demoCode) toast(`${t("verify_code")}: ${demoCode}`);
    });
    $$("[data-vverify]").forEach(b => b.onclick = async () => {
      const kind = b.dataset.vverify; const target = kind === "phone" ? u.phone : u.email;
      const code = b.closest(".verify-line").querySelector("input").value;
      if (!(await DB.verifyOTP(target, code))) return toast(t("otp_invalid"));
      DB.markContactVerified(kind); toast(t("otp_verified")); route();
    });
    const sp = $("[data-vsave-phone]");
    if (sp) sp.onclick = () => {
      try { DB.updateMyPhone($("#vphone").value); toast(t("upgrade_phone_saved")); route(); }
      catch (e) { toast(t(e.message)); }
    };
    const bu = $("#upgradeBtn"); if (bu) bu.onclick = () => openUpgradePay();
    const cu = $("#completeUpgrade");
    if (cu) cu.onclick = () => {
      try { DB.completeUpgrade(); toast(t("upgrade_done")); go("#/dashboard"); route(); }
      catch (e) { toast(t(e.message)); }
    };
  }
  function savedSearchesHTML(u) {
    const list = u.savedSearches || [];
    if (!list.length) return "";
    const cards = list.map(s => {
      const n = DB.publicListings().filter(l => matchFilters(l, s.filters)).length;
      return `<div class="card">
        <h3>${esc(s.name)}</h3>
        <p class="muted">${N(n)} ${esc(t("matches_now"))}</p>
        <div class="row gap">
          <button class="btn small" data-run="${s.id}">${esc(t("run"))}</button>
          <button class="btn small danger" data-sdel="${s.id}">${esc(t("delete"))}</button>
        </div></div>`;
    }).join("");
    return `<h2>${esc(t("saved_searches"))}</h2><div class="grid">${cards}</div>`;
  }
  function saveSearchModal() {
    const u = DB.currentUser();
    if (!u) { toast(t("not_signed_in")); return go("#/login"); }
    const suggested = [F.cat ? t(CAT_KEY[F.cat]) : t("all"), F.type ? t(F.type === "sale" ? "type_sale" : "type_rent") : "", F.country ? GEO[F.country].name : "", F.loc.slice(-1)[0] || ""].filter(Boolean).join(" · ");
    modal(`<h2>${esc(t("save_search"))}</h2>
      <label>${esc(t("search_name"))}<input id="ssName" class="input" value="${esc(suggested)}" maxlength="80"></label>
      <div class="actions"><button class="btn ghost" data-close>${esc(t("cancel"))}</button>
        <button class="btn big" id="ssSave">${esc(t("save"))}</button></div>`);
    $("#ssSave").onclick = () => {
      const name = $("#ssName").value.trim() || suggested;
      DB.addSavedSearch(name, { ...F, loc: F.loc.slice() });
      closeModal(); toast(t("search_saved")); route();
    };
  }

  /* ---------- admin tools: settings, content and dashboard (saved in this browser) ---------- */
  const SET_KEY = "ea_settings", CONTENT_KEY = "ea_content", WIDGET_KEY = "ea_admin_widgets";
  const CONTENT_KEYS = ["hero_title", "hero_sub", "about_p1", "about_p2", "about_p3", "help_text", "footer_about", "step1", "step2", "step3", "step4"];
  const readJSON = (k, fb) => { try { return JSON.parse(localStorage.getItem(k)) || fb; } catch (e) { return fb; } };
  function loadContent() { return readJSON(CONTENT_KEY, {}); }
  function applySettings() {
    const s = readJSON(SET_KEY, null);
    if (!s) return;
    if (s.office) Object.assign(C.office, s.office);
    if (s.supportEmail) C.supportEmail = s.supportEmail;
    if (s.registrationFee) C.registrationFee = s.registrationFee;
    if (s.boostPrice) C.boost.priceUGX = s.boostPrice;
    if (s.plans) Object.keys(s.plans).forEach(k => { if (C.plans[k] && s.plans[k]) C.plans[k].price = s.plans[k]; });
    if (s.gift) Object.assign(C.gift, s.gift);
    if (s.referral) Object.assign(C.referral, s.referral);
    if (s.hours) Object.assign(C.hours, s.hours);
  }
  function adminWidgets() { return Object.assign({ stats: true, revenue: true }, readJSON(WIDGET_KEY, {})); }
  function widgetChooser() {
    const w = adminWidgets();
    return `<div class="card widget-bar"><b>${esc(t("customise_dashboard"))}:</b>
      <label class="chk"><input type="checkbox" data-widget="stats" ${w.stats ? "checked" : ""}> ${esc(t("widget_stats"))}</label>
      <label class="chk"><input type="checkbox" data-widget="revenue" ${w.revenue ? "checked" : ""}> ${esc(t("widget_revenue"))}</label></div>`;
  }
  function hhmm(v) { const m = /^(\d{1,2}):(\d{2})$/.exec(String(v).trim()); return m ? (+m[1]) + (+m[2]) / 60 : NaN; }
  function toHHMM(x) { const h = Math.floor(x), m = Math.round((x - h) * 60); return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`; }
  function settingsForm() {
    const hrs = C.hours;
    const f = (label, name, type, value) => `<label>${esc(label)}<input name="${name}" type="${type}" ${type === "number" ? 'min="0"' : ""} class="input" value="${esc(value)}"></label>`;
    return `<section class="card"><h2>${esc(t("settings"))}</h2>
      <p class="muted">${esc(t("browser_only_note"))}</p>
      <form id="settingsForm"><div class="grid2">
        ${f(t("office_address"), "address", "text", C.office.address)}
        ${f(t("po_box"), "poBox", "text", C.office.poBox)}
        ${f(t("office_phone"), "phone", "text", C.office.phone)}
        ${f(t("support_email"), "supportEmail", "text", C.supportEmail)}
        ${f(t("reg_fee_label"), "registrationFee", "number", C.registrationFee)}
        ${f(t("boost_price_label"), "boostPrice", "number", C.boost.priceUGX)}
        ${f(t("plan_budget") + " (UGX)", "planBudget", "number", C.plans.budget.price)}
        ${f(t("plan_economy") + " (UGX)", "planEconomy", "number", C.plans.economy.price)}
        ${f(t("plan_premium") + " (UGX)", "planPremium", "number", C.plans.premium.price)}
        ${f(t("gift_min_label"), "giftMin", "number", C.gift.minUGX)}
        ${f(t("gift_max_label"), "giftMax", "number", C.gift.maxUGX)}
        ${f(t("referral_bonus_label"), "referralBonus", "number", C.referral.bonusUGX)}
        ${f(t("weekday_open") + " (HH:MM)", "monOpen", "text", toHHMM(hrs.mon_fri[0]))}
        ${f(t("weekday_close") + " (HH:MM)", "monClose", "text", toHHMM(hrs.mon_fri[1]))}
        ${f(t("sat_open") + " (HH:MM)", "satOpen", "text", toHHMM(hrs.sat[0]))}
        ${f(t("sat_close") + " (HH:MM)", "satClose", "text", toHHMM(hrs.sat[1]))}
      </div>
      <p id="settingsErr" class="error" role="alert"></p>
      <div class="actions"><button type="button" class="btn ghost" id="settingsReset">${esc(t("reset"))}</button>
        <button type="submit" class="btn big">${esc(t("save"))}</button></div></form>${backupCardHTML()}</section>`;
  }
  function contentForm() {
    const L = adminContentLang || lang;
    const cur = OVR[L] || {};
    return `<section class="card"><h2>${esc(t("content"))}</h2>
      <p class="muted">${esc(t("browser_only_note"))}</p>
      <form id="contentForm">
        <label>${esc(t("content_language"))}<select id="contentLang" class="input">${["en", "fr", "ar"].map(l => `<option value="${l}" ${l === L ? "selected" : ""}>${esc(I[l].lang_name)}</option>`).join("")}</select></label>
        ${CONTENT_KEYS.map(k => `<label>${esc(k)}<textarea name="${k}" class="input" rows="2">${esc(cur[k] || I[L][k] || I.en[k] || "")}</textarea></label>`).join("")}
        <div class="actions"><button type="button" class="btn ghost" id="contentReset">${esc(t("reset"))}</button>
          <button type="submit" class="btn big">${esc(t("save"))}</button></div>
      </form></section>`;
  }
  /* ---------- backup and restore (this browser\'s data) ---------- */
  const BACKUP_KEYS = ["ea_v1_db", "ea_settings", "ea_content", "ea_notice", "ea_admin_widgets"];
  function backupCardHTML() {
    const last = localStorage.getItem("ea_last_backup");
    return `<div class="card backup-card"><h3>${esc(t("backup_title"))}</h3>
      <p class="muted">${esc(t("backup_desc"))}</p>
      <p class="muted small-note">${esc(t("backup_last"))}: ${esc(last || t("backup_never"))}</p>
      <div class="row gap"><button type="button" class="btn big" id="backupNow">${esc(t("backup_now"))}</button></div>
      <hr>
      <label>${esc(t("backup_restore_label"))}<input type="file" id="restoreFile" accept="application/json,.json" class="input"></label>
      <p id="restoreErr" class="error" role="alert"></p>
      <button type="button" class="btn ghost" id="restoreNow">${esc(t("backup_restore_btn"))}</button></div>`;
  }
  function bindBackup() {
    const bk = $("#backupNow");
    if (bk) bk.onclick = () => {
      const items = {};
      BACKUP_KEYS.forEach(k => { const v = localStorage.getItem(k); if (v !== null) items[k] = v; });
      const file = { app: "NOMIDMAN TRANS", kind: "admin-backup", createdAt: new Date().toISOString(), items };
      const a = document.createElement("a");
      a.href = URL.createObjectURL(new Blob([JSON.stringify(file, null, 2)], { type: "application/json" }));
      const stamp = new Date().toISOString().slice(0, 16).replace(/[:T]/g, "-");
      a.download = `nomidman-backup-${stamp}.json`;
      document.body.appendChild(a); a.click(); a.remove();
      localStorage.setItem("ea_last_backup", new Date().toLocaleString());
      toast(t("backup_done")); route();
    };
    const rn = $("#restoreNow");
    if (rn) rn.onclick = async () => {
      const err = $("#restoreErr"); err.textContent = "";
      const f = $("#restoreFile").files[0];
      if (!f) return err.textContent = t("backup_restore_pick");
      let data;
      try { data = JSON.parse(await f.text()); } catch (e) { data = null; }
      if (!data || data.app !== "NOMIDMAN TRANS" || data.kind !== "admin-backup" || !data.items) return err.textContent = t("backup_restore_bad");
      if (!confirm(t("backup_restore_confirm"))) return;
      BACKUP_KEYS.forEach(k => { if (data.items[k] !== undefined) localStorage.setItem(k, data.items[k]); });
      localStorage.setItem("ea_last_restore", new Date().toLocaleString());
      location.reload();
    };
  }
  function bindAdminTools() {
    bindBackup();
    bindLegalForm();
    $$("[data-widget]").forEach(cb => cb.onchange = () => {
      const w = adminWidgets(); w[cb.dataset.widget] = cb.checked;
      localStorage.setItem(WIDGET_KEY, JSON.stringify(w)); route();
    });
    const sf = $("#settingsForm");
    if (sf) {
      sf.onsubmit = (e) => {
        e.preventDefault();
        const err = $("#settingsErr"); err.textContent = "";
        const fd = Object.fromEntries(new FormData(sf).entries());
        const nums = ["registrationFee", "boostPrice", "planBudget", "planEconomy", "planPremium", "giftMin", "giftMax", "referralBonus"].map(k => +fd[k]);
        if (nums.some(n => !isFinite(n) || n < 0)) return err.textContent = t("settings_invalid");
        const mon = [hhmm(fd.monOpen), hhmm(fd.monClose)], sat = [hhmm(fd.satOpen), hhmm(fd.satClose)];
        if ([...mon, ...sat].some(x => !isFinite(x))) return err.textContent = t("settings_time_invalid");
        const s = {
          office: { address: fd.address, poBox: fd.poBox, phone: fd.phone }, supportEmail: fd.supportEmail,
          registrationFee: +fd.registrationFee, boostPrice: +fd.boostPrice,
          plans: { budget: +fd.planBudget, economy: +fd.planEconomy, premium: +fd.planPremium },
          gift: { minUGX: +fd.giftMin, maxUGX: +fd.giftMax }, referral: { bonusUGX: +fd.referralBonus }, hours: { mon_fri: mon, sat: sat }
        };
        localStorage.setItem(SET_KEY, JSON.stringify(s)); applySettings(); toast(t("settings_saved")); route();
      };
      $("#settingsReset").onclick = () => { localStorage.removeItem(SET_KEY); location.reload(); };
    }
    const nf = $("#noticeForm");
    if (nf) {
      nf.onsubmit = (e) => {
        e.preventDefault();
        const fd = new FormData(nf);
        localStorage.setItem(NOTICE_KEY, JSON.stringify({ enabled: fd.get("enabled") === "on", en: String(fd.get("en") || "").trim(), fr: String(fd.get("fr") || "").trim(), ar: String(fd.get("ar") || "").trim() }));
        toast(t("notice_saved")); route();
      };
      $("#noticeOff").onclick = () => { localStorage.setItem(NOTICE_KEY, JSON.stringify({ enabled: false, en: "", fr: "", ar: "" })); toast(t("notice_saved")); route(); };
    }
    const cf = $("#contentForm");
    if (cf) {
      $("#contentLang").onchange = (e) => { adminContentLang = e.target.value; route(); };
      cf.onsubmit = (e) => {
        e.preventDefault();
        const L = adminContentLang || lang;
        const fd = Object.fromEntries(new FormData(cf).entries());
        const all = loadContent(); all[L] = {};
        CONTENT_KEYS.forEach(k => { const v = String(fd[k] || "").trim(); if (v && v !== (I[L][k] || "")) all[L][k] = v; });
        localStorage.setItem(CONTENT_KEY, JSON.stringify(all)); OVR = all; toast(t("content_saved")); route();
      };
      $("#contentReset").onclick = () => {
        const all = loadContent(); delete all[adminContentLang || lang];
        localStorage.setItem(CONTENT_KEY, JSON.stringify(all)); OVR = all; route();
      };
    }
  }

  /* ---------- NOTICE box (switched on and off from the admin Notice tab) ---------- */
  const NOTICE_KEY = "ea_notice";
  function noticeHTML() {
    const n = readJSON(NOTICE_KEY, null);
    if (!n || !n.enabled) return "";
    const text = n[lang] || n.en || "";
    if (!text) return "";
    return `<section class="notice" role="status"><b class="notice-label">${esc(t("notice_label"))}</b> <span>${esc(text)}</span></section>`;
  }
  function noticeForm() {
    const n = readJSON(NOTICE_KEY, { enabled: false, en: "", fr: "", ar: "" });
    return `<section class="card"><h2>${esc(t("notice"))}</h2>
      <p class="muted">${esc(t("browser_only_note"))}</p>
      <form id="noticeForm">
        <label class="chk"><input type="checkbox" name="enabled" ${n.enabled ? "checked" : ""}> ${esc(t("notice_enabled"))}</label>
        <label>English<textarea name="en" class="input" rows="2">${esc(n.en || "")}</textarea></label>
        <label>Français<textarea name="fr" class="input" rows="2">${esc(n.fr || "")}</textarea></label>
        <label>العربية<textarea name="ar" class="input" rows="2">${esc(n.ar || "")}</textarea></label>
        <div class="actions"><button type="button" class="btn ghost" id="noticeOff">${esc(t("notice_off"))}</button>
          <button type="submit" class="btn big">${esc(t("save"))}</button></div>
      </form></section>`;
  }

  /* ---------- owner referral: code, link and credit ---------- */
  let refFromUrl = null; // referral code from a #/register?ref=... link
  function referralCardHTML(raw) {
    if (!raw.refCode) return "";
    const link = (C.siteUrl || location.href.split("#")[0]) + "/#/register?ref=" + raw.refCode;
    const bal = DB.creditBalance(raw);
    const msg = encodeURIComponent(t("referral_share_msg").replace("{link}", link));
    const subj = encodeURIComponent(t("referral_share_subject"));
    return `<div class="card"><h3>${esc(t("referral_title"))}</h3>
      <p>${esc(t("referral_credit"))}: ${bal ? localAmountHTML(bal, countryCur(raw.nationality)) : `<b>${esc(t("referral_none"))}</b>`}</p>
      ${bal ? `<p class="muted small-note">${esc(t("referral_expires").replace("{date}", dateStr(DB.creditExpiryDate(raw))))}</p>` : ""}
      <p>${esc(t("referral_code"))}: <b>${esc(raw.refCode)}</b></p>
      <p class="muted small-note"><bdi dir="ltr">${esc(link)}</bdi></p>
      <div class="row gap">
        <a class="btn small" target="_blank" rel="noopener" href="https://wa.me/?text=${msg}">WhatsApp</a>
        <a class="btn small" href="sms:?body=${msg}">SMS</a>
        <a class="btn small" href="mailto:?subject=${subj}&body=${msg}">Email</a>
        <button class="btn small" data-copy-ref="${esc(link)}">${esc(t("referral_copy"))}</button>
      </div></div>`;
  }

  /* ---------- land area: length x breadth in one unit; area shown in m2 or km2 ---------- */
  function landArea() {
    const f = $("#landLen"); if (!f) return null;
    const L = +$("#landLen").value, B = +$("#landBreadth").value, unit = $("#landUnit").value;
    if (!(L > 0) || !(B > 0)) return null;
    return { value: Math.round(L * B * 100) / 100, unit: unit === "km" ? "km²" : "m²" };
  }
  function areaEquivalents(value, unit) {
    const m2 = unit === "km²" ? value * 1e6 : value;
    const f = (x) => (x >= 100 ? Math.round(x) : Math.round(x * 100) / 100).toLocaleString(numLoc());
    return `${f(m2 / 4046.8564224)} ${t("unit_acres")} · ${f(m2 / 10000)} ${t("unit_hectares")}`;
  }
  function landBlockHTML(land) {
    const typeLabel = land.type === "customary" ? t("land_customary") : t("land_non_customary");
    const unitLabel = land.unit === "km" ? "km" : "m";
    return `<div class="veh-box"><h3>${esc(t("land_details"))}</h3>
      <p><b>${esc(t("land_type"))}:</b> ${esc(typeLabel)}</p>
      <p><b>${esc(t("land_dimensions"))}:</b> ${esc(land.length)} ${unitLabel} × ${esc(land.breadth)} ${unitLabel}</p>
      <p><b>${esc(t("land_area"))}:</b> ${esc(Number(land.area).toLocaleString(numLoc()))} ${esc(land.areaUnit)} (${esc(areaEquivalents(Number(land.area), land.areaUnit))})</p>
      <p class="muted small-note">${esc(t("land_title_note"))}</p></div>`;
  }

  /* ---------- vehicle identifiers and sharing ---------- */
  function vehicleBlockHTML(v) {
    return `<div class="veh-box"><h3>${esc(t("vehicle_details"))}</h3>
      <p><b>${esc(t("engine_no"))}:</b> ${esc(v.engine || "—")}</p>
      <p><b>${esc(t("chassis_no"))}:</b> ${esc(v.chassis || "—")}</p>
      <p><b>${esc(t("plate_no"))}:</b> ${esc(v.plate || "—")}</p></div>`;
  }
  // Share works for everyone: no sign-in needed
  function openShare(l) {
    if (!l) return;
    const url = (C.siteUrl || location.href.split("#")[0]) + "/#/listing/" + l.id;
    const text = `${l.title} · ${fmt(l.price, l.currency)} · E-ASSET`;
    const enc = encodeURIComponent;
    const native = navigator.share ? `<button class="btn share-btn" id="nativeShare">⇪ ${esc(t("share_more"))}</button>` : "";
    const opt = (href, label, cls = "") => `<a class="btn share-btn ${cls}" target="_blank" rel="noopener" href="${href}">${label}</a>`;
    modal(`<h2>${esc(t("share_title"))}</h2>
      <p class="muted small-note"><bdi dir="ltr">${esc(url)}</bdi></p>
      <div class="share-grid">
        ${opt("sms:?body=" + enc(text + " " + url), "💬 " + esc(t("share_sms")))}
        ${opt("mailto:?subject=" + enc(l.title) + "&body=" + enc(text + "\n" + url), "✉ " + esc(t("share_email")))}
        ${opt("https://wa.me/?text=" + enc(text + " " + url), "WhatsApp", "wa")}
        ${opt("https://www.facebook.com/sharer/sharer.php?u=" + enc(url), "Facebook")}
        ${opt("https://twitter.com/intent/tweet?text=" + enc(text) + "&url=" + enc(url), "X")}
        ${opt("fb-messenger://share/?link=" + enc(url), "Messenger")}
        <button class="btn share-btn" data-copy-share="${esc(url)}" data-open="https://www.tiktok.com/">TikTok</button>
        <button class="btn share-btn" data-copy-share="${esc(url)}" data-open="https://www.instagram.com/">Instagram</button>
        <button class="btn share-btn ghost" data-copy-share="${esc(url)}">${esc(t("share_copy"))}</button>
        ${native}
      </div>
      <p class="muted small-note">${esc(t("share_app_note"))}</p>
      <div class="actions"><button class="btn ghost" data-close>${esc(t("close"))}</button></div>`);
    $$("[data-copy-share]").forEach(b => b.onclick = async () => {
      try { await navigator.clipboard.writeText(b.dataset.copyShare); toast(t("copied")); } catch (e) { toast(b.dataset.copyShare); }
      if (b.dataset.open) window.open(b.dataset.open, "_blank", "noopener");
    });
    const ns = $("#nativeShare");
    if (ns) ns.onclick = () => navigator.share({ title: l.title, text, url }).catch(() => {});
  }

  /* ---------- legal details, re-acceptance, and account closure ---------- */
  const LEGAL_KEY = "ea_legal";
  function applyLegal() { const saved = readJSON(LEGAL_KEY, null); if (saved) Object.assign(C.legal, saved); }
  // Fills the admin-set details into the legal pages; unset fields stay highlighted
  function legalText(html) {
    const L = C.legal;
    const v = (x) => (x ? esc(x) : `<mark class="todo">[${esc(t("legal_to_confirm"))}]</mark>`);
    return html.replace(/\{\{LAST_UPDATED\}\}/g, v(L.lastUpdated)).replace(/\{\{DPO\}\}/g, v(L.dpo))
      .replace(/\{\{SERVER\}\}/g, v(L.serverLocation)).replace(/\{\{PAYMENT_YEARS\}\}/g, v(L.paymentYears))
      .replace(/\{\{REFUND_YEARS\}\}/g, v(L.refundYears));
  }
  function legalForm() {
    const L = C.legal;
    const f = (label, name, val) => `<label>${esc(label)}<input name="${name}" class="input" value="${esc(val || "")}"></label>`;
    const log = (L.log || []).slice().reverse().map(x => `<li>${esc(x.date)} · ${esc(x.summary)}${x.material ? " · " + esc(t("legal_material_tag")) : ""}</li>`).join("") || `<li class="muted">${esc(t("legal_no_changes"))}</li>`;
    return `<section class="card"><h2>${esc(t("legal"))}</h2>
      <p class="muted">${esc(t("browser_only_note"))}</p>
      <p><b>${esc(t("legal_last_updated"))}:</b> ${esc(L.lastUpdated)} · <b>${esc(t("legal_version"))}:</b> ${L.version}</p>
      <form id="legalForm">
        ${f(t("legal_dpo"), "dpo", L.dpo)}
        ${f(t("legal_server"), "serverLocation", L.serverLocation)}
        ${f(t("legal_payment_years"), "paymentYears", L.paymentYears)}
        ${f(t("legal_refund_years"), "refundYears", L.refundYears)}
        <label class="chk"><input type="checkbox" name="material"> ${esc(t("legal_material"))}</label>
        <p id="legalErr" class="error" role="alert"></p>
        <div class="actions"><button type="submit" class="btn big">${esc(t("save"))}</button></div>
      </form>
      <h3>${esc(t("legal_changes"))}</h3><ul>${log}</ul></section>`;
  }
  function bindLegalForm() {
    const f = $("#legalForm"); if (!f) return;
    f.onsubmit = (e) => {
      e.preventDefault();
      const fd = new FormData(f);
      const keys = ["dpo", "serverLocation", "paymentYears", "refundYears"];
      const vals = Object.fromEntries(keys.map(k => [k, String(fd.get(k) || "").trim()]));
      const err = $("#legalErr"); err.textContent = "";
      if (keys.some(k => !vals[k])) return err.textContent = t("legal_all_required");
      if (keys.every(k => vals[k] === C.legal[k])) return err.textContent = t("legal_no_change");
      const material = fd.get("material") === "on";
      const today = new Date().toISOString().slice(0, 10);
      const next = { ...vals, lastUpdated: today, version: C.legal.version + (material ? 1 : 0),
        log: (C.legal.log || []).concat([{ date: today, summary: t("legal_log_summary"), material }]) };
      localStorage.setItem(LEGAL_KEY, JSON.stringify(next)); applyLegal();
      toast(t("legal_saved")); route();
    };
  }
  // Non-dismissable prompt for a closed account (restore) or for revised terms (accept)
  function gateModal(html) { modal(html); $("#modal").onclick = null; }
  function accountGate() {
    const u = DB.currentUserRaw();
    if (!u || u.role === "admin") return false;
    if (u.closedAt) {
      gateModal(`<h2>${esc(t("restore_title"))}</h2><p>${esc(t("restore_text"))}</p>
        <div class="actions"><button class="btn ghost" id="keepClosed">${esc(t("keep_closed"))}</button><button class="btn big" id="restoreAcct">${esc(t("restore_btn"))}</button></div>`);
      $("#restoreAcct").onclick = () => { DB.restoreAccount(); closeModal(); toast(t("restore_done")); route(); };
      $("#keepClosed").onclick = () => { DB.logout(); closeModal(); route(); };
      return true;
    }
    if ((u.acceptedLegal ?? 1) < C.legal.version) {
      gateModal(`<h2>${esc(t("legal_update_title"))}</h2><p>${esc(t("legal_update_text"))}</p>
        <label class="chk"><input type="checkbox" id="acceptLegal"> ${esc(t("agree_prefix"))} <a href="#/terms">${esc(t("nav_terms"))}</a> · <a href="#/privacy">${esc(t("nav_privacy"))}</a></label>
        <p id="gateErr" class="error" role="alert"></p>
        <div class="actions"><button class="btn big" id="doAccept">${esc(t("accept_btn"))}</button></div>`);
      $("#doAccept").onclick = () => {
        if (!$("#acceptLegal").checked) return ($("#gateErr").textContent = t("agree_required"));
        DB.acceptLegal(C.legal.version); closeModal(); route();
      };
      return true;
    }
    return false;
  }
  function closeAccountCardHTML() {
    const u = DB.currentUserRaw(); if (!u || u.role === "admin") return "";
    return `<div class="card close-card"><h3 class="delete-title">${esc(t("close_title"))}</h3>
      <p class="muted">${esc(t("close_desc"))}</p>
      <button class="btn danger" id="closeAcct">${esc(t("close_btn"))}</button></div>`;
  }
  function confirmCloseAccount() {
    modal(`<h2>${esc(t("close_title"))}</h2><p>${esc(t("close_warning"))}</p>
      <div class="actions"><button class="btn ghost" data-close>${esc(t("cancel"))}</button><button class="btn danger" id="doClose">${esc(t("close_confirm"))}</button></div>`);
    $("#doClose").onclick = () => { DB.closeAccount(); DB.logout(); closeModal(); toast(t("close_done")); go("#/"); };
  }

  /* ---------- headline: letters fly in from random directions, then drift ---------- */
  function heroLetters(text) {
    // each word gets its own colour; letters of the same word share it
    const palette = ["#e53935", "#fb8c00", "#43a047", "#1e88e5", "#8e24aa", "#00acc1"];
    let i = 0, w = 0;
    return [...String(text)].map(ch => {
      if (ch === " ") { w++; return " "; }
      const color = palette[w % palette.length];
      const r = () => Math.round((Math.random() * 2 - 1) * 120);
      const style = `--c:${color};--dx:${r()}px;--dy:${r()}px;--r:${Math.round((Math.random() * 2 - 1) * 240)}deg;--d:${(i++ * 0.04).toFixed(2)}s;--t:${(3 + Math.random() * 3).toFixed(2)}s`;
      return `<span class="fly" style="${style}">${esc(ch)}</span>`;
    }).join("");
  }

  /* ---------- owner storefront: one shareable page of an owner's live listings ---------- */
  const shopLink = (code) => (C.siteUrl || location.href.split("#")[0]) + "/#/shop/" + code;
  function shopLinkHTML(l) {
    const o = DB.allUsers().find(u => u.id === l.ownerId);
    if (!o || !o.refCode) return "";
    return `<p><a href="#/shop/${esc(o.refCode)}">${esc(t("shop_view"))}</a></p>`;
  }
  function viewShop(code) {
    const o = DB.allUsers().find(u => u.refCode === code && u.role === "owner");
    if (!o) return `<section class="card"><h2>${esc(t("no_results"))}</h2><a class="btn" href="#/listings">${esc(t("back"))}</a></section>`;
    const name = o.name || `${o.firstName} ${o.lastName}`;
    const list = DB.publicListings().filter(l => l.ownerId === o.id);
    const msg = encodeURIComponent(`${t("shop_share_msg")}: ${name} ${shopLink(code)}`);
    return `<section class="card shop-head"><h2>${esc(t("shop_title"))}: ${esc(name)}</h2>
      <p class="muted">${esc(t("shop_intro"))}</p>
      <div class="row gap">
        <button class="btn small" data-copy-shop="${esc(shopLink(code))}">${esc(t("referral_copy"))}</button>
        <a class="btn small" target="_blank" rel="noopener" href="https://wa.me/?text=${msg}">WhatsApp</a>
      </div></section>
      <div class="grid">${list.length ? list.map(card).join("") : `<p class="muted empty">${esc(t("no_results"))}</p>`}</div>`;
  }

  /* ---------- router ---------- */
  function route() {
    DB.purgeExpired();
    if (accountGate()) return;
    const raw = location.hash.replace(/^#\/?/, "");
    const [pathPart, qs] = raw.split("?");
    const query = new URLSearchParams(qs || "");
    const parts = pathPart.split("/").filter(Boolean);
    const [a, b] = parts;
    if (a === "register" && query.get("ref")) refFromUrl = query.get("ref");
    const u = DB.currentUserRaw();
    let html = "", after = null;

    const needLogin = ["dashboard", "new", "edit"];
    if (needLogin.includes(a) && !u) { toast(t("not_signed_in")); location.hash = "#/login"; return; }

    if (!a) { html = viewHome(); after = bindHome; }
    else if (a === "listings") { html = viewListings(query); after = bindListings; }
    else if (a === "listing") { html = viewListingDetail(b); after = () => { bindListingDetail(b); bindGallery(DB.getListing(b)); }; }
    else if (a === "login") { html = viewLogin(); after = bindLogin; }
    else if (a === "register") { html = viewRegister(); after = bindRegister; }
    else if (a === "forgot") { html = viewForgot(); after = bindForgot; }
    else if (a === "dashboard") { html = viewDashboard(); after = bindDashboard; }
    else if (a === "new") { html = viewListingForm(null); after = () => bindListingForm(null); }
    else if (a === "edit") { html = viewListingForm(b); after = () => bindListingForm(b); }
    else if (a === "zero") { html = viewAdmin(); after = bindAdmin; }
    else if (a === "about") { html = viewAbout(); }
    else if (a === "app") { html = viewGetApp(); }
    else if (a === "shop") { html = viewShop(b); }
    else if (["privacy", "terms", "disclaimer"].includes(a)) { html = viewLegal(a); }
    else { html = viewHome(); after = bindHome; }

    const root = $("#app");
    root.innerHTML = header() + demoBar() + `<main class="wrap" id="main">${html}</main>` + footer();
    bindHeader();
    if (after) after();
    window.scrollTo(0, 0);
  }

  function bindHeader() {
    $$("[data-lang]").forEach(b => b.onclick = () => {
      lang = b.dataset.lang; localStorage.setItem("ea_lang", lang); applyLang(); route();
    });
    $("#themeBtn").onclick = () => {
      theme = theme === "dark" ? "light" : "dark";
      localStorage.setItem("ea_theme", theme); applyTheme(); route();
    };
    const lo = $("#logoutBtn");
    if (lo) lo.onclick = () => { DB.logout(); toast(t("signed_out")); go("#/"); };
    $("#burger").onclick = () => $("#mainnav").classList.toggle("open");
    const gb = $("#giftBtn"); if (gb) gb.onclick = openGift;
  }

  /* ---------- exchange rates (from data/rates.json, updated daily on the server) ---------- */
  let RATES_META = null; // { asOf, attribution } when live rates are loaded
  async function loadRates() {
    try {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 4000);
      const res = await fetch("data/rates.json", { cache: "no-store", signal: ctrl.signal });
      clearTimeout(timer);
      if (!res.ok) return;
      const d = await res.json();
      let applied = 0;
      Object.keys(C.currencies).forEach(cur => {
        const v = d.rates && d.rates[cur];
        if (typeof v === "number" && v > 0 && isFinite(v)) { C.currencies[cur].perUGX = v; applied++; }
      });
      if (applied && d.asOf) RATES_META = { asOf: d.asOf, attribution: d.attribution || "" };
    } catch (e) { /* keep built-in fallback rates */ }
  }
  function ratesNote() {
    if (!RATES_META) return esc(t("rates_fallback"));
    const ageDays = (Date.now() - new Date(RATES_META.asOf).getTime()) / DAY;
    const stale = ageDays > 3 ? ` ${t("rates_stale")}` : "";
    const credit = RATES_META.attribution ? ` · ${RATES_META.attribution}` : "";
    return `${esc(t("rates_as_of"))} ${esc(dateStr(RATES_META.asOf))}${esc(credit)}${stale ? `<span class="error">${esc(stale)}</span>` : ""}`;
  }

  /* ---------- boot ---------- */
  async function boot() {
    applyTheme(); applyLang();
    if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
      navigator.serviceWorker.register("sw.js").catch(() => {});
    }
    await DB.seed();
    OVR = loadContent();
    applySettings();
    applyLegal();
    await loadRates();
    window.addEventListener("hashchange", () => { $("#mainnav") && $("#mainnav").classList.remove("open"); route(); });
    route();
    setInterval(() => { DB.purgeExpired(); }, 60000);
  }
  document.addEventListener("DOMContentLoaded", boot);
})();
