#!/usr/bin/env python3
"""Idempotent patches for the generated android/ project: App Links (open dagbadigitalacademy.com URLs in the app), notification permission and release signing.
Each patch is skipped if already applied and aborts loudly if the generated file does not look as expected (Capacitor templates can change between versions).
UNTESTED against a freshly generated project (no network here): review `git diff android/` after running it."""
import os, re, sys
ROOT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "android")
MAN = os.path.join(ROOT, "app/src/main/AndroidManifest.xml"); GRADLE = os.path.join(ROOT, "app/build.gradle")
HOST = os.environ.get("DAGBA_HOST", "dagbadigitalacademy.com")
def rd(p):
    if not os.path.exists(p): sys.exit(f"{p} not found: run `npx cap add android` first")
    return open(p, encoding="utf8").read()
def manifest():
    s = rd(MAN)
    if "dagba-applinks" not in s:
        link = f'''
            <!-- dagba-applinks: https://{HOST}/courses/..., /blog/..., /learn/... open inside the app (verified through /.well-known/assetlinks.json) -->
            <intent-filter android:autoVerify="true">
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="https" android:host="{HOST}" android:pathPrefix="/courses" />
                <data android:scheme="https" android:host="{HOST}" android:pathPrefix="/blog" />
                <data android:scheme="https" android:host="{HOST}" android:pathPrefix="/learn" />
                <data android:scheme="https" android:host="{HOST}" android:pathPrefix="/faith" />
                <data android:scheme="https" android:host="{HOST}" android:pathPrefix="/paths" />
            </intent-filter>
'''
        m = re.search(r"(<activity[^>]*MainActivity[^>]*>.*?)(</activity>)", s, re.S)
        if not m: sys.exit("MainActivity not found in AndroidManifest.xml")
        s = s[:m.end(1)] + link + s[m.start(2):]
    for perm in ("android.permission.INTERNET", "android.permission.POST_NOTIFICATIONS", "android.permission.ACCESS_NETWORK_STATE"):
        if perm not in s: s = s.replace("</manifest>", f'    <uses-permission android:name="{perm}" />\n</manifest>')
    open(MAN, "w", encoding="utf8").write(s); print("AndroidManifest.xml patched")
def gradle():
    s = rd(GRADLE)
    if "keystore.properties" in s: print("build.gradle already patched"); return
    head = '''def keystoreProperties = new Properties()
def keystorePropertiesFile = rootProject.file("keystore.properties")   // NEVER commit this file or the .jks
if (keystorePropertiesFile.exists()) { keystoreProperties.load(new FileInputStream(keystorePropertiesFile)) }

'''
    s = head + s
    sign = '''    signingConfigs {
        release {
            if (keystorePropertiesFile.exists()) {
                storeFile file(keystoreProperties["storeFile"]); storePassword keystoreProperties["storePassword"]
                keyAlias keystoreProperties["keyAlias"]; keyPassword keystoreProperties["keyPassword"]
            }
        }
    }
'''
    if "android {" not in s: sys.exit("android { block not found in app/build.gradle")
    s = s.replace("android {", "android {\n" + sign, 1)
    if "buildTypes {" in s and "signingConfig signingConfigs.release" not in s:
        s = re.sub(r"(buildTypes\s*\{\s*release\s*\{)", r"\1\n            signingConfig signingConfigs.release", s, 1)
    open(GRADLE, "w", encoding="utf8").write(s); print("app/build.gradle patched for release signing")
manifest(); gradle()
