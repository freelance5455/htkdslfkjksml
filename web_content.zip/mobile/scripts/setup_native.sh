#!/usr/bin/env bash
# Generates the Android and iOS projects from this folder. Needs: Node 20+, internet, and (Android) JDK 17 + Android Studio, (iOS) a Mac with Xcode + CocoaPods.
# Run from the mobile/ folder on a PC or Mac (Termux cannot build Android/iOS apps).  Usage: bash scripts/setup_native.sh [android|ios|both]
set -euo pipefail
cd "$(dirname "$0")/.."; WHAT="${1:-both}"
node -e "process.exit(+process.versions.node.split('.')[0] >= 20 ? 0 : 1)" || { echo "Node 20+ required"; exit 1; }
npm install
npm run check
npx capacitor-assets generate --iconBackgroundColor '#7236E6' --splashBackgroundColor '#7236E6' --iconBackgroundColorDark '#16121f' --splashBackgroundColorDark '#16121f' || echo "asset generation needs ./resources/*.png (present)"
if [ "$WHAT" = android ] || [ "$WHAT" = both ]; then [ -d android ] || npx cap add android; python3 scripts/patch_android.py; fi
if [ "$WHAT" = ios ] || [ "$WHAT" = both ]; then
  if [ "$(uname)" = Darwin ]; then [ -d ios ] || npx cap add ios; else echo "Skipping iOS: needs macOS (use the GitHub Actions macOS job in ci/ios.yml)."; fi
fi
npx cap sync
echo "Done. Next: docs/ANDROID_BUILD.md and docs/IOS_BUILD.md"
