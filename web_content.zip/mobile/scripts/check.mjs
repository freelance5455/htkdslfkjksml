// Static safety/quality gate for the web layer. Run before every build or live update:  npm run check
import { readdirSync, readFileSync, writeFileSync, mkdtempSync } from "node:fs"; import { join } from "node:path"; import { execFileSync } from "node:child_process"; import { tmpdir } from "node:os";
const www = new URL("../www/", import.meta.url).pathname; let bad = 0; const fail = (m) => { console.error("FAIL " + m); bad++; };
const files = readdirSync(join(www, "js")).filter(f => f.endsWith(".js")); const tmp = mkdtempSync(join(tmpdir(), "chk-"));
for (const f of files) { const src = readFileSync(join(www, "js", f), "utf8"); const t = join(tmp, f.replace(/\.js$/, ".mjs")); writeFileSync(t, src);
  try { execFileSync(process.execPath, ["--check", t], { stdio: "pipe" }); } catch (e) { fail(`syntax error in js/${f}\n${e.stderr}`); }
  if (f !== "util.js" && /\.innerHTML\s*=|insertAdjacentHTML|document\.write|\beval\(|new Function\(/.test(src)) fail(`js/${f}: unsafe HTML/code injection API (use h()/textContent)`);
  if (/(secret|sk_live|sk_test|private_key|BEGIN [A-Z ]*PRIVATE|api[_-]?key\s*[:=])/i.test(src)) fail(`js/${f}: looks like a secret. Secrets must never ship in the app`);
  if (/localStorage\.setItem\(["'`](access|refresh|token)/i.test(src)) fail(`js/${f}: tokens must go in the secure vault, not localStorage`);
  if (/bank[ _-]?(transfer|account)|account[_ ]number/i.test(src)) fail(`js/${f}: bank-transfer purchase UI is not allowed inside the store apps`);
  if (/\b(JSS|SS[123])\b/.test(src)) fail(`js/${f}: legacy JSS/SS class levels must not appear`); }
const html = readFileSync(join(www, "index.html"), "utf8");
if (!/Content-Security-Policy/.test(html) || /unsafe-eval/.test(html)) fail("index.html: CSP missing or allows unsafe-eval");
if (/<script(?![^>]*\bsrc=)[^>]*>/.test(html)) fail("index.html: inline <script> is blocked by the CSP");
console.log(bad ? `${bad} problem(s)` : `OK: ${files.length} scripts checked`); process.exit(bad ? 1 : 0);
