#!/usr/bin/env bash
# Creates the Android UPLOAD key (once). KEEP THE .jks AND ITS PASSWORDS IN A PASSWORD MANAGER + AN OFFLINE BACKUP: with Play App Signing, losing it is recoverable
# only through a Google support reset, so back it up anyway. Never commit it. Usage: bash scripts/gen_android_keystore.sh
set -euo pipefail
cd "$(dirname "$0")/.."; mkdir -p android; K=android/dagba-upload.jks
[ -f "$K" ] && { echo "$K already exists: not overwriting."; exit 1; }
keytool -genkeypair -v -keystore "$K" -alias dagba-upload -keyalg RSA -keysize 4096 -validity 10000
read -r -s -p "Re-enter the keystore password to write keystore.properties: " P; echo
read -r -s -p "Key password (same as store password if you pressed Enter at keytool): " KP; echo; KP="${KP:-$P}"
printf 'storeFile=dagba-upload.jks\nstorePassword=%s\nkeyAlias=dagba-upload\nkeyPassword=%s\n' "$P" "$KP" > android/keystore.properties; chmod 600 android/keystore.properties
echo "android/keystore.properties written (git-ignored). SHA-256 fingerprint for assetlinks.json is shown by:  keytool -list -v -keystore $K -alias dagba-upload"
