// End-to-end: the REAL app modules (api client, screens) against a REAL backend started with scripts/dev_seeded_server.py.
// Run:  python3 ../scripts/dev_seeded_server.py 5055 &  then  DAGBA_E2E=http://127.0.0.1:5055 node --test tests/
import test from "node:test"; import assert from "node:assert/strict";
const BASE = process.env.DAGBA_E2E; const skip = !BASE && "set DAGBA_E2E to the dev server URL";
let A, B, C, API, UI;
test("setup", { skip }, async () => {
  globalThis.__DAGBA_API_BASE__ = BASE; const { installDom } = await import("./support/dom_shim.mjs"); installDom();
  API = await import("../www/js/api.js"); A = await import("../www/js/screens_a.js"); B = await import("../www/js/screens_b.js"); C = await import("../www/js/screens_c.js");
});
const text = (el) => el.textContent;
test("guest can browse home and explore", { skip }, async () => {
  const home = await A.home(); assert.match(text(home), /Welcome to Dagba/); assert.match(text(home), /Paid Maths/); assert.doesNotMatch(text(home), /Draft/);
  const ex = await A.explore({}, new URLSearchParams()); await new Promise(r => setTimeout(r, 500)); assert.match(text(ex), /Explore/); assert.match(text(ex), /Advanced/);
});
test("guest course detail shows curriculum locked and sign-in CTA", { skip }, async () => {
  const el = await A.course({ slug: "paid-maths" }); assert.match(text(el), /Paid Maths/); assert.match(text(el), /By /); assert.doesNotMatch(text(el), /body/);
});
test("login, token refresh and sync", { skip }, async () => {
  await assert.rejects(() => API.login("alice@t.test", "wrong", {}), /Incorrect email or password/);
  const u = await API.login("alice@t.test", "Passw0rdTest1", { platform: "android" }); assert.equal(u.email, "alice@t.test");
  API.session.access = "expired.token";                                    // simulate an expired access token: client must refresh transparently
  const me = await API.api("/me"); assert.equal(me.user.email, "alice@t.test"); assert.notEqual(API.session.access, "expired.token");
});
test("signed-in screens render with real data", { skip }, async () => {
  const home = await A.home(); assert.match(text(home), /Alice|alice/i); 
  const lr = await B.learning(); assert.match(text(lr), /My Learning/); assert.match(text(lr), /Paid Maths/);
  const ln = await B.learn({ slug: "paid-maths" }); assert.match(text(ln), /Start learning|Resume learning/); assert.match(text(ln), /L1/);
  const first = (await API.api("/learn/paid-maths")).curriculum[0].lessons[0].id;
  const ls = await B.lesson({ id: String(first) }); assert.match(text(ls), /L1/); assert.match(text(ls), /Complete & continue/);
  const act = await C.activity({}, new URLSearchParams()); assert.match(text(act), /Activity/);
  const pr = await C.profile(); assert.match(text(pr), /Alice/i); assert.match(text(pr), /Delete account/);
  const pl = await C.plans(); assert.match(text(pl), /Acad Sub/); assert.match(text(pl), /do not unlock Income Skills/);
  const pay = await C.payments(); assert.match(text(pay), /Purchases/);
  const cert = await B.certificates(); assert.match(text(cert), /No certificates yet/);
});
test("locked content gives a clear error, not a crash", { skip }, async () => {
  const lessonId = (await API.api("/courses/marketing")).course.curriculum[0].lessons[0].id;
  await assert.rejects(() => API.api("/lessons/" + lessonId), (e) => e.status === 403 && /paid course|access/i.test(e.message));
});
test("offline fallback serves the last cached copy", { skip }, async () => {
  await API.api("/courses"); const realFetch = globalThis.fetch; globalThis.fetch = async () => { throw new TypeError("network down"); };
  try { const d = await API.api("/courses"); assert.ok(d.courses.length); assert.equal(API.net.stale, true); await assert.rejects(() => API.api("/categories?x=1"), (e) => e.code === "offline"); } finally { globalThis.fetch = realFetch; }
});
test("logout revokes the session on the server", { skip }, async () => {
  const tok = API.session.access; await API.logout(); const r = await fetch(BASE + "/api/v1/me", { headers: { Authorization: "Bearer " + tok } }); assert.equal(r.status, 401);
});
