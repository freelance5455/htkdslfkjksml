// Minimal DOM used ONLY by tests to execute the screens without a browser. It implements just what the app uses.
class ClassList { constructor(n) { this.n = n; } toggle(c, on) { const s = new Set((this.n.className || "").split(/\s+/).filter(Boolean)); (on ?? !s.has(c)) ? s.add(c) : s.delete(c); this.n.className = [...s].join(" "); } }
export class Node_ {
  constructor(tag) { this.tag = tag; this.attrs = {}; this.children = []; this.style = {}; this.className = ""; this.listeners = {}; this.dataset = {}; this.hidden = false; this._text = null; this.classList = new ClassList(this); this.value = ""; this.files = []; }
  setAttribute(k, v) { this.attrs[k] = String(v); if (k === "class") this.className = v; if (k === "value") this.value = v; } getAttribute(k) { return this.attrs[k] ?? null; }
  append(...k) { for (const x of k) this.children.push(typeof x === "string" ? new Text_(x) : x); } appendChild(x) { this.append(x); return x; } replaceChildren(...k) { this.children = []; this.append(...k); }
  addEventListener(t, f) { (this.listeners[t] ||= []).push(f); } fire(t, ev = {}) { (this.listeners[t] || []).forEach(f => f({ target: this, preventDefault() {}, ...ev })); }
  set innerHTML(s) { this._html = s; this.children = []; } get innerHTML() { return this._html || ""; }
  set textContent(s) { this.children = []; this._text = String(s); } get textContent() { return (this._text ?? "") + this.children.map(c => c.textContent).join(""); }
  *walk() { yield this; for (const c of this.children) if (c.walk) yield* c.walk(); }
  matches(sel) { return sel.split(",").some(s => { s = s.trim(); const m = s.match(/^([a-z0-9]*)((?:\.[\w-]+)*)(\[[\w-]+\])?$/i); if (!m) return false; const [, t, cl, at] = m; if (t && t !== this.tag) return false; for (const c of cl.split(".").filter(Boolean)) if (!(" " + this.className + " ").includes(" " + c + " ")) return false; if (at && !(at.slice(1, -1) in this.attrs)) return false; return true; }); }
  querySelectorAll(sel) { return [...this.walk()].filter(n => n !== this && n.matches && n.matches(sel)); } querySelector(sel) { return this.querySelectorAll(sel)[0] || null; }
  closest() { return null; } remove() {} focus() {} contains() { return true; } get disabled() { return !!this._d; } set disabled(v) { this._d = v; }
  click() { this.fire("click"); } texts() { return this.textContent; }
}
class Text_ { constructor(t) { this.t = t; } get textContent() { return this.t; } }
export function installDom() {
  const byId = {}; const store = {};
  globalThis.document = { createElement: t => new Node_(t), createTextNode: t => new Text_(t), createElementNS: (_, t) => new Node_(t), getElementById: id => (byId[id] ||= new Node_("div")), querySelector: s => (s === "#tabs" ? byId.tabs ||= new Node_("nav") : null), contains: () => true, addEventListener() {}, visibilityState: "visible" };
  globalThis.Node = class { static [Symbol.hasInstance](v) { return v instanceof Node_ || v instanceof Text_; } };
  globalThis.window = { scrollTo() {}, Capacitor: undefined, addEventListener() {} }; globalThis.location = { hash: "", href: "" }; globalThis.history = { back() {}, length: 1, replaceState() {} };
  globalThis.localStorage = { getItem: k => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); }, removeItem: k => { delete store[k]; }, get length() { return Object.keys(store).length; }, key: i => Object.keys(store)[i] };
  Object.defineProperty(globalThis.localStorage, "__keys", { get: () => Object.keys(store) });
  globalThis.HashChangeEvent = class {}; globalThis.confirm = () => true; Object.defineProperty(globalThis, "navigator", { value: { userAgent: "Test (Android 14)" }, configurable: true });
  const orig = Object.keys; Object.keys = (o) => (o === globalThis.localStorage ? globalThis.localStorage.__keys : orig(o));
  return byId;
}
