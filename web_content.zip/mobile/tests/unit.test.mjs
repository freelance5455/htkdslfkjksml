import test from "node:test"; import assert from "node:assert/strict";
import { routeForUrl, compareVersions, naira, mins, initials } from "../www/js/util.js";
const S = "https://dagbadigitalacademy.com";
test("deep links map to in-app routes", () => {
  assert.equal(routeForUrl(S + "/courses/web-design", S), "/course/web-design"); assert.equal(routeForUrl(S + "/blog/hello-1/", S), "/article/hello-1");
  assert.equal(routeForUrl(S + "/faith/lesson/grace", S), "/faith-item/grace"); assert.equal(routeForUrl(S + "/paths/p1", S), "/path/p1"); assert.equal(routeForUrl(S + "/notifications", S), "/activity");
  assert.equal(routeForUrl("https://evil.example/courses/x", S), null); assert.equal(routeForUrl("javascript:alert(1)", S), null); assert.equal(routeForUrl(S + "/admin", S), null);
});
test("version compare", () => { assert.equal(compareVersions("1.0.0", "1.0.1"), -1); assert.equal(compareVersions("1.2.0", "1.10.0"), -1); assert.equal(compareVersions("2.0.0", "1.9.9"), 1); assert.equal(compareVersions("1.0.0", "1.0.0"), 0); assert.equal(compareVersions("1.0.0", ""), 1); });
test("formatters", () => { assert.equal(naira(500000), "₦5,000"); assert.equal(naira(150050), "₦1,500.50"); assert.equal(mins(95), "1h 35m"); assert.equal(mins(30), "30 min"); assert.equal(initials("ada obi lawal"), "AO"); });
