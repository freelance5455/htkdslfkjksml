# TO‘LOVCHI Android app

This Expo SDK 58 app is an additive workspace in the existing TO‘LOVCHI repository. The web Super Admin Dashboard remains in the repository root and continues to use its existing React/Vite/Express stack.

The customer app is designed to keep financial records in an SQLCipher-encrypted on-device database. The admin server does not receive customer transactions, debts, bill contents or zakat inputs. Use the custom native development build; Expo Go does not include SQLCipher.

## Current identifiers and external setup

`uz.tolovchi.app` is a pre-release Android/iOS identifier placeholder, not an approved or reserved Play Store ID. The owner must choose an unused, permanently owned Android package ID before creating the first Play listing. Copy `.env.example` to a local, untracked `.env` only if configuring public build IDs; never put service-account JSON, signing secrets or private keys in `EXPO_PUBLIC_*` values.

The repository includes EAS internal APK and production AAB profiles, but no Expo/EAS or Play Console account is connected and no signed APK/AAB has been produced. App Store products, Play Billing, AdMob production IDs and cloud backup are intentionally disabled until owner-controlled accounts and trusted service configuration exist.

## Local commands

From the repository root: `pnpm install`, `pnpm mobile:check`, `pnpm mobile:test`, `pnpm mobile:doctor`, and `pnpm mobile:start`. Starting on an Android device requires a compatible custom development build because SQLCipher is not included in Expo Go. See `../docs/BUILD-ANDROID-PHONE.md` for the phone-friendly owner build flow.
