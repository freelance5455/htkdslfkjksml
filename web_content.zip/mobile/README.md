# Dagba Digital Academy: mobile app (Capacitor)

`www/` is the whole app (vanilla JS ES modules, no build step). It holds **no content**: every course, price, banner and article is fetched from `https://dagbadigitalacademy.com/api/v1` (see `../docs/02_API_REFERENCE.md`). Capacitor wraps it as the Android and iOS apps.

```
www/index.html          shell + Content-Security-Policy + 5-tab bottom navigation (Home, Explore, My Learning, Activity, Profile)
www/js/config.js        API_BASE (the only deployment setting), APP_VERSION
www/js/api.js           token vault (Keychain/Keystore), auto-refresh, ETag + offline cache
www/js/native.js        network detection, Android back button, deep links, share, push, live-update check
www/js/iap.js           Google Play Billing / Apple IAP bridge (server verifies every purchase)
www/js/screens_*.js     all screens; app.js is the router
resources/              icon + splash sources (run `npm run assets`)
scripts/                check.mjs (safety gate), setup_native.sh, patch_android.py, gen_android_keystore.sh
ci/                     GitHub Actions templates (untested)
tests/                  unit tests + end-to-end tests against a real backend
```
## Everyday commands
```
npm install
npm run check && npm test                     # unit tests; add DAGBA_E2E=http://127.0.0.1:5055 for end-to-end (start the dev server first, below)
python3 ../backend/scripts/dev_seeded_server.py 5055    # DEV ONLY throw-away data; demo login alice@t.test / Passw0rdTest1
bash scripts/setup_native.sh both             # create android/ and ios/ (PC/Mac; iOS needs macOS)
```
The UI is tested headlessly (`tests/e2e.test.mjs` renders every screen against the real backend using a minimal DOM). It has **not** been looked at on a real phone or emulator in this build environment, so expect to adjust visual details after your first device run.
See `../docs` for build, release, billing and update procedures.
