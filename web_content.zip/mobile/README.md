# NOMIDMAN TRANS: Android and iOS apps

This folder turns the website into store apps. The app shows the same site, so one codebase serves the website, Android and iOS.

## Contents
- `www/`: the website (Flutterwave edition). After any website change, rebuild the source (`node scripts/build-editions.mjs`) and copy `dist/NOMIDMAN-TRANS-CO-LTD-Flutterwave/` into `www/`.
- `capacitor.config.json`: app name, identifier (`com.nomidmantrans.app`) and settings.
- `package.json`: the Capacitor tools (installed in step 1).
- `resources/` and `store/`: icons (1024, 512 and 192 pixels) and the store listing.

## Requirements
1. Node.js 18 or newer.
2. Android: Android Studio, and a Google Play developer account (about USD 25 once).
3. iOS: a Mac with Xcode, and an Apple Developer account (about USD 99 a year).

## Build steps
1. `npm install`
2. `npx cap add android` and/or `npx cap add ios` (run once)
3. `npx cap sync` (after every website change)
4. `npx cap open android` or `npx cap open ios`
5. Android Studio: Build > Generate Signed App Bundle. Keep the signing key safe.
6. Xcode: Product > Archive, then upload.

## Before submitting
- The live backend must be connected. Until then, the app works on demo data on each device.
- Privacy policy and terms must be live at https://nomidtrans.shop.
- Replace the test payment key with the live key before building.
- Check each store's rules on payments inside apps before building the payment screens.
- Raise the version number each release.
