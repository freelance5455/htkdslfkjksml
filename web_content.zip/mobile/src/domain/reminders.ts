import { addLocalDays, isDateKey, localDateFromKey, nextOccurrence, toLocalDateKey } from "./dates";

export function reminderDateKeys(dueDate: string, offsets: readonly number[]): string[] {
  if (!isDateKey(dueDate)) throw new RangeError("Reminder due date must be a valid calendar date.");
  const unique = new Set<number>();
  for (const offset of offsets) {
    if (!Number.isInteger(offset) || offset < 0 || offset > 365) {
      throw new RangeError("Reminder offsets must be whole days from 0 to 365.");
    }
    unique.add(offset);
  }
  return Array.from(unique).map((offset) => addLocalDays(dueDate, -offset)).sort();
}

/** Reminders fire at 09:00 local time; a due-today reminder becomes a 1-minute fallback. */
export function reminderTimeForDate(dateKey: string, now = new Date()): Date | null {
  if (!isDateKey(dateKey)) throw new RangeError("Reminder date must be a valid calendar date.");
  const scheduled = localDateFromKey(dateKey, 9);
  if (scheduled.getTime() > now.getTime()) return scheduled;
  if (dateKey === toLocalDateKey(now)) return new Date(now.getTime() + 60_000);
  return null;
}

export function nextReminderOccurrence(dateKey: string, repeatsYearly: boolean, now = new Date()): string | null {
  if (!isDateKey(dateKey)) throw new RangeError("Calendar date must be valid.");
  const today = toLocalDateKey(now);
  if (!repeatsYearly) return dateKey >= today ? dateKey : null;
  let candidate = dateKey;
  const anchorDay = Number(dateKey.slice(8, 10));
  for (let count = 0; count < 200 && candidate < today; count += 1) {
    candidate = nextOccurrence(candidate, "yearly", 1, anchorDay) ?? candidate;
  }
  return candidate >= today ? candidate : null;
}
