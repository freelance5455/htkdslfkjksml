import { describe, expect, it } from "vitest";
import { calculateZakat, gramsToMilliGrams, HANAFI_REFERENCE_NISAB, type ZakatInput } from "./zakat";

const base = (): ZakatInput => ({
  currency: "UZS", currencyFractionDigits: 0, cashMinor: "150000000", bankSavingsMinor: "50000000", goldValueMinor: "0", silverValueMinor: "0",
  tradeInventoryMinor: "0", receivablesMinor: "0", otherEligibleAssetsMinor: "0", dueLiabilitiesMinor: "25000000", applicableDeductionsMinor: "5000000",
  nisabBasis: "silver", goldNisabMilliGrams: HANAFI_REFERENCE_NISAB.goldMilliGrams, silverNisabMilliGrams: HANAFI_REFERENCE_NISAB.silverMilliGrams,
  silverPricePerGramMinor: "15000", haulConfirmed: false, nisabConfirmed: false,
});

describe("Zakat estimator", () => {
  it("converts editable gram weights exactly to thousandths of a gram", () => {
    expect(gramsToMilliGrams("87.48")).toBe("87480");
    expect(gramsToMilliGrams("612.350")).toBe("612350");
    expect(gramsToMilliGrams("0")).toBeNull();
    expect(gramsToMilliGrams("1.2345")).toBeNull();
  });

  it("shows itemized cash and savings less liabilities and deductions", () => {
    const result = calculateZakat(base());
    expect(result.grossAssetsMinor).toBe("200000000");
    expect(result.liabilitiesAndDeductionsMinor).toBe("30000000");
    expect(result.zakatableWealthMinor).toBe("170000000");
    expect(result.status).toBe("confirm_conditions");
    expect(result.zakatDueMinor).toBeNull();
  });

  it("shows no payable amount until both nisab and haul are confirmed", () => {
    const input = base();
    input.haulConfirmed = true;
    expect(calculateZakat(input).zakatDueMinor).toBeNull();
    input.nisabConfirmed = true;
    const estimate = calculateZakat(input);
    expect(estimate.status).toBe("estimate_available");
    expect(estimate.zakatDueMinor).toBe("4250000");
  });

  it("requires a current user-entered price for the selected nisab metal", () => {
    const input = base();
    delete input.silverPricePerGramMinor;
    const result = calculateZakat(input);
    expect(result.status).toBe("needs_price");
    expect(result.zakatDueMinor).toBeNull();
  });

  it("does not make an estimate payable when the selected nisab weight is zero", () => {
    const input = base();
    input.silverNisabMilliGrams = "0";
    input.haulConfirmed = true;
    input.nisabConfirmed = true;
    const result = calculateZakat(input);
    expect(result.status).toBe("needs_nisab");
    expect(result.selectedNisabValueMinor).toBeNull();
    expect(result.zakatDueMinor).toBeNull();
  });

  it("calculates an entered metal weight in grams without confusing it with milligrams", () => {
    const input = base();
    input.goldValueMinor = undefined;
    input.goldWeightGrams = "1.500";
    input.goldPricePerGramMinor = "10000";
    const result = calculateZakat(input);
    expect(result.grossAssetsMinor).toBe("200015000");
  });
});
