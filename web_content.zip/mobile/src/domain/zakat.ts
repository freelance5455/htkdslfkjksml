export type ZakatInput = {
  currency: string;
  currencyFractionDigits: number;
  cashMinor: string;
  bankSavingsMinor: string;
  goldValueMinor?: string;
  goldWeightGrams?: string;
  goldPricePerGramMinor?: string;
  silverValueMinor?: string;
  silverWeightGrams?: string;
  silverPricePerGramMinor?: string;
  tradeInventoryMinor: string;
  receivablesMinor: string;
  otherEligibleAssetsMinor: string;
  dueLiabilitiesMinor: string;
  applicableDeductionsMinor: string;
  nisabBasis: "gold" | "silver";
  goldNisabMilliGrams: string;
  silverNisabMilliGrams: string;
  haulConfirmed: boolean;
  nisabConfirmed: boolean;
};

export type ZakatResult = {
  grossAssetsMinor: string;
  liabilitiesAndDeductionsMinor: string;
  zakatableWealthMinor: string;
  selectedNisabValueMinor: string | null;
  status: "needs_price" | "below_nisab" | "confirm_conditions" | "estimate_available";
  zakatDueMinor: string | null;
  explanation: string;
};

const MILLI = 1000n;

function minor(value: string | undefined): bigint {
  if (value === undefined || value.trim() === "") return 0n;
  if (!/^\d+$/.test(value)) throw new RangeError("Zakat amounts must be positive minor-unit integers.");
  return BigInt(value);
}

function milliGramsFromGrams(value: string): bigint | null {
  const match = /^(\d{1,8})(?:\.(\d{1,3}))?$/.exec(value.trim());
  if (!match) return null;
  const fraction = (match[2] ?? "").padEnd(3, "0");
  return BigInt(match[1]) * MILLI + BigInt(fraction || "0");
}

export function gramsToMilliGrams(value: string): string | null {
  return milliGramsFromGrams(value)?.toString() ?? null;
}

function metalValue(weightGrams?: string, pricePerGramMinor?: string): bigint | null {
  if (weightGrams === undefined || weightGrams.trim() === "") return 0n;
  const weight = milliGramsFromGrams(weightGrams);
  if (weight === null) return null;
  if (weight === 0n) return 0n;
  if (!pricePerGramMinor || !/^\d+$/.test(pricePerGramMinor) || BigInt(pricePerGramMinor) <= 0n) return null;
  return (weight * BigInt(pricePerGramMinor) + MILLI / 2n) / MILLI;
}

function roundTwoPointFivePercent(value: bigint): bigint {
  return (value * 25n + 500n) / 1000n;
}

/**
 * This estimate intentionally returns no payable amount until the user has entered a price
 * and explicitly confirmed the selected nisab and applicable lunar-year/haul condition.
 */
export function calculateZakat(input: ZakatInput): ZakatResult {
  const goldFromWeight = metalValue(input.goldWeightGrams, input.goldPricePerGramMinor);
  const silverFromWeight = metalValue(input.silverWeightGrams, input.silverPricePerGramMinor);
  const goldValue = input.goldValueMinor?.trim() ? minor(input.goldValueMinor) : goldFromWeight;
  const silverValue = input.silverValueMinor?.trim() ? minor(input.silverValueMinor) : silverFromWeight;
  const nisabPrice = input.nisabBasis === "gold" ? input.goldPricePerGramMinor : input.silverPricePerGramMinor;
  const nisabWeight = minor(input.nisabBasis === "gold" ? input.goldNisabMilliGrams : input.silverNisabMilliGrams);
  const validNisabPrice = Boolean(nisabPrice && /^\d+$/.test(nisabPrice) && BigInt(nisabPrice) > 0n);
  const selectedNisab = validNisabPrice
    ? (nisabWeight * BigInt(nisabPrice!) + MILLI / 2n) / MILLI
    : null;
  const assets = [
    minor(input.cashMinor),
    minor(input.bankSavingsMinor),
    goldValue ?? 0n,
    silverValue ?? 0n,
    minor(input.tradeInventoryMinor),
    minor(input.receivablesMinor),
    minor(input.otherEligibleAssetsMinor),
  ];
  const grossAssets = assets.reduce((sum, item) => sum + item, 0n);
  const liabilities = minor(input.dueLiabilitiesMinor) + minor(input.applicableDeductionsMinor);
  const wealth = grossAssets > liabilities ? grossAssets - liabilities : 0n;
  const base = {
    grossAssetsMinor: grossAssets.toString(),
    liabilitiesAndDeductionsMinor: liabilities.toString(),
    zakatableWealthMinor: wealth.toString(),
    selectedNisabValueMinor: selectedNisab?.toString() ?? null,
  };
  const assetPriceMissing = (input.goldValueMinor?.trim() === "" || input.goldValueMinor === undefined) && goldFromWeight === null
    || (input.silverValueMinor?.trim() === "" || input.silverValueMinor === undefined) && silverFromWeight === null;
  if (!validNisabPrice || selectedNisab === null || assetPriceMissing) {
    return { ...base, status: "needs_price", zakatDueMinor: null, explanation: "Enter a current price per gram for the selected nisab metal and for any metal assets entered by weight." };
  }
  if (wealth < selectedNisab) {
    return { ...base, status: "below_nisab", zakatDueMinor: null, explanation: "The estimate is below the currently entered nisab reference." };
  }
  if (!input.nisabConfirmed || !input.haulConfirmed) {
    return {
      ...base,
      status: "confirm_conditions",
      zakatDueMinor: null,
      explanation: "Review the threshold and personally confirm both nisab and the applicable lunar-year/haul condition before showing a payable estimate.",
    };
  }
  return {
    ...base,
    status: "estimate_available",
    zakatDueMinor: roundTwoPointFivePercent(wealth).toString(),
    explanation: "Illustrative 2.5% estimate based only on the entries and conditions you confirmed.",
  };
}

/** Hanafi-oriented editable starting references, expressed in thousandths of a gram. */
export const HANAFI_REFERENCE_NISAB = {
  goldMilliGrams: "87480",
  silverMilliGrams: "612350",
} as const;
