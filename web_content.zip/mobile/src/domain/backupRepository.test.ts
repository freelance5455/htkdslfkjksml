import { describe, expect, it, vi } from "vitest";

const state = vi.hoisted(() => ({ database: null as unknown }));
vi.mock("../db/repositorySupport", () => ({ readyDatabase: async () => state.database }));

import { createPortableBackupSnapshot, restorePortableBackupSnapshot } from "../db/backupRepository";

const tableColumns: Record<string, string[]> = {
  categories: ["id", "name", "kind", "color", "is_default", "created_at"],
  transactions: ["id", "kind", "category_id", "amount_minor", "currency", "date_key", "note", "source_type", "source_id", "is_demo", "created_at", "updated_at"],
  bills: ["id", "title", "category_id", "amount_minor", "currency", "next_due_date", "recurrence", "interval", "anchor_day", "reminder_offsets", "is_active", "is_demo", "created_at", "updated_at"],
  bill_payments: ["id", "bill_id", "occurrence_date", "paid_date", "amount_minor", "currency", "transaction_id", "created_at"],
  debts: ["id", "direction", "person", "note", "principal_minor", "currency", "start_date", "due_date", "reminder_offsets", "is_demo", "created_at", "updated_at"],
  debt_repayments: ["id", "debt_id", "amount_minor", "date_key", "note", "transaction_id", "created_at"],
  budgets: ["id", "month_key", "category_id", "limit_minor", "currency", "created_at", "updated_at"],
  important_dates: ["id", "title", "date_key", "repeats_yearly", "note", "reminder_offsets", "is_demo", "created_at", "updated_at"],
  zakat_profiles: ["id", "label", "calculation_date", "currency", "method", "input_json", "haul_confirmed", "nisab_confirmed", "reminder_date", "created_at", "updated_at"],
  manual_fx_rates: ["id", "base_currency", "quote_currency", "rate_numerator", "rate_denominator", "effective_date", "created_at"],
  app_settings: ["key", "value", "updated_at"],
};

function fixtures(): Record<string, Record<string, string | number | null>[]> {
  return {
    categories: [
      { id: "builtin-income", name: "Salary", kind: "income", color: "#14836d", is_default: 1, created_at: "2026-01-01T00:00:00Z" },
      { id: "custom-home", name: "Home", kind: "expense", color: "#123456", is_default: 0, created_at: "2026-01-02T00:00:00Z" },
    ],
    transactions: [{ id: "tx-1", kind: "expense", category_id: "custom-home", amount_minor: "900719925474099312345", currency: "UZS", date_key: "2026-01-03", note: "local", source_type: "manual", source_id: null, is_demo: 0, created_at: "2026-01-03T00:00:00Z", updated_at: "2026-01-03T00:00:00Z" }],
    bills: [], bill_payments: [], debts: [], debt_repayments: [], budgets: [], important_dates: [], zakat_profiles: [], manual_fx_rates: [],
    app_settings: [
      { key: "language", value: "\"uz\"", updated_at: "2026-01-01T00:00:00Z" },
      { key: "preferredCurrency", value: "\"UZS\"", updated_at: "2026-01-01T00:00:00Z" },
      { key: "themeMode", value: "\"system\"", updated_at: "2026-01-01T00:00:00Z" },
      { key: "customCurrencies", value: "[]", updated_at: "2026-01-01T00:00:00Z" },
      { key: "localRemindersEnabled", value: "true", updated_at: "2026-01-01T00:00:00Z" },
      { key: "zakatReminder", value: "{\"dateKey\":\"2026-11-30\",\"offsets\":[3,1,0]}", updated_at: "2026-01-01T00:00:00Z" },
      { key: "zakatProfile", value: JSON.stringify({ cash: "0", savings: "0", goldWeight: "", goldPrice: "", goldValue: "", silverWeight: "", silverPrice: "", silverValue: "", inventory: "0", receivables: "0", otherAssets: "0", liabilities: "0", deductions: "0", goldNisabGrams: "87.48", silverNisabGrams: "612.35", nisabBasis: "silver", haulConfirmed: false, nisabConfirmed: false, calculationDate: "2026-01-04", currency: "UZS", resultStatus: "estimate_available", savedAt: "2026-01-04T00:00:00Z" }), updated_at: "2026-01-04T00:00:00Z" },
      { key: "pinVerifier", value: "should-not-export", updated_at: "2026-01-01T00:00:00Z" },
    ],
  };
}

function installFakeDatabase() {
  const data = fixtures();
  const operations: Array<{ sql: string; params: unknown[] }> = [];
  let transactionCalls = 0;
  const transaction = {
    runAsync: async (sql: string, params: unknown[] = []) => {
      operations.push({ sql, params });
      return { changes: 1, lastInsertRowId: 1 };
    },
  };
  const database = {
    getAllAsync: async (sql: string) => {
      const pragma = sql.match(/^PRAGMA table_info\("([a-z_]+)"\)$/);
      if (pragma) return (tableColumns[pragma[1] ?? ""] ?? []).map((name) => ({ name }));
      const select = sql.match(/^SELECT \* FROM "([a-z_]+)"$/);
      if (select) return data[select[1] ?? ""] ?? [];
      throw new Error(`Unexpected query: ${sql}`);
    },
    withExclusiveTransactionAsync: async (callback: (tx: typeof transaction) => Promise<void>) => {
      transactionCalls += 1;
      await callback(transaction);
    },
  };
  state.database = database;
  return { operations, getTransactionCalls: () => transactionCalls };
}

describe("portable backup repository", () => {
  it("exports every finance table while omitting built-in categories and non-allowlisted settings", async () => {
    installFakeDatabase();
    const snapshot = await createPortableBackupSnapshot();
    expect(Object.keys(snapshot.tables)).toEqual(Object.keys(tableColumns));
    expect(snapshot.tables.categories.map((row) => row.id)).toEqual(["custom-home"]);
    expect(snapshot.tables.app_settings.map((row) => row.key)).toEqual(["language", "preferredCurrency", "themeMode", "customCurrencies", "localRemindersEnabled", "zakatReminder", "zakatProfile"]);
    expect(snapshot.tables.app_settings.find((row) => row.key === "zakatProfile")?.value).toContain("silverNisabGrams");
    expect(snapshot.tables.transactions[0]?.amount_minor).toBe("900719925474099312345");
    expect(snapshot.tables.bill_payments).toEqual([]);
    expect(snapshot.tables.zakat_profiles).toEqual([]);
  });

  it("validates first, clears in foreign-key-safe order, then inserts custom categories before linked records", async () => {
    const fake = installFakeDatabase();
    const snapshot = await createPortableBackupSnapshot();
    await restorePortableBackupSnapshot(snapshot);
    expect(fake.getTransactionCalls()).toBe(1);
    const sql = fake.operations.map((operation) => operation.sql);
    expect(sql.slice(0, 12)).toEqual([
      "DELETE FROM notification_links",
      "DELETE FROM debt_repayments",
      "DELETE FROM bill_payments",
      "DELETE FROM transactions",
      "DELETE FROM bills",
      "DELETE FROM debts",
      "DELETE FROM budgets",
      "DELETE FROM important_dates",
      "DELETE FROM zakat_profiles",
      "DELETE FROM manual_fx_rates",
      "DELETE FROM categories WHERE is_default=0",
      "DELETE FROM app_settings WHERE key IN (?,?,?,?,?,?,?)",
    ]);
    expect(sql.findIndex((statement) => statement.startsWith('INSERT INTO "categories"'))).toBeLessThan(sql.findIndex((statement) => statement.startsWith('INSERT INTO "transactions"')));
    expect(fake.operations.some((operation) => operation.params.includes("should-not-export"))).toBe(false);
  });

  it("rejects injected non-allowlisted settings before starting a write transaction", async () => {
    const fake = installFakeDatabase();
    const snapshot = await createPortableBackupSnapshot();
    snapshot.tables.app_settings.push({ key: "pinVerifier", value: "not-allowed", updated_at: "2026-01-02T00:00:00Z" });
    await expect(restorePortableBackupSnapshot(snapshot)).rejects.toThrow("BACKUP_FILE_INVALID");
    expect(fake.getTransactionCalls()).toBe(0);
  });

  it("rejects malformed custom currency preferences before database mutation", async () => {
    const fake = installFakeDatabase();
    const snapshot = await createPortableBackupSnapshot();
    const currencies = snapshot.tables.app_settings.find((row) => row.key === "customCurrencies");
    if (!currencies) throw new Error("customCurrencies fixture is missing");
    currencies.value = JSON.stringify([{ code: "BAD", name: "Invalid precision", symbol: "B", fractionDigits: 99 }]);
    await expect(restorePortableBackupSnapshot(snapshot)).rejects.toThrow("BACKUP_FILE_INVALID");
    expect(fake.getTransactionCalls()).toBe(0);
  });
});
