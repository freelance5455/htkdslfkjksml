export type RationalFxRate = { numerator: string; denominator: string };

function gcd(a: bigint, b: bigint): bigint {
  let left = a < 0n ? -a : a;
  let right = b < 0n ? -b : b;
  while (right) [left, right] = [right, left % right];
  return left;
}

export function rationalFxRate(numeratorText: string, denominatorText: string): RationalFxRate | null {
  if (!/^\d{1,24}$/.test(numeratorText.trim()) || !/^\d{1,24}$/.test(denominatorText.trim())) return null;
  const numerator = BigInt(numeratorText.trim());
  const denominator = BigInt(denominatorText.trim());
  if (numerator <= 0n || denominator <= 0n) return null;
  const divisor = gcd(numerator, denominator);
  return { numerator: (numerator / divisor).toString(), denominator: (denominator / divisor).toString() };
}
