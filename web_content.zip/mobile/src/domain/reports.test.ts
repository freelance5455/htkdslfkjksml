import { describe, expect, it } from "vitest";
import { aggregateMonthlyReport, type ReportTransaction } from "./reports";

const row = (input: Partial<ReportTransaction> & Pick<ReportTransaction, "id" | "kind" | "amountMinor" | "dateKey">): ReportTransaction => ({
  id: input.id, kind: input.kind, amountMinor: input.amountMinor, dateKey: input.dateKey,
  categoryId: input.categoryId ?? null, categoryName: input.categoryName ?? null,
  currency: input.currency ?? "UZS", note: input.note ?? "", isDemo: input.isDemo ?? false,
});

describe("monthly report aggregation", () => {
  it("totals the chosen currency exactly and groups expenses by category and local date", () => {
    const rows = [
      row({ id: "1", kind: "income", amountMinor: "5000000", dateKey: "2026-05-01" }),
      row({ id: "2", kind: "expense", amountMinor: "1000000", dateKey: "2026-05-02", categoryId: "food", categoryName: "Food", isDemo: true }),
      row({ id: "3", kind: "expense", amountMinor: "250000", dateKey: "2026-05-02", categoryId: "home", categoryName: "Home" }),
    ];
    const result = aggregateMonthlyReport("2026-05", "UZS", rows);
    expect(result.incomeMinor).toBe("5000000");
    expect(result.expenseMinor).toBe("1250000");
    expect(result.balanceMinor).toBe("3750000");
    expect(result.demoCount).toBe(1);
    expect(result.transactionCount).toBe(3);
    expect(result.categories.map((item) => item.amountMinor)).toEqual(["1000000", "250000"]);
    expect(result.days).toEqual([
      { dateKey: "2026-05-01", incomeMinor: "5000000", expenseMinor: "0" },
      { dateKey: "2026-05-02", incomeMinor: "0", expenseMinor: "1250000" },
    ]);
  });

  it("rejects negative values rather than silently reporting malformed records", () => {
    expect(() => aggregateMonthlyReport("2026-05", "UZS", [row({ id: "1", kind: "expense", amountMinor: "-1", dateKey: "2026-05-01" })])).toThrow("Transaction amount cannot be negative.");
  });
});
