import { describe, expect, it } from "vitest";
import { convertMinorUnits, decimalToMinorUnits, formatMoney, minorUnitsToDecimal } from "./money";

describe("money", () => {
  it("parses the selected currency precision without floating point", () => {
    expect(decimalToMinorUnits("12 500", 0)).toBeNull();
    expect(decimalToMinorUnits("12500", 0)).toBe("12500");
    expect(decimalToMinorUnits("19,95", 2)).toBe("1995");
    expect(decimalToMinorUnits("1.234", 2)).toBeNull();
    expect(minorUnitsToDecimal("123456", 2)).toBe("1234.56");
  });

  it("converts with a rational manual rate and half-up rounding", () => {
    // USD 1.00 × 12,345.50 UZS/USD = 12,346 UZS after whole-soʻm rounding.
    expect(convertMinorUnits("100", 2, 0, "1234550", "100")).toBe("12346");
  });

  it("formats a large value from exact minor units", () => {
    expect(formatMoney("123456789012345678", { code: "USD", name: "US dollar", symbol: "$", fractionDigits: 2 }, "en-US"))
      .toBe("$1,234,567,890,123,456.78");
  });
});
