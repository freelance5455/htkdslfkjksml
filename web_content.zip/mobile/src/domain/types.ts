import type { Recurrence } from "./dates";

export type EntryType = "income" | "expense";
export type DebtDirection = "lent" | "borrowed";
export type Category = { id: string; name: string; kind: EntryType; color: string; isDefault: boolean };
export type Transaction = {
  id: string; kind: EntryType; categoryId: string | null; amountMinor: string; currency: string;
  dateKey: string; note: string; isDemo: boolean; createdAt: string;
};
export type Bill = {
  id: string; title: string; categoryId: string | null; amountMinor: string; currency: string;
  nextDueDate: string; recurrence: Recurrence; interval: number; anchorDay: number; reminderOffsets: number[];
  isActive: boolean; isDemo: boolean;
};
export type Debt = {
  id: string; direction: DebtDirection; person: string; note: string; principalMinor: string;
  currency: string; startDate: string; dueDate: string | null; reminderOffsets: number[]; isDemo: boolean;
};
export type Repayment = { id: string; debtId: string; amountMinor: string; dateKey: string; note: string };
export type Budget = { id: string; monthKey: string; categoryId: string; limitMinor: string; currency: string };
export type ImportantDate = { id: string; title: string; dateKey: string; repeatsYearly: boolean; note: string; isDemo: boolean; reminderOffsets?: number[] };
export type MonthlySummary = { currency: string; incomeMinor: string; expenseMinor: string; balanceMinor: string };
