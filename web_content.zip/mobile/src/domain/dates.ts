export type Recurrence = "none" | "daily" | "weekly" | "monthly" | "yearly";

export function isDateKey(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const [year, month, day] = value.split("-").map(Number);
  const date = new Date(year, month - 1, day, 12, 0, 0, 0);
  return date.getFullYear() === year && date.getMonth() === month - 1 && date.getDate() === day;
}

export function toLocalDateKey(date = new Date()): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

export function localDateFromKey(dateKey: string, hour = 12): Date {
  if (!isDateKey(dateKey)) throw new RangeError("Enter a valid calendar date.");
  const [year, month, day] = dateKey.split("-").map(Number);
  return new Date(year, month - 1, day, hour, 0, 0, 0);
}

export function addLocalDays(dateKey: string, amount: number): string {
  if (!Number.isInteger(amount)) throw new RangeError("Day change must be a whole number.");
  const date = localDateFromKey(dateKey);
  date.setDate(date.getDate() + amount);
  return toLocalDateKey(date);
}

export function daysInMonth(year: number, monthIndex: number): number {
  return new Date(year, monthIndex + 1, 0, 12).getDate();
}

/** Advances a recurring schedule while preserving its original day-of-month anchor. */
export function nextOccurrence(
  currentDateKey: string,
  recurrence: Recurrence,
  interval = 1,
  anchorDay?: number,
): string | null {
  if (!isDateKey(currentDateKey)) throw new RangeError("Enter a valid calendar date.");
  if (recurrence === "none") return null;
  if (!Number.isInteger(interval) || interval < 1 || interval > 120) {
    throw new RangeError("Repeat interval must be from 1 to 120.");
  }
  const current = localDateFromKey(currentDateKey);
  if (recurrence === "daily") return addLocalDays(currentDateKey, interval);
  if (recurrence === "weekly") return addLocalDays(currentDateKey, interval * 7);

  const originalDay = anchorDay ?? current.getDate();
  if (recurrence === "monthly") {
    const monthIndex = current.getFullYear() * 12 + current.getMonth() + interval;
    const year = Math.floor(monthIndex / 12);
    const month = monthIndex % 12;
    return `${year}-${String(month + 1).padStart(2, "0")}-${String(Math.min(originalDay, daysInMonth(year, month))).padStart(2, "0")}`;
  }

  const year = current.getFullYear() + interval;
  const month = current.getMonth();
  return `${year}-${String(month + 1).padStart(2, "0")}-${String(Math.min(originalDay, daysInMonth(year, month))).padStart(2, "0")}`;
}

export function daysBetween(fromDateKey: string, toDateKey: string): number {
  const from = Date.UTC(...dateParts(fromDateKey));
  const to = Date.UTC(...dateParts(toDateKey));
  return Math.round((to - from) / 86_400_000);
}

function dateParts(dateKey: string): [number, number, number] {
  if (!isDateKey(dateKey)) throw new RangeError("Enter a valid calendar date.");
  const [year, month, day] = dateKey.split("-").map(Number);
  return [year, month - 1, day];
}

export function formatLocalDate(dateKey: string, locale: string): string {
  return new Intl.DateTimeFormat(locale, { day: "numeric", month: "short", year: "numeric" })
    .format(localDateFromKey(dateKey));
}
