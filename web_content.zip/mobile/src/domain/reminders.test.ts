import { describe, expect, it } from "vitest";
import { nextReminderOccurrence, reminderDateKeys, reminderTimeForDate } from "./reminders";

describe("local reminder dates", () => {
  it("sorts and deduplicates valid offsets across a month boundary", () => {
    expect(reminderDateKeys("2025-02-01", [3, 1, 0, 1])).toEqual(["2025-01-29", "2025-01-31", "2025-02-01"]);
  });

  it("rejects invalid due dates and reminder offsets", () => {
    expect(() => reminderDateKeys("2025-02-29", [1])).toThrow();
    expect(() => reminderDateKeys("2025-02-28", [-1])).toThrow();
  });

  it("uses the next morning for future reminders, skips old dates, and does not silently miss due-today", () => {
    const morning = new Date(2025, 0, 10, 8, 0, 0, 0);
    expect(reminderTimeForDate("2025-01-11", morning)?.getHours()).toBe(9);
    expect(reminderTimeForDate("2025-01-09", morning)).toBeNull();
    const afterNine = new Date(2025, 0, 10, 11, 0, 0, 0);
    expect(reminderTimeForDate("2025-01-10", afterNine)?.getTime()).toBe(afterNine.getTime() + 60_000);
  });

  it("advances a recurring important date to its next local occurrence", () => {
    expect(nextReminderOccurrence("2024-07-20", true, new Date(2025, 7, 1, 12))).toBe("2026-07-20");
    expect(nextReminderOccurrence("2024-07-20", false, new Date(2025, 7, 1, 12))).toBeNull();
    expect(nextReminderOccurrence("2024-02-29", true, new Date(2028, 1, 27, 12))).toBe("2028-02-29");
  });
});
