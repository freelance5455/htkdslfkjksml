export type CurrencyDefinition = {
  code: string;
  name: string;
  symbol: string;
  fractionDigits: number;
};

export const DEFAULT_CURRENCIES: readonly CurrencyDefinition[] = [
  { code: "UZS", name: "Uzbekistani soʻm", symbol: "soʻm", fractionDigits: 0 },
  { code: "USD", name: "US dollar", symbol: "$", fractionDigits: 2 },
  { code: "EUR", name: "Euro", symbol: "€", fractionDigits: 2 },
  { code: "RUB", name: "Russian ruble", symbol: "₽", fractionDigits: 2 },
  { code: "KZT", name: "Kazakhstani tenge", symbol: "₸", fractionDigits: 2 },
  { code: "TRY", name: "Turkish lira", symbol: "₺", fractionDigits: 2 },
  { code: "GBP", name: "British pound", symbol: "£", fractionDigits: 2 },
  { code: "CNY", name: "Chinese yuan", symbol: "¥", fractionDigits: 2 },
];

export function currencyDefinitionFor(
  code: string,
  customCurrencies: readonly CurrencyDefinition[] = [],
): CurrencyDefinition {
  return [...DEFAULT_CURRENCIES, ...customCurrencies].find((item) => item.code === code)
    ?? { code, name: code, symbol: code, fractionDigits: 2 };
}

export function fractionDigitsFor(
  code: string,
  customCurrencies: readonly CurrencyDefinition[] = [],
): number {
  return [...DEFAULT_CURRENCIES, ...customCurrencies].find((item) => item.code === code)
    ?.fractionDigits ?? 2;
}

function pow10(digits: number): bigint {
  if (!Number.isInteger(digits) || digits < 0 || digits > 6) {
    throw new RangeError("Currency precision must be from 0 to 6 decimal places.");
  }
  return 10n ** BigInt(digits);
}

/** Parses an ungrouped user entry to integer minor units. Invalid precision is rejected, not rounded. */
export function decimalToMinorUnits(value: string, fractionDigits: number): string | null {
  if (!Number.isInteger(fractionDigits) || fractionDigits < 0 || fractionDigits > 6) return null;
  let input = value.trim().replace(",", ".");
  if (input.startsWith(".")) input = `0${input}`;
  const match = /^(\d{1,16})(?:\.(\d{0,6}))?$/.exec(input);
  if (!match) return null;
  const fraction = match[2] ?? "";
  if (fraction.length > fractionDigits) return null;
  const scale = pow10(fractionDigits);
  const whole = BigInt(match[1]);
  const paddedFraction = BigInt((fraction + "0".repeat(fractionDigits)).slice(0, fractionDigits) || "0");
  return (whole * scale + paddedFraction).toString();
}

export function minorUnitsToDecimal(minorUnits: string | bigint, fractionDigits: number): string {
  const value = BigInt(minorUnits);
  const scale = pow10(fractionDigits);
  const negative = value < 0n;
  const absolute = negative ? -value : value;
  const whole = absolute / scale;
  if (fractionDigits === 0) return `${negative ? "-" : ""}${whole}`;
  const fraction = (absolute % scale).toString().padStart(fractionDigits, "0");
  return `${negative ? "-" : ""}${whole}.${fraction}`;
}

export function formatMoney(
  minorUnits: string | bigint,
  currency: CurrencyDefinition,
  locale = "uz-Latn-UZ",
): string {
  const value = BigInt(minorUnits);
  const negative = value < 0n;
  const absolute = negative ? -value : value;
  const scale = pow10(currency.fractionDigits);
  const whole = absolute / scale;
  const fraction = currency.fractionDigits
    ? (absolute % scale).toString().padStart(currency.fractionDigits, "0")
    : "";
  const groupedWhole = new Intl.NumberFormat(locale, { maximumFractionDigits: 0 }).format(whole);
  const decimalSeparator = new Intl.NumberFormat(locale).formatToParts(1.1)
    .find((part) => part.type === "decimal")?.value ?? ".";
  const number = `${negative ? "−" : ""}${groupedWhole}${fraction ? `${decimalSeparator}${fraction}` : ""}`;
  const symbolBefore = ["$", "€", "₽", "£", "¥"].includes(currency.symbol);
  return symbolBefore ? `${currency.symbol}${number}` : `${number} ${currency.symbol || currency.code}`;
}

/** Converts with a positive rational quote rate, rounded half-up to the target minor unit. */
export function convertMinorUnits(
  amountMinor: string | bigint,
  fromDigits: number,
  toDigits: number,
  rateNumerator: string | bigint,
  rateDenominator: string | bigint,
): string {
  const amount = BigInt(amountMinor);
  const numerator = amount * BigInt(rateNumerator) * pow10(toDigits);
  const denominator = BigInt(rateDenominator) * pow10(fromDigits);
  if (denominator <= 0n) throw new RangeError("The conversion rate must be positive.");
  const absolute = numerator < 0n ? -numerator : numerator;
  const rounded = (absolute * 2n + denominator) / (2n * denominator);
  return (numerator < 0n ? -rounded : rounded).toString();
}

export function sumMinorUnits(values: readonly (string | bigint)[]): string {
  return values.reduce<bigint>((sum, value) => sum + BigInt(value), 0n).toString();
}
