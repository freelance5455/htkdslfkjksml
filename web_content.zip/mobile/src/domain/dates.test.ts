import { describe, expect, it } from "vitest";
import { addLocalDays, isDateKey, nextOccurrence } from "./dates";

describe("local dates and recurrence", () => {
  it("rejects impossible date keys", () => {
    expect(isDateKey("2026-02-29")).toBe(false);
    expect(isDateKey("2028-02-29")).toBe(true);
  });

  it("steps across month-end while preserving the original bill day", () => {
    expect(nextOccurrence("2026-01-31", "monthly", 1, 31)).toBe("2026-02-28");
    expect(nextOccurrence("2026-02-28", "monthly", 1, 31)).toBe("2026-03-31");
  });

  it("clamps a yearly leap-day event to February 28 in a non-leap year", () => {
    expect(nextOccurrence("2024-02-29", "yearly", 1, 29)).toBe("2025-02-28");
  });

  it("uses calendar dates rather than 24-hour jumps for DST boundaries", () => {
    expect(addLocalDays("2026-03-07", 1)).toBe("2026-03-08");
  });
});
