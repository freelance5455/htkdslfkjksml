import { describe, expect, it } from "vitest";
import { rationalFxRate } from "./fxRates";

describe("manual FX rates", () => {
  it("reduces a positive integer ratio exactly", () => {
    expect(rationalFxRate("12800", "100")).toEqual({ numerator: "128", denominator: "1" });
  });
  it("rejects zero, signs, decimals and oversized inputs", () => {
    expect(rationalFxRate("0", "1")).toBeNull();
    expect(rationalFxRate("1.25", "1")).toBeNull();
    expect(rationalFxRate("1", "-1")).toBeNull();
    expect(rationalFxRate("1".repeat(25), "1")).toBeNull();
  });
});
