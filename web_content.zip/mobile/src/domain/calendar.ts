import { nextOccurrence, type Recurrence } from "./dates";
import type { Bill, Debt, ImportantDate } from "./types";

export type CalendarEvent = {
  id: string;
  sourceId: string;
  type: "bill" | "debt" | "important";
  title: string;
  dateKey: string;
  amountMinor?: string;
  currency?: string;
  isDemo: boolean;
};

function nextMonth(monthKey: string): string {
  const [year, month] = monthKey.split("-").map(Number);
  return month === 12 ? `${year + 1}-01` : `${year}-${String(month + 1).padStart(2, "0")}`;
}

function validMonth(monthKey: string): boolean {
  return /^\d{4}-(0[1-9]|1[0-2])$/.test(monthKey);
}

export function billDatesInMonth(bill: Bill, monthKey: string): string[] {
  if (!validMonth(monthKey)) throw new RangeError("Calendar month must use YYYY-MM.");
  const start = `${monthKey}-01`;
  const end = `${nextMonth(monthKey)}-01`;
  let occurrence = bill.nextDueDate;
  let steps = 0;
  while (occurrence < start && bill.recurrence !== "none" && steps < 50000) {
    const following = nextOccurrence(occurrence, bill.recurrence, bill.interval, bill.anchorDay);
    if (!following || following <= occurrence) return [];
    occurrence = following; steps += 1;
  }
  const output: string[] = [];
  while (occurrence >= start && occurrence < end && steps < 50000) {
    output.push(occurrence);
    if (bill.recurrence === "none") break;
    const following = nextOccurrence(occurrence, bill.recurrence, bill.interval, bill.anchorDay);
    if (!following || following <= occurrence) break;
    occurrence = following; steps += 1;
  }
  return output;
}

function dateInCalendarYear(dateKey: string, year: number): string | null {
  let candidate = dateKey;
  let candidateYear = Number(candidate.slice(0, 4));
  if (candidateYear > year) return null;
  let steps = 0;
  while (candidateYear < year && steps < 1200) {
    const following = nextOccurrence(candidate, "yearly", 1, Number(dateKey.slice(8, 10)));
    if (!following) return null;
    candidate = following; candidateYear = Number(candidate.slice(0, 4)); steps += 1;
  }
  return candidateYear === year ? candidate : null;
}

export function calendarEventsForMonth(input: {
  monthKey: string;
  bills: Bill[];
  debts: Debt[];
  dates: ImportantDate[];
}): CalendarEvent[] {
  const { monthKey, bills, debts, dates } = input;
  if (!validMonth(monthKey)) throw new RangeError("Calendar month must use YYYY-MM.");
  const events: CalendarEvent[] = [];
  for (const bill of bills) for (const dateKey of billDatesInMonth(bill, monthKey)) {
    events.push({ id: `bill:${bill.id}:${dateKey}`, sourceId: bill.id, type: "bill", title: bill.title, dateKey, amountMinor: bill.amountMinor, currency: bill.currency, isDemo: bill.isDemo });
  }
  for (const debt of input.debts) if (debt.dueDate?.startsWith(monthKey)) {
    events.push({ id: `debt:${debt.id}:${debt.dueDate}`, sourceId: debt.id, type: "debt", title: debt.person, dateKey: debt.dueDate, amountMinor: debt.principalMinor, currency: debt.currency, isDemo: debt.isDemo });
  }
  const year = Number(monthKey.slice(0, 4));
  for (const date of dates) {
    const dateKey = date.repeatsYearly ? dateInCalendarYear(date.dateKey, year) : date.dateKey;
    if (dateKey?.startsWith(monthKey)) events.push({ id: `important:${date.id}:${dateKey}`, sourceId: date.id, type: "important", title: date.title, dateKey, isDemo: date.isDemo });
  }
  return events.sort((left, right) => left.dateKey.localeCompare(right.dateKey) || left.type.localeCompare(right.type) || left.title.localeCompare(right.title));
}

export const recurrenceLabels: Readonly<Record<Recurrence, string>> = {
  none: "No repeat", daily: "Daily", weekly: "Weekly", monthly: "Monthly", yearly: "Yearly",
};
