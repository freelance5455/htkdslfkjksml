import { describe, expect, it, vi } from "vitest";

const { randomState } = vi.hoisted(() => ({ randomState: { counter: 0 } }));
vi.mock("expo-crypto", () => ({
  getRandomBytesAsync: async (length: number) => {
    const seed = randomState.counter++;
    return Uint8Array.from({ length }, (_, index) => (seed * 37 + index + 1) & 255);
  },
}));

import { decryptBackupPayload, encryptBackupPayload } from "../features/backupCrypto";

const sample = {
  app: "TOLOVCHI",
  rows: [{ amountMinor: "900719925474099312345", currency: "UZS", person: "private contact" }],
};

describe("encrypted portable backups", () => {
  it("round-trips UTF-8 financial data without exposing it in the file", async () => {
    const encrypted = await encryptBackupPayload(sample, "correct-horse-battery-uzbekistan");
    expect(encrypted).not.toContain("private contact");
    expect(await decryptBackupPayload(encrypted, "correct-horse-battery-uzbekistan")).toEqual(sample);
  });

  it("rejects weak passphrases and wrong passwords", async () => {
    await expect(encryptBackupPayload(sample, "short")).rejects.toThrow("BACKUP_PASSPHRASE_WEAK");
    const encrypted = await encryptBackupPayload(sample, "another-long-private-passphrase");
    await expect(decryptBackupPayload(encrypted, "different-long-private-passphrase")).rejects.toThrow("BACKUP_PASSWORD_OR_FILE_INVALID");
  });

  it("detects authenticated ciphertext changes and unsupported file formats", async () => {
    const encrypted = await encryptBackupPayload(sample, "tamper-resistant-backup-passphrase");
    const envelope = JSON.parse(encrypted) as { ciphertext: string };
    envelope.ciphertext = `${envelope.ciphertext.slice(0, -4)}AAAA`;
    await expect(decryptBackupPayload(JSON.stringify(envelope), "tamper-resistant-backup-passphrase")).rejects.toThrow("BACKUP_PASSWORD_OR_FILE_INVALID");
    await expect(decryptBackupPayload("{}", "tamper-resistant-backup-passphrase")).rejects.toThrow("BACKUP_PASSWORD_OR_FILE_INVALID");
  });
});
