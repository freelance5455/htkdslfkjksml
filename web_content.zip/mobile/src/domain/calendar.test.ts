import { describe, expect, it } from "vitest";
import { billDatesInMonth, calendarEventsForMonth } from "./calendar";
import type { Bill, Debt, ImportantDate } from "./types";

const bill = (overrides: Partial<Bill> = {}): Bill => ({
  id: "bill-1", title: "Utilities", categoryId: "home", amountMinor: "12500", currency: "UZS",
  nextDueDate: "2025-01-31", recurrence: "monthly", interval: 1, anchorDay: 31, reminderOffsets: [3, 1, 0], isActive: true, isDemo: false,
  ...overrides,
});

describe("calendar projection", () => {
  it("preserves monthly day anchors across short months", () => {
    expect(billDatesInMonth(bill(), "2025-02")).toEqual(["2025-02-28"]);
    expect(billDatesInMonth(bill(), "2025-03")).toEqual(["2025-03-31"]);
  });

  it("projects a repeated bill more than once when its interval is daily", () => {
    expect(billDatesInMonth(bill({ nextDueDate: "2025-03-01", recurrence: "daily", anchorDay: 1 }), "2025-03")).toHaveLength(31);
  });

  it("projects one-time dates only in their month and annual dates on leap-safe dates", () => {
    const dates: ImportantDate[] = [
      { id: "leap", title: "Annual reminder", dateKey: "2024-02-29", repeatsYearly: true, note: "", isDemo: false },
      { id: "once", title: "One time", dateKey: "2025-03-20", repeatsYearly: false, note: "", isDemo: false },
    ];
    expect(calendarEventsForMonth({ monthKey: "2025-02", bills: [], debts: [], dates }).map((event) => event.dateKey)).toEqual(["2025-02-28"]);
    expect(calendarEventsForMonth({ monthKey: "2025-03", bills: [], debts: [], dates }).map((event) => event.title)).toEqual(["One time"]);
  });

  it("includes debts due in the selected month and sorts all event types by date", () => {
    const debt: Debt = { id: "d1", direction: "borrowed", person: "Label", note: "", principalMinor: "1000", currency: "USD", startDate: "2025-02-01", dueDate: "2025-02-10", reminderOffsets: [], isDemo: false };
    const events = calendarEventsForMonth({ monthKey: "2025-02", bills: [bill({ nextDueDate: "2025-02-05", recurrence: "none" })], debts: [debt], dates: [] });
    expect(events.map((event) => [event.type, event.dateKey])).toEqual([["bill", "2025-02-05"], ["debt", "2025-02-10"]]);
  });
});
