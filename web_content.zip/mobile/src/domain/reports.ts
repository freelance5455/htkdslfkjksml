export type ReportTransaction = {
  id: string;
  kind: "income" | "expense";
  categoryId: string | null;
  categoryName: string | null;
  amountMinor: string;
  currency: string;
  dateKey: string;
  note: string;
  isDemo: boolean;
};
export type ReportCategoryTotal = { categoryId: string | null; categoryName: string; amountMinor: string };
export type ReportDayTotal = { dateKey: string; incomeMinor: string; expenseMinor: string };
export type MonthlyReport = {
  monthKey: string;
  currency: string;
  incomeMinor: string;
  expenseMinor: string;
  balanceMinor: string;
  transactionCount: number;
  demoCount: number;
  categories: ReportCategoryTotal[];
  days: ReportDayTotal[];
};

export function aggregateMonthlyReport(monthKey: string, currency: string, rows: readonly ReportTransaction[]): MonthlyReport {
  let income = 0n;
  let expense = 0n;
  let demoCount = 0;
  const byCategory = new Map<string, { categoryId: string | null; categoryName: string; amount: bigint }>();
  const byDay = new Map<string, { income: bigint; expense: bigint }>();
  for (const row of rows) {
    const amount = BigInt(row.amountMinor);
    if (amount < 0n) throw new RangeError("Transaction amount cannot be negative.");
    if (row.kind === "income") income += amount;
    else expense += amount;
    if (row.isDemo) demoCount += 1;
    const day = byDay.get(row.dateKey) ?? { income: 0n, expense: 0n };
    if (row.kind === "income") day.income += amount;
    else day.expense += amount;
    byDay.set(row.dateKey, day);
    if (row.kind === "expense") {
      const key = row.categoryId ?? "__uncategorized__";
      const current = byCategory.get(key) ?? { categoryId: row.categoryId, categoryName: row.categoryName ?? "Other", amount: 0n };
      current.amount += amount;
      byCategory.set(key, current);
    }
  }
  const categories = [...byCategory.values()]
    .sort((a, b) => a.amount === b.amount ? a.categoryName.localeCompare(b.categoryName) : a.amount > b.amount ? -1 : 1)
    .map((row) => ({ categoryId: row.categoryId, categoryName: row.categoryName, amountMinor: row.amount.toString() }));
  const days = [...byDay.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([dateKey, totals]) => ({
    dateKey, incomeMinor: totals.income.toString(), expenseMinor: totals.expense.toString(),
  }));
  return {
    monthKey, currency, incomeMinor: income.toString(), expenseMinor: expense.toString(),
    balanceMinor: (income - expense).toString(), transactionCount: rows.length, demoCount, categories, days,
  };
}
