import * as Crypto from "expo-crypto";
import { addLocalDays, toLocalDateKey } from "../domain/dates";
import { decimalToMinorUnits } from "../domain/money";
import { addBill, addDebt, addTransaction } from "../db/repository";

function sampleAmounts(currency: string) {
  return currency === "UZS"
    ? { salary: "9200000", food: "185000", bill: "320000", debt: "1450000" }
    : { salary: "2400.00", food: "42.50", bill: "68.00", debt: "185.00" };
}

function amount(text: string, currency: string, fractionDigits: number): string {
  const result = decimalToMinorUnits(text, fractionDigits);
  if (result === null) throw new Error(`Invalid fictional sample amount for ${currency}.`);
  return result;
}

export async function addFictionalSampleData(currency: string, fractionDigits: number): Promise<void> {
  const today = toLocalDateKey();
  const values = sampleAmounts(currency);
  const examples = [
    { kind: "income" as const, categoryId: "income-salary", text: values.salary, note: "Fictional sample — monthly pay" },
    { kind: "expense" as const, categoryId: "expense-food", text: values.food, note: "Fictional sample — groceries" },
  ];
  for (const example of examples) {
    await addTransaction({
      kind: example.kind,
      categoryId: example.categoryId,
      amountMinor: amount(example.text, currency, fractionDigits),
      currency,
      dateKey: today,
      note: example.note,
      isDemo: true,
    });
  }
  const dueDate = addLocalDays(today, 3);
  const anchorDay = Number(dueDate.slice(8, 10));
  await addBill({
    id: `sample-bill-${Crypto.randomUUID()}`,
    title: "Fictional sample — household service",
    categoryId: "expense-home",
    amountMinor: amount(values.bill, currency, fractionDigits),
    currency,
    nextDueDate: dueDate,
    recurrence: "monthly",
    interval: 1,
    anchorDay,
    reminderOffsets: [3, 1, 0],
    isDemo: true,
  });
  const debtDueDate = addLocalDays(today, 28);
  await addDebt({
    id: `sample-debt-${Crypto.randomUUID()}`,
    direction: "borrowed",
    person: "Fictional sample counterparty",
    note: "Fictional sample — no real person or debt",
    principalMinor: amount(values.debt, currency, fractionDigits),
    currency,
    startDate: today,
    dueDate: debtDueDate,
    reminderOffsets: [3, 1, 0],
    isDemo: true,
  });
}
