import { Platform } from "react-native";
import * as Notifications from "expo-notifications";
import { reminderDateKeys, reminderTimeForDate } from "../domain/reminders";
import { t, type AppLanguage, type TranslationKeyType } from "../i18n";
import { listBills, listDebts, listImportantDates, readSetting, writeSetting } from "../db/repository";

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldPlaySound: true,
    shouldSetBadge: false,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

type ReminderKind = "bill" | "debt" | "date";

export async function requestLocalReminderPermission(): Promise<boolean> {
  if (Platform.OS !== "android" && Platform.OS !== "ios") return false;
  const before = await Notifications.getPermissionsAsync();
  const result = before.granted ? before : await Notifications.requestPermissionsAsync();
  if (!result.granted) return false;
  if (Platform.OS === "android") {
    await Notifications.setNotificationChannelAsync("reminders", {
      name: "TO‘LOVCHI reminders",
      importance: Notifications.AndroidImportance.DEFAULT,
      vibrationPattern: [0, 180, 100, 180],
      lightColor: "#14836d",
    });
  }
  return true;
}

export async function cancelEntityReminders(entityId: string): Promise<void> {
  if (Platform.OS !== "android" && Platform.OS !== "ios") return;
  const scheduled = await Notifications.getAllScheduledNotificationsAsync();
  await Promise.all(scheduled
    .filter((request) => request.content.data?.entityId === entityId)
    .map((request) => Notifications.cancelScheduledNotificationAsync(request.identifier)));
}

export async function scheduleEntityReminders(input: {
  entityId: string;
  kind: ReminderKind;
  dueDate: string;
  offsets: readonly number[];
  language: AppLanguage;
}): Promise<boolean> {
  if (!(await readSetting<boolean>("localRemindersEnabled", true))) return false;
  if (!(await requestLocalReminderPermission())) return false;
  await cancelEntityReminders(input.entityId);
  const key = `${input.kind}ReminderBody` as TranslationKeyType;
  const dates = reminderDateKeys(input.dueDate, input.offsets);
  for (const dateKey of dates) {
    const triggerDate = reminderTimeForDate(dateKey, new Date());
    if (!triggerDate) continue;
    await Notifications.scheduleNotificationAsync({
      content: {
        title: t(input.language, "appName"),
        body: t(input.language, key),
        data: { entityId: input.entityId, kind: input.kind },
        sound: "default",
      },
      trigger: {
        type: Notifications.SchedulableTriggerInputTypes.DATE,
        date: triggerDate,
        ...(Platform.OS === "android" ? { channelId: "reminders" } : {}),
      },
    });
  }
  return true;
}

export async function cancelAllLocalReminders(): Promise<void> {
  if (Platform.OS === "android" || Platform.OS === "ios") await Notifications.cancelAllScheduledNotificationsAsync();
}

export async function setLocalRemindersEnabled(enabled: boolean, language: AppLanguage): Promise<boolean> {
  if (enabled && !(await requestLocalReminderPermission())) return false;
  await writeSetting("localRemindersEnabled", enabled);
  if (!enabled) {
    await cancelAllLocalReminders();
    return true;
  }
  await rescheduleAllLocalReminders(language);
  return true;
}

export async function rescheduleAllLocalReminders(language: AppLanguage): Promise<void> {
  if (!(await readSetting<boolean>("localRemindersEnabled", true))) return;
  const [bills, debts, dates] = await Promise.all([listBills(), listDebts(), listImportantDates()]);
  await Promise.all([
    ...bills.map((bill) => scheduleEntityReminders({ entityId: bill.id, kind: "bill", dueDate: bill.nextDueDate, offsets: bill.reminderOffsets, language })),
    ...debts.filter((debt) => debt.dueDate).map((debt) => scheduleEntityReminders({ entityId: debt.id, kind: "debt", dueDate: debt.dueDate!, offsets: debt.reminderOffsets, language })),
    ...dates.filter((date) => (date.reminderOffsets?.length ?? 0) > 0).map((date) => scheduleEntityReminders({ entityId: date.id, kind: "date", dueDate: date.dateKey, offsets: date.reminderOffsets ?? [], language })),
  ]);
}
