import { Platform } from "react-native";
import * as Notifications from "expo-notifications";
import { nextReminderOccurrence, reminderDateKeys, reminderTimeForDate } from "../domain/reminders";
import { toLocalDateKey } from "../domain/dates";
import { t, type AppLanguage, type TranslationKeyType } from "../i18n";
import { listBills, listDebts, listImportantDates, readSetting, writeSetting } from "../db/repository";

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldPlaySound: true,
    shouldSetBadge: false,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

type ReminderKind = "bill" | "debt" | "date";

export async function requestLocalReminderPermission(): Promise<boolean> {
  if (Platform.OS !== "android" && Platform.OS !== "ios") return false;
  const before = await Notifications.getPermissionsAsync();
  const result = before.granted ? before : await Notifications.requestPermissionsAsync();
  if (!result.granted) return false;
  if (Platform.OS === "android") {
    await Notifications.setNotificationChannelAsync("reminders", {
      name: "TO‘LOVCHI reminders",
      importance: Notifications.AndroidImportance.DEFAULT,
      vibrationPattern: [0, 180, 100, 180],
      lightColor: "#14836d",
    });
  }
  return true;
}

export async function cancelEntityReminders(entityId: string): Promise<void> {
  if (Platform.OS !== "android" && Platform.OS !== "ios") return;
  const scheduled = await Notifications.getAllScheduledNotificationsAsync();
  await Promise.all(scheduled
    .filter((request) => request.content.data?.entityId === entityId)
    .map((request) => Notifications.cancelScheduledNotificationAsync(request.identifier)));
}

export async function scheduleEntityReminders(input: {
  entityId: string;
  kind: ReminderKind;
  dueDate: string;
  offsets: readonly number[];
  language: AppLanguage;
  repeatsYearly?: boolean;
  requestPermission?: boolean;
  allowDueTodayFallback?: boolean;
}): Promise<boolean> {
  if (!(await readSetting<boolean>("localRemindersEnabled", true))) return false;
  const permissionGranted = input.requestPermission === false
    ? (Platform.OS === "android" || Platform.OS === "ios") && (await Notifications.getPermissionsAsync()).granted
    : await requestLocalReminderPermission();
  if (!permissionGranted) return false;
  const dueDate = input.repeatsYearly ? nextReminderOccurrence(input.dueDate, true) : input.dueDate;
  const existing = await Notifications.getAllScheduledNotificationsAsync();
  const today = toLocalDateKey(new Date());
  const keepToday = input.allowDueTodayFallback === false
    ? new Set(existing.filter((request) => request.content.data?.entityId === input.entityId && request.content.data?.dateKey === today).map((request) => request.identifier))
    : new Set<string>();
  await Promise.all(existing
    .filter((request) => request.content.data?.entityId === input.entityId && !keepToday.has(request.identifier))
    .map((request) => Notifications.cancelScheduledNotificationAsync(request.identifier)));
  if (!dueDate) return true;
  const key = `${input.kind}ReminderBody` as TranslationKeyType;
  const dates = reminderDateKeys(dueDate, input.offsets);
  for (const dateKey of dates) {
    const triggerDate = reminderTimeForDate(dateKey, new Date(), input.allowDueTodayFallback ?? true);
    if (!triggerDate) continue;
    await Notifications.scheduleNotificationAsync({
      content: {
        title: t(input.language, "appName"),
        body: t(input.language, key),
        data: { entityId: input.entityId, kind: input.kind, dateKey },
        sound: "default",
      },
      trigger: {
        type: Notifications.SchedulableTriggerInputTypes.DATE,
        date: triggerDate,
        ...(Platform.OS === "android" ? { channelId: "reminders" } : {}),
      },
    });
  }
  return true;
}

export async function cancelAllLocalReminders(): Promise<void> {
  if (Platform.OS === "android" || Platform.OS === "ios") await Notifications.cancelAllScheduledNotificationsAsync();
}

export async function setLocalRemindersEnabled(enabled: boolean, language: AppLanguage): Promise<boolean> {
  if (enabled && !(await requestLocalReminderPermission())) return false;
  await writeSetting("localRemindersEnabled", enabled);
  if (!enabled) {
    await cancelAllLocalReminders();
    return true;
  }
  await rescheduleAllLocalReminders(language);
  return true;
}

export async function rescheduleAllLocalReminders(language: AppLanguage): Promise<void> {
  if (!(await readSetting<boolean>("localRemindersEnabled", true))) return;
  const [bills, debts, dates, zakatReminder] = await Promise.all([
    listBills(), listDebts(), listImportantDates(), readSetting<{ dateKey?: string; offsets?: number[] } | null>("zakatReminder", null),
  ]);
  const backgroundRefresh = { requestPermission: false, allowDueTodayFallback: false } as const;
  await Promise.all([
    ...bills.map((bill) => scheduleEntityReminders({ entityId: bill.id, kind: "bill", dueDate: bill.nextDueDate, offsets: bill.reminderOffsets, language, ...backgroundRefresh })),
    ...debts.filter((debt) => debt.dueDate && BigInt(debt.remainingMinor) > 0n).map((debt) => scheduleEntityReminders({ entityId: debt.id, kind: "debt", dueDate: debt.dueDate!, offsets: debt.reminderOffsets, language, ...backgroundRefresh })),
    ...dates.filter((date) => (date.reminderOffsets?.length ?? 0) > 0).map((date) => scheduleEntityReminders({ entityId: date.id, kind: "date", dueDate: date.dateKey, offsets: date.reminderOffsets ?? [], language, repeatsYearly: date.repeatsYearly, ...backgroundRefresh })),
    ...(zakatReminder?.dateKey && zakatReminder.offsets?.length ? [scheduleEntityReminders({ entityId: "zakat-annual", kind: "date", dueDate: zakatReminder.dateKey, offsets: zakatReminder.offsets, language, repeatsYearly: true, ...backgroundRefresh })] : []),
  ]);
}
