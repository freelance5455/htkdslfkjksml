import { describe, expect, it } from "vitest";
import { escapeHtml, makeMonthlyCsv, safeSpreadsheetCell } from "./reportSerialization";
import type { MonthlyReport, ReportTransaction } from "../domain/reports";

const report: MonthlyReport = {
  monthKey: "2026-05", currency: "UZS", incomeMinor: "0", expenseMinor: "0", balanceMinor: "0",
  transactionCount: 1, demoCount: 0, categories: [], days: [],
};
const row: ReportTransaction = {
  id: "1", kind: "expense", categoryId: "x", categoryName: "=HYPERLINK(\"x\")", amountMinor: "500", currency: "UZS",
  dateKey: "2026-05-01", note: "=cmd|/C calc", isDemo: false,
};
const labels = {
  date: "Date", kind: "Kind", category: "Category", amount: "Amount", currency: "Currency", note: "Note",
  income: "Income", expense: "Expense", month: "Month", totalIncome: "Total income", totalExpenses: "Total expenses",
  balance: "Balance", expenseBreakdown: "By category", day: "Day", demoNotice: "Sample", privateNotice: "Private",
};

describe("report export serialization", () => {
  it("prefixes spreadsheet formulas and quotes embedded delimiters", () => {
    expect(safeSpreadsheetCell("=1+1")).toBe("\"'=1+1\"");
    expect(safeSpreadsheetCell("Food, & drink")).toBe("\"Food, & drink\"");
  });
  it("protects user notes from formula execution when exported as CSV", () => {
    const csv = makeMonthlyCsv(report, [row], 0, labels);
    expect(csv.startsWith("\uFEFF")).toBe(true);
    expect(csv).toContain("\"'=HYPERLINK(" );
    expect(csv).toContain("\"'=cmd|/C calc\"");
  });
  it("escapes locally entered labels before embedding them in printable HTML", () => {
    expect(escapeHtml("<script a='x'>&\"" )).toBe("&lt;script a=&#39;x&#39;&gt;&amp;&quot;");
  });
});
