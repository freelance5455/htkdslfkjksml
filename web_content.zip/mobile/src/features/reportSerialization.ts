import { minorUnitsToDecimal } from "../domain/money";
import type { MonthlyReport } from "../domain/reports";
import type { ReportTransaction } from "../domain/reports";

export type ReportLabels = {
  date: string; kind: string; category: string; amount: string; currency: string; note: string;
  income: string; expense: string; month: string; totalIncome: string; totalExpenses: string;
  balance: string; expenseBreakdown: string; day: string; demoNotice: string; privateNotice: string;
};

export function safeSpreadsheetCell(value: string): string {
  const normalized = /^[\s]*[=+\-@\t\r]/.test(value) ? `'${value}` : value;
  return `"${normalized.replace(/"/g, '""')}"`;
}

export function makeMonthlyCsv(
  report: MonthlyReport,
  rows: readonly ReportTransaction[],
  digits: number,
  labels: ReportLabels,
): string {
  const lines: string[][] = [
    [labels.month, report.monthKey],
    [labels.currency, report.currency],
    [labels.totalIncome, minorUnitsToDecimal(report.incomeMinor, digits)],
    [labels.totalExpenses, minorUnitsToDecimal(report.expenseMinor, digits)],
    [labels.balance, minorUnitsToDecimal(report.balanceMinor, digits)],
    [],
    [labels.date, labels.kind, labels.category, labels.amount, labels.currency, labels.note],
    ...rows.map((row) => [
      row.dateKey, row.kind === "income" ? labels.income : labels.expense,
      row.categoryName ?? "", minorUnitsToDecimal(row.amountMinor, digits), row.currency, row.note,
    ]),
  ];
  return `\uFEFF${lines.map((line) => line.map(safeSpreadsheetCell).join(",")).join("\r\n")}`;
}

export function escapeHtml(value: string): string {
  return value.replace(/[&<>"']/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  })[character] ?? character);
}

export function makeMonthlyPdfHtml(
  report: MonthlyReport,
  digits: number,
  labels: ReportLabels & { title: string; report: string },
  formatAmount: (minor: string) => string,
): string {
  const categoryRows = report.categories.map((item) =>
    `<tr><td>${escapeHtml(item.categoryName)}</td><td class="amount">${escapeHtml(formatAmount(item.amountMinor))}</td></tr>`,
  ).join("");
  const dailyRows = report.days.map((item) =>
    `<tr><td>${escapeHtml(item.dateKey)}</td><td class="amount">${escapeHtml(minorUnitsToDecimal(item.incomeMinor, digits))}</td><td class="amount">${escapeHtml(minorUnitsToDecimal(item.expenseMinor, digits))}</td></tr>`,
  ).join("");
  const notice = report.demoCount > 0 ? `<p class="notice">${escapeHtml(labels.demoNotice)}</p>` : "";
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>
    body{font-family:Arial,sans-serif;color:#183029;padding:26px}h1{font-size:24px;margin:0 0 6px}h2{font-size:15px;margin:24px 0 8px;color:#145b4e}.meta{color:#53665e;font-size:12px}.summary{display:flex;gap:8px;flex-wrap:wrap;margin:18px 0}.tile{border:1px solid #dce7e1;border-radius:10px;padding:10px 12px;min-width:130px}.tile b{display:block;font-size:11px;color:#5a7067;margin-bottom:6px}.tile span{font-size:15px;font-weight:bold}.notice{background:#fff4dd;padding:10px;border-radius:8px;font-size:12px}table{width:100%;border-collapse:collapse;font-size:12px}th,td{border-bottom:1px solid #e3ebe6;padding:8px;text-align:left}th{color:#50645b}.amount{text-align:right;white-space:nowrap}.foot{margin-top:24px;color:#687b73;font-size:10px}
    </style></head><body><h1>${escapeHtml(labels.title)}</h1><div class="meta">${escapeHtml(labels.report)} · ${escapeHtml(report.monthKey)} · ${escapeHtml(report.currency)}</div>${notice}
    <div class="summary"><div class="tile"><b>${escapeHtml(labels.totalIncome)}</b><span>${escapeHtml(formatAmount(report.incomeMinor))}</span></div><div class="tile"><b>${escapeHtml(labels.totalExpenses)}</b><span>${escapeHtml(formatAmount(report.expenseMinor))}</span></div><div class="tile"><b>${escapeHtml(labels.balance)}</b><span>${escapeHtml(formatAmount(report.balanceMinor))}</span></div></div>
    <h2>${escapeHtml(labels.expenseBreakdown)}</h2><table><tbody>${categoryRows || `<tr><td colspan="2">—</td></tr>`}</tbody></table>
    <h2>${escapeHtml(labels.report)}</h2><table><thead><tr><th>${escapeHtml(labels.day)}</th><th class="amount">${escapeHtml(labels.income)}</th><th class="amount">${escapeHtml(labels.expense)}</th></tr></thead><tbody>${dailyRows || `<tr><td colspan="3">—</td></tr>`}</tbody></table>
    <p class="foot">${escapeHtml(labels.privateNotice)}</p></body></html>`;
}
