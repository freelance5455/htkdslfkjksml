import { gcm } from "@noble/ciphers/aes";
import { pbkdf2Async } from "@noble/hashes/pbkdf2";
import { sha256 } from "@noble/hashes/sha2";
import { bytesToUtf8, utf8ToBytes } from "@noble/hashes/utils";
import * as Crypto from "expo-crypto";

export const BACKUP_PASSPHRASE_MIN_LENGTH = 12;
export const BACKUP_MAX_PLAINTEXT_BYTES = 20 * 1024 * 1024;
export const BACKUP_MAX_FILE_CHARACTERS = 32 * 1024 * 1024;
const PBKDF2_ITERATIONS = 310_000;
const SALT_BYTES = 16;
const NONCE_BYTES = 12;
const KEY_BYTES = 32;
const AUTHENTICATED_DATA = utf8ToBytes("TOLOVCHI:encrypted-backup:v1");
const BASE64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
const BASE64_INDEX = new Int16Array(128).fill(-1);
for (let index = 0; index < BASE64.length; index += 1) BASE64_INDEX[BASE64.charCodeAt(index)] = index;

type BackupEnvelope = {
  app: "TOLOVCHI";
  formatVersion: 1;
  kdf: "PBKDF2-HMAC-SHA256";
  iterations: number;
  cipher: "AES-256-GCM";
  salt: string;
  nonce: string;
  ciphertext: string;
};

function bytesToBase64(bytes: Uint8Array): string {
  let result = "";
  for (let offset = 0; offset < bytes.length; offset += 3) {
    const first = bytes[offset] ?? 0;
    const second = bytes[offset + 1] ?? 0;
    const third = bytes[offset + 2] ?? 0;
    result += BASE64[first >> 2];
    result += BASE64[((first & 3) << 4) | (second >> 4)];
    result += offset + 1 < bytes.length ? BASE64[((second & 15) << 2) | (third >> 6)] : "=";
    result += offset + 2 < bytes.length ? BASE64[third & 63] : "=";
  }
  return result;
}

function base64ToBytes(value: string): Uint8Array {
  if (!value || value.length % 4 !== 0 || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(value)) {
    throw new Error("BACKUP_PASSWORD_OR_FILE_INVALID");
  }
  const padding = value.endsWith("==") ? 2 : value.endsWith("=") ? 1 : 0;
  const output = new Uint8Array((value.length / 4) * 3 - padding);
  let target = 0;
  for (let offset = 0; offset < value.length; offset += 4) {
    const chars = [value.charCodeAt(offset), value.charCodeAt(offset + 1), value.charCodeAt(offset + 2), value.charCodeAt(offset + 3)];
    const a = BASE64_INDEX[chars[0] ?? -1] ?? -1;
    const b = BASE64_INDEX[chars[1] ?? -1] ?? -1;
    const c = chars[2] === 61 ? 0 : BASE64_INDEX[chars[2] ?? -1] ?? -1;
    const d = chars[3] === 61 ? 0 : BASE64_INDEX[chars[3] ?? -1] ?? -1;
    if (a < 0 || b < 0 || c < 0 || d < 0) throw new Error("BACKUP_PASSWORD_OR_FILE_INVALID");
    if (target < output.length) output[target++] = (a << 2) | (b >> 4);
    if (target < output.length) output[target++] = ((b & 15) << 4) | (c >> 2);
    if (target < output.length) output[target++] = ((c & 3) << 6) | d;
  }
  return output;
}

function assertPassphrase(passphrase: string): void {
  if (passphrase.length < BACKUP_PASSPHRASE_MIN_LENGTH || passphrase.length > 256 || passphrase.includes("\u0000")) {
    throw new Error("BACKUP_PASSPHRASE_WEAK");
  }
}

async function deriveKey(passphrase: string, salt: Uint8Array): Promise<Uint8Array> {
  return pbkdf2Async(sha256, utf8ToBytes(passphrase), salt, {
    c: PBKDF2_ITERATIONS,
    dkLen: KEY_BYTES,
    asyncTick: 20,
  });
}

export async function encryptBackupPayload(payload: unknown, passphrase: string): Promise<string> {
  assertPassphrase(passphrase);
  const serialized = JSON.stringify(payload);
  if (!serialized) throw new Error("BACKUP_FILE_INVALID");
  const plaintext = utf8ToBytes(serialized);
  if (plaintext.length > BACKUP_MAX_PLAINTEXT_BYTES) throw new Error("BACKUP_FILE_TOO_LARGE");
  const salt = await Crypto.getRandomBytesAsync(SALT_BYTES);
  const nonce = await Crypto.getRandomBytesAsync(NONCE_BYTES);
  const key = await deriveKey(passphrase, salt);
  try {
    const ciphertext = gcm(key, nonce, AUTHENTICATED_DATA).encrypt(plaintext);
    const envelope: BackupEnvelope = {
      app: "TOLOVCHI",
      formatVersion: 1,
      kdf: "PBKDF2-HMAC-SHA256",
      iterations: PBKDF2_ITERATIONS,
      cipher: "AES-256-GCM",
      salt: bytesToBase64(salt),
      nonce: bytesToBase64(nonce),
      ciphertext: bytesToBase64(ciphertext),
    };
    return JSON.stringify(envelope);
  } finally {
    key.fill(0);
    plaintext.fill(0);
  }
}

function parseEnvelope(text: string): BackupEnvelope {
  if (text.length > BACKUP_MAX_FILE_CHARACTERS) throw new Error("BACKUP_FILE_TOO_LARGE");
  let parsed: unknown;
  try { parsed = JSON.parse(text); } catch { throw new Error("BACKUP_PASSWORD_OR_FILE_INVALID"); }
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error("BACKUP_PASSWORD_OR_FILE_INVALID");
  const candidate = parsed as Partial<BackupEnvelope>;
  if (candidate.app !== "TOLOVCHI" || candidate.formatVersion !== 1 || candidate.kdf !== "PBKDF2-HMAC-SHA256" || candidate.iterations !== PBKDF2_ITERATIONS || candidate.cipher !== "AES-256-GCM" || typeof candidate.salt !== "string" || typeof candidate.nonce !== "string" || typeof candidate.ciphertext !== "string") {
    throw new Error("BACKUP_PASSWORD_OR_FILE_INVALID");
  }
  return candidate as BackupEnvelope;
}

export async function decryptBackupPayload(encryptedFile: string, passphrase: string): Promise<unknown> {
  assertPassphrase(passphrase);
  const envelope = parseEnvelope(encryptedFile);
  const salt = base64ToBytes(envelope.salt);
  const nonce = base64ToBytes(envelope.nonce);
  const ciphertext = base64ToBytes(envelope.ciphertext);
  if (salt.length !== SALT_BYTES || nonce.length !== NONCE_BYTES || ciphertext.length < 16 || ciphertext.length > BACKUP_MAX_PLAINTEXT_BYTES + 16) {
    throw new Error("BACKUP_PASSWORD_OR_FILE_INVALID");
  }
  const key = await deriveKey(passphrase, salt);
  try {
    const plaintext = gcm(key, nonce, AUTHENTICATED_DATA).decrypt(ciphertext);
    if (plaintext.length > BACKUP_MAX_PLAINTEXT_BYTES) throw new Error("BACKUP_FILE_TOO_LARGE");
    try { return JSON.parse(bytesToUtf8(plaintext)) as unknown; }
    catch { throw new Error("BACKUP_PASSWORD_OR_FILE_INVALID"); }
    finally { plaintext.fill(0); }
  } catch {
    throw new Error("BACKUP_PASSWORD_OR_FILE_INVALID");
  } finally {
    key.fill(0);
  }
}
