import * as Crypto from "expo-crypto";
import * as LocalAuthentication from "expo-local-authentication";
import * as SecureStore from "expo-secure-store";
import { bytesToHex, hexToBytes } from "@noble/hashes/utils";
import { derivePinDigest } from "./pinKdf";

const STORAGE_KEY = "tolovchi.local-lock.v1";
const MAX_ATTEMPTS_BEFORE_WAIT = 5;
const INITIAL_WAIT_MS = 30_000;
const MAX_WAIT_MS = 15 * 60_000;

type PinRecord = {
  salt: string;
  digest: string;
  failedAttempts: number;
  blockedUntil: number;
  biometricEnabled: boolean;
};

export type PinVerification = { ok: boolean; retryAfterMs: number };

async function readRecord(): Promise<PinRecord | null> {
  const raw = await SecureStore.getItemAsync(STORAGE_KEY);
  if (!raw) return null;
  try {
    const value = JSON.parse(raw) as Partial<PinRecord>;
    if (typeof value.salt !== "string" || typeof value.digest !== "string") return null;
    return {
      salt: value.salt,
      digest: value.digest,
      failedAttempts: Number.isInteger(value.failedAttempts) ? Number(value.failedAttempts) : 0,
      blockedUntil: Number.isFinite(value.blockedUntil) ? Number(value.blockedUntil) : 0,
      biometricEnabled: value.biometricEnabled === true,
    };
  } catch {
    return null;
  }
}

async function writeRecord(value: PinRecord): Promise<void> {
  await SecureStore.setItemAsync(STORAGE_KEY, JSON.stringify(value));
}

function constantTimeEqual(leftHex: string, rightHex: string): boolean {
  let left: Uint8Array;
  let right: Uint8Array;
  try {
    left = hexToBytes(leftHex);
    right = hexToBytes(rightHex);
  } catch {
    return false;
  }
  if (left.length !== right.length) return false;
  let mismatch = 0;
  for (let index = 0; index < left.length; index += 1) mismatch |= left[index] ^ right[index];
  return mismatch === 0;
}

export async function hasAppPin(): Promise<boolean> {
  return (await readRecord()) !== null;
}

export async function isBiometricUnlockEnabled(): Promise<boolean> {
  return (await readRecord())?.biometricEnabled === true;
}

export async function setAppPin(pin: string, preserveBiometricUnlock = false): Promise<void> {
  if (!/^\d{6,12}$/.test(pin)) throw new Error("Choose a PIN with 6 to 12 digits.");
  const previousRecord = preserveBiometricUnlock ? await readRecord() : null;
  const salt = bytesToHex(await Crypto.getRandomBytesAsync(16));
  const digest = await derivePinDigest(pin, salt);
  await writeRecord({ salt, digest, failedAttempts: 0, blockedUntil: 0, biometricEnabled: previousRecord?.biometricEnabled === true });
}

export async function verifyAppPin(pin: string): Promise<PinVerification> {
  const record = await readRecord();
  if (!record) return { ok: false, retryAfterMs: 0 };
  const now = Date.now();
  if (record.blockedUntil > now) return { ok: false, retryAfterMs: record.blockedUntil - now };
  const digest = await derivePinDigest(pin, record.salt);
  if (constantTimeEqual(digest, record.digest)) {
    await writeRecord({ ...record, failedAttempts: 0, blockedUntil: 0 });
    return { ok: true, retryAfterMs: 0 };
  }
  const failedAttempts = record.failedAttempts + 1;
  const exponent = Math.min(Math.max(failedAttempts - MAX_ATTEMPTS_BEFORE_WAIT, 0), 5);
  const waitMs = failedAttempts < MAX_ATTEMPTS_BEFORE_WAIT ? 0 : Math.min(MAX_WAIT_MS, INITIAL_WAIT_MS * (2 ** exponent));
  await writeRecord({ ...record, failedAttempts, blockedUntil: waitMs > 0 ? now + waitMs : 0 });
  return { ok: false, retryAfterMs: waitMs };
}

export async function enableBiometricUnlock(enabled: boolean): Promise<void> {
  const record = await readRecord();
  if (!record) throw new Error("Set a PIN before enabling biometric unlock.");
  if (enabled) {
    const hardware = await LocalAuthentication.hasHardwareAsync();
    const enrolled = await LocalAuthentication.isEnrolledAsync();
    if (!hardware || !enrolled) throw new Error("Enroll a fingerprint or face unlock in Android Settings first.");
  }
  await writeRecord({ ...record, biometricEnabled: enabled });
}

export async function unlockWithBiometrics(): Promise<boolean> {
  if (!(await isBiometricUnlockEnabled())) return false;
  const result = await LocalAuthentication.authenticateAsync({
    promptMessage: "Unlock TO‘LOVCHI",
    fallbackLabel: "Use PIN",
    cancelLabel: "Cancel",
  });
  return result.success;
}

export async function removeAppPin(): Promise<void> {
  await SecureStore.deleteItemAsync(STORAGE_KEY);
}
