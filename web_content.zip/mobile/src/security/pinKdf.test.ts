import { describe, expect, it } from "vitest";
import { derivePinDigest, PIN_KDF_ITERATIONS } from "./pinKdf";

describe("local PIN KDF", () => {
  it("uses a strong PBKDF2 work factor and binds the digest to its salt", async () => {
    expect(PIN_KDF_ITERATIONS).toBeGreaterThanOrEqual(100_000);
    const first = await derivePinDigest("123456", "00112233445566778899aabbccddeeff");
    const sameSalt = await derivePinDigest("123456", "00112233445566778899aabbccddeeff");
    const otherSalt = await derivePinDigest("123456", "ffeeddccbbaa99887766554433221100");
    expect(first).toHaveLength(64);
    expect(first).toBe(sameSalt);
    expect(first).not.toBe(otherSalt);
  });
});
