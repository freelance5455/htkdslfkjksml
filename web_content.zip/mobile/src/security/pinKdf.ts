import { pbkdf2Async } from "@noble/hashes/pbkdf2";
import { sha256 } from "@noble/hashes/sha256";
import { bytesToHex, utf8ToBytes } from "@noble/hashes/utils";

export const PIN_KDF_ITERATIONS = 120_000;

export async function derivePinDigest(pin: string, saltHex: string): Promise<string> {
  const derived = await pbkdf2Async(sha256, utf8ToBytes(pin), utf8ToBytes(saltHex), {
    c: PIN_KDF_ITERATIONS,
    dkLen: 32,
    asyncTick: 128,
  });
  return bytesToHex(derived);
}
