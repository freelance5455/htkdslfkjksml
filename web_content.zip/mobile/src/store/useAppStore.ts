import { create } from 'zustand';

export interface MailboxItem {
  id: string;
  address: string;
  username: string;
  domain: string;
  expiresAt: string;
  unreadCount: number;
}

export interface PhoneNumberItem {
  id: string;
  number: string;
  countryCode: string;
  status: 'ACTIVE' | 'EXPIRING_SOON' | 'RELEASED';
  expiresAt: string;
  creditsCost: number;
  smsCount: number;
}

export interface AppState {
  token: string | null;
  userId: string | null;
  credits: number;
  isGuest: boolean;
  activeMailboxId: string | null;
  mailboxes: MailboxItem[];
  phoneNumbers: PhoneNumberItem[];
  darkMode: boolean;
  setAuth: (token: string, userId: string, isGuest: boolean, credits: number) => void;
  setCredits: (credits: number) => void;
  setMailboxes: (mailboxes: MailboxItem[]) => void;
  setActiveMailboxId: (id: string | null) => void;
  setPhoneNumbers: (numbers: PhoneNumberItem[]) => void;
  toggleDarkMode: () => void;
  reset: () => void;
}

export const useAppStore = create<AppState>((set) => ({
  token: null,
  userId: null,
  credits: 20,
  isGuest: true,
  activeMailboxId: null,
  mailboxes: [],
  phoneNumbers: [],
  darkMode: true,
  setAuth: (token, userId, isGuest, credits) =>
    set({ token, userId, isGuest, credits }),
  setCredits: (credits) => set({ credits }),
  setMailboxes: (mailboxes) =>
    set((state) => ({
      mailboxes,
      activeMailboxId: state.activeMailboxId || mailboxes[0]?.id || null,
    })),
  setActiveMailboxId: (activeMailboxId) => set({ activeMailboxId }),
  setPhoneNumbers: (phoneNumbers) => set({ phoneNumbers }),
  toggleDarkMode: () => set((state) => ({ darkMode: !state.darkMode })),
  reset: () =>
    set({
      token: null,
      userId: null,
      credits: 20,
      mailboxes: [],
      phoneNumbers: [],
      activeMailboxId: null,
    }),
}));
