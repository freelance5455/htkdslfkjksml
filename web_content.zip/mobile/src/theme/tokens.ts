export const palette = {
  emerald: "#14836d", emeraldDark: "#0e6a58", emeraldSoft: "#e3f2ec", ink: "#14221d", inkMuted: "#64736c",
  canvas: "#f7faf8", surface: "#ffffff", surfaceDark: "#17221e", line: "#e5ece8", navy: "#1c3650",
  amber: "#b16d16", amberSoft: "#fff2da", red: "#b83f3d", redSoft: "#fde9e7", white: "#ffffff",
} as const;
export type ThemeColors = { [key in keyof typeof palette]: string };
export const spacing = { xs: 4, sm: 8, md: 14, lg: 20, xl: 28, xxl: 40 } as const;
export const radius = { sm: 10, md: 16, lg: 22, pill: 999 } as const;
