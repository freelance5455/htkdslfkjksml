import * as Crypto from "expo-crypto";
import { isDateKey } from "../domain/dates";
import { rationalFxRate, type RationalFxRate } from "../domain/fxRates";
import { readyDatabase } from "./repositorySupport";

export type ManualFxRate = {
  id: string;
  baseCurrency: string;
  quoteCurrency: string;
  numerator: string;
  denominator: string;
  effectiveDate: string;
};

export async function saveManualFxRate(input: Omit<ManualFxRate, "id"> & { id?: string }): Promise<void> {
  const base = input.baseCurrency.trim().toUpperCase();
  const quote = input.quoteCurrency.trim().toUpperCase();
  if (!/^[A-Z0-9_-]{3,12}$/.test(base) || !/^[A-Z0-9_-]{3,12}$/.test(quote) || base === quote) throw new RangeError("Choose two different valid currencies.");
  if (!isDateKey(input.effectiveDate)) throw new RangeError("Rate date must be a valid YYYY-MM-DD date.");
  const rate = rationalFxRate(input.numerator, input.denominator);
  if (!rate) throw new RangeError("Enter positive integer numerator and denominator values.");
  const database = await readyDatabase();
  const id = input.id ?? Crypto.randomUUID();
  await database.runAsync(
    `INSERT INTO manual_fx_rates(id,base_currency,quote_currency,rate_numerator,rate_denominator,effective_date,created_at)
     VALUES(?,?,?,?,?,?,?) ON CONFLICT(base_currency,quote_currency,effective_date) DO UPDATE SET rate_numerator=excluded.rate_numerator,rate_denominator=excluded.rate_denominator`,
    [id, base, quote, rate.numerator, rate.denominator, input.effectiveDate, new Date().toISOString()],
  );
}

export async function listManualFxRates(): Promise<ManualFxRate[]> {
  const database = await readyDatabase();
  const rows = await database.getAllAsync<Record<string, unknown>>(
    "SELECT id,base_currency,quote_currency,rate_numerator,rate_denominator,effective_date FROM manual_fx_rates ORDER BY effective_date DESC,base_currency,quote_currency",
  );
  return rows.map((row) => ({
    id: String(row.id), baseCurrency: String(row.base_currency), quoteCurrency: String(row.quote_currency),
    numerator: String(row.rate_numerator), denominator: String(row.rate_denominator), effectiveDate: String(row.effective_date),
  }));
}

export async function deleteManualFxRate(id: string): Promise<void> {
  const database = await readyDatabase();
  await database.runAsync("DELETE FROM manual_fx_rates WHERE id=?", [id]);
}

export async function findManualFxRate(baseCurrency: string, quoteCurrency: string, onDate: string): Promise<RationalFxRate | null> {
  const base = baseCurrency.toUpperCase(), quote = quoteCurrency.toUpperCase();
  if (!isDateKey(onDate) || base === quote) return null;
  const database = await readyDatabase();
  const direct = await database.getFirstAsync<{ rate_numerator: string; rate_denominator: string }>(
    "SELECT rate_numerator,rate_denominator FROM manual_fx_rates WHERE base_currency=? AND quote_currency=? AND effective_date<=? ORDER BY effective_date DESC,created_at DESC LIMIT 1",
    [base, quote, onDate],
  );
  if (direct) return rationalFxRate(String(direct.rate_numerator), String(direct.rate_denominator));
  const inverse = await database.getFirstAsync<{ rate_numerator: string; rate_denominator: string }>(
    "SELECT rate_numerator,rate_denominator FROM manual_fx_rates WHERE base_currency=? AND quote_currency=? AND effective_date<=? ORDER BY effective_date DESC,created_at DESC LIMIT 1",
    [quote, base, onDate],
  );
  return inverse ? rationalFxRate(String(inverse.rate_denominator), String(inverse.rate_numerator)) : null;
}
