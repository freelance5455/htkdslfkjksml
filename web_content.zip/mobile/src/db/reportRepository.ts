import { aggregateMonthlyReport, type MonthlyReport, type ReportTransaction } from "../domain/reports";
import { readyDatabase } from "./repositorySupport";

function monthRange(monthKey: string): [string, string] {
  const match = /^(\d{4})-(0[1-9]|1[0-2])$/.exec(monthKey);
  if (!match) throw new RangeError("Month must use YYYY-MM format.");
  const year = Number(match[1]);
  const month = Number(match[2]);
  const nextYear = month === 12 ? year + 1 : year;
  const nextMonth = month === 12 ? 1 : month + 1;
  return [`${monthKey}-01`, `${nextYear}-${String(nextMonth).padStart(2, "0")}-01`];
}

export async function getReportTransactions(monthKey: string, currency: string): Promise<ReportTransaction[]> {
  const [from, until] = monthRange(monthKey);
  if (!/^[A-Z0-9_-]{3,12}$/.test(currency)) throw new RangeError("Currency code is invalid.");
  const database = await readyDatabase();
  const rows = await database.getAllAsync<Record<string, unknown>>(
    `SELECT t.id,t.kind,t.category_id,t.amount_minor,t.currency,t.date_key,t.note,t.is_demo,c.name AS category_name
     FROM transactions t LEFT JOIN categories c ON c.id=t.category_id
     WHERE t.date_key>=? AND t.date_key<? AND t.currency=? ORDER BY t.date_key,t.created_at,t.id`,
    [from, until, currency],
  );
  return rows.map((row) => ({
    id: String(row.id), kind: row.kind as ReportTransaction["kind"],
    categoryId: row.category_id == null ? null : String(row.category_id),
    categoryName: row.category_name == null ? null : String(row.category_name),
    amountMinor: String(row.amount_minor), currency: String(row.currency), dateKey: String(row.date_key),
    note: String(row.note ?? ""), isDemo: Number(row.is_demo) === 1,
  }));
}

export async function getMonthlyReport(monthKey: string, currency: string): Promise<MonthlyReport> {
  return aggregateMonthlyReport(monthKey, currency, await getReportTransactions(monthKey, currency));
}
