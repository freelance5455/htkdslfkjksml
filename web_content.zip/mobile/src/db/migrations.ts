import type * as SQLite from "expo-sqlite";

const MIGRATIONS: readonly { version: number; sql: string }[] = [
  { version: 1, sql: `
    CREATE TABLE IF NOT EXISTS app_settings (key TEXT PRIMARY KEY NOT NULL,value TEXT NOT NULL,updated_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS categories (id TEXT PRIMARY KEY NOT NULL,name TEXT NOT NULL,kind TEXT NOT NULL CHECK(kind IN ('income','expense')),color TEXT NOT NULL,is_default INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS transactions (
      id TEXT PRIMARY KEY NOT NULL,kind TEXT NOT NULL CHECK(kind IN ('income','expense')),category_id TEXT REFERENCES categories(id) ON DELETE SET NULL,
      amount_minor TEXT NOT NULL CHECK(length(amount_minor)>0),currency TEXT NOT NULL CHECK(length(currency) BETWEEN 3 AND 12),
      date_key TEXT NOT NULL CHECK(date(date_key) IS NOT NULL),note TEXT NOT NULL DEFAULT '',source_type TEXT NOT NULL DEFAULT 'manual',source_id TEXT,
      is_demo INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL,updated_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS transactions_date_idx ON transactions(date_key DESC);
    CREATE INDEX IF NOT EXISTS transactions_kind_date_idx ON transactions(kind,date_key DESC);
    CREATE TABLE IF NOT EXISTS bills (
      id TEXT PRIMARY KEY NOT NULL,title TEXT NOT NULL,category_id TEXT REFERENCES categories(id) ON DELETE SET NULL,
      amount_minor TEXT NOT NULL,currency TEXT NOT NULL,next_due_date TEXT NOT NULL CHECK(date(next_due_date) IS NOT NULL),
      recurrence TEXT NOT NULL CHECK(recurrence IN ('none','daily','weekly','monthly','yearly')),interval INTEGER NOT NULL DEFAULT 1 CHECK(interval BETWEEN 1 AND 120),
      anchor_day INTEGER NOT NULL CHECK(anchor_day BETWEEN 1 AND 31),reminder_offsets TEXT NOT NULL DEFAULT '[3,1,0]',is_active INTEGER NOT NULL DEFAULT 1,
      is_demo INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL,updated_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS bills_due_idx ON bills(is_active,next_due_date);
    CREATE TABLE IF NOT EXISTS bill_payments (
      id TEXT PRIMARY KEY NOT NULL,bill_id TEXT NOT NULL REFERENCES bills(id) ON DELETE CASCADE,occurrence_date TEXT NOT NULL,
      paid_date TEXT NOT NULL CHECK(date(paid_date) IS NOT NULL),amount_minor TEXT NOT NULL,currency TEXT NOT NULL,
      transaction_id TEXT NOT NULL REFERENCES transactions(id) ON DELETE RESTRICT,created_at TEXT NOT NULL,UNIQUE(bill_id,occurrence_date)
    );
    CREATE TABLE IF NOT EXISTS debts (
      id TEXT PRIMARY KEY NOT NULL,direction TEXT NOT NULL CHECK(direction IN ('lent','borrowed')),person TEXT NOT NULL,note TEXT NOT NULL DEFAULT '',
      principal_minor TEXT NOT NULL,currency TEXT NOT NULL,start_date TEXT NOT NULL CHECK(date(start_date) IS NOT NULL),
      due_date TEXT CHECK(due_date IS NULL OR date(due_date) IS NOT NULL),reminder_offsets TEXT NOT NULL DEFAULT '[3,1,0]',
      is_demo INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL,updated_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS debts_due_idx ON debts(due_date);
    CREATE TABLE IF NOT EXISTS debt_repayments (
      id TEXT PRIMARY KEY NOT NULL,debt_id TEXT NOT NULL REFERENCES debts(id) ON DELETE CASCADE,amount_minor TEXT NOT NULL,
      date_key TEXT NOT NULL CHECK(date(date_key) IS NOT NULL),note TEXT NOT NULL DEFAULT '',transaction_id TEXT NOT NULL REFERENCES transactions(id) ON DELETE RESTRICT,created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS debt_repayments_debt_idx ON debt_repayments(debt_id,date_key);
    CREATE TABLE IF NOT EXISTS budgets (
      id TEXT PRIMARY KEY NOT NULL,month_key TEXT NOT NULL CHECK(length(month_key)=7),category_id TEXT NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
      limit_minor TEXT NOT NULL,currency TEXT NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL,UNIQUE(month_key,category_id,currency)
    );
    CREATE TABLE IF NOT EXISTS important_dates (
      id TEXT PRIMARY KEY NOT NULL,title TEXT NOT NULL,date_key TEXT NOT NULL CHECK(date(date_key) IS NOT NULL),repeats_yearly INTEGER NOT NULL DEFAULT 0,
      note TEXT NOT NULL DEFAULT '',reminder_offsets TEXT NOT NULL DEFAULT '[]',is_demo INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL,updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS notification_links (
      id TEXT PRIMARY KEY NOT NULL,entity_type TEXT NOT NULL,entity_id TEXT NOT NULL,occurrence_key TEXT NOT NULL,offset_days INTEGER NOT NULL,
      notification_id TEXT NOT NULL,scheduled_for TEXT NOT NULL,UNIQUE(entity_type,entity_id,occurrence_key,offset_days)
    );
    CREATE TABLE IF NOT EXISTS zakat_profiles (
      id TEXT PRIMARY KEY NOT NULL,label TEXT NOT NULL,calculation_date TEXT NOT NULL CHECK(date(calculation_date) IS NOT NULL),currency TEXT NOT NULL,
      method TEXT NOT NULL DEFAULT 'hanafi-configurable',input_json TEXT NOT NULL,haul_confirmed INTEGER NOT NULL DEFAULT 0,
      nisab_confirmed INTEGER NOT NULL DEFAULT 0,reminder_date TEXT,created_at TEXT NOT NULL,updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS manual_fx_rates (
      id TEXT PRIMARY KEY NOT NULL,base_currency TEXT NOT NULL,quote_currency TEXT NOT NULL,rate_numerator TEXT NOT NULL,rate_denominator TEXT NOT NULL,
      effective_date TEXT NOT NULL CHECK(date(effective_date) IS NOT NULL),created_at TEXT NOT NULL,UNIQUE(base_currency,quote_currency,effective_date)
    );
    CREATE INDEX IF NOT EXISTS transactions_category_date_idx ON transactions(category_id,date_key);
    PRAGMA user_version = 1;
  ` },
];

export async function migrateLocalDatabase(database: SQLite.SQLiteDatabase): Promise<void> {
  const current = await database.getFirstAsync<{ user_version: number }>("PRAGMA user_version;");
  const version = current?.user_version ?? 0;
  for (const migration of MIGRATIONS) {
    if (migration.version <= version) continue;
    await database.withExclusiveTransactionAsync(async (transaction) => {
      await transaction.execAsync(migration.sql);
    });
  }
}
export const LOCAL_SCHEMA_VERSION = MIGRATIONS.at(-1)?.version ?? 0;
