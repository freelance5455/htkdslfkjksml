import type * as SQLite from "expo-sqlite";

export async function ensureDefaultCategoriesForDatabase(db: SQLite.SQLiteDatabase): Promise<void> {
  const rows = [
    ["income-salary","Salary","income","#14836d"],
    ["income-other","Other income","income","#478e7f"],
    ["expense-home","Home & utilities","expense","#557c9b"],
    ["expense-food","Food","expense","#7b8e58"],
    ["expense-transport","Transport","expense","#826fa6"],
    ["expense-health","Health","expense","#bf765f"],
    ["expense-family","Family","expense","#ba8a42"],
    ["expense-other","Other","expense","#708078"],
  ] as const;
  const now = new Date().toISOString();
  for (const [id,name,kind,color] of rows) {
    await db.runAsync("INSERT OR IGNORE INTO categories(id,name,kind,color,is_default,created_at) VALUES(?,?,?,?,1,?)",[id,name,kind,color,now]);
  }
}
