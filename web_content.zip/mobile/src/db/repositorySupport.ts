import { ensureDefaultCategoriesForDatabase } from "./seed";
import { migrateLocalDatabase } from "./migrations";
import { openEncryptedDatabase } from "./database";
import * as SQLite from "expo-sqlite";

let readyPromise: Promise<SQLite.SQLiteDatabase> | null = null;
export async function readyDatabase(): Promise<SQLite.SQLiteDatabase> {
  if (!readyPromise) {
    readyPromise = (async () => {
      const db = await openEncryptedDatabase();
      await migrateLocalDatabase(db);
      await ensureDefaultCategoriesForDatabase(db);
      return db;
    })().catch((error) => { readyPromise = null; throw error; });
  }
  return readyPromise;
}
