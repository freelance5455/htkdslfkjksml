import * as Crypto from "expo-crypto";
import { addLocalDays, nextOccurrence, toLocalDateKey } from "../domain/dates";
import type { Bill, Budget, Category, Debt, ImportantDate, MonthlySummary, Repayment, Transaction } from "../domain/types";
import { readyDatabase } from "./repositorySupport";

const nowIso = () => new Date().toISOString();
const id = () => Crypto.randomUUID();
const toJson = (value: unknown) => JSON.stringify(value);

export async function ensureDefaultCategories(): Promise<void> {
  const database = await readyDatabase();
  const createdAt = nowIso();
  const defaults: Category[] = [
    { id: "income-salary", name: "Salary", kind: "income", color: "#14836d", isDefault: true },
    { id: "income-other", name: "Other income", kind: "income", color: "#478e7f", isDefault: true },
    { id: "expense-home", name: "Home & utilities", kind: "expense", color: "#557c9b", isDefault: true },
    { id: "expense-food", name: "Food", kind: "expense", color: "#7b8e58", isDefault: true },
    { id: "expense-transport", name: "Transport", kind: "expense", color: "#826fa6", isDefault: true },
    { id: "expense-health", name: "Health", kind: "expense", color: "#bf765f", isDefault: true },
    { id: "expense-family", name: "Family", kind: "expense", color: "#ba8a42", isDefault: true },
    { id: "expense-other", name: "Other", kind: "expense", color: "#708078", isDefault: true },
  ];
  await database.withExclusiveTransactionAsync(async (tx) => {
    for (const item of defaults) await tx.runAsync(
      "INSERT OR IGNORE INTO categories(id,name,kind,color,is_default,created_at) VALUES(?,?,?,?,?,?)",
      [item.id, item.name, item.kind, item.color, 1, createdAt],
    );
  });
}

export async function listCategories(kind?: "income" | "expense"): Promise<Category[]> {
  const database = await readyDatabase();
  const rows = kind
    ? await database.getAllAsync<{ id: string; name: string; kind: "income" | "expense"; color: string; is_default: number }>("SELECT id,name,kind,color,is_default FROM categories WHERE kind=? ORDER BY is_default DESC,name", [kind])
    : await database.getAllAsync<{ id: string; name: string; kind: "income" | "expense"; color: string; is_default: number }>("SELECT id,name,kind,color,is_default FROM categories ORDER BY kind,is_default DESC,name");
  return rows.map((row) => ({ id: row.id, name: row.name, kind: row.kind, color: row.color, isDefault: row.is_default === 1 }));
}

export async function addCategory(input: Omit<Category, "isDefault">): Promise<void> {
  const database = await readyDatabase();
  await database.runAsync("INSERT INTO categories(id,name,kind,color,is_default,created_at) VALUES(?,?,?,?,0,?)", [input.id, input.name.trim(), input.kind, input.color, nowIso()]);
}

export async function deleteCategory(categoryId: string): Promise<void> {
  const database = await readyDatabase();
  await database.runAsync("DELETE FROM categories WHERE id=? AND is_default=0", [categoryId]);
}

export async function addTransaction(input: Omit<Transaction, "id" | "createdAt" | "isDemo"> & { isDemo?: boolean }): Promise<string> {
  const database = await readyDatabase();
  const transactionId = id();
  const now = nowIso();
  await database.runAsync(
    `INSERT INTO transactions(id,kind,category_id,amount_minor,currency,date_key,note,source_type,source_id,is_demo,created_at,updated_at)
     VALUES(?,?,?,?,?,?,?,'manual',NULL,?,?,?)`,
    [transactionId,input.kind,input.categoryId,input.amountMinor,input.currency,input.dateKey,input.note.trim(),input.isDemo?1:0,now,now],
  );
  return transactionId;
}

export async function listTransactions(options: { kind?: "income" | "expense"; monthKey?: string; search?: string; limit?: number } = {}): Promise<Transaction[]> {
  const database = await readyDatabase();
  const clauses: string[] = [];
  const params: (string | number)[] = [];
  if (options.kind) { clauses.push("kind=?"); params.push(options.kind); }
  if (options.monthKey) { clauses.push("date_key>=? AND date_key<?"); params.push(`${options.monthKey}-01`, nextMonthKey(options.monthKey)); }
  if (options.search?.trim()) { clauses.push("(note LIKE ? OR category_id IN (SELECT id FROM categories WHERE name LIKE ?))"); params.push(`%${options.search.trim()}%`, `%${options.search.trim()}%`); }
  const limit = Math.max(1,Math.min(options.limit??100,500));
  const rows = await database.getAllAsync<Record<string,unknown>>(
    `SELECT id,kind,category_id,amount_minor,currency,date_key,note,is_demo,created_at FROM transactions ${clauses.length?`WHERE ${clauses.join(" AND ")}`:""} ORDER BY date_key DESC,created_at DESC LIMIT ?`,[...params,limit],
  );
  return rows.map((row)=>({id:String(row.id),kind:row.kind as "income"|"expense",categoryId:row.category_id?String(row.category_id):null,amountMinor:String(row.amount_minor),currency:String(row.currency),dateKey:String(row.date_key),note:String(row.note??""),isDemo:Number(row.is_demo)===1,createdAt:String(row.created_at)}));
}

export async function deleteTransaction(transactionId: string): Promise<void> {
  const database = await readyDatabase();
  await database.runAsync("DELETE FROM transactions WHERE id=? AND source_type='manual'",[transactionId]);
}

export async function monthlySummary(monthKey: string,currency:string):Promise<MonthlySummary>{
  const database=await readyDatabase();
  const rows=await database.getAllAsync<{kind:"income"|"expense";amount_minor:string}>("SELECT kind,amount_minor FROM transactions WHERE date_key>=? AND date_key<? AND currency=?",[`${monthKey}-01`,nextMonthKey(monthKey),currency]);
  const income=rows.filter((x)=>x.kind==="income").reduce((s,x)=>s+BigInt(x.amount_minor),0n);
  const expense=rows.filter((x)=>x.kind==="expense").reduce((s,x)=>s+BigInt(x.amount_minor),0n);
  return {currency,incomeMinor:income.toString(),expenseMinor:expense.toString(),balanceMinor:(income-expense).toString()};
}

function nextMonthKey(monthKey:string):string{
  const match=/^(\d{4})-(0[1-9]|1[0-2])$/.exec(monthKey);if(!match)throw new RangeError("Month must use YYYY-MM format.");
  const year=Number(match[1]),month=Number(match[2]);return month===12?`${year+1}-01`:`${year}-${String(month+1).padStart(2,"0")}`;
}

export async function addBill(input:Omit<Bill,"isActive"|"isDemo">&{isDemo?:boolean}):Promise<void>{
  const database=await readyDatabase(),now=nowIso();
  await database.runAsync(`INSERT INTO bills(id,title,category_id,amount_minor,currency,next_due_date,recurrence,interval,anchor_day,reminder_offsets,is_active,is_demo,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,1,?,?,?)`,
    [input.id,input.title.trim(),input.categoryId,input.amountMinor,input.currency,input.nextDueDate,input.recurrence,input.interval,input.anchorDay,toJson(input.reminderOffsets),input.isDemo?1:0,now,now]);
}

export async function listBills(activeOnly=true):Promise<Bill[]>{
  const database=await readyDatabase();const rows=await database.getAllAsync<Record<string,unknown>>(`SELECT * FROM bills ${activeOnly?"WHERE is_active=1":""} ORDER BY next_due_date`);
  return rows.map((row)=>({id:String(row.id),title:String(row.title),categoryId:row.category_id?String(row.category_id):null,amountMinor:String(row.amount_minor),currency:String(row.currency),nextDueDate:String(row.next_due_date),recurrence:row.recurrence as Bill["recurrence"],interval:Number(row.interval),anchorDay:Number(row.anchor_day),reminderOffsets:parseNumberArray(row.reminder_offsets),isActive:Number(row.is_active)===1,isDemo:Number(row.is_demo)===1}));
}

export async function markBillPaid(billId:string,paidDate=toLocalDateKey()):Promise<void>{
  const database=await readyDatabase();
  await database.withExclusiveTransactionAsync(async(tx)=>{
    const bill=await tx.getFirstAsync<Record<string,unknown>>("SELECT * FROM bills WHERE id=? AND is_active=1",[billId]);if(!bill)throw new Error("This bill is no longer active.");
    const occurrence=String(bill.next_due_date),now=nowIso(),transactionId=id();
    const categoryId=bill.category_id==null?null:String(bill.category_id);
    const amountMinor=String(bill.amount_minor),currency=String(bill.currency),title=String(bill.title);
    const demoFlag=Number(bill.is_demo)===1?1:0;
    await tx.runAsync(`INSERT INTO transactions(id,kind,category_id,amount_minor,currency,date_key,note,source_type,source_id,is_demo,created_at,updated_at) VALUES(?,'expense',?,?,?,?,?,'bill',?,?,?,?)`,
      [transactionId,categoryId,amountMinor,currency,paidDate,`Paid: ${title}`,billId,demoFlag,now,now]);
    await tx.runAsync("INSERT INTO bill_payments(id,bill_id,occurrence_date,paid_date,amount_minor,currency,transaction_id,created_at) VALUES(?,?,?,?,?,?,?,?)",
      [id(),billId,occurrence,paidDate,amountMinor,currency,transactionId,now]);
    const recurrence=String(bill.recurrence),next=nextOccurrence(occurrence,recurrence as Bill["recurrence"],Number(bill.interval),Number(bill.anchor_day));
    if(next)await tx.runAsync("UPDATE bills SET next_due_date=?,updated_at=? WHERE id=?",[next,now,billId]);
    else await tx.runAsync("UPDATE bills SET is_active=0,updated_at=? WHERE id=?",[now,billId]);
  });
}

function parseNumberArray(value:unknown):number[]{try{const parsed=JSON.parse(String(value??"[]"));return Array.isArray(parsed)?parsed.filter((item)=>Number.isInteger(item)&&item>=0&&item<=365):[]}catch{return[]}}
export async function deleteBill(billId:string):Promise<void>{const database=await readyDatabase();await database.runAsync("DELETE FROM bills WHERE id=?",[billId]);}

export async function addDebt(input:Omit<Debt,"isDemo">&{isDemo?:boolean}):Promise<void>{
  const database=await readyDatabase(),now=nowIso();
  await database.runAsync("INSERT INTO debts(id,direction,person,note,principal_minor,currency,start_date,due_date,reminder_offsets,is_demo,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
    [input.id,input.direction,input.person.trim(),input.note.trim(),input.principalMinor,input.currency,input.startDate,input.dueDate,toJson(input.reminderOffsets),input.isDemo?1:0,now,now]);
}

export async function listDebts():Promise<Array<Debt&{repaidMinor:string;remainingMinor:string}>>{
  const database=await readyDatabase();const rows=await database.getAllAsync<Record<string,unknown>>(`SELECT d.*,COALESCE(SUM(CAST(r.amount_minor AS INTEGER)),0) AS repaid_minor FROM debts d LEFT JOIN debt_repayments r ON r.debt_id=d.id GROUP BY d.id ORDER BY CASE WHEN d.due_date IS NULL THEN 1 ELSE 0 END,d.due_date`);
  return rows.map((row)=>{const principal=BigInt(String(row.principal_minor)),repaid=BigInt(String(row.repaid_minor));return{id:String(row.id),direction:row.direction as Debt["direction"],person:String(row.person),note:String(row.note),principalMinor:principal.toString(),currency:String(row.currency),startDate:String(row.start_date),dueDate:row.due_date?String(row.due_date):null,reminderOffsets:parseNumberArray(row.reminder_offsets),isDemo:Number(row.is_demo)===1,repaidMinor:repaid.toString(),remainingMinor:(principal>repaid?principal-repaid:0n).toString()}});
}

export async function listRepayments(debtId:string):Promise<Repayment[]>{
  const database=await readyDatabase();const rows=await database.getAllAsync<Record<string,unknown>>("SELECT id,debt_id,amount_minor,date_key,note FROM debt_repayments WHERE debt_id=? ORDER BY date_key DESC,created_at DESC",[debtId]);
  return rows.map((row)=>({id:String(row.id),debtId:String(row.debt_id),amountMinor:String(row.amount_minor),dateKey:String(row.date_key),note:String(row.note)}));
}

export async function addRepayment(debtId:string,amountMinor:string,dateKey=toLocalDateKey(),note=""):Promise<void>{
  const database=await readyDatabase();await database.withExclusiveTransactionAsync(async(tx)=>{
    const debt=await tx.getFirstAsync<Record<string,unknown>>("SELECT d.*,COALESCE(SUM(CAST(r.amount_minor AS INTEGER)),0) AS repaid_minor FROM debts d LEFT JOIN debt_repayments r ON r.debt_id=d.id WHERE d.id=? GROUP BY d.id",[debtId]);
    if(!debt)throw new Error("This debt record no longer exists.");const amount=BigInt(amountMinor),remaining=BigInt(String(debt.principal_minor))-BigInt(String(debt.repaid_minor));
    if(amount<=0n||amount>remaining)throw new Error("Repayment must be positive and no greater than the remaining balance.");
    const now=nowIso(),transactionId=id(),repaymentId=id(),kind=String(debt.direction)==="lent"?"income":"expense";
    const currency=String(debt.currency),person=String(debt.person),demoFlag=Number(debt.is_demo)===1?1:0;
    await tx.runAsync("INSERT INTO transactions(id,kind,category_id,amount_minor,currency,date_key,note,source_type,source_id,is_demo,created_at,updated_at) VALUES(?,?,NULL,?,?,?,?,'debt_repayment',?,?,?,?)",
      [transactionId,kind,amount.toString(),currency,dateKey,`Debt repayment: ${person}`,debtId,demoFlag,now,now]);
    await tx.runAsync("INSERT INTO debt_repayments(id,debt_id,amount_minor,date_key,note,transaction_id,created_at) VALUES(?,?,?,?,?,?,?)",[repaymentId,debtId,amount.toString(),dateKey,note.trim(),transactionId,now]);
  });
}

export async function deleteDebt(debtId: string): Promise<void> {
  const database = await readyDatabase();
  await database.withExclusiveTransactionAsync(async (tx) => {
    await tx.runAsync("DELETE FROM transactions WHERE source_type='debt_repayment' AND source_id=?", [debtId]);
    await tx.runAsync("DELETE FROM debt_repayments WHERE debt_id=?", [debtId]);
    await tx.runAsync("DELETE FROM debts WHERE id=?", [debtId]);
  });
}

export async function addBudget(input:Budget):Promise<void>{const database=await readyDatabase(),now=nowIso();await database.runAsync("INSERT INTO budgets(id,month_key,category_id,limit_minor,currency,created_at,updated_at) VALUES(?,?,?,?,?,?,?) ON CONFLICT(month_key,category_id,currency) DO UPDATE SET limit_minor=excluded.limit_minor,updated_at=excluded.updated_at",[input.id,input.monthKey,input.categoryId,input.limitMinor,input.currency,now,now]);}
export async function listBudgets(monthKey:string,currency:string):Promise<Array<Budget&{spentMinor:string}>>{
  const database=await readyDatabase();const rows=await database.getAllAsync<Record<string,unknown>>("SELECT b.*,COALESCE(SUM(CAST(t.amount_minor AS INTEGER)),0) AS spent_minor FROM budgets b LEFT JOIN transactions t ON t.category_id=b.category_id AND t.currency=b.currency AND t.kind='expense' AND t.date_key>=? AND t.date_key<? WHERE b.month_key=? AND b.currency=? GROUP BY b.id ORDER BY b.category_id",[`${monthKey}-01`,nextMonthKey(monthKey),monthKey,currency]);
  return rows.map((row)=>({id:String(row.id),monthKey:String(row.month_key),categoryId:String(row.category_id),limitMinor:String(row.limit_minor),currency:String(row.currency),spentMinor:String(row.spent_minor)}));
}
export async function deleteBudget(budgetId: string): Promise<void> {
  const database = await readyDatabase();
  await database.runAsync("DELETE FROM budgets WHERE id=?", [budgetId]);
}

export async function addImportantDate(input:ImportantDate&{reminderOffsets:number[]}):Promise<void>{const database=await readyDatabase(),now=nowIso();await database.runAsync("INSERT INTO important_dates(id,title,date_key,repeats_yearly,note,reminder_offsets,is_demo,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",[input.id,input.title.trim(),input.dateKey,input.repeatsYearly?1:0,input.note.trim(),toJson(input.reminderOffsets),input.isDemo?1:0,now,now]);}
export async function listImportantDates():Promise<ImportantDate[]>{const database=await readyDatabase();const rows=await database.getAllAsync<Record<string,unknown>>("SELECT * FROM important_dates ORDER BY date_key");return rows.map((row)=>({id:String(row.id),title:String(row.title),dateKey:String(row.date_key),repeatsYearly:Number(row.repeats_yearly)===1,note:String(row.note),isDemo:Number(row.is_demo)===1,reminderOffsets:parseNumberArray(row.reminder_offsets)}));}
export async function deleteImportantDate(id: string): Promise<void> {
  const database = await readyDatabase();
  await database.runAsync("DELETE FROM important_dates WHERE id=?", [id]);
}
export async function readSetting<T>(key:string,fallback:T):Promise<T>{const database=await readyDatabase(),row=await database.getFirstAsync<{value:string}>("SELECT value FROM app_settings WHERE key=?",[key]);if(!row)return fallback;try{return JSON.parse(row.value) as T}catch{return fallback}}
export async function writeSetting(key:string,value:unknown):Promise<void>{const database=await readyDatabase();await database.runAsync("INSERT INTO app_settings(key,value,updated_at) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at",[key,toJson(value),nowIso()]);}
export async function countCustomerRecords():Promise<number>{const database=await readyDatabase();const tables=["transactions","bills","debts","debt_repayments","bill_payments","budgets","important_dates","zakat_profiles","manual_fx_rates"] as const;let total=0;for(const table of tables){const row=await database.getFirstAsync<{count:number}>(`SELECT COUNT(*) AS count FROM ${table}`);total+=Number(row?.count??0)}return total;}
export async function deleteAllCustomerRecords():Promise<void>{const database=await readyDatabase();await database.withExclusiveTransactionAsync(async(tx)=>{await tx.execAsync("DELETE FROM notification_links;DELETE FROM debt_repayments;DELETE FROM bill_payments;DELETE FROM transactions;DELETE FROM bills;DELETE FROM debts;DELETE FROM budgets;DELETE FROM important_dates;DELETE FROM zakat_profiles;DELETE FROM manual_fx_rates;DELETE FROM categories WHERE is_default=0;")});}

export async function clearSampleData(): Promise<number> {
  const database = await readyDatabase();
  let removed = 0;
  await database.withExclusiveTransactionAsync(async (tx) => {
    const counts = [
      "SELECT COUNT(*) AS count FROM transactions WHERE is_demo=1",
      "SELECT COUNT(*) AS count FROM bills WHERE is_demo=1",
      "SELECT COUNT(*) AS count FROM debts WHERE is_demo=1",
      "SELECT COUNT(*) AS count FROM important_dates WHERE is_demo=1",
    ];
    for (const query of counts) {
      const row = await tx.getFirstAsync<{ count: number }>(query);
      removed += Number(row?.count ?? 0);
    }
    await tx.runAsync("DELETE FROM notification_links");
    await tx.runAsync("DELETE FROM debt_repayments WHERE debt_id IN (SELECT id FROM debts WHERE is_demo=1)");
    await tx.runAsync("DELETE FROM bill_payments WHERE bill_id IN (SELECT id FROM bills WHERE is_demo=1)");
    await tx.runAsync("DELETE FROM transactions WHERE is_demo=1");
    await tx.runAsync("DELETE FROM bills WHERE is_demo=1");
    await tx.runAsync("DELETE FROM debts WHERE is_demo=1");
    await tx.runAsync("DELETE FROM important_dates WHERE is_demo=1");
  });
  return removed;
}
