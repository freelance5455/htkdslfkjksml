import { readyDatabase } from "./repositorySupport";
import { LOCAL_SCHEMA_VERSION } from "./migrations";
import { isDateKey } from "../domain/dates";
import { DEFAULT_CURRENCIES } from "../domain/money";

const TABLES = [
  "categories",
  "transactions",
  "bills",
  "bill_payments",
  "debts",
  "debt_repayments",
  "budgets",
  "important_dates",
  "zakat_profiles",
  "manual_fx_rates",
  "app_settings",
] as const;
const PREFERENCE_KEYS = [
  "language",
  "preferredCurrency",
  "themeMode",
  "customCurrencies",
  "localRemindersEnabled",
  "zakatReminder",
  "zakatProfile",
] as const;
const PREFERENCE_KEY_SET = new Set<string>(PREFERENCE_KEYS);
const MAX_RECORDS = 50_000;

type BackupRow = Record<string, string | number | null>;
export type PortableBackupSnapshot = {
  app: "TOLOVCHI";
  formatVersion: 1;
  schemaVersion: number;
  createdAt: string;
  tables: Record<(typeof TABLES)[number], BackupRow[]>;
};

export async function createPortableBackupSnapshot(): Promise<PortableBackupSnapshot> {
  const database = await readyDatabase();
  const tables = {} as PortableBackupSnapshot["tables"];
  let totalRows = 0;
  for (const table of TABLES) {
    const rows = await database.getAllAsync<BackupRow>(`SELECT * FROM "${table}"`);
    const filtered = table === "categories"
      ? rows.filter((row) => Number(row.is_default) === 0)
      : table === "app_settings"
        ? rows.filter((row) => PREFERENCE_KEY_SET.has(String(row.key)))
        : rows;
    totalRows += filtered.length;
    if (totalRows > MAX_RECORDS) throw new Error("BACKUP_TOO_MANY_RECORDS");
    tables[table] = filtered;
  }
  return {
    app: "TOLOVCHI",
    formatVersion: 1,
    schemaVersion: LOCAL_SCHEMA_VERSION,
    createdAt: new Date().toISOString(),
    tables,
  };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

function assertSnapshotShape(value: unknown): asserts value is PortableBackupSnapshot {
  if (!isRecord(value) || value.app !== "TOLOVCHI" || value.formatVersion !== 1 || value.schemaVersion !== LOCAL_SCHEMA_VERSION || typeof value.createdAt !== "string" || !isRecord(value.tables)) {
    throw new Error("BACKUP_FILE_INVALID");
  }
  const names = Object.keys(value.tables).sort();
  if (names.join("|") !== [...TABLES].sort().join("|")) throw new Error("BACKUP_FILE_INVALID");
}

function parsePreference(row: Record<string, unknown>): unknown {
  if (typeof row.value !== "string") throw new Error("BACKUP_FILE_INVALID");
  try { return JSON.parse(row.value) as unknown; }
  catch { throw new Error("BACKUP_FILE_INVALID"); }
}

function validateCustomCurrencies(value: unknown): void {
  if (!Array.isArray(value) || value.length > 100) throw new Error("BACKUP_FILE_INVALID");
  const usedCodes = new Set(DEFAULT_CURRENCIES.map((item) => item.code));
  for (const currency of value) {
    if (!isRecord(currency) || Object.keys(currency).sort().join("|") !== "code|fractionDigits|name|symbol") throw new Error("BACKUP_FILE_INVALID");
    if (typeof currency.code !== "string" || !/^[A-Z0-9_-]{3,12}$/.test(currency.code) || usedCodes.has(currency.code)) throw new Error("BACKUP_FILE_INVALID");
    if (typeof currency.name !== "string" || !currency.name.trim() || currency.name.length > 60) throw new Error("BACKUP_FILE_INVALID");
    if (typeof currency.symbol !== "string" || !currency.symbol.trim() || currency.symbol.length > 12) throw new Error("BACKUP_FILE_INVALID");
    if (typeof currency.fractionDigits !== "number" || !Number.isInteger(currency.fractionDigits) || currency.fractionDigits < 0 || currency.fractionDigits > 6) throw new Error("BACKUP_FILE_INVALID");
    usedCodes.add(currency.code);
  }
}

function validateZakatProfile(value: unknown): void {
  const requiredStrings = ["cash", "savings", "goldWeight", "goldPrice", "goldValue", "silverWeight", "silverPrice", "silverValue", "inventory", "receivables", "otherAssets", "liabilities", "deductions", "goldNisabGrams", "silverNisabGrams", "calculationDate", "currency"];
  const allowedKeys = [...requiredStrings, "nisabBasis", "haulConfirmed", "nisabConfirmed", "resultStatus", "savedAt"];
  if (!isRecord(value) || Object.keys(value).some((key) => !allowedKeys.includes(key))) throw new Error("BACKUP_FILE_INVALID");
  if (requiredStrings.some((key) => typeof value[key] !== "string" || (value[key] as string).length > 128)) throw new Error("BACKUP_FILE_INVALID");
  if (!isDateKey(value.calculationDate as string) || !/^[A-Za-z0-9_-]{3,12}$/.test(value.currency as string)) throw new Error("BACKUP_FILE_INVALID");
  if (value.nisabBasis !== "gold" && value.nisabBasis !== "silver") throw new Error("BACKUP_FILE_INVALID");
  if (typeof value.haulConfirmed !== "boolean" || typeof value.nisabConfirmed !== "boolean") throw new Error("BACKUP_FILE_INVALID");
  if (value.resultStatus !== undefined && !["needs_price", "needs_nisab", "below_nisab", "confirm_conditions", "estimate_available"].includes(String(value.resultStatus))) throw new Error("BACKUP_FILE_INVALID");
  if (value.savedAt !== undefined && (typeof value.savedAt !== "string" || value.savedAt.length > 64)) throw new Error("BACKUP_FILE_INVALID");
}

function validatePreferenceRows(rows: BackupRow[]): void {
  const preferences = new Map<string, unknown>();
  for (const row of rows) {
    if (typeof row.key !== "string" || !PREFERENCE_KEY_SET.has(row.key) || preferences.has(row.key)) throw new Error("BACKUP_FILE_INVALID");
    preferences.set(row.key, parsePreference(row));
  }
  const language = preferences.get("language");
  if (language !== undefined && language !== "uz" && language !== "ru" && language !== "en") throw new Error("BACKUP_FILE_INVALID");
  const theme = preferences.get("themeMode");
  if (theme !== undefined && theme !== "system" && theme !== "light" && theme !== "dark") throw new Error("BACKUP_FILE_INVALID");
  const customCurrencies = preferences.get("customCurrencies");
  if (customCurrencies !== undefined) validateCustomCurrencies(customCurrencies);
  const currency = preferences.get("preferredCurrency");
  if (currency !== undefined) {
    if (typeof currency !== "string" || !/^[A-Za-z0-9_-]{3,12}$/.test(currency)) throw new Error("BACKUP_FILE_INVALID");
    const customCodes = Array.isArray(customCurrencies) ? customCurrencies.filter(isRecord).map((item) => item.code) : [];
    if (![...DEFAULT_CURRENCIES.map((item) => item.code), ...customCodes].includes(currency)) throw new Error("BACKUP_FILE_INVALID");
  }
  const remindersEnabled = preferences.get("localRemindersEnabled");
  if (remindersEnabled !== undefined && typeof remindersEnabled !== "boolean") throw new Error("BACKUP_FILE_INVALID");
  const zakatReminder = preferences.get("zakatReminder");
  if (zakatReminder !== undefined && zakatReminder !== null) {
    if (!isRecord(zakatReminder) || Object.keys(zakatReminder).sort().join("|") !== "dateKey|offsets" || typeof zakatReminder.dateKey !== "string" || !isDateKey(zakatReminder.dateKey) || !Array.isArray(zakatReminder.offsets) || zakatReminder.offsets.length > 3 || zakatReminder.offsets.some((offset) => offset !== 3 && offset !== 1 && offset !== 0) || new Set(zakatReminder.offsets).size !== zakatReminder.offsets.length) throw new Error("BACKUP_FILE_INVALID");
  }
  const zakatProfile = preferences.get("zakatProfile");
  if (zakatProfile !== undefined) validateZakatProfile(zakatProfile);
}

export async function restorePortableBackupSnapshot(value: unknown): Promise<void> {
  assertSnapshotShape(value);
  const database = await readyDatabase();
  const columnsByTable = new Map<(typeof TABLES)[number], string[]>();
  let totalRows = 0;

  for (const table of TABLES) {
    const schema = await database.getAllAsync<{ name: string }>(`PRAGMA table_info("${table}")`);
    const columns = schema.map((column) => column.name);
    if (columns.length === 0) throw new Error("BACKUP_SCHEMA_UNAVAILABLE");
    columnsByTable.set(table, columns);
    const rows = value.tables[table];
    if (!Array.isArray(rows)) throw new Error("BACKUP_FILE_INVALID");
    totalRows += rows.length;
    if (totalRows > MAX_RECORDS) throw new Error("BACKUP_TOO_MANY_RECORDS");
    const expectedKeys = [...columns].sort().join("|");
    for (const row of rows) {
      if (!isRecord(row) || Object.keys(row).sort().join("|") !== expectedKeys) throw new Error("BACKUP_FILE_INVALID");
      for (const cell of Object.values(row)) {
        if (cell !== null && typeof cell !== "string" && (typeof cell !== "number" || !Number.isFinite(cell))) throw new Error("BACKUP_FILE_INVALID");
      }
      if (table === "categories" && Number(row.is_default) !== 0) throw new Error("BACKUP_FILE_INVALID");
    }
    if (table === "app_settings") validatePreferenceRows(rows);
  }

  await database.withExclusiveTransactionAsync(async (transaction) => {
    await transaction.runAsync("DELETE FROM notification_links");
    await transaction.runAsync("DELETE FROM debt_repayments");
    await transaction.runAsync("DELETE FROM bill_payments");
    await transaction.runAsync("DELETE FROM transactions");
    await transaction.runAsync("DELETE FROM bills");
    await transaction.runAsync("DELETE FROM debts");
    await transaction.runAsync("DELETE FROM budgets");
    await transaction.runAsync("DELETE FROM important_dates");
    await transaction.runAsync("DELETE FROM zakat_profiles");
    await transaction.runAsync("DELETE FROM manual_fx_rates");
    await transaction.runAsync("DELETE FROM categories WHERE is_default=0");
    const preferencePlaceholders = PREFERENCE_KEYS.map(() => "?").join(",");
    await transaction.runAsync(`DELETE FROM app_settings WHERE key IN (${preferencePlaceholders})`, [...PREFERENCE_KEYS]);

    for (const table of TABLES) {
      const columns = columnsByTable.get(table)!;
      const rows = value.tables[table];
      if (rows.length === 0) continue;
      const quotedColumns = columns.map((column) => `"${column}"`).join(",");
      const placeholders = columns.map(() => "?").join(",");
      const insert = `INSERT INTO "${table}" (${quotedColumns}) VALUES (${placeholders})`;
      for (const row of rows) {
        await transaction.runAsync(insert, columns.map((column) => row[column] ?? null));
      }
    }
  });
}
