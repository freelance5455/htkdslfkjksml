import * as Crypto from "expo-crypto";
import * as SecureStore from "expo-secure-store";
import * as SQLite from "expo-sqlite";

const DATABASE_NAME = "tolovchi-finance.db";
const DATABASE_KEY_NAME = "tolovchi.sqlcipher.key.v1";
let openPromise: Promise<SQLite.SQLiteDatabase> | null = null;

function bytesToHex(bytes: Uint8Array): string {
  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
}

export async function openEncryptedDatabase(): Promise<SQLite.SQLiteDatabase> {
  if (openPromise) return openPromise;
  openPromise = (async () => {
    const key = await SecureStore.getItemAsync(DATABASE_KEY_NAME);
    const generatedKey = key ?? bytesToHex(await Crypto.getRandomBytesAsync(32));
    if (!key) await SecureStore.setItemAsync(DATABASE_KEY_NAME, generatedKey);

    const database = await SQLite.openDatabaseAsync(DATABASE_NAME);
    try {
      // Only hexadecimal CSPRNG material can reach this SQL literal.
      await database.execAsync(`PRAGMA key = "x'${generatedKey}'";`);
      const cipher = await database.getFirstAsync<{ cipher_version?: string }>("PRAGMA cipher_version;");
      if (!cipher?.cipher_version) {
        throw new Error("Secure local storage is unavailable: this native build does not include SQLCipher.");
      }
      await database.execAsync("PRAGMA foreign_keys = ON; PRAGMA journal_mode = WAL;");
      return database;
    } catch (error) {
      await database.closeAsync();
      openPromise = null;
      throw error;
    }
  })();
  return openPromise;
}

export async function deleteLocalEncryptionKeyForFullReset(): Promise<void> {
  await SecureStore.deleteItemAsync(DATABASE_KEY_NAME);
  openPromise = null;
}

export const DATABASE_NAME_FOR_BACKUP = DATABASE_NAME;
