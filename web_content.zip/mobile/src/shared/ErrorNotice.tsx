import { StyleSheet, Text, View } from "react-native";
import { palette, radius, spacing } from "../theme/tokens";

export function ErrorNotice({ title, message }: { title: string; message: string }) {
  return (
    <View accessibilityRole="alert" style={styles.card}>
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.body}>{message}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: { backgroundColor: palette.redSoft, borderColor: "#f1c7c4", borderWidth: 1, borderRadius: radius.md, padding: spacing.lg, marginVertical: spacing.md },
  title: { color: palette.red, fontSize: 16, fontWeight: "700", marginBottom: spacing.xs },
  body: { color: palette.ink, fontSize: 14, lineHeight: 20 },
});
