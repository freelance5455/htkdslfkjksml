import { createContext, useContext, useEffect, useMemo, useState, type PropsWithChildren } from "react";
import { AppState, useColorScheme } from "react-native";
import { detectDeviceLanguage, type AppLanguage } from "../i18n";
import { readyDatabase } from "../db/repositorySupport";
import { ensureDefaultCategories, readSetting, writeSetting } from "../db/repository";
import { enableBiometricUnlock, hasAppPin, isBiometricUnlockEnabled, removeAppPin, setAppPin, unlockWithBiometrics, verifyAppPin, type PinVerification } from "../security/appLock";
import { palette, type ThemeColors } from "../theme/tokens";

export type ThemeMode = "system" | "light" | "dark";
type FinanceContextValue = {
  ready: boolean;
  error: string | null;
  onboardingComplete: boolean;
  locked: boolean;
  hasPin: boolean;
  biometricEnabled: boolean;
  language: AppLanguage;
  currency: string;
  themeMode: ThemeMode;
  colors: ThemeColors;
  refreshKey: number;
  completeOnboarding: (language: AppLanguage, currency: string) => Promise<void>;
  setLanguage: (language: AppLanguage) => Promise<void>;
  setCurrency: (currency: string) => Promise<void>;
  setThemeMode: (mode: ThemeMode) => Promise<void>;
  createPin: (pin: string) => Promise<void>;
  changePin: (oldPin: string, newPin: string) => Promise<boolean>;
  removePin: (pin: string) => Promise<boolean>;
  setBiometric: (enabled: boolean) => Promise<void>;
  unlockPin: (pin: string) => Promise<PinVerification>;
  unlockBiometric: () => Promise<boolean>;
  lock: () => void;
  refresh: () => void;
};

const FinanceContext = createContext<FinanceContextValue | null>(null);
const darkPalette: ThemeColors = {
  ...palette,
  ink: "#f1f7f3",
  inkMuted: "#a6b6ae",
  canvas: "#101815",
  surface: "#17221e",
  surfaceDark: "#09100d",
  line: "#2b3b34",
  emeraldSoft: "#183a31",
  amberSoft: "#382a18",
  redSoft: "#3d2625",
};

export function MobileProvider({ children }: PropsWithChildren) {
  const systemScheme = useColorScheme();
  const [ready, setReady] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [onboardingComplete, setOnboardingComplete] = useState(false);
  const [locked, setLocked] = useState(false);
  const [hasPinState, setHasPinState] = useState(false);
  const [biometricEnabled, setBiometricEnabled] = useState(false);
  const [language, setLanguageState] = useState<AppLanguage>(detectDeviceLanguage());
  const [currency, setCurrencyState] = useState("UZS");
  const [themeMode, setThemeModeState] = useState<ThemeMode>("system");
  const [refreshKey, setRefreshKey] = useState(0);

  useEffect(() => {
    let mounted = true;
    void (async () => {
      await readyDatabase();
      await ensureDefaultCategories();
      const [onboarded, savedLanguage, savedCurrency, savedTheme, pinExists, bioEnabled] = await Promise.all([
        readSetting<boolean>("onboardingComplete", false),
        readSetting<AppLanguage>("language", detectDeviceLanguage()),
        readSetting<string>("preferredCurrency", "UZS"),
        readSetting<ThemeMode>("themeMode", "system"),
        hasAppPin(),
        isBiometricUnlockEnabled(),
      ]);
      if (!mounted) return;
      setOnboardingComplete(onboarded);
      setLanguageState(savedLanguage);
      setCurrencyState(savedCurrency);
      setThemeModeState(savedTheme);
      setHasPinState(pinExists);
      setBiometricEnabled(bioEnabled);
      setLocked(onboarded && pinExists);
      setReady(true);
    })().catch((cause: unknown) => {
      if (mounted) setError(cause instanceof Error ? cause.message : "The encrypted local database could not be opened.");
    });
    return () => { mounted = false; };
  }, []);

  useEffect(() => {
    if (!hasPinState) return;
    const subscription = AppState.addEventListener("change", (state) => {
      if (state === "inactive" || state === "background") setLocked(true);
    });
    return () => subscription.remove();
  }, [hasPinState]);

  const colors = useMemo<ThemeColors>(() => {
    const dark = themeMode === "dark" || (themeMode === "system" && systemScheme === "dark");
    return dark ? darkPalette : palette;
  }, [systemScheme, themeMode]);

  const value = useMemo<FinanceContextValue>(() => ({
    ready, error, onboardingComplete, locked, hasPin: hasPinState, biometricEnabled,
    language, currency, themeMode, colors, refreshKey,
    completeOnboarding: async (newLanguage, newCurrency) => {
      await Promise.all([
        writeSetting("language", newLanguage),
        writeSetting("preferredCurrency", newCurrency),
        writeSetting("themeMode", themeMode),
        writeSetting("onboardingComplete", true),
      ]);
      setLanguageState(newLanguage);
      setCurrencyState(newCurrency);
      setOnboardingComplete(true);
      setLocked(false);
    },
    setLanguage: async (next) => { await writeSetting("language", next); setLanguageState(next); },
    setCurrency: async (next) => { await writeSetting("preferredCurrency", next); setCurrencyState(next); },
    setThemeMode: async (next) => { await writeSetting("themeMode", next); setThemeModeState(next); },
    createPin: async (pin) => { await setAppPin(pin); setHasPinState(true); setBiometricEnabled(false); setLocked(false); },
    changePin: async (oldPin, newPin) => {
      const result = await verifyAppPin(oldPin);
      if (!result.ok) return false;
      await setAppPin(newPin, await isBiometricUnlockEnabled());
      return true;
    },
    removePin: async (pin) => {
      const result = await verifyAppPin(pin);
      if (!result.ok) return false;
      await removeAppPin();
      setHasPinState(false);
      setBiometricEnabled(false);
      setLocked(false);
      return true;
    },
    setBiometric: async (enabled) => { await enableBiometricUnlock(enabled); setBiometricEnabled(enabled); },
    unlockPin: async (pin) => {
      const result = await verifyAppPin(pin);
      if (result.ok) setLocked(false);
      return result;
    },
    unlockBiometric: async () => {
      const success = await unlockWithBiometrics();
      if (success) setLocked(false);
      return success;
    },
    lock: () => { if (hasPinState) setLocked(true); },
    refresh: () => setRefreshKey((key) => key + 1),
  }), [ready, error, onboardingComplete, locked, hasPinState, biometricEnabled, language, currency, themeMode, colors, refreshKey]);

  return <FinanceContext.Provider value={value}>{children}</FinanceContext.Provider>;
}

export function useFinance(): FinanceContextValue {
  const value = useContext(FinanceContext);
  if (!value) throw new Error("useFinance must be used inside MobileProvider.");
  return value;
}
