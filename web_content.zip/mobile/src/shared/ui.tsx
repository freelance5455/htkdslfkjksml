import type { PropsWithChildren } from "react";
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View, type PressableProps, type StyleProp, type TextInputProps, type ViewStyle } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { radius, spacing } from "../theme/tokens";
import { useFinance } from "./MobileProvider";

export function Page({ title, subtitle, children, scroll = true, style }: PropsWithChildren<{ title?: string; subtitle?: string; scroll?: boolean; style?: StyleProp<ViewStyle> }>) {
  const { colors } = useFinance();
  const content = (
    <View style={[styles.content, style]}>
      {title ? <Text style={[styles.pageTitle, { color: colors.ink }]}>{title}</Text> : null}
      {subtitle ? <Text style={[styles.pageSubtitle, { color: colors.inkMuted }]}>{subtitle}</Text> : null}
      {children}
    </View>
  );
  return <SafeAreaView style={[styles.safe, { backgroundColor: colors.canvas }]} edges={["top", "left", "right"]}>
    {scroll ? <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={styles.scroll}>{content}</ScrollView> : content}
  </SafeAreaView>;
}

export function Card({ children, style }: PropsWithChildren<{ style?: StyleProp<ViewStyle> }>) {
  const { colors } = useFinance();
  return <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.line }, style]}>{children}</View>;
}

export function Heading({ children, detail }: PropsWithChildren<{ detail?: string }>) {
  const { colors } = useFinance();
  return <View style={styles.headingRow}><Text style={[styles.heading, { color: colors.ink }]}>{children}</Text>{detail ? <Text style={[styles.detail, { color: colors.inkMuted }]}>{detail}</Text> : null}</View>;
}

export function Button({ title, variant = "primary", disabled, style, ...props }: PressableProps & { title: string; variant?: "primary" | "secondary" | "danger"; style?: StyleProp<ViewStyle> }) {
  const { colors } = useFinance();
  const background = variant === "primary" ? colors.emerald : variant === "danger" ? colors.redSoft : colors.emeraldSoft;
  const foreground = variant === "primary" ? colors.white : variant === "danger" ? colors.red : colors.emeraldDark;
  return <Pressable accessibilityRole="button" disabled={disabled} style={({ pressed }) => [styles.button, { backgroundColor: background, opacity: disabled ? 0.5 : pressed ? 0.78 : 1 }, style]} {...props}>
    <Text style={[styles.buttonText, { color: foreground }]}>{title}</Text>
  </Pressable>;
}

export function Field({ label, hint, style, ...props }: TextInputProps & { label: string; hint?: string; style?: StyleProp<ViewStyle> }) {
  const { colors } = useFinance();
  return <View style={styles.fieldWrap}>
    <Text style={[styles.fieldLabel, { color: colors.ink }]}>{label}</Text>
    <TextInput accessibilityLabel={label} placeholderTextColor={colors.inkMuted} selectionColor={colors.emerald}
      {...props} style={[styles.field, { backgroundColor: colors.surface, borderColor: colors.line, color: colors.ink }, style]} />
    {hint ? <Text style={[styles.fieldHint, { color: colors.inkMuted }]}>{hint}</Text> : null}
  </View>;
}

export function Pill({ title, selected, onPress, style }: { title: string; selected: boolean; onPress: () => void; style?: ViewStyle }) {
  const { colors } = useFinance();
  return <Pressable accessibilityRole="button" accessibilityState={{ selected }} onPress={onPress}
    style={[styles.pill, { backgroundColor: selected ? colors.emeraldSoft : colors.surface, borderColor: selected ? colors.emerald : colors.line }, style]}>
    <Text style={{ color: selected ? colors.emeraldDark : colors.inkMuted, fontSize: 13, fontWeight: "700" }}>{title}</Text>
  </Pressable>;
}

export function EmptyState({ title, detail, action }: { title: string; detail: string; action?: { title: string; onPress: () => void } }) {
  const { colors } = useFinance();
  return <View style={[styles.empty, { borderColor: colors.line, backgroundColor: colors.surface }]}>
    <Text style={[styles.emptyTitle, { color: colors.ink }]}>{title}</Text>
    <Text style={[styles.emptyDetail, { color: colors.inkMuted }]}>{detail}</Text>
    {action ? <Button title={action.title} onPress={action.onPress} style={{ marginTop: spacing.md }} /> : null}
  </View>;
}

export function Label({ children, color }: PropsWithChildren<{ color?: string }>) {
  const { colors } = useFinance();
  return <Text style={[styles.label, { color: color ?? colors.inkMuted }]}>{children}</Text>;
}

const styles = StyleSheet.create({
  safe: { flex: 1 }, scroll: { paddingBottom: spacing.xxl }, content: { paddingHorizontal: spacing.lg, paddingTop: spacing.md, gap: spacing.md },
  pageTitle: { fontSize: 26, fontWeight: "800", letterSpacing: -0.4 }, pageSubtitle: { fontSize: 14, lineHeight: 20, marginTop: -spacing.sm },
  card: { borderWidth: 1, borderRadius: radius.md, padding: spacing.md, gap: spacing.sm },
  headingRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: spacing.sm },
  heading: { fontSize: 17, fontWeight: "800" }, detail: { fontSize: 12, fontWeight: "600" },
  button: { minHeight: 48, alignItems: "center", justifyContent: "center", borderRadius: radius.md, paddingHorizontal: spacing.lg, paddingVertical: 12 },
  buttonText: { fontSize: 15, fontWeight: "800", textAlign: "center" },
  fieldWrap: { gap: 7 }, fieldLabel: { fontSize: 13, fontWeight: "700" }, field: { minHeight: 48, borderWidth: 1, borderRadius: radius.sm, paddingHorizontal: 13, paddingVertical: 10, fontSize: 16 }, fieldHint: { fontSize: 12, lineHeight: 17 },
  pill: { minHeight: 38, paddingHorizontal: 13, justifyContent: "center", borderRadius: radius.pill, borderWidth: 1 },
  empty: { borderWidth: 1, borderRadius: radius.md, padding: spacing.lg, alignItems: "flex-start", gap: spacing.sm }, emptyTitle: { fontSize: 16, fontWeight: "800" }, emptyDetail: { fontSize: 14, lineHeight: 21 },
  label: { fontSize: 12, fontWeight: "700" },
});
