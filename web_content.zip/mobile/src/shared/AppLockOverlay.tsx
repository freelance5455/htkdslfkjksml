import { useEffect, useState } from "react";
import { ActivityIndicator, KeyboardAvoidingView, Platform, StyleSheet, Text, TextInput, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { t } from "../i18n";
import { radius, spacing } from "../theme/tokens";
import { Button } from "./ui";
import { useFinance } from "./MobileProvider";

export function AppLockOverlay() {
  const { locked, hasPin, biometricEnabled, language, colors, unlockPin, unlockBiometric } = useFinance();
  const [pin, setPin] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [blockedUntil, setBlockedUntil] = useState(0);
  const [now, setNow] = useState(Date.now());
  const secondsLeft = Math.max(0, Math.ceil((blockedUntil - now) / 1000));

  useEffect(() => {
    if (!locked) { setPin(""); setMessage(""); setBlockedUntil(0); }
  }, [locked]);
  useEffect(() => {
    if (!blockedUntil) return;
    const timer = setInterval(() => setNow(Date.now()), 500);
    return () => clearInterval(timer);
  }, [blockedUntil]);

  if (!locked) return null;
  const submit = async () => {
    setBusy(true);
    setMessage("");
    try {
      const result = await unlockPin(pin);
      if (result.ok) return;
      setPin("");
      setBlockedUntil(result.retryAfterMs > 0 ? Date.now() + result.retryAfterMs : 0);
      setMessage(result.retryAfterMs > 0 ? `Try again in ${Math.ceil(result.retryAfterMs / 1000)} seconds.` : "That PIN was not correct. Try again.");
    } catch {
      setMessage(t(language, "genericError"));
    } finally {
      setBusy(false);
    }
  };
  const biometrics = async () => {
    setBusy(true);
    setMessage("");
    try {
      if (!(await unlockBiometric())) setMessage("Biometric verification was not completed. Use your PIN.");
    } catch {
      setMessage("Biometric unlock is unavailable. Use your PIN.");
    } finally {
      setBusy(false);
    }
  };

  return <View accessibilityViewIsModal style={[StyleSheet.absoluteFill, styles.scrim, { backgroundColor: colors.canvas }]}>
    <KeyboardAvoidingView style={styles.center} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <SafeAreaView style={styles.safe}>
        <View style={[styles.logo, { backgroundColor: colors.emeraldSoft }]}><Text style={[styles.logoText, { color: colors.emerald }]}>T</Text></View>
        <Text style={[styles.title, { color: colors.ink }]}>{t(language, "lockTitle")}</Text>
        <Text style={[styles.subtitle, { color: colors.inkMuted }]}>{t(language, "offline")}</Text>
        <TextInput value={pin} onChangeText={(value) => setPin(value.replace(/\D/g, "").slice(0, 12))}
          placeholder="••••••" placeholderTextColor={colors.inkMuted} secureTextEntry keyboardType="number-pad" textContentType="oneTimeCode"
          autoFocus accessibilityLabel={t(language, "usePin")} style={[styles.input, { color: colors.ink, backgroundColor: colors.surface, borderColor: colors.line }]} />
        {message ? <Text accessibilityRole="alert" style={[styles.message, { color: colors.red }]}>{message}</Text> : null}
        {secondsLeft > 0 ? <Text style={[styles.message, { color: colors.amber }]}>{`Try again in ${secondsLeft} seconds.`}</Text> : null}
        <Button title={busy ? "…" : t(language, "unlock")} disabled={busy || secondsLeft > 0 || pin.length < 6} onPress={() => void submit()} />
        {biometricEnabled && hasPin ? <Button variant="secondary" title={t(language, "useBiometric")} disabled={busy} onPress={() => void biometrics()} /> : null}
        {busy ? <ActivityIndicator color={colors.emerald} /> : null}
      </SafeAreaView>
    </KeyboardAvoidingView>
  </View>;
}

const styles = StyleSheet.create({
  scrim: { zIndex: 10000, elevation: 10000, justifyContent: "center" }, center: { width: "100%", alignItems: "center" },
  safe: { width: "100%", maxWidth: 420, paddingHorizontal: spacing.lg, gap: spacing.md, alignItems: "stretch" },
  logo: { alignSelf: "center", width: 60, height: 60, borderRadius: radius.lg, alignItems: "center", justifyContent: "center", marginBottom: spacing.sm },
  logoText: { fontSize: 30, fontWeight: "900" }, title: { fontSize: 24, fontWeight: "900", textAlign: "center" }, subtitle: { fontSize: 14, textAlign: "center", marginBottom: spacing.sm },
  input: { borderWidth: 1, borderRadius: radius.md, minHeight: 56, textAlign: "center", fontSize: 24, letterSpacing: 8 },
  message: { fontSize: 13, textAlign: "center" },
});
