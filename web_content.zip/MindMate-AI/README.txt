MindMate AI — Fast Chat + Saved Chats

FEATURES
- Simple white chat interface.
- Wellbeing and General Knowledge modes.
- Gemini API key check before reporting that the app is connected.
- Gemini 3.5 Flash-Lite selected by default for faster responses.
- Optional Gemini 3.5 Flash model selection.
- Streaming replies and short response limits.
- Save chats automatically on this device; reopen or delete saved chats.
- API key is kept in page memory only for the current browser session.

RUN
1. Extract the complete ZIP.
2. Open MindMate-AI/index.html in a modern browser with internet access.
3. Open API settings and choose Gemini 3.5 Flash-Lite (recommended for speed).
4. Paste your Gemini API key and press Connect. The app tests the key and selected model.
5. Start chatting. Use Saved chats to reopen earlier conversations.

NOTES
- Gemini 3.5 Flash-Lite is the faster, lower-cost option; Gemini 3.5 Flash is also selectable.
- Actual response speed depends on internet connection, Google service latency, API quotas, and model availability. A fixed response time cannot be guaranteed.
- Saved chats use this browser's local storage. Clearing browser data may erase them; they do not sync across devices.
- This is a browser-based project, not an Android APK. Do not publish a browser-exposed API key. A public release should use a secure backend.
- No live API call was tested with the user's private API key.

WELLBEING SAFETY
MindMate is a wellbeing companion, not a diagnosis, treatment, or crisis service. Encourage trusted human and professional support when needed.
