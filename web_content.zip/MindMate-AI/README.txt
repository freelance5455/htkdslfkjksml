MINDMATE AI — GEMINI 3.8 FLASH EDITION

HOW TO USE ON ANDROID
1. Extract this ZIP file.
2. Open index.html in a browser (Chrome is recommended). If your file manager cannot open it, use a simple HTML preview app or upload the folder to a trusted static website host.
3. Get a Gemini API key from https://aistudio.google.com/app/apikey
4. Open Gemini API settings inside MindMate AI, paste the key, and tap “Use this key”.
5. Send a test message.

PRIMARY MODEL: gemini-3.8-flash
FALLBACK MODEL: gemini-3.5-flash-lite

IMPORTANT SECURITY NOTE
This is a simple prototype. A key entered into a browser page can be exposed to anyone who can inspect the page or network requests. Do not publish it as a public app or share your API key. A public app should call Gemini through a secure backend. API availability and charges depend on Google's current terms and your account.
