MindMate AI — Quick Response + Wellbeing + GK Edition

FEATURES
- Five guided wellbeing levels.
- Optional mood check-in and quick support tools: 5-4-3 grounding, tiny action, gentle thought check, and reaching out to a trusted person.
- General Knowledge (GK) mode for facts, explanations, and MCQ practice.
- Instant offline answers for common stable GK questions, such as Pakistan's capital, planets, basic science, and SI units.
- Other GK and wellbeing questions use Gemini 3.5 Flash-Lite with streaming responses.
- Shorter model responses (180-token cap) to reduce wait time.
- Concise prompt instructions; recent conversation history is limited.

RUN
1. Extract the complete ZIP.
2. Open MindMate-AI/index.html in a modern browser with internet access.
3. Open Gemini API settings, paste your own Gemini API key, and tap Use this key.
4. Choose Wellbeing or General Knowledge (GK) mode, then send a message.

SPEED NOTES
- Common built-in GK questions answer immediately without a network request.
- Other AI responses depend on internet speed, Google service latency, API quotas, and model availability. A 2–3 second response cannot be guaranteed.
- The app uses the official model ID gemini-3.5-flash-lite. Model availability may vary by account and region.
- This is a browser-based demo, not an APK. Do not publish a browser-exposed API key; use a secure backend for a public release.

WELLBEING SAFETY
MindMate is a wellbeing companion, not a diagnosis, treatment, or crisis service. Small coping steps may help some people, but they are not a guaranteed cure. Seek trusted human and professional support when needed.
