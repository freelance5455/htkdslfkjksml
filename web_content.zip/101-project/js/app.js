// ==================== DEFAULTS ====================
const DEFAULT_WORKOUTS = [
  {
    id: 'tuesday',
    name: 'TERÇA — SUPERIOR',
    subtitle: 'Peito + Costas + Ombros + Braços',
    exercises: [
      { id: 't1', name: 'Flexão com mochila', sets: 4, reps: '8–15', type: 'reps' },
      { id: 't2', name: 'Remada curvada com mochila', sets: 4, reps: '8–15', type: 'reps' },
      { id: 't3', name: 'Remada unilateral com mochila', sets: 3, reps: '10–15', type: 'reps' },
      { id: 't4', name: 'Pike push-up', sets: 3, reps: '6–12', type: 'reps' },
      { id: 't5', name: 'Flexão fechada', sets: 3, reps: '8–15', type: 'reps' },
      { id: 't6', name: 'Rosca com mochila', sets: 3, reps: '10–15', type: 'reps' }
    ]
  },
  {
    id: 'thursday',
    name: 'QUINTA — INFERIOR + CORE',
    subtitle: 'Perna + Glúteos + Panturrilha + Abdômen',
    exercises: [
      { id: 'q1', name: 'Agachamento com mochila', sets: 4, reps: '10–15', type: 'reps' },
      { id: 'q2', name: 'Afundo búlgaro', sets: 3, reps: '8–12 cada perna', type: 'reps' },
      { id: 'q3', name: 'Stiff com mochila', sets: 3, reps: '10–15', type: 'reps' },
      { id: 'q4', name: 'Elevação pélvica com mochila', sets: 3, reps: '10–15', type: 'reps' },
      { id: 'q5', name: 'Panturrilha unilateral', sets: 4, reps: '12–20', type: 'reps' },
      { id: 'q6', name: 'Elevação de pernas', sets: 3, reps: '10–15', type: 'reps' },
      { id: 'q7', name: 'Prancha', sets: 3, reps: '30–60 segundos', type: 'time' }
    ]
  }
];

const MILESTONES = [1, 10, 25, 50, 75, 101];

// ==================== STATE ====================
let state = {
  workouts: [],
  progress: {},      // { [wId]: { [exId]: [ {done, reps, load, time}, ... ] } }
  notes: {},         // { [wId]: { [exId]: string } }
  prs: {},           // { [exName]: { maxReps, maxLoad, bestTime } }
  history: [],       // [ { date, workoutId, name, setsDone, exercisesDone } ]
  totalCompleted: 0,
  settings: { restSeconds: 90 },
  currentId: null,
  focusIdx: 0,
  focusSet: 0,
  rest: { remaining: 0, interval: null, paused: false },
  logPending: null,  // { exId, setIndex, fromFocus }
  editBuffer: null,
  manageId: null,
  renameMode: false,
  notesExId: null
};

// ==================== STORAGE ====================
function loadData() {
  try {
    const saved = localStorage.getItem('101project_v3');
    if (saved) {
      const d = JSON.parse(saved);
      state.workouts = d.workouts || structuredClone(DEFAULT_WORKOUTS);
      state.progress = d.progress || {};
      state.notes = d.notes || {};
      state.prs = d.prs || {};
      state.history = d.history || [];
      state.totalCompleted = d.totalCompleted || 0;
      state.settings = d.settings || { restSeconds: 90 };
    } else {
      // migrate
      const old = localStorage.getItem('101project_v2') || localStorage.getItem('101project');
      if (old) {
        try {
          const o = JSON.parse(old);
          state.workouts = o.workouts || structuredClone(DEFAULT_WORKOUTS);
          if (!Array.isArray(state.workouts)) state.workouts = structuredClone(DEFAULT_WORKOUTS);
          state.progress = {};
          state.settings = o.settings || { restSeconds: 90 };
        } catch(e) {
          state.workouts = structuredClone(DEFAULT_WORKOUTS);
        }
      } else {
        state.workouts = structuredClone(DEFAULT_WORKOUTS);
      }
      state.progress = {};
      state.notes = {};
      state.prs = {};
      state.history = [];
      state.totalCompleted = 0;
    }
  } catch(e) {
    state.workouts = structuredClone(DEFAULT_WORKOUTS);
    state.progress = {};
    state.notes = {};
    state.prs = {};
    state.history = [];
    state.totalCompleted = 0;
    state.settings = { restSeconds: 90 };
  }
  state.workouts.forEach(w => {
    if (!state.progress[w.id]) state.progress[w.id] = {};
    if (!state.notes[w.id]) state.notes[w.id] = {};
  });
}

function saveData() {
  localStorage.setItem('101project_v3', JSON.stringify({
    workouts: state.workouts,
    progress: state.progress,
    notes: state.notes,
    prs: state.prs,
    history: state.history,
    totalCompleted: state.totalCompleted,
    settings: state.settings
  }));
}

// ==================== HELPERS ====================
function getWorkout(id) { return state.workouts.find(w => w.id === id); }

function getProgress(id) {
  const workout = getWorkout(id);
  if (!workout) return { done: 0, total: 0, setsDone: 0, setsTotal: 0 };
  let done = 0, setsDone = 0, setsTotal = 0;
  workout.exercises.forEach(ex => {
    const prog = state.progress[id][ex.id] || [];
    const completed = prog.filter(s => s && s.done).length;
    setsDone += completed;
    setsTotal += ex.sets;
    if (completed >= ex.sets) done++;
  });
  return { done, total: workout.exercises.length, setsDone, setsTotal };
}

function formatTime(sec) {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return String(m).padStart(2,'0') + ':' + String(s).padStart(2,'0');
}

function generateId() {
  return 'w_' + Date.now() + '_' + Math.random().toString(36).slice(2,7);
}

function getPR(name) {
  return state.prs[name] || { maxReps: 0, maxLoad: 0, bestTime: 0 };
}

function updatePR(name, reps, load, time, type) {
  if (!state.prs[name]) state.prs[name] = { maxReps: 0, maxLoad: 0, bestTime: 0 };
  const pr = state.prs[name];
  if (type === 'time') {
    if (time > pr.bestTime) pr.bestTime = time;
  } else {
    if (reps > pr.maxReps) pr.maxReps = reps;
    if (load > pr.maxLoad) pr.maxLoad = load;
  }
}

function formatDate(d) {
  const days = ['DOM','SEG','TER','QUA','QUI','SEX','SÁB'];
  const dt = new Date(d);
  return days[dt.getDay()] + ' ' + String(dt.getDate()).padStart(2,'0') + '/' + String(dt.getMonth()+1).padStart(2,'0');
}

// ==================== SCREENS ====================
function showScreen(name) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  const el = document.getElementById(name + '-screen');
  if (el) el.classList.add('active');

  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  const navs = document.querySelectorAll('.nav-btn');
  if (name === 'home') navs[0].classList.add('active');
  else if (name === 'history') navs[1].classList.add('active');
  else if (name === 'settings') navs[2].classList.add('active');

  if (name === 'home') { renderHome(); updateEvolutionBar(); }
  if (name === 'history') renderHistory();
  if (name === 'settings') updateSettingsUI();
}

function goHome() {
  stopRest();
  showScreen('home');
  state.currentId = null;
}

function closeComplete() {
  document.getElementById('complete-overlay').classList.add('hidden');
  goHome();
}

// ==================== EVOLUTION ====================
function updateEvolutionBar() {
  document.getElementById('evo-count').textContent = state.totalCompleted;
  const cont = document.getElementById('evo-milestones');
  cont.innerHTML = '';
  MILESTONES.forEach(m => {
    const d = document.createElement('div');
    d.className = 'evo-dot' + (state.totalCompleted >= m ? ' done' : '');
    cont.appendChild(d);
  });
}

function showEvolution() {
  document.getElementById('evo-big').textContent = state.totalCompleted;
  const path = document.getElementById('evo-path');
  path.innerHTML = '';
  MILESTONES.forEach(m => {
    const s = document.createElement('span');
    s.className = 'evo-milestone' + (state.totalCompleted >= m ? ' reached' : '');
    s.textContent = m === 101 ? '101 🔥' : m;
    path.appendChild(s);
  });
  document.getElementById('evo-overlay').classList.remove('hidden');
}

function closeEvo() {
  document.getElementById('evo-overlay').classList.add('hidden');
}

// ==================== HOME ====================
function renderHome() {
  const container = document.getElementById('workouts-list');
  container.innerHTML = '';

  if (state.workouts.length === 0) {
    container.innerHTML = '<div class="empty-state"><p>Nenhum treino criado.</p><button class="btn-empty-create" onclick="openCreateWorkout()">+ CRIAR TREINO</button></div>';
    return;
  }

  state.workouts.forEach(w => {
    const p = getProgress(w.id);
    const pct = p.total ? (p.done / p.total) * 100 : 0;
    const card = document.createElement('div');
    card.className = 'day-card';
    card.onclick = function(e) {
      if (e.target.closest('.btn-card-menu')) return;
      startWorkout(w.id);
    };
    card.innerHTML =
      '<button class="btn-card-menu" onclick="openManage(\'' + w.id + '\')">⋯</button>' +
      '<div class="day-info">' +
        '<span class="day-name">' + w.exercises.length + ' exercícios</span>' +
        '<span class="day-focus">' + w.name + '</span>' +
        '<span class="day-muscles">' + (w.subtitle || '') + '</span>' +
      '</div>' +
      '<div class="day-progress">' +
        '<div class="progress-bar"><div class="progress-fill" style="width:' + pct + '%"></div></div>' +
        '<span class="progress-text">' + p.done + '/' + p.total + '</span>' +
      '</div>' +
      '<button class="btn-start">COMEÇAR TREINO</button>';
    container.appendChild(card);
  });
}

function startWorkout(id) {
  state.currentId = id;
  const w = getWorkout(id);
  if (!w) return;
  document.getElementById('workout-title').textContent = w.name;
  document.getElementById('workout-subtitle').textContent = w.subtitle || '';
  renderExercises();
  updateOverallProgress();
  showScreen('workout');
}

// ==================== EXERCISES LIST ====================
function renderExercises() {
  const container = document.getElementById('exercises-list');
  const workout = getWorkout(state.currentId);
  if (!workout) return;
  const prog = state.progress[state.currentId] || {};
  const notes = state.notes[state.currentId] || {};

  container.innerHTML = '';

  workout.exercises.forEach(ex => {
    const sets = prog[ex.id] || [];
    const completed = sets.filter(s => s && s.done).length;
    const allDone = completed >= ex.sets;
    const pr = getPR(ex.name);

    let setsHtml = '';
    for (let i = 0; i < ex.sets; i++) {
      const s = sets[i];
      const done = s && s.done;
      let logged = '';
      if (done) {
        if (ex.type === 'time') logged = (s.time || 0) + 's';
        else {
          logged = (s.reps || 0) + ' reps';
          if (s.load) logged += ' • ' + s.load + 'kg';
        }
      }
      setsHtml +=
        '<div class="set-row ' + (done ? 'done' : '') + '" onclick="openLogSet(\'' + ex.id + '\',' + i + ',false)">' +
          '<div class="set-checkbox"></div>' +
          '<span class="set-label">Série ' + (i+1) + '</span>' +
          (logged ? '<span class="set-logged">' + logged + '</span>' : '') +
        '</div>';
    }

    let prText = '';
    if (ex.type === 'time' && pr.bestTime) prText = 'PR: ' + pr.bestTime + 's';
    else if (pr.maxReps) {
      prText = 'PR: ' + pr.maxReps + ' reps';
      if (pr.maxLoad) prText += ' • ' + pr.maxLoad + 'kg';
    }

    const card = document.createElement('div');
    card.className = 'exercise-card' + (allDone ? ' completed' : '');
    card.innerHTML =
      '<div class="exercise-header">' +
        '<div>' +
          '<div class="exercise-name">' + ex.name + '</div>' +
          '<div class="exercise-meta">' + ex.sets + ' séries × ' + ex.reps + '</div>' +
          (prText ? '<div class="exercise-pr">' + prText + '</div>' : '') +
        '</div>' +
        (allDone ? '<span class="exercise-status">✓ CONCLUÍDO</span>' : '') +
      '</div>' +
      '<div class="sets-list">' + setsHtml + '</div>' +
      '<div style="display:flex">' +
        (!allDone ? '<button class="btn-mark-all" onclick="markAllSets(\'' + ex.id + '\')">MARCAR TODAS</button>' : '') +
        '<button class="btn-note" onclick="openNotes(\'' + ex.id + '\')">📝 NOTA</button>' +
      '</div>' +
      (notes[ex.id] ? '<div class="exercise-note">"' + notes[ex.id] + '"</div>' : '');

    container.appendChild(card);
  });
  updateFinishButton();
}

function openLogSet(exId, setIndex, fromFocus) {
  const workout = getWorkout(state.currentId);
  const ex = workout.exercises.find(e => e.id === exId);
  if (!ex) return;

  // if already done, allow uncheck
  const prog = state.progress[state.currentId][exId] || [];
  if (prog[setIndex] && prog[setIndex].done && !fromFocus) {
    // uncheck
    prog[setIndex] = { done: false };
    saveData();
    renderExercises();
    updateOverallProgress();
    return;
  }

  state.logPending = { exId, setIndex, fromFocus, type: ex.type };

  document.getElementById('log-title').textContent = 'SÉRIE ' + (setIndex + 1);
  document.getElementById('log-exercise').textContent = ex.name;

  const isTime = ex.type === 'time';
  document.getElementById('log-reps-field').style.display = isTime ? 'none' : 'block';
  document.getElementById('log-load-field').style.display = isTime ? 'none' : 'block';
  document.getElementById('log-time-field').style.display = isTime ? 'block' : 'none';

  // prefill from previous or PR
  const prev = prog[setIndex - 1];
  if (isTime) {
    document.getElementById('log-time').value = (prev && prev.time) || getPR(ex.name).bestTime || 45;
  } else {
    document.getElementById('log-reps').value = (prev && prev.reps) || Math.max(8, getPR(ex.name).maxReps || 10);
    document.getElementById('log-load').value = (prev && prev.load) || getPR(ex.name).maxLoad || 0;
  }

  document.getElementById('log-overlay').classList.remove('hidden');
}

function adjLog(field, delta) {
  const el = document.getElementById('log-' + field);
  let v = parseFloat(el.value) || 0;
  v = Math.max(0, v + delta);
  if (field === 'reps') v = Math.min(99, Math.round(v));
  if (field === 'load') v = Math.min(100, Math.round(v * 2) / 2);
  if (field === 'time') v = Math.min(600, Math.round(v));
  el.value = v;
}

function confirmLog(withData) {
  const p = state.logPending;
  if (!p) return;

  const workout = getWorkout(state.currentId);
  const ex = workout.exercises.find(e => e.id === p.exId);

  if (!state.progress[state.currentId][p.exId]) {
    state.progress[state.currentId][p.exId] = Array(ex.sets).fill(null).map(() => ({ done: false }));
  }
  // ensure length
  while (state.progress[state.currentId][p.exId].length < ex.sets) {
    state.progress[state.currentId][p.exId].push({ done: false });
  }

  let entry = { done: true };
  if (withData) {
    if (ex.type === 'time') {
      entry.time = parseInt(document.getElementById('log-time').value) || 0;
      updatePR(ex.name, 0, 0, entry.time, 'time');
    } else {
      entry.reps = parseInt(document.getElementById('log-reps').value) || 0;
      entry.load = parseFloat(document.getElementById('log-load').value) || 0;
      updatePR(ex.name, entry.reps, entry.load, 0, 'reps');
    }
  }

  state.progress[state.currentId][p.exId][p.setIndex] = entry;
  saveData();

  document.getElementById('log-overlay').classList.add('hidden');
  state.logPending = null;

  if (p.fromFocus) {
    // stay in focus, show next or rest
    afterFocusSetLogged();
  } else {
    renderExercises();
    updateOverallProgress();
    startRest();
  }
}

function markAllSets(exId) {
  const workout = getWorkout(state.currentId);
  const ex = workout.exercises.find(e => e.id === exId);
  if (!ex) return;
  if (!state.progress[state.currentId][exId]) {
    state.progress[state.currentId][exId] = [];
  }
  for (let i = 0; i < ex.sets; i++) {
    if (!state.progress[state.currentId][exId][i] || !state.progress[state.currentId][exId][i].done) {
      state.progress[state.currentId][exId][i] = { done: true };
    }
  }
  saveData();
  renderExercises();
  updateOverallProgress();
}

function updateOverallProgress() {
  const p = getProgress(state.currentId);
  document.getElementById('overall-text').textContent = p.done + '/' + p.total + ' exercícios';
  document.getElementById('overall-fill').style.width = (p.total ? (p.done / p.total) * 100 : 0) + '%';
  updateFinishButton();
}

function updateFinishButton() {
  const p = getProgress(state.currentId);
  document.getElementById('btn-finish').disabled = p.done < p.total || p.total === 0;
}

function finishWorkout() {
  const p = getProgress(state.currentId);
  if (p.done < p.total) return;

  const w = getWorkout(state.currentId);
  state.history.unshift({
    date: new Date().toISOString(),
    workoutId: state.currentId,
    name: w.name,
    setsDone: p.setsDone,
    exercisesDone: p.done
  });
  if (state.history.length > 100) state.history = state.history.slice(0, 100);

  state.totalCompleted++;
  // clear current progress so it can be done again
  state.progress[state.currentId] = {};
  saveData();

  document.getElementById('complete-stats').textContent =
    p.setsDone + '/' + p.setsTotal + ' séries  •  ' + p.done + '/' + p.total + ' exercícios';
  document.getElementById('complete-evo').textContent =
    'Total: ' + state.totalCompleted + ' treinos concluídos' +
    (MILESTONES.includes(state.totalCompleted) ? '  🔥 MARCO ATINGIDO!' : '');

  document.getElementById('complete-overlay').classList.remove('hidden');
  updateEvolutionBar();
}

// ==================== FOCUS MODE ====================
function enterFocusMode() {
  const workout = getWorkout(state.currentId);
  if (!workout || workout.exercises.length === 0) return;

  // find first incomplete
  state.focusIdx = 0;
  state.focusSet = 0;
  for (let i = 0; i < workout.exercises.length; i++) {
    const ex = workout.exercises[i];
    const prog = state.progress[state.currentId][ex.id] || [];
    const done = prog.filter(s => s && s.done).length;
    if (done < ex.sets) {
      state.focusIdx = i;
      state.focusSet = done;
      break;
    }
  }
  showScreen('focus');
  renderFocus();
}

function exitFocusMode() {
  stopRest();
  showScreen('workout');
  renderExercises();
  updateOverallProgress();
}

function renderFocus() {
  const workout = getWorkout(state.currentId);
  const ex = workout.exercises[state.focusIdx];
  if (!ex) { exitFocusMode(); return; }

  const prog = state.progress[state.currentId][ex.id] || [];
  const doneCount = prog.filter(s => s && s.done).length;

  document.getElementById('focus-progress-text').textContent = (state.focusIdx + 1) + '/' + workout.exercises.length;
  document.getElementById('focus-name').textContent = ex.name;
  document.getElementById('focus-meta').textContent = ex.sets + ' séries × ' + ex.reps;
  document.getElementById('focus-set-info').textContent = 'SÉRIE ' + (state.focusSet + 1) + ' DE ' + ex.sets;

  const pr = getPR(ex.name);
  let prText = '';
  if (ex.type === 'time' && pr.bestTime) prText = 'PR: ' + pr.bestTime + 's';
  else if (pr.maxReps) {
    prText = 'PR: ' + pr.maxReps + ' reps';
    if (pr.maxLoad) prText += ' • ' + pr.maxLoad + 'kg';
  }
  document.getElementById('focus-pr').textContent = prText;

  // show last logged of this exercise
  let loggedText = '';
  prog.forEach((s, i) => {
    if (s && s.done) {
      if (ex.type === 'time') loggedText += 'S' + (i+1) + ': ' + (s.time||0) + 's  ';
      else loggedText += 'S' + (i+1) + ': ' + (s.reps||0) + (s.load ? '@' + s.load + 'kg' : '') + '  ';
    }
  });
  document.getElementById('focus-logged').textContent = loggedText;

  document.getElementById('btn-focus-complete').style.display = 'block';
  document.getElementById('btn-focus-next').style.display = 'none';
  document.getElementById('focus-rest').style.display = 'none';
}

function focusCompleteSet() {
  const workout = getWorkout(state.currentId);
  const ex = workout.exercises[state.focusIdx];
  openLogSet(ex.id, state.focusSet, true);
}

function afterFocusSetLogged() {
  // start rest then allow next
  document.getElementById('btn-focus-complete').style.display = 'none';
  document.getElementById('focus-rest').style.display = 'block';
  startRest(true); // focus version
}

function focusNext() {
  const workout = getWorkout(state.currentId);
  const ex = workout.exercises[state.focusIdx];
  state.focusSet++;

  if (state.focusSet >= ex.sets) {
    // next exercise
    state.focusIdx++;
    state.focusSet = 0;
    if (state.focusIdx >= workout.exercises.length) {
      // finished all
      exitFocusMode();
      // check if can finish
      const p = getProgress(state.currentId);
      if (p.done >= p.total) finishWorkout();
      return;
    }
  }
  renderFocus();
}

// ==================== REST ====================
function startRest(isFocus) {
  if (state.rest.interval) return;
  state.rest.remaining = state.settings.restSeconds;
  state.rest.paused = false;

  if (isFocus) {
    document.getElementById('focus-rest-time').textContent = formatTime(state.rest.remaining);
    document.getElementById('btn-pause-focus').textContent = 'PAUSAR';
  } else {
    document.getElementById('timer-display').textContent = formatTime(state.rest.remaining);
    document.getElementById('btn-pause').textContent = 'PAUSAR';
    document.getElementById('rest-overlay').classList.remove('hidden');
  }

  state.rest.interval = setInterval(function() {
    if (state.rest.paused) return;
    state.rest.remaining--;
    const t = formatTime(Math.max(0, state.rest.remaining));
    if (isFocus) document.getElementById('focus-rest-time').textContent = t;
    else document.getElementById('timer-display').textContent = t;

    if (state.rest.remaining <= 0) {
      clearInterval(state.rest.interval);
      state.rest.interval = null;
      if (navigator.vibrate) navigator.vibrate([200, 100, 200]);

      if (isFocus) {
        document.getElementById('focus-rest-time').textContent = 'PRÓXIMA SÉRIE';
        document.getElementById('btn-focus-next').style.display = 'block';
        document.getElementById('focus-rest').style.display = 'none';
      } else {
        const modal = document.querySelector('.rest-modal');
        modal.classList.add('rest-finished');
        document.getElementById('timer-display').textContent = 'PRÓXIMA SÉRIE';
        setTimeout(function() {
          modal.classList.remove('rest-finished');
          document.getElementById('rest-overlay').classList.add('hidden');
        }, 1600);
      }
    }
  }, 1000);
}

function stopRest() {
  if (state.rest.interval) {
    clearInterval(state.rest.interval);
    state.rest.interval = null;
  }
  document.getElementById('rest-overlay').classList.add('hidden');
}

function togglePause() {
  state.rest.paused = !state.rest.paused;
  const txt = state.rest.paused ? 'CONTINUAR' : 'PAUSAR';
  const b1 = document.getElementById('btn-pause');
  const b2 = document.getElementById('btn-pause-focus');
  if (b1) b1.textContent = txt;
  if (b2) b2.textContent = txt;
}

function adjustRest(delta) {
  state.rest.remaining = Math.max(0, state.rest.remaining + delta);
  const t = formatTime(state.rest.remaining);
  const d1 = document.getElementById('timer-display');
  const d2 = document.getElementById('focus-rest-time');
  if (d1) d1.textContent = t;
  if (d2) d2.textContent = t;
  if (state.rest.remaining <= 0 && state.rest.interval) {
    clearInterval(state.rest.interval);
    state.rest.interval = null;
  }
}

function skipRest() {
  stopRest();
  // if in focus, show next button
  if (document.getElementById('focus-screen').classList.contains('active')) {
    document.getElementById('focus-rest').style.display = 'none';
    document.getElementById('btn-focus-next').style.display = 'block';
  }
}

// ==================== HISTORY ====================
function renderHistory() {
  const list = document.getElementById('history-list');
  if (state.history.length === 0) {
    list.innerHTML = '<div class="history-empty">Nenhum treino concluído ainda.<br>Finalize um treino para aparecer aqui.</div>';
    return;
  }
  list.innerHTML = '';
  state.history.forEach(h => {
    const item = document.createElement('div');
    item.className = 'history-item';
    item.innerHTML =
      '<div><div class="history-date">' + formatDate(h.date) + ' ✓</div>' +
      '<div class="history-name">' + h.name + '</div></div>' +
      '<div class="history-stats">' + h.exercisesDone + ' exercícios<br>' + h.setsDone + ' séries</div>';
    list.appendChild(item);
  });
}

// ==================== SETTINGS ====================
function updateSettingsUI() {
  document.getElementById('default-rest-display').textContent = state.settings.restSeconds + 's';
  document.querySelectorAll('.preset-btn').forEach(b => {
    b.classList.toggle('active', parseInt(b.dataset.sec) === state.settings.restSeconds);
  });
}

function setRestPreset(sec) {
  state.settings.restSeconds = sec;
  saveData();
  updateSettingsUI();
}

function adjustDefaultRest(delta) {
  state.settings.restSeconds = Math.max(15, Math.min(300, state.settings.restSeconds + delta));
  saveData();
  updateSettingsUI();
}

function resetAllProgress() {
  if (!confirm('Zerar o progresso atual de todos os treinos?')) return;
  state.progress = {};
  state.workouts.forEach(w => { state.progress[w.id] = {}; });
  saveData();
  renderHome();
  alert('Progresso zerado.');
}

function resetHistory() {
  if (!confirm('Apagar todo o histórico e contador de treinos?')) return;
  state.history = [];
  state.totalCompleted = 0;
  saveData();
  updateEvolutionBar();
  alert('Histórico limpo.');
}

// ==================== NOTES ====================
function openNotes(exId) {
  state.notesExId = exId;
  const workout = getWorkout(state.currentId);
  const ex = workout.exercises.find(e => e.id === exId);
  document.getElementById('notes-ex-name').textContent = ex.name;
  document.getElementById('notes-text').value = (state.notes[state.currentId] || {})[exId] || '';
  document.getElementById('notes-overlay').classList.remove('hidden');
}

function closeNotes() {
  document.getElementById('notes-overlay').classList.add('hidden');
  state.notesExId = null;
}

function saveNotes() {
  if (!state.notes[state.currentId]) state.notes[state.currentId] = {};
  const txt = document.getElementById('notes-text').value.trim();
  if (txt) state.notes[state.currentId][state.notesExId] = txt;
  else delete state.notes[state.currentId][state.notesExId];
  saveData();
  closeNotes();
  renderExercises();
}

// ==================== CREATE / MANAGE ====================
function openCreateWorkout() {
  state.renameMode = false;
  state.manageId = null;
  document.getElementById('create-title').textContent = 'NOVO TREINO';
  document.getElementById('btn-create-confirm').textContent = 'CRIAR TREINO';
  document.getElementById('create-name').value = '';
  document.getElementById('create-subtitle').value = '';
  document.getElementById('create-overlay').classList.remove('hidden');
  setTimeout(() => document.getElementById('create-name').focus(), 80);
}

function closeCreate() {
  document.getElementById('create-overlay').classList.add('hidden');
  state.renameMode = false;
}

function confirmCreate() {
  const name = document.getElementById('create-name').value.trim();
  const subtitle = document.getElementById('create-subtitle').value.trim();
  if (!name) { alert('Digite um nome.'); return; }

  if (state.renameMode && state.manageId) {
    const w = getWorkout(state.manageId);
    if (w) { w.name = name; w.subtitle = subtitle; saveData(); }
    closeCreate(); closeManage(); renderHome();
    return;
  }

  const nw = { id: generateId(), name, subtitle, exercises: [] };
  state.workouts.push(nw);
  state.progress[nw.id] = {};
  state.notes[nw.id] = {};
  saveData();
  closeCreate();
  renderHome();
  startWorkout(nw.id);
  setTimeout(() => toggleEditMode(), 250);
}

function openManage(id) {
  state.manageId = id;
  const w = getWorkout(id);
  if (!w) return;
  document.getElementById('manage-name').textContent = w.name;
  document.getElementById('manage-overlay').classList.remove('hidden');
}

function closeManage() {
  document.getElementById('manage-overlay').classList.add('hidden');
  state.manageId = null;
}

function renameCurrentWorkout() {
  const w = getWorkout(state.manageId);
  if (!w) return;
  state.renameMode = true;
  document.getElementById('create-title').textContent = 'RENOMEAR TREINO';
  document.getElementById('btn-create-confirm').textContent = 'SALVAR';
  document.getElementById('create-name').value = w.name;
  document.getElementById('create-subtitle').value = w.subtitle || '';
  document.getElementById('create-overlay').classList.remove('hidden');
}

function deleteCurrentWorkout() {
  const w = getWorkout(state.manageId);
  if (!w) return;
  if (!confirm('Excluir "' + w.name + '"?')) return;
  state.workouts = state.workouts.filter(x => x.id !== state.manageId);
  delete state.progress[state.manageId];
  delete state.notes[state.manageId];
  saveData();
  closeManage();
  renderHome();
}

// ==================== EDIT ====================
function toggleEditMode() {
  if (!state.currentId) return;
  const w = getWorkout(state.currentId);
  if (!w) return;
  state.editBuffer = structuredClone(w.exercises);
  renderEditList();
  document.getElementById('edit-overlay').classList.remove('hidden');
}

function closeEdit() {
  document.getElementById('edit-overlay').classList.add('hidden');
  state.editBuffer = null;
}

function renderEditList() {
  const list = document.getElementById('edit-list');
  list.innerHTML = '';
  if (state.editBuffer.length === 0) {
    list.innerHTML = '<p style="text-align:center;color:var(--text-muted);padding:20px">Nenhum exercício. Adicione!</p>';
    return;
  }
  state.editBuffer.forEach((ex, idx) => {
    const item = document.createElement('div');
    item.className = 'edit-item';
    item.innerHTML =
      '<input type="text" value="' + ex.name + '" onchange="updateEditName(' + idx + ',this.value)" placeholder="Nome">' +
      '<div class="edit-row">' +
        '<input type="number" min="1" max="12" value="' + ex.sets + '" onchange="updateEditSets(' + idx + ',this.value)" placeholder="Séries">' +
        '<input type="text" value="' + ex.reps + '" onchange="updateEditReps(' + idx + ',this.value)" placeholder="Reps / tempo">' +
      '</div>' +
      '<div class="edit-actions-row">' +
        '<button class="btn-move" onclick="moveExercise(' + idx + ',-1)" ' + (idx===0?'disabled':'') + '>↑</button>' +
        '<button class="btn-move" onclick="moveExercise(' + idx + ',1)" ' + (idx===state.editBuffer.length-1?'disabled':'') + '>↓</button>' +
        '<button class="btn-delete" onclick="deleteExercise(' + idx + ')">Remover</button>' +
      '</div>';
    list.appendChild(item);
  });
}

function updateEditName(i, v) { state.editBuffer[i].name = v.trim() || state.editBuffer[i].name; }
function updateEditSets(i, v) { state.editBuffer[i].sets = Math.max(1, Math.min(12, parseInt(v)||3)); }
function updateEditReps(i, v) { state.editBuffer[i].reps = v.trim() || '8–12'; }
function moveExercise(i, d) {
  const n = i + d;
  if (n < 0 || n >= state.editBuffer.length) return;
  const t = state.editBuffer[i]; state.editBuffer[i] = state.editBuffer[n]; state.editBuffer[n] = t;
  renderEditList();
}
function deleteExercise(i) { state.editBuffer.splice(i, 1); renderEditList(); }
function addExercise() {
  state.editBuffer.push({ id: 'ex_' + Date.now(), name: 'Novo exercício', sets: 3, reps: '8–12', type: 'reps' });
  renderEditList();
  document.getElementById('edit-list').scrollTop = 9999;
}

function saveEdits() {
  const w = getWorkout(state.currentId);
  if (!w) return;
  const oldP = state.progress[state.currentId] || {};
  const newP = {};
  state.editBuffer.forEach(ex => {
    if (oldP[ex.id]) {
      newP[ex.id] = Array(ex.sets).fill(null).map((_, i) => oldP[ex.id][i] || { done: false });
    }
  });
  w.exercises = state.editBuffer;
  state.progress[state.currentId] = newP;
  saveData();
  closeEdit();
  renderExercises();
  updateOverallProgress();
}

// ==================== INIT ====================
document.addEventListener('DOMContentLoaded', function() {
  loadData();
  renderHome();
  updateEvolutionBar();
  updateSettingsUI();

  let lastTouch = 0;
  document.addEventListener('touchend', function(e) {
    const now = Date.now();
    if (now - lastTouch <= 300) e.preventDefault();
    lastTouch = now;
  }, { passive: false });
});
