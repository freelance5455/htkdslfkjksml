Salary & OT Calculator v5.4

จุดประสงค์: Android APK สำหรับโปรแกรม Salary & OT Calculator โดยคงหน้าตา/ตรรกะคำนวณของ v5.1

สิ่งที่แก้:
- Save/Load: LocalStorage + native JSON backup ใน internal app storage พร้อมเลือกข้อมูลที่ใหม่กว่าโดย savedAt
- PNG: Android MediaStore -> Downloads/Salary_OT
- PDF A4: Android PdfDocument -> Downloads/Salary_OT (หลายหน้าได้)
- CSV: Android MediaStore -> Downloads/Salary_OT
- Print: Android PrintManager + A4
- ไม่พึ่ง CDN สำหรับการส่งออกใน APK
- Android 10+ ใช้ MediaStore ไม่ต้องขอ storage permission
- Android 9 และต่ำกว่าขอ WRITE_EXTERNAL_STORAGE เมื่อจำเป็น

Build:
เปิดโฟลเดอร์นี้ใน AndroidIDE หรือ Android Studio แล้ว Assemble Debug APK


จุดแก้ไข v5.4
- ส่งออก PNG และ PDF ผ่าน Android Native + MediaStore ลง Downloads/Salary_OT โดยตรง
- ส่งออก CSV ผ่าน Android Native + MediaStore
- พิมพ์รายงานผ่าน Android PrintManager ขนาด A4
- บันทึกข้อมูลสำรองในพื้นที่ภายในแอป และโหลดกลับได้แม้ LocalStorage หาย
- ล้างข้อมูลทั้งหมดจะล้าง Native backup ด้วย
- รองรับ Android 10+ โดยไม่ต้องขอ WRITE_EXTERNAL_STORAGE สำหรับ Downloads
- Android 9 และต่ำกว่าจะขอสิทธิ์เขียนไฟล์เมื่อจำเป็น
