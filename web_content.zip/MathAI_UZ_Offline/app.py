import re
import sympy as sp
from flask import Flask, render_template, request, jsonify
app=Flask(__name__)

def clean(s):
    return s.strip().replace("²","^2").replace("³","^3").replace("−","-").replace("×","*").replace("÷","/").replace("π","pi")

def solve_math(problem, category="Matematika"):
    s=clean(problem)
    if not s: return {"ok":False,"error":"Masalani kiriting."}
    try:
        x=sp.symbols("x")
        if "=" in s:
            a,b=s.split("=",1)
            allowed=r"[0-9xX+\-*/().\s^]+"
            if not re.fullmatch(allowed,a) or not re.fullmatch(allowed,b): raise ValueError
            expr=sp.sympify(a.replace("^","**"))-sp.sympify(b.replace("^","**"))
            sol=sp.solve(expr,x)
            vals=", ".join("x = "+sp.sstr(v) for v in sol) if sol else "Yechim topilmadi."
            steps="\n".join("   x = "+sp.sstr(v) for v in sol) or "   Yechim mavjud emas."
            ans=f"1. Berilgan\n   {problem}\n\n2. Formula/usul\n   Tenglamani soddalashtirib, x ni topamiz.\n\n3. Bosqichma-bosqich yechim\n{steps}\n\n4. Tekshirish\n   SymPy orqali tekshirildi.\n\n5. Yakuniy javob\n   {vals}"
        else:
            expr=sp.sympify(s.replace("^","**"))
            res=sp.simplify(expr)
            ans=f"1. Berilgan\n   {problem}\n\n2. Formula/usul\n   Ifodani soddalashtiramiz.\n\n3. Bosqichma-bosqich yechim\n   {sp.sstr(expr)} = {sp.sstr(res)}\n\n4. Tekshirish\n   Hisoblash SymPy orqali tekshirildi.\n\n5. Yakuniy javob\n   {sp.sstr(res)}"
        return {"ok":True,"answer":ans}
    except Exception:
        return {"ok":False,"error":"Bu masalani offline rejimda tushunib bo‘lmadi. Masalan: 2x + 7 = 19 yoki 3/4 + 5/8."}

@app.get("/")
def index(): return render_template("index.html")
@app.post("/api/solve")
def solve():
    d=request.get_json(silent=True) or {}
    return jsonify(solve_math(d.get("problem",""),d.get("category","Matematika")))
@app.get("/api/health")
def health(): return jsonify({"offline":True,"status":"ready"})
if __name__=="__main__": app.run(host="0.0.0.0",port=5000,debug=False)
