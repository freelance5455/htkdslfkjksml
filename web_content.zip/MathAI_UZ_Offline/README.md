MathAI UZ Offline

Termux:
pip install -r requirements.txt
python app.py

Brauzer: http://127.0.0.1:5000
Server 0.0.0.0 da ishlaydi, shuning uchun bir Wi-Fi tarmog‘idagi qurilmalar lokal IP orqali kira oladi.

Bu ZIP APK emas; APK qilish uchun WebView/Android builder kerak.
