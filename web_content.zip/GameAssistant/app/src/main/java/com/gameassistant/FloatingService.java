package com.gameassistant;
import android.app.*;import android.content.*;import android.graphics.*;import android.graphics.drawable.GradientDrawable;
import android.os.*;import android.view.*;import android.widget.*;
public class FloatingService extends Service{
 WindowManager wm;View hex;TextView panel;WindowManager.LayoutParams lp,pp;Handler h=new Handler(Looper.getMainLooper());
 static class Hex extends View{Paint f=new Paint(Paint.ANTI_ALIAS_FLAG),s=new Paint(Paint.ANTI_ALIAS_FLAG),t=new Paint(Paint.ANTI_ALIAS_FLAG);Path p=new Path();
  Hex(Context c){super(c);setLayerType(LAYER_TYPE_SOFTWARE,null);f.setColor(Color.BLACK);s.setStyle(Paint.Style.STROKE);s.setStrokeWidth(7);s.setColor(Color.rgb(255,40,60));s.setShadowLayer(14,0,0,Color.RED);
   t.setColor(Color.WHITE);t.setTextAlign(Paint.Align.CENTER);t.setFakeBoldText(true);t.setTextSize(34);}
  @Override protected void onDraw(Canvas c){float r=Math.min(getWidth(),getHeight())/2f-14,cx=getWidth()/2f,cy=getHeight()/2f;p.reset();
   for(int i=0;i<6;i++){double a=Math.toRadians(60*i-30);float x=cx+(float)(r*Math.cos(a)),y=cy+(float)(r*Math.sin(a));if(i==0)p.moveTo(x,y);else p.lineTo(x,y);}p.close();
   c.drawPath(p,f);c.drawPath(p,s);c.drawText("COD",cx,cy+12,t);}}
 Runnable tick=new Runnable(){public void run(){Intent i=registerReceiver(null,new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
  int lv=i.getIntExtra(BatteryManager.EXTRA_LEVEL,-1),t=i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,-1);ActivityManager.MemoryInfo m=new ActivityManager.MemoryInfo();
  ((ActivityManager)getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(m);String s="Battery: "+(lv<0?"N/A":lv+"%")+"\nTemp: "+(t<0?"N/A":(t/10.0)+"°C")+"\nRAM free: "+(m.availMem>>20)+" MB";
  if(t>=420)s+="\n⚠ Phone is hot";panel.setText(s);h.postDelayed(this,3000);}};
 @Override public IBinder onBind(Intent i){return null;}
 @Override public int onStartCommand(Intent i,int f,int id){
  if(Build.VERSION.SDK_INT>=26){((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(new NotificationChannel("fa","Floating assistant",NotificationManager.IMPORTANCE_LOW));}
  startForeground(1,new Notification.Builder(this,"fa").setContentTitle("Game Assistant").setContentText("Floating assistant is on").setSmallIcon(android.R.drawable.ic_menu_info_details).build());
  if(hex!=null)return START_NOT_STICKY;wm=(WindowManager)getSystemService(WINDOW_SERVICE);int ty=WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,fl=WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
  hex=new Hex(this);lp=new WindowManager.LayoutParams(170,170,ty,fl,PixelFormat.TRANSLUCENT);lp.gravity=Gravity.TOP|Gravity.START;lp.x=20;lp.y=300;
  panel=new TextView(this);panel.setTextColor(Color.WHITE);panel.setPadding(28,20,28,20);panel.setTextSize(14);GradientDrawable g=new GradientDrawable();g.setColor(Color.argb(235,10,10,12));g.setStroke(3,Color.rgb(255,40,60));g.setCornerRadius(24);panel.setBackground(g);
  pp=new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,ty,fl,PixelFormat.TRANSLUCENT);pp.gravity=Gravity.TOP|Gravity.START;
  panel.setVisibility(View.GONE);wm.addView(panel,pp);wm.addView(hex,lp);
  hex.setOnTouchListener(new View.OnTouchListener(){int sx,sy;float tx,ty2;boolean mv;
   public boolean onTouch(View v,MotionEvent e){switch(e.getAction()){case MotionEvent.ACTION_DOWN:sx=lp.x;sy=lp.y;tx=e.getRawX();ty2=e.getRawY();mv=false;return true;
    case MotionEvent.ACTION_MOVE:float dx=e.getRawX()-tx,dy=e.getRawY()-ty2;if(Math.abs(dx)+Math.abs(dy)>12)mv=true;if(mv){lp.x=sx+(int)dx;lp.y=sy+(int)dy;wm.updateViewLayout(hex,lp);
     pp.x=lp.x+180;pp.y=lp.y;if(panel.getVisibility()==View.VISIBLE)wm.updateViewLayout(panel,pp);}return true;
    case MotionEvent.ACTION_UP:if(!mv){boolean on=panel.getVisibility()==View.VISIBLE;pp.x=lp.x+180;pp.y=lp.y;wm.updateViewLayout(panel,pp);panel.setVisibility(on?View.GONE:View.VISIBLE);}return true;}return false;}});
  h.post(tick);return START_NOT_STICKY;}
 @Override public void onDestroy(){h.removeCallbacks(tick);try{if(hex!=null)wm.removeView(hex);if(panel!=null)wm.removeView(panel);}catch(Exception e){}hex=null;super.onDestroy();}
}
