package com.gameassistant;
import android.app.*;import android.content.*;import android.net.Uri;import android.os.*;import android.provider.Settings;
import android.webkit.*;import android.graphics.Color;import org.json.JSONObject;
public class MainActivity extends Activity{
 WebView w;boolean pending;
 @Override protected void onCreate(Bundle b){super.onCreate(b);
  getWindow().setStatusBarColor(Color.BLACK);getWindow().setNavigationBarColor(Color.BLACK);
  if(Build.VERSION.SDK_INT>=33)requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},1);
  w=new WebView(this);setContentView(w);WebSettings s=w.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);
  s.setAllowFileAccess(false);w.setBackgroundColor(Color.BLACK);w.addJavascriptInterface(new Bridge(),"Android");w.loadUrl("file:///android_asset/index.html");}
 @Override protected void onResume(){super.onResume();if(pending&&Settings.canDrawOverlays(this)){pending=false;startForegroundService(new Intent(this,FloatingService.class));}}
 @Override public void onBackPressed(){if(w.canGoBack())w.goBack();else super.onBackPressed();}
 class Bridge{
  @JavascriptInterface public String getDeviceInfo(){try{JSONObject o=new JSONObject();
   Intent i=registerReceiver(null,new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
   int lv=i.getIntExtra(BatteryManager.EXTRA_LEVEL,-1),sc=i.getIntExtra(BatteryManager.EXTRA_SCALE,100),t=i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,-1),st=i.getIntExtra(BatteryManager.EXTRA_STATUS,-1);
   o.put("battery",lv<0?-1:lv*100/sc);o.put("temp",t<0?-1:t/10.0);o.put("charging",st==BatteryManager.BATTERY_STATUS_CHARGING);
   ActivityManager.MemoryInfo m=new ActivityManager.MemoryInfo();((ActivityManager)getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(m);
   o.put("ramTotal",m.totalMem);o.put("ramFree",m.availMem);
   android.os.StatFs f=new android.os.StatFs(Environment.getDataDirectory().getPath());o.put("storTotal",f.getTotalBytes());o.put("storFree",f.getAvailableBytes());
   o.put("model",Build.MANUFACTURER+" "+Build.MODEL);o.put("android",Build.VERSION.RELEASE);return o.toString();}catch(Exception e){return "{}";}}
  @JavascriptInterface public boolean canOverlay(){return Settings.canDrawOverlays(MainActivity.this);}
  @JavascriptInterface public void startFloating(){runOnUiThread(()->{
   if(!Settings.canDrawOverlays(MainActivity.this)){pending=true;startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));return;}
   startForegroundService(new Intent(MainActivity.this,FloatingService.class));});}
  @JavascriptInterface public void stopFloating(){runOnUiThread(()->stopService(new Intent(MainActivity.this,FloatingService.class)));}
 }}
