# Angelcraftini Copienini 🎮

Juego 2D móvil en HTML5 Canvas, sin librerías externas.

## Ejecutar
Abre `index.html` en un navegador moderno. Para móvil puedes servir la carpeta desde cualquier servidor estático y añadirla a la pantalla de inicio.

## Controles
- Móvil: ◀ ▲ ▶
- Teclado: A/D o ←/→ y W/↑/Espacio

## Empaquetar
Los archivos están pensados para convertirse en una app mediante un wrapper WebView, PWA o cualquier empaquetador HTML5.
