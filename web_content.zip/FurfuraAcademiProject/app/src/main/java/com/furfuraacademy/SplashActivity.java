package com.furfuraacademy;

// Splash Activity placeholder