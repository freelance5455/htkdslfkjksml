package com.dleaf.householdinventory;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.io.File;
import java.io.IOException;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_CAMERA = 41;
    private WebView web;
    private Uri photoUri;
    private TextRecognizer recognizer;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    }

    public class Bridge {
        @JavascriptInterface public void scanPhoto() {
            runOnUiThread(() -> {
                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
                    return;
                }
                launchCamera();
            });
        }
    }

    private void launchCamera() {
        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        File dir = new File(getCacheDir(), "camera"); dir.mkdirs();
        File f = new File(dir, "inventory_scan.jpg");
        photoUri = FileProvider.getUriForFile(this, "com.dleaf.householdinventory.fileprovider", f);
        i.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
        i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivityForResult(i, 42);
    }

    @Override protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req, result, data);
        if (req == 42 && result == RESULT_OK && photoUri != null) {
            try {
                InputImage image = InputImage.fromFilePath(this, photoUri);
                recognizer.process(image).addOnSuccessListener(r -> {
                    String text = r.getText().replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r");
                    web.evaluateJavascript("window.onScanResult(\"" + text + "\")", null);
                    Toast.makeText(this, "Foto berhasil dibaca. Cek hasilnya sebelum simpan.", Toast.LENGTH_LONG).show();
                }).addOnFailureListener(e -> Toast.makeText(this, "Tulisan di foto belum terbaca.", Toast.LENGTH_LONG).show());
            } catch (IOException e) { Toast.makeText(this, "Foto tidak bisa diproses.", Toast.LENGTH_LONG).show(); }
        }
    }

    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r,p,g);
        if(r==REQ_CAMERA){
            if(g.length>0 && g[0]==PackageManager.PERMISSION_GRANTED) launchCamera();
            else Toast.makeText(this, "Izin kamera ditolak. Aktifkan Kamera di Pengaturan aplikasi Dleaf.", Toast.LENGTH_LONG).show();
        }
    }
}
