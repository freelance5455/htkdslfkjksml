لعبة زَاد - مشروع Android Studio جاهز (الإصدار 1.2)
======================================================
المشروع كامل جاهز: لا تحتاج إنشاء مشروع ولا نسخ ملفات ولا أي منصة خارجية.

طريقة استخراج ملف APK:
1) فك ضغط الملف، ثم افتح Android Studio واختر File > Open ثم اختر مجلد "Zad".
2) انتظر انتهاء Gradle Sync (أول مرة يحتاج إنترنت ليحمّل الأدوات تلقائيًا).
3) من القائمة: Build > Build Bundle(s) / APK(s) > Build APK(s)
4) الملف الناتج: app/build/outputs/apk/debug/app-debug.apk  (انقله لهاتفك وثبّته)
   - للنشر على Google Play: Build > Generate Signed Bundle / APK.

ملاحظات:
- اسم التطبيق: app/src/main/res/values/strings.xml  (حاليًا: زاد)
- رقم الإصدار: versionName / versionCode في app/build.gradle (حاليًا 1.2)
- ولعرض رقم الإصدار داخل الإعدادات: عدّل APP_VERSION في app/src/main/assets/index.html
- الأسئلة (300 سؤال): app/src/main/assets/questions.js  (للزيادة أضف أسئلة بنفس الصيغة)
- الأيقونة: استبدل ic_launcher.png في مجلدات res/mipmap-* (أو: كليك يمين على app > New > Image Asset)
- التطبيق يعمل بدون إنترنت.
