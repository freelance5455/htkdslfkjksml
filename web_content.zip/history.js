(function () {
  function syncThemeVariables() {
    const root = document.documentElement;
    root.style.setProperty("--user-bg", localStorage.getItem("bgColor") || "#ccd5ae");
    root.style.setProperty("--user-btn", localStorage.getItem("btnColor") || "#d4a373");
    root.style.setProperty("--user-box", localStorage.getItem("boxColor") || "#e9edc9");
    root.style.setProperty("--user-display", localStorage.getItem("ansowerColor") || "#fefae0");
    root.style.setProperty("--user-text", localStorage.getItem("textColor") || "#5f6650");
    root.style.setProperty("--user-setting", localStorage.getItem("settingBoxColor") || "#faedcd");
    document.body.style.backgroundColor = root.style.getPropertyValue("--user-bg").trim();
  }

  function getEntries() {
    const count = Number(localStorage.getItem("numbers")) || 0;
    const entries = [];
    for (let i = count; i >= 1; i--) {
      const value = localStorage.getItem("Number" + i);
      if (value !== null && value !== "") entries.push(value);
    }
    return entries;
  }

  function render() {
    syncThemeVariables();
    const parent = document.querySelector("#history");
    const countEl = document.querySelector("#historyCount");
    const statusEl = document.querySelector("#historyStatus");
    const entries = getEntries();

    parent.innerHTML = "";
    countEl.textContent = `${entries.length} محاسبه`;
    statusEl.textContent = entries.length ? "آخرین محاسبات در بالا هستند" : "هنوز محاسبه‌ای ذخیره نشده";

    if (!entries.length) {
      const empty = document.createElement("div");
      empty.className = "history-empty";
      empty.innerHTML = '<div class="history-empty-icon">🧮</div><strong>تاریخچه خالی است</strong><span>بعد از زدن «=»، محاسبات اینجا ذخیره می‌شوند.</span>';
      parent.appendChild(empty);
      return;
    }

    const list = document.createElement("div");
    list.className = "history-list";

    entries.forEach((entry) => {
      const item = document.createElement("article");
      item.className = "history-item";

      const parts = String(entry).split("=");
      const exp = parts.length > 1 ? parts.slice(0, -1).join("=") : String(entry);
      const result = parts.length > 1 ? parts[parts.length - 1] : "";

      const expression = document.createElement("div");
      expression.className = "history-expression";
      expression.textContent = exp;

      if (result !== "") {
        const equals = document.createElement("div");
        equals.className = "history-equals";
        equals.textContent = "=";

        const resultEl = document.createElement("div");
        resultEl.className = "history-result";
        resultEl.textContent = result;

        item.append(expression, equals, resultEl);
      } else {
        item.append(expression);
      }

      list.appendChild(item);
    });

    parent.appendChild(list);
  }

  window.clearAll = function () {
    const count = Number(localStorage.getItem("numbers")) || 0;
    for (let i = 1; i <= count; i++) localStorage.removeItem("Number" + i);
    localStorage.removeItem("numbers");
    render();
  };

  render();
  window.addEventListener("storage", render);
})();
