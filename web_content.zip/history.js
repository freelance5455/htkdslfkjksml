function read() {
  let count = Number(localStorage.getItem("numbers")) || 0;
  let parent = document.querySelector("#history");
  parent.innerHTML = "";

  if (count === 0) {
    let p = document.createElement("p");
    p.textContent = "هیچ محاسبه‌ای ذخیره نشده";
    p.style.textAlign = "center";
    p.style.color = "#aaa";
    parent.appendChild(p);
    return;
  }

  for (let i = count; i >= 1; i--) {
    let item = localStorage.getItem("Number" + i);
    if (item) {
      let p = document.createElement("p");
      p.className = "history-item";
      p.textContent = item;
      parent.appendChild(p);
    }
  }
}

function clearAll() {
  let count = Number(localStorage.getItem("numbers")) || 0;
  for (let i = 1; i <= count; i++) {
    localStorage.removeItem("Number" + i);
  }
  localStorage.removeItem("numbers");
  read();
}

read();

/* ===== اعمال تنظیمات ===== */
document.querySelector("body").style.backgroundColor =
  localStorage.getItem("bgColor") || "#ccd5ae";

let btnColor = localStorage.getItem("btnColor") || "#d4a373";
let textColor = localStorage.getItem("textColor") || "#fff";

document.querySelectorAll(".button, .clear-all").forEach(function (el) {
  el.style.backgroundColor = btnColor;
  el.style.borderColor = btnColor;
  el.style.color = textColor;
});

let boxColor = localStorage.getItem("boxColor") || "#e9edc9";
document.querySelectorAll(".main").forEach(function (el) {
  el.style.backgroundColor = boxColor;
  el.style.borderColor = boxColor;
});

let settingBox = localStorage.getItem("settingBoxColor") || "#fefae0";
document.querySelectorAll(".history-box").forEach(function (el) {
  el.style.backgroundColor = settingBox;
});