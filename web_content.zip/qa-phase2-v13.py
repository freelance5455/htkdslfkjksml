from pathlib import Path
import re,json
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parent
html=(root/'index.html').read_text()
for f in ('curriculum-v6.js','curriculum-v7.js','university-v8.js','inquiry-v9.js','kingdom-v10.js','career-v11.js','life-v12.js','curriculum-v13.js','academy-v13.js'):
    html=html.replace(f'<script src="{f}"></script>', '<script>\n'+(root/f).read_text()+'\n</script>')
html=html.replace('<link rel="stylesheet" href="university-v8.css">','<style>'+ (root/'university-v8.css').read_text()+'</style>')
html=html.replace('<link rel="stylesheet" href="inquiry-v9.css">','<style>'+ (root/'inquiry-v9.css').read_text()+'</style>')
html=html.replace('<link rel="stylesheet" href="kingdom-v10.css">','<style>'+ (root/'kingdom-v10.css').read_text()+'</style>')
html=html.replace('<link rel="stylesheet" href="career-v11.css">','<style>'+ (root/'career-v11.css').read_text()+'</style>')
html=html.replace('<link rel="stylesheet" href="life-v12.css">','<style>'+ (root/'life-v12.css').read_text()+'</style>')
html=html.replace('<link rel="stylesheet" href="academy-v13.css">','<style>'+ (root/'academy-v13.css').read_text()+'</style>')
html=re.sub(r'<link rel="preconnect"[^>]*>|<link href="https://fonts.googleapis.com[^>]*>', '',html)

def init_page(browser, backing=None):
    pg=browser.new_page(viewport={'width':390,'height':844})
    errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
    state=backing if backing else {'loonieAcademy_v1':json.dumps({'onboarded':True,'done':{'79':'5/5'},'stars':{'79':3},'checks':{},'notes':{'79':'old note preserved'},'sound':False})}
    pg.evaluate('''db => {
      window.__db=db;
      Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>window.__db[k]??null,setItem:(k,v)=>window.__db[k]=String(v),removeItem:k=>delete window.__db[k],clear:()=>{Object.keys(window.__db).forEach(k=>delete window.__db[k]);}}});
    }''',state)
    pg.set_content(html,wait_until='load',timeout=60000)
    pg.wait_for_timeout(150)
    assert not errors,errors[:5]
    return pg,errors

def route(pg,h):
    pg.evaluate('h => location.hash="#"+h',h)
    pg.wait_for_timeout(75)
    pg.evaluate("route()")
    assert 'Something went wrong' not in pg.locator('#screen').inner_text()

def mark_lessons(pg,i):
    pg.evaluate('''i => { const a=LOONIE_V8.active();for(let id of a.terms[i].lessons){state.done[id]='5/5';state.stars[id]=3;}save(); }''',i)

def answer_all(pg,kind,term):
    result=pg.evaluate('''({kind,term}) => {
       const a=LOONIE_V8.active(),d=a.pr.terms[term].drafts[kind];
       for (let i=0;i<d.qs.length;i++) {
          const q=LOONIE_V8.resolveQ(d.qs[i]);
          document.querySelector(`button[data-n="${i}"][data-choice="${q.a}"]`).click();
       }
       if(kind==='assignment'){
          const t=document.querySelector('#uni-reflect');t.value='I checked my calculations and assumptions against the lesson examples. I would verify records, units and evidence before taking any real action.';t.dispatchEvent(new Event('input',{bubbles:true}));
       }
       const submit=document.querySelector('#uni-submit');if(submit.disabled)throw new Error('Submit disabled '+kind);
       submit.click();return document.querySelector('#screen').innerText.slice(0,220);
    }''',{'kind':kind,'term':term})
    assert 'Assessment passed' in result,result
    print('PASSED:',kind,term,'100%',flush=True)

def do_cap(pg,term):
    result=pg.evaluate('''term=>{
       const a=LOONIE_V8.active(),d=a.pr.terms[term].drafts.capstone;
       for(let i=0;i<4;i++){
          const ta=document.querySelector(`textarea[data-note="${i}"]`);
          ta.value='For this milestone I would document the evidence, identify assumptions and risks, show my calculations or simulation, and request qualified review where needed.';
          ta.dispatchEvent(new Event('input',{bubbles:true}));
          const answer=LOONIE_V8.resolveQ(d.qs[i]).a;
          document.querySelector(`button[data-check="${i}"][data-choice="${answer}"]`).click();
       }
       for(let i=0;i<4;i++)document.querySelector(`button[data-r="${i}"][data-v="4"]`).click();
       const sub=document.querySelector('#uni-cap-submit');if(sub.disabled)throw new Error('Capstone disabled');
       sub.click();return document.querySelector('#screen').innerText.slice(0,230);
    }''',term)
    assert 'Project marked complete' in result,result
    print('PASSED: capstone',term,'100%',flush=True)

with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    pg,errors=init_page(browser)
    val=pg.evaluate('LOONIE_V8.validate()');assert val['ok'] and (val['lessons'],val['subjects'],val['questionCount'])==(807,37,3714),val
    print('CATALOG_OK',val)
    for i in range(4):
       route(pg,f'uni-term-{i}')
       if i>0:
         assert '🔒' in pg.locator('#screen').inner_text(),'Semester gate not shown'
    route(pg,'uni')
    assert pg.locator('#uni-prog').count()==1
    pg.locator('#uni-prog').select_option('trade')
    assert pg.locator('#uni-focus').count()==1
    pg.locator('#uni-focus').select_option('elec')
    assert pg.evaluate('LOONIE_V8.active().id')=='trade:elec'
    pg.locator('#uni-prog').select_option('open')
    pg.locator('#uni-focus').select_option('biology' if False else 'bio')
    assert pg.evaluate('LOONIE_V8.active().id')=='open:bio'
    pg.locator('#uni-prog').select_option('acct')
    route(pg,'uni-term-0')
    assert not pg.locator('a[href="#uni-assess-assignment-0"]').count(),'Assignment must be gated'
    # Existing lessons count. Complete target lessons using old engine history as fixture.
    mark_lessons(pg,0)
    route(pg,'uni-term-0')
    assert pg.locator('a[href="#uni-assess-assignment-0"]').count()==1
    route(pg,'uni-assess-assignment-0')
    failure=pg.evaluate('''() => {
       const d=LOONIE_V8.active().pr.terms[0].drafts.assignment;
       for(let i=0;i<d.qs.length;i++){
          const wrong=(LOONIE_V8.resolveQ(d.qs[i]).a+1)%4;
          document.querySelector(`button[data-n="${i}"][data-choice="${wrong}"]`).click();
       }
       const ta=document.querySelector('#uni-reflect');ta.value='I need to recheck the evidence, understand my errors and retry using the worked examples.';ta.dispatchEvent(new Event('input',{bubbles:true}));
       document.querySelector('#uni-submit').click();
       return L O O N I E;
    }'''.replace('L O O N I E','0'))
    assert not pg.evaluate('LOONIE_V8.passes ? L O O N I E : LOONIE_V8.gate(LOONIE_V8.active(),0,"exam")'.replace('L O O N I E','false'))
    assert pg.evaluate('LOONIE_V8.score(LOONIE_V8.active(),0,"assignment")')==0
    route(pg,'uni-assess-assignment-0');answer_all(pg,'assignment',0)
    assert pg.evaluate('LOONIE_V8.active().pr.terms[0].results.assignment.history.length')==2
    route(pg,'uni-term-0');assert pg.locator('a[href="#uni-assess-exam-0"]').count()==1
    route(pg,'uni-assess-exam-0')
    # Draft persists after answer/return route.
    pg.locator('button[data-n="0"]').first.click()
    pg.evaluate('location.hash="#uni-term-0"')
    pg.wait_for_timeout(70)
    route(pg,'uni-assess-exam-0')
    assert pg.evaluate('Object.keys(LOONIE_V8.active().pr.terms[0].drafts.exam.answers).length')==1,'Exam draft not resumed'
    answer_all(pg,'exam',0)
    route(pg,'uni-term-0');assert pg.locator('a[href="#uni-capstone-0"]').count()==1
    route(pg,'uni-capstone-0');do_cap(pg,0)
    route(pg,'uni-term-1');assert '🔒' not in pg.locator('#screen').inner_text().split('Semester study plan')[0]
    assert pg.evaluate('LOONIE_V8.finished(LOONIE_V8.active(),0)')
    route(pg,'uni-transcript')
    assert '100%' in pg.locator('#screen').inner_text()
    assert pg.locator('#uni-csv').count()==1 and pg.locator('#uni-json').count()==1
    # Actually download the local transcript files and check their contents.
    with pg.expect_download(timeout=10000) as dl:
        pg.locator('#uni-csv').click()
    downloaded=dl.value
    assert downloaded.suggested_filename.endswith('.csv')
    csv=Path(downloaded.path()).read_text()
    assert 'UNOFFICIAL' in csv and 'Financial Foundations' in csv
    with pg.expect_download(timeout=10000) as dl:
        pg.locator('#uni-json').click()
    exported=json.loads(Path(dl.value.path()).read_text())
    assert exported['saved']['terms']['0']['results']['assignment']['best']==100
    print('CSV_JSON_EXPORT_OK')
    print('TRANSCRIPT:',pg.locator('#screen').inner_text()[:350].replace('\n',' '))
    # Finish all remaining semesters via real UI input and grading.
    for term in [1,2,3]:
       mark_lessons(pg,term)
       route(pg,f'uni-assess-assignment-{term}');answer_all(pg,'assignment',term)
       route(pg,f'uni-assess-exam-{term}');answer_all(pg,'exam',term)
       route(pg,f'uni-capstone-{term}');do_cap(pg,term)
       assert pg.evaluate('i=>LOONIE_V8.finished(LOONIE_V8.active(),i)',term)
    route(pg,'uni-transcript')
    assert '4/4' in pg.locator('#screen').inner_text()
    assert pg.evaluate('Object.keys(state.university.plans).length')>=3,'Other pathways lost'
    data=pg.evaluate('({legacy:state.done[79],notes:state.notes[79],uni:state.university,backup:makeBackup()})')
    assert data['legacy']=='5/5' and data['notes']=='old note preserved'
    restored=json.loads(data['backup'])['state'];assert 'university' in restored
    pg.screenshot(path=str(root/'qa-university-transcript-phone.png'),full_page=True)
    print('ALL_4_SEMESTERS_PASS 100%')
    print('UNIVERSITY_BACKUP_CHECKSUM',pg.evaluate('parseBackup(makeBackup()).app'))
    print('OVERALL JS_ERRORS',errors)
    db=pg.evaluate('window.__db')
    pg.close()
    pg2,errors2=init_page(browser,db)
    route(pg2,'uni-transcript')
    assert pg2.evaluate('LOONIE_V8.active().terms.every((t,i)=>LOONIE_V8.finished(LOONIE_V8.active(),i))')
    assert pg2.evaluate('state.done[79]')=='5/5'
    print('RELOAD_PERSISTENCE_OK')
    # Backup-to-old-version compatibility: original user data import still migrates.
    pg2.evaluate('''() => {const old={done:{79:'5/5'},checks:{},onboarded:true};
    const st=migrate(old);for(const k in state)delete state[k];Object.assign(state,st);save();}''')
    route(pg2,'uni')
    assert pg2.evaluate('LOONIE_V8.validate().ok')
    assert pg2.evaluate('state.done[79]')=='5/5'
    print('LEGACY_RESTORE_BACKWARD_COMPAT_OK')
    assert not (errors or errors2),errors+errors2
    browser.close()
print('ALL TESTS PASSED')
