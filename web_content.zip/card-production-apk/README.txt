Card Production Schedule - Offline APK Ready
============================================

IMPORTANTE: Huwag gamitin ang AppsGeyser kung blank screen ang result.

Mas magandang converters (mas reliable para sa offline HTML):

1. https://www.htmltoapk.dev/     ← subukan muna ito
2. https://www.htmltoapp.dev/

Paano:
- Upload ang index.html (o ang ZIP na ito)
- App Name: Card Production Schedule
- Package: com.card.production.schedule
- Build → Download APK

Dapat offline at gumagana ang calendar + notes.
