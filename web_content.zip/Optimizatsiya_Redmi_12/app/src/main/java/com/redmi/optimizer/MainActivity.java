package com.redmi.optimizer;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new DeviceActions(), "Android");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }
    private class DeviceActions {
        @JavascriptInterface public String deviceInfo() {
            return Build.MANUFACTURER + " " + Build.MODEL + " • Android " + Build.VERSION.RELEASE;
        }
        @JavascriptInterface public void openDisplay() { open(Settings.ACTION_DISPLAY_SETTINGS); }
        @JavascriptInterface public void openBattery() { open(Settings.ACTION_BATTERY_SAVER_SETTINGS); }
        @JavascriptInterface public void openApps() { open(Settings.ACTION_APPLICATION_SETTINGS); }
        @JavascriptInterface public void openWifi() { open(Settings.ACTION_WIFI_SETTINGS); }
        @JavascriptInterface public void openDeveloper() { open(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS); }
        @JavascriptInterface public void openSettings() { open(Settings.ACTION_SETTINGS); }
        @JavascriptInterface public void showMessage(String msg) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show());
        }
        private void open(String action) {
            runOnUiThread(() -> {
                try { startActivity(new Intent(action)); }
                catch (Exception e) {
                    startActivity(new Intent(Settings.ACTION_SETTINGS));
                    Toast.makeText(MainActivity.this, "Tela indisponível neste aparelho.", Toast.LENGTH_LONG).show();
                }
            });
        }
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
