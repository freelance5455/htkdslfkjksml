# SPARRING+ — prototype Android

Prototype Android simple avec une interface WebView locale, sans compte et sans réseau. L'application comprend :
- schémas corporels de face et de dos, avec zones sélectionnables;
- type de frappe ou incident, mécanisme de blessure et blessure suspectée;
- douleur, gonflement, mobilité et date approximative;
- avertissements de prudence et historique local sur l'appareil.

## Ouvrir le projet
1. Installe Android Studio sur un ordinateur.
2. Ouvre le dossier `SparringPlusAndroid` dans Android Studio.
3. Laisse Gradle synchroniser le projet.
4. Lance l'application sur un émulateur ou un téléphone Android en mode développeur.

## Créer un APK
Dans Android Studio : **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
Le fichier APK est généré dans `app/build/outputs/apk/debug/`.

## Limites importantes
Ceci est un prototype fonctionnel, pas une application médicale validée. Il ne diagnostique pas et ne calcule pas automatiquement un délai de guérison. Les zones anatomiques sont schématiques et doivent être testées/améliorées avant diffusion. Les données sont stockées localement dans le WebView et ne sont pas chiffrées; ne pas y enregistrer d'informations médicales sensibles. Il faudra faire vérifier les conseils médicaux par un professionnel avant publication.
