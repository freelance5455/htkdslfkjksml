# Afzal School Management Portal — MVP Demo

## Included
- Responsive school dashboard
- Student, teacher, class, fee, exam and attendance screens
- Add/edit/delete records
- Search and print
- Fee amounts in Pakistani rupees (PKR)
- Attendance saved by date
- Basic result report printing
- Demo login with two roles

## Run locally
1. Extract the ZIP.
2. Open `index.html` in a modern browser (Chrome, Edge, Firefox).
3. Demo admin login: `admin` / `admin123`
4. Demo teacher login: `teacher` / `teacher123`

A local web server is preferable for testing. If Python is installed, open a terminal in this folder and run:
`python -m http.server 8000`
Then visit `http://localhost:8000`.

## Important limitations
This is a front-end MVP prototype, not production-ready school software:
- Records are stored in this browser's localStorage, not a central database. They won't sync between devices and can be cleared by the browser.
- Login credentials are hard-coded in client-side JavaScript and are NOT secure authentication.
- Role restrictions are only demo UI restrictions and can be bypassed.
- There are no server backups, audit logs, multi-user synchronization, or production-grade authorization.

Do not enter real student data into this demo.

## Publish a preview online
You can publish this static demo to a static hosting service such as Netlify or GitHub Pages by uploading the `index.html` file or deploying this folder. That only publishes the demo and does not make its storage or login secure.

## Before real school use
Replace the localStorage layer with a server database (for example PostgreSQL via Supabase), use Supabase Auth or another trusted identity provider, enforce permissions in database row-level security policies, enable HTTPS, configure backups, validate inputs server-side, and test with synthetic data. Do not store student records until those controls are in place.
