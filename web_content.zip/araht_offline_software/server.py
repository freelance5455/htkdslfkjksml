
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
import sqlite3, json, os, socket
from urllib.parse import urlparse
from datetime import datetime

ROOT = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(ROOT, "araht_data.sqlite3")
HOST = "0.0.0.0"
PORT = 8765

def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    con.executescript("""
    CREATE TABLE IF NOT EXISTS parties(
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT DEFAULT '',
      kind TEXT DEFAULT 'کسان', notes TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS entries(
      id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT NOT NULL, entry_type TEXT NOT NULL,
      party_id INTEGER, item TEXT DEFAULT '', bags REAL DEFAULT 0, weight_kg REAL DEFAULT 0,
      rate REAL DEFAULT 0, gross REAL DEFAULT 0, deduction REAL DEFAULT 0, net REAL DEFAULT 0,
      notes TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(party_id) REFERENCES parties(id));
    CREATE TABLE IF NOT EXISTS supplies(
      id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT NOT NULL, destination TEXT DEFAULT 'منڈی',
      party TEXT DEFAULT '', vehicle TEXT DEFAULT '', driver TEXT DEFAULT '', item TEXT DEFAULT '',
      bags REAL DEFAULT 0, dispatch_kg REAL DEFAULT 0, received_kg REAL DEFAULT 0,
      purchase_cost REAL DEFAULT 0, sale_amount REAL DEFAULT 0, commission_income REAL DEFAULT 0,
      freight REAL DEFAULT 0, loading REAL DEFAULT 0, unloading REAL DEFAULT 0, market_fee REAL DEFAULT 0,
      other_expenses REAL DEFAULT 0, shortage_kg REAL DEFAULT 0, received_amount REAL DEFAULT 0,
      notes TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS cashbook(
      id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT NOT NULL, party TEXT DEFAULT '',
      direction TEXT NOT NULL, amount REAL DEFAULT 0, description TEXT DEFAULT '',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    """)
    return con

def asdict(row):
    return dict(row) if row else None

class Handler(BaseHTTPRequestHandler):
    def send_json(self, obj, code=200):
        raw = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code); self.send_header("Content-Type","application/json; charset=utf-8")
        self.send_header("Content-Length",str(len(raw))); self.send_header("Access-Control-Allow-Origin","*")
        self.end_headers(); self.wfile.write(raw)
    def body(self):
        n=int(self.headers.get("Content-Length","0"))
        return json.loads(self.rfile.read(n).decode("utf-8")) if n else {}
    def do_GET(self):
        path=urlparse(self.path).path
        if path=="/" or path=="/logo.png":
            filename = "index.html" if path=="/" else "logo.png"
            try:
                with open(os.path.join(ROOT,filename),"rb") as f: data=f.read()
                ctype = "text/html; charset=utf-8" if filename.endswith("html") else "image/png"
                self.send_response(200); self.send_header("Content-Type",ctype)
                self.send_header("Content-Length",str(len(data))); self.end_headers(); self.wfile.write(data)
            except FileNotFoundError: self.send_error(500,filename+" missing")
            return
        con=db()
        try:
            if path=="/api/parties":
                rows=con.execute("SELECT * FROM parties ORDER BY id DESC").fetchall(); self.send_json([asdict(x) for x in rows])
            elif path=="/api/entries":
                rows=con.execute("""SELECT entries.*, parties.name party_name FROM entries LEFT JOIN parties ON parties.id=entries.party_id ORDER BY entries.id DESC""").fetchall(); self.send_json([asdict(x) for x in rows])
            elif path=="/api/supplies":
                rows=con.execute("SELECT * FROM supplies ORDER BY id DESC").fetchall(); self.send_json([asdict(x) for x in rows])
            elif path=="/api/cashbook":
                rows=con.execute("SELECT * FROM cashbook ORDER BY id DESC").fetchall(); self.send_json([asdict(x) for x in rows])
            elif path=="/api/summary":
                entries=con.execute("SELECT COALESCE(SUM(gross),0) gross, COALESCE(SUM(deduction),0) deductions FROM entries").fetchone()
                sup=con.execute("""SELECT COALESCE(SUM(sale_amount+commission_income),0) income,
                  COALESCE(SUM(purchase_cost+freight+loading+unloading+market_fee+other_expenses),0) costs,
                  COALESCE(SUM(received_amount),0) received,
                  COALESCE(SUM(dispatch_kg),0) dispatch, COALESCE(SUM(received_kg),0) arrived,
                  COALESCE(SUM(shortage_kg),0) shortage FROM supplies""").fetchone()
                cash=con.execute("""SELECT COALESCE(SUM(CASE WHEN direction='آمد' THEN amount ELSE 0 END),0) cash_in,
                  COALESCE(SUM(CASE WHEN direction='خرچ' THEN amount ELSE 0 END),0) cash_out FROM cashbook""").fetchone()
                self.send_json({"entries":asdict(entries),"supplies":asdict(sup),"cashbook":asdict(cash),
                  "profit":float(sup["income"] or 0)-float(sup["costs"] or 0)})
            elif path=="/api/backup":
                with open(DB,"rb") as f: data=f.read()
                self.send_response(200); self.send_header("Content-Type","application/octet-stream")
                self.send_header("Content-Disposition",'attachment; filename="araht_data.sqlite3"')
                self.send_header("Content-Length",str(len(data))); self.end_headers(); self.wfile.write(data); return
            else: self.send_error(404)
        finally: con.close()
    def do_POST(self):
        path=urlparse(self.path).path; data=self.body(); con=db()
        try:
            if path=="/api/parties":
                con.execute("INSERT INTO parties(name,phone,kind,notes) VALUES(?,?,?,?)",
                  (data.get("name","").strip(),data.get("phone",""),data.get("kind","کسان"),data.get("notes","")))
            elif path=="/api/entries":
                con.execute("""INSERT INTO entries(date,entry_type,party_id,item,bags,weight_kg,rate,gross,deduction,net,notes)
                  VALUES(?,?,?,?,?,?,?,?,?,?,?)""", tuple(data.get(k) for k in ["date","entry_type","party_id","item","bags","weight_kg","rate","gross","deduction","net","notes"]))
            elif path=="/api/supplies":
                keys=["date","destination","party","vehicle","driver","item","bags","dispatch_kg","received_kg","purchase_cost","sale_amount","commission_income","freight","loading","unloading","market_fee","other_expenses","shortage_kg","received_amount","notes"]
                con.execute("INSERT INTO supplies("+",".join(keys)+") VALUES("+",".join("?" for _ in keys)+")",tuple(data.get(k,0 if k not in ["date","destination","party","vehicle","driver","item","notes"] else "") for k in keys))
            elif path=="/api/cashbook":
                con.execute("INSERT INTO cashbook(date,party,direction,amount,description) VALUES(?,?,?,?,?)",
                  (data.get("date"),data.get("party",""),data.get("direction","آمد"),data.get("amount",0),data.get("description","")))
            else: self.send_error(404); return
            con.commit(); self.send_json({"ok":True,"id":con.execute("SELECT last_insert_rowid()").fetchone()[0]})
        except Exception as e:
            con.rollback(); self.send_json({"ok":False,"error":str(e)},400)
        finally: con.close()
    def do_DELETE(self):
        path=urlparse(self.path).path
        table={"parties":"parties","entries":"entries","supplies":"supplies","cashbook":"cashbook"}.get(path.split("/")[2] if len(path.split("/"))>2 else "")
        try: ident=int(path.rsplit("/",1)[1])
        except: self.send_error(400); return
        if not table: self.send_error(404); return
        con=db()
        try:
            con.execute(f"DELETE FROM {table} WHERE id=?",(ident,)); con.commit(); self.send_json({"ok":True})
        finally: con.close()
    def log_message(self, *args): pass

if __name__=="__main__":
    db().close()
    s=ThreadingHTTPServer((HOST,PORT),Handler)
    try:
        hn=socket.gethostname()
        ips=sorted({x[4][0] for x in socket.getaddrinfo(hn,None) if x[0]==socket.AF_INET and not x[4][0].startswith("127.")})
    except: ips=[]
    print("\nآڑھت آف لائن سافٹ ویئر چل رہا ہے")
    print("اسی کمپیوٹر پر: http://127.0.0.1:%s"%PORT)
    print("اسی Wi-Fi پر موبائل/دوسرے کمپیوٹر سے: http://COMPUTER-IP:%s"%PORT)
    print("کمپیوٹر کا IP دیکھنے کے لیے Windows میں ipconfig چلائیں۔")
    print("بند کرنے کے لیے Ctrl+C دبائیں.\n")
    s.serve_forever()
