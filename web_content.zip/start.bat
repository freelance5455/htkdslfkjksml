@echo off
cd /d "%~dp0"
echo Instalando/verificando dependencias...
npm install
if errorlevel 1 (
  echo.
  echo Nao foi possivel instalar as dependencias.
  pause
  exit /b 1
)
echo.
echo Iniciando EcoColeta Multiplayer...
npm start
pause
