@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Kartino Server

echo.
echo ========================================
echo        KARTINO - Offline Server
echo ========================================
echo.

where node >nul 2>&1
if errorlevel 1 (
  echo ERROR: Node.js is not installed.
  echo Download from: https://nodejs.org
  echo.
  pause
  exit /b 1
)

python build.py 2>nul || python3 build.py 2>nul

if "%ADMIN_PASSWORD%"=="" set ADMIN_PASSWORD=kartinoasmin
if "%ADMIN_USERNAME%"=="" set ADMIN_USERNAME=mahdi689

echo  Admin username : %ADMIN_USERNAME%
echo  Admin password : %ADMIN_PASSWORD%
echo  Site address   : http://localhost:8080
echo.
echo  Starting... (Press Ctrl+C to stop)
echo.

node server.js
echo.
echo Server stopped.
pause
