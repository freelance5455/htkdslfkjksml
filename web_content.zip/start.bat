@echo off
title ASION AI - Google Agent
color 0A
echo.
echo  ╔══════════════════════════════════════╗
echo  ║      ASION AI - Google Agent         ║
echo  ║   Ollama + Puppeteer + Node.js       ║
echo  ╚══════════════════════════════════════╝
echo.

:: Cek Node.js
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Node.js tidak ditemukan!
    echo Download di: https://nodejs.org
    pause
    exit /b 1
)

:: Cek Ollama
where ollama >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Ollama tidak ditemukan!
    echo Download di: https://ollama.com
    pause
    exit /b 1
)

echo [1/4] Memulai Ollama...
start "Ollama Server" /min cmd /c "ollama serve"
timeout /t 3 /nobreak >nul

echo [2/4] Menarik model qwen2.5:7b (skip jika sudah ada)...
ollama pull qwen2.5:7b

echo [3/4] Install dependensi Node.js...
if not exist node_modules (
    npm install
    echo [3b] Install browser Puppeteer...
    npx puppeteer browsers install chrome
)

echo [4/4] Menjalankan server...
echo.
echo  Server: http://localhost:3000
echo  Tekan Ctrl+C untuk berhenti
echo.
start "" http://localhost:3000
node server.js
pause
