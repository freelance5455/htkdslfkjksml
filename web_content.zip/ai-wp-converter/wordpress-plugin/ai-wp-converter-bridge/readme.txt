=== AI Website Converter Bridge ===
Requires at least: 6.2
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 0.1.0
License: GPLv2 or later

Companion plugin for the AI Website to WordPress Converter.

== Description ==

* REST endpoint `POST /wp-json/aiwpc/v1/pages` creates a **draft** page from converted Gutenberg / Kadence block markup.
  Publishing requires `status=publish` **and** `confirm_publish=true`, plus the `publish_pages` capability.
* Stores the optional page CSS (sanitized, max 50 KB) and loads it only on that page (front end and editor).
* Optional image import: downloads external images referenced by the blocks into the Media Library and rewrites the URLs
  (requires `upload_files`; uses WordPress' own safe download rules).
* Tools → AI Converter Import: paste block markup + CSS to create a draft without the web app.

Authentication: WordPress Application Passwords (Users → Profile → Application Passwords). Use an Editor account.

== Endpoint ==

POST /wp-json/aiwpc/v1/pages
  title (string, required)
  content (string, required — block markup)
  css (string)
  status ("draft" | "publish", default "draft")
  confirm_publish (bool)
  import_images (bool)
  source_url (string)

GET /wp-json/aiwpc/v1/status — plugin version and whether Kadence Blocks is active.
