<?php
/**
 * Plugin Name:       AI Website Converter Bridge
 * Description:       Companion plugin for the AI Website to WordPress Converter. Creates draft pages from converted Gutenberg/Kadence block markup (REST API or Tools screen), attaches the page CSS, and can import images into the Media Library.
 * Version:           0.1.0
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            WPConvert AI
 * License:           GPL-2.0-or-later
 * Text Domain:       aiwpc
 */

defined( 'ABSPATH' ) || exit;

final class AIWPC_Bridge {

	const VERSION   = '0.1.0';
	const META_CSS  = '_aiwpc_css';
	const META_SRC  = '_aiwpc_source_url';
	const MAX_CSS   = 51200;   // 50 KB.
	const MAX_HTML  = 2097152; // 2 MB.
	const MAX_IMAGES = 40;

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_page_css' ) );
		add_action( 'enqueue_block_editor_assets', array( __CLASS__, 'enqueue_editor_css' ) );
		add_action( 'admin_menu', array( __CLASS__, 'admin_menu' ) );
		add_action( 'admin_post_aiwpc_import', array( __CLASS__, 'handle_admin_import' ) );
	}

	/* ------------------------------------------------------------------ REST */

	public static function register_routes() {
		register_rest_route(
			'aiwpc/v1',
			'/pages',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'rest_create_page' ),
				'permission_callback' => function () {
					return current_user_can( 'edit_pages' );
				},
				'args'                => array(
					'title'           => array( 'type' => 'string', 'required' => true ),
					'content'         => array( 'type' => 'string', 'required' => true ),
					'css'             => array( 'type' => 'string', 'default' => '' ),
					'status'          => array( 'type' => 'string', 'enum' => array( 'draft', 'publish' ), 'default' => 'draft' ),
					'confirm_publish' => array( 'type' => 'boolean', 'default' => false ),
					'import_images'   => array( 'type' => 'boolean', 'default' => false ),
					'source_url'      => array( 'type' => 'string', 'default' => '' ),
				),
			)
		);
		register_rest_route(
			'aiwpc/v1',
			'/status',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => function () {
					return array(
						'plugin'          => 'ai-wp-converter-bridge',
						'version'         => self::VERSION,
						'kadence_blocks'  => defined( 'KADENCE_BLOCKS_VERSION' ) ? KADENCE_BLOCKS_VERSION : null,
						'can_edit_pages'  => current_user_can( 'edit_pages' ),
					);
				},
				'permission_callback' => function () {
					return is_user_logged_in();
				},
			)
		);
	}

	public static function rest_create_page( WP_REST_Request $request ) {
		$status = $request->get_param( 'status' );
		if ( 'publish' === $status ) {
			if ( ! $request->get_param( 'confirm_publish' ) ) {
				return new WP_Error( 'aiwpc_publish_needs_confirmation', __( 'Publishing requires confirm_publish=true. Pages are created as drafts by default.', 'aiwpc' ), array( 'status' => 400 ) );
			}
			if ( ! current_user_can( 'publish_pages' ) ) {
				return new WP_Error( 'aiwpc_cannot_publish', __( 'Your account cannot publish pages.', 'aiwpc' ), array( 'status' => 403 ) );
			}
		}
		$result = self::create_page(
			array(
				'title'         => $request->get_param( 'title' ),
				'content'       => $request->get_param( 'content' ),
				'css'           => $request->get_param( 'css' ),
				'status'        => $status,
				'import_images' => (bool) $request->get_param( 'import_images' ),
				'source_url'    => $request->get_param( 'source_url' ),
			)
		);
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		return new WP_REST_Response( $result, 201 );
	}

	/* --------------------------------------------------------------- Core */

	/**
	 * Creates the page. Content goes through wp_insert_post, so the usual kses filtering applies
	 * to users without the unfiltered_html capability.
	 *
	 * @return array|WP_Error
	 */
	public static function create_page( array $args ) {
		$content = (string) $args['content'];
		if ( '' === trim( $content ) ) {
			return new WP_Error( 'aiwpc_empty', __( 'No block content was provided.', 'aiwpc' ), array( 'status' => 400 ) );
		}
		if ( strlen( $content ) > self::MAX_HTML ) {
			return new WP_Error( 'aiwpc_too_large', __( 'Content is larger than 2 MB.', 'aiwpc' ), array( 'status' => 413 ) );
		}
		if ( false === strpos( $content, '<!-- wp:' ) ) {
			return new WP_Error( 'aiwpc_not_blocks', __( 'Content must be Gutenberg block markup (it should contain <!-- wp: --> comments).', 'aiwpc' ), array( 'status' => 400 ) );
		}
		$blocks = parse_blocks( $content );
		$named  = array_filter(
			$blocks,
			function ( $b ) {
				return ! empty( $b['blockName'] );
			}
		);
		if ( empty( $named ) ) {
			return new WP_Error( 'aiwpc_not_blocks', __( 'No blocks could be parsed from the content.', 'aiwpc' ), array( 'status' => 400 ) );
		}

		$status  = in_array( $args['status'], array( 'draft', 'publish' ), true ) ? $args['status'] : 'draft';
		$post_id = wp_insert_post(
			wp_slash(
				array(
					'post_type'    => 'page',
					'post_status'  => 'draft', // Always start as draft; publish (if confirmed) after images are processed.
					'post_title'   => sanitize_text_field( $args['title'] ? $args['title'] : __( 'Converted page', 'aiwpc' ) ),
					'post_content' => $content,
				)
			),
			true
		);
		if ( is_wp_error( $post_id ) ) {
			return $post_id;
		}

		$css = self::sanitize_css( (string) $args['css'] );
		if ( '' !== $css ) {
			update_post_meta( $post_id, self::META_CSS, wp_slash( $css ) );
		}
		$source = esc_url_raw( (string) $args['source_url'] );
		if ( $source ) {
			update_post_meta( $post_id, self::META_SRC, $source );
		}

		$imported = 0;
		$failed   = array();
		if ( ! empty( $args['import_images'] ) && current_user_can( 'upload_files' ) ) {
			list( $content, $imported, $failed ) = self::import_images( $content, $post_id );
			if ( $imported ) {
				wp_update_post( wp_slash( array( 'ID' => $post_id, 'post_content' => $content ) ) );
			}
		}

		if ( 'publish' === $status ) {
			wp_update_post( array( 'ID' => $post_id, 'post_status' => 'publish' ) );
		}

		return array(
			'id'              => $post_id,
			'status'          => get_post_status( $post_id ),
			'edit_url'        => get_edit_post_link( $post_id, 'raw' ),
			'preview_url'     => get_preview_post_link( $post_id ),
			'blocks'          => count( $named ),
			'css_attached'    => '' !== $css,
			'images_imported' => $imported,
			'images_failed'   => $failed,
		);
	}

	/** Plain CSS only: no markup, no @import, no remote fonts/behaviors, size-limited. */
	public static function sanitize_css( $css ) {
		$css = wp_strip_all_tags( $css );
		$css = preg_replace( '/@import[^;]*;?/i', '', $css );
		$css = preg_replace( '/(expression\s*\(|behavior\s*:|javascript:|-moz-binding)/i', '', $css );
		$css = str_ireplace( '</style', '', $css );
		return substr( trim( $css ), 0, self::MAX_CSS );
	}

	/**
	 * Downloads external images referenced by the blocks into the Media Library and rewrites their URLs.
	 *
	 * @return array{0:string,1:int,2:array}
	 */
	public static function import_images( $content, $post_id ) {
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$home      = wp_parse_url( home_url() );
		$home_key  = strtolower( ( $home['host'] ?? '' ) . ':' . ( $home['port'] ?? '' ) );
		preg_match_all( '#https?://[^\s"\'<>()\\\\]+\.(?:jpe?g|png|gif|webp|avif)(?:\?[^\s"\'<>()\\\\]*)?#i', $content, $m );
		$urls = array_slice( array_unique( $m[0] ), 0, self::MAX_IMAGES );

		$count  = 0;
		$failed = array();
		foreach ( $urls as $url ) {
			$decoded = html_entity_decode( $url );
			$parts = wp_parse_url( $decoded );
			if ( strtolower( ( $parts['host'] ?? '' ) . ':' . ( $parts['port'] ?? '' ) ) === $home_key ) {
				continue; // Already on this site.
			}
			$new = media_sideload_image( $decoded, $post_id, null, 'src' );
			if ( is_wp_error( $new ) ) {
				$failed[] = array( 'url' => $decoded, 'error' => $new->get_error_message() );
				continue;
			}
			$content = str_replace( array( $url, str_replace( '/', '\/', $url ) ), array( $new, str_replace( '/', '\/', $new ) ), $content );
			++$count;
		}
		return array( $content, $count, $failed );
	}

	/* --------------------------------------------------------------- CSS output */

	private static function css_for( $post_id ) {
		$css = get_post_meta( $post_id, self::META_CSS, true );
		return is_string( $css ) ? self::sanitize_css( $css ) : '';
	}

	public static function enqueue_page_css() {
		if ( ! is_singular() ) {
			return;
		}
		$css = self::css_for( get_queried_object_id() );
		if ( '' === $css ) {
			return;
		}
		wp_register_style( 'aiwpc-page', false, array(), self::VERSION );
		wp_enqueue_style( 'aiwpc-page' );
		wp_add_inline_style( 'aiwpc-page', $css );
	}

	public static function enqueue_editor_css() {
		$post = get_post();
		if ( ! $post ) {
			return;
		}
		$css = self::css_for( $post->ID );
		if ( '' === $css ) {
			return;
		}
		wp_register_style( 'aiwpc-editor', false, array(), self::VERSION );
		wp_enqueue_style( 'aiwpc-editor' );
		wp_add_inline_style( 'aiwpc-editor', $css );
	}

	/* --------------------------------------------------------------- Admin screen */

	public static function admin_menu() {
		add_management_page(
			__( 'AI Converter Import', 'aiwpc' ),
			__( 'AI Converter Import', 'aiwpc' ),
			'edit_pages',
			'aiwpc-import',
			array( __CLASS__, 'render_admin_page' )
		);
	}

	public static function render_admin_page() {
		if ( ! current_user_can( 'edit_pages' ) ) {
			return;
		}
		$notice = isset( $_GET['aiwpc_notice'] ) ? sanitize_text_field( wp_unslash( $_GET['aiwpc_notice'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$post   = isset( $_GET['aiwpc_post'] ) ? absint( $_GET['aiwpc_post'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'AI Converter Import', 'aiwpc' ); ?></h1>
			<?php if ( 'created' === $notice && $post ) : ?>
				<div class="notice notice-success"><p>
					<?php esc_html_e( 'Draft page created.', 'aiwpc' ); ?>
					<a href="<?php echo esc_url( get_edit_post_link( $post ) ); ?>"><?php esc_html_e( 'Open in the editor', 'aiwpc' ); ?></a>
				</p></div>
			<?php elseif ( $notice && 'created' !== $notice ) : ?>
				<div class="notice notice-error"><p><?php echo esc_html( $notice ); ?></p></div>
			<?php endif; ?>
			<p><?php esc_html_e( 'Paste the block markup from the converter to create a draft page. The optional CSS is stored with the page and loaded only on that page.', 'aiwpc' ); ?></p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'aiwpc_import' ); ?>
				<input type="hidden" name="action" value="aiwpc_import">
				<table class="form-table" role="presentation">
					<tr><th scope="row"><label for="aiwpc-title"><?php esc_html_e( 'Page title', 'aiwpc' ); ?></label></th>
						<td><input name="title" id="aiwpc-title" type="text" class="regular-text" required></td></tr>
					<tr><th scope="row"><label for="aiwpc-content"><?php esc_html_e( 'Block markup', 'aiwpc' ); ?></label></th>
						<td><textarea name="content" id="aiwpc-content" rows="14" class="large-text code" required></textarea></td></tr>
					<tr><th scope="row"><label for="aiwpc-css"><?php esc_html_e( 'Additional CSS (optional)', 'aiwpc' ); ?></label></th>
						<td><textarea name="css" id="aiwpc-css" rows="5" class="large-text code"></textarea></td></tr>
					<?php if ( current_user_can( 'upload_files' ) ) : ?>
					<tr><th scope="row"><?php esc_html_e( 'Images', 'aiwpc' ); ?></th>
						<td><label><input type="checkbox" name="import_images" value="1"> <?php esc_html_e( 'Import external images into the Media Library (only images you have the right to use)', 'aiwpc' ); ?></label></td></tr>
					<?php endif; ?>
				</table>
				<?php submit_button( __( 'Create draft page', 'aiwpc' ) ); ?>
			</form>
			<h2><?php esc_html_e( 'Connecting the web app', 'aiwpc' ); ?></h2>
			<p>
				<?php esc_html_e( 'REST endpoint:', 'aiwpc' ); ?> <code><?php echo esc_html( rest_url( 'aiwpc/v1/pages' ) ); ?></code><br>
				<?php esc_html_e( 'Authenticate with an Application Password (Users → Profile → Application Passwords) for a user with the Editor role. Pages are created as drafts.', 'aiwpc' ); ?>
			</p>
		</div>
		<?php
	}

	public static function handle_admin_import() {
		if ( ! current_user_can( 'edit_pages' ) ) {
			wp_die( esc_html__( 'You are not allowed to create pages.', 'aiwpc' ), 403 );
		}
		check_admin_referer( 'aiwpc_import' );
		$result = self::create_page(
			array(
				'title'         => isset( $_POST['title'] ) ? sanitize_text_field( wp_unslash( $_POST['title'] ) ) : '',
				'content'       => isset( $_POST['content'] ) ? wp_unslash( $_POST['content'] ) : '', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- block markup, filtered by wp_insert_post/kses.
				'css'           => isset( $_POST['css'] ) ? wp_unslash( $_POST['css'] ) : '', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized in sanitize_css().
				'status'        => 'draft',
				'import_images' => ! empty( $_POST['import_images'] ),
				'source_url'    => '',
			)
		);
		$args = is_wp_error( $result )
			? array( 'aiwpc_notice' => $result->get_error_message() )
			: array( 'aiwpc_notice' => 'created', 'aiwpc_post' => $result['id'] );
		wp_safe_redirect( add_query_arg( $args, admin_url( 'tools.php?page=aiwpc-import' ) ) );
		exit;
	}
}

AIWPC_Bridge::init();
