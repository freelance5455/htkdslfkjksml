'use strict';
const input = document.getElementById('app-url');
const msg = document.getElementById('msg');
function show(kind, text) {
  msg.hidden = false;
  msg.className = 'status' + (kind === 'error' ? ' error' : kind === 'ok' ? ' ok' : '');
  msg.textContent = text;
}
function normalized() {
  const v = input.value.trim().replace(/\/+$/, '');
  try {
    const u = new URL(v);
    if (u.protocol !== 'http:' && u.protocol !== 'https:') throw new Error();
    if (u.protocol === 'http:' && !/^(localhost|127\.0\.0\.1|\[::1\])$/.test(u.hostname)) show('', 'Tip: use https:// for anything other than localhost.');
    return u.origin + u.pathname.replace(/\/+$/, '');
  } catch {
    return null;
  }
}
chrome.storage.local.get('appUrl').then(({ appUrl }) => { input.value = appUrl || 'http://localhost:3000'; });
document.getElementById('save').addEventListener('click', async () => {
  const v = normalized();
  if (!v) return show('error', 'Enter a valid http(s) URL.');
  await chrome.storage.local.set({ appUrl: v });
  show('ok', 'Saved.');
});
document.getElementById('test').addEventListener('click', async () => {
  const v = normalized();
  if (!v) return show('error', 'Enter a valid http(s) URL.');
  show('', 'Testing…');
  try {
    const res = await fetch(v + '/api/status', { signal: AbortSignal.timeout(5000) });
    const data = await res.json();
    if (!data.ok) throw new Error();
    show('ok', `Connected. AI: ${data.ai.configured ? 'configured' : 'not configured (Basic mode)'}.`);
  } catch {
    show('error', `Could not reach ${v}/api/status. Is the app running, and does it allow this extension (EXTENSION_ORIGINS)?`);
  }
});
