// In-page section picker. Injected on demand (after capture-core.js) when the user clicks
// "Select a section" in the popup. Hover to highlight, ↑/↓ to widen/narrow, click to capture, Esc to cancel.
(function () {
  'use strict';
  if (window.__wpcPickerActive) return;
  window.__wpcPickerActive = true;

  var Z = 2147483646;
  var box = document.createElement('div');
  var label = document.createElement('div');
  var bar = document.createElement('div');
  box.setAttribute('data-wpc-ui', '');
  label.setAttribute('data-wpc-ui', '');
  bar.setAttribute('data-wpc-ui', '');
  box.style.cssText = 'position:fixed;pointer-events:none;z-index:' + Z + ';border:2px solid #7c3aed;background:rgba(124,58,237,.10);border-radius:6px;transition:all .06s ease;box-shadow:0 0 0 4000px rgba(15,23,42,.18)';
  label.style.cssText = 'position:fixed;pointer-events:none;z-index:' + (Z + 1) + ';background:#6d28d9;color:#fff;font:600 11px/1.2 system-ui,sans-serif;padding:4px 7px;border-radius:5px;white-space:nowrap';
  bar.style.cssText = 'position:fixed;left:50%;top:14px;transform:translateX(-50%);z-index:' + (Z + 1) + ';background:#0f172a;color:#fff;font:500 13px/1.3 system-ui,sans-serif;padding:10px 14px;border-radius:12px;box-shadow:0 10px 30px rgba(0,0,0,.25)';
  bar.textContent = 'WPConvert: click a section to capture · ↑ wider · ↓ narrower · Esc to cancel';
  document.documentElement.appendChild(box);
  document.documentElement.appendChild(label);
  document.documentElement.appendChild(bar);

  var current = null;
  var stack = [];

  function isUi(el) { return el && el.closest && el.closest('[data-wpc-ui]'); }

  function bestTarget(el) {
    // prefer a meaningful block: climb from tiny inline elements to their block container
    while (el && el !== document.body && el.parentElement) {
      var r = el.getBoundingClientRect();
      var d = getComputedStyle(el).display;
      if (r.height >= 40 && r.width >= 120 && d !== 'inline') break;
      el = el.parentElement;
    }
    return el;
  }

  function show(el) {
    current = el;
    if (!el) return;
    var r = el.getBoundingClientRect();
    box.style.left = r.left + 'px';
    box.style.top = r.top + 'px';
    box.style.width = r.width + 'px';
    box.style.height = r.height + 'px';
    var name = el.tagName.toLowerCase() + (el.id ? '#' + el.id : '') + (el.classList.length ? '.' + Array.prototype.slice.call(el.classList, 0, 2).join('.') : '');
    label.textContent = name + '  ' + Math.round(r.width) + '×' + Math.round(r.height);
    label.style.left = Math.max(4, r.left) + 'px';
    label.style.top = Math.max(4, r.top - 24) + 'px';
  }

  function onMove(e) {
    var el = document.elementFromPoint(e.clientX, e.clientY);
    if (!el || isUi(el)) return;
    stack = [];
    show(bestTarget(el));
  }

  function toast(text, ok) {
    bar.textContent = text;
    bar.style.background = ok ? '#065f46' : '#9f1239';
    setTimeout(function () { bar.remove(); }, 4000);
  }

  function cleanup() {
    window.__wpcPickerActive = false;
    document.removeEventListener('mousemove', onMove, true);
    document.removeEventListener('click', onClick, true);
    document.removeEventListener('keydown', onKey, true);
    window.removeEventListener('scroll', onScroll, true);
    box.remove();
    label.remove();
  }

  function onClick(e) {
    if (isUi(e.target)) return;
    e.preventDefault();
    e.stopPropagation();
    var el = current;
    cleanup();
    if (!el) return toast('Nothing selected.', false);
    try {
      var capture = globalThis.WPCCapture.captureDocument(document, { root: el, mode: 'extension', baseUrl: location.href });
      if (!capture.sections.length) {
        chrome.runtime.sendMessage({ type: 'wpc-capture-error', error: 'That area has no text, images or buttons to convert.' });
        return toast('That area has no text, images or buttons to convert. Try a larger section.', false);
      }
      chrome.runtime.sendMessage({ type: 'wpc-capture', capture: capture }, function (res) {
        if (chrome.runtime.lastError || !res || !res.ok) return toast('Could not store the capture: ' + ((chrome.runtime.lastError && chrome.runtime.lastError.message) || (res && res.error) || 'unknown error'), false);
        toast('Section captured ✓ — click the WPConvert icon to convert it.', true);
      });
    } catch (err) {
      chrome.runtime.sendMessage({ type: 'wpc-capture-error', error: String(err && err.message || err) });
      toast('Capture failed: ' + (err && err.message || err), false);
    }
  }

  function onKey(e) {
    if (e.key === 'Escape') { e.preventDefault(); cleanup(); bar.remove(); return; }
    if (e.key === 'ArrowUp' && current && current.parentElement && current !== document.body) {
      e.preventDefault(); stack.push(current); show(current.parentElement);
    }
    if (e.key === 'ArrowDown' && stack.length) { e.preventDefault(); show(stack.pop()); }
    if (e.key === 'Enter' && current) { e.preventDefault(); onClick({ target: current, preventDefault: function () {}, stopPropagation: function () {} }); }
  }

  function onScroll() { if (current) show(current); }

  document.addEventListener('mousemove', onMove, true);
  document.addEventListener('click', onClick, true);
  document.addEventListener('keydown', onKey, true);
  window.addEventListener('scroll', onScroll, true);
})();
