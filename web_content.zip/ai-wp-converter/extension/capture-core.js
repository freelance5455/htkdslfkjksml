/*
 * capture-core.js — shared page-capture walker.
 *
 * Runs in two places:
 *   1. The Chrome extension (injected into the active tab, real computed styles + layout boxes)
 *   2. The web app server (URL mode, parsed with linkedom: no layout, inline styles + class hints only)
 *
 * It is a classic script (no import/export) so the extension can inject it with
 * chrome.scripting.executeScript. It exposes globalThis.WPCCapture.captureDocument().
 *
 * Source of truth: web/lib/capture/capture-core.js — `npm run sync:extension` copies it
 * into extension/capture-core.js.
 */
(function (root) {
  'use strict';

  var VERSION = 1;
  var SKIP_TAGS = {
    SCRIPT: 1, STYLE: 1, NOSCRIPT: 1, TEMPLATE: 1, IFRAME: 1, OBJECT: 1, EMBED: 1, CANVAS: 1,
    LINK: 1, META: 1, HEAD: 1, DIALOG: 1, SELECT: 1, OPTION: 1, INPUT: 1, TEXTAREA: 1, LABEL: 1,
    svg: 1, SVG: 1, MAP: 1, AREA: 1, SOURCE: 1, TRACK: 1, PARAM: 1
  };
  var UNSUPPORTED = { FORM: 'form', VIDEO: 'video', AUDIO: 'audio', TABLE: 'table', IFRAME: 'embedded iframe', NAV: 'navigation menu' };
  var SECTION_TAGS = { SECTION: 1, HEADER: 1, FOOTER: 1, ARTICLE: 1, ASIDE: 1 };
  var INLINE_TAGS = {
    A: 1, ABBR: 1, B: 1, BDI: 1, BDO: 1, BR: 1, CITE: 1, CODE: 1, DATA: 1, DFN: 1, EM: 1, I: 1, KBD: 1, MARK: 1,
    Q: 1, S: 1, SAMP: 1, SMALL: 1, SPAN: 1, STRONG: 1, SUB: 1, SUP: 1, TIME: 1, U: 1, VAR: 1, WBR: 1, FONT: 1, DEL: 1, INS: 1
  };
  var MAX_SECTIONS = 40;
  var MAX_BLOCKS = 1500;

  /* ---------------- helpers ---------------- */

  function tag(el) { return (el && el.tagName ? String(el.tagName) : '').toUpperCase(); }

  function cleanText(s) { return String(s || '').replace(/[\s ]+/g, ' ').trim(); }

  function escapeHtml(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function absUrl(u, base) {
    if (!u) return '';
    u = String(u).trim();
    if (/^(javascript|vbscript|data):/i.test(u)) return '';
    try { return new URL(u, base).href; } catch (e) { return ''; }
  }

  function safeHref(u, base) {
    if (!u) return '';
    if (/^(mailto:|tel:)/i.test(u.trim())) return u.trim();
    if (/^#/.test(u.trim())) return u.trim();
    var a = absUrl(u, base);
    return /^https?:/i.test(a) ? a : '';
  }

  function hex2(n) { var h = Math.round(n).toString(16); return h.length === 1 ? '0' + h : h; }

  /** Normalise a CSS colour to #rrggbb, rgba(), or '' for transparent/unknown. */
  function normColor(c) {
    if (!c) return '';
    c = String(c).trim().toLowerCase();
    if (c === 'transparent' || c === 'inherit' || c === 'initial' || c === 'currentcolor' || c === 'none') return '';
    var m = c.match(/^rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:\s*[,/]\s*([\d.]+%?))?\s*\)$/);
    if (m) {
      var a = m[4] === undefined ? 1 : (m[4].slice(-1) === '%' ? parseFloat(m[4]) / 100 : parseFloat(m[4]));
      if (a <= 0.02) return '';
      if (a >= 0.99) return '#' + hex2(+m[1]) + hex2(+m[2]) + hex2(+m[3]);
      return 'rgba(' + Math.round(+m[1]) + ', ' + Math.round(+m[2]) + ', ' + Math.round(+m[3]) + ', ' + Math.round(a * 100) / 100 + ')';
    }
    if (/^#[0-9a-f]{3}$/.test(c)) return '#' + c[1] + c[1] + c[2] + c[2] + c[3] + c[3];
    if (/^#[0-9a-f]{6}$/.test(c)) return c;
    if (/^#[0-9a-f]{8}$/.test(c)) return c.slice(7) === 'ff' ? c.slice(0, 7) : c;
    var named = { white: '#ffffff', black: '#000000', red: '#ff0000', blue: '#0000ff', green: '#008000', gray: '#808080', grey: '#808080' };
    return named[c] || '';
  }

  function px(v) { var n = parseFloat(v); return isFinite(n) ? n : 0; }

  function firstBgUrl(bgImage, base) {
    if (!bgImage || bgImage === 'none') return '';
    var m = String(bgImage).match(/url\((['"]?)(.*?)\1\)/i);
    return m ? absUrl(m[2], base) : '';
  }

  /* -------- style providers -------- */

  /** Parses an inline style attribute — used when there is no layout engine (server URL mode). */
  function parseInlineStyle(el) {
    var out = {};
    var s = el.getAttribute && el.getAttribute('style');
    if (!s) return out;
    s.split(';').forEach(function (decl) {
      var i = decl.indexOf(':');
      if (i < 0) return;
      var k = decl.slice(0, i).trim().toLowerCase();
      var v = decl.slice(i + 1).replace(/!important/i, '').trim();
      var camel = k.replace(/-([a-z])/g, function (_, c) { return c.toUpperCase(); });
      out[camel] = v;
      if (k === 'background' && !out.backgroundColor) {
        var col = v.match(/(#[0-9a-f]{3,8}\b|rgba?\([^)]*\))/i);
        if (col) out.backgroundColor = col[1];
        if (/url\(/i.test(v)) out.backgroundImage = v;
        if (/gradient\(/i.test(v)) out.backgroundImage = v;
      }
    });
    return out;
  }

  /* ---------------- main ---------------- */

  /**
   * @param {Document} doc
   * @param {object} opts
   *   root       Element to capture (default doc.body)
   *   baseUrl    URL used to resolve relative links/images
   *   mode       'extension' | 'url'
   *   getStyle   el -> CSSStyleDeclaration-like (default: computed style if available, else inline style)
   *   getRect    el -> {x,y,width,height} | null
   */
  function captureDocument(doc, opts) {
    opts = opts || {};
    var win = doc.defaultView;
    var hasLayout = opts.mode === 'extension' && win && typeof win.getComputedStyle === 'function';
    var base = opts.baseUrl || (doc.location && doc.location.href) || '';
    var getStyle = opts.getStyle || (hasLayout ? function (el) { return win.getComputedStyle(el); } : parseInlineStyle);
    var getRect = opts.getRect || (hasLayout ? function (el) { return el.getBoundingClientRect(); } : function () { return null; });
    var rootEl = opts.root || doc.body;
    var warnings = [];
    var warned = {};
    var blockCount = 0;

    function warn(key, msg) { if (!warned[key]) { warned[key] = 1; warnings.push(msg); } }

    var styleCache = typeof Map !== 'undefined' ? new Map() : null;
    function st(el) {
      if (!styleCache) return getStyle(el) || {};
      if (!styleCache.has(el)) styleCache.set(el, getStyle(el) || {});
      return styleCache.get(el);
    }

    function classStr(el) {
      var c = el.getAttribute && el.getAttribute('class');
      return c ? String(c) : '';
    }

    function isHidden(el) {
      if (!el.getAttribute) return true;
      if (el.hasAttribute('hidden') || el.getAttribute('aria-hidden') === 'true') return true;
      if (/\b(sr-only|screen-reader-text|visually-hidden|hidden|d-none|is-hidden)\b/.test(classStr(el))) return true;
      var s = st(el);
      if (s.display === 'none' || s.visibility === 'hidden' || s.opacity === '0') return true;
      if (hasLayout) {
        var r = getRect(el);
        if (r && (r.width < 2 || r.height < 2) && tag(el) !== 'BR') {
          // allow zero-height wrappers that still have visible absolutely-positioned children
          if (s.overflow === 'hidden' || !el.children || !el.children.length) return true;
        }
        if (s.position === 'fixed' && /cookie|consent|gdpr|popup|modal|chat/i.test(classStr(el) + ' ' + (el.id || ''))) return true;
      }
      return false;
    }

    function isSkippable(el) {
      var t = tag(el);
      if (SKIP_TAGS[t] || SKIP_TAGS[el.tagName]) return true;
      if (UNSUPPORTED[t]) {
        warn(t, 'Skipped ' + UNSUPPORTED[t] + ' content — it has no reliable editable block equivalent in this version.');
        return true;
      }
      var role = el.getAttribute && el.getAttribute('role');
      if (role === 'navigation' || role === 'dialog' || role === 'alertdialog') {
        if (role === 'navigation') warn('NAV', 'Skipped navigation menu content — rebuild menus in Appearance → Menus or the Kadence header builder.');
        return true;
      }
      return isHidden(el);
    }

    function hasText(el) { return cleanText(el.textContent).length > 0; }

    function hasContent(el) {
      if (isSkippable(el)) return false;
      if (tag(el) === 'IMG' || tag(el) === 'PICTURE') return !!imageSrc(el);
      if (hasText(el)) return true;
      if (el.querySelector && el.querySelector('img')) return true;
      var s = st(el);
      return !!firstBgUrl(s.backgroundImage, base);
    }

    function elementChildren(el) {
      var out = [];
      var kids = el.children || [];
      for (var i = 0; i < kids.length; i++) if (hasContent(kids[i])) out.push(kids[i]);
      return out;
    }

    function ownBackground(el) { return normColor(st(el).backgroundColor); }

    function isInlineOnly(el) {
      var nodes = el.childNodes || [];
      var any = false;
      for (var i = 0; i < nodes.length; i++) {
        var n = nodes[i];
        if (n.nodeType === 3) { if (cleanText(n.textContent)) any = true; continue; }
        if (n.nodeType !== 1) continue;
        if (isSkippable(n)) continue;
        var t = tag(n);
        if (!INLINE_TAGS[t]) return false;
        if (t === 'A' && isButtonish(n)) return false;
        if (n.querySelector && n.querySelector('img,div,p,h1,h2,h3,h4,h5,h6,ul,ol,section')) return false;
        if (hasLayout) {
          var d = st(n).display;
          if (d && d !== 'inline' && d !== 'contents' && t !== 'BR') return false;
        }
        if (cleanText(n.textContent)) any = true;
      }
      return any;
    }

    /* ---- inline HTML serialiser (whitelist) ---- */
    function inlineHtml(el) {
      var out = '';
      var nodes = el.childNodes || [];
      for (var i = 0; i < nodes.length; i++) {
        var n = nodes[i];
        if (n.nodeType === 3) { out += escapeHtml(String(n.textContent).replace(/[\s ]+/g, ' ')); continue; }
        if (n.nodeType !== 1 || isSkippable(n)) continue;
        var t = tag(n);
        var inner = inlineHtml(n);
        if (t === 'BR') { out += '<br>'; continue; }
        if (!cleanText(inner.replace(/<[^>]+>/g, ''))) continue;
        if (t === 'STRONG' || t === 'B') out += '<strong>' + inner + '</strong>';
        else if (t === 'EM' || t === 'I') out += '<em>' + inner + '</em>';
        else if (t === 'CODE' || t === 'KBD') out += '<code>' + inner + '</code>';
        else if (t === 'A') {
          var href = safeHref(n.getAttribute('href'), base);
          out += href ? '<a href="' + escapeHtml(href) + '">' + inner + '</a>' : inner;
        } else if (hasLayout && t === 'SPAN' && +st(n).fontWeight >= 600 && +st(el).fontWeight < 600) out += '<strong>' + inner + '</strong>';
        else out += inner;
      }
      return out;
    }

    function trimHtml(h) {
      return h.replace(/^(\s|<br>)+/, '').replace(/(\s|<br>)+$/, '').replace(/\s{2,}/g, ' ');
    }

    /* ---- images ---- */
    function imageSrc(el) {
      var img = tag(el) === 'IMG' ? el : (el.querySelector ? el.querySelector('img') : null);
      if (!img) return '';
      var src = (hasLayout && img.currentSrc) || img.getAttribute('src') || '';
      var lazy = img.getAttribute('data-src') || img.getAttribute('data-lazy-src') || img.getAttribute('data-original');
      if ((!src || /^data:/i.test(src)) && lazy) src = lazy;
      if (!src || /^data:/i.test(src)) {
        var srcset = img.getAttribute('srcset') || img.getAttribute('data-srcset') || '';
        var first = srcset.split(',')[0];
        if (first) src = first.trim().split(/\s+/)[0];
      }
      return absUrl(src, base);
    }

    function imageBlock(el) {
      var img = tag(el) === 'IMG' ? el : el.querySelector('img');
      var src = imageSrc(el);
      if (!src) return null;
      var w = 0, h = 0;
      if (hasLayout) { var r = getRect(img); if (r) { w = Math.round(r.width); h = Math.round(r.height); } }
      if (!w) w = parseInt(img.getAttribute('width'), 10) || 0;
      if (!h) h = parseInt(img.getAttribute('height'), 10) || 0;
      if (hasLayout && w && h && w < 24 && h < 24) return null; // tracking pixels / tiny icons
      var s = hasLayout ? st(img) : {};
      var block = { type: 'image', src: src, alt: cleanText(img.getAttribute('alt')).slice(0, 300) };
      if (w) block.width = w;
      if (h) block.height = h;
      var radius = px(s.borderTopLeftRadius || s.borderRadius);
      if (radius) block.radius = Math.min(radius, 999);
      return block;
    }

    /* ---- buttons ---- */
    function isButtonish(el) {
      var t = tag(el);
      if (t === 'BUTTON') return hasText(el) && (el.getAttribute('type') !== 'submit' || true);
      if (t !== 'A') return false;
      if (!hasText(el)) return false;
      if (cleanText(el.textContent).length > 60) return false;
      if (el.getAttribute('role') === 'button') return true;
      if (/\b(btn|button|cta|wp-block-button__link|kb-button|elementor-button)\b/i.test(classStr(el))) return true;
      if (hasLayout) {
        var s = st(el);
        var bg = normColor(s.backgroundColor);
        var border = px(s.borderTopWidth) > 0 && normColor(s.borderTopColor);
        var padded = px(s.paddingLeft) >= 8 && px(s.paddingTop) >= 4;
        if ((bg || border) && padded && /block|flex|grid/.test(s.display || '')) return true;
        if (bg && padded) return true;
      }
      return false;
    }

    function buttonItem(el) {
      var s = st(el);
      var bg = normColor(s.backgroundColor);
      var borderColor = px(s.borderTopWidth) > 0 ? normColor(s.borderTopColor) : '';
      var item = {
        text: cleanText(el.textContent).slice(0, 80),
        href: tag(el) === 'A' ? safeHref(el.getAttribute('href'), base) : '',
        variant: bg ? 'fill' : (borderColor ? 'outline' : 'fill')
      };
      if (!hasLayout && /(^|[\s_-])(outline|ghost|secondary|bordered)([\s_-]|$)/i.test(classStr(el))) item.variant = 'outline';
      if (bg) item.background = bg;
      var color = normColor(s.color);
      if (color) item.color = color;
      if (borderColor && !bg) item.borderColor = borderColor;
      var radius = px(s.borderTopLeftRadius || s.borderRadius);
      if (radius) item.radius = Math.min(Math.round(radius), 999);
      return item;
    }

    /* ---- typography ---- */
    function textStyle(el, block) {
      var s = st(el);
      if (hasLayout) {
        var c = normColor(s.color);
        if (c) block.color = c;
        var fs = px(s.fontSize);
        if (fs) block.fontSize = Math.round(fs);
        var fw = parseInt(s.fontWeight, 10);
        if (fw && block.type === 'heading' && fw !== 700) block.fontWeight = fw;
      } else if (s.color) {
        var c2 = normColor(s.color);
        if (c2) block.color = c2;
      }
      var ta = s.textAlign;
      if (ta === 'center' || ta === 'right') block.align = ta;
      else if (ta === '-webkit-center') block.align = 'center';
      return block;
    }

    /* ---- layout detection ---- */
    function looksLikeRow(el, kids) {
      if (kids.length < 2) return false;
      var allButtons = kids.every(function (k) { return isButtonish(k) || (elementChildren(k).length === 1 && isButtonish(elementChildren(k)[0])); });
      if (allButtons) return false;
      var allInline = kids.every(function (k) { return INLINE_TAGS[tag(k)] && !isButtonish(k); });
      if (allInline) return false;
      if (hasLayout) {
        var rects = kids.map(getRect);
        var pr = getRect(el);
        var sideBySide = 0;
        for (var i = 1; i < rects.length; i++) {
          if (Math.abs(rects[i].top - rects[0].top) < 24 && rects[i].left >= rects[i - 1].left + rects[i - 1].width - 4) sideBySide++;
        }
        return sideBySide >= 1 && pr && rects[0].width < pr.width * 0.9;
      }
      var s = st(el);
      if (/flex/.test(s.display || '') && !/column/.test(s.flexDirection || '')) return true;
      if (/grid/.test(s.display || '') && /\S+\s+\S+/.test(s.gridTemplateColumns || '')) return true;
      return /(^|[\s_-])(row|columns?|cols|grid|features?|cards|split|two-col|three-col)([\s_-]|$)/i.test(classStr(el));
    }

    function columnStyle(el) {
      var s = st(el);
      var col = {};
      var bg = ownBackground(el);
      if (bg) col.background = bg;
      if (hasLayout) {
        var c = normColor(s.color);
        if (c) col.textColor = c;
        var radius = px(s.borderTopLeftRadius);
        if (radius && bg) col.radius = Math.min(Math.round(radius), 999);
        if (bg) col.padding = Math.min(Math.round(px(s.paddingTop)), 120);
        var shadow = s.boxShadow;
        if (shadow && shadow !== 'none') col.shadow = true;
        var bw = px(s.borderTopWidth);
        if (bw && normColor(s.borderTopColor)) col.borderColor = normColor(s.borderTopColor);
      }
      return col;
    }

    /* ---- block collection ---- */
    function pushBlock(list, b) {
      if (!b || blockCount >= MAX_BLOCKS) return;
      if (b.type === 'buttons' && list.length && list[list.length - 1].type === 'buttons') {
        Array.prototype.push.apply(list[list.length - 1].items, b.items);
        return;
      }
      blockCount++;
      list.push(b);
    }

    function paragraphFrom(el) {
      var html = trimHtml(inlineHtml(el));
      if (!cleanText(html.replace(/<[^>]+>/g, ''))) return null;
      return textStyle(el, { type: 'paragraph', html: html });
    }

    function collectBlocks(el, inColumn, out) {
      out = out || [];
      if (isInlineOnly(el)) {
        var p = paragraphFrom(el);
        if (p) pushBlock(out, p);
        return out;
      }
      var nodes = el.childNodes || [];
      var looseText = '';
      function flushLoose() {
        var t = cleanText(looseText);
        if (t) pushBlock(out, { type: 'paragraph', html: escapeHtml(t) });
        looseText = '';
      }
      for (var i = 0; i < nodes.length; i++) {
        var n = nodes[i];
        if (n.nodeType === 3) { looseText += n.textContent; continue; }
        if (n.nodeType !== 1) continue;
        if (isSkippable(n)) continue;
        var t = tag(n);
        if (INLINE_TAGS[t] && !isButtonish(n) && !(n.querySelector && n.querySelector('img,div,p,h1,h2,h3,h4,h5,h6,ul,ol'))) {
          looseText += n.textContent;
          continue;
        }
        flushLoose();
        if (!hasContent(n)) continue;
        handleElement(n, inColumn, out);
      }
      flushLoose();
      return out;
    }

    function handleElement(n, inColumn, out) {
      var t = tag(n);
      if (/^H[1-6]$/.test(t)) {
        var html = trimHtml(inlineHtml(n));
        if (cleanText(html.replace(/<[^>]+>/g, ''))) pushBlock(out, textStyle(n, { type: 'heading', level: +t[1], html: html }));
        return;
      }
      if (t === 'P') {
        var ek = elementChildren(n);
        if (!cleanText(n.textContent) && ek.length === 1 && (tag(ek[0]) === 'IMG' || tag(ek[0]) === 'PICTURE')) { pushBlock(out, imageBlock(ek[0])); return; }
        if (ek.length && ek.every(isButtonish) && cleanText(n.textContent) === cleanText(ek.map(function (e) { return e.textContent; }).join(' '))) {
          pushBlock(out, { type: 'buttons', items: ek.map(buttonItem), align: st(n).textAlign === 'center' ? 'center' : undefined });
          return;
        }
        pushBlock(out, paragraphFrom(n));
        return;
      }
      if (t === 'IMG' || t === 'PICTURE') { pushBlock(out, imageBlock(n)); return; }
      if (t === 'FIGURE') {
        pushBlock(out, imageBlock(n));
        var cap = n.querySelector('figcaption');
        if (cap && cleanText(cap.textContent)) pushBlock(out, { type: 'paragraph', html: trimHtml(inlineHtml(cap)), small: true });
        return;
      }
      if (t === 'UL' || t === 'OL') {
        var items = [];
        var lis = n.children || [];
        for (var j = 0; j < lis.length && items.length < 60; j++) {
          if (tag(lis[j]) !== 'LI' || isSkippable(lis[j])) continue;
          var h = trimHtml(inlineHtml(lis[j]));
          if (cleanText(h.replace(/<[^>]+>/g, ''))) items.push(h);
        }
        if (items.length) pushBlock(out, { type: 'list', ordered: t === 'OL', items: items });
        return;
      }
      if (t === 'BLOCKQUOTE') {
        var citeEl = n.querySelector('cite,footer');
        var qb = { type: 'quote', html: trimHtml(inlineHtml(n)) };
        if (citeEl) { qb.cite = cleanText(citeEl.textContent).slice(0, 200); }
        pushBlock(out, qb);
        return;
      }
      if (t === 'HR') { pushBlock(out, { type: 'separator' }); return; }
      if (isButtonish(n)) {
        var align = undefined;
        var parent = n.parentElement;
        if (parent) { var pa = st(parent); if (pa.textAlign === 'center' || pa.justifyContent === 'center') align = 'center'; }
        pushBlock(out, { type: 'buttons', items: [buttonItem(n)], align: align });
        return;
      }
      if (t === 'BUTTON') return;

      // containers
      var kids = elementChildren(n);
      if (!inColumn && looksLikeRow(n, kids)) {
        var chunks = [];
        var size = kids.length > 6 ? (kids.length % 4 === 0 ? 4 : 3) : kids.length;
        for (var c = 0; c < kids.length; c += size) chunks.push(kids.slice(c, c + size));
        chunks.forEach(function (chunk) {
          var cols = chunk.map(function (k) {
            var col = columnStyle(k);
            col.blocks = collectBlocks(k, true, []);
            if (!col.blocks.length && (tag(k) === 'IMG' || tag(k) === 'PICTURE')) col.blocks = [imageBlock(k)].filter(Boolean);
            if (!col.blocks.length && isButtonish(k)) col.blocks = [{ type: 'buttons', items: [buttonItem(k)] }];
            return col;
          }).filter(function (col) { return col.blocks.length; });
          if (cols.length >= 2) pushBlock(out, { type: 'columns', columns: cols });
          else if (cols.length === 1) cols[0].blocks.forEach(function (b) { pushBlock(out, b); });
        });
        return;
      }
      if (inColumn && looksLikeRow(n, kids) && !warned.nestedcols) {
        warn('nestedcols', 'Nested column layouts were flattened into a single column.');
      }
      // a card (own background) on its own row becomes a one-column box
      var bg = ownBackground(n);
      if (!inColumn && bg && hasLayout && bg !== ownBackground(n.parentElement || n)) {
        var col1 = columnStyle(n);
        col1.blocks = collectBlocks(n, true, []);
        if (col1.blocks.length) { pushBlock(out, { type: 'columns', columns: [col1] }); return; }
      }
      collectBlocks(n, inColumn, out);
    }

    /* ---- sections ---- */
    function sectionKind(el, blocks) {
      var t = tag(el);
      if (t === 'FOOTER' || /footer/i.test(classStr(el) + ' ' + (el.id || ''))) return 'footer';
      if (blocks.some(function (b) { return b.type === 'heading' && b.level === 1; })) return 'hero';
      if (/hero|banner|masthead/i.test(classStr(el))) return 'hero';
      if (t === 'HEADER') return 'header';
      var cols = blocks.filter(function (b) { return b.type === 'columns'; });
      if (cols.some(function (c) { return c.columns.length >= 3; })) return 'features';
      if (blocks.length <= 4 && blocks.some(function (b) { return b.type === 'buttons'; })) return 'cta';
      return 'content';
    }

    function sectionLabel(kind, blocks, idx) {
      var h = blocks.filter(function (b) { return b.type === 'heading'; })[0];
      if (!h) {
        for (var i = 0; i < blocks.length && !h; i++) {
          if (blocks[i].type === 'columns') blocks[i].columns.forEach(function (c) { c.blocks.forEach(function (b) { if (!h && b.type === 'heading') h = b; }); });
        }
      }
      var text = h ? cleanText(h.html.replace(/<[^>]+>/g, '')) : '';
      var names = { header: 'Header', hero: 'Hero', features: 'Features', cta: 'Call to action', footer: 'Footer', content: 'Section' };
      return (names[kind] || 'Section') + (text ? ': ' + text.slice(0, 48) : ' ' + (idx + 1));
    }

    function buildSection(els) {
      var el = els[0];
      var blocks = [];
      els.forEach(function (e) {
        if (els.length === 1) collectBlocks(e, false, blocks);
        else if (hasContent(e)) handleElement(e, false, blocks);
      });
      if (!blocks.length) return null;
      var s = st(el);
      var section = { blocks: blocks };
      if (els.length === 1) {
        var bg = ownBackground(el);
        if (bg) section.background = bg;
        var bgUrl = firstBgUrl(s.backgroundImage, base);
        if (bgUrl) section.backgroundImage = bgUrl;
        if (/gradient\(/i.test(s.backgroundImage || '')) {
          var gcol = String(s.backgroundImage).match(/(#[0-9a-f]{3,8}\b|rgba?\([^)]*\))/i);
          if (!bg && gcol) section.background = normColor(gcol[1]);
          section.gradient = true;
        }
        if (hasLayout) {
          var c = normColor(s.color);
          if (c) section.textColor = c;
          var pt = Math.round(px(s.paddingTop)), pb = Math.round(px(s.paddingBottom));
          if (pt || pb) section.paddingY = Math.min(Math.max(pt, pb), 200);
        }
      }
      var centered = blocks.filter(function (b) { return b.type === 'heading' || b.type === 'paragraph'; });
      if (centered.length && centered.every(function (b) { return b.align === 'center'; })) section.align = 'center';
      else if (els.length === 1 && !hasLayout && /center/.test(s.textAlign || '')) section.align = 'center';
      var kind = sectionKind(el, blocks);
      section.kind = kind;
      section.label = sectionLabel(kind, blocks, sections.length);
      section.id = 's' + (sections.length + 1);
      return section;
    }

    var sections = [];
    function addSection(els) {
      if (sections.length >= MAX_SECTIONS) { warn('maxsec', 'Page truncated to the first ' + MAX_SECTIONS + ' sections.'); return; }
      var s = buildSection(els);
      if (s) sections.push(s);
    }

    function isSectionLike(el) {
      return SECTION_TAGS[tag(el)] || !!ownBackground(el) || !!firstBgUrl(st(el).backgroundImage, base) || /(^|[\s_-])(section|hero|banner|block|band|container)([\s_-]|$)/i.test(classStr(el));
    }

    function containsSections(el) {
      if (tag(el) === 'MAIN') return true;
      var kids = elementChildren(el);
      if (kids.length < 2) return false;
      var n = 0;
      kids.forEach(function (k) { if (SECTION_TAGS[tag(k)] || tag(k) === 'MAIN') n++; });
      return n >= 2;
    }

    function collectSections(el, depth) {
      var kids = elementChildren(el);
      if (!kids.length) return;
      if (kids.length === 1 && depth < 10 && !isLeafish(kids[0]) && !ownBackground(kids[0]) && !SECTION_TAGS[tag(kids[0])]) {
        return collectSections(kids[0], depth + 1);
      }
      var loose = [];
      function flush() { if (loose.length) { addSection(loose); loose = []; } }
      kids.forEach(function (k) {
        if (isLeafish(k)) { loose.push(k); return; }
        flush();
        if (depth < 6 && containsSections(k) && !ownBackground(k)) collectSections(k, depth + 1);
        else if (!isSectionLike(k) && elementChildren(k).length > 1 && depth < 6 && elementChildren(k).every(isSectionLike) && !looksLikeRow(k, elementChildren(k))) collectSections(k, depth + 1);
        else addSection([k]);
      });
      flush();
    }

    function isLeafish(el) {
      var t = tag(el);
      return /^H[1-6]$/.test(t) || t === 'P' || t === 'IMG' || t === 'PICTURE' || t === 'FIGURE' || t === 'UL' || t === 'OL' || t === 'BLOCKQUOTE' || isButtonish(el) || INLINE_TAGS[t];
    }

    if (rootEl === doc.body || rootEl === doc.documentElement) collectSections(doc.body, 0);
    else if (containsSections(rootEl)) collectSections(rootEl, 0);
    else addSection([rootEl]);

    /* ---- theme ---- */
    var bodyStyle = st(doc.body);
    var htmlStyle = doc.documentElement ? st(doc.documentElement) : {};
    var theme = {
      background: normColor(bodyStyle.backgroundColor) || normColor(htmlStyle.backgroundColor) || '#ffffff',
      text: normColor(bodyStyle.color) || '#1f2937'
    };
    if (hasLayout && bodyStyle.fontFamily) theme.fontFamily = String(bodyStyle.fontFamily).slice(0, 200);
    var h1 = doc.querySelector('h1,h2');
    if (hasLayout && h1) { var hf = st(h1).fontFamily; if (hf && hf !== theme.fontFamily) theme.headingFontFamily = String(hf).slice(0, 200); }
    var btnBgs = {};
    sections.forEach(function (s) {
      (function walk(blocks) {
        blocks.forEach(function (b) {
          if (b.type === 'buttons') b.items.forEach(function (it) { if (it.background) btnBgs[it.background] = (btnBgs[it.background] || 0) + 1; });
          if (b.type === 'columns') b.columns.forEach(function (c) { walk(c.blocks); });
        });
      })(s.blocks);
    });
    var accent = Object.keys(btnBgs).sort(function (a, b) { return btnBgs[b] - btnBgs[a]; })[0];
    if (accent) theme.accent = accent;
    var metaTheme = doc.querySelector('meta[name="theme-color"]');
    if (!theme.accent && metaTheme) { var mc = normColor(metaTheme.getAttribute('content')); if (mc) theme.accent = mc; }

    if (!hasLayout) warnings.push('URL mode reads the page HTML only (no rendered styles), so colors, spacing and column layouts are approximate. Use the Chrome extension for a more faithful capture.');
    if (sections.some(function (s) { return s.gradient; })) warnings.push('Background gradients were simplified to a solid color.');

    var title = cleanText((doc.querySelector('title') || {}).textContent || '');
    var lang = (doc.documentElement && doc.documentElement.getAttribute('lang')) || '';
    return {
      version: VERSION,
      source: {
        url: base,
        title: title.slice(0, 200),
        lang: lang.slice(0, 20),
        mode: hasLayout ? 'extension' : 'url',
        scope: rootEl === doc.body ? 'page' : 'section',
        capturedAt: new Date().toISOString()
      },
      theme: theme,
      sections: sections,
      warnings: warnings
    };
  }

  root.WPCCapture = { captureDocument: captureDocument, normColor: normColor, VERSION: VERSION };
})(typeof globalThis !== 'undefined' ? globalThis : this);
