// Popup controller. All page access happens here, after the user clicks a button
// (activeTab + scripting). Captured data is only sent to the app URL set in Settings.
'use strict';

const DEFAULT_APP = 'http://localhost:3000';
const $ = (id) => document.getElementById(id);
let appUrl = DEFAULT_APP;
let capture = null;
let result = null;

/* ---------- helpers ---------- */

function setStatus(kind, text) {
  const el = $('status');
  if (!text) { el.hidden = true; return; }
  el.hidden = false;
  el.className = 'status' + (kind === 'error' ? ' error' : kind === 'ok' ? ' ok' : '');
  el.innerHTML = '';
  if (kind === 'busy') { const s = document.createElement('span'); s.className = 'spinner'; el.appendChild(s); }
  const t = document.createElement('span');
  t.textContent = text;
  el.appendChild(t);
}

function slug(s) {
  return (s || 'page').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 50) || 'page';
}

function downloadText(name, text, type) {
  const url = URL.createObjectURL(new Blob([text], { type: (type || 'text/plain') + ';charset=utf-8' }));
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 1000);
}

function countBlocks(cap) {
  let n = 0;
  cap.sections.forEach((s) => s.blocks.forEach((b) => { n++; if (b.type === 'columns') b.columns.forEach((c) => { n += c.blocks.length; }); }));
  return n;
}

/** Why a tab cannot be captured, or null if it can. */
function unsupportedReason(tab) {
  const url = tab && tab.url ? tab.url : '';
  if (!url) return 'This tab has no page loaded.';
  if (/^(chrome|edge|brave|about|devtools|chrome-extension|view-source):/i.test(url)) return 'Browser pages (like chrome:// and extension pages) cannot be captured.';
  if (/^https:\/\/(chrome\.google\.com\/webstore|chromewebstore\.google\.com)/i.test(url)) return 'Chrome does not allow extensions to read the Chrome Web Store.';
  if (/\.pdf($|[?#])/i.test(url)) return 'PDF files cannot be converted.';
  if (!/^(https?|file):/i.test(url)) return 'Only web pages (http/https) can be captured.';
  return null;
}

async function activeTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

/* ---------- app connection ---------- */

async function checkApp() {
  const pill = $('app-status');
  try {
    const res = await fetch(appUrl + '/api/status', { signal: AbortSignal.timeout(4000) });
    const data = await res.json();
    if (!data.ok) throw new Error();
    pill.textContent = data.ai && data.ai.configured ? 'App connected · AI' : 'App connected';
    pill.className = 'pill pill-ok';
    return true;
  } catch {
    pill.textContent = 'App offline';
    pill.className = 'pill pill-bad';
    pill.title = `Cannot reach ${appUrl}. Start the web app or change the URL in Settings.`;
    return false;
  }
}

/* ---------- capture ---------- */

function renderCapture() {
  $('capture-card').hidden = !capture;
  if (!capture) return;
  $('cap-scope').textContent = capture.source.scope === 'section' ? 'Captured section' : 'Captured page';
  $('cap-title').textContent = capture.source.title || 'Untitled page';
  $('cap-url').textContent = capture.source.url;
  const list = $('cap-sections');
  list.innerHTML = '';
  capture.sections.slice(0, 30).forEach((s, i) => {
    const li = document.createElement('li');
    const sw = document.createElement('span');
    sw.className = 'swatch';
    sw.style.background = s.background || (capture.theme && capture.theme.background) || '#fff';
    const name = document.createElement('span');
    name.className = 'name';
    name.textContent = `${i + 1}. ${s.label}`;
    li.append(sw, name);
    list.appendChild(li);
  });
  $('cap-stats').textContent = `${capture.sections.length} section${capture.sections.length === 1 ? '' : 's'} · ${countBlocks(capture)} blocks` + (capture.warnings && capture.warnings.length ? ` · ${capture.warnings.length} note(s)` : '');
}

function renderResult() {
  $('result').hidden = !result;
  if (!result) return;
  const o = result.output;
  $('res-stats').textContent = `${o.stats.sections} sections · ${o.format === 'kadence' ? `${o.stats.kadenceBlocks} Kadence + ${o.stats.coreBlocks} core blocks` : `${o.stats.coreBlocks} core blocks`} · ${result.ai.used ? 'AI organized' : 'Basic mode'}`;
  const ul = $('res-warnings');
  ul.innerHTML = '';
  o.warnings.slice(0, 6).forEach((w) => { const li = document.createElement('li'); li.textContent = w; ul.appendChild(li); });
}

async function captureFullPage() {
  setStatus('busy', 'Capturing page…');
  const tab = await activeTab();
  const reason = unsupportedReason(tab);
  if (reason) return setStatus('error', reason);
  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['capture-core.js'] });
    const [res] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => globalThis.WPCCapture.captureDocument(document, { mode: 'extension', baseUrl: location.href }),
    });
    const cap = res && res.result;
    if (!cap || !cap.sections || !cap.sections.length) return setStatus('error', 'No text, images or buttons were found on this page. Try selecting a section instead.');
    capture = cap;
    result = null;
    await chrome.storage.local.set({ lastCapture: cap, lastResult: null, lastError: null });
    renderCapture();
    renderResult();
    setStatus(null);
  } catch (e) {
    const msg = String((e && e.message) || e);
    setStatus('error', /Cannot access|cannot be scripted|permission/i.test(msg) ? 'Chrome blocked access to this page. Reload the page and try again — some pages (file:// without permission, the Web Store) cannot be captured.' : 'Capture failed: ' + msg);
  }
}

async function startPicker() {
  const tab = await activeTab();
  const reason = unsupportedReason(tab);
  if (reason) return setStatus('error', reason);
  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['capture-core.js', 'picker.js'] });
    setStatus('busy', 'Click a section on the page. When it is captured, open this popup again to convert it.');
    setTimeout(() => window.close(), 1200);
  } catch (e) {
    setStatus('error', 'Could not start the picker: ' + String((e && e.message) || e));
  }
}

/* ---------- convert ---------- */

async function convert() {
  if (!capture) return;
  if (!$('permission').checked) return setStatus('error', 'Please confirm you own this page or have permission to reproduce it.');
  $('btn-convert').disabled = true;
  setStatus('busy', 'Converting to WordPress blocks…');
  try {
    const res = await fetch(appUrl + '/api/convert', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({ capture, format: $('format').value, permission: true, useAi: true }),
      signal: AbortSignal.timeout(120000),
    });
    const data = await res.json().catch(() => ({ ok: false, error: `Unexpected response (HTTP ${res.status})` }));
    if (!data.ok) throw new Error(data.error || 'Conversion failed.');
    result = data.record;
    await chrome.storage.local.set({ lastResult: { id: result.id, output: { blocks: result.output.blocks, format: result.output.format, stats: result.output.stats, warnings: result.output.warnings }, ai: result.ai, title: result.title } });
    renderResult();
    setStatus('ok', 'Done — copy the code or open it in the web app.');
    const tab = await activeTab();
    if (tab && tab.id) chrome.action.setBadgeText({ text: '', tabId: tab.id });
  } catch (e) {
    const msg = String((e && e.message) || e);
    setStatus('error', /Failed to fetch|NetworkError|TimeoutError|aborted/i.test(msg) ? `Cannot reach the converter app at ${appUrl}. Start it or change the URL in Settings.` : msg);
  } finally {
    $('btn-convert').disabled = false;
  }
}

/* ---------- init ---------- */

async function init() {
  const stored = await chrome.storage.local.get(['appUrl', 'lastCapture', 'lastResult', 'lastError', 'format']);
  appUrl = (stored.appUrl || DEFAULT_APP).replace(/\/+$/, '');
  capture = stored.lastCapture || null;
  result = stored.lastResult || null;
  if (stored.format) $('format').value = stored.format;
  const tab = await activeTab().catch(() => null);
  const reason = unsupportedReason(tab);
  if (reason) {
    $('page-info').textContent = reason;
    $('btn-page').disabled = true;
    $('btn-section').disabled = true;
  } else if (tab) {
    $('page-info').textContent = 'Capture “' + (tab.title || tab.url).slice(0, 70) + '” or one section of it.';
  }
  if (stored.lastError) { setStatus('error', stored.lastError); chrome.storage.local.set({ lastError: null }); }
  renderCapture();
  renderResult();
  checkApp();

  $('btn-page').addEventListener('click', captureFullPage);
  $('btn-section').addEventListener('click', startPicker);
  $('btn-convert').addEventListener('click', convert);
  $('format').addEventListener('change', () => chrome.storage.local.set({ format: $('format').value }));
  $('btn-clear').addEventListener('click', async () => {
    capture = null; result = null;
    await chrome.storage.local.set({ lastCapture: null, lastResult: null });
    renderCapture(); renderResult(); setStatus(null);
  });
  $('btn-save-capture').addEventListener('click', () => capture && downloadText(`${slug(capture.source.title)}-capture.json`, JSON.stringify(capture, null, 2), 'application/json'));
  $('btn-copy').addEventListener('click', async () => {
    if (!result) return;
    try { await navigator.clipboard.writeText(result.output.blocks); setStatus('ok', 'Block code copied. Paste it into the WordPress code editor.'); }
    catch { setStatus('error', 'Copy failed — use Download instead.'); }
  });
  $('btn-download').addEventListener('click', () => result && downloadText(`${slug(result.title)}-${result.output.format}-blocks.html`, result.output.blocks, 'text/html'));
  $('btn-open').addEventListener('click', () => result && chrome.tabs.create({ url: `${appUrl}/convert/${encodeURIComponent(result.id)}` }));
}

init();
