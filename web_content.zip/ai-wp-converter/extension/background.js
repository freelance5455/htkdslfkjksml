// Service worker: receives section captures from the in-page picker and keeps the latest one
// until the popup is reopened. It does nothing on its own — every capture starts with a user click.

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg !== 'object') return;
  if (msg.type === 'wpc-capture' && msg.capture) {
    chrome.storage.local
      .set({ lastCapture: msg.capture, lastResult: null, lastError: null })
      .then(() => {
        if (sender.tab?.id) {
          chrome.action.setBadgeBackgroundColor({ color: '#6d28d9', tabId: sender.tab.id });
          chrome.action.setBadgeText({ text: '1', tabId: sender.tab.id });
        }
        sendResponse({ ok: true });
      })
      .catch((e) => sendResponse({ ok: false, error: String(e?.message || e) }));
    return true; // async response
  }
  if (msg.type === 'wpc-capture-error') {
    chrome.storage.local.set({ lastError: String(msg.error || 'Capture failed') });
    sendResponse({ ok: true });
  }
});
