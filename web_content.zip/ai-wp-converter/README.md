# AI Website to WordPress Converter (MVP)

Convert a website design you own into **editable WordPress blocks** — Kadence Blocks (Row Layout, Section, Advanced Text, Advanced Image, Advanced Button) or standard Gutenberg core blocks — plus a clean standalone HTML + CSS export.

```
ai-wp-converter/
├── web/                     Next.js 15 + TypeScript + Tailwind v4 web app and API
│   ├── app/                 pages (converter, dashboard, pricing, SEO pages) and API routes
│   ├── components/          UI (converter workspace, preview, code panel, WordPress panel)
│   ├── lib/capture/         capture-core.js — page walker shared with the extension
│   ├── lib/converter/       PageModel schema, sanitizer, Kadence + core block generators, HTML/CSS export
│   ├── lib/server/          URL fetching (SSRF-safe), AI layer, conversion pipeline, history store, usage limits
│   └── test/                unit tests + fixtures (sample landing page, all-features model)
├── extension/               Chrome extension (Manifest V3, no build step)
├── wordpress-plugin/
│   └── ai-wp-converter-bridge/   companion plugin: REST draft pages, page CSS, image import, Tools screen
└── tools/
    ├── validator/           runs generated markup through the real WordPress block parser + Kadence save() code
    └── browser-test/        headless-Chromium end-to-end tests for the app and the extension
```

## How it works

```
 URL ──► server fetch (anonymous, public pages only) ─┐
                                                     ├─► capture-core.js ─► PageModel (JSON) ─► sanitize/validate
 Chrome extension ─► capture-core.js in the tab ─────┘                          │
   (computed styles + layout boxes)                                             ▼
                                              optional AI pass (server-side key) ─► organize sections / prompt edits
                                                                                │
                              ┌─────────────────────────────────────────────────┼──────────────────────┐
                              ▼                                                 ▼                      ▼
                    Kadence block markup                             core Gutenberg markup     HTML + styles.css
                              └──────────────► copy / download / draft page via REST ◄─────────────────┘
```

* **PageModel** (`web/lib/converter/types.ts`) is the single intermediate format: sections → headings, paragraphs, images, buttons, lists, quotes, separators and columns/cards. Everything external (extension capture, uploaded JSON, AI output) is validated with zod and inline HTML is rebuilt from a whitelist (`<strong> <em> <code> <a href> <br>`).
* **Kadence output** uses attribute names from Kadence Blocks' `block.json` files; the static markup mirrors their `save()` functions. Kadence then generates the styling (padding, colors, font sizes) server-side from those attributes.
* **Core output** uses Group/Cover, Columns, Heading, Paragraph, Image, Buttons, List, Quote and Separator.
* Page content, CSS and images stay separate: blocks go into the page, a small optional CSS snippet goes to Additional CSS (or is attached to the page by the plugin), and images can be imported into the Media Library.

---

## 1. Web app setup

Requirements: Node.js 20+ (tested with 22).

```bash
cd web
npm install
cp .env.example .env.local      # optional — everything works without changes
npm run dev                     # http://localhost:3000
# production
npm run build && npm start
```

`.env.local` options:

| Variable | Purpose |
|---|---|
| `SITE_URL` | Public URL, used for canonical URLs, sitemap.xml and Open Graph. |
| `ANTHROPIC_API_KEY` | Enables AI (section clean-up + "Request a change" prompts). Empty = **Basic mode** (rule-based; no fake AI output). |
| `AI_MODEL` | Model name, default `claude-sonnet-5-5`. `ANTHROPIC_BASE_URL` for a proxy/gateway. |
| `DATA_DIR` | Folder for conversion history (JSON files, default `.data`). |
| `ALLOW_PRIVATE_URLS` | `true` only for local development (lets you convert `http://localhost` pages and send drafts to an `http://` WordPress). |
| `EXTENSION_ORIGINS` | Comma-separated extension origins allowed by CORS (e.g. `chrome-extension://<your-extension-id>`). Empty = any `chrome-extension://` origin. |
| `FREE_CONVERSIONS_PER_HOUR` | Per-IP limit for the free plan (default 30). |

The API key is only read on the server (`web/lib/server/ai.ts`); it never reaches the browser or the extension.

### API

| Route | Description |
|---|---|
| `POST /api/convert` | `{ url }` or `{ capture }` (extension JSON) or `{ conversionId }` (re-generate), plus `format: "kadence" \| "core"`, `useAi`, `permission: true`. Send `Accept: application/x-ndjson` to stream progress events. |
| `POST /api/refine` | `{ conversionId, prompt }` — AI edit (requires a key). |
| `GET /api/conversions`, `GET/DELETE /api/conversions/:id` | History. |
| `POST /api/wordpress/draft` | `{ conversionId, siteUrl, username, appPassword, title, importImages }` — creates a **draft** page (plugin endpoint, falls back to core `/wp/v2/pages`). Credentials are not stored. |
| `GET /api/status` | App version, whether AI is configured. |

## 2. Chrome extension

1. Start the web app.
2. Open `chrome://extensions`, enable **Developer mode**, click **Load unpacked**, select the `extension/` folder.
3. Pin **WPConvert AI**. Open its **Settings** if your app is not at `http://localhost:3000`.
4. On a page you own: click the icon → **Capture full page** or **Select a section** (hover, ↑/↓ to widen/narrow, click or Enter; Esc cancels) → tick the permission box → **Convert to WordPress** → **Copy code**, **Download**, or **Open in web app**. **Download capture (.json)** saves the capture for the web app's import area.

Permissions: `activeTab`, `scripting`, `storage` — no host permissions, nothing runs until you click. The extension only talks to the app URL you set.

After editing `web/lib/capture/capture-core.js`, run `npm run sync:extension` in `web/` to copy it into the extension.

## 3. WordPress

**Option A — paste:** Pages → Add New → ⋮ → Code editor → paste the block markup → Exit code editor. For Kadence pages set *Page Layout → Fullwidth* (and hide the title if the design has its own hero). Paste the optional CSS into Customizer → Additional CSS.

**Option B — draft via REST (recommended):**
1. Zip `wordpress-plugin/ai-wp-converter-bridge` (or use the provided zip), upload via Plugins → Add New → Upload, activate.
2. Users → Profile → Application Passwords → create one (use an **Editor** account).
3. In the converter result, fill in *Send to WordPress as a draft* (https site URL, username, Application Password).
   The plugin creates a **draft**, attaches the page CSS (loaded only on that page), and optionally imports images into the Media Library.
   Publishing through the API needs `status=publish` **and** `confirm_publish=true`; the web app only ever creates drafts.

**Option C — Tools → AI Converter Import** (plugin admin screen): paste block markup + CSS to create a draft without the web app.

Requirements for Kadence output: the free **Kadence Blocks** plugin (Pro not needed). The Kadence theme is recommended.

## 4. Testing

What was run for this MVP:

| Check | Command | Result |
|---|---|---|
| Unit tests (capture, sanitizer, generators, escaping, AI layer with a mock API, SSRF guard) | `cd web && npm test` | 16/16 pass |
| Production build + type check | `cd web && npm run build` | passes |
| Block validity — current Gutenberg (block-library 11.2) **+ Kadence Blocks 3.7.12.1's real `save()` code** | `cd tools/validator && npm run validate` | Kadence output: all blocks strictly valid. Core output: all valid (images validate through Gutenberg's own deprecation path in 11.x). |
| Block validity — Gutenberg 9.22 (WordPress 6.8 era) | `npm run validate:legacy` | all core blocks strictly valid |
| Web UI end-to-end in headless Chromium (convert, preview, device toggles, format switch, dashboard, mobile layout) | `cd tools/browser-test && node e2e-app.mjs` | passes, no horizontal overflow on mobile |
| Extension end-to-end (real popup.js/picker.js/capture-core.js on a rendered page, chrome.* APIs shimmed) | `node e2e-extension.mjs` | full-page capture, section picker, convert, open-in-app, chrome:// error all pass |
| WordPress 7.1.3 (SQLite) + bridge plugin | manual scripts | drafts created via the app; wrong password → clear 401 message; Author role → 403; publish without confirmation rejected; CSS sanitized (`<script>`, `@import` removed); image import rewrites URLs |
| Kadence server-side CSS | Kadence's PHP `build_css()` on the imported pages | backgrounds, background image + overlay, padding, card radius/border, heading colors + responsive sizes, button colors all generated |

To validate Kadence markup yourself:
```bash
git clone --depth 1 https://github.com/stellarwp/kadence-blocks tools/kadence-blocks
cd tools/validator && npm install && npm run build:kadence -- ../kadence-blocks
npm run validate                       # files written by `npm test` in web/
node validate.mjs path/to/your-blocks.html
```

Browser tests use `CHROME_PATH` (a local Chrome) if set, otherwise the bundled `@sparticuz/chromium`. The extension test needs the `extension/` folder served over HTTP and the app started with `EXTENSION_ORIGINS` set to that origin (see the header of `e2e-extension.mjs`).

## 5. Security & responsible use

* The UI and extension require confirming you own the page or have permission. URL mode fetches anonymously — no cookies, logins, CAPTCHA or paywall bypass; bot-challenge pages are refused.
* SSRF protection: private/loopback/link-local/metadata addresses are blocked on every redirect hop; 3 MB / 12 s limits; HTML only.
* Every capture, upload and AI response is schema-validated and sanitized; the preview runs in a sandboxed iframe with a strict CSP (no scripts).
* WordPress: Application Passwords over https, used once and never stored; drafts by default; capability checks (`edit_pages`, `publish_pages`, `upload_files`); content goes through `wp_insert_post` (kses for users without `unfiltered_html`); CSS is stripped of markup, `@import` and script-like constructs.
* Images are hotlinked until imported — the UI tells users to only use images they have rights to.

## 6. SEO (marketing pages)

Homepage targets "AI Website to WordPress Converter"; `/chrome-extension`, `/kadence-converter` and `/wordpress-import-guide` each cover a distinct topic. Every page has a unique title/description, canonical URL, Open Graph/Twitter metadata, one H1 and semantic headings. `sitemap.xml`, `robots.txt` (API, results and dashboard are not indexed), a generated Open Graph image, and structured data limited to what is accurate (WebSite on the homepage, BreadcrumbList on guides; no FAQ or rating markup). Set `SITE_URL` in production.

## 7. Subscription readiness (not implemented)

`web/lib/plans.ts` defines plans; only **Free** exists. Pro and Agency are shown as *Planned — not available yet* with no prices and no checkout. Usage limits run through `lib/server/usage.ts` (in-memory, per IP) and history through `lib/server/store.ts` (JSON files) — both are small modules to replace with a database / Redis and Stripe when accounts are added. `ConversionRecord.ownerId` is reserved for that.

## 8. Unfinished features & known limitations

* **No user accounts or billing.** History is shared per server; paid plans are placeholders.
* **History storage is file-based** — on serverless hosts (e.g. Vercel) `.data` is not persistent; use a VPS/Docker or swap `store.ts` for a database.
* **Usage limiting is in-memory** (resets on restart, per instance).
* **The extension is not published** on the Chrome Web Store (load unpacked). It was tested with shimmed `chrome.*` APIs in headless Chromium, not as an installed extension in desktop Chrome — do a manual check in Chrome before relying on it.
* **URL mode is approximate**: no rendering, so it only sees inline styles and class names (use the extension for faithful colors, sizes and columns).
* **Not converted**: navigation menus, forms, sliders/carousels, video/iframes, tables, SVG icons, animations, hover states; gradients become solid colors; web fonts are not embedded; nested column layouts are flattened.
* **Images are hotlinked** unless imported with the plugin (WordPress only downloads from ports 80/443/8080).
* **Kadence**: verified against Kadence Blocks 3.7.12.1. Other versions should open fine (Kadence keeps deprecations), but re-run the validator after major Kadence updates. Outline buttons use the global Kadence outline style. Box shadows use the small optional CSS snippet. Page layout (Fullwidth / hide title) is set manually.
* **Core output on very new Gutenberg** (plugin 11.x): images are upgraded silently by Gutenberg's own migration when opened — no error, but the saved markup changes on first save.
* **AI**: tested against a mock of the Messages API (no real key was available in the build environment). Prompt edits are only available with a key; the model name is configurable.
* **DNS rebinding** between the SSRF check and the fetch is not fully prevented (acceptable for an MVP; pin resolved IPs or use an egress proxy in production).
