import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import type { AddressInfo } from 'node:net';
import { aiStatus, organizeWithAi, refineWithAi } from '../lib/server/ai';
import { sanitizePageModel } from '../lib/converter';

// A local stand-in for the Anthropic Messages API so the AI code path is tested without a key or network.
let server: http.Server;
let lastRequest: any = null;
const model = sanitizePageModel(JSON.parse(fs.readFileSync(path.join(__dirname, 'fixtures/all-features.json'), 'utf8')));

beforeAll(async () => {
  server = http.createServer((req, res) => {
    let body = '';
    req.on('data', (c) => (body += c));
    req.on('end', () => {
      lastRequest = { headers: req.headers, body: JSON.parse(body) };
      const userText: string = lastRequest.body.messages[0].content;
      let text: string;
      if (userText.includes('BREAK')) text = 'Sorry, I cannot do that.';
      else if (userText.includes('INJECT')) {
        const m = structuredClone(model) as any;
        m.sections[0].blocks[0].html = 'Hi <script>alert(1)</script><img src=x onerror=alert(1)>there';
        text = JSON.stringify(m);
      } else if (lastRequest.body.system.includes('edit a website layout')) {
        const m = structuredClone(model) as any;
        m.sections[0].background = '#0f172a';
        m.sections[0].textColor = '#ffffff';
        text = '```json\n' + JSON.stringify(m) + '\n```';
      } else {
        const m = structuredClone(model) as any;
        m.sections[0].label = 'Hero: cleaned by AI';
        text = JSON.stringify(m);
      }
      res.writeHead(200, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ content: [{ type: 'text', text }] }));
    });
  });
  await new Promise<void>((r) => server.listen(0, '127.0.0.1', r));
  process.env.ANTHROPIC_API_KEY = 'test-key';
  process.env.ANTHROPIC_BASE_URL = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});

afterAll(() => {
  server.close();
  delete process.env.ANTHROPIC_API_KEY;
  delete process.env.ANTHROPIC_BASE_URL;
});

describe('AI layer', () => {
  it('reports configuration from the environment', () => {
    expect(aiStatus().configured).toBe(true);
  });

  it('organizes a capture and sends the key only server-side', async () => {
    const r = await organizeWithAi(model);
    expect(r.used).toBe(true);
    expect(r.model.sections[0].label).toBe('Hero: cleaned by AI');
    expect(lastRequest.headers['x-api-key']).toBe('test-key');
    expect(lastRequest.body.system).toMatch(/never invent copy/);
  });

  it('applies a change request', async () => {
    const r = await refineWithAi(model, 'make the hero dark');
    expect(r.model.sections[0].background).toBe('#0f172a');
  });

  it('sanitizes AI output', async () => {
    const r = await refineWithAi(model, 'INJECT');
    expect(r.model.sections[0].blocks[0]).toMatchObject({ html: 'Hi there' });
  });

  it('falls back to Basic rules when the AI answer is unusable', async () => {
    const organized = await organizeWithAi({ ...model, warnings: ['BREAK'] });
    expect(organized.used).toBe(false);
    expect(organized.note).toMatch(/built-in rules/);
    await expect(refineWithAi(model, 'BREAK it')).rejects.toThrow(/Nothing was changed/);
  });
});
