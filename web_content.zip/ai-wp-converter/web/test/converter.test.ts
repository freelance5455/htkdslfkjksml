import { describe, expect, it } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import { captureHtml } from '../lib/capture/server-capture';
import { convertModel, sanitizePageModel } from '../lib/converter';
import { sanitizeInline } from '../lib/converter/sanitize';

const fixture = fs.readFileSync(path.join(__dirname, 'fixtures/landing.html'), 'utf8');
const outDir = path.join(__dirname, 'output');
fs.mkdirSync(outDir, { recursive: true });

describe('URL-mode capture', () => {
  const capture: any = captureHtml(fixture, 'https://bakery.example.com/');

  it('finds the page sections and skips nav, forms, scripts and hidden content', () => {
    fs.writeFileSync(path.join(outDir, 'capture.json'), JSON.stringify(capture, null, 2));
    const json = JSON.stringify(capture);
    expect(capture.sections.length).toBeGreaterThanOrEqual(4);
    expect(json).not.toContain('tracking');
    expect(json).not.toContain('We use cookies');
    expect(json).not.toContain('/about'); // nav menu skipped
    expect(capture.warnings.join(' ')).toMatch(/form/i);
  });

  it('detects the hero, buttons, columns and background image', () => {
    expect(capture.sections[0].kind).toBe('header');
    const hero = capture.sections.find((s: any) => s.kind === 'hero');
    expect(hero.background).toBe('#f5f3ff');
    expect(hero.blocks.find((b: any) => b.type === 'heading').html).toContain('<em>delivered</em>');
    const btns = hero.blocks.find((b: any) => b.type === 'buttons');
    expect(btns.items.map((i: any) => i.text)).toEqual(['Order a loaf', 'See how it works']);
    expect(btns.items[0].href).toBe('https://bakery.example.com/order');
    expect(hero.blocks.find((b: any) => b.type === 'image').src).toBe('https://bakery.example.com/img/hero-bread.jpg');

    const features = capture.sections.find((s: any) => s.blocks.some((b: any) => b.type === 'columns' && b.columns.length === 3));
    expect(features).toBeTruthy();
    const split = capture.sections.find((s: any) => s.blocks.some((b: any) => b.type === 'columns' && b.columns.length === 2));
    expect(split).toBeTruthy();
    const cta = capture.sections.find((s: any) => s.backgroundImage);
    expect(cta.backgroundImage).toBe('https://images.example.com/wheat-field.jpg');
    expect(cta.background).toBe('#1e1b4b');
  });

  for (const format of ['kadence', 'core'] as const) {
    it(`converts to ${format} blocks`, () => {
      const { output } = convertModel(capture, { format, seed: 'test' });
      fs.writeFileSync(path.join(outDir, `landing.${format}.html`), output.blocks);
      fs.writeFileSync(path.join(outDir, `landing.export.html`), output.html);
      fs.writeFileSync(path.join(outDir, `landing.export.css`), output.htmlCss);
      expect(output.blocks).not.toMatch(/<script/i);
      expect(output.stats.sections).toBe(capture.sections.length);
      if (format === 'kadence') {
        expect(output.blocks).toContain('<!-- wp:kadence/rowlayout');
        expect(output.blocks).toContain('<!-- wp:kadence/singlebtn');
        expect(output.stats.kadenceBlocks).toBeGreaterThan(10);
      } else {
        expect(output.blocks).not.toContain('kadence');
        expect(output.blocks).toContain('<!-- wp:cover');
      }
      // balanced block delimiters
      const opens = (output.blocks.match(/<!-- wp:/g) || []).length - (output.blocks.match(/\/-->/g) || []).length;
      const closes = (output.blocks.match(/<!-- \/wp:/g) || []).length;
      expect(opens).toBe(closes);
    });
  }
});

describe('sanitizer', () => {
  it('keeps only whitelisted inline markup', () => {
    expect(sanitizeInline('Hi <b onclick="x()">there</b><script>alert(1)</script> <a href="javascript:alert(1)">bad</a> <a href="https://ok.example">ok</a><img src=x onerror=alert(1)>')).toBe(
      'Hi <strong>there</strong> bad <a href="https://ok.example/">ok</a>',
    );
  });

  it('rejects malformed capture data with a readable error', () => {
    expect(() => sanitizePageModel({ version: 1, sections: [] })).toThrow(/Invalid capture data/);
    expect(() => sanitizePageModel({ version: 1, source: {}, theme: {}, sections: [{ id: 's1', blocks: [{ type: 'image', src: 'javascript:alert(1)' }] }] })).toThrow(/No convertible content/);
  });

  it('escapes block comment attributes the way WordPress does', () => {
    const model = {
      version: 1,
      source: {},
      theme: {},
      sections: [{ id: 's1', blocks: [{ type: 'buttons', items: [{ text: 'Go -- now & "then"', href: 'https://x.example/?a=1&b=2' }] }] }],
    };
    const { output } = convertModel(model, { format: 'kadence', seed: 't' });
    expect(output.blocks).toContain('Go \\u002d\\u002d now \\u0026 \\u0022then\\u0022');
    expect(output.blocks).not.toContain('-->"');
  });
});

describe('all supported block features', () => {
  const model = JSON.parse(fs.readFileSync(path.join(__dirname, 'fixtures/all-features.json'), 'utf8'));
  for (const format of ['kadence', 'core'] as const) {
    it(`renders every feature as ${format} markup`, () => {
      const { output } = convertModel(model, { format, seed: 'feat' });
      fs.writeFileSync(path.join(outDir, `features.${format}.html`), output.blocks);
      expect(output.blocks).toContain('Dashboard \\"preview\\"'.replace(/\\"/g, '&quot;'));
      expect(output.warnings.join(' ')).toMatch(/Images \(\d+\)/);
    });
  }
});
