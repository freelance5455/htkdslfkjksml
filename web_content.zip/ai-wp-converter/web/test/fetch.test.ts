import { describe, expect, it } from 'vitest';
import { fetchPublicPage, normalizeUrl } from '../lib/server/fetch-page';

describe('URL fetching safety', () => {
  it('normalizes and validates URLs', () => {
    expect(normalizeUrl('example.com/page').href).toBe('https://example.com/page');
    expect(() => normalizeUrl('ftp://example.com')).toThrow(/http and https/);
    expect(() => normalizeUrl('https://user:pw@example.com')).toThrow(/credentials/);
    expect(() => normalizeUrl('')).toThrow(/Enter a website URL/);
  });

  it('blocks private and local network addresses (SSRF)', async () => {
    delete process.env.ALLOW_PRIVATE_URLS;
    for (const u of ['http://127.0.0.1:8090/', 'http://localhost/', 'http://10.0.0.5/', 'http://192.168.1.1/', 'http://169.254.169.254/latest/meta-data', 'http://[::1]/']) {
      await expect(fetchPublicPage(u)).rejects.toThrow(/Private or local/);
    }
  });
});
