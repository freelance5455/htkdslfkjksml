import Link from 'next/link';
import { JsonLd, breadcrumb } from '@/components/JsonLd';
import { pageMeta, SITE_URL } from '@/lib/site';

export const metadata = pageMeta(
  '/chrome-extension',
  'Chrome Extension for WordPress — Capture a Page or Section',
  'Install the Chrome extension to capture the rendered design of a page you own — or one section — and convert it into editable WordPress Gutenberg and Kadence blocks.',
);

export default function ChromeExtensionPage() {
  return (
    <article className="prose-page mx-auto max-w-3xl px-4 py-14 sm:px-6">
      <JsonLd data={breadcrumb([{ name: 'Home', path: '/' }, { name: 'Chrome extension', path: '/chrome-extension' }], SITE_URL)} />
      <h1 className="text-4xl font-bold tracking-tight">Chrome extension for WordPress page capture</h1>
      <p className="mt-4 text-lg">
        The extension reads a page the way Chrome renders it — real colors, font sizes, spacing and side-by-side columns — so the converter can rebuild it as editable WordPress blocks far more accurately than from HTML alone.
      </p>

      <h2>What it does</h2>
      <ul>
        <li>Captures the current tab only when you click the extension. Nothing runs in the background and no browsing history is collected.</li>
        <li>Lets you capture the whole page or <strong>pick one section</strong> by hovering and clicking.</li>
        <li>Extracts visible headings, paragraphs, images, links, buttons, background colors and column layout.</li>
        <li>Sends the capture to your converter app, then shows the result with <strong>Copy code</strong> and <strong>Download</strong> buttons.</li>
        <li>Can also save the capture as a <code>.json</code> file to import on the <Link href="/">converter page</Link>.</li>
      </ul>

      <h2>Install (developer mode)</h2>
      <p>The extension is not on the Chrome Web Store yet. Load it unpacked from the project folder:</p>
      <ol>
        <li>Open <code>chrome://extensions</code> and turn on <strong>Developer mode</strong>.</li>
        <li>Click <strong>Load unpacked</strong> and choose the <code>extension</code> folder of this project.</li>
        <li>Pin “WPConvert AI” to the toolbar.</li>
        <li>Open the extension’s <strong>Settings</strong> and set the app URL (default <code>http://localhost:3000</code>).</li>
      </ol>

      <h2>Permissions it uses</h2>
      <table>
        <thead><tr><th>Permission</th><th>Why</th></tr></thead>
        <tbody>
          <tr><td><code>activeTab</code></td><td>Read the tab you are on, only after you click the extension.</td></tr>
          <tr><td><code>scripting</code></td><td>Inject the capture script into that tab on demand.</td></tr>
          <tr><td><code>storage</code></td><td>Remember your app URL and the last capture/result.</td></tr>
        </tbody>
      </table>
      <p>No host permissions are requested. The extension talks only to the app URL you configure.</p>

      <h2>Pages it cannot capture</h2>
      <p>Chrome does not allow extensions on <code>chrome://</code> pages, the Chrome Web Store or PDF viewers. Content behind a login is captured only as you see it — please capture only pages you own or have permission to reproduce.</p>

      <p className="mt-10"><Link href="/wordpress-import-guide">Next: import the result into WordPress →</Link></p>
    </article>
  );
}
