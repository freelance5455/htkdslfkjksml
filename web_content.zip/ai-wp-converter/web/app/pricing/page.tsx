import Link from 'next/link';
import { PLANS } from '@/lib/plans';
import { pageMeta } from '@/lib/site';

export const metadata = pageMeta('/pricing', 'Pricing', 'The AI Website to WordPress Converter is free to use today. Paid plans with accounts, higher limits and team features are planned.');

export default function Pricing() {
  return (
    <div className="mx-auto max-w-6xl px-4 py-14 sm:px-6">
      <div className="mx-auto max-w-2xl text-center">
        <h1 className="text-4xl font-bold tracking-tight">Pricing</h1>
        <p className="mt-3 text-lg text-ink-700">Everything that exists today is free. Paid plans are planned and not on sale yet.</p>
      </div>
      <div className="mt-12 grid gap-6 md:grid-cols-3">
        {PLANS.map((p) => (
          <section key={p.id} className={`card flex flex-col p-7 ${p.status === 'available' ? 'ring-2 ring-brand-500' : ''}`} aria-labelledby={`plan-${p.id}`}>
            <div className="flex items-center justify-between">
              <h2 id={`plan-${p.id}`} className="text-xl font-semibold">{p.name}</h2>
              <span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${p.status === 'available' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-800'}`}>
                {p.status === 'available' ? 'Available now' : 'Planned — not available yet'}
              </span>
            </div>
            <p className="mt-4 text-3xl font-bold">{p.monthlyPrice === 0 ? '$0' : 'Price not set'}</p>
            <p className="text-sm text-ink-500">{p.monthlyPrice === 0 ? `Up to ${p.conversionsPerHour} conversions per hour` : 'Monthly and annual billing planned'}</p>
            <ul className="mt-6 flex-1 space-y-2 text-sm">
              {(p.status === 'available' ? p.features : p.plannedFeatures || []).map((f) => (
                <li key={f} className="flex gap-2 text-ink-700">
                  <span className={p.status === 'available' ? 'text-emerald-600' : 'text-ink-500'} aria-hidden="true">{p.status === 'available' ? '✓' : '○'}</span>
                  {f}
                  {p.status !== 'available' && <span className="sr-only">(planned)</span>}
                </li>
              ))}
            </ul>
            {p.status === 'available' ? (
              <Link href="/#converter" className="btn-primary mt-6">Start converting</Link>
            ) : (
              <p className="mt-6 rounded-xl bg-slate-50 px-4 py-3 text-center text-sm text-ink-500">No checkout yet — this plan is in planning.</p>
            )}
          </section>
        ))}
      </div>
    </div>
  );
}
