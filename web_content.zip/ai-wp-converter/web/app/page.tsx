import Link from 'next/link';
import { Workspace } from '@/components/converter/Workspace';
import { Faq } from '@/components/Faq';
import { JsonLd } from '@/components/JsonLd';
import { aiStatus } from '@/lib/server/ai';
import { pageMeta, SITE_NAME, SITE_URL } from '@/lib/site';

export const dynamic = 'force-dynamic';

export const metadata = pageMeta(
  '/',
  'AI Website to WordPress Converter — Editable Gutenberg & Kadence Blocks',
  'Convert a website design you own into editable WordPress blocks. Capture a page with the Chrome extension or a URL and get Kadence Row Layouts, Advanced Text, buttons and images — plus clean HTML and CSS.',
);

const STEPS = [
  { n: '01', t: 'Capture the design', d: 'Paste a public URL, or click the Chrome extension on any page you own to capture the full page or a single section with its real colors and layout.' },
  { n: '02', t: 'Analyze and organize', d: 'Headings, text, images, buttons, cards and columns are grouped into clean sections. With an AI key configured, AI tidies the structure — it never invents copy.' },
  { n: '03', t: 'Generate editable blocks', d: 'Get valid Gutenberg block markup: Kadence Row Layout, Section, Advanced Text, Advanced Image and Advanced Button — or standard core blocks.' },
  { n: '04', t: 'Import as a draft', d: 'Copy into the block editor, download the files, or let the companion plugin create a draft page through the WordPress REST API.' },
];

const FEATURES = [
  { t: 'Editable WordPress blocks', d: 'No giant HTML blob. Every heading, paragraph, image and button becomes its own block you can edit, move or restyle.' },
  { t: 'Kadence WordPress converter', d: 'Sections map to Kadence Row Layouts with background, padding and columns set through real Kadence attributes.', href: '/kadence-converter' },
  { t: 'Chrome extension for WordPress', d: 'Capture exactly what you see — computed colors, fonts and side-by-side layouts — only when you click.', href: '/chrome-extension' },
  { t: 'HTML to WordPress, cleanly separated', d: 'Page content, optional CSS and images are kept apart, with clear notes on where each one belongs.' },
  { t: 'Drafts, never surprise publishing', d: 'Pages are created as drafts with an Application Password. You review and publish from WordPress.' },
  { t: 'Honest conversion reports', d: 'Anything that is not reproduced — hover effects, forms, menus, gradients — is listed so nothing gets lost silently.' },
];

const SUPPORT: [string, string, string][] = [
  ['Section / container', 'Row Layout (kadence/rowlayout)', 'Group or Cover'],
  ['Columns and cards', 'Row Layout + Section (kadence/column)', 'Columns + Column'],
  ['Headings and paragraphs', 'Advanced Text (kadence/advancedheading)', 'Heading, Paragraph'],
  ['Images', 'Advanced Image (kadence/image)', 'Image'],
  ['Buttons and links', 'Advanced Button (kadence/advancedbtn + singlebtn)', 'Buttons + Button'],
  ['Lists, quotes, dividers', 'Core List, Quote, Separator', 'List, Quote, Separator'],
  ['Background colors, spacing', 'Row / column attributes', 'Block style attributes'],
];

const FAQ = [
  {
    q: 'What does the AI website to WordPress converter actually produce?',
    a: 'Gutenberg block markup that you paste into the block editor (or send as a draft page), an optional small CSS snippet, and a standalone HTML + CSS export. The blocks are standard, editable WordPress blocks — not a shortcode or an embedded HTML file.',
  },
  {
    q: 'Do I need Kadence to use the output?',
    a: (
      <>
        No. Choose <strong>Core Gutenberg</strong> output and the page works with any block theme or classic theme that supports the block editor. Choose <strong>Kadence Blocks</strong> output if Kadence Blocks is installed — the free plugin is enough for every block we generate.
      </>
    ),
  },
  {
    q: 'Is URL mode as accurate as the Chrome extension?',
    a: 'No. URL mode reads the page HTML on our server without rendering it, so it only sees inline styles and class names. The Chrome extension reads the page as your browser renders it, so colors, font sizes, spacing and side-by-side columns are much more faithful.',
  },
  {
    q: 'Which websites can I convert?',
    a: 'Only pages you own or have permission to reproduce. The converter fetches pages anonymously and will not log in, solve CAPTCHAs or get past paywalls. Images keep pointing to the original site until you upload your own copies.',
  },
  {
    q: 'What is not converted?',
    a: 'Navigation menus, forms, sliders, videos, embedded iframes, scripts, animations and hover effects. Gradients are simplified to a solid color and web fonts are not embedded. Each conversion lists what needs your attention.',
  },
  {
    q: 'Does it work without an AI API key?',
    a: 'Yes. Without a key the app runs in Basic mode: the built-in rules organize sections and generate the same valid blocks. AI adds smarter section clean-up and prompt-based edits; the app never shows simulated AI results.',
  },
  {
    q: 'How do I import the result into WordPress?',
    a: (
      <>
        Open a new page, switch to the Code editor, paste the block markup and switch back. Or install the companion plugin and send the page as a draft. The <Link href="/wordpress-import-guide">WordPress import guide</Link> walks through both.
      </>
    ),
  },
];

export default function Home() {
  const ai = aiStatus();
  return (
    <>
      <JsonLd data={{ '@context': 'https://schema.org', '@type': 'WebSite', name: SITE_NAME, url: SITE_URL + '/' }} />
      <section className="relative overflow-hidden">
        <div className="bg-grid absolute inset-0 -z-10 [mask-image:radial-gradient(ellipse_at_top,black_30%,transparent_70%)]" aria-hidden="true" />
        <div className="absolute left-1/2 top-[-12rem] -z-10 h-[34rem] w-[60rem] -translate-x-1/2 rounded-full bg-gradient-to-r from-brand-200/50 via-blue-200/40 to-brand-100/40 blur-3xl" aria-hidden="true" />
        <div className="mx-auto max-w-7xl px-4 pb-12 pt-14 sm:px-6 sm:pt-20">
          <div className="mx-auto max-w-3xl text-center animate-fade-up">
            <p className="inline-flex items-center gap-2 rounded-full border border-brand-200 bg-white/80 px-3 py-1 text-xs font-semibold text-brand-700 shadow-sm">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" aria-hidden="true" /> Gutenberg + Kadence Blocks output
            </p>
            <h1 className="mt-5 text-4xl font-extrabold tracking-tight sm:text-6xl">
              AI Website to <span className="text-gradient">WordPress</span> Converter
            </h1>
            <p className="mx-auto mt-5 max-w-2xl text-lg leading-8 text-ink-700">
              Convert a website design you own into clean, editable WordPress blocks. Paste a URL or capture a page with the Chrome extension — get Kadence Row Layouts, text, images and buttons ready to import.
            </p>
          </div>
          <div className="mt-10">
            <Workspace aiConfigured={ai.configured} />
          </div>
          <p className="mt-4 text-center text-xs text-ink-500">
            Best results: <Link href="/chrome-extension" className="font-medium text-brand-600 hover:underline">capture with the Chrome extension</Link> · Free plan, no account needed
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6" aria-labelledby="how">
        <h2 id="how" className="text-center text-3xl font-bold tracking-tight">How to convert a website design to WordPress</h2>
        <p className="mx-auto mt-3 max-w-2xl text-center text-ink-700">Four steps from a live page to an editable draft in your WordPress site.</p>
        <ol className="mt-10 grid gap-5 md:grid-cols-4">
          {STEPS.map((s) => (
            <li key={s.n} className="card p-6">
              <span className="text-gradient text-sm font-bold">{s.n}</span>
              <h3 className="mt-2 text-lg font-semibold">{s.t}</h3>
              <p className="mt-2 text-sm leading-6 text-ink-700">{s.d}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className="bg-gradient-to-b from-white via-brand-50/50 to-white py-16" aria-labelledby="features">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <h2 id="features" className="text-center text-3xl font-bold tracking-tight">Built for real WordPress pages</h2>
          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {FEATURES.map((f) => (
              <div key={f.t} className="card p-6 transition hover:-translate-y-0.5 hover:shadow-lg">
                <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-brand-500 to-blue-500 opacity-90" aria-hidden="true" />
                <h3 className="mt-4 font-semibold">{f.href ? <Link href={f.href} className="hover:text-brand-700">{f.t}</Link> : f.t}</h3>
                <p className="mt-2 text-sm leading-6 text-ink-700">{f.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-5xl px-4 py-16 sm:px-6" aria-labelledby="mapping">
        <h2 id="mapping" className="text-center text-3xl font-bold tracking-tight">Website to Gutenberg blocks: what maps to what</h2>
        <p className="mx-auto mt-3 max-w-2xl text-center text-ink-700">
          Kadence markup is checked against the save functions of Kadence Blocks; core output against the WordPress block parser.
        </p>
        <div className="card mt-8 overflow-x-auto">
          <table className="w-full min-w-[560px] text-left text-sm">
            <thead className="bg-slate-50 text-xs uppercase tracking-wide text-ink-500">
              <tr>
                <th className="px-5 py-3">On the website</th>
                <th className="px-5 py-3">Kadence output</th>
                <th className="px-5 py-3">Core Gutenberg output</th>
              </tr>
            </thead>
            <tbody>
              {SUPPORT.map(([a, b, c]) => (
                <tr key={a} className="border-t border-slate-100">
                  <td className="px-5 py-3 font-medium">{a}</td>
                  <td className="px-5 py-3 text-ink-700">{b}</td>
                  <td className="px-5 py-3 text-ink-700">{c}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <div className="py-8">
        <Faq items={FAQ} />
      </div>

      <section className="mx-auto mt-12 max-w-5xl px-4 sm:px-6">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-brand-700 via-brand-600 to-blue-600 px-8 py-12 text-center text-white shadow-xl">
          <h2 className="text-3xl font-bold tracking-tight">Capture pages straight from Chrome</h2>
          <p className="mx-auto mt-3 max-w-xl text-white/85">The extension captures the rendered design — or just the section you pick — and sends it to the converter in one click.</p>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <Link href="/chrome-extension" className="rounded-xl bg-white px-5 py-3 text-sm font-semibold text-brand-700 shadow hover:bg-brand-50">
              Get the Chrome extension
            </Link>
            <Link href="/wordpress-import-guide" className="rounded-xl border border-white/40 px-5 py-3 text-sm font-semibold text-white hover:bg-white/10">
              Read the import guide
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
