import { ImageResponse } from 'next/og';
export const alt = 'AI Website to WordPress Converter';
export const size = { width: 1200, height: 630 };
export const contentType = 'image/png';
export default function OG() {
  return new ImageResponse(
    (
      <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: 80, background: 'linear-gradient(135deg,#6d28d9,#2563eb)', color: '#fff' }}>
        <div style={{ fontSize: 30, opacity: 0.85 }}>Gutenberg + Kadence Blocks</div>
        <div style={{ fontSize: 76, fontWeight: 800, lineHeight: 1.05, marginTop: 20 }}>AI Website to WordPress Converter</div>
        <div style={{ fontSize: 32, marginTop: 28, opacity: 0.9 }}>Turn a design you own into editable WordPress blocks.</div>
      </div>
    ),
    size,
  );
}
