import { runRefine } from '@/lib/server/pipeline';
import { json, preflight, readJson } from '@/lib/server/http';
import { checkUsage, clientKey } from '@/lib/server/usage';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 120;

export function OPTIONS(req: Request) {
  return preflight(req);
}

export async function POST(req: Request) {
  try {
    const body = await readJson(req);
    const usage = checkUsage(clientKey(req));
    if (!usage.ok) return json(req, { ok: false, error: `Free plan limit reached. Try again in ${usage.resetInMinutes} min.` }, 429);
    const record = await runRefine(String(body.conversionId || ''), String(body.prompt || ''), body.format === 'core' ? 'core' : body.format === 'kadence' ? 'kadence' : undefined);
    return json(req, { ok: true, record });
  } catch (e: any) {
    return json(req, { ok: false, error: e?.message || 'Edit failed.' }, 400);
  }
}
