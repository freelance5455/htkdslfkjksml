import { deleteConversion, getConversion } from '@/lib/server/store';
import { json, preflight } from '@/lib/server/http';

export const dynamic = 'force-dynamic';

export function OPTIONS(req: Request) {
  return preflight(req);
}

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const record = await getConversion((await params).id);
  return record ? json(req, { ok: true, record }) : json(req, { ok: false, error: 'Not found' }, 404);
}

export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return (await deleteConversion((await params).id)) ? json(req, { ok: true }) : json(req, { ok: false, error: 'Not found' }, 404);
}
