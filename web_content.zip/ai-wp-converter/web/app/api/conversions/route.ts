import { listConversions } from '@/lib/server/store';
import { json, preflight } from '@/lib/server/http';

export const dynamic = 'force-dynamic';

export function OPTIONS(req: Request) {
  return preflight(req);
}

export async function GET(req: Request) {
  return json(req, { ok: true, items: await listConversions(50) });
}
