import { getConversion } from '@/lib/server/store';
import { assertPublicHost, FetchPageError, normalizeUrl } from '@/lib/server/fetch-page';
import { json, readJson } from '@/lib/server/http';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * POST /api/wordpress/draft — creates a DRAFT page on the user's WordPress site.
 * Uses WordPress Application Passwords over HTTPS. Credentials are used for this one request and never stored.
 * Prefers the companion plugin endpoint (stores page CSS, optional image import); falls back to core /wp/v2/pages.
 */
export async function POST(req: Request) {
  try {
    const body = await readJson(req, 64 * 1024);
    const rec = await getConversion(String(body.conversionId || ''));
    if (!rec) return json(req, { ok: false, error: 'Conversion not found.' }, 404);
    const site = normalizeUrl(String(body.siteUrl || ''));
    if (site.protocol !== 'https:' && process.env.ALLOW_PRIVATE_URLS !== 'true') {
      return json(req, { ok: false, error: 'Use an https:// site URL — Application Passwords must not be sent over plain http.' }, 400);
    }
    await assertPublicHost(site);
    const user = String(body.username || '').trim();
    const pass = String(body.appPassword || '').replace(/\s+/g, ' ').trim();
    if (!user || !pass) return json(req, { ok: false, error: 'Enter your WordPress username and an Application Password.' }, 400);
    const auth = 'Basic ' + Buffer.from(`${user}:${pass}`).toString('base64');
    const title = String(body.title || rec.title || 'Converted page').slice(0, 200);
    const rootUrl = site.origin + site.pathname.replace(/\/+$/, '').replace(/\/wp-admin.*$/, '');

    const call = async (route: string, payload: unknown) => {
      for (const u of [`${rootUrl}/wp-json${route}`, `${rootUrl}/?rest_route=${route}`]) {
        const res = await fetch(u, {
          method: 'POST',
          redirect: 'error',
          headers: { Authorization: auth, 'Content-Type': 'application/json', Accept: 'application/json' },
          body: JSON.stringify(payload),
          signal: AbortSignal.timeout(30000),
        }).catch((e) => {
          throw new FetchPageError(`Could not reach ${site.host} (${e?.cause?.code || e?.message}).`, 502);
        });
        const data: any = await res.json().catch(() => null);
        // Not JSON (e.g. pretty permalinks off, so /wp-json/ shows a normal page) → try ?rest_route=
        if (data === null || typeof data !== 'object') continue;
        return { status: res.status, data };
      }
      throw new FetchPageError(`Could not find the WordPress REST API on ${site.host}. Check the site URL and that the REST API is not disabled.`, 502);
    };

    const plugin = await call('/aiwpc/v1/pages', {
      title,
      content: rec.output.blocks,
      css: rec.output.css,
      status: 'draft',
      import_images: !!body.importImages,
      source_url: rec.sourceUrl,
    });
    if (plugin.status >= 200 && plugin.status < 300 && plugin.data?.id) {
      return json(req, { ok: true, usedPlugin: true, ...plugin.data });
    }
    if (plugin.data?.code !== 'rest_no_route') {
      return json(req, { ok: false, error: wpError(plugin.status, plugin.data) }, 400);
    }
    const core = await call('/wp/v2/pages', { title, content: rec.output.blocks, status: 'draft' });
    if (core.status >= 200 && core.status < 300 && core.data?.id) {
      return json(req, {
        ok: true,
        usedPlugin: false,
        id: core.data.id,
        edit_url: `${rootUrl}/wp-admin/post.php?post=${core.data.id}&action=edit`,
        preview_url: core.data.link,
        note: 'Draft created with the core REST API. Install the companion plugin to attach the page CSS and import images automatically.',
      });
    }
    return json(req, { ok: false, error: wpError(core.status, core.data) }, 400);
  } catch (e: any) {
    return json(req, { ok: false, error: e?.message || 'Could not create the draft.' }, e instanceof FetchPageError ? e.status : 400);
  }
}

function wpError(status: number, data: any): string {
  if (status === 401) return 'WordPress rejected the login. Check the username and Application Password (Users → Profile → Application Passwords).';
  if (status === 403) return `Your WordPress user is not allowed to create pages${data?.message ? `: ${data.message}` : '.'}`;
  return `WordPress returned HTTP ${status}${data?.message ? `: ${String(data.message).replace(/<[^>]+>/g, '')}` : ''}.`;
}
