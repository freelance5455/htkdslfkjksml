import { runConversion, type ConvertRequest } from '@/lib/server/pipeline';
import { checkUsage, clientKey } from '@/lib/server/usage';
import { corsHeaders, json, preflight, readJson } from '@/lib/server/http';
import { FetchPageError } from '@/lib/server/fetch-page';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 120;

export function OPTIONS(req: Request) {
  return preflight(req);
}

/**
 * POST /api/convert
 * Body: { url } | { capture } | { conversionId }, plus { format: 'kadence'|'core', useAi, permission }
 * With "Accept: application/x-ndjson" it streams progress events, otherwise returns one JSON response.
 */
export async function POST(req: Request) {
  let body: ConvertRequest;
  try {
    body = await readJson(req);
  } catch (e: any) {
    return json(req, { ok: false, error: e.message }, 400);
  }
  if (!body.conversionId) {
    const usage = checkUsage(clientKey(req));
    if (!usage.ok) return json(req, { ok: false, error: `Free plan limit reached (${usage.limit} conversions per hour). Try again in ${usage.resetInMinutes} min.` }, 429);
  }
  const stream = (req.headers.get('accept') || '').includes('application/x-ndjson');
  if (!stream) {
    try {
      const record = await runConversion(body, () => {});
      return json(req, { ok: true, record });
    } catch (e: any) {
      return json(req, { ok: false, error: e?.message || 'Conversion failed.' }, e instanceof FetchPageError ? e.status : 400);
    }
  }
  const enc = new TextEncoder();
  const body$ = new ReadableStream({
    async start(controller) {
      const send = (o: unknown) => controller.enqueue(enc.encode(JSON.stringify(o) + '\n'));
      try {
        const record = await runConversion(body, (ev) => send({ type: 'stage', ...ev }));
        send({ type: 'result', record });
      } catch (e: any) {
        send({ type: 'error', message: e?.message || 'Conversion failed.' });
      }
      controller.close();
    },
  });
  return new Response(body$, { headers: { 'Content-Type': 'application/x-ndjson', 'Cache-Control': 'no-store', ...corsHeaders(req) } });
}
