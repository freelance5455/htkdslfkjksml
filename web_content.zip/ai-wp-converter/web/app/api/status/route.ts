import { aiStatus } from '@/lib/server/ai';
import { json, preflight } from '@/lib/server/http';
import { KADENCE_VERIFIED_VERSION } from '@/lib/converter';

export const dynamic = 'force-dynamic';

export function OPTIONS(req: Request) {
  return preflight(req);
}

export function GET(req: Request) {
  const ai = aiStatus();
  return json(req, { ok: true, app: 'ai-wp-converter', version: '0.1.0', ai: { configured: ai.configured }, kadenceVerifiedVersion: KADENCE_VERIFIED_VERSION });
}
