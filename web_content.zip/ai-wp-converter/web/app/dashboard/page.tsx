import Link from 'next/link';
import { listConversions } from '@/lib/server/store';
import { aiStatus } from '@/lib/server/ai';
import { FREE_PLAN } from '@/lib/plans';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'Dashboard — recent conversions', robots: { index: false, follow: true } };

export default async function Dashboard() {
  const items = await listConversions(50);
  const ai = aiStatus();
  const totalSections = items.reduce((n, i) => n + i.sections, 0);
  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="mt-1 text-ink-700">Recent conversions stored on this server.</p>
        </div>
        <Link href="/#converter" className="btn-primary">New conversion</Link>
      </div>

      <dl className="mt-8 grid gap-4 sm:grid-cols-4">
        {[
          ['Conversions', String(items.length)],
          ['Sections converted', String(totalSections)],
          ['Plan', `${FREE_PLAN.name} · ${FREE_PLAN.conversionsPerHour}/hour`],
          ['AI', ai.configured ? 'Configured' : 'Basic mode'],
        ].map(([k, v]) => (
          <div key={k} className="card p-5">
            <dt className="text-xs font-medium uppercase tracking-wide text-ink-500">{k}</dt>
            <dd className="mt-1 text-xl font-semibold">{v}</dd>
          </div>
        ))}
      </dl>

      {items.length === 0 ? (
        <div className="card mt-8 p-10 text-center">
          <p className="font-semibold">No conversions yet</p>
          <p className="mt-1 text-sm text-ink-500">Convert a URL or a Chrome extension capture and it will show up here.</p>
        </div>
      ) : (
        <ul className="mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {items.map((c) => (
            <li key={c.id}>
              <Link href={`/convert/${c.id}`} className="card block h-full p-5 transition hover:-translate-y-0.5 hover:border-brand-200 hover:shadow-lg">
                <div className="flex items-start justify-between gap-3">
                  <h2 className="line-clamp-2 font-semibold">{c.title}</h2>
                  <span className={`shrink-0 rounded-full px-2 py-0.5 text-[11px] font-semibold ${c.format === 'kadence' ? 'bg-brand-100 text-brand-700' : 'bg-blue-100 text-blue-700'}`}>
                    {c.format === 'kadence' ? 'Kadence' : 'Core'}
                  </span>
                </div>
                <p className="mt-1 truncate text-sm text-ink-500">{c.sourceUrl || 'Uploaded capture'}</p>
                <div className="mt-4 flex flex-wrap gap-x-4 gap-y-1 text-xs text-ink-500">
                  <span>{c.sections} sections</span>
                  <span>{c.blocks} blocks</span>
                  <span>{c.sourceMode === 'extension' ? 'Extension' : c.sourceMode === 'url' ? 'URL' : 'Upload'}</span>
                  <span>{c.ai.used ? 'AI' : 'Basic'}</span>
                  <time dateTime={c.createdAt}>{new Date(c.createdAt).toLocaleString('en-US', { dateStyle: 'medium', timeStyle: 'short' })}</time>
                </div>
              </Link>
            </li>
          ))}
        </ul>
      )}
      <p className="mt-8 text-xs text-ink-500">History is shared by everyone using this server until user accounts are added (planned).</p>
    </div>
  );
}
