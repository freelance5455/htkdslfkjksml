import Link from 'next/link';
import { JsonLd, breadcrumb } from '@/components/JsonLd';
import { pageMeta, SITE_URL } from '@/lib/site';
import { KADENCE_VERIFIED_VERSION } from '@/lib/converter';

export const metadata = pageMeta(
  '/kadence-converter',
  'Kadence WordPress Converter — Website to Kadence Blocks',
  'How the converter turns website sections into Kadence Row Layouts, Sections, Advanced Text, Advanced Image and Advanced Button blocks, and what you need installed.',
);

export default function KadencePage() {
  return (
    <article className="prose-page mx-auto max-w-3xl px-4 py-14 sm:px-6">
      <JsonLd data={breadcrumb([{ name: 'Home', path: '/' }, { name: 'Kadence converter', path: '/kadence-converter' }], SITE_URL)} />
      <h1 className="text-4xl font-bold tracking-tight">Kadence WordPress converter</h1>
      <p className="mt-4 text-lg">
        Choose <strong>Kadence Blocks</strong> output and each section of the source page becomes a Kadence Row Layout you can keep editing with Kadence’s own controls — padding, backgrounds, columns, typography and buttons.
      </p>

      <h2>Requirements</h2>
      <ul>
        <li>WordPress with the block editor.</li>
        <li>The free <strong>Kadence Blocks</strong> plugin (Kadence Blocks Pro is not required for anything we generate).</li>
        <li>The Kadence theme is recommended so buttons, fonts and container width follow your global settings.</li>
      </ul>

      <h2>How elements are mapped</h2>
      <table>
        <thead><tr><th>Source</th><th>Kadence block</th><th>Attributes we set</th></tr></thead>
        <tbody>
          <tr><td>Section</td><td>Row Layout</td><td>full width, inherit content width, background color or image + overlay, top/bottom padding, text color</td></tr>
          <tr><td>Cards / columns</td><td>Row Layout + Section</td><td>column count, background, border radius, padding, text color</td></tr>
          <tr><td>Heading</td><td>Advanced Text</td><td>level, color, alignment, responsive font size, weight</td></tr>
          <tr><td>Paragraph</td><td>Advanced Text (HTML tag “p”)</td><td>color, alignment, font size when it differs from body text</td></tr>
          <tr><td>Image</td><td>Advanced Image</td><td>URL, alt text, width for small images, border radius</td></tr>
          <tr><td>Buttons</td><td>Advanced Button</td><td>alignment; per button: text, link, colors, radius, fill or outline style</td></tr>
          <tr><td>Lists, quotes, dividers</td><td>Core List, Quote, Separator</td><td>kept as core blocks inside Kadence sections</td></tr>
        </tbody>
      </table>

      <h2>How we keep the markup valid</h2>
      <p>
        Attribute names come from Kadence Blocks’ own <code>block.json</code> definitions — nothing is guessed. Our test suite compiles the real Kadence <code>save()</code> functions (Kadence Blocks {KADENCE_VERIFIED_VERSION}) and runs the generated pages through the WordPress block parser and validator, so blocks open without “unexpected content” errors.
      </p>
      <p>
        Kadence renders most styling (colors, padding, font sizes) as CSS generated from block attributes on the server, which is why the markup itself stays small and editable.
      </p>

      <h2>Known limits</h2>
      <ul>
        <li>Hover colors, box shadows and gradients are not mapped to Kadence settings. Card shadows use a small optional CSS snippet.</li>
        <li>Outline buttons use your global Kadence outline button style.</li>
        <li>Nested column layouts are flattened to one level of columns.</li>
      </ul>
      <p className="mt-10"><Link href="/">Try the converter →</Link></p>
    </article>
  );
}
