import { notFound } from 'next/navigation';
import Link from 'next/link';
import { Workspace } from '@/components/converter/Workspace';
import { getConversion } from '@/lib/server/store';
import { aiStatus } from '@/lib/server/ai';
import type { ClientRecord } from '@/components/converter/types';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'Conversion result', robots: { index: false, follow: false } };

export default async function ConversionPage({ params }: { params: Promise<{ id: string }> }) {
  const rec = await getConversion((await params).id);
  if (!rec) notFound();
  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <nav className="mb-6 text-sm text-ink-500" aria-label="Breadcrumb">
        <Link href="/dashboard" className="hover:text-brand-600">Dashboard</Link> <span aria-hidden="true">/</span> <span className="text-ink-900">{rec.title}</span>
      </nav>
      <Workspace aiConfigured={aiStatus().configured} initialRecord={rec as ClientRecord} />
    </div>
  );
}
