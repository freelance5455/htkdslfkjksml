import type { MetadataRoute } from 'next';
import { SITE_URL } from '@/lib/site';
export default function sitemap(): MetadataRoute.Sitemap {
  const pages: [string, number][] = [['/', 1], ['/chrome-extension', 0.8], ['/kadence-converter', 0.8], ['/wordpress-import-guide', 0.7], ['/pricing', 0.5]];
  return pages.map(([p, priority]) => ({ url: `${SITE_URL}${p}`, changeFrequency: 'monthly', priority }));
}
