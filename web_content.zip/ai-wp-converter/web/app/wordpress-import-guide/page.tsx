import Link from 'next/link';
import { JsonLd, breadcrumb } from '@/components/JsonLd';
import { pageMeta, SITE_URL } from '@/lib/site';

export const metadata = pageMeta(
  '/wordpress-import-guide',
  'WordPress Import Guide — Paste Blocks or Create a Draft',
  'Step-by-step: import converted Gutenberg or Kadence blocks into WordPress, where the CSS and images belong, and how to create draft pages with the companion plugin.',
);

export default function ImportGuide() {
  return (
    <article className="prose-page mx-auto max-w-3xl px-4 py-14 sm:px-6">
      <JsonLd data={breadcrumb([{ name: 'Home', path: '/' }, { name: 'WordPress import guide', path: '/wordpress-import-guide' }], SITE_URL)} />
      <h1 className="text-4xl font-bold tracking-tight">WordPress import guide</h1>
      <p className="mt-4 text-lg">A conversion gives you three separate things. Each one has its own place in WordPress — you never paste a whole website’s source code into a page.</p>
      <table>
        <thead><tr><th>Output</th><th>Where it goes</th></tr></thead>
        <tbody>
          <tr><td>Block markup</td><td>The page content (block editor → Code editor).</td></tr>
          <tr><td>Additional CSS (optional)</td><td>Appearance → Customize → Additional CSS, or attached to the page automatically by the companion plugin.</td></tr>
          <tr><td>Images</td><td>Your Media Library. Until you replace them, images load from the original site.</td></tr>
          <tr><td>HTML + styles.css</td><td>A standalone copy for review or other platforms — not for WordPress.</td></tr>
        </tbody>
      </table>

      <h2 id="paste">Option 1: paste into the block editor</h2>
      <ol>
        <li>Pages → Add New.</li>
        <li>Open the <strong>⋮ Options</strong> menu (top right) → <strong>Code editor</strong> (or press Ctrl+Shift+Alt+M).</li>
        <li>Paste the block markup and click <strong>Exit code editor</strong>.</li>
        <li>For Kadence output: in the Kadence page settings, set <strong>Page Layout → Fullwidth</strong> and turn off the page title if your design has its own hero.</li>
        <li>Save as draft, preview, then publish when you are happy.</li>
      </ol>

      <h2 id="plugin">Option 2: create a draft with the companion plugin</h2>
      <ol>
        <li>Upload <code>wordpress-plugin/ai-wp-converter-bridge</code> (zip it first) via Plugins → Add New → Upload, and activate it.</li>
        <li id="application-password">Create an Application Password: Users → Profile → <strong>Application Passwords</strong> → enter a name → Add New. Copy the generated password.</li>
        <li>In the converter, open <strong>Send to WordPress as a draft</strong>, enter your site URL (https), username and the Application Password.</li>
        <li>The plugin creates a <strong>draft</strong> page, stores the page CSS so it loads only on that page, and — if you tick the option — imports images into your Media Library.</li>
      </ol>
      <p>Without the plugin the converter falls back to the core <code>/wp/v2/pages</code> REST API and still creates a draft; add the CSS manually.</p>
      <p>
        Use a user with the <strong>Editor</strong> role (least privilege). Revoke the Application Password when you are done. Some hosts strip the Authorization header — if login fails with a correct password, ask your host to pass it through.
      </p>

      <h2>Option 3: import a capture later</h2>
      <p>In the Chrome extension, choose <strong>Download capture</strong>. On the <Link href="/">converter</Link>, switch to <strong>Import extension capture</strong> and drop the <code>.json</code> file.</p>

      <h2>After importing</h2>
      <ul>
        <li>Replace images with your own uploads (Block toolbar → Replace).</li>
        <li>Set fonts in Customizer → Typography if the original used a web font you are licensed to use.</li>
        <li>Rebuild menus and forms with WordPress or Kadence tools — they are not converted.</li>
      </ul>
    </article>
  );
}
