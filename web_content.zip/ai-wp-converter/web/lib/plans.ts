/**
 * Plan definitions. Only the Free plan exists today; paid plans are placeholders so the
 * pricing page, usage limits and a future payment provider (e.g. Stripe) have one source of truth.
 * Nothing here is sold yet — the pricing page labels planned plans clearly.
 */
export interface Plan {
  id: 'free' | 'pro' | 'agency';
  name: string;
  status: 'available' | 'planned';
  monthlyPrice: number | null; // null = not decided yet
  annualPrice: number | null;
  conversionsPerHour: number | null;
  features: string[];
  plannedFeatures?: string[];
}

export const PLANS: Plan[] = [
  {
    id: 'free',
    name: 'Free',
    status: 'available',
    monthlyPrice: 0,
    annualPrice: 0,
    conversionsPerHour: Number(process.env.FREE_CONVERSIONS_PER_HOUR || 30),
    features: [
      'URL conversion and Chrome extension capture',
      'Kadence Blocks and core Gutenberg output',
      'HTML + CSS download',
      'Draft pages via the WordPress companion plugin',
      'Recent conversion history (this server)',
    ],
  },
  {
    id: 'pro',
    name: 'Pro',
    status: 'planned',
    monthlyPrice: null,
    annualPrice: null,
    conversionsPerHour: null,
    features: [],
    plannedFeatures: ['User accounts with saved history', 'Higher usage limits', 'AI edits included', 'Monthly or annual billing'],
  },
  {
    id: 'agency',
    name: 'Agency',
    status: 'planned',
    monthlyPrice: null,
    annualPrice: null,
    conversionsPerHour: null,
    features: [],
    plannedFeatures: ['Multiple WordPress sites', 'Team seats', 'Bulk page conversion', 'Priority support'],
  },
];

export const FREE_PLAN = PLANS[0];
