/** CORS for the Chrome extension + small JSON helpers for route handlers. */

function allowedOrigin(origin: string | null): string | null {
  if (!origin) return null;
  const list = (process.env.EXTENSION_ORIGINS || '').split(',').map((s) => s.trim()).filter(Boolean);
  if (list.length) return list.includes(origin) ? origin : null;
  return /^chrome-extension:\/\/[a-p]{32}$/.test(origin) ? origin : null;
}

export function corsHeaders(req: Request): Record<string, string> {
  const origin = allowedOrigin(req.headers.get('origin'));
  if (!origin) return {};
  return {
    'Access-Control-Allow-Origin': origin,
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Max-Age': '600',
    Vary: 'Origin',
  };
}

export function preflight(req: Request) {
  return new Response(null, { status: 204, headers: corsHeaders(req) });
}

export function json(req: Request, body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', ...corsHeaders(req) } });
}

export async function readJson(req: Request, maxBytes = 4 * 1024 * 1024): Promise<any> {
  const len = Number(req.headers.get('content-length') || 0);
  if (len > maxBytes) throw new Error('Request too large (max 4 MB).');
  const text = await req.text();
  if (text.length > maxBytes) throw new Error('Request too large (max 4 MB).');
  try {
    return JSON.parse(text);
  } catch {
    throw new Error('Request body must be JSON.');
  }
}
