import { captureHtml } from '../capture/server-capture';
import { convertModel, sanitizePageModel } from '../converter';
import type { OutputFormat, PageModel } from '../converter/types';
import { fetchPublicPage } from './fetch-page';
import { organizeWithAi, refineWithAi } from './ai';
import { getConversion, newId, saveConversion, type ConversionRecord } from './store';

export type Stage = 'fetch' | 'analyze' | 'organize' | 'generate' | 'save';
export type Emit = (e: { stage: Stage; status: 'start' | 'done'; note?: string }) => void;

export interface ConvertRequest {
  url?: string;
  capture?: unknown; // capture from the extension or an uploaded .json
  conversionId?: string; // re-generate an existing conversion (e.g. switch format)
  format?: OutputFormat;
  useAi?: boolean;
  permission?: boolean;
}

export async function runConversion(req: ConvertRequest, emit: Emit): Promise<ConversionRecord> {
  const format: OutputFormat = req.format === 'core' ? 'core' : 'kadence';
  let model: PageModel;
  let ai = { used: false, note: '' };
  let existing: ConversionRecord | null = null;

  if (req.conversionId) {
    existing = await getConversion(req.conversionId);
    if (!existing) throw new Error('Conversion not found.');
    model = existing.model;
    ai = existing.ai;
  } else {
    if (!req.permission) throw new Error('Please confirm you own this website or have permission to reproduce its design and content.');
    let raw: unknown;
    if (req.url) {
      emit({ stage: 'fetch', status: 'start' });
      const { html, finalUrl } = await fetchPublicPage(req.url);
      emit({ stage: 'fetch', status: 'done', note: `Downloaded ${Math.round(html.length / 1024)} KB` });
      emit({ stage: 'analyze', status: 'start' });
      raw = captureHtml(html, finalUrl);
    } else if (req.capture) {
      emit({ stage: 'analyze', status: 'start' });
      raw = req.capture;
    } else {
      throw new Error('Provide a website URL or a capture file.');
    }
    model = sanitizePageModel(raw);
    emit({ stage: 'analyze', status: 'done', note: `${model.sections.length} sections found` });

    emit({ stage: 'organize', status: 'start' });
    if (req.useAi) {
      const r = await organizeWithAi(model);
      model = r.model;
      ai = { used: r.used, note: r.note };
    } else {
      ai = { used: false, note: 'Basic mode: organized by the built-in rules.' };
    }
    emit({ stage: 'organize', status: 'done', note: ai.note });
  }

  emit({ stage: 'generate', status: 'start' });
  const id = existing?.id || newId();
  const { model: clean, output } = convertModel(model, { format, seed: id.slice(0, 5) });
  emit({ stage: 'generate', status: 'done', note: `${output.stats.blocks} blocks · ${format === 'kadence' ? 'Kadence' : 'core Gutenberg'}` });

  emit({ stage: 'save', status: 'start' });
  const now = new Date().toISOString();
  const record: ConversionRecord = {
    id,
    createdAt: existing?.createdAt || now,
    updatedAt: now,
    title: clean.source.title || clean.sections[0]?.label || 'Untitled page',
    sourceUrl: clean.source.url,
    sourceMode: clean.source.mode,
    format,
    model: clean,
    output,
    ai,
  };
  await saveConversion(record);
  emit({ stage: 'save', status: 'done' });
  return record;
}

export async function runRefine(conversionId: string, prompt: string, format?: OutputFormat): Promise<ConversionRecord> {
  const existing = await getConversion(conversionId);
  if (!existing) throw new Error('Conversion not found.');
  if (!prompt.trim()) throw new Error('Describe the change you want.');
  const r = await refineWithAi(existing.model, prompt);
  const fmt = format || existing.format;
  const { model, output } = convertModel(r.model, { format: fmt, seed: existing.id.slice(0, 5) });
  const record: ConversionRecord = { ...existing, model, output, format: fmt, updatedAt: new Date().toISOString(), ai: { used: true, note: r.note } };
  await saveConversion(record);
  return record;
}
