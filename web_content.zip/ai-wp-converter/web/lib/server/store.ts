/**
 * Conversion history. MVP implementation: one JSON file per conversion in DATA_DIR.
 * Swap this module for a database (Postgres, SQLite, KV…) when you add accounts —
 * the rest of the app only uses the functions exported here.
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import type { ConversionOutput, PageModel } from '../converter/types';

export interface ConversionRecord {
  id: string;
  createdAt: string;
  updatedAt: string;
  title: string;
  sourceUrl: string;
  sourceMode: string;
  format: ConversionOutput['format'];
  model: PageModel;
  output: ConversionOutput;
  ai: { used: boolean; note: string };
  ownerId?: string; // reserved for user accounts
}

export type ConversionSummary = Pick<ConversionRecord, 'id' | 'createdAt' | 'title' | 'sourceUrl' | 'sourceMode' | 'format' | 'ai'> & {
  sections: number;
  blocks: number;
};

const dir = () => path.resolve(process.env.DATA_DIR || '.data', 'conversions');
const ID_RE = /^[a-z0-9]{8,32}$/;

export function newId(): string {
  return crypto.randomBytes(9).toString('hex');
}

export async function saveConversion(rec: ConversionRecord): Promise<void> {
  if (!ID_RE.test(rec.id)) throw new Error('bad id');
  await fs.mkdir(dir(), { recursive: true });
  await fs.writeFile(path.join(dir(), `${rec.id}.json`), JSON.stringify(rec));
}

export async function getConversion(id: string): Promise<ConversionRecord | null> {
  if (!ID_RE.test(id)) return null;
  try {
    return JSON.parse(await fs.readFile(path.join(dir(), `${id}.json`), 'utf8'));
  } catch {
    return null;
  }
}

export async function listConversions(limit = 30): Promise<ConversionSummary[]> {
  let files: string[] = [];
  try {
    files = (await fs.readdir(dir())).filter((f) => f.endsWith('.json'));
  } catch {
    return [];
  }
  const stats = await Promise.all(files.map(async (f) => ({ f, t: (await fs.stat(path.join(dir(), f))).mtimeMs })));
  stats.sort((a, b) => b.t - a.t);
  const out: ConversionSummary[] = [];
  for (const { f } of stats.slice(0, limit)) {
    try {
      const r: ConversionRecord = JSON.parse(await fs.readFile(path.join(dir(), f), 'utf8'));
      out.push({ id: r.id, createdAt: r.createdAt, title: r.title, sourceUrl: r.sourceUrl, sourceMode: r.sourceMode, format: r.format, ai: r.ai, sections: r.output.stats.sections, blocks: r.output.stats.blocks });
    } catch {
      /* skip unreadable file */
    }
  }
  return out;
}

export async function deleteConversion(id: string): Promise<boolean> {
  if (!ID_RE.test(id)) return false;
  try {
    await fs.unlink(path.join(dir(), `${id}.json`));
    return true;
  } catch {
    return false;
  }
}
