/**
 * Usage limiting (in-memory sliding window per client key). Good enough for a single server MVP;
 * replace with Redis/DB counters keyed by user + plan when accounts and billing are added.
 */
import { FREE_PLAN } from '../plans';

const hits = new Map<string, number[]>();
const WINDOW = 60 * 60 * 1000;

export function clientKey(req: Request): string {
  const fwd = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim();
  return fwd || req.headers.get('x-real-ip') || 'local';
}

export function checkUsage(key: string): { ok: boolean; remaining: number; limit: number; resetInMinutes: number } {
  const limit = FREE_PLAN.conversionsPerHour || 30;
  const now = Date.now();
  const list = (hits.get(key) || []).filter((t) => now - t < WINDOW);
  if (list.length >= limit) {
    hits.set(key, list);
    return { ok: false, remaining: 0, limit, resetInMinutes: Math.ceil((WINDOW - (now - list[0])) / 60000) };
  }
  list.push(now);
  hits.set(key, list);
  return { ok: true, remaining: limit - list.length, limit, resetInMinutes: 60 };
}
