import dns from 'node:dns/promises';
import net from 'node:net';

const MAX_BYTES = 3 * 1024 * 1024;
const TIMEOUT_MS = 12000;
const MAX_REDIRECTS = 4;

export class FetchPageError extends Error {
  constructor(message: string, public status = 400) {
    super(message);
  }
}

function isPrivateIp(ip: string): boolean {
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split('.').map(Number);
    return a === 10 || a === 127 || a === 0 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127) || a >= 224;
  }
  const v = ip.toLowerCase();
  if (v.startsWith('::ffff:')) return isPrivateIp(v.slice(7));
  return v === '::1' || v === '::' || v.startsWith('fc') || v.startsWith('fd') || v.startsWith('fe80');
}

export async function assertPublicHost(u: URL) {
  if (process.env.ALLOW_PRIVATE_URLS === 'true') return;
  const host = u.hostname.replace(/^\[|\]$/g, '');
  if (host === 'localhost' || host.endsWith('.localhost') || host.endsWith('.internal') || host.endsWith('.local')) {
    throw new FetchPageError('Private or local addresses cannot be converted.');
  }
  const addrs = net.isIP(host) ? [host] : (await dns.lookup(host, { all: true }).catch(() => [])).map((a) => a.address);
  if (!addrs.length) throw new FetchPageError(`Could not resolve ${host}.`);
  if (addrs.some(isPrivateIp)) throw new FetchPageError('Private or local addresses cannot be converted.');
}

export function normalizeUrl(input: string): URL {
  let s = (input || '').trim();
  if (!s) throw new FetchPageError('Enter a website URL.');
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(s) && !/^https?:\/\//i.test(s)) throw new FetchPageError('Only http and https URLs are supported.');
  if (/^(javascript|data|file|mailto):/i.test(s)) throw new FetchPageError('Only http and https URLs are supported.');
  if (!/^https?:\/\//i.test(s)) s = 'https://' + s;
  let u: URL;
  try {
    u = new URL(s);
  } catch {
    throw new FetchPageError('That does not look like a valid URL.');
  }
  if (u.protocol !== 'http:' && u.protocol !== 'https:') throw new FetchPageError('Only http and https URLs are supported.');
  if (u.username || u.password) throw new FetchPageError('URLs with credentials are not supported.');
  return u;
}

/**
 * Fetch a public HTML page. Blocks private networks (SSRF), limits size/time and follows a few redirects,
 * re-checking each hop. It never sends cookies or credentials, so it only sees what an anonymous visitor sees.
 */
export async function fetchPublicPage(input: string): Promise<{ html: string; finalUrl: string }> {
  let url = normalizeUrl(input);
  for (let hop = 0; hop <= MAX_REDIRECTS; hop++) {
    await assertPublicHost(url);
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
    let res: Response;
    try {
      res = await fetch(url, {
        redirect: 'manual',
        signal: ctrl.signal,
        headers: {
          'User-Agent': 'Mozilla/5.0 (compatible; AIWPConverter/0.1; +https://github.com/) page-to-blocks',
          Accept: 'text/html,application/xhtml+xml',
        },
      });
    } catch (e: any) {
      clearTimeout(timer);
      throw new FetchPageError(e?.name === 'AbortError' ? 'The website took too long to respond.' : `Could not reach the website (${e?.cause?.code || e?.message || 'network error'}).`, 502);
    }
    clearTimeout(timer);
    if (res.status >= 300 && res.status < 400 && res.headers.get('location')) {
      url = new URL(res.headers.get('location')!, url);
      if (url.protocol !== 'http:' && url.protocol !== 'https:') throw new FetchPageError('Redirected to an unsupported URL.');
      continue;
    }
    if (res.status === 401 || res.status === 403) throw new FetchPageError(`The website refused access (HTTP ${res.status}). Pages behind logins or bot protection are not supported.`, 422);
    if (!res.ok) throw new FetchPageError(`The website returned HTTP ${res.status}.`, 422);
    const type = res.headers.get('content-type') || '';
    if (!/text\/html|application\/xhtml/i.test(type)) throw new FetchPageError(`That URL is not an HTML page (${type.split(';')[0] || 'unknown type'}).`, 422);
    const reader = res.body?.getReader();
    if (!reader) throw new FetchPageError('Empty response from the website.', 422);
    const chunks: Uint8Array[] = [];
    let size = 0;
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.length;
      if (size > MAX_BYTES) {
        await reader.cancel();
        throw new FetchPageError('The page is larger than 3 MB, which is not supported.', 413);
      }
      chunks.push(value);
    }
    const html = new TextDecoder('utf-8').decode(Buffer.concat(chunks));
    if (/<form[^>]+(captcha|cf-challenge)|cf-browser-verification|challenge-platform/i.test(html)) {
      throw new FetchPageError('The website is showing a bot-protection challenge. Use the Chrome extension on a page you are allowed to capture.', 422);
    }
    return { html, finalUrl: url.href };
  }
  throw new FetchPageError('Too many redirects.', 422);
}
