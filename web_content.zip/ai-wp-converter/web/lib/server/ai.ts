/**
 * Optional AI layer (server-side only — the API key never reaches the browser or the extension).
 * Works on the PageModel JSON, never on raw HTML, and every AI response is re-validated and
 * sanitized before use. When no key is configured the app runs in Basic mode instead.
 */
import { sanitizePageModel } from '../converter';
import type { PageModel } from '../converter/types';

const MAX_MODEL_CHARS = 120_000;

export function aiStatus() {
  const configured = !!process.env.ANTHROPIC_API_KEY;
  return { configured, model: configured ? process.env.AI_MODEL || 'claude-sonnet-5-5' : null };
}

const SCHEMA_HINT = `PageModel JSON shape:
{ "version": 1, "source": {...keep as is...}, "theme": { "background", "text", "accent?", "fontFamily?" },
  "sections": [ { "id", "label", "kind": "hero|features|content|cta|footer|header", "background?", "backgroundImage?", "textColor?", "align?": "left|center|right", "paddingY?": number,
    "blocks": [ Block ] } ], "warnings": [string] }
Block = {"type":"heading","level":1-6,"html","color?","align?","fontSize?"} | {"type":"paragraph","html","color?","align?","fontSize?","small?"}
 | {"type":"image","src","alt","width?","height?","radius?"} | {"type":"buttons","align?","items":[{"text","href","variant":"fill|outline","background?","color?","radius?"}]}
 | {"type":"list","ordered","items":[html]} | {"type":"quote","html","cite?"} | {"type":"separator"}
 | {"type":"columns","columns":[{"background?","textColor?","radius?","padding?","shadow?","blocks":[Block without columns]}]}  (1-6 columns)
Colors must be #rrggbb or rgba(r, g, b, a). "html" may only contain <strong>, <em>, <code>, <br>, <a href>.`;

async function callClaude(system: string, user: string): Promise<string> {
  const { configured, model } = aiStatus();
  if (!configured) throw new Error('AI is not configured');
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 90_000);
  try {
    const base = (process.env.ANTHROPIC_BASE_URL || 'https://api.anthropic.com').replace(/\/+$/, '');
    const res = await fetch(`${base}/v1/messages`, {
      method: 'POST',
      signal: ctrl.signal,
      headers: {
        'content-type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY!,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({ model, max_tokens: 16000, system, messages: [{ role: 'user', content: user }] }),
    });
    const data: any = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data?.error?.message || `AI request failed (HTTP ${res.status})`);
    return (data.content || []).filter((c: any) => c.type === 'text').map((c: any) => c.text).join('');
  } finally {
    clearTimeout(timer);
  }
}

function extractJson(text: string): unknown {
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  const raw = fenced ? fenced[1] : text.slice(text.indexOf('{'), text.lastIndexOf('}') + 1);
  return JSON.parse(raw);
}

export interface AiResult {
  model: PageModel;
  used: boolean;
  note: string;
}

/** Step 3 of the workflow: let the AI organise captured content into clean sections. */
export async function organizeWithAi(model: PageModel): Promise<AiResult> {
  if (!aiStatus().configured) return { model, used: false, note: 'Basic mode: sections were organized by the built-in rules (no AI key configured).' };
  const json = JSON.stringify(model);
  if (json.length > MAX_MODEL_CHARS) return { model, used: false, note: 'Page too large for the AI pass; used the built-in rules instead.' };
  try {
    const text = await callClaude(
      `You clean up website captures for conversion into WordPress blocks. ${SCHEMA_HINT}
Rules: keep the page's real text and images — never invent copy, links, prices or testimonials. You may: fix section labels/kinds,
remove junk (cookie notices, "skip to content", duplicate menus, empty items), merge paragraphs that were split mid-sentence,
make heading levels logical (exactly one level-1 heading on the page), and group obvious card/feature lists into columns.
Respond with the full PageModel JSON only.`,
      json,
    );
    const next = sanitizePageModel({ ...(extractJson(text) as object), version: 1, source: model.source });
    return { model: next, used: true, note: 'AI organized the captured content into sections.' };
  } catch (e: any) {
    return { model, used: false, note: `AI pass skipped (${e?.message || 'invalid response'}); used the built-in rules instead.` };
  }
}

/** Step 5: apply a user's change request ("make the hero dark", "shorten the intro"…). */
export async function refineWithAi(model: PageModel, instruction: string): Promise<AiResult> {
  if (!aiStatus().configured) throw new Error('Prompt edits need an AI key (ANTHROPIC_API_KEY). Basic mode cannot apply free-text changes.');
  const text = await callClaude(
    `You edit a website layout described as JSON before it is converted to WordPress blocks. ${SCHEMA_HINT}
Apply the user's requested change and keep everything else identical. Only add new text if the user explicitly asks for it.
Respond with the full updated PageModel JSON only.`,
    `Change request: ${instruction.slice(0, 2000)}\n\nCurrent PageModel:\n${JSON.stringify(model)}`,
  );
  let next: PageModel;
  try {
    next = sanitizePageModel({ ...(extractJson(text) as object), version: 1, source: model.source });
  } catch (e: any) {
    throw new Error(`The AI returned an unusable layout (${e?.message}). Nothing was changed.`);
  }
  return { model: next, used: true, note: 'Applied your change with AI.' };
}
