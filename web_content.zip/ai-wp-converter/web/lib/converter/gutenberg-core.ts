/**
 * PageModel → standard Gutenberg (core) blocks.
 * Markup mirrors the save() output of @wordpress/block-library and is checked by
 * tools/validator against the real Gutenberg parser (current + WP 6.8-era versions).
 */
import type { Block, ButtonItem, Column, LeafBlock, PageModel, Section } from './types';
import { block, classAttr, fluidSize, styleAttr, MAX_FIXED_IMAGE_WIDTH } from './blocks-common';
import { escapeAttr, escapeText } from './sanitize';

interface Ctx {
  textColor?: string; // inherited text colour, so children only set colours that differ
  counts: { core: number; images: number };
}

const isBodySize = (n?: number) => !n || (n >= 14 && n <= 18);

function heading(b: Extract<LeafBlock, { type: 'heading' }>, ctx: Ctx): string {
  const color = b.color && b.color !== ctx.textColor ? b.color : undefined;
  const fontSize = b.fontSize ? fluidSize(b.fontSize) : undefined;
  const attrs = {
    textAlign: b.align && b.align !== 'left' ? b.align : undefined,
    level: b.level === 2 ? undefined : b.level,
    style: { color: { text: color }, typography: { fontSize, fontWeight: b.fontWeight ? String(b.fontWeight) : undefined } },
  };
  const cls = classAttr(['wp-block-heading', attrs.textAlign && `has-text-align-${attrs.textAlign}`, color && 'has-text-color']);
  const st = styleAttr([['color', color], ['font-size', fontSize], ['font-weight', b.fontWeight]]);
  ctx.counts.core++;
  return block('core/heading', attrs, `<h${b.level}${cls}${st}>${b.html}</h${b.level}>`);
}

function paragraph(b: Extract<LeafBlock, { type: 'paragraph' }>, ctx: Ctx): string {
  const color = b.color && b.color !== ctx.textColor ? b.color : undefined;
  const fs = b.small ? 14 : isBodySize(b.fontSize) ? undefined : b.fontSize;
  const fontSize = fs ? fluidSize(fs) : undefined;
  const align = b.align && b.align !== 'left' ? b.align : undefined;
  const attrs = { align, style: { color: { text: color }, typography: { fontSize } } };
  const cls = classAttr([align && `has-text-align-${align}`, color && 'has-text-color']);
  const st = styleAttr([['color', color], ['font-size', fontSize]]);
  ctx.counts.core++;
  return block('core/paragraph', attrs, `<p${cls}${st}>${b.html}</p>`);
}

function image(b: Extract<LeafBlock, { type: 'image' }>, ctx: Ctx): string {
  const width = b.width && b.width <= MAX_FIXED_IMAGE_WIDTH ? `${b.width}px` : undefined;
  const radius = b.radius ? `${b.radius}px` : undefined;
  const attrs = { width, style: { border: { radius } } };
  const cls = classAttr(['wp-block-image', width && 'is-resized', radius && 'has-custom-border']);
  const st = styleAttr([['border-radius', radius], ['width', width]]);
  ctx.counts.core++;
  ctx.counts.images++;
  return block('core/image', attrs, `<figure${cls}><img src="${escapeAttr(b.src)}" alt="${escapeAttr(b.alt || '')}"${st}/></figure>`);
}

function button(it: ButtonItem, ctx: Ctx): string {
  const outline = it.variant === 'outline';
  const bg = outline ? undefined : it.background;
  const radius = it.radius !== undefined ? `${it.radius}px` : undefined;
  const borderColor = outline ? it.borderColor || it.color : undefined;
  const attrs = {
    className: outline ? 'is-style-outline' : undefined,
    style: {
      color: { background: bg, text: it.color },
      border: { radius, color: borderColor, width: borderColor ? '2px' : undefined },
    },
  };
  const linkCls = classAttr([
    'wp-block-button__link',
    it.color && 'has-text-color',
    bg && 'has-background',
    borderColor && 'has-border-color',
    'wp-element-button',
  ]);
  const st = styleAttr([
    ['border-color', borderColor],
    ['border-width', borderColor ? '2px' : undefined],
    ['border-radius', radius],
    ['color', it.color],
    ['background-color', bg],
  ]);
  const href = it.href ? ` href="${escapeAttr(it.href)}"` : '';
  ctx.counts.core++;
  return block('core/button', attrs, `<div${classAttr(['wp-block-button', outline && 'is-style-outline'])}><a${linkCls}${href}${st}>${escapeText(it.text)}</a></div>`);
}

function buttons(b: Extract<LeafBlock, { type: 'buttons' }>, ctx: Ctx): string {
  const justify = b.align === 'center' ? 'center' : b.align === 'right' ? 'right' : undefined;
  const attrs = { layout: justify ? { type: 'flex', justifyContent: justify } : undefined };
  ctx.counts.core++;
  return block('core/buttons', attrs, `<div class="wp-block-buttons">${b.items.map((it) => button(it, ctx)).join('\n')}</div>`);
}

function list(b: Extract<LeafBlock, { type: 'list' }>, ctx: Ctx): string {
  const tag = b.ordered ? 'ol' : 'ul';
  const items = b.items.map((h) => {
    ctx.counts.core++;
    return block('core/list-item', {}, `<li>${h}</li>`);
  });
  ctx.counts.core++;
  return block('core/list', { ordered: b.ordered || undefined }, `<${tag} class="wp-block-list">${items.join('\n')}</${tag}>`);
}

function quote(b: Extract<LeafBlock, { type: 'quote' }>, ctx: Ctx): string {
  ctx.counts.core += 2;
  const p = block('core/paragraph', {}, `<p>${b.html}</p>`);
  const cite = b.cite ? `<cite>${escapeText(b.cite)}</cite>` : '';
  return block('core/quote', {}, `<blockquote class="wp-block-quote">${p}${cite}</blockquote>`);
}

function leaf(b: LeafBlock, ctx: Ctx): string {
  switch (b.type) {
    case 'heading': return heading(b, ctx);
    case 'paragraph': return paragraph(b, ctx);
    case 'image': return image(b, ctx);
    case 'buttons': return buttons(b, ctx);
    case 'list': return list(b, ctx);
    case 'quote': return quote(b, ctx);
    case 'separator':
      ctx.counts.core++;
      return block('core/separator', {}, '<hr class="wp-block-separator has-alpha-channel-opacity"/>');
  }
}

function column(c: Column, ctx: Ctx): string {
  const pad = c.background || c.borderColor ? `${c.padding || 24}px` : undefined;
  const radius = c.radius ? `${c.radius}px` : undefined;
  const borderColor = c.borderColor;
  const attrs = {
    className: c.shadow ? 'aiwpc-card-shadow' : undefined,
    style: {
      color: { background: c.background, text: c.textColor && c.textColor !== ctx.textColor ? c.textColor : undefined },
      spacing: pad ? { padding: { top: pad, right: pad, bottom: pad, left: pad } } : undefined,
      border: { radius, color: borderColor, width: borderColor ? '1px' : undefined },
    },
  };
  const textColor = attrs.style.color.text;
  const cls = classAttr([
    'wp-block-column',
    c.shadow && 'aiwpc-card-shadow',
    borderColor && 'has-border-color',
    textColor && 'has-text-color',
    c.background && 'has-background',
  ]);
  const st = styleAttr([
    ['border-color', borderColor],
    ['border-width', borderColor ? '1px' : undefined],
    ['border-radius', radius],
    ['color', textColor],
    ['background-color', c.background],
    ['padding-top', pad],
    ['padding-right', pad],
    ['padding-bottom', pad],
    ['padding-left', pad],
  ]);
  const inner = c.blocks.map((b) => leaf(b, { ...ctx, textColor: c.textColor || ctx.textColor })).join('\n\n');
  ctx.counts.core++;
  return block('core/column', attrs, `<div${cls}${st}>${inner}</div>`);
}

function columns(b: Extract<Block, { type: 'columns' }>, ctx: Ctx): string {
  ctx.counts.core++;
  return block('core/columns', {}, `<div class="wp-block-columns">${b.columns.map((c) => column(c, ctx)).join('\n\n')}</div>`);
}

function sectionBody(s: Section, ctx: Ctx): string {
  return s.blocks.map((b) => (b.type === 'columns' ? columns(b, ctx) : leaf(b, ctx))).join('\n\n');
}

function section(s: Section, model: PageModel, ctx: Ctx): string {
  const py = `${Math.max(32, Math.min(s.paddingY ?? 64, 160))}px`;
  const text = s.textColor && s.textColor !== model.theme.text ? s.textColor : undefined;
  const inner = sectionBody(s, { ...ctx, textColor: s.textColor || model.theme.text });
  const className = `aiwpc-section aiwpc-${s.kind}`;
  ctx.counts.core++;
  if (s.backgroundImage) {
    const overlay = s.background || '#000000';
    const attrs = {
      url: s.backgroundImage,
      dimRatio: s.background ? 70 : 50,
      customOverlayColor: overlay,
      isUserOverlayColor: true,
      align: 'full',
      className,
      style: { spacing: { padding: { top: py, bottom: py } } },
      layout: { type: 'constrained' },
    };
    const dim = attrs.dimRatio === 50 ? 'has-background-dim' : `has-background-dim-${attrs.dimRatio} has-background-dim`;
    ctx.counts.images++;
    return block(
      'core/cover',
      attrs,
      `<div class="wp-block-cover alignfull ${className}"${styleAttr([['padding-top', py], ['padding-bottom', py]])}><img class="wp-block-cover__image-background" alt="" src="${escapeAttr(s.backgroundImage)}" data-object-fit="cover"/><span aria-hidden="true" class="wp-block-cover__background ${dim}" style="background-color:${overlay}"></span><div class="wp-block-cover__inner-container">${inner}</div></div>`,
    );
  }
  const bg = s.background && s.background !== model.theme.background ? s.background : undefined;
  const attrs = {
    align: 'full',
    className,
    style: {
      color: { background: bg, text },
      spacing: { padding: { top: py, bottom: py, left: '24px', right: '24px' } },
    },
    layout: { type: 'constrained' },
  };
  const cls = classAttr(['wp-block-group', 'alignfull', 'aiwpc-section', `aiwpc-${s.kind}`, text && 'has-text-color', bg && 'has-background']);
  const st = styleAttr([['color', text], ['background-color', bg], ['padding-top', py], ['padding-right', '24px'], ['padding-bottom', py], ['padding-left', '24px']]);
  return block('core/group', attrs, `<div${cls}${st}>${inner}</div>`);
}

export function toCoreBlocks(model: PageModel) {
  const ctx: Ctx = { counts: { core: 0, images: 0 } };
  const markup = model.sections.map((s) => section(s, model, ctx)).join('\n\n');
  return { markup, counts: { core: ctx.counts.core, kadence: 0, images: ctx.counts.images } };
}

/** Used by the Kadence generator for block types Kadence has no simpler equivalent for. */
export function coreLeaf(b: LeafBlock, textColor: string | undefined, counts: { core: number; images: number }): string {
  return leaf(b, { textColor, counts });
}
