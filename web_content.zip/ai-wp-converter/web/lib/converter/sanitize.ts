import { parseHTML } from 'linkedom';
import { PageModelSchema, type Block, type LeafBlock, type PageModel } from './types';

/** Escape text for HTML element content. */
export function escapeText(s: string): string {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

/** Escape a value for a double-quoted HTML attribute. */
export function escapeAttr(s: string): string {
  return String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

export function safeHref(href: string | undefined): string {
  if (!href) return '';
  const h = href.trim();
  if (/^(mailto:|tel:)/i.test(h)) return h.slice(0, 500);
  if (/^#[\w-]*$/.test(h)) return h;
  try {
    const u = new URL(h);
    return u.protocol === 'http:' || u.protocol === 'https:' ? u.href : '';
  } catch {
    return '';
  }
}

export function safeImageSrc(src: string | undefined): string {
  if (!src) return '';
  try {
    const u = new URL(src.trim());
    return u.protocol === 'http:' || u.protocol === 'https:' ? u.href : '';
  } catch {
    return '';
  }
}

/**
 * Rebuilds inline HTML from a strict whitelist: <strong> <em> <code> <a href> <br>.
 * Everything else is unwrapped to its text. Attributes other than a safe href are dropped.
 */
export function sanitizeInline(html: string): string {
  if (!html) return '';
  if (!/[<&]/.test(html)) return escapeText(html).replace(/\s+/g, ' ').trim();
  const { document } = parseHTML(`<!doctype html><html><body><div id="r">${html}</div></body></html>`);
  const root = document.getElementById('r');
  if (!root) return '';
  const walk = (node: any): string => {
    let out = '';
    for (const n of Array.from(node.childNodes) as any[]) {
      if (n.nodeType === 3) {
        out += escapeText(String(n.textContent)).replace(/\s+/g, ' ');
        continue;
      }
      if (n.nodeType !== 1) continue;
      const t = String(n.tagName).toUpperCase();
      if (['SCRIPT', 'STYLE', 'IFRAME', 'OBJECT', 'EMBED', 'TEMPLATE', 'SVG', 'NOSCRIPT'].includes(t)) continue;
      if (t === 'BR') {
        out += '<br>';
        continue;
      }
      const inner = walk(n);
      if (!inner.replace(/<[^>]+>/g, '').trim() && t !== 'BR') continue;
      if (t === 'STRONG' || t === 'B') out += `<strong>${inner}</strong>`;
      else if (t === 'EM' || t === 'I') out += `<em>${inner}</em>`;
      else if (t === 'CODE') out += `<code>${inner}</code>`;
      else if (t === 'A') {
        const href = safeHref(n.getAttribute('href') || '');
        out += href ? `<a href="${escapeAttr(href)}">${inner}</a>` : inner;
      } else out += inner;
    }
    return out;
  };
  return walk(root).replace(/^(\s|<br>)+|(\s|<br>)+$/g, '').replace(/\s{2,}/g, ' ');
}

export function plainText(html: string): string {
  return html
    .replace(/<br>/g, ' ')
    .replace(/<[^>]+>/g, '')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&amp;/g, '&')
    .replace(/\s+/g, ' ')
    .trim();
}

function cleanLeaf(b: LeafBlock): LeafBlock | null {
  switch (b.type) {
    case 'heading':
    case 'paragraph': {
      const html = sanitizeInline(b.html);
      return plainText(html) ? { ...b, html } : null;
    }
    case 'quote': {
      const html = sanitizeInline(b.html);
      return plainText(html) ? { ...b, html, cite: b.cite ? plainText(escapeText(b.cite)) : undefined } : null;
    }
    case 'list': {
      const items = b.items.map(sanitizeInline).filter((h) => plainText(h));
      return items.length ? { ...b, items } : null;
    }
    case 'image': {
      const src = safeImageSrc(b.src);
      return src ? { ...b, src, alt: (b.alt || '').replace(/[<>]/g, '').slice(0, 300) } : null;
    }
    case 'buttons': {
      const items = b.items
        .map((it) => ({ ...it, text: it.text.replace(/[<>]/g, '').trim(), href: safeHref(it.href) }))
        .filter((it) => it.text);
      return items.length ? { ...b, items } : null;
    }
    case 'separator':
      return b;
  }
}

/** Section-level text alignment becomes explicit on each text/button block (so every output format agrees). */
function inheritAlign<T extends Block>(b: T, align: 'left' | 'center' | 'right' | undefined): T {
  if (!align || align === 'left') return b;
  if (b.type === 'heading' || b.type === 'paragraph' || b.type === 'buttons') return (b.align ? b : { ...b, align }) as T;
  if (b.type === 'columns') return { ...b, columns: b.columns.map((c) => ({ ...c, blocks: c.blocks.map((x) => inheritAlign(x, align)) })) } as T;
  return b;
}

function cleanBlock(b: Block): Block | null {
  if (b.type === 'columns') {
    const columns = b.columns
      .map((c) => ({ ...c, blocks: c.blocks.map(cleanLeaf).filter((x): x is LeafBlock => !!x) }))
      .filter((c) => c.blocks.length);
    return columns.length ? { ...b, columns } : null;
  }
  return cleanLeaf(b);
}

/**
 * Validate + sanitize untrusted page data (extension capture, uploaded JSON, AI output).
 * Throws a readable error when the structure is invalid.
 */
export function sanitizePageModel(input: unknown): PageModel {
  const parsed = PageModelSchema.safeParse(input);
  if (!parsed.success) {
    const issue = parsed.error.issues[0];
    throw new Error(`Invalid capture data at "${issue.path.join('.')}": ${issue.message}`);
  }
  const model = parsed.data;
  const sections = model.sections
    .map((s) => ({
      ...s,
      label: s.label.replace(/[<>]/g, ''),
      backgroundImage: safeImageSrc(s.backgroundImage) || undefined,
      blocks: s.blocks
        .map(cleanBlock)
        .filter((x): x is Block => !!x)
        .map((b) => inheritAlign(b, s.align)),
    }))
    .filter((s) => s.blocks.length);
  if (!sections.length) throw new Error('No convertible content was found in the capture.');
  return {
    ...model,
    source: { ...model.source, url: safeHref(model.source.url) || '', title: plainText(escapeText(model.source.title)) },
    sections,
  };
}
