/**
 * PageModel → Kadence Blocks markup (Row Layout, Section/Column, Advanced Text, Advanced Image,
 * Advanced Button). Attribute names come from Kadence Blocks' own block.json files and the static
 * markup mirrors their save() functions (verified by tools/validator, which compiles Kadence's
 * real save() code from github.com/stellarwp/kadence-blocks — see KADENCE_VERIFIED_VERSION).
 *
 * Lists, quotes and separators stay as core blocks (fully supported inside Kadence columns).
 */
import type { Block, ButtonItem, Column, LeafBlock, PageModel, Section } from './types';
import { block, makeIdFactory, MAX_FIXED_IMAGE_WIDTH } from './blocks-common';
import { escapeAttr } from './sanitize';
import { coreLeaf } from './gutenberg-core';

export const KADENCE_VERIFIED_VERSION = '3.7.12.1';

interface Ctx {
  id: () => string;
  textColor?: string;
  counts: { core: number; kadence: number; images: number };
}

function responsiveSize(px?: number): [number | string, number | string, number | string] | undefined {
  if (!px) return undefined;
  if (px < 30) return [px, '', ''];
  return [px, Math.round(px * 0.82), Math.max(24, Math.round(px * 0.65))];
}

function advText(b: Extract<LeafBlock, { type: 'heading' | 'paragraph' }>, ctx: Ctx): string {
  const uid = ctx.id();
  const isHeading = b.type === 'heading';
  const level = isHeading ? (b as Extract<LeafBlock, { type: 'heading' }>).level : 2;
  const color = b.color && b.color !== ctx.textColor ? b.color : undefined;
  let size: number | undefined = b.fontSize;
  if (!isHeading) size = (b as Extract<LeafBlock, { type: 'paragraph' }>).small ? 14 : b.fontSize && (b.fontSize < 14 || b.fontSize > 18) ? b.fontSize : undefined;
  const attrs: Record<string, unknown> = {
    level: isHeading && level !== 2 ? level : undefined,
    uniqueID: uid,
    align: b.align && b.align !== 'left' ? b.align : undefined,
    color,
    fontSize: responsiveSize(size),
    fontWeight: isHeading && (b as Extract<LeafBlock, { type: 'heading' }>).fontWeight ? String((b as Extract<LeafBlock, { type: 'heading' }>).fontWeight) : undefined,
    htmlTag: isHeading ? undefined : 'p',
  };
  const tag = isHeading ? `h${level}` : 'p';
  ctx.counts.kadence++;
  return block(
    'kadence/advancedheading',
    attrs,
    `<${tag} class="kt-adv-heading${uid} wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading${uid}">${b.html}</${tag}>`,
  );
}

function advImage(b: Extract<LeafBlock, { type: 'image' }>, ctx: Ctx): string {
  const uid = ctx.id();
  const width = b.width && b.width <= MAX_FIXED_IMAGE_WIDTH ? b.width : undefined;
  const r = b.radius;
  const attrs = {
    width,
    uniqueID: uid,
    borderRadius: r ? [r, r, r, r] : undefined,
  };
  ctx.counts.kadence++;
  ctx.counts.images++;
  const cls = `wp-block-kadence-image kb-image${uid}${width ? ' is-resized' : ''}`;
  return block(
    'kadence/image',
    attrs,
    `<figure class="${cls}"><img src="${escapeAttr(b.src)}" alt="${escapeAttr(b.alt || '')}" class="kb-img"${width ? ` width="${width}"` : ''}/></figure>`,
  );
}

function singleButton(it: ButtonItem, ctx: Ctx): string {
  const outline = it.variant === 'outline';
  const r = it.radius;
  ctx.counts.kadence++;
  return block(
    'kadence/singlebtn',
    {
      uniqueID: ctx.id(),
      text: it.text,
      link: it.href || undefined,
      color: it.color,
      background: outline ? undefined : it.background,
      borderRadius: r !== undefined ? [r, r, r, r] : undefined,
      inheritStyles: outline ? 'outline' : undefined,
    },
    null,
  );
}

function advButtons(b: Extract<LeafBlock, { type: 'buttons' }>, ctx: Ctx): string {
  const uid = ctx.id();
  const hAlign = b.align === 'center' ? undefined : b.align === 'right' ? 'right' : 'left'; // Kadence default is center
  ctx.counts.kadence++;
  const inner = b.items.map((it) => singleButton(it, ctx)).join('\n');
  return block('kadence/advancedbtn', { hAlign, uniqueID: uid }, `<div class="wp-block-kadence-advancedbtn kb-buttons-wrap kb-btns${uid}">${inner}</div>`);
}

function leaf(b: LeafBlock, ctx: Ctx): string {
  switch (b.type) {
    case 'heading':
    case 'paragraph':
      return advText(b, ctx);
    case 'image':
      return advImage(b, ctx);
    case 'buttons':
      return advButtons(b, ctx);
    default:
      return coreLeaf(b, ctx.textColor, ctx.counts);
  }
}

function kColumn(index: number, c: Omit<Partial<Column>, 'blocks'> & { blocks: string[] }, ctx: Ctx): string {
  const uid = ctx.id();
  const hasBox = !!(c.background || c.borderColor);
  const p = hasBox ? c.padding || 24 : undefined;
  const r = c.radius;
  const attrs = {
    id: index + 1,
    background: c.background,
    borderRadius: r ? [r, r, r, r] : undefined,
    uniqueID: uid,
    textColor: c.textColor && c.textColor !== ctx.textColor ? c.textColor : undefined,
    padding: p ? [p, p, p, p] : undefined,
    // Kadence borderStyle: one entry, each side = [color, style, width]
    borderStyle: c.borderColor
      ? [{ top: [c.borderColor, 'solid', 1], right: [c.borderColor, 'solid', 1], bottom: [c.borderColor, 'solid', 1], left: [c.borderColor, 'solid', 1], unit: 'px' }]
      : undefined,
    className: c.shadow ? 'aiwpc-card-shadow' : undefined,
    kbVersion: 2,
  };
  ctx.counts.kadence++;
  const cls = `wp-block-kadence-column kadence-column${uid}${c.shadow ? ' aiwpc-card-shadow' : ''}`;
  return block('kadence/column', attrs, `<div class="${cls}"><div class="kt-inside-inner-col">${c.blocks.join('\n\n')}</div></div>`);
}

function kRow(columns: string[], attrs: Record<string, unknown>, ctx: Ctx): string {
  ctx.counts.kadence++;
  return block('kadence/rowlayout', { uniqueID: ctx.id(), columns: columns.length, colLayout: 'equal', ...attrs, kbVersion: 2 }, columns.join('\n\n'));
}

/** A model "columns" block → a nested Row Layout without its own padding/background. */
function nestedRow(b: Extract<Block, { type: 'columns' }>, ctx: Ctx): string {
  const cols = b.columns.map((c, i) =>
    kColumn(i, { ...c, blocks: c.blocks.map((x) => leaf(x, { ...ctx, textColor: c.textColor || ctx.textColor })) }, ctx),
  );
  return kRow(cols, { padding: [0, '', 0, ''], columnGutter: 'wide' }, ctx);
}

function section(s: Section, model: PageModel, ctx: Ctx): string {
  const py = Math.max(32, Math.min(s.paddingY ?? 64, 160));
  const sctx = { ...ctx, textColor: s.textColor || model.theme.text };
  const inner = s.blocks.map((b) => (b.type === 'columns' ? nestedRow(b, sctx) : leaf(b, sctx)));
  const bg = s.background && s.background !== model.theme.background ? s.background : undefined;
  const textColor = s.textColor && s.textColor !== model.theme.text ? s.textColor : undefined;
  if (s.backgroundImage) ctx.counts.images++;
  return kRow(
    [kColumn(0, { blocks: inner }, ctx)],
    {
      columns: 1,
      bgColor: bg,
      bgImg: s.backgroundImage,
      overlay: s.backgroundImage ? s.background || '#000000' : undefined,
      overlayOpacity: s.backgroundImage ? (s.background ? 70 : 50) : undefined,
      textColor,
      align: 'full',
      inheritMaxWidth: true,
      padding: [py, '', py, ''],
      className: `aiwpc-section aiwpc-${s.kind}`,
    },
    ctx,
  );
}

export function toKadenceBlocks(model: PageModel, seed?: string) {
  const ctx: Ctx = { id: makeIdFactory(seed), counts: { core: 0, kadence: 0, images: 0 } };
  const markup = model.sections.map((s) => section(s, model, ctx)).join('\n\n');
  return { markup, counts: ctx.counts };
}
