/** Helpers shared by the Gutenberg generators. */

/** Same escaping the WordPress serializer applies to block comment attributes. */
export function serializeAttributes(attrs: Record<string, unknown>): string {
  return JSON.stringify(attrs)
    .replace(/--/g, '\\u002d\\u002d')
    .replace(/</g, '\\u003c')
    .replace(/>/g, '\\u003e')
    .replace(/&/g, '\\u0026')
    .replace(/\\"/g, '\\u0022');
}

function prune(v: unknown): unknown {
  if (Array.isArray(v)) return v;
  if (v && typeof v === 'object') {
    const out: Record<string, unknown> = {};
    for (const [k, val] of Object.entries(v)) {
      const p = prune(val);
      if (p === undefined || p === null || p === '') continue;
      if (typeof p === 'object' && !Array.isArray(p) && !Object.keys(p as object).length) continue;
      out[k] = p;
    }
    return out;
  }
  return v;
}

export function cleanAttrs(attrs: Record<string, unknown>): Record<string, unknown> {
  return prune(attrs) as Record<string, unknown>;
}

/** Wrap saved HTML in a block delimiter. `name` like "core/heading" or "kadence/column". */
export function block(name: string, attrs: Record<string, unknown>, html?: string | null): string {
  const short = name.startsWith('core/') ? name.slice(5) : name;
  const a = cleanAttrs(attrs);
  const json = Object.keys(a).length ? ' ' + serializeAttributes(a) : '';
  if (html === null || html === undefined) return `<!-- wp:${short}${json} /-->`;
  return `<!-- wp:${short}${json} -->\n${html}\n<!-- /wp:${short} -->`;
}

export function classAttr(classes: (string | false | undefined | null)[]): string {
  const c = classes.filter(Boolean).join(' ');
  return c ? ` class="${c}"` : '';
}

export function styleAttr(decls: [string, string | number | undefined | null | false][]): string {
  const s = decls.filter(([, v]) => v !== undefined && v !== null && v !== '' && v !== false).map(([k, v]) => `${k}:${v}`).join(';');
  return s ? ` style="${s}"` : '';
}

/** Responsive font size for large headings: scales down on small screens. */
export function fluidSize(px: number): string {
  if (px < 30) return `${px}px`;
  const min = Math.max(24, Math.round(px * 0.62));
  const vw = Math.round((px / 14.4) * 100) / 100;
  return `clamp(${min}px, ${vw}vw, ${px}px)`;
}

/** Short random prefix so Kadence uniqueIDs don't collide with blocks already on the page. */
export function makeIdFactory(seed?: string) {
  const prefix = (seed || Math.random().toString(36).slice(2, 7)).replace(/[^a-z0-9]/gi, '').slice(0, 6) || 'cnv';
  let n = 0;
  return () => `${prefix}_${(++n).toString(36)}`;
}

export const MAX_FIXED_IMAGE_WIDTH = 600;
