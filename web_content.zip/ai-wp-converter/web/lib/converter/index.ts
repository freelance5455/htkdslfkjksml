import type { ConversionOutput, OutputFormat, PageModel } from './types';
import { sanitizePageModel } from './sanitize';
import { toCoreBlocks } from './gutenberg-core';
import { toKadenceBlocks } from './gutenberg-kadence';
import { htmlDocument, pageCss, previewDocument, wordpressExtraCss } from './html-export';

export { sanitizePageModel } from './sanitize';
export { KADENCE_VERIFIED_VERSION } from './gutenberg-kadence';
export type { PageModel, ConversionOutput, OutputFormat } from './types';

function walk(model: PageModel, fn: (b: any) => void) {
  for (const s of model.sections)
    for (const b of s.blocks) {
      fn(b);
      if (b.type === 'columns') b.columns.forEach((c) => c.blocks.forEach(fn));
    }
}

/** Notes about styling that the generated blocks do not reproduce. */
export function styleWarnings(model: PageModel, format: OutputFormat): string[] {
  const w = [...(model.warnings || [])];
  let images = 0;
  let shadows = 0;
  let outline = 0;
  walk(model, (b) => {
    if (b.type === 'image') images++;
    if (b.type === 'buttons') outline += b.items.filter((i: any) => i.variant === 'outline').length;
  });
  model.sections.forEach((s) => s.blocks.forEach((b) => b.type === 'columns' && b.columns.forEach((c) => c.shadow && shadows++)));
  const bgImages = model.sections.filter((s) => s.backgroundImage).length;
  if (images || bgImages)
    w.push(
      `Images (${images + bgImages}) still point to the original website. Only use them if you have permission, and upload them to your Media Library (the companion plugin can import them when it creates the draft).`,
    );
  if (model.theme.fontFamily)
    w.push(`Fonts are not embedded. The source used "${model.theme.fontFamily.split(',')[0].replace(/["']/g, '')}" — set it in Customizer → Typography if you have a license for it.`);
  if (shadows) w.push(`${shadows} card shadow(s) need the small "Additional CSS" snippet (class aiwpc-card-shadow).`);
  if (format === 'kadence' && outline)
    w.push('Outline buttons use your Kadence global "Outline" button style; exact border colors may differ.');
  w.push('Hover effects, animations, custom scripts, forms and navigation menus are not converted.');
  return Array.from(new Set(w));
}

export interface ConvertOptions {
  format?: OutputFormat;
  seed?: string;
}

export function convertModel(input: unknown, opts: ConvertOptions = {}): { model: PageModel; output: ConversionOutput } {
  const model = sanitizePageModel(input);
  const format = opts.format || 'kadence';
  const gen = format === 'kadence' ? toKadenceBlocks(model, opts.seed) : toCoreBlocks(model);
  let blockCount = 0;
  walk(model, () => blockCount++);
  const output: ConversionOutput = {
    format,
    blocks: gen.markup + '\n',
    css: wordpressExtraCss(format),
    html: htmlDocument(model),
    htmlCss: pageCss(model),
    previewDoc: previewDocument(model),
    warnings: styleWarnings(model, format),
    stats: {
      sections: model.sections.length,
      blocks: blockCount,
      images: gen.counts.images,
      kadenceBlocks: (gen.counts as any).kadence || 0,
      coreBlocks: gen.counts.core,
    },
  };
  return { model, output };
}
