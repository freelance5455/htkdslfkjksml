import { z } from 'zod';

/**
 * PageModel — the intermediate, editable representation every conversion goes through:
 *   capture (extension / URL) → PageModel → (optional AI edits) → Gutenberg / Kadence / HTML+CSS
 * Anything coming from outside (extension, uploaded JSON, AI output) is validated with these schemas.
 */

const color = z
  .string()
  .max(40)
  .regex(/^(#[0-9a-fA-F]{6}([0-9a-fA-F]{2})?|rgba\(\s*\d{1,3},\s*\d{1,3},\s*\d{1,3},\s*(0|1|0?\.\d+)\s*\))$/, 'unsupported color');
const url = z.string().max(2048);
const inlineHtml = z.string().max(20000);
const align = z.enum(['left', 'center', 'right']).optional();

export const ButtonItemSchema = z.object({
  text: z.string().min(1).max(120),
  href: url.optional().default(''),
  variant: z.enum(['fill', 'outline']).optional().default('fill'),
  background: color.optional(),
  color: color.optional(),
  borderColor: color.optional(),
  radius: z.number().min(0).max(999).optional(),
});

const HeadingSchema = z.object({
  type: z.literal('heading'),
  level: z.number().int().min(1).max(6),
  html: inlineHtml,
  color: color.optional(),
  align,
  fontSize: z.number().min(8).max(200).optional(),
  fontWeight: z.number().min(100).max(900).optional(),
});
const ParagraphSchema = z.object({
  type: z.literal('paragraph'),
  html: inlineHtml,
  color: color.optional(),
  align,
  fontSize: z.number().min(8).max(120).optional(),
  small: z.boolean().optional(),
});
const ImageSchema = z.object({
  type: z.literal('image'),
  src: url,
  alt: z.string().max(300).optional().default(''),
  width: z.number().min(1).max(5000).optional(),
  height: z.number().min(1).max(5000).optional(),
  radius: z.number().min(0).max(999).optional(),
});
const ButtonsSchema = z.object({
  type: z.literal('buttons'),
  items: z.array(ButtonItemSchema).min(1).max(8),
  align,
});
const ListSchema = z.object({
  type: z.literal('list'),
  ordered: z.boolean().optional().default(false),
  items: z.array(inlineHtml).min(1).max(100),
});
const QuoteSchema = z.object({ type: z.literal('quote'), html: inlineHtml, cite: z.string().max(200).optional() });
const SeparatorSchema = z.object({ type: z.literal('separator') });

const LeafBlockSchema = z.discriminatedUnion('type', [HeadingSchema, ParagraphSchema, ImageSchema, ButtonsSchema, ListSchema, QuoteSchema, SeparatorSchema]);

export const ColumnSchema = z.object({
  background: color.optional(),
  textColor: color.optional(),
  borderColor: color.optional(),
  radius: z.number().min(0).max(999).optional(),
  padding: z.number().min(0).max(200).optional(),
  shadow: z.boolean().optional(),
  blocks: z.array(LeafBlockSchema).max(200),
});
const ColumnsSchema = z.object({ type: z.literal('columns'), columns: z.array(ColumnSchema).min(1).max(6) });

export const BlockSchema = z.discriminatedUnion('type', [HeadingSchema, ParagraphSchema, ImageSchema, ButtonsSchema, ListSchema, QuoteSchema, SeparatorSchema, ColumnsSchema]);

export const SectionSchema = z.object({
  id: z.string().max(40),
  label: z.string().max(120).optional().default('Section'),
  kind: z.enum(['hero', 'features', 'content', 'cta', 'footer', 'header']).optional().default('content'),
  background: color.optional(),
  backgroundImage: url.optional(),
  gradient: z.boolean().optional(),
  textColor: color.optional(),
  align: align,
  paddingY: z.number().min(0).max(300).optional(),
  blocks: z.array(BlockSchema).max(400),
});

export const PageModelSchema = z.object({
  version: z.literal(1),
  source: z.object({
    url: z.string().max(2048).optional().default(''),
    title: z.string().max(300).optional().default(''),
    lang: z.string().max(20).optional().default(''),
    mode: z.enum(['extension', 'url', 'upload', 'ai']).optional().default('upload'),
    scope: z.enum(['page', 'section']).optional().default('page'),
    capturedAt: z.string().max(40).optional(),
  }),
  theme: z.object({
    background: color.optional().default('#ffffff'),
    text: color.optional().default('#1f2937'),
    accent: color.optional(),
    fontFamily: z.string().max(200).optional(),
    headingFontFamily: z.string().max(200).optional(),
  }),
  sections: z.array(SectionSchema).min(1).max(60),
  warnings: z.array(z.string().max(400)).max(100).optional().default([]),
});

export type ButtonItem = z.infer<typeof ButtonItemSchema>;
export type Column = z.infer<typeof ColumnSchema>;
export type Block = z.infer<typeof BlockSchema>;
export type LeafBlock = z.infer<typeof LeafBlockSchema>;
export type Section = z.infer<typeof SectionSchema>;
export type PageModel = z.infer<typeof PageModelSchema>;

export type OutputFormat = 'kadence' | 'core';

export interface ConversionOutput {
  format: OutputFormat;
  blocks: string; // Gutenberg block markup for the post content
  css: string; // optional Additional CSS
  html: string; // standalone HTML document (page body + linked CSS) for download
  htmlCss: string; // stylesheet for the standalone HTML
  previewDoc: string; // self-contained HTML used for the live preview iframe
  warnings: string[];
  stats: { sections: number; blocks: number; images: number; kadenceBlocks: number; coreBlocks: number };
}
