export const SITE_NAME = 'AI Website to WordPress Converter';
export const SITE_URL = (process.env.SITE_URL || 'http://localhost:3000').replace(/\/+$/, '');

export const NAV = [
  { href: '/', label: 'Converter' },
  { href: '/dashboard', label: 'Dashboard' },
  { href: '/chrome-extension', label: 'Chrome Extension' },
  { href: '/kadence-converter', label: 'Kadence' },
  { href: '/wordpress-import-guide', label: 'Import guide' },
  { href: '/pricing', label: 'Pricing' },
];

export function pageMeta(path: string, title: string, description: string) {
  return {
    title,
    description,
    alternates: { canonical: path },
    openGraph: { title, description, url: path, siteName: SITE_NAME, type: 'website' as const },
    twitter: { card: 'summary_large_image' as const, title, description },
  };
}
