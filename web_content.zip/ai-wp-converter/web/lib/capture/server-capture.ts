import { parseHTML } from 'linkedom';
import './capture-core.js';

type CaptureFn = (doc: any, opts: Record<string, unknown>) => unknown;

function core(): { captureDocument: CaptureFn } {
  const api = (globalThis as any).WPCCapture;
  if (!api) throw new Error('capture core not loaded');
  return api;
}

/** Capture a page from raw HTML (URL mode). No layout engine, so styles come from inline CSS + class hints. */
export function captureHtml(html: string, baseUrl: string) {
  const { document } = parseHTML(html);
  return core().captureDocument(document, { baseUrl, mode: 'url' });
}
