// Copies the shared capture walker into the Chrome extension (single source of truth: web/lib/capture/capture-core.js).
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const here = path.dirname(fileURLToPath(import.meta.url));
const src = path.join(here, '../lib/capture/capture-core.js');
const dest = path.join(here, '../../extension/capture-core.js');
fs.copyFileSync(src, dest);
console.log(`Copied capture-core.js → ${path.relative(process.cwd(), dest)}`);
