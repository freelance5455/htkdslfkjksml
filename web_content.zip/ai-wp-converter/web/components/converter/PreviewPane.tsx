'use client';
import { useState } from 'react';

const DEVICES = [
  { key: 'desktop', label: 'Desktop', width: '100%' },
  { key: 'tablet', label: 'Tablet', width: '768px' },
  { key: 'mobile', label: 'Mobile', width: '390px' },
] as const;

export function PreviewPane({ doc, title }: { doc: string; title: string }) {
  const [device, setDevice] = useState<(typeof DEVICES)[number]['key']>('desktop');
  const d = DEVICES.find((x) => x.key === device)!;
  return (
    <div className="card overflow-hidden">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 bg-slate-50/70 px-4 py-3">
        <div className="flex items-center gap-2">
          <span className="flex gap-1.5" aria-hidden="true">
            <span className="h-2.5 w-2.5 rounded-full bg-rose-300" />
            <span className="h-2.5 w-2.5 rounded-full bg-amber-300" />
            <span className="h-2.5 w-2.5 rounded-full bg-emerald-300" />
          </span>
          <h2 className="ml-2 text-sm font-semibold">Live preview</h2>
        </div>
        <div className="flex rounded-lg border border-slate-200 bg-white p-0.5" role="group" aria-label="Preview device">
          {DEVICES.map((x) => (
            <button
              key={x.key}
              type="button"
              onClick={() => setDevice(x.key)}
              aria-pressed={device === x.key}
              className={`rounded-md px-3 py-1.5 text-xs font-medium transition ${device === x.key ? 'bg-brand-600 text-white shadow' : 'text-ink-700 hover:bg-slate-50'}`}
            >
              {x.label}
            </button>
          ))}
        </div>
      </div>
      <div className="overflow-x-auto bg-slate-100/80 p-3 sm:p-4">
        <iframe
          title={`Preview of ${title}`}
          srcDoc={doc}
          sandbox=""
          className="mx-auto block h-[640px] rounded-lg border border-slate-200 bg-white shadow-sm transition-[width] duration-300"
          style={{ width: d.width, maxWidth: d.key === 'desktop' ? '100%' : undefined }}
        />
      </div>
      <p className="border-t border-slate-200 px-4 py-2.5 text-xs text-ink-500">
        Preview of the clean recreation. In WordPress, your Kadence theme styles (fonts, buttons, container width) will apply.
      </p>
    </div>
  );
}
