'use client';
import { useState } from 'react';
import type { ClientRecord } from './types';

export function WordPressPanel({ record }: { record: ClientRecord }) {
  const [site, setSite] = useState('');
  const [user, setUser] = useState('');
  const [pass, setPass] = useState('');
  const [title, setTitle] = useState(record.title);
  const [importImages, setImportImages] = useState(false);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<{ ok: boolean; message: string; edit?: string; preview?: string } | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setResult(null);
    try {
      const res = await fetch('/api/wordpress/draft', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ conversionId: record.id, siteUrl: site, username: user, appPassword: pass, title, importImages }),
      });
      const data = await res.json();
      if (!data.ok) setResult({ ok: false, message: data.error || 'Could not create the draft.' });
      else
        setResult({
          ok: true,
          message: data.usedPlugin ? `Draft page #${data.id} created with the companion plugin${data.images_imported ? ` (${data.images_imported} images imported)` : ''}.` : data.note || `Draft page #${data.id} created.`,
          edit: data.edit_url,
          preview: data.preview_url,
        });
    } catch {
      setResult({ ok: false, message: 'Network error — the request did not complete.' });
    } finally {
      setBusy(false);
      setPass('');
    }
  }

  return (
    <form onSubmit={submit} className="card p-5">
      <h2 className="text-base font-semibold">Send to WordPress as a draft</h2>
      <p className="mt-1 text-sm text-ink-500">
        Creates an unpublished draft using an{' '}
        <a className="text-brand-600 underline" href="/wordpress-import-guide#application-password">
          Application Password
        </a>
        . Credentials are used for this request only and never stored. You publish it yourself from WordPress.
      </p>
      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        <label className="text-xs font-medium text-ink-700 sm:col-span-2">
          Site URL
          <input className="input mt-1" type="url" required placeholder="https://your-site.com" value={site} onChange={(e) => setSite(e.target.value)} />
        </label>
        <label className="text-xs font-medium text-ink-700">
          Username
          <input className="input mt-1" required autoComplete="username" value={user} onChange={(e) => setUser(e.target.value)} />
        </label>
        <label className="text-xs font-medium text-ink-700">
          Application Password
          <input className="input mt-1" type="password" required autoComplete="off" placeholder="xxxx xxxx xxxx xxxx" value={pass} onChange={(e) => setPass(e.target.value)} />
        </label>
        <label className="text-xs font-medium text-ink-700 sm:col-span-2">
          Page title
          <input className="input mt-1" value={title} onChange={(e) => setTitle(e.target.value)} />
        </label>
        <label className="flex items-start gap-2 text-xs text-ink-700 sm:col-span-2">
          <input type="checkbox" className="mt-0.5 accent-brand-600" checked={importImages} onChange={(e) => setImportImages(e.target.checked)} />
          <span>Import images into my Media Library (requires the companion plugin; only for images I have the right to use)</span>
        </label>
      </div>
      <button className="btn-primary mt-4 w-full" disabled={busy}>
        {busy ? 'Creating draft…' : 'Create draft page'}
      </button>
      {result && (
        <div className={`mt-3 rounded-xl px-4 py-3 text-sm ${result.ok ? 'bg-emerald-50 text-emerald-800' : 'bg-rose-50 text-rose-800'}`} role="status">
          {result.message}
          {result.edit && (
            <span className="mt-1 block">
              <a className="font-semibold underline" href={result.edit} target="_blank" rel="noreferrer">
                Open in editor →
              </a>
            </span>
          )}
        </div>
      )}
    </form>
  );
}
