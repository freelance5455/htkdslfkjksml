'use client';
import { useCallback, useRef, useState } from 'react';
import { ProgressSteps } from './ProgressSteps';
import { PreviewPane } from './PreviewPane';
import { CodePanel } from './CodePanel';
import { WordPressPanel } from './WordPressPanel';
import type { ClientRecord, StageState } from './types';

type Mode = 'url' | 'upload';
type Format = 'kadence' | 'core';

export function Workspace({ aiConfigured, initialRecord }: { aiConfigured: boolean; initialRecord?: ClientRecord }) {
  const [mode, setMode] = useState<Mode>('url');
  const [url, setUrl] = useState('');
  const [file, setFile] = useState<{ name: string; data: unknown } | null>(null);
  const [dragging, setDragging] = useState(false);
  const [permission, setPermission] = useState(false);
  const [format, setFormat] = useState<Format>(initialRecord?.format || 'kadence');
  const [useAi, setUseAi] = useState(aiConfigured);
  const [running, setRunning] = useState(false);
  const [stages, setStages] = useState<StageState>({});
  const [hasFetchStep, setHasFetchStep] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [record, setRecord] = useState<ClientRecord | null>(initialRecord || null);
  const [prompt, setPrompt] = useState('');
  const [refining, setRefining] = useState(false);
  const [refineMsg, setRefineMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const resultRef = useRef<HTMLDivElement>(null);

  const stream = useCallback(async (body: Record<string, unknown>) => {
    setRunning(true);
    setError(null);
    setStages({});
    setHasFetchStep(!!body.url);
    try {
      const res = await fetch('/api/convert', { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/x-ndjson' }, body: JSON.stringify(body) });
      if (!res.ok || !res.body) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || `Request failed (HTTP ${res.status}).`);
      }
      const reader = res.body.getReader();
      const dec = new TextDecoder();
      let buf = '';
      let got: ClientRecord | null = null;
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        let i: number;
        while ((i = buf.indexOf('\n')) >= 0) {
          const line = buf.slice(0, i).trim();
          buf = buf.slice(i + 1);
          if (!line) continue;
          const ev = JSON.parse(line);
          if (ev.type === 'stage') setStages((s) => ({ ...s, [ev.stage]: { status: ev.status, note: ev.note } }));
          else if (ev.type === 'error') throw new Error(ev.message);
          else if (ev.type === 'result') got = ev.record;
        }
      }
      if (!got) throw new Error('The conversion ended without a result.');
      setRecord(got);
      setFormat(got.format);
      if (!body.conversionId) window.history.replaceState(null, '', `/convert/${got.id}`);
      setTimeout(() => resultRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 80);
    } catch (e: any) {
      setError(e?.message || 'Conversion failed.');
    } finally {
      setRunning(false);
    }
  }, []);

  function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!permission) {
      setError('Please confirm you own this website or have permission to reproduce it.');
      return;
    }
    if (mode === 'url') {
      if (!url.trim()) return setError('Enter a website URL.');
      stream({ url, format, useAi, permission });
    } else {
      if (!file) return setError('Choose a capture file (.json) exported from the Chrome extension.');
      stream({ capture: file.data, format, useAi, permission });
    }
  }

  async function readFile(f: File | undefined) {
    if (!f) return;
    setError(null);
    if (f.size > 4 * 1024 * 1024) return setError('That file is larger than 4 MB.');
    try {
      const data = JSON.parse(await f.text());
      if (!data || data.version !== 1 || !Array.isArray(data.sections)) throw new Error();
      setFile({ name: f.name, data });
    } catch {
      setFile(null);
      setError('That file is not a capture exported by the extension (expected JSON with "version": 1 and "sections").');
    }
  }

  function switchFormat(f: Format) {
    setFormat(f);
    if (record && record.format !== f) stream({ conversionId: record.id, format: f });
  }

  async function refine(e: React.FormEvent) {
    e.preventDefault();
    if (!record || !prompt.trim()) return;
    setRefining(true);
    setRefineMsg(null);
    try {
      const res = await fetch('/api/refine', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ conversionId: record.id, prompt, format }) });
      const data = await res.json();
      if (!data.ok) throw new Error(data.error);
      setRecord(data.record);
      setPrompt('');
      setRefineMsg({ ok: true, text: data.record.ai.note });
    } catch (err: any) {
      setRefineMsg({ ok: false, text: err?.message || 'The change could not be applied.' });
    } finally {
      setRefining(false);
    }
  }

  return (
    <div id="converter" className="scroll-mt-24">
      <form onSubmit={onSubmit} className="card relative mx-auto max-w-3xl p-2 sm:p-3">
        <div className="flex gap-1 rounded-xl bg-slate-100/80 p-1" role="tablist" aria-label="Input type">
          {(['url', 'upload'] as Mode[]).map((m) => (
            <button
              key={m}
              type="button"
              role="tab"
              aria-selected={mode === m}
              onClick={() => setMode(m)}
              className={`flex-1 rounded-lg px-3 py-2 text-sm font-medium transition ${mode === m ? 'bg-white text-brand-700 shadow-sm' : 'text-ink-500 hover:text-ink-900'}`}
            >
              {m === 'url' ? 'Website URL' : 'Import extension capture'}
            </button>
          ))}
        </div>

        <div className="p-3 sm:p-4">
          {mode === 'url' ? (
            <div className="flex flex-col gap-3 sm:flex-row">
              <label htmlFor="site-url" className="sr-only">
                Website URL
              </label>
              <input id="site-url" className="input !py-3.5 text-base" type="text" inputMode="url" placeholder="https://your-website.com/landing-page" value={url} onChange={(e) => setUrl(e.target.value)} autoComplete="url" />
              <button className="btn-primary !py-3.5 sm:w-52" disabled={running}>
                {running ? (
                  <>
                    <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" aria-hidden="true" /> Converting…
                  </>
                ) : (
                  'Convert Website'
                )}
              </button>
            </div>
          ) : (
            <div>
              <label
                onDragOver={(e) => {
                  e.preventDefault();
                  setDragging(true);
                }}
                onDragLeave={() => setDragging(false)}
                onDrop={(e) => {
                  e.preventDefault();
                  setDragging(false);
                  readFile(e.dataTransfer.files[0]);
                }}
                className={`flex cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed px-6 py-8 text-center transition ${dragging ? 'border-brand-500 bg-brand-50' : 'border-slate-200 hover:border-brand-200 hover:bg-brand-50/40'}`}
              >
                <span className="text-sm font-semibold text-ink-900">{file ? file.name : 'Drop a capture file here, or click to choose'}</span>
                <span className="mt-1 text-xs text-ink-500">
                  {file ? `${(file.data as any).sections.length} sections ready to convert` : 'Use “Download capture” in the Chrome extension to create one (.json).'}
                </span>
                <input type="file" accept="application/json,.json" className="sr-only" onChange={(e) => readFile(e.target.files?.[0])} />
              </label>
              <button className="btn-primary mt-3 w-full !py-3.5" disabled={running || !file}>
                {running ? 'Converting…' : 'Convert capture'}
              </button>
            </div>
          )}

          <div className="mt-4 flex flex-col gap-3 text-sm sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xs font-medium text-ink-500">Output</span>
              <div className="flex rounded-lg border border-slate-200 p-0.5" role="group" aria-label="Output format">
                {(['kadence', 'core'] as Format[]).map((f) => (
                  <button
                    key={f}
                    type="button"
                    aria-pressed={format === f}
                    onClick={() => (record ? switchFormat(f) : setFormat(f))}
                    disabled={running}
                    className={`rounded-md px-3 py-1.5 text-xs font-medium transition ${format === f ? 'bg-ink-900 text-white' : 'text-ink-700 hover:bg-slate-50'}`}
                  >
                    {f === 'kadence' ? 'Kadence Blocks' : 'Core Gutenberg'}
                  </button>
                ))}
              </div>
            </div>
            <label className={`flex items-center gap-2 text-xs ${aiConfigured ? 'text-ink-700' : 'text-ink-500'}`} title={aiConfigured ? '' : 'Set ANTHROPIC_API_KEY on the server to enable AI'}>
              <input type="checkbox" className="accent-brand-600" checked={useAi && aiConfigured} disabled={!aiConfigured} onChange={(e) => setUseAi(e.target.checked)} />
              {aiConfigured ? 'Use AI to organize sections' : 'AI not configured — Basic mode'}
            </label>
          </div>
          <label className="mt-3 flex items-start gap-2 text-xs leading-5 text-ink-700">
            <input type="checkbox" className="mt-0.5 accent-brand-600" checked={permission} onChange={(e) => setPermission(e.target.checked)} />
            <span>I own this website or have permission to reproduce its design and content. (Pages behind logins, paywalls or bot protection are not supported.)</span>
          </label>
        </div>
      </form>

      {error && (
        <div className="mx-auto mt-4 max-w-3xl rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-800" role="alert">
          {error}
        </div>
      )}

      {(running || (error && Object.keys(stages).length > 0)) && (
        <div className="mx-auto mt-4 max-w-3xl">
          <ProgressSteps stages={stages} skipFetch={!hasFetchStep} failed={!!error} />
        </div>
      )}

      {record && (
        <div ref={resultRef} className="mx-auto mt-10 max-w-7xl scroll-mt-20 animate-fade-up px-0">
          <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-brand-600">Conversion result</p>
              <h2 className="mt-1 text-xl font-bold tracking-tight sm:text-2xl">{record.title}</h2>
              {record.sourceUrl && (
                <p className="mt-0.5 truncate text-sm text-ink-500">
                  from {record.sourceUrl} · {record.sourceMode === 'extension' ? 'Chrome extension capture' : record.sourceMode === 'url' ? 'URL (HTML only)' : 'uploaded capture'}
                </p>
              )}
            </div>
            <span className={`rounded-full px-3 py-1 text-xs font-semibold ${record.ai.used ? 'bg-brand-100 text-brand-700' : 'bg-slate-100 text-ink-700'}`}>{record.ai.used ? 'AI organized' : 'Basic mode'}</span>
          </div>

          <div className="grid gap-5 lg:grid-cols-12">
            <div className="space-y-5 lg:col-span-7">
              <PreviewPane doc={record.output.previewDoc} title={record.title} />
              <form onSubmit={refine} className="card p-5">
                <h2 className="text-base font-semibold">Request a change</h2>
                <p className="mt-1 text-sm text-ink-500">
                  {aiConfigured ? 'Describe a simple change — e.g. “make the hero background dark navy”, “turn the features into 2 columns”.' : 'Prompt edits need an AI key on the server. In Basic mode you can edit the blocks directly in WordPress.'}
                </p>
                <div className="mt-3 flex flex-col gap-2 sm:flex-row">
                  <input className="input" placeholder="Make the call-to-action buttons rounded and purple" value={prompt} onChange={(e) => setPrompt(e.target.value)} disabled={!aiConfigured || refining} maxLength={2000} aria-label="Change request" />
                  <button className="btn-primary sm:w-36" disabled={!aiConfigured || refining || !prompt.trim()}>
                    {refining ? 'Applying…' : 'Apply'}
                  </button>
                </div>
                {refineMsg && <p className={`mt-2 text-sm ${refineMsg.ok ? 'text-emerald-700' : 'text-rose-700'}`}>{refineMsg.text}</p>}
              </form>
              <div className="card p-5">
                <h2 className="text-base font-semibold">Sections</h2>
                <ol className="mt-3 grid gap-2 sm:grid-cols-2">
                  {record.model.sections.map((s, i) => (
                    <li key={s.id} className="flex items-center gap-3 rounded-xl border border-slate-100 bg-slate-50/60 px-3 py-2 text-sm">
                      <span className="grid h-6 w-6 shrink-0 place-items-center rounded-md bg-white text-xs font-semibold text-brand-700 shadow-sm">{i + 1}</span>
                      <span className="h-4 w-4 shrink-0 rounded border border-slate-200" style={{ background: s.background || record.model.theme.background }} aria-hidden="true" />
                      <span className="truncate">{s.label}</span>
                    </li>
                  ))}
                </ol>
              </div>
            </div>
            <div className="space-y-5 lg:col-span-5">
              <CodePanel record={record} />
              {record.output.warnings.length > 0 && (
                <div className="card p-5">
                  <h2 className="text-base font-semibold">Review before publishing</h2>
                  <ul className="mt-3 space-y-2 text-sm text-ink-700">
                    {record.output.warnings.map((w, i) => (
                      <li key={i} className="flex gap-2">
                        <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-amber-400" aria-hidden="true" />
                        {w}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              <WordPressPanel key={record.id} record={record} />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
