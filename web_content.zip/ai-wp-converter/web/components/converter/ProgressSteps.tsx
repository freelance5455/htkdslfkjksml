import type { StageKey, StageState } from './types';

const STEPS: { key: StageKey; label: string }[] = [
  { key: 'fetch', label: 'Fetch page' },
  { key: 'analyze', label: 'Analyze structure' },
  { key: 'organize', label: 'Organize sections' },
  { key: 'generate', label: 'Generate blocks' },
  { key: 'save', label: 'Save' },
];

export function ProgressSteps({ stages, skipFetch, failed }: { stages: StageState; skipFetch: boolean; failed: boolean }) {
  const steps = skipFetch ? STEPS.filter((s) => s.key !== 'fetch') : STEPS;
  const doneCount = steps.filter((s) => stages[s.key]?.status === 'done').length;
  const pct = Math.round((doneCount / steps.length) * 100);
  return (
    <div className="card p-5" role="status" aria-live="polite">
      <div className="flex items-center justify-between text-sm">
        <span className="font-semibold">{failed ? 'Conversion stopped' : pct === 100 ? 'Conversion complete' : 'Converting…'}</span>
        <span className="tabular-nums text-ink-500">{pct}%</span>
      </div>
      <div className="mt-3 h-2 overflow-hidden rounded-full bg-slate-100">
        <div className={`h-full rounded-full transition-all duration-500 ${failed ? 'bg-rose-400' : 'bg-gradient-to-r from-brand-500 to-blue-500'}`} style={{ width: `${Math.max(pct, 4)}%` }} />
      </div>
      <ol className="mt-4 grid gap-2 sm:grid-cols-5">
        {steps.map((s) => {
          const st = stages[s.key]?.status;
          return (
            <li key={s.key} className="flex items-start gap-2 text-xs">
              <span
                className={`mt-0.5 grid h-4 w-4 shrink-0 place-items-center rounded-full text-[10px] font-bold ${
                  st === 'done' ? 'bg-emerald-500 text-white' : st === 'start' ? (failed ? 'bg-rose-400 text-white' : 'animate-pulse bg-brand-500 text-white') : 'bg-slate-200 text-slate-500'
                }`}
                aria-hidden="true"
              >
                {st === 'done' ? '✓' : st === 'start' && failed ? '!' : ''}
              </span>
              <span>
                <span className={st ? 'font-medium text-ink-900' : 'text-ink-500'}>{s.label}</span>
                {stages[s.key]?.note && <span className="block text-ink-500">{stages[s.key]!.note}</span>}
              </span>
            </li>
          );
        })}
      </ol>
    </div>
  );
}
