'use client';
import { useState } from 'react';
import { copyText, download, slug, type ClientRecord } from './types';

type Tab = 'blocks' | 'css' | 'html' | 'htmlcss';

export function CodePanel({ record }: { record: ClientRecord }) {
  const [tab, setTab] = useState<Tab>('blocks');
  const [copied, setCopied] = useState<string | null>(null);
  const o = record.output;
  const name = slug(record.title);
  const tabs: { key: Tab; label: string; content: string; file: string; type: string; hint: string }[] = [
    {
      key: 'blocks',
      label: o.format === 'kadence' ? 'Kadence blocks' : 'Gutenberg blocks',
      content: o.blocks,
      file: `${name}-${o.format}-blocks.html`,
      type: 'text/html',
      hint: 'Paste into the WordPress block editor (Options ⋮ → Code editor), then switch back to the visual editor.',
    },
    { key: 'css', label: 'Additional CSS', content: o.css, file: `${name}-additional.css`, type: 'text/css', hint: 'Optional. Appearance → Customize → Additional CSS (the companion plugin can attach it to the page for you).' },
    { key: 'html', label: 'HTML', content: o.html, file: `${name}.html`, type: 'text/html', hint: 'Standalone HTML export (links to styles.css). Not for pasting into WordPress.' },
    { key: 'htmlcss', label: 'styles.css', content: o.htmlCss, file: 'styles.css', type: 'text/css', hint: 'Stylesheet for the standalone HTML export.' },
  ];
  const t = tabs.find((x) => x.key === tab)!;
  const lines = t.content.split('\n').length;

  async function onCopy() {
    const ok = await copyText(t.content);
    setCopied(ok ? t.key : 'fail');
    setTimeout(() => setCopied(null), 1800);
  }

  return (
    <div className="card flex h-full flex-col overflow-hidden">
      <div className="flex items-center justify-between gap-2 border-b border-slate-200 bg-slate-50/70 px-4 py-3">
        <h2 className="text-sm font-semibold">Generated WordPress code</h2>
        <div className="flex gap-2">
          <button type="button" className="btn-secondary !px-3 !py-1.5 !text-xs" onClick={onCopy}>
            {copied === t.key ? 'Copied ✓' : copied === 'fail' ? 'Copy failed' : 'Copy'}
          </button>
          <button type="button" className="btn-secondary !px-3 !py-1.5 !text-xs" onClick={() => download(t.file, t.content, t.type)}>
            Download
          </button>
        </div>
      </div>
      <div className="flex gap-1 overflow-x-auto border-b border-slate-200 px-2 pt-2" role="tablist" aria-label="Output files">
        {tabs.map((x) => (
          <button
            key={x.key}
            role="tab"
            aria-selected={tab === x.key}
            type="button"
            onClick={() => setTab(x.key)}
            className={`whitespace-nowrap rounded-t-lg px-3 py-2 text-xs font-medium transition ${tab === x.key ? 'border-b-2 border-brand-600 text-brand-700' : 'text-ink-500 hover:text-ink-900'}`}
          >
            {x.label}
          </button>
        ))}
      </div>
      <p className="px-4 pt-3 text-xs text-ink-500">{t.hint}</p>
      <pre className="m-3 max-h-[520px] min-h-[300px] flex-1 overflow-auto rounded-xl bg-[#0f1020] p-4 font-mono text-[11.5px] leading-5 text-violet-100" tabIndex={0} aria-label={`${t.label} code, ${lines} lines`}>
        <code>{t.content}</code>
      </pre>
      <div className="flex flex-wrap items-center justify-between gap-2 border-t border-slate-200 px-4 py-3 text-xs text-ink-500">
        <span>
          {lines} lines · {o.stats.sections} sections · {o.format === 'kadence' ? `${o.stats.kadenceBlocks} Kadence + ${o.stats.coreBlocks} core blocks` : `${o.stats.coreBlocks} core blocks`}
        </span>
        <button
          type="button"
          className="font-medium text-brand-600 hover:underline"
          onClick={() => download(`${slug(record.title)}-capture.json`, JSON.stringify(record.model, null, 2), 'application/json')}
        >
          Download page model (.json)
        </button>
      </div>
    </div>
  );
}
