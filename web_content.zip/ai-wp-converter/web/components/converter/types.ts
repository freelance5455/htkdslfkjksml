import type { ConversionOutput, PageModel } from '@/lib/converter/types';

export interface ClientRecord {
  id: string;
  createdAt: string;
  updatedAt: string;
  title: string;
  sourceUrl: string;
  sourceMode: string;
  format: 'kadence' | 'core';
  model: PageModel;
  output: ConversionOutput;
  ai: { used: boolean; note: string };
}

export type StageKey = 'fetch' | 'analyze' | 'organize' | 'generate' | 'save';
export type StageState = Partial<Record<StageKey, { status: 'start' | 'done'; note?: string }>>;

export function download(filename: string, content: string, type = 'text/plain') {
  const blob = new Blob([content], { type: `${type};charset=utf-8` });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    URL.revokeObjectURL(a.href);
    a.remove();
  }, 500);
}

export async function copyText(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand('copy');
    ta.remove();
    return ok;
  }
}

export function slug(s: string) {
  return (s || 'page').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 50) || 'page';
}
