export interface FaqItem {
  q: string;
  a: React.ReactNode;
}

export function Faq({ items, id = 'faq', title = 'Frequently asked questions' }: { items: FaqItem[]; id?: string; title?: string }) {
  return (
    <section id={id} className="mx-auto max-w-3xl scroll-mt-24 px-4 sm:px-6" aria-labelledby={`${id}-title`}>
      <h2 id={`${id}-title`} className="text-center text-3xl font-bold tracking-tight">
        {title}
      </h2>
      <div className="mt-8 divide-y divide-slate-200 rounded-2xl border border-slate-200 bg-white">
        {items.map((it) => (
          <details key={it.q} className="group px-5 py-4 [&_summary::-webkit-details-marker]:hidden">
            <summary className="flex cursor-pointer list-none items-center justify-between gap-4 text-left font-medium">
              <h3 className="text-base">{it.q}</h3>
              <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-brand-50 text-brand-700 transition group-open:rotate-45" aria-hidden="true">
                +
              </span>
            </summary>
            <div className="mt-3 text-sm leading-6 text-ink-700">{it.a}</div>
          </details>
        ))}
      </div>
    </section>
  );
}
