export function Logo({ className = 'h-8 w-8' }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={className} aria-hidden="true">
      <defs>
        <linearGradient id="lg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#7c3aed" />
          <stop offset="1" stopColor="#2563eb" />
        </linearGradient>
      </defs>
      <rect width="32" height="32" rx="9" fill="url(#lg)" />
      <path d="M8 11h7v4H8zM8 17h7v4H8zM17 11h7v10h-7z" fill="#fff" opacity=".95" />
      <circle cx="24.5" cy="8" r="2.2" fill="#fde68a" />
    </svg>
  );
}
