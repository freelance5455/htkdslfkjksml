'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useState } from 'react';
import { Logo } from './Logo';
import { NAV, SITE_NAME } from '@/lib/site';

export function SiteHeader() {
  const path = usePathname();
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-40 border-b border-slate-200/70 bg-white/80 backdrop-blur-lg">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6">
        <Link href="/" className="flex items-center gap-2.5 font-semibold tracking-tight" aria-label={`${SITE_NAME} home`}>
          <Logo />
          <span className="hidden sm:inline">
            WP<span className="text-gradient">Convert</span> AI
          </span>
        </Link>
        <nav className="hidden items-center gap-1 lg:flex" aria-label="Main">
          {NAV.map((n) => (
            <Link
              key={n.href}
              href={n.href}
              className={`rounded-lg px-3 py-2 text-sm font-medium transition ${path === n.href ? 'bg-brand-50 text-brand-700' : 'text-ink-700 hover:bg-slate-50 hover:text-ink-900'}`}
            >
              {n.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <Link href="/#converter" className="btn-primary hidden !px-4 !py-2 sm:inline-flex">
            Convert a website
          </Link>
          <button className="btn-secondary lg:hidden" onClick={() => setOpen(!open)} aria-expanded={open} aria-controls="mobile-nav">
            Menu
          </button>
        </div>
      </div>
      {open && (
        <nav id="mobile-nav" className="border-t border-slate-200 bg-white px-4 py-3 lg:hidden" aria-label="Mobile">
          {NAV.map((n) => (
            <Link key={n.href} href={n.href} onClick={() => setOpen(false)} className="block rounded-lg px-3 py-2.5 text-sm font-medium text-ink-700 hover:bg-brand-50">
              {n.label}
            </Link>
          ))}
        </nav>
      )}
    </header>
  );
}
