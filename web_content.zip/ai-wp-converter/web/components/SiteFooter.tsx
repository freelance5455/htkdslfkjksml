import Link from 'next/link';
import { Logo } from './Logo';

export function SiteFooter() {
  return (
    <footer className="mt-24 border-t border-slate-200 bg-slate-50/60">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-12 sm:px-6 md:grid-cols-4">
        <div className="md:col-span-2">
          <div className="flex items-center gap-2 font-semibold">
            <Logo className="h-7 w-7" /> WPConvert AI
          </div>
          <p className="mt-3 max-w-md text-sm leading-6 text-ink-500">
            Turn a website design you own into editable WordPress blocks — Kadence Row Layouts, Advanced Text, buttons and images, or standard Gutenberg blocks.
          </p>
          <p className="mt-3 max-w-md text-xs leading-5 text-ink-500">
            Only convert pages you own or have permission to reproduce. The converter does not bypass logins, paywalls or bot protection.
          </p>
        </div>
        <div>
          <h2 className="text-sm font-semibold">Product</h2>
          <ul className="mt-3 space-y-2 text-sm text-ink-500">
            <li><Link className="hover:text-brand-600" href="/">Website to WordPress converter</Link></li>
            <li><Link className="hover:text-brand-600" href="/chrome-extension">Chrome extension for WordPress</Link></li>
            <li><Link className="hover:text-brand-600" href="/kadence-converter">Kadence WordPress converter</Link></li>
            <li><Link className="hover:text-brand-600" href="/pricing">Pricing</Link></li>
          </ul>
        </div>
        <div>
          <h2 className="text-sm font-semibold">Resources</h2>
          <ul className="mt-3 space-y-2 text-sm text-ink-500">
            <li><Link className="hover:text-brand-600" href="/wordpress-import-guide">WordPress import guide</Link></li>
            <li><Link className="hover:text-brand-600" href="/dashboard">Recent conversions</Link></li>
            <li><Link className="hover:text-brand-600" href="/#faq">FAQ</Link></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-slate-200 py-5 text-center text-xs text-ink-500">© {new Date().getFullYear()} WPConvert AI · Not affiliated with WordPress or Kadence.</div>
    </footer>
  );
}
