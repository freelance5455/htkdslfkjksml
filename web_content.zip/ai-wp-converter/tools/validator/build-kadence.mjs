// Compiles the real save() functions + block.json of the Kadence blocks we generate
// from a checkout of github.com/stellarwp/kadence-blocks, so the validator can check
// our markup against Kadence's own code instead of guessed attributes.
//
// Usage: node build-kadence.mjs /path/to/kadence-blocks
import { build } from 'esbuild';
import fs from 'node:fs';
import path from 'node:path';

const repo = process.argv[2] || process.env.KADENCE_BLOCKS_DIR;
if (!repo || !fs.existsSync(path.join(repo, 'src/blocks'))) {
  console.error('Pass the path to a kadence-blocks checkout: node build-kadence.mjs ../kadence-blocks');
  process.exit(1);
}
const blocks = ['rowlayout', 'column', 'advancedheading', 'advancedbtn', 'singlebtn', 'image'];
const version = (fs.readFileSync(path.join(repo, 'kadence-blocks.php'), 'utf8').match(/Version:\s*([\d.]+)/) || [])[1];

let entry = `export const KADENCE_VERSION = ${JSON.stringify(version)};\nexport const defs = {};\n`;
for (const b of blocks) {
  const dir = path.join(repo, 'src/blocks', b);
  const hasSave = fs.existsSync(path.join(dir, 'save.js'));
  entry += `import meta_${b} from ${JSON.stringify(path.join(dir, 'block.json'))};\n`;
  entry += hasSave ? `import save_${b} from ${JSON.stringify(path.join(dir, 'save.js'))};\n` : `const save_${b} = () => null;\n`;
  entry += `defs[${JSON.stringify(b)}] = { metadata: meta_${b}, save: save_${b} };\n`;
}
const nm = path.resolve('node_modules');
await build({
  stdin: { contents: entry, resolveDir: process.cwd(), loader: 'js' },
  bundle: true,
  platform: 'node',
  format: 'cjs',
  outfile: 'dist/kadence-saves.cjs',
  loader: { '.js': 'jsx' },
  jsx: 'transform',
  jsxFactory: '__wpEl.createElement',
  jsxFragment: '__wpEl.Fragment',
  banner: { js: 'const __wpEl = require("@wordpress/element");' },
  external: ['@wordpress/*', 'react', 'react-dom'],
  nodePaths: [nm],
  logLevel: 'warning',
});
console.log(`Built dist/kadence-saves.cjs from Kadence Blocks ${version}`);
