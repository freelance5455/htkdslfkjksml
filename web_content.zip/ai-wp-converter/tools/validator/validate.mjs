// Validates Gutenberg block markup with the real WordPress block parser + validator.
//
//   node validate.mjs <file.html> [more files]           current Gutenberg + Kadence save() functions
//   node validate.mjs --legacy <file.html>               Gutenberg 9.22 (WordPress 6.8 era), core blocks only
//
// Exit code 1 if any block is invalid (i.e. the editor would show "This block contains unexpected content").
import './env.mjs';
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';

const args = process.argv.slice(2);
const legacy = args.includes('--legacy');
const files = args.filter((a) => !a.startsWith('--'));
if (!files.length) {
  console.error('usage: node validate.mjs [--legacy] <file.html>...');
  process.exit(2);
}
const base = legacy ? path.resolve('legacy/package.json') : import.meta.url;
const require = createRequire(base);
const blocksApi = require('@wordpress/blocks');
const library = require('@wordpress/block-library');
const realWarn = console.warn, realError = console.error, realInfo = console.info;
const quiet = () => { console.warn = console.error = console.info = () => {}; };
const loud = () => { console.warn = realWarn; console.error = realError; console.info = realInfo; };

quiet();
library.registerCoreBlocks();
loud();

let kadenceVersion = null;
if (!legacy) {
  const kadencePath = path.resolve('dist/kadence-saves.cjs');
  if (fs.existsSync(kadencePath)) {
    const K = createRequire(import.meta.url)(kadencePath);
    kadenceVersion = K.KADENCE_VERSION;
    for (const d of Object.values(K.defs)) {
      const { name, ...rest } = d.metadata;
      if (!blocksApi.getBlockType(name)) blocksApi.registerBlockType(name, { ...rest, title: rest.title || name, save: d.save, edit: () => null });
    }
  } else {
    console.warn('! dist/kadence-saves.cjs not found — Kadence blocks will not be validated (run build-kadence.mjs).');
  }
}

let failed = 0;
for (const file of files) {
  const content = fs.readFileSync(file, 'utf8');
  quiet();
  const parsed = blocksApi.parse(content);
  loud();
  const stats = { total: 0, strict: 0, migrated: 0, invalid: 0, unchecked: 0, byName: {} };
  const problems = [];
  const visit = (b, trail) => {
    if (!b.name) return;
    stats.total++;
    stats.byName[b.name] = (stats.byName[b.name] || 0) + 1;
    const type = blocksApi.getBlockType(b.name);
    if (!type || b.name === 'core/missing' || b.name === 'core/freeform') {
      stats.unchecked++;
    } else if (!b.isValid) {
      stats.invalid++;
      problems.push({ where: trail + ' > ' + b.name, issues: (b.validationIssues || []).map((i) => i.args?.slice(0, 3).join(' | ')).slice(0, 3), html: b.originalContent?.slice(0, 300) });
    } else {
      quiet();
      const [strict] = blocksApi.validateBlock(b, type);
      loud();
      if (strict) stats.strict++;
      else stats.migrated++;
    }
    (b.innerBlocks || []).forEach((ib, i) => visit(ib, trail + ' > ' + b.name + `[${i}]`));
  };
  parsed.forEach((b, i) => visit(b, `#${i}`));
  const label = legacy ? 'Gutenberg 9.22 (WP 6.8 era)' : `Gutenberg ${require('@wordpress/block-library/package.json').version}${kadenceVersion ? ` + Kadence Blocks ${kadenceVersion}` : ''}`;
  console.log(`\n${path.basename(file)} — ${label}`);
  console.log(`  blocks: ${stats.total}  valid: ${stats.strict}  valid-via-deprecation: ${stats.migrated}  invalid: ${stats.invalid}  not-checked: ${stats.unchecked}`);
  console.log('  ' + Object.entries(stats.byName).map(([k, v]) => `${k}×${v}`).join('  '));
  for (const p of problems.slice(0, 10)) {
    console.log(`  ✗ ${p.where}`);
    p.issues.forEach((i) => console.log(`      ${String(i).slice(0, 400)}`));
  }
  if (stats.invalid) failed++;
}
process.exit(failed ? 1 : 0);
