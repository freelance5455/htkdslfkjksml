// Sets up a browser-like global environment so the real Gutenberg packages
// (and Kadence's own save() functions) can run in Node.
import { JSDOM, VirtualConsole } from 'jsdom';

const virtualConsole = new VirtualConsole();
virtualConsole.on('jsdomError', (e) => { if (!/Could not parse CSS/.test(e.message)) console.error(e); });

const dom = new JSDOM('<!doctype html><html><body></body></html>', { url: 'http://localhost/', pretendToBeVisual: true, virtualConsole });
const g = globalThis;
const w = dom.window;
for (const key of ['window', 'document', 'navigator', 'Node', 'Element', 'HTMLElement', 'DOMParser', 'MutationObserver', 'getComputedStyle', 'requestAnimationFrame', 'cancelAnimationFrame', 'CustomEvent', 'Event', 'KeyboardEvent', 'HTMLIFrameElement', 'Range', 'Selection', 'DocumentFragment', 'localStorage', 'sessionStorage', 'CSS', 'HTMLDocument', 'Text', 'HTMLAnchorElement', 'HTMLTemplateElement']) {
  if (w[key] !== undefined) {
    try { g[key] = w[key]; } catch { Object.defineProperty(g, key, { value: w[key], configurable: true, writable: true }); }
  }
}
g.matchMedia = w.matchMedia = () => ({ matches: false, addListener() {}, removeListener() {}, addEventListener() {}, removeEventListener() {} });
g.ResizeObserver = w.ResizeObserver = class { observe() {} unobserve() {} disconnect() {} };
g.IntersectionObserver = w.IntersectionObserver = class { observe() {} unobserve() {} disconnect() {} };
g.wp = w.wp = {};
w.kadence_blocks_params = g.kadence_blocks_params = { globalSettings: '{}' };
