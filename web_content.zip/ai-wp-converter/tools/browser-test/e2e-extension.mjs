// Integration test for the Chrome extension in a headless Chromium that cannot load extensions.
// It runs the real popup.html / popup.js / picker.js / capture-core.js with a small shim for the
// chrome.* APIs, capturing a real rendered page and converting it with the real web app API.
//
//   1. serve ../../extension at EXT_ORIGIN (e.g. python3 -m http.server 8091)
//   2. start the app with EXTENSION_ORIGINS=<EXT_ORIGIN> ALLOW_PRIVATE_URLS=true
//   3. node e2e-extension.mjs
import path from 'node:path';
import fs from 'node:fs';
import { launch, wait } from './browser.mjs';

const APP = process.env.APP_URL || 'http://127.0.0.1:3000';
const SITE = process.env.TEST_SITE || 'http://127.0.0.1:8090/';
const EXT_ORIGIN = process.env.EXT_ORIGIN || 'http://127.0.0.1:8091';
const EXT_DIR = path.resolve('../../extension');
const OUT = process.env.OUT_DIR || '.';

const browser = await launch();
const site = await browser.newPage();
await site.setViewport({ width: 1280, height: 900 });
await site.goto(SITE, { waitUntil: 'load' });

// ---- 1. popup flow: capture full page → convert ----
const popup = await browser.newPage();
await popup.setViewport({ width: 380, height: 640 });
const errors = [];
popup.on('pageerror', (e) => errors.push(e.message));

await popup.exposeFunction('__execInTab', async (files, funcSrc) => {
  for (const f of files || []) await site.addScriptTag({ content: fs.readFileSync(path.join(EXT_DIR, f), 'utf8') });
  if (funcSrc) return site.evaluate(`(${funcSrc})()`);
  return null;
});
await popup.evaluateOnNewDocument(
  (siteUrl, appUrl) => {
    const store = { appUrl };
    const tab = { id: 7, url: siteUrl, title: 'Brightleaf Bakery — Fresh bread delivered' };
    window.__opened = [];
    window.chrome = {
      tabs: { query: async () => [tab], create: async (o) => window.__opened.push(o.url) },
      scripting: {
        executeScript: async ({ files, func }) => [{ result: await window.__execInTab(files || [], func ? func.toString() : null) }],
      },
      storage: {
        local: {
          get: async (keys) => Object.fromEntries((Array.isArray(keys) ? keys : [keys]).map((k) => [k, store[k]])),
          set: async (o) => Object.assign(store, o),
        },
      },
      action: { setBadgeText() {}, setBadgeBackgroundColor() {} },
      runtime: { sendMessage() {}, lastError: null },
    };
    window.__store = store;
  },
  SITE,
  APP,
);
await popup.goto(`${EXT_ORIGIN}/popup.html`, { waitUntil: 'load' });
await popup.waitForFunction(() => /App connected|App offline/.test(document.getElementById('app-status').textContent), { timeout: 8000 });
console.log('app status pill:', await popup.$eval('#app-status', (e) => e.textContent));

await popup.click('#btn-page');
await popup.waitForFunction(() => !document.getElementById('capture-card').hidden, { timeout: 15000 });
const cap = await popup.evaluate(() => window.__store.lastCapture);
console.log('captured:', cap.source.mode, cap.source.scope, `${cap.sections.length} sections`, '|', cap.sections.map((s) => `${s.kind}${s.background ? '(' + s.background + ')' : ''}`).join(', '));
const features = cap.sections.find((s) => s.blocks.some((b) => b.type === 'columns' && b.columns.length === 3));
console.log('3-column cards detected from rendered CSS:', !!features, features ? JSON.stringify(features.blocks.find((b) => b.type === 'columns').columns[0]).slice(0, 160) : '');
const heroBtn = cap.sections.flatMap((s) => s.blocks).find((b) => b.type === 'buttons');
console.log('hero buttons (computed styles):', JSON.stringify(heroBtn.items));
fs.writeFileSync(path.join(OUT, 'extension-capture.json'), JSON.stringify(cap, null, 2));

// conversion requires the permission checkbox
await popup.click('#btn-convert');
console.log('without permission:', await popup.$eval('#status', (e) => e.textContent));
await popup.click('#permission');
await popup.click('#btn-convert');
await popup.waitForFunction(() => !document.getElementById('result').hidden || document.querySelector('#status.error'), { timeout: 60000 });
console.log('convert status:', await popup.$eval('#status', (e) => e.textContent));
console.log('result stats:', await popup.$eval('#res-stats', (e) => e.textContent));
await popup.screenshot({ path: path.join(OUT, 'extension-popup.png'), fullPage: true });
const lastResult = await popup.evaluate(() => window.__store.lastResult);
fs.writeFileSync(path.join(OUT, 'extension.kadence.html'), lastResult.output.blocks);
await popup.click('#btn-open');
console.log('open in web app →', await popup.evaluate(() => window.__opened[0]));

// ---- 2. unsupported page message ----
const p2 = await browser.newPage();
await p2.evaluateOnNewDocument(() => {
  window.chrome = { tabs: { query: async () => [{ id: 1, url: 'chrome://settings', title: 'Settings' }] }, storage: { local: { get: async () => ({}), set: async () => {} } }, action: {}, runtime: {} };
});
await p2.goto(`${EXT_ORIGIN}/popup.html`, { waitUntil: 'load' });
await wait(300);
console.log('chrome:// page:', await p2.$eval('#page-info', (e) => e.textContent), '| buttons disabled:', await p2.$eval('#btn-page', (e) => e.disabled));

// ---- 3. section picker on the real page ----
const messages = [];
await site.exposeFunction('__wpcMsg', (m) => messages.push(m));
await site.evaluate(() => {
  window.chrome = { runtime: { sendMessage: (m, cb) => { window.__wpcMsg(m); cb && cb({ ok: true }); }, lastError: null } };
});
for (const f of ['capture-core.js', 'picker.js']) await site.addScriptTag({ content: fs.readFileSync(path.join(EXT_DIR, f), 'utf8') });
const card = await site.$('.features .card');
const box = await card.boundingBox();
await site.mouse.move(box.x + 20, box.y + 20);
await wait(100);
console.log('picker label:', await site.$eval('[data-wpc-ui]:nth-of-type(2)', (e) => e.textContent).catch(() => '?'));
await site.keyboard.press('ArrowUp'); // widen from the card to the grid
await site.keyboard.press('ArrowUp'); // … to the container with the heading
await site.keyboard.press('Enter');
await wait(300);
const msg = messages.find((m) => m.type === 'wpc-capture');
if (!msg) {
  console.log('picker: no capture message', messages);
} else {
  console.log('picker capture:', msg.capture.source.scope, `${msg.capture.sections.length} section(s)`, JSON.stringify(msg.capture.sections[0].blocks.map((b) => (b.type === 'columns' ? `columns${b.columns.length}` : b.type))));
}
console.log('page errors:', errors.length ? errors : 'none');
await browser.close();
