// Launches Chromium for tests: uses CHROME_PATH (a local Chrome) if set, otherwise the bundled @sparticuz/chromium build.
import puppeteer from 'puppeteer-core';

export async function launch(extraArgs = []) {
  if (process.env.CHROME_PATH) {
    return puppeteer.launch({ executablePath: process.env.CHROME_PATH, headless: true, args: extraArgs });
  }
  const chromium = (await import('@sparticuz/chromium')).default;
  return puppeteer.launch({ args: [...chromium.args, ...extraArgs], executablePath: await chromium.executablePath(), headless: true });
}

export const wait = (ms) => new Promise((r) => setTimeout(r, ms));
