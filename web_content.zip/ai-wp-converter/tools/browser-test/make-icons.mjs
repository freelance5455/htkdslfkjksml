// Renders the extension icons (PNG) from the logo SVG.
import { launch } from './browser.mjs';
import path from 'node:path';
const out = path.resolve(process.argv[2] || '../../extension/icons');
const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#7c3aed"/><stop offset="1" stop-color="#2563eb"/></linearGradient></defs><rect width="32" height="32" rx="9" fill="url(#g)"/><path d="M8 11h7v4H8zM8 17h7v4H8zM17 11h7v10h-7z" fill="#fff" opacity=".95"/><circle cx="24.5" cy="8" r="2.2" fill="#fde68a"/></svg>`;
const browser = await launch();
const page = await browser.newPage();
for (const size of [16, 32, 48, 128]) {
  await page.setViewport({ width: size, height: size, deviceScaleFactor: 1 });
  await page.setContent(`<html><body style="margin:0;background:transparent">${svg.replace('<svg ', `<svg width="${size}" height="${size}" `)}</body></html>`);
  await page.screenshot({ path: `${out}/icon${size}.png`, omitBackground: true, clip: { x: 0, y: 0, width: size, height: size } });
}
await browser.close();
console.log('icons written to', out);
