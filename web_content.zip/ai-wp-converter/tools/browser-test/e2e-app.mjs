// End-to-end check of the web app UI in a real (headless) Chromium.
//   APP_URL=http://127.0.0.1:3000 TEST_SITE=http://127.0.0.1:8090/ node e2e-app.mjs
import { launch, wait } from './browser.mjs';

const APP = process.env.APP_URL || 'http://127.0.0.1:3000';
const SITE = process.env.TEST_SITE || 'http://127.0.0.1:8090/';
const OUT = process.env.OUT_DIR || '.';
const browser = await launch();
const page = await browser.newPage();
const errors = [];
page.on('pageerror', (e) => errors.push(e.message));
page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
await page.setViewport({ width: 1366, height: 900 });
await page.goto(APP + '/', { waitUntil: 'networkidle0' });

// 1. permission is required
await page.type('#site-url', SITE);
await page.click('form button.btn-primary');
await page.waitForSelector('[role=alert]');
console.log('permission check:', await page.$eval('[role=alert]', (e) => e.textContent));

// 2. real conversion
await page.evaluate(() => {
  const perm = [...document.querySelectorAll('label')].find((l) => l.textContent.includes('permission'));
  perm.querySelector('input').click();
});
await page.click('form button.btn-primary');
await page.waitForFunction(() => /conversion result/i.test(document.body.innerText), { timeout: 30000 });
const info = await page.evaluate(() => ({
  path: location.pathname,
  code: document.querySelector('pre code')?.textContent?.slice(0, 60),
  sections: document.querySelectorAll('ol li').length,
  warnings: [...document.querySelectorAll('h2')].some((h) => h.textContent.includes('Review before publishing')),
  sandboxedIframe: document.querySelector('iframe')?.getAttribute('sandbox') === '',
}));
console.log('result:', JSON.stringify(info));
await page.screenshot({ path: `${OUT}/app-result.png`, fullPage: true });

// 3. preview content renders inside the sandboxed iframe
const frame = page.frames().find((f) => f !== page.mainFrame());
console.log('preview h1:', await frame.$eval('h1', (e) => e.textContent));

// 4. switch to core Gutenberg output
await page.evaluate(() => [...document.querySelectorAll('button')].find((b) => b.textContent === 'Core Gutenberg').click());
await page.waitForFunction(() => document.querySelector('pre code')?.textContent.includes('<!-- wp:group'), { timeout: 20000 });
console.log('core switch: ok');

// 5. mobile preview toggle
await page.evaluate(() => [...document.querySelectorAll('button')].find((b) => b.textContent === 'Mobile').click());
await wait(500);
console.log('mobile iframe width:', await page.$eval('iframe', (e) => Math.round(e.getBoundingClientRect().width)));

// 6. dashboard lists it
await page.goto(APP + '/dashboard', { waitUntil: 'networkidle0' });
console.log('dashboard cards:', await page.$$eval('main ul li a', (a) => a.length));

// 7. mobile layout of the homepage
await page.setViewport({ width: 390, height: 844, isMobile: true });
await page.goto(APP + '/', { waitUntil: 'networkidle0' });
await page.screenshot({ path: `${OUT}/app-mobile.png` });
console.log('mobile horizontal overflow:', await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth));
console.log('console errors:', errors.length ? errors : 'none');
await browser.close();
