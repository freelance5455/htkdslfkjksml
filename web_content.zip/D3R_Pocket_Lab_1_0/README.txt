D3R Pocket Lab 1.0
Free Software by D3R CyberTech

CONTENUTO
- index.html: applicazione web mobile in italiano.
- README.txt: istruzioni.

COME PROVARLA
1. Estrai lo ZIP sul PC.
2. Apri index.html con Chrome, Edge o Firefox.
3. Per provarla su Android, trasferisci index.html sul telefono e aprilo con un browser compatibile.

LIMITI IMPORTANTI
- Questa è una prima versione HTML: non è un APK Android.
- Il test display mostra campiture di colore; i pixel difettosi devono essere individuati visivamente.
- Il test touch evidenzia le caselle attraversate dal dito; il multitouch può variare in base al browser.
- I sensori sono accessibili solo se browser e dispositivo li espongono e i permessi sono concessi.
- Le informazioni di rete sono limitate da ciò che il browser rende disponibile.
- La sezione QR verifica il supporto del browser; la scansione QR completa non è implementata in questa versione.
- Non vengono raccolti né inviati dati a server.
- Per un APK con test hardware più completi serve un progetto Android nativo, ad esempio con Android Studio e Kotlin.
