ANKITA SORRY ❤️ — Android Studio प्रोजेक्ट

या प्रोजेक्टमध्ये:
- अंकितासाठी English apology message
- Android Text-to-Speech वापरून voice
- floating heart animation
- Play Voice, Stop Voice आणि More Hearts buttons

APK कसा बनवायचा:
1. संगणकावर Android Studio स्थापित करा.
2. ZIP extract करा.
3. Android Studio मध्ये File > Open निवडा आणि AnkitaSorryAndroid फोल्डर उघडा.
4. Gradle sync पूर्ण होऊ द्या.
5. Build > Build Bundle(s) / APK(s) > Build APK(s) निवडा.
6. APK साधारणपणे app/build/outputs/apk/debug/app-debug.apk येथे तयार होईल.
7. फोनवर पाठवून install करा. Debug APK फक्त स्वतःच्या चाचणीसाठी योग्य आहे; इतरांना शेअर करण्यासाठी signed release APK तयार करा.

टीप: या ZIP मध्ये Android Studio source project आहे, compiled APK नाही. APK तयार करण्यासाठी Android Studio/Gradle build आवश्यक आहे.
