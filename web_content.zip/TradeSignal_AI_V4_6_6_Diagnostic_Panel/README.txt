TradeSignal AI V4.6.6 — Painel Diagnóstico

Motor V4.6.6 mantido como referência/congelado.
O painel é somente diagnóstico e não altera as regras do motor.

Inclui:
- seleção 3K / 5K / 15K
- seleção H3 / H5 / H10 / H20
- Sinais, Líquido/op, Acum., DD e PF
- IC-G baseline
- registro dos testes H5 A×B e H10 A×B já realizados
- IC-E-G e estado dos testes registrados
