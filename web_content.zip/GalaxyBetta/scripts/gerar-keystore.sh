#!/bin/bash
# Gera a chave de assinatura UMA VEZ. GUARDE o arquivo e as senhas: sem eles
# voce nao consegue mais atualizar o app. NUNCA envie o .keystore para o GitHub.
set -e
keytool -genkeypair -v -keystore galaxybetta.keystore -alias galaxybetta \
  -keyalg RSA -keysize 2048 -validity 10000
echo
echo "Crie 4 Secrets no GitHub (Settings > Secrets and variables > Actions):"
echo "  KEYSTORE_BASE64   = saida de: base64 -w0 galaxybetta.keystore"
echo "  KEYSTORE_PASSWORD = senha do keystore"
echo "  KEY_ALIAS         = galaxybetta"
echo "  KEY_PASSWORD      = senha da chave"
