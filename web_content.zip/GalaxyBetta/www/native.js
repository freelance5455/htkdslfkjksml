/* GalaxyNative - recursos nativos do Android para o jogo (Capacitor).
 * No navegador comum tudo continua funcionando (usa localStorage e ignora o resto). */
(function () {
  var P = (window.Capacitor && window.Capacitor.Plugins) || {};
  var isNative = !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());

  var G = {
    isNative: isNative,

    /* Salvamento: grava no armazenamento nativo (Preferences). O jogo continua usando
       localStorage; aqui guardamos uma cópia que sobrevive se o Android limpar o WebView. */
    saveNative: function (key, value) {
      try { if (P.Preferences) P.Preferences.set({ key: key, value: String(value) }); } catch (e) {}
    },
    loadNative: function (key) {
      try { return P.Preferences ? P.Preferences.get({ key: key }).then(function (r) { return r.value; }) : Promise.resolve(null); }
      catch (e) { return Promise.resolve(null); }
    },

    /* Vibração: light | medium | heavy | success | error */
    vibrate: function (kind) {
      kind = kind || 'light';
      try {
        if (P.Haptics) {
          if (kind === 'success' || kind === 'error' || kind === 'warning')
            return P.Haptics.notification({ type: kind.toUpperCase() });
          return P.Haptics.impact({ style: kind.toUpperCase() });
        }
        if (navigator.vibrate) navigator.vibrate(30);
      } catch (e) {}
    },

    /* Lembrete diário */
    dailyReminder: function (hour, minute, title, body) {
      var LN = P.LocalNotifications;
      if (!LN) return Promise.resolve(false);
      return LN.requestPermissions().then(function (p) {
        if (p.display !== 'granted') return false;
        return LN.cancel({ notifications: [{ id: 1 }] }).then(function () {
          return LN.schedule({ notifications: [{
            id: 1,
            title: title || 'Galaxy Betta',
            body: body || 'Seu betta lendário te espera! Venha jogar.',
            schedule: { on: { hour: hour == null ? 18 : hour, minute: minute || 0 }, allowWhileIdle: true }
          }] });
        }).then(function () { return true; });
      }).catch(function () { return false; });
    },
    cancelReminder: function () {
      try { if (P.LocalNotifications) P.LocalNotifications.cancel({ notifications: [{ id: 1 }] }); } catch (e) {}
    },

    /* Botão voltar: o jogo pode definir G.onBack = function(){ return true; } se tratou */
    onBack: null
  };

  if (isNative) {
    try { P.StatusBar && P.StatusBar.hide(); } catch (e) {}
    try {
      P.App && P.App.addListener('backButton', function () {
        if (G.onBack && G.onBack() === true) return;
        P.App.exitApp();
      });
      P.App && P.App.addListener('appStateChange', function (s) {
        document.dispatchEvent(new CustomEvent(s.isActive ? 'galaxy:resume' : 'galaxy:pause'));
      });
    } catch (e) {}
  }

  window.GalaxyNative = G;
})();
