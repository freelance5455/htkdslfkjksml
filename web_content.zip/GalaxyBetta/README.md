# Galaxy: The Betta Fish Adventure - app Android (Capacitor)

O jogo (index.html extraido do seu APK) agora fica DENTRO do app, offline, com recursos nativos:
- vibracao nativa (haptics) quando o betta leva dano
- salvamento duplicado no armazenamento nativo (restaura o progresso se o WebView for limpo)
- lembrete diario as 18h por notificacao
- botao voltar, tela cheia, splash e orientacao retrato

## Gerar o APK sem Mac e sem Android Studio (GitHub Actions)
1. Crie um repositorio no GitHub e envie TODO o conteudo desta pasta.
2. Aba **Actions > Build APK > Run workflow**.
3. Ao terminar, baixe **GalaxyBetta-apk** em *Artifacts*: `app-debug.apk` serve para testar.
4. Para o APK de loja (assinado): rode `scripts/gerar-keystore.sh`, crie os 4 Secrets que ele indica e
   rode o workflow de novo -> sai `GalaxyBetta-release.apk`.
5. Icone: coloque um PNG 1024x1024 em `assets/icon-only.png` (o workflow gera todos os tamanhos).

## Para reenviar ao Uptodown
- Use o `GalaxyBetta-release.apk` (assinado).
- Na descricao, cite o que o app tem: jogo de acao offline, salva progresso, vibracao, lembrete diario.
- Mande capturas de tela reais do jogo e icone quadrado maior que 128x128.
- Guarde o keystore: as atualizacoes futuras precisam ser assinadas com a mesma chave.
- Quanto mais recursos proprios o jogo tiver (conquistas, ranking local, tela de configuracoes),
  menos ele parece um "webview simples".
