const fpsMessages = {
  60: "60 FPS target selected. Usually the most compatible target, but actual FPS depends on the phone and game settings.",
  90: "90 FPS target selected. It works only if both the phone display and the game officially support this mode.",
  120: "120 FPS target selected. A 120Hz screen alone does not guarantee 120 FPS; the game, chipset, temperature and software must also support it."
};
document.querySelectorAll(".fps-option").forEach(button => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".fps-option").forEach(item => item.classList.remove("active"));
    button.classList.add("active");
    document.getElementById("fps-message").textContent = fpsMessages[button.dataset.fps];
  });
});
const size = document.getElementById("cross-size");
const gap = document.getElementById("cross-gap");
function updateCrosshair(){
  document.querySelector(".crosshair").style.setProperty("--size", size.value + "px");
  document.querySelector(".crosshair").style.setProperty("--gap", gap.value + "px");
  document.getElementById("cross-size-value").textContent = size.value;
  document.getElementById("cross-gap-value").textContent = gap.value;
}
size.addEventListener("input", updateCrosshair);
gap.addEventListener("input", updateCrosshair);
document.getElementById("reset-checks").addEventListener("click", () => {
  document.querySelectorAll('.check input').forEach(input => input.checked = false);
});
document.getElementById("device-check").addEventListener("click", () => {
  const model = document.getElementById("device").value.trim() || "Your phone";
  const refresh = document.getElementById("refresh").value;
  let note;
  if (refresh === "Unknown") {
    note = "Check Settings → Display for your phone's refresh-rate options. Actual game FPS is controlled separately by the game and device software.";
  } else {
    const hz = parseInt(refresh, 10);
    note = `${model}: the selected display setting is ${refresh}. This is only the screen refresh rate, not a promise of ${hz} FPS in a game. Use only FPS modes offered in the game's official settings.`;
  }
  document.getElementById("device-message").textContent = note;
});
updateCrosshair();
