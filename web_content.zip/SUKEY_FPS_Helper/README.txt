SUKEY FPS HELPER — Spck Editor project

FILES
- index.html
- style.css
- script.js

HOW TO USE ON ANDROID
1. Extract the ZIP.
2. In Spck Editor, open/import the project folder.
3. Open index.html and use Preview.
4. FPS buttons are educational selectors; they do not unlock or force FPS.
5. Crosshair is only shown inside this helper page, not over Free Fire.
6. Device optimisation is a manual checklist; it does not change system settings.

IMPORTANT
60/90/120 FPS requires official support from the phone, display, game, and software.
Do not install unknown FPS unlockers or use files that modify game data.
This is source code, not a compiled APK.
