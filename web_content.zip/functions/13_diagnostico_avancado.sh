#!/system/bin/sh
# Diagnóstico somente leitura. Não altera nenhuma configuração.

echo "--- Diagnóstico Avançado ---"

# ZRAM
if [ -r /sys/block/zram0/disksize ] || grep -q zram /proc/swaps 2>/dev/null; then
  echo "ZRAM: presente"
else
  echo "ZRAM: não detectado"
fi

# Governor de CPU (leitura)
gov="$(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null)"
if [ -n "$gov" ]; then
  echo "Governor CPU0: $gov"
else
  echo "Governor CPU0: não legível sem root"
fi

# Zona térmica (leitura)
temp="$(cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null)"
if [ -n "$temp" ]; then
  echo "Zona térmica 0: ${temp} (unidade varia por fabricante)"
else
  echo "Zona térmica: não legível"
fi

# Taxa de atualização de tela
refresh="$(dumpsys display 2>/dev/null | grep -m1 -o 'fps=[0-9.]*')"
[ -n "$refresh" ] && echo "Tela: $refresh" || echo "Tela: taxa não detectada via dumpsys"

# Renderer gráfico ativo
renderer="$(getprop debug.hwui.renderer 2>/dev/null)"
[ -z "$renderer" ] && renderer="skiagl (padrão)"
echo "Renderer HWUI: $renderer"
