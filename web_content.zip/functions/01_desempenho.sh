#!/system/bin/sh
. "${0%/*}/../lib/common.sh"
# Fluidez da interface: sem mexer em CPU/GPU ou térmica.
set_setting global window_animation_scale 0.0
set_setting global transition_animation_scale 0.0
set_setting global animator_duration_scale 0.0
