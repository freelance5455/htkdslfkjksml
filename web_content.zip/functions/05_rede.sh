#!/system/bin/sh
# Sem alterar DNS, TCP ou propriedades experimentais.
# Mantido como módulo separado para futuras versões.
exit 0
