#!/system/bin/sh
# Reduz a prioridade de log de serviços do sistema para WARN (W).
# Não apaga logs existentes, não mexe em kernel/security/crash/recovery.
. "${0%/*}/../lib/common.sh"

set_prop log.tag.ActivityManager W
set_prop log.tag.ActivityTaskManager W
set_prop log.tag.WindowManager W
set_prop log.tag.PackageManager W
set_prop log.tag.PowerManagerService W
set_prop log.tag.AudioFlinger W
set_prop log.tag.AudioPolicyManager W
set_prop log.tag.CameraService W
set_prop log.tag.BluetoothManagerService W
set_prop log.tag.WifiService W
set_prop log.tag.ConnectivityService W
set_prop log.tag.SurfaceFlinger W
set_prop log.tag.InputDispatcher W
set_prop log.tag.JobScheduler W
set_prop log.tag.AlarmManager W
