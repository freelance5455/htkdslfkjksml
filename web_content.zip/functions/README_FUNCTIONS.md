# Cloud Functions - La Conquista Medieval (Paso 1)

Este módulo contiene la lógica del servidor de Google Cloud Functions (Firebase Functions v2) para arbitrar partidas multijugador, batallas pactadas y tareas de fondo.

## Funciones Principales

1. **`resolveDuePvPChallenges`**:
   - Tarea programada que se ejecuta periódicamente (`every 5 minutes`).
   - Busca en la colección `pvp_challenges` los desafíos pactados (`status == 'accepted'`) cuya hora convenida (`scheduledTime`) ya se ha alcanzado.
   - Ejecuta la simulación de combate de forma autoritativa en el backend, distribuye el botín en oro y puntos de gloria entre ambos reinos, y actualiza el estado a `completed`.

2. **`expireStaleChallenges`**:
   - Tarea programada (`every 30 minutes`).
   - Marca automáticamente como declinados aquellos desafíos pendientes que no recibieron respuesta antes de la hora fijada.

3. **`getFeudalServerStatus`**:
   - Endpoint HTTP con soporte CORS para consultar la hora oficial del servidor feudal y la estación del año.

## Despliegue

```bash
cd functions
npm install
firebase deploy --only functions
```
