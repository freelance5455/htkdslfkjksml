#!/system/bin/sh
cmd activity trim-caches >/dev/null 2>&1 || true
pm trim-caches 512M >/dev/null 2>&1 || true
exit 0
