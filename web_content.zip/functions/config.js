// All business rules live here. Change a number, redeploy: `firebase deploy --only functions`.
module.exports = {
  REGION: 'europe-west1',
  DATABASE_ID: 'ai-studio-e2f64d7f-84c3-48c6-b454-228549a2a217',

  // Owner accounts (email must be verified). Same list as firestore.rules.
  ADMIN_EMAILS: ['smsmsohag20@gmail.com', 'smsm.sohag@gmail.com'],

  // Top-up packages. Must match src/economy.ts and firestore.rules.
  TOPUP_PACKAGES: {
    p50: { price: 50, coins: 5000, flowers: 250 },
    p100: { price: 100, coins: 12000, flowers: 600 },
    p250: { price: 250, coins: 30000, flowers: 1500 }
  },

  DAILY_BONUS: { coins: 250, flowers: 50 },

  // Gifts paid with COINS give the receiver `earnings`. Gifts paid with flowers give none.
  RECEIVER_SHARE: 0.5,

  // Withdrawals (defaults, adjust to your policy)
  EGP_PER_EARNING: 0.01,        // 10,000 earnings = 100 EGP
  MIN_WITHDRAW_EARNINGS: 10000,
  MIN_ACCOUNT_AGE_DAYS: 7,
  WITHDRAW_METHODS: ['vodafone_cash']
};
