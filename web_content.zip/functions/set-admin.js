// Run ONLY in a trusted environment with Firebase Admin SDK credentials.
// Replace TARGET_UID with the UID of your own account from Firebase Console.
const admin = require("firebase-admin");
admin.initializeApp({ credential: admin.credential.applicationDefault() });
const TARGET_UID = "REPLACE_WITH_YOUR_FIREBASE_AUTH_UID";
if (TARGET_UID.startsWith("REPLACE_")) throw new Error("Set TARGET_UID first.");
admin.auth().setCustomUserClaims(TARGET_UID, { admin: true })
  .then(() => { console.log("Admin claim assigned. Sign out and sign back in."); process.exit(0); })
  .catch(err => { console.error(err); process.exit(1); });
