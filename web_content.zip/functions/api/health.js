export async function onRequest() {
  return Response.json({
    app: "Xpressfood",
    status: "starter",
    message: "API scaffold only. Authentication, orders, dispatch and payments are not configured."
  }, { headers: { "Cache-Control": "no-store" } });
}
