import { initializeApp } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import { getFirestore, FieldValue } from "firebase-admin/firestore";
import { onCall, HttpsError } from "firebase-functions/v2/https";
import { createHash, randomBytes, randomInt, scrypt as scryptCb, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";

initializeApp();
const db = getFirestore();
const scrypt = promisify(scryptCb) as (password: string, salt: string, length: number) => Promise<Buffer>;
const normalize = (s: string) => s.normalize("NFKC").trim().toLocaleLowerCase("de-DE").replace(/\s+/g, " ");
const sha = (s: string) => createHash("sha256").update(s).digest("hex");
const pinHash = async (pin: string, salt: string) => (await scrypt(pin, salt, 64)).toString("hex");
const validText = (v: unknown, min: number, max: number): v is string => typeof v === "string" && v.trim().length >= min && v.trim().length <= max;
const genPin = () => String(randomInt(0, 100_000_000)).padStart(8, "0");
const genFamilyCode = () => randomBytes(5).toString("hex").toUpperCase();

async function throttle(key: string, limit = 8) {
  const ref = db.collection("loginLimits").doc(sha(key));
  await db.runTransaction(async tx => {
    const snap = await tx.get(ref);
    const now = Date.now();
    const data = snap.data();
    const since = data?.windowStart?.toMillis?.() ?? 0;
    const count = since > now - 15 * 60 * 1000 ? Number(data?.count ?? 0) : 0;
    if (count >= limit) throw new HttpsError("resource-exhausted", "Zu viele Versuche. Bitte später erneut versuchen.");
    tx.set(ref, { count: count + 1, windowStart: since > now - 15 * 60 * 1000 ? data.windowStart : FieldValue.serverTimestamp() });
  });
}

export const createFamily = onCall({ enforceAppCheck: true, maxInstances: 4 }, async request => {
  const familyName = request.data?.familyName;
  const adminName = request.data?.adminName;
  if (!validText(familyName, 2, 60) || !validText(adminName, 2, 40)) throw new HttpsError("invalid-argument", "Familienname und Mitgliedsname sind erforderlich.");
  await throttle(`create:${request.rawRequest.ip ?? "unknown"}`, 3);
  const familyId = db.collection("families").doc().id;
  const uid = db.collection("families").doc().id;
  const familyCode = genFamilyCode();
  const pin = genPin();
  const salt = randomBytes(16).toString("hex");
  const key = sha(normalize(adminName));
  const credential = await getAuth().createUser({ uid, displayName: adminName.trim() });
  const batch = db.batch();
  batch.set(db.collection("families").doc(familyId), { name: familyName.trim(), inviteCode: familyCode, inviteCodeHash: sha(familyCode), createdAt: FieldValue.serverTimestamp() });
  batch.set(db.collection("familyCodes").doc(sha(familyCode)), { familyId });
  batch.set(db.collection("families").doc(familyId).collection("members").doc(uid), { displayName: adminName.trim(), role: "admin", createdAt: FieldValue.serverTimestamp() });
  batch.set(db.collection("families").doc(familyId).collection("credentials").doc(key), { uid, name: adminName.trim(), nameKey: key, pinSalt: salt, pinHash: await pinHash(pin, salt), role: "admin", failedCount: 0, lockUntil: null });
  await batch.commit();
  const token = await getAuth().createCustomToken(credential.uid, { familyId, role: "admin", displayName: adminName.trim() });
  return { familyId, familyCode, pin, token };
});

export const loginWithPin = onCall({ enforceAppCheck: true, maxInstances: 8 }, async request => {
  const familyCode = request.data?.familyCode;
  const name = request.data?.name;
  const pin = request.data?.pin;
  if (!validText(familyCode, 8, 16) || !validText(name, 2, 40) || typeof pin !== "string" || !/^\d{8}$/.test(pin)) throw new HttpsError("invalid-argument", "Angaben ungültig.");
  const familyKey = sha(familyCode.trim().toUpperCase());
  const nameKey = sha(normalize(name));
  await throttle(`login:${request.rawRequest.ip ?? "unknown"}:${familyKey}:${nameKey}`);
  const code = await db.collection("familyCodes").doc(familyKey).get();
  if (!code.exists) throw new HttpsError("unauthenticated", "Anmeldung fehlgeschlagen.");
  const familyId = code.get("familyId") as string;
  const credRef = db.collection("families").doc(familyId).collection("credentials").doc(nameKey);
  const cred = await credRef.get();
  if (!cred.exists) throw new HttpsError("unauthenticated", "Anmeldung fehlgeschlagen.");
  const data = cred.data()!;
  const lock = data.lockUntil?.toMillis?.() ?? 0;
  if (lock > Date.now()) throw new HttpsError("resource-exhausted", "Anmeldung vorübergehend gesperrt.");
  const actual = Buffer.from(await pinHash(pin, data.pinSalt), "hex");
  const expected = Buffer.from(data.pinHash, "hex");
  const ok = actual.length === expected.length && timingSafeEqual(actual, expected);
  if (!ok) {
    await db.runTransaction(async tx => {
      const latest = await tx.get(credRef); const failures = Number(latest.get("failedCount") ?? 0) + 1;
      tx.update(credRef, { failedCount: failures, lockUntil: failures >= 5 ? new Date(Date.now() + 15 * 60 * 1000) : null });
    });
    throw new HttpsError("unauthenticated", "Anmeldung fehlgeschlagen.");
  }
  await credRef.update({ failedCount: 0, lockUntil: null });
  const token = await getAuth().createCustomToken(data.uid, { familyId, role: data.role, displayName: data.name });
  return { token, familyId };
});

export const inviteMember = onCall({ enforceAppCheck: true }, async request => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Bitte anmelden.");
  const familyId = request.auth.token.familyId as string;
  if (request.auth.token.role !== "admin") throw new HttpsError("permission-denied", "Nur Familienadmins können Mitglieder einladen.");
  const name = request.data?.name;
  if (!validText(name, 2, 40)) throw new HttpsError("invalid-argument", "Name ungültig.");
  const nameKey = sha(normalize(name));
  const credRef = db.collection("families").doc(familyId).collection("credentials").doc(nameKey);
  if ((await credRef.get()).exists) throw new HttpsError("already-exists", "Dieser Name ist in der Familie schon vergeben.");
  const uid = db.collection("families").doc().id;
  const pin = genPin(); const salt = randomBytes(16).toString("hex");
  await getAuth().createUser({ uid, displayName: name.trim() });
  const batch = db.batch();
  batch.set(db.collection("families").doc(familyId).collection("members").doc(uid), { displayName: name.trim(), role: "member", createdAt: FieldValue.serverTimestamp() });
  batch.set(credRef, { uid, name: name.trim(), nameKey, pinSalt: salt, pinHash: await pinHash(pin, salt), role: "member", failedCount: 0, lockUntil: null });
  await batch.commit();
  return { name: name.trim(), pin };
});

export const setProfilePhoto = onCall({ enforceAppCheck: true }, async request => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Bitte anmelden.");
  const familyId = request.auth.token.familyId as string;
  const uid = request.auth.uid;
  const storagePath = request.data?.storagePath;
  if (typeof storagePath !== "string" || !storagePath.startsWith(`families/${familyId}/profiles/${uid}/`) || storagePath.length > 500) {
    throw new HttpsError("invalid-argument", "Profilbild ungültig.");
  }
  await db.collection("families").doc(familyId).collection("members").doc(uid).update({ profilePhotoPath: storagePath });
  return { ok: true };
});
