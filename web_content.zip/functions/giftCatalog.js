// Server-side copy of AVAILABLE_GIFTS (src/gifts.ts). Prices are enforced HERE.
// If you add or reprice a gift in src/gifts.ts, update this file too and redeploy.
module.exports = {
  "snowglobe_tree": {
    "name": "كرة الثلج الكريستالية",
    "icon": "🔮",
    "cost": 999,
    "costCoins": 9999,
    "color": "from-cyan-400 via-blue-500 to-indigo-600"
  },
  "rose": {
    "name": "وردة جورية متألقة",
    "icon": "🌹",
    "cost": 10,
    "costCoins": 50,
    "color": "from-rose-500 to-pink-600"
  },
  "lollipop": {
    "name": "مصاصة السعادة الوردية",
    "icon": "🍭",
    "cost": 30,
    "costCoins": 150,
    "color": "from-pink-400 via-rose-500 to-purple-500"
  },
  "rocket": {
    "name": "صاروخ الفضاء المتألق",
    "icon": "🚀",
    "cost": 150,
    "costCoins": 750,
    "color": "from-purple-600 via-indigo-600 to-cyan-500"
  },
  "finger_heart": {
    "name": "قلب الأصابع الكوري",
    "icon": "🫰",
    "cost": 45,
    "costCoins": 225,
    "color": "from-pink-500 to-rose-400"
  },
  "glowing_star": {
    "name": "نجمة السعادة الساطعة",
    "icon": "🌟",
    "cost": 80,
    "costCoins": 400,
    "color": "from-amber-300 via-yellow-400 to-amber-500"
  },
  "magic_mic": {
    "name": "ميكروفون الغناء الذهبي",
    "icon": "🎤",
    "cost": 200,
    "costCoins": 1000,
    "color": "from-rose-400 via-pink-500 to-purple-600"
  },
  "planet_heart": {
    "name": "كوكب القلوب الفضائي",
    "icon": "🪐",
    "cost": 500,
    "costCoins": 2500,
    "color": "from-fuchsia-500 via-pink-500 to-cyan-400"
  },
  "kisses": {
    "name": "قبلات المحبة والود",
    "icon": "💋",
    "cost": 25,
    "costCoins": 125,
    "color": "from-red-500 to-rose-600"
  },
  "love_letter": {
    "name": "رسالة حب ذهبية",
    "icon": "💌",
    "cost": 40,
    "costCoins": 200,
    "color": "from-pink-400 to-amber-500"
  },
  "crown": {
    "name": "تاج زهرة الملكي",
    "icon": "👑",
    "cost": 250,
    "costCoins": 1250,
    "color": "from-yellow-400 to-amber-600"
  },
  "diamond": {
    "name": "زهرة الألماس البراقة",
    "icon": "💎",
    "cost": 500,
    "costCoins": 2500,
    "color": "from-cyan-400 to-blue-600"
  }
};
