#!/system/bin/sh
. "${0%/*}/../lib/common.sh"
# Remove apenas indicadores visuais de depuração.
set_setting system show_touches 0
set_setting system pointer_location 0
