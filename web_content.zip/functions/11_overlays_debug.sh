#!/system/bin/sh
# Desativa overlays de depuração visual (HWUI, SurfaceFlinger, EGL).
# Todos via 'settings' ou propriedades debug.* — nenhuma exige root.
# Não mexe em nada de segurança, thermal ou boot.
. "${0%/*}/../lib/common.sh"

# --- Settings: global ---
set_setting global debug_view_attributes 0
set_setting global sysui_demo_on 0
set_setting global sysui_tuner_demo_on 0
set_setting global debug_layout 0
set_setting global show_layout_bounds 0
set_setting global debug_gpu_overdraw 0
set_setting global verify_gpu_debug_layers 0
set_setting global enable_gpu_debug_layers 0
set_setting global wait_for_debugger 0
set_setting global debug_app ""

# --- Settings: system ---
set_setting system show_refresh_rate 0
set_setting system show_hw_layers_updates 0
set_setting system show_screen_updates 0
set_setting system show_surface_updates 0
set_setting system show_non_rect_clip 0
set_setting system hwui_profile 0

# --- Propriedades debug.hwui.* ---
set_prop debug.hwui.show_dirty_regions 0
set_prop debug.hwui.show_layers_updates 0
set_prop debug.hwui.overdraw false
set_prop debug.hwui.profile false
set_prop debug.hwui.show_non_rect_clip 0
set_prop debug.hwui.show_draw 0

# --- Propriedades debug.sf.* (SurfaceFlinger) ---
set_prop debug.sf.showupdates 0
set_prop debug.sf.showcpu 0
set_prop debug.sf.showbackground 0
set_prop debug.sf.showfps 0
set_prop debug.sf.showgpu 0
set_prop debug.sf.showrefresh 0
set_prop debug.sf.showpageflips 0
set_prop debug.sf.showlayers 0
set_prop debug.sf.ddms 0

# --- Propriedades EGL / tracing ---
set_prop debug.egl.trace 0
set_prop debug.egl.calltrace 0
set_prop debug.tracing.visualizer 0
set_prop debug.choreographer.profile false
set_prop debug.renderengine.debug 0
