V88 Firebase Functions

This folder contains the server-side earning settlement and withdrawal handlers.
The earning balance is intentionally written only by the Firebase Admin SDK because the database rules protect users/{uid}/balance from direct client writes.

Deploy from the project root:
firebase deploy --only functions,database
