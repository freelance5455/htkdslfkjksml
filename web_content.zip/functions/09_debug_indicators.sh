#!/system/bin/sh
. "${0%/*}/../lib/common.sh" 2>/dev/null || exit 1
set_setting system show_touches 0
set_setting system pointer_location 0
