#!/system/bin/sh
echo "Modelo: $(getprop ro.product.model)"
echo "Android: $(getprop ro.build.version.release)"
echo "SDK: $(getprop ro.build.version.sdk)"
echo "ABI: $(getprop ro.product.cpu.abi)"
echo "Game Mode: $(cmd game help >/dev/null 2>&1 && echo SIM || echo NAO)"
