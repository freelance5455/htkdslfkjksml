const {onDocumentCreated}=require('firebase-functions/v2/firestore');
const {onDocumentUpdated}=require('firebase-functions/v2/firestore');
const {logger}=require('firebase-functions');
const admin=require('firebase-admin');
admin.initializeApp();
const db=admin.firestore();
const radiusKm=8;
function distanceKm(a,b){const rad=x=>x*Math.PI/180,dl=rad(b.lat-a.lat),dn=rad(b.lon-a.lon),h=Math.sin(dl/2)**2+Math.cos(rad(a.lat))*Math.cos(rad(b.lat))*Math.sin(dn/2)**2;return 6371*2*Math.asin(Math.sqrt(h))}
exports.matchNearestDriver=onDocumentCreated('orders/{orderId}',async event=>{
 const snap=event.data;if(!snap)return;const order=snap.data();if(order.status!=='searching')return;
 const drivers=await db.collection('drivers').where('online','==',true).where('approved','==',true).get();
 const candidates=[];
 for(const d of drivers.docs){const x=d.data();if(d.id===order.customerId||!Number.isFinite(x.lat)||!Number.isFinite(x.lon))continue;const km=distanceKm({lat:order.from.lat,lon:order.from.lon},{lat:x.lat,lon:x.lon});if(km<=radiusKm)candidates.push({id:d.id,name:x.name||'Sürücü',km,token:x.fcmToken})}
 candidates.sort((a,b)=>a.km-b.km);
 if(!candidates.length){await snap.ref.update({matchingMessage:'Yaxınlıqda təsdiqlənmiş onlayn sürücü tapılmadı.'});return}
 // Notify the nearest available driver. The driver must accept; concurrent acceptance is guarded by Firestore rules/transaction.
 const nearest=candidates[0];
 await snap.ref.update({notifiedDriverId:nearest.id,notifiedAt:admin.firestore.FieldValue.serverTimestamp()});
 if(nearest.token){try{await admin.messaging().send({token:nearest.token,notification:{title:'Yeni taksi sifarişi',body:`${order.city}: ${order.priceAZN} AZN`},data:{orderId:event.params.orderId,type:'taxi_order'}})}catch(e){logger.warn('FCM push failed; token setup may be missing',e.message)}}
 logger.info(`Order ${event.params.orderId}: nearest driver ${nearest.id}, ${nearest.km.toFixed(2)} km`);
});
exports.clearDriverOnCompletion=onDocumentUpdated('orders/{orderId}',async event=>{
 const before=event.data.before.data(),after=event.data.after.data();
 if(!before||!after||before.status===after.status)return;
 if(after.status==='completed'&&after.driverId){await db.collection('drivers').doc(after.driverId).set({currentOrderId:null,updatedAt:admin.firestore.FieldValue.serverTimestamp()},{merge:true})}
});