'use strict';
const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');
const C = require('./config');
const GIFTS = require('./giftCatalog');

initializeApp();
const db = getFirestore(C.DATABASE_ID);
const opts = { region: C.REGION };

// ---------- helpers ----------
const ID_RE = /^[A-Za-z0-9_-]{1,128}$/;
const fail = (code, msg) => new HttpsError(code, msg);

function authUid(req) {
  if (!req.auth) throw fail('unauthenticated', 'يجب تسجيل الدخول أولاً');
  return req.auth.uid;
}
function cleanId(v, label) {
  if (typeof v !== 'string' || !ID_RE.test(v)) throw fail('invalid-argument', `معرّف غير صالح: ${label}`);
  return v;
}
async function requireAdmin(req) {
  const uid = authUid(req);
  const t = req.auth.token || {};
  if (t.email_verified === true && C.ADMIN_EMAILS.includes(t.email)) return uid;
  const snap = await db.doc(`admins/${uid}`).get();
  if (!snap.exists) throw fail('permission-denied', 'هذه العملية للإدارة فقط');
  return uid;
}
const userRef = (uid) => db.doc(`users/${uid}`);
// Immutable wallet history: written only here (security rules forbid client writes).
function writeLedger(tx, uid, entry) {
  tx.set(db.collection(`users/${uid}/transactions`).doc(), {
    userId: uid,
    ...entry,
    createdAt: FieldValue.serverTimestamp()
  });
}
const num = (v) => (typeof v === 'number' && isFinite(v) ? v : 0);
const iso = () => new Date().toISOString();

// ---------- gifts ----------
// context.type: 'room' | 'chat' | 'profile' | 'bag'
exports.sendGift = onCall(opts, async (request) => {
  const uid = authUid(request);
  const data = request.data || {};
  const gift = GIFTS[data.giftId];
  if (!gift) throw fail('invalid-argument', 'الهدية غير موجودة');
  const currency = data.currency === 'flowers' ? 'flowers' : data.currency === 'coins' ? 'coins' : null;
  if (!currency) throw fail('invalid-argument', 'نوع العملة غير صالح');
  const quantity = Math.min(Math.max(parseInt(data.quantity, 10) || 1, 1), 99);
  const ctx = data.context || {};
  const kind = ctx.type;
  if (!['room', 'chat', 'profile', 'bag'].includes(kind)) throw fail('invalid-argument', 'سياق الهدية غير صالح');

  const price = currency === 'coins' ? gift.costCoins * quantity : gift.cost * quantity;
  const balanceField = currency === 'coins' ? 'coins' : 'flowersCount';

  let targetId = uid;
  let roomRef = null;
  let chatId = null;
  if (kind === 'bag') {
    targetId = uid;
  } else if (kind === 'room') {
    roomRef = db.doc(`rooms/${cleanId(ctx.roomId, 'room')}`);
    targetId = ctx.targetUserId ? cleanId(ctx.targetUserId, 'target') : null; // default: host (below)
  } else {
    targetId = cleanId(ctx.targetUserId, 'target');
  }
  if (kind !== 'bag' && targetId === uid) throw fail('invalid-argument', 'لا يمكنك إهداء نفسك');

  const result = await db.runTransaction(async (tx) => {
    const senderSnap = await tx.get(userRef(uid));
    if (!senderSnap.exists) throw fail('not-found', 'حسابك غير موجود');
    const sender = senderSnap.data();

    let room = null;
    if (roomRef) {
      const roomSnap = await tx.get(roomRef);
      if (!roomSnap.exists) throw fail('not-found', 'الغرفة غير موجودة');
      room = roomSnap.data();
      if (!targetId) targetId = room.hostId;
      if (targetId === uid) throw fail('invalid-argument', 'لا يمكنك إهداء نفسك');
    }

    let target = sender;
    let targetSnap = senderSnap;
    if (targetId !== uid) {
      targetSnap = await tx.get(userRef(targetId));
      if (!targetSnap.exists) throw fail('not-found', 'المستلم غير موجود');
      target = targetSnap.data();
    }
    const giftRef = db.doc(`users/${targetId}/gifts/${data.giftId}`);
    const giftSnap = await tx.get(giftRef);

    const balance = num(sender[balanceField]);
    if (balance < price) {
      throw fail('failed-precondition', `الرصيد غير كافٍ. المطلوب ${price} والمتاح ${balance}`);
    }
    const newBalance = balance - price;
    const earned = kind !== 'bag' && currency === 'coins' ? Math.floor(price * C.RECEIVER_SHARE) : 0;
    const now = iso();

    // 1. sender balance + ledger
    tx.update(userRef(uid), { [balanceField]: newBalance, updatedAt: now });
    writeLedger(tx, uid, {
      type: kind === 'bag' ? 'gift_purchase' : 'gift_sent',
      currency,
      amount: -price,
      balanceAfter: newBalance,
      refType: kind,
      refId: data.giftId,
      counterpartyId: kind === 'bag' ? null : targetId,
      note: `${gift.name} × ${quantity}`
    });

    // 2. receiver earnings + ledger
    if (earned > 0) {
      const earningsAfter = num(target.earnings) + earned;
      tx.update(userRef(targetId), { earnings: FieldValue.increment(earned), updatedAt: now });
      writeLedger(tx, targetId, {
        type: 'gift_received',
        currency: 'earnings',
        amount: earned,
        balanceAfter: earningsAfter,
        refType: kind,
        refId: data.giftId,
        counterpartyId: uid,
        note: `${gift.name} × ${quantity}`
      });
    }

    // 3. gift record on receiver profile
    if (giftSnap.exists) {
      tx.update(giftRef, {
        count: FieldValue.increment(quantity),
        fromId: uid,
        fromName: sender.displayName || '',
        fromAvatar: sender.photoURL || '',
        updatedAt: now
      });
    } else {
      tx.set(giftRef, {
        id: data.giftId,
        giftId: data.giftId,
        name: gift.name,
        icon: gift.icon,
        count: quantity,
        fromId: uid,
        fromName: sender.displayName || '',
        fromAvatar: sender.photoURL || '',
        isSelfPurchased: kind === 'bag',
        receivedAt: now,
        updatedAt: now
      });
    }

    // 4. message (server-authored so it cannot be forged by clients)
    if (kind === 'room') {
      tx.set(roomRef.collection('messages').doc(), {
        roomId: roomRef.id,
        senderId: uid,
        senderName: sender.displayName || '',
        senderAvatar: sender.photoURL || '',
        text: `أهدى ${gift.name} ${gift.icon}${quantity > 1 ? ` × ${quantity}` : ''}`,
        type: 'gift',
        giftType: gift.name,
        giftId: data.giftId,
        targetUserId: targetId,
        targetName: target.displayName || '',
        createdAt: now
      });
    } else if (kind === 'chat') {
      chatId = [uid, targetId].sort().join('_');
      const chatRef = db.doc(`direct_chats/${chatId}`);
      const time = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit', timeZone: 'Africa/Cairo' });
      const text = `أرسل ${gift.icon} ${gift.name}`;
      tx.set(chatRef, {
        id: chatId,
        participants: [uid, targetId],
        participantDetails: {
          [uid]: { displayName: sender.displayName || '', photoURL: sender.photoURL || '', username: sender.username || '' },
          [targetId]: { displayName: target.displayName || '', photoURL: target.photoURL || '', username: target.username || '' }
        },
        lastMessage: `🎁 ${text}`,
        lastMessageSenderId: uid,
        lastTime: time,
        updatedAt: now
      }, { merge: true });
      tx.set(chatRef.collection('messages').doc(), {
        chatId,
        senderId: uid,
        senderName: sender.displayName || '',
        senderAvatar: sender.photoURL || '',
        text,
        type: 'gift',
        gift: { id: data.giftId, name: gift.name, icon: gift.icon, cost: gift.costCoins, color: gift.color },
        createdAt: now,
        timestamp: time
      });
    }

    return {
      coins: currency === 'coins' ? newBalance : num(sender.coins),
      flowersCount: currency === 'flowers' ? newBalance : num(sender.flowersCount),
      earnedByReceiver: earned
    };
  });

  return { ok: true, ...result };
});

// ---------- daily bonus ----------
exports.claimDailyBonus = onCall(opts, async (request) => {
  const uid = authUid(request);
  const today = Math.floor(Date.now() / 86400000);
  const out = await db.runTransaction(async (tx) => {
    const snap = await tx.get(userRef(uid));
    if (!snap.exists) throw fail('not-found', 'حسابك غير موجود');
    const u = snap.data();
    if (num(u.lastDailyClaimDay) >= today) throw fail('failed-precondition', 'استلمت مكافأة اليوم بالفعل');
    const coins = num(u.coins) + C.DAILY_BONUS.coins;
    const flowers = num(u.flowersCount) + C.DAILY_BONUS.flowers;
    tx.update(userRef(uid), { coins, flowersCount: flowers, lastDailyClaimDay: today, updatedAt: iso() });
    writeLedger(tx, uid, { type: 'daily_bonus', currency: 'coins', amount: C.DAILY_BONUS.coins, balanceAfter: coins, refType: 'daily', refId: String(today), note: 'مكافأة يومية' });
    writeLedger(tx, uid, { type: 'daily_bonus', currency: 'flowers', amount: C.DAILY_BONUS.flowers, balanceAfter: flowers, refType: 'daily', refId: String(today), note: 'مكافأة يومية' });
    return { coins, flowersCount: flowers };
  });
  return { ok: true, ...out, bonus: C.DAILY_BONUS };
});

// ---------- top-up review (admin) ----------
exports.reviewTopup = onCall(opts, async (request) => {
  const adminUid = await requireAdmin(request);
  const requestId = cleanId((request.data || {}).requestId, 'request');
  const decision = (request.data || {}).decision;
  if (!['approve', 'reject'].includes(decision)) throw fail('invalid-argument', 'قرار غير صالح');
  const reviewer = request.auth.token.email || adminUid;

  await db.runTransaction(async (tx) => {
    const reqRef = db.doc(`payment_requests/${requestId}`);
    const reqSnap = await tx.get(reqRef);
    if (!reqSnap.exists) throw fail('not-found', 'الطلب غير موجود');
    const req = reqSnap.data();
    if (req.status !== 'pending') throw fail('failed-precondition', 'تمت مراجعة هذا الطلب من قبل');

    if (decision === 'reject') {
      tx.update(reqRef, { status: 'rejected', reviewedAt: iso(), reviewedBy: reviewer });
      return;
    }

    // Amounts come from the server table, never from client-supplied numbers.
    let pkg = C.TOPUP_PACKAGES[req.packageId];
    if (!pkg) {
      pkg = Object.values(C.TOPUP_PACKAGES).find((p) => p.price === req.amount); // old requests without packageId
    }
    if (!pkg) throw fail('failed-precondition', 'الطلب لا يطابق أي باقة معتمدة، ارفضه أو راجع المبلغ يدوياً');

    const uRef = userRef(req.userId);
    const uSnap = await tx.get(uRef);
    if (!uSnap.exists) throw fail('not-found', 'حساب المستخدم غير موجود');
    const u = uSnap.data();
    const coins = num(u.coins) + pkg.coins;
    const flowers = num(u.flowersCount) + pkg.flowers;

    tx.update(reqRef, { status: 'approved', reviewedAt: iso(), reviewedBy: reviewer, creditedCoins: pkg.coins, creditedFlowers: pkg.flowers });
    tx.update(uRef, { coins, flowersCount: flowers, updatedAt: iso() });
    writeLedger(tx, req.userId, { type: 'topup', currency: 'coins', amount: pkg.coins, balanceAfter: coins, refType: 'payment_request', refId: requestId, note: `شحن ${pkg.price} ج.م` });
    writeLedger(tx, req.userId, { type: 'topup', currency: 'flowers', amount: pkg.flowers, balanceAfter: flowers, refType: 'payment_request', refId: requestId, note: `شحن ${pkg.price} ج.م` });
  });
  return { ok: true };
});

// ---------- withdrawals ----------
exports.requestWithdrawal = onCall(opts, async (request) => {
  const uid = authUid(request);
  const data = request.data || {};
  const amount = parseInt(data.amount, 10);
  const method = data.method || 'vodafone_cash';
  const phone = typeof data.phone === 'string' ? data.phone.trim() : '';
  if (!C.WITHDRAW_METHODS.includes(method)) throw fail('invalid-argument', 'طريقة السحب غير متاحة');
  if (!Number.isInteger(amount) || amount <= 0) throw fail('invalid-argument', 'المبلغ غير صالح');
  if (amount < C.MIN_WITHDRAW_EARNINGS) throw fail('failed-precondition', `الحد الأدنى للسحب ${C.MIN_WITHDRAW_EARNINGS} من الأرباح`);
  if (!/^01[0125][0-9]{8}$/.test(phone)) throw fail('invalid-argument', 'رقم فودافون كاش غير صالح (11 رقم يبدأ بـ 01)');

  const out = await db.runTransaction(async (tx) => {
    const snap = await tx.get(userRef(uid));
    if (!snap.exists) throw fail('not-found', 'حسابك غير موجود');
    const u = snap.data();

    const ageDays = (Date.now() - Date.parse(u.createdAt || '')) / 86400000;
    if (!isFinite(ageDays) || ageDays < C.MIN_ACCOUNT_AGE_DAYS) {
      throw fail('failed-precondition', `يجب أن يمر ${C.MIN_ACCOUNT_AGE_DAYS} أيام على إنشاء الحساب`);
    }
    const earnings = num(u.earnings);
    if (earnings < amount) throw fail('failed-precondition', `رصيد الأرباح (${earnings}) أقل من المبلغ المطلوب`);

    // Single-field query (no composite index needed); statuses are checked in code.
    const mine = await tx.get(db.collection('withdrawals').where('userId', '==', uid));
    if (mine.docs.some((d) => ['pending', 'approved'].includes(d.data().status))) {
      throw fail('failed-precondition', 'لديك طلب سحب قيد المعالجة، انتظر اكتماله');
    }

    const now = iso();
    const wRef = db.collection('withdrawals').doc();
    const amountEGP = Math.round(amount * C.EGP_PER_EARNING * 100) / 100;
    const after = earnings - amount;

    tx.update(userRef(uid), { earnings: after, updatedAt: now });
    tx.set(wRef, {
      userId: uid,
      userDisplayName: u.displayName || '',
      userEmail: u.email || '',
      amountEarnings: amount,
      amountEGP,
      method,
      phone,
      status: 'pending',
      createdAt: now,
      updatedAt: now,
      history: [{ status: 'pending', at: now, by: uid }]
    });
    writeLedger(tx, uid, { type: 'withdrawal_hold', currency: 'earnings', amount: -amount, balanceAfter: after, refType: 'withdrawal', refId: wRef.id, note: `طلب سحب ${amountEGP} ج.م` });
    return { id: wRef.id, amountEGP };
  });
  return { ok: true, ...out };
});

// User cancels own pending request -> held earnings are returned.
exports.cancelWithdrawal = onCall(opts, async (request) => {
  const uid = authUid(request);
  const id = cleanId((request.data || {}).withdrawalId, 'withdrawal');
  await db.runTransaction(async (tx) => {
    const wRef = db.doc(`withdrawals/${id}`);
    const wSnap = await tx.get(wRef);
    if (!wSnap.exists || wSnap.data().userId !== uid) throw fail('not-found', 'الطلب غير موجود');
    const w = wSnap.data();
    if (w.status !== 'pending') throw fail('failed-precondition', 'لا يمكن إلغاء طلب تمت معالجته');
    const uSnap = await tx.get(userRef(uid));
    const after = num(uSnap.data().earnings) + w.amountEarnings;
    const now = iso();
    tx.update(userRef(uid), { earnings: after, updatedAt: now });
    tx.update(wRef, { status: 'cancelled', updatedAt: now, history: FieldValue.arrayUnion({ status: 'cancelled', at: now, by: uid }) });
    writeLedger(tx, uid, { type: 'withdrawal_refund', currency: 'earnings', amount: w.amountEarnings, balanceAfter: after, refType: 'withdrawal', refId: id, note: 'إلغاء طلب السحب' });
  });
  return { ok: true };
});

// Admin: pending -> approve | reject ; approved -> paid | reject
exports.reviewWithdrawal = onCall(opts, async (request) => {
  const adminUid = await requireAdmin(request);
  const data = request.data || {};
  const id = cleanId(data.withdrawalId, 'withdrawal');
  const decision = data.decision;
  const note = typeof data.note === 'string' ? data.note.slice(0, 300) : '';
  if (!['approve', 'reject', 'paid'].includes(decision)) throw fail('invalid-argument', 'قرار غير صالح');
  if (decision === 'reject' && !note.trim()) throw fail('invalid-argument', 'اكتب سبب الرفض');
  const reviewer = request.auth.token.email || adminUid;

  await db.runTransaction(async (tx) => {
    const wRef = db.doc(`withdrawals/${id}`);
    const wSnap = await tx.get(wRef);
    if (!wSnap.exists) throw fail('not-found', 'الطلب غير موجود');
    const w = wSnap.data();
    const now = iso();

    const allowed = {
      approve: ['pending'],
      paid: ['approved'],
      reject: ['pending', 'approved']
    };
    if (!allowed[decision].includes(w.status)) {
      throw fail('failed-precondition', `لا يمكن تنفيذ هذا القرار والطلب في حالة (${w.status})`);
    }

    if (decision === 'reject') {
      const uSnap = await tx.get(userRef(w.userId));
      if (!uSnap.exists) throw fail('not-found', 'حساب المستخدم غير موجود');
      const after = num(uSnap.data().earnings) + w.amountEarnings;
      tx.update(userRef(w.userId), { earnings: after, updatedAt: now });
      writeLedger(tx, w.userId, { type: 'withdrawal_refund', currency: 'earnings', amount: w.amountEarnings, balanceAfter: after, refType: 'withdrawal', refId: id, note: `رفض الطلب: ${note}` });
    }
    if (decision === 'paid') {
      writeLedger(tx, w.userId, { type: 'withdrawal_paid', currency: 'earnings', amount: 0, balanceAfter: null, refType: 'withdrawal', refId: id, note: `تم تحويل ${w.amountEGP} ج.م` });
    }

    const status = decision === 'approve' ? 'approved' : decision === 'paid' ? 'paid' : 'rejected';
    tx.update(wRef, {
      status,
      updatedAt: now,
      reviewedBy: reviewer,
      adminNote: note,
      history: FieldValue.arrayUnion({ status, at: now, by: reviewer, note })
    });
  });
  return { ok: true };
});
