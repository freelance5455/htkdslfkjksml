const {onValueCreated}=require('firebase-functions/v2/database');
const {onSchedule}=require('firebase-functions/v2/scheduler');
const admin=require('firebase-admin');
admin.initializeApp();
function collectTokens(node,out=[]){if(!node)return out;if(typeof node==='string'){out.push(node);return out}if(typeof node==='object'){if(node.token)out.push(node.token);else Object.values(node).forEach(v=>collectTokens(v,out));}return out}
exports.sendPushFromQueue=onValueCreated('/pushQueue/{id}',async(event)=>{
  const data=event.data.val()||{};
  const snap=await admin.database().ref('fcmTokens').once('value');
  const tokens=[...new Set(collectTokens(snap.val()||{}))];
  if(!tokens.length){
    await admin.database().ref('pushQueue/'+event.params.id).update({status:'no_tokens',sentAt:Date.now(),successCount:0,failureCount:0});
    return null;
  }
  const base={notification:{title:String(data.title||'Vaishnav World'),body:String(data.text||data.body||'New devotional update')},
    data:{type:String(data.type||'general'),route:String(data.route||'notifications')}};
  let successCount=0,failureCount=0,bad=[];
  // FCM multicast accepts up to 500 registration tokens per request.
  for(let i=0;i<tokens.length;i+=500){
    const batch=tokens.slice(i,i+500);
    const res=await admin.messaging().sendEachForMulticast({...base,tokens:batch});
    successCount+=res.successCount;failureCount+=res.failureCount;
    res.responses.forEach((r,j)=>{if(!r.success)bad.push(batch[j]);});
  }
  if(bad.length){
    const all=snap.val()||{};
    for(const [key,x] of Object.entries(all)){
      const t=typeof x==='string'?x:x?.token;
      if(t&&bad.includes(t))await admin.database().ref('fcmTokens/'+key).remove();
    }
  }
  await admin.database().ref('pushQueue/'+event.params.id).update({status:'sent',sentAt:Date.now(),successCount,failureCount});
  return null;
});
exports.sendBirthdayWishesDaily=onSchedule({schedule:'0 6 * * *',timeZone:'Asia/Kolkata'},async()=>{
  const now=new Date();
  const iso=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Kolkata',year:'numeric',month:'2-digit',day:'2-digit'}).format(now);
  const md=iso.slice(5,10);
  const users=(await admin.database().ref('users').once('value')).val()||{};
  for(const [uid,u] of Object.entries(users)){
    const people=[];
    if(u?.dob && String(u.dob).slice(5,10)===md) people.push({id:'you',name:u.name||'Devotee'});
    for(const [id,m] of Object.entries(u?.members||{})){if(m?.dob&&String(m.dob).slice(5,10)===md)people.push({id,name:m.name||'Devotee'});}
    for(const p of people){
      const key=`${iso}_${uid}_${p.id}`;
      const sent=await admin.database().ref('birthdayNotifications/'+key).once('value');
      if(sent.exists()) continue;
      const q=admin.database().ref('pushQueue').push();
      await q.set({title:'🎂 Birthday Wishes',text:`Today is ${p.name}'s birthday. Send your warm wishes! 🙏`,type:'birthday',route:'home',target:'all',status:'queued',createdAt:Date.now()});
      await admin.database().ref('birthdayNotifications/'+key).set({uid,memberId:p.id,name:p.name,createdAt:Date.now()});
    }
  }
  return null;
});
