const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");
initializeApp();
const db = getFirestore();

function requireUser(req) {
  if (!req.auth) throw new HttpsError("unauthenticated", "कृपया पहले login करें।");
  return req.auth.uid;
}
function requireAdmin(req) {
  const uid = requireUser(req);
  if (req.auth.token.admin !== true) throw new HttpsError("permission-denied", "Admin access आवश्यक है।");
  return uid;
}
function cleanString(value, max=500) {
  if (typeof value !== "string") throw new HttpsError("invalid-argument", "Invalid text field.");
  const v=value.trim();
  if (!v || v.length>max) throw new HttpsError("invalid-argument", "Text field खाली या बहुत लंबा है।");
  return v;
}
function validHttpsUrl(value) {
  try { const u=new URL(value); return u.protocol==="https:" && !!u.hostname; } catch { return false; }
}

exports.createOrder = onCall({ enforceAppCheck: false }, async (req) => {
  const uid=requireUser(req);
  const serviceId=cleanString(req.data?.serviceId,100);
  const targetUrl=cleanString(req.data?.targetUrl,1500);
  const quantity=Number(req.data?.quantity);
  if (!validHttpsUrl(targetUrl)) throw new HttpsError("invalid-argument","केवल valid https URL स्वीकार है।");
  if (!Number.isSafeInteger(quantity) || quantity<1 || quantity>1000000) throw new HttpsError("invalid-argument","Quantity मान्य सीमा में होनी चाहिए।");

  const serviceRef=db.collection("services").doc(serviceId);
  const serviceSnap=await serviceRef.get();
  if(!serviceSnap.exists || serviceSnap.data().active!==true) throw new HttpsError("not-found","यह service उपलब्ध नहीं है।");
  const s=serviceSnap.data();
  if(quantity < Number(s.minQty||1) || quantity > Number(s.maxQty||100000)) throw new HttpsError("invalid-argument","Quantity इस service की सीमा से बाहर है।");
  const rate=Number(s.pricePer1000);
  if(!Number.isFinite(rate)||rate<0) throw new HttpsError("failed-precondition","Service rate सही नहीं है।");
  const totalPrice=Math.round((rate*quantity/1000)*100)/100;
  const orderRef=db.collection("orders").doc();
  await orderRef.set({
    userId:uid, serviceId, platform:String(s.platform||"Other"),
    serviceName:String(s.name||"Service"), targetUrl, quantity,
    pricePer1000:rate, totalPrice, currency:"INR",
    status:"Pending", paymentStatus:"UNPAID", paymentReference:null,
    createdAt:FieldValue.serverTimestamp(), updatedAt:FieldValue.serverTimestamp()
  });
  return { orderId:orderRef.id, totalPrice, currency:"INR" };
});

exports.adminUpdateOrder = onCall(async (req) => {
  requireAdmin(req);
  const orderId=cleanString(req.data?.orderId,150);
  const status=cleanString(req.data?.status,30);
  const allowed=["Pending","Processing","Completed","Cancelled"];
  if(!allowed.includes(status)) throw new HttpsError("invalid-argument","Invalid status.");
  const ref=db.collection("orders").doc(orderId);
  const snap=await ref.get();
  if(!snap.exists) throw new HttpsError("not-found","Order नहीं मिला।");
  await ref.update({status,updatedAt:FieldValue.serverTimestamp()});
  return {ok:true};
});

exports.submitPaymentReference = onCall(async (req) => {
  const uid=requireUser(req);
  const orderId=cleanString(req.data?.orderId,150);
  const utr=cleanString(req.data?.utr,100);
  const ref=db.collection("orders").doc(orderId);
  const snap=await ref.get();
  if(!snap.exists) throw new HttpsError("not-found","Order नहीं मिला।");
  const order=snap.data();
  if(order.userId!==uid && req.auth.token.admin!==true) throw new HttpsError("permission-denied","यह आपका order नहीं है।");
  if(req.auth.token.admin===true) {
    // Admin must independently verify the reference in the bank/UPI app before marking paid.
    await ref.update({paymentStatus:"PAID",paymentReference:utr,paymentVerifiedBy:uid,paymentVerifiedAt:FieldValue.serverTimestamp(),updatedAt:FieldValue.serverTimestamp()});
  } else {
    await ref.update({paymentStatus:"REFERENCE_SUBMITTED",paymentReference:utr,paymentSubmittedAt:FieldValue.serverTimestamp(),updatedAt:FieldValue.serverTimestamp()});
  }
  return {ok:true};
});
