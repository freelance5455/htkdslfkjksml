const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { defineString } = require('firebase-functions/params');
const { initializeApp } = require('firebase-admin/app');
const { getAuth } = require('firebase-admin/auth');
const { getFirestore } = require('firebase-admin/firestore');

initializeApp();
const db = getFirestore();
// This is the Firebase Web API key, which is a client project identifier, not a service-account secret.
const webApiKey = defineString('FIREBASE_WEB_API_KEY');

// Verifies username+password with Firebase Identity Toolkit, without exposing an account's email
// unless the supplied password is valid. Passwords are never stored by this function.
exports.usernameLogin = onCall({ maxInstances: 10 }, async (request) => {
  const username = String(request.data?.username || '').trim().toLowerCase();
  const password = String(request.data?.password || '');
  if (!/^[a-z0-9_.]{3,24}$/.test(username) || !password) {
    throw new HttpsError('unauthenticated', 'Invalid username or password.');
  }
  const index = await db.collection('usernames').doc(username).get();
  if (!index.exists || typeof index.data()?.uid !== 'string') {
    // Same outward error as wrong password; do not reveal whether a username exists.
    throw new HttpsError('unauthenticated', 'Invalid username or password.');
  }
  let account;
  try { account = await getAuth().getUser(index.data().uid); }
  catch (_) { throw new HttpsError('unauthenticated', 'Invalid username or password.'); }
  if (!account.email) throw new HttpsError('unauthenticated', 'Invalid username or password.');
  let response;
  try {
    response = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${webApiKey.value()}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: account.email, password, returnSecureToken: true })
    });
  } catch (_) { throw new HttpsError('unavailable', 'Sign-in service unavailable. Please try again.'); }
  if (!response.ok) throw new HttpsError('unauthenticated', 'Invalid username or password.');
  return { email: account.email };
});

