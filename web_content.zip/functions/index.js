const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore } = require("firebase-admin/firestore");
initializeApp();

const BLOCKED = [
  "fuck", "shit", "bitch", "asshole", "bastard", "dick", "piss",
  "cunt", "motherfucker", "nigger", "faggot"
];
function cleanName(value) {
  return String(value || "").normalize("NFKC").trim().replace(/\s+/g, " ");
}
function isCleanName(name) {
  const normalized = name.toLowerCase().replace(/[^a-z0-9]/g, "");
  return !BLOCKED.some(word => normalized.includes(word));
}

exports.setDisplayName = onCall(async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Please sign in first.");
  const name = cleanName(request.data?.displayName);
  if (!/^[a-zA-Z0-9 _.-]{3,20}$/.test(name))
    throw new HttpsError("invalid-argument", "Use 3–20 letters, numbers, spaces, dots, _ or -.");
  if (!isCleanName(name))
    throw new HttpsError("invalid-argument", "Please choose a respectful display name.");
  await getFirestore().doc(`profiles/${request.auth.uid}`).set({
    displayName: name,
    updatedAt: new Date()
  }, { merge: true });
  return { ok: true, displayName: name };
});