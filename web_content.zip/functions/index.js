const {onCall,HttpsError} = require("firebase-functions/v2/https");
const {initializeApp} = require("firebase-admin/app");
const {getFirestore} = require("firebase-admin/firestore");
const {getMessaging} = require("firebase-admin/messaging");
initializeApp();
const db=getFirestore();

async function adminOnly(request){
  if(!request.auth) throw new HttpsError("unauthenticated","Login required");
  const u=await db.doc(`users/${request.auth.uid}`).get();
  if(!u.exists || u.data().role!=="admin") throw new HttpsError("permission-denied","Admin only");
}

exports.sendPush=onCall(async request=>{
  await adminOnly(request);
  const {title,body,url}=request.data||{};
  if(!title || !body) throw new HttpsError("invalid-argument","title and body are required");
  const users=await db.collection("users").get();
  const tokens=[];
  for(const u of users.docs){
    const ts=await u.ref.collection("tokens").get();
    ts.forEach(t=>{if(t.id)tokens.push(t.id)});
  }
  let sent=0;
  for(let i=0;i<tokens.length;i+=500){
    const batch=tokens.slice(i,i+500);
    const r=await getMessaging().sendEachForMulticast({
      tokens:batch,
      notification:{title,body},
      data:{url:url||"/"}
    });
    sent+=r.successCount;
  }
  return {sent};
});