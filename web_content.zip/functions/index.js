const {onCall, HttpsError} = require("firebase-functions/v2/https");
const {initializeApp} = require("firebase-admin/app");
const {getAuth} = require("firebase-admin/auth");
const {getFirestore, FieldValue} = require("firebase-admin/firestore");
const crypto = require("crypto");
initializeApp();
const db = getFirestore();

exports.createGarage = onCall(async (req) => {
  if (!req.auth) throw new HttpsError("unauthenticated", "Sign in first.");
  const name = String(req.data.name || "").trim();
  if (!name) throw new HttpsError("invalid-argument", "Garage name is required.");
  const uid = req.auth.uid, ref = db.collection("garages").doc();
  await ref.set({name, ownerUid: uid, createdAt: FieldValue.serverTimestamp()});
  await ref.collection("members").doc(uid).set({uid, role:"manager", displayName:req.auth.token.name || "Manager", createdAt:FieldValue.serverTimestamp()});
  await db.collection("users").doc(uid).set({garageId:ref.id, role:"manager"}, {merge:true});
  return {garageId:ref.id};
});

exports.createEmployee = onCall(async (req) => {
  if (!req.auth) throw new HttpsError("unauthenticated", "Sign in first.");
  const garageId = String(req.data.garageId || "");
  const email = String(req.data.email || "").trim().toLowerCase();
  const displayName = String(req.data.displayName || "").trim();
  const tempPassword = String(req.data.tempPassword || "");
  if (!garageId || !email || !displayName || tempPassword.length < 8)
    throw new HttpsError("invalid-argument", "Garage, name, email and password (8+ chars) are required.");
  const member = await db.doc(`garages/${garageId}/members/${req.auth.uid}`).get();
  if (!member.exists || member.data().role !== "manager")
    throw new HttpsError("permission-denied", "Manager only.");
  let user;
  try { user = await getAuth().createUser({email, password:tempPassword, displayName, disabled:false}); }
  catch (e) { throw new HttpsError("already-exists", e.message); }
  await db.doc(`garages/${garageId}/members/${user.uid}`).set({
    uid:user.uid, role:"employee", displayName, email, mustChangePassword:true,
    createdAt:FieldValue.serverTimestamp()
  });
  await db.doc(`users/${user.uid}`).set({garageId, role:"employee"});
  return {uid:user.uid, email};
});

exports.createInvite = onCall(async (req) => {
  if (!req.auth) throw new HttpsError("unauthenticated", "Sign in first.");
  const garageId = String(req.data.garageId || "");
  const m = await db.doc(`garages/${garageId}/members/${req.auth.uid}`).get();
  if (!m.exists || m.data().role !== "manager") throw new HttpsError("permission-denied", "Manager only.");
  const code = crypto.randomBytes(5).toString("hex").toUpperCase();
  await db.doc(`garages/${garageId}/invites/${code}`).set({code, active:true, createdAt:FieldValue.serverTimestamp()});
  return {code};
});