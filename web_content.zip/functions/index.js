const functions = require("firebase-functions");
const admin = require("firebase-admin");
admin.initializeApp();
const db = admin.database();
const logger = functions.logger || console;
const RATES = {0:0.10,1:0.15,2:0.20,3:0.30,4:0.40,5:0.50};
const num=(v,d=0)=>{const x=Number(v);return Number.isFinite(x)?x:d};
const obj=v=>v&&typeof v==="object"?v:{};
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function settleClaim(uid,claimId){
 const claimRef=db.ref(`earningClaims/${uid}/${claimId}`);
 const snap=await claimRef.once('value'); if(!snap.exists())return null;
 const claim=obj(snap.val()); if(String(claim.uid)!==String(uid))return null;
 const status=String(claim.status||'PENDING').toUpperCase();
 if(status==='PROCESSED'||status==='REJECTED'||status==='FAILED'||claim.clientFallbackApplied===true)return null;
 const lock=await claimRef.transaction(cur=>{if(!cur)return;const st=String(cur.status||'PENDING').toUpperCase();if(st!=='PENDING')return;return {...cur,status:'PROCESSING',processingAt:admin.database.ServerValue.TIMESTAMP,serverVersion:'V89'};});
 if(!lock.committed)return null;
 try{
  const fresh=obj((await claimRef.once('value')).val());
  const sessionId=String(fresh.sessionId||'');const mb=Math.max(0,num(fresh.simulationMb));const earning=Math.max(0,num(fresh.simulationEarning));
  if(!sessionId||mb<=0||earning<=0){await claimRef.update({status:'REJECTED',reason:'INVALID_EARNING_CLAIM',processedAt:admin.database.ServerValue.TIMESTAMP});return null;}
  let sessionSnap=null,session={};
  for(let i=0;i<10;i++){sessionSnap=await db.ref(`sellSessions/${uid}/${sessionId}`).once('value');session=obj(sessionSnap.val());if(sessionSnap.exists()&&String(session.status||'').toUpperCase()==='STOPPED')break;await sleep(350);}
  const duration=Math.max(0,num(session.stoppedAt)-num(session.startedAt));
  const maxMb=Math.min(25000,Math.max(50,duration/1000*22));
  if(!sessionSnap?.exists()||String(session.uid)!==String(uid)||String(session.status||'').toUpperCase()!=='STOPPED'||duration<=0||mb>maxMb||Math.abs(num(session.simulationMb)-mb)>0.011||Math.abs(num(session.simulationEarning)-earning)>0.011){await claimRef.update({status:'REJECTED',reason:'SESSION_VALIDATION_FAILED',processedAt:admin.database.ServerValue.TIMESTAMP});return null;}
  const userSnap=await db.ref(`users/${uid}`).once('value'); if(!userSnap.exists()){await claimRef.update({status:'REJECTED',reason:'USER_NOT_FOUND',processedAt:admin.database.ServerValue.TIMESTAMP});return null;}
  const user=obj(userSnap.val());const level=Math.max(0,Math.min(5,num(user.level)));const rate=RATES[level]??0.10;const expected=Number((mb/5*rate).toFixed(4));
  if(Math.abs(expected-earning)>0.011){await claimRef.update({status:'REJECTED',reason:'EARNING_MISMATCH',expectedEarning:expected,processedAt:admin.database.ServerValue.TIMESTAMP});return null;}
  const updates={};
  updates[`users/${uid}/balance`]=Number((num(user.balance)+earning).toFixed(2));
  updates[`users/${uid}/totalEarned`]=Number((num(user.totalEarned)+earning).toFixed(4));
  updates[`users/${uid}/totalDataSold`]=Number((num(user.totalDataSold)+mb).toFixed(2));
  updates[`users/${uid}/pendingBalance`]=0;
  updates[`users/${uid}/lastSeenAt`]=admin.database.ServerValue.TIMESTAMP;
  updates[`sellSessions/${uid}/${sessionId}/verifiedDataMb`]=mb;
  updates[`sellSessions/${uid}/${sessionId}/verifiedEarnings`]=earning;
  updates[`sellSessions/${uid}/${sessionId}/serverVerified`]=true;
  updates[`sellSessions/${uid}/${sessionId}/settledAt`]=admin.database.ServerValue.TIMESTAMP;
  updates[`earningClaims/${uid}/${claimId}/status`]='PROCESSED';
  updates[`earningClaims/${uid}/${claimId}/processedAt`]=admin.database.ServerValue.TIMESTAMP;
  updates[`earningClaims/${uid}/${claimId}/processingAt`]=null;
  await db.ref().update(updates); logger.info('V89/V88 earning claim processed',{uid,claimId,sessionId,mb,earning}); return true;
 }catch(error){logger.error('V88 earning settlement failed',{uid,claimId,error:String(error?.message||error)});await claimRef.update({status:'PENDING',reason:'SERVER_RETRY',lastError:String(error?.message||error),lastCheckedAt:admin.database.ServerValue.TIMESTAMP}).catch(()=>{});return false;}
}
exports.processEarningClaim=functions.database.ref('/earningClaims/{uid}/{claimId}').onWrite(async(change,context)=>{const after=change.after.val()||{};if(!after||after.uid!==context.params.uid)return null;return settleClaim(context.params.uid,context.params.claimId);});
exports.retryEarningOnSessionStop=functions.database.ref('/sellSessions/{uid}/{sessionId}').onWrite(async(change,context)=>{const session=change.after.val()||{};if(!session||String(session.uid)!==String(context.params.uid)||String(session.status||'').toUpperCase()!=='STOPPED')return null;const snap=await db.ref(`earningClaims/${context.params.uid}`).orderByChild('sessionId').equalTo(context.params.sessionId).once('value');const jobs=[];snap.forEach(child=>{const c=obj(child.val());if(String(c.status||'PENDING').toUpperCase()==='PENDING')jobs.push(settleClaim(context.params.uid,child.key));});await Promise.all(jobs);return null;});
exports.retryEarningClaim=functions.database.ref('/earningClaimRetries/{uid}/{retryId}').onWrite(async(change,context)=>{const retry=change.after.val()||{};if(!retry||retry.uid!==context.params.uid)return null;const claimId=String(retry.claimId||'');if(claimId)await settleClaim(context.params.uid,claimId);return null;});
exports.processWithdrawalRequest=functions.database.ref('/withdrawalRequests/{uid}/{requestId}').onCreate(async(snap,context)=>{const {uid,requestId}=context.params,req=obj(snap.val());if(req.uid!==uid||String(req.status).toUpperCase()!=='REQUESTED')return null;const userSnap=await db.ref(`users/${uid}`).once('value');if(!userSnap.exists())return null;const user=obj(userSnap.val());if(user.withdrawalActivated!==true){await db.ref(`withdrawalRequests/${uid}/${requestId}`).update({status:'REJECTED',reason:'WITHDRAWAL_NOT_ACTIVATED'});return null;}const amount=num(req.amount);if(!(amount>0)){await db.ref(`withdrawalRequests/${uid}/${requestId}`).update({status:'REJECTED',reason:'INVALID_AMOUNT'});return null;}const existing=await db.ref('withdrawals').orderByChild('uid').equalTo(uid).once('value');let pending=0;existing.forEach(s=>{const w=obj(s.val());if(String(w.status||'PENDING').toUpperCase()==='PENDING')pending+=Math.max(0,num(w.amount));});const available=Math.max(0,num(user.balance)-pending);if(amount>available){await db.ref(`withdrawalRequests/${uid}/${requestId}`).update({status:'REJECTED',reason:'INSUFFICIENT_AVAILABLE_BALANCE'});return null;}const orderId=String(req.orderId||`WD-${requestId}`);const payload={id:requestId,orderId,uid,name:String(req.name||user.name||'User'),email:String(req.email||user.email||''),mobile:String(req.mobile||user.mobile||''),method:String(req.method||'UPI'),amount,status:'PENDING',statusMessage:'Waiting for admin approval',createdAt:req.createdAt||admin.database.ServerValue.TIMESTAMP,updatedAt:admin.database.ServerValue.TIMESTAMP,details:obj(req.details)};const updates={};updates[`withdrawals/${requestId}`]=payload;updates[`users/${uid}/withdrawalIds/${requestId}`]=true;updates[`users/${uid}/withdrawalOrders/${orderId}`]=requestId;updates[`withdrawalRequests/${uid}/${requestId}/status`]='PROCESSED';updates[`withdrawalRequests/${uid}/${requestId}/processedAt`]=admin.database.ServerValue.TIMESTAMP;await db.ref().update(updates);logger.info('V88 withdrawal request processed',{uid,requestId,amount});return null;});
