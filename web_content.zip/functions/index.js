const functions=require('firebase-functions/v1'),admin=require('firebase-admin');
admin.initializeApp();const db=admin.firestore(),FV=admin.firestore.FieldValue;
const SUPER=(process.env.SUPER_ADMIN_EMAIL||'').toLowerCase();
// Add ENFORCE_APPCHECK=true to functions/.env once App Check is configured (see README)
const fn=functions.runWith({enforceAppCheck:process.env.ENFORCE_APPCHECK==='true'}).https;
const E=(c,m)=>new functions.https.HttpsError(c,m),deny=()=>E('permission-denied','Not allowed'),bad=m=>E('invalid-argument',m);
const clean=(s,n)=>String(s||'').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F<>]/g,'').trim().slice(0,n);
const isMod=a=>['admin','superadmin'].includes(a.token.role);
const log=(action,actor,target,extra)=>db.collection('logs').add({action,actor,target:target||null,extra:extra||null,at:FV.serverTimestamp()});
async function active(c){if(!c.auth)throw E('unauthenticated','Login required');if(c.auth.token.suspended)throw deny();return c.auth;}
async function setClaims(uid,p){const u=await admin.auth().getUser(uid);await admin.auth().setCustomUserClaims(uid,{...(u.customClaims||{}),...p});}
async function limit(uid){const r=db.doc('rl/'+uid);await db.runTransaction(async t=>{const s=await t.get(r),n=Date.now();let x=s.exists?s.data():{w:n,n:0};if(n-x.w>10000)x={w:n,n:0};if(++x.n>15)throw E('resource-exhausted','Slow down');t.set(r,x);});}
async function validUsers(ids){const out=[];for(const id of [...new Set(ids||[])].slice(0,50)){const s=await db.doc('users/'+String(id)).get();if(s.exists&&!s.data().suspended)out.push(s.id);}return out;}

exports.onUserCreate=functions.auth.user().onCreate(u=>{const n=clean(u.displayName||(u.email||'user').split('@')[0],40);
 return db.doc('users/'+u.uid).set({email:u.email||'',displayName:n,searchName:n.toLowerCase(),photoURL:u.photoURL||'',role:'user',suspended:false,createdAt:FV.serverTimestamp()});});

// Trusted bootstrap: only the verified owner email, decided server-side.
exports.bootstrapSuperAdmin=fn.onCall(async(d,c)=>{const a=await active(c);
 if(!SUPER||(a.token.email||'').toLowerCase()!==SUPER||a.token.email_verified!==true)throw deny();
 if(a.token.role!=='superadmin'){await setClaims(a.uid,{role:'superadmin'});await db.doc('users/'+a.uid).update({role:'superadmin'});await log('bootstrap',a.uid);}
 return{ok:true};});

exports.setRole=fn.onCall(async(d,c)=>{const a=await active(c);if(a.token.role!=='superadmin')throw deny();
 const t=await admin.auth().getUser(String(d.uid));
 if(!['admin','user'].includes(d.role)||(t.email||'').toLowerCase()===SUPER||t.customClaims?.role==='superadmin')throw deny();
 await setClaims(t.uid,{role:d.role});await db.doc('users/'+t.uid).update({role:d.role});await log('setRole',a.uid,t.uid,d.role);return{ok:true};});

exports.setSuspended=fn.onCall(async(d,c)=>{const a=await active(c);if(!isMod(a))throw deny();
 const t=await admin.auth().getUser(String(d.uid)),tr=t.customClaims?.role,s=!!d.suspended;
 if(t.uid===a.uid||tr==='superadmin'||(tr==='admin'&&a.token.role!=='superadmin'))throw deny();
 await setClaims(t.uid,{suspended:s});await admin.auth().updateUser(t.uid,{disabled:s});if(s)await admin.auth().revokeRefreshTokens(t.uid);
 await db.doc('users/'+t.uid).update({suspended:s});await log(s?'suspend':'reactivate',a.uid,t.uid);return{ok:true};});

exports.openDm=fn.onCall(async(d,c)=>{const a=await active(c),o=String(d.uid);if(o===a.uid)throw bad('Cannot message yourself');
 if(!(await validUsers([o])).length)throw bad('User unavailable');
 const id=[a.uid,o].sort().join('_'),r=db.doc('chats/'+id);
 if(!(await r.get()).exists)await r.set({type:'dm',members:[a.uid,o],admins:[],lastAt:FV.serverTimestamp(),lastMessage:'',reads:{},createdAt:FV.serverTimestamp()});return{id};});

exports.sendMessage=fn.onCall(async(d,c)=>{const a=await active(c);await limit(a.uid);
 const r=db.doc('chats/'+d.chatId),s=await r.get();if(!s.exists||!s.data().members.includes(a.uid))throw deny();
 const text=clean(d.text,2000);let img=null;
 if(d.imageUrl){if(!String(d.imageUrl).startsWith('https://firebasestorage.googleapis.com/')||!d.imageUrl.includes(encodeURIComponent('chat/'+d.chatId+'/')))throw bad('Bad image');img=d.imageUrl;}
 if(!text&&!img)throw bad('Empty message');
 const m=r.collection('messages').doc();
 await db.batch().set(m,{from:a.uid,text,imageUrl:img,at:FV.serverTimestamp(),deleted:false})
  .update(r,{lastMessage:text?text.slice(0,80):'📷 Photo',lastAt:FV.serverTimestamp(),lastFrom:a.uid,['reads.'+a.uid]:FV.serverTimestamp()}).commit();
 return{id:m.id};});

exports.markRead=fn.onCall(async(d,c)=>{const a=await active(c),r=db.doc('chats/'+d.chatId),s=await r.get();
 if(!s.exists||!s.data().members.includes(a.uid))throw deny();await r.update({['reads.'+a.uid]:FV.serverTimestamp()});return{ok:true};});

exports.createGroup=fn.onCall(async(d,c)=>{const a=await active(c),name=clean(d.name,40);if(!name)throw bad('Name required');
 const m=(await validUsers(d.members)).filter(x=>x!==a.uid);if(!m.length)throw bad('Add at least one member');
 const r=db.collection('chats').doc();await r.set({type:'group',name,photoURL:'',members:[a.uid,...m],admins:[a.uid],lastAt:FV.serverTimestamp(),lastMessage:'Group created',reads:{},createdBy:a.uid,createdAt:FV.serverTimestamp()});
 return{id:r.id};});

async function grp(c,id){const a=await active(c),r=db.doc('chats/'+id),s=await r.get();if(!s.exists||s.data().type!=='group')throw bad('Group not found');return{a,r,g:s.data()};}
exports.updateGroup=fn.onCall(async(d,c)=>{const {a,r,g}=await grp(c,d.chatId);
 if(!g.members.includes(a.uid)||!(g.admins.includes(a.uid)||isMod(a)))throw deny();
 const up={};if(d.name)up.name=clean(d.name,40);
 if(d.photoURL&&String(d.photoURL).startsWith('https://firebasestorage.googleapis.com/')&&d.photoURL.includes(encodeURIComponent('groupavatars/'+d.chatId)))up.photoURL=d.photoURL;
 if(d.add?.length){const add=(await validUsers(d.add)).filter(x=>!g.members.includes(x));if(g.members.length+add.length>50)throw bad('Max 50 members');if(add.length)up.members=FV.arrayUnion(...add);}
 else if(d.remove?.length){const rm=d.remove.filter(x=>g.members.includes(x)&&!g.admins.includes(x));if(rm.length)up.members=FV.arrayRemove(...rm);}
 if(d.makeAdmin&&g.members.includes(d.makeAdmin.uid)&&d.makeAdmin.uid!==a.uid)up.admins=d.makeAdmin.admin?FV.arrayUnion(d.makeAdmin.uid):FV.arrayRemove(d.makeAdmin.uid);
 if(Object.keys(up).length)await r.update(up);return{ok:true};});

exports.leaveGroup=fn.onCall(async(d,c)=>{const {a,r,g}=await grp(c,d.chatId);if(!g.members.includes(a.uid))throw deny();
 const members=g.members.filter(x=>x!==a.uid);let admins=g.admins.filter(x=>x!==a.uid);if(!admins.length&&members.length)admins=[members[0]];
 await r.update({members,admins});return{ok:true};});

exports.reportMessage=fn.onCall(async(d,c)=>{const a=await active(c);await limit(a.uid);const s=await db.doc('chats/'+d.chatId).get();
 if(!s.exists||!s.data().members.includes(a.uid))throw deny();await db.collection('reports').add({chatId:d.chatId,mid:String(d.mid),by:a.uid,reason:clean(d.reason,200),at:FV.serverTimestamp()});return{ok:true};});

exports.deleteMessage=fn.onCall(async(d,c)=>{const a=await active(c),r=db.doc(`chats/${d.chatId}/messages/${d.mid}`),m=await r.get();
 if(!m.exists)throw bad('Not found');
 if(d.keep){if(!isMod(a))throw deny();}
 else{if(m.data().from!==a.uid&&!isMod(a))throw deny();await r.update({deleted:true,text:'',imageUrl:null});await log('deleteMessage',a.uid,d.mid,d.chatId);}
 if(d.reportId&&isMod(a))await db.doc('reports/'+d.reportId).delete();return{ok:true};});

exports.deleteGroup=fn.onCall(async(d,c)=>{const a=await active(c);if(!isMod(a))throw deny();const r=db.doc('chats/'+d.chatId),s=await r.get();
 if(!s.exists||s.data().type!=='group')throw bad('Not a group');await db.recursiveDelete(r);await log('deleteGroup',a.uid,d.chatId);return{ok:true};});

exports.stats=fn.onCall(async(d,c)=>{const a=await active(c);if(!isMod(a))throw deny();
 const cnt=async q=>(await q.count().get()).data().count,st=(await admin.database().ref('status').once('value')).val()||{};
 let online=0;for(const u in st)if(Object.values(st[u].conns||{}).some(x=>x.state==='online'))online++;
 const users=await cnt(db.collection('users'));
 return{users,online,offline:users-online,chats:await cnt(db.collection('chats')),groups:await cnt(db.collection('chats').where('type','==','group')),suspended:await cnt(db.collection('users').where('suspended','==',true))};});
