/**
 * BD BLOOD DONATION - Cloud Functions
 * Server-Side Matching & Instant Push Notification Trigger
 * Project: bd-blood-dontion
 */

const functions = require('firebase-functions');
const admin = require('firebase-admin');

admin.initializeApp();

// Blood Compatibility Matrix
const BLOOD_COMPATIBILITY = {
  'A+': ['A+', 'A-', 'O+', 'O-'],
  'A-': ['A-', 'O-'],
  'B+': ['B+', 'B-', 'O+', 'O-'],
  'B-': ['B-', 'O-'],
  'AB+': ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'],
  'AB-': ['AB-', 'A-', 'B-', 'O-'],
  'O+': ['O+', 'O-'],
  'O-': ['O-']
};

/**
 * Triggered on every new blood request created in Firestore
 * 1. Matches available donors in the requested district
 * 2. Checks blood group compatibility
 * 3. Excludes requester & blocked users
 * 4. Dispatches FCM Push Notifications & creates in-app notifications
 */
exports.onBloodRequestCreated = functions.firestore
  .document('blood_requests/{requestId}')
  .onCreate(async (snap, context) => {
    const request = snap.data();
    const requestId = context.params.requestId;
    const db = admin.firestore();

    const {
      patientName,
      bloodGroup,
      hospitalName,
      division,
      district,
      upazila,
      isEmergency,
      requesterId
    } = request;

    try {
      // 1. Fetch available donors in the same district
      const donorsSnap = await db.collection('users')
        .where('district', '==', district)
        .where('isAvailable', '==', true)
        .limit(100)
        .get();

      if (donorsSnap.empty) {
        console.log(`[Matching] No available donors found in district: ${district}`);
        return null;
      }

      const acceptableDonorGroups = BLOOD_COMPATIBILITY[bloodGroup] || [bloodGroup];
      const eligibleTokens = [];
      const notifBatch = db.batch();

      donorsSnap.forEach((donorDoc) => {
        const donor = donorDoc.data();
        const donorId = donorDoc.id;

        // Skip requester
        if (donorId === requesterId) return;

        // Verify blood compatibility
        if (!acceptableDonorGroups.includes(donor.bloodGroup)) return;

        // Create In-App Notification in Firestore
        const notifRef = db.collection('notifications').doc();
        notifBatch.set(notifRef, {
          recipientId: donorId,
          requestId: requestId,
          requesterId: requesterId,
          type: isEmergency ? 'emergency_request' : 'matching_request',
          title: isEmergency ? '🚨 জরুরি রক্তের প্রয়োজন!' : '🩸 রক্তদানের অনুরোধ',
          message: `${bloodGroup} গ্রুপের রক্ত প্রয়োজন: ${hospitalName}`,
          bloodGroup: bloodGroup,
          hospitalName: hospitalName,
          district: district,
          upazila: upazila || '',
          isEmergency: Boolean(isEmergency),
          read: false,
          createdAt: admin.firestore.FieldValue.serverTimestamp()
        });

        // Collect FCM token if registered on user's profile
        if (donor.fcmToken) {
          eligibleTokens.push(donor.fcmToken);
        }
      });

      await notifBatch.commit();
      console.log(`[Matching] Notified eligible donors for request ${requestId}`);

      // 2. Send Multicast Push Notification via FCM
      if (eligibleTokens.length > 0) {
        const messagePayload = {
          notification: {
            title: isEmergency ? '🚨 জরুরি রক্তের প্রয়োজন!' : '🩸 জরুরি রক্তদানের আবেদন',
            body: `রোগী: ${patientName} | গ্রুপ: ${bloodGroup} | হাসপাতাল: ${hospitalName}`
          },
          data: {
            requestId: String(requestId),
            bloodGroup: String(bloodGroup),
            isEmergency: String(isEmergency)
          },
          tokens: eligibleTokens
        };

        const response = await admin.messaging().sendEachForMulticast(messagePayload);
        console.log(`[FCM] Sent: ${response.successCount} success, ${response.failureCount} failed.`);
      }

      return null;
    } catch (error) {
      console.error('[Blood Matching Function Error]:', error);
      return null;
    }
  });
