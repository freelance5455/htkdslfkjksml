const { onValueCreated } = require('firebase-functions/v2/database');
const admin = require('firebase-admin');

admin.initializeApp();

function collectTokens(node, out = []) {
  if (!node) return out;
  if (typeof node === 'string') {
    out.push(node);
  } else if (typeof node === 'object') {
    if (typeof node.token === 'string' && node.token) out.push(node.token);
    else Object.values(node).forEach(value => collectTokens(value, out));
  }
  return out;
}

exports.sendPushFromQueue = onValueCreated('/pushQueue/{id}', async (event) => {
  const data = event.data.val() || {};
  const snap = await admin.database().ref('fcmTokens').once('value');
  const tokens = [...new Set(collectTokens(snap.val() || {}))];

  if (!tokens.length) {
    await admin.database().ref(`pushQueue/${event.params.id}`).update({
      status: 'no_tokens',
      sentAt: Date.now(),
      successCount: 0,
      failureCount: 0
    });
    return null;
  }

  let successCount = 0;
  let failureCount = 0;
  const invalidTokens = [];

  // FCM multicast requests accept at most 500 registration tokens each.
  for (let start = 0; start < tokens.length; start += 500) {
    const batch = tokens.slice(start, start + 500);
    const message = {
      notification: {
        title: String(data.title || 'Vaishnav World'),
        body: String(data.text || data.body || 'New devotional update')
      },
      data: {
        type: String(data.type || 'general'),
        route: String(data.route || 'notifications')
      },
      tokens: batch
    };

    const result = await admin.messaging().sendEachForMulticast(message);
    successCount += result.successCount;
    failureCount += result.failureCount;

    result.responses.forEach((response, index) => {
      if (!response.success) {
        const code = response.error && response.error.code || '';
        if (
          code.includes('registration-token-not-registered') ||
          code.includes('invalid-registration-token')
        ) {
          invalidTokens.push(batch[index]);
        }
      }
    });
  }

  // Remove only invalid/unregistered tokens; keep tokens for temporary errors.
  if (invalidTokens.length) {
    const all = snap.val() || {};
    const invalidSet = new Set(invalidTokens);
    for (const [key, value] of Object.entries(all)) {
      const token = typeof value === 'string' ? value : value && value.token;
      if (token && invalidSet.has(token)) {
        await admin.database().ref(`fcmTokens/${key}`).remove();
      }
    }
  }

  await admin.database().ref(`pushQueue/${event.params.id}`).update({
    status: 'sent',
    sentAt: Date.now(),
    successCount,
    failureCount,
    deviceCount: tokens.length
  });
  return null;
});
