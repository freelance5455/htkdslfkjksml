/**
 * Cloud Functions para La Conquista Medieval - Paso 1
 * Sincronización de batallas pactadas, liquidación de desafíos y arbitraje feudal en Firestore.
 */

const { onSchedule } = require('firebase-functions/v2/scheduler');
const { onDocumentUpdated, onDocumentCreated } = require('firebase-functions/v2/firestore');
const { onRequest } = require('firebase-functions/v2/https');
const admin = require('firebase-admin');

if (!admin.apps.length) {
  admin.initializeApp();
}

const db = admin.firestore();

// Ponderaciones militares para el motor de batalla en servidor
const UNIT_STATS = {
  militia: { attack: 12, defense: 14, cost: 25 },
  swordsman: { attack: 28, defense: 22, cost: 65 },
  archer: { attack: 35, defense: 10, cost: 80 },
  crossbowman: { attack: 45, defense: 16, cost: 110 },
  lightCavalry: { attack: 55, defense: 25, cost: 140 },
  knight: { attack: 85, defense: 60, cost: 250 },
  batteringRam: { attack: 70, defense: 50, cost: 300 },
  catapult: { attack: 110, defense: 30, cost: 450 },
};

/**
 * Calcula el poder militar de un contingente
 */
function calculatePower(army = {}) {
  let power = 0;
  for (const [unit, count] of Object.entries(army)) {
    if (UNIT_STATS[unit] && count > 0) {
      power += UNIT_STATS[unit].attack * count;
    }
  }
  return Math.max(10, power);
}

/**
 * Resuelve una contienda militar pactada entre atacante y defensor
 */
function simulateBattle(challengerKingdom, defenderKingdom, goldStake = 100) {
  const cArmy = challengerKingdom.army || { militia: 25 };
  const dArmy = defenderKingdom.army || { militia: 25 };

  const wallBonus = 1 + ((defenderKingdom.buildings?.wall || 1) * 0.08);
  const attackerPower = calculatePower(cArmy) * (0.85 + Math.random() * 0.3);
  const defenderPower = calculatePower(dArmy) * wallBonus * (0.85 + Math.random() * 0.3);

  const victory = attackerPower >= defenderPower;
  const ratio = victory ? attackerPower / defenderPower : defenderPower / attackerPower;

  const attackerCasualties = {};
  const defenderCasualties = {};

  for (const [unit, count] of Object.entries(cArmy)) {
    if (count > 0) {
      const lossRate = victory ? Math.min(0.35, 0.2 / Math.sqrt(ratio)) : Math.min(0.65, 0.45 * ratio);
      const losses = Math.round(count * lossRate);
      if (losses > 0) attackerCasualties[unit] = losses;
    }
  }

  for (const [unit, count] of Object.entries(dArmy)) {
    if (count > 0) {
      const lossRate = victory ? Math.min(0.65, 0.45 * ratio) : Math.min(0.35, 0.2 / Math.sqrt(ratio));
      const losses = Math.round(count * lossRate);
      if (losses > 0) defenderCasualties[unit] = losses;
    }
  }

  const gloryGained = Math.round(Math.max(35, (victory ? 120 : 30) * Math.min(1.8, ratio)));

  return {
    victory,
    attackerPower: Math.round(attackerPower),
    defenderPower: Math.round(defenderPower),
    attackerCasualties,
    defenderCasualties,
    goldTransferred: victory ? goldStake : -goldStake,
    gloryGained,
    resolvedAt: Date.now(),
    summary: victory
      ? `Victoria del Reino ${challengerKingdom.kingdomName}. Sus mesnadas doblegaron a la guarnición de ${defenderKingdom.kingdomName}.`
      : `Defensa triunfal del Reino ${defenderKingdom.kingdomName}. El asalto pactado por ${challengerKingdom.kingdomName} fue repelido con firmeza.`,
  };
}

/**
 * 1. Tarea Programada: Arbitraje y Ejecución de Batallas PvP pactadas vencidas
 * Se ejecuta automáticamente cada 5 minutos para procesar desafíos pendientes de liza
 */
exports.resolveDuePvPChallenges = onSchedule('every 5 minutes', async (event) => {
  const now = Date.now();
  console.log(`[PvP Arbiter] Comprobando batallas acordadas vencidas al timestamp: ${now}`);

  try {
    const dueSnapshot = await db
      .collection('pvp_challenges')
      .where('status', '==', 'accepted')
      .where('scheduledTime', '<=', now)
      .limit(50)
      .get();

    if (dueSnapshot.empty) {
      console.log('[PvP Arbiter] No hay batallas pendientes de resolución.');
      return;
    }

    console.log(`[PvP Arbiter] Se encontraron ${dueSnapshot.size} batallas para dirimir.`);

    for (const docSnap of dueSnapshot.docs) {
      const challenge = docSnap.data();
      const challengeId = docSnap.id;

      try {
        const [cSnap, dSnap] = await Promise.all([
          db.collection('kingdoms').doc(challenge.challengerId).get(),
          db.collection('kingdoms').doc(challenge.defenderId).get(),
        ]);

        const cData = cSnap.exists ? cSnap.data() : { kingdomName: challenge.challengerKingdomName, army: { militia: 20 } };
        const dData = dSnap.exists ? dSnap.data() : { kingdomName: challenge.defenderKingdomName, army: { militia: 20 } };

        const report = simulateBattle(cData, dData, challenge.goldStake || 100);

        // Actualizar el documento de desafío con el resultado
        await db.collection('pvp_challenges').doc(challengeId).update({
          status: 'completed',
          battleReport: report,
          resolvedAt: now,
          updatedAt: now,
        });

        // Actualizar arcas y gloria en ambos reinos en lote
        const batch = db.batch();
        if (cSnap.exists) {
          const cRef = db.collection('kingdoms').doc(challenge.challengerId);
          const newGold = Math.max(0, (cData.resources?.gold || 0) + report.goldTransferred);
          const newGlory = Math.max(0, (cData.gloryPoints || 0) + (report.victory ? report.gloryGained : -20));
          batch.update(cRef, {
            'resources.gold': newGold,
            gloryPoints: newGlory,
            lastUpdated: now,
          });
        }

        if (dSnap.exists) {
          const dRef = db.collection('kingdoms').doc(challenge.defenderId);
          const newGold = Math.max(0, (dData.resources?.gold || 0) - report.goldTransferred);
          const newGlory = Math.max(0, (dData.gloryPoints || 0) + (!report.victory ? report.gloryGained : -20));
          batch.update(dRef, {
            'resources.gold': newGold,
            gloryPoints: newGlory,
            lastUpdated: now,
          });
        }

        await batch.commit();
        console.log(`[PvP Arbiter] Batalla ${challengeId} dirimida exitosamente.`);
      } catch (err) {
        console.error(`[PvP Arbiter] Error resolviendo batalla ${challengeId}:`, err);
      }
    }
  } catch (error) {
    console.error('[PvP Arbiter] Error en la consulta de batallas:', error);
  }
});

/**
 * 2. Tarea Programada: Caducidad de desafíos diplomáticos sin respuesta
 * Cancela desafíos en estado 'pending' cuyo plazo de respuesta ha expirado
 */
exports.expireStaleChallenges = onSchedule('every 30 minutes', async (event) => {
  const now = Date.now();
  try {
    const expiredSnap = await db
      .collection('pvp_challenges')
      .where('status', '==', 'pending')
      .where('scheduledTime', '<=', now)
      .limit(30)
      .get();

    if (!expiredSnap.empty) {
      const batch = db.batch();
      expiredSnap.forEach((docSnap) => {
        batch.update(docSnap.ref, {
          status: 'declined',
          replyMessage: 'El desafío expiró sin respuesta del soberano convocado.',
          updatedAt: now,
        });
      });
      await batch.commit();
      console.log(`[PvP Arbiter] Se marcaron ${expiredSnap.size} desafíos caducados como declinados.`);
    }
  } catch (err) {
    console.error('[PvP Arbiter] Error caducando desafíos:', err);
  }
});

/**
 * 3. Endpoint HTTP: Tiempo y Estado del Servidor Feudal
 */
exports.getFeudalServerStatus = onRequest({ cors: true }, (req, res) => {
  const now = new Date();
  const year = 1085 + (now.getFullYear() - 2026);
  res.status(200).json({
    ok: true,
    serverTimestamp: now.getTime(),
    feudalDate: `Año Feudal ${year}`,
    isoDate: now.toISOString(),
    status: 'Corona de Hispania Operativa',
  });
});
