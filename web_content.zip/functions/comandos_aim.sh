#!/bin/bash
# Comandos AIM - Melhor precisão de mira / resposta de toque
# Para Brevent / Termux / ADB
# Todos com 2>/dev/null || true

echo "Aplicando comandos de AIM (sensibilidade + resposta de toque)..."

# === Velocidade e sensibilidade do ponteiro/toque ===
settings put system pointer_speed 7 2>/dev/null || true
settings put system touch_slop 2 2>/dev/null || true
settings put system view.touch_slop 2 2>/dev/null || true
settings put system touch_sensitivity 1.5 2>/dev/null || true
settings put system MovementSpeedRatio 1.5 2>/dev/null || true
settings put system ZoomSpeedRatio 1.5 2>/dev/null || true

# === Tempo de resposta (clique mais rápido) ===
settings put secure long_press_timeout 150 2>/dev/null || true
settings put secure multi_press_timeout 80 2>/dev/null || true
settings put system multi_press_timeout 80 2>/dev/null || true
settings put system pointer_gesture_duration 25 2>/dev/null || true

# === Calibração de toque (mais precisão) ===
settings put system touch.pressure.scale 0.001 2>/dev/null || true
settings put system touch.size.calibration geometric 2>/dev/null || true
settings put system touch.size.scale 1.5 2>/dev/null || true
settings put system touch.size.bias 0 2>/dev/null || true

# === Reduzir lag de input (ajuda na mira) ===
settings put global window_animation_scale 0 2>/dev/null || true
settings put global transition_animation_scale 0 2>/dev/null || true
settings put global animator_duration_scale 0 2>/dev/null || true
settings put global force_gpu_rendering 1 2>/dev/null || true
settings put global disable_hw_overlays 1 2>/dev/null || true

# === Outros ajustes de resposta ===
settings put system SwipeTransitionAngleCosine 0.5 2>/dev/null || true
settings put system DragMinSwitchSpeed 99999.0px/s 2>/dev/null || true
settings put system SwipeMaxWidthRatio 1 2>/dev/null || true
settings put system ro.min.fling_velocity 8000 2>/dev/null || true
settings put system min_fling_velocity 8000 2>/dev/null || true

# === Boost de toque (se o aparelho aceitar) ===
settings put system touch_response_boost 1 2>/dev/null || true
settings put system game_touchscreen_boost 1 2>/dev/null || true
settings put system touch_sampling_rate 1 2>/dev/null || true

echo "Comandos de AIM aplicados!"
echo "Reinicie o celular e teste a mira no jogo."
echo "Combine com o arquivo otimizacao_gaming.sh para melhor resultado."
