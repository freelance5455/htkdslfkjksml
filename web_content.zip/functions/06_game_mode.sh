#!/system/bin/sh
if cmd game help >/dev/null 2>&1; then exit 0; fi
exit 1
