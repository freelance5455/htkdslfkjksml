#!/system/bin/sh
echo "TM Otimizações"
echo "Modelo: $(getprop ro.product.model)"
echo "Fabricante: $(getprop ro.product.manufacturer)"
echo "Android: $(getprop ro.build.version.release)"
echo "SDK: $(getprop ro.build.version.sdk)"
echo "ABI: $(getprop ro.product.cpu.abi)"
