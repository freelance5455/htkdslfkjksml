#!/system/bin/sh
cmd power help 2>&1 | grep -q 'set-fixed-performance-mode-enabled'
