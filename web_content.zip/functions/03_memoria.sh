#!/system/bin/sh
# A limpeza é opcional e conservadora; não mata aplicativos aleatoriamente.
cmd activity trim-caches >/dev/null 2>&1 || true
pm trim-caches 512M >/dev/null 2>&1 || true
