import fs from 'fs';
import path from 'path';
import { PNG } from 'pngjs';

const publicDir = path.resolve(process.cwd(), 'public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

// 1. Create Brand SVG: public/icon.svg
const svgContent = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <linearGradient id="bgGrad" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#141414" />
      <stop offset="50%" stop-color="#0a0a0a" />
      <stop offset="100%" stop-color="#050505" />
    </linearGradient>
    <linearGradient id="goldGrad" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#fde68a" />
      <stop offset="30%" stop-color="#f59e0b" />
      <stop offset="70%" stop-color="#d97706" />
      <stop offset="100%" stop-color="#b45309" />
    </linearGradient>
    <linearGradient id="goldAccent" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#fffbeb" />
      <stop offset="100%" stop-color="#f59e0b" />
    </linearGradient>
    <radialGradient id="goldGlow" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#f59e0b" stop-opacity="0.3" />
      <stop offset="100%" stop-color="#f59e0b" stop-opacity="0" />
    </radialGradient>
    <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="0" dy="12" stdDeviation="16" flood-color="#000000" flood-opacity="0.8" />
      <feDropShadow dx="0" dy="0" stdDeviation="24" flood-color="#f59e0b" flood-opacity="0.25" />
    </filter>
  </defs>

  <!-- Background -->
  <rect width="512" height="512" rx="112" fill="url(#bgGrad)" />
  <rect width="510" height="510" x="1" y="1" rx="111" fill="none" stroke="#f59e0b" stroke-width="2" stroke-opacity="0.25" />
  
  <!-- Ambient Glow -->
  <circle cx="256" cy="256" r="210" fill="url(#goldGlow)" />

  <!-- Shield / Hexagon Shape -->
  <g filter="url(#shadow)">
    <!-- Outer Shield Border -->
    <path d="M 256 70 L 400 135 L 400 280 C 400 375 256 445 256 445 C 256 445 112 375 112 280 L 112 135 Z" 
          fill="#121214" stroke="url(#goldGrad)" stroke-width="7" stroke-linejoin="round" />
    
    <!-- Inner Shield Accent -->
    <path d="M 256 86 L 384 144 L 384 274 C 384 357 256 422 256 422 C 256 422 128 357 128 274 L 128 144 Z" 
          fill="#0c0c0e" stroke="#f59e0b" stroke-width="1.5" stroke-opacity="0.4" stroke-linejoin="round" />

    <!-- Crown / Apex Element -->
    <path d="M 226 128 L 256 108 L 286 128 L 274 142 L 238 142 Z" fill="url(#goldAccent)" />
    <circle cx="256" cy="98" r="6" fill="#fde68a" />
    <circle cx="220" cy="118" r="4.5" fill="#f59e0b" />
    <circle cx="292" cy="118" r="4.5" fill="#f59e0b" />

    <!-- Monogram 'M' with Architectural Lines -->
    <path d="M 180 340 L 180 185 L 225 185 L 256 270 L 287 185 L 332 185 L 332 340 L 298 340 L 298 238 L 268 318 L 244 318 L 214 238 L 214 340 Z" 
          fill="url(#goldGrad)" />
    
    <!-- Empire Sparkle Accents -->
    <polygon points="256,346 261,360 275,365 261,370 256,384 251,370 237,365 251,360" fill="url(#goldAccent)" />
    <polygon points="196,160 198,166 204,168 198,170 196,176 194,170 188,168 194,166" fill="#fde68a" />
    <polygon points="316,160 318,166 324,168 318,170 316,176 314,170 308,168 314,166" fill="#fde68a" />
  </g>
</svg>`;

fs.writeFileSync(path.join(publicDir, 'icon.svg'), svgContent, 'utf-8');
console.log('Created icon.svg');

// Helper to draw a rich gold/black icon onto PNG buffer
function createIconPNG(size: number, isMaskable: boolean): Buffer {
  const png = new PNG({ width: size, height: size });
  
  // Background parameters
  const cx = size / 2;
  const cy = size / 2;
  // If maskable, Android requires 10-15% safe padding. Scale factor:
  const scale = isMaskable ? 0.72 : 0.88;
  const cornerRadius = isMaskable ? 0 : size * 0.22; // rounded for non-maskable or flat bleed for maskable

  // Colors
  const bgDark1 = [18, 18, 20];
  const bgDark2 = [8, 8, 10];
  const goldLight = [253, 230, 138];
  const goldMid = [245, 158, 11];
  const goldDark = [180, 83, 9];
  const goldShine = [255, 251, 235];

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const idx = (size * y + x) << 2;
      
      // Rounded corner check for standard icon
      if (!isMaskable) {
        let inside = true;
        const r = cornerRadius;
        if (x < r && y < r) {
          inside = (x - r) ** 2 + (y - r) ** 2 <= r * r;
        } else if (x > size - r && y < r) {
          inside = (x - (size - r)) ** 2 + (y - r) ** 2 <= r * r;
        } else if (x < r && y > size - r) {
          inside = (x - r) ** 2 + (y - (size - r)) ** 2 <= r * r;
        } else if (x > size - r && y > size - r) {
          inside = (x - (size - r)) ** 2 + (y - (size - r)) ** 2 <= r * r;
        }
        if (!inside) {
          png.data[idx] = 0;
          png.data[idx + 1] = 0;
          png.data[idx + 2] = 0;
          png.data[idx + 3] = 0;
          continue;
        }
      }

      // Base background: radial subtle glow + subtle gradient
      const normY = y / size;
      const distFromCenter = Math.sqrt((x - cx) ** 2 + (y - cy) ** 2) / (size * 0.5);
      
      let r = bgDark1[0] * (1 - normY) + bgDark2[0] * normY;
      let g = bgDark1[1] * (1 - normY) + bgDark2[1] * normY;
      let b = bgDark1[2] * (1 - normY) + bgDark2[2] * normY;

      // Subtle ambient gold warmth in center
      if (distFromCenter < 1.0) {
        const glow = (1 - distFromCenter) * 0.18;
        r += goldMid[0] * glow;
        g += goldMid[1] * glow;
        b += goldMid[2] * glow;
      }

      // Normalized coordinates within scaled emblem area (-1 to 1)
      const nx = (x - cx) / (cx * scale);
      const ny = (y - cy) / (cy * scale);

      // Render Shield boundary
      // Upper flat/slant: ny >= -0.7 + Math.abs(nx) * 0.25
      // Side: Math.abs(nx) <= 0.65
      // Bottom tapered curve: ny <= 0.85 - (nx * nx) * 0.9
      const insideShieldOuter = 
        Math.abs(nx) <= 0.65 &&
        ny >= -0.72 + Math.abs(nx) * 0.25 &&
        (ny <= 0.25 || ny <= 0.85 - (Math.abs(nx) / 0.65) * 0.6);

      const insideShieldInner = 
        Math.abs(nx) <= 0.57 &&
        ny >= -0.64 + Math.abs(nx) * 0.23 &&
        (ny <= 0.22 || ny <= 0.77 - (Math.abs(nx) / 0.57) * 0.55);

      if (insideShieldOuter) {
        if (!insideShieldInner) {
          // Gold metallic shield rim
          const goldFactor = (nx + ny + 1.5) / 3;
          r = goldLight[0] * (1 - goldFactor) + goldMid[0] * goldFactor;
          g = goldLight[1] * (1 - goldFactor) + goldMid[1] * goldFactor;
          b = goldLight[2] * (1 - goldFactor) + goldMid[2] * goldFactor;
        } else {
          // Shield body: deep obsidian black
          r = 12;
          g = 12;
          b = 14;

          // Inside the shield: Draw Monogram 'M'
          // Standardized 'M' geometry in nx [-0.42, 0.42], ny [-0.3, 0.45]
          const inMBox = Math.abs(nx) <= 0.42 && ny >= -0.32 && ny <= 0.45;
          if (inMBox) {
            const absX = Math.abs(nx);
            // Left & right pillars
            const isPillar = absX >= 0.27 && absX <= 0.42;
            
            // Diagonals towards center
            // Line from (0.35, -0.32) to (0.0, 0.18)
            // Distance to diagonal segment
            const targetX = (0.18 - ny) * (0.34 / 0.50);
            const isDiagonal = ny >= -0.32 && ny <= 0.18 && Math.abs(absX - targetX) <= 0.075;

            if (isPillar || isDiagonal) {
              // Rich multi-stop gold gradient with highlight
              const mGradient = (nx * 0.7 + ny * 0.3 + 0.5);
              r = goldLight[0] * (1 - mGradient) + goldMid[0] * mGradient;
              g = goldLight[1] * (1 - mGradient) + goldMid[1] * mGradient;
              b = goldLight[2] * (1 - mGradient) + goldMid[2] * mGradient;

              // Top highlight bevel
              if (ny < -0.28) {
                r = goldShine[0];
                g = goldShine[1];
                b = goldShine[2];
              }
            }
          }

          // Crown jewel on top apex of shield
          if (Math.abs(nx) <= 0.08 && ny >= -0.58 && ny <= -0.42) {
            r = goldLight[0];
            g = goldLight[1];
            b = goldLight[2];
          }
          // Center diamond star below M
          if (Math.abs(nx) + Math.abs(ny - 0.58) <= 0.05) {
            r = goldShine[0];
            g = goldShine[1];
            b = goldShine[2];
          }
        }
      }

      // Border outline for non-maskable icons
      if (!isMaskable) {
        const borderDist = Math.min(x, y, size - 1 - x, size - 1 - y);
        if (borderDist <= 2) {
          r = r * 0.7 + goldMid[0] * 0.3;
          g = g * 0.7 + goldMid[1] * 0.3;
          b = b * 0.7 + goldMid[2] * 0.3;
        }
      }

      png.data[idx] = Math.min(255, Math.max(0, Math.round(r)));
      png.data[idx + 1] = Math.min(255, Math.max(0, Math.round(g)));
      png.data[idx + 2] = Math.min(255, Math.max(0, Math.round(b)));
      png.data[idx + 3] = 255;
    }
  }

  return PNG.sync.write(png);
}

// Generate all required icons
const icon192 = createIconPNG(192, false);
fs.writeFileSync(path.join(publicDir, 'pwa-192x192.png'), icon192);
console.log('Created pwa-192x192.png');

const icon512 = createIconPNG(512, false);
fs.writeFileSync(path.join(publicDir, 'pwa-512x512.png'), icon512);
console.log('Created pwa-512x512.png');

const iconMaskable512 = createIconPNG(512, true);
fs.writeFileSync(path.join(publicDir, 'pwa-maskable-512x512.png'), iconMaskable512);
console.log('Created pwa-maskable-512x512.png');

const iconApple180 = createIconPNG(180, false);
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), iconApple180);
console.log('Created apple-touch-icon.png');

// Also create favicon.png (64x64) and favicon.ico
const icon64 = createIconPNG(64, false);
fs.writeFileSync(path.join(publicDir, 'favicon.png'), icon64);
fs.writeFileSync(path.join(publicDir, 'favicon.ico'), icon64);
console.log('Created favicon.png & favicon.ico');

console.log('All icons successfully created in /public!');
