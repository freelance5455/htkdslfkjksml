import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';

const rootDir = process.cwd();
const rootFolderName = 'money-making-empire-ai-website-builder';
const zipFileName = 'money-making-empire-ai-website-builder.zip';

// Patterns to exclude completely
const EXCLUDE_DIRS = new Set([
  'node_modules',
  '.git',
  'dist',
  'build',
  '.gradle',
  '.idea',
  'coverage',
  '.cache'
]);

const EXCLUDE_FILES = new Set([
  'money-making-empire-ai-website-builder.zip',
  'money-making-empire-website-builder.zip',
  'server.js',
  '.env',
  '.env.local'
]);

function shouldExclude(relativePath: string): boolean {
  const parts = relativePath.split(path.sep);

  for (const part of parts) {
    if (EXCLUDE_DIRS.has(part)) {
      return true;
    }
  }

  const fileName = parts[parts.length - 1];
  if (EXCLUDE_FILES.has(fileName)) {
    return true;
  }

  // Exclude logs, zip archives, DS_Store, tmp files
  if (
    fileName.endsWith('.zip') ||
    fileName.endsWith('.log') ||
    fileName === '.DS_Store' ||
    fileName.endsWith('.tmp')
  ) {
    return true;
  }

  // In android directory, exclude build outputs and caches
  if (
    relativePath.includes('android/build') ||
    relativePath.includes('android/app/build') ||
    relativePath.includes('android/.gradle')
  ) {
    return true;
  }

  return false;
}

function getAllFiles(dir: string, fileList: string[] = []): string[] {
  const entries = fs.readdirSync(dir, { withFileTypes: true });

  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    const relPath = path.relative(rootDir, fullPath);

    if (shouldExclude(relPath)) {
      continue;
    }

    if (entry.isDirectory()) {
      getAllFiles(fullPath, fileList);
    } else if (entry.isFile()) {
      fileList.push(relPath);
    }
  }

  return fileList;
}

async function packageZip() {
  console.log('Collecting project files...');
  const files = getAllFiles(rootDir);
  console.log(`Found ${files.length} project files to package.`);

  const zip = new JSZip();

  for (const relPath of files) {
    const fullPath = path.join(rootDir, relPath);
    const data = fs.readFileSync(fullPath);

    // Normalize path separators to forward slash for zip specification
    const zipPath = `${rootFolderName}/${relPath.split(path.sep).join('/')}`;

    // Preserve permissions if executable (e.g. gradlew)
    const stat = fs.statSync(fullPath);
    const isExecutable = Boolean(stat.mode & 0o111);

    zip.file(zipPath, data, {
      date: stat.mtime,
      unixPermissions: isExecutable ? 0o755 : 0o644
    });
  }

  console.log('Generating ZIP archive with DEFLATE compression...');
  const zipBuffer = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 9 },
  });

  const outputRootPath = path.join(rootDir, zipFileName);
  fs.writeFileSync(outputRootPath, zipBuffer);
  console.log(`Saved: ${outputRootPath} (${(zipBuffer.length / 1024 / 1024).toFixed(2)} MB)`);

  // Also copy to public/ so it can be directly downloaded in browser/phone
  const publicDir = path.join(rootDir, 'public');
  if (!fs.existsSync(publicDir)) {
    fs.mkdirSync(publicDir, { recursive: true });
  }
  const publicPath = path.join(publicDir, zipFileName);
  fs.writeFileSync(publicPath, zipBuffer);
  console.log(`Saved to public downloads: ${publicPath}`);

  console.log('Packaging complete!');
}

packageZip().catch((err) => {
  console.error('Error packaging zip:', err);
  process.exit(1);
});
