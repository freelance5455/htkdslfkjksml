# Money Making Empire — AI Website Builder (Android & Web)

Private internal enterprise application for building high-converting, premium client-ready business websites with live visual editor, real-time preview, AI styling, and Android APK compilation.

## Project Structure
- `android/` - Full native Capacitor Android project (Gradle, manifests, mipmap icons, splash screens)
- `src/` - React 19 + TypeScript application source code
- `public/` - Web assets, PWA icons (192, 512, maskable), manifest, and apple-touch-icon
- `.github/workflows/build-android.yml` - Automated GitHub Actions workflow to build release APK
- `capacitor.config.json` - Capacitor configuration (`com.moneymakingempire.websitebuilder`)
- `package.json` - Dependencies and build scripts

## Requirements
- Node.js 20+ or 22+
- npm or bun

## Setup & Running Locally
```bash
# 1. Install dependencies
npm install --legacy-peer-deps

# 2. Run local development server
npm run dev

# 3. Build production web bundle
npm run build
```

## Android APK Compilation via Capacitor
```bash
# 1. Build web app and sync with Android native wrapper
npm run build
npx cap sync android

# 2. Open in Android Studio
npx cap open android

# Or build release APK via Gradle command line:
cd android
./gradlew assembleRelease
```
The output APK is generated at:
`android/app/build/outputs/apk/release/app-release.apk` (or `app-release-unsigned.apk`)

## Automated GitHub Actions APK Build
1. Push this repository to your **private** GitHub account.
2. Go to the **Actions** tab on GitHub and run the **Build Android APK** workflow.
3. Once completed, download the release APK artifact directly from GitHub Actions.
