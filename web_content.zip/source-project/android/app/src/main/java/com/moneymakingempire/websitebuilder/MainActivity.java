package com.moneymakingempire.websitebuilder;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
