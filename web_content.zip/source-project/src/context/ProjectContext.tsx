import React, { createContext, useContext, useState, useEffect } from 'react';
import { WebsiteProject, ProjectStatus, AssetItem, QualityReport } from '../types/website';
import { TEMPLATE_CATALOG } from '../data/templateCatalog';
import { runQualityAudit } from '../services/qualityChecker';
import { aiProvider, AIProviderStatus } from '../services/aiProvider';
import { ensureMultiPageProject } from '../utils/multiPageBuilder';

interface ProjectContextType {
  projects: WebsiteProject[];
  activeProject: WebsiteProject | null;
  activeView: 'dashboard' | 'wizard' | 'editor' | 'projects' | 'templates' | 'assets' | 'deployment' | 'handoff' | 'settings';
  setActiveView: (view: 'dashboard' | 'wizard' | 'editor' | 'projects' | 'templates' | 'assets' | 'deployment' | 'handoff' | 'settings') => void;
  setActiveProject: (project: WebsiteProject | null) => void;
  createProject: (newProject: WebsiteProject) => void;
  updateProject: (updated: WebsiteProject) => void;
  duplicateProject: (projectId: string, newName?: string, newClient?: string) => WebsiteProject;
  deleteProject: (projectId: string) => void;
  updateProjectStatus: (projectId: string, status: ProjectStatus) => void;
  auditActiveProject: () => QualityReport | null;
  assets: AssetItem[];
  addAsset: (asset: Omit<AssetItem, 'id' | 'createdAt'>) => void;
  updateAsset: (asset: AssetItem) => void;
  deleteAsset: (assetId: string) => void;
  aiStatus: AIProviderStatus;
  refreshAiStatus: () => void;
}

const ProjectContext = createContext<ProjectContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY = 'mme_website_projects_v1';
const ASSETS_STORAGE_KEY = 'mme_website_assets_v1';

const INITIAL_ASSETS: AssetItem[] = [
  {
    id: 'ast-1',
    name: 'Modern Architectural Studio Facade',
    url: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80',
    altText: 'Glass and steel commercial corporate tower against clear sky',
    category: 'hero',
    dimensions: '1200x800',
    origin: 'stock_licensed',
    format: 'webp',
    license: 'Unsplash Commercial License',
    fileSize: '320 KB',
    aspectRatio: '16:9',
    createdAt: '2026-09-20T10:00:00.000Z',
  },
  {
    id: 'ast-2',
    name: 'Private Clinical Sanctuary Suite',
    url: 'https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&w=1200&q=80',
    altText: 'Boutique minimalist dental operatory with natural lighting',
    category: 'facility',
    dimensions: '1200x800',
    origin: 'stock_licensed',
    format: 'webp',
    license: 'Unsplash Commercial License',
    fileSize: '290 KB',
    aspectRatio: '16:9',
    createdAt: '2026-09-21T10:00:00.000Z',
  },
  {
    id: 'ast-3',
    name: 'Culinary Wood-Fired Plating',
    url: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=1200&q=80',
    altText: 'Fine dining contemporary tasting course over cedar embers',
    category: 'hero',
    dimensions: '1200x800',
    origin: 'stock_licensed',
    format: 'webp',
    license: 'Unsplash Commercial License',
    fileSize: '340 KB',
    aspectRatio: '16:9',
    createdAt: '2026-09-22T10:00:00.000Z',
  },
  {
    id: 'ast-4',
    name: 'Architectural Shingle Roofing Installation',
    url: 'https://images.unsplash.com/photo-1632759145351-1d592919f522?auto=format&fit=crop&w=1200&q=80',
    altText: 'Contractor installing high-definition asphalt roof shingles',
    category: 'service',
    dimensions: '1200x800',
    origin: 'stock_licensed',
    format: 'webp',
    license: 'Unsplash Commercial License',
    fileSize: '310 KB',
    aspectRatio: '16:9',
    createdAt: '2026-09-23T10:00:00.000Z',
  },
  {
    id: 'ast-5',
    name: 'Executive Partner Consultation Room',
    url: 'https://images.unsplash.com/photo-1497215728101-856f4ea42174?auto=format&fit=crop&w=1200&q=80',
    altText: 'Minimalist creative agency meeting conference room',
    category: 'facility',
    dimensions: '1200x800',
    origin: 'stock_licensed',
    format: 'webp',
    license: 'Unsplash Commercial License',
    fileSize: '280 KB',
    aspectRatio: '16:9',
    createdAt: '2026-09-24T10:00:00.000Z',
  },
];

export const ProjectProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [projects, setProjects] = useState<WebsiteProject[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed.map(ensureMultiPageProject);
        }
      }
    } catch (e) {
      console.warn('Failed to load projects from storage:', e);
    }
    // Initialize with our 5 realistic high-caliber templates
    return TEMPLATE_CATALOG.map((t) => ensureMultiPageProject(t.initialProject));
  });

  const [activeProjectId, setActiveProjectId] = useState<string>(() => {
    return projects[0]?.id || '';
  });

  const [activeView, setActiveView] = useState<'dashboard' | 'wizard' | 'editor' | 'projects' | 'templates' | 'assets' | 'deployment' | 'handoff' | 'settings'>('dashboard');

  const [assets, setAssets] = useState<AssetItem[]>(() => {
    try {
      const saved = localStorage.getItem(ASSETS_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {}
    return INITIAL_ASSETS;
  });

  const [aiStatus, setAiStatus] = useState<AIProviderStatus>({
    configured: false,
    model: 'gemini-3.8-flash',
    mode: 'demo',
    provider: 'Money Making Empire AI Engine',
  });

  const refreshAiStatus = async () => {
    const status = await aiProvider.checkStatus();
    setAiStatus(status);
  };

  useEffect(() => {
    refreshAiStatus();
  }, []);

  // Sync projects to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(projects));
    } catch (e) {
      console.warn('Failed to save projects to localStorage:', e);
    }
  }, [projects]);

  // Sync assets to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(ASSETS_STORAGE_KEY, JSON.stringify(assets));
    } catch (e) {
      console.warn('Failed to save assets to localStorage:', e);
    }
  }, [assets]);

  const rawActive = projects.find((p) => p.id === activeProjectId) || projects[0] || null;
  const activeProject = rawActive ? ensureMultiPageProject(rawActive) : null;

  const setActiveProject = (project: WebsiteProject | null) => {
    if (project) {
      setActiveProjectId(project.id);
    }
  };

  const createProject = (newProject: WebsiteProject) => {
    const multiPaged = ensureMultiPageProject(newProject);
    const auditedReport = runQualityAudit(multiPaged);
    const projectWithAudit = {
      ...multiPaged,
      qualityReport: auditedReport,
      updatedAt: new Date().toISOString(),
    };
    setProjects((prev) => [projectWithAudit, ...prev]);
    setActiveProjectId(projectWithAudit.id);
    setActiveView('editor');
  };

  const updateProject = (updated: WebsiteProject) => {
    const auditedReport = runQualityAudit(updated);
    const finalized = {
      ...updated,
      qualityReport: auditedReport,
      updatedAt: new Date().toISOString(),
    };
    setProjects((prev) => prev.map((p) => (p.id === finalized.id ? finalized : p)));
  };

  const duplicateProject = (projectId: string, newName?: string, newClient?: string): WebsiteProject => {
    const target = projects.find((p) => p.id === projectId);
    if (!target) throw new Error('Target project not found');

    const clonedId = `prj-${Date.now()}`;
    const duplicated: WebsiteProject = {
      ...JSON.parse(JSON.stringify(target)),
      id: clonedId,
      name: newName || `${target.name} (Copy)`,
      clientName: newClient || `${target.clientName} (New Client)`,
      status: 'draft',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      deployment: {
        ...target.deployment,
        customDomain: '',
        deploymentUrl: `https://${clonedId.slice(0, 16)}.empire-preview.app`,
        verified: false,
        httpsActive: true,
        dnsStatus: 'not_configured',
      },
    };

    duplicated.qualityReport = runQualityAudit(duplicated);

    setProjects((prev) => [duplicated, ...prev]);
    setActiveProjectId(clonedId);
    return duplicated;
  };

  const deleteProject = (projectId: string) => {
    setProjects((prev) => prev.filter((p) => p.id !== projectId));
    if (activeProjectId === projectId) {
      const remaining = projects.filter((p) => p.id !== projectId);
      if (remaining.length > 0) {
        setActiveProjectId(remaining[0].id);
      }
    }
  };

  const updateProjectStatus = (projectId: string, status: ProjectStatus) => {
    setProjects((prev) =>
      prev.map((p) => (p.id === projectId ? { ...p, status, updatedAt: new Date().toISOString() } : p))
    );
  };

  const auditActiveProject = (): QualityReport | null => {
    if (!activeProject) return null;
    const report = runQualityAudit(activeProject);
    updateProject({ ...activeProject, qualityReport: report });
    return report;
  };

  const addAsset = (assetData: Omit<AssetItem, 'id' | 'createdAt'>) => {
    const newAsset: AssetItem = {
      ...assetData,
      id: `ast-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setAssets((prev) => [newAsset, ...prev]);
  };

  const updateAsset = (updated: AssetItem) => {
    setAssets((prev) => prev.map((a) => (a.id === updated.id ? updated : a)));
  };

  const deleteAsset = (assetId: string) => {
    setAssets((prev) => prev.filter((a) => a.id !== assetId));
  };

  return (
    <ProjectContext.Provider
      value={{
        projects,
        activeProject,
        activeView,
        setActiveView,
        setActiveProject,
        createProject,
        updateProject,
        duplicateProject,
        deleteProject,
        updateProjectStatus,
        auditActiveProject,
        assets,
        addAsset,
        updateAsset,
        deleteAsset,
        aiStatus,
        refreshAiStatus,
      }}
    >
      {children}
    </ProjectContext.Provider>
  );
};

export const useProjects = (): ProjectContextType => {
  const context = useContext(ProjectContext);
  if (!context) {
    throw new Error('useProjects must be used within a ProjectProvider');
  }
  return context;
};
