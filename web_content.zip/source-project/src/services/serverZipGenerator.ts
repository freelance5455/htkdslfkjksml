import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';

const rootFolderName = 'money-making-empire-ai-website-builder';
const zipFileName = 'money-making-empire-ai-website-builder.zip';

// Directories to exclude strictly
const EXCLUDE_DIRS = new Set([
  'node_modules',
  '.git',
  'dist',
  'build',
  '.gradle',
  '.idea',
  'coverage',
  '.cache',
  '.vite',
  'tmp'
]);

// Files to exclude strictly (no secrets, no previous zip binaries, no local envs)
const EXCLUDE_FILES = new Set([
  'money-making-empire-ai-website-builder.zip',
  'money-making-empire-website-builder.zip',
  '.env',
  '.env.local',
  '.env.production',
  '.env.development',
  'server.js',
  '.DS_Store',
  'Thumbs.db'
]);

function shouldExclude(relativePath: string): boolean {
  const parts = relativePath.split(path.sep);

  for (const part of parts) {
    if (EXCLUDE_DIRS.has(part)) {
      return true;
    }
  }

  const fileName = parts[parts.length - 1];
  if (EXCLUDE_FILES.has(fileName)) {
    return true;
  }

  // Exclude logs, zip archives, temporary files
  if (
    fileName.endsWith('.zip') ||
    fileName.endsWith('.log') ||
    fileName.endsWith('.tmp') ||
    fileName.startsWith('.DS_Store')
  ) {
    return true;
  }

  // In android directory, exclude build outputs and caches
  if (
    relativePath.includes('android/build') ||
    relativePath.includes('android/app/build') ||
    relativePath.includes('android/.gradle')
  ) {
    return true;
  }

  return false;
}

function getAllFiles(dir: string, rootDir: string, fileList: string[] = []): string[] {
  const entries = fs.readdirSync(dir, { withFileTypes: true });

  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    const relPath = path.relative(rootDir, fullPath);

    if (shouldExclude(relPath)) {
      continue;
    }

    if (entry.isDirectory()) {
      getAllFiles(fullPath, rootDir, fileList);
    } else if (entry.isFile()) {
      fileList.push(relPath);
    }
  }

  return fileList;
}

// In-memory cache for fast repeated downloads
let cachedZipBuffer: Buffer | null = null;
let lastPackagedTime = 0;
const CACHE_TTL_MS = 15000; // 15 seconds cache

export async function generateProjectZip(rootDir: string, forceRebuild = false): Promise<Buffer> {
  const now = Date.now();
  if (!forceRebuild && cachedZipBuffer && (now - lastPackagedTime < CACHE_TTL_MS)) {
    return cachedZipBuffer;
  }

  console.log('[ZipPackager] Scanning current project files at runtime...');
  const files = getAllFiles(rootDir, rootDir);
  console.log(`[ZipPackager] Packaging ${files.length} project files...`);

  const zip = new JSZip();

  for (const relPath of files) {
    const fullPath = path.join(rootDir, relPath);
    const data = fs.readFileSync(fullPath);

    // Normalize path separators to forward slash for standard ZIP format
    const zipPath = `${rootFolderName}/${relPath.split(path.sep).join('/')}`;

    const stat = fs.statSync(fullPath);
    const isExecutable = Boolean(stat.mode & 0o111) || relPath.endsWith('gradlew') || relPath.endsWith('gradlew.bat');

    zip.file(zipPath, data, {
      date: stat.mtime,
      unixPermissions: isExecutable ? 0o755 : 0o644
    });
  }

  console.log('[ZipPackager] Compressing ZIP archive...');
  const zipBuffer = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 9 },
  });

  cachedZipBuffer = zipBuffer;
  lastPackagedTime = Date.now();

  // Save to disk at root and public/ as well for static fallback
  try {
    const rootZipPath = path.join(rootDir, zipFileName);
    fs.writeFileSync(rootZipPath, zipBuffer);

    const publicDir = path.join(rootDir, 'public');
    if (!fs.existsSync(publicDir)) {
      fs.mkdirSync(publicDir, { recursive: true });
    }
    const publicZipPath = path.join(publicDir, zipFileName);
    fs.writeFileSync(publicZipPath, zipBuffer);
    console.log(`[ZipPackager] ZIP updated: ${(zipBuffer.length / 1024 / 1024).toFixed(2)} MB`);
  } catch (err) {
    console.warn('[ZipPackager] Disk write warning (in-memory buffer still ready):', err);
  }

  return zipBuffer;
}
