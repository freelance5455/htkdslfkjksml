import { WebsiteProject, BusinessInfo, BrandConfig, WebsiteType, SEOConfig, BrandStyle } from '../types/website';
import { extractClientContextFromPrompt } from '../utils/promptExtractor';

export interface AIProviderStatus {
  configured: boolean;
  model: string;
  mode: 'online' | 'demo';
  provider: string;
}

export interface WebsiteGenerationParams {
  business: BusinessInfo;
  brand: BrandConfig;
  type: WebsiteType;
  pages: string[];
}

export class AIProviderService {
  private static instance: AIProviderService;

  private constructor() {}

  public static getInstance(): AIProviderService {
    if (!AIProviderService.instance) {
      AIProviderService.instance = new AIProviderService();
    }
    return AIProviderService.instance;
  }

  public async checkStatus(): Promise<AIProviderStatus> {
    try {
      const res = await fetch('/api/ai/status');
      if (res.ok) {
        return await res.json();
      }
    } catch (e) {
      // Backend not reached or offline
    }
    return {
      configured: false,
      model: 'deterministic-heuristic',
      mode: 'demo',
      provider: 'Money Making Empire Local Engine (Demo Mode)',
    };
  }

  public async generateSectionImage(params: {
    prompt: string;
    industry: string;
    style: BrandStyle;
    sectionType: string;
    colorPalette?: { primary: string; accent: string };
    aspectRatio?: '16:9' | '4:3' | '1:1' | '21:9' | '3:4';
  }): Promise<{
    imageUrl: string;
    altText: string;
    origin: 'ai_generated' | 'stock_licensed';
    prompt: string;
    dimensions?: string;
    license: string;
  }> {
    try {
      const res = await fetch('/api/ai/generate-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.success && data.imageUrl) {
          return {
            imageUrl: data.imageUrl,
            altText: data.altText,
            origin: data.origin || 'ai_generated',
            prompt: data.prompt,
            dimensions: data.dimensions || '1600x900',
            license: data.license || 'Commercial Royalty-Free License',
          };
        }
      }
    } catch (e) {
      console.warn('generateSectionImage failed, using verified fallback image:', e);
    }

    return {
      imageUrl: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1600&q=80',
      altText: `High-resolution commercial architecture and workspace for ${params.industry || 'business'}`,
      origin: 'ai_generated',
      prompt: params.prompt,
      dimensions: '1600x900',
      license: 'Commercial Royalty-Free Unsplash Verified License',
    };
  }

  public async generateWebsite(params: WebsiteGenerationParams): Promise<{
    heroHeadline: string;
    heroSubheadline: string;
    heroCtaPrimary: string;
    heroCtaSecondary: string;
    services: { title: string; description: string; badge?: string }[];
    processSteps: { title: string; description: string }[];
    faq: { question: string; answer: string }[];
    aboutNarrative: string;
    seoTitle: string;
    seoDescription: string;
    mode: 'online' | 'demo';
  }> {
    try {
      const res = await fetch('/api/ai/generate-website', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });

      if (res.ok) {
        const json = await res.json();
        if (json.success && json.data?.heroHeadline) {
          return {
            ...json.data,
            mode: 'online',
          };
        }
      }
    } catch (e) {
      console.warn('AI generateWebsite request failed, using intelligent local engine:', e);
    }

    // High-fidelity deterministic fallback based on business parameters
    const biz = params.business;
    const ind = biz.industry || 'Professional Services';
    const location = biz.location ? ` in ${biz.location}` : '';

    return {
      mode: 'demo',
      heroHeadline: `Uncompromising ${ind} crafted for discerning clients${location}.`,
      heroSubheadline: `${biz.description || `Delivering bespoke ${ind} with rigorous attention to detail, transparent communication, and enduring outcomes.`}`,
      heroCtaPrimary: biz.primaryGoal === 'Generate calls' ? 'Speak with a Specialist' : biz.primaryGoal === 'Book appointments' ? 'Book Private Consultation' : 'Request Custom Quote',
      heroCtaSecondary: biz.whatsapp ? 'Direct WhatsApp Line' : 'Explore Capabilities',
      services: (biz.services && biz.services.length > 0 ? biz.services : [
        'Bespoke Advisory & Planning',
        'Turnkey Project Execution',
        'Ongoing Dedicated Management',
      ]).map((srv, idx) => ({
        title: srv,
        description: `Comprehensive ${srv.toLowerCase()} tailored to specific client milestones, ensuring predictable results and complete transparency.`,
        badge: idx === 0 ? 'Core Discipline' : idx === 1 ? 'Comprehensive' : 'Advisory',
      })),
      processSteps: [
        {
          title: 'Initial Diagnostic & Discovery',
          description: 'We analyze your exact requirements, evaluate constraints, and formulate a clear execution roadmap.',
        },
        {
          title: 'Custom Engineering & Build',
          description: 'Our specialists craft each component to exacting standards with continuous milestone reviews.',
        },
        {
          title: 'Final Delivery & Quality Signoff',
          description: 'Rigorous inspection followed by seamless handoff, documentation, and dedicated aftercare.',
        },
      ],
      faq: [
        {
          question: `How does your ${ind} service compare to standard alternatives?`,
          answer: `We prioritize bespoke execution, direct principal involvement, and zero shortcuts. Every deliverable is customized to your exact objectives.`,
        },
        {
          question: 'What is the typical timeline and onboarding process?',
          answer: 'Following our initial consultation, we provide a detailed project schedule with defined checkpoints and transparent milestones.',
        },
        {
          question: 'How do we get started or request an initial estimate?',
          answer: `Submit your details through our consultation form or contact our direct phone/WhatsApp line for an immediate response.`,
        },
      ],
      aboutNarrative: `Founded to elevate standards in ${ind}, we combine decades of rigorous technical capability with a quiet commitment to exceptional client service.`,
      seoTitle: `${biz.name} | Premium ${ind}${location}`,
      seoDescription: `${biz.description || `Specialized ${ind} services`}. Contact ${biz.name} today for consultation and estimates.`,
    };
  }

  public async modifyWebsite(
    command: string,
    currentWebsite: WebsiteProject
  ): Promise<{
    updatedProject: WebsiteProject;
    summary: string;
    mode: 'online' | 'demo';
  }> {
    try {
      const res = await fetch('/api/ai/modify-website', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command, currentWebsite }),
      });

      if (res.ok) {
        const json = await res.json();
        if (json.success && json.changes) {
          const ch = json.changes;
          const clone: WebsiteProject = JSON.parse(JSON.stringify(currentWebsite));
          const home = clone.pages.find((p) => p.isHome) || clone.pages[0];
          const hero = home.sections.find((s) => s.type === 'hero');

          if (hero) {
            if (ch.heroHeadline) hero.title = ch.heroHeadline;
            if (ch.heroSubheadline) hero.subtitle = ch.heroSubheadline;
            if (ch.heroCtaPrimary && hero.ctaPrimary) hero.ctaPrimary.label = ch.heroCtaPrimary;
            if (ch.heroCtaSecondary && hero.ctaSecondary) hero.ctaSecondary.label = ch.heroCtaSecondary;
          }

          if (ch.primaryColor) clone.brand.primaryColor = ch.primaryColor;
          if (ch.accentColor) clone.brand.accentColor = ch.accentColor;
          if (ch.style) clone.brand.style = ch.style;

          if (ch.newServices && Array.isArray(ch.newServices)) {
            const srvSec = home.sections.find((s) => s.type === 'services');
            if (srvSec) {
              srvSec.items = ch.newServices.map((ns: any, idx: number) => ({
                id: `srv-ai-${Date.now()}-${idx}`,
                title: ns.title,
                description: ns.description,
                badge: ns.badge || 'Featured',
              }));
            }
          }

          clone.updatedAt = new Date().toISOString();
          return {
            updatedProject: clone,
            summary: ch.summaryOfChanges || 'Successfully applied AI enhancements.',
            mode: 'online',
          };
        }
      }
    } catch (e) {
      console.warn('AI modifyWebsite failed, applying intelligent local heuristic:', e);
    }

    // Local deterministic modification heuristics
    const clone: WebsiteProject = JSON.parse(JSON.stringify(currentWebsite));
    const home = clone.pages.find((p) => p.isHome) || clone.pages[0];
    const hero = home.sections.find((s) => s.type === 'hero');
    const lowerCmd = command.toLowerCase();
    let summary = 'Updated website with custom modifications.';

    if (lowerCmd.includes('premium') || lowerCmd.includes('luxur')) {
      clone.brand.style = 'Luxury';
      clone.brand.fontPairing = 'luxury';
      clone.brand.primaryColor = '#0a192f';
      clone.brand.accentColor = '#c5a059';
      if (hero) {
        hero.title = `The pinnacle of ${clone.business.industry || 'craftsmanship'}. Unrivaled distinction.`;
        hero.subtitle = 'Bespoke precision engineered for discerning clients who demand absolute perfection in every detail.';
        if (hero.ctaPrimary) hero.ctaPrimary.label = 'Request Private Consultation';
      }
      summary = 'Applied Luxury aesthetic: elevated typography, gold accent palette, and refined authoritative copy.';
    } else if (lowerCmd.includes('whatsapp')) {
      if (hero) {
        hero.ctaSecondary = {
          label: 'Direct WhatsApp Concierge',
          link: `https://wa.me/${clone.business.whatsapp?.replace(/[^0-9]/g, '') || '1234567890'}`,
          type: 'whatsapp',
          icon: 'whatsapp',
        };
      }
      summary = 'Configured high-converting WhatsApp direct inquiry button in the hero and contact sections.';
    } else if (lowerCmd.includes('dentist') || lowerCmd.includes('dental')) {
      clone.business.industry = 'Cosmetic & Restorative Dentistry';
      clone.type = 'Medical/Dental';
      clone.brand.style = 'Luxury';
      clone.brand.primaryColor = '#0a192f';
      clone.brand.accentColor = '#c5a059';
      if (hero) {
        hero.title = 'Bespoke smile transformations. Architectural dental artistry.';
        hero.subtitle = 'Handcrafted Swiss porcelain restorations and computer-guided implant dentistry in a private clinical sanctuary.';
        if (hero.ctaPrimary) hero.ctaPrimary.label = 'Book Smile Diagnostic';
      }
      summary = 'Rewrote hero and positioning specifically for a high-end cosmetic and dental clinic.';
    } else if (lowerCmd.includes('clean') || lowerCmd.includes('minimal') || lowerCmd.includes('less text')) {
      clone.brand.style = 'Minimal';
      clone.brand.fontPairing = 'clean';
      if (hero && hero.subtitle) {
        hero.subtitle = 'Precision execution. Measurable business results. No compromises.';
      }
      summary = 'Streamlined copy, reduced text density, and maximized clean whitespace.';
    } else if (lowerCmd.includes('process') || lowerCmd.includes('step')) {
      const hasProc = home.sections.some((s) => s.type === 'process');
      if (!hasProc) {
        home.sections.push({
          id: `sec-proc-${Date.now()}`,
          type: 'process',
          title: 'Our Transparent 3-Step Execution Model',
          subtitle: 'A disciplined framework structured for clarity, accountability, and predictable results.',
          layoutVariant: 'timeline',
          items: [
            { id: 'p1', title: '01. Strategic Audit & Planning', description: 'Comprehensive diagnostic of your goals, timeline, and scope.' },
            { id: 'p2', title: '02. Precision Production', description: 'Execution with continuous milestone transparency and zero surprises.' },
            { id: 'p3', title: '03. Delivery & Long-Term Support', description: 'Final signoff, complete asset handoff, and dedicated support.' },
          ],
          isVisible: true,
          order: home.sections.length + 1,
        });
      }
      summary = 'Added an elegant 3-step client execution process section.';
    } else {
      if (hero) {
        hero.title = `High-impact ${clone.business.industry} designed for conversion.`;
      }
      summary = `Applied requested adjustments based on "${command}".`;
    }

    clone.updatedAt = new Date().toISOString();
    return {
      updatedProject: clone,
      summary,
      mode: 'demo',
    };
  }

  public async enhancePrompt(prompt: string): Promise<string> {
    try {
      const res = await fetch('/api/ai/enhance-prompt', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.enhancedPrompt) return data.enhancedPrompt;
      }
    } catch (e) {
      console.warn('Failed to call /api/ai/enhance-prompt, using local fallback:', e);
    }
    return `Build a high-converting, premium website based on: "${prompt}". Use an elevated modern visual style, clear value-focused typography, specialized service showcases, verified process steps, direct consultation booking, WhatsApp contact line, and a 24/7 AI chatbot for instant client inquiries.`;
  }

  public async generateFromPrompt(prompt: string, clientInfo?: any): Promise<any> {
    try {
      const res = await fetch('/api/ai/prompt-generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, clientInfo }),
      });
      if (res.ok) {
        const json = await res.json();
        if (json.success && json.data) {
          return { ...json.data, mode: json.mode || 'online' };
        }
      }
    } catch (e) {
      console.warn('Failed to call /api/ai/prompt-generate, falling back to local heuristic:', e);
    }

    // Heuristic Fallback driven 100% by the user prompt
    const clientContext = extractClientContextFromPrompt(prompt, clientInfo);
    const bizName = clientContext.hasCustomName ? clientContext.businessName : (clientInfo?.businessName || '[Business Name]');
    const industry = clientContext.industry;
    const loc = clientContext.location;
    const services = clientContext.services.length > 0 ? clientContext.services : [
      'Diagnostic Consultation',
      'Full Turnkey Delivery',
      'Dedicated Client Advisory',
    ];

    return {
      mode: 'demo',
      business: {
        name: bizName,
        industry,
        description: `Specialized ${industry.toLowerCase()} delivering meticulous execution and personalized attention to detail${loc ? ` in ${loc}` : ''}.`,
        location: loc,
        phone: clientContext.phone || '',
        email: clientContext.email || '',
        whatsapp: clientContext.hasWhatsApp ? (clientContext.phone || 'active') : '',
        websiteUrl: clientContext.websiteUrl || '',
        socialUrls: {},
        businessHours: 'Mon - Sat: 9:00 AM - 6:00 PM',
        services,
        products: [],
        targetAudience: 'Clients demanding absolute excellence and transparent service',
        primaryGoal: clientContext.primaryGoal,
      },
      brand: {
        logoUrl: '',
        primaryColor: clientContext.primaryColor,
        secondaryColor: clientContext.secondaryColor,
        accentColor: clientContext.accentColor,
        fontPairing: clientContext.fontPairing,
        style: clientContext.style,
        borderRadius: 'subtle',
        lightMode: clientContext.lightMode,
      },
      websiteType: clientContext.websiteType,
      pages: ['Home', 'Services', 'FAQ', 'Contact'],
      chatbotEnabled: clientContext.hasChatbot,
      sections: [
        {
          type: 'hero',
          title: `Welcome to ${bizName}`,
          subtitle: `Specialized ${industry.toLowerCase()}${loc ? ` serving ${loc}` : ''}. Engineered for excellence and high-touch client service.`,
          kicker: loc ? `${industry} · ${loc}` : `${industry}`,
          layoutVariant: 'split-right',
          ctaPrimary: {
            label: clientContext.primaryGoal === 'Book appointments' ? 'Book Appointment' : 'Get In Touch',
            link: '#contact',
            type: 'primary',
            icon: 'arrow'
          },
          ctaSecondary: clientContext.hasWhatsApp ? {
            label: 'WhatsApp Concierge',
            link: clientContext.phone ? `https://wa.me/${clientContext.phone.replace(/[^0-9]/g, '')}` : '#contact',
            type: 'whatsapp',
            icon: 'whatsapp'
          } : {
            label: 'Explore Services',
            link: '#services',
            type: 'outline',
            icon: 'arrow'
          },
        },
      ],
      seo: {
        pageTitle: `${bizName} | ${industry}${loc ? ` · ${loc}` : ''}`,
        metaDescription: `Discover specialized ${industry.toLowerCase()} at ${bizName}${loc ? ` in ${loc}` : ''}. Connect with our team today.`,
        businessCategory: industry,
      },
    };
  }

  public async refineSection(
    command: string,
    section: any,
    websiteContext: any
  ): Promise<{ updatedSection: any; summary: string; mode: 'online' | 'demo' }> {
    try {
      const res = await fetch('/api/ai/refine-section', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command, section, websiteContext }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.updatedSection) {
          return {
            updatedSection: data.updatedSection,
            summary: data.summary || 'Section updated successfully.',
            mode: data.mode || 'online',
          };
        }
      }
    } catch (e) {
      console.warn('refineSection failed, using local heuristic:', e);
    }

    const clone = JSON.parse(JSON.stringify(section));
    return {
      updatedSection: clone,
      summary: `Updated section based on "${command}".`,
      mode: 'demo',
    };
  }

  public async chatRefine(
    message: string,
    currentWebsite: WebsiteProject,
    selectedSectionId?: string,
    history?: any[]
  ): Promise<{ reply: string; updatedProject: WebsiteProject; summary: string; mode: 'online' | 'demo' }> {
    try {
      const res = await fetch('/api/ai/chat-refine', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message, currentWebsite, selectedSectionId, history }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.updatedProject) {
          return {
            reply: data.reply || 'Changes applied successfully.',
            updatedProject: data.updatedProject,
            summary: data.summary || 'Updated website.',
            mode: data.mode || 'online',
          };
        }
      }
    } catch (e) {
      console.warn('chatRefine failed, using fallback:', e);
    }

    const result = await this.modifyWebsite(message, currentWebsite);
    return {
      reply: `I've analyzed your instruction and refined the design accordingly while protecting all your existing business facts.`,
      updatedProject: result.updatedProject,
      summary: result.summary,
      mode: 'demo',
    };
  }

  public generateSEO(business: BusinessInfo, brand: BrandConfig): SEOConfig {
    const title = `${business.name} | ${business.industry || 'Professional Services'}${business.location ? ` · ${business.location}` : ''}`;
    const desc = `${business.description || `Specialized ${business.industry || 'services'}`}. Direct bookings, phone consultations, and quote requests.`;

    const schema = {
      '@context': 'https://schema.org',
      '@type': 'LocalBusiness',
      name: business.name,
      description: business.description,
      telephone: business.phone,
      email: business.email,
      address: {
        '@type': 'PostalAddress',
        streetAddress: business.location,
      },
      url: business.websiteUrl || 'https://client-website.com',
      priceRange: '$$$',
    };

    return {
      pageTitle: title.length > 68 ? title.slice(0, 65) + '...' : title,
      metaDescription: desc.length > 155 ? desc.slice(0, 152) + '...' : desc,
      ogTitle: business.name,
      ogDescription: desc,
      ogImage: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80',
      canonicalUrl: business.websiteUrl || 'https://client-website.com',
      robots: 'index, follow',
      businessCategory: business.industry || 'Business Services',
      serviceArea: business.location || 'Local & Regional',
      structuredDataJson: JSON.stringify(schema, null, 2),
    };
  }

  public improveDesign(style: BrandStyle, industry: string): Partial<BrandConfig> {
    switch (style) {
      case 'Luxury':
        return {
          primaryColor: '#0a192f',
          secondaryColor: '#1e293b',
          accentColor: '#c5a059',
          fontPairing: 'luxury',
          borderRadius: 'subtle',
          lightMode: true,
        };
      case 'Corporate':
        return {
          primaryColor: '#0f172a',
          secondaryColor: '#334155',
          accentColor: '#2563eb',
          fontPairing: 'modern',
          borderRadius: 'subtle',
          lightMode: true,
        };
      case 'Modern':
        return {
          primaryColor: '#18181b',
          secondaryColor: '#27272a',
          accentColor: '#d97706',
          fontPairing: 'clean',
          borderRadius: 'rounded',
          lightMode: true,
        };
      case 'Editorial':
        return {
          primaryColor: '#0a0a0a',
          secondaryColor: '#171717',
          accentColor: '#10b981',
          fontPairing: 'editorial',
          borderRadius: 'none',
          lightMode: false,
        };
      case 'Technology':
        return {
          primaryColor: '#030712',
          secondaryColor: '#111827',
          accentColor: '#06b6d4',
          fontPairing: 'technical',
          borderRadius: 'subtle',
          lightMode: false,
        };
      case 'Premium Local Business':
      default:
        return {
          primaryColor: '#0f172a',
          secondaryColor: '#1e293b',
          accentColor: '#ea580c',
          fontPairing: 'clean',
          borderRadius: 'subtle',
          lightMode: true,
        };
    }
  }
}

export const aiProvider = AIProviderService.getInstance();
