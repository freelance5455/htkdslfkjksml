import React from 'react';
import { WebsiteProject, ProjectVersion } from '../../types/website';
import { 
  History, 
  X, 
  RotateCcw, 
  Clock, 
  Check, 
  Copy, 
  Sparkles, 
  Layers 
} from 'lucide-react';

interface VersionHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  project: WebsiteProject;
  onRestoreVersion: (version: ProjectVersion) => void;
}

export const VersionHistoryModal: React.FC<VersionHistoryModalProps> = ({
  isOpen,
  onClose,
  project,
  onRestoreVersion,
}) => {
  if (!isOpen) return null;

  const versions: ProjectVersion[] = project.versionHistory && project.versionHistory.length > 0
    ? project.versionHistory
    : [
        {
          id: 'ver-initial',
          versionNumber: 1,
          timestamp: project.createdAt || new Date().toISOString(),
          label: 'Version 1 - Initial Project Creation',
          summary: 'Baseline project structure and sections.',
          snapshot: JSON.parse(JSON.stringify(project)),
        },
      ];

  // Sort newest versions first
  const sortedVersions = [...versions].sort((a, b) => b.versionNumber - a.versionNumber);

  return (
    <div className="fixed inset-0 z-50 bg-neutral-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl max-w-xl w-full p-6 shadow-2xl space-y-5 animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <History className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Project Version History</h3>
              <p className="text-[11px] text-neutral-400">
                Recoverable snapshots created before each major AI modification.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Versions List */}
        <div className="max-h-80 overflow-y-auto space-y-3 pr-1 scrollbar-thin">
          {sortedVersions.map((ver, idx) => {
            const isCurrent = idx === 0;
            return (
              <div
                key={ver.id}
                className={`p-3.5 rounded-xl border text-xs transition-all flex items-start justify-between gap-3 ${
                  isCurrent
                    ? 'bg-neutral-950 border-amber-500/40 shadow-sm'
                    : 'bg-neutral-950/60 border-neutral-800 hover:border-neutral-700'
                }`}
              >
                <div className="space-y-1 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-neutral-200">
                      Version {ver.versionNumber}
                    </span>
                    {isCurrent && (
                      <span className="px-2 py-0.5 rounded text-[9px] font-mono uppercase bg-amber-500/10 border border-amber-500/30 text-amber-400">
                        Current Active State
                      </span>
                    )}
                  </div>
                  <div className="text-[11px] text-neutral-400">
                    {ver.label || 'Project Checkpoint'}
                  </div>
                  {ver.summary && (
                    <div className="text-[10px] text-neutral-500 italic">
                      "{ver.summary}"
                    </div>
                  )}
                  <div className="text-[10px] font-mono text-neutral-500 flex items-center gap-1.5 pt-1">
                    <Clock className="w-3 h-3 text-neutral-600" />
                    <span>{new Date(ver.timestamp).toLocaleString()}</span>
                  </div>
                </div>

                {!isCurrent && (
                  <button
                    type="button"
                    onClick={() => {
                      if (confirm(`Restore to Version ${ver.versionNumber}? Your current state will be saved as a new version.`)) {
                        onRestoreVersion(ver);
                        onClose();
                      }
                    }}
                    className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-amber-500 hover:text-neutral-950 text-neutral-200 font-semibold text-[11px] flex items-center gap-1.5 transition-all self-center border border-neutral-700"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Restore</span>
                  </button>
                )}
              </div>
            );
          })}
        </div>

        {/* Footer info */}
        <div className="pt-2 border-t border-neutral-800 flex items-center justify-between text-[11px] text-neutral-400">
          <span>{sortedVersions.length} recoverable version(s) saved</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-white font-semibold text-xs"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
