import React, { useState } from 'react';
import { useProjects } from '../../context/ProjectContext';
import { WebsiteProject, ProjectStatus } from '../../types/website';
import { 
  Plus, 
  Search, 
  Copy, 
  Edit3, 
  ExternalLink, 
  Download, 
  Trash2, 
  Globe, 
  Filter, 
  Sparkles,
  Calendar,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { downloadProjectZip, generateStandaloneHtml } from '../../services/exportService';
import { ShareWebsiteModal } from '../common/ShareWebsiteModal';

export const ProjectsView: React.FC = () => {
  const { projects, setActiveProject, setActiveView, duplicateProject, deleteProject, updateProjectStatus } = useProjects();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  
  // Duplicate modal state
  const [duplicateModalTarget, setDuplicateModalTarget] = useState<WebsiteProject | null>(null);
  const [dupName, setDupName] = useState('');
  const [dupClient, setDupClient] = useState('');

  // Share modal state
  const [shareModalTarget, setShareModalTarget] = useState<WebsiteProject | null>(null);

  const filteredProjects = projects.filter((p) => {
    const matchesSearch =
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.clientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.business.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.business.industry.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus = statusFilter === 'all' || p.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleOpenDuplicate = (p: WebsiteProject) => {
    setDuplicateModalTarget(p);
    setDupName(`${p.name} (Custom Demo)`);
    setDupClient(`${p.clientName} Prospect`);
  };

  const handleConfirmDuplicate = () => {
    if (!duplicateModalTarget) return;
    const cloned = duplicateProject(duplicateModalTarget.id, dupName, dupClient);
    setDuplicateModalTarget(null);
    setActiveProject(cloned);
    setActiveView('editor');
  };

  const handleOpenPreview = (p: WebsiteProject) => {
    const html = generateStandaloneHtml(p);
    const win = window.open('', '_blank');
    if (win) {
      win.document.write(html);
      win.document.close();
    }
  };

  const handleExportZip = async (p: WebsiteProject) => {
    const blob = await downloadProjectZip(p);
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${p.business.name.toLowerCase().replace(/[^a-z0-9]/g, '-')}-website.zip`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-neutral-100 tracking-tight">Project Management</h1>
          <p className="text-xs text-neutral-400 mt-1">
            Manage your client websites, duplicate demos for new prospects, and export production assets.
          </p>
        </div>

        <button
          onClick={() => setActiveView('wizard')}
          className="px-4 py-2 rounded-lg bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-neutral-950 text-xs font-bold flex items-center gap-1.5 shadow-sm active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>New Website Project</span>
        </button>
      </div>

      {/* Filter Bar & Search */}
      <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between bg-neutral-900 p-3 rounded-xl border border-neutral-800">
        
        {/* Search Input */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-neutral-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by project name, client, or industry..."
            className="w-full pl-9 pr-4 py-1.5 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-amber-500"
          />
        </div>

        {/* Status Segmented Buttons */}
        <div className="flex items-center gap-1 overflow-x-auto text-xs pb-1 md:pb-0">
          {[
            { id: 'all', label: 'All' },
            { id: 'draft', label: 'Draft' },
            { id: 'demo', label: 'Demo' },
            { id: 'client_review', label: 'Review' },
            { id: 'approved', label: 'Approved' },
            { id: 'ready_to_deploy', label: 'Deploy Ready' },
            { id: 'live', label: 'Live' },
          ].map((st) => (
            <button
              key={st.id}
              onClick={() => setStatusFilter(st.id)}
              className={`px-3 py-1.5 rounded-md font-medium whitespace-nowrap transition-colors ${
                statusFilter === st.id
                  ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20 font-bold'
                  : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800'
              }`}
            >
              {st.label}
            </button>
          ))}
        </div>
      </div>

      {/* Project Cards Grid */}
      {filteredProjects.length === 0 ? (
        <div className="p-12 text-center rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-400">
          <AlertCircle className="w-8 h-8 text-neutral-500 mx-auto mb-3" />
          <h3 className="font-semibold text-neutral-200 mb-1">No Projects Found</h3>
          <p className="text-xs mb-4">No projects matched your search criteria.</p>
          <button
            onClick={() => {
              setSearchQuery('');
              setStatusFilter('all');
            }}
            className="text-xs text-amber-400 hover:underline"
          >
            Clear filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredProjects.map((p) => {
            const audit = p.qualityReport;
            const score = audit?.overallScore || 90;

            return (
              <div
                key={p.id}
                className="rounded-xl bg-neutral-900 border border-neutral-800 hover:border-neutral-700 transition-all shadow-md flex flex-col justify-between overflow-hidden group"
              >
                <div className="p-5">
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div>
                      <span className="text-[10px] uppercase font-mono text-neutral-500 tracking-wider">
                        {p.type}
                      </span>
                      <h3 className="font-bold text-base text-neutral-100 group-hover:text-amber-300 transition-colors truncate max-w-[220px]">
                        {p.business.name}
                      </h3>
                      <div className="text-xs text-neutral-400">{p.clientName}</div>
                    </div>

                    <select
                      value={p.status}
                      onChange={(e) => updateProjectStatus(p.id, e.target.value as any)}
                      className={`text-[10px] font-mono uppercase px-2 py-0.5 rounded font-semibold border focus:outline-none cursor-pointer ${
                        p.status === 'live'
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                          : p.status === 'demo'
                          ? 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                          : p.status === 'client_review'
                          ? 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20'
                          : 'bg-neutral-800 text-neutral-400 border-neutral-700'
                      }`}
                    >
                      <option value="draft">Draft</option>
                      <option value="demo">Demo</option>
                      <option value="client_review">Client Review</option>
                      <option value="approved">Approved</option>
                      <option value="ready_to_deploy">Ready to Deploy</option>
                      <option value="live">Live</option>
                    </select>
                  </div>

                  <p className="text-xs text-neutral-400 line-clamp-2 mb-4 leading-relaxed">
                    {p.business.description}
                  </p>

                  <div className="space-y-1.5 text-[11px] text-neutral-400 border-t border-neutral-800/80 pt-3">
                    <div className="flex justify-between">
                      <span className="text-neutral-500">Industry:</span>
                      <span className="text-neutral-300 truncate max-w-[170px]">{p.business.industry}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-neutral-500">Brand Style:</span>
                      <span className="text-neutral-300">{p.brand.style} ({p.brand.fontPairing})</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-neutral-500">Quality Score:</span>
                      <span className="font-mono text-amber-400 font-bold">{score}% Ready</span>
                    </div>
                  </div>

                  {/* Clear Share Website Button */}
                  <div className="pt-3 border-t border-neutral-800/80">
                    <button
                      type="button"
                      onClick={() => setShareModalTarget(p)}
                      className="w-full py-2 px-3 rounded-lg bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 hover:border-amber-400 text-amber-400 hover:text-amber-300 text-xs font-semibold flex items-center justify-center gap-1.5 transition-all shadow-sm active:scale-[0.98]"
                      title="Share Website"
                    >
                      <span>🔗 Share Website</span>
                    </button>
                  </div>
                </div>

                {/* Card Action Footer */}
                <div className="px-5 py-3 bg-neutral-950/60 border-t border-neutral-800 flex items-center justify-between text-xs">
                  <span className="text-[10px] text-neutral-500">
                    Updated {new Date(p.updatedAt).toLocaleDateString()}
                  </span>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => {
                        setActiveProject(p);
                        setActiveView('editor');
                      }}
                      className="px-2.5 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-white font-semibold flex items-center gap-1"
                    >
                      <Edit3 className="w-3 h-3" /> Edit
                    </button>
                    <button
                      onClick={() => handleOpenPreview(p)}
                      title="Open Clean Preview"
                      className="p-1.5 rounded text-neutral-400 hover:text-white hover:bg-neutral-800"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleOpenDuplicate(p)}
                      title="Duplicate Website"
                      className="p-1.5 rounded text-neutral-400 hover:text-white hover:bg-neutral-800"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleExportZip(p)}
                      title="Download Package"
                      className="p-1.5 rounded text-neutral-400 hover:text-white hover:bg-neutral-800"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => {
                        if (confirm(`Are you sure you want to delete ${p.name}?`)) {
                          deleteProject(p.id);
                        }
                      }}
                      title="Delete Project"
                      className="p-1.5 rounded text-neutral-500 hover:text-rose-400 hover:bg-neutral-800"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* DUPLICATE PROJECT MODAL */}
      {duplicateModalTarget && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-6 max-w-md w-full shadow-2xl space-y-4">
            <div>
              <div className="text-xs uppercase tracking-wider text-amber-400 font-mono font-bold mb-1">
                Fast Client Demo Replicator
              </div>
              <h3 className="text-lg font-bold text-white">Duplicate Website Project</h3>
              <p className="text-xs text-neutral-400 mt-1">
                Clones the component hierarchy, design system, and layout structure while allowing you to change client identity and business specifics.
              </p>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-neutral-400 font-semibold mb-1">New Project Name</label>
                <input
                  type="text"
                  value={dupName}
                  onChange={(e) => setDupName(e.target.value)}
                  className="w-full px-3 py-2 rounded bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-neutral-400 font-semibold mb-1">New Client / Prospect Name</label>
                <input
                  type="text"
                  value={dupClient}
                  onChange={(e) => setDupClient(e.target.value)}
                  className="w-full px-3 py-2 rounded bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-neutral-800">
              <button
                onClick={() => setDuplicateModalTarget(null)}
                className="px-4 py-2 rounded text-neutral-400 hover:text-white text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmDuplicate}
                className="px-4 py-2 rounded bg-amber-400 hover:bg-amber-300 text-neutral-950 text-xs font-bold shadow transition-all active:scale-95"
              >
                Create Cloned Project
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SHARE WEBSITE MODAL */}
      <ShareWebsiteModal
        project={shareModalTarget}
        isOpen={Boolean(shareModalTarget)}
        onClose={() => setShareModalTarget(null)}
        onDeployClick={(p) => {
          setActiveProject(p);
          setActiveView('deployment');
        }}
      />

    </div>
  );
};
