import React, { useState, useEffect } from 'react';
import { 
  Bot, 
  Users, 
  MessageSquare, 
  Zap, 
  Search, 
  Filter, 
  Trash2, 
  CheckCircle, 
  Clock, 
  Mail, 
  Phone, 
  Download, 
  RefreshCw, 
  ExternalLink, 
  AlertCircle,
  Shield,
  Eye,
  X
} from 'lucide-react';
import { ChatbotLead, ChatbotConversation } from '../../types/chatbot';
import { WebsiteProject } from '../../types/website';
import { chatbotProvider, ChatbotStatus } from '../../services/chatbotProvider';

interface ChatbotLeadDashboardProps {
  projects: WebsiteProject[];
  selectedProjectId?: string | null;
  onSelectProject?: (projectId: string) => void;
}

export const ChatbotLeadDashboard: React.FC<ChatbotLeadDashboardProps> = ({
  projects,
  selectedProjectId,
  onSelectProject,
}) => {
  const [filterProject, setFilterProject] = useState<string>(selectedProjectId || 'all');
  const [leads, setLeads] = useState<ChatbotLead[]>([]);
  const [conversations, setConversations] = useState<ChatbotConversation[]>([]);
  const [status, setStatus] = useState<ChatbotStatus | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedConversation, setSelectedConversation] = useState<ChatbotConversation | null>(null);
  const [activeTab, setActiveTab] = useState<'leads' | 'conversations'>('leads');
  const [searchQuery, setSearchQuery] = useState('');

  const loadData = async () => {
    setIsLoading(true);
    const [fetchedStatus, fetchedLeads, fetchedConvs] = await Promise.all([
      chatbotProvider.getStatus(),
      chatbotProvider.getLeads(filterProject === 'all' ? undefined : filterProject),
      chatbotProvider.getConversations(filterProject === 'all' ? undefined : filterProject),
    ]);

    setStatus(fetchedStatus);
    setLeads(fetchedLeads);
    setConversations(fetchedConvs);
    setIsLoading(false);
  };

  useEffect(() => {
    loadData();
  }, [filterProject]);

  const handleDeleteLead = async (id: string) => {
    if (confirm('Are you sure you want to delete this lead? This is permanent for privacy compliance.')) {
      const ok = await chatbotProvider.deleteLead(id);
      if (ok) {
        setLeads((prev) => prev.filter((l) => l.id !== id));
      }
    }
  };

  const handleDeleteConversation = async (id: string) => {
    if (confirm('Delete this conversation history?')) {
      const ok = await chatbotProvider.deleteConversation(id);
      if (ok) {
        setConversations((prev) => prev.filter((c) => c.id !== id));
        if (selectedConversation?.id === id) {
          setSelectedConversation(null);
        }
      }
    }
  };

  const handleExportLeadsCsv = () => {
    if (leads.length === 0) return;
    const headers = ['ID', 'Date', 'Website', 'Name', 'Email', 'Phone', 'WhatsApp', 'Service', 'Status', 'Message'];
    const rows = leads.map((l) => [
      l.id,
      new Date(l.date).toLocaleString(),
      `"${(l.websiteName || '').replace(/"/g, '""')}"`,
      `"${(l.name || '').replace(/"/g, '""')}"`,
      l.email || '',
      l.phone || '',
      l.whatsapp || '',
      `"${(l.interestedService || '').replace(/"/g, '""')}"`,
      l.status,
      `"${(l.message || '').replace(/"/g, '""')}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `chatbot-leads-${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Filtered lists
  const filteredLeads = leads.filter((l) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      l.name.toLowerCase().includes(q) ||
      l.email.toLowerCase().includes(q) ||
      l.phone.toLowerCase().includes(q) ||
      (l.websiteName && l.websiteName.toLowerCase().includes(q)) ||
      (l.interestedService && l.interestedService.toLowerCase().includes(q))
    );
  });

  const filteredConversations = conversations.filter((c) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      (c.websiteName && c.websiteName.toLowerCase().includes(q)) ||
      (c.requestedService && c.requestedService.toLowerCase().includes(q)) ||
      c.messages.some((m) => m.content.toLowerCase().includes(q))
    );
  });

  // Real metric calculations - Zero fake numbers
  const totalConversations = conversations.length;
  const leadsCaptured = leads.length;
  const activeConversations = conversations.filter((c) => c.status === 'active').length;
  const conversionEvents = leads.length; // Each lead captured is a primary conversion

  return (
    <div className="space-y-6">
      {/* HEADER & CONTROLS */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-neutral-900 border border-neutral-800 p-5 rounded-xl">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[11px] font-mono uppercase tracking-widest text-amber-400 font-semibold">
              Live AI Operations
            </span>
            <span className="text-neutral-600">·</span>
            <span className="text-[11px] text-neutral-400">Customer Support & Lead Capture</span>
          </div>
          <h2 className="text-lg font-bold text-neutral-100 flex items-center gap-2">
            <Bot className="w-5 h-5 text-amber-400" />
            <span>24/7 AI Chatbot & Lead Engine</span>
          </h2>
          <p className="text-xs text-neutral-400 mt-1">
            Real customer interactions, captured inquiries, and conversion events across your generated websites.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Project selector filter */}
          <div className="flex items-center gap-2">
            <label className="text-xs text-neutral-400">Filter:</label>
            <select
              value={filterProject}
              onChange={(e) => setFilterProject(e.target.value)}
              className="bg-neutral-950 border border-neutral-800 text-xs rounded-lg px-3 py-1.5 text-neutral-200 focus:outline-none focus:border-amber-500"
            >
              <option value="all">All Websites ({projects.length})</option>
              {projects.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.business.name}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={loadData}
            title="Refresh Data"
            className="p-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 transition-colors"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          </button>

          {leads.length > 0 && (
            <button
              onClick={handleExportLeadsCsv}
              className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
          )}
        </div>
      </div>

      {/* METRICS ROW - NO FAKE DATA */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-neutral-400 text-xs mb-2">
            <span>Chatbot Conversations</span>
            <MessageSquare className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-neutral-100">
            {totalConversations}
          </div>
          <div className="text-[10px] text-neutral-500 mt-1">Total visitor sessions</div>
        </div>

        <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-neutral-400 text-xs mb-2">
            <span>Leads Captured</span>
            <Users className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-emerald-400">
            {leadsCaptured}
          </div>
          <div className="text-[10px] text-neutral-500 mt-1">Verified contact submissions</div>
        </div>

        <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-neutral-400 text-xs mb-2">
            <span>Active Conversations</span>
            <Clock className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-amber-400">
            {activeConversations}
          </div>
          <div className="text-[10px] text-neutral-500 mt-1">In-flight assistant dialogues</div>
        </div>

        <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-neutral-400 text-xs mb-2">
            <span>Conversion Events</span>
            <Zap className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-purple-400">
            {conversionEvents}
          </div>
          <div className="text-[10px] text-neutral-500 mt-1">Quote & appointment leads</div>
        </div>
      </div>

      {/* AI STATUS BANNER & PRIVACY NOTICE */}
      <div className="p-3.5 rounded-xl bg-neutral-900/60 border border-neutral-800 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          {status?.configured ? (
            <span className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-mono text-[11px]">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              AI Assistant Available 24/7 (Google Gemini Server)
            </span>
          ) : (
            <span className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20 font-mono text-[11px]">
              <AlertCircle className="w-3.5 h-3.5" />
              AI Chatbot Not Configured (API key missing on server)
            </span>
          )}
          <span className="text-neutral-500">|</span>
          <span className="text-neutral-400 text-[11px]">
            Model: {status?.model || 'Deterministic Failsafe'}
          </span>
        </div>

        <div className="flex items-center gap-1.5 text-neutral-400 text-[11px]">
          <Shield className="w-3.5 h-3.5 text-emerald-500" />
          <span>Privacy Compliant · Isolated Client Data · GDPR Deletion Enabled</span>
        </div>
      </div>

      {/* TAB SELECTOR & SEARCH */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-neutral-800 pb-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('leads')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-2 ${
              activeTab === 'leads'
                ? 'bg-amber-400 text-neutral-950 font-bold'
                : 'bg-neutral-900 text-neutral-300 hover:bg-neutral-800'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Captured Leads ({leads.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('conversations')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-2 ${
              activeTab === 'conversations'
                ? 'bg-amber-400 text-neutral-950 font-bold'
                : 'bg-neutral-900 text-neutral-300 hover:bg-neutral-800'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Conversations ({conversations.length})</span>
          </button>
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-neutral-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search leads or messages..."
            className="w-full bg-neutral-900 border border-neutral-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-amber-500"
          />
        </div>
      </div>

      {/* LEADS TAB */}
      {activeTab === 'leads' && (
        <div className="bg-neutral-900 border border-neutral-800 rounded-xl overflow-hidden shadow-xl">
          {filteredLeads.length === 0 ? (
            <div className="p-12 text-center text-neutral-400 space-y-2">
              <Users className="w-8 h-8 mx-auto text-neutral-600 mb-2" />
              <div className="text-sm font-semibold text-neutral-300">No leads captured yet</div>
              <p className="text-xs text-neutral-500 max-w-sm mx-auto">
                When visitors ask for quotes, booking, or contact requests via the website AI chatbot, their details will appear here securely.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-neutral-950/70 text-neutral-400 uppercase tracking-wider font-semibold border-b border-neutral-800">
                  <tr>
                    <th className="py-3 px-4">Date</th>
                    <th className="py-3 px-4">Contact Details</th>
                    <th className="py-3 px-4">Website / Client</th>
                    <th className="py-3 px-4">Interested Service</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-800 text-neutral-200">
                  {filteredLeads.map((lead) => (
                    <tr key={lead.id} className="hover:bg-neutral-800/50 transition-colors">
                      <td className="py-3 px-4 text-neutral-400 font-mono text-[11px] whitespace-nowrap">
                        {new Date(lead.date).toLocaleDateString([], {
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-neutral-100">{lead.name}</div>
                        <div className="flex items-center gap-2 text-[11px] text-neutral-400 mt-0.5">
                          {lead.email && (
                            <a href={`mailto:${lead.email}`} className="hover:text-amber-400 flex items-center gap-1">
                              <Mail className="w-3 h-3 text-neutral-500" />
                              <span>{lead.email}</span>
                            </a>
                          )}
                          {lead.phone && (
                            <a href={`tel:${lead.phone}`} className="hover:text-emerald-400 flex items-center gap-1">
                              <Phone className="w-3 h-3 text-neutral-500" />
                              <span>{lead.phone}</span>
                            </a>
                          )}
                        </div>
                      </td>
                      <td className="py-3 px-4 text-neutral-300 font-medium">
                        {lead.websiteName}
                      </td>
                      <td className="py-3 px-4">
                        {lead.interestedService ? (
                          <span className="px-2 py-0.5 rounded bg-neutral-800 text-neutral-300 text-[11px] border border-neutral-700">
                            {lead.interestedService}
                          </span>
                        ) : (
                          <span className="text-neutral-500 italic text-[11px]">General Inquiry</span>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`inline-block px-2 py-0.5 rounded font-mono text-[10px] uppercase font-semibold ${
                            lead.status === 'new'
                              ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                              : lead.status === 'contacted'
                              ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20'
                              : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          }`}
                        >
                          {lead.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handleDeleteLead(lead.id)}
                            title="Delete Lead (Privacy)"
                            className="p-1 rounded text-neutral-500 hover:text-rose-400 hover:bg-neutral-800 transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* CONVERSATIONS TAB */}
      {activeTab === 'conversations' && (
        <div className="bg-neutral-900 border border-neutral-800 rounded-xl overflow-hidden shadow-xl">
          {filteredConversations.length === 0 ? (
            <div className="p-12 text-center text-neutral-400 space-y-2">
              <MessageSquare className="w-8 h-8 mx-auto text-neutral-600 mb-2" />
              <div className="text-sm font-semibold text-neutral-300">No conversations yet.</div>
              <p className="text-xs text-neutral-500 max-w-sm mx-auto">
                Interactive dialogue sessions between website visitors and the 24/7 AI chatbot will appear here in real time.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-neutral-950/70 text-neutral-400 uppercase tracking-wider font-semibold border-b border-neutral-800">
                  <tr>
                    <th className="py-3 px-4">Date</th>
                    <th className="py-3 px-4">Website</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4">Messages</th>
                    <th className="py-3 px-4">Requested Service</th>
                    <th className="py-3 px-4">Lead Status</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-800 text-neutral-200">
                  {filteredConversations.map((conv) => (
                    <tr key={conv.id} className="hover:bg-neutral-800/50 transition-colors">
                      <td className="py-3 px-4 text-neutral-400 font-mono text-[11px] whitespace-nowrap">
                        {new Date(conv.date).toLocaleDateString([], {
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </td>
                      <td className="py-3 px-4 font-semibold text-neutral-100">
                        {conv.websiteName}
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`inline-block px-2 py-0.5 rounded font-mono text-[10px] uppercase font-semibold ${
                            conv.status === 'lead_captured'
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                              : conv.status === 'completed'
                              ? 'bg-neutral-800 text-neutral-300'
                              : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                          }`}
                        >
                          {conv.status.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-neutral-400 font-mono">
                        {conv.messagesCount || conv.messages?.length || 0} msgs
                      </td>
                      <td className="py-3 px-4 text-neutral-300">
                        {conv.requestedService || 'General Q&A'}
                      </td>
                      <td className="py-3 px-4">
                        {conv.lead ? (
                          <span className="text-emerald-400 flex items-center gap-1 text-[11px]">
                            <CheckCircle className="w-3 h-3" />
                            <span>{conv.lead.name}</span>
                          </span>
                        ) : (
                          <span className="text-neutral-500 text-[11px]">—</span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => setSelectedConversation(conv)}
                            title="Inspect Transcript"
                            className="p-1 rounded text-neutral-300 hover:text-white hover:bg-neutral-800 transition-colors"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteConversation(conv.id)}
                            title="Delete Conversation"
                            className="p-1 rounded text-neutral-500 hover:text-rose-400 hover:bg-neutral-800 transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* CONVERSATION TRANSCRIPT MODAL */}
      {selectedConversation && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="w-full max-w-xl bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl flex flex-col max-h-[85vh] overflow-hidden">
            <div className="p-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-950">
              <div>
                <h3 className="font-bold text-sm text-neutral-100 flex items-center gap-2">
                  <Bot className="w-4 h-4 text-amber-400" />
                  <span>Conversation Transcript</span>
                </h3>
                <div className="text-[11px] text-neutral-400 mt-0.5">
                  {selectedConversation.websiteName} · {new Date(selectedConversation.date).toLocaleString()}
                </div>
              </div>
              <button
                onClick={() => setSelectedConversation(null)}
                className="p-1 rounded-lg text-neutral-400 hover:text-neutral-100 hover:bg-neutral-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {selectedConversation.lead && (
              <div className="bg-emerald-950/30 border-b border-emerald-800/40 p-3 text-xs flex items-center justify-between">
                <div>
                  <div className="font-semibold text-emerald-300">Captured Lead Details:</div>
                  <div className="text-neutral-300 text-[11px]">
                    {selectedConversation.lead.name} · {selectedConversation.lead.email || selectedConversation.lead.phone}
                  </div>
                </div>
                {selectedConversation.requestedService && (
                  <span className="px-2 py-0.5 rounded bg-emerald-900/60 text-emerald-300 text-[10px] font-mono">
                    {selectedConversation.requestedService}
                  </span>
                )}
              </div>
            )}

            <div className="flex-1 overflow-y-auto p-4 space-y-3 text-xs">
              {selectedConversation.messages && selectedConversation.messages.length > 0 ? (
                selectedConversation.messages.map((m, idx) => (
                  <div
                    key={idx}
                    className={`flex flex-col ${
                      m.role === 'user' ? 'items-end' : 'items-start'
                    }`}
                  >
                    <div className="text-[10px] text-neutral-500 uppercase font-mono mb-0.5">
                      {m.role === 'user' ? 'Visitor' : 'AI Assistant'}
                    </div>
                    <div
                      className={`max-w-[85%] rounded-xl px-3 py-2 leading-relaxed ${
                        m.role === 'user'
                          ? 'bg-neutral-200 text-neutral-950 font-medium'
                          : 'bg-neutral-800 text-neutral-200 border border-neutral-700/60'
                      }`}
                    >
                      {m.content}
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center text-neutral-500 py-8">
                  No individual messages recorded in this session.
                </div>
              )}
            </div>

            <div className="p-3 border-t border-neutral-800 bg-neutral-950 flex items-center justify-between">
              <span className="text-[11px] text-neutral-500 font-mono">
                ID: {selectedConversation.id}
              </span>
              <button
                onClick={() => setSelectedConversation(null)}
                className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-neutral-200"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
