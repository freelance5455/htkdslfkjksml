import React, { useState, useEffect, useRef } from 'react';
import { 
  MessageCircle, 
  Sparkles, 
  Headphones, 
  Bot, 
  X, 
  Send, 
  Phone, 
  Calendar, 
  MapPin, 
  Mail, 
  Shield, 
  ChevronRight, 
  RotateCcw,
  AlertCircle,
  CheckCircle2,
  ExternalLink
} from 'lucide-react';
import { ChatbotConfig, ChatMessage, ChatbotLead } from '../../types/chatbot';
import { BusinessInfo } from '../../types/website';
import { chatbotProvider, ChatbotStatus } from '../../services/chatbotProvider';

interface WebsiteChatbotWidgetProps {
  config?: ChatbotConfig;
  business: BusinessInfo;
  brandPrimaryColor?: string;
  projectId?: string;
  previewMode?: boolean; // in studio preview vs published
}

export const WebsiteChatbotWidget: React.FC<WebsiteChatbotWidgetProps> = ({
  config,
  business,
  brandPrimaryColor = '#d97706', // default warm amber/gold
  projectId = 'default',
  previewMode = false,
}) => {
  // If explicitly disabled, don't render
  if (config && config.enabled === false) {
    return null;
  }

  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [status, setStatus] = useState<ChatbotStatus | null>(null);
  const [showLeadForm, setShowLeadForm] = useState(false);
  const [leadCaptured, setLeadCaptured] = useState(false);
  const [conversationId, setConversationId] = useState<string>(() => `conv_${Date.now()}`);

  // Lead Form State
  const [leadName, setLeadName] = useState('');
  const [leadEmail, setLeadEmail] = useState('');
  const [leadPhone, setLeadPhone] = useState('');
  const [leadWhatsApp, setLeadWhatsApp] = useState('');
  const [leadService, setLeadService] = useState('');
  const [leadMessage, setLeadMessage] = useState('');
  const [leadSubmitting, setLeadSubmitting] = useState(false);
  const [leadError, setLeadError] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const businessName = config?.businessName || business.name || 'Business';
  const themeColor = config?.color || brandPrimaryColor || '#d97706';
  const position = config?.position || 'bottom-right';

  // Check provider status on mount
  useEffect(() => {
    chatbotProvider.getStatus().then((s) => {
      setStatus(s);
    });
  }, []);

  // Initialize conversation when opened
  useEffect(() => {
    if (isOpen && messages.length === 0) {
      chatbotProvider.initializeChat(
        config || {
          enabled: true,
          businessName,
          businessDescription: business.description,
          tone: 'professional',
          customGreeting: '',
          welcomeMessage: '',
          color: themeColor,
          iconStyle: 'message-circle',
          position: 'bottom-right',
          suggestedQuestions: [
            'What services do you offer?',
            'How can I book an appointment?',
            'Where are you located?',
            'How can I contact you?'
          ],
          conversionButtons: {
            callNow: true,
            whatsapp: Boolean(business.whatsapp),
            bookAppointment: true,
            requestQuote: true,
            contactUs: true,
            visitLocation: Boolean(business.location),
          },
        },
        business,
        projectId
      ).then((initData) => {
        setMessages([
          {
            id: `msg_welcome_${Date.now()}`,
            role: 'assistant',
            content: initData.welcomeMessage,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            suggestedQuestions: initData.suggestedQuestions,
          },
        ]);
      });
    }
  }, [isOpen, config, business, businessName, themeColor, projectId, messages.length]);

  // Scroll to bottom when messages update
  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isLoading, showLeadForm]);

  // Focus input when opened
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 200);
    }
  }, [isOpen]);

  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend || inputValue).trim();
    if (!text || isLoading) return;

    const userMsg: ChatMessage = {
      id: `msg_u_${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const newHistory = [...messages, userMsg];
    setMessages(newHistory);
    setInputValue('');
    setIsLoading(true);

    const businessContext = chatbotProvider.getBusinessContext(
      config || {
        enabled: true,
        businessName,
        businessDescription: business.description,
        tone: 'professional',
        customGreeting: '',
        welcomeMessage: '',
        color: themeColor,
        iconStyle: 'message-circle',
        position: 'bottom-right',
        suggestedQuestions: [],
        conversionButtons: {
          callNow: true,
          whatsapp: true,
          bookAppointment: true,
          requestQuote: true,
          contactUs: true,
          visitLocation: true,
        },
      },
      business
    );

    const result = await chatbotProvider.sendMessage(text, newHistory, businessContext, {
      projectId,
      websiteName: businessName,
    });

    setIsLoading(false);

    const assistantMsg: ChatMessage = {
      id: `msg_a_${Date.now()}`,
      role: 'assistant',
      content: result.reply,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isLeadCard: result.shouldOfferLeadCapture,
    };

    const finalMessages = [...newHistory, assistantMsg];
    setMessages(finalMessages);

    if (result.shouldOfferLeadCapture) {
      setShowLeadForm(true);
    }

    // Record conversation in background
    chatbotProvider.endConversation(conversationId, {
      projectId,
      websiteName: businessName,
      messages: finalMessages,
      status: result.shouldOfferLeadCapture ? 'lead_captured' : 'active',
      requestedService: result.relevantServices?.[0],
    });
  };

  const handleLeadSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!leadName.trim()) {
      setLeadError('Please provide your name.');
      return;
    }
    if (!leadEmail.trim() && !leadPhone.trim()) {
      setLeadError('Please provide either an email or phone number.');
      return;
    }

    setLeadSubmitting(true);
    setLeadError(null);

    const res = await chatbotProvider.collectLead({
      projectId,
      websiteName: businessName,
      name: leadName.trim(),
      email: leadEmail.trim(),
      phone: leadPhone.trim(),
      whatsapp: leadWhatsApp.trim() || undefined,
      interestedService: leadService || undefined,
      message: leadMessage.trim() || undefined,
    });

    setLeadSubmitting(false);

    if (res.success && res.lead) {
      setLeadCaptured(true);
      setShowLeadForm(false);
      
      const confirmMsg: ChatMessage = {
        id: `msg_confirm_${Date.now()}`,
        role: 'assistant',
        content: `Thank you, ${leadName.trim()}! Your inquiry has been sent directly to the team at ${businessName}. We will be in touch shortly.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      const updatedMessages = [...messages, confirmMsg];
      setMessages(updatedMessages);

      chatbotProvider.endConversation(conversationId, {
        projectId,
        websiteName: businessName,
        messages: updatedMessages,
        status: 'lead_captured',
        lead: res.lead,
        requestedService: leadService,
      });
    } else {
      setLeadError(res.error || 'Failed to submit details. Please contact us directly.');
    }
  };

  const handleResetConversation = () => {
    setConversationId(`conv_${Date.now()}`);
    setMessages([]);
    setShowLeadForm(false);
    setLeadCaptured(false);
  };

  // Icon mapping
  const renderIcon = (style?: string) => {
    switch (style) {
      case 'sparkles':
        return <Sparkles className="w-5 h-5" />;
      case 'headset':
        return <Headphones className="w-5 h-5" />;
      case 'bot':
        return <Bot className="w-5 h-5" />;
      case 'message-circle':
      default:
        return <MessageCircle className="w-5 h-5" />;
    }
  };

  // Conversion actions
  const conversionConfig = config?.conversionButtons || {
    callNow: true,
    whatsapp: Boolean(business.whatsapp),
    bookAppointment: true,
    requestQuote: true,
    contactUs: true,
    visitLocation: Boolean(business.location),
  };

  const hasPhone = Boolean(business.phone);
  const hasWhatsapp = Boolean(business.whatsapp);
  const hasLocation = Boolean(business.location);
  const hasBookingUrl = Boolean(config?.bookingUrl);

  const cleanPhone = business.phone ? business.phone.replace(/[^0-9+]/g, '') : '';
  const cleanWa = business.whatsapp ? business.whatsapp.replace(/[^0-9]/g, '') : '';

  return (
    <div
      className={`fixed z-50 transition-all duration-300 font-sans ${
        position === 'bottom-left' ? 'left-4 sm:left-6' : 'right-4 sm:right-6'
      } bottom-4 sm:bottom-6`}
    >
      {/* CHAT PANEL */}
      {isOpen && (
        <div 
          className="w-[calc(100vw-2rem)] sm:w-[380px] md:w-[410px] h-[580px] max-h-[calc(100vh-6rem)] bg-neutral-900 text-neutral-100 rounded-2xl shadow-2xl border border-neutral-800 flex flex-col overflow-hidden mb-3 animate-in fade-in slide-in-from-bottom-5 duration-200"
          style={{
            boxShadow: '0 20px 40px -15px rgba(0,0,0,0.5), 0 0 0 1px rgba(255,255,255,0.06)'
          }}
        >
          {/* HEADER */}
          <div 
            className="p-4 border-b border-neutral-800 flex items-center justify-between text-neutral-100 relative overflow-hidden"
            style={{
              backgroundColor: '#171717',
              borderTop: `3px solid ${themeColor}`
            }}
          >
            <div className="flex items-center gap-3">
              <div 
                className="w-9 h-9 rounded-full flex items-center justify-center text-neutral-950 font-bold shadow-md"
                style={{ backgroundColor: themeColor }}
              >
                {renderIcon(config?.iconStyle)}
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h3 className="text-sm font-bold text-neutral-100 tracking-tight leading-snug">
                    {businessName} Assistant
                  </h3>
                </div>

                {/* 24/7 Availability badge - Grounded in actual status */}
                <div className="flex items-center gap-1.5 mt-0.5">
                  {status?.configured ? (
                    <span className="flex items-center gap-1 text-[11px] font-medium text-emerald-400">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                      AI assistant available 24/7
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 text-[11px] font-medium text-neutral-400">
                      <span className="w-1.5 h-1.5 rounded-full bg-neutral-500" />
                      AI chatbot not configured
                    </span>
                  )}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={handleResetConversation}
                title="Restart Conversation"
                className="p-1.5 rounded-lg text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800 transition-colors"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
              <button
                onClick={() => setIsOpen(false)}
                title="Close Chat"
                className="p-1.5 rounded-lg text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* QUICK DIRECT CONVERSION BAR */}
          <div className="bg-neutral-950/80 px-3 py-2 border-b border-neutral-800/80 flex items-center gap-1.5 overflow-x-auto no-scrollbar text-xs">
            {conversionConfig.callNow && hasPhone && (
              <a
                href={`tel:${cleanPhone}`}
                className="flex items-center gap-1 px-2.5 py-1 rounded-md bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-[11px] font-medium whitespace-nowrap transition-colors"
              >
                <Phone className="w-3 h-3 text-emerald-400" />
                Call Now
              </a>
            )}
            {conversionConfig.whatsapp && hasWhatsapp && (
              <a
                href={`https://wa.me/${cleanWa}`}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1 px-2.5 py-1 rounded-md bg-emerald-950/60 border border-emerald-800/60 hover:bg-emerald-900/60 text-emerald-300 text-[11px] font-medium whitespace-nowrap transition-colors"
              >
                <MessageCircle className="w-3 h-3 text-emerald-400" />
                WhatsApp
              </a>
            )}
            {conversionConfig.bookAppointment && (
              <a
                href={hasBookingUrl ? config?.bookingUrl : '#contact'}
                target={hasBookingUrl ? '_blank' : undefined}
                rel={hasBookingUrl ? 'noreferrer' : undefined}
                className="flex items-center gap-1 px-2.5 py-1 rounded-md bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-[11px] font-medium whitespace-nowrap transition-colors"
              >
                <Calendar className="w-3 h-3" style={{ color: themeColor }} />
                Book
              </a>
            )}
            {conversionConfig.requestQuote && !leadCaptured && (
              <button
                onClick={() => setShowLeadForm(!showLeadForm)}
                className="flex items-center gap-1 px-2.5 py-1 rounded-md bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-[11px] font-medium whitespace-nowrap transition-colors"
              >
                <Mail className="w-3 h-3 text-amber-400" />
                Get Quote
              </button>
            )}
            {conversionConfig.visitLocation && hasLocation && (
              <a
                href={`https://maps.google.com/?q=${encodeURIComponent(business.location)}`}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1 px-2.5 py-1 rounded-md bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-[11px] font-medium whitespace-nowrap transition-colors"
              >
                <MapPin className="w-3 h-3 text-cyan-400" />
                Directions
              </a>
            )}
          </div>

          {/* MESSAGES SCROLL AREA */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3.5 text-xs">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex flex-col ${
                  msg.role === 'user' ? 'items-end' : 'items-start'
                }`}
              >
                <div
                  className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 leading-relaxed shadow-sm ${
                    msg.role === 'user'
                      ? 'bg-neutral-200 text-neutral-950 font-medium rounded-tr-sm'
                      : 'bg-neutral-800/90 text-neutral-200 border border-neutral-700/60 rounded-tl-sm'
                  }`}
                >
                  <p className="whitespace-pre-wrap">{msg.content}</p>

                  {/* Optional suggested questions chips on welcome message */}
                  {msg.suggestedQuestions && msg.suggestedQuestions.length > 0 && (
                    <div className="mt-3 pt-2.5 border-t border-neutral-700/60 flex flex-col gap-1.5">
                      <span className="text-[10px] text-neutral-400 uppercase tracking-wider font-semibold">
                        Suggested questions:
                      </span>
                      {msg.suggestedQuestions.map((q, idx) => (
                        <button
                          key={idx}
                          onClick={() => handleSendMessage(q)}
                          disabled={isLoading}
                          className="text-left text-[11px] px-2.5 py-1.5 rounded-lg bg-neutral-900/80 hover:bg-neutral-700/80 border border-neutral-700/50 text-neutral-300 transition-colors flex items-center justify-between group"
                        >
                          <span>{q}</span>
                          <ChevronRight className="w-3 h-3 text-neutral-500 group-hover:text-neutral-200" />
                        </button>
                      ))}
                    </div>
                  )}
                </div>
                <span className="text-[10px] text-neutral-500 mt-1 px-1">
                  {msg.timestamp}
                </span>
              </div>
            ))}

            {/* TYPING INDICATOR */}
            {isLoading && (
              <div className="flex items-center gap-1.5 p-2 bg-neutral-800/80 rounded-xl w-16 border border-neutral-700/50">
                <span className="w-1.5 h-1.5 rounded-full bg-neutral-400 animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-1.5 h-1.5 rounded-full bg-neutral-400 animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-1.5 h-1.5 rounded-full bg-neutral-400 animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            )}

            {/* INTERACTIVE LEAD CAPTURE FORM (OFFERED IN-LINE) */}
            {showLeadForm && !leadCaptured && (
              <div className="bg-neutral-950 border border-neutral-700/80 rounded-xl p-3.5 shadow-lg space-y-2.5 my-2">
                <div className="flex items-center justify-between border-b border-neutral-800 pb-2">
                  <div className="flex items-center gap-1.5 text-neutral-100 font-semibold text-xs">
                    <Mail className="w-3.5 h-3.5" style={{ color: themeColor }} />
                    <span>{config?.leadCapturePrompt || 'Would you like us to contact you?'}</span>
                  </div>
                  <button
                    onClick={() => setShowLeadForm(false)}
                    className="text-neutral-500 hover:text-neutral-300 p-0.5"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>

                <form onSubmit={handleLeadSubmit} className="space-y-2">
                  {leadError && (
                    <div className="text-[11px] text-rose-400 bg-rose-950/40 border border-rose-800/50 p-1.5 rounded">
                      {leadError}
                    </div>
                  )}

                  <div>
                    <label className="text-[10px] uppercase tracking-wider text-neutral-400 block mb-0.5">Your Name *</label>
                    <input
                      type="text"
                      required
                      value={leadName}
                      onChange={(e) => setLeadName(e.target.value)}
                      placeholder="e.g. John Doe"
                      className="w-full bg-neutral-900 border border-neutral-800 rounded px-2 py-1.5 text-xs text-neutral-100 focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[10px] uppercase tracking-wider text-neutral-400 block mb-0.5">Email</label>
                      <input
                        type="email"
                        value={leadEmail}
                        onChange={(e) => setLeadEmail(e.target.value)}
                        placeholder="john@example.com"
                        className="w-full bg-neutral-900 border border-neutral-800 rounded px-2 py-1.5 text-xs text-neutral-100 focus:outline-none focus:border-amber-500"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] uppercase tracking-wider text-neutral-400 block mb-0.5">Phone</label>
                      <input
                        type="tel"
                        value={leadPhone}
                        onChange={(e) => setLeadPhone(e.target.value)}
                        placeholder="+1 (555) 000-0000"
                        className="w-full bg-neutral-900 border border-neutral-800 rounded px-2 py-1.5 text-xs text-neutral-100 focus:outline-none focus:border-amber-500"
                      />
                    </div>
                  </div>

                  {business.services && business.services.length > 0 && (
                    <div>
                      <label className="text-[10px] uppercase tracking-wider text-neutral-400 block mb-0.5">Interested Service</label>
                      <select
                        value={leadService}
                        onChange={(e) => setLeadService(e.target.value)}
                        className="w-full bg-neutral-900 border border-neutral-800 rounded px-2 py-1.5 text-xs text-neutral-100 focus:outline-none focus:border-amber-500"
                      >
                        <option value="">Select a service...</option>
                        {business.services.map((srv: any, i: number) => {
                          const title = typeof srv === 'string' ? srv : srv.title;
                          return <option key={i} value={title}>{title}</option>;
                        })}
                      </select>
                    </div>
                  )}

                  <div>
                    <label className="text-[10px] uppercase tracking-wider text-neutral-400 block mb-0.5">Message (Optional)</label>
                    <textarea
                      rows={2}
                      value={leadMessage}
                      onChange={(e) => setLeadMessage(e.target.value)}
                      placeholder="Tell us what you're looking for..."
                      className="w-full bg-neutral-900 border border-neutral-800 rounded px-2 py-1.5 text-xs text-neutral-100 focus:outline-none focus:border-amber-500 resize-none"
                    />
                  </div>

                  <div className="flex items-center gap-1.5 text-[10px] text-neutral-400 pt-1">
                    <Shield className="w-3 h-3 text-neutral-500 shrink-0" />
                    <span>Your details are kept strictly private and sent only to {businessName}.</span>
                  </div>

                  <button
                    type="submit"
                    disabled={leadSubmitting}
                    className="w-full py-2 rounded font-semibold text-xs text-neutral-950 transition-all flex items-center justify-center gap-1.5 disabled:opacity-50"
                    style={{ backgroundColor: themeColor }}
                  >
                    {leadSubmitting ? (
                      <span>Sending inquiry...</span>
                    ) : (
                      <>
                        <span>Submit Details</span>
                        <CheckCircle2 className="w-3.5 h-3.5" />
                      </>
                    )}
                  </button>
                </form>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* INPUT FORM */}
          <div className="p-3 bg-neutral-950 border-t border-neutral-800">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage();
              }}
              className="flex items-center gap-2"
            >
              <input
                ref={inputRef}
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="Ask about services, hours, or quotes..."
                disabled={isLoading}
                className="flex-1 bg-neutral-900 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-xs text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-neutral-600 disabled:opacity-50"
              />
              <button
                type="submit"
                disabled={isLoading || !inputValue.trim()}
                className="w-9 h-9 rounded-xl flex items-center justify-center text-neutral-950 transition-all disabled:opacity-30 disabled:cursor-not-allowed shrink-0"
                style={{ backgroundColor: themeColor }}
                title="Send Message"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
            
            {/* Knowledge Privacy Notice - Client branding only */}
            <div className="text-[10px] text-center text-neutral-500 mt-2">
              Responses based strictly on verified {businessName} details.
            </div>
          </div>
        </div>
      )}

      {/* FLOATING TRIGGER BUTTON */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        aria-label="Open AI Assistant"
        className="flex items-center gap-2.5 px-4 py-3 rounded-full text-neutral-950 font-bold shadow-2xl transition-all transform hover:scale-105 active:scale-95 group focus:outline-none"
        style={{
          backgroundColor: themeColor,
          boxShadow: `0 10px 25px -5px ${themeColor}66`,
        }}
      >
        <span className="relative flex items-center justify-center">
          {isOpen ? (
            <X className="w-5 h-5 text-neutral-950" />
          ) : (
            renderIcon(config?.iconStyle)
          )}
          {status?.configured && !isOpen && (
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-500 rounded-full border-2 border-white animate-pulse" />
          )}
        </span>

        {config?.buttonLabel ? (
          <span className="text-xs font-bold tracking-tight">
            {config.buttonLabel}
          </span>
        ) : (
          <span className="text-xs font-bold tracking-tight hidden sm:inline">
            Chat with {businessName}
          </span>
        )}
      </button>
    </div>
  );
};
