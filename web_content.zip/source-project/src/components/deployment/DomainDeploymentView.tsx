import React, { useState } from 'react';
import { useProjects } from '../../context/ProjectContext';
import { deploymentService } from '../../services/deploymentProvider';
import { 
  Globe, 
  Check, 
  Copy, 
  RefreshCw, 
  ExternalLink, 
  ShieldCheck, 
  AlertTriangle, 
  Layers, 
  ArrowRight,
  Server,
  Lock,
  Clock,
  Sparkles
} from 'lucide-react';

export const DomainDeploymentView: React.FC = () => {
  const { activeProject, updateProject, projects, setActiveProject } = useProjects();
  
  const [selectedProviderId, setSelectedProviderId] = useState<string>('manual');
  const [customDomainInput, setCustomDomainInput] = useState<string>(
    activeProject?.deployment?.customDomain || ''
  );
  const [isVerifying, setIsVerifying] = useState<boolean>(false);
  const [verificationFeedback, setVerificationFeedback] = useState<string | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!activeProject) {
    return (
      <div className="p-12 text-center text-neutral-400">
        <p>No active project selected. Select a project to configure deployment.</p>
      </div>
    );
  }

  const deployment = activeProject.deployment;
  const providers = deploymentService.listProviders();
  const currentProvider = deploymentService.getProvider(selectedProviderId);

  const handleSaveDomain = async () => {
    if (!customDomainInput.trim()) {
      alert('Please enter a custom domain (e.g. acmeconsulting.com)');
      return;
    }

    const clean = customDomainInput.replace(/^https?:\/\//, '').replace(/\/.*$/, '').trim();
    const records = await currentProvider.addCustomDomain(clean);

    updateProject({
      ...activeProject,
      deployment: {
        ...activeProject.deployment,
        customDomain: clean,
        dnsRecords: records,
        dnsStatus: 'pending',
      },
    });

    setVerificationFeedback('Custom domain saved. Please add the required DNS records at your domain registrar.');
  };

  const handleCheckDns = async () => {
    if (!deployment.customDomain) {
      alert('Please configure a custom domain first.');
      return;
    }

    setIsVerifying(true);
    setVerificationFeedback(null);

    try {
      const result = await currentProvider.verifyCustomDomain(deployment.customDomain);
      
      updateProject({
        ...activeProject,
        deployment: {
          ...activeProject.deployment,
          verified: result.verified,
          httpsActive: result.httpsActive,
          lastDnsCheck: new Date().toISOString(),
          dnsStatus: result.verified ? 'propagated' : 'pending',
        },
      });

      setVerificationFeedback(result.statusText);
    } catch (err: any) {
      setVerificationFeedback(`DNS Query Exception: ${err.message}`);
    } finally {
      setIsVerifying(false);
    }
  };

  const handleMarkLive = () => {
    updateProject({
      ...activeProject,
      status: 'live',
      updatedAt: new Date().toISOString(),
    });
    alert(`Success: ${activeProject.name} is now marked as LIVE production.`);
  };

  const handleCopyText = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-8">
      
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 mb-1">
          <span className="text-[11px] font-mono uppercase tracking-wider text-amber-400 font-semibold">
            Infrastructure & DNS Engine
          </span>
          <span className="text-neutral-600">·</span>
          <span className="text-xs text-neutral-400">10-Step Agency Deployment Pipeline</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-neutral-100 tracking-tight">
          Domain & Production Deployment
        </h1>
        <p className="text-xs sm:text-sm text-neutral-400 mt-1">
          Connect your client’s custom domain, configure nameservers and DNS records, and track live SSL certificate issuance.
        </p>
      </div>

      {/* 10-Step Visual Flow Progress */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-5 shadow-lg">
        <span className="text-[10px] uppercase font-mono tracking-wider text-neutral-400 font-semibold block mb-3">
          Agency Production Checklist
        </span>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs">
          {[
            { step: '1. Build Website', done: true },
            { step: '2. Client Preview', done: true },
            { step: '3. Staging Deploy', done: true },
            { step: '4. Deployment URL', done: true },
            { step: '5. Custom Domain', done: Boolean(deployment.customDomain) },
            { step: '6. DNS Records', done: deployment.dnsRecords.length > 0 },
            { step: '7. Verify DNS', done: deployment.verified },
            { step: '8. Connect Domain', done: deployment.verified },
            { step: '9. Confirm HTTPS', done: deployment.httpsActive },
            { step: '10. Mark LIVE', done: activeProject.status === 'live' },
          ].map((item, idx) => (
            <div
              key={idx}
              className={`p-2.5 rounded-lg border flex items-center justify-between transition-all ${
                item.done
                  ? 'bg-emerald-500/5 border-emerald-500/30 text-emerald-300'
                  : 'bg-neutral-950 border-neutral-800 text-neutral-500'
              }`}
            >
              <span className="truncate text-[11px] font-medium">{item.step}</span>
              {item.done ? (
                <Check className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
              ) : (
                <Clock className="w-3 h-3 text-neutral-600 flex-shrink-0" />
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Main Workspace Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Domain & Provider Settings */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Card 1: Staging & Deployment Endpoint */}
          <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <Server className="w-4 h-4 text-amber-400" />
                <span>Active Deployment Endpoint</span>
              </h2>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-semibold">
                EDGE ACTIVE
              </span>
            </div>

            <div>
              <label className="block text-[11px] text-neutral-400 uppercase tracking-wider font-semibold mb-1">
                Staging Preview URL
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  readOnly
                  value={deployment.deploymentUrl}
                  className="flex-1 px-3 py-2 rounded bg-neutral-950 border border-neutral-800 text-xs font-mono text-neutral-300"
                />
                <button
                  onClick={() => handleCopyText(deployment.deploymentUrl, 'deploy-url')}
                  className="px-3 py-2 rounded bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-semibold flex items-center gap-1"
                >
                  {copiedKey === 'deploy-url' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>Copy</span>
                </button>
              </div>
            </div>
          </div>

          {/* Card 2: Custom Domain Assignment */}
          <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-6 shadow-sm space-y-4">
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-2 mb-1">
                <Globe className="w-4 h-4 text-cyan-400" />
                <span>Client Custom Domain Configuration</span>
              </h2>
              <p className="text-xs text-neutral-400">
                Enter your client’s purchased domain (e.g. <code className="text-neutral-300">company.com</code>).
              </p>
            </div>

            <div>
              <label className="block text-[11px] text-neutral-400 uppercase tracking-wider font-semibold mb-1">
                Client Domain Name
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={customDomainInput}
                  onChange={(e) => setCustomDomainInput(e.target.value)}
                  placeholder="e.g. auradentalclinic.com"
                  className="flex-1 px-3.5 py-2.5 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-amber-500 font-mono"
                />
                <button
                  onClick={handleSaveDomain}
                  className="px-4 py-2.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-neutral-950 text-xs font-bold transition-all shadow active:scale-95"
                >
                  Save Domain
                </button>
              </div>
            </div>

            {/* Hosting Provider Architecture */}
            <div>
              <label className="block text-[11px] text-neutral-400 uppercase tracking-wider font-semibold mb-1">
                Deployment Provider Engine
              </label>
              <div className="grid grid-cols-2 gap-2">
                {providers.map((prv) => (
                  <button
                    key={prv.id}
                    onClick={() => setSelectedProviderId(prv.id)}
                    className={`p-3 rounded-lg border text-left text-xs transition-all ${
                      selectedProviderId === prv.id
                        ? 'bg-amber-500/10 border-amber-500 text-amber-400 font-bold'
                        : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:text-white'
                    }`}
                  >
                    <div>{prv.name}</div>
                    <div className="text-[10px] text-neutral-500 mt-0.5">
                      {prv.isConfigured ? 'Available' : 'Requires API Token'}
                    </div>
                  </button>
                ))}
              </div>
              <div className="text-[11px] text-neutral-500 mt-2">
                Note: We do not fake automatic registrar changes. Follow the manual DNS steps below at GoDaddy, Namecheap, Cloudflare, or Google Domains.
              </div>
            </div>
          </div>

          {/* Card 3: DNS Records Table */}
          {deployment.dnsRecords.length > 0 && (
            <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-6 shadow-sm space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-sm font-bold text-white">Required DNS Records for Client Registrar</h2>
                <button
                  onClick={handleCheckDns}
                  disabled={isVerifying}
                  className="px-3 py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold flex items-center gap-1.5 transition-all disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isVerifying ? 'animate-spin text-amber-400' : ''}`} />
                  <span>{isVerifying ? 'Querying DNS...' : 'Check DNS Records'}</span>
                </button>
              </div>

              {verificationFeedback && (
                <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-neutral-300">
                  <div className="font-semibold text-amber-400 mb-0.5">Verification Report:</div>
                  <div>{verificationFeedback}</div>
                </div>
              )}

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-neutral-950 text-neutral-400 font-mono text-[10px] uppercase border-b border-neutral-800">
                    <tr>
                      <th className="py-2.5 px-3">Type</th>
                      <th className="py-2.5 px-3">Host / Name</th>
                      <th className="py-2.5 px-3">Target Value</th>
                      <th className="py-2.5 px-3">TTL</th>
                      <th className="py-2.5 px-3 text-right">Copy</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-800 text-neutral-300 font-mono">
                    {deployment.dnsRecords.map((rec, idx) => (
                      <tr key={idx} className="hover:bg-neutral-950/40">
                        <td className="py-2.5 px-3 font-bold text-amber-400">{rec.type}</td>
                        <td className="py-2.5 px-3">{rec.name}</td>
                        <td className="py-2.5 px-3 truncate max-w-[200px]">{rec.value}</td>
                        <td className="py-2.5 px-3 text-neutral-500">{rec.ttl}</td>
                        <td className="py-2.5 px-3 text-right">
                          <button
                            onClick={() => handleCopyText(rec.value, `rec-${idx}`)}
                            className="p-1 hover:text-white text-neutral-400"
                            title="Copy Value"
                          >
                            {copiedKey === `rec-${idx}` ? (
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

        </div>

        {/* Right Column: Status & Live Launch */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Status Overview Card */}
          <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-6 shadow-sm space-y-5">
            <h3 className="text-sm font-bold text-white">Live Readiness Overview</h3>

            <div className="space-y-3 text-xs">
              <div className="flex items-center justify-between p-3 rounded-lg bg-neutral-950 border border-neutral-800">
                <span className="text-neutral-400">DNS Resolution</span>
                <span
                  className={`font-mono uppercase font-bold text-[11px] ${
                    deployment.dnsStatus === 'propagated' ? 'text-emerald-400' : 'text-amber-400'
                  }`}
                >
                  {deployment.dnsStatus === 'propagated' ? 'Propagated' : 'Pending Verification'}
                </span>
              </div>

              <div className="flex items-center justify-between p-3 rounded-lg bg-neutral-950 border border-neutral-800">
                <span className="text-neutral-400">SSL / HTTPS Security</span>
                <span className="flex items-center gap-1 font-mono text-[11px] text-emerald-400 font-bold">
                  <Lock className="w-3 h-3" />
                  <span>{deployment.httpsActive ? 'Active (Let\'s Encrypt)' : 'Pending'}</span>
                </span>
              </div>

              <div className="flex items-center justify-between p-3 rounded-lg bg-neutral-950 border border-neutral-800">
                <span className="text-neutral-400">Project Status</span>
                <span className="font-mono uppercase font-bold text-[11px] text-amber-400">
                  {activeProject.status.replace('_', ' ')}
                </span>
              </div>
            </div>

            {/* Launch Website Live Button */}
            <div className="pt-2">
              <button
                onClick={handleMarkLive}
                disabled={activeProject.status === 'live'}
                className="w-full py-3 rounded-lg bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2 transition-all transform active:scale-95 disabled:opacity-50"
              >
                <Check className="w-4 h-4" />
                <span>{activeProject.status === 'live' ? 'Website is Marked LIVE' : 'Mark Website as LIVE'}</span>
              </button>
            </div>
          </div>

          {/* Simple Step-by-Step Guide for Client Registrars */}
          <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-6 shadow-sm space-y-3 text-xs">
            <h3 className="text-sm font-bold text-white">Registrar Configuration Guide</h3>
            <ol className="space-y-2 text-neutral-400 list-decimal list-inside leading-relaxed text-[11px]">
              <li>Log in to your client’s registrar (GoDaddy, Namecheap, Google, etc.).</li>
              <li>Navigate to the **DNS Management** or **DNS Records** screen.</li>
              <li>Add an **A Record** with Host <code className="text-neutral-200">@</code> pointing to <code className="text-neutral-200">76.76.21.21</code>.</li>
              <li>Add a **CNAME Record** with Host <code className="text-neutral-200">www</code> pointing to <code className="text-neutral-200">cname.empire-network.net</code>.</li>
              <li>Save changes and allow between 5 minutes and a few hours for global DNS cache propagation.</li>
              <li>Click **Check DNS Records** above to verify.</li>
            </ol>
          </div>

        </div>

      </div>

    </div>
  );
};
