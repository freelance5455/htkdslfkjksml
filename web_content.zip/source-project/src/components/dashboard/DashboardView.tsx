import React from 'react';
import { useProjects } from '../../context/ProjectContext';
import { 
  FolderKanban, 
  FileEdit, 
  PlayCircle, 
  CheckCircle2, 
  Globe, 
  PlusCircle, 
  ArrowRight, 
  Sparkles, 
  Copy, 
  ExternalLink, 
  Download,
  Calendar,
  Layers,
  ShieldCheck
} from 'lucide-react';
import { downloadProjectZip, generateStandaloneHtml } from '../../services/exportService';
import { PWAInstallButton } from '../common/PWAInstallButton';
import { ShareWebsiteModal } from '../common/ShareWebsiteModal';
import { WebsiteProject } from '../../types/website';

export const DashboardView: React.FC = () => {
  const { projects, setActiveView, setActiveProject, duplicateProject } = useProjects();
  const [shareTarget, setShareTarget] = React.useState<WebsiteProject | null>(null);

  const totalProjects = projects.length;
  const draftCount = projects.filter((p) => p.status === 'draft').length;
  const demoCount = projects.filter((p) => p.status === 'demo').length;
  const reviewCount = projects.filter((p) => p.status === 'client_review' || p.status === 'approved').length;
  const liveCount = projects.filter((p) => p.status === 'live' || p.status === 'ready_to_deploy').length;

  const handleEdit = (project: any) => {
    setActiveProject(project);
    setActiveView('editor');
  };

  const handleDuplicate = (project: any) => {
    const dup = duplicateProject(project.id);
    setActiveProject(dup);
    setActiveView('editor');
  };

  const handleExport = async (project: any) => {
    const blob = await downloadProjectZip(project);
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${project.business.name.toLowerCase().replace(/[^a-z0-9]/g, '-')}-website.zip`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handlePreview = (project: any) => {
    const html = generateStandaloneHtml(project);
    const win = window.open('', '_blank');
    if (win) {
      win.document.write(html);
      win.document.close();
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Studio Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 sm:p-8 rounded-2xl bg-gradient-to-br from-neutral-900 via-neutral-900 to-neutral-950 border border-neutral-800 shadow-xl relative overflow-hidden">
        <div className="relative z-10 max-w-2xl">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-[11px] font-mono uppercase tracking-widest text-amber-400 font-semibold">
              Private Agency Studio
            </span>
            <span className="text-neutral-600">·</span>
            <span className="text-[11px] text-neutral-400">High-Conversion Production Engine</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-neutral-100 tracking-tight leading-tight">
            Money Making Empire — AI Website Builder
          </h1>
          <p className="text-xs sm:text-sm text-neutral-400 mt-2 leading-relaxed">
            Create high-converting, premium client-ready websites. Built for client demos, rapid production deployments, and bespoke web design projects with zero fake data.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 relative z-10">
          <button
            onClick={() => setActiveView('templates')}
            className="px-4 py-2.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold flex items-center gap-1.5 transition-all"
          >
            <Layers className="w-3.5 h-3.5 text-neutral-400" />
            <span>Browse Templates</span>
          </button>
          <button
            onClick={() => setActiveView('wizard')}
            className="px-5 py-2.5 rounded-lg bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-neutral-950 text-xs font-bold flex items-center gap-2 shadow-lg shadow-amber-500/20 transition-all transform active:scale-95"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Quick Create Website</span>
          </button>
        </div>

        <div className="absolute right-0 bottom-0 translate-x-12 translate-y-12 w-64 h-64 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* Android Mobile Install Banner */}
      <PWAInstallButton variant="banner" />

      {/* METRIC CARDS */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 sm:gap-4">
        {[
          { label: 'Total Projects', value: totalProjects, icon: FolderKanban, color: 'text-neutral-100' },
          { label: 'Draft Websites', value: draftCount, icon: FileEdit, color: 'text-neutral-300' },
          { label: 'Demo Websites', value: demoCount, icon: PlayCircle, color: 'text-amber-400' },
          { label: 'Client Reviews', value: reviewCount, icon: CheckCircle2, color: 'text-cyan-400' },
          { label: 'Live / Ready', value: liveCount, icon: Globe, color: 'text-emerald-400' },
        ].map((stat, idx) => {
          const Icon = stat.icon;
          return (
            <div
              key={idx}
              className="p-5 rounded-xl bg-neutral-900 border border-neutral-800 shadow-sm flex flex-col justify-between"
            >
              <div className="flex items-center justify-between mb-3 text-neutral-500">
                <span className="text-xs font-medium">{stat.label}</span>
                <Icon className={`w-4 h-4 ${stat.color}`} />
              </div>
              <div className={`text-2xl sm:text-3xl font-bold font-mono ${stat.color}`}>
                {stat.value}
              </div>
            </div>
          );
        })}
      </div>

      {/* RECENTLY UPDATED WEBSITES TABLE */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-xl overflow-hidden shadow-xl">
        <div className="p-5 border-b border-neutral-800 flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-neutral-100">Recently Updated Websites</h2>
            <p className="text-xs text-neutral-400 mt-0.5">
              Production websites and client demos ready for review or export.
            </p>
          </div>
          <button
            onClick={() => setActiveView('projects')}
            className="text-xs text-amber-400 hover:text-amber-300 font-semibold flex items-center gap-1"
          >
            <span>View All ({projects.length})</span> <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-950/60 text-neutral-400 uppercase tracking-wider font-semibold border-b border-neutral-800">
              <tr>
                <th className="py-3 px-4">Business & Client</th>
                <th className="py-3 px-4">Industry / Archetype</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Readiness</th>
                <th className="py-3 px-4">Last Updated</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/80 text-neutral-200">
              {projects.slice(0, 5).map((p) => {
                const audit = p.qualityReport;
                const score = audit?.overallScore || 90;
                return (
                  <tr key={p.id} className="hover:bg-neutral-800/50 transition-colors group">
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-neutral-100">{p.business.name}</div>
                      <div className="text-[11px] text-neutral-400">{p.clientName}</div>
                    </td>
                    <td className="py-3.5 px-4">
                      <div>{p.business.industry}</div>
                      <div className="text-[10px] text-neutral-500">{p.type}</div>
                    </td>
                    <td className="py-3.5 px-4">
                      <span
                        className={`inline-block px-2 py-0.5 rounded font-mono text-[10px] uppercase font-semibold ${
                          p.status === 'live'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                            : p.status === 'demo'
                            ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                            : p.status === 'client_review'
                            ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20'
                            : 'bg-neutral-800 text-neutral-400'
                        }`}
                      >
                        {p.status.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 font-mono">
                      <span className="flex items-center gap-1.5">
                        <span className={`w-1.5 h-1.5 rounded-full ${score >= 80 ? 'bg-emerald-400' : 'bg-amber-400'}`} />
                        <span>{score}%</span>
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-neutral-400">
                      {new Date(p.updatedAt).toLocaleDateString(undefined, {
                        month: 'short',
                        day: 'numeric',
                      })}
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => handleEdit(p)}
                          className="px-2.5 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-semibold"
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => setShareTarget(p)}
                          title="Share Website"
                          className="px-2 py-1 rounded bg-neutral-950 border border-neutral-800 hover:border-amber-400 text-amber-400 text-xs font-semibold flex items-center gap-1"
                        >
                          <span>🔗 Share</span>
                        </button>
                        <button
                          onClick={() => handlePreview(p)}
                          title="Open Live Preview"
                          className="p-1 rounded text-neutral-400 hover:text-white hover:bg-neutral-800"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDuplicate(p)}
                          title="Duplicate Website"
                          className="p-1 rounded text-neutral-400 hover:text-white hover:bg-neutral-800"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleExport(p)}
                          title="Download ZIP"
                          className="p-1 rounded text-neutral-400 hover:text-white hover:bg-neutral-800"
                        >
                          <Download className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* QUICK AGENCY WORKFLOW SHORTCUTS */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div 
          onClick={() => setActiveView('wizard')}
          className="p-6 rounded-xl bg-neutral-900 border border-neutral-800 hover:border-amber-500/50 cursor-pointer transition-all group"
        >
          <div className="w-10 h-10 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
            <Sparkles className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-sm text-neutral-100 mb-1">New Client Intake</h3>
          <p className="text-xs text-neutral-400">
            Step through our 5-step wizard to compile a tailored, conversion-focused business website in minutes.
          </p>
        </div>

        <div 
          onClick={() => setActiveView('deployment')}
          className="p-6 rounded-xl bg-neutral-900 border border-neutral-800 hover:border-cyan-500/50 cursor-pointer transition-all group"
        >
          <div className="w-10 h-10 rounded-lg bg-cyan-500/10 text-cyan-400 flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
            <Globe className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-sm text-neutral-100 mb-1">Domain & DNS Setup</h3>
          <p className="text-xs text-neutral-400">
            Connect client apex and www custom domains, generate DNS records, and verify live propagation.
          </p>
        </div>

        <div 
          onClick={() => setActiveView('handoff')}
          className="p-6 rounded-xl bg-neutral-900 border border-neutral-800 hover:border-emerald-500/50 cursor-pointer transition-all group"
        >
          <div className="w-10 h-10 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-sm text-neutral-100 mb-1">Client Handoff Portal</h3>
          <p className="text-xs text-neutral-400">
            Generate clean, professional delivery reports and maintenance summaries ready for client signoff.
          </p>
        </div>
      </div>

      {/* SHARE WEBSITE MODAL */}
      <ShareWebsiteModal
        project={shareTarget}
        isOpen={Boolean(shareTarget)}
        onClose={() => setShareTarget(null)}
        onDeployClick={(p) => {
          setActiveProject(p);
          setActiveView('deployment');
        }}
      />

    </div>
  );
};
