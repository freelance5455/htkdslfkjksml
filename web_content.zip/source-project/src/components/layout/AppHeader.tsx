import React from 'react';
import { useProjects } from '../../context/ProjectContext';
import { 
  Sparkles, 
  LayoutDashboard, 
  PlusCircle, 
  FolderKanban, 
  Layers, 
  Image as ImageIcon, 
  Globe, 
  FileCheck, 
  Settings, 
  ExternalLink,
  ChevronDown
} from 'lucide-react';
import { PWAInstallButton } from '../common/PWAInstallButton';
import { AndroidZipButton } from '../common/AndroidZipButton';

export const AppHeader: React.FC = () => {
  const { activeView, setActiveView, projects, activeProject, setActiveProject, aiStatus } = useProjects();

  interface NavItem {
    id: 'dashboard' | 'wizard' | 'projects' | 'templates' | 'assets' | 'deployment' | 'handoff' | 'settings';
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    highlight?: boolean;
    count?: number;
  }

  const navItems: NavItem[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'wizard', label: 'New Website', icon: PlusCircle, highlight: true },
    { id: 'projects', label: 'Projects', icon: FolderKanban, count: projects.length },
    { id: 'templates', label: 'Templates', icon: Layers },
    { id: 'assets', label: 'Assets', icon: ImageIcon },
    { id: 'deployment', label: 'Domain & Deploy', icon: Globe },
    { id: 'handoff', label: 'Client Handoff', icon: FileCheck },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <header className="sticky top-0 z-40 bg-neutral-950/95 backdrop-blur border-b border-neutral-800 text-neutral-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo & Internal Studio Brand */}
          <div className="flex items-center gap-6">
            <button 
              onClick={() => setActiveView('dashboard')}
              className="flex items-center gap-3 group text-left focus:outline-none"
            >
              <div className="w-9 h-9 rounded-lg bg-neutral-900 border border-amber-500/30 flex items-center justify-center text-neutral-950 font-extrabold shadow-sm shadow-amber-500/20 group-hover:scale-105 transition-transform overflow-hidden">
                <img src="/pwa-192x192.png" alt="Money Making Empire" className="w-full h-full object-cover" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-sm tracking-wide text-neutral-100 uppercase">Money Making Empire</span>
                  <span className="text-[10px] tracking-wider uppercase px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20 font-mono">Internal</span>
                </div>
                <div className="text-[11px] text-neutral-400 font-medium">AI Website Builder & Client Engine</div>
              </div>
            </button>

            {/* Project Quick Switcher */}
            {activeProject && (
              <div className="hidden xl:flex items-center gap-2 pl-4 border-l border-neutral-800">
                <span className="text-xs text-neutral-500">Current:</span>
                <div className="relative group">
                  <select
                    value={activeProject.id}
                    onChange={(e) => {
                      const selected = projects.find((p) => p.id === e.target.value);
                      if (selected) setActiveProject(selected);
                    }}
                    className="bg-neutral-900 border border-neutral-800 text-xs rounded-md px-2.5 py-1.5 text-neutral-200 pr-7 appearance-none focus:outline-none focus:border-amber-500 cursor-pointer font-medium max-w-[200px] truncate"
                  >
                    {projects.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name} ({p.status.toUpperCase()})
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="w-3.5 h-3.5 absolute right-2 top-2.5 text-neutral-400 pointer-events-none" />
                </div>
                <button
                  onClick={() => setActiveView('editor')}
                  className="text-xs text-amber-400 hover:text-amber-300 font-medium px-2 py-1 rounded hover:bg-neutral-900 transition-colors flex items-center gap-1"
                >
                  Open Editor <ExternalLink className="w-3 h-3" />
                </button>
              </div>
            )}
          </div>

          {/* Navigation Tabs */}
          <nav className="hidden md:flex items-center gap-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeView === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveView(item.id as any)}
                  className={`relative px-3 py-2 text-xs font-medium rounded-md transition-all flex items-center gap-1.5 ${
                    isActive
                      ? 'bg-neutral-900 text-amber-400 shadow-inner border border-neutral-800'
                      : item.highlight
                      ? 'text-amber-300 hover:text-amber-200 hover:bg-amber-500/10'
                      : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-amber-400' : 'text-neutral-400'}`} />
                  <span>{item.label}</span>
                  {'count' in item && typeof item.count === 'number' && (
                    <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-neutral-800 text-neutral-400">
                      {item.count}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Right Status & Quick Action */}
          <div className="flex items-center gap-2.5">
            <div className="hidden lg:flex items-center gap-2 text-[11px] px-2.5 py-1 rounded-full bg-neutral-900 border border-neutral-800">
              <span className={`w-1.5 h-1.5 rounded-full ${aiStatus.configured ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
              <span className="text-neutral-400 font-medium">AI:</span>
              <span className={aiStatus.configured ? 'text-emerald-400' : 'text-neutral-300'}>
                {aiStatus.configured ? 'Gemini 3.8 Flash' : 'Deterministic'}
              </span>
            </div>

            {/* In-App Android / PWA Install Button */}
            <PWAInstallButton variant="header" />

            {/* Clearly visible Android App & Project ZIP button */}
            <AndroidZipButton variant="header" />

            <button
              onClick={() => setActiveView('wizard')}
              className="px-3.5 py-1.5 rounded-md text-xs font-semibold text-neutral-950 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 shadow-sm shadow-amber-500/20 flex items-center gap-1.5 transition-all transform active:scale-95"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Create Website</span>
              <span className="sm:hidden">Create</span>
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Nav Bar */}
      <div className="md:hidden overflow-x-auto flex items-center gap-2 px-4 py-2 border-t border-neutral-900 bg-neutral-950 no-scrollbar">
        <PWAInstallButton variant="header" className="flex-shrink-0" />
        <AndroidZipButton variant="header" className="flex-shrink-0" />
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveView(item.id as any)}
              className={`flex-shrink-0 px-2.5 py-1 text-xs font-medium rounded transition-all flex items-center gap-1 ${
                isActive ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' : 'text-neutral-400'
              }`}
            >
              <Icon className="w-3 h-3" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};

