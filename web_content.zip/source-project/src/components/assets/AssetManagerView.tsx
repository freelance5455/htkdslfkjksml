import React, { useState } from 'react';
import { useProjects } from '../../context/ProjectContext';
import { AssetItem, ImageOrigin, ImageAspectRatio } from '../../types/website';
import { optimizeClientImageUpload } from '../../utils/imageOptimizer';
import { aiProvider } from '../../services/aiProvider';
import { 
  Image as ImageIcon, 
  Upload, 
  Plus, 
  Trash2, 
  Copy, 
  ExternalLink, 
  Search, 
  Check, 
  X, 
  Eye, 
  Edit2,
  Sparkles,
  Layers,
  ShieldCheck,
  Tag,
  RefreshCw
} from 'lucide-react';

export const AssetManagerView: React.FC = () => {
  const { assets, addAsset, updateAsset, deleteAsset, activeProject, updateProject } = useProjects();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedOrigin, setSelectedOrigin] = useState<string>('all');

  // New asset modal
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [addSourceTab, setAddSourceTab] = useState<'upload' | 'ai' | 'url'>('upload');
  const [newName, setNewName] = useState('');
  const [newUrl, setNewUrl] = useState('');
  const [newAlt, setNewAlt] = useState('');
  const [newCategory, setNewCategory] = useState<AssetItem['category']>('hero');
  const [newOrigin, setNewOrigin] = useState<ImageOrigin>('client_upload');
  const [newDimensions, setNewDimensions] = useState('High-Res');
  const [newFileSize, setNewFileSize] = useState<string | undefined>();
  const [newFormat, setNewFormat] = useState<AssetItem['format']>('webp');
  const [isUploading, setIsUploading] = useState(false);

  // AI Generation in Assets state
  const defaultPrompt = activeProject
    ? `Create a premium modern ${activeProject.business.industry.toLowerCase()} hero image.`
    : 'Create a luxury modern clinic interior hero image.';
  const [aiPrompt, setAiPrompt] = useState(defaultPrompt);
  const [isGeneratingAi, setIsGeneratingAi] = useState(false);

  // Edit / Rename modal state
  const [editingAsset, setEditingAsset] = useState<AssetItem | null>(null);
  const [editName, setEditName] = useState('');
  const [editAlt, setEditAlt] = useState('');
  const [editCategory, setEditCategory] = useState<AssetItem['category']>('hero');
  const [editUrl, setEditUrl] = useState('');

  // Preview modal
  const [previewAsset, setPreviewAsset] = useState<AssetItem | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const categories = [
    { id: 'all', label: 'All Assets' },
    { id: 'hero', label: 'Hero Banners' },
    { id: 'service', label: 'Services' },
    { id: 'facility', label: 'Offices & Facilities' },
    { id: 'team', label: 'Team' },
    { id: 'logo', label: 'Logos' },
    { id: 'gallery', label: 'Gallery' },
  ];

  const origins = [
    { id: 'all', label: 'All Sources' },
    { id: 'client_upload', label: 'Client Uploads' },
    { id: 'ai_generated', label: 'AI Generated' },
    { id: 'stock_licensed', label: 'Stock Licensed' },
  ];

  const filteredAssets = assets.filter((ast) => {
    const matchesCategory = selectedCategory === 'all' || ast.category === selectedCategory;
    const matchesOrigin = selectedOrigin === 'all' || ast.origin === selectedOrigin;
    const matchesSearch =
      ast.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ast.altText.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesOrigin && matchesSearch;
  });

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const optimized = await optimizeClientImageUpload(file);
      setNewUrl(optimized.dataUrl);
      setNewDimensions(optimized.dimensions);
      setNewFileSize(optimized.fileSize);
      setNewFormat(optimized.format);
      setNewOrigin('client_upload');
      if (!newName) {
        setNewName(file.name.replace(/\.[^/.]+$/, ''));
      }
      if (!newAlt) {
        setNewAlt(`Client photograph of ${file.name.replace(/\.[^/.]+$/, '')}`);
      }
    } catch (err: any) {
      alert(`Upload error: ${err.message}`);
    } finally {
      setIsUploading(false);
    }
  };

  const handleGenerateAi = async () => {
    if (!aiPrompt.trim()) return;

    setIsGeneratingAi(true);
    try {
      const result = await aiProvider.generateSectionImage({
        prompt: aiPrompt,
        industry: activeProject?.business.industry || 'Business Services',
        style: activeProject?.brand.style || 'Modern',
        sectionType: newCategory,
        aspectRatio: '16:9',
      });

      setNewUrl(result.imageUrl);
      setNewName(`AI: ${aiPrompt.slice(0, 28)}...`);
      setNewAlt(result.altText);
      setNewOrigin('ai_generated');
      setNewDimensions(result.dimensions || '1600x900');
      setNewFileSize('320 KB');
      setNewFormat('webp');
    } catch (err: any) {
      alert(`AI Image generation failed: ${err.message}`);
    } finally {
      setIsGeneratingAi(false);
    }
  };

  const handleSaveNewAsset = () => {
    if (!newName.trim() || !newUrl.trim()) {
      alert('Please provide an asset title and image.');
      return;
    }

    addAsset({
      name: newName.trim(),
      url: newUrl.trim(),
      altText: newAlt.trim() || newName.trim(),
      category: newCategory,
      dimensions: newDimensions,
      fileSize: newFileSize,
      format: newFormat,
      origin: newOrigin,
      license: newOrigin === 'client_upload' ? 'Client Provided Rights' : newOrigin === 'ai_generated' ? 'AI Studio Production License' : 'Commercial Stock License',
    });

    setIsAddModalOpen(false);
    setNewName('');
    setNewUrl('');
    setNewAlt('');
  };

  const handleOpenEdit = (ast: AssetItem) => {
    setEditingAsset(ast);
    setEditName(ast.name);
    setEditAlt(ast.altText);
    setEditCategory(ast.category);
    setEditUrl(ast.url);
  };

  const handleSaveEdit = () => {
    if (!editingAsset) return;
    updateAsset({
      ...editingAsset,
      name: editName.trim() || editingAsset.name,
      altText: editAlt.trim() || editingAsset.altText,
      category: editCategory,
      url: editUrl.trim() || editingAsset.url,
    });
    setEditingAsset(null);
  };

  const handleCopyUrl = (url: string, id: string) => {
    navigator.clipboard.writeText(url);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleApplyToActiveProjectHero = (ast: AssetItem) => {
    if (!activeProject) {
      alert('No active project loaded in the studio.');
      return;
    }
    const home = activeProject.pages.find((p) => p.isHome) || activeProject.pages[0];
    const updatedSections = home.sections.map((sec) =>
      sec.type === 'hero'
        ? {
            ...sec,
            imageUrl: ast.url,
            imageAlt: ast.altText,
            imageOrigin: ast.origin,
            isImagePlaceholder: false,
          }
        : sec
    );
    const updatedPages = activeProject.pages.map((p) =>
      p.id === home.id ? { ...p, sections: updatedSections } : p
    );
    updateProject({
      ...activeProject,
      pages: updatedPages,
    });
    alert(`Applied "${ast.name}" as Hero banner in "${activeProject.name}"!`);
  };

  const handleReplaceUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const opt = await optimizeClientImageUpload(file);
      setEditUrl(opt.dataUrl);
    } catch (err: any) {
      alert(`File optimization error: ${err.message}`);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="text-[11px] font-mono uppercase tracking-wider text-amber-400 font-semibold mb-1">
            Visual Asset Management & Media Hub
          </div>
          <h1 className="text-2xl font-bold text-neutral-100 tracking-tight">Studio Asset Library</h1>
          <p className="text-xs text-neutral-400 mt-1">
            Upload device imagery (JPG, PNG, WebP, SVG), generate AI section visuals, and curate verified stock photos with transparent origin badges.
          </p>
        </div>

        <button
          onClick={() => {
            setAddSourceTab('upload');
            setIsAddModalOpen(true);
          }}
          className="px-4 py-2 rounded-lg bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-neutral-950 text-xs font-bold flex items-center gap-1.5 shadow-sm active:scale-95 transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>Add Media Asset</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="space-y-3 bg-neutral-900 p-4 rounded-xl border border-neutral-800">
        <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-neutral-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search assets by name or alt description..."
              className="w-full pl-9 pr-4 py-1.5 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-amber-500"
            />
          </div>

          {/* Origin Segmented Tabs */}
          <div className="flex items-center gap-1 overflow-x-auto text-xs pb-1 md:pb-0">
            {origins.map((orig) => (
              <button
                key={orig.id}
                onClick={() => setSelectedOrigin(orig.id)}
                className={`px-3 py-1.5 rounded-md font-medium whitespace-nowrap transition-colors ${
                  selectedOrigin === orig.id
                    ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20 font-bold'
                    : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800'
                }`}
              >
                {orig.label}
              </button>
            ))}
          </div>
        </div>

        {/* Categories Bar */}
        <div className="flex items-center gap-1 overflow-x-auto text-xs pt-1 border-t border-neutral-800/80">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-2.5 py-1 rounded text-xs transition-colors ${
                selectedCategory === cat.id
                  ? 'text-white font-semibold bg-neutral-800'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Assets Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
        {filteredAssets.map((ast) => (
          <div
            key={ast.id}
            className="rounded-xl bg-neutral-900 border border-neutral-800 hover:border-neutral-700 transition-all overflow-hidden flex flex-col justify-between group shadow-sm"
          >
            <div>
              {/* Image Preview Container */}
              <div 
                className="relative h-44 bg-neutral-950 overflow-hidden cursor-pointer" 
                onClick={() => setPreviewAsset(ast)}
              >
                <img
                  src={ast.url}
                  alt={ast.altText}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  loading="lazy"
                  decoding="async"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                  <span className="p-2 rounded-full bg-black/70 text-white hover:bg-black/90">
                    <Eye className="w-4 h-4" />
                  </span>
                </div>
                
                {/* Source Origin Badge */}
                <span
                  className={`absolute top-2 left-2 text-[9px] font-mono uppercase font-bold px-2 py-0.5 rounded backdrop-blur border ${
                    ast.origin === 'client_upload'
                      ? 'bg-emerald-950/80 text-emerald-400 border-emerald-500/30'
                      : ast.origin === 'ai_generated'
                      ? 'bg-amber-950/80 text-amber-400 border-amber-500/30'
                      : 'bg-black/80 text-neutral-300 border-white/10'
                  }`}
                >
                  {ast.origin?.replace('_', ' ') || 'Asset'}
                </span>

                {ast.dimensions && (
                  <span className="absolute bottom-2 right-2 text-[9px] font-mono px-1.5 py-0.5 rounded bg-black/80 text-neutral-400">
                    {ast.dimensions}
                  </span>
                )}
              </div>

              {/* Meta */}
              <div className="p-4 space-y-1.5">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-xs text-neutral-100 truncate flex-1">{ast.name}</h3>
                  <button
                    onClick={() => handleOpenEdit(ast)}
                    className="p-1 text-neutral-500 hover:text-amber-400"
                    title="Rename & Edit Alt Text"
                  >
                    <Edit2 className="w-3 h-3" />
                  </button>
                </div>
                <p className="text-[11px] text-neutral-400 line-clamp-2 leading-relaxed">
                  Alt: {ast.altText}
                </p>
                {ast.fileSize && (
                  <div className="text-[10px] text-neutral-500 font-mono">
                    Size: {ast.fileSize} · {ast.format?.toUpperCase() || 'WEBP'}
                  </div>
                )}
              </div>
            </div>

            {/* Actions Footer */}
            <div className="px-4 py-2.5 bg-neutral-950/60 border-t border-neutral-800 flex items-center justify-between text-xs">
              <button
                onClick={() => handleCopyUrl(ast.url, ast.id)}
                className="text-[11px] text-neutral-400 hover:text-white flex items-center gap-1"
              >
                {copiedId === ast.id ? (
                  <>
                    <Check className="w-3 h-3 text-emerald-400" />
                    <span className="text-emerald-400">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3" />
                    <span>Copy URL</span>
                  </>
                )}
              </button>

              <div className="flex items-center gap-1.5">
                {activeProject && (
                  <button
                    onClick={() => handleApplyToActiveProjectHero(ast)}
                    className="text-[10px] text-amber-400 hover:text-amber-300 font-semibold px-2 py-0.5 rounded bg-amber-500/10 border border-amber-500/20"
                    title="Set as Hero in Active Project"
                  >
                    Set as Hero
                  </button>
                )}

                <button
                  onClick={() => {
                    if (confirm(`Delete asset "${ast.name}"?`)) {
                      deleteAsset(ast.id);
                    }
                  }}
                  title="Delete Asset"
                  className="text-neutral-500 hover:text-rose-400 transition-colors p-1"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* ADD ASSET MODAL */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 max-w-lg w-full shadow-2xl space-y-4 text-xs text-neutral-200">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <div>
                <h3 className="text-sm font-bold text-white">Add New Media Asset</h3>
                <p className="text-[11px] text-neutral-400">Upload a client file or generate with AI.</p>
              </div>
              <button onClick={() => setIsAddModalOpen(false)} className="text-neutral-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Source Tab Toggle */}
            <div className="flex border border-neutral-800 rounded-lg p-1 bg-neutral-950">
              <button
                type="button"
                onClick={() => setAddSourceTab('upload')}
                className={`flex-1 py-1.5 rounded text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors ${
                  addSourceTab === 'upload' ? 'bg-neutral-800 text-amber-400' : 'text-neutral-400'
                }`}
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Device Upload</span>
              </button>
              <button
                type="button"
                onClick={() => setAddSourceTab('ai')}
                className={`flex-1 py-1.5 rounded text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors ${
                  addSourceTab === 'ai' ? 'bg-neutral-800 text-amber-400' : 'text-neutral-400'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>AI Generate</span>
              </button>
              <button
                type="button"
                onClick={() => setAddSourceTab('url')}
                className={`flex-1 py-1.5 rounded text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors ${
                  addSourceTab === 'url' ? 'bg-neutral-800 text-amber-400' : 'text-neutral-400'
                }`}
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>Direct URL</span>
              </button>
            </div>

            {/* TAB CONTENT: UPLOAD */}
            {addSourceTab === 'upload' && (
              <div className="space-y-3">
                <label className="flex flex-col items-center justify-center h-28 border-2 border-dashed border-neutral-800 hover:border-amber-500/50 rounded-xl cursor-pointer bg-neutral-950 transition-colors p-3 text-center">
                  <Upload className="w-6 h-6 text-neutral-500 mb-1" />
                  <span className="font-semibold text-neutral-200 text-xs">
                    {isUploading ? 'Optimizing image...' : 'Click to select JPG, PNG, WebP, or SVG'}
                  </span>
                  <span className="text-[10px] text-neutral-500 mt-0.5">
                    Client-side WebP compression (max 1920px)
                  </span>
                  <input
                    type="file"
                    accept="image/jpeg,image/png,image/webp,image/svg+xml"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>
              </div>
            )}

            {/* TAB CONTENT: AI GENERATE */}
            {addSourceTab === 'ai' && (
              <div className="space-y-3">
                <div>
                  <label className="block text-[11px] text-neutral-400 font-semibold mb-1">
                    AI Prompt
                  </label>
                  <textarea
                    rows={2}
                    value={aiPrompt}
                    onChange={(e) => setAiPrompt(e.target.value)}
                    placeholder="Describe the architectural or commercial scene..."
                    className="w-full px-3 py-2 rounded bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
                <button
                  type="button"
                  onClick={handleGenerateAi}
                  disabled={isGeneratingAi || !aiPrompt.trim()}
                  className="w-full py-2 rounded bg-amber-400 hover:bg-amber-300 text-neutral-950 font-bold flex items-center justify-center gap-1.5 disabled:opacity-50"
                >
                  {isGeneratingAi ? (
                    <>
                      <div className="w-3 h-3 border-2 border-neutral-950 border-t-transparent rounded-full animate-spin" />
                      <span>Generating Visual...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Generate AI Image</span>
                    </>
                  )}
                </button>
              </div>
            )}

            {/* TAB CONTENT: URL */}
            {addSourceTab === 'url' && (
              <div>
                <label className="block text-[11px] text-neutral-400 font-semibold mb-1">
                  Image URL
                </label>
                <input
                  type="text"
                  value={newUrl}
                  onChange={(e) => {
                    setNewUrl(e.target.value);
                    setNewOrigin('stock_licensed');
                  }}
                  placeholder="https://..."
                  className="w-full px-3 py-2 rounded bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:border-amber-500"
                />
              </div>
            )}

            {/* Image Preview thumbnail if available */}
            {newUrl && (
              <div className="p-2 rounded bg-neutral-950 border border-neutral-800 flex items-center gap-3">
                <img src={newUrl} alt="Preview" className="w-14 h-14 object-cover rounded" />
                <div className="flex-1 truncate">
                  <div className="font-semibold text-white truncate">{newName || 'Image Asset'}</div>
                  <div className="text-[10px] text-neutral-400">Origin: {newOrigin.replace('_', ' ')}</div>
                </div>
              </div>
            )}

            {/* Name, Alt Text & Category */}
            <div className="space-y-3">
              <div>
                <label className="block text-[11px] text-neutral-400 font-semibold mb-1">
                  Asset Title *
                </label>
                <input
                  type="text"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="e.g. Modern Consultation Suite"
                  className="w-full px-3 py-2 rounded bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-[11px] text-neutral-400 font-semibold mb-1">
                  Accessibility Alt Text *
                </label>
                <input
                  type="text"
                  value={newAlt}
                  onChange={(e) => setNewAlt(e.target.value)}
                  placeholder="Accurate visual description for screen readers and SEO..."
                  className="w-full px-3 py-2 rounded bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-[11px] text-neutral-400 font-semibold mb-1">
                  Category
                </label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as any)}
                  className="w-full px-3 py-2 rounded bg-neutral-950 border border-neutral-800 text-white focus:outline-none"
                >
                  <option value="hero">Hero Banner</option>
                  <option value="service">Service</option>
                  <option value="facility">Offices & Facility</option>
                  <option value="team">Team</option>
                  <option value="gallery">Gallery</option>
                  <option value="logo">Logo</option>
                  <option value="other">Other</option>
                </select>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-neutral-800">
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="px-4 py-2 rounded text-neutral-400 hover:text-white font-semibold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveNewAsset}
                className="px-4 py-2 rounded bg-amber-400 hover:bg-amber-300 text-neutral-950 font-bold shadow"
              >
                Save to Asset Library
              </button>
            </div>
          </div>
        </div>
      )}

      {/* EDIT / RENAME ASSET MODAL */}
      {editingAsset && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-6 max-w-md w-full shadow-2xl space-y-4 text-xs text-neutral-200">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <h3 className="text-sm font-bold text-white">Edit Asset Details</h3>
              <button onClick={() => setEditingAsset(null)} className="text-neutral-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-[11px] text-neutral-400 font-semibold mb-1">Asset Name</label>
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full px-3 py-2 rounded bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-[11px] text-neutral-400 font-semibold mb-1">Alt Text (A11y)</label>
                <input
                  type="text"
                  value={editAlt}
                  onChange={(e) => setEditAlt(e.target.value)}
                  className="w-full px-3 py-2 rounded bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-[11px] text-neutral-400 font-semibold mb-1">Category</label>
                <select
                  value={editCategory}
                  onChange={(e) => setEditCategory(e.target.value as any)}
                  className="w-full px-3 py-2 rounded bg-neutral-950 border border-neutral-800 text-white focus:outline-none"
                >
                  <option value="hero">Hero Banner</option>
                  <option value="service">Service</option>
                  <option value="facility">Offices & Facility</option>
                  <option value="team">Team</option>
                  <option value="gallery">Gallery</option>
                  <option value="logo">Logo</option>
                  <option value="other">Other</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] text-neutral-400 font-semibold mb-1">Replace with Device File</label>
                <label className="flex items-center gap-2 px-3 py-2 rounded-lg bg-neutral-950 border border-dashed border-neutral-700 hover:border-amber-500/50 cursor-pointer text-neutral-300 transition-colors">
                  <Upload className="w-4 h-4 text-amber-400" />
                  <span className="text-[11px]">Browse file to replace (JPG, PNG, WebP, SVG)</span>
                  <input
                    type="file"
                    accept="image/jpeg,image/png,image/webp,image/svg+xml"
                    onChange={handleReplaceUpload}
                    className="hidden"
                  />
                </label>
              </div>

              <div>
                <label className="block text-[11px] text-neutral-400 font-semibold mb-1">Image URL / Data URL</label>
                <input
                  type="text"
                  value={editUrl}
                  onChange={(e) => setEditUrl(e.target.value)}
                  className="w-full px-3 py-2 rounded bg-neutral-950 border border-neutral-800 text-white focus:outline-none"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-neutral-800">
              <button
                type="button"
                onClick={() => setEditingAsset(null)}
                className="px-4 py-2 rounded text-neutral-400 hover:text-white font-semibold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveEdit}
                className="px-4 py-2 rounded bg-amber-400 hover:bg-amber-300 text-neutral-950 font-bold shadow"
              >
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}

      {/* PREVIEW MODAL */}
      {previewAsset && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-neutral-900 border border-neutral-800 rounded-2xl overflow-hidden max-w-3xl w-full shadow-2xl">
            <div className="p-4 border-b border-neutral-800 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm text-white">{previewAsset.name}</h3>
                <p className="text-[11px] text-neutral-400">Alt: {previewAsset.altText}</p>
              </div>
              <button onClick={() => setPreviewAsset(null)} className="text-neutral-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="bg-black max-h-[60vh] flex items-center justify-center p-2">
              <img
                src={previewAsset.url}
                alt={previewAsset.altText}
                className="max-h-[55vh] object-contain rounded"
                referrerPolicy="no-referrer"
              />
            </div>

            <div className="p-4 bg-neutral-950 flex flex-wrap items-center justify-between gap-4 text-xs">
              <div className="flex items-center gap-4 text-[11px] text-neutral-400">
                <span className="uppercase font-mono font-bold text-amber-400">
                  {previewAsset.origin?.replace('_', ' ') || 'Asset'}
                </span>
                {previewAsset.dimensions && <span>{previewAsset.dimensions}</span>}
                {previewAsset.fileSize && <span>{previewAsset.fileSize}</span>}
                {previewAsset.license && <span>{previewAsset.license}</span>}
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleCopyUrl(previewAsset.url, previewAsset.id)}
                  className="px-3 py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-white font-semibold flex items-center gap-1"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy URL</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
