import React, { useState } from 'react';
import { useProjects } from '../../context/ProjectContext';
import { TEMPLATE_CATALOG, TemplateDefinition } from '../../data/templateCatalog';
import { ClientWebsiteRenderer } from '../preview/ClientWebsiteRenderer';
import { 
  Layers, 
  ExternalLink, 
  PlusCircle, 
  Sparkles, 
  Search, 
  X, 
  Check, 
  ArrowRight,
  ShieldCheck
} from 'lucide-react';

export const TemplatesView: React.FC = () => {
  const { createProject, setActiveView } = useProjects();
  const [selectedIndustry, setSelectedIndustry] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [previewTemplate, setPreviewTemplate] = useState<TemplateDefinition | null>(null);

  const industries = ['All', 'Medical / Dental', 'Fine Dining & Hospitality', 'Trades & Home Services', 'Creative & Digital Agency', 'Technology / B2B SaaS'];

  const filteredTemplates = TEMPLATE_CATALOG.filter((tpl) => {
    const matchesIndustry = selectedIndustry === 'All' || tpl.industry.includes(selectedIndustry);
    const matchesSearch =
      tpl.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tpl.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tpl.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesIndustry && matchesSearch;
  });

  const handleUseTemplate = (tpl: TemplateDefinition) => {
    const newProjectId = `prj-${Date.now()}`;
    const cloned = {
      ...JSON.parse(JSON.stringify(tpl.initialProject)),
      id: newProjectId,
      name: `${tpl.name} Project`,
      clientName: 'New Client Prospect',
      status: 'draft',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    createProject(cloned);
    setPreviewTemplate(null);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="text-[11px] font-mono uppercase tracking-wider text-amber-400 font-semibold mb-1">
            Curated Industry Foundations
          </div>
          <h1 className="text-2xl font-bold text-neutral-100 tracking-tight">Website Template Catalog</h1>
          <p className="text-xs text-neutral-400 mt-1">
            Professional architectures designed for specific business models. Use as starting points, then customize with client specifics.
          </p>
        </div>

        <button
          onClick={() => setActiveView('wizard')}
          className="px-4 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold flex items-center gap-1.5 transition-all"
        >
          <PlusCircle className="w-3.5 h-3.5 text-amber-400" />
          <span>Build from Scratch</span>
        </button>
      </div>

      {/* Filters and Search */}
      <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between bg-neutral-900 p-3 rounded-xl border border-neutral-800">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-neutral-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search templates by keyword, niche, or tag..."
            className="w-full pl-9 pr-4 py-1.5 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-amber-500"
          />
        </div>

        <div className="flex items-center gap-1 overflow-x-auto text-xs pb-1 md:pb-0">
          {industries.map((ind) => (
            <button
              key={ind}
              onClick={() => setSelectedIndustry(ind)}
              className={`px-3 py-1.5 rounded-md font-medium whitespace-nowrap transition-colors ${
                selectedIndustry === ind
                  ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20 font-bold'
                  : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800'
              }`}
            >
              {ind}
            </button>
          ))}
        </div>
      </div>

      {/* Templates Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTemplates.map((tpl) => (
          <div
            key={tpl.id}
            className="rounded-xl bg-neutral-900 border border-neutral-800 hover:border-neutral-700 transition-all shadow-md overflow-hidden flex flex-col justify-between group"
          >
            <div>
              {/* Thumbnail */}
              <div className="relative h-48 overflow-hidden bg-neutral-950">
                <img
                  src={tpl.thumbnail}
                  alt={tpl.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-neutral-900 via-transparent to-transparent pointer-events-none" />
                <span className="absolute top-3 left-3 text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded bg-black/70 backdrop-blur text-white border border-white/10">
                  {tpl.type}
                </span>
                <span className="absolute top-3 right-3 text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/90 text-neutral-950">
                  {tpl.style}
                </span>
              </div>

              {/* Body */}
              <div className="p-5">
                <h3 className="font-bold text-base text-neutral-100 mb-1 group-hover:text-amber-300 transition-colors">
                  {tpl.name}
                </h3>
                <div className="text-[11px] text-amber-400/90 font-medium mb-2.5">
                  {tpl.industry}
                </div>
                <p className="text-xs text-neutral-400 line-clamp-2 mb-4 leading-relaxed">
                  {tpl.description}
                </p>

                {/* Tags */}
                <div className="flex flex-wrap gap-1.5">
                  {tpl.tags.map((tag, tIdx) => (
                    <span
                      key={tIdx}
                      className="text-[10px] px-2 py-0.5 rounded bg-neutral-950 border border-neutral-800 text-neutral-400"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="p-4 bg-neutral-950/60 border-t border-neutral-800 flex items-center justify-between gap-2">
              <button
                onClick={() => setPreviewTemplate(tpl)}
                className="px-3 py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>Live Preview</span>
              </button>

              <button
                onClick={() => handleUseTemplate(tpl)}
                className="px-3.5 py-1.5 rounded bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-neutral-950 text-xs font-bold flex items-center gap-1.5 shadow-sm active:scale-95 transition-all"
              >
                <span>Use as Base</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* FULLSCREEN TEMPLATE PREVIEW MODAL */}
      {previewTemplate && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex flex-col">
          {/* Modal Header */}
          <div className="h-14 border-b border-neutral-800 px-6 flex items-center justify-between bg-neutral-950 text-neutral-200">
            <div className="flex items-center gap-3">
              <span className="font-bold text-sm text-white">{previewTemplate.name}</span>
              <span className="text-xs text-neutral-500">· {previewTemplate.industry} ({previewTemplate.style})</span>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => handleUseTemplate(previewTemplate)}
                className="px-4 py-1.5 rounded bg-amber-400 hover:bg-amber-300 text-neutral-950 text-xs font-bold flex items-center gap-1.5 shadow"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Customize This Foundation</span>
              </button>
              <button
                onClick={() => setPreviewTemplate(null)}
                className="p-1.5 text-neutral-400 hover:text-white rounded hover:bg-neutral-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Modal Body: Live Render */}
          <div className="flex-1 overflow-y-auto bg-neutral-950 flex justify-center p-4">
            <div className="w-full max-w-6xl shadow-2xl rounded-lg overflow-hidden border border-neutral-800 bg-white">
              <ClientWebsiteRenderer project={previewTemplate.initialProject} interactive={false} />
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
