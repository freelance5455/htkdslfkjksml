import React, { useState } from 'react';
import {
  Download,
  Smartphone,
  Copy,
  Check,
  X,
  Terminal,
  FolderArchive,
  ArrowRight,
  ShieldCheck,
  Laptop,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { triggerProjectZipDownload } from '../../utils/downloadProjectZip';

interface AndroidZipModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidZipModal: React.FC<AndroidZipModalProps> = ({ isOpen, onClose }) => {
  const [copiedCode, setCopiedCode] = useState(false);
  const [downloadStarted, setDownloadStarted] = useState(false);
  const [downloadStatus, setDownloadStatus] = useState<string | null>(null);
  const [downloadError, setDownloadError] = useState<string | null>(null);

  if (!isOpen) return null;

  const zipFileName = 'money-making-empire-ai-website-builder.zip';

  const terminalCommands = `# 1. Extract the downloaded project archive
unzip money-making-empire-ai-website-builder.zip
cd money-making-empire-ai-website-builder

# 2. Install dependencies & build production web assets
npm install
npm run build

# 3. Synchronize assets with Capacitor Android native wrapper
npx cap sync android

# 4. Open in Android Studio OR build directly via Gradle:
# Option A - Android Studio:
npx cap open android
# (In Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s))

# Option B - Command Line Gradle build (requires Android SDK):
cd android && ./gradlew assembleDebug
# Generated APK will be at: android/app/build/outputs/apk/debug/app-debug.apk`;

  const copyCommands = () => {
    navigator.clipboard.writeText(terminalCommands);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2200);
  };

  const handleDownloadClick = async () => {
    setDownloadStarted(true);
    setDownloadError(null);
    setDownloadStatus('Packaging and initiating ZIP download...');

    const result = await triggerProjectZipDownload((status) => {
      setDownloadStatus(status);
    });

    if (result.success) {
      setDownloadStatus('money-making-empire-ai-website-builder.zip downloaded!');
      setTimeout(() => {
        setDownloadStarted(false);
        setDownloadStatus(null);
      }, 5000);
    } else {
      setDownloadError(result.error || 'Failed to download ZIP');
      setDownloadStarted(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm animate-fade-in"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-xl max-h-[92vh] overflow-y-auto rounded-2xl bg-neutral-900 border border-neutral-800 shadow-2xl text-neutral-100 flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between px-5 py-4 bg-neutral-950/95 border-b border-neutral-800 backdrop-blur-md">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-neutral-950 font-bold shadow-md shadow-amber-500/20 flex-shrink-0">
              <Smartphone className="w-5 h-5 text-neutral-950" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-bold text-neutral-100 flex items-center gap-2">
                <span>Android App & Project ZIP</span>
                <span className="text-[10px] tracking-wider uppercase px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20 font-mono">
                  Ready
                </span>
              </h2>
              <p className="text-xs text-neutral-400">
                Package source code & compile APK in external Android environment
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800 transition-colors"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Workflow Breadcrumb */}
        <div className="px-5 py-2.5 bg-neutral-950/60 border-b border-neutral-800/80 flex items-center gap-1.5 text-[10px] sm:text-[11px] font-mono text-neutral-400 overflow-x-auto no-scrollbar">
          <span className="text-amber-400 font-semibold whitespace-nowrap">AI Studio</span>
          <ArrowRight className="w-3 h-3 text-neutral-600 flex-shrink-0" />
          <span className="text-amber-300 font-semibold whitespace-nowrap">Download ZIP</span>
          <ArrowRight className="w-3 h-3 text-neutral-600 flex-shrink-0" />
          <span className="text-neutral-300 whitespace-nowrap">External Android Build</span>
          <ArrowRight className="w-3 h-3 text-neutral-600 flex-shrink-0" />
          <span className="text-emerald-400 whitespace-nowrap">Compile APK</span>
          <ArrowRight className="w-3 h-3 text-neutral-600 flex-shrink-0" />
          <span className="text-neutral-300 whitespace-nowrap">Install on Phone</span>
        </div>

        {/* Modal Body */}
        <div className="p-5 space-y-5">
          {/* SECTION 1: DOWNLOAD PROJECT ZIP */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-amber-400 text-neutral-950 font-bold text-xs flex items-center justify-center">
                  1
                </span>
                <h3 className="text-xs sm:text-sm font-bold text-neutral-100 uppercase tracking-wide">
                  Download Project ZIP
                </h3>
              </div>
              <span className="text-[11px] font-mono text-neutral-400">~1.2 MB</span>
            </div>

            <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 flex-shrink-0 mt-0.5">
                  <FolderArchive className="w-4 h-4" />
                </div>
                <div className="space-y-1 min-w-0">
                  <div className="text-xs font-semibold text-neutral-200 truncate font-mono text-amber-300">
                    {zipFileName}
                  </div>
                  <p className="text-xs text-neutral-400 leading-relaxed">
                    Complete current project archive including the native Capacitor Android project (<code className="text-neutral-300 font-mono text-[11px]">android/</code>), full React source code, website editor, AI Prompt Mode, Guided Mode, chatbot, and templates.
                  </p>
                </div>
              </div>

              {/* Direct Download Button */}
              <button
                onClick={handleDownloadClick}
                disabled={downloadStarted}
                className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-neutral-950 font-bold text-xs sm:text-sm shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 transition-all transform active:scale-98 disabled:opacity-75 cursor-pointer"
              >
                <Download className={`w-4 h-4 text-neutral-950 ${downloadStarted ? 'animate-bounce' : ''}`} />
                <span>
                  {downloadStarted ? (downloadStatus || 'Packaging & Downloading...') : 'Download Project ZIP (money-making-empire-ai-website-builder.zip)'}
                </span>
              </button>

              {downloadStatus && !downloadError && (
                <div className="p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs flex items-center gap-2 font-mono">
                  <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
                  <span>{downloadStatus}</span>
                </div>
              )}

              {downloadError && (
                <div className="p-2.5 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-xs flex items-center gap-2">
                  <AlertCircle className="w-3.5 h-3.5 text-red-400 flex-shrink-0" />
                  <span>{downloadError}</span>
                </div>
              )}

              <div className="flex items-center justify-between text-[11px] text-neutral-400 px-1 pt-0.5">
                <span className="flex items-center gap-1.5 text-neutral-300">
                  <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                  <span>No secrets included • Clean placeholder .env.example</span>
                </span>
                <span className="text-neutral-500 font-mono text-[10px]">
                  Direct ZIP Binary
                </span>
              </div>
            </div>
          </div>

          {/* SECTION 2: ANDROID APK INSTRUCTIONS */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-amber-400 text-neutral-950 font-bold text-xs flex items-center justify-center">
                  2
                </span>
                <h3 className="text-xs sm:text-sm font-bold text-neutral-100 uppercase tracking-wide">
                  Android APK Instructions
                </h3>
              </div>
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-neutral-800 text-neutral-300">
                Capacitor Native
              </span>
            </div>

            <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3">
              <p className="text-xs text-neutral-300 leading-relaxed">
                Take the downloaded ZIP to an external <strong>Android / Capacitor build environment</strong> (such as Android Studio, a local PC with Java & Android SDK, or GitHub Actions) to compile the APK:
              </p>

              <ol className="space-y-2 text-xs text-neutral-300">
                <li className="flex items-start gap-2">
                  <span className="text-amber-400 font-mono font-bold">•</span>
                  <span><strong>Extract ZIP:</strong> Extract <code className="text-amber-300 font-mono text-[11px]">{zipFileName}</code> to a folder on your computer.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-amber-400 font-mono font-bold">•</span>
                  <span><strong>Build Web Assets:</strong> Run <code className="text-neutral-200 font-mono text-[11px]">npm install && npm run build</code>.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-amber-400 font-mono font-bold">•</span>
                  <span><strong>Sync Android:</strong> Run <code className="text-neutral-200 font-mono text-[11px]">npx cap sync android</code> to transfer assets into the Android native wrapper.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-amber-400 font-mono font-bold">•</span>
                  <span><strong>Compile APK:</strong> Open in Android Studio (<code className="text-neutral-200 font-mono text-[11px]">npx cap open android</code>) and click <em>Build APK</em>, or run <code className="text-neutral-200 font-mono text-[11px]">cd android && ./gradlew assembleDebug</code>.</span>
                </li>
              </ol>

              {/* Terminal Code Snippet with Copy */}
              <div className="space-y-1.5 pt-1">
                <div className="flex items-center justify-between text-xs text-neutral-400">
                  <span className="flex items-center gap-1.5 font-mono text-[11px]">
                    <Terminal className="w-3.5 h-3.5 text-amber-400" />
                    <span>Terminal build commands:</span>
                  </span>
                  <button
                    onClick={copyCommands}
                    className="flex items-center gap-1 text-[11px] font-mono text-amber-400 hover:text-amber-300 transition-colors"
                  >
                    {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedCode ? 'Copied to Clipboard!' : 'Copy Commands'}</span>
                  </button>
                </div>
                <div className="relative rounded-lg bg-neutral-950 p-3 font-mono text-[11px] text-neutral-300 border border-neutral-800/90 overflow-x-auto leading-relaxed">
                  <pre className="whitespace-pre">{terminalCommands}</pre>
                </div>
              </div>
            </div>
          </div>

          {/* Project Structure Included */}
          <div className="p-3.5 rounded-lg bg-neutral-950/60 border border-neutral-800/80 text-xs text-neutral-300 space-y-1.5">
            <div className="font-semibold text-neutral-200 flex items-center gap-1.5">
              <Laptop className="w-4 h-4 text-amber-400" />
              <span>Project Structure Included in ZIP:</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-[11px] font-mono text-neutral-400 pt-1">
              <div><strong className="text-neutral-200">android/</strong> (Capacitor Android wrapper)</div>
              <div><strong className="text-neutral-200">src/</strong> (Full React & TypeScript code)</div>
              <div><strong className="text-neutral-200">public/</strong> (Icons, manifests, assets)</div>
              <div><strong className="text-neutral-200">capacitor.config.json</strong> (Config)</div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="sticky bottom-0 z-10 px-5 py-3 bg-neutral-950 border-t border-neutral-800 flex items-center justify-between text-xs text-neutral-400">
          <span className="text-[11px]">
            Target: <strong className="text-neutral-200 font-mono">Android (Capacitor)</strong>
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-medium transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
