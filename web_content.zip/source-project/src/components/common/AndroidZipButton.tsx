import React, { useState } from 'react';
import { Smartphone, Download } from 'lucide-react';
import { AndroidZipModal } from './AndroidZipModal';

interface AndroidZipButtonProps {
  className?: string;
  variant?: 'header' | 'banner' | 'compact';
}

export const AndroidZipButton: React.FC<AndroidZipButtonProps> = ({
  className = '',
  variant = 'header'
}) => {
  const [modalOpen, setModalOpen] = useState(false);

  if (variant === 'banner') {
    return (
      <>
        <div className={`p-4 rounded-xl bg-gradient-to-r from-amber-500/15 via-neutral-900 to-neutral-900 border border-amber-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-lg shadow-amber-500/5 ${className}`}>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-neutral-950 font-bold shadow-md shadow-amber-500/20 flex-shrink-0">
              <Smartphone className="w-5 h-5 text-neutral-950" />
            </div>
            <div>
              <div className="font-semibold text-neutral-100 text-sm flex items-center gap-2">
                <span>Android App & Project ZIP</span>
                <span className="text-[10px] uppercase font-mono px-1.5 py-0.2 rounded bg-amber-400/20 text-amber-300">ZIP & APK</span>
              </div>
              <p className="text-xs text-neutral-400 mt-0.5">
                Download project ZIP and compile APK in external Android build environment.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 sm:self-center">
            <button
              onClick={() => setModalOpen(true)}
              className="px-3.5 py-2 rounded-lg text-xs font-bold text-neutral-950 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 shadow-md shadow-amber-500/20 flex items-center gap-1.5 transition-all active:scale-95 whitespace-nowrap"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Android App & ZIP</span>
            </button>
          </div>
        </div>

        <AndroidZipModal isOpen={modalOpen} onClose={() => setModalOpen(false)} />
      </>
    );
  }

  return (
    <>
      <button
        onClick={() => setModalOpen(true)}
        title="Android App & Download Project ZIP"
        className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-semibold border border-amber-500/40 bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 transition-all active:scale-95 shadow-sm shadow-amber-500/10 cursor-pointer ${className}`}
      >
        <Smartphone className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
        <span className="hidden sm:inline">Android App & ZIP</span>
        <span className="sm:hidden">App & ZIP</span>
      </button>

      <AndroidZipModal isOpen={modalOpen} onClose={() => setModalOpen(false)} />
    </>
  );
};
