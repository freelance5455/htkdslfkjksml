import React, { useState } from 'react';
import { 
  Download, 
  Smartphone, 
  CheckCircle2, 
  Copy, 
  Check, 
  X, 
  Sparkles, 
  ArrowRight, 
  ShieldCheck, 
  Terminal,
  ExternalLink,
  Laptop
} from 'lucide-react';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import { triggerProjectZipDownload } from '../../utils/downloadProjectZip';

interface AndroidAppModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidAppModal: React.FC<AndroidAppModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, install, isAndroid, isIOS } = usePWAInstall();
  const [activeTab, setActiveTab] = useState<'pwa' | 'apk' | 'zip'>('pwa');
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCode(id);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const handleInstallClick = async () => {
    if (isInstallable) {
      const success = await install();
      if (success) {
        onClose();
      }
    }
  };

  const apkBuildCommands = `# 1. Build the production web bundle
npm run build

# 2. Sync web assets with Capacitor Android wrapper
npx cap sync android

# 3. Open in Android Studio or build release APK
npx cap open android

# Or build directly via Gradle (requires Android SDK installed):
cd android && ./gradlew assembleRelease`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div 
        className="relative w-full max-w-xl max-h-[90vh] overflow-y-auto rounded-2xl bg-neutral-900 border border-neutral-800 shadow-2xl text-neutral-100 flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 bg-neutral-950/95 border-b border-neutral-800">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-neutral-950 font-bold shadow-md shadow-amber-500/20">
              <Smartphone className="w-5 h-5 text-neutral-950" />
            </div>
            <div>
              <h2 className="text-base font-bold text-neutral-100 flex items-center gap-2">
                Install on Android
                <span className="text-[10px] tracking-wider uppercase px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20 font-mono">Mobile App</span>
              </h2>
              <p className="text-xs text-neutral-400">Money Making Empire — AI Website Builder</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-neutral-800 bg-neutral-950/50 px-6 pt-3 gap-4 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveTab('pwa')}
            className={`pb-3 text-xs font-semibold flex items-center gap-2 border-b-2 whitespace-nowrap transition-all ${
              activeTab === 'pwa'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>1-Click PWA App</span>
          </button>
          <button
            onClick={() => setActiveTab('apk')}
            className={`pb-3 text-xs font-semibold flex items-center gap-2 border-b-2 whitespace-nowrap transition-all ${
              activeTab === 'apk'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>Capacitor Android APK</span>
          </button>
          <button
            onClick={() => setActiveTab('zip')}
            className={`pb-3 text-xs font-semibold flex items-center gap-2 border-b-2 whitespace-nowrap transition-all ${
              activeTab === 'zip'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download Project ZIP</span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-6 space-y-5">
          {activeTab === 'pwa' ? (
            <div className="space-y-4">
              {/* App Status Card */}
              <div className="p-4 rounded-xl bg-gradient-to-br from-neutral-950 to-neutral-900 border border-amber-500/20 flex items-start gap-4">
                <img 
                  src="/pwa-192x192.png" 
                  alt="Empire Logo" 
                  className="w-16 h-16 rounded-xl border border-amber-500/30 shadow-lg shadow-amber-500/10 object-cover flex-shrink-0"
                />
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-neutral-100 text-sm">Empire AI Website Builder</span>
                    <span className="text-[10px] text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-1.5 py-0.5 rounded flex items-center gap-1 font-mono">
                      <CheckCircle2 className="w-2.5 h-2.5" /> Ready
                    </span>
                  </div>
                  <p className="text-xs text-neutral-400 leading-relaxed">
                    Install directly to your Android home screen as a standalone full-screen mobile application. No browser URL bar, instant offline caching, and native app launch speed.
                  </p>
                </div>
              </div>

              {/* Install Action Button if available */}
              {isInstallable && !isInstalled && (
                <button
                  onClick={handleInstallClick}
                  className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-neutral-950 font-bold text-sm shadow-lg shadow-amber-500/25 flex items-center justify-center gap-2 transition-all transform active:scale-98"
                >
                  <Download className="w-4 h-4" />
                  <span>Install App on This Device</span>
                </button>
              )}

              {isInstalled && (
                <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
                  <span>This app is already installed in Standalone Mode on your device!</span>
                </div>
              )}

              {/* Step-by-step for Android Phone */}
              <div className="space-y-3">
                <h3 className="text-xs font-semibold text-neutral-300 uppercase tracking-wider">
                  How to install on Android (Chrome / Brave / Edge):
                </h3>
                <ol className="space-y-2.5 text-xs text-neutral-300">
                  <li className="flex items-start gap-2.5 p-2.5 rounded-lg bg-neutral-950/60 border border-neutral-800">
                    <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-[11px] flex-shrink-0">1</span>
                    <span>Open this website URL in <strong>Google Chrome</strong> or your favorite browser on your Android device.</span>
                  </li>
                  <li className="flex items-start gap-2.5 p-2.5 rounded-lg bg-neutral-950/60 border border-neutral-800">
                    <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-[11px] flex-shrink-0">2</span>
                    <span>Tap the <strong>three dots menu (⋮)</strong> at the top-right corner of Chrome.</span>
                  </li>
                  <li className="flex items-start gap-2.5 p-2.5 rounded-lg bg-neutral-950/60 border border-neutral-800">
                    <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-[11px] flex-shrink-0">3</span>
                    <span>Tap <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong>.</span>
                  </li>
                  <li className="flex items-start gap-2.5 p-2.5 rounded-lg bg-neutral-950/60 border border-neutral-800">
                    <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-[11px] flex-shrink-0">4</span>
                    <span>Confirm by tapping <strong>Install</strong>. The Money Making Empire icon will appear on your app drawer and home screen!</span>
                  </li>
                </ol>
              </div>

              {/* Features in Standalone mode */}
              <div className="grid grid-cols-2 gap-2 pt-1">
                <div className="p-2.5 rounded-lg bg-neutral-950/40 border border-neutral-800/80 flex items-center gap-2 text-neutral-300 text-xs">
                  <ShieldCheck className="w-4 h-4 text-amber-400 flex-shrink-0" />
                  <span>Standalone Full-Screen</span>
                </div>
                <div className="p-2.5 rounded-lg bg-neutral-950/40 border border-neutral-800/80 flex items-center gap-2 text-neutral-300 text-xs">
                  <Sparkles className="w-4 h-4 text-amber-400 flex-shrink-0" />
                  <span>Full AI & Builder Features</span>
                </div>
              </div>
            </div>
          ) : activeTab === 'apk' ? (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-neutral-200">Pre-configured Capacitor Android Native Wrapper</span>
                  <span className="text-[10px] text-amber-400 font-mono">com.moneymakingempire.websitebuilder</span>
                </div>
                <p className="text-xs text-neutral-400 leading-relaxed">
                  The complete Capacitor Android configuration has been established in this project with <code className="text-amber-300 font-mono text-[11px]">capacitor.config.json</code> and <code className="text-amber-300 font-mono text-[11px]">@capacitor/android</code>.
                </p>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs text-neutral-300">
                  <span>Build Steps to generate APK on your workstation:</span>
                  <button
                    onClick={() => copyToClipboard(apkBuildCommands, 'apk-cmds')}
                    className="flex items-center gap-1 text-[11px] text-amber-400 hover:text-amber-300 transition-colors"
                  >
                    {copiedCode === 'apk-cmds' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedCode === 'apk-cmds' ? 'Copied!' : 'Copy Commands'}</span>
                  </button>
                </div>
                <div className="relative rounded-lg bg-neutral-950 p-3.5 font-mono text-[11px] text-neutral-300 border border-neutral-800 overflow-x-auto">
                  <pre className="whitespace-pre">{apkBuildCommands}</pre>
                </div>
              </div>

              <div className="pt-2">
                <button
                  onClick={() => triggerProjectZipDownload()}
                  className="w-full py-2.5 px-4 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border border-neutral-700 font-semibold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <Download className="w-4 h-4 text-amber-400" />
                  <span>Download Complete Project ZIP (Offline / External Build)</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-neutral-200">Download Complete Project ZIP Archive</span>
                  <span className="text-[10px] text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded font-mono">Ready</span>
                </div>
                <p className="text-xs text-neutral-400 leading-relaxed">
                  Contains the complete, uncompiled source code, Android native Capacitor wrapper, all UI views, website editor, templates, chatbot system, and GitHub Actions APK build workflow.
                </p>
              </div>

              {/* Download Action Button */}
              <button
                onClick={() => triggerProjectZipDownload()}
                className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-neutral-950 font-bold text-xs shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 transition-all transform active:scale-98 cursor-pointer"
              >
                <Download className="w-4 h-4 text-neutral-950" />
                <span>Download money-making-empire-ai-website-builder.zip</span>
              </button>

              <div className="p-3.5 rounded-lg bg-neutral-950/80 border border-neutral-800 text-xs text-neutral-300 space-y-2">
                <div className="font-semibold text-neutral-200 flex items-center gap-1.5">
                  <Laptop className="w-4 h-4 text-amber-400" />
                  <span>Archive Structure (extracts to project root):</span>
                </div>
                <ul className="space-y-1 font-mono text-[11px] text-neutral-400 pl-4 list-disc">
                  <li><strong className="text-neutral-200">android/</strong> — Complete Capacitor Android project & Gradle files</li>
                  <li><strong className="text-neutral-200">src/</strong> — All React & TypeScript components, editor, & chatbot</li>
                  <li><strong className="text-neutral-200">public/</strong> — PWA icons, manifest, and assets</li>
                  <li><strong className="text-neutral-200">.github/workflows/</strong> — Automated Android APK GitHub Actions workflow</li>
                  <li><strong className="text-neutral-200">capacitor.config.json</strong> — Native Android configuration</li>
                  <li><strong className="text-neutral-200">package.json & lockfile</strong> — All dependencies</li>
                </ul>
              </div>

              <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800/80 text-[11px] text-neutral-400">
                <span className="text-amber-400 font-semibold">External Build Services: </span>
                You can directly upload this ZIP to any external Android build service, Cloud build pipeline, or extract it locally to run <code className="text-amber-300 font-mono">./gradlew assembleRelease</code>.
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-neutral-950 border-t border-neutral-800 flex items-center justify-between text-xs text-neutral-400">
          <span>Display Mode: <strong className="text-neutral-200">Standalone (Full Screen)</strong></span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-medium transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
