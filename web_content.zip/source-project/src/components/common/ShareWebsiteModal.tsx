import React, { useState } from 'react';
import { WebsiteProject } from '../../types/website';
import { 
  Globe, 
  Copy, 
  Check, 
  ExternalLink, 
  X, 
  AlertCircle, 
  Share2, 
  MessageSquare, 
  Mail,
  ArrowRight,
  ShieldCheck
} from 'lucide-react';

interface ShareWebsiteModalProps {
  project: WebsiteProject | null;
  isOpen: boolean;
  onClose: () => void;
  onDeployClick?: (project: WebsiteProject) => void;
}

/**
 * Returns the real public HTTPS website URL if the project is deployed.
 * Rejects fake, localhost, internal, or staging/preview URLs.
 */
export function getDeployedWebsiteUrl(project: WebsiteProject | null): string | null {
  if (!project) return null;

  // A project is considered deployed if it is explicitly marked 'live' or verified with propagated DNS
  const isDeployed = 
    project.status === 'live' || 
    Boolean(project.deployment?.verified && project.deployment?.dnsStatus === 'propagated');

  if (!isDeployed) {
    return null;
  }

  // Extract candidate domain
  let candidate = project.deployment?.customDomain || project.business?.websiteUrl || '';
  candidate = candidate.trim().replace(/^https?:\/\//i, '').replace(/\/+$/, '');

  // Exclude fake, localhost, internal, or staging domains
  if (
    !candidate ||
    candidate.includes('localhost') ||
    candidate.includes('127.0.0.1') ||
    candidate.includes('.internal') ||
    candidate.includes('.local') ||
    candidate.includes('staging') ||
    candidate.includes('empire-preview.app')
  ) {
    return null;
  }

  return `https://${candidate}`;
}

export const ShareWebsiteModal: React.FC<ShareWebsiteModalProps> = ({
  project,
  isOpen,
  onClose,
  onDeployClick,
}) => {
  const [copied, setCopied] = useState(false);
  const [shareFeedback, setShareFeedback] = useState<string | null>(null);

  if (!isOpen || !project) return null;

  const publicUrl = getDeployedWebsiteUrl(project);
  const isDeployed = Boolean(publicUrl);

  const handleCopy = async () => {
    if (!publicUrl) return;
    try {
      await navigator.clipboard.writeText(publicUrl);
      setCopied(true);
      setShareFeedback('Link copied to clipboard!');
      setTimeout(() => {
        setCopied(false);
        setShareFeedback(null);
      }, 3000);
    } catch {
      // Fallback
      setShareFeedback('Failed to copy. Please select and copy manually.');
    }
  };

  const handleNativeShare = async () => {
    if (!publicUrl) return;
    if (navigator.share) {
      try {
        await navigator.share({
          title: project.business.name,
          text: `Explore the official website of ${project.business.name}:`,
          url: publicUrl,
        });
        setShareFeedback('Shared successfully!');
      } catch (err: any) {
        if (err.name !== 'AbortError') {
          handleCopy();
        }
      }
    } else {
      handleCopy();
    }
  };

  const shareText = `Explore the official website for ${project.business.name}: ${publicUrl || ''}`;
  const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(shareText)}`;
  const mailtoUrl = `mailto:?subject=${encodeURIComponent(`Official Website: ${project.business.name}`)}&body=${encodeURIComponent(shareText)}`;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-150">
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-5 animate-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <span className="text-base">🔗</span>
            <h2 className="text-base font-bold text-neutral-100">Share Website</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-neutral-400 hover:text-white p-1 rounded-lg hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Project Info */}
        <div className="flex items-center justify-between p-3 rounded-xl bg-neutral-950 border border-neutral-800/80 text-xs">
          <div>
            <div className="font-bold text-neutral-200">{project.business.name}</div>
            <div className="text-neutral-500">{project.business.industry}</div>
          </div>
          <span className={`text-[10px] uppercase font-mono px-2 py-0.5 rounded font-semibold border ${
            project.status === 'live'
              ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
              : 'bg-neutral-800 text-neutral-400 border-neutral-700'
          }`}>
            {project.status.replace('_', ' ')}
          </span>
        </div>

        {/* CONDITIONAL BODY: DEPLOYED vs NOT DEPLOYED */}
        {isDeployed && publicUrl ? (
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400">
              <ShieldCheck className="w-4 h-4" />
              <span>Website is live on public HTTPS</span>
            </div>

            {/* Public URL Box */}
            <div className="space-y-1.5">
              <label className="text-[11px] font-mono uppercase text-neutral-400">
                Public Website URL
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  readOnly
                  value={publicUrl}
                  className="flex-1 px-3 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-neutral-100 font-mono focus:outline-none select-all"
                />
                <button
                  type="button"
                  onClick={handleCopy}
                  className="px-3 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs flex items-center gap-1.5 shadow-sm active:scale-95 transition-all whitespace-nowrap"
                  title="Copy link to clipboard"
                >
                  {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied!' : 'Copy Link'}</span>
                </button>
              </div>
            </div>

            {/* Share Options */}
            <div className="space-y-2 pt-2 border-t border-neutral-800/80">
              <div className="text-xs font-semibold text-neutral-300">Share Options:</div>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={handleNativeShare}
                  className="p-2.5 rounded-lg bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-white text-xs font-medium flex flex-col items-center gap-1 transition-colors"
                >
                  <Share2 className="w-4 h-4 text-amber-400" />
                  <span>Share</span>
                </button>
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2.5 rounded-lg bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-white text-xs font-medium flex flex-col items-center gap-1 transition-colors"
                >
                  <MessageSquare className="w-4 h-4 text-emerald-400" />
                  <span>WhatsApp</span>
                </a>
                <a
                  href={mailtoUrl}
                  className="p-2.5 rounded-lg bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-white text-xs font-medium flex flex-col items-center gap-1 transition-colors"
                >
                  <Mail className="w-4 h-4 text-sky-400" />
                  <span>Email</span>
                </a>
              </div>
            </div>

            {/* Open in new tab button */}
            <a
              href={publicUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-2.5 px-4 rounded-lg bg-neutral-950 border border-neutral-800 hover:border-neutral-700 text-neutral-200 hover:text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
            >
              <span>Visit Live Website</span>
              <ExternalLink className="w-3.5 h-3.5 text-neutral-400" />
            </a>

            {shareFeedback && (
              <div className="p-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs text-center font-medium animate-in fade-in">
                {shareFeedback}
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-4 py-2">
            <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/20 space-y-2">
              <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                <span>Deploy website first.</span>
              </div>
              <p className="text-xs text-neutral-300 leading-relaxed">
                This project has not been deployed to a live public HTTPS domain yet. Deploy the website to get a public link to share with your client.
              </p>
            </div>

            {onDeployClick && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onDeployClick(project);
                }}
                className="w-full py-2.5 px-4 rounded-lg bg-amber-500 hover:bg-amber-400 text-neutral-950 text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm active:scale-95 transition-all"
              >
                <span>Deploy Website Now</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        )}

      </div>
    </div>
  );
};
