import React, { useState } from 'react';
import { Smartphone, Download, CheckCircle2 } from 'lucide-react';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import { AndroidAppModal } from './AndroidAppModal';

interface PWAInstallButtonProps {
  variant?: 'header' | 'banner' | 'compact';
  className?: string;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({ 
  variant = 'header',
  className = '' 
}) => {
  const { isInstallable, isInstalled, install, isAndroid } = usePWAInstall();
  const [modalOpen, setModalOpen] = useState(false);

  const handleClick = async () => {
    if (isInstallable) {
      const outcome = await install();
      if (!outcome) {
        setModalOpen(true);
      }
    } else {
      setModalOpen(true);
    }
  };

  if (isInstalled) {
    if (variant === 'compact') {
      return (
        <span className={`inline-flex items-center gap-1 text-[11px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 ${className}`}>
          <CheckCircle2 className="w-3 h-3" />
          <span>App Installed</span>
        </span>
      );
    }
    return null;
  }

  if (variant === 'banner') {
    return (
      <>
        <div className={`p-4 rounded-xl bg-gradient-to-r from-amber-500/15 via-neutral-900 to-neutral-900 border border-amber-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-lg shadow-amber-500/5 ${className}`}>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-neutral-950 font-bold shadow-md shadow-amber-500/20 flex-shrink-0">
              <Smartphone className="w-5 h-5 text-neutral-950" />
            </div>
            <div>
              <div className="font-semibold text-neutral-100 text-sm flex items-center gap-2">
                <span>Install on Android Device</span>
                <span className="text-[10px] uppercase font-mono px-1.5 py-0.2 rounded bg-amber-400/20 text-amber-300">PWA & APK</span>
              </div>
              <p className="text-xs text-neutral-400 mt-0.5">
                Run standalone without browser navigation bar with full hardware speed.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 sm:self-center">
            <button
              onClick={handleClick}
              className="px-3.5 py-2 rounded-lg text-xs font-bold text-neutral-950 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 shadow-md shadow-amber-500/20 flex items-center gap-1.5 transition-all active:scale-95 whitespace-nowrap"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{isInstallable ? '1-Click Install' : 'Install Android App'}</span>
            </button>
          </div>
        </div>

        <AndroidAppModal isOpen={modalOpen} onClose={() => setModalOpen(false)} />
      </>
    );
  }

  // Header variant
  return (
    <>
      <button
        onClick={handleClick}
        title="Install Android App"
        className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-semibold border border-amber-500/30 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 transition-all active:scale-95 shadow-sm shadow-amber-500/10 ${className}`}
      >
        <Smartphone className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
        <span className="hidden sm:inline">Install Android App</span>
        <span className="sm:hidden">Install</span>
      </button>

      <AndroidAppModal isOpen={modalOpen} onClose={() => setModalOpen(false)} />
    </>
  );
};
