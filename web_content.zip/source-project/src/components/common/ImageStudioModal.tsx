import React, { useState } from 'react';
import { useProjects } from '../../context/ProjectContext';
import { ImageOrigin, ImageAspectRatio, ImageFocalPoint, AssetItem } from '../../types/website';
import { 
  optimizeClientImageUpload, 
  generateBrandedPlaceholderSvg, 
  imageFocalPointToClass, 
  imageAspectRatioToClass 
} from '../../utils/imageOptimizer';
import { aiProvider } from '../../services/aiProvider';
import { 
  Upload, 
  Sparkles, 
  Image as ImageIcon, 
  Link as LinkIcon, 
  Check, 
  X, 
  Crop, 
  Eye, 
  ShieldCheck, 
  Layers, 
  RefreshCw,
  Sliders,
  AlertCircle
} from 'lucide-react';

interface ImageStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentImageUrl?: string;
  currentAltText?: string;
  currentOrigin?: ImageOrigin;
  currentAspectRatio?: ImageAspectRatio;
  currentFocalPoint?: ImageFocalPoint;
  isPlaceholder?: boolean;
  sectionTitle?: string;
  sectionType?: string;
  onApply: (imageData: {
    url: string;
    altText: string;
    origin: ImageOrigin;
    aspectRatio: ImageAspectRatio;
    focalPoint: ImageFocalPoint;
    isPlaceholder: boolean;
  }) => void;
}

export const ImageStudioModal: React.FC<ImageStudioModalProps> = ({
  isOpen,
  onClose,
  currentImageUrl,
  currentAltText,
  currentOrigin = 'stock_licensed',
  currentAspectRatio = '16:9',
  currentFocalPoint = 'center',
  isPlaceholder = false,
  sectionTitle,
  sectionType = 'hero',
  onApply,
}) => {
  const { assets, addAsset, activeProject } = useProjects();

  const [activeTab, setActiveTab] = useState<'upload' | 'ai' | 'library' | 'stock' | 'placeholder'>('upload');
  
  // Image state
  const [selectedUrl, setSelectedUrl] = useState<string>(currentImageUrl || '');
  const [altText, setAltText] = useState<string>(currentAltText || '');
  const [origin, setOrigin] = useState<ImageOrigin>(currentOrigin);
  const [aspectRatio, setAspectRatio] = useState<ImageAspectRatio>(currentAspectRatio || '16:9');
  const [focalPoint, setFocalPoint] = useState<ImageFocalPoint>(currentFocalPoint || 'center');
  const [usePlaceholder, setUsePlaceholder] = useState<boolean>(isPlaceholder);

  // Upload state
  const [isCompressing, setIsCompressing] = useState(false);
  const [uploadStats, setUploadStats] = useState<{ size: string; dimensions: string } | null>(null);

  // AI Prompt state
  const defaultAiPrompt = activeProject
    ? `Create a premium modern ${activeProject.business.industry.toLowerCase()} ${sectionType} photography image with natural architectural lighting`
    : `Create a high-end luxury business ${sectionType} image`;
  const [aiPrompt, setAiPrompt] = useState<string>(defaultAiPrompt);
  const [isGeneratingAi, setIsGeneratingAi] = useState(false);

  // External URL input
  const [urlInput, setUrlInput] = useState('');

  if (!isOpen) return null;

  // Handle client device upload with auto-compression
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsCompressing(true);
    try {
      const optimized = await optimizeClientImageUpload(file);
      setSelectedUrl(optimized.dataUrl);
      setOrigin('client_upload');
      setUsePlaceholder(false);
      setUploadStats({ size: optimized.fileSize, dimensions: optimized.dimensions });
      if (!altText) {
        setAltText(`Client photograph for ${activeProject?.business.name || 'business'} ${sectionType}`);
      }
      // Also automatically save to asset library
      addAsset({
        name: file.name.replace(/\.[^/.]+$/, ''),
        url: optimized.dataUrl,
        altText: altText || `Client photograph for ${activeProject?.business.name || 'business'}`,
        category: sectionType as any || 'hero',
        dimensions: optimized.dimensions,
        fileSize: optimized.fileSize,
        format: optimized.format,
        origin: 'client_upload',
        license: 'Client Provided Asset',
        aspectRatio: optimized.aspectRatio,
      });
    } catch (err: any) {
      alert(`Image processing error: ${err.message}`);
    } finally {
      setIsCompressing(false);
    }
  };

  // Handle AI Image Generation
  const handleGenerateAiImage = async () => {
    if (!aiPrompt.trim()) return;

    setIsGeneratingAi(true);
    try {
      const result = await aiProvider.generateSectionImage({
        prompt: aiPrompt,
        industry: activeProject?.business.industry || 'Business Services',
        style: activeProject?.brand.style || 'Modern',
        sectionType,
        aspectRatio: aspectRatio === 'auto' ? '16:9' : aspectRatio,
        colorPalette: {
          primary: activeProject?.brand.primaryColor || '#0f172a',
          accent: activeProject?.brand.accentColor || '#d97706',
        },
      });

      setSelectedUrl(result.imageUrl);
      setAltText(result.altText);
      setOrigin(result.origin);
      setUsePlaceholder(false);

      // Save to asset library
      addAsset({
        name: `AI: ${aiPrompt.slice(0, 30)}...`,
        url: result.imageUrl,
        altText: result.altText,
        category: (sectionType as any) || 'hero',
        dimensions: result.dimensions || '1600x900',
        origin: 'ai_generated',
        prompt: aiPrompt,
        license: result.license,
        aspectRatio,
      });
    } catch (err: any) {
      alert(`AI generation failed: ${err.message}`);
    } finally {
      setIsGeneratingAi(false);
    }
  };

  // Handle Select from Library
  const handleSelectAsset = (asset: AssetItem) => {
    setSelectedUrl(asset.url);
    setAltText(asset.altText);
    setOrigin(asset.origin || 'client_upload');
    setUsePlaceholder(false);
    if (asset.aspectRatio) setAspectRatio(asset.aspectRatio);
  };

  // Handle Select Placeholder
  const handleSetPlaceholder = () => {
    const svgUrl = generateBrandedPlaceholderSvg(
      'Add your business image',
      aspectRatio === '16:9' ? '1200 x 675' : aspectRatio === '1:1' ? '800 x 800' : '1000 x 750',
      `${sectionType.toUpperCase()} Visual Slot`,
      activeProject?.brand.lightMode || false
    );
    setSelectedUrl(svgUrl);
    setAltText(`Clearly marked business image placeholder for ${sectionTitle || sectionType}`);
    setOrigin('placeholder');
    setUsePlaceholder(true);
  };

  // Apply Changes
  const handleApply = () => {
    if (!selectedUrl && !usePlaceholder) {
      alert('Please select, upload, or generate an image.');
      return;
    }

    onApply({
      url: selectedUrl,
      altText: altText || `${activeProject?.business.name || 'Business'} ${sectionType} visual`,
      origin,
      aspectRatio,
      focalPoint,
      isPlaceholder: usePlaceholder,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden text-neutral-200">
        
        {/* Modal Header */}
        <div className="h-16 px-6 border-b border-neutral-800 flex items-center justify-between bg-neutral-950 flex-shrink-0">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs uppercase font-mono tracking-wider text-amber-400 font-bold">
                Image Production Studio
              </span>
              <span className="text-neutral-600">·</span>
              <span className="text-xs text-neutral-400 capitalize">{sectionType} section image</span>
            </div>
            <h2 className="text-base font-bold text-white tracking-tight">
              Edit & Source Section Imagery
            </h2>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body: Split Controls & Live Preview */}
        <div className="flex-1 overflow-y-auto grid grid-cols-1 md:grid-cols-12 divide-y md:divide-y-0 md:divide-x divide-neutral-800">
          
          {/* Left Column: Sourcing Tabs & Inputs */}
          <div className="md:col-span-7 p-6 space-y-5">
            
            {/* Source Switcher Tabs */}
            <div className="flex border border-neutral-800 rounded-lg p-1 bg-neutral-950 text-xs overflow-x-auto">
              {[
                { id: 'upload', label: 'Client Upload', icon: Upload },
                { id: 'ai', label: 'AI Generate', icon: Sparkles },
                { id: 'library', label: 'Asset Library', icon: Layers },
                { id: 'stock', label: 'URL / Stock', icon: LinkIcon },
                { id: 'placeholder', label: 'Placeholder', icon: ImageIcon },
              ].map((tab) => {
                const Icon = tab.icon;
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as any)}
                    className={`flex-1 py-1.5 px-2.5 rounded-md font-medium whitespace-nowrap transition-colors flex items-center justify-center gap-1.5 ${
                      isActive
                        ? 'bg-neutral-800 text-amber-400 font-bold shadow-sm'
                        : 'text-neutral-400 hover:text-neutral-200'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </div>

            {/* TAB 1: CLIENT UPLOAD */}
            {activeTab === 'upload' && (
              <div className="space-y-4 text-xs">
                <div>
                  <h3 className="font-bold text-white text-sm mb-1">Upload Real Client Photography</h3>
                  <p className="text-neutral-400">
                    Supports JPG, PNG, WebP, and SVG. Uploads are automatically optimized for fast responsive delivery.
                  </p>
                </div>

                <label className="flex flex-col items-center justify-center h-36 border-2 border-dashed border-neutral-800 hover:border-amber-500/50 rounded-xl cursor-pointer bg-neutral-950 transition-colors p-4 text-center">
                  <Upload className="w-7 h-7 text-neutral-500 mb-2" />
                  <span className="font-semibold text-neutral-200">
                    {isCompressing ? 'Optimizing Image...' : 'Click to Browse Device Files'}
                  </span>
                  <span className="text-[10px] text-neutral-500 mt-1">
                    Automatic resize to WebP (max 1920px) · Zero loss of crispness
                  </span>
                  <input
                    type="file"
                    accept="image/jpeg,image/png,image/webp,image/svg+xml"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>

                {uploadStats && (
                  <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs flex items-center justify-between">
                    <span>Optimized: {uploadStats.dimensions} ({uploadStats.size})</span>
                    <span className="font-mono text-[10px] uppercase font-bold">Client Verified</span>
                  </div>
                )}
              </div>
            )}

            {/* TAB 2: AI GENERATE */}
            {activeTab === 'ai' && (
              <div className="space-y-4 text-xs">
                <div>
                  <h3 className="font-bold text-white text-sm mb-1">Generate Contextual AI Image</h3>
                  <p className="text-neutral-400">
                    Creates custom imagery matching the client's industry, brand palette, and section requirements. Never generates fake people or fraudulent evidence.
                  </p>
                </div>

                <div>
                  <label className="block text-[11px] uppercase tracking-wider text-neutral-400 font-semibold mb-1">
                    Image Prompt
                  </label>
                  <textarea
                    rows={3}
                    value={aiPrompt}
                    onChange={(e) => setAiPrompt(e.target.value)}
                    placeholder="e.g. Create a luxury restaurant interior image with timber and warm candlelight..."
                    className="w-full px-3 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>

                {/* Prompt Presets */}
                <div className="space-y-1">
                  <span className="text-[10px] text-neutral-500 uppercase tracking-wider font-semibold block">
                    Quick Industry Presets:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {[
                      'Create a premium modern dental clinic hero image.',
                      'Create a luxury restaurant interior image.',
                      'Create a professional roofing company hero image.',
                      'Create an executive law firm conference boardroom.',
                      'Create a luxury architectural estate hero image.',
                      'Create a minimal creative agency design studio loft.',
                      'Create a high-end luxury beauty salon styling suite.',
                      'Create a boutique fitness and pilates training sanctuary.',
                    ].map((preset, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setAiPrompt(preset)}
                        className="px-2.5 py-1 rounded bg-neutral-950 border border-neutral-800 hover:border-amber-500/40 text-[10px] text-neutral-400 hover:text-white truncate max-w-full"
                      >
                        {preset}
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleGenerateAiImage}
                  disabled={isGeneratingAi || !aiPrompt.trim()}
                  className="w-full py-2.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-neutral-950 font-bold flex items-center justify-center gap-1.5 shadow transition-all active:scale-95 disabled:opacity-50"
                >
                  {isGeneratingAi ? (
                    <>
                      <div className="w-3.5 h-3.5 border-2 border-neutral-950 border-t-transparent rounded-full animate-spin" />
                      <span>Synthesizing Visual Asset...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Generate AI Image</span>
                    </>
                  )}
                </button>
              </div>
            )}

            {/* TAB 3: ASSET LIBRARY */}
            {activeTab === 'library' && (
              <div className="space-y-3 text-xs">
                <div>
                  <h3 className="font-bold text-white text-sm mb-1">Pick from Project Asset Library</h3>
                  <p className="text-neutral-400">Previously uploaded client imagery and saved assets.</p>
                </div>

                <div className="grid grid-cols-3 gap-2.5 max-h-56 overflow-y-auto pr-1">
                  {assets.map((ast) => (
                    <div
                      key={ast.id}
                      onClick={() => handleSelectAsset(ast)}
                      className={`relative rounded-lg overflow-hidden border cursor-pointer group transition-all ${
                        selectedUrl === ast.url
                          ? 'border-amber-500 ring-2 ring-amber-500/40'
                          : 'border-neutral-800 hover:border-neutral-700'
                      }`}
                    >
                      <img
                        src={ast.url}
                        alt={ast.altText}
                        className="h-20 w-full object-cover"
                        loading="lazy"
                        referrerPolicy="no-referrer"
                      />
                      <div className="p-1 bg-neutral-950 text-[10px] truncate text-neutral-300">
                        {ast.name}
                      </div>
                      <span className="absolute top-1 right-1 text-[8px] uppercase px-1 py-0.2 rounded bg-black/80 font-mono text-white">
                        {ast.origin?.replace('_', ' ') || 'Asset'}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 4: STOCK / URL */}
            {activeTab === 'stock' && (
              <div className="space-y-4 text-xs">
                <div>
                  <h3 className="font-bold text-white text-sm mb-1">Licensed Commercial Stock & URL</h3>
                  <p className="text-neutral-400">
                    Enter a direct image URL with verified commercial use rights.
                  </p>
                </div>

                <div className="flex gap-2">
                  <input
                    type="text"
                    value={urlInput}
                    onChange={(e) => setUrlInput(e.target.value)}
                    placeholder="https://images.unsplash.com/photo-..."
                    className="flex-1 px-3 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:border-amber-500"
                  />
                  <button
                    onClick={() => {
                      if (urlInput.trim()) {
                        setSelectedUrl(urlInput.trim());
                        setOrigin('stock_licensed');
                        setUsePlaceholder(false);
                      }
                    }}
                    className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 font-semibold rounded-lg text-white"
                  >
                    Load URL
                  </button>
                </div>
              </div>
            )}

            {/* TAB 5: BRANDED PLACEHOLDER */}
            {activeTab === 'placeholder' && (
              <div className="space-y-4 text-xs">
                <div>
                  <h3 className="font-bold text-white text-sm mb-1">Honest Client Image Placeholder</h3>
                  <p className="text-neutral-400 leading-relaxed">
                    If legitimate client photography is not yet available, we show a refined, architectural placeholder marked <strong className="text-white">"Add your business image"</strong>. This preserves the layout integrity while preventing deceptive fake imagery.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 text-center space-y-3">
                  <div className="w-12 h-12 rounded-full bg-amber-500/10 text-amber-400 flex items-center justify-center mx-auto">
                    <ShieldCheck className="w-6 h-6" />
                  </div>
                  <div className="font-semibold text-white">Use Honest Architectural Placeholder</div>
                  <p className="text-[11px] text-neutral-400">
                    Displays exact dimensions and clear upload callouts without faking reviews or customer photos.
                  </p>
                  <button
                    type="button"
                    onClick={handleSetPlaceholder}
                    className="px-4 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-amber-400 font-bold border border-amber-500/30"
                  >
                    Set as Honest Placeholder
                  </button>
                </div>
              </div>
            )}

            {/* CROP & FOCAL POINT EDITING CONTROLS */}
            <div className="pt-4 border-t border-neutral-800 space-y-3 text-xs">
              <span className="font-bold uppercase tracking-wider text-amber-400 block">
                Image Crop & Focal Layout
              </span>

              {/* Aspect Ratio */}
              <div>
                <label className="block text-[11px] text-neutral-400 font-semibold mb-1">
                  Aspect Ratio
                </label>
                <div className="grid grid-cols-5 gap-1.5">
                  {[
                    { id: '16:9', label: '16:9 Wide' },
                    { id: '4:3', label: '4:3 Classic' },
                    { id: '1:1', label: '1:1 Square' },
                    { id: '21:9', label: '21:9 Cinema' },
                    { id: '3:4', label: '3:4 Portrait' },
                  ].map((asp) => (
                    <button
                      key={asp.id}
                      type="button"
                      onClick={() => setAspectRatio(asp.id as ImageAspectRatio)}
                      className={`py-1.5 px-1 text-center rounded border transition-all text-[11px] ${
                        aspectRatio === asp.id
                          ? 'border-amber-400 text-amber-400 bg-amber-500/10 font-bold'
                          : 'border-neutral-800 text-neutral-400 hover:text-white'
                      }`}
                    >
                      {asp.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Focal Point (Alignment) */}
              <div>
                <label className="block text-[11px] text-neutral-400 font-semibold mb-1">
                  Focal Center Point
                </label>
                <div className="grid grid-cols-5 gap-1.5">
                  {(['center', 'top', 'bottom', 'left', 'right'] as ImageFocalPoint[]).map((foc) => (
                    <button
                      key={foc}
                      type="button"
                      onClick={() => setFocalPoint(foc)}
                      className={`py-1.5 text-center rounded border capitalize text-[11px] transition-all ${
                        focalPoint === foc
                          ? 'border-amber-400 text-amber-400 bg-amber-500/10 font-bold'
                          : 'border-neutral-800 text-neutral-400 hover:text-white'
                      }`}
                    >
                      {foc}
                    </button>
                  ))}
                </div>
              </div>

              {/* Alt Text Input */}
              <div>
                <label className="block text-[11px] text-neutral-400 font-semibold mb-1">
                  Accessibility Alt Text *
                </label>
                <input
                  type="text"
                  value={altText}
                  onChange={(e) => setAltText(e.target.value)}
                  placeholder="Describe the image content for screen readers and SEO..."
                  className="w-full px-3 py-2 rounded bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:border-amber-500 text-xs"
                />
              </div>
            </div>

          </div>

          {/* Right Column: Live Responsive Preview & Metadata */}
          <div className="md:col-span-5 p-6 bg-neutral-950 flex flex-col justify-between space-y-4">
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs uppercase font-mono tracking-wider text-neutral-400 font-semibold">
                  Live Placement Preview
                </span>
                <span
                  className={`text-[10px] font-mono uppercase px-2 py-0.5 rounded font-bold ${
                    origin === 'client_upload'
                      ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                      : origin === 'ai_generated'
                      ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                      : origin === 'placeholder'
                      ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20'
                      : 'bg-neutral-800 text-neutral-400'
                  }`}
                >
                  Origin: {origin.replace('_', ' ')}
                </span>
              </div>

              {/* Crop Frame Simulation */}
              <div className="rounded-xl overflow-hidden border border-neutral-800 bg-neutral-900 shadow-xl relative group">
                {selectedUrl ? (
                  <div className={`w-full overflow-hidden ${imageAspectRatioToClass(aspectRatio)}`}>
                    <img
                      src={selectedUrl}
                      alt={altText}
                      className={`w-full h-full object-cover ${imageFocalPointToClass(focalPoint)}`}
                      referrerPolicy="no-referrer"
                    />
                  </div>
                ) : (
                  <div className="h-48 flex items-center justify-center text-neutral-500 text-xs">
                    No image selected
                  </div>
                )}

                {/* Overlaid Badge */}
                <div className="absolute bottom-2 left-2 px-2 py-1 rounded bg-black/75 backdrop-blur text-[10px] font-mono text-neutral-300">
                  {aspectRatio} · {focalPoint} focal point
                </div>
              </div>

              {/* Image Origin & Transparency Specs */}
              <div className="mt-4 p-3.5 rounded-lg bg-neutral-900 border border-neutral-800 text-xs space-y-1.5">
                <div className="flex justify-between text-neutral-400">
                  <span>Source Classification:</span>
                  <span className="font-semibold text-white capitalize">{origin.replace('_', ' ')}</span>
                </div>
                <div className="flex justify-between text-neutral-400">
                  <span>Commercial Rights:</span>
                  <span className="text-emerald-400 font-medium">Verified / Safe for Client Site</span>
                </div>
                <div className="flex justify-between text-neutral-400">
                  <span>Optimization:</span>
                  <span className="text-neutral-300">Responsive Container / Lazy Loaded</span>
                </div>
              </div>
            </div>

            {/* Modal Bottom Actions */}
            <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-800">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-lg text-neutral-400 hover:text-white text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleApply}
                className="px-5 py-2.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-neutral-950 font-bold text-xs shadow-md transition-all active:scale-95 flex items-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                <span>Apply to Website</span>
              </button>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
