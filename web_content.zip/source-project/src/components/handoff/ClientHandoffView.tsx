import React, { useState } from 'react';
import { useProjects } from '../../context/ProjectContext';
import { 
  FileCheck, 
  Copy, 
  Check, 
  Printer, 
  ExternalLink, 
  Mail, 
  Phone, 
  MessageSquare, 
  Globe, 
  ShieldCheck, 
  Lock,
  Layers,
  Sparkles
} from 'lucide-react';

export const ClientHandoffView: React.FC = () => {
  const { activeProject, projects, setActiveProject } = useProjects();
  const [copiedType, setCopiedType] = useState<string | null>(null);

  if (!activeProject) {
    return (
      <div className="p-12 text-center text-neutral-400">
        <p>No active project selected. Select a project to generate client handoff.</p>
      </div>
    );
  }

  const p = activeProject;
  const deployment = p.deployment;

  const emailText = `Subject: Your Website Delivery & Handoff Summary — ${p.business.name}

Hi ${p.clientName},

We are pleased to deliver your new custom business website for ${p.business.name}.

WEBSITE CREDENTIALS & ACCESS
----------------------------------------
- Production URL: ${deployment.customDomain ? `https://${deployment.customDomain}` : deployment.deploymentUrl}
- Staging Preview: ${deployment.deploymentUrl}
- Current Status: ${p.status.toUpperCase()}
- SSL Encryption: ${deployment.httpsActive ? 'Active (HTTPS 256-bit)' : 'Pending DNS'}

PRIMARY CONTACT & CONVERSION CHANNELS
----------------------------------------
- Primary Phone: ${p.business.phone || 'N/A'}
- WhatsApp Inquiries: ${p.business.whatsapp || 'N/A'}
- Contact Email: ${p.business.email || 'N/A'}
- Physical Location: ${p.business.location || 'N/A'}

BRAND GUIDELINES & PALETTE
----------------------------------------
- Primary Color: ${p.brand.primaryColor}
- Accent Color: ${p.brand.accentColor}
- Typography Family: ${p.brand.fontPairing}

ROUTINE MAINTENANCE & UPDATES
----------------------------------------
1. All inquiries submitted through your contact form are routed directly to ${p.business.email || 'your email'}.
2. Phone and WhatsApp buttons connect directly to your designated lines.
3. If you need text or imagery updates, please send your requests to our studio.

Thank you for partnering with us!
`;

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(emailText);
    setCopiedType('email');
    setTimeout(() => setCopiedType(null), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-6">
      
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="text-[11px] font-mono uppercase tracking-wider text-amber-400 font-semibold mb-1">
            Client Delivery Document
          </div>
          <h1 className="text-2xl font-bold text-neutral-100 tracking-tight">Client Handoff Portal</h1>
          <p className="text-xs text-neutral-400 mt-1">
            Generate and deliver an executive handoff package with URLs, DNS records, brand specifications, and maintenance notes.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopyEmail}
            className="px-3.5 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-all"
          >
            {copiedType === 'email' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>Copy Handoff Email</span>
          </button>
          <button
            onClick={handlePrint}
            className="px-3.5 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-all"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Report</span>
          </button>
        </div>
      </div>

      {/* Main Handoff Document Sheet */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-6 sm:p-10 shadow-2xl space-y-8 text-neutral-200">
        
        {/* Document Header */}
        <div className="border-b border-neutral-800 pb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-[10px] font-mono uppercase tracking-widest text-amber-400 font-bold block mb-1">
              Production Website Handoff
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              {p.business.name}
            </h2>
            <div className="text-xs text-neutral-400 mt-0.5">
              Client: <span className="text-neutral-200 font-medium">{p.clientName}</span> · Scope: {p.type}
            </div>
          </div>

          <div className="text-right">
            <span
              className={`inline-block px-3 py-1 rounded font-mono text-xs uppercase font-bold ${
                p.status === 'live'
                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                  : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
              }`}
            >
              Status: {p.status.replace('_', ' ')}
            </span>
            <div className="text-[10px] text-neutral-500 mt-1">
              Delivered: {new Date().toLocaleDateString()}
            </div>
          </div>
        </div>

        {/* Section 1: Live Production & Staging URLs */}
        <div className="space-y-3">
          <h3 className="text-xs uppercase tracking-wider font-bold text-neutral-400 flex items-center gap-1.5">
            <Globe className="w-4 h-4 text-amber-400" />
            <span>Production & Staging Access</span>
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 rounded-lg bg-neutral-950 border border-neutral-800">
              <span className="text-[11px] text-neutral-500 block mb-1">Live Custom Domain</span>
              <a
                href={deployment.customDomain ? `https://${deployment.customDomain}` : '#'}
                target="_blank"
                rel="noreferrer"
                className="text-sm font-mono text-amber-400 font-bold hover:underline flex items-center gap-1.5"
              >
                <span>{deployment.customDomain || 'Pending Domain Connection'}</span>
                {deployment.customDomain && <ExternalLink className="w-3.5 h-3.5" />}
              </a>
            </div>

            <div className="p-4 rounded-lg bg-neutral-950 border border-neutral-800">
              <span className="text-[11px] text-neutral-500 block mb-1">Staging / Backup URL</span>
              <a
                href={deployment.deploymentUrl}
                target="_blank"
                rel="noreferrer"
                className="text-xs font-mono text-neutral-300 hover:underline flex items-center gap-1.5 truncate"
              >
                <span className="truncate">{deployment.deploymentUrl}</span>
                <ExternalLink className="w-3.5 h-3.5 flex-shrink-0" />
              </a>
            </div>
          </div>
        </div>

        {/* Section 2: Communication & Conversion Infrastructure */}
        <div className="space-y-3">
          <h3 className="text-xs uppercase tracking-wider font-bold text-neutral-400 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Active Lead Routing Channels</span>
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800">
              <span className="text-[10px] text-neutral-500 block">Click-to-Call Phone</span>
              <span className="font-semibold text-white">{p.business.phone || 'Not Configured'}</span>
            </div>
            <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800">
              <span className="text-[10px] text-neutral-500 block">WhatsApp Direct Concierge</span>
              <span className="font-semibold text-emerald-400">{p.business.whatsapp || 'Not Configured'}</span>
            </div>
            <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800">
              <span className="text-[10px] text-neutral-500 block">Lead Notification Email</span>
              <span className="font-semibold text-white truncate block">{p.business.email || 'Not Configured'}</span>
            </div>
          </div>
        </div>

        {/* Section 3: Brand Guidelines Summary */}
        <div className="space-y-3">
          <h3 className="text-xs uppercase tracking-wider font-bold text-neutral-400 flex items-center gap-1.5">
            <Layers className="w-4 h-4 text-cyan-400" />
            <span>Brand Colors & Typography Reference</span>
          </h3>
          <div className="p-4 rounded-lg bg-neutral-950 border border-neutral-800 flex flex-wrap items-center justify-between gap-4 text-xs">
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 rounded border border-neutral-700" style={{ backgroundColor: p.brand.primaryColor }} />
              <div>
                <div className="font-bold text-white">Primary Brand</div>
                <div className="font-mono text-[10px] text-neutral-400">{p.brand.primaryColor}</div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-6 h-6 rounded border border-neutral-700" style={{ backgroundColor: p.brand.accentColor }} />
              <div>
                <div className="font-bold text-white">Accent Highlight</div>
                <div className="font-mono text-[10px] text-neutral-400">{p.brand.accentColor}</div>
              </div>
            </div>

            <div>
              <div className="font-bold text-white">Font Pairing</div>
              <div className="text-[10px] text-neutral-400">{p.brand.fontPairing} ({p.brand.style})</div>
            </div>
          </div>
        </div>

        {/* Section 4: Basic Maintenance Notes */}
        <div className="space-y-3 border-t border-neutral-800 pt-6 text-xs text-neutral-400 leading-relaxed">
          <h3 className="text-xs uppercase tracking-wider font-bold text-neutral-300">
            Client Maintenance & Operating Notes
          </h3>
          <ul className="space-y-2 list-disc list-inside text-[11px]">
            <li>Your website is hosted on globally distributed edge nodes for sub-second load times.</li>
            <li>Automated SSL certificates renew periodically with zero manual action required.</li>
            <li>Inquiries submitted through the contact forms are delivered in real time to <span className="text-neutral-200">{p.business.email}</span>.</li>
            <li>Click-to-call and WhatsApp buttons connect callers directly to your designated staff lines.</li>
            <li>For content revisions, text changes, or new section additions, please submit your request to your account manager.</li>
          </ul>
        </div>

      </div>

    </div>
  );
};
