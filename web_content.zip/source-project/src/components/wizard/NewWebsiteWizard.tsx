import React, { useState } from 'react';
import { useProjects } from '../../context/ProjectContext';
import { 
  BusinessInfo, 
  BrandConfig, 
  WebsiteType, 
  BrandStyle, 
  PrimaryGoal, 
  WebsiteProject,
  WebsiteSection 
} from '../../types/website';
import { aiProvider } from '../../services/aiProvider';
import { generateBrandedPlaceholderSvg } from '../../utils/imageOptimizer';
import { createDefaultPagesForBusiness } from '../../utils/multiPageBuilder';
import { validateAndSanitizeProject } from '../../utils/promptExtractor';
import { 
  Building2, 
  Palette, 
  Layers, 
  FileText, 
  Sparkles, 
  ArrowRight, 
  ArrowLeft, 
  Check, 
  Plus, 
  Trash2,
  Wand2,
  AlertCircle,
  Image as ImageIcon,
  ShieldCheck,
  Sliders
} from 'lucide-react';
import { AIPromptBuilder } from './AIPromptBuilder';

const WEBSITE_TYPES: WebsiteType[] = [
  'Business Website',
  'Landing Page',
  'Service Business',
  'Local Business',
  'Medical/Dental',
  'Law Firm',
  'Real Estate',
  'Agency',
  'Restaurant',
  'Accounting',
  'Fitness',
  'Beauty/Salon',
  'Consultant',
  'SaaS',
  'Portfolio',
  'E-commerce',
  'Other',
];

const BRAND_STYLES: BrandStyle[] = [
  'Luxury',
  'Modern',
  'Minimal',
  'Corporate',
  'Bold',
  'Elegant',
  'Editorial',
  'Friendly',
  'Technology',
  'Premium Local Business',
];

const PRIMARY_GOALS: PrimaryGoal[] = [
  'Generate calls',
  'Generate WhatsApp messages',
  'Generate leads',
  'Book appointments',
  'Get quote requests',
  'Sell products',
  'Build credibility',
  'Showcase portfolio',
  'Other',
];

const DEFAULT_PAGES_OPTIONS = [
  'Home',
  'About',
  'Services',
  'Portfolio',
  'Pricing',
  'FAQ',
  'Contact',
  'Booking',
  'Privacy Policy',
  'Terms',
];

export const NewWebsiteWizard: React.FC = () => {
  const { createProject, setActiveView, aiStatus } = useProjects();
  const [builderMode, setBuilderMode] = useState<'ai_prompt' | 'guided'>('ai_prompt');
  const [step, setStep] = useState<number>(1);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationError, setGenerationError] = useState<string | null>(null);

  // STEP 1 STATE
  const [business, setBusiness] = useState<BusinessInfo>({
    name: '',
    industry: '',
    description: '',
    location: '',
    phone: '',
    email: '',
    whatsapp: '',
    websiteUrl: '',
    socialUrls: {},
    businessHours: 'Mon - Fri: 9:00 AM - 6:00 PM',
    services: ['Bespoke Consultation', 'Full Project Implementation', 'Dedicated Support'],
    products: [],
    targetAudience: 'High-value private and enterprise clients seeking premium outcomes',
    primaryGoal: 'Generate leads',
  });
  const [newServiceInput, setNewServiceInput] = useState('');

  // STEP 2 STATE
  const [brand, setBrand] = useState<BrandConfig>({
    logoUrl: '',
    primaryColor: '#0f172a',
    secondaryColor: '#1e293b',
    accentColor: '#d97706',
    fontPairing: 'modern',
    style: 'Modern',
    borderRadius: 'subtle',
    lightMode: true,
  });
  const [imageStrategy, setImageStrategy] = useState<'niche_verified' | 'honest_placeholders' | 'ai_generate'>('niche_verified');

  // STEP 3 STATE
  const [selectedType, setSelectedType] = useState<WebsiteType>('Business Website');

  // STEP 4 STATE
  const [selectedPages, setSelectedPages] = useState<string[]>(['Home', 'Services', 'FAQ', 'Contact']);
  const [customPageInput, setCustomPageInput] = useState('');

  // Auto AI styling assistant
  const handleAutoDesignDirection = () => {
    const recommended = aiProvider.improveDesign(brand.style, business.industry);
    setBrand((prev) => ({
      ...prev,
      ...recommended,
    }));
  };

  const addService = () => {
    if (newServiceInput.trim()) {
      setBusiness((prev) => ({
        ...prev,
        services: [...prev.services, newServiceInput.trim()],
      }));
      setNewServiceInput('');
    }
  };

  const removeService = (index: number) => {
    setBusiness((prev) => ({
      ...prev,
      services: prev.services.filter((_, idx) => idx !== index),
    }));
  };

  const togglePage = (page: string) => {
    if (page === 'Home') return; // Home is always required
    if (selectedPages.includes(page)) {
      setSelectedPages(selectedPages.filter((p) => p !== page));
    } else {
      setSelectedPages([...selectedPages, page]);
    }
  };

  const addCustomPage = () => {
    if (customPageInput.trim() && !selectedPages.includes(customPageInput.trim())) {
      setSelectedPages([...selectedPages, customPageInput.trim()]);
      setCustomPageInput('');
    }
  };

  // Niche Imagery Helper for Wizard Generation
  const resolveWizardImage = async (
    sectionName: 'hero' | 'about' | 'service' | 'portfolio' | 'gallery' | 'cta',
    slotLabel: string,
    dimensions: string,
    idx = 0
  ): Promise<{
    url: string;
    altText: string;
    origin: 'client_upload' | 'ai_generated' | 'stock_licensed' | 'placeholder';
    isPlaceholder: boolean;
  }> => {
    if (imageStrategy === 'honest_placeholders') {
      return {
        url: generateBrandedPlaceholderSvg(
          'Add your business image',
          dimensions,
          `${business.name || 'Business'} ${slotLabel}`,
          brand.lightMode
        ),
        altText: `Placeholder for ${business.name || 'business'} ${slotLabel}`,
        origin: 'placeholder',
        isPlaceholder: true,
      };
    }

    if (imageStrategy === 'ai_generate') {
      try {
        const aiImg = await aiProvider.generateSectionImage({
          prompt: `Create a premium modern ${business.industry || 'business'} ${slotLabel} image`,
          industry: business.industry || 'Professional Services',
          style: brand.style,
          sectionType: sectionName,
          aspectRatio: '16:9',
        });
        return {
          url: aiImg.imageUrl,
          altText: aiImg.altText,
          origin: 'ai_generated',
          isPlaceholder: false,
        };
      } catch (e) {
        // fallback to niche below
      }
    }

    // Niche Verified Photography
    const lower = (business.industry || selectedType || '').toLowerCase();
    let url = 'https://images.unsplash.com/photo-1497215728101-856f4ea42174?auto=format&fit=crop&w=1200&q=80';
    let altText = `${business.name} professional workspace and consulting suite`;

    if (lower.includes('dent') || lower.includes('oral') || lower.includes('smile')) {
      if (sectionName === 'hero') {
        url = 'https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&w=1200&q=80';
        altText = 'Architectural cosmetic dental operatory suite with panoramic city views';
      } else if (sectionName === 'about') {
        url = 'https://images.unsplash.com/photo-1629909615184-74f495363b67?auto=format&fit=crop&w=1200&q=80';
        altText = 'Boutique consultation suite with ambient lighting and diagnostic imaging';
      } else if (sectionName === 'cta') {
        url = 'https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?auto=format&fit=crop&w=1200&q=80';
        altText = 'Swiss precision ceramic dental restorative equipment';
      } else {
        const pool = [
          'https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1629909615184-74f495363b67?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1606811841689-23dfddce3e95?auto=format&fit=crop&w=800&q=80',
        ];
        url = pool[idx % pool.length];
        altText = 'Aura dental clinical suite';
      }
    } else if (lower.includes('restaur') || lower.includes('food') || lower.includes('dining')) {
      if (sectionName === 'hero') {
        url = 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=80';
        altText = 'Architectural dining room with oak tables and ambient warm lighting';
      } else if (sectionName === 'about') {
        url = 'https://images.unsplash.com/photo-1550966871-3ed3cdb5ed0c?auto=format&fit=crop&w=1200&q=80';
        altText = 'Private sommelier dining sanctuary with timber finishes';
      } else if (sectionName === 'cta') {
        url = 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=1200&q=80';
        altText = 'Contemporary seasonal gastronomy tasting dish plated over natural cedar';
      } else {
        const pool = [
          'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1550966871-3ed3cdb5ed0c?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=800&q=80',
        ];
        url = pool[idx % pool.length];
        altText = 'Signature gastronomy dish and dining ambiance';
      }
    } else if (lower.includes('roof') || lower.includes('contract') || lower.includes('trade')) {
      if (sectionName === 'hero') {
        url = 'https://images.unsplash.com/photo-1632759145351-1d592919f522?auto=format&fit=crop&w=1200&q=80';
        altText = 'High-definition architectural shingle roof on a custom modern residential home';
      } else if (sectionName === 'about') {
        url = 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1200&q=80';
        altText = 'Modern residential roofline with copper gutters and architectural detailing';
      } else if (sectionName === 'cta') {
        url = 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=1200&q=80';
        altText = 'Licensed roofing specialists inspecting standing seam metal roof';
      } else {
        const pool = [
          'https://images.unsplash.com/photo-1632759145351-1d592919f522?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=800&q=80',
        ];
        url = pool[idx % pool.length];
        altText = 'Architectural residential roofing project';
      }
    } else if (lower.includes('law') || lower.includes('legal') || lower.includes('attorney')) {
      if (sectionName === 'hero') {
        url = 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80';
        altText = 'Metropolitan corporate law office skyscraper against clear morning sky';
      } else {
        url = 'https://images.unsplash.com/photo-1497215728101-856f4ea42174?auto=format&fit=crop&w=1200&q=80';
        altText = 'Executive law firm boardroom with panoramic glass windows';
      }
    } else if (lower.includes('real') || lower.includes('estate')) {
      if (sectionName === 'hero') {
        url = 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1200&q=80';
        altText = 'Contemporary luxury architectural villa with infinity pool and glass facade';
      } else if (sectionName === 'about') {
        url = 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80';
        altText = 'Architectural living pavilion with natural stone hearth';
      } else {
        url = 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1200&q=80';
        altText = 'Private estate dining terrace overlooking landscaped coastal horizon';
      }
    }

    return {
      url,
      altText,
      origin: 'stock_licensed',
      isPlaceholder: false,
    };
  };

  // STEP 5: FINAL GENERATION
  const handleGenerateWebsite = async () => {
    setIsGenerating(true);
    setGenerationError(null);

    try {
      const generatedCopy = await aiProvider.generateWebsite({
        business,
        brand,
        type: selectedType,
        pages: selectedPages,
      });

      const projectId = `prj-${Date.now()}`;

      // Resolve Hero Image
      const heroImg = await resolveWizardImage('hero', 'Hero Visual Slot', '1200 x 675 (16:9)');

      // Assemble sections
      const sections: WebsiteSection[] = [];
      let orderIndex = 1;

      // 1. HERO SECTION
      sections.push({
        id: `sec-hero-${Date.now()}`,
        type: 'hero',
        title: generatedCopy.heroHeadline,
        subtitle: generatedCopy.heroSubheadline,
        kicker: `${business.industry || selectedType} · ${business.location || 'Excellence'}`,
        layoutVariant: 'split-right',
        imageUrl: heroImg.url,
        imageAlt: heroImg.altText,
        imageOrigin: heroImg.origin,
        isImagePlaceholder: heroImg.isPlaceholder,
        imageAspectRatio: '16:9',
        imageFocalPoint: 'center',
        ctaPrimary: {
          label: generatedCopy.heroCtaPrimary || 'Schedule Consultation',
          link: '#contact',
          type: 'primary',
          icon: 'arrow',
        },
        ctaSecondary: business.whatsapp
          ? {
              label: 'Direct WhatsApp Line',
              link: `https://wa.me/${business.whatsapp.replace(/[^0-9]/g, '')}`,
              type: 'whatsapp',
              icon: 'whatsapp',
            }
          : {
              label: 'View Services',
              link: '#services',
              type: 'outline',
              icon: 'arrow',
            },
        isVisible: true,
        order: orderIndex++,
      });

      // 2. ABOUT SECTION (If selected or relevant)
      if (selectedPages.includes('About')) {
        const aboutImg = await resolveWizardImage('about', 'Facility & Studio Slot', '1000 x 750 (4:3)');
        sections.push({
          id: `sec-about-${Date.now()}`,
          type: 'about',
          title: `About ${business.name}`,
          subtitle: generatedCopy.aboutNarrative || business.description,
          kicker: 'Our Philosophy & Standards',
          layoutVariant: 'split-left',
          imageUrl: aboutImg.url,
          imageAlt: aboutImg.altText,
          imageOrigin: aboutImg.origin,
          isImagePlaceholder: aboutImg.isPlaceholder,
          imageAspectRatio: '4:3',
          imageFocalPoint: 'center',
          items: [
            { id: 'ab-1', title: 'Dedicated Principal Oversight', description: 'Every engagement is directed personally by licensed specialists.' },
            { id: 'ab-2', title: 'Uncompromising Quality Materials', description: 'Sourced from verified manufacturers with guaranteed durability.' },
            { id: 'ab-3', title: 'Transparent Milestone Pricing', description: 'Zero hidden add-ons or scope creep.' },
          ],
          isVisible: true,
          order: orderIndex++,
        });
      }

      // 3. SERVICES SECTION
      const serviceItems = await Promise.all(
        generatedCopy.services.map(async (srv, idx) => {
          const srvImg = await resolveWizardImage('service', `${srv.title} Capability Slot`, '800 x 450 (16:9)', idx);
          return {
            id: `srv-${idx}-${Date.now()}`,
            title: srv.title,
            description: srv.description,
            badge: srv.badge || `Capability 0${idx + 1}`,
            imageUrl: srvImg.url,
            imageAlt: srvImg.altText,
            imageOrigin: srvImg.origin,
            isPlaceholder: srvImg.isPlaceholder,
          };
        })
      );

      sections.push({
        id: `sec-services-${Date.now()}`,
        type: 'services',
        title: 'Specialized Capabilities',
        subtitle: `Tailored ${business.industry || 'services'} executed with rigorous standards and complete accountability.`,
        layoutVariant: 'grid-3',
        items: serviceItems,
        isVisible: true,
        order: orderIndex++,
      });

      // 4. PORTFOLIO SECTION (If selected)
      if (selectedPages.includes('Portfolio')) {
        const portfolioItems = await Promise.all([
          resolveWizardImage('portfolio', 'Featured Project 01', '800 x 600', 0),
          resolveWizardImage('portfolio', 'Featured Project 02', '800 x 600', 1),
          resolveWizardImage('portfolio', 'Featured Project 03', '800 x 600', 2),
        ]);

        sections.push({
          id: `sec-portfolio-${Date.now()}`,
          type: 'portfolio',
          title: 'Featured Client Engagements',
          subtitle: 'A selection of recent projects delivered according to rigorous architectural and craft standards.',
          layoutVariant: 'grid-3',
          items: [
            {
              id: 'p-1',
              title: `${business.location || 'Metropolitan'} Executive Project`,
              description: 'Comprehensive scope delivered on schedule with microscopic quality inspection.',
              imageUrl: portfolioItems[0].url,
              imageAlt: portfolioItems[0].altText,
              imageOrigin: portfolioItems[0].origin,
              isPlaceholder: portfolioItems[0].isPlaceholder,
              badge: 'Completed',
              features: ['Full Turnkey', 'Verified Signoff'],
            },
            {
              id: 'p-2',
              title: 'Private Commission Transformation',
              description: 'Bespoke custom specification tailored to complex site constraints.',
              imageUrl: portfolioItems[1].url,
              imageAlt: portfolioItems[1].altText,
              imageOrigin: portfolioItems[1].origin,
              isPlaceholder: portfolioItems[1].isPlaceholder,
              badge: 'Completed',
              features: ['Custom Materials', 'Warranty Protected'],
            },
            {
              id: 'p-3',
              title: 'Institutional Grade Modernization',
              description: 'High-throughput overhaul with continuous stakeholder reporting.',
              imageUrl: portfolioItems[2].url,
              imageAlt: portfolioItems[2].altText,
              imageOrigin: portfolioItems[2].origin,
              isPlaceholder: portfolioItems[2].isPlaceholder,
              badge: 'Completed',
              features: ['Compliance Verified', 'Guaranteed Scope'],
            },
          ],
          isVisible: true,
          order: orderIndex++,
        });
      }

      // 5. PROCESS SECTION
      sections.push({
        id: `sec-process-${Date.now()}`,
        type: 'process',
        title: 'Client Engagement Protocol',
        subtitle: 'A transparent 3-step workflow ensuring precision from diagnostic discovery to final delivery.',
        layoutVariant: 'timeline',
        items: generatedCopy.processSteps.map((stp, idx) => ({
          id: `step-${idx}-${Date.now()}`,
          title: stp.title,
          description: stp.description,
        })),
        isVisible: true,
        order: orderIndex++,
      });

      // 6. PRICING SECTION (If selected)
      if (selectedPages.includes('Pricing')) {
        sections.push({
          id: `sec-pricing-${Date.now()}`,
          type: 'pricing',
          title: 'Transparent Engagement Scopes',
          subtitle: 'Structured investment tiers designed for predictability, transparent milestones, and zero scope creep.',
          layoutVariant: 'grid-3',
          items: [
            {
              id: 'tier-1',
              title: 'Essential Consultation',
              price: 'Diagnostic',
              description: 'Thorough evaluation, preliminary discovery, and formulated execution roadmap.',
              features: ['Comprehensive Audit', 'Written Diagnostic Report', 'Direct Specialist Consultation'],
            },
            {
              id: 'tier-2',
              title: 'Full Execution Scope',
              price: 'Custom Project',
              badge: 'Recommended',
              description: 'End-to-end implementation with dedicated principal management and delivery signoff.',
              features: ['Complete Implementation', 'Dedicated Account Lead', 'Priority Scheduling', 'Warranty & Quality Signoff'],
            },
            {
              id: 'tier-3',
              title: 'Ongoing Retainer',
              price: 'Advisory',
              description: 'Continuous oversight, preventive servicing, and priority response guarantees.',
              features: ['Regular Scheduled Inspections', 'Guaranteed Response Times', 'Dedicated Maintenance'],
            },
          ],
          isVisible: true,
          order: orderIndex++,
        });
      }

      // 7. HIGH-CONVERTING CTA BANNER
      const ctaBgImg = await resolveWizardImage('cta', 'CTA Background Visual Slot', '1600 x 900 (16:9)');
      sections.push({
        id: `sec-cta-${Date.now()}`,
        type: 'cta-banner',
        title: `Ready to Discuss Your Project with ${business.name}?`,
        subtitle: 'Schedule a private diagnostic consultation or reach out directly via phone or WhatsApp.',
        kicker: 'Begin Consultation',
        layoutVariant: 'centered',
        imageUrl: ctaBgImg.url,
        imageAlt: ctaBgImg.altText,
        imageOrigin: ctaBgImg.origin,
        isImagePlaceholder: ctaBgImg.isPlaceholder,
        ctaPrimary: {
          label: 'Book Consultation',
          link: '#contact',
          type: 'primary',
          icon: 'calendar',
        },
        ctaSecondary: business.phone
          ? {
              label: `Call ${business.phone}`,
              link: `tel:${business.phone}`,
              type: 'call',
              icon: 'phone',
            }
          : undefined,
        isVisible: true,
        order: orderIndex++,
      });

      // 8. FAQ SECTION
      sections.push({
        id: `sec-faq-${Date.now()}`,
        type: 'faq',
        title: 'Frequently Asked Questions',
        subtitle: 'Clear, direct answers regarding scope, scheduling, and project execution.',
        layoutVariant: 'accordion',
        items: generatedCopy.faq.map((fq, idx) => ({
          id: `faq-${idx}-${Date.now()}`,
          title: fq.question,
          description: fq.answer,
        })),
        isVisible: true,
        order: orderIndex++,
      });

      // 9. CONTACT SECTION
      sections.push({
        id: `sec-contact-${Date.now()}`,
        type: 'contact',
        title: 'Initiate a Consultation',
        subtitle: 'Submit your requirements below or reach our direct line to discuss your objectives.',
        layoutVariant: 'split-left',
        ctaPrimary: {
          label: 'Submit Request',
          link: '#',
          type: 'primary',
          icon: 'mail',
        },
        ctaSecondary: business.phone
          ? {
              label: `Call ${business.phone}`,
              link: `tel:${business.phone}`,
              type: 'call',
              icon: 'phone',
            }
          : undefined,
        isVisible: true,
        order: orderIndex++,
      });

      const newProject: WebsiteProject = {
        id: projectId,
        name: `${business.name || 'New Client'} Website`,
        clientName: business.name || 'Client',
        status: 'draft',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        business,
        brand,
        type: selectedType,
        activePageId: 'page-home',
        deployment: {
          provider: 'manual',
          customDomain: business.websiteUrl?.replace(/^https?:\/\//, '') || '',
          deploymentUrl: `https://${projectId.slice(0, 16)}.empire-preview.app`,
          verified: false,
          httpsActive: true,
          dnsStatus: 'not_configured',
          dnsRecords: [
            { type: 'A', name: '@', value: '76.76.21.21', ttl: '3600', status: 'pending' },
            { type: 'CNAME', name: 'www', value: 'cname.empire-network.net', ttl: '3600', status: 'pending' },
          ],
        },
        pages: createDefaultPagesForBusiness(business, brand, sections),
      };

      const verified = validateAndSanitizeProject(
        newProject,
        `${business.name} ${business.industry} ${business.description}`,
        business
      );

      createProject(verified);
    } catch (err: any) {
      console.error('Generation error:', err);
      setGenerationError(err.message || 'An error occurred during website compilation.');
      setIsGenerating(false);
    }
  };

  if (builderMode === 'ai_prompt') {
    return <AIPromptBuilder onSwitchToGuided={() => setBuilderMode('guided')} />;
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Wizard Header with Mode Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-mono uppercase tracking-wider text-amber-400 font-semibold">
              Guided Website Production Wizard
            </span>
            <span className="text-xs text-neutral-400">
              · Step {step} of 5
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-neutral-100 tracking-tight">
            Create Client-Ready Business Website
          </h1>
          <p className="text-xs sm:text-sm text-neutral-400 mt-1">
            Fill in structured business information to compile an authentic, conversion-focused website.
          </p>
        </div>

        {/* Mode Switcher: [ AI PROMPT MODE ] [ GUIDED MODE ] */}
        <div className="flex items-center p-1 rounded-xl bg-neutral-900 border border-neutral-800 self-start sm:self-center shadow-lg">
          <button
            type="button"
            onClick={() => setBuilderMode('ai_prompt')}
            className="px-4 py-2 rounded-lg text-xs font-medium text-neutral-400 hover:text-white transition-all flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI PROMPT MODE</span>
          </button>
          <button
            type="button"
            className="px-4 py-2 rounded-lg text-xs font-bold transition-all bg-gradient-to-r from-amber-500 to-amber-600 text-neutral-950 shadow-md shadow-amber-500/20 flex items-center gap-1.5"
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>GUIDED MODE</span>
          </button>
        </div>
      </div>

      {/* Step Indicators */}
      <div className="grid grid-cols-5 gap-2 mb-8">
        {[
          { num: 1, label: 'Business Info', icon: Building2 },
          { num: 2, label: 'Brand & Style', icon: Palette },
          { num: 3, label: 'Type', icon: Layers },
          { num: 4, label: 'Pages', icon: FileText },
          { num: 5, label: 'Generate', icon: Sparkles },
        ].map((item) => {
          const Icon = item.icon;
          const isCurrent = step === item.num;
          const isDone = step > item.num;
          return (
            <button
              key={item.num}
              onClick={() => step > item.num && setStep(item.num)}
              className={`p-3 rounded-lg text-left transition-all border flex flex-col justify-between ${
                isCurrent
                  ? 'bg-neutral-900 border-amber-500 shadow-sm shadow-amber-500/10'
                  : isDone
                  ? 'bg-neutral-950 border-neutral-800 text-neutral-300 hover:border-neutral-700'
                  : 'bg-neutral-950/40 border-neutral-900 text-neutral-600 cursor-not-allowed'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <Icon className={`w-4 h-4 ${isCurrent ? 'text-amber-400' : isDone ? 'text-emerald-400' : 'text-neutral-600'}`} />
                {isDone && <Check className="w-3.5 h-3.5 text-emerald-400" />}
              </div>
              <div className="text-[11px] font-semibold truncate">{item.label}</div>
            </button>
          );
        })}
      </div>

      {/* STEP CONTENT CONTAINER */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-6 sm:p-8 mb-8 shadow-xl">
        
        {/* STEP 1: BUSINESS INFORMATION */}
        {step === 1 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-bold text-white mb-1">Step 1 — Business Information</h2>
              <p className="text-xs text-neutral-400">
                Provide real business details. We never invent fake reviews, revenue, or certifications.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs uppercase tracking-wider text-neutral-300 font-semibold mb-1">
                  Business Name *
                </label>
                <input
                  type="text"
                  required
                  value={business.name}
                  onChange={(e) => setBusiness({ ...business, name: e.target.value })}
                  placeholder="e.g. Apex Physical Therapy & Performance"
                  className="w-full px-3.5 py-2.5 rounded-lg bg-neutral-950 border border-neutral-800 text-neutral-100 placeholder-neutral-600 focus:outline-none focus:border-amber-500 text-sm"
                />
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-neutral-300 font-semibold mb-1">
                  Industry / Category *
                </label>
                <input
                  type="text"
                  required
                  value={business.industry}
                  onChange={(e) => setBusiness({ ...business, industry: e.target.value })}
                  placeholder="e.g. Sports Physical Therapy & Rehabilitation"
                  className="w-full px-3.5 py-2.5 rounded-lg bg-neutral-950 border border-neutral-800 text-neutral-100 placeholder-neutral-600 focus:outline-none focus:border-amber-500 text-sm"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs uppercase tracking-wider text-neutral-300 font-semibold mb-1">
                Business Description & Value Proposition *
              </label>
              <textarea
                rows={3}
                required
                value={business.description}
                onChange={(e) => setBusiness({ ...business, description: e.target.value })}
                placeholder="What does the business do, what problems does it solve, and what sets it apart?"
                className="w-full px-3.5 py-2.5 rounded-lg bg-neutral-950 border border-neutral-800 text-neutral-100 placeholder-neutral-600 focus:outline-none focus:border-amber-500 text-sm"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs uppercase tracking-wider text-neutral-300 font-semibold mb-1">
                  Location / Address
                </label>
                <input
                  type="text"
                  value={business.location}
                  onChange={(e) => setBusiness({ ...business, location: e.target.value })}
                  placeholder="e.g. Austin, TX or 401 Congress Ave"
                  className="w-full px-3.5 py-2.5 rounded-lg bg-neutral-950 border border-neutral-800 text-neutral-100 placeholder-neutral-600 focus:outline-none focus:border-amber-500 text-sm"
                />
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-neutral-300 font-semibold mb-1">
                  Phone (Click-to-call)
                </label>
                <input
                  type="tel"
                  value={business.phone}
                  onChange={(e) => setBusiness({ ...business, phone: e.target.value })}
                  placeholder="+1 (512) 555-0199"
                  className="w-full px-3.5 py-2.5 rounded-lg bg-neutral-950 border border-neutral-800 text-neutral-100 placeholder-neutral-600 focus:outline-none focus:border-amber-500 text-sm"
                />
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-neutral-300 font-semibold mb-1">
                  WhatsApp Number
                </label>
                <input
                  type="tel"
                  value={business.whatsapp}
                  onChange={(e) => setBusiness({ ...business, whatsapp: e.target.value })}
                  placeholder="+15125550199"
                  className="w-full px-3.5 py-2.5 rounded-lg bg-neutral-950 border border-neutral-800 text-neutral-100 placeholder-neutral-600 focus:outline-none focus:border-amber-500 text-sm"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs uppercase tracking-wider text-neutral-300 font-semibold mb-1">
                  Contact Email
                </label>
                <input
                  type="email"
                  value={business.email}
                  onChange={(e) => setBusiness({ ...business, email: e.target.value })}
                  placeholder="hello@apexphysical.com"
                  className="w-full px-3.5 py-2.5 rounded-lg bg-neutral-950 border border-neutral-800 text-neutral-100 placeholder-neutral-600 focus:outline-none focus:border-amber-500 text-sm"
                />
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-neutral-300 font-semibold mb-1">
                  Target Customers
                </label>
                <input
                  type="text"
                  value={business.targetAudience}
                  onChange={(e) => setBusiness({ ...business, targetAudience: e.target.value })}
                  placeholder="e.g. Endurance athletes, executives recovering from injury"
                  className="w-full px-3.5 py-2.5 rounded-lg bg-neutral-950 border border-neutral-800 text-neutral-100 placeholder-neutral-600 focus:outline-none focus:border-amber-500 text-sm"
                />
              </div>
            </div>

            {/* Primary Conversion Goal */}
            <div>
              <label className="block text-xs uppercase tracking-wider text-neutral-300 font-semibold mb-2">
                Primary Conversion Goal *
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {PRIMARY_GOALS.map((goal) => (
                  <button
                    key={goal}
                    type="button"
                    onClick={() => setBusiness({ ...business, primaryGoal: goal })}
                    className={`px-3 py-2 text-xs rounded-lg border text-left transition-all ${
                      business.primaryGoal === goal
                        ? 'bg-amber-500/10 border-amber-500 text-amber-400 font-semibold'
                        : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:text-neutral-200'
                    }`}
                  >
                    {goal}
                  </button>
                ))}
              </div>
            </div>

            {/* Services List */}
            <div>
              <label className="block text-xs uppercase tracking-wider text-neutral-300 font-semibold mb-1">
                Core Services & Offerings
              </label>
              <div className="flex gap-2 mb-3">
                <input
                  type="text"
                  value={newServiceInput}
                  onChange={(e) => setNewServiceInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addService())}
                  placeholder="Add a service (e.g. Post-Surgical Knee Rehab)..."
                  className="flex-1 px-3.5 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-neutral-100 placeholder-neutral-600 focus:outline-none focus:border-amber-500 text-xs"
                />
                <button
                  type="button"
                  onClick={addService}
                  className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold rounded-lg flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" /> Add
                </button>
              </div>
              <div className="flex flex-wrap gap-2">
                {business.services.map((srv, idx) => (
                  <span
                    key={idx}
                    className="inline-flex items-center gap-1.5 px-3 py-1 rounded bg-neutral-950 border border-neutral-800 text-xs text-neutral-200"
                  >
                    <span>{srv}</span>
                    <button
                      type="button"
                      onClick={() => removeService(idx)}
                      className="text-neutral-500 hover:text-rose-400"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </span>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* STEP 2: BRAND */}
        {step === 2 && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-bold text-white mb-1">Step 2 — Client Brand & Visual System</h2>
                <p className="text-xs text-neutral-400">
                  Configure brand identity. The client website will NEVER use Money Making Empire branding.
                </p>
              </div>
              <button
                type="button"
                onClick={handleAutoDesignDirection}
                className="px-3 py-1.5 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-400 text-xs font-semibold rounded-md flex items-center gap-1.5 transition-all"
              >
                <Wand2 className="w-3.5 h-3.5" /> Auto AI Color & Typography
              </button>
            </div>

            {/* Brand Style selection */}
            <div>
              <label className="block text-xs uppercase tracking-wider text-neutral-300 font-semibold mb-2">
                Brand Aesthetic Style *
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                {BRAND_STYLES.map((style) => (
                  <button
                    key={style}
                    type="button"
                    onClick={() => {
                      setBrand({ ...brand, style });
                      const rec = aiProvider.improveDesign(style, business.industry);
                      setBrand((prev) => ({ ...prev, ...rec, style }));
                    }}
                    className={`p-3 text-xs rounded-lg border text-center transition-all ${
                      brand.style === style
                        ? 'bg-amber-500/10 border-amber-500 text-amber-400 font-bold'
                        : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:text-neutral-200'
                    }`}
                  >
                    {style}
                  </button>
                ))}
              </div>
            </div>

            {/* Color Pickers */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs uppercase tracking-wider text-neutral-300 font-semibold mb-1">
                  Primary Brand Color
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={brand.primaryColor}
                    onChange={(e) => setBrand({ ...brand, primaryColor: e.target.value })}
                    className="w-10 h-10 rounded border border-neutral-700 bg-neutral-950 cursor-pointer"
                  />
                  <input
                    type="text"
                    value={brand.primaryColor}
                    onChange={(e) => setBrand({ ...brand, primaryColor: e.target.value })}
                    className="flex-1 px-3 py-2 rounded bg-neutral-950 border border-neutral-800 text-neutral-100 font-mono text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-neutral-300 font-semibold mb-1">
                  Secondary Color
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={brand.secondaryColor}
                    onChange={(e) => setBrand({ ...brand, secondaryColor: e.target.value })}
                    className="w-10 h-10 rounded border border-neutral-700 bg-neutral-950 cursor-pointer"
                  />
                  <input
                    type="text"
                    value={brand.secondaryColor}
                    onChange={(e) => setBrand({ ...brand, secondaryColor: e.target.value })}
                    className="flex-1 px-3 py-2 rounded bg-neutral-950 border border-neutral-800 text-neutral-100 font-mono text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-neutral-300 font-semibold mb-1">
                  Accent Color
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={brand.accentColor}
                    onChange={(e) => setBrand({ ...brand, accentColor: e.target.value })}
                    className="w-10 h-10 rounded border border-neutral-700 bg-neutral-950 cursor-pointer"
                  />
                  <input
                    type="text"
                    value={brand.accentColor}
                    onChange={(e) => setBrand({ ...brand, accentColor: e.target.value })}
                    className="flex-1 px-3 py-2 rounded bg-neutral-950 border border-neutral-800 text-neutral-100 font-mono text-xs"
                  />
                </div>
              </div>
            </div>

            {/* Typography Pairing */}
            <div>
              <label className="block text-xs uppercase tracking-wider text-neutral-300 font-semibold mb-2">
                Font Pairing Direction
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                {[
                  { id: 'modern', name: 'Plus Jakarta Sans', sample: 'Modern & High Tech' },
                  { id: 'luxury', name: 'Cinzel Serif', sample: 'Luxury & Haute Horlogerie' },
                  { id: 'editorial', name: 'Playfair Display', sample: 'Editorial & Literary' },
                  { id: 'clean', name: 'Inter Clean', sample: 'Neutral & Clean Enterprise' },
                  { id: 'technical', name: 'JetBrains Mono', sample: 'Developer & Data' },
                ].map((f) => (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => setBrand({ ...brand, fontPairing: f.id as any })}
                    className={`p-3 text-left rounded-lg border transition-all ${
                      brand.fontPairing === f.id
                        ? 'bg-amber-500/10 border-amber-500 text-amber-400'
                        : 'bg-neutral-950 border-neutral-800 text-neutral-400'
                    }`}
                  >
                    <div className="text-xs font-bold text-white truncate">{f.name}</div>
                    <div className="text-[10px] text-neutral-500 truncate">{f.sample}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Image Production Strategy */}
            <div className="pt-2 border-t border-neutral-800">
              <label className="block text-xs uppercase tracking-wider text-neutral-300 font-semibold mb-2">
                Image Production & Placement Strategy *
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {[
                  {
                    id: 'niche_verified',
                    title: 'Curated Niche Photography',
                    desc: 'High-res architectural & facility photography accurately matched to your industry with verified commercial royalty-free license.',
                    badge: 'Recommended for Demos',
                  },
                  {
                    id: 'honest_placeholders',
                    title: 'Honest Business Placeholders',
                    desc: 'Polished "Add your business image" placeholders with dimension callouts. Never invents fake staff or credentials.',
                    badge: 'Strict Client Staging',
                  },
                  {
                    id: 'ai_generate',
                    title: 'AI Contextual Imagery',
                    desc: 'Generates custom visual scenes matching brand style and color palette without fake customer photos.',
                    badge: 'Experimental AI',
                  },
                ].map((strat) => (
                  <button
                    key={strat.id}
                    type="button"
                    onClick={() => setImageStrategy(strat.id as any)}
                    className={`p-3.5 rounded-lg border text-left transition-all flex flex-col justify-between ${
                      imageStrategy === strat.id
                        ? 'bg-amber-500/10 border-amber-500 text-amber-400 font-semibold shadow-sm'
                        : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:text-neutral-200'
                    }`}
                  >
                    <div>
                      <div className="text-xs font-bold text-white mb-1">{strat.title}</div>
                      <div className="text-[11px] text-neutral-400 leading-relaxed mb-3">{strat.desc}</div>
                    </div>
                    <span className="text-[9px] font-mono uppercase px-2 py-0.5 rounded bg-neutral-900 border border-neutral-800 text-amber-400/90 self-start">
                      {strat.badge}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Corner Radius & Mode */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs uppercase tracking-wider text-neutral-300 font-semibold mb-1">
                  Card & Button Geometry
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'none', label: 'Square (0px)' },
                    { id: 'subtle', label: 'Subtle (8px)' },
                    { id: 'rounded', label: 'Pill (16px+)' },
                  ].map((rad) => (
                    <button
                      key={rad.id}
                      type="button"
                      onClick={() => setBrand({ ...brand, borderRadius: rad.id as any })}
                      className={`py-2 text-xs rounded border text-center ${
                        brand.borderRadius === rad.id
                          ? 'border-amber-500 text-amber-400 bg-amber-500/10'
                          : 'border-neutral-800 text-neutral-400 bg-neutral-950'
                      }`}
                    >
                      {rad.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-neutral-300 font-semibold mb-1">
                  Website Light / Dark Scheme
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setBrand({ ...brand, lightMode: true })}
                    className={`py-2 text-xs rounded border text-center ${
                      brand.lightMode
                        ? 'border-amber-500 text-amber-400 bg-amber-500/10 font-semibold'
                        : 'border-neutral-800 text-neutral-400 bg-neutral-950'
                    }`}
                  >
                    Clean Light Canvas
                  </button>
                  <button
                    type="button"
                    onClick={() => setBrand({ ...brand, lightMode: false })}
                    className={`py-2 text-xs rounded border text-center ${
                      !brand.lightMode
                        ? 'border-amber-500 text-amber-400 bg-amber-500/10 font-semibold'
                        : 'border-neutral-800 text-neutral-400 bg-neutral-950'
                    }`}
                  >
                    Dark Luxury Canvas
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* STEP 3: WEBSITE TYPE */}
        {step === 3 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-bold text-white mb-1">Step 3 — Website Archetype</h2>
              <p className="text-xs text-neutral-400">
                Select the structural archetype to configure layout conventions and section priority.
              </p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
              {WEBSITE_TYPES.map((type) => (
                <button
                  key={type}
                  type="button"
                  onClick={() => setSelectedType(type)}
                  className={`p-3.5 text-xs rounded-xl border text-left transition-all ${
                    selectedType === type
                      ? 'bg-amber-500/10 border-amber-500 text-amber-400 font-bold shadow-md shadow-amber-500/10'
                      : 'bg-neutral-950 border-neutral-800 text-neutral-300 hover:border-neutral-700'
                  }`}
                >
                  <div className="font-semibold">{type}</div>
                  <div className="text-[10px] text-neutral-500 mt-1">Specialized conversion flow</div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* STEP 4: PAGES */}
        {step === 4 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-bold text-white mb-1">Step 4 — Information Architecture & Pages</h2>
              <p className="text-xs text-neutral-400">
                Select the pages to scaffold. We do not generate unnecessary bloat pages automatically.
              </p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {DEFAULT_PAGES_OPTIONS.map((page) => {
                const isSelected = selectedPages.includes(page);
                const isHome = page === 'Home';
                return (
                  <button
                    key={page}
                    type="button"
                    disabled={isHome}
                    onClick={() => togglePage(page)}
                    className={`p-3 rounded-lg border text-left flex items-center justify-between text-xs transition-all ${
                      isSelected
                        ? 'bg-amber-500/10 border-amber-500 text-amber-400 font-semibold'
                        : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:text-neutral-200'
                    } ${isHome ? 'opacity-80 cursor-not-allowed' : ''}`}
                  >
                    <span>{page} {isHome && '(Required)'}</span>
                    {isSelected && <Check className="w-3.5 h-3.5" />}
                  </button>
                );
              })}
            </div>

            {/* Custom page input */}
            <div className="pt-4 border-t border-neutral-800">
              <label className="block text-xs uppercase tracking-wider text-neutral-300 font-semibold mb-2">
                Add Custom Page
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={customPageInput}
                  onChange={(e) => setCustomPageInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addCustomPage())}
                  placeholder="e.g. Technology Stack or Smile Gallery..."
                  className="flex-1 px-3.5 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-neutral-100 placeholder-neutral-600 focus:outline-none focus:border-amber-500 text-xs"
                />
                <button
                  type="button"
                  onClick={addCustomPage}
                  className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-semibold rounded-lg flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" /> Add Page
                </button>
              </div>
            </div>
          </div>
        )}

        {/* STEP 5: PRE-COMPILATION REVIEW */}
        {step === 5 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-bold text-white mb-1">Step 5 — Content Engine & Compilation</h2>
              <p className="text-xs text-neutral-400">
                Ready to generate your custom client website using {aiStatus.configured ? 'Google Gemini 3.8 Flash' : 'High-Precision Deterministic Engine'}.
              </p>
            </div>

            {generationError && (
              <div className="p-4 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                <span>{generationError}</span>
              </div>
            )}

            {/* Summary specifications table */}
            <div className="bg-neutral-950 rounded-lg p-5 border border-neutral-800 space-y-3 text-xs">
              <div className="flex justify-between border-b border-neutral-800/60 pb-2">
                <span className="text-neutral-500">Business Target:</span>
                <span className="text-white font-semibold">{business.name || 'Untitled Client'} ({business.industry})</span>
              </div>
              <div className="flex justify-between border-b border-neutral-800/60 pb-2">
                <span className="text-neutral-500">Archetype:</span>
                <span className="text-white font-medium">{selectedType} · {brand.style} style</span>
              </div>
              <div className="flex justify-between border-b border-neutral-800/60 pb-2">
                <span className="text-neutral-500">Conversion Objective:</span>
                <span className="text-amber-400 font-semibold">{business.primaryGoal}</span>
              </div>
              <div className="flex justify-between border-b border-neutral-800/60 pb-2">
                <span className="text-neutral-500">Direct Channels:</span>
                <span className="text-neutral-300">
                  {business.phone ? `Phone: ${business.phone}` : ''} {business.whatsapp ? `· WhatsApp: ${business.whatsapp}` : ''}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-500">Included Pages:</span>
                <span className="text-neutral-300">{selectedPages.join(', ')}</span>
              </div>
            </div>

            <div className="p-4 rounded-lg bg-amber-500/5 border border-amber-500/20 text-xs text-neutral-300 space-y-1">
              <div className="font-semibold text-amber-400 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" /> Client Standards Enforcement Active
              </div>
              <p className="text-[11px] text-neutral-400">
                - No fabricated metrics, fake customer counts, or fictitious awards.<br />
                - Live phone and WhatsApp CTA handlers pre-wired to client numbers.<br />
                - Client-ready responsive preview and exportable package generated on completion.
              </p>
            </div>
          </div>
        )}

      </div>

      {/* Wizard Footer Controls */}
      <div className="flex items-center justify-between">
        {step > 1 ? (
          <button
            type="button"
            onClick={() => setStep(step - 1)}
            disabled={isGenerating}
            className="px-4 py-2.5 rounded-lg border border-neutral-800 text-neutral-300 hover:bg-neutral-900 text-xs font-semibold flex items-center gap-2 transition-all"
          >
            <ArrowLeft className="w-3.5 h-3.5" /> Previous Step
          </button>
        ) : (
          <button
            type="button"
            onClick={() => setActiveView('dashboard')}
            className="px-4 py-2.5 rounded-lg border border-neutral-800 text-neutral-400 hover:bg-neutral-900 text-xs font-semibold"
          >
            Cancel
          </button>
        )}

        {step < 5 ? (
          <button
            type="button"
            onClick={() => {
              if (step === 1 && !business.name.trim()) {
                alert('Please enter a Business Name before proceeding.');
                return;
              }
              setStep(step + 1);
            }}
            className="px-5 py-2.5 rounded-lg bg-neutral-100 hover:bg-white text-neutral-950 text-xs font-bold flex items-center gap-2 transition-all shadow-sm active:scale-95"
          >
            <span>Continue</span> <ArrowRight className="w-3.5 h-3.5" />
          </button>
        ) : (
          <button
            type="button"
            disabled={isGenerating}
            onClick={handleGenerateWebsite}
            className="px-6 py-3 rounded-lg bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-neutral-950 text-xs sm:text-sm font-extrabold flex items-center gap-2 shadow-lg shadow-amber-500/25 transition-all transform active:scale-95 disabled:opacity-50"
          >
            {isGenerating ? (
              <>
                <div className="w-4 h-4 border-2 border-neutral-950 border-t-transparent rounded-full animate-spin" />
                <span>Compiling Client Website...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Generate Client Website</span>
              </>
            )}
          </button>
        )}
      </div>
    </div>
  );
};
