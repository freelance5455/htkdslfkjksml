import React, { useState, useEffect, useRef } from 'react';
import { useProjects } from '../../context/ProjectContext';
import { 
  WebsiteProject, 
  WebsiteSection, 
  BrandStyle, 
  WebsiteType, 
  PrimaryGoal, 
  AIPromptHistoryItem,
  ProjectVersion 
} from '../../types/website';
import { aiProvider } from '../../services/aiProvider';
import { runQualityAudit } from '../../services/qualityChecker';
import { extractClientContextFromPrompt, enforceClientIdentity } from '../../utils/promptExtractor';
import { createDefaultPagesForBusiness } from '../../utils/multiPageBuilder';
import { 
  Sparkles, 
  Wand2, 
  ArrowRight, 
  X, 
  RotateCcw, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  ChevronDown, 
  ChevronUp, 
  Building2, 
  Phone, 
  Mail, 
  MessageSquare, 
  Globe, 
  MapPin, 
  Sliders, 
  ShieldCheck,
  StopCircle,
  HelpCircle,
  Flame,
  Layers,
  Crown
} from 'lucide-react';

interface QuickPreset {
  id: string;
  name: string;
  badge: string;
  icon: string;
  prompt: string;
}

const QUICK_PRESETS: QuickPreset[] = [
  {
    id: 'luxury',
    name: 'Luxury Business',
    badge: 'High-Ticket',
    icon: '👑',
    prompt: 'Build a prestigious website for a private wealth advisory and family office in London. Use an opulent dark navy and champagne gold aesthetic, bespoke client services, transparent investment philosophies, partner credentials, private consultation booking, direct WhatsApp concierge, and a 24/7 AI customer concierge.',
  },
  {
    id: 'dental',
    name: 'Dental Clinic',
    badge: 'Healthcare',
    icon: '✨',
    prompt: 'Build a premium website for a luxury dental clinic in Dubai. Use a sophisticated dark blue and gold visual style, cinematic animations, service sections, testimonials, appointment booking, WhatsApp contact, and a 24/7 AI chatbot.',
  },
  {
    id: 'restaurant',
    name: 'Restaurant',
    badge: 'Hospitality',
    icon: '🍷',
    prompt: 'Build an atmospheric website for an upscale fine dining restaurant and sommelier lounge. Use a moody dark slate and warm amber visual style, chef’s seasonal tasting menu, private dining reservations, interactive table booking, direct WhatsApp line, and a 24/7 AI dining assistant.',
  },
  {
    id: 'law',
    name: 'Law Firm',
    badge: 'Legal',
    icon: '⚖️',
    prompt: 'Build an authoritative corporate website for a high-stakes commercial litigation and advisory law firm. Use a deep midnight navy and platinum aesthetic, practice area matrices, partner credentials, confidential intake forms, direct call button, and an intelligent 24/7 AI legal inquiry assistant.',
  },
  {
    id: 'realestate',
    name: 'Real Estate',
    badge: 'Property',
    icon: '🏛️',
    prompt: 'Build a high-end luxury real estate agency website. Use an architectural clean stone and bronze design, private estate portfolios, interactive property viewing requests, direct broker WhatsApp contact, and a 24/7 AI property concierge.',
  },
  {
    id: 'gym',
    name: 'Gym & Fitness',
    badge: 'Wellness',
    icon: '⚡',
    prompt: 'Build a bold, modern website for a boutique athletic performance and movement club. Use a high-contrast dark charcoal and electric cyan palette, personal coaching tiers, facility showcases, trial session bookings, WhatsApp line, and a 24/7 AI fitness assistant.',
  },
  {
    id: 'agency',
    name: 'Agency',
    badge: 'Creative',
    icon: '🚀',
    prompt: 'Build a cutting-edge website for a boutique digital design and growth agency. Use a minimalist obsidian and copper aesthetic, case study showcases, transparent scope packages, discovery call scheduling, and an interactive 24/7 AI intake assistant.',
  },
  {
    id: 'portfolio',
    name: 'Portfolio',
    badge: 'Design',
    icon: '🎨',
    prompt: 'Build an editorial portfolio website for an architectural and industrial designer. Use a clean Swiss grid with generous whitespace, curated project case studies, client accolades, and a direct inquiry contact form.',
  },
  {
    id: 'local',
    name: 'Local Service',
    badge: 'Contractor',
    icon: '🔨',
    prompt: 'Build a high-converting website for an architectural roofing and contractor company. Use an authoritative navy and safety orange palette, transparent 3-step project estimates, warranty guarantees, emergency click-to-call dispatch, and a 24/7 AI quote assistant.',
  },
  {
    id: 'ecommerce',
    name: 'E-commerce',
    badge: 'Boutique',
    icon: '🛍️',
    prompt: 'Build a sophisticated storefront website for an artisanal luxury leather goods atelier. Use an elegant dark espresso and cream palette, product collections, craftsmanship storytelling, direct ordering, and a 24/7 customer service AI assistant.',
  },
];

const PROMPT_HISTORY_STORAGE_KEY = 'mme_ai_prompt_history_v2';

interface AIPromptBuilderProps {
  onSwitchToGuided: () => void;
}

export const AIPromptBuilder: React.FC<AIPromptBuilderProps> = ({ onSwitchToGuided }) => {
  const { createProject, aiStatus } = useProjects();

  const [prompt, setPrompt] = useState<string>('');
  const [isEnhancing, setIsEnhancing] = useState<boolean>(false);
  const [enhancedResult, setEnhancedResult] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [generationStep, setGenerationStep] = useState<number>(0);
  const [generationError, setGenerationError] = useState<string | null>(null);
  const [showClientFields, setShowClientFields] = useState<boolean>(false);

  // Optional Client Information
  const [clientInfo, setClientInfo] = useState({
    clientName: '',
    businessName: '',
    industry: '',
    location: '',
    phone: '',
    email: '',
    whatsapp: '',
    websiteUrl: '',
    brandStyle: '' as BrandStyle | '',
    primaryGoal: '' as PrimaryGoal | '',
  });

  // Prompt History
  const [promptHistory, setPromptHistory] = useState<AIPromptHistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem(PROMPT_HISTORY_STORAGE_KEY);
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return [];
  });

  const abortControllerRef = useRef<AbortController | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(PROMPT_HISTORY_STORAGE_KEY, JSON.stringify(promptHistory.slice(0, 15)));
    } catch (e) {}
  }, [promptHistory]);

  const handleEnhancePrompt = async () => {
    if (!prompt.trim()) return;
    setIsEnhancing(true);
    setGenerationError(null);
    try {
      const enhanced = await aiProvider.enhancePrompt(prompt);
      setEnhancedResult(enhanced);
    } catch (err: any) {
      setGenerationError(err.message || 'Failed to enhance prompt');
    } finally {
      setIsEnhancing(false);
    }
  };

  const handleApplyEnhancedPrompt = () => {
    if (enhancedResult) {
      setPrompt(enhancedResult);
      setEnhancedResult(null);
    }
  };

  const handleSelectPreset = (presetPrompt: string) => {
    setPrompt(presetPrompt);
    setEnhancedResult(null);
    window.scrollTo({ top: 120, behavior: 'smooth' });
  };

  const handleClearPrompt = () => {
    setPrompt('');
    setEnhancedResult(null);
  };

  const handleStopGeneration = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setIsGenerating(false);
    setGenerationStep(0);
    setGenerationError('Generation was stopped by user.');
  };

  // Live progress stages
  const STAGES = [
    { title: 'Understanding request...', done: 'Business requirements identified' },
    { title: 'Planning website...', done: 'Site architecture & pages structured' },
    { title: 'Designing visual system...', done: 'Typography, palette & geometry determined' },
    { title: 'Building sections...', done: 'Custom copy & conversion layouts crafted' },
    { title: 'Adding responsive layout...', done: 'Mobile-first optimization verified' },
    { title: 'Configuring features...', done: 'CTA channels & 24/7 Chatbot pre-wired' },
    { title: 'Final quality check...', done: 'Full audit checklist calculated' },
  ];

  const handleBuildWebsite = async () => {
    if (!prompt.trim()) {
      setGenerationError('Please enter a description of the website you wish to build.');
      return;
    }

    setIsGenerating(true);
    setGenerationError(null);
    setGenerationStep(0);

    const controller = new AbortController();
    abortControllerRef.current = controller;

    // Realistic step progression interval
    const stepInterval = setInterval(() => {
      setGenerationStep((prev) => {
        if (prev < STAGES.length - 1) return prev + 1;
        return prev;
      });
    }, 450);

    try {
      // 1. Extract fresh client context from current prompt as source of truth
      const clientContext = extractClientContextFromPrompt(prompt, clientInfo);

      const aiData = await aiProvider.generateFromPrompt(prompt, {
        ...clientInfo,
        businessName: clientContext.hasCustomName ? clientContext.businessName : (clientInfo.businessName || ''),
        industry: clientContext.industry || clientInfo.industry,
        location: clientContext.location || clientInfo.location,
      });

      clearInterval(stepInterval);
      setGenerationStep(STAGES.length);

      const effectiveBizName = clientContext.hasCustomName ? clientContext.businessName : (aiData.business?.name || '[Business Name]');

      // Save to prompt history
      const newHistoryItem: AIPromptHistoryItem = {
        id: `ph-${Date.now()}`,
        prompt: prompt.trim(),
        timestamp: new Date().toISOString(),
        businessName: effectiveBizName,
        industry: aiData.business?.industry || clientContext.industry || clientInfo.industry,
      };
      setPromptHistory((prev) => [newHistoryItem, ...prev.filter((p) => p.prompt !== prompt.trim())].slice(0, 15));

      // Resolve Niche Imagery for generated sections
      const sections: WebsiteSection[] = [];
      let order = 1;

      // Niche imagery pool
      const keyword = (aiData.business?.industry || prompt || '').toLowerCase();
      let heroImgUrl = 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1600&q=80';
      let heroAlt = `${aiData.business?.name || 'Business'} architectural workspace`;

      if (keyword.includes('dent') || keyword.includes('smile')) {
        heroImgUrl = 'https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&w=1600&q=80';
        heroAlt = 'Boutique cosmetic dental operatory suite with panoramic city view';
      } else if (keyword.includes('restaur') || keyword.includes('food') || keyword.includes('dining')) {
        heroImgUrl = 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1600&q=80';
        heroAlt = 'Architectural dining room with oak tables and ambient warm lighting';
      } else if (keyword.includes('roof') || keyword.includes('contract')) {
        heroImgUrl = 'https://images.unsplash.com/photo-1632759145351-1d592919f522?auto=format&fit=crop&w=1600&q=80';
        heroAlt = 'High-definition architectural shingle roof on modern residential home';
      } else if (keyword.includes('law') || keyword.includes('legal')) {
        heroImgUrl = 'https://images.unsplash.com/photo-1497215728101-856f4ea42174?auto=format&fit=crop&w=1600&q=80';
        heroAlt = 'Executive law firm boardroom with panoramic glass windows';
      } else if (keyword.includes('real estate') || keyword.includes('villa') || keyword.includes('property')) {
        heroImgUrl = 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1600&q=80';
        heroAlt = 'Contemporary luxury architectural villa with infinity pool and glass facade';
      } else if (keyword.includes('fit') || keyword.includes('gym')) {
        heroImgUrl = 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=1600&q=80';
        heroAlt = 'High-end boutique fitness training sanctuary';
      }

      // Convert generated sections into verified WebsiteSection format
      if (Array.isArray(aiData.sections) && aiData.sections.length > 0) {
        aiData.sections.forEach((sec: any, idx: number) => {
          const secType = sec.type || 'hero';
          sections.push({
            id: `sec-${secType}-${Date.now()}-${idx}`,
            type: secType,
            title: sec.title || 'Excellence in Service',
            subtitle: sec.subtitle || '',
            kicker: sec.kicker || undefined,
            layoutVariant: sec.layoutVariant || (secType === 'hero' ? 'split-right' : 'grid-3'),
            imageUrl: secType === 'hero' ? heroImgUrl : sec.imageUrl || undefined,
            imageAlt: secType === 'hero' ? heroAlt : sec.imageAlt || undefined,
            imageOrigin: 'stock_licensed',
            imageAspectRatio: secType === 'hero' ? '16:9' : '4:3',
            imageFocalPoint: 'center',
            isImagePlaceholder: false,
            ctaPrimary: sec.ctaPrimary || (secType === 'hero' ? {
              label: 'Book Consultation',
              link: '#contact',
              type: 'primary',
              icon: 'arrow',
            } : undefined),
            ctaSecondary: sec.ctaSecondary,
            items: Array.isArray(sec.items) ? sec.items.map((it: any, iIdx: number) => ({
              id: `it-${iIdx}-${Date.now()}`,
              title: it.title || `Item 0${iIdx + 1}`,
              description: it.description || '',
              badge: it.badge,
              price: it.price,
              features: it.features,
            })) : undefined,
            isVisible: true,
            order: order++,
          });
        });
      } else {
        // Fallback default hero if AI sections array was empty
        sections.push({
          id: `sec-hero-${Date.now()}`,
          type: 'hero',
          title: `Unrivaled ${aiData.business?.industry || 'Excellence'}. Crafted Without Compromise.`,
          subtitle: `Providing high-touch, transparent service with measurable, enduring outcomes in ${aiData.business?.location || 'our market'}.`,
          kicker: 'PREMIER QUALITY',
          layoutVariant: 'split-right',
          imageUrl: heroImgUrl,
          imageAlt: heroAlt,
          imageOrigin: 'stock_licensed',
          imageAspectRatio: '16:9',
          imageFocalPoint: 'center',
          isImagePlaceholder: false,
          ctaPrimary: {
            label: 'Book Consultation',
            link: '#contact',
            type: 'primary',
            icon: 'arrow',
          },
          isVisible: true,
          order: order++,
        });
      }

      const projectId = `prj-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
      const resolvedBizName = clientContext.hasCustomName ? clientContext.businessName : (aiData.business?.name || clientInfo.businessName || 'Premier Client Atelier');
      const resolvedIndustry = clientContext.industry || aiData.business?.industry || clientInfo.industry || 'Professional Services';
      const resolvedLocation = clientContext.location || aiData.business?.location || clientInfo.location || '';
      const resolvedServices = clientContext.services.length > 0 ? clientContext.services : (aiData.business?.services || ['Diagnostic Consultation', 'Turnkey Implementation', 'Dedicated Advisory']);
      const projectName = `${resolvedBizName} Website`;

      const initialProject: WebsiteProject = {
        id: projectId,
        name: projectName,
        clientName: clientInfo.clientName || resolvedBizName || 'Private Client',
        status: 'draft',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        business: {
          name: resolvedBizName,
          industry: resolvedIndustry,
          description: aiData.business?.description || `Bespoke ${resolvedIndustry.toLowerCase()} tailored to discerning clients${resolvedLocation ? ` in ${resolvedLocation}` : ''}.`,
          location: resolvedLocation,
          phone: clientContext.phone || clientInfo.phone || aiData.business?.phone || '',
          email: clientContext.email || clientInfo.email || aiData.business?.email || '',
          whatsapp: clientContext.hasWhatsApp ? (clientInfo.whatsapp || 'active') : '',
          websiteUrl: clientContext.websiteUrl || clientInfo.websiteUrl || aiData.business?.websiteUrl || '',
          socialUrls: {},
          businessHours: aiData.business?.businessHours || 'Mon - Fri: 9:00 AM - 6:00 PM',
          services: resolvedServices,
          products: [],
          targetAudience: aiData.business?.targetAudience || 'Discerning private and commercial clients',
          primaryGoal: clientContext.primaryGoal || aiData.business?.primaryGoal || 'Generate leads',
        },
        brand: {
          logoUrl: '',
          primaryColor: aiData.brand?.primaryColor || clientContext.primaryColor || '#0a192f',
          secondaryColor: aiData.brand?.secondaryColor || clientContext.secondaryColor || '#1e293b',
          accentColor: aiData.brand?.accentColor || clientContext.accentColor || '#c5a059',
          fontPairing: aiData.brand?.fontPairing || clientContext.fontPairing || 'luxury',
          style: aiData.brand?.style || clientContext.style || 'Luxury',
          borderRadius: aiData.brand?.borderRadius || 'subtle',
          lightMode: aiData.brand?.lightMode !== undefined ? aiData.brand.lightMode : clientContext.lightMode,
        },
        type: aiData.websiteType || clientContext.websiteType || 'Business Website',
        activePageId: 'page-home',
        deployment: {
          provider: 'manual',
          customDomain: clientContext.websiteUrl?.replace(/^https?:\/\//, '') || '',
          deploymentUrl: `https://${projectId.slice(0, 16)}.empire-preview.app`,
          verified: false,
          httpsActive: true,
          dnsStatus: 'not_configured',
          dnsRecords: [
            { type: 'A', name: '@', value: '76.76.21.21', ttl: '3600', status: 'pending' },
            { type: 'CNAME', name: 'www', value: 'cname.empire-network.net', ttl: '3600', status: 'pending' },
          ],
        },
        pages: createDefaultPagesForBusiness(
          {
            name: resolvedBizName,
            industry: resolvedIndustry,
            description: aiData.business?.description || `Bespoke ${resolvedIndustry.toLowerCase()} tailored to discerning clients${resolvedLocation ? ` in ${resolvedLocation}` : ''}.`,
            location: resolvedLocation,
            phone: clientContext.phone || clientInfo.phone || aiData.business?.phone || '',
            email: clientContext.email || clientInfo.email || aiData.business?.email || '',
            whatsapp: clientContext.hasWhatsApp ? (clientInfo.whatsapp || 'active') : '',
            websiteUrl: clientContext.websiteUrl || clientInfo.websiteUrl || aiData.business?.websiteUrl || '',
            socialUrls: {},
            businessHours: aiData.business?.businessHours || 'Mon - Fri: 9:00 AM - 6:00 PM',
            services: resolvedServices,
            products: [],
            targetAudience: aiData.business?.targetAudience || 'Discerning private and commercial clients',
            primaryGoal: clientContext.primaryGoal || aiData.business?.primaryGoal || 'Generate leads',
          },
          {
            logoUrl: '',
            primaryColor: aiData.brand?.primaryColor || clientContext.primaryColor || '#0a192f',
            secondaryColor: aiData.brand?.secondaryColor || clientContext.secondaryColor || '#1e293b',
            accentColor: aiData.brand?.accentColor || clientContext.accentColor || '#c5a059',
            fontPairing: aiData.brand?.fontPairing || clientContext.fontPairing || 'luxury',
            style: aiData.brand?.style || clientContext.style || 'Luxury',
            borderRadius: aiData.brand?.borderRadius || 'subtle',
            lightMode: aiData.brand?.lightMode !== undefined ? aiData.brand.lightMode : clientContext.lightMode,
          },
          sections
        ),
        chatbot: aiData.chatbotEnabled ? {
          enabled: true,
          businessName: aiData.business?.name || clientInfo.businessName || 'Our Business',
          businessDescription: aiData.business?.description || 'Premier services',
          tone: 'professional',
          welcomeMessage: `Welcome to ${aiData.business?.name || 'our business'}. How can we assist you with our services today?`,
          customGreeting: 'Ask our 24/7 assistant anything about our services, location, or consultation bookings.',
          color: aiData.brand?.primaryColor || '#0a192f',
          iconStyle: 'sparkles',
          position: 'bottom-right',
          suggestedQuestions: ['What services do you offer?', 'Where are you located?', 'How do I book a consultation?'],
          conversionButtons: { callNow: true, whatsapp: true, bookAppointment: true, requestQuote: true, contactUs: true, visitLocation: true },
        } : undefined,
      };

      // Create Version 1 snapshot
      const initialVersion: ProjectVersion = {
        id: `ver-1-${Date.now()}`,
        versionNumber: 1,
        timestamp: new Date().toISOString(),
        label: 'Version 1 - AI Prompt Creation',
        summary: `Initial website generated from prompt: "${prompt.slice(0, 80)}..."`,
        snapshot: JSON.parse(JSON.stringify(initialProject)),
      };

      initialProject.versionHistory = [initialVersion];
      initialProject.aiConversationHistory = [
        {
          id: `conv-${Date.now()}`,
          role: 'user',
          content: prompt,
          timestamp: new Date().toISOString(),
          actionApplied: 'Initial website build from AI prompt',
        },
        {
          id: `conv-resp-${Date.now()}`,
          role: 'assistant',
          content: `I've analyzed your requirements and generated a complete client-ready website for "${initialProject.business.name}". The website includes ${sections.length} tailored sections, a high-converting ${initialProject.brand.style} visual identity (${initialProject.brand.primaryColor} and ${initialProject.brand.accentColor}), responsive layout, ${initialProject.chatbot?.enabled ? '24/7 AI chatbot,' : ''} and optimized SEO metadata.`,
          timestamp: new Date().toISOString(),
        },
      ];

      // Enforce client context validation so client identity is strictly preserved
      const verifiedProject = enforceClientIdentity(initialProject, prompt, clientInfo);

      // Refresh snapshot and history with verified identity
      initialVersion.snapshot = JSON.parse(JSON.stringify(verifiedProject));
      verifiedProject.versionHistory = [initialVersion];
      if (verifiedProject.aiConversationHistory && verifiedProject.aiConversationHistory[1]) {
        verifiedProject.aiConversationHistory[1].content = `I've analyzed your requirements and generated a complete client-ready website for "${verifiedProject.business.name}". The website includes ${sections.length} tailored sections, a high-converting ${verifiedProject.brand.style} visual identity (${verifiedProject.brand.primaryColor} and ${verifiedProject.brand.accentColor}), responsive layout, ${verifiedProject.chatbot?.enabled ? '24/7 AI chatbot,' : ''} and optimized SEO metadata.`;
      }

      // Audit and create verified project
      createProject(verifiedProject);

      // Clean client fields state to guarantee subsequent generation starts fresh
      setClientInfo({
        clientName: '',
        businessName: '',
        industry: '',
        location: '',
        phone: '',
        email: '',
        whatsapp: '',
        websiteUrl: '',
        brandStyle: '',
        primaryGoal: '',
      });
    } catch (err: any) {
      clearInterval(stepInterval);
      console.error('AI Build error:', err);
      setGenerationError(err.message || 'AI generation failed. Please try again.');
      setIsGenerating(false);
      setGenerationStep(0);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* HEADER WITH DUAL MODE SWITCHER */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-mono uppercase tracking-wider text-amber-400 font-semibold flex items-center gap-1.5">
              <Crown className="w-3.5 h-3.5" /> Money Making Empire AI Studio
            </span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-amber-500/10 border border-amber-500/30 text-amber-300">
              {aiStatus.configured ? 'Gemini 3.8 Flash Online' : 'Engine Ready'}
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-neutral-100 tracking-tight">
            Build a Website With AI
          </h1>
          <p className="text-xs sm:text-sm text-neutral-400 mt-1 max-w-xl">
            Describe the website you want. The AI will turn your idea into a complete client-ready website.
          </p>
        </div>

        {/* MODE TOGGLE: [ AI PROMPT MODE ] [ GUIDED MODE ] */}
        <div className="flex items-center p-1 rounded-xl bg-neutral-900 border border-neutral-800 self-start sm:self-center shadow-lg">
          <button
            type="button"
            className="px-4 py-2 rounded-lg text-xs font-bold transition-all bg-gradient-to-r from-amber-500 to-amber-600 text-neutral-950 shadow-md shadow-amber-500/20 flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI PROMPT MODE</span>
          </button>
          <button
            type="button"
            onClick={onSwitchToGuided}
            className="px-4 py-2 rounded-lg text-xs font-medium text-neutral-400 hover:text-neutral-100 hover:bg-neutral-800/60 transition-all flex items-center gap-1.5"
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>GUIDED MODE</span>
          </button>
        </div>
      </div>

      {/* GENERATION IN PROGRESS MODAL / OVERLAY */}
      {isGenerating && (
        <div className="fixed inset-0 z-50 bg-neutral-950/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-neutral-900 border border-amber-500/40 rounded-2xl p-6 sm:p-8 max-w-lg w-full shadow-2xl space-y-6">
            <div className="text-center space-y-2">
              <div className="w-12 h-12 rounded-full bg-amber-500/10 border border-amber-500/30 flex items-center justify-center mx-auto text-amber-400 animate-pulse">
                <Sparkles className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-white">Assembling Your Client Website</h3>
              <p className="text-xs text-neutral-400">
                Transforming your prompt into a conversion-focused, production-grade website.
              </p>
            </div>

            {/* Stages Checklist */}
            <div className="space-y-2.5 bg-neutral-950/60 rounded-xl p-4 border border-neutral-800 text-xs">
              {STAGES.map((stg, idx) => {
                const isPassed = generationStep > idx;
                const isCurrent = generationStep === idx;
                return (
                  <div key={idx} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {isPassed ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                      ) : isCurrent ? (
                        <div className="w-4 h-4 border-2 border-amber-400 border-t-transparent rounded-full animate-spin flex-shrink-0" />
                      ) : (
                        <div className="w-4 h-4 rounded-full border border-neutral-700 flex-shrink-0" />
                      )}
                      <span className={isPassed ? 'text-neutral-300 font-medium' : isCurrent ? 'text-amber-400 font-bold' : 'text-neutral-500'}>
                        {stg.title}
                      </span>
                    </div>
                    {isPassed && (
                      <span className="text-[11px] font-mono text-emerald-400/90 truncate max-w-[180px]">
                        ✓ {stg.done}
                      </span>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Stop Generation Button */}
            <div className="flex justify-center pt-2">
              <button
                type="button"
                onClick={handleStopGeneration}
                className="px-4 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-semibold flex items-center gap-2 transition-all border border-neutral-700"
              >
                <StopCircle className="w-3.5 h-3.5 text-rose-400" />
                <span>Stop Generation</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MAIN AI PROMPT STUDIO CARD */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 sm:p-7 shadow-2xl relative space-y-6">
        
        {/* PROMPT BOX HEADER & ACTION CONTROLS */}
        <div className="flex items-center justify-between">
          <label htmlFor="ai-website-prompt" className="text-xs uppercase tracking-wider text-neutral-300 font-bold flex items-center gap-2">
            <span>Describe the website you want to build</span>
            <span className="text-[10px] font-normal text-neutral-500">(Be as specific or simple as you like)</span>
          </label>

          <div className="flex items-center gap-2">
            {prompt && (
              <button
                type="button"
                onClick={handleClearPrompt}
                className="text-xs text-neutral-500 hover:text-neutral-300 flex items-center gap-1 transition-colors px-2 py-1 rounded"
              >
                <X className="w-3.5 h-3.5" /> Clear
              </button>
            )}
            <span className="text-[11px] font-mono text-neutral-500">
              {prompt.length} chars
            </span>
          </div>
        </div>

        {/* LARGE MULTILINE PROMPT TEXTAREA */}
        <div className="relative">
          <textarea
            id="ai-website-prompt"
            rows={5}
            value={prompt}
            onChange={(e) => {
              setPrompt(e.target.value);
              setGenerationError(null);
            }}
            placeholder="Build a premium website for a luxury dental clinic in Dubai. Use a sophisticated dark blue and gold visual style, cinematic animations, service sections, testimonials, appointment booking, WhatsApp contact, and a 24/7 AI chatbot."
            className="w-full p-4 sm:p-5 rounded-xl bg-neutral-950 border border-neutral-800 text-neutral-100 placeholder-neutral-600 focus:outline-none focus:border-amber-500/80 focus:ring-1 focus:ring-amber-500/50 text-sm leading-relaxed transition-all resize-y min-h-[140px]"
          />

          {/* Enhance Prompt Button inside prompt box bottom-right */}
          <div className="absolute right-3 bottom-3 flex items-center gap-2">
            <button
              type="button"
              disabled={isEnhancing || !prompt.trim()}
              onClick={handleEnhancePrompt}
              className="px-3.5 py-1.5 rounded-lg bg-neutral-900/90 hover:bg-neutral-800 text-amber-400 text-xs font-bold border border-amber-500/30 flex items-center gap-1.5 transition-all shadow-md active:scale-95 disabled:opacity-40"
              title="Transform simple prompt into complete architecture specification"
            >
              {isEnhancing ? (
                <>
                  <div className="w-3 h-3 border-2 border-amber-400 border-t-transparent rounded-full animate-spin" />
                  <span>Enhancing...</span>
                </>
              ) : (
                <>
                  <Wand2 className="w-3.5 h-3.5 text-amber-400" />
                  <span>Enhance Prompt ✨</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* ENHANCED PROMPT PREVIEW DIALOG (IF ACTIVE) */}
        {enhancedResult && (
          <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/40 text-xs space-y-3 animate-in fade-in duration-200">
            <div className="flex items-center justify-between">
              <span className="font-bold text-amber-400 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4" /> AI Enhanced Website Specification
              </span>
              <button
                type="button"
                onClick={() => setEnhancedResult(null)}
                className="text-neutral-400 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
            <p className="text-neutral-200 leading-relaxed bg-neutral-950/70 p-3 rounded-lg border border-neutral-800 font-sans">
              {enhancedResult}
            </p>
            <div className="flex items-center justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => setEnhancedResult(null)}
                className="px-3 py-1.5 rounded text-neutral-400 hover:text-white text-xs"
              >
                Dismiss
              </button>
              <button
                type="button"
                onClick={handleApplyEnhancedPrompt}
                className="px-4 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs flex items-center gap-1.5 shadow-sm"
              >
                <span>Apply to Prompt</span>
              </button>
            </div>
          </div>
        )}

        {/* ERROR MESSAGE DISPLAY */}
        {generationError && (
          <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{generationError}</span>
            </div>
            <button
              type="button"
              onClick={() => setGenerationError(null)}
              className="text-rose-400 hover:text-rose-200"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* QUICK PRESETS ROW */}
        <div>
          <div className="flex items-center justify-between mb-2.5">
            <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-400 flex items-center gap-1.5">
              <Flame className="w-3.5 h-3.5 text-amber-400" />
              Quick-Start Presets
            </span>
            <span className="text-[10px] text-neutral-500">Click to insert example prompt</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
            {QUICK_PRESETS.map((preset) => (
              <button
                key={preset.id}
                type="button"
                onClick={() => handleSelectPreset(preset.prompt)}
                className="p-2.5 rounded-xl bg-neutral-950 border border-neutral-800 hover:border-amber-500/50 hover:bg-neutral-900/80 text-left transition-all group flex flex-col justify-between"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-base">{preset.icon}</span>
                  <span className="text-[9px] font-mono uppercase px-1.5 py-0.5 rounded bg-neutral-900 text-neutral-400 group-hover:text-amber-400 group-hover:bg-amber-500/10">
                    {preset.badge}
                  </span>
                </div>
                <div className="text-xs font-semibold text-neutral-200 group-hover:text-white truncate">
                  {preset.name}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* OPTIONAL CLIENT & BRAND INFORMATION (COLLAPSIBLE) */}
        <div className="pt-2 border-t border-neutral-800">
          <button
            type="button"
            onClick={() => setShowClientFields(!showClientFields)}
            className="flex items-center justify-between w-full py-2 text-xs font-bold text-neutral-300 hover:text-white transition-colors"
          >
            <div className="flex items-center gap-2">
              <Building2 className="w-4 h-4 text-amber-400" />
              <span>Client & Brand Information (Optional)</span>
              <span className="text-[10px] font-normal text-neutral-500">
                — Fill if you already have verified client details
              </span>
            </div>
            {showClientFields ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>

          {showClientFields && (
            <div className="mt-4 p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-4 text-xs animate-in fade-in duration-200">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-neutral-400 font-medium mb-1">Client / Owner Name</label>
                  <input
                    type="text"
                    value={clientInfo.clientName}
                    onChange={(e) => setClientInfo({ ...clientInfo, clientName: e.target.value })}
                    placeholder="e.g. Dr. Tariq Mansoor"
                    className="w-full px-3 py-2 rounded-lg bg-neutral-900 border border-neutral-800 text-white placeholder-neutral-600 focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-neutral-400 font-medium mb-1">Business Name</label>
                  <input
                    type="text"
                    value={clientInfo.businessName}
                    onChange={(e) => setClientInfo({ ...clientInfo, businessName: e.target.value })}
                    placeholder="e.g. Emirates Dental Atelier"
                    className="w-full px-3 py-2 rounded-lg bg-neutral-900 border border-neutral-800 text-white placeholder-neutral-600 focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-neutral-400 font-medium mb-1">Industry / Niche</label>
                  <input
                    type="text"
                    value={clientInfo.industry}
                    onChange={(e) => setClientInfo({ ...clientInfo, industry: e.target.value })}
                    placeholder="e.g. Cosmetic Dentistry"
                    className="w-full px-3 py-2 rounded-lg bg-neutral-900 border border-neutral-800 text-white placeholder-neutral-600 focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-neutral-400 font-medium mb-1">Location / Service Area</label>
                  <input
                    type="text"
                    value={clientInfo.location}
                    onChange={(e) => setClientInfo({ ...clientInfo, location: e.target.value })}
                    placeholder="e.g. Downtown Dubai, UAE"
                    className="w-full px-3 py-2 rounded-lg bg-neutral-900 border border-neutral-800 text-white placeholder-neutral-600 focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-neutral-400 font-medium mb-1">Website URL</label>
                  <input
                    type="text"
                    value={clientInfo.websiteUrl}
                    onChange={(e) => setClientInfo({ ...clientInfo, websiteUrl: e.target.value })}
                    placeholder="e.g. emiratesdental.ae"
                    className="w-full px-3 py-2 rounded-lg bg-neutral-900 border border-neutral-800 text-white placeholder-neutral-600 focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-neutral-400 font-medium mb-1">Phone Number</label>
                  <input
                    type="tel"
                    value={clientInfo.phone}
                    onChange={(e) => setClientInfo({ ...clientInfo, phone: e.target.value })}
                    placeholder="+971 4 555 0199"
                    className="w-full px-3 py-2 rounded-lg bg-neutral-900 border border-neutral-800 text-white placeholder-neutral-600 focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-neutral-400 font-medium mb-1">Contact Email</label>
                  <input
                    type="email"
                    value={clientInfo.email}
                    onChange={(e) => setClientInfo({ ...clientInfo, email: e.target.value })}
                    placeholder="concierge@emiratesdental.ae"
                    className="w-full px-3 py-2 rounded-lg bg-neutral-900 border border-neutral-800 text-white placeholder-neutral-600 focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-neutral-400 font-medium mb-1">WhatsApp Number</label>
                  <input
                    type="tel"
                    value={clientInfo.whatsapp}
                    onChange={(e) => setClientInfo({ ...clientInfo, whatsapp: e.target.value })}
                    placeholder="+971501234567"
                    className="w-full px-3 py-2 rounded-lg bg-neutral-900 border border-neutral-800 text-white placeholder-neutral-600 focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* BUILD WEBSITE BUTTON / DESKTOP & MOBILE STICKY BAR */}
        <div className="pt-4 flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-neutral-800">
          <div className="text-xs text-neutral-400 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Client Protection Active: Real business info used. Zero fabricated reviews.</span>
          </div>

          <button
            type="button"
            disabled={isGenerating || !prompt.trim()}
            onClick={handleBuildWebsite}
            className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-neutral-950 font-extrabold text-sm flex items-center justify-center gap-2 shadow-xl shadow-amber-500/25 transition-all transform active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <Sparkles className="w-4 h-4" />
            <span>Build Website</span>
            <ArrowRight className="w-4 h-4 ml-1" />
          </button>
        </div>
      </div>

      {/* PROMPT HISTORY DRAWER / RECENT PROMPTS */}
      {promptHistory.length > 0 && (
        <div className="mt-8 bg-neutral-900/60 border border-neutral-800/80 rounded-2xl p-5 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-400 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              Recent AI Website Prompts ({promptHistory.length})
            </span>
            <button
              type="button"
              onClick={() => setPromptHistory([])}
              className="text-[11px] text-neutral-500 hover:text-neutral-300"
            >
              Clear History
            </button>
          </div>

          <div className="space-y-2">
            {promptHistory.slice(0, 5).map((item) => (
              <div
                key={item.id}
                onClick={() => handleSelectPreset(item.prompt)}
                className="p-3 rounded-xl bg-neutral-950/80 border border-neutral-800/80 hover:border-amber-500/40 text-left transition-all cursor-pointer flex items-center justify-between group"
              >
                <div className="truncate flex-1 mr-3">
                  <div className="text-xs font-medium text-neutral-200 group-hover:text-amber-300 truncate">
                    {item.prompt}
                  </div>
                  <div className="text-[10px] text-neutral-500 font-mono mt-0.5">
                    {new Date(item.timestamp).toLocaleDateString()} {item.businessName ? `· ${item.businessName}` : ''}
                  </div>
                </div>
                <button
                  type="button"
                  className="px-2.5 py-1 rounded bg-neutral-900 border border-neutral-800 text-[10px] font-semibold text-neutral-400 group-hover:text-amber-400 group-hover:border-amber-500/30 flex-shrink-0"
                >
                  Use Prompt
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
