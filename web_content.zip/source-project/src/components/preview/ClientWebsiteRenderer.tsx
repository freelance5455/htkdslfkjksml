import React, { useState } from 'react';
import { WebsiteProject, WebsiteSection, CTAButton } from '../../types/website';
import { 
  imageFocalPointToClass, 
  imageAspectRatioToClass, 
  generateBrandedPlaceholderSvg 
} from '../../utils/imageOptimizer';
import { WebsiteChatbotWidget } from '../chatbot/WebsiteChatbotWidget';
import { 
  Phone, 
  Mail, 
  MessageSquare, 
  Calendar, 
  ArrowRight, 
  Check, 
  CheckCircle, 
  Sparkles, 
  ChevronDown, 
  MapPin, 
  Clock, 
  ShieldCheck, 
  Star,
  ExternalLink,
  Image as ImageIcon,
  Upload,
  Menu,
  X
} from 'lucide-react';

interface ClientWebsiteRendererProps {
  project: WebsiteProject;
  activePageId?: string;
  onNavigatePage?: (pageId: string) => void;
  interactive?: boolean;
  onSectionClick?: (sectionId: string) => void;
  onImageClick?: (sectionId: string, itemIndex?: number) => void;
  selectedSectionId?: string | null;
}

export const ClientWebsiteRenderer: React.FC<ClientWebsiteRendererProps> = ({
  project,
  activePageId,
  onNavigatePage,
  interactive = true,
  onSectionClick,
  onImageClick,
  selectedSectionId,
}) => {
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [openFaqId, setOpenFaqId] = useState<string | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const activeId = activePageId || project.activePageId || project.pages[0]?.id;
  const currentPage = project.pages.find((p) => p.id === activeId) || project.pages.find((p) => p.isHome) || project.pages[0];
  const pages = project.pages || [];
  const brand = project.brand;
  const business = project.business;

  // Font styling class mapping
  const headingFontClass =
    brand.fontPairing === 'luxury'
      ? "font-['Cinzel'] tracking-wide"
      : brand.fontPairing === 'editorial'
      ? "font-['Playfair_Display']"
      : brand.fontPairing === 'technical'
      ? "font-['JetBrains_Mono'] tracking-tight"
      : "font-['Plus_Jakarta_Sans'] font-bold";

  const bodyFontClass =
    brand.fontPairing === 'editorial' ? "font-['Inter']" : "font-['Plus_Jakarta_Sans']";

  const roundedClass =
    brand.borderRadius === 'rounded'
      ? 'rounded-2xl'
      : brand.borderRadius === 'subtle'
      ? 'rounded-lg'
      : 'rounded-none';

  const btnRoundedClass =
    brand.borderRadius === 'rounded'
      ? 'rounded-full'
      : brand.borderRadius === 'subtle'
      ? 'rounded-md'
      : 'rounded-none';

  const renderCtaIcon = (iconName?: string) => {
    switch (iconName) {
      case 'phone':
        return <Phone className="w-4 h-4" />;
      case 'whatsapp':
        return <MessageSquare className="w-4 h-4 text-emerald-400" />;
      case 'calendar':
        return <Calendar className="w-4 h-4" />;
      case 'mail':
        return <Mail className="w-4 h-4" />;
      case 'check':
        return <Check className="w-4 h-4" />;
      default:
        return <ArrowRight className="w-4 h-4" />;
    }
  };

  const renderCtaButton = (btn?: CTAButton, isPrimary: boolean = true) => {
    if (!btn || !btn.label) return null;

    let href = btn.link;
    if (btn.type === 'call' && business.phone) {
      href = `tel:${business.phone.replace(/[^0-9+]/g, '')}`;
    } else if (btn.type === 'whatsapp' && business.whatsapp) {
      const cleanWa = business.whatsapp.replace(/[^0-9]/g, '');
      href = `https://wa.me/${cleanWa}?text=Hello%20${encodeURIComponent(business.name)},%20I%20would%20like%20to%20inquire%20about%20your%20services.`;
    }

    const handleCtaClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
      if (!href) return;
      if (href.startsWith('tel:') || href.startsWith('mailto:') || href.startsWith('http') || btn.type === 'whatsapp') {
        return;
      }
      e.preventDefault();
      // Check if matches page slug or id
      const targetPage = pages.find((p) => p.slug === href || p.id === href || `/${p.id}` === href);
      if (targetPage && onNavigatePage) {
        onNavigatePage(targetPage.id);
        return;
      }
      if (href === '#contact') {
        const contactPage = pages.find((p) => p.slug === '/contact' || p.id === 'page-contact');
        const hasContactSection = currentPage.sections.some((s) => s.type === 'contact');
        if (!hasContactSection && contactPage && onNavigatePage) {
          onNavigatePage(contactPage.id);
        } else {
          const el = document.getElementById('contact');
          if (el) el.scrollIntoView({ behavior: 'smooth' });
        }
        return;
      }
      if (href === '#services') {
        const servicesPage = pages.find((p) => p.slug === '/services' || p.id === 'page-services');
        const hasServicesSection = currentPage.sections.some((s) => s.type === 'services');
        if (!hasServicesSection && servicesPage && onNavigatePage) {
          onNavigatePage(servicesPage.id);
        } else {
          const el = document.getElementById('services');
          if (el) el.scrollIntoView({ behavior: 'smooth' });
        }
        return;
      }
    };

    if (btn.type === 'whatsapp') {
      return (
        <a
          href={href}
          target="_blank"
          rel="noopener noreferrer"
          className={`inline-flex items-center gap-2 px-5 py-3 text-xs sm:text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 shadow-sm transition-all transform active:scale-95 ${btnRoundedClass}`}
        >
          <MessageSquare className="w-4 h-4" />
          <span>{btn.label}</span>
        </a>
      );
    }

    if (isPrimary) {
      return (
        <a
          href={href}
          onClick={handleCtaClick}
          style={{ backgroundColor: brand.primaryColor }}
          className={`inline-flex items-center gap-2 px-6 py-3 text-xs sm:text-sm font-semibold text-white shadow-sm hover:opacity-95 transition-all transform active:scale-95 cursor-pointer ${btnRoundedClass}`}
        >
          {renderCtaIcon(btn.icon)}
          <span>{btn.label}</span>
        </a>
      );
    }

    return (
      <a
        href={href}
        onClick={handleCtaClick}
        style={{ borderColor: brand.secondaryColor }}
        className={`inline-flex items-center gap-2 px-5 py-3 text-xs sm:text-sm font-semibold border text-neutral-800 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-all cursor-pointer ${btnRoundedClass}`}
      >
        {renderCtaIcon(btn.icon)}
        <span>{btn.label}</span>
      </a>
    );
  };

  const renderSection = (sec: WebsiteSection) => {
    if (!sec.isVisible) return null;

    const isSelected = selectedSectionId === sec.id;
    const selectionBorder = isSelected
      ? 'ring-2 ring-amber-500 ring-offset-2 ring-offset-neutral-900 relative z-10'
      : '';

    switch (sec.type) {
      case 'hero':
        return (
          <header
            key={sec.id}
            onClick={() => onSectionClick?.(sec.id)}
            className={`relative overflow-hidden py-16 sm:py-24 transition-all cursor-pointer ${selectionBorder} ${
              brand.lightMode ? 'bg-slate-50/70 text-slate-900' : 'bg-neutral-950 text-neutral-100'
            }`}
          >
            <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
              <div
                className={`grid grid-cols-1 ${
                  sec.imageUrl && sec.layoutVariant.includes('split')
                    ? 'lg:grid-cols-12 gap-12 items-center'
                    : 'max-w-3xl mx-auto text-center'
                }`}
              >
                <div
                  className={
                    sec.imageUrl && sec.layoutVariant === 'split-left'
                      ? 'lg:col-span-6 lg:order-2'
                      : sec.imageUrl && sec.layoutVariant === 'split-right'
                      ? 'lg:col-span-6'
                      : ''
                  }
                >
                  {sec.kicker && (
                    <div
                      style={{ color: brand.accentColor }}
                      className="text-xs uppercase tracking-widest font-bold mb-4 flex items-center gap-2 justify-center lg:justify-start"
                    >
                      <span className="w-2 h-2 rounded-full" style={{ backgroundColor: brand.accentColor }} />
                      <span>{sec.kicker}</span>
                    </div>
                  )}

                  <h1 className={`text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight mb-6 leading-[1.15] ${headingFontClass}`}>
                    {sec.title}
                  </h1>

                  {sec.subtitle && (
                    <p className={`text-base sm:text-lg mb-8 leading-relaxed ${brand.lightMode ? 'text-slate-600' : 'text-neutral-400'} ${bodyFontClass}`}>
                      {sec.subtitle}
                    </p>
                  )}

                  <div className={`flex flex-wrap gap-3 items-center ${sec.layoutVariant === 'centered' ? 'justify-center' : 'justify-start'}`}>
                    {renderCtaButton(sec.ctaPrimary, true)}
                    {renderCtaButton(sec.ctaSecondary, false)}
                  </div>

                  {business.location && (
                    <div className="mt-8 flex items-center gap-2 text-xs text-neutral-500">
                      <MapPin className="w-3.5 h-3.5 text-neutral-400" />
                      <span>{business.location}</span>
                      {business.businessHours && (
                        <>
                          <span>·</span>
                          <Clock className="w-3.5 h-3.5 text-neutral-400" />
                          <span>{business.businessHours}</span>
                        </>
                      )}
                    </div>
                  )}
                </div>

                {sec.imageUrl && sec.layoutVariant.includes('split') && (
                  <div
                    className={`relative ${
                      sec.layoutVariant === 'split-left'
                        ? 'lg:col-span-6 lg:order-1'
                        : 'lg:col-span-6'
                    }`}
                  >
                    <div 
                      onClick={(e) => {
                        if (onImageClick) {
                          e.stopPropagation();
                          onImageClick(sec.id);
                        }
                      }}
                      className={`relative overflow-hidden shadow-2xl border border-neutral-200 dark:border-neutral-800 group cursor-pointer ${roundedClass} ${imageAspectRatioToClass(sec.imageAspectRatio)}`}
                    >
                      {sec.isImagePlaceholder ? (
                        <div className="w-full h-full min-h-[360px] bg-neutral-900 border border-dashed border-neutral-700 flex flex-col items-center justify-center p-6 text-center hover:bg-neutral-800/80 transition-colors">
                          <div className="w-12 h-12 rounded-full bg-amber-500/10 text-amber-400 flex items-center justify-center mb-3">
                            <ImageIcon className="w-6 h-6" />
                          </div>
                          <span className="font-bold text-sm text-neutral-200 mb-1">Add your business image</span>
                          <span className="text-[11px] text-neutral-500 mb-3 max-w-xs">
                            Recommended {sec.imageAspectRatio || '16:9'} · High-Resolution Client Photo
                          </span>
                          <span className="text-[10px] uppercase font-mono px-2.5 py-1 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center gap-1">
                            <Upload className="w-3 h-3" /> Click to Upload / AI Generate
                          </span>
                        </div>
                      ) : (
                        <>
                          <img
                            src={sec.imageUrl}
                            alt={sec.imageAlt || sec.title}
                            className={`w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ${imageFocalPointToClass(sec.imageFocalPoint)}`}
                            loading="eager"
                            decoding="async"
                            referrerPolicy="no-referrer"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent pointer-events-none" />
                          {sec.imageOrigin && (
                            <span className="absolute top-3 right-3 text-[9px] font-mono uppercase px-2 py-0.5 rounded bg-black/80 backdrop-blur text-white/90 border border-white/10 opacity-80 group-hover:opacity-100 transition-opacity">
                              {sec.imageOrigin.replace('_', ' ')}
                            </span>
                          )}
                          {interactive && (
                            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
                              <span className="px-3 py-1.5 rounded-lg bg-neutral-900/90 text-amber-400 text-xs font-bold border border-amber-500/40 flex items-center gap-1.5 shadow-lg">
                                <Sparkles className="w-3.5 h-3.5" />
                                <span>Edit / Replace Image</span>
                              </span>
                            </div>
                          )}
                        </>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </header>
        );

      case 'services':
        return (
          <section
            key={sec.id}
            id="services"
            onClick={() => onSectionClick?.(sec.id)}
            className={`py-20 cursor-pointer transition-all ${selectionBorder} ${
              brand.lightMode ? 'bg-white text-slate-900' : 'bg-neutral-900 text-neutral-100'
            }`}
          >
            <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center max-w-2xl mx-auto mb-16">
                <h2 className={`text-2xl sm:text-4xl font-bold tracking-tight mb-4 ${headingFontClass}`}>
                  {sec.title}
                </h2>
                {sec.subtitle && (
                  <p className={`text-sm sm:text-base ${brand.lightMode ? 'text-slate-600' : 'text-neutral-400'} ${bodyFontClass}`}>
                    {sec.subtitle}
                  </p>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
                {(sec.items || []).map((item, idx) => (
                  <div
                    key={item.id || idx}
                    className={`border transition-all duration-300 hover:shadow-lg flex flex-col justify-between overflow-hidden ${
                      brand.lightMode
                        ? 'bg-slate-50/50 border-slate-200/80 hover:border-slate-300'
                        : 'bg-neutral-950/60 border-neutral-800 hover:border-neutral-700'
                    } ${roundedClass}`}
                  >
                    {/* Optional Service Image Slot */}
                    {(item.imageUrl || item.isPlaceholder) && (
                      <div 
                        onClick={(e) => {
                          if (onImageClick) {
                            e.stopPropagation();
                            onImageClick(sec.id, idx);
                          }
                        }}
                        className="relative aspect-[16/9] w-full overflow-hidden bg-neutral-900 group cursor-pointer border-b border-neutral-200 dark:border-neutral-800"
                      >
                        {item.isPlaceholder ? (
                          <div className="w-full h-full flex flex-col items-center justify-center p-3 text-center bg-neutral-950 hover:bg-neutral-900 transition-colors">
                            <ImageIcon className="w-5 h-5 text-neutral-500 mb-1" />
                            <span className="text-[11px] font-bold text-neutral-300">Add capability photo</span>
                            <span className="text-[9px] text-neutral-500">Service Slot 0{idx + 1}</span>
                          </div>
                        ) : (
                          <>
                            <img
                              src={item.imageUrl}
                              alt={item.imageAlt || item.title}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                              loading="lazy"
                              decoding="async"
                              referrerPolicy="no-referrer"
                            />
                            {item.imageOrigin && (
                              <span className="absolute top-2 right-2 text-[8px] font-mono uppercase px-1.5 py-0.5 rounded bg-black/80 text-white">
                                {item.imageOrigin.replace('_', ' ')}
                              </span>
                            )}
                          </>
                        )}
                      </div>
                    )}

                    <div className="p-6 sm:p-8">
                      {item.badge && (
                        <div
                          style={{ color: brand.accentColor }}
                          className="text-[11px] font-bold uppercase tracking-wider mb-3 flex items-center gap-1.5"
                        >
                          <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: brand.accentColor }} />
                          <span>{item.badge}</span>
                        </div>
                      )}
                      <h3 className={`text-lg sm:text-xl font-bold mb-3 ${headingFontClass}`}>
                        {item.title}
                      </h3>
                      <p className={`text-xs sm:text-sm leading-relaxed mb-6 ${brand.lightMode ? 'text-slate-600' : 'text-neutral-400'} ${bodyFontClass}`}>
                        {item.description}
                      </p>
                    </div>

                    <div className="p-6 pt-0 sm:p-8 sm:pt-0">
                      <div className="pt-4 border-t border-neutral-200 dark:border-neutral-800/80 flex items-center justify-between text-xs font-semibold">
                        <span className="text-neutral-400">Custom Scope</span>
                        <a href="#contact" className="hover:underline flex items-center gap-1" style={{ color: brand.accentColor }}>
                          Inquire <ArrowRight className="w-3 h-3" />
                        </a>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>
        );

      case 'process':
        return (
          <section
            key={sec.id}
            onClick={() => onSectionClick?.(sec.id)}
            className={`py-20 cursor-pointer transition-all ${selectionBorder} ${
              brand.lightMode ? 'bg-slate-50/60 text-slate-900' : 'bg-neutral-950 text-neutral-100'
            }`}
          >
            <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center max-w-2xl mx-auto mb-16">
                <h2 className={`text-2xl sm:text-4xl font-bold tracking-tight mb-4 ${headingFontClass}`}>
                  {sec.title}
                </h2>
                {sec.subtitle && (
                  <p className={`text-sm sm:text-base ${brand.lightMode ? 'text-slate-600' : 'text-neutral-400'} ${bodyFontClass}`}>
                    {sec.subtitle}
                  </p>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {(sec.items || []).map((step, idx) => (
                  <div
                    key={step.id || idx}
                    className={`relative p-6 sm:p-8 border ${
                      brand.lightMode
                        ? 'bg-white border-slate-200/80'
                        : 'bg-neutral-900 border-neutral-800'
                    } ${roundedClass}`}
                  >
                    <div
                      style={{ color: brand.accentColor }}
                      className="text-3xl sm:text-4xl font-extrabold mb-4 font-mono"
                    >
                      0{idx + 1}
                    </div>
                    <h3 className={`text-lg font-bold mb-2 ${headingFontClass}`}>
                      {step.title}
                    </h3>
                    <p className={`text-xs sm:text-sm leading-relaxed ${brand.lightMode ? 'text-slate-600' : 'text-neutral-400'} ${bodyFontClass}`}>
                      {step.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </section>
        );

      case 'pricing':
        return (
          <section
            key={sec.id}
            onClick={() => onSectionClick?.(sec.id)}
            className={`py-20 cursor-pointer transition-all ${selectionBorder} ${
              brand.lightMode ? 'bg-white text-slate-900' : 'bg-neutral-900 text-neutral-100'
            }`}
          >
            <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center max-w-2xl mx-auto mb-16">
                <h2 className={`text-2xl sm:text-4xl font-bold tracking-tight mb-4 ${headingFontClass}`}>
                  {sec.title}
                </h2>
                {sec.subtitle && (
                  <p className={`text-sm sm:text-base ${brand.lightMode ? 'text-slate-600' : 'text-neutral-400'} ${bodyFontClass}`}>
                    {sec.subtitle}
                  </p>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch">
                {(sec.items || []).map((tier, idx) => (
                  <div
                    key={tier.id || idx}
                    className={`p-8 border flex flex-col justify-between ${
                      tier.badge === 'Recommended'
                        ? 'border-amber-500 shadow-xl relative'
                        : brand.lightMode
                        ? 'bg-slate-50/60 border-slate-200'
                        : 'bg-neutral-950 border-neutral-800'
                    } ${roundedClass}`}
                  >
                    <div>
                      {tier.badge && (
                        <span className="inline-block px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider rounded bg-amber-500/10 text-amber-500 border border-amber-500/20 mb-4">
                          {tier.badge}
                        </span>
                      )}
                      <h3 className={`text-xl font-bold mb-2 ${headingFontClass}`}>{tier.title}</h3>
                      <div className="text-3xl font-extrabold mb-4">{tier.price || 'Custom Scope'}</div>
                      <p className={`text-xs mb-6 ${brand.lightMode ? 'text-slate-600' : 'text-neutral-400'}`}>
                        {tier.description}
                      </p>
                      {tier.features && (
                        <ul className="space-y-2.5 mb-8 text-xs">
                          {tier.features.map((feat, fIdx) => (
                            <li key={fIdx} className="flex items-center gap-2">
                              <CheckCircle className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                              <span>{feat}</span>
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                    <a
                      href="#contact"
                      style={{ backgroundColor: brand.primaryColor }}
                      className={`w-full py-3 text-center text-xs font-semibold text-white shadow-sm hover:opacity-90 transition-all ${btnRoundedClass}`}
                    >
                      Select Plan
                    </a>
                  </div>
                ))}
              </div>
            </div>
          </section>
        );

      case 'faq':
        return (
          <section
            key={sec.id}
            onClick={() => onSectionClick?.(sec.id)}
            className={`py-20 cursor-pointer transition-all ${selectionBorder} ${
              brand.lightMode ? 'bg-slate-50/50 text-slate-900' : 'bg-neutral-950 text-neutral-100'
            }`}
          >
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center mb-14">
                <h2 className={`text-2xl sm:text-4xl font-bold tracking-tight mb-3 ${headingFontClass}`}>
                  {sec.title}
                </h2>
                {sec.subtitle && (
                  <p className={`text-sm ${brand.lightMode ? 'text-slate-600' : 'text-neutral-400'} ${bodyFontClass}`}>
                    {sec.subtitle}
                  </p>
                )}
              </div>

              <div className="space-y-3">
                {(sec.items || []).map((faq, idx) => {
                  const isOpen = openFaqId === faq.id || (openFaqId === null && idx === 0);
                  return (
                    <div
                      key={faq.id || idx}
                      className={`border transition-colors ${
                        brand.lightMode
                          ? 'bg-white border-slate-200/80 hover:border-slate-300'
                          : 'bg-neutral-900 border-neutral-800 hover:border-neutral-700'
                      } ${roundedClass}`}
                    >
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setOpenFaqId(isOpen ? '' : faq.id);
                        }}
                        className="w-full text-left px-6 py-4 flex items-center justify-between font-semibold text-sm sm:text-base focus:outline-none"
                      >
                        <span className={headingFontClass}>{faq.title}</span>
                        <ChevronDown
                          className={`w-4 h-4 text-neutral-400 transition-transform duration-200 ${
                            isOpen ? 'transform rotate-180 text-amber-500' : ''
                          }`}
                        />
                      </button>
                      {isOpen && (
                        <div className={`px-6 pb-5 pt-1 text-xs sm:text-sm leading-relaxed border-t border-neutral-100 dark:border-neutral-800/60 ${brand.lightMode ? 'text-slate-600' : 'text-neutral-400'} ${bodyFontClass}`}>
                          {faq.description}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </section>
        );

      case 'contact':
        return (
          <section
            key={sec.id}
            id="contact"
            onClick={() => onSectionClick?.(sec.id)}
            className={`py-20 cursor-pointer transition-all ${selectionBorder} ${
              brand.lightMode ? 'bg-slate-900 text-white' : 'bg-black text-neutral-100'
            }`}
          >
            <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
                <div className="lg:col-span-6">
                  <div className="text-xs uppercase tracking-widest font-bold mb-3" style={{ color: brand.accentColor }}>
                    Direct Consultation
                  </div>
                  <h2 className={`text-3xl sm:text-4xl font-bold mb-4 tracking-tight leading-tight ${headingFontClass}`}>
                    {sec.title}
                  </h2>
                  <p className="text-sm sm:text-base text-neutral-300 mb-8 leading-relaxed">
                    {sec.subtitle || 'Connect with our principals to evaluate your project scope and schedule.'}
                  </p>

                  <div className="space-y-4 text-sm text-neutral-300">
                    {business.location && (
                      <div className="flex items-start gap-3">
                        <MapPin className="w-5 h-5 text-neutral-400 mt-0.5 flex-shrink-0" />
                        <div>
                          <div className="font-semibold text-white">Location / Address</div>
                          <div className="text-xs text-neutral-400">{business.location}</div>
                        </div>
                      </div>
                    )}

                    {business.phone && (
                      <div className="flex items-start gap-3">
                        <Phone className="w-5 h-5 text-neutral-400 mt-0.5 flex-shrink-0" />
                        <div>
                          <div className="font-semibold text-white">Telephone</div>
                          <a href={`tel:${business.phone}`} className="text-xs text-amber-300 hover:underline">
                            {business.phone}
                          </a>
                        </div>
                      </div>
                    )}

                    {business.whatsapp && (
                      <div className="flex items-start gap-3">
                        <MessageSquare className="w-5 h-5 text-emerald-400 mt-0.5 flex-shrink-0" />
                        <div>
                          <div className="font-semibold text-white">WhatsApp Direct</div>
                          <a
                            href={`https://wa.me/${business.whatsapp.replace(/[^0-9]/g, '')}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-xs text-emerald-400 hover:underline font-medium"
                          >
                            Chat on WhatsApp
                          </a>
                        </div>
                      </div>
                    )}

                    {business.email && (
                      <div className="flex items-start gap-3">
                        <Mail className="w-5 h-5 text-neutral-400 mt-0.5 flex-shrink-0" />
                        <div>
                          <div className="font-semibold text-white">Direct Email</div>
                          <a href={`mailto:${business.email}`} className="text-xs text-neutral-400 hover:underline">
                            {business.email}
                          </a>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                <div className={`lg:col-span-6 p-6 sm:p-8 bg-neutral-900 border border-neutral-800 ${roundedClass}`}>
                  {formSubmitted ? (
                    <div className="text-center py-12">
                      <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto mb-4">
                        <Check className="w-6 h-6" />
                      </div>
                      <h3 className="text-xl font-bold text-white mb-2">Inquiry Received</h3>
                      <p className="text-xs text-neutral-400 mb-6">
                        Your message has been logged. Our coordinator will review your request and reply promptly.
                      </p>
                      <button
                        onClick={() => setFormSubmitted(false)}
                        className="text-xs text-amber-400 hover:underline"
                      >
                        Submit another inquiry
                      </button>
                    </div>
                  ) : (
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        setFormSubmitted(true);
                      }}
                      className="space-y-4"
                    >
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-[11px] uppercase tracking-wider text-neutral-400 font-semibold mb-1">
                            Your Name *
                          </label>
                          <input
                            type="text"
                            required
                            placeholder="John Smith"
                            className="w-full px-3.5 py-2 text-xs rounded bg-neutral-950 border border-neutral-700 text-white placeholder-neutral-600 focus:outline-none focus:border-amber-500"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] uppercase tracking-wider text-neutral-400 font-semibold mb-1">
                            Phone Number *
                          </label>
                          <input
                            type="tel"
                            required
                            placeholder="(555) 000-0000"
                            className="w-full px-3.5 py-2 text-xs rounded bg-neutral-950 border border-neutral-700 text-white placeholder-neutral-600 focus:outline-none focus:border-amber-500"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-[11px] uppercase tracking-wider text-neutral-400 font-semibold mb-1">
                          Email Address *
                        </label>
                        <input
                          type="email"
                          required
                          placeholder="client@company.com"
                          className="w-full px-3.5 py-2 text-xs rounded bg-neutral-950 border border-neutral-700 text-white placeholder-neutral-600 focus:outline-none focus:border-amber-500"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] uppercase tracking-wider text-neutral-400 font-semibold mb-1">
                          Service of Interest
                        </label>
                        <select className="w-full px-3.5 py-2 text-xs rounded bg-neutral-950 border border-neutral-700 text-white focus:outline-none focus:border-amber-500">
                          {business.services.map((srv, idx) => (
                            <option key={idx} value={srv}>
                              {srv}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-[11px] uppercase tracking-wider text-neutral-400 font-semibold mb-1">
                          Message / Project Brief
                        </label>
                        <textarea
                          rows={3}
                          placeholder="Briefly describe your requirements or preferred appointment times..."
                          className="w-full px-3.5 py-2 text-xs rounded bg-neutral-950 border border-neutral-700 text-white placeholder-neutral-600 focus:outline-none focus:border-amber-500"
                        />
                      </div>

                      <button
                        type="submit"
                        style={{ backgroundColor: brand.accentColor }}
                        className={`w-full py-3 text-xs sm:text-sm font-bold text-neutral-950 shadow-md hover:opacity-90 transition-all ${btnRoundedClass}`}
                      >
                        Submit Consultation Request
                      </button>

                      <div className="text-[10px] text-neutral-500 text-center flex items-center justify-center gap-1">
                        <ShieldCheck className="w-3.5 h-3.5" />
                        <span>All inquiries are confidential. Zero marketing spam.</span>
                      </div>
                    </form>
                  )}
                </div>
              </div>
            </div>
          </section>
        );

      case 'about':
        return (
          <section
            key={sec.id}
            id="about"
            onClick={() => onSectionClick?.(sec.id)}
            className={`py-20 cursor-pointer transition-all ${selectionBorder} ${
              brand.lightMode ? 'bg-slate-50/70 text-slate-900' : 'bg-neutral-900 text-neutral-100'
            }`}
          >
            <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
                <div className="lg:col-span-6">
                  {sec.kicker && (
                    <div className="text-xs uppercase tracking-widest font-bold mb-3" style={{ color: brand.accentColor }}>
                      {sec.kicker}
                    </div>
                  )}
                  <h2 className={`text-2xl sm:text-4xl font-bold tracking-tight mb-4 ${headingFontClass}`}>
                    {sec.title}
                  </h2>
                  <p className={`text-sm sm:text-base mb-6 leading-relaxed ${brand.lightMode ? 'text-slate-600' : 'text-neutral-400'} ${bodyFontClass}`}>
                    {sec.subtitle || sec.content || business.description}
                  </p>

                  {sec.items && sec.items.length > 0 && (
                    <div className="space-y-3 pt-2">
                      {sec.items.map((it, idx) => (
                        <div key={idx} className="flex items-start gap-3 text-xs sm:text-sm">
                          <CheckCircle className="w-4 h-4 text-emerald-500 mt-0.5 flex-shrink-0" />
                          <div>
                            <span className="font-semibold text-neutral-900 dark:text-neutral-100">{it.title}</span>
                            {it.description && <span className="text-neutral-500 block text-xs mt-0.5">{it.description}</span>}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="lg:col-span-6">
                  <div
                    onClick={(e) => {
                      if (onImageClick) {
                        e.stopPropagation();
                        onImageClick(sec.id);
                      }
                    }}
                    className={`relative overflow-hidden shadow-xl border border-neutral-200 dark:border-neutral-800 group cursor-pointer ${roundedClass} ${imageAspectRatioToClass(sec.imageAspectRatio || '4:3')}`}
                  >
                    {sec.isImagePlaceholder || !sec.imageUrl ? (
                      <div className="w-full h-full min-h-[320px] bg-neutral-950 border border-dashed border-neutral-800 flex flex-col items-center justify-center p-6 text-center hover:bg-neutral-900/80 transition-colors">
                        <div className="w-10 h-10 rounded-full bg-amber-500/10 text-amber-400 flex items-center justify-center mb-2">
                          <ImageIcon className="w-5 h-5" />
                        </div>
                        <span className="font-bold text-xs text-neutral-200">Add your business image</span>
                        <span className="text-[10px] text-neutral-500 mt-1 mb-2">
                          Facility, Studio, or Founder Portrait Slot
                        </span>
                        <span className="text-[9px] uppercase font-mono px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center gap-1">
                          <Upload className="w-2.5 h-2.5" /> Upload or AI Generate
                        </span>
                      </div>
                    ) : (
                      <>
                        <img
                          src={sec.imageUrl}
                          alt={sec.imageAlt || sec.title}
                          className={`w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ${imageFocalPointToClass(sec.imageFocalPoint)}`}
                          loading="lazy"
                          decoding="async"
                          referrerPolicy="no-referrer"
                        />
                        {sec.imageOrigin && (
                          <span className="absolute top-3 right-3 text-[9px] font-mono uppercase px-2 py-0.5 rounded bg-black/80 backdrop-blur text-white/90 border border-white/10 opacity-80 group-hover:opacity-100 transition-opacity">
                            {sec.imageOrigin.replace('_', ' ')}
                          </span>
                        )}
                        {interactive && (
                          <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
                            <span className="px-3 py-1.5 rounded-lg bg-neutral-900/90 text-amber-400 text-xs font-bold border border-amber-500/40 flex items-center gap-1.5 shadow-lg">
                              <Sparkles className="w-3.5 h-3.5" />
                              <span>Edit / Replace Image</span>
                            </span>
                          </div>
                        )}
                      </>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </section>
        );

      case 'gallery':
        return (
          <section
            key={sec.id}
            id="gallery"
            onClick={() => onSectionClick?.(sec.id)}
            className={`py-20 cursor-pointer transition-all ${selectionBorder} ${
              brand.lightMode ? 'bg-white text-slate-900' : 'bg-neutral-950 text-neutral-100'
            }`}
          >
            <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center max-w-2xl mx-auto mb-14">
                <h2 className={`text-2xl sm:text-4xl font-bold tracking-tight mb-3 ${headingFontClass}`}>
                  {sec.title}
                </h2>
                {sec.subtitle && (
                  <p className={`text-sm ${brand.lightMode ? 'text-slate-600' : 'text-neutral-400'} ${bodyFontClass}`}>
                    {sec.subtitle}
                  </p>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                {(sec.galleryImages || (sec.items?.filter(it => it.imageUrl).map(it => ({
                  id: it.id,
                  url: it.imageUrl!,
                  altText: it.imageAlt || it.title,
                  caption: it.title,
                  origin: it.imageOrigin || 'stock_licensed',
                  isPlaceholder: it.isPlaceholder,
                }))) || [
                  { id: 'g1', url: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=800&q=80', altText: 'Architectural facade', caption: 'Corporate Facility', origin: 'stock_licensed' as const, isPlaceholder: false },
                  { id: 'g2', url: 'https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&w=800&q=80', altText: 'Studio Operatory', caption: 'Client Suite', origin: 'stock_licensed' as const, isPlaceholder: false },
                  { id: 'g3', url: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80', altText: 'Gastronomy Course', caption: 'Signature Craft', origin: 'stock_licensed' as const, isPlaceholder: false },
                ]).map((imgItem, idx) => (
                  <div
                    key={imgItem.id || idx}
                    className={`group relative overflow-hidden border border-neutral-200 dark:border-neutral-800 shadow-md ${roundedClass} aspect-[4/3] bg-neutral-900`}
                  >
                    {imgItem.isPlaceholder ? (
                      <div className="w-full h-full flex flex-col items-center justify-center p-4 text-center bg-neutral-950 border border-dashed border-neutral-800">
                        <ImageIcon className="w-6 h-6 text-neutral-600 mb-1" />
                        <span className="text-xs font-semibold text-neutral-300">Add your business image</span>
                        <span className="text-[10px] text-neutral-500">Gallery Slot 0{idx + 1}</span>
                      </div>
                    ) : (
                      <>
                        <img
                          src={imgItem.url}
                          alt={imgItem.altText}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                          loading="lazy"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">
                          <span className="text-xs font-semibold text-white">{imgItem.caption || imgItem.altText}</span>
                        </div>
                      </>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </section>
        );

      case 'portfolio':
        return (
          <section
            key={sec.id}
            id="portfolio"
            onClick={() => onSectionClick?.(sec.id)}
            className={`py-20 cursor-pointer transition-all ${selectionBorder} ${
              brand.lightMode ? 'bg-slate-50/70 text-slate-900' : 'bg-neutral-900 text-neutral-100'
            }`}
          >
            <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center max-w-2xl mx-auto mb-16">
                <h2 className={`text-2xl sm:text-4xl font-bold tracking-tight mb-4 ${headingFontClass}`}>
                  {sec.title}
                </h2>
                {sec.subtitle && (
                  <p className={`text-sm sm:text-base ${brand.lightMode ? 'text-slate-600' : 'text-neutral-400'} ${bodyFontClass}`}>
                    {sec.subtitle}
                  </p>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {(sec.items || []).map((proj, idx) => (
                  <div
                    key={proj.id || idx}
                    className={`overflow-hidden border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-950 flex flex-col justify-between shadow-sm hover:shadow-lg transition-all ${roundedClass}`}
                  >
                    <div className="h-48 overflow-hidden bg-neutral-900 relative">
                      {proj.imageUrl ? (
                        <img
                          src={proj.imageUrl}
                          alt={proj.imageAlt || proj.title}
                          className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                          loading="lazy"
                        />
                      ) : (
                        <div className="w-full h-full flex flex-col items-center justify-center p-4 text-center bg-neutral-950">
                          <ImageIcon className="w-6 h-6 text-neutral-600 mb-1" />
                          <span className="text-xs font-semibold text-neutral-400">Add project photo</span>
                        </div>
                      )}
                      {proj.badge && (
                        <span className="absolute top-3 left-3 text-[10px] font-bold px-2 py-0.5 rounded bg-black/80 backdrop-blur text-white">
                          {proj.badge}
                        </span>
                      )}
                    </div>

                    <div className="p-6">
                      <h3 className={`text-lg font-bold mb-2 ${headingFontClass}`}>{proj.title}</h3>
                      <p className={`text-xs text-neutral-500 dark:text-neutral-400 leading-relaxed mb-4 ${bodyFontClass}`}>
                        {proj.description}
                      </p>
                      {proj.features && (
                        <div className="flex flex-wrap gap-1.5">
                          {proj.features.map((feat, fIdx) => (
                            <span key={fIdx} className="text-[10px] px-2 py-0.5 rounded bg-neutral-100 dark:bg-neutral-900 text-neutral-600 dark:text-neutral-400">
                              {feat}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>
        );

      case 'cta-banner':
        return (
          <section
            key={sec.id}
            onClick={() => onSectionClick?.(sec.id)}
            className={`relative py-20 px-4 sm:px-6 lg:px-8 cursor-pointer overflow-hidden transition-all ${selectionBorder} ${
              sec.imageUrl ? 'bg-neutral-950 text-white' : brand.lightMode ? 'bg-slate-100 text-slate-900' : 'bg-neutral-900 text-white'
            }`}
          >
            {/* Background Image Slot with Legibility Overlay */}
            {sec.imageUrl && (
              <div className="absolute inset-0 z-0">
                <img
                  src={sec.imageUrl}
                  alt={sec.imageAlt || sec.title}
                  className={`w-full h-full object-cover ${imageFocalPointToClass(sec.imageFocalPoint)}`}
                  loading="lazy"
                  decoding="async"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-neutral-950/85 backdrop-blur-xs" />
              </div>
            )}

            <div className="relative z-10 max-w-4xl mx-auto text-center space-y-6">
              {sec.kicker && (
                <div
                  style={{ color: brand.accentColor }}
                  className="text-xs font-bold uppercase tracking-widest"
                >
                  {sec.kicker}
                </div>
              )}
              <h2 className={`text-3xl sm:text-5xl font-extrabold tracking-tight ${headingFontClass}`}>
                {sec.title}
              </h2>
              {sec.subtitle && (
                <p className={`text-base sm:text-lg max-w-2xl mx-auto leading-relaxed ${
                  sec.imageUrl || !brand.lightMode ? 'text-neutral-300' : 'text-slate-600'
                } ${bodyFontClass}`}>
                  {sec.subtitle}
                </p>
              )}
              <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
                {renderCtaButton(sec.ctaPrimary, true)}
                {renderCtaButton(sec.ctaSecondary, false)}
              </div>

              {/* Background image origin or edit indicator */}
              {interactive && sec.imageUrl && (
                <div className="pt-2">
                  <button
                    type="button"
                    onClick={(e) => {
                      if (onImageClick) {
                        e.stopPropagation();
                        onImageClick(sec.id);
                      }
                    }}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-black/60 text-[10px] text-amber-400 font-mono border border-amber-500/30 hover:bg-black/90 transition-colors"
                  >
                    <Sparkles className="w-3 h-3" />
                    <span>Background Image: {sec.imageOrigin?.replace('_', ' ') || 'Stock'} · Click to Edit</span>
                  </button>
                </div>
              )}
            </div>
          </section>
        );

      case 'testimonials':
        return (
          <section
            key={sec.id}
            id="testimonials"
            onClick={() => onSectionClick?.(sec.id)}
            className={`py-20 cursor-pointer transition-all ${selectionBorder} ${
              brand.lightMode ? 'bg-slate-50/60 text-slate-900' : 'bg-neutral-950 text-neutral-100'
            }`}
          >
            <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center max-w-2xl mx-auto mb-16">
                <h2 className={`text-2xl sm:text-4xl font-bold tracking-tight mb-4 ${headingFontClass}`}>
                  {sec.title || 'Client Perspectives'}
                </h2>
                {sec.subtitle && (
                  <p className={`text-sm sm:text-base ${brand.lightMode ? 'text-slate-600' : 'text-neutral-400'} ${bodyFontClass}`}>
                    {sec.subtitle}
                  </p>
                )}
                <div className="mt-2 text-[10px] uppercase font-mono text-neutral-500 flex items-center justify-center gap-1">
                  <ShieldCheck className="w-3 h-3 text-emerald-500" />
                  <span>Authenticated Client Engagements</span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {(sec.items || []).map((item, idx) => (
                  <div
                    key={item.id || idx}
                    className={`p-6 sm:p-8 border flex flex-col justify-between ${
                      brand.lightMode
                        ? 'bg-white border-slate-200/80 shadow-sm'
                        : 'bg-neutral-900 border-neutral-800'
                    } ${roundedClass}`}
                  >
                    <div>
                      {/* Rating stars if specified */}
                      {item.rating && (
                        <div className="flex gap-1 text-amber-400 mb-4">
                          {Array.from({ length: item.rating }).map((_, rIdx) => (
                            <Star key={rIdx} className="w-3.5 h-3.5 fill-current" />
                          ))}
                        </div>
                      )}
                      <p className={`text-xs sm:text-sm leading-relaxed mb-6 italic ${
                        brand.lightMode ? 'text-slate-700' : 'text-neutral-300'
                      } ${bodyFontClass}`}>
                        "{item.description}"
                      </p>
                    </div>

                    <div className="flex items-center gap-3 pt-4 border-t border-neutral-100 dark:border-neutral-800">
                      {/* STRICT IMAGE RULE: ONLY render genuine photo if supplied. Never fake faces. */}
                      {item.imageUrl ? (
                        <div className="relative">
                          <img
                            src={item.imageUrl}
                            alt={item.clientName || 'Client'}
                            className="w-10 h-10 rounded-full object-cover border border-neutral-300 dark:border-neutral-700"
                            loading="lazy"
                            decoding="async"
                            referrerPolicy="no-referrer"
                          />
                          <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-emerald-500 rounded-full border-2 border-white dark:border-neutral-900" title="Client Supplied Photo" />
                        </div>
                      ) : (
                        /* Elegant Monogram Avatar with initials */
                        <div
                          style={{ backgroundColor: brand.primaryColor, color: '#ffffff' }}
                          className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-xs font-mono uppercase shadow-inner"
                        >
                          {(item.clientName || item.title || 'CL')
                            .split(' ')
                            .map((n) => n[0])
                            .slice(0, 2)
                            .join('')}
                        </div>
                      )}

                      <div className="text-left overflow-hidden">
                        <div className={`font-bold text-xs sm:text-sm truncate ${
                          brand.lightMode ? 'text-slate-900' : 'text-neutral-100'
                        }`}>
                          {item.clientName || item.title}
                        </div>
                        <div className="text-[11px] text-neutral-500 truncate">
                          {item.clientRole || item.subtitle || 'Verified Client'}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>
        );

      case 'features':
        return (
          <section
            key={sec.id}
            id="features"
            onClick={() => onSectionClick?.(sec.id)}
            className={`py-20 cursor-pointer transition-all ${selectionBorder} ${
              brand.lightMode ? 'bg-white text-slate-900' : 'bg-neutral-900 text-neutral-100'
            }`}
          >
            <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center max-w-2xl mx-auto mb-16">
                <h2 className={`text-2xl sm:text-4xl font-bold tracking-tight mb-4 ${headingFontClass}`}>
                  {sec.title}
                </h2>
                {sec.subtitle && (
                  <p className={`text-sm sm:text-base ${brand.lightMode ? 'text-slate-600' : 'text-neutral-400'} ${bodyFontClass}`}>
                    {sec.subtitle}
                  </p>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {(sec.items || []).map((feat, idx) => (
                  <div
                    key={feat.id || idx}
                    className={`p-6 sm:p-8 border ${
                      brand.lightMode
                        ? 'bg-slate-50/50 border-slate-200/80 hover:border-slate-300'
                        : 'bg-neutral-950/60 border-neutral-800 hover:border-neutral-700'
                    } ${roundedClass}`}
                  >
                    <div
                      style={{ color: brand.accentColor }}
                      className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center mb-4"
                    >
                      <Sparkles className="w-5 h-5" />
                    </div>
                    <h3 className={`text-lg font-bold mb-2 ${headingFontClass}`}>{feat.title}</h3>
                    <p className={`text-xs sm:text-sm leading-relaxed ${brand.lightMode ? 'text-slate-600' : 'text-neutral-400'} ${bodyFontClass}`}>
                      {feat.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </section>
        );

      default:
        return null;
    }
  };

  return (
    <div className={`w-full min-h-screen ${brand.lightMode ? 'bg-white text-slate-900' : 'bg-neutral-950 text-neutral-100'} selection:bg-amber-400/20`}>
      {/* CLIENT BRANDED NAVBAR (ZERO MONEY MAKING EMPIRE LOGOS HERE) */}
      <nav
        className={`sticky top-0 z-30 border-b backdrop-blur-md transition-colors ${
          brand.lightMode
            ? 'bg-white/90 border-slate-200/80 text-slate-900'
            : 'bg-neutral-950/90 border-neutral-800 text-neutral-100'
        }`}
      >
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          {/* Logo / Brand Name */}
          <div 
            onClick={() => {
              const home = pages.find((p) => p.isHome) || pages[0];
              if (home) onNavigatePage?.(home.id);
            }}
            className="flex items-center gap-3 cursor-pointer hover:opacity-90 transition-opacity"
          >
            {brand.logoUrl ? (
              <img src={brand.logoUrl} alt={business.name} className="h-8 w-auto object-contain" />
            ) : (
              <span className={`text-lg sm:text-xl font-bold tracking-tight ${headingFontClass}`}>
                {business.name}
              </span>
            )}
          </div>

          {/* Desktop Navigation Links */}
          <div className="hidden md:flex items-center gap-1 sm:gap-2 text-xs sm:text-sm">
            {pages.map((page) => {
              const isActive = page.id === currentPage.id;
              return (
                <button
                  key={page.id}
                  type="button"
                  onClick={() => onNavigatePage?.(page.id)}
                  className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
                    isActive
                      ? brand.lightMode 
                        ? 'bg-slate-100 font-bold text-slate-950'
                        : 'bg-neutral-800 text-white font-bold'
                      : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-white'
                  }`}
                >
                  {page.title}
                </button>
              );
            })}
          </div>

          {/* Right Action Buttons */}
          <div className="flex items-center gap-3">
            {business.phone && (
              <a
                href={`tel:${business.phone}`}
                className="hidden sm:inline-flex items-center gap-1.5 font-semibold text-xs text-neutral-600 dark:text-neutral-300 hover:text-neutral-900 dark:hover:text-white"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>{business.phone}</span>
              </a>
            )}
            <button
              type="button"
              onClick={() => {
                const contactPage = pages.find((p) => p.id === 'page-contact' || p.slug === '/contact');
                if (contactPage && onNavigatePage) {
                  onNavigatePage(contactPage.id);
                } else {
                  const el = document.getElementById('contact');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }
              }}
              style={{ backgroundColor: brand.primaryColor }}
              className={`px-4 py-2 font-semibold text-white shadow-sm hover:opacity-95 transition-all text-xs ${btnRoundedClass}`}
            >
              Get In Touch
            </button>

            {/* Mobile Hamburger Toggle */}
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Dropdown Drawer */}
        {mobileMenuOpen && (
          <div className={`md:hidden border-b px-4 py-3 space-y-2 animate-in slide-in-from-top-2 duration-200 ${
            brand.lightMode ? 'bg-white border-slate-200 text-slate-900' : 'bg-neutral-900 border-neutral-800 text-neutral-100'
          }`}>
            <div className="space-y-1">
              {pages.map((page) => (
                <button
                  key={page.id}
                  type="button"
                  onClick={() => {
                    onNavigatePage?.(page.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full text-left px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                    page.id === currentPage.id
                      ? brand.lightMode
                        ? 'bg-slate-100 font-bold text-slate-900'
                        : 'bg-neutral-800 text-white font-bold'
                      : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-white'
                  }`}
                >
                  {page.title}
                </button>
              ))}
            </div>

            {business.phone && (
              <div className="pt-2 border-t border-neutral-800">
                <a
                  href={`tel:${business.phone}`}
                  className="flex items-center gap-2 px-3 py-2 text-sm text-neutral-300 hover:text-white"
                >
                  <Phone className="w-4 h-4 text-emerald-400" />
                  <span>Call {business.phone}</span>
                </a>
              </div>
            )}
          </div>
        )}
      </nav>

      {/* RENDER ALL SECTIONS OF THE CURRENT ACTIVE PAGE */}
      <div className="w-full">
        {currentPage.sections.map((sec) => (
          <div key={sec.id} className="relative group/sec">
            {selectedSectionId === sec.id && interactive && (
              <div className="absolute top-4 left-4 z-30 pointer-events-none flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500 text-neutral-950 text-xs font-bold shadow-xl border border-amber-300 animate-in fade-in slide-in-from-top-1">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Ask AI to edit this section</span>
              </div>
            )}
            {renderSection(sec)}
          </div>
        ))}
      </div>

      {/* CLIENT FOOTER */}
      <footer
        className={`py-12 border-t text-xs ${
          brand.lightMode
            ? 'bg-slate-100 border-slate-200 text-slate-600'
            : 'bg-neutral-950 border-neutral-900 text-neutral-500'
        }`}
      >
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <div className={`font-bold text-sm mb-1 ${headingFontClass} ${brand.lightMode ? 'text-slate-900' : 'text-neutral-300'}`}>
                {business.name}
              </div>
              <div>© {new Date().getFullYear()} {business.name}. All rights reserved.</div>
            </div>

            {/* Footer Multi-Page Links */}
            <div className="flex flex-wrap items-center gap-4 text-xs">
              {pages.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => onNavigatePage?.(p.id)}
                  className={`transition-colors hover:underline ${
                    p.id === currentPage.id
                      ? brand.lightMode ? 'text-slate-950 font-bold' : 'text-white font-bold'
                      : 'text-neutral-500 hover:text-neutral-300'
                  }`}
                >
                  {p.title}
                </button>
              ))}
            </div>
          </div>

          <div className="pt-4 border-t border-neutral-800/40 flex flex-wrap items-center justify-between gap-4 text-xs text-neutral-500">
            <div>
              {business.location && <span>Location: {business.location}</span>}
              {business.businessHours && <span> · Hours: {business.businessHours}</span>}
            </div>
            {business.email && <div>Email: {business.email}</div>}
          </div>
        </div>
      </footer>

      {/* 24/7 AI BUSINESS CHATBOT (OPTIONAL / CONFIGURABLE) */}
      {project.chatbot?.enabled !== false && (
        <WebsiteChatbotWidget
          config={project.chatbot}
          business={business}
          brandPrimaryColor={brand.primaryColor}
          projectId={project.id}
          previewMode={interactive}
        />
      )}
    </div>
  );
};
