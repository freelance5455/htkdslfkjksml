export type ChatbotTone = 
  | 'professional' 
  | 'friendly' 
  | 'luxury' 
  | 'concise' 
  | 'helpful' 
  | 'casual';

export type ChatbotPosition = 'bottom-right' | 'bottom-left';

export type ChatbotIconStyle = 'message-circle' | 'sparkles' | 'headset' | 'bot';

export interface ConversionButtonsConfig {
  callNow: boolean;
  whatsapp: boolean;
  bookAppointment: boolean;
  requestQuote: boolean;
  contactUs: boolean;
  visitLocation: boolean;
}

export interface ChatbotConfig {
  enabled: boolean;
  businessName: string;
  businessDescription: string;
  servicesSummary?: string;
  faqs?: { question: string; answer: string }[];
  businessHours?: string;
  location?: string;
  contactPhone?: string;
  contactEmail?: string;
  whatsapp?: string;
  bookingUrl?: string;
  tone: ChatbotTone;
  customGreeting: string;
  welcomeMessage: string;
  color: string;
  iconStyle: ChatbotIconStyle;
  position: ChatbotPosition;
  buttonLabel?: string;
  suggestedQuestions: string[];
  conversionButtons: ConversionButtonsConfig;
  leadCapturePrompt?: string;
}

export interface ChatbotLead {
  id: string;
  projectId: string;
  websiteName: string;
  date: string;
  name: string;
  email: string;
  phone: string;
  whatsapp?: string;
  interestedService?: string;
  message?: string;
  status: 'new' | 'contacted' | 'closed';
  source: 'chatbot';
}

export interface ChatMessage {
  id: string;
  role: 'assistant' | 'user';
  content: string;
  timestamp: string;
  suggestedQuestions?: string[];
  isLeadCard?: boolean;
}

export interface ChatbotConversation {
  id: string;
  projectId: string;
  websiteName: string;
  date: string;
  updatedAt: string;
  status: 'active' | 'completed' | 'lead_captured';
  messagesCount: number;
  lead?: ChatbotLead;
  requestedService?: string;
  messages: ChatMessage[];
}

export interface ChatbotAnalytics {
  totalConversations: number;
  activeConversations: number;
  leadsCaptured: number;
  conversionEvents: number;
}
