export type ProjectStatus =
  | 'draft'
  | 'demo'
  | 'client_review'
  | 'approved'
  | 'ready_to_deploy'
  | 'live';

export type BrandStyle =
  | 'Luxury'
  | 'Modern'
  | 'Minimal'
  | 'Corporate'
  | 'Bold'
  | 'Elegant'
  | 'Editorial'
  | 'Friendly'
  | 'Technology'
  | 'Premium Local Business';

export type WebsiteType =
  | 'Landing Page'
  | 'Business Website'
  | 'Service Business'
  | 'Local Business'
  | 'Agency'
  | 'Restaurant'
  | 'Real Estate'
  | 'Medical/Dental'
  | 'Law Firm'
  | 'Accounting'
  | 'Fitness'
  | 'Beauty/Salon'
  | 'E-commerce'
  | 'Portfolio'
  | 'Consultant'
  | 'SaaS'
  | 'Other';

export type PrimaryGoal =
  | 'Generate calls'
  | 'Generate WhatsApp messages'
  | 'Generate leads'
  | 'Book appointments'
  | 'Sell products'
  | 'Get quote requests'
  | 'Build credibility'
  | 'Showcase portfolio'
  | 'Other';

export interface BusinessInfo {
  name: string;
  industry: string;
  description: string;
  location: string;
  phone: string;
  email: string;
  whatsapp: string;
  websiteUrl: string;
  socialUrls: {
    instagram?: string;
    linkedin?: string;
    facebook?: string;
    twitter?: string;
  };
  businessHours: string;
  services: string[];
  products: string[];
  targetAudience: string;
  primaryGoal: PrimaryGoal;
}

export interface BrandConfig {
  logoUrl?: string;
  primaryColor: string; // e.g. '#0f172a' or '#0d9488'
  secondaryColor: string; // e.g. '#334155'
  accentColor: string; // e.g. '#d97706' or '#3b82f6'
  fontPairing: 'modern' | 'luxury' | 'editorial' | 'clean' | 'technical';
  style: BrandStyle;
  borderRadius: 'none' | 'subtle' | 'rounded';
  lightMode: boolean; // default true for client websites or false depending on style
}

export type ImageOrigin = 'client_upload' | 'ai_generated' | 'stock_licensed' | 'placeholder';

export type ImageAspectRatio = '16:9' | '4:3' | '1:1' | '21:9' | '3:4' | 'auto';
export type ImageFocalPoint = 'center' | 'top' | 'bottom' | 'left' | 'right';

export interface ImageMetadata {
  url: string;
  altText: string;
  origin: ImageOrigin;
  prompt?: string;
  license?: string;
  dimensions?: string;
  fileSize?: string;
  format?: 'jpg' | 'jpeg' | 'png' | 'webp' | 'svg';
  aspectRatio?: ImageAspectRatio;
  focalPoint?: ImageFocalPoint;
  isPlaceholder?: boolean;
}

export interface GalleryImageItem {
  id: string;
  url: string;
  altText: string;
  caption?: string;
  origin: ImageOrigin;
  aspectRatio?: ImageAspectRatio;
  isPlaceholder?: boolean;
}

export type SectionType =
  | 'hero'
  | 'services'
  | 'features'
  | 'about'
  | 'process'
  | 'testimonials'
  | 'pricing'
  | 'faq'
  | 'contact'
  | 'cta-banner'
  | 'portfolio'
  | 'gallery'
  | 'location-map';

export type LayoutVariant =
  | 'centered'
  | 'split-left'
  | 'split-right'
  | 'grid-3'
  | 'grid-4'
  | 'cards-with-icons'
  | 'accordion'
  | 'timeline'
  | 'boxed'
  | 'minimal';

export interface CTAButton {
  label: string;
  link: string; // e.g. '#contact', 'tel:+1...', 'https://wa.me/...'
  type: 'primary' | 'secondary' | 'outline' | 'whatsapp' | 'call';
  icon?: 'phone' | 'whatsapp' | 'arrow' | 'calendar' | 'mail' | 'check';
}

export interface SectionItem {
  id: string;
  title: string;
  subtitle?: string;
  description: string;
  badge?: string;
  icon?: string;
  price?: string;
  features?: string[];
  clientName?: string;
  clientRole?: string;
  rating?: number;
  imageUrl?: string;
  imageAlt?: string;
  imageOrigin?: ImageOrigin;
  isPlaceholder?: boolean;
}

export interface WebsiteSection {
  id: string;
  type: SectionType;
  title: string;
  subtitle?: string;
  kicker?: string;
  content?: string;
  layoutVariant: LayoutVariant;
  ctaPrimary?: CTAButton;
  ctaSecondary?: CTAButton;
  items?: SectionItem[];
  imageUrl?: string;
  imageAlt?: string;
  imageOrigin?: ImageOrigin;
  imageAspectRatio?: ImageAspectRatio;
  imageFocalPoint?: ImageFocalPoint;
  isImagePlaceholder?: boolean;
  galleryImages?: GalleryImageItem[];
  backgroundColor?: 'default' | 'surface' | 'accent-subtle' | 'dark';
  isVisible: boolean;
  order: number;
}

export interface SEOConfig {
  pageTitle: string;
  metaDescription: string;
  ogTitle: string;
  ogDescription: string;
  ogImage: string;
  canonicalUrl: string;
  robots: string; // 'index, follow'
  businessCategory: string;
  serviceArea: string;
  structuredDataJson?: string;
}

export interface WebsitePage {
  id: string;
  title: string;
  slug: string;
  isHome: boolean;
  sections: WebsiteSection[];
  seo: SEOConfig;
}

export interface DeploymentConfig {
  provider: 'vercel' | 'cloudflare' | 'netlify' | 'custom' | 'manual';
  customDomain: string;
  deploymentUrl: string;
  verified: boolean;
  httpsActive: boolean;
  lastDnsCheck?: string;
  dnsStatus: 'not_configured' | 'pending' | 'propagated' | 'error';
  dnsRecords: {
    type: 'A' | 'CNAME' | 'TXT';
    name: string;
    value: string;
    ttl: string;
    status: 'detected' | 'pending' | 'mismatch';
  }[];
}

export interface QualityMetricCheck {
  id: string;
  title: string;
  category: 'Performance' | 'SEO' | 'Accessibility' | 'Mobile' | 'Conversion';
  status: 'pass' | 'warning' | 'fail' | 'not_checked';
  scoreImpact: number;
  description: string;
  fixAction?: string;
}

export interface QualityReport {
  overallScore: number;
  performanceScore: number;
  seoScore: number;
  accessibilityScore: number;
  mobileScore: number;
  conversionScore: number;
  checks: QualityMetricCheck[];
  lastAudited: string;
}

import {
  ChatbotConfig,
  ChatbotTone,
  ChatbotPosition,
  ChatbotIconStyle,
  ChatbotLead,
  ChatbotConversation,
  ChatMessage,
  ChatbotAnalytics,
  ConversionButtonsConfig,
} from './chatbot';

export type {
  ChatbotConfig,
  ChatbotTone,
  ChatbotPosition,
  ChatbotIconStyle,
  ChatbotLead,
  ChatbotConversation,
  ChatMessage,
  ChatbotAnalytics,
  ConversionButtonsConfig,
};

export interface ProjectVersion {
  id: string;
  versionNumber: number;
  timestamp: string;
  label: string;
  summary?: string;
  snapshot: any; // Serialized WebsiteProject snapshot
}

export interface AIPromptHistoryItem {
  id: string;
  prompt: string;
  timestamp: string;
  businessName?: string;
  industry?: string;
}

export interface WebsiteProject {
  id: string;
  name: string;
  clientName: string;
  status: ProjectStatus;
  createdAt: string;
  updatedAt: string;
  business: BusinessInfo;
  brand: BrandConfig;
  type: WebsiteType;
  pages: WebsitePage[];
  activePageId: string;
  deployment: DeploymentConfig;
  qualityReport?: QualityReport;
  internalNotes?: string;
  chatbot?: ChatbotConfig;
  versionHistory?: ProjectVersion[];
  aiConversationHistory?: {
    id: string;
    role: 'user' | 'assistant';
    content: string;
    timestamp: string;
    actionApplied?: string;
    targetSectionId?: string;
  }[];
}

export interface AssetItem {
  id: string;
  name: string;
  url: string;
  altText: string;
  category: 'logo' | 'hero' | 'service' | 'team' | 'facility' | 'gallery' | 'other';
  dimensions?: string;
  fileSize?: string;
  format?: 'jpg' | 'jpeg' | 'png' | 'webp' | 'svg';
  origin: ImageOrigin;
  prompt?: string;
  license?: string;
  aspectRatio?: ImageAspectRatio;
  createdAt: string;
}

export interface ClientHandoffSummary {
  projectName: string;
  clientName: string;
  businessName: string;
  liveUrl: string;
  customDomain: string;
  status: ProjectStatus;
  primaryContact: {
    phone: string;
    email: string;
    whatsapp: string;
  };
  domainSetup: {
    status: string;
    provider: string;
    nameserversOrRecords: string;
  };
  httpsStatus: string;
  maintenanceNotes: string[];
  brandPalette: {
    primary: string;
    secondary: string;
    accent: string;
    fonts: string;
  };
}
