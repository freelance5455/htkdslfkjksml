import { ImageAspectRatio, ImageFocalPoint, ImageOrigin } from '../types/website';

export interface OptimizedImageResult {
  dataUrl: string;
  width: number;
  height: number;
  dimensions: string;
  fileSize: string;
  format: 'jpg' | 'jpeg' | 'png' | 'webp' | 'svg';
  aspectRatio: ImageAspectRatio;
}

/**
 * Client-side image optimizer using HTML5 Canvas.
 * Compresses large client camera uploads down to responsive web dimensions (max 1920px),
 * preventing localStorage overflow and ensuring lightning-fast load times.
 */
export async function optimizeClientImageUpload(
  file: File,
  maxDimension = 1920,
  quality = 0.85
): Promise<OptimizedImageResult> {
  const format = file.type.includes('svg')
    ? 'svg'
    : file.type.includes('webp')
    ? 'webp'
    : file.type.includes('png')
    ? 'png'
    : 'jpeg';

  // SVG files are vectors, preserve as text data URL without rasterizing
  if (format === 'svg') {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const text = e.target?.result as string;
        resolve({
          dataUrl: text,
          width: 800,
          height: 600,
          dimensions: 'Vector SVG',
          fileSize: `${(file.size / 1024).toFixed(1)} KB`,
          format: 'svg',
          aspectRatio: '16:9',
        });
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  // Raster image compression via Canvas
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        if (width > maxDimension || height > maxDimension) {
          if (width > height) {
            height = Math.round((height * maxDimension) / width);
            width = maxDimension;
          } else {
            width = Math.round((width * maxDimension) / height);
            height = maxDimension;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Canvas context not available'));
          return;
        }

        // Draw image
        ctx.drawImage(img, 0, 0, width, height);

        // Determine optimal aspect ratio
        const ratio = width / height;
        let aspectRatio: ImageAspectRatio = '16:9';
        if (Math.abs(ratio - 16 / 9) < 0.2) aspectRatio = '16:9';
        else if (Math.abs(ratio - 4 / 3) < 0.15) aspectRatio = '4:3';
        else if (Math.abs(ratio - 1) < 0.15) aspectRatio = '1:1';
        else if (Math.abs(ratio - 21 / 9) < 0.25) aspectRatio = '21:9';
        else if (Math.abs(ratio - 3 / 4) < 0.15) aspectRatio = '3:4';

        // Export as WebP or JPEG
        const outputMime = 'image/webp';
        const dataUrl = canvas.toDataURL(outputMime, quality);
        const approxSizeKb = (dataUrl.length * 0.75) / 1024;

        resolve({
          dataUrl,
          width,
          height,
          dimensions: `${width}x${height}`,
          fileSize: `${approxSizeKb.toFixed(0)} KB`,
          format: 'webp',
          aspectRatio,
        });
      };
      img.onerror = reject;
      img.src = e.target?.result as string;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export function imageFocalPointToClass(focal?: ImageFocalPoint): string {
  switch (focal) {
    case 'top':
      return 'object-top';
    case 'bottom':
      return 'object-bottom';
    case 'left':
      return 'object-left';
    case 'right':
      return 'object-right';
    case 'center':
    default:
      return 'object-center';
  }
}

export function imageAspectRatioToClass(aspect?: ImageAspectRatio): string {
  switch (aspect) {
    case '16:9':
      return 'aspect-video';
    case '4:3':
      return 'aspect-[4/3]';
    case '1:1':
      return 'aspect-square';
    case '21:9':
      return 'aspect-[21/9]';
    case '3:4':
      return 'aspect-[3/4]';
    case 'auto':
    default:
      return 'aspect-auto';
  }
}

/**
 * Creates an elegant SVG data URL placeholder that looks polished and high-end,
 * clearly communicating that a real client photo belongs here without faking credentials.
 */
export function generateBrandedPlaceholderSvg(
  label = 'Add your business image',
  dimensions = '1200 x 675 (16:9)',
  category = 'Hero Photography Slot',
  lightMode = false
): string {
  const bg = lightMode ? '#f1f5f9' : '#0f172a';
  const gridStroke = lightMode ? '#e2e8f0' : '#1e293b';
  const borderStroke = lightMode ? '#cbd5e1' : '#334155';
  const circleBg = lightMode ? '#ffffff' : '#1e293b';
  const circleStroke = lightMode ? '#94a3b8' : '#475569';
  const textTitle = lightMode ? '#0f172a' : '#f8fafc';
  const textSub = lightMode ? '#64748b' : '#94a3b8';
  const accent = '#d97706';

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="675" viewBox="0 0 1200 675" fill="none">
    <rect width="1200" height="675" fill="${bg}"/>
    <defs>
      <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
        <path d="M 40 0 L 0 0 0 40" fill="none" stroke="${gridStroke}" stroke-width="1"/>
      </pattern>
    </defs>
    <rect width="1200" height="675" fill="url(#grid)" />
    <rect x="40" y="40" width="1120" height="595" rx="16" fill="none" stroke="${borderStroke}" stroke-width="2" stroke-dasharray="8 8"/>
    
    <!-- Central Badge -->
    <g transform="translate(600, 310)">
      <circle r="44" fill="${circleBg}" stroke="${circleStroke}" stroke-width="2"/>
      <path d="M -16 -8 L 0 -24 L 16 -8 M -16 8 L 0 24 L 16 8 M -24 0 L 24 0" stroke="${accent}" stroke-width="3" stroke-linecap="round"/>
      <text y="75" text-anchor="middle" font-family="system-ui, -apple-system, sans-serif" font-size="22" font-weight="700" fill="${textTitle}" letter-spacing="0.5">${label}</text>
      <text y="105" text-anchor="middle" font-family="system-ui, -apple-system, sans-serif" font-size="14" font-weight="500" fill="${textSub}">${category} · Recommended ${dimensions}</text>
      <text y="130" text-anchor="middle" font-family="ui-monospace, monospace" font-size="11" font-weight="600" fill="${accent}" letter-spacing="1">CLICK TO UPLOAD OR GENERATE WITH AI</text>
    </g>
  </svg>`;

  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}
