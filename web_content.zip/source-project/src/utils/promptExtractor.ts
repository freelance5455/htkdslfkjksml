/**
 * Prompt Extractor & Client Context Engine
 * Ensures the CURRENT USER PROMPT is the absolute, untampered source of truth for business generation.
 * Prevents any hardcoded default client ("Apex Strategic Solutions", "Aura Dental", or previous project)
 * or stale industry state from overriding the user's intended business.
 */

import { WebsiteProject, WebsiteSection, WebsitePage, BrandStyle } from '../types/website';

export interface ExtractedClientContext {
  businessName: string;
  hasCustomName: boolean;
  industry: string;
  location: string;
  services: string[];
  style: BrandStyle;
  websiteType: string;
  primaryGoal: string;
  hasWhatsApp: boolean;
  hasChatbot: boolean;
  hasMenu: boolean;
  hasBooking: boolean;
  hasCall: boolean;
  phone: string;
  email: string;
  websiteUrl: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  fontPairing: 'luxury' | 'modern' | 'editorial' | 'clean' | 'technical';
  lightMode: boolean;
  requestedSections: string[];
}

export function extractClientContextFromPrompt(
  prompt: string,
  clientInfo?: any
): ExtractedClientContext {
  const p = (prompt || '').trim();
  const lower = p.toLowerCase();

  // 1. EXTRACT BUSINESS NAME
  let businessName = '';
  let hasCustomName = false;

  // First priority: Quoted names in prompt, e.g. "Skyline 27" or 'Skyline 27'
  const quotedMatch = p.match(/["']([A-Za-z0-9][A-Za-z0-9'&.\s\-]{1,40}?)["']/);
  if (quotedMatch && quotedMatch[1]) {
    const candidate = quotedMatch[1].trim();
    const commonWords = ['luxury', 'modern', 'website', 'business', 'restaurant', 'clinic', 'minimal', 'dark', 'light'];
    if (!commonWords.includes(candidate.toLowerCase())) {
      businessName = candidate;
      hasCustomName = true;
    }
  }

  // Second priority: Specific named / called / for patterns
  if (!businessName) {
    const namePatterns = [
      // "website for Skyline 27, a rooftop lounge"
      // "restaurant website for Skyline 27"
      // "website for Royal Spice Restaurant in London"
      /(?:website|site|landing page|presence)\s+for\s+(?:a\s+[\w\s]+\s+)?['"]?([A-Z0-9][A-Za-z0-9'&.\s\-]+?)['"]?(?:\s+in\s+|,|\.|\s+with\b|\s+that\b|\s+offering\b|\s+services\b|\s+a\s+modern\b|\s+a\s+luxury\b|\s+a\s+rooftop\b|\s+a\s+boutique\b|\s+a\s+premier\b|\band\b|$|\n)/i,
      // "named Skyline 27" or "called Skyline 27"
      /(?:named|called)\s+['"]?([A-Z0-9][A-Za-z0-9'&.\s\-]+?)['"]?(?:\s+in\s+|,|\.|\s+with\b|\s+a\b|$|\n)/i,
      // "business name: Skyline 27"
      /(?:business name|client name|brand name)[:\s]+['"]?([A-Z0-9][A-Za-z0-9'&.\s\-]+?)['"]?(?:,|\.|$|\n)/i,
      // "restaurant Skyline 27" or "lounge Skyline 27"
      /(?:restaurant|lounge|bistro|cafe|clinic|firm|studio|agency)\s+['"]?([A-Z0-9][A-Za-z0-9'&.\s\-]+?)['"]?(?:\s+in\s+|,|\.|\s+with\b|$|\n)/i,
      // "for Skyline 27"
      /(?:for|about)\s+['"]?([A-Z0-9][A-Za-z0-9'&.\s\-]+?)['"]?(?:\s+in\s+|,|\.|\s+with\b|\s+offering\b|\s+services\b|$|\n)/i,
    ];

    for (const pattern of namePatterns) {
      const match = p.match(pattern);
      if (match && match[1]) {
        let candidate = match[1].trim();
        candidate = candidate.replace(/[,\.:;]$/, '').trim();
        candidate = candidate.replace(/^(a|an|the)\s+/i, '');
        const stopWords = ['website', 'business', 'landing page', 'company', 'client', 'firm', 'portfolio', 'restaurant', 'clinic', 'agency', 'luxury', 'modern'];
        if (candidate.length >= 2 && !stopWords.includes(candidate.toLowerCase())) {
          businessName = candidate;
          hasCustomName = true;
          break;
        }
      }
    }
  }

  // Fallback to explicit clientInfo if user provided it in fields and prompt had no name
  if (!businessName && clientInfo?.businessName && typeof clientInfo.businessName === 'string' && clientInfo.businessName.trim()) {
    businessName = clientInfo.businessName.trim();
    hasCustomName = true;
  }

  // 2. EXTRACT LOCATION
  let location = '';
  const locMatch = p.match(/\b(?:in|at|based in|located in|serving|around)\s+([A-Z][a-zA-Z\s]+?)(?:[,\.]|\s+with|\s+offering|\s+services|\s+that|\s+and|$|\n)/i);
  if (locMatch && locMatch[1]) {
    const candidateLoc = locMatch[1].trim().replace(/[,\.]$/, '').trim();
    if (candidateLoc.length > 2 && !['A', 'An', 'The', 'Our', 'My'].includes(candidateLoc)) {
      location = candidateLoc;
    }
  }
  if (!location && clientInfo?.location) {
    location = clientInfo.location;
  }

  // 3. EXTRACT SERVICES
  let services: string[] = [];
  const servMatch = p.match(/(?:services include|they offer|offering|services:|specializing in|features:?)\s+([^.]+)/i);
  if (servMatch && servMatch[1]) {
    services = servMatch[1]
      .split(/,|\band\b|;|\+/)
      .map(s => s.trim())
      .filter(s => s.length > 2 && !['and', 'etc', 'more', 'also'].includes(s.toLowerCase()))
      .map(s => s.charAt(0).toUpperCase() + s.slice(1));
  }

  // 4. INDUSTRY & NICHE CLASSIFICATION (THE PROMPT IS THE PRIMARY SOURCE OF TRUTH)
  let industry = '';
  let websiteType = 'Business Website';
  let style: BrandStyle = 'Modern';
  let fontPairing: ExtractedClientContext['fontPairing'] = 'modern';
  let primaryColor = '#0f172a';
  let secondaryColor = '#1e293b';
  let accentColor = '#d97706';
  let lightMode = true;
  let primaryGoal = 'Generate leads';

  if (lower.includes('restaur') || lower.includes('dining') || lower.includes('food') || lower.includes('cafe') || lower.includes('bistro') || lower.includes('cuisine') || lower.includes('lounge') || lower.includes('bar') || lower.includes('steakhouse')) {
    industry = lower.includes('rooftop') ? 'Rooftop Fine Dining & Lounge' : lower.includes('indian') ? 'Modern Indian Gastronomy' : 'Contemporary Fine Dining';
    websiteType = 'Restaurant';
    style = 'Editorial';
    fontPairing = 'editorial';
    primaryColor = '#121214';
    secondaryColor = '#1e1e24';
    accentColor = '#eab308';
    lightMode = false;
    primaryGoal = 'Book appointments';
    if (services.length === 0) {
      services = ['Chef’s Tasting Menu', 'Private Dining & Events', 'Artisanal Beverage Program'];
    }
  } else if (lower.includes('dent') || lower.includes('oral') || lower.includes('teeth') || lower.includes('orthodont') || lower.includes('smile')) {
    industry = 'Cosmetic & Restorative Dentistry';
    websiteType = 'Medical/Dental';
    style = 'Luxury';
    fontPairing = 'luxury';
    primaryColor = '#0a192f';
    secondaryColor = '#112240';
    accentColor = '#c5a059';
    lightMode = false;
    primaryGoal = 'Book appointments';
    if (services.length === 0) {
      services = ['Comprehensive Dental Exam', 'Cosmetic Veneers', 'Dental Implants'];
    }
  } else if (lower.includes('wealth') || lower.includes('family office') || lower.includes('private equity') || lower.includes('asset management') || lower.includes('investment')) {
    industry = 'Private Wealth Advisory & Family Office';
    websiteType = 'Financial Services';
    style = 'Luxury';
    fontPairing = 'luxury';
    primaryColor = '#0a192f';
    secondaryColor = '#1e293b';
    accentColor = '#c5a059';
    lightMode = false;
    primaryGoal = 'Book appointments';
    if (services.length === 0) {
      services = ['Discretionary Portfolio Management', 'Multigenerational Wealth Planning', 'Alternative Asset Allocation'];
    }
  } else if (lower.includes('roof') || lower.includes('contract') || lower.includes('plumb') || lower.includes('electric') || lower.includes('hvac') || lower.includes('siding')) {
    industry = 'Architectural Roofing & Exterior Solutions';
    websiteType = 'Local Business';
    style = 'Premium Local Business';
    fontPairing = 'clean';
    primaryColor = '#0f172a';
    secondaryColor = '#1e293b';
    accentColor = '#ea580c';
    lightMode = true;
    primaryGoal = 'Get quote requests';
    if (services.length === 0) {
      services = ['Residential Roofing Replacement', 'Commercial Roof Systems', 'Comprehensive Inspections'];
    }
  } else if (lower.includes('real estate') || lower.includes('property') || lower.includes('homes') || lower.includes('villa') || lower.includes('realtor')) {
    industry = 'Residential Real Estate & Estates';
    websiteType = 'Real Estate';
    style = 'Luxury';
    fontPairing = 'luxury';
    primaryColor = '#0f172a';
    secondaryColor = '#1e293b';
    accentColor = '#d4af37';
    lightMode = false;
    primaryGoal = 'Generate leads';
    if (services.length === 0) {
      services = ['Exclusive Property Listings', 'Private Buyer Representation', 'Architectural Valuations'];
    }
  } else if (lower.includes('law') || lower.includes('legal') || lower.includes('attorney') || lower.includes('counsel') || lower.includes('litigation')) {
    industry = 'Corporate & Commercial Litigation';
    websiteType = 'Law Firm';
    style = 'Corporate';
    fontPairing = 'modern';
    primaryColor = '#0b132b';
    secondaryColor = '#1c2541';
    accentColor = '#3a86ff';
    lightMode = true;
    primaryGoal = 'Generate calls';
    if (services.length === 0) {
      services = ['Commercial Dispute Resolution', 'Corporate Regulatory Advisory', 'Confidential Consultation'];
    }
  } else if (lower.includes('gym') || lower.includes('fitness') || lower.includes('workout') || lower.includes('athletic')) {
    industry = 'Boutique Functional Movement & Athletic Training';
    websiteType = 'Fitness';
    style = 'Bold';
    fontPairing = 'clean';
    primaryColor = '#09090b';
    secondaryColor = '#18181b';
    accentColor = '#06b6d4';
    lightMode = false;
    primaryGoal = 'Book appointments';
  } else if (lower.includes('agency') || lower.includes('design studio') || lower.includes('branding') || lower.includes('marketing agency')) {
    industry = 'Boutique Creative & Brand Studio';
    websiteType = 'Agency';
    style = 'Modern';
    fontPairing = 'modern';
    primaryColor = '#0f172a';
    secondaryColor = '#1e293b';
    accentColor = '#6366f1';
    lightMode = true;
    primaryGoal = 'Generate leads';
  } else if (lower.includes('tech') || lower.includes('saas') || lower.includes('software') || lower.includes('digital') || lower.includes('ai')) {
    industry = 'Digital Innovation & Enterprise Systems';
    websiteType = 'Technology';
    style = 'Technology';
    fontPairing = 'technical';
    primaryColor = '#030712';
    secondaryColor = '#111827';
    accentColor = '#06b6d4';
    lightMode = false;
    primaryGoal = 'Generate leads';
  } else {
    // Only use clientInfo.industry if prompt had no industry signals
    industry = clientInfo?.industry || 'Specialized Professional Services';
    if (services.length === 0) {
      services = ['Diagnostic Consultation', 'Turnkey Implementation', 'Dedicated Client Advisory'];
    }
  }

  // 5. COLOR PREFERENCES EXPLICITLY MENTIONED
  if (lower.includes('gold') || lower.includes('champagne')) {
    accentColor = '#c5a059';
  } else if (lower.includes('copper') || lower.includes('bronze')) {
    accentColor = '#d97706';
  } else if (lower.includes('blue') || lower.includes('navy')) {
    primaryColor = '#0a192f';
    secondaryColor = '#1e293b';
  } else if (lower.includes('green') || lower.includes('emerald')) {
    accentColor = '#10b981';
  }

  if (lower.includes('dark') || lower.includes('moody') || lower.includes('black')) {
    lightMode = false;
  } else if (lower.includes('light') || lower.includes('clean white')) {
    lightMode = true;
  }

  // 6. DETECT CTAS & SECTIONS
  const hasWhatsApp = lower.includes('whatsapp') || Boolean(clientInfo?.whatsapp);
  const hasChatbot = lower.includes('chatbot') || lower.includes('chat') || lower.includes('24/7');
  const hasMenu = lower.includes('menu') || lower.includes('dishes') || lower.includes('food') || websiteType === 'Restaurant';
  const hasBooking = lower.includes('booking') || lower.includes('appointment') || lower.includes('reservation');
  const hasCall = lower.includes('call') || lower.includes('phone');

  const requestedSections: string[] = ['hero'];
  if (hasMenu) requestedSections.push('menu');
  if (services.length > 0) requestedSections.push('services');
  requestedSections.push('about');
  requestedSections.push('contact');

  // Fallback business name if user didn't specify one:
  // MUST NEVER BE "Apex Strategic Solutions"
  if (!businessName) {
    businessName = '[Business Name]';
    hasCustomName = false;
  }

  return {
    businessName,
    hasCustomName,
    industry,
    location,
    services,
    style,
    websiteType,
    primaryGoal,
    hasWhatsApp,
    hasChatbot,
    hasMenu,
    hasBooking,
    hasCall,
    phone: clientInfo?.phone || '',
    email: clientInfo?.email || '',
    websiteUrl: clientInfo?.websiteUrl || '',
    primaryColor,
    secondaryColor,
    accentColor,
    fontPairing,
    lightMode,
    requestedSections,
  };
}

/**
 * Validates that the generated project strictly uses the user's prompt business name
 * and propagates it everywhere, removing any stale or foreign default client.
 */
export function enforceClientIdentity(
  project: any,
  prompt: string,
  clientInfo?: any
): any {
  return validateAndSanitizeProject(project, prompt, clientInfo);
}

/**
 * Automated post-generation validation and sanitization engine.
 * Guarantees that stale templates, demo businesses, or previous project state
 * NEVER leak into the newly generated website.
 */
export function validateAndSanitizeProject(
  project: WebsiteProject,
  prompt: string,
  clientInfo?: any
): WebsiteProject {
  if (!project) return project;

  const extracted = extractClientContextFromPrompt(prompt, clientInfo);
  const targetBusinessName = extracted.hasCustomName
    ? extracted.businessName
    : project.business?.name && project.business.name !== 'Apex Strategic Solutions' && !project.business.name.includes('Aura Dental')
    ? project.business.name
    : 'Premier Atelier';

  const targetIndustry = extracted.industry || project.business?.industry || 'Professional Services';
  const targetLocation = extracted.location || project.business?.location || '';

  // Deep clone
  const sanitized: WebsiteProject = JSON.parse(JSON.stringify(project));

  // 1. Enforce business facts
  sanitized.business = sanitized.business || ({} as any);
  sanitized.business.name = targetBusinessName;
  sanitized.business.industry = targetIndustry;
  if (targetLocation) sanitized.business.location = targetLocation;
  if (extracted.services.length > 0) {
    sanitized.business.services = extracted.services;
  }

  // 2. Project metadata
  sanitized.name = `${targetBusinessName} Website`;
  sanitized.clientName = targetBusinessName;

  // Stale demo business patterns to purge
  const STALE_DEMO_NAMES = [
    /Apex Strategic Solutions/gi,
    /Apex Solutions/gi,
    /Aura Private Dental & Aesthetics/gi,
    /Aura Dental & Aesthetics Demo/gi,
    /Aura Private Dental Clinic/gi,
    /Aura Dental/gi,
    /Dr\. Evelyn Vance/gi,
    /Vanguard Counsel Partners LLP/gi,
    /Vanguard Counsel/gi,
    /Komorebi Dining & Lounge/gi,
    /Komorebi Contemporary Dining/gi,
    /Komorebi Dining/gi,
    /Ironclad Roofing & Exteriors LLC/gi,
    /Ironclad Roofing/gi,
    /Kite & Catalyst Brand Studio/gi,
    /Kite & Catalyst/gi,
    /Synapse Data Systems Inc\./gi,
    /Synapse Engine/gi,
  ];

  // Industry-specific cross-contamination keywords
  const isRestaurant = targetIndustry.toLowerCase().includes('dining') || targetIndustry.toLowerCase().includes('restaurant');
  const isDental = targetIndustry.toLowerCase().includes('dental') || targetIndustry.toLowerCase().includes('dentist');
  const isWealth = targetIndustry.toLowerCase().includes('wealth') || targetIndustry.toLowerCase().includes('investment');
  const isRoofing = targetIndustry.toLowerCase().includes('roof');

  // Purge text helper
  const purgeStaleText = (text: string): string => {
    if (!text || typeof text !== 'string') return text;
    let result = text;
    for (const pattern of STALE_DEMO_NAMES) {
      result = result.replace(pattern, targetBusinessName);
    }

    // Cross-industry decontamination
    if (isRestaurant) {
      result = result.replace(/dental operatory|clinical sanctuary|porcelain restorations|dental implant|cosmetic dentistry|smile design|veneers/gi, 'dining room & culinary kitchen');
      result = result.replace(/private wealth advisory|family office|investment management/gi, 'fine dining hospitality');
      result = result.replace(/standing seam metal roof|shingle replacement|roof inspection/gi, 'seasonal culinary offerings');
    } else if (isDental) {
      result = result.replace(/seasonal tasting menu|culinary experience|hearth bread|sommelier/gi, 'custom smile design');
      result = result.replace(/standing seam metal roof|roofing installation/gi, 'clinical restoration');
    } else if (isWealth) {
      result = result.replace(/porcelain veneers|dental operatory|dental implant/gi, 'private wealth preservation');
      result = result.replace(/seasonal tasting menu|culinary experience/gi, 'bespoke investment strategy');
    } else if (isRoofing) {
      result = result.replace(/porcelain veneers|dental operatory|tasting menu/gi, 'exterior craftsmanship');
    }

    return result;
  };

  // 3. Purge description, email, and website
  if (sanitized.business.description) {
    sanitized.business.description = purgeStaleText(sanitized.business.description);
  }
  if (sanitized.business.email?.includes('auradental') || sanitized.business.email?.includes('apexsolutions') || sanitized.business.email?.includes('vanguard')) {
    sanitized.business.email = `concierge@${targetBusinessName.toLowerCase().replace(/[^a-z0-9]/g, '')}.com`;
  }
  if (sanitized.business.websiteUrl?.includes('auradental') || sanitized.business.websiteUrl?.includes('apexsolutions')) {
    sanitized.business.websiteUrl = `https://${targetBusinessName.toLowerCase().replace(/[^a-z0-9]/g, '')}.com`;
  }

  // 4. Sanitize pages and sections
  if (Array.isArray(sanitized.pages)) {
    sanitized.pages.forEach((page: WebsitePage) => {
      if (page.seo) {
        page.seo.pageTitle = purgeStaleText(page.seo.pageTitle || '');
        if (!page.seo.pageTitle.includes(targetBusinessName)) {
          page.seo.pageTitle = `${targetBusinessName} | ${targetIndustry}`;
        }
        page.seo.ogTitle = targetBusinessName;
        page.seo.businessCategory = targetIndustry;
        if (page.seo.metaDescription) {
          page.seo.metaDescription = purgeStaleText(page.seo.metaDescription);
        }
      }

      if (Array.isArray(page.sections)) {
        page.sections.forEach((sec: WebsiteSection) => {
          if (sec.title) sec.title = purgeStaleText(sec.title);
          if (sec.subtitle) sec.subtitle = purgeStaleText(sec.subtitle);
          if (sec.kicker) sec.kicker = purgeStaleText(sec.kicker);

          // Hero section specific validation
          if (sec.type === 'hero') {
            if (isRestaurant) {
              if (!sec.title || sec.title.includes('smile') || sec.title.includes('precision') || sec.title.includes('Counsel')) {
                sec.title = `Atmospheric Dining & Unrivaled Gastronomy at ${targetBusinessName}.`;
              }
              if (!sec.subtitle || sec.subtitle.includes('dental') || sec.subtitle.includes('wealth')) {
                sec.subtitle = `Seasonal tasting menus, exceptional regional ingredients, and attentive hospitality in a captivating atmosphere.`;
              }
              if (!sec.imageUrl || sec.imageUrl.includes('dental') || sec.imageUrl.includes('roof')) {
                sec.imageUrl = 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1600&q=80';
                sec.imageAlt = `${targetBusinessName} atmospheric dining room`;
              }
            }
          }

          // Section items validation
          if (Array.isArray(sec.items)) {
            sec.items.forEach((item) => {
              if (item.title) item.title = purgeStaleText(item.title);
              if (item.description) item.description = purgeStaleText(item.description);
              if (item.badge) item.badge = purgeStaleText(item.badge);
            });
          }
        });
      }
    });
  }

  // 5. Sanitize chatbot
  if (sanitized.chatbot) {
    sanitized.chatbot.businessName = targetBusinessName;
    sanitized.chatbot.welcomeMessage = `Welcome to ${targetBusinessName}. How can we assist you with our ${targetIndustry.toLowerCase()} services today?`;
    if (sanitized.chatbot.businessDescription) {
      sanitized.chatbot.businessDescription = purgeStaleText(sanitized.chatbot.businessDescription);
    }
  }

  return sanitized;
}
