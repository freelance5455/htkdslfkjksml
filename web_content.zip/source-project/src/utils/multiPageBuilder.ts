import { 
  BusinessInfo, 
  BrandConfig, 
  WebsitePage, 
  WebsiteSection, 
  WebsiteProject,
  SectionItem 
} from '../types/website';

/**
 * Creates rich, context-specific default sections for About, Services, and Contact pages
 * using the extracted/provided business information.
 */
export function createDefaultPagesForBusiness(
  business: BusinessInfo,
  brand: BrandConfig,
  homeSections: WebsiteSection[]
): WebsitePage[] {
  const bizName = business.name || 'Our Company';
  const industry = business.industry || 'Professional Services';
  const location = business.location || '';
  const phone = business.phone || '';
  const email = business.email || '';
  const whatsapp = business.whatsapp || '';

  // 1. HOME PAGE
  const homePage: WebsitePage = {
    id: 'page-home',
    title: 'Home',
    slug: '/',
    isHome: true,
    seo: {
      pageTitle: `${bizName} | Premier ${industry}${location ? ` in ${location}` : ''}`,
      metaDescription: business.description || `Welcome to ${bizName}. Offering industry-leading ${industry} with dedication, precision, and excellence.`,
      ogTitle: `${bizName} - Official Website`,
      ogDescription: business.description || `Premier ${industry} services.`,
      ogImage: homeSections.find((s) => s.imageUrl)?.imageUrl || 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80',
      canonicalUrl: business.websiteUrl || 'https://client-site.com',
      robots: 'index, follow',
      businessCategory: industry,
      serviceArea: location || 'Regional',
    },
    sections: homeSections,
  };

  // 2. ABOUT US PAGE
  const aboutSections: WebsiteSection[] = [
    {
      id: `sec-about-hero-${Date.now()}`,
      type: 'hero',
      title: `About ${bizName}`,
      subtitle: `Dedicated to setting the highest standard in ${industry.toLowerCase()}${location ? ` across ${location}` : ''}. Built on trust, craft, and client-first commitment.`,
      kicker: 'OUR HERITAGE & MISSION',
      layoutVariant: 'centered',
      imageUrl: 'https://images.unsplash.com/photo-1497215728101-856f4ea42174?auto=format&fit=crop&w=1200&q=80',
      imageAlt: `Executive consultation room at ${bizName}`,
      imageOrigin: 'stock_licensed',
      imageAspectRatio: '16:9',
      imageFocalPoint: 'center',
      ctaPrimary: {
        label: 'Schedule a Consultation',
        link: '#contact',
        type: 'primary',
        icon: 'arrow',
      },
      ctaSecondary: {
        label: 'Explore Our Services',
        link: '/services',
        type: 'secondary',
        icon: 'arrow',
      },
      isVisible: true,
      order: 1,
    },
    {
      id: `sec-about-story-${Date.now()}`,
      type: 'about',
      title: 'Our Purpose & Operating Standards',
      subtitle: business.description || `At ${bizName}, we combine deep expertise in ${industry.toLowerCase()} with disciplined execution to deliver exceptional results.`,
      kicker: 'WHO WE ARE',
      layoutVariant: 'split-right',
      imageUrl: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80',
      imageAlt: `${bizName} headquarters`,
      imageOrigin: 'stock_licensed',
      imageAspectRatio: '4:3',
      imageFocalPoint: 'center',
      items: [
        {
          id: 'ab-1',
          title: 'Uncompromising Quality',
          description: `Every engagement with ${bizName} is executed to rigorous specifications with continuous quality checkpoints.`,
          badge: 'Standard',
        },
        {
          id: 'ab-2',
          title: 'Direct Accountability',
          description: 'You work directly with experienced senior professionals who take personal ownership of your outcomes.',
          badge: 'Transparency',
        },
        {
          id: 'ab-3',
          title: `Deep Rooted in ${location || 'Our Community'}`,
          description: `Proudly serving discerning clientele throughout ${location || 'the region'} with enduring local reputation.`,
          badge: 'Integrity',
        },
      ],
      isVisible: true,
      order: 2,
    },
    {
      id: `sec-about-process-${Date.now()}`,
      type: 'process',
      title: 'How We Work Together',
      subtitle: 'A structured, transparent engagement model designed around clear communication and timely delivery.',
      kicker: 'METHODOLOGY',
      layoutVariant: 'timeline',
      items: [
        {
          id: 'pr-1',
          title: '01. Discovery & Analysis',
          description: 'We listen to your specific requirements, audit existing parameters, and formulate a custom action plan.',
          badge: 'Step 1',
        },
        {
          id: 'pr-2',
          title: '02. Tailored Strategy',
          description: 'A bespoke proposal detailing milestones, scope, resource allocation, and anticipated outcomes.',
          badge: 'Step 2',
        },
        {
          id: 'pr-3',
          title: '03. Precision Execution',
          description: 'Disciplined implementation with regular status updates and direct responsiveness to feedback.',
          badge: 'Step 3',
        },
        {
          id: 'pr-4',
          title: '04. Review & Long-Term Support',
          description: 'Comprehensive walkthrough of results, quality verification, and ongoing client care.',
          badge: 'Step 4',
        },
      ],
      isVisible: true,
      order: 3,
    },
    {
      id: `sec-about-cta-${Date.now()}`,
      type: 'cta-banner',
      title: `Experience the ${bizName} Advantage`,
      subtitle: `Speak directly with our team to discuss your goals in ${industry.toLowerCase()}.`,
      kicker: 'GET STARTED TODAY',
      layoutVariant: 'centered',
      ctaPrimary: {
        label: phone ? `Call Us: ${phone}` : 'Contact Our Team',
        link: phone ? `tel:${phone}` : '#contact',
        type: 'call',
        icon: 'phone',
      },
      ctaSecondary: whatsapp ? {
        label: 'Message on WhatsApp',
        link: `https://wa.me/${whatsapp.replace(/[^0-9]/g, '')}`,
        type: 'whatsapp',
        icon: 'whatsapp',
      } : undefined,
      isVisible: true,
      order: 4,
    },
  ];

  const aboutPage: WebsitePage = {
    id: 'page-about',
    title: 'About Us',
    slug: '/about',
    isHome: false,
    seo: {
      pageTitle: `About Us | ${bizName} - ${industry}`,
      metaDescription: `Learn about ${bizName}, our story, mission, and dedication to excellence in ${industry}.`,
      ogTitle: `About ${bizName}`,
      ogDescription: `Learn about our heritage, operating principles, and team.`,
      ogImage: 'https://images.unsplash.com/photo-1497215728101-856f4ea42174?auto=format&fit=crop&w=1200&q=80',
      canonicalUrl: `${business.websiteUrl || 'https://client-site.com'}/about`,
      robots: 'index, follow',
      businessCategory: industry,
      serviceArea: location || 'Regional',
    },
    sections: aboutSections,
  };

  // 3. SERVICES PAGE
  const servicesList = business.services && business.services.length > 0
    ? business.services
    : ['Comprehensive Consultation', 'Premium Implementation', 'Strategic Advisory', 'Ongoing Maintenance & Support'];

  const serviceItems: SectionItem[] = servicesList.map((svc, sIdx) => ({
    id: `svc-full-${sIdx}`,
    title: svc,
    description: `Bespoke ${svc.toLowerCase()} delivered with exacting precision, top-tier materials, and verified performance standards.`,
    badge: `Specialty 0${sIdx + 1}`,
    features: ['Customized roadmap', 'Dedicated lead specialist', 'Milestone guarantees', 'Comprehensive post-service support'],
  }));

  const servicesSections: WebsiteSection[] = [
    {
      id: `sec-services-hero-${Date.now()}`,
      type: 'hero',
      title: 'Our Services & Capabilities',
      subtitle: `Explore the full spectrum of professional ${industry.toLowerCase()} solutions offered by ${bizName}.`,
      kicker: 'PROVEN CAPABILITIES',
      layoutVariant: 'centered',
      imageUrl: 'https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&w=1200&q=80',
      imageAlt: `${bizName} specialized facility`,
      imageOrigin: 'stock_licensed',
      imageAspectRatio: '16:9',
      imageFocalPoint: 'center',
      ctaPrimary: {
        label: 'Request a Service Quote',
        link: '#contact',
        type: 'primary',
        icon: 'arrow',
      },
      isVisible: true,
      order: 1,
    },
    {
      id: `sec-services-grid-${Date.now()}`,
      type: 'services',
      title: 'Comprehensive Solutions',
      subtitle: `Each service is calibrated to deliver tangible value, clear deliverables, and enduring satisfaction.`,
      kicker: 'CORE OFFERINGS',
      layoutVariant: 'grid-3',
      items: serviceItems,
      isVisible: true,
      order: 2,
    },
    {
      id: `sec-services-faq-${Date.now()}`,
      type: 'faq',
      title: 'Frequently Asked Questions',
      subtitle: `Clear answers to common questions regarding our ${industry.toLowerCase()} services and engagement process.`,
      kicker: 'FAQ',
      layoutVariant: 'accordion',
      items: [
        {
          id: 'faq-1',
          title: `How do I begin working with ${bizName}?`,
          description: 'Getting started is seamless. Simply contact us via our form, direct telephone, or WhatsApp to schedule an initial diagnostic conversation.',
        },
        {
          id: 'faq-2',
          title: 'What is the typical turnaround or project duration?',
          description: 'Timelines are established upfront during the initial consultation. We pride ourselves on meeting agreed delivery schedules with zero compromise on quality.',
        },
        {
          id: 'faq-3',
          title: 'Are pricing and terms transparent?',
          description: 'Yes. Every proposal comes with a comprehensive scope breakdown and clear payment terms prior to work commencement.',
        },
      ],
      isVisible: true,
      order: 3,
    },
    {
      id: `sec-services-cta-${Date.now()}`,
      type: 'cta-banner',
      title: 'Ready for Tailored Excellence?',
      subtitle: `Contact our specialist team today for custom quotes and availability.`,
      kicker: 'LET\'S DISCUSS YOUR PROJECT',
      layoutVariant: 'centered',
      ctaPrimary: {
        label: 'Book Consultation',
        link: '#contact',
        type: 'primary',
        icon: 'calendar',
      },
      isVisible: true,
      order: 4,
    },
  ];

  const servicesPage: WebsitePage = {
    id: 'page-services',
    title: 'Services',
    slug: '/services',
    isHome: false,
    seo: {
      pageTitle: `Services | ${bizName} - ${industry}`,
      metaDescription: `Explore our specialized ${industry} services and customized solutions at ${bizName}.`,
      ogTitle: `Services at ${bizName}`,
      ogDescription: `Comprehensive ${industry} services delivered to the highest standard.`,
      ogImage: 'https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&w=1200&q=80',
      canonicalUrl: `${business.websiteUrl || 'https://client-site.com'}/services`,
      robots: 'index, follow',
      businessCategory: industry,
      serviceArea: location || 'Regional',
    },
    sections: servicesSections,
  };

  // 4. CONTACT PAGE
  const contactSections: WebsiteSection[] = [
    {
      id: `sec-contact-hero-${Date.now()}`,
      type: 'hero',
      title: `Contact ${bizName}`,
      subtitle: `We look forward to connecting with you. Reach out via direct phone, WhatsApp, or our secure inquiry form below.`,
      kicker: 'DIRECT COMMUNICATION',
      layoutVariant: 'centered',
      ctaPrimary: phone ? {
        label: `Direct Call: ${phone}`,
        link: `tel:${phone}`,
        type: 'call',
        icon: 'phone',
      } : undefined,
      ctaSecondary: whatsapp ? {
        label: 'WhatsApp Chat',
        link: `https://wa.me/${whatsapp.replace(/[^0-9]/g, '')}`,
        type: 'whatsapp',
        icon: 'whatsapp',
      } : undefined,
      isVisible: true,
      order: 1,
    },
    {
      id: `sec-contact-main-${Date.now()}`,
      type: 'contact',
      title: 'Send Us an Inquiry',
      subtitle: `Our team typically responds within 24 business hours. Confidential, responsive, and direct.`,
      kicker: 'CONNECT TODAY',
      layoutVariant: 'split-right',
      isVisible: true,
      order: 2,
    },
    {
      id: `sec-contact-faq-${Date.now()}`,
      type: 'faq',
      title: 'Contact & Visiting Details',
      subtitle: 'Everything you need to know about our business hours and consultation bookings.',
      kicker: 'OFFICE HOURS & LOCATION',
      layoutVariant: 'accordion',
      items: [
        {
          id: 'cf-1',
          title: 'What are your operating hours?',
          description: business.businessHours || 'Monday through Friday, 9:00 AM to 6:00 PM. Weekend appointments available upon request.',
        },
        {
          id: 'cf-2',
          title: 'Where are you located?',
          description: location ? `Our principal office is located in ${location}. Contact us for precise appointment directions.` : 'We serve regional and national clients with both on-site and remote consultation capabilities.',
        },
        {
          id: 'cf-3',
          title: 'Do you offer emergency or rush requests?',
          description: phone ? `For urgent inquiries, please telephone our direct line at ${phone} for accelerated assistance.` : 'Please note urgency in your inquiry message for prioritized scheduling.',
        },
      ],
      isVisible: true,
      order: 3,
    },
  ];

  const contactPage: WebsitePage = {
    id: 'page-contact',
    title: 'Contact',
    slug: '/contact',
    isHome: false,
    seo: {
      pageTitle: `Contact Us | ${bizName} - ${location || industry}`,
      metaDescription: `Get in touch with ${bizName}. Telephone, email, WhatsApp, and office hours for ${industry} consultations.`,
      ogTitle: `Contact ${bizName}`,
      ogDescription: `Get in touch with our team for prompt assistance.`,
      ogImage: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80',
      canonicalUrl: `${business.websiteUrl || 'https://client-site.com'}/contact`,
      robots: 'index, follow',
      businessCategory: industry,
      serviceArea: location || 'Regional',
    },
    sections: contactSections,
  };

  return [homePage, aboutPage, servicesPage, contactPage];
}

/**
 * Guarantees that any project has a full multi-page architecture with at least
 * Home, About Us, Services, and Contact pages.
 */
export function ensureMultiPageProject(project: WebsiteProject): WebsiteProject {
  if (!project) return project;

  const pages = project.pages || [];
  if (pages.length >= 2) {
    // Already multi-page
    return {
      ...project,
      activePageId: project.activePageId || pages[0].id,
    };
  }

  // Has only 1 page (home). Generate the remaining 3 pages seamlessly!
  const homePage = pages[0] || {
    id: 'page-home',
    title: 'Home',
    slug: '/',
    isHome: true,
    sections: [],
    seo: {
      pageTitle: `${project.business.name} | ${project.business.industry}`,
      metaDescription: project.business.description,
      ogTitle: project.business.name,
      ogDescription: project.business.description,
      ogImage: '',
      canonicalUrl: project.business.websiteUrl || '',
      robots: 'index, follow',
      businessCategory: project.business.industry,
      serviceArea: project.business.location,
    },
  };

  const defaultPages = createDefaultPagesForBusiness(
    project.business,
    project.brand,
    homePage.sections
  );

  return {
    ...project,
    pages: defaultPages,
    activePageId: project.activePageId || 'page-home',
  };
}
