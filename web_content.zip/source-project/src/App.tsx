import React from 'react';
import { ProjectProvider, useProjects } from './context/ProjectContext';
import { AppHeader } from './components/layout/AppHeader';
import { DashboardView } from './components/dashboard/DashboardView';
import { NewWebsiteWizard } from './components/wizard/NewWebsiteWizard';
import { WebsiteEditor } from './components/editor/WebsiteEditor';
import { ProjectsView } from './components/projects/ProjectsView';
import { TemplatesView } from './components/templates/TemplatesView';
import { AssetManagerView } from './components/assets/AssetManagerView';
import { DomainDeploymentView } from './components/deployment/DomainDeploymentView';
import { ClientHandoffView } from './components/handoff/ClientHandoffView';
import { SettingsView } from './components/settings/SettingsView';
import { OfflineIndicator } from './components/common/OfflineIndicator';

const MainAppContent: React.FC = () => {
  const { activeView } = useProjects();

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-['Plus_Jakarta_Sans',sans-serif]">
      <AppHeader />
      <main className={`flex-1 pb-safe ${activeView === 'editor' ? 'flex flex-col min-h-0 overflow-hidden' : ''}`}>
        {activeView === 'dashboard' && <DashboardView />}
        {activeView === 'wizard' && <NewWebsiteWizard />}
        {activeView === 'editor' && <WebsiteEditor />}
        {activeView === 'projects' && <ProjectsView />}
        {activeView === 'templates' && <TemplatesView />}
        {activeView === 'assets' && <AssetManagerView />}
        {activeView === 'deployment' && <DomainDeploymentView />}
        {activeView === 'handoff' && <ClientHandoffView />}
        {activeView === 'settings' && <SettingsView />}
      </main>
      <OfflineIndicator />
    </div>
  );
};

export default function App() {
  return (
    <ProjectProvider>
      <MainAppContent />
    </ProjectProvider>
  );
}
