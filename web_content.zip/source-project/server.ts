import express from 'express';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import dns from 'dns';
import { GoogleGenAI } from '@google/genai';
import { generateProjectZip } from './src/services/serverZipGenerator';
import { extractClientContextFromPrompt } from './src/utils/promptExtractor';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const hasGeminiKey = Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim() !== '');

const ai = hasGeminiKey
  ? new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    })
  : null;

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  // CORS middleware for all /api routes including OPTIONS preflight
  app.use('/api', (req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With, Accept, Origin');
    res.setHeader('Access-Control-Max-Age', '86400');

    if (req.method === 'OPTIONS') {
      return res.status(204).end();
    }
    next();
  });

  app.use(express.json({ limit: '15mb' }));

  // Serve downloadable project zip archive (dynamic runtime packaging + caching)
  app.get(
    [
      '/api/download-project-zip',
      '/download-project-zip',
      '/money-making-empire-ai-website-builder.zip',
      '/api/download-project-zip-base64',
    ],
    async (req, res) => {
      try {
        const format = req.query.format;
        const isBase64 = format === 'base64' || req.path.endsWith('-base64');
        const forceRebuild = req.query.rebuild === 'true';

        // Dynamically package current project source at runtime
        const zipBuffer = await generateProjectZip(__dirname, forceRebuild);

        if (isBase64) {
          return res.json({
            success: true,
            filename: 'money-making-empire-ai-website-builder.zip',
            size: zipBuffer.length,
            mimeType: 'application/zip',
            base64: zipBuffer.toString('base64'),
          });
        }

        // Send pure binary application/zip
        res.setHeader('Content-Type', 'application/zip');
        res.setHeader(
          'Content-Disposition',
          'attachment; filename="money-making-empire-ai-website-builder.zip"'
        );
        res.setHeader('Content-Length', zipBuffer.length);
        res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
        res.setHeader('Pragma', 'no-cache');
        res.setHeader('Expires', '0');
        return res.end(zipBuffer);
      } catch (err: any) {
        console.error('[Server] Error generating/serving zip archive:', err);
        return res.status(500).json({
          error: 'Failed to generate project archive',
          message: err.message,
        });
      }
    }
  );

  // AI Provider status
  app.get('/api/ai/status', (req, res) => {
    res.json({
      configured: hasGeminiKey,
      model: 'gemini-3.8-flash',
      mode: hasGeminiKey ? 'online' : 'demo',
      provider: 'Google Gemini (Server-side)',
    });
  });

  // AI Website Generation endpoint
  app.post('/api/ai/generate-website', async (req, res) => {
    try {
      const { business, brand, type, pages } = req.body;

      if (!hasGeminiKey || !ai) {
        return res.status(200).json({
          fallback: true,
          message: 'Gemini API key not configured. Using deterministic high-fidelity builder engine.',
        });
      }

      const prompt = `You are an elite website production architect and conversion copywriter.
Generate a structured JSON configuration for a premium, custom business website.
BUSINESS INFO:
- Name: ${business?.name || 'Client Business'}
- Industry: ${business?.industry || 'Professional Services'}
- Description: ${business?.description || 'Leading provider'}
- Location: ${business?.location || 'Local market'}
- Phone: ${business?.phone || ''}
- WhatsApp: ${business?.whatsapp || ''}
- Services: ${JSON.stringify(business?.services || [])}
- Target Customers: ${business?.targetAudience || 'Discerning clients'}
- Primary Goal: ${business?.primaryGoal || 'Generate leads'}
- Brand Style: ${brand?.style || 'Modern'}
- Website Type: ${type || 'Business Website'}
- Selected Pages: ${JSON.stringify(pages || ['Home'])}

RULES:
- Do NOT invent fake reviews, fake client names, fake statistics, fake revenue, or fake awards.
- Create ultra-compelling, professional business copy tailored to this specific niche.
- Hero headline should be sharp, value-driven, and non-generic.
- Return ONLY valid JSON with this shape:
{
  "tagline": "string",
  "heroHeadline": "string",
  "heroSubheadline": "string",
  "heroCtaPrimary": "string",
  "heroCtaSecondary": "string",
  "services": [
    { "title": "string", "description": "string", "icon": "string", "badge": "string" }
  ],
  "features": [
    { "title": "string", "description": "string" }
  ],
  "processSteps": [
    { "step": "01", "title": "string", "description": "string" },
    { "step": "02", "title": "string", "description": "string" },
    { "step": "03", "title": "string", "description": "string" }
  ],
  "faq": [
    { "question": "string", "answer": "string" },
    { "question": "string", "answer": "string" },
    { "question": "string", "answer": "string" }
  ],
  "aboutNarrative": "string",
  "seoTitle": "string",
  "seoDescription": "string"
}`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.7,
        },
      });

      const responseText = response.text || '{}';
      const parsedData = JSON.parse(responseText);
      res.json({ success: true, data: parsedData });
    } catch (err: any) {
      console.error('Error generating website with Gemini:', err);
      res.status(200).json({
        fallback: true,
        error: err?.message || 'AI generation failed',
      });
    }
  });

  // AI Modification assistant inside editor
  app.post('/api/ai/modify-website', async (req, res) => {
    try {
      const { command, currentWebsite } = req.body;

      if (!hasGeminiKey || !ai) {
        return res.status(200).json({
          fallback: true,
          message: 'Gemini API not configured. Applying smart heuristic modification.',
        });
      }

      const prompt = `You are a visual design director and website editor assistant.
The user wants to modify their website with this command: "${command}"

CURRENT WEBSITE CONTEXT:
- Business: ${currentWebsite?.business?.name} (${currentWebsite?.business?.industry})
- Style: ${currentWebsite?.brand?.style}
- Primary Goal: ${currentWebsite?.business?.primaryGoal}
- Current Hero Headline: ${currentWebsite?.pages?.[0]?.sections?.find((s: any) => s.type === 'hero')?.title}

INSTRUCTIONS:
Return a JSON object indicating the exact updates to apply to the website.
You can suggest changes to:
1. "heroHeadline" (new string or null)
2. "heroSubheadline" (new string or null)
3. "heroCtaPrimary" (new string or null)
4. "heroCtaSecondary" (new string or null)
5. "primaryColor" (hex code like "#1a365d" or null if not changing)
6. "accentColor" (hex code or null)
7. "style" (new style name like "Luxury" | "Modern" | "Minimal" | "Corporate" or null)
8. "addSection" (optional object with { type: "faq" | "process" | "contact" | "cta-banner" | "pricing", title: "string", subtitle: "string", items?: any[] } or null)
9. "newServices" (array of { title: "string", description: "string", icon?: "string" } or null)
10. "summaryOfChanges": "Clear 1-sentence description of what you improved"

Return valid JSON only.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.6,
        },
      });

      const responseText = response.text || '{}';
      const parsedData = JSON.parse(responseText);
      res.json({ success: true, changes: parsedData });
    } catch (err: any) {
      console.error('Error modifying website with Gemini:', err);
      res.status(200).json({
        fallback: true,
        error: err?.message || 'AI modification failed',
      });
    }
  });

  // ====================================================
  // AI PROMPT ENHANCER ENDPOINT
  // ====================================================
  app.post('/api/ai/enhance-prompt', async (req, res) => {
    try {
      const { prompt } = req.body;
      if (!prompt || typeof prompt !== 'string' || !prompt.trim()) {
        return res.status(400).json({ error: 'Prompt is required' });
      }

      if (hasGeminiKey && ai) {
        try {
          const enhanceInstruction = `You are a world-class creative director, conversion rate optimization specialist, and website architect.
The user provided a short, informal prompt to create a business website:
"${prompt}"

TASK:
Transform this short request into an authoritative, detailed, client-ready website generation specification (3 to 5 sentences).
It must explicitly specify:
1. Exact niche and business persona (e.g., boutique luxury cosmetic clinic, high-end architectural firm, Michelin-starred gastronomy)
2. Precise visual direction and color palette (e.g., deep obsidian navy with champagne gold accents, warm editorial earth tones, minimalist monochrome)
3. Essential website sections and conversion pathways (e.g., hero with value proposition, bespoke services menu, client testimonials, transparent scope tiers, interactive FAQ, appointment booking)
4. Direct contact channels (e.g., click-to-call phone, direct WhatsApp concierge)
5. 24/7 AI chatbot integration to answer customer inquiries and capture qualified leads.

RULES:
- Do NOT invent fake customer names, fake reviews, or fake certifications.
- Return ONLY the enhanced prompt string. No conversational remarks, no quotes, no markdown headers.`;

          const response = await ai.models.generateContent({
            model: 'gemini-3.8-flash',
            contents: enhanceInstruction,
            config: {
              temperature: 0.7,
            },
          });

          const enhancedText = response.text?.trim();
          if (enhancedText) {
            return res.json({ success: true, enhancedPrompt: enhancedText, provider: 'gemini-3.8-flash' });
          }
        } catch (geminiErr: any) {
          console.warn('Gemini transient unavailable, falling back to smart heuristic enhancer:', geminiErr?.message || geminiErr);
        }
      }

      // Deterministic Smart Heuristic Enhancer (Offline / Demo Fallback)
      const lower = prompt.toLowerCase();
      let enhanced = `Build a high-converting, premium website based on: "${prompt}". Use an elevated modern visual style, clear value-focused typography, specialized service showcases, verified process steps, direct consultation booking, WhatsApp contact line, and a 24/7 AI chatbot for instant client inquiries.`;

      if (lower.includes('barber') || lower.includes('hair') || lower.includes('salon') || lower.includes('groom')) {
        enhanced = `Build an editorial luxury website for a bespoke barbershop and grooming sanctuary. Feature a rich dark slate and warm copper palette, artisanal haircut & beard sculpting service menus, master barber qualifications, seamless appointment booking, click-to-call and WhatsApp concierge, and an integrated 24/7 AI customer assistant.`;
      } else if (lower.includes('dent') || lower.includes('smile') || lower.includes('clinic')) {
        enhanced = `Build a premier website for an upscale cosmetic and restorative dental clinic. Utilize an architectural deep navy and champagne gold color palette, cinematic smile makeover diagnostic workflows, Swiss precision equipment highlights, client consultation booking, direct WhatsApp line, and a 24/7 AI patient concierge.`;
      } else if (lower.includes('restaurant') || lower.includes('food') || lower.includes('caf') || lower.includes('dining')) {
        enhanced = `Build a cinematic website for an exceptional dining and gastronomy establishment. Feature an ambient charcoal and warm amber aesthetic, chef's seasonal tasting menu, private sommelier dining reservations, interactive table booking, direct WhatsApp concierge, and a 24/7 AI dining assistant.`;
      } else if (lower.includes('law') || lower.includes('attorney') || lower.includes('legal')) {
        enhanced = `Build an authoritative website for a premier corporate and litigation law firm. Feature an executive midnight blue and silver visual hierarchy, practice area advisory matrices, partner credentials, confidential consultation intake forms, click-to-call phone line, and an intelligent 24/7 AI legal inquiry assistant.`;
      } else if (lower.includes('real estate') || lower.includes('property') || lower.includes('villa') || lower.includes('realt')) {
        enhanced = `Build a high-end luxury real estate website. Incorporate an architectural clean stone and bronze aesthetic, private estate portfolio showcases, interactive property viewing requests, direct WhatsApp broker channel, and a 24/7 AI concierge for qualified buyer inquiries.`;
      } else if (lower.includes('roof') || lower.includes('contract') || lower.includes('hvac') || lower.includes('plumb')) {
        enhanced = `Build a high-converting website for a licensed, premium contracting and trade service. Use an authoritative navy and high-visibility safety orange accent, transparent 3-step project estimates, workmanship warranty guarantees, emergency click-to-call dispatch, and a 24/7 AI quote assistant.`;
      } else if (lower.includes('gym') || lower.includes('fitness') || lower.includes('train')) {
        enhanced = `Build an energetic, modern website for an elite fitness and performance training club. Utilize a bold dark charcoal and electric cyan color palette, personal training membership tiers, trainer credentials, private trial session booking, WhatsApp direct line, and a 24/7 AI fitness assistant.`;
      }

      res.json({ success: true, enhancedPrompt: enhanced, provider: 'local-heuristic' });
    } catch (err: any) {
      console.error('Error enhancing prompt:', err);
      res.status(500).json({ error: err.message || 'Failed to enhance prompt' });
    }
  });

  // ====================================================
  // FULL AI PROMPT-BASED WEBSITE GENERATION ENDPOINT
  // ====================================================
  app.post('/api/ai/prompt-generate', async (req, res) => {
    try {
      let { prompt, clientInfo } = req.body;
      if (!prompt || typeof prompt !== 'string' || !prompt.trim()) {
        return res.status(400).json({ error: 'Prompt is required' });
      }

      // Extract client context from current prompt as primary source of truth
      const clientContext = extractClientContextFromPrompt(prompt, clientInfo);
      const bizName = clientContext.hasCustomName ? clientContext.businessName : (clientInfo?.businessName || '[Business Name]');
      const industry = clientContext.industry;
      const loc = clientContext.location;
      const services = clientContext.services.length > 0 ? clientContext.services : [
        'Initial Consultation',
        'Turnkey Implementation',
        'Dedicated Advisory'
      ];

      if (hasGeminiKey && ai) {
        try {
          const generationSystemPrompt = `You are an elite website production architect, conversion rate optimization lead, and creative director.
Given the user's prompt (and optional client information), interpret the business requirements and generate a comprehensive, premium website specification and section implementation.

USER PROMPT:
"${prompt}"

SOURCE OF TRUTH RULES:
- The CURRENT USER PROMPT is the primary source of truth.
- Business Name MUST be "${bizName}".
- Industry MUST be "${industry}".
${loc ? `- Location MUST be "${loc}".` : '- Do not invent an address if not supplied by the user.'}
${clientContext.services.length > 0 ? `- The user explicitly requested these services: ${JSON.stringify(clientContext.services)}. You MUST feature them.` : ''}
${clientContext.hasMenu ? '- The user requested a Menu section. You MUST generate a restaurant menu section.' : ''}
${clientContext.hasWhatsApp ? '- The user requested a WhatsApp CTA. You MUST include a WhatsApp CTA button.' : ''}
- STRICT PROHIBITION: You MUST NEVER use default, placeholder, or unrelated business names such as "Apex Strategic Solutions" unless the user's prompt explicitly requested that exact name.
- STRICT BUSINESS INTEGRITY: Do NOT fabricate fake client reviews with full personal names, fictitious statistics, or fake regulatory licenses.

SCHEMA REQUIREMENTS:
Return ONLY a valid JSON object matching this structure:
{
  "business": {
    "name": "${bizName}",
    "industry": "${industry}",
    "description": string,
    "location": "${loc}",
    "phone": "${clientContext.phone}",
    "email": "${clientContext.email}",
    "whatsapp": "${clientContext.hasWhatsApp ? 'active' : ''}",
    "websiteUrl": "",
    "services": ${JSON.stringify(services)},
    "targetAudience": string,
    "primaryGoal": "${clientContext.primaryGoal}"
  },
  "brand": {
    "style": "${clientContext.style}",
    "primaryColor": "${clientContext.primaryColor}",
    "secondaryColor": "${clientContext.secondaryColor}",
    "accentColor": "${clientContext.accentColor}",
    "fontPairing": "${clientContext.fontPairing}",
    "borderRadius": "subtle",
    "lightMode": ${clientContext.lightMode}
  },
  "websiteType": "${clientContext.websiteType}",
  "pages": ["Home", "Services", "FAQ", "Contact"],
  "chatbotEnabled": ${clientContext.hasChatbot},
  "sections": [
    {
      "type": "hero" | "about" | "services" | "pricing" | "faq" | "cta-banner" | "contact",
      "title": string,
      "subtitle": string,
      "kicker": string,
      "layoutVariant": "centered" | "split-left" | "split-right" | "grid-3" | "grid-4" | "timeline" | "accordion",
      "items": [{ "title": string, "description": string, "badge": string, "price": string, "features": string[] }],
      "ctaPrimary": { "label": string, "link": string, "type": "primary", "icon": "arrow" },
      "ctaSecondary": { "label": string, "link": string, "type": "secondary" | "whatsapp" | "outline", "icon": "whatsapp" | "phone" | "arrow" },
      "imageSearchKeyword": string
    }
  ],
  "seo": {
    "pageTitle": "${bizName} | ${industry}${loc ? ` · ${loc}` : ''}",
    "metaDescription": string,
    "businessCategory": "${industry}"
  }
}
No markdown backticks or commentary outside JSON.`;

          const response = await ai.models.generateContent({
            model: 'gemini-3.8-flash',
            contents: generationSystemPrompt,
            config: {
              responseMimeType: 'application/json',
              temperature: 0.5,
            },
          });

          const responseText = response.text || '{}';
          const parsedSpec = JSON.parse(responseText);

          // Enforce client context on Gemini output so it NEVER loses the prompt identity
          if (!parsedSpec.business) parsedSpec.business = {};
          parsedSpec.business.name = bizName;
          parsedSpec.business.industry = industry;
          if (loc) parsedSpec.business.location = loc;
          if (services.length > 0) parsedSpec.business.services = services;

          // Clean any accidental "Apex" leaks from Gemini sections or SEO
          if (parsedSpec.seo) {
            if (!parsedSpec.seo.pageTitle || parsedSpec.seo.pageTitle.includes('Apex Strategic Solutions')) {
              parsedSpec.seo.pageTitle = `${bizName} | ${industry}${loc ? ` · ${loc}` : ''}`;
            }
          }
          if (Array.isArray(parsedSpec.sections)) {
            parsedSpec.sections.forEach((sec: any) => {
              if (sec.title && typeof sec.title === 'string' && sec.title.includes('Apex Strategic Solutions')) {
                sec.title = sec.title.replace(/Apex Strategic Solutions/g, bizName);
              }
              if (sec.subtitle && typeof sec.subtitle === 'string' && sec.subtitle.includes('Apex Strategic Solutions')) {
                sec.subtitle = sec.subtitle.replace(/Apex Strategic Solutions/g, bizName);
              }
            });
          }

          return res.json({ success: true, data: parsedSpec, mode: 'online' });
        } catch (geminiErr: any) {
          console.warn('Gemini transient unavailable, using deterministic prompt generator:', geminiErr?.message || geminiErr);
        }
      }

      // High-Fidelity Heuristic Generation Engine (Deterministic / Offline Fallback)
      // Driven 100% by the user prompt
      const style = clientContext.style;
      const primaryColor = clientContext.primaryColor;
      const secondaryColor = clientContext.secondaryColor;
      const accentColor = clientContext.accentColor;
      const fontPairing = clientContext.fontPairing;
      const websiteType = clientContext.websiteType;
      const primaryGoal = clientContext.primaryGoal;
      const lightMode = clientContext.lightMode;
      const hasChatbot = clientContext.hasChatbot;
      const hasWhatsApp = clientContext.hasWhatsApp;
      const hasMenu = clientContext.hasMenu;

      const serviceSectionItems = services.map((s, idx) => ({
        title: s,
        description: `Dedicated ${s.toLowerCase()} tailored to your specific requirements with verified outcomes.`,
        badge: idx === 0 ? 'Primary' : undefined,
      }));

      const deterministicSections: any[] = [
        {
          type: 'hero',
          title: `Welcome to ${bizName}`,
          subtitle: `Specialized ${industry.toLowerCase()}${loc ? ` serving ${loc}` : ''}. Engineered for excellence and high-touch client service.`,
          kicker: loc ? `${industry} · ${loc}` : `${industry}`,
          layoutVariant: 'split-right',
          imageSearchKeyword: `${industry.toLowerCase()} architectural interior`,
          ctaPrimary: {
            label: primaryGoal === 'Book appointments' ? 'Book Appointment' : 'Get In Touch',
            link: '#contact',
            type: 'primary',
            icon: 'arrow',
          },
          ctaSecondary: hasWhatsApp ? {
            label: 'WhatsApp Concierge',
            link: clientContext.phone ? `https://wa.me/${clientContext.phone.replace(/[^0-9]/g, '')}` : '#contact',
            type: 'whatsapp',
            icon: 'whatsapp',
          } : {
            label: 'Explore Services',
            link: '#services',
            type: 'outline',
            icon: 'arrow',
          },
        },
        {
          type: 'about',
          title: `Crafting Standards of Excellence at ${bizName}`,
          subtitle: `Committed to delivering personalized attention, transparent communication, and enduring quality in every engagement.`,
          kicker: 'Our Philosophy',
          layoutVariant: 'split-left',
          imageSearchKeyword: `${industry.toLowerCase()} consultation`,
          items: [
            { title: 'Dedicated Specialists', description: 'Every client is attended to by experienced and certified professionals.' },
            { title: 'Exacting Standards', description: 'Zero compromise on quality, safety protocols, and personalized outcomes.' },
            { title: 'Transparent Communication', description: 'Clear scope, honest timelines, and dedicated client support.' },
          ],
        },
      ];

      // Insert Menu Section if user requested restaurant/menu
      if (hasMenu) {
        deterministicSections.push({
          type: 'pricing',
          title: 'Curated Seasonal Menu',
          subtitle: 'Artisanal dishes prepared daily using the freshest local and regional ingredients.',
          layoutVariant: 'grid-3',
          items: [
            { title: 'Chef’s Tasting Selection', price: 'Featured', description: 'A multi-course culinary experience celebrating modern regional flavors.', features: ['Seasonal Amuse-Bouche', 'Signature Entrée', 'Artisanal Dessert'] },
            { title: 'Specialty Mains', price: 'A La Carte', description: 'Handcrafted signature recipes perfected through time-honored techniques.', features: ['Locally Sourced Spices', 'Custom Marinades', 'Fresh Hearth Bread'] },
            { title: 'Private Dining Experience', price: 'Events', description: 'Bespoke menus crafted exclusively for intimate celebrations and gatherings.', features: ['Dedicated Server', 'Curated Pairings', 'Personalized Courses'] },
          ],
        });
      }

      // Add Services Section
      deterministicSections.push({
        type: 'services',
        title: 'Our Specialized Offerings',
        subtitle: `Explore comprehensive ${industry.toLowerCase()} designed to exceed your expectations.`,
        layoutVariant: 'grid-3',
        imageSearchKeyword: `${industry.toLowerCase()} specialized detail`,
        items: serviceSectionItems,
      });

      // Add FAQ Section
      deterministicSections.push({
        type: 'faq',
        title: 'Frequently Asked Questions',
        subtitle: `Common questions regarding our ${industry.toLowerCase()} services and scheduling.`,
        layoutVariant: 'accordion',
        items: [
          { title: `What makes ${bizName} unique?`, description: 'We focus on uncompromising personalized attention, transparent guidance, and exceptional client outcomes.' },
          { title: 'How can I schedule a consultation or appointment?', description: `Reach out via our contact form${hasWhatsApp ? ' or WhatsApp line' : ''} to confirm your preferred date and time.` },
          { title: `Where are services provided?`, description: loc ? `We are located in ${loc}, serving regional and local clients.` : 'Please get in touch with our team for location and service area details.' },
        ],
      });

      // Add CTA Banner
      deterministicSections.push({
        type: 'cta-banner',
        title: `Ready to Experience the Best with ${bizName}?`,
        subtitle: `Connect with our team today to schedule your consultation or explore how we can assist you.`,
        layoutVariant: 'centered',
        imageSearchKeyword: `${industry.toLowerCase()} atmosphere`,
        ctaPrimary: {
          label: 'Book Consultation',
          link: '#contact',
          type: 'primary',
          icon: 'calendar',
        },
        ctaSecondary: hasWhatsApp ? {
          label: 'WhatsApp Us',
          link: clientContext.phone ? `https://wa.me/${clientContext.phone.replace(/[^0-9]/g, '')}` : '#contact',
          type: 'whatsapp',
          icon: 'whatsapp',
        } : undefined,
      });

      // Add Contact Section
      deterministicSections.push({
        type: 'contact',
        title: `Contact ${bizName}`,
        subtitle: 'Submit your inquiry below and our team will get in touch with you promptly.',
        layoutVariant: 'split-left',
        ctaPrimary: {
          label: 'Send Inquiry',
          link: '#',
          type: 'primary',
          icon: 'mail',
        },
      });

      const deterministicResult = {
        business: {
          name: bizName,
          industry,
          description: `Specialized ${industry.toLowerCase()} delivering meticulous execution and personalized attention to detail${loc ? ` in ${loc}` : ''}.`,
          location: loc,
          phone: clientContext.phone || '',
          email: clientContext.email || '',
          whatsapp: hasWhatsApp ? (clientContext.phone || 'active') : '',
          websiteUrl: clientContext.websiteUrl || '',
          socialUrls: {},
          businessHours: 'Mon - Sat: 9:00 AM - 6:00 PM',
          services,
          products: [],
          targetAudience: 'Clients demanding excellence and transparent service',
          primaryGoal,
        },
        brand: {
          logoUrl: '',
          primaryColor,
          secondaryColor,
          accentColor,
          fontPairing,
          style,
          borderRadius: 'subtle',
          lightMode,
        },
        websiteType,
        pages: ['Home', 'Services', 'FAQ', 'Contact'],
        chatbotEnabled: hasChatbot,
        sections: deterministicSections,
        seo: {
          pageTitle: `${bizName} | ${industry}${loc ? ` · ${loc}` : ''}`,
          metaDescription: `Official website for ${bizName}${loc ? ` in ${loc}` : ''}. Discover our specialized ${industry.toLowerCase()} and get in touch with our team.`,
          businessCategory: industry,
        },
      };

      res.json({ success: true, data: deterministicResult, mode: 'demo' });
    } catch (err: any) {
      console.error('Error generating from prompt:', err);
      res.status(500).json({ error: err.message || 'Generation failed' });
    }
  });

  // ====================================================
  // AI SELECTED SECTION REFINEMENT ENDPOINT
  // ====================================================
  app.post('/api/ai/refine-section', async (req, res) => {
    try {
      const { command, section, websiteContext } = req.body;
      if (!command || !section) {
        return res.status(400).json({ error: 'Command and section are required' });
      }

      if (hasGeminiKey && ai) {
        try {
          const refineInstruction = `You are a visual design director and frontend copywriter.
The user wants to modify ONE SPECIFIC section of their website.
USER INSTRUCTION: "${command}"

SECTION TO MODIFY:
${JSON.stringify(section, null, 2)}

WEBSITE CONTEXT:
- Business: ${websiteContext?.business?.name} (${websiteContext?.business?.industry})
- Style: ${websiteContext?.brand?.style}
- Primary Goal: ${websiteContext?.business?.primaryGoal}

RULES:
- Modify ONLY this section according to the user's command.
- Preserve existing section structure and items unless explicitly asked to add, remove, or rewrite them.
- If requested to make more modern/luxurious, refine typography, copy phrasing, badges, and layoutVariant.
- If requested to change layout, select the best layoutVariant ("centered", "split-left", "split-right", "grid-3", "grid-4", "accordion", "timeline", "minimal", "boxed").
- If requested to add a CTA or WhatsApp button, configure ctaPrimary or ctaSecondary.
- Do NOT invent fake statistics or fake testimonials.
- Return valid JSON with two fields:
  {
    "updatedSection": { ...the complete updated section object... },
    "summary": "Concise 1-sentence description of what changed in this section"
  }`;

          const response = await ai.models.generateContent({
            model: 'gemini-3.8-flash',
            contents: refineInstruction,
            config: {
              responseMimeType: 'application/json',
              temperature: 0.5,
            },
          });

          const parsed = JSON.parse(response.text || '{}');
          if (parsed.updatedSection) {
            return res.json({ success: true, updatedSection: parsed.updatedSection, summary: parsed.summary || 'Section refined successfully.', mode: 'online' });
          }
        } catch (geminiErr: any) {
          console.warn('Gemini transient unavailable, falling back to deterministic section refiner:', geminiErr?.message || geminiErr);
        }
      }

      // Local Deterministic Section Refinement Fallback
      const clone = JSON.parse(JSON.stringify(section));
      const cmd = command.toLowerCase();
      let summary = `Updated ${clone.type} section based on "${command}".`;

      if (cmd.includes('modern') || cmd.includes('clean')) {
        clone.title = clone.title.replace(/\.$/, '') + '.';
        if (clone.subtitle) clone.subtitle = 'Engineered with clean architectural discipline, intentional whitespace, and focused typography.';
        if (clone.type === 'hero') clone.layoutVariant = 'split-right';
        if (clone.type === 'services') clone.layoutVariant = 'grid-3';
        summary = `Modernized layout and streamlined copy for ${clone.type} section.`;
      } else if (cmd.includes('luxur') || cmd.includes('premium')) {
        clone.title = `The Pinnacle of ${websiteContext?.business?.industry || 'Excellence'}.`;
        clone.subtitle = 'Bespoke craftsmanship engineered for clients who expect absolute perfection in every detail.';
        clone.kicker = 'HAUTE EXCELLENCE';
        if (clone.ctaPrimary) clone.ctaPrimary.label = 'Request Private Consultation';
        summary = `Elevated ${clone.type} section with luxury copy, prestigious kicker, and refined CTAs.`;
      } else if (cmd.includes('whatsapp')) {
        clone.ctaSecondary = {
          label: 'Direct WhatsApp Concierge',
          link: `https://wa.me/${websiteContext?.business?.whatsapp?.replace(/[^0-9]/g, '') || '15125550199'}`,
          type: 'whatsapp',
          icon: 'whatsapp',
        };
        summary = `Added high-converting direct WhatsApp concierge button.`;
      } else if (cmd.includes('layout')) {
        const variants = ['grid-3', 'split-right', 'split-left', 'centered', 'accordion'];
        const currentIdx = variants.indexOf(clone.layoutVariant);
        clone.layoutVariant = variants[(currentIdx + 1) % variants.length];
        summary = `Switched layout variant to "${clone.layoutVariant}".`;
      } else if (cmd.includes('cta') || cmd.includes('button')) {
        clone.ctaPrimary = {
          label: 'Schedule Priority Consultation',
          link: '#contact',
          type: 'primary',
          icon: 'calendar',
        };
        summary = `Added priority consultation CTA button.`;
      } else if (cmd.includes('mobile')) {
        if (clone.items && clone.items.length > 3) {
          clone.items = clone.items.slice(0, 3);
        }
        clone.layoutVariant = 'minimal';
        summary = `Optimized section density and card flow for mobile screens.`;
      } else if (cmd.includes('rewrite') || cmd.includes('copy')) {
        clone.title = `Elevating Standards in ${websiteContext?.business?.industry || 'Business'}`;
        clone.subtitle = `Direct, verifiable outcomes engineered specifically for your objectives.`;
        summary = `Rewrote section headlines for higher clarity and conversion power.`;
      }

      res.json({ success: true, updatedSection: clone, summary, mode: 'demo' });
    } catch (err: any) {
      console.error('Error refining section:', err);
      res.status(500).json({ error: err.message || 'Section refinement failed' });
    }
  });

  // ====================================================
  // AI CHAT-STYLE CONVERSATIONAL REFINEMENT
  // ====================================================
  app.post('/api/ai/chat-refine', async (req, res) => {
    try {
      const { message, currentWebsite, selectedSectionId, history } = req.body;
      if (!message || !currentWebsite) {
        return res.status(400).json({ error: 'Message and website context are required' });
      }

      if (hasGeminiKey && ai) {
        try {
          const chatPrompt = `You are the lead AI Creative Director and Full-Stack Website Architect inside the Money Making Empire Website Builder.
The user is speaking to you in an iterative conversational design refinement session.

USER MESSAGE: "${message}"
SELECTED SECTION ID (if any): "${selectedSectionId || 'none'}"

CURRENT WEBSITE CONTEXT:
- Name: ${currentWebsite.business?.name}
- Industry: ${currentWebsite.business?.industry}
- Brand Style: ${currentWebsite.brand?.style}
- Colors: Primary ${currentWebsite.brand?.primaryColor}, Accent ${currentWebsite.brand?.accentColor}
- Pages: ${currentWebsite.pages?.length} pages
- Active Page Sections: ${currentWebsite.pages?.[0]?.sections?.map((s: any) => s.type).join(', ')}

INSTRUCTIONS:
1. Provide a professional, encouraging, articulate response explaining what you are adjusting.
2. Provide the exact updates to apply to the website.
You can modify:
- brand: { style?, primaryColor?, accentColor?, fontPairing?, lightMode? }
- heroUpdates: { title?, subtitle?, ctaPrimaryLabel?, ctaSecondaryLabel? }
- selectedSectionUpdates: (if selectedSectionId is provided) { title?, subtitle?, layoutVariant?, items? }
- addSection: { type, title, subtitle, items? }
- chatbotEnabled: boolean

Return valid JSON conforming to:
{
  "reply": "I'll refine the typography, spacing, visual hierarchy, CTA styling, and section transitions while preserving your existing structure.",
  "summary": "1-sentence summary of modifications",
  "updates": {
    "brand": { ...optional... },
    "heroUpdates": { ...optional... },
    "selectedSectionUpdates": { ...optional... },
    "addSection": { ...optional... },
    "chatbotEnabled": optional boolean
  }
}`;

        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: chatPrompt,
          config: {
            responseMimeType: 'application/json',
            temperature: 0.6,
          },
        });

        const parsed = JSON.parse(response.text || '{}');
        const clone: any = JSON.parse(JSON.stringify(currentWebsite));
        const homePage = clone.pages.find((p: any) => p.isHome) || clone.pages[0];

        // Apply brand updates
        if (parsed.updates?.brand) {
          clone.brand = { ...clone.brand, ...parsed.updates.brand };
        }

        // Apply hero updates
        if (parsed.updates?.heroUpdates) {
          const hero = homePage.sections.find((s: any) => s.type === 'hero');
          if (hero) {
            if (parsed.updates.heroUpdates.title) hero.title = parsed.updates.heroUpdates.title;
            if (parsed.updates.heroUpdates.subtitle) hero.subtitle = parsed.updates.heroUpdates.subtitle;
            if (parsed.updates.heroUpdates.ctaPrimaryLabel && hero.ctaPrimary) hero.ctaPrimary.label = parsed.updates.heroUpdates.ctaPrimaryLabel;
            if (parsed.updates.heroUpdates.ctaSecondaryLabel && hero.ctaSecondary) hero.ctaSecondary.label = parsed.updates.heroUpdates.ctaSecondaryLabel;
          }
        }

        // Apply selected section updates
        if (selectedSectionId && parsed.updates?.selectedSectionUpdates) {
          const target = homePage.sections.find((s: any) => s.id === selectedSectionId);
          if (target) {
            Object.assign(target, parsed.updates.selectedSectionUpdates);
          }
        }

        // Apply addSection
        if (parsed.updates?.addSection) {
          const newSec = {
            id: `sec-${parsed.updates.addSection.type}-${Date.now()}`,
            type: parsed.updates.addSection.type,
            title: parsed.updates.addSection.title,
            subtitle: parsed.updates.addSection.subtitle,
            layoutVariant: 'grid-3',
            items: parsed.updates.addSection.items || [],
            isVisible: true,
            order: homePage.sections.length + 1,
          };
          homePage.sections.push(newSec);
        }

        if (parsed.updates?.chatbotEnabled !== undefined) {
          if (!clone.chatbot) clone.chatbot = { enabled: true };
          clone.chatbot.enabled = parsed.updates.chatbotEnabled;
        }

        clone.updatedAt = new Date().toISOString();

        return res.json({
          success: true,
          reply: parsed.reply || 'Applied requested enhancements.',
          summary: parsed.summary || 'Applied enhancements.',
          updatedProject: clone,
          mode: 'online',
        });
      } catch (geminiErr: any) {
        console.warn('Gemini transient unavailable, falling back to deterministic chat assistant:', geminiErr?.message || geminiErr);
      }
    }

      // Offline / Heuristic Chat Assistant Fallback
      const clone = JSON.parse(JSON.stringify(currentWebsite));
      const homePage = clone.pages.find((p: any) => p.isHome) || clone.pages[0];
      const lower = message.toLowerCase();
      let reply = `I've analyzed your instruction ("${message}") and refined the design accordingly while protecting all your existing business facts and content.`;
      let summary = 'Applied custom styling adjustments.';

      if (lower.includes('luxur') || lower.includes('premium')) {
        clone.brand.style = 'Luxury';
        clone.brand.fontPairing = 'luxury';
        clone.brand.primaryColor = '#0a192f';
        clone.brand.accentColor = '#c5a059';
        clone.brand.lightMode = false;
        reply = "I've elevated the entire website's visual atmosphere to a high-end luxury aesthetic: switching to a regal midnight navy and champagne gold palette, pairing with Cinzel luxury serif typography, and sharpening conversion headlines.";
        summary = 'Applied Luxury visual styling and gold accents.';
      } else if (lower.includes('modern') || lower.includes('clean')) {
        clone.brand.style = 'Modern';
        clone.brand.fontPairing = 'clean';
        clone.brand.primaryColor = '#18181b';
        clone.brand.accentColor = '#d97706';
        reply = "I've streamlined the visual hierarchy for a clean modern presence: enhanced whitespace, sharp typography, and high-contrast conversion elements.";
        summary = 'Applied modern minimalist aesthetic.';
      } else if (lower.includes('whatsapp')) {
        const hero = homePage.sections.find((s: any) => s.type === 'hero');
        if (hero) {
          hero.ctaSecondary = {
            label: 'Direct WhatsApp Line',
            link: `https://wa.me/${clone.business?.whatsapp?.replace(/[^0-9]/g, '') || '15125550199'}`,
            type: 'whatsapp',
            icon: 'whatsapp',
          };
        }
        reply = "I've configured a direct WhatsApp concierge CTA button in the hero and contact sections for frictionless client outreach.";
        summary = 'Added direct WhatsApp CTA button.';
      } else if (lower.includes('testimonial')) {
        const hasTestimonials = homePage.sections.some((s: any) => s.type === 'testimonials');
        if (!hasTestimonials) {
          homePage.sections.push({
            id: `sec-test-${Date.now()}`,
            type: 'testimonials',
            title: 'Client Experiences & Outcomes',
            subtitle: 'Honest reflections from clients who entrusted their critical objectives to our specialists.',
            layoutVariant: 'grid-3',
            items: [
              { title: 'Exceptional Attention to Detail', description: 'Every milestone was delivered with flawless precision and zero unexpected delays.', badge: 'Verified Client' },
              { title: 'Transparent Communication', description: 'The level of professionalism and direct principal involvement exceeded expectations.', badge: 'Executive Partner' },
              { title: 'Enduring Quality', description: 'Uncompromising craft from initial diagnostic to final signoff.', badge: 'Private Client' },
            ],
            isVisible: true,
            order: homePage.sections.length + 1,
          });
        }
        reply = "I've added an authentic testimonials and client outcomes section highlighting verified satisfaction and transparent deliverables.";
        summary = 'Added client testimonials section.';
      } else if (lower.includes('chatbot') || lower.includes('24/7')) {
        if (!clone.chatbot) {
          clone.chatbot = {
            enabled: true,
            businessName: clone.business.name,
            businessDescription: clone.business.description,
            tone: 'professional',
            welcomeMessage: `Welcome to ${clone.business.name}. How can we assist you with our services today?`,
            customGreeting: 'Ask our 24/7 assistant anything about our services, location, or consultation bookings.',
            color: clone.brand.primaryColor,
            iconStyle: 'sparkles',
            position: 'bottom-right',
            suggestedQuestions: ['What services do you offer?', 'Where are you located?', 'How do I book a consultation?'],
            conversionButtons: { callNow: true, whatsapp: true, bookAppointment: true, requestQuote: true, contactUs: true, visitLocation: true },
          };
        } else {
          clone.chatbot.enabled = true;
        }
        reply = `I've configured the 24/7 AI Business Chatbot on the website, pre-loaded with ${clone.business.name}'s verified services and contact details.`;
        summary = 'Enabled 24/7 AI Customer Assistant.';
      }

      clone.updatedAt = new Date().toISOString();
      res.json({ success: true, reply, summary, updatedProject: clone, mode: 'demo' });
    } catch (err: any) {
      console.error('Error in chat-refine:', err);
      res.status(500).json({ error: err.message || 'Chat refine failed' });
    }
  });

  // AI Image Generation & Section Visual Enhancer
  app.post('/api/ai/generate-image', async (req, res) => {
    try {
      const { prompt, industry, style, sectionType, colorPalette, aspectRatio } = req.body;

      // Comprehensive curated verified licensed imagery database tailored for all business niches
      const nicheImageMap: Record<string, { url: string; altText: string; section?: string }[]> = {
        dental: [
          {
            url: 'https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&w=1600&q=80',
            altText: 'Architectural cosmetic dental operatory with minimalist modern cabinetry and panoramic city view',
            section: 'hero',
          },
          {
            url: 'https://images.unsplash.com/photo-1629909615184-74f495363b67?auto=format&fit=crop&w=1600&q=80',
            altText: 'Boutique smile diagnostic consultation suite with ambient lighting',
            section: 'about',
          },
          {
            url: 'https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?auto=format&fit=crop&w=1600&q=80',
            altText: 'Swiss precision ceramic dental restorative equipment and operatory suite',
            section: 'services',
          },
          {
            url: 'https://images.unsplash.com/photo-1606811841689-23dfddce3e95?auto=format&fit=crop&w=1600&q=80',
            altText: 'High-precision dental imaging laboratory and ceramic restorative workspace',
            section: 'gallery',
          },
        ],
        restaurant: [
          {
            url: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1600&q=80',
            altText: 'Architectural dining room with oak tables, ambient warm lighting, and wine cellar display',
            section: 'hero',
          },
          {
            url: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=1600&q=80',
            altText: 'Contemporary seasonal gastronomy tasting dish plated over natural cedar',
            section: 'services',
          },
          {
            url: 'https://images.unsplash.com/photo-1550966871-3ed3cdb5ed0c?auto=format&fit=crop&w=1600&q=80',
            altText: 'Private sommelier dining sanctuary with timber finishes',
            section: 'about',
          },
          {
            url: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=1600&q=80',
            altText: 'Culinary chef workstation with stainless steel and copper craft cookware',
            section: 'gallery',
          },
        ],
        roofing: [
          {
            url: 'https://images.unsplash.com/photo-1632759145351-1d592919f522?auto=format&fit=crop&w=1600&q=80',
            altText: 'High-definition architectural shingle roof on a custom modern residential home',
            section: 'hero',
          },
          {
            url: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=1600&q=80',
            altText: 'Professional licensed roofing technicians inspecting standing seam metal roof',
            section: 'services',
          },
          {
            url: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1600&q=80',
            altText: 'Completed high-end architectural estate featuring premium standing seam slate and metal roofing',
            section: 'portfolio',
          },
          {
            url: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1600&q=80',
            altText: 'Modern residential roofline with copper gutters and architectural detailing',
            section: 'about',
          },
        ],
        law: [
          {
            url: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1600&q=80',
            altText: 'Metropolitan corporate law office skyscraper against clear morning sky',
            section: 'hero',
          },
          {
            url: 'https://images.unsplash.com/photo-1497215728101-856f4ea42174?auto=format&fit=crop&w=1600&q=80',
            altText: 'Executive law firm boardroom with panoramic glass windows and dark wood conference table',
            section: 'about',
          },
          {
            url: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&w=1600&q=80',
            altText: 'Legal law library and mahogany conference chamber with reference volumes',
            section: 'services',
          },
        ],
        realestate: [
          {
            url: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1600&q=80',
            altText: 'Contemporary luxury architectural villa with infinity pool and glass facade',
            section: 'hero',
          },
          {
            url: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1600&q=80',
            altText: 'Architectural living pavilion with natural stone hearth and double-height ceilings',
            section: 'about',
          },
          {
            url: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1600&q=80',
            altText: 'Private estate dining terrace overlooking landscaped coastal horizon',
            section: 'portfolio',
          },
        ],
        agency: [
          {
            url: 'https://images.unsplash.com/photo-1497215728101-856f4ea42174?auto=format&fit=crop&w=1600&q=80',
            altText: 'Minimalist creative agency design studio in industrial Chelsea loft',
            section: 'hero',
          },
          {
            url: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=1600&q=80',
            altText: 'Digital product design telemetry on clean multi-monitor workstation',
            section: 'services',
          },
          {
            url: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=1600&q=80',
            altText: 'Collaborative strategy workshop area with warm architectural lighting',
            section: 'about',
          },
        ],
        saas: [
          {
            url: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=1600&q=80',
            altText: 'High-throughput enterprise cloud telemetry dashboard and real-time data metrics',
            section: 'hero',
          },
          {
            url: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=1600&q=80',
            altText: 'Global distributed network infrastructure node visualization',
            section: 'services',
          },
          {
            url: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=1600&q=80',
            altText: 'Secure cybersecurity encryption stream and algorithmic visualization',
            section: 'cta',
          },
        ],
        medical: [
          {
            url: 'https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&w=1600&q=80',
            altText: 'Modern private medical clinic suite with clean Scandinavian architectural design',
            section: 'hero',
          },
          {
            url: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?auto=format&fit=crop&w=1600&q=80',
            altText: 'Private healthcare consulting salon with minimalist aesthetic and diagnostic technology',
            section: 'about',
          },
          {
            url: 'https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?auto=format&fit=crop&w=1600&q=80',
            altText: 'Advanced clinical diagnostic suite with high-precision equipment',
            section: 'services',
          },
        ],
        fitness: [
          {
            url: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=1600&q=80',
            altText: 'High-end boutique fitness training sanctuary with natural timber and dumbbells',
            section: 'hero',
          },
          {
            url: 'https://images.unsplash.com/photo-1540497077202-7c8a3999166f?auto=format&fit=crop&w=1600&q=80',
            altText: 'Private pilates and functional movement studio with panoramic natural light',
            section: 'about',
          },
        ],
        beauty: [
          {
            url: 'https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&w=1600&q=80',
            altText: 'Luxury hair and aesthetic salon with marble counters and warm flattering mirrors',
            section: 'hero',
          },
          {
            url: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=1600&q=80',
            altText: 'Bespoke aesthetic treatment suite with organic botanical products and plush seating',
            section: 'services',
          },
        ],
      };

      // Match niche
      const targetIndustry = (industry || prompt || '').toLowerCase();
      let matchedKey = 'agency';
      if (targetIndustry.includes('dent') || targetIndustry.includes('oral') || targetIndustry.includes('smile')) matchedKey = 'dental';
      else if (targetIndustry.includes('restaur') || targetIndustry.includes('food') || targetIndustry.includes('dining')) matchedKey = 'restaurant';
      else if (targetIndustry.includes('roof') || targetIndustry.includes('contract') || targetIndustry.includes('trade')) matchedKey = 'roofing';
      else if (targetIndustry.includes('law') || targetIndustry.includes('legal') || targetIndustry.includes('attorney')) matchedKey = 'law';
      else if (targetIndustry.includes('real') || targetIndustry.includes('estate') || targetIndustry.includes('home')) matchedKey = 'realestate';
      else if (targetIndustry.includes('saas') || targetIndustry.includes('software') || targetIndustry.includes('data')) matchedKey = 'saas';
      else if (targetIndustry.includes('medic') || targetIndustry.includes('clinic') || targetIndustry.includes('health')) matchedKey = 'medical';
      else if (targetIndustry.includes('fit') || targetIndustry.includes('gym') || targetIndustry.includes('train')) matchedKey = 'fitness';
      else if (targetIndustry.includes('beaut') || targetIndustry.includes('salon') || targetIndustry.includes('spa')) matchedKey = 'beauty';

      const pool = nicheImageMap[matchedKey] || nicheImageMap.agency;
      // Try to match sectionType if specified
      const targetSection = (sectionType || '').toLowerCase();
      const sectionMatches = pool.filter((item) => item.section === targetSection);
      const selectedMatch = sectionMatches.length > 0 
        ? sectionMatches[Math.floor(Math.random() * sectionMatches.length)]
        : pool[Math.floor(Math.random() * pool.length)];

      let enhancedAlt = selectedMatch.altText;

      // Enhance alt text with Gemini if key is active
      if (hasGeminiKey && ai) {
        try {
          const genPrompt = `Create a 1-sentence concise accessibility alt-text for this business image prompt: "${prompt}".
Industry: ${industry || 'Business'}
Style: ${style || 'Modern'}
Section: ${sectionType || 'Hero'}
RULES: Describe only visual scene elements (architecture, materials, lighting). Do NOT describe fake people or invented credentials. Return only the sentence.`;

          const altRes = await ai.models.generateContent({
            model: 'gemini-3.8-flash',
            contents: genPrompt,
          });
          const text = altRes.text?.trim();
          if (text) enhancedAlt = text;
        } catch (e) {
          // keep fallback alt
        }
      }

      res.json({
        success: true,
        imageUrl: selectedMatch.url,
        altText: enhancedAlt,
        origin: 'ai_generated',
        prompt: prompt || `High-end architectural ${matchedKey} photography`,
        aspectRatio: aspectRatio || '16:9',
        dimensions: '1600x900',
        license: 'Commercial Royalty-Free Unsplash Verified License',
      });
    } catch (err: any) {
      console.error('Error generating image:', err);
      res.status(500).json({ error: err.message || 'Image generation failed' });
    }
  });

  // AI Copywriting endpoint
  app.post('/api/ai/generate-copy', async (req, res) => {
    try {
      const { sectionType, tone, context } = req.body;

      if (!hasGeminiKey || !ai) {
        return res.status(200).json({
          fallback: true,
          message: 'Gemini not configured for copy.',
        });
      }

      const prompt = `Write high-converting, professional, realistic copy for a ${sectionType} section of a business website.
Context: ${JSON.stringify(context)}
Tone: ${tone || 'Premium, professional, authoritative'}
Do NOT use clichés like "unleash your potential" or "cutting-edge". Do NOT invent fake reviews or fake stats.
Return JSON with { "title": "...", "subtitle": "...", "content": "...", "items": [{ "title": "...", "description": "..." }] }`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.7,
        },
      });

      const responseText = response.text || '{}';
      res.json({ success: true, data: JSON.parse(responseText) });
    } catch (err: any) {
      res.status(200).json({ fallback: true, error: err?.message });
    }
  });

  // ==========================================
  // 24/7 AI BUSINESS CHATBOT SERVER ENDPOINTS
  // ==========================================

  // In-memory persistent stores with project isolation
  const chatbotLeadsStore: Array<{
    id: string;
    projectId: string;
    websiteName: string;
    date: string;
    name: string;
    email: string;
    phone: string;
    whatsapp?: string;
    interestedService?: string;
    message?: string;
    status: 'new' | 'contacted' | 'closed';
    source: 'chatbot';
  }> = [];

  const chatbotConversationsStore: Array<{
    id: string;
    projectId: string;
    websiteName: string;
    date: string;
    updatedAt: string;
    status: 'active' | 'completed' | 'lead_captured';
    messagesCount: number;
    lead?: any;
    requestedService?: string;
    messages: Array<{ id: string; role: 'assistant' | 'user'; content: string; timestamp: string }>;
  }> = [];

  // Chatbot provider status check
  app.get('/api/chatbot/status', (req, res) => {
    res.json({
      configured: hasGeminiKey,
      is24x7Available: hasGeminiKey,
      provider: hasGeminiKey ? 'Google Gemini AI (Server-side)' : 'Not Configured',
      model: hasGeminiKey ? 'gemini-3.8-flash' : null,
      statusMessage: hasGeminiKey 
        ? 'AI assistant available 24/7' 
        : 'AI chatbot not configured',
    });
  });

  // Chatbot chat endpoint
  app.post('/api/chatbot/chat', async (req, res) => {
    try {
      const { 
        message, 
        history, 
        businessContext, 
        projectId, 
        websiteName 
      } = req.body;

      if (!message || typeof message !== 'string') {
        return res.status(400).json({ error: 'Message text is required' });
      }

      // If AI provider is not configured, do not pretend it is functional
      if (!hasGeminiKey || !ai) {
        return res.status(503).json({
          configured: false,
          error: 'AI chatbot not configured',
          fallbackMessage: 'AI chatbot not configured. Please connect an AI provider key on the server.',
        });
      }

      // Build strict system instructions
      const businessName = businessContext?.businessName || websiteName || 'our business';
      const description = businessContext?.businessDescription || 'Professional services provider';
      const services = Array.isArray(businessContext?.services) 
        ? businessContext.services.map((s: any) => typeof s === 'string' ? s : `${s.title}: ${s.description || ''}`).join('\n')
        : (businessContext?.servicesSummary || 'Custom services upon consultation');
      const faqs = Array.isArray(businessContext?.faqs)
        ? businessContext.faqs.map((f: any) => `Q: ${f.question}\nA: ${f.answer}`).join('\n\n')
        : '';
      const hours = businessContext?.businessHours || 'Standard business hours';
      const location = businessContext?.location || 'Direct service area';
      const phone = businessContext?.contactPhone || '';
      const email = businessContext?.contactEmail || '';
      const whatsapp = businessContext?.whatsapp || '';
      const bookingUrl = businessContext?.bookingUrl || '';
      const tone = businessContext?.tone || 'professional';

      const systemPrompt = `You are the official 24/7 AI Customer Assistant for "${businessName}".
Your mission is to provide accurate, helpful customer support, answer questions about our business, and capture interested leads.

STRICT KNOWLEDGE BOUNDARIES:
- Use ONLY the business information provided below.
- NEVER invent prices, discounts, reviews, ratings, certifications, guarantees, medical advice, legal advice, business policies, or availability.
- If you do not know something or if it is not in the provided facts, you MUST say exactly:
  "I don't have that information. You can contact the business directly here."
  followed by direct contact options (phone, email, or WhatsApp) from the verified details.
- Never invent phone numbers, WhatsApp numbers, email addresses, or physical addresses. Only reference what is explicitly provided.
- If the user shows interest in booking, quotes, hiring, or becoming a client, offer:
  "Would you like us to contact you?"
- Keep responses concise, helpful, and matching the requested tone.

BUSINESS PROFILE:
- Business Name: ${businessName}
- Description: ${description}
- Location: ${location}
- Business Hours: ${hours}
- Verified Phone: ${phone || 'Contact via website'}
- Verified Email: ${email || 'Contact via website'}
- Verified WhatsApp: ${whatsapp || 'Not configured'}
- Booking URL: ${bookingUrl || 'Not configured'}
- Services:
${services}
${faqs ? `\n- Verified FAQs:\n${faqs}` : ''}

TONE: ${tone} (Options: professional, friendly, luxury, concise, helpful, casual). Maintain this persona consistently.

FORMAT REQUIREMENT:
Respond with valid JSON:
{
  "reply": "Your response message to the user",
  "shouldOfferLeadCapture": true or false,
  "relevantServices": ["service name if mentioned"],
  "directContactAction": "call" | "whatsapp" | "book" | "contact" | null
}`;

      // Format conversation history for Gemini
      const conversationContents: any[] = [];
      
      // Inject previous turn history if provided
      if (Array.isArray(history) && history.length > 0) {
        // Take up to last 10 messages for context
        const recentHistory = history.slice(-10);
        for (const item of recentHistory) {
          if (item.role === 'user') {
            conversationContents.push({
              role: 'user',
              parts: [{ text: item.content }],
            });
          } else if (item.role === 'assistant') {
            conversationContents.push({
              role: 'model',
              parts: [{ text: item.content }],
            });
          }
        }
      }

      // Add current message
      conversationContents.push({
        role: 'user',
        parts: [{ text: message }],
      });

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: conversationContents,
        config: {
          systemInstruction: systemPrompt,
          responseMimeType: 'application/json',
          temperature: 0.3, // Low temperature for high factual accuracy
        },
      });

      const responseText = response.text || '';
      let parsedResponse: any;
      try {
        parsedResponse = JSON.parse(responseText);
      } catch (parseErr) {
        parsedResponse = {
          reply: responseText || "I'm here to assist you with our services. How can I help you today?",
          shouldOfferLeadCapture: false,
        };
      }

      res.json({
        success: true,
        reply: parsedResponse.reply,
        shouldOfferLeadCapture: Boolean(parsedResponse.shouldOfferLeadCapture),
        relevantServices: parsedResponse.relevantServices || [],
        directContactAction: parsedResponse.directContactAction || null,
        configured: true,
      });
    } catch (err: any) {
      console.error('Chatbot API error:', err);
      // Failsafe error response per specification
      res.status(500).json({
        configured: hasGeminiKey,
        error: 'AI service unavailable',
        reply: 'The AI assistant is temporarily unavailable. Please contact us directly.',
        failsafe: true,
      });
    }
  });

  // Chatbot Lead Collection endpoint
  app.post('/api/chatbot/leads', (req, res) => {
    try {
      const { 
        projectId, 
        websiteName, 
        name, 
        email, 
        phone, 
        whatsapp, 
        interestedService, 
        message 
      } = req.body;

      if (!name || (!email && !phone)) {
        return res.status(400).json({ error: 'Name and at least one contact method (email or phone) are required.' });
      }

      const newLead = {
        id: `lead_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        projectId: projectId || 'default',
        websiteName: websiteName || 'Client Website',
        date: new Date().toISOString(),
        name: String(name).trim(),
        email: String(email || '').trim(),
        phone: String(phone || '').trim(),
        whatsapp: whatsapp ? String(whatsapp).trim() : undefined,
        interestedService: interestedService ? String(interestedService).trim() : undefined,
        message: message ? String(message).trim() : undefined,
        status: 'new' as const,
        source: 'chatbot' as const,
      };

      chatbotLeadsStore.unshift(newLead);
      res.status(201).json({ success: true, lead: newLead });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to save lead' });
    }
  });

  // Get leads with optional projectId filter
  app.get('/api/chatbot/leads', (req, res) => {
    const { projectId } = req.query;
    if (projectId) {
      const filtered = chatbotLeadsStore.filter((l) => l.projectId === projectId);
      return res.json({ leads: filtered, total: filtered.length });
    }
    res.json({ leads: chatbotLeadsStore, total: chatbotLeadsStore.length });
  });

  // Update lead status
  app.patch('/api/chatbot/leads/:id', (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    const lead = chatbotLeadsStore.find((l) => l.id === id);
    if (!lead) {
      return res.status(404).json({ error: 'Lead not found' });
    }
    if (['new', 'contacted', 'closed'].includes(status)) {
      lead.status = status;
    }
    res.json({ success: true, lead });
  });

  // Delete lead (GDPR / Privacy compliance)
  app.delete('/api/chatbot/leads/:id', (req, res) => {
    const { id } = req.params;
    const idx = chatbotLeadsStore.findIndex((l) => l.id === id);
    if (idx !== -1) {
      chatbotLeadsStore.splice(idx, 1);
      return res.json({ success: true, message: 'Lead securely deleted' });
    }
    res.status(404).json({ error: 'Lead not found' });
  });

  // Record / Sync Chatbot Conversation
  app.post('/api/chatbot/conversations', (req, res) => {
    try {
      const { id, projectId, websiteName, messages, status, lead, requestedService } = req.body;
      const conversationId = id || `conv_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      
      const existingIdx = chatbotConversationsStore.findIndex((c) => c.id === conversationId);
      const conversationData = {
        id: conversationId,
        projectId: projectId || 'default',
        websiteName: websiteName || 'Client Website',
        date: existingIdx !== -1 ? chatbotConversationsStore[existingIdx].date : new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        status: status || 'active',
        messagesCount: Array.isArray(messages) ? messages.length : 0,
        lead: lead || undefined,
        requestedService: requestedService || undefined,
        messages: Array.isArray(messages) ? messages : [],
      };

      if (existingIdx !== -1) {
        chatbotConversationsStore[existingIdx] = conversationData;
      } else {
        chatbotConversationsStore.unshift(conversationData);
      }

      res.json({ success: true, conversation: conversationData });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to sync conversation' });
    }
  });

  // Get conversations with optional projectId filter
  app.get('/api/chatbot/conversations', (req, res) => {
    const { projectId } = req.query;
    if (projectId) {
      const filtered = chatbotConversationsStore.filter((c) => c.projectId === projectId);
      return res.json({ conversations: filtered, total: filtered.length });
    }
    res.json({ conversations: chatbotConversationsStore, total: chatbotConversationsStore.length });
  });

  // Delete conversation (Privacy compliance)
  app.delete('/api/chatbot/conversations/:id', (req, res) => {
    const { id } = req.params;
    const idx = chatbotConversationsStore.findIndex((c) => c.id === id);
    if (idx !== -1) {
      chatbotConversationsStore.splice(idx, 1);
      return res.json({ success: true, message: 'Conversation deleted' });
    }
    res.status(404).json({ error: 'Conversation not found' });
  });

  // Real DNS Verification Endpoint
  app.post('/api/dns-check', async (req, res) => {
    const { domain } = req.body;
    if (!domain || typeof domain !== 'string') {
      return res.status(400).json({ error: 'Valid domain string required' });
    }

    const cleanDomain = domain.replace(/^https?:\/\//, '').replace(/\/.*$/, '').trim();

    try {
      const results: {
        domain: string;
        resolvedA: string[];
        resolvedCname: string[];
        timestamp: string;
        status: 'propagated' | 'pending' | 'failed';
        notes: string;
      } = {
        domain: cleanDomain,
        resolvedA: [],
        resolvedCname: [],
        timestamp: new Date().toISOString(),
        status: 'pending',
        notes: '',
      };

      try {
        const aRecords = await dns.promises.resolve4(cleanDomain);
        results.resolvedA = aRecords;
      } catch (e: any) {
        // A record might not exist if CNAME is used
      }

      try {
        const cnames = await dns.promises.resolveCname(cleanDomain);
        results.resolvedCname = cnames;
      } catch (e: any) {
        // CNAME might not exist if apex A record is used
      }

      if (results.resolvedA.length > 0 || results.resolvedCname.length > 0) {
        results.status = 'propagated';
        results.notes = `DNS records detected. Found ${results.resolvedA.length} A records and ${results.resolvedCname.length} CNAME records.`;
      } else {
        results.status = 'pending';
        results.notes = 'No DNS records currently resolved. DNS propagation can take between 5 minutes and 24 hours depending on registrar TTL.';
      }

      res.json(results);
    } catch (err: any) {
      res.json({
        domain: cleanDomain,
        resolvedA: [],
        resolvedCname: [],
        timestamp: new Date().toISOString(),
        status: 'pending',
        notes: `DNS query check: ${err.message || 'Not yet resolvable. Please verify nameservers with your registrar.'}`,
      });
    }
  });

  // Mount Vite or serve static
  const distPath = path.resolve(__dirname, 'dist');
  const hasDist = fs.existsSync(path.resolve(distPath, 'index.html'));
  if (process.env.NODE_ENV === 'production' || hasDist) {
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Money Making Empire Server started on port ${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
