PESQUISA 2026 — PROJETO ANDROID

Este é o projeto-fonte Android para abrir o simulador de pesquisa eleitoral em um app.
O APK ainda precisa ser compilado no Android Studio.

COMO GERAR O APK:
1. Instale o Android Studio em um computador.
2. Abra a pasta Pesquisa2026_Android no Android Studio.
3. Aguarde a sincronização do Gradle e a instalação do Android SDK 35, se solicitado.
4. No menu, escolha Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Ao terminar, clique em "locate" para encontrar o arquivo APK.

O app abre a página HTML localmente, sem precisar de internet.
O histórico é salvo no armazenamento local do WebView.

Observação: esta é uma simulação fictícia, não uma pesquisa real nem um produto do Datafolha.
