RentMate Kenya - website files
Upload all five files to the GitHub repository (github.com/anthonykithongo23-collab/rentmate)
or give this folder to a web-to-APK tool. The file index.html must keep that exact name.
Live site: https://anthonykithongo23-collab.github.io/rentmate/
