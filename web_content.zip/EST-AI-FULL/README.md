# EST-AI — Legendary Knowledge Engine (Architecture Edition)

## What is included
- 30 separated JavaScript modules for normalization, intent/entity detection, query rewriting, phrase/keyword/inverted-index/fuzzy matching, geographic disambiguation, relevance, source trust, freshness, deduplication, conflict checks, consensus, evidence, abstention, answer planning/composition/formatting/citations, memory, feedback, and orchestration.
- 50 JSON knowledge pack files under `data/knowledge-01.json` ... `knowledge-50.json`, plus `data/manifest.json`.
- 20 source catalog entries and additional online adapters. Availability/CORS/rate limits vary by provider.
- Chunked JSON/JSONL ingestion utility for large datasets (1,000 records per batch).
- Hard abstention on weak matches and special city/country guard for Alexandria/Egypt/USA.

## Important data-count disclosure
This archive contains a starter corpus, not 500,000 preloaded facts. The manifest reports the actual seed-record count and sets `target_records: 500000` with `target_is_preloaded: false`. Reaching 500k requires importing licensed/open datasets or running controlled ingestion jobs from the listed publishers, checking their terms, attribution, language coverage, duplicates, and record quality. The 50 pack files are physical shards; they do not imply 500k records.

## Running
Serve the folder over HTTP(S); opening `index.html` as `file://` blocks fetch and service-worker behavior.

## Safety / quality
- A result is not promoted to verified knowledge merely because it was generated.
- Feedback tunes source preferences only; it does not rewrite facts.
- Always show source URLs; verify important claims at their original publisher.
- Public APIs may require keys, impose quotas, block browser CORS, or change schemas. A production deployment should proxy them through a backend, rate-limit requests, and cache responses.
- This is a retrieval and rules engine, not a trained language model.
