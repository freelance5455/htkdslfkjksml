(()=>{
 const $=id=>document.getElementById(id),STORE="estai_history_v2",ACTIVE="estai_active_v2";
 const messages=$("messages"),welcome=$("welcome"),input=$("userInput"),form=$("chatForm");
 let busy=false,history=[],current=[];
 const safe=(s)=>String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
 function toast(s){const t=$("toast");t.textContent=s;t.classList.add("show");clearTimeout(toast.timer);toast.timer=setTimeout(()=>t.classList.remove("show"),2500);}
 function saveHistory(){try{localStorage.setItem(STORE,JSON.stringify(history.slice(-40)));}catch{toast("مساحة التخزين ممتلئة؛ لم يتم حفظ السجل.");}}
 function persistActive(){try{if(current.length)localStorage.setItem(ACTIVE,JSON.stringify(current));else localStorage.removeItem(ACTIVE);}catch{}}
 function saveCurrent(){if(!current.length)return;const first=current.find(x=>x.role==="user")?.text||"محادثة جديدة";const item={id:Date.now(),title:first.slice(0,65),date:new Date().toISOString(),messages:current};history.unshift(item);history=history.slice(0,40);saveHistory();renderHistory();localStorage.removeItem(ACTIVE);}
 function switchView(name){document.querySelectorAll(".side-link").forEach(x=>x.classList.toggle("active",x.dataset.view===name));document.querySelectorAll(".view").forEach(x=>x.classList.toggle("active",x.id===name+"View"));$("sidebar").classList.remove("open");}
 function addMessage(role,text,sources=[],meta=""){
  welcome.style.display="none";const wrap=document.createElement("div");wrap.className=`message ${role}`;
  const avatar=document.createElement("div");avatar.className="avatar";avatar.textContent=role==="user"?"أنت":"EST";
  const body=document.createElement("div");body.className="bubble";const content=document.createElement("div");content.innerHTML=ESTResponse.render(text);body.appendChild(content);
  if(sources.length){const list=document.createElement("div");list.className="source-list";sources.forEach(s=>{if(s.url){const a=document.createElement("a");a.className="source-link";a.href=s.url;a.target="_blank";a.rel="noopener noreferrer";a.textContent=s.title;list.appendChild(a);}else{const span=document.createElement("span");span.className="source-link";span.textContent=s.title;list.appendChild(span);}});body.appendChild(list);}
  if(meta){const m=document.createElement("div");m.className="meta-line";m.textContent=meta;body.appendChild(m);}
  if(role==="assistant"){const tools=document.createElement("div");tools.className="message-tools";const copy=document.createElement("button");copy.className="mini-tool";copy.textContent="نسخ الإجابة";copy.addEventListener("click",async()=>{try{await navigator.clipboard.writeText(text);toast("تم نسخ الإجابة");}catch{toast("تعذر النسخ من هذا المتصفح");}});tools.appendChild(copy);if(meta&&meta.includes("تجربة:")&&meta.split("تجربة:")[1].trim()){const expId=meta.split("تجربة:")[1].trim();[ [1,"مفيدة"],[-1,"غير مفيدة"] ].forEach(([rating,label])=>{const vote=document.createElement("button");vote.className="mini-tool";vote.textContent=label;vote.addEventListener("click",async()=>{await ESTKnowledgeStore.rateExperience(expId,rating);vote.textContent=rating>0?"شكراً للتقييم":"تم تسجيل الملاحظة";vote.disabled=true;refreshKnowledge();});tools.appendChild(vote);});}body.appendChild(tools);}
  wrap.append(avatar,body);messages.appendChild(wrap);wrap.scrollIntoView({behavior:"smooth",block:"end"});
 }
 async function answer(query){
  if(busy)return;busy=true;$("sendButton").disabled=true;current.push({role:"user",text:query});persistActive();addMessage("user",query);
  const analysis=ESTAnalyzer.analyze(query);let result=null,meta=[];let remoteRecords=[];
  if(analysis.intent==="calculation"){
   const calc=ESTCalculator.calculate(query);
   if(calc&&!calc.error)result={text:`**نتيجة العملية الحسابية**\n${calc.expression} = **${calc.value}**`,sources:[{title:"محرك الحساب الداخلي",url:null}],confidence:"نتيجة حسابية"};
   else if(calc?.error)result={text:calc.error,sources:[],confidence:"تعذر الحساب"};
  }
  let cached=[];try{cached=await ESTKnowledgeStore.getAll();}catch{}
  const allRecords=ESTRanking.dedupe([...ESTDatabase.all(),...cached]);
  const engineRun=await ESTM.run(query,allRecords);
  const local=engineRun.abstain?[]:engineRun.ranked;
  if(cached.length)meta.push("ذاكرة معرفية تراكمية");
  if(local.length)meta.push("بحث محلي مرتب بحسب تطابق العبارات والكلمات");
  if(!result&&analysis.intent==="compare")result=ESTResponse.compare(local);
  if(!result&&local.length)result=ESTResponse.localAnswer(local);
  if(navigator.onLine&&analysis.intent!=="calculation"){
   try{
    const preferences=await ESTKnowledgeStore.sourcePreferences(query,analysis.intent).catch(()=>({}));const remote=await ESTSearch.online(query,analysis,preferences);remoteRecords=remote.records||[];
    if(remoteRecords.length){
     const remoteAnswer=ESTResponse.onlineAnswer(remoteRecords,analysis);
     if(result){result.text+="\n\n"+remoteAnswer.text;result.sources=ESTRanking.dedupe([...(result.sources||[]),...remoteAnswer.sources].map((x,i)=>({...x,id:ESTAnalyzer.normalize(x.title)}))).map(x=>({title:x.title,url:x.url}));result.confidence="دمج معرفة محلية مع نتائج متعددة؛ يلزم الرجوع للمصادر";}
     else result=remoteAnswer;
     meta.push("بحث متوازٍ عبر "+(remote.successful||[]).length+" من "+(remote.attempted||[]).length+" مصادر");
    }
    if(remote.errors?.length)meta.push("مصادر لم تستجب: "+remote.errors.join("، "));
   }catch(e){meta.push("تعذر إكمال بعض عمليات البحث الخارجية");}
  }
  if(!result)result={text:analysis.intent==="geography"&&analysis.entities?.includes("alexandria")?"الإسكندرية مدينة مصرية وليست دولة، لذلك لا توجد لها عاصمة. هل تقصد عاصمة محافظة الإسكندرية أم عاصمة مصر؟":(navigator.onLine?"لم أعثر على أدلة كافية مرتبطة بسؤالك. لن أخمّن إجابة غير مدعومة؛ حاول إعادة صياغة السؤال أو تحديد المقصود.":"لا توجد معلومة موثوقة كافية في الذاكرة المحلية حالياً. اتصل بالإنترنت أو أضف مصدراً موثوقاً."),sources:[],confidence:"امتناع آمن: لا توجد مطابقة كافية"};
  // الخبرة تحفظ مسار المعالجة ومصادرها وتقييمها، ولا تتحول تلقائياً إلى حقيقة معرفية.
  let experienceId="";try{experienceId=await ESTKnowledgeStore.storeExperience({query,intent:analysis.intent,answer:result.text.slice(0,5000),sourceNames:[...new Set((result.sources||[]).map(x=>x.title.split(" — ")[0]))],confidence:result.confidence,recordIds:remoteRecords.map(x=>x.id).slice(0,20)});}catch{}
  const mode=navigator.onLine?"وضع هجين":"وضع محلي دون إنترنت";
  const detail=`المعالجة: ${meta.join(" + ")||"قواعد محلية"} · ${mode} · ${result.confidence} · تجربة: ${experienceId}`;
  current.push({role:"assistant",text:result.text,sources:result.sources||[],meta:detail,experienceId});persistActive();addMessage("assistant",result.text,result.sources||[],detail);
  busy=false;$("sendButton").disabled=false;input.focus();refreshKnowledge();
 }
 function startNew(){saveCurrent();current=[];messages.innerHTML="";welcome.style.display="block";input.value="";switchView("chat");input.focus();}
 async function renderKnowledge(filter=""){
  const cached=await ESTKnowledgeStore.getAll().catch(()=>[]),all=[...ESTDatabase.all(),...cached];
  const records=all.filter(r=>(r.title+" "+r.category+" "+r.content+" "+(r.keywords||[]).join(" ")).toLowerCase().includes(filter.toLowerCase())).slice(0,300);
  $("knowledgeList").innerHTML=records.length?records.map(r=>`<article class="knowledge-item"><div class="item-main"><b>${safe(r.title)}</b><p>${safe((r.content||"").slice(0,180))}${(r.content||"").length>180?"…":""}</p></div><span class="item-tag">${safe(r.source||r.category||"عام")}</span></article>`).join(""):`<div class="empty-state">لا توجد نتائج مطابقة.</div>`;
 }
 function renderHistory(){
  $("historyList").innerHTML=history.length?history.map(h=>`<article class="history-item"><div class="item-main"><b>${safe(h.title)}</b><p>${new Date(h.date).toLocaleString("ar-EG")} · ${h.messages.length} رسائل</p></div><button class="secondary-button" data-open="${h.id}">فتح</button></article>`).join(""):`<div class="empty-state">لا توجد محادثات محفوظة بعد.</div>`;
  $("historyList").querySelectorAll("[data-open]").forEach(btn=>btn.addEventListener("click",()=>{const item=history.find(h=>String(h.id)===btn.dataset.open);if(!item)return;current=item.messages.slice();messages.innerHTML="";current.forEach(m=>addMessage(m.role,m.text,m.sources||[],m.meta||""));switchView("chat");}));
 }
 function updateStatus(){$("connectionLabel").textContent=navigator.onLine?"متصل · المصادر متاحة":"غير متصل · قاعدة محلية";$("modePill").textContent=navigator.onLine?"الوضع الهجين":"الوضع المحلي";$("statusTitle").textContent=navigator.onLine?"النظام متصل":"النظام يعمل محلياً";$("statusDot").style.background=navigator.onLine?"#18a46b":"#d69b35";}
 function exportFile(name,data,type="application/json"){const blob=new Blob([data],{type}),url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download=name;a.click();URL.revokeObjectURL(url);}
 form.addEventListener("submit",e=>{e.preventDefault();const q=input.value.trim();if(!q||busy)return;input.value="";input.style.height="auto";answer(q);});
 input.addEventListener("input",()=>{input.style.height="auto";input.style.height=Math.min(input.scrollHeight,140)+"px";});
 input.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();form.requestSubmit();}});
 document.querySelectorAll(".suggestion").forEach(b=>b.addEventListener("click",()=>{input.value=b.dataset.prompt;form.requestSubmit();}));
 $("newChat").addEventListener("click",startNew);$("clearButton").addEventListener("click",()=>{saveCurrent();current=[];messages.innerHTML="";welcome.style.display="block";toast("تم إنهاء المحادثة الحالية");});
 $("menuButton").addEventListener("click",()=>$("sidebar").classList.toggle("open"));
 document.querySelectorAll(".side-link").forEach(b=>b.addEventListener("click",()=>switchView(b.dataset.view)));
 $("exportButton").addEventListener("click",()=>{if(!current.length){toast("لا توجد رسائل لتصديرها");return;}exportFile("EST-AI-conversation.txt",current.map(m=>`${m.role==="user"?"المستخدم":"EST-AI"}:\n${m.text}`).join("\n\n"),"text/plain;charset=utf-8");});
 $("knowledgeSearch").addEventListener("input",e=>renderKnowledge(e.target.value));
 $("importJson").addEventListener("change",async e=>{const file=e.target.files[0];if(!file)return;try{
  const raw=JSON.parse(await file.text());let data=Array.isArray(raw)?raw:(Array.isArray(raw.records)?raw.records:(Array.isArray(raw.items)?raw.items:[raw]));
  const normalized=data.map((x,i)=>({id:String(x.id||x.qid||x.key||("import-"+Date.now()+"-"+i)),title:String(x.title||x.label||x.name||"").trim(),category:String(x.category||x.type||"بيانات مستوردة"),keywords:Array.isArray(x.keywords)?x.keywords:(Array.isArray(x.aliases)?x.aliases:[]),content:String(x.content||x.description||x.extract||x.text||"").trim(),facts:x.facts&&typeof x.facts==="object"?x.facts:{},source:String(x.source||"ملف JSON مستورد"),url:x.url||x.uri||null})).filter(x=>x.title&&x.content);
  if(!normalized.length)throw Error("No valid records");
  const n=await ESTKnowledgeStore.putMany(normalized);toast(`تم استيراد ${n.toLocaleString("en-US")} سجل إلى الذاكرة المحلية`);await refreshKnowledge();
 }catch(err){toast("ملف JSON غير صالح أو لا يحتوي حقول عنوان ومحتوى");}e.target.value="";});
 $("exportKnowledge").addEventListener("click",async()=>{const cached=await ESTKnowledgeStore.getAll();exportFile("EST-AI-knowledge.json",JSON.stringify([...ESTDatabase.exportAll(),...cached],null,2));});
 $("syncCountries").addEventListener("click",async()=>{if(!navigator.onLine){toast("اتصل بالإنترنت لتحميل بيانات الدول");return;}const b=$("syncCountries");b.disabled=true;b.textContent="جارٍ تحميل بيانات الدول...";try{const records=await ESTProviders.syncCountries();await ESTKnowledgeStore.putMany(records);toast(`تم حفظ ${records.length} سجلاً جغرافياً محلياً`);await refreshKnowledge();}catch(e){toast("تعذر تحميل الموسوعة حالياً؛ حاول لاحقاً");}finally{b.disabled=false;b.textContent="＋ تحميل موسوعة الدول (250+)";}});
 $("clearOnlineCache").addEventListener("click",async()=>{if(!confirm("سيؤدي ذلك إلى حذف السجلات المكتسبة من البحث وموسوعة الدول من هذا الجهاز. هل تريد المتابعة؟"))return;await ESTKnowledgeStore.clear();await refreshKnowledge();toast("تم مسح الذاكرة المعرفية المكتسبة");});
 $("deleteHistory").addEventListener("click",()=>{if(!confirm("هل تريد حذف سجل المحادثات المحفوظ محلياً؟"))return;history=[];saveHistory();renderHistory();toast("تم حذف السجل");});
 async function refreshKnowledge(){const domains=ESTDatabase.domains(),baseCount=ESTDatabase.all().length,cacheCount=await ESTKnowledgeStore.count().catch(()=>0),count=baseCount+cacheCount,exp=await ESTKnowledgeStore.experienceStats().catch(()=>({count:0,positive:0,negative:0}));$("knowledgeCount").textContent=count;$("knowledgeStats").innerHTML=`<div class="stat-card"><strong>${count.toLocaleString("en-US")}</strong><span>سجلات المعرفة</span></div><div class="stat-card"><strong>${ESTProviders.SOURCES.length}</strong><span>موصلات مصادر خارجية</span></div><div class="stat-card"><strong>${cacheCount.toLocaleString("en-US")}</strong><span>سجلات مكتسبة</span></div><div class="stat-card"><strong>${exp.count.toLocaleString("en-US")}</strong><span>خبرات معالجة محفوظة</span></div><div class="stat-card"><strong>${exp.positive.toLocaleString("en-US")}</strong><span>تقييمات إيجابية</span></div>`;renderKnowledge($("knowledgeSearch").value); }
 window.addEventListener("online",updateStatus);window.addEventListener("offline",updateStatus);
 async function init(){
  await ESTDatabase.load();try{history=JSON.parse(localStorage.getItem(STORE)||"[]");if(!Array.isArray(history))history=[];}catch{history=[];}
  updateStatus();refreshKnowledge();renderHistory();
  if("serviceWorker"in navigator&&location.protocol!=="file:")navigator.serviceWorker.register("./service-worker.js").catch(()=>{});
 }
 init().catch(e=>{console.error(e);toast("تعذر تحميل قاعدة البيانات. شغّل الموقع عبر خادم ويب.");});
})();