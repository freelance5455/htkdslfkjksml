/* Safe arithmetic parser. Never evaluates arbitrary JavaScript. */
window.ESTCalculator=(()=>{
 function calculate(source){
  let s=String(source).replace(/[×x]/gi,"*").replace(/÷/g,"/").replace(/,/g,"").replace(/[^\d.+*/()\-%\s]/g,"").trim();
  if(!s||!/[+\-*/%]/.test(s))return null;
  let i=0;
  function ws(){while(s[i]===" ")i++;}
  function expr(){let v=term();while(true){ws();let op=s[i];if(op!=="+"&&op!=="-")break;i++;let n=term();v=op==="+"?v+n:v-n;}return v;}
  function term(){let v=factor();while(true){ws();let op=s[i];if(!["*","/","%"].includes(op))break;i++;let n=factor();if((op==="/"||op==="%")&&n===0)throw Error("لا يمكن القسمة على صفر");v=op==="*"?v*n:op==="/"?v/n:v%n;}return v;}
  function factor(){ws();let sign=1;if(s[i]==="+")i++;else if(s[i]==="-"){sign=-1;i++;}ws();let v;if(s[i]==="("){i++;v=expr();ws();if(s[i]!==")")throw Error("أقواس غير مكتملة");i++;}else{let start=i;while(i<s.length&&/[0-9.]/.test(s[i]))i++;if(start===i)throw Error("صيغة حسابية غير مكتملة");v=Number(s.slice(start,i));if(!Number.isFinite(v))throw Error("رقم غير صالح");}return sign*v;}
  try{const result=expr();ws();if(i!==s.length||!Number.isFinite(result))return {error:"تعذر فهم العملية الحسابية."};return {value:Number(result.toPrecision(12)),expression:s};}catch(e){return {error:e.message||"عملية غير صالحة"};}
 }
 return {calculate};
})();