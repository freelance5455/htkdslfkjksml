ESTM.memoryRetrieve=async q=>{try{return await ESTKnowledgeStore.search(q,8);}catch{return[];}};
