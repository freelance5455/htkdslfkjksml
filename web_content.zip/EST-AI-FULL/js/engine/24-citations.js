ESTM.citations=rows=>rows.filter(r=>r.url).map(r=>({title:r.source+" — "+r.title,url:r.url}));
