ESTM.plan=(q,rows)=>({intent:ESTM.intent(q),entities:ESTM.entities(q),maxItems:ESTM.intent(q)==="general"?4:6,records:rows});
