ESTM.phraseScore=(q,r)=>{let a=ESTM.normalize(q),t=ESTM.normalize(r.title||"");return a.length>3&&t.includes(a)?30:0;};
