ESTM.memoryWrite=async rows=>{try{return await ESTKnowledgeStore.putMany(rows.filter(r=>r.source&&r.url));}catch{return 0;}};
