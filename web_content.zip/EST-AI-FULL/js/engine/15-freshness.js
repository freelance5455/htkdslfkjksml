ESTM.freshness=r=>r.updatedAt?Math.max(0,1-(Date.now()-r.updatedAt)/(365*86400000*2)):.2;
