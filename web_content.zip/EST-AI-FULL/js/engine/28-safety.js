ESTM.safeAnswer=(q,r)=>({query:q,records:r});
