ESTM.format=s=>String(s||"").trim().replace(/\n{3,}/g,"\n\n");
