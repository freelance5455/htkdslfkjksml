ESTM.keywordScore=(q,r)=>{let ts=ESTM.tokens(q),blob=ESTM.normalize([r.title,r.content,r.category,...(r.keywords||[])].join(" "));return ts.reduce((s,t)=>s+(blob.includes(t)?3:0),0);};
