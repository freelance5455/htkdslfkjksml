ESTM.shouldAbstain=(ranked)=>!ranked.length||ranked[0].score<7||ranked[0].coverage<.34;
