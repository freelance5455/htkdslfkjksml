ESTM.consensus=rows=>{let n=new Set(rows.map(r=>r.source).filter(Boolean)).size;return{sources:n,level:n>=3?"متعدد المصادر":n===2?"مصدران":"مصدر واحد أو أقل"};};
