ESTM.relevance=(q,r)=>ESTM.phraseScore(q,r)+ESTM.keywordScore(q,r)+ESTM.fuzzy(q,r.title)*8;
