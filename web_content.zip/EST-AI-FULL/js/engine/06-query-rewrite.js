ESTM.rewrite=q=>{let n=ESTM.normalize(q);return [...new Set([q,n,...ESTM.tokens(q)])].filter(Boolean);};
