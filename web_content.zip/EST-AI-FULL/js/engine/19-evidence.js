ESTM.evidence=rows=>rows.filter(r=>r.content&&r.source&&r.url);
