ESTM.tokens=s=>ESTM.normalize(s).split(" ").filter(x=>x.length>1&&!ESTM.stop.has(x));
