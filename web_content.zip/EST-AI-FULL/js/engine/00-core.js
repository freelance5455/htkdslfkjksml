window.ESTM=window.ESTM||{}; ESTM.version="2.0"; ESTM.safe=(x)=>String(x??"").normalize("NFKC");
