-- Unser Vorrat: Einkauf -> vorläufiger Bestand (Korrektur)
-- Einmal komplett im Supabase SQL Editor ausführen.

alter table public.shopping_items
  add column if not exists inventory_item_id bigint
  references public.inventory_items(id) on delete set null;

-- Bestehende Daten werden nicht verändert.
-- Die Verknüpfung wird bei neu abgehakten Einkäufen gesetzt.
