SHARON AI — GEMINI CHAT APP

CONTENTS
- index.html: app entry point (required by many HTML-to-APK builders)
- style.css: responsive modern dark theme
- app.js: Gemini API chat, conversation context, voice input, read-aloud
- manifest.json and sw.js: optional PWA support

HOW TO RUN / BUILD APK
1. Extract this ZIP.
2. Open the extracted Sharon_AI_Gemini_App folder in your HTML-to-APK builder.
3. Set the start page / entry file to: index.html
4. Keep index.html, style.css, app.js, manifest.json and sw.js together.
5. Build the APK.
6. Open Sharon AI, tap Settings, paste your Gemini API key, select a model, and Save.
7. Start chatting. Tap the microphone for voice input; use Read aloud for spoken replies.

GEMINI API KEY
Create/manage a key in Google AI Studio: https://aistudio.google.com/app/apikey
The app sends requests to Google's Gemini generateContent API.
The key is stored in this browser/app's local storage. Anyone with access to the app/device may be able to extract it. Do not distribute an APK containing your personal key. For a public app, use your own backend to keep the key secret and apply usage limits.

VOICE NOTES
- Voice input uses the browser's Web Speech API and generally works best in Chrome/WebView versions that support SpeechRecognition.
- Speech recognition may require internet, microphone permission, and a compatible Android WebView.
- Read-aloud uses SpeechSynthesis; voice availability depends on the Android device.
- This is voice input plus spoken responses, not Gemini's native real-time two-way audio conversation.

TROUBLESHOOTING
- If builder says index.html not found: select the extracted project folder, not the ZIP preview; set index.html as the start page.
- If styles/scripts are missing: preserve the folder structure and filenames exactly.
- If API errors occur: verify key, network, model availability, and API quota.
- If microphone does nothing: grant microphone permission to the app and test in Chrome.

SECURITY
This is a client-side demo app. A Gemini API key embedded in a client app cannot be kept secret. Use a secure server proxy before publishing to other users.
