const $=id=>document.getElementById(id);
let messages=[], chats=[], recognition=null, listening=false;
const KEY='sharon_gemini_key', MODEL='sharon_gemini_model', SPEAK='sharon_speak';
$('apiKey').value=localStorage.getItem(KEY)||'';
$('model').value=localStorage.getItem(MODEL)||'gemini-2.5-flash';
$('speakReplies').checked=localStorage.getItem(SPEAK)==='true';
function toast(t){$('toast').textContent=t;$('toast').style.display='block';setTimeout(()=>$('toast').style.display='none',2600)}
function openSettings(){$('settingsModal').classList.add('open')}
$('settingsBtn').onclick=openSettings;$('closeSettings').onclick=()=>$('settingsModal').classList.remove('open');
$('saveSettings').onclick=()=>{localStorage.setItem(KEY,$('apiKey').value.trim());localStorage.setItem(MODEL,$('model').value);localStorage.setItem(SPEAK,$('speakReplies').checked);$('settingsModal').classList.remove('open');toast('Settings saved')};
$('newChat').onclick=()=>{messages=[];$('messages').innerHTML='';$('welcome').style.display='block';$('sidebar').classList.remove('open');};
$('menuBtn').onclick=()=>$('sidebar').classList.toggle('open');
document.querySelectorAll('[data-prompt]').forEach(b=>b.onclick=()=>{ $('prompt').value=b.dataset.prompt;send();});
function addMessage(role,text){$('welcome').style.display='none';const wrap=document.createElement('div');wrap.className='message '+role;const av=document.createElement('div');av.className='avatar';av.textContent=role==='user'?'Y':'✦';const body=document.createElement('div');body.className='bubble';body.textContent=text;wrap.append(av,body);$('messages').append(wrap);$('chatArea').scrollTop=$('chatArea').scrollHeight;return body}
function updateHistory(title){const b=document.createElement('button');b.textContent=title.slice(0,35);b.onclick=()=>toast('Start a new chat to begin another conversation.');$('history').prepend(b)}
async function send(){const text=$('prompt').value.trim();if(!text)return;if(!localStorage.getItem(KEY)){openSettings();toast('Add your Gemini API key first');return}
$('prompt').value='';$('prompt').style.height='auto';addMessage('user',text);messages.push({role:'user',parts:[{text}]});$('sendBtn').disabled=true;
const pending=addMessage('assistant','Thinking…');
try{const model=localStorage.getItem(MODEL)||'gemini-2.5-flash';const url=`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(localStorage.getItem(KEY))}`;
const response=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({contents:messages,generationConfig:{temperature:0.7,maxOutputTokens:2048}})});
const data=await response.json();if(!response.ok)throw new Error(data.error?.message||`API error ${response.status}`);
const answer=data.candidates?.[0]?.content?.parts?.map(p=>p.text||'').join('')||'I could not generate a response. Please try again.';
pending.textContent=answer;messages.push({role:'model',parts:[{text:answer}]});
const actions=document.createElement('div');actions.className='msg-actions';const copy=document.createElement('button');copy.textContent='Copy';copy.onclick=()=>navigator.clipboard?.writeText(answer).then(()=>toast('Copied'));const speak=document.createElement('button');speak.textContent='🔊 Read aloud';speak.onclick=()=>speakText(answer);actions.append(copy,speak);pending.append(actions);
if(localStorage.getItem(SPEAK)==='true')speakText(answer);
if(messages.length===2)updateHistory(text);
}catch(e){pending.textContent='Error: '+e.message+'\n\nCheck your API key, internet connection, and selected model.';messages.pop();}
finally{$('sendBtn').disabled=false;$('chatArea').scrollTop=$('chatArea').scrollHeight;}}
$('sendBtn').onclick=send;$('prompt').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send()}});
$('prompt').addEventListener('input',e=>{e.target.style.height='auto';e.target.style.height=Math.min(e.target.scrollHeight,140)+'px'});
function speakText(text){if(!('speechSynthesis'in window)){toast('Read aloud is not supported in this browser');return}speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang='en-IN';speechSynthesis.speak(u)}
$('voiceBtn').onclick=()=>{const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){toast('Voice input is not supported in this browser. Try Chrome.');return}
if(listening){recognition.stop();return}recognition=new SR();recognition.lang='en-IN';recognition.interimResults=false;recognition.maxAlternatives=1;recognition.onstart=()=>{listening=true;$('voiceBtn').classList.add('listening');toast('Listening… speak now')};recognition.onend=()=>{listening=false;$('voiceBtn').classList.remove('listening')};recognition.onerror=e=>toast('Voice error: '+e.error);recognition.onresult=e=>{$('prompt').value= e.results[0][0].transcript;$('prompt').focus()};recognition.start()};
if('serviceWorker'in navigator && location.protocol.startsWith('http'))navigator.serviceWorker.register('./sw.js').catch(()=>{});
