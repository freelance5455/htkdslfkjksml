# Nasif — Muslim Discipline App

A self-contained Islamic self-discipline web app built for Nasif.

## Features
- **User-Choice App Control & Haram Content Shield:** Toggle restrictions on any app by your own choice.
- **4-Minute Working Timer:** Restricted apps allow 4 minutes (`04:00`) of working time before automatic lock.
- **Salah Time Detector:** Grounded local prayer times (Chennai default) with live countdown & Qibla direction.
- **Hidden Home Prayer Guide:** Practical 5-step guide for praying discreetly at home.
- **Dua's & Tasbih Counter:** Categorized authentic daily Duas with Arabic, transliteration, and English translation.
- **Al-Qur'an Reference:** Clean Surah & Ayah reader with transliteration, translation, font-size control, and bookmarks.

## How to Run
Open `index.html` in any modern web browser.
