const CITY_SALAH_DATA = {
      chennai: { name: "Chennai, India", lat: 13.0827, lng: 80.2707, qibla: "288° WNW (4,382 km to Makkah)", times: { Fajr: "04:58", Sunrise: "06:13", Dhuhr: "11:56", Asr: "16:03", Maghrib: "17:40", Isha: "18:55" } },
      bengaluru: { name: "Bengaluru, India", lat: 12.9716, lng: 77.5946, qibla: "288° WNW (4,108 km to Makkah)", times: { Fajr: "05:09", Sunrise: "06:23", Dhuhr: "12:07", Asr: "16:14", Maghrib: "17:51", Isha: "19:05" } },
      hyderabad: { name: "Hyderabad, India", lat: 17.3850, lng: 78.4867, qibla: "285° WNW (3,995 km to Makkah)", times: { Fajr: "05:08", Sunrise: "06:25", Dhuhr: "12:03", Asr: "16:05", Maghrib: "17:40", Isha: "18:57" } },
      mumbai: { name: "Mumbai, India", lat: 19.0760, lng: 72.8777, qibla: "280° W (3,478 km to Makkah)", times: { Fajr: "05:32", Sunrise: "06:51", Dhuhr: "12:26", Asr: "16:24", Maghrib: "17:59", Isha: "19:18" } },
      delhi: { name: "New Delhi, India", lat: 28.6139, lng: 77.2090, qibla: "266° W (3,828 km to Makkah)", times: { Fajr: "05:27", Sunrise: "06:51", Dhuhr: "12:09", Asr: "15:52", Maghrib: "17:26", Isha: "18:50" } },
      makkah: { name: "Makkah, Saudi Arabia", lat: 21.4225, lng: 39.8262, qibla: "0° Kaaba (Al-Masjid al-Haram)", times: { Fajr: "05:17", Sunrise: "06:39", Dhuhr: "12:10", Asr: "15:23", Maghrib: "17:40", Isha: "19:10" } },
      madinah: { name: "Madinah, Saudi Arabia", lat: 24.5247, lng: 39.5692, qibla: "176° S (340 km to Makkah)", times: { Fajr: "05:21", Sunrise: "06:46", Dhuhr: "12:12", Asr: "15:21", Maghrib: "17:38", Isha: "19:08" } }
    };

    const HIDDEN_PRAYER_STEPS = [
      { id: 1, title: "1. Choose a Quiet, Private Spot & Lock the Door", summary: "Pray inside your bedroom or a quiet corner when family/housemates are occupied or resting. Face Qibla (288° WNW in Chennai). Any clean floor, towel, or bedsheet is valid." },
      { id: 2, title: "2. Perform Wudu Quietly (or Wipe Over Socks)", summary: "Use low water flow in the washroom so it sounds like normal washing. If you already put on thick socks while in wudu, you may wipe over them (masah). If water access is genuinely unsafe, Tayammum is permitted." },
      { id: 3, title: "3. Recite Silently (Sirri) in All Prayers", summary: "Move your lips softly without making an audible sound for Takbir, Al-Fatihah, Surahs, and Tashahhud. Silent recitation is completely valid when privacy is needed." },
      { id: 4, title: "4. Normal Posture vs. Sitting Option (When Necessary)", summary: "When alone behind a closed door, pray standing with normal Ruku and Sujud. If someone enters unexpectedly or you face severe hardship, you may sit and gesture Ruku and Sujud with head inclinations." },
      { id: 5, title: "5. Focus on Fard (Obligatory) Rak'ahs First", summary: "If time or privacy is tight, prioritize the Fard rak'ahs (Fajr 2, Dhuhr 4, Asr 4, Maghrib 3, Isha 4) so your obligatory Salah is never missed." }
    ];

    const TASBIH_PHRASES = [
      { arabic: "سُبْحَانَ اللَّهِ", translit: "SubhanAllah", meaning: "Glory be to Allah (free from all imperfection)." },
      { arabic: "الْحَمْدُ لِلَّهِ", translit: "Alhamdulillah", meaning: "All praise and thanks belong to Allah." },
      { arabic: "اللَّهُ أَكْبَرُ", translit: "Allahu Akbar", meaning: "Allah is the Greatest." },
      { arabic: "لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ", translit: "La ilaha illallahu wahdahu la sharika lah, lahul-mulku wa lahul-hamdu wa Huwa 'ala kulli shay'in Qadir", meaning: "There is no deity worthy of worship except Allah alone, without partner; to Him belongs all sovereignty and all praise, and He is over all things Omnipotent." },
      { arabic: "أَسْتَغْفِرُ اللَّهَ الْعَظِيمَ الَّذِي لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ وَأَتُوبُ إِلَيْهِ", translit: "Astaghfirullahal-'Azim al-ladhi la ilaha illa Huwal-Hayyul-Qayyumu wa atubu ilayh", meaning: "I seek forgiveness from Allah the Almighty, besides Whom there is no deity, the Ever-Living, the Sustainer of all, and I repent to Him." },
      { arabic: "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ الْعَظِيمِ", translit: "SubhanAllahi wa bihamdihi, SubhanAllahil-'Azim", meaning: "Glory be to Allah and praise Him; Glory be to Allah, the Supreme." },
      { arabic: "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ الْعَلِيِّ الْعَظِيمِ", translit: "La hawla wa la quwwata illa billahil-'Aliyyil-'Azim", meaning: "There is no might and no power except through Allah, the Most High, the Most Great." },
      { arabic: "اللَّهُمَّ صَلِّ عَلَىٰ مُحَمَّدٍ وَعَلَىٰ آلِ مُحَمَّدٍ كَمَا صَلَّيْتَ عَلَىٰ إِبْرَاهِيمَ وَعَلَىٰ آلِ إِبْرَاهِيمَ إِنَّكَ حَمِيدٌ مَجِيدٌ", translit: "Allahumma salli 'ala Muhammadin wa 'ala ali Muhammadin kama sallayta 'ala Ibrahima wa 'ala ali Ibrahima innaka Hamidun Majid", meaning: "O Allah, send prayers upon Muhammad and the family of Muhammad, as You sent prayers upon Ibrahim and the family of Ibrahim; indeed, You are Praiseworthy and Glorious." }
    ];

    const DUAS_DATA = [
      { id: "d1", title: "Protection from Haram & Temptation", category: "Protection", arabic: "اللَّهُمَّ اكْفِنِي بِحَلَالِكَ عَنْ حَرَامِكَ وَأَغْنِنِي بِفَضْلِكَ عَمَّنْ سِوَاكَ", translit: "Allahummak-fini bi-halalika 'an haramika, wa aghnini bi-fadlika 'amman siwak.", meaning: "O Allah, suffice me with what You have made lawful against what You have made unlawful, and enrich me by Your bounty from needing anyone besides You." },
      { id: "d2", title: "Steadfastness of the Heart", category: "Guidance", arabic: "يَا مُقَلِّبَ الْقُلُوبِ ثَبِّتْ قَلْبِي عَلَى دِينِكَ", translit: "Ya Muqallibal-qulub, thabbit qalbi 'ala dinik.", meaning: "O Turner of the hearts, keep my heart firm upon Your religion." },
      { id: "d3", title: "Purifying the Heart & Guarding Chastity", category: "Protection", arabic: "اللَّهُمَّ اغْفِرْ ذَنْبِي وَطَهِّرْ قَلْبِي وَحَصِّنْ فَرْجِي", translit: "Allahummagh-fir dhanbi, wa tahhir qalbi, wa hassin farji.", meaning: "O Allah, forgive my sin, purify my heart, and guard my chastity." },
      { id: "d4", title: "Morning & Evening Protection", category: "Morning/Evening", arabic: "بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ", translit: "Bismillahil-ladhi la yadurru ma'as-mihi shay'un fil-ardi wa la fis-sama'i wa Huwas-Sami'ul-'Alim.", meaning: "In the name of Allah, with whose name nothing on earth or in heaven can cause harm, and He is the All-Hearing, All-Knowing." },
      { id: "d5", title: "Entering the House", category: "Daily", arabic: "بِسْمِ اللَّهِ وَلَجْنَا، وَبِسْمِ اللَّهِ خَرَجْنَا، وَعَلَى اللَّهِ رَبِّنَا تَوَكَّلْنَا", translit: "Bismillahi walajna, wa bismillahi kharajna, wa 'alallahi Rabbina tawakkalna.", meaning: "In the name of Allah we enter, in the name of Allah we leave, and upon Allah our Lord we rely." },
      { id: "d6", title: "Leaving the House", category: "Daily", arabic: "بِسْمِ اللَّهِ، تَوَكَّلْتُ عَلَى اللَّهِ، وَلَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ", translit: "Bismillahi, tawakkaltu 'alallahi, wa la hawla wa la quwwata illa billah.", meaning: "In the name of Allah, I place my trust in Allah; there is no might and no power except through Allah." },
      { id: "d7", title: "Sayyidul Istighfar (Master Supplication for Forgiveness)", category: "Forgiveness", arabic: "اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، أَسْتَغْفِرُكَ وَأَتُوبُ إِلَيْكَ", translit: "Allahumma Anta Rabbi la ilaha illa Anta, khalaqtani wa ana 'abduka, astaghfiruka wa atubu ilayk.", meaning: "O Allah, You are my Lord, none has the right to be worshipped except You. You created me and I am Your servant; I seek Your forgiveness and repent to You." },
      { id: "d8", title: "Before Sleeping", category: "Sleep", arabic: "بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا", translit: "Bismika Allahumma amutu wa ahya.", meaning: "In Your name, O Allah, I die (sleep) and I live (wake)." }
    ];

    const HADITH_DATA = [
      { source: "Sahih al-Bukhari 6412", topic: "Guarding Time & Health", text: "The Prophet (peace be upon him) said: 'There are two blessings which many people lose: health and free time for doing good.'" },
      { source: "Sahih Muslim 2956", topic: "Discipline of the Believer", text: "The Prophet (peace be upon him) said: 'The world is a prison for the believer and a paradise for the unbeliever.'" },
      { source: "Sahih al-Bukhari 528", topic: "Consistency in Salah", text: "The Prophet (peace be upon him) said: 'The five daily prayers and from one Friday prayer to the next are expiation for whatever sins come in between, so long as one does not commit major sins.'" },
      { source: "Sahih Muslim 2564", topic: "Purity of Heart", text: "The Prophet (peace be upon him) said: 'Allah does not look at your appearance or wealth, rather He looks at your hearts and deeds.'" }
    ];

    const HIJRI_EVENTS = [
      { hijri: "15 Jumada al-Akhirah 1448", title: "Today (25 Nov 2026)", note: "Recommended fast of Ayyam al-Bid (13th, 14th, 15th)." },
      { hijri: "1 Rajab 1448", title: "Start of Sacred Month of Rajab", note: "Prepare the heart for Ramadan with extra Salah & Istighfar." },
      { hijri: "15 Sha'ban 1448", title: "Mid-Sha'ban", note: "Increase voluntary fasting and Qur'an recitation." },
      { hijri: "1 Ramadan 1448", title: "Beginning of Ramadan", note: "Obligatory fasting, Taraweeh, and completing the Qur'an." },
      { hijri: "1 Shawwal 1448", title: "Eid al-Fitr", note: "Celebration of gratitude after Ramadan." }
    ];

    const ALL_SURAHS_META = [
      [1,"Al-Fatihah","The Opening",7,"Makkan"],[2,"Al-Baqarah","The Cow",286,"Madinan"],[3,"Ali 'Imran","Family of Imran",200,"Madinan"],
      [4,"An-Nisa","The Women",176,"Madinan"],[5,"Al-Ma'idah","The Table Spread",120,"Madinan"],[6,"Al-An'am","The Cattle",165,"Makkan"],
      [7,"Al-A'raf","The Heights",206,"Makkan"],[8,"Al-Anfal","The Spoils of War",75,"Madinan"],[9,"At-Tawbah","The Repentance",129,"Madinan"],
      [10,"Yunus","Jonah",109,"Makkan"],[11,"Hud","Hud",123,"Makkan"],[12,"Yusuf","Joseph",111,"Makkan"],
      [13,"Ar-Ra'd","The Thunder",43,"Madinan"],[14,"Ibrahim","Abraham",52,"Makkan"],[15,"Al-Hijr","The Rocky Tract",99,"Makkan"],
      [16,"An-Nahl","The Bee",128,"Makkan"],[17,"Al-Isra","The Night Journey",111,"Makkan"],[18,"Al-Kahf","The Cave",110,"Makkan"],
      [19,"Maryam","Mary",98,"Makkan"],[20,"Taha","Ta-Ha",135,"Makkan"],[21,"Al-Anbya","The Prophets",112,"Makkan"],
      [22,"Al-Hajj","The Pilgrimage",78,"Madinan"],[23,"Al-Mu'minun","The Believers",118,"Makkan"],[24,"An-Nur","The Light",64,"Madinan"],
      [25,"Al-Furqan","The Criterion",77,"Makkan"],[26,"Ash-Shu'ara","The Poets",227,"Makkan"],[27,"An-Naml","The Ant",93,"Makkan"],
      [28,"Al-Qasas","The Stories",88,"Makkan"],[29,"Al-'Ankabut","The Spider",69,"Makkan"],[30,"Ar-Rum","The Romans",60,"Makkan"],
      [31,"Luqman","Luqman",34,"Makkan"],[32,"As-Sajdah","The Prostration",30,"Makkan"],[33,"Al-Ahzab","The Combined Forces",73,"Madinan"],
      [34,"Saba","Sheba",54,"Makkan"],[35,"Fatir","Originator",45,"Makkan"],[36,"Ya-Sin","Ya Sin",83,"Makkan"],
      [37,"As-Saffat","Those who set the Ranks",182,"Makkan"],[38,"Sad","The Letter Saad",88,"Makkan"],[39,"Az-Zumar","The Troops",75,"Makkan"],
      [40,"Ghafir","The Forgiver",85,"Makkan"],[41,"Fussilat","Explained in Detail",54,"Makkan"],[42,"Ash-Shuraa","The Consultation",53,"Makkan"],
      [43,"Az-Zukhruf","The Ornaments of Gold",89,"Makkan"],[44,"Ad-Dukhan","The Smoke",59,"Makkan"],[45,"Al-Jathiyah","The Crouching",37,"Makkan"],
      [46,"Al-Ahqaf","The Wind-Curved Sandhills",35,"Makkan"],[47,"Muhammad","Muhammad",38,"Madinan"],[48,"Al-Fath","The Victory",29,"Madinan"],
      [49,"Al-Hujurat","The Rooms",18,"Madinan"],[50,"Qaf","The Letter Qaf",45,"Makkan"],[51,"Adh-Dhariyat","The Winnowing Winds",60,"Makkan"],
      [52,"At-Tur","The Mount",49,"Makkan"],[53,"An-Najm","The Star",62,"Makkan"],[54,"Al-Qamar","The Moon",55,"Makkan"],
      [55,"Ar-Rahman","The Beneficent",78,"Madinan"],[56,"Al-Waqi'ah","The Inevitable",96,"Makkan"],[57,"Al-Hadid","The Iron",29,"Madinan"],
      [58,"Al-Mujadila","The Pleading Woman",22,"Madinan"],[59,"Al-Hashr","The Exile",24,"Madinan"],[60,"Al-Mumtahanah","She that is to be examined",13,"Madinan"],
      [61,"As-Saf","The Ranks",14,"Madinan"],[62,"Al-Jumu'ah","The Congregation",11,"Madinan"],[63,"Al-Munafiqun","The Hypocrites",11,"Madinan"],
      [64,"At-Taghabun","The Mutual Disillusion",18,"Madinan"],[65,"At-Talaq","The Divorce",12,"Madinan"],[66,"At-Tahrim","The Prohibition",12,"Madinan"],
      [67,"Al-Mulk","The Sovereignty",30,"Makkan"],[68,"Al-Qalam","The Pen",52,"Makkan"],[69,"Al-Haqqah","The Reality",52,"Makkan"],
      [70,"Al-Ma'arij","The Ascending Stairways",44,"Makkan"],[71,"Nuh","Noah",28,"Makkan"],[72,"Al-Jinn","The Jinn",28,"Makkan"],
      [73,"Al-Muzzammil","The Enshrouded One",20,"Makkan"],[74,"Al-Muddaththir","The Cloaked One",56,"Makkan"],[75,"Al-Qiyamah","The Resurrection",40,"Makkan"],
      [76,"Al-Insan","The Man",31,"Madinan"],[77,"Al-Mursalat","The Emissaries",50,"Makkan"],[78,"An-Naba","The Tidings",40,"Makkan"],
      [79,"An-Nazi'at","Those who drag forth",46,"Makkan"],[80,"'Abasa","He Frowned",42,"Makkan"],[81,"At-Takwir","The Overthrowing",29,"Makkan"],
      [82,"Al-Infitar","The Cleaving",19,"Makkan"],[83,"Al-Mutaffifin","The Defrauding",36,"Makkan"],[84,"Al-Inshiqaq","The Sundering",25,"Makkan"],
      [85,"Al-Buruj","The Mansions of the Stars",22,"Makkan"],[86,"At-Tariq","The Nightcommer",17,"Makkan"],[87,"Al-A'la","The Most High",19,"Makkan"],
      [88,"Al-Ghashiyah","The Overwhelming",26,"Makkan"],[89,"Al-Fajr","The Dawn",30,"Makkan"],[90,"Al-Balad","The City",20,"Makkan"],
      [91,"Ash-Shams","The Sun",15,"Makkan"],[92,"Al-Layl","The Night",21,"Makkan"],[93,"Ad-Duhaa","The Morning Hours",11,"Makkan"],
      [94,"Ash-Sharh","The Relief",8,"Makkan"],[95,"At-Tin","The Fig",8,"Makkan"],[96,"Al-'Alaq","The Clot",19,"Makkan"],
      [97,"Al-Qadr","The Power",5,"Makkan"],[98,"Al-Bayyinah","The Clear Proof",8,"Madinan"],[99,"Az-Zalzalah","The Earthquake",8,"Madinan"],
      [100,"Al-'Adiyat","The Courser",11,"Makkan"],[101,"Al-Qari'ah","The Calamity",11,"Makkan"],[102,"At-Takathur","The Rivalry in world increase",8,"Makkan"],
      [103,"Al-Asr","The Declining Day",3,"Makkan"],[104,"Al-Humazah","The Traducer",9,"Makkan"],[105,"Al-Fil","The Elephant",5,"Makkan"],
      [106,"Quraysh","Quraysh",4,"Makkan"],[107,"Al-Ma'un","The Small kindnesses",7,"Makkan"],[108,"Al-Kawthar","The Abundance",3,"Makkan"],
      [109,"Al-Kafirun","The Disbelievers",6,"Makkan"],[110,"An-Nasr","The Divine Support",3,"Madinan"],[111,"Al-Masad","The Palm Fiber",5,"Makkan"],
      [112,"Al-Ikhlas","The Sincerity",4,"Makkan"],[113,"Al-Falaq","The Daybreak",5,"Makkan"],[114,"An-Nas","Mankind",6,"Makkan"]
    ];

    const BUILTIN_QURAN_CACHE = {
      1: [
        { n: 1, ar: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ", tr: "Bismillahir-Rahmanir-Rahim", en: "In the name of Allah, the Entirely Merciful, the Especially Merciful." },
        { n: 2, ar: "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ", tr: "Al-hamdu lillahi Rabbil-'alamin", en: "All praise is due to Allah, Lord of the worlds." },
        { n: 3, ar: "الرَّحْمَٰنِ الرَّحِيمِ", tr: "Ar-Rahmanir-Rahim", en: "The Entirely Merciful, the Especially Merciful," },
        { n: 4, ar: "مَالِكِ يَوْمِ الدِّينِ", tr: "Maliki yawmid-din", en: "Sovereign of the Day of Recompense." },
        { n: 5, ar: "إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ", tr: "Iyyaka na'budu wa iyyaka nasta'in", en: "It is You we worship and You we ask for help." },
        { n: 6, ar: "اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ", tr: "Ihdinas-siratal-mustaqim", en: "Guide us to the straight path —" },
        { n: 7, ar: "صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ", tr: "Siratal-ladhina an'amta 'alayhim ghayril-maghdubi 'alayhim wa lad-dallin", en: "The path of those upon whom You have bestowed favor, not of those who have evoked anger or of those who are astray." }
      ],
      94: [
        { n: 1, ar: "أَلَمْ نَشْرَحْ لَكَ صَدْرَكَ", tr: "Alam nashrah laka sadrak", en: "Did We not expand for you your breast?" },
        { n: 2, ar: "وَوَضَعْنَا عَنْكَ وِزْرَكَ", tr: "Wa wada'na 'anka wizrak", en: "And We removed from you your burden" },
        { n: 3, ar: "الَّذِي أَنْقَضَ ظَهْرَكَ", tr: "Alladhi anqada zahrak", en: "Which had weighed upon your back" },
        { n: 4, ar: "وَرَفَعْنَا لَكَ ذِكْرَكَ", tr: "Wa rafa'na laka dhikrak", en: "And raised high for you your repute." },
        { n: 5, ar: "فَإِنَّ مَعَ الْعُسْرِ يُسْرًا", tr: "Fa inna ma'al-'usri yusra", en: "For indeed, with hardship will be ease." },
        { n: 6, ar: "إِنَّ مَعَ الْعُسْرِ يُسْرًا", tr: "Inna ma'al-'usri yusra", en: "Indeed, with hardship will be ease." },
        { n: 7, ar: "فَإِذَا فَرَغْتَ فَانْصَبْ", tr: "Fa idha faraghta fansab", en: "So when you have finished [your duties], then stand up [for worship]." },
        { n: 8, ar: "وَإِلَىٰ رَبِّكَ فَارْغَبْ", tr: "Wa ila Rabbika farghab", en: "And to your Lord direct [your] longing." }
      ],
      103: [
        { n: 1, ar: "وَالْعَصْرِ", tr: "Wal-'asr", en: "By time," },
        { n: 2, ar: "إِنَّ الْإِنْسَانَ لَفِي خُسْرٍ", tr: "Innal-insana lafi khusr", en: "Indeed, mankind is in loss," },
        { n: 3, ar: "إِلَّا الَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ وَتَوَاصَوْا بِالْحَقِّ وَتَوَاصَوْا بِالصَّبْرِ", tr: "Illal-ladhina amanu wa 'amilus-salihati wa tawasaw bil-haqqi wa tawasaw bis-sabr", en: "Except for those who have believed and done righteous deeds and advised each other to truth and advised each other to patience." }
      ],
      108: [
        { n: 1, ar: "إِنَّا أَعْطَيْنَاكَ الْكَوْثَرَ", tr: "Inna a'taynakal-kawthar", en: "Indeed, We have granted you, [O Muhammad], al-Kawthar." },
        { n: 2, ar: "فَصَلِّ لِرَبِّكَ وَانْحَرْ", tr: "Fasalli li-Rabbika wanhar", en: "So pray to your Lord and sacrifice [to Him alone]." },
        { n: 3, ar: "إِنَّ شَانِئَكَ هُوَ الْأَبْتَرُ", tr: "Inna shani'aka huwal-abtar", en: "Indeed, your enemy is the one cut off." }
      ],
      112: [
        { n: 1, ar: "قُلْ هُوَ اللَّهُ أَحَدٌ", tr: "Qul Huwallahu Ahad", en: "Say, 'He is Allah, [who is] One,'" },
        { n: 2, ar: "اللَّهُ الصَّمَدُ", tr: "Allahus-Samad", en: "Allah, the Eternal Refuge." },
        { n: 3, ar: "لَمْ يَلِدْ وَلَمْ يُولَدْ", tr: "Lam yalid wa lam yulad", en: "He neither begets nor is born," },
        { n: 4, ar: "وَلَمْ يَكُنْ لَهُ كُفُوًا أَحَدٌ", tr: "Wa lam yakun lahu kufuwan ahad", en: "Nor is there to Him any equivalent." }
      ],
      113: [
        { n: 1, ar: "قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ", tr: "Qul a'udhu bi-Rabbil-falaq", en: "Say, 'I seek refuge in the Lord of daybreak" },
        { n: 2, ar: "مِنْ شَرِّ مَا خَلَقَ", tr: "Min sharri ma khalaq", en: "From the evil of that which He created" },
        { n: 3, ar: "وَمِنْ شَرِّ غَاسِقٍ إِذَا وَقَبَ", tr: "Wa min sharri ghasiqin idha waqab", en: "And from the evil of darkness when it settles" },
        { n: 4, ar: "وَمِنْ شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ", tr: "Wa min sharrin-naffathati fil-'uqad", en: "And from the evil of the blowers in knots" },
        { n: 5, ar: "وَمِنْ شَرِّ حَاسِدٍ إِذَا حَسَدَ", tr: "Wa min sharri hasidin idha hasad", en: "And from the evil of an envier when he envies.'" }
      ],
      114: [
        { n: 1, ar: "قُلْ أَعُوذُ بِرَبِّ النَّاسِ", tr: "Qul a'udhu bi-Rabbin-nas", en: "Say, 'I seek refuge in the Lord of mankind," },
        { n: 2, ar: "مَلِكِ النَّاسِ", tr: "Malikin-nas", en: "The Sovereign of mankind," },
        { n: 3, ar: "إِلَٰهِ النَّاسِ", tr: "Ilahin-nas", en: "The God of mankind," },
        { n: 4, ar: "مِنْ شَرِّ الْوَسْوَاسِ الْخَنَّاسِ", tr: "Min sharril-waswasil-khannas", en: "From the evil of the retreating whisperer —" },
        { n: 5, ar: "الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ", tr: "Alladhi yuwaswisu fi sudurin-nas", en: "Who whispers [evil] into the breasts of mankind —" },
        { n: 6, ar: "مِنَ الْجِنَّةِ وَالنَّاسِ", tr: "Minal-jinnati wan-nas", en: "From among the jinn and mankind.'" }
      ]
    };

    const defaultState = {
      activeView: "home",
      city: "chennai",
      apps: [
        { id: "a1", name: "Instagram", category: "Social Media", restricted: true, remaining: 240, blocked: false },
        { id: "a2", name: "TikTok / Reels", category: "Video / Reels", restricted: true, remaining: 240, blocked: false },
        { id: "a3", name: "YouTube", category: "Video / Reels", restricted: true, remaining: 240, blocked: false },
        { id: "a4", name: "X / Twitter", category: "Social Media", restricted: true, remaining: 240, blocked: false },
        { id: "a5", name: "Web Browser", category: "Browser / Web", restricted: true, remaining: 240, blocked: false },
        { id: "a6", name: "Gaming Hub", category: "Gaming", restricted: false, remaining: 240, blocked: false }
      ],
      shields: [
        { id: "s1", label: "Block Adult / Indecent Content", enabled: true },
        { id: "s2", label: "Block Gambling & Betting Sites", enabled: true },
        { id: "s3", label: "Block Short-Form Reels & Shorts", enabled: true },
        { id: "s4", label: "Block Haram Music & Popups", enabled: true }
      ],
      salahDone: { Fajr: false, Dhuhr: false, Asr: false, Maghrib: false, Isha: false },
      reviewedSteps: [],
      duaCategory: "All",
      duaSearch: "",
      duaFavs: ["d1"],
      tasbihPhraseIdx: 0,
      tasbihCount: 0,
      tasbihTarget: 33,
      selectedSurahId: 1,
      surahSearch: "",
      showTranslit: true,
      showTranslation: true,
      arabicFontSize: 26,
      bookmarkedAyahs: []
    };

    let state = loadState();
    let activeSessionAppId = null;
    let timerInterval = null;
    let timerPaused = false;
    let timerSpeed = 1;
    let compassHeading = 0;
    let qiblaBearing = 288;

    function loadState() {
      try {
        const raw = localStorage.getItem("nasif_muslim_discipline_v3");
        if (raw) return { ...defaultState, ...JSON.parse(raw) };
      } catch (e) {}
      return JSON.parse(JSON.stringify(defaultState));
    }

    function saveState() {
      try { localStorage.setItem("nasif_muslim_discipline_v3", JSON.stringify(state)); } catch (e) {}
    }

    function showToast(msg) {
      const el = document.getElementById("toast");
      el.textContent = msg;
      el.classList.remove("hidden");
      clearTimeout(el._timer);
      el._timer = setTimeout(() => el.classList.add("hidden"), 2600);
    }

    function formatMMSS(sec) {
      return `${String(Math.floor(sec / 60)).padStart(2, "0")}:${String(sec % 60).padStart(2, "0")}`;
    }

    function getAppBadgeIcon(category) {
      const map = { "Social Media": "📱", "Video / Reels": "🎬", "Browser / Web": "🌐", "Gaming": "🎮", "Entertainment": "📺" };
      return map[category] || "📲";
    }

    function escapeHtml(str) {
      return String(str).replace(/[&<>"']/g, m => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m]));
    }

    // ---------- View Switching (Separate Icon -> Separate View) ----------
    function openView(viewId) {
      state.activeView = viewId;
      saveState();
      document.querySelectorAll(".app-view").forEach(v => v.classList.add("hidden"));
      const target = document.getElementById(`view-${viewId}`);
      if (target) target.classList.remove("hidden");
      document.getElementById("btn-back-home").classList.toggle("hidden", viewId === "home");

      document.querySelectorAll(".bottom-nav-btn").forEach(b => {
        if (b.dataset.openView === viewId) {
          b.classList.add("text-amber-300", "bg-emerald-900/70");
          b.classList.remove("text-emerald-200");
        } else {
          b.classList.remove("text-amber-300", "bg-emerald-900/70");
          b.classList.add("text-emerald-200");
        }
      });
      if (viewId === "qibla") startAutoGyroscope();
      window.scrollTo({ top: 0, behavior: "smooth" });
    }

    // ---------- App Control & Haram Shield ----------
    function renderAppControl() {
      document.getElementById("stat-restricted-count").textContent = state.apps.filter(a => a.restricted).length;
      document.getElementById("stat-blocked-count").textContent = state.apps.filter(a => a.blocked).length;
      document.getElementById("stat-shields-count").textContent = `${state.shields.filter(s => s.enabled).length} / ${state.shields.length} Active`;

      const listEl = document.getElementById("app-list-container");
      listEl.innerHTML = "";
      state.apps.forEach(app => {
        const card = document.createElement("div");
        card.className = `flex flex-wrap items-center justify-between gap-3 p-3.5 rounded-2xl border transition ${
          app.blocked ? "bg-amber-50/80 border-amber-300" : "bg-emerald-50/40 border-emerald-900/10"
        }`;
        const statusBadge = app.blocked
          ? `<span class="px-2 py-0.5 rounded-full bg-red-100 text-red-800 text-[11px] font-bold">BLOCKED (00:00)</span>`
          : app.restricted
          ? `<span class="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[11px] font-bold">4m Limit • ${formatMMSS(app.remaining)} left</span>`
          : `<span class="px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 text-[11px] font-semibold">Allowed (User Choice)</span>`;

        card.innerHTML = `
          <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-xl bg-white border border-emerald-900/10 flex items-center justify-center text-lg shadow-sm shrink-0">${getAppBadgeIcon(app.category)}</div>
            <div class="space-y-1">
              <div class="flex items-center gap-2 flex-wrap">
                <span class="font-bold text-sm text-emerald-950">${escapeHtml(app.name)}</span>
                <span class="text-[11px] text-emerald-700 bg-white px-2 py-0.5 rounded-lg border border-emerald-200">${escapeHtml(app.category)}</span>
              </div>
              <div>${statusBadge}</div>
            </div>
          </div>
          <div class="flex items-center gap-2">
            <button type="button" data-action="toggle-restrict" data-id="${app.id}" class="px-3 py-1.5 rounded-xl text-xs font-semibold border transition ${
              app.restricted ? "bg-emerald-800 text-amber-50 border-emerald-900" : "bg-white text-emerald-900 border-emerald-300"
            }">${app.restricted ? "Restricted ✓" : "Allowing"}</button>
            ${
              app.restricted
                ? `<button type="button" data-action="launch" data-id="${app.id}" ${app.blocked ? "disabled" : ""} class="px-3.5 py-1.5 rounded-xl text-xs font-bold transition shadow-sm ${
                    app.blocked ? "bg-slate-200 text-slate-500 cursor-not-allowed" : "bg-amber-500 hover:bg-amber-400 text-emerald-950"
                  }">${app.blocked ? "Locked" : "Open (4m)"}</button>`
                : ""
            }
          </div>
        `;
        listEl.appendChild(card);
      });

      const shieldEl = document.getElementById("shield-list");
      shieldEl.innerHTML = "";
      state.shields.forEach(sh => {
        const row = document.createElement("label");
        row.className = "flex items-center justify-between gap-2 p-3.5 rounded-2xl bg-emerald-50/50 border border-emerald-900/10 cursor-pointer hover:bg-emerald-50";
        row.innerHTML = `
          <span class="text-xs sm:text-sm font-semibold text-emerald-950">${escapeHtml(sh.label)}</span>
          <input type="checkbox" data-shield-id="${sh.id}" ${sh.enabled ? "checked" : ""} class="accent-emerald-700 w-4 h-4" />
        `;
        shieldEl.appendChild(row);
      });

      updateActiveTimerUI();
    }

    function startAppTimer(appId) {
      const app = state.apps.find(a => a.id === appId);
      if (!app || !app.restricted || app.blocked) return;
      clearInterval(timerInterval);
      activeSessionAppId = appId;
      timerPaused = false;
      updateActiveTimerUI();

      timerInterval = setInterval(() => {
        if (timerPaused) return;
        const target = state.apps.find(a => a.id === activeSessionAppId);
        if (!target) return;
        target.remaining = Math.max(0, target.remaining - 1);
        if (target.remaining === 0) {
          target.blocked = true;
          clearInterval(timerInterval);
          timerInterval = null;
          saveState();
          renderAppControl();
          document.getElementById("blocked-modal-app").textContent = target.name;
          document.getElementById("modal-blocked").classList.remove("hidden");
          return;
        }
        saveState();
        updateActiveTimerUI();
      }, Math.floor(1000 / timerSpeed));
      showToast(`${app.name} opened — 4-minute working timer active`);
    }

    function updateActiveTimerUI() {
      const nameEl = document.getElementById("active-app-name");
      const timeEl = document.getElementById("active-timer-display");
      const barEl = document.getElementById("active-timer-bar");
      const ringEl = document.getElementById("active-timer-ring");
      const statusEl = document.getElementById("active-timer-status");
      const btnToggle = document.getElementById("btn-timer-toggle");
      const btnStop = document.getElementById("btn-timer-stop");
      const circumference = 326.72;

      const app = state.apps.find(a => a.id === activeSessionAppId);
      if (!app) {
        nameEl.textContent = "Select a restricted app to test";
        timeEl.textContent = "04:00";
        barEl.style.width = "100%";
        ringEl.style.strokeDashoffset = "0";
        statusEl.textContent = "Only 4 minutes of working time allowed before block.";
        btnToggle.disabled = true;
        btnStop.disabled = true;
        return;
      }
      nameEl.textContent = `Running: ${app.name}`;
      timeEl.textContent = formatMMSS(app.remaining);
      const ratio = app.remaining / 240;
      barEl.style.width = `${Math.round(ratio * 100)}%`;
      ringEl.style.strokeDashoffset = String(circumference * (1 - ratio));
      statusEl.textContent = app.blocked ? `${app.name} is now BLOCKED.` : timerPaused ? "Timer paused." : `Counting down (${timerSpeed}x) — auto-blocks at 00:00.`;
      btnToggle.disabled = app.blocked;
      btnToggle.textContent = timerPaused ? "Resume Timer" : "Pause Timer";
      btnStop.disabled = false;
    }

    // ---------- Salah, Home Strip & Qibla Compass ----------
    function computeQiblaBearing(lat, lng) {
      const phi1 = (lat * Math.PI) / 180;
      const phi2 = (21.4225 * Math.PI) / 180;
      const dLambda = ((39.8262 - lng) * Math.PI) / 180;
      const y = Math.sin(dLambda);
      const x = Math.cos(phi1) * Math.tan(phi2) - Math.sin(phi1) * Math.cos(dLambda);
      return Math.round(((Math.atan2(y, x) * 180) / Math.PI + 360) % 360);
    }

    let gyroStarted = false;
    function startAutoGyroscope() {
      if (gyroStarted) return;
      const badge = document.getElementById("gyro-status-badge");
      const handleOrientation = ev => {
        let heading = null;
        if (typeof ev.webkitCompassHeading === "number") {
          heading = ev.webkitCompassHeading;
        } else if (ev.alpha !== null && ev.alpha !== undefined) {
          heading = (360 - ev.alpha) % 360;
        }
        if (heading !== null && !Number.isNaN(heading)) {
          compassHeading = Math.round((heading + 360) % 360);
          const slider = document.getElementById("slider-compass-heading");
          if (slider) slider.value = compassHeading;
          if (badge) {
            badge.textContent = "Gyroscope Active • Live";
            badge.className = "px-2.5 py-1 rounded-full bg-emerald-800 text-amber-200 text-[11px] font-bold";
          }
          updateCompassUI();
        }
      };

      if (typeof DeviceOrientationEvent !== "undefined" && typeof DeviceOrientationEvent.requestPermission !== "function") {
        window.addEventListener("deviceorientationabsolute", handleOrientation, true);
        window.addEventListener("deviceorientation", handleOrientation, true);
        gyroStarted = true;
      } else if (typeof DeviceOrientationEvent !== "undefined") {
        if (badge) badge.textContent = "Tap Calibrate for iOS Gyro";
      }
    }

    function updateCompassUI() {
      const dial = document.getElementById("compass-svg");
      const ringWrap = document.getElementById("compass-ring-wrap");
      const pill = document.getElementById("compass-guidance-pill");
      const headArrow = document.getElementById("guidance-head-arrow");
      document.getElementById("qibla-needle-group").setAttribute("transform", `rotate(${qiblaBearing} 100 100)`);
      dial.style.transform = `rotate(${-compassHeading}deg)`;
      let diff = ((qiblaBearing - compassHeading + 540) % 360) - 180;
      const absDiff = Math.abs(diff);
      const statusEl = document.getElementById("compass-status-text");
      if (absDiff <= 5) {
        pill.textContent = "✓ Aligned with Kaaba (Qibla)!";
        pill.className = "py-2.5 px-4 rounded-2xl bg-emerald-800 border border-amber-400 text-amber-200 text-sm font-extrabold";
        ringWrap.className = "relative p-2 rounded-full border-4 border-emerald-600 bg-emerald-50/40 transition-colors";
        headArrow.className = "mb-1 px-3 py-1 rounded-full bg-amber-400 text-emerald-950 text-[11px] font-extrabold tracking-wide shadow-sm";
        statusEl.textContent = `Heading: ${compassHeading}° • Facing Qibla ✓`;
      } else {
        const dirText = diff > 0 ? `Turn ${Math.round(absDiff)}° Right →` : `← Turn ${Math.round(absDiff)}° Left`;
        pill.textContent = `${dirText} toward Kaaba`;
        pill.className = "py-2.5 px-4 rounded-2xl bg-amber-50 border border-amber-300 text-amber-900 text-sm font-extrabold";
        ringWrap.className = "relative p-2 rounded-full border-4 border-emerald-900/15 transition-colors";
        headArrow.className = "mb-1 px-3 py-1 rounded-full bg-emerald-900 text-amber-300 text-[11px] font-extrabold tracking-wide shadow-sm";
        statusEl.textContent = `Heading: ${compassHeading}° • Move your phone to auto-guide`;
      }
      document.getElementById("qibla-bearing-label").textContent = `Target Qibla: ${qiblaBearing}°`;
      document.getElementById("compass-heading-val").textContent = `${compassHeading}°`;
    }

    function parseTimeToday(hhmm) {
      const [h, m] = hhmm.split(":").map(Number);
      const d = new Date();
      d.setHours(h, m, 0, 0);
      return d;
    }

    function updateSalahClock() {
      const city = CITY_SALAH_DATA[state.city] || CITY_SALAH_DATA.chennai;
      const now = new Date();
      document.getElementById("live-clock").textContent = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
      document.getElementById("home-live-clock").textContent = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

      const prayerOrder = ["Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"];
      let nextName = "Fajr";
      let nextDate = parseTimeToday(city.times.Fajr);
      nextDate.setDate(nextDate.getDate() + 1);

      for (const p of prayerOrder) {
        const pDate = parseTimeToday(city.times[p]);
        if (pDate > now) { nextName = p; nextDate = pDate; break; }
      }

      const diffSec = Math.max(0, Math.floor((nextDate - now) / 1000));
      const hrs = Math.floor(diffSec / 3600);
      const mins = Math.floor((diffSec % 3600) / 60);
      const secs = diffSec % 60;
      const countdown = `${String(hrs).padStart(2, "0")}:${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;

      document.getElementById("next-salah-name").textContent = `${nextName} (${city.times[nextName]})`;
      document.getElementById("next-salah-countdown").textContent = countdown;
      document.getElementById("header-next-salah").textContent = `Next: ${nextName} in ${hrs}h ${mins}m`;
      document.getElementById("home-next-salah-title").textContent = `${nextName} • ${city.times[nextName]}`;
      document.getElementById("home-next-salah-sub").textContent = `Starts in ${hrs}h ${mins}m ${secs}s`;
    }

    function renderSalahAndGuide() {
      const city = CITY_SALAH_DATA[state.city] || CITY_SALAH_DATA.chennai;
      document.getElementById("salah-city-title").textContent = city.name;
      document.getElementById("home-city-label").textContent = city.name;
      document.getElementById("qibla-info").textContent = `Qibla: ${city.qibla}`;
      document.getElementById("select-city").value = state.city;
      qiblaBearing = computeQiblaBearing(city.lat, city.lng);
      updateCompassUI();

      // Home 5-Prayer Strip
      const stripEl = document.getElementById("home-prayer-strip");
      stripEl.innerHTML = "";
      ["Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"].forEach(p => {
        const cell = document.createElement("div");
        cell.className = "rounded-xl bg-emerald-900/75 border border-amber-400/25 px-2 py-1.5 text-center";
        cell.innerHTML = `<p class="text-[10px] text-emerald-200 font-medium">${p}</p><p class="text-xs font-bold text-amber-200 tabular-nums">${city.times[p]}</p>`;
        stripEl.appendChild(cell);
      });

      const list = document.getElementById("salah-schedule-list");
      list.innerHTML = "";
      Object.entries(city.times).forEach(([name, time]) => {
        const isPrayer = name !== "Sunrise";
        const checked = state.salahDone[name];
        const row = document.createElement("div");
        row.className = "flex items-center justify-between px-3.5 py-2.5 rounded-xl bg-emerald-950/60 border border-amber-500/20 text-xs";
        row.innerHTML = `
          <div class="flex items-center gap-2">
            ${isPrayer ? `<input type="checkbox" data-salah="${name}" ${checked ? "checked" : ""} class="accent-amber-400 w-4 h-4 cursor-pointer" />` : `<span class="w-4 h-4 inline-block text-center text-amber-300">☀</span>`}
            <span class="font-semibold ${checked ? "line-through text-emerald-300/70" : "text-amber-50"}">${name}</span>
          </div>
          <span class="font-bold text-amber-300 tabular-nums">${time}</span>
        `;
        list.appendChild(row);
      });

      const stepsEl = document.getElementById("hidden-prayer-steps");
      stepsEl.innerHTML = "";
      HIDDEN_PRAYER_STEPS.forEach(step => {
        const done = state.reviewedSteps.includes(step.id);
        const card = document.createElement("div");
        card.className = `p-4 rounded-2xl border transition ${done ? "bg-emerald-50 border-emerald-400" : "bg-white border-emerald-900/15"}`;
        card.innerHTML = `
          <div class="flex items-start justify-between gap-3">
            <div class="space-y-1">
              <h4 class="text-sm font-bold text-emerald-950">${step.title}</h4>
              <p class="text-xs sm:text-sm text-emerald-800 leading-relaxed">${step.summary}</p>
            </div>
            <button type="button" data-step-id="${step.id}" class="shrink-0 px-3 py-1.5 rounded-xl text-xs font-semibold border transition ${
              done ? "bg-emerald-800 text-amber-50 border-emerald-900" : "bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100"
            }">${done ? "Reviewed ✓" : "Mark Read"}</button>
          </div>
        `;
        stepsEl.appendChild(card);
      });
      document.getElementById("hidden-guide-progress").textContent = `${state.reviewedSteps.length} / ${HIDDEN_PRAYER_STEPS.length} Steps Reviewed`;
      updateSalahClock();
    }

    // ---------- Dua's, Tasbih, Hadith, Hijri ----------
    function renderTasbih() {
      const phrase = TASBIH_PHRASES[state.tasbihPhraseIdx] || TASBIH_PHRASES[0];
      document.getElementById("select-tasbih").value = String(state.tasbihPhraseIdx);
      document.getElementById("tasbih-arabic").textContent = phrase.arabic;
      document.getElementById("tasbih-translit").textContent = phrase.translit;
      document.getElementById("tasbih-meaning").textContent = phrase.meaning;
      document.getElementById("tasbih-count").textContent = state.tasbihCount;
      document.getElementById("tasbih-target-display").textContent = state.tasbihTarget;
      document.querySelectorAll(".tasbih-target-btn").forEach(b => {
        b.className = Number(b.dataset.tasbihTarget) === state.tasbihTarget
          ? "tasbih-target-btn px-2.5 py-1 rounded-lg text-xs font-bold bg-amber-400 text-emerald-950"
          : "tasbih-target-btn px-2.5 py-1 rounded-lg text-xs font-semibold bg-emerald-900 text-amber-100";
      });
    }

    function renderDuas() {
      const categories = ["All", "Favorites", ...new Set(DUAS_DATA.map(d => d.category))];
      const catEl = document.getElementById("dua-categories");
      catEl.innerHTML = "";
      categories.forEach(cat => {
        const btn = document.createElement("button");
        btn.type = "button";
        btn.dataset.duaCat = cat;
        btn.className = `px-3 py-1.5 rounded-xl text-xs font-semibold border transition ${
          state.duaCategory === cat ? "bg-emerald-800 text-amber-50 border-emerald-900" : "bg-emerald-50 text-emerald-900 border-emerald-200 hover:bg-emerald-100"
        }`;
        btn.textContent = cat;
        catEl.appendChild(btn);
      });

      const q = state.duaSearch.trim().toLowerCase();
      const filtered = DUAS_DATA.filter(d => {
        const matchesCat = state.duaCategory === "All" || (state.duaCategory === "Favorites" && state.duaFavs.includes(d.id)) || d.category === state.duaCategory;
        const matchesQ = !q || d.title.toLowerCase().includes(q) || d.meaning.toLowerCase().includes(q) || d.translit.toLowerCase().includes(q);
        return matchesCat && matchesQ;
      });

      const listEl = document.getElementById("dua-list");
      listEl.innerHTML = "";
      filtered.forEach(d => {
        const isFav = state.duaFavs.includes(d.id);
        const card = document.createElement("div");
        card.className = "p-4 rounded-2xl border border-emerald-900/15 bg-emerald-50/30 space-y-2.5 flex flex-col justify-between";
        card.innerHTML = `
          <div class="space-y-2">
            <div class="flex items-start justify-between gap-2">
              <div>
                <span class="text-[11px] font-semibold text-amber-800 bg-amber-100 px-2.5 py-0.5 rounded-full">${escapeHtml(d.category)}</span>
                <h4 class="text-sm font-bold text-emerald-950 mt-1">${escapeHtml(d.title)}</h4>
              </div>
              <button type="button" data-fav-dua="${d.id}" class="text-lg leading-none ${isFav ? "text-amber-500" : "text-slate-300 hover:text-amber-400"}">★</button>
            </div>
            <p class="font-arabic text-xl text-emerald-950 bg-white p-3.5 rounded-2xl border border-emerald-900/10 shadow-sm">${d.arabic}</p>
            <p class="text-xs font-medium text-emerald-800 italic">${escapeHtml(d.translit)}</p>
            <p class="text-xs text-emerald-900 leading-relaxed">${escapeHtml(d.meaning)}</p>
          </div>
          <div class="pt-1 flex justify-end">
            <button type="button" data-copy-dua="${d.id}" class="text-xs font-semibold text-emerald-800 bg-white px-3 py-1 rounded-xl border border-emerald-200">Copy Dua</button>
          </div>
        `;
        listEl.appendChild(card);
      });
    }

    function renderHadithAndCalendar() {
      const hEl = document.getElementById("hadith-list");
      hEl.innerHTML = "";
      HADITH_DATA.forEach(h => {
        const c = document.createElement("div");
        c.className = "p-4 rounded-2xl bg-emerald-50/40 border border-emerald-900/10 space-y-2";
        c.innerHTML = `
          <div class="flex items-center justify-between">
            <span class="text-xs font-bold text-emerald-900">${escapeHtml(h.topic)}</span>
            <span class="text-[11px] font-semibold text-amber-800 bg-amber-100 px-2 py-0.5 rounded-full">${escapeHtml(h.source)}</span>
          </div>
          <p class="text-xs sm:text-sm text-emerald-950 leading-relaxed">${escapeHtml(h.text)}</p>
        `;
        hEl.appendChild(c);
      });

      const calEl = document.getElementById("hijri-events-list");
      calEl.innerHTML = "";
      HIJRI_EVENTS.forEach(ev => {
        const row = document.createElement("div");
        row.className = "p-3.5 rounded-2xl bg-emerald-50/50 border border-emerald-900/10 flex flex-wrap items-center justify-between gap-2";
        row.innerHTML = `
          <div>
            <p class="text-sm font-bold text-emerald-950">${escapeHtml(ev.title)}</p>
            <p class="text-xs text-emerald-700">${escapeHtml(ev.note)}</p>
          </div>
          <span class="text-xs font-bold text-amber-800 bg-amber-100 px-3 py-1 rounded-xl">${escapeHtml(ev.hijri)}</span>
        `;
        calEl.appendChild(row);
      });
    }

    // ---------- Full 114-Surah Al-Qur'an Reader ----------
    async function loadSurahAyahs(surahId) {
      if (BUILTIN_QURAN_CACHE[surahId]) return BUILTIN_QURAN_CACHE[surahId];
      try {
        const res = await fetch(`https://api.alquran.cloud/v1/surah/${surahId}/editions/quran-uthmani,en.sahih,en.transliteration`);
        if (!res.ok) throw new Error("Network error");
        const json = await res.json();
        if (json.code === 200 && Array.isArray(json.data) && json.data.length >= 2) {
          const arAyahs = json.data[0].ayahs;
          const enAyahs = json.data[1].ayahs;
          const trAyahs = json.data[2] ? json.data[2].ayahs : [];
          const merged = arAyahs.map((a, idx) => ({
            n: a.numberInSurah,
            ar: a.text,
            tr: trAyahs[idx] ? trAyahs[idx].text : "",
            en: enAyahs[idx] ? enAyahs[idx].text : ""
          }));
          BUILTIN_QURAN_CACHE[surahId] = merged;
          return merged;
        }
      } catch (e) {}
      return null;
    }

    async function renderQuran() {
      const q = state.surahSearch.trim().toLowerCase();
      const surahListEl = document.getElementById("surah-list");
      surahListEl.innerHTML = "";
      ALL_SURAHS_META.filter(([id, name, en]) => !q || String(id) === q || name.toLowerCase().includes(q) || en.toLowerCase().includes(q)).forEach(([id, name, en, count]) => {
        const active = id === state.selectedSurahId;
        const btn = document.createElement("button");
        btn.type = "button";
        btn.dataset.surahId = id;
        btn.className = `w-full text-left px-3.5 py-2.5 rounded-xl border transition flex items-center justify-between ${
          active ? "bg-emerald-800 text-amber-50 border-emerald-900 shadow-sm" : "bg-emerald-50/40 text-emerald-950 border-emerald-900/10 hover:bg-emerald-50"
        }`;
        btn.innerHTML = `
          <div><p class="text-xs font-bold">${id}. ${escapeHtml(name)}</p><p class="text-[11px] ${active ? "text-emerald-200" : "text-emerald-700"}">${escapeHtml(en)}</p></div>
          <span class="text-[11px] font-medium ${active ? "text-amber-300" : "text-emerald-700"}">${count}v</span>
        `;
        surahListEl.appendChild(btn);
      });

      const meta = ALL_SURAHS_META.find(s => s[0] === state.selectedSurahId) || ALL_SURAHS_META[0];
      const [id, name, english, totalAyahs, revType] = meta;
      document.getElementById("quran-surah-title").textContent = `${id}. ${name} (${english})`;
      document.getElementById("quran-surah-meta").textContent = `${revType} • ${totalAyahs} Ayahs`;
      document.getElementById("quran-bismillah").classList.toggle("hidden", id === 9);

      const ayahsEl = document.getElementById("quran-ayahs-container");
      ayahsEl.innerHTML = `<p class="text-sm text-emerald-700 py-8 text-center">Loading full Surah ${escapeHtml(name)} (${totalAyahs} Ayahs)...</p>`;
      const ayahs = await loadSurahAyahs(id);
      if (state.selectedSurahId !== id) return;

      ayahsEl.innerHTML = "";
      if (!ayahs) {
        ayahsEl.innerHTML = `<div class="p-4 rounded-2xl bg-amber-50 border border-amber-300 text-xs text-amber-900">Unable to reach online Qur'an edition right now. Built-in Surahs (1, 94, 103, 108, 112–114) remain available offline.</div>`;
        return;
      }
      ayahs.forEach(a => {
        const key = `${id}:${a.n}`;
        const bookmarked = state.bookmarkedAyahs.includes(key);
        const card = document.createElement("div");
        card.className = "p-4 rounded-2xl border border-emerald-900/10 bg-emerald-50/25 space-y-2";
        card.innerHTML = `
          <div class="flex items-center justify-between">
            <span class="px-2.5 py-0.5 rounded-lg bg-emerald-900 text-amber-200 text-xs font-bold">${id}:${a.n}</span>
            <button type="button" data-bookmark-ayah="${key}" class="text-xs font-semibold ${bookmarked ? "text-amber-600" : "text-emerald-700"}">${bookmarked ? "Bookmarked ★" : "Bookmark ☆"}</button>
          </div>
          <p class="font-arabic text-emerald-950" style="font-size:${state.arabicFontSize}px">${a.ar} ۝</p>
          ${state.showTranslit && a.tr ? `<p class="text-xs italic text-emerald-800">${escapeHtml(a.tr)}</p>` : ""}
          ${state.showTranslation && a.en ? `<p class="text-sm text-emerald-950 leading-relaxed">${escapeHtml(a.en)}</p>` : ""}
        `;
        ayahsEl.appendChild(card);
      });
    }

    // ---------- Event Listeners ----------
    document.querySelectorAll("[data-open-view]").forEach(btn => {
      btn.addEventListener("click", () => openView(btn.dataset.openView));
    });
    document.getElementById("btn-go-home").addEventListener("click", () => openView("home"));
    document.getElementById("btn-back-home").addEventListener("click", () => openView("home"));

    document.getElementById("form-add-app").addEventListener("submit", e => {
      e.preventDefault();
      const input = document.getElementById("input-new-app");
      const name = input.value.trim();
      if (!name) return;
      const category = document.getElementById("select-new-app-cat").value;
      state.apps.unshift({ id: "app_" + Date.now(), name, category, restricted: true, remaining: 240, blocked: false });
      input.value = "";
      saveState();
      renderAppControl();
      showToast(`Added ${name} with 4-minute restriction`);
    });

    document.getElementById("app-list-container").addEventListener("click", e => {
      const btn = e.target.closest("button[data-action]");
      if (!btn) return;
      const id = btn.dataset.id;
      const action = btn.dataset.action;
      const app = state.apps.find(a => a.id === id);
      if (!app) return;
      if (action === "toggle-restrict") {
        app.restricted = !app.restricted;
        if (!app.restricted) { app.blocked = false; app.remaining = 240; if (activeSessionAppId === id) { clearInterval(timerInterval); activeSessionAppId = null; } }
        saveState();
        renderAppControl();
        showToast(`${app.name}: ${app.restricted ? "Restricted (4m limit)" : "Allowed by your choice"}`);
      } else if (action === "launch") startAppTimer(id);
    });

    document.getElementById("shield-list").addEventListener("change", e => {
      const cb = e.target.closest("input[data-shield-id]");
      if (!cb) return;
      const sh = state.shields.find(s => s.id === cb.dataset.shieldId);
      if (sh) { sh.enabled = cb.checked; saveState(); renderAppControl(); }
    });

    document.getElementById("btn-reset-all-timers").addEventListener("click", () => {
      clearInterval(timerInterval);
      activeSessionAppId = null;
      state.apps.forEach(a => { a.remaining = 240; a.blocked = false; });
      saveState();
      renderAppControl();
      showToast("All 4-minute timers reset");
    });

    document.querySelectorAll(".speed-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        timerSpeed = Number(btn.dataset.speed);
        document.querySelectorAll(".speed-btn").forEach(b => { b.classList.remove("bg-amber-400", "text-emerald-950"); b.classList.add("text-amber-100"); });
        btn.classList.add("bg-amber-400", "text-emerald-950");
        btn.classList.remove("text-amber-100");
        if (activeSessionAppId && !timerPaused) startAppTimer(activeSessionAppId);
        else updateActiveTimerUI();
      });
    });

    document.getElementById("btn-timer-toggle").addEventListener("click", () => { timerPaused = !timerPaused; updateActiveTimerUI(); });
    document.getElementById("btn-timer-stop").addEventListener("click", () => { clearInterval(timerInterval); activeSessionAppId = null; renderAppControl(); });

    document.getElementById("btn-blocked-close").addEventListener("click", () => document.getElementById("modal-blocked").classList.add("hidden"));
    document.getElementById("btn-blocked-to-duas").addEventListener("click", () => { document.getElementById("modal-blocked").classList.add("hidden"); openView("duas"); });
    document.getElementById("btn-blocked-to-quran").addEventListener("click", () => { document.getElementById("modal-blocked").classList.add("hidden"); openView("quran"); });

    document.getElementById("select-city").addEventListener("change", e => { state.city = e.target.value; saveState(); renderSalahAndGuide(); });
    document.getElementById("slider-compass-heading").addEventListener("input", e => { compassHeading = Number(e.target.value); updateCompassUI(); });

    document.getElementById("btn-enable-compass").addEventListener("click", async () => {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(pos => {
          qiblaBearing = computeQiblaBearing(pos.coords.latitude, pos.coords.longitude);
          updateCompassUI();
          showToast(`GPS Qibla updated: ${qiblaBearing}°`);
        }, () => showToast("Using selected city coordinates for Qibla"));
      }
      if (typeof DeviceOrientationEvent !== "undefined" && typeof DeviceOrientationEvent.requestPermission === "function") {
        try { const perm = await DeviceOrientationEvent.requestPermission(); if (perm !== "granted") return; } catch (e) {}
      }
      window.addEventListener("deviceorientationabsolute", ev => {
        if (ev.alpha !== null) { compassHeading = Math.round((360 - ev.alpha) % 360); document.getElementById("slider-compass-heading").value = compassHeading; updateCompassUI(); }
      });
      window.addEventListener("deviceorientation", ev => {
        if (typeof ev.webkitCompassHeading === "number") { compassHeading = Math.round(ev.webkitCompassHeading); document.getElementById("slider-compass-heading").value = compassHeading; updateCompassUI(); }
      });
      showToast("Compass & GPS position active");
    });

    document.getElementById("salah-schedule-list").addEventListener("change", e => {
      const cb = e.target.closest("input[data-salah]");
      if (!cb) return;
      state.salahDone[cb.dataset.salah] = cb.checked;
      saveState();
      renderSalahAndGuide();
    });

    document.getElementById("hidden-prayer-steps").addEventListener("click", e => {
      const btn = e.target.closest("button[data-step-id]");
      if (!btn) return;
      const id = Number(btn.dataset.stepId);
      if (state.reviewedSteps.includes(id)) state.reviewedSteps = state.reviewedSteps.filter(x => x !== id);
      else state.reviewedSteps.push(id);
      saveState();
      renderSalahAndGuide();
    });

    document.getElementById("select-tasbih").addEventListener("change", e => { state.tasbihPhraseIdx = Number(e.target.value); saveState(); renderTasbih(); });
    document.querySelectorAll(".tasbih-target-btn").forEach(btn => {
      btn.addEventListener("click", () => { state.tasbihTarget = Number(btn.dataset.tasbihTarget); saveState(); renderTasbih(); });
    });
    document.getElementById("btn-tasbih-inc").addEventListener("click", () => {
      state.tasbihCount += 1;
      if (state.tasbihCount === state.tasbihTarget) showToast(`MashaAllah! Completed ${state.tasbihTarget} Tasbih`);
      saveState();
      renderTasbih();
    });
    document.getElementById("btn-tasbih-reset").addEventListener("click", () => { state.tasbihCount = 0; saveState(); renderTasbih(); });

    document.getElementById("dua-categories").addEventListener("click", e => {
      const btn = e.target.closest("button[data-dua-cat]");
      if (!btn) return;
      state.duaCategory = btn.dataset.duaCat;
      saveState();
      renderDuas();
    });
    document.getElementById("input-dua-search").addEventListener("input", e => { state.duaSearch = e.target.value; renderDuas(); });
    document.getElementById("dua-list").addEventListener("click", e => {
      const favBtn = e.target.closest("button[data-fav-dua]");
      if (favBtn) {
        const id = favBtn.dataset.favDua;
        if (state.duaFavs.includes(id)) state.duaFavs = state.duaFavs.filter(x => x !== id);
        else state.duaFavs.push(id);
        saveState();
        renderDuas();
        return;
      }
      const copyBtn = e.target.closest("button[data-copy-dua]");
      if (copyBtn) {
        const dua = DUAS_DATA.find(d => d.id === copyBtn.dataset.copyDua);
        if (!dua) return;
        const text = `${dua.title}\n${dua.arabic}\n${dua.translit}\n${dua.meaning}`;
        if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(() => showToast("Dua copied")).catch(() => fallbackCopy(text));
        else fallbackCopy(text);
      }
    });
    function fallbackCopy(text) {
      const ta = document.createElement("textarea");
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      try { document.execCommand("copy"); showToast("Dua copied"); } catch (e) {}
      document.body.removeChild(ta);
    }

    document.getElementById("input-surah-search").addEventListener("input", e => { state.surahSearch = e.target.value; renderQuran(); });
    document.getElementById("surah-list").addEventListener("click", e => {
      const btn = e.target.closest("button[data-surah-id]");
      if (!btn) return;
      state.selectedSurahId = Number(btn.dataset.surahId);
      saveState();
      renderQuran();
    });
    document.getElementById("toggle-translit").addEventListener("change", e => { state.showTranslit = e.target.checked; saveState(); renderQuran(); });
    document.getElementById("toggle-translation").addEventListener("change", e => { state.showTranslation = e.target.checked; saveState(); renderQuran(); });
    document.getElementById("btn-font-dec").addEventListener("click", () => { state.arabicFontSize = Math.max(18, state.arabicFontSize - 2); saveState(); renderQuran(); });
    document.getElementById("btn-font-inc").addEventListener("click", () => { state.arabicFontSize = Math.min(40, state.arabicFontSize + 2); saveState(); renderQuran(); });
    document.getElementById("quran-ayahs-container").addEventListener("click", e => {
      const btn = e.target.closest("button[data-bookmark-ayah]");
      if (!btn) return;
      const key = btn.dataset.bookmarkAyah;
      if (state.bookmarkedAyahs.includes(key)) state.bookmarkedAyahs = state.bookmarkedAyahs.filter(k => k !== key);
      else state.bookmarkedAyahs.push(key);
      saveState();
      renderQuran();
    });

    // ---------- Init ----------
    openView(state.activeView || "home");
    renderAppControl();
    renderSalahAndGuide();
    renderTasbih();
    renderDuas();
    renderHadithAndCalendar();
    renderQuran();
    setInterval(updateSalahClock, 1000);