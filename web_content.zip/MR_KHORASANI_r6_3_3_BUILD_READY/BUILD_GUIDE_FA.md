# راهنمای آماده‌سازی و Build — MR KHORASANI r6.3.3

## ریشه پروژه

این ZIP اصلاح شده و تمام فایل‌های پروژه در ریشه پوشه قرار دارند؛ دیگر مسیر `auth_work/src` برای Build لازم نیست.

## پیش‌نیازها

- Node.js 22+
- npm 10.9+
- Android Studio سازگار با Capacitor 8، Android SDK و Platform Tools (API 24+)
- JDK سازگار با Gradle؛ JBR همراه Android Studio پیشنهاد می‌شود.
- اتصال اینترنت برای نصب وابستگی‌های npm و دریافت Gradle/SDK

## Windows

```bat
build-android.bat
```

## Linux/macOS

```bash
chmod +x build-android.sh
./build-android.sh
```

## اجرای دستی

```bash
npm install
npm test
npm run check
npm run auth:build
npm run android:debug
```

`android:debug` ابتدا دارایی‌های Web را آماده می‌کند، کتابخانه ذخیره‌سازی امن را با esbuild از افزونه بومی Bundle می‌کند، سپس Capacitor Android را اضافه/همگام می‌کند و Gradle را برای APK دیباگ اجرا می‌کند.

## خروجی

`dist/MR-KHORASANI-r6.3.3-secure-auth-debug.apk`

فایل هش SHA-256 کنار آن ایجاد می‌شود.

## package-lock.json

فایل lock داخل بسته نیست، چون محیط آماده‌سازی امکان دسترسی به رجیستری npm را نداشت. اولین `npm install` وابستگی‌های مستقیم pin‌شده را نصب می‌کند و lockfile می‌سازد؛ اجراهای بعدی اسکریپت از `npm ci` استفاده خواهند کرد.

## موارد لازم قبل از انتشار

1. شناسه و کلید Publishable پروژه Supabase عملیاتی را در تنظیمات برنامه با مقدارهای واقعی مقصد تطبیق دهید.
2. قالب OTP ایمیل Supabase را مطابق راهنمای `AUTH_RECOVERY_FA.md` تنظیم کنید.
3. در Android Studio نسخه Release را با کلید امضای اختصاصی خود امضا کنید. APK debug برای انتشار عمومی مناسب نیست.
4. کنترل نقش و RLS را روی پروژه واقعی Supabase تست کنید.

هیچ Service Role یا Secret Key نباید داخل برنامه موبایل قرار بگیرد.

## وضعیت بررسی این بسته

تست‌های Node و بررسی نحوی در محیط آماده‌سازی قابل اجرا هستند. کامپایل APK واقعی در این محیط انجام نشده، چون Android SDK و Gradle نصب نیستند.
