import { createClient } from 'npm:@supabase/supabase-js@2.119.2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, apikey, content-type, x-client-info',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Content-Type': 'application/json; charset=utf-8',
  'Cache-Control': 'no-store',
};
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: corsHeaders });
const COMPANY_ID = 'c74889aa-321f-42e6-8cad-856d84cd415a';

function cleanText(value: unknown, max = 180): string {
  return String(value ?? '').trim().slice(0, max);
}
function positiveIntOrNull(value: unknown): number | null {
  if (value === null || value === undefined || value === '') return null;
  const n = Number(value);
  return Number.isSafeInteger(n) && n >= 0 ? n : null;
}
async function insertBatches(client: any, table: string, rows: any[], conflict: string) {
  for (let i = 0; i < rows.length; i += 400) {
    const { error } = await client.from(table).upsert(rows.slice(i, i + 400), { onConflict: conflict, ignoreDuplicates: true });
    if (error) throw error;
  }
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') return new Response('ok', { status: 204, headers: corsHeaders });
  if (req.method !== 'POST') return json({ ok: false, error: 'روش درخواست مجاز نیست.' }, 405);

  const url = Deno.env.get('SUPABASE_URL') || '';
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '';
  if (!url || !serviceKey) return json({ ok: false, error: 'پیکربندی امن تابع ناقص است.' }, 500);

  const authHeader = req.headers.get('Authorization') || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : '';
  if (!token) return json({ ok: false, error: 'نشست احراز هویت معتبر نیست.' }, 401);

  const service = createClient(url, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data: authData, error: authError } = await service.auth.getUser(token);
  if (authError || !authData.user) return json({ ok: false, error: 'نشست کاربر معتبر نیست.' }, 401);

  let body: Record<string, any>;
  try { body = await req.json(); } catch { return json({ ok: false, error: 'بدنه درخواست JSON معتبر نیست.' }, 400); }

  const { data: actor, error: profileError } = await service.from('mrk_user_profiles')
    .select('user_id,company_id,role,booth_code,can_manage_users,is_active')
    .eq('user_id', authData.user.id).maybeSingle();
  if (profileError || !actor?.is_active || !actor.can_manage_users) {
    return json({ ok: false, error: 'این عملیات فقط برای مدیر مجاز سامانه مجاز است.' }, 403);
  }

  const companyId = actor.company_id;
  if (companyId !== COMPANY_ID || (body.company_id && body.company_id !== companyId)) {
    return json({ ok: false, error: 'شناسه سازمان با مجوز فعلی تطبیق ندارد.' }, 403);
  }

  try {
    if (body.action === 'bootstrap_catalog') {
      const boothsIn = Array.isArray(body.booths) ? body.booths : [];
      const posIn = Array.isArray(body.pos) ? body.pos : [];
      const productsIn = Array.isArray(body.products) ? body.products : [];
      const stockIn = Array.isArray(body.stock_rows) ? body.stock_rows : [];
      if (boothsIn.length !== 13 || posIn.length !== 20 || productsIn.length < 1 || productsIn.length > 500 || stockIn.length > 5000) {
        return json({ ok: false, error: 'حجم یا تعداد اطلاعات پایه با الگوی نسخه r6 سازگار نیست.' }, 422);
      }
      const booths = boothsIn.map((b: any) => ({
        company_id: companyId, code: cleanText(b.code, 12), name: cleanText(b.name, 100),
        inventory_rows: positiveIntOrNull(b.inventoryRows) ?? 0,
        missing_opening_qty: positiveIntOrNull(b.missingOpeningQty) ?? 0,
        counted_opening_qty: positiveIntOrNull(b.countedOpeningQty) ?? 0,
        product_count: positiveIntOrNull(b.productCount) ?? 0,
        status: cleanText(b.status, 180), is_active: true,
      }));
      const pos = posIn.map((p: any) => ({
        company_id: companyId, code: cleanText(p.code, 24), holder: cleanText(p.holder, 100),
        booth_code: p.boothCode ? cleanText(p.boothCode, 12) : null, status: cleanText(p.status, 100), is_active: true,
      }));
      const products = productsIn.map((p: any) => ({
        company_id: companyId, product_key: cleanText(p.key, 180), product_code: Number(p.code),
        name: cleanText(p.name, 220), normalized_name: cleanText(p.normalizedName || p.name, 220),
        price: positiveIntOrNull(p.price), candidate_price: positiveIntOrNull(p.candidatePrice),
        price_status: cleanText(p.priceStatus, 80), price_conflict: p.priceConflict === true,
        source_names: Array.isArray(p.sourceNames) ? p.sourceNames.slice(0, 20).map((x: unknown) => cleanText(x, 220)) : [],
        unit: cleanText(p.unit, 40), unit_status: cleanText(p.unitStatus, 80),
        code_conflict: p.codeConflict === true, same_name_multiple_codes: p.sameNameMultipleCodes === true,
        sale_blocked: p.saleBlocked === true, is_active: true,
      }));
      if (products.some((p: any) => !p.product_key || !p.name || !Number.isInteger(p.product_code))) {
        return json({ ok: false, error: 'یکی از کالاهای ارسالی دارای کد یا نام نامعتبر است.' }, 422);
      }
      const boothProducts = stockIn.map((s: any) => ({
        company_id: companyId, booth_code: cleanText(s.boothCode, 12), product_key: cleanText(s.productKey, 180),
        opening_qty: s.openingQty === null || s.openingQty === undefined ? null : Number(s.openingQty),
        opening_status: cleanText(s.openingStatus, 80), source_row: positiveIntOrNull(s.sourceRow),
      }));
      if (boothProducts.some((s: any) => !s.booth_code || !s.product_key || (s.opening_qty !== null && (!Number.isFinite(s.opening_qty) || s.opening_qty < 0)))) {
        return json({ ok: false, error: 'اطلاعات موجودی اولیه شامل مقدار نامعتبر است.' }, 422);
      }

      // Insert-only bootstrap: reruns never reset operational data or balances.
      await insertBatches(service, 'mrk_booths', booths, 'code');
      await insertBatches(service, 'mrk_pos_terminals', pos, 'code');
      await insertBatches(service, 'mrk_products', products, 'product_key');
      await insertBatches(service, 'mrk_booth_products', boothProducts, 'booth_code,product_key');
      const balances = boothProducts.map((s: any) => ({
        company_id: companyId, booth_code: s.booth_code, product_key: s.product_key,
        quantity: s.opening_qty, is_known: s.opening_qty !== null,
      }));
      balances.push(...products.map((p: any) => ({ company_id: companyId, booth_code: 'CENTRAL', product_key: p.product_key, quantity: 0, is_known: true })));
      await insertBatches(service, 'mrk_stock_balances', balances, 'booth_code,product_key');
      return json({ ok: true, booths: booths.length, terminals: pos.length, products: products.length, boothProducts: boothProducts.length, stockBalances: balances.length });
    }

    if (body.action === 'list_users') {
      const { data, error } = await service.from('mrk_user_profiles')
        .select('user_id,user_code,display_name,email,role,booth_code,can_manage_users,is_active,created_at')
        .eq('company_id', companyId).order('created_at');
      if (error) throw error;
      return json({ ok: true, users: data || [] });
    }

    if (body.action === 'create_user') {
      const email = cleanText(body.email, 254).toLowerCase();
      const displayName = cleanText(body.display_name, 100);
      const userCode = cleanText(body.user_code, 24).toUpperCase();
      const role = body.role === 'booth' ? 'booth' : body.role === 'accountant' ? 'accountant' : '';
      const boothCode = role === 'booth' ? cleanText(body.booth_code, 12) : null;
      const password = String(body.password || '');
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || password.length < 12 || !displayName || !/^[A-Z0-9-]{2,24}$/.test(userCode) || !role) {
        return json({ ok: false, error: 'ایمیل، نام، کد کاربر، نقش یا گذرواژه معتبر نیست. گذرواژه حداقل ۱۲ نویسه باشد.' }, 422);
      }
      if (role === 'booth') {
        const { data: booth, error } = await service.from('mrk_booths').select('code').eq('code', boothCode).eq('is_active', true).maybeSingle();
        if (error) throw error;
        if (!booth) return json({ ok: false, error: 'کد غرفه فعال در فهرست سامانه وجود ندارد.' }, 422);
      }
      const { data: created, error: createError } = await service.auth.admin.createUser({ email, password, email_confirm: true });
      if (createError) throw createError;
      const { error: insertError } = await service.from('mrk_user_profiles').insert({
        user_id: created.user.id, company_id: companyId, user_code: userCode, display_name: displayName,
        email, role, booth_code: boothCode, can_manage_users: false, is_active: true,
      });
      if (insertError) {
        await service.auth.admin.deleteUser(created.user.id);
        throw insertError;
      }
      return json({ ok: true, user: { user_id: created.user.id, user_code: userCode, display_name: displayName, email, role, booth_code: boothCode, is_active: true } });
    }

    if (body.action === 'disable_user') {
      const userId = cleanText(body.user_id, 64);
      if (!userId || userId === authData.user.id) return json({ ok: false, error: 'مدیر نمی‌تواند حساب خودش را از این مسیر غیرفعال کند.' }, 422);
      const { data: target, error: targetError } = await service.from('mrk_user_profiles').select('user_id').eq('user_id', userId).eq('company_id', companyId).maybeSingle();
      if (targetError) throw targetError;
      if (!target) return json({ ok: false, error: 'کاربر در سازمان انتخاب‌شده یافت نشد.' }, 404);
      const { error } = await service.from('mrk_user_profiles').update({ is_active: false, can_manage_users: false, updated_at: new Date().toISOString() }).eq('user_id', userId);
      if (error) throw error;
      return json({ ok: true, disabled: userId });
    }

    return json({ ok: false, error: 'عملیات درخواست‌شده تعریف نشده است.' }, 400);
  } catch (error) {
    console.error('mrk-admin operation failed:', error?.message || error);
    return json({ ok: false, error: 'عملیات مدیریتی انجام نشد؛ جزئیات حساس سرور منتشر نمی‌شود.' }, 500);
  }
});
