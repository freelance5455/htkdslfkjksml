-- MR,KHORASANI r6 cloud sync/security migration
-- Additive only: does not alter or delete the existing accounting schema/data.
-- Target company: mr-khorasani-finance / MR,KHORASANI.

create schema if not exists private;
revoke all on schema private from public, anon;
grant usage on schema private to authenticated;

create table if not exists public.mrk_booths (
  code text primary key,
  company_id uuid not null default 'c74889aa-321f-42e6-8cad-856d84cd415a' references public.companies(id),
  name text not null,
  inventory_rows integer not null default 0 check (inventory_rows >= 0),
  missing_opening_qty integer not null default 0 check (missing_opening_qty >= 0),
  counted_opening_qty integer not null default 0 check (counted_opening_qty >= 0),
  product_count integer not null default 0 check (product_count >= 0),
  status text not null default '', is_active boolean not null default true,
  created_at timestamptz not null default now()
);
create table if not exists public.mrk_pos_terminals (
  code text primary key,
  company_id uuid not null default 'c74889aa-321f-42e6-8cad-856d84cd415a' references public.companies(id),
  holder text not null default '', booth_code text null references public.mrk_booths(code) on update cascade on delete restrict,
  status text not null default '', is_active boolean not null default true, created_at timestamptz not null default now()
);
create table if not exists public.mrk_products (
  product_key text primary key,
  company_id uuid not null default 'c74889aa-321f-42e6-8cad-856d84cd415a' references public.companies(id),
  product_code integer not null, name text not null, normalized_name text not null,
  price bigint null check (price is null or price >= 0), candidate_price bigint null check (candidate_price is null or candidate_price >= 0),
  price_status text not null default '', price_conflict boolean not null default false,
  source_names jsonb not null default '[]'::jsonb, unit text not null default '', unit_status text not null default '',
  code_conflict boolean not null default false, same_name_multiple_codes boolean not null default false,
  sale_blocked boolean not null default false, is_active boolean not null default true,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.mrk_booth_products (
  company_id uuid not null default 'c74889aa-321f-42e6-8cad-856d84cd415a' references public.companies(id),
  booth_code text not null references public.mrk_booths(code) on update cascade on delete restrict,
  product_key text not null references public.mrk_products(product_key) on update cascade on delete restrict,
  opening_qty numeric null check (opening_qty is null or opening_qty >= 0),
  opening_status text not null default '', source_row integer null,
  primary key (booth_code, product_key)
);

create table if not exists public.mrk_user_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  company_id uuid not null default 'c74889aa-321f-42e6-8cad-856d84cd415a' references public.companies(id),
  user_code text not null unique, display_name text not null, email text not null,
  role text not null check (role in ('accountant','booth')),
  booth_code text null references public.mrk_booths(code) on update cascade on delete restrict,
  can_manage_users boolean not null default false,
  is_active boolean not null default true,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  constraint mrk_user_role_booth_check check (
    (role = 'accountant' and booth_code is null) or (role = 'booth' and booth_code is not null)
  )
);

create table if not exists public.mrk_stock_balances (
  company_id uuid not null default 'c74889aa-321f-42e6-8cad-856d84cd415a' references public.companies(id),
  booth_code text not null, product_key text not null references public.mrk_products(product_key),
  quantity numeric null check (quantity is null or quantity >= 0),
  is_known boolean not null default true, revision bigint not null default 0,
  updated_at timestamptz not null default now(),
  primary key (booth_code, product_key)
);

create table if not exists public.mrk_sync_events (
  seq bigint generated always as identity unique,
  event_id uuid primary key,
  company_id uuid not null references public.companies(id),
  booth_code text null,
  event_type text not null check (event_type in (
    'sale_bundle','booth_closure','purchase_bundle','warehouse_transfer_bundle','warehouse_transfer_in',
    'warehouse_transfer_accountant','booth_transfer_bundle','inventory_bundle','sale_return_bundle',
    'final_closure','reconciliation_bundle','product_upsert'
  )),
  entity_id text not null,
  payload jsonb not null check (pg_column_size(payload) <= 1048576),
  actor_id uuid not null references auth.users(id),
  device_id text not null check (length(trim(device_id)) between 1 and 128),
  created_at timestamptz not null default now()
);
create index if not exists mrk_sync_events_company_seq_idx on public.mrk_sync_events(company_id, seq);
create index if not exists mrk_sync_events_booth_seq_idx on public.mrk_sync_events(company_id, booth_code, seq);
create unique index if not exists mrk_purchase_invoice_unique_idx
  on public.mrk_sync_events(company_id, lower(payload->'purchase'->>'invoiceNo'))
  where event_type='purchase_bundle';

-- Map only already-authorized company members. No local demo PINs or arbitrary Auth users are imported.
insert into public.mrk_user_profiles(user_id, company_id, user_code, display_name, email, role, booth_code, can_manage_users, is_active)
select cm.user_id, cm.company_id,
       'ACC-' || upper(substr(replace(cm.user_id::text,'-',''),1,8)),
       coalesce(nullif(cup.display_name,''), nullif(u.email,''), 'حسابدار'), u.email,
       'accountant', null, (cm.role in ('OWNER','ADMIN')), cm.is_active
from public.company_members cm
join auth.users u on u.id=cm.user_id
left join public.company_user_profiles cup on cup.user_id=cm.user_id and cup.company_id=cm.company_id
where cm.company_id='c74889aa-321f-42e6-8cad-856d84cd415a'
  and cm.is_active=true and cm.role in ('OWNER','ADMIN','FINANCE','ACCOUNTANT')
on conflict (user_id) do nothing;

-- Build server-authoritative opening balances from source opening data. NULL remains unknown, not zero.
insert into public.mrk_stock_balances(company_id,booth_code,product_key,quantity,is_known)
select bp.company_id,bp.booth_code,bp.product_key,bp.opening_qty,(bp.opening_qty is not null)
from public.mrk_booth_products bp
on conflict (booth_code,product_key) do nothing;
insert into public.mrk_stock_balances(company_id,booth_code,product_key,quantity,is_known)
select p.company_id,'CENTRAL',p.product_key,0,true from public.mrk_products p
on conflict (booth_code,product_key) do nothing;

create or replace function private.mrk_current_company_id()
returns uuid language sql stable security definer set search_path = ''
as $$ select p.company_id from public.mrk_user_profiles p where p.user_id=(select auth.uid()) and p.is_active limit 1 $$;
create or replace function private.mrk_current_role()
returns text language sql stable security definer set search_path = ''
as $$ select p.role from public.mrk_user_profiles p where p.user_id=(select auth.uid()) and p.is_active limit 1 $$;
create or replace function private.mrk_current_booth_code()
returns text language sql stable security definer set search_path = ''
as $$ select p.booth_code from public.mrk_user_profiles p where p.user_id=(select auth.uid()) and p.is_active limit 1 $$;
create or replace function private.mrk_is_active_user()
returns boolean language sql stable security definer set search_path = ''
as $$ select exists(select 1 from public.mrk_user_profiles p where p.user_id=(select auth.uid()) and p.is_active) $$;
create or replace function private.mrk_is_accountant()
returns boolean language sql stable security definer set search_path = ''
as $$ select coalesce(private.mrk_current_role()='accountant',false) $$;
create or replace function private.mrk_can_manage_users()
returns boolean language sql stable security definer set search_path = ''
as $$ select exists(select 1 from public.mrk_user_profiles p where p.user_id=(select auth.uid()) and p.is_active and p.can_manage_users) $$;
revoke all on all functions in schema private from public, anon;
grant execute on function private.mrk_current_company_id() to authenticated;
grant execute on function private.mrk_current_role() to authenticated;
grant execute on function private.mrk_current_booth_code() to authenticated;
grant execute on function private.mrk_is_active_user() to authenticated;
grant execute on function private.mrk_is_accountant() to authenticated;
grant execute on function private.mrk_can_manage_users() to authenticated;

alter table public.mrk_booths enable row level security;
alter table public.mrk_pos_terminals enable row level security;
alter table public.mrk_products enable row level security;
alter table public.mrk_booth_products enable row level security;
alter table public.mrk_user_profiles enable row level security;
alter table public.mrk_stock_balances enable row level security;
alter table public.mrk_sync_events enable row level security;

-- Policies are intentionally scoped to the authenticated server profile, not user-editable JWT metadata.
drop policy if exists mrk_booths_read_scoped on public.mrk_booths;
create policy mrk_booths_read_scoped on public.mrk_booths for select to authenticated
using (company_id=private.mrk_current_company_id() and (private.mrk_is_accountant() or code=private.mrk_current_booth_code()));
drop policy if exists mrk_pos_read_scoped on public.mrk_pos_terminals;
create policy mrk_pos_read_scoped on public.mrk_pos_terminals for select to authenticated
using (company_id=private.mrk_current_company_id() and (private.mrk_is_accountant() or booth_code=private.mrk_current_booth_code()));
drop policy if exists mrk_products_read_scoped on public.mrk_products;
create policy mrk_products_read_scoped on public.mrk_products for select to authenticated
using (company_id=private.mrk_current_company_id() and is_active and (private.mrk_is_accountant() or exists(
  select 1 from public.mrk_booth_products bp where bp.product_key=mrk_products.product_key and bp.booth_code=private.mrk_current_booth_code()
)));
drop policy if exists mrk_booth_products_read_scoped on public.mrk_booth_products;
create policy mrk_booth_products_read_scoped on public.mrk_booth_products for select to authenticated
using (company_id=private.mrk_current_company_id() and (private.mrk_is_accountant() or booth_code=private.mrk_current_booth_code()));
drop policy if exists mrk_profiles_read_scoped on public.mrk_user_profiles;
create policy mrk_profiles_read_scoped on public.mrk_user_profiles for select to authenticated
using (user_id=(select auth.uid()) or (company_id=private.mrk_current_company_id() and private.mrk_can_manage_users()));
drop policy if exists mrk_events_read_scoped on public.mrk_sync_events;
create policy mrk_events_read_scoped on public.mrk_sync_events for select to authenticated
using (company_id=private.mrk_current_company_id() and (
  private.mrk_is_accountant() or (
    booth_code=private.mrk_current_booth_code() and event_type in
      ('sale_bundle','booth_closure','warehouse_transfer_in','booth_transfer_bundle','sale_return_bundle')
  )
));
drop policy if exists mrk_events_insert_scoped on public.mrk_sync_events;
create policy mrk_events_insert_scoped on public.mrk_sync_events for insert to authenticated
with check (company_id=private.mrk_current_company_id() and actor_id=(select auth.uid()) and private.mrk_is_active_user() and (
  private.mrk_is_accountant() or (event_type in ('sale_bundle','booth_closure') and booth_code=private.mrk_current_booth_code())
));

revoke all on public.mrk_booths, public.mrk_pos_terminals, public.mrk_products, public.mrk_booth_products,
  public.mrk_user_profiles, public.mrk_stock_balances, public.mrk_sync_events from anon, public;
grant select on public.mrk_booths, public.mrk_pos_terminals, public.mrk_products, public.mrk_booth_products,
  public.mrk_user_profiles, public.mrk_sync_events to authenticated;
grant insert on public.mrk_sync_events to authenticated;
-- Stock balance table is private to the trigger path; no client grants are issued.

create or replace function private.mrk_validate_sync_event()
returns trigger language plpgsql security definer set search_path = ''
as $$
declare
  v_role text := private.mrk_current_role();
  v_booth text := private.mrk_current_booth_code();
  v_company uuid := private.mrk_current_company_id();
  v_sale jsonb;
  v_line jsonb;
  v_payment jsonb;
  v_product public.mrk_products%rowtype;
  v_balance numeric;
  v_qty numeric;
  v_expected numeric := 0;
  v_received numeric := 0;
  v_day text;
  v_transfer jsonb;
  v_payload_movement jsonb;
begin
  if v_role is null or v_company is null or new.company_id<>v_company or new.actor_id<>(select auth.uid()) then
    raise exception 'MRK_AUTH_PROFILE_INVALID' using errcode='42501';
  end if;
  new.created_at := now();

  if v_role='booth' then
    if new.event_type not in ('sale_bundle','booth_closure') or new.booth_code is distinct from v_booth then
      raise exception 'MRK_BOOTH_EVENT_FORBIDDEN' using errcode='42501';
    end if;
    if new.event_type='sale_bundle' then
      v_sale := new.payload->'sale';
      if v_sale is null or v_sale->>'boothCode' is distinct from v_booth or v_sale->>'id' is distinct from new.entity_id then
        raise exception 'MRK_SALE_SCOPE_INVALID' using errcode='42501';
      end if;
      v_day := v_sale->>'day';
      if v_day is null or v_day<>(now() at time zone 'Asia/Tehran')::date::text then
        raise exception 'MRK_BOOTH_SALE_DATE_INVALID' using errcode='22023';
      end if;
      if jsonb_typeof(v_sale->'lines')<>'array' or jsonb_array_length(v_sale->'lines')=0 then
        raise exception 'MRK_SALE_LINES_REQUIRED' using errcode='22023';
      end if;
      for v_line in select value from jsonb_array_elements(v_sale->'lines') loop
        select * into v_product from public.mrk_products p
        join public.mrk_booth_products bp on bp.product_key=p.product_key and bp.booth_code=v_booth
        where p.product_key=v_line->>'productKey' and p.company_id=v_company and p.is_active;
        if not found or v_product.sale_blocked or v_product.price_conflict or v_product.price is null
          or (v_line->>'unitPrice')::numeric<>v_product.price then
          raise exception 'MRK_PRODUCT_NOT_ASSIGNED_OR_PRICE_INVALID' using errcode='22023';
        end if;
        v_qty := (v_line->>'qty')::numeric;
        if v_qty<=0 or (v_product.unit<>'کیلوگرم' and v_qty<>trunc(v_qty)) then
          raise exception 'MRK_SALE_QUANTITY_INVALID' using errcode='22023';
        end if;
        if round(v_qty*v_product.price)::bigint<>(v_line->>'lineTotal')::bigint then
          raise exception 'MRK_SALE_LINE_TOTAL_INVALID' using errcode='22023';
        end if;
        v_expected := v_expected + round(v_qty*v_product.price);
        perform pg_advisory_xact_lock(hashtextextended(v_booth||':'||v_product.product_key,0));
        select quantity into v_balance from public.mrk_stock_balances
          where booth_code=v_booth and product_key=v_product.product_key for update;
        if not found or v_balance is null or v_balance<v_qty then
          raise exception 'MRK_SERVER_STOCK_INSUFFICIENT_OR_UNKNOWN: %',v_product.name using errcode='22023';
        end if;
      end loop;
      if v_expected<>(v_sale->>'expectedAmount')::numeric then raise exception 'MRK_SALE_TOTAL_INVALID' using errcode='22023'; end if;
      if jsonb_typeof(v_sale->'payments')<>'array' then raise exception 'MRK_SALE_PAYMENTS_INVALID' using errcode='22023'; end if;
      for v_payment in select value from jsonb_array_elements(v_sale->'payments') loop
        if v_payment->>'type' not in ('POS','CASH','PERSONNEL') or (v_payment->>'amount')::numeric<=0 then
          raise exception 'MRK_PAYMENT_INVALID' using errcode='22023';
        end if;
        if v_payment->>'type'='POS' and not exists(select 1 from public.mrk_pos_terminals t where t.code=v_payment->>'posCode' and t.booth_code=v_booth and t.is_active) then
          raise exception 'MRK_POS_NOT_ASSIGNED' using errcode='22023';
        end if;
        v_received := v_received + (v_payment->>'amount')::numeric;
      end loop;
      if v_received<>(v_sale->>'totalReceived')::numeric or v_received>v_expected then raise exception 'MRK_PAYMENT_TOTAL_INVALID' using errcode='22023'; end if;
      -- Lock and decrement only after all sale lines and payments have passed validation.
      for v_line in select value from jsonb_array_elements(v_sale->'lines') order by value->>'productKey' loop
        update public.mrk_stock_balances set quantity=quantity-(v_line->>'qty')::numeric, revision=revision+1, updated_at=now()
          where booth_code=v_booth and product_key=v_line->>'productKey';
      end loop;
      -- One tracking reference cannot be reused for the same booth/POS/business date.
      for v_payment in select value from jsonb_array_elements(v_sale->'payments') where value->>'type'='POS' loop
        perform pg_advisory_xact_lock(hashtextextended(v_day||':'||v_payment->>'posCode'||':'||v_payment->>'trackingCode',0));
        if exists(select 1 from public.mrk_sync_events e, lateral jsonb_array_elements(e.payload->'sale'->'payments') p
          where e.event_type='sale_bundle' and e.booth_code=v_booth and e.payload->'sale'->>'day'=v_day
            and p.value->>'type'='POS' and p.value->>'posCode'=v_payment->>'posCode' and p.value->>'trackingCode'=v_payment->>'trackingCode') then
          raise exception 'MRK_DUPLICATE_POS_TRACKING' using errcode='23505';
        end if;
      end loop;
    else
      if new.payload->'closure'->>'boothCode' is distinct from v_booth or new.payload->'closure'->>'day' is distinct from (now() at time zone 'Asia/Tehran')::date::text then
        raise exception 'MRK_CLOSURE_SCOPE_INVALID' using errcode='42501';
      end if;
      if exists(select 1 from public.mrk_sync_events e where e.event_type='booth_closure' and e.booth_code=v_booth and e.payload->'closure'->>'day'=new.payload->'closure'->>'day') then
        raise exception 'MRK_BOOTH_ALREADY_CLOSED' using errcode='23505';
      end if;
    end if;
  else
    -- Accountant-only financial/inventory actions. Keep event scope company-bound.
    if new.event_type='purchase_bundle' then
      for v_line in select value from jsonb_array_elements(new.payload->'purchase'->'lines') loop
        v_qty := (v_line->>'qty')::numeric;
        if v_qty<=0 or not exists(select 1 from public.mrk_products where product_key=v_line->>'productKey' and company_id=v_company and is_active) then
          raise exception 'MRK_PURCHASE_LINE_INVALID' using errcode='22023';
        end if;
        insert into public.mrk_stock_balances(company_id,booth_code,product_key,quantity,is_known)
        values(v_company,'CENTRAL',v_line->>'productKey',v_qty,true)
        on conflict (booth_code,product_key) do update set quantity=coalesce(public.mrk_stock_balances.quantity,0)+excluded.quantity,is_known=true,revision=public.mrk_stock_balances.revision+1,updated_at=now();
      end loop;
    elsif new.event_type='warehouse_transfer_bundle' then
      v_transfer := new.payload->'transfer';
      if v_transfer->>'from'<>'CENTRAL' or not exists(select 1 from public.mrk_booths where code=v_transfer->>'to' and is_active) then raise exception 'MRK_WAREHOUSE_TRANSFER_INVALID' using errcode='22023'; end if;
      v_qty := (v_transfer->>'qty')::numeric;
      perform pg_advisory_xact_lock(hashtextextended('CENTRAL:'||v_transfer->>'productKey',0));
      select quantity into v_balance from public.mrk_stock_balances where booth_code='CENTRAL' and product_key=v_transfer->>'productKey' for update;
      if not found or v_balance is null or v_balance<v_qty then raise exception 'MRK_CENTRAL_STOCK_INSUFFICIENT' using errcode='22023'; end if;
      update public.mrk_stock_balances set quantity=quantity-v_qty,revision=revision+1,updated_at=now() where booth_code='CENTRAL' and product_key=v_transfer->>'productKey';
      insert into public.mrk_stock_balances(company_id,booth_code,product_key,quantity,is_known)
      values(v_company,v_transfer->>'to',v_transfer->>'productKey',v_qty,true)
      on conflict (booth_code,product_key) do update set quantity=coalesce(public.mrk_stock_balances.quantity,0)+excluded.quantity,is_known=true,revision=public.mrk_stock_balances.revision+1,updated_at=now();
    elsif new.event_type='inventory_bundle' then
      v_payload_movement := new.payload->'movement';
      v_qty := coalesce((v_payload_movement->>'countedQty')::numeric,(v_payload_movement->>'delta')::numeric,0);
      if v_payload_movement->>'type'='COUNT' then
        update public.mrk_stock_balances set quantity=(v_payload_movement->>'countedQty')::numeric,is_known=true,revision=revision+1,updated_at=now()
        where booth_code=v_payload_movement->>'boothCode' and product_key=v_payload_movement->>'productKey';
      else
        update public.mrk_stock_balances set quantity=quantity+v_qty,revision=revision+1,updated_at=now()
        where booth_code=v_payload_movement->>'boothCode' and product_key=v_payload_movement->>'productKey' and quantity is not null;
      end if;
    elsif new.event_type='sale_return_bundle' then
      for v_line in select value from jsonb_array_elements(new.payload->'movements') loop
        update public.mrk_stock_balances set quantity=quantity+(v_line->>'delta')::numeric,revision=revision+1,updated_at=now()
          where booth_code=v_line->>'boothCode' and product_key=v_line->>'productKey' and quantity is not null;
      end loop;
    elsif new.event_type='booth_transfer_bundle' then
      for v_line in select value from jsonb_array_elements(new.payload->'movements') loop
        update public.mrk_stock_balances set quantity=quantity+(v_line->>'delta')::numeric,revision=revision+1,updated_at=now()
          where booth_code=v_line->>'boothCode' and product_key=v_line->>'productKey' and quantity is not null;
      end loop;
    end if;
  end if;
  return new;
end $$;
revoke all on function private.mrk_validate_sync_event() from public, anon, authenticated;
drop trigger if exists mrk_validate_sync_event_before_insert on public.mrk_sync_events;
create trigger mrk_validate_sync_event_before_insert before insert on public.mrk_sync_events
for each row execute function private.mrk_validate_sync_event();

-- The application writes immutable events only. Direct mutation/deletion is not granted.
revoke update, delete on public.mrk_sync_events from anon, authenticated, public;
grant usage, select on sequence public.mrk_sync_events_seq_seq to authenticated;

do $$ begin
  if exists(select 1 from pg_publication where pubname='supabase_realtime')
    and not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='mrk_sync_events') then
    alter publication supabase_realtime add table public.mrk_sync_events;
  end if;
end $$;
