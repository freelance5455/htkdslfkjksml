-- MR KHORASANI | Supabase schema draft
-- IMPORTANT: Prepared locally only. NOT applied to any Supabase project.
-- Review the target project's existing schema before running this file.
-- No DROP/TRUNCATE statements are used.

create table public.mrk_booths (
  code text primary key,
  name text not null,
  inventory_rows integer not null default 0 check (inventory_rows >= 0),
  missing_opening_qty integer not null default 0 check (missing_opening_qty >= 0),
  counted_opening_qty integer not null default 0 check (counted_opening_qty >= 0),
  product_count integer not null default 0 check (product_count >= 0),
  status text not null default '',
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.mrk_pos_terminals (
  code text primary key,
  holder text not null default '',
  booth_code text null references public.mrk_booths(code) on update cascade on delete restrict,
  status text not null default '',
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.mrk_products (
  product_key text primary key,
  product_code integer not null,
  name text not null,
  normalized_name text not null,
  price bigint null check (price is null or price >= 0),
  candidate_price bigint null check (candidate_price is null or candidate_price >= 0),
  price_status text not null default '',
  price_conflict boolean not null default false,
  source_names jsonb not null default '[]'::jsonb,
  unit text not null default '',
  unit_status text not null default '',
  code_conflict boolean not null default false,
  same_name_multiple_codes boolean not null default false,
  sale_blocked boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.mrk_booth_products (
  booth_code text not null references public.mrk_booths(code) on update cascade on delete restrict,
  product_key text not null references public.mrk_products(product_key) on update cascade on delete restrict,
  opening_qty numeric null check (opening_qty is null or opening_qty >= 0),
  opening_status text not null default '',
  source_row integer null,
  primary key (booth_code, product_key)
);

-- One Auth user maps to one internal user code/role. PINs are never stored here.
create table public.mrk_user_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  user_code text not null unique,
  display_name text not null,
  role text not null check (role in ('accountant','booth')),
  booth_code text null references public.mrk_booths(code) on update cascade on delete restrict,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint mrk_user_role_booth_check check (
    (role = 'accountant' and booth_code is null) or
    (role = 'booth' and booth_code is not null)
  )
);

create table public.mrk_sales (
  id uuid primary key,
  booth_code text not null references public.mrk_booths(code) on update cascade on delete restrict,
  pos_code text not null references public.mrk_pos_terminals(code) on update cascade on delete restrict,
  business_date date not null,
  created_at timestamptz not null default now(),
  tracking_code text not null check (length(trim(tracking_code)) > 0),
  receipt_amount bigint not null check (receipt_amount >= 0),
  expected_amount bigint not null check (expected_amount >= 0),
  difference bigint generated always as (receipt_amount - expected_amount) stored,
  status text generated always as (case when receipt_amount = expected_amount then 'MATCH' else 'MISMATCH' end) stored,
  created_by uuid not null references auth.users(id) on delete restrict,
  unique (business_date, pos_code, tracking_code),
  unique (id, booth_code)
);

create table public.mrk_sale_lines (
  id uuid primary key default gen_random_uuid(),
  sale_id uuid not null,
  booth_code text not null,
  product_key text not null references public.mrk_products(product_key) on update cascade on delete restrict,
  product_code integer not null,
  product_name text not null,
  qty numeric not null check (qty > 0),
  unit text not null,
  unit_price bigint not null check (unit_price >= 0),
  line_total bigint generated always as (round(qty * unit_price)::bigint) stored,
  created_at timestamptz not null default now(),
  foreign key (sale_id, booth_code) references public.mrk_sales(id, booth_code) on delete restrict,
  unique (sale_id, product_key)
);

create table public.mrk_stock_movements (
  id uuid primary key,
  booth_code text not null,
  product_key text not null,
  sale_id uuid null,
  sale_line_id uuid null unique references public.mrk_sale_lines(id) on delete restrict,
  qty_delta numeric not null check (qty_delta <> 0),
  occurred_at timestamptz not null default now(),
  reason text not null,
  created_by uuid not null references auth.users(id) on delete restrict,
  foreign key (booth_code, product_key) references public.mrk_booth_products(booth_code, product_key) on delete restrict,
  foreign key (sale_id, booth_code) references public.mrk_sales(id, booth_code) on delete restrict
);

create table public.mrk_reconciliations (
  id uuid primary key,
  business_date date not null,
  pos_code text not null references public.mrk_pos_terminals(code) on update cascade on delete restrict,
  booth_code text null references public.mrk_booths(code) on update cascade on delete restrict,
  app_total bigint not null check (app_total >= 0),
  external_total bigint not null check (external_total >= 0),
  difference bigint generated always as (external_total - app_total) stored,
  sale_count integer not null default 0 check (sale_count >= 0),
  created_at timestamptz not null default now(),
  created_by uuid not null references auth.users(id) on delete restrict,
  unique (business_date, pos_code)
);

create index mrk_sales_booth_date_idx on public.mrk_sales (booth_code, business_date desc);
create index mrk_sales_pos_date_idx on public.mrk_sales (pos_code, business_date desc);
create index mrk_sale_lines_sale_idx on public.mrk_sale_lines (sale_id);
create index mrk_stock_movements_booth_product_idx on public.mrk_stock_movements (booth_code, product_key, occurred_at desc);
create index mrk_reconciliations_date_idx on public.mrk_reconciliations (business_date desc);

-- Authorization claims must be set server-side in Auth app_metadata, never user_metadata.
-- Expected claims: {"role":"accountant","active":true,"booth_code":null}
-- or {"role":"booth","active":true,"booth_code":"G01"}.
create or replace function public.mrk_is_active_user()
returns boolean
language sql stable
set search_path = ''
as $$
  select coalesce((auth.jwt() -> 'app_metadata' ->> 'active')::boolean, false)
$$;

create or replace function public.mrk_is_accountant()
returns boolean
language sql stable
set search_path = ''
as $$
  select public.mrk_is_active_user()
     and coalesce(auth.jwt() -> 'app_metadata' ->> 'role', '') = 'accountant'
$$;

create or replace function public.mrk_can_access_booth(p_booth_code text)
returns boolean
language sql stable
set search_path = ''
as $$
  select public.mrk_is_active_user() and (
    public.mrk_is_accountant() or (
      coalesce(auth.jwt() -> 'app_metadata' ->> 'role', '') = 'booth'
      and coalesce(auth.jwt() -> 'app_metadata' ->> 'booth_code', '') = p_booth_code
    )
  )
$$;

revoke all on function public.mrk_is_active_user() from public, anon;
revoke all on function public.mrk_is_accountant() from public, anon;
revoke all on function public.mrk_can_access_booth(text) from public, anon;
grant execute on function public.mrk_is_active_user() to authenticated;
grant execute on function public.mrk_is_accountant() to authenticated;
grant execute on function public.mrk_can_access_booth(text) to authenticated;

alter table public.mrk_booths enable row level security;
alter table public.mrk_pos_terminals enable row level security;
alter table public.mrk_products enable row level security;
alter table public.mrk_booth_products enable row level security;
alter table public.mrk_user_profiles enable row level security;
alter table public.mrk_sales enable row level security;
alter table public.mrk_sale_lines enable row level security;
alter table public.mrk_stock_movements enable row level security;
alter table public.mrk_reconciliations enable row level security;

-- Re-runnable policy creation (does not drop existing policies).
do $$ begin
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='mrk_booths' and policyname='mrk_booths_read_scoped') then
    create policy mrk_booths_read_scoped on public.mrk_booths for select to authenticated
      using (public.mrk_can_access_booth(code));
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='mrk_pos_terminals' and policyname='mrk_pos_read_scoped') then
    create policy mrk_pos_read_scoped on public.mrk_pos_terminals for select to authenticated
      using (public.mrk_is_accountant() or (booth_code is not null and public.mrk_can_access_booth(booth_code)));
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='mrk_products' and policyname='mrk_products_read_assigned') then
    create policy mrk_products_read_assigned on public.mrk_products for select to authenticated
      using (public.mrk_is_active_user() and (public.mrk_is_accountant() or exists (
        select 1 from public.mrk_booth_products bp
        where bp.product_key = mrk_products.product_key
          and bp.booth_code = (auth.jwt() -> 'app_metadata' ->> 'booth_code')
      )));
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='mrk_booth_products' and policyname='mrk_booth_products_read_scoped') then
    create policy mrk_booth_products_read_scoped on public.mrk_booth_products for select to authenticated
      using (public.mrk_can_access_booth(booth_code));
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='mrk_user_profiles' and policyname='mrk_profiles_read_self_or_accountant') then
    create policy mrk_profiles_read_self_or_accountant on public.mrk_user_profiles for select to authenticated
      using (user_id = (select auth.uid()) or public.mrk_is_accountant());
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='mrk_sales' and policyname='mrk_sales_read_scoped') then
    create policy mrk_sales_read_scoped on public.mrk_sales for select to authenticated
      using (public.mrk_can_access_booth(booth_code));
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='mrk_sales' and policyname='mrk_sales_insert_scoped') then
    create policy mrk_sales_insert_scoped on public.mrk_sales for insert to authenticated
      with check (created_by = (select auth.uid()) and public.mrk_can_access_booth(booth_code)
        and exists (select 1 from public.mrk_pos_terminals pt where pt.code = mrk_sales.pos_code and pt.booth_code = mrk_sales.booth_code));
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='mrk_sale_lines' and policyname='mrk_sale_lines_read_scoped') then
    create policy mrk_sale_lines_read_scoped on public.mrk_sale_lines for select to authenticated
      using (public.mrk_can_access_booth(booth_code));
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='mrk_sale_lines' and policyname='mrk_sale_lines_insert_scoped') then
    create policy mrk_sale_lines_insert_scoped on public.mrk_sale_lines for insert to authenticated
      with check (public.mrk_can_access_booth(booth_code) and exists (
        select 1 from public.mrk_sales s where s.id = mrk_sale_lines.sale_id and s.booth_code = mrk_sale_lines.booth_code and s.created_by = (select auth.uid())
      ) and exists (
        select 1 from public.mrk_booth_products bp where bp.booth_code = mrk_sale_lines.booth_code and bp.product_key = mrk_sale_lines.product_key
      ));
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='mrk_stock_movements' and policyname='mrk_stock_movements_read_scoped') then
    create policy mrk_stock_movements_read_scoped on public.mrk_stock_movements for select to authenticated
      using (public.mrk_can_access_booth(booth_code));
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='mrk_stock_movements' and policyname='mrk_stock_movements_insert_scoped') then
    create policy mrk_stock_movements_insert_scoped on public.mrk_stock_movements for insert to authenticated
      with check (created_by = (select auth.uid()) and public.mrk_can_access_booth(booth_code)
        and exists (select 1 from public.mrk_sale_lines sl where sl.id = mrk_stock_movements.sale_line_id and sl.sale_id = mrk_stock_movements.sale_id and sl.booth_code = mrk_stock_movements.booth_code));
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='mrk_reconciliations' and policyname='mrk_reconciliations_read_scoped') then
    create policy mrk_reconciliations_read_scoped on public.mrk_reconciliations for select to authenticated
      using (public.mrk_can_access_booth(booth_code));
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='mrk_reconciliations' and policyname='mrk_reconciliations_insert_accountant') then
    create policy mrk_reconciliations_insert_accountant on public.mrk_reconciliations for insert to authenticated
      with check (created_by = (select auth.uid()) and public.mrk_is_accountant());
  end if;
end $$;

-- Least-privilege table grants. RLS still applies to every authenticated query.
revoke all on table public.mrk_booths, public.mrk_pos_terminals, public.mrk_products,
  public.mrk_booth_products, public.mrk_user_profiles, public.mrk_sales,
  public.mrk_sale_lines, public.mrk_stock_movements, public.mrk_reconciliations
  from anon, authenticated;

grant usage on schema public to authenticated;
grant select on public.mrk_booths, public.mrk_pos_terminals, public.mrk_products,
  public.mrk_booth_products, public.mrk_user_profiles, public.mrk_sales,
  public.mrk_sale_lines, public.mrk_stock_movements, public.mrk_reconciliations
  to authenticated;
grant insert on public.mrk_sales, public.mrk_sale_lines, public.mrk_stock_movements,
  public.mrk_reconciliations to authenticated;

-- Intentionally no UPDATE or DELETE grants/policies for operational sales,
-- sale lines, stock movements, or reconciliations in this first controlled draft.
-- Corrections should use a separately reviewed adjustment/reversal workflow.
