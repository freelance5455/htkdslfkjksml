-- MRK r6 PWA: server-side payload, stock and product-catalog guards.
-- Additive migration: it does not alter or delete the existing accounting schema.

CREATE UNIQUE INDEX IF NOT EXISTS mrk_sync_events_business_entity_uq
ON public.mrk_sync_events(company_id, event_type, entity_id)
WHERE event_type IN (
  'sale_bundle','booth_closure','purchase_bundle','warehouse_transfer_bundle',
  'warehouse_transfer_in','booth_transfer_bundle','inventory_bundle',
  'sale_return_bundle','final_closure','reconciliation_bundle'
);

CREATE OR REPLACE FUNCTION private.mrk_validate_r6_event_payload()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $function$
DECLARE
  v_role text := private.mrk_current_role();
  v_sale jsonb;
  v_line jsonb;
  v_movement jsonb;
  v_count integer;
  v_qty numeric;
  v_sold numeric;
  v_returned numeric;
  v_stock numeric;
  v_source text;
  v_destination text;
  v_product text;
BEGIN
  IF v_role IS DISTINCT FROM 'accountant' AND v_role IS DISTINCT FROM 'booth' THEN
    RAISE EXCEPTION 'MRK_ACCOUNT_ROLE_REQUIRED' USING ERRCODE='42501';
  END IF;

  IF NEW.event_type = 'sale_bundle' THEN
    v_sale := NEW.payload->'sale';
    IF v_sale IS NULL OR jsonb_typeof(v_sale->'lines') IS DISTINCT FROM 'array'
       OR jsonb_typeof(NEW.payload->'movements') IS DISTINCT FROM 'array' THEN
      RAISE EXCEPTION 'MRK_SALE_PAYLOAD_INCOMPLETE' USING ERRCODE='22023';
    END IF;
    IF jsonb_array_length(NEW.payload->'movements') <> jsonb_array_length(v_sale->'lines') THEN
      RAISE EXCEPTION 'MRK_SALE_MOVEMENT_COUNT_MISMATCH' USING ERRCODE='22023';
    END IF;
    FOR v_line IN SELECT value FROM jsonb_array_elements(v_sale->'lines') LOOP
      SELECT count(*) INTO v_count
      FROM jsonb_array_elements(NEW.payload->'movements') m
      WHERE m->>'id' = (v_sale->>'id') || ':' || (v_line->>'productKey')
        AND m->>'type' = 'SALE'
        AND m->>'boothCode' = NEW.booth_code
        AND m->>'productKey' = v_line->>'productKey'
        AND (m->>'delta')::numeric = -((v_line->>'qty')::numeric);
      IF v_count <> 1 THEN
        RAISE EXCEPTION 'MRK_SALE_MOVEMENT_MISMATCH' USING ERRCODE='22023';
      END IF;
    END LOOP;
  ELSIF NEW.event_type = 'inventory_bundle' THEN
    v_movement := NEW.payload->'movement';
    IF v_movement IS NULL OR v_movement->>'boothCode' IS NULL OR v_movement->>'productKey' IS NULL
       OR NOT EXISTS (
          SELECT 1 FROM public.mrk_booth_products bp
          WHERE bp.booth_code=v_movement->>'boothCode'
            AND bp.product_key=v_movement->>'productKey'
            AND bp.company_id=NEW.company_id
       ) THEN
      RAISE EXCEPTION 'MRK_INVENTORY_SCOPE_INVALID' USING ERRCODE='22023';
    END IF;
    IF NOT EXISTS (
      SELECT 1 FROM public.mrk_stock_balances sb
      WHERE sb.booth_code=v_movement->>'boothCode'
        AND sb.product_key=v_movement->>'productKey'
        AND sb.company_id=NEW.company_id
    ) THEN
      RAISE EXCEPTION 'MRK_STOCK_BALANCE_ROW_MISSING' USING ERRCODE='22023';
    END IF;
    IF v_movement->>'type'='COUNT' THEN
      IF coalesce((v_movement->>'countedQty')::numeric,-1) < 0 THEN
        RAISE EXCEPTION 'MRK_COUNT_QUANTITY_INVALID' USING ERRCODE='22023';
      END IF;
    ELSIF v_movement->>'type' IN ('ADJUST_UP','ADJUST_DOWN') THEN
      SELECT quantity INTO v_stock FROM public.mrk_stock_balances
      WHERE booth_code=v_movement->>'boothCode' AND product_key=v_movement->>'productKey' FOR UPDATE;
      IF v_stock IS NULL OR (v_movement->>'delta')::numeric = 0 THEN
        RAISE EXCEPTION 'MRK_STOCK_UNKNOWN_OR_DELTA_INVALID' USING ERRCODE='22023';
      END IF;
    ELSE
      RAISE EXCEPTION 'MRK_INVENTORY_MOVEMENT_TYPE_INVALID' USING ERRCODE='22023';
    END IF;
  ELSIF NEW.event_type = 'sale_return_bundle' THEN
    IF jsonb_typeof(NEW.payload->'movements') IS DISTINCT FROM 'array'
       OR jsonb_array_length(NEW.payload->'movements')=0
       OR NEW.payload->'returnRecord'->>'sourceSaleId' IS NULL THEN
      RAISE EXCEPTION 'MRK_RETURN_PAYLOAD_INCOMPLETE' USING ERRCODE='22023';
    END IF;
    FOR v_movement IN SELECT value FROM jsonb_array_elements(NEW.payload->'movements') LOOP
      IF v_movement->>'type' IS DISTINCT FROM 'SALE_RETURN'
         OR v_movement->>'boothCode' IS DISTINCT FROM NEW.booth_code
         OR (v_movement->>'qty')::numeric <= 0
         OR (v_movement->>'delta')::numeric <> (v_movement->>'qty')::numeric THEN
        RAISE EXCEPTION 'MRK_RETURN_MOVEMENT_INVALID' USING ERRCODE='22023';
      END IF;
      SELECT (line->>'qty')::numeric INTO v_sold
      FROM public.mrk_sync_events e,
           LATERAL jsonb_array_elements(e.payload->'sale'->'lines') line
      WHERE e.company_id=NEW.company_id AND e.event_type='sale_bundle'
        AND e.payload->'sale'->>'id'=v_movement->>'sourceSaleId'
        AND e.booth_code=NEW.booth_code
        AND line->>'productKey'=v_movement->>'productKey'
      LIMIT 1;
      IF v_sold IS NULL THEN
        RAISE EXCEPTION 'MRK_RETURN_SOURCE_SALE_NOT_FOUND' USING ERRCODE='22023';
      END IF;
      SELECT coalesce(sum((m->>'qty')::numeric),0) INTO v_returned
      FROM public.mrk_sync_events e,
           LATERAL jsonb_array_elements(e.payload->'movements') m
      WHERE e.company_id=NEW.company_id AND e.event_type='sale_return_bundle'
        AND e.payload->'returnRecord'->>'sourceSaleId'=v_movement->>'sourceSaleId'
        AND m->>'productKey'=v_movement->>'productKey';
      IF v_returned + (v_movement->>'qty')::numeric > v_sold THEN
        RAISE EXCEPTION 'MRK_RETURN_EXCEEDS_ORIGINAL_SALE' USING ERRCODE='22023';
      END IF;
      SELECT quantity INTO v_stock FROM public.mrk_stock_balances
      WHERE company_id=NEW.company_id AND booth_code=NEW.booth_code
        AND product_key=v_movement->>'productKey' FOR UPDATE;
      IF NOT FOUND OR v_stock IS NULL THEN
        RAISE EXCEPTION 'MRK_RETURN_STOCK_UNKNOWN' USING ERRCODE='22023';
      END IF;
    END LOOP;
  ELSIF NEW.event_type = 'booth_transfer_bundle' THEN
    IF jsonb_typeof(NEW.payload->'movements') IS DISTINCT FROM 'array'
       OR jsonb_array_length(NEW.payload->'movements') <> 2 THEN
      RAISE EXCEPTION 'MRK_TRANSFER_REQUIRES_PAIRED_MOVEMENTS' USING ERRCODE='22023';
    END IF;
    SELECT value->>'boothCode', value->>'productKey' INTO v_source,v_product
    FROM jsonb_array_elements(NEW.payload->'movements') WHERE value->>'type'='TRANSFER_OUT' LIMIT 1;
    SELECT value->>'boothCode' INTO v_destination
    FROM jsonb_array_elements(NEW.payload->'movements') WHERE value->>'type'='TRANSFER_IN' LIMIT 1;
    IF v_source IS NULL OR v_destination IS NULL OR v_source=v_destination OR v_source='CENTRAL'
       OR NOT EXISTS (
         SELECT 1 FROM jsonb_array_elements(NEW.payload->'movements') m
         WHERE m->>'type'='TRANSFER_OUT' AND m->>'productKey'=v_product
           AND (m->>'delta')::numeric < 0
           AND (m->>'qty')::numeric = -(m->>'delta')::numeric
       ) OR NOT EXISTS (
         SELECT 1 FROM jsonb_array_elements(NEW.payload->'movements') m
         WHERE m->>'type'='TRANSFER_IN' AND m->>'productKey'=v_product
           AND (m->>'delta')::numeric > 0
           AND (m->>'qty')::numeric = (m->>'delta')::numeric
       ) THEN
      RAISE EXCEPTION 'MRK_TRANSFER_PAIR_INVALID' USING ERRCODE='22023';
    END IF;
    IF EXISTS (
      SELECT 1 FROM jsonb_array_elements(NEW.payload->'movements') m
      WHERE m->>'transferId' IS DISTINCT FROM NEW.entity_id
    ) THEN
      RAISE EXCEPTION 'MRK_TRANSFER_ID_MISMATCH' USING ERRCODE='22023';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM public.mrk_booth_products bp WHERE bp.company_id=NEW.company_id AND bp.booth_code=v_source AND bp.product_key=v_product)
       OR NOT EXISTS (SELECT 1 FROM public.mrk_booth_products bp WHERE bp.company_id=NEW.company_id AND bp.booth_code=v_destination AND bp.product_key=v_product) THEN
      RAISE EXCEPTION 'MRK_TRANSFER_PRODUCT_NOT_ASSIGNED' USING ERRCODE='22023';
    END IF;
    FOR v_movement IN SELECT value FROM jsonb_array_elements(NEW.payload->'movements') LOOP
      SELECT quantity INTO v_stock FROM public.mrk_stock_balances
      WHERE company_id=NEW.company_id AND booth_code=v_movement->>'boothCode'
        AND product_key=v_movement->>'productKey' FOR UPDATE;
      IF NOT FOUND OR v_stock IS NULL THEN
        RAISE EXCEPTION 'MRK_TRANSFER_STOCK_UNKNOWN' USING ERRCODE='22023';
      END IF;
      IF v_movement->>'type'='TRANSFER_OUT' AND v_stock < -(v_movement->>'delta')::numeric THEN
        RAISE EXCEPTION 'MRK_TRANSFER_SOURCE_STOCK_INSUFFICIENT' USING ERRCODE='22023';
      END IF;
    END LOOP;
  ELSIF NEW.event_type = 'warehouse_transfer_bundle' THEN
    v_transfer := NEW.payload->'transfer';
    IF v_transfer->>'from' IS DISTINCT FROM 'CENTRAL'
       OR NOT EXISTS (SELECT 1 FROM public.mrk_booths WHERE company_id=NEW.company_id AND code=v_transfer->>'to' AND is_active)
       OR NOT EXISTS (SELECT 1 FROM public.mrk_booth_products WHERE company_id=NEW.company_id AND booth_code=v_transfer->>'to' AND product_key=v_transfer->>'productKey') THEN
      RAISE EXCEPTION 'MRK_CENTRAL_TRANSFER_SCOPE_INVALID' USING ERRCODE='22023';
    END IF;
    SELECT quantity INTO v_stock FROM public.mrk_stock_balances
    WHERE company_id=NEW.company_id AND booth_code='CENTRAL' AND product_key=v_transfer->>'productKey' FOR UPDATE;
    IF NOT FOUND OR v_stock IS NULL OR v_stock < (v_transfer->>'qty')::numeric THEN
      RAISE EXCEPTION 'MRK_CENTRAL_TRANSFER_STOCK_INSUFFICIENT' USING ERRCODE='22023';
    END IF;
    SELECT quantity INTO v_stock FROM public.mrk_stock_balances
    WHERE company_id=NEW.company_id AND booth_code=v_transfer->>'to' AND product_key=v_transfer->>'productKey' FOR UPDATE;
    IF NOT FOUND OR v_stock IS NULL THEN
      RAISE EXCEPTION 'MRK_DESTINATION_STOCK_UNKNOWN' USING ERRCODE='22023';
    END IF;
  ELSIF NEW.event_type = 'purchase_bundle' THEN
    IF coalesce(NEW.payload->'purchase'->>'invoiceNo','')='' OR
       jsonb_typeof(NEW.payload->'purchase'->'lines') IS DISTINCT FROM 'array' OR
       jsonb_array_length(NEW.payload->'purchase'->'lines')=0 THEN
      RAISE EXCEPTION 'MRK_PURCHASE_DOCUMENT_INCOMPLETE' USING ERRCODE='22023';
    END IF;
  END IF;
  RETURN NEW;
END;
$function$;

REVOKE ALL ON FUNCTION private.mrk_validate_r6_event_payload() FROM PUBLIC, anon, authenticated;
DROP TRIGGER IF EXISTS mrk_00_validate_r6_event_payload ON public.mrk_sync_events;
CREATE TRIGGER mrk_00_validate_r6_event_payload
BEFORE INSERT ON public.mrk_sync_events
FOR EACH ROW EXECUTE FUNCTION private.mrk_validate_r6_event_payload();

CREATE OR REPLACE FUNCTION private.mrk_apply_product_upsert()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $function$
DECLARE
  p jsonb := NEW.payload->'product';
  v_booth text;
  v_opening jsonb;
  v_qty numeric;
  v_status text;
  v_product_key text;
BEGIN
  IF NEW.event_type <> 'product_upsert' THEN RETURN NEW; END IF;
  IF private.mrk_current_role() IS DISTINCT FROM 'accountant'
     OR NEW.actor_id IS DISTINCT FROM (SELECT auth.uid())
     OR NEW.company_id IS DISTINCT FROM private.mrk_current_company_id() THEN
    RAISE EXCEPTION 'MRK_PRODUCT_CHANGE_NOT_AUTHORIZED' USING ERRCODE='42501';
  END IF;
  v_product_key := left(trim(coalesce(p->>'key','')),180);
  IF v_product_key='' OR coalesce(trim(p->>'name'),'')='' OR coalesce(trim(p->>'unit'),'')=''
     OR coalesce(p->>'code','') !~ '^[0-9]+$'
     OR jsonb_typeof(p->'assignedStalls') IS DISTINCT FROM 'array'
     OR jsonb_array_length(p->'assignedStalls')=0 THEN
    RAISE EXCEPTION 'MRK_PRODUCT_PAYLOAD_INVALID' USING ERRCODE='22023';
  END IF;
  IF p->>'price' IS NOT NULL AND (p->>'price')::numeric < 0 THEN
    RAISE EXCEPTION 'MRK_PRODUCT_PRICE_INVALID' USING ERRCODE='22023';
  END IF;
  IF EXISTS (
    SELECT 1 FROM jsonb_array_elements_text(p->'assignedStalls') x
    WHERE NOT EXISTS (SELECT 1 FROM public.mrk_booths b WHERE b.company_id=NEW.company_id AND b.code=x AND b.is_active)
  ) THEN
    RAISE EXCEPTION 'MRK_PRODUCT_BOOTH_ASSIGNMENT_INVALID' USING ERRCODE='22023';
  END IF;

  INSERT INTO public.mrk_products(
    company_id,product_key,product_code,name,normalized_name,price,candidate_price,
    price_status,price_conflict,source_names,unit,unit_status,code_conflict,
    same_name_multiple_codes,sale_blocked,is_active,notes,updated_at
  ) VALUES (
    NEW.company_id,v_product_key,(p->>'code')::integer,left(p->>'name',220),
    left(coalesce(p->>'normalizedName',p->>'name'),220),nullif(p->>'price','')::bigint,
    nullif(p->>'candidatePrice','')::bigint,left(coalesce(p->>'priceStatus',''),80),
    coalesce((p->>'priceConflict')::boolean,false),
    CASE WHEN jsonb_typeof(p->'sourceNames')='array' THEN p->'sourceNames' ELSE jsonb_build_array(p->>'name') END,
    left(p->>'unit',40),left(coalesce(p->>'unitStatus',''),80),
    coalesce((p->>'codeConflict')::boolean,false),coalesce((p->>'sameNameMultipleCodes')::boolean,false),
    coalesce((p->>'saleBlocked')::boolean,true),true,left(coalesce(p->>'description',''),1000),now()
  ) ON CONFLICT(product_key) DO UPDATE SET
    product_code=excluded.product_code,name=excluded.name,normalized_name=excluded.normalized_name,
    price=excluded.price,candidate_price=excluded.candidate_price,price_status=excluded.price_status,
    price_conflict=excluded.price_conflict,source_names=excluded.source_names,unit=excluded.unit,
    unit_status=excluded.unit_status,code_conflict=excluded.code_conflict,
    same_name_multiple_codes=excluded.same_name_multiple_codes,sale_blocked=excluded.sale_blocked,
    is_active=true,notes=excluded.notes,updated_at=now();

  DELETE FROM public.mrk_booth_products bp
  WHERE bp.company_id=NEW.company_id AND bp.product_key=v_product_key
    AND NOT EXISTS (SELECT 1 FROM jsonb_array_elements_text(p->'assignedStalls') x WHERE x=bp.booth_code);

  FOR v_booth IN SELECT jsonb_array_elements_text(p->'assignedStalls') LOOP
    SELECT value INTO v_opening FROM jsonb_array_elements(coalesce(p->'openingRows','[]'::jsonb))
    WHERE value->>'boothCode'=v_booth LIMIT 1;
    v_qty := CASE WHEN v_opening IS NULL OR v_opening->>'openingQty' IS NULL OR v_opening->>'openingQty'='' THEN NULL ELSE (v_opening->>'openingQty')::numeric END;
    v_status := coalesce(v_opening->>'openingStatus','موجودی نامشخص');
    INSERT INTO public.mrk_booth_products(company_id,booth_code,product_key,opening_qty,opening_status,source_row)
    VALUES(NEW.company_id,v_booth,v_product_key,v_qty,v_status,nullif(v_opening->>'sourceRow','')::integer)
    ON CONFLICT(booth_code,product_key) DO UPDATE SET opening_status=excluded.opening_status;
    INSERT INTO public.mrk_stock_balances(company_id,booth_code,product_key,quantity,is_known)
    VALUES(NEW.company_id,v_booth,v_product_key,v_qty,v_qty IS NOT NULL)
    ON CONFLICT(booth_code,product_key) DO NOTHING;
  END LOOP;
  INSERT INTO public.mrk_stock_balances(company_id,booth_code,product_key,quantity,is_known)
  VALUES(NEW.company_id,'CENTRAL',v_product_key,0,true)
  ON CONFLICT(booth_code,product_key) DO NOTHING;
  RETURN NEW;
END;
$function$;

REVOKE ALL ON FUNCTION private.mrk_apply_product_upsert() FROM PUBLIC, anon, authenticated;
DROP TRIGGER IF EXISTS mrk_apply_product_upsert_after_insert ON public.mrk_sync_events;
CREATE TRIGGER mrk_apply_product_upsert_after_insert
AFTER INSERT ON public.mrk_sync_events
FOR EACH ROW EXECUTE FUNCTION private.mrk_apply_product_upsert();
