-- Product description field used by the server-side product_upsert trigger.
ALTER TABLE public.mrk_products ADD COLUMN IF NOT EXISTS notes text;
