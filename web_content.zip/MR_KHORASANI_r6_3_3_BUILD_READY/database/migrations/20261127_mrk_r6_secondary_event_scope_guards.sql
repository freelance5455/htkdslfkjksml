-- Block sales after closure and require booth-facing transfer views to match a committed atomic transfer.
CREATE OR REPLACE FUNCTION private.mrk_validate_secondary_event_scope()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=''
AS $function$
DECLARE
  v_role text := private.mrk_current_role();
  v_closure jsonb; v_day text; v_move jsonb; v_source_move jsonb;
BEGIN
  IF NEW.event_type='sale_bundle' THEN
    v_day := NEW.payload->'sale'->>'day';
    IF EXISTS (SELECT 1 FROM public.mrk_sync_events e
      WHERE e.company_id=NEW.company_id AND e.booth_code=NEW.booth_code
        AND ((e.event_type='booth_closure' AND e.payload->'closure'->>'day'=v_day)
          OR (e.event_type='final_closure' AND e.payload->'closure'->>'boothCode'=NEW.booth_code
            AND e.payload->'closure'->>'day'=v_day))) THEN
      RAISE EXCEPTION 'MRK_SALE_AFTER_BOOTH_CLOSE' USING ERRCODE='23514';
    END IF;
  ELSIF NEW.event_type='booth_closure' THEN
    v_closure := NEW.payload->'closure'; v_day := v_closure->>'day';
    IF v_closure IS NULL OR v_closure->>'id' IS DISTINCT FROM NEW.entity_id
       OR v_closure->>'boothCode' IS DISTINCT FROM NEW.booth_code
       OR v_day IS NULL OR v_day !~ '^\d{4}-\d{2}-\d{2}$'
       OR NOT EXISTS (SELECT 1 FROM public.mrk_booths b WHERE b.company_id=NEW.company_id AND b.code=NEW.booth_code AND b.is_active)
       OR (v_role='booth' AND (NEW.booth_code IS DISTINCT FROM private.mrk_current_booth_code()
         OR v_day<>(now() at time zone 'Asia/Tehran')::date::text)) THEN
      RAISE EXCEPTION 'MRK_BOOTH_CLOSURE_SCOPE_INVALID' USING ERRCODE='42501';
    END IF;
    IF EXISTS (SELECT 1 FROM public.mrk_sync_events e WHERE e.company_id=NEW.company_id
      AND e.booth_code=NEW.booth_code AND e.event_type='booth_closure'
      AND e.payload->'closure'->>'day'=v_day) THEN
      RAISE EXCEPTION 'MRK_BOOTH_ALREADY_CLOSED' USING ERRCODE='23505';
    END IF;
  ELSIF NEW.event_type='warehouse_transfer_in' THEN
    IF jsonb_typeof(NEW.payload->'movements') IS DISTINCT FROM 'array'
       OR jsonb_array_length(NEW.payload->'movements')<>1 THEN
      RAISE EXCEPTION 'MRK_TRANSFER_IN_VIEW_INVALID' USING ERRCODE='22023';
    END IF;
    SELECT value INTO v_move FROM jsonb_array_elements(NEW.payload->'movements')
    WHERE value->>'id'=NEW.entity_id||':IN' LIMIT 1;
    IF v_move IS NULL OR v_move->>'boothCode' IS DISTINCT FROM NEW.booth_code THEN
      RAISE EXCEPTION 'MRK_TRANSFER_IN_DESTINATION_INVALID' USING ERRCODE='22023';
    END IF;
    SELECT m.value INTO v_source_move
    FROM public.mrk_sync_events e, LATERAL jsonb_array_elements(e.payload->'movements') m(value)
    WHERE e.company_id=NEW.company_id AND e.entity_id=NEW.entity_id
      AND e.event_type IN ('warehouse_transfer_bundle','booth_transfer_bundle')
      AND m.value->>'id'=NEW.entity_id||':IN' AND m.value->>'boothCode'=NEW.booth_code
      AND ((e.event_type='warehouse_transfer_bundle' AND e.payload->'transfer'->>'to'=NEW.booth_code
          AND m.value->>'type'='WAREHOUSE_TRANSFER_IN')
        OR (e.event_type='booth_transfer_bundle' AND m.value->>'type'='TRANSFER_IN'))
    LIMIT 1;
    IF v_source_move IS NULL OR NEW.payload->'movements'<>jsonb_build_array(v_source_move) THEN
      RAISE EXCEPTION 'MRK_TRANSFER_IN_WITHOUT_COMMITTED_TRANSFER' USING ERRCODE='23514';
    END IF;
  END IF;
  RETURN NEW;
END;
$function$;
REVOKE ALL ON FUNCTION private.mrk_validate_secondary_event_scope() FROM PUBLIC,anon,authenticated;
DROP TRIGGER IF EXISTS mrk_000a_validate_secondary_event_scope ON public.mrk_sync_events;
CREATE TRIGGER mrk_000a_validate_secondary_event_scope BEFORE INSERT ON public.mrk_sync_events
FOR EACH ROW EXECUTE FUNCTION private.mrk_validate_secondary_event_scope();
