-- Explicitly revoke default CRUD grants from browser roles.
REVOKE ALL ON TABLE
  public.mrk_booths, public.mrk_pos_terminals, public.mrk_products,
  public.mrk_booth_products, public.mrk_user_profiles,
  public.mrk_stock_balances, public.mrk_sync_events
FROM anon, authenticated, public;

GRANT SELECT ON TABLE
  public.mrk_booths, public.mrk_pos_terminals, public.mrk_products,
  public.mrk_booth_products, public.mrk_user_profiles, public.mrk_sync_events
TO authenticated;
GRANT INSERT ON TABLE public.mrk_sync_events TO authenticated;
REVOKE UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER
ON TABLE public.mrk_sync_events FROM anon, authenticated, public;

REVOKE ALL ON SEQUENCE public.mrk_sync_events_seq_seq FROM anon, authenticated, public;
GRANT USAGE, SELECT ON SEQUENCE public.mrk_sync_events_seq_seq TO authenticated;
