-- Correct typed column aliases in the deployed product assignment trigger.
CREATE OR REPLACE FUNCTION private.mrk_apply_product_upsert()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = ''
AS $function$
DECLARE
  p jsonb := NEW.payload->'product';
  v_booth text; v_opening jsonb; v_qty numeric; v_status text; v_product_key text;
BEGIN
  IF NEW.event_type <> 'product_upsert' THEN RETURN NEW; END IF;
  IF private.mrk_current_role() IS DISTINCT FROM 'accountant'
     OR NEW.actor_id IS DISTINCT FROM (SELECT auth.uid())
     OR NEW.company_id IS DISTINCT FROM private.mrk_current_company_id() THEN
    RAISE EXCEPTION 'MRK_PRODUCT_CHANGE_NOT_AUTHORIZED' USING ERRCODE='42501';
  END IF;
  v_product_key := left(trim(coalesce(p->>'key','')),180);
  IF v_product_key='' OR coalesce(trim(p->>'name'),'')='' OR coalesce(trim(p->>'unit'),'')=''
     OR coalesce(p->>'code','') !~ '^[0-9]+$'
     OR jsonb_typeof(p->'assignedStalls') IS DISTINCT FROM 'array'
     OR jsonb_array_length(p->'assignedStalls')=0 THEN
    RAISE EXCEPTION 'MRK_PRODUCT_PAYLOAD_INVALID' USING ERRCODE='22023';
  END IF;
  IF p->>'price' IS NOT NULL AND (p->>'price')::numeric < 0 THEN
    RAISE EXCEPTION 'MRK_PRODUCT_PRICE_INVALID' USING ERRCODE='22023';
  END IF;
  IF EXISTS (SELECT 1 FROM jsonb_array_elements_text(p->'assignedStalls') AS x(booth_code)
    WHERE NOT EXISTS (SELECT 1 FROM public.mrk_booths b WHERE b.company_id=NEW.company_id AND b.code=x.booth_code AND b.is_active)) THEN
    RAISE EXCEPTION 'MRK_PRODUCT_BOOTH_ASSIGNMENT_INVALID' USING ERRCODE='22023';
  END IF;
  INSERT INTO public.mrk_products(
    company_id,product_key,product_code,name,normalized_name,price,candidate_price,
    price_status,price_conflict,source_names,unit,unit_status,code_conflict,
    same_name_multiple_codes,sale_blocked,is_active,notes,updated_at
  ) VALUES (
    NEW.company_id,v_product_key,(p->>'code')::integer,left(p->>'name',220),
    left(coalesce(p->>'normalizedName',p->>'name'),220),nullif(p->>'price','')::bigint,
    nullif(p->>'candidatePrice','')::bigint,left(coalesce(p->>'priceStatus',''),80),
    coalesce((p->>'priceConflict')::boolean,false),
    CASE WHEN jsonb_typeof(p->'sourceNames')='array' THEN p->'sourceNames' ELSE jsonb_build_array(p->>'name') END,
    left(p->>'unit',40),left(coalesce(p->>'unitStatus',''),80),coalesce((p->>'codeConflict')::boolean,false),
    coalesce((p->>'sameNameMultipleCodes')::boolean,false),coalesce((p->>'saleBlocked')::boolean,true),
    true,left(coalesce(p->>'description',''),1000),now()
  ) ON CONFLICT(product_key) DO UPDATE SET
    product_code=excluded.product_code,name=excluded.name,normalized_name=excluded.normalized_name,
    price=excluded.price,candidate_price=excluded.candidate_price,price_status=excluded.price_status,
    price_conflict=excluded.price_conflict,source_names=excluded.source_names,unit=excluded.unit,
    unit_status=excluded.unit_status,code_conflict=excluded.code_conflict,
    same_name_multiple_codes=excluded.same_name_multiple_codes,sale_blocked=excluded.sale_blocked,
    is_active=true,notes=excluded.notes,updated_at=now();
  DELETE FROM public.mrk_booth_products bp
  WHERE bp.company_id=NEW.company_id AND bp.product_key=v_product_key
    AND NOT EXISTS (SELECT 1 FROM jsonb_array_elements_text(p->'assignedStalls') AS x(booth_code) WHERE x.booth_code=bp.booth_code);
  FOR v_booth IN SELECT jsonb_array_elements_text(p->'assignedStalls') LOOP
    SELECT value INTO v_opening FROM jsonb_array_elements(coalesce(p->'openingRows','[]'::jsonb))
    WHERE value->>'boothCode'=v_booth LIMIT 1;
    v_qty := CASE WHEN v_opening IS NULL OR v_opening->>'openingQty' IS NULL OR v_opening->>'openingQty'=''
      THEN NULL ELSE (v_opening->>'openingQty')::numeric END;
    v_status := coalesce(v_opening->>'openingStatus','موجودی نامشخص');
    INSERT INTO public.mrk_booth_products(company_id,booth_code,product_key,opening_qty,opening_status,source_row)
    VALUES(NEW.company_id,v_booth,v_product_key,v_qty,v_status,nullif(v_opening->>'sourceRow','')::integer)
    ON CONFLICT(booth_code,product_key) DO UPDATE SET opening_status=excluded.opening_status;
    INSERT INTO public.mrk_stock_balances(company_id,booth_code,product_key,quantity,is_known)
    VALUES(NEW.company_id,v_booth,v_product_key,v_qty,v_qty IS NOT NULL)
    ON CONFLICT(booth_code,product_key) DO NOTHING;
  END LOOP;
  INSERT INTO public.mrk_stock_balances(company_id,booth_code,product_key,quantity,is_known)
  VALUES(NEW.company_id,'CENTRAL',v_product_key,0,true)
  ON CONFLICT(booth_code,product_key) DO NOTHING;
  RETURN NEW;
END;
$function$;
