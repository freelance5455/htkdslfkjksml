-- MRK r6 follow-up migration. Applied to klomsegarpfdkhkmoazy.
-- Adds booth-visible inventory/catalog feed and server-posts accountant sales.
ALTER TABLE public.mrk_sync_events DROP CONSTRAINT IF EXISTS mrk_sync_events_event_type_check;
ALTER TABLE public.mrk_sync_events ADD CONSTRAINT mrk_sync_events_event_type_check CHECK (event_type = ANY (ARRAY[
  'sale_bundle','booth_closure','purchase_bundle','warehouse_transfer_bundle',
  'warehouse_transfer_in','warehouse_transfer_accountant','booth_transfer_bundle',
  'inventory_bundle','sale_return_bundle','final_closure','reconciliation_bundle',
  'product_upsert','product_catalog_refresh'
]::text[]));

DROP POLICY IF EXISTS mrk_events_read_scoped ON public.mrk_sync_events;
CREATE POLICY mrk_events_read_scoped ON public.mrk_sync_events FOR SELECT TO authenticated
USING (company_id=private.mrk_current_company_id() AND (
  private.mrk_is_accountant() OR (
    booth_code=private.mrk_current_booth_code() AND event_type = ANY (ARRAY[
      'sale_bundle','booth_closure','warehouse_transfer_in','booth_transfer_bundle',
      'sale_return_bundle','inventory_bundle','product_catalog_refresh'
    ]::text[])
  )
));

CREATE OR REPLACE FUNCTION private.mrk_validate_accountant_sale()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=''
AS $function$
DECLARE
  v_sale jsonb := NEW.payload->'sale';
  v_line jsonb; v_payment jsonb; v_product public.mrk_products%rowtype;
  v_qty numeric; v_balance numeric; v_expected numeric := 0; v_received numeric := 0; v_day text;
BEGIN
  IF NEW.event_type <> 'sale_bundle' OR private.mrk_current_role() <> 'accountant' THEN RETURN NEW; END IF;
  IF v_sale IS NULL OR v_sale->>'id' IS DISTINCT FROM NEW.entity_id
     OR v_sale->>'boothCode' IS DISTINCT FROM NEW.booth_code
     OR NOT EXISTS (SELECT 1 FROM public.mrk_booths b WHERE b.company_id=NEW.company_id AND b.code=NEW.booth_code AND b.is_active)
     OR jsonb_typeof(v_sale->'lines') IS DISTINCT FROM 'array' OR jsonb_array_length(v_sale->'lines')=0
     OR jsonb_typeof(v_sale->'payments') IS DISTINCT FROM 'array' THEN
    RAISE EXCEPTION 'MRK_ACCOUNTANT_SALE_SHAPE_INVALID' USING ERRCODE='22023';
  END IF;
  v_day := v_sale->>'day';
  IF v_day IS NULL OR v_day !~ '^\d{4}-\d{2}-\d{2}$' THEN
    RAISE EXCEPTION 'MRK_ACCOUNTANT_SALE_DATE_INVALID' USING ERRCODE='22023';
  END IF;
  FOR v_line IN SELECT value FROM jsonb_array_elements(v_sale->'lines') LOOP
    SELECT p.* INTO v_product FROM public.mrk_products p
    JOIN public.mrk_booth_products bp ON bp.company_id=p.company_id AND bp.product_key=p.product_key AND bp.booth_code=NEW.booth_code
    WHERE p.company_id=NEW.company_id AND p.product_key=v_line->>'productKey' AND p.is_active;
    IF NOT FOUND OR v_product.sale_blocked OR v_product.price_conflict OR v_product.price IS NULL
       OR (v_line->>'unitPrice')::numeric<>v_product.price THEN
      RAISE EXCEPTION 'MRK_ACCOUNTANT_SALE_PRODUCT_OR_PRICE_INVALID' USING ERRCODE='22023';
    END IF;
    v_qty := (v_line->>'qty')::numeric;
    IF v_qty<=0 OR (v_product.unit<>'کیلوگرم' AND v_qty<>trunc(v_qty))
       OR (v_product.unit='کیلوگرم' AND abs(v_qty*100-round(v_qty*100))>0.000001) THEN
      RAISE EXCEPTION 'MRK_ACCOUNTANT_SALE_QUANTITY_INVALID' USING ERRCODE='22023';
    END IF;
    IF round(v_qty*v_product.price)::bigint<>(v_line->>'lineTotal')::bigint THEN
      RAISE EXCEPTION 'MRK_ACCOUNTANT_SALE_LINE_TOTAL_INVALID' USING ERRCODE='22023';
    END IF;
    PERFORM pg_advisory_xact_lock(hashtextextended(NEW.booth_code||':'||v_product.product_key,0));
    SELECT quantity INTO v_balance FROM public.mrk_stock_balances
    WHERE company_id=NEW.company_id AND booth_code=NEW.booth_code AND product_key=v_product.product_key FOR UPDATE;
    IF NOT FOUND OR v_balance IS NULL OR v_balance<v_qty THEN
      RAISE EXCEPTION 'MRK_ACCOUNTANT_SALE_STOCK_UNKNOWN_OR_INSUFFICIENT: %',v_product.name USING ERRCODE='22023';
    END IF;
    v_expected := v_expected + round(v_qty*v_product.price);
  END LOOP;
  IF v_expected<>(v_sale->>'expectedAmount')::numeric THEN
    RAISE EXCEPTION 'MRK_ACCOUNTANT_SALE_TOTAL_INVALID' USING ERRCODE='22023';
  END IF;
  FOR v_payment IN SELECT value FROM jsonb_array_elements(v_sale->'payments') LOOP
    IF v_payment->>'type' NOT IN ('POS','CASH','PERSONNEL') OR (v_payment->>'amount')::numeric<=0
       OR (v_payment->>'amount')::numeric<>trunc((v_payment->>'amount')::numeric) THEN
      RAISE EXCEPTION 'MRK_ACCOUNTANT_SALE_PAYMENT_INVALID' USING ERRCODE='22023';
    END IF;
    IF v_payment->>'type'='POS' THEN
      IF NOT EXISTS (SELECT 1 FROM public.mrk_pos_terminals t WHERE t.company_id=NEW.company_id
        AND t.code=v_payment->>'posCode' AND t.booth_code=NEW.booth_code AND t.is_active)
        OR coalesce(trim(v_payment->>'trackingCode'),'')='' THEN
        RAISE EXCEPTION 'MRK_ACCOUNTANT_SALE_POS_INVALID' USING ERRCODE='22023';
      END IF;
      PERFORM pg_advisory_xact_lock(hashtextextended(v_day||':'||(v_payment->>'posCode')||':'||(v_payment->>'trackingCode'),0));
      IF EXISTS (SELECT 1 FROM public.mrk_sync_events e,
        LATERAL jsonb_array_elements(e.payload->'sale'->'payments') p
        WHERE e.company_id=NEW.company_id AND e.event_type='sale_bundle'
          AND e.payload->'sale'->>'day'=v_day AND p->>'type'='POS'
          AND p->>'posCode'=v_payment->>'posCode' AND p->>'trackingCode'=v_payment->>'trackingCode') THEN
        RAISE EXCEPTION 'MRK_DUPLICATE_POS_TRACKING' USING ERRCODE='23505';
      END IF;
    END IF;
    v_received := v_received + (v_payment->>'amount')::numeric;
  END LOOP;
  IF v_received<>(v_sale->>'totalReceived')::numeric OR v_received>v_expected
     OR coalesce((v_sale->>'outstandingAmount')::numeric,v_expected-v_received)<>v_expected-v_received THEN
    RAISE EXCEPTION 'MRK_ACCOUNTANT_SALE_SETTLEMENT_INVALID' USING ERRCODE='22023';
  END IF;
  UPDATE public.mrk_stock_balances sb
  SET quantity=sb.quantity-(line.value->>'qty')::numeric, revision=sb.revision+1, updated_at=now()
  FROM jsonb_array_elements(v_sale->'lines') AS line(value)
  WHERE sb.company_id=NEW.company_id AND sb.booth_code=NEW.booth_code
    AND sb.product_key=line.value->>'productKey';
  RETURN NEW;
END;
$function$;
REVOKE ALL ON FUNCTION private.mrk_validate_accountant_sale() FROM PUBLIC,anon,authenticated;
DROP TRIGGER IF EXISTS mrk_01_validate_accountant_sale ON public.mrk_sync_events;
CREATE TRIGGER mrk_01_validate_accountant_sale BEFORE INSERT ON public.mrk_sync_events
FOR EACH ROW EXECUTE FUNCTION private.mrk_validate_accountant_sale();
