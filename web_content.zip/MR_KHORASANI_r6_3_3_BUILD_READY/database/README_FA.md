# وضعیت Supabase — انتشار r6 امن

پروژه مرجع: `mr-khorasani-finance` / `klomsegarpfdkhkmoazy` / `eu-central-1`.

ساختار پایه `mrk_*` به‌صورت افزایشی روی پایگاه داده فعال اعمال شده است؛ جداول حسابداری موجود و اطلاعات آن‌ها حذف یا جایگزین نشده‌اند. پنج عضو مجاز سازمان به پروفایل‌های احرازشده نگاشت شده‌اند؛ دو عضو با نقش OWNER/ADMIN اختیار مدیریت حساب دارند. کاربر غرفه‌دار تا زمان ایجاد از پنل مدیر وجود ندارد.

## اشیای جدید

- جداول: `mrk_booths`, `mrk_pos_terminals`, `mrk_products`, `mrk_booth_products`, `mrk_user_profiles`, `mrk_stock_balances`, `mrk_sync_events`.
- توابع دسترسی امن در schema خصوصی `private` و سیاست‌های RLS بر اساس پروفایل سرور.
- triggerهای اعتبارسنجی payload، نقش، تخصیص غرفه/کالا، قیمت، پرداخت، موجودی، برگشت و انتقال.
- `mrk_sync_events` در publication مربوط به Supabase Realtime قرار دارد.
- Edge Function `mrk-admin` با `verify_jwt=true` برای راه‌اندازی insert-only کاتالوگ و مدیریت حساب‌های ورود.

## مهاجرت‌ها

ترتیب انتشار روی پروژه مقصد:

1. DDL افزایشی پایه `mrk_*` به پروژه مقصد اعمال شده است.
2. `migrations/20261127_mrk_r6_cloud_event_guards.sql`
3. `migrations/20261127_mrk_r6_product_assignment_alias_fix.sql`
4. `migrations/20261127_mrk_r6_catalog_feed_and_accountant_sales.sql`
5. `migrations/20261127_mrk_r6_server_sale_serialization.sql`
6. `migrations/20261127_mrk_r6_explicit_client_privilege_hardening.sql`
7. `migrations/20261127_mrk_r6_secondary_event_scope_guards.sql`
8. `migrations/20261127_mrk_r6_product_notes_field.sql`

مهاجرت‌های شماره ۲ تا ۸ از طریق Supabase migration tool اعمال شده‌اند. DDL پایه پیش از آن با SQL افزایشی اجرا شده و در تاریخچه migration اصلی Supabase ثبت نشده است؛ این نکته برای ممیزی و تطبیق schema مهم است.

فایل‌های `archive_unapplied/` شامل پیش‌نویس‌های قدیمی r6 هستند و فقط برای ارجاع نگهداری شده‌اند. آن‌ها را روی پروژه فعال دوباره اجرا نکنید.

## امنیت

- کلید publishable برای وب قابل نمایش است و در برنامه استفاده می‌شود.
- هیچ service-role یا secret key در وب، ZIP یا IndexedDB قرار نمی‌گیرد.
- دسترسی به جداول بر پایه RLS است؛ جدول `mrk_stock_balances` مستقیماً در اختیار کلاینت نیست.
- ایجاد کاربر از Edge Function با اعتبارسنجی JWT و مجوز `can_manage_users` انجام می‌شود.
- نقش و `booth_code` از جدول سروری استخراج می‌شوند و به `user_metadata` قابل‌ویرایش تکیه ندارند.

## هشدارهای باقی‌مانده Security Advisor

- Leaked Password Protection در تنظیمات Auth هنوز فعال نیست؛ پیش از انتشار عمومی از مسیر Authentication → Settings → Password Security فعال شود. راهنمای رسمی: https://supabase.com/docs/guides/auth/password-security#password-strength-and-leaked-password-protection.
- هشدار نصب `pg_net` در schema عمومی از قبل وجود داشته و جزو تغییرات این انتشار نیست.
- `mrk_stock_balances` عمداً RLS فعال و بدون policy خواندن/نوشتن کلاینت دارد؛ نقش `authenticated` نیز هیچ مجوز مستقیمی روی این جدول ندارد. تغییر موجودی فقط از triggerهای سروری انجام می‌شود.

## راه‌اندازی کاتالوگ و کاربر

ورود مدیر مجاز به PWA باعث اجرای idempotent و insert-only bootstrap می‌شود. این bootstrap رکورد موجود یا مانده‌های عملیاتی را overwrite نمی‌کند. مدیر سپس حساب غرفه‌دار را از پنل تنظیمات ایجاد می‌کند. هیچ رمز ثابت/PIN آزمایشی تعریف نشده است.
