-- Read-only verification queries. Safe to run after schema/catalog setup.
-- These statements only SELECT catalog metadata and row counts.

-- 1) Objects present in the expected schema.
select table_name
from information_schema.tables
where table_schema = 'public'
  and table_name like 'mrk_%'
order by table_name;

-- 2) Column names and data types.
select table_name, ordinal_position, column_name, data_type, is_nullable
from information_schema.columns
where table_schema = 'public'
  and table_name like 'mrk_%'
order by table_name, ordinal_position;

-- 3) RLS state for all MRK tables.
select n.nspname as schema_name, c.relname as table_name,
       c.relrowsecurity as rls_enabled,
       c.relforcerowsecurity as rls_forced
from pg_class c
join pg_namespace n on n.oid = c.relnamespace
where n.nspname = 'public' and c.relname like 'mrk_%'
  and c.relkind = 'r'
order by c.relname;

-- 4) Policies and their expressions.
select schemaname, tablename, policyname, permissive, roles, cmd, qual, with_check
from pg_policies
where schemaname = 'public' and tablename like 'mrk_%'
order by tablename, policyname;

-- 5) Catalog totals; these should match source seed summary if inserted.
select 'booths' as entity, count(*) as rows from public.mrk_booths
union all select 'pos_terminals', count(*) from public.mrk_pos_terminals
union all select 'products', count(*) from public.mrk_products
union all select 'booth_products', count(*) from public.mrk_booth_products
union all select 'user_profiles', count(*) from public.mrk_user_profiles
union all select 'sales', count(*) from public.mrk_sales
union all select 'sale_lines', count(*) from public.mrk_sale_lines
union all select 'stock_movements', count(*) from public.mrk_stock_movements
union all select 'reconciliations', count(*) from public.mrk_reconciliations
order by entity;
