(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.PersianCalendar=api})(typeof globalThis!=='undefined'?globalThis:this,function(){
 'use strict';
 const breaks=[-61,9,38,199,426,686,756,818,1111,1181,1210,1635,2060,2097,2192,2262,2324,2394,2456,3178];
 const div=(a,b)=>Math.floor(a/b),mod=(a,b)=>a-Math.floor(a/b)*b;
 function jalCal(jy){if(jy<breaks[0]||jy>=breaks[breaks.length-1])throw new RangeError('سال شمسی خارج از محدوده پشتیبانی است.');let gy=jy+621,leapJ=-14,jp=breaks[0],jump=0;for(let i=1;i<breaks.length;i++){const jm=breaks[i];jump=jm-jp;if(jy<jm)break;leapJ+=div(jump,33)*8+div(mod(jump,33),4);jp=jm}let n=jy-jp;leapJ+=div(n,33)*8+div(mod(n,33)+3,4);if(mod(jump,33)===4&&jump-n===4)leapJ++;const leapG=div(gy,4)-div((div(gy,100)+1)*3,4)-150;const march=20+leapJ-leapG;if(jump-n<6)n=n-jump+div(jump+4,33)*33;let leap=mod(mod(n+1,33)-1,4);if(leap===-1)leap=4;return{leap,gy,march}}
 function g2d(gy,gm,gd){let d=div((gy+div(gm-8,6)+100100)*1461,4)+div(153*mod(gm+9,12)+2,5)+gd-34840408;d=d-div(div(gy+100100+div(gm-8,6),100)*3,4)+752;return d}
 function j2d(jy,jm,jd){const r=jalCal(jy);return g2d(r.gy,3,r.march)+(jm-1)*31-div(jm,7)*(jm-7)+jd-1}
 function d2g(jdn){let j=4*jdn+139361631;j+=div(div(4*jdn+183187720,146097)*3,4)*4-3908;const i=div(mod(j,1461),4)*5+308;const gd=div(mod(i,153),5)+1;const gm=mod(div(i,153),12)+1;const gy=div(j,1461)-100100+div(8-gm,6);return{gy,gm,gd}}
 function d2j(jdn){const g=d2g(jdn);let jy=g.gy-621;const r=jalCal(jy);const jdn1f=g2d(g.gy,3,r.march);let k=jdn-jdn1f,jm,jd;if(k>=0){if(k<=185){jm=1+div(k,31);jd=mod(k,31)+1;return{jy,jm,jd}}k-=186}else{jy-=1;k+=179;if(r.leap===1)k++}jm=7+div(k,30);jd=mod(k,30)+1;return{jy,jm,jd}}
 function digitsToAscii(value){return String(value??'').replace(/[۰-۹]/g,d=>String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d))).replace(/[٠-٩]/g,d=>String('٠١٢٣٤٥٦٧٨٩'.indexOf(d))).trim()}
 function toPersianDigits(value){return String(value).replace(/\d/g,d=>'۰۱۲۳۴۵۶۷۸۹'[Number(d)])}
 const formatter=new Intl.DateTimeFormat('en-US-u-ca-persian-nu-latn',{timeZone:'UTC',year:'numeric',month:'2-digit',day:'2-digit'});
 function parse(value){const s=digitsToAscii(value).replace(/[.-]/g,'/');const m=s.match(/^(\d{3,4})\/(\d{1,2})\/(\d{1,2})$/);if(!m)return null;const jy=Number(m[1]),jm=Number(m[2]),jd=Number(m[3]);if(jm<1||jm>12||jd<1||jd>31)return null;return{jy,jm,jd}}
 function toGregorian(value){const p=typeof value==='object'&&value?value:parse(value);if(!p)return null;const start=Date.UTC(p.jy+621,2,15,12),target=`${p.jy}-${p.jm}-${p.jd}`;for(let i=0;i<370;i++){const d=new Date(start+i*86400000),parts=Object.fromEntries(formatter.formatToParts(d).filter(x=>x.type!=='literal').map(x=>[x.type,Number(x.value)]));if(parts.year===p.jy&&parts.month===p.jm&&parts.day===p.jd)return `${d.getUTCFullYear()}-${String(d.getUTCMonth()+1).padStart(2,'0')}-${String(d.getUTCDate()).padStart(2,'0')}`}return null}
 function toJalali(value){const s=digitsToAscii(value),m=s.match(/^(\d{4})-(\d{2})-(\d{2})$/);if(!m)return '';const d=new Date(Date.UTC(Number(m[1]),Number(m[2])-1,Number(m[3]),12));const parts=Object.fromEntries(formatter.formatToParts(d).filter(x=>x.type!=='literal').map(x=>[x.type,Number(x.value)]));return toPersianDigits(`${parts.year}/${String(parts.month).padStart(2,'0')}/${String(parts.day).padStart(2,'0')}`)}
 function today(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`}
 function valid(value){return toGregorian(value)!==null}
 return{digitsToAscii,toPersianDigits,parse,toGregorian,toJalali,today,valid};
});
