# MR,KHORASANI r6 — بسته ساخت APK اندروید

این ZIP سورس برنامه، تنظیمات Capacitor، اسکریپت ایجاد پروژه Native و فرمان ساخت APK آزمایشی را دارد. این بسته برای مبدل‌های ساده ZIP-to-APK که فقط HTML را در WebView باز می‌کنند طراحی نشده است؛ آن مبدل‌ها وابستگی محلی SDK را نصب نمی‌کنند. پوشه Android Native پس از اجرای `android:setup` توسط Capacitor ایجاد و با سورس همین ZIP همگام می‌شود.

## ساخت APK در Windows

پیش‌نیاز: Node.js 22+، npm 12 به‌روز، Android Studio 2025.2.1+، Android SDK Platform API 24 یا بالاتر و Java 21. سپس:

1. ZIP را در یک مسیر ساده مانند `C:\MRKhorasani` استخراج کنید.
2. `build-android.bat` را اجرا کنید؛ یا در Android Studio/Terminal فرمان‌های زیر را بزنید:

```powershell
npm install
npm run test
npm run android:setup
npm run android:debug
```

3. خروجی APK آزمایشی در مسیر زیر ایجاد می‌شود:

`android/app/build/outputs/apk/debug/app-debug.apk`

اسکریپت `build-android.bat` همین فایل را در `dist/MR-KHORASANI-r6.3.3-secure-auth-debug.apk` کپی می‌کند. APK نوع Debug با کلید debug محلی امضا می‌شود و برای نصب و آزمون دستگاه مناسب است.

## نسخه انتشار (Release)

برای انتشار عمومی یا فروش، در Android Studio از مسیر Build → Generate Signed Bundle / APK یک Android App Bundle یا APK امضاشده بسازید. Keystore و رمز آن باید خارج از ZIP و در محل امن نگهداری شوند. هیچ کلید امضایی در این بسته تعبیه نشده است.

## ساخت خودکار

Workflow در `.github/workflows/android-debug-apk.yml` با اجرای دستی یا push، APK آزمایشی تولید و به‌صورت Artifact در GitHub Actions منتشر می‌کند.

## نکات اجرای اپ

- Supabase JS به‌صورت محلی در پوشه `www/vendor/supabase.js` کپی و پیش از loader بارگذاری می‌شود؛ loader نیز همراه دارایی‌ها کپی می‌شود. بنابراین APK ساخته‌شده با Capacitor برای بارگذاری SDK به CDN وابسته نیست.
- از ارسال مستقیم ZIP سورس به سایت/برنامه مبدل ساده ZIP-to-APK خودداری کنید. این روش `npm install` و آماده‌سازی Native را اجرا نمی‌کند و می‌تواند همین خطای کتابخانه احراز هویت را ایجاد کند. برای APK از `build-android.bat` یا GitHub Actions استفاده کنید.
- Service Worker وب در محیط Native ثبت نمی‌شود؛ خود دارایی‌ها داخل APK بسته‌بندی می‌شوند. صف آفلاین IndexedDB و اتصال Supabase هنگام وجود اینترنت حفظ می‌شود.
- برای اولین ورود و bootstrap کاتالوگ، اینترنت و حساب مدیر واقعی لازم است.
- `database/archive_unapplied/` فایل‌های مرجع قدیمی است و نباید اجرا شود.

## نسخه ابزار

Capacitor 8.6.3 به‌صورت دقیق pin شده است. مستندات رسمی: https://capacitorjs.com/docs/android و https://capacitorjs.com/docs/getting-started/environment-setup.

**محدودیت تحویل:** این محیط Android Studio و Android SDK ندارد؛ در نتیجه فایل APK کامپایل‌شده در اینجا تولید نشده است. این بسته پروژه آماده ساخت است و APK با اجرای فرمان‌های بالا تولید می‌شود.

نسخه r6.3: SDK احراز هویت در خروجی Native به‌صورت محلی بسته‌بندی می‌شود؛ پنل مدیر تعداد کاربران، فهرست ایمیل‌ها، ماتریس دسترسی نقش‌ها و ارسال لینک بازیابی گذرواژه را نمایش می‌دهد. پس از build، اتصال اینترنت WebView برای ورود اولیه الزامی است.


## نکته مهم درباره خطای Preview و مبدل ZIP-to-APK

اگر فایل ZIP سورس را به برنامه/سایت مبدل ساده ZIP-to-APK بدهید، آن مبدل معمولاً `npm install` و اسکریپت Capacitor را اجرا نمی‌کند. در این حالت SDK محلی در `www/vendor/supabase.js` ساخته نمی‌شود و WebView ممکن است خطای «کتابخانه احراز هویت ابری بارگذاری نشده است» نشان دهد. برای ساخت APK این بسته را استخراج کنید و `build-android.bat` را در Windows دارای Android Studio/SDK و Java 21 اجرا کنید، یا workflow موجود GitHub Actions را اجرا کنید. فایل APK خروجی را مستقیماً نصب کنید؛ ZIP سورس را به مبدل ساده ندهید.

## مدیریت کاربران در r6.3

در تنظیمات، مدیر مجاز می‌تواند شمار کاربران و فهرست حساب‌ها را ببیند، حساب جدید با ایمیل و گذرواژه اولیه بسازد، و لینک بازیابی گذرواژه را برای ایمیل هر حساب فعال درخواست کند. ماتریس فعلی مبتنی بر نقش است: حسابدار به نمای کلی/فروش/موجودی/گزارش/تنظیمات؛ غرفه‌دار فقط به فروش غرفه تخصیص‌یافته؛ مدیریت حساب‌ها فقط به مدیر دارای `can_manage_users`. گذرواژه موجود هیچ‌گاه نمایش داده نمی‌شود.

## اصلاح r6.3 برای خطای باقی‌مانده کتابخانه
در r6.2 نام فایل UMD اشتباه تعیین شده بود (`supabase.min.js`). نسخه رسمی این بسته فایل `dist/umd/supabase.js` را ارائه می‌کند. r6.3 این نام را در CDN، آماده‌سازی Native و Service Worker یکسان کرده است. پس از ساخت، داخل `www/vendor/supabase.js` باید فایل SDK وجود داشته باشد.

## پیش‌فرض ورود مدیر در r6.3.1

ایمیل `alijim88887777@gmail.com` هنگام بازشدن فرم ورود به‌صورت پیش‌فرض نمایش داده می‌شود. گذرواژه در بسته ذخیره نشده و از طریق دکمه بازیابی ایمیلی، باید روی حساب واقعی Supabase تعیین شود. شرح کامل در `ADMIN_LOGIN_FA.md` آمده است.


## ورود در نسخه r6.3.2
صفحهٔ ورود دو روش دارد: ایمیل/گذرواژه و کد یک‌بارمصرف ایمیل. برای روش کد، در Supabase → Authentication → Email Templates → Magic Link باید `{{ .Token }}` در قالب باشد و SMTP فعال باشد. این روش کد را درون APK تأیید می‌کند؛ نیازی به deep link یا بازشدن مرورگر نیست. هر دو روش به حساب واقعی Supabase و پروفایل فعال `mrk_user_profiles` نیاز دارند.

شناسه پروژه‌ای که این سورس به آن متصل است در `app.js` تنظیم شده است؛ پیش از انتشار آن را با پروژهٔ واقعی خود تطبیق دهید.

## کتابخانه احراز هویت امن r6.3.3

- نشست APK با افزونه Secure Storage در Android Keystore و AES-256-GCM نگهداری می‌شود.
- اگر افزونه در Native ساخته و بارگذاری نشود، برنامه به ذخیره‌سازی ناامن fallback نمی‌کند و ورود متوقف می‌شود.
- نشست وب/PWA فقط در حافظهٔ همان اجرا نگهداری می‌شود و با بارگذاری مجدد صفحه باید دوباره وارد شوید.
- پیش از ساخت Native، `npm install` و سپس فرایند `npm run android:debug` پل Keystore را Bundle می‌کند.
- گزارش فنی: `AUTH_LIBRARY_RELEASE_REPORT_FA.md` و راهنمای مستقل: `AUTH_LIBRARY_README_FA.md`.
