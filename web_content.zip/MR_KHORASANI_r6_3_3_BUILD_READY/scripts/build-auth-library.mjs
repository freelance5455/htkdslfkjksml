import { build } from 'esbuild';
import { mkdir } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

export async function buildAuthLibrary() {
  const output = path.join(root, 'vendor', 'mrk-secure-storage.js');
  await mkdir(path.dirname(output), { recursive: true });
  await build({
    absWorkingDir: root,
    entryPoints: ['scripts/secure-storage-entry.mjs'],
    outfile: output,
    bundle: true,
    platform: 'browser',
    format: 'iife',
    target: ['es2020'],
    minify: true,
    sourcemap: false,
    legalComments: 'none',
  });
  console.log('MRK native secure-storage bridge bundled:', path.relative(root, output));
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  await buildAuthLibrary();
}
