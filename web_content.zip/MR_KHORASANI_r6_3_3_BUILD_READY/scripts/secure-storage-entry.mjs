import { SecureStorage } from '@capnative/capacitor-secure-storage';

// The native implementation uses Android Keystore / iOS Keychain.
// This bridge is bundled into the app; web mode never calls the plugin.
if (typeof globalThis !== 'undefined') {
  globalThis.MRKNativeSecureStorage = SecureStorage;
}
