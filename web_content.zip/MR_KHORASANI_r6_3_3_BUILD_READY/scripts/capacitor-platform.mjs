import { existsSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const platform = process.argv[2];
const action = process.argv[3] || 'setup';
if (!['android','ios'].includes(platform)) throw new Error('Platform must be android or ios.');
const isWin = process.platform === 'win32';
const npx = isWin ? 'npx.cmd' : 'npx';
function run(command, args, cwd=root) {
  const result = spawnSync(command, args, { cwd, stdio: 'inherit', shell: isWin, env: process.env });
  if (result.status !== 0) process.exit(result.status || 1);
}
run(process.execPath, [path.join(root,'scripts','prepare-native-assets.mjs')]);
const nativeDir = path.join(root, platform);
if (existsSync(nativeDir)) run(npx, ['cap','sync',platform]);
else { run(npx, ['cap','add',platform]); run(npx, ['cap','sync',platform]); }
if (action === 'setup') {
  console.log(`${platform} native project is ready. Open it in the relevant IDE.`);
} else if (platform === 'android' && action === 'debug') {
  const gradlew = isWin ? 'gradlew.bat' : './gradlew';
  run(gradlew, ['assembleDebug'], nativeDir);
  console.log('Debug APK: android/app/build/outputs/apk/debug/app-debug.apk');
} else if (platform === 'ios' && action === 'simulator') {
  const xcode = path.join(nativeDir,'App','App.xcodeproj');
  run('xcodebuild', ['-project',xcode,'-scheme','App','-sdk','iphonesimulator','-configuration','Debug','-derivedDataPath',path.join(root,'build','ios-simulator'),'CODE_SIGNING_ALLOWED=NO'], root);
  console.log('iOS Simulator .app is in build/ios-simulator/Build/Products/Debug-iphonesimulator/');
} else if (platform === 'android' && action === 'open') {
  run(npx,['cap','open','android']);
} else if (platform === 'ios' && action === 'open') {
  run(npx,['cap','open','ios']);
} else {
  throw new Error(`Unsupported action ${action} for ${platform}`);
}
