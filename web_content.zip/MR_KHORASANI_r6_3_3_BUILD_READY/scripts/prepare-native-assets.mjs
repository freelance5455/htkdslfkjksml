import { copyFile, mkdir, readFile, writeFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import path from 'node:path';
import { buildAuthLibrary } from './build-auth-library.mjs';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const www = path.join(root, 'www');
await buildAuthLibrary();

const files = [
  'index.html','styles.css','supabase-loader.js','auth-library.js','app.js','cloud-sync.js','seed.js','sales-domain.js',
  'persian-calendar.js','excel-export.js','manifest.webmanifest','sw.js',
  'icon.svg','icon-512.png','apple-touch-icon.png','vendor/mrk-secure-storage.js'
];
await mkdir(www, { recursive: true });
for (const file of files) {
  const destination = path.join(www, file);
  await mkdir(path.dirname(destination), { recursive: true });
  await copyFile(path.join(root, file), destination);
}
const sdk = path.join(root, 'node_modules', '@supabase', 'supabase-js', 'dist', 'umd', 'supabase.js');
if (!existsSync(sdk)) throw new Error('Supabase UMD SDK not found. Run npm install before native:prepare.');
await mkdir(path.join(www, 'vendor'), { recursive: true });
await copyFile(sdk, path.join(www, 'vendor', 'supabase.js'));
const indexPath = path.join(www, 'index.html');
let html = await readFile(indexPath, 'utf8');
const loaderTag = '<script src="supabase-loader.js"></script>';
const localSdkTag = '<script src="./vendor/supabase.js"></script>';
if (!html.includes(loaderTag)) throw new Error('Supabase loader tag was not found in index.html; refusing to build without the authentication dependency.');
if (!html.includes(localSdkTag)) html = html.replace(loaderTag, `${localSdkTag}${loaderTag}`);
if (!html.includes(localSdkTag) || !html.includes(loaderTag)) throw new Error('Local Supabase SDK preload could not be configured.');
await writeFile(indexPath, html, 'utf8');
const appPath = path.join(www, 'app.js');
let app = await readFile(appPath, 'utf8');
const sw = "if('serviceWorker'in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));";
const nativeAware = "if('serviceWorker'in navigator && !window.Capacitor?.isNativePlatform?.())window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));";
if (app.includes(sw)) app = app.replace(sw, nativeAware);
else if (!app.includes('Capacitor?.isNativePlatform')) throw new Error('Service-worker registration anchor changed; review native compatibility before building.');
await writeFile(appPath, app, 'utf8');
console.log('Native web assets prepared in www/ with locally bundled Supabase SDK.');
