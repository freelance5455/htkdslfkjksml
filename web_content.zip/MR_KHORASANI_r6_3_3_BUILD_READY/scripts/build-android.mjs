import { spawnSync } from 'node:child_process';
import { copyFile, mkdir, access, readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const isWindows = process.platform === 'win32';
const npm = isWindows ? 'npm.cmd' : 'npm';

function run(command, args) {
  const result = spawnSync(command, args, {
    cwd: root,
    stdio: 'inherit',
    shell: isWindows,
    env: process.env,
  });
  if (result.error) throw result.error;
  if (result.status !== 0) process.exit(result.status ?? 1);
}

const [major] = process.versions.node.split('.').map(Number);
if (major < 22) {
  throw new Error(`Node.js 22+ is required. Current version: ${process.version}`);
}
const npmVersion = spawnSync(npm, ['--version'], { cwd: root, encoding: 'utf8', shell: isWindows, env: process.env });
if (npmVersion.error || npmVersion.status !== 0) throw new Error('npm could not be executed. Install npm 10.9 or newer.');
const [npmMajor, npmMinor] = npmVersion.stdout.trim().split('.').map(Number);
if (npmMajor < 10 || (npmMajor === 10 && npmMinor < 9)) throw new Error(`npm 10.9+ is required. Current version: ${npmVersion.stdout.trim()}`);

const lockfile = path.join(root, 'package-lock.json');
try {
  await access(lockfile);
  run(npm, ['ci']);
} catch (error) {
  if (error?.code !== 'ENOENT') throw error;
  console.log('No package-lock.json found. Installing pinned direct dependencies and generating a lockfile.');
  run(npm, ['install']);
}

run(npm, ['test']);
run(npm, ['run', 'check']);
run(npm, ['run', 'android:debug']);

const apkSource = path.join(root, 'android', 'app', 'build', 'outputs', 'apk', 'debug', 'app-debug.apk');
try { await access(apkSource); } catch { throw new Error(`Gradle completed without producing the expected APK: ${apkSource}`); }
const dist = path.join(root, 'dist');
await mkdir(dist, { recursive: true });
const apkDestination = path.join(dist, 'MR-KHORASANI-r6.3.3-secure-auth-debug.apk');
await copyFile(apkSource, apkDestination);
const digest = createHash('sha256').update(await readFile(apkDestination)).digest('hex');
await writeFile(`${apkDestination}.sha256`, `${digest}  MR-KHORASANI-r6.3.3-secure-auth-debug.apk\n`, 'utf8');
console.log(`\nBuild complete: dist/MR-KHORASANI-r6.3.3-secure-auth-debug.apk`);
