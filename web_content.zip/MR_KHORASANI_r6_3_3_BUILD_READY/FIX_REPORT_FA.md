# گزارش اصلاح خطای کتابخانه احراز هویت — r6.3

## علت تأییدشده در سورس r6.2
نام فایل UMD کتابخانه Supabase در سه نقطه اشتباه ثبت شده بود: دو مسیر CDN در `supabase-loader.js`، مسیر منبع در `scripts/prepare-native-assets.mjs` و فهرست SDKهای Service Worker در `sw.js`. مسیر تنظیم‌شده `dist/umd/supabase.min.js` بود، درحالی‌که مسیر UMD بسته رسمی مورد استفاده `dist/umd/supabase.js` است.

## اصلاح r6.3
- همه ارجاعات به فایل درست `dist/umd/supabase.js` تغییر کرده‌اند.
- آماده‌سازی Android فایل را از `node_modules/@supabase/supabase-js/dist/umd/supabase.js` به `www/vendor/supabase.js` کپی می‌کند.
- فایل `www/index.html` اسکریپت SDK محلی را پیش از `supabase-loader.js` اجرا می‌کند.
- CDNهای وب و Preview هم به فایل درست اشاره می‌کنند.
- Service Worker کش را با نام نسخه جدید می‌سازد و مسیرهای صحیح SDK را در فهرست پیش‌بارگذاری قرار می‌دهد.
- آزمون قراردادی جدید، بازگشت `supabase.min.js` را رد می‌کند.

## کنترل خروجی Native پس از آماده‌سازی
پس از اجرای `npm install` و `npm run android:setup` باید این موارد موجود باشند:
- `www/vendor/supabase.js`
- `www/supabase-loader.js`
- در `www/index.html`، تگ `./vendor/supabase.js` قبل از `supabase-loader.js` قرار گرفته باشد.

## محدودیت مبدل ZIP-to-APK
این ZIP سورس Capacitor است و شامل `node_modules` یا APK کامپایل‌شده نیست. مبدل ساده ZIP-to-APK معمولاً `npm install` و `scripts/prepare-native-assets.mjs` را اجرا نمی‌کند؛ در آن حالت SDK محلی ساخته نمی‌شود و Preview فقط در صورت دسترسی شبکه به یکی از CDNهای صحیح کار خواهد کرد. برای APK قابل اتکا، `build-android.bat` یا GitHub Actions باید اجرا شود.

## آزمون‌ها
- `npm run check`: موفق
- `npm test`: 132 موفق، 0 ناموفق
- ساخت APK واقعی، اجرای WebView روی دستگاه و تست زنده CDN در محیط فعلی انجام نشده‌اند.
