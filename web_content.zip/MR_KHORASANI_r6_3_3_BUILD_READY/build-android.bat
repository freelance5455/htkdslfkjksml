@echo off
setlocal
cd /d "%~dp0"
call npm run build:android || exit /b 1
