/*
 * MR KHORASANI Cloud Authentication Library
 * - Supabase Auth v2 client factory is injected by the app's pinned SDK loader.
 * - Native session persistence is delegated to Android Keystore / iOS Keychain.
 * - Browser sessions are memory-only; localStorage is intentionally never used.
 */
(function (root, factory) {
  const api = factory(root);
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) root.MRKAuthLibrary = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (root) {
  'use strict';

  const AUTH_STORAGE_VERSION = 'v1';
  const AUTH_STORAGE_PREFIX = 'mrk-auth:';
  const PROFILE_COLUMNS = 'user_id,company_id,user_code,display_name,email,role,booth_code,can_manage_users,is_active';

  function normalizeEmail(email) {
    return String(email || '').trim().toLowerCase();
  }

  function validEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizeEmail(email));
  }

  function normalizeOtp(value) {
    const persian = '۰۱۲۳۴۵۶۷۸۹';
    const arabic = '٠١٢٣٤٥٦٧٨٩';
    return String(value || '').replace(/[۰-۹٠-٩]/g, digit => {
      const p = persian.indexOf(digit);
      return String(p >= 0 ? p : arabic.indexOf(digit));
    }).replace(/[\s-]/g, '');
  }

  function isPrivilegedKey(value) {
    const key = String(value || '').trim();
    if (/^sb_secret_/i.test(key) || /service[_-]?role/i.test(key)) return true;
    const parts = key.split('.');
    if (parts.length !== 3) return false;
    try {
      const encoded = parts[1].replace(/-/g, '+').replace(/_/g, '/');
      const padded = encoded + '='.repeat((4 - encoded.length % 4) % 4);
      const decoded = typeof root.atob === 'function'
        ? root.atob(padded)
        : (typeof Buffer !== 'undefined' ? Buffer.from(padded, 'base64').toString('utf8') : '');
      const payload = JSON.parse(decoded || '{}');
      return ['service_role', 'supabase_admin'].includes(String(payload.role || '').toLowerCase());
    } catch (_) {
      return false;
    }
  }

  function createMemoryStorage() {
    const values = new Map();
    return Object.freeze({
      async getItem(key) { return values.has(key) ? values.get(key) : null; },
      async setItem(key, value) { values.set(key, String(value)); },
      async removeItem(key) { values.delete(key); },
    });
  }

  function createSecureStorageAdapter(nativeStorage, prefix = AUTH_STORAGE_PREFIX) {
    if (!nativeStorage || typeof nativeStorage.get !== 'function' ||
        typeof nativeStorage.set !== 'function' || typeof nativeStorage.remove !== 'function') {
      throw new Error('Secure storage plugin is unavailable; refusing an unencrypted session fallback.');
    }
    const keyFor = key => `${prefix}${String(key)}`;
    return Object.freeze({
      async getItem(key) {
        const storageKey = keyFor(key);
        try {
          const result = await nativeStorage.get({ key: storageKey });
          return result?.value === null || result?.value === undefined ? null : String(result.value);
        } catch (error) {
          // A corrupted/tampered ciphertext must never be reused. Remove only that
          // session key and let Supabase initialize as signed-out; other Keystore
          // failures remain fatal so we never downgrade to plaintext storage.
          if (error?.code === 'DECRYPTION_ERROR') {
            await nativeStorage.remove({ key: storageKey });
            return null;
          }
          throw error;
        }
      },
      async setItem(key, value) {
        await nativeStorage.set({ key: keyFor(key), value: String(value) });
      },
      async removeItem(key) {
        await nativeStorage.remove({ key: keyFor(key) });
      },
    });
  }

  function projectStorageKey(url) {
    const host = new URL(url).hostname.toLowerCase();
    const projectRef = host.endsWith('.supabase.co') ? host.slice(0, -'.supabase.co'.length) : host;
    const safeRef = projectRef.replace(/[^a-z0-9.-]/g, '-').slice(0, 100);
    return `mrk-khorasani-auth-${AUTH_STORAGE_VERSION}-${safeRef}`;
  }

  function createAuthLibrary(dependencies = {}) {
    const createClient = dependencies.createClient;
    const isNative = typeof dependencies.isNative === 'function'
      ? dependencies.isNative
      : () => dependencies.isNative === true || Boolean(root.Capacitor?.isNativePlatform?.());
    const nativeStorage = Object.prototype.hasOwnProperty.call(dependencies, 'nativeStorage')
      ? dependencies.nativeStorage
      : (root.MRKNativeSecureStorage || null);
    let client = null;
    let mode = null;
    let initialized = false;

    function requireClient() {
      if (!initialized || !client) throw new Error('Cloud authentication library has not been initialized.');
      return client;
    }

    async function initialize({ url, publicKey } = {}) {
      if (initialized) return client;
      if (typeof createClient !== 'function') throw new Error('Supabase createClient function is unavailable.');
      if (!url || !publicKey) throw new Error('Supabase URL and publishable key are required.');
      const parsed = new URL(url);
      if (parsed.protocol !== 'https:' && parsed.hostname !== 'localhost' && parsed.hostname !== '127.0.0.1') {
        throw new Error('Cloud authentication requires HTTPS.');
      }
      if (isPrivilegedKey(publicKey)) {
        throw new Error('A Supabase secret or service-role credential must never be used in a client application.');
      }

      const native = Boolean(isNative());
      let storage;
      if (native) {
        storage = createSecureStorageAdapter(nativeStorage);
        mode = 'native-keystore';
      } else {
        // Web fallback is intentionally volatile: a reload requires a fresh login.
        storage = createMemoryStorage();
        mode = 'web-memory-only';
      }

      client = createClient(url, publicKey, {
        auth: {
          storage,
          storageKey: projectStorageKey(url),
          persistSession: true,
          autoRefreshToken: true,
          detectSessionInUrl: !native,
          flowType: 'pkce',
          skipAutoInitialize: true,
        },
      });

      try {
        if (typeof client?.auth?.initialize === 'function') {
          const result = await client.auth.initialize();
          if (result?.error) throw result.error;
        }
        if (!client?.auth) throw new Error('Supabase Auth client could not be initialized.');
        initialized = true;
        return client;
      } catch (error) {
        client = null;
        mode = null;
        throw new Error(`Cloud authentication initialization failed: ${error?.message || 'unknown error'}`);
      }
    }

    async function signInWithPassword(email, password) {
      const normalized = normalizeEmail(email);
      if (!validEmail(normalized)) throw new Error('ایمیل معتبر وارد کنید.');
      if (!String(password || '')) throw new Error('گذرواژه را وارد کنید.');
      return requireClient().auth.signInWithPassword({ email: normalized, password: String(password) });
    }

    async function requestEmailOtp(email) {
      const normalized = normalizeEmail(email);
      if (!validEmail(normalized)) throw new Error('ایمیل معتبر وارد کنید.');
      return requireClient().auth.signInWithOtp({
        email: normalized,
        options: { shouldCreateUser: false },
      });
    }

    async function verifyEmailOtp(email, token) {
      const normalized = normalizeEmail(email);
      const code = normalizeOtp(token);
      if (!validEmail(normalized)) throw new Error('ایمیل معتبر وارد کنید.');
      if (!/^[0-9]{6,8}$/.test(code)) throw new Error('کد ورود باید ۶ تا ۸ رقم باشد.');
      return requireClient().auth.verifyOtp({ email: normalized, token: code, type: 'email' });
    }

    async function requestPasswordReset(email) {
      const normalized = normalizeEmail(email);
      if (!validEmail(normalized)) throw new Error('ایمیل معتبر وارد کنید.');
      // Redirect destinations are controlled by the Supabase project's allow-list,
      // not accepted from arbitrary UI input.
      return requireClient().auth.resetPasswordForEmail(normalized);
    }

    async function updatePassword(password) {
      const value = String(password || '');
      if (value.length < 12) throw new Error('گذرواژه باید حداقل ۱۲ نویسه داشته باشد.');
      return requireClient().auth.updateUser({ password: value });
    }

    async function getVerifiedUser() {
      const auth = requireClient().auth;
      const { data: sessionData, error: sessionError } = await auth.getSession();
      if (sessionError) throw sessionError;
      if (!sessionData?.session) return null;
      const { data, error } = await auth.getUser();
      if (error) throw error;
      return data?.user || null;
    }

    async function getAuthorizedProfile({ userId, companyId } = {}) {
      if (!userId || !companyId) throw new Error('Authenticated user and company scope are required.');
      const verifiedUser = await getVerifiedUser();
      if (!verifiedUser || verifiedUser.id !== userId) {
        throw new Error('Authenticated identity does not match the requested workspace profile.');
      }
      const { data, error } = await requireClient().from('mrk_user_profiles')
        .select(PROFILE_COLUMNS)
        .eq('user_id', userId)
        .eq('company_id', companyId)
        .maybeSingle();
      if (error) throw error;
      if (!data || data.user_id !== userId || data.company_id !== companyId || data.is_active !== true) {
        throw new Error('برای این حساب کاربری مجوز فعال در سامانه تعریف نشده است.');
      }
      if (!['accountant', 'booth'].includes(data.role)) {
        throw new Error('نقش این حساب برای ورود به محیط کار معتبر نیست.');
      }
      if (!data.user_code || !data.display_name || (data.role === 'booth' && !data.booth_code)) {
        throw new Error('پروفایل کاربر ناقص است؛ مدیر سامانه باید اطلاعات دسترسی را اصلاح کند.');
      }
      if (data.can_manage_users === true && data.role !== 'accountant') {
        throw new Error('ترکیب نقش و مجوز مدیریت این حساب معتبر نیست.');
      }
      return data;
    }

    async function signOut() {
      const active = requireClient();
      const { error } = await active.auth.signOut({ scope: 'local' });
      if (error) throw error;
      return true;
    }

    function onAuthStateChange(callback) {
      if (typeof callback !== 'function') throw new TypeError('Auth state callback must be a function.');
      return requireClient().auth.onAuthStateChange(callback);
    }

    return Object.freeze({
      initialize,
      signInWithPassword,
      requestEmailOtp,
      verifyEmailOtp,
      requestPasswordReset,
      updatePassword,
      getVerifiedUser,
      getAuthorizedProfile,
      signOut,
      onAuthStateChange,
      get client() { return client; },
      get securityMode() { return mode; },
      get initialized() { return initialized; },
    });
  }

  return Object.freeze({
    createAuthLibrary,
    createMemoryStorage,
    createSecureStorageAdapter,
    normalizeEmail,
    normalizeOtp,
  });
});
