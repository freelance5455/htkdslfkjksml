(function (root) {
  'use strict';
  const EVENT_TYPES = Object.freeze([
    'sale_bundle', 'booth_closure', 'purchase_bundle', 'warehouse_transfer_bundle',
    'warehouse_transfer_in', 'booth_transfer_bundle', 'inventory_bundle',
    'sale_return_bundle', 'final_closure', 'reconciliation_bundle', 'product_upsert', 'product_catalog_refresh'
  ]);
  const BOOTH_READ_TYPES = Object.freeze([
    'sale_bundle', 'booth_closure', 'warehouse_transfer_in', 'booth_transfer_bundle',
    'sale_return_bundle', 'inventory_bundle', 'product_catalog_refresh'
  ]);
  const BOOTH_WRITE_TYPES = Object.freeze(['sale_bundle', 'booth_closure']);

  function canSubmit(profile, eventType, boothCode, payload) {
    if (!profile || profile.is_active !== true || !profile.company_id || !EVENT_TYPES.includes(eventType)) return false;
    if (profile.role === 'accountant') return true;
    if (profile.role !== 'booth' || !profile.booth_code || profile.booth_code !== boothCode || !BOOTH_WRITE_TYPES.includes(eventType)) return false;
    if (eventType === 'sale_bundle') return Boolean(payload?.sale && payload.sale.boothCode === profile.booth_code);
    if (eventType === 'booth_closure') return Boolean(payload?.closure && payload.closure.boothCode === profile.booth_code);
    return false;
  }

  function createEvent({ profile, eventType, boothCode = null, entityId, payload, deviceId, idFactory, now }) {
    if (!canSubmit(profile, eventType, boothCode, payload)) throw new Error('اجازه ارسال این رویداد برای کاربر فعلی وجود ندارد.');
    if (!entityId || !payload || !deviceId) throw new Error('شناسه رکورد، محتوا و دستگاه برای همگام‌سازی الزامی است.');
    const makeId = idFactory || (() => root.crypto?.randomUUID?.());
    const eventId = makeId();
    if (!eventId) throw new Error('ساخت شناسه یکتای رویداد ممکن نشد.');
    return {
      event_id: eventId,
      company_id: profile.company_id,
      booth_code: boothCode,
      event_type: eventType,
      entity_id: String(entityId),
      payload,
      actor_id: profile.user_id,
      device_id: deviceId,
      created_at: (now || (() => new Date().toISOString()))()
    };
  }

  function upsert(list, row, key = 'id') {
    if (!row || row[key] == null) return;
    const index = list.findIndex(item => item?.[key] === row[key]);
    if (index < 0) list.push(row); else list[index] = row;
  }

  function reduceEvent(state, event) {
    const next = { ...state };
    for (const name of ['sales', 'purchases', 'stock', 'movements', 'dayClosures', 'reconciliations', 'products']) {
      next[name] = Array.isArray(state[name]) ? state[name].slice() : [];
    }
    const payload = event?.payload || {};
    const type = event?.event_type;
    if (type === 'sale_bundle' && payload.sale) upsert(next.sales, payload.sale);
    if (type === 'purchase_bundle' && payload.purchase) upsert(next.purchases, payload.purchase);
    if (type === 'booth_closure' && payload.closure) upsert(next.dayClosures, payload.closure);
    if (type === 'final_closure' && payload.closure) upsert(next.dayClosures, payload.closure);
    for (const rec of payload.reconciliations || (payload.reconciliation ? [payload.reconciliation] : [])) upsert(next.reconciliations, rec);
    for (const product of payload.products || (payload.product ? [payload.product] : [])) upsert(next.products, product);
    for (const stock of payload.stockUpdates || []) upsert(next.stock, stock);
    for (const movement of payload.movements || []) upsert(next.movements, movement);
    return next;
  }

  const api = { EVENT_TYPES, BOOTH_READ_TYPES, BOOTH_WRITE_TYPES, canSubmit, createEvent, reduceEvent };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.CloudSync = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
