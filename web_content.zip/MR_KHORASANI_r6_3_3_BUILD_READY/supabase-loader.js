/* MR KHORASANI auth dependency loader — pinned Supabase JS v2.119.2 */
(function (root) {
  'use strict';
  const VERSION = '2.119.2';
  const CLASSIC_SOURCES = [
    `https://cdn.jsdelivr.net/npm/@supabase/supabase-js@${VERSION}/dist/umd/supabase.js`,
    `https://unpkg.com/@supabase/supabase-js@${VERSION}/dist/umd/supabase.js`
  ];
  const MODULE_SOURCE = `https://esm.sh/@supabase/supabase-js@${VERSION}?bundle`;

  function loadClassic(src) {
    return new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = src;
      script.async = true;
      script.crossOrigin = 'anonymous';
      script.onload = () => {
        if (root.supabase && typeof root.supabase.createClient === 'function') resolve(src);
        else reject(new Error('SDK script loaded without createClient'));
      };
      script.onerror = () => reject(new Error('SDK source could not be loaded'));
      document.head.appendChild(script);
    });
  }

  async function loadSdk() {
    if (root.supabase && typeof root.supabase.createClient === 'function') return 'already-loaded';
    const failures = [];
    for (const src of CLASSIC_SOURCES) {
      try {
        await loadClassic(src);
        return src;
      } catch (error) {
        failures.push(`${new URL(src).hostname}: ${error.message}`);
      }
    }
    try {
      const module = await import(MODULE_SOURCE);
      if (typeof module.createClient !== 'function') throw new Error('createClient export missing');
      root.supabase = { createClient: module.createClient };
      return MODULE_SOURCE;
    } catch (error) {
      failures.push(`esm.sh: ${error.message}`);
    }
    throw new Error('کتابخانه احراز هویت بارگذاری نشد. اتصال اینترنت یا دسترسی WebView به CDNها را بررسی کنید. جزئیات: ' + failures.join(' | '));
  }

  root.MRK_SUPABASE_READY = loadSdk();
})(window);
