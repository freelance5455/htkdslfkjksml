const CACHE='mr-khorasani-shell-v16-r633-secure-auth-keystore';
const SDK_URLS=[
 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.119.2/dist/umd/supabase.js',
 'https://unpkg.com/@supabase/supabase-js@2.119.2/dist/umd/supabase.js',
 'https://esm.sh/@supabase/supabase-js@2.119.2?bundle'
];
const ASSETS=['./','./index.html','./styles.css','./app.js','./cloud-sync.js','./supabase-loader.js','./auth-library.js','./vendor/mrk-secure-storage.js','./seed.js','./sales-domain.js','./persian-calendar.js','./excel-export.js','./manifest.webmanifest','./icon.svg','./apple-touch-icon.png','./icon-512.png'];
self.addEventListener('install',event=>{event.waitUntil((async()=>{const cache=await caches.open(CACHE);await cache.addAll(ASSETS);await Promise.allSettled(SDK_URLS.map(url=>cache.add(url)));await self.skipWaiting()})())});
self.addEventListener('activate',event=>{event.waitUntil((async()=>{const keys=await caches.keys();await Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)));await self.clients.claim()})())});
self.addEventListener('fetch',event=>{if(event.request.method!=='GET')return;event.respondWith((async()=>{const cached=await caches.match(event.request);if(cached)return cached;try{const response=await fetch(event.request);const url=new URL(event.request.url);if(response&&response.ok&&(url.origin===self.location.origin||SDK_URLS.includes(url.href))){const copy=response.clone();caches.open(CACHE).then(cache=>cache.put(event.request,copy))}return response}catch(_){if(event.request.mode==='navigate')return caches.match('./index.html');return Response.error()}})())});
