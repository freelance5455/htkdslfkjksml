const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const Domain = require('../sales-domain.js');

test('Jalali calendar parses Persian digits and round-trips a known date', () => {
  const Cal = require('../persian-calendar.js');
  assert.equal(Cal.toGregorian('۱۴۰۵/۰۹/۰۶'), '2026-11-27');
  assert.equal(Cal.toJalali('2026-11-27'), '۱۴۰۵/۰۹/۰۶');
  assert.equal(Cal.toGregorian('1405-09-06'), '2026-11-27');
});

test('booth closing snapshot aggregates sales, POS terminals, stock and daily movements', () => {
  const snapshot = Domain.buildBoothClosingSnapshot({
    id: '2026-11-27::G01', boothCode: 'G01', boothName: 'آرش', boothHolderName: 'آرش', day: '2026-11-27', closedAt: '2026-11-27T20:00:00.000Z',
    sales: [{ id: 'S1', boothCode: 'G01', day: '2026-11-27', expectedAmount: 5000, payments: [{type:'POS',posCode:'P1',amount:3000},{type:'CASH',amount:1000}], lines:[{productKey:'P1',name:'آب',qty:2,unitPrice:2500,lineTotal:5000}] }],
    stockRecords: [{ id:'G01::P1', boothCode:'G01', productKey:'P1', openingQty:10, movements:[{id:'s1',type:'SALE',delta:-2,at:'2026-11-27T10:00:00.000Z'}] }],
    movements: [{id:'s1',boothCode:'G01',productKey:'P1',type:'SALE',delta:-2,at:'2026-11-27T10:00:00.000Z'}],
    posTerminals: [{code:'P1',boothCode:'G01'}]
  });
  assert.equal(snapshot.ok, true);
  assert.equal(snapshot.closure.salesCount, 1);
  assert.equal(snapshot.closure.expectedPosTotals[0].amount, 3000);
  assert.equal(snapshot.closure.stockRows[0].closingQty, 8);
  assert.equal(snapshot.closure.salesLines[0].qty, 2);
});

test('booth closure reconciliation detects individual terminal mismatch and returns written report', () => {
  const closure = { id:'2026-11-27::G01', day:'2026-11-27', boothCode:'G01', boothName:'آرش', salesCount:2, expectedPosTotals:[{posCode:'P1',amount:3000},{posCode:'P2',amount:1500}] };
  const result = Domain.reconcileBoothClosing({closure, actualPosTotals:[{posCode:'P1',amount:3000},{posCode:'P2',amount:1400}], reconciledAt:'2026-11-27T22:00:00.000Z'});
  assert.equal(result.ok, true);
  assert.equal(result.closure.totalDifference, -100);
  assert.match(result.closure.reportText, /مغایرت/);
  assert.equal(result.closure.reconciliationRows[1].difference, -100);
});

test('booth closing rejects missing terminal totals and malformed amounts', () => {
  const closure = { id:'x', expectedPosTotals:[{posCode:'P1',amount:20}] };
  assert.equal(Domain.reconcileBoothClosing({closure, actualPosTotals:[]}).code, 'CLOSING_POS_TOTALS_REQUIRED');
  assert.equal(Domain.reconcileBoothClosing({closure, actualPosTotals:[{posCode:'P1',amount:-1}]}).code, 'CLOSING_POS_TOTALS_INVALID');
});

test('OOXML export creates a real xlsx zip package with multiple worksheet parts', () => {
  const X = require('../excel-export.js');
  const bytes = X.createWorkbookBytes({sheets:[{name:'فروش',rows:[['غرفه','فروش'],['G01',12345]]},{name:'موجودی',rows:[['کالا','مانده'],['آب',12]]}]});
  const text = Buffer.from(bytes).toString('latin1');
  assert.equal(bytes[0], 0x50);
  assert.equal(bytes[1], 0x4b);
  assert.match(text, /xl\/worksheets\/sheet1.xml/);
  assert.match(text, /xl\/worksheets\/sheet2.xml/);
  assert.match(text, /\[Content_Types\]\.xml/);
  const buffer = Buffer.from(bytes);
  const eocd = buffer.lastIndexOf(Buffer.from([0x50, 0x4b, 0x05, 0x06]));
  assert.ok(eocd >= 0, 'end-of-central-directory record must exist');
  const centralOffset = buffer.readUInt32LE(eocd + 16);
  assert.equal(buffer.subarray(centralOffset, centralOffset + 4).toString('hex'), '504b0102');
  assert.equal(buffer.readUInt32LE(centralOffset + 42), 0, 'first local file offset must point to byte zero');
});

test('application includes day closure state, booth report export, Jalali inputs and deadline checks', () => {
  const app = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8');
  const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
  const sw = fs.readFileSync(path.join(__dirname, '..', 'sw.js'), 'utf8');
  assert.match(app, /DB_VERSION=7/);
  assert.match(app, /dayClosures/);
  assert.match(app, /saveBoothClosureAtomically/);
  assert.match(app, /finalizeBoothClosure/);
  assert.match(app, /createWorkbookBytes/);
  assert.match(app, /showDirectoryPicker/);
  assert.match(app, /checkClosingDeadline/);
  assert.match(app, /jalali-date/);
  assert.match(html, /persian-calendar\.js[\s\S]*excel-export\.js[\s\S]*app\.js/);
  assert.match(sw, /persian-calendar\.js/);
  assert.match(sw, /excel-export\.js/);
});

test('sales write checks the day closure record in the same atomic transaction', () => {
  const app = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8');
  assert.match(app, /db\.transaction\(\['sales','stock','movements','dayClosures'\],'readwrite'\)/);
  assert.match(app, /closureStore\.get\(.*input\.day.*input\.boothCode/);
  assert.match(app, /روز این غرفه بسته شده است/);
});

test('preliminary booth close report includes Persian local date and payment-source totals', () => {
  const domainSource = fs.readFileSync(path.join(__dirname, '..', 'sales-domain.js'), 'utf8');
  const appSource = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8');
  assert.match(domainSource, /جمع دریافت ثبت‌شده \(کارتخوان، نقدی و پرسنل\)/);
  assert.match(domainSource, /دریافت نقدی/);
  assert.match(domainSource, /دریافت پرسنلی/);
  assert.match(appSource, /saveFinalBoothClosureAtomically/);
  assert.match(appSource, /window\.addEventListener\('focus',\(\)=>\{checkClosingDeadline\(\);refreshCloud\(\)/);
});

test('booth closing workbook has separate sheets for sales, receipts, movements and ending stock', () => {
  const appSource = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8');
  assert.match(appSource, /name:'فروش اقلام'/);
  assert.match(appSource, /name:'دریافت‌ها'/);
  assert.match(appSource, /name:'گردش کالا'/);
  assert.match(appSource, /name:'مانده پایان دوره'/);
  assert.match(appSource, /name:'تطبیق کارتخوان'/);
});

test('iOS PWA package declares Apple web app metadata and local app icons', () => {
  const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
  const manifest = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'manifest.webmanifest'), 'utf8'));
  const sw = fs.readFileSync(path.join(__dirname, '..', 'sw.js'), 'utf8');
  assert.match(html, /apple-mobile-web-app-capable/);
  assert.match(html, /apple-touch-icon\.png/);
  assert.ok(manifest.icons.some(icon => icon.src === 'icon-512.png' && icon.sizes === '512x512'));
  assert.match(sw, /apple-touch-icon\.png/);
});
