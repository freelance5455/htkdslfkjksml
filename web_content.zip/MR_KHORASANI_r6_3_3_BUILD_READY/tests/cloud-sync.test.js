const test = require('node:test');
const assert = require('node:assert/strict');
const CloudSync = require('../cloud-sync.js');

test('accountant can submit all supported sync event types', () => {
  const profile = { role: 'accountant', is_active: true, company_id: 'company-1' };
  for (const type of CloudSync.EVENT_TYPES) {
    assert.equal(CloudSync.canSubmit(profile, type, 'G01'), true, type);
  }
});

test('booth user can only submit own sale and day-close events', () => {
  const profile = { role: 'booth', booth_code: 'G03', is_active: true, company_id: 'company-1' };
  assert.equal(CloudSync.canSubmit(profile, 'sale_bundle', 'G03', { sale: { boothCode: 'G03' } }), true);
  assert.equal(CloudSync.canSubmit(profile, 'booth_closure', 'G03', { closure: { boothCode: 'G03' } }), true);
  assert.equal(CloudSync.canSubmit(profile, 'sale_bundle', 'G02', { sale: { boothCode: 'G02' } }), false);
  assert.equal(CloudSync.canSubmit(profile, 'purchase_bundle', 'G03'), false);
  assert.equal(CloudSync.canSubmit(profile, 'warehouse_transfer_bundle', 'G03'), false);
});

test('inactive and malformed profiles cannot submit events', () => {
  assert.equal(CloudSync.canSubmit({ role: 'accountant', is_active: false }, 'sale_bundle', 'G01'), false);
  assert.equal(CloudSync.canSubmit(null, 'sale_bundle', 'G01'), false);
  assert.equal(CloudSync.canSubmit({ role: 'superadmin', is_active: true }, 'sale_bundle', 'G01'), false);
});

test('event builder requires identity and produces deterministic sync envelope fields', () => {
  const event = CloudSync.createEvent({
    profile: { role: 'booth', is_active: true, company_id: 'company-1', booth_code: 'G03', user_id: 'user-1' },
    eventType: 'sale_bundle', boothCode: 'G03', entityId: 'sale-1', payload: { sale: { id: 'sale-1', boothCode: 'G03' } },
    deviceId: 'device-1', idFactory: () => 'event-1', now: () => '2026-11-27T10:00:00.000Z'
  });
  assert.equal(event.event_id, 'event-1');
  assert.equal(event.company_id, 'company-1');
  assert.equal(event.actor_id, 'user-1');
  assert.equal(event.booth_code, 'G03');
  assert.equal(event.event_type, 'sale_bundle');
  assert.equal(event.created_at, '2026-11-27T10:00:00.000Z');
});

test('remote event reducer upserts sale and stock without duplicating movements', () => {
  const state = { sales: [], purchases: [], stock: [], movements: [], dayClosures: [], reconciliations: [] };
  const event = { event_id: 'e1', event_type: 'sale_bundle', payload: {
    sale: { id: 's1', boothCode: 'G03' },
    stockUpdates: [{ id: 'G03::p1', boothCode: 'G03', productKey: 'p1', movements: [{ id: 'm1', delta: -1 }] }],
    movements: [{ id: 'm1', stockId: 'G03::p1', delta: -1 }]
  }};
  const once = CloudSync.reduceEvent(state, event);
  const twice = CloudSync.reduceEvent(once, event);
  assert.equal(twice.sales.length, 1);
  assert.equal(twice.stock.length, 1);
  assert.equal(twice.movements.length, 1);
});
