const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '..');
const read = name => fs.readFileSync(path.join(root, name), 'utf8');

test('Supabase loader has independent pinned CDN sources and module fallback', () => {
  const loader = read('supabase-loader.js');
  assert.match(loader, /cdn\.jsdelivr\.net\/npm\/@supabase\/supabase-js@\$\{VERSION\}/);
  assert.match(loader, /unpkg\.com\/@supabase\/supabase-js@\$\{VERSION\}/);
  assert.match(loader, /esm\.sh\/@supabase\/supabase-js@\$\{VERSION\}\?bundle/);
  assert.match(loader, /MRK_SUPABASE_READY/);
});

test('HTML loads the local auth loader before application bootstrap and includes password recovery UI', () => {
  const html = read('index.html');
  assert.match(html, /supabase-loader\.js/);
  assert.ok(html.indexOf('supabase-loader.js') < html.indexOf('app.js'));
  assert.match(html, /id="forgotPasswordBtn"/);
  assert.match(html, /id="passwordRecoveryView"/);
  assert.match(html, /id="passwordRecoveryForm"/);
});

test('app waits for SDK readiness and implements email recovery plus authenticated password update', () => {
  const app = read('app.js');
  const auth = read('auth-library.js');
  assert.match(app, /await window\.MRK_SUPABASE_READY/);
  assert.match(auth, /resetPasswordForEmail\(normalized\)/);
  assert.match(app, /MRKAuth\.requestPasswordReset\(email\)/);
  assert.match(app, /requestPasswordRecovery\(email\)/);
  assert.match(app, /PASSWORD_RECOVERY/);
  assert.match(auth, /updateUser\(\{ password: value \}\)/);
  assert.match(app, /MRKAuth\.updatePassword\(password\)/);
  assert.match(app, /password\.length<12/);
});

test('service worker cache is versioned and does not answer failed script requests with index.html', () => {
  const sw = read('sw.js');
  assert.match(sw, /mr-khorasani-shell-v16-r633-secure-auth-keystore/);
  assert.match(sw, /\.\/supabase-loader\.js/);
  assert.match(sw, /event\.request\.mode==='navigate'/);
  assert.doesNotMatch(sw, /catch\(_\)\{return caches\.match\('\.\/index\.html'\)\}/);
});

test('admin user manager exposes user counts, effective access matrix and email-based password reset',()=>{
 const app=read('app.js');
 assert.match(app,/function renderUserAccessMatrix\(\)/);
 assert.match(app,/function renderCloudUsersPanel\(users,usersError=/);
 assert.match(app,/کل کاربران/);
 assert.match(app,/ماتریس دسترسی نقش‌ها/);
 assert.match(app,/data-reset-cloud-user/);
 assert.match(app,/requestPasswordRecovery\(email\)/);
 assert.match(app,/can_manage_users/);
 assert.match(app,/action:'list_users'/);
 assert.match(app,/functions\.invoke\('mrk-admin'/);
});


test('email OTP alternative keeps existing accounts only and verifies code inside the app',()=>{
 const app=read('app.js'), auth=read('auth-library.js'), html=read('index.html');
 assert.match(html,/id="otpModeBtn"/);
 assert.match(html,/id="otpLoginCode"/);
 assert.match(html,/id="verifyEmailOtpBtn"/);
 assert.match(auth,/signInWithOtp\(\{[\s\S]*shouldCreateUser:\s*false/);
 assert.match(auth,/verifyOtp\(\{ email: normalized, token: code, type: 'email' \}\)/);
 assert.match(app,/MRKAuth\.verifyEmailOtp/);
 assert.match(app,/completeCloudLogin\(data\.user\)/);
 assert.match(app,/function setLoginMode\(mode\)/);
});

test('OTP mode does not remove server-side role/profile authorization',()=>{
 const app=read('app.js'), auth=read('auth-library.js');
 assert.match(app,/async function verifyEmailOtp/);
 assert.match(app,/await completeCloudLogin\(data\.user\)/);
 assert.match(auth,/getAuthorizedProfile/);
 assert.match(auth,/is_active !== true/);
});

test('app auth entry points are routed through the cloud auth library',()=>{
 const app=read('app.js');
 assert.match(app,/MRKAuth\.signInWithPassword/);
 assert.match(app,/MRKAuth\.requestEmailOtp/);
 assert.match(app,/MRKAuth\.verifyEmailOtp/);
 assert.doesNotMatch(app,/supabaseClient\.auth\.(signInWithPassword|signInWithOtp|verifyOtp|getSession|getUser|signOut)/);
});
