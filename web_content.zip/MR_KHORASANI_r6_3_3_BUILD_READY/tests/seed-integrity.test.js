const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');

const context = { window: {} };
vm.createContext(context);
vm.runInContext(fs.readFileSync(require.resolve('../seed.js'), 'utf8'), context);
const seed = context.window.APP_SEED;

test('seed has unique product keys and stock identifiers', () => {
  assert.equal(new Set(seed.products.map(p => p.key)).size, seed.products.length);
  assert.equal(new Set(seed.stockRows.map(s => s.stockKey)).size, seed.stockRows.length);
});

test('every stock row references an assigned product and follows the canonical stock key', () => {
  const products = new Map(seed.products.map(p => [p.key, p]));
  for (const stock of seed.stockRows) {
    const product = products.get(stock.productKey);
    assert.ok(product, `Missing product ${stock.productKey}`);
    assert.ok(product.assignedStalls.includes(stock.boothCode), `Unassigned stock row ${stock.stockKey}`);
    assert.equal(stock.stockKey, `${stock.boothCode}::${stock.productKey}`);
  }
});

test('POS terminal codes are unique and each terminal belongs to a known booth', () => {
  assert.equal(new Set(seed.pos.map(p => p.code)).size, seed.pos.length);
  const booths = new Set(seed.booths.map(b => b.code));
  for (const terminal of seed.pos) {
    if (terminal.boothCode !== null) assert.ok(booths.has(terminal.boothCode));
  }
  assert.equal(seed.pos.filter(p => p.boothCode === null).length, 13);
});

test('unknown opening stock remains null and is not coerced to zero in seed data', () => {
  assert.ok(seed.stockRows.some(s => s.openingQty === null));
  assert.equal(seed.stockRows.filter(s => s.openingQty === null).length, 492);
});
