'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { createAuthLibrary, createSecureStorageAdapter, createMemoryStorage } = require('../auth-library.js');

function makeClientStub() {
  const calls = [];
  const client = {
    calls,
    auth: {
      initialize: async () => { calls.push(['initialize']); },
      signInWithPassword: async (value) => { calls.push(['signInWithPassword', value]); return { data: { user: { id: 'u-1' } }, error: null }; },
      signInWithOtp: async (value) => { calls.push(['signInWithOtp', value]); return { data: {}, error: null }; },
      verifyOtp: async (value) => { calls.push(['verifyOtp', value]); return { data: { user: { id: 'u-1' } }, error: null }; },
      getSession: async () => { calls.push(['getSession']); return { data: { session: { access_token: 'a', refresh_token: 'r' } }, error: null }; },
      getUser: async () => { calls.push(['getUser']); return { data: { user: { id: 'u-1' } }, error: null }; },
      resetPasswordForEmail: async (email, options) => { calls.push(['resetPasswordForEmail', email, options]); return { error: null }; },
      updateUser: async (value) => { calls.push(['updateUser', value]); return { error: null }; },
      signOut: async (options) => { calls.push(['signOut', options]); return { error: null }; },
      onAuthStateChange: (callback) => { calls.push(['onAuthStateChange']); return { data: { subscription: { unsubscribe() {} } } }; },
    },
    from(table) {
      return {
        select(columns) {
          return {
            eq(field, value) {
              return {
                eq(field2, value2) {
                  calls.push(['profileQuery', table, columns, field, value, field2, value2]);
                  return { maybeSingle: async () => ({ data: { user_id: 'u-1', company_id: 'company-1', role: 'accountant', user_code: 'ACC-01', display_name: 'مدیر مالی', is_active: true, can_manage_users: true }, error: null }) };
                },
              };
            },
          };
        },
      };
    },
  };
  return client;
}

test('secure storage adapter namespaces keys and delegates encrypted native storage operations', async () => {
  const values = new Map();
  const native = {
    async get({ key }) { return { value: values.get(key) ?? null }; },
    async set({ key, value }) { values.set(key, value); },
    async remove({ key }) { values.delete(key); },
  };
  const storage = createSecureStorageAdapter(native, 'mrk-auth:');
  await storage.setItem('sb-token', '{"refresh_token":"secret"}');
  assert.equal(await storage.getItem('sb-token'), '{"refresh_token":"secret"}');
  assert.equal(values.has('mrk-auth:sb-token'), true);
  await storage.removeItem('sb-token');
  assert.equal(await storage.getItem('sb-token'), null);
});

test('secure storage adapter fails closed when native storage methods are absent', () => {
  assert.throws(() => createSecureStorageAdapter({}, 'mrk-auth:'), /secure storage/i);
});

test('memory storage persists only for the lifetime of the library instance', async () => {
  const storage = createMemoryStorage();
  await storage.setItem('session', 'token');
  assert.equal(await storage.getItem('session'), 'token');
  await storage.removeItem('session');
  assert.equal(await storage.getItem('session'), null);
});

test('native initialization uses secure persistence, auto-refresh, PKCE and awaits SDK initialization', async () => {
  const client = makeClientStub();
  let captured;
  const nativeStorage = { get: async () => ({ value: null }), set: async () => {}, remove: async () => {} };
  const auth = createAuthLibrary({
    createClient: (...args) => { captured = args; return client; },
    nativeStorage,
    isNative: true,
  });
  await auth.initialize({ url: 'https://project.supabase.co', publicKey: 'publishable-key' });
  const options = captured[2].auth;
  assert.equal(options.persistSession, true);
  assert.equal(options.autoRefreshToken, true);
  assert.equal(options.flowType, 'pkce');
  assert.equal(options.storageKey, 'mrk-khorasani-auth-v1-project');
  assert.equal(options.detectSessionInUrl, false);
  assert.equal(client.calls[0][0], 'initialize');
  assert.equal(auth.securityMode, 'native-keystore');
});

test('native initialization refuses to create a client when Keystore bridge is unavailable', async () => {
  let called = false;
  const auth = createAuthLibrary({ createClient: () => { called = true; }, isNative: true, nativeStorage: null });
  await assert.rejects(auth.initialize({ url: 'https://project.supabase.co', publicKey: 'public' }), /keystore|secure storage/i);
  assert.equal(called, false);
});

test('web initialization uses in-memory session storage and never falls back to localStorage', async () => {
  const client = makeClientStub();
  let captured;
  const auth = createAuthLibrary({ createClient: (...args) => { captured = args; return client; }, isNative: false });
  await auth.initialize({ url: 'https://project.supabase.co', publicKey: 'public' });
  assert.equal(auth.securityMode, 'web-memory-only');
  const storage = captured[2].auth.storage;
  await storage.setItem('session', 'secret');
  assert.equal(await storage.getItem('session'), 'secret');
  assert.equal(Object.prototype.hasOwnProperty.call(globalThis, 'localStorage'), false);
});

test('password and email OTP methods normalize email and prohibit account creation', async () => {
  const client = makeClientStub();
  const auth = createAuthLibrary({ createClient: () => client, isNative: false });
  await auth.initialize({ url: 'https://project.supabase.co', publicKey: 'public' });
  await auth.signInWithPassword(' User@Example.com ', 'password-value');
  await auth.requestEmailOtp(' User@Example.com ');
  await auth.verifyEmailOtp(' User@Example.com ', '۱۲۳۴۵۶');
  assert.deepEqual(client.calls.find(x => x[0] === 'signInWithPassword')[1], { email: 'user@example.com', password: 'password-value' });
  const otp = client.calls.find(x => x[0] === 'signInWithOtp')[1];
  assert.equal(otp.options.shouldCreateUser, false);
  assert.deepEqual(client.calls.find(x => x[0] === 'verifyOtp')[1], { email: 'user@example.com', token: '123456', type: 'email' });
});

test('OTP rejects malformed codes before contacting Supabase', async () => {
  const client = makeClientStub();
  const auth = createAuthLibrary({ createClient: () => client, isNative: false });
  await auth.initialize({ url: 'https://project.supabase.co', publicKey: 'public' });
  await assert.rejects(auth.verifyEmailOtp('user@example.com', '12345'), /۶ تا ۸/);
  await assert.rejects(auth.verifyEmailOtp('user@example.com', 'code 123456'), /۶ تا ۸/);
  assert.equal(client.calls.some(x => x[0] === 'verifyOtp'), false);
});

test('verified user lookup validates the session against Supabase Auth', async () => {
  const client = makeClientStub();
  const auth = createAuthLibrary({ createClient: () => client, isNative: false });
  await auth.initialize({ url: 'https://project.supabase.co', publicKey: 'public' });
  const user = await auth.getVerifiedUser();
  assert.equal(user.id, 'u-1');
  assert.deepEqual(client.calls.filter(x => ['getSession', 'getUser'].includes(x[0])).map(x => x[0]), ['getSession', 'getUser']);
});

test('workspace profile query is restricted to the authenticated user and configured company', async () => {
  const client = makeClientStub();
  const auth = createAuthLibrary({ createClient: () => client, isNative: false });
  await auth.initialize({ url: 'https://project.supabase.co', publicKey: 'public' });
  const profile = await auth.getAuthorizedProfile({ userId: 'u-1', companyId: 'company-1' });
  assert.equal(profile.role, 'accountant');
  assert.deepEqual(client.calls.find(x => x[0] === 'profileQuery').slice(1), [
    'mrk_user_profiles',
    'user_id,company_id,user_code,display_name,email,role,booth_code,can_manage_users,is_active',
    'user_id', 'u-1', 'company_id', 'company-1',
  ]);
});

test('logout revokes only the current device session', async () => {
  const client = makeClientStub();
  const auth = createAuthLibrary({ createClient: () => client, isNative: false });
  await auth.initialize({ url: 'https://project.supabase.co', publicKey: 'public' });
  await auth.signOut();
  assert.deepEqual(client.calls.find(x => x[0] === 'signOut'), ['signOut', { scope: 'local' }]);
});


test('native secure storage clears a corrupted encrypted session and allows a clean login', async () => {
  const removed = [];
  const native = {
    async get() { const error = new Error('ciphertext invalid'); error.code = 'DECRYPTION_ERROR'; throw error; },
    async set() {},
    async remove({ key }) { removed.push(key); },
  };
  const storage = createSecureStorageAdapter(native, 'mrk-auth:');
  assert.equal(await storage.getItem('session-key'), null);
  assert.deepEqual(removed, ['mrk-auth:session-key']);
});

test('cloud auth refuses Supabase secret and service-role credentials before client creation', async () => {
  let createCount = 0;
  const auth = createAuthLibrary({ createClient: () => { createCount++; return makeClientStub(); }, isNative: false });
  await assert.rejects(auth.initialize({ url: 'https://project.supabase.co', publicKey: 'sb_secret_do_not_use' }), /publishable|service.role|secret/i);
  const jwtPayload = Buffer.from(JSON.stringify({ role: 'service_role' })).toString('base64url');
  await assert.rejects(auth.initialize({ url: 'https://project.supabase.co', publicKey: `e30.${jwtPayload}.signature` }), /publishable|service.role|secret/i);
  assert.equal(createCount, 0);
});

test('profile authorization verifies the live Supabase user matches requested identity', async () => {
  const client = makeClientStub();
  client.auth.getUser = async () => ({ data: { user: { id: 'different-user' } }, error: null });
  const auth = createAuthLibrary({ createClient: () => client, isNative: false });
  await auth.initialize({ url: 'https://project.supabase.co', publicKey: 'public' });
  await assert.rejects(auth.getAuthorizedProfile({ userId: 'u-1', companyId: 'company-1' }), /authenticated identity/i);
  assert.equal(client.calls.some(x => x[0] === 'profileQuery'), false);
});
