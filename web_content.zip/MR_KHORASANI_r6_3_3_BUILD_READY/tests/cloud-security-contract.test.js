const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.join(__dirname,'..');
const app=fs.readFileSync(path.join(root,'app.js'),'utf8');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const seed=fs.readFileSync(path.join(root,'seed.js'),'utf8');
const sw=fs.readFileSync(path.join(root,'sw.js'),'utf8');
const admin=fs.readFileSync(path.join(root,'supabase/functions/mrk-admin/index.ts'),'utf8');
const cloud=fs.readFileSync(path.join(root,'cloud-sync.js'),'utf8');
const auth=fs.readFileSync(path.join(root,'auth-library.js'),'utf8');

test('r6 requires central email/password authentication and server profile',()=>{
 assert.match(html,/loginEmail/);assert.match(html,/loginPassword/);assert.doesNotMatch(html,/loginPin|loginCode/);
 assert.match(auth,/signInWithPassword/);assert.match(auth,/mrk_user_profiles/);assert.match(auth,/auth\.getUser/);assert.match(app,/MRKAuth\.signInWithPassword/);
 assert.doesNotMatch(app,/digestPin|stall-session/);
});

test('demo identities and PINs are removed from the shipped seed',()=>{
 assert.match(seed,/initialUsers":\[\]/);
 assert.doesNotMatch(seed,/"pin"\s*:/);
 assert.doesNotMatch(app,/2486|4101|4102|4103|4104|4105|4106/);
});

test('multi-device sync persists outbox and applied ids and subscribes to realtime events',()=>{
 assert.match(app,/syncOutbox/);assert.match(app,/syncApplied/);assert.match(app,/mrk_sync_events/);
 assert.match(app,/postgres_changes/);assert.match(app,/flushCloudOutbox/);assert.match(app,/pullCloudEvents/);
 assert.match(app,/cloud-last-seq/);
});

test('admin function validates user JWT and manager profile before creating or disabling users',()=>{
 assert.match(admin,/auth\.getUser\(token\)/);assert.match(admin,/can_manage_users/);
 assert.match(admin,/auth\.admin\.createUser/);assert.match(admin,/is_active\s*:\s*false/);
 assert.doesNotMatch(admin,/service_role.*console\.log|console\.log.*service_role/i);
});

test('service worker caches the pinned Supabase SDK for PWA offline startup',()=>{
 assert.match(sw,/supabase-js@2\.119\.2/);assert.match(sw,/SDK_URLS\.map\(url=>cache\.add\(url\)\)/);
 assert.match(sw,/mr-khorasani-shell-v16-r633-secure-auth-keystore/);
});

test('native authentication stores sessions in Keystore and web auth is memory-only, never localStorage',()=>{
 assert.match(auth,/createSecureStorageAdapter/);assert.match(auth,/native-keystore/);assert.match(auth,/web-memory-only/);assert.match(auth,/skipAutoInitialize:\s*true/);
 assert.doesNotMatch(auth,/localStorage\s*\./);
});

test('public client contains only Supabase publishable key and never service role credential',()=>{
 assert.match(app,/SUPABASE_PUBLISHABLE_KEY/);assert.doesNotMatch(app,/SUPABASE_SERVICE_ROLE_KEY|service_role/);
});

test('booth-to-booth transfer sends both stock legs atomically and a destination-only view event',()=>{
 assert.match(app,/queueCloudEvent\('booth_transfer_bundle',null,transferId,\{movements\}\)/);
 assert.match(app,/queueCloudEvent\('warehouse_transfer_in',input\.toBoothCode,transferId,\{movements:inbound\}\)/);
});

test('outbox does not submit another logged-in user’s offline events',()=>{
 assert.match(app,/item\.event\?\.actor_id!==cloudProfile\.user_id/);
 assert.match(app,/صف سایر کاربران این دستگاه محفوظ است/);
});

test('booth devices receive their scoped stock count and product catalogue refresh',()=>{
 assert.match(app,/queueCloudEvent\('inventory_bundle',saved\.movement\.boothCode/);
 assert.match(app,/queueCloudEvent\('product_catalog_refresh',boothCode/);
 assert.match(cloud,/product_catalog_refresh/);
 assert.match(cloud,/inventory_bundle/);
});


test('startup does not replace the trusted packaged catalogue with stale local product rows before manager bootstrap',()=>{
 assert.doesNotMatch(app,/await seedDatabase\(\);await loadProductCatalog\(\);/);
 assert.match(app,/await seedDatabase\(\);await ensureCentralWarehouseRows\(\)/);
});

test('deployed SQL contracts include booth catalogue feed and server-side sale serialization/validation',()=>{
 const migration=fs.readFileSync(path.join(root,'database/migrations/20261127_mrk_r6_catalog_feed_and_accountant_sales.sql'),'utf8');
 const serial=fs.readFileSync(path.join(root,'database/migrations/20261127_mrk_r6_server_sale_serialization.sql'),'utf8');
 assert.match(migration,/product_catalog_refresh/);
 assert.match(migration,/inventory_bundle/);
 assert.match(migration,/mrk_validate_accountant_sale/);
 assert.match(serial,/mrk_lock_booth_sale/);
 assert.match(serial,/MRK_SALE_STOCK_UNKNOWN_OR_INSUFFICIENT/);
 assert.match(serial,/MRK_SALE_SETTLEMENT_INVALID/);
 assert.match(serial,/v_product\.price<=0/);
 assert.match(serial,/Asia\/Tehran/);
});


test('database migrations revoke browser CRUD defaults and keep stock balances server-only',()=>{
 const grants=fs.readFileSync(path.join(root,'database/migrations/20261127_mrk_r6_explicit_client_privilege_hardening.sql'),'utf8');
 assert.match(grants,/REVOKE ALL ON TABLE[\s\S]*mrk_stock_balances[\s\S]*FROM anon, authenticated, public/);
 assert.match(grants,/GRANT INSERT ON TABLE public\.mrk_sync_events TO authenticated/);
 assert.match(grants,/GRANT SELECT ON TABLE[\s\S]*mrk_sync_events/);
});

test('secondary server guards reject post-close sales and unpaired warehouse transfer feed events',()=>{
 const guard=fs.readFileSync(path.join(root,'database/migrations/20261127_mrk_r6_secondary_event_scope_guards.sql'),'utf8');
 assert.match(guard,/MRK_SALE_AFTER_BOOTH_CLOSE/);
 assert.match(guard,/MRK_TRANSFER_IN_WITHOUT_COMMITTED_TRANSFER/);
 assert.match(guard,/warehouse_transfer_bundle/);
 assert.match(guard,/booth_transfer_bundle/);
});

test('product description field exists for the product upsert trigger',()=>{
 const migration=fs.readFileSync(path.join(root,'database/migrations/20261127_mrk_r6_product_notes_field.sql'),'utf8');
 assert.match(migration,/ADD COLUMN IF NOT EXISTS notes text/);
});


test('Realtime events are serialized and cannot advance the durable sequence cursor out of order',()=>{
 assert.match(app,/let cloudApplyQueue=Promise\.resolve\(\)/);
 assert.match(app,/cloudApplyQueue\.then\(\(\)=>applyCloudEventSerial\(event,options\)/);
 assert.match(app,/async function applyCloudEventSerial\(event,\{advanceCursor=true\}=\{\}\)/);
 assert.match(app,/applyCloudEvent\(payload\.new,\{advanceCursor:false\}\)/);
 assert.match(app,/if\(advanceCursor&&Number\(event\.seq\)>0\)/);
});

test('Incremental pull remains the only ordered path that advances the sequence cursor',()=>{
 assert.match(app,/for\(const row of data\)\{await applyCloudEvent\(row\);cursor=Math\.max\(cursor,Number\(row\.seq\)\|\|0\)\}/);
 assert.match(app,/async function pullCloudEvents\(\)[\s\S]*?for\(const row of data\)\{await applyCloudEvent\(row\);cursor=Math\.max\(cursor,Number\(row\.seq\)\|\|0\)\}/);
});


test('manager Edge Function email validator accepts ordinary valid addresses and rejects embedded whitespace',()=>{
 const match=admin.match(/(\/\^.*?\/)\.test\(email\)/);
 assert.ok(match,'email regular expression should be present in the deployed source');
 const validator=new RegExp(match[1].slice(1,-1));
 assert.equal(validator.test('sales.user@example.com'),true);
 assert.equal(validator.test('bad address@example.com'),false);
});


test('account switching clears prior local business cache but preserves queued events for their original user',()=>{
 assert.match(app,/CLOUD_SYNC_SEQ_OVERLAP=256/);
 assert.match(app,/for\(const store of \['products','stock','sales','reconciliations','movements','purchases','dayClosures','syncApplied'\]\)await clearStore\(store\)/);
 assert.doesNotMatch(app,/for\(const store of \[[^\]]*syncOutbox/);
 assert.match(app,/item\.event\?\.actor_id!==cloudProfile\.user_id/);
});

test('sequence pull re-reads an overlap window to recover late-committing lower sequence ids',()=>{
 assert.match(app,/queryCursor=Math\.max\(0,cursor-CLOUD_SYNC_SEQ_OVERLAP\)/);
 assert.match(app,/\.gt\('seq',queryCursor\)/);
 assert.match(app,/queryCursor=cursor/);
});
