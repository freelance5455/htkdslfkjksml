import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { execFileSync } from 'node:child_process';
const root = process.cwd();
const pkg = JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
const cap = JSON.parse(fs.readFileSync(path.join(root,'capacitor.config.json'),'utf8'));
const isAndroid = Boolean(pkg.dependencies['@capacitor/android']);
const isIOS = Boolean(pkg.dependencies['@capacitor/ios']);
test('Capacitor app identity and webDir are stable',()=>{
 assert.equal(cap.appId,'com.mrkhorasani.finance');
 assert.equal(cap.webDir,'www');
});
test('native dependencies are pinned to a single Capacitor 8 patch release',()=>{
 const versions=['@capacitor/core','@capacitor/cli', ...(isAndroid?['@capacitor/android']:[]), ...(isIOS?['@capacitor/ios']:[])];
 for (const name of versions) {
  const version=pkg.dependencies[name]||pkg.devDependencies[name];
  assert.equal(version,'8.6.3',`${name} must be pinned`);
 }
});
test('native asset preparation vendors the pinned Supabase SDK and skips native service workers',()=>{
 const script=fs.readFileSync(path.join(root,'scripts/prepare-native-assets.mjs'),'utf8');
 assert.match(script,/dist.*umd.*supabase\.js/);
 assert.match(script,/Capacitor\?\.isNativePlatform/);
});
if (isAndroid) test('Android package exposes a debug APK build command and CI workflow',()=>{
 assert.ok(pkg.scripts['android:debug']);
 assert.ok(fs.existsSync(path.join(root,'.github/workflows/android-debug-apk.yml')));
});
if (isIOS) test('iOS package exposes Xcode and simulator build commands',()=>{
 assert.ok(pkg.scripts['ios:setup']);
 assert.ok(pkg.scripts['ios:simulator']);
 assert.ok(fs.existsSync(path.join(root,'.github/workflows/ios-simulator.yml')));
});
test('client bundle does not contain service-role credential names',()=>{
 for(const file of ['app.js','index.html','cloud-sync.js']){
  const content=fs.readFileSync(path.join(root,file),'utf8');
  assert.doesNotMatch(content,/SUPABASE_SERVICE_ROLE_KEY|sb_secret_/);
 }
});

test('native asset preparation bundles Supabase locally and copies its loader',()=>{
 const script=fs.readFileSync(path.join(root,'scripts/prepare-native-assets.mjs'),'utf8');
 assert.match(script,/supabase-loader\.js/);
 assert.match(script,/vendor\/supabase\.js/);
 assert.match(script,/loaderTag/);
 assert.doesNotMatch(script,/const cdn = '<script src=\"https:\/\/cdn\.jsdelivr\.net/);
});

test('Capacitor native setup copies the auth loader and preloads the local SDK before startup', async()=>{
 const temp=fs.mkdtempSync(path.join(os.tmpdir(),'mrk-native-test-'));
 try {
  fs.cpSync(root,temp,{recursive:true,filter:src=>!src.includes(`${path.sep}node_modules${path.sep}`)&&!src.includes(`${path.sep}www${path.sep}`)});
  const sdk=path.join(temp,'node_modules','@supabase','supabase-js','dist','umd','supabase.js');
  fs.mkdirSync(path.dirname(sdk),{recursive:true});
  fs.writeFileSync(sdk,'/* test sdk placeholder */');
  const esbuild=path.join(temp,'node_modules','esbuild');
  fs.mkdirSync(esbuild,{recursive:true});
  fs.writeFileSync(path.join(esbuild,'package.json'),JSON.stringify({name:'esbuild',type:'module',exports:'./index.js'}));
  fs.writeFileSync(path.join(esbuild,'index.js'),
   "import fs from 'node:fs'; import path from 'node:path'; export async function build(options) { const root=options.absWorkingDir; fs.copyFileSync(path.join(root,'vendor','mrk-secure-storage.js'),options.outfile); }");
  execFileSync(process.execPath,[path.join(temp,'scripts','prepare-native-assets.mjs')],{cwd:temp,stdio:'pipe'});
  const nativeHtml=fs.readFileSync(path.join(temp,'www','index.html'),'utf8');
  const sdkTag=nativeHtml.indexOf('<script src="./vendor/supabase.js"></script>');
  const loaderTag=nativeHtml.indexOf('<script src="supabase-loader.js"></script>');
  assert.ok(sdkTag>=0 && loaderTag>sdkTag,'local SDK must load before the fallback loader');
  assert.ok(fs.existsSync(path.join(temp,'www','supabase-loader.js')),'auth loader must be copied into www');
  assert.ok(fs.existsSync(path.join(temp,'www','auth-library.js')),'auth library must be copied into www');
  assert.ok(fs.existsSync(path.join(temp,'www','vendor','mrk-secure-storage.js')),'secure storage bridge must be copied into www');
  assert.equal(fs.readFileSync(path.join(temp,'www','vendor','supabase.js'),'utf8'),'/* test sdk placeholder */');
  const nativeApp=fs.readFileSync(path.join(temp,'www','app.js'),'utf8');
  assert.match(nativeApp,/!window\.Capacitor\?\.isNativePlatform/,'native builds should not register the PWA service worker');
 } finally { fs.rmSync(temp,{recursive:true,force:true}); }
});

test('Supabase UMD artifact filename matches the package output (supabase.js, not supabase.min.js)',()=>{
 const loader=fs.readFileSync(path.join(root,'supabase-loader.js'),'utf8');
 const prep=fs.readFileSync(path.join(root,'scripts/prepare-native-assets.mjs'),'utf8');
 const sw=fs.readFileSync(path.join(root,'sw.js'),'utf8');
 assert.match(loader,/dist\/umd\/supabase\.js/);
 assert.match(prep,/dist', 'umd', 'supabase\.js/);
 assert.match(prep,/vendor', 'supabase\.js/);
 assert.match(sw,/dist\/umd\/supabase\.js/);
 for(const source of [loader,prep,sw]) assert.doesNotMatch(source,/supabase\.min\.js/);
});

test('secure cloud auth dependencies are pinned to Capacitor 8 compatible releases',()=>{
 assert.equal(pkg.dependencies['@capnative/capacitor-secure-storage'],'8.0.1');
 assert.equal(pkg.devDependencies.esbuild,'0.28.2');
 assert.ok(pkg.scripts['auth:build']);
});
