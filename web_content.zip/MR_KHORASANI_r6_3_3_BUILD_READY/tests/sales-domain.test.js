const test = require('node:test');
const assert = require('node:assert/strict');
const { prepareSale, getCurrentStock } = require('../sales-domain.js');

const product = {
  key: 'P-1', code: 1, name: 'آب', price: 1000, unit: 'عدد',
  assignedStalls: ['G01'], saleBlocked: false, priceConflict: false
};
const pos = { code: 'POS-1', boothCode: 'G01' };
const base = {
  boothCode: 'G01', boothName: 'غرفه یک', posCode: 'POS-1',
  day: '2026-11-25', trackingCode: 'TRACK-1', receiptAmount: 2000,
  cart: [{ productKey: 'P-1', qty: 2 }],
  products: [product], posTerminals: [pos],
  stockRecords: [{ id: 'G01::P-1', boothCode: 'G01', productKey: 'P-1', openingQty: 5, movements: [] }],
  existingSales: [], userCode: 'USER-1', createdAt: '2026-11-25T10:00:00.000Z', id: 'sale-1'
};

function prepare(overrides = {}) { return prepareSale({ ...base, ...overrides }); }

test('allows an in-stock sale and produces matching stock movement', () => {
  const result = prepare();
  assert.equal(result.ok, true);
  assert.equal(result.sale.status, 'MATCH');
  assert.equal(result.sale.expectedAmount, 2000);
  assert.equal(result.stockUpdates[0].movements[0].delta, -2);
  assert.equal(getCurrentStock(result.stockUpdates[0]), 3);
});

test('rejects a sale when opening stock is unknown instead of treating it as zero', () => {
  const result = prepare({ stockRecords: [{ ...base.stockRecords[0], openingQty: null }] });
  assert.equal(result.ok, false);
  assert.equal(result.code, 'UNKNOWN_STOCK');
});

test('rejects a sale when no stock record exists for the booth and product', () => {
  const result = prepare({ stockRecords: [] });
  assert.equal(result.ok, false);
  assert.equal(result.code, 'STOCK_RECORD_MISSING');
});

test('rejects quantities greater than current stock after earlier movements', () => {
  const result = prepare({
    cart: [{ productKey: 'P-1', qty: 4 }],
    stockRecords: [{ ...base.stockRecords[0], movements: [{ id: 'old', delta: -2 }] }]
  });
  assert.equal(result.ok, false);
  assert.equal(result.code, 'INSUFFICIENT_STOCK');
});

test('rejects a product not assigned to the selected booth', () => {
  const result = prepare({ boothCode: 'G02', posTerminals: [{ code: 'POS-1', boothCode: 'G02' }] });
  assert.equal(result.ok, false);
  assert.equal(result.code, 'PRODUCT_NOT_ASSIGNED');
});

test('rejects a POS terminal assigned to another booth', () => {
  const result = prepare({ posTerminals: [{ code: 'POS-1', boothCode: 'G02' }] });
  assert.equal(result.ok, false);
  assert.equal(result.code, 'POS_NOT_ASSIGNED');
});

test('rejects duplicate terminal tracking reference for the same day', () => {
  const result = prepare({ existingSales: [{ posCode: 'POS-1', day: '2026-11-25', trackingCode: 'TRACK-1' }] });
  assert.equal(result.ok, false);
  assert.equal(result.code, 'DUPLICATE_TRACKING');
});

test('allows receipt mismatches but records them explicitly for reconciliation', () => {
  const result = prepare({ receiptAmount: 1900 });
  assert.equal(result.ok, true);
  assert.equal(result.sale.status, 'MISMATCH');
  assert.equal(result.sale.difference, -100);
});

test('rejects malformed or negative receipt values', () => {
  for (const receiptAmount of [-1, 'abc', NaN]) {
    const result = prepare({ receiptAmount });
    assert.equal(result.ok, false);
    assert.equal(result.code, 'INVALID_RECEIPT');
  }
});

test('merges duplicate cart rows before checking stock and writing a line', () => {
  const result = prepare({
    cart: [{ productKey: 'P-1', qty: 2 }, { productKey: 'P-1', qty: 2 }],
    stockRecords: [{ ...base.stockRecords[0], openingQty: 3 }]
  });
  assert.equal(result.ok, false);
  assert.equal(result.code, 'INSUFFICIENT_STOCK');
});

test('rejects fractional quantities for count-based products', () => {
  const result = prepare({ cart: [{ productKey: 'P-1', qty: 1.5 }] });
  assert.equal(result.ok, false);
  assert.equal(result.code, 'INVALID_QUANTITY');
});

test('rejects kilogram quantities with more than two decimal places', () => {
  const kgProduct = { ...product, unit: 'کیلوگرم' };
  const result = prepare({ products: [kgProduct], cart: [{ productKey: 'P-1', qty: 1.234 }] });
  assert.equal(result.ok, false);
  assert.equal(result.code, 'INVALID_QUANTITY');
});

test('rounds kilogram line totals to whole rial before receipt comparison', () => {
  const kgProduct = { ...product, unit: 'کیلوگرم', price: 1001 };
  const result = prepare({ products: [kgProduct], cart: [{ productKey: 'P-1', qty: 1.25 }], receiptAmount: 1251 });
  assert.equal(result.ok, true);
  assert.equal(result.sale.expectedAmount, 1251);
  assert.equal(result.sale.lines[0].lineTotal, 1251);
});

test('rejects a sale when the calculated stock balance is negative from prior history', () => {
  const result = prepare({
    stockRecords: [{ ...base.stockRecords[0], movements: [{ id: 'bad', delta: -8 }] }]
  });
  assert.equal(result.ok, false);
  assert.equal(result.code, 'INVALID_STOCK');
});

test('rejects a product whose price is blocked even if stock is available', () => {
  const result = prepare({ products: [{ ...product, saleBlocked: true }] });
  assert.equal(result.ok, false);
  assert.equal(result.code, 'PRODUCT_BLOCKED');
});

test('read-only inventory audit detects a previous sale without stock movement', () => {
  const audit = require('../sales-domain.js').auditSalesInventory(
    [{ id: 'legacy-sale', boothCode: 'G01', lines: [{ productKey: 'P-1', qty: 2, name: 'آب' }] }],
    [{ ...base.stockRecords[0], movements: [] }]
  );
  assert.equal(audit.salesCount, 1);
  assert.equal(audit.lineCount, 1);
  assert.equal(audit.okLines, 0);
  assert.equal(audit.missingMovements, 1);
  assert.equal(audit.findings[0].code, 'MISSING_STOCK_MOVEMENT');
});

test('read-only inventory audit confirms sale movement and does not mutate source stock', () => {
  const stock = { ...base.stockRecords[0], movements: [{ id: 'legacy-sale:P-1', saleId: 'legacy-sale', delta: -2 }] };
  const before = JSON.stringify(stock);
  const audit = require('../sales-domain.js').auditSalesInventory(
    [{ id: 'legacy-sale', boothCode: 'G01', lines: [{ productKey: 'P-1', qty: 2, name: 'آب' }] }],
    [stock]
  );
  assert.equal(audit.issueCount, 0);
  assert.equal(audit.okLines, 1);
  assert.equal(JSON.stringify(stock), before);
});

const { prepareInventoryMovement, prepareSaleReturn, auditInventoryLedger } = require('../sales-domain.js');

test('allows an initial stock count to establish a previously unknown balance', () => {
  const result = prepareInventoryMovement({
    id: 'count-1', boothCode: 'G01', productKey: 'P-1',
    stock: { ...base.stockRecords[0], openingQty: null, movements: [] },
    product, type: 'COUNT', qty: 8, at: '2026-11-25T11:00:00.000Z',
    reason: 'شمارش اولیه', reference: 'COUNT-001', userCode: 'USER-1'
  });
  assert.equal(result.ok, true);
  assert.equal(getCurrentStock(result.stock), 8);
  assert.equal(result.movement.type, 'COUNT');
});

test('records inbound stock and updates the current balance', () => {
  const result = prepareInventoryMovement({
    id: 'in-1', boothCode: 'G01', productKey: 'P-1',
    stock: base.stockRecords[0], product, type: 'IN', qty: 3,
    at: '2026-11-25T11:00:00.000Z', reason: 'خرید', reference: 'BUY-1', userCode: 'USER-1'
  });
  assert.equal(result.ok, true);
  assert.equal(getCurrentStock(result.stock), 8);
  assert.equal(result.movement.delta, 3);
});

test('rejects outbound movement that would make stock negative', () => {
  const result = prepareInventoryMovement({
    id: 'out-1', boothCode: 'G01', productKey: 'P-1',
    stock: base.stockRecords[0], product, type: 'OUT', qty: 6,
    at: '2026-11-25T11:00:00.000Z', reason: 'مصرف', reference: 'ISSUE-1', userCode: 'USER-1'
  });
  assert.equal(result.ok, false);
  assert.equal(result.code, 'INSUFFICIENT_STOCK');
});

test('rejects non-count stock movement while opening balance is unknown', () => {
  const result = prepareInventoryMovement({
    id: 'in-unknown', boothCode: 'G01', productKey: 'P-1',
    stock: { ...base.stockRecords[0], openingQty: null, movements: [] },
    product, type: 'IN', qty: 3, at: '2026-11-25T11:00:00.000Z',
    reason: 'خرید', reference: 'BUY-1', userCode: 'USER-1'
  });
  assert.equal(result.ok, false);
  assert.equal(result.code, 'UNKNOWN_STOCK');
});

test('a stock count resets the balance at its effective time', () => {
  const stock = { ...base.stockRecords[0], movements: [
    { id: 'old-sale', type: 'SALE', delta: -2, at: '2026-11-24T10:00:00.000Z' },
    { id: 'count', type: 'COUNT', countedQty: 6, delta: 0, at: '2026-11-25T10:00:00.000Z' },
    { id: 'new-sale', type: 'SALE', delta: -1, at: '2026-11-25T11:00:00.000Z' }
  ] };
  assert.equal(getCurrentStock(stock), 5);
});

test('allows partial sale return but caps cumulative returned quantity at sold quantity', () => {
  const sale = { id: 'sale-1', boothCode: 'G01', lines: [{ productKey: 'P-1', qty: 4, name: 'آب', unit: 'عدد', unitPrice: 1000 }] };
  const stock = { ...base.stockRecords[0], movements: [{ id: 'sale-move', saleId: 'sale-1', type: 'SALE', delta: -4, at: '2026-11-25T10:00:00.000Z' }] };
  const first = prepareSaleReturn({
    id: 'return-1', sale, stockRecords: [stock], priorReturns: [],
    items: [{ productKey: 'P-1', qty: 2 }], at: '2026-11-25T12:00:00.000Z', reason: 'مرجوع مشتری', userCode: 'USER-1'
  });
  assert.equal(first.ok, true);
  assert.equal(getCurrentStock(first.stockUpdates[0]), 3);
  const second = prepareSaleReturn({
    id: 'return-2', sale, stockRecords: [first.stockUpdates[0]],
    priorReturns: [{ sourceSaleId: 'sale-1', type: 'SALE_RETURN', productKey: 'P-1', qty: 2 }],
    items: [{ productKey: 'P-1', qty: 3 }], at: '2026-11-25T13:00:00.000Z', reason: 'مرجوع مشتری', userCode: 'USER-1'
  });
  assert.equal(second.ok, false);
  assert.equal(second.code, 'RETURN_EXCEEDS_SOLD');
});

test('inventory ledger audit detects missing mirror records', () => {
  const stock = { ...base.stockRecords[0], movements: [{ id: 'm-1', delta: 2, type: 'IN', at: '2026-11-25T11:00:00.000Z' }] };
  const audit = auditInventoryLedger([stock], []);
  assert.equal(audit.issueCount, 1);
  assert.equal(audit.findings[0].code, 'MISSING_LEDGER_RECORD');
});

test('a verified count can establish a balance after unquantifiable legacy movements', () => {
  const stock = { ...base.stockRecords[0], openingQty: null, movements: [
    { id: 'legacy-unknown', delta: -2, at: '2026-11-24T10:00:00.000Z' },
    { id: 'count', type: 'COUNT', countedQty: 7, delta: 0, at: '2026-11-25T10:00:00.000Z' },
    { id: 'new-in', type: 'IN', delta: 3, at: '2026-11-25T11:00:00.000Z' }
  ] };
  assert.equal(getCurrentStock(stock), 10);
});

test('current stock calculation follows effective dates rather than insertion order', () => {
  const stock = { ...base.stockRecords[0], movements: [
    { id: 'later-out', type: 'OUT', delta: -2, at: '2026-11-25T12:00:00.000Z' },
    { id: 'earlier-in', type: 'IN', delta: 3, at: '2026-11-25T11:00:00.000Z' }
  ] };
  assert.equal(getCurrentStock(stock), 6);
});

test('sale return rejects fractional quantity for count-based products', () => {
  const sale = { id: 'sale-1', boothCode: 'G01', lines: [{ productKey: 'P-1', qty: 4, name: 'آب', unit: 'عدد', unitPrice: 1000 }] };
  const result = prepareSaleReturn({ id: 'return-frac', sale, stockRecords: [base.stockRecords[0]], priorReturns: [], items: [{ productKey: 'P-1', qty: 1.5 }], at: '2026-11-25T12:00:00.000Z', reason: 'مرجوع', userCode: 'USER-1' });
  assert.equal(result.ok, false);
  assert.equal(result.code, 'INVALID_QUANTITY');
});

test('inventory ledger audit accepts matching stock and ledger movement records', () => {
  const movement = { id: 'ledger-1', stockId: 'G01::P-1', boothCode: 'G01', productKey: 'P-1', type: 'IN', delta: 2, qty: 2, at: '2026-11-25T11:00:00.000Z' };
  const stock = { ...base.stockRecords[0], movements: [movement] };
  const audit = auditInventoryLedger([stock], [movement]);
  assert.equal(audit.issueCount, 0);
  assert.equal(audit.movementCount, 1);
});

test('sale movements carry stable stock references for independent ledger persistence', () => {
  const result = prepare();
  assert.equal(result.ok, true);
  assert.equal(result.stockUpdates[0].movements[0].type, 'SALE');
  assert.equal(result.stockUpdates[0].movements[0].stockId, 'G01::P-1');
});

const { prepareInventoryTransfer, buildProductCardex } = require('../sales-domain.js');
const transferProduct = { ...product, assignedStalls: ['G01', 'G02'] };
const destinationStock = { id: 'G02::P-1', boothCode: 'G02', productKey: 'P-1', openingQty: 10, movements: [] };

function transfer(overrides = {}) {
  return prepareInventoryTransfer({
    id: 'transfer-1', transferId: 'transfer-1', product: transferProduct,
    fromBoothCode: 'G01', toBoothCode: 'G02',
    sourceStock: base.stockRecords[0], destinationStock,
    qty: 3, at: '2026-11-25T14:00:00.000Z',
    reference: 'TR-001', reason: 'توزیع موجودی', userCode: 'FIN', ...overrides
  });
}

test('prepares a balanced booth transfer with paired outbound and inbound movements', () => {
  const result = transfer();
  assert.equal(result.ok, true);
  assert.equal(getCurrentStock(result.sourceStock), 2);
  assert.equal(getCurrentStock(result.destinationStock), 13);
  assert.equal(result.movements.length, 2);
  assert.deepEqual(result.movements.map(x => x.type), ['TRANSFER_OUT', 'TRANSFER_IN']);
  assert.equal(result.movements[0].delta + result.movements[1].delta, 0);
  assert.equal(result.movements[0].transferId, result.movements[1].transferId);
});

test('rejects transfer to the same booth', () => {
  const result = transfer({ toBoothCode: 'G01', destinationStock: base.stockRecords[0] });
  assert.equal(result.ok, false);
  assert.equal(result.code, 'INVALID_TRANSFER');
});

test('rejects transfer when product is not assigned to destination booth', () => {
  const result = transfer({ product: { ...transferProduct, assignedStalls: ['G01'] } });
  assert.equal(result.ok, false);
  assert.equal(result.code, 'PRODUCT_NOT_ASSIGNED');
});

test('rejects transfer when destination balance is unknown', () => {
  const result = transfer({ destinationStock: { ...destinationStock, openingQty: null } });
  assert.equal(result.ok, false);
  assert.equal(result.code, 'UNKNOWN_STOCK');
});

test('rejects transfer quantity above source available stock', () => {
  const result = transfer({ qty: 6 });
  assert.equal(result.ok, false);
  assert.equal(result.code, 'INSUFFICIENT_STOCK');
});

test('rejects transfer quantity precision invalid for count-based items', () => {
  const result = transfer({ qty: 1.5 });
  assert.equal(result.ok, false);
  assert.equal(result.code, 'INVALID_QUANTITY');
});

test('product cardex calculates opening, running balance and date-filtered rows', () => {
  const stock = { ...base.stockRecords[0], movements: [
    { id: 'in-1', stockId: 'G01::P-1', type: 'IN', delta: 4, qty: 4, at: '2026-11-24T10:00:00.000Z' },
    { id: 'out-1', stockId: 'G01::P-1', type: 'OUT', delta: -2, qty: 2, at: '2026-11-25T10:00:00.000Z' },
    { id: 'return-1', stockId: 'G01::P-1', type: 'SALE_RETURN', delta: 1, qty: 1, at: '2026-11-26T10:00:00.000Z' }
  ] };
  const result = buildProductCardex({ stock, ledgerRecords: [], fromAt: '2026-11-25T00:00:00.000Z', toAt: '2026-11-25T23:59:59.999Z' });
  assert.equal(result.openingBalance, 9);
  assert.equal(result.rows.length, 1);
  assert.equal(result.rows[0].outbound, 2);
  assert.equal(result.rows[0].balance, 7);
  assert.equal(result.closingBalance, 7);
});

test('product cardex deduplicates movements mirrored in the independent ledger', () => {
  const movement = { id: 'in-1', stockId: 'G01::P-1', type: 'IN', delta: 2, qty: 2, at: '2026-11-25T10:00:00.000Z' };
  const result = buildProductCardex({ stock: { ...base.stockRecords[0], movements: [movement] }, ledgerRecords: [movement] });
  assert.equal(result.rows.length, 1);
  assert.equal(result.closingBalance, 7);
});

test('product cardex remains unknown until an effective stock count establishes balance', () => {
  const stock = { ...base.stockRecords[0], openingQty: null, movements: [
    { id: 'unknown-in', stockId: 'G01::P-1', type: 'IN', delta: 2, qty: 2, at: '2026-11-24T10:00:00.000Z' },
    { id: 'count-1', stockId: 'G01::P-1', type: 'COUNT', delta: 0, qty: 6, countedQty: 6, at: '2026-11-25T10:00:00.000Z' },
    { id: 'out-1', stockId: 'G01::P-1', type: 'OUT', delta: -1, qty: 1, at: '2026-11-25T11:00:00.000Z' }
  ] };
  const result = buildProductCardex({ stock, ledgerRecords: [] });
  assert.equal(result.openingBalance, null);
  assert.equal(result.closingBalance, 5);
  assert.equal(result.rows.at(-1).balance, 5);
});


test('inventory ledger audit detects a transfer missing its paired movement', () => {
  const onlyOut = { id: 'tr-9:OUT', transferId: 'tr-9', transferSide: 'OUT', stockId: 'G01::P-1', boothCode: 'G01', productKey: 'P-1', type: 'TRANSFER_OUT', delta: -2, qty: 2 };
  const audit = auditInventoryLedger([], [onlyOut]);
  assert.ok(audit.findings.some(f => f.code === 'TRANSFER_PAIR_INCOMPLETE' && f.transferId === 'tr-9'));
});

test('inventory ledger audit accepts a balanced transfer pair', () => {
  const out = { id: 'tr-10:OUT', transferId: 'tr-10', transferSide: 'OUT', stockId: 'G01::P-1', boothCode: 'G01', productKey: 'P-1', type: 'TRANSFER_OUT', delta: -2, qty: 2 };
  const inside = { id: 'tr-10:IN', transferId: 'tr-10', transferSide: 'IN', stockId: 'G02::P-1', boothCode: 'G02', productKey: 'P-1', type: 'TRANSFER_IN', delta: 2, qty: 2 };
  const audit = auditInventoryLedger([], [out, inside]);
  assert.equal(audit.findings.filter(f => String(f.code).startsWith('TRANSFER_PAIR')).length, 0);
});

test('supports a split settlement across assigned POS and cash sources', () => {
  const result = prepare({
    payments: [
      { type: 'POS', amount: 1200, posCode: 'POS-1', trackingCode: 'POS-REF-1' },
      { type: 'CASH', amount: 800 }
    ],
    boothHolderName: 'آرش'
  });
  assert.equal(result.ok, true);
  assert.equal(result.sale.expectedAmount, 2000);
  assert.equal(result.sale.totalReceived, 2000);
  assert.equal(result.sale.outstandingAmount, 0);
  assert.equal(result.sale.settlementStatus, 'PAID');
  assert.equal(result.sale.payments.length, 2);
});

test('posts partial settlement balance automatically to the booth holder account', () => {
  const result = prepare({
    payments: [{ type: 'CASH', amount: 500 }],
    boothHolderName: 'آرش'
  });
  assert.equal(result.ok, true);
  assert.equal(result.sale.totalReceived, 500);
  assert.equal(result.sale.outstandingAmount, 1500);
  assert.equal(result.sale.settlementStatus, 'PARTIAL');
  assert.equal(result.sale.receivableAccountName, 'آرش');
});

test('allows an entirely unpaid sale and assigns the full amount to the booth holder', () => {
  const result = prepare({ payments: [], boothHolderName: 'آرش' });
  assert.equal(result.ok, true);
  assert.equal(result.sale.totalReceived, 0);
  assert.equal(result.sale.outstandingAmount, 2000);
  assert.equal(result.sale.settlementStatus, 'UNPAID');
  assert.equal(result.sale.receivableAccountName, 'آرش');
});

test('rejects split settlement allocations above the sale total', () => {
  const result = prepare({ payments: [{ type: 'CASH', amount: 2001 }], boothHolderName: 'آرش' });
  assert.equal(result.ok, false);
  assert.equal(result.code, 'PAYMENT_EXCEEDS_TOTAL');
});

test('requires each POS settlement allocation to use a booth-assigned terminal and unique reference', () => {
  const invalidTerminal = prepare({ payments: [{ type: 'POS', amount: 1000, posCode: 'OTHER', trackingCode: 'P-1' }] });
  assert.equal(invalidTerminal.ok, false);
  assert.equal(invalidTerminal.code, 'POS_NOT_ASSIGNED');
  const duplicate = prepare({ payments: [
    { type: 'POS', amount: 500, posCode: 'POS-1', trackingCode: 'SAME' },
    { type: 'POS', amount: 500, posCode: 'POS-1', trackingCode: 'SAME' }
  ] });
  assert.equal(duplicate.ok, false);
  assert.equal(duplicate.code, 'DUPLICATE_TRACKING');
});

test('supports personnel as a distinct receipt source', () => {
  const result = prepare({ payments: [{ type: 'PERSONNEL', amount: 2000, personnelName: 'پرسنل شیفت' }] });
  assert.equal(result.ok, true);
  assert.equal(result.sale.payments[0].type, 'PERSONNEL');
  assert.equal(result.sale.receiptAmount, 2000);
});

test('detects a POS tracking reference already stored in another split-settlement sale', () => {
  const result = prepare({
    payments: [{ type: 'POS', amount: 1000, posCode: 'POS-1', trackingCode: 'EXISTING-REF' }],
    existingSales: [{ day: '2026-11-25', payments: [{ type: 'POS', posCode: 'POS-1', trackingCode: 'EXISTING-REF', amount: 300 }] }]
  });
  assert.equal(result.ok, false);
  assert.equal(result.code, 'DUPLICATE_TRACKING');
});

test('rejects unknown payment sources and non-positive individual receipt amounts', () => {
  for (const payments of [
    [{ type: 'CREDIT', amount: 100 }],
    [{ type: 'CASH', amount: 0 }],
    [{ type: 'CASH', amount: -1 }],
    [{ type: 'CASH', amount: 1.5 }]
  ]) {
    const result = prepare({ payments });
    assert.equal(result.ok, false);
  }
});

test('retains the booth holder name on the sale even when fully settled', () => {
  const result = prepare({ payments: [{ type: 'CASH', amount: 2000 }], boothHolderName: 'نام صاحب غرفه' });
  assert.equal(result.ok, true);
  assert.equal(result.sale.boothHolderName, 'نام صاحب غرفه');
  assert.equal(result.sale.receivableAccountName, null);
});

const { prepareCentralPurchase, prepareCentralTransfer } = require('../sales-domain.js');

test('central purchase receipt increases central warehouse stock and records purchase details', () => {
  const result = prepareCentralPurchase({
    id: 'buy-1', invoiceNo: 'PUR-001', supplier: 'تأمین‌کننده الف', day: '2026-11-26',
    items: [{ productKey: 'P-1', qty: 7 }], products: [product], stockRecords: [],
    userCode: 'FIN', createdAt: '2026-11-26T10:00:00.000Z'
  });
  assert.equal(result.ok, true);
  assert.equal(getCurrentStock(result.stockUpdates[0]), 7);
  assert.equal(result.purchase.invoiceNo, 'PUR-001');
  assert.equal(result.stockUpdates[0].movements[0].type, 'PURCHASE_IN');
});

test('central transfer decreases central stock and increases the selected booth stock', () => {
  const result = prepareCentralTransfer({
    id: 'wh-1', product, toBoothCode: 'G01', qty: 3,
    sourceStock: { id: 'CENTRAL::P-1', boothCode: 'CENTRAL', productKey: 'P-1', openingQty: 8, movements: [] },
    destinationStock: { id: 'G01::P-1', boothCode: 'G01', productKey: 'P-1', openingQty: 2, movements: [] },
    at: '2026-11-26T11:00:00.000Z', reference: 'WH-001', reason: 'شارژ غرفه', userCode: 'FIN'
  });
  assert.equal(result.ok, true);
  assert.equal(result.sourceBalance, 5);
  assert.equal(result.destinationBalance, 5);
  assert.deepEqual(result.movements.map(m => m.type), ['WAREHOUSE_TRANSFER_OUT', 'WAREHOUSE_TRANSFER_IN']);
});

test('central transfer rejects quantities above central warehouse balance', () => {
  const result = prepareCentralTransfer({
    id: 'wh-2', product, toBoothCode: 'G01', qty: 9,
    sourceStock: { id: 'CENTRAL::P-1', boothCode: 'CENTRAL', productKey: 'P-1', openingQty: 8, movements: [] },
    destinationStock: { id: 'G01::P-1', boothCode: 'G01', productKey: 'P-1', openingQty: 2, movements: [] },
    at: '2026-11-26T11:00:00.000Z', reference: 'WH-002', reason: 'شارژ غرفه', userCode: 'FIN'
  });
  assert.equal(result.ok, false);
  assert.equal(result.code, 'INSUFFICIENT_STOCK');
});

test('central purchase receipt rejects invalid or fractional unit quantities', () => {
  const result = prepareCentralPurchase({
    id: 'buy-2', invoiceNo: 'PUR-002', supplier: 'تأمین‌کننده الف', day: '2026-11-26',
    items: [{ productKey: 'P-1', qty: 1.5 }], products: [product], stockRecords: [], userCode: 'FIN', createdAt: '2026-11-26T10:00:00.000Z'
  });
  assert.equal(result.ok, false);
  assert.equal(result.code, 'INVALID_QUANTITY');
});
