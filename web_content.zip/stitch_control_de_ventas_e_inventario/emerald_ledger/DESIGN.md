---
name: Emerald Ledger
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#404944'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#707974'
  outline-variant: '#bfc9c3'
  surface-tint: '#2b6954'
  primary: '#003527'
  on-primary: '#ffffff'
  primary-container: '#064e3b'
  on-primary-container: '#80bea6'
  inverse-primary: '#95d3ba'
  secondary: '#006d2f'
  on-secondary: '#ffffff'
  secondary-container: '#5dfd8a'
  on-secondary-container: '#007232'
  tertiary: '#4a2400'
  on-tertiary: '#ffffff'
  tertiary-container: '#6a3700'
  on-tertiary-container: '#ff9939'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#b0f0d6'
  primary-fixed-dim: '#95d3ba'
  on-primary-fixed: '#002117'
  on-primary-fixed-variant: '#0b513d'
  secondary-fixed: '#66ff8e'
  secondary-fixed-dim: '#3de273'
  on-secondary-fixed: '#002109'
  on-secondary-fixed-variant: '#005322'
  tertiary-fixed: '#ffdcc3'
  tertiary-fixed-dim: '#ffb77d'
  on-tertiary-fixed: '#2f1500'
  on-tertiary-fixed-variant: '#6e3900'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  spacing-2xs: 0.25rem
  spacing-xs: 0.5rem
  spacing-sm: 0.75rem
  spacing-md: 1rem
  spacing-lg: 1.25rem
  spacing-xl: 1.5rem
  spacing-2xl: 2rem
  spacing-3xl: 2.5rem
  screen-edge-mobile: 1rem
  gutter-mobile: 0.75rem
---

## Brand & Style

The design system projects clarity, financial confidence, and effortless operability for micro-entrepreneurs and independent vendors. The emotional tone balances fiscal seriousness with daily approachability, transforming intimidating bookkeeping tasks into straightforward, rewarding interactions.

The visual style is **Modern Tactile Minimalist**:
- High breathability and crisp layouts prioritize data legibility over decorative excess.
- Soft, rounded surfaces mimic physical accounting index cards.
- Strategic pops of vibrant social messaging green signal immediate, communicative action (e.g., instant payment reminders via messaging channels).
- High visual contrast ensures readability in fast-paced retail or on-the-go environments under natural sunlight.

## Colors

The palette establishes financial credibility while maintaining active, practical channels for customer interaction:

- **Primary (`#064E3B` - Deep Emerald):** Represents foundational capital, security, and institutional reliability. Used for primary navigation headers, dominant buttons, and primary ledger balances.
- **Secondary (`#25D366` - WhatsApp Green):** High-energy conversational accent reserved strictly for direct actions—dispatching collection reminders, confirming receipts, and sharing digital invoices.
- **Tertiary (`#D97706` - Warm Amber):** Vital for transactional alerts, primarily "Vence mañana" (Due Tomorrow) and nearing credit horizons.
- **Neutral (`#64748B` - Slate):** Delivers balanced, accessible contrast for metadata, secondary labels, and structural dividers.

### Semantic Status Colors
- **Cobrado (Collected / Paid):** `#059669` (Medium Emerald) on `#ECFDF5` background.
- **Vence Mañana (Due Tomorrow):** `#D97706` (Amber) on `#FFFBEB` background.
- **Pendiente (Pending / Overdue):** `#DC2626` (Crimson) on `#FEF2F2` background.
- **Surface Background:** `#F8FAFC` (Off-white canvas) keeping contrast high and screen glare minimal.

## Typography

The type system blends the energetic structural geometry of **Plus Jakarta Sans** for major numbers, ledger totals, and headings with the neutral clarity of **Inter** for dense tabular data, metadata, and transactional line items.

- Numerical tracking is kept tight and tabular when rendering monetary balances, stock counts, and dates.
- Section tags and payment status indicators use `label-sm` with explicit uppercase tracking for instant scanning during rapid inventory lookups.
- Currency symbols are displayed in `body-sm` or `label-md` relative to large display values to maintain typographic hierarchy.

## Layout & Spacing

The layout is built around a mobile-first, 4-column fluid grid system engineered for one-handed operation.

- **Screen Margins:** Fixed at `16px` (`screen-edge-mobile`) to maximize visible card width on compact displays.
- **Vertical Rhythm:** Rooted in an 8-point spatial model. Minor sub-item offsets utilize a 4-point micro-scale (`spacing-2xs`).
- **Touch Targets:** Interactive areas (such as quick payment reminders, list taps, and quantity incrementers) preserve a minimum hit boundary of `48px x 48px`.
- **Card Clustering:** Related ledger details (client name, amount, due date chip) are packaged with `12px` (`spacing-sm`) internal padding, creating self-contained, easily digestible units.

## Elevation & Depth

Visual hierarchy relies on clean ambient elevation with emerald-tinted undertones rather than stark grey drops:

- **Surface Floor (`Level 0`):** Pure background canvas `#F8FAFC`.
- **Resting Card Surface (`Level 1`):** Pure white (`#FFFFFF`) with a micro-border of `1px solid #E2E8F0` layered over an ambient shadow: `0px 2px 8px -2px rgba(6, 78, 59, 0.04), 0px 1px 3px -1px rgba(0, 0, 0, 0.05)`.
- **Active / Dragged Elements (`Level 2`):** `0px 8px 16px -4px rgba(6, 78, 59, 0.08), 0px 4px 6px -2px rgba(0, 0, 0, 0.04)`.
- **Floating Modals & Action Drawers (`Level 3`):** `0px 16px 24px -6px rgba(6, 78, 59, 0.12), 0px 6px 12px -4px rgba(0, 0, 0, 0.06)`.

Borders work in tandem with elevation: cards with overdue balances subtly replace the default neutral outline with a muted red edge (`#FCA5A5`) to draw the eye without disrupting the layout.

## Shapes

The interface embraces a friendly and approachable curvature (`roundedness: 2`):

- **Standard Cards & Containers:** Radiused at `16px` (`rounded-lg` / `1rem`), providing a modern, tactile feel that fits naturally on handheld devices.
- **Buttons & Input Fields:** Radiused at `12px` (`0.75rem`) for crisp boundaries during form completion and sales registration.
- **Status Chips & Pills:** Full pill radius (`9999px`) to create clear geometric contrast against rectangular data cards.
- **Action Buttons (FAB):** Circular or large rounded pills (`24px` radius) positioned at the bottom right for instant transaction logging.

## Components

### Buttons
- **Primary (Record Sale / Add Stock):** Solid `#064E3B` with white text, `12px` radius, `48px` height, font `label-lg`.
- **Secondary / Action (Send WhatsApp Reminder):** Solid `#25D366` with `#064E3B` text and embedded WhatsApp vector icon.
- **Tertiary / Ghost:** Transparent background, `1px solid #CBD5E1`, text `#064E3B`.

### Status Badges & Chips
- **Cobrado (Collected):** Green container (`#ECFDF5`), green text (`#059669`), green checkmark icon.
- **Vence Mañana (Due Tomorrow):** Amber container (`#FFFBEB`), amber text (`#D97706`), clock icon.
- **Pendiente / Vencido (Pending):** Light red container (`#FEF2F2`), red text (`#DC2626`), exclamation icon.
- Height: `24px`, padding: `4px 10px`, pill-shaped (`9999px`), typography: `label-sm`.

### Cards
- **Transaction Card:** White background, `16px` radius, `12px` inner padding. Houses client name (`headline-sm`), balance due (`display-lg` scale down or `headline-md`), due status chip, and inline quick-trigger button to dispatch reminder messages.
- **Inventory Stock Card:** Two-column split with current SKU image/placeholder, name, quantity stepper (`- / +`), and a visual alert bar if units fall below threshold.

### Input Fields
- Container: `#FFFFFF` fill with `1px solid #CBD5E1`, `12px` corner radius. Focused state transitions border to `#064E3B` with `3px` focus ring in `rgba(6, 78, 59, 0.1)`.
- Numeric inputs for cash values feature a prominent, non-editable `$ / S/. / Q.` currency indicator inside the left pad.

### List Items & Dividers
- Lists employ full-width white card rows separated by `8px` vertical spacing rather than harsh 1px rule lines, preserving a clean card-deck feel.