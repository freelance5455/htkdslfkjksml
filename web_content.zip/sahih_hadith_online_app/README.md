# Sahih Hadith Online Android/Web App

This package contains an installable mobile-friendly web app and a starter Android WebView project.

## Current features
- Online Hadith interface
- Sahih Bukhari / Sahih Muslim selector
- Search and random Hadith UI
- English / Urdu / Hindi / Telugu / Arabic language selector
- Copy/share
- Installable as a PWA
- No login

## Important data note
The UI uses the public fawazahmed0 Hadith API over HTTPS. It provides edition JSON, multiple languages and grades. Language availability varies by collection, so the app now reports when a selected language is unavailable instead of showing a generic API failure.

For production, connect a verified/licensed data source that provides the required English, Urdu, Hindi and Telugu translations and clearly exposes collection/reference/grading metadata.

## Web deployment
Upload the contents of `web/` to any HTTPS static host (GitHub Pages, Netlify, Cloudflare Pages, etc.). On Android Chrome, open the site and choose "Add to Home screen"/"Install app".

## Android
The Android folder is a starter Android Studio project that loads the web app from a configurable HTTPS URL. Set `WEB_APP_URL` in MainActivity.kt to your deployed web app URL.
