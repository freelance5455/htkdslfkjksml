import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter, Routes, Route, Link, useLocation, useNavigate, useParams } from "react-router-dom";
import {
  ArrowLeft, ArrowRight, BarChart3, Bell, CalendarDays, Check, ChevronLeft, CircleDollarSign,
  Headphones, Home, LayoutDashboard, LogIn, Menu, Mic2, Package, Search, Settings, ShoppingCart,
  SlidersHorizontal, Sparkles, Speaker, UserRound, Users, X, Activity, RefreshCw, Radio, AudioLines
} from "lucide-react";
import "./styles.css";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:4000";

const fallbackProducts = [
  {id:"p1",name:"سیستم کامل JBL PRX برای هیئت",brand:"JBL",category:"سیستم کامل",price:null,status:"inquiry",image:"speaker",featured:true},
  {id:"p2",name:"باند JBL PRX 715",brand:"JBL",category:"باند و بلندگو",price:null,status:"inquiry",image:"speaker",featured:true},
  {id:"p3",name:"میکسر Yamaha MG16",brand:"Yamaha",category:"میکسر",price:null,status:"inquiry",image:"mixer",featured:true},
  {id:"p4",name:"میکروفون بی‌سیم Shure QLX-D",brand:"Shure",category:"میکروفون",price:null,status:"inquiry",image:"mic",featured:true},
  {id:"p5",name:"آمپلی‌فایر Crown XLS",brand:"Crown",category:"آمپلی‌فایر",price:null,status:"inquiry",image:"amp",featured:false},
  {id:"p6",name:"آمپلی‌فایر / میکسر Dynacord",brand:"Dynacord",category:"آمپلی‌فایر",price:null,status:"inquiry",image:"amp",featured:false},
  {id:"p7",name:"باند RCF",brand:"RCF",category:"باند و بلندگو",price:null,status:"inquiry",image:"speaker",featured:false},
  {id:"p8",name:"باند Electro-Voice",brand:"EV",category:"باند و بلندگو",price:1400000,status:"verified-reference",source:"HomeServize",updatedAt:"مرجع عمومی",image:"speaker",featured:true}
];

const formatToman = (n) => n == null ? "استعلام قیمت" : new Intl.NumberFormat("fa-IR").format(n) + " تومان";
const getToken = () => localStorage.getItem("avaye_private_token");
const setToken = (t) => t ? localStorage.setItem("avaye_private_token", t) : localStorage.removeItem("avaye_private_token");

function PrivateGate({children}){
  const [ready,setReady]=useState(false);
  const [authed,setAuthed]=useState(false);
  const [phone,setPhone]=useState("");
  const [password,setPassword]=useState("");
  const [error,setError]=useState("");
  const navigate=useNavigate();

  useEffect(()=>{
    const token=getToken();
    if(!token){ setReady(true); return; }
    fetch(`${API_URL}/api/auth/me`,{headers:{Authorization:`Bearer ${token}`}})
      .then(r=>{ if(!r.ok) throw new Error(); setAuthed(true); })
      .catch(()=>setToken(null))
      .finally(()=>setReady(true));
  },[]);

  const login=async(e)=>{
    e.preventDefault(); setError("");
    try{
      const r=await fetch(`${API_URL}/api/auth/login`,{
        method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({phone,password})
      });
      const data=await r.json();
      if(!r.ok) throw new Error(data.error||"ورود ناموفق بود");
      setToken(data.token); setAuthed(true); navigate("/");
    }catch(err){ setError(err.message); }
  };

  if(!ready) return <div className="min-h-screen grid place-items-center bg-ink text-white"><div className="panel p-8">در حال بررسی دسترسی…</div></div>;
  if(authed) return children;

  return <div className="min-h-screen bg-ink text-white font-vazir grid place-items-center p-5">
    <div className="w-full max-w-md panel p-8 md:p-10">
      <div className="logoMark mx-auto w-fit"><LockIcon/></div>
      <h1 className="mt-5 text-center text-2xl font-black">آوای ولایت — ورود خصوصی</h1>
      <p className="mt-3 text-center text-sm leading-7 text-white/45">این نسخه خصوصی است و فقط کاربران مجاز می‌توانند وارد شوند.</p>
      <form onSubmit={login} className="mt-7 space-y-4">
        <label className="field">شماره موبایل<input value={phone} onChange={e=>setPhone(e.target.value)} placeholder="شماره مجاز" autoComplete="username"/></label>
        <label className="field">رمز عبور<input value={password} onChange={e=>setPassword(e.target.value)} placeholder="رمز عبور" type="password" autoComplete="current-password"/></label>
        {error && <div className="rounded-xl border border-red-400/20 bg-red-400/10 p-3 text-sm text-red-200">{error}</div>}
        <button className="goldBtn w-full justify-center" type="submit"><LogIn size={17}/> ورود</button>
      </form>
      <p className="mt-5 text-center text-[11px] text-white/30">اطلاعات ورود در فایل .env سرور تنظیم می‌شود.</p>
    </div>
  </div>;
}
function LockIcon(){ return <span style={{display:"inline-flex"}}><span className="sr-only">قفل</span>🔒</span>; }


function App(){
  const [products,setProducts] = useState(fallbackProducts);
  const [live,setLive] = useState(true);
  useEffect(()=>{
    let timer;
    const load=async()=>{
      try{
        const token=getToken();
        const r=await fetch(`${API_URL}/api/products`,{headers:{Authorization:`Bearer ${token}`}});
        if(r.status===401){ setToken(null); window.location.reload(); return; }
        if(r.ok){ const data=await r.json(); if(Array.isArray(data.products)) setProducts(data.products); }
      }catch{}
    };
    load();
    timer=setInterval(load,15000);
    return()=>clearInterval(timer);
  },[]);
  return <PrivateGate><Shell products={products} live={live} setLive={setLive}/></PrivateGate>;
}

function Shell({products,live,setLive}){
  return <div className="min-h-screen bg-ink text-white font-vazir">
    <Header />
    <main className="pb-24 md:pb-8"><Routes>
      <Route path="/" element={<HomePage products={products} live={live}/>}/>
      <Route path="/products" element={<ProductsPage products={products}/>}/>
      <Route path="/products/:id" element={<ProductPage products={products}/>}/>
      <Route path="/studio" element={<StudioPage/>}/>
      <Route path="/cart" element={<CartPage products={products}/>}/>
      <Route path="/login" element={<LoginPage/>}/>
      <Route path="/about" element={<AboutPage/>}/>
      <Route path="/admin" element={<AdminPage products={products} setProducts={()=>{}}/>}/>
    </Routes></main>
    <MobileNav/>
    <footer className="border-t border-white/10 bg-black/20 py-10">
      <div className="container flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div><Brand/><p className="mt-2 text-xs text-white/45">تجهیزات صدا، استودیو و سیستم‌های مراسم</p></div>
        <div className="text-xs text-white/40">© آوای ولایت — قیمت‌های خارجی با برچسب «مرجع» نمایش داده می‌شوند.</div>
      </div>
    </footer>
  </div>
}

function Brand(){
  return <Link to="/" className="flex items-center gap-3">
    <span className="logoMark"><AudioLines size={23}/></span>
    <span className="text-lg font-black tracking-tight">آوای ولایت</span>
  </Link>
}

function Header(){
  const [open,setOpen]=useState(false);
  return <header className="sticky top-0 z-40 border-b border-white/10 bg-ink/85 backdrop-blur-xl">
    <div className="container flex h-20 items-center justify-between">
      <Brand/>
      <nav className="hidden items-center gap-7 md:flex text-sm text-white/65">
        <Nav to="/">خانه</Nav><Nav to="/products">محصولات</Nav><Nav to="/studio">استودیو</Nav><Nav to="/about">درباره ما</Nav><Nav to="/admin">مدیریت</Nav>
      </nav>
      <div className="hidden items-center gap-2 md:flex">
        <Link className="iconBtn" to="/cart"><ShoppingCart size={18}/></Link>
        <button className="goldBtn px-4 py-2.5 text-sm" onClick={()=>{setToken(null);window.location.reload();}}><LogIn size={16}/> خروج</button>
      </div>
      <button className="iconBtn md:hidden" onClick={()=>setOpen(!open)}>{open?<X/>:<Menu/>}</button>
    </div>
    {open && <div className="md:hidden border-t border-white/10 bg-black/50 p-4 space-y-2">
      {["/","/products","/studio","/about","/admin"].map((p,i)=><Link key={p} onClick={()=>setOpen(false)} className="block rounded-xl p-3 hover:bg-white/5" to={p}>{["خانه","محصولات","استودیو","درباره ما","مدیریت"][i]}</Link>)}
    </div>}
  </header>
}

function Nav({to,children}){ const loc=useLocation(); return <Link className={loc.pathname===to?"text-gold2":"hover:text-white"} to={to}>{children}</Link> }

function HomePage({products,live}){
  return <div>
    <section className="container grid min-h-[650px] items-center gap-12 py-16 lg:grid-cols-[1.05fr_.95fr]">
      <div>
        <div className="livePill"><span className="pulse"></span> قیمت‌ها در حال بروزرسانی</div>
        <h1 className="mt-6 text-4xl font-black leading-[1.45] md:text-6xl">صدای حرفه‌ای،<br/><span className="text-gold2">برای لحظه‌های مهم</span></h1>
        <p className="mt-6 max-w-xl text-base leading-8 text-white/60 md:text-lg">تجهیزات حرفه‌ای صدا، مناسب هیئت‌ها و مراسم؛ از باند و میکسر تا میکروفون و آمپلی‌فایر، با امکان اجاره و استعلام قیمت روز.</p>
        <div className="mt-8 flex flex-wrap gap-3">
          <Link to="/products" className="goldBtn">مشاهده محصولات <ArrowLeft size={18}/></Link>
          <Link to="/studio" className="ghostBtn">خدمات استودیو</Link>
        </div>
        <div className="mt-10 grid max-w-xl grid-cols-3 gap-3">
          {[["۲۴/۷","پایش قیمت"],["+۸","برند حرفه‌ای"],["۱۰۰٪","RTL و موبایل"]].map(x=><div className="stat" key={x[0]}><b>{x[0]}</b><span>{x[1]}</span></div>)}
        </div>
      </div>
      <HeroVisual/>
    </section>

    <section className="container py-8">
      <SectionTitle eyebrow="LIVE MARKET" title="محبوب‌ترین تجهیزات" action="همه محصولات" href="/products"/>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">{products.filter(p=>p.featured).slice(0,4).map(p=><ProductCard key={p.id} p={p}/>)}</div>
    </section>

    <section className="container py-16">
      <div className="panel grid gap-8 overflow-hidden p-8 md:grid-cols-2 md:p-12">
        <div><div className="goldText text-sm">استودیو و صدابرداری</div><h2 className="mt-3 text-3xl font-black">ضبط، میکس و صدای حرفه‌ای</h2><p className="mt-4 leading-8 text-white/55">برای پادکست، مداحی، سخنرانی و محتوای صوتی، سرویس‌های استودیو و مهندسی صدا را رزرو کنید.</p><Link className="goldBtn mt-6 inline-flex" to="/studio">مشاهده خدمات</Link></div>
        <div className="studioVisual"><Mic2 size={110}/><div className="eq"><i/><i/><i/><i/><i/><i/><i/><i/></div></div>
      </div>
    </section>
  </div>
}

function HeroVisual(){
  return <div className="heroVisual">
    <div className="heroGlow"></div><div className="speakerBig"><Speaker size={120}/><div className="speakerRing"></div></div>
    <div className="mixerMini"><SlidersHorizontal/><div className="faders">{Array.from({length:7}).map((_,i)=><i key={i} style={{height:30+i*7}}/>)}</div></div>
    <div className="heroCaption"><span>آماده برای مراسم</span><b>صدای شفاف، قدرت واقعی</b></div>
  </div>
}

function SectionTitle({eyebrow,title,action,href}){
  return <div className="mb-6 flex items-end justify-between"><div><div className="goldText text-xs tracking-widest">{eyebrow}</div><h2 className="mt-2 text-2xl font-black md:text-3xl">{title}</h2></div>{href&&<Link className="text-sm text-white/55 hover:text-gold2" to={href}>{action} <ArrowLeft className="inline" size={15}/></Link>}</div>
}

function ProductCard({p}){
  return <Link to={`/products/${p.id}`} className="productCard">
    <div className="productArt"><EquipmentIcon type={p.image}/><span className={p.status==="verified-reference"?"refBadge":"liveBadge"}>{p.status==="verified-reference"?"مرجع قیمت":"استعلام"}</span></div>
    <div className="p-4"><div className="text-xs text-white/40">{p.brand} · {p.category}</div><h3 className="mt-1 font-bold">{p.name}</h3><div className="mt-4 flex items-end justify-between"><div><div className="text-[10px] text-white/35">اجاره روزانه</div><strong className={p.price?"text-gold2":"text-white/60"}>{formatToman(p.price)}</strong></div><ChevronLeft className="text-white/30" size={18}/></div>{p.source&&<div className="mt-2 text-[10px] text-white/30">منبع: {p.source}</div>}</div>
  </Link>
}

function EquipmentIcon({type="speaker"}){
  const Icon=type==="mixer"?SlidersHorizontal:type==="mic"?Mic2:type==="amp"?Activity:Speaker;
  return <div className="equipIcon"><Icon size={72}/><div className="soundWave">{[1,2,3,4,5].map(n=><i key={n} style={{height:10+n*7}}/>)}</div></div>
}

function ProductsPage({products}){
  const [q,setQ]=useState(""); const [cat,setCat]=useState("همه");
  const cats=["همه","باند و بلندگو","میکسر","میکروفون","آمپلی‌فایر","سیستم کامل"];
  const list=products.filter(p=>(cat==="همه"||p.category===cat)&&p.name.includes(q));
  return <div className="container py-12"><div className="mb-8"><div className="goldText text-xs">PRODUCTS</div><h1 className="mt-2 text-4xl font-black">تجهیزات حرفه‌ای</h1><p className="mt-3 text-white/50">قیمت روز در صورت وجود منبع معتبر؛ در غیر این صورت استعلام.</p></div>
    <div className="mb-7 flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between"><div className="searchBox"><Search size={18}/><input value={q} onChange={e=>setQ(e.target.value)} placeholder="جستجو در تجهیزات..."/></div><div className="flex flex-wrap gap-2">{cats.map(c=><button key={c} onClick={()=>setCat(c)} className={cat===c?"chip active":"chip"}>{c}</button>)}</div></div>
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{list.map(p=><ProductCard p={p} key={p.id}/>)}</div>
  </div>
}

function ProductPage({products}){
  const {id}=useParams(); const p=products.find(x=>x.id===id)||products[0];
  return <div className="container py-12"><Link to="/products" className="text-sm text-white/45"><ArrowRight className="inline" size={15}/> بازگشت</Link>
    <div className="mt-6 grid gap-8 lg:grid-cols-2">
      <div className="detailArt"><EquipmentIcon type={p.image}/><div className="detailGlow"></div></div>
      <div className="panel p-7 md:p-9"><div className="text-xs text-white/40">{p.brand} · {p.category}</div><h1 className="mt-2 text-3xl font-black">{p.name}</h1>
        <div className="mt-6 priceBox"><span>اجاره روزانه</span><strong>{formatToman(p.price)}</strong>{p.source&&<small>مرجع عمومی: {p.source}</small>}</div>
        <div className="mt-6 grid grid-cols-3 gap-2">{["کیفیت حرفه‌ای","مناسب مراسم","پشتیبانی فنی"].map(x=><div className="miniFeature" key={x}><Check size={16}/>{x}</div>)}</div>
        <p className="mt-7 leading-8 text-white/55">این صفحه برای نمایش مشخصات و وضعیت قیمت طراحی شده است. قیمت‌های خارجی با برچسب مرجع نمایش داده می‌شوند و قیمت اختصاصی آوای ولایت تنها پس از تأیید منبع ثبت می‌شود.</p>
        <button className="goldBtn mt-7 w-full">افزودن به سبد <ShoppingCart size={18}/></button>
      </div>
    </div>
  </div>
}

function StudioPage(){
  const services=["ضبط مداحی و سخنرانی","میکس و مسترینگ","تولید پادکست","صدابرداری مراسم"];
  return <div className="container py-12"><div className="grid gap-8 lg:grid-cols-[1.1fr_.9fr]"><div><div className="goldText text-xs">STUDIO</div><h1 className="mt-3 text-4xl font-black md:text-5xl">استودیو ضبط<br/><span className="text-gold2">صدای حرفه‌ای</span></h1><p className="mt-5 max-w-xl leading-8 text-white/55">فضای تخصصی برای ضبط، ویرایش و آماده‌سازی محتوای صوتی با تجهیزات حرفه‌ای و مهندسی صدا.</p><button className="goldBtn mt-7">درخواست رزرو <CalendarDays size={18}/></button></div><div className="studioHero"><Mic2 size={130}/><div className="recording"><span className="pulse"></span> در حال ضبط</div></div></div>
    <div className="mt-14 grid gap-4 md:grid-cols-2">{services.map((s,i)=><div className="panel p-6" key={s}><div className="flex items-center justify-between"><span className="number">0{i+1}</span><Mic2 className="text-gold2"/></div><h3 className="mt-5 text-xl font-bold">{s}</h3><p className="mt-2 text-sm leading-7 text-white/45">سرویس تخصصی با امکان هماهنگی زمان و تجهیزات مورد نیاز.</p></div>)}</div>
  </div>
}

function CartPage(){return <div className="container py-20"><div className="panel mx-auto max-w-2xl p-10 text-center"><ShoppingCart className="mx-auto text-gold2" size={42}/><h1 className="mt-5 text-2xl font-black">سبد شما خالی است</h1><p className="mt-3 text-white/50">تجهیزات مورد نظر را از صفحه محصولات انتخاب کنید.</p><Link className="goldBtn mt-6 inline-flex" to="/products">مشاهده محصولات</Link></div></div>}

function LoginPage(){return <div className="container py-16"><div className="mx-auto max-w-md panel p-8"><div className="mx-auto logoMark w-fit"><UserRound/></div><h1 className="mt-5 text-center text-2xl font-black">ورود به حساب</h1><label className="field">شماره موبایل<input placeholder="09xxxxxxxxx"/></label><label className="field">رمز عبور<input type="password" placeholder="••••••••"/></label><button className="goldBtn mt-5 w-full">ورود <LogIn size={17}/></button><p className="mt-5 text-center text-xs text-white/35">حساب آزمایشی در این نسخه فعال است.</p></div></div>}

function AboutPage(){return <div className="container py-16"><div className="max-w-3xl"><div className="goldText text-xs">ABOUT</div><h1 className="mt-3 text-4xl font-black">آوای ولایت</h1><p className="mt-6 leading-9 text-white/60">یک پلتفرم تخصصی برای دسترسی سریع به تجهیزات صدای حرفه‌ای، اجاره سیستم‌های مناسب هیئت و مراسم، و خدمات استودیو و صدابرداری.</p><div className="mt-10 grid gap-4 md:grid-cols-3">{["قیمت شفاف","تجهیزات حرفه‌ای","پشتیبانی تخصصی"].map((x,i)=><div className="panel p-6" key={x}><Sparkles className="text-gold2"/><h3 className="mt-4 font-bold">{x}</h3></div>)}</div></div></div>}

function AdminPage({products}){
  const data=[["فروردین",28],["اردیبهشت",34],["خرداد",42],["تیر",38],["مرداد",55],["شهریور",61]];
  return <div className="container py-10"><div className="flex flex-wrap items-end justify-between gap-4"><div><div className="goldText text-xs">ADMIN</div><h1 className="mt-2 text-3xl font-black">داشبورد مدیریت</h1></div><button className="ghostBtn"><RefreshCw size={17}/> همگام‌سازی قیمت</button></div>
    <div className="mt-7 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">{[["درآمد کل","۴۸۶,۲۰۰,۰۰۰","CircleDollarSign"],["سفارش امروز","۲۴","Package"],["کاربران","۱,۸۴۲","Users"],["محصولات",products.length,"Speaker"]].map(([a,b,c])=>{const I=c==="CircleDollarSign"?CircleDollarSign:c==="Package"?Package:c==="Users"?Users:Speaker;return <div className="panel p-5" key={a}><I className="text-gold2"/><div className="mt-5 text-xs text-white/40">{a}</div><b className="mt-1 block text-2xl">{b}</b></div>})}</div>
    <div className="mt-5 grid gap-5 lg:grid-cols-[1.4fr_.6fr]"><div className="panel p-6"><h2 className="font-bold">فروش ماهانه</h2><div className="mt-5 h-64"><BarChartSimple data={data}/></div></div><div className="panel p-6"><h2 className="font-bold">سلامت منابع قیمت</h2><div className="mt-5 space-y-3">{["HomeServize","اجاره باند تهران","Iran Renter"].map((x,i)=><div className="sourceRow" key={x}><span className="pulse green"></span><div className="flex-1"><b>{x}</b><small>{i===2?"نیازمند بررسی":"آخرین همگام‌سازی موفق"}</small></div><Activity size={16}/></div>)}</div></div></div>
    <div className="panel mt-5 p-6"><div className="flex items-center justify-between"><h2 className="font-bold">آخرین سفارش‌ها</h2><button className="text-xs text-gold2">مشاهده همه</button></div><div className="mt-5 overflow-auto"><table><thead><tr><th>سفارش</th><th>مشتری</th><th>مبلغ</th><th>وضعیت</th></tr></thead><tbody>{["#AV-1082","#AV-1081","#AV-1080","#AV-1079"].map((x,i)=><tr key={x}><td>{x}</td><td>کاربر {i+1}</td><td>{["۳۵,۰۰۰,۰۰۰","۱۲,۵۰۰,۰۰۰","۸,۸۰۰,۰۰۰","۲۱,۰۰۰,۰۰۰"][i]} تومان</td><td><span className="okBadge">تایید شده</span></td></tr>)}</tbody></table></div></div>
  </div>
}

function BarChartSimple({data}){
  const max=Math.max(...data.map(x=>x[1]));
  return <div className="h-full flex items-end gap-3">{data.map(([m,v])=><div className="flex-1 h-full flex flex-col justify-end items-center gap-2" key={m}><div className="bar" style={{height:`${(v/max)*85}%`}}></div><span className="text-[10px] text-white/35">{m}</span></div>)}</div>
}

function MobileNav(){return <nav className="mobileNav md:hidden">{[[Home,"/","خانه"],[Speaker,"/products","محصولات"],[Radio,"/studio","استودیو"],[ShoppingCart,"/cart","سبد"],[UserRound,"/login","حساب"]].map(([I,to,l])=><Link to={to} key={to}><I size={18}/><span>{l}</span></Link>)}</nav>}

createRoot(document.getElementById("root")).render(<BrowserRouter><App/></BrowserRouter>);
