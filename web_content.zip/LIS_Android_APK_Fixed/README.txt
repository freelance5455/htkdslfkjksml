LIS Android APK - Fixed Print/PDF Build

This project is an Android Studio WebView app for the supplied LIS HTML file.

PRINT/PDF FIX:
Quotation and Invoice Print/PDF no longer depend on window.print() inside the Android WebView.
The HTML sends the complete document to a native Android PrintManager bridge.
From the Android print screen, choose a printer or "Save as PDF".

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).

App data remains in the WebView localStorage, as in the supplied HTML.
