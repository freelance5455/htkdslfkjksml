/* Native AdMob bridge adapter.
 * A native Android wrapper should expose:
 * window.AndroidAdMob.showRewardedAd("coins"|"hint"|"life")
 * and call back into window.onRewardedAdCompleted(type) after a completed ad.
 */
window.AD_MANAGER = {
  showRewarded: function(type){
    try {
      if (window.AndroidAdMob && typeof window.AndroidAdMob.showRewardedAd === "function") {
        window.AndroidAdMob.showRewardedAd(type);
        return true;
      }
    } catch(e) {}
    return false;
  }
};
window.onRewardedAdCompleted = function(type){
  if (typeof window.grantAdReward === "function") window.grantAdReward(type);
};
