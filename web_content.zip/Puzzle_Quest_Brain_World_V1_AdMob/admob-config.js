/* AdMob configuration
 * IMPORTANT: HTML-to-APK Builder wraps this game in a WebView and does not
 * provide a native AdMob SDK bridge. Keep this config ready for a native
 * AdMob-capable wrapper. Do NOT use your own ads for testing.
 */
window.ADMOB_CONFIG = {
  enabled: true,
  rewardedAdUnitId: "ca-app-pub-3940256099942544/5224354917", // Google test rewarded ID
  rewards: { coins: 100, hint: 1, life: 1 }
};
