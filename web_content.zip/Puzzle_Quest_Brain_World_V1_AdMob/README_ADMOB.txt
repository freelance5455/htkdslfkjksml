PUZZLE QUEST: BRAIN WORLD — AdMob-ready build

This ZIP adds the Rewarded Ad UI/bridge and Google test Rewarded Ad Unit ID.

IMPORTANT:
The current HTML-to-APK Builder is a WebView wrapper and its current feature list does not provide a native Google Mobile Ads/AdMob SDK bridge. Therefore, uploading this ZIP to that builder will NOT by itself make real AdMob ads appear. The game will show a message when the ad button is pressed.

For real ads, build the same game with an Android wrapper that includes the Google Mobile Ads SDK and exposes:
window.AndroidAdMob.showRewardedAd(type)
Then call:
window.onRewardedAdCompleted(type)
after the user completes the rewarded ad.

The config currently uses Google's test rewarded unit:
ca-app-pub-3940256099942544/5224354917
Replace it only for a production native build after creating your own AdMob Rewarded Ad Unit.

Rewards included:
- AD +100 button -> +100 coins after completed ad
- Bridge also supports hint/life reward types for future buttons.
