PUZZLE QUEST: BRAIN WORLD — FINAL EDITION v2
==============================================

This version keeps the same single 100-level puzzle game, but the difficulty curve is intentionally gradual:

1–10   = Very easy / confidence building
11–20  = Easy+
21–30  = Moderate
31–40  = Medium
41–50  = Medium-Hard
51–60  = Hard
61–70  = Harder
71–80  = Very Hard
81–90  = Expert
91–100 = Final Master

Included:
• 100 levels
• Math, sequence, logic, riddles, science, geography, word puzzles and code/cipher
• 1–3 stars
• Coins, XP, lives
• Hints and skip
• Level map with sequential unlocking
• Daily reward
• Achievements
• localStorage save/autosave
• Responsive mobile UI
• Phaser vector/neon presentation

Important:
Phaser is loaded from jsDelivr CDN, so the browser version needs internet for the Phaser library.
For a fully offline APK, bundle Phaser locally in the APK builder.

This is a polished playable game prototype/release candidate. It is not claimed to be AAA commercial production art.
