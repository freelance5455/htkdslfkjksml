SHADOW STRIKE V25 — GRAPHICS QUALITY UPGRADE

V25 uses V24 as its base. This release focuses ONLY on visual quality; gameplay, map, controls, enemies, and character/building features are otherwise kept as the V24 base.

Graphics changes:
- WebGL antialiasing enabled for smoother edges.
- Procedural surface, facade, and asphalt textures increased to 512x512.
- Anisotropic texture filtering enabled (capped for mobile performance).
- Improved selectable render resolution: Performance, Balanced, High. High uses up to 1.6 device pixel ratio; actual resolution depends on the device.
- Render pacing targets adjusted per quality setting.

Performance varies by phone and browser. If the frame rate drops, select Performance. Real-time shadow maps remain disabled intentionally to avoid a large mobile performance cost. Three.js is loaded from an external CDN, so internet is required on first load.

Validation: JavaScript syntax and ZIP integrity checks. No physical-device visual/FPS test has been performed.
