/* SHADOW STRIKE V25: graphics-quality-only upgrade based on V24. */
(()=>{
'use strict';
const G=window.ShadowGame;
if(!window.THREE||!G){console.warn('3D renderer unavailable; using classic renderer.');return;}
const THREE=window.THREE;
const canvas2d=document.getElementById('gameCanvas');canvas2d.style.display='none';
const isMobile=matchMedia('(pointer:coarse)').matches||Math.min(innerWidth,innerHeight)<700;
let renderQuality='performance',lastRenderAt=0;
const renderer=new THREE.WebGLRenderer({antialias:true,alpha:false,powerPreference:'high-performance',stencil:false,depth:true,preserveDrawingBuffer:false});
function qualityParams(q){return q==='high'?{dpr:Math.min(devicePixelRatio||1,1.6),fps:50,dust:90}:q==='balanced'?{dpr:Math.min(devicePixelRatio||1,1.2),fps:40,dust:55}:{dpr:Math.min(devicePixelRatio||1,.9),fps:30,dust:28};}
function applyQuality(q){renderQuality=['high','balanced','performance'].includes(q)?q:'performance';const v=qualityParams(renderQuality);renderer.setPixelRatio(v.dpr);renderer.setSize(innerWidth,innerHeight,false);dust.visible=true;if(dust.geometry.getAttribute('position').count!==v.dust){const arr=new Float32Array(v.dust*3);for(let i=0;i<v.dust;i++){arr[i*3]=1+Math.random()*22;arr[i*3+1]=.25+Math.random()*3.8;arr[i*3+2]=1+Math.random()*22;}dust.geometry.setAttribute('position',new THREE.BufferAttribute(arr,3));}return v;}
renderer.setSize(innerWidth,innerHeight);renderer.shadowMap.enabled=false;renderer.setClearColor(0xb8d5e6,1);
renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.08;
renderer.domElement.id='world3d';renderer.domElement.style.cssText='position:fixed;inset:0;width:100%;height:100%;z-index:0;display:block;touch-action:none;';document.body.insertBefore(renderer.domElement,document.getElementById('hud'));
const aim=document.createElement('div');aim.id='aimReticle';aim.setAttribute('aria-label','نشانه هدف گیری');aim.innerHTML='<i></i><b></b><i></i><b></b>';aim.style.cssText='position:fixed;left:50%;top:50%;width:24px;height:24px;transform:translate(-50%,-50%);z-index:3;pointer-events:none;display:block;filter:drop-shadow(0 1px 2px #15212a);';aim.querySelectorAll('i').forEach((el,i)=>{el.style.cssText='position:absolute;background:#f8fff5;border:1px solid #1b3137;border-radius:1px;width:7px;height:2px;left:50%;top:50%;transform:translate(-50%,-50%) '+(i===0?'translateX(-7px)':'translateX(7px)')+';'});aim.querySelectorAll('b').forEach((el,i)=>{el.style.cssText='position:absolute;background:#f8fff5;border:1px solid #1b3137;border-radius:1px;width:2px;height:7px;left:50%;top:50%;transform:translate(-50%,-50%) '+(i===0?'translateY(-7px)':'translateY(7px)')+';'});document.body.appendChild(aim);
const scene=new THREE.Scene();scene.background=new THREE.Color(0xb8d5e6);scene.fog=new THREE.FogExp2(0xd4e0df,.0065);
const camera=new THREE.PerspectiveCamera(76,innerWidth/innerHeight,.08,110);camera.rotation.order='YXZ';scene.add(camera);
const hemi=new THREE.HemisphereLight(0xf0f6ff,0x77796b,1.8);scene.add(hemi);
const key=new THREE.DirectionalLight(0xfff5e6,2.15);key.position.set(-5,14,7);key.castShadow=false;scene.add(key);
// V16: avoid multiple expensive point lights on mobile; emissive trim supplies local color.
function surfaceTexture(base,grit,lines=false){const c=document.createElement('canvas');c.width=512;c.height=512;const q=c.getContext('2d');q.fillStyle=base;q.fillRect(0,0,512,512);for(let i=0;i<3920;i++){const v=Math.random();q.fillStyle=v>.5?`rgba(255,255,255,${Math.random()*.075})`:`rgba(0,0,0,${Math.random()*.12})`;q.fillRect(Math.random()*512,Math.random()*512,1+Math.random()*8,1+Math.random()*4);}if(lines){q.strokeStyle='rgba(8,15,19,.3)';q.lineWidth=1;for(let y=16;y<512;y+=64){q.beginPath();q.moveTo(0,y);q.lineTo(512,y);q.stroke();}}const t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(2,2);t.colorSpace=THREE.SRGBColorSpace;return t;}
const floorTex=surfaceTexture('#777c78',.1,true),wallTex=surfaceTexture('#898b83',.1,true),crateTex=surfaceTexture('#777568',.1,true);
const maxAnisotropy=renderer.capabilities.getMaxAnisotropy();[floorTex,wallTex,crateTex].forEach(t=>{t.anisotropy=Math.min(8,maxAnisotropy);});
const mats={floor:new THREE.MeshStandardMaterial({map:floorTex,color:0xd6d3c8,roughness:.94,metalness:.03}),wall:new THREE.MeshStandardMaterial({map:wallTex,color:0xd4d0c4,roughness:.9,metalness:.04}),wall2:new THREE.MeshStandardMaterial({map:wallTex,color:0xe0dbcd,roughness:.9,metalness:.03}),trim:new THREE.MeshStandardMaterial({color:0x6ba99c,emissive:0x16483f,emissiveIntensity:.45,metalness:.35,roughness:.48}),yellow:new THREE.MeshStandardMaterial({color:0xc99a4b,metalness:.12,roughness:.72}),crate:new THREE.MeshStandardMaterial({map:crateTex,color:0xc0b69b,roughness:.92,metalness:.02}),dark:new THREE.MeshStandardMaterial({color:0x3c4140,metalness:.25,roughness:.65}),enemy:new THREE.MeshStandardMaterial({color:0x76504a,roughness:.78,metalness:.08}),enemyGlow:new THREE.MeshStandardMaterial({color:0xc85d50,emissive:0x501a14,emissiveIntensity:.55}),ammo:new THREE.MeshStandardMaterial({color:0x45f3d7,emissive:0x0b8c7d,emissiveIntensity:1.2}),med:new THREE.MeshStandardMaterial({color:0x65f58b,emissive:0x138b37,emissiveIntensity:1.1})};
const boxGeo=new THREE.BoxGeometry(1,1,1);const wallMeshes=[];
function addBox(x,y,z,sx,sy,sz,mat,shadow=true){const m=new THREE.Mesh(boxGeo,mat);m.position.set(x,y,z);m.scale.set(sx,sy,sz);m.castShadow=false;m.receiveShadow=false;scene.add(m);return m;}
// Industrial concrete floor and ceiling
const floor=new THREE.Mesh(new THREE.PlaneGeometry(24,24),mats.floor);floor.rotation.x=-Math.PI/2;floor.position.set(12,0,12);floor.receiveShadow=true;scene.add(floor);
const ceiling=new THREE.Mesh(new THREE.PlaneGeometry(24,24),new THREE.MeshStandardMaterial({color:0x899b9f,roughness:.95,side:THREE.DoubleSide}));ceiling.rotation.x=Math.PI/2;ceiling.position.set(12,4.6,12);scene.add(ceiling);
// Floor grid / hazard lines
const grid=new THREE.GridHelper(24,48,0x89958b,0xb0b4a7);grid.position.set(12,.012,12);grid.material.transparent=true;grid.material.opacity=.11;scene.add(grid);
G.map.forEach((row,z)=>row.forEach((v,x)=>{if(!v)return;const mat=((x+z)%4===0)?mats.wall2:mats.wall;wallMeshes.push(addBox(x+.5,1.9,z+.5,1,3.8,1,mat));
 if((x*3+z*7)%11===0){addBox(x+.5,3.82,z+.5,.82,.055,.82,mats.trim,false);}
}));
// V20: lightweight architectural facade kit. Cosmetic only; gameplay collision/map stays unchanged.
// Procedural, tiny texture maps add surface scale without downloading heavy assets.
function makeConcreteTexture(){const c=document.createElement('canvas');c.width=512;c.height=512;const g=c.getContext('2d');g.fillStyle='#b7b2a6';g.fillRect(0,0,512,512);
 // Slightly irregular plaster variation and weather streaks.
 for(let i=0;i<5800;i++){const a=Math.random()*.10;g.fillStyle=Math.random()>.48?`rgba(255,250,235,${a})`:`rgba(45,49,48,${a})`;g.fillRect(Math.random()*512,Math.random()*512,1+Math.random()*8,1+Math.random()*3);}
 for(let i=0;i<136;i++){const x=Math.random()*512,y=Math.random()*512;g.strokeStyle='rgba(63,61,54,.20)';g.lineWidth=.45+Math.random()*.65;g.beginPath();g.moveTo(x,y);g.lineTo(x+(Math.random()-.5)*8,y+5+Math.random()*18);g.lineTo(x+(Math.random()-.5)*12,y+14+Math.random()*32);g.stroke();}
 // Fine aggregate and subtle runoff streaks add scale cues without external texture files.
 for(let i=0;i<9600;i++){const a=.015+Math.random()*.055;g.fillStyle=Math.random()>.5?`rgba(245,240,226,${a})`:`rgba(35,39,37,${a})`;g.fillRect(Math.random()*512,Math.random()*512,.5+Math.random()*1.4,.5+Math.random()*1.8);}
 for(let i=0;i<10;i++){const x=Math.random()*512;const h=36+Math.random()*130;const gr=g.createLinearGradient(x,0,x+2+Math.random()*4,h);gr.addColorStop(0,'rgba(70,68,60,.12)');gr.addColorStop(1,'rgba(70,68,60,0)');g.fillStyle=gr;g.fillRect(x,0,3+Math.random()*3,h);}
 // Faint panel joints keep the surface from looking like a flat plastic block.
 g.strokeStyle='rgba(65,67,63,.12)';g.lineWidth=1;for(let y=128;y<512;y+=128){g.beginPath();g.moveTo(0,y);g.lineTo(512,y);g.stroke();}
 const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(1.2,1.2);return t;}
const facadeTexture=makeConcreteTexture();facadeTexture.anisotropy=Math.min(8,renderer.capabilities.getMaxAnisotropy());
const facadeStone=new THREE.MeshStandardMaterial({map:facadeTexture,color:0xc0baad,roughness:.94,metalness:.01});
const facadeLight=new THREE.MeshStandardMaterial({map:facadeTexture,color:0xd4ccbc,roughness:.88,metalness:.02});
const facadeDark=new THREE.MeshStandardMaterial({color:0x555b5b,roughness:.86,metalness:.06});
const windowGlass=new THREE.MeshStandardMaterial({color:0x526873,roughness:.19,metalness:.38,emissive:0x10191d,emissiveIntensity:.12});
const windowFrame=new THREE.MeshStandardMaterial({color:0x6f7776,roughness:.48,metalness:.5});
const concreteBand=new THREE.MeshStandardMaterial({map:facadeTexture,color:0xb3ad9f,roughness:.95});
const weatherStain=new THREE.MeshStandardMaterial({color:0x817f75,roughness:1,transparent:true,opacity:.32,depthWrite:false});
const balconyMetal=new THREE.MeshStandardMaterial({color:0x4a5556,roughness:.58,metalness:.48});
const acMaterial=new THREE.MeshStandardMaterial({color:0xc4c5bd,roughness:.72,metalness:.22});
const facadeBoxGeo=new THREE.BoxGeometry(1,1,1);
function facadeBox(x,y,z,sx,sy,sz,mat){const m=new THREE.Mesh(facadeBoxGeo,mat);m.position.set(x,y,z);m.scale.set(sx,sy,sz);m.castShadow=false;m.receiveShadow=false;scene.add(m);return m;}
function addFacadeWindow(x,y,z,face){
 const side=face==='x'; const frame=side?[.46,.76,.055]:[.055,.76,.46];
 const glass=side?[.35,.62,.025]:[.025,.62,.35];
 facadeBox(x,y,z,...frame,windowFrame);facadeBox(x,y,z,...glass,windowGlass);
 // Central mullion and a chunky projecting sill make windows read as real building openings.
 if(side){facadeBox(x,y,z,.025,.62,.065,facadeDark);facadeBox(x,y-.405,z,.56,.07,.12,facadeLight);facadeBox(x,y+.405,z,.54,.055,.10,facadeLight);}
 else{facadeBox(x,y,z,.065,.62,.025,facadeDark);facadeBox(x,y-.405,z,.12,.07,.56,facadeLight);facadeBox(x,y+.405,z,.10,.055,.54,facadeLight);}
}
// Put windows and horizontal floor bands only on exposed wall faces, never in walkable cells.
for(let z=1;z<23;z++)for(let x=1;x<23;x++){
 if(G.map[z]?.[x]!==1)continue;
 const faces=[];
 if(G.map[z]?.[x-1]===0)faces.push('left');if(G.map[z]?.[x+1]===0)faces.push('right');
 if(G.map[z-1]?.[x]===0)faces.push('front');if(G.map[z+1]?.[x]===0)faces.push('back');
 if(!faces.length)continue;
 // Select a facade rhythm deterministically so the city doesn't look tiled or repetitive.
 const style=(x*7+z*11)%5;
 for(const face of faces){
  const px=x+.5,pz=z+.5,offset=.512;
  const wx=face==='left'?x-offset:face==='right'?x+1+offset:px;
  const wz=face==='front'?z-offset:face==='back'?z+1+offset:pz;
  const side=face==='left'||face==='right';
  // Window spacing and varied floors: some wall panels remain solid for visual variety.
  if(style!==1&&style!==4){const yy=style===2?2.45:1.65;addFacadeWindow(wx,yy,wz,side?'x':'z');if(style===0&&((x+z)%3===0))addFacadeWindow(wx,3.25,wz,side?'x':'z');}
  // Cornice / floor slab band, plus occasional pilaster.
  const bandPos=side?[wx,2.02,pz]:[px,2.02,wz];
  facadeBox(...bandPos,side?.045:0.94,.075,side?.94:.045,concreteBand);
  if(style===0){const col=side?[wx,1.9,pz]:[px,1.9,wz];facadeBox(...col,side?.07:.09,3.65,side?.09:.07,facadeLight);}
 }
}
// V21: sparse weather marks, shallow balconies and exterior AC units on selected exposed facades.
// Details are deterministic and cosmetic; they do not change collision or navigation.
for(let z=2;z<22;z++)for(let x=2;x<22;x++){
 if(G.map[z]?.[x]!==1)continue;const style=(x*13+z*5)%7;if(style!==0&&style!==3)continue;
 const candidates=[];if(G.map[z]?.[x-1]===0)candidates.push(['x',x-.525,z+.5]);if(G.map[z]?.[x+1]===0)candidates.push(['x',x+1.525,z+.5]);if(G.map[z-1]?.[x]===0)candidates.push(['z',x+.5,z-.525]);if(G.map[z+1]?.[x]===0)candidates.push(['z',x+.5,z+1.525]);
 if(!candidates.length)continue;const [face,fx,fz]=candidates[(x+z)%candidates.length];const alongX=face==='z';
 // Thin weathering streaks beneath selected window lines.
 facadeBox(fx,1.25,fz,alongX?.22:.012,.46,alongX?.012:.22,weatherStain);
 if(style===0){const sx=alongX?.52:.12,sz=alongX?.12:.52;facadeBox(fx,1.18,fz,sx,.07,sz,balconyMetal);facadeBox(fx,1.34,fz,sx,.035,sz,facadeLight);}
 else {
  const unit=facadeBox(fx,1.15,fz,alongX?.30:.16,.22,alongX?.16:.30,acMaterial);
  facadeBox(fx,1.15, fz,alongX?.20:.025,.12,alongX?.025:.20,facadeDark);
  // A tiny condenser grille gives the unit a readable mechanical face.
  for(let k=-1;k<=1;k++)facadeBox(fx+(alongX?k*.045:0),1.15,fz+(alongX?0:k*.045),alongX?.012:.025,.13,alongX?.025:.012,balconyMetal);
 }
}

// V24: varied street-facing architecture: recessed-looking entrances, lintels, steps,
// and selected chipped/broken wall edges. These are cosmetic overlays; map/collision stay intact.
const doorDark=new THREE.MeshStandardMaterial({color:0x252b2c,roughness:.98});
const doorMetal=new THREE.MeshStandardMaterial({color:0x505a59,metalness:.42,roughness:.7});
const stepMat=new THREE.MeshStandardMaterial({color:0x8c887d,roughness:.98});
for(let z=1;z<23;z++)for(let x=1;x<23;x++){
 if(G.map[z]?.[x]!==1)continue;
 const faces=[];if(G.map[z]?.[x-1]===0)faces.push(['x',x-.535,z+.5]);if(G.map[z]?.[x+1]===0)faces.push(['x',x+1.535,z+.5]);if(G.map[z-1]?.[x]===0)faces.push(['z',x+.5,z-.535]);if(G.map[z+1]?.[x]===0)faces.push(['z',x+.5,z+1.535]);
 if(!faces.length)continue;
 const [face,fx,fz]=faces[(x*5+z*3)%faces.length],alongX=face==='z';
 if((x*11+z*7)%8===0){
  facadeBox(fx,.88,fz,alongX?.48:.055,.12,alongX?.055:.48,doorDark);
  facadeBox(fx,1.39,fz,alongX?.48:.075,1.02,alongX?.075:.48,doorDark);
  facadeBox(fx,.38,fz,alongX?.58:.11,.075,alongX?.11:.58,doorMetal);
  facadeBox(fx,.10,fz,alongX?.64:.14,.10,alongX?.14:.64,stepMat);
  facadeBox(fx,1.94,fz,alongX?.62:.13,.12,alongX?.13:.62,facadeLight);
  facadeBox(fx,1.38,fz,alongX?.045:.06,.88,alongX?.06:.045,doorMetal);
 }
 if((x*13+z*17)%13===0){
  // Jagged-looking chips at a wall corner, made from a few low-poly concrete fragments.
  const chipMat=(x+z)%2?facadeDark:facadeLight;
  for(let k=0;k<3;k++){const chip=new THREE.Mesh(new THREE.DodecahedronGeometry(.10+(k%2)*.045,0),chipMat);chip.position.set(fx+(alongX?0:(k-1)*.10),2.85-k*.42,fz+(alongX?(k-1)*.10:0));chip.scale.set(alongX?.55:1,.65,alongX?1:.55);chip.rotation.set(k*.7,k*.4,k*.8);scene.add(chip);}
 }
}

// Rooftop parapets and ledges soften the block silhouette without expensive shadows.
for(let z=1;z<23;z++)for(let x=1;x<23;x++)if(G.map[z]?.[x]===1){
 if(G.map[z-1]?.[x]===0)facadeBox(x+.5,3.82,z-.035,.96,.11,.10,facadeLight);
 if(G.map[z+1]?.[x]===0)facadeBox(x+.5,3.82,z+1.035,.96,.11,.10,facadeLight);
 if(G.map[z]?.[x-1]===0)facadeBox(x-.035,3.82,z+.5,.10,.11,.96,facadeLight);
 if(G.map[z]?.[x+1]===0)facadeBox(x+1.035,3.82,z+.5,.10,.11,.96,facadeLight);
}

// V22: subtle architectural service details, recessed vent panels and roof drainage pipes.
const ventMat=new THREE.MeshStandardMaterial({color:0x555d5c,roughness:.72,metalness:.34});
for(let z=2;z<22;z++)for(let x=2;x<22;x++){
 if(G.map[z]?.[x]!==1)continue;
 const style=(x*17+z*19)%9;if(style!==2&&style!==6)continue;
 const faces=[];if(G.map[z]?.[x-1]===0)faces.push(['x',x-.53,z+.5]);if(G.map[z]?.[x+1]===0)faces.push(['x',x+1.53,z+.5]);if(G.map[z-1]?.[x]===0)faces.push(['z',x+.5,z-.53]);if(G.map[z+1]?.[x]===0)faces.push(['z',x+.5,z+1.53]);
 if(!faces.length)continue;const [face,fx,fz]=faces[(x*3+z)%faces.length],alongX=face==='z';
 facadeBox(fx,2.85,fz,alongX?.34:.035,.24,alongX?.035:.34,facadeDark);
 facadeBox(fx,2.85,fz,alongX?.27:.045,.17,alongX?.045:.27,ventMat);
 for(let n=-2;n<=2;n++)facadeBox(fx+(alongX?n*.045:0),2.85,fz+(alongX?0:n*.045),alongX?.012:.05,.16,alongX?.05:.012,windowFrame);
}
// Drain pipes on selected external corners; thin cylinders are cheap and add vertical scale cues.
const drainMat=new THREE.MeshStandardMaterial({color:0x626965,roughness:.65,metalness:.42});
for(let z=2;z<22;z+=4)for(let x=2;x<22;x+=5){if(G.map[z]?.[x]!==1)continue;if(G.map[z]?.[x-1]!==0)continue;const pipe=new THREE.Mesh(new THREE.CylinderGeometry(.022,.022,3.55,5),drainMat);pipe.position.set(x-.535,1.9,z+.5);scene.add(pipe);}

// Industrial props: crates, columns, pipes, warning stripes
for(let i=0;i<16;i++){const x=2.4+(i*7%19),z=2.6+(i*11%19);if(G.map[Math.floor(z)]?.[Math.floor(x)]!==0)continue;if(Math.hypot(x-3.5,z-3.5)<3.4)continue;
 const s=.36+(i%3)*.13;addBox(x,.35+s/2,z,s,.7+s,s,mats.crate);addBox(x,.35+s/2,z,s+.025,.035,s+.025,i%2?mats.yellow:mats.dark,false);
}
for(let z=2;z<23;z+=5){addBox(1.22,3.9,z, .09,.09,4.2,mats.dark,false);addBox(1.28,3.86,z, .025,.025,4.2,mats.trim,false);}
// Ceiling lights
for(let x=3;x<23;x+=5)for(let z=3;z<23;z+=6){addBox(x,4.48,z,.85,.035,.18,mats.trim,false);}
// V14 atmosphere: low-cost dust motes and hazard strips add depth without external assets.
const dustGeo=new THREE.BufferGeometry(),dustCount=isMobile?28:55,dustPositions=new Float32Array(dustCount*3);
for(let i=0;i<dustCount;i++){dustPositions[i*3]=1+Math.random()*22;dustPositions[i*3+1]=.25+Math.random()*3.8;dustPositions[i*3+2]=1+Math.random()*22;}
dustGeo.setAttribute('position',new THREE.BufferAttribute(dustPositions,3));
const dust=new THREE.Points(dustGeo,new THREE.PointsMaterial({color:0xe5e1c9,size:.028,transparent:true,opacity:.22,depthWrite:false}));scene.add(dust);
const hazardMat=new THREE.MeshStandardMaterial({color:0xdba64a,emissive:0x30200a,roughness:.7});
for(let z=5;z<22;z+=6){const stripe=new THREE.Mesh(new THREE.BoxGeometry(1.8,.012,.07),hazardMat);stripe.position.set(8.5,.018,z);scene.add(stripe);}
// V15: raised floor seams, wall braces and readable doorway frames give spaces stronger scale cues.
const seamMat=new THREE.MeshStandardMaterial({color:0x555b57,roughness:.95});
for(let x=2;x<23;x+=2){const seam=new THREE.Mesh(new THREE.BoxGeometry(.012,.008,21),seamMat);seam.position.set(x,.016,12);scene.add(seam);}
for(let z=2;z<23;z+=6){for(let x=2;x<22;x+=8){if(G.map[z]?.[x]===0&&G.map[z]?.[x+1]===0){addBox(x+.5,1.7,z+.04,.08,3.3,.12,mats.dark);addBox(x+1.5,1.7,z+.04,.08,3.3,.12,mats.dark);addBox(x+1,3.35,z+.04,2.1,.12,.12,mats.yellow,false);}}}

// V23: stronger street-level read using a low-cost asphalt overlay, cracks, curbs and scattered rubble.
const asphaltCanvas=document.createElement('canvas');asphaltCanvas.width=512;asphaltCanvas.height=512;
const asphaltCtx=asphaltCanvas.getContext('2d');asphaltCtx.fillStyle='#656a68';asphaltCtx.fillRect(0,0,512,512);
for(let i=0;i<7200;i++){const shade=70+Math.floor(Math.random()*55);asphaltCtx.fillStyle=`rgba(${shade},${shade+2},${shade},${Math.random()*.20})`;const r=Math.random()*1.8+.25;asphaltCtx.fillRect(Math.random()*512,Math.random()*512,r,r);}
for(let i=0;i<56;i++){const x=Math.random()*512,y=Math.random()*512;asphaltCtx.strokeStyle='rgba(35,39,38,.36)';asphaltCtx.lineWidth=1+Math.random();asphaltCtx.beginPath();asphaltCtx.moveTo(x,y);let px=x,py=y;for(let k=0;k<3;k++){px+=(Math.random()-.5)*22;py+=Math.random()*16;asphaltCtx.lineTo(px,py);}asphaltCtx.stroke();}
const asphaltTex=new THREE.CanvasTexture(asphaltCanvas);asphaltTex.anisotropy=Math.min(8,renderer.capabilities.getMaxAnisotropy());asphaltTex.wrapS=asphaltTex.wrapT=THREE.RepeatWrapping;asphaltTex.repeat.set(5,5);asphaltTex.colorSpace=THREE.SRGBColorSpace;
const asphaltMat=new THREE.MeshStandardMaterial({map:asphaltTex,color:0xb4b6b1,roughness:1,metalness:0});
const streetOverlay=new THREE.Mesh(new THREE.PlaneGeometry(23.7,23.7),asphaltMat);streetOverlay.rotation.x=-Math.PI/2;streetOverlay.position.set(12,.009,12);streetOverlay.renderOrder=1;scene.add(streetOverlay);
const crackMat=new THREE.MeshBasicMaterial({color:0x353a38,transparent:true,opacity:.58});
const curbMat=new THREE.MeshStandardMaterial({color:0x999990,roughness:.96});
// Low curb sections along selected walkable edges; visual only and deliberately below ankle height.
for(let z=3;z<22;z+=4){if(G.map[z]?.[2]===0){addBox(2.04,.055,z+.5,.10,.11,.92,curbMat,false);}if(G.map[z]?.[21]===0){addBox(21.96,.055,z+.5,.10,.11,.92,curbMat,false);}}
// Fine branching asphalt cracks and small chips are sparse to protect mobile frame time.
for(let i=0;i<20;i++){const x=2.2+(i*37%195)/10,z=2.4+(i*53%190)/10;if(G.map[Math.floor(z)]?.[Math.floor(x)]!==0)continue;const len=.18+(i%4)*.08;const crack=new THREE.Mesh(new THREE.BoxGeometry(len,.003,.012),crackMat);crack.position.set(x,.019,z);crack.rotation.y=(i*1.37)%Math.PI;scene.add(crack);}
const rubbleMats=[new THREE.MeshStandardMaterial({color:0x8a877c,roughness:1}),new THREE.MeshStandardMaterial({color:0x6d716d,roughness:1}),new THREE.MeshStandardMaterial({color:0xaaa394,roughness:1})];
for(let i=0;i<18;i++){const x=2.5+(i*29%190)/10,z=2.5+(i*41%190)/10;if(G.map[Math.floor(z)]?.[Math.floor(x)]!==0)continue;const geo=new THREE.DodecahedronGeometry(.045+(i%3)*.018,0);const bit=new THREE.Mesh(geo,rubbleMats[i%rubbleMats.length]);bit.position.set(x,.035,z);bit.rotation.set(i*.7,i*1.3,i*.4);bit.scale.set(1.3,.55,.8);scene.add(bit);}

// V15 weapon: layered receiver, handguard rails, sights, magazine, stock and metallic muzzle.
const gun=new THREE.Group();camera.add(gun);
const gunMetal=new THREE.MeshStandardMaterial({color:0x303638,metalness:.68,roughness:.38});
const gunPoly=new THREE.MeshStandardMaterial({color:0x4b514c,metalness:.32,roughness:.58});
const rubber=new THREE.MeshStandardMaterial({color:0x101518,metalness:.08,roughness:.92});
const bronze=new THREE.MeshStandardMaterial({color:0x987d52,metalness:.5,roughness:.42});
function gunBox(s,pos,mat,rot=0){const m=new THREE.Mesh(new THREE.BoxGeometry(...s),mat);m.position.set(...pos);m.rotation.z=rot;m.castShadow=true;gun.add(m);return m;}
gunBox([.24,.19,.62],[.31,-.27,-.65],gunMetal);
gunBox([.18,.13,.32],[.31,-.29,-.91],gunPoly);
gunBox([.105,.105,.43],[.31,-.22,-1.02],gunMetal);
const barrel=new THREE.Mesh(new THREE.CylinderGeometry(.028,.038,.43,16),gunMetal);barrel.rotation.x=Math.PI/2;barrel.position.set(.31,-.22,-1.24);gun.add(barrel);
const muzzle=new THREE.Mesh(new THREE.CylinderGeometry(.044,.044,.08,16),bronze);muzzle.rotation.x=Math.PI/2;muzzle.position.set(.31,-.22,-1.46);gun.add(muzzle);
gunBox([.14,.055,.49],[.31,-.15,-.69],gunPoly);
gunBox([.055,.028,.52],[.31,-.112,-.70],gunMetal);
gunBox([.14,.22,.19],[.31,-.43,-.51],rubber,-.18);
gunBox([.14,.24,.19],[.31,-.47,-.75],gunMetal,.08);
gunBox([.10,.10,.16],[.31,-.13,-.46],gunPoly);
gunBox([.06,.07,.10],[.31,-.075,-.46],mats.trim);
for(let i=0;i<5;i++)gunBox([.19,.018,.018],[.31,-.205+i*.035,-.77],rubber);
const muzzleLight=new THREE.PointLight(0xffc36c,0,2,2);muzzleLight.position.set(.31,-.22,-1.25);camera.add(muzzleLight);const muzzleFlash=new THREE.Mesh(new THREE.ConeGeometry(.09,.28,8),new THREE.MeshBasicMaterial({color:0xffc36c,transparent:true,opacity:.9}));muzzleFlash.rotation.x=-Math.PI/2;muzzleFlash.position.set(.31,-.22,-1.62);muzzleFlash.visible=false;gun.add(muzzleFlash);
const enemyObjects=new Map(),pickupObjects=new Map();
const enemyTracerMat=new THREE.LineBasicMaterial({color:0xffbd72,transparent:true,opacity:.9});let enemyTracer=null;
// V22: higher-readability tactical characters: helmet, neck, layered armor, pouches,
// knee pads, gloves, boot soles and a more detailed low-poly rifle. Geometry stays lightweight.
function enemyModel(e){
 const g=new THREE.Group(),heavy=e.type==='heavy'||e.type==='boss';
 const armorMat=heavy?new THREE.MeshStandardMaterial({color:e.type==='boss'?0x76603b:0x465461,metalness:.32,roughness:.66}):new THREE.MeshStandardMaterial({color:0x4d5650,metalness:.12,roughness:.82});
 const clothMat=new THREE.MeshStandardMaterial({color:heavy?0x343b3e:0x343b37,roughness:.96});
 const skinMat=new THREE.MeshStandardMaterial({color:0x77695b,roughness:.92});
 const strapMat=new THREE.MeshStandardMaterial({color:0x252a28,roughness:.88});
 const pouchMat=new THREE.MeshStandardMaterial({color:0x5b5a4b,roughness:.92});
 const metalMat=new THREE.MeshStandardMaterial({color:0x30383a,metalness:.62,roughness:.48});
 function part(geo,mat,pos,scale,rot){const m=new THREE.Mesh(geo,mat);m.position.set(...pos);if(scale)m.scale.set(...scale);if(rot)m.rotation.set(...rot);m.castShadow=false;m.receiveShadow=false;g.add(m);return m;}
 // Body and neck: layered shapes avoid the single capsule / toy-like silhouette.
 const body=part(new THREE.CapsuleGeometry(heavy?.25:.19,heavy?.55:.48,4,8),clothMat,[0,.88,0]);
 part(new THREE.CylinderGeometry(.075,.085,.11,8),skinMat,[0,1.25,-.005]);
 part(new THREE.BoxGeometry(heavy?.46:.37,.32,.235),armorMat,[0,1.04,-.025]);
 // Plate carrier rim and segmented front plates.
 part(new THREE.BoxGeometry(heavy?.39:.31,.12,.245),strapMat,[0,1.19,-.025]);
 for(let x of [-1,0,1])part(new THREE.BoxGeometry(.085,.105,.025),heavy?metalMat:pouchMat,[x*(heavy?.115:.09),1.045,-.153]);
 for(let x of [-1,1]){part(new THREE.BoxGeometry(.095,.13,.07),pouchMat,[x*.22,.96,-.025]);part(new THREE.BoxGeometry(.085,.09,.07),pouchMat,[x*.22,.82,-.035]);}
 // Head, helmet shell, rim, side ear cups and dark eye protection.
 part(new THREE.SphereGeometry(heavy?.155:.135,12,9),skinMat,[0,1.42,-.01]);
 part(new THREE.SphereGeometry(heavy?.17:.15,12,8,0,Math.PI*2,0,Math.PI*.62),armorMat,[0,1.475,-.015]);
 part(new THREE.BoxGeometry(.30,.035,.20),strapMat,[0,1.405,-.01]);
 part(new THREE.BoxGeometry(.18,.045,.035),new THREE.MeshStandardMaterial({color:0x222b2e,metalness:.22,roughness:.3}),[0,1.43,-.135]);
 for(const side of [-1,1])part(new THREE.CylinderGeometry(.035,.035,.035,8),strapMat,[side*.145,1.43,-.005],[1,1,1],[0,0,Math.PI/2]);
 // Shoulder armor over articulated upper arms.
 const limbs=[];
 for(const side of [-1,1]){
  // V24: limbs rotate around shoulder, elbow and hip pivots rather than their geometric centres.
  const shoulder=new THREE.Group();shoulder.position.set(side*.27,1.13,-.005);g.add(shoulder);
  part(new THREE.SphereGeometry(heavy?.13:.105,8,6),armorMat,[side*.27,1.13,-.005],[1,1,.88]);
  const upperMesh=new THREE.Mesh(new THREE.CapsuleGeometry(.065,.23,3,6),clothMat);upperMesh.position.set(side*.025,-.16,0);upperMesh.rotation.z=-side*.10;shoulder.add(upperMesh);
  const elbow=new THREE.Group();elbow.position.set(side*.03,-.29,-.055);shoulder.add(elbow);
  const foreMesh=new THREE.Mesh(new THREE.CapsuleGeometry(.055,.20,3,6),armorMat);foreMesh.position.set(0,-.105,-.025);elbow.add(foreMesh);
  const handMesh=new THREE.Mesh(new THREE.SphereGeometry(.06,7,5),strapMat);handMesh.position.set(0,-.22,-.04);elbow.add(handMesh);
  limbs.push({mesh:shoulder,side,kind:'arm'},{mesh:elbow,side,kind:'forearm'});
  const hip=new THREE.Group();hip.position.set(side*.115,.52,.005);g.add(hip);
  const legMesh=new THREE.Mesh(new THREE.CapsuleGeometry(.075,.28,3,6),clothMat);legMesh.position.set(0,-.14,0);hip.add(legMesh);
  const knee=new THREE.Mesh(new THREE.BoxGeometry(.12,.105,.055),armorMat);knee.position.set(0,-.19,-.065);hip.add(knee);
  const boot=new THREE.Group();boot.position.set(0,-.34,-.035);hip.add(boot);
  const bootMesh=new THREE.Mesh(new THREE.BoxGeometry(.145,.105,.235),strapMat);bootMesh.position.set(0,-.025,-.02);boot.add(bootMesh);
  const soleMesh=new THREE.Mesh(new THREE.BoxGeometry(.15,.025,.24),metalMat);soleMesh.position.set(0,-.075,-.02);boot.add(soleMesh);
  limbs.push({mesh:hip,side,kind:'leg'},{mesh:boot,side,kind:'boot'});
 }
 // Backpack, seams and shoulder straps.
 part(new THREE.BoxGeometry(.30,.36,.14),strapMat,[0,.91,.15]);
 part(new THREE.BoxGeometry(.23,.10,.16),pouchMat,[0,1.04,.19]);
 part(new THREE.BoxGeometry(.045,.37,.025),pouchMat,[-.10,.98,-.145]);
 part(new THREE.BoxGeometry(.045,.37,.025),pouchMat,[.10,.98,-.145]);
 if(e.type==='boss'){
  part(new THREE.BoxGeometry(.62,.17,.28),armorMat,[0,1.20,-.01]);
  part(new THREE.TorusGeometry(.19,.018,5,14),mats.yellow,[0,1.61,0]);
 }
 // V23 character pass: visible webbing, shoulder seams, elbow/knee guards and compact radio details.
 const webbingMat=new THREE.MeshStandardMaterial({color:0x252d2b,roughness:.9});
 const stitchMat=new THREE.MeshStandardMaterial({color:0x777666,roughness:.86});
 for(const side of [-1,1]){
  // Shoulder strap follows the front of the plate carrier.
  const strap=part(new THREE.BoxGeometry(.045,.29,.035),webbingMat,[side*.115,1.08,-.158]);strap.rotation.z=side*.12;
  part(new THREE.BoxGeometry(.12,.075,.035),stitchMat,[side*.31,.79,-.112]);
  // Larger faceted knee shell and boot toe cap improve the silhouette at game distance.
  part(new THREE.BoxGeometry(.135,.12,.065),armorMat,[side*.115,.39,-.067]);
  part(new THREE.BoxGeometry(.13,.055,.055),strapMat,[side*.115,.105,-.174]);
  // Small side utility pouch / radio block on the upper torso.
  if(side===1){part(new THREE.BoxGeometry(.075,.15,.075),strapMat,[.225,1.13,.015]);part(new THREE.BoxGeometry(.055,.035,.02),stitchMat,[.225,1.20,-.028]);}
 }
 // Front carrier seams and a short diagonal sling; slim parts avoid bulky toy-like proportions.
 part(new THREE.BoxGeometry(.018,.24,.018),stitchMat,[0,1.04,-.159]);
 const sling=part(new THREE.BoxGeometry(.028,.44,.022),webbingMat,[-.105,.99,-.17]);sling.rotation.z=-.35;
 // Rifle with receiver, stock, magazine, barrel, handguard and compact sight.
 const rifle=new THREE.Group();
 function gunPart(geo,mat,pos,scale){const m=new THREE.Mesh(geo,mat);m.position.set(...pos);if(scale)m.scale.set(...scale);m.castShadow=false;rifle.add(m);return m;}
 gunPart(new THREE.BoxGeometry(.09,.085,.34),metalMat,[.20,.91,-.23]);
 gunPart(new THREE.BoxGeometry(.07,.075,.17),strapMat,[.20,.91,.035]);
 gunPart(new THREE.BoxGeometry(.075,.15,.075),metalMat,[.20,.80,-.22]);
 gunPart(new THREE.CylinderGeometry(.014,.014,.27,7),metalMat,[.20,.93,-.52],null).rotation.x=Math.PI/2;
 gunPart(new THREE.BoxGeometry(.105,.06,.18),clothMat,[.20,.93,-.39]);
 gunPart(new THREE.BoxGeometry(.07,.055,.075),strapMat,[.20,1.0,-.22]);
 gunPart(new THREE.BoxGeometry(.035,.035,.07),mats.dark,[.20,1.045,-.22]);
 // V23: visible front sight, barrel collar and compact optic on the enemy weapon.
 gunPart(new THREE.BoxGeometry(.035,.035,.055),metalMat,[.20,1.005,-.47]);
 gunPart(new THREE.BoxGeometry(.055,.045,.075),strapMat,[.20,1.055,-.29]);
 gunPart(new THREE.BoxGeometry(.018,.035,.025),metalMat,[.20,1.093,-.29]);
 const slingEnd=gunPart(new THREE.BoxGeometry(.018,.018,.19),pouchMat,[.15,.80,-.08]);slingEnd.rotation.x=-.18;
 g.add(rifle);g.userData.rifle=rifle;g.userData.limbs=limbs;g.userData.body=body;scene.add(g);return g;
}
function pickupModel(p){const g=new THREE.Group();const mat=p.type==='ammo'?mats.ammo:mats.med;const a=new THREE.Mesh(new THREE.BoxGeometry(.28,.28,.28),mat);a.castShadow=false;g.add(a);const ring=new THREE.Mesh(new THREE.TorusGeometry(.25,.025,6,20),mat);ring.rotation.x=Math.PI/2;g.add(ring);scene.add(g);return g;}
function resize3d(){camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();const v=qualityParams(renderQuality);renderer.setPixelRatio(v.dpr);renderer.setSize(innerWidth,innerHeight,false);}
window.set3DQuality=applyQuality;
applyQuality('performance');
window.addEventListener('resize',resize3d);
window.render3D=function(){const now=performance.now(),params=qualityParams(renderQuality);if(now-lastRenderAt<1000/params.fps)return;lastRenderAt=now;const p=G.player;camera.position.set(p.x/64,.86+Math.sin(p.walk)*.025,p.y/64);camera.rotation.set(0,-p.dir-Math.PI/2,0);camera.rotation.y=-p.dir-Math.PI/2;const movingBob=Math.sin(p.walk)*.012;gun.position.y=movingBob-Math.max(0,p.recoil)*.07;gun.position.x=Math.sin(p.walk*.5)*.009;gun.rotation.x=-Math.max(0,p.recoil)*.13+Math.sin(p.walk)*.008;gun.rotation.z=Math.sin(p.walk*.5)*.012;const firingNow=window.ShadowGame.flash>0;muzzleLight.intensity=firingNow?10:0;muzzleFlash.visible=firingNow;
 const active=new Set();for(const e of G.enemies){if(!e.alive)continue;active.add(e);let o=enemyObjects.get(e);if(!o){o=enemyModel(e);enemyObjects.set(e,o);}o.position.set(e.x/64,0,e.y/64);o.rotation.y=Math.atan2(e.x-p.x,e.y-p.y);if(o.userData.rifle){o.userData.rifle.rotation.x=Math.sin(e.phase*1.7)*.035+(e.shooting?Math.sin(now*.045)*.012:0);o.userData.rifle.rotation.z=Math.sin(e.phase*.85)*.012;}o.position.y=Math.abs(Math.sin(e.phase*1.7))*.025+Math.sin(now*.002+e.phase)*.003;const moving=!G.trainingMode&&Math.hypot(p.x-e.x,p.y-e.y)>75;const gait=moving?Math.sin(e.phase*1.7):0;const firing=e.shooting?1:0;for(const limb of o.userData.limbs||[]){if(limb.kind==='leg'){limb.mesh.rotation.x=gait*.48;limb.mesh.rotation.z=limb.side*.025;}else if(limb.kind==='boot'){limb.mesh.rotation.x=-gait*.12;}else if(limb.kind==='arm'){limb.mesh.rotation.x=(moving?gait*.18:0)-firing*.16;limb.mesh.rotation.z=limb.side*(.10+firing*.045);}else if(limb.kind==='forearm'){limb.mesh.rotation.x=(moving?-Math.max(0,gait)*.22:0)-firing*.12;limb.mesh.rotation.z=limb.side*.035;}}if(o.userData.body){o.userData.body.rotation.x=-firing*.035+Math.sin(now*.002+e.phase)*.006;o.userData.body.rotation.z=moving?Math.sin(e.phase*1.7)*.025:0;}if(e.type==='boss'&&o.userData.body)o.userData.body.material.emissive.setHex(Math.sin(performance.now()*.006)>0?0x251000:0x080400);}
 for(const [e,o] of enemyObjects)if(!active.has(e)){scene.remove(o);enemyObjects.delete(e);}
 const activeP=new Set();for(const pick of G.pickups){if(!pick.alive)continue;activeP.add(pick);let o=pickupObjects.get(pick);if(!o){o=pickupModel(pick);pickupObjects.set(pick,o);}o.position.set(pick.x/64,.48+Math.sin(performance.now()*.002+pick.x)*.07,pick.y/64);o.rotation.y=performance.now()*.0008;}
 for(const [pick,o] of pickupObjects)if(!activeP.has(pick)){scene.remove(o);pickupObjects.delete(pick);}
 dust.rotation.y=now*.000018;
 if(G.enemyShot&&G.enemyShot.until>now){if(enemyTracer)scene.remove(enemyTracer);const pts=[new THREE.Vector3(G.enemyShot.x/64,.98,G.enemyShot.y/64),new THREE.Vector3(p.x/64,.78,p.y/64)];enemyTracer=new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),enemyTracerMat);scene.add(enemyTracer);}else if(enemyTracer){scene.remove(enemyTracer);enemyTracer.geometry.dispose();enemyTracer=null;}
 renderer.render(scene,camera);
};
window.addEventListener('webglcontextlost',e=>{e.preventDefault();console.warn('WebGL context lost');});
})();
