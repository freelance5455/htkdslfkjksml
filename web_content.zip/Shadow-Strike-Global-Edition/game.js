/* SHADOW STRIKE V16 — mobile-first performance edition with adaptive 3D rendering. */
(() => {
'use strict';
const canvas=document.getElementById('gameCanvas'),ctx=canvas.getContext('2d',{alpha:false});
// V14 bridge: the same gameplay simulation feeds the optional Three.js renderer.
window.ShadowGame={map:null,player:null,get enemies(){return enemies},get pickups(){return pickups},get flash(){return flash},use3D:false};

const $=id=>document.getElementById(id);
const TAU=Math.PI*2, TILE=64, FOV=Math.PI/3, MAP_N=24;
let W=innerWidth,H=innerHeight,zBuffer=[],last=0,raf=0,started=false,paused=true,gameOver=false,trainingMode=false;
let quality='performance',sensitivity=1,soundEnabled=true,audioCtx=null;
let score=0,wave=1,kills=0,shotsFired=0,shotsHit=0,shake=0,flash=0,messageTimer=0,moveX=0,moveY=0,lookX=0,firing=false,impactFlash=0;
let bestScore=0,bestWave=1;
let armor=0;
// V12: a short temporal phase-shift ability (a 4D-inspired gameplay illusion).
let phaseTime=0,phaseCooldown=0,phasePulse=0;
// V13: tactical rift scan reveals hostile positions briefly through cover.
let scanTime=0,scanCooldown=0,scanPulse=0,ambientSurge=0;
let weaponMode=0; // 0 assault rifle, 1 precision pistol
try{const record=JSON.parse(localStorage.getItem("ss-v17-record")||"{}");bestScore=Number(record.bestScore)||0;bestWave=Number(record.bestWave)||1}catch(_){}
const map=[
[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
[1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
[1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
[1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
[1,0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
[1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
[1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
[1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
[1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
[1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
[1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
[1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
[1,1,1,1,1,1,1,1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,1],
[1,0,0,0,0,0,0,1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,1],
[1,0,0,0,0,0,0,1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,1],
[1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,1],
[1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
[1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
[1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
[1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
[1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
[1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
[1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]];
const player={x:3.5*TILE,y:3.5*TILE,dir:0,health:100,speed:170,ammo:12,reserve:60,mag:12,cool:0,reload:0,recoil:0,walk:0,damageFlash:0,weapon:0};
const keys={};let enemies=[],pickups=[];
window.ShadowGame.map=map;window.ShadowGame.player=player;

function resize(){const cap=quality==='performance'?1:quality==='balanced'?1.4:2;const dpr=Math.min(devicePixelRatio||1,cap);W=innerWidth;H=innerHeight;canvas.width=Math.round(W*dpr);canvas.height=Math.round(H*dpr);ctx.setTransform(dpr,0,0,dpr,0,0);zBuffer=new Array(Math.ceil(W/2)).fill(99);}
addEventListener('resize',resize);resize();
function norm(a){while(a<-Math.PI)a+=TAU;while(a>Math.PI)a-=TAU;return a}
function open(x,y){const gx=Math.floor(x/TILE),gy=Math.floor(y/TILE);return !!(map[gy]&&map[gy][gx]===0)}
function wallBetween(x1,y1,x2,y2){const n=Math.ceil(Math.hypot(x2-x1,y2-y1)/10);for(let i=1;i<n;i++){const t=i/n;if(!open(x1+(x2-x1)*t,y1+(y2-y1)*t))return true}return false}
function spawnWave(){enemies=[];const count=trainingMode?7:Math.min(3+wave*2,18);let tries=0;while(enemies.length<count&&tries++<300){const gx=2+Math.floor(Math.random()*20),gy=2+Math.floor(Math.random()*20),x=(gx+.5)*TILE,y=(gy+.5)*TILE;if(!open(x,y)||Math.hypot(x-player.x,y-player.y)<TILE*5||enemies.some(e=>Math.hypot(e.x-x,e.y-y)<TILE*2))continue;const bossWave=!trainingMode&&wave%5===0;const isBoss=bossWave&&enemies.length===0;const roll=Math.random();const type=trainingMode?'soldier':(isBoss?'boss':(wave>=3&&roll<.18?'heavy':roll<Math.min(.15+wave*.025,.4)?'runner':'soldier'));const hp=trainingMode?1:type==='boss'?12:type==='heavy'?5:type==='runner'?2:2+Math.floor(wave/3);enemies.push({x,y,type,health:hp,maxHealth:hp,alive:true,attack:Math.random()*1.5,stun:0,phase:Math.random()*TAU})} $('wave').textContent=wave;showMessage(trainingMode?'تمرین تیراندازی — هدف‌ها را بزن':wave%5===0?'⚠ BOSS WAVE '+wave:'WAVE '+wave+' INCOMING',2.2);$('mission').textContent=trainingMode?`هدف‌های تمرینی: ${enemies.length}`:wave%5===0?'هدف ویژه: فرمانده زرهی را حذف کن':`پاک‌سازی منطقه: ${enemies.length} دشمن`}
function showMessage(s,t=1.2){$('centerMessage').textContent=s;$('centerMessage').style.opacity=1;messageTimer=t}
function tone(freq=140,duration=.055,type='square',volume=.035){if(!soundEnabled)return;try{audioCtx=audioCtx||new (window.AudioContext||window.webkitAudioContext)();if(audioCtx.state==='suspended')audioCtx.resume();const o=audioCtx.createOscillator(),g=audioCtx.createGain();o.type=type;o.frequency.setValueAtTime(freq,audioCtx.currentTime);o.frequency.exponentialRampToValueAtTime(Math.max(35,freq*.45),audioCtx.currentTime+duration);g.gain.setValueAtTime(volume,audioCtx.currentTime);g.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+duration);o.connect(g);g.connect(audioCtx.destination);o.start();o.stop(audioCtx.currentTime+duration)}catch(_){}}
function fire(){if(!started||paused||gameOver)return;if(player.reload>0)return;if(player.cool>0)return;if(player.ammo<=0){showMessage('خشاب خالی — RELOAD',.8);return}player.ammo--;shotsFired++;player.cool=weaponMode===0?.22:.34;player.recoil=weaponMode===0?1:.72;shake=weaponMode===0?2:1.2;flash=.07;tone(weaponMode===0?115:190,.075,'sawtooth',.045);let target=null,best=Infinity;
for(const e of enemies){if(!e.alive)continue;const d=Math.hypot(e.x-player.x,e.y-player.y),a=norm(Math.atan2(e.y-player.y,e.x-player.x)-player.dir);const tolerance=Math.max(.055,(weaponMode===0?.22:.16)/(d/TILE));if(Math.abs(a)<tolerance&&d<best&&!wallBetween(player.x,player.y,e.x,e.y)){target=e;best=d}}
if(target){shotsHit++;tone(620,.045,'triangle',.025);impactFlash=.12;target.health-=weaponMode===0?1:2;target.stun=target.type==='boss'?.08:.22;score+=target.type==='boss'?25:10;if(target.health<=0){target.alive=false;kills++;score+=90;if(Math.random()<.34){const roll=Math.random();pickups.push({x:target.x,y:target.y,type:roll<.40?'ammo':roll<.78?'med':'armor',alive:true})}showMessage('HOSTILE DOWN  +100',.65)}else showMessage('HIT',.3)}updateHUD()}
function switchWeapon(){weaponMode=weaponMode===0?1:0;player.cool=0;showMessage(weaponMode===0?'VX-12 ASSAULT':'PX-9 PRECISION',.9);const name=$('weaponName');if(name)name.textContent=weaponMode===0?'VX-12 / ASSAULT':'PX-9 / PRECISION';}
function reload(){if(!started||paused||player.reload>0||player.ammo===player.mag||player.reserve<=0)return;player.reload=weaponMode===0?1.05:.82;tone(260,.08,'triangle',.025);showMessage('RELOADING…',.7)}
function updateHUD(){$('bestScore').textContent=String(bestScore).padStart(4,'0');$('hp').textContent=Math.max(0,Math.ceil(player.health));$('healthfill').style.width=Math.max(0,player.health)+'%';const armorEl=$('armorValue');if(armorEl)armorEl.textContent=String(Math.ceil(armor));$('ammo').textContent=player.ammo;$('reserve').textContent=player.reserve;$('weaponName').textContent=weaponMode===0?'VX-12 / ASSAULT':'PX-9 / PRECISION';$('score').textContent=String(score).padStart(4,'0');$('mission').textContent=trainingMode?`هدف‌های باقی‌مانده: ${enemies.filter(e=>e.alive).length}`:`دشمنان باقی‌مانده: ${enemies.filter(e=>e.alive).length}`}
function hurt(n){const absorbed=Math.min(armor,n*.65);armor=Math.max(0,armor-absorbed);player.health=Math.max(0,player.health-(n-absorbed));player.damageFlash=.25;shake=4;updateHUD();if(player.health<=0)endGame(false)}
function update(dt){if(paused||!started||gameOver)return;dt=Math.min(dt,.04);phaseTime=Math.max(0,phaseTime-dt);phaseCooldown=Math.max(0,phaseCooldown-dt);phasePulse=Math.max(0,phasePulse-dt);scanTime=Math.max(0,scanTime-dt);scanCooldown=Math.max(0,scanCooldown-dt);scanPulse=Math.max(0,scanPulse-dt);ambientSurge=Math.max(0,ambientSurge-dt);if(Math.random()<dt*.11)ambientSurge=.25+Math.random()*.45;updatePhaseButton();updateScanButton();player.cool=Math.max(0,player.cool-dt);player.recoil=Math.max(0,player.recoil-dt*5);flash=Math.max(0,flash-dt);shake=Math.max(0,shake-dt*12);player.damageFlash=Math.max(0,player.damageFlash-dt);impactFlash=Math.max(0,impactFlash-dt);if(messageTimer>0&&(messageTimer-=dt)<=0)$('centerMessage').style.opacity=0;
if(player.reload>0&&(player.reload-=dt)<=0){const n=Math.min(player.mag-player.ammo,player.reserve);player.ammo+=n;player.reserve-=n;updateHUD()}
let turn=0,forward=0,strafe=0;if(keys.ArrowLeft||keys.KeyQ)turn-=1;if(keys.ArrowRight||keys.KeyE)turn+=1;forward+=(keys.KeyW||keys.ArrowUp)?1:0;forward-=(keys.KeyS||keys.ArrowDown)?1:0;strafe+=(keys.KeyD)?1:0;strafe-=(keys.KeyA)?1:0;
player.dir+=turn*2.3*dt+lookX;lookX=0;if(firing&&player.cool<=0)fire();forward+=-moveY;strafe+=moveX;
const mag=Math.hypot(forward,strafe)||1,run=keys.ShiftLeft||keys.ShiftRight?1.45:1,speed=player.speed*run*dt;
if(forward||strafe){const f=forward/mag*speed,s=strafe/mag*speed;const dx=Math.cos(player.dir)*f-Math.sin(player.dir)*s,dy=Math.sin(player.dir)*f+Math.cos(player.dir)*s;const rad=13;if(open(player.x+dx+Math.sign(dx)*rad,player.y))player.x+=dx;if(open(player.x,player.y+dy+Math.sign(dy)*rad))player.y+=dy;player.walk+=dt*12}
for(const e of enemies){if(!e.alive)continue;const enemyDt=phaseTime>0?dt*.28:dt;e.phase+=enemyDt*4;if(e.stun>0){e.stun-=enemyDt;continue}const dx=player.x-e.x,dy=player.y-e.y,d=Math.hypot(dx,dy),a=Math.atan2(dy,dx);if(trainingMode)continue;/* Enemies now fire at range instead of draining health continuously on contact. */if(d>TILE*2.2){const sp=(e.type==='runner'?54:e.type==='boss'?18:e.type==='heavy'?20:26)*(1+wave*.018)*enemyDt,nx=e.x+Math.cos(a)*sp,ny=e.y+Math.sin(a)*sp;if(d>TILE*4.2&&open(nx,e.y)&&!enemies.some(o=>o!==e&&o.alive&&Math.hypot(o.x-nx,o.y-e.y)<22))e.x=nx;if(d>TILE*4.2&&open(e.x,ny))e.y=ny;}e.attack-=enemyDt;if(e.attack<=0&&d<TILE*8&&!wallBetween(e.x,e.y,player.x,player.y)){if(phaseTime<=0){hurt(e.type==='boss'?7:e.type==='heavy'?5:3);window.ShadowGame.enemyShot={x:e.x,y:e.y,until:performance.now()+140};}e.attack=(e.type==='boss'?1.65:2.0)+Math.random()*.9;}if(d<TILE*1.05&&e.attack<=.15){/* a close-range hit is possible, but never every frame */if(phaseTime<=0)hurt(2);e.attack=.8;}}
for(const p of pickups){if(!p.alive||Math.hypot(p.x-player.x,p.y-player.y)>TILE*.6)continue;p.alive=false;if(p.type==='ammo'){player.reserve=Math.min(180,player.reserve+24);showMessage('AMMO +24')}else if(p.type==='armor'){const gained=Math.min(50,100-armor);armor+=gained;showMessage(gained>0?'ARMOR +'+Math.round(gained):'ARMOR FULL')}else{const gained=Math.min(25,100-player.health);player.health+=gained;showMessage(gained>0?'MEDKIT +'+Math.round(gained):'HEALTH FULL')}updateHUD()}
if(enemies.length&&enemies.every(e=>!e.alive)){if(trainingMode){showMessage('تمرین کامل شد! 🎯',2);paused=true;$('pauseBtn').textContent='▶';return}wave++;player.health=Math.min(100,player.health+12);player.reserve=Math.min(180,player.reserve+12);player.ammo=player.mag;spawnWave();updateHUD()}}
function drawBackground(){
 const sky=ctx.createLinearGradient(0,0,0,H*.58);
 sky.addColorStop(0,'#030711');sky.addColorStop(.35,'#0b1c2b');sky.addColorStop(.72,'#1c3a48');sky.addColorStop(1,'#536064');
 ctx.fillStyle=sky;ctx.fillRect(0,0,W,H*.54);
 // distant industrial skyline silhouettes
 for(let i=0;i<18;i++){const bw=W/13, bx=i*W/17, bh=H*(.035+((i*37)%11)/100);ctx.fillStyle=i%3===0?'#102532':'#091722';ctx.fillRect(bx,H*.49-bh,bw,bh);ctx.fillStyle='#55d9d122';for(let j=0;j<3;j++)ctx.fillRect(bx+bw*(.18+j*.24),H*.49-bh+8,bw*.06,Math.max(2,bh*.18))}
 // atmospheric haze near the horizon
 const haze=ctx.createLinearGradient(0,H*.35,0,H*.64);haze.addColorStop(0,'#4ac6d000');haze.addColorStop(.75,'#70c8c51c');haze.addColorStop(1,'#0a151d00');ctx.fillStyle=haze;ctx.fillRect(0,H*.32,W,H*.32);
 const floor=ctx.createLinearGradient(0,H/2,0,H);floor.addColorStop(0,'#29383b');floor.addColorStop(.32,'#202c31');floor.addColorStop(1,'#03070c');ctx.fillStyle=floor;ctx.fillRect(0,H/2,W,H/2);
 // perspective floor grid and illuminated seams
 ctx.strokeStyle='#9adbd51b';ctx.lineWidth=1;for(let i=1;i<19;i++){const y=H/2+(i/19)**2*H/2;ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke()}
 for(let i=-10;i<=10;i++){ctx.beginPath();ctx.moveTo(W/2,H/2);ctx.lineTo(W/2+i*W/10,H);ctx.stroke()}
 // worn concrete: perspective joints, damp patches, grit and reflected industrial lights
 for(let i=0;i<10;i++){const y=H*.58+i*i*H*.0035;ctx.fillStyle=i%2?'#64d9d410':'#f7b85b0c';ctx.fillRect((i*173)%Math.max(1,W),y,W*(.04+(i%4)*.025),1+i*.22)}
 ctx.save();ctx.beginPath();ctx.rect(0,H*.52,W,H*.48);ctx.clip();
 for(let i=0;i<22;i++){const depth=.54+((i*17)%43)/100;const y=H*depth;const x=((i*137)%Math.max(1,W));const ww=(W*.008+(i%4)*W*.004)*(depth*depth);const hh=Math.max(1,H*.0015*(i%3+1)*depth);ctx.fillStyle=i%5===0?'#8b9b9818':'#02070a24';ctx.fillRect(x,y,ww,hh);}
 // irregular shallow puddles with muted reflections
 for(let i=0;i<7;i++){const x=(i*211+W*.07)%W,y=H*(.67+(i%4)*.075),rw=W*(.018+(i%3)*.012),rh=Math.max(2,H*.003);ctx.fillStyle=i%2?'#74aeb31b':'#d6c8a20e';ctx.beginPath();ctx.ellipse(x,y,rw,rh,(i%3-.8)*.12,0,TAU);ctx.fill();ctx.strokeStyle='#b4d6d40b';ctx.lineWidth=1;ctx.beginPath();ctx.ellipse(x,y,rw*.72,rh*.55,0,0,TAU);ctx.stroke();}
 // fine concrete seams converge toward the vanishing point
 ctx.strokeStyle='#050a0d35';ctx.lineWidth=1;for(let i=0;i<8;i++){const yy=H*(.59+i*.052);ctx.beginPath();ctx.moveTo(0,yy);ctx.lineTo(W,yy+((i%3)-1)*H*.008);ctx.stroke()}
 ctx.restore();
 // suspended smoke wisps near the horizon
 const t=performance.now()*.00003;for(let i=0;i<4;i++){const x=(W*(.12+i*.23)+Math.sin(t+i)*W*.025);const y=H*(.39+(i%2)*.055);const r=ctx.createRadialGradient(x,y,1,x,y,W*.12);r.addColorStop(0,'#a5b7b51a');r.addColorStop(1,'#8fa9b000');ctx.fillStyle=r;ctx.fillRect(x-W*.12,y-W*.05,W*.24,H*.1)}
}
function renderWalls(){const step=1,cols=Math.ceil(W/step);for(let i=0;i<cols;i++){const x=i*step,ra=player.dir-FOV/2+(x/W)*FOV,rx=Math.cos(ra),ry=Math.sin(ra);let mx=Math.floor(player.x/TILE),my=Math.floor(player.y/TILE),ddx=Math.abs(1/rx),ddy=Math.abs(1/ry),sx,sy,sdx,sdy;if(rx<0){sx=-1;sdx=(player.x/TILE-mx)*ddx}else{sx=1;sdx=(mx+1-player.x/TILE)*ddx}if(ry<0){sy=-1;sdy=(player.y/TILE-my)*ddy}else{sy=1;sdy=(my+1-player.y/TILE)*ddy}
let side=0,hit=false,dist=24;while(!hit&&Math.min(sdx,sdy)<dist){if(sdx<sdy){sdx+=ddx;mx+=sx;side=0}else{sdy+=ddy;my+=sy;side=1}if(mx<0||my<0||mx>=MAP_N||my>=MAP_N){hit=true;dist=24}else if(map[my][mx]){hit=true;dist=side===0?(mx-player.x/TILE+(1-sx)/2)/rx:(my-player.y/TILE+(1-sy)/2)/ry}}
const corrected=Math.max(.1,dist*Math.cos(ra-player.dir));zBuffer[Math.min(zBuffer.length-1,Math.floor(x/2))]=corrected;const wh=Math.min(H*2,H/corrected),top=H/2-wh/2;const shade=Math.max(14,Math.floor(190-corrected*7-(side?34:0)));const stripe=((mx*7+my*11)%4===0)?12:0;ctx.fillStyle=`rgb(${Math.max(0,shade-16+stripe)},${Math.max(0,shade-3+stripe)},${Math.max(0,shade+8+stripe)})`;ctx.fillRect(x,top,step+1,wh);
 // industrial wall panel seams and occasional amber hazard markings
 const u=(side===0?player.y/TILE+dist*ry:player.x/TILE+dist*rx)%1;
 if(u<.025){ctx.fillStyle='#02060a70';ctx.fillRect(x,top,step+1,wh)}
 if((mx+my)%7===0&&u>.16&&u<.22){ctx.fillStyle='#ffc76b55';ctx.fillRect(x,top+wh*.72,step+1,Math.max(2,wh*.025))}
 if((mx*3+my)%9===0&&u>.48&&u<.5){ctx.fillStyle='#55f6e533';ctx.fillRect(x,top+wh*.18,step+1,Math.max(2,wh*.12))}
 ctx.fillStyle='#d6f6f01a';ctx.fillRect(x,top,step+1,Math.max(1,wh*.018));
 // layered metallic wall panels, emissive strips and warning bands
 if(wh>70){const panel=(Math.floor(u*8)%4);if(panel===0){ctx.fillStyle='#07121b55';ctx.fillRect(x,top+wh*.16,step+1,wh*.34)}if(panel===2){ctx.fillStyle='#b9d6dc12';ctx.fillRect(x,top+wh*.22,step+1,wh*.012);ctx.fillRect(x,top+wh*.62,step+1,wh*.012)}}
 if((mx*5+my*3)%13===0&&u>.25&&u<.29){ctx.fillStyle='#ffbd5944';ctx.fillRect(x,top+wh*.3,step+1,Math.max(2,wh*.035))}
 if(wh>38){ctx.fillStyle='#0003';for(let yy=top+wh*.2;yy<top+wh;yy+=Math.max(14,wh*.18))ctx.fillRect(x,yy,step+1,1)}
 // deterministic concrete stains, chipped edges and bolt marks add texture without image assets
 if(wh>90){const grime=((mx*13+my*7+Math.floor(u*31))%9);if(grime===0){ctx.fillStyle='#03080b35';ctx.fillRect(x,top+wh*(.24+u*.2),step+1,wh*.13)}if(grime===3){ctx.fillStyle='#a9b9b912';ctx.fillRect(x,top+wh*.48,step+1,Math.max(1,wh*.008))}if(u>.08&&u<.095){ctx.fillStyle='#02060966';ctx.fillRect(x,top+wh*.12,step+1,wh*.76)}}
 if(wh>130&&((mx+my)%5===0)){ctx.fillStyle='#111a1d';ctx.fillRect(x,top+wh*.08,step+1,Math.max(1,wh*.012));ctx.fillRect(x,top+wh*.9,step+1,Math.max(1,wh*.01))}}}
function drawEnemies(){const list=enemies.filter(e=>e.alive).map(e=>({...e,a:norm(Math.atan2(e.y-player.y,e.x-player.x)-player.dir),d:Math.hypot(e.x-player.x,e.y-player.y)})).filter(e=>Math.abs(e.a)<FOV*.72&&e.d>10).sort((a,b)=>b.d-a.d);for(const e of list){const sx=(.5+e.a/FOV)*W,size=Math.min(H*1.1,H*.76/(e.d/TILE));if(sx<0||sx>=W||e.d/TILE>zBuffer[Math.min(zBuffer.length-1,Math.floor(sx/2))])continue;const bob=Math.sin(e.phase)*size*.018,cy=H/2+size*.07+bob,x=sx-size*.18,y=cy-size*.38;
ctx.save();ctx.translate(sx,0);ctx.shadowColor=e.type==='boss'?'#ffc76b':e.type==='heavy'?'#b18cff':e.type==='runner'?'#ff4b5e':'#e45c47';ctx.shadowBlur=e.type==='boss'?22:12;// layered tactical silhouette: helmet, visor, plate carrier, pouches, arms, rifle and boots
ctx.fillStyle='#101820';ctx.fillRect(-size*.19,y+size*.49,size*.15,size*.30);ctx.fillRect(size*.045,y+size*.49,size*.15,size*.30);
ctx.fillStyle='#263b43';ctx.fillRect(-size*.215,y+size*.73,size*.19,size*.055);ctx.fillRect(size*.035,y+size*.73,size*.19,size*.055);
ctx.fillStyle=e.type==='boss'?'#8a5724':e.type==='heavy'?'#55456e':e.type==='runner'?'#762b37':'#40534d';const bodyScale=e.type==='boss'?1.28:e.type==='heavy'?1.12:1;ctx.fillRect(-size*.18*bodyScale,y+size*.22,size*.36*bodyScale,size*.35);
ctx.fillStyle='#17272c';ctx.fillRect(-size*.145,y+size*.25,size*.29,size*.25);ctx.fillStyle='#9aab9c';ctx.globalAlpha=.28;ctx.fillRect(-size*.13,y+size*.27,size*.26,size*.035);ctx.globalAlpha=1;
ctx.fillStyle='#263a40';ctx.fillRect(-size*.245,y+size*.25,size*.09,size*.28);ctx.fillRect(size*.155,y+size*.25,size*.09,size*.28);
ctx.fillStyle='#b28b68';ctx.fillRect(-size*.105,y+size*.035,size*.21,size*.19);ctx.fillStyle='#1a2529';ctx.fillRect(-size*.14,y-size*.005,size*.28,size*.085);ctx.fillStyle='#37484a';ctx.beginPath();ctx.ellipse(0,y+size*.025,size*.15,size*.085,0,Math.PI,TAU);ctx.fill();
ctx.fillStyle='#071219';ctx.fillRect(-size*.12,y+size*.085,size*.24,size*.045);ctx.fillStyle=e.type==='boss'?'#ffc76b':e.type==='heavy'?'#c7a6ff':'#ff514d';ctx.fillRect(-size*.075,y+size*.098,size*.045,size*.018);ctx.fillRect(size*.03,y+size*.098,size*.045,size*.018);
ctx.fillStyle='#111c22';for(let q=0;q<3;q++)ctx.fillRect(-size*.12+q*size*.085,y+size*.34,size*.055,size*.07);
ctx.fillStyle='#0b1218';ctx.fillRect(size*.04,y+size*.31,size*.31,size*.055);ctx.fillRect(size*.29,y+size*.295,size*.055,size*.085);ctx.fillStyle='#718087';ctx.fillRect(size*.13,y+size*.30,size*.13,size*.018);ctx.restore();
if(e.health<e.maxHealth){ctx.fillStyle='#17212b';ctx.fillRect(sx-size*.22,y-10,size*.44,5);ctx.fillStyle=e.type==='boss'?'#ffc76b':e.type==='heavy'?'#b18cff':'#ff5367';ctx.fillRect(sx-size*.22,y-10,size*.44*(e.health/e.maxHealth),5)}}}
function drawPickups(){for(const p of pickups){if(!p.alive)continue;const a=norm(Math.atan2(p.y-player.y,p.x-player.x)-player.dir),d=Math.hypot(p.x-player.x,p.y-player.y);if(Math.abs(a)>FOV/2||d<10)continue;const sx=(.5+a/FOV)*W;if(d/TILE>zBuffer[Math.min(zBuffer.length-1,Math.floor(sx/2))])continue;const s=Math.max(5,Math.min(24,180/(d/TILE)));ctx.fillStyle=p.type==='ammo'?'#55f6e5':p.type==='armor'?'#ffc76b':'#7cff9b';ctx.shadowColor=ctx.fillStyle;ctx.shadowBlur=14;ctx.fillRect(sx-s/2,H/2-s/2,s,s);ctx.shadowBlur=0}}
function drawWeapon(){const bob=Math.sin(player.walk)*4,rx=player.recoil*14;ctx.save();ctx.translate(W*.53,H*.94+bob+rx);ctx.rotate(-.04);ctx.fillStyle='#101820';ctx.beginPath();ctx.moveTo(-W*.105,0);ctx.lineTo(-W*.075,-H*.17);ctx.lineTo(-W*.025,-H*.22);ctx.lineTo(W*.035,-H*.22);ctx.lineTo(W*.08,-H*.08);ctx.lineTo(W*.1,0);ctx.closePath();ctx.fill();ctx.fillStyle='#344a59';ctx.fillRect(-W*.025,-H*.27,W*.05,H*.16);
 // receiver, barrel, optic, rail and textured grip
 ctx.fillStyle='#0a1119';ctx.fillRect(-W*.018,-H*.29,W*.036,H*.17);ctx.fillStyle='#71828b';ctx.fillRect(-W*.014,-H*.265,W*.028,H*.018);
 ctx.fillStyle='#182630';ctx.fillRect(-W*.012,-H*.34,W*.024,H*.075);ctx.fillStyle='#05090d';ctx.fillRect(-W*.009,-H*.345,W*.018,H*.045);
 ctx.fillStyle='#243c49';ctx.fillRect(-W*.043,-H*.17,W*.022,H*.12);ctx.fillStyle='#070d12';for(let i=0;i<5;i++)ctx.fillRect(-W*.041,-H*.16+i*H*.018,W*.018,H*.004);
 ctx.fillStyle='#55f6e5';ctx.globalAlpha=.6;ctx.fillRect(-W*.005,-H*.27,W*.01,H*.08);ctx.globalAlpha=.35;ctx.fillRect(-W*.03,-H*.205,W*.06,H*.006);ctx.restore();if(flash>0){ctx.fillStyle=`rgba(255,203,99,${flash*10})`;ctx.beginPath();ctx.moveTo(W*.53,H*.67);ctx.lineTo(W*.49,H*.57);ctx.lineTo(W*.53,H*.48);ctx.lineTo(W*.57,H*.57);ctx.closePath();ctx.fill()}}
function drawMinimap(){const s=Math.min(4.2,W/95),mw=MAP_N*s,mh=MAP_N*s,x=W-mw-12,y=H-mh-12;ctx.fillStyle='#06101bd9';ctx.fillRect(x-5,y-5,mw+10,mh+10);for(let j=0;j<MAP_N;j++)for(let i=0;i<MAP_N;i++){ctx.fillStyle=map[j][i]?'#45606a':'#13232d';ctx.fillRect(x+i*s,y+j*s,s-.4,s-.4)}for(const e of enemies)if(e.alive){ctx.fillStyle=e.type==='boss'?'#ffc76b':e.type==='heavy'?'#b18cff':'#ff5367';ctx.fillRect(x+e.x/TILE*s-1.5,y+e.y/TILE*s-1.5,e.type==='boss'?5:3,e.type==='boss'?5:3)}ctx.fillStyle='#55f6e5';ctx.beginPath();ctx.arc(x+player.x/TILE*s,y+player.y/TILE*s,3,0,TAU);ctx.fill();ctx.strokeStyle='#55f6e5';ctx.beginPath();ctx.moveTo(x+player.x/TILE*s,y+player.y/TILE*s);ctx.lineTo(x+(player.x+Math.cos(player.dir)*TILE)/TILE*s,y+(player.y+Math.sin(player.dir)*TILE)/TILE*s);ctx.stroke()}
function drawAtmosphere(){
 // drifting embers / rain streaks are deterministic and inexpensive
 const now=performance.now();
 for(let i=0;i<48;i++){const x=((i*197+now*(.018+(i%4)*.009))%(W+30))-15;const y=((i*83+now*(.055+(i%5)*.012))%(H*.78));ctx.strokeStyle=i%7===0?'#ffc76b38':'#9dd9e51b';ctx.lineWidth=i%7===0?1.4:1;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x-3,y+7+(i%5)*2);ctx.stroke()}
 // dusty air catches the overhead lights; small particles drift at different depths
 for(let i=0;i<34;i++){const x=((i*149+now*(.009+(i%5)*.003))%(W+20))-10;const y=((i*71+now*(.012+(i%4)*.004))%(H*.76));const r=i%9===0?1.7:.7;ctx.fillStyle=i%9===0?'#ffc76b55':'#c4d8d51c';ctx.beginPath();ctx.arc(x,y,r,0,TAU);ctx.fill()}
 // cinematic vignette
 const v=ctx.createRadialGradient(W*.5,H*.47,Math.min(W,H)*.18,W*.5,H*.5,Math.max(W,H)*.72);
 v.addColorStop(0,'#00000000');v.addColorStop(.68,'#02060a24');v.addColorStop(1,'#010308c9');ctx.fillStyle=v;ctx.fillRect(0,0,W,H);
 // subtle chromatic HUD-like edge glow
 ctx.fillStyle='#55f6e506';ctx.fillRect(0,0,W,2);ctx.fillRect(0,H-2,W,2);
}
function drawRiftScan(){
 const now=performance.now();
 // Subtle volumetric shafts and flickering industrial lamps add changing environmental light.
 ctx.save();ctx.globalCompositeOperation='screen';
 for(let i=0;i<4;i++){const x=W*(.13+i*.245)+Math.sin(now*.00035+i*2)*W*.025;const alpha=.018+(ambientSurge*.025);const beam=ctx.createLinearGradient(x,0,x+W*.075,H*.64);beam.addColorStop(0,`rgba(255,190,105,${alpha*1.8})`);beam.addColorStop(1,'rgba(255,190,105,0)');ctx.fillStyle=beam;ctx.beginPath();ctx.moveTo(x-3,0);ctx.lineTo(x+W*.075,H*.62);ctx.lineTo(x-W*.02,H*.62);ctx.closePath();ctx.fill()}
 if(scanTime>0||scanPulse>0){const strength=scanTime>0?Math.min(1,scanTime*1.7):scanPulse*2;const radius=Math.max(W,H)*(.08+(1-strength)*.7);ctx.strokeStyle=`rgba(76,255,218,${.16+strength*.5})`;ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(W*.5,H*.51,radius,radius*.55,0,0,TAU);ctx.stroke();ctx.strokeStyle=`rgba(76,255,218,${.12+strength*.22})`;ctx.lineWidth=1;for(let i=0;i<3;i++){ctx.beginPath();ctx.ellipse(W*.5,H*.51,radius*(.55+i*.22),radius*(.3+i*.12),0,0,TAU);ctx.stroke()}
  // World-space targets are projected to screen; scan intentionally reveals them through walls.
  for(const e of enemies){if(!e.alive)continue;const a=norm(Math.atan2(e.y-player.y,e.x-player.x)-player.dir);if(Math.abs(a)>FOV*.75)continue;const d=Math.hypot(e.x-player.x,e.y-player.y),sx=(.5+a/FOV)*W,sz=Math.min(H*.55,H*.42/(d/TILE));const sy=H*.5-sz*.55;ctx.strokeStyle=e.type==='boss'?`rgba(255,193,94,${.65+strength*.3})`:`rgba(69,255,215,${.5+strength*.35})`;ctx.lineWidth=e.type==='boss'?3:2;ctx.strokeRect(sx-sz*.22,sy-sz*.12,sz*.44,sz*.75);ctx.fillStyle=ctx.strokeStyle;ctx.font='bold 10px system-ui';ctx.textAlign='center';ctx.fillText(e.type==='boss'?'HOSTILE // PRIORITY':'HOSTILE',sx,sy-8);}
 }
 ctx.restore();
}
function render(){ctx.save();if(shake>0)ctx.translate((Math.random()-.5)*shake*2,(Math.random()-.5)*shake*2);drawBackground();renderWalls();drawPickups();drawEnemies();drawWeapon();drawMinimap();drawAtmosphere();drawRiftScan();if(phaseTime>0||phasePulse>0){const strength=phaseTime>0?Math.min(1,phaseTime*1.6):phasePulse*2;ctx.save();ctx.globalCompositeOperation='screen';ctx.fillStyle=`rgba(39,226,255,${.045+strength*.06})`;ctx.fillRect(0,0,W,H);ctx.globalCompositeOperation='lighter';ctx.strokeStyle=`rgba(91,244,255,${.14+strength*.24})`;ctx.lineWidth=1;for(let i=0;i<7;i++){const y=((i*97+performance.now()*.22)%H);ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y-18);ctx.stroke()}ctx.fillStyle=`rgba(75,240,255,${.06+strength*.06})`;ctx.fillRect(0,0,W,3);ctx.restore();}const cx=W/2,cy=H/2;ctx.strokeStyle=player.cool>0?'#ffc76b':'#eaffff';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(cx-10,cy);ctx.lineTo(cx-4,cy);ctx.moveTo(cx+4,cy);ctx.lineTo(cx+10,cy);ctx.moveTo(cx,cy-10);ctx.lineTo(cx,cy-4);ctx.moveTo(cx,cy+4);ctx.lineTo(cx,cy+10);ctx.stroke();if(impactFlash>0){ctx.strokeStyle='#ffdf85';ctx.lineWidth=2.5;ctx.beginPath();ctx.moveTo(cx-13,cy-13);ctx.lineTo(cx-6,cy-6);ctx.moveTo(cx+13,cy-13);ctx.lineTo(cx+6,cy-6);ctx.moveTo(cx-13,cy+13);ctx.lineTo(cx-6,cy+6);ctx.moveTo(cx+13,cy+13);ctx.lineTo(cx+6,cy+6);ctx.stroke()}if(player.damageFlash>0){ctx.fillStyle=`rgba(255,40,70,${player.damageFlash*1.4})`;ctx.fillRect(0,0,W,H)}ctx.restore()}
function loop(t){const dt=Math.min(.05,(t-last)/1000||0);last=t;update(dt);if(typeof window.render3D==='function'&&window.ShadowGame&&window.ShadowGame.use3D)window.render3D();else render();raf=requestAnimationFrame(loop)}
function start(isTraining=false){window.ShadowGame.use3D=typeof window.render3D==='function'&&!!window.THREE;if(!window.ShadowGame.use3D){showMessage('3D unavailable — classic renderer',1.6)}trainingMode=isTraining;score=0;kills=0;shotsFired=0;shotsHit=0;wave=1;pickups=[];player.x=3.5*TILE;player.y=3.5*TILE;player.dir=0;player.health=100;armor=0;player.ammo=12;player.mag=12;player.reserve=60;weaponMode=0;player.cool=0;player.reload=0;phaseTime=0;phaseCooldown=0;phasePulse=0;scanTime=0;scanCooldown=0;scanPulse=0;started=true;paused=false;gameOver=false;$('startScreen').style.display='none';$('endScreen').style.display='none';spawnWave();updateHUD()}
function endGame(win){gameOver=true;paused=true;const previous=bestScore;if(score>bestScore)bestScore=score;if(wave>bestWave)bestWave=wave;try{localStorage.setItem('ss-v17-record',JSON.stringify({bestScore,bestWave}))}catch(_){}$('bestScore').textContent=String(bestScore).padStart(4,'0');$('endScreen').style.display='flex';$('endTitle').textContent=win?'عملیات موفق':'عملیات پایان یافت';const accuracy=shotsFired?Math.round(shotsHit/shotsFired*100):0;$('endText').textContent=`${trainingMode?'تمرین':'عملیات'} به پایان رسید. آمار کامل پایین صفحه است.`;$('finalScore').textContent=score;$('finalKills').textContent=kills;$('finalWave').textContent=wave;$('recordMessage').textContent=score>previous?'🏆 رکورد جدید ثبت شد!':`دقت شلیک: ${accuracy}% · بهترین رکورد: ${bestScore}`;$('againBtn').textContent='تلاش دوباره';}
function updatePhaseButton(){const b=$('phaseShift');if(!b)return;if(phaseTime>0){b.textContent='PHASE '+phaseTime.toFixed(1)+'s';b.style.opacity='1';b.style.borderColor='#72f7ff';}else if(phaseCooldown>0){b.textContent='CHARGE '+Math.ceil(phaseCooldown)+'s';b.style.opacity='.62';b.style.borderColor='#ffffff45';}else{b.textContent='PHASE SHIFT';b.style.opacity='1';b.style.borderColor='#55f6e5';}}
function activatePhase(){if(!started||paused||gameOver)return;if(phaseCooldown>0||phaseTime>0){showMessage(phaseTime>0?'PHASE ACTIVE':'هسته فاز در حال شارژ است',.7);return;}phaseTime=2.8;phaseCooldown=13;phasePulse=.9;shake=Math.max(shake,1.4);tone(420,.16,'sine',.04);showMessage('◈ TEMPORAL PHASE — TIME DILATED',1.25);updatePhaseButton();}
function updateScanButton(){const b=$('riftScan');if(!b)return;if(scanTime>0){b.textContent='SCAN '+scanTime.toFixed(1)+'s';b.style.borderColor='#55f6e5';b.style.opacity='1'}else if(scanCooldown>0){b.textContent='SCAN '+Math.ceil(scanCooldown)+'s';b.style.borderColor='#ffffff45';b.style.opacity='.62'}else{b.textContent='RIFT SCAN';b.style.borderColor='#55f6e5';b.style.opacity='1'}}
function activateScan(){if(!started||paused||gameOver)return;if(scanCooldown>0||scanTime>0){showMessage(scanTime>0?'اهداف در حال اسکن هستند':'اسکن در حال شارژ است',.7);return}scanTime=4.2;scanCooldown=18;scanPulse=1;shake=Math.max(shake,.8);tone(660,.22,'sine',.035);showMessage('◉ RIFT SCAN — HOSTILES REVEALED',1.3);updateScanButton()}
$('riftScan').addEventListener('pointerdown',e=>{e.preventDefault();activateScan()});
$('phaseShift').addEventListener('pointerdown',e=>{e.preventDefault();activatePhase()});
$('startBtn').addEventListener('click',()=>start(false));$('trainingBtn').addEventListener('click',()=>start(true));$('againBtn').addEventListener('click',()=>start(trainingMode));
$('howBtn').addEventListener('click',()=>alert('موبایل: جوی‌استیک پایین چپ برای حرکت، سمت راست صفحه را بکشید تا بچرخید، FIRE برای شلیک و RELOAD برای خشاب.\\nکامپیوتر: W/A/S/D حرکت، فلش‌ها چرخش، کلیک شلیک، R خشاب، Shift دویدن.'));
$('pauseBtn').addEventListener('click',()=>{if(!started||gameOver)return;paused=!paused;$('pauseBtn').textContent=paused?'▶':'Ⅱ';if(paused)showMessage('PAUSED',99);else{$('centerMessage').style.opacity=0}});
addEventListener('keydown',e=>{keys[e.code]=true;if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Space'].includes(e.code))e.preventDefault();if(e.code==='KeyR')reload();if(e.code==='KeyX')activatePhase();if(e.code==='KeyC')activateScan();if(e.code==='Digit1'&&started&&!paused){weaponMode=0;showMessage('VX-12 ASSAULT',.7)}if(e.code==='Digit2'&&started&&!paused){weaponMode=1;showMessage('PX-9 PRECISION',.7)}if(e.code==='Escape'&&started&&!gameOver){paused=!paused;$('pauseBtn').textContent=paused?'▶':'Ⅱ'}});
addEventListener('keyup',e=>keys[e.code]=false);addEventListener('blur',()=>{if(started&&!gameOver){paused=true;$('pauseBtn').textContent='▶'}});
// V17 FIX: Three.js canvas sits above the hidden 2D canvas. Listen on document
// and only capture gestures that start on the active WebGL canvas.
let rightTouch=null,lastX=0;const isWorldTarget=e=>e.target&&e.target.id==='world3d';
document.addEventListener('pointerdown',e=>{if(!started||paused||!isWorldTarget(e))return;if(e.pointerType==='mouse'){fire();return;}if(e.clientX>W*.42){rightTouch=e.pointerId;lastX=e.clientX;e.preventDefault();try{e.target.setPointerCapture(e.pointerId)}catch(_){}}},{passive:false});
document.addEventListener('pointermove',e=>{if(e.pointerId===rightTouch){const dx=e.clientX-lastX;lookX+=dx*.0045*sensitivity;lastX=e.clientX;e.preventDefault()}},{passive:false});
const endLook=e=>{if(e.pointerId===rightTouch)rightTouch=null};document.addEventListener('pointerup',endLook);document.addEventListener('pointercancel',endLook);
const stick=$('stick'),knob=$('knob');let stickId=null,stickCenter={x:0,y:0};stick.addEventListener('pointerdown',e=>{stickId=e.pointerId;stick.setPointerCapture(e.pointerId);const r=stick.getBoundingClientRect();stickCenter={x:r.left+r.width/2,y:r.top+r.height/2};moveStick(e)});function moveStick(e){const dx=e.clientX-stickCenter.x,dy=e.clientY-stickCenter.y,m=Math.min(38,Math.hypot(dx,dy)),a=Math.atan2(dy,dx),x=Math.cos(a)*m,y=Math.sin(a)*m;knob.style.transform=`translate(${x}px,${y}px)`;moveX=x/38;moveY=y/38}stick.addEventListener('pointermove',e=>{if(e.pointerId===stickId)moveStick(e)});function resetStick(){stickId=null;moveX=moveY=0;knob.style.transform='translate(0,0)'}stick.addEventListener('pointerup',resetStick);stick.addEventListener('pointercancel',resetStick);
$('fire').addEventListener('pointerdown',e=>{e.preventDefault();firing=true;fire();try{$('fire').setPointerCapture(e.pointerId)}catch(_){}});const stopFire=()=>{firing=false};$('fire').addEventListener('pointerup',stopFire);$('fire').addEventListener('pointercancel',stopFire);$('fire').addEventListener('lostpointercapture',stopFire);$('reload').addEventListener('pointerdown',e=>{e.preventDefault();reload()});const weaponBtn=$('weaponSwitch');if(weaponBtn)weaponBtn.addEventListener('pointerdown',e=>{e.preventDefault();switchWeapon()});const sprint=$('sprint');sprint.addEventListener('pointerdown',e=>{e.preventDefault();keys.ShiftLeft=true;sprint.setPointerCapture(e.pointerId)});const stopSprint=()=>{keys.ShiftLeft=false};sprint.addEventListener('pointerup',stopSprint);sprint.addEventListener('pointercancel',stopSprint);sprint.addEventListener('lostpointercapture',stopSprint);
const settingsScreen=$('settingsScreen');
function openSettings(){settingsScreen.style.display='flex';$('qualitySelect').value=quality;$('sensSlider').value=Math.round(sensitivity*100);$('sensValue').textContent=Math.round(sensitivity*100)+'%';$('soundToggle').checked=soundEnabled}
$('settingsBtn').addEventListener('click',openSettings);
$('closeSettingsBtn').addEventListener('click',()=>settingsScreen.style.display='none');
$('sensSlider').addEventListener('input',e=>$('sensValue').textContent=e.target.value+'%');
$('saveSettingsBtn').addEventListener('click',()=>{quality=$('qualitySelect').value;sensitivity=Number($('sensSlider').value)/100;soundEnabled=$('soundToggle').checked;try{localStorage.setItem('ss-v17-settings',JSON.stringify({quality,sensitivity,soundEnabled}))}catch(_){}settingsScreen.style.display='none';resize();if(typeof window.set3DQuality==='function')window.set3DQuality(quality);showMessage('تنظیمات ذخیره شد ✓',1.2)});
try{const saved=JSON.parse(localStorage.getItem('ss-v16-settings')||'null');if(saved){quality=['high','balanced','performance'].includes(saved.quality)?saved.quality:'performance';sensitivity=Math.max(.5,Math.min(1.8,Number(saved.sensitivity)||1));soundEnabled=saved.soundEnabled!==false}}catch(_){}
resize();if(typeof window.set3DQuality==='function')window.set3DQuality(quality);updateHUD();updatePhaseButton();updateScanButton();requestAnimationFrame(loop);
})();