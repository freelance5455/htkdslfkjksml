Chattha Heart & Medical Center, M.B. Din — Offline Daily Closing
PIN: 594113
No Google account/cloud required.
Records are stored on the phone.
Export Backup creates a JSON backup; Import Backup restores it.
Build the APK with Android Studio: Build > Build APK(s).
