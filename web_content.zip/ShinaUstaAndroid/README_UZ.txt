# Shina Usta — Android ilova loyihasi

Bu loyiha mavjud HTML kalkulyatorni Android ilovasiga (WebView) o‘raydi.
Telegram yoki serverga ulanish yo‘q. Kalkulyator oflayn ishlaydi va chekni Android
chop etish oynasi orqali PDF sifatida saqlash mumkin.

## APK yig‘ish (Android Studio orqali)

1. Kompyuterga Android Studio va JDK 17 o‘rnating.
2. Android Studio → Open → `ShinaUstaAndroid` papkasini tanlang.
3. Gradle sync tugashini kuting. Android SDK Platform 35 so‘ralsa, SDK Manager orqali o‘rnating.
4. Menyudan Build → Build Bundle(s) / APK(s) → Build APK(s) ni bosing.
5. APK odatda `app/build/outputs/apk/debug/app-debug.apk` ichida hosil bo‘ladi.
6. APK faylni telefonga ko‘chirib, oching. Telefon sozlamasida ushbu manbadan ilova o‘rnatishga ruxsat berish so‘ralishi mumkin.

## Ilova ichida
- Har bir xizmat miqdori alohida kiritiladi.
- Bir nechta shina o‘lchamini bitta buyurtmaga qo‘shish mumkin.
- Narxlar mavjud HTML prays-listidan olinadi.
- PDF chek Android print oynasi orqali saqlanadi.

## Muhim
Bu ZIP Android Studio manba loyihasidir, oldindan kompilyatsiya qilingan APK emas.
APK olish uchun yuqoridagi build amallarini bajarish kerak. Android SDK/Gradle muhiti
bo‘lmagan sababli bu muhitda haqiqiy APK kompilyatsiya qilinmadi.
