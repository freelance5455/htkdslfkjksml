Partners Diary — APK Forge HTML package

Use index.html as the WebView/HTML source.

Included:
- Existing Partners Diary V5 interface and offline storage
- Call action
- Separate WhatsApp and WhatsApp Business Android intent handlers
- Existing follow-up, appointment, backup/restore and recruitment features

Important:
- The HTML package does not itself guarantee notifications when the APK is completely closed.
- For closed-app appointment/follow-up alerts, the APK Forge product must explicitly support native scheduled/local notifications and expose that capability to the WebView.
