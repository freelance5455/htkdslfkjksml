import os
from dotenv import load_dotenv

load_dotenv()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "").strip()
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash").strip()
PORT = int(os.getenv("PORT", "8765"))
LANGUAGE_HINT = "Reply in the same language as the user. Understand English and Hindi; use simple Hinglish when the user does."
