BUILD THE APK (needs Node.js + Android Studio)
1. Unzip this folder, open a terminal inside it.
2. npm install
3. npm run setup
4. npm run open   (opens Android Studio)
5. In Android Studio: Build > Build Bundle(s)/APK(s) > Build APK(s)
APK location: android/app/build/outputs/apk/debug/app-debug.apk
Admin PIN: 1234
