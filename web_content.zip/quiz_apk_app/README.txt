QUIZ DE RACIOCÍNIO — 13 DESAFIOS

Abra index.html no navegador para usar.

No Android, você pode abrir a página pelo navegador e usar “Adicionar à tela inicial” para ficar com aparência de aplicativo.

Observação: este pacote é um app web/PWA. Ele ainda não é um APK compilado.
