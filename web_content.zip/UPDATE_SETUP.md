# نظام التحديثات

التطبيق بيفحص كل مرة يفتح فيها عن ملف JSON على:
`https://xgaming-api-1scl-production.up.railway.app/api/app-update`

لازم السيرفر يرجع JSON بالشكل ده:
```json
{
  "versionCode": 3,
  "versionName": "1.2",
  "apkUrl": "https://example.com/XGaming-1.2.apk",
  "notes": "إصلاحات وتحسينات"
}
```

لما `versionCode` على السيرفر يكون أكبر من النسخة المثبتة، يظهر للمستخدم إشعار داخل التطبيق، ثم يتم تنزيل APK وفتح شاشة تثبيته.

مهم: Android العادي لا يسمح للتطبيق بتثبيت تحديث بصمت من نفسه؛ سيظهر تأكيد التثبيت من النظام. أول مرة فقط قد يطلب السماح لهذا التطبيق بتثبيت ملفات APK من مصادر غير معروفة.

غيّر `UPDATE_JSON_URL` في `MainActivity.kt` لو هتستخدم رابط API مختلف.
