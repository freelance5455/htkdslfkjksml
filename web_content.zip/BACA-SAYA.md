# Orbit PKL Studio (aplikasi)

Aplikasi pembuat laporan Prakerin. Setelah dipasang, ia terbuka seperti aplikasi biasa
(tanpa bilah alamat) dan tetap bisa dipakai tanpa internet.

## Isi folder
- `index.html` : aplikasi
- `manifest.webmanifest` : nama, ikon, dan warna aplikasi
- `sw.js` : penyimpan offline (service worker)
- `icons/` : ikon aplikasi

## Cara memasang
Aplikasi hanya bisa dipasang bila dibuka lewat alamat web (http atau https).
Membuka `index.html` langsung dari folder tetap berfungsi sebagai halaman biasa,
tetapi tombol Pasang aplikasi dan mode offline tidak aktif.

**Cara 1: unggah gratis (paling mudah).** Unggah seluruh isi folder ini ke Netlify Drop
(app.netlify.com/drop), GitHub Pages, atau Cloudflare Pages. Buka alamat yang diberikan
dari ponsel atau komputer, lalu ketuk **Pasang aplikasi** di pojok kanan atas.

**Cara 2: coba di komputer sendiri.** Di dalam folder ini jalankan
`python -m http.server 8000`, lalu buka `http://localhost:8000` di Chrome atau Edge.

- Android: Chrome, menu titik tiga, lalu Pasang aplikasi.
- iPhone atau iPad: Safari, ketuk Bagikan, lalu Tambah ke Layar Utama.
- Komputer: ikon pasang di ujung kanan bilah alamat Chrome atau Edge.

## Memperbarui aplikasi
Setelah mengganti `index.html`, ubah angka versi di baris pertama `sw.js`
(misalnya `orbit-pkl-v2`) lalu unggah ulang. Pengguna akan melihat pesan
"Pembaruan aplikasi siap" dan cukup memuat ulang.

## Membuat berkas APK untuk Android
Setelah aplikasi berada di alamat https, buka pwabuilder.com, masukkan alamatnya,
lalu pilih paket Android.

## Catatan
- Data laporan tersimpan di perangkat masing-masing (penyimpanan browser), tidak dikirim ke server.
- Font tampilan dimuat dari Google Fonts saat pertama online, lalu disimpan untuk dipakai offline.
