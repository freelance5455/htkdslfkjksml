# TradeSignal AI V4.6.6 — Potential Internal Autopsy v2 — touch/error fix

Android WebView laboratory. Single action button: AUTÓPSIA INTERNA DO POTENCIAL.

Runs automatically:
1. Potential weight ±15 / ±10 / ±5 / 0
2. Threshold 1.00x / 1.10x / 1.25x / 1.50x
3. Final causal matrix across 3K/5K/15K and H3/H5/H10/H20

Reference remains V4.6.6, cost 0.240%, official threshold 1.25x. No real orders.


Fix v2: the simplified single-button screen no longer calls the legacy disableButtons() routine, which referenced removed controls and caused “Cannot read properties of null (reading 'value')”. The WebView project is ready to compile; this environment does not include Gradle, so no APK binary is included.
