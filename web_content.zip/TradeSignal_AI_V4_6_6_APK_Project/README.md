# TradeSignal AI — APK Project Base V4.6.6

## Objetivo
Projeto Android para empacotar o laboratório/motor V4.6.6 em um APK instalável.

## Regra de preservação
O arquivo `app/src/main/assets/tradesignal_v4_6_6.html` é a cópia de referência do V4.6.6.
A camada Android apenas abre esse arquivo em WebView. Não há alteração no motor de sinais.

## Próxima etapa
Compilar com Android Studio/Gradle em um ambiente que tenha Android SDK 35.

## Versão
4.6.6 — motor de referência congelado.

## Observação
Este projeto é a estrutura de compilação; o APK binário precisa ser gerado por um ambiente Android com SDK/Gradle.
