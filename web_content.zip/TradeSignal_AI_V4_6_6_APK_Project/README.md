# TradeSignal AI V4.6.6 — Autópsia Interna do Potential v3

Projeto Android WebView do laboratório diagnóstico.

## Correção v3
- Corrigido o erro `Cannot read properties of null (reading 'value')`.
- O laboratório agora usa `BTCUSDT` e `5m` como padrão quando os controles de ativo/intervalo não estão presentes.
- Mantido o botão único `AUTÓPSIA INTERNA DO POTENCIAL`.
- Mantida a referência V4.6.6 congelada, custo ida/volta 0,240% e limiar oficial 1,25×.
- Sem envio de ordens.

## Execução
O APK pode ser compilado em um ambiente Android/Gradle. Este pacote é o projeto-fonte; não inclui APK compilado.
