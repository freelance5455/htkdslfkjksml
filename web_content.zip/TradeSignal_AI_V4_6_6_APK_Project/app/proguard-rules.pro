# V4.6.6 engine is kept as an asset and is not minified by Android.
