# V46 — Excel Import File Picker Callback Fix

Based directly on V45. Root cause found in V45: the Android asset HTML used a WebView file input while MainActivity did not install a WebChromeClient, so Android could show the file picker but had no callback path back into the WebView.

V46 fixes this by:
- Installing a WebChromeClient with onShowFileChooser and a dedicated callback request code.
- Returning the selected Uri to WebView file inputs when the picker is used through that route.
- Making the Android asset Choose File control an explicit button that calls AndroidDPM.pickImportFile() first, with browser file-input fallback.
- Preserving the direct native Android picker/parser/import flow used in V45.
- Preserving Download Excel Template and all existing app/Supabase logic.
