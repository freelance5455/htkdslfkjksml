#!/system/bin/sh
MODPATH="${0%/*}"

wait_until_login() {
    until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 2; done
    until [ -d "/sdcard/Android" ]; do sleep 1; done
}

write() {
    local file="$1" value="$2"
    [ -z "$file" ] || [ -z "$value" ] || [ ! -f "$file" ] && return 1
    echo "$value" > "$file" 2>/dev/null && log_msg "WRITE $file = $value"
}

HARDWARE="$(getprop ro.hardware)"
SOC_MODEL="$(getprop ro.soc.model)"
PLATFORM="$(getprop ro.board.platform)"
CHIPSET="UNKNOWN"

case "$HARDWARE$SOC_MODEL$PLATFORM" in
    *mt*|*MT*|*helio*|*dimensity*) CHIPSET="MTK"        ;;
    *qcom*|*sm*|*sdm*|*msm*)       CHIPSET="SNAPDRAGON"  ;;
    *exynos*|*s5e*|*universal*)    CHIPSET="EXYNOS"      ;;
    *ums*|*sc*|*tiger*)            CHIPSET="UNISOC"      ;;
    *gs*|*zuma*|*tensor*)          CHIPSET="TENSOR"      ;;
esac

wait_until_login

if command -v cmd >/dev/null 2>&1; then
    cmd notification post -S bigtext -t '𝗞𝗿𝘆𝘁𝗲𝘅 𝗥𝗮𝘁𝗲.' "kry_$(date +%s)" 'Touch optimization in progress...' >/dev/null 2>&1 &
fi

resetprop ro.input.noresample 1
resetprop windowsmgr.max_events_per_sec 300
resetprop view.touch_slop 1
resetprop ro.min_pointer_dur 0
resetprop touch.distance.scale 0
resetprop view.scroll_friction 10
resetprop ro.min.fling_velocity 160
resetprop ro.max.fling_velocity 25000

resetprop debug.input.enable_game_mode 1
resetprop persist.vendor.touch.game_mode 1
resetprop ro.vendor.touch_sensitivity 1
resetprop persist.sys.miui.touch_catch_miss 0

for tp in \
    /sys/devices/virtual/touchscreen/touchscreen \
    /sys/class/touch/touch_dev \
    /sys/devices/platform/goodix_ts.0 \
    /sys/devices/platform/goodix_ts \
    /sys/class/sec/tsp \
    /proc/touchpanel
do
    [ -d "$tp" ] || continue
    write "$tp/report_rate"        "1"
    write "$tp/up_rate"            "1"
    write "$tp/game_switch_enable" "1"
    write "$tp/panel_mode"         "1"
    write "$tp/edge_limit"         "0"
    write "$tp/glove_mode"         "1"
    write "$tp/debug_level"        "0"
done

case "$CHIPSET" in
    MTK)
        write "/proc/touchpanel/game_switch_enable"     "1"
        write "/proc/touchpanel/oplus_tp_limit_enable"  "0"
        write "/proc/touchpanel/oplus_tp_direction"     "1"
        write "/proc/touchpanel/report_rate_white_list" "1"
        write "/sys/kernel/ged/hal/touch_boost"         "1"
        ;;

    SNAPDRAGON)
        for syn in /sys/bus/i2c/drivers/synaptics_dsx*/*; do
            [ -d "$syn" ] || continue
            write "$syn/0d_threshold"      "10"
            write "$syn/no_sleep_settings" "1"
            write "$syn/reporting_mode"    "0"
            write "$syn/wakeup_gesture"    "0"
        done
        for gti in /sys/bus/spi/devices/*/input/input*; do
            [ -d "$gti" ] || continue
            write "$gti/report_rate_curr" "240"
            write "$gti/game_mode"        "1"
        done
        write "/sys/module/msm_performance/parameters/touchboost" "1"
        ;;

    EXYNOS)
        for sec in /sys/class/sec/tsp /sys/class/sec/sec_touchscreen; do
            [ -d "$sec" ] || continue
            write "$sec/sensitivity_mode"  "1"
            write "$sec/report_rate"       "1"
            write "$sec/ear_detect_enable" "0"
            echo "set_game_mode,1" > "$sec/cmd" 2>/dev/null
        done
        ;;

    UNISOC)
        for ums in /sys/class/touchscreen /sys/bus/i2c/devices/*-0038 /sys/bus/i2c/devices/*-0020; do
            [ -d "$ums" ] || continue
            write "$ums/game_mode"     "1"
            write "$ums/report_rate"   "1"
            write "$ums/glove_mode"    "1"
            write "$ums/edge_suppress" "0"
        done
        ;;

    TENSOR)
        for gti in /sys/devices/platform/10090000.hsi2c/i2c-*/*/gti.0 /sys/class/touch/touch_dev; do
            [ -d "$gti" ] || continue
            write "$gti/scan_mode"        "0"
            write "$gti/report_rate_curr" "240"
            write "$gti/game_mode"        "1"
            write "$gti/sensing_mode"     "0"
        done
        resetprop persist.vendor.google.touch_prediction 0
        ;;
esac

for PROC in "inputflinger" "system_server"; do
    for pid in $(pgrep -f "$PROC"); do
        ionice -c 1 -n 0 -p "$pid" >/dev/null 2>&1
        log_msg "Priority boosted: $PROC (pid $pid)"
    done
done

write "/sys/module/drm/parameters/debug" "0"
for debug_node in /sys/devices/virtual/touchscreen/*/debug_level /sys/class/touch/touch_dev/debug_level /sys/class/sec/tsp/debug_level; do
    write "$debug_node" "0"
done

if command -v cmd >/dev/null 2>&1; then
    cmd notification post -S bigtext -t '𝗞𝗿𝘆𝘁𝗲𝘅 𝗥𝗮𝘁𝗲.' "kry_$(date +%s)" 'Extreme Touch & Low Latency Injected. Zero Delay Enabled.' >/dev/null 2>&1 &
fi

sync
exit 0