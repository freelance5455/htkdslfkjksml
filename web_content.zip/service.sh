#!/system/bin/sh

MODDIR="${0%/*}"
case "$0" in
    */*) MODDIR="${0%/*}" ;;
    *) MODDIR="$(pwd 2>/dev/null || echo /data/adb/modules/Switchmat)" ;;
esac

CONFIG="$MODDIR/config.conf"

. "$MODDIR/lib/props.sh"

echo $$ > "$MODDIR/monitor.pid" 2>/dev/null

LOG_TAG="VULKAN_ENGINE"
LOG_FILE="/data/local/tmp/vulkan_engine.log"
CURRENT_MODE=""
LAST_PACKAGE=""
LAST_CFG_MTIME=""

log_msg() {
    local msg="$(date '+%Y-%m-%d %H:%M:%S') - $1"
    local sz=0
    if [ -f "$LOG_FILE" ]; then
        sz=$(wc -c < "$LOG_FILE" 2>/dev/null)
        if [ -n "$sz" ] && [ "$sz" -gt 524288 ] 2>/dev/null; then
            mv -f "$LOG_FILE" "$LOG_FILE.old" 2>/dev/null
        fi
    fi
    log -t "$LOG_TAG" "$msg" 2>/dev/null
    echo "$msg" >> "$LOG_FILE" 2>/dev/null
}

read_auto_render() {
    AUTO_RENDER=1
    local line=""
    line=$(grep -E "^AUTO_RENDER=" "$CONFIG" 2>/dev/null | tail -n 1)
    [ -n "$line" ] && AUTO_RENDER="${line#*=}"
}

apply_mode() {
    local mode="$1"
    apply_all
    if [ "$mode" = "vk" ]; then
        apply_render_mode game
    else
        apply_render_mode normal
    fi
}

write_state() {
    local mode="$1" pkg="$2"
    echo "$mode" > "$MODDIR/current_mode" 2>/dev/null
    [ -n "$pkg" ] && echo "$pkg" > "$MODDIR/last_focus" 2>/dev/null
}

config_changed() {
    local m=""
    m=$(stat -c '%Y' "$CONFIG" 2>/dev/null)
    [ -z "$m" ] && return 1
    [ "$m" = "$LAST_CFG_MTIME" ] && return 1
    LAST_CFG_MTIME="$m"
    return 0
}

if command -v renice >/dev/null 2>&1; then
    renice -n 19 -p $$ 2>/dev/null
fi

log_msg "═══ HYPERVULKAN SWITCHER v3.2.1 iniciado ═══"
log_msg "Dispositivo: $(get_prop ro.product.model)"

apply_mode gl
CURRENT_MODE=normal
write_state normal ""
log_msg "Modo inicial: GL/stock (aplicado de inmediato)"

sleep 15

while true; do
    if config_changed; then
        if [ "$CURRENT_MODE" = "vulkan" ]; then
            apply_mode vk
        else
            apply_mode gl
        fi
        log_msg "Config cambiado -> reaplicado ($CURRENT_MODE)"
    fi

    read_auto_render

    if [ "$AUTO_RENDER" != "1" ]; then
        if [ "$CURRENT_MODE" != "normal" ]; then
            apply_mode gl
            CURRENT_MODE=normal
            write_state normal ""
            log_msg "Auto-render desactivado -> GL/stock"
        fi
        sleep 6
        continue
    fi

    PKG=$(current_package)

    if [ -z "$PKG" ]; then
        if [ "$CURRENT_MODE" != "normal" ]; then
            apply_mode gl
            CURRENT_MODE=normal
            log_msg "Sin app de juego en foco -> GL/stock"
        fi
        write_state normal ""
        LAST_PACKAGE=""
        sleep 4
        continue
    fi

    if [ "$PKG" = "$LAST_PACKAGE" ]; then
        sleep 4
        continue
    fi
    LAST_PACKAGE="$PKG"

    if is_game "$PKG"; then
        write_state "$CURRENT_MODE" "$PKG"
        if [ "$CURRENT_MODE" != "vulkan" ]; then
            log_msg "🎮 Juego: $PKG -> MODO VULKAN"
            apply_mode vk
            CURRENT_MODE=vulkan
            write_state vulkan "$PKG"
            log_msg "Props Vulkan aplicadas"
        fi
    else
        write_state "$CURRENT_MODE" ""
        if [ "$CURRENT_MODE" != "normal" ]; then
            apply_mode gl
            CURRENT_MODE=normal
            write_state normal ""
        fi
    fi
    sleep 2
done
