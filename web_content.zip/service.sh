#!/system/bin/sh
MODDIR=${0%/*}
BIN="${MODDIR}/triggerctl"
chmod 755 "$BIN"
exec "$BIN" service "$MODDIR" "$@"
