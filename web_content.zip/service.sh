#!/system/bin/sh
# TM Otimizações: persistência apenas das animações.
MODDIR="${0%/*}"
while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 2; done
. "$MODDIR/lib/common.sh"
set_setting global window_animation_scale 0.0
set_setting global transition_animation_scale 0.0
set_setting global animator_duration_scale 0.0
sh "$MODDIR/functions/11_overlays_debug.sh" >/dev/null 2>&1 || true
sh "$MODDIR/functions/12_log_leve.sh" >/dev/null 2>&1 || true
exit 0
