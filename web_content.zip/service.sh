#!/system/bin/sh
# Celestial-Game-Opt by Kazuyoo
# Copyright (c) 2026 Kazuyoo
# Licensed under the GNU General Public License v3.0 or later.
# See LICENSE file for details.
# Open-source powered — with appreciation to GL-DP and all contributors.
MODDIR=${0%/*}
export PATH="$MODDIR/system/bin:$PATH"

build_game_list() {
    local out="/data/local/tmp/gamelist.txt"
    local backup="/data/adb/kazuyoo_gamelist.txt"
    local tmp="/data/local/tmp/gamelist_raw.txt"
    local merged="/data/local/tmp/gamelist_merged.txt"
    : > "$tmp"

    # Detect games from the system (dumpsys game, fallback to pm + built-in whitelist)
    local VERSION=$(getprop ro.build.version.sdk)
    if [ "$VERSION" -ge 31 ]; then
        dumpsys game 2>/dev/null | grep -Eo 'com\.[a-zA-Z0-9._]+' | sort -u > "$tmp"
        [ ! -s "$tmp" ] && pm list packages -3 | cut -d: -f2 | grep -F -f "$MODDIR/gamelist.txt" > "$tmp"
    else
        pm list packages -3 | cut -d: -f2 | grep -F -f "$MODDIR/gamelist.txt" > "$tmp"
    fi

    local detected=""
    while read -r pkg; do
        case "$pkg" in
            ""|*whatsapp*|*chrome*|*youtube*|*browser*|*webview*|*music*|*video*|*gallery*|*maps*|*gmail*|*drive*) continue ;;
        esac
        detected="$detected$pkg
"
    done < "$tmp"
    rm -f "$tmp"

    if [ -s "$backup" ]; then
        : > "$merged"
        cat "$backup" >> "$merged"

        printf '%s' "$detected" | while read -r pkg; do
            [ -z "$pkg" ] && continue
            if ! grep -qxF "$pkg" "$merged" && ! grep -qxF "#$pkg" "$merged"; then
                echo "$pkg" >> "$merged"
            fi
        done

        sort -u -o "$merged" "$merged"
        cp "$merged" "$out"
        cp "$out" "$backup"
        rm -f "$merged"
    else
        printf '%s' "$detected" | sort -u > "$out"
        cp "$out" "$backup" 2>/dev/null
    fi
}

tweaks_optimization() {
    settings put global activity_manager_constants "max_cached_processes=8,background_settle_time=30000,gc_min_interval=60000,process_start_async=true,power_check_max_cpu_1=5,power_check_max_cpu_2=3,power_check_max_cpu_3=1,power_check_max_cpu_4=1,max_phantom_processes=16,low_swap_threshold_percent=0.20,proactive_kills_enabled=true,max_previous_time=30000,service_restart_duration=5000,binder_heavy_hitter_watcher_enabled=false"
    device_config override game android.os.adpf_prefer_power_efficiency false
    device_config override game android.os.adpf_hwui_gpu true
    device_config override game android.os.adpf_obtainview_boost true
    device_config override game android.os.adpf_measure_during_input_event_boost true
    device_config override game android.server.app.disable_game_mode_when_app_top false
    device_config override core_graphics com.android.graphics.surfaceflinger.flags.latch_unsignaled_with_auto_refresh_changed false
    device_config override core_graphics com.android.graphics.surfaceflinger.flags.use_known_refresh_rate_for_fps_consistency true
    device_config override core_graphics com.android.graphics.surfaceflinger.flags.cache_when_source_crop_layer_only_moved true
    device_config override core_graphics com.android.graphics.surfaceflinger.flags.commit_not_composited true
    device_config override core_graphics com.android.graphics.surfaceflinger.flags.add_sf_skipped_frames_to_trace false
    device_config override art_performance com.android.art.flags.fast_baseline_compiler true
    device_config override art_performance com.android.art.flags.reg_alloc_spill_slot_reuse true
    device_config override system_performance android.os.message_queue_tail_tracking false
    device_config override system_performance android.os.perfetto_sdk_tracing false
    echo "0" > "/sys/kernel/tracing/tracing_on"
    echo "0" > "/sys/kernel/debug/tracing/tracing_on"
    sfdo force-client-composition enabled
    cmd display set-match-content-frame-rate-pref 1
    setprop debug.graphics.game_default_frame_rate.disabled 1
    cmd display set-user-disabled-hdr-types 1 2 3 4
    settings put global settings_enable_monitor_phantom_procs false
    settings put secure long_press_timeout 190
    settings put secure multi_press_timeout 200
    settings put global fstrim_mandatory_interval 1
    
    ## vivo opt
    settings list system | grep -q game_do_not_disturb && game_do_not_disturb 1
    settings list system | grep -q game_scene_more_fps && game_scene_more_fps 1
    settings list system | grep -q gamecube_background_call_state && gamecube_background_call_state 1
    settings list system | grep -q gamecube_block_notification_on && gamecube_block_notification_on 1
    settings list system | grep -q gamecube_block_notification_state && gamecube_block_notification_state 1
    settings list system | grep -q gamecube_competition_mode_state && gamecube_competition_mode_state 1
    settings list system | grep -q gamecube_competition_system_state && gamecube_competition_system_state 1
    settings list system | grep -q call_feedback && settings put system call_feedback 0
    settings list system | grep -q call_feedback && settings put system call_log 0
    settings list system | grep -q color_enhancement && settings put system color_enhancement 1
    
    cmd package list packages --user 0 | cut -f2 -d: | while read -r app; do
        dumpsys game 2>/dev/null | grep -qF "$app" && cmd ufw settings set-preload-enable "$app" true
    done
    if command -v su >/dev/null 2>&1; then
        su -c "resetprop -n debug.sf.auto_latch_unsignaled true"
        su -c "resetprop -n debug.sf.enable_advanced_sf_phase_offset 1"
        su -c "resetprop -n debug.sf.latch_unsignaled 1"
        su -c "resetprop -n debug.sf.enable_gl_backpressure true"
        su -c "resetprop -n debug.sf.use_phase_offsets_as_durations 1"
    else
        setprop debug.sf.auto_latch_unsignaled true
        setprop debug.sf.enable_advanced_sf_phase_offset 1
        setprop debug.sf.latch_unsignaled 1
        setprop debug.sf.enable_gl_backpressure true
        setprop debug.sf.use_phase_offsets_as_durations 1
    fi
    [ -n "$(getprop debug.thermal.throttle.support)" ] && {
        setprop debug.thermal.throttle.support no
        su -c "resetprop -n -v debug.thermal.throttle.support no" 2>/dev/null
    }
    [ "$(getprop ro.build.version.release)" -ge 13 ] && {
        setprop debug.fwk.enable_adpf_cpu_hint true
        setprop debug.sf.enable_adpf_cpu_hint true
    }
}

# Wait for boot
while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 2; done
until [ -d "/sdcard/Android" ] || [ -d "/storage/emulated/0/Android" ]; do sleep 1; done

# Start daemon first
build_game_list
cgo_engine --execute

# Then run optimizations in background
tweaks_optimization

# Notify & set daemon priority
if command -v su >/dev/null 2>&1; then
    su -lp 2000 -c "cmd notification post -S bigtext -t 'Celestial-Game-Opt' tag 'Status : Optimization Completed!'" >/dev/null 2>&1
else
    cmd notification post -S bigtext -t 'Celestial-Game-Opt' 'tags' 'Status : Optimization Completed!' >/dev/null 2>&1
fi
sleep 1
# lower shell priority @HoyoSlave
for a in $(ps|grep ^shell|awk '{print $2}');do ionice -c 3 -n 7 -p "$a";iorenice "$a" 7 idle;renice -n 19 -p "$a";done 2>/dev/null

exit 0
