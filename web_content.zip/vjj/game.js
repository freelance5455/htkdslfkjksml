(function () {
'use strict';
/* =====================================================================
   WILD FRONTIER: SURVIVE THE UNKNOWN
   Vanilla JS + Canvas. Sections:
   1 Constants/util   2 Settings+Audio   3 Items/recipes   4 Sprites
   5 World generation 6 State/inventory  7 FX   8 Collision
   9 Entities/AI     10 Player actions   11 Survival/time  12 Save/load
   13 Rendering      14 UI               15 Input          16 Flow/loop
   ===================================================================== */

/* ---------- 1. CONSTANTS / UTIL ---------- */
const TILE = 32, W = 160, H = 160, N = W * H;
const SAVE_KEY = 'wildfrontier_save_v1', SAVE_BAK = 'wildfrontier_save_v1_bak', SET_KEY = 'wildfrontier_settings_v1', SAVE_VER = 1;
const DAY_LEN = 420, MAX_STACKS = 20, STACK_MAX = 99, HOTBAR_N = 6, CHEST_STACKS = 16;
const WALK = 78, SPRINT = 130, HUNGER_RATE = 0.11, THIRST_RATE = 0.16, ACTIVE_R = 560;
const T = { DEEP: 0, SHALLOW: 1, SAND: 2, GRASS: 3, FOREST: 4, ROCKG: 5, DIRT: 6, POND: 7 };
const O = { NONE: 0, TREE: 1, PINE: 2, ROCK: 3, BUSH: 4, BERRY: 5, BUSHE: 6, CRYSTAL: 7, STUMP: 8, MUSH: 9, CACHE: 10, TENT: 11, RUIN: 12, BONES: 13, CACHEO: 14, EMBERS: 15 };
const S = { NONE: 0, WALL: 1, DOOR: 2, CHEST: 3, FIRE: 4, BENCH: 5 };
const OSOLID = new Uint8Array(32);
[O.TREE, O.PINE, O.ROCK, O.CRYSTAL, O.CACHE, O.TENT, O.RUIN].forEach(function (k) { OSOLID[k] = 1; });

const $ = function (id) { return document.getElementById(id); };
const clamp = function (v, a, b) { return v < a ? a : v > b ? b : v; };
const rnd = Math.random;

function mulberry32(a) {
  return function () {
    a |= 0; a = a + 0x6D2B79F5 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
function hash2(x, y, s) {
  let h = Math.imul(x, 374761393) + Math.imul(y, 668265263) + Math.imul(s, 1442695041) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177); h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}
function vnoise(x, y, s) {
  const ix = Math.floor(x), iy = Math.floor(y), fx = x - ix, fy = y - iy;
  const u = fx * fx * (3 - 2 * fx), v = fy * fy * (3 - 2 * fy);
  const a = hash2(ix, iy, s), b = hash2(ix + 1, iy, s), c = hash2(ix, iy + 1, s), d = hash2(ix + 1, iy + 1, s);
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}
function fbm(x, y, s) {
  let t = 0, a = 0.5, f = 1, n = 0;
  for (let i = 0; i < 4; i++) { t += vnoise(x * f, y * f, s + i * 17) * a; n += a; a *= 0.5; f *= 2; }
  return t / n;
}

/* ---------- 2. SETTINGS + AUDIO ---------- */
const settings = { sound: true, volume: 0.6, fps: false };
function loadSettings() {
  try {
    const s = JSON.parse(localStorage.getItem(SET_KEY) || 'null');
    if (s && typeof s === 'object') {
      settings.sound = s.sound !== false;
      if (typeof s.volume === 'number' && isFinite(s.volume)) settings.volume = clamp(s.volume, 0, 1);
      settings.fps = !!s.fps;
    }
  } catch (e) { /* ignore */ }
}
function saveSettings() { try { localStorage.setItem(SET_KEY, JSON.stringify(settings)); } catch (e) { /* ignore */ } }

const SFX = {
  ctx: null, master: null, nbuf: null,
  init: function () {
    if (this.ctx) { this.resume(); return; }
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.connect(this.ctx.destination);
      const len = this.ctx.sampleRate, b = this.ctx.createBuffer(1, len, this.ctx.sampleRate), d = b.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      this.nbuf = b;
      this.apply();
    } catch (e) { this.ctx = null; }
  },
  apply: function () { if (this.master) this.master.gain.value = settings.sound ? settings.volume * 0.5 : 0; },
  resume: function () { if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume().catch(function () {}); },
  tone: function (f, d, type, vol, slide, delay) {
    if (!this.ctx || !settings.sound) return;
    const c = this.ctx, t = c.currentTime + (delay || 0), o = c.createOscillator(), g = c.createGain();
    o.type = type || 'square';
    o.frequency.setValueAtTime(f, t);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, f + slide), t + d);
    g.gain.setValueAtTime(vol || 0.2, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + d);
    o.connect(g); g.connect(this.master); o.start(t); o.stop(t + d + 0.03);
  },
  noise: function (d, vol, freq, delay, q) {
    if (!this.ctx || !settings.sound || !this.nbuf) return;
    const c = this.ctx, t = c.currentTime + (delay || 0), s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
    s.buffer = this.nbuf; f.type = 'bandpass'; f.frequency.value = freq || 1000; f.Q.value = q || 0.8;
    g.gain.setValueAtTime(vol || 0.2, t); g.gain.exponentialRampToValueAtTime(0.001, t + d);
    s.connect(f); f.connect(g); g.connect(this.master); s.start(t); s.stop(t + d + 0.03);
  },
  play: function (n) {
    if (!this.ctx) return;
    switch (n) {
      case 'chop': this.noise(0.09, 0.4, 900); this.tone(130, 0.1, 'triangle', 0.3, -70); break;
      case 'mine': this.noise(0.07, 0.35, 2600, 0, 2); this.tone(320, 0.07, 'square', 0.12, -120); break;
      case 'pick': this.tone(660, 0.07, 'square', 0.13, 200); this.tone(990, 0.09, 'square', 0.11, 150, 0.06); break;
      case 'attack': this.noise(0.12, 0.28, 1700, 0, 0.6); break;
      case 'hit': this.tone(160, 0.12, 'sawtooth', 0.3, -100); this.noise(0.06, 0.3, 700); break;
      case 'hurt': this.tone(240, 0.25, 'sawtooth', 0.35, -170); break;
      case 'craft': this.tone(440, 0.09, 'square', 0.15); this.tone(660, 0.09, 'square', 0.15, 0, 0.09); this.tone(880, 0.16, 'triangle', 0.2, 0, 0.18); break;
      case 'click': this.tone(520, 0.04, 'square', 0.1); break;
      case 'error': this.tone(150, 0.16, 'square', 0.18, -40); break;
      case 'eat': this.noise(0.08, 0.25, 600); this.noise(0.08, 0.25, 700, 0.12); break;
      case 'drink': this.noise(0.22, 0.2, 500, 0, 3); this.tone(300, 0.1, 'sine', 0.15, 200, 0.05); break;
      case 'place': this.tone(190, 0.1, 'square', 0.22, -70); this.noise(0.06, 0.25, 500); break;
      case 'death': this.tone(220, 0.9, 'sawtooth', 0.4, -190); break;
      case 'door': this.tone(110, 0.12, 'triangle', 0.25, 60); break;
      default: break;
    }
  }
};

/* ---------- 3. ITEMS / RECIPES ---------- */
const ITEMS = {
  wood:     { n: 'Wood', c: 'mat', d: 'Sturdy logs for tools and building.' },
  stone:    { n: 'Stone', c: 'mat', d: 'Hard rock for tools and fires.' },
  fiber:    { n: 'Plant Fiber', c: 'mat', d: 'Tough strands for binding tools.' },
  crystal:  { n: 'Crystal Shard', c: 'mat', d: 'Rare glowing shard from dangerous places.' },
  berries:  { n: 'Wild Berries', c: 'cons', food: 8, water: 3, d: 'Sweet and a little juicy. +8 food.' },
  mushroom: { n: 'Mushroom', c: 'cons', food: 6, d: 'Forest mushroom. +6 food.' },
  meat:     { n: 'Raw Meat', c: 'cons', food: 10, d: 'Better cooked over a campfire. +10 food.' },
  cooked:   { n: 'Cooked Meat', c: 'cons', food: 35, d: 'Hot and filling. +35 food.' },
  beans:    { n: 'Canned Beans', c: 'cons', food: 30, d: 'Old supplies. +30 food.' },
  bottle:   { n: 'Water Bottle', c: 'cons', water: 45, d: 'Clean drinking water. +45 water.' },
  bandage:  { n: 'Bandage', c: 'cons', heal: 35, d: 'Restores 35 health.' },
  axe:      { n: 'Wooden Axe', c: 'tool', chop: 3, mine: 1, dmg: 2, reach: 40, cd: 0.5, d: 'Chops trees 3x faster. Light weapon (2 dmg).' },
  pickaxe:  { n: 'Stone Pickaxe', c: 'tool', chop: 1, mine: 3, dmg: 2, reach: 40, cd: 0.5, d: 'Mines rock 3x faster. Required for crystals.' },
  spear:    { n: 'Wooden Spear', c: 'tool', chop: 1, mine: 1, dmg: 4, reach: 62, cd: 0.55, d: 'Long reach weapon (4 dmg).' },
  cspear:   { n: 'Crystal Spear', c: 'tool', chop: 1, mine: 1, dmg: 8, reach: 68, cd: 0.45, d: 'Glowing spear (8 dmg). Made at a workbench.' },
  campfire: { n: 'Campfire', c: 'build', s: S.FIRE, d: 'Lights the night, cooks meat, speeds healing.' },
  wall:     { n: 'Wooden Wall', c: 'build', s: S.WALL, rot: true, d: 'Solid wall block.' },
  floor:    { n: 'Wooden Floor', c: 'build', s: 'floor', d: 'Walkable floor. Build walls on top.' },
  door:     { n: 'Wooden Door', c: 'build', s: S.DOOR, rot: true, d: 'Open and close with Interact.' },
  chest:    { n: 'Storage Chest', c: 'build', s: S.CHEST, d: 'Store up to 16 item types.' },
  bench:    { n: 'Workbench', c: 'build', s: S.BENCH, d: 'Needed for advanced recipes.' }
};
const CATS = { mat: 'Materials', cons: 'Consumables', tool: 'Tools & Weapons', build: 'Structures' };
const RECIPES = [
  { id: 'axe', cost: { wood: 4, stone: 2, fiber: 2 } },
  { id: 'pickaxe', cost: { wood: 3, stone: 4, fiber: 2 } },
  { id: 'spear', cost: { wood: 4, stone: 2, fiber: 2 } },
  { id: 'campfire', cost: { wood: 6, stone: 4 } },
  { id: 'wall', cost: { wood: 4 } },
  { id: 'floor', cost: { wood: 2 }, yield: 2 },
  { id: 'door', cost: { wood: 6, fiber: 2 } },
  { id: 'chest', cost: { wood: 10, fiber: 2 } },
  { id: 'bench', cost: { wood: 12, stone: 4, fiber: 4 } },
  { id: 'bandage', cost: { fiber: 3, berries: 2 } },
  { id: 'cspear', cost: { wood: 4, crystal: 3, fiber: 2 }, bench: true }
];
function recipeOf(id) { for (let i = 0; i < RECIPES.length; i++) if (RECIPES[i].id === id) return RECIPES[i]; return null; }

/* ---------- 4. SPRITES (all procedural) ---------- */
function mkCanvas(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
function spr(w, h, fn) { const cv = mkCanvas(w, h), c = cv.getContext('2d'); fn(c); return cv; }
function R(c, col, x, y, w, h) { c.fillStyle = col; c.fillRect(x * 2, y * 2, w * 2, h * 2); }   // 2px grid
function inE(x, y, cx, cy, rx, ry) { const dx = (x + 0.5 - cx) / rx, dy = (y + 0.5 - cy) / ry; return dx * dx + dy * dy <= 1; }
function blob(c, col, cx, cy, rx, ry) {
  for (let gy = Math.floor(cy - ry); gy <= Math.ceil(cy + ry); gy++)
    for (let gx = Math.floor(cx - rx); gx <= Math.ceil(cx + rx); gx++) if (inE(gx, gy, cx, cy, rx, ry)) R(c, col, gx, gy, 1, 1);
}
function shadow(c, x, y, rx, ry, a) { c.fillStyle = 'rgba(0,0,0,' + (a || 0.25) + ')'; c.beginPath(); c.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2); c.fill(); }
function poly(c, col, pts) { c.fillStyle = col; c.beginPath(); c.moveTo(pts[0][0], pts[0][1]); for (let i = 1; i < pts.length; i++) c.lineTo(pts[i][0], pts[i][1]); c.closePath(); c.fill(); }

const TS = [];          // terrain sprites by terrain id
const SP = {};          // object / structure sprites
const ICONS = {};       // item icon canvases (16x16)
const ICONURL = {};
let lightSpr = null, fireGlow = null;

function buildTerrain() {
  function tile(base, seed, fn) {
    const cv = mkCanvas(32, 32), c = cv.getContext('2d'), rng = mulberry32(seed);
    c.fillStyle = base; c.fillRect(0, 0, 32, 32); fn(c, rng); return cv;
  }
  function speck(c, rng, cols, n) { for (let k = 0; k < n; k++) R(c, cols[(rng() * cols.length) | 0], (rng() * 16) | 0, (rng() * 16) | 0, 1, 1); }
  TS[T.GRASS] = []; TS[T.FOREST] = []; TS[T.SAND] = []; TS[T.DIRT] = []; TS[T.ROCKG] = [];
  for (let v = 0; v < 4; v++) {
    TS[T.GRASS].push(tile('#4f9a3a', 11 + v, function (c, r) {
      speck(c, r, ['#5eaa45', '#418a31', '#68b84c'], 26);
      for (let k = 0; k < 3; k++) { const x = (r() * 14 + 1) | 0, y = (r() * 13 + 1) | 0; R(c, '#357a2a', x, y, 1, 2); R(c, '#6cc050', x + 1, y - 1 + 1, 1, 1); }
      if (v === 3) { const x = (r() * 13 + 1) | 0, y = (r() * 13 + 1) | 0; R(c, '#fff4b0', x, y, 1, 1); R(c, '#f0a0c0', x + 3, y + 4, 1, 1); }
    }));
    TS[T.FOREST].push(tile('#37702f', 31 + v, function (c, r) {
      speck(c, r, ['#2c5e27', '#43833a', '#274f22'], 28); speck(c, r, ['#6a5232', '#7d6038'], 5);
    }));
    TS[T.SAND].push(tile('#e4d291', 51 + v, function (c, r) { speck(c, r, ['#d2bd7a', '#f1e4ab', '#c9b46f'], 20); }));
    TS[T.DIRT].push(tile('#8c6c48', 71 + v, function (c, r) { speck(c, r, ['#755837', '#a27f58', '#68502f'], 24); }));
    TS[T.ROCKG].push(tile('#787c82', 91 + v, function (c, r) {
      speck(c, r, ['#8d9198', '#62666c', '#9ca0a6'], 22);
      const x = (r() * 8) | 0, y = (r() * 10) | 0; R(c, '#5a5e64', x, y, 4, 1); R(c, '#5a5e64', x + 3, y + 1, 3, 1);
    }));
  }
  const water = [
    [T.DEEP, '#1d4f93', '#2c6db8', '#163e78'], [T.SHALLOW, '#2f88cc', '#6cc3ef', '#2874b4'], [T.POND, '#38a8c4', '#9be3f2', '#2a90ac']
  ];
  water.forEach(function (w) {
    TS[w[0]] = [];
    for (let f = 0; f < 4; f++) TS[w[0]].push(tile(w[1], 5, function (c) {
      for (let k = 0; k < 5; k++) {
        const y = (k * 3 + f) % 16, x = (k * 5 + f * 2) % 13;
        R(c, w[2], x, y, 3, 1); R(c, w[3], (x + 7) % 13, (y + 8) % 16, 2, 1);
      }
    }));
  });
}

function buildObjSprites() {
  SP.tree = [0, 1].map(function (v) {
    return spr(32, 48, function (c) {
      shadow(c, 16, 42, 11, 4);
      R(c, '#4e3219', 6, 15, 4, 7); R(c, '#6e4727', 6, 15, 2, 7); R(c, '#3a2412', 9, 17, 1, 5);
      const dk = v ? '#1f5a2a' : '#215e24', md = v ? '#2e7d35' : '#32802a', lt = v ? '#46a047' : '#4aa23a';
      blob(c, dk, 8, 10.5, 7.5, 7); blob(c, md, 8, 9.5, 7, 6.2); blob(c, lt, 6, 7, 4, 3);
      const r = mulberry32(5 + v);
      for (let k = 0; k < 16; k++) { const x = (2 + r() * 12) | 0, y = (3 + r() * 11) | 0; if (inE(x, y, 8, 9.5, 7, 6.2)) R(c, r() < 0.5 ? lt : dk, x, y, 1, 1); }
    });
  });
  SP.pine = spr(32, 48, function (c) {
    shadow(c, 16, 42, 9, 3.5); R(c, '#4e3219', 7, 18, 2, 4);
    for (let r = 0; r < 7; r++) {
      const yy = 2 + Math.floor(r * 2.7), ww = 2 + r * 2, x = 8 - ww / 2;
      R(c, '#1c5636', x, yy, ww, 3); R(c, '#2d7a48', x, yy, Math.max(1, ww * 0.55), 2); R(c, '#164a2c', x + ww - 1, yy + 1, 1, 2);
    }
  });
  SP.stump = spr(32, 32, function (c) {
    shadow(c, 16, 24, 8, 3); R(c, '#5b3b21', 5, 9, 6, 6); R(c, '#8a5f36', 5, 8, 6, 3); R(c, '#c49660', 6, 8, 4, 2); R(c, '#7a5030', 7, 9, 2, 1);
  });
  SP.rock = [0, 1].map(function (v) {
    return spr(32, 32, function (c) {
      shadow(c, 16, 26, 12, 4);
      blob(c, '#5a5e66', 8, 10.5, 7, 5); blob(c, '#7e838b', 8, 9.5, 6.4, 4.4); blob(c, '#a3a8b0', 6.5, 8, 3.4, 2.2);
      R(c, '#4a4e55', 4, 13, 8, 1);
      if (v) { blob(c, '#6b7078', 12.5, 12, 2.5, 2); R(c, '#9aa0a8', 12, 11, 1, 1); } else { R(c, '#4a4e55', 8, 8, 1, 3); }
    });
  });
  SP.crystal = spr(32, 32, function (c) {
    shadow(c, 16, 27, 11, 4);
    c.fillStyle = 'rgba(80,230,255,.22)'; c.beginPath(); c.arc(16, 17, 14, 0, 7); c.fill();
    poly(c, '#2aa7c4', [[16, 3], [22, 20], [16, 28], [10, 20]]); poly(c, '#7ff0ff', [[16, 3], [19, 20], [16, 28], [13, 20]]);
    poly(c, '#27b8a0', [[7, 12], [12, 22], [8, 28], [4, 22]]); poly(c, '#6fe8d8', [[25, 11], [28, 22], [24, 28], [20, 22]]);
    poly(c, '#ffffff', [[15, 6], [16, 5], [16, 12], [14, 14]]);
  });
  SP.bush = spr(32, 32, function (c) {
    shadow(c, 16, 25, 10, 3.5);
    blob(c, '#256a2c', 8, 11.5, 6.5, 4.5); blob(c, '#2f8a37', 8, 10.5, 6, 4); blob(c, '#52b04c', 6.5, 9, 3, 2);
    const r = mulberry32(9); for (let k = 0; k < 8; k++) { const x = (3 + r() * 10) | 0, y = (7 + r() * 8) | 0; if (inE(x, y, 8, 10.5, 6, 4)) R(c, '#1e5a26', x, y, 1, 1); }
  });
  SP.berry = spr(32, 32, function (c) {
    shadow(c, 16, 25, 10, 3.5);
    blob(c, '#256a2c', 8, 11.5, 6.5, 4.5); blob(c, '#2f8a37', 8, 10.5, 6, 4); blob(c, '#52b04c', 6.5, 9, 3, 2);
    [[4, 9], [7, 7], [10, 10], [6, 12], [11, 8], [9, 13]].forEach(function (p) { R(c, '#d6304a', p[0], p[1], 1, 1); R(c, '#ff98a4', p[0], p[1], 1, 0.5); });
  });
  SP.bushe = spr(32, 32, function (c) {
    shadow(c, 16, 25, 8, 3);
    blob(c, '#3d6b30', 8, 12, 5, 3); R(c, '#7a6a3a', 5, 7, 1, 5); R(c, '#7a6a3a', 8, 6, 1, 6); R(c, '#7a6a3a', 11, 8, 1, 4); R(c, '#4f8a3a', 5, 7, 1, 1); R(c, '#4f8a3a', 11, 8, 1, 1);
  });
  SP.mush = spr(32, 32, function (c) {
    shadow(c, 16, 24, 8, 3);
    [[5, 11, 3], [9, 12, 4], [7, 9, 2]].forEach(function (m) {
      R(c, '#eadfc2', m[0], m[1], 1, 3); blob(c, '#c0392b', m[0] + 0.5, m[1], m[2] / 1.6, 1.3); R(c, '#fff', m[0], m[1] - 1, 1, 1);
    });
  });
  SP.cache = spr(32, 32, function (c) {
    shadow(c, 16, 26, 11, 4);
    R(c, '#5a3819', 3, 8, 10, 8); R(c, '#8a5a30', 3, 6, 10, 3); R(c, '#a47038', 3, 6, 10, 1);
    R(c, '#2e2e32', 3, 10, 10, 1); R(c, '#2e2e32', 5, 6, 1, 10); R(c, '#2e2e32', 10, 6, 1, 10); R(c, '#d4ae5a', 7, 10, 2, 2);
    R(c, '#c0392b', 12, 3, 1, 4); R(c, '#e05a48', 12, 3, 3, 2);
  });
  SP.cacheo = spr(32, 32, function (c) {
    shadow(c, 16, 26, 11, 4);
    R(c, '#5a3819', 3, 8, 10, 8); R(c, '#241810', 4, 9, 8, 3); R(c, '#8a5a30', 2, 3, 10, 3); R(c, '#2e2e32', 5, 3, 1, 3);
  });
  SP.tent = spr(32, 32, function (c) {
    shadow(c, 16, 27, 13, 4);
    poly(c, '#b9a477', [[16, 4], [3, 26], [16, 26]]); poly(c, '#8f7b52', [[16, 4], [29, 26], [16, 26]]);
    poly(c, '#2c2416', [[16, 14], [11, 26], [21, 26]]); R(c, '#6b4a22', 7, 1, 1, 3); poly(c, '#a89264', [[3, 26], [5, 28], [9, 26]]);
  });
  SP.ruin = spr(32, 32, function (c) {
    shadow(c, 16, 27, 12, 4);
    R(c, '#6a6e75', 2, 8, 12, 7); R(c, '#8a8e95', 2, 7, 12, 2); R(c, '#50545a', 2, 12, 12, 1); R(c, '#50545a', 7, 8, 1, 4);
    R(c, '#7a7e85', 3, 4, 4, 3); R(c, '#4c7a3a', 9, 7, 3, 1); R(c, '#4c7a3a', 2, 10, 2, 1); R(c, '#2e2e32', 10, 4, 2, 4);
  });
  SP.bones = spr(32, 32, function (c) {
    shadow(c, 16, 22, 7, 2.5, 0.18);
    R(c, '#e8e2d0', 4, 10, 6, 1); R(c, '#e8e2d0', 4, 9, 1, 1); R(c, '#e8e2d0', 4, 11, 1, 1); R(c, '#e8e2d0', 9, 9, 1, 1); R(c, '#e8e2d0', 9, 11, 1, 1);
    blob(c, '#e8e2d0', 11, 8, 2.2, 2); R(c, '#201810', 10, 7, 1, 1); R(c, '#201810', 12, 7, 1, 1);
  });
  SP.embers = spr(32, 32, function (c) {
    shadow(c, 16, 22, 9, 3, 0.15);
    for (let k = 0; k < 8; k++) { const a = k / 8 * 6.283; blob(c, '#6d7178', 8 + Math.cos(a) * 4.5, 9 + Math.sin(a) * 3.2, 1.4, 1.2); }
    blob(c, '#2a2622', 8, 9, 3.4, 2.4); R(c, '#4a2c1a', 6, 9, 4, 1);
  });
  /* structures */
  SP.floor = spr(32, 32, function (c) {
    R(c, '#b58650', 0, 0, 16, 16);
    for (let k = 0; k < 4; k++) { R(c, '#8e6338', 0, k * 4 + 3, 16, 1); R(c, '#c99a62', 0, k * 4, 16, 1); }
    R(c, '#8e6338', 5, 0, 1, 4); R(c, '#8e6338', 11, 4, 1, 4); R(c, '#8e6338', 3, 8, 1, 4); R(c, '#8e6338', 9, 12, 1, 4);
    for (let k = 0; k < 4; k++) { R(c, '#5a3a1c', 1, k * 4 + 1, 1, 1); R(c, '#5a3a1c', 14, k * 4 + 1, 1, 1); }
  });
  SP.wall = [0, 1].map(function (v) {
    return spr(32, 48, function (c) {
      shadow(c, 16, 44, 14, 3.5, 0.3);
      c.translate(0, 16);
      R(c, '#b98245', 0, 2, 16, 3); R(c, '#d09a5a', 0, 2, 16, 1);        // top
      R(c, '#8a5a2e', 0, 5, 16, 10);                                      // front face
      if (!v) { R(c, '#6a431f', 0, 8, 16, 1); R(c, '#6a431f', 0, 11, 16, 1); R(c, '#a8733a', 0, 6, 16, 1); R(c, '#6a431f', 6, 5, 1, 3); R(c, '#6a431f', 11, 8, 1, 3); }
      else { for (let k = 1; k < 4; k++) R(c, '#6a431f', k * 4 - 1, 5, 1, 10); R(c, '#a8733a', 0, 6, 1, 9); }
      R(c, '#4a2e14', 0, 15, 16, 1);
    });
  });
  SP.doorC = [0, 1].map(function (v) {
    return spr(32, 48, function (c) {
      shadow(c, 16, 44, 14, 3.5, 0.3); c.translate(0, 16);
      R(c, '#4e3219', 0, 2, 16, 14); R(c, '#9a6a34', 2, 4, 12, 11);
      if (!v) { R(c, '#7a4f24', 2, 8, 12, 1); R(c, '#7a4f24', 2, 12, 12, 1); } else { R(c, '#7a4f24', 6, 4, 1, 11); R(c, '#7a4f24', 10, 4, 1, 11); }
      R(c, '#e0c060', 11, 9, 2, 2); R(c, '#3a2410', 0, 15, 16, 1);
    });
  });
  SP.doorO = spr(32, 48, function (c) {
    shadow(c, 16, 44, 14, 3.5, 0.2); c.translate(0, 16);
    R(c, '#4e3219', 0, 2, 3, 14); R(c, '#4e3219', 13, 2, 3, 14); R(c, '#4e3219', 0, 1, 16, 2); R(c, '#8a5a2e', 3, 3, 2, 12);
  });
  SP.chest = spr(32, 32, function (c) {
    shadow(c, 16, 27, 11, 3.5, 0.3);
    R(c, '#6f4220', 2, 8, 12, 8); R(c, '#9b6330', 2, 5, 12, 4); R(c, '#b9803f', 2, 5, 12, 1);
    R(c, '#cfa84b', 7, 5, 2, 11); R(c, '#cfa84b', 2, 8, 12, 1); R(c, '#2a1c0c', 7, 10, 2, 2);
  });
  SP.bench = spr(32, 48, function (c) {
    shadow(c, 16, 44, 14, 3.5, 0.3); c.translate(0, 14);
    R(c, '#5a3a1c', 2, 10, 2, 6); R(c, '#5a3a1c', 12, 10, 2, 6);
    R(c, '#b07a40', 0, 6, 16, 5); R(c, '#cf9a58', 0, 6, 16, 1); R(c, '#6a431f', 0, 10, 16, 1);
    R(c, '#aab0b8', 3, 4, 5, 2); R(c, '#6a431f', 8, 4, 1, 2);        // saw
    R(c, '#7a5a30', 11, 3, 1, 3); R(c, '#8a8e95', 10, 3, 3, 1);       // hammer
  });
  SP.fire = spr(32, 32, function (c) {
    shadow(c, 16, 24, 10, 3.5, 0.3);
    for (let k = 0; k < 8; k++) { const a = k / 8 * 6.283; blob(c, '#70747b', 8 + Math.cos(a) * 5, 11 + Math.sin(a) * 3, 1.4, 1.2); }
    R(c, '#5a3a1c', 4, 10, 8, 2); R(c, '#4a2c14', 5, 12, 6, 1); R(c, '#7a4f24', 5, 10, 6, 1);
  });
  /* glow sprites */
  lightSpr = spr(128, 128, function (c) {
    const g = c.createRadialGradient(64, 64, 0, 64, 64, 64);
    g.addColorStop(0, 'rgba(255,255,255,1)'); g.addColorStop(0.45, 'rgba(255,255,255,.7)'); g.addColorStop(1, 'rgba(255,255,255,0)');
    c.fillStyle = g; c.fillRect(0, 0, 128, 128);
  });
  fireGlow = spr(128, 128, function (c) {
    const g = c.createRadialGradient(64, 64, 0, 64, 64, 64);
    g.addColorStop(0, 'rgba(255,170,70,.55)'); g.addColorStop(1, 'rgba(255,120,30,0)');
    c.fillStyle = g; c.fillRect(0, 0, 128, 128);
  });
}

function makeIcon(id) {
  if (ICONS[id]) return ICONS[id];
  const cv = mkCanvas(16, 16), c = cv.getContext('2d');
  function r(col, x, y, w, h) { c.fillStyle = col; c.fillRect(x, y, w, h); }
  function line(col, x0, y0, x1, y1) { const n = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0)); for (let i = 0; i <= n; i++) r(col, Math.round(x0 + (x1 - x0) * i / n), Math.round(y0 + (y1 - y0) * i / n), 1, 1); }
  switch (id) {
    case 'wood': r('#7a4a24', 1, 5, 14, 4); r('#a56d3a', 1, 5, 14, 1); r('#d9b074', 1, 6, 2, 2); r('#6a3f1e', 2, 10, 12, 4); r('#8a5a30', 2, 10, 12, 1); r('#d9b074', 2, 11, 2, 2); break;
    case 'stone': r('#5c6068', 3, 7, 10, 7); r('#80858d', 4, 6, 8, 7); r('#a3a8b0', 5, 6, 4, 3); r('#4a4e55', 3, 13, 10, 1); break;
    case 'fiber': for (let k = 0; k < 5; k++) { line('#4fae4a', 3 + k * 2, 14, 2 + k * 2 + (k % 2 ? 1 : -1), 3 + (k % 3)); } r('#8a6a30', 2, 12, 12, 1); break;
    case 'crystal': c.fillStyle = '#2aa7c4'; c.beginPath(); c.moveTo(8, 1); c.lineTo(13, 10); c.lineTo(8, 15); c.lineTo(3, 10); c.fill(); c.fillStyle = '#8ff3ff'; c.beginPath(); c.moveTo(8, 1); c.lineTo(10, 10); c.lineTo(8, 15); c.lineTo(6, 10); c.fill(); break;
    case 'berries': r('#3a8a3a', 7, 2, 3, 3); r('#d6304a', 3, 7, 4, 4); r('#d6304a', 8, 6, 4, 4); r('#c02040', 5, 10, 4, 4); r('#ff98a4', 4, 8, 1, 1); r('#ff98a4', 9, 7, 1, 1); break;
    case 'mushroom': r('#eadfc2', 7, 8, 3, 6); r('#c0392b', 3, 4, 10, 5); r('#e05a48', 4, 4, 8, 2); r('#fff', 5, 6, 2, 1); r('#fff', 9, 5, 2, 1); break;
    case 'meat': case 'cooked': { const a = id === 'meat' ? ['#d6606a', '#f08a94'] : ['#8a4a22', '#b5703a']; r(a[0], 3, 3, 9, 8); r(a[1], 4, 3, 6, 3); r('#f0ead8', 11, 10, 3, 3); r('#f0ead8', 12, 12, 3, 2); break; }
    case 'beans': r('#8a8e95', 3, 3, 10, 11); r('#c0392b', 3, 6, 10, 5); r('#e8e2d0', 5, 7, 6, 2); r('#5a5e64', 3, 3, 10, 1); r('#5a5e64', 3, 13, 10, 1); break;
    case 'bottle': r('#9fd8ee', 6, 1, 4, 3); r('#4aa8d8', 4, 4, 8, 10); r('#9be3f2', 5, 5, 2, 7); r('#2a78a8', 4, 13, 8, 1); break;
    case 'bandage': r('#efe8d8', 2, 5, 12, 6); r('#d8cfb8', 2, 10, 12, 1); r('#c0392b', 7, 6, 2, 4); r('#c0392b', 6, 7, 4, 2); break;
    case 'axe': line('#8a5a2e', 3, 14, 11, 4); line('#a8733a', 4, 14, 12, 4); r('#9aa0a8', 8, 2, 6, 5); r('#c8ccd2', 9, 2, 5, 2); r('#6a6e75', 8, 6, 3, 1); break;
    case 'pickaxe': line('#8a5a2e', 3, 14, 11, 5); r('#9aa0a8', 3, 3, 11, 2); r('#c8ccd2', 4, 3, 9, 1); r('#9aa0a8', 3, 4, 2, 2); r('#9aa0a8', 12, 4, 2, 2); break;
    case 'spear': case 'cspear': line('#8a5a2e', 2, 14, 12, 4); line('#a8733a', 3, 14, 13, 4); poly(c, id === 'spear' ? '#c8ccd2' : '#7ff0ff', [[14, 1], [15, 6], [10, 4]]); if (id === 'cspear') r('#2aa7c4', 12, 3, 2, 2); break;
    case 'campfire': r('#70747b', 2, 11, 3, 3); r('#70747b', 11, 11, 3, 3); r('#5a3a1c', 3, 11, 10, 2); poly(c, '#f08a2a', [[8, 2], [12, 10], [4, 10]]); poly(c, '#ffd860', [[8, 5], [10, 10], [6, 10]]); break;
    case 'wall': r('#b98245', 1, 3, 14, 3); r('#8a5a2e', 1, 6, 14, 8); r('#6a431f', 1, 9, 14, 1); r('#6a431f', 1, 12, 14, 1); r('#4a2e14', 1, 14, 14, 1); break;
    case 'floor': r('#b58650', 1, 1, 14, 14); for (let k = 0; k < 4; k++) r('#8e6338', 1, k * 4 + 4, 14, 1); r('#8e6338', 6, 1, 1, 3); r('#8e6338', 10, 5, 1, 3); break;
    case 'door': r('#4e3219', 3, 1, 10, 14); r('#9a6a34', 4, 3, 8, 11); r('#7a4f24', 4, 7, 8, 1); r('#e0c060', 10, 8, 2, 2); break;
    case 'chest': r('#6f4220', 2, 7, 12, 7); r('#9b6330', 2, 4, 12, 4); r('#cfa84b', 7, 4, 2, 10); r('#2a1c0c', 7, 8, 2, 2); break;
    case 'bench': r('#5a3a1c', 3, 9, 2, 5); r('#5a3a1c', 11, 9, 2, 5); r('#b07a40', 1, 5, 14, 5); r('#cf9a58', 1, 5, 14, 1); r('#aab0b8', 3, 2, 5, 2); r('#8a8e95', 10, 2, 3, 1); r('#7a5a30', 11, 2, 1, 3); break;
    default: r('#888', 3, 3, 10, 10);
  }
  ICONS[id] = cv; return cv;
}
function iconURL(id) { return ICONURL[id] || (ICONURL[id] = makeIcon(id).toDataURL()); }

/* ---------- 5. WORLD GENERATION ---------- */
let world = null;
let terr, obj, hpA, floorA, st, sr, ss, baseObj, baseHp, explored;
const ETYPES = {
  rabbit: { hp: 4, spd: 38, run: 120, hw: 4, hh: 3, drop: [['meat', 1, 1]], hostile: false },
  deer:   { hp: 9, spd: 36, run: 105, hw: 6, hh: 4, drop: [['meat', 2, 2]], hostile: false },
  wolf:   { hp: 16, spd: 48, run: 108, hw: 6, hh: 4, dmg: 8, det: 150, cd: 1.1, hostile: true, drop: [['meat', 1, 1]] },
  bear:   { hp: 42, spd: 44, run: 94, hw: 9, hh: 6, dmg: 16, det: 140, cd: 1.6, hostile: true, drop: [['meat', 3, 3]] },
  shade:  { hp: 11, spd: 52, run: 98, hw: 5, hh: 4, dmg: 7, det: 210, cd: 1.2, hostile: true, night: true, drop: [['crystal', 1, 0.25]] }
};

function isLandT(t) { return t !== T.DEEP && t !== T.SHALLOW && t !== T.POND; }

function generateWorld(seed) {
  const rng = mulberry32(seed >>> 0), ns = seed & 0xffff;
  const w = {
    seed: seed, terr: new Uint8Array(N), obj: new Uint8Array(N), hp: new Uint8Array(N), floor: new Uint8Array(N),
    st: new Uint8Array(N), sr: new Uint8Array(N), ss: new Uint8Array(N), explored: new Uint8Array(N), clr: new Uint8Array(N),
    reach: new Uint8Array(N), spawns: [], pois: [], chests: new Map(), regrow: [], dead: new Set(), start: { tx: W >> 1, ty: H >> 1 }
  };
  const tr = w.terr, ob = w.obj, hp = w.hp, cx = W / 2, cy = H / 2, V = new Float32Array(N);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const dx = (x - cx) / (W * 0.5), dy = (y - cy) / (H * 0.5), d = Math.sqrt(dx * dx + dy * dy);
    const e = fbm(x * 0.035, y * 0.035, ns);
    const v = 0.55 * e + 0.8 * (1 - Math.pow(Math.min(d, 1.4), 1.5));
    V[y * W + x] = v;
    let t;
    if (v < 0.36) t = T.DEEP; else if (v < 0.42) t = T.SHALLOW; else if (v < 0.485) t = T.SAND;
    else {
      const rn = fbm(x * 0.07 + 40, y * 0.07, ns + 50), mo = fbm(x * 0.045 + 90, y * 0.045, ns + 90);
      if (rn > 0.64 && v > 0.55) t = T.ROCKG; else if (mo > 0.52) t = T.FOREST; else t = T.GRASS;
    }
    if (Math.hypot(x - cx, y - cy) < 12 && v >= 0.485) t = T.GRASS;
    tr[y * W + x] = t;
  }
  function inb(x, y) { return x >= 0 && y >= 0 && x < W && y < H; }
  function put(i, type) { ob[i] = type; hp[i] = type === O.TREE || type === O.PINE ? 10 : type === O.ROCK ? 8 : type === O.CRYSTAL ? 6 : type === O.CACHE ? 1 : 0; }
  // ponds
  function pond(px, py, r) {
    for (let y = Math.floor(py - r - 2); y <= py + r + 2; y++) for (let x = Math.floor(px - r - 2); x <= px + r + 2; x++) {
      if (!inb(x, y)) continue;
      const d = Math.hypot(x - px, y - py) + (hash2(x, y, ns + 7) - 0.5) * 1.2;
      if (d < r && isLandT(tr[y * W + x]) && tr[y * W + x] !== T.SAND) tr[y * W + x] = T.POND;
    }
  }
  pond(cx + 8, cy - 3, 2.4);
  for (let k = 0, made = 0; k < 120 && made < 8; k++) {
    const x = (rng() * W) | 0, y = (rng() * H) | 0, i = y * W + x;
    if (V[i] > 0.62 && Math.hypot(x - cx, y - cy) > 14 && (tr[i] === T.GRASS || tr[i] === T.FOREST)) { pond(x, y, 2 + rng() * 1.6); made++; }
  }
  // clearings
  for (let k = 0, made = 0; k < 150 && made < 8; k++) {
    const x = (rng() * W) | 0, y = (rng() * H) | 0, i = y * W + x;
    if (V[i] > 0.58 && (tr[i] === T.GRASS || tr[i] === T.FOREST)) {
      const r = 4 + rng() * 2;
      for (let yy = Math.floor(y - r); yy <= y + r; yy++) for (let xx = Math.floor(x - r); xx <= x + r; xx++) {
        if (inb(xx, yy) && Math.hypot(xx - x, yy - y) < r) { const j = yy * W + xx; if (tr[j] === T.FOREST) tr[j] = T.GRASS; if (isLandT(tr[j])) w.clr[j] = 1; }
      }
      made++;
    }
  }
  // objects
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const i = y * W + x, t = tr[i];
    if (!isLandT(t) || Math.hypot(x - cx, y - cy) < 6) continue;
    const r = rng(), cl = w.clr[i];
    if (t === T.FOREST) {
      const dens = clamp(0.14 + (fbm(x * 0.09, y * 0.09, ns + 3) - 0.4) * 0.9, 0.08, 0.36);
      if (cl) { if (r < 0.04) put(i, O.BUSH); else if (r < 0.08) put(i, O.BERRY); else if (r < 0.1) put(i, O.ROCK); }
      else if (r < dens) put(i, rng() < 0.4 ? O.PINE : O.TREE);
      else if (r < dens + 0.03) put(i, O.BUSH); else if (r < dens + 0.045) put(i, O.BERRY); else if (r < dens + 0.065) put(i, O.MUSH); else if (r < dens + 0.075) put(i, O.ROCK);
    } else if (t === T.GRASS) {
      if (cl) { if (r < 0.06) put(i, O.BUSH); else if (r < 0.11) put(i, O.BERRY); else if (r < 0.16) put(i, O.ROCK); else if (r < 0.18) put(i, O.MUSH); else if (r < 0.2) put(i, O.TREE); }
      else if (r < 0.035) put(i, rng() < 0.3 ? O.PINE : O.TREE); else if (r < 0.06) put(i, O.BUSH); else if (r < 0.072) put(i, O.BERRY); else if (r < 0.085) put(i, O.ROCK); else if (r < 0.088) put(i, O.MUSH);
    } else if (t === T.ROCKG) {
      if (r < 0.2) put(i, O.ROCK); else if (r < 0.206 + (V[i] > 0.9 ? 0.004 : 0)) put(i, O.CRYSTAL); else if (r < 0.22) put(i, O.PINE);
    } else if (t === T.SAND) { if (r < 0.01) put(i, O.ROCK); }
  }
  // reachability (terrain only; trees/rocks can be cleared by the player)
  const sx = w.start.tx, sy = w.start.ty, q = new Int32Array(N); let qh = 0, qt = 0;
  q[qt++] = sy * W + sx; w.reach[sy * W + sx] = 1;
  while (qh < qt) {
    const i = q[qh++], x = i % W, y = (i / W) | 0;
    const nb = [[x + 1, y], [x - 1, y], [x, y + 1], [x, y - 1]];
    for (let k = 0; k < 4; k++) {
      const nx = nb[k][0], ny = nb[k][1]; if (!inb(nx, ny)) continue;
      const j = ny * W + nx; if (w.reach[j] || !isLandT(tr[j])) continue;
      w.reach[j] = 1; q[qt++] = j;
    }
  }
  function randReach(minD, maxD, tries, pred) {
    for (let k = 0; k < tries; k++) {
      const x = (rng() * W) | 0, y = (rng() * H) | 0, i = y * W + x, d = Math.hypot(x - sx, y - sy);
      if (w.reach[i] && d >= minD && d <= maxD && (!pred || pred(i, x, y))) return i;
    }
    return -1;
  }
  function clearArea(x, y, r) { for (let yy = y - r; yy <= y + r; yy++) for (let xx = x - r; xx <= x + r; xx++) if (inb(xx, yy)) { ob[yy * W + xx] = 0; hp[yy * W + xx] = 0; } }
  function allLand(x, y, r) { for (let yy = y - r; yy <= y + r; yy++) for (let xx = x - r; xx <= x + r; xx++) { if (!inb(xx, yy) || !isLandT(tr[yy * W + xx]) || !w.reach[yy * W + xx]) return false; } return true; }
  // guaranteed starting resources
  function scatter(type, count, r0, r1) {
    for (let k = 0, placed = 0; k < 600 && placed < count; k++) {
      const a = rng() * 6.283, d = r0 + rng() * (r1 - r0), x = Math.round(sx + Math.cos(a) * d), y = Math.round(sy + Math.sin(a) * d);
      if (!inb(x, y)) continue;
      const i = y * W + x; if (!isLandT(tr[i]) || ob[i]) continue;
      if (OSOLID[type]) { let free = 0; for (let yy = -1; yy <= 1; yy++) for (let xx = -1; xx <= 1; xx++) if ((xx || yy) && inb(x + xx, y + yy) && !OSOLID[ob[(y + yy) * W + x + xx]] && isLandT(tr[(y + yy) * W + x + xx])) free++; if (free < 6) continue; }
      put(i, type); placed++;
    }
  }
  clearArea(sx, sy, 3);
  scatter(O.TREE, 10, 5, 12); scatter(O.PINE, 4, 5, 12); scatter(O.ROCK, 8, 4, 11); scatter(O.BUSH, 8, 3, 10); scatter(O.BERRY, 5, 4, 11); scatter(O.MUSH, 3, 5, 11);
  // abandoned camps
  for (let k = 0, made = 0; k < 400 && made < 5; k++) {
    const i = randReach(18, 80, 20, function (j, x, y) { return allLand(x, y, 3) && tr[j] !== T.SAND; });
    if (i < 0) continue; const x = i % W, y = (i / W) | 0;
    let far = true; w.pois.forEach(function (p) { if (Math.hypot(p.tx - x, p.ty - y) < 20) far = false; }); if (!far) continue;
    clearArea(x, y, 3);
    put(y * W + x - 1, O.TENT); ob[y * W + x + 1] = O.EMBERS; put((y - 1) * W + x + 2, O.CACHE);
    ob[(y + 2) * W + x - 2] = O.RUIN; ob[(y - 2) * W + x + 1] = O.RUIN; ob[(y + 1) * W + x + 3] = O.BONES;
    w.pois.push({ k: 'camp', tx: x, ty: y }); made++;
  }
  // hidden supply caches
  for (let k = 0, made = 0; k < 400 && made < 10; k++) {
    const i = randReach(14, 80, 20, function (j) { return (tr[j] === T.FOREST || tr[j] === T.GRASS) && !ob[j]; });
    if (i < 0) continue; put(i, O.CACHE); made++;
    const x = i % W, y = (i / W) | 0; w.pois.push({ k: 'cache', tx: x, ty: y, hidden: true });
  }
  // dangerous areas
  let dz = 0;
  for (let pass = 0; pass < 2 && dz < 3; pass++) for (let k = 0; k < 400 && dz < 3; k++) {
    const i = randReach(pass ? 28 : 44, 90, 20, function (j, x, y) { return allLand(x, y, 5); });
    if (i < 0) continue; const x = i % W, y = (i / W) | 0;
    let far = true; w.pois.forEach(function (p) { if (p.k === 'danger' && Math.hypot(p.tx - x, p.ty - y) < 30) far = false; }); if (!far) continue;
    for (let yy = y - 6; yy <= y + 6; yy++) for (let xx = x - 6; xx <= x + 6; xx++) if (inb(xx, yy) && Math.hypot(xx - x, yy - y) < 6.5 && isLandT(tr[yy * W + xx])) { tr[yy * W + xx] = T.ROCKG; ob[yy * W + xx] = 0; hp[yy * W + xx] = 0; }
    for (let c2 = 0; c2 < 5; c2++) { const a = c2 / 5 * 6.283 + 0.4; put((y + Math.round(Math.sin(a) * 3.5)) * W + x + Math.round(Math.cos(a) * 3.5), O.CRYSTAL); }
    put(y * W + x, O.CACHE); hp[y * W + x] = 2;
    ob[(y + 1) * W + x + 2] = O.BONES; ob[(y - 2) * W + x - 1] = O.BONES;
    for (let c3 = 0; c3 < 6; c3++) { const a = c3 / 6 * 6.283 + 0.9, j = (y + Math.round(Math.sin(a) * 5)) * W + x + Math.round(Math.cos(a) * 5); if (!ob[j]) put(j, O.ROCK); }
    w.pois.push({ k: 'danger', tx: x, ty: y }); dz++;
    w.spawns.push({ t: 'bear', x: (x + 2) * TILE + 16, y: (y + 2) * TILE + 16 }, { t: 'wolf', x: (x - 2) * TILE + 16, y: (y + 1) * TILE + 16 }, { t: 'wolf', x: (x + 1) * TILE + 16, y: (y - 3) * TILE + 16 });
  }
  // wildlife
  function spawnAt(t, count, minD, maxD, pred) {
    for (let k = 0, placed = 0; k < 500 && placed < count; k++) {
      const i = randReach(minD, maxD, 10, function (j) { return !ob[j] && pred(tr[j]); });
      if (i < 0) continue; w.spawns.push({ t: t, x: (i % W) * TILE + 16, y: ((i / W) | 0) * TILE + 16 }); placed++;
    }
  }
  spawnAt('rabbit', 12, 9, 90, function (t) { return t === T.GRASS; });
  spawnAt('deer', 6, 12, 90, function (t) { return t === T.GRASS || t === T.FOREST; });
  spawnAt('wolf', 5, 28, 90, function (t) { return t === T.FOREST || t === T.GRASS; });
  w.spawns.forEach(function (s, i) { s.sid = i; });
  return w;
}

function useWorld(w) {
  world = w; terr = w.terr; obj = w.obj; hpA = w.hp; floorA = w.floor; st = w.st; sr = w.sr; ss = w.ss; explored = w.explored;
  baseObj = new Uint8Array(obj); baseHp = new Uint8Array(hpA);
}

/* ---------- 6. STATE / INVENTORY ---------- */
const P = { x: 0, y: 0, vx: 0, vy: 0, kx: 0, ky: 0, fx: 0, fy: 1, hp: 100, hunger: 100, thirst: 100, stam: 100, stamDelay: 0, exh: false, cool: 0, swing: 0, inv: 0, anim: 0, moving: false, drinkCd: 0, tx: -1, ty: -1, target: null };
const G = { state: 'title', t: 0.3, day: 1, time: 0, tut: 0, tutT: 0, spawnT: 3, autoT: 45, hintT: 0, nightWarned: false, lowT: 0, stats: { kills: 0, crafted: 0, built: 0, moved: 0, drank: 0 } };
const inv = {};
let hotbar = [null, null, null, null, null, null], equipped = null, invDirty = true;
const ui = { panel: null, tab: 'all', invSel: null, chest: -1, confirm: null, prevState: null };
const B = { on: false, item: null, rot: 0, remove: false, tx: 0, ty: 0, err: null, fix: false };
let ents = [], drops = [], fires = [];
const keys = new Set(), hold = { attack: false, sprint: false }, joy = { active: false, id: -1, x: 0, y: 0, ox: 0, oy: 0 };
const mouse = { x: 0, y: 0, in: false, wx: 0, wy: 0 };
const cam = { x: 0, y: 0, shake: 0 };

function invCount(id) { return inv[id] | 0; }
function stackCount() { let n = 0; for (const k in inv) if (inv[k] > 0) n++; return n; }
function addItem(id, n) {
  n = n | 0; if (n <= 0) return 0;
  const have = inv[id] | 0;
  if (!have && stackCount() >= MAX_STACKS) return n;
  const add = Math.min(STACK_MAX - have, n);
  if (add > 0) {
    inv[id] = have + add; invDirty = true;
    if (!have && ITEMS[id].c !== 'mat' && hotbar.indexOf(id) < 0) { const s = hotbar.indexOf(null); if (s >= 0) hotbar[s] = id; }
  }
  return n - add;
}
function removeItem(id, n) {
  const have = inv[id] | 0;
  if (n <= 0 || have < n) return false;
  inv[id] = have - n; invDirty = true;
  if (inv[id] <= 0) { delete inv[id]; const s = hotbar.indexOf(id); if (s >= 0) hotbar[s] = null; if (equipped === id) equipped = null; }
  return true;
}
function canAfford(rec) { for (const k in rec.cost) if (invCount(k) < rec.cost[k]) return false; return true; }
function missingText(rec) {
  const m = [];
  for (const k in rec.cost) if (invCount(k) < rec.cost[k]) m.push((rec.cost[k] - invCount(k)) + ' more ' + ITEMS[k].n);
  return m.join(', ');
}
function collect(id, n, x, y, silent) {
  const left = addItem(id, n), got = n - left;
  if (got > 0) { floatText(x, y, '+' + got + ' ' + ITEMS[id].n, '#fff2b0'); if (!silent) SFX.play('pick'); }
  if (left > 0) { spawnDrop(id, left, P.x + (rnd() - 0.5) * 20, P.y + 10); toast('Inventory full!', 'bad'); }
  return got;
}
function curTool() { return equipped && ITEMS[equipped] && ITEMS[equipped].c === 'tool' && inv[equipped] > 0 ? ITEMS[equipped] : HAND; }
const HAND = { n: 'Fists', chop: 1, mine: 1, dmg: 1, reach: 34, cd: 0.45 };

/* ---------- 7. FX: particles, floating text, toasts ---------- */
const PN = 260, parts = [];
for (let i = 0; i < PN; i++) parts.push({ on: false, x: 0, y: 0, vx: 0, vy: 0, life: 0, max: 1, col: '#fff', sz: 2, g: 0 });
let pHead = 0;
function emitP(x, y, vx, vy, life, col, sz, g) {
  const p = parts[pHead]; pHead = (pHead + 1) % PN;
  p.on = true; p.x = x; p.y = y; p.vx = vx; p.vy = vy; p.life = life; p.max = life; p.col = col; p.sz = sz; p.g = g;
}
function burst(x, y, n, cols, spd, life, sz, g) {
  for (let i = 0; i < n; i++) { const a = rnd() * 6.283, s = spd * (0.4 + rnd() * 0.8); emitP(x, y, Math.cos(a) * s, Math.sin(a) * s - spd * 0.3, life * (0.6 + rnd() * 0.6), cols[(rnd() * cols.length) | 0], sz, g); }
}
const floats = []; for (let i = 0; i < 16; i++) floats.push({ on: false, x: 0, y: 0, t: '', life: 0, col: '#fff' });
let fHead = 0;
function floatText(x, y, t, col) { const f = floats[fHead]; fHead = (fHead + 1) % floats.length; f.on = true; f.x = x; f.y = y; f.t = t; f.life = 1.1; f.col = col || '#fff'; }
let lastToast = '', lastToastT = 0;
function toast(msg, kind) {
  const now = performance.now();
  if (msg === lastToast && now - lastToastT < 1500) return;
  lastToast = msg; lastToastT = now;
  const box = $('toasts'), el = document.createElement('div');
  el.className = 'toast' + (kind ? ' ' + kind : ''); el.textContent = msg; box.appendChild(el);
  while (box.children.length > 4) box.removeChild(box.firstChild);
  setTimeout(function () { el.classList.add('fade'); }, 2600);
  setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 3100);
}
function updateFx(dt) {
  for (let i = 0; i < PN; i++) { const p = parts[i]; if (!p.on) continue; p.life -= dt; if (p.life <= 0) { p.on = false; continue; } p.vy += p.g * dt; p.x += p.vx * dt; p.y += p.vy * dt; }
  for (let i = 0; i < floats.length; i++) { const f = floats[i]; if (!f.on) continue; f.life -= dt; f.y -= 16 * dt; if (f.life <= 0) f.on = false; }
}

/* ---------- 8. COLLISION / MOVEMENT ---------- */
function tileSolid(tx, ty) {
  if (tx < 0 || ty < 0 || tx >= W || ty >= H) return true;
  const i = ty * W + tx, t = terr[i];
  if (t <= T.SHALLOW || t === T.POND) return true;
  if (OSOLID[obj[i]]) return true;
  const s = st[i];
  if (s) { if (s === S.DOOR) return ss[i] === 0; return s !== S.FIRE; }
  return false;
}
function boxHit(x, y, hw, hh) {
  const x0 = Math.floor((x - hw) / TILE), x1 = Math.floor((x + hw - 0.001) / TILE), y0 = Math.floor((y - hh) / TILE), y1 = Math.floor((y + hh - 0.001) / TILE);
  for (let ty = y0; ty <= y1; ty++) for (let tx = x0; tx <= x1; tx++) if (tileSolid(tx, ty)) return true;
  return false;
}
function moveEnt(e, dx, dy, hw, hh) {
  let moved = false;
  if (dx) {
    if (!boxHit(e.x + dx, e.y, hw, hh)) { e.x += dx; moved = true; }
    else {
      const nud = Math.abs(dx) * 0.9;
      if (!boxHit(e.x + dx, e.y - nud, hw, hh) && !boxHit(e.x, e.y - nud, hw, hh)) e.y -= nud;
      else if (!boxHit(e.x + dx, e.y + nud, hw, hh) && !boxHit(e.x, e.y + nud, hw, hh)) e.y += nud;
    }
  }
  if (dy) {
    if (!boxHit(e.x, e.y + dy, hw, hh)) { e.y += dy; moved = true; }
    else {
      const nud = Math.abs(dy) * 0.9;
      if (!boxHit(e.x - nud, e.y + dy, hw, hh) && !boxHit(e.x - nud, e.y, hw, hh)) e.x -= nud;
      else if (!boxHit(e.x + nud, e.y + dy, hw, hh) && !boxHit(e.x + nud, e.y, hw, hh)) e.x += nud;
    }
  }
  return moved;
}
function freeTileNear(tx, ty) {
  if (!tileSolid(tx, ty)) return [tx * TILE + 16, ty * TILE + 16];
  for (let r = 1; r < 8; r++) for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) if (!tileSolid(tx + dx, ty + dy)) return [(tx + dx) * TILE + 16, (ty + dy) * TILE + 16];
  return [tx * TILE + 16, ty * TILE + 16];
}

/* ---------- 9. ENTITIES / AI ---------- */
function spawnEnt(t, x, y, sid) {
  const def = ETYPES[t];
  const e = { t: t, x: x, y: y, hp: def.hp, mhp: def.hp, kx: 0, ky: 0, dir: 1, state: 'wander', timer: rnd() * 2, tx: 0, ty: 0, cool: 0, flash: 0, anim: rnd() * 6, sid: sid === undefined ? -1 : sid, hx: x, hy: y, stuck: 0, dodge: 0, lunge: 0, moving: false, dead: false };
  ents.push(e); return e;
}
function spawnInitialEnts() {
  ents.length = 0;
  world.spawns.forEach(function (s) { if (!world.dead.has(s.sid)) spawnEnt(s.t, s.x, s.y, s.sid); });
}
function spawnDrop(id, n, x, y) {
  for (let i = 0; i < drops.length; i++) if (drops[i].n <= 0) { const d = drops[i]; d.id = id; d.n = n; d.x = x; d.y = y; d.t = 0; return; }
  if (drops.length < 60) drops.push({ id: id, n: n, x: x, y: y, t: 0 });
}
function killEnt(e) {
  e.dead = true; G.stats.kills++;
  if (e.sid >= 0) world.dead.add(e.sid);
  const def = ETYPES[e.t];
  def.drop.forEach(function (d) {
    if (d[2] < 1) { if (rnd() < d[2]) spawnDrop(d[0], d[1], e.x, e.y); } else spawnDrop(d[0], d[1] + (e.t === 'deer' ? (rnd() < 0.4 ? 1 : 0) : 0), e.x + (rnd() - 0.5) * 8, e.y);
  });
  burst(e.x, e.y - 4, 10, e.t === 'shade' ? ['#6a3fb0', '#d65cf0'] : ['#c0392b', '#e8d8b0'], 70, 0.5, 2, 120);
}
function hurtEnt(e, dmg, nx, ny, kb) {
  e.hp -= dmg; e.flash = 0.15; e.kx = nx * kb; e.ky = ny * kb;
  floatText(e.x, e.y - 14, '-' + dmg, '#ff8f7a'); SFX.play('hit');
  burst(e.x, e.y - 5, 5, ['#fff', '#ffb0a0'], 60, 0.3, 2, 100);
  if (ETYPES[e.t].hostile) e.state = 'chase'; else { e.state = 'flee'; e.timer = 3; }
  if (e.hp <= 0) killEnt(e);
}
function darkness() { return 1 - daylight(); }
function daylight() { return clamp(-Math.cos(G.t * 6.2832) * 1.5 + 0.6, 0, 1); }

function updateEnts(dt) {
  const A2 = ACTIVE_R * ACTIVE_R;
  for (let i = ents.length - 1; i >= 0; i--) {
    const e = ents[i];
    if (e.dead) { ents.splice(i, 1); continue; }
    const dx = P.x - e.x, dy = P.y - e.y, d2 = dx * dx + dy * dy;
    if (d2 > A2) { if (ETYPES[e.t].night && d2 > 900 * 900) ents.splice(i, 1); continue; }
    const def = ETYPES[e.t], dist = Math.sqrt(d2) || 1;
    if (e.flash > 0) e.flash -= dt; if (e.cool > 0) e.cool -= dt; if (e.lunge > 0) e.lunge -= dt;
    if (e.kx || e.ky) { moveEnt(e, e.kx * dt, e.ky * dt, def.hw, def.hh); const f = Math.exp(-9 * dt); e.kx *= f; e.ky *= f; if (Math.abs(e.kx) < 4) e.kx = 0; if (Math.abs(e.ky) < 4) e.ky = 0; }
    let mx = 0, my = 0, sp = 0;
    e.timer -= dt;
    if (def.hostile) {
      const det = def.det * (def.night || darkness() > 0.4 ? 1 : 0.6);
      if (e.state === 'chase') {
        if (G.state !== 'playing' || dist > det * 1.9) { e.state = 'wander'; e.timer = 1; }
        else if (dist > 18) { mx = dx / dist; my = dy / dist; sp = def.run; }
        else if (e.cool <= 0) { e.cool = def.cd; e.lunge = 0.15; damagePlayer(def.dmg, dx / dist, dy / dist); }
      } else if (dist < det && G.state === 'playing') { e.state = 'chase'; }
    } else {
      if (e.state === 'flee' || dist < 70) {
        if (e.state === 'flee' && e.timer <= 0) e.state = 'wander';
        mx = -dx / dist; my = -dy / dist; sp = def.run; if (dist < 70) { e.state = 'flee'; e.timer = 1.5; }
      }
    }
    if (!sp) {
      if (e.timer <= 0) {
        e.timer = 1 + rnd() * 2.5;
        if (rnd() < 0.45) { e.tx = 0; e.ty = 0; } else { const a = rnd() * 6.283; e.tx = Math.cos(a); e.ty = Math.sin(a); }
        const hdx = e.hx - e.x, hdy = e.hy - e.y;
        if (hdx * hdx + hdy * hdy > 180 * 180) { const hd = Math.sqrt(hdx * hdx + hdy * hdy); e.tx = hdx / hd; e.ty = hdy / hd; }
      }
      mx = e.tx; my = e.ty; sp = (mx || my) ? def.spd : 0;
    }
    if (e.dodge > 0) { e.dodge -= dt; const px = -my, py = mx; mx += px * 1.2; my += py * 1.2; }
    e.moving = false;
    if (sp > 0) {
      const l = Math.hypot(mx, my) || 1, step = sp * dt;
      const moved = moveEnt(e, mx / l * step, my / l * step, def.hw, def.hh);
      e.moving = moved; e.anim += dt * 8;
      if (mx > 0.1) e.dir = 1; else if (mx < -0.1) e.dir = -1;
      if (!moved) { e.stuck += dt; if (e.stuck > 0.35) { e.stuck = 0; if (e.state === 'wander') e.timer = 0; else e.dodge = 0.5; } } else e.stuck = 0;
    }
  }
}
function spawnLogic(dt) {
  G.spawnT -= dt; if (G.spawnT > 0) return; G.spawnT = 2.5;
  const dk = darkness(); let shades = 0, passive = 0;
  for (let i = 0; i < ents.length; i++) { if (ents[i].t === 'shade') shades++; else if (!ETYPES[ents[i].t].hostile) passive++; }
  if (dk > 0.55 && shades < Math.min(5, 2 + (G.day >> 1))) {
    for (let k = 0; k < 8; k++) {
      const a = rnd() * 6.283, d = 380 + rnd() * 140, x = P.x + Math.cos(a) * d, y = P.y + Math.sin(a) * d, tx = Math.floor(x / TILE), ty = Math.floor(y / TILE);
      if (tx > 0 && ty > 0 && tx < W - 1 && ty < H - 1 && isLandT(terr[ty * W + tx]) && !tileSolid(tx, ty)) { spawnEnt('shade', tx * TILE + 16, ty * TILE + 16, -1); break; }
    }
  } else if (dk < 0.3 && shades > 0) {
    for (let i = ents.length - 1; i >= 0; i--) if (ents[i].t === 'shade') { burst(ents[i].x, ents[i].y - 6, 8, ['#6a3fb0', '#d65cf0'], 40, 0.6, 2, -30); ents.splice(i, 1); }
  }
  if (passive < 14 && dk < 0.5) {
    for (let k = 0; k < 6; k++) {
      const a = rnd() * 6.283, d = 480 + rnd() * 200, x = P.x + Math.cos(a) * d, y = P.y + Math.sin(a) * d, tx = Math.floor(x / TILE), ty = Math.floor(y / TILE);
      if (tx > 0 && ty > 0 && tx < W - 1 && ty < H - 1 && terr[ty * W + tx] === T.GRASS && !tileSolid(tx, ty)) { spawnEnt('rabbit', tx * TILE + 16, ty * TILE + 16, -1); break; }
    }
  }
}
function updateDrops(dt) {
  for (let i = 0; i < drops.length; i++) {
    const d = drops[i]; if (d.n <= 0) continue;
    d.t += dt;
    const dx = P.x - d.x, dy = P.y - d.y, dist = Math.hypot(dx, dy);
    if (dist < 48 && d.t > 0.3) { d.x += dx / dist * 120 * dt; d.y += dy / dist * 120 * dt; }
    if (dist < 14 && d.t > 0.3) {
      const left = addItem(d.id, d.n), got = d.n - left;
      if (got > 0) { floatText(P.x, P.y - 16, '+' + got + ' ' + ITEMS[d.id].n, '#fff2b0'); SFX.play('pick'); }
      d.n = left;
      if (left > 0) { toast('Inventory full!', 'bad'); d.t = -2; }
    }
  }
}

/* ---------- 10. PLAYER ACTIONS ---------- */
function damagePlayer(n, nx, ny) {
  if (P.inv > 0 || G.state !== 'playing') return;
  P.hp -= n; P.inv = 0.6; P.kx = nx * 150; P.ky = ny * 150; cam.shake = 5;
  SFX.play('hurt'); burst(P.x, P.y - 8, 6, ['#c0392b', '#ff8f7a'], 70, 0.4, 2, 120);
  const v = $('vignette'); v.classList.add('on'); setTimeout(function () { v.classList.remove('on'); }, 120);
  if (P.hp <= 0) { P.hp = 0; die(); }
}
function tileOfPoint(x, y) { return [Math.floor(x / TILE), Math.floor(y / TILE)]; }

function tryAttack() {
  if (P.cool > 0 || G.state !== 'playing' || ui.panel || B.on) return;
  if (P.stam < 5) { toast('Too tired to swing!', 'bad'); P.cool = 0.4; return; }
  const tool = curTool();
  P.cool = tool.cd; P.swing = 0.22; P.stam -= 5; P.stamDelay = 0.8;
  SFX.play('attack');
  // entities
  let hit = false;
  for (let i = 0; i < ents.length; i++) {
    const e = ents[i]; if (e.dead) continue;
    const dx = e.x - P.x, dy = e.y - P.y, dist = Math.hypot(dx, dy);
    if (dist <= tool.reach + 8 && (dist < 16 || (dx * P.fx + dy * P.fy) / dist > 0.3)) { hurtEnt(e, tool.dmg, dx / (dist || 1), dy / (dist || 1), 170); hit = true; }
  }
  if (hit) return;
  // resources: probe in front, then aim assist
  const probes = [20, 34];
  for (let k = 0; k < probes.length; k++) {
    const t = tileOfPoint(P.x + P.fx * probes[k], P.y + P.fy * probes[k]);
    if (hitTile(t[0], t[1], tool)) return;
  }
  const ptx = Math.floor(P.x / TILE), pty = Math.floor(P.y / TILE);
  let best = null, bd = 1e9;
  for (let ty = pty - 1; ty <= pty + 1; ty++) for (let tx = ptx - 1; tx <= ptx + 1; tx++) {
    if (tx < 0 || ty < 0 || tx >= W || ty >= H) continue;
    const o = obj[ty * W + tx]; if (o !== O.TREE && o !== O.PINE && o !== O.ROCK && o !== O.CRYSTAL) continue;
    const dx = tx * TILE + 16 - P.x, dy = ty * TILE + 16 - P.y, d = Math.hypot(dx, dy);
    if (d < 52 && (dx * P.fx + dy * P.fy) / d > 0.3 && d < bd) { bd = d; best = [tx, ty]; }
  }
  if (best) hitTile(best[0], best[1], tool);
}
let hitFx = { i: -1, t: 0 };
function hitTile(tx, ty, tool) {
  if (tx < 0 || ty < 0 || tx >= W || ty >= H) return false;
  const i = ty * W + tx, o = obj[i], cx = tx * TILE + 16, cy = ty * TILE + 16;
  if (o === O.TREE || o === O.PINE) {
    const pw = tool.chop; hpA[i] = Math.max(0, hpA[i] - pw); hitFx.i = i; hitFx.t = 0.18;
    SFX.play('chop'); burst(cx, cy - 12, 5, ['#3f9a3c', '#2e7d35', '#7a4a24'], 60, 0.5, 2, 120);
    collect(S_WOOD, pw, cx, cy - 20, true);
    if (hpA[i] <= 0) { obj[i] = O.STUMP; burst(cx, cy - 8, 12, ['#3f9a3c', '#2e7d35', '#c49660'], 90, 0.7, 2, 160); toast('Tree felled'); SFX.play('pick'); }
    return true;
  }
  if (o === O.ROCK) {
    const pw = tool.mine; hpA[i] = Math.max(0, hpA[i] - pw); hitFx.i = i; hitFx.t = 0.18;
    SFX.play('mine'); burst(cx, cy - 4, 5, ['#a3a8b0', '#7e838b', '#fff'], 70, 0.4, 2, 120);
    collect('stone', pw, cx, cy - 12, true);
    if (hpA[i] <= 0) { obj[i] = O.NONE; burst(cx, cy, 10, ['#a3a8b0', '#7e838b'], 90, 0.6, 2, 160); }
    return true;
  }
  if (o === O.CRYSTAL) {
    if (tool.mine < 3) { toast('You need a Stone Pickaxe to mine crystal.', 'bad'); SFX.play('error'); return true; }
    hpA[i] = Math.max(0, hpA[i] - tool.mine); hitFx.i = i; hitFx.t = 0.18;
    SFX.play('mine'); burst(cx, cy - 6, 8, ['#7ff0ff', '#2aa7c4', '#fff'], 80, 0.6, 2, 60);
    collect('crystal', 1, cx, cy - 14, true); collect('stone', 1, cx, cy - 14, true);
    if (hpA[i] <= 0) { obj[i] = O.NONE; toast('Rare crystal harvested!', 'good'); }
    return true;
  }
  return false;
}
const S_WOOD = 'wood';

function findInteract() {
  const ptx = Math.floor(P.x / TILE), pty = Math.floor(P.y / TILE);
  let best = null, bs = 1e9;
  for (let ty = pty - 1; ty <= pty + 1; ty++) for (let tx = ptx - 1; tx <= ptx + 1; tx++) {
    if (tx < 0 || ty < 0 || tx >= W || ty >= H) continue;
    const i = ty * W + tx, o = obj[i], t = terr[i], s = st[i];
    let kind = null, label = '';
    if (s) {
      if (s === S.DOOR) { kind = 'door'; label = ss[i] ? 'Close door' : 'Open door'; }
      else if (s === S.CHEST) { kind = 'chest'; label = 'Open chest'; }
      else if (s === S.FIRE) { kind = 'fire'; label = invCount('meat') > 0 ? 'Cook meat' : 'Campfire'; }
      else if (s === S.BENCH) { kind = 'bench'; label = 'Use workbench'; }
    } else if (o === O.BERRY) { kind = 'berry'; label = 'Pick berries'; }
    else if (o === O.BUSH) { kind = 'bush'; label = 'Gather fiber'; }
    else if (o === O.MUSH) { kind = 'mush'; label = 'Pick mushroom'; }
    else if (o === O.CACHE) { kind = 'cache'; label = 'Open supply cache'; }
    else if (t === T.POND) { kind = 'drink'; label = 'Drink water'; }
    else if (t <= T.SHALLOW) { kind = 'salt'; label = 'Sea water'; }
    if (!kind) continue;
    const dx = tx * TILE + 16 - P.x, dy = ty * TILE + 16 - P.y, d = Math.hypot(dx, dy);
    if (d > 52) continue;
    const dot = (dx * P.fx + dy * P.fy) / Math.max(d, 1);
    if (kind === 'salt' && dot < 0.5) continue;
    const sc = d - dot * 10 + (kind === 'salt' ? 15 : 0);
    if (sc < bs) { bs = sc; best = { kind: kind, tx: tx, ty: ty, label: label, i: i }; }
  }
  return best;
}

const LOOT_POOL = [['wood', 3, 4], ['fiber', 2, 3], ['beans', 1, 2], ['bottle', 1, 1], ['bandage', 1, 1], ['stone', 3, 3], ['berries', 3, 3], ['cooked', 1, 1]];
function openCache(i, tx, ty) {
  const rich = hpA[i] >= 2, cx = tx * TILE + 16, cy = ty * TILE;
  let loot = [];
  if (rich) loot = [['crystal', 2 + ((rnd() * 3) | 0)], ['beans', 2], ['bandage', 1 + ((rnd() * 2) | 0)], ['bottle', 1], ['cooked', 2]];
  else {
    const pool = LOOT_POOL.slice();
    for (let k = 0; k < 3; k++) { const j = (rnd() * pool.length) | 0, p = pool.splice(j, 1)[0]; loot.push([p[0], p[1] + ((rnd() * p[2]) | 0)]); }
  }
  loot.forEach(function (l) { collect(l[0], l[1], cx, cy, true); });
  obj[i] = O.CACHEO; hpA[i] = 0; SFX.play('pick'); burst(cx, cy + 12, 10, ['#d4ae5a', '#fff2b0'], 70, 0.6, 2, 60);
  toast(rich ? 'Rare supply cache looted!' : 'Supply cache opened!', 'good');
}
function doInteract() {
  if (G.state !== 'playing' || ui.panel || B.on) return;
  const t = P.target; if (!t) { return; }
  const cx = t.tx * TILE + 16, cy = t.ty * TILE + 16, i = t.i;
  switch (t.kind) {
    case 'drink':
      if (P.drinkCd > 0) return;
      if (P.thirst >= 98) { toast('You are not thirsty.'); return; }
      P.thirst = Math.min(100, P.thirst + 28); P.drinkCd = 0.55; G.stats.drank++; SFX.play('drink');
      burst(cx, cy, 6, ['#9be3f2', '#fff'], 50, 0.4, 2, 100); floatText(P.x, P.y - 16, '+Water', '#9be3f2'); break;
    case 'salt': toast('Sea water is salty. Find a freshwater pond!', 'bad'); SFX.play('error'); break;
    case 'berry': {
      const n = 2 + ((rnd() * 2) | 0); collect('berries', n, cx, cy - 8);
      obj[i] = O.BUSHE; world.regrow.push({ i: i, t: 160, to: O.BERRY }); burst(cx, cy, 6, ['#d6304a', '#2f8a37'], 50, 0.4, 2, 100); break;
    }
    case 'bush': {
      const n = 1 + ((rnd() * 2) | 0); collect('fiber', n, cx, cy - 8);
      obj[i] = O.BUSHE; world.regrow.push({ i: i, t: 110, to: rnd() < 0.4 ? O.BERRY : O.BUSH }); burst(cx, cy, 6, ['#4fae4a', '#2f8a37'], 50, 0.4, 2, 100); break;
    }
    case 'mush': collect('mushroom', 1, cx, cy - 8); obj[i] = O.NONE; break;
    case 'cache': openCache(i, t.tx, t.ty); break;
    case 'door': ss[i] = ss[i] ? 0 : 1; SFX.play('door');
      if (ss[i] === 0 && Math.abs(P.x - cx) < 20 && Math.abs(P.y - cy) < 20) { ss[i] = 1; toast('Something is in the doorway.'); } break;
    case 'chest': ui.chest = i; openPanel('chest'); break;
    case 'bench': openPanel('craft'); break;
    case 'fire': {
      const n = Math.min(invCount('meat'), 5);
      if (n <= 0) { toast('Bring raw meat to cook it here.'); break; }
      removeItem('meat', n); collect('cooked', n, cx, cy - 10, true); SFX.play('eat'); toast('Cooked ' + n + ' meat', 'good');
      burst(cx, cy - 6, 8, ['#ffd860', '#f08a2a'], 40, 0.5, 2, -40); break;
    }
    default: break;
  }
  invDirty = true;
}
function updateRegrow(dt) {
  const rg = world.regrow;
  for (let k = rg.length - 1; k >= 0; k--) {
    const r = rg[k]; r.t -= dt;
    if (r.t <= 0) { if (obj[r.i] === O.BUSHE) obj[r.i] = r.to; rg[k] = rg[rg.length - 1]; rg.pop(); }
  }
}

/* --- consuming / hotbar --- */
function consume(id) {
  const it = ITEMS[id]; if (!it || !inv[id]) return false;
  const needF = it.food && P.hunger < 99, needW = it.water && P.thirst < 99, needH = it.heal && P.hp < 100;
  if (!needF && !needW && !needH) { toast("You don't need that right now."); return false; }
  removeItem(id, 1);
  if (it.food) P.hunger = Math.min(100, P.hunger + it.food);
  if (it.water) P.thirst = Math.min(100, P.thirst + it.water);
  if (it.heal) P.hp = Math.min(100, P.hp + it.heal);
  SFX.play(it.water && !it.food ? 'drink' : 'eat');
  floatText(P.x, P.y - 18, it.heal ? '+Health' : (it.food ? '+Food' : '+Water'), it.heal ? '#ff8f7a' : it.food ? '#f0c060' : '#9be3f2');
  return true;
}
function useHotbar(i) {
  const id = hotbar[i]; if (!id || !inv[id]) return;
  const it = ITEMS[id];
  if (it.c === 'tool') { equipped = equipped === id ? null : id; toast(equipped ? 'Equipped ' + it.n : 'Hands free'); SFX.play('click'); }
  else if (it.c === 'cons') consume(id);
  else if (it.c === 'build') startBuild(id);
  invDirty = true;
}

/* --- crafting --- */
function nearBench() {
  const ptx = Math.floor(P.x / TILE), pty = Math.floor(P.y / TILE);
  for (let y = pty - 3; y <= pty + 3; y++) for (let x = ptx - 3; x <= ptx + 3; x++) if (x >= 0 && y >= 0 && x < W && y < H && st[y * W + x] === S.BENCH) return true;
  return false;
}
function craft(id) {
  const rec = recipeOf(id); if (!rec) return;
  if (rec.bench && !nearBench()) { toast('You need to be near a Workbench.', 'bad'); SFX.play('error'); return; }
  if (!canAfford(rec)) { toast('Missing: ' + missingText(rec), 'bad'); SFX.play('error'); return; }
  const it = ITEMS[id], y = rec.yield || 1;
  if (it.c === 'tool' && invCount(id) > 0) { toast('You already have a ' + it.n + '.'); return; }
  const have = invCount(id);
  if (!have && stackCount() >= MAX_STACKS) { toast('Inventory full!', 'bad'); SFX.play('error'); return; }
  if (have + y > STACK_MAX) { toast('Stack is full.', 'bad'); return; }
  for (const k in rec.cost) removeItem(k, rec.cost[k]);
  addItem(id, y);
  if (it.c === 'tool' && !equipped) equipped = id;
  G.stats.crafted++; SFX.play('craft'); toast('Crafted ' + it.n + (y > 1 ? ' x' + y : ''), 'good');
  invDirty = true;
}

/* --- building --- */
function startBuild(id) {
  const it = ITEMS[id], rec = recipeOf(id);
  if (!invCount(id) && !(rec && canAfford(rec))) { toast('Need materials: ' + (rec ? missingText(rec) : ''), 'bad'); SFX.play('error'); return; }
  B.on = true; B.item = id; B.remove = false; B.rot = 0; B.fix = false; closePanel(true); updateBuildUI(); SFX.play('click');
}
function startRemove() { B.on = true; B.remove = true; B.item = null; B.fix = false; closePanel(true); updateBuildUI(); }
function cancelBuild() { B.on = false; B.item = null; B.remove = false; updateBuildUI(); }
function canPlace(id, tx, ty) {
  if (tx < 0 || ty < 0 || tx >= W || ty >= H) return 'Out of bounds';
  const i = ty * W + tx, t = terr[i];
  if (!isLandT(t)) return 'Cannot build on water';
  const o = obj[i]; if (o !== O.NONE && o !== O.STUMP && o !== O.EMBERS && o !== O.BONES) return 'Blocked by terrain object';
  if (Math.hypot(tx * TILE + 16 - P.x, ty * TILE + 16 - P.y) > TILE * 5.5) return 'Too far away';
  const it = ITEMS[id];
  if (it.s === 'floor') { if (floorA[i]) return 'Floor already here'; if (st[i]) return 'Tile occupied'; return null; }
  if (st[i]) return 'Tile occupied';
  if (it.s === S.FIRE) return null;
  const x0 = tx * TILE, y0 = ty * TILE;
  if (P.x + 6 > x0 && P.x - 6 < x0 + TILE && P.y + 5 > y0 && P.y - 5 < y0 + TILE) return 'You are in the way';
  for (let k = 0; k < ents.length; k++) { const e = ents[k]; if (!e.dead && e.x > x0 - 6 && e.x < x0 + TILE + 6 && e.y > y0 - 6 && e.y < y0 + TILE + 6) return 'A creature is in the way'; }
  return null;
}
function recomputeFires() { fires.length = 0; for (let i = 0; i < N; i++) if (st[i] === S.FIRE) fires.push(i); }
function placeBuild() {
  if (!B.on || G.state !== 'playing') return;
  const tx = B.tx, ty = B.ty, i = ty * W + tx;
  if (B.remove) { removeAt(tx, ty); return; }
  const id = B.item, it = ITEMS[id], err = canPlace(id, tx, ty);
  if (err) { toast(err, 'bad'); SFX.play('error'); return; }
  let paid = false;
  if (invCount(id) > 0) { removeItem(id, 1); paid = true; }
  else { const rec = recipeOf(id); if (rec && canAfford(rec)) { for (const k in rec.cost) removeItem(k, rec.cost[k]); if (rec.yield > 1) addItem(id, rec.yield - 1); paid = true; } }
  if (!paid) { toast('Out of materials.', 'bad'); SFX.play('error'); cancelBuild(); return; }
  if (obj[i] === O.STUMP || obj[i] === O.EMBERS || obj[i] === O.BONES) { obj[i] = O.NONE; hpA[i] = 0; }
  if (it.s === 'floor') floorA[i] = 1; else { st[i] = it.s; sr[i] = B.rot & 3; ss[i] = 0; if (it.s === S.CHEST) world.chests.set(i, {}); if (it.s === S.FIRE) recomputeFires(); }
  G.stats.built++; SFX.play('place'); burst(tx * TILE + 16, ty * TILE + 16, 8, ['#c49660', '#8a5a2e'], 50, 0.4, 2, 120);
  invDirty = true;
  if (!invCount(id) && !(recipeOf(id) && canAfford(recipeOf(id)))) { toast('Out of ' + it.n + 's'); cancelBuild(); }
}
function removeAt(tx, ty) {
  if (tx < 0 || ty < 0 || tx >= W || ty >= H) return;
  const i = ty * W + tx, cx = tx * TILE + 16, cy = ty * TILE + 16;
  if (Math.hypot(cx - P.x, cy - P.y) > TILE * 5.5) { toast('Too far away', 'bad'); return; }
  let item = null;
  if (st[i]) {
    for (const k in ITEMS) if (ITEMS[k].s === st[i]) item = k;
    if (st[i] === S.CHEST) { const c = world.chests.get(i) || {}; for (const k in c) collect(k, c[k], cx, cy, true); world.chests.delete(i); }
    const wasFire = st[i] === S.FIRE; st[i] = 0; sr[i] = 0; ss[i] = 0; if (wasFire) recomputeFires();
  } else if (floorA[i]) { floorA[i] = 0; item = 'floor'; }
  else { toast('Nothing of yours to remove here.'); return; }
  if (item) collect(item, 1, cx, cy, true);
  SFX.play('place'); burst(cx, cy, 6, ['#c49660', '#8a5a2e'], 50, 0.4, 2, 120); invDirty = true;
}
function updateBuildTarget() {
  if (!B.on) return;
  if (!B.fix) {
    if (mouse.in && !touchMode) { B.tx = Math.floor(mouse.wx / TILE); B.ty = Math.floor(mouse.wy / TILE); }
    else { B.tx = Math.floor((P.x + P.fx * TILE) / TILE); B.ty = Math.floor((P.y + P.fy * TILE) / TILE); }
  }
  if (B.remove) { const i = B.ty * W + B.tx; B.err = (B.tx >= 0 && B.ty >= 0 && B.tx < W && B.ty < H && (st[i] || floorA[i])) ? null : 'Nothing to remove'; }
  else B.err = canPlace(B.item, B.tx, B.ty);
  updateBuildUI();
}
function updateBuildUI() {
  const bar = $('buildBar');
  bar.classList.toggle('hidden', !B.on);
  $('btnAttack').style.visibility = B.on ? 'hidden' : 'visible'; $('btnInteract').style.visibility = B.on ? 'hidden' : 'visible';
  if (!B.on) return;
  const nm = B.remove ? 'Remove structure' : ITEMS[B.item].n + ' (x' + invCount(B.item) + ')';
  const html = '<b>' + nm + '</b> &middot; ' + (B.err ? '<span class="bad">' + B.err + '</span>' : '<span class="ok">OK to ' + (B.remove ? 'remove' : 'place') + '</span>');
  if (html !== B.lastHtml) { $('buildInfo').innerHTML = html; B.lastHtml = html; }
  $('btnRotate').style.display = (!B.remove && ITEMS[B.item].rot) ? '' : 'none';
  $('btnPlace').textContent = B.remove ? 'Remove' : 'Place';
}

/* ---------- 11. SURVIVAL / TIME ---------- */
function survival(dt) {
  const spr_ = P.sprinting ? 1.5 : 1;
  P.hunger = Math.max(0, P.hunger - HUNGER_RATE * dt * spr_);
  P.thirst = Math.max(0, P.thirst - THIRST_RATE * dt * spr_);
  P.sinceHurt = (P.sinceHurt || 0) + dt;
  G.lowT -= dt;
  if (P.hunger <= 0 || P.thirst <= 0) {
    P.hp -= 2 * dt; P.sinceHurt = 0;
    if (G.lowT <= 0) { G.lowT = 8; toast(P.thirst <= 0 ? 'You are dehydrated! Find fresh water.' : 'You are starving! Find food.', 'bad'); }
    if (P.hp <= 0) { P.hp = 0; die(); }
  } else {
    if (G.lowT <= 0 && (P.hunger < 20 || P.thirst < 20)) { G.lowT = 20; toast(P.thirst < P.hunger ? 'You are very thirsty.' : 'You are very hungry.', 'bad'); }
    if (P.hunger > 40 && P.thirst > 40 && P.hp < 100 && P.sinceHurt > 5) {
      let rate = 0.6;
      for (let k = 0; k < fires.length; k++) { const f = fires[k]; if (Math.abs((f % W) * TILE + 16 - P.x) < 100 && Math.abs(((f / W) | 0) * TILE + 16 - P.y) < 100) { rate = 1.8; break; } }
      P.hp = Math.min(100, P.hp + rate * dt);
    }
  }
  const dk = darkness();
  if (dk > 0.5 && !G.nightWarned) { G.nightWarned = true; toast('Night falls... shadows stir. Stay near a campfire.', 'bad'); }
  if (dk < 0.2) G.nightWarned = false;
}

const TUT = [
  { t: 'Move with WASD / the joystick. Hold Shift / RUN to sprint.', done: function () { return G.stats.moved > 220; } },
  { t: 'Walk up to bushes and press E / USE to gather Plant Fiber (need 4).', done: function () { return invCount('fiber') >= 4 || invCount('axe') > 0; } },
  { t: 'Face trees and press Space / HIT for Wood (8). Hit rocks for Stone (4).', done: function () { return (invCount('wood') >= 8 && invCount('stone') >= 4) || invCount('axe') > 0; } },
  { t: 'Open CRAFT and make a Wooden Axe.', done: function () { return invCount('axe') > 0 || G.stats.crafted > 0 && invCount('axe') > 0; } },
  { t: 'Craft a Stone Pickaxe and a Wooden Spear for mining and defense.', done: function () { return invCount('pickaxe') > 0 && invCount('spear') > 0; } },
  { t: 'Drink at freshwater ponds (E / USE). Sea water is salty!', done: function () { return G.stats.drank > 0; } },
  { t: 'Open BUILD: place a floor, walls and a door to make a shelter.', done: function () { let n = 0; for (let i = 0; i < N; i++) if (st[i] === S.WALL) { n++; if (n >= 4) return true; } return false; } },
  { t: 'Craft and place a Campfire. It lights the night and cooks meat.', done: function () { return fires.length > 0; } },
  { t: 'Explore! Find abandoned camps, supply caches and rare crystals.', done: function () { return G.tutT > 14; } }
];
function tutorial(dt) {
  if (G.tut >= TUT.length) return;
  G.tutT += dt;
  if (G.hintT <= 0) { G.hintT = 0.5; } else { G.hintT -= dt; return; }
  const step = TUT[G.tut];
  if (G.tutShown !== G.tut) { G.tutShown = G.tut; G.tutT = 0; $('objective').textContent = 'Goal: ' + step.t; toast(step.t); }
  if (step.done()) { G.tut++; G.tutShown = -1; if (G.tut >= TUT.length) $('objective').textContent = ''; else { G.tutShown = -1; } }
}

function die() {
  if (G.state === 'dead') return;
  G.state = 'dead'; SFX.play('death'); closePanel(true); cancelBuild();
  hold.attack = hold.sprint = false; joy.active = false; setJoy(0, 0);
  $('goStats').textContent = 'You survived ' + G.day + ' day' + (G.day > 1 ? 's' : '') + ' and defeated ' + G.stats.kills + ' creature' + (G.stats.kills === 1 ? '' : 's') + '.';
  $('btnGoLoad').style.display = hasSave() ? '' : 'none';
  show('gameover');
}

/* ---------- 12. SAVE / LOAD ---------- */
function toB64(u8) { let s = ''; for (let i = 0; i < u8.length; i += 8192) s += String.fromCharCode.apply(null, u8.subarray(i, i + 8192)); return btoa(s); }
function buildSave() {
  const changes = [], structs = [], floors = [], chests = {};
  for (let i = 0; i < N; i++) {
    if (obj[i] !== baseObj[i] || hpA[i] !== baseHp[i]) changes.push([i, obj[i], hpA[i]]);
    if (floorA[i]) floors.push(i);
    if (st[i]) structs.push([i, st[i], sr[i], ss[i]]);
  }
  world.chests.forEach(function (v, k) { chests[k] = v; });
  const runs = []; let s0 = -1;
  for (let i = 0; i <= N; i++) { const on = i < N && explored[i]; if (on && s0 < 0) s0 = i; else if (!on && s0 >= 0) { runs.push([s0, i - s0]); s0 = -1; } }
  return {
    v: SAVE_VER, seed: world.seed, savedAt: Date.now(), t: G.t, day: G.day, tut: G.tut, stats: G.stats,
    player: { x: P.x, y: P.y, fx: P.fx, fy: P.fy, hp: P.hp, hunger: P.hunger, thirst: P.thirst, stam: P.stam },
    inv: Object.assign({}, inv), hotbar: hotbar.slice(), eq: equipped,
    changes: changes, structs: structs, floors: floors, chests: chests, regrow: world.regrow.map(function (r) { return [r.i, r.t, r.to]; }),
    dead: Array.from(world.dead), explored: runs
  };
}
function saveGame(manual) {
  if (G.state === 'dead' || !world) return false;
  try {
    const old = localStorage.getItem(SAVE_KEY);
    if (old) { try { localStorage.setItem(SAVE_BAK, old); } catch (e) { /* ignore */ } }
    localStorage.setItem(SAVE_KEY, JSON.stringify(buildSave()));
    if (manual) toast('Game saved', 'good');
    return true;
  } catch (e) { if (manual) toast('Could not save (storage unavailable)', 'bad'); return false; }
}
function num(v, d, a, b) { return typeof v === 'number' && isFinite(v) ? clamp(v, a, b) : d; }
function parseSave(raw) {
  if (!raw) return null;
  let d; try { d = JSON.parse(raw); } catch (e) { return null; }
  if (!d || typeof d !== 'object' || d.v !== SAVE_VER || typeof d.seed !== 'number' || !d.player || typeof d.player !== 'object') return null;
  return d;
}
function readSaveData() {
  let d = null;
  try { d = parseSave(localStorage.getItem(SAVE_KEY)); if (!d) d = parseSave(localStorage.getItem(SAVE_BAK)); } catch (e) { d = null; }
  return d;
}
function hasSave() { try { return !!localStorage.getItem(SAVE_KEY) || !!localStorage.getItem(SAVE_BAK); } catch (e) { return false; } }
function applySave(d) {
  const w = generateWorld(d.seed | 0); useWorld(w);
  (Array.isArray(d.changes) ? d.changes : []).forEach(function (c) { if (Array.isArray(c) && c[0] >= 0 && c[0] < N) { obj[c[0]] = c[1] & 31; hpA[c[0]] = c[2] & 255; } });
  (Array.isArray(d.floors) ? d.floors : []).forEach(function (i) { if (i >= 0 && i < N) floorA[i] = 1; });
  (Array.isArray(d.structs) ? d.structs : []).forEach(function (s) { if (Array.isArray(s) && s[0] >= 0 && s[0] < N) { st[s[0]] = s[1] & 7; sr[s[0]] = s[2] & 3; ss[s[0]] = s[3] & 1; } });
  if (d.chests && typeof d.chests === 'object') for (const k in d.chests) { const c = {}; for (const id in d.chests[k]) if (ITEMS[id]) c[id] = num(d.chests[k][id], 0, 0, STACK_MAX); w.chests.set(+k, c); }
  for (let i = 0; i < N; i++) if (st[i] === S.CHEST && !w.chests.has(i)) w.chests.set(i, {});
  (Array.isArray(d.regrow) ? d.regrow : []).forEach(function (r) { if (Array.isArray(r) && r[0] >= 0 && r[0] < N) w.regrow.push({ i: r[0], t: num(r[1], 60, 0, 999), to: r[2] | 0 }); });
  (Array.isArray(d.dead) ? d.dead : []).forEach(function (s) { w.dead.add(s | 0); });
  (Array.isArray(d.explored) ? d.explored : []).forEach(function (r) { if (Array.isArray(r)) for (let i = r[0]; i < r[0] + r[1] && i < N; i++) explored[i] = 1; });
  for (const k in inv) delete inv[k];
  if (d.inv && typeof d.inv === 'object') for (const id in d.inv) if (ITEMS[id]) { const n = num(d.inv[id], 0, 0, STACK_MAX) | 0; if (n > 0) inv[id] = n; }
  hotbar = [null, null, null, null, null, null];
  if (Array.isArray(d.hotbar)) for (let i = 0; i < HOTBAR_N; i++) hotbar[i] = (typeof d.hotbar[i] === 'string' && inv[d.hotbar[i]]) ? d.hotbar[i] : null;
  equipped = (typeof d.eq === 'string' && inv[d.eq] && ITEMS[d.eq].c === 'tool') ? d.eq : null;
  const p = d.player;
  P.hp = num(p.hp, 100, 1, 100); P.hunger = num(p.hunger, 100, 0, 100); P.thirst = num(p.thirst, 100, 0, 100); P.stam = num(p.stam, 100, 0, 100);
  P.fx = p.fx === 1 || p.fx === -1 ? p.fx : 0; P.fy = p.fy === 1 || p.fy === -1 ? p.fy : 0; if (!P.fx && !P.fy) P.fy = 1;
  const f = freeTileNear(Math.floor(num(p.x, w.start.tx * TILE, 0, W * TILE - 1) / TILE), Math.floor(num(p.y, w.start.ty * TILE, 0, H * TILE - 1) / TILE));
  P.x = f[0]; P.y = f[1];
  G.t = num(d.t, 0.3, 0, 0.9999); G.day = num(d.day, 1, 1, 99999) | 0; G.tut = num(d.tut, 0, 0, TUT.length) | 0;
  if (d.stats && typeof d.stats === 'object') for (const k in G.stats) G.stats[k] = num(d.stats[k], 0, 0, 1e9);
  resetRuntime();
  return true;
}
function resetRuntime() {
  P.vx = P.vy = P.kx = P.ky = 0; P.cool = 0; P.swing = 0; P.inv = 0; P.exh = false; P.stamDelay = 0; P.sinceHurt = 10; P.target = null; P.sprinting = false;
  cam.x = P.x; cam.y = P.y; cam.shake = 0; G.state = 'paused'; G.spawnT = 3; G.autoT = 45; G.nightWarned = false; G.tutShown = -1; G.hintT = 0; G.lowT = 6;
  drops.length = 0; for (let i = 0; i < PN; i++) parts[i].on = false;
  recomputeFires(); spawnInitialEnts(); rebuildMinimap(); invDirty = true; cancelBuild();
  P.tx = -1; P.ty = -1;
}

/* ---------- minimap ---------- */
const mmEl = $('minimap'), mmCtx = mmEl.getContext('2d'), mmImg = mkCanvas(W, H), mmImgCtx = mmImg.getContext('2d');
let mmData = mmImgCtx.createImageData(W, H);
mmEl.width = W; mmEl.height = H;
const MMCOL = [[23, 63, 115], [44, 111, 176], [217, 197, 138], [90, 154, 62], [47, 106, 44], [122, 126, 134], [138, 106, 70], [58, 167, 196]];
function paintMM(i) {
  let c = MMCOL[terr[i]];
  const o = obj[i];
  if (o === O.TREE || o === O.PINE) c = [30, 80, 34]; else if (o === O.ROCK) c = [150, 154, 160]; else if (o === O.CRYSTAL) c = [120, 240, 255];
  const p = i * 4; mmData.data[p] = c[0]; mmData.data[p + 1] = c[1]; mmData.data[p + 2] = c[2]; mmData.data[p + 3] = 255;
}
function rebuildMinimap() {
  mmData = mmImgCtx.createImageData(W, H);
  for (let i = 0; i < N; i++) if (explored[i]) paintMM(i);
  mmImgCtx.putImageData(mmData, 0, 0);
}
function reveal(tx, ty, r) {
  let ch = false;
  for (let y = ty - r; y <= ty + r; y++) for (let x = tx - r; x <= tx + r; x++) {
    if (x < 0 || y < 0 || x >= W || y >= H || (x - tx) * (x - tx) + (y - ty) * (y - ty) > r * r) continue;
    const i = y * W + x; if (!explored[i]) { explored[i] = 1; paintMM(i); ch = true; }
  }
  if (ch) mmImgCtx.putImageData(mmData, 0, 0);
}
function drawMinimap() {
  mmCtx.fillStyle = '#0a0f14'; mmCtx.fillRect(0, 0, W, H);
  mmCtx.imageSmoothingEnabled = false; mmCtx.drawImage(mmImg, 0, 0);
  world.pois.forEach(function (p) {
    if (p.hidden || !explored[p.ty * W + p.tx]) return;
    mmCtx.fillStyle = p.k === 'danger' ? '#ff4030' : '#ffb840'; mmCtx.fillRect(p.tx - 2, p.ty - 2, 5, 5);
    mmCtx.fillStyle = '#000'; mmCtx.fillRect(p.tx - 1, p.ty - 1, 3, 3);
  });
  mmCtx.fillStyle = '#ff9a30'; for (let k = 0; k < fires.length; k++) mmCtx.fillRect(fires[k] % W - 1, ((fires[k] / W) | 0) - 1, 3, 3);
  const px = P.x / TILE, py = P.y / TILE, blink = ((performance.now() / 300) | 0) % 2;
  mmCtx.fillStyle = '#000'; mmCtx.fillRect(px - 3, py - 3, 7, 7); mmCtx.fillStyle = blink ? '#fff' : '#ff4a4a'; mmCtx.fillRect(px - 2, py - 2, 5, 5);
}

/* ---------- 13. RENDERING ---------- */
const cv = $('game'), ctx = cv.getContext('2d');
const lightC = mkCanvas(2, 2), lctx = lightC.getContext('2d');
const view = { w: 0, h: 0, dpr: 1, scale: 1 };
let rcx = 0, rcy = 0, touchMode = false;
const drawList = [];

function resize() {
  const dpr = Math.min(window.devicePixelRatio || 1, 2), w = window.innerWidth, h = window.innerHeight;
  view.dpr = dpr; view.w = w; view.h = h;
  cv.width = Math.floor(w * dpr); cv.height = Math.floor(h * dpr);
  const zoom = clamp(Math.round(h / (12.5 * TILE) * 20) / 20, 0.7, 2.4);
  view.scale = zoom * dpr;
  lightC.width = Math.ceil(cv.width / 2); lightC.height = Math.ceil(cv.height / 2);
}

function tvar(x, y) { return (((x * 92837111) ^ (y * 689287499)) >>> 0) & 3; }
function ovar(x, y) { return (((x * 73856093) ^ (y * 19349663)) >>> 0) & 1; }

function drawObjTile(c, tx, ty, i, o, time) {
  const x = tx * TILE, y = ty * TILE; let sx = 0;
  if (hitFx.i === i && hitFx.t > 0) sx = Math.sin(hitFx.t * 60) * 1.5;
  switch (o) {
    case O.TREE: c.drawImage(SP.tree[ovar(tx, ty)], x + sx, y - 16); break;
    case O.PINE: c.drawImage(SP.pine, x + sx, y - 16); break;
    case O.ROCK: c.drawImage(SP.rock[ovar(tx, ty)], x + sx, y); break;
    case O.CRYSTAL: c.drawImage(SP.crystal, x + sx, y); break;
    case O.BUSH: c.drawImage(SP.bush, x, y); break;
    case O.BERRY: c.drawImage(SP.berry, x, y); break;
    case O.BUSHE: c.drawImage(SP.bushe, x, y); break;
    case O.STUMP: c.drawImage(SP.stump, x, y); break;
    case O.MUSH: c.drawImage(SP.mush, x, y); break;
    case O.CACHE: c.drawImage(SP.cache, x, y); break;
    case O.CACHEO: c.drawImage(SP.cacheo, x, y); break;
    case O.TENT: c.drawImage(SP.tent, x, y); break;
    case O.RUIN: c.drawImage(SP.ruin, x, y); break;
    case O.BONES: c.drawImage(SP.bones, x, y); break;
    case O.EMBERS: c.drawImage(SP.embers, x, y); break;
    default: break;
  }
}
function drawStructTile(c, tx, ty, i, s, time) {
  const x = tx * TILE, y = ty * TILE, rot = sr[i] & 1;
  switch (s) {
    case S.WALL: c.drawImage(SP.wall[rot], x, y - 16); break;
    case S.DOOR: if (ss[i]) c.drawImage(SP.doorO, x, y - 16); else c.drawImage(SP.doorC[rot], x, y - 16); break;
    case S.CHEST: c.drawImage(SP.chest, x, y); break;
    case S.BENCH: c.drawImage(SP.bench, x, y - 14); break;
    case S.FIRE: {
      c.drawImage(SP.fire, x, y);
      const f = Math.sin(time * 14 + i) * 1.5, f2 = Math.sin(time * 19 + i * 2) * 1;
      c.fillStyle = '#e8651c'; c.beginPath(); c.moveTo(x + 11, y + 22); c.lineTo(x + 16 + f2, y + 6 + f); c.lineTo(x + 21, y + 22); c.fill();
      c.fillStyle = '#ffb83a'; c.beginPath(); c.moveTo(x + 13, y + 22); c.lineTo(x + 16 + f, y + 11 + f2); c.lineTo(x + 19, y + 22); c.fill();
      c.fillStyle = '#fff2a0'; c.fillRect(x + 15, y + 16 + f2 * 0.5, 2, 5);
      break;
    }
    default: break;
  }
}

function drawPlayer(c) {
  const x = Math.round(P.x), y = Math.round(P.y), fx = P.fx, fy = P.fy;
  const sw = Math.sin(P.anim * 2) * (P.moving ? 1 : 0), lg = sw * 3;
  shadowE(c, x, y + 6, 7, 3);
  if (P.inv > 0 && ((P.inv * 20) | 0) % 2) c.globalAlpha = 0.45;
  const bob = Math.abs(sw) * -1;
  // legs
  c.fillStyle = '#3b3a52';
  if (fx) { c.fillRect(x - 3 + lg * 0.7, y + 1, 3, 5); c.fillRect(x + 1 - lg * 0.7, y + 1, 3, 5); }
  else { c.fillRect(x - 4, y + 1 - (lg > 0 ? lg * 0.5 : 0), 3, 5 + (lg > 0 ? 0 : lg * 0.5)); c.fillRect(x + 1, y + 1 + (lg < 0 ? lg * 0.5 : 0), 3, 5 - (lg < 0 ? lg * 0.5 : lg * 0.5)); }
  // body
  c.fillStyle = '#3a6ea5'; c.fillRect(x - 5, y - 9 + bob, 10, 10); c.fillStyle = '#2f5a8a'; c.fillRect(x - 5, y - 1 + bob, 10, 2); c.fillStyle = '#4f8ac5'; c.fillRect(x - 5, y - 9 + bob, 10, 2);
  // arms
  c.fillStyle = '#e2b08a'; c.fillRect(x - 7, y - 8 + bob + lg * 0.4, 2, 6); c.fillRect(x + 5, y - 8 + bob - lg * 0.4, 2, 6);
  // head
  c.fillStyle = '#e2b08a'; c.fillRect(x - 4, y - 17 + bob, 8, 8);
  c.fillStyle = '#4a2f1b'; c.fillRect(x - 4, y - 17 + bob, 8, fy < 0 ? 8 : 3);
  if (fx) c.fillRect(x - (fx > 0 ? 4 : -2), y - 17 + bob, 2, 5);
  c.fillStyle = '#1c1208';
  if (fy > 0) { c.fillRect(x - 2, y - 13 + bob, 1, 2); c.fillRect(x + 1, y - 13 + bob, 1, 2); }
  else if (fx) c.fillRect(x + fx * 2, y - 13 + bob, 1, 2);
  // tool
  if (equipped && inv[equipped] && ITEMS[equipped].c === 'tool') {
    const sp = P.swing > 0 ? 1 - P.swing / 0.22 : 0.3, ang = (sp - 0.5) * 2.2;
    c.save(); c.translate(x + fx * 8 + (fy ? 5 : 0), y - 5 + fy * 4); c.rotate(ang + (fx < 0 ? Math.PI * 0.2 : 0) + (fy ? 0 : 0)); if (fx < 0) c.scale(-1, 1);
    c.drawImage(makeIcon(equipped), -7, -13, 16, 16); c.restore();
  }
  c.globalAlpha = 1;
  if (P.swing > 0) {
    const p = 1 - P.swing / 0.22, base = Math.atan2(fy, fx);
    c.strokeStyle = 'rgba(255,255,255,' + (0.7 * (1 - p)) + ')'; c.lineWidth = 3; c.beginPath();
    c.arc(x, y - 6, 18 + p * 6, base - 0.9 + p * 0.5, base + 0.9 + p * 0.5); c.stroke();
  }
}
function shadowE(c, x, y, rx, ry) { c.fillStyle = 'rgba(0,0,0,.28)'; c.beginPath(); c.ellipse(x, y, rx, ry, 0, 0, 6.283); c.fill(); }
function drawEnt(c, e) {
  const x = Math.round(e.x + (e.lunge > 0 ? e.dir * 3 : 0)), y = Math.round(e.y), d = e.dir, fl = e.flash > 0, an = Math.sin(e.anim) * (e.moving ? 1 : 0);
  const col = function (a) { return fl ? '#ffffff' : a; };
  switch (e.t) {
    case 'rabbit':
      shadowE(c, x, y + 2, 6, 2.5);
      c.fillStyle = col('#cdb892'); c.beginPath(); c.ellipse(x, y - 3 - Math.abs(an) * 2, 5, 3.5, 0, 0, 6.283); c.fill();
      c.beginPath(); c.arc(x + d * 4, y - 6 - Math.abs(an) * 2, 3, 0, 6.283); c.fill();
      c.fillRect(x + d * 3 - 1, y - 12 - Math.abs(an) * 2, 2, 5); c.fillRect(x + d * 5 - 1, y - 11 - Math.abs(an) * 2, 2, 4);
      c.fillStyle = col('#fff'); c.fillRect(x - d * 5, y - 4, 2, 2); c.fillStyle = '#201810'; c.fillRect(x + d * 5, y - 7 - Math.abs(an) * 2, 1, 1); break;
    case 'deer':
      shadowE(c, x, y + 3, 10, 3);
      c.fillStyle = col('#7a4f2a'); c.fillRect(x - 5, y - 2 + an, 2, 5); c.fillRect(x - 1, y - 2 - an, 2, 5); c.fillRect(x + 3, y - 2 + an, 2, 5);
      c.fillStyle = col('#9b6b3c'); c.beginPath(); c.ellipse(x, y - 8, 8, 4.5, 0, 0, 6.283); c.fill();
      c.fillRect(x + d * 7 - 1, y - 15, 3, 8); c.beginPath(); c.arc(x + d * 9, y - 15, 3, 0, 6.283); c.fill();
      c.fillStyle = col('#5a3a1c'); c.fillRect(x + d * 8 - 1, y - 21, 1, 4); c.fillRect(x + d * 10, y - 21, 1, 4); c.fillStyle = col('#f0e8d0'); c.fillRect(x - d * 8, y - 9, 2, 2); break;
    case 'wolf':
      shadowE(c, x, y + 3, 10, 3);
      c.fillStyle = col('#555a64'); c.fillRect(x - 6, y - 2 + an, 2, 5); c.fillRect(x - 2, y - 2 - an, 2, 5); c.fillRect(x + 3, y - 2 + an, 2, 5);
      c.fillStyle = col('#7c818c'); c.beginPath(); c.ellipse(x, y - 7, 8, 4.5, 0, 0, 6.283); c.fill();
      c.beginPath(); c.arc(x + d * 8, y - 9, 3.5, 0, 6.283); c.fill(); c.fillRect(x + d * 7 - 1, y - 14, 2, 3); c.fillRect(x + d * 10 - 1, y - 14, 2, 3);
      c.fillRect(x - d * 11, y - 10, 4, 2); c.fillStyle = e.state === 'chase' ? '#ff3030' : '#201810'; c.fillRect(x + d * 9, y - 10, 1, 1); break;
    case 'bear':
      shadowE(c, x, y + 4, 13, 4);
      c.fillStyle = col('#3f2815'); c.fillRect(x - 8, y - 2 + an, 4, 6); c.fillRect(x + 4, y - 2 - an, 4, 6);
      c.fillStyle = col('#5c3b22'); c.beginPath(); c.ellipse(x, y - 9, 11, 7, 0, 0, 6.283); c.fill();
      c.beginPath(); c.arc(x + d * 10, y - 12, 5, 0, 6.283); c.fill(); c.fillRect(x + d * 8 - 1, y - 18, 3, 3); c.fillRect(x + d * 12 - 1, y - 18, 3, 3);
      c.fillStyle = col('#a07850'); c.fillRect(x + d * 12, y - 11, 3, 3); c.fillStyle = e.state === 'chase' ? '#ff3030' : '#201810'; c.fillRect(x + d * 10, y - 14, 1, 1); break;
    case 'shade': {
      const f = Math.sin(e.anim * 0.6) * 2;
      c.globalAlpha = 0.85; c.fillStyle = col('#241a3b'); c.beginPath(); c.ellipse(x, y - 8 + f, 7, 9, 0, 0, 6.283); c.fill();
      c.fillRect(x - 7, y - 3 + f, 14, 6); for (let k = 0; k < 4; k++) c.fillRect(x - 7 + k * 4, y + 3 + f, 3, 3 + Math.sin(e.anim + k) * 1.5);
      c.globalAlpha = 1; c.fillStyle = '#ff4de0'; c.fillRect(x - 3, y - 11 + f, 2, 3); c.fillRect(x + 1, y - 11 + f, 2, 3); break;
    }
    default: break;
  }
  if (e.hp < e.mhp) { const w = 14; c.fillStyle = '#000'; c.fillRect(x - w / 2 - 1, y - 27, w + 2, 4); c.fillStyle = e.t === 'rabbit' || e.t === 'deer' ? '#e8a24a' : '#e24a3a'; c.fillRect(x - w / 2, y - 26, w * Math.max(0, e.hp / e.mhp), 2); }
}

function render(now) {
  const time = now / 1000, s = view.scale, w = cv.width, h = cv.height;
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.fillStyle = '#0b1a2a'; ctx.fillRect(0, 0, w, h);
  if (!world) return;
  const vw = w / s, vh = h / s;
  let camX = cam.x - vw / 2, camY = cam.y - vh / 2;
  if (cam.shake > 0) { camX += (rnd() - 0.5) * cam.shake; camY += (rnd() - 0.5) * cam.shake; }
  camX = clamp(camX, 0, Math.max(0, W * TILE - vw)); camY = clamp(camY, 0, Math.max(0, H * TILE - vh));
  camX = Math.round(camX * s) / s; camY = Math.round(camY * s) / s; rcx = camX; rcy = camY;
  ctx.setTransform(s, 0, 0, s, -camX * s, -camY * s); ctx.imageSmoothingEnabled = false;
  const x0 = Math.max(0, Math.floor(camX / TILE)), x1 = Math.min(W - 1, Math.floor((camX + vw) / TILE)), y0 = Math.max(0, Math.floor(camY / TILE)), y1 = Math.min(H - 1, Math.floor((camY + vh) / TILE));
  const wf = ((time * 2.5) | 0) & 3;
  for (let ty = y0; ty <= y1; ty++) for (let tx = x0; tx <= x1; tx++) {
    const i = ty * W + tx, t = terr[i];
    ctx.drawImage(t === T.DEEP || t === T.SHALLOW || t === T.POND ? TS[t][(wf + tx + ty) & 3] : TS[t][tvar(tx, ty)], tx * TILE, ty * TILE);
    if (floorA[i]) ctx.drawImage(SP.floor, tx * TILE, ty * TILE);
  }
  // drops
  for (let i = 0; i < drops.length; i++) { const d = drops[i]; if (d.n <= 0) continue; const bob = Math.sin(time * 4 + i) * 1.5; shadowE(ctx, d.x, d.y + 4, 5, 2); ctx.drawImage(makeIcon(d.id), Math.round(d.x - 6), Math.round(d.y - 10 + bob), 12, 12); }
  // gather visible entities
  drawList.length = 0;
  const pad = 40;
  for (let i = 0; i < ents.length; i++) { const e = ents[i]; if (!e.dead && e.x > camX - pad && e.x < camX + vw + pad && e.y > camY - pad && e.y < camY + vh + pad) drawList.push(e); }
  drawList.push(P);
  for (let i = 1; i < drawList.length; i++) { const a = drawList[i]; let j = i - 1; while (j >= 0 && drawList[j].y > a.y) { drawList[j + 1] = drawList[j]; j--; } drawList[j + 1] = a; }
  let di = 0;
  for (let ty = y0; ty <= Math.min(H - 1, y1 + 1); ty++) {
    for (let tx = x0; tx <= x1; tx++) {
      const i = ty * W + tx, o = obj[i], s2 = st[i];
      if (o) drawObjTile(ctx, tx, ty, i, o, time);
      if (s2) drawStructTile(ctx, tx, ty, i, s2, time);
    }
    while (di < drawList.length && Math.floor(drawList[di].y / TILE) <= ty) { const e = drawList[di++]; if (e === P) drawPlayer(ctx); else drawEnt(ctx, e); }
  }
  while (di < drawList.length) { const e = drawList[di++]; if (e === P) drawPlayer(ctx); else drawEnt(ctx, e); }
  // target indicator
  if (G.state === 'playing' && P.target && !B.on) {
    const t = P.target, bx = t.tx * TILE, by = t.ty * TILE, a = 2 + Math.sin(time * 8) * 1.5;
    ctx.strokeStyle = 'rgba(255,240,160,.9)'; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.moveTo(bx + 2 - a, by + 8); ctx.lineTo(bx + 2 - a, by + 2 - a); ctx.lineTo(bx + 8, by + 2 - a); ctx.moveTo(bx + 30 + a, by + 8); ctx.lineTo(bx + 30 + a, by + 2 - a); ctx.lineTo(bx + 24, by + 2 - a);
    ctx.moveTo(bx + 2 - a, by + 24); ctx.lineTo(bx + 2 - a, by + 30 + a); ctx.lineTo(bx + 8, by + 30 + a); ctx.moveTo(bx + 30 + a, by + 24); ctx.lineTo(bx + 30 + a, by + 30 + a); ctx.lineTo(bx + 24, by + 30 + a); ctx.stroke();
  }
  // build ghost
  if (B.on && G.state === 'playing') {
    const bx = B.tx * TILE, by = B.ty * TILE;
    if (B.remove) { ctx.fillStyle = B.err ? 'rgba(200,200,200,.25)' : 'rgba(230,60,40,.4)'; ctx.fillRect(bx, by, TILE, TILE); }
    else {
      ctx.globalAlpha = 0.65;
      const it = ITEMS[B.item], fake = 31;
      if (it.s === 'floor') ctx.drawImage(SP.floor, bx, by);
      else if (it.s === S.WALL) ctx.drawImage(SP.wall[B.rot & 1], bx, by - 16);
      else if (it.s === S.DOOR) ctx.drawImage(SP.doorC[B.rot & 1], bx, by - 16);
      else if (it.s === S.CHEST) ctx.drawImage(SP.chest, bx, by);
      else if (it.s === S.BENCH) ctx.drawImage(SP.bench, bx, by - 14);
      else if (it.s === S.FIRE) ctx.drawImage(SP.fire, bx, by);
      ctx.globalAlpha = 1; ctx.fillStyle = B.err ? 'rgba(230,60,40,.35)' : 'rgba(80,230,80,.3)'; ctx.fillRect(bx, by, TILE, TILE);
      ctx.strokeStyle = B.err ? '#ff6a50' : '#8aff6a'; ctx.lineWidth = 1; ctx.strokeRect(bx + 0.5, by + 0.5, TILE - 1, TILE - 1);
    }
  }
  // particles
  for (let i = 0; i < PN; i++) { const p = parts[i]; if (!p.on) continue; ctx.globalAlpha = Math.min(1, p.life / p.max * 1.5); ctx.fillStyle = p.col; ctx.fillRect(Math.round(p.x), Math.round(p.y), p.sz, p.sz); }
  ctx.globalAlpha = 1;
  renderLight(camX, camY, s, vw, vh, x0, x1, y0, y1);
  // floating text above lighting
  ctx.setTransform(s, 0, 0, s, -camX * s, -camY * s);
  ctx.font = 'bold 9px "Courier New", monospace'; ctx.textAlign = 'center'; ctx.lineWidth = 3; ctx.strokeStyle = '#000';
  for (let i = 0; i < floats.length; i++) { const f = floats[i]; if (!f.on) continue; ctx.globalAlpha = Math.min(1, f.life * 2); ctx.strokeText(f.t, f.x, f.y); ctx.fillStyle = f.col; ctx.fillText(f.t, f.x, f.y); }
  ctx.globalAlpha = 1; ctx.setTransform(1, 0, 0, 1, 0, 0);
}
function renderLight(camX, camY, s, vw, vh, x0, x1, y0, y1) {
  const dl = daylight(), dark = (1 - dl) * 0.84;
  if (dark < 0.03) return;
  const tint = clamp(1 - Math.abs(dl - 0.4) * 2.4, 0, 1);
  const r = Math.round(8 + 60 * tint), g = Math.round(12 + 18 * tint), b = Math.round(38 - 8 * tint);
  const lw = lightC.width, lh = lightC.height, k = 0.5 * s;
  lctx.globalCompositeOperation = 'source-over'; lctx.globalAlpha = 1; lctx.clearRect(0, 0, lw, lh);
  lctx.fillStyle = 'rgba(' + r + ',' + g + ',' + b + ',' + dark.toFixed(3) + ')'; lctx.fillRect(0, 0, lw, lh);
  lctx.globalCompositeOperation = 'destination-out';
  function light(x, y, rad, a) { const sx = (x - camX) * k, sy = (y - camY) * k, rr = rad * k; lctx.globalAlpha = a; lctx.drawImage(lightSpr, sx - rr, sy - rr, rr * 2, rr * 2); }
  if (G.state !== 'title') light(P.x, P.y - 6, 78, 0.6);
  const fl = 1 + Math.sin(performance.now() / 90) * 0.04;
  const vis = [];
  for (let n = 0; n < fires.length; n++) {
    const f = fires[n], fx = (f % W) * TILE + 16, fy = ((f / W) | 0) * TILE + 16;
    if (fx < camX - 160 || fx > camX + vw + 160 || fy < camY - 160 || fy > camY + vh + 160) continue;
    light(fx, fy - 4, 150 * fl, 1); vis.push(fx, fy);
  }
  lctx.globalAlpha = 1; lctx.globalCompositeOperation = 'source-over';
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.imageSmoothingEnabled = true; ctx.drawImage(lightC, 0, 0, lw, lh, 0, 0, cv.width, cv.height);
  ctx.globalCompositeOperation = 'lighter';
  for (let n = 0; n < vis.length; n += 2) { const sx = (vis[n] - camX) * s, sy = (vis[n + 1] - camY) * s, rr = 150 * fl * s; ctx.globalAlpha = dark; ctx.drawImage(fireGlow, sx - rr, sy - rr, rr * 2, rr * 2); }
  ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over'; ctx.imageSmoothingEnabled = false;
}

/* ---------- 14. UI ---------- */
const HUDFILL = {};
function setBar(id, v) { const r = Math.round(v); if (HUDFILL[id] !== r) { HUDFILL[id] = r; $(id).style.width = r + '%'; } }
let lastHud = 0, lastPrompt = '';
function updateHud(now) {
  if (now - lastHud < 80) return; lastHud = now;
  setBar('barHp', P.hp); setBar('barFood', P.hunger); setBar('barWater', P.thirst); setBar('barStam', P.stam);
  const bars = document.querySelectorAll('#bars .bar');
  bars[0].classList.toggle('low', P.hp < 25); bars[1].classList.toggle('low', P.hunger < 15); bars[2].classList.toggle('low', P.thirst < 15); bars[3].classList.toggle('low', P.exh);
  const hrs = G.t * 24, hh = Math.floor(hrs), mm = Math.floor((hrs - hh) * 60);
  $('clock').textContent = 'Day ' + G.day + ' ' + (hh < 10 ? '0' : '') + hh + ':' + (mm < 10 ? '0' : '') + mm;
  const pe = $('prompt'), txt = (!B.on && !ui.panel && P.target) ? P.target.label : '';
  if (txt !== lastPrompt) { lastPrompt = txt; pe.style.display = txt ? 'block' : 'none'; pe.textContent = txt ? (touchMode ? '' : 'E: ') + txt : ''; }
  if (invDirty) { invDirty = false; renderHotbar(); if (ui.panel === 'inv') renderInv(); if (ui.panel === 'craft') renderCraft(); if (ui.panel === 'build') renderBuildPanel(); if (ui.panel === 'chest') renderChest(); }
  drawMinimap();
  if (settings.fps) $('fps').textContent = fpsVal + ' fps';
}
function renderHotbar() {
  const hb = $('hotbar'); let html = '';
  for (let i = 0; i < HOTBAR_N; i++) {
    const id = hotbar[i];
    html += '<button class="slot' + (id && id === equipped ? ' eq' : '') + '" data-i="' + i + '"><span class="k">' + (i + 1) + '</span>' + (id ? '<img src="' + iconURL(id) + '" alt="">' + (ITEMS[id].c !== 'tool' ? '<span class="q">' + invCount(id) + '</span>' : '') : '') + '</button>';
  }
  hb.innerHTML = html;
}
function invRow(id, sel) { return '<button class="item' + (sel ? ' sel' : '') + '" data-id="' + id + '"><img src="' + iconURL(id) + '" alt=""><span class="q">' + inv[id] + '</span>' + ITEMS[id].n + '</button>'; }
function renderInv() {
  $('invCap').textContent = stackCount() + '/' + MAX_STACKS + ' slots';
  let tabs = '<button class="tab' + (ui.tab === 'all' ? ' sel' : '') + '" data-tab="all">All</button>';
  for (const k in CATS) tabs += '<button class="tab' + (ui.tab === k ? ' sel' : '') + '" data-tab="' + k + '">' + CATS[k] + '</button>';
  $('invTabs').innerHTML = tabs;
  let html = '', count = 0;
  const order = Object.keys(ITEMS);
  for (let i = 0; i < order.length; i++) { const id = order[i]; if (inv[id] > 0 && (ui.tab === 'all' || ITEMS[id].c === ui.tab)) { html += invRow(id, id === ui.invSel); count++; } }
  $('invList').innerHTML = count ? html : '<p style="font-size:12px;color:#b9ad85">Nothing here yet. Gather resources by hitting trees and rocks, or interacting with bushes.</p>';
  const d = $('invDetail'), id = ui.invSel;
  if (!id || !inv[id]) { ui.invSel = null; d.innerHTML = '<p style="font-size:12px;color:#b9ad85">Select an item.</p>'; return; }
  const it = ITEMS[id];
  let h = '<h3 style="margin:0;color:#d4ae5a">' + it.n + ' <small>x' + inv[id] + '</small></h3><div style="color:#b9ad85">' + CATS[it.c] + '</div><div>' + it.d + '</div>';
  if (it.c === 'cons') h += '<button class="btn small" data-act="use">Use</button>';
  if (it.c === 'tool') h += '<button class="btn small" data-act="equip">' + (equipped === id ? 'Unequip' : 'Equip') + '</button>';
  if (it.c === 'build') h += '<button class="btn small" data-act="build">Build</button>';
  if (it.c !== 'mat') h += '<button class="btn small" data-act="hot">' + (hotbar.indexOf(id) >= 0 ? 'Remove from hotbar' : 'Add to hotbar') + '</button>';
  h += '<button class="btn small danger" data-act="drop">Drop 1</button>';
  d.innerHTML = h;
}
function renderCraft() {
  $('craftNote').textContent = nearBench() ? 'Workbench nearby' : '';
  let html = '';
  RECIPES.forEach(function (r) {
    const it = ITEMS[r.id], ok = canAfford(r) && (!r.bench || nearBench());
    let needs = '';
    for (const k in r.cost) { const have = invCount(k); needs += '<span class="need ' + (have >= r.cost[k] ? 'yes' : 'no') + '">' + ITEMS[k].n + ' ' + have + '/' + r.cost[k] + '</span>'; }
    if (r.bench) needs += '<span class="need ' + (nearBench() ? 'yes' : 'no') + '">Workbench nearby</span>';
    html += '<div class="recipe"><img src="' + iconURL(r.id) + '" alt=""><div class="info"><b>' + it.n + (r.yield > 1 ? ' x' + r.yield : '') + '</b> <span style="color:#9d916c">(have ' + invCount(r.id) + ')</span><div class="d">' + it.d + '</div><div>' + needs + '</div></div><button class="btn small' + (ok ? '' : ' off') + '" data-craft="' + r.id + '">Craft</button></div>';
  });
  $('craftList').innerHTML = html;
}
function renderBuildPanel() {
  let html = '';
  RECIPES.forEach(function (r) {
    const it = ITEMS[r.id]; if (it.c !== 'build') return;
    const ok = invCount(r.id) > 0 || canAfford(r);
    let needs = ''; for (const k in r.cost) needs += '<span class="need ' + (invCount(k) >= r.cost[k] ? 'yes' : 'no') + '">' + ITEMS[k].n + ' ' + r.cost[k] + '</span>';
    html += '<div class="recipe"><img src="' + iconURL(r.id) + '" alt=""><div class="info"><b>' + it.n + '</b> <span style="color:#9d916c">(owned ' + invCount(r.id) + ')</span><div class="d">' + it.d + '</div><div>' + (invCount(r.id) > 0 ? '<span class="need yes">Uses 1 owned</span>' : needs) + '</div></div><button class="btn small' + (ok ? '' : ' off') + '" data-build="' + r.id + '">Place</button></div>';
  });
  html += '<div class="recipe"><div class="info"><b>Remove structures</b><div class="d">Pick up your own placed structures and get them back.</div></div><button class="btn small danger" data-build="__remove">Remove</button></div>';
  $('buildList').innerHTML = html;
}
function renderChest() {
  const c = world.chests.get(ui.chest);
  if (!c) { closePanel(); return; }
  let a = '', b = '';
  for (const id in c) if (c[id] > 0) a += '<button class="item" data-take="' + id + '"><img src="' + iconURL(id) + '" alt=""><span class="q">' + c[id] + '</span>' + ITEMS[id].n + '</button>';
  for (const id in inv) if (inv[id] > 0) b += '<button class="item" data-store="' + id + '"><img src="' + iconURL(id) + '" alt=""><span class="q">' + inv[id] + '</span>' + ITEMS[id].n + '</button>';
  $('chestList').innerHTML = a || '<p style="font-size:12px;color:#b9ad85">Empty.</p>';
  $('chestInv').innerHTML = b || '<p style="font-size:12px;color:#b9ad85">Backpack is empty.</p>';
}
const PANELS = { inv: 'panelInv', craft: 'panelCraft', build: 'panelBuild', chest: 'panelChest' };
function openPanel(name) {
  if (G.state !== 'playing') return;
  if (B.on) cancelBuild();
  if (ui.panel) $(PANELS[ui.panel]).classList.add('hidden');
  ui.panel = name; $(PANELS[name]).classList.remove('hidden'); hold.attack = hold.sprint = false; joy.active = false; setJoy(0, 0);
  invDirty = true; SFX.play('click');
  if (name === 'inv') renderInv(); else if (name === 'craft') renderCraft(); else if (name === 'build') renderBuildPanel(); else renderChest();
}
function closePanel(silent) {
  if (!ui.panel) return;
  $(PANELS[ui.panel]).classList.add('hidden'); ui.panel = null; ui.chest = -1; if (!silent) SFX.play('click');
}
function show(id) { $(id).classList.remove('hidden'); }
function hide(id) { $(id).classList.add('hidden'); }
function showConfirm(title, msg, yes, cb) {
  $('confirmTitle').textContent = title; $('confirmMsg').textContent = msg; $('confirmYes').textContent = yes; ui.confirm = cb; show('confirm');
}
function refreshTitle() {
  const has = hasSave(), d = has ? readSaveData() : null;
  $('btnContinue').classList.toggle('off', !d);
  $('saveInfo').textContent = d ? ('Saved game: Day ' + (d.day | 0) + ' - ' + new Date(d.savedAt || Date.now()).toLocaleString()) : (has ? 'Saved data is damaged and cannot be loaded.' : 'No saved game yet.');
}

/* ---------- 15. INPUT ---------- */
function setJoy(x, y) {
  joy.x = x; joy.y = y;
  const k = $('joyKnob'), r = $('joyBase').offsetWidth * 0.3;
  k.style.transform = 'translate(' + (x * r) + 'px,' + (y * r) + 'px)';
}
function initInput() {
  const zone = $('joyZone'), base = $('joyBase');
  zone.addEventListener('pointerdown', function (e) {
    if (joy.active) return; e.preventDefault();
    touchMode = e.pointerType !== 'mouse';
    joy.active = true; joy.id = e.pointerId; zone.setPointerCapture(e.pointerId);
    const zr = zone.getBoundingClientRect(), bw = base.offsetWidth;
    joy.ox = e.clientX; joy.oy = e.clientY;
    base.style.left = clamp(e.clientX - zr.left - bw / 2, 4, zr.width - bw) + 'px'; base.style.bottom = clamp(zr.bottom - e.clientY - bw / 2, 4, zr.height - bw) + 'px';
    joy.ox = zr.left + parseFloat(base.style.left) + bw / 2; joy.oy = zr.bottom - parseFloat(base.style.bottom) - bw / 2;
    SFX.init();
  });
  zone.addEventListener('pointermove', function (e) {
    if (!joy.active || e.pointerId !== joy.id) return; e.preventDefault();
    const rad = base.offsetWidth * 0.5; let dx = e.clientX - joy.ox, dy = e.clientY - joy.oy; const m = Math.hypot(dx, dy);
    if (m > rad) { dx = dx / m * rad; dy = dy / m * rad; }
    const nx = dx / rad, ny = dy / rad, mag = Math.hypot(nx, ny);
    if (mag < 0.18) setJoy(0, 0); else setJoy(nx, ny);
  });
  function endJoy(e) { if (e.pointerId !== joy.id) return; joy.active = false; joy.id = -1; setJoy(0, 0); base.style.left = ''; base.style.bottom = ''; }
  zone.addEventListener('pointerup', endJoy); zone.addEventListener('pointercancel', endJoy); zone.addEventListener('lostpointercapture', endJoy);

  function holdBtn(id, key) {
    const el = $(id);
    el.addEventListener('pointerdown', function (e) { e.preventDefault(); touchMode = e.pointerType !== 'mouse'; SFX.init(); hold[key] = true; el.classList.add('down'); el.setPointerCapture(e.pointerId); if (key === 'attack') tryAttack(); });
    const up = function () { hold[key] = false; el.classList.remove('down'); };
    el.addEventListener('pointerup', up); el.addEventListener('pointercancel', up); el.addEventListener('lostpointercapture', up);
  }
  holdBtn('btnAttack', 'attack'); holdBtn('btnSprint', 'sprint');
  $('btnInteract').addEventListener('pointerdown', function (e) { e.preventDefault(); touchMode = e.pointerType !== 'mouse'; SFX.init(); doInteract(); });

  $('btnInv').addEventListener('click', function () { SFX.init(); ui.panel === 'inv' ? closePanel() : openPanel('inv'); });
  $('btnCraft').addEventListener('click', function () { SFX.init(); ui.panel === 'craft' ? closePanel() : openPanel('craft'); });
  $('btnBuild').addEventListener('click', function () { SFX.init(); ui.panel === 'build' ? closePanel() : openPanel('build'); });
  $('btnPause').addEventListener('click', function () { pauseGame(); });
  $('btnPlace').addEventListener('click', placeBuild);
  $('btnRotate').addEventListener('click', function () { B.rot = (B.rot + 1) & 3; SFX.play('click'); });
  $('btnCancel').addEventListener('click', function () { cancelBuild(); SFX.play('click'); });
  document.querySelectorAll('.closeBtn').forEach(function (b) { b.addEventListener('click', function () { closePanel(); }); });
  document.querySelectorAll('.overlay').forEach(function (o) { o.addEventListener('pointerdown', function (e) { if (e.target === o) closePanel(); }); });

  $('hotbar').addEventListener('click', function (e) { const b = e.target.closest('.slot'); if (b && G.state === 'playing' && !ui.panel) { SFX.init(); useHotbar(+b.dataset.i); } });
  $('invTabs').addEventListener('click', function (e) { const b = e.target.closest('.tab'); if (b) { ui.tab = b.dataset.tab; SFX.play('click'); renderInv(); } });
  $('invList').addEventListener('click', function (e) { const b = e.target.closest('.item'); if (b) { ui.invSel = b.dataset.id; SFX.play('click'); renderInv(); } });
  $('invDetail').addEventListener('click', function (e) {
    const b = e.target.closest('[data-act]'); if (!b || !ui.invSel) return; const id = ui.invSel, a = b.dataset.act;
    if (a === 'use') consume(id);
    else if (a === 'equip') { equipped = equipped === id ? null : id; SFX.play('click'); }
    else if (a === 'build') { startBuild(id); return; }
    else if (a === 'hot') { const s = hotbar.indexOf(id); if (s >= 0) hotbar[s] = null; else { const f = hotbar.indexOf(null); if (f >= 0) hotbar[f] = id; else toast('Hotbar is full.', 'bad'); } SFX.play('click'); }
    else if (a === 'drop') { if (removeItem(id, 1)) { spawnDrop(id, 1, P.x + P.fx * 22, P.y + P.fy * 22); drops[drops.length - 1].t = -1.5; SFX.play('click'); } }
    invDirty = true;
  });
  $('craftList').addEventListener('click', function (e) { const b = e.target.closest('[data-craft]'); if (b) { craft(b.dataset.craft); invDirty = true; } });
  $('buildList').addEventListener('click', function (e) { const b = e.target.closest('[data-build]'); if (!b) return; if (b.dataset.build === '__remove') startRemove(); else startBuild(b.dataset.build); });
  $('chestList').addEventListener('click', function (e) {
    const b = e.target.closest('[data-take]'); if (!b) return; const c = world.chests.get(ui.chest); if (!c) return; const id = b.dataset.take, n = c[id] | 0;
    const left = addItem(id, n); if (left === n) { toast('Inventory full!', 'bad'); SFX.play('error'); return; }
    if (left > 0) c[id] = left; else delete c[id]; SFX.play('pick'); invDirty = true;
  });
  $('chestInv').addEventListener('click', function (e) {
    const b = e.target.closest('[data-store]'); if (!b) return; const c = world.chests.get(ui.chest); if (!c) return; const id = b.dataset.store, n = inv[id] | 0;
    if (!c[id] && Object.keys(c).length >= CHEST_STACKS) { toast('Chest is full.', 'bad'); SFX.play('error'); return; }
    const space = STACK_MAX - (c[id] | 0), mv = Math.min(space, n); if (mv <= 0) { toast('Stack is full.', 'bad'); return; }
    c[id] = (c[id] | 0) + mv; removeItem(id, mv); SFX.play('click'); invDirty = true;
  });

  // canvas pointer (desktop attack / mobile build aim)
  cv.addEventListener('pointerdown', function (e) {
    if (G.state !== 'playing' || ui.panel) return;
    SFX.init(); const isMouse = e.pointerType === 'mouse'; touchMode = !isMouse;
    mouseWorld(e);
    if (B.on) { if (isMouse) { B.fix = false; placeBuild(); } else { B.tx = Math.floor(mouse.wx / TILE); B.ty = Math.floor(mouse.wy / TILE); B.fix = true; } return; }
    if (isMouse && e.button === 0) tryAttack();
  });
  cv.addEventListener('pointermove', function (e) { if (e.pointerType === 'mouse') { mouse.in = true; mouseWorld(e); } });
  cv.addEventListener('pointerleave', function () { mouse.in = false; });
  cv.addEventListener('contextmenu', function (e) { e.preventDefault(); });

  window.addEventListener('keydown', onKey); window.addEventListener('keyup', function (e) { keys.delete(e.code); });
  window.addEventListener('blur', function () { keys.clear(); hold.attack = hold.sprint = false; });
  document.addEventListener('contextmenu', function (e) { e.preventDefault(); });
  document.addEventListener('gesturestart', function (e) { e.preventDefault(); });
  document.addEventListener('touchmove', function (e) { if (!e.target.closest || !e.target.closest('.scroll')) e.preventDefault(); }, { passive: false });
  document.addEventListener('dblclick', function (e) { e.preventDefault(); });
  document.addEventListener('visibilitychange', function () { if (document.hidden && G.state === 'playing') pauseGame(); });
  window.addEventListener('resize', resize); window.addEventListener('orientationchange', function () { setTimeout(resize, 200); });
  document.addEventListener('pointerdown', function () { SFX.init(); }, { once: true });
}
function mouseWorld(e) { mouse.x = e.clientX; mouse.y = e.clientY; mouse.wx = rcx + (e.clientX * view.dpr) / view.scale; mouse.wy = rcy + (e.clientY * view.dpr) / view.scale; }
function onKey(e) {
  if (e.repeat && e.code !== 'Space') { if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].indexOf(e.code) >= 0) e.preventDefault(); return; }
  keys.add(e.code);
  if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].indexOf(e.code) >= 0) e.preventDefault();
  if (!$('confirm').classList.contains('hidden')) { if (e.code === 'Escape') hide('confirm'); return; }
  if (G.state === 'paused' && e.code === 'Escape' && !$('pause').classList.contains('hidden')) { resumeGame(); return; }
  if (G.state !== 'playing') return;
  switch (e.code) {
    case 'Escape': if (ui.panel) closePanel(); else if (B.on) cancelBuild(); else pauseGame(); break;
    case 'KeyE': if (ui.panel === 'chest') closePanel(); else doInteract(); break;
    case 'KeyI': ui.panel === 'inv' ? closePanel() : openPanel('inv'); break;
    case 'KeyC': ui.panel === 'craft' ? closePanel() : openPanel('craft'); break;
    case 'KeyB': ui.panel === 'build' ? closePanel() : openPanel('build'); break;
    case 'KeyR': if (B.on && !B.remove && ITEMS[B.item].rot) { B.rot = (B.rot + 1) & 3; SFX.play('click'); } break;
    case 'KeyQ': if (B.on) cancelBuild(); break;
    case 'Enter': case 'KeyF': if (B.on) placeBuild(); break;
    default:
      if (e.code.indexOf('Digit') === 0) { const n = +e.code.charAt(5) - 1; if (n >= 0 && n < HOTBAR_N && !ui.panel) useHotbar(n); }
  }
}

/* ---------- 16. FLOW / MAIN LOOP ---------- */
let fpsVal = 0, fpsC = 0, fpsT = 0;
function updatePlayer(dt) {
  let ix = 0, iy = 0;
  if (keys.has('KeyA') || keys.has('ArrowLeft')) ix -= 1; if (keys.has('KeyD') || keys.has('ArrowRight')) ix += 1;
  if (keys.has('KeyW') || keys.has('ArrowUp')) iy -= 1; if (keys.has('KeyS') || keys.has('ArrowDown')) iy += 1;
  if (joy.active) { ix += joy.x; iy += joy.y; }
  let mag = Math.hypot(ix, iy); if (mag > 1) { ix /= mag; iy /= mag; mag = 1; }
  const wantSprint = (keys.has('ShiftLeft') || keys.has('ShiftRight') || hold.sprint) && mag > 0.1;
  if (P.exh && P.stam >= 25) P.exh = false;
  const sprinting = wantSprint && P.stam > 0.5 && !P.exh;
  P.sprinting = sprinting;
  if (sprinting) { P.stam -= 18 * dt; P.stamDelay = 0.7; if (P.stam <= 0.5) { P.stam = 0; P.exh = true; toast('Out of breath!', 'bad'); } }
  else if (P.stamDelay > 0) P.stamDelay -= dt; else P.stam = Math.min(100, P.stam + (mag < 0.1 ? 26 : 16) * dt);
  const sp = sprinting ? SPRINT : WALK, k = 1 - Math.exp(-16 * dt);
  P.vx += (ix * sp - P.vx) * k; P.vy += (iy * sp - P.vy) * k;
  const kf = Math.exp(-10 * dt); P.kx *= kf; P.ky *= kf; if (Math.abs(P.kx) < 3) P.kx = 0; if (Math.abs(P.ky) < 3) P.ky = 0;
  const ox = P.x, oy = P.y;
  moveEnt(P, (P.vx + P.kx) * dt, (P.vy + P.ky) * dt, 6, 5);
  P.x = clamp(P.x, 8, W * TILE - 8); P.y = clamp(P.y, 8, H * TILE - 8);
  const mv = Math.hypot(P.x - ox, P.y - oy); G.stats.moved += mv;
  P.moving = mv > 0.15; if (P.moving) P.anim += mv * 0.3 * (sprinting ? 1 : 1); else P.anim *= 0.8;
  if (mag > 0.25) { if (Math.abs(ix) > Math.abs(iy) * 1.05) { P.fx = ix > 0 ? 1 : -1; P.fy = 0; } else if (Math.abs(iy) > Math.abs(ix) * 1.05) { P.fy = iy > 0 ? 1 : -1; P.fx = 0; } }
  if (P.cool > 0) P.cool -= dt; if (P.swing > 0) P.swing -= dt; if (P.inv > 0) P.inv -= dt; if (P.drinkCd > 0) P.drinkCd -= dt;
  const tx = Math.floor(P.x / TILE), ty = Math.floor(P.y / TILE);
  if (tx !== P.tx || ty !== P.ty) { P.tx = tx; P.ty = ty; reveal(tx, ty, 10); }
  if (hitFx.t > 0) hitFx.t -= dt;
  if (hold.attack || keys.has('Space') || keys.has('KeyJ')) tryAttack();
  P.target = B.on ? null : findInteract();
}
function update(dt) {
  G.t += dt / DAY_LEN; if (G.t >= 1) { G.t -= 1; G.day++; toast('A new day dawns - Day ' + G.day, 'good'); }
  updatePlayer(dt); updateEnts(dt); updateDrops(dt); updateRegrow(dt); updateBuildTarget(); spawnLogic(dt); survival(dt); tutorial(dt);
  G.autoT -= dt; if (G.autoT <= 0) { G.autoT = 45; saveGame(false); }
  const k = 1 - Math.exp(-8 * dt); cam.x += (P.x - cam.x) * k; cam.y += (P.y - 8 - cam.y) * k;
  if (cam.shake > 0) cam.shake = Math.max(0, cam.shake - 30 * dt);
}
let lastT = 0, titleAng = 0;
function frame(now) {
  requestAnimationFrame(frame);
  let dt = (now - lastT) / 1000; lastT = now; if (dt > 0.1) dt = 0.1; if (dt < 0) dt = 0;
  fpsC++; fpsT += dt; if (fpsT >= 1) { fpsVal = fpsC; fpsC = 0; fpsT = 0; }
  if (G.state === 'playing' && !ui.panel) update(dt);
  else if (G.state === 'title' && world) { titleAng += dt * 0.05; cam.x = W * TILE / 2 + Math.cos(titleAng) * 700; cam.y = H * TRIM() + Math.sin(titleAng * 1.3) * 500; G.t = 0.78; }
  if (G.state === 'playing' || G.state === 'paused' || G.state === 'dead') { if (ui.panel !== null || G.state !== 'playing') { /* world frozen */ } updateFx(G.state === 'playing' && !ui.panel ? dt : 0); }
  render(now);
  if (G.state !== 'title') updateHud(now);
}
function TRIM() { return TILE / 2; }

function pauseGame() {
  if (G.state !== 'playing') return;
  closePanel(true); cancelBuild(); G.state = 'paused'; hold.attack = hold.sprint = false; joy.active = false; setJoy(0, 0); keys.clear();
  saveGame(false); show('pause'); SFX.play('click');
}
function resumeGame() { hide('pause'); hide('settings'); G.state = 'playing'; lastT = performance.now(); SFX.resume(); }
function enterGame() {
  hide('title'); hide('loading'); hide('gameover'); hide('pause'); show('hud'); $('toasts').innerHTML = ''; $('objective').textContent = '';
  updateBuildUI(); renderHotbar(); resize();
}
function startNewGame() {
  show('loading'); hide('title');
  setTimeout(function () {
    const seed = (Math.random() * 4294967295) >>> 0, w = generateWorld(seed); useWorld(w);
    for (const k in inv) delete inv[k]; hotbar = [null, null, null, null, null, null]; equipped = null;
    Object.assign(P, { hp: 100, hunger: 100, thirst: 100, stam: 100, fx: 0, fy: 1 });
    P.x = w.start.tx * TILE + 16; P.y = w.start.ty * TILE + 16;
    G.t = 0.3; G.day = 1; G.tut = 0; G.tutT = 0; G.time = 0; for (const k in G.stats) G.stats[k] = 0;
    resetRuntime(); reveal(w.start.tx, w.start.ty, 10); enterGame(); G.state = 'paused'; show('intro');
  }, 40);
}
function loadSaved(fromGameOver) {
  const d = readSaveData();
  if (!d) { toast('No valid saved game found.', 'bad'); refreshTitle(); return false; }
  show('loading'); hide('title'); hide('pause'); hide('gameover');
  setTimeout(function () {
    try { applySave(d); enterGame(); hide('loading'); G.state = 'playing'; lastT = performance.now(); toast('Game loaded', 'good'); }
    catch (err) { hide('loading'); toast('Save data is damaged.', 'bad'); showTitle(); }
  }, 40);
  return true;
}
function showTitle() {
  G.state = 'title'; hide('hud'); hide('pause'); hide('gameover'); hide('intro'); hide('loading'); closePanel(true); cancelBuild();
  if (!world) { useWorld(generateWorld((Math.random() * 4294967295) >>> 0)); }
  refreshTitle(); show('title');
}
function syncSettingsUI() { $('optSound').textContent = settings.sound ? 'ON' : 'OFF'; $('optFps').textContent = settings.fps ? 'ON' : 'OFF'; $('optVol').value = Math.round(settings.volume * 100); $('fps').style.display = settings.fps ? 'block' : 'none'; }
let settingsFrom = 'title';
function initMenus() {
  $('btnNew').addEventListener('click', function () {
    SFX.init(); SFX.play('click');
    if (hasSave()) showConfirm('Start a new game?', 'Your existing save will be replaced the next time the game saves.', 'New Game', startNewGame); else startNewGame();
  });
  $('btnContinue').addEventListener('click', function () { SFX.init(); SFX.play('click'); if ($('btnContinue').classList.contains('off')) { toast('No valid saved game found.', 'bad'); return; } loadSaved(); });
  $('btnSettings').addEventListener('click', function () { SFX.init(); SFX.play('click'); settingsFrom = 'title'; syncSettingsUI(); show('settings'); });
  $('btnBegin').addEventListener('click', function () { SFX.init(); SFX.play('click'); hide('intro'); G.state = 'playing'; lastT = performance.now(); });
  $('btnSettingsBack').addEventListener('click', function () { hide('settings'); SFX.play('click'); });
  $('optSound').addEventListener('click', function () { settings.sound = !settings.sound; SFX.apply(); saveSettings(); syncSettingsUI(); SFX.play('click'); });
  $('optFps').addEventListener('click', function () { settings.fps = !settings.fps; saveSettings(); syncSettingsUI(); });
  $('optVol').addEventListener('input', function () { settings.volume = clamp(+$('optVol').value / 100, 0, 1); SFX.apply(); saveSettings(); });
  $('optVol').addEventListener('change', function () { SFX.play('click'); });
  $('btnResume').addEventListener('click', function () { SFX.play('click'); resumeGame(); });
  $('btnSave').addEventListener('click', function () { SFX.play('click'); saveGame(true); });
  $('btnLoad').addEventListener('click', function () {
    SFX.play('click'); if (!hasSave()) { toast('No saved game to load.', 'bad'); return; }
    showConfirm('Load saved game?', 'Progress since your last save will be lost.', 'Load', function () { loadSaved(); });
  });
  $('btnPauseSettings').addEventListener('click', function () { SFX.play('click'); syncSettingsUI(); show('settings'); });
  $('btnReset').addEventListener('click', function () {
    SFX.play('click');
    showConfirm('Reset the world?', 'This permanently deletes your saved game and generates a brand new island.', 'Reset World', function () {
      try { localStorage.removeItem(SAVE_KEY); localStorage.removeItem(SAVE_BAK); } catch (e) { /* ignore */ }
      hide('pause'); startNewGame();
    });
  });
  $('btnQuit').addEventListener('click', function () { SFX.play('click'); saveGame(false); showTitle(); });
  $('btnGoLoad').addEventListener('click', function () { SFX.play('click'); loadSaved(true); });
  $('btnGoNew').addEventListener('click', function () {
    SFX.play('click'); hide('gameover');
    if (hasSave()) showConfirm('Start a new game?', 'Your existing save will be replaced the next time the game saves.', 'New Game', startNewGame); else startNewGame();
  });
  $('btnGoTitle').addEventListener('click', function () { SFX.play('click'); showTitle(); });
  $('confirmYes').addEventListener('click', function () { const cb = ui.confirm; ui.confirm = null; hide('confirm'); if (cb) cb(); });
  $('confirmNo').addEventListener('click', function () { ui.confirm = null; hide('confirm'); if (G.state === 'dead') show('gameover'); });
}

function boot() {
  loadSettings(); buildTerrain(); buildObjSprites();
  Object.keys(ITEMS).forEach(makeIcon);
  resize(); initInput(); initMenus(); syncSettingsUI();
  setTimeout(function () { showTitle(); }, 30);
  requestAnimationFrame(function (t) { lastT = t; requestAnimationFrame(frame); });
}
boot();
})();
