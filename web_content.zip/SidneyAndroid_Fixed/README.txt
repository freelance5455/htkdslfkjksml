SIDNEY ASSISTENTE - CORREÇÃO DO ERRO DE WEBVIEW

Correção principal:
- O index.html agora fica em app/src/main/assets/index.html.
- A MainActivity NÃO tenta mais abrir diretamente https://appassets.androidplatform.net/web/index.html.
- O HTML é carregado localmente com loadDataWithBaseURL usando a base HTTPS https://appassets.androidplatform.net/web/.
- Isso elimina o ERR_HTTP_RESPONSE_CODE_FAILURE mostrado no aparelho.
- JavaScript, armazenamento local, microfone, internet e ponte Android para TTS estão habilitados.
- O TTS usa pt-BR e tenta selecionar uma voz masculina quando o mecanismo do aparelho expõe uma voz identificada como masculina. Se o aparelho não oferecer uma voz masculina pt-BR, ele usa a voz pt-BR disponível.

Como gerar o APK:
1. Abra esta pasta no Android Studio.
2. Espere o Gradle sincronizar.
3. Vá em Build > Build APK(s).
4. Instale o APK gerado no celular.

Observação:
- A chave da Gemini continua sendo informada no próprio aplicativo, conforme o HTML original. Não foi embutida uma chave no APK.
