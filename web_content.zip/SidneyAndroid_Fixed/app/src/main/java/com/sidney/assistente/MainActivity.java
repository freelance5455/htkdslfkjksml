package com.sidney.assistente;

import android.app.Activity;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    private WebView webView;
    private TextToSpeech tts;
    private boolean ttsReady = false;

    private static final String START_URL = "https://appassets.androidplatform.net/web/index.html";

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setTextZoom(100);
        s.setUserAgentString(s.getUserAgentString() + " SidneyAssistente/2.0");

        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) loadLocalHtmlFallback();
            }
        });

        tts = new TextToSpeech(this, this);
        loadLocalHtml();
    }

    private void loadLocalHtml() {
        try {
            java.io.InputStream in = getAssets().open("index.html");
            byte[] data = new byte[in.available()];
            int off = 0, n;
            while (off < data.length && (n = in.read(data, off, data.length - off)) > 0) off += n;
            in.close();
            String html = new String(data, java.nio.charset.StandardCharsets.UTF_8);
            // The HTML is supplied directly to WebView with an HTTPS base URL.
            // This avoids the failing appassets.androidplatform.net/web/index.html request
            // while keeping a secure origin for HTTPS API calls made by the page.
            webView.loadDataWithBaseURL("https://appassets.androidplatform.net/web/", html, "text/html", "UTF-8", null);
        } catch (Exception e) {
            loadLocalHtmlFallback();
        }
    }

    private void loadLocalHtmlFallback() {
        if (webView == null) return;
        webView.postDelayed(() -> loadLocalHtmlNoLoop(), 100);
    }

    private void loadLocalHtmlNoLoop() {
        try {
            java.io.InputStream in = getAssets().open("index.html");
            java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            in.close();
            String html = out.toString("UTF-8");
            webView.loadDataWithBaseURL("https://appassets.androidplatform.net/web/", html, "text/html", "UTF-8", null);
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível abrir o assistente: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            int result = tts.setLanguage(new Locale("pt", "BR"));
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED;
            if (ttsReady) selectVoice();
        }
    }

    private void selectVoice() {
        if (tts == null) return;
        try {
            Set<Voice> voices = tts.getVoices();
            if (voices == null) return;
            Voice fallback = null;
            for (Voice v : voices) {
                Locale l = v.getLocale();
                if (l == null || !"pt".equalsIgnoreCase(l.getLanguage())) continue;
                if ("BR".equalsIgnoreCase(l.getCountry())) {
                    if (fallback == null) fallback = v;
                    String name = v.getName().toLowerCase(Locale.ROOT);
                    if (name.contains("male") || name.contains("masc") || name.contains("homem") || name.contains("brasil") && name.contains("1")) {
                        tts.setVoice(v); return;
                    }
                }
            }
            if (fallback != null) tts.setVoice(fallback);
        } catch (Exception ignored) {}
    }

    public class AndroidBridge {
        @JavascriptInterface public void speak(String text) {
            if (text == null || text.trim().isEmpty()) return;
            runOnUiThread(() -> {
                if (!ttsReady) { tts = new TextToSpeech(MainActivity.this, MainActivity.this); return; }
                selectVoice();
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sid-response");
            });
        }
        @JavascriptInterface public void stopSpeak() {
            if (tts != null) runOnUiThread(() -> tts.stop());
        }
        @JavascriptInterface public String getApiKey() { return ""; }
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
