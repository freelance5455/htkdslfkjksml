npm install -D gh-pages
# أضف إلى package.json: "homepage": "https://USERNAME.github.io/mobile-code-studio"
npm run build
npx gh-pages -d dist