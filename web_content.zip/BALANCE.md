# Balance notes (v10.0.0)

Measured with automated runs (Node, deterministic seeds, nobody playing the player's nation; the AI plays all others).

## Old World 1936 (44 nations, 377 land provinces)
| Check | Result |
|---|---|
| Nations alive after 1 / 3 / 5 years | about 42 / 36-38 / 29-35 (small nations are absorbed; large powers survive) |
| Largest nation | Soviet Union 66 -> 73-83 provinces in 5 years (about 20%); no AI reached the 30% domination threshold |
| Simultaneous wars | 12-25 war pairs (alliances pull nations in) |
| Speed (Node, no rendering) | about 8 ms per game day |

## Empires (7 fictional nations, 61 provinces)
| Check | Result |
|---|---|
| Nations alive after 4 years | 4-6 of 7 |
| Largest nation | 17-30 provinces (28-49%) |
| Speed | under 1 ms per game day |

## Rules that shape balance
- Victory thresholds: Old World 30% land / 45% with allies; Empires 50% / 65%.
- AI difficulty (menu): Easy (grace 240 days, rare attacks, income 90%), Normal (150 days), Hard (90 days, income 115%).
- Event sizes scale with the nation's economy (gold) and manpower pool; they are small compared with monthly income so no single event decides a game.
- Goals pay modest gold and manpower (roughly one to two weeks of income).

## Known balance limits
- The Soviet Union is deliberately large and holds first place most of the time; the Old World campaign is a hard mode for small nations.
- A player who never acts is usually conquered within 2-4 years in the Old World scenario.
- AI nations see more than a player would (no fog of war for the AI).
