# Ball Camera Android wrapper

This project wraps the supplied `index.html` in an Android WebView and fixes the Camera permission path needed by `getUserMedia()`.

Key points:
- Android `CAMERA` permission is declared.
- Runtime camera permission is requested.
- WebView `PermissionRequest` grants `RESOURCE_VIDEO_CAPTURE` after Android permission is granted.
- `WebViewAssetLoader` serves the HTML at the HTTPS-style `appassets.androidplatform.net` origin so browser camera APIs can run in a secure origin.
- `INTERNET` permission is included because the supplied HTML loads Tesseract.js from jsDelivr.

Open the folder in Android Studio and build the APK. Internet access is required the first time Gradle downloads Android/AndroidX dependencies.
