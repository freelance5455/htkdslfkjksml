Vita+ Saúde - projeto Android

Como gerar o APK:
1. Instale o Android Studio.
2. Abra a pasta VitaPlus-Android.
3. Aguarde o Gradle sincronizar e instalar os componentes pedidos.
4. Menu Build > Build Bundle(s) / APK(s) > Build APK(s).
5. O APK de debug ficará em app/build/outputs/apk/debug/app-debug.apk.

Package ID: com.vitaplus.saude
Min Android: 7.0 (API 24)

O aplicativo é um projeto educacional. Os registros de saúde são armazenados localmente no aparelho pelo próprio app. Ele não substitui avaliação profissional.
