# Universe Sandbox v0.4

A mobile-first 3D gravity + exotic-physics sandbox in Three.js r160. No build step, no npm; dependencies load from unpkg via import maps (internet needed on first load).

## Run it
Browsers block ES modules on `file://`, so double-clicking `index.html` shows a blank page. Serve the folder:

- **Computer:** `cd universe-sandbox && python3 -m http.server 8000`, open http://localhost:8000
- **Phone (same Wi-Fi):** open `http://<computer-ip>:8000`
- **No computer:** upload the folder to Netlify Drop, GitHub Pages or Cloudflare Pages
- **APK later:** wrap with Capacitor (serves over a local origin, so modules work)

## Controls
- **Place:** pick a category tab (Stars, Planets, Compact, Exotic, Particles, Tools) and a type, then tap the sheet. ⚠ marks SPECULATIVE types. Default velocity is a circular orbit around the most massive body (particles with `launch` fly off in a random direction; wormholes and strings stay put).
- **Select:** tap a body. Panel shows mass, speed, distance to primary, plus **this body's mass ×** and **gravity ×** sliders, Focus and Delete.
- **Camera:** one finger rotates; two fingers pinch-zoom and pan. The **move pad** (bottom right) flies the camera: ▲▼◀▶ move across the map, ⬆⬇ go up/down, ⌂ goes home. Keyboard: WASD/arrows, Q/E. Speed scales with zoom.
- **⚙ Fields panel:** sliders for everything (below), the **sheet size** (20 to 5000 AU; it is also the placement limit), and a mass slider for every object and particle type.
- **Time:** 0× to 4× slider, pause, reset scenario, trails toggle.
- **Secret lab:** exists. Tap the word "Speed" seven times quickly (or enter the Konami code on a keyboard).

## Units
Length = AU, mass = solar masses (M☉), time = years, so **G = 4π²**. One simulated year = 4 s at 1×.

## Honesty labels
- **REAL**: standard physics implemented as stated (within numerical error).
- **SIMPLIFIED**: deliberate approximation or numerical device.
- **SPECULATIVE**: not established physics, or a toy; exploration only.
Every slider shows its label in the panel; the source comments say the same.

## What the simulation does
- Pairwise Newtonian gravity between all bodies, velocity Verlet, softened (REAL form; softening SIMPLIFIED)
- **G×, force-law exponent, Higgs vev, per-type mass, per-body mass and gravity**: SPECULATIVE (the real constants cannot change; per-body gravity ≠ 1 breaks Newton's 3rd law). Only the Higgs-given fraction of mass follows the Higgs slider (~1% for nucleon-like matter, 100% for electrons and neutrinos; "Ludicrous Higgs" makes it 100% for everything)
- **Electromagnetism** (Coulomb form, scaled constant) and **strong force** (Yukawa-style, nucleons only) with sliders: SIMPLIFIED. Protons can "fuse" when pulled together
- **Weak force**: free neutrons decay into proton + electron + anti-neutrino; the slider scales the rate (REAL process, SIMPLIFIED timescale and momentum)
- **Antimatter**: gravitates like matter; annihilates with matter on contact, remainder keeps the larger body's velocity (photon momentum not tracked)
- **Dark energy** H² slider: outward a = H²·r from the origin (Newtonian stand-in, SIMPLIFIED). Negative values crunch
- **Phantom energy / Big Rip**: H² grows as 1/(1 − t/T)². Bodies are shredded when tidal pull beats surface gravity, cascading into debris (SPECULATIVE; real timing differs because radii are inflated)
- **Vacuum decay**: Tools → ☢, tap to nucleate a bubble that expands at the slider speed and destroys everything inside (SPECULATIVE)
- **Wormholes**: place two; entering one exits the other (SPECULATIVE). **Cosmic strings**: no Newtonian pull (real property), plus a toy sideways tug (SPECULATIVE)
- **Negative mass**, **zombie matter** (infects what it touches, respawns 4 s after deletion; fiction), **dark matter** (collisionless, gravity only, SIMPLIFIED)

## What it does NOT do
No relativity (the speed limit slider is a numerical clamp, not c), no event horizons, no real magnetic fields (`magnetarFieldStub` is an uncalled stub), no rotation, tides, radiation, or fragmentation except Big Rip debris. Masses of SMBHs and particles are scaled so everything fits one sandbox. Max 220 bodies.

## Extending
- **New type:** add one `T(...)` line to `BODY_TYPES` in `js/bodies.js` (it appears in the palette and the mass sliders).
- **New scenario:** append a plain object to `SCENARIOS` in `js/scenarios.js` (`{type,pos,vel}` or `{type,around,r,angle}`).
- **New slider:** append a row to `FIELD_DEFS` in `js/fields.js`, then read `fields.<id>` in `physics.js` or `effects.js`.
- **New secret:** append to `makeSecrets` in `js/effects.js`.
