// =====================================================================
// ui.js — builds and wires all DOM controls. No simulation logic here.
// =====================================================================
import { FIELD_DEFS } from './fields.js';
import { fields } from './physics.js';

const $ = (id) => document.getElementById(id);
const fmt = (v) => Number(v.toPrecision(3)).toString();
const el = (tag, txt, cls) => { const e = document.createElement(tag); if (txt != null) e.textContent = txt; if (cls) e.className = cls; return e; };

export function initUI({ types, scenarios, defaultType, getSel, h }) {
  const syncers = [];

  // ----- Palette: category tabs + type buttons (⚠ = SPECULATIVE) -----
  const groups = [...new Set(types.map((t) => t.group))], tabs = $('tabs'), pal = $('palette');
  let cur = types.find((t) => t.id === defaultType).group, curType = defaultType;
  function drawPalette() {
    pal.replaceChildren();
    for (const t of types.filter((x) => x.group === cur)) {
      const b = el('button', t.name, (t.speculative ? 'spec ' : '') + (t.id === curType ? 'active' : ''));
      b.onclick = () => { curType = t.id; h.onType(t.id); pal.querySelectorAll('button').forEach((x) => x.classList.toggle('active', x === b)); };
      pal.append(b);
    }
  }
  for (const g of groups) {
    const b = el('button', g, g === cur ? 'active' : '');
    b.onclick = () => { cur = g; tabs.querySelectorAll('button').forEach((x) => x.classList.toggle('active', x === b)); drawPalette(); };
    tabs.append(b);
  }
  drawPalette();

  // ----- Top bar -----
  const sel = $('scenario'); for (const s of scenarios) sel.add(new Option(s.name, s.id));
  sel.onchange = () => h.onScenario(sel.value);
  $('pause').onclick = () => { $('pause').textContent = h.onPause() ? '▶' : '⏸'; };
  $('reset').onclick = () => h.onReset();
  $('trails').onclick = () => $('trails').classList.toggle('on', h.onTrails());
  $('fbtn').onclick = () => { $('fields').hidden = !$('fields').hidden; $('fbtn').classList.toggle('on', !$('fields').hidden); };
  $('speed').oninput = (e) => { $('speedval').textContent = (+e.target.value).toFixed(1) + '×'; h.onSpeed(+e.target.value); };
  $('focus').onclick = () => h.onFocus();
  $('delete').onclick = () => h.onDelete();
  $('hide').onclick = () => h.onHide();

  // ----- Fields panel (generated from FIELD_DEFS + one mass slider per object/particle type) -----
  const panel = $('fields');
  function slider(label, tag, min, max, step, log, get, set) {
    const row = el('label', null, 'srow'), out = el('b'), i = el('input');
    i.type = 'range'; i.min = min; i.max = max; i.step = step;
    const sync = () => { const v = get(); i.value = log ? Math.log10(Math.abs(v) || 1e-9) : v; out.textContent = fmt(v); };
    i.oninput = () => { const x = log ? 10 ** +i.value : +i.value; set(x); out.textContent = fmt(x); };
    row.append(el('span', label + (tag ? ` [${tag}]` : '')), out, i); panel.append(row); syncers.push(sync); sync();
  }
  let lastGroup = '';
  for (const d of FIELD_DEFS) {
    if (d.group !== lastGroup) { panel.append(el('h4', d.group)); lastGroup = d.group; }
    slider(d.label, d.tag, d.min, d.max, d.step, d.log, () => fields[d.id], (v) => { fields[d.id] = v; h.onField(d.id); });
  }
  panel.append(el('h4', 'Mass of every object & particle (× default)'));
  for (const t of types.filter((x) => x.mass !== undefined)) {
    slider(t.name, t.speculative ? 'SPECULATIVE' : '', -3, 3, 0.05, true, () => fields.kindMass[t.id] ?? 1, (v) => { fields.kindMass[t.id] = v; });
  }
  const rip = el('button', 'Start Big Rip (phantom energy)');
  const setRip = (on) => { rip.textContent = on ? 'Stop Big Rip' : 'Start Big Rip (phantom energy)'; rip.classList.toggle('on', on); };
  rip.onclick = () => setRip(h.onRip());
  const rf = el('button', 'Reset all fields to defaults'); rf.onclick = () => h.onResetFields();
  panel.append(el('h4', 'Actions'), rip, rf);

  // ----- Selected-body sliders: this body's mass × and gravity × -----
  $('bmass').oninput = (e) => { const b = getSel(); if (b) { b.mulM = 10 ** +e.target.value; $('mv').textContent = fmt(b.mulM); } };
  $('bgrav').oninput = (e) => { const b = getSel(); if (b) { b.gs = +e.target.value; $('gv').textContent = fmt(b.gs); } };

  // ----- Move pad (hold to fly; also WASD/arrows, Q/E on keyboard) -----
  const pad = $('pad');
  for (const item of [['⌂', 'home'], ['▲', 'f'], ['⬆', 'u'], ['◀', 'l'], null, ['▶', 'r'], ['⬇', 'd'], ['▼', 'b']]) {
    if (!item) { pad.append(el('span')); continue; }
    const [txt, dir] = item;
    const b = el('button', txt);
    if (dir === 'home') b.onclick = () => h.onHome();
    else {
      b.onpointerdown = (e) => { e.preventDefault(); h.onMove(dir, true); };
      for (const ev of ['onpointerup', 'onpointerleave', 'onpointercancel']) b[ev] = () => h.onMove(dir, false);
    }
    pad.append(b);
  }

  // ----- Secret lab -----
  let taps = 0, tapT = 0;
  $('speedlbl').onclick = () => { const n = performance.now(); taps = n - tapT < 1500 ? taps + 1 : 1; tapT = n; if (taps >= 7) { taps = 0; api.toggleSecret(); } };

  const api = {
    setInfo(html) { $('info').hidden = html === null; if (html !== null) $('infotxt').innerHTML = html; },
    bindSel(b) {
      if (!b) return;
      $('bmass').value = Math.log10(b.mulM); $('mv').textContent = fmt(b.mulM);
      $('bgrav').value = b.gs; $('gv').textContent = fmt(b.gs);
    },
    setFollow(on) { $('focus').textContent = on ? 'Unfocus' : 'Focus'; $('focus').classList.toggle('on', on); },
    sync() { syncers.forEach((f) => f()); },
    setRip,
    setHud(t) { $('hud').textContent = t; },
    initSecret(list) {
      const s = $('secret'); s.append(el('b', '🔮 Secret lab'));
      for (const it of list) { const b = el('button', it.name); b.onclick = () => it.run(); s.append(b); }
    },
    toggleSecret() { $('secret').hidden = !$('secret').hidden; },
  };
  return api;
}
