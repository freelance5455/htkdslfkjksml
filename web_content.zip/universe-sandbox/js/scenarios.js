// =====================================================================
// scenarios.js — preset setups as PLAIN DATA. Add one by appending an object.
// Body spec (units: AU, M☉, AU/yr):
//   { type, pos:[x,y,z], vel:[x,y,z] }                 explicit state
//   { type, around:<index of earlier body>, r, angle }   circular orbit in y=0 plane (SIMPLIFIED)
// Optional per body: name, mass, radius. Optional per scenario: camera:[x,y,z].
// `type` is any id from BODY_TYPES. Wormhole mouths link in the order listed.
// =====================================================================
const SUN = { type: 'star', pos: [0, 0, 0], name: 'Sun' };

export const SCENARIOS = [
  { id: 'single', name: 'Single Planet', bodies: [SUN, { type: 'planet', around: 0, r: 1, angle: 0, name: 'Earth-like' }] },

  { id: 'binary', name: 'Binary Star', camera: [0, 9, 12], bodies: [
    // Equal 1 M☉ stars 1 AU apart: v = sqrt(G·m / (2·d)) ≈ 4.443 AU/yr about the centre of mass
    { type: 'star', pos: [0.5, 0, 0], vel: [0, 0, 4.443], name: 'Star A' },
    { type: 'star', pos: [-0.5, 0, 0], vel: [0, 0, -4.443], name: 'Star B' },
    { type: 'planet', pos: [4, 0, 0], vel: [0, 0, 4.443] },   // circumbinary: v = sqrt(G·2/4)
  ] },

  { id: 'triple', name: 'Triple Star (hierarchical)', camera: [0, 8, 10], bodies: [
    // A (1 M☉) + B (0.5 M☉) 0.4 AU apart, relative speed sqrt(G·1.5/0.4) = 12.17; centre of mass at origin
    { type: 'star', pos: [-0.1333, 0, 0], vel: [0, 0, -4.056], name: 'Star A' },
    { type: 'reddwarf', pos: [0.2667, 0, 0], vel: [0, 0, 8.113], mass: 0.5, name: 'Star B' },
    { type: 'planet', pos: [3, 0, 0], vel: [0, 0, 4.443], name: 'Circumbinary' },
  ] },

  { id: 'reddwarf', name: 'Red Dwarf System', camera: [0, 1.5, 2], bodies: [
    { type: 'reddwarf', pos: [0, 0, 0], name: 'Proxima-like' },
    { type: 'planet', around: 0, r: 0.15, angle: 0, radius: 0.015, name: 'b' },
    { type: 'planet', around: 0, r: 0.3, angle: 2, radius: 0.015, name: 'c' },
    { type: 'icegiant', around: 0, r: 0.55, angle: 4, radius: 0.02, name: 'd' },
  ] },

  { id: 'moons', name: 'Planet with Moons', camera: [0, 1.5, 2.5], bodies: [
    SUN,
    { type: 'planet', around: 0, r: 1, angle: 0, mass: 1e-3, radius: 0.012, name: 'Giant' },  // Jupiter-mass so its Hill sphere holds moons
    { type: 'moon', around: 1, r: 0.025, angle: 0, radius: 0.006, name: 'Moon I' },
    { type: 'moon', around: 1, r: 0.04, angle: 2.5, radius: 0.006, name: 'Moon II' },
  ] },

  { id: 'nsbinary', name: 'Neutron Star Binary', camera: [0, 0.6, 0.9], bodies: [
    // 1.4 + 1.4 M☉, 0.2 AU apart: v = 0.5·sqrt(G·2.8/0.2) ≈ 11.75 each
    { type: 'neutron', pos: [0.1, 0, 0], vel: [0, 0, 11.75], name: 'NS A' },
    { type: 'neutron', pos: [-0.1, 0, 0], vel: [0, 0, -11.75], name: 'NS B' },
  ] },

  { id: 'bhstar', name: 'Black Hole + Star', camera: [0, 4, 6], bodies: [
    { type: 'blackhole', pos: [0, 0, 0], name: 'Black hole' },
    { type: 'star', around: 0, r: 3, angle: 0, name: 'Companion' },
    { type: 'planet', around: 1, r: 0.3, angle: 1, radius: 0.015, name: 'Survivor' },
  ] },

  { id: 'flyby', name: 'Magnetar Flyby', camera: [0, 9, 13], bodies: [
    SUN,
    { type: 'planet', around: 0, r: 1, angle: 0, name: 'Earth-like' },
    { type: 'planet', around: 0, r: 2.2, angle: 3, name: 'Outer planet' },
    { type: 'magnetar', pos: [-8, 0, 4], vel: [3.5, 0, -1.0], name: 'Magnetar' },   // SPECULATIVE object, gravity only
  ] },

  { id: 'worm', name: 'Wormhole Playground', camera: [0, 6, 7], bodies: [
    SUN,
    { type: 'planet', around: 0, r: 1, angle: 3.14159, name: 'Traveller' },
    { type: 'wormhole', pos: [1.05, 0, 0] }, { type: 'wormhole', pos: [-2.2, 0, 1] },
  ] },

  { id: 'string', name: 'Cosmic String Crossing', camera: [0, 3, 4], bodies: [
    SUN, { type: 'planet', around: 0, r: 1, angle: 0, name: 'Earth-like' }, { type: 'string', pos: [1.1, 0, 0.8] },
  ] },

  { id: 'zombie', name: 'Zombie Outbreak', camera: [0, 5, 7], bodies: [
    SUN,
    { type: 'planet', around: 0, r: 0.7, angle: 0 }, { type: 'planet', around: 0, r: 1.2, angle: 2 }, { type: 'gasgiant', around: 0, r: 2, angle: 4 },
    { type: 'zombie', pos: [2.5, 0, 0], vel: [0, 0, 1.5], name: 'Patient zero' },
  ] },

  { id: 'lab', name: 'Particle Lab', camera: [0, 1.2, 1.6], bodies: [
    { type: 'proton', pos: [0, 0, 0] }, { type: 'proton', pos: [0.07, 0, 0.02] }, { type: 'freeneutron', pos: [-0.12, 0, -0.1] },
    { type: 'freeneutron', pos: [0.1, 0, -0.2] }, { type: 'electron', pos: [0.3, 0, 0], vel: [0, 0, 1.2] },
    { type: 'electron', pos: [-0.3, 0, 0.1], vel: [0, 0, -1.2] }, { type: 'positron', pos: [0.8, 0, 0], vel: [-1.5, 0, 0] },
    { type: 'antineutrino', pos: [-0.6, 0, 0.4], vel: [10, 0, -3] },
  ] },

  { id: 'riplab', name: 'Big Rip Lab (⚙ → Start Big Rip)', camera: [0, 6, 10], bodies: [
    SUN,
    { type: 'planet', around: 0, r: 0.4, angle: 0 }, { type: 'planet', around: 0, r: 1, angle: 2 },
    { type: 'gasgiant', around: 0, r: 3, angle: 4 }, { type: 'icegiant', around: 0, r: 6, angle: 1 },
  ] },

  { id: 'halo', name: 'Dark Matter Halo', camera: [0, 60, 90], bodies: [
    { type: 'smbh', pos: [0, 0, 0], name: 'Galactic core' },
    { type: 'star', around: 0, r: 12, angle: 0 }, { type: 'reddwarf', around: 0, r: 20, angle: 1.5 }, { type: 'bluegiant', around: 0, r: 30, angle: 3 },
    { type: 'whitedwarf', around: 0, r: 40, angle: 4.5 }, { type: 'star', around: 0, r: 55, angle: 5.5 },
    { type: 'darkmatter', around: 0, r: 15, angle: 2 }, { type: 'darkmatter', around: 0, r: 35, angle: 4 }, { type: 'darkmatter', around: 0, r: 50, angle: 0.5 },
  ] },

  { id: 'empty', name: 'Empty System', bodies: [] },
];
