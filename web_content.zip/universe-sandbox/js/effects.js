// =====================================================================
// effects.js — exotic phenomena that act on bodies each frame, plus secret-lab actions.
// Everything here is SPECULATIVE or SIMPLIFIED; each block says which.
// =====================================================================
import * as THREE from 'three';
import { fields, hubble2, GBASE, massFactor, mostMassive, circularVelocity } from './physics.js';
import { resetTrail } from './bodies.js';

export const MAX_BODIES = 220;
const BUBBLE_GEO = new THREE.SphereGeometry(1, 24, 16);
const rnd = () => Math.random() * 2 - 1;
const rv = (s) => new THREE.Vector3(rnd(), 0, rnd()).normalize().multiplyScalar(s); // random planar vector

export function initEffects({ scene, bodies, add, remove, burst }) {
  const bubbles = [], respawns = []; let pending = null;

  // SPECULATIVE: vacuum decay — a true-vacuum bubble expands and destroys everything it engulfs.
  function nucleate(p) {
    const m = new THREE.Mesh(BUBBLE_GEO, new THREE.MeshBasicMaterial({ color: 0x66ffd0, transparent: true, opacity: 0.16, side: THREE.DoubleSide, depthWrite: false }));
    m.position.copy(p); m.scale.setScalar(0.05); scene.add(m); bubbles.push({ m, c: p.clone(), r: 0.05 });
  }
  // SPECULATIVE: wormholes link in pairs (1st placed = A, 2nd = B). Anything entering a mouth exits the other.
  function link(b) {
    if (pending && !pending.gone) {
      pending.link = b; b.link = pending;
      pending.name = 'Wormhole A'; b.name = 'Wormhole B';
      pending.label.element.textContent = pending.name; b.label.element.textContent = b.name; pending = null;
    } else pending = b;
  }
  function onRemove(b, reason) {
    if (b.link) b.link.link = null;
    if (pending === b) pending = null;
    if (b.zombie && reason === 'delete') respawns.push({ t: performance.now() + 4000, id: b.type.id, mass: b.mass, radius: b.radius, name: b.name, pos: b.pos.clone(), vel: b.vel.clone() });
  }
  function clear() {
    for (const q of bubbles) { scene.remove(q.m); q.m.material.dispose(); }
    bubbles.length = 0; respawns.length = 0; pending = null;
  }
  // SIMPLIFIED: Big-Rip tearing. A body is shredded when the tidal pull of H² across its radius beats its own surface gravity.
  function rip(b) {
    burst(b.pos, 12); remove(b, 'rip');
    if (bodies.length >= MAX_BODIES - 4 || b.radius < 0.006) return;
    const k1 = rv(0.5), k2 = rv(0.5);                   // kicks sum to zero: momentum conserved
    [k1, k1.clone().negate(), k2, k2.clone().negate()].forEach((k, i) => {
      add(b.type.id, b.pos.clone().add(k.clone().multiplyScalar(b.radius)), b.vel.clone().add(k), { mass: b.mass / 4, radius: b.radius * 0.6, name: 'Debris', zombie: b.zombie, mulM: b.mulM, gs: b.gs });
    });
  }

  function update(years, now) {
    const list = [...bodies], H2 = hubble2();
    for (let k = bubbles.length - 1; k >= 0; k--) {
      const q = bubbles[k]; q.r += fields.bubbleV * years; q.m.scale.setScalar(q.r);
      for (const b of list) if (!b.gone && b.pos.distanceTo(q.c) < q.r + b.radius) { burst(b.pos, 20); remove(b, 'vacuum'); }
      if (q.r > 5000) { scene.remove(q.m); q.m.material.dispose(); bubbles.splice(k, 1); }
    }
    if (H2 > 0) for (const b of list) {
      if (b.gone || b.type.collide === false || b.radius < 0.0025) continue;
      const g = GBASE * fields.G * Math.abs(b.mass * massFactor(b) * b.gs) / (b.radius * b.radius);
      if (H2 * b.radius > g) rip(b);
    }
    // REAL process, SIMPLIFIED rates/momentum: free neutron → proton + electron + anti-neutrino. Rate ∝ weak slider.
    if (fields.weak > 0 && years > 0) for (const b of list) {
      if (b.gone || !b.type.decay || Math.random() > fields.weak * years / 0.4) continue;
      remove(b, 'decay'); burst(b.pos, 10);
      add('proton', b.pos.clone(), b.vel.clone());
      add('electron', b.pos.clone().add(rv(0.02)), b.vel.clone().add(rv(8)));
      add('antineutrino', b.pos.clone(), b.vel.clone().add(rv(40)));
    }
    for (const w of list) {
      if (w.gone) continue;
      if (w.type.id === 'wormhole' && w.link) {
        for (const c of list) {
          if (c === w || c.gone || c.type.pinned || c.cd > fields.simTime || c.pos.distanceTo(w.pos) >= w.radius) continue;
          const d = c.vel.lengthSq() > 1e-9 ? c.vel.clone().normalize() : rv(1);
          c.pos.copy(w.link.pos).addScaledVector(d, w.link.radius * 1.6); c.cd = fields.simTime + 0.05;
          resetTrail(c); burst(c.pos, 6);
        }
      } else if (w.type.id === 'string' && fields.stringMu > 0 && years > 0) {
        // SPECULATIVE: strings exert no Newtonian pull (real property); here they only tug nearby bodies sideways (a toy wake effect).
        for (const c of list) {
          if (c === w || c.gone || c.type.pinned || Math.abs(c.pos.y - w.pos.y) > 3) continue;
          const dx = c.pos.x - w.pos.x, dz = c.pos.z - w.pos.z, d = Math.hypot(dx, dz);
          if (d > 0.3 || d < 1e-4) continue;
          const k = fields.stringMu * 20 * (1 - d / 0.3) * years; c.vel.x -= dx / d * k; c.vel.z -= dz / d * k;
        }
      }
    }
    for (let k = respawns.length - 1; k >= 0; k--) {   // fiction: zombie matter returns 4 s after deletion
      if (now < respawns[k].t) continue;
      const r = respawns.splice(k, 1)[0];
      const nb = add(r.id, r.pos.clone().add(rv(0.4)), r.vel, { mass: r.mass, radius: r.radius, name: r.name, zombie: true });
      if (nb) burst(nb.pos, 25);
    }
  }
  return { nucleate, link, onRemove, update, clear };
}

// ---------- Secret lab (unlock: tap "Speed" 7×, or the Konami code on a keyboard) ----------
export function makeSecrets({ add, bodies, center, sync, toggleDisco }) {
  const spawn = (id, p, v) => add(id, p, v);
  return [
    { name: '🪩 Disco mode (toggle)', run: toggleDisco },
    { name: '☄ Meteor shower', run() {
      const pr = mostMassive(bodies); if (!pr) return;
      for (let k = 0; k < 25; k++) {
        const a = Math.random() * 6.28, r = 4 + Math.random() * 6, p = new THREE.Vector3(Math.cos(a) * r, 0, Math.sin(a) * r).add(pr.pos);
        spawn('comet', p, circularVelocity(pr, p).multiplyScalar(0.15 + Math.random() * 0.4));
      }
    } },
    { name: '🌌 Spawn mini galaxy at camera focus', run() {
      const c = center().clone(); c.y = 0;
      const core = spawn('smbh', c, new THREE.Vector3()); if (!core) return;
      const kinds = ['reddwarf', 'star', 'whitedwarf', 'bluegiant'];
      for (let k = 0; k < 40; k++) {
        const a = Math.random() * 6.28, r = 8 * Math.exp(Math.random() * 2.1), p = new THREE.Vector3(Math.cos(a) * r, 0, Math.sin(a) * r).add(c);
        spawn(k < 30 ? kinds[k % 4] : 'darkmatter', p, circularVelocity(core, p));
      }
    } },
    { name: '💥 Big Crunch (H² = −3)', run() { fields.H2 = -3; sync(); } },
    { name: '🙃 Flip gravity (G = −1)', run() { fields.G = -1; sync(); } },
  ];
}
