// =====================================================================
// physics.js — Universe Sandbox v0.4
// UNITS: length = AU, mass = solar masses (M☉), time = years.
// In these units G = 4π² AU³ / (M☉·yr²).   // REAL (Kepler's 3rd law)
// `fields` holds every slider; the real constants are the defaults.
// =====================================================================
import * as THREE from 'three';
import { FIELD_DEFS } from './fields.js';

export const GBASE = 4 * Math.PI * Math.PI;  // REAL
const EMK = 2e-9;       // SIMPLIFIED: Coulomb constant for scaled-up sandbox "particles" (real e/m ratios are absurd here)
const STK = 1e-5;       // SIMPLIFIED: Yukawa-style nucleon attraction strength
const STR_RANGE = 0.05; // SIMPLIFIED: strong-force range (AU)
const RIPC = 0.05;      // SPECULATIVE: phantom-energy H² amplitude, H² = RIPC / (1 - t/T)²
export const DT = 0.001, MAX_SUBSTEPS = 30;

export const fields = { kindMass: {}, simTime: 0, ripOn: false, ripT0: 0 };
export function resetFields() { for (const d of FIELD_DEFS) fields[d.id] = d.def; fields.kindMass = {}; fields.ripOn = false; }
resetFields();

let dirty = true;
export const invalidate = () => { dirty = true; };
const _d = new THREE.Vector3();

// ---------- Masses ----------
// SPECULATIVE: only the Higgs-given fraction of a body's mass follows the Higgs vev.
// (Real nucleons get ~1% of their mass from Higgs; electrons ~100%. Ludicrous mode makes it 100% for all.)
export function massFactor(b) {
  const f = fields.higgsAll ? 1 : (b.type.higgsFrac ?? 0.01);
  return (fields.kindMass[b.type.id] ?? 1) * (1 - f + f * fields.higgs) * b.mulM;
}
// mi = inertial mass; me = gravitational source strength (mi × per-body gravity slider)
export function refreshMasses(bodies) { for (const b of bodies) { b.mi = b.mass * massFactor(b); b.me = b.mi * b.gs; } }
const inert = (b) => (Math.abs(b.mi) < 1e-14 ? (b.mi < 0 ? -1e-14 : 1e-14) : b.mi);

// SIMPLIFIED: Newtonian stand-in for accelerated expansion, a = H²·r from the origin (real expansion is metric, not a force).
// SPECULATIVE: with Big Rip on, H² diverges as t → T (phantom energy, w < -1).
export function hubble2() {
  let h = fields.H2;
  if (fields.ripOn) { const x = Math.max(5e-4, 1 - (fields.simTime - fields.ripT0) / fields.ripT); h += RIPC / (x * x); }
  return h;
}

// ---------- Forces ----------
// REAL form (softened): pairwise gravity between ALL bodies, O(n²). Slider changes (G×, exponent, per-body
// gravity) are SPECULATIVE and break Newton's 3rd law when per-body gravity ≠ 1.
// SIMPLIFIED: Coulomb (REAL form, scaled constant) and Yukawa strong force between nucleon-type bodies.
export function computeAccelerations(bodies) {
  refreshMasses(bodies);
  const e2 = fields.soft ** 2, g = GBASE * fields.G, p1 = (fields.n + 1) / 2, sq = fields.n === 2;
  const em = EMK * fields.em, st = STK * fields.strong, H2 = hubble2();
  for (const b of bodies) b.acc.set(0, 0, 0).addScaledVector(b.pos, H2);
  for (let i = 0; i < bodies.length; i++) {
    const a = bodies[i];
    for (let j = i + 1; j < bodies.length; j++) {
      const b = bodies[j];
      _d.subVectors(b.pos, a.pos);
      const r2 = _d.lengthSq() + e2;
      const f = g / (sq ? r2 * Math.sqrt(r2) : Math.pow(r2, p1));
      a.acc.addScaledVector(_d, f * b.me); b.acc.addScaledVector(_d, -f * a.me);
      if (em && a.q && b.q) { const c = em * a.q * b.q / (r2 * Math.sqrt(r2)); a.acc.addScaledVector(_d, -c / inert(a)); b.acc.addScaledVector(_d, c / inert(b)); }
      if (st && a.type.nuc && b.type.nuc) {
        const r = Math.sqrt(r2), k = st * (1 / r2 + 1 / (STR_RANGE * r)) * Math.exp(-r / STR_RANGE) / r;
        a.acc.addScaledVector(_d, k / inert(a)); b.acc.addScaledVector(_d, -k / inert(b));
      }
    }
  }
}

// ---------- Integrator ----------
// REAL: velocity Verlet (symplectic, 2nd order). SIMPLIFIED: speed clamp `cmax` is a numerical guard, NOT relativity.
export function stepVerlet(bodies, dt) {
  if (dirty) { computeAccelerations(bodies); dirty = false; }
  for (const b of bodies) {
    b.accOld.copy(b.acc);
    if (b.type.pinned) continue;
    b.pos.addScaledVector(b.vel, dt).addScaledVector(b.acc, 0.5 * dt * dt);
  }
  computeAccelerations(bodies);
  for (const b of bodies) {
    if (b.type.pinned) { b.vel.set(0, 0, 0); continue; }
    b.vel.addScaledVector(b.accOld, 0.5 * dt).addScaledVector(b.acc, 0.5 * dt);
    const s = b.vel.length();
    if (!Number.isFinite(s + b.pos.x + b.pos.y + b.pos.z)) { b.dead = true; b.pos.set(0, 0, 0); b.vel.set(0, 0, 0); }
    else if (s > fields.cmax) b.vel.multiplyScalar(fields.cmax / s);
  }
}

// ---------- Collisions ----------
// REAL: inelastic merge conserves mass + momentum. SIMPLIFIED: contact uses inflated display radii.
// REAL process, SIMPLIFIED handling: matter + antimatter annihilate; remainder keeps the bigger body's velocity
// (photon momentum is not tracked). SPECULATIVE: zombie matter converts whatever it touches.
// Bodies with type.collide === false (neutrinos, dark matter, wormholes...) never merge.
export function mergeBodies(bodies) {
  const events = [];
  for (let i = 0; i < bodies.length; i++) {
    for (let j = i + 1; j < bodies.length; j++) {
      const a = bodies[i], b = bodies[j];
      if (a.type.collide === false || b.type.collide === false) continue;
      if (a.pos.distanceTo(b.pos) >= a.radius + b.radius) continue;
      const [big, small] = a.mass >= b.mass ? [a, b] : [b, a];
      const m = big.mass + small.mass;
      const p = new THREE.Vector3().addScaledVector(big.pos, big.mass).addScaledVector(small.pos, small.mass).divideScalar(m);
      dirty = true;
      if (a.anti !== b.anti) {
        const rem = big.mass - small.mass;
        bodies.splice(bodies.indexOf(small), 1);
        if (rem < 1e-9 * big.mass) {
          bodies.splice(bodies.indexOf(big), 1);
          events.push({ survivor: null, absorbed: small, point: p, anni: true }, { survivor: null, absorbed: big, point: p, anni: true });
        } else { big.radius *= Math.cbrt(rem / big.mass); big.mass = rem; events.push({ survivor: big, absorbed: small, point: p, anni: true }); }
        return events.concat(mergeBodies(bodies));
      }
      const v = new THREE.Vector3().addScaledVector(big.vel, big.mass).addScaledVector(small.vel, small.mass).divideScalar(m);
      big.radius = Math.cbrt(big.radius ** 3 + small.radius ** 3);
      big.mass = m; big.pos.copy(p); big.vel.copy(v);
      if (small.zombie) big.zombie = true;
      if (big.zombie) small.zombie = true;
      bodies.splice(bodies.indexOf(small), 1);
      events.push({ survivor: big, absorbed: small, point: p.clone() });
      return events.concat(mergeBodies(bodies));
    }
  }
  return events;
}

// ---------- Advance ----------
export function advance(bodies, years) {
  const n = Math.min(MAX_SUBSTEPS, Math.max(1, Math.ceil(years / DT)));
  const h = Math.min(DT, years / n);
  let events = [];
  for (let k = 0; k < n; k++) {
    stepVerlet(bodies, h); fields.simTime += h;
    const e = mergeBodies(bodies);
    if (e.length) events = events.concat(e);
  }
  return events;
}

// ---------- Orbit helpers ----------
export function mostMassive(bodies, exclude = null) {
  let best = null;
  for (const b of bodies) if (b !== exclude && !b.type.pinned && (!best || b.mass > best.mass)) best = b;
  return best;
}

// SIMPLIFIED: circular speed around ONE primary in the y=0 plane, using the current G×, exponent and mass sliders:
// v² / r = G·me / r^n.  Ignores all other bodies, so orbits are only approximately circular.
export function circularVelocity(primary, pos) {
  const r = new THREE.Vector3().subVectors(pos, primary.pos); r.y = 0;
  const d = r.length();
  if (d < 1e-6) return primary.vel.clone();
  const me = primary.mass * massFactor(primary) * primary.gs;
  const speed = Math.sqrt(Math.max(0, GBASE * fields.G * me * Math.pow(d, 1 - fields.n)));
  return new THREE.Vector3(-r.z / d, 0, r.x / d).multiplyScalar(speed).add(primary.vel);
}
