// =====================================================================
// bodies.js — object type configs + Three.js visuals
// Masses in M☉; radii are DISPLAY radii in AU (inflated). Add a type = add one T(...) line.
// Optional flags: speculative, anti, zombie, charge, nuc (strong force), decay (weak decay),
//   collide:false, pinned (fixed in space), ghost (see-through), launch (random-direction speed),
//   higgsFrac (fraction of mass that follows the Higgs vev; default 0.01), glow (colour).
// =====================================================================
import * as THREE from 'three';
import { CSS2DObject } from 'three/addons/renderers/CSS2DRenderer.js';

const T = (id, name, group, mass, radius, color, emissive, o = {}) => ({ id, name, group, kind: id, mass, radius, color, emissive, ...o });

export const BODY_TYPES = [
  // ----- Stars (SIMPLIFIED: Newtonian point masses, cosmetic radii/glow) -----
  T('reddwarf', 'Red Dwarf', 'Stars', 0.2, 0.07, 0xff7043, 0xcc3300),
  T('star', 'Sun-like Star', 'Stars', 1, 0.12, 0xffd27a, 0xffa030),
  T('redgiant', 'Red Giant', 'Stars', 1.2, 0.35, 0xff5a36, 0xdd3300),
  T('bluegiant', 'Blue Giant', 'Stars', 20, 0.3, 0x9ec5ff, 0x4a7dff),
  T('whitedwarf', 'White Dwarf', 'Stars', 0.6, 0.02, 0xf4f8ff, 0xbcd0ff),
  T('browndwarf', 'Brown Dwarf', 'Stars', 0.05, 0.05, 0x8b4a2b, 0x3a1500),
  // ----- Planets & small bodies -----
  T('planet', 'Planet', 'Planets', 3e-6, 0.05, 0x4a90d9, 0x000000),
  T('gasgiant', 'Gas Giant', 'Planets', 1e-3, 0.06, 0xd9a066, 0x000000),
  T('icegiant', 'Ice Giant', 'Planets', 5e-5, 0.045, 0x7fd6e8, 0x000000),
  T('moon', 'Moon', 'Planets', 3.7e-8, 0.025, 0xaaaaaa, 0x000000),
  T('comet', 'Comet', 'Planets', 1e-14, 0.01, 0xdde8ee, 0x335566),
  T('probe', 'Probe', 'Planets', 1e-12, 0.015, 0x66ffcc, 0x22aa88),
  // ----- Compact objects (SIMPLIFIED: Newtonian; no event horizon, relativity or degenerate matter) -----
  T('neutron', 'Neutron Star', 'Compact', 1.4, 0.03, 0xbfd8ff, 0x6aa0ff),
  // SPECULATIVE: gravitationally a 1.4 M☉ neutron star. No magnetic field physics yet.
  T('magnetar', 'Magnetar', 'Compact', 1.4, 0.03, 0xff9bd8, 0xff3fa0, { speculative: true }),
  T('blackhole', 'Black Hole', 'Compact', 10, 0.08, 0x000000, 0x000000, { glow: 0xff7a1a, higgsFrac: 0 }),
  // SIMPLIFIED: mass scaled down ~10⁶× so galaxies fit in the sandbox.
  T('smbh', 'Supermassive BH', 'Compact', 1e5, 0.6, 0x000000, 0x000000, { glow: 0xff9a3a, higgsFrac: 0 }),
  // ----- Exotic (all SPECULATIVE unless noted) -----
  T('antimatter', 'Antimatter Star', 'Exotic', 1, 0.12, 0xb36bff, 0x7a2cff, { anti: true, speculative: true }), // gravity same as matter (measured for antihydrogen); annihilates with matter
  T('zombie', 'Zombie Matter', 'Exotic', 0.5, 0.06, 0x7fbf3f, 0x2a5a10, { zombie: true, speculative: true }),   // fiction: infects what it touches; respawns if deleted
  T('darkmatter', 'Dark Matter Clump', 'Exotic', 0.5, 0.15, 0x331a55, 0x220a44, { collide: false, ghost: true, higgsFrac: 0 }), // SIMPLIFIED: collisionless, gravity only
  T('negmass', 'Negative Mass', 'Exotic', -0.5, 0.06, 0xe0e0ff, 0x8080ff, { collide: false, speculative: true }),
  T('wormhole', 'Wormhole Mouth', 'Exotic', 1e-9, 0.12, 0x000000, 0x000000, { glow: 0x33ddff, collide: false, pinned: true, speculative: true }), // place two to link them
  T('string', 'Cosmic String', 'Exotic', 1e-9, 0.02, 0xffe066, 0xffe066, { collide: false, pinned: true, speculative: true }),
  // ----- Particles (SIMPLIFIED: macro-scale, mass ratios kept: proton/electron ≈ 1836) -----
  T('electron', 'Electron', 'Particles', 2e-9, 0.008, 0x66aaff, 0x2266ff, { charge: -1, higgsFrac: 1 }),
  T('positron', 'Positron', 'Particles', 2e-9, 0.008, 0xff66aa, 0xff2266, { charge: 1, anti: true, higgsFrac: 1 }),
  T('proton', 'Proton', 'Particles', 3.67e-6, 0.012, 0xff6666, 0xaa2222, { charge: 1, nuc: true }),
  T('antiproton', 'Antiproton', 'Particles', 3.67e-6, 0.012, 0x66ffaa, 0x22aa66, { charge: -1, nuc: true, anti: true }),
  T('freeneutron', 'Free Neutron', 'Particles', 3.67e-6, 0.012, 0xcccccc, 0x555555, { nuc: true, decay: true }),
  T('neutrino', 'Neutrino', 'Particles', 1e-12, 0.006, 0xffffff, 0xaaaaff, { collide: false, launch: 40, higgsFrac: 1 }),
  T('antineutrino', 'Anti-neutrino', 'Particles', 1e-12, 0.006, 0xffaaff, 0xff66ff, { collide: false, launch: 40, anti: true, higgsFrac: 1 }),
];

// SPECULATIVE STUB — NOT CALLED by the engine. Future home of magnetar magnetic-field forces. Returns zero.
export function magnetarFieldStub(magnetar, bodies) { return new THREE.Vector3(0, 0, 0); }

// ---------- Shared resources (reused by every body; never disposed) ----------
const SPHERE = new THREE.SphereGeometry(1, 20, 14);
const TRAIL_N = 100;
const trailMat = new THREE.LineBasicMaterial({ vertexColors: true, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false });
const STR_GEO = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0, -150, 0), new THREE.Vector3(0, 150, 0)]);
const STR_MAT = new THREE.LineBasicMaterial({ color: 0xffe066 });
const glowTex = (() => {
  const c = document.createElement('canvas'); c.width = c.height = 64;
  const g = c.getContext('2d'), grad = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  grad.addColorStop(0, 'rgba(255,255,255,1)'); grad.addColorStop(0.25, 'rgba(255,255,255,.35)'); grad.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = grad; g.fillRect(0, 0, 64, 64);
  return new THREE.CanvasTexture(c);
})();

// ---------- Body data ----------
let uid = 0;
export function createBody(type, pos, vel, o = {}) {
  return { id: ++uid, type, kind: type.kind, name: o.name ?? `${type.name} ${uid}`,
    mass: o.mass ?? type.mass, radius: o.radius ?? type.radius,
    q: type.charge ?? 0, anti: !!type.anti, zombie: o.zombie ?? !!type.zombie,
    mulM: o.mulM ?? 1, gs: o.gs ?? 1, cd: 0, mi: 0, me: 0, link: null,
    pos: pos.clone(), vel: vel.clone(), acc: new THREE.Vector3(), accOld: new THREE.Vector3() };
}

// SIMPLIFIED: glow is cosmetic, log-scaled with |mass|.
const glowSize = (b) => 2 + 1.1 * Math.max(0, Math.log10(Math.abs(b.mass) || 1e-12) + 6);

// ---------- Visuals ----------
export function attachVisual(b, scene) {
  const t = b.type, glowColor = t.glow ?? (t.emissive || t.color);
  b.mesh = new THREE.Mesh(SPHERE, new THREE.MeshStandardMaterial({ color: t.color, emissive: t.emissive, roughness: 0.7, transparent: !!t.ghost, opacity: t.ghost ? 0.35 : 1 }));
  b.glow = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTex, color: glowColor, blending: THREE.AdditiveBlending, transparent: true, depthWrite: false, opacity: t.ghost ? 0.2 : 0.55 }));
  const div = document.createElement('div'); div.className = 'lbl'; div.textContent = b.name;
  b.label = new CSS2DObject(div); b.label.position.set(0, 1.6, 0);
  b.mesh.add(b.glow, b.label);
  if (t.id === 'string') b.mesh.add(new THREE.Line(STR_GEO, STR_MAT)); // vertical string, ±3 AU
  const col = new Float32Array(TRAIL_N * 3), c = new THREE.Color(glowColor);
  for (let i = 0; i < TRAIL_N; i++) { const f = (i / (TRAIL_N - 1)) ** 2; col.set([c.r * f, c.g * f, c.b * f], i * 3); }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(TRAIL_N * 3), 3));
  geo.setAttribute('color', new THREE.BufferAttribute(col, 3));
  b.trail = new THREE.Line(geo, trailMat); b.trail.frustumCulled = false;
  refreshVisual(b); resetTrail(b);
  scene.add(b.mesh, b.trail);
}

export function refreshVisual(b) { // after radius/mass/zombie change, or to undo disco colours
  const t = b.type, m = b.mesh.material, z = b.zombie;
  m.color.set(z ? 0x7fbf3f : t.color); m.emissive.set(z ? 0x2a5a10 : t.emissive);
  b.glow.material.color.set(z ? 0x8fdf4f : (t.glow ?? (t.emissive || t.color)));
  b.mesh.scale.setScalar(b.radius); b.glow.scale.setScalar(glowSize(b)); b.mesh.position.copy(b.pos);
}
export const updateVisual = (b) => b.mesh.position.copy(b.pos);

export function resetTrail(b) {
  const p = b.trail.geometry.attributes.position;
  for (let i = 0; i < TRAIL_N; i++) p.setXYZ(i, b.pos.x, b.pos.y, b.pos.z);
  p.needsUpdate = true;
}
export function pushTrail(b) {
  const p = b.trail.geometry.attributes.position;
  p.array.copyWithin(0, 3); p.setXYZ(TRAIL_N - 1, b.pos.x, b.pos.y, b.pos.z); p.needsUpdate = true;
}

// Disposes per-body GPU resources. Shared geometry/materials/texture are kept.
export function disposeBody(b, scene) {
  b.label.element.remove(); scene.remove(b.mesh, b.trail);
  b.mesh.material.dispose(); b.glow.material.dispose(); b.trail.geometry.dispose();
}
