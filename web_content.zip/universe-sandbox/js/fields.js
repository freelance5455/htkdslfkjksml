// =====================================================================
// fields.js — DATA ONLY: every global slider. Add a row => a new slider appears.
// tag: REAL | SIMPLIFIED | SPECULATIVE | VIEW (cosmetic).
// log:true => min/max are log10 exponents and `def` is the real value.
// =====================================================================
export const FIELD_DEFS = [
  { group: 'View', id: 'sheet', label: 'Sheet size (AU)', min: 1.3, max: 3.7, step: 0.05, def: 200, log: true, tag: 'VIEW' },
  { group: 'Gravity', id: 'G', label: 'Gravity strength G×', min: 0, max: 10, step: 0.1, def: 1, tag: 'SPECULATIVE' },
  { group: 'Gravity', id: 'n', label: 'Force-law exponent (real = 2)', min: 1, max: 4, step: 0.1, def: 2, tag: 'SPECULATIVE' },
  { group: 'Gravity', id: 'soft', label: 'Softening ε (AU)', min: -3.3, max: -0.5, step: 0.05, def: 0.003, log: true, tag: 'SIMPLIFIED' },
  { group: 'Higgs field', id: 'higgs', label: 'Higgs vev × (shifts Higgs-given mass)', min: 0, max: 3, step: 0.05, def: 1, tag: 'SPECULATIVE' },
  { group: 'Higgs field', id: 'higgsAll', label: 'Ludicrous Higgs: ALL mass from Higgs (0/1)', min: 0, max: 1, step: 1, def: 0, tag: 'SPECULATIVE' },
  { group: 'Other forces', id: 'em', label: 'Electromagnetism (charged particles)', min: 0, max: 10, step: 0.1, def: 1, tag: 'SIMPLIFIED' },
  { group: 'Other forces', id: 'strong', label: 'Strong force (nucleons)', min: 0, max: 10, step: 0.1, def: 1, tag: 'SIMPLIFIED' },
  { group: 'Other forces', id: 'weak', label: 'Weak force (neutron decay rate)', min: 0, max: 10, step: 0.1, def: 1, tag: 'SIMPLIFIED' },
  { group: 'Cosmology', id: 'H2', label: 'Dark energy H² (1/yr², negative = crunch)', min: -3, max: 20, step: 0.05, def: 0, tag: 'SIMPLIFIED' },
  { group: 'Cosmology', id: 'ripT', label: 'Big Rip time T (yr)', min: 5, max: 60, step: 1, def: 15, tag: 'SPECULATIVE' },
  { group: 'Exotica', id: 'bubbleV', label: 'Vacuum bubble speed (AU/yr)', min: 1, max: 200, step: 1, def: 20, tag: 'SPECULATIVE' },
  { group: 'Exotica', id: 'stringMu', label: 'Cosmic string tension', min: 0, max: 10, step: 0.1, def: 1, tag: 'SPECULATIVE' },
  { group: 'Numerics', id: 'cmax', label: 'Speed limit (AU/yr)', min: 2, max: 4.3, step: 0.05, def: 3000, log: true, tag: 'SIMPLIFIED' },
];
