// =====================================================================
// main.js — scene setup, game loop, input. Physics: physics.js. Phenomena: effects.js.
// =====================================================================
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { CSS2DRenderer } from 'three/addons/renderers/CSS2DRenderer.js';
import { advance, invalidate, circularVelocity, mostMassive, fields, resetFields, hubble2 } from './physics.js';
import { BODY_TYPES, createBody, attachVisual, updateVisual, refreshVisual, disposeBody, pushTrail, resetTrail } from './bodies.js';
import { SCENARIOS } from './scenarios.js';
import { initUI } from './ui.js';
import { initEffects, makeSecrets, MAX_BODIES } from './effects.js';

const YEARS_PER_SEC = 0.25;   // SIMPLIFIED: display time scale at 1× (Earth-like orbit ≈ 4 s)
const DEFAULT_CAM = [0, 5, 8];
const TOOLS = [{ id: 'tool:bubble', name: '☢ Vacuum decay', group: 'Tools', speculative: true }]; // tap to nucleate a bubble
const state = { bodies: [], selected: null, paused: false, speed: 1, trails: true, follow: false, typeId: 'planet', scenarioId: SCENARIOS[0].id, disco: false };

// ---------- Renderer / scene ----------
const app = document.getElementById('app');
const renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
app.appendChild(renderer.domElement);
const labels = new CSS2DRenderer();
Object.assign(labels.domElement.style, { position: 'absolute', top: '0', left: '0', pointerEvents: 'none' });
app.appendChild(labels.domElement);
const scene = new THREE.Scene(); scene.background = new THREE.Color(0x02030a);
const camera = new THREE.PerspectiveCamera(55, 1, 0.05, 60000);
const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true; controls.minDistance = 0.1; controls.maxDistance = 20000;
controls.touches = { ONE: THREE.TOUCH.ROTATE, TWO: THREE.TOUCH.DOLLY_PAN };
scene.add(new THREE.AmbientLight(0xffffff, 0.9));
const sun = new THREE.DirectionalLight(0xffffff, 1.2); sun.position.set(5, 10, 7); scene.add(sun);

const sp = new Float32Array(1500 * 3);   // starfield (cosmetic); follows the camera so it never runs out
for (let i = 0; i < 1500; i++) { const v = new THREE.Vector3().randomDirection().multiplyScalar(30000 + Math.random() * 8000); sp.set([v.x, v.y, v.z], i * 3); }
const starGeo = new THREE.BufferGeometry(); starGeo.setAttribute('position', new THREE.BufferAttribute(sp, 3));
const stars = new THREE.Points(starGeo, new THREE.PointsMaterial({ color: 0xaab8ff, size: 1.5, sizeAttenuation: false })); stars.frustumCulled = false; scene.add(stars);

// Sheet: grid + faint plane on y=0. Size comes from the "Sheet size" slider; also the placement limit (±size/2).
const sheet = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ color: 0x16204a, transparent: true, opacity: 0.28, side: THREE.DoubleSide, depthWrite: false }));
sheet.rotation.x = -Math.PI / 2; sheet.position.y = -0.001; scene.add(sheet);
let grid = null;
function buildGrid() {
  if (grid) { scene.remove(grid); grid.geometry.dispose(); grid.material.dispose(); }
  const size = fields.sheet, step = [1, 2, 5, 10, 20, 50, 100, 200, 500, 1000].find((s) => size / s <= 60) ?? 1000;
  grid = new THREE.GridHelper(size, Math.round(size / step), 0x3a4a7a, 0x1c2540);
  grid.material.transparent = true; grid.material.opacity = 0.6; scene.add(grid); sheet.scale.setScalar(size);
}

// ---------- Collision sparks (pooled; cosmetic) ----------
const SP = 400, sPos = new Float32Array(SP * 3), sCol = new Float32Array(SP * 3), sVel = new Float32Array(SP * 3), sLife = new Float32Array(SP);
let sparkI = 0;
const sparkGeo = new THREE.BufferGeometry();
sparkGeo.setAttribute('position', new THREE.BufferAttribute(sPos, 3)); sparkGeo.setAttribute('color', new THREE.BufferAttribute(sCol, 3));
const sparks = new THREE.Points(sparkGeo, new THREE.PointsMaterial({ size: 0.08, vertexColors: true, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false }));
sparks.frustumCulled = false; scene.add(sparks);
function burst(p, n = 40) {
  for (let k = 0; k < n; k++) {
    const i = sparkI++ % SP, d = new THREE.Vector3().randomDirection().multiplyScalar(0.3 + Math.random() * 0.9);
    sPos.set([p.x, p.y, p.z], i * 3); sVel.set([d.x, d.y, d.z], i * 3); sLife[i] = 1;
  }
}
function updateSparks(dt) {
  for (let i = 0; i < SP; i++) {
    if (sLife[i] <= 0) continue;
    sLife[i] -= dt; const c = Math.max(sLife[i], 0);
    for (let a = 0; a < 3; a++) sPos[i * 3 + a] += sVel[i * 3 + a] * dt;
    sCol.set([c, 0.7 * c, 0.3 * c], i * 3);
  }
  sparkGeo.attributes.position.needsUpdate = sparkGeo.attributes.color.needsUpdate = true;
}

// ---------- Body management ----------
function addBody(typeId, pos, vel, o = {}) {
  if (state.bodies.length >= MAX_BODIES) return null;
  const b = createBody(BODY_TYPES.find((t) => t.id === typeId), pos, vel, o);
  attachVisual(b, scene); b.trail.visible = state.trails;
  state.bodies.push(b); invalidate(); return b;
}
function removeBody(b, reason = 'other') {
  if (b.gone) return;
  b.gone = true;
  const i = state.bodies.indexOf(b); if (i >= 0) state.bodies.splice(i, 1);
  if (state.selected === b) select(null);
  disposeBody(b, scene); fx.onRemove(b, reason); invalidate();
}
function select(b) {
  state.selected?.label.element.classList.remove('sel');
  state.selected = b; b?.label.element.classList.add('sel');
  if (!b) { state.follow = false; ui.setFollow(false); ui.setInfo(null); } else { ui.bindSel(b); ui.setInfo(infoHtml(b)); }
}
const fx = initEffects({ scene, bodies: state.bodies, add: addBody, remove: removeBody, burst });

function loadScenario(id) {
  state.scenarioId = id; select(null);
  [...state.bodies].forEach((b) => removeBody(b, 'reset'));
  fx.clear(); sLife.fill(0); sCol.fill(0); fields.simTime = 0; fields.ripOn = false; ui.setRip(false);
  const sc = SCENARIOS.find((s) => s.id === id), made = [];
  for (const s of sc.bodies) {
    let pos, vel;
    if (s.around != null) {   // SIMPLIFIED circular orbit around an earlier body
      const p = made[s.around], a = s.angle ?? 0;
      pos = p.pos.clone().add(new THREE.Vector3(Math.cos(a) * s.r, 0, Math.sin(a) * s.r)); vel = circularVelocity(p, pos);
    } else { pos = new THREE.Vector3(...s.pos); vel = new THREE.Vector3(...(s.vel ?? [0, 0, 0])); }
    const b = addBody(s.type, pos, vel, { mass: s.mass, radius: s.radius, name: s.name }); made.push(b);
    if (s.type === 'wormhole') fx.link(b);
  }
  camera.position.set(...(sc.camera ?? DEFAULT_CAM)); controls.target.set(0, 0, 0);
}

function handleMerge(e) {   // physics already removed e.absorbed from the array
  if (state.selected === e.absorbed) select(e.survivor);
  disposeBody(e.absorbed, scene); e.absorbed.gone = true; fx.onRemove(e.absorbed, 'merge');
  if (e.survivor) refreshVisual(e.survivor);
  burst(e.point, e.anni ? 90 : 40);
}

// ---------- Info panel ----------
function infoHtml(b) {
  const pr = mostMassive(state.bodies, b), sp = b.vel.length(), tag = [b.anti && 'ANTIMATTER', b.zombie && 'ZOMBIE', b.type.speculative && 'SPECULATIVE'].filter(Boolean).join(' · ');
  return `<b>${b.name}</b> (${b.kind}${tag ? ' · ' + tag : ''})<br>Mass: ${b.mass.toExponential(2)} M☉${b.q ? ` · charge ${b.q > 0 ? '+' : ''}${b.q}` : ''}<br>` +
    `Speed: ${sp.toFixed(2)} AU/yr (${(sp * 4.74047).toFixed(1)} km/s)<br>` +
    (pr ? `To ${pr.name}: ${b.pos.distanceTo(pr.pos).toFixed(3)} AU` : 'No primary body');
}

// ---------- Movement (pad + keyboard): flies camera AND target ----------
const keys = { f: 0, b: 0, l: 0, r: 0, u: 0, d: 0 }, UP = new THREE.Vector3(0, 1, 0), _f = new THREE.Vector3(), _r = new THREE.Vector3(), _v = new THREE.Vector3();
function goHome() { camera.position.set(...DEFAULT_CAM); controls.target.set(0, 0, 0); }
function applyMove(dt) {
  if (!(keys.f || keys.b || keys.l || keys.r || keys.u || keys.d)) return;
  if (state.follow) { state.follow = false; ui.setFollow(false); }
  _f.set(0, 0, -1).applyQuaternion(camera.quaternion); _f.y = 0;
  if (_f.lengthSq() < 0.01) { _f.copy(UP).applyQuaternion(camera.quaternion); _f.y = 0; }   // looking straight down: use camera "up"
  _f.normalize(); _r.crossVectors(_f, UP);
  _v.set(0, 0, 0).addScaledVector(_f, keys.f - keys.b).addScaledVector(_r, keys.r - keys.l).addScaledVector(UP, keys.u - keys.d)
    .multiplyScalar(Math.max(0.5, camera.position.distanceTo(controls.target)) * 0.9 * dt);   // speed scales with zoom
  camera.position.add(_v); controls.target.add(_v);
}
const KEYMAP = { KeyW: 'f', ArrowUp: 'f', KeyS: 'b', ArrowDown: 'b', KeyA: 'l', ArrowLeft: 'l', KeyD: 'r', ArrowRight: 'r', KeyE: 'u', KeyQ: 'd' };
const KONAMI = 'ArrowUp ArrowUp ArrowDown ArrowDown ArrowLeft ArrowRight ArrowLeft ArrowRight KeyB KeyA'; let seq = [];
addEventListener('keydown', (e) => { if (KEYMAP[e.code]) keys[KEYMAP[e.code]] = 1; seq = [...seq, e.code].slice(-10); if (seq.join(' ') === KONAMI) ui.toggleSecret(); });
addEventListener('keyup', (e) => { if (KEYMAP[e.code]) keys[KEYMAP[e.code]] = 0; });

// ---------- UI ----------
const ui = initUI({ types: [...BODY_TYPES, ...TOOLS], scenarios: SCENARIOS, defaultType: state.typeId, getSel: () => state.selected, h: {
  onType: (id) => { state.typeId = id; },
  onScenario: loadScenario,
  onPause: () => (state.paused = !state.paused),
  onReset: () => loadScenario(state.scenarioId),
  onTrails: () => {
    state.trails = !state.trails;
    for (const b of state.bodies) { b.trail.visible = state.trails; if (state.trails) resetTrail(b); }
    return state.trails;
  },
  onSpeed: (v) => { state.speed = v; },
  onFocus: () => { if (state.selected) { state.follow = !state.follow; ui.setFollow(state.follow); } },
  onDelete: () => { if (state.selected) removeBody(state.selected, 'delete'); },
  onField: (id) => { if (id === 'sheet') buildGrid(); },
  onRip: () => { fields.ripOn = !fields.ripOn; fields.ripT0 = fields.simTime; return fields.ripOn; },
  onResetFields: () => { resetFields(); ui.setRip(false); ui.sync(); buildGrid(); },
  onMove: (dir, on) => { keys[dir] = on ? 1 : 0; },
  onHome: goHome,
  onHide: () => select(null),   // deselect: closes the info/slider panel
} });
ui.initSecret(makeSecrets({ add: addBody, bodies: state.bodies, center: () => controls.target, sync: () => ui.sync(),
  toggleDisco: () => { state.disco = !state.disco; if (!state.disco) state.bodies.forEach(refreshVisual); } }));

// ---------- Input: tap = select/place, drag/pinch = camera ----------
const el = renderer.domElement, ptrs = new Set(), ray = new THREE.Raycaster(), plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
let down = null, multi = false;
el.addEventListener('pointerdown', (e) => {
  ptrs.add(e.pointerId);
  if (ptrs.size > 1) multi = true; else { multi = false; down = { x: e.clientX, y: e.clientY, t: performance.now() }; }
});
el.addEventListener('pointerup', (e) => {
  ptrs.delete(e.pointerId);
  if (ptrs.size) return;
  if (down && !multi && Math.hypot(e.clientX - down.x, e.clientY - down.y) < 10 && performance.now() - down.t < 500) onTap(e.clientX, e.clientY);
  down = null; multi = false;
});
el.addEventListener('pointercancel', (e) => { ptrs.delete(e.pointerId); down = null; });

function onTap(x, y) {
  const w = innerWidth, h = innerHeight, v = new THREE.Vector3();
  let hit = null, best = 30;                       // pick radius in screen pixels (finger-friendly)
  for (const b of state.bodies) {
    v.copy(b.pos).project(camera);
    if (v.z > 1) continue;
    const d = Math.hypot((v.x + 1) / 2 * w - x, (1 - v.y) / 2 * h - y);
    if (d < best) { best = d; hit = b; }
  }
  if (hit) return select(hit);
  ray.setFromCamera(new THREE.Vector2(x / w * 2 - 1, -(y / h) * 2 + 1), camera);
  const p = ray.ray.intersectPlane(plane, new THREE.Vector3());
  if (!p || Math.max(Math.abs(p.x), Math.abs(p.z)) > fields.sheet / 2) return;   // outside the sheet
  if (state.typeId === 'tool:bubble') return fx.nucleate(p);
  const t = BODY_TYPES.find((k) => k.id === state.typeId), primary = mostMassive(state.bodies);
  const vel = t.pinned ? new THREE.Vector3() : t.launch ? new THREE.Vector3(Math.random() - 0.5, 0, Math.random() - 0.5).normalize().multiplyScalar(t.launch)
    : primary ? circularVelocity(primary, p) : new THREE.Vector3();   // default: circular orbit around the most massive body
  const b = addBody(t.id, p, vel);
  if (b) { if (t.id === 'wormhole') fx.link(b); select(b); }
}

// ---------- Loop ----------
function resize() {
  renderer.setSize(innerWidth, innerHeight); labels.setSize(innerWidth, innerHeight);
  camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix();
}
addEventListener('resize', resize); resize();

let last = performance.now(), infoT = 0;
function frame(now) {
  requestAnimationFrame(frame);
  const dt = Math.min((now - last) / 1000, 0.05); last = now;
  const years = !state.paused && state.speed > 0 ? dt * state.speed * YEARS_PER_SEC : 0;
  if (years > 0) {
    for (const e of advance(state.bodies, years)) handleMerge(e);
    fx.update(years, now);
    for (const b of state.bodies.filter((x) => x.dead)) removeBody(b, 'nan');   // numerically broken bodies are dropped
    for (const b of state.bodies) { updateVisual(b); if (state.trails) pushTrail(b); }
  } else fx.update(0, now);
  if (state.disco) for (const b of state.bodies) { const hue = ((now / 25 + b.id * 47) % 360) / 360; b.mesh.material.color.setHSL(hue, 0.9, 0.55); b.mesh.material.emissive.setHSL(hue, 0.9, 0.3); }
  if (state.follow && state.selected) {            // smooth follow: move target and camera by the same delta
    _v.copy(state.selected.pos).sub(controls.target).multiplyScalar(Math.min(1, dt * 8));
    controls.target.add(_v); camera.position.add(_v);
  }
  applyMove(dt); controls.update(); updateSparks(dt); stars.position.copy(camera.position);
  if ((infoT += dt) > 0.1) {
    infoT = 0; if (state.selected) ui.setInfo(infoHtml(state.selected));
    ui.setHud(`t ${fields.simTime.toFixed(2)} yr · H² ${hubble2().toFixed(2)} · ${state.bodies.length} bodies`);
  }
  renderer.render(scene, camera); labels.render(scene, camera);
}
buildGrid(); loadScenario(state.scenarioId);
requestAnimationFrame(frame);
