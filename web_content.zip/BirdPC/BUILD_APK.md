# How to Build the Bird PC APK

## Method 1: On Android Phone with Termux (No PC Required)
1. Install **Termux** and **ZArchiver** from F-Droid.
2. Extract \`BirdPC-Android-Project.zip\` to \`/sdcard/Download/BirdPC\`.
3. In Termux, run:
   \`\`\`bash
   pkg update -y
   pkg install -y openjdk-17 git gradle
   cd /sdcard/Download/BirdPC
   chmod +x ./gradlew
   ./gradlew assembleDebug
   \`\`\`
4. Install the output APK:
   \`app/build/outputs/apk/debug/app-debug.apk\`

## Method 2: Android Studio on PC/Mac
1. Open Android Studio.
2. Select **File > Open** and choose the \`BirdPC\` directory.
3. Allow Gradle to sync.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK location: \`app/build/outputs/apk/debug/app-debug.apk\`.

## Method 3: 1-Click Cloud Build with GitHub Actions
1. Push this project to GitHub.
2. GitHub Actions runs \`.github/workflows/build-apk.yml\` automatically.
3. Download the compiled APK from the **Actions** artifacts tab!
