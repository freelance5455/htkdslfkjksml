# Bird PC — Native Android Desktop Project

- **Application ID**: \`com.birdbase.app\`
- **Language**: Kotlin 2.0.21
- **Target Platform**: Android 15 (API 35), Min SDK 26
- **UI Framework**: Android Jetpack Compose & Material 3
- **Build System**: Android Gradle 8.7.2

## Features
- Windows 11 inspired desktop environment for Android
- 30+ interactive application modules
- 100+ native features
- Custom launcher icon upload and density mipmap generation
- Component-alias dynamic launcher support

## Building the APK
Run:
\`\`\`bash
./gradlew assembleDebug
\`\`\`
The resulting APK will be at:
\`\`\`
app/build/outputs/apk/debug/app-debug.apk
\`\`\`
