# Proguard rules for Bird PC (com.birdbase.app)
-keepattributes *Annotation*
-keepclassmembers class * {
    @androidx.compose.runtime.Composable *;
}
-dontwarn okhttp3.**
-dontwarn javax.annotation.**
