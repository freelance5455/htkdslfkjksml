package com.birdbase.app

import org.junit.Test
import org.junit.Assert.*

class BirdPCTest {
    @Test
    fun testPackageIdentity() {
        assertEquals("com.birdbase.app", "com.birdbase.app")
    }

    @Test
    fun testModuleCount() {
        assertTrue(AppRegistry.modules.size >= 15)
    }
}
