package com.birdbase.app

import android.content.Context
import android.content.SharedPreferences

class SettingsManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("bird_pc_settings", Context.MODE_PRIVATE)

    fun getTheme(): String = prefs.getString("theme", "dark") ?: "dark"
    fun setTheme(theme: String) = prefs.edit().putString("theme", theme).apply()

    fun getTaskbarAlign(): String = prefs.getString("taskbar_align", "center") ?: "center"
    fun setTaskbarAlign(align: String) = prefs.edit().putString("taskbar_align", align).apply()
}
