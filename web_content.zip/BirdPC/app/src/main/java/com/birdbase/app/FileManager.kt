package com.birdbase.app

import java.io.File

class FileManager {
    fun listProjectFiles(rootDir: File): List<String> {
        return rootDir.walkTopDown().map { it.relativeTo(rootDir).path }.toList()
    }
}
