package com.birdbase.app

/**
 * AppRegistry manages registration of all 32 desktop modules and 100+ native features.
 */
object AppRegistry {
    data class AppModule(val id: String, val name: String, val category: String)

    val modules = listOf(
        AppModule("app-icon-studio", "App Icon Studio", "Development"),
        AppModule("project-exporter", "APK Builder & Exporter", "Development"),
        AppModule("file-explorer", "File Explorer", "Productivity"),
        AppModule("bird-browser", "Bird Browser", "Productivity"),
        AppModule("bird-ai", "Bird AI Copilot", "AI"),
        AppModule("image-studio", "Creative Studio", "Media"),
        AppModule("terminal", "Terminal CLI", "Development"),
        AppModule("task-manager", "Task Manager", "System"),
        AppModule("settings", "Settings", "System"),
        AppModule("notepad", "Notepad", "Productivity"),
        AppModule("app-store", "Bird App Store", "Productivity"),
        AppModule("calculator", "Calculator", "Utilities"),
        AppModule("calendar", "Calendar & Clock", "Utilities"),
        AppModule("checklist", "100+ Features Audit", "Development"),
        AppModule("apk-vs-zip", "APK vs ZIP Explainer", "Development")
    )
}
