package com.birdbase.app

data class WindowState(
    val id: String,
    val title: String,
    val isMinimized: Boolean = false,
    val isMaximized: Boolean = false,
    val zIndex: Int = 0
)

class WindowManager {
    private val windows = mutableListOf<WindowState>()

    fun openWindow(title: String): WindowState {
        val win = WindowState(id = "win-${System.currentTimeMillis()}", title = title)
        windows.add(win)
        return win
    }

    fun closeWindow(id: String) {
        windows.removeAll { it.id == id }
    }
}
