package com.birdbase.app

class BrowserManager {
    private val bookmarks = listOf(
        "https://developer.android.com/compose",
        "https://github.com/birdbase/birdpc-android",
        "https://kotlinlang.org"
    )

    fun getBookmarks(): List<String> = bookmarks
}
