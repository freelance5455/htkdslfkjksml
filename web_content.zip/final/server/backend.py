import os, sqlite3, secrets, hashlib, time, json, re
from datetime import datetime, timezone
from typing import Optional
import httpx
from fastapi import FastAPI, HTTPException, Header, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

DB=os.getenv('DATABASE_PATH','/data/smart_employee.db')
ADMIN_PASSWORD_ENV=os.getenv('ADMIN_PASSWORD','').strip()
ADMIN_SECRET=os.getenv('ADMIN_SECRET','CHANGE_ME_IN_PRODUCTION')
AI_BASE=os.getenv('AI_BASE_URL','https://api.openai.com/v1')
AI_KEY=os.getenv('AI_API_KEY','')
AI_MODEL=os.getenv('AI_MODEL','gpt-4o-mini')
PAYMENT_PROVIDER=os.getenv('PAYMENT_PROVIDER','manual').lower()
ZARINPAL_MERCHANT_ID=os.getenv('ZARINPAL_MERCHANT_ID','').strip()
ZARINPAL_SANDBOX=os.getenv('ZARINPAL_SANDBOX','false').lower()=='true'
PUBLIC_BASE_URL=os.getenv('PUBLIC_BASE_URL','').rstrip('/')
RATE_LIMIT=int(os.getenv('RATE_LIMIT_PER_MINUTE','60'))
app=FastAPI(title='کارمند هوشمند',version='5.0.0')
app.add_middleware(CORSMiddleware,allow_origins=['*'],allow_credentials=False,allow_methods=['*'],allow_headers=['*'])
_hits={}

def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; c.execute('PRAGMA foreign_keys=ON'); return c

def now(): return datetime.now(timezone.utc).isoformat()
def hashpw(p,salt=''): return hashlib.sha256((salt+p+'|'+ADMIN_SECRET).encode()).hexdigest()
def token(n=24): return secrets.token_urlsafe(n)
def init():
    os.makedirs(os.path.dirname(DB) or '.',exist_ok=True)
    c=db(); c.executescript('''
    CREATE TABLE IF NOT EXISTS settings(id INTEGER PRIMARY KEY CHECK(id=1),business_name TEXT NOT NULL DEFAULT 'کارمند هوشمند',tone TEXT NOT NULL DEFAULT 'صمیمی و حرفه‌ای',rule TEXT NOT NULL DEFAULT '',support_phone TEXT DEFAULT '',support_text TEXT DEFAULT 'پشتیبانی',bank_name TEXT DEFAULT '',bank_card TEXT DEFAULT '',bank_iban TEXT DEFAULT '',payment_note TEXT DEFAULT '',gateway_url TEXT DEFAULT '',currency TEXT DEFAULT 'تومان');
    CREATE TABLE IF NOT EXISTS admin(id INTEGER PRIMARY KEY CHECK(id=1),password_hash TEXT NOT NULL,created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,price INTEGER NOT NULL,stock INTEGER NOT NULL DEFAULT 0,emoji TEXT DEFAULT '📦',description TEXT DEFAULT '',active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL,updated_at TEXT);
    CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY AUTOINCREMENT,tracking_token TEXT UNIQUE NOT NULL,items_json TEXT NOT NULL,product_id INTEGER,product_name TEXT NOT NULL,qty INTEGER NOT NULL,total INTEGER NOT NULL,customer_name TEXT DEFAULT '',customer_phone TEXT DEFAULT '',status TEXT NOT NULL DEFAULT 'در انتظار پرداخت',payment_status TEXT NOT NULL DEFAULT 'pending',created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY AUTOINCREMENT,order_id INTEGER NOT NULL,amount INTEGER NOT NULL,provider TEXT NOT NULL DEFAULT 'manual',authority TEXT DEFAULT '',status TEXT NOT NULL DEFAULT 'pending',created_at TEXT NOT NULL,updated_at TEXT NOT NULL,FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE);
    CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,expires_at INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT,action TEXT NOT NULL,detail TEXT DEFAULT '',created_at TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS idx_products_active ON products(active); CREATE INDEX IF NOT EXISTS idx_orders_created ON orders(created_at); CREATE INDEX IF NOT EXISTS idx_payments_status ON payments(status);
    ''')
    if not c.execute('SELECT 1 FROM settings WHERE id=1').fetchone(): c.execute('INSERT INTO settings(id) VALUES(1)')
    if not c.execute('SELECT 1 FROM products').fetchone():
        c.executemany('INSERT INTO products(name,price,stock,emoji,description,created_at,updated_at) VALUES(?,?,?,?,?,?,?)',[( 'هدفون بی‌سیم',890000,12,'🎧','هدفون بی‌سیم مناسب استفاده روزمره.',now(),now()),('ساعت هوشمند',1990000,7,'⌚','ساعت هوشمند با امکانات کاربردی.',now(),now()),('پاوربانک',1190000,18,'🔋','پاوربانک قابل حمل.',now(),now())])
    if ADMIN_PASSWORD_ENV and not c.execute('SELECT 1 FROM admin WHERE id=1').fetchone(): c.execute('INSERT INTO admin(id,password_hash,created_at) VALUES(1,?,?)',(hashpw(ADMIN_PASSWORD_ENV),now()))
    c.commit(); c.close()
init()

def rate_limit(request:Request):
    ip=request.client.host if request.client else 'unknown'; t=int(time.time()); key=(ip,t//60); _hits[key]=_hits.get(key,0)+1
    if _hits[key]>RATE_LIMIT: raise HTTPException(429,'تعداد درخواست‌ها زیاد است؛ کمی بعد دوباره تلاش کنید.')
    if len(_hits)>3000:
        for k in list(_hits):
            if k[1]<t//60-2: _hits.pop(k,None)

def admin_required(authorization: Optional[str]):
    if not authorization or not authorization.startswith('Bearer '): raise HTTPException(401,'ورود مدیریت لازم است')
    t=authorization[7:]; c=db(); r=c.execute('SELECT 1 FROM sessions WHERE token=? AND expires_at>?',(t,int(time.time()))).fetchone(); c.close()
    if not r: raise HTTPException(401,'نشست مدیریت منقضی شده است')

def admin_exists():
    c=db(); r=c.execute('SELECT 1 FROM admin WHERE id=1').fetchone(); c.close(); return bool(r)
def audit(action,detail=''):
    c=db(); c.execute('INSERT INTO audit(action,detail,created_at) VALUES(?,?,?)',(action,detail,now())); c.commit(); c.close()

class PasswordIn(BaseModel): password:str=Field(min_length=6,max_length=200)
class ProductIn(BaseModel): name:str=Field(min_length=1,max_length=120); price:int=Field(ge=0); stock:int=Field(ge=0); emoji:str='📦'; description:str=''; active:bool=True
class OrderItem(BaseModel): product_id:int; qty:int=Field(gt=0,le=100)
class OrderIn(BaseModel): items:list[OrderItem]=Field(min_length=1,max_length=30); customer_name:str=Field(default='',max_length=120); customer_phone:str=Field(default='',max_length=40)
class SettingsIn(BaseModel): business_name:str=Field(min_length=1,max_length=120); tone:str='صمیمی و حرفه‌ای'; rule:str=''; support_phone:str=''; support_text:str='پشتیبانی'; bank_name:str=''; bank_card:str=''; bank_iban:str=''; payment_note:str=''; gateway_url:str=''
class ChatIn(BaseModel): message:str=Field(min_length=1,max_length=2000)
class PaymentIn(BaseModel): order_id:int; provider:str=''
class PaymentCallbackIn(BaseModel): authority:str=''; status:str=''

@app.middleware('http')
async def limiter(request:Request,call_next):
    if request.url.path.startswith('/api/public/'): rate_limit(request)
    return await call_next(request)

@app.get('/api/health')
def health(): return {'ok':True,'version':'5.1.0','admin_configured':admin_exists(),'ai_configured':bool(AI_KEY),'payment_provider':PAYMENT_PROVIDER,'payment_gateway_configured':bool(ZARINPAL_MERCHANT_ID if PAYMENT_PROVIDER=='zarinpal' else (os.getenv('PAYMENT_GATEWAY_URL','') or ''))}

@app.get('/api/public/settings')
def public_settings():
    c=db(); r=c.execute("SELECT business_name,tone,support_phone,support_text,currency,(CASE WHEN gateway_url<>'' THEN 1 ELSE 0 END) payment_gateway_enabled FROM settings WHERE id=1").fetchone(); c.close(); return dict(r)
@app.get('/api/public/products')
def public_products():
    c=db(); r=c.execute('SELECT id,name,price,stock,emoji,description FROM products WHERE active=1 ORDER BY id DESC').fetchall(); c.close(); return [dict(x) for x in r]

@app.post('/api/public/orders')
def public_order(x:OrderIn):
    c=db(); products=[]; total=0
    try:
        for it in x.items:
            p=c.execute('SELECT * FROM products WHERE id=? AND active=1',(it.product_id,)).fetchone()
            if not p: raise HTTPException(404,'یکی از محصولات پیدا نشد')
            if p['stock']<it.qty: raise HTTPException(400,f"موجودی {p['name']} کافی نیست")
            products.append((p,it)); total += p['price']*it.qty
        for p,it in products:
            cur=c.execute('UPDATE products SET stock=stock-?,updated_at=? WHERE id=? AND stock>=?',(it.qty,now(),p['id'],it.qty))
            if cur.rowcount!=1: raise HTTPException(409,'موجودی در لحظه سفارش تغییر کرد')
        tracking=token(16); primary=products[0][0]
        items=[{'product_id':p['id'],'name':p['name'],'qty':it.qty,'price':p['price']} for p,it in products]
        c.execute('INSERT INTO orders(tracking_token,items_json,product_id,product_name,qty,total,customer_name,customer_phone,status,payment_status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(tracking,json.dumps(items,ensure_ascii=False),primary['id'],primary['name'],sum(it.qty for _,it in products),total,x.customer_name,x.customer_phone,'در انتظار پرداخت','pending',now(),now()))
        oid=c.execute('SELECT last_insert_rowid()').fetchone()[0]; c.commit()
        return {'ok':True,'order_id':oid,'tracking_token':tracking,'total':total,'status':'در انتظار پرداخت'}
    except HTTPException:
        c.rollback(); raise
    finally: c.close()

@app.get('/api/public/orders/{tracking}')
def public_order_status(tracking:str):
    c=db(); o=c.execute('SELECT id,tracking_token,items_json,total,customer_name,status,payment_status,created_at,updated_at FROM orders WHERE tracking_token=?',(tracking,)).fetchone(); c.close()
    if not o: raise HTTPException(404,'سفارش پیدا نشد')
    d=dict(o); d['items']=json.loads(d.pop('items_json')); return d

@app.post('/api/public/payments/create')
async def create_payment(x:PaymentIn, request:Request):
    c=db(); o=c.execute('SELECT * FROM orders WHERE id=?',(x.order_id,)).fetchone(); s=c.execute('SELECT * FROM settings WHERE id=1').fetchone()
    if not o: c.close(); raise HTTPException(404,'سفارش پیدا نشد')
    if o['payment_status']=='paid': c.close(); return {'ok':True,'status':'paid','order_id':o['id']}
    provider=(x.provider or PAYMENT_PROVIDER or 'manual').lower()
    authority=token(10)
    c.execute('INSERT INTO payments(order_id,amount,provider,authority,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?)',(o['id'],o['total'],provider,authority,'pending',now(),now()))
    pid=c.execute('SELECT last_insert_rowid()').fetchone()[0]; c.commit(); c.close()
    if provider=='zarinpal':
        if not ZARINPAL_MERCHANT_ID: raise HTTPException(503,'درگاه زرین‌پال هنوز با Merchant ID تنظیم نشده است')
        api='https://sandbox.zarinpal.com/pg/v4/payment' if ZARINPAL_SANDBOX else 'https://payment.zarinpal.com/pg/v4/payment'
        callback=(PUBLIC_BASE_URL or str(request.base_url).rstrip('/'))+'/api/public/payments/zarinpal/callback'
        payload={'merchant_id':ZARINPAL_MERCHANT_ID,'amount':o['total'],'currency':'IRR','description':f'کارمند هوشمند - سفارش {o["id"]}','callback_url':callback,'metadata':{'mobile':o['customer_phone'] or ''}}
        try:
            async with httpx.AsyncClient(timeout=20) as client:
                rr=await client.post(api+'/request.json',json=payload)
            data=rr.json(); code=data.get('data',{}).get('code')
            if code != 100:
                raise HTTPException(502,'ایجاد تراکنش زرین‌پال ناموفق بود')
            auth=str(data['data']['authority'])
            c=db(); c.execute('UPDATE payments SET authority=?,updated_at=? WHERE id=?',(auth,now(),pid)); c.commit(); c.close()
            start='https://sandbox.zarinpal.com/pg/StartPay/' if ZARINPAL_SANDBOX else 'https://www.zarinpal.com/pg/StartPay/'
            return {'ok':True,'provider':'zarinpal','payment_id':pid,'authority':auth,'redirect_url':start+auth}
        except HTTPException: raise
        except Exception: raise HTTPException(502,'ارتباط با زرین‌پال برقرار نشد')
    if provider=='gateway':
        base=s['gateway_url'] or os.getenv('PAYMENT_GATEWAY_URL')
        if not base: raise HTTPException(503,'درگاه عمومی تنظیم نشده است')
        return {'ok':True,'provider':'gateway','payment_id':pid,'redirect_url':base+'?order_id='+str(o['id'])+'&amount='+str(o['total'])+'&authority='+authority}
    return {'ok':True,'provider':'manual','payment_id':pid,'amount':o['total'],'bank_name':s['bank_name'],'bank_card':s['bank_card'],'bank_iban':s['bank_iban'],'payment_note':s['payment_note'],'authority':authority}

@app.get('/api/public/payments/zarinpal/callback')
async def zarinpal_callback(Authority:str='',Status:str=''):
    c=db(); p=c.execute('SELECT * FROM payments WHERE authority=?',(Authority,)).fetchone()
    if not p: c.close(); raise HTTPException(404,'تراکنش پیدا نشد')
    if Status != 'OK':
        c.execute('UPDATE payments SET status="failed",updated_at=? WHERE id=?',(now(),p['id'])); c.commit(); c.close(); return {'ok':False,'status':'cancelled'}
    if not ZARINPAL_MERCHANT_ID: c.close(); raise HTTPException(503,'درگاه تنظیم نشده است')
    api='https://sandbox.zarinpal.com/pg/v4/payment' if ZARINPAL_SANDBOX else 'https://payment.zarinpal.com/pg/v4/payment'
    c.close()
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            rr=await client.post(api+'/verify.json',json={'merchant_id':ZARINPAL_MERCHANT_ID,'amount':p['amount'],'authority':Authority})
        data=rr.json(); code=data.get('data',{}).get('code')
        if code not in (100,101): raise HTTPException(502,'تأیید پرداخت ناموفق بود')
        ref=data.get('data',{}).get('ref_id','')
        c=db(); c.execute('UPDATE payments SET status="paid",updated_at=? WHERE id=?',(now(),p['id'])); c.execute('UPDATE payments SET authority=? WHERE id=?',(f'{Authority}|{ref}',p['id'])); c.execute('UPDATE orders SET payment_status="paid",status="تأیید شده",updated_at=? WHERE id=?',(now(),p['order_id'])); c.commit(); c.close()
        return {'ok':True,'status':'paid','order_id':p['order_id'],'ref_id':ref}
    except HTTPException: raise
    except Exception: raise HTTPException(502,'خطا در تأیید تراکنش')

@app.post('/api/public/chat')
async def public_chat(x:ChatIn):
    c=db(); ps=c.execute('SELECT name,price,stock,description FROM products WHERE active=1').fetchall(); s=c.execute('SELECT * FROM settings WHERE id=1').fetchone(); c.close()
    catalog='\n'.join([f"- {p['name']}: {p['price']} تومان، موجودی {p['stock']}، توضیح: {p['description']}" for p in ps]) or 'هیچ محصولی موجود نیست.'
    if not AI_KEY:
        q=x.message.lower()
        for p in ps:
            if p['name'].lower() in q: return {'reply':f"{p['name']}: {p['price']:,} تومان؛ موجودی {p['stock']} عدد.", 'mode':'local'}
        return {'reply':f"سلام 👋 من کارمند هوشمند {s['business_name']} هستم. درباره محصولات سؤال کن.\n\n{catalog}", 'mode':'local'}
    system=f"تو کارمند فروش {s['business_name']} هستی. لحن: {s['tone']}. فقط بر اساس کاتالوگ پاسخ بده و قیمت/موجودی را حدس نزن. اگر اطلاعات کافی نیست بگو باید از مدیریت پرسیده شود.\n{catalog}\nقانون: {s['rule']}"
    try:
        async with httpx.AsyncClient(timeout=45) as client:
            r=await client.post(AI_BASE.rstrip('/')+'/chat/completions',headers={'Authorization':f'Bearer {AI_KEY}','Content-Type':'application/json'},json={'model':AI_MODEL,'messages':[{'role':'system','content':system},{'role':'user','content':x.message}],'temperature':0.2})
        if r.status_code>=400: raise Exception()
        return {'reply':r.json()['choices'][0]['message']['content'],'mode':'ai'}
    except Exception: raise HTTPException(502,'سرویس هوش مصنوعی در دسترس نیست')

@app.post('/api/admin/setup')
def admin_setup(x:PasswordIn):
    if admin_exists(): raise HTTPException(409,'رمز مدیریت قبلاً تنظیم شده است')
    c=db(); c.execute('INSERT INTO admin(id,password_hash,created_at) VALUES(1,?,?)',(hashpw(x.password),now())); c.commit(); c.close(); audit('admin_setup'); return {'ok':True}
@app.post('/api/admin/login')
def admin_login(x:PasswordIn):
    c=db(); r=c.execute('SELECT password_hash FROM admin WHERE id=1').fetchone(); c.close()
    if not r: raise HTTPException(428,'ابتدا رمز مدیریت را تنظیم کنید')
    if hashpw(x.password)!=r['password_hash']: raise HTTPException(401,'رمز مدیریت اشتباه است')
    t=secrets.token_urlsafe(48); c=db(); c.execute('INSERT INTO sessions VALUES(?,?)',(t,int(time.time())+60*60*24*7)); c.commit(); c.close(); return {'token':t,'expires_in':604800}
@app.post('/api/admin/change-password')
def change_password(x:PasswordIn,authorization:Optional[str]=Header(None)): admin_required(authorization); c=db(); c.execute('UPDATE admin SET password_hash=? WHERE id=1',(hashpw(x.password),)); c.commit(); c.close(); return {'ok':True}
@app.post('/api/admin/logout')
def logout(authorization:Optional[str]=Header(None)):
    admin_required(authorization); c=db(); c.execute('DELETE FROM sessions WHERE token=?',(authorization[7:],)); c.commit(); c.close(); return {'ok':True}
@app.get('/api/admin/products')
def admin_products(authorization:Optional[str]=Header(None)): admin_required(authorization); c=db(); r=c.execute('SELECT * FROM products ORDER BY id DESC').fetchall(); c.close(); return [dict(x) for x in r]
@app.post('/api/admin/products')
def add_product(x:ProductIn,authorization:Optional[str]=Header(None)): admin_required(authorization); c=db(); c.execute('INSERT INTO products(name,price,stock,emoji,description,active,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)',(x.name,x.price,x.stock,x.emoji,x.description,int(x.active),now(),now())); c.commit(); c.close(); return {'ok':True}
@app.put('/api/admin/products/{pid}')
def edit_product(pid:int,x:ProductIn,authorization:Optional[str]=Header(None)):
    admin_required(authorization); c=db(); cur=c.execute('UPDATE products SET name=?,price=?,stock=?,emoji=?,description=?,active=?,updated_at=? WHERE id=?',(x.name,x.price,x.stock,x.emoji,x.description,int(x.active),now(),pid));
    if cur.rowcount==0: c.close(); raise HTTPException(404,'محصول پیدا نشد')
    c.commit(); c.close(); return {'ok':True}
@app.delete('/api/admin/products/{pid}')
def delete_product(pid:int,authorization:Optional[str]=Header(None)): admin_required(authorization); c=db(); c.execute('UPDATE products SET active=0,updated_at=? WHERE id=?',(now(),pid)); c.commit(); c.close(); return {'ok':True}
@app.get('/api/admin/orders')
def admin_orders(authorization:Optional[str]=Header(None)):
    admin_required(authorization); c=db(); r=c.execute('SELECT * FROM orders ORDER BY id DESC').fetchall(); c.close(); out=[]
    for x in r:
        d=dict(x); d['items']=json.loads(d.pop('items_json')); out.append(d)
    return out
@app.put('/api/admin/orders/{oid}/status')
def order_status(oid:int,status:str,authorization:Optional[str]=Header(None)):
    admin_required(authorization); allowed={'در انتظار پرداخت','در انتظار','تأیید شده','ارسال شد','تحویل شد','لغو شد'}
    if status not in allowed: raise HTTPException(400,'وضعیت نامعتبر است')
    c=db(); cur=c.execute('UPDATE orders SET status=?,updated_at=? WHERE id=?',(status,now(),oid)); c.commit(); c.close()
    if cur.rowcount==0: raise HTTPException(404,'سفارش پیدا نشد')
    return {'ok':True}
@app.get('/api/admin/payments')
def admin_payments(authorization:Optional[str]=Header(None)):
    admin_required(authorization); c=db(); r=c.execute('SELECT * FROM payments ORDER BY id DESC').fetchall(); c.close(); return [dict(x) for x in r]
@app.post('/api/admin/payments/{pid}/approve')
def approve_payment(pid:int,authorization:Optional[str]=Header(None)):
    admin_required(authorization); c=db(); p=c.execute('SELECT * FROM payments WHERE id=?',(pid,)).fetchone()
    if not p: c.close(); raise HTTPException(404,'پرداخت پیدا نشد')
    c.execute('UPDATE payments SET status="paid",updated_at=? WHERE id=?',(now(),pid)); c.execute('UPDATE orders SET payment_status="paid",status="تأیید شده",updated_at=? WHERE id=?',(now(),p['order_id'])); c.commit(); c.close(); audit('payment_approved',str(pid)); return {'ok':True}
@app.get('/api/admin/stats')
def admin_stats(authorization:Optional[str]=Header(None)):
    admin_required(authorization); c=db(); p=c.execute('SELECT COUNT(*) n FROM products WHERE active=1').fetchone()['n']; o=c.execute('SELECT COUNT(*) n,COALESCE(SUM(total),0) total FROM orders').fetchone(); paid=c.execute('SELECT COALESCE(SUM(amount),0) total FROM payments WHERE status="paid"').fetchone()['total']; pending=c.execute('SELECT COUNT(*) n FROM orders WHERE payment_status="pending"').fetchone()['n']; c.close(); return {'products':p,'orders':o['n'],'sales':o['total'],'paid':paid,'pending_payments':pending}
@app.get('/api/admin/settings')
def admin_settings(authorization:Optional[str]=Header(None)): admin_required(authorization); c=db(); r=c.execute('SELECT business_name,tone,rule,support_phone,support_text,bank_name,bank_card,bank_iban,payment_note,gateway_url FROM settings WHERE id=1').fetchone(); c.close(); return dict(r)
@app.put('/api/admin/settings')
def admin_set_settings(x:SettingsIn,authorization:Optional[str]=Header(None)):
    admin_required(authorization); c=db(); c.execute('UPDATE settings SET business_name=?,tone=?,rule=?,support_phone=?,support_text=?,bank_name=?,bank_card=?,bank_iban=?,payment_note=?,gateway_url=? WHERE id=1',(x.business_name,x.tone,x.rule,x.support_phone,x.support_text,x.bank_name,x.bank_card,x.bank_iban,x.payment_note,x.gateway_url)); c.commit(); c.close(); return {'ok':True}
@app.get('/api/admin/audit')
def admin_audit(authorization:Optional[str]=Header(None)): admin_required(authorization); c=db(); r=c.execute('SELECT * FROM audit ORDER BY id DESC LIMIT 100').fetchall(); c.close(); return [dict(x) for x in r]

app.mount('/',StaticFiles(directory='web',html=True),name='web')
