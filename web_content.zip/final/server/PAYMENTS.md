# پرداخت واقعی

این پروژه پرداخت را به شکل server-side پیاده کرده است. کلید درگاه داخل APK قرار نمی‌گیرد.

## زرین‌پال
متغیرهای زیر را روی سرور تنظیم کنید:
- `PAYMENT_PROVIDER=zarinpal`
- `ZARINPAL_MERCHANT_ID=...`
- `ZARINPAL_SANDBOX=false` برای محیط واقعی
- `PUBLIC_BASE_URL=https://دامنه-واقعی`

جریان:
1. کاربر سفارش می‌سازد.
2. `/api/public/payments/create` تراکنش را از سرور ایجاد می‌کند.
3. کاربر به StartPay هدایت می‌شود.
4. زرین‌پال به callback برمی‌گردد.
5. سرور verify می‌کند.
6. فقط بعد از verify موفق، `payment_status=paid` و دسترسی/وضعیت سفارش فعال می‌شود.

بدون Merchant ID واقعی، پرداخت زنده عمداً فعال نمی‌شود.

## درگاه دیگر
ساختار provider جداست و می‌توان adapter همان درگاه را اضافه کرد؛ هیچ credential محرمانه‌ای داخل کد یا APK قرار ندهید.
