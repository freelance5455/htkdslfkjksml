# کارمند هوشمند — Android

اپ رسمی Android به صورت WebView امن به Backend وصل می‌شود. URL سرور در `MainActivity.kt` قرار دارد و باید پس از فعال‌شدن دامنه واقعی تنظیم شود.

## Build
Android Studio رسمی از Gradle/Android Gradle Plugin برای build و تولید APK/AAB استفاده می‌کند. این محیط فعلی Android SDK/Gradle cache لازم برای build نهایی را ندارد، بنابراین این بسته سورس قابل build است، نه APK ادعایی.

## پرداخت
پرداخت روی سرور انجام می‌شود؛ Merchant ID و secret هرگز داخل APK قرار نمی‌گیرند. فعال‌شدن اشتراک فقط بعد از verify موفق درگاه انجام می‌شود.
