plugins { id("com.android.application"); kotlin("android") }

android { namespace = "ir.karmandhooshmand.app"; compileSdk = 35
    defaultConfig { applicationId = "ir.karmandhooshmand.app"; minSdk = 24; targetSdk = 35; versionCode = 1; versionName = "1.0.0" }
    buildTypes { release { isMinifyEnabled = true; proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro") } }
}

dependencies { implementation("androidx.core:core-ktx:1.15.0"); implementation("androidx.appcompat:appcompat:1.7.0") }
