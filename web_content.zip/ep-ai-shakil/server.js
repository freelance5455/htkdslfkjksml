import "dotenv/config";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import multer from "multer";
import OpenAI, { toFile } from "openai";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);
const MODEL = process.env.OPENAI_MODEL || "gpt-6-astra";
const openai = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

app.use(helmet({ crossOriginResourcePolicy: { policy: "cross-origin" } }));
app.use(cors());
app.use(express.json({ limit: "12mb" }));
app.use("/api", rateLimit({ windowMs: 60_000, limit: 30, standardHeaders: true, legacyHeaders: false }));

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024, files: 1 }
});

function requireAI(req, res, next) {
  if (!openai) return res.status(503).json({ error: "সার্ভারে OPENAI_API_KEY সেট করা হয়নি।" });
  next();
}

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, app: "EP AI - SHAKIL", aiConfigured: Boolean(openai) });
});

app.post("/api/chat", requireAI, async (req, res) => {
  try {
    const { message, history = [], imageDataUrl, useWebSearch = false } = req.body || {};
    if (typeof message !== "string" || !message.trim()) {
      return res.status(400).json({ error: "একটি প্রশ্ন লিখুন।" });
    }
    if (message.length > 12000) return res.status(400).json({ error: "প্রশ্নটি অনেক বড়।" });

    const safeHistory = Array.isArray(history)
      ? history.slice(-12).filter(m =>
          m && ["user", "assistant"].includes(m.role) &&
          typeof m.content === "string" && m.content.length <= 12000
        )
      : [];

    const content = [{ type: "input_text", text: message.trim() }];
    if (typeof imageDataUrl === "string" &&
        /^data:image\/(png|jpeg|jpg|webp);base64,/.test(imageDataUrl) &&
        imageDataUrl.length < 8_000_000) {
      content.push({ type: "input_image", image_url: imageDataUrl });
    }

    const input = [
      ...safeHistory.map(m => ({ role: m.role, content: m.content })),
      { role: "user", content }
    ];

    const response = await openai.responses.create({
      model: MODEL,
      instructions: "You are EP AI – SHAKIL, a helpful, safe, bilingual Bengali and English assistant. Reply in the language the user uses. Be clear, accurate, age-appropriate, and honest about uncertainty. Never claim to have performed actions you did not perform.",
      input,
      ...(useWebSearch ? { tools: [{ type: "web_search" }] } : {})
    });

    res.json({ reply: response.output_text || "দুঃখিত, কোনো উত্তর পাওয়া যায়নি।" });
  } catch (err) {
    console.error("Chat error:", err?.message || err);
    res.status(500).json({ error: "AI উত্তর তৈরি করা যায়নি। সার্ভার সেটিংস ও API usage পরীক্ষা করুন।" });
  }
});

app.post("/api/image", requireAI, async (req, res) => {
  try {
    const prompt = String(req.body?.prompt || "").trim();
    if (!prompt) return res.status(400).json({ error: "ছবির বর্ণনা লিখুন।" });
    if (prompt.length > 2000) return res.status(400).json({ error: "বর্ণনাটি অনেক বড়।" });

    const result = await openai.images.generate({
      model: "gpt-image-2",
      prompt,
      size: "1024x1024"
    });
    const image = result.data?.[0]?.b64_json;
    if (!image) return res.status(502).json({ error: "ছবি তৈরি হয়নি।" });
    res.json({ imageDataUrl: `data:image/png;base64,${image}` });
  } catch (err) {
    console.error("Image error:", err?.message || err);
    res.status(500).json({ error: "ছবি তৈরি করা যায়নি। API image access ও billing পরীক্ষা করুন।" });
  }
});

app.post("/api/file", requireAI, upload.single("file"), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: "একটি PDF বা ডকুমেন্ট নির্বাচন করুন।" });
    const allowed = ["application/pdf", "text/plain"];
    if (!allowed.includes(req.file.mimetype)) {
      return res.status(400).json({ error: "এই ডেমোতে PDF ও TXT ফাইল সমর্থিত।" });
    }
    const uploaded = await openai.files.create({
      file: await toFile(req.file.buffer, req.file.originalname),
      purpose: "user_data"
    });
    res.json({ fileId: uploaded.id, filename: req.file.originalname });
  } catch (err) {
    console.error("File error:", err?.message || err);
    res.status(500).json({ error: "ফাইল আপলোড করা যায়নি।" });
  }
});

app.post("/api/file/ask", requireAI, async (req, res) => {
  try {
    const { fileId, question } = req.body || {};
    if (typeof fileId !== "string" || !fileId.startsWith("file_")) {
      return res.status(400).json({ error: "ফাইলটি আগে আপলোড করুন।" });
    }
    const response = await openai.responses.create({
      model: MODEL,
      input: [{
        role: "user",
        content: [
          { type: "input_file", file_id: fileId },
          { type: "input_text", text: String(question || "এই ফাইলটির সারাংশ বাংলায় দাও।").slice(0, 3000) }
        ]
      }]
    });
    res.json({ reply: response.output_text || "কোনো উত্তর পাওয়া যায়নি।" });
  } catch (err) {
    console.error("File ask error:", err?.message || err);
    res.status(500).json({ error: "ফাইল বিশ্লেষণ করা যায়নি।" });
  }
});

// The Android app loads the same web interface from the app bundle.
app.use(express.static(path.join(__dirname, "public")));
app.get(/.*/, (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, "0.0.0.0", () => {
  console.log(`EP AI server running on http://localhost:${PORT}`);
  if (!openai) console.log("Set OPENAI_API_KEY in .env to enable AI features.");
});