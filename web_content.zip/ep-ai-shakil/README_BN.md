# EP AI – SHAKIL (Android + Backend)

এটি একটি starter project। এতে আছে বাংলা/ইংরেজি chat UI, chat history (এই ডিভাইসের browser storage-এ), image input, image generation, optional web search, voice input/output, এবং PDF/TXT upload ও analysis।

## কী কী লাগবে
- Node.js 20 বা তার পরের LTS সংস্করণ
- একটি OpenAI API key এবং API usage/billing access
- Android Studio (APK বানাতে)
- Android ফোনে ইনস্টল করার জন্য Android SDK

## 1) Backend চালু করো
প্রজেক্ট ফোল্ডারে terminal খুলে চালাও:

```bash
npm install
```

`.env.example` কপি করে `.env` নাম দাও এবং তাতে নিজের API key যোগ করো:

```env
OPENAI_API_KEY=your_real_key_here
OPENAI_MODEL=gpt-6-astra
PORT=3000
```

তারপর:

```bash
npm start
```

Backend `http://localhost:3000`-এ চলবে। `http://localhost:3000/api/health` খুলে `aiConfigured: true` দেখো।

**নিরাপত্তা:** `.env` বা API key কখনো কাউকে পাঠাবে না, GitHub-এ আপলোড করবে না, এবং Android app-এর HTML/JS-এ বসাবে না। API key শুধু backend server-এ থাকবে। API ব্যবহারে খরচ হতে পারে; usage limit সেট করে রাখো।

## 2) Browser-এ পরীক্ষা
Backend চালু রেখে `http://localhost:3000` খোলো। Chat, web search toggle, image generation, image attach, voice এবং PDF/TXT feature পরীক্ষা করো।

## 3) Android APK project তৈরি
Android build-এর জন্য কম্পিউটারে Android Studio দরকার। Terminal-এ:

```bash
npm run android:add
npm run android:sync
npm run android:open
```

Android Studio-তে Gradle sync শেষ হলে Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করো।

## 4) Android app-কে backend-এর সাথে যুক্ত করা
Release APK-তে backend URL অবশ্যই public HTTPS address হতে হবে। `public/index.html`-এর আগে `app.js` লোড হওয়ার আগেই একটি config script যোগ করো:

```html
<script>
  window.EP_AI_API_BASE = "https://YOUR-BACKEND-DOMAIN";
</script>
<script src="app.js"></script>
```

`YOUR-BACKEND-DOMAIN`-এর জায়গায় তোমার নিজের deployed backend domain বসাও। শুধু `localhost` দিলে অন্য Android ফোনে কাজ করবে না। Backend-কে HTTPS-এ deploy করো এবং API key সেখানে secret environment variable হিসেবে রাখো।

## Feature notes
- AI chat: OpenAI Responses API
- Web search: Responses API-এর `web_search` tool; ব্যবহার করলে অতিরিক্ত API usage হতে পারে।
- Image understanding: image input সহ chat endpoint
- Image generation: Images API (`gpt-image-2`); account/model access লাগতে পারে।
- PDF/TXT: server-এ upload হয়, OpenAI Files API দিয়ে বিশ্লেষণ হয়।
- Voice: browser/device-এর speech recognition ও speech synthesis support-এর ওপর নির্ভর করে।
- Chat history: বর্তমানে শুধু device-এর localStorage-এ; account sync নেই।
- Authentication, cloud database, payments, push notifications এবং production abuse monitoring এই starter project-এ অন্তর্ভুক্ত নয়।

## Troubleshooting
- `OPENAI_API_KEY সেট করা হয়নি`: `.env` ফাইল ও server restart পরীক্ষা করো।
- API error: API key, project access, usage/billing এবং model access পরীক্ষা করো।
- APK-তে AI response আসে না: backend HTTPS URL ঠিকমতো সেট হয়েছে কি না দেখো।
- Voice কাজ করে না: browser/device permission এবং speech API support পরীক্ষা করো।
