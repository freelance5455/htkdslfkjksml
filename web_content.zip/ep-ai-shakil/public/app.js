const $ = (id) => document.getElementById(id);
const messagesEl = $("messages"), promptEl = $("prompt"), welcome = $("welcome");
let chats = JSON.parse(localStorage.getItem("epai_chats") || "[]");
let currentId = null, selectedImage = null, uploadedFileId = null;
let useWebSearch = false, imageMode = false, lang = localStorage.getItem("epai_lang") || "bn";
const API_BASE = window.EP_AI_API_BASE || ""; // Set to deployed backend URL for APK builds if hosted separately.

function api(path){ return `${API_BASE}${path}`; }
function saveChats(){ localStorage.setItem("epai_chats", JSON.stringify(chats)); renderHistory(); }
function currentChat(){ return chats.find(c => c.id === currentId); }
function newChat(){
  currentId = crypto.randomUUID();
  chats.unshift({id:currentId,title:lang==="bn"?"নতুন চ্যাট":"New chat",messages:[]});
  saveChats(); renderMessages(); $("sidebar").classList.remove("open");
}
function renderHistory(){
  $("history").innerHTML = "";
  chats.slice(0,30).forEach(c=>{
    const b=document.createElement("button"); b.className="history-item"+(c.id===currentId?" active":"");
    b.textContent=c.title; b.onclick=()=>{currentId=c.id;renderMessages();renderHistory();$("sidebar").classList.remove("open");};
    $("history").appendChild(b);
  });
}
function renderMessages(){
  messagesEl.innerHTML="";
  const c=currentChat(); const has=!!(c&&c.messages.length);
  welcome.style.display=has?"none":"block";
  if(!c)return;
  c.messages.forEach(m=>appendMessage(m.role,m.content,m.image,false));
}
function appendMessage(role,content,image,actions=true){
  welcome.style.display="none";
  const row=document.createElement("div");row.className=`message ${role}`;
  const av=document.createElement("div");av.className="msg-avatar";av.textContent=role==="user"?"You":"✦";
  const wrap=document.createElement("div");
  const bubble=document.createElement("div");bubble.className="bubble";bubble.textContent=content;
  if(image){const img=document.createElement("img");img.src=image;img.alt="Attached image";bubble.appendChild(img);}
  wrap.appendChild(bubble);
  if(role==="assistant"&&actions){
    const tools=document.createElement("div");tools.className="msg-actions";
    const copy=document.createElement("button");copy.textContent="Copy";copy.onclick=()=>{navigator.clipboard?.writeText(content);toast("Copied");};
    const speak=document.createElement("button");speak.textContent="🔊 Read";speak.onclick=()=>speakText(content);
    tools.append(copy,speak);wrap.appendChild(tools);
  }
  row.append(av,wrap);messagesEl.appendChild(row);$("chatArea").scrollTop=$("chatArea").scrollHeight;
  return bubble;
}
function toast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200);}
function setBusy(on){$("sendBtn").disabled=on;$("sendBtn").textContent=on?"…":"↑";}
function addToCurrent(role,content,image){
  let c=currentChat();if(!c){newChat();c=currentChat();}
  c.messages.push({role,content,image:image||null});
  if(c.title==="নতুন চ্যাট"||c.title==="New chat")c.title=content.slice(0,32)||"Chat";
  saveChats();
}
async function send(){
  const text=promptEl.value.trim();
  if(imageMode){if(!text)return toast("ছবির বর্ণনা লিখুন");return createImage(text);}
  if(!text&&!selectedImage)return;
  if(!currentChat())newChat();
  const history=currentChat().messages.slice(-12).map(m=>({role:m.role,content:m.content}));
  addToCurrent("user",text||"এই ছবিটি বিশ্লেষণ করো",selectedImage);
  appendMessage("user",text||"এই ছবিটি বিশ্লেষণ করো",selectedImage,false);
  promptEl.value="";promptEl.style.height="auto";
  const image=selectedImage;selectedImage=null;$("attachmentPreview").textContent="";
  setBusy(true);const bubble=appendMessage("assistant","EP AI উত্তর তৈরি করছে…",null,false);
  try{
    const r=await fetch(api("/api/chat"),{method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({message:text||"Describe this image in Bengali.",history,imageDataUrl:image,useWebSearch})});
    const data=await r.json();if(!r.ok)throw new Error(data.error||"Request failed");
    bubble.textContent=data.reply;addToCurrent("assistant",data.reply);renderHistory();
    addActionsToBubble(bubble,data.reply);
  }catch(e){bubble.textContent=`সমস্যা: ${e.message}\nBackend সার্ভার চালু আছে এবং API Key সেট করা আছে কি না দেখো।`;}
  finally{setBusy(false);useWebSearch=false;$("webBtn").classList.remove("selected");}
}
function addActionsToBubble(bubble,text){
 const wrap=bubble.parentElement;const tools=document.createElement("div");tools.className="msg-actions";
 const c=document.createElement("button");c.textContent="Copy";c.onclick=()=>{navigator.clipboard?.writeText(text);toast("Copied");};
 const s=document.createElement("button");s.textContent="🔊 Read";s.onclick=()=>speakText(text);
 tools.append(c,s);wrap.appendChild(tools);
}
async function createImage(prompt){
 if(!currentChat())newChat();addToCurrent("user","ছবি তৈরি করো: "+prompt);appendMessage("user","ছবি তৈরি করো: "+prompt,false);
 promptEl.value="";setBusy(true);const bubble=appendMessage("assistant","ছবি তৈরি হচ্ছে…",null,false);
 try{
  const r=await fetch(api("/api/image"),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({prompt})});
  const d=await r.json();if(!r.ok)throw new Error(d.error||"Image request failed");
  bubble.textContent="তোমার তৈরি করা ছবি:";const img=document.createElement("img");img.src=d.imageDataUrl;img.alt=prompt;img.style.maxWidth="100%";bubble.appendChild(img);
  addToCurrent("assistant","তোমার তৈরি করা ছবি: "+prompt);renderHistory();
 }catch(e){bubble.textContent="ছবি তৈরি করা যায়নি: "+e.message;}
 finally{setBusy(false);imageMode=false;$("imageModeBtn").classList.remove("selected");}
}
function speakText(text){
 if(!("speechSynthesis" in window))return toast("এই ডিভাইসে voice playback নেই");
 const u=new SpeechSynthesisUtterance(text);u.lang=/[\u0980-\u09FF]/.test(text)?"bn-BD":"en-US";speechSynthesis.cancel();speechSynthesis.speak(u);
}
$("sendBtn").onclick=send;
promptEl.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send();}});
promptEl.addEventListener("input",()=>{promptEl.style.height="auto";promptEl.style.height=Math.min(promptEl.scrollHeight,150)+"px";});
$("newChat").onclick=newChat;$("clearBtn").onclick=()=>{if(currentChat()){currentChat().messages=[];saveChats();renderMessages();}};
$("menuBtn").onclick=()=>$("sidebar").classList.toggle("open");
$("themeBtn").onclick=()=>{document.body.classList.toggle("light");localStorage.setItem("epai_theme",document.body.classList.contains("light")?"light":"dark");};
if(localStorage.getItem("epai_theme")==="light")document.body.classList.add("light");
$("langBtn").onclick=()=>{lang=lang==="bn"?"en":"bn";localStorage.setItem("epai_lang",lang);applyLanguage();};
function applyLanguage(){
 document.querySelectorAll("[data-en]").forEach(el=>el.textContent=el.dataset[lang]);
 promptEl.placeholder=promptEl.dataset["placeholder"+(lang==="bn"?"Bn":"En")];
}
applyLanguage();
document.querySelectorAll(".suggestion").forEach(b=>b.onclick=()=>{promptEl.value=b.dataset.prompt;send();});
$("webBtn").onclick=()=>{useWebSearch=!useWebSearch;$("webBtn").classList.toggle("selected",useWebSearch);toast(useWebSearch?"Web search enabled":"Web search disabled");};
$("imageModeBtn").onclick=()=>{imageMode=!imageMode;$("imageModeBtn").classList.toggle("selected",imageMode);promptEl.placeholder=imageMode?"কেমন ছবি তৈরি করতে চাও?":"EP AI-কে কিছু জিজ্ঞেস করো...";};
$("attachBtn").onclick=()=>$("imageInput").click();
$("imageInput").onchange=e=>{const f=e.target.files[0];if(!f)return;if(f.size>5*1024*1024)return toast("ছবি ৫ MB-এর কম হতে হবে");const reader=new FileReader();reader.onload=()=>{selectedImage=reader.result;$("attachmentPreview").textContent="ছবি যুক্ত হয়েছে: "+f.name;};reader.readAsDataURL(f);};
$("voiceBtn").onclick=()=>{
 const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR)return toast("এই ব্রাউজারে voice input নেই");
 const rec=new SR();rec.lang=lang==="bn"?"bn-BD":"en-US";rec.onresult=e=>{promptEl.value=e.results[0][0].transcript;};rec.start();
};
$("fileBtn").onclick=()=>$("docInput").click();
$("docInput").onchange=async e=>{
 const f=e.target.files[0];if(!f)return;const fd=new FormData();fd.append("file",f);toast("ফাইল আপলোড হচ্ছে…");
 try{const r=await fetch(api("/api/file"),{method:"POST",body:fd});const d=await r.json();if(!r.ok)throw new Error(d.error);uploadedFileId=d.fileId;$("attachmentPreview").textContent="ফাইল যুক্ত: "+d.filename+" — এখন প্রশ্ন লিখে পাঠাও।";$("fileBtn").classList.add("selected");}
 catch(err){toast(err.message);}
};
const originalSend=send;
$("sendBtn").onclick=async()=>{
 if(uploadedFileId && promptEl.value.trim()){
  const q=promptEl.value.trim();promptEl.value="";if(!currentChat())newChat();appendMessage("user","ফাইল সম্পর্কে: "+q);setBusy(true);const bubble=appendMessage("assistant","ফাইল বিশ্লেষণ হচ্ছে…",null,false);
  try{const r=await fetch(api("/api/file/ask"),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({fileId:uploadedFileId,question:q})});const d=await r.json();if(!r.ok)throw new Error(d.error);bubble.textContent=d.reply;addToCurrent("user","ফাইল সম্পর্কে: "+q);addToCurrent("assistant",d.reply);addActionsToBubble(bubble,d.reply);}
  catch(err){bubble.textContent="সমস্যা: "+err.message;}finally{uploadedFileId=null;$("attachmentPreview").textContent="";$("fileBtn").classList.remove("selected");setBusy(false);}return;
 }
 originalSend();
};
if(chats.length){currentId=chats[0].id;renderMessages();}else newChat();
renderHistory();
