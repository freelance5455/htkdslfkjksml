package com.boardboost.cbse12;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {
    private WebView webView;
    public class AndroidBridge {
        @JavascriptInterface public void exitApp(){ runOnUiThread(() -> finish()); }
        @JavascriptInterface public void openPdf(String assetPath){
            runOnUiThread(() -> {
                try {
                    String clean = assetPath == null ? "" : assetPath.replaceFirst("^/+", "");
                    if (!clean.startsWith("papers/") || clean.contains("..")) throw new IllegalArgumentException("Invalid paper path");
                    File dir = new File(getCacheDir(), "scoredeck");
                    if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("Cannot create cache");
                    String name = new File(clean).getName();
                    File out = new File(dir, name);
                    try (InputStream in = getAssets().open(clean); FileOutputStream fos = new FileOutputStream(out)) {
                        byte[] buf = new byte[8192]; int n;
                        while ((n = in.read(buf)) != -1) fos.write(buf, 0, n);
                    }
                    Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName()+".fileprovider", out);
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setDataAndType(uri, "application/pdf");
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                    try { startActivity(intent); }
                    catch (Exception e) { Toast.makeText(MainActivity.this, "No PDF viewer is installed.", Toast.LENGTH_LONG).show(); }
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Unable to open the paper.", Toast.LENGTH_LONG).show();
                }
            });
        }
    }
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        webView = new WebView(this);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
        if (Build.VERSION.SDK_INT >= 33) getOnBackInvokedDispatcher().registerOnBackInvokedCallback(android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT, this::dispatchBackToWebView);
    }
    private void dispatchBackToWebView(){ if(webView!=null) webView.evaluateJavascript("typeof handleAndroidBack==='function' ? handleAndroidBack() : (window.AndroidBridge&&AndroidBridge.exitApp&&AndroidBridge.exitApp())",null); else finish(); }
    @Override public void onBackPressed(){ if(Build.VERSION.SDK_INT<33) dispatchBackToWebView(); }
    @Override protected void onDestroy(){ if(webView!=null) webView.destroy(); super.onDestroy(); }
}
