ScoreDeck v1.5 — CBSE Class 12 Commerce

Package/application ID: com.boardboost.cbse12
Version: 1.6 (versionCode 7)

This is an incremental upgrade of the existing ScoreDeck v1.3 Android project.
The WebView loads app/src/main/assets/index.html and keeps localStorage compatibility, including the legacy boardboost_v3_ storage prefix.

Included sample-paper assets:
- 5 supplied CBSE 2026–27 sample-paper PDFs
- 58 compressed WebP page images for the in-app viewer

Build with a current Android Studio/Gradle environment. The project targets SDK 35 and keeps minSdk 23.

Important: end-to-end Android device testing could not be performed in this environment because a usable Android SDK/emulator was not available. Static Gradle/project inspection and Java/JS syntax checks were performed. Android runtime verification remains unavailable.
