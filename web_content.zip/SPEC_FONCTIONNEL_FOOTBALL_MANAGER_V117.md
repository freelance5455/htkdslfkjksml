# CGD V117 — Contrat fonctionnel Football Manager (adapté au jeu de dames)

**Exigence fondamentale confirmée par le propriétaire du projet.** Ce document complète le socle technique 0.1. Il ne prétend pas que les fonctions décrites sont déjà développées.

## 1. Principe directeur

CGD V117 doit être un véritable jeu de gestion sportive et de carrière, inspiré de la profondeur de Football Manager et adapté aux dames. Il ne doit pas reprendre la logique technique du précédent jeu : empilement de correctifs, écrans décoratifs, résultats simulés sans cohérence, compétitions isolées ou actions qui ne mettent pas à jour le reste du monde.

Le jeu repose sur un **monde simulé unique**, une **horloge/calendrier central**, des **données cohérentes** et des **moteurs de compétition branchés au même système**.

## 2. Les huit compétitions doivent être accessibles et jouables

Les sept entrées historiques restent distinctes ; la Coupe Fédéral constitue la huitième compétition ajoutée à la demande du propriétaire du projet :
1. Coupe Galactique
2. Coupe des Clubs
3. Champions League
4. Intergalactique des Clubs
5. Intergalactique (sélections nationales)
6. Coupe Lunaire
7. Dame d’Or
8. Coupe Fédéral (nouvelle coupe de clubs inspirée de la Carabao Cup)

Chaque compétition doit disposer d'un écran complet, de son règlement, de ses participants, de son calendrier, de ses rencontres, de son classement ou tableau, de ses résultats, de sa progression et de son palmarès selon son format.

**Jouabilité exigée :**
- le joueur peut consulter toutes les compétitions et leur état réel ;
- son club participe automatiquement lorsqu'il remplit les critères de qualification ;
- chaque rencontre impliquant son club peut être jouée manuellement ou confiée à la simulation ;
- les autres rencontres sont simulées par l'IA au moment où le calendrier avance ;
- chaque résultat est homologué une seule fois et actualise immédiatement les écrans concernés ;
- les groupes, tours, qualifications, éliminations, finales et vainqueurs progressent automatiquement ;
- aucune compétition ne reste bloquée sur une page « bientôt disponible », « moteur non activé » ou une simple maquette ;
- si le club n'est pas qualifié, le jeu explique pourquoi et affiche l'état réel de la compétition, sans fabriquer une participation.

**Dame d’Or :** c'est une distinction individuelle, pas une coupe à rencontres. Elle doit être intégrée comme course de récompense : critères publics, statistiques comparables, candidats, classement/projection, cérémonie, vainqueur et archives. Ne pas la transformer artificiellement en tournoi.

**Intergalactique :** compétition des sélections nationales, distincte de l'Intergalactique des Clubs. La gestion/participation nationale doit être intégrée selon les règles de carrière qui seront arrêtées ; ne jamais fusionner les deux compétitions.

## 3. Les cinq divisions

Hiérarchie obligatoire :
1. Super League
2. Ligue A
3. Ligue B
4. Ligue C
5. Ligue D

Les Ligues C et D conservent l'ouverture différée issue du projet V116 : Ligue C à partir de la saison 3 et Ligue D à partir de la saison 5, chacune avec 12 clubs disponibles, sous réserve de validation finale du calendrier d'ouverture. Les mouvements de clubs préservent identité, historique, damistes, finances et contrats.

Les montées et descentes sont paramétrées par règlement et appliquées une seule fois à la clôture de saison. Aucun club ne peut être dupliqué, perdu ou placé dans deux divisions simultanément.

## 4. Le moteur de match de dames

Un match n'est pas un simple tirage de score. Il utilise un moteur cohérent :
- damiste choisi parmi les deux damistes du club ; adversaire choisi par l'IA ;
- niveau, forme, fatigue, expérience et préparation pris en compte ;
- règles de dames définies et appliquées uniformément ;
- déroulement lisible avec coups/temps forts et résultat produit par la partie ;
- mode manuel pour jouer la partie, mode simulation pour déléguer à l'IA ;
- tactique et consignes influencent le comportement sans garantir artificiellement le résultat.

Préparation à préserver : résumé de l'affiche, choix d'un des deux damistes avec niveau et forme, stratégie Offensive/Équilibrée/Défensive/Agressive, consignes prudent/risqué et centre/ailes, gestion du temps à 20 secondes par tour ; à l’échéance, le joueur perd la main et l’adversaire joue, sans retrait de pion. « Commencer la rencontre » reste désactivé tant qu'aucun damiste n'est choisi ; « Retour » revient à l'écran précédent.

## 5. Calendrier et simulation du monde

Un seul calendrier central orchestre journées des cinq divisions, tours et finales des huit compétitions, repos et préparation, transferts/contrats, événements de carrière et cérémonies.

Quand le joueur avance le temps :
1. identifier tous les événements prévus à cette date ;
2. simuler ou jouer les rencontres de tous les clubs et compétitions ;
3. valider et enregistrer chaque résultat une seule fois ;
4. recalculer classements, statistiques, tableaux, qualifications, finances et actualités ;
5. avancer la date seulement après validation complète.

Une rencontre ne peut être générée deux fois, oubliée, jouée deux fois ou comptabilisée deux fois. Les reports et chevauchements sont gérés explicitement. Le match du club du joueur n'est pas simulé avant son choix « jouer » ou « simuler ».

## 6. Carrière et administration — profondeur attendue

Intégrer progressivement des systèmes réellement reliés : création/choix du club et profil du manager ; deux damistes par club, recrutement, progression, forme, fatigue ; tactiques, entraînement et préparation ; budget, revenus, dépenses, primes, salaires ; contrats et transferts ; staff et administration ; objectifs, réputation, confiance et sécurité du poste ; actualités et boîte de réception ; statistiques historiques, palmarès, trophées et récompenses mensuelles/annuelles ; sauvegarde et reprise de carrière.

Les fonctionnalités sont livrées par modules complets et reliés, pas sous forme de boutons sans action.

## 7. Architecture technique non négociable

- Projet V117 indépendant ; V116 reste intact.
- Modules séparés : calendrier, moteur de dames, championnats, coupes, carrière, finances, transferts, IA, historique, interface.
- Une source de vérité pour l'état du monde et un registre central d'événements/matchs.
- Chaque match possède un identifiant stable, un statut et une trace de traitement.
- Résultats et changements d'état transactionnels/idempotents.
- Règlements déclaratifs/configurables ; aucun correctif tardif ne remplace silencieusement un moteur.
- Validation des données au chargement et à chaque fin de journée/saison.
- Sauvegarde versionnée, migration contrôlée et secours.
- Tests des formats, qualifications, résultats, classements, progression des coupes, saisons, sauvegarde/reprise et cas limites.
- Interface paysage, rubriques accessibles par navigation et défilement, sans suppression de contenu.

## 8. Critères de réception

Une compétition n'est terminée que si son règlement est implémenté ; son format produit les bons participants et rencontres ; matchs manuels et simulés utilisent le même moteur ; toutes les rencontres IA se jouent ; résultats et statistiques s'actualisent ; qualifications et tours progressent jusqu'au vainqueur ; une sauvegarde au milieu de la compétition reprend exactement son état ; plusieurs saisons n'engendrent ni doublons ni blocages.

V117 n'est déclarée prête que lorsque ces critères passent pour les huit compétitions et les cinq divisions, et que la carrière avance sur plusieurs saisons sans incohérence.

## 9. État réel du socle 0.1

Le socle contient une structure initiale de cinq divisions, sept identifiants de compétition, un calendrier aller-retour de démonstration pour les championnats, une sauvegarde locale et six tests unitaires réussis.

Il **ne contient pas encore** le moteur de dames jouable, les sept moteurs complets, l'IA de simulation du monde, les finances, les transferts, le staff ni la carrière Football Manager complète. L'interface actuelle est une base de démonstration et non un jeu final. Le prototype 0.1 ne doit donc pas être présenté comme déjà jouable dans toutes les compétitions.

## 10. Ordre de développement

1. Modèle de données unifié et horloge/calendrier central.
2. Moteur de dames jouable, modes manuel et simulation IA partageant les mêmes règles.
3. Cycle complet d'une journée : matchs, homologation, actualisation, sauvegarde.
4. Championnats des cinq divisions et promotion/relégation.
5. Moteurs des six compétitions à rencontres, progression jusqu'à la finale.
6. Course Dame d'Or et récompenses.
7. Carrière manager, effectif, tactique, finances, transferts et staff.
8. Interface complète, tests multi-saisons, sauvegarde/reprise et validation de bout en bout.

**Décision de conception :** la profondeur de gestion et la jouabilité de toutes les compétitions sont des exigences centrales, pas des options facultatives.

## Mise à jour de développement — étape moteur 0.2
Le projet contient maintenant un premier moteur isolé de dames 10×10 et une partie d'essai contre une IA heuristique. Il applique les prises obligatoires, les prises multiples, les dames volantes, la promotion et la règle de prise maximale. Douze tests automatiques passent à ce stade. Cette partie d'essai n'est pas encore reliée au calendrier central, aux résultats de carrière ni aux sept compétitions : ces intégrations restent des critères bloquants avant la livraison d'une carrière complète.

## Avancement technique — étape 0.3
Le calendrier central sait désormais simuler une journée en laissant en attente la rencontre du club dirigé, ou simuler aussi cette rencontre à la demande. Le moteur de simulation produit des résultats reproductibles à état identique, en fonction de la force et de la forme des deux damistes. Chaque résultat est inscrit une seule fois dans les statistiques et le classement. Les résultats récents sont visibles dans le tableau de bord.

Limite explicite : le résultat du championnat utilise pour l'instant un modèle statistique de force d'équipe. Il n'est pas encore calculé en jouant les coups du damier 10×10 ; le damier d'essai reste séparé du calendrier de carrière.

## 9. Patrimoine galactique à préserver

L'inventaire vérifié dans le code V116 est consigné dans `AUDIT_HERITAGE_V116_V117.md`. Il comprend 24 galaxies, 60 emplacements d'arènes de clubs, 9 arènes spéciales à règles, 11 variantes visuelles, 24 damistes légendaires (13 historiques conservés et 11 ajouts V117), 10 banques, 12 sponsors, 8 promoteurs/diffuseurs, 16 partenaires et 22 entreprises. Ces structures doivent être conservées, puis enrichies par de nouvelles structures galactiques sans remplacement ni suppression. Les nombres encore non vérifiés doivent rester marqués « à inventorier ».

Les 24 damistes légendaires (13 historiques conservés et 11 ajouts V117) doivent conserver leurs identités, leur statut immortel et leurs pouvoirs spécifiques après portage. Le catalogue de données est intégré dans le socle 0.4 ; l'activation complète des pouvoirs reste à développer.

## 10. Règles et temps de match issus de V116

L'inventaire source relève un damier 10×10, 20 pions par camp, prise obligatoire, prises multiples, dames volantes, prise maximale et promotion. Le chronométrage de V116 comprend 10 secondes par tour avec retrait automatique de la dernière pièce du camp fautif en cas de dépassement dans V116 ; cette règle est remplacée en V117 par 20 secondes par tour, puis passage de la main à l’adversaire sans retrait de pion ; un temps global standard de 5 minutes, une prolongation de 3 minutes en cas d'égalité de pièces, et des variantes selon les arènes. L'arène Temporelle remplace le chronomètre par une limite de 40 coups par camp. Les arènes spéciales modifient parfois les règles de déplacement, de capture, de promotion ou les cases du plateau.

Le socle V117 applique le contrôle de légalité des coups et la règle de 20 secondes par tour dans la partie d'essai ; à l'échéance, la main passe à l'adversaire sans retrait de pion. Le temps global, la prolongation et les variantes d'arènes restent à intégrer avant de déclarer le moteur conforme à l'ensemble des règles V116.


## Mise à jour technique — étape 0.8

Les matchs automatiques de championnat utilisent maintenant le même moteur de dames que les parties jouables. Deux IA exécutent des coups légaux sur le damier 10×10, avec les règles de l'arène, les chronomètres globaux, le maximum de prises, les promotions, la fin par absence de pièces/coup légal et la règle des 50 demi-coups sans progrès. Les temps de réflexion simulés respectent le plafond de 20 secondes par tour. Les résultats sont déterministes à partir de l'identifiant de rencontre et de la saison, puis enregistrés une seule fois dans le calendrier central.

Cette étape ne déclare pas les sept compétitions entièrement opérationnelles : leurs formats, tirages, phases, quotas et règles de qualification doivent être portés séparément depuis la V116.


## Ajout utilisateur — Coupe Fédéral (8e compétition)

La V117 comporte désormais huit entrées de compétition : les sept rubriques historiques conservées, plus la nouvelle **Coupe Fédéral**. Cette dernière s'inspire de la Carabao Cup anglaise : coupe à élimination directe, une seule rencontre par confrontation, tirage au sort reproductible, départage aux tirs au but en cas d'égalité et finale sur terrain neutre. Tous les clubs des divisions actives participent. Les matchs sont intégrés au calendrier central, utilisent le moteur commun de dames et ne modifient pas les statistiques du championnat. La Coupe des Clubs conserve son propre format historique de type FA Cup ; elle n'est ni remplacée ni fusionnée avec la Coupe Fédéral.


## 10. Avancement des moteurs de compétition — socle 1.0

La V117 contient huit compétitions au total : sept héritées de V116 et la Coupe Fédéral nouvelle. Au socle 1.0, la Coupe Galactique et la Coupe Fédéral sont raccordées au calendrier central et au moteur commun de dames. Les six autres compétitions ne sont pas encore déclarées opérationnelles.

**Coupe Galactique — format historique V116 porté dans V117 :** 8 clubs, club dirigé inclus avec 7 autres participants tirés au sort ; quarts de finale, demi-finales, finale ; programmation aux journées 6, 12 et 18 du championnat. Les rencontres utilisent le moteur de dames IA ou le plateau manuel du club dirigé. En cas de partie nulle, le prototype V116 faisait un départage aléatoire à 50 % ; V117 utilise un départage déterministe lié à l'identifiant du match pour rendre les sauvegardes reproductibles.

**Coupe Fédéral :** nouvelle compétition, distincte des sept formats historiques, inspirée de la Carabao Cup. Son règlement V117 est documenté dans `STAGE_0_9_COUPe_FEDERAL.md`.

La Coupe des Clubs conserve son règlement historique propre de type FA Cup (36 clubs issus des trois divisions initiales, entrées progressives des divisions), et ne doit pas être confondue avec la Coupe Fédéral.


## Socle 1.1 — Coupe des Clubs

La Coupe des Clubs est raccordée avec son règlement V116 : 36 clubs des trois divisions initiales, entrée progressive Ligue B au premier tour, Ligue A au deuxième, Super League au troisième ; match unique, tirage sans têtes de série, exemption automatique en cas de nombre impair, prolongation puis tirs au but. Le tableau complet est 12 → 18 → 21 → 11 → 6 → 3 → 2 → 1, soit six tours et une finale (35 matchs). Les rencontres sont inscrites au calendrier central et utilisent le moteur commun de dames. Le match du club dirigé reste jouable manuellement. Calendrier confirmé : la Coupe des Clubs se dispute pendant la saison régulière, chaque jeudi du mois lunaire, jusqu'à la finale ; les anciennes dates fixes du mois 8 sont supprimées. Le moteur associe chaque tour au jeudi lunaire correspondant lorsque le calendrier lunaire officiel est fourni. Un jour complet d'intervalle sépare les compétitions ordinaires. Exception de période : les deux compétitions organisées par l'AGD — Coupe Intergalactique des galaxies et Intergalactique des Clubs — se disputent après la fin officielle de la saison régulière FGD, aux dates officielles AGD. Aucune date FGD/AGD n'est inventée. Cette coupe est distincte de la Coupe Fédéral.


## Socle 1.3 — Calendrier de carrière sans chevauchement

La FGD organise les championnats et les coupes des clubs. L'AGD organise la Coupe Intergalactique des galaxies et l'Intergalactique des Clubs. Le calendrier central utilise une semaine interne commençant le lundi : les journées de championnat sont placées le samedi, les créneaux des coupes FGD sont placés le mardi lorsqu'ils sont libres, et la Coupe des Clubs conserve le jeudi lunaire officiel. Chaque événement de compétition est séparé du suivant par au moins un jour complet sans compétition. Le planificateur contrôle également qu'un club ne reçoit pas deux rencontres trop rapprochées.

L'avancement se fait événement par événement : les rencontres des autres clubs sont simulées automatiquement ; le match du club dirigé reste en attente et doit être joué ou simulé avant de poursuivre la carrière. La date de fin de saison régulière est fournie par le calendrier FGD. Les deux dates des compétitions AGD sont fournies séparément par le calendrier AGD et doivent être postérieures à cette fin de saison, avec un jour complet entre les deux.

À la date du socle 1.3, les règles de la Champions League et de la Coupe Lunaire restaient à inventorier. La Champions League a été auditée dans le code V116 et raccordée au moteur V117 au socle 1.5. La Coupe Lunaire a été confirmée par l’utilisateur comme compétition AGD et intégrée au socle 1.6 après audit du moteur V116.


## Étape 1.5 — Champions League Galactique (règles auditées V116)
- Organisateur : FGD.
- Qualification : 32 clubs actifs les mieux classés, ordonnés par points puis niveau ; tirage en 4 chapeaux de 8, répartis en serpentin dans 8 groupes de 4.
- Groupes : chaque club dispute 6 matchs, aller-retour contre les trois adversaires ; 96 rencontres au total.
- Classement : points, différence de buts, buts marqués ; en cas d'égalité parfaite, l'ordre stable du tirage sert uniquement de départage technique, sans inventer un critère sportif supplémentaire.
- Qualification : les deux premiers de chaque groupe, soit 16 clubs.
- Phase finale : huitièmes, quarts, demi-finales et finale en match unique ; pas de petite finale. Les matchs à égalité sont départagés de façon reproductible dans le moteur V117.
- Total : 111 rencontres par édition (96 groupes + 15 éliminations directes).
- Les rencontres utilisent le moteur commun de dames, le calendrier central, les statistiques propres à la compétition et la protection anti-double-comptage.
- Chaque journée de groupes et chaque tour final reçoit un créneau FGD libre. Les dates existantes sont protégées lors de la création dynamique des tours suivants.


## Coupe Lunaire AGD (socle 1.6)
Compétition annuelle entre les huit représentants galactiques du moteur V116 : Astra Nova, Orion, Andromède, Nébula, Vega, Solarys, Éclipse et Lyris. Élimination directe en trois tours : 4 quarts, 2 demi-finales, 1 finale, sans petite finale. Fenêtre historique du douzième mois lunaire, créneaux espacés de sept jours. Le manager peut choisir une galaxie à représenter et jouer son match sur le damier ; sinon l'IA simule toutes les rencontres. Résultats et champion sont archivés sans incidence sur les classements des clubs.


## Mise à jour socle 1.7 — Coupe Intergalactique des galaxies

Le moteur AGD à 24 sélections est intégré : six groupes de quatre, 36 rencontres de groupes. Les deux premiers de chaque groupe et les quatre meilleurs troisièmes sont qualifiés, soit 16 sélections. Elles disputent les huitièmes, quarts, demi-finales et finale (51 rencontres au total). L'édition a lieu tous les trois cycles saisonniers. Les rencontres de la sélection dirigée restent jouables manuellement. La date d'ouverture provient du calendrier officiel AGD ; les étapes sont espacées de deux jours.


## Mise à jour socle 1.8 — Intergalactique des Clubs

Le moteur AGD est intégré selon le format V116 : 32 clubs, quatre chapeaux, huit groupes de quatre, trois journées de groupes, deux qualifiés par groupe, puis huitièmes, quarts, demi-finales et finale (63 rencontres). Les clubs doivent disposer d'une licence active et ne pas être suspendus. V117 refuse les faux clubs de remplissage présents dans l'ancien code : si moins de 32 clubs réels sont éligibles, l'édition est bloquée. La fenêtre AGD reprend les jours de programme historiques et respecte le repos entre les deux compétitions intergalactiques.

## Gouvernance de la Dame d’Or, messagerie, presse et négociations — décisions confirmées

La Dame d’Or est organisée par la Fédération Galactique des Dames (FGD), avec la collaboration de l’Association Galactique des Dames (AGD).

La messagerie et la presse doivent proposer une gestion relationnelle inspirée de Football Manager 26 : le manager reçoit des préoccupations et demandes des damistes, des supporters, de la direction et des médias, puis peut répondre. Les réponses influencent de manière contextualisée le moral, la confiance, les relations et la réputation. Les échanges et leurs conséquences sont conservés dans l’historique.

Les contrats des damistes doivent être négociables. Les sponsors, partenaires, promoteurs/diffuseurs, banques et autres structures commerciales doivent, au contraire, venir spontanément vers les clubs avec des offres entrantes. Le club ne les démarche pas. Le manager peut accepter, refuser ou négocier les avantages et obligations afin de conclure un accord gagnant-gagnant. Aucun contrat commercial n’est signé automatiquement ; il faut un accord explicite. Les montants, fréquences et barèmes non audités ne sont pas inventés.

Voir `STAGE_2_2_GOUVERNANCE_RELATIONS_NEGOCIATIONS.md` pour les exigences détaillées et l’état réel d’implémentation.
