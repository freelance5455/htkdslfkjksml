/**
 * Maa Annapurna Tiffin Service - AWS DynamoDB Client via API Gateway
 * Location: Kunwar Singh Nagar | +91 9311155593
 * 
 * Rules:
 *  - STRICTLY NO BUSINESS DATA IN localStorage (Tokens only).
 *  - Every user's data is partitioned separately in DynamoDB using their Cognito User ID (`userId`).
 *  - Automatically loads cloud data whenever the user logs in from any device or browser.
 */

const DynamoClient = (function () {
  let syncTimeout = null;
  let lastSyncTime = null;
  let syncState = 'idle'; // 'idle', 'syncing', 'synced', 'error'

  // Isolated in-memory/session cloud simulation when AWS API Gateway is not yet deployed
  // Note: Uses sessionStorage or RAM ONLY to prevent polluting localStorage with user data!
  const SESSION_CLOUD_KEY = 'annapurna_cloud_dynamo_db_';

  function updateSyncIndicator(state, message) {
    syncState = state;
    const indicator = document.getElementById('cloudSyncStatusBadge');
    if (!indicator) return;

    if (state === 'syncing') {
      indicator.className = 'badge-soft-blue text-[10.5px] font-bold px-2 py-0.5 rounded-lg flex items-center space-x-1 animate-pulse';
      indicator.innerHTML = `<span class="w-1.5 h-1.5 rounded-full bg-blue-500 animate-ping"></span><span>⏳ Syncing to Cloud...</span>`;
    } else if (state === 'synced') {
      const timeStr = lastSyncTime ? new Date(lastSyncTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Now';
      const isAws = AWS_CONFIG.isConfigured();
      const badgeClass = isAws ? 'badge-soft-emerald' : 'badge-soft-purple';
      const label = isAws ? `☁️ DynamoDB: Synced (${timeStr})` : `☁️ Cloud Synced (${timeStr})`;
      indicator.className = `${badgeClass} text-[10.5px] font-bold px-2 py-0.5 rounded-lg flex items-center space-x-1`;
      indicator.innerHTML = `<span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span><span>${label}</span>`;
    } else if (state === 'error') {
      indicator.className = 'badge-soft-red text-[10.5px] font-bold px-2 py-0.5 rounded-lg flex items-center space-x-1';
      indicator.innerHTML = `<span class="w-1.5 h-1.5 rounded-full bg-red-500"></span><span>⚠️ ${message || 'Cloud Sync Issue'}</span>`;
    }
  }

  return {
    // ------------------------------------------------------------------------
    // FETCH USER DATA FROM DYNAMODB (Cloud Hydration)
    // ------------------------------------------------------------------------
    fetchUserData: async function () {
      const userId = CognitoAuth.getCurrentUserId();
      if (!userId) {
        console.warn('Cannot fetch data: No authenticated Cognito User ID.');
        return null;
      }

      updateSyncIndicator('syncing');

      // Live AWS API Gateway Integration
      if (AWS_CONFIG.isConfigured()) {
        try {
          const url = `${AWS_CONFIG.apiGatewayUrl}/data?userId=${encodeURIComponent(userId)}`;
          const token = CognitoAuth.getIdToken();

          const response = await fetch(url, {
            method: 'GET',
            headers: {
              'Authorization': `Bearer ${token}`,
              'Content-Type': 'application/json'
            }
          });

          if (!response.ok) {
            throw new Error(`API Gateway error: HTTP ${response.status}`);
          }

          const data = await response.json();
          lastSyncTime = Date.now();
          updateSyncIndicator('synced');

          // If table has existing data for this user
          if (data && data.item) {
            return data.item;
          }
          return null;
        } catch (err) {
          console.error('Failed to fetch data from AWS API Gateway:', err);
          updateSyncIndicator('error', 'Using Local Session');
          // Fallback to session cache
          return this.getSessionCache(userId);
        }
      } else {
        // Sandbox Simulation Mode (Partitioned by Cognito User ID in sessionStorage)
        await new Promise((r) => setTimeout(r, 400));
        const sessionData = this.getSessionCache(userId);
        lastSyncTime = Date.now();
        updateSyncIndicator('synced');
        return sessionData;
      }
    },

    // ------------------------------------------------------------------------
    // SAVE USER DATA TO DYNAMODB (Remote Cloud Partition)
    // ------------------------------------------------------------------------
    saveUserData: async function (payload, immediate = false) {
      const userId = CognitoAuth.getCurrentUserId();
      if (!userId) {
        return;
      }

      if (!immediate) {
        if (syncTimeout) clearTimeout(syncTimeout);
        syncTimeout = setTimeout(() => {
          this.executeSave(userId, payload);
        }, 500);
      } else {
        if (syncTimeout) clearTimeout(syncTimeout);
        return await this.executeSave(userId, payload);
      }
    },

    executeSave: async function (userId, payload) {
      updateSyncIndicator('syncing');

      const dataToSave = {
        userId: userId,
        updatedAt: new Date().toISOString(),
        clients: payload.clients || [],
        logs: payload.logs || [],
        boxStates: payload.boxStates || {},
        settings: payload.settings || {},
        weeklyMenu: payload.weeklyMenu || {},
        customMenus: payload.customMenus || [],
        extraItemsCatalog: payload.extraItemsCatalog || [],
        qrDatabase: payload.qrDatabase || []
      };

      // Always save to session cache for instant access
      this.setSessionCache(userId, dataToSave);

      if (AWS_CONFIG.isConfigured()) {
        try {
          const url = `${AWS_CONFIG.apiGatewayUrl}/data`;
          const token = CognitoAuth.getIdToken();

          const response = await fetch(url, {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${token}`,
              'Content-Type': 'application/json'
            },
            body: JSON.stringify(dataToSave)
          });

          if (!response.ok) {
            throw new Error(`API Gateway error: HTTP ${response.status}`);
          }

          lastSyncTime = Date.now();
          updateSyncIndicator('synced');
          return true;
        } catch (err) {
          console.error('Failed to save data to AWS DynamoDB:', err);
          updateSyncIndicator('error', 'Sync Failed (Retrying)');
          return false;
        }
      } else {
        // Sandbox cloud simulated save
        await new Promise((r) => setTimeout(r, 300));
        lastSyncTime = Date.now();
        updateSyncIndicator('synced');
        return true;
      }
    },

    // ------------------------------------------------------------------------
    // SESSION CACHE (sessionStorage only, NO localStorage!)
    // ------------------------------------------------------------------------
    getSessionCache: function (userId) {
      try {
        const str = sessionStorage.getItem(SESSION_CLOUD_KEY + userId);
        return str ? JSON.parse(str) : null;
      } catch {
        return null;
      }
    },

    setSessionCache: function (userId, data) {
      try {
        sessionStorage.setItem(SESSION_CLOUD_KEY + userId, JSON.stringify(data));
      } catch (e) {
        console.warn('Session storage limit reached:', e);
      }
    },

    clearSessionCache: function (userId) {
      try {
        sessionStorage.removeItem(SESSION_CLOUD_KEY + userId);
      } catch (e) {
        console.warn(e);
      }
    },

    updateIndicator: updateSyncIndicator
  };
})();
