-- Faragooya Season Rewards + CP Wallet (additive migration)
-- Run in Supabase SQL Editor. Assumes public.profiles(id uuid, role text, full_name text).
-- Does not drop or overwrite existing academy/game tables.
begin;
create table if not exists public.fg_cp_wallets (
  user_id uuid primary key references auth.users(id) on delete cascade,
  balance bigint not null default 0 check (balance >= 0),
  xp bigint not null default 0 check (xp >= 0),
  updated_at timestamptz not null default now()
);
create table if not exists public.fg_cp_transactions (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  actor_id uuid references auth.users(id) on delete set null,
  amount bigint not null check (amount <> 0),
  balance_after bigint not null check (balance_after >= 0),
  reason text not null,
  idempotency_key text unique,
  created_at timestamptz not null default now()
);
create table if not exists public.fg_reward_claims (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  reward_key text not null,
  reward_day date not null default (timezone('utc', now())::date),
  cp_awarded integer not null default 0 check (cp_awarded >= 0),
  xp_awarded integer not null default 0 check (xp_awarded >= 0),
  created_at timestamptz not null default now(),
  unique(user_id, reward_key, reward_day)
);
alter table public.fg_cp_wallets enable row level security;
alter table public.fg_cp_transactions enable row level security;
alter table public.fg_reward_claims enable row level security;
drop policy if exists fg_wallet_read_own on public.fg_cp_wallets;
create policy fg_wallet_read_own on public.fg_cp_wallets for select to authenticated using (user_id = auth.uid());
drop policy if exists fg_transactions_read_own on public.fg_cp_transactions;
create policy fg_transactions_read_own on public.fg_cp_transactions for select to authenticated using (user_id = auth.uid());
drop policy if exists fg_claims_read_own on public.fg_reward_claims;
create policy fg_claims_read_own on public.fg_reward_claims for select to authenticated using (user_id = auth.uid());
revoke insert, update, delete on public.fg_cp_wallets from anon, authenticated;
revoke insert, update, delete on public.fg_cp_transactions from anon, authenticated;
revoke insert, update, delete on public.fg_reward_claims from anon, authenticated;

create or replace function public.fg_get_my_rewards()
returns table(balance bigint, xp bigint)
language plpgsql security definer set search_path = public, pg_temp as $$
begin
  if auth.uid() is null then raise exception 'authentication_required'; end if;
  insert into public.fg_cp_wallets(user_id) values(auth.uid()) on conflict(user_id) do nothing;
  return query select w.balance, w.xp from public.fg_cp_wallets w where w.user_id=auth.uid();
end; $$;

create or replace function public.fg_admin_grant_cp(p_user_id uuid, p_amount integer, p_reason text default 'هدیه مدیر', p_key text default null)
returns table(balance bigint)
language plpgsql security definer set search_path = public, pg_temp as $$
declare v_actor uuid := auth.uid(); v_role text; v_balance bigint; v_key text;
begin
  if v_actor is null then raise exception 'authentication_required'; end if;
  select role into v_role from public.profiles where id=v_actor;
  if coalesce(v_role,'') not in ('admin','manager','مدیر') then raise exception 'admin_only'; end if;
  if p_user_id is null or p_amount is null or p_amount=0 or abs(p_amount)>100000 then raise exception 'invalid_amount'; end if;
  v_key := nullif(trim(p_key),'');
  if v_key is not null and exists(select 1 from public.fg_cp_transactions where idempotency_key=v_key) then
    return query select w.balance from public.fg_cp_wallets w where w.user_id=p_user_id; return;
  end if;
  insert into public.fg_cp_wallets(user_id) values(p_user_id) on conflict(user_id) do nothing;
  update public.fg_cp_wallets set balance=balance+p_amount, updated_at=now()
   where user_id=p_user_id and balance+p_amount>=0 returning balance into v_balance;
  if v_balance is null then raise exception 'insufficient_balance_or_invalid_user'; end if;
  insert into public.fg_cp_transactions(user_id,actor_id,amount,balance_after,reason,idempotency_key)
   values(p_user_id,v_actor,p_amount,v_balance,coalesce(nullif(trim(p_reason),''),'تغییر موجودی توسط مدیر'),v_key);
  return query select v_balance;
end; $$;

create or replace function public.fg_claim_daily_reward(p_reward_key text)
returns table(balance bigint, xp bigint, cp_awarded integer, xp_awarded integer)
language plpgsql security definer set search_path = public, pg_temp as $$
declare v_uid uuid := auth.uid(); v_cp integer; v_xp integer; v_balance bigint; v_xp_total bigint; v_day date := timezone('utc',now())::date;
begin
 if v_uid is null then raise exception 'authentication_required'; end if;
 -- The server owns the reward catalog; unknown keys cannot mint arbitrary CP.
 case p_reward_key
  when 'daily_login' then v_cp:=5; v_xp:=10;
  when 'first_match' then v_cp:=12; v_xp:=20;
  when 'ten_correct' then v_cp:=18; v_xp:=30;
  when 'two_wins' then v_cp:=25; v_xp:=45;
  else raise exception 'unknown_reward';
 end case;
 insert into public.fg_cp_wallets(user_id) values(v_uid) on conflict(user_id) do nothing;
 insert into public.fg_reward_claims(user_id,reward_key,reward_day,cp_awarded,xp_awarded)
 values(v_uid,p_reward_key,v_day,v_cp,v_xp) on conflict(user_id,reward_key,reward_day) do nothing;
 if not found then raise exception 'reward_already_claimed'; end if;
 update public.fg_cp_wallets set balance=balance+v_cp,xp=xp+v_xp,updated_at=now()
  where user_id=v_uid returning fg_cp_wallets.balance,fg_cp_wallets.xp into v_balance,v_xp_total;
 insert into public.fg_cp_transactions(user_id,actor_id,amount,balance_after,reason,idempotency_key)
 values(v_uid,v_uid,v_cp,v_balance,'جایزه روزانه: '||p_reward_key,'reward:'||v_uid::text||':'||p_reward_key||':'||v_day::text);
 return query select v_balance,v_xp_total,v_cp,v_xp;
end; $$;
revoke all on function public.fg_get_my_rewards() from public, anon;
revoke all on function public.fg_admin_grant_cp(uuid,integer,text,text) from public, anon;
revoke all on function public.fg_claim_daily_reward(text) from public, anon;
grant execute on function public.fg_get_my_rewards() to authenticated;
grant execute on function public.fg_admin_grant_cp(uuid,integer,text,text) to authenticated;
grant execute on function public.fg_claim_daily_reward(text) to authenticated;
commit;
