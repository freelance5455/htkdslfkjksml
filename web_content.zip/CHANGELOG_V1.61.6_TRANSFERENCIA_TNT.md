# v1.61.6 — Manchete de transferência

- Ao concluir uma transferência, o jogo abre automaticamente uma matéria especial de mercado.
- Layout editorial esportivo inspirado em chamadas de TV esportiva, sem reproduzir logotipo oficial de emissora.
- Exibe clube de origem e destino com os escudos já cadastrados no projeto.
- Exibe uma ilustração vetorial de camisa nas cores do novo clube (não inventa rosto/foto do jogador).
- Manchete e texto usam o nome do atleta e os clubes reais daquela negociação.
- Dados financeiros usam os valores existentes na proposta; quando não há valor, informa que não foi divulgado.
- Inclui duração do contrato, salário semanal e status oficializado.
- A matéria só aparece depois da conclusão/aceitação da transferência, não ao receber uma proposta.
