// سرور ساده برای اپ تولید ویدیو با هوش مصنوعی
// این سرور فقط یک واسط (proxy) بین مرورگر شما و Runway API است.
// کلید API هرگز ذخیره نمی‌شود؛ در هر درخواست از مرورگر می‌آید و مستقیم برای Runway فرستاده می‌شود.

const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const RUNWAY_BASE = "https://api.dev.runwayml.com/v1";
const RUNWAY_VERSION = "2024-11-06";
const HF_BASE = "https://api-inference.huggingface.co/models";

app.use(express.json({ limit: "25mb" })); // برای اجازه‌دادن به تصاویر base64 نسبتاً بزرگ
app.use(express.static(path.join(__dirname, "public")));

function requireApiKey(req, res) {
  const apiKey = req.body?.apiKey || req.query?.apiKey;
  if (!apiKey || typeof apiKey !== "string" || apiKey.trim().length < 10) {
    res.status(400).json({ error: "کلید API معتبر نیست یا وارد نشده است." });
    return null;
  }
  return apiKey.trim();
}

// شروع یک تسک تولید ویدیو (متن‌به‌ویدیو یا تصویر‌به‌ویدیو)
app.post("/api/generate", async (req, res) => {
  const apiKey = requireApiKey(req, res);
  if (!apiKey) return;

  const { mode, model, promptText, promptImage, ratio, duration } = req.body;

  if (!promptText || !promptText.trim()) {
    return res.status(400).json({ error: "توضیح صحنه (پرامپت) نمی‌تواند خالی باشد." });
  }

  const endpoint = mode === "image_to_video" ? "image_to_video" : "text_to_video";

  if (mode === "image_to_video" && !promptImage) {
    return res.status(400).json({ error: "برای حالت تصویر‌به‌ویدیو باید یک تصویر انتخاب کنید." });
  }

  const payload = {
    model: model || (mode === "image_to_video" ? "gen4_turbo" : "gen4.5"),
    promptText: promptText.trim(),
    ratio: ratio || "1280:720",
    duration: Number(duration) || 5
  };
  if (mode === "image_to_video") {
    payload.promptImage = promptImage;
  }

  try {
    const response = await fetch(`${RUNWAY_BASE}/${endpoint}`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        "X-Runway-Version": RUNWAY_VERSION
      },
      body: JSON.stringify(payload)
    });

    const data = await response.json();

    if (!response.ok) {
      return res.status(response.status).json({
        error: data?.error || data?.message || "درخواست ساخت ویدیو رد شد.",
        details: data
      });
    }

    res.json({ taskId: data.id });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "خطا در ارتباط با سرویس Runway.", details: String(err) });
  }
});

// بررسی وضعیت یک تسک
app.get("/api/status/:id", async (req, res) => {
  const apiKey = requireApiKey(req, res);
  if (!apiKey) return;

  const { id } = req.params;

  try {
    const response = await fetch(`${RUNWAY_BASE}/tasks/${id}`, {
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "X-Runway-Version": RUNWAY_VERSION
      }
    });

    const data = await response.json();

    if (!response.ok) {
      return res.status(response.status).json({
        error: data?.error || data?.message || "خطا در دریافت وضعیت تسک.",
        details: data
      });
    }

    res.json(data);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "خطا در ارتباط با سرویس Runway.", details: String(err) });
  }
});

// مسیر رایگان: ساخت ویدیو با مدل‌های متن‌باز روی Hugging Face Inference API
// این مسیر بدون هزینه است ولی کندتر، محدودتر (تعداد درخواست در ساعت) و با کیفیت پایین‌تر از Runway.
app.post("/api/generate-free", async (req, res) => {
  const apiKey = req.body?.apiKey?.trim();
  const promptText = req.body?.promptText?.trim();
  const model = req.body?.model || "ali-vilab/text-to-video-ms-1.7b";

  if (!apiKey || apiKey.length < 5) {
    return res.status(400).json({ error: "توکن Hugging Face را وارد کنید (رایگان از huggingface.co/settings/tokens)." });
  }
  if (!promptText) {
    return res.status(400).json({ error: "توضیح صحنه (پرامپت) نمی‌تواند خالی باشد." });
  }

  const maxAttempts = 6;

  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 4 * 60 * 1000);

      const response = await fetch(`${HF_BASE}/${model}`, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${apiKey}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ inputs: promptText }),
        signal: controller.signal
      });
      clearTimeout(timeout);

      const contentType = response.headers.get("content-type") || "";

      // مدل هنوز روی سرورهای رایگان hugging face بالا نیامده؛ کمی صبر و تلاش دوباره
      if (response.status === 503) {
        const info = await response.json().catch(() => ({}));
        const waitMs = Math.min(Math.ceil((info.estimated_time || 15) * 1000), 30000);
        await new Promise(r => setTimeout(r, waitMs));
        continue;
      }

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        return res.status(response.status).json({
          error: errData.error || "مدل رایگان روی Hugging Face خطا داد.",
          details: errData
        });
      }

      if (contentType.includes("video")) {
        const buf = Buffer.from(await response.arrayBuffer());
        return res.json({ videoData: `data:video/mp4;base64,${buf.toString("base64")}` });
      }

      const data = await response.json().catch(() => null);
      return res.status(500).json({ error: "پاسخ غیرمنتظره از Hugging Face.", details: data });

    } catch (err) {
      if (attempt === maxAttempts - 1) {
        return res.status(500).json({ error: "خطا در ارتباط با Hugging Face.", details: String(err) });
      }
    }
  }

  res.status(504).json({ error: "مدل رایگان بارگذاری نشد؛ چند دقیقه دیگر دوباره امتحان کنید." });
});

app.listen(PORT, () => {
  console.log(`✅ اپ روی آدرس زیر اجراست:  http://localhost:${PORT}`);
});
