# CalcSpace — HTML/JavaScript prototype

## Included
- Functional four-function calculator with decimals, percent, clear and delete.
- First-run demo PIN setup; entering the PIN and pressing `=` opens the dashboard.
- Demo contact list, one-to-one local conversation UI, timestamps, message deletion is not implemented yet, file picker UI, settings and export/delete controls.
- Call screen UI with demo mute/speaker/camera toggles.

## Important limitations
This is a frontend prototype only. Messages are saved locally in the same browser and are NOT delivered to another user. There is no real registration, backend database, remote notifications, upload service, WebRTC media, signaling server, TURN server, end-to-end encryption, or verified secure vault. Call controls are visual demonstrations and do not access the camera or microphone. The PIN hash in browser storage is not a substitute for native secure storage or server-side authentication. Do not use real secrets or sensitive conversations.

## Run
Open `index.html` in a modern browser. Some browser security features such as Web Crypto require a secure context (HTTPS or localhost).

## Wrap as APK
1. Upload `calcspace-web.zip` to a reputable HTML/ZIP-to-APK wrapper or import `index.html` into a WebView-based Android project.
2. Set app name to `CalcSpace` and package ID to a unique reverse-domain identifier.
3. Build a debug APK and test on a spare/test device first.
4. For release use, sign the APK with your own signing key and keep that key private.
5. A wrapped website APK does not add real messaging or calls; backend and WebRTC work is still required.

## Suggested real backend architecture
- Authentication: Supabase Auth or Firebase Authentication.
- Data: Supabase Postgres with strict row-level security, or Firebase Firestore security rules.
- File attachments: private object storage with short-lived signed URLs and size/type limits.
- Notifications: FCM/APNs integration with server-side delivery.
- Calls: WebRTC with authenticated signaling via WebSocket/realtime service and STUN/TURN (a TURN relay may incur cost).
- Security: TLS, rate limits, abuse/report/block workflows, account deletion, minimal logs, encrypted device storage, and a tested cryptographic design before making any encryption claims.
