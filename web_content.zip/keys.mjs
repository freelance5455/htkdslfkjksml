// One-time: node tools/keys.mjs  -> writes ledger_private.pem (KEEP SECRET, never commit) and prints the public key for src-tauri/ledger_pubkey.txt
import { generateKeyPairSync } from "node:crypto";
import { writeFileSync } from "node:fs";
const { publicKey, privateKey } = generateKeyPairSync("ed25519");
writeFileSync("ledger_private.pem", privateKey.export({ type: "pkcs8", format: "pem" }), { mode: 0o600 });
console.log("PUBLIC KEY (paste into src-tauri/ledger_pubkey.txt, no quotes):\n" + publicKey.export({ type: "spki", format: "der" }).subarray(-32).toString("base64"));
console.log("\nPrivate key saved to ledger_private.pem. Add its contents as the GitHub secret LEDGER_PRIVATE_KEY, then delete the file.");
