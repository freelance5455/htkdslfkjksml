# Weather Live — Android project (English + বাংলা)

## What is included
- Native Android shell with runtime GPS permission prompts.
- English/Bengali toggle in the app.
- Current temperature, feels-like temperature, humidity, wind, pressure, UV, hourly and 7-day forecast.
- Weather data fetched from Open-Meteo over HTTPS.
- Refreshes every 5 minutes while the app is open, and requests location again on launch.

## Important limitations
- This is a starter project for testing and completing before publication, not a guaranteed Play Store-approved release.
- It requires internet and location permission. Background updates are intentionally not enabled.
- Forecast is supplied by Open-Meteo. Review their current terms and attribution requirements before release.
- Test on real Android devices, handle location denial and offline states, and prepare a privacy policy because location is used.
- Target SDK / Play requirements change. Verify the current Google Play target API, Data safety form, privacy policy, content rating, app signing, screenshots and listing requirements before publishing.

## Build options
### Android Studio on a computer (recommended)
1. Unzip the project.
2. Open the `WeatherLiveAndroid` folder in Android Studio.
3. Allow Gradle sync and install required Android SDK Platform 35 / JDK 17 if prompted.
4. Run on a phone with USB debugging enabled, or use Build > Build Bundle(s) / APK(s).
5. Test location permission, language toggle, no internet, GPS disabled, and app restart.

### If you only have an Android phone
1. Upload this ZIP to a private GitHub repository using your browser.
2. Open the repository's Actions tab and enable Actions.
3. The included workflow can build a debug APK. Download it from the completed workflow's Artifacts.
4. A debug APK is for testing only. For Play Store, create a signed Android App Bundle (AAB) and complete Google Play Console setup. Google Play Console registration may have a fee; do not assume publishing is free.

## Privacy notes
The app requests approximate/precise location to retrieve local weather. Coordinates are sent to the Open-Meteo API to obtain weather data. Add a public privacy policy describing location use, retention, data sharing and contact details before public release.
