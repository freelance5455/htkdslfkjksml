const NOTAS = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];

let canciones = JSON.parse(localStorage.getItem('cifras_app') || '[]');
if (!canciones.length) {
    canciones = [{
        id: '1',
        titulo: 'De Música Ligera',
        artista: 'Soda Stereo',
        tono: 'Bm',
        cuerpo: '[Bm] Ella usó mi ca[G]beza como un re[D]volver [A]\n[Bm] Incendió mi re[G]fugio y me de[D]jó caer [A]\n\n[Bm] De músi[G]ca li[D]gera [A]\n[Bm] Nada nos [G]libra, nada [D]más que[A]dar'
    }];
}

let actual = null;
let semitonos = 0;
let scrollTimer = null;

function render() {
    const q = document.getElementById('buscar').value.toLowerCase();
    const listEl = document.getElementById('lista');
    listEl.innerHTML = '';
    
    canciones
        .filter(c => c.titulo.toLowerCase().includes(q) || c.artista.toLowerCase().includes(q))
        .forEach(c => {
            const card = document.createElement('div');
            card.className = 'card';
            card.innerHTML = `
                <div>
                    <b>${c.titulo}</b><br>
                    <small style="color:#94a3b8">${c.artista}</small>
                </div>
                <div class="badge">${c.tono}</div>
            `;
            card.onclick = () => abrirVisor(c);
            listEl.appendChild(card);
        });
}

function transponer(acorde, semi) {
    return acorde.replace(/([A-G][#b]?)/g, (m) => {
        let idx = NOTAS.indexOf(m.replace('b', '#'));
        if (idx === -1) return m;
        let nIdx = (idx + semi) % 12;
        if (nIdx < 0) nIdx += 12;
        return NOTAS[nIdx];
    });
}

function renderVisor() {
    let txt = actual.cuerpo.replace(/\[(.*?)\]/g, (m, p1) => `<span class="acorde">${transponer(p1, semitonos)}</span>`);
    document.getElementById('v-cuerpo').innerHTML = txt;
    document.getElementById('v-tono').textContent = transponer(actual.tono || 'C', semitonos);
}

function abrirVisor(c) {
    actual = c;
    semitonos = 0;
    document.getElementById('v-titulo').textContent = c.titulo;
    document.getElementById('v-artista').textContent = c.artista;
    renderVisor();
    document.getElementById('visor').classList.add('open');
}

document.getElementById('v-mas').onclick = () => { semitonos++; renderVisor(); };
document.getElementById('v-menos').onclick = () => { semitonos--; renderVisor(); };

document.getElementById('v-cerrar').onclick = () => {
    document.getElementById('visor').classList.remove('open');
    if (scrollTimer) {
        clearInterval(scrollTimer);
        scrollTimer = null;
        document.getElementById('v-scroll').textContent = '▶ Auto-Scroll';
    }
};

document.getElementById('v-scroll').onclick = function() {
    const c = document.getElementById('v-cuerpo');
    if (scrollTimer) {
        clearInterval(scrollTimer);
        scrollTimer = null;
        this.textContent = '▶ Auto-Scroll';
    } else {
        scrollTimer = setInterval(() => c.scrollTop += 1, 50);
        this.textContent = '⏸ Pausa';
    }
};

document.getElementById('btn-nuevo').onclick = () => {
    document.getElementById('e-titulo').value = '';
    document.getElementById('e-artista').value = '';
    document.getElementById('e-tono').value = 'C';
    document.getElementById('e-cuerpo').value = '';
    document.getElementById('editor').classList.add('open');
};

document.getElementById('e-cerrar').onclick = () => document.getElementById('editor').classList.remove('open');

document.getElementById('e-guardar').onclick = () => {
    const t = document.getElementById('e-titulo').value.trim();
    if (!t) return;
    canciones.push({
        id: Date.now().toString(),
        titulo: t,
        artista: document.getElementById('e-artista').value.trim(),
        tono: document.getElementById('e-tono').value.trim() || 'C',
        cuerpo: document.getElementById('e-cuerpo').value
    });
    localStorage.setItem('cifras_app', JSON.stringify(canciones));
    render();
    document.getElementById('editor').classList.remove('open');
};

document.getElementById('v-borrar').onclick = () => {
    if (confirm('¿Eliminar esta canción?')) {
        canciones = canciones.filter(c => c.id !== actual.id);
        localStorage.setItem('cifras_app', JSON.stringify(canciones));
        render();
        document.getElementById('visor').classList.remove('open');
    }
};

document.getElementById('buscar').oninput = render;

render();
