# Levesie Music

Projet Android léger (Java + WebView), interface noire et verte inspirée des applications de streaming musical.

## Fonctions de cette version
- Interface d'accueil et catégories musicales.
- Lecture de fichiers audio choisis sur le téléphone.
- Lecture de vidéos locales.
- Accès au site TikTok via un lien externe.
- Recherche locale d'interface et navigation.

## Limites importantes
Cette version est un prototype hors ligne : elle ne contient pas de catalogue musical en ligne, de comptes, de synchronisation, de playlists cloud ni d'intégration API officielle TikTok. Les vignettes sont des exemples et ne sont pas des morceaux audio.
Pour diffuser de la musique, il faut obtenir les droits nécessaires et disposer d'un serveur ou d'une API autorisée.

## Construire l'APK
1. Installer Android Studio et un JDK compatible.
2. Ouvrir le dossier `Levesie_Music_Source` dans Android Studio.
3. Laisser Gradle synchroniser le projet (connexion Internet nécessaire pour télécharger le plugin Android).
4. Choisir **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. L'APK debug se trouve normalement dans `app/build/outputs/apk/debug/`.

Pour une version de production : **Build > Generate Signed Bundle / APK** et créer une clé de signature.

## Objectif 5 Mo
Le projet est volontairement sans images lourdes, sans SDK de réseau social et sans bibliothèque audio externe. La taille finale de l'APK dépend de la version Android/du build et doit être mesurée après compilation. La limite de 5 Mo n'est pas garantie.
