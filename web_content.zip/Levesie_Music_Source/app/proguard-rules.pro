# WebView entry point is kept by Android framework manifest references.
