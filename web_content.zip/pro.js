/* Digital Printable: sessions, credits, payments, help, admin. Edit the PRO block only. */
const PRO = {
  SUPABASE_URL: "https://dgbhasgxinjclfjlmglx.supabase.co",
  SUPABASE_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRnYmhhc2d4aW5qY2xmamxtZ2x4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTUyMzcyMzUsImV4cCI6MjExMDgxMzIzNX0.5c4PHP35sXins1yuKbKolazL5ivENw0OWTiCxlYgDCk",
  SUPPORT_EMAIL: "digitalprintable94@gmail.com",
  UPI_ID: "saiful07@ptaxis",
  PAYEE: "Digital Printable",
  PRICE: 25,
  QR_URL: "qr.png"
};
const $ = (id) => document.getElementById(id);
const RECOVER = /type=recovery/.test(location.hash);
const LINK_ERROR = /error_code=/.test(location.hash);
const sb = (window.supabase && !PRO.SUPABASE_URL.includes("YOUR-"))
  ? window.supabase.createClient(PRO.SUPABASE_URL, PRO.SUPABASE_KEY) : null;
let ST = null;
const fmtDate = (s) => new Date(s).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
const esc = (t) => String(t == null ? "" : t).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
function devId() {
  let d = localStorage.getItem("dp_dev");
  if (!d) { d = crypto.randomUUID ? crypto.randomUUID() : Date.now() + "-" + Math.random().toString(36).slice(2); localStorage.setItem("dp_dev", d); }
  return d;
}

// ---------- Local storage: only history stays on the device ----------
loadPersistedState = function () {
  try { const s = JSON.parse(localStorage.getItem("dp_state_v1") || "null"); if (s && Array.isArray(s.history)) state.history = s.history; } catch (e) {}
};
savePersistedState = function () {
  try { localStorage.setItem("dp_state_v1", JSON.stringify({ history: state.history })); } catch (e) {}
};
createDefaultLectureData = function () { state.files = []; state.slides = []; };

// ---------- Back navigation (in-app and device back button) ----------
const ROOT = new Set(["root", "screen-auth", "screen-home", "screen-history", "screen-settings", "screen-profile"]);
let stack = [{ id: "root" }], lastBack = 0;
const _show = showScreen, _switch = switchAuthMode;
history.replaceState({ guard: true }, "");
history.pushState({ id: "root", d: 0 }, "");
function theme(id) { const m = document.querySelector('meta[name="theme-color"]'); if (m) m.content = id === "screen-auth" ? "#4f46e5" : "#ffffff"; }
function renderEntry(e) {
  if (e.id === "screen-auth") _switch(e.mode || "login");
  _show(e.id); theme(e.id);
}
showScreen = function (id) {
  const top = stack[stack.length - 1], prev = stack[stack.length - 2];
  if (top.id === id && !top.mode) return renderEntry({ id });
  if (prev && prev.id === id && !prev.mode && !ROOT.has(top.id)) return history.back();
  const item = { id };
  if (ROOT.has(id) && ROOT.has(top.id)) { stack[stack.length - 1] = item; history.replaceState({ id, d: stack.length - 1 }, ""); }
  else { stack.push(item); history.pushState({ id, d: stack.length - 1 }, ""); }
  renderEntry(item);
};
switchAuthMode = function (m) {
  const top = stack[stack.length - 1];
  if (m === "login" && top.mode) return history.back();
  _switch(m);
  if (m !== "login" && top.mode !== m) {
    const item = { id: "screen-auth", mode: m };
    if (top.mode) { stack[stack.length - 1] = item; history.replaceState({ ...item, d: stack.length - 1 }, ""); }
    else { stack.push(item); history.pushState({ ...item, d: stack.length - 1 }, ""); }
  }
  const n = $("auth-name-wrap"); if (n) n.classList.add("hidden");
};
window.addEventListener("popstate", (ev) => {
  const s = ev.state || {};
  if (s.guard) {
    if (Date.now() - lastBack < 2000) return history.back();
    lastBack = Date.now(); showToast("Press back again to exit");
    const cur = stack[stack.length - 1]; stack = [{ id: cur.id }];
    history.pushState({ id: cur.id, d: 0 }, ""); return;
  }
  if (typeof s.d === "number") { stack = stack.slice(0, s.d + 1); stack[s.d] = { id: s.id, mode: s.mode }; renderEntry(stack[s.d]); }
});
goBack = function () { history.back(); };

// ---------- Status (cached so Premium never flickers off) ----------
function applyStatus(d) {
  ST = d;
  state.isPremium = !!d.premium_until && new Date(d.premium_until) > new Date();
  state.freeLeft = d.free_left;
  state.user = { name: (d.email || "").split("@")[0], email: d.email };
  state.isLoggedIn = true;
  paint();
}
async function refresh() {
  if (!sb) return;
  const { data, error } = await sb.rpc("get_status", { p_device: devId() });
  if (error || !data) return;
  const was = ST && ST.payment && ST.payment.status === "pending";
  applyStatus(data);
  try { localStorage.setItem("dp_status", JSON.stringify(data)); } catch (e) {}
  if (was && state.isPremium) showToast("Premium is now active!");
}
function paint() {
  syncProfileUI(); updateQuotaUI();
  const box = $("pro-status"); if (!box || !ST) return;
  const p = ST.payment; let h = "";
  if (state.isPremium) h = `<div class="rounded-xl bg-teal-50 border border-teal-200 text-teal-800 text-xs font-semibold p-3">Premium active until ${fmtDate(ST.premium_until)}</div>`;
  else if (p && p.status === "pending") h = `<div class="rounded-xl bg-amber-50 border border-amber-300 text-amber-900 text-xs p-3"><b>Payment under review.</b> Premium turns on within 24 hours after we verify it. This message stays until then.</div>`;
  else if (p && p.status === "rejected") h = `<div class="rounded-xl bg-rose-50 border border-rose-300 text-rose-800 text-xs p-3"><b>Payment not accepted${p.reason ? ": " + esc(p.reason) : ""}.</b> <button onclick="openPay()" class="underline font-bold">Send it again</button></div>`;
  box.innerHTML = h;
  const ab = $("pro-admin-btn");
  if (ab) { ab.classList.toggle("hidden", !ST.is_admin); ab.textContent = `Admin panel${ST.pending_count ? " (" + ST.pending_count + " waiting)" : ""}`; }
  const pl = $("profile-plan-label"); if (pl && state.isPremium) pl.textContent = "Premium until " + fmtDate(ST.premium_until);
  const pb = $("profile-upgrade-btn"); if (pb) pb.textContent = state.isPremium ? "Extend 30 days" : "Upgrade now";
}

// ---------- Auth ----------
function startRecovery() {
  _switch("login"); state.authMode = "recovery";
  $("auth-heading").textContent = "Set New Password";
  $("auth-subheading").textContent = "Choose a new password for your account";
  $("auth-email-input").parentElement.classList.add("hidden");
  $("auth-name-wrap").classList.add("hidden");
  $("auth-pass-wrap").classList.remove("hidden");
  $("auth-forgot-row").classList.add("hidden");
  $("auth-submit-btn").textContent = "Update Password";
  $("auth-switch-text").innerHTML = "";
  _show("screen-auth"); theme("screen-auth");
}
function resetAuthFields() { const e = $("auth-email-input"); if (e) e.parentElement.classList.remove("hidden"); }
handleAuthSubmit = async function () {
  if (!sb) return showToast("Backend is not set up yet.");
  const btn = $("auth-submit-btn"), pass = $("auth-pass-input").value;
  if (state.authMode === "recovery") {
    if (pass.length < 6) return showToast("Password must be at least 6 characters.");
    btn.disabled = true;
    const r = await sb.auth.updateUser({ password: pass }); btn.disabled = false;
    if (r.error) return showToast(r.error.message);
    history.replaceState(history.state, "", location.pathname);
    resetAuthFields(); state.authMode = "login"; $("auth-pass-input").value = "";
    await refresh(); showScreen("screen-home"); return showToast("Password updated.");
  }
  const email = $("auth-email-input").value.trim().toLowerCase();
  if (!/^\S+@\S+\.\S+$/.test(email)) return showToast("Enter a valid email address.");
  if (state.authMode === "forgot") {
    btn.disabled = true;
    const { error } = await sb.auth.resetPasswordForEmail(email, { redirectTo: location.origin + location.pathname });
    btn.disabled = false;
    if (!error) switchAuthMode("login");
    return showToast(error ? error.message : "Reset link sent. Check your email.");
  }
  if (pass.length < 6) return showToast("Password must be at least 6 characters.");
  btn.disabled = true;
  const r = state.authMode === "signup"
    ? await sb.auth.signUp({ email, password: pass, options: { emailRedirectTo: location.origin + location.pathname } })
    : await sb.auth.signInWithPassword({ email, password: pass });
  btn.disabled = false;
  if (r.error) return showToast(r.error.message);
  if (!r.data.session) { switchAuthMode("login"); return showToast("Confirm your email, then log in."); }
  await refresh(); showScreen("screen-home");
  showToast(ST && ST.is_admin && ST.pending_count ? `${ST.pending_count} payment(s) waiting for review` : "Welcome!");
};
logoutUser = async function () {
  if (sb) await sb.auth.signOut();
  localStorage.removeItem("dp_status");
  ST = null; state.isLoggedIn = false; state.isPremium = false; state.freeLeft = 2;
  resetAuthFields(); $("pro-status").innerHTML = "";
  showScreen("screen-auth"); switchAuthMode("login"); showToast("Logged out.");
};
resetAllAppData = restorePurchases = function () {};

// ---------- Choose PDF, credits, build ----------
openStep1Wizard = function () { state.files = []; state.slides = []; renderSelectedFiles(); showScreen("screen-step1"); };
handleChoosePdfClick = function () { (state.isPremium || state.freeLeft > 0) ? openStep1Wizard() : openPaywall(); };
const _goStep2 = goToStep2;
goToStep2 = function () { if (!state.slides.length) return showToast("Select at least one PDF first."); _goStep2(); };
const _build = startBuildPdf;
startBuildPdf = async function () {
  if (!sb) return showToast("Backend is not set up yet.");
  const { data, error } = await sb.rpc("consume_credit", { p_device: devId() });
  if (error || !data || !data.ok) {
    await refresh();
    if (data && data.reason === "limit") return openPaywall();
    return showToast("Could not start. Check your internet and try again.");
  }
  state.isPremium = true; // the credit was already charged on the server
  try {
    await _build();
    const h = state.history[0];
    if (h && state.latestPdfBlobUrl) { await pdfPut(h.id, await (await fetch(state.latestPdfBlobUrl)).blob()); }
    while (state.history.length > 15) { const x = state.history.pop(); pdfDel(x.id); }
    savePersistedState();
  } finally { await refresh(); }
};

// ---------- Saved PDFs (IndexedDB) ----------
function idb() { return new Promise((res, rej) => { const r = indexedDB.open("dp_files", 1); r.onupgradeneeded = () => r.result.createObjectStore("pdf"); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); }); }
async function pdfPut(id, blob) { try { const d = await idb(); await new Promise((res) => { const t = d.transaction("pdf", "readwrite"); t.objectStore("pdf").put(blob, id); t.oncomplete = t.onerror = res; }); } catch (e) {} }
async function pdfGet(id) { try { const d = await idb(); return await new Promise((res) => { const q = d.transaction("pdf").objectStore("pdf").get(id); q.onsuccess = () => res(q.result); q.onerror = () => res(null); }); } catch (e) { return null; } }
async function pdfDel(id) { try { const d = await idb(); d.transaction("pdf", "readwrite").objectStore("pdf").delete(id); } catch (e) {} }
async function openPdf(id) {
  const b = await pdfGet(id);
  if (!b) return showToast("This file is no longer on this device. Convert it again.");
  const h = state.history.find((x) => x.id === id), url = URL.createObjectURL(b);
  const a = document.createElement("a"); a.href = url; a.download = (h && h.name) || "Digital_Printable.pdf";
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 120000);
  showToast("PDF saved to Downloads. Tap the notification to open it.");
}
const _del = deleteHistoryItem;
deleteHistoryItem = function (i) { const h = state.history[i]; if (h) pdfDel(h.id); _del(i); };

// ---------- Layout cards: real slides ----------
function slideCell(i) {
  const s = state.slides.filter((x) => x.selected)[i];
  if (!s || !s.imageDataUrl) return "";
  const f = s.isDark && state.printOptions.removeBg ? "filter:invert(1) hue-rotate(180deg)" : "";
  return `<div class="rounded-[3px] overflow-hidden border border-slate-300 bg-white min-h-0"><img src="${s.imageDataUrl}" alt="" class="w-full h-full object-contain" style="${f}"></div>`;
}

// ---------- Premium: benefits first, then payment ----------
openPaywall = function () { if (ST && ST.payment && ST.payment.status === "pending") return openPay(); $("pro-benefits").classList.remove("hidden"); };
function closeBenefits() { $("pro-benefits").classList.add("hidden"); }
function toPayment() { closeBenefits(); openPay(); }
function closePay() { $("pro-pay").classList.add("hidden"); }
async function loadSettings() {
  if (!sb) return;
  const { data } = await sb.from("app_settings").select("key,value,updated_at");
  (data || []).forEach((r) => {
    if (r.key === "price" && +r.value) PRO.PRICE = +r.value;
    if (r.key === "upi_id" && r.value) PRO.UPI_ID = r.value;
    if (r.key === "qr_path" && r.value) PRO.QR_URL = sb.storage.from("qr").getPublicUrl(r.value).data.publicUrl;
  });
}
async function openPay() {
  const b = $("pro-pay-body"), p = ST && ST.payment;
  $("pro-pay").classList.remove("hidden");
  if (p && p.status === "pending") {
    b.innerHTML = `<div class="rounded-xl bg-amber-50 border border-amber-300 text-amber-900 text-sm p-4"><b>Payment under review.</b><br>Premium turns on within 24 hours after we verify your payment. You do not need to send anything again.</div>`;
    return;
  }
  b.innerHTML = '<p class="text-xs text-slate-500 text-center py-6">Loading...</p>';
  await loadSettings();
  const link = `upi://pay?pa=${encodeURIComponent(PRO.UPI_ID)}&pn=${encodeURIComponent(PRO.PAYEE)}&am=${PRO.PRICE}&cu=INR&tn=Digital%20Printable%20Premium`;
  b.innerHTML = `
    <div class="text-center"><div class="text-3xl font-extrabold text-teal-700">₹${PRO.PRICE}</div><div class="text-xs text-slate-500">30 days of Premium</div></div>
    <div class="flex justify-center"><img src="${esc(PRO.QR_URL)}" alt="UPI QR code" class="w-44 h-44 rounded-xl border border-slate-200 object-contain bg-white" onerror="this.style.display='none'"></div>
    <div class="text-center text-xs text-slate-600">UPI ID: <b>${esc(PRO.UPI_ID)}</b></div>
    <div class="grid grid-cols-2 gap-2">
      <a href="${link}" class="py-2.5 rounded-xl bg-indigo-600 text-white text-xs font-bold text-center">Pay in UPI app</a>
      <button onclick="navigator.clipboard&&navigator.clipboard.writeText(PRO.UPI_ID).then(()=>showToast('UPI ID copied'))" class="py-2.5 rounded-xl border-2 border-indigo-600 text-indigo-600 text-xs font-bold">Copy UPI ID</button>
    </div>
    <ol class="text-xs text-slate-600 list-decimal pl-5 space-y-0.5"><li>Pay exactly ₹${PRO.PRICE}.</li><li>Enter the 12-digit transaction ID (UTR).</li><li>Upload the payment screenshot.</li></ol>
    <input id="pay-utr" inputmode="numeric" maxlength="12" placeholder="12-digit transaction ID" class="w-full px-3 py-3 rounded-xl border border-slate-300 text-sm">
    <input id="pay-file" type="file" accept="image/*" class="w-full text-xs">
    <button id="pay-send" onclick="submitPay()" class="w-full py-3.5 rounded-xl bg-gradient-to-r from-indigo-600 to-teal-600 text-white font-extrabold text-sm">Send for verification</button>
    <p class="text-[11px] text-slate-500 text-center">We check every payment by hand. Premium turns on within 24 hours.</p>`;
}
async function submitPay() {
  const utr = $("pay-utr").value.trim(), f = $("pay-file").files[0], btn = $("pay-send");
  if (!/^\d{12}$/.test(utr)) return showToast("Transaction ID must be 12 digits.");
  if (!f || !f.type.startsWith("image/")) return showToast("Upload your payment screenshot.");
  if (f.size > 3 * 1024 * 1024) return showToast("Screenshot must be under 3 MB.");
  btn.disabled = true; btn.textContent = "Sending...";
  const reset = () => { btn.disabled = false; btn.textContent = "Send for verification"; };
  const { data: u } = await sb.auth.getUser();
  const path = `${u.user.id}/${Date.now()}.${f.type === "image/png" ? "png" : f.type === "image/webp" ? "webp" : "jpg"}`;
  const up = await sb.storage.from("proofs").upload(path, f, { contentType: f.type });
  if (up.error) { reset(); return showToast("Upload failed. Try again."); }
  const { data, error } = await sb.rpc("submit_payment", { p_utr: utr, p_path: path });
  if (error || !data || !data.ok) { await sb.storage.from("proofs").remove([path]); reset(); return showToast((data && data.reason) || "Could not send. Try again."); }
  await refresh(); openPay(); showToast("Sent. We will verify within 24 hours.");
}

// ---------- Help ----------
openHelp = function () { showScreen("screen-help"); };
function sendHelpMail() {
  const m = $("help-msg").value.trim();
  if (!m) return showToast("Write your message first.");
  const who = ST && ST.email ? "\n\nAccount: " + ST.email : "";
  location.href = `mailto:${PRO.SUPPORT_EMAIL}?subject=${encodeURIComponent("Digital Printable support")}&body=${encodeURIComponent(m + who)}`;
}

// ---------- Admin ----------
let adminTab = "req";
function closeAdmin() { $("pro-admin").classList.add("hidden"); }
function openAdmin(tab) {
  adminTab = typeof tab === "string" ? tab : adminTab;
  $("pro-admin").classList.remove("hidden");
  document.querySelectorAll("[data-at]").forEach((b) => { const on = b.dataset.at === adminTab; b.className = "flex-1 py-2 rounded-lg text-xs font-bold " + (on ? "bg-white shadow text-indigo-700" : "text-slate-500"); b.dataset.at = b.dataset.at; });
  const body = $("pro-admin-body"); body.innerHTML = '<p class="text-xs text-slate-500 py-4 text-center">Loading...</p>';
  ({ req: adminReq, earn: adminEarn, set: adminSet })[adminTab](body);
}
async function adminReq(b) {
  const { data, error } = await sb.rpc("admin_list");
  if (error) return (b.innerHTML = '<p class="text-xs text-rose-600">Could not load.</p>');
  if (!data.length) return (b.innerHTML = '<p class="text-sm text-slate-500 text-center py-8">No payments waiting.</p>');
  const urls = await Promise.all(data.map((r) => sb.storage.from("proofs").createSignedUrl(r.proof_path, 900)));
  b.innerHTML = data.map((r, i) => { const u = urls[i].data ? urls[i].data.signedUrl : "";
    return `<div class="flex items-center gap-2.5 rounded-xl border border-slate-200 p-2">
      <a href="${u}" target="_blank" rel="noopener" class="shrink-0"><img src="${u}" alt="Payment proof" class="w-14 h-14 rounded-lg object-cover bg-slate-100"></a>
      <div class="min-w-0 flex-1 text-[11px] leading-tight"><b class="block truncate text-xs">${esc(r.email)}</b>UTR ${esc(r.utr)}<br>${fmtDate(r.created_at)}</div>
      <div class="flex flex-col gap-1 shrink-0"><button onclick="decide(${r.id},true)" class="px-3 py-1.5 rounded-lg bg-teal-600 text-white text-[11px] font-bold">Approve</button><button onclick="decide(${r.id},false)" class="px-3 py-1.5 rounded-lg bg-rose-100 text-rose-700 text-[11px] font-bold">Reject</button></div></div>`; }).join("");
}
async function decide(id, ok) {
  let reason = null;
  if (ok) { if (!confirm("Approve and give 30 days of Premium?")) return; }
  else { reason = prompt("Reason for rejection (the user will see it):"); if (reason === null) return; }
  const { error } = await sb.rpc("admin_decide", { p_id: id, p_approve: ok, p_reason: reason });
  showToast(error ? "Failed: " + error.message : ok ? "Approved." : "Rejected.");
  await refresh(); openAdmin("req");
}
async function adminEarn(b) {
  const { data: s, error } = await sb.rpc("admin_stats");
  if (error || !s) return (b.innerHTML = '<p class="text-xs text-rose-600">Run supabase_update.sql first.</p>');
  const cell = (l, v) => `<div class="rounded-xl bg-slate-50 border border-slate-200 p-2.5 text-center"><div class="text-base font-extrabold text-slate-900">${v}</div><div class="text-[10px] text-slate-500">${l}</div></div>`;
  const max = Math.max(1, ...s.daily.map((d) => d.v));
  b.innerHTML = `<div class="grid grid-cols-3 gap-2">${cell("Today", "₹" + s.today)}${cell("Last 7 days", "₹" + s.week)}${cell("Last 30 days", "₹" + s.month)}${cell("Last 12 months", "₹" + s.year)}${cell("All time", "₹" + s.total)}${cell("Active Premium", s.premium)}</div>
    <div class="rounded-xl border border-slate-200 p-3 mt-1"><div class="text-[11px] font-bold text-slate-600 mb-2">Last 7 days</div>
    <div class="flex items-end gap-1.5 h-24">${s.daily.map((d) => `<div class="flex-1 flex flex-col items-center justify-end h-full"><div class="w-full rounded-t bg-indigo-500" style="height:${Math.max(3, (d.v / max) * 100)}%"></div><div class="text-[8px] text-slate-400 mt-1">${esc(d.d.slice(0, 2))}</div></div>`).join("")}</div></div>
    <p class="text-[11px] text-slate-500 text-center">${s.approved} paid orders • ${s.users} users</p>`;
}
async function adminSet(b) {
  await loadSettings();
  b.innerHTML = `<div class="text-center"><img src="${esc(PRO.QR_URL)}" alt="Current QR" class="w-36 h-36 object-contain mx-auto rounded-xl border border-slate-200 bg-white"></div>
    <input id="adm-qr" type="file" accept="image/*" class="w-full text-xs">
    <button onclick="saveQr()" class="w-full py-2.5 rounded-xl bg-indigo-600 text-white text-xs font-bold">Upload new QR</button>
    <input id="adm-upi" value="${esc(PRO.UPI_ID)}" placeholder="UPI ID" class="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm">
    <input id="adm-price" type="number" min="1" value="${PRO.PRICE}" placeholder="Price in rupees" class="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm">
    <button onclick="saveSettings()" class="w-full py-2.5 rounded-xl border-2 border-indigo-600 text-indigo-600 text-xs font-bold">Save UPI ID and price</button>`;
}
async function saveQr() {
  const f = $("adm-qr").files[0];
  if (!f || !f.type.startsWith("image/") || f.size > 2 * 1024 * 1024) return showToast("Choose an image under 2 MB.");
  const path = `qr-${Date.now()}.${f.type === "image/png" ? "png" : f.type === "image/webp" ? "webp" : "jpg"}`;
  const up = await sb.storage.from("qr").upload(path, f, { contentType: f.type });
  if (up.error) return showToast("Upload failed: " + up.error.message);
  const r = await sb.rpc("admin_set_setting", { p_key: "qr_path", p_value: path });
  showToast(r.error ? "Failed: " + r.error.message : "QR updated."); openAdmin("set");
}
async function saveSettings() {
  const upi = $("adm-upi").value.trim(), price = String(parseInt($("adm-price").value, 10) || 0);
  if (!/^[\w.\-]+@[\w.\-]+$/.test(upi) || +price < 1) return showToast("Enter a valid UPI ID and price.");
  const a = await sb.rpc("admin_set_setting", { p_key: "upi_id", p_value: upi });
  const c = await sb.rpc("admin_set_setting", { p_key: "price", p_value: price });
  showToast(a.error || c.error ? "Failed to save." : "Saved."); openAdmin("set");
}

// ---------- UI injection and boot ----------
function injectUI() {
  const sheet = (id, title, close, body) => `<div id="${id}" class="hidden fixed inset-0 z-50 bg-slate-950/70 flex items-end justify-center"><div class="w-full max-w-[430px] max-h-[92vh] overflow-y-auto rounded-t-3xl bg-white p-5 space-y-3"><div class="flex items-center justify-between"><h3 class="font-extrabold text-slate-900">${title}</h3><button onclick="${close}()" class="w-8 h-8 rounded-full bg-slate-200 font-bold" aria-label="Close">✕</button></div>${body}</div></div>`;
  const perk = (t, d) => `<div class="p-2.5 rounded-xl bg-slate-50 border border-slate-100"><div class="font-bold text-xs text-slate-900">${t}</div><div class="text-[11px] text-slate-500">${d}</div></div>`;
  document.body.insertAdjacentHTML("beforeend",
    sheet("pro-benefits", "Go Premium", "closeBenefits", `<div class="space-y-2">${perk("Unlimited conversions", "Convert as many PDFs as you need for 30 days")}${perk("Bigger files", "Up to 600 pages per PDF instead of 100")}${perk("All layouts and Quick Note pages", "Fit 1 to 12 slides on one sheet")}${perk("Saves ink and paper", "Dark slides become clean white pages")}</div><div class="text-center"><span class="text-2xl font-extrabold text-teal-700">₹${PRO.PRICE}</span> <span class="text-xs text-slate-500">for 30 days, no auto-renew</span></div><button onclick="toPayment()" class="w-full py-3.5 rounded-xl bg-gradient-to-r from-indigo-600 to-teal-600 text-white font-extrabold text-sm">Continue to payment</button><button onclick="closeBenefits()" class="w-full py-2.5 text-xs font-bold text-slate-500">Not now</button>`) +
    sheet("pro-pay", "Pay for Premium", "closePay", '<div id="pro-pay-body" class="space-y-3"></div>') +
    `<div id="pro-admin" class="hidden fixed inset-0 z-50 bg-slate-950/70 flex items-end justify-center"><div class="w-full max-w-[430px] h-[88vh] flex flex-col rounded-t-3xl bg-white p-4 gap-3"><div class="flex items-center justify-between"><h3 class="font-extrabold text-slate-900">Admin</h3><button onclick="closeAdmin()" class="w-8 h-8 rounded-full bg-slate-200 font-bold" aria-label="Close">✕</button></div><div class="flex gap-1 p-1 rounded-xl bg-slate-100"><button data-at="req" onclick="openAdmin('req')">Requests</button><button data-at="earn" onclick="openAdmin('earn')">Earnings</button><button data-at="set" onclick="openAdmin('set')">QR and price</button></div><div id="pro-admin-body" class="flex-1 overflow-y-auto space-y-2"></div></div></div>`);
  $("bottom-nav").insertAdjacentHTML("beforebegin", `<div id="screen-help" class="screen"><div class="shrink-0 bg-white border-b border-slate-200 px-4 py-3 flex items-center gap-3"><button onclick="goBack()" class="w-9 h-9 rounded-full bg-slate-100 text-slate-700 font-bold" aria-label="Back">←</button><h2 class="font-extrabold text-slate-900 text-base">Help &amp; Support</h2></div><div class="scroll-area p-4 bg-slate-50"><div class="rounded-2xl bg-white border border-slate-200 p-4 space-y-3"><h3 class="font-extrabold text-slate-900 text-lg">How can we help you?</h3><p class="text-xs text-slate-500">Send us your issue or feature suggestion and we will get back to you.</p><label class="text-xs font-bold text-slate-700" for="help-msg">Your message</label><textarea id="help-msg" rows="5" placeholder="Describe what happened or what feature you would like to see..." class="w-full p-3 rounded-xl border border-slate-300 text-sm"></textarea><button onclick="sendHelpMail()" class="w-full py-3.5 rounded-xl bg-indigo-600 text-white font-extrabold text-sm">Send by email</button><div class="flex items-center justify-between gap-2 rounded-xl bg-indigo-50 p-3"><div class="min-w-0"><div class="text-[11px] text-slate-500">Support email</div><div class="text-sm font-bold text-indigo-700 truncate">${PRO.SUPPORT_EMAIL}</div></div><button onclick="navigator.clipboard&&navigator.clipboard.writeText(PRO.SUPPORT_EMAIL).then(()=>showToast('Email copied'))" class="px-3 py-1.5 rounded-full border border-indigo-300 text-indigo-700 text-xs font-bold">Copy</button></div></div></div></div>`);
  const hb = $("home-banner"); if (hb) hb.insertAdjacentHTML("beforebegin", '<div id="pro-status" class="mb-3"></div>');
  const ub = $("profile-upgrade-btn"); if (ub) ub.insertAdjacentHTML("afterend", '<button id="pro-admin-btn" onclick="openAdmin()" class="hidden mt-3 px-4 py-2.5 rounded-xl bg-slate-900 text-white font-bold text-sm"></button>');
  const g = $("auth-social-section"); if (g) g.innerHTML = "";
}
function ready() { document.documentElement.classList.remove("booting"); }
async function boot() {
  injectUI();
  setTimeout(ready, 3500);
  if (!sb) { const s = $("auth-subheading"); if (s) s.textContent = "Setup needed: fill in pro.js"; return ready(); }
  sb.auth.onAuthStateChange((ev) => { if (ev === "PASSWORD_RECOVERY") { startRecovery(); ready(); } });
  if (LINK_ERROR) { history.replaceState(history.state, "", location.pathname); showToast("This link is invalid or has expired. Request a new one."); ready(); return showScreen("screen-auth"), switchAuthMode("forgot"); }
  const { data } = await sb.auth.getSession();
  if (data.session) {
    state.isLoggedIn = true;
    try { const c = JSON.parse(localStorage.getItem("dp_status") || "null"); if (c) applyStatus(c); } catch (e) {}
    if (RECOVER) startRecovery(); else showScreen("screen-home");
    ready(); loadSettings(); refresh();
  } else { showScreen("screen-auth"); ready(); loadSettings(); }
  setInterval(() => { if (state.isLoggedIn && !document.hidden) refresh(); }, 60000);
  document.addEventListener("visibilitychange", () => { if (!document.hidden && state.isLoggedIn) refresh(); });
}
if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot); else boot();
