# CGD V117 — Socle 1.3 : calendrier de carrière FGD / AGD

## Répartition des autorités (clarification de l'utilisateur)
- **FGD — Fédération Galactique de Dames** : organise les championnats et les coupes des clubs.
- **AGD — Association Galactique de Dames** : organise les deux compétitions galactiques : **Coupe Intergalactique des galaxies** et **Intergalactique des Clubs**.
- **Dame d'Or** reste une distinction individuelle ; son autorité de remise doit être confirmée avant de lui attribuer un organisateur.

## Semaine-type de programmation
Le calendrier interne commence un lundi (jour 1) :
- Samedi : journées de championnat FGD, une fois par semaine, 22 journées dans le format actuel des divisions à 12 clubs.
- Mardi : créneau de coupe FGD, affecté par le planificateur aux tours connus et aux tours futurs une fois leurs formats intégrés.
- Jeudi : Coupe des Clubs, uniquement aux jeudis du calendrier lunaire officiel, pendant la saison régulière et jusqu'à la finale.
- Les autres jours servent au repos, à la récupération et à la préparation.

Chaque événement de compétition est séparé du suivant par au moins deux jours calendaires, ce qui garantit une journée complète sans compétition. Le calendrier contrôle aussi les dates de chaque club afin de détecter deux rencontres trop rapprochées.

## Avancement de carrière
Le bouton « Avancer au prochain événement » sélectionne le prochain événement du calendrier central. Il simule les rencontres des autres clubs avec le moteur commun. Le match du club dirigé reste en attente ; l'avancement ne doit pas sauter ce match et l'utilisateur le joue ou choisit de le simuler. Les résultats sont enregistrés une seule fois.

## Fenêtre AGD de fin de saison
1. La FGD fournit la date officielle de fin de saison régulière.
2. L'AGD fournit deux dates distinctes : Coupe Intergalactique des galaxies et Intergalactique des Clubs.
3. Chaque date AGD doit être postérieure à la fin FGD et les deux événements doivent être séparés par au moins un jour complet.
4. Une fenêtre AGD sans moteur de compétition intégré bloque l'avancement au lieu d'être ignorée.

## Données non inventées / éléments à compléter
- Sept jeudis lunaires officiels consécutifs (écart de sept jours) pour les sept tours de la Coupe des Clubs.
- Date officielle FGD de fin de saison régulière.
- Deux dates officielles AGD.
- Règlements exacts et moteurs des compétitions non encore portées, notamment Champions League et Coupe Lunaire.
- L'autorité organisatrice de la distinction Dame d'Or reste à confirmer.
- Le démarrage de la saison est volontairement bloqué tant que les huit moteurs de compétition ne sont pas prêts, que les sept jeudis lunaires sont chargés, que la date de fin FGD est connue et que les deux dates AGD sont enregistrées. Cela empêche de jouer une saison incomplète et de sauter une compétition. Cela empêche de jouer une saison incomplète et de sauter une compétition.

Aucune date lunaire ou fédérale n'est fabriquée. Les créneaux du mardi sont une règle de programmation interne pour les coupes FGD, pas une prétendue date historique de V116.

## Vérifications
- Calendrier de 22 journées de championnat le samedi.
- Coupe Galactique sur les mardis associés aux journées 6, 12 et 18.
- Coupe Fédéral sur des mardis libres distincts.
- Coupe des Clubs sur les jeudis lunaires officiels.
- Contrôle de l'intervalle minimal entre événements.
- Contrôle de l'intervalle des matchs par club.
- Avancement central : simulation IA et attente du match du club dirigé.
- Blocage d'une fenêtre AGD non encore jouable.

## État de validation du socle 1.3
- Tests automatisés : 90 réussis, 0 échec.
- Vérification syntaxique : tous les modules JavaScript de `src/` passent `node --check`.
- Contrôle d'intégrité de l'état : 424 rencontres dans l'état de démonstration (396 championnat + 28 rencontres de coupes actuellement créées), registre des huit compétitions et validation du calendrier cohérents.
- Le parcours navigateur/tactile n'a pas encore été validé dans cette étape.
- L'écran de saisie des calendriers officiels (jeudis lunaires, date de fin FGD et deux dates AGD) reste à construire. Les fonctions de réception et de validation existent dans le moteur ; les valeurs officielles ne sont pas présentes dans le projet.
- La saison reste volontairement bloquée en l'état : cinq moteurs (Champions League, les deux compétitions AGD, Coupe Lunaire et Dame d'Or) et les calendriers officiels ne sont pas encore prêts. Ce verrou est une protection contre une saison incomplète, pas une erreur de lancement.
