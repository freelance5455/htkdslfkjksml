let currentAnswer;
let score = 0;
let streak = 0;
let highestStreak = 0;
let questionsAnswered = 0;
let correctAnswers = 0;

let currentLevel = "";
let questionTimeout;


// SHOW SCREENS

function showScreen(screenName) {

    // Hide all screens
    document.querySelectorAll(".screen").forEach(screen => {
        screen.classList.add("hidden");
    });


    // Show selected screen
    if (screenName === "home") {
        document.getElementById("homeScreen").classList.remove("hidden");
    }

    else if (screenName === "progress") {
        document.getElementById("progressScreen").classList.remove("hidden");
        updateProgress();
    }

    else if (screenName === "achievement") {
        document.getElementById("achievementScreen").classList.remove("hidden");
        updateAchievements();
    }


    // Update navigation
    document.querySelectorAll(".nav-item").forEach(item => {
        item.classList.remove("active");
    });


    if (screenName === "home") {
        document.querySelectorAll(".nav-item")[0].classList.add("active");
    }

    else if (screenName === "progress") {
        document.querySelectorAll(".nav-item")[1].classList.add("active");
    }

    else if (screenName === "achievement") {
        document.querySelectorAll(".nav-item")[2].classList.add("active");
    }
}


// START GAME

function startGame(level) {

    currentLevel = level;

    document.querySelectorAll(".screen").forEach(screen => {
        screen.classList.add("hidden");
    });

    document.getElementById("gameScreen").classList.remove("hidden");

    document.getElementById("levelBadge").textContent =
        level.toUpperCase();

    generateQuestion();
}


// GENERATE QUESTION

function generateQuestion() {

    let num1;
    let num2;
    let operator;


    // EASY
    if (currentLevel === "easy") {

        num1 = Math.floor(Math.random() * 20) + 1;
        num2 = Math.floor(Math.random() * 20) + 1;

        operator = Math.random() > 0.5 ? "+" : "-";

        if (operator === "-" && num2 > num1) {
            [num1, num2] = [num2, num1];
        }
    }


    // MEDIUM
    else if (currentLevel === "medium") {

        operator = Math.random() > 0.5 ? "*" : "/";


        if (operator === "*") {

            num1 = Math.floor(Math.random() * 12) + 1;
            num2 = Math.floor(Math.random() * 12) + 1;

        } else {

            num2 = Math.floor(Math.random() * 10) + 1;

            currentAnswer =
                Math.floor(Math.random() * 12) + 1;

            num1 = num2 * currentAnswer;

            document.getElementById("question").textContent =
                `${num1} ÷ ${num2} = ?`;

            clearAnswer();

            return;
        }
    }


    // HARD
    else if (currentLevel === "hard") {

        const operators = ["+", "-", "*"];

        operator =
            operators[Math.floor(Math.random() * operators.length)];

        num1 = Math.floor(Math.random() * 50) + 10;
        num2 = Math.floor(Math.random() * 30) + 1;

        if (operator === "-" && num2 > num1) {
            [num1, num2] = [num2, num1];
        }
    }


    // CALCULATE

    if (operator === "+") {
        currentAnswer = num1 + num2;
    }

    else if (operator === "-") {
        currentAnswer = num1 - num2;
    }

    else if (operator === "*") {
        currentAnswer = num1 * num2;
    }


    let symbol = operator;

    if (operator === "*") {
        symbol = "×";
    }


    document.getElementById("question").textContent =
        `${num1} ${symbol} ${num2} = ?`;

    clearAnswer();
}


// CLEAR ANSWER

function clearAnswer() {

    document.getElementById("answer").value = "";

    document.getElementById("message").textContent = "";

    document.getElementById("answer").focus();
}


// CHECK ANSWER

function checkAnswer() {

    const input = document.getElementById("answer");


    if (input.value === "") {

        document.getElementById("message").textContent =
            "⚠️ Please enter an answer!";

        return;
    }


    const userAnswer = Number(input.value);

    questionsAnswered++;


    // CORRECT ANSWER

    if (userAnswer === currentAnswer) {

        score += 10;

        correctAnswers++;

        streak++;


        if (streak > highestStreak) {
            highestStreak = streak;
        }


        document.getElementById("message").textContent =
            "🎉 Correct! Great job!";

    }


    // WRONG ANSWER

    else {

        streak = 0;

        document.getElementById("message").textContent =
            `❌ Correct answer: ${currentAnswer}`;
    }


    // UPDATE HEADER

    document.getElementById("score").textContent = score;

    document.getElementById("streak").textContent = streak;


    // DISABLE MULTIPLE CLICKS

    document.querySelector(".submit-btn").disabled = true;


    questionTimeout = setTimeout(() => {

        document.querySelector(".submit-btn").disabled = false;

        generateQuestion();

    }, 1500);
}


// UPDATE PROGRESS

function updateProgress() {

    document.getElementById("progressScore").textContent = score;

    document.getElementById("highestStreak").textContent =
        highestStreak + " 🔥";

    document.getElementById("questionsAnswered").textContent =
        questionsAnswered;

    document.getElementById("correctAnswers").textContent =
        correctAnswers;
}


// UPDATE ACHIEVEMENTS

function updateAchievements() {

    // FIRST WIN
    if (correctAnswers >= 1) {

        document.getElementById("firstWin")
            .classList.remove("locked");

        document.getElementById("firstWin")
            .classList.add("unlocked");
    }


    // 100 SCORE
    if (score >= 100) {

        document.getElementById("score100")
            .classList.remove("locked");

        document.getElementById("score100")
            .classList.add("unlocked");
    }


    // 5 STREAK
    if (highestStreak >= 5) {

        document.getElementById("streak5")
            .classList.remove("locked");

        document.getElementById("streak5")
            .classList.add("unlocked");
    }


    // 20 QUESTIONS
    if (questionsAnswered >= 20) {

        document.getElementById("answer20")
            .classList.remove("locked");

        document.getElementById("answer20")
            .classList.add("unlocked");
    }
}


// GO HOME

function goHome() {

    clearTimeout(questionTimeout);

    document.getElementById("gameScreen")
        .classList.add("hidden");

    showScreen("home");

    document.querySelector(".submit-btn").disabled = false;
}


// ENTER KEY

document.getElementById("answer").addEventListener(
    "keydown",
    function(event) {

        if (event.key === "Enter") {
            checkAnswer();
        }

    }
);