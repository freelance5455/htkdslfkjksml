const $ = (id) => document.getElementById(id);
const chatFeed = $('chatFeed'), giftFeed = $('giftFeed');
let comments = 0, gifts = 0, soundOn = false, autoScroll = true, activeTab = 'chat', socket;
let audioContext;
const MAX_ITEMS = 180;
function setStatus(status, message) {
  $('status').textContent = message || status;
  $('dot').className = 'dot ' + (status === 'connected' ? 'ok' : ['offline','warning'].includes(status) ? 'bad' : '');
}
function timeNow(ts) { return new Date(ts || Date.now()).toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'}); }
function removeEmpty(feed) { const empty = feed.querySelector('.empty'); if (empty) empty.remove(); }
function addItem(feed, {user,nickname,message,time,kind='chat',avatar}) {
  removeEmpty(feed);
  const item = document.createElement('article'); item.className = 'item' + (kind === 'gift' ? ' gift-item' : '');
  const av = document.createElement('div'); av.className = 'avatar'; av.textContent = (nickname || user || '?').trim().charAt(0).toUpperCase();
  const body = document.createElement('div'); body.className = 'body';
  const name = document.createElement('div'); name.className = 'name'; name.textContent = nickname && nickname !== user ? `${nickname} · @${user}` : `@${user || 'usuário'}`;
  const msg = document.createElement('div'); msg.className = 'message'; msg.textContent = message;
  body.append(name,msg); const stamp = document.createElement('time'); stamp.className = 'time'; stamp.textContent = timeNow(time);
  item.append(av,body,stamp); feed.append(item);
  while (feed.children.length > MAX_ITEMS) feed.firstElementChild.remove();
  if (autoScroll && ((activeTab === 'chat' && feed === chatFeed) || (activeTab === 'gifts' && feed === giftFeed))) feed.scrollTop = feed.scrollHeight;
}
function playAlert() {
  if (!soundOn) return;
  try {
    audioContext ||= new (window.AudioContext || window.webkitAudioContext)();
    if (audioContext.state === 'suspended') audioContext.resume();
    const now = audioContext.currentTime;
    [880,1175].forEach((freq,i)=>{const osc=audioContext.createOscillator(),gain=audioContext.createGain();osc.frequency.value=freq;osc.type='sine';gain.gain.setValueAtTime(.0001,now+i*.13);gain.gain.exponentialRampToValueAtTime(.18,now+i*.13+.02);gain.gain.exponentialRampToValueAtTime(.0001,now+i*.13+.20);osc.connect(gain);gain.connect(audioContext.destination);osc.start(now+i*.13);osc.stop(now+i*.13+.22);});
  } catch {}
}
function showGift(data) {
  gifts += Number(data.count || 1); $('giftCount').textContent = gifts; $('giftBadge').textContent = gifts;
  const label = `${data.giftName || 'Presente'}${Number(data.count)>1 ? ` × ${data.count}` : ''}`;
  $('giftAlert').querySelector('.gift-copy').innerHTML = '';
  const b=document.createElement('b');b.textContent=`🎉 ${data.nickname || data.user} enviou um presente!`;
  const s=document.createElement('span');s.textContent=label;
  $('giftAlert').querySelector('.gift-copy').append(b,s);
  addItem(giftFeed,{user:data.user,nickname:data.nickname,message:`Enviou ${label}`,time:data.timestamp,kind:'gift'});
  playAlert();
}
function handle(packet) {
  const d = packet.data || {};
  if (packet.type === 'status') setStatus(d.status,d.message);
  if (packet.type === 'chat') { comments++; $('commentCount').textContent=comments; $('chatBadge').textContent=comments; addItem(chatFeed,{user:d.user,nickname:d.nickname,message:d.content,time:d.timestamp}); }
  if (packet.type === 'gift') showGift(d);
  if (packet.type === 'like') $('likes').textContent=Number(d.total||0).toLocaleString('pt-BR');
  if (packet.type === 'member') addItem(chatFeed,{user:d.user,nickname:d.nickname,message:'entrou na LIVE 👋',time:d.timestamp});
}
function connect() {
  const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
  socket = new WebSocket(`${proto}//${location.host}/ws`);
  socket.onmessage = e => { try { handle(JSON.parse(e.data)); } catch {} };
  socket.onclose = () => { setStatus('warning','Reconectando painel…'); setTimeout(connect,2500); };
  socket.onopen = () => { setStatus('connecting','Painel conectado; aguardando LIVE…'); };
  const heartbeat = setInterval(()=>{ if(socket && socket.readyState===WebSocket.OPEN) socket.send('ping'); },20000);
  socket.onerror = () => socket.close();
}
fetch('/config').then(r=>r.json()).then(c=>{if(c.username)$('profile').textContent='@'+c.username}).catch(()=>{});
document.querySelectorAll('.tab').forEach(btn=>btn.addEventListener('click',()=>{
  activeTab=btn.dataset.tab;fetch('/config').then(r=>r.json()).then(c=>{if(c.username)$('profile').textContent='@'+c.username}).catch(()=>{});
document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b===btn));
  chatFeed.classList.toggle('hidden',activeTab!=='chat');giftFeed.classList.toggle('hidden',activeTab!=='gifts');
  const feed=activeTab==='chat'?chatFeed:giftFeed;if(autoScroll)feed.scrollTop=feed.scrollHeight;
}));
$('soundBtn').textContent='🔇 Toque para ativar som';
$('soundBtn').addEventListener('click',()=>{soundOn=!soundOn;$('soundBtn').textContent=soundOn?'🔊 Som ligado':'🔇 Som desligado';$('soundBtn').classList.toggle('off',!soundOn);if(soundOn){try{audioContext ||= new (window.AudioContext||window.webkitAudioContext)();audioContext.resume();}catch{}}});
$('autoBtn').addEventListener('click',()=>{autoScroll=!autoScroll;$('autoBtn').textContent=autoScroll?'↓ Novos automáticos':'↕ Rolagem manual';$('autoBtn').classList.toggle('off',!autoScroll)});
connect();
if ('serviceWorker' in navigator) window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));
