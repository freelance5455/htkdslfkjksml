import express from 'express';
import http from 'node:http';
import { WebSocketServer, WebSocket } from 'ws';
import { ControlEvent, TikTokLiveConnection, WebcastEvent } from 'tiktok-live-connector';

const PORT = Number(process.env.PORT || 3000);
const USERNAME = (process.env.LIVE_USERNAME || 'sounsc_').replace(/^@/, '').trim();
const RETRY_MS = Number(process.env.RETRY_MS || 30000);
const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws' });
let liveConnection;
let retryTimer;
let connecting = false;
let shuttingDown = false;
let state = { status: 'starting', username: USERNAME, roomId: null, message: 'Iniciando serviço…' };

app.use(express.static('public', { extensions: ['html'] }));
app.get('/health', (_req, res) => res.json({ ok: true, state, clients: wss.clients.size }));
app.get('/config', (_req, res) => res.json({ username: USERNAME }));

function broadcast(payload) {
  const data = JSON.stringify(payload);
  for (const client of wss.clients) {
    if (client.readyState === WebSocket.OPEN) client.send(data);
  }
}
function setState(status, message, extra = {}) {
  state = { ...state, status, message, ...extra };
  broadcast({ type: 'status', data: state });
  console.log(`[${status}] ${message}`);
}
function scheduleReconnect() {
  if (shuttingDown || retryTimer) return;
  connecting = false;
  retryTimer = setTimeout(() => {
    retryTimer = null;
    connectTikTok();
  }, RETRY_MS);
  retryTimer.unref?.();
}
function userId(user) {
  return user?.uniqueId || user?.displayId || user?.nickname || 'usuário';
}
function avatarUrl(user) {
  const avatar = user?.avatarThumb || user?.avatarMedium || user?.avatar;
  if (typeof avatar === 'string') return avatar;
  return avatar?.urlList?.[0] || avatar?.url_list?.[0] || null;
}
function giftDetails(event) {
  const gift = event.gift || event.giftDetails || event.extendedGiftInfo || {};
  return {
    name: gift.name || gift.giftName || gift.describe || event.extendedGiftInfo?.name || `Presente ${event.giftId || ''}`.trim(),
    diamonds: Number(gift.diamondCount ?? gift.diamond_count ?? event.extendedGiftInfo?.diamond_count ?? 0),
    type: Number(gift.type ?? gift.giftType ?? event.giftType ?? event.extendedGiftInfo?.gift_type ?? 0)
  };
}

wss.on('connection', (socket) => {
  socket.send(JSON.stringify({ type: 'status', data: state }));
  socket.on('message', (raw) => {
    // Heartbeat from the browser keeps the panel connection alive on hosts that sleep when idle.
    if (raw.toString() === 'ping' && socket.readyState === WebSocket.OPEN) socket.send('pong');
  });
  socket.on('error', () => {});
});

async function connectTikTok() {
  if (connecting || shuttingDown) return;
  connecting = true;
  clearTimeout(retryTimer);
  retryTimer = null;
  const connection = new TikTokLiveConnection(USERNAME, { enableExtendedGiftInfo: true });
  liveConnection = connection;

  connection.on(ControlEvent.CONNECTED, (info = {}) => {
    connecting = false;
    setState('connected', `Conectado à LIVE de @${USERNAME}`, { roomId: String(info.roomId || connection.roomId || '') });
  });
  connection.on(ControlEvent.ERROR, ({ info, exception } = {}) => {
    console.error('TikTok connector:', info, exception?.message || exception || 'erro');
    setState('warning', 'O TikTok apresentou um erro. Tentando reconectar…');
    scheduleReconnect();
  });
  connection.on(ControlEvent.DISCONNECTED, ({ code, reason } = {}) => {
    setState('reconnecting', `Conexão interrompida${code ? ` (${code})` : ''}${reason ? `: ${reason}` : ''}. Reconectando…`);
    scheduleReconnect();
  });
  connection.on(WebcastEvent.CHAT, (event) => {
    broadcast({ type: 'chat', data: {
      id: String(event.msgId || event.common?.msgId || `${Date.now()}-${Math.random()}`),
      user: userId(event.user), nickname: event.user?.nickname || userId(event.user),
      avatar: avatarUrl(event.user), content: event.comment || event.content || '', timestamp: Date.now()
    }});
  });
  connection.on(WebcastEvent.GIFT, (event) => {
    const gift = giftDetails(event);
    if (gift.type === 1 && event.repeatEnd !== true && event.repeatEnd !== 1) return;
    broadcast({ type: 'gift', data: {
      id: String(event.msgId || event.common?.msgId || `${Date.now()}-${Math.random()}`),
      user: userId(event.user), nickname: event.user?.nickname || userId(event.user),
      giftName: gift.name, count: Number(event.repeatCount || event.comboCount || 1),
      diamonds: gift.diamonds, image: event.extendedGiftInfo?.image?.urlList?.[0] || null,
      timestamp: Date.now()
    }});
  });
  connection.on(WebcastEvent.LIKE, (event) => broadcast({ type: 'like', data: {
    count: Number(event.likeCount || event.count || 0),
    total: Number(event.totalLikeCount || event.total || 0)
  }}));
  connection.on(WebcastEvent.MEMBER, (event) => broadcast({ type: 'member', data: {
    user: userId(event.user), nickname: event.user?.nickname || userId(event.user), timestamp: Date.now()
  }}));

  try {
    setState('connecting', `Procurando a LIVE de @${USERNAME}…`);
    const result = await connection.connect();
    connecting = false;
    setState('connected', `Conectado à LIVE de @${USERNAME}`, { roomId: String(result?.roomId || connection.roomId || '') });
  } catch (error) {
    connecting = false;
    console.error('Não foi possível conectar:', error?.message || error);
    setState('offline', `Não foi possível conectar a @${USERNAME}. Nova tentativa em ${Math.round(RETRY_MS / 1000)} segundos.`, { error: error?.message || 'connection_failed' });
    try { await connection.disconnect(); } catch {}
    scheduleReconnect();
  }
}

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Atlas Live Chat em http://localhost:${PORT} — TikTok @${USERNAME}`);
  connectTikTok();
});

async function shutdown() {
  shuttingDown = true;
  clearTimeout(retryTimer);
  try { await liveConnection?.disconnect(); } catch {}
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 3000).unref();
}
process.once('SIGINT', shutdown);
process.once('SIGTERM', shutdown);
