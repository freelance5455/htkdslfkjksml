# Atlas Live Chat — pacote pronto para publicação

Painel web vertical para acompanhar a LIVE pública de `@sounsc_` no Moto E6 Play enquanto o iPhone 13 transmite.

## Inclui
- Interface vertical e instalável como PWA.
- Comentários, presentes, curtidas e entradas na LIVE.
- Alerta visual de presente e alerta sonoro (o usuário precisa tocar em **Ativar som** uma vez, por restrição de áudio automático dos navegadores).
- Reconexão do painel e do conector com o TikTok.
- Heartbeat do navegador para manter a conexão do painel ativa.
- Endpoint `/health` para diagnóstico.
- Sem senha, cookies ou sessão da conta TikTok.

## Requisitos
- Node.js 20 ou superior.
- Hospedagem de servidor Node.js com acesso de saída à internet e suporte a WebSocket.
- A conta `@sounsc_` precisa estar com uma LIVE pública ativa para o conector localizar a sala.

## Executar localmente
```bash
npm install
npm start
```
Abra `http://localhost:3000`. Para usar outro perfil, defina `LIVE_USERNAME`.

## Publicar no Render
1. Coloque o conteúdo desta pasta em um repositório GitHub.
2. No Render, escolha **New > Blueprint** e selecione o repositório.
3. O Render lê `render.yaml` e cria o serviço `atlas-live-chat`.
4. Quando terminar, copie a URL HTTPS do serviço.
5. Abra a URL no Moto E6 Play, toque em **Som desligado** para ativar o som e, no menu do navegador, escolha **Adicionar à tela inicial**.
6. Inicie a LIVE pública no iPhone 13. O painel deve mudar para “Conectado à LIVE de @sounsc_”.

## Observações importantes
- Este projeto usa `tiktok-live-connector`, uma biblioteca comunitária que interage com endpoints não oficiais/reversos do TikTok. O TikTok pode alterar o protocolo, limitar a conexão ou impedir o acesso; não há garantia de funcionamento permanente.
- A hospedagem gratuita pode suspender ou reiniciar serviços e não garante disponibilidade contínua. Para monitoramento estável durante lives longas, pode ser necessário um plano sempre ativo.
- A conexão com a LIVE só pode ser validada com a conta ao vivo e o serviço publicado. O pacote não inclui uma hospedagem já criada, pois isso exige autenticação e autorização na conta de hospedagem do usuário.
- Presentes em sequência são contabilizados no evento final da sequência para evitar somar atualizações cumulativas repetidas.
- O contador de curtidas depende dos eventos enviados pelo TikTok e pode não ser perfeitamente contínuo.

## Diagnóstico
- `https://SUA-URL/health` mostra o estado do servidor e o número de navegadores conectados.
- Se aparecer “offline”, confirme que `@sounsc_` está ao vivo publicamente e veja os logs do serviço no Render.
- Não coloque senha ou cookies do TikTok no projeto.
