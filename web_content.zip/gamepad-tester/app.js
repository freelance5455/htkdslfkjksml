const $=s=>document.querySelector(s);
const LB={xbox:['A','B','X','Y','LB','RB','LT','RT','Back','Start','L3','R3','↑','↓','←','→','Home'],
ps:['✕','○','□','△','L1','R1','L2','R2','Share','Options','L3','R3','↑','↓','←','→','PS'],
sw:['B','A','Y','X','L','R','ZL','ZR','−','+','L3','R3','↑','↓','←','→','Home']};
LB.gen=LB.xbox;
const KN={xbox:'Xbox',ps:'PlayStation',sw:'Nintendo',gen:'يد ألعاب'};
const DIRS=['U','R','D','L'],DL={U:'↑',R:'→',D:'↓',L:'←'};
const HD=[['U'],['U','R'],['R'],['R','D'],['D'],['D','L'],['L'],['L','U']];
let G=null,T=null,K='gen',STD=false,REQ=[],SK=[],TA=[],HAT=-1,idx=-1,want=-1,lastUI=0,sig='',RAW=[];
const lab=i=>STD?(LB[K][i]||'زر '+i):'زر '+i;
const clamp=(x,a,b)=>Math.min(b,Math.max(a,x));
const kind=g=>{const s=g.id.toLowerCase();return /xbox|045e/.test(s)?'xbox':/playstation|054c|dualshock|dualsense|wireless controller/.test(s)?'ps':/nintendo|057e|pro controller/.test(s)?'sw':'gen'};
const newT=()=>({tested:new Set(),hat:new Set(),skip:new Set(),max:{},axmax:{},sect:[new Set(),new Set()],rest:{on:false,done:false,end:0,d:[0,0],stuck:new Set(),trig:0},rumble:null});

function classify(g){
  const ax=g.axes;SK=[];TA=[];HAT=-1;
  if(STD){SK=ax.length>=4?[[0,1],[2,3]]:ax.length>=2?[[0,1]]:[];return}
  const st=[];
  ax.forEach((v,i)=>{if(v>1.05)HAT=i;else if(v<-.9)TA.push(i);else st.push(i)});
  for(let k=0;k+1<st.length&&SK.length<2;k+=2)SK.push([st[k],st[k+1]]);
}
function setup(g){
  K=kind(g);STD=g.mapping==='standard';T=newT();classify(g);sig='';
  REQ=[];for(let i=0;i<g.buttons.length;i++){if(STD&&i>=16)continue;REQ.push(i)}
  $('#name').textContent=KN[K];$('#nid').textContent=g.id.split(' (')[0];
  $('#pad').dataset.k=K;$('#pad').classList.toggle('gen',!STD);
  $('#mode').textContent=STD?'تخطيط قياسي: تظهر أسماء الأزرار الحقيقية.':'تخطيط غير قياسي: تظهر الأزرار بأرقامها. اضغط أي زر لترى رقمه.';
  for(let i=0;i<4;i++){const t=$('#t'+i);if(t)t.textContent=STD?lab(i):''}
  buildTicks();buildChips();
  $('#rawbox').hidden=STD||!g.axes.length;
  RAW=[];if(!STD)$('#raw').innerHTML=g.axes.map((v,i)=>`<div class="rw"><span>محور ${i}</span><div class="bar"><i id="r${i}"></i></div></div>`).join('');
  $('#wait').hidden=true;$('#main').hidden=false;
}
function buildTicks(){const svg=$('#pad');svg.querySelectorAll('.tk').forEach(e=>e.remove());
  for(let s=0;s<SK.length;s++){const cx=s?220:140;for(let k=0;k<16;k++){const a=-Math.PI+(k+.5)*Math.PI/8,c=Math.cos(a),n=Math.sin(a),l=document.createElementNS('http://www.w3.org/2000/svg','line');
    l.setAttribute('x1',cx+25*c);l.setAttribute('y1',112+25*n);l.setAttribute('x2',cx+31*c);l.setAttribute('y2',112+31*n);l.setAttribute('class','tk');l.id='tk'+s+'_'+k;svg.appendChild(l)}}}
function buildChips(){
  let h=REQ.map(i=>`<span class="chip" id="c${i}" data-i="${i}">${lab(i)}</span>`).join('');
  if(HAT>=0)h+=DIRS.map(d=>`<span class="chip" id="h${d}">اتجاه ${DL[d]}</span>`).join('');
  $('#chips').innerHTML=h;
}
$('#chips').onclick=e=>{if(!T)return;const s=e.target.dataset.i;if(s===undefined)return;const i=+s;if(T.tested.has(i))return;T.skip.has(i)?T.skip.delete(i):T.skip.add(i)};

function frame(g){
  const b=g.buttons,ax=g.axes,rest=T.rest;
  if(rest.on&&Date.now()>rest.end){rest.on=false;rest.done=true;$('#rest').disabled=false;$('#rest').textContent='أعد قياس الراحة'}
  for(let i=0;i<b.length;i++){
    const v=b[i].value,p=b[i].pressed||v>.5,isT=STD&&(i===6||i===7);
    if(STD){const el=$('#b'+i);if(el){if(isT)el.style.fillOpacity=.15+.85*v;else el.classList.toggle('on',p)}
      if(i<4){const tx=$('#t'+i);if(tx)tx.classList.toggle('on',p)}}
    if(p&&!rest.on)$('#last').textContent='آخر زر مضغوط: '+lab(i);
    if(rest.on){if(p)rest.stuck.add(i);if(isT)rest.trig=Math.max(rest.trig,v)}else if(p)T.tested.add(i);
    T.max[i]=Math.max(T.max[i]||0,v);
    const c=$('#c'+i);
    if(c){c.classList.toggle('live',p);c.classList.toggle('ok',T.tested.has(i)&&!p);c.classList.toggle('bad',rest.done&&rest.stuck.has(i));c.classList.toggle('skip',T.skip.has(i))}
  }
  for(const a of TA){const n=clamp(((ax[a]||0)+1)/2,0,1);if(rest.on)rest.trig=Math.max(rest.trig,n);else T.axmax[a]=Math.max(T.axmax[a]||0,n)}
  if(HAT>=0){const v=ax[HAT],cur=v>1.05?[]:HD[clamp(Math.round((v+1)*3.5),0,7)];
    DIRS.forEach(d=>{const c=$('#h'+d);if(!c)return;const on=cur.includes(d);if(on&&!rest.on)T.hat.add(d);c.classList.toggle('live',on);c.classList.toggle('ok',T.hat.has(d)&&!on)})}
  for(let s=0;s<SK.length;s++){
    const x=ax[SK[s][0]]||0,y=ax[SK[s][1]]||0,m=Math.hypot(x,y);
    const d=$(s?'#rs':'#ls');d.setAttribute('cx',(s?220:140)+14*x);d.setAttribute('cy',112+14*y);
    if(rest.on)rest.d[s]=Math.max(rest.d[s],m);
    else if(m>.75)T.sect[s].add(Math.floor(((Math.atan2(y,x)+Math.PI)/(2*Math.PI))*16)%16);
  }
  if(!STD)for(let i=0;i<ax.length;i++){const r=$('#r'+i);if(r)r.style.width=clamp((ax[i]+1)/2*100,0,100)+'%'}
  if(Date.now()-lastUI>250){lastUI=Date.now();ui()}
}

function evaluate(){
  const M=[],iss=[];
  const act=REQ.filter(i=>!T.skip.has(i)),hn=HAT>=0?4:0;
  const tested=act.filter(i=>T.tested.has(i)&&!T.rest.stuck.has(i)).length+T.hat.size,total=act.length+hn;
  M.push([40,total?tested/total:0]);
  const un=act.filter(i=>!T.tested.has(i)).map(lab).concat(HAT>=0?DIRS.filter(d=>!T.hat.has(d)).map(d=>'اتجاه '+DL[d]):[]);
  if(un.length)iss.push(['w','⏳ اضغط هذه الأزرار: '+un.join('، ')+(STD?'':' (إن لم يكن الزر موجودًا في يدك فالمس اسمه لاستثنائه)')]);
  const stuck=[...T.rest.stuck];
  if(stuck.length)iss.push(['f','⚠️ أزرار عالقة (مضغوطة وحدها): '+stuck.map(lab).join('، ')]);
  const nm=['الأيسر','الأيمن'];
  for(let s=0;s<SK.length;s++){
    const cov=clamp(T.sect[s].size/14,0,1);M.push([10,cov]);
    if(cov<1)iss.push(['w','⏳ أدر الذراع '+nm[s]+' دورة كاملة على الحافة ('+Math.round(cov*100)+'%)']);
    if(T.rest.done){const d=T.rest.d[s];M.push([10,clamp(1-(d-.05)/.2,0,1)]);
      if(d>.12)iss.push(['f','⚠️ الذراع '+nm[s]+' ينحرف '+Math.round(d*100)+'% وهو في الراحة (drift)'])}
  }
  if(!T.rest.done)iss.push(['w','⏳ اضغط «قياس حالة الراحة» واترك اليد 3 ثوانٍ']);
  const tv=STD&&G.buttons.length>7?[6,7].map(i=>T.max[i]||0):TA.map(a=>T.axmax[a]||0);
  if(tv.length){
    let r=tv.reduce((s,v)=>s+Math.min(1,v/.9),0)/tv.length;
    if(T.rest.done&&T.rest.trig>.08){r*=.5;iss.push(['f','⚠️ أحد الزرين الخلفيين يعطي قراءة وهو غير مضغوط'])}
    M.push([10,r]);
    if(Math.min(...tv)<.9)iss.push(['w','⏳ اضغط الزرين الخلفيين (التريغر) حتى النهاية']);
  }
  if(G&&G.vibrationActuator){
    if(T.rumble===null)iss.push(['w','⏳ جرّب اختبار الاهتزاز']);
    else{M.push([10,T.rumble?1:0]);if(!T.rumble)iss.push(['f','⚠️ الاهتزاز لا يعمل'])}
  }
  const W=M.reduce((a,m)=>a+m[0],0),P=Math.round(100*M.reduce((a,m)=>a+m[0]*m[1],0)/W);
  const fault=iss.some(i=>i[0]==='f');
  return {P:fault?Math.min(P,89):P,iss,pending:iss.some(i=>i[0]==='w'),fault,tested,total};
}

function ui(){
  const r=evaluate(),c=r.P>=85?'#4ee0a0':r.P>=60?'#ffc15c':'#ff6b81';
  const gz=$('#gauge');gz.style.setProperty('--p',r.P);gz.style.setProperty('--c',c);
  $('#pct').textContent=r.P+'%';
  $('#verdict').style.color=r.pending?'#5cc8ff':c;
  $('#verdict').textContent=r.pending?'جارٍ الفحص… أكمل الخطوات الظاهرة':r.P>=90?'اليد سليمة ✅':r.P>=75?'اليد جيدة مع ملاحظات':r.P>=55?'اليد تحتاج انتباهًا':'اليد بها أعطال ⚠️';
  $('#issues').innerHTML=r.iss.length?r.iss.map(i=>`<li class="${i[0]}">${i[1]}</li>`).join(''):'<li class="g">✅ اكتمل الفحص ولم تظهر أي مشكلة</li>';
  $('#bprog').textContent='اختبرت '+r.tested+' من '+r.total+' زرًا';$('#bbar').style.width=Math.round(100*r.tested/Math.max(1,r.total))+'%';
  for(let s=0;s<SK.length;s++)for(let k=0;k<16;k++){const t=$('#tk'+s+'_'+k);if(t)t.classList.toggle('hit',T.sect[s].has(k))}
  const nm=['الأيسر','الأيمن'];let h='';
  for(let s=0;s<SK.length;s++){const cv=Math.round(clamp(T.sect[s].size/14,0,1)*100);
    h+=`الذراع ${nm[s]}: تغطية الدوران ${cv}%`+(T.rest.done?` · انحراف الراحة ${Math.round(T.rest.d[s]*100)}%`:'')+`<div class="bar"><i style="width:${cv}%"></i></div>`}
  if(!SK.length)h='لم يُعثر على أذرع في هذه اليد.';
  $('#sinfo').innerHTML=h;
}

$('#rest').onclick=()=>{if(!T)return;const r=T.rest;r.on=true;r.d=[0,0];r.stuck=new Set();r.trig=0;r.end=Date.now()+3000;$('#rest').disabled=true;$('#rest').textContent='لا تلمس اليد… جارٍ القياس'};
$('#vib').onclick=async()=>{
  const a=G&&G.vibrationActuator;
  if(!a){T.rumble=null;alert('هذه اليد أو هذا المتصفح لا يدعم اختبار الاهتزاز.');return}
  try{await a.playEffect('dual-rumble',{duration:700,strongMagnitude:1,weakMagnitude:1});$('#vask').hidden=false}
  catch(e){alert('تعذّر تشغيل الاهتزاز.')}
};
$('#vy').onclick=()=>{T.rumble=true;$('#vask').hidden=true};
$('#vn').onclick=()=>{T.rumble=false;$('#vask').hidden=true};
$('#reset').onclick=()=>{if(!G)return;T=newT();buildChips();$('#vask').hidden=true;$('#rest').disabled=false;$('#rest').textContent='قياس حالة الراحة (اترك الأذرع 3 ثوانٍ)'};
$('#pick').onclick=e=>{const x=e.target.dataset.x;if(x!==undefined){want=+x;sig=''}};

function pickUI(a){
  const s=a.map(x=>x.index+x.id).join('|')+idx;if(s===sig)return;sig=s;
  const el=$('#pick');el.hidden=a.length<2;
  el.innerHTML=a.length<2?'':'<div class="note">أكثر من يد متصلة، اختر اليد المراد فحصها:</div>'+a.map(x=>`<button data-x="${x.index}" class="${x.index===idx?'pri':''}">يد ${x.index+1}</button>`).join('');
}
function loop(){
  const a=(navigator.getGamepads?[...navigator.getGamepads()]:[]).filter(x=>x&&x.connected);
  const g=a.find(x=>x.index===want)||a.find(x=>x.index===idx)||a[a.length-1];
  if(g){if(g.index!==idx){idx=g.index;setup(g)}G=g;pickUI(a);frame(g)}
  else if(idx!==-1){idx=-1;want=-1;G=null;sig='';$('#wait').hidden=false;$('#main').hidden=true}
  requestAnimationFrame(loop);
}
if('serviceWorker' in navigator&&location.protocol.startsWith('http')){navigator.serviceWorker.register('sw.js').catch(()=>{})}
loop();
