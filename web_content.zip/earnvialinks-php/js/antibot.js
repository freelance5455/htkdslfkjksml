/* EarnViaLinks - client side security helper.
   1) attaches the login token to /api calls and stores it after login
   2) on link gateway pages (/s/slug): requests a signed visit token, collects human-interaction signals
      and (optional) Cloudflare Turnstile, and sends them with the view/click request. */
(function () {
  if (window.__evlAntibot) return; window.__evlAntibot = 1;
  var UKEY = 'evl_user_token';
  var origFetch = window.fetch.bind(window);
  var visits = {}, human = 0, turnstileToken = '', tsWidget = null, tsCfg = null, tsLoading = false;

  // ---- human signals: only real (trusted) user input counts
  ['pointerdown', 'touchstart', 'keydown', 'click', 'scroll', 'wheel'].forEach(function (ev) {
    window.addEventListener(ev, function (e) { if (e.isTrusted) human++; }, { passive: true, capture: true });
  });
  function autoFlags() {
    var f = 0;
    try { if (navigator.webdriver) f |= 1; } catch (e) {}
    try { if (window._phantom || window.callPhantom || window.__nightmare) f |= 2; } catch (e) {}
    try { if (!navigator.languages || !navigator.languages.length) f |= 4; } catch (e) {}
    try { if (/HeadlessChrome/.test(navigator.userAgent)) f |= 8; } catch (e) {}
    return f;
  }

  // ---- visit token when a gateway page opens
  function slugFromPath() {
    var m = location.pathname.match(/^\/(?:s|short)\/([^\/?#]+)/);
    return m ? decodeURIComponent(m[1]).toLowerCase() : '';
  }
  function startVisit(slug) {
    visits[slug] = { token: '', t: Date.now(), pending: true };
    origFetch('/api/short/visit/' + encodeURIComponent(slug), { method: 'POST' })
      .then(function (r) { return r.json(); })
      .then(function (d) { if (d && d.token) visits[slug] = { token: d.token, t: Date.now() }; })
      .catch(function () { delete visits[slug]; });
    initTurnstile();
  }
  var lastSlug = '';
  setInterval(function () {
    var s = slugFromPath();
    if (!s) { lastSlug = ''; hideTurnstile(); return; }
    if (s !== lastSlug || !visits[s] || (Date.now() - visits[s].t > 25 * 60 * 1000)) { lastSlug = s; startVisit(s); }
  }, 500);

  // ---- Cloudflare Turnstile (only when TURNSTILE_SITE_KEY + TURNSTILE_SECRET are set on the server)
  var box = null;
  function hideTurnstile() { if (box) box.style.display = 'none'; }
  function initTurnstile() {
    var show = function () { if (box) box.style.display = 'block'; };
    if (tsCfg && tsCfg.turnstileEnabled) { show(); return; }
    if (tsCfg || tsLoading) return;
    tsLoading = true;
    origFetch('/api/antibot/config').then(function (r) { return r.json(); }).then(function (c) {
      tsCfg = c || {}; tsLoading = false;
      if (!tsCfg.turnstileEnabled || !tsCfg.turnstileSiteKey) return;
      box = document.createElement('div');
      box.style.cssText = 'position:fixed;left:50%;bottom:14px;transform:translateX(-50%);z-index:2147482000;background:#fff;border:1px solid #e2e8f0;border-radius:14px;padding:8px 10px;box-shadow:0 8px 30px rgba(0,0,0,.18);font:600 11px sans-serif;color:#475569;text-align:center';
      box.innerHTML = '<div style="margin-bottom:4px">Security check</div><div id="evl-ts"></div>';
      document.body.appendChild(box);
      var s = document.createElement('script');
      s.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit'; s.async = true;
      s.onload = function () {
        try {
          tsWidget = window.turnstile.render('#evl-ts', {
            sitekey: tsCfg.turnstileSiteKey,
            callback: function (t) { turnstileToken = t; },
            'expired-callback': function () { turnstileToken = ''; try { window.turnstile.reset(tsWidget); } catch (e) {} },
            'error-callback': function () { turnstileToken = ''; }
          });
        } catch (e) {}
      };
      document.head.appendChild(s);
    }).catch(function () { tsLoading = false; tsCfg = {}; });
  }

  // ---- fetch wrapper
  var expiredHandled = false;
  window.fetch = function (input, init) {
    var path = '';
    try {
      var url = typeof input === 'string' ? input : (input && input.url) || '';
      path = url.replace(location.origin, '');
      if (path.indexOf('/api/') === 0) {
        init = init || {};
        var h = new Headers(init.headers || (typeof input !== 'string' && input.headers) || {});
        var ut = localStorage.getItem(UKEY);
        if (ut && !h.has('X-User-Token')) h.set('X-User-Token', ut);
        var m = path.match(/^\/api\/(?:short|s)\/click\/([^\/?#]+)/);
        if (m) {
          var slug = decodeURIComponent(m[1]).toLowerCase(), v = visits[slug];
          if (v && v.token) h.set('X-Visit-Token', v.token);
          h.set('X-Human', human + ',' + autoFlags());
          if (turnstileToken) h.set('X-Turnstile', turnstileToken);
        }
        init.headers = h;
      }
    } catch (e) {}
    var p = origFetch(input, init);
    try {
      if (/^\/api\/auth\/(login|verify-email|register)/.test(path)) {
        p.then(function (r) { return r.clone().json(); }).then(function (d) {
          if (d && d.userToken) localStorage.setItem(UKEY, d.userToken);
        }).catch(function () {});
      } else if (/^\/api\/(withdrawals|user|streak|loyalty|referrals)/.test(path)) {
        p.then(function (r) {
          if (r.status !== 401) return;
          r.clone().json().then(function (d) {
            if (d && d.code === 'USER_AUTH_REQUIRED' && !expiredHandled) {
              expiredHandled = true;
              localStorage.removeItem(UKEY); localStorage.removeItem('evl_current_user_v3');
              alert('Your login session expired. Please log in again.');
              location.href = '/?action=login';
            }
          }).catch(function () {});
        }).catch(function () {});
      }
      if (/^\/api\/short\/click\//.test(path) && tsWidget !== null) {
        p.then(function () { turnstileToken = ''; try { window.turnstile.reset(tsWidget); } catch (e) {} }).catch(function () {});
      }
    } catch (e) {}
    return p;
  };

  // logout: forget the token
  window.addEventListener('storage', function () {});
})();
