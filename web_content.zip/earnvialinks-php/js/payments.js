/* earnvialinks - country list (A-Z) and payout methods per country. Edit freely. */
(function () {
  var C = "AF Afghanistan|AL Albania|DZ Algeria|AD Andorra|AO Angola|AG Antigua and Barbuda|AR Argentina|AM Armenia|AU Australia|AT Austria|AZ Azerbaijan|BS Bahamas|BH Bahrain|BD Bangladesh|BB Barbados|BY Belarus|BE Belgium|BZ Belize|BJ Benin|BT Bhutan|BO Bolivia|BA Bosnia and Herzegovina|BW Botswana|BR Brazil|BN Brunei|BG Bulgaria|BF Burkina Faso|BI Burundi|CV Cabo Verde|KH Cambodia|CM Cameroon|CA Canada|CF Central African Republic|TD Chad|CL Chile|CN China|CO Colombia|KM Comoros|CG Congo|CD Congo (DR)|CR Costa Rica|CI Cote d'Ivoire|HR Croatia|CU Cuba|CY Cyprus|CZ Czech Republic|DK Denmark|DJ Djibouti|DM Dominica|DO Dominican Republic|EC Ecuador|EG Egypt|SV El Salvador|GQ Equatorial Guinea|ER Eritrea|EE Estonia|SZ Eswatini|ET Ethiopia|FJ Fiji|FI Finland|FR France|GA Gabon|GM Gambia|GE Georgia|DE Germany|GH Ghana|GR Greece|GD Grenada|GT Guatemala|GN Guinea|GW Guinea-Bissau|GY Guyana|HT Haiti|HN Honduras|HK Hong Kong|HU Hungary|IS Iceland|IN India|ID Indonesia|IR Iran|IQ Iraq|IE Ireland|IL Israel|IT Italy|JM Jamaica|JP Japan|JO Jordan|KZ Kazakhstan|KE Kenya|KI Kiribati|XK Kosovo|KW Kuwait|KG Kyrgyzstan|LA Laos|LV Latvia|LB Lebanon|LS Lesotho|LR Liberia|LY Libya|LI Liechtenstein|LT Lithuania|LU Luxembourg|MO Macao|MG Madagascar|MW Malawi|MY Malaysia|MV Maldives|ML Mali|MT Malta|MH Marshall Islands|MR Mauritania|MU Mauritius|MX Mexico|FM Micronesia|MD Moldova|MC Monaco|MN Mongolia|ME Montenegro|MA Morocco|MZ Mozambique|MM Myanmar|NA Namibia|NR Nauru|NP Nepal|NL Netherlands|NZ New Zealand|NI Nicaragua|NE Niger|NG Nigeria|KP North Korea|MK North Macedonia|NO Norway|OM Oman|PK Pakistan|PW Palau|PS Palestine|PA Panama|PG Papua New Guinea|PY Paraguay|PE Peru|PH Philippines|PL Poland|PT Portugal|PR Puerto Rico|QA Qatar|RO Romania|RU Russia|RW Rwanda|KN Saint Kitts and Nevis|LC Saint Lucia|VC Saint Vincent and the Grenadines|WS Samoa|SM San Marino|ST Sao Tome and Principe|SA Saudi Arabia|SN Senegal|RS Serbia|SC Seychelles|SL Sierra Leone|SG Singapore|SK Slovakia|SI Slovenia|SB Solomon Islands|SO Somalia|ZA South Africa|KR South Korea|SS South Sudan|ES Spain|LK Sri Lanka|SD Sudan|SR Suriname|SE Sweden|CH Switzerland|SY Syria|TW Taiwan|TJ Tajikistan|TZ Tanzania|TH Thailand|TL Timor-Leste|TG Togo|TO Tonga|TT Trinidad and Tobago|TN Tunisia|TR Turkey|TM Turkmenistan|TV Tuvalu|UG Uganda|UA Ukraine|AE United Arab Emirates|GB United Kingdom|US United States|UY Uruguay|UZ Uzbekistan|VU Vanuatu|VA Vatican City|VE Venezuela|VN Vietnam|YE Yemen|ZM Zambia|ZW Zimbabwe";

  function flag(cc) {
    if (cc === "XK") return "\uD83C\uDDFD\uD83C\uDDF0";
    return String.fromCodePoint.apply(null, cc.split("").map(function (ch) { return 127397 + ch.charCodeAt(0); }));
  }

  var countries = C.split("|").map(function (s) {
    var cc = s.slice(0, 2), name = s.slice(3);
    return { cc: cc, name: name, flag: flag(cc), label: flag(cc) + " " + name };
  }).sort(function (a, b) { return a.name.localeCompare(b.name); });

  var BANK = "Bank Transfer (IBAN / SWIFT)";
  var GLOBAL = ["PayPal", "Skrill", "Neteller", "Payeer", "Payoneer", "Wise", "Perfect Money", "AdvCash", "Binance Pay", "Crypto (USDT TRC20)", "Crypto (USDT BEP20)", "Bitcoin (BTC)"];

  var HINT = {
    "PayPal": "PayPal e-mail address",
    "Skrill": "Skrill account e-mail",
    "Neteller": "Neteller account e-mail",
    "Payeer": "Payeer wallet number (e.g. P1234567)",
    "Payoneer": "Payoneer account e-mail",
    "Wise": "Wise account e-mail",
    "Perfect Money": "Perfect Money account (e.g. U1234567)",
    "AdvCash": "AdvCash e-mail or wallet (U1234 5678 9012)",
    "Binance Pay": "Binance Pay ID (numeric)",
    "Crypto (USDT TRC20)": "USDT wallet address (TRC20 network only)",
    "Crypto (USDT BEP20)": "USDT wallet address (BEP20 network only)",
    "Bitcoin (BTC)": "Bitcoin wallet address",
    "UPI": "UPI ID (e.g. name@okaxis)",
    "Pix": "Pix key (CPF, e-mail, phone or random key)",
    "PayNow": "Registered mobile number or UEN",
    "PromptPay": "Registered mobile number or national ID",
    "Zelle": "Registered e-mail or phone number",
    "Cash App": "$Cashtag",
    "Venmo": "@username",
    "Interac e-Transfer": "Interac e-mail address",
    "Revolut": "Revolut @username or phone",
    "SEPA Instant / Revolut": "Revolut @username or phone",
    "Bizum": "Registered mobile number",
    "Swish": "Registered mobile number",
    "MobilePay": "Registered mobile number",
    "Vipps": "Registered mobile number",
    "TWINT": "Registered mobile number",
    "BLIK": "Registered mobile number",
    "iDEAL": "IBAN linked to iDEAL",
    "MB WAY": "Registered mobile number",
    "PayID": "PayID (phone / e-mail)",
    "Alipay": "Alipay account (phone / e-mail)",
    "WeChat Pay": "WeChat ID",
    "Kaspi.kz": "Kaspi phone number"
  };

  // Local wallets / popular payout options per country (in addition to the international list + bank transfer)
  var M = {
    PK: ["Easypaisa", "JazzCash", "SadaPay", "NayaPay", "Raast"],
    IN: ["UPI", "PhonePe", "Google Pay", "Paytm Wallet"],
    BD: ["bKash", "Nagad", "Rocket", "Upay"],
    LK: ["FriMi", "Genie", "eZ Cash"],
    NP: ["eSewa", "Khalti", "IME Pay"],
    AF: ["M-Paisa", "Hesab Pay"],
    BT: ["mBoB", "DK Bank"],
    MV: ["BML MobilePay"],
    ID: ["GoPay", "OVO", "DANA", "ShopeePay", "LinkAja"],
    PH: ["GCash", "Maya", "Coins.ph"],
    VN: ["MoMo", "ZaloPay", "ViettelPay"],
    TH: ["PromptPay", "TrueMoney Wallet", "Rabbit LINE Pay"],
    MY: ["Touch 'n Go eWallet", "GrabPay", "Boost", "DuitNow"],
    SG: ["PayNow", "GrabPay"],
    MM: ["Wave Money", "KBZPay"],
    KH: ["Wing", "ABA Pay"],
    LA: ["BCEL OnePay", "U-Money"],
    CN: ["Alipay", "WeChat Pay"],
    HK: ["PayMe", "Alipay HK", "FPS"],
    MO: ["MPay"],
    TW: ["LINE Pay", "JKOPay"],
    JP: ["PayPay", "Rakuten Pay", "LINE Pay"],
    KR: ["KakaoPay", "Toss", "Naver Pay"],
    MN: ["Golomt Pay", "SocialPay"],
    KZ: ["Kaspi.kz"],
    UZ: ["Payme", "Click"],
    KG: ["Elsom", "O!Dengi"],
    TJ: ["Korti Milli"],
    AZ: ["m10", "Kapital Pay"],
    AM: ["Idram", "Telcell"],
    GE: ["TBC Pay", "BOG Pay"],
    RU: ["YooMoney", "QIWI", "SBP (Fast Payments)"],
    BY: ["ERIP"],
    UA: ["Monobank", "PrivatBank (Privat24)"],
    MD: ["MIA Pay"],
    TR: ["Papara", "Ininal"],
    IL: ["Bit", "PayBox"],
    SA: ["STC Pay", "Mada"],
    AE: ["Careem Pay", "Payit", "e& money"],
    QA: ["Fawran", "Ooredoo Money"],
    KW: ["KNET"],
    BH: ["BenefitPay"],
    OM: ["Thawani Pay"],
    JO: ["CliQ", "Zain Cash"],
    LB: ["OMT", "Whish Money"],
    IQ: ["ZainCash", "FIB (First Iraqi Bank)"],
    YE: ["Kuraimi (Jawali)", "OneCash"],
    SY: ["MTN Cash", "Syriatel Cash"],
    PS: ["Jawwal Pay", "PalPay"],
    EG: ["Vodafone Cash", "InstaPay", "Fawry"],
    LY: ["Sadad", "Tadawul Pay"],
    TN: ["Flouci", "D17 (La Poste)"],
    DZ: ["Baridimob", "CCP"],
    MA: ["Orange Money", "CashPlus", "Inwi Money"],
    SD: ["Bankak (BOK)", "Fawry Sudan"],
    NG: ["OPay", "PalmPay", "Moniepoint", "Kuda", "Paga"],
    GH: ["MTN Mobile Money", "Vodafone Cash", "AirtelTigo Money"],
    KE: ["M-Pesa", "Airtel Money"],
    TZ: ["M-Pesa", "Tigo Pesa", "Airtel Money", "Halopesa"],
    UG: ["MTN Mobile Money", "Airtel Money"],
    RW: ["MTN Mobile Money", "Airtel Money"],
    BI: ["Lumitel Lumicash", "EcoCash Burundi"],
    ET: ["Telebirr", "CBE Birr"],
    SO: ["EVC Plus", "Sahal (Golis)"],
    DJ: ["D-Money"],
    ER: [],
    SS: ["MTN Mobile Money"],
    ZA: ["Capitec Pay", "FNB eWallet", "SnapScan"],
    ZM: ["MTN Mobile Money", "Airtel Money"],
    ZW: ["EcoCash", "OneMoney"],
    MZ: ["M-Pesa", "e-Mola", "mKesh"],
    MW: ["Airtel Money", "TNM Mpamba"],
    BW: ["Orange Money", "MyZaka"],
    NA: ["EasyWallet", "PayToday"],
    MG: ["MVola", "Orange Money", "Airtel Money"],
    MU: ["Juice (MCB)", "my.t money"],
    CM: ["Orange Money", "MTN Mobile Money"],
    CI: ["Orange Money", "Wave", "MTN Mobile Money", "Moov Money"],
    SN: ["Wave", "Orange Money", "Free Money"],
    ML: ["Orange Money", "Moov Money"],
    BF: ["Orange Money", "Moov Money"],
    BJ: ["MTN Mobile Money", "Moov Money"],
    TG: ["T-Money", "Moov Money"],
    NE: ["Orange Money", "Airtel Money"],
    GA: ["Airtel Money", "Moov Money"],
    CG: ["MTN Mobile Money", "Airtel Money"],
    CD: ["M-Pesa", "Orange Money", "Airtel Money"],
    GN: ["Orange Money", "MTN Mobile Money"],
    SL: ["Orange Money", "Afrimoney"],
    LR: ["Orange Money", "Lonestar MTN Money"],
    GM: ["Wave", "Afrimoney"],
    MR: ["Bankily", "Masrvi"],
    AO: ["Unitel Money", "Multicaixa Express"],
    LS: ["M-Pesa Lesotho", "EcoCash Lesotho"],
    SZ: ["MTN MoMo Eswatini", "eMali"],
    BR: ["Pix", "Mercado Pago", "PicPay"],
    MX: ["SPEI (CLABE)", "Mercado Pago"],
    AR: ["Mercado Pago", "Uala"],
    CL: ["Mach", "Tenpo", "Mercado Pago"],
    CO: ["Nequi", "Daviplata"],
    PE: ["Yape", "Plin"],
    EC: ["Deuna", "Payphone"],
    BO: ["Tigo Money", "QR Simple"],
    PY: ["Tigo Money", "Personal Pay"],
    UY: ["Prex", "Mercado Pago"],
    VE: ["Pago Movil", "Zinli"],
    CR: ["SINPE Movil"],
    GT: ["Tigo Money"],
    SV: ["Tigo Money", "Chivo Wallet"],
    HN: ["Tigo Money", "Tengo"],
    NI: ["Tigo Money"],
    PA: ["Yappy", "Nequi Panama"],
    DO: ["Tpago", "Banreservas Wallet"],
    JM: ["Lynk"],
    HT: ["MonCash", "NatCash"],
    TT: ["Linx", "WiPay"],
    CU: ["Transfermovil"],
    PR: ["ATH Movil", "Zelle"],
    US: ["Cash App", "Venmo", "Zelle"],
    CA: ["Interac e-Transfer"],
    GB: ["Revolut", "Monzo"],
    IE: ["Revolut"],
    NL: ["iDEAL", "Revolut"],
    DE: ["Revolut", "N26"],
    FR: ["Revolut", "Lydia"],
    BE: ["Bancontact", "Payconiq"],
    LU: ["Payconiq"],
    ES: ["Bizum", "Revolut"],
    PT: ["MB WAY", "Revolut"],
    IT: ["Satispay", "PostePay"],
    CH: ["TWINT"],
    AT: ["EPS", "Revolut"],
    SE: ["Swish"],
    DK: ["MobilePay"],
    FI: ["MobilePay", "OP Pay"],
    NO: ["Vipps"],
    IS: ["Aur", "Kass"],
    PL: ["BLIK", "Revolut"],
    CZ: ["Revolut", "Twisto"],
    SK: ["Revolut", "Tatra Pay"],
    HU: ["Revolut", "SimplePay"],
    RO: ["Revolut", "Revolut RO"],
    BG: ["Revolut", "Paysera"],
    GR: ["Revolut", "Viva Wallet"],
    HR: ["Revolut", "KEKS Pay"],
    RS: ["IPS Pay", "Paysera"],
    LT: ["Paysera", "Revolut"],
    LV: ["Paysera", "Revolut"],
    EE: ["Paysera", "Revolut"],
    AU: ["PayID", "Osko"],
    NZ: ["POLi Payments", "Wise Account"],
    FJ: ["M-PAiSA", "MyCash"],
    PG: ["BSP Pay", "Digicel Wallet"],
    WS: ["Digicel Wallet"],
    VU: ["Digicel Wallet"]
  };

  function stripFlag(s) { return String(s || "").replace(/^[^A-Za-z]+/, "").trim(); }
  var ALIAS = { "uae": "United Arab Emirates", "usa": "United States", "uk": "United Kingdom", "u.s.": "United States", "other country": "", "other": "" };
  function findCountry(str) {
    var n = stripFlag(str).toLowerCase();
    if (Object.prototype.hasOwnProperty.call(ALIAS, n)) n = ALIAS[n].toLowerCase();
    if (!n) return null;
    for (var i = 0; i < countries.length; i++) if (countries[i].name.toLowerCase() === n) return countries[i];
    return null;
  }

  // Gateways configured in the admin panel (settings.paymentGateways) come FIRST, in the admin's order,
  // so every user sees every method in the same sequence as the homescreen. Country wallets follow.
  var COVERS = [
    [/usdt|crypto|tether/i, "Crypto (USDT TRC20)", "USDT wallet address (TRC20 network only)"],
    [/paypal/i, "PayPal", "PayPal e-mail address"],
    [/^upi/i, "UPI", "UPI ID (e.g. name@okaxis)"],
    [/easypaisa/i, "Easypaisa", "Easypaisa mobile number (03XXXXXXXXX)"],
    [/jazzcash/i, "JazzCash", "JazzCash mobile number (03XXXXXXXXX)"],
    [/bkash/i, "bKash", "bKash mobile number (01XXXXXXXXX)"],
    [/nagad/i, "Nagad", "Nagad mobile number (01XXXXXXXXX)"],
    [/payeer/i, "Payeer", "Payeer wallet number (e.g. P1234567)"],
    [/airtm/i, "", "Airtm account e-mail"],
    [/nigeria.*bank|bank.*nigeria/i, "", "Account name, bank name & 10-digit account number"],
    [/pakistan.*bank|bank.*pakistan|bank/i, "", "Account holder, bank name & IBAN / account number"]
  ];
  function gwInfo(name) {
    for (var i = 0; i < COVERS.length; i++) if (COVERS[i][0].test(name)) return { covers: COVERS[i][1], hint: COVERS[i][2] };
    return { covers: "", hint: "Registered mobile number / account ID" };
  }

  function getMethods(countryStr, gateways) {
    var c = findCountry(countryStr);
    var local = c && M[c.cc] ? M[c.cc] : [];
    var seen = {};
    var out = [];
    function pack(name, group) {
      if (seen[name]) return null; seen[name] = 1;
      return { name: name, group: group, kind: name === BANK ? "bank" : "account", hint: HINT[name] || "Registered mobile number / account ID" };
    }
    if (Array.isArray(gateways)) {
      gateways.forEach(function (g) {
        if (!g || !g.name || g.enabled === false || seen[g.name]) return;
        var info = gwInfo(String(g.name));
        seen[g.name] = 1;
        if (info.covers) seen[info.covers] = 1; // don't list the same wallet twice
        out.push({ name: g.name, group: "main", kind: "account", hint: info.hint });
      });
    }
    local.forEach(function (n) { var p = pack(n, "local"); if (p) out.push(p); });
    GLOBAL.forEach(function (n) { var p = pack(n, "global"); if (p) out.push(p); });
    var b = pack(BANK, "bank"); if (b) out.push(b);
    return { country: c, methods: out };
  }

  function isBank(method) { return /bank/i.test(String(method || "")) && /iban|swift/i.test(String(method || "")) || String(method || "") === BANK; }

  // details string for bank: "Account Holder: X | Bank: Y | IBAN/Account: Z | SWIFT/BIC: W"
  var KEYS = ["Account Holder", "Bank Name", "IBAN / Account No", "SWIFT / BIC"];
  function parseBank(str) {
    var o = ["", "", "", ""];
    String(str || "").split("|").forEach(function (part) {
      var i = part.indexOf(":"); if (i < 0) return;
      var k = part.slice(0, i).trim().toLowerCase(), v = part.slice(i + 1).trim();
      if (k.indexOf("holder") >= 0) o[0] = v; else if (k.indexOf("bank") >= 0) o[1] = v; else if (k.indexOf("iban") >= 0) o[2] = v; else if (k.indexOf("swift") >= 0) o[3] = v;
    });
    return o;
  }
  function buildBank(a) { return KEYS.map(function (k, i) { return k + ": " + String(a[i] || "").trim(); }).join(" | "); }

  function validate(method, details) {
    var d = String(details || "").trim();
    if (!method) return "Select a payment method.";
    if (isBank(method)) {
      var p = parseBank(d);
      if (!p[0].trim()) return "Enter the account holder name.";
      if (!p[1].trim()) return "Enter the bank name.";
      var iban = p[2].replace(/\s+/g, "");
      if (iban.length < 8 || !/^[A-Za-z0-9\-]+$/.test(iban)) return "Enter a valid IBAN / account number.";
      var sw = p[3].replace(/\s+/g, "");
      if (!/^[A-Za-z]{4}[A-Za-z]{2}[A-Za-z0-9]{2}([A-Za-z0-9]{3})?$/.test(sw)) return "Enter a valid SWIFT / BIC code (8 or 11 characters).";
      return "";
    }
    if (d.length < 3) return "Enter your account / wallet details.";
    return "";
  }

  window.EVL_PAY = { countries: countries, BANK: BANK, GLOBAL: GLOBAL, getMethods: getMethods, findCountry: findCountry, isBank: isBank, parseBank: parseBank, buildBank: buildBank, validate: validate, bankKeys: KEYS };
})();
