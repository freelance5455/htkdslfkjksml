/* EarnViaLinks - email OTP verification popup.
   Used by the sign-up / login flow: window.__evlVerifyEmail(email, message, emailSent) -> Promise<{user}|null> */
(function () {
  var CSS = '#evl-otp-bg{position:fixed;inset:0;z-index:2147483000;background:rgba(15,23,42,.65);backdrop-filter:blur(4px);display:flex;align-items:center;justify-content:center;padding:16px;font-family:inherit}' +
    '#evl-otp{background:#fff;color:#0f172a;width:100%;max-width:400px;border-radius:20px;padding:26px 22px;box-shadow:0 25px 60px rgba(0,0,0,.35)}' +
    '#evl-otp h3{margin:0 0 6px;font-size:20px;font-weight:800}' +
    '#evl-otp p{margin:0 0 14px;font-size:13px;line-height:1.5;color:#475569}' +
    '#evl-otp input{width:100%;box-sizing:border-box;text-align:center;font-size:28px;letter-spacing:10px;font-weight:700;padding:12px 8px;border:2px solid #e2e8f0;border-radius:14px;outline:none;color:#6c14ff}' +
    '#evl-otp input:focus{border-color:#6c14ff}' +
    '#evl-otp button{cursor:pointer;font-family:inherit}' +
    '#evl-otp .evl-main{width:100%;margin-top:14px;padding:13px;border:0;border-radius:14px;background:#6c14ff;color:#fff;font-weight:700;font-size:14px}' +
    '#evl-otp .evl-main:disabled{opacity:.6}' +
    '#evl-otp .evl-row{display:flex;justify-content:space-between;margin-top:12px}' +
    '#evl-otp .evl-link{background:none;border:0;color:#6c14ff;font-weight:700;font-size:12px;padding:4px 0}' +
    '#evl-otp .evl-link:disabled{color:#94a3b8;cursor:default}' +
    '#evl-otp .evl-cancel{color:#64748b}' +
    '#evl-otp .evl-msg{min-height:18px;margin-top:10px;font-size:12px;font-weight:600;text-align:center}';

  function api(path, body) {
    return fetch('/api/auth/' + path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
      .then(function (r) { return r.json().catch(function () { return {}; }).then(function (d) { d._status = r.status; return d; }); });
  }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  window.__evlVerifyEmail = function (email, message, emailSent) {
    return new Promise(function (resolve) {
      var old = document.getElementById('evl-otp-bg'); if (old) old.remove();
      if (!document.getElementById('evl-otp-css')) {
        var st = document.createElement('style'); st.id = 'evl-otp-css'; st.textContent = CSS; document.head.appendChild(st);
      }
      var bg = document.createElement('div'); bg.id = 'evl-otp-bg';
      bg.innerHTML = '<div id="evl-otp" role="dialog" aria-modal="true"><h3>Verify your email</h3>' +
        '<p>' + esc(message || ('Enter the 6-digit code we sent to ' + email + '.')) + '</p>' +
        '<input id="evl-otp-in" type="text" inputmode="numeric" pattern="[0-9]*" maxlength="6" autocomplete="one-time-code" placeholder="••••••">' +
        '<div class="evl-msg" id="evl-otp-msg"></div>' +
        '<button class="evl-main" id="evl-otp-go">Verify &amp; Continue</button>' +
        '<div class="evl-row"><button class="evl-link" id="evl-otp-re" disabled>Resend code</button>' +
        '<button class="evl-link evl-cancel" id="evl-otp-x">Cancel</button></div></div>';
      document.body.appendChild(bg);
      var input = bg.querySelector('#evl-otp-in'), msg = bg.querySelector('#evl-otp-msg'),
        go = bg.querySelector('#evl-otp-go'), re = bg.querySelector('#evl-otp-re'), x = bg.querySelector('#evl-otp-x');
      var timer = null, busy = false;

      function say(t, ok) { msg.textContent = t || ''; msg.style.color = ok ? '#059669' : '#e11d48'; }
      function done(v) { clearInterval(timer); bg.remove(); resolve(v); }
      function cooldown(sec) {
        clearInterval(timer);
        re.disabled = true;
        (function tick() {
          if (sec <= 0) { re.disabled = false; re.textContent = 'Resend code'; clearInterval(timer); return; }
          re.textContent = 'Resend in ' + sec + 's'; sec--;
        })();
        timer = setInterval(function () {
          if (sec <= 0) { re.disabled = false; re.textContent = 'Resend code'; clearInterval(timer); return; }
          re.textContent = 'Resend in ' + sec + 's'; sec--;
        }, 1000);
      }
      function verify() {
        var code = input.value.replace(/\D/g, '');
        if (code.length !== 6) { say('Please enter the 6-digit code.'); return; }
        if (busy) return; busy = true; go.disabled = true; say('Verifying…', true);
        api('verify-email', { email: email, code: code }).then(function (d) {
          busy = false; go.disabled = false;
          if (d.success && d.user) { say('Verified!', true); done({ user: d.user }); }
          else say(d.message || 'Verification failed. Please try again.');
        }).catch(function () { busy = false; go.disabled = false; say('Network error. Please try again.'); });
      }
      input.addEventListener('input', function () {
        input.value = input.value.replace(/\D/g, '').slice(0, 6);
        if (input.value.length === 6) verify();
      });
      input.addEventListener('keydown', function (e) { if (e.key === 'Enter') verify(); });
      go.addEventListener('click', verify);
      re.addEventListener('click', function () {
        re.disabled = true; say('Sending a new code…', true);
        api('resend-verification', { email: email }).then(function (d) {
          if (d.success) { say('A new code has been sent. Check your inbox (and spam).', true); cooldown(60); }
          else { say(d.message || 'Could not resend the code.'); cooldown(d.wait || 15); }
        }).catch(function () { say('Network error. Please try again.'); re.disabled = false; });
      });
      x.addEventListener('click', function () { done(null); });
      cooldown(emailSent === false ? 5 : 60);
      if (emailSent === false) say(message || '', false);
      setTimeout(function () { input.focus(); }, 50);
    });
  };
})();
