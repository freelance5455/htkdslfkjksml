/**
 * earnvialinks (earnvialinks.com) - Full-Page Script Integration v1.2
 * Automatically monetizes external download and outbound links.
 * 
 * Usage:
 * <script type="text/javascript">
 *   var earnvialinks_api_key = 'YOUR_PUBLISHER_API_KEY';
 *   var earnvialinks_domains = ['mega.nz', 'mediafire.com', 'drive.google.com', 'dropbox.com']; // Optional: specify target domains
 *   // var earnvialinks_exclude_domains = ['yourdomain.com', 'google.com']; // Optional: domains to exclude
 * </script>
 * <script src="https://earnvialinks.com/js/fullpage.js" async></script>
 */
(function() {
  'use strict';

  function initEarnvialinksFullPage() {
    var apiKey = window.earnvialinks_api_key || window.earnvialinks_key || '';
    if (!apiKey) {
      console.warn('[earnvialinks.com] Full-Page Script: earnvialinks_api_key is missing.');
      return;
    }

    var baseUrl = window.earnvialinks_base_url || 'https://earnvialinks.com';
    var rawDomains = window.earnvialinks_domains;
    var rawExclude = window.earnvialinks_exclude_domains;

    var targetDomains = Array.isArray(rawDomains) ? rawDomains.map(function(d) { return d.toLowerCase().trim(); }) : [];
    var excludeDomains = Array.isArray(rawExclude) ? rawExclude.map(function(d) { return d.toLowerCase().trim(); }) : [];

    // Always exclude current host and common platforms
    try {
      if (window.location && window.location.hostname) {
        excludeDomains.push(window.location.hostname.toLowerCase());
      }
    } catch(e) {}
    excludeDomains.push('earnvialinks.com', 'localhost', '127.0.0.1');

    function isDomainMatched(hostname, domainList) {
      for (var i = 0; i < domainList.length; i++) {
        var d = domainList[i];
        if (hostname === d || hostname.indexOf('.' + d) !== -1 || d.indexOf(hostname) !== -1) {
          return true;
        }
      }
      return false;
    }

    function shouldMonetize(href) {
      if (!href || typeof href !== 'string') return false;
      var trimmed = href.trim();
      if (trimmed.indexOf('http://') !== 0 && trimmed.indexOf('https://') !== 0) return false;
      if (trimmed.indexOf(baseUrl) === 0) return false;

      try {
        var parsed = new URL(trimmed);
        var host = parsed.hostname.toLowerCase();

        // Check exclusions
        if (isDomainMatched(host, excludeDomains)) {
          return false;
        }

        // If target domains list is provided, only monetize matched
        if (targetDomains.length > 0) {
          return isDomainMatched(host, targetDomains);
        }

        return true;
      } catch (e) {
        return false;
      }
    }

    function processLink(a) {
      if (!a || a.getAttribute('data-evl-processed')) return;
      var href = a.getAttribute('href');
      if (shouldMonetize(href)) {
        a.setAttribute('data-evl-processed', 'true');
        a.setAttribute('data-evl-original', href);
        // Direct redirect gateway via Quick API
        var monetizedUrl = baseUrl + '/api/quick?api=' + encodeURIComponent(apiKey) + '&url=' + encodeURIComponent(href) + '&redirect=1';
        a.setAttribute('href', monetizedUrl);
      }
    }

    function scanAllLinks() {
      var links = document.getElementsByTagName('a');
      for (var i = 0; i < links.length; i++) {
        processLink(links[i]);
      }
    }

    // Initial scan
    scanAllLinks();

    // Listen for dynamically inserted nodes (single-page apps, infinite scroll)
    if (window.MutationObserver) {
      var observer = new MutationObserver(function(mutations) {
        for (var i = 0; i < mutations.length; i++) {
          var addedNodes = mutations[i].addedNodes;
          for (var j = 0; j < addedNodes.length; j++) {
            var node = addedNodes[j];
            if (node.nodeType === 1) { // ELEMENT_NODE
              if (node.tagName === 'A') {
                processLink(node);
              } else if (node.getElementsByTagName) {
                var subLinks = node.getElementsByTagName('a');
                for (var k = 0; k < subLinks.length; k++) {
                  processLink(subLinks[k]);
                }
              }
            }
          }
        }
      });

      observer.observe(document.body || document.documentElement, {
        childList: true,
        subtree: true,
      });
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initEarnvialinksFullPage);
  } else {
    initEarnvialinksFullPage();
  }
})();
