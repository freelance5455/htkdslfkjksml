<?php
// earnvialinks PHP port: helpers, JSON storage, auth, security, OTP, mail, slugs, gateways.
define('ROOT', dirname(__DIR__));
$__envFile = ROOT . '/.env';
if (is_file($__envFile)) {
    foreach (file($__envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $__l) {
        if (preg_match('/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/', $__l, $m) && $__l[0] !== '#') {
            $v = trim($m[2], "\"'");
            if (getenv($m[1]) === false) putenv($m[1] . '=' . $v);
        }
    }
}
function env($k, $d = '') { $v = getenv($k); return ($v === false || $v === '') ? $d : $v; }
$__dp = is_file(ROOT . '/data-path.php') ? @include ROOT . '/data-path.php' : null; // optional: <?php return '/home/USER/earnvialinks-data';
define('DATA_DIR', env('DATA_DIR') ? rtrim(env('DATA_DIR'), '/') : ((is_string($__dp) && trim($__dp) !== '') ? rtrim(trim($__dp), '/') : ROOT . '/data'));
define('DB_FILE', DATA_DIR . '/database.json');

function now_sec() { return time(); }
function iso_now() { return gmdate('Y-m-d\TH:i:s') . '.000Z'; }
function today() { return gmdate('Y-m-d'); }
function yesterday() { return gmdate('Y-m-d', time() - 86400); }
function stamp() { return gmdate('Y-m-d H:i:s'); }
function stamp_min() { return gmdate('Y-m-d H:i'); }
function rnd($a, $b) { return random_int($a, $b); }
function hexs($n) { return bin2hex(random_bytes($n)); }
function has($a, $k) { return is_array($a) && array_key_exists($k, $a) && $a[$k] !== null; }
function sstr($v) { return is_string($v) ? trim($v) : ((is_int($v) || is_float($v)) ? (string)$v : ''); }
function num($v) { return is_numeric($v) ? (float)$v : (float)(is_string($v) ? floatval($v) : 0); }
function ival($v) { return (int)floatval($v); }
function r4($n) { return round((float)$n, 4); }
function money($n) { return number_format((float)$n, 2, '.', ','); }
function lower($v) { return strtolower((string)($v ?? '')); }
function is_assoc($v) { return is_array($v) && ($v === [] || array_keys($v) !== range(0, count($v) - 1)); }
function find_idx($list, $fn) { foreach ($list as $i => $x) if ($fn($x)) return $i; return -1; }

// ---------- request / response ----------
function req_headers() {
    $h = [];
    foreach ($_SERVER as $k => $v) {
        if (strpos($k, 'HTTP_') === 0) $h[strtolower(str_replace('_', '-', substr($k, 5)))] = $v;
    }
    if (!isset($h['authorization']) && isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) $h['authorization'] = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
    return $h;
}
function hdr($k) { global $HEADERS; return (string)($HEADERS[strtolower($k)] ?? ''); }
function out($code, $data) {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR);
    exit;
}
function fail($code, $msg, $extra = []) { out($code, array_merge(['success' => false, 'message' => $msg], $extra)); }
function clean_ip($ip) { $ip = trim(explode(',', (string)$ip)[0]); if (strpos($ip, '::ffff:') === 0) $ip = substr($ip, 7); return $ip; }
function client_ip() {
    $ip = clean_ip(hdr('cf-connecting-ip') ?: (hdr('x-forwarded-for') ?: hdr('x-real-ip')));
    if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
    $s = clean_ip($_SERVER['REMOTE_ADDR'] ?? '');
    return filter_var($s, FILTER_VALIDATE_IP) ? $s : '0.0.0.0';
}
function secure_ip() {
    $cf = clean_ip(hdr('cf-connecting-ip'));
    if ($cf) return $cf;
    $x = array_values(array_filter(array_map('trim', explode(',', hdr('x-forwarded-for')))));
    if ($x) return clean_ip($x[count($x) - 1]);
    return clean_ip(hdr('x-real-ip') ?: ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'));
}
function site_base() {
    $e = rtrim(trim(env('BASE_URL')), '/');
    if (!$e) { $sb = $GLOBALS['DB']['site']['baseUrl'] ?? ''; if (is_string($sb) && $sb !== '') $e = rtrim(trim($sb), '/'); }
    if ($e && preg_match('#^(https?)://(.+)$#i', $e, $m)) return ['proto' => strtolower($m[1]) . '://', 'host' => $m[2], 'origin' => $e];
    $https = strtolower(trim(explode(',', hdr('x-forwarded-proto'))[0])) === 'https' || (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    $proto = $https ? 'https://' : 'http://';
    $host = trim(explode(',', hdr('x-forwarded-host') ?: ($_SERVER['HTTP_HOST'] ?? 'localhost'))[0]);
    return ['proto' => $proto, 'host' => $host, 'origin' => $proto . $host];
}

// ---------- gateways ----------
function pg_norm($s) { return preg_replace('/[^a-z0-9]/', '', strtolower((string)$s)); }
function pg_required() {
    return [
        ['usdt_trc20', 'USDT (TRC-20 Crypto)', 10, 'Global (Tron TRC20)', 'Global zero-fee crypto payout via Tron TRC-20', ['usdttrc20', 'usdttrc20crypto', 'cryptousdttrc20', 'usdt', 'crypto', 'gwcrypto', 'gwusdt']],
        ['paypal', 'PayPal', 10, 'Global (200+ Countries)', 'Direct PayPal wallet balance transfer in USD', ['paypal', 'paypalusd', 'gwpaypal']],
        ['upi', 'UPI', 10, 'India (Instant VPA)', 'Direct UPI transfer in INR (PhonePe, GPay, Paytm)', ['upi', 'upiindia', 'gwupi']],
        ['bank_pk', 'Local Bank Transfer (Pakistan)', 20, 'Pakistan (All Local Banks)', 'Wire transfer directly to any local Pakistani bank (IBAN)', ['bankpk', 'localbanktransferpakistan', 'gwbankpk']],
        ['easypaisa', 'Easypaisa (Pakistan)', 10, 'Pakistan (Mobile Account)', 'Instant mobile account transfer to Pakistani numbers', ['easypaisa', 'easypaisapakistan', 'gweasypaisa']],
        ['ngbank', 'Nigerian Bank Transfer', 10, 'Nigeria (All Commercial Banks)', 'Direct NGN bank transfer across GTBank, Access, Zenith, Kuda & OPay', ['ngbank', 'nigerianbanktransfer', 'nigerianbank', 'gwngbank']],
        ['bkash', 'bKash (Bangladesh)', 10, 'Bangladesh (Personal Wallet)', 'Fast bKash personal account mobile money transfer in BDT', ['bkash', 'bkashbangladesh', 'gwbkash']],
        ['jazzcash', 'JazzCash (Pakistan)', 10, 'Pakistan (Mobile Account)', 'Direct mobile wallet transfer in PKR', ['jazzcash', 'jazzcashpakistan', 'gwjazzcash']],
        ['payeer', 'Payeer (USD)', 10, 'Global', 'Worldwide electronic wallet payout', ['payeer', 'payeerusd', 'gwpayeer']],
        ['airtm', 'Airtm', 10, 'Global', 'Global peer-to-peer dollar balance', ['airtm', 'gwairtm']],
    ];
}
function migrate_gateways(&$s) {
    if (!is_array($s) || ($s['paymentGatewaysVersion'] ?? 0) === 2) return false;
    $cur = array_values(array_filter(is_array($s['paymentGateways'] ?? null) ? $s['paymentGateways'] : [], 'is_array'));
    $proc = $s['withdrawalProcessingTime'] ?? 'Withdraw Every Week';
    $used = []; $ordered = [];
    foreach (pg_required() as $r) {
        $idx = -1;
        foreach ($cur as $i => $g) if (!isset($used[$i]) && (in_array(pg_norm($g['id'] ?? ''), $r[5], true) || in_array(pg_norm($g['name'] ?? ''), $r[5], true))) { $idx = $i; break; }
        if ($idx >= 0) { $used[$idx] = 1; $ordered[] = $cur[$idx]; }
        else $ordered[] = ['id' => $r[0], 'name' => $r[1], 'minPayout' => $r[2], 'processingTime' => $proc, 'fee' => '0% (Free)', 'enabled' => true, 'coverage' => $r[3], 'description' => $r[4]];
    }
    foreach ($cur as $i => $g) if (!isset($used[$i])) $ordered[] = $g;
    $s['paymentGateways'] = $ordered; $s['paymentGatewaysVersion'] = 2;
    return true;
}

// ---------- storage ----------
function initial_db() {
    $rates = [['🇨🇭', 'Switzerland', 30, 'Premium'], ['🇮🇸', 'Iceland', 30, 'Premium'], ['🇺🇸', 'United States', 20, 'Premium'], ['🇬🇧', 'United Kingdom', 20, 'Premium'], ['🇨🇦', 'Canada', 20, 'Premium'], ['🇦🇺', 'Australia', 20, 'Premium'], ['🇩🇪', 'Germany', 14, 'High'], ['🇦🇪', 'United Arab Emirates', 12, 'High'], ['🇸🇦', 'Saudi Arabia', 10, 'High'], ['🇵🇰', 'Pakistan', 8, 'Standard'], ['🇮🇳', 'India', 8, 'Standard'], ['🇧🇩', 'Bangladesh', 8, 'Standard'], ['🇵🇭', 'Philippines', 8, 'Standard'], ['🌍', 'All Other Countries', 8, 'Standard']];
    return [
        'users' => [], 'links' => [], 'withdrawals' => [],
        'settings' => [
            'minWithdrawal' => 10.0, 'withdrawalProcessingTime' => 'Withdraw Every Week', 'defaultCPM' => 8.0, 'clickPayout' => 0.008, 'signupBonus' => 2.0, 'adminKey' => '',
            'bannerZoneId' => 'zone_banner_839102', 'popunderZoneId' => 'zone_popunder_472190', 'inPagePushZoneId' => 'zone_inpage_991823',
            'directLinksEnabled' => true, 'antiFraudEnabled' => true, 'minViewSeconds' => 12, 'viewCooldownHours' => 12, 'maxViewsPerIpPerHour' => 40,
            'streakDirectLinkEnabled' => false, 'streakDirectLink' => '',
            'directLink1' => 'https://otieuwai.net/4/839102', 'directLink2' => 'https://otieuwai.net/4/839103', 'directLink3' => 'https://otieuwai.net/4/839104',
            'announcement' => 'Welcome to earnvialinks Publisher Network', 'referralPercent' => 15,
            'countryCpmRates' => array_map(function ($r) { return ['flag' => $r[0], 'country' => $r[1], 'rate' => (float)$r[2], 'tier' => $r[3]]; }, $rates),
            'smtpConfig' => ['host' => 'smtp.hostinger.com', 'port' => 465, 'secure' => true, 'user' => 'mail@earnvialinks.com', 'pass' => '', 'fromName' => 'EarnViaLinks', 'fromEmail' => 'mail@earnvialinks.com'],
            'databaseConfig' => ['host' => 'localhost', 'name' => '', 'user' => '', 'pass' => '', 'port' => 3306, 'connected' => false],
        ],
        'visitLogs' => [], 'passwordResets' => [], 'emailVerifications' => [], 'fraudLogs' => [], 'emailLogs' => [], 'updatedAt' => iso_now(),
    ];
}
// The dashboard (React) crashes to a blank page when a number is null/"text" or a list is an object.
// Data restored from older backups often has such values, so coerce every field the UI formats.
function sanitize_records(&$d) {
    $n = function ($v) { return is_numeric($v) ? $v + 0 : 0; };
    $arr = function ($v) { if (is_array($v)) return array_values($v); if (is_string($v) && $v !== '') return array_values(array_filter(array_map('trim', explode(',', $v)), 'strlen')); return []; };
    foreach ($d['users'] as $i => $u) {
        if (!is_array($u)) { unset($d['users'][$i]); continue; }
        foreach (['bal', 'balance', 'earnPtc', 'earnOffers', 'referralEarnings', 'adminAdjustment'] as $k) if (array_key_exists($k, $u) || in_array($k, ['bal', 'balance'], true)) $u[$k] = $n($u[$k] ?? 0);
        foreach (['views', 'referralCount', 'streakDay'] as $k) $u[$k] = (int)$n($u[$k] ?? 0);
        foreach (['claimedStreakDays', 'loyaltyClaimed', 'claimedReferralTiers'] as $k) if (array_key_exists($k, $u)) $u[$k] = $arr($u[$k]);
        foreach (['name', 'email', 'country', 'paymentDetails', 'joinedDate', 'referralCode', 'apiKey', 'status'] as $k) if (array_key_exists($k, $u) && !is_string($u[$k])) $u[$k] = ($u[$k] === null || is_array($u[$k])) ? '' : (string)$u[$k];
        if (($u['status'] ?? '') === '') $u['status'] = 'Active';
        if (empty($u['joinedDate'])) $u['joinedDate'] = substr((string)($u['createdAt'] ?? gmdate('Y-m-d')), 0, 10) ?: gmdate('Y-m-d');
        $d['users'][$i] = $u;
    }
    $d['users'] = array_values($d['users']);
    foreach ($d['links'] as $i => $l) {
        if (!is_array($l)) { unset($d['links'][$i]); continue; }
        foreach (['clicks', 'views', 'earnings', 'uniqueClicks'] as $k) $l[$k] = $n($l[$k] ?? 0);
        foreach (['slug', 'url', 'originalUrl', 'title', 'createdAt', 'userId'] as $k) if (!is_string($l[$k] ?? '')) $l[$k] = '';
        foreach (['slug', 'url', 'originalUrl', 'title', 'createdAt', 'userId'] as $k) if (!array_key_exists($k, $l)) $l[$k] = '';
        $d['links'][$i] = $l;
    }
    $d['links'] = array_values($d['links']);
    foreach ($d['withdrawals'] as $i => $w) {
        if (!is_array($w)) { unset($d['withdrawals'][$i]); continue; }
        $w['amount'] = $n($w['amount'] ?? 0);
        foreach (['method', 'status', 'details', 'userName', 'userEmail', 'requestedAt'] as $k) if (!is_string($w[$k] ?? '')) $w[$k] = '';
        $d['withdrawals'][$i] = $w;
    }
    $d['withdrawals'] = array_values($d['withdrawals']);
    foreach ($d['visitLogs'] as $i => $v) { if (!is_array($v)) unset($d['visitLogs'][$i]); }
    $d['visitLogs'] = array_values($d['visitLogs']);
}
function normalize_db($d) {
    foreach (['users', 'links', 'withdrawals', 'visitLogs', 'passwordResets', 'emailLogs', 'referralLogs', 'emailVerifications', 'fraudLogs'] as $k) if (!is_array($d[$k] ?? null)) $d[$k] = [];
    foreach (['adminSessions', 'userSessions'] as $k) if (!is_array($d[$k] ?? null)) $d[$k] = [];
    $d['settings'] = array_replace(initial_db()['settings'], is_array($d['settings'] ?? null) ? $d['settings'] : []);
    migrate_gateways($d['settings']);
    sanitize_records($d);
    if (in_array($d['settings']['adminKey'] ?? '', ['admin@techmax', 'admin@jd'], true)) $d['settings']['adminKey'] = '';
    return $d;
}
function read_json($f) { $t = @file_get_contents($f); $d = $t ? json_decode($t, true) : null; return is_array($d) ? $d : null; }
function db_load() {
    global $DB;
    if (!is_dir(DATA_DIR)) @mkdir(DATA_DIR, 0775, true);
    $d = (is_file(DB_FILE) && filesize(DB_FILE) > 0) ? read_json(DB_FILE) : null;
    if (!$d) {
        foreach (['database.backup.json', 'database.backup.prev.json', 'database.sample.json'] as $f) {
            if (is_file(DATA_DIR . '/' . $f) && filesize(DATA_DIR . '/' . $f) > 0 && ($d = read_json(DATA_DIR . '/' . $f))) break;
        }
        if (!$d) $d = initial_db();
        file_put_contents(DB_FILE, json_encode(normalize_db($d), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }
    $DB = normalize_db($d);
}
function save_db($force = false) {
    global $DB;
    static $last = 0;
    if (($force || time() - $last > 30) && is_file(DB_FILE) && filesize(DB_FILE) > 0) {
        if (is_file(DATA_DIR . '/database.backup.json')) @copy(DATA_DIR . '/database.backup.json', DATA_DIR . '/database.backup.prev.json');
        @copy(DB_FILE, DATA_DIR . '/database.backup.json'); $last = time();
    }
    $DB['updatedAt'] = iso_now();
    $tmp = DB_FILE . '.tmp.' . hexs(6);
    file_put_contents($tmp, json_encode($DB, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    rename($tmp, DB_FILE);
    return true;
}
// small expiring key/value store for rate limits & anti-fraud (data/runtime.json)
function rt_op($fn) {
    $f = DATA_DIR . '/runtime.json';
    $d = read_json($f) ?: [];
    $now = time();
    foreach ($d as $k => $v) if (($v['x'] ?? 0) < $now) unset($d[$k]);
    $r = $fn($d, $now);
    @file_put_contents($f, json_encode($d));
    return $r;
}
function rl_hit($key, $max, $windowSec) {
    return rt_op(function (&$d, $now) use ($key, $max, $windowSec) {
        if (!isset($d[$key])) $d[$key] = ['n' => 0, 'x' => $now + $windowSec];
        $d[$key]['n']++;
        return $d[$key]['n'] <= $max;
    });
}
function rl_blocked($key, $max) { return rt_op(function (&$d) use ($key, $max) { return isset($d[$key]) && $d[$key]['n'] >= $max; }); }
function rl_clear($key) { rt_op(function (&$d) use ($key) { unset($d[$key]); }); }

// ---------- auth ----------
function hash_pw($pw) { return password_hash($pw, PASSWORD_BCRYPT, ['cost' => 10]); }
function verify_pw($pw, $stored) {
    if (!$stored) return [false, false];
    if (strpos($stored, '$2') === 0) return [password_verify($pw, $stored), false];
    return [hash_equals((string)$stored, (string)$pw), true];
}
function admin_key() {
    global $DB;
    $e = env('ADMIN_PASSKEY'); $s = $DB['settings']['adminKey'] ?? '';
    if (in_array($s, ['admin@techmax', 'admin@jd'], true)) $s = '';
    return $e ?: $s;
}
function has_admin_key() { global $DB; return strlen(trim(env('ADMIN_PASSKEY'))) >= 4 || strlen(trim($DB['settings']['adminKey'] ?? '')) >= 4; }
function admin_token() {
    $raw = hdr('authorization') ?: hdr('x-admin-token');
    return trim(preg_match('/Bearer\s+(.*)$/i', $raw, $m) ? $m[1] : $raw);
}
function is_admin_session($t) { global $DB; return $t && isset($DB['adminSessions'][$t]) && ($DB['adminSessions'][$t]['expiresAt'] ?? 0) >= time(); }
function create_admin_session() {
    global $DB; $now = time();
    foreach ($DB['adminSessions'] as $t => $s) if (($s['expiresAt'] ?? 0) < $now) unset($DB['adminSessions'][$t]);
    $t = hexs(32); $exp = $now + 7 * 86400;
    $DB['adminSessions'][$t] = ['token' => $t, 'createdAt' => $now, 'expiresAt' => $exp];
    return [$t, $exp];
}
function require_admin() {
    global $DB;
    $t = admin_token();
    if (!$t) fail(401, 'Access Denied: Administrative authentication token required.');
    if (!isset($DB['adminSessions'][$t])) fail(401, 'Access Denied: Invalid or expired administrative session.');
    if (($DB['adminSessions'][$t]['expiresAt'] ?? 0) < time()) { unset($DB['adminSessions'][$t]); save_db(); fail(401, 'Access Denied: Administrative session expired.'); }
}
function without_pw($u) { unset($u['password']); return $u; }
function find_user($id) { global $DB; return find_idx($DB['users'], function ($u) use ($id) { return ($u['id'] ?? '') === $id; }); }

// ---------- user sessions & anti-fraud ----------
function sha($t) { return hash('sha256', (string)$t); }
function create_user_session($userId) {
    global $DB; $now = time(); $mine = [];
    foreach ($DB['userSessions'] as $k => $s) {
        if (($s['expiresAt'] ?? 0) < $now) unset($DB['userSessions'][$k]);
        elseif (($s['userId'] ?? '') === $userId) $mine[$k] = $s['createdAt'] ?? 0;
    }
    if (count($mine) >= 8) { asort($mine); foreach (array_slice(array_keys($mine), 0, count($mine) - 7) as $k) unset($DB['userSessions'][$k]); }
    $t = 'ust_' . hexs(32);
    $DB['userSessions'][sha($t)] = ['userId' => $userId, 'createdAt' => $now, 'expiresAt' => $now + 30 * 86400];
    return $t;
}
function drop_user_sessions($userId) { global $DB; foreach ($DB['userSessions'] as $k => $s) if (($s['userId'] ?? '') === $userId) unset($DB['userSessions'][$k]); }
function require_user($userId) {
    global $DB;
    if (is_admin_session(admin_token())) { $i = find_user($userId); return $i >= 0 ? $DB['users'][$i] : []; }
    $tok = trim(hdr('x-user-token'));
    $s = $tok ? ($DB['userSessions'][sha($tok)] ?? null) : null;
    if (!$s || ($s['expiresAt'] ?? 0) < time()) fail(401, 'Your login session has expired. Please log in again.', ['code' => 'USER_AUTH_REQUIRED']);
    if ($userId && $s['userId'] !== $userId) fail(403, 'Access denied for this account.');
    $i = find_user($s['userId']);
    if ($i < 0) fail(401, 'Account not found. Please log in again.', ['code' => 'USER_AUTH_REQUIRED']);
    if (in_array($DB['users'][$i]['status'] ?? '', ['Banned', 'Suspended'], true)) fail(403, 'This account is not active.');
    return $DB['users'][$i];
}
function sec_secret() { global $DB; if (empty($DB['securitySecret'])) { $DB['securitySecret'] = hexs(32); save_db(); } return $DB['securitySecret']; }
function ua_hash() { return substr(sha(hdr('user-agent')), 0, 10); }
function b64u($s) { return rtrim(strtr(base64_encode($s), '+/', '-_'), '='); }
function b64u_d($s) { return base64_decode(strtr($s, '-_', '+/')); }
function make_visit_token($slug) {
    $p = b64u(json_encode(['s' => $slug, 't' => (int)(microtime(true) * 1000), 'n' => hexs(8), 'u' => ua_hash()]));
    return $p . '.' . b64u(hash_hmac('sha256', $p, sec_secret(), true));
}
function read_visit_token($slug) {
    $parts = explode('.', trim(hdr('x-visit-token')));
    if (count($parts) !== 2 || !$parts[0] || !$parts[1]) return null;
    if (!hash_equals(b64u(hash_hmac('sha256', $parts[0], sec_secret(), true)), $parts[1])) return null;
    $d = json_decode(b64u_d($parts[0]), true);
    return (is_array($d) && ($d['s'] ?? '') === $slug && ($d['u'] ?? '') === ua_hash()) ? $d : null;
}
function fraud_cfg() {
    global $DB; $s = $DB['settings'];
    return ['enabled' => ($s['antiFraudEnabled'] ?? true) !== false, 'minSeconds' => max(0, num($s['minViewSeconds'] ?? 12)), 'cooldown' => max(0, num($s['viewCooldownHours'] ?? 12)), 'maxHr' => max(1, ival($s['maxViewsPerIpPerHour'] ?? 40))];
}
function verify_turnstile($token, $ip) {
    $sk = env('TURNSTILE_SECRET');
    if (!$sk) return 'skip';
    if (!$token) return 'missing';
    $ctx = stream_context_create(['http' => ['method' => 'POST', 'timeout' => 5, 'header' => 'Content-Type: application/x-www-form-urlencoded', 'content' => http_build_query(['secret' => $sk, 'response' => $token, 'remoteip' => $ip])]]);
    $r = @file_get_contents('https://challenges.cloudflare.com/turnstile/v0/siteverify', false, $ctx);
    if ($r === false) return 'unreachable';
    $d = json_decode($r, true);
    return !empty($d['success']) ? 'ok' : 'fail';
}
function evaluate_click($slug, $link) {
    global $DB;
    $c = fraud_cfg(); $ip = secure_ip(); $ua = hdr('user-agent');
    if (!$c['enabled']) return ['counted' => true, 'ip' => $ip];
    $rej = function ($r) use ($ip) { return ['counted' => false, 'reason' => $r, 'ip' => $ip]; };
    if (!$ua || strlen($ua) < 12 || preg_match('/bot|crawl|spider|slurp|curl|wget|python|requests|httpclient|java\/|okhttp|axios|node-fetch|go-http|libwww|php|scrapy|headless|phantom|puppeteer|playwright|selenium|lighthouse|postman/i', $ua)) return $rej('bot-user-agent');
    if (!hdr('accept-language')) return $rej('no-browser-language');
    $tok = read_visit_token($slug);
    if (!$tok) return $rej('missing-or-invalid-visit-token');
    $age = (int)(microtime(true) * 1000) - $tok['t'];
    if ($age > 7200000) return $rej('token-expired');
    if ($age < $c['minSeconds'] * 1000) return $rej('too-fast');
    $hv = explode(',', hdr('x-human') ?: '0,0');
    $ev = (int)($hv[0] ?? 0); $flags = (int)($hv[1] ?? 0);
    if ($flags) return $rej('automation-detected');
    if ($ev < 1) return $rej('no-human-interaction');
    $ts = verify_turnstile(trim(hdr('x-turnstile')), $ip);
    if ($ts === 'missing' || $ts === 'fail') return $rej('captcha-failed');
    $oi = !empty($link['userId']) ? find_user($link['userId']) : -1;
    if ($oi >= 0 && in_array($ip, $DB['users'][$oi]['knownIps'] ?? [], true)) return $rej('self-click');
    $vKey = 'v:' . sha("$ip|" . ua_hash() . "|$slug"); $nKey = 'n:' . $tok['n']; $hKey = 'h:' . $ip;
    $res = rt_op(function (&$d, $now) use ($vKey, $nKey, $hKey, $c) {
        if (isset($d[$nKey])) return 'token-reused';
        if (isset($d[$vKey])) return 'duplicate-view';
        if (isset($d[$hKey]) && $d[$hKey]['n'] >= $c['maxHr']) return 'ip-hourly-limit';
        $d[$nKey] = ['x' => $now + 10800];
        if ($c['cooldown'] > 0) $d[$vKey] = ['x' => $now + (int)($c['cooldown'] * 3600)];
        if (!isset($d[$hKey])) $d[$hKey] = ['n' => 0, 'x' => $now + 3600];
        $d[$hKey]['n']++;
        return 'ok';
    });
    return $res === 'ok' ? ['counted' => true, 'ip' => $ip] : $rej($res);
}
function log_fraud($slug, $reason, $ip) {
    global $DB;
    array_unshift($DB['fraudLogs'], ['id' => 'frd-' . time() . '-' . hexs(2), 'timestamp' => stamp(), 'slug' => $slug, 'reason' => $reason, 'ip' => $ip, 'userAgent' => substr(hdr('user-agent'), 0, 120)]);
    $DB['fraudLogs'] = array_slice($DB['fraudLogs'], 0, 500);
}
function remember_ip(&$user) {
    $ip = secure_ip();
    if (!$ip || $ip === '0.0.0.0') return;
    $l = array_values(array_filter($user['knownIps'] ?? [], function ($x) use ($ip) { return $x !== $ip; }));
    array_unshift($l, $ip);
    $user['knownIps'] = array_slice($l, 0, 6);
}

// ---------- mail / OTP ----------
function smtp_send($host, $port, $secure, $user, $pass, $from, $fromName, $to, $subject, $html) {
    $fp = @stream_socket_client(($secure ? 'ssl://' : '') . $host . ':' . $port, $en, $es, 10);
    if (!$fp) throw new Exception("SMTP connect failed: $es");
    stream_set_timeout($fp, 15);
    $rd = function () use ($fp) { $r = ''; while (($l = fgets($fp, 512)) !== false) { $r .= $l; if (strlen($l) < 4 || $l[3] === ' ') break; } return $r; };
    $cmd = function ($c, $ok) use ($fp, $rd) { if ($c !== null) fwrite($fp, $c . "\r\n"); $r = $rd(); if (strpos($r, (string)$ok) !== 0) throw new Exception('SMTP error: ' . trim($r)); return $r; };
    $cmd(null, 220); $cmd('EHLO ' . ($_SERVER['SERVER_NAME'] ?? 'localhost'), 250);
    if (!$secure && $port != 25) { $cmd('STARTTLS', 220); stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT); $cmd('EHLO localhost', 250); }
    $cmd('AUTH LOGIN', 334); $cmd(base64_encode($user), 334); $cmd(base64_encode($pass), 235);
    $cmd("MAIL FROM:<$from>", 250); $cmd("RCPT TO:<$to>", 250); $cmd('DATA', 354);
    $msg = "From: =?UTF-8?B?" . base64_encode($fromName) . "?= <$from>\r\nReply-To: $from\r\nTo: $to\r\nSubject: =?UTF-8?B?" . base64_encode($subject) . "?=\r\nMIME-Version: 1.0\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . chunk_split(base64_encode($html));
    fwrite($fp, $msg . "\r\n.\r\n"); $cmd(null, 250); fwrite($fp, "QUIT\r\n"); fclose($fp);
}
function send_email($to, $subject, $html, $type = 'general', $code = null) {
    global $DB;
    $smtp = $DB['settings']['smtpConfig'] ?? [];
    $host = env('SMTP_HOST') ?: ($smtp['host'] ?? ''); $user = env('SMTP_USER') ?: ($smtp['user'] ?? '');
    $from = env('SMTP_FROM_EMAIL') ?: ($user ?: ($smtp['fromEmail'] ?? 'mail@earnvialinks.com'));
    $pass = env('SMTP_PASS') ?: ($smtp['pass'] ?? ''); $sent = false; $err = null;
    if ($host && $user && $pass) {
        try {
            $port = (int)(env('SMTP_PORT') ?: ($smtp['port'] ?? 465)) ?: 465;
            smtp_send($host, $port, $port === 465, $user, $pass, $from, $smtp['fromName'] ?? 'EarnViaLinks', $to, $subject, $html);
            $sent = true;
        } catch (Throwable $e) { $err = $e->getMessage(); }
    } else $err = 'SMTP password is not configured';
    array_unshift($DB['emailLogs'], ['id' => 'eml-' . time() . '-' . rnd(100, 999), 'recipient' => $to, 'subject' => $subject, 'type' => $type, 'status' => $sent ? 'sent' : 'simulated', 'code' => $code, 'error' => $sent ? null : $err, 'timestamp' => iso_now()]);
    $DB['emailLogs'] = array_slice($DB['emailLogs'], 0, 100);
    save_db();
    return ['success' => true, 'simulated' => !$sent, 'error' => $sent ? null : $err];
}
function otp_enabled() { if (getenv('EMAIL_VERIFICATION') !== false && getenv('EMAIL_VERIFICATION') !== '') return strtolower(env('EMAIL_VERIFICATION')) !== 'off'; return ($GLOBALS['DB']['site']['emailVerification'] ?? true) !== false; }
function otp_hash($salt, $email, $code) { return hash('sha256', "$salt:" . lower($email) . ":$code"); }
function issue_otp($user, $force = false) {
    global $DB;
    $email = lower($user['email']); $now = (int)(microtime(true) * 1000);
    $DB['emailVerifications'] = array_values(array_filter($DB['emailVerifications'], function ($r) use ($now) { return $r['expiresAt'] > $now - 3600000; }));
    $oi = find_idx($DB['emailVerifications'], function ($r) use ($email) { return $r['email'] === $email; });
    $old = $oi >= 0 ? $DB['emailVerifications'][$oi] : null;
    $sends = array_values(array_filter($old['sends'] ?? [], function ($t) use ($now) { return $t > $now - 3600000; }));
    if (!$force && $old && $now - $old['sentAt'] < 60000) return ['ok' => false, 'throttled' => true, 'wait' => (int)ceil((60000 - ($now - $old['sentAt'])) / 1000)];
    if (count($sends) >= 6) return ['ok' => false, 'limited' => true];
    $code = (string)rnd(100000, 999999); $salt = hexs(8); $sends[] = $now;
    $DB['emailVerifications'] = array_values(array_filter($DB['emailVerifications'], function ($r) use ($email) { return $r['email'] !== $email; }));
    array_unshift($DB['emailVerifications'], ['email' => $email, 'salt' => $salt, 'codeHash' => otp_hash($salt, $email, $code), 'expiresAt' => $now + 600000, 'attempts' => 0, 'sentAt' => $now, 'sends' => $sends]);
    save_db();
    $nm = htmlspecialchars($user['name'] ?? '', ENT_QUOTES);
    $html = '<div style="font-family:Arial;max-width:480px;margin:auto;padding:28px;border:1px solid #e2e8f0;border-radius:16px"><h2>Verify your email</h2><p>Hi ' . $nm . ', enter this 6-digit code to verify your EarnViaLinks account:</p><div style="font-size:34px;letter-spacing:10px;font-weight:bold;color:#6c14ff;text-align:center;padding:16px;background:#f5f0ff;border-radius:12px">' . $code . '</div><p style="color:#64748b;font-size:12px">Valid for 10 minutes.</p></div>';
    $m = send_email($user['email'], "$code is your EarnViaLinks verification code", $html, 'signup_otp', null);
    return ['ok' => true, 'emailSent' => !$m['simulated']];
}
function check_otp($email, $code) {
    global $DB;
    $email = lower($email); $now = (int)(microtime(true) * 1000);
    $i = find_idx($DB['emailVerifications'], function ($r) use ($email) { return $r['email'] === $email; });
    if ($i < 0 || $DB['emailVerifications'][$i]['expiresAt'] < $now) return ['ok' => false, 'status' => 400, 'message' => 'This code has expired. Please request a new one.'];
    $rec = &$DB['emailVerifications'][$i];
    if ($rec['attempts'] >= 5) return ['ok' => false, 'status' => 429, 'message' => 'Too many wrong attempts. Please request a new code.'];
    if (hash_equals($rec['codeHash'], otp_hash($rec['salt'], $email, trim((string)$code)))) { array_splice($DB['emailVerifications'], $i, 1); return ['ok' => true]; }
    $rec['attempts']++; $left = 5 - $rec['attempts']; save_db();
    return ['ok' => false, 'status' => 400, 'message' => $left > 0 ? "Incorrect code. $left attempt(s) left." : 'Too many wrong attempts. Please request a new code.'];
}

// ---------- slugs ----------
function validate_slug($slug, $links, $excludeId = null) {
    $reserved = ['realadmin', 'admin', 'api', 'auth', 'dashboard', 'payment-proof', 'blog', 'faq', 'terms', 'privacy', 'contact', 'support', 'customer-support', 'payout-rates', 'rates', 'short', 's', 'ref', 'join', 'register', 'signup', 'login', 'logout', 'reset', 'users', 'user', 'settings', 'monetization', 'ads', 'traffic', 'dmca', 'legal', 'api.php', 'index.php', 'index.html', 'robots.txt', 'sitemap.xml', 'favicon.ico', 'assets', 'static', 'public', 'dist', 'data', 'null', 'undefined', 'true', 'false', 'root', 'server', 'config', 'script', 'iframe', 'test', 'dev', 'app', 'www', 'mail', 'email', 'webhook', 'hook', 'download', 'share', 'link', 'links'];
    $banned = ['phishing', 'hacker', 'hacking', 'hack', 'crack', 'cracked', 'malware', 'trojan', 'virus', 'spyware', 'ransomware', 'exploit', 'keylogger', 'ddos', 'botnet', 'carding', 'scam', 'fraud', 'stealer', 'token-grabber', 'grabber', 'free-robux', 'free-nitro', 'free-vbucks', 'darkweb', 'porn', 'porno', 'xxx', 'adult', 'sex', 'nude', 'nsfw', 'hentai', 'escort', 'camgirl', 'erotic', 'pedophile', 'cp', 'terrorist', 'terror', 'suicide', 'weapons', 'hitman', 'bomb', 'cocaine', 'heroin', 'meth', 'fuck', 'shit', 'bitch', 'asshole', 'cunt', 'dick', 'pussy', 'faggot', 'nigger'];
    $c = strtolower(trim((string)$slug));
    if ($c === '') return ['isValid' => false, 'error' => 'Slug cannot be empty', 'code' => 'EMPTY'];
    if (strlen($c) < 3) return ['isValid' => false, 'error' => 'Slug must be at least 3 characters long', 'code' => 'LENGTH'];
    if (strlen($c) > 40) return ['isValid' => false, 'error' => 'Slug cannot exceed 40 characters', 'code' => 'LENGTH'];
    if (!preg_match('/^[a-z0-9_-]+$/', $c)) return ['isValid' => false, 'error' => 'Slug can only contain letters, numbers, hyphens (-), and underscores (_)', 'code' => 'INVALID_CHARACTERS'];
    if (in_array($c, $reserved, true)) return ['isValid' => false, 'error' => "\"$slug\" is a reserved system path and cannot be used", 'code' => 'RESERVED'];
    $norm = preg_replace('/[^a-z0-9]/', '', $c); $tokens = array_values(array_filter(preg_split('/[^a-z0-9]+/', $c)));
    foreach ($banned as $w) {
        $cl = preg_replace('/[^a-z0-9]/', '', $w); $hit = false;
        if (strlen($cl) <= 3) $hit = in_array($cl, $tokens, true);
        else { $hit = strpos($norm, $cl) !== false; foreach ($tokens as $t) if (strpos($t, $cl) !== false) $hit = true; }
        if ($hit) return ['isValid' => false, 'error' => "Slug contains a prohibited word (\"$w\"). Malicious, inappropriate, or scam words are not allowed.", 'code' => 'BANNED'];
    }
    foreach ($links ?: [] as $l) if (!empty($l['slug']) && strtolower($l['slug']) === $c && !($excludeId && ($l['id'] ?? '') === $excludeId)) return ['isValid' => false, 'error' => "The slug \"$slug\" is already taken. Please choose a different alias.", 'code' => 'TAKEN'];
    return ['isValid' => true];
}
