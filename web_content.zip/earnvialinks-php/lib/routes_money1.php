<?php
// Money part 1: constants, helpers, click tracking
const DEFAULT_STREAK_REWARDS = [0.10, 0.20, 0.30, 0.40, 0.60, 0.80, 1.00];
function default_loyalty() {
    return [['id' => 'tier-starter', 'title' => 'Starter Milestone', 'targetDailyViews' => 25, 'rewardAmount' => 0.50], ['id' => 'tier-1', 'title' => 'Bronze Publisher', 'targetDailyViews' => 100, 'rewardAmount' => 2.00], ['id' => 'tier-2', 'title' => 'Silver Publisher', 'targetDailyViews' => 1000, 'rewardAmount' => 10.00], ['id' => 'tier-3', 'title' => 'Gold Publisher', 'targetDailyViews' => 10000, 'rewardAmount' => 50.00], ['id' => 'tier-4', 'title' => 'Diamond Elite', 'targetDailyViews' => 50000, 'rewardAmount' => 200.00]];
}
function referral_tiers() {
    return [
        ['id' => 'ref-tier-bronze', 'name' => 'Bronze Starter', 'minReferrals' => 0, 'commissionPercent' => 15, 'bonusReward' => 0, 'badge' => '🥉', 'color' => '#cd7f32', 'description' => 'Starting level: 15% lifetime revenue share on every referral.'],
        ['id' => 'ref-tier-silver', 'name' => 'Silver Pro', 'minReferrals' => 6, 'commissionPercent' => 18, 'bonusReward' => 5.0, 'badge' => '🥈', 'color' => '#94a3b8', 'description' => '18% lifetime commission + $5.00 cash milestone bonus.'],
        ['id' => 'ref-tier-gold', 'name' => 'Gold Master', 'minReferrals' => 21, 'commissionPercent' => 20, 'bonusReward' => 15.0, 'badge' => '🥇', 'color' => '#fbbf24', 'description' => '20% lifetime commission + $15.00 cash milestone bonus.'],
        ['id' => 'ref-tier-platinum', 'name' => 'Platinum Elite', 'minReferrals' => 51, 'commissionPercent' => 22, 'bonusReward' => 35.0, 'badge' => '💎', 'color' => '#38bdf8', 'description' => '22% lifetime commission + $35.00 cash milestone bonus.'],
        ['id' => 'ref-tier-diamond', 'name' => 'Diamond VIP', 'minReferrals' => 101, 'commissionPercent' => 25, 'bonusReward' => 100.0, 'badge' => '👑', 'color' => '#6c14ff', 'description' => '25% lifetime commission + $100.00 cash milestone bonus.'],
    ];
}
function iso_map() {
    return ['US' => ['United States', '🇺🇸'], 'GB' => ['United Kingdom', '🇬🇧'], 'CA' => ['Canada', '🇨🇦'], 'AU' => ['Australia', '🇦🇺'], 'DE' => ['Germany', '🇩🇪'], 'AE' => ['United Arab Emirates', '🇦🇪'], 'SA' => ['Saudi Arabia', '🇸🇦'], 'PK' => ['Pakistan', '🇵🇰'], 'IN' => ['India', '🇮🇳'], 'BD' => ['Bangladesh', '🇧🇩'], 'NG' => ['Nigeria', '🇳🇬'], 'PH' => ['Philippines', '🇵🇭']];
}
function streak_rewards() { global $DB; return is_array($DB['settings']['streakRewards'] ?? null) ? $DB['settings']['streakRewards'] : DEFAULT_STREAK_REWARDS; }
function loyalty_tiers() { global $DB; $t = $DB['settings']['loyaltyTiers'] ?? null; return (is_array($t) && $t) ? $t : default_loyalty(); }
function streak_tz() { try { return new DateTimeZone(env('STREAK_TZ', 'Asia/Riyadh')); } catch (Throwable $e) { return new DateTimeZone('UTC'); } }
function streak_state($user) {
    $tz = streak_tz(); $now = new DateTime('now', $tz);
    $todayK = $now->format('Y-m-d'); $mid = (clone $now)->setTime(0, 0, 0);
    $yK = (clone $mid)->modify('-1 second')->format('Y-m-d'); $next = (clone $mid)->modify('+1 day');
    $last = $user['lastClaimDate'] ?? null;
    $arr = array_map('ival', is_array($user['claimedStreakDays'] ?? null) ? $user['claimedStreakDays'] : []);
    $claimedToday = $last === $todayK; $missed = false;
    if ($claimedToday) { $claimed = $arr; $day = $arr ? max($arr) : 1; }
    elseif ($last === $yK) { if (count($arr) >= 7) { $day = 1; $claimed = []; } else { $day = (count($arr) % 7) + 1; $claimed = $arr; } }
    else { $day = 1; $claimed = []; $missed = !!$last && count($arr) > 0; }
    return ['todayK' => $todayK, 'yesterdayK' => $yK, 'claimedToday' => $claimedToday, 'streakDay' => $day, 'claimed' => $claimed, 'missed' => $missed, 'nextClaimAt' => $next->getTimestamp() * 1000, 'serverNow' => (int)(microtime(true) * 1000), 'tz' => env('STREAK_TZ', 'Asia/Riyadh')];
}
function calc_ref_tier($count) {
    $T = referral_tiers();
    for ($i = count($T) - 1; $i >= 0; $i--) if ($count >= $T[$i]['minReferrals']) {
        $next = $i < count($T) - 1 ? $T[$i + 1] : null;
        return ['activeTier' => $T[$i], 'nextTier' => $next, 'referralsToNext' => $next ? max(0, $next['minReferrals'] - $count) : 0];
    }
    return ['activeTier' => $T[0], 'nextTier' => $T[1], 'referralsToNext' => 6];
}
function withdrawable_balance($userId) {
    global $DB;
    $ui = find_user($userId);
    if ($ui < 0) return 0;
    $user = $DB['users'][$ui];
    $gross = num(has($DB['settings'], 'signupBonus') ? $DB['settings']['signupBonus'] : 2.0);
    foreach ($DB['links'] as $l) if (!empty($l['userId']) && $l['userId'] === $userId) $gross += num($l['earnings'] ?? 0);
    $rw = streak_rewards();
    foreach (is_array($user['claimedStreakDays'] ?? null) ? $user['claimedStreakDays'] : [] as $d) if (isset($rw[ival($d) - 1])) $gross += num($rw[ival($d) - 1]);
    $tiers = loyalty_tiers();
    foreach (is_array($user['loyaltyClaimed'] ?? null) ? $user['loyaltyClaimed'] : [] as $tid) foreach ($tiers as $t) if (($t['id'] ?? '') === $tid) $gross += num($t['rewardAmount']);
    $gross += num($user['referralEarnings'] ?? 0) + num($user['adminAdjustment'] ?? 0) + num($user['earnPtc'] ?? 0) + num($user['earnOffers'] ?? 0);
    $wd = 0;
    foreach ($DB['withdrawals'] as $w) if (!empty($w['userId']) && $w['userId'] === $userId && in_array($w['status'] ?? '', ['Pending', 'Completed', 'Approved'], true)) $wd += num($w['amount'] ?? 0);
    $stored = num(has($user, 'bal') ? $user['bal'] : ($user['balance'] ?? 0));
    return min(max(0, r4($gross - $wd)), $stored);
}
function user_matches_ref($u, $refLower) { return lower($u['id'] ?? '') === $refLower || lower($u['referralCode'] ?? '') === $refLower || lower($u['name'] ?? '') === $refLower || lower($u['email'] ?? '') === $refLower; }

function routes_money1($uri, $m) {
    global $DB, $IN, $Q;
    if ($m === 'POST' && preg_match('#^(short|s)/click/(.+)$#', $uri, $mm)) {
        $slug = strtolower(trim(rawurldecode($mm[2])));
        $country = sstr($IN['country'] ?? '');
        $hdrCC = strtoupper(trim(hdr('cf-ipcountry') ?: hdr('x-country-code')));
        $cc = has($IN, 'countryCode') ? strtoupper(sstr($IN['countryCode'])) : '';
        if (preg_match('/^[A-Z]{2}$/', $hdrCC) && $hdrCC !== 'XX' && $hdrCC !== 'T1') { $country = ''; $cc = $hdrCC; }
        if ($country === '') { $iso = iso_map(); $country = isset($iso[$cc]) ? $iso[$cc][0] : ($cc !== '' ? "$cc Region" : 'Other Countries'); }
        $ip = secure_ip();
        if (!rl_hit('click:' . $ip, 90, 60)) fail(429, 'Too many requests. Please slow down.');
        $rates = is_array($DB['settings']['countryCpmRates'] ?? null) ? $DB['settings']['countryCpmRates'] : [];
        $matched = null; $mc = $country; $flag = '🌐';
        foreach ($rates as $cr) {
            $rc = sstr($cr['country'] ?? '');
            if ($rc !== '' && (strtolower($rc) === strtolower($country) || (strpos(strtolower($country), strtolower($rc)) !== false && strtolower($rc) !== 'all other countries'))) { $matched = $cr; $mc = $rc; $flag = $cr['flag'] ?? '🌐'; break; }
        }
        if (!$matched) foreach ($rates as $cr) if (strpos(lower($cr['country'] ?? ''), 'other') !== false) { $matched = $cr; $mc = $cr['country']; $flag = $cr['flag'] ?? '🌐'; break; }
        $payout = $matched ? r4(num($matched['rate']) / 1000) : (has($IN, 'payout') ? r4(num($IN['payout'])) : 0.008);
        $cd = trim("$flag $mc");
        $li = find_idx($DB['links'], function ($l) use ($slug) { return lower($l['slug'] ?? '') === $slug; });
        if ($li < 0) fail(404, 'Link not found');
        $link = &$DB['links'][$li];
        $v = evaluate_click($slug, $link);
        if (!$v['counted']) {
            log_fraud($slug, $v['reason'], $v['ip']); save_db();
            out(200, ['success' => true, 'counted' => false, 'earned' => 0, 'country' => $cd, 'clicks' => $link['clicks'], 'earnings' => $link['earnings'], 'originalUrl' => $link['originalUrl'] ?? '', 'publisherBal' => 0, 'referralCommission' => 0]);
        }
        $link['clicks'] = ival($link['clicks'] ?? 0) + 1; $link['earnings'] = r4(num($link['earnings'] ?? 0) + $payout);
        $pubBal = 0; $refComm = 0;
        if (!empty($link['userId']) && ($pi = find_user($link['userId'])) >= 0) {
            $pub = &$DB['users'][$pi];
            $pub['bal'] = r4(num($pub['bal'] ?? 0) + $payout); $pub['views'] = ival($pub['views'] ?? 0) + 1; $pubBal = $pub['bal'];
            $rb = lower(sstr($pub['referredBy'] ?? ''));
            if ($rb !== '') {
                $ri = find_idx($DB['users'], function ($u) use ($rb) { return user_matches_ref($u, $rb); });
                if ($ri >= 0) {
                    $ref = &$DB['users'][$ri]; $cnt = ival($ref['referralCount'] ?? 0);
                    $rate = num(has($DB['settings'], 'referralPercent') ? $DB['settings']['referralPercent'] : 15); if ($rate <= 0) $rate = 15;
                    if ($cnt >= 101) $rate = max($rate, 25); elseif ($cnt >= 51) $rate = max($rate, 22); elseif ($cnt >= 21) $rate = max($rate, 20); elseif ($cnt >= 6) $rate = max($rate, 18);
                    $refComm = r4($payout * ($rate / 100));
                    if ($refComm > 0) {
                        $ref['bal'] = r4(num($ref['bal'] ?? 0) + $refComm); $ref['referralEarnings'] = r4(num($ref['referralEarnings'] ?? 0) + $refComm);
                        array_unshift($DB['referralLogs'], ['id' => 'ref-log-' . round(microtime(true) * 1000) . '-' . hexs(2), 'referrerId' => $ref['id'], 'referredUserId' => $pub['id'], 'referredUserName' => $pub['name'] ?? ('Publisher #' . substr($pub['id'], -4)), 'linkSlug' => $slug, 'viewEarned' => $payout, 'commission' => $refComm, 'ratePercent' => $rate, 'timestamp' => stamp(), 'country' => $cd]);
                        $DB['referralLogs'] = array_slice($DB['referralLogs'], 0, 250);
                    }
                    unset($ref);
                }
            }
            unset($pub);
        }
        $ua = hdr('user-agent') ?: 'Unknown';
        $device = preg_match('/ipad|tablet|(android(?!.*mobile))/i', $ua) ? 'Tablet' : (preg_match('/mobi|iphone|android/i', $ua) ? 'Mobile' : 'Desktop');
        $os = 'Other'; foreach (['android' => 'Android', 'iphone|ipad|ipod' => 'iOS', 'windows' => 'Windows', 'macintosh|mac os x' => 'macOS', 'linux' => 'Linux'] as $re => $n) if (preg_match("/$re/i", $ua)) { $os = $n; break; }
        $br = 'Other'; foreach (['edg|edge' => 'Edge', 'opr|opera' => 'Opera', 'firefox' => 'Firefox', 'chrome|chromium' => 'Chrome', 'safari' => 'Safari'] as $re => $n) if (preg_match("/$re/i", $ua)) { $br = $n; break; }
        $rh = strtolower(preg_replace('/^www\./', '', (string)parse_url(hdr('referer'), PHP_URL_HOST)));
        if ($rh === '') $rn = 'Direct / Social App'; elseif (strpos($rh, 't.me') !== false || strpos($rh, 'telegram') !== false) $rn = 'Telegram'; elseif (strpos($rh, 'youtube') !== false) $rn = 'YouTube'; elseif (strpos($rh, 'facebook') !== false) $rn = 'Facebook'; elseif (strpos($rh, 'whatsapp') !== false) $rn = 'WhatsApp'; elseif (strpos($rh, 'twitter') !== false || strpos($rh, 'x.com') !== false) $rn = 'X'; else $rn = $rh;
        array_unshift($DB['visitLogs'], ['id' => 'vst-' . round(microtime(true) * 1000) . '-' . hexs(3), 'slug' => $slug, 'linkId' => $link['id'] ?? '', 'userId' => $link['userId'] ?? '', 'userEmail' => $link['userEmail'] ?? '', 'ip' => $ip, 'country' => $cd, 'earned' => $payout, 'timestamp' => stamp(), 'userAgent' => $ua, 'device' => $device, 'os' => $os, 'browser' => $br, 'referrer' => $rn]);
        $DB['visitLogs'] = array_slice($DB['visitLogs'], 0, 1000);
        save_db();
        out(200, ['success' => true, 'earned' => $payout, 'country' => $cd, 'clicks' => $link['clicks'], 'earnings' => $link['earnings'], 'originalUrl' => $link['originalUrl'] ?? '', 'publisherBal' => $pubBal, 'referralCommission' => $refComm]);
    }
    if ($uri === 'short/visit/' . substr($uri, 12) && $m === 'POST' && strpos($uri, 'short/visit/') === 0) {
        $ip = secure_ip();
        if (!rl_hit('visit:' . $ip, 60, 60)) fail(429, 'Too many requests.');
        $slug = strtolower(trim(rawurldecode(substr($uri, 12))));
        if (find_idx($DB['links'], function ($l) use ($slug) { return lower($l['slug'] ?? '') === $slug; }) < 0) fail(404, 'Link not found');
        out(200, ['success' => true, 'token' => make_visit_token($slug)]);
    }
    if ($uri === 'antibot/config' && $m === 'GET') out(200, ['success' => true, 'turnstileSiteKey' => env('TURNSTILE_SITE_KEY'), 'turnstileEnabled' => !!(env('TURNSTILE_SITE_KEY') && env('TURNSTILE_SECRET'))]);
    if ($uri === 'admin/fraud-logs' && $m === 'GET') {
        require_admin(); $by = [];
        foreach ($DB['fraudLogs'] as $l) $by[$l['reason']] = ($by[$l['reason']] ?? 0) + 1;
        out(200, ['success' => true, 'total' => count($DB['fraudLogs']), 'byReason' => (object)$by, 'logs' => array_slice($DB['fraudLogs'], 0, 100)]);
    }
    if ($uri === 'detect-ip' && $m === 'GET') {
        $ip = client_ip() ?: '103.255.4.19'; $cc = strtoupper(trim(hdr('cf-ipcountry') ?: hdr('x-country-code')));
        $lo = in_array($ip, ['127.0.0.1', '::1'], true);
        if (!$cc) $cc = $lo ? 'PK' : 'US';
        $iso = iso_map();
        out(200, ['ip' => $lo ? '103.255.4.19' : $ip, 'countryCode' => $cc, 'country' => isset($iso[$cc]) ? $iso[$cc][0] : "$cc Region", 'flag' => isset($iso[$cc]) ? $iso[$cc][1] : '🌐']);
    }
}
