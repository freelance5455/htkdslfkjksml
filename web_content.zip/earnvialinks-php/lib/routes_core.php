<?php
// Core endpoints part 1
const MASK = '••••••••';
function out_text($code, $t) { http_response_code($code); header('Content-Type: text/plain; charset=utf-8'); echo $t; exit; }
function new_session($userId) { $t = create_user_session($userId); save_db(); return $t; }
function count_referral(&$user) {
    global $DB;
    $rb = lower(sstr($user['referredBy'] ?? ''));
    if (!$rb || !empty($user['referralCounted'])) return;
    foreach ($DB['users'] as &$u) {
        if (($u['id'] ?? '') !== $user['id'] && (lower($u['id'] ?? '') === $rb || lower($u['referralCode'] ?? '') === $rb || lower($u['name'] ?? '') === $rb || lower($u['email'] ?? '') === $rb)) { $u['referralCount'] = ival($u['referralCount'] ?? 0) + 1; break; }
    }
    unset($u);
    $user['referralCounted'] = true;
}
function otp_response($user, $r) {
    $msg = !empty($r['emailSent']) ? "We sent a 6-digit verification code to {$user['email']}. Enter it to activate your account." : (!empty($r['limited']) ? 'Too many codes requested. Please try again in an hour.' : "We couldn't send the verification email right now. Please tap Resend in a minute, or contact mail@earnvialinks.com.");
    return ['success' => false, 'verificationRequired' => true, 'email' => $user['email'], 'emailSent' => !empty($r['emailSent']), 'message' => $msg];
}
function merge_settings($cur, $inc) {
    $o = array_replace($cur, $inc);
    foreach (['smtpConfig', 'databaseConfig'] as $k) if (is_array($inc[$k] ?? null)) {
        $old = is_array($cur[$k] ?? null) ? $cur[$k] : [];
        $o[$k] = array_replace($old, $inc[$k]);
        if (($inc[$k]['pass'] ?? null) === MASK) $o[$k]['pass'] = $old['pass'] ?? '';
    }
    $o['adminKey'] = $cur['adminKey'] ?? '';
    return $o;
}
function new_link($userId, $userEmail, $slug, $url, $alias) {
    $b = site_base();
    return ['id' => 'lnk-' . time() . 'p' . rnd(10, 99), 'userId' => $userId, 'userEmail' => $userEmail, 'slug' => $slug, 'originalUrl' => $url, 'shortUrl' => $b['host'] . '/s/' . $slug, 'fullUrl' => $b['proto'] . $b['host'] . '/s/' . $slug, 'clicks' => 0, 'earnings' => 0, 'status' => 'Active', 'createdAt' => today(), 'alias' => $alias ?: $slug];
}
function random_slug() {
    global $DB; $n = 0;
    do { $slug = (string)rnd(10000000, 99999999); $v = validate_slug($slug, $DB['links']); $n++; } while (!$v['isValid'] && $n < 50);
    return $slug;
}
function with_http($u) { return preg_match('#^https?://#i', $u) ? $u : 'https://' . $u; }

function routes_core($uri, $m) {
    global $DB, $IN, $Q;
    if ($uri === 'health' || $uri === 'status') {
        out(200, ['status' => 'online', 'platform' => 'earnvialinks (PHP Engine)', 'php_version' => PHP_VERSION, 'storage_engine' => 'JSON Flatfile (Atomic Writes + Auto-Backup)', 'atomic_writes' => true, 'backup_enabled' => true, 'backup_present' => is_file(DATA_DIR . '/database.backup.json'), 'database_file' => 'data/database.json', 'timestamp' => iso_now()]);
    }
    if ($uri === 'settings' && $m === 'GET') {
        $s = $DB['settings']; unset($s['adminKey']);
        if (is_array($s['smtpConfig'] ?? null)) $s['smtpConfig']['pass'] = !empty($s['smtpConfig']['pass']) ? MASK : '';
        if (is_array($s['databaseConfig'] ?? null)) $s['databaseConfig']['pass'] = !empty($s['databaseConfig']['pass']) ? MASK : '';
        out(200, ['success' => true, 'settings' => $s]);
    }
    if ($uri === 'admin/settings' && $m === 'POST') {
        require_admin();
        if (is_array($IN['settings'] ?? null)) { $DB['settings'] = merge_settings($DB['settings'], $IN['settings']); save_db(); }
        out(200, ['success' => true, 'message' => 'Platform settings updated successfully', 'settings' => $DB['settings']]);
    }
    if ($uri === 'admin/cpm-rates' && $m === 'POST') {
        require_admin();
        if (is_array($IN['rates'] ?? null) && count($IN['rates']) > 0) { $DB['settings']['countryCpmRates'] = array_values($IN['rates']); save_db(); }
        out(200, ['success' => true, 'message' => 'Publisher CPM rates updated successfully', 'rates' => $DB['settings']['countryCpmRates']]);
    }
    if ($uri === 'short/create' && $m === 'POST') {
        $url = sstr($IN['url'] ?? '');
        $alias = has($IN, 'customAlias') ? sstr($IN['customAlias']) : sstr($IN['alias'] ?? '');
        $userId = has($IN, 'userId') ? sstr($IN['userId']) : 'guest'; $email = sstr($IN['userEmail'] ?? '');
        if (!$url) out(400, ['success' => false, 'error' => 'Valid destination URL is required']);
        $url = with_http($url); $slug = $alias;
        if ($slug) { $v = validate_slug($slug, $DB['links']); if (!$v['isValid']) out($v['code'] === 'TAKEN' ? 409 : 400, ['success' => false, 'error' => $v['error'], 'code' => $v['code']]); }
        else $slug = random_slug();
        $link = new_link($userId, $email, $slug, $url, $alias);
        array_unshift($DB['links'], $link);
        if ($userId !== 'guest' && ($i = find_user($userId)) >= 0) $DB['users'][$i]['linksCount'] = ($DB['users'][$i]['linksCount'] ?? 0) + 1;
        save_db(); out(200, ['success' => true, 'link' => $link]);
    }
    if ($uri === 'short/bulk' && $m === 'POST') {
        $urls = $IN['urls'] ?? null; $prefix = sstr($IN['prefix'] ?? ''); $userId = sstr($IN['userId'] ?? '') ?: 'guest'; $email = sstr($IN['userEmail'] ?? '');
        if (!is_array($urls) || !$urls) out(400, ['success' => false, 'error' => 'Array of URLs is required']);
        $raw = [];
        foreach ($urls as $u) { $c = sstr($u); if ($c !== '' && $c[0] !== '#') $raw[] = $c; }
        if (!$raw) out(400, ['success' => false, 'error' => 'No valid URLs provided in batch']);
        $lim = min(count($raw), 50);
        $pre = $prefix ? preg_replace('/[^a-z0-9_-]/', '', strtolower($prefix)) : '';
        if ($pre) { $v = validate_slug($pre, []); if (!$v['isValid'] && in_array($v['code'], ['BANNED', 'RESERVED'], true)) out(400, ['success' => false, 'error' => $v['error'], 'code' => $v['code']]); }
        $b = site_base(); $created = [];
        for ($i = 0; $i < $lim; $i++) {
            $slug = $pre ? "$pre-" . ($i + 1) . '-' . substr(hexs(2), 0, 3) : substr(hexs(4), 0, 6);
            for ($n = 0; $n < 20; $n++) { if (find_idx($DB['links'], function ($l) use ($slug) { return lower($l['slug'] ?? '') === lower($slug); }) < 0) break; $slug = substr(hexs(4), 0, 6); }
            $link = ['id' => 'lnk-' . time() . "-$i-" . substr(hexs(2), 0, 4), 'userId' => $userId, 'userEmail' => $email, 'slug' => $slug, 'originalUrl' => with_http($raw[$i]), 'shortUrl' => $b['host'] . '/s/' . $slug, 'fullUrl' => $b['proto'] . $b['host'] . '/s/' . $slug, 'clicks' => 0, 'earnings' => 0, 'status' => 'Active', 'alias' => $pre ? "$pre-" . ($i + 1) : null, 'createdAt' => today()];
            array_unshift($DB['links'], $link); $created[] = $link;
        }
        save_db(); out(200, ['success' => true, 'count' => count($created), 'links' => $created]);
    }
    if (in_array($uri, ['', 'api', 'api.php', 'quick'], true) && $m === 'GET' && isset($Q['api']) && isset($Q['url'])) {
        $apiKey = sstr($Q['api']); $url = sstr($Q['url']);
        $alias = isset($Q['alias']) ? preg_replace('/[^a-z0-9_-]/', '', strtolower(sstr($Q['alias']))) : '';
        $format = isset($Q['format']) ? strtolower(sstr($Q['format'])) : 'json'; $redirect = ($Q['redirect'] ?? '') === '1';
        $err = function ($st, $msg, $code = null) use ($format) { if ($format === 'text') out_text($st, 'Error: ' . $msg); $b = ['status' => 'error', 'message' => $msg]; if ($code) $b['code'] = $code; out($st, $b); };
        if (!$url) $err(400, 'Destination URL is required');
        $url = with_http($url);
        if (!rl_hit('devapi:' . secure_ip(), 120, 60)) $err(429, 'Too many requests. Slow down.');
        $ui = $apiKey ? find_idx($DB['users'], function ($u) use ($apiKey) { return !empty($u['apiKey']) && hash_equals($u['apiKey'], $apiKey); }) : -1;
        if ($ui < 0) $err(403, 'Invalid API key. Check your API key in Publisher Dashboard -> Tools.');
        $user = $DB['users'][$ui];
        if ($alias) { $v = validate_slug($alias, $DB['links']); if (!$v['isValid']) $err($v['code'] === 'TAKEN' ? 409 : 400, $v['error'], $v['code']); }
        $slug = $alias ?: random_slug();
        $link = new_link($user['id'], $user['email'] ?? '', $slug, $url, $alias);
        array_unshift($DB['links'], $link); save_db();
        if ($redirect) { header('Location: ' . $link['fullUrl'], true, 302); exit; }
        if ($format === 'text') out_text(200, $link['fullUrl']);
        out(200, ['status' => 'success', 'shortenedUrl' => $link['fullUrl'], 'shortUrl' => $link['shortUrl'], 'slug' => $link['slug'], 'originalUrl' => $link['originalUrl']]);
    }
    if (in_array($uri, ['database/config', 'database/test-mysql'], true) && $m === 'POST') {
        require_admin();
        out(200, ['success' => true, 'message' => 'Primary database is fully operational with atomic writes and automated rotating backups.', 'storage' => ['engine' => 'JSON Flatfile (PHP, atomic writes)', 'database_file' => 'data/database.json', 'backup_file' => 'data/database.backup.json', 'backup_exists' => is_file(DATA_DIR . '/database.backup.json'), 'database_size' => is_file(DB_FILE) ? filesize(DB_FILE) : 0, 'total_users' => count($DB['users']), 'total_links' => count($DB['links']), 'total_withdrawals' => count($DB['withdrawals']), 'atomic_writes' => true, 'locking' => 'flock']]);
    }
    if ($uri === 'email/save-smtp' && $m === 'POST') {
        require_admin();
        if (is_array($IN['smtpConfig'] ?? null)) {
            $cur = $DB['settings']['smtpConfig'] ?? []; $mg = array_replace($cur, $IN['smtpConfig']);
            if (($IN['smtpConfig']['pass'] ?? null) === MASK) $mg['pass'] = $cur['pass'] ?? '';
            $DB['settings']['smtpConfig'] = $mg; save_db();
        }
        out(200, ['success' => true, 'message' => 'SMTP settings saved successfully.']);
    }
    if ($uri === 'auth/test-smtp' && $m === 'POST') {
        require_admin();
        $to = sstr($IN['testEmail'] ?? '');
        if (!$to) fail(400, 'Recipient email is required.');
        if (is_array($IN['smtpConfig'] ?? null)) {
            $cur = $DB['settings']['smtpConfig'] ?? []; $mg = array_replace($cur, $IN['smtpConfig']);
            if (($IN['smtpConfig']['pass'] ?? null) === MASK) $mg['pass'] = $cur['pass'] ?? '';
            $DB['settings']['smtpConfig'] = $mg; save_db();
        }
        $res = send_email($to, 'Mail Server Connectivity Test', '<div style="font-family:Arial;padding:20px"><h2>SMTP works!</h2><p>Your EarnViaLinks mail server is configured correctly.</p></div>', 'test', null);
        out(200, ['success' => true, 'message' => $res['simulated'] ? 'Test email was NOT delivered (' . ($res['error'] ?: 'simulated') . '). Check SMTP settings.' : 'Test message sent to ' . $to, 'simulated' => $res['simulated']]);
    }
    if ($uri === 'email/logs' && $m === 'GET') { require_admin(); out(200, ['success' => true, 'logs' => $DB['emailLogs']]); }
}
