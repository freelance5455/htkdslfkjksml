<?php
// Money part 2: referrals, user profile, admin users
function looks_hashed($s) { return strlen($s) >= 30 && strpos($s, '$2') === 0; }
function ref_links($code) { $b = site_base()['origin']; $e = rawurlencode($code); return ['referralLink' => "$b/?ref=$e", 'cleanPathLink' => "$b/ref/$e", 'registerLink' => "$b/?ref=$e&action=register"]; }
function routes_money2($uri, $m) {
    global $DB, $IN, $Q;
    if ($uri === 'referrals/stats' && $m === 'GET') {
        $userId = sstr($Q['userId'] ?? '');
        if (!$userId) fail(400, 'User ID is required');
        require_user($userId); $key = strtolower($userId);
        $ui = find_idx($DB['users'], function ($u) use ($userId, $key) { return ($u['id'] ?? '') === $userId || (!empty($u['referralCode']) && lower($u['referralCode']) === $key) || (!empty($u['email']) && lower($u['email']) === $key); });
        if ($ui < 0) fail(404, 'User not found');
        $user = $DB['users'][$ui]; $code = !empty($user['referralCode']) ? $user['referralCode'] : $user['id']; $referred = [];
        foreach ($DB['users'] as $u) {
            if (empty($u['referredBy'])) continue;
            $r = lower(sstr($u['referredBy']));
            if ($r === lower($user['id']) || (!empty($user['referralCode']) && $r === lower($user['referralCode'])) || (!empty($user['name']) && $r === lower($user['name'])) || (!empty($user['email']) && $r === lower($user['email'])))
                $referred[] = ['id' => $u['id'], 'name' => !empty($u['name']) ? substr($u['name'], 0, 3) . '***' : 'Publisher #' . substr($u['id'], -4), 'country' => $u['country'] ?? 'Global', 'views' => ival($u['views'] ?? 0), 'bal' => num($u['bal'] ?? 0), 'joinedDate' => $u['joinedDate'] ?? today(), 'status' => $u['status'] ?? 'Active'];
        }
        $total = max(ival($user['referralCount'] ?? 0), count($referred)); $td = calc_ref_tier($total);
        $rate = max(ival($td['activeTier']['commissionPercent']), ival(has($DB['settings'], 'referralPercent') ? $DB['settings']['referralPercent'] : 15));
        $sum = 0; foreach ($referred as &$r) { $r['commission'] = r4($r['bal'] * ($rate / 100)); $sum += $r['commission']; } unset($r);
        $te = num($user['referralEarnings'] ?? 0) > 0 ? num($user['referralEarnings']) : r4($sum);
        $recent = []; foreach ($DB['referralLogs'] as $l) if (($l['referrerId'] ?? '') === $user['id']) { $recent[] = $l; if (count($recent) >= 30) break; }
        out(200, array_merge(['success' => true, 'referralCode' => $code, 'hasCustomCode' => !empty($user['referralCode'])], ref_links($code), ['referralPercent' => $rate, 'activeTier' => $td['activeTier'], 'nextTier' => $td['nextTier'], 'referralsToNext' => $td['referralsToNext'], 'allTiers' => referral_tiers(), 'claimedTiers' => $user['claimedReferralTiers'] ?? [], 'totalReferrals' => $total, 'totalEarnings' => $te, 'referredUsers' => $referred, 'recentCommissions' => $recent]));
    }
    if ($uri === 'referrals/claim-tier-bonus' && $m === 'POST') {
        $userId = sstr($IN['userId'] ?? ''); $tierId = has($IN, 'tierId') ? sstr($IN['tierId']) : sstr($IN['milestoneTierId'] ?? '');
        if (!$userId || !$tierId) fail(400, 'User ID and Milestone Tier ID are required.');
        require_user($userId); $ui = find_user($userId);
        if ($ui < 0) fail(404, 'User not found.');
        $u = &$DB['users'][$ui]; $tier = null; foreach (referral_tiers() as $t) if ($t['id'] === $tierId) $tier = $t;
        if (!$tier || $tier['bonusReward'] <= 0) fail(400, 'Invalid milestone tier.');
        $rc = ival($u['referralCount'] ?? 0);
        if ($rc < $tier['minReferrals']) fail(400, "Milestone locked: You need at least {$tier['minReferrals']} active referrals to unlock {$tier['name']}. You currently have $rc.");
        $cl = is_array($u['claimedReferralTiers'] ?? null) ? $u['claimedReferralTiers'] : [];
        if (in_array($tierId, $cl, true)) fail(400, "You have already claimed the {$tier['name']} bonus.");
        $b = num($tier['bonusReward']); $u['bal'] = r4(num($u['bal'] ?? 0) + $b); $u['balance'] = $u['bal']; $u['claimedReferralTiers'] = array_merge($cl, [$tierId]); save_db();
        out(200, ['success' => true, 'message' => "🎉 Success! $" . money($b) . " {$tier['name']} milestone cash bonus credited to your balance!", 'bonusAwarded' => $b, 'newBalance' => $u['bal'], 'claimedTiers' => $u['claimedReferralTiers']]);
    }
    if ($uri === 'user/regenerate-api-key' && $m === 'POST') {
        $userId = sstr($IN['userId'] ?? ''); if (!$userId) fail(400, 'User ID is required');
        require_user($userId); $ui = find_user($userId); if ($ui < 0) fail(404, 'User not found');
        $k = 'el_live_' . hexs(16); $DB['users'][$ui]['apiKey'] = $k; save_db();
        out(200, ['success' => true, 'apiKey' => $k, 'message' => 'New API Key generated successfully.']);
    }
    if ($uri === 'user/set-referral-code' && $m === 'POST') {
        $userId = sstr($IN['userId'] ?? ''); $c = sstr(has($IN, 'customCode') ? $IN['customCode'] : (has($IN, 'referralHandle') ? $IN['referralHandle'] : ($IN['handle'] ?? '')));
        if (!$userId || !$c) fail(400, 'User ID and custom handle are required.');
        require_user($userId);
        if (!preg_match('/^[a-zA-Z0-9_-]{3,20}$/', $c)) fail(400, 'Referral handle must be 3-20 characters long and contain only letters, numbers, hyphens, or underscores.');
        $ui = find_user($userId); if ($ui < 0) fail(404, 'User not found.');
        foreach ($DB['users'] as $u) if (($u['id'] ?? '') !== $userId && ((!empty($u['referralCode']) && lower($u['referralCode']) === lower($c)) || lower($u['id'] ?? '') === lower($c))) fail(409, "The referral handle \"$c\" is already in use by another publisher. Please select another.");
        $DB['users'][$ui]['referralCode'] = $c; save_db();
        out(200, array_merge(['success' => true, 'referralCode' => $c], ref_links($c), ['message' => 'Custom referral handle saved successfully!']));
    }
    if ($uri === 'user/analytics' && $m === 'GET') {
        $k = sstr(hdr('x-api-key')); if ($k === '') fail(401, 'Publisher API key is required.');
        $pi = find_idx($DB['users'], function ($c) use ($k) { return !empty($c['apiKey']) && hash_equals($c['apiKey'], $k); });
        if ($pi < 0) fail(403, 'Invalid publisher API key.');
        $pid = (string)$DB['users'][$pi]['id'];
        $links = array_values(array_filter($DB['links'], function ($l) use ($pid) { return ($l['userId'] ?? '') === $pid; }));
        $owned = array_map(function ($l) { return lower($l['slug'] ?? ''); }, $links); $vl = [];
        foreach ($DB['visitLogs'] as $g) if (($g['userId'] ?? '') === $pid || in_array(lower($g['slug'] ?? ''), $owned, true)) { unset($g['ip'], $g['userEmail'], $g['userAgent']); $vl[] = $g; }
        out(200, ['success' => true, 'links' => $links, 'visitLogs' => $vl, 'referralLogs' => array_values(array_filter($DB['referralLogs'], function ($l) use ($pid) { return ($l['referrerId'] ?? '') === $pid; }))]);
    }
    if ($uri === 'user/me' && $m === 'GET') {
        $userId = sstr($Q['userId'] ?? ''); if (!$userId) fail(400, 'User ID is required.');
        require_user($userId); $ui = find_user($userId); if ($ui < 0) fail(404, 'User not found.');
        if (empty($DB['users'][$ui]['apiKey'])) { $DB['users'][$ui]['apiKey'] = 'el_live_' . hexs(16); save_db(); }
        $bal = withdrawable_balance($userId); $user = without_pw($DB['users'][$ui]); $user['bal'] = $bal; $user['balance'] = $bal;
        $e = 0; $v = 0; foreach ($DB['links'] as $l) if (($l['userId'] ?? '') === $userId) { $e += num($l['earnings'] ?? 0); $v += ival($l['clicks'] ?? 0); }
        $user['ecpm'] = $v > 0 ? r4(($e / $v) * 1000) : 0; $user['ecpmViews'] = $v;
        out(200, ['success' => true, 'user' => $user, 'serverBalance' => $bal]);
    }
    if ($uri === 'admin/users/add' && $m === 'POST') {
        require_admin(); $nu = is_array($IN['user'] ?? null) ? $IN['user'] : $IN; $email = strtolower(sstr($nu['email'] ?? '')); $name = sstr($nu['name'] ?? '');
        if (!$email || !$name) fail(400, 'User name and email are required.');
        if (find_idx($DB['users'], function ($u) use ($email) { return lower($u['email'] ?? '') === $email; }) >= 0) fail(409, 'A user with this email address already exists.');
        $raw = sstr($nu['password'] ?? '') ?: 'pass' . hexs(4); $bal = has($nu, 'bal') ? num($nu['bal']) : (has($nu, 'balance') ? num($nu['balance']) : 2.0);
        $rec = ['id' => sstr($nu['id'] ?? '') ?: 'usr-' . time() . '_' . hexs(3), 'name' => $name, 'email' => $email, 'password' => looks_hashed($raw) ? $raw : hash_pw($raw), 'country' => $nu['country'] ?? 'United States', 'bal' => $bal, 'balance' => $bal, 'adminAdjustment' => $bal - 2.0, 'views' => has($nu, 'views') ? ival($nu['views']) : 0, 'status' => $nu['status'] ?? 'Active', 'role' => $nu['role'] ?? 'publisher', 'paymentMethod' => $nu['paymentMethod'] ?? 'PayPal', 'paymentDetails' => $nu['paymentDetails'] ?? '', 'joinedDate' => $nu['joinedDate'] ?? today(), 'createdAt' => iso_now(), 'apiKey' => 'el_live_' . hexs(16), 'streakDay' => 1, 'lastClaimDate' => null, 'claimedStreakDays' => [], 'referredBy' => $nu['referredBy'] ?? null, 'referralEarnings' => 0, 'referralCount' => 0, 'loyaltyClaimed' => []];
        array_unshift($DB['users'], $rec); save_db(); out(200, ['success' => true, 'user' => without_pw($rec), 'message' => 'User account created successfully.']);
    }
    if ($uri === 'admin/users/update' && $m === 'POST') {
        require_admin(); $d = is_array($IN['user'] ?? null) ? $IN['user'] : $IN; $id = sstr($d['id'] ?? '');
        if (!$id) fail(400, 'User ID is required.');
        $ui = find_user($id); if ($ui < 0) fail(404, 'User not found.');
        $u = &$DB['users'][$ui];
        foreach (['name', 'country', 'status', 'role', 'paymentMethod', 'paymentDetails'] as $k) if (has($d, $k)) $u[$k] = sstr($d[$k]);
        if (has($d, 'email')) $u['email'] = strtolower(sstr($d['email']));
        if (has($d, 'views')) $u['views'] = ival($d['views']);
        if (sstr($d['password'] ?? '')) { $raw = sstr($d['password']); if ($raw !== ($u['password'] ?? '')) $u['password'] = looks_hashed($raw) ? $raw : hash_pw($raw); }
        if (has($d, 'bal') || has($d, 'balance')) {
            $nb = has($d, 'bal') ? num($d['bal']) : num($d['balance']); $u['bal'] = $nb; $u['balance'] = $nb; $le = 0;
            foreach ($DB['links'] as $l) if (($l['userId'] ?? '') === $id) $le += num($l['earnings'] ?? 0);
            $st = 0; $rw = streak_rewards(); foreach ($u['claimedStreakDays'] ?? [] as $dd) if (isset($rw[ival($dd) - 1])) $st += num($rw[ival($dd) - 1]);
            $lt = 0; $tiers = is_array($DB['settings']['loyaltyTiers'] ?? null) ? $DB['settings']['loyaltyTiers'] : [];
            foreach ($u['loyaltyClaimed'] ?? [] as $tid) foreach ($tiers as $t) if (($t['id'] ?? '') === $tid) $lt += num($t['rewardAmount']);
            $wd = 0; foreach ($DB['withdrawals'] as $w) if (($w['userId'] ?? '') === $id && in_array($w['status'] ?? '', ['Pending', 'Completed', 'Approved'], true)) $wd += num($w['amount'] ?? 0);
            $u['adminAdjustment'] = r4($nb - (2.0 + $le + $st + $lt + num($u['referralEarnings'] ?? 0) + num($u['earnPtc'] ?? 0) + num($u['earnOffers'] ?? 0) - $wd));
        }
        save_db(); out(200, ['success' => true, 'user' => without_pw($u), 'message' => 'User updated successfully.']);
    }
}
