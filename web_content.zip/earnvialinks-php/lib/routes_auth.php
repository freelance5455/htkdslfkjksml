<?php
// Core endpoints part 2: database admin + auth
function routes_auth($uri, $m) {
    global $DB, $IN, $Q;
    if ($uri === 'admin/export' && $m === 'GET') {
        require_admin();
        $d = $DB;
        foreach (['adminSessions', 'userSessions', 'securitySecret', 'emailVerifications', 'passwordResets'] as $k) unset($d[$k]);
        unset($d['settings']['adminKey']);
        foreach (['smtpConfig', 'databaseConfig'] as $k) if (!empty($d['settings'][$k]['pass'])) $d['settings'][$k]['pass'] = MASK;
        $d['_meta'] = ['app' => 'earnvialinks', 'format' => 1, 'exportedAt' => iso_now(), 'counts' => ['users' => count($d['users']), 'links' => count($d['links']), 'withdrawals' => count($d['withdrawals'])]];
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="earnvialinks-database-' . today() . '.json"');
        echo json_encode($d, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); exit;
    }
    if ($uri === 'admin/restore' && $m === 'POST') {
        require_admin();
        $src = (is_array($IN['data'] ?? null) && is_array($IN['data']['users'] ?? null)) ? $IN['data'] : $IN;
        if (!is_array($src['users'] ?? null)) fail(400, 'Invalid backup file: "users" list not found. Upload the JSON you downloaded from Export Database JSON.');
        $bad = array_filter($src['users'], function ($u) { return !is_array($u) || !sstr($u['id'] ?? '') || !sstr($u['email'] ?? ''); });
        if ($bad) fail(400, 'Invalid backup file: ' . count($bad) . ' user record(s) have no id/email. Nothing was changed.');
        foreach (['links', 'withdrawals', 'visitLogs', 'referralLogs', 'emailLogs'] as $k) if (isset($src[$k]) && !is_array($src[$k])) fail(400, "Invalid backup file: \"$k\" must be a list. Nothing was changed.");
        if (is_file(DB_FILE) && filesize(DB_FILE) > 0) @copy(DB_FILE, DATA_DIR . '/database.pre-restore-' . time() . '.json');
        $next = $src;
        foreach (['_meta', 'adminSessions', 'userSessions', 'securitySecret'] as $k) unset($next[$k]);
        $next['settings'] = merge_settings($DB['settings'], is_array($src['settings'] ?? null) ? $src['settings'] : []);
        if (($src['settings']['paymentGatewaysVersion'] ?? 0) !== 2) unset($next['settings']['paymentGatewaysVersion']);
        $next['adminSessions'] = $DB['adminSessions']; $next['userSessions'] = $DB['userSessions'];
        if (!empty($DB['securitySecret'])) $next['securitySecret'] = $DB['securitySecret'];
        $next['passwordResets'] = []; $next['emailVerifications'] = $DB['emailVerifications'];
        $next['site'] = $DB['site'] ?? []; if (empty($next['earn']['cpalead']) && !empty($DB['earn']['cpalead'])) $next['earn']['cpalead'] = $DB['earn']['cpalead'];
        $DB = normalize_db($next);
        save_db(true);
        $c = ['users' => count($DB['users']), 'links' => count($DB['links']), 'withdrawals' => count($DB['withdrawals'])];
        out(200, ['success' => true, 'message' => "Database restored: {$c['users']} users, {$c['links']} links, {$c['withdrawals']} withdrawals.", 'counts' => $c]);
    }
    if ($uri === 'database' && $m === 'GET') {
        require_admin(); $d = $DB; foreach (['adminSessions', 'userSessions', 'securitySecret'] as $k) unset($d[$k]);
        out(200, ['success' => true, 'data' => $d]);
    }
    if (in_array($uri, ['database/save', 'database/sync'], true) && $m === 'POST') {
        require_admin();
        if (is_array($IN['users'] ?? null)) {
            $keep = []; foreach ($DB['users'] as $u) $keep[$u['id'] ?? ''] = $u;
            $DB['users'] = array_map(function ($u) use ($keep) {
                $cur = is_array($u) ? ($keep[$u['id'] ?? ''] ?? null) : null;
                if (!$cur) return $u;
                foreach (['streakDay', 'lastClaimDate', 'lastClaimAt', 'claimedStreakDays', 'loyaltyClaimed', 'emailVerified', 'emailVerifiedAt'] as $k) { if (array_key_exists($k, $cur)) $u[$k] = $cur[$k]; else unset($u[$k]); }
                return $u;
            }, $IN['users']);
        }
        foreach (['links', 'withdrawals', 'visitLogs'] as $k) if (isset($IN[$k])) $DB[$k] = $IN[$k];
        if (is_array($IN['settings'] ?? null)) $DB['settings'] = merge_settings($DB['settings'], $IN['settings']);
        save_db(true); out(200, ['success' => true, 'message' => 'Database state synchronized.']);
    }
    if ($uri === 'database/reset' && $m === 'POST') {
        require_admin(); $DB = normalize_db(initial_db()); save_db(true);
        out(200, ['success' => true, 'message' => 'Database reset to clean factory defaults', 'data' => $DB]);
    }
    if ($uri === 'auth/register' && $m === 'POST') {
        $name = sstr($IN['name'] ?? ''); $email = strtolower(sstr($IN['email'] ?? '')); $pw = sstr($IN['password'] ?? '');
        $country = has($IN, 'country') ? sstr($IN['country']) : 'Global'; $pm = has($IN, 'paymentMethod') ? sstr($IN['paymentMethod']) : 'PayPal';
        $pd = sstr($IN['paymentDetails'] ?? ''); $ref = sstr($IN['referredBy'] ?? '');
        if (!rl_hit('reg:' . secure_ip(), 8, 3600)) fail(429, 'Too many sign-ups from this network. Please try again later.');
        if (strlen($name) > 80 || strlen($email) > 120 || strlen($pw) > 200 || !preg_match('/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/', $email)) fail(400, 'Please enter a valid name, email and password.');
        if (!$name || !$email || !$pw) fail(400, 'Name, email, and password are required.');
        if (strlen($pw) < 6) fail(400, 'Password must be at least 6 characters long.');
        $ei = find_idx($DB['users'], function ($u) use ($email) { return lower($u['email'] ?? '') === $email; });
        if ($ei >= 0 && ($DB['users'][$ei]['emailVerified'] ?? null) !== false) fail(409, 'An account with this email already exists. Please log in.');
        if ($ei >= 0) {
            $e = &$DB['users'][$ei];
            $e = array_replace($e, ['name' => $name, 'password' => hash_pw($pw), 'country' => $country, 'paymentMethod' => $pm ?: 'PayPal', 'paymentDetails' => $pd, 'referredBy' => $ref ?: ($e['referredBy'] ?? null)]);
            save_db(); $r = issue_otp($e, false); out(200, otp_response($e, $r));
        }
        $bonus = num(has($DB['settings'], 'signupBonus') ? $DB['settings']['signupBonus'] : 2.0); $verify = otp_enabled();
        $user = ['id' => 'usr-' . time() . rnd(100, 999), 'name' => $name, 'email' => $email, 'password' => hash_pw($pw), 'country' => $country, 'bal' => $bonus, 'balance' => $bonus, 'views' => 0, 'status' => 'Active', 'role' => 'publisher', 'paymentMethod' => $pm ?: 'PayPal', 'paymentDetails' => $pd, 'streakDay' => 1, 'lastClaimDate' => null, 'claimedStreakDays' => [], 'joinedDate' => today(), 'createdAt' => iso_now(), 'referredBy' => $ref ?: null, 'referralEarnings' => 0, 'referralCount' => 0, 'emailVerified' => !$verify, 'apiKey' => 'el_live_' . hexs(16)];
        remember_ip($user);
        if (!$verify) { $user['emailVerifiedAt'] = iso_now(); count_referral($user); }
        array_unshift($DB['users'], $user); save_db();
        if (!$verify) out(200, ['success' => true, 'user' => without_pw($user), 'userToken' => new_session($user['id'])]);
        $r = issue_otp($user, true); out(200, otp_response($user, $r));
    }
    if ($uri === 'auth/verify-email' && $m === 'POST') {
        $email = strtolower(sstr($IN['email'] ?? '')); $code = sstr($IN['code'] ?? '');
        if (!rl_hit('vfy:' . secure_ip(), 40, 900)) fail(429, 'Too many attempts. Please wait a few minutes.');
        if (!$email || !preg_match('/^\d{6}$/', $code)) fail(400, 'Please enter the 6-digit code from your email.');
        $ui = find_idx($DB['users'], function ($u) use ($email) { return lower($u['email'] ?? '') === $email; });
        if ($ui < 0 || ($DB['users'][$ui]['emailVerified'] ?? null) !== false) fail(400, 'This email is not waiting for verification. Please log in.');
        $res = check_otp($email, $code);
        if (!$res['ok']) fail($res['status'], $res['message']);
        $u = &$DB['users'][$ui]; $u['emailVerified'] = true; $u['emailVerifiedAt'] = iso_now(); count_referral($u); remember_ip($u);
        $tok = create_user_session($u['id']); save_db();
        $o = without_pw($u); $o['bal'] = num($o['bal'] ?? ($o['balance'] ?? 0)); $o['balance'] = $o['bal'];
        out(200, ['success' => true, 'message' => 'Email verified successfully!', 'user' => $o, 'userToken' => $tok]);
    }
    if ($uri === 'auth/resend-verification' && $m === 'POST') {
        $email = strtolower(sstr($IN['email'] ?? ''));
        if (!$email) fail(400, 'Email is required.');
        $ui = find_idx($DB['users'], function ($u) use ($email) { return lower($u['email'] ?? '') === $email; });
        $generic = ['success' => true, 'message' => 'If this email is waiting for verification, a new code has been sent.'];
        if ($ui < 0 || ($DB['users'][$ui]['emailVerified'] ?? null) !== false) out(200, $generic);
        $r = issue_otp($DB['users'][$ui]);
        if (!empty($r['throttled'])) fail(429, "Please wait {$r['wait']}s before requesting another code.", ['wait' => $r['wait']]);
        if (!empty($r['limited'])) fail(429, 'Too many codes requested. Please try again in an hour.');
        if (empty($r['emailSent'])) out(200, ['success' => false, 'message' => "We couldn't send the verification email right now. Please tap Resend in a minute, or contact mail@earnvialinks.com."]);
        out(200, $generic);
    }
    if ($uri === 'auth/login' && $m === 'POST') {
        $email = strtolower(sstr($IN['email'] ?? '')); $pw = sstr($IN['password'] ?? '');
        if (!$email || !$pw) fail(400, 'Email and password are required.');
        $ipK = 'login-ip:' . secure_ip(); $emK = 'login-em:' . $email;
        if (rl_blocked($emK, 8) || !rl_hit($ipK, 40, 900)) fail(429, 'Too many login attempts. Please wait 15 minutes and try again.');
        $ui = find_idx($DB['users'], function ($u) use ($email) { return lower($u['email'] ?? '') === $email; });
        if ($ui >= 0) {
            $u = &$DB['users'][$ui];
            list($ok, $rehash) = verify_pw($pw, $u['password'] ?? '');
            if ($ok) {
                if (($u['status'] ?? '') === 'Banned') fail(403, 'This account has been permanently banned due to policy violations.');
                if (($u['status'] ?? '') === 'Suspended') fail(403, 'Account suspended by administrator. Please contact support.');
                if ($rehash) { $u['password'] = hash_pw($pw); save_db(); }
                if (($u['emailVerified'] ?? null) === false && otp_enabled()) { $r = issue_otp($u); out(200, otp_response($u, !empty($r['throttled']) ? ['emailSent' => true] : $r)); }
                rl_clear($emK); remember_ip($u); $tok = create_user_session($u['id']); save_db();
                $a = without_pw($u); $a['bal'] = num($a['bal'] ?? ($a['balance'] ?? 0)); $a['balance'] = $a['bal']; $a['views'] = ival($a['views'] ?? 0);
                out(200, ['success' => true, 'user' => $a, 'userToken' => $tok]);
            }
        }
        rl_hit($emK, 8, 900); fail(401, 'Invalid email or password.');
    }
    if ($uri === 'auth/admin-setup-status' && $m === 'GET') { $h = has_admin_key(); out(200, ['success' => true, 'setupRequired' => !$h, 'hasAdminKey' => $h]); }
    if ($uri === 'auth/admin-setup' && $m === 'POST') {
        if (has_admin_key()) fail(400, 'Administrative passkey has already been established. Please log in.');
        $p = sstr($IN['passkey'] ?? ''); $c = sstr($IN['confirmPasskey'] ?? '');
        if (strlen($p) < 8) fail(400, 'Administrative passkey must be at least 8 characters long.');
        if ($c !== '' && $p !== $c) fail(400, 'Passkey confirmation does not match.');
        $DB['settings']['adminKey'] = $p; list($t, $exp) = create_admin_session(); save_db(true);
        out(200, ['success' => true, 'token' => $t, 'expiresAt' => $exp * 1000, 'message' => 'Master administrative passkey configured successfully. Welcome to your Admin Console.']);
    }
    if ($uri === 'auth/admin-login' && $m === 'POST') {
        $p = has($IN, 'passkey') ? sstr($IN['passkey']) : sstr($IN['password'] ?? ''); $k = 'admin-login:' . secure_ip();
        if (rl_blocked($k, 6)) fail(429, 'Too many failed attempts. Admin login is locked for 15 minutes.');
        $exp = admin_key();
        if (!$exp) out(400, ['success' => false, 'setupRequired' => true, 'message' => 'First-run setup required: Please configure your master admin passkey before logging in.']);
        if ($p && hash_equals($exp, $p)) { rl_clear($k); list($t, $e) = create_admin_session(); save_db(); out(200, ['success' => true, 'token' => $t, 'expiresAt' => $e * 1000, 'message' => 'Admin credentials authenticated successfully.']); }
        rl_hit($k, 6, 900); usleep(350000); fail(401, 'Access Denied: Invalid Administrative Passkey.');
    }
    if ($uri === 'auth/verify-admin-session') {
        if (is_admin_session(admin_token())) out(200, ['success' => true, 'valid' => true]);
        out(401, ['success' => false, 'valid' => false, 'message' => 'Administrative session invalid or expired.']);
    }
    if ($uri === 'auth/admin-logout' && $m === 'POST') {
        $t = admin_token(); if ($t && isset($DB['adminSessions'][$t])) { unset($DB['adminSessions'][$t]); save_db(); }
        out(200, ['success' => true, 'message' => 'Administrative session ended.']);
    }
    if ($uri === 'admin/change-passkey' && $m === 'POST') {
        require_admin(); $cur = sstr($IN['currentPasskey'] ?? ''); $nw = sstr($IN['newPasskey'] ?? ''); $exp = admin_key();
        if (!$exp || !hash_equals($exp, $cur)) fail(400, 'Current administrative passkey is incorrect.');
        if (strlen($nw) < 8) fail(400, 'New passkey must be at least 8 characters.');
        $DB['settings']['adminKey'] = $nw; save_db(true); out(200, ['success' => true, 'message' => 'Administrative passkey changed successfully.']);
    }
    if ($uri === 'auth/forgot-password' && $m === 'POST') {
        $email = strtolower(sstr($IN['email'] ?? ''));
        if (!$email) fail(400, 'Email is required.');
        if (!rl_hit('fgt-ip:' . secure_ip(), 8, 3600) || !rl_hit('fgt-em:' . $email, 4, 3600)) fail(429, 'Too many reset requests. Please try again in an hour.');
        if (find_idx($DB['users'], function ($u) use ($email) { return lower($u['email'] ?? '') === $email; }) < 0) fail(404, 'No account found with this email.');
        $code = (string)rnd(100000, 999999);
        array_unshift($DB['passwordResets'], ['id' => 'rst-' . time(), 'email' => $email, 'code' => $code, 'token' => 'rst_' . time() . '_' . hexs(16), 'expiresAt' => (time() + 900) * 1000, 'used' => false, 'createdAt' => iso_now()]);
        $DB['passwordResets'] = array_slice($DB['passwordResets'], 0, 200); save_db();
        $html = '<div style="font-family:Arial;max-width:480px;margin:auto;padding:28px;border:1px solid #e2e8f0;border-radius:16px"><h2>Password reset code</h2><div style="font-size:34px;letter-spacing:10px;font-weight:bold;color:#6c14ff;text-align:center;padding:16px;background:#f5f0ff;border-radius:12px">' . $code . '</div><p style="color:#64748b;font-size:12px">Valid for 15 minutes.</p></div>';
        $mail = send_email($email, 'Your 6-Digit Password Reset Code', $html, 'password_reset', $code);
        $b = ['success' => true, 'message' => 'Password reset code sent to your email.', 'simulated' => $mail['simulated']];
        if ($mail['simulated'] && env('DEV_SHOW_RESET_CODE') === 'true') $b['code'] = $code;
        out(200, $b);
    }
}
