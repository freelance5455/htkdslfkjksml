<?php
// Site settings (no .env needed), install check, daily backups.
function site_cfg() {
    global $DB; $s = is_array($DB['site'] ?? null) ? $DB['site'] : [];
    return array_replace(['baseUrl' => '', 'forceMainDomain' => false, 'emailVerification' => true], $s);
}
function env_set($k) { $v = getenv($k); return $v !== false && $v !== ''; }
function auto_origin() {
    $https = strtolower(trim(explode(',', hdr('x-forwarded-proto'))[0])) === 'https' || (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    $host = trim(explode(',', hdr('x-forwarded-host') ?: ($_SERVER['HTTP_HOST'] ?? 'localhost'))[0]);
    return ($https ? 'https://' : 'http://') . $host;
}
function backup_dir() { $d = DATA_DIR . '/backups'; if (!is_dir($d)) @mkdir($d, 0775, true); return $d; }
function backup_list() {
    $o = [];
    foreach ((array)glob(backup_dir() . '/database-????-??-??.json') as $f) $o[] = ['name' => basename($f), 'size' => filesize($f), 'time' => gmdate('Y-m-d H:i', filemtime($f)) . ' UTC'];
    usort($o, function ($a, $b) { return strcmp($b['name'], $a['name']); });
    return $o;
}
// Runs on every API request but only does work once per day.
function daily_backup() {
    if (!is_file(DB_FILE) || filesize(DB_FILE) < 10) return;
    $f = backup_dir() . '/database-' . today() . '.json';
    if (is_file($f)) return;
    if (!@copy(DB_FILE, $f)) return;
    $all = backup_list(); foreach (array_slice($all, 7) as $b) @unlink(backup_dir() . '/' . $b['name']);
}
function sanitized_export($d) {
    foreach (['adminSessions', 'userSessions', 'securitySecret', 'emailVerifications', 'passwordResets'] as $k) unset($d[$k]);
    unset($d['settings']['adminKey']);
    foreach (['smtpConfig', 'databaseConfig'] as $k) if (!empty($d['settings'][$k]['pass'])) $d['settings'][$k]['pass'] = MASK;
    $d['_meta'] = ['app' => 'earnvialinks', 'format' => 1, 'exportedAt' => iso_now(), 'counts' => ['users' => count($d['users'] ?? []), 'links' => count($d['links'] ?? []), 'withdrawals' => count($d['withdrawals'] ?? [])]];
    return $d;
}
// Managed redirect block in .htaccess: sends every other domain (www etc.) to the main domain. API stays untouched.
function apply_domain_redirect($enable, $baseUrl) {
    $f = ROOT . '/.htaccess'; $t = @file_get_contents($f);
    if ($t === false || !is_writable($f)) return 'Could not edit .htaccess (file not writable). Set it manually or make the file writable.';
    $t = preg_replace('/\R?# BEGIN EVL-DOMAIN.*?# END EVL-DOMAIN\R?/s', "\n", $t);
    if ($enable) {
        if (!preg_match('#^(https?)://([a-z0-9.-]+)$#i', $baseUrl, $m)) return 'Main domain must be like https://yourdomain.com (no port or path) to force redirects.';
        $host = strtolower($m[2]); $re = str_replace('.', '\\.', $host);
        $block = "# BEGIN EVL-DOMAIN (managed from admin panel - do not edit)\nRewriteCond %{HTTP_HOST} !^" . $re . "$ [NC]\nRewriteCond %{REQUEST_URI} !^/api\nRewriteRule ^(.*)$ " . strtolower($m[1]) . "://" . $host . "/$1 [R=301,L]\n# END EVL-DOMAIN\n";
        if (strpos($t, 'RewriteEngine On') === false) return '.htaccess has no RewriteEngine line.';
        $t = preg_replace('/RewriteEngine On\R/', "RewriteEngine On\n" . $block, $t, 1);
    }
    @copy($f, $f . '.bak'); return file_put_contents($f, $t) === false ? 'Could not write .htaccess.' : '';
}
function site_view() {
    $c = site_cfg();
    return ['baseUrl' => $c['baseUrl'], 'forceMainDomain' => !empty($c['forceMainDomain']), 'emailVerification' => $c['emailVerification'] !== false,
        'envBaseUrl' => env_set('BASE_URL'), 'envEmailVerification' => env_set('EMAIL_VERIFICATION'), 'detected' => auto_origin(),
        'dataDir' => DATA_DIR, 'dataInsideWebRoot' => strpos(realpath(DATA_DIR) ?: DATA_DIR, realpath(ROOT) ?: ROOT) === 0, 'backups' => backup_list()];
}
function install_check() {
    global $DB; $r = [];
    $add = function ($id, $label, $st, $detail, $fix = '') use (&$r) { $r[] = ['id' => $id, 'label' => $label, 'status' => $st, 'detail' => $detail, 'fix' => $fix]; };
    $probe = DATA_DIR . '/.write-test-' . hexs(3); $w = @file_put_contents($probe, 'x') !== false; @unlink($probe);
    $add('data', 'Data folder writable', $w ? 'ok' : 'bad', DATA_DIR, 'Set the data folder permission to 775 in hPanel File Manager.');
    $add('php', 'PHP version', version_compare(PHP_VERSION, '7.4', '<') ? 'bad' : (version_compare(PHP_VERSION, '8.0', '<') ? 'warn' : 'ok'), PHP_VERSION, 'In hPanel > PHP Configuration choose PHP 8.1 or newer.');
    $miss = array_filter(['json', 'mbstring', 'openssl', 'curl'], function ($e) { return !extension_loaded($e); });
    $add('ext', 'PHP extensions (json, mbstring, openssl, curl)', $miss ? 'warn' : 'ok', $miss ? 'Missing: ' . implode(', ', $miss) : 'All present', 'Enable the missing extensions in hPanel > PHP Configuration > Extensions.');
    $c = site_cfg(); $envB = env_set('BASE_URL');
    $add('base', 'Base URL', ($envB || $c['baseUrl']) ? 'ok' : 'warn', $envB ? env('BASE_URL') . ' (from .env)' : ($c['baseUrl'] ?: 'Auto-detect (' . auto_origin() . ')'), 'Open Site Settings and enter your main domain, e.g. https://yourdomain.com.');
    $add('admin', 'Admin passkey set', has_admin_key() ? 'ok' : 'bad', has_admin_key() ? 'Set' : 'Not set', 'Open /realadmin and create the passkey on the first-run screen.');
    $s = $DB['settings']['smtpConfig'] ?? [];
    $mail = (env('SMTP_HOST') ?: ($s['host'] ?? '')) && (env('SMTP_USER') ?: ($s['user'] ?? '')) && (env('SMTP_PASS') ?: ($s['pass'] ?? ''));
    $add('smtp', 'Email (SMTP) settings', $mail ? 'ok' : (otp_enabled() ? 'bad' : 'warn'), $mail ? 'Host, user and password present' : 'SMTP password/host missing', 'Fill SMTP in the Email tab and send a test email. Without it users cannot receive OTP codes.');
    $pub = 'unknown'; $origin = $envB ? rtrim(env('BASE_URL'), '/') : ($c['baseUrl'] ?: auto_origin());
    if (basename(DATA_DIR) === 'data' && dirname(DATA_DIR) === ROOT && function_exists('curl_init')) {
        $ch = curl_init($origin . '/data/database.json'); curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_NOBODY => true, CURLOPT_TIMEOUT => 4, CURLOPT_CONNECTTIMEOUT => 3, CURLOPT_FOLLOWLOCATION => false, CURLOPT_SSL_VERIFYPEER => false]);
        curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
        $pub = $code === 200 ? 'public' : ($code ? 'blocked' : 'unknown');
    } elseif (strpos(realpath(DATA_DIR) ?: DATA_DIR, realpath(ROOT) ?: ROOT) !== 0) $pub = 'blocked';
    $add('public', 'Data folder not publicly readable', $pub === 'blocked' ? 'ok' : ($pub === 'public' ? 'bad' : 'warn'), $pub === 'blocked' ? 'Not reachable from the web' : ($pub === 'public' ? 'database.json is downloadable from the web!' : 'Could not test automatically'), 'Make sure data/.htaccess exists, or move the data folder outside public_html (data-path.php).');
    $bk = backup_list(); $age = $bk ? time() - strtotime(substr($bk[0]['name'], 9, 10) . ' 00:00:00 UTC') : null;
    $add('backup', 'Daily backup', $bk ? ($age < 3 * 86400 ? 'ok' : 'warn') : 'warn', $bk ? 'Latest: ' . $bk[0]['time'] . ' (' . count($bk) . ' kept)' : 'No backup yet (created on the next visit)', 'Also download a backup now and keep it on your computer.');
    return $r;
}
function routes_site($uri, $m) {
    global $DB, $IN;
    if ($uri === 'admin/site' && $m === 'GET') { require_admin(); out(200, ['success' => true, 'site' => site_view()]); }
    if ($uri === 'admin/site/save' && $m === 'POST') {
        require_admin(); $in = is_array($IN['site'] ?? null) ? $IN['site'] : []; $c = site_cfg();
        $b = rtrim(sstr($in['baseUrl'] ?? ''), '/');
        if ($b !== '' && !preg_match('#^https?://[a-z0-9.-]+(:\d+)?$#i', $b)) fail(400, 'Main domain must look like https://yourdomain.com (no path).');
        $force = !empty($in['forceMainDomain']);
        if ($force && $b === '') fail(400, 'Enter the main domain first to force redirects to it.');
        $warn = '';
        if ($force) {
            $cur = strtolower(parse_url(auto_origin(), PHP_URL_HOST) ?: ''); $main = strtolower(parse_url($b, PHP_URL_HOST) ?: '');
            if ($cur !== $main && $cur !== 'www.' . $main && 'www.' . $cur !== $main) fail(400, "You are on $cur but the main domain is $main. Open the admin panel from the main domain (or its www version) before forcing redirects, so you cannot lock yourself out.");
        }
        $err = apply_domain_redirect($force, $b);
        if ($err) { if ($force) fail(500, $err); $warn = $err; }
        $c['baseUrl'] = $b; $c['forceMainDomain'] = $force; $c['emailVerification'] = !empty($in['emailVerification']);
        $DB['site'] = $c; save_db(true);
        $w = $warn; if (env_set('BASE_URL')) $w .= ' Note: .env BASE_URL is set and takes priority over this field.'; if (env_set('EMAIL_VERIFICATION')) $w .= ' Note: .env EMAIL_VERIFICATION takes priority over this toggle.';
        out(200, ['success' => true, 'site' => site_view(), 'warning' => trim($w)]);
    }
    if ($uri === 'admin/install-check' && $m === 'GET') { require_admin(); out(200, ['success' => true, 'checks' => install_check(), 'backups' => backup_list()]); }
    if ($uri === 'admin/backup/download' && $m === 'GET') {
        require_admin(); $n = sstr($_GET['file'] ?? ''); $d = $DB; $name = 'earnvialinks-backup-' . today() . '.json';
        if ($n !== '') { if (!preg_match('/^database-\d{4}-\d{2}-\d{2}\.json$/', $n) || !is_file(backup_dir() . '/' . $n)) fail(404, 'Backup not found.'); $d = json_decode((string)file_get_contents(backup_dir() . '/' . $n), true) ?: []; $name = 'earnvialinks-' . $n; }
        header('Content-Type: application/json; charset=utf-8'); header('Content-Disposition: attachment; filename="' . $name . '"');
        echo json_encode(sanitized_export($d), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); exit;
    }
}
