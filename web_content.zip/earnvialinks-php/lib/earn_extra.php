<?php
// Earn extras: verified PTC sessions (heartbeat based) + CPAlead offerwall (admin settings, postback, log)

// ---------- PTC sessions (stored as small files so heartbeats never touch the big JSON database) ----------
function ptc_dir() { $d = DATA_DIR . '/ptc'; if (!is_dir($d)) @mkdir($d, 0775, true); return $d; }
function ptc_valid_token($t) { return is_string($t) && preg_match('/^[a-f0-9]{32}$/', $t); }
function ptc_session_create($userId, $adId, $seconds, $mode, $nowMs) {
    $dir = ptc_dir(); $tok = hexs(16);
    if (rnd(1, 15) === 1) foreach ((array)glob($dir . '/*.json') as $f) if (@filemtime($f) < time() - 3600) @unlink($f);
    $s = ['userId' => $userId, 'adId' => $adId, 'seconds' => $seconds, 'mode' => $mode, 'at' => $nowMs, 'lastPing' => $nowMs, 'verified' => 0, 'ip' => client_ip(), 'ua' => ua_hash()];
    @file_put_contents($dir . '/' . $tok . '.json', json_encode($s), LOCK_EX);
    return $tok;
}
function ptc_session_read($tok) {
    if (!ptc_valid_token($tok)) return null;
    $f = ptc_dir() . '/' . $tok . '.json'; if (!is_file($f)) return null;
    $s = json_decode((string)@file_get_contents($f), true);
    return is_array($s) ? $s : null;
}
function ptc_session_delete($tok) { if (ptc_valid_token($tok)) @unlink(ptc_dir() . '/' . $tok . '.json'); }
// Called BEFORE the global DB lock (see api.php) - cheap, no database access.
function ptc_ping($IN) {
    $tok = sstr($IN['token'] ?? ''); if (!ptc_valid_token($tok)) fail(400, 'Invalid session.');
    $f = ptc_dir() . '/' . $tok . '.json'; if (!is_file($f)) fail(400, 'Ad session expired. Please open the ad again.');
    $h = fopen($f, 'c+'); if (!$h) fail(500, 'Session error.');
    flock($h, LOCK_EX);
    $s = json_decode((string)stream_get_contents($h), true);
    if (!is_array($s) || ($s['userId'] ?? '') !== sstr($IN['userId'] ?? '')) { flock($h, LOCK_UN); fclose($h); fail(400, 'Invalid session.'); }
    $now = (int)(microtime(true) * 1000); $delta = $now - (int)$s['lastPing'];
    $visible = !empty($IN['visible']);
    $counts = ($s['mode'] === 'frame') ? $visible : !$visible; // frame: viewer tab must be visible+focused; tab: user must be away on the ad tab
    // only real elapsed time is credited (so spamming pings gives nothing), and long gaps (tab frozen / closed) are not credited
    if ($counts && $delta > 0 && $delta <= 7000) $s['verified'] = (int)$s['verified'] + min($delta, 3500);
    $s['lastPing'] = $now;
    ftruncate($h, 0); rewind($h); fwrite($h, json_encode($s)); fflush($h); flock($h, LOCK_UN); fclose($h);
    out(200, ['success' => true, 'verified' => (int)$s['verified'], 'need' => (int)$s['seconds'] * 1000]);
}
// Warn the admin when an ad site refuses to be shown inside our viewer frame.
function frame_check($url) {
    if (!function_exists('curl_init')) return '';
    $c = curl_init($url);
    curl_setopt_array($c, [CURLOPT_RETURNTRANSFER => true, CURLOPT_HEADER => true, CURLOPT_NOBODY => true, CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 4, CURLOPT_TIMEOUT => 5, CURLOPT_CONNECTTIMEOUT => 3, CURLOPT_USERAGENT => 'Mozilla/5.0 EarnViaLinks-FrameCheck']);
    $h = (string)curl_exec($c); curl_close($c);
    if ($h === '') return '';
    if (preg_match('/^x-frame-options:\s*(deny|sameorigin)/im', $h)) return 'This site blocks being shown inside a frame (X-Frame-Options). Switch this ad to "New tab" mode or users will see a blank page.';
    if (preg_match('/^content-security-policy:[^\r\n]*frame-ancestors\s+(?!\*)[^\r\n;]*/im', $h)) return 'This site restricts framing (CSP frame-ancestors). If users see a blank page, switch this ad to "New tab" mode.';
    return '';
}

// ---------- CPAlead ----------
function cpalead_defaults() {
    return ['enabled' => false, 'title' => 'CPAlead Offerwall', 'description' => 'Complete offers, installs and sign-ups to earn rewards.', 'badge' => 'Top Paying', 'maxReward' => '', 'offerwallUrl' => '', 'secret' => '', 'rewardMode' => 'points', 'sharePercent' => 60.0, 'pointsPerUsd' => 100.0, 'maxCreditUsd' => 100.0, 'allowedIps' => '', 'updatedAt' => ''];
}
function cpalead_cfg() {
    global $DB; earn_db();
    $c = array_replace(cpalead_defaults(), is_array($DB['earn']['cpalead'] ?? null) ? $DB['earn']['cpalead'] : []);
    // one-time migration: postbacks arrive in points and 100 points = $1 (admin can still change it afterwards)
    if (empty($c['ppu100'])) { $c['rewardMode'] = 'points'; $c['pointsPerUsd'] = 100.0; $c['ppu100'] = true; if (is_array($DB['earn']['cpalead'] ?? null)) { $DB['earn']['cpalead'] = $c; save_db(); } }
    return $c;
}
function cpalead_public($userId) {
    $c = cpalead_cfg();
    if (empty($c['enabled']) || !preg_match('#^https?://#i', (string)$c['offerwallUrl'])) return null;
    $u = preg_replace('/\{(user_?id|uid|subid)\}/i', rawurlencode($userId), $c['offerwallUrl']);
    return ['title' => $c['title'], 'description' => $c['description'], 'badge' => $c['badge'], 'maxReward' => $c['maxReward'], 'url' => $u];
}
function cpalead_param($names) { foreach ($names as $n) { $v = $_GET[$n] ?? ($_POST[$n] ?? null); if ($v !== null && !is_array($v)) { $v = cpalead_clean($v); if ($v !== '') return $v; } } return ''; }
// An unreplaced macro such as {payout}, [payout] or %payout% means CPAlead did not fill the value: treat as empty.
function cpalead_clean($v) { $v = trim((string)$v); return preg_match('/^(\{[^}]*\}|\[[^\]]*\]|%[^%]*%|\$\{[^}]*\}|null|undefined)$/i', $v) ? '' : $v; }
function cpalead_find_user($raw) {
    global $DB; $raw = trim(rawurldecode((string)$raw)); if ($raw === '') return -1;
    $l = strtolower($raw);
    $i = find_idx($DB['users'], function ($u) use ($raw, $l) { return ($u['id'] ?? '') === $raw || strtolower($u['id'] ?? '') === $l; });
    if ($i < 0) $i = find_idx($DB['users'], function ($u) use ($l) { return strtolower($u['email'] ?? '') === $l; });
    return $i;
}
// Keeps the last 200 postback calls (success and failure) with the reason, for the admin "Postback attempts" table.
function cpalead_attempt($ok, $note, $uid = '') {
    global $DB; earn_db();
    if (!is_array($DB['earn']['cpaAttempts'] ?? null)) $DB['earn']['cpaAttempts'] = [];
    $q = $_GET + $_POST; unset($q['key'], $q['secret'], $q['password'], $q['pw']);
    array_unshift($DB['earn']['cpaAttempts'], ['at' => iso_now(), 'ok' => (bool)$ok, 'note' => substr((string)$note, 0, 300), 'userId' => (string)$uid, 'ip' => client_ip(), 'query' => substr(http_build_query($q), 0, 400)]);
    if (count($DB['earn']['cpaAttempts']) > 200) $DB['earn']['cpaAttempts'] = array_slice($DB['earn']['cpaAttempts'], 0, 200);
    save_db();
}

function routes_earn_extra($uri, $m) {
    global $DB, $IN, $Q;
    if ($uri === 'admin/earn/cpalead' && $m === 'GET') {
        require_admin(); earn_db(); $c = cpalead_cfg();
        out(200, ['success' => true, 'config' => $c, 'log' => array_slice($DB['earn']['cpaLog'] ?? [], 0, 100), 'attempts' => array_slice($DB['earn']['cpaAttempts'] ?? [], 0, 50), 'stats' => ['credits' => ival($DB['earn']['stats']['cpaCredits'] ?? 0), 'paid' => r4(num($DB['earn']['stats']['cpaPaid'] ?? 0)), 'reversed' => ival($DB['earn']['stats']['cpaReversed'] ?? 0)], 'origin' => site_base()['origin']]);
    }
    if ($uri === 'admin/earn/cpalead/save' && $m === 'POST') {
        require_admin(); earn_db(); $in = is_array($IN['config'] ?? null) ? $IN['config'] : []; $c = cpalead_cfg();
        $url = sstr($in['offerwallUrl'] ?? $c['offerwallUrl']);
        if ($url !== '' && !preg_match('#^https://\S+$#i', $url)) fail(400, 'Offerwall URL must start with https://');
        $secret = sstr($in['secret'] ?? $c['secret']); if ($secret !== '' && !preg_match('/^[A-Za-z0-9_-]{12,80}$/', $secret)) fail(400, 'Secret key must be 12-80 letters/numbers (use Generate).');
        $c['enabled'] = !empty($in['enabled']) && $url !== '';
        if (!empty($in['enabled']) && $url === '') fail(400, 'Enter the CPAlead offerwall URL first.');
        if ($c['enabled'] && $secret === '') fail(400, 'Generate a secret key before enabling (it protects your postback).');
        $c['title'] = substr(sstr($in['title'] ?? $c['title']), 0, 80) ?: 'CPAlead Offerwall';
        $c['description'] = substr(sstr($in['description'] ?? $c['description']), 0, 300);
        $c['badge'] = substr(sstr($in['badge'] ?? $c['badge']), 0, 30); $c['maxReward'] = substr(sstr($in['maxReward'] ?? $c['maxReward']), 0, 40);
        $c['offerwallUrl'] = $url; $c['secret'] = $secret;
        $c['rewardMode'] = (($in['rewardMode'] ?? $c['rewardMode']) === 'points') ? 'points' : 'payout';
        $c['sharePercent'] = min(100, max(0, num($in['sharePercent'] ?? $c['sharePercent'])));
        $c['pointsPerUsd'] = max(1, num($in['pointsPerUsd'] ?? $c['pointsPerUsd']));
        $c['maxCreditUsd'] = max(0.01, num($in['maxCreditUsd'] ?? $c['maxCreditUsd']));
        $c['allowedIps'] = substr(sstr($in['allowedIps'] ?? $c['allowedIps']), 0, 400); $c['updatedAt'] = iso_now();
        $c['ppu100'] = true; $DB['earn']['cpalead'] = $c; save_db();
        $w = ($url !== '' && !preg_match('/\{(user_?id|uid|subid)\}/i', $url)) ? 'Your URL has no {user_id} placeholder - users will not be identified and their rewards cannot be credited.' : '';
        out(200, ['success' => true, 'config' => $c, 'warning' => $w]);
    }
    if ($uri === 'postback/cpalead' && ($m === 'GET' || $m === 'POST')) {
        earn_db(); $c = cpalead_cfg();
        // every attempt (accepted or rejected) is recorded so the admin can see exactly why a lead was not credited
        $reject = function ($code, $msg) { cpalead_attempt(false, $msg); fail($code, $msg); };
        if (empty($c['enabled']) || $c['secret'] === '') $reject(403, 'Offerwall postback is disabled.');
        $key = cpalead_param(['key', 'secret', 'password', 'pw']);
        if (!rl_hit('cpapb:' . client_ip(), 600, 60)) fail(429, 'Too many requests.');
        if (!hash_equals($c['secret'], $key)) { if (!rl_hit('cpabad:' . client_ip(), 20, 3600)) fail(429, 'Blocked.'); $reject(403, 'Invalid key.'); }
        if (trim($c['allowedIps']) !== '') { $ok = array_filter(array_map('trim', explode(',', $c['allowedIps']))); if (!in_array(client_ip(), $ok, true)) $reject(403, 'IP not allowed: ' . client_ip()); }
        $uid = cpalead_param(['subid', 'sub_id', 'subid1', 'sub1', 'user_id', 'userid', 'uid', 's1', 'aff_sub']);
        $tx = cpalead_param(['lead_id', 'leadid', 'transaction_id', 'conversion_id', 'txid', 'tx_id', 'click_id', 'id']);
        $payout = num(cpalead_param(['payout', 'revenue', 'amount', 'earnings', 'commission']));
        $pts = num(cpalead_param(['virtual_currency', 'virtual_currency_amount', 'points', 'currency']));
        $status = strtolower(cpalead_param(['status', 'state']));
        if ($uid === '') $reject(400, 'Missing subid (the offerwall URL must contain {user_id} and the postback must send subid).');
        $ui = cpalead_find_user($uid);
        if ($ui < 0) $reject(404, 'User not found for subid "' . substr($uid, 0, 60) . '".');
        $uid = $DB['users'][$ui]['id'];
        if ($tx === '') $tx = 'auto-' . substr(sha1($uid . '|' . $payout . '|' . $pts . '|' . cpalead_param(['ip_address', 'ip']) . '|' . cpalead_param(['offer_id', 'campaign_id', 'offer_title', 'title']) . '|' . date('YmdHi')), 0, 24);
        $tx = substr(preg_replace('/[^A-Za-z0-9_.:-]/', '', $tx), 0, 80);
        $log = &$DB['earn']['cpaLog']; $li = find_idx($log, function ($x) use ($tx) { return ($x['txid'] ?? '') === $tx && empty($x['blocked']); });
        $isRev = in_array($status, ['reversed', 'reversal', 'chargeback', 'rejected', 'declined', 'cancelled', 'canceled', '-1'], true);
        if ($isRev) {
            if ($li < 0 || !empty($log[$li]['reversed'])) { cpalead_attempt(true, 'Nothing to reverse.', $uid); out(200, ['success' => true, 'message' => 'Nothing to reverse.']); }
            $u = &$DB['users'][$ui]; $amt = num($log[$li]['usd']); $nb = max(0, r4(num($u['bal'] ?? 0) - $amt));
            $u['bal'] = $nb; $u['balance'] = $nb; $u['earnOffers'] = max(0, r4(num($u['earnOffers'] ?? 0) - $amt));
            $log[$li]['reversed'] = true; $log[$li]['reversedAt'] = iso_now(); $DB['earn']['stats']['cpaReversed'] = ival($DB['earn']['stats']['cpaReversed'] ?? 0) + 1;
            cpalead_attempt(true, 'Reversed.', $uid); save_db();
            out(200, ['success' => true, 'message' => 'Reversed.']);
        }
        if ($li >= 0) { cpalead_attempt(true, 'Duplicate ignored.', $uid); out(200, ['success' => true, 'message' => 'Duplicate ignored.']); } // CPAlead may retry; never pay twice
        // pick the reward; if the chosen mode has no value but the other one does, use that instead of dropping the lead
        $fromPayout = $payout * $c['sharePercent'] / 100; $fromPts = $pts > 0 ? $pts / max(1, $c['pointsPerUsd']) : 0;
        $usd = ($c['rewardMode'] === 'points') ? ($fromPts > 0 ? $fromPts : $fromPayout) : ($fromPayout > 0 ? $fromPayout : $fromPts);
        $usd = r4($usd); if ($usd <= 0) $reject(400, 'No payout/points value received (payout=' . substr(cpalead_param(['payout', 'revenue', 'amount']), 0, 20) . ', points=' . substr(cpalead_param(['virtual_currency', 'points']), 0, 20) . '). Check the macro names in the CPAlead postback.');
        if ($usd > $c['maxCreditUsd']) { array_unshift($log, ['id' => 'cpa-' . time() . rnd(100, 999), 'txid' => $tx, 'userId' => $uid, 'usd' => 0, 'blocked' => true, 'note' => 'Over max credit ($' . $usd . ')', 'at' => iso_now()]); $reject(400, 'Credit $' . $usd . ' exceeds the safety limit ($' . $c['maxCreditUsd'] . ').'); }
        $u = &$DB['users'][$ui]; if (in_array($u['status'] ?? '', ['Banned', 'Suspended'], true)) $reject(403, 'User not active.');
        $nb = r4(num($u['bal'] ?? 0) + $usd); $u['bal'] = $nb; $u['balance'] = $nb; $u['earnOffers'] = r4(num($u['earnOffers'] ?? 0) + $usd);
        array_unshift($log, ['id' => 'cpa-' . time() . rnd(100, 999), 'txid' => $tx, 'userId' => $uid, 'userEmail' => $u['email'] ?? '', 'usd' => $usd, 'payout' => $payout, 'points' => $pts, 'ip' => cpalead_param(['ip_address', 'ip']), 'at' => iso_now()]);
        if (count($log) > 1000) $log = array_slice($log, 0, 1000);
        $DB['earn']['stats']['cpaCredits'] = ival($DB['earn']['stats']['cpaCredits'] ?? 0) + 1; $DB['earn']['stats']['cpaPaid'] = r4(num($DB['earn']['stats']['cpaPaid'] ?? 0) + $usd);
        cpalead_attempt(true, 'Credited $' . $usd, $uid); save_db();
        out(200, ['success' => true, 'credited' => $usd]);
    }
}
