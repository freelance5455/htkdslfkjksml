<?php
// Money part 3: withdrawals, streaks, loyalty, link lookup, Earn (PTC / offerwalls / surveys), impersonate
function earn_db() {
    global $DB;
    if (!is_array($DB['earn'] ?? null)) $DB['earn'] = [];
    foreach (['ptcAds', 'offerwalls', 'surveys'] as $k) if (!is_array($DB['earn'][$k] ?? null)) $DB['earn'][$k] = [];
    foreach (['ptcLog', 'pending', 'cpaLog'] as $k) if (!is_array($DB['earn'][$k] ?? null)) $DB['earn'][$k] = [];
    if (!is_array($DB['earn']['stats'] ?? null)) $DB['earn']['stats'] = ['ptcClicks' => 0, 'ptcPaid' => 0];
}
function earn_clean_item($kind, $inc, $cur) {
    $b = $cur ?: [];
    $g = function ($k, $d = '') use ($inc, $b) { return has($inc, $k) ? $inc[$k] : ($b[$k] ?? $d); };
    $url = sstr($g('url')); $url = preg_match('#^https?://\S+$#i', $url) ? substr($url, 0, 1000) : '';
    $o = ['id' => $b['id'] ?? ($kind . '-' . time() . rnd(100, 999)), 'title' => substr(sstr($g('title')), 0, 120), 'description' => substr(sstr($g('description')), 0, 400), 'url' => $url, 'status' => $g('status') === 'Paused' ? 'Paused' : 'Active', 'createdAt' => $b['createdAt'] ?? iso_now()];
    if ($kind === 'ptc') { $o['reward'] = max(0, r4(num($g('reward', 0)))); $o['seconds'] = min(300, max(5, ival($g('seconds', 15)))); $o['mode'] = $g('mode', 'frame') === 'tab' ? 'tab' : 'frame'; $o['budget'] = max(0, ival($g('budget', 0))); $o['clicks'] = ival($b['clicks'] ?? 0); }
    else { $o['maxReward'] = substr(sstr($g('maxReward')), 0, 40); $o['embed'] = has($inc, 'embed') ? !!$inc['embed'] : !empty($b['embed']); $o['badge'] = substr(sstr($g('badge')), 0, 30); }
    return $o;
}
function withdraw_eligibility($u) {
    global $DB;
    $needViews = ival(has($DB['settings'], 'minWithdrawViews') ? $DB['settings']['minWithdrawViews'] : 5000);
    $needRefs = ival(has($DB['settings'], 'minWithdrawReferrals') ? $DB['settings']['minWithdrawReferrals'] : 2);
    $views = ival($u['views'] ?? 0); $cnt = 0;
    foreach ($DB['users'] as $x) {
        if (empty($x['referredBy'])) continue; $r = lower(sstr($x['referredBy']));
        if ($r === lower($u['id'] ?? '') || (!empty($u['referralCode']) && $r === lower($u['referralCode'])) || (!empty($u['name']) && $r === lower($u['name'])) || (!empty($u['email']) && $r === lower($u['email']))) $cnt++;
    }
    $refs = max(ival($u['referralCount'] ?? 0), $cnt);
    $ok = $views >= $needViews && $refs >= $needRefs;
    $msg = '';
    if (!$ok) {
        $parts = [];
        if ($views < $needViews) $parts[] = "your views ($views) are below $needViews";
        if ($refs < $needRefs) $parts[] = "you have $refs of $needRefs required referrals";
        $msg = 'You are not eligible for withdrawal yet: ' . implode(' and ', $parts) . '. Complete ' . number_format($needViews) . ' views and ' . $needRefs . ' referrals first.';
    }
    return ['ok' => $ok, 'views' => $views, 'referrals' => $refs, 'needViews' => $needViews, 'needReferrals' => $needRefs, 'message' => $msg];
}
function routes_money3($uri, $m) {
    global $DB, $IN, $Q;
    if ($uri === 'admin/users/delete' && $m === 'POST') {
        require_admin(); $id = has($IN, 'id') ? sstr($IN['id']) : sstr($IN['userId'] ?? '');
        if (!$id) fail(400, 'User ID is required.');
        $before = count($DB['users']);
        $DB['users'] = array_values(array_filter($DB['users'], function ($u) use ($id) { return ($u['id'] ?? '') !== $id; }));
        if (count($DB['users']) === $before) fail(404, 'User not found.');
        $DB['links'] = array_values(array_filter($DB['links'], function ($l) use ($id) { return ($l['userId'] ?? '') !== $id; }));
        $DB['withdrawals'] = array_values(array_filter($DB['withdrawals'], function ($w) use ($id) { return ($w['userId'] ?? '') !== $id; }));
        save_db(true); out(200, ['success' => true, 'message' => 'User and associated data permanently removed.']);
    }
    if ($uri === 'withdrawals' && $m === 'GET') {
        $userId = sstr($Q['userId'] ?? ''); $list = $DB['withdrawals'];
        if (!is_admin_session(admin_token())) {
            if (!$userId) $list = [];
            else {
                require_user($userId); $ui = find_user($userId); $em = $ui >= 0 ? lower($DB['users'][$ui]['email'] ?? '') : '';
                $list = array_values(array_filter($list, function ($w) use ($userId, $em) { return ($w['userId'] ?? '') === $userId || ($em && lower($w['userEmail'] ?? '') === $em); }));
            }
        }
        out(200, ['success' => true, 'withdrawals' => $list]);
    }
    if ($uri === 'withdrawals/request' && $m === 'POST') {
        $userId = sstr($IN['userId'] ?? ''); $req = has($IN, 'amount') ? num($IN['amount']) : null; $mn = has($IN, 'method') ? sstr($IN['method']) : 'PayPal'; $details = sstr($IN['details'] ?? '');
        if (!$userId) fail(400, 'User ID is required to request a withdrawal.');
        require_user($userId); $ui = find_user($userId); if ($ui < 0) fail(404, 'Publisher account not found.');
        $u = &$DB['users'][$ui];
        if (in_array($u['status'] ?? '', ['Banned', 'Suspended'], true)) fail(403, 'Account is suspended or banned. Withdrawals disabled.');
        $maxW = withdrawable_balance($userId); $gw = null;
        foreach (is_array($DB['settings']['paymentGateways'] ?? null) ? $DB['settings']['paymentGateways'] : [] as $g) if (($g['name'] ?? '') === $mn) { $gw = $g; break; }
        $minT = $gw ? num(has($gw, 'minPayout') ? $gw['minPayout'] : 10.0) : num(has($DB['settings'], 'minWithdrawal') ? $DB['settings']['minWithdrawal'] : 10.0);
        $amount = round(($req !== null && $req > 0) ? min($req, $maxW) : $maxW, 2);
        if ($req !== null && $req > $maxW + 0.001) fail(400, 'Requested withdrawal amount ($' . money($req) . ') exceeds your server-verified earnings ($' . money($maxW) . ').');
        if ($amount < $minT) fail(400, "Minimum withdrawal threshold for $mn is $" . money($minT) . '. Your verified withdrawable balance is $' . money($maxW) . '.');
        // final step only: eligibility (views + referrals) is checked when the user actually submits the request
        $el = withdraw_eligibility($u); if (!$el['ok']) fail(403, $el['message'], ['eligibility' => $el]);
        $nb = max(0, r4(num($u['bal'] ?? 0) - $amount)); $u['bal'] = $nb; $u['balance'] = $nb;
        $wd = ['id' => 'wd-' . time() . rnd(100, 999), 'userId' => $u['id'], 'userName' => $u['name'] ?? 'Publisher', 'userEmail' => $u['email'] ?? '', 'method' => $mn, 'amount' => $amount, 'details' => $details ?: ($u['paymentDetails'] ?? ''), 'status' => 'Pending', 'requestedAt' => stamp_min()];
        array_unshift($DB['withdrawals'], $wd); save_db();
        out(200, ['success' => true, 'message' => 'Withdrawal request created successfully.', 'withdrawal' => $wd, 'newBalance' => $nb]);
    }
    if ($uri === 'withdrawals/approve' && $m === 'POST') {
        require_admin(); $id = sstr($IN['id'] ?? ''); if (!$id) fail(400, 'Withdrawal ID is required.');
        $wi = find_idx($DB['withdrawals'], function ($w) use ($id) { return ($w['id'] ?? '') === $id; }); if ($wi < 0) fail(404, 'Withdrawal record not found.');
        $tx = sstr($IN['txHash'] ?? '') ?: 'TXN-' . strtoupper(dechex(time())) . '-' . strtoupper(substr(hexs(4), 0, 8));
        $DB['withdrawals'][$wi]['status'] = 'Completed'; $DB['withdrawals'][$wi]['txHash'] = $tx; save_db();
        out(200, ['success' => true, 'message' => 'Withdrawal marked Completed and transaction hash generated.', 'withdrawal' => $DB['withdrawals'][$wi], 'txHash' => $tx]);
    }
    if ($uri === 'withdrawals/reject' && $m === 'POST') {
        require_admin(); $id = sstr($IN['id'] ?? ''); if (!$id) fail(400, 'Withdrawal ID is required.');
        $wi = find_idx($DB['withdrawals'], function ($w) use ($id) { return ($w['id'] ?? '') === $id; }); if ($wi < 0) fail(404, 'Withdrawal record not found.');
        $w = &$DB['withdrawals'][$wi];
        if (($w['status'] ?? '') === 'Pending' && !empty($w['userId']) && num($w['amount']) > 0 && ($ui = find_user($w['userId'])) >= 0) { $DB['users'][$ui]['bal'] = r4(num($DB['users'][$ui]['bal'] ?? 0) + num($w['amount'])); $DB['users'][$ui]['balance'] = $DB['users'][$ui]['bal']; }
        $w['status'] = 'Rejected'; save_db();
        out(200, ['success' => true, 'message' => 'Withdrawal rejected and amount refunded to user balance.', 'withdrawal' => $w]);
    }
    if ($uri === 'streak/status' && $m === 'GET') {
        $userId = sstr($Q['userId'] ?? ''); if (!$userId) fail(400, 'User ID is required.');
        require_user($userId); $ui = find_user($userId); if ($ui < 0) fail(404, 'User account not found.');
        $st = streak_state($DB['users'][$ui]);
        out(200, ['success' => true, 'streakDay' => $st['streakDay'], 'claimedStreakDays' => $st['claimed'], 'claimedToday' => $st['claimedToday'], 'missed' => $st['missed'], 'nextClaimAt' => $st['nextClaimAt'], 'serverNow' => $st['serverNow'], 'timezone' => $st['tz'], 'lastClaimDate' => $DB['users'][$ui]['lastClaimDate'] ?? null]);
    }
    if ($uri === 'streak/claim' && $m === 'POST') {
        $userId = sstr($IN['userId'] ?? ''); if (!$userId) fail(400, 'User ID is required.');
        require_user($userId); $ui = find_user($userId); if ($ui < 0) fail(404, 'User account not found.');
        $u = &$DB['users'][$ui]; $st = streak_state($u); $now = (int)(microtime(true) * 1000);
        if ($st['claimedToday']) fail(400, "You have already claimed today's streak reward. Next reward unlocks at midnight!", ['nextClaimAt' => $st['nextClaimAt'], 'serverNow' => $now]);
        $day = $st['streakDay']; $claimed = $st['claimed']; $rw = streak_rewards(); $reward = num(has($rw, $day - 1) ? $rw[$day - 1] : 0.10);
        $nb = r4(num($u['bal'] ?? 0) + $reward); $u['bal'] = $nb; $u['balance'] = $nb; $u['streakDay'] = $day; $u['lastClaimDate'] = $st['todayK']; $u['lastClaimAt'] = $now;
        if (!in_array($day, $claimed, true)) $claimed[] = $day; sort($claimed); $u['claimedStreakDays'] = $claimed; save_db();
        out(200, ['success' => true, 'message' => "Successfully claimed Day $day bonus ($" . money($reward) . ')! Balance credited.', 'reward' => $reward, 'streakDay' => $day, 'claimedStreakDays' => $claimed, 'newBalance' => $nb, 'lastClaimDate' => $st['todayK'], 'nextClaimAt' => $st['nextClaimAt'], 'serverNow' => $now]);
    }
    if ($uri === 'user/payment' && $m === 'POST') {
        $userId = sstr($IN['userId'] ?? ''); if (!$userId) fail(400, 'User ID is required.');
        require_user($userId); $ui = find_user($userId); if ($ui < 0) fail(404, 'User account not found.');
        $pm = substr(sstr($IN['paymentMethod'] ?? ''), 0, 60); $pd = substr(sstr($IN['paymentDetails'] ?? ''), 0, 200);
        if (!$pm) fail(400, 'Please choose a payout method.'); if (!$pd) fail(400, 'Please enter your account number / wallet / email.');
        $DB['users'][$ui]['paymentMethod'] = $pm; $DB['users'][$ui]['paymentDetails'] = $pd; save_db();
        out(200, ['success' => true, 'message' => 'Payout method saved.', 'paymentMethod' => $pm, 'paymentDetails' => $pd]);
    }
    if ($uri === 'loyalty/claim' && $m === 'POST') {
        $userId = sstr($IN['userId'] ?? ''); $tid = sstr($IN['tierId'] ?? '');
        if (!$userId || !$tid) fail(400, 'User ID and Tier ID are required.');
        require_user($userId); $ui = find_user($userId); if ($ui < 0) fail(404, 'User account not found.');
        $u = &$DB['users'][$ui]; $tier = null; foreach (loyalty_tiers() as $t) if (($t['id'] ?? '') === $tid) $tier = $t;
        if (!$tier) fail(404, 'Loyalty tier not found.');
        $cl = is_array($u['loyaltyClaimed'] ?? null) ? $u['loyaltyClaimed'] : [];
        if (in_array($tid, $cl, true)) fail(400, 'Milestone bonus has already been claimed!');
        $v = ival($u['views'] ?? 0); $need = ival($tier['targetDailyViews']);
        if ($v < $need) fail(400, 'Milestone locked: You have ' . number_format($v) . ' views, need ' . number_format($need) . '.');
        $b = num($tier['rewardAmount']); $nb = r4(num($u['bal'] ?? 0) + $b); $u['bal'] = $nb; $u['balance'] = $nb; $cl[] = $tid; $u['loyaltyClaimed'] = $cl; save_db();
        out(200, ['success' => true, 'message' => '🎉 Milestone Achieved! Credited $' . money($b) . ' to your balance.', 'reward' => $b, 'loyaltyClaimed' => $cl, 'newBalance' => $nb]);
    }
    // ---------- Earn ----------
    if ($uri === 'admin/earn' && $m === 'GET') { require_admin(); earn_db(); $e = $DB['earn']; out(200, ['success' => true, 'earn' => ['ptcAds' => $e['ptcAds'], 'offerwalls' => $e['offerwalls'], 'surveys' => $e['surveys'], 'stats' => $e['stats']]]); }
    $kinds = ['ptc' => 'ptcAds', 'offerwall' => 'offerwalls', 'survey' => 'surveys'];
    if ($uri === 'admin/earn/save' && $m === 'POST') {
        require_admin(); earn_db(); $kind = sstr($IN['kind'] ?? '');
        if (!isset($kinds[$kind]) || !is_array($IN['item'] ?? null)) fail(400, 'Invalid request.');
        $key = $kinds[$kind]; $inc = $IN['item'];
        $idx = has($inc, 'id') ? find_idx($DB['earn'][$key], function ($x) use ($inc) { return $x['id'] === sstr($inc['id']); }) : -1;
        $item = earn_clean_item($kind, $inc, $idx >= 0 ? $DB['earn'][$key][$idx] : null);
        if (!$item['title']) fail(400, 'Title is required.');
        if (!$item['url']) fail(400, 'A valid URL starting with http:// or https:// is required.');
        if ($idx >= 0) $DB['earn'][$key][$idx] = $item; else array_unshift($DB['earn'][$key], $item);
        save_db(); out(200, ['success' => true, 'item' => $item, 'warning' => ($kind === 'ptc' && $item['mode'] === 'frame') ? frame_check($item['url']) : '']);
    }
    if ($uri === 'admin/earn/delete' && $m === 'POST') {
        require_admin(); earn_db(); $kind = sstr($IN['kind'] ?? ''); if (!isset($kinds[$kind])) fail(400, 'Invalid request.');
        $id = sstr($IN['id'] ?? ''); $DB['earn'][$kinds[$kind]] = array_values(array_filter($DB['earn'][$kinds[$kind]], function ($x) use ($id) { return $x['id'] !== $id; }));
        save_db(); out(200, ['success' => true]);
    }
    if ($uri === 'admin/impersonate' && $m === 'POST') {
        require_admin(); $ui = find_user(sstr($IN['userId'] ?? '')); if ($ui < 0) fail(404, 'Publisher account not found.');
        $t = create_user_session($DB['users'][$ui]['id']); save_db(); out(200, ['success' => true, 'userToken' => $t]);
    }
    if ($uri === 'earn/list' && $m === 'GET') {
        $userId = sstr($Q['userId'] ?? ''); if (!$userId) fail(400, 'User ID is required.');
        require_user($userId); earn_db(); $e = $DB['earn']; $log = $e['ptcLog'][$userId] ?? []; $now = (int)(microtime(true) * 1000); $ads = [];
        foreach ($e['ptcAds'] as $a) {
            if (($a['status'] ?? '') !== 'Active' || (!empty($a['budget']) && $a['clicks'] >= $a['budget'])) continue;
            $last = num($log[$a['id']] ?? 0); $done = $last && $now - $last < 86400000;
            $ads[] = ['id' => $a['id'], 'title' => $a['title'], 'description' => $a['description'], 'reward' => $a['reward'], 'seconds' => $a['seconds'], 'mode' => ($a['mode'] ?? 'frame'), 'done' => (bool)$done, 'nextAt' => $done ? $last + 86400000 : 0];
        }
        $pub = function ($x) { return ['id' => $x['id'], 'title' => $x['title'], 'description' => $x['description'], 'url' => $x['url'], 'maxReward' => $x['maxReward'] ?? '', 'embed' => !empty($x['embed']), 'badge' => $x['badge'] ?? '']; };
        $act = function ($l) { return array_values(array_map(function ($x) { return $x; }, array_filter($l, function ($x) { return ($x['status'] ?? '') === 'Active'; }))); };
        out(200, ['success' => true, 'serverNow' => $now, 'ptcAds' => $ads, 'offerwalls' => array_map($pub, $act($e['offerwalls'])), 'surveys' => array_map($pub, $act($e['surveys'])), 'cpalead' => cpalead_public($userId)]);
    }
    if ($uri === 'earn/ptc/start' && $m === 'POST') {
        $userId = sstr($IN['userId'] ?? ''); if (!$userId) fail(400, 'User ID is required.');
        require_user($userId); earn_db(); $ai = find_idx($DB['earn']['ptcAds'], function ($a) use ($IN) { return $a['id'] === sstr($IN['adId'] ?? ''); });
        $ad = $ai >= 0 ? $DB['earn']['ptcAds'][$ai] : null;
        if (!$ad || $ad['status'] !== 'Active' || (!empty($ad['budget']) && $ad['clicks'] >= $ad['budget'])) fail(404, 'This ad is no longer available.');
        $last = num($DB['earn']['ptcLog'][$userId][$ad['id']] ?? 0); $now = (int)(microtime(true) * 1000);
        if ($last && $now - $last < 86400000) fail(400, 'You already viewed this ad today. Come back tomorrow!');
        if (!rl_hit('ptcstart:' . $userId, 30, 600)) fail(429, 'Too many attempts. Please wait a few minutes.');
        $mode = ($ad['mode'] ?? 'frame') === 'tab' ? 'tab' : 'frame';
        $tok = ptc_session_create($userId, $ad['id'], (int)$ad['seconds'], $mode, $now);
        out(200, ['success' => true, 'token' => $tok, 'url' => $ad['url'], 'seconds' => $ad['seconds'], 'mode' => $mode]);
    }
    if ($uri === 'earn/ptc/claim' && $m === 'POST') {
        $userId = sstr($IN['userId'] ?? ''); if (!$userId) fail(400, 'User ID is required.');
        require_user($userId); earn_db(); $tok = sstr($IN['token'] ?? '');
        $p = ptc_session_read($tok);
        if (!$p || $p['userId'] !== $userId) fail(400, 'Invalid or expired ad session. Please open the ad again.');
        $ai = find_idx($DB['earn']['ptcAds'], function ($a) use ($p) { return $a['id'] === $p['adId']; });
        if ($ai < 0) { ptc_session_delete($tok); fail(404, 'This ad is no longer available.'); }
        $ad = &$DB['earn']['ptcAds'][$ai]; $now = (int)(microtime(true) * 1000);
        $need = (int)$p['seconds'] * 1000;
        if ((int)$p['seconds'] !== (int)$ad['seconds']) $need = max($need, (int)$ad['seconds'] * 1000); // admin raised the timer meanwhile
        if ($now - $p['at'] < $need - 500) fail(400, 'Please keep the ad open for ' . (int)ceil(($need - ($now - $p['at'])) / 1000) . ' more seconds.');
        if (($p['verified'] ?? 0) < $need - 1500) {
            $miss = (int)ceil(($need - ($p['verified'] ?? 0)) / 1000);
            fail(400, ($p['mode'] === 'frame' ? 'Timer only counts while this tab is visible and in focus. ' : 'Timer only counts while you are viewing the ad tab. ') . 'Stay ' . $miss . ' more second' . ($miss === 1 ? '' : 's') . ' and try again.', ['verified' => (int)($p['verified'] ?? 0), 'need' => $need]);
        }
        if (!empty($p['ip']) && $p['ip'] !== client_ip() && !rl_hit('ptcip:' . $userId, 3, 3600)) fail(403, 'Session mismatch. Please open the ad again.');
        ptc_session_delete($tok);
        $last = num($DB['earn']['ptcLog'][$userId][$ad['id']] ?? 0); if ($last && $now - $last < 86400000) fail(400, 'You already viewed this ad today.');
        if (!empty($ad['budget']) && $ad['clicks'] >= $ad['budget']) fail(404, 'This ad is no longer available.');
        $ui = find_user($userId); if ($ui < 0) fail(404, 'User account not found.');
        $u = &$DB['users'][$ui]; $nb = r4(num($u['bal'] ?? 0) + $ad['reward']); $u['bal'] = $nb; $u['balance'] = $nb; $u['earnPtc'] = r4(num($u['earnPtc'] ?? 0) + $ad['reward']);
        $DB['earn']['ptcLog'][$userId][$ad['id']] = $now; $ad['clicks'] = ($ad['clicks'] ?? 0) + 1;
        $DB['earn']['stats']['ptcClicks']++; $DB['earn']['stats']['ptcPaid'] = r4(num($DB['earn']['stats']['ptcPaid']) + $ad['reward']); save_db();
        out(200, ['success' => true, 'reward' => $ad['reward'], 'newBalance' => $nb, 'message' => '+$' . number_format($ad['reward'], 4) . ' added to your balance!', 'nextAt' => $now + 86400000]);
    }
    if ($m === 'GET' && preg_match('#^(short|s)/(.+)$#', $uri, $mm)) {
        $slug = strtolower($mm[2]); $li = find_idx($DB['links'], function ($l) use ($slug) { return lower($l['slug'] ?? '') === $slug; });
        if ($li < 0) fail(404, 'Short link not found.');
        out(200, ['success' => true, 'link' => $DB['links'][$li]]);
    }
}
