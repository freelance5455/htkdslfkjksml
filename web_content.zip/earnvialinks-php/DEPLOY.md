# EarnViaLinks PHP - Deploy, Admin Password & Database Restore

## 1. Requirements
* Apache hosting with PHP 7.4+ (PHP 8.x best), `mod_rewrite` enabled (Hostinger, cPanel, any shared hosting - all have it).
* PHP extensions: `json`, `mbstring`, `openssl` (all default). Nothing else - no Composer, no database server.
* HTTPS (free SSL in your hosting panel).

## 2. Upload (Hostinger / cPanel)
1. Download and unzip `earnvialinks-php.zip` on your computer. You will see `index.html`, `api.php`, `.htaccess`, `lib/`, `data/`, `assets/` ...
2. hPanel / cPanel -> **File Manager** -> open `public_html` (for a sub-domain: its own folder).
3. Upload **all** files and folders into `public_html` (zip upload + "Extract" is fastest). Make sure the hidden file **`.htaccess`** is there (File Manager -> Settings -> "Show hidden files").
4. Make folder `data/` writable: right-click -> Permissions -> **755** (or 775). If you get "Internal server error" while saving, use 775/777 for `data/`.
5. Copy `.env.example` to `.env` and edit it (BASE_URL, ADMIN_PASSKEY, SMTP_*). Never share `.env`.
6. Open `https://yourdomain.com` - the site loads. Open `https://yourdomain.com/api/health` - you should see `"status":"online"`.

Domain points to a sub-folder? Put the files there; `.htaccess` works from any folder.
Nginx (VPS): `location /api { try_files $uri /api.php?$query_string; }`, `location ~ ^/(lib|data)/ { deny all; }`, `location / { try_files $uri /index.html; }`, `location ~ \.php$ { fastcgi_pass ...; }` and pass the `Authorization` header (`fastcgi_param HTTP_AUTHORIZATION $http_authorization;`).

## 3. Admin panel & passwords
* Admin URL: **https://yourdomain.com/realadmin**
* The admin has ONE master "passkey" (no username).
  * **Option A (recommended):** put `ADMIN_PASSKEY=YourStrongPassword` in `.env`. It always works and overrides everything. Change it by editing `.env`.
  * **Option B:** leave it empty. The first time you open `/realadmin` you get a "first-run setup" screen - choose a passkey (min 8 chars). It is stored in `data/database.json` (`settings.adminKey`).
  * Inside the admin panel -> Settings you can also change the passkey (needs the current one).
* **Forgot the admin passkey?** Set `ADMIN_PASSKEY=NewPass123` in `.env` and log in with it. (Or edit `data/database.json` -> `"adminKey"` and set it to `""` to get the setup screen again.)
* Admin login is rate-limited: 6 wrong tries = locked 15 minutes. Admin session lasts 7 days.
* Publishers log in at the site (Log In button). In admin -> Users you can ban, edit balance, and use **Login As** to open any publisher dashboard.
* Old publisher passwords (bcrypt hashes from your old PHP/Node site) keep working. Plain-text passwords in an old file are auto-converted to bcrypt on the user's first login.

## 4. Restoring your old JSON database (users, links, balances, withdrawals)
Your old file is `database.json` (from the old PHP/Node server `data/` folder, or an export from Admin -> Database -> Export).

**Method 1 - copy the file (easiest, do it before the first visitors come):**
1. Upload your old file to `data/` and name it exactly **`database.json`** (replace the existing one if any).
2. Visit the site once. Done - users, links, withdrawals, CPM rates, settings are all there. Missing newer sections (earn, sessions...) are added automatically.

**Method 2 - from the admin panel (site already running):**
1. Open `/realadmin` -> log in -> **Database / Backup** tab -> **Restore / Import JSON** -> choose your old file.
2. It validates the file, saves a safety copy `data/database.pre-restore-<time>.json`, then imports users/links/withdrawals/settings. Your admin passkey and SMTP password are kept.
3. Everyone has to log in again afterwards (old sessions are cleared) - passwords stay the same.

**Method 3 - bad/empty file recovery:** the system automatically falls back to `data/database.backup.json`, then `database.backup.prev.json`, then `database.sample.json` if `database.json` is corrupted.

Test after restore: log in as one old publisher (same email/password as before) and check the balance.

## 5. Backups (important!)
* The site auto-saves `data/database.backup.json` and `database.backup.prev.json` (rotating, at most every 30 s).
* Download a manual backup anytime: Admin -> Database -> **Export Database JSON**. Do this daily/weekly.
* Optional: set `DATA_DIR=/home/USER/earnvialinks-data` in `.env` to keep the database outside `public_html`.
* The `data/` and `lib/` folders are blocked from the web by `.htaccess` (test: `https://yourdomain.com/data/database.json` must show "Forbidden").

## 6. Email (OTP + password reset)
Fill `SMTP_*` in `.env` (or Admin -> Email Settings). Hostinger: host `smtp.hostinger.com`, port `465`, user = your mailbox, password = mailbox password. Use Admin -> Send test email to confirm. Without SMTP, new users cannot receive the signup code (set `EMAIL_VERIFICATION=off` temporarily if needed).

## 7. Earn section (PTC / Offerwalls / Surveys)
Admin -> **Earn: PTC, Offerwalls & Surveys**: add PTC ads (URL, reward, timer, view limit), offerwall and survey links (use `{user_id}` in the URL to pass the publisher's ID). Publishers see them under Dashboard -> Earn. Offerwall/survey completion is not auto-credited yet (needs partner postback - next step).

## 8. Troubleshooting
| Problem | Fix |
|---|---|
| Blank page / 404 on `/dashboard` or short links | `.htaccess` missing or mod_rewrite off |
| `/api/health` shows 404 or downloads PHP | PHP not enabled for the domain; choose PHP 8.x in hosting panel |
| "Internal server error" on login/register | `data/` not writable -> chmod 775 |
| Admin says unauthorized after login | host strips the Authorization header; the included `.htaccess` fixes it - make sure it is uploaded |
| Short link shows `localhost` | set `BASE_URL` in `.env` |
| Changes not visible | clear browser cache once (file names are versioned) |

## Earn: CPAlead + verified PTC (added)

1. Admin panel -> Earn -> **CPAlead**: paste your offerwall URL (put `{user_id}` where the subid goes), click Generate for the secret key, choose payout share %, switch ON, Save.
2. Copy the **Postback URL** shown on that page into CPAlead -> Postback. Use the macro names CPAlead shows you. Parameters accepted: `subid`, `payout`, `virtual_currency`, `lead_id`, `ip_address`, `status`.
3. Paste the redesigned layout/card/CSS (cpalead-offerwall-design.md) into CPAlead -> Offerwall -> Customize.
4. Earn -> **Paid-to-Click**: set the stay timer (5-300 s) and how the ad opens. "Viewer" mode checks the user stayed (timer pauses when the tab is hidden or unfocused; the server counts heartbeats). "New tab" is for sites that refuse framing.
5. PTC sessions are small files in `data/ptc/` (auto-cleaned). Make sure `data/` is writable.

## No .env needed (Site Settings)

Admin -> **Site Settings, Install Check & Backups**:
- **Main domain / Base URL** (empty = auto-detect), optional redirect of www/other domains to it, **email verification ON/OFF**, send a test email.
- **Install Check** lists green/red items with a one-line fix each.
- **Backups**: one automatic copy per day, last 7 kept in `data/backups/`, plus "Download backup now". Restore via the Database tab.
- `.env` is optional; if present its values still win (BASE_URL, EMAIL_VERIFICATION, SMTP_*, ADMIN_PASSKEY, DATA_DIR).
- Optional private data folder: rename `data-path.sample.php` to `data-path.php`, put the folder path inside, copy `database.json` there first.
