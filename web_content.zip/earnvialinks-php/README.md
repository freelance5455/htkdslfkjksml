# EarnViaLinks - PHP version

Pure PHP (7.4+ / 8.x) + JSON-file database. No Node.js, no MySQL, no Composer.

```
index.html, assets/, js/ ...   frontend (React build, unchanged design)
api.php                        the whole backend entry point  (/api/*)
lib/*.php                      backend code
data/database.json             your database (created automatically)
.htaccess                      routing (API -> api.php, everything else -> index.html)
.env                           your settings (copy from .env.example)
```

Read **DEPLOY.md** for step-by-step hosting, admin password and database restore.
