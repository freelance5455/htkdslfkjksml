import{a as Fe}from"./rolldown-runtime-DS2seoW7.js";import{i as Me}from"./vendor-motion-DJytK0Rj.js";
const R=Fe(Me(),1),h=R.createElement,{useState:us,useEffect:ue,useCallback:uc}=R;
const KINDS={ptc:["ptc","Paid-to-Click Ads","ptcAds"],offerwalls:["offerwall","Offerwalls","offerwalls"],surveys:["survey","Surveys","surveys"]};
const blank=k=>k==="ptc"?{title:"",url:"",description:"",reward:"0.01",seconds:"15",budget:"0",mode:"frame",status:"Active"}:{title:"",url:"",description:"",maxReward:"",badge:"",embed:false,status:"Active"};

function Field({label,children}){return h("label",{className:"evl-field"},h("span",null,label),children)}

const gen=()=>{const a=new Uint8Array(18);crypto.getRandomValues(a);return Array.from(a,b=>b.toString(16).padStart(2,"0")).join("")};
function CpaPanel({hdr,flash}){
  const [d,setD]=us(null),[f,setF]=us(null),[saving,setSaving]=us(false);
  const load=uc(async()=>{try{const r=await fetch("/api/admin/earn/cpalead",{headers:hdr}),j=await r.json();if(j.success){setD(j);setF(j.config)}else flash(j.message||"Failed to load.")}catch{flash("Network error.")}},[]);
  ue(()=>{load()},[load]);
  if(!d||!f)return h("p",{className:"text-sm text-slate-500"},"Loading…");
  const set=(k,v)=>setF(x=>({...x,[k]:v}));
  const inp=(k,props={})=>h("input",{className:"evl-input",value:f[k]??"",onChange:e=>set(k,e.target.value),...props});
  const save=async e=>{e.preventDefault();setSaving(true);
    try{const r=await fetch("/api/admin/earn/cpalead/save",{method:"POST",headers:hdr,body:JSON.stringify({config:f})}),j=await r.json();
      if(!r.ok||!j.success){flash(j.message||"Save failed.");return}
      flash(j.warning?("Saved. ⚠ "+j.warning):"CPAlead settings saved.");load()}catch{flash("Network error.")}finally{setSaving(false)}};
  const pb=d.origin+"/api/postback/cpalead?key="+(f.secret||"YOUR_SECRET")+"&subid={subid}&payout={payout}&virtual_currency={virtual_currency}&lead_id={lead_id}&ip_address={ip_address}";
  const st=d.stats||{};
  return h("div",{className:"space-y-6","data-testid":"admin-cpalead"},
    h("div",{className:"evl-admin-stats"},[["Conversions credited",st.credits||0],["Paid to users","$"+Number(st.paid||0).toFixed(4)],["Reversed",st.reversed||0],["Status",f.enabled?"ON":"OFF"]].map(([l,v])=>h("div",{key:l,className:"evl-admin-stat"},h("span",null,l),h("strong",{className:"font-data"},v)))),
    h("form",{onSubmit:save,className:"evl-form bg-white rounded-2xl border border-slate-200 shadow-sm"},
      h(Field,{label:"Show CPAlead offerwall to users"},h("select",{className:"evl-input",value:f.enabled?"1":"0",onChange:e=>set("enabled",e.target.value==="1")},h("option",{value:"0"},"OFF"),h("option",{value:"1"},"ON"))),
      h(Field,{label:"Tab title shown to users"},inp("title",{maxLength:80})),
      h(Field,{label:"Short description"},inp("description",{maxLength:300})),
      h(Field,{label:"Badge text (optional)"},inp("badge",{maxLength:30})),
      h(Field,{label:"CPAlead offerwall URL: put {user_id} where the subid goes"},inp("offerwallUrl",{placeholder:"https://… (copy from CPAlead, set subid={user_id})"})),
      h(Field,{label:"Secret key (protects your postback)"},h("div",{style:{display:"flex",gap:".5rem"}},inp("secret",{placeholder:"click Generate"}),h("button",{type:"button",className:"evl-btn-ghost",onClick:()=>set("secret",gen())},"Generate"))),
      h(Field,{label:"How users get paid"},h("select",{className:"evl-input",value:f.rewardMode,onChange:e=>set("rewardMode",e.target.value)},h("option",{value:"payout"},"Share of USD payout (recommended)"),h("option",{value:"points"},"Convert CPAlead points (virtual_currency)"))),
      f.rewardMode==="payout"?h(Field,{label:"User share of payout (%), the rest is your profit"},inp("sharePercent",{type:"number",min:"0",max:"100",step:"1"}))
        :h(Field,{label:"Points per $1"},inp("pointsPerUsd",{type:"number",min:"1"})),
      h(Field,{label:"Safety limit: max credit per conversion (USD)"},inp("maxCreditUsd",{type:"number",min:"0.01",step:"0.01"})),
      h(Field,{label:"Allowed postback IPs (optional, comma separated)"},inp("allowedIps",{placeholder:"leave empty unless CPAlead gave you IPs"})),
      h("div",{className:"evl-form-actions"},h("button",{type:"submit",disabled:saving,className:"vues-button-primary evl-btn"},saving?"Saving…":"Save CPAlead settings"))),
    h("div",{className:"bg-white rounded-2xl border border-slate-200 shadow-sm",style:{padding:"1.25rem"}},
      h("strong",{className:"font-display"},"Postback URL (paste in CPAlead → Postback)"),
      h("div",{className:"text-xs font-data",style:{wordBreak:"break-all",background:"#f8fafc",padding:".75rem",borderRadius:".75rem",marginTop:".5rem",userSelect:"all"}},pb),
      h("p",{className:"text-xs text-slate-500 font-sans",style:{marginTop:".5rem"}},"Accepted parameters: subid, payout, virtual_currency, lead_id (or transaction_id), ip_address, status. Replace the {…} macros with the exact macro names shown on CPAlead's postback page. Duplicate lead IDs are ignored; a status of reversed/chargeback deducts the credit.")),
    h("div",{className:"bg-white rounded-2xl border border-slate-200 shadow-sm",style:{padding:"1.25rem",overflowX:"auto"}},
      h("strong",{className:"font-display"},"Recent conversions"),
      d.log.length===0?h("p",{className:"text-xs text-slate-500",style:{marginTop:".5rem"}},"No conversions received yet."):
      h("table",{className:"text-xs font-data",style:{width:"100%",marginTop:".5rem",borderCollapse:"collapse"}},
        h("thead",null,h("tr",null,["Time","User","Lead ID","Credited","Status"].map(x=>h("th",{key:x,style:{textAlign:"left",padding:".35rem .5rem",borderBottom:"1px solid #e2e8f0"}},x)))),
        h("tbody",null,d.log.map(x=>h("tr",{key:x.id},[(x.at||"").slice(0,16).replace("T"," "),x.userEmail||x.userId,x.txid,"$"+Number(x.usd||0).toFixed(4),x.blocked?"blocked":x.reversed?"reversed":"ok"].map((c,i)=>h("td",{key:i,style:{padding:".35rem .5rem",borderBottom:"1px solid #f1f5f9"}},c))))))),
    h("div",{className:"bg-white rounded-2xl border border-slate-200 shadow-sm",style:{padding:"1.25rem",overflowX:"auto"}},
      h("strong",{className:"font-display"},"Postback attempts (last 50, including failed)"),
      h("p",{className:"text-xs text-slate-500 font-sans",style:{marginTop:".25rem"}},"If a user was not credited, the reason is shown here. Empty table = CPAlead is not reaching this URL at all."),
      !(d.attempts&&d.attempts.length)?h("p",{className:"text-xs text-slate-500",style:{marginTop:".5rem"}},"No postback calls received yet."):
      h("table",{className:"text-xs font-data",style:{width:"100%",marginTop:".5rem",borderCollapse:"collapse"}},
        h("thead",null,h("tr",null,["Time","Result","Reason","Received data"].map(x=>h("th",{key:x,style:{textAlign:"left",padding:".35rem .5rem",borderBottom:"1px solid #e2e8f0"}},x)))),
        h("tbody",null,d.attempts.map((x,n)=>h("tr",{key:n},[(x.at||"").slice(0,19).replace("T"," "),x.ok?"OK":"FAILED",x.note,x.query].map((c,i)=>h("td",{key:i,style:{padding:".35rem .5rem",borderBottom:"1px solid #f1f5f9",color:i===1?(x.ok?"#16a34a":"#dc2626"):undefined,wordBreak:"break-all"}},c))))))));
}

export const EarnAdmin=({token})=>{
  const [tab,setTab]=us("ptc"),[earn,setEarn]=us(null),[form,setForm]=us(null),[msg,setMsg]=us(""),[saving,setSaving]=us(false);
  const hdr={"Content-Type":"application/json",Authorization:"Bearer "+token};
  const load=uc(async()=>{
    try{const r=await fetch("/api/admin/earn",{headers:hdr}),j=await r.json();
      if(j.success)setEarn(j.earn);else setMsg(j.message||"Failed to load Earn data.")}catch{setMsg("Network error.")}
  },[token]);
  ue(()=>{load()},[load]);
  const flash=t=>{setMsg(t);setTimeout(()=>setMsg(""),t.length>60?9000:3500)};
  const [kind,label,key]=KINDS[tab]||KINDS.ptc;
  const items=earn&&earn[key]||[];
  const save=async e=>{
    e.preventDefault();setSaving(true);
    try{const r=await fetch("/api/admin/earn/save",{method:"POST",headers:hdr,body:JSON.stringify({kind,item:form})}),j=await r.json();
      if(!r.ok||!j.success){flash(j.message||"Save failed.");return}
      setForm(null);flash(j.warning?("Saved. ⚠ "+j.warning):"Saved successfully.");load()}catch{flash("Network error.")}finally{setSaving(false)}
  };
  const toggle=async it=>{
    const r=await fetch("/api/admin/earn/save",{method:"POST",headers:hdr,body:JSON.stringify({kind,item:{...it,status:it.status==="Active"?"Paused":"Active"}})});
    r.ok?load():flash("Update failed.");
  };
  const del=async it=>{
    if(!confirm('Delete "'+it.title+'"?'))return;
    const r=await fetch("/api/admin/earn/delete",{method:"POST",headers:hdr,body:JSON.stringify({kind,id:it.id})});
    r.ok?load():flash("Delete failed.");
  };
  const set=(k,v)=>setForm(f=>({...f,[k]:v}));
  const inp=(k,props={})=>h("input",{className:"evl-input",value:form[k]??"",onChange:e=>set(k,e.target.value),...props});
  const st=earn&&earn.stats||{};
  return h("div",{className:"space-y-6","data-testid":"admin-earn-section"},
    h("div",{className:"evl-admin-stats"},
      [["PTC Ads",earn?earn.ptcAds.length:0],["PTC Views Paid",st.ptcClicks||0],["PTC Paid Out","$"+Number(st.ptcPaid||0).toFixed(4)],["Offerwalls / Surveys",(earn?earn.offerwalls.length:0)+" / "+(earn?earn.surveys.length:0)]]
        .map(([l,v])=>h("div",{key:l,className:"evl-admin-stat"},h("span",null,l),h("strong",{className:"font-data"},v)))),
    h("div",{className:"evl-earn-tabs"},[...Object.entries(KINDS),["cpalead",[0,"CPAlead"]]].map(([k,[,l]])=>h("button",{key:k,type:"button","data-testid":"admin-earn-tab-"+k,onClick:()=>{setTab(k);setForm(null)},className:`px-2 sm:px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all font-data cursor-pointer ${tab===k?"bg-[#6c14ff] text-white shadow-sm":"text-slate-600 hover:text-slate-900 hover:bg-white"}`},l))),
    msg&&h("div",{className:"evl-earn-msg evl-ok","data-testid":"admin-earn-msg"},msg),
    tab==="cpalead"?h(CpaPanel,{hdr,flash}):h(R.Fragment,null,
    h("div",{className:"flex items-center justify-between gap-3"},
      h("h2",{className:"text-lg font-bold text-slate-900 font-display"},label+" ("+items.length+")"),
      !form&&h("button",{type:"button","data-testid":"admin-earn-add-btn",className:"vues-button-primary evl-btn",onClick:()=>setForm(blank(tab))},"+ Add "+(tab==="ptc"?"PTC Ad":tab==="offerwalls"?"Offerwall":"Survey"))),
    form&&h("form",{onSubmit:save,className:"evl-form bg-white rounded-2xl border border-slate-200 shadow-sm","data-testid":"admin-earn-form"},
      h(Field,{label:"Title"},inp("title",{required:true,maxLength:120,"data-testid":"earn-form-title"})),
      h(Field,{label:tab==="ptc"?"Ad URL (https://…)":"Provider URL (use {user_id} for the publisher ID)"},inp("url",{required:true,placeholder:"https://","data-testid":"earn-form-url"})),
      h(Field,{label:"Short description"},inp("description",{maxLength:400})),
      tab==="ptc"?h(R.Fragment,null,
        h(Field,{label:"Reward per view (USD)"},inp("reward",{type:"number",step:"0.0001",min:"0","data-testid":"earn-form-reward"})),
        h(Field,{label:"Stay timer (seconds, 5–300) — user must stay this long"},inp("seconds",{type:"number",min:"5",max:"300","data-testid":"earn-form-seconds"})),
        h(Field,{label:"How the ad opens"},h("select",{className:"evl-input",value:form.mode||"frame",onChange:e=>set("mode",e.target.value)},h("option",{value:"frame"},"Inside our viewer (strict: timer pauses if user leaves the tab)"),h("option",{value:"tab"},"New tab (for sites that block framing: user must stay on the ad tab)"))),
        h(Field,{label:"Max total views (0 = unlimited)"},inp("budget",{type:"number",min:"0"})))
      :h(R.Fragment,null,
        h(Field,{label:"Highest reward label (e.g. $50)"},inp("maxReward")),
        h(Field,{label:"Badge text (e.g. Top Paying)"},inp("badge")),
        h(Field,{label:"Open inside the site (iframe)"},h("select",{className:"evl-input",value:form.embed?"1":"0",onChange:e=>set("embed",e.target.value==="1")},h("option",{value:"0"},"No — open in new tab"),h("option",{value:"1"},"Yes — embed iframe")))),
      h(Field,{label:"Status"},h("select",{className:"evl-input",value:form.status,onChange:e=>set("status",e.target.value)},h("option",{value:"Active"},"Active"),h("option",{value:"Paused"},"Paused"))),
      h("div",{className:"evl-form-actions"},
        h("button",{type:"submit",disabled:saving,"data-testid":"earn-form-save",className:"vues-button-primary evl-btn"},saving?"Saving…":form.id?"Update":"Create"),
        h("button",{type:"button",className:"evl-btn-ghost",onClick:()=>setForm(null)},"Cancel"))),
    !earn?h("p",{className:"text-sm text-slate-500"},"Loading…")
    :items.length===0?h("div",{className:"evl-earn-empty"},h("p",null,"Nothing added yet. Click “Add” to create the first entry."))
    :h("div",{className:"evl-admin-list"},items.map(it=>h("div",{key:it.id,className:"evl-admin-row","data-testid":"admin-earn-row-"+it.id},
      h("div",{className:"evl-admin-row-main"},
        h("div",{className:"flex items-center gap-2"},h("strong",{className:"font-display"},it.title),
          h("span",{className:"evl-pill "+(it.status==="Active"?"":"evl-pill-off")},it.status)),
        h("div",{className:"text-xs text-slate-500 font-data evl-trunc"},it.url),
        h("div",{className:"text-xs text-slate-600 font-data"},tab==="ptc"
          ?"$"+Number(it.reward).toFixed(4)+" · "+it.seconds+"s · "+(it.mode==="tab"?"new tab":"viewer")+" · views "+(it.clicks||0)+(it.budget?" / "+it.budget:" / ∞")
          :(it.maxReward?"Up to "+it.maxReward+" · ":"")+(it.embed?"iframe":"new tab"))),
      h("div",{className:"evl-admin-row-actions"},
        h("button",{type:"button",className:"evl-btn-ghost",onClick:()=>setForm({...it})},"Edit"),
        h("button",{type:"button",className:"evl-btn-ghost",onClick:()=>toggle(it)},it.status==="Active"?"Pause":"Resume"),
        h("button",{type:"button",className:"evl-btn-ghost evl-danger",onClick:()=>del(it)},"Delete")))))));
};
