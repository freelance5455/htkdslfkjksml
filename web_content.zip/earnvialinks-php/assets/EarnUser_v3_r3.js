import{a as Fe}from"./rolldown-runtime-DS2seoW7.js";import{i as Me}from"./vendor-motion-DJytK0Rj.js";
const R=Fe(Me(),1),h=R.createElement,{useState:us,useEffect:ue,useRef:ur,useCallback:uc}=R;
const money=(n,d=4)=>"$"+Number(n||0).toFixed(d);
const fillUrl=(u,id)=>String(u||"").replace(/\{(user_?id|uid|subid)\}/gi,encodeURIComponent(id));
const fmtLeft=ms=>{const m=Math.max(0,Math.ceil(ms/6e4)),H=Math.floor(m/60);return H>0?`${H}h ${m%60}m`:`${m}m`};


const SANDBOX="allow-scripts allow-same-origin allow-forms";
const isVisible=()=>document.visibilityState==="visible"&&document.hasFocus();
const post=(u,b)=>fetch(u,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(b)}).then(r=>r.json().then(j=>({ok:r.ok,j})));

function PtcViewer({user,session,onClaimed,onClose}){
  const need=session.seconds,mode=session.mode;
  const [left,setLeft]=us(need),[paused,setPaused]=us(false),[ready,setReady]=us(false),[busy,setBusy]=us(false),[note,setNote]=us("");
  const counted=ur(0),last=ur(performance.now()),finalSent=ur(false),srv=ur(0),dead=ur(false);
  const ping=uc(async()=>{
    try{const {ok,j}=await post("/api/earn/ptc/ping",{userId:user.id,token:session.token,visible:isVisible()});
      if(ok&&j.success){srv.current=j.verified/1000;counted.current=Math.min(counted.current,srv.current+2.5);return j}
      if(!ok&&j&&j.message&&!dead.current){dead.current=true;setNote(j.message)}
    }catch{}
    return null;
  },[user.id,session.token]);
  ue(()=>{
    const tick=setInterval(()=>{
      const n=performance.now(),dt=Math.min(n-last.current,500);last.current=n;
      const vis=isVisible(),counting=mode==="frame"?vis:!vis;
      setPaused(!counting);
      if(counting&&!ready)counted.current=Math.min(need,counted.current+dt/1000);
      const rem=Math.max(0,Math.ceil(need-counted.current-0.001));
      setLeft(rem);
      if(rem===0&&!finalSent.current&&!ready){
        finalSent.current=true;
        ping().then(j=>{
          if(j&&j.need-j.verified<=1500)setReady(true);
          else{finalSent.current=false;if(j)counted.current=Math.min(counted.current,j.verified/1000)}
        });
      }
    },250);
    const hb=setInterval(()=>{if(!ready)ping()},2000);
    ping();
    return()=>{clearInterval(tick);clearInterval(hb)};
  },[ready,ping,need,mode]);
  const claim=async()=>{
    if(!ready||busy)return;setBusy(true);setNote("");
    try{const {ok,j}=await post("/api/earn/ptc/claim",{userId:user.id,token:session.token});
      if(ok&&j.success){onClaimed(j);return}
      if(j&&j.verified!==undefined){counted.current=j.verified/1000;finalSent.current=false;setReady(false);setNote(j.message)}
      else{setNote(j.message||"Could not credit this ad.");onClose(true)}
    }catch{setNote("Network error. Please try again.")}finally{setBusy(false)}
  };
  const pct=Math.min(100,Math.round((need-left)/need*100));
  const status=ready?"Verified ✓ — claim your reward":paused
    ?(mode==="frame"?"Paused — keep this tab open and in focus":"Paused — go to the ad tab and stay there")
    :(mode==="frame"?"Stay on this page… reward unlocks in "+left+"s":"Stay on the ad tab… reward unlocks in "+left+"s");
  const bar=h("div",{className:"evl-viewer-bar"},
    h("div",{className:"evl-viewer-info"},
      h("strong",{className:"font-display"},session.ad.title),
      h("span",{className:"evl-viewer-status"+(paused&&!ready?" evl-viewer-paused":"")+(ready?" evl-viewer-ready":"")},status),
      h("div",{className:"evl-viewer-track"},h("div",{className:"evl-viewer-fill",style:{width:pct+"%"}}))),
    h("div",{className:"evl-active-actions"},
      mode==="tab"&&h("a",{href:session.url,target:"_blank",rel:"noopener noreferrer",className:"evl-btn-ghost"},"Reopen ad"),
      h("button",{type:"button","data-testid":"ptc-claim-btn",disabled:!ready||busy,onClick:claim,className:"vues-button-primary evl-btn"},ready?"Claim "+money(session.ad.reward):left+"s"),
      h("button",{type:"button",className:"evl-btn-ghost",onClick:()=>onClose(false)},"Close")));
  if(mode==="frame")return h("div",{className:"evl-viewer","data-testid":"ptc-viewer"},bar,
    note&&h("div",{className:"evl-viewer-note"},note),
    h("iframe",{src:session.url,title:session.ad.title,className:"evl-viewer-frame",sandbox:SANDBOX,referrerPolicy:"no-referrer"}));
  return h("div",{className:"evl-viewer evl-viewer-tabmode","data-testid":"ptc-viewer"},h("div",{className:"evl-viewer-card"},bar,
    note&&h("div",{className:"evl-viewer-note"},note),
    h("p",{className:"text-xs text-slate-500 font-sans",style:{marginTop:".75rem"}},"The ad opened in a new tab. The timer only counts while you are on that tab — come back here when it reaches 0 to claim.")));
}

function PtcCard({ad,onOpen,busy}){
  return h("div",{className:"evl-earn-card","data-testid":"ptc-card-"+ad.id},
    h("div",{className:"evl-earn-card-top"},
      h("span",{className:"evl-card-ico"},"▶"),h("span",{className:"evl-pill"},"Paid to Click"),
      h("span",{className:"evl-reward font-data"},money(ad.reward))),
    h("h3",{className:"evl-card-title font-display"},ad.title),
    ad.description&&h("p",{className:"evl-card-desc"},ad.description),
    h("div",{className:"evl-card-meta font-data"},"Stay for "+ad.seconds+"s · "+(ad.mode==="tab"?"opens in new tab":"opens here")),
    ad.done
      ?h("button",{disabled:!0,className:"evl-btn-ghost",type:"button"},"Viewed ✓ · back in "+fmtLeft(ad.nextAt-Date.now()))
      :h("button",{className:"vues-button-primary evl-btn","data-testid":"ptc-view-"+ad.id,disabled:busy,onClick:()=>onOpen(ad),type:"button"},"View Ad & Earn"));
}

function ProviderCard({item,kind,onOpen}){
  return h("div",{className:"evl-earn-card","data-testid":kind+"-card-"+item.id},
    h("div",{className:"evl-earn-card-top"},
      h("span",{className:"evl-card-ico"},kind==="offerwall"?"★":"✎"),h("span",{className:"evl-pill"},item.badge||(kind==="offerwall"?"Offerwall":"Survey")),
      item.maxReward&&h("span",{className:"evl-reward font-data"},"Up to "+item.maxReward)),
    h("h3",{className:"evl-card-title font-display"},item.title),
    item.description&&h("p",{className:"evl-card-desc"},item.description),
    h("button",{className:"vues-button-primary evl-btn","data-testid":kind+"-open-"+item.id,onClick:()=>onOpen(item),type:"button"},kind==="offerwall"?"Open Offerwall":"Start Surveys"));
}

function Empty({title,text}){
  return h("div",{className:"evl-earn-empty","data-testid":"earn-empty"},
    h("div",{className:"evl-earn-empty-ico"},"✦"),
    h("h3",{className:"font-display"},title),
    h("p",null,text),
    h("span",{className:"evl-pill"},"No tasks available right now — coming soon"));
}

export const EarnPanel=({user,updateUser})=>{
  const [tab,setTab]=us("ptc"),[data,setData]=us(null),[err,setErr]=us(""),[busy,setBusy]=us(false);
  const [session,setSession]=us(null),[msg,setMsg]=us(null),[frame,setFrame]=us(null);
  const load=uc(async()=>{
    try{const r=await fetch("/api/earn/list?userId="+encodeURIComponent(user.id)),j=await r.json();
      if(!r.ok||!j.success){setErr(j.message||"Could not load Earn tasks.");return}
      setErr("");setData(j)}catch{setErr("Network error. Please try again.")}
  },[user.id]);
  ue(()=>{load()},[load]);
  const flash=(type,text)=>{setMsg({type,text});setTimeout(()=>setMsg(null),4500)};
  const openPtc=async ad=>{
    if(busy||session)return;
    setBusy(true);
    const win=ad.mode==="tab"?window.open("about:blank","_blank"):null;
    try{
      const {ok,j}=await post("/api/earn/ptc/start",{userId:user.id,adId:ad.id});
      if(!ok||!j.success){if(win)win.close();flash("error",j.message||"Could not open this ad.");load();return}
      if(j.mode==="tab"){if(win)win.location.href=j.url;else window.open(j.url,"_blank")}
      else if(win)win.close();
      setSession({ad,token:j.token,url:j.url,seconds:j.seconds,mode:j.mode});
    }catch{if(win)win.close();flash("error","Network error. Please try again.")}
    finally{setBusy(false)}
  };
  const claimed=j=>{
    updateUser&&updateUser({...user,bal:j.newBalance,balance:j.newBalance});
    flash("success",j.message);setSession(null);load();
  };
  const openProvider=it=>{
    const u=fillUrl(it.url,user.id);
    if(it.embed)setFrame({title:it.title,url:u});else window.open(u,"_blank","noopener,noreferrer");
  };
  const cpa=data&&data.cpalead,tabs=[["ptc","Paid to Click"],...(cpa?[["cpalead",cpa.title.length>16?"CPAlead":cpa.title]]:[]),["offerwalls","Offerwalls"],["surveys","Surveys"]];
  const body=()=>{
    if(err)return h("div",{className:"evl-earn-empty"},h("p",null,err),h("button",{className:"evl-btn-ghost",onClick:load,type:"button"},"Retry"));
    if(!data)return h("div",{className:"evl-earn-empty"},h("p",null,"Loading tasks…"));
    if(tab==="cpalead"&&cpa)return h("div",{className:"evl-cpa-wrap","data-testid":"cpalead-wall"},
      h("div",{className:"evl-frame-bar"},h("div",null,h("strong",{className:"font-display"},cpa.title),cpa.description&&h("div",{className:"text-xs text-slate-500 font-sans"},cpa.description)),cpa.badge&&h("span",{className:"evl-pill"},cpa.badge)),
      h("iframe",{src:cpa.url,title:cpa.title,className:"evl-cpa-frame",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox",referrerPolicy:"no-referrer-when-downgrade"}));
    if(tab==="ptc")return data.ptcAds.length
      ?h("div",{className:"evl-cards"},data.ptcAds.map(a=>h(PtcCard,{key:a.id,ad:a,onOpen:openPtc,busy:busy||!!session})))
      :h(Empty,{title:"Paid to Click",text:"View advertiser websites for a few seconds and get paid for every verified click."});
    const list=tab==="offerwalls"?data.offerwalls:data.surveys,kind=tab==="offerwalls"?"offerwall":"survey";
    return list.length
      ?h("div",{className:"evl-cards"},list.map(i=>h(ProviderCard,{key:i.id,item:i,kind,onOpen:openProvider})))
      :h(Empty,{title:tab==="offerwalls"?"Offerwalls":"Surveys",text:tab==="offerwalls"?"Complete offers from our partner walls such as app installs and sign-ups to earn rewards.":"Share your opinion in short surveys and earn money for every completed one."});
  };
  const nAds=data?data.ptcAds.filter(a=>!a.done).length:0,pot=data?data.ptcAds.filter(a=>!a.done).reduce((t,a)=>t+a.reward,0):0;
  const tiles=[["Ads available",String(nAds),"to view today"],["Potential today",money(pot,2),"from Paid to Click"],["Offerwalls / Surveys",data?(data.offerwalls.length+(data.cpalead?1:0))+" / "+data.surveys.length:"–","partners live"]];
  return h("div",{className:"space-y-6 animate-fade-in","data-testid":"earn-section"},
    h("div",{className:"evl-earn-stats"},tiles.map(([l,v,s])=>h("div",{key:l,className:"evl-earn-stat"},h("span",null,l),h("strong",{className:"font-data"},v),h("em",null,s)))),
    h("div",{className:"bg-white rounded-2xl border border-slate-200 shadow-sm evl-earn-head"},
      h("h2",{className:"text-xl font-bold text-slate-900 font-display"},"Earn More"),
      h("p",{className:"text-xs text-slate-500 font-sans"},"Paid ads, offerwalls and surveys — extra ways to grow your balance besides link shortening."),
      h("div",{className:"evl-earn-tabs",style:{marginTop:"1rem"}},tabs.map(([k,l])=>h("button",{key:k,type:"button","data-testid":"earn-subtab-"+k,onClick:()=>setTab(k),className:`px-2 sm:px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all font-data cursor-pointer ${tab===k?"bg-[#6c14ff] text-white shadow-sm":"text-slate-600 hover:text-slate-900 hover:bg-white"}`},l)))),
    msg&&h("div",{"data-testid":"earn-message",className:"evl-earn-msg "+(msg.type==="success"?"evl-ok":"evl-bad")},msg.text),
    session&&h(PtcViewer,{user,session,onClaimed:claimed,onClose:failed=>{setSession(null);if(failed)load()}}),
    body(),
    frame&&h("div",{className:"evl-frame-wrap","data-testid":"earn-frame"},
      h("div",{className:"evl-frame-bar"},h("strong",{className:"font-display"},frame.title),
        h("button",{type:"button",className:"evl-btn-ghost",onClick:()=>setFrame(null)},"Close")),
      h("iframe",{src:frame.url,title:frame.title,className:"evl-frame",allow:"clipboard-write"})));
};
