import{a as Fe}from"./rolldown-runtime-DS2seoW7.js";import{i as Me}from"./vendor-motion-DJytK0Rj.js";
const R=Fe(Me(),1),h=R.createElement,{useState:us,useEffect:ue,useCallback:uc}=R;
const COL={ok:["#dcfce7","#15803d","OK"],warn:["#fef3c7","#b45309","Check"],bad:["#fee2e2","#b91c1c","Fix"]};
function Field({label,hint,children}){return h("label",{className:"evl-field"},h("span",null,label),children,hint&&h("small",{className:"text-xs text-slate-500",style:{display:"block",marginTop:".25rem"}},hint))}
export const SiteAdmin=({token})=>{
  const hdr={"Content-Type":"application/json",Authorization:"Bearer "+token};
  const [site,setSite]=us(null),[f,setF]=us(null),[checks,setChecks]=us(null),[backups,setBackups]=us([]),[msg,setMsg]=us(""),[saving,setSaving]=us(false),[to,setTo]=us(""),[mailBusy,setMailBusy]=us(false);
  const flash=t=>{setMsg(t);setTimeout(()=>setMsg(""),t.length>70?10000:4000)};
  const loadChecks=uc(async()=>{try{const r=await fetch("/api/admin/install-check",{headers:hdr}),j=await r.json();if(j.success){setChecks(j.checks);setBackups(j.backups)}}catch{}},[token]);
  const load=uc(async()=>{try{const r=await fetch("/api/admin/site",{headers:hdr}),j=await r.json();if(j.success){setSite(j.site);setF({baseUrl:j.site.baseUrl,forceMainDomain:j.site.forceMainDomain,emailVerification:j.site.emailVerification})}else flash(j.message||"Failed to load.")}catch{flash("Network error.")}loadChecks()},[token]);
  ue(()=>{load()},[load]);
  const save=async e=>{e.preventDefault();setSaving(true);
    try{const r=await fetch("/api/admin/site/save",{method:"POST",headers:hdr,body:JSON.stringify({site:f})}),j=await r.json();
      if(!r.ok||!j.success){flash(j.message||"Save failed.");return}
      setSite(j.site);flash(j.warning?"Saved. "+j.warning:"Site settings saved.");loadChecks()}catch{flash("Network error.")}finally{setSaving(false)}};
  const dl=async file=>{try{const r=await fetch("/api/admin/backup/download"+(file?"?file="+encodeURIComponent(file):""),{headers:hdr});if(!r.ok){flash("Download failed.");return}
    const b=await r.blob(),a=document.createElement("a");a.href=URL.createObjectURL(b);a.download=file?"earnvialinks-"+file:"earnvialinks-backup-"+new Date().toISOString().slice(0,10)+".json";document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),4000)}catch{flash("Network error.")}};
  const testMail=async()=>{if(!to)return flash("Enter a recipient email first.");setMailBusy(true);
    try{const r=await fetch("/api/auth/test-smtp",{method:"POST",headers:hdr,body:JSON.stringify({testEmail:to})}),j=await r.json();flash(j.message||"Done.");loadChecks()}catch{flash("Network error.")}finally{setMailBusy(false)}};
  if(!site||!f)return h("p",{className:"text-sm text-slate-500"},msg||"Loading…");
  const set=(k,v)=>setF(x=>({...x,[k]:v})),card="bg-white rounded-2xl border border-slate-200 shadow-sm",pad={padding:"1.25rem"};
  return h("div",{className:"space-y-6","data-testid":"admin-site"},
    msg&&h("div",{className:"evl-earn-msg evl-ok"},msg),
    h("form",{onSubmit:save,className:"evl-form "+card},
      h("h2",{className:"text-lg font-bold text-slate-900 font-display"},"Site Settings"),
      h(Field,{label:"Main domain / Base URL",hint:site.envBaseUrl?"A BASE_URL in .env is set and takes priority over this field.":"Leave empty for auto-detect (currently: "+site.detected+"). Short links will use this domain."},
        h("input",{className:"evl-input",value:f.baseUrl,placeholder:"https://yourdomain.com  (empty = auto-detect)",onChange:e=>set("baseUrl",e.target.value)})),
      h(Field,{label:"Redirect other domains (www etc.) to the main domain",hint:"Edits .htaccess for you. Open the admin from the main domain first. API/postbacks are not redirected."},
        h("select",{className:"evl-input",value:f.forceMainDomain?"1":"0",onChange:e=>set("forceMainDomain",e.target.value==="1")},h("option",{value:"0"},"No"),h("option",{value:"1"},"Yes, force main domain"))),
      h(Field,{label:"Email verification (OTP) on signup",hint:site.envEmailVerification?"EMAIL_VERIFICATION in .env is set and takes priority.":"Turn OFF only if email sending is broken; users will then sign up without a code."},
        h("select",{className:"evl-input",value:f.emailVerification?"1":"0",onChange:e=>set("emailVerification",e.target.value==="1")},h("option",{value:"1"},"ON"),h("option",{value:"0"},"OFF"))),
      h("div",{className:"evl-form-actions"},h("button",{type:"submit",disabled:saving,className:"vues-button-primary evl-btn"},saving?"Saving…":"Save Site Settings"))),
    h("div",{className:card,style:pad},
      h("strong",{className:"font-display"},"Email test"),
      h("p",{className:"text-xs text-slate-500 font-sans",style:{margin:".35rem 0 .6rem"}},"SMTP host/user/password are edited in the Email tab. Send a test with the saved settings:"),
      h("div",{style:{display:"flex",gap:".5rem",flexWrap:"wrap"}},h("input",{className:"evl-input",style:{flex:"1 1 220px"},placeholder:"you@example.com",value:to,onChange:e=>setTo(e.target.value)}),
        h("button",{type:"button",disabled:mailBusy,className:"evl-btn-ghost",onClick:testMail},mailBusy?"Sending…":"Send test email"))),
    h("div",{className:card,style:pad},
      h("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center",gap:".5rem"}},h("strong",{className:"font-display"},"Install Check"),h("button",{type:"button",className:"evl-btn-ghost",onClick:loadChecks},"Re-check")),
      !checks?h("p",{className:"text-xs text-slate-500"},"Checking…"):h("div",{style:{marginTop:".6rem",display:"grid",gap:".5rem"}},checks.map(c=>{const [bg,fg,t]=COL[c.status]||COL.warn;
        return h("div",{key:c.id,style:{display:"flex",gap:".7rem",alignItems:"flex-start",padding:".6rem .75rem",borderRadius:".75rem",border:"1px solid #e2e8f0"}},
          h("span",{style:{background:bg,color:fg,fontWeight:800,fontSize:".65rem",padding:".2rem .55rem",borderRadius:"99px",flex:"0 0 auto",marginTop:".1rem"}},t),
          h("div",{style:{minWidth:0}},h("div",{className:"text-sm font-bold text-slate-800"},c.label),h("div",{className:"text-xs text-slate-500",style:{wordBreak:"break-all"}},c.detail),c.status!=="ok"&&c.fix&&h("div",{className:"text-xs",style:{color:fg,marginTop:".2rem"}},"→ "+c.fix)))}))),
    h("div",{className:card,style:pad},
      h("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center",gap:".5rem",flexWrap:"wrap"}},h("strong",{className:"font-display"},"Backups (last 7 days, automatic daily)"),h("button",{type:"button",className:"vues-button-primary evl-btn",onClick:()=>dl("")},"Download backup now")),
      h("p",{className:"text-xs text-slate-500 font-sans",style:{margin:".4rem 0"}},"Stored in your private data folder on this hosting account. Also keep a downloaded copy on your computer. Restore with the Database tab."),
      backups.length===0?h("p",{className:"text-xs text-slate-500"},"No automatic backup yet; one is created on the next visit."):
      h("div",{style:{display:"grid",gap:".4rem"}},backups.map(b=>h("div",{key:b.name,style:{display:"flex",justifyContent:"space-between",gap:".5rem",alignItems:"center",padding:".45rem .7rem",border:"1px solid #e2e8f0",borderRadius:".6rem"}},
        h("span",{className:"text-xs font-data"},b.name+" · "+Math.round(b.size/1024)+" KB · "+b.time),h("button",{type:"button",className:"evl-btn-ghost",onClick:()=>dl(b.name)},"Download"))))),
    h("p",{className:"text-xs text-slate-500 font-sans"},"Data folder: "+site.dataDir+(site.dataInsideWebRoot?" (inside the site, blocked by .htaccess; optional: move outside public_html with data-path.php)":" (outside the public web folder)")));
};
