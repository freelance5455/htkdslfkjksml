<?php
// OPTIONAL. Rename this file to data-path.php to store the database OUTSIDE public_html.
// 1) In hPanel File Manager create a folder next to public_html, e.g. earnvialinks-data (permission 775).
// 2) Copy database.json (and the backups folder) from data/ into it.
// 3) Put its full path below. Your real path is shown in Admin > Install Check.
return '/home/YOUR_USER/earnvialinks-data';
