<?php
// EarnViaLinks PHP API entry. All /api/* requests are routed here by .htaccess.
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING & ~E_DEPRECATED);
ini_set('display_errors', '0');
require __DIR__ . '/lib/core.php';
foreach (['routes_core', 'routes_auth', 'routes_money1', 'routes_money2', 'routes_money3', 'earn_extra', 'site_settings'] as $f) require __DIR__ . '/lib/' . $f . '.php';

$HEADERS = req_headers();
$method = $_SERVER['REQUEST_METHOD'];
if ($method === 'OPTIONS') { http_response_code(204); exit; }
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri = trim(preg_replace('#^/?api(\.php)?#', '', $path), '/');
$Q = $_GET;
$raw = file_get_contents('php://input');
$IN = [];
if ($raw !== '' && $raw !== false) { $j = json_decode($raw, true); if (is_array($j)) $IN = $j; }
if (!$IN && $_POST) $IN = $_POST;

if (!is_dir(DATA_DIR)) @mkdir(DATA_DIR, 0775, true);
if ($method === 'POST' && $uri === 'earn/ptc/ping') ptc_ping($IN); // lightweight heartbeat: handled before the global DB lock
$lock = fopen(DATA_DIR . '/.lock', 'c');
flock($lock, LOCK_EX); // one request at a time keeps the JSON database consistent
set_exception_handler(function ($e) { error_log('[earnvialinks] ' . $e->getMessage()); out(500, ['success' => false, 'message' => 'Internal server error.']); });
db_load();
daily_backup();
routes_core($uri, $method);
routes_auth($uri, $method);
routes_money1($uri, $method);
routes_money2($uri, $method);
routes_money3($uri, $method);
routes_earn_extra($uri, $method);
routes_site($uri, $method);
out(404, ['error' => 'Not Found', 'uri' => $uri, 'method' => $method]);
