YOGI GK GS HINDI TEST - Android-friendly installable web app

Open index.html in a browser to use the practice app. To install it like an app, host the folder on an HTTPS static host and choose the browser menu > Add to Home screen / Install app.

This build contains 26 sample GK/GS questions in Hindi with Hindi options and explanations, category filters, shuffled practice tests, timer, answer review, and offline caching.

Important: It does NOT contain 20,000 questions yet. A large question bank must be compiled and fact-checked before it can honestly be called 20,000+ verified questions. Live internet retrieval or AI-generated questions requires a secure backend/API and internet access. This ZIP is a web app project, not a directly installable APK.
