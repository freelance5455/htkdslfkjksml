Health Buddy - ZIP to APK

یہ پیکج HTML/CSS/JavaScript والی موجودہ Health Buddy ایپ کو آن لائن ZIP-to-APK Builder میں اپ لوڈ کرنے کے لیے ہے۔

اہم: ZIP میں index.html مرکزی سطح پر موجود ہے، اس لیے اسے Extract یا دوبارہ ZIP کرنے کی ضرورت نہیں۔

آن لائن طریقہ:
1) https://ziptoapk.com کھولیں۔
2) Build an APK / ZIP to APK منتخب کریں۔
3) HEALTH_BUDDY_WEB_APK.zip اپ لوڈ کریں۔
4) App name: Health Buddy
5) Package ID: com.nasirsandhu.healthbuddy
6) Build APK دبائیں اور مکمل ہونے پر APK ڈاؤن لوڈ کریں۔

موجودہ پیکج کے فیچرز: وزن، شوگر، HbA1c، BP ریکارڈ؛ روزانہ پانی/کھانے کی ڈائری؛ وزن کا ہدف؛ مقامی ریکارڈ؛ CSV ایکسپورٹ؛ اردو/انگریزی؛ عمومی صحت رہنمائی۔

نوٹ: یہ موجودہ MVP ہے۔ کیلوری/میکرو کاؤنٹر اور AI چیٹ اس ورژن میں شامل نہیں۔ ایپ ڈیٹا اسی ڈیوائس کے مقامی اسٹوریج میں رکھتی ہے۔
