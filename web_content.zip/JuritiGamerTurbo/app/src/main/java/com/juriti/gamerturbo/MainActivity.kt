package com.juriti.gamerturbo

import android.app.Activity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.ViewGroup
import android.graphics.Color
import android.content.Intent
import android.provider.Settings
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val executor = Executors.newSingleThreadExecutor()
    private val requestCode = 7412

    private fun jsMessage(message: String) {
        val safe = message.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ")
        runOnUiThread { if (::webView.isInitialized) webView.evaluateJavascript("toast('$safe')", null) }
    }

    private fun shizukuReady(): Boolean = try { Shizuku.pingBinder() } catch (_: Throwable) { false }

    private fun hasPermission(): Boolean = try {
        shizukuReady() && Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    private fun runShell(command: String): String {
        if (!hasPermission()) return "ERRO: Shizuku não está conectado ou a permissão não foi concedida."
        return try {
            val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
            val output = BufferedReader(InputStreamReader(process.inputStream)).readText().trim()
            val error = BufferedReader(InputStreamReader(process.errorStream)).readText().trim()
            val code = process.waitFor()
            if (code == 0) output.ifBlank { "OK" } else "ERRO: ${error.ifBlank { output }}"
        } catch (e: Throwable) { "ERRO: ${e.message ?: "falha ao executar comando"}" }
    }

    inner class AppBridge {
        @android.webkit.JavascriptInterface fun shizukuStatus(): String = when {
            !shizukuReady() -> "Shizuku não está iniciado. Abra o app Shizuku e inicie o serviço."
            !hasPermission() -> "Shizuku está iniciado, mas falta conceder permissão ao Juriti."
            else -> "Conectado e autorizado. UID do serviço: ${try { Shizuku.getUid() } catch (_: Throwable) { -1 }}"
        }

        @android.webkit.JavascriptInterface fun requestShizukuPermission(): String {
            return try {
                if (!shizukuReady()) "Abra o Shizuku e inicie o serviço primeiro."
                else if (hasPermission()) "O Juriti já tem permissão do Shizuku."
                else { runOnUiThread { Shizuku.requestPermission(requestCode) }; "Pedido de permissão enviado; aceite a janela do Shizuku." }
            } catch (e: Throwable) { "Não foi possível pedir permissão: ${e.message}" }
        }

        @android.webkit.JavascriptInterface fun setAnimationProfile(profile: String): String {
            val value = when (profile) { "fast" -> "0.5"; "normal" -> "1.0"; "off" -> "0.0"; else -> return "Perfil inválido." }
            val command = "settings put global window_animation_scale $value && settings put global transition_animation_scale $value && settings put global animator_duration_scale $value && echo 'Animações configuradas' && settings get global window_animation_scale && settings get global transition_animation_scale && settings get global animator_duration_scale"
            return runShell(command)
        }

        @android.webkit.JavascriptInterface fun readAnimationScales(): String = runShell("echo 'Escala de janela:'; settings get global window_animation_scale; echo 'Escala de transição:'; settings get global transition_animation_scale; echo 'Duração do animador:'; settings get global animator_duration_scale")

        @android.webkit.JavascriptInterface fun openBatterySettings(): String {
            runOnUiThread { try { startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)) } catch (_: Throwable) { startActivity(Intent(Settings.ACTION_SETTINGS)) } }
            return "Abrindo configurações de bateria do Android."
        }

        @android.webkit.JavascriptInterface fun openDisplaySettings(): String {
            runOnUiThread { try { startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS)) } catch (_: Throwable) { startActivity(Intent(Settings.ACTION_SETTINGS)) } }
            return "Abrindo configurações de tela do Android."
        }

        @android.webkit.JavascriptInterface fun openDndSettings(): String {
            runOnUiThread { try { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) } catch (_: Throwable) { startActivity(Intent(Settings.ACTION_SETTINGS)) } }
            return "Abrindo configurações de Não Perturbe. O Android pode exigir autorização própria."
        }

        @android.webkit.JavascriptInterface fun openApplicationSettings(): String {
            runOnUiThread { try { startActivity(Intent(Settings.ACTION_APPLICATION_SETTINGS)) } catch (_: Throwable) { startActivity(Intent(Settings.ACTION_SETTINGS)) } }
            return "Abrindo a lista de aplicativos nas configurações do Android. Escolha o app para ver armazenamento e limpar somente o cache."
        }

        @android.webkit.JavascriptInterface fun openBatteryUsageSettings(): String {
            runOnUiThread { try { startActivity(Intent(Settings.ACTION_BATTERY_USAGE_SUMMARY)) } catch (_: Throwable) { try { startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)) } catch (_: Throwable) { startActivity(Intent(Settings.ACTION_SETTINGS)) } } }
            return "Abrindo uso da bateria. As opções de restrição dependem do Android e do fabricante."
        }

        @android.webkit.JavascriptInterface fun openStorageSettings(): String {
            runOnUiThread { try { startActivity(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)) } catch (_: Throwable) { try { startActivity(Intent(Settings.ACTION_STORAGE_SETTINGS)) } catch (_: Throwable) { startActivity(Intent(Settings.ACTION_SETTINGS)) } } }
            return "Abrindo configurações de armazenamento. Nenhum arquivo foi apagado."
        }

        @android.webkit.JavascriptInterface fun thermalStatus(): String {
            return try {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                    val power = getSystemService(POWER_SERVICE) as android.os.PowerManager
                    val status = power.currentThermalStatus
                    val label = when (status) {
                        android.os.PowerManager.THERMAL_STATUS_NONE -> "Normal"
                        android.os.PowerManager.THERMAL_STATUS_LIGHT -> "Leve"
                        android.os.PowerManager.THERMAL_STATUS_MODERATE -> "Moderado"
                        android.os.PowerManager.THERMAL_STATUS_SEVERE -> "Alto"
                        android.os.PowerManager.THERMAL_STATUS_CRITICAL -> "Crítico"
                        android.os.PowerManager.THERMAL_STATUS_EMERGENCY -> "Emergência"
                        android.os.PowerManager.THERMAL_STATUS_SHUTDOWN -> "Desligamento térmico iminente"
                        else -> "Indisponível"
                    }
                    "Estado térmico do sistema: $label (nível $status). O Android não forneceu temperatura em °C."
                } else "Este Android não disponibiliza a API de estado térmico usada pelo Juriti."
            } catch (e: Throwable) { "Não foi possível consultar o estado térmico: ${e.message ?: "indisponível"}" }
        }
    }

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7, 0, 15)
        window.navigationBarColor = Color.rgb(7, 0, 15)
        webView = WebView(this)
        webView.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        webView.setBackgroundColor(Color.rgb(7, 0, 15))
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.addJavascriptInterface(AppBridge(), "JuritiNative")
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        setContentView(webView)
        if (savedInstanceState != null) webView.restoreState(savedInstanceState)
        else webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
