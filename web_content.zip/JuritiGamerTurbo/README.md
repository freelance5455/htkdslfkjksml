# JURITI Gamer Turbo — projeto Android pronto para compilar

Projeto Android nativo (Kotlin + WebView local) com a interface JURITI Gamer Turbo, arte do Zoro, abertura animada e efeito sonoro local. O código-fonte e os recursos estão em `app/src/main/`.

## O que está incluído
- Projeto Android Gradle com Android Gradle Plugin 8.6.1 e Kotlin 2.0.20.
- `compileSdk 35`, `minSdk 23`, `targetSdk 28`.
- Interface local em `app/src/main/assets/index.html`, imagens em `assets/` e áudio `zoro_intro.wav`.
- Ponte Shizuku em Kotlin para consultar o estado de conexão/permissão, ajustar e ler escalas de animação do sistema, abrir configurações do Android e consultar o estado térmico quando disponível.
- Workflow GitHub Actions em `.github/workflows/android-apk.yml` para compilar um APK de debug e disponibilizá-lo como artefato.

## Compilar no AndroidIDE
1. Extraia o ZIP para uma pasta do armazenamento interno.
2. Abra no AndroidIDE a pasta `JuritiGamerTurbo` — a pasta que contém `settings.gradle`.
3. Quando solicitado, instale/configure JDK 17, Android SDK Platform 35 e Android Build Tools compatíveis.
4. Aguarde a sincronização do Gradle e execute `:app:assembleDebug`.
5. Se a compilação terminar com sucesso, o APK estará em `app/build/outputs/apk/debug/app-debug.apk`.

**Nota:** este pacote não inclui `gradlew`/Gradle Wrapper. Use a instalação Gradle disponibilizada pelo AndroidIDE ou configure um wrapper no ambiente de desenvolvimento.

## Alternativa: gerar o APK no GitHub Actions
1. Crie um repositório GitHub e envie o conteúdo desta pasta para a branch `main`.
2. Abra a aba **Actions** e habilite workflows, se o GitHub solicitar.
3. Selecione **Gerar APK JURITI Gamer Turbo** e clique em **Run workflow**; também há execução automática em pushes para `main`.
4. Quando terminar, abra a execução e baixe o artefato `JuritiGamerTurbo-debug-apk`.

## Antes de instalar
- Este ambiente de trabalho não compilou nem executou o APK. A compilação e o funcionamento precisam ser confirmados no AndroidIDE ou no GitHub Actions e, depois, no aparelho.
- Ações que dependem de Shizuku exigem que o serviço Shizuku esteja iniciado e que o usuário conceda a permissão ao Juriti.
- Os controles visuais e indicadores de desempenho não garantem aumento de FPS, limpeza de RAM ou redução de temperatura.
- Para distribuir publicamente, configure assinatura de release, ícone, política de privacidade e testes.
