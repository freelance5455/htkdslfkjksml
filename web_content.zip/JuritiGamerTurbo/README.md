# JURITI Gamer Turbo — projeto Android WebView

Projeto-base Android que abre uma interface HTML local dentro de um app Android. A imagem original enviada foi incluída em `app/src/main/assets/juriti-original.png` e aparece na aba **Arte original** e na tela inicial.

## O que já funciona
- Navegação inferior entre Início, Jogos, Otimização, Shizuku e Mais.
- Ações demonstrativas para alternar telas, ativar/desativar opções visuais e abrir a arte original.
- Layout responsivo com tema preto/roxo.
- WebView sem necessidade de conexão à internet para carregar a interface.

## Limitações importantes
Este é um protótipo visual. Os indicadores de RAM/CPU e opções de otimização são demonstrações; eles não medem nem modificam o sistema Android. A integração real com Shizuku, depuração sem fio ou serviços do sistema precisa ser desenvolvida separadamente e requer permissões e testes.

## Compilar pelo celular Android com AndroidIDE
1. Baixe e extraia `JuritiGamerTurbo.zip` para uma pasta do armazenamento interno.
2. Instale o AndroidIDE apenas por uma fonte oficial/confiável e consulte os requisitos atuais em https://docs.androidide.com/.
3. Abra o projeto extraído no AndroidIDE (selecione a pasta que contém `settings.gradle`).
4. Aguarde a sincronização do Gradle. Se o app solicitar SDK/Build Tools, instale os componentes recomendados pelo próprio IDE.
5. Execute a tarefa Gradle `:app:assembleDebug` (geralmente pelo terminal do projeto com `./gradlew assembleDebug`, se o wrapper estiver disponível; este pacote não inclui o wrapper Gradle).
6. O APK de debug, se a compilação concluir, ficará em `app/build/outputs/apk/debug/app-debug.apk`.
7. Toque no APK no gerenciador de arquivos para instalar. Se solicitado, autorize a instalação de apps daquela fonte nas configurações do Android.

## Observações
- Requer Android 6.0 (API 23) ou superior.
- O projeto usa Android Gradle Plugin 8.6.1 e Kotlin 2.0.20; se o ambiente móvel tiver incompatibilidade, use as versões sugeridas pelo AndroidIDE.
- Para distribuição pública, configure assinatura de release, ícone próprio, política de privacidade e testes.


## Integração Shizuku nesta versão

Esta atualização foi aplicada sobre o projeto existente, preservando a interface, arte do Zoro, painel flutuante, animação de abertura e áudio. Na tela Shizuku, use “Verificar conexão” e “Autorizar Juriti no Shizuku” após iniciar o serviço no app Shizuku. A autorização depende do serviço estar ativo no Android.
