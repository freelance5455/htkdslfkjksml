ST World bd Delivery System

এই সংস্করণে কোনো Login/OTP নেই।
Admin: দোকান, Rider এবং Order তৈরি/দেখা।
Order তৈরির সময় অবশ্যই Pickup Shop এবং Rider নির্বাচন করতে হবে।
Shop: দোকানের নাম, ঠিকানা, WhatsApp নম্বর।
Rider: নাম, WhatsApp নম্বর, এলাকা।
Rider: Accept → পণ্য রিসিভ → Delivered।
Google Maps ও WhatsApp বাটন আছে।

নোট: এই ZIP সংস্করণটি browser local storage ব্যবহার করে। একই ডাটা বিভিন্ন ফোন/PC-তে শেয়ার করতে অনলাইন database (যেমন Supabase) সংযোগ লাগবে।
