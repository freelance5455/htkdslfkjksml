PC Builder Simulator — două jocuri

Cum se joacă:
1. Deschide index.html într-un browser modern (Chrome, Edge, Firefox).
2. În Magazin cumpără componentele.
3. În Asamblare montează toate cele 8 piese.
4. Pornește PC-ul și intră în Game Center.
5. Snake: folosește săgețile de pe monitor sau tastele săgeată/WASD.
6. Meteor Dodge: evită meteoriții cu butoanele STÂNGA/DREAPTA din monitor sau tastele săgeată stânga/dreapta (și A/D).
7. În Setări poți schimba culoarea RGB, dificultatea și volumul simulativ.

Jocul rulează local în browser, fără instalare și fără internet.
