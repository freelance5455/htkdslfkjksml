# Carreira de Craque v1.59.3 — Copa do Brasil integrada ao fluxo normal

- Removida a seção da Copa do Brasil da tela Início.
- Adicionada a entrada **COPA DO BRASIL** ao lado das divisões brasileiras na área Ligas.
- O calendário em **Partidas → Calendário da temporada** mostra os jogos da Copa do Brasil do clube, com fase, data, adversário, mando, placar e situação.
- Removido o botão manual **Simular Fase Atual**.
- As partidas da Copa passam a ser processadas automaticamente quando o calendário alcança as datas marcadas, usando `simulateMatchEngine`.
- Ida e volta são processadas em suas respectivas datas; o agregado e os pênaltis são resolvidos após o jogo de volta.
- O avanço de fase, premiações e campeão são processados uma única vez.
- As datas da Copa evitam os dias de jogos do Brasileirão dos dois clubes envolvidos; partidas da Copa entre clubes diferentes podem ocorrer na mesma data.
- Limpeza única de saves de carreira autorizada pelo usuário para iniciar os testes desta atualização; dados-base de clubes, elencos e escudos são preservados.
