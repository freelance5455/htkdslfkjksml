DARK MAZE

1) Double-clique sur Play.bat (internet necessaire la 1ere fois).
2) Deux fichiers sont crees dans ce dossier:
   - DarkMaze.html        -> pour ordinateur (clavier)
   - DarkMaze-Phone.html  -> pour TELEPHONE (tactile, plein ecran)
3) Envoie DarkMaze-Phone.html au telephone (WhatsApp > Document, Drive, USB)
   puis ouvre-le avec Chrome. Marche sans internet.
