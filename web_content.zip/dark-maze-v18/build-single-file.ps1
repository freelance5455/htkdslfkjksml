# كيحمل المكتبات مرة وحدة وكيصاوب جوج ملفات: DarkMaze.html (كمبيوتر) و DarkMaze-Phone.html (تيليفون)
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$libs = @(
  @{ n='three.min.js';  u='https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js' },
  @{ n='fflate.min.js'; u='https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/libs/fflate.min.js' },
  @{ n='FBXLoader.js';  u='https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/loaders/FBXLoader.js' }
)
foreach ($l in $libs) {
  $path = "$PSScriptRoot\libs\$($l.n)"
  if (-not (Test-Path $path)) { Invoke-WebRequest $l.u -OutFile $path }
}
$targets = @( @{ src='index.html'; out='DarkMaze.html' }, @{ src='index-phone.html'; out='DarkMaze-Phone.html' } )
foreach ($t in $targets) {
  $html = [IO.File]::ReadAllText("$PSScriptRoot\$($t.src)", [Text.Encoding]::UTF8)
  foreach ($l in $libs) {
    $code = [IO.File]::ReadAllText("$PSScriptRoot\libs\$($l.n)", [Text.Encoding]::UTF8)
    $tag = '<script src="libs/' + $l.n + '"></script>'
    if (-not $html.Contains($tag)) { throw "tag not found: $tag" }
    $html = $html.Replace($tag, '<script>' + $code + '</script>')
  }
  [IO.File]::WriteAllText("$PSScriptRoot\$($t.out)", $html, (New-Object Text.UTF8Encoding($false)))
}
Write-Host 'DarkMaze.html + DarkMaze-Phone.html ready'
