@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Preparation du jeu ... (internet necessaire seulement la 1ere fois)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build-single-file.ps1"
if errorlevel 1 (
  echo.
  echo Erreur: verifie ta connexion internet puis relance Play.bat
  pause
  exit /b 1
)
start "" "%~dp0DarkMaze.html"
