# CryptoPulse Stage 1172 — Home Prices + Futures Chart Bugfix

## Scope
Mobile-only stabilization based on the Stage 1171 test build.

## Fixed
- Added the missing JavaScript receiver for Android `fetchMissingLBankTickers()` callbacks.
- Missing/lower Home market rows now update the shared live cache and visible Home row immediately.
- Added a persistence-safe Home refresh after each missing-symbol price callback.
- Hardened Futures feed retry from 9 seconds to 20 seconds for Android cold-start/network latency.
- Added a browser-only LBank Contract REST fallback for Futures preview/testing when the native bridge is unavailable.
- Futures snapshot/sample updates now redraw the candle chart as soon as usable Futures data arrives.
- Version bumped to 12.2.0 / versionCode 122.

## Data integrity
- Futures fallback uses the LBank Contract `SwapU` market endpoint; it does not fabricate Futures prices from Spot data.
- No private key, seed phrase, signing, broadcast, mainnet, or real-money trading capability was added.
- CPLS contract/Testnet work remains unchanged.

## Next test
1. App cold start must show Home.
2. Lower Home rows must receive real prices.
3. Trade chart must remain working.
4. Futures chart must populate after opening Futures.
5. Switching Home → Trade → Futures → Home must retain live market data.
