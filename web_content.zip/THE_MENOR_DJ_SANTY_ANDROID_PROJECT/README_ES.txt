THE MENOR DJ SANTY SAMPLER — proyecto Android

Este proyecto abre el sampler desde app/src/main/assets/index.html mediante
file:///android_asset/index.html. No depende de appassets.androidplatform.net,
por lo que evita el fallo de carga que aparece cuando un conversor no incluye
correctamente el archivo HTML.

CÓMO GENERAR EL APK
1. En un computador instala Android Studio y JDK 17.
2. Descomprime este ZIP. En Android Studio selecciona Open y elige la carpeta
   THE_MENOR_DJ_SANTY_ANDROID_PROJECT.
3. Espera la sincronización de Gradle. Si pide instalar Android SDK 35, acepta.
4. Selecciona Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Pulsa Locate en el aviso de finalización para encontrar app-debug.apk.
6. Pasa app-debug.apk al Vivo, ábrelo e instala permitiendo la instalación
   desde esa fuente cuando Android lo solicite. Luego aparecerá como app con icono.

NOTAS
- Este ZIP es el proyecto fuente para compilar, no un APK ya compilado.
- El proyecto requiere conexión a internet en el computador para descargar
  Gradle/Android Gradle Plugin durante la primera sincronización.
- La función Web MIDI puede seguir limitada en Android WebView; los pads y la
  carga de audio están incluidos. Los sonidos y proyectos se guardan en el
  almacenamiento del WebView de la app.
