# BISP BOP Alflah Retailers — Android APK Build Guide

Yeh folder aap ki web app (`www/index.html`) ko **bilkul bina kisi change ke** ek
Android APK mein convert karne ke liye taiyar kiya gaya hai, Capacitor
(official, free, open-source tool) ka istemal karte hue.

**Important:** Asal APK banane (compile karne) ke liye Android build tools
(Node.js + Android Studio) chahiye hote hain jo is chat ke andar maujood
nahi hain — is liye yeh steps aapko apne khud ke computer (Windows/Mac/
Linux) par chalane honge. Ek dafa setup ho jaye to agli baar sirf 2 commands
se naya APK ban jata hai.

---

## Cheezein jo pehle se set hain
- **App Name:** BISP BOP Alflah Retailers
- **Package ID:** `com.bisp.bopalflah.retailers`
- **App ka poora HTML/CSS/JS** — `www/index.html` mein waisa hi hai jaisa
  pehle chat mein tha, koi tabdeeli nahi.
- LocalStorage (data save, users, login) APK ke WebView mein bhi normal
  kaam karta hai — isko alag se kuch nahi karna parega.
- PDF download (jsPDF) ek CDN script use karta hai, is liye APK ko internet
  permission ke sath rakha gaya hai (pehli dafa khulte waqt net chahiye hoga
  taake yeh library load ho; baad mein bhi PDF button ke liye net chalu
  rakhein).

---

## Step 1 — Zaroori software install karein (sirf ek dafa)
1. [Node.js](https://nodejs.org) (LTS version) install karein.
2. [Android Studio](https://developer.android.com/studio) install karein
   (isi mein Android SDK bhi aata hai).

## Step 2 — Is folder ko computer par khol kar terminal chalayein
```bash
cd bisp-apk-project
npm install
npx cap init "BISP BOP Alflah Retailers" "com.bisp.bopalflah.retailers" --web-dir=www
npx cap add android
npx cap sync android
```

## Step 3 — Android Studio mein kholein aur APK banayein
```bash
npx cap open android
```
Android Studio khulne ke baad:
1. Upar menu se **Build → Build Bundle(s) / APK(s) → Build APK(s)** dabayein.
2. Build poora hone ke baad **"locate"** link dabayein — APK file
   `android/app/build/outputs/apk/debug/app-debug.apk` mein milegi.
3. Yeh file apne phone mein bhej kar install kar lein (phone mein
   "Install from unknown sources" allow karna parega).

## Step 4 (Optional) — App ka icon aur splash screen
- Apna logo `resources/icon.png` (1024×1024) aur
  `resources/splash.png` (2732×2732) naam se rakh kar yeh command chalayein:
```bash
npx @capacitor/assets generate --android
```

## Step 5 (Optional) — Play Store ke liye signed release APK
Debug APK testing ke liye theek hai. Play Store par publish karne se pehle
Android Studio se **signed release build** banani hogi (Google ka official
guide: "Sign your app").

---

## Agar kuch error aaye
- `npx cap sync android` dobara chalayein jab bhi `www/index.html` update
  karein.
- Agar PDF download kaam na kare, phone ka internet connection check karein
  (jsPDF library CDN se load hoti hai).
