# Swarnava Life OS — Android project

This project packages the Life OS HTML interface inside a native Android app. It loads the page offline using `WebViewAssetLoader` (a stable HTTPS-style local origin), enables DOM storage and IndexedDB, and supplies the Android file chooser and JavaScript bridge that a plain HTML file does not have.

## Build an APK

1. Install Android Studio, Android SDK Platform 35 (or newer), and JDK 17.
2. Install Gradle 8.9 (the build uses Android Gradle Plugin 8.7.3) or configure Android Studio to use a local Gradle 8.9 installation.
3. Open the **LifeOS_Android** folder in Android Studio and sync the project.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio creates the debug APK at `app/build/outputs/apk/debug/app-debug.apk`. Install that APK on the Android device.

The `gradle-wrapper.properties` file pins Gradle 8.9, but the wrapper launcher/JAR is not bundled. For command-line builds, generate it once from an installed Gradle 8.9 using `gradle wrapper --gradle-version 8.9`, then run `./gradlew :app:assembleDebug` (or `gradlew.bat :app:assembleDebug` on Windows).

The build environment used to prepare this source bundle did not contain the Android SDK or Gradle, so an APK has not been compiled or device-tested here.

## Android support included

- **Music import:** the Music screen uses Android's Storage Access Framework (`ACTION_OPEN_DOCUMENT`) and supports multi-select. Selected document URIs are granted persistent read access when the provider allows it; no broad storage permission is requested. Reopen the app and selected tracks remain in the list.
- **Native playback:** selected URI tracks are played by Android `MediaPlayer` in a `mediaPlayback` foreground service with a playback notification and pause/resume/stop controls. The codecs available depend on the Android build and the individual device; no app can guarantee playback of every proprietary or unusual codec (for example, some WMA/MIDI variants).
- **Other file inputs:** profile photos, wallpaper image/video, wallpaper audio, and JSON restore use the WebView file chooser, implemented with the Android document picker.
- **Wallpaper and app storage:** the HTML is loaded from `https://appassets.androidplatform.net/assets/index.html`, not `file://`. This gives localStorage and IndexedDB a stable origin for the app. Custom wallpaper media stays inside Life OS; it does not become the Android launcher/system wallpaper.
- **Notifications and reminders:** Android notifications and scheduled reminders are connected to the app's existing reminder data. Exact alarm access is optional; without it, Android may deliver reminders later than their requested time. Android 13+ asks for notification permission.
- **Contacts, dialer, print and files:** contacts import requests Contacts permission; call buttons open the system dialer; printing uses Android Print; JSON and PDF exports save under Downloads/LifeOS.

## First launch / moving from the old HTML version

The Android package has isolated app storage. Use **Backup & Settings → Restore from backup file** to import the old JSON database. The old browser's IndexedDB media store is separate, so choose your wallpaper and re-import music in the new Android app once after installing it.

## Important

This is an Android Studio source project, not a prebuilt APK. Review and test it on your own device before relying on alarms, reminders, media formats, or background behavior. Battery saver, document-provider permissions, Android version, and OEM customizations can affect behavior.
