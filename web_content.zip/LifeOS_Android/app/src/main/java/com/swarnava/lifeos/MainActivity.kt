package com.swarnava.lifeos

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ClipData
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import android.print.PrintAttributes
import android.print.PrintManager
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.WindowCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.lang.ref.WeakReference
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var assetLoader: WebViewAssetLoader
    private var webFileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingNavigation: Pair<String, String?>? = null
    private var pendingPermissionAction: String? = null

    private val prefs by lazy { getSharedPreferences("lifeos_android", MODE_PRIVATE) }

    companion object {
        private const val URL = "https://appassets.androidplatform.net/assets/index.html"
        private const val REQ_WEB_FILE = 8101
        private const val REQ_AUDIO_FILES = 8102
        private const val REQ_NOTIFICATIONS = 8103
        private const val REQ_CONTACTS = 8104
        private const val REMINDER_CHANNEL = "lifeos_reminders"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        window.statusBarColor = android.graphics.Color.rgb(15, 23, 32)
        window.navigationBarColor = android.graphics.Color.rgb(15, 23, 32)

        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web = WebView(this).apply {
            setBackgroundColor(android.graphics.Color.TRANSPARENT)
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                allowFileAccess = false
                allowContentAccess = true
                allowFileAccessFromFileURLs = false
                allowUniversalAccessFromFileURLs = false
                javaScriptCanOpenWindowsAutomatically = false
                mediaPlaybackRequiresUserGesture = true
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                loadsImagesAutomatically = true
                setSupportMultipleWindows(false)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) safeBrowsingEnabled = true
            }
            addJavascriptInterface(AndroidBridge(), "Android")
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                    val uri = request?.url ?: return null
                    return assetLoader.shouldInterceptRequest(uri)
                }

                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request.url
                    if (uri.host == "appassets.androidplatform.net") return false
                    if (uri.scheme == "tel" || uri.scheme == "mailto" || uri.scheme == "https" || uri.scheme == "http") {
                        return try {
                            startActivity(Intent(Intent.ACTION_VIEW, uri))
                            true
                        } catch (_: Exception) { true }
                    }
                    return true
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    MusicPlaybackService.attachWebView(web)
                    emitSavedMusicList()
                    pendingNavigation?.let { (tab, date) ->
                        val d = JSONObject.quote(date ?: "")
                        web.evaluateJavascript("window.openFromNative && window.openFromNative(${JSONObject.quote(tab)}, $d)", null)
                        pendingNavigation = null
                    }
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?
                ): Boolean {
                    webFileCallback?.onReceiveValue(null)
                    webFileCallback = filePathCallback
                    return try {
                        val params = fileChooserParams
                        val accepts = params?.acceptTypes.orEmpty()
                            .flatMap { it.split(",") }
                            .map { it.trim() }
                            .filter { it.contains("/") && !it.contains("*/*") }
                            .distinct()
                        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                            addCategory(Intent.CATEGORY_OPENABLE)
                            type = when {
                                accepts.size == 1 -> accepts.first()
                                accepts.isNotEmpty() -> "*/*"
                                else -> "*/*"
                            }
                            if (accepts.isNotEmpty()) putExtra(Intent.EXTRA_MIME_TYPES, accepts.toTypedArray())
                            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params?.mode == FileChooserParams.MODE_OPEN_MULTIPLE)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                        }
                        startActivityForResult(intent, REQ_WEB_FILE)
                        true
                    } catch (e: Exception) {
                        webFileCallback?.onReceiveValue(null)
                        webFileCallback = null
                        toast("Android file picker could not open: ${e.localizedMessage ?: "unknown error"}")
                        false
                    }
                }
            }
        }
        setContentView(web)
        web.loadUrl(URL)
        handleLaunchIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleLaunchIntent(intent)
    }

    private fun handleLaunchIntent(intent: Intent?) {
        val tab = intent?.getStringExtra("lifeos_tab") ?: return
        val date = intent.getStringExtra("lifeos_date")
        if (::web.isInitialized && web.progress == 100) {
            web.evaluateJavascript("window.openFromNative && window.openFromNative(${JSONObject.quote(tab)}, ${JSONObject.quote(date ?: "")})", null)
        } else pendingNavigation = tab to date
    }

    override fun onDestroy() {
        if (::web.isInitialized) {
            MusicPlaybackService.detachWebView(web)
            web.destroy()
        }
        super.onDestroy()
    }

    override fun onBackPressed() {
        if (!::web.isInitialized) {
            super.onBackPressed()
            return
        }
        web.evaluateJavascript(
            "(function(){if(document.body.classList.contains('open')){goHome();return 'handled'}return 'home'})()"
        ) { result -> if (result == "\"home\"") finish() }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_WEB_FILE) {
            val callback = webFileCallback
            webFileCallback = null
            val uris = if (resultCode == RESULT_OK) collectUris(data) else emptyList()
            persistReadPermissions(uris, data?.flags ?: 0)
            callback?.onReceiveValue(uris.takeIf { it.isNotEmpty() }?.toTypedArray())
            return
        }
        if (requestCode == REQ_AUDIO_FILES) {
            if (resultCode != RESULT_OK) {
                js("window.onNativeMusicPickerCancelled && window.onNativeMusicPickerCancelled()")
                return
            }
            val uris = collectUris(data)
            persistReadPermissions(uris, data?.flags ?: 0)
            val old = prefs.getStringSet("music_uris", emptySet()).orEmpty().toMutableSet()
            uris.forEach { old.add(it.toString()) }
            prefs.edit().putStringSet("music_uris", old).apply()
            emitMusicList(old.toList())
        }
    }

    private fun collectUris(data: Intent?): List<Uri> {
        if (data == null) return emptyList()
        val out = linkedSetOf<Uri>()
        data.clipData?.let { clip -> for (i in 0 until clip.itemCount) clip.getItemAt(i).uri?.let(out::add) }
        data.data?.let(out::add)
        return out.toList()
    }

    private fun persistReadPermissions(uris: List<Uri>, flags: Int) {
        val readFlag = flags and Intent.FLAG_GRANT_READ_URI_PERMISSION
        if (readFlag == 0) return
        uris.forEach { uri ->
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            catch (_: SecurityException) { /* Some document providers grant temporary, not persistable access. */ }
            catch (_: Exception) { }
        }
    }

    private fun openAudioPicker() {
        try {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
                putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("audio/*", "application/ogg", "video/mp4"))
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            startActivityForResult(intent, REQ_AUDIO_FILES)
        } catch (e: Exception) {
            toast("Could not open Android Files: ${e.localizedMessage ?: "unknown error"}")
            js("window.onNativeMusicErr && window.onNativeMusicErr()")
        }
    }

    private fun emitSavedMusicList() {
        val saved = prefs.getStringSet("music_uris", emptySet()).orEmpty().toList()
        if (saved.isNotEmpty()) emitMusicList(saved)
    }

    private fun emitMusicList(rawUris: List<String>) {
        val result = JSONArray()
        rawUris.distinct().forEach { raw ->
            try {
                val uri = Uri.parse(raw)
                val name = displayName(uri).ifBlank { "Audio file" }
                var duration = 0.0
                try {
                    val retriever = MediaMetadataRetriever()
                    retriever.setDataSource(this, uri)
                    duration = (retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) / 1000.0
                    retriever.release()
                } catch (_: Exception) { }
                result.put(JSONObject().apply {
                    put("id", raw)
                    put("u", raw)
                    put("t", name.substringBeforeLast('.', name))
                    put("a", "")
                    put("d", duration)
                })
            } catch (_: Exception) { }
        }
        js("window.onNativeMusicFiles && window.onNativeMusicFiles(${result})")
    }

    private fun displayName(uri: Uri): String {
        var name = ""
        var cursor: Cursor? = null
        try {
            cursor = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            if (cursor?.moveToFirst() == true) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) name = cursor.getString(index).orEmpty()
            }
        } catch (_: Exception) { } finally { cursor?.close() }
        return name.ifBlank { uri.lastPathSegment.orEmpty() }
    }

    private fun js(script: String) {
        if (!::web.isInitialized) return
        runOnUiThread { web.evaluateJavascript(script, null) }
    }

    private fun toast(message: String) = runOnUiThread { Toast.makeText(this, message, Toast.LENGTH_LONG).show() }

    private fun saveBytesToDownloads(name: String, bytes: ByteArray, mime: String): Uri? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, mime)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/LifeOS")
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return null
                contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                values.clear(); values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                contentResolver.update(uri, values, null, null)
                uri
            } else {
                val folder = File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "LifeOS")
                folder.mkdirs()
                val file = File(folder, name)
                file.writeBytes(bytes)
                FileProvider.getUriForFile(this, "$packageName.files", file)
            }
        } catch (e: Exception) {
            toast("Could not save file: ${e.localizedMessage ?: "storage error"}")
            null
        }
    }

    private fun shareUri(uri: Uri, name: String, mime: String) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, name)
            clipData = ClipData.newUri(contentResolver, name, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try { startActivity(Intent.createChooser(send, "Share $name")) }
        catch (_: Exception) { toast("No app is available to share this file") }
    }

    private fun openAppSettings() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }

    private fun requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            pendingPermissionAction = "notifications"
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIFICATIONS)
        } else js("window.onNotifPerm && window.onNotifPerm(true)")
    }

    private fun requestContacts() {
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            pendingPermissionAction = "contacts"
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), REQ_CONTACTS)
        } else readContacts()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            REQ_NOTIFICATIONS -> js("window.onNotifPerm && window.onNotifPerm(${grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED || Build.VERSION.SDK_INT < 33})")
            REQ_CONTACTS -> if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) readContacts() else toast("Contacts permission was not granted")
        }
        pendingPermissionAction = null
    }

    private fun readContacts() {
        val list = JSONArray()
        try {
            contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
                null, null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE LOCALIZED ASC"
            )?.use { cursor ->
                val nameIx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val phoneIx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (cursor.moveToNext()) list.put(JSONObject().apply {
                    put("n", if (nameIx >= 0) cursor.getString(nameIx).orEmpty() else "")
                    put("p", if (phoneIx >= 0) cursor.getString(phoneIx).orEmpty() else "")
                })
            }
        } catch (e: Exception) { toast("Could not read contacts: ${e.localizedMessage ?: "unknown error"}") }
        js("window.onPhoneContacts && window.onPhoneContacts($list)")
    }

    private fun scheduleReminder(id: String, at: Long, title: String, body: String, go: String?, date: String?) {
        val alarm = getSystemService(ALARM_SERVICE) as AlarmManager
        val requestCode = id.hashCode() and 0x7fffffff
        val intent = Intent(this, LifeOsReminderReceiver::class.java).apply {
            data = Uri.parse("lifeos-reminder://$requestCode")
            putExtra("id", requestCode)
            putExtra("title", title)
            putExtra("body", body)
            putExtra("go", go ?: "")
            putExtra("date", date ?: "")
        }
        val pi = PendingIntent.getBroadcast(this, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        try {
            if (Build.VERSION.SDK_INT >= 31 && alarm.canScheduleExactAlarms()) alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (_: SecurityException) {
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    private fun cancelReminder(id: String) {
        val alarm = getSystemService(ALARM_SERVICE) as AlarmManager
        val requestCode = id.hashCode() and 0x7fffffff
        val intent = Intent(this, LifeOsReminderReceiver::class.java).apply { data = Uri.parse("lifeos-reminder://$requestCode") }
        val pi = PendingIntent.getBroadcast(this, requestCode, intent, PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE) ?: return
        alarm.cancel(pi); pi.cancel()
    }

    inner class AndroidBridge {
        @JavascriptInterface fun pickAudioFiles() { runOnUiThread { openAudioPicker() } }
        @JavascriptInterface fun musicScan() { runOnUiThread { openAudioPicker() } }
        @JavascriptInterface fun musicPlay(uri: String) {
            val intent = Intent(this@MainActivity, MusicPlaybackService::class.java)
                .setAction(MusicPlaybackService.ACTION_PLAY)
                .putExtra(MusicPlaybackService.EXTRA_URI, uri)
                .putExtra(MusicPlaybackService.EXTRA_TITLE, displayName(Uri.parse(uri)).substringBeforeLast('.', "Life OS music"))
            startMusicService(intent, true)
        }
        @JavascriptInterface fun musicPause() = musicCommand(MusicPlaybackService.ACTION_PAUSE)
        @JavascriptInterface fun musicResume() = musicCommand(MusicPlaybackService.ACTION_RESUME)
        @JavascriptInterface fun musicStop() = musicCommand(MusicPlaybackService.ACTION_STOP)
        @JavascriptInterface fun musicSeek(milliseconds: Int) = musicCommand(MusicPlaybackService.ACTION_SEEK, milliseconds)
        @JavascriptInterface fun musicVol(percent: Int) = musicCommand(MusicPlaybackService.ACTION_VOLUME, percent)
        @JavascriptInterface fun keepAlive(on: Boolean, text: String) { /* Music uses its own media-playback foreground service. */ }

        @JavascriptInterface fun setTimer(seconds: Int, label: String) {
            runOnUiThread { scheduleReminder("timer-${System.currentTimeMillis()}", System.currentTimeMillis() + seconds.coerceAtLeast(1) * 1000L, "⏰ $label", "Timer finished", null, null) }
        }

        @JavascriptInterface fun setAlarm(hour: Int, minute: Int, label: String) {
            runOnUiThread {
                val cal = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, hour.coerceIn(0, 23)); set(Calendar.MINUTE, minute.coerceIn(0, 59)); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                    if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
                }
                val am = getSystemService(ALARM_SERVICE) as AlarmManager
                val id = "daily-alarm-$hour-$minute"
                val requestCode = id.hashCode() and 0x7fffffff
                val i = Intent(this@MainActivity, LifeOsReminderReceiver::class.java).apply {
                    data = Uri.parse("lifeos-reminder://$requestCode")
                    putExtra("id", requestCode); putExtra("title", "⏰ $label"); putExtra("body", "Your Life OS alarm")
                }
                val pi = PendingIntent.getBroadcast(this@MainActivity, requestCode, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                am.setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.timeInMillis, AlarmManager.INTERVAL_DAY, pi)
            }
        }

        @JavascriptInterface fun syncReminders(payload: String) {
            runOnUiThread {
                try {
                    val root = JSONObject(payload)
                    val items = root.optJSONArray("items") ?: JSONArray()
                    val current = mutableSetOf<String>()
                    val old = prefs.getStringSet("reminder_ids", emptySet()).orEmpty()
                    old.forEach { if (it !in current) cancelReminder(it) }
                    for (i in 0 until items.length()) {
                        val item = items.optJSONObject(i) ?: continue
                        val key = item.optString("k")
                        val at = item.optLong("at")
                        if (key.isBlank() || at <= System.currentTimeMillis()) continue
                        current.add(key)
                        scheduleReminder(key, at, item.optString("ti", "Life OS reminder"), item.optString("bo", ""), item.optString("go", ""), item.optString("dt", ""))
                    }
                    prefs.edit().putStringSet("reminder_ids", current).apply()
                } catch (e: Exception) { toast("Could not update reminders: ${e.localizedMessage ?: "invalid data"}") }
            }
        }

        @JavascriptInterface fun scheduleOne(id: String, at: Double, title: String, body: String, channel: String, flags: Int) {
            runOnUiThread { scheduleReminder(id, at.toLong(), title, body, null, null) }
        }
        @JavascriptInterface fun cancelOne(id: String) { runOnUiThread { cancelReminder(id) } }
        @JavascriptInterface fun notifAsk() { runOnUiThread { requestNotifications() } }
        @JavascriptInterface fun onNotifPerm() { }
        @JavascriptInterface fun notifyNow(title: String, body: String) { runOnUiThread { ReminderNotifications.show(this@MainActivity, title, body, 770001, null, null) } }
        @JavascriptInterface fun notifState(): String {
            val allowed = Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            val exact = Build.VERSION.SDK_INT < 31 || (getSystemService(ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms()
            return JSONObject().put("notif", allowed).put("exact", exact).put("count", prefs.getStringSet("reminder_ids", emptySet())?.size ?: 0).toString()
        }
        @JavascriptInterface fun exactSettings() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= 31) try { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))) } catch (_: Exception) { openAppSettings() }
            }
        }
        @JavascriptInterface fun notifSettings() {
            runOnUiThread { startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)) }
        }
        @JavascriptInterface fun openSettings() { runOnUiThread { openAppSettings() } }
        @JavascriptInterface fun batterySettings() {
            runOnUiThread { try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (_: Exception) { openAppSettings() } }
        }
        @JavascriptInterface fun dial(number: String) = openDialer(number)
        @JavascriptInterface fun call(number: String) = openDialer(number)
        @JavascriptInterface fun importContacts() { runOnUiThread { requestContacts() } }
        @JavascriptInterface fun printPage() {
            runOnUiThread {
                val manager = getSystemService(Context.PRINT_SERVICE) as PrintManager
                val adapter = web.createPrintDocumentAdapter("LifeOS")
                manager.print("LifeOS", adapter, PrintAttributes.Builder().build())
            }
        }
        @JavascriptInterface fun saveTextFile(name: String, data: String, mime: String) {
            runOnUiThread {
                val uri = saveBytesToDownloads(name, data.toByteArray(Charsets.UTF_8), mime)
                toast(if (uri != null) "Saved to Downloads/LifeOS/$name" else "Could not save $name")
            }
        }
        @JavascriptInterface fun saveBase64File(name: String, data: String, mime: String) {
            runOnUiThread {
                try {
                    val bytes = android.util.Base64.decode(data, android.util.Base64.DEFAULT)
                    val uri = saveBytesToDownloads(name, bytes, mime)
                    toast(if (uri != null) "Saved to Downloads/LifeOS/$name" else "Could not save $name")
                } catch (e: Exception) { toast("Could not decode file: ${e.localizedMessage ?: "unknown error"}") }
            }
        }
        @JavascriptInterface fun shareFile(name: String, data: String, to: String, email: String) {
            runOnUiThread {
                val uri = saveBytesToDownloads(name, data.toByteArray(Charsets.UTF_8), "application/json")
                if (uri != null) shareUri(uri, name, "application/json")
            }
        }
    }

    private fun openDialer(number: String) {
        runOnUiThread {
            try { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(number)}"))) }
            catch (_: Exception) { toast("No dialer app is available") }
        }
    }

    private fun startMusicService(intent: Intent, foreground: Boolean) {
        try {
            if (Build.VERSION.SDK_INT >= 26 && foreground) startForegroundService(intent) else startService(intent)
        } catch (e: Exception) { toast("Android could not start audio playback: ${e.localizedMessage ?: "unknown error"}") }
    }

    private fun musicCommand(action: String, value: Int? = null) {
        runOnUiThread {
            val i = Intent(this, MusicPlaybackService::class.java).setAction(action)
            if (value != null) i.putExtra(MusicPlaybackService.EXTRA_VALUE, value)
            try { startService(i) } catch (_: Exception) { }
        }
    }
}

class MusicPlaybackService : android.app.Service() {
    companion object {
        const val ACTION_PLAY = "com.swarnava.lifeos.music.PLAY"
        const val ACTION_PAUSE = "com.swarnava.lifeos.music.PAUSE"
        const val ACTION_RESUME = "com.swarnava.lifeos.music.RESUME"
        const val ACTION_STOP = "com.swarnava.lifeos.music.STOP"
        const val ACTION_SEEK = "com.swarnava.lifeos.music.SEEK"
        const val ACTION_VOLUME = "com.swarnava.lifeos.music.VOLUME"
        const val EXTRA_URI = "uri"
        const val EXTRA_TITLE = "title"
        const val EXTRA_VALUE = "value"
        private const val CHANNEL = "lifeos_music"
        private const val NOTIFICATION_ID = 73021
        @Volatile private var webRef: WeakReference<WebView>? = null
        @Volatile var active: MusicPlaybackService? = null
        fun attachWebView(view: WebView) { webRef = WeakReference(view) }
        fun detachWebView(view: WebView) { if (webRef?.get() === view) webRef = null }
    }

    private var player: android.media.MediaPlayer? = null
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private var trackTitle = "Life OS music"
    private var volume = 0.8f

    private val tick = object : Runnable {
        override fun run() {
            val p = player
            if (p != null) {
                try { sendJs("window.onMusicTick && window.onMusicTick(${p.currentPosition}, ${p.duration}, ${p.isPlaying})") }
                catch (_: Exception) { }
                handler.postDelayed(this, 500)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        active = this
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY -> {
                val uri = intent.getStringExtra(EXTRA_URI)
                trackTitle = intent.getStringExtra(EXTRA_TITLE) ?: "Life OS music"
                if (!uri.isNullOrBlank()) beginForeground(trackTitle, uri)
            }
            ACTION_PAUSE -> pausePlayback()
            ACTION_RESUME -> resumePlayback()
            ACTION_SEEK -> seekPlayback(intent.getIntExtra(EXTRA_VALUE, 0))
            ACTION_VOLUME -> setVolume(intent.getIntExtra(EXTRA_VALUE, 80))
            ACTION_STOP -> stopPlayback()
        }
        return START_NOT_STICKY
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(CHANNEL, "Music playback", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Shows the track currently playing in Life OS"
                setShowBadge(false)
            })
        }
    }

    private fun beginForeground(title: String, rawUri: String) {
        val notification = buildNotification(title, true)
        startForeground(NOTIFICATION_ID, notification)
        stopPlayerOnly()
        try {
            val uri = Uri.parse(rawUri)
            val p = android.media.MediaPlayer()
            player = p
            p.setWakeMode(this, android.os.PowerManager.PARTIAL_WAKE_LOCK)
            p.setAudioAttributes(android.media.AudioAttributes.Builder()
                .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
                .build())
            p.setOnPreparedListener {
                it.setVolume(volume, volume)
                it.start()
                handler.removeCallbacks(tick)
                handler.post(tick)
                updateNotification()
            }
            p.setOnCompletionListener {
                sendJs("window.onMusicEnd && window.onMusicEnd()")
                stopPlayerOnly()
                updateNotification()
            }
            p.setOnErrorListener { _, _, _ ->
                sendJs("window.onMusicErr && window.onMusicErr()")
                stopPlayback()
                true
            }
            p.setDataSource(this, uri)
            p.prepareAsync()
        } catch (e: Exception) {
            sendJs("window.onMusicErr && window.onMusicErr()")
            stopPlayback()
        }
    }

    fun pausePlayback() {
        try { if (player?.isPlaying == true) player?.pause() } catch (_: Exception) { }
        sendTick()
        updateNotification()
    }

    fun resumePlayback() {
        try { player?.start(); handler.removeCallbacks(tick); handler.post(tick) } catch (_: Exception) { }
        updateNotification()
    }

    fun seekPlayback(milliseconds: Int) {
        try { player?.seekTo(milliseconds.coerceAtLeast(0)) } catch (_: Exception) { }
        sendTick()
    }

    fun setVolume(percent: Int) {
        volume = percent.coerceIn(0, 100) / 100f
        try { player?.setVolume(volume, volume) } catch (_: Exception) { }
    }

    private fun sendTick() {
        val p = player ?: return
        try { sendJs("window.onMusicTick && window.onMusicTick(${p.currentPosition}, ${p.duration}, ${p.isPlaying})") }
        catch (_: Exception) { }
    }

    private fun stopPlayerOnly() {
        handler.removeCallbacks(tick)
        try { player?.reset(); player?.release() } catch (_: Exception) { }
        player = null
    }

    fun stopPlayback() {
        stopPlayerOnly()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun buildNotification(title: String, playing: Boolean): Notification {
        val open = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP).putExtra("lifeos_tab", "mus")
        val content = PendingIntent.getActivity(this, 73022, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val pauseAction = if (playing) ACTION_PAUSE else ACTION_RESUME
        val pauseIcon = if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        val pause = PendingIntent.getService(this, 73023, Intent(this, MusicPlaybackService::class.java).setAction(pauseAction), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 73024, Intent(this, MusicPlaybackService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(title)
            .setContentText(if (playing) "Playing from Life OS" else "Paused · Life OS music")
            .setContentIntent(content)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(pauseIcon, if (playing) "Pause" else "Resume", pause).build())
            .addAction(Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stop).build())
            .build()
    }

    private fun updateNotification() {
        val playing = try { player?.isPlaying == true } catch (_: Exception) { false }
        val notification = buildNotification(trackTitle, playing)
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIFICATION_ID, notification)
    }

    private fun sendJs(script: String) {
        webRef?.get()?.post { webRef?.get()?.evaluateJavascript(script, null) }
    }

    override fun onBind(intent: Intent?) = null

    override fun onDestroy() {
        stopPlayerOnly()
        active = null
        super.onDestroy()
    }

}

class LifeOsReminderReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra("id", (intent.dataString ?: "lifeos").hashCode() and 0x7fffffff)
        val title = intent.getStringExtra("title") ?: "Life OS reminder"
        val body = intent.getStringExtra("body") ?: "You have a reminder"
        val go = intent.getStringExtra("go") ?: ""
        val date = intent.getStringExtra("date") ?: ""
        ReminderNotifications.show(context, title, body, id, go, date)
    }
}

object ReminderNotifications {
    private const val CHANNEL = "lifeos_reminders"
    fun show(context: Context, title: String, body: String, id: Int, go: String?, date: String?) {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel(CHANNEL, "Life OS reminders", NotificationManager.IMPORTANCE_DEFAULT))
        val open = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("lifeos_tab", go ?: "")
            putExtra("lifeos_date", date ?: "")
        }
        val pending = PendingIntent.getActivity(context, id, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(context, CHANNEL) else Notification.Builder(context)
        notification.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(Notification.BigTextStyle().bigText(body))
            .setContentIntent(pending)
            .setAutoCancel(true)
        manager.notify(id, notification.build())
    }
}
