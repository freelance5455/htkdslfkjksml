#!/usr/bin/env bash
set -euo pipefail
if [[ -x "./gradlew" ]]; then
  ./gradlew :app:assembleDebug
elif command -v gradle >/dev/null 2>&1; then
  gradle :app:assembleDebug
else
  echo "Gradle is not installed. Open this folder in Android Studio, or install Gradle 8.9 and rerun this script." >&2
  exit 1
fi
echo "APK: app/build/outputs/apk/debug/app-debug.apk"
