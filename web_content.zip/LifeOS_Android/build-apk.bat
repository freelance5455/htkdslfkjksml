@echo off
if exist gradlew.bat (
  call gradlew.bat :app:assembleDebug
) else (
  where gradle >nul 2>nul
  if errorlevel 1 (
    echo Gradle is not installed. Open this folder in Android Studio or install Gradle 8.9.
    exit /b 1
  )
  gradle :app:assembleDebug
)
if errorlevel 1 exit /b %errorlevel%
echo APK: app\build\outputs\apk\debug\app-debug.apk
