// Модуль для механики покупок
window.gameShop = {
    buyBusiness(id) {
        const business = window.gameState.businesses.find(b => b.id === id);
        if (!business || window.gameState.balance < business.cost) return;

        // Списываем деньги
        window.gameState.balance -= business.cost;
        
        // Увеличиваем количество предприятий
        business.count++;
        
        // Увеличиваем цену на 15% для следующей покупки (инфляция в стиле симуляторов)
        business.cost = Math.floor(business.cost * 1.15);

        // Пересчитываем доход и силу клика
        window.gameStorage.recalculatePPS();

        // Обновляем интерфейс и сохраняем прогресс
        window.gameUI.updateCounters();
        window.gameUI.renderShop();
        window.gameStorage.save();
    }
};
