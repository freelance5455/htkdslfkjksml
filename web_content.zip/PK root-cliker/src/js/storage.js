// Модуль для сохранения и загрузки прогресса
window.gameStorage = {
    saveKey: 'business_empire_clicker_save',

    save() {
        const dataToSave = {
            balance: window.gameState.balance,
            businesses: window.gameState.businesses.map(b => ({ id: b.id, count: b.count, cost: b.cost }))
        };
        localStorage.setItem(this.saveKey, JSON.stringify(dataToSave));
    },

    load() {
        const savedData = localStorage.getItem(this.saveKey);
        if (!savedData) return;

        try {
            const parsed = JSON.parse(savedData);
            window.gameState.balance = parsed.balance || 0;
            
            if (parsed.businesses) {
                parsed.businesses.forEach(savedBusiness => {
                    const business = window.gameState.businesses.find(b => b.id === savedBusiness.id);
                    if (business) {
                        business.count = savedBusiness.count || 0;
                        business.cost = savedBusiness.cost || business.cost;
                    }
                });
            }
            this.recalculatePPS();
        } catch (e) {
            console.error("Ошибка загрузки сохранения", e);
        }
    },

    recalculatePPS() {
        let totalPPS = 0;
        let totalPPC = 1;

        window.gameState.businesses.forEach(b => {
            totalPPS += b.count * b.income;
            // Каждые 2 бизнеса увеличивают силу клика на 1
            totalPPC += Math.floor(b.count / 2);
        });

        window.gameState.pps = totalPPS;
        window.gameState.ppc = totalPPC;
    }
};
