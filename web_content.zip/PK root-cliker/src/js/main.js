// Основной цикл и инициализация игры
document.addEventListener('DOMContentLoaded', () => {
    // 1. Загружаем сохраненную игру
    window.gameStorage.load();

    // 2. Первичная отрисовка интерфейса
    window.gameUI.updateCounters();
    window.gameUI.renderShop();

    // 3. Обработка клика по главной кнопке
    const clickButton = document.getElementById('click-button');
    clickButton.addEventListener('click', () => {
        window.gameState.balance += window.gameState.ppc;
        window.gameUI.updateCounters();
        
        // Перерисовываем магазин, так как баланс изменился и кнопки могли стать доступными
        window.gameUI.renderShop();
    });

    // 4. Ежесекундный таймер начисления пассивного дохода (PPS)
    setInterval(() => {
        if (window.gameState.pps > 0) {
            window.gameState.balance += window.gameState.pps;
            window.gameUI.updateCounters();
            window.gameUI.renderShop();
        }
    }, 1000);

    // 5. Автосохранение каждые 15 секунд
    setInterval(() => {
        window.gameStorage.save();
    }, 15000);
});
