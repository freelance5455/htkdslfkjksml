// Модуль управления интерфейсом
window.gameUI = {
    formatMoney(amount) {
        return '$' + amount.toLocaleString('ru-RU');
    },

    updateCounters() {
        document.getElementById('balance-display').innerText = this.formatMoney(window.gameState.balance);
        document.getElementById('pps-display').innerText = `+${this.formatMoney(window.gameState.pps)}/с`;
        document.getElementById('ppc-display').innerText = window.gameState.ppc;
    },

    renderShop() {
        const container = document.getElementById('shop-container');
        container.innerHTML = '';

        window.gameState.businesses.forEach(b => {
            const itemDiv = document.createElement('div');
            itemDiv.className = `shop-item ${window.gameState.balance < b.cost ? 'disabled' : ''}`;
            
            itemDiv.innerHTML = `
                <div class="item-info">
                    <span class="item-name">${b.icon} ${b.name} (${b.count})</span>
                    <span class="item-meta">Доход: +$${b.income}/с | Цена: ${this.formatMoney(b.cost)}</span>
                </div>
                <button class="buy-btn" data-id="${b.id}" ${window.gameState.balance < b.cost ? 'disabled' : ''}>
                    Купить
                </button>
            `;
            container.appendChild(itemDiv);
        });

        this.registerShopEvents();
    },

    registerShopEvents() {
        const buttons = document.querySelectorAll('.buy-btn');
        buttons.forEach(btn => {
            btn.onclick = (e) => {
                const id = e.target.getAttribute('data-id');
                window.gameShop.buyBusiness(id);
            };
        });
    }
};
