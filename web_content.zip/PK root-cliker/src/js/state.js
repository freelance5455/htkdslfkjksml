// Глобальное состояние игры
window.gameState = {
    balance: 0,
    pps: 0, // Profit Per Second (Доход в секунду)
    ppc: 1, // Profit Per Click (Доход за клик)
    
    // Перечень доступных бизнесов для покупки в стиле Business Empire
    businesses: [
        { id: 'taxi', name: 'Таксопарк', cost: 50, income: 1, count: 0, icon: '🚖' },
        { id: 'cafe', name: 'Сеть Кофеин', cost: 250, income: 5, count: 0, icon: '☕' },
        { id: 'shop', name: 'Супермаркет', cost: 1000, income: 25, count: 0, icon: '🛒' },
        { id: 'factory', name: 'Завод электроники', cost: 7500, income: 150, count: 0, icon: '🏭' },
        { id: 'bank', name: 'Коммерческий Банк', cost: 50000, income: 1200, count: 0, icon: '🏦' }
    ]
};
