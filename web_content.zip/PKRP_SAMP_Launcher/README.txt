PKRP SAMP LAUNCHER
==================

How to open:
1. Extract the ZIP file.
2. Open the extracted folder.
3. Double-click index.html (Chrome, Edge or another browser).

Features:
- Responsive dark green launcher interface
- Main server: Padakkalam Roleplay (PKRP)
- PLAY NOW button displays the "Server Under Maintenance" notice
- About PKRP popup

Note:
This is a front-end launcher mockup. It does not connect to or launch a live SA-MP server.
