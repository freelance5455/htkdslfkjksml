# ANONYMOUX STUDIO 2.5.5 — change log

## Changes
- Fish Audio Agent adapter now retains HTTP status and bounded provider diagnostics in server logs, classifies authentication, account access, invalid configuration, rate-limit and outage responses, and avoids replaying mutating requests.
- Fish Audio session creation now sends only the documented `agent_id` request field; the response object is passed through to the Fish web SDK as its session token. Provider session end is requested before usage reconciliation.
- Credit packages support administrator-configurable display order, promotional badge and optional bonus credits (zero by default). Existing package rows are upgraded additively.
- Missing proposed NGN package names are initialized without overwriting existing package records: Starter (250 / ₦2,500), Creator (600 / ₦6,000), Studio (1,500 / ₦15,000), Professional (3,500 / ₦35,000). Existing package records are not overwritten.
- Buy Credits displays per-credit pricing and optional package bonus information.
- New-wallet welcome-credit default is 250; existing wallet balances and explicitly configured admin settings are preserved.
- Shorts Studio navigation and onboarding workspace card removed. The old URL returns HTTP 404 with a safe route to Video Studio. Explore is preserved.

## Not claimed / pending
- Live Fish Audio Agent API, Flutterwave checkout/webhook and production-host acceptance tests require the owner's configured credentials and hosting environment; they were not run in this build environment.
- Agent billing rates and provider costs outside measured Fish usage have not been invented or changed.
