# My Mobile App PWA Package

This bundle turns your website into an installable Progressive Web App (PWA) for Android, iOS, Windows, and Mac.

## How to use:
1. Upload these files (`manifest.webmanifest`, `service-worker.js`, `offline.html`) to the root of your web server (public/ folder).
2. Add the following line inside your website's `<head>` tag:
   `<link rel="manifest" href="/manifest.webmanifest">`
3. Register the service worker in your JS file:
   ```javascript
   if ('serviceWorker' in navigator) {
     navigator.serviceWorker.register('/service-worker.js');
   }
   ```
Users visiting your website on Chrome, Safari, Edge, or Samsung Internet will now see the "Install App" button!
