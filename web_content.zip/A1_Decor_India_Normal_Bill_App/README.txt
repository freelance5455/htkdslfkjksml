A1 Decor India - Custom Bill Maker

Features:
- Image-style professional bill layout.
- Customizable business name, phone, tagline, address, GST and PAN.
- Upload your business logo.
- Upload YOUR authorized signature; customer signature remains blank.
- Custom bill accent colour.
- Customer and bill details.
- Measurement/area item calculation.
- Preview before print/share.
- Share full bill as PNG image or PDF using Android Web Share when supported.
- WhatsApp Bill shares the full bill image, not just a text message, when Android Web Share supports files.
- Local storage for business settings, logo, signature and bill history.

For HTML-to-APK converters, upload this ZIP with index.html at the project root/folder as required by the converter.
The image/PDF share features use html2canvas and jsPDF from CDN, so the generated APK should allow internet access for those libraries unless the converter bundles them.

Fullscreen visual update: mobile preview is edge-to-edge, bill scales to screen width, logo has rounded corners, and shared image/PDF captures the complete bill.

Professional bill layout updated. Signature is larger, with manual Crop Signature and Auto Crop. PDF sharing now uses file sharing when supported and otherwise saves a PDF for WhatsApp attachment.


Latest fixes: rounded logo corners; invoice preview table now includes Area / Unit plus a dedicated Rate column; PDF sharing uses Android/Web Share when supported and otherwise opens/downloads the generated PDF for manual sharing.
