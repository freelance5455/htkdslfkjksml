# FF HEADSHOT PANEL

Unofficial companion app for Free Fire players: sensitivity reference sliders, DPI guide, aim guide,
HUD layout guide, daily training tracker and device profiles. React + TypeScript + Tailwind, saves
everything in LocalStorage, installable as a PWA, packaged for Android with Capacitor.

It does not modify game files and contains no cheats, injectors or memory editors.

## Run in the browser
```bash
npm install
npm run dev
```

## Build the APK (Android)
Requirements: Node 18+, JDK 17, Android Studio (with Android SDK).

```bash
npm install
npm run icons            # makes launcher icons from /assets (run after android:add)
npm run android:add      # first time only, creates the /android project
npm run android:sync     # builds the web app and copies it into Android
npm run android:open     # opens Android Studio
```

In Android Studio: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
The debug APK is at `android/app/build/outputs/apk/debug/app-debug.apk`. Copy it to your phone and install it
(allow "Install unknown apps" for your file manager).

Order tip: run `npm run android:add` first, then `npm run icons`, then `npm run android:sync`.

### Release APK (for sharing)
Android Studio → **Build → Generate Signed Bundle / APK → APK**, create a keystore, choose *release*.
Keep the keystore file and passwords safe: you need the same one for every future update.

## PWA
`npm run build` outputs `dist/` with `manifest.webmanifest` and `sw.js`. Host it on any HTTPS site and the browser
will offer "Add to Home screen".
