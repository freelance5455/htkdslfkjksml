/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#080406',
        panel: '#150a0d',
        panel2: '#1d0f13',
        line: '#33161c',
        blood: '#6b0c19',
        neon: '#ff1f3d',
        bone: '#f4e9ea',
        mute: '#a58a8e',
      },
      fontFamily: {
        game: ['"Chakra Petch"', 'Bahnschrift', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        neon: '0 0 0 1px rgba(255,31,61,.55), 0 0 18px rgba(255,31,61,.35)',
      },
      keyframes: {
        pulseRing: {
          '0%,100%': { opacity: '.55', transform: 'scale(1)' },
          '50%': { opacity: '1', transform: 'scale(1.04)' },
        },
        rise: {
          from: { opacity: '0', transform: 'translateY(8px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
      },
      animation: {
        pulseRing: 'pulseRing 3s ease-in-out infinite',
        rise: 'rise .25s ease-out both',
      },
    },
  },
  plugins: [],
};
