import { useState } from 'react';
import { RotateCcw, Save } from 'lucide-react';
import { Button, Card, Notice, PageHeader, Slider } from '../components/ui';
import { DEFAULT_SENS, SENS_FIELDS, Sens, SensKey, useStore } from '../store';
import { useToast } from '../toast';
import type { Route } from '../router';

export default function Sensitivity({ go }: { go: (r: Route) => void }) {
  const { state, update } = useStore();
  const toast = useToast();
  const [draft, setDraft] = useState<Sens>(state.sens);
  const dirty = (Object.keys(draft) as SensKey[]).some((k) => draft[k] !== state.sens[k]);

  const save = () => {
    update((s) => ({ ...s, sens: draft, activeProfileId: null }));
    toast('Sensitivity saved');
  };
  const reset = () => {
    setDraft(DEFAULT_SENS);
    update((s) => ({ ...s, sens: DEFAULT_SENS, activeProfileId: null }));
    toast('Reset to default values');
  };

  return (
    <div className="animate-rise">
      <PageHeader
        title="Sensitivity settings"
        sub="Set your preferred values here, then copy them into Free Fire under Settings → Sensitivity."
        onBack={() => go('home')}
      />

      <Card className="divide-y divide-line !py-1">
        {SENS_FIELDS.map((f) => (
          <Slider
            key={f.key}
            label={f.label}
            hint={f.hint}
            value={draft[f.key]}
            onChange={(v) => setDraft((d) => ({ ...d, [f.key]: v }))}
          />
        ))}
      </Card>

      {dirty && <p className="mt-3 text-center text-xs font-semibold text-neon">You have unsaved changes</p>}

      <div className="mt-4 grid grid-cols-2 gap-3">
        <Button onClick={save} disabled={!dirty}>
          <Save size={18} /> Save
        </Button>
        <Button variant="ghost" onClick={reset}>
          <RotateCcw size={18} /> Reset
        </Button>
      </div>

      <div className="mt-5 space-y-3">
        <Notice>
          This app does not change the game. These values are stored on your phone as a reference, and you enter
          them in Free Fire yourself. Starting points are not a guarantee; test in Training Ground and adjust by 3–5
          points at a time.
        </Notice>
        <button
          onClick={() => go('profiles')}
          className="w-full rounded-xl border border-line bg-panel py-3 text-sm font-semibold text-bone active:border-neon/60"
        >
          Save these as a device profile
        </button>
      </div>
    </div>
  );
}
