import { Crosshair, Dumbbell, Smartphone, Gauge, Target, LayoutGrid, ChevronRight, Flame } from 'lucide-react';
import { Card, Logo } from '../components/ui';
import { SENS_FIELDS, streak, todayKey, useStore } from '../store';
import { EXERCISES } from '../data';
import type { Route } from '../router';

export default function Home({ go }: { go: (r: Route) => void }) {
  const { state } = useStore();
  const doneToday = state.training[todayKey()]?.length ?? 0;
  const days = streak(state.training);

  const shortcuts: { route: Route; title: string; desc: string; Icon: typeof Crosshair }[] = [
    { route: 'training', title: 'Headshot training', desc: 'Daily drills and progress', Icon: Dumbbell },
    { route: 'sensitivity', title: 'Sensitivity settings', desc: 'Sliders for every scope', Icon: Crosshair },
    { route: 'profiles', title: 'Device optimization', desc: 'Low, mid and high-end profiles', Icon: Smartphone },
  ];
  const guides: { route: Route; title: string; Icon: typeof Crosshair }[] = [
    { route: 'dpi', title: 'DPI guide', Icon: Gauge },
    { route: 'aim', title: 'Aim precision', Icon: Target },
    { route: 'hud', title: 'Custom HUD', Icon: LayoutGrid },
  ];

  return (
    <div className="animate-rise">
      <div className="flex flex-col items-center pb-6 pt-4 text-center">
        <Logo size={84} />
        <h1 className="neon-text mt-4 text-3xl font-bold tracking-wide">FF HEADSHOT PANEL</h1>
        <p className="mt-2 max-w-xs text-sm leading-relaxed text-mute">
          Welcome back. Tune your sensitivity, practise your aim and match your settings to your phone.
        </p>
      </div>

      <div className="mb-5 grid grid-cols-2 gap-3">
        <Card className="!p-3.5">
          <p className="text-xs text-mute">Today&apos;s drills</p>
          <p className="mt-1 text-2xl font-bold">
            {doneToday}
            <span className="text-base text-mute"> / {EXERCISES.length}</span>
          </p>
        </Card>
        <Card className="!p-3.5">
          <p className="text-xs text-mute">Practice streak</p>
          <p className="mt-1 flex items-center gap-1.5 text-2xl font-bold">
            <Flame size={22} className="text-neon" />
            {days} {days === 1 ? 'day' : 'days'}
          </p>
        </Card>
      </div>

      <div className="space-y-3">
        {shortcuts.map(({ route, title, desc, Icon }) => (
          <button
            key={route}
            onClick={() => go(route)}
            className="flex w-full items-center gap-4 rounded-2xl border border-line bg-panel p-4 text-left active:border-neon/60 active:bg-panel2"
          >
            <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-blood/50 text-neon">
              <Icon size={24} />
            </span>
            <span className="flex-1">
              <span className="block font-bold">{title}</span>
              <span className="text-xs text-mute">{desc}</span>
            </span>
            <ChevronRight size={20} className="text-mute" />
          </button>
        ))}
      </div>

      <h2 className="mb-3 mt-7 text-sm font-semibold text-mute">Guides</h2>
      <div className="grid grid-cols-3 gap-3">
        {guides.map(({ route, title, Icon }) => (
          <button
            key={route}
            onClick={() => go(route)}
            className="flex flex-col items-center gap-2 rounded-2xl border border-line bg-panel px-2 py-4 text-center text-xs font-semibold active:border-neon/60"
          >
            <Icon size={22} className="text-neon" />
            {title}
          </button>
        ))}
      </div>

      <Card className="mt-7">
        <h2 className="mb-3 text-sm font-semibold text-mute">Your saved sensitivity</h2>
        <dl className="grid grid-cols-2 gap-x-6 gap-y-2 text-sm">
          {SENS_FIELDS.map((f) => (
            <div key={f.key} className="flex justify-between">
              <dt className="text-mute">{f.label}</dt>
              <dd className="font-bold tabular-nums">{state.sens[f.key]}</dd>
            </div>
          ))}
        </dl>
      </Card>

      <p className="mt-6 text-center text-[11px] leading-relaxed text-mute">
        Unofficial guide app. Not affiliated with Garena. Results depend on practice and your device.
      </p>
    </div>
  );
}
