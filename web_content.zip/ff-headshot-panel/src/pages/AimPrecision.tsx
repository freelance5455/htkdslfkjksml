import { Accordion, Bullets, Notice, PageHeader } from '../components/ui';
import type { Route } from '../router';

export default function AimPrecision({ go }: { go: (r: Route) => void }) {
  return (
    <div className="animate-rise">
      <PageHeader
        title="Aim precision"
        sub="Legitimate settings and habits that improve your aim over time."
        onBack={() => go('home')}
      />
      <div className="space-y-3">
        <Accordion title="In-game settings to check" defaultOpen>
          <Bullets
            items={[
              'Open Settings → Sensitivity and set values for General, Red Dot, 2x, 4x, Sniper and Free Look.',
              'Use lower values for higher-zoom scopes. Small movements matter more at long range.',
              'If your version of the game offers gyroscope aiming, try it in Training Ground before using it in a match.',
              'Pick a graphics and frame rate setting your phone can hold steady.',
            ]}
          />
        </Accordion>

        <Accordion title="Crosshair placement">
          <Bullets
            items={[
              'Keep your crosshair at head height while you move, so you only make small corrections.',
              'Aim at corners and doorways before you peek around them.',
              'After each fight, return the crosshair to head height right away.',
            ]}
          />
        </Accordion>

        <Accordion title="Drag, tap and burst">
          <Bullets
            items={[
              'Drag: fire while moving your thumb up to the head. Smooth, short drags beat fast, wild ones.',
              'Tap: single shots with a quick correction in between. Good at longer range.',
              'Burst: short controlled sprays. Emptying the magazine at once makes recoil hard to manage.',
            ]}
          />
        </Accordion>

        <Accordion title="Movement and positioning">
          <Bullets
            items={[
              'Strafe side to side while firing so you are harder to hit.',
              'Fight from cover. Peek, shoot, return.',
              'Choose fights where you have the advantage: high ground, cover nearby, enemy in the open.',
            ]}
          />
        </Accordion>

        <Accordion title="Practice routine">
          <Bullets
            items={[
              '10–20 minutes of Training Ground a day beats one long session a week.',
              'Change one setting at a time and test it for several matches before judging it.',
              'Take breaks. Tired thumbs and eyes make aim worse.',
            ]}
          />
        </Accordion>

        <Notice>
          Good aim comes from practice. No setting or app can guarantee headshots, and nothing here protects an account
          from game rules. Play fair and do not use hacks or modified game files.
        </Notice>
      </div>
    </div>
  );
}
