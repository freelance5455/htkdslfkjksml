import { useState } from 'react';
import { Bullets, Card, Notice, PageHeader } from '../components/ui';
import { FingerStyle, HUD_LAYOUTS } from '../data';
import type { Route } from '../router';

export default function CustomHud({ go }: { go: (r: Route) => void }) {
  const [style, setStyle] = useState<FingerStyle>('3');
  const layout = HUD_LAYOUTS[style];

  return (
    <div className="animate-rise">
      <PageHeader
        title="Custom HUD"
        sub="Pick how many fingers you use to see a suggested button layout."
        onBack={() => go('home')}
      />

      <div role="tablist" aria-label="Finger style" className="mb-4 grid grid-cols-3 gap-2">
        {(['2', '3', '4'] as FingerStyle[]).map((s) => (
          <button
            key={s}
            role="tab"
            aria-selected={style === s}
            onClick={() => setStyle(s)}
            className={`min-h-[48px] rounded-xl border text-sm font-bold ${
              style === s ? 'border-neon bg-neon/15 text-neon' : 'border-line bg-panel text-mute'
            }`}
          >
            {s} fingers
          </button>
        ))}
      </div>

      <Card className="!p-3">
        <svg viewBox="0 0 420 190" className="w-full" role="img" aria-label={`HUD layout for ${layout.title}`}>
          <rect x="2" y="2" width="416" height="186" rx="18" fill="#0b0507" stroke="#33161c" strokeWidth="2" />
          {layout.buttons.map((b) => (
            <g key={b.label}>
              <circle
                cx={b.x}
                cy={b.y}
                r={b.r}
                fill={b.big ? 'rgba(255,31,61,.22)' : 'rgba(255,31,61,.1)'}
                stroke="#ff1f3d"
                strokeWidth={b.big ? 2.5 : 1.5}
              />
              <text
                x={b.x}
                y={b.y + 4}
                textAnchor="middle"
                fontSize={b.r > 24 ? 11 : 9}
                fontWeight="700"
                fill="#f4e9ea"
              >
                {b.label}
              </text>
            </g>
          ))}
        </svg>
        <p className="mt-2 text-center text-xs text-mute">{layout.title}</p>
      </Card>

      <Card className="mt-4">
        <h2 className="mb-3 font-bold">Placement tips</h2>
        <Bullets items={layout.notes} />
      </Card>

      <Card className="mt-4">
        <h2 className="mb-3 font-bold">How to apply it in the game</h2>
        <Bullets
          items={[
            'Open Free Fire Settings → Layout (or Customize HUD).',
            'Drag each button to the suggested spot and use the size slider for Fire and Move.',
            'Save, then test in Training Ground and nudge buttons until nothing feels cramped.',
          ]}
        />
      </Card>

      <div className="mt-4">
        <Notice>Layouts are personal. Use these as a starting point and adjust to your hand size and phone.</Notice>
      </div>
    </div>
  );
}
