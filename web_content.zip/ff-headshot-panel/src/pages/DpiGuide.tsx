import { Accordion, Bullets, Notice, PageHeader } from '../components/ui';
import type { Route } from '../router';

export default function DpiGuide({ go }: { go: (r: Route) => void }) {
  return (
    <div className="animate-rise">
      <PageHeader
        title="DPI guide"
        sub="What DPI means on a phone, and how to set up your device safely."
        onBack={() => go('home')}
      />
      <div className="space-y-3">
        <Accordion title="What is DPI?" defaultOpen>
          <p>
            DPI means dots per inch. On Android it describes screen density: how many pixels fit in one inch of your
            display. A higher DPI makes buttons and text smaller on screen; a lower DPI makes them bigger.
          </p>
          <p>
            DPI does not change how fast your aim moves. In Free Fire, aim speed comes from the sensitivity sliders,
            your screen's touch response and your frame rate.
          </p>
        </Accordion>

        <Accordion title="Guidance by device type">
          <p className="font-semibold text-neon">Low-end</p>
          <Bullets
            items={[
              'Keep the default display size. Changing it will not make the game faster.',
              'Lower in-game graphics and frame rate settings first.',
              'Free up storage and close other apps before you play.',
            ]}
          />
          <p className="pt-2 font-semibold text-neon">Mid-range</p>
          <Bullets
            items={[
              'Use the default or one step smaller display size so the HUD has more room.',
              'Enable your phone\'s game mode or performance mode if it has one.',
            ]}
          />
          <p className="pt-2 font-semibold text-neon">High-end</p>
          <Bullets
            items={[
              'Set the screen refresh rate to its highest stable option in Display settings.',
              'Watch temperature. A hot phone slows down and makes aim feel inconsistent.',
            ]}
          />
        </Accordion>

        <Accordion title="Change display size safely">
          <Bullets
            items={[
              'Open Settings → Display → Display size and text (on Samsung: Screen zoom).',
              'Move the slider one step at a time and check that you can still read and tap everything.',
              'Open Free Fire and check that the HUD buttons are still easy to reach.',
              'If something feels wrong, go back to the default step.',
            ]}
          />
          <Notice>
            Avoid third-party "DPI changer" apps and developer-option tricks that need root or computer commands. They
            can make the screen hard to use and may cause problems you cannot easily undo.
          </Notice>
        </Accordion>

        <Accordion title="Improve touch response">
          <Bullets
            items={[
              'Clean the screen and your thumbs. Sweat and dust change touch accuracy.',
              'Thick or cracked screen protectors reduce response. A thin tempered glass works best.',
              'If your phone has a touch sensitivity or glove mode setting, try it with your protector on.',
              'Turn on Do Not Disturb so notifications do not interrupt your match.',
              'Keep your phone cool and avoid playing while charging at high heat.',
            ]}
          />
        </Accordion>
      </div>
    </div>
  );
}
