import { FormEvent, useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { Button, Card, Notice, PageHeader } from '../components/ui';
import { PRESETS } from '../data';
import { SENS_FIELDS, Sens, useStore } from '../store';
import { useToast } from '../toast';
import type { Route } from '../router';

function Summary({ sens }: { sens: Sens }) {
  return (
    <dl className="mt-3 grid grid-cols-3 gap-2 text-center">
      {SENS_FIELDS.map((f) => (
        <div key={f.key} className="rounded-lg bg-ink/60 px-1 py-2">
          <dd className="text-base font-bold tabular-nums text-neon">{sens[f.key]}</dd>
          <dt className="text-[10px] leading-tight text-mute">{f.label}</dt>
        </div>
      ))}
    </dl>
  );
}

export default function Profiles({ go }: { go: (r: Route) => void }) {
  const { state, update } = useStore();
  const toast = useToast();
  const [name, setName] = useState('');

  const apply = (id: string, sens: Sens, label: string) => {
    update((s) => ({ ...s, sens: { ...sens }, activeProfileId: id }));
    toast(`${label} applied`);
  };

  const saveCustom = (e: FormEvent) => {
    e.preventDefault();
    const n = name.trim();
    if (!n) {
      toast('Enter a profile name first');
      return;
    }
    const id = `custom-${Date.now()}`;
    update((s) => ({ ...s, profiles: [...s.profiles, { id, name: n, sens: { ...s.sens } }], activeProfileId: id }));
    setName('');
    toast('Profile saved');
  };

  const remove = (id: string) => {
    update((s) => ({
      ...s,
      profiles: s.profiles.filter((p) => p.id !== id),
      activeProfileId: s.activeProfileId === id ? null : s.activeProfileId,
    }));
    toast('Profile deleted');
  };

  return (
    <div className="animate-rise">
      <PageHeader
        title="Device profiles"
        sub="Start from a preset for your phone class, or save your own."
        onBack={() => go('home')}
      />

      <div className="space-y-4">
        {PRESETS.map((p) => {
          const active = state.activeProfileId === p.id;
          return (
            <Card key={p.id} className={active ? '!border-neon/70' : ''}>
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h2 className="font-bold">{p.name}</h2>
                  <p className="text-xs text-mute">{p.tagline}</p>
                </div>
                {active && <span className="rounded-md bg-neon/20 px-2 py-1 text-[11px] font-bold text-neon">Active</span>}
              </div>
              <Summary sens={p.sens} />
              <ul className="mt-3 space-y-1.5 text-xs leading-relaxed text-mute">
                {p.tips.map((t) => (
                  <li key={t}>• {t}</li>
                ))}
              </ul>
              <Button className="mt-4 w-full" variant={active ? 'ghost' : 'primary'} onClick={() => apply(p.id, p.sens, p.name)}>
                Use this profile
              </Button>
            </Card>
          );
        })}
      </div>

      <h2 className="mb-3 mt-7 text-sm font-semibold text-mute">My profiles</h2>
      <Card>
        <form onSubmit={saveCustom} className="space-y-3">
          <label htmlFor="pname" className="block text-sm font-semibold">
            Save your current sensitivity as a profile
          </label>
          <input
            id="pname"
            value={name}
            onChange={(e) => setName(e.target.value)}
            maxLength={30}
            placeholder="e.g. My phone, Tournament"
            className="min-h-[48px] w-full rounded-xl border border-line bg-ink px-3.5 text-sm text-bone placeholder:text-mute focus:border-neon"
          />
          <Button type="submit" className="w-full">
            <Plus size={18} /> Save profile
          </Button>
        </form>
      </Card>

      {state.profiles.length === 0 ? (
        <p className="mt-4 text-center text-sm text-mute">No saved profiles yet. Name one above to create it.</p>
      ) : (
        <div className="mt-4 space-y-4">
          {state.profiles.map((p) => {
            const active = state.activeProfileId === p.id;
            return (
              <Card key={p.id} className={active ? '!border-neon/70' : ''}>
                <div className="flex items-center justify-between gap-3">
                  <h3 className="font-bold">{p.name}</h3>
                  {active && <span className="rounded-md bg-neon/20 px-2 py-1 text-[11px] font-bold text-neon">Active</span>}
                </div>
                <Summary sens={p.sens} />
                <div className="mt-4 grid grid-cols-[1fr_auto] gap-3">
                  <Button onClick={() => apply(p.id, p.sens, p.name)} variant={active ? 'ghost' : 'primary'}>
                    Use this profile
                  </Button>
                  <Button variant="danger" onClick={() => remove(p.id)} ariaLabel={`Delete ${p.name}`}>
                    <Trash2 size={18} />
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      <div className="mt-5">
        <Notice>Presets are starting points, not guaranteed best values. Adjust after testing on your own device.</Notice>
      </div>
    </div>
  );
}
