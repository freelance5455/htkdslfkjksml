import { useState } from 'react';
import { RotateCcw } from 'lucide-react';
import { Button, Card, Logo, PageHeader, Toggle } from '../components/ui';
import { DEFAULT_STATE, useStore } from '../store';
import { useToast } from '../toast';
import type { Route } from '../router';

export default function SettingsPage({ go }: { go: (r: Route) => void }) {
  const { state, update, resetAll } = useStore();
  const toast = useToast();
  const [confirm, setConfirm] = useState(false);

  const setPref = (k: 'glow' | 'reduceMotion', v: boolean) =>
    update((s) => ({ ...s, prefs: { ...s.prefs, [k]: v } }));

  return (
    <div className="animate-rise">
      <PageHeader title="Settings" sub="Changes save automatically on this device." onBack={() => go('home')} />

      <Card className="divide-y divide-line !py-1">
        <div className="flex items-center justify-between py-3">
          <div>
            <p className="font-semibold">Dark theme</p>
            <p className="mt-0.5 text-xs text-mute">Always on to keep the game-ready look</p>
          </div>
          <span className="rounded-md bg-neon/20 px-2 py-1 text-[11px] font-bold text-neon">On</span>
        </div>
        <Toggle
          label="Neon glow"
          desc="Glowing red highlights on titles and buttons"
          checked={state.prefs.glow}
          onChange={(v) => setPref('glow', v)}
        />
        <Toggle
          label="Reduce animations"
          desc="Turns off movement effects"
          checked={state.prefs.reduceMotion}
          onChange={(v) => setPref('reduceMotion', v)}
        />
      </Card>

      <Card className="mt-4">
        <h2 className="font-bold">Reset settings</h2>
        <p className="mt-1 text-sm text-mute">
          Restores default preferences and sensitivity, and deletes saved profiles and training history.
        </p>
        {!confirm ? (
          <Button variant="danger" className="mt-4 w-full" onClick={() => setConfirm(true)}>
            <RotateCcw size={18} /> Reset everything
          </Button>
        ) : (
          <div className="mt-4 grid grid-cols-2 gap-3">
            <Button variant="ghost" onClick={() => setConfirm(false)}>
              Keep my data
            </Button>
            <Button
              onClick={() => {
                resetAll();
                setConfirm(false);
                toast('Everything reset');
              }}
            >
              Yes, reset
            </Button>
          </div>
        )}
        <button
          onClick={() => {
            update((s) => ({ ...s, prefs: DEFAULT_STATE.prefs }));
            toast('Display preferences reset');
          }}
          className="mt-3 w-full py-2 text-xs font-semibold text-mute underline"
        >
          Reset display preferences only
        </button>
      </Card>

      <Card className="mt-4">
        <div className="flex items-center gap-4">
          <Logo size={52} />
          <div>
            <h2 className="font-bold">About FF HEADSHOT PANEL</h2>
            <p className="text-xs text-mute">Version 1.0.0</p>
          </div>
        </div>
        <p className="mt-4 text-sm leading-relaxed text-mute">
          A companion guide for sensitivity, aim practice, HUD layout and device setup. It works offline and keeps all
          your data on your phone.
        </p>
        <p className="mt-3 text-sm leading-relaxed text-mute">
          This is an unofficial app and is not affiliated with Garena or Free Fire. It does not modify game files, and it
          contains no cheats, injectors or memory editors. It cannot promise headshots or protect any account from bans.
        </p>
      </Card>
    </div>
  );
}
