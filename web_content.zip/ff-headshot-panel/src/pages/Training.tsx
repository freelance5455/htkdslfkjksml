import { Check, Flame } from 'lucide-react';
import { Card, Notice, PageHeader } from '../components/ui';
import { DRAG_STEPS, EXERCISES } from '../data';
import { streak, todayKey, useStore } from '../store';
import type { Route } from '../router';

function lastDays(n: number): { key: string; label: string }[] {
  const out: { key: string; label: string }[] = [];
  const names = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    out.push({ key: todayKey(d), label: names[d.getDay()] });
  }
  return out;
}

export default function Training({ go }: { go: (r: Route) => void }) {
  const { state, update } = useStore();
  const today = todayKey();
  const done = state.training[today] ?? [];
  const totalMin = EXERCISES.reduce((a, e) => a + e.minutes, 0);
  const doneMin = EXERCISES.filter((e) => done.includes(e.id)).reduce((a, e) => a + e.minutes, 0);
  const days = lastDays(7);
  const totalSessions = Object.values(state.training).filter((v) => v.length > 0).length;

  const toggle = (id: string) =>
    update((s) => {
      const cur = s.training[today] ?? [];
      const next = cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id];
      const training = { ...s.training };
      if (next.length === 0) delete training[today];
      else training[today] = next;
      return { ...s, training };
    });

  return (
    <div className="animate-rise">
      <PageHeader
        title="Headshot training"
        sub="Short daily drills. Tick each one when you finish it in Training Ground."
        onBack={() => go('home')}
      />

      <Card>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs text-mute">Today</p>
            <p className="text-2xl font-bold">
              {done.length}
              <span className="text-base text-mute"> / {EXERCISES.length} drills</span>
            </p>
            <p className="text-xs text-mute">
              {doneMin} of {totalMin} minutes
            </p>
          </div>
          <div className="text-right">
            <p className="text-xs text-mute">Streak</p>
            <p className="flex items-center justify-end gap-1 text-2xl font-bold">
              <Flame size={22} className="text-neon" />
              {streak(state.training)}
            </p>
            <p className="text-xs text-mute">{totalSessions} days practised</p>
          </div>
        </div>

        <div className="mt-4 h-2 overflow-hidden rounded-full bg-line">
          <div
            className="h-full rounded-full bg-neon transition-all"
            style={{ width: `${(done.length / EXERCISES.length) * 100}%` }}
          />
        </div>

        <div className="mt-5 flex items-end justify-between gap-2" aria-label="Last 7 days">
          {days.map((d) => {
            const n = state.training[d.key]?.length ?? 0;
            const h = 8 + (n / EXERCISES.length) * 44;
            return (
              <div key={d.key} className="flex flex-1 flex-col items-center gap-1.5">
                <div className="flex h-14 items-end">
                  <div
                    className={`w-6 rounded-md ${n > 0 ? 'bg-neon' : 'bg-line'}`}
                    style={{ height: h }}
                    title={`${n} drills`}
                  />
                </div>
                <span className={`text-[11px] ${d.key === today ? 'font-bold text-bone' : 'text-mute'}`}>
                  {d.label}
                </span>
              </div>
            );
          })}
        </div>
      </Card>

      <h2 className="mb-3 mt-6 text-sm font-semibold text-mute">Daily exercises</h2>
      <ul className="space-y-3">
        {EXERCISES.map((e) => {
          const checked = done.includes(e.id);
          return (
            <li key={e.id}>
              <button
                onClick={() => toggle(e.id)}
                aria-pressed={checked}
                className={`flex w-full items-start gap-3.5 rounded-2xl border p-4 text-left ${
                  checked ? 'border-neon/60 bg-blood/25' : 'border-line bg-panel'
                }`}
              >
                <span
                  className={`mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border-2 ${
                    checked ? 'border-neon bg-neon text-white' : 'border-mute'
                  }`}
                >
                  {checked && <Check size={16} strokeWidth={3} />}
                </span>
                <span className="flex-1">
                  <span className="flex items-baseline justify-between gap-2">
                    <span className="font-bold">{e.title}</span>
                    <span className="text-xs text-mute">{e.minutes} min</span>
                  </span>
                  <span className="mt-1 block text-sm leading-relaxed text-mute">{e.how}</span>
                </span>
              </button>
            </li>
          );
        })}
      </ul>

      <Card className="mt-6">
        <h2 className="mb-3 font-bold">Drag headshot practice</h2>
        <ol className="space-y-3 text-sm leading-relaxed">
          {DRAG_STEPS.map((s, i) => (
            <li key={s} className="flex gap-3">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-blood text-xs font-bold text-neon">
                {i + 1}
              </span>
              <span>{s}</span>
            </li>
          ))}
        </ol>
      </Card>

      <div className="mt-4">
        <Notice>Progress improves with regular practice. Tracking your drills helps you stay consistent but does not promise results.</Notice>
      </div>
    </div>
  );
}
