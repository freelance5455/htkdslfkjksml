import type { Sens } from './store';

export interface Preset {
  id: string;
  name: string;
  tagline: string;
  sens: Sens;
  tips: string[];
}

/** Starting points only. Every player and device feels different. */
export const PRESETS: Preset[] = [
  {
    id: 'preset-low',
    name: 'Low-end device',
    tagline: '2–3 GB RAM, older chipsets',
    sens: { general: 80, redDot: 75, scope2x: 70, scope4x: 64, sniper: 55, freeLook: 65 },
    tips: [
      'Set graphics to Smooth and frame rate to Standard or Medium so frames stay even.',
      'Uneven frames make drags feel inconsistent, so start a little lower and raise slowly.',
      'Close background apps and keep at least 3 GB of storage free before playing.',
      'Turn off battery saver while playing; it can throttle the processor.',
    ],
  },
  {
    id: 'preset-mid',
    name: 'Mid-range device',
    tagline: '4–6 GB RAM, recent mid chipsets',
    sens: { general: 88, redDot: 82, scope2x: 76, scope4x: 70, sniper: 60, freeLook: 70 },
    tips: [
      'Balanced graphics with High frame rate (if offered) is a good middle ground.',
      'Test the numbers in Training Ground for 10 minutes before changing anything else.',
      'Change one slider at a time so you know which change helped.',
    ],
  },
  {
    id: 'preset-high',
    name: 'High-end device',
    tagline: '8 GB+ RAM, flagship chipsets, 90–120 Hz screens',
    sens: { general: 95, redDot: 90, scope2x: 84, scope4x: 78, sniper: 68, freeLook: 75 },
    tips: [
      'High refresh rate screens respond faster, so you can often use higher values.',
      'Use the highest frame rate option your device keeps stable, not just the highest available.',
      'Watch for heat. A hot phone throttles and makes aim feel different mid-match.',
    ],
  },
];

export interface Exercise {
  id: string;
  title: string;
  minutes: number;
  how: string;
}

export const EXERCISES: Exercise[] = [
  {
    id: 'ex-warm',
    title: 'Warm-up drag',
    minutes: 3,
    how: 'In Training Ground, hold fire and drag slowly up and down on a target. Focus on smooth, even movement.',
  },
  {
    id: 'ex-drag',
    title: 'Slow drag headshots',
    minutes: 5,
    how: 'Aim at the chest, hold fire, and drag your thumb straight up to the head. Stop the drag when the crosshair reaches head height.',
  },
  {
    id: 'ex-tap',
    title: 'Tap and adjust',
    minutes: 4,
    how: 'Fire single taps at head height while strafing. After each tap, correct your crosshair before the next one.',
  },
  {
    id: 'ex-scope',
    title: 'Scope switching',
    minutes: 5,
    how: 'Practice the same targets with Red Dot, then 2x. Notice which sensitivity feels too fast or too slow.',
  },
  {
    id: 'ex-recoil',
    title: 'Burst control',
    minutes: 4,
    how: 'Fire short bursts, release, re-center on the head, and fire again. Avoid emptying the magazine in one hold.',
  },
  {
    id: 'ex-review',
    title: 'Cool-down review',
    minutes: 2,
    how: 'Write down one thing that worked and one thing to fix tomorrow. Small notes add up.',
  },
];

export const DRAG_STEPS: string[] = [
  'Open Training Ground and stand 10–20 metres from a bot.',
  'Place your aim at the chest with your crosshair centred on the body.',
  'Hold the fire button with your thumb and start dragging slowly upward.',
  'Stop the drag as soon as the crosshair is at head height. Over-dragging puts shots above the head.',
  'Release, reset your aim on the chest, and repeat. Speed comes after accuracy.',
  'Raise or lower your General and Red Dot values by 3–5 points if you consistently overshoot or undershoot.',
];

export type FingerStyle = '2' | '3' | '4';

export interface HudButton {
  label: string;
  x: number;
  y: number;
  r: number;
  big?: boolean;
}

export const HUD_LAYOUTS: Record<FingerStyle, { title: string; buttons: HudButton[]; notes: string[] }> = {
  '2': {
    title: '2 fingers (both thumbs)',
    buttons: [
      { label: 'Move', x: 70, y: 120, r: 34 },
      { label: 'Fire', x: 335, y: 112, r: 30, big: true },
      { label: 'Jump', x: 372, y: 62, r: 18 },
      { label: 'Crouch', x: 292, y: 150, r: 18 },
      { label: 'Scope', x: 290, y: 78, r: 18 },
    ],
    notes: [
      'Keep Fire large and close to your right thumb so you never lift it to shoot.',
      'Place Jump above Fire so one thumb slide reaches both.',
      'Easiest to learn, but you cannot move and aim at the same time as well as with more fingers.',
    ],
  },
  '3': {
    title: '3 fingers (thumbs + 1 index)',
    buttons: [
      { label: 'Move', x: 70, y: 125, r: 34 },
      { label: 'Fire L', x: 128, y: 62, r: 24, big: true },
      { label: 'Fire R', x: 335, y: 112, r: 28, big: true },
      { label: 'Jump', x: 372, y: 62, r: 18 },
      { label: 'Crouch', x: 292, y: 150, r: 18 },
      { label: 'Scope', x: 290, y: 78, r: 18 },
    ],
    notes: [
      'Put a second Fire button near your left index finger, just above the Move stick.',
      'Your left thumb keeps moving while your index finger shoots.',
      'Keep both Fire buttons the same size so muscle memory stays consistent.',
    ],
  },
  '4': {
    title: '4 fingers (claw)',
    buttons: [
      { label: 'Move', x: 70, y: 128, r: 34 },
      { label: 'Fire L', x: 118, y: 52, r: 22, big: true },
      { label: 'Fire R', x: 305, y: 48, r: 22, big: true },
      { label: 'Aim', x: 335, y: 118, r: 30 },
      { label: 'Jump', x: 372, y: 82, r: 17 },
      { label: 'Crouch', x: 280, y: 152, r: 17 },
      { label: 'Scope', x: 250, y: 100, r: 17 },
    ],
    notes: [
      'Index fingers handle Fire and scope while thumbs handle movement and aim.',
      'Takes the longest to learn. Practise in Training Ground before ranked or squad matches.',
      'Leave a small gap between Fire buttons and the screen edge so your fingers are not cramped.',
    ],
  },
};
