import { createContext, useCallback, useContext, useEffect, useState, ReactNode } from 'react';

export type SensKey = 'general' | 'redDot' | 'scope2x' | 'scope4x' | 'sniper' | 'freeLook';
export type Sens = Record<SensKey, number>;

export const SENS_FIELDS: { key: SensKey; label: string; hint: string }[] = [
  { key: 'general', label: 'General', hint: 'Camera movement without a scope' },
  { key: 'redDot', label: 'Red Dot', hint: 'Close-range scoped aiming' },
  { key: 'scope2x', label: '2x Scope', hint: 'Mid-range control' },
  { key: 'scope4x', label: '4x Scope', hint: 'Long-range, usually lower' },
  { key: 'sniper', label: 'Sniper Scope', hint: 'Slowest, for precise adjustments' },
  { key: 'freeLook', label: 'Free Look', hint: 'Looking around while moving' },
];

export const DEFAULT_SENS: Sens = {
  general: 85,
  redDot: 80,
  scope2x: 75,
  scope4x: 68,
  sniper: 58,
  freeLook: 70,
};

export interface Profile {
  id: string;
  name: string;
  sens: Sens;
}

export interface Prefs {
  glow: boolean;
  reduceMotion: boolean;
}

export interface AppState {
  sens: Sens;
  profiles: Profile[];
  activeProfileId: string | null;
  prefs: Prefs;
  /** date (YYYY-MM-DD) -> completed exercise ids */
  training: Record<string, string[]>;
}

const KEY = 'ffhp:v1';

export const DEFAULT_STATE: AppState = {
  sens: DEFAULT_SENS,
  profiles: [],
  activeProfileId: null,
  prefs: { glow: true, reduceMotion: false },
  training: {},
};

function load(): AppState {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return DEFAULT_STATE;
    const p = JSON.parse(raw) as Partial<AppState>;
    return {
      ...DEFAULT_STATE,
      ...p,
      sens: { ...DEFAULT_SENS, ...(p.sens ?? {}) },
      prefs: { ...DEFAULT_STATE.prefs, ...(p.prefs ?? {}) },
    };
  } catch {
    return DEFAULT_STATE;
  }
}

interface Ctx {
  state: AppState;
  update: (fn: (s: AppState) => AppState) => void;
  resetAll: () => void;
}

const StoreCtx = createContext<Ctx | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AppState>(load);

  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(state));
    } catch {
      /* storage full or blocked: app keeps working in memory */
    }
    const root = document.documentElement;
    root.classList.toggle('noglow', !state.prefs.glow);
    root.classList.toggle('reduce-motion', state.prefs.reduceMotion);
  }, [state]);

  const update = useCallback((fn: (s: AppState) => AppState) => setState(fn), []);
  const resetAll = useCallback(() => {
    try {
      localStorage.removeItem(KEY);
    } catch {
      /* ignore */
    }
    setState(DEFAULT_STATE);
  }, []);

  return <StoreCtx.Provider value={{ state, update, resetAll }}>{children}</StoreCtx.Provider>;
}

export function useStore(): Ctx {
  const c = useContext(StoreCtx);
  if (!c) throw new Error('useStore must be used inside StoreProvider');
  return c;
}

export function todayKey(d = new Date()): string {
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${d.getFullYear()}-${m}-${day}`;
}

export function streak(training: Record<string, string[]>): number {
  let count = 0;
  const d = new Date();
  if (!(training[todayKey(d)]?.length > 0)) d.setDate(d.getDate() - 1);
  while (training[todayKey(d)]?.length > 0) {
    count++;
    d.setDate(d.getDate() - 1);
  }
  return count;
}
