import { useEffect, useState } from 'react';

export const ROUTES = [
  'home', 'sensitivity', 'dpi', 'aim', 'hud', 'training', 'profiles', 'settings',
] as const;
export type Route = (typeof ROUTES)[number];

function read(): Route {
  const h = window.location.hash.replace('#/', '');
  return (ROUTES as readonly string[]).includes(h) ? (h as Route) : 'home';
}

export function useRoute(): [Route, (r: Route) => void] {
  const [route, setRoute] = useState<Route>(read);
  useEffect(() => {
    const onHash = () => {
      setRoute(read());
      window.scrollTo(0, 0);
    };
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);
  return [route, (r) => { window.location.hash = '#/' + r; }];
}
