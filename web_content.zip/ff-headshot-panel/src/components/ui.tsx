import { CSSProperties, ReactNode, useState } from 'react';
import { ChevronDown, ArrowLeft } from 'lucide-react';

export function Logo({ size = 64 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" aria-hidden className="logo-ring animate-pulseRing">
      <g fill="none" stroke="#ff1f3d" strokeWidth="4" strokeLinecap="round">
        <circle cx="32" cy="32" r="16" />
        <path d="M32 6v12M32 46v12M6 32h12M46 32h12" />
      </g>
      <circle cx="32" cy="32" r="4" fill="#ff1f3d" />
    </svg>
  );
}

export function PageHeader({ title, sub, onBack }: { title: string; sub?: string; onBack: () => void }) {
  return (
    <header className="mb-5">
      <button
        onClick={onBack}
        className="mb-3 -ml-1 flex items-center gap-1.5 rounded-lg px-1 py-1 text-sm text-mute active:text-bone"
      >
        <ArrowLeft size={16} /> Home
      </button>
      <h1 className="neon-text text-2xl font-bold leading-tight">{title}</h1>
      {sub && <p className="mt-1.5 max-w-prose text-sm leading-relaxed text-mute">{sub}</p>}
    </header>
  );
}

export function Card({ children, className = '' }: { children: ReactNode; className?: string }) {
  return (
    <section className={`rounded-2xl border border-line bg-panel p-4 ${className}`}>{children}</section>
  );
}

export function Button({
  children, onClick, variant = 'primary', className = '', disabled, type = 'button', ariaLabel,
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'ghost' | 'danger';
  className?: string;
  disabled?: boolean;
  type?: 'button' | 'submit';
  ariaLabel?: string;
}) {
  const styles = {
    primary: 'bg-neon text-white shadow-neon active:brightness-90',
    ghost: 'border border-line bg-panel2 text-bone active:bg-line',
    danger: 'border border-neon/50 bg-transparent text-neon active:bg-neon/10',
  }[variant];
  return (
    <button
      type={type}
      aria-label={ariaLabel}
      onClick={onClick}
      disabled={disabled}
      className={`flex min-h-[48px] items-center justify-center gap-2 rounded-xl px-4 text-sm font-bold transition disabled:opacity-40 ${styles} ${className}`}
    >
      {children}
    </button>
  );
}

export function Slider({
  label, hint, value, onChange,
}: { label: string; hint?: string; value: number; onChange: (v: number) => void }) {
  const id = `s-${label.replace(/\s+/g, '-')}`;
  return (
    <div className="py-3">
      <div className="mb-2.5 flex items-baseline justify-between gap-3">
        <label htmlFor={id} className="font-semibold">{label}</label>
        <span className="min-w-[2.5ch] text-right text-lg font-bold tabular-nums text-neon">{value}</span>
      </div>
      <input
        id={id}
        type="range"
        min={0}
        max={100}
        step={1}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="ff"
        style={{ '--p': `${value}%` } as CSSProperties}
      />
      {hint && <p className="mt-2 text-xs text-mute">{hint}</p>}
    </div>
  );
}

export function Toggle({
  label, desc, checked, onChange,
}: { label: string; desc?: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className="flex w-full items-center justify-between gap-4 py-3 text-left"
    >
      <span>
        <span className="block font-semibold">{label}</span>
        {desc && <span className="mt-0.5 block text-xs text-mute">{desc}</span>}
      </span>
      <span
        className={`relative h-7 w-12 shrink-0 rounded-full border transition ${
          checked ? 'border-neon bg-neon/30' : 'border-line bg-panel2'
        }`}
      >
        <span
          className={`absolute top-0.5 h-5 w-5 rounded-full transition-all ${
            checked ? 'left-6 bg-neon' : 'left-0.5 bg-mute'
          }`}
        />
      </span>
    </button>
  );
}

export function Accordion({
  title, children, defaultOpen = false,
}: { title: string; children: ReactNode; defaultOpen?: boolean }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="overflow-hidden rounded-2xl border border-line bg-panel">
      <button
        onClick={() => setOpen(!open)}
        aria-expanded={open}
        className="flex min-h-[52px] w-full items-center justify-between gap-3 px-4 py-3 text-left font-semibold"
      >
        {title}
        <ChevronDown size={18} className={`shrink-0 text-neon transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>
      {open && (
        <div className="animate-rise space-y-2 border-t border-line px-4 py-3 text-sm leading-relaxed text-bone/90">
          {children}
        </div>
      )}
    </div>
  );
}

export function Bullets({ items }: { items: string[] }) {
  return (
    <ul className="space-y-2">
      {items.map((t) => (
        <li key={t} className="flex gap-2.5">
          <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-neon" />
          <span>{t}</span>
        </li>
      ))}
    </ul>
  );
}

export function Notice({ children }: { children: ReactNode }) {
  return (
    <p className="rounded-xl border border-blood bg-blood/25 px-3.5 py-3 text-xs leading-relaxed text-bone/90">
      {children}
    </p>
  );
}
