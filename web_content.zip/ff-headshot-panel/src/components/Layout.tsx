import { ReactNode } from 'react';
import { Home, Crosshair, Dumbbell, Smartphone, Settings } from 'lucide-react';
import type { Route } from '../router';

const NAV: { route: Route; label: string; Icon: typeof Home }[] = [
  { route: 'home', label: 'Home', Icon: Home },
  { route: 'sensitivity', label: 'Sensitivity', Icon: Crosshair },
  { route: 'training', label: 'Training', Icon: Dumbbell },
  { route: 'profiles', label: 'Profiles', Icon: Smartphone },
  { route: 'settings', label: 'Settings', Icon: Settings },
];

export function Layout({
  route, go, children,
}: { route: Route; go: (r: Route) => void; children: ReactNode }) {
  return (
    <div className="mx-auto min-h-screen max-w-md font-game">
      <main className="safe-top px-4 pb-28">{children}</main>
      <nav
        aria-label="Main"
        className="safe-bottom fixed inset-x-0 bottom-0 z-40 border-t border-line bg-ink/95 backdrop-blur"
      >
        <ul className="mx-auto flex max-w-md">
          {NAV.map(({ route: r, label, Icon }) => {
            const active = route === r;
            return (
              <li key={r} className="flex-1">
                <button
                  onClick={() => go(r)}
                  aria-current={active ? 'page' : undefined}
                  className={`flex w-full flex-col items-center gap-1 py-2.5 text-[11px] font-semibold ${
                    active ? 'text-neon' : 'text-mute'
                  }`}
                >
                  <Icon size={21} strokeWidth={active ? 2.5 : 2} />
                  {label}
                </button>
              </li>
            );
          })}
        </ul>
      </nav>
    </div>
  );
}
