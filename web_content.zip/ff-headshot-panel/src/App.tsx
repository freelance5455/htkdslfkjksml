import { Layout } from './components/Layout';
import { ToastProvider } from './toast';
import { useRoute } from './router';
import Home from './pages/Home';
import Sensitivity from './pages/Sensitivity';
import DpiGuide from './pages/DpiGuide';
import AimPrecision from './pages/AimPrecision';
import CustomHud from './pages/CustomHud';
import Training from './pages/Training';
import Profiles from './pages/Profiles';
import SettingsPage from './pages/SettingsPage';

export default function App() {
  const [route, go] = useRoute();
  return (
    <ToastProvider>
      <Layout route={route} go={go}>
        {route === 'home' && <Home go={go} />}
        {route === 'sensitivity' && <Sensitivity go={go} />}
        {route === 'dpi' && <DpiGuide go={go} />}
        {route === 'aim' && <AimPrecision go={go} />}
        {route === 'hud' && <CustomHud go={go} />}
        {route === 'training' && <Training go={go} />}
        {route === 'profiles' && <Profiles go={go} />}
        {route === 'settings' && <SettingsPage go={go} />}
      </Layout>
    </ToastProvider>
  );
}
