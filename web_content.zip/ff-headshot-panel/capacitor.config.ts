import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.ffheadshotpanel.app',
  appName: 'FF HEADSHOT PANEL',
  webDir: 'dist',
  backgroundColor: '#080406',
  android: {
    allowMixedContent: false,
  },
};

export default config;
