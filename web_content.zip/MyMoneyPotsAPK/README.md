# My Money Pots v5 — Android APK build project

This is an Android Studio project containing the v5 app and a native Android WebView wrapper.

## Important fixes in this build
- Native Android WebView file chooser is implemented (`onShowFileChooser`) so the **Choose JSON backup file** control can open Android's file picker.
- JSON restore validates the backup structure and restores categories, budgets and transactions.
- A second restore route is included: paste the contents of the JSON backup into the text area. This is a fallback if a particular WebView/file provider blocks file selection.
- Existing local data uses the same localStorage key (`my-money-pots-v1`) as v5. Installing an update over the same package should preserve app data; uninstalling first can erase it.

## Build APK
1. Install Android Studio on a computer and open this `MyMoneyPotsAPK` folder.
2. Allow Gradle sync and install any requested Android SDK components (compile SDK 35).
3. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. Android Studio creates the debug APK under `app/build/outputs/apk/debug/`.
5. For a release APK, use **Build → Generate Signed Bundle / APK** and keep the signing key safe for future updates.

## Test restore
- In the app: Settings → Data backup → Choose JSON backup file → select the exported `money-pots-backup.json` → Restore selected backup.
- If the file chooser does not appear, open the JSON backup in a text editor, copy all its contents, paste into the alternative text area, and select **Restore pasted JSON**.

## Data safety
Back up your data before installing. Update the existing app without uninstalling it. Android may retain app data for an in-place update when the application ID and signing certificate match. A newly signed APK with a different key cannot update an existing installation; it may require uninstalling, which can erase local app data. Keep the JSON backup safe.
