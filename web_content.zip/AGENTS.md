# AgentBase workspace export — notes for AI coding tools

This folder is an exported AgentBase workspace. Each app is a static web page
that runs inside a sandboxed iframe and gets data from its host page.

## Layout

- `apps/<app_id>/src/` — **the app source. Edit here.** `app.json` has the
  app's name, scope, bound table and `entry_file`.
- `apps/<app_id>/queries.json` — the app's named queries. **Edit here** to read
  or write new data.
- `schema.sql` (Postgres DDL), `schema.json`, `sample-data.json` (if present),
  `layout.json` — the workspace's tables and sidebar. Read-only reference.
- `runtime/` and `dev/` — **platform-owned. Do not edit.** They are replaced by
  the platform's current versions on upload, so changes there are lost.
- `manifest.json` — package metadata. Do not edit.

## Data access

Apps get data **only** through the Bridge SDK, which the platform injects:

```js
const res = await window.agentdb.executeQuery('load_tasks', { status: 'active' });
// res.rows is an array of objects keyed by column name
```

To read or write something new, add a named query to `queries.json`:

```json
"load_open_by_owner": {
  "name": "load_open_by_owner",
  "sql": "SELECT id, title FROM tasks WHERE status = $1 AND owner = $2",
  "params": [{"name": "status", "type": "text", "nullable": false},
             {"name": "owner", "type": "text", "nullable": false}],
  "description": "Open tasks for one owner",
  "is_mutation": false
}
```

- Placeholders are `$1..$n`, bound in `params` order. Param types: `text`,
  `integer`, `float`, `boolean`, `timestamp`, `uuid`.
- Set `is_mutation: true` for INSERT / UPDATE / DELETE.
- SQL is PostgreSQL. Tables are referenced unqualified.
- Never use raw SQL (`agentdb.query(sql)` is disabled) and never `fetch` an API.

## Sandbox limits (same as production)

- **No localStorage / sessionStorage.** The bridge shims them in memory; do not
  rely on client-side storage.
- **No ES modules / `import`.** Use classic `<script>` tags (CDN or files in
  `src/`) and globals. List section scripts before `main.js`.
- **No same-origin access to the parent**, and `fetch()` of the app's own files
  fails. Do not add a `<script>` tag for the Bridge SDK — it is injected.
- All bridge methods return Promises: `await` them, show a loading state, and
  catch errors. Never wrap `executeQuery` in your own timeout or retry loop.

## Styling

Dashboards that declare `<html data-palette="…">` get the B-Suite design system
injected: tokens, palettes, component CSS and `window.gsDash` (the API, with
comments, is in `runtime/kit.src.js`; `runtime/kit.js` is the minified copy the
page loads). Use its components and CSS custom properties
(`--ink-*`, `--brand-500`, `--viz-1..6`, `--s-*`, …). **Do not hard-code colors**
or the theme — the palette is applied by the platform, and the page follows the
OS light/dark setting.

## Run locally

```bash
npx serve .
```

Then open `http://localhost:3000/dev/host.html` and pick an app. Queries run
unchanged against an in-browser Postgres (PGlite) loaded with `schema.sql` and
`sample-data.json` (the newest rows, up to 200 per table).
