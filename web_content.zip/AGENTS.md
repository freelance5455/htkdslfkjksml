# Crossword Stage Design Rules

## 1. Answer Formatting (Strict - No Prefixes)
- Answers **MUST NOT** include categorizing or descriptive prefixes such as:
  - NO "سورة" (e.g., use "الدخان", NEVER "سورة الدخان")
  - NO "غزوة" (e.g., use "خيبر", NEVER "غزوة خيبر")
  - NO "نهر" (e.g., use "التيمز", NEVER "نهر التيمز")
  - NO "شجرة" (e.g., use "السدر", NEVER "شجرة السدر")
  - NO "جبال" (e.g., use "الأطلس", NEVER "جبال الأطلس")
  - NO "مدينة" (e.g., use "قسنطينة", NEVER "مدينة قسنطينة")
  - NO "طائر" (e.g., use "اللقلق", NEVER "طائر اللقلق")
  - NO "أسلوب" (e.g., use "الاستثناء", NEVER "أسلوب الاستثناء")
  - NO "كوكب", "نادي", "علم", etc. when the core subject is sufficient (e.g., "المنطق" not "علم المنطق").

## 2. No Duplicate Answers
- Every answer in the entire database (Stages 1 through 50) must be 100% unique.
- Always check the database before introducing or suggesting any answer.

## 3. Clue Quality & Sensitivity
- Avoid mentioning the answer or obvious parts of it in the clue text.
- Do not mention aircraft models or numbers in clues if asked to describe the manufacturer.
- Respect user choices for difficulty (avoid overly obscure answers unless requested).

## 4. Grid Specifications
- 25 questions per stage.
- 25x25 grid, fully connected, no unintended words, valid golden layout.
