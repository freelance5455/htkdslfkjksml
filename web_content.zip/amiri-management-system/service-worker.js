const C='amiri-v1',F=['./','index.html','manifest.json','css/style.css','css/responsive.css','js/db.js','js/auth.js','js/modules.js','js/app.js','assets/logo/logo.svg','assets/icons/icon.svg'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(C).then(c=>c.addAll(F)));self.skipWaiting()});
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!=C).map(x=>caches.delete(x))))));
self.addEventListener('fetch',e=>e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request))));
