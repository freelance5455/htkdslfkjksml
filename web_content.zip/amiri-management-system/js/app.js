const NAV=[['dashboard','📊 داشبورد'],['sales','🛒 فروش'],['purchases','📥 خرید'],['products','📦 محصولات'],['categories','🏷 دسته‌بندی‌ها'],['inventory','🏬 انبار'],['expenses','💸 مصارف'],['customers','👥 مشتریان'],['suppliers','🚚 تأمین‌کنندگان'],['debts','📒 بدهی و طلب'],['reports','📈 گزارش‌ها'],['users','🔐 کاربران','a'],['backup','💾 پشتیبان','a'],['settings','⚙ تنظیمات','a']];
let cur='dashboard';
async function route(n){if(n)cur=n;if(NAV.find(x=>x[0]==cur)[2]&&me.role!='admin')cur='dashboard';view().onclick=null;document.querySelectorAll('#nav a').forEach(a=>a.classList.toggle('on',a.dataset.r==cur));$('#side').classList.remove('open');try{await R[cur]()}catch(e){console.error(e);toast(e.message,1)}}
function showApp(){$('#login').hidden=true;$('#app').hidden=false;$('#who').textContent=me.username+(me.role=='admin'?' (مدیر)':' (کارمند)');
$('#nav').innerHTML=NAV.filter(x=>!x[2]||me.role=='admin').map(x=>`<a data-r=${x[0]}>${x[1]}</a>`).join('');$('#nav').onclick=e=>e.target.dataset.r&&route(e.target.dataset.r);route('dashboard')}
(async()=>{await DB.open();const first=await seedAdmin();Object.assign(CFG,await DB.get('settings',1)||{});
document.documentElement.dataset.theme=localStorage.getItem('th')||'light';
$('#th').onclick=()=>{const t=document.documentElement.dataset.theme=='dark'?'light':'dark';document.documentElement.dataset.theme=t;localStorage.setItem('th',t)};
$('#lo').onclick=logout;$('#mt').onclick=()=>$('#side').classList.toggle('open');
$('#lf').onsubmit=async e=>{e.preventDefault();try{await login($('#lu').value,$('#lp').value);showApp()}catch(x){toast(x.message,1)}};
const s=sessionStorage.getItem('me');if(s){me=JSON.parse(s);showApp()}else{$('#login').hidden=false;if(first)$('#lh').textContent='ورود اولیه: admin / admin123 (بعد از ورود تغییر دهید)'}
if('serviceWorker'in navigator)navigator.serviceWorker.register('service-worker.js').catch(()=>{})})();
