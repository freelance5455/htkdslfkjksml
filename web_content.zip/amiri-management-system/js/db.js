const STORES=['users','settings','categories','products','customers','suppliers','sales','purchases','expenses','payments','logs'];
const DB={db:null,
open(){return new Promise((ok,no)=>{const r=indexedDB.open('amiri',1);r.onupgradeneeded=()=>STORES.forEach(s=>r.result.createObjectStore(s,{keyPath:'id',autoIncrement:true}));r.onsuccess=()=>{DB.db=r.result;ok()};r.onerror=()=>no(r.error)})},
tx:(s,m='readonly')=>DB.db.transaction(s,m),
req:r=>new Promise((ok,no)=>{r.onsuccess=()=>ok(r.result);r.onerror=()=>no(r.error)}),
all:s=>DB.req(DB.tx(s).objectStore(s).getAll()),
get:(s,id)=>DB.req(DB.tx(s).objectStore(s).get(id)),
put:(s,o)=>DB.req(DB.tx(s,'readwrite').objectStore(s).put(o)),
del:(s,id)=>DB.req(DB.tx(s,'readwrite').objectStore(s).delete(id)),
async dump(){const o={app:'AMIRI',date:new Date().toISOString()};for(const s of STORES)o[s]=await DB.all(s);return o},
async restore(o){if(o.app!='AMIRI')throw Error('فایل پشتیبان معتبر نیست');const t=DB.tx(STORES,'readwrite');for(const s of STORES){const st=t.objectStore(s);st.clear();(o[s]||[]).forEach(x=>st.put(x))}return new Promise((a,b)=>{t.oncomplete=a;t.onerror=()=>b(t.error)})}};
