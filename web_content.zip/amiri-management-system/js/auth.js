let me=null;
const hash=async s=>{s='amiri'+s;if(window.crypto&&crypto.subtle){const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s));return[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('')}let h=0;for(const c of s)h=Math.imul(31,h)+c.charCodeAt(0)|0;return'x'+h};
async function seedAdmin(){if(!(await DB.all('users')).length){await DB.put('users',{username:'admin',role:'admin',hash:await hash('admin123')});await DB.put('settings',{id:1,name:'دکان امیری',owner:'',phone:'',address:'',cur:'افغانی',foot:'از خرید شما سپاسگزاریم'});return true}}
async function login(u,p){const h=await hash(p),x=(await DB.all('users')).find(v=>v.username==u.trim()&&v.hash==h);if(!x)throw Error('نام کاربری یا رمز عبور اشتباه است');me={id:x.id,username:x.username,role:x.role};sessionStorage.setItem('me',JSON.stringify(me))}
function logout(){sessionStorage.removeItem('me');location.reload()}
