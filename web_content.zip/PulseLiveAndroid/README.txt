Pulse Live Android project

Photo chooser fix (v1.4):
- Candidate photo picker callback now returns a cancellation result safely and handles chooser launch failures.
- Selected images are converted to compressed JPEG data URLs instead of temporary object URLs.
- Candidate photos and poll state are saved in WebView local storage, so photos remain after closing/reopening the app.
- Large photos are resized to a maximum 900px edge to reduce local storage usage.

Open this folder in Android Studio and run the app. In Settings, use the Choose Photo control beside a candidate, select an image, then tap Apply Changes if you also edited other settings.
Note: local browser storage has finite capacity; use smaller images if storage fills.

Version 1.5 photo picker repair: the Choose Photo button now calls a native Android JavaScript bridge and opens the system image picker directly, bypassing WebView file-input handling. The selected image is downsampled/compressed and returned to the page for preview and local persistence.
