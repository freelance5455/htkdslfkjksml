PULSE LIVE POLL - ANDROID APP PROJECT

This is an Android Studio project wrapper for the Pulse Live TV polling web app.

BUILD AN APK
1. Download and extract Pulse_Live_Android_Project.zip on a computer.
2. Install Android Studio (https://developer.android.com/studio).
3. Open the extracted PulseLiveAndroid folder in Android Studio.
4. Allow Gradle sync and install the Android SDK platform requested if prompted.
5. Use Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When the build completes, click Locate. The debug APK is usually at:
   app/build/outputs/apk/debug/app-debug.apk
7. Transfer that APK to your Android phone and install it. You may need to allow installing apps from that file manager.

FEATURES
- Native Android wrapper with app launcher entry.
- Bundled offline HTML interface.
- Candidate photos and poll thumbnail can be selected from device gallery/file picker.
- TV-style shine effects, editable title, candidate count and voting UI.

LIMITATIONS
- This package is the Android Studio source project, not a compiled APK. An Android SDK/Gradle build environment is required to compile it.
- Votes are local to the app session and are not synchronized across viewers/devices.
