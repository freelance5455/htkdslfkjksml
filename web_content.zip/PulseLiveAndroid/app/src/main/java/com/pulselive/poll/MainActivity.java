package com.pulselive.poll;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import android.util.Base64;
import android.widget.Toast;
import android.content.ClipData;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_PICKER_REQUEST = 7421;
    private int pendingPhotoIndex = -1;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xff070b18);
        getWindow().setNavigationBarColor(0xff030611);
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new PhotoBridge(), "AndroidPhotoPicker");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    // ACTION_OPEN_DOCUMENT works with Android's system photo picker and document providers.
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("image/*");
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    intent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    startActivityForResult(intent, FILE_PICKER_REQUEST);
                    return true;
                } catch (Exception firstError) {
                    try {
                        Intent fallback = new Intent(Intent.ACTION_GET_CONTENT);
                        fallback.addCategory(Intent.CATEGORY_OPENABLE);
                        fallback.setType("image/*");
                        startActivityForResult(Intent.createChooser(fallback, "Choose candidate photo"), FILE_PICKER_REQUEST);
                        return true;
                    } catch (Exception secondError) {
                        if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                        filePathCallback = null;
                        Toast.makeText(MainActivity.this, "Unable to open gallery. Please try Files or Photos.", Toast.LENGTH_LONG).show();
                        return false;
                    }
                }
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void launchNativePhotoPicker(int index) {
        pendingPhotoIndex = index;
        try {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("image/*");
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(Intent.createChooser(intent, "Choose candidate photo"), FILE_PICKER_REQUEST);
        } catch (Exception e) {
            pendingPhotoIndex = -1;
            Toast.makeText(this, "No gallery or file picker app found", Toast.LENGTH_LONG).show();
        }
    }

    private class PhotoBridge {
        @JavascriptInterface public void choosePhoto(int candidateIndex) {
            runOnUiThread(() -> launchNativePhotoPicker(candidateIndex));
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_PICKER_REQUEST) return;
        // Clear any WebView HTML file chooser callback too, if it was used.
        if (filePathCallback != null) {
            Uri[] uris = (resultCode == Activity.RESULT_OK && data != null && data.getData() != null)
                    ? new Uri[]{data.getData()} : null;
            filePathCallback.onReceiveValue(uris);
            filePathCallback = null;
        }
        if (pendingPhotoIndex < 0) return;
        int index = pendingPhotoIndex;
        pendingPhotoIndex = -1;
        if (resultCode != Activity.RESULT_OK || data == null || data.getData() == null) {
            Toast.makeText(this, "Photo selection cancelled", Toast.LENGTH_SHORT).show();
            return;
        }
        Uri uri = data.getData();
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            InputStream first = getContentResolver().openInputStream(uri);
            BitmapFactory.decodeStream(first, null, bounds);
            if (first != null) first.close();
            int sample = 1;
            while (bounds.outWidth / sample > 900 || bounds.outHeight / sample > 900) sample *= 2;
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = sample;
            InputStream second = getContentResolver().openInputStream(uri);
            Bitmap bitmap = BitmapFactory.decodeStream(second, null, opts);
            if (second != null) second.close();
            if (bitmap == null) throw new IllegalStateException("Unsupported image");
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 78, bytes);
            bitmap.recycle();
            String base64 = Base64.encodeToString(bytes.toByteArray(), Base64.NO_WRAP);
            final String js = "window.onNativePhotoPicked && window.onNativePhotoPicked(" + index + ", 'data:image/jpeg;base64," + base64 + "')";
            runOnUiThread(() -> webView.evaluateJavascript(js, value -> {}));
            Toast.makeText(this, "Candidate photo selected", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Could not read that photo. Try another image.", Toast.LENGTH_LONG).show();
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
