المزايدة السرية - مشروع Android

هذا مشروع Android Studio يحوّل لعبة HTML إلى تطبيق APK يعمل أوفلاين.

طريقة الاستخدام:
1) افتح مجلد SecretAuction في Android Studio أو AndroidIDE.
2) انتظر Gradle Sync.
3) اختر Build > Build APK(s).
4) ستجد APK في app/build/outputs/apk/debug/app-debug.apk

ملفات اللعبة موجودة هنا:
app/src/main/assets/index.html

لا يحتاج التطبيق إلى إنترنت ولا توجد صلاحية Internet في المشروع.
