# CodeGot v77 — Free con piso de 10 s en TODOS los caminos (sobre v76)

## Causa del error
- El piso de 10 s de v76 solo estaba en la rama «Free con texto normal». Si la pregunta activaba búsqueda web o el simulador de negocio, Free se saltaba esa rama y respondía a la velocidad normal del modelo (parecida a Flash).

## Corrección
- Code Free: el texto no aparece antes de 10 s desde el envío, sea texto, búsqueda web o simulador. Si el modelo tarda más de 10 s, sale cuando termine.
- Code súper Flash: sin cambios (atajos locales, caché 24 h, predicción mientras se escribe, dos modelos a la vez, 300 tokens).
## Revertir: zip v76.
