# CodeGot v34 — cambios

## Barra lateral de chats · negro Obsidiana
- Fondo obsidiana cálido (degradado #151517 → #0a0a0b con un velo cálido arriba) que combina con el papel vainilla del chat; borde y sombra suaves.
- Textos en blanco hueso (#efece3), secundarios #b9b5a8, etiquetas #85827a.
- Botones (Nuevo chat, Navegador privado, Agent), buscador, selector de proyecto, chats recientes, pie, avatar y botones Actualizar/Cuenta adaptados. Foco en dorado tenue (mismo acento cálido del chat).
- Solo color: no cambia estructura, IDs ni lógica. Estilos en `<style id="nexus-obsidian-sidebar">` (al final del HTML); variables `--obs-*` para retocar tonos.
- Archivos: `original.html` y `rebuild_nexus/zoe-nova-ia.html` (idénticos).

## v34b — ajustes para no dañar el diseño
- Íconos de "Navegador privado" y "CodeGot Agent": se mantiene el cuadro redondeado original, ahora en cristal oscuro con el ícono claro (antes quedaban claro sobre crema = invisibles).
- Buscador: input plano (sin borde/sombra nativa) → desaparece el contorno interno.
- Selector de proyecto: sin sombra/borde nativo, con flecha propia.
