# CodeGot v33 — cambios

## Chat · fluidez "agua 100 % + pizca de rapidez"
- **Texto de la IA**: ahora sale con un caudal suavizado (filtro de velocidad + acumulador fraccional), sin saltos de palabra ni acelerones. Ritmo base un poco más alto y el atraso se recupera más rápido; al terminar la respuesta se vacía el resto con más ganas, sin corte brusco.
- **Scroll automático**: resorte más ágil (`NX_GLIDE_TAU` 0.44→0.34) y tope de velocidad mayor (`NX_GLIDE_MAXV` 680→900), siempre sin rebote.
- **Párrafos nuevos**: aparecen con fundido + subida de 7 px (curva larga y suave, .46 s). Mensajes: .3 s.
- Respeta "reducir movimiento".
- Compose: `collectBatched` a 16 ms (60 Hz), resortes de lista y fundido ajustados.
- Archivos: `original.html` y `rebuild_nexus/zoe-nova-ia.html` (idénticos), `compose/ChatStreaming.kt`, `compose/NexusMotion.kt`.
- Ajustes rápidos: velocidad base = `0.062` (car/ms) y `tau` (340/170) en `nxPaceTick`.

## v33b — 0 lag
- Ritmo del texto sin rampa de arranque (el primer cuadro ya sale a velocidad), base 0.078 car/ms, recuperación de atraso `tau` 240/110 ms.
- El scroll automático ahora se mueve en el **mismo cuadro** que el texto (antes iba 1 cuadro tarde). Resorte `NX_GLIDE_TAU` 0.26, `NX_GLIDE_MAXV` 1100.
- La cola del streaming actualiza un único nodo de texto (`.data`) en vez de recrear contenido.
- La burbuja que escribe ya no es capa GPU (`will-change`/`backface-visibility` fuera) → no se re-pinta completa por cuadro.
