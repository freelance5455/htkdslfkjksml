# CodeGot v73 — Flash instantáneo, Cerebrot cercano y mensajes siempre visibles (sobre v72)

## Code súper Flash (y Free) — respuestas locales instantáneas
- Saludos, «cómo estás», gracias, despedidas y «quién eres» se responden en el dispositivo, sin llamar al modelo: ~10–35 ms (medido). Usan el nombre del usuario.
- Para el resto: el refuerzo con el segundo modelo arranca a los 250 ms (antes 350) y el tope de salida baja a 500 tokens. El tiempo de la IA remota depende de la red y no se puede garantizar por debajo de medio segundo.
## Code Free: se mantiene el tope duro de 8 s (v72).
## Code Cerebrot
- Más cercano: llama al usuario por su nombre mucho, pregunta por él/ella (cómo está, qué estudia, para cuándo es la prueba, qué le cuesta) y SIEMPRE cierra preguntando qué quiere estudiar ahora.
## Mensajes que se veían vacíos / desaparecían
- Se quitaron content-visibility y las capas GPU de la última burbuja (fallan en algunos WebView) y se añadió auto-reparación: si una animación de entrada queda a medias, se termina; también al volver a la app, rotar o hacer scroll.
- Si el texto final quedara vacío en pantalla, se vuelve a escribir.
## Revertir: zip v72.
