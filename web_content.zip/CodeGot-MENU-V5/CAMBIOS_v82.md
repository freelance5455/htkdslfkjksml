# CodeGot v82 — Límite global de 1,000 mensajes, bug del chat del editor e icono nuevo (sobre v81)

## Límite diario global
- Cada usuario tiene 1,000 mensajes al día sumando los 3 motores (Free, Flash y Cerebrot). Da igual si los reparte o los gasta todos en un solo motor.
- Al llegar a 1,000, TODOS los motores se bloquean y aparece la pantalla «IA recargándose» (porcentaje, hora de regreso y tiempo restante).
- Al terminar la recarga (2 horas) los contadores vuelven a 0. Los contadores también se reinician a medianoche.
- El menú de motores muestra «Te quedan N de 1000 hoy» (el mismo total para los tres).
- Consola: cgResetLimits() reinicia contadores y recarga manualmente.

## Bug del chat del editor de app
- Los mensajes de la IA se encogían (min-height permitía flex-shrink) y su texto se montaba debajo del mensaje del usuario. Ahora cada mensaje conserva su altura real y la lista hace scroll.

## Icono nuevo
- Se reemplazó el icono anterior por la «C» negra nueva: favicon, apple-touch-icon, manifest/PWA y todos los avatares/logos de la app (--cg-logo en fondo blanco redondeado; --cg-logo-mask transparente para las máscaras).

## Revertir: zip v81.
