# CodeGot v78 — Tope de 10 s de Free en la capa de pantalla (sobre v77)

- El piso de 10 s de Code Free ahora se aplica donde se dibuja la respuesta (handleSend), no solo dentro de la función de IA. Contado desde el instante en que se toca enviar: nada de texto se muestra antes de 10 s, sea cual sea el camino (saludo, texto, búsqueda web, simulador).
- Si el usuario detiene la respuesta, no se muestra nada retenido. Si hay error, se descarta lo retenido.
- Code súper Flash: sin cambios.
## Revertir: zip v77.
