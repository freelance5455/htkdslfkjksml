# CodeGot v38 — barra lateral sin lag

Reemplaza el bloque `nexus-v37-sidebar-flow` por `nexus-v38-sidebar-smooth` (al final del HTML).

Causas del lag (por revisión del código; no medido en dispositivo):
- **Desenfoque a pantalla completa** (`backdrop-filter: blur(10px)` en `#scrim`, bloque `nexus-sidebar-blur`): re-desenfocaba todo el chat en cada cuadro al abrir y al arrastrar. Ahora el fondo oscuro es un simple fundido (solo opacity).
- **Transición de `box-shadow`** de la v37: repintaba en cada cuadro. Quitada; el panel solo anima `transform`.
- **Cascada de chats** de `waterFlowStyle` (600 ms con retrasos de hasta 405 ms): quitada.

Se mantiene: curva `cubic-bezier(.22,1,.36,1)` a 300 ms (la misma de los mensajes), soltado del arrastre 220–320 ms, y `nx-ultrafast` excluyendo `#sidebar`/`#scrim`.
Si se quiere el desenfoque de vuelta, hay que aplicarlo solo cuando el panel termina de abrirse (nunca durante el movimiento).
