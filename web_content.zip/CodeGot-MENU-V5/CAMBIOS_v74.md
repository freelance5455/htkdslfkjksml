# CodeGot v74 — Flash al máximo, Free pausado y diseño profesional (sobre v73)

## Code súper Flash (objetivo ≈ 1 s)
- Respuestas locales instantáneas ampliadas (saludos, gracias, ok, qué puedes hacer, moneda, dado, número al azar, chiste, quién eres, hora, fecha y cálculos).
- Caché: la misma pregunta como primer mensaje de un chat se responde al instante (6 h, sin preguntas sensibles al tiempo).
- Conexión caliente permanente (se renueva cada ~19 s), refuerzo con el 2.º modelo a los 120 ms, salida máx. 350 tokens, historial de 6 mensajes, respuestas de ≤30 palabras.
## Code Free (más pausado, sin optimizaciones)
- Sin atajos locales, sin carrera de modelos, sin tope de 8 s: razona con nivel medio y responde completo. (El tope de 8 s de v70–v72 se retiró por pedido.)
## Diseño
- Icono nuevo: tile oscuro con anillo degradado (azul→violeta→naranja, igual que el botón Agent) y gesto en menta; reemplaza el cuadro blanco. Aplica en bienvenida, barra superior, junto a cada respuesta y barra lateral.
- Sistema visual: tipografía y espaciado afinados, tarjetas con borde fino y relieve, burbujas con degradado sutil, numeración con acento, barra de escribir de cristal con aro del color del motor al enfocar, botones de acción más cómodos. Funciona en tema oscuro y claro.
- Corregido un error latente (purgeGuestPersistence no definida).
## Revertir: zip v73.
