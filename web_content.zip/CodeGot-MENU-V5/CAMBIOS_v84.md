# CodeGot v84 — Flash más rápido, «Pensando» nuevo y diseño del chat (sobre v83)

## Code súper Flash
- Respuestas locales (0 ms, sin internet): raíz cuadrada y cúbica de CUALQUIER número (antes solo las exactas), «raíz cuadrada» sin número (pregunta de qué número), cuadrado, cubo, mitad, doble, triple, factorial y «X elevado a Y».
- Carrera de modelos con relevos: 2 modelos salen a la vez; a 0,6 s sale un 3.º; después se relanzan con conexiones nuevas (1,3 s · 2,1 s · 3,0 s). Si una petición falla, la siguiente sale al instante. Con mala red ya no se queda 45–60 s en «Pensando»: a los 25 s sin texto muestra un error claro.
- Predicción al escribir: ahora empieza a los 0,35 s de pausa (antes 0,6 s).
- Nota honesta: una respuesta del modelo en 0,5 s depende de la red y no se puede garantizar al 100 %; lo local, la caché y la predicción sí son instantáneos.

## Animación «Pensando» (nueva)
- Orbe con logo y 3 anillos, borde de luz giratorio, líneas que se «escriben», barra de progreso, pasos y cronómetro.
- Color y velocidad por motor (Free violeta · Flash ámbar y más rápida · Cerebrot violeta intenso). Frases propias por motor. Tema claro y oscuro. Respeta «reducir movimiento».

## Diseño del chat
- Solo estilos: no se quitó ni movió ningún botón (cámara, adjuntos, Agent, motores, Detener…).
- Burbujas, lectura de respuestas, citas, código, tablas, acciones de mensaje y entrada suave de mensajes.

## Versión visible: v84. Revertir: zip v83.
