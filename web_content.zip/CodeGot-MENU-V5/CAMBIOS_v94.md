# CodeGot v94 — Diseño vainilla profesional, sin brillos (sobre v93)

## Tema claro
- Fondo blanco pastel vainilla (#FBF8F1), tarjetas en vainilla más oscuro, texto casi negro.
- Todos los botones principales en negro con texto vainilla (enviar, Agent, motor «Flash», Crear cuenta, Iniciar sesión, Actualizar, ajustes…). Los secundarios (Cancelar, Cerrar) llevan borde negro y fondo transparente.

## Tema oscuro (Ajustes → Apariencia → Oscuro)
- Fondo negro puro. Los botones pasan a blanco con texto negro. Avatar y logo de portada en blanco.

## Sin brillos (0 LED)
- Quitados: fondo difuminado de colores (aurora) de la portada, halos del logo, título con degradado azul-morado-naranja, borde degradado del botón Agent y del avatar, degradado del botón enviar, resplandor al escribir, colores naranja/morado de los motores, círculos azules de las tarjetas y degradado del «Pensando».
- Se mantienen en rojo solo las acciones destructivas (Eliminar cuenta, Borrar datos) y los avisos de error.

## Nota técnico
- Todo es un único bloque CSS al final (`codegot-v94-vanilla-pro`); no se tocó la lógica. Revertir: borrar ese bloque.
- La barra de estado del teléfono también cambia (vainilla en claro, negro en oscuro).

## Versión visible: v94. Revertir: zip v93.
