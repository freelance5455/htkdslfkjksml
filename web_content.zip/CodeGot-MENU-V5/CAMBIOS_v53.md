# CodeGot v53 — Cambio de tema instantáneo (sobre v52)

**Problema medido:** al cambiar el tema en Ajustes se disparaban ~400 transiciones CSS de las capas antiguas a la vez; la pantalla tardaba 600–880 ms en asentarse y se veían colores mezclados a mitad de camino (sensación de lag/bug).

**Solución:**
- Mientras se re-pinta, las transiciones se congelan (clase temporal `g51-switching` con especificidad blindada) y se reactivan 2 cuadros después. Los colores nuevos se aplican en el mismo instante.
- Si el tema resuelto ya es el actual (p. ej. Automático → Claro con el teléfono en claro) no se re-pinta nada.
- Respaldo por tiempo si la pestaña está en segundo plano; la clase nunca se queda pegada.
- Barras de desplazamiento ahora siguen el color del tema.

**Resultado (headless, 390×844):** 620–880 ms → ~30 ms; 0 animaciones visibles; 30 cambios seguidos sin errores ni estado inconsistente; "Automático" sigue en vivo al tema del sistema; el tema se recuerda y se aplica antes de pintar (sin parpadeo).

v50 intacto (verificado byte a byte). Revertir: borrar los bloques `g51-themeboot`, `codegot-v51-google`, `codegot-v51-pro-js` y `id="g51"`.
