# CodeGot v81 — La recarga se quita sola si hay un motor disponible (sobre v80)

- Mientras se muestra «IA recargándose», cada segundo se revisa: si algún motor tiene mensajes disponibles, la tarjeta y el bloqueo desaparecen al instante. Al cambiar de motor también se revisa.
- La tarjeta muestra el uso de cada motor (p. ej. «Free 100/100 · Flash 25/25 · Cerebrot 25/25 · v81») para ver si de verdad están los tres agotados y confirmar que se está usando esta versión.
- Si los tres están agotados, la recarga dura 2 horas y al terminar los tres motores vuelven a tener todos sus mensajes.
- Consola: cgResetLimits() reinicia contadores y recarga manualmente.
## Revertir: zip v80.
