# CodeGot v75 — Free mucho más lento y Flash al límite (sobre v74)

## Code Free (deliberadamente lento)
- Razonamiento en nivel ALTO (antes medio).
- Espera deliberada de 3 a 4,5 s antes de empezar a responder.
- El texto se escribe en pantalla a ~18 caracteres/segundo, sin ponerse al día, y la respuesta se termina de escribir a ese ritmo (se puede detener con el botón de parar).
- El prompt ya no limita a ~150 palabras: pide respuesta completa, ordenada y bien explicada.

## Code súper Flash (lo más rápido posible)
- Refuerzo con el 2.º modelo a los 50 ms (antes 120 ms).
- Salida máx. 300 tokens (antes 350), historial de 4 mensajes (antes 6), respuestas de ≤25 palabras (antes 30).
- El texto aparece sin pacing (render prácticamente instantáneo).
- Precalentamiento de la conexión con cualquier toque en la pantalla, además de enfocar/escribir en el cuadro de texto.
- Se mantienen los atajos locales, la caché de 6 h y la conexión caliente cada ~19 s.

## Revertir: zip v74.
