# CodeGot v61 — "Agua + Lamborghini": chat fluido y veloz (sobre v60)

## Qué cambia
- **Texto como agua**: cada letra nueva aparece con un fundido breve (de borroso a nítido) en lugar de saltar. El fundido continúa en la fase correcta aunque el HTML se regenere cada cuadro (animation-delay negativo = edad de la letra).
- **Ritmo más ágil, sin tirones**: arranque 35 % más rápido y alcance del atraso más corto (el caudal sigue filtrado, así que no hay acelerones). Al terminar el stream, vacía el resto en ~70 ms.
- **Scroll pegado al texto**: el seguimiento (resorte críticamente amortiguado, sin rebote) pasa de τ 0.26 s a 0.17 s y de tope 1100 a 3200 px/s. En la prueba, el chat llega al final en ~1.9 s en vez de ~3 s, con descenso siempre monótono.
- **Mensajes**: entrada con curva expo-out (arranque inmediato, final largo y sedoso), escala y origen según quién habla; solo animan los últimos 6 (listas largas más rápidas).
- **Inicio ⇄ chat** se funde en vez de saltar.
- **Controles**: respuesta inmediata al tocar (80 ms) y regreso largo y suave; barra de escribir con transiciones de la misma curva.
- Respeta "reducir movimiento". El texto final y lo guardado no cambian.

## Tocado
- Bloque `codegot-v61-water` (CSS) y script `codegot-v61-water` al final.
- Parche en el script principal: `nxStreamRender` ahora llama a `cgSoften` tras pintar (el original quedó como `nxStreamRender0`), y 5 constantes (`tau`, `target`, filtro de caudal, `NX_GLIDE_TAU`, `NX_GLIDE_MAXV`).

## Probado (Chromium 390×844, streaming simulado)
Texto final intacto (negrita, listas), 0 errores de JavaScript, el scroll converge sin rebote, 0 letras animadas pendientes al terminar.

## Revertir
Borrar el bloque y el script `codegot-v61-water`, renombrar `nxStreamRender0` a `nxStreamRender` (quitando la función envoltorio) y restaurar: `tau` 110/240, `target` 0.078, filtro 85, `NX_GLIDE_TAU` 0.26, `NX_GLIDE_MAXV` 1100.
