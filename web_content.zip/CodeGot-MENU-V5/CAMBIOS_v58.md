# CodeGot v58 — Letra un poco más pequeña (sobre v57)

Solo tamaños de letra (≈8–10 % menos), sin tocar lógica ni colores:
- Saludo y títulos: 31→28 px, barra superior y menú 22→20 px, títulos de ventanas 24→21,5 px.
- Subtítulo del inicio 16→14,5; tarjetas del inicio 15/13→13,5/12.
- Ajustes: botones 16→14,5, descripciones 13,5→12,5, términos legales 14,5→13,5.
- Chat: mensajes y barra de escritura 16→15 px.
- Menú lateral, botones y chips del Agent proporcionales.

Revertir: borrar el bloque `codegot-v58-type`.
