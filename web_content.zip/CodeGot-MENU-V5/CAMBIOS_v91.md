# CodeGot v91 — Plan Pro al pulsar Actualizar (sobre v90)

## Actualizar → CodeGot Pro
- Al tocar el botón **Actualizar** del pie de la barra lateral se abre el plan **CodeGot Pro** mensual.
- Precio: **15 USD / mes**.
- Funciones mostradas:
  - Code Súper Flash · 250.000 límite de mensajes
  - Code Cerebrot · 250.000 límite de mensajes
  - Code Agente · ilimitado · modificaciones ilimitadas
- Botón inferior **15 USD** listo para conectar la pasarela de pago (por ahora muestra aviso de “pago próximamente” y guarda `window.__codegotProCheckout`).

## UI
- Modal tipo bottom sheet (Material), compatible con tema claro y oscuro.
- Se cierra con la X, tocando fuera o el botón de atrás del sistema si ya estaba cableado.

## Versión visible: v91. Revertir: zip v90.

## Corrección (mismo zip v91)
- El script del plan Pro había quedado dentro de un texto de otro script, por eso el botón **Actualizar** no hacía nada. Se movió al final real del `<body>` y se restauró el texto original. Ahora **Actualizar** abre el plan Pro (15 USD/mes) y el botón **15 USD** responde.

## Cuenta obligatoria, sin invitado (mismo zip v91)
- Si no hay una cuenta con sesión iniciada, la app muestra una pantalla de bienvenida y el panel de cuenta (Crear cuenta / Iniciar sesión) que **no se puede cerrar**: sin botón Cerrar, sin tocar fuera y se reabre si se intenta salir.
- Al crear la cuenta o iniciar sesión, la app se desbloquea sola. Al cerrar sesión vuelve a pedirla.
- No hay modo invitado. Los usuarios que ya tenían sesión iniciada no ven cambios.

## Corrección: al cerrar el plan Pro la pantalla se trababa (mismo zip v91)
- El botón **15 USD** ya no usa `alert()` (se congela en visores/WebView de Android); ahora muestra un aviso propio dentro de la app.
- La hoja del plan Pro, cuando está cerrada, queda con `display:none` y no puede tapar toques.
- Cierre con X, tocando fuera, botón Atrás o Esc, con un solo escuchador que no se pierde si la pantalla se redibuja.
