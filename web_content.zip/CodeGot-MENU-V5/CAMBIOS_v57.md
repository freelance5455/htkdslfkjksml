# CodeGot v57 — Respuestas con formato real + herramientas Pro (sobre v56)

**El hallazgo principal de la auditoría:** el chat borraba todo el formato de la IA (negritas, títulos, listas, tablas, código) y lo mostraba como texto plano; los chats guardados incluso mostraban los `**` y `#` sin procesar. Los estilos de v56 (viñetas de color, citas, tarjetas de código, tablas) existían, pero nunca se aplicaban. Ahora sí.

## Nuevo
- **Formato real en las respuestas**: títulos, **negrita**, *cursiva*, listas (con sublistas y numeración correcta), citas, tablas (con scroll horizontal), enlaces, líneas separadoras y código. Funciona mientras el texto fluye, al terminar y en los chats guardados.
- **Bloques de código** con tarjeta, nombre del lenguaje y botón **Copiar**.
- **Regenerar respuesta** (solo en la última respuesta).
- **Reintentar** dentro del aviso de error de IA (un toque y reenvía tu último mensaje).
- **Leer en voz alta** por respuesta (con botón de detener) y **Compartir** cuando el dispositivo lo permite.
- **Botón "ir al final"** al subir en conversaciones largas.
- **Vibración suave** al enviar, copiar y regenerar.
- **Foco visible** para teclado y lector de pantalla.
- El punto de escritura ahora acompaña el último párrafo o ítem de la lista.

## Seguridad
- Todo el HTML de la respuesta se escapa **antes** de dar formato (un `<script>` o `<img onerror>` de la IA se muestra como texto). Solo se enlazan `http(s)` y `mailto`.

## Tocado
- `nxStreamRender`, `nxFinalText` (ahora reciben el texto crudo), `addBubble` (respuestas guardadas), función `cgMd` nueva, puente `cgRegenerate/cgCanRegen` y los bloques `codegot-v57-format` / `codegot-v57-tools` al final.
- Regenerar/Reintentar no se ofrecen si tu último mensaje llevaba archivo o imagen adjunta.

## Probado (Chromium headless 390×844, claro y oscuro, respuesta simulada)
- 26 pruebas unitarias del motor de formato (XSS, listas anidadas, tablas, código sin cerrar mientras llega el texto, rendimiento).
- Respuesta con título, lista, sublista, tabla, cita, código y enlace: todo renderiza; el `<script>` no se ejecuta.
- Copiar código, regenerar (1 llamada a la IA, sin duplicar mensajes), chat guardado con formato, botón al final, error 500 → Reintentar → respuesta correcta. 0 errores de JavaScript.

## Pendiente importante (no se puede arreglar solo con HTML)
- **La clave de la API de Gemini va dentro de la app**, solo ofuscada (XOR). Cualquiera que abra el HTML/APK puede recuperarla y usarla a tu costa. Para una app "Pro" de verdad hay que mover las llamadas a un servidor propio (por ejemplo una función en la nube que guarde la clave) y limitar la clave por cuota/app en Google Cloud.
- El archivo tiene 54 bloques `<style>` y ~4.800 `!important` apilados de versiones anteriores. Funciona, pero cada cambio de diseño es más difícil y pesa en el arranque; conviene consolidarlo en una versión limpia.

Revertir: borrar los bloques `codegot-v57-format` y `codegot-v57-tools` y restaurar `nxStreamRender`, `nxFinalText`, `addBubble` y las 3 llamadas `nxFinalText(answerSpan,cleanText(...))` de v56.
