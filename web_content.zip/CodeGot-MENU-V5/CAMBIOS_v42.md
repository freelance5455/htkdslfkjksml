# CodeGot v42 — fluida, no seca

v41 era rápida pero se sentía trabada (180 ms demasiado corto).
v42: **260 ms** panel / **240 ms** scrim, curva del chat `cubic-bezier(.22,1,.36,1)`.
Arranca con decisión, aterriza suave. Sin blur, sin cascada, sin box-shadow animado.
Gesto de soltar: 180–280 ms.
