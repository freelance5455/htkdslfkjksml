# CodeGot v97 — Súper agente del editor: más lento y más profesional (sobre v96)

## Más lento (las fases siguen ligadas a las señales reales; solo se alargan y suavizan las transiciones)
- Entrada de la tarjeta .38 s → .75 s. Anillo giratorio 1,25 s → 2,8 s. Estrella 1,8 s → 3,8 s. Brillo del título 2,2 s → 4,6 s. Punto del paso activo 1,2 s → 2,6 s. Destello de la barra 1,6 s → 3,4 s.
- Riel de pasos y barra de progreso: ahora se deslizan en 1,3 s con curva suave (antes .45 s). Nodos, etiquetas y cambio de título entre .6 y .9 s. La tarjeta se pliega en .9 s y el visto final se dibuja en .9 s.
- Con «reducir movimiento» activado en el sistema, todo sigue casi instantáneo.

## Más profesional
- Tarjeta con el mismo estilo que el chat (v96): borde fino, esquinas de 20 px, vainilla en claro y negro en oscuro.
- Etiqueta «SÚPER AGENTE» en mayúsculas con espaciado, título en semibold, cronómetro con borde fino.
- Línea divisoria sobre los 5 pasos; el paso activo lleva un aro plano suave (sin brillo); etiquetas más legibles.
- Barra de progreso más gruesa (4 px) y línea de código en caja con borde.

## No se tocó
- La lógica del agente, los tiempos reales, el límite diario ni el chat principal.

## Revertir: zip v96 o borrar el bloque `codegot-v97-agent`.
## Versión: v97.
