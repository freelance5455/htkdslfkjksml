# CodeGot v71 — Tarjetas siempre, límites diarios, Free 8 s y navegador rápido (sobre v70)

## 1) Tarjetas de Cerebrot
Causa real: si la foto del tema no cargaba (Wikipedia bloqueada/lenta, vista previa), la tarjeta entera nunca se mostraba. Ahora, si la foto falla o tarda más de 5 s, prueba la siguiente y, al final, usa la imagen generada por CodeGot. La tarjeta siempre sale en Cerebrot.

## 2) Límites diarios (reemplazan el aviso «Quedan N mensajes antes de que la IA se recargue»)
- Por usuario y por motor, se reinicia a medianoche (hora del dispositivo): Code Free 150, Code súper Flash 25, Code Cerebrot 25.
- Se eliminó el aviso de «quedan N mensajes» y la pantalla «La IA se está recargando».
- Al llegar al tope de un motor sale un aviso corto y puede cambiar a otro motor.

## 3) Code Free: tope duro de 8 s
- A los 8 s, si ya hay texto, se corta y se da por terminada (sin pedir continuación). Refuerzo a los 1,8 s. Tope de salida ~900 tokens salvo que pidan algo largo/código.

## 4) Navegador privado más rápido
- Animaciones de entrada/salida y pantalla de carga reducidas de ~1–1,6 s a ~0,2–0,4 s; se muestra la página en cuanto carga (máx. 3,5 s de espera); conexiones precalentadas (Wikipedia, Google).

## Límites honestos
Los 8 s de Free no se pueden garantizar si no llega ningún texto de la red; y la velocidad de las páginas dentro del navegador depende de cada sitio.
## Revertir: CAMBIOS_v70 / zip v70.
