package com.nexus.ia.pro.ui.chat

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch

/**
 * Selector de archivos/fotos del sistema que añade los adjuntos al [ComposerState].
 *
 * Los metadatos de cada Uri (MIME + nombre) se leen en `Dispatchers.IO` ([toAttachments]); el hilo principal solo
 * recibe el resultado ya listo. Devuelve una lambda estable (misma instancia entre recomposiciones) para pasarla
 * a un botón sin forzar recomposiciones.
 *
 * Requiere `androidx.activity:activity-compose`.
 */
@Composable
fun rememberAttachmentPicker(composer: ComposerState): () -> Unit {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            scope.launch { context.toAttachments(uris).forEach(composer::addAttachment) }
        }
    }
    return remember(launcher) { { launcher.launch(arrayOf("image/*", "*/*")) } }
}
