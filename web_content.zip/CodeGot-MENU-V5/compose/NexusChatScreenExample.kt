package com.nexus.ia.pro.ui.chat

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier

/**
 * Pantalla de ejemplo que conecta TODAS las piezas. Úsala como guía para tu pantalla real:
 *
 *   Enviar ──► ChatMessage(text + attachments) ──► historial ──► ChatMessageList ──► ChatMessageBubble
 *
 * Reglas para mantenerlo fluido:
 *  • El estado (`messages`, `composer`) es estable y sus lambdas solo capturan valores estables → esta pantalla
 *    no se recompone al teclear ni al llegar mensajes: solo las piezas que leen ese estado.
 *  • El auto-scroll vive DENTRO de [ChatMessageList] (snapshotFlow): no hace falta LaunchedEffect aquí.
 *  • Mientras esperas el primer token pasa `isThinking = true` a [ChatMessageList] (animación "CodeGot pensando").
 *  • Para respuestas de IA en streaming, añade un mensaje vacío y actualízalo con `updateText` (ver TODO).
 */
@Composable
fun NexusChatScreenExample() {
    val composer = rememberComposerState()
    val messages = remember { mutableStateListOf<ChatMessage>() }

    // Lambda recordada: misma instancia entre recomposiciones → ChatInputBar se puede saltar
    val onSend = remember(composer, messages) {
        {
            messages += composer.buildMessageAndClear()
            /* TODO: llamar a la IA. Streaming fluido:
             *   val reply = ChatMessage(text = "", isUser = false)
             *   messages += reply
             *   // collectBatched ya ejecuta el flujo de origen (red) en Dispatchers.IO y publica en Main cada 16 ms:
 *   viewModel.tokens(prompt).collectBatched { full -> messages.updateText(reply.id, full) }
             *   // Adjuntar: val pickFiles = rememberAttachmentPicker(composer)  (lee metadatos en IO)
             */
        }
    }

    Scaffold(
        containerColor = NexusColors.Bg,
        bottomBar = {
            ChatInputBar(
                state = composer,
                onSend = onSend,
            )
        },
    ) { padding ->
        ChatMessageList(
            messages = messages,
            modifier = Modifier.padding(padding),
        )
    }
}
