# CodeGot v85 — Free a 6 s, texto más rápido y límites por motor (sobre v84)
- Code Free: la respuesta aparece a los 6 s exactos desde el envío (antes 20 s), pase lo que pase por debajo. El menú dice «tarda unos 6 s».
- Code Free: el texto se escribe más rápido (~37 caracteres/s, antes ~20).
- Límites diarios por motor: Free 1000 · Code súper Flash 100 · Code Cerebrot 100. El menú muestra «Te quedan N de M hoy» de cada uno.
- Al agotarse un motor: si «Cambiar automáticamente» está activo, pasa a otro con mensajes; si no, aparece el aviso para elegir otro. Cuando se agotan los tres, sale «IA recargándose» (2 h).
- Versión visible: v85. Revertir: zip v84.
