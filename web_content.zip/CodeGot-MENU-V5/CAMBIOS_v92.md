# CodeGot v92 — Copiar código, botones del chat y editor más limpio (sobre v91)

## 1. Copiar código (CodeGot Agent)
- El botón "Descargar ZIP" ahora es **Copiar código**: copia el código de toda la app (un archivo = código tal cual; varios = separados con el nombre de cada archivo).
- Respaldo para WebView/Android si el portapapeles moderno no está disponible (también en el "Copiar" de cada archivo).

## 2. Botones del chat
- Bajo la respuesta de la IA: una sola fila, iconos iguales, orden fijo: Copiar · Me gusta · No me gusta · Regenerar · Leer en voz alta · Compartir.
- Bajo el mensaje del usuario: solo **Copiar** (sin Me gusta ni Regenerar).

## 3. Editor de apps: texto que se salía de pantalla
- Los bloques de código y las tablas de las respuestas ahora se ajustan al ancho; palabras/URLs largas se parten.

## 4. Saludos y preguntas en el editor
- Saludos, gracias y despedidas: respuesta local instantánea, sin tarjeta de Súper agente ni "Analizando tu app".
- Preguntas: respuesta breve con puntos de espera, sin tarjeta, sin verificación y sin gastar modificaciones del día.
- Pedidos de cambio: igual que antes. Si hay duda, se trata como pedido de cambio.

## Versión visible: v92. Revertir: zip v91.
