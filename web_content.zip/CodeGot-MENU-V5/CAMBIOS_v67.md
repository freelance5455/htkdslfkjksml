# CodeGot v67 — Respuestas en segundo plano + 3 motores de IA (sobre v66)

## 1) La IA sigue respondiendo aunque cambies de chat
- Antes: si preguntabas algo y abrías otro chat, la respuesta se perdía o caía en el chat equivocado, y no podías escribir en el otro chat hasta que terminara.
- Ahora: cada chat tiene su propia respuesta en curso. Puedes salir, abrir otro chat (incluso escribir allí) y la respuesta sigue llegando y se guarda en SU chat.
- Al volver a ese chat ves el texto que ya llevaba (o la respuesta completa si ya terminó) y sigue fluyendo.
- Barra lateral: punto azul parpadeando = ese chat está respondiendo; punto fijo = terminó mientras estabas en otro chat. Además sale un aviso "CodeGot ya respondió en «…»".
- "Detener" solo detiene la respuesta del chat que estás viendo.

## 2) Botón ^ con 3 motores (barra donde escribes)
- **Code Free**: el motor de siempre (sin cambios).
- **Code súper Flash**: el más rápido. Lanza dos modelos rápidos a la vez (el 2.º arranca a los 350 ms, o antes si el 1.º falla) y gana el que emita texto primero; razonamiento mínimo, respuestas directas y breves, sin retraso de "máquina de escribir" y sin búsqueda web.
- **Code Cerebrot**: razona con más profundidad y es el ÚNICO que muestra las tarjetas del tema (Wikipedia) cuando pides "explícame", "enséñame", "ayúdame", "describe", "define", "detalla", "aclara", "cuéntame", "aprender", "estudiar", "entender"… Con Free y Flash no salen tarjetas (y al cambiar a ellos las del chat abierto se quitan; al volver a Cerebrot reaparecen).
- El motor elegido se recuerda al cerrar la app.

## 3) Animación al cambiar de motor
El chat se desenfoca, aparece "Preparando motor" con anillo animado en el color del motor, se activa el nuevo motor y el chat se adapta (tarjetas sí/no); luego la animación desaparece y el chat vuelve nítido. Con "reducir movimiento" se acorta.

## Tocado
- `handleSend` reescrita (trabajos por chat `nxJobs`), `selectChat`, `renderSavedConversation`, `renderRecentList`, botón Detener, `nexusAskOpenAI`, `callOpenAI` (nivel de razonamiento por motor) y nueva `nxRaceFast`.
- Script `nexus-topic-image`: `isQuestion` ahora depende del motor, palabras nuevas de explicar/enseñar y `nxTopicSync`.
- Nuevos bloques al final: `<style id="codegot-v67-engines">` y `<script id="codegot-v67-engines-js">`.

## Revertir
Usar `CAMBIOS_v66` / el zip v66. Para quitar solo los motores: borrar los dos bloques `codegot-v67-engines*` y la línea `if(window.cgEngine…) return false;` de `isQuestion`.

## Probado (Chrome sin interfaz, IA simulada)
- Preguntar → abrir otro chat → la respuesta se guarda en el chat correcto, el otro chat queda intacto, aparece el punto de "sin leer" y al volver se ve completa.
- Salir y volver a mitad de la respuesta: se ve el texto parcial y sigue fluyendo.
- Menú ^ con los 3 motores, animación de desenfoque, motor guardado.
- Free y Flash no piden tarjetas; Cerebrot sí. Flash usa el modelo rápido con razonamiento mínimo; Cerebrot razonamiento medio.
- Con un servidor simulado de 60 ms, el primer texto salió a ~85 ms. **La velocidad real depende de Google y de tu internet: no se puede garantizar medio segundo exacto, pero Flash es lo más rápido posible con estos modelos.** No pude probar con la API real ni en un teléfono: pruébalo en el dispositivo.
- Los nombres de modelo `gemini-3.5-flash-lite` y `gemini-3.5-flash` son los que ya usaba tu app; si alguno no existiera, Flash cae al otro automáticamente.
