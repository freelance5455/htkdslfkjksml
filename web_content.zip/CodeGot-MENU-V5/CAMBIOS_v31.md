# CodeGot v31 — cambios

## CodeGot Agent · Editar app
- **Nuevo indicador "pensando"** en el chat del editor (donde antes estaban los 3 puntos): un cuadro profesional que gira (marco con núcleo que pulsa en sentido contrario), el texto **"Súper agente pensando"** con brillo suave y los 3 puntos animados al lado.
- Respeta "reducir movimiento" del sistema.
- Archivos tocados: `original.html` y `rebuild_nexus/zoe-nova-ia.html` (idénticos). Estilos `.nxa-sq`, `.nxa-tl`, `.nxa-td`.
