# CodeGot v80 — La recarga ya no bloquea si queda algún motor disponible (sobre v79)

- La pantalla «IA recargándose» solo puede existir si los TRES motores están realmente agotados. Si hay una recarga guardada pero queda algún motor con mensajes, se borra sola al abrir o al enviar.
- Nunca se inicia una recarga si queda algún motor con mensajes: se pasa a ese motor y se envía.
- Un envío vacío (tocar enviar sin texto) ya no cuenta ni dispara bloqueos.
## Revertir: zip v79.
