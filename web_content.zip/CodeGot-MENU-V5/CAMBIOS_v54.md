# CodeGot v54 — "Pensando" del Agent, de vuelta y mucho mejor (sobre v53)

Cuando la IA está preparando una respuesta en el chat, vuelve el cuadro que gira del chat del Agent, ahora rediseñado:

- **Cuadro con anillo-cometa**: el degradado del saludo (azul → violeta → rojo → naranja) recorre el borde y la marca CodeGot respira dentro; resplandor suave detrás.
- **Frases reales según lo que haces**: "Pensando" → "Analizando tu pregunta" → "Preparando la respuesta". Con búsqueda web: "Buscando en la web / Contrastando fuentes". Con archivo adjunto: "Revisando tu archivo". En modo negocios: "Analizando tu negocio". Si tarda: "Sigo en ello" y "Tarda más de lo normal". El ancho no salta al cambiar de frase.
- **Cronómetro** que aparece (la tarjeta se ensancha suave) solo si pasan más de 3 s, y **línea de progreso** inferior.
- **Punto de escritura** de colores al final del texto mientras la IA va escribiendo; desaparece solo al terminar.
- Claro y oscuro (sigue los tokens del tema), en pausa en segundo plano, y con "reducir movimiento" queda quieto.
- Solo transform/opacity en el compositor; el temporizador se detiene solo cuando llega el texto o se detiene la generación.

Probado en headless 390×844 (claro y oscuro) con respuesta simulada: el indicador sale al enviar, cambia de frase a 2,4 s y 5,2 s, muestra el cronómetro a los 3 s, se retira al llegar el primer texto, el punto de escritura aparece solo durante la generación y la imagen del tema ("Sobre tu pregunta") sigue enganchándose igual (se mantiene la clase `.typing-row`). 0 errores de JavaScript.

Tocado: `showTyping()` (ahora recibe el contexto de la pregunta), la llamada en `handleSend`, `nxSetGenerating()` (marca `cg-gen`) y el bloque `<style id="codegot-v54-think">` al final. Lo demás es idéntico a v53.

Revertir: restaurar `showTyping()` de v53 y borrar el bloque `codegot-v54-think`.
