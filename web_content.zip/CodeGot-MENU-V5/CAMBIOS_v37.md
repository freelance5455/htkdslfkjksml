# CodeGot v37 — barra lateral con la fluidez del chat

## Barra lateral de chats
- Abre y cierra con la **misma curva y duración que los mensajes de la IA**: `cubic-bezier(.22,1,.36,1)` a 300 ms (variable `--nx-water`). Antes: ease-in-out de .27 s impuesto por `nx-ultrafast-css`, además acelerado x1.4 por el script `nx-ultrafast`.
- El fondo oscuro (scrim), los botones/filas de dentro y el soltado del gesto de arrastre (220–320 ms) usan esa misma curva.
- Los primeros 8 chats del historial entran con la animación de un mensaje nuevo (`nxV32Msg`) con un escalonado de 25 ms (antes: cascada de 600 ms).
- El script `nx-ultrafast` ahora excluye `#sidebar` y `#scrim` (igual que las filas de la IA).
- Respeta "reducir movimiento".
- Solo movimiento: no cambia colores, estructura ni lógica. Estilos en `<style id="nexus-v37-sidebar-flow">` (al final del HTML). Para cambiar el ritmo: `300ms` en ese bloque.
- Archivos: `original.html` y `rebuild_nexus/zoe-nova-ia.html` (idénticos). Compose no tiene barra lateral; no se tocó.
