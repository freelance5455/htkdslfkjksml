# CodeGot v30 — cambios

## CodeGot Agent
- **Pantalla completa real**: el botón ahora pone la app a toda la pantalla, con una **X** arriba a la derecha para salir (también con Esc). La app no se recarga ni pierde su estado. (Antes quedaba encerrada dentro del panel por un `contain:layout`.)
- **Editar**: nuevo botón junto a "Pantalla completa" (aparece con la app terminada). Abre un chat IA normal —mismo motor/API del chat— con la app al lado, en vivo.
  - Mientras el modelo trabaja, la app actual se **desenfoca** bajo un velo de cristal con "Agregando modificaciones". La versión nueva carga detrás del desenfoque y, al estar lista, el velo se disuelve y la app se enfoca con una transición suave (+ "Modificaciones aplicadas").
  - Hay una **X** arriba para salir del editor.
  - Si el usuario solo pregunta, responde con texto y no cuenta. Solo cuentan las modificaciones realmente aplicadas.
  - Los cambios se validan antes de aplicarse; si algo sale mal la app queda igual y no se descuenta.
  - Pantallas anchas / horizontal: chat a la izquierda, app a la derecha. Teléfono vertical: app arriba, chat abajo.
- **Límite de 10 modificaciones por día**. Al aplicar la décima se saca al usuario de la sección y aparece un **cronómetro de 4 h** sobre el botón "CodeGot Agent" de la barra lateral; no se puede entrar hasta que llegue a 0:00:00. Al terminar, el contador vuelve a 0.
  - Constantes en el script `nx-agent-js`: `EDIT_LIMIT` y `LOCK_MS`.
- Los avisos (toast) del Agent ahora sí se ven (antes el puente no los mostraba).

## Chat
- Capa de fluidez: resorte de scroll más sedoso, mensajes antiguos fuera de pantalla no se pintan, y los párrafos nuevos entran con fundido.

## Nota
- El límite y el cronómetro se guardan en el dispositivo (por cuenta). Sin servidor no pueden ser infalibles: borrar los datos del navegador o cambiar la hora del equipo los reinicia/adelanta.
