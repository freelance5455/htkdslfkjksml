# CodeGot v86 — Flash más didáctico y Cerebrot más razonado (sobre v85)
## Code súper Flash
- Respuestas de 3 a 5 frases (40–80 palabras): dato directo primero, luego el porqué en palabras sencillas y un ejemplo corto si ayuda. Saludos y datos simples siguen en una frase.
- Misma velocidad: salida en streaming, razonamiento mínimo, carrera de modelos, respuestas locales, caché y predicción intactos. Tope de salida 300 → 520 tokens.
- Caché de Flash reiniciada (v2) para no mostrar respuestas cortas viejas.
## Code Cerebrot
- Razonamiento ALTO (antes medio) y 350–600 palabras (antes 250–450).
- Estructura: idea en una frase · analogía · paso a paso · ejemplo con números · errores comunes · para recordar · NUEVO «Pruébate» (pregunta de comprobación).
- Razona en silencio antes de escribir; el texto se entiende solo junto a la tarjeta visual de imágenes del tema (la tarjeta no se modificó).
- Menú: «El más razonado · explica paso a paso con tarjetas del tema».
## Versión visible: v86. Revertir: zip v85.
