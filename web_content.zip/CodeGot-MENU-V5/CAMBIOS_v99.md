# CodeGot v99 — Burbujas redondeadas profesionales y «Analizando tu pregunta» más lento (sobre v98)

## Burbujas de pregunta y respuesta
- Esquinas de 26 px con una esquina «de cola» de 8 px: abajo-izquierda en la respuesta de la IA, abajo-derecha en la pregunta del usuario.
- Avatar del logo ahora circular con aro fino; cabecera algo más alta, más aire interior (20 px) y línea divisoria más limpia.
- Color: burbuja del usuario en vainilla un poco más cálido (#EFE8D8) para que destaque del fondo; respuesta en vainilla casi blanco. Oscuro: igual que antes.
- Las 6 burbujas más recientes llevan una sombra suave de profundidad; las antiguas solo una línea fina (menos coste al desplazar).

## Indicador «Analizando tu pregunta» (Pensando)
- Más lento: velocidad ×1,5 (Free 1,5 · Flash .95 · Cerebrot 1,9).
- Más profesional: burbuja plana del mismo estilo que las respuestas, sin el borde de luz giratorio, sin resplandor, sin anillos extra y sin la sombra grande que dejaba una banda bajo la tarjeta. Queda el anillo del logo con una sola estela, la frase con brillo suave, las líneas que «se escriben» y la barra fina.
- Mejora de rendimiento: el borde cónico animado se repintaba en cada cuadro; ya no existe.

## No se tocó
- Lógica de chat; textos y fases del indicador; botones bajo cada mensaje.

## Revertir: zip v98 (o borrar `codegot-v99-think` y restaurar el bloque `codegot-v96-cards`).
## Versión: v99.
