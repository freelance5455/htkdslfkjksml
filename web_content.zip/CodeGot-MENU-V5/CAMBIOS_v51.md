# CodeGot v51 — Diseño profesional estilo Google (sobre v50)

## Qué cambia (solo capa visual + accesibilidad; la lógica no se tocó)
- Sistema de diseño único (Material 3 / paleta Gemini): superficies #fff / #f0f4f9, acento azul Google #0b57d0, tipografía Google Sans → Roboto → Inter, elevación y estados hover/pressed consistentes.
- Inicio: saludo con degradado Google, tarjetas tonales, compositor tipo "pastilla" que se eleva al enfocar, botón Agent delineado.
- Barra lateral: ahora es un cajón CLARO coherente con el resto (antes era negra sobre una app clara). "Nuevo chat" como acción principal tonal.
- Mensajes: burbuja tonal para el usuario, respuesta de la IA sin burbuja a 16 px (legible, sin zoom en iOS).
- Diálogos (permisos, Ajustes, cuenta, Agent): 28 px de radio, botones de texto/rellenos, tarjetas de Ajustes agrupadas, acción de borrar en rojo suave.
- Snackbar (toast) oscuro estilo Google; un solo fondo blanco (se eliminaron capas crema superpuestas).

## Accesibilidad y calidad
- Foco visible en todo (antes casi inexistente), botones de 44 px, Ajustes con nombre accesible, landmark <main>, diálogos con role="dialog", conversación como región en vivo.
- Teclado: Esc cierra diálogo/menú, "/" enfoca el mensaje, Enter/Espacio activan los ítems del menú.
- Aviso de "Sin conexión" / "Conexión restablecida".
- PWA: manifiesto en línea + metas para instalar como app (pantalla completa, color de tema).

## Seguridad (pendiente, requiere servidor)
La clave de Gemini viaja dentro del HTML (solo ofuscada con XOR); cualquiera puede extraerla. Recomendado: moverla a un proxy/backend y restringirla por dominio en Google AI Studio.

## Cómo revertir
Borrar `<style id="codegot-v51-google">`, `<script id="codegot-v51-pro-js">` y `id="g51"` de `<html>`. El resto es idéntico a v50.
