# CodeGot v69 — Respuestas siempre completas + Cerebrot que enseña de verdad (sobre v68)

## 1) Ningún motor deja la respuesta a medias
**Causa del corte** (captura: la lista terminaba en «• A»): el código nunca miraba por qué terminaba la respuesta, y en Gemini los tokens de "pensamiento" cuentan dentro del máximo de salida. Cerebrot (razonamiento medio) gastaba casi todo el presupuesto (2200 + 1500) pensando y se quedaba sin espacio para escribir.
- Presupuesto de salida mucho mayor: Cerebrot 11 000 (antes 3 700), Free 5 000 (antes 3 700), con búsqueda web 5 500+, simulador 24 000 máx. Es solo un tope, no alarga las respuestas simples.
- **Continuación automática** en TODOS los motores (Free, Flash, Cerebrot): si la respuesta termina por límite de tokens (`MAX_TOKENS`) o la conexión se corta a mitad, CodeGot pide continuar "exactamente donde se cortó, sin repetir" hasta 3 veces y el texto sigue fluyendo en la misma burbuja. Si no se puede continuar (sin red), se conserva lo recibido.
- Se lee ahora `finishReason` de Gemini (stream y no-stream).

## 2) Code Cerebrot: explica para que se ENTIENDA
Antes Cerebrot usaba el prompt base estricto ("prohibido ejemplos", "1-2 oraciones") con una nota corta encima: se contradecían. Ahora tiene su propio prompt de profesor:
1. La idea en una frase · 2. Para imaginarlo (analogía cotidiana) · 3. Paso a paso (términos definidos al aparecer) · 4. Ejemplo concreto resuelto · 5. Ojo con esto (errores comunes) · 6. Para recordar · y cierra con una pregunta de comprobación o el siguiente paso.
- Asume principiante curioso y adapta el nivel si el usuario dice quién es.
- Frases cortas, negrita en términos clave, listas y pasos numerados.
- 250-450 palabras normalmente, **planifica el largo para cerrar siempre completo**.
- Preguntas que no son de aprender (dato, tarea, saludo): responde directo, sin forzar la estructura.
- Usa el nombre del usuario con naturalidad.
Las tarjetas del tema (Wikipedia) siguen igual.

## Tocado
`callOpenAI` (margen de tokens por nivel de razonamiento, `finish`), `nexusAskOpenAI` (presupuesto, bucle de continuación, prompt de Cerebrot), nueva `nxCerebrotSystem`. Free y Flash conservan sus prompts.

## Revertir
Usar `CAMBIOS_v68` / el zip v68.

## Probado (Node + servidor simulado, no la API real)
Cerebrot, Free y Flash con respuesta cortada por `MAX_TOKENS` y por conexión cortada sin `finishReason`: se completa, el texto de pantalla coincide con el guardado y solo hay 1 petición extra; respuesta normal (`STOP`): sin petición extra. Sintaxis de todos los scripts sin errores.
No pude probar con la API real ni en el teléfono: prueba "explícame las matemáticas" con Cerebrot.
