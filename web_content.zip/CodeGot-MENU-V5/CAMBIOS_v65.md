# CodeGot v65 — Icono nítido + "Pensando" premium (sobre v64)

## Icono sin pixelado
- Causa: el logo era una imagen de 256 px con ruido en los bordes, y en el avatar de cada respuesta se usaba como **máscara de 15 px** (por eso se veía como un cuadro blocoso).
- Ahora el logo es **vectorial (SVG)**: queda nítido a cualquier tamaño y pantalla. Mismo estilo (carita teal con ojos grandes), redibujado limpio.
- El avatar de la IA en los mensajes (y en el chat del Agent) usa el logo **a color** a 18 px, ya no una máscara.
- Favicon (192 px) e icono de pantalla de inicio (180 px) regenerados desde el mismo diseño.

## "Pensando" — nivel premium
- Logo vectorial dentro de un **anillo fino con arco teal→champagne** que gira con ritmo orgánico (acelera y frena), y el logo respira.
- **Destello suave** que cruza la tarjeta cada ~3 s.
- Frase activa con brillo; el cambio de frase desliza hacia arriba.
- **Pasos 1·2·3** que se alargan al avanzar, **puntos en onda**, cronómetro que aparece suave.
- Solo `opacity`/`transform` (compositor), pausa en segundo plano, respeta "reducir movimiento".

## Tocado
Variable `--cg-logo` (ahora SVG), favicon/apple-touch, bloque `<style id="codegot-v65-think">` (reemplaza al v64-think). `showTyping()` sigue igual que en v64.

## Revertir
- Animación: borrar `<style id="codegot-v65-think">`.
- Anillo giratorio solamente: quitar la regla `.cg-th-sq::before` del bloque.
