# CodeGot v39 — fluidez de la barra lateral = fluidez del chat

La barra lateral de chats usa **exactamente** la misma curva y ritmo que los mensajes de la IA (`nxV32Msg` / `--nx-water`):

- **Curva:** `cubic-bezier(.22,1,.36,1)`
- **Duración del panel y del scrim:** 300 ms
- **Elementos internos** (recent-item, side-item, botones): 160 ms con la misma curva; active 80 ms
- Sin cascada de entrada de chats, sin `backdrop-filter` en el scrim, sin transición de `box-shadow`
- Solo `transform` / `opacity` (capa de composición) → sin lag al abrir/arrastrar
- El gesto de arrastre sigue soltando entre 220–320 ms con la misma curva
- `nx-ultrafast` y estilos antiguos (`nexus-sidebar-turbo`, `waterFlowStyle`, `nexus-sidebar-blur`) quedan por debajo por especificidad (doble `#id`)

Archivos: `rebuild_nexus/zoe-nova-ia.html` y `original.html` (idénticos).
