# CodeGot v43 — como el agua

Curva líquida `cubic-bezier(.16,1,.3,1)` · panel 320 ms · scrim 280 ms.
Limpia estilos inline antes de abrir/cerrar (sin salto = sin traba).
Sin blur, sin cascada, sin box-shadow animado.
