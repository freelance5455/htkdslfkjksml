# CodeGot v60 — "Aurora Glass": editor premium + pulido global (sobre v59)

Solo CSS (bloque `codegot-v60-premium` al final). Lógica, límite de 10 ediciones y motor de la IA intactos.

## Editar app (la sección de tu captura)
- **Vista en vivo dentro de un dispositivo**: marco oscuro con isla, brillo de borde y luz de marca difuminada detrás.
- **Mientras la IA trabaja**: el marco se enciende con un aro de degradado giratorio, la luz de fondo pulsa y la tarjeta de vidrio muestra orbe de marca, porcentaje y barra de degradado.
- **Cabecera de vidrio** con etiqueta "Studio", botones circulares flotantes, contador con rayo y barra de progreso.
- **Hoja de chat** con borde de degradado, sombra de profundidad y desvanecido al hacer scroll.
- **Mensajes** con entrada animada; tu burbuja con tinte de marca y aro fino.
- **Sugerencias** en tarjetas con borde de degradado, flecha y aparición escalonada.
- **Compositor** con aro de degradado al escribir y botón enviar con degradado y resorte.
- Fondo con aurora suave. Claro y oscuro. Pantallas anchas conservan el diseño lado a lado.

## Pulido global
Barra superior esmerilada, menú lateral (búsqueda con foco, pie con avatar de degradado, pulsaciones con resorte), panel Agent (tarjetas con relieve, botón principal y orbe con degradado), ajustes y tarjetas del inicio con micro-interacciones. Respeta "reducir movimiento".

## Revertir
Borrar el bloque `<style id="codegot-v60-premium">`.
