# CodeGot v70 — Tarjetas de Cerebrot otra vez + Code Free con meta de 8 s (sobre v69)

## 1) Tarjetas del tema en Cerebrot
**Causa:** la lista de palabras que activan las tarjetas solo reconocía «explícame / explica / enséñame…». Con «Me explicas la ciencia» (captura) no coincidía ("explicas") y no salía tarjeta. (No lo causó v69.)
- Ahora se reconocen todas las formas naturales: explicas, puedes explicarme, podrías explicar, expliques, enseñas, enseñarme, describes, defines, aclaras, detallas, me cuentas, ayudas, etc.
- El tema se extrae bien aunque lo pidas así: «Me explicas la ciencia» → ciencia; «Puedes explicarme la fotosíntesis» → fotosíntesis; «Defines inflación» → inflación.
- Siguen sin salir tarjetas con Free y Flash, y con frases que no piden aprender («hola», «qué hora es»).

## 2) Code Free: meta de 8 s
- **Razonamiento mínimo** por defecto (bajo solo si la pregunta tiene cálculo/lógica/código).
- **Refuerzo automático**: si el modelo principal no emite texto en 2,5 s, arranca el de respaldo y gana el primero que escriba.
- Petición sin preflight y conexión precalentada (igual que Flash).
- **Instrucción de tiempo**: respuesta completa pero eficiente (~150 palabras salvo que se pida más) y siempre terminada.
- Hora, fecha y cálculos simples se responden en local, al instante (también en Free).
- La continuación automática de v69 sigue activa por si se corta.

## Tocado
Script `nexus-topic-image` (`LEARN_RE`, nueva `nxVerbNorm`, `deriveTopic`), `nxRaceFast` (modelos/tiempo de refuerzo configurables), `nexusAskOpenAI` (rama Free) y el bloque de precalentado.

## Revertir
Usar `CAMBIOS_v69` / el zip v69.

## Probado (Node + servidor simulado, no la API real)
14 frases para tarjetas/tema correctas; Free: respuesta normal con 1 petición, principal lento → refuerzo a los 2,5 s, hora local sin llamar a la API.
## Límite honesto
Un tope de 8 s "sí o sí" no puede garantizarse con una red/IA externa: respuestas largas pedidas a propósito o mala señal pueden tardar más. Con las medidas de arriba lo normal queda muy por debajo. Mide con `cgFlashStats()` en la consola.
