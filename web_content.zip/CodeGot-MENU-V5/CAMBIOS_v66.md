# CodeGot v66 — La imagen del tema aparece al ritmo de la respuesta (sobre v65)

## Qué cambia
- Antes: apenas salía el primer texto, la tarjeta "Sobre tu pregunta" aparecía **completa de golpe** y empujaba la respuesta hacia abajo.
- Ahora: la tarjeta **se despliega poco a poco, de arriba hacia abajo, siguiendo los caracteres que la IA va escribiendo** (se completa cuando ya salieron ~240 caracteres). Con un filtro suave, así no hay saltos aunque el texto llegue a ráfagas.
- Respuesta corta o que termina antes: la tarjeta se completa sola (~0.5 s después de terminar). Tope de seguridad: 4.5 s.
- El chat sigue el despliegue (scroll pegado) mientras estás al final.
- **Historial** (mensajes viejos al abrir un chat): la imagen aparece al instante, igual que antes.
- Con "reducir movimiento" activado: aparece directa, sin despliegue.

## Tocado
Función `nxReveal` dentro del script `nexus-topic-image` (una llamada tras insertar la tarjeta) y el bloque `<style id="codegot-v66-reveal">`.
El resto (búsqueda de la imagen, carrusel, caché) no cambia.

## Revertir
Borrar la línea `try{nxReveal(fig,bubble,near);}catch(_e){}` (la tarjeta vuelve a aparecer de golpe) y el bloque `codegot-v66-reveal`.

## Probado
Sintaxis de todos los scripts sin errores. Simulación del despliegue con texto a ~105 car/s: la altura crece de forma monótona siguiendo el texto, termina y limpia los estilos (respuesta larga y corta); en historial no hace nada. No pude abrirlo en un navegador real aquí: pruébalo en el teléfono.

## Incluye lo de v65
Logo vectorial nítido (avatar de la IA sin pixelado) y la animación "Pensando" premium.
