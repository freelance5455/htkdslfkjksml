# CodeGot v90 — Capa Android / Material You sobre todo el chat (sobre v89)

Solo estilo y microinteracciones; no cambia lógica, botones ni funciones.

## Qué se nota
- Burbujas del usuario en "contenedor primario" sólido (azul tonal claro / azul profundo en oscuro), sin degradado ni borde.
- Tarjetas de inicio tonales de 24px con iconos en círculo tonal de 44px.
- Barra de escribir de 56px, 28px de radio, anillo de foco azul de 2px (se quitó el aro dorado antiguo); botón enviar azul con sombra nivel 1; chip de motor como "assist chip" de 12px.
- Botón "bajar" como FAB cuadrado redondeado (16px) con sombra nivel 3.
- Barra lateral estilo Navigation Drawer: ítems de 56px en píldora, "Nuevo chat" en contenedor tonal, buscador y selector de proyecto tonales.
- Snackbar Material para los avisos (toast), diálogos como bottom sheet con asa y 28px de radio, menús de 16px.
- Tipografía Material 3 (título 22px, saludo 32px, texto 16px/24px).

## Microinteracciones Android
- Ripple Material al tocar botones, tarjetas y elementos del menú.
- Vibración corta (6 ms) al tocar. Para desactivarla: localStorage cg_haptics = '0'.
- Barra superior tonal al desplazar el chat.
- Entrada de mensajes con curva "emphasized decelerate" (0,46 s).
- Botón "Atrás" de Android: cierra menú lateral / diálogos / navegador antes de salir de la app.
- Anillo de foco visible (accesibilidad) y selección de texto con el color primario.

## Versión visible: v90. Revertir: zip v89.
