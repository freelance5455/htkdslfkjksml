# CodeGot v55 — CodeGot Agent con el mismo diseño del chat (sobre v54)

La pantalla de **crear app** (CodeGot Agent) tenía su propio estilo crema/negro con títulos en mayúsculas espaciadas. Ahora usa exactamente el mismo sistema de diseño del chat (tokens `--g-*`), así que **claro y oscuro** funcionan solos.

- **Cabecera** igual a la barra del chat: botones redondos de 44 px, título "CodeGot Agent" en 22 px (sin mayúsculas espaciadas) y sin el hueco extra de arriba.
- **Portada**: el cuadro con el logo, el título con degradado azul→violeta→rojo→naranja y el subtítulo centrado, como el saludo del chat.
- **Tarjetas** tonales de 24 px (sin bordes); la de "Tu app" se comporta como el compositor del chat (al escribir se vuelve blanca con sombra suave y el cuadro crece con el texto).
- **Botones** en píldora (Crear app = azul primario, Detener = contorno), sugerencias como chips, segmentos Vista previa/Archivos/Registro estilo Material 3.
- **Progreso y plan**: orbe azul, barra con el degradado del chat, línea de tiempo azul, insignias Completada/En curso/Pendiente con colores del tema. Mientras trabaja, la portada se compacta para ver el progreso sin hacer scroll.
- **Proyectos**, menú de opciones, aviso flotante "Agent · 25%" (ahora sobre el compositor, ya no lo tapa) y toasts con el estilo del chat.
- **Editor de apps**: mensajes igual que el chat (tuyos en burbuja tonal, de la IA sin burbuja), barra de escritura idéntica al compositor, tarjeta del súper agente y velo de trabajo con los mismos colores.
- **A su medida**: pantallas muy estrechas (<360 px: botones apilados), tablets/escritorio (ancho máx. 680 px) y horizontal (sin logo para ganar espacio); respeta "reducir movimiento".

Tocado: título y portada del panel (2 textos en `nx-agent-js`, "Editar app" en el editor) y el bloque `<style id="codegot-v55-agent">` al final. Lógica del Agent, chat y finanzas idénticas a v54.

Revertir: borrar el bloque `codegot-v55-agent` y restaurar los textos "COREGPT AGENT", "EDITAR APP" y la portada sin logo.
