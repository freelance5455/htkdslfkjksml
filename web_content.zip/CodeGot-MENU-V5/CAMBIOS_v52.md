# CodeGot v52 — Modo oscuro + más pulido (sobre v51)

- **Modo oscuro Material 3** (Automático / Claro / Oscuro). Se elige en Ajustes → Apariencia y se recuerda en el dispositivo. "Automático" sigue el tema del teléfono. Se aplica antes de pintar (sin parpadeo blanco).
- **Botón "ir al final"** en el chat: aparece al subir y baja suave al último mensaje.
- **Áreas táctiles de 44 px** en lo que faltaba (Ajustes cerrar, Actualizar, buscar chats, cámara).
- **Vibración sutil** al enviar y al crear chat (solo móviles compatibles).
- Colores del diseño pasados a tokens (un solo lugar para cambiar la paleta).
- v50 intacto: chat, Agent, finanzas, navegador y límites no se tocaron (verificado byte a byte).

Revertir v52/v51: borrar `<script id="g51-themeboot">`, `<style id="codegot-v51-google">`, `<script id="codegot-v51-pro-js">` y `id="g51"` de `<html>`.
