# CodeGot v76 — Free ≈10 s y Flash ≈0,5 s (sobre v75)

## Code Free (≈10 s)
- El texto de la respuesta NO aparece antes de 10 s desde el envío (el modelo trabaja de inmediato con razonamiento alto, pero el texto se retiene hasta cumplir el plazo; si el modelo tarda más de 10 s, sale cuando termine).
- Después se escribe a ~18 caracteres/s. Se quitó la espera aleatoria de v75.

## Code súper Flash (objetivo ≈0,5 s)
- Predicción mientras se escribe: tras una pausa de 0,6 s en el cuadro de texto, Flash ya genera la respuesta del texto actual. Si el usuario envía exactamente eso (primer mensaje del chat), se muestra al instante; si aún está en vuelo, se espera hasta 2,5 s esa misma petición.
- Los dos modelos rápidos salen a la vez (refuerzo a 1 ms).
- Caché: 24 h y hasta 150 preguntas (antes 6 h / 40).
- Se mantienen atajos locales, conexión caliente, 300 tokens, historial de 4 y ≤25 palabras.
- Nota: la predicción hace llamadas extra a la API mientras se escribe.
## Revertir: zip v75.
