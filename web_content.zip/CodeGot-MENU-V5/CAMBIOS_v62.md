# CodeGot v62 — Chat sobrio, sin "LED" (sobre v61)

Solo CSS (bloque `codegot-v62-clean` al final).

## Quitado
- Punto de colores que pulsaba al final del texto mientras la IA escribe.
- En "Pensando": aro-cometa giratorio, resplandor pulsante y línea de degradado inferior.

## Se conserva
Logo, texto "Pensando…" con su relevo, fundido de letras (v61) y todo el formato de las respuestas.

## Revertir
Borrar el bloque `<style id="codegot-v62-clean">`.
