# CodeGot v72 — Free en 8 s, Free 100/día y cambio de motor al agotarse (sobre v71)

- Code Free: tope duro de 8 s. A los 8 s con texto → se corta y termina; sin texto → se cancela y avisa «no alcanzó a responder en 8 s» (botón de reintentar). Refuerzo a los 1,2 s, tope de salida ~700 tokens salvo pedidos largos/código.
- Límites diarios por usuario y motor: Code Free 100, Code súper Flash 25, Code Cerebrot 25 (se reinician a medianoche).
- Motor agotado: aparece un cuadro que pide elegir otro motor disponible (con cuántos mensajes le quedan en cada uno).
- Nueva casilla en el menú de motores (^): «Cambiar automáticamente a un motor disponible». Si está activa, al agotarse el motor el sistema pasa solo a uno con mensajes disponibles y envía el mensaje sin preguntar. También está en el cuadro de motor agotado.
- El menú de motores muestra «Te quedan N de M hoy» / «Agotado hoy» en cada motor.
## Revertir: zip v71.
