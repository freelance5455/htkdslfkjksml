# CodeGot v98 — Botón de enviar profesional + animación del agente un poco más rápida (sobre v97)

## Botón de enviar (chat y editor de apps)
- Con texto escrito: botón circular sólido (negro en tema claro, blanco en oscuro), flecha hacia arriba más firme y elevación sutil neutra. Sin degradados de colores ni brillos.
- Sin texto o mientras el agente trabaja: botón apagado vainilla (gris cálido) con borde fino, para que se vea claramente inactivo.
- Chat y editor ahora usan el mismo diseño y la misma flecha. El del editor baja de 54 px a 48 px para quedar proporcionado con la barra.
- Al tocar: una sola reducción suave (efecto táctil v95); antes se sumaban dos. Aro de foco visible y hover sutil.

## Animación del Súper agente: un poco más rápida que v97
- Entrada .55 s, anillo 1,9 s, estrella 2,6 s, brillo del título 3,2 s, punto activo 1,8 s, destello 2,4 s, barra y riel .9 s, pasos .5–.6 s, plegado .65 s. (v97 era ~40 % más lenta; la original, ~40 % más rápida.)

## No se tocó
- Lógica de chat y agente; tamaño del botón del chat; botón Detener.

## Revertir: zip v97 o borrar el bloque `codegot-v98-send` (y restaurar los tiempos de `codegot-v97-agent`).
## Versión: v98.
