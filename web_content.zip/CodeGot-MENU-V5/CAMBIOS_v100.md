# CodeGot v100b — Flash <1 s (refuerzo tras 13 s de demora) (optimización de latencia extrema, sobre v99)

## Objetivo
- **Code súper Flash**: primera respuesta (TTFT) en menos de 1 segundo para la mayoría de preguntas.
- **Code Cerebrot**: primera respuesta en menos de 2 segundos, manteniendo calidad de explicación.

## Optimizaciones Flash (motor súper rápido)
1. **Carrera más agresiva**: 3 modelos salen en t=0 (lite + flash + 3.6-flash). Relevos a 350 ms / 650 ms / 950 ms. Gana el primero que emite texto; el resto se cancela.
2. **Tokens de salida más bajos**: tope duro de 380 tokens (respuestas aún más cortas y rápidas de generar).
3. **Timeouts más estrictos**: firstByteMs 5,5 s · idle 9 s · máximo total 14 s (antes 25 s).
4. **Caché ampliada**: cualquier pregunta exacta (normalizada) se cachea 12 h, no solo el primer mensaje del chat. Se reutiliza aunque haya historial.
5. **Prefetch más temprano**: se dispara con pausa de escritura de 400 ms (antes ~600 ms).
6. **Local ampliado**: más saludos, «quién eres / quién te creó», conversiones simples de unidades y respuestas instantáneas adicionales.
7. **Indicador «Pensando»**: velocidad ×0,55 (más ágil) para que la UI no se sienta lenta mientras llega el primer token.

## Optimizaciones Cerebrot (profesor rápido)
1. **Nivel de razonamiento medio** (antes high): reduce mucho el tiempo de pensamiento interno del modelo sin perder la estructura de explicación.
2. **Carrera ligera de calidad**: se lanza en paralelo el modelo principal (medium) y un flash-lite de respaldo a los 280 ms; gana el primero que emite. Si el principal llega primero se usa; si no, el rápido con el mismo system prompt de profesor.
3. **Tope de tokens 1 100**: suficiente para la estructura completa (idea + analogía + pasos + ejemplo + prueba) sin generar de más.
4. **Historial recortado**: últimas 6 intervenciones de texto (antes más).
5. **Indicador «Pensando»**: velocidad ×1,05 (más rápido que v99) para alinear percepción con el objetivo <2 s.

## Qué no se tocó
- Reglas de exactitud, personalidad, tarjetas visuales de Cerebrot, límites diarios, Free, UI de burbujas v99, agente.

## Medición
- `cgFlashStats()` sigue disponible en consola (ttft_p50, bajo_1s %).
- Cerebrot no tiene stats propias; se mide con el cronómetro del indicador.

## Revertir
- Zip v99 o restaurar los bloques de carrera/prompt/thinkLevel y las CSS de --t3-spd.

## Versión: v100.


## v100b (corrección tras captura de 13 s)
- **4 modelos en paralelo desde t=0**: gemini-3.5-flash-lite, gemini-3.1-flash-lite, gemini-3.6-flash, gemini-2.5-flash-lite.
- **Thinking siempre minimal** en Flash (antes podía subir a low y sumar segundos).
- **Prompt Flash ~60 % más corto**.
- **Tope de salida 320 tokens**.
- Fallbacks ampliados (3.1-lite, 2.5-lite, 3.8-flash).
- «Tarda más de lo normal» aparece más tarde (no a los ~5–6 s).
- maxMs 18 s para no cortar carreras lentas de red.

Nota: 1 s exacto depende de la red y de la carga de la API de Google. Con la carrera de 4 modelos y thinking minimal se maximiza la probabilidad de TTFT bajo 1 s en condiciones normales.
