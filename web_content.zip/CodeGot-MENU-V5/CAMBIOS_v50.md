# CodeGot v50 — Súper agente: animación premium + edición sin límites (sobre v49)

## Animación (todas las fases son reales, 0 simulación)
- Nueva tarjeta de estado: marca animada (anillo + destello), fase actual con brillo, cronómetro, barra de progreso y 5 pasos (Analizar → Planificar → Escribir → Verificar → Aplicar).
- Muestra en vivo el archivo que escribe, sus líneas y la última línea de código generada.
- Al terminar la tarjeta se pliega en un resumen con ✓, tiempo y archivos cambiados (+líneas / −líneas).
- El velo sobre la vista previa usa la misma marca y un % de avance real (blur reducido: más fluido).
- Solo transform/opacity; respeta prefers-reduced-motion; nada corre en reposo.

## Capacidad del súper agente
- Parches <<<EDIT>>> (FIND/WITH): cambia solo lo necesario en archivos grandes (más rápido, sin cortes). Los archivos completos <<<FILE>>> siguen funcionando.
- Presupuesto de salida del editor: hasta 12 000 tokens (antes 6 500). Las demás funciones del Agent no cambian.
- Prueba de ejecución en segundo plano: abre la versión nueva en un iframe oculto, pulsa sus botones y recoge errores reales de JavaScript / pantalla en blanco.
- Autocorrección: si el cambio no se puede aplicar o da errores al ejecutarse, el agente se corrige solo (hasta 3 intentos) con el error real como pista. Si no lo logra, la app queda igual y no se descuenta del límite de 10.
- Al enviar, el modelo recibe los errores de ejecución de la app actual (útil para "haz que funcione de verdad").
- Nuevas instrucciones de ingeniería y diseño (lógica completa, casos límite, accesibilidad, móvil primero, sin red).
- Vista previa: localStorage/sessionStorage funcionan en memoria (antes lanzaban error en el iframe aislado) y se permite eval (las calculadoras lo usan); el iframe sigue aislado y sin red.
- Sugerencias nuevas: "Que funcione de verdad", "Más profesional", "Modo oscuro", "Cambiar colores".

No se tocó: chat, navegador, finanzas, descanso de IA, límite de 10 modificaciones/4 h ni la sesión del Agent.
