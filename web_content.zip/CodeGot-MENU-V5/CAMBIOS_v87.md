# CodeGot v87 — Cerebrot lanza tarjetas en preguntas sobre temas (sobre v86)

## Code Cerebrot · tarjetas del tema
- Antes: las tarjetas de imagen (Wikipedia / Commons) solo salían si el mensaje tenía verbos de aprender/enseñar (explícame, ayúdame, enséñame, define, describe…).
- Ahora: también salen cuando la pregunta permite extraer un tema claro (qué es…, cómo funciona…, háblame de…, información sobre…, quién es…, etc.), usando la misma lógica de `topicFromQuestion`.
- Sigue siendo exclusivo de Cerebrot (Free y Flash no muestran tarjetas nuevas).
- Saludos, frases sueltas y temas de negocio siguen sin tarjeta (igual que antes).

## Versión visible: v87. Revertir: zip v86.
