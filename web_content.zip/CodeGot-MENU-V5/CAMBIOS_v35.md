# CodeGot v35 — cambios
- Prompt de sistema: nueva regla 14 FLUIDEZ → dato clave en la primera línea, sin intros, frases cortas, párrafos de 1–3 líneas, guiones simples para listas y código/pasos en bloques pequeños.
- Respeta el resto de reglas (modo estricto, texto plano, español).
- Archivos: `original.html` y `rebuild_nexus/zoe-nova-ia.html`.
