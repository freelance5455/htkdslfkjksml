# CodeGot v40 — barra lateral con la fluidez de Ajustes

## Problema
Al abrir la barra lateral de chats se veía lag (stutter). Ajustes abría limpio e instantáneo.

## Causas del lag (confirmadas en código)
1. **`backdrop-filter: blur(24px)`** en el propio `.sidebar` (CSS base) + **blur(10px)** en el scrim (`nexus-sidebar-blur`): re-desenfocaba el chat entero en cada cuadro del slide.
2. Apertura a **420 ms** (“sedoso”) del bloque extrema + cascada de 7 ítems con delays de hasta 150 ms.
3. Transiciones de box-shadow / filtros que forzaban repaint.

## Solución (igual principio que Ajustes)
Ajustes (`#settingsScrim`) es un fade ~90–130 ms de una capa sólida, **sin blur**. Aplicamos lo mismo al sheet:

| Elemento | Antes | Ahora (v40) |
|----------|-------|-------------|
| Panel | blur + 300–420 ms | **sin blur**, transform **200 ms** `cubic-bezier(.22,1,.36,1)` |
| Scrim | blur + 260–400 ms | **sin blur**, opacity **180 ms** misma curva |
| Chats del historial | cascada 320 ms | **animation: none** |
| Gesto de soltar | 220–320 ms | **160–220 ms** |
| Base CSS | blur(24px) en `.sidebar` | **none** |

Solo `transform` / `opacity` (compositor). `contain: layout style paint`. Doble `#id` para ganar a todos los overrides anteriores.

Archivos: `rebuild_nexus/zoe-nova-ia.html` y `original.html` (idénticos).
