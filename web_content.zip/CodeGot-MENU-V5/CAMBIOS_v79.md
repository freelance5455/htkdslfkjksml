# CodeGot v79 — Free mucho más lento, tarjetas estables y límites con cambio de motor (sobre v78)

## Code Free (mucho más lento)
- Nada de texto antes de 20 s desde el envío (antes 10 s), en las dos capas (IA y pantalla). Constante ajustable: window.NX_FREE_HOLD_MS.
- Escritura en pantalla a ~8 caracteres/s (antes ~18).

## Cambiar de motor ya no altera las respuestas
- Las tarjetas (imágenes del tema) de Cerebrot ya no desaparecen al cambiar a Flash/Free, ni se agregan a mensajes viejos al volver a Cerebrot. Las tarjetas nuevas siguen saliendo solo con Cerebrot.

## Límites
- Si se acaba el límite de un motor (o de dos), se pasa automáticamente a un motor con mensajes disponibles y el mensaje se envía igual (aviso breve).
- Solo si se agotan los TRES motores: recarga de 2 horas con el aviso de recarga; al terminar, los tres motores recuperan todos sus mensajes.
## Revertir: zip v78.
