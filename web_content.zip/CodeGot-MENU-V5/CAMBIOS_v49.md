# CodeGot v49 — movimiento premium en toda la app (sobre v48)
Hallazgo: TODA la app (menús, modales, botones, toasts, topbar…) usaba una curva simétrica de 270 ms (.45,.05,.55,.95), también al PRESIONAR. Esa curva arranca lenta: el toque se sentía con retraso y todo "tardaba en despertar".
- Al tocar (:active): cada componente usa su respuesta rápida original. Medido en el botón de menú: antes tardaba ~240 ms en hundirse (con 70 ms sin moverse); ahora llega a su posición en ~36 ms.
- Al soltar / abrir / cerrar: todo fluye con la curva del chat cubic-bezier(.22,1,.36,1) a 360 ms (arranca al instante y se asienta largo, como agua). Antes arrancaba lento.
- El observador global de animaciones ahora hace 1 barrido por cuadro (antes 1 por cada cambio de clase/estilo, forzando recálculo de estilos).
- touch-action:manipulation: sin espera ni zoom accidental por doble toque en botones.
- Imágenes: decodificación asíncrona (sin tirones al aparecer en las respuestas).
- No se tocó: filas de la IA (fluidez igual), barra lateral (v48), navegador privado ni Agent, ni el diseño.
