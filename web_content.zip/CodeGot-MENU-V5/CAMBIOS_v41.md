# CodeGot v41 — causa del lag LOCALIZADA y eliminada

## Problema
La barra lateral seguía laggeada aunque v38–v40 intentaban anular estilos.

## Causa raíz (encontrada)
El bloque `<style id="waterFlowStyle">` (líneas ~9155) imponía:

```css
.sidebar { transition: transform 560ms, box-shadow 560ms !important; }
.scrim   { transition: opacity 480ms !important; }
.recent-item:nth-child(1..8) { animation: wtItemIn 600ms + delay hasta 405ms !important; }
```

Eso re-pintaba box-shadow en cada cuadro y animaba 8 ítems en cascada.
Los overrides posteriores no siempre ganaban del todo en WebView Android.

## Fix v41
1. **Eliminadas** las reglas de sidebar/scrim/recent-item de `waterFlowStyle` (no solo anuladas).
2. **Eliminados** los `animation-delay` del bloque extrema.
3. **`nx-ultrafast-css`** ahora excluye `#sidebar` y `#scrim` explícitamente.
4. Una sola regla limpia al final (`nexus-v41-sidebar-clean`):
   - Panel: `transform` 180 ms, curva del chat, **sin blur**, **sin box-shadow animado**
   - Scrim: `opacity` 160 ms, **sin blur**
   - Historial: `animation: none` total
   - Sin `will-change` permanente ni `contain: paint`
5. Gesto de soltar: 140–200 ms.

Resultado: misma sensación limpia e instantánea que Ajustes.
