# CodeGot v56 — Capa PREMIUM (sobre v55)

Auditoría del chat, la barra lateral, los ajustes y el Agent, y una capa de diseño única (`<style id="codegot-v56-premium">`). Solo estilos: la lógica no se tocó.

- **Portada**: aurora suave de marca detrás del saludo, orbe con aro degradado y profundidad, entrada escalonada (orbe → título → subtítulo → tarjetas), tarjetas que se elevan al tocar.
- **Barra superior**: botón Agent con aro degradado y avatar con anillo de marca.
- **Compositor**: al escribir aparece un aro azul con sombra suave; el botón enviar pasa a degradado cuando hay texto.
- **Mensajes**: la IA ahora ocupa todo el ancho (antes quedaba estrecha) con su marca en un círculo con aro degradado; viñetas de color, citas con barra violeta, bloques de código con tarjeta, tablas redondeadas, enlaces con subrayado animado. Tus mensajes con burbuja tonal más fina. Cada mensaje entra con un fundido corto.
- **Barra lateral**: fondo tonal, ítem activo con brillo de marca, anillo en el avatar y botón Actualizar con aro degradado.
- **Diálogos y avisos**: entrada con rebote suave y sombras con profundidad.
- **Lectura en pantallas grandes**: columna centrada de 760 px.
- Claro y oscuro con los mismos tokens; transiciones solo de transform/opacity, sin blur en tiempo real y sin animaciones infinitas; respeta "reducir movimiento".

Nota técnica: el script del v51 recoloca su hoja al final, por eso este bloque usa un prefijo con mayor especificidad (`html#g51:root:root:root body`).

Revertir: borrar el bloque `codegot-v56-premium`.
