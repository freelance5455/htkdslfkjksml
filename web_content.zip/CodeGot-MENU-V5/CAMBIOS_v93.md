# CodeGot v93 — Límite de peticiones (429), mensajes limpios y sesión obligatoria (sobre v92)

## 1. Límite de peticiones (429)
- Mensaje único y amable: «El servidor está recibiendo muchas consultas en este momento. Por favor, reintenta tu mensaje en un minuto.»
- Reintento silencioso con espera exponencial (~3 s y ~6 s; respeta el tiempo que indique la API, máx. 10 s). Primero prueba los otros modelos al instante; si todos están limitados, espera y vuelve a empezar. Solo después se muestra el aviso.
- Aplica a chat normal, modo Flash, Agent y títulos. Si el usuario pulsa detener, la espera se cancela.

## 2. Mensajes sin jerga técnica
- Ya no aparecen «tokens», «modelo alternativo», «Gemini», claves de API ni códigos HTTP. El detalle técnico va solo a la consola del navegador.
- Red de seguridad en el chat: cualquier error con esas palabras se cambia por un aviso genérico.

## 3. Sesión obligatoria
- Cerrar sesión, borrar la cuenta activa o borrar la última cuenta bloquea la app al instante y exige crear cuenta o iniciar sesión (antes, borrar la cuenta activa no recargaba ni bloqueaba bien).
- Sin sesión, tocar una cuenta de la lista ya no entra directo: abre «Iniciar sesión» con el correo puesto y pide la contraseña.

## Versión visible: v93. Revertir: zip v92.
