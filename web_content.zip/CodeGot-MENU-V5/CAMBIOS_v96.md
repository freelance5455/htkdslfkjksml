# CodeGot v96 — Pregunta y respuesta en tarjetas profesionales (sobre v95)

- Cada respuesta de la IA va dentro de una tarjeta: borde fino vainilla, esquinas de 20 px, cabecera con el logo y la etiqueta «CodeGot», línea divisoria y el texto debajo a todo el ancho (antes quedaba sangrado 44 px por el logo).
- Cada pregunta del usuario va en su tarjeta (alineada a la derecha, máx. 86 %) con la etiqueta «TÚ» y la misma línea divisoria.
- Tema claro: respuesta en vainilla casi blanco, pregunta en vainilla un tono más oscuro. Tema oscuro: tarjetas negras con borde gris fino. Sin brillos ni degradados.
- Los botones (Copiar, Me gusta…) siguen debajo de cada tarjeta, igual que antes.
- Solo CSS (bloque `codegot-v96-cards`); no se tocó la lógica. Revertir: borrar ese bloque o usar el zip v95.

## Versión: v96.
