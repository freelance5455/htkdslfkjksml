# CodeGot v95 — Chat fluido, táctil inmediato y vainilla más fino (sobre v94)

## Fluidez
- Antes, al abrir un chat TODOS los mensajes repetían una animación de 460 ms (una regla de v7x la forzaba con !important). Ahora solo se animan los 2 últimos (200 ms, opacidad + 8 px). El resto aparece al instante.
- Quitado el desenfoque (blur) permanente de la barra superior, la zona de escribir y los mensajes: era lo que más cuesta al desplazar el chat en el móvil. Ahora son fondos vainilla sólidos (negro en tema oscuro); mismo aspecto.
- Respuestas largas (código): el tramo en curso se repinta como máximo cada 60–120 ms en lugar de cada cuadro. El último texto siempre se pinta y el texto final no se pisa. (Cambio en `nxStreamRender` / `nxFinalText`; solo actúa cuando el tramo supera 1.500 caracteres.)

## Táctil
- Nuevo script `codegot-v95-touch`: el botón se hunde en el mismo instante del toque (antes `:active` esperaba ~100 ms dentro de zonas con scroll) y vuelve con un rebote suave al soltar. Se cancela solo si el dedo se arrastra (scroll). Botones redondos y acciones del mensaje se hunden más (.88), filas de lista casi nada (.985).
- Respeta «reducir movimiento» del sistema.

## Color
- Burbuja del usuario con un filo sutil vainilla, bloques de código sin sombra pesada, cursor del campo de texto del color del botón (negro en claro, blanco en oscuro).

## Qué NO se tocó
- Lógica de chat, motores, cuentas, límites, plan Pro, posiciones de botones.
- `content-visibility` sigue desactivado a propósito (v73: dejaba mensajes vacíos en algunos WebView).

## Revertir
- Zip v94, o borrar el bloque `codegot-v95-fluid` y el script `codegot-v95-touch`, y restaurar `nxStreamRender` / `nxFinalText` (marcados «v95»).

## Versión: v95.
