# CodeGot v36 — optimización Compose (rendimiento)

Revisión de los 15 archivos de `compose/`. La base ya aplicaba: `@Immutable/@Stable`, `key` + `contentType` en LazyColumn/LazyRow,
lecturas diferidas en `graphicsLayer`, springs hoisteados y estado derivado (`canSend`). Se corrigió lo que faltaba:

1. **Main thread → IO**
   - `Context.toAttachment` ahora es `suspend` y corre en `Dispatchers.IO` (antes `getType`/`query` del ContentResolver podían bloquear Main).
   - Nuevo `toAttachments(uris)` (un solo cambio de contexto) y `rememberAttachmentPicker(composer)` (`AttachmentPicker.kt`).
   - `collectBatched` aplica `flowOn(Dispatchers.IO)` al flujo de origen (red/SSE/JSON); acumulación y `onText` siguen en Main.
2. **Recomposición / re-maquetado**
   - `ChatMessageBubble`: el texto se divide por párrafos; los cerrados mantienen el mismo String y se saltan → durante el streaming solo se mide el último párrafo, no todo el mensaje.
   - `ChatMessageList`: `contentType` por (usuario/IA × con/sin adjuntos) → mejor reciclaje.
3. **Animaciones**
   - `NexusThinkingIndicator`: 3 relojes infinitos en vez de 4 (onda y brillo comparten reloj de 16 s); `Stroke` y lista de colores hoisteados → cero asignaciones por cuadro.

No se tocó el aspecto visual. Sin compilar en este entorno (no hay SDK de Android): compilar y probar en dispositivo.
La vista previa del Agent es HTML/WebView, no Compose; no se modificó en esta pasada.
