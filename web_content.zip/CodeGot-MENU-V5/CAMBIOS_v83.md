# CodeGot v83 — Mismos cambios de v82, ahora también en original.html (sobre v82)

- Los cambios de v82 (límite global de 1,000 mensajes entre los 3 motores, arreglo del chat del editor e icono «C» nuevo) solo estaban en rebuild_nexus/zoe-nova-ia.html; original.html seguía con el contenido viejo. Ahora los dos archivos son idénticos.
- Chat del editor: además del CSS, cada mensaje se crea con flex-shrink:0 y height:auto, así no se encoge ni se monta sobre otro.
- Versión visible: la tarjeta «IA recargándose» dice «N/1000 mensajes hoy · v83» y la consola muestra «CodeGot build v83».
## Revertir: zip v82.
