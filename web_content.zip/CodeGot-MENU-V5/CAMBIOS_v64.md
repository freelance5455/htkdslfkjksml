# CodeGot v64 — "Pensando" rediseñado + renombre CodeGPT → CodeGot (sobre v63)

## Animación de pensamiento (solo cuando la IA prepara la respuesta)
- **Logo real que respira**: el logo de la app con una escala suave (2.4 s), en vez del cuadro liso.
- **Puntos en onda líquida** junto a la frase (reemplazan los "..." que aparecían a saltos).
- **Pasos con indicadores**: tres marcas bajo el nombre; la activa se alarga y las anteriores quedan rellenas, así se ve que avanza (Pensando → Analizando → Preparando).
- **Frase activa con brillo suave**; las frases ocultas ya no animan (menos trabajo para el teléfono).
- **Entrada con resorte** y cronómetro con la misma curva suave.
- Solo `opacity`/`transform` (compositor). Sin aros, resplandores ni barras: se mantiene el estilo sobrio de v62. Pausa en segundo plano y respeta "reducir movimiento".

## Nombre
- CodeGPT → **CodeGot** en HTML (textos visibles, ids, clases, variables CSS), Kotlin y documentos.
- Se **conservaron** las claves de almacenamiento `codegpt_theme_v52` y `codegpt_topic_img` a propósito: así nadie pierde su tema guardado ni la caché de imágenes. Son internas y no se ven.
- El icono (PNG incrustado) no contiene texto, no cambia.

## Tocado
`showTyping()` (HTML del indicador + actualización de pasos) y el bloque nuevo `<style id="codegot-v64-think">` al final.

## Revertir la animación
Borrar `<style id="codegot-v64-think">` y restaurar `showTyping()` de v63.

## Probado
Sintaxis de todos los scripts sin errores. No pude abrirla en un navegador real aquí: pruébala en el teléfono.
