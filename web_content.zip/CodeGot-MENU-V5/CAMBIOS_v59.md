# CodeGot v59 — "Editar app" rediseñado (sobre v58)

Misma paleta, tokens y formas del chat (claro y oscuro):
- **Vista en vivo** como tarjeta con sombra, barra "● Vista en vivo", botón **Recargar** y botón **Ampliar** la vista (44 % ↔ 68 %).
- **Hoja de chat** con esquinas redondeadas y agarrador, que sube sobre la vista.
- **Contador** con ícono de rayo y barra de progreso en degradado (se pone rojo al acercarse a 10).
- **Mensajes**: los tuyos en burbuja tonal; los de la IA sin burbuja, con la marca en círculo de aro degradado y con formato (negritas, listas, código).
- **Sugerencias** en tarjetas 2×2 con ícono de color, como las del inicio.
- **Compositor** igual al del chat: aro azul al escribir, botón enviar gris sin texto y degradado con texto. Placeholder más corto ("Pide un cambio…").
- Texto de bienvenida más claro. Pantallas anchas conservan el diseño lado a lado.

Tocado: bloque `codegot-v59-editor` al final y 4 parches pequeños en el script del Agent (`edMsg`, `edCountSync`, barra de la vista, bienvenida). Lógica de edición y límite de 10 al día intactas.

Revertir: borrar el bloque `codegot-v59-editor` y los parches mencionados.
