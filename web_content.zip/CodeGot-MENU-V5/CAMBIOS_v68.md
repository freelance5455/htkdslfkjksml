# CodeGot v68 — Code súper Flash optimizado (sobre v67)

Solo se toca el motor **Code súper Flash**. Free y Cerebrot no cambian.

## Qué se optimizó
1. **Respuestas locales instantáneas (0 ms, exactas)**: "qué hora es", "qué día es hoy" (con el reloj del dispositivo) y cálculos simples ("12*8", "cuánto es 7 más 8", "15% de 240", "raíz cuadrada de 144"). No se llama al modelo, así que no pueden fallar ni tardar. Si el cálculo es ambiguo (p. ej. "1.000+5", "10-12") se lo deja al modelo.
2. **Sin viaje extra de red (preflight CORS)**: cada petición normal a Gemini obliga al navegador a hacer una consulta previa (OPTIONS). Flash ahora usa una petición "simple" que la evita. Se activa sola solo si una prueba única en segundo plano confirma que el servidor la acepta; si algo falla, vuelve a la forma normal sin que el usuario lo note.
3. **Conexión precalentada**: al abrir la app, al cambiar a Flash y al tocar el cuadro de texto se mantiene viva la conexión con Google, para que al enviar no se pierda tiempo en conectar.
4. **Prompt compacto** (~900 caracteres en vez de ~5000): mismas reglas esenciales (exactitud, formato, idioma, confidencialidad) con tope duro de **1-2 frases / 40 palabras** salvo que el usuario pida más. Menos texto que generar = respuesta completa más rápida. La personalidad "muy cálida" larga ya no se envía en Flash.
5. **Razonamiento adaptativo**: 'minimal' por defecto; 'low' si la pregunta tiene números, cálculo, lógica o código (para responder bien y no solo rápido).
6. **Historial recortado** a los últimos 8 mensajes en Flash (solo si todo es texto; con imágenes/archivos se envía completo).
7. **Nivel de razonamiento no soportado**: ahora se recuerda por modelo durante 24 h (antes se perdía al cerrar y cada sesión pagaba un reintento).
8. **Medición**: `cgFlashStats()` (consola del navegador) muestra tiempo hasta el primer texto (p50 / p90), % de respuestas bajo 1 s y las últimas 8. También queda en `localStorage.cg_flash_stats`.

## Tocado
`nxRaceFast` (reescrita), `callOpenAI` (petición simple + niveles por modelo), `nexusAskOpenAI` (rama Flash), nuevas `nxFlashLocal`, `nxFlashSystem`, `nxFlashHistory`, `nxNeedsThought`, `nxFlashWarm`, `nxProbeSimple`, `nxBadLv`, y el bloque `<script id="codegot-v68-flash-js">` al final.

## Revertir
Usar `CAMBIOS_v67` / el zip v67.

## Probado (Node + servidor simulado, sin la API real)
- 31 casos de cálculo/hora/fecha correctos, incluidos los ambiguos que deben ir al modelo.
- Petición normal, petición simple, servidor que rechaza la simple (vuelve a la normal y lo recuerda), modelo que no admite 'minimal' (reintenta una vez y lo recuerda), y refuerzo del 2.º modelo a los 350 ms cuando el 1.º es lento.
- Sintaxis de los 18 scripts sin errores.

## Límite honesto
Con la API real **no puedo garantizar** "siempre < 1 s": depende de Google y de tu internet (con mala señal, la conexión sola puede pasar de 1 s). Lo que sí queda garantizado: hora/fecha/cálculos en 0 ms, y para el resto se quitó todo el retraso evitable. Mide en tu teléfono/PC con `cgFlashStats()` y, si el p90 queda sobre 1000 ms, se ajustan los modelos o el tiempo de refuerzo con esos datos reales.
