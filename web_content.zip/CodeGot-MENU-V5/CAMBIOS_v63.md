# CodeGot v63 — Rebrand + Fluid Design Overhaul

## Cambios principales
- **Nombre**: CoreGPT → CodeGot en todo el proyecto (HTML, títulos, CSS ids, Kotlin, docs).
- **Icono**: Reemplazado favicon, apple-touch-icon y logo principal (`--cg-logo`) por el nuevo icono de carita teal con ojos grandes.
- **Logo CSS**: Cambiado de mask monocromo a `background-image` a color para que se vea el icono completo y a color en avatares / hero.
- **Diseño general del chat**:
  - Nueva identidad de color teal (`#53AFA4`) derivada del icono.
  - Bordes más suaves y consistentes (18px en burbujas).
  - Sombras más sutiles y orgánicas.
  - Focus rings y hover states en teal.
  - Scrollbar personalizado suave.
- **Animaciones 100% fluidas "como el agua"**:
  - Easings rediseñados a curvas más orgánicas (`cubic-bezier(0.22, 1, 0.36, 1)`, spring suave).
  - Entrada de burbujas más lenta y con blur ligero que se disuelve (340ms).
  - Transiciones globales suavizadas.
  - Bounce de typing más líquido.
  - Ambient float más gentil.
  - Micro-interacciones en botones (scale + color).
  - will-change y transform3d para GPU.
- Se respetan las preferencias de reduced-motion existentes.

## Archivos tocados
- `rebuild_nexus/zoe-nova-ia.html` (y sincronizado `original.html`)
- Todos los `.kt` y `.md` (renombre de marca)
- Nuevo bloque `<style id="codegot-v63-fluid">`

## Cómo revertir el estilo
Borrar el bloque `<style id="codegot-v63-fluid">`.
