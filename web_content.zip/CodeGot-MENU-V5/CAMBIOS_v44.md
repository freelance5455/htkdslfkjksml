# CodeGot v44 — más agua

Curva `cubic-bezier(.12,1,.28,1)` · panel 360 ms + opacity suave · scrim 320 ms.
Sensación de emerger del borde, aterrizaje más largo y líquido.
