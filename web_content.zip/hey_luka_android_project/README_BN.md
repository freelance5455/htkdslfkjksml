# হে লুকা — Android প্রজেক্ট

এটি একটি starter project, সম্পূর্ণ unrestricted phone-control assistant নয়।

## যা আছে
- বাংলা HTML ইন্টারফেস
- Android SpeechRecognizer দিয়ে বাংলা voice-to-text
- Gemini API text chat
- Home screen button
- Flashlight button (Camera permission লাগতে পারে)
- WhatsApp message compose/draft (ব্যবহারকারীকে নিজে Send চাপতে হবে)
- Accessibility Service-এর নিরাপদ skeleton

## সীমাবদ্ধতা
- লক স্ক্রিনে সব সময় “হে লুকা” শুনে জেগে ওঠা এই সংস্করণে নেই।
- HTML/APK একা Android-এর সব permission পেতে পারে না।
- Accessibility service Settings থেকে ব্যবহারকারীকে নিজে enable করতে হবে; এই skeleton নিজে থেকে স্ক্রিনে ক্লিক করে না।
- API key APK-তে নিরাপদ নয়। ব্যক্তিগত পরীক্ষার বাইরে server-side proxy/Firebase AI Logic ব্যবহার করুন।
- APK বানাতে সাধারণত কম্পিউটারে Android Studio/Gradle লাগে। শুধু ফোনে ZIP খুললেই APK হবে না।

## কম্পিউটারে APK বানানো
1. Android Studio ইনস্টল করুন।
2. ZIP extract করুন।
3. Android Studio → Open → `hey_luka_android_project` ফোল্ডার নির্বাচন করুন।
4. Gradle sync শেষ হতে দিন।
5. Build → Build APK(s)।
6. `app/build/outputs/apk/debug/app-debug.apk` ফোনে কপি করে ইনস্টল করুন।
7. অ্যাপের প্রয়োজনীয় permission দিন।

অ্যাপ খুলে Gemini API key লিখুন। এই starter key স্থায়ীভাবে ফাইলে রাখে না।
