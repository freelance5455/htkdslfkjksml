package com.example.heyluka;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.net.URLEncoder;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private WebView webView;
    private boolean torchOn = false;
    private static final int SPEECH_REQUEST = 101;
    private static final int CAMERA_REQUEST = 102;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new LukaBridge(), "LukaAndroid");
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class LukaBridge {
        @JavascriptInterface public void startVoice() {
            runOnUiThread(() -> {
                Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD");
                i.putExtra(RecognizerIntent.EXTRA_PROMPT, "হে লুকাকে নির্দেশ দিন");
                try { startActivityForResult(i, SPEECH_REQUEST); }
                catch (Exception e) { Toast.makeText(MainActivity.this, "Voice recognition চালু করা যায়নি।", Toast.LENGTH_LONG).show(); }
            });
        }
        @JavascriptInterface public void goHome() {
            runOnUiThread(() -> startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)));
        }
        @JavascriptInterface public void toggleFlash() {
            runOnUiThread(() -> {
                if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_REQUEST);
                    Toast.makeText(MainActivity.this, "Camera permission দিন, তারপর আবার চাপুন।", Toast.LENGTH_LONG).show();
                    return;
                }
                try {
                    CameraManager cm = (CameraManager)getSystemService(CAMERA_SERVICE);
                    String found = null;
                    for (String id : cm.getCameraIdList()) {
                        Boolean has = cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                        if (Boolean.TRUE.equals(has)) { found = id; break; }
                    }
                    if (found == null) { Toast.makeText(MainActivity.this, "ফ্ল্যাশলাইট পাওয়া যায়নি।", Toast.LENGTH_SHORT).show(); return; }
                    torchOn = !torchOn;
                    cm.setTorchMode(found, torchOn);
                    webView.evaluateJavascript("window.onLukaFlashResult && window.onLukaFlashResult(" + torchOn + ")", null);
                } catch (Exception e) { Toast.makeText(MainActivity.this, "ফ্ল্যাশলাইট চালু করা যায়নি।", Toast.LENGTH_LONG).show(); }
            });
        }
        @JavascriptInterface public void openWhatsAppDraft(String phone, String message) {
            runOnUiThread(() -> {
                try {
                    String digits = phone.replaceAll("[^0-9]", "");
                    String encoded = URLEncoder.encode(message, "UTF-8");
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + digits + "?text=" + encoded)));
                } catch (Exception e) { Toast.makeText(MainActivity.this, "WhatsApp খোলা যায়নি।", Toast.LENGTH_LONG).show(); }
            });
        }
        @JavascriptInterface public void openPackage(String packageName) {
            runOnUiThread(() -> {
                Intent i = getPackageManager().getLaunchIntentForPackage(packageName);
                if (i != null) startActivity(i);
                else Toast.makeText(MainActivity.this, "অ্যাপটি ইনস্টল করা নেই।", Toast.LENGTH_SHORT).show();
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SPEECH_REQUEST) {
            String result = "";
            if (resultCode == RESULT_OK && data != null) {
                ArrayList<String> list = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if (list != null && !list.isEmpty()) result = list.get(0);
            }
            String safe = result.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ");
            webView.evaluateJavascript("window.onLukaVoiceResult && window.onLukaVoiceResult('" + safe + "')", null);
        }
    }
    @Override protected void onDestroy() {
        try {
            CameraManager cm = (CameraManager)getSystemService(CAMERA_SERVICE);
            for (String id : cm.getCameraIdList()) {
                if (Boolean.TRUE.equals(cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE))) cm.setTorchMode(id, false);
            }
        } catch (Exception ignored) {}
        if (webView != null) { webView.removeJavascriptInterface("LukaAndroid"); webView.destroy(); }
        super.onDestroy();
    }
}
