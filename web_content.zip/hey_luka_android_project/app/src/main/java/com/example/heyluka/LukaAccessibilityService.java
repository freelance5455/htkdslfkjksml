package com.example.heyluka;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;

/** নিরাপদ skeleton: ব্যবহারকারীর অনুমতি ছাড়া স্ক্রিন পড়ে বা স্বয়ংক্রিয় ক্লিক করে না। */
public class LukaAccessibilityService extends AccessibilityService {
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        // ভবিষ্যতে স্বচ্ছ ও ব্যবহারকারী-অনুমোদিত ফিচারের জন্য ভিত্তি।
    }
    @Override public void onInterrupt() {}
}
