// Verschlüsselung fürs Cloud-Backup: AES-256-GCM, Schlüssel wird per PBKDF2 aus dem
// Backup-Passwort abgeleitet. Passwort und Klartext verlassen den Browser nie -
// nur das verschlüsselte Ergebnis wird an den Worker gesendet.

const PBKDF2_ITERATIONS = 250000;

function bufToBase64(buffer) {
  let binary = '';
  const bytes = new Uint8Array(buffer);
  for (let i = 0; i < bytes.byteLength; i += 1) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

function base64ToBuf(base64) {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
  return bytes.buffer;
}

async function deriveKey(password, salt, usage) {
  const enc = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', salt, iterations: PBKDF2_ITERATIONS, hash: 'SHA-256' },
    keyMaterial,
    { name: 'AES-GCM', length: 256 },
    false,
    [usage]
  );
}

// Verschlüsselt ein beliebiges JSON-serialisierbares Objekt. Gibt ein Objekt zurück,
// das direkt als JSON an den Worker geschickt werden kann.
export async function encryptJSON(data, password) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const key = await deriveKey(password, salt, 'encrypt');
  const enc = new TextEncoder();
  const ciphertext = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, enc.encode(JSON.stringify(data)));
  return { v: 1, salt: bufToBase64(salt), iv: bufToBase64(iv), ciphertext: bufToBase64(ciphertext) };
}

// Entschlüsselt ein Objekt, das zuvor mit encryptJSON erzeugt wurde. Wirft einen Fehler,
// wenn das Passwort falsch ist oder die Daten beschädigt/manipuliert wurden (GCM prüft
// die Integrität automatisch mit).
export async function decryptJSON(payload, password) {
  if (!payload || typeof payload !== 'object' || !payload.salt || !payload.iv || !payload.ciphertext) {
    throw new Error('invalid-payload');
  }
  const salt = new Uint8Array(base64ToBuf(payload.salt));
  const iv = new Uint8Array(base64ToBuf(payload.iv));
  const key = await deriveKey(password, salt, 'decrypt');
  const ciphertext = base64ToBuf(payload.ciphertext);
  const plainBuffer = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, ciphertext);
  return JSON.parse(new TextDecoder().decode(plainBuffer));
}

export function makeBackupId() {
  if (crypto.randomUUID) return crypto.randomUUID();
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}-${Math.random().toString(36).slice(2, 12)}`;
}
