ANONYMOUX STUDIO 2.4.3 — PUBLIC ONBOARDING + LIP SYNC RELIABILITY PATCH
=========================================================================

Base archive: ANONYMOUX_STUDIOS_2.4.2_LANDING_LOGIN_SIGNUP.zip

PUBLIC VISITOR FLOW
- Kept onboarding.php as the public marketing landing page.
- Added onboarding-tour.php as a dedicated five-step workspace introduction.
- Landing-page Login and Sign Up actions now lead through the workspace tour before authentication.
- Workspace preview cards retain their intended destination and route through the tour.
- Tour includes five visual slides: Realtime Video Edit, AI Image Editing, AI Video Editing, AI Lip Sync, and the connected dashboard.
- Added Skip Intro, Back, Next, slide dots, keyboard navigation, swipe navigation, progress state, and reduced-motion support.
- Final Continue routes to the selected login or registration form while preserving the safe next destination.
- Authenticated visitors continue to their requested destination without being asked to authenticate again.
- Updated the sign-in/register cross-links so users can switch account paths through the tour.

RESPONSIVE DESIGN
- Desktop uses a wide image-and-copy composition.
- Mobile uses a tall cinematic preview with compact controls and safe-area spacing.
- Uses existing workspace preview assets and ANONYMOUX branding; does not copy Fuaprint branding.

LIP SYNC RELIABILITY
- Added authenticated server upload-limit discovery for PHP upload_max_filesize, post_max_size and application caps.
- Added client-side file-size preflight before a potentially oversized multipart upload.
- Anchored the Lip Sync API URL against document.baseURI for root and subdirectory deployments.
- Added a long upload timeout and no-cache request behavior.
- Added robust JSON parsing and actionable diagnostics for HTML/PHP error responses and generic browser fetch failures.
- Improved status polling response parsing.
- Added server-side execution-time handling for long media requests.
- Existing provider-side upload, job creation, status polling, output retrieval, idempotency and credit/refund logic retained.

SECURITY
- config.local.php is excluded from this distributable archive. Preserve the private config.local.php already present on an existing server when deploying this update.
- config.local.example.php remains available as a setup template.
- No API credentials are embedded in the new onboarding files.

VALIDATION
- PHP syntax checks: PASS (62 PHP files).
- JavaScript syntax checks: PASS (workspace scripts, tour script and existing onboarding script).
- ZIP integrity: checked after packaging.
- Live Magic Hour API requests, production PHP upload limits, mobile browser behavior, and provider rendering cannot be truthfully certified without the target host and provider account. The new diagnostics are designed to expose the exact server/provider response instead of hiding it behind a generic fetch message.
