Adidas2Strava - APKForge 1.0

IMPORTACIÓN
- Este ZIP contiene index.html en la raíz del proyecto.
- Importa el ZIP directamente en APKForge 1.0.
- No contiene Java, Gradle ni scripts de compilación.

FUNCIONES
- Formulario para probar el login.
- Campo opcional X-App-Key (no se proporciona una clave ficticia).
- Variable N configurable entre 1 y 200.
- Solicitud de listado y detalles de actividades mediante rutas históricas.
- Exportación de las respuestas recibidas a un JSON descargable.
- Diagnóstico HTTP y errores de red.

LIMITACIONES IMPORTANTES
Las rutas /webapps/services/auth/login, /webapps/services/runsessions/v3/sync y
/webapps/services/runsessions/v2/{id}/details proceden de un cliente histórico
no oficial de Runtastic. No son una API pública documentada y pueden haber dejado
de funcionar. La autenticación también puede requerir una X-App-Key vigente.
La app no contiene una clave de aplicación ni credenciales. El WebView de APKForge
puede bloquear peticiones por CORS o políticas de red. Un error Failed to fetch
no significa necesariamente que el email o contraseña sean incorrectos.
No se evitan MFA, CAPTCHA ni otros controles de acceso. No se integra Strava.

SEGURIDAD
La contraseña se borra del campo tras intentar el login. El token solo permanece
en memoria durante la sesión y no se guarda en localStorage. No compartas logs
que contengan datos privados.
