# Kingdoms of Emberfall — Android prototype
An original fantasy kingdom/base-building and raid prototype with realm upgrades, resource economy, troop recruitment, raids, quests, and local save progress.

## Play now
Open `app/src/main/assets/index.html` in a modern mobile or desktop browser.

## Build the Android APK
This environment has Java but no Android SDK, Gradle executable, or Android build tools, so it cannot compile the APK here. To build the APK, install Android Studio with Android SDK Platform 35 and JDK 17+, open this folder as a Gradle project, sync, then select **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Android Studio will create `app/build/outputs/apk/debug/app-debug.apk`.

Package: `com.emberfall.kingdomashes` • Minimum Android: 6.0 (API 23) • Version: 0.1.0
