import os
import zipfile
import shutil

# Ensure any nested zip inside android assets is removed
android_assets_zip = "android/app/src/main/assets/public/spr-project.zip"
if os.path.exists(android_assets_zip):
    os.remove(android_assets_zip)
    print("Removed unnecessary nested zip from android assets.")

# Verify mandatory Capacitor & Android files exist before zipping
required_files = [
    "android/app/capacitor.build.gradle",
    "android/capacitor.settings.gradle",
    "android/app/build.gradle",
    "android/settings.gradle",
    "android/variables.gradle",
    "android/gradle.properties",
    "android/app/src/main/AndroidManifest.xml",
    "android/app/src/main/java/com/sahil/spr3d/MainActivity.java",
    "android/app/src/main/assets/public/audio/spr_runner_theme.mp3",
    "android/app/src/main/assets/public/index.html",
    "public/audio/spr_runner_theme.mp3",
    "package.json",
    "package-lock.json",
    "capacitor.config.json"
]

for rf in required_files:
    if not os.path.exists(rf):
        raise FileNotFoundError(f"CRITICAL ERROR: Required file {rf} is missing before zipping!")

out_zip_name = "SPR_SwapLab_UNDER_50MB_READY.zip"
out_zip_paths = [
    out_zip_name,
    "public/" + out_zip_name,
    "public/spr-project.zip"
]
if os.path.exists("dist"):
    out_zip_paths.append("dist/" + out_zip_name)
    out_zip_paths.append("dist/spr-project.zip")

exclude_dirs = {
    'node_modules',
    '.git',
    '.aistudio',
    '.cache',
    'dev-dist',
    '.idea',
    '.gradle',
    'dist',
    'build'
}

exclude_extensions = {
    '.zip'
}

print("Creating SPR complete project ZIP archive...")

temp_zip = "spr-temp.zip"
with zipfile.ZipFile(temp_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
    for root, dirs, files in os.walk('.'):
        # filter directories in-place
        dirs[:] = [d for d in dirs if d not in exclude_dirs and not d.startswith('.')]
        
        for file in files:
            file_path = os.path.join(root, file)
            rel_path = os.path.relpath(file_path, '.')
            
            # Skip zip files and temp files
            if any(file.endswith(ext) for ext in exclude_extensions) or 'spr-temp' in file:
                continue
                
            zf.write(file_path, arcname=rel_path)

# Verify archive integrity and size limit
with zipfile.ZipFile(temp_zip, 'r') as zf:
    namelist = set(zf.namelist())
    for rf in required_files:
        if rf not in namelist:
            raise RuntimeError(f"VERIFICATION FAILED: {rf} was not packaged into ZIP!")
    # Verify NO nested zip inside android assets
    for name in namelist:
        if name.startswith("android/app/src/main/assets/public/") and name.endswith(".zip"):
            raise RuntimeError(f"VERIFICATION FAILED: Found nested zip {name} in android assets!")

final_size_mb = os.path.getsize(temp_zip) / (1024 * 1024)
print(f"Archive verified and written successfully. Size: {final_size_mb:.2f} MB")

if final_size_mb >= 50.0:
    raise RuntimeError(f"SIZE LIMIT EXCEEDED: Final ZIP is {final_size_mb:.2f} MB, which is >= 50 MB!")

for target in out_zip_paths:
    shutil.copyfile(temp_zip, target)
    print(f"Copied to {target}")

os.remove(temp_zip)
print(f"SUCCESS: {out_zip_name} packaging complete ({final_size_mb:.2f} MB) - STRICTLY UNDER 50 MB!")
