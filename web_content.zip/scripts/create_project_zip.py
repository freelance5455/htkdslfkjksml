#!/usr/bin/env python3
"""
JARVIS Project Exporter & ZIP Archiver
Creates an airtight, complete, standalone ZIP backup of the entire JARVIS codebase.
Excludes build caches (node_modules, dist, .git, .aistudio) while preserving all
source files, audio assets, Android APK wrapper files, documentation, and configs.
"""

import os
import sys
import zipfile
import hashlib
import shutil

ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUTPUT_ROOT_ZIP = os.path.join(ROOT_DIR, "Jarvis_Complete_Project.zip")
OUTPUT_PUBLIC_DIR = os.path.join(ROOT_DIR, "public")
OUTPUT_PUBLIC_ZIP = os.path.join(OUTPUT_PUBLIC_DIR, "Jarvis_Complete_Project.zip")

EXCLUDED_DIRS = {
    "node_modules",
    "dist",
    ".git",
    ".aistudio",
    ".jarvis_checkpoints",
    "__pycache__",
    ".turbo",
    ".cache",
}

EXCLUDED_FILES = {
    "Jarvis_Complete_Project.zip",
    ".DS_Store",
    "Thumbs.db",
}

def should_include(rel_path: str) -> bool:
    parts = rel_path.split(os.sep)
    for part in parts:
        if part in EXCLUDED_DIRS:
            return False
    filename = os.path.basename(rel_path)
    if filename in EXCLUDED_FILES:
        return False
    if filename.endswith(".pyc"):
        return False
    return True

def create_archive():
    print("=" * 65)
    print("JARVIS 2.0: CREATING COMPLETE PROJECT BACKUP ARCHIVE")
    print(f"Source Directory: {ROOT_DIR}")
    print("=" * 65)

    os.makedirs(OUTPUT_PUBLIC_DIR, exist_ok=True)

    # Remove previous zip archives if present
    for path in [OUTPUT_ROOT_ZIP, OUTPUT_PUBLIC_ZIP]:
        if os.path.exists(path):
            try:
                os.remove(path)
            except Exception:
                pass

    total_files = 0
    total_uncompressed_bytes = 0
    categories = {}

    with zipfile.ZipFile(OUTPUT_ROOT_ZIP, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zipf:
        for root, dirs, files in os.walk(ROOT_DIR):
            # Prune excluded directories
            dirs[:] = [d for d in dirs if d not in EXCLUDED_DIRS]

            for file in sorted(files):
                abs_path = os.path.join(root, file)
                rel_path = os.path.relpath(abs_path, ROOT_DIR)

                if not should_include(rel_path):
                    continue

                zipf.write(abs_path, rel_path)
                file_size = os.path.getsize(abs_path)
                total_files += 1
                total_uncompressed_bytes += file_size

                # Categorize for reporting
                category = rel_path.split(os.sep)[0]
                categories[category] = categories.get(category, 0) + 1

    # Also copy to public/ directory for instant browser HTTP download
    shutil.copyfile(OUTPUT_ROOT_ZIP, OUTPUT_PUBLIC_ZIP)

    compressed_size = os.path.getsize(OUTPUT_ROOT_ZIP)

    # Calculate SHA-256 Checksum
    hasher = hashlib.sha256()
    with open(OUTPUT_ROOT_ZIP, "rb") as f:
        while chunk := f.read(65536):
            hasher.update(chunk)
    checksum = hasher.hexdigest()

    print("\n✓ Project backup successfully generated!")
    print(f"Total Files Archived:       {total_files}")
    print(f"Uncompressed Total Size:    {total_uncompressed_bytes / (1024 * 1024):.2f} MB")
    print(f"Compressed Archive Size:    {compressed_size / (1024 * 1024):.2f} MB")
    print(f"SHA-256 Checksum:           {checksum}")
    print("\nBreakdown by Directory:")
    for cat, count in sorted(categories.items()):
        print(f"  • {cat}/: {count} files")

    print(f"\nArchives Saved to:")
    print(f"  1. {OUTPUT_ROOT_ZIP}")
    print(f"  2. {OUTPUT_PUBLIC_ZIP}")
    print("=" * 65)

if __name__ == "__main__":
    create_archive()
