#!/bin/bash
set -e

SRC="public/pwa-512x512.png"
RES="android/app/src/main/res"

echo "Using source: $SRC"

# Densities format: name:size:fg_size
densities=("mdpi:48:108" "hdpi:72:162" "xhdpi:96:216" "xxhdpi:144:324" "xxxhdpi:192:432")

for item in "${densities[@]}"; do
  IFS=":" read -r name size fg_size <<< "$item"
  dir="$RES/mipmap-$name"
  mkdir -p "$dir"

  # Standard launcher icon
  convert "$SRC" -resize "${size}x${size}^" -gravity center -extent "${size}x${size}" "$dir/ic_launcher.png"

  # Circular launcher icon
  radius=$((size / 2))
  convert "$SRC" -resize "${size}x${size}^" -gravity center -extent "${size}x${size}" \
    \( -size "${size}x${size}" xc:none -fill white -draw "circle $radius,$radius $radius,1" \) \
    -compose DstIn -composite "$dir/ic_launcher_round.png"

  # Adaptive icon foreground (72% inner size for Android adaptive icon safe zone)
  inner_size=$((fg_size * 72 / 100))
  convert "$SRC" -resize "${inner_size}x${inner_size}^" -gravity center -extent "${inner_size}x${inner_size}" \
    -background none -gravity center -extent "${fg_size}x${fg_size}" "$dir/ic_launcher_foreground.png"

  echo "Generated icons for $name ($size x $size, fg: $fg_size x $fg_size)"
done

# Also update web/PWA/public icons
convert "$SRC" -resize 192x192 public/pwa-192x192.png
convert "$SRC" -resize 512x512 public/pwa-512x512.png
# Maskable icon (80% safe zone with dark background)
convert "$SRC" -resize 410x410 -background "#0f172a" -gravity center -extent 512x512 public/pwa-maskable-512x512.png
convert "$SRC" -resize 180x180 public/apple-touch-icon.png
convert "$SRC" -resize 64x64 public/favicon.png

echo "All Android launcher and PWA icons generated successfully!"
