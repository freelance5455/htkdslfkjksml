import { mkdirSync, writeFileSync, rmSync } from "node:fs";
import { dirname, join } from "node:path";
import { execFileSync } from "node:child_process";

const root = "/workspace/android-src/Netzschild";

function w(rel, content) {
  const p = join(root, rel);
  mkdirSync(dirname(p), { recursive: true });
  writeFileSync(p, content.trimStart());
}

rmSync("/workspace/android-src", { recursive: true, force: true });

w(
  "README.txt",
  `Netzschild — Handy-Schutz
========================

Was die App tut
---------------
Netzschild läuft als sichtbarer Hintergrunddienst. Sie richtet ein lokales
VPN nur auf diesem Gerät ein (kein Fernzugriff, kein Account). Darüber sieht
sie jede Domain, bevor eine Verbindung aufgebaut wird.

Bei bekannten Betrugsseiten, Lookalikes (z. B. sparkasse-login-check.tk)
oder unsicheren Signalen erscheint eine Nachfrage:

  Blockieren  ·  Nur diesmal  ·  Immer vertrauen

HTTPS-Inhalte werden NICHT entschlüsselt. Geprüft werden DNS-Namen,
Zieladressen und Vertrauenssignale. Das ist der wirksame Weg gegen
gefälschte Websites, ohne den Datenverkehr mitzulesen.

APK erzeugen
------------
1. Android Studio installieren (kostenlos, developer.android.com).
2. „Open“ → diesen Ordner „Netzschild“ wählen.
3. Warten, bis Gradle fertig ist (erster Start dauert).
4. Handy per USB, USB-Debugging an — oder einen Emulator.
5. Menü Build → Build Bundle(s) / APK(s) → Build APK(s).

Die APK liegt danach unter:
  app/build/outputs/apk/debug/app-debug.apk

Zum Verteilen: Build → Generate Signed Bundle / APK.

Erste Schritte auf dem Handy
----------------------------
Die App fragt nacheinander:
  • Benachrichtigungen
  • VPN-Verbindung (systemeigener Android-Dialog)
  • optional Akku-Optimierung ignorieren, damit der Schutz nicht einschläft
  • optional Einblendung über anderen Apps für die Warnung

Solange Schutz aktiv ist, bleibt die Mitteilung „Netzschild aktiv“ sichtbar.
`,
);

w(
  "settings.gradle.kts",
  `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "Netzschild"
include(":app")
`,
);

w(
  "build.gradle.kts",
  `plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
`,
);

w(
  "gradle.properties",
  `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
kotlin.code.style=official
android.nonTransitiveRClass=true
`,
);

w(
  "gradle/wrapper/gradle-wrapper.properties",
  `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.7-bin.zip
networkTimeout=10000
validateDistributionUrl=true
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
`,
);

w(
  "app/build.gradle.kts",
  `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "de.netzschild.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "de.netzschild.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro",
            )
        }
    }

    buildFeatures {
        viewBinding = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.activity:activity-ktx:1.9.2")
}
`,
);

w("app/proguard-rules.pro", `# Netzschild — default keep\n`);

w(
  "app/src/main/AndroidManifest.xml",
  `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_SPECIAL_USE" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
    <uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" />
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />
    <uses-permission
        android:name="android.permission.QUERY_ALL_PACKAGES"
        tools:ignore="QueryAllPackagesPermission" />

    <application
        android:name=".NetzschildApp"
        android:allowBackup="false"
        android:icon="@drawable/ic_shield"
        android:label="@string/app_name"
        android:roundIcon="@drawable/ic_shield"
        android:supportsRtl="true"
        android:theme="@style/Theme.Netzschild"
        android:networkSecurityConfig="@xml/network_security_config">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:launchMode="singleTop">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <activity
            android:name=".TrustPromptActivity"
            android:exported="false"
            android:excludeFromRecents="true"
            android:launchMode="singleTop"
            android:theme="@style/Theme.Netzschild.Dialog" />

        <service
            android:name=".vpn.ShieldVpnService"
            android:exported="false"
            android:foregroundServiceType="specialUse"
            android:permission="android.permission.BIND_VPN_SERVICE">
            <intent-filter>
                <action android:name="android.net.VpnService" />
            </intent-filter>
            <property
                android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE"
                android:value="Lokale Domainprüfung zum Schutz vor betrügerischen Websites" />
        </service>

        <receiver
            android:name=".boot.BootReceiver"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
            </intent-filter>
        </receiver>
    </application>
</manifest>
`,
);

w(
  "app/src/main/java/de/netzschild/app/NetzschildApp.kt",
  `package de.netzschild.app

import android.app.Application
import de.netzschild.app.notify.ShieldNotifications

class NetzschildApp : Application() {
    override fun onCreate() {
        super.onCreate()
        ShieldNotifications.ensureChannels(this)
    }
}
`,
);

w(
  "app/src/main/java/de/netzschild/app/engine/ReputationEngine.kt",
  `package de.netzschild.app.engine

data class Finding(val title: String, val detail: String, val danger: Boolean)

enum class Verdict { TRUSTED, UNKNOWN, SUSPICIOUS, MALICIOUS }

data class Inspection(
    val host: String,
    val verdict: Verdict,
    val findings: List<Finding>,
    val brandHit: String?,
)

object ReputationEngine {
    private val riskyTlds = setOf(
        "tk", "gq", "ml", "cf", "ga", "xyz", "top", "click", "link",
        "zip", "mov", "country", "loan", "win", "review", "gdn",
    )
    private val bait = listOf(
        "login", "secure", "update", "verify", "konto", "account",
        "sicherheit", "kundencenter", "paket", "sendung", "tan",
        "freigabe", "restore", "bonus", "gewinn", "alert",
    )
    private val malicious = setOf(
        "sparkasse-sicherheit.tk",
        "sparkasse-login-check.tk",
        "paypal-konto-update.com",
        "paypal-sicherheit-service.net",
        "dhl-paket-sendung.net",
        "dhl-sendungsverfolgung.xyz",
        "appleid-verify-login.com",
        "icloud-account-restore.tk",
        "telekom-kundencenter.xyz",
        "amazon-prime-bonus.top",
        "microsoft-konto-alert.gq",
        "elster-steuerauskunft.click",
        "whatsapp-voice-mail.ml",
        "postbank-tan-freigabe.cf",
        "n26-karten-sperre.ga",
        "secure-paypal-de.net",
        "konto-update-sparkasse.com",
    )
    private val brands = listOf(
        "sparkasse" to "Sparkasse",
        "volksbank" to "Volksbank",
        "deutsche-bank" to "Deutsche Bank",
        "commerzbank" to "Commerzbank",
        "postbank" to "Postbank",
        "paypal" to "PayPal",
        "amazon" to "Amazon",
        "dhl" to "DHL",
        "telekom" to "Telekom",
        "apple" to "Apple",
        "icloud" to "Apple",
        "google" to "Google",
        "microsoft" to "Microsoft",
        "elster" to "ELSTER",
        "whatsapp" to "WhatsApp",
        "n26" to "N26",
        "ing" to "ING",
    )
    private val official = setOf(
        "sparkasse.de", "paypal.com", "paypal.de", "amazon.de", "amazon.com",
        "dhl.de", "dhl.com", "telekom.de", "t-online.de", "apple.com",
        "icloud.com", "google.com", "google.de", "gmail.com", "microsoft.com",
        "live.com", "office.com", "elster.de", "whatsapp.com", "whatsapp.net",
        "n26.com", "ing.de", "postbank.de", "commerzbank.de", "deutsche-bank.de",
        "facebook.com", "instagram.com", "youtube.com",
    )

    fun inspect(raw: String): Inspection {
        val host = normalize(raw)
        if (host.isEmpty()) {
            return Inspection(host, Verdict.UNKNOWN, emptyList(), null)
        }
        val findings = mutableListOf<Finding>()
        var score = 0
        var brandHit: String? = null

        if (host.matches(Regex("""^\d{1,3}(\.\d{1,3}){3}$""")) || host.contains(":")) {
            findings += Finding("IP statt Domain", "Seriöse Dienste nutzen selten eine nackte IP.", true)
            score += 45
        }
        if (host in malicious || registrable(host) in malicious) {
            findings += Finding("Bekannte Betrugsseite", "Eintrag in der lokalen Sperrliste.", true)
            score += 90
        }
        if (host.startsWith("xn--") || host.any { it.code > 127 }) {
            findings += Finding("Versteckte Zeichen", "Punycode oder fremde Schrift — klassischer Lookalike.", true)
            score += 40
        }
        val tld = host.substringAfterLast('.', "")
        if (tld in riskyTlds) {
            findings += Finding("Auffällige Endung .$tld", "Diese Endung wird oft für Phishing missbraucht.", false)
            score += 22
        }
        if (host.count { it == '-' } >= 2) {
            findings += Finding("Viele Bindestriche", "Echte Marken-Domains sind kurz.", false)
            score += 12
        }
        val baitHits = bait.filter { host.contains(it) }
        if (baitHits.isNotEmpty()) {
            findings += Finding(
                "Druck-Wörter in der Domain",
                "Enthält \${baitHits.take(3).joinToString(\", \")}.",
                false,
            )
            score += 8 * minOf(baitHits.size, 3)
        }
        for ((needle, label) in brands) {
            val officialHit = official.any { host == it || host.endsWith(".$it") }
            if (!officialHit && host.contains(needle) && registrable(host) !in official) {
                brandHit = label
                findings += Finding("Sieht aus wie $label", "Die Adresse imitiert $label, ist aber nicht offiziell.", true)
                score += 50
                break
            }
        }
        val isOfficial = official.any { host == it || host.endsWith(".$it") }
        if (isOfficial) {
            findings.add(0, Finding("Original-Domain", "Hinterlegter Vertrauensanker.", false))
            score = maxOf(0, score - 70)
        }
        val verdict = when {
            isOfficial && score < 22 -> Verdict.TRUSTED
            score >= 55 -> Verdict.MALICIOUS
            score >= 22 -> Verdict.SUSPICIOUS
            else -> Verdict.UNKNOWN
        }
        return Inspection(host, verdict, findings, brandHit)
    }

    fun needsAsk(inspection: Inspection, stored: String?): Boolean {
        if (stored != null) return false
        return inspection.verdict == Verdict.MALICIOUS || inspection.verdict == Verdict.SUSPICIOUS
    }

    private fun normalize(raw: String): String {
        var s = raw.trim().lowercase().trimEnd('.')
        s = s.removePrefix("https://").removePrefix("http://")
        s = s.substringBefore("/").substringBefore(":")
        return s
    }

    private fun registrable(host: String): String {
        val p = host.split(".").filter { it.isNotEmpty() }
        return if (p.size <= 2) host else p.takeLast(2).joinToString(".")
    }
}
`,
);

w(
  "app/src/main/java/de/netzschild/app/engine/TrustStore.kt",
  `package de.netzschild.app.engine

import android.content.Context

object TrustStore {
    const val ALLOW = "allow"
    const val BLOCK = "block"
    const val TRUST = "trust"

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences("netzschild_trust", Context.MODE_PRIVATE)

    fun get(ctx: Context, host: String): String? =
        prefs(ctx).getString(host.lowercase(), null)

    fun put(ctx: Context, host: String, decision: String) {
        prefs(ctx).edit().putString(host.lowercase(), decision).apply()
    }

    fun shouldBlock(ctx: Context, inspection: Inspection): Boolean {
        val stored = get(ctx, inspection.host)
        if (stored == BLOCK) return true
        if (stored == TRUST || stored == ALLOW) return false
        return inspection.verdict == Verdict.MALICIOUS
    }
}
`,
);

w(
  "app/src/main/java/de/netzschild/app/engine/TrafficLog.kt",
  `package de.netzschild.app.engine

import java.util.concurrent.CopyOnWriteArrayList

data class TrafficEntry(
    val at: Long,
    val host: String,
    val verdict: Verdict,
    val decision: String,
)

object TrafficLog {
    private val items = CopyOnWriteArrayList<TrafficEntry>()
    var listener: (() -> Unit)? = null

    fun add(host: String, verdict: Verdict, decision: String) {
        items.add(0, TrafficEntry(System.currentTimeMillis(), host, verdict, decision))
        while (items.size > 300) items.removeAt(items.lastIndex)
        listener?.invoke()
    }

    fun snapshot(): List<TrafficEntry> = items.toList()
}
`,
);

w(
  "app/src/main/java/de/netzschild/app/notify/ShieldNotifications.kt",
  `package de.netzschild.app.notify

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import de.netzschild.app.MainActivity
import de.netzschild.app.R
import de.netzschild.app.TrustPromptActivity

object ShieldNotifications {
    const val CHANNEL_STATUS = "status"
    const val CHANNEL_ALERT = "alert"
    const val ID_ONGOING = 41

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_STATUS, "Schutzstatus", NotificationManager.IMPORTANCE_LOW),
        )
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ALERT, "Sicherheitsnachfragen", NotificationManager.IMPORTANCE_HIGH),
        )
    }

    fun ongoing(ctx: Context): Notification {
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(ctx, CHANNEL_STATUS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(ctx.getString(R.string.app_name))
            .setContentText(ctx.getString(R.string.status_on))
            .setOngoing(true)
            .setContentIntent(open)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    fun ask(ctx: Context, host: String, reason: String) {
        val intent = Intent(ctx, TrustPromptActivity::class.java)
            .putExtra(TrustPromptActivity.EXTRA_HOST, host)
            .putExtra(TrustPromptActivity.EXTRA_REASON, reason)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pi = PendingIntent.getActivity(
            ctx, host.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL_ALERT)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(ctx.getString(R.string.ask_title))
            .setContentText(host)
            .setStyle(NotificationCompat.BigTextStyle().bigText("$host\n$reason"))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(host.hashCode() and 0x7fffffff, n)
        try {
            ctx.startActivity(intent)
        } catch (_: Exception) {
            // bleibt als Mitteilung sichtbar
        }
    }
}
`,
);

w(
  "app/src/main/java/de/netzschild/app/vpn/DnsCodec.kt",
  `package de.netzschild.app.vpn

object DnsCodec {
    fun readQueryName(dns: ByteArray): String? {
        if (dns.size < 12) return null
        var i = 12
        val labels = ArrayList<String>()
        while (i < dns.size) {
            val len = dns[i].toInt() and 0xFF
            if (len == 0) break
            if (len and 0xC0 != 0) return null
            if (i + 1 + len > dns.size) return null
            labels += dns.copyOfRange(i + 1, i + 1 + len).toString(Charsets.US_ASCII)
            i += 1 + len
        }
        if (labels.isEmpty()) return null
        return labels.joinToString(".").lowercase()
    }

    fun nxDomain(query: ByteArray): ByteArray {
        val out = query.copyOf()
        if (out.size < 4) return out
        // QR=1, RA=1, RCODE=3 (NXDOMAIN)
        out[2] = ((out[2].toInt() and 0x01) or 0x80).toByte()
        out[3] = 0x83.toByte()
        out[6] = 0
        out[7] = 0
        out[8] = 0
        out[9] = 0
        out[10] = 0
        out[11] = 0
        return out
    }
}
`,
);

w(
  "app/src/main/java/de/netzschild/app/vpn/ShieldVpnService.kt",
  `package de.netzschild.app.vpn

import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import de.netzschild.app.engine.ReputationEngine
import de.netzschild.app.engine.TrafficLog
import de.netzschild.app.engine.TrustStore
import de.netzschild.app.engine.Verdict
import de.netzschild.app.notify.ShieldNotifications
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.atomic.AtomicBoolean

class ShieldVpnService : VpnService(), Runnable {
    private val running = AtomicBoolean(false)
    private var tun: ParcelFileDescriptor? = null
    private var worker: Thread? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ShieldNotifications.ensureChannels(this)
        startForeground(ShieldNotifications.ID_ONGOING, ShieldNotifications.ongoing(this))
        startTunnel()
        return START_STICKY
    }

    private fun startTunnel() {
        stopTunnel()
        val builder = Builder()
            .setSession("Netzschild")
            .setMtu(1500)
            .addAddress("10.111.1.2", 32)
            .addDnsServer("10.111.1.1")
            .addRoute("10.111.1.1", 32)
            .setBlocking(true)
        if (Build.VERSION.SDK_INT >= 29) builder.setMetered(false)
        tun = builder.establish() ?: return
        running.set(true)
        worker = Thread(this, "netzschild-tun").also { it.start() }
    }

    private fun stopTunnel() {
        running.set(false)
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        worker = null
    }

    override fun onDestroy() {
        stopTunnel()
        super.onDestroy()
    }

    override fun run() {
        val pfd = tun ?: return
        val input = FileInputStream(pfd.fileDescriptor)
        val output = FileOutputStream(pfd.fileDescriptor)
        val buf = ByteArray(32767)
        while (running.get()) {
            val n = try {
                input.read(buf)
            } catch (_: Exception) {
                break
            }
            if (n <= 0) continue
            handle(buf, n, output)
        }
    }

    private fun handle(pkt: ByteArray, len: Int, out: FileOutputStream) {
        if (len < 28) return
        val version = (pkt[0].toInt() ushr 4) and 0xF
        if (version != 4) return
        val ihl = (pkt[0].toInt() and 0x0F) * 4
        val proto = pkt[9].toInt() and 0xFF
        if (proto != 17) return
        val udp = ihl
        if (len < udp + 8) return
        val dstPort = ((pkt[udp + 2].toInt() and 0xFF) shl 8) or (pkt[udp + 3].toInt() and 0xFF)
        if (dstPort != 53) return
        val dnsOff = udp + 8
        val dns = pkt.copyOfRange(dnsOff, len)
        val host = DnsCodec.readQueryName(dns) ?: return
        val inspection = ReputationEngine.inspect(host)
        val stored = TrustStore.get(this, inspection.host)
        val block = TrustStore.shouldBlock(this, inspection) ||
            (stored == null && inspection.verdict == Verdict.SUSPICIOUS)

        if (ReputationEngine.needsAsk(inspection, stored)) {
            val reason = inspection.findings.firstOrNull()?.title ?: "Unklare Vertrauenslage"
            ShieldNotifications.ask(this, inspection.host, reason)
        }

        val decision = when {
            block -> TrustStore.BLOCK
            stored != null -> stored
            else -> TrustStore.ALLOW
        }
        TrafficLog.add(inspection.host, inspection.verdict, decision)

        if (block) {
            val nx = DnsCodec.nxDomain(dns)
            writeUdpReply(pkt, ihl, nx, out)
            return
        }
        forward(pkt, ihl, dns, out)
    }

    private fun forward(orig: ByteArray, ihl: Int, dns: ByteArray, out: FileOutputStream) {
        try {
            val sock = DatagramSocket()
            protect(sock)
            sock.soTimeout = 2500
            val dest = InetAddress.getByName("1.1.1.1")
            sock.send(DatagramPacket(dns, dns.size, dest, 53))
            val replyBuf = ByteArray(4096)
            val incoming = DatagramPacket(replyBuf, replyBuf.size)
            sock.receive(incoming)
            sock.close()
            writeUdpReply(orig, ihl, incoming.data.copyOf(incoming.length), out)
        } catch (_: Exception) {
            writeUdpReply(orig, ihl, DnsCodec.nxDomain(dns), out)
        }
    }

    private fun writeUdpReply(orig: ByteArray, ihl: Int, payload: ByteArray, out: FileOutputStream) {
        val udpLen = 8 + payload.size
        val total = ihl + udpLen
        val pkt = ByteArray(total)
        System.arraycopy(orig, 0, pkt, 0, ihl + 8)
        // swap src/dst IP
        System.arraycopy(orig, 16, pkt, 12, 4)
        System.arraycopy(orig, 12, pkt, 16, 4)
        pkt[8] = 64
        pkt[10] = 0
        pkt[11] = 0
        val totalHi = (total ushr 8) and 0xFF
        val totalLo = total and 0xFF
        pkt[2] = totalHi.toByte()
        pkt[3] = totalLo.toByte()
        checksum(pkt, 0, ihl, 10)
        // swap ports
        pkt[ihl] = orig[ihl + 2]
        pkt[ihl + 1] = orig[ihl + 3]
        pkt[ihl + 2] = orig[ihl]
        pkt[ihl + 3] = orig[ihl + 1]
        pkt[ihl + 4] = ((udpLen ushr 8) and 0xFF).toByte()
        pkt[ihl + 5] = (udpLen and 0xFF).toByte()
        pkt[ihl + 6] = 0
        pkt[ihl + 7] = 0
        System.arraycopy(payload, 0, pkt, ihl + 8, payload.size)
        udpChecksum(pkt, ihl, udpLen)
        out.write(pkt)
    }

    private fun checksum(buf: ByteArray, off: Int, len: Int, at: Int) {
        buf[at] = 0
        buf[at + 1] = 0
        var sum = 0
        var i = off
        while (i < off + len - 1) {
            sum += ((buf[i].toInt() and 0xFF) shl 8) or (buf[i + 1].toInt() and 0xFF)
            i += 2
        }
        if (len % 2 != 0) sum += (buf[off + len - 1].toInt() and 0xFF) shl 8
        while (sum ushr 16 != 0) sum = (sum and 0xFFFF) + (sum ushr 16)
        val c = sum.inv() and 0xFFFF
        buf[at] = (c ushr 8).toByte()
        buf[at + 1] = (c and 0xFF).toByte()
    }

    private fun udpChecksum(pkt: ByteArray, ihl: Int, udpLen: Int) {
        pkt[ihl + 6] = 0
        pkt[ihl + 7] = 0
        var sum = 0
        // pseudo header
        for (i in 12 until 20 step 2) {
            sum += ((pkt[i].toInt() and 0xFF) shl 8) or (pkt[i + 1].toInt() and 0xFF)
        }
        sum += 17
        sum += udpLen
        var i = ihl
        val end = ihl + udpLen
        while (i < end - 1) {
            sum += ((pkt[i].toInt() and 0xFF) shl 8) or (pkt[i + 1].toInt() and 0xFF)
            i += 2
        }
        if (udpLen % 2 != 0) sum += (pkt[end - 1].toInt() and 0xFF) shl 8
        while (sum ushr 16 != 0) sum = (sum and 0xFFFF) + (sum ushr 16)
        var c = sum.inv() and 0xFFFF
        if (c == 0) c = 0xFFFF
        pkt[ihl + 6] = (c ushr 8).toByte()
        pkt[ihl + 7] = (c and 0xFF).toByte()
    }
}
`,
);

w(
  "app/src/main/java/de/netzschild/app/TrustPromptActivity.kt",
  `package de.netzschild.app

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import de.netzschild.app.engine.ReputationEngine
import de.netzschild.app.engine.TrustStore

class TrustPromptActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_trust)
        val host = intent.getStringExtra(EXTRA_HOST) ?: run { finish(); return }
        val inspection = ReputationEngine.inspect(host)
        findViewById<TextView>(R.id.host).text = inspection.host
        findViewById<TextView>(R.id.reason).text =
            inspection.findings.joinToString("\\n\\n") { "\${it.title}\\n\${it.detail}" }
                .ifBlank { intent.getStringExtra(EXTRA_REASON) ?: getString(R.string.ask_fallback) }

        findViewById<MaterialButton>(R.id.btn_block).setOnClickListener {
            TrustStore.put(this, inspection.host, TrustStore.BLOCK)
            finish()
        }
        findViewById<MaterialButton>(R.id.btn_once).setOnClickListener {
            TrustStore.put(this, inspection.host, TrustStore.ALLOW)
            finish()
        }
        findViewById<MaterialButton>(R.id.btn_trust).setOnClickListener {
            TrustStore.put(this, inspection.host, TrustStore.TRUST)
            finish()
        }
    }

    companion object {
        const val EXTRA_HOST = "host"
        const val EXTRA_REASON = "reason"
    }
}
`,
);

w(
  "app/src/main/java/de/netzschild/app/MainActivity.kt",
  `package de.netzschild.app

import android.Manifest
import android.app.AppOpsManager
import android.content.Intent
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import de.netzschild.app.engine.TrafficLog
import de.netzschild.app.engine.TrustStore
import de.netzschild.app.engine.Verdict
import de.netzschild.app.vpn.ShieldVpnService

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var toggle: MaterialSwitch
    private lateinit var adapter: LogAdapter

    private val notifyPerm = registerForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { /* recorded by system */ }

    private val vpnPrepare = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        if (result.resultCode == RESULT_OK) startShield()
        else {
            toggle.isChecked = false
            Toast.makeText(this, R.string.vpn_denied, Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        toggle = findViewById(R.id.toggle)
        adapter = LogAdapter()
        val list = findViewById<RecyclerView>(R.id.traffic)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter

        toggle.setOnCheckedChangeListener { _, on ->
            if (on) enableProtection() else stopShield()
        }

        findViewById<MaterialButton>(R.id.btn_notify).setOnClickListener { askNotifications() }
        findViewById<MaterialButton>(R.id.btn_battery).setOnClickListener { askBattery() }
        findViewById<MaterialButton>(R.id.btn_overlay).setOnClickListener { askOverlay() }
        findViewById<MaterialButton>(R.id.btn_usage).setOnClickListener { askUsage() }

        TrafficLog.listener = { runOnUiThread { adapter.reload() } }
        adapter.reload()
        refreshStatus(false)
    }

    override fun onDestroy() {
        TrafficLog.listener = null
        super.onDestroy()
    }

    private fun enableProtection() {
        askNotifications()
        val prep = VpnService.prepare(this)
        if (prep != null) vpnPrepare.launch(prep) else startShield()
    }

    private fun startShield() {
        ContextCompat.startForegroundService(
            this,
            Intent(this, ShieldVpnService::class.java),
        )
        getSharedPreferences("netzschild", MODE_PRIVATE).edit().putBoolean("on", true).apply()
        refreshStatus(true)
    }

    private fun stopShield() {
        stopService(Intent(this, ShieldVpnService::class.java))
        getSharedPreferences("netzschild", MODE_PRIVATE).edit().putBoolean("on", false).apply()
        refreshStatus(false)
    }

    private fun refreshStatus(on: Boolean) {
        status.text = getString(if (on) R.string.status_on else R.string.status_off)
        toggle.isChecked = on
    }

    private fun askNotifications() {
        if (Build.VERSION.SDK_INT >= 33) {
            notifyPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun askBattery() {
        if (Build.VERSION.SDK_INT < 23) return
        val pm = getSystemService(PowerManager::class.java)
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            Toast.makeText(this, R.string.battery_ok, Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                .setData(Uri.parse("package:$packageName")),
        )
    }

    private fun askOverlay() {
        if (Settings.canDrawOverlays(this)) {
            Toast.makeText(this, R.string.overlay_ok, Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(
            Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName"),
            ),
        )
    }

    private fun askUsage() {
        val appOps = getSystemService(AppOpsManager::class.java)
        val mode = appOps.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName,
        )
        if (mode == AppOpsManager.MODE_ALLOWED) {
            Toast.makeText(this, R.string.usage_ok, Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
    }

    private class LogAdapter : RecyclerView.Adapter<LogAdapter.VH>() {
        private var data = TrafficLog.snapshot()
        fun reload() {
            data = TrafficLog.snapshot()
            notifyDataSetChanged()
        }
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_traffic, parent, false)
            return VH(v)
        }
        override fun getItemCount() = data.size
        override fun onBindViewHolder(holder: VH, position: Int) {
            val e = data[position]
            holder.host.text = e.host
            holder.meta.text = when (e.verdict) {
                Verdict.MALICIOUS -> "Gefährlich"
                Verdict.SUSPICIOUS -> "Verdächtig"
                Verdict.TRUSTED -> "Vertrauenswürdig"
                Verdict.UNKNOWN -> "Unbekannt"
            } + " · " + when (e.decision) {
                TrustStore.BLOCK -> "blockiert"
                TrustStore.TRUST -> "vertraut"
                else -> "durchgelassen"
            }
        }
        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val host: TextView = v.findViewById(R.id.item_host)
            val meta: TextView = v.findViewById(R.id.item_meta)
        }
    }
}
`,
);

w(
  "app/src/main/java/de/netzschild/app/boot/BootReceiver.kt",
  `package de.netzschild.app.boot

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService
import androidx.core.content.ContextCompat
import de.netzschild.app.vpn.ShieldVpnService

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        val on = context.getSharedPreferences("netzschild", Context.MODE_PRIVATE)
            .getBoolean("on", false)
        if (!on) return
        if (VpnService.prepare(context) != null) return
        ContextCompat.startForegroundService(
            context,
            Intent(context, ShieldVpnService::class.java),
        )
    }
}
`,
);

w(
  "app/src/main/res/values/strings.xml",
  `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">Netzschild</string>
    <string name="status_on">Schutz aktiv · Domainprüfung im Hintergrund</string>
    <string name="status_off">Schutz aus · Verkehr ungeprüft</string>
    <string name="ask_title">Netzschild fragt nach</string>
    <string name="ask_fallback">Diese Adresse ist nicht klar vertrauenswürdig.</string>
    <string name="vpn_denied">Ohne VPN-Freigabe kann Netzschild keine Domains sehen.</string>
    <string name="battery_ok">Akku-Ausnahme ist bereits erteilt.</string>
    <string name="overlay_ok">Einblendung ist bereits erlaubt.</string>
    <string name="usage_ok">Nutzungszugriff ist bereits erlaubt.</string>
    <string name="perm_notify">Benachrichtigungen</string>
    <string name="perm_battery">Im Hintergrund behalten</string>
    <string name="perm_overlay">Warnung über anderen Apps</string>
    <string name="perm_usage">App-Zuordnung (optional)</string>
    <string name="headline">Schutz, der nachfragt</string>
    <string name="body">Netzschild prüft jede Domain lokal. Bei Zweifel entscheidet Sie — nicht still irgendwer.</string>
    <string name="block">Blockieren</string>
    <string name="once">Nur diesmal erlauben</string>
    <string name="trust">Immer vertrauen</string>
    <string name="traffic">Aktueller Verkehr</string>
</resources>
`,
);

w(
  "app/src/main/res/values/colors.xml",
  `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="bg">#07110C</color>
    <color name="surface">#102018</color>
    <color name="fg">#E7F3EC</color>
    <color name="muted">#7F9789</color>
    <color name="primary">#3DDC97</color>
    <color name="danger">#E07A6A</color>
    <color name="on_primary">#07110C</color>
</resources>
`,
);

w(
  "app/src/main/res/values/themes.xml",
  `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.Netzschild" parent="Theme.Material3.Dark.NoActionBar">
        <item name="android:statusBarColor">@color/bg</item>
        <item name="android:navigationBarColor">@color/bg</item>
        <item name="android:windowBackground">@color/bg</item>
        <item name="colorPrimary">@color/primary</item>
        <item name="colorOnPrimary">@color/on_primary</item>
        <item name="colorSurface">@color/surface</item>
        <item name="colorOnSurface">@color/fg</item>
        <item name="android:textColor">@color/fg</item>
    </style>
    <style name="Theme.Netzschild.Dialog" parent="Theme.Material3.Dark.Dialog">
        <item name="android:windowBackground">@color/surface</item>
        <item name="colorPrimary">@color/primary</item>
    </style>
</resources>
`,
);

w(
  "app/src/main/res/layout/activity_main.xml",
  `<?xml version="1.0" encoding="utf-8"?>
<androidx.core.widget.NestedScrollView xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="@color/bg"
    android:fillViewport="true">

    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:orientation="vertical"
        android:padding="20dp">

        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="@string/app_name"
            android:textColor="@color/primary"
            android:textSize="14sp" />

        <TextView
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="12dp"
            android:text="@string/headline"
            android:textColor="@color/fg"
            android:textSize="26sp"
            android:textStyle="bold" />

        <TextView
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="8dp"
            android:text="@string/body"
            android:textColor="@color/muted"
            android:textSize="15sp" />

        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="20dp"
            android:background="@color/surface"
            android:orientation="vertical"
            android:padding="16dp">

            <TextView
                android:id="@+id/status"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:text="@string/status_off"
                android:textColor="@color/fg"
                android:textSize="16sp" />

            <com.google.android.material.materialswitch.MaterialSwitch
                android:id="@+id/toggle"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:layout_marginTop="8dp"
                android:text="Schutz starten"
                android:textColor="@color/fg" />
        </LinearLayout>

        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_marginTop="24dp"
            android:text="Berechtigungen"
            android:textColor="@color/fg"
            android:textSize="16sp" />

        <com.google.android.material.button.MaterialButton
            android:id="@+id/btn_notify"
            style="@style/Widget.Material3.Button.TonalButton"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="8dp"
            android:minHeight="48dp"
            android:text="@string/perm_notify" />

        <com.google.android.material.button.MaterialButton
            android:id="@+id/btn_battery"
            style="@style/Widget.Material3.Button.TonalButton"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:minHeight="48dp"
            android:text="@string/perm_battery" />

        <com.google.android.material.button.MaterialButton
            android:id="@+id/btn_overlay"
            style="@style/Widget.Material3.Button.TonalButton"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:minHeight="48dp"
            android:text="@string/perm_overlay" />

        <com.google.android.material.button.MaterialButton
            android:id="@+id/btn_usage"
            style="@style/Widget.Material3.Button.OutlinedButton"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:minHeight="48dp"
            android:text="@string/perm_usage" />

        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_marginTop="24dp"
            android:text="@string/traffic"
            android:textColor="@color/fg"
            android:textSize="16sp" />

        <androidx.recyclerview.widget.RecyclerView
            android:id="@+id/traffic"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:nestedScrollingEnabled="false"
            android:layout_marginTop="8dp" />
    </LinearLayout>
</androidx.core.widget.NestedScrollView>
`,
);

w(
  "app/src/main/res/layout/activity_trust.xml",
  `<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:background="@color/surface"
    android:orientation="vertical"
    android:padding="20dp">

    <TextView
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:text="@string/ask_title"
        android:textColor="@color/primary"
        android:textSize="13sp" />

    <TextView
        android:id="@+id/host"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="8dp"
        android:fontFamily="monospace"
        android:textColor="@color/fg"
        android:textSize="16sp" />

    <TextView
        android:id="@+id/reason"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="12dp"
        android:textColor="@color/muted"
        android:textSize="14sp" />

    <com.google.android.material.button.MaterialButton
        android:id="@+id/btn_block"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="16dp"
        android:backgroundTint="@color/danger"
        android:minHeight="48dp"
        android:text="@string/block"
        android:textColor="@color/fg" />

    <com.google.android.material.button.MaterialButton
        android:id="@+id/btn_once"
        style="@style/Widget.Material3.Button.TonalButton"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:minHeight="48dp"
        android:text="@string/once" />

    <com.google.android.material.button.MaterialButton
        android:id="@+id/btn_trust"
        style="@style/Widget.Material3.Button.TextButton"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:minHeight="48dp"
        android:text="@string/trust" />
</LinearLayout>
`,
);

w(
  "app/src/main/res/layout/item_traffic.xml",
  `<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:orientation="vertical"
    android:paddingTop="10dp"
    android:paddingBottom="10dp">

    <TextView
        android:id="@+id/item_host"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:fontFamily="monospace"
        android:textColor="@color/fg"
        android:textSize="13sp" />

    <TextView
        android:id="@+id/item_meta"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="2dp"
        android:textColor="@color/muted"
        android:textSize="12sp" />
</LinearLayout>
`,
);

w(
  "app/src/main/res/drawable/ic_shield.xml",
  `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    <path
        android:fillColor="#07110C"
        android:pathData="M0,0h108v108h-108z" />
    <path
        android:fillColor="#00000000"
        android:pathData="M54,22 L84,32 V54 C84,74 68,88 54,94 C40,88 24,74 24,54 V32 Z"
        android:strokeWidth="4"
        android:strokeColor="#3DDC97" />
    <path
        android:pathData="M54,38 V72 M40,54 H68"
        android:strokeWidth="4"
        android:strokeColor="#3DDC97"
        android:strokeLineCap="round" />
</vector>
`,
);

w(
  "app/src/main/res/drawable/ic_notification.xml",
  `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#00000000"
        android:pathData="M12,3 L19,6 V12 C19,16.5 16,19.5 12,21 C8,19.5 5,16.5 5,12 V6 Z"
        android:strokeWidth="1.8"
        android:strokeColor="#3DDC97" />
</vector>
`,
);

w(
  "app/src/main/res/xml/backup_rules.xml",
  `<?xml version="1.0" encoding="utf-8"?>
<full-backup-content>
    <exclude domain="sharedpref" path="netzschild_trust.xml" />
</full-backup-content>
`,
);

w(
  "app/src/main/res/xml/data_extraction_rules.xml",
  `<?xml version="1.0" encoding="utf-8"?>
<data-extraction-rules>
    <cloud-backup>
        <exclude domain="sharedpref" path="netzschild_trust.xml" />
    </cloud-backup>
</data-extraction-rules>
`,
);

w(
  "app/src/main/res/xml/network_security_config.xml",
  `<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <base-config cleartextTrafficPermitted="false" />
</network-security-config>
`,
);

const zipOut = "/workspace/public/netzschild-android.zip";
execFileSync("python3", [
  "-c",
  "import pathlib, zipfile\nroot = pathlib.Path('/workspace/android-src')\nout = pathlib.Path('/workspace/public/netzschild-android.zip')\nwith zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:\n    for p in (root / 'Netzschild').rglob('*'):\n        if p.is_file():\n            z.write(p, p.relative_to(root).as_posix())\nprint('wrote', out, 'bytes', out.stat().st_size)\n",
]);
console.log("wrote", zipOut);
