#!/usr/bin/env python3
"""
Official Android Debug APK Compiler and Signer for ShieldVPN
Uses real Android build toolchain:
- aapt (Android Asset Packaging Tool)
- javac & Google D8 (Dalvik 035 Executable compiler)
- zipalign (4-byte alignment)
- apksigner (v1, v2, v3 cryptographic signing)
"""

import os
import sys
import shutil
import subprocess
import struct
import zlib

ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
BUILD_DIR = '/tmp/shieldvpn_apk_build'
DIST_DIR = os.path.join(ROOT_DIR, 'dist')
APK_ROOT_TARGET = os.path.join(ROOT_DIR, 'app-debug.apk')
APK_PUBLIC_TARGET = os.path.join(ROOT_DIR, 'public', 'app-debug.apk')
ANDROID_JAR = '/usr/local/lib/android.jar'
R8_JAR = '/usr/local/bin/r8.jar'
FRAMEWORK_RES = '/usr/share/android-framework-res/framework-res.apk'
KEYSTORE_PATH = '/tmp/shieldvpn_debug.keystore'

def run_cmd(cmd, cwd=None):
    res = subprocess.run(cmd, shell=True, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if res.returncode != 0:
        print(f"Error running: {cmd}\nOutput: {res.stdout}\nError: {res.stderr}")
        sys.exit(res.returncode)
    return res.stdout

def make_png_icon(width, height, r, g, b):
    png = b'\x89PNG\r\n\x1a\n'
    ihdr = struct.pack('>IIBBBBB', width, height, 8, 2, 0, 0, 0)
    png += struct.pack('>I4s', len(ihdr), b'IHDR') + ihdr + struct.pack('>I', zlib.crc32(b'IHDR' + ihdr) & 0xffffffff)
    row_bytes = bytearray([0]) + bytearray([r, g, b] * width)
    raw_data = bytes(row_bytes * height)
    compressed = zlib.compress(raw_data)
    png += struct.pack('>I4s', len(compressed), b'IDAT') + compressed + struct.pack('>I', zlib.crc32(b'IDAT' + compressed) & 0xffffffff)
    png += struct.pack('>I4s', 0, b'IEND') + struct.pack('>I', zlib.crc32(b'IEND') & 0xffffffff)
    return png

def main():
    print("--- [1/6] Building production web assets ---")
    run_cmd("npm run build", cwd=ROOT_DIR)

    # Clean build dir
    if os.path.exists(BUILD_DIR):
        shutil.rmtree(BUILD_DIR)
    os.makedirs(os.path.join(BUILD_DIR, 'res', 'values'), exist_ok=True)
    os.makedirs(os.path.join(BUILD_DIR, 'res', 'mipmap-hdpi'), exist_ok=True)
    os.makedirs(os.path.join(BUILD_DIR, 'src', 'com', 'shieldvpn', 'app'), exist_ok=True)
    os.makedirs(os.path.join(BUILD_DIR, 'obj'), exist_ok=True)

    print("--- [2/6] Writing Android resources and Manifest ---")
    manifest_xml = """<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.shieldvpn.app"
    android:versionCode="1"
    android:versionName="1.0.0">

    <uses-sdk android:minSdkVersion="21" android:targetSdkVersion="34" />
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

    <application
        android:label="@string/app_name"
        android:icon="@mipmap/ic_launcher"
        android:allowBackup="true"
        android:supportsRtl="true"
        android:theme="@android:style/Theme.NoTitleBar.Fullscreen">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|keyboardHidden|screenSize"
            android:label="@string/app_name">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
"""
    with open(os.path.join(BUILD_DIR, 'AndroidManifest.xml'), 'w') as f:
        f.write(manifest_xml)

    strings_xml = """<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">ShieldVPN</string>
</resources>
"""
    with open(os.path.join(BUILD_DIR, 'res', 'values', 'strings.xml'), 'w') as f:
        f.write(strings_xml)

    # Launcher icon
    icon_png = make_png_icon(192, 192, 79, 70, 229)
    with open(os.path.join(BUILD_DIR, 'res', 'mipmap-hdpi', 'ic_launcher.png'), 'wb') as f:
        f.write(icon_png)

    print("--- [3/6] Compiling Java Activity and generating DEX bytecode ---")
    java_src = """package com.shieldvpn.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }
        });

        webView.loadUrl("file:///android_asset/public/index.html");
        setContentView(webView);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
"""
    with open(os.path.join(BUILD_DIR, 'src', 'com', 'shieldvpn', 'app', 'MainActivity.java'), 'w') as f:
        f.write(java_src)

    run_cmd(f"javac -cp {ANDROID_JAR} -d {BUILD_DIR}/obj {BUILD_DIR}/src/com/shieldvpn/app/MainActivity.java")
    run_cmd(f"java -cp {R8_JAR} com.android.tools.r8.D8 --lib {ANDROID_JAR} --output {BUILD_DIR} --min-api 21 {BUILD_DIR}/obj/com/shieldvpn/app/*.class")

    print("--- [4/6] Packaging base APK with aapt ---")
    unaligned_apk = os.path.join(BUILD_DIR, 'unaligned.apk')
    run_cmd(f"aapt package -f -m -M {BUILD_DIR}/AndroidManifest.xml -S {BUILD_DIR}/res -I {FRAMEWORK_RES} -F {unaligned_apk}")

    # Add classes.dex
    run_cmd(f"aapt add {unaligned_apk} classes.dex", cwd=BUILD_DIR)

    # Add dist assets to assets/public
    assets_dir = os.path.join(BUILD_DIR, 'assets', 'public')
    os.makedirs(assets_dir, exist_ok=True)
    for item in os.listdir(DIST_DIR):
        if item == 'app-debug.apk':
            continue
        s = os.path.join(DIST_DIR, item)
        d = os.path.join(assets_dir, item)
        if os.path.isdir(s):
            shutil.copytree(s, d)
        else:
            shutil.copy2(s, d)

    run_cmd(f"find assets -type f | xargs aapt add {unaligned_apk}", cwd=BUILD_DIR)

    print("--- [5/6] 4-byte Zipaligning APK ---")
    aligned_apk = os.path.join(BUILD_DIR, 'aligned.apk')
    run_cmd(f"zipalign -f -p 4 {unaligned_apk} {aligned_apk}")

    print("--- [6/6] Cryptographically signing APK with v1, v2, v3 signatures ---")
    if not os.path.exists(KEYSTORE_PATH):
        run_cmd(f"keytool -genkey -v -keystore {KEYSTORE_PATH} -storepass android -alias androiddebugkey -keypass android -keyalg RSA -keysize 2048 -validity 10000 -dname 'CN=Android Debug,O=Android,C=US'")

    run_cmd(f"apksigner sign --ks {KEYSTORE_PATH} --ks-pass pass:android --ks-key-alias androiddebugkey --key-pass pass:android {aligned_apk}")
    verify_output = run_cmd(f"apksigner verify -v {aligned_apk}")
    print(verify_output)

    # Copy to outputs
    shutil.copy2(aligned_apk, APK_ROOT_TARGET)
    shutil.copy2(aligned_apk, APK_PUBLIC_TARGET)

    size_kb = os.path.getsize(APK_ROOT_TARGET) / 1024
    print(f"SUCCESS! Signed, verified APK generated at:\n-> {APK_ROOT_TARGET} ({size_kb:.1f} KB)\n-> {APK_PUBLIC_TARGET}")

if __name__ == '__main__':
    main()
