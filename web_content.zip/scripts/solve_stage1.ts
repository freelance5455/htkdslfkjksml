import fs from 'fs';
import { normalizeArabicString } from '../src/engine/normalization';

function cleanWord(str: string): string {
  return normalizeArabicString(str.replace(/\s+/g, ''));
}
import { validateCrosswordLayout } from '../src/engine/CrosswordValidator';
import { CrosswordLayout, PlacedWord, BlackCell } from '../src/types/crosswordLayout';

interface QInput {
  id: string;
  clue: string;
  answer: string;
}

const rawQuestions: QInput[] = [
  { id: 'q_01', clue: 'ما اسم المدينة التي كانت عاصمة الدولة العباسية؟', answer: 'بغداد' },
  { id: 'q_02', clue: 'ما أطول نهر في قارة أوروبا؟', answer: 'الفولغا' },
  { id: 'q_03', clue: 'ما العنصر الكيميائي الذي رمزه O؟', answer: 'الأكسجين' },
  { id: 'q_04', clue: 'ما العضو المسؤول بشكل رئيسي عن ضخ الدم إلى أنحاء الجسم؟', answer: 'القلب' },
  { id: 'q_05', clue: 'ما الكوكب المعروف بالكوكب الأحمر؟', answer: 'المريخ' },
  { id: 'q_06', clue: 'من الشاعر الملقب بشاعر النيل؟', answer: 'حافظ إبراهيم' },
  { id: 'q_07', clue: 'ما علامة رفع المثنى؟', answer: 'الألف' },
  { id: 'q_08', clue: 'ما اسم أقدم ملحمة أدبية معروفة في التاريخ؟', answer: 'ملحمة جلجامش' },
  { id: 'q_09', clue: 'ما السورة التي تُسمى أم الكتاب؟', answer: 'الفاتحة' },
  { id: 'q_10', clue: 'من العالم الذي ارتبط اختراعه بالمصباح الكهربائي المتوهج تجاريًا؟', answer: 'توماس إديسون' },
  { id: 'q_11', clue: 'ما اسم الآلة الموسيقية الوترية العربية التي تشتهر برقبتها الطويلة؟', answer: 'العود' },
  { id: 'q_12', clue: 'كم عدد اللاعبين الأساسيين في فريق كرة القدم داخل الملعب؟', answer: 'أحد عشر' },
  { id: 'q_13', clue: 'ما أكبر حيوان معروف على سطح الأرض؟', answer: 'الحوت الأزرق' },
  { id: 'q_14', clue: 'ما عاصمة اليابان؟', answer: 'طوكيو' },
  { id: 'q_15', clue: 'من العالم المسلم الذي اشتهر بكتابه "القانون في الطب"؟', answer: 'ابن سينا' },
  { id: 'q_16', clue: 'ما المدينة التي تُعرف بلقب مدينة الألف مئذنة؟', answer: 'القاهرة' },
  { id: 'q_17', clue: 'ما المصطلح الذي يطلق على الارتفاع العام والمستمر في أسعار السلع والخدمات؟', answer: 'التضخم' },
  { id: 'q_18', clue: 'ما الاسم الذي يطلق على النص المكتوب الذي يصف أحداث الفيلم ومشاهده وحواراته؟', answer: 'السيناريو' },
  { id: 'q_19', clue: 'ما اسم التجربة الفكرية التي استخدمها أفلاطون لشرح انتقال الإنسان من عالم الظلال إلى معرفة الحقيقة؟', answer: 'كهف أفلاطون' },
  { id: 'q_20', clue: 'ما اسم السنة التي يكون فيها شهر فبراير 29 يومًا؟', answer: 'السنة الكبيسة' },
  { id: 'q_21', clue: 'ما الوحدة الأساسية لقياس شدة التيار الكهربائي؟', answer: 'الأمبير' },
  { id: 'q_22', clue: 'ما اسم المعاهدة التي أنهت حرب الثلاثين عامًا في أوروبا عام 1648؟', answer: 'صلح وستفاليا' },
  { id: 'q_23', clue: 'ما اسم النظام الكتابي الذي اشتهر به السومريون؟', answer: 'المسمارية' },
  { id: 'q_24', clue: 'ما الجهاز الذي يحوّل الطاقة الكهربائية إلى ضوء؟', answer: 'المصباح' },
  { id: 'q_25', clue: 'ما العدد الذي يمثل مجموع المحيطات الكبرى على سطح الأرض؟', answer: 'خمسة' },
];

interface WordDef {
  id: string;
  clue: string;
  answer: string;
  norm: string;
  len: number;
}

const words: WordDef[] = rawQuestions.map(q => ({
  id: q.id,
  clue: q.clue,
  answer: q.answer,
  norm: cleanWord(q.answer),
  len: cleanWord(q.answer).length,
}));

console.log('Words ready:', words.map(w => `${w.id}: ${w.norm} (${w.len})`).join('\n'));

// Let's write an exhaustive searcher to place all 25 words in 15x15
type Dir = 'across' | 'down';

interface Placed {
  word: WordDef;
  dir: Dir;
  r: number;
  c: number;
}

function canPlace(
  word: WordDef,
  dir: Dir,
  r: number,
  c: number,
  grid: (string | null)[][],
  cellDirs: Set<Dir>[][],
  placedWords: Placed[]
): boolean {
  const len = word.len;
  if (dir === 'across') {
    if (c + len > 15 || r >= 15 || r < 0 || c < 0) return false;
    // check before and after
    if (c > 0 && grid[r][c - 1] !== null) return false;
    if (c + len < 15 && grid[r][c + len] !== null) return false;

    let hasIntersect = placedWords.length === 0;

    for (let k = 0; k < len; k++) {
      const cur = grid[r][c + k];
      const targetChar = word.norm[k];

      if (cur !== null) {
        if (cur !== targetChar) return false;
        if (cellDirs[r][c + k].has('across')) return false; // same direction overlap
        hasIntersect = true;
      } else {
        // Parallel adjacency check: above and below must not have adjacent parallel words unless crossing
        if (r > 0 && grid[r - 1][c + k] !== null && !cellDirs[r - 1][c + k].has('down')) {
          // If above is occupied by across word, parallel touch is forbidden
          return false;
        }
        if (r < 14 && grid[r + 1][c + k] !== null && !cellDirs[r + 1][c + k].has('down')) {
          return false;
        }
      }
    }
    return hasIntersect;
  } else {
    // down
    if (r + len > 15 || c >= 15 || r < 0 || c < 0) return false;
    if (r > 0 && grid[r - 1][c] !== null) return false;
    if (r + len < 15 && grid[r + len][c] !== null) return false;

    let hasIntersect = placedWords.length === 0;

    for (let k = 0; k < len; k++) {
      const cur = grid[r + k][c];
      const targetChar = word.norm[k];

      if (cur !== null) {
        if (cur !== targetChar) return false;
        if (cellDirs[r + k][c].has('down')) return false;
        hasIntersect = true;
      } else {
        if (c > 0 && grid[r + k][c - 1] !== null && !cellDirs[r + k][c - 1].has('across')) {
          return false;
        }
        if (c < 14 && grid[r + k][c + 1] !== null && !cellDirs[r + k][c + 1].has('across')) {
          return false;
        }
      }
    }
    return hasIntersect;
  }
}

function solve(): Placed[] | null {
  const grid: (string | null)[][] = Array.from({ length: 15 }, () => Array(15).fill(null));
  const cellDirs: Set<Dir>[][] = Array.from({ length: 15 }, () => Array.from({ length: 15 }, () => new Set<Dir>()));

  // Sort words by length descending
  const sorted = [...words].sort((a, b) => b.len - a.len);

  const placed: Placed[] = [];

  let nodes = 0;
  let maxPlaced = 0;

  function backtrack(unplaced: WordDef[]): boolean {
    nodes++;
    if (nodes % 50000 === 0) {
      console.log(`Nodes: ${nodes}, current placed: ${placed.length}, maxPlaced: ${maxPlaced}`);
    }

    if (placed.length > maxPlaced) {
      maxPlaced = placed.length;
      console.log(`New record placed: ${maxPlaced}/25`);
    }

    if (unplaced.length === 0) return true;

    // Find candidate placements for all unplaced words, choose the one with fewest valid placements (MRV)
    let bestCandidates: { word: WordDef; dir: Dir; r: number; c: number; score: number }[] | null = null;
    let bestWordIdx = -1;

    for (let i = 0; i < unplaced.length; i++) {
      const w = unplaced[i];
      const candidates: { word: WordDef; dir: Dir; r: number; c: number; score: number }[] = [];

      if (placed.length === 0) {
        // Place first word in middle across
        const r = 7;
        const c = Math.floor((15 - w.len) / 2);
        candidates.push({ word: w, dir: 'across', r, c, score: 10 });
      } else {
        // Find all intersecting cells
        for (const dir of ['across', 'down'] as Dir[]) {
          for (let r = 0; r < 15; r++) {
            for (let c = 0; c < 15; c++) {
              if (canPlace(w, dir, r, c, grid, cellDirs, placed)) {
                // Score by number of intersections
                let intersections = 0;
                for (let k = 0; k < w.len; k++) {
                  const cr = dir === 'down' ? r + k : r;
                  const cc = dir === 'across' ? c + k : c;
                  if (grid[cr][cc] !== null) intersections++;
                }
                candidates.push({ word: w, dir, r, c, score: intersections });
              }
            }
          }
        }
      }

      if (candidates.length === 0 && placed.length > 0) {
        // Impossible branch
        return false;
      }

      if (bestCandidates === null || candidates.length < bestCandidates.length) {
        bestCandidates = candidates;
        bestWordIdx = i;
        if (candidates.length === 1) break; // Most constrained possible
      }
    }

    if (!bestCandidates || bestCandidates.length === 0) return false;

    // Sort candidates by intersection count descending
    bestCandidates.sort((a, b) => b.score - a.score);

    const chosenWord = unplaced[bestWordIdx];
    const nextUnplaced = unplaced.filter((_, idx) => idx !== bestWordIdx);

    for (const cand of bestCandidates) {
      // Place cand
      const changes: { r: number; c: number; wasNull: boolean }[] = [];
      for (let k = 0; k < chosenWord.len; k++) {
        const cr = cand.dir === 'down' ? cand.r + k : cand.r;
        const cc = cand.dir === 'across' ? cand.c + k : cand.c;
        const wasNull = grid[cr][cc] === null;
        grid[cr][cc] = chosenWord.norm[k];
        cellDirs[cr][cc].add(cand.dir);
        changes.push({ r: cr, c: cc, wasNull });
      }

      const p: Placed = {
        word: chosenWord,
        dir: cand.dir,
        r: cand.r,
        c: cand.c
      };
      placed.push(p);

      if (backtrack(nextUnplaced)) return true;

      // Undo
      placed.pop();
      for (const ch of changes) {
        cellDirs[ch.r][ch.c].delete(cand.dir);
        if (ch.wasNull) {
          grid[ch.r][ch.c] = null;
        }
      }
    }

    return false;
  }

  const success = backtrack(sorted);
  return success ? placed : null;
}

const result = solve();
if (result) {
  console.log('SOLVED SUCCESSFULLY WITH ALL 25 WORDS!');
  
  // Convert to CrosswordLayout format
  const gridCells = Array.from({ length: 15 }, () => Array(15).fill(null));
  result.forEach(p => {
    for (let k = 0; k < p.word.len; k++) {
      const cr = p.dir === 'down' ? p.r + k : p.r;
      const cc = p.dir === 'across' ? p.c + k : p.c;
      gridCells[cr][cc] = p.word.norm[k];
    }
  });

  const blackCells: BlackCell[] = [];
  for (let r = 0; r < 15; r++) {
    for (let c = 0; c < 15; c++) {
      if (gridCells[r][c] === null) {
        blackCells.push({ row: r, column: c });
      }
    }
  }

  // Assign numbers top-to-bottom, right-to-left or left-to-right
  const wordsPlaced: PlacedWord[] = result.map((p, idx) => {
    const letters = [];
    for (let k = 0; k < p.word.len; k++) {
      letters.push({
        letter: p.word.norm[k],
        row: p.dir === 'down' ? p.r + k : p.r,
        column: p.dir === 'across' ? p.c + k : p.c
      });
    }

    return {
      id: p.word.id,
      number: idx + 1,
      clue: p.word.clue,
      answer: p.word.answer,
      normalizedAnswer: p.word.norm,
      length: p.word.len,
      direction: p.dir,
      startRow: p.r,
      startColumn: p.c,
      reversed: false,
      letters
    };
  });

  // Sort words by startRow, then startColumn to assign standard crossword numbers
  wordsPlaced.sort((a, b) => {
    if (a.startRow !== b.startRow) return a.startRow - b.startRow;
    return a.startColumn - b.startColumn;
  });
  wordsPlaced.forEach((w, idx) => {
    w.number = idx + 1;
  });

  const finalLayout: CrosswordLayout = {
    gridRows: 15,
    gridColumns: 15,
    words: wordsPlaced,
    blackCells
  };

  const validation = validateCrosswordLayout(finalLayout);
  console.log('Validation results:', validation);

  fs.writeFileSync('./src/data/golden_stage_01.json', JSON.stringify(finalLayout, null, 2));
  console.log('Saved to golden_stage_01.json!');
} else {
  console.log('Could not find layout for this order.');
}
