import { chromium } from "playwright";
import fs from "node:fs";

const OUT = "test-output";
const logs = [];
let failures = 0;

function makeWav(seconds = 1.2, sampleRate = 44100) {
  const length = Math.floor(seconds * sampleRate);
  const data = Buffer.alloc(length * 2);
  for (let i = 0; i < length; i++) {
    const sample = Math.sin((2 * Math.PI * 440 * i) / sampleRate) * 0.2;
    data.writeInt16LE(Math.round(sample * 32767), i * 2);
  }
  const header = Buffer.alloc(44);
  header.write("RIFF", 0);
  header.writeUInt32LE(36 + data.length, 4);
  header.write("WAVE", 8);
  header.write("fmt ", 12);
  header.writeUInt32LE(16, 16);
  header.writeUInt16LE(1, 20);
  header.writeUInt16LE(1, 22);
  header.writeUInt32LE(sampleRate, 24);
  header.writeUInt32LE(sampleRate * 2, 28);
  header.writeUInt16LE(2, 32);
  header.writeUInt16LE(16, 34);
  header.write("data", 36);
  header.writeUInt32LE(data.length, 40);
  return Buffer.concat([header, data]);
}

fs.writeFileSync(`${OUT}/sample-question-audio.wav`, makeWav(1.2));

const browser = await chromium.launch({ args: ["--no-sandbox", "--autoplay-policy=no-user-gesture-required"] });
const context = await browser.newContext({ viewport: { width: 1440, height: 1000 }, locale: "ar-SA", acceptDownloads: true });
const page = await context.newPage();
page.on("console", (message) => {
  if (message.type() === "error") logs.push(`[console:error] ${message.text()}`);
});
page.on("pageerror", (error) => {
  failures++;
  logs.push(`[pageerror] ${error.message}`);
});

async function shot(name) {
  await page.waitForTimeout(500);
  await page.screenshot({ path: `${OUT}/${name}.png`, fullPage: false });
}

try {
  await page.goto("http://localhost:4173/", { waitUntil: "networkidle" });
  await page.waitForTimeout(1200);

  // كل صفحة: فتح والتقاط لقطة ومراقبة الأخطاء
  const nav = [
    ["الأسئلة والأجوبة", "ui-questions"],
    ["الصوت والتوقيت", "ui-audio"],
    ["التصميم المرئي", "ui-design"],
    ["المعاينة الحية", "ui-preview"],
    ["تصدير الفيديو", "ui-export"],
    ["اختبار المحرك", "ui-selftest"],
    ["الدليل وتقرير الاختبار", "ui-help"],
  ];
  for (const [label, shotName] of nav) {
    await page.getByRole("button", { name: label, exact: true }).first().click();
    await page.waitForTimeout(900);
    await shot(shotName);
  }

  // رفع صوت حقيقي للسؤال الأول + استمرار بعد إعادة التحميل
  await page.getByRole("button", { name: "الأسئلة والأجوبة", exact: true }).first().click();
  await page.waitForTimeout(600);
  const audioInputs = page.locator('input[type="file"][accept^="audio"]');
  const audioCount = await audioInputs.count();
  if (audioCount < 1) throw new Error("لم يُعثر على حقل رفع صوت");
  await audioInputs.first().setInputFiles(`${OUT}/sample-question-audio.wav`);
  await page.waitForTimeout(1600);
  const uploaded = await page.getByText("sample-question-audio.wav").count();
  if (!uploaded) throw new Error("لم يظهر اسم الملف بعد الرفع");
  const playButton = page.getByRole("button", { name: "تشغيل المعاينة" }).first();
  if (await playButton.count()) {
    await playButton.click();
    await page.waitForTimeout(700);
  }
  await shot("ui-question-audio-uploaded");
  await page.waitForTimeout(1600);
  await page.reload({ waitUntil: "networkidle" });
  await page.waitForTimeout(1800);
  await page.getByRole("button", { name: "الأسئلة والأجوبة", exact: true }).first().click();
  await page.waitForTimeout(700);
  const persisted = await page.getByText("sample-question-audio.wav").count();
  if (!persisted) throw new Error("اسم الملف لم يعد بعد إعادة التحميل — فشل اختبار الحفظ");
  logs.push("UPLOAD_AND_PERSISTENCE_PASS");

  // تصدير مشروع نموذجي متعدد الأسئلة بمقاس خفيف
  await page.getByRole("button", { name: "تصدير الفيديو", exact: true }).first().click();
  await page.waitForTimeout(800);
  await page.getByRole("button", { name: /نسخة خفيفة للهاتف/ }).click();
  await page.waitForTimeout(300);
  await page.getByRole("button", { name: "إنشاء الفيديو", exact: true }).first().click();
  await page.getByText("اكتمل التصدير وتم التحقق من الملف").waitFor({ timeout: 420000 });
  logs.push("PROJECT_EXPORT_PASS");
  await shot("ui-project-export-pass");
  const downloadPromise = page.waitForEvent("download", { timeout: 30000 });
  await page.getByRole("button", { name: /تنزيل MP4/ }).first().click();
  const download = await downloadPromise;
  await download.saveAs(`${OUT}/quiz-project-export.mp4`);
  logs.push(`PROJECT_DOWNLOAD_PASS ${fs.statSync(`${OUT}/quiz-project-export.mp4`).size} bytes`);
} catch (error) {
  failures++;
  logs.push(`[test-fail] ${error.message}`);
  await page.screenshot({ path: `${OUT}/ui-failure.png`, fullPage: false }).catch(() => undefined);
  const text = await page.locator("body").innerText().catch(() => "");
  fs.writeFileSync(`${OUT}/ui-failure.txt`, text);
} finally {
  fs.writeFileSync(`${OUT}/ui-test.log`, logs.join("\n"));
  console.log(logs.join("\n"));
  await browser.close();
}
process.exit(failures ? 1 : 0);
