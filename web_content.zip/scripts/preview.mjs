import http from 'node:http';
import {readFile} from 'node:fs/promises';
import {join,resolve} from 'node:path';
const base=resolve('app/src/main/assets');
const mime={'.html':'text/html','.css':'text/css','.mjs':'text/javascript','.svg':'image/svg+xml'};
http.createServer(async(req,res)=>{const path=new URL(req.url,'http://127.0.0.1').pathname;const name=path==='/'?'index.html':path.slice(1);if(!/^[\w.-]+$/.test(name))return res.writeHead(403).end();try{const content=await readFile(join(base,name));res.writeHead(200,{'content-type':mime[name.slice(name.lastIndexOf('.'))]||'application/octet-stream'});res.end(content);}catch{res.writeHead(404).end();}}).listen(8000,'127.0.0.1',()=>console.log('JAZZY preview at http://localhost:8000'));
