import fs from 'fs';
import { STAGE_02_QUESTIONS } from '../src/data/stage02Questions';
import { normalizeArabicString } from '../src/engine/normalization';
import { validateCrosswordLayout } from '../src/engine/CrosswordValidator';
import {
  CrosswordLayout,
  CrosswordLayoutWord,
  CrosswordLayoutCell,
  LayoutCellCoordinate,
  CrosswordLayoutClue
} from '../src/types/crosswordLayout';

function log(msg: string) {
  fs.appendFileSync('/tmp/stage2_log.txt', msg + '\n');
}

fs.writeFileSync('/tmp/stage2_log.txt', 'Starting Stage 2 solver...\n');

function cleanWord(str: string): string {
  return normalizeArabicString(str.replace(/\s+/g, ''));
}

const words = STAGE_02_QUESTIONS.map((q) => ({
  id: q.id,
  clue: q.clue,
  answer: q.answer,
  norm: cleanWord(q.answer),
  len: cleanWord(q.answer).length
}));

log(`Total words: ${words.length}`);

type Dir = 'across' | 'down';

interface Placement {
  word: typeof words[0];
  dir: Dir;
  r: number;
  c: number;
  reversed: boolean;
}

function solveGrid(GRID_SIZE: number, maxRestarts: number): Placement[] | null {
  for (let restart = 0; restart < maxRestarts; restart++) {
    const grid: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
    const cellAcross: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
    const cellDown: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));

    function canFit(wStr: string, dir: Dir, r: number, c: number): { valid: boolean; inters: number } {
      const len = wStr.length;
      if (dir === 'across') {
        if (c < 0 || c + len > GRID_SIZE || r < 0 || r >= GRID_SIZE) return { valid: false, inters: 0 };
        if (c > 0 && grid[r][c - 1] !== null) return { valid: false, inters: 0 };
        if (c + len < GRID_SIZE && grid[r][c + len] !== null) return { valid: false, inters: 0 };

        let inters = 0;
        for (let k = 0; k < len; k++) {
          const cur = grid[r][c + k];
          if (cur !== null) {
            if (cur !== wStr[k]) return { valid: false, inters: 0 };
            if (cellAcross[r][c + k] !== null) return { valid: false, inters: 0 };
            inters++;
          } else {
            if (r > 0 && grid[r - 1][c + k] !== null) return { valid: false, inters: 0 };
            if (r < GRID_SIZE - 1 && grid[r + 1][c + k] !== null) return { valid: false, inters: 0 };
          }
        }
        return { valid: inters > 0, inters };
      } else {
        if (r < 0 || r + len > GRID_SIZE || c < 0 || c >= GRID_SIZE) return { valid: false, inters: 0 };
        if (r > 0 && grid[r - 1][c] !== null) return { valid: false, inters: 0 };
        if (r + len < GRID_SIZE && grid[r + len][c] !== null) return { valid: false, inters: 0 };

        let inters = 0;
        for (let k = 0; k < len; k++) {
          const cur = grid[r + k][c];
          if (cur !== null) {
            if (cur !== wStr[k]) return { valid: false, inters: 0 };
            if (cellDown[r + k][c] !== null) return { valid: false, inters: 0 };
            inters++;
          } else {
            if (c > 0 && grid[r + k][c - 1] !== null) return { valid: false, inters: 0 };
            if (c < GRID_SIZE - 1 && grid[r + k][c + 1] !== null) return { valid: false, inters: 0 };
          }
        }
        return { valid: inters > 0, inters };
      }
    }

    const placed: Placement[] = [];
    const root = words.find((w) => w.len === 15) || words[0];
    const rootDir: Dir = Math.random() > 0.5 ? 'across' : 'down';
    const rootR = rootDir === 'across' ? Math.floor(GRID_SIZE / 2) : Math.floor((GRID_SIZE - root.len) / 2);
    const rootC = rootDir === 'down' ? Math.floor(GRID_SIZE / 2) : Math.floor((GRID_SIZE - root.len) / 2);

    for (let k = 0; k < root.len; k++) {
      const cr = rootDir === 'down' ? rootR + k : rootR;
      const cc = rootDir === 'across' ? rootC + k : rootC;
      grid[cr][cc] = root.norm[k];
      if (rootDir === 'across') cellAcross[cr][cc] = root.id;
      else cellDown[cr][cc] = root.id;
    }
    placed.push({ word: root, dir: rootDir, r: rootR, c: rootC, reversed: false });

    let unplaced = words.filter((w) => w.id !== root.id);

    while (unplaced.length > 0) {
      type Candidate = {
        word: typeof words[0];
        dir: Dir;
        r: number;
        c: number;
        reversed: boolean;
        inters: number;
        score: number;
      };

      const cands: Candidate[] = [];

      for (const w of unplaced) {
        for (const dir of ['across', 'down'] as Dir[]) {
          for (const rev of [false, true]) {
            const wStr = rev ? w.norm.split('').reverse().join('') : w.norm;
            for (let r = 0; r < GRID_SIZE; r++) {
              for (let c = 0; c < GRID_SIZE; c++) {
                const fit = canFit(wStr, dir, r, c);
                if (fit.valid) {
                  const midR = dir === 'down' ? r + w.len / 2 : r;
                  const midC = dir === 'across' ? c + w.len / 2 : c;
                  const distCenter = Math.abs(midR - GRID_SIZE / 2) + Math.abs(midC - GRID_SIZE / 2);
                  const score = fit.inters * 50 + w.len * 2 - distCenter * 0.7 - (rev ? 0.5 : 0) + Math.random() * 3;
                  cands.push({ word: w, dir, r, c, reversed: rev, inters: fit.inters, score });
                }
              }
            }
          }
        }
      }

      if (cands.length === 0) {
        break;
      }

      cands.sort((a, b) => b.score - a.score);
      const topPick = cands[Math.floor(Math.random() * Math.min(3, cands.length))];

      const pickStr = topPick.reversed ? topPick.word.norm.split('').reverse().join('') : topPick.word.norm;
      for (let k = 0; k < topPick.word.len; k++) {
        const cr = topPick.dir === 'down' ? topPick.r + k : topPick.r;
        const cc = topPick.dir === 'across' ? topPick.c + k : topPick.c;
        grid[cr][cc] = pickStr[k];
        if (topPick.dir === 'across') cellAcross[cr][cc] = topPick.word.id;
        else cellDown[cr][cc] = topPick.word.id;
      }

      placed.push({
        word: topPick.word,
        dir: topPick.dir,
        r: topPick.r,
        c: topPick.c,
        reversed: topPick.reversed
      });

      unplaced = unplaced.filter((w) => w.id !== topPick.word.id);
    }

    if (restart % 200 === 0) {
      log(`Restart ${restart}: Placed ${placed.length}/${words.length}`);
    }

    if (placed.length === words.length) {
      log(`🎉 Solved all ${words.length} words on restart ${restart}!`);
      return placed;
    }
  }

  return null;
}

function buildAndValidate(GRID_SIZE: number, solved: Placement[]): CrosswordLayout | null {
  const gridChars: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
  solved.forEach((p) => {
    const wStr = p.reversed ? p.word.norm.split('').reverse().join('') : p.word.norm;
    for (let k = 0; k < p.word.len; k++) {
      const cr = p.dir === 'down' ? p.r + k : p.r;
      const cc = p.dir === 'across' ? p.c + k : p.c;
      gridChars[cr][cc] = wStr[k];
    }
  });

  const cells: CrosswordLayoutCell[] = [];
  const blackCells: LayoutCellCoordinate[] = [];

  for (let r = 0; r < GRID_SIZE; r++) {
    for (let c = 0; c < GRID_SIZE; c++) {
      const char = gridChars[r][c];
      if (char === null) {
        blackCells.push({ row: r, col: c });
        cells.push({ row: r, column: c, isBlocked: true, letter: '' });
      } else {
        const acrossW = solved.find((p) => p.dir === 'across' && p.r === r && c >= p.c && c < p.c + p.word.len);
        const downW = solved.find((p) => p.dir === 'down' && p.c === c && r >= p.r && r < p.r + p.word.len);
        cells.push({
          row: r,
          column: c,
          isBlocked: false,
          letter: char,
          acrossWordId: acrossW?.word.id,
          downWordId: downW?.word.id
        });
      }
    }
  }

  const layoutWords: CrosswordLayoutWord[] = solved.map((p) => {
    const coords: LayoutCellCoordinate[] = [];
    for (let k = 0; k < p.word.len; k++) {
      coords.push({
        row: p.dir === 'down' ? p.r + k : p.r,
        col: p.dir === 'across' ? p.c + k : p.c
      });
    }

    return {
      id: p.word.id,
      clue: p.word.clue,
      answer: p.word.answer,
      normalizedAnswer: p.word.norm,
      direction: p.dir,
      startRow: p.r,
      startColumn: p.c,
      length: p.word.len,
      cells: coords,
      number: 1,
      reversed: p.reversed
    };
  });

  layoutWords.sort((a, b) => {
    if (a.startRow !== b.startRow) return a.startRow - b.startRow;
    return a.startColumn - b.startColumn;
  });

  layoutWords.forEach((w, idx) => {
    w.number = idx + 1;
    const cell = cells.find((c) => c.row === w.startRow && c.column === w.startColumn);
    if (cell) {
      cell.clueNumber = w.number;
    }
  });

  const clues: CrosswordLayoutClue[] = layoutWords.map((w) => ({
    id: w.id,
    number: w.number,
    direction: w.direction,
    clue: w.clue,
    length: w.length,
    wordId: w.id,
    reversed: w.reversed
  }));

  const layout: CrosswordLayout = {
    gridRows: GRID_SIZE,
    gridColumns: GRID_SIZE,
    cells,
    words: layoutWords,
    clues,
    blackCells
  };

  const validation = validateCrosswordLayout(layout);
  if (validation.isValid) {
    return layout;
  } else {
    log(`Validation failed: ${JSON.stringify(validation.items.filter((i) => !i.passed))}`);
    return null;
  }
}

for (const size of [19, 18, 20, 17]) {
  log(`\nTesting size ${size}x${size}...`);
  const solution = solveGrid(size, 4000);
  if (solution) {
    const layout = buildAndValidate(size, solution);
    if (layout) {
      log(`🏆 Golden layout saved to src/data/golden_stage_02.json`);
      fs.writeFileSync('./src/data/golden_stage_02.json', JSON.stringify(layout, null, 2));
      break;
    }
  }
}

log('Solver finished.');
