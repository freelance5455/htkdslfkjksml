import fs from 'fs';
import { normalizeArabicString } from '../src/engine/normalization';
import { validateCrosswordLayout } from '../src/engine/CrosswordValidator';
import { CrosswordLayout, CrosswordLayoutWord, CrosswordLayoutCell, LayoutCellCoordinate, CrosswordLayoutClue } from '../src/types/crosswordLayout';

function cleanWord(str: string): string {
  return normalizeArabicString(str.replace(/\s+/g, ''));
}

const rawQuestions = [
  { id: 'q_01', clue: 'ما اسم المدينة التي كانت عاصمة الدولة العباسية؟', answer: 'بغداد' },
  { id: 'q_02', clue: 'ما أطول نهر في قارة أوروبا؟', answer: 'الفولغا' },
  { id: 'q_03', clue: 'ما العنصر الكيميائي الذي رمزه O؟', answer: 'الأكسجين' },
  { id: 'q_04', clue: 'ما العضو المسؤول بشكل رئيسي عن ضخ الدم إلى أنحاء الجسم؟', answer: 'القلب' },
  { id: 'q_05', clue: 'ما الكوكب المعروف بالكوكب الأحمر؟', answer: 'المريخ' },
  { id: 'q_06', clue: 'من الشاعر الملقب بشاعر النيل؟', answer: 'حافظ إبراهيم' },
  { id: 'q_07', clue: 'ما علامة رفع المثنى؟', answer: 'الألف' },
  { id: 'q_08', clue: 'ما اسم أقدم ملحمة أدبية معروفة في التاريخ؟', answer: 'جلجامش' },
  { id: 'q_09', clue: 'ما السورة التي تُسمى أم الكتاب؟', answer: 'الفاتحة' },
  { id: 'q_10', clue: 'من العالم الذي ارتبط اختراعه بالمصباح الكهربائي المتوهج تجاريًا؟', answer: 'إديسون' },
  { id: 'q_11', clue: 'ما اسم الآلة الموسيقية الوترية العربية التي تشتهر برقبتها الطويلة؟', answer: 'البزق' },
  { id: 'q_12', clue: 'كم عدد اللاعبين الأساسيين في فريق كرة القدم داخل الملعب؟', answer: 'أحد عشر' },
  { id: 'q_13', clue: 'ما أكبر حيوان معروف على سطح الأرض؟', answer: 'الحوت الأزرق' },
  { id: 'q_14', clue: 'ما عاصمة اليابان؟', answer: 'طوكيو' },
  { id: 'q_15', clue: 'من العالم المسلم الذي اشتهر بكتابه "القانون في الطب"؟', answer: 'ابن سينا' },
  { id: 'q_16', clue: 'ما المدينة التي تُعرف بلقب مدينة الألف مئذنة؟', answer: 'القاهرة' },
  { id: 'q_17', clue: 'ما المصطلح الذي يطلق على الارتفاع العام والمستمر في أسعار السلع والخدمات؟', answer: 'التضخم' },
  { id: 'q_18', clue: 'ما الاسم الذي يطلق على النص المكتوب الذي يصف أحداث الفيلم ومشاهده وحواراته؟', answer: 'السيناريو' },
  { id: 'q_19', clue: 'ما اسم التجربة الفكرية التي استخدمها أفلاطون لشرح انتقال الإنسان من عالم الظلال إلى معرفة الحقيقة؟', answer: 'كهف أفلاطون' },
  { id: 'q_20', clue: 'ما اسم السنة التي يكون فيها شهر فبراير 29 يومًا؟', answer: 'كبيسة' },
  { id: 'q_21', clue: 'ما الوحدة الأساسية لقياس شدة التيار الكهربائي؟', answer: 'الأمبير' },
  { id: 'q_22', clue: 'ما اسم المعاهدة التي أنهت حرب الثلاثين عامًا في أوروبا عام 1648؟', answer: 'وستفاليا' },
  { id: 'q_23', clue: 'ما اسم النظام الكتابي الذي اشتهر به السومريون؟', answer: 'المسمارية' },
  { id: 'q_24', clue: 'ما الجهاز الذي يحوّل الطاقة الكهربائية إلى ضوء؟', answer: 'المصباح' },
  { id: 'q_25', clue: 'ما العدد الذي يمثل مجموع المحيطات الكبرى على سطح الأرض؟', answer: 'خمسة' },
];

const words = rawQuestions.map(q => ({
  id: q.id,
  clue: q.clue,
  answer: q.answer,
  norm: cleanWord(q.answer),
  len: cleanWord(q.answer).length
}));

type Dir = 'across' | 'down';

function solveOnGrid(GRID_SIZE: number): any[] | null {
  const grid: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
  const cellAcross: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
  const cellDown: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));

  function canFitStrict(w: any, dir: Dir, r: number, c: number, placedCount: number): { valid: boolean; inters: number } {
    const len = w.len;
    if (dir === 'across') {
      if (c + len > GRID_SIZE || r < 0 || r >= GRID_SIZE || c < 0) return { valid: false, inters: 0 };
      // Before and after word must be null
      if (c > 0 && grid[r][c - 1] !== null) return { valid: false, inters: 0 };
      if (c + len < GRID_SIZE && grid[r][c + len] !== null) return { valid: false, inters: 0 };

      let touches = placedCount === 0;
      let inters = 0;

      for (let k = 0; k < len; k++) {
        const cur = grid[r][c + k];
        if (cur !== null) {
          // Intersection: must match letter and must NOT already have an across word
          if (cur !== w.norm[k]) return { valid: false, inters: 0 };
          if (cellAcross[r][c + k] !== null) return { valid: false, inters: 0 };
          touches = true;
          inters++;
        } else {
          // Non-intersecting cell: directly above and below MUST be empty!
          if (r > 0 && grid[r - 1][c + k] !== null) return { valid: false, inters: 0 };
          if (r < GRID_SIZE - 1 && grid[r + 1][c + k] !== null) return { valid: false, inters: 0 };
        }
      }
      return { valid: touches, inters };
    } else {
      if (r + len > GRID_SIZE || c < 0 || c >= GRID_SIZE || r < 0) return { valid: false, inters: 0 };
      // Before and after word must be null
      if (r > 0 && grid[r - 1][c] !== null) return { valid: false, inters: 0 };
      if (r + len < GRID_SIZE && grid[r + len][c] !== null) return { valid: false, inters: 0 };

      let touches = placedCount === 0;
      let inters = 0;

      for (let k = 0; k < len; k++) {
        const cur = grid[r + k][c];
        if (cur !== null) {
          if (cur !== w.norm[k]) return { valid: false, inters: 0 };
          if (cellDown[r + k][c] !== null) return { valid: false, inters: 0 };
          touches = true;
          inters++;
        } else {
          // Non-intersecting cell: directly left and right MUST be empty!
          if (c > 0 && grid[r + k][c - 1] !== null) return { valid: false, inters: 0 };
          if (c < GRID_SIZE - 1 && grid[r + k][c + 1] !== null) return { valid: false, inters: 0 };
        }
      }
      return { valid: touches, inters };
    }
  }

  let placed: any[] = [];
  let maxP = 0;

  function backtrack(unplaced: any[]): any[] | null {
    if (placed.length > maxP) {
      maxP = placed.length;
      console.log(`[GRID ${GRID_SIZE}x${GRID_SIZE}] Strict Placed: ${maxP}/25`);
    }
    if (unplaced.length === 0) return [...placed];

    const options: any[] = [];
    for (const w of unplaced) {
      const valid: any[] = [];
      for (const dir of ['across', 'down'] as Dir[]) {
        for (let r = 0; r < GRID_SIZE; r++) {
          for (let c = 0; c < GRID_SIZE; c++) {
            const res = canFitStrict(w, dir, r, c, placed.length);
            if (res.valid) {
              const midR = dir === 'down' ? r + w.len / 2 : r;
              const midC = dir === 'across' ? c + w.len / 2 : c;
              const dist = Math.abs(midR - GRID_SIZE/2) + Math.abs(midC - GRID_SIZE/2);
              valid.push({ dir, r, c, inters: res.inters, score: res.inters * 15 - dist * 0.5 });
            }
          }
        }
      }
      if (valid.length > 0) {
        options.push({ word: w, placements: valid });
      }
    }

    if (options.length === 0) return null;

    options.sort((a, b) => a.placements.length - b.placements.length);
    const chosen = options[0];
    chosen.placements.sort((a: any, b: any) => b.score - a.score);

    const nextUnplaced = unplaced.filter(w => w.id !== chosen.word.id);

    for (const pl of chosen.placements) {
      const changes: any[] = [];
      for (let k = 0; k < chosen.word.len; k++) {
        const cr = pl.dir === 'down' ? pl.r + k : pl.r;
        const cc = pl.dir === 'across' ? pl.c + k : pl.c;
        const wasNull = grid[cr][cc] === null;
        grid[cr][cc] = chosen.word.norm[k];
        if (pl.dir === 'across') cellAcross[cr][cc] = chosen.word.id;
        else cellDown[cr][cc] = chosen.word.id;
        changes.push({ r: cr, c: cc, wasNull });
      }

      placed.push({ word: chosen.word, dir: pl.dir, r: pl.r, c: pl.c });
      const res = backtrack(nextUnplaced);
      if (res) return res;

      placed.pop();
      for (const ch of changes) {
        if (pl.dir === 'across') cellAcross[ch.r][ch.c] = null;
        else cellDown[ch.r][ch.c] = null;
        if (ch.wasNull) grid[ch.r][ch.c] = null;
      }
    }
    return null;
  }

  const sortedRoots = [...words].sort((a, b) => b.len - a.len);
  for (const root of sortedRoots) {
    for (const dir of ['across', 'down'] as Dir[]) {
      for (let rPos = 2; rPos < GRID_SIZE - 2; rPos += 2) {
        placed = [];
        maxP = 0;
        for (let r = 0; r < GRID_SIZE; r++) {
          for (let c = 0; c < GRID_SIZE; c++) {
            grid[r][c] = null;
            cellAcross[r][c] = null;
            cellDown[r][c] = null;
          }
        }
        const rootR = dir === 'across' ? rPos : Math.floor((GRID_SIZE - root.len) / 2);
        const rootC = dir === 'down' ? rPos : Math.floor((GRID_SIZE - root.len) / 2);

        for (let k = 0; k < root.len; k++) {
          const cr = dir === 'down' ? rootR + k : rootR;
          const cc = dir === 'across' ? rootC + k : rootC;
          grid[cr][cc] = root.norm[k];
          if (dir === 'across') cellAcross[cr][cc] = root.id;
          else cellDown[cr][cc] = root.id;
        }
        placed.push({ word: root, dir, r: rootR, c: rootC });

        const sol = backtrack(words.filter(w => w.id !== root.id));
        if (sol) return sol;
      }
    }
  }
  return null;
}

for (const size of [17, 18, 19, 20]) {
  console.log(`\n=== Testing strict size ${size}x${size} ===`);
  const sol = solveOnGrid(size);
  if (sol) {
    console.log(`FOUND 100% STRICT VALID SOLUTION FOR ${size}x${size}!`);
    const gridChars: (string | null)[][] = Array.from({ length: size }, () => Array(size).fill(null));
    sol.forEach(p => {
      for (let k = 0; k < p.word.len; k++) {
        const cr = p.dir === 'down' ? p.r + k : p.r;
        const cc = p.dir === 'across' ? p.c + k : p.c;
        gridChars[cr][cc] = p.word.norm[k];
      }
    });

    const cells: CrosswordLayoutCell[] = [];
    const blackCells: LayoutCellCoordinate[] = [];

    for (let r = 0; r < size; r++) {
      for (let c = 0; c < size; c++) {
        const char = gridChars[r][c];
        if (char === null) {
          blackCells.push({ row: r, col: c });
          cells.push({ row: r, column: c, isBlocked: true, letter: '' });
        } else {
          const acrossW = sol.find(p => p.dir === 'across' && p.r === r && c >= p.c && c < p.c + p.word.len);
          const downW = sol.find(p => p.dir === 'down' && p.c === c && r >= p.r && r < p.r + p.word.len);
          cells.push({
            row: r,
            column: c,
            isBlocked: false,
            letter: char,
            acrossWordId: acrossW?.word.id,
            downWordId: downW?.word.id
          });
        }
      }
    }

    const layoutWords: CrosswordLayoutWord[] = sol.map(p => {
      const coords: LayoutCellCoordinate[] = [];
      for (let k = 0; k < p.word.len; k++) {
        coords.push({
          row: p.dir === 'down' ? p.r + k : p.r,
          col: p.dir === 'across' ? p.c + k : p.c
        });
      }

      return {
        id: p.word.id,
        clue: p.word.clue,
        answer: p.word.answer,
        normalizedAnswer: p.word.norm,
        direction: p.dir,
        startRow: p.r,
        startColumn: p.c,
        length: p.word.len,
        cells: coords,
        number: 1,
        reversed: false
      };
    });

    layoutWords.sort((a, b) => {
      if (a.startRow !== b.startRow) return a.startRow - b.startRow;
      return a.startColumn - b.startColumn;
    });

    layoutWords.forEach((w, idx) => {
      w.number = idx + 1;
      const cell = cells.find(c => c.row === w.startRow && c.column === w.startColumn);
      if (cell) {
        cell.clueNumber = w.number;
      }
    });

    const clues: CrosswordLayoutClue[] = layoutWords.map(w => ({
      id: w.id,
      number: w.number,
      direction: w.direction,
      clue: w.clue,
      answer: w.answer
    }));

    const layout: CrosswordLayout = {
      gridRows: size,
      gridColumns: size,
      cells,
      words: layoutWords,
      blackCells,
      clues,
      metadata: {
        totalWords: 25,
        placedWords: 25,
        intersectionsCount: 24,
        blackCellsCount: blackCells.length,
        generatedAt: new Date().toISOString()
      }
    };

    const validation = validateCrosswordLayout(layout);
    console.log('Validation results:\n', JSON.stringify(validation, null, 2));

    if (validation.isValid) {
      fs.writeFileSync('./src/data/golden_stage_01.json', JSON.stringify(layout, null, 2));
      console.log('SAVED TO golden_stage_01.json WITH 100% VALIDATION PASS!');
      break;
    } else {
      console.log('Layout generated but failed some validation rules.');
    }
  }
}
