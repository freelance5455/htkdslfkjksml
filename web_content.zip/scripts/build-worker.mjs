// Bundles the Hono worker (and its shared imports) into build/worker.js for
// Wrangler local dev and the Sites deployment manifest.
import { build } from 'esbuild';
import { rmSync, mkdirSync } from 'node:fs';

rmSync('build', { recursive: true, force: true });
mkdirSync('build', { recursive: true });

await build({
  entryPoints: ['worker/index.ts'],
  bundle: true,
  format: 'esm',
  target: 'es2022',
  platform: 'neutral',
  mainFields: ['module', 'main'],
  conditions: ['workerd', 'worker', 'browser'],
  outfile: 'build/worker.js',
  minify: false,
  legalComments: 'none',
  external: ['node:*', 'cloudflare:*'],
  logLevel: 'info',
});
console.log('worker bundled -> build/worker.js');
