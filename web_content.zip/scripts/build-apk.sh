#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
if ! command -v java >/dev/null 2>&1; then
  echo 'Java 17 یا بالاتر نصب نیست.' >&2
  exit 1
fi
./gradlew --no-daemon --stacktrace assembleDebug
printf '\nفایل APK: app/build/outputs/apk/debug/app-debug.apk\n'
