#!/bin/sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)"
SDK="${ANDROID_SDK_ROOT:-/opt/android-sdk}"
BT="$SDK/build-tools/34.0.0"
PLATFORM="$SDK/platforms/android-34/android.jar"
OUT="${TMPDIR:-/tmp}/daftar-apk"
KS="$ROOT/android/daftar-release.keystore"
APK="$ROOT/artifacts/daftar-shift.apk"

mkdir -p "$ROOT/android/app/src/main/res/drawable" "$ROOT/artifacts"
python3 "$ROOT/scripts/make-android-icon.py" "$ROOT/android/app/src/main/res/drawable/ic_launcher.png"

cd "$ROOT"
npx vite build --config vite.android.config.ts

rm -rf "$OUT"
mkdir -p "$OUT/gen" "$OUT/classes" "$ROOT/artifacts"

"$BT/aapt2" compile --dir "$ROOT/android/app/src/main/res" -o "$OUT/res.zip"
"$BT/aapt2" link \
  -o "$OUT/base.apk" \
  -I "$PLATFORM" \
  --manifest "$ROOT/android/app/src/main/AndroidManifest.xml" \
  -A "$ROOT/android/app/src/main/assets" \
  --java "$OUT/gen" \
  "$OUT/res.zip"

find "$OUT/gen" -name '*.java' > "$OUT/sources.list"
printf '%s\n' "$ROOT/android/app/src/main/java/app/daftarshift/MainActivity.java" >> "$OUT/sources.list"
javac --release 17 -encoding UTF-8 -classpath "$PLATFORM" -d "$OUT/classes" @"$OUT/sources.list"

jar --create --file "$OUT/classes.jar" -C "$OUT/classes" .
"$BT/d8" --min-api 24 --lib "$PLATFORM" --output "$OUT" "$OUT/classes.jar"

cp "$OUT/base.apk" "$OUT/unsigned.apk"
( cd "$OUT" && jar uf unsigned.apk classes.dex )
"$BT/zipalign" -p -f 4 "$OUT/unsigned.apk" "$OUT/aligned.apk"

if [ ! -f "$KS" ]; then
  keytool -genkeypair -keystore "$KS" -alias daftar -keyalg RSA -keysize 2048 -validity 10000 \
    -storepass daftarshift -keypass daftarshift \
    -dname "CN=Daftar Shift, OU=Health, O=Daftar Shift, C=IQ"
fi

"$BT/apksigner" sign \
  --ks "$KS" \
  --ks-pass pass:daftarshift \
  --key-pass pass:daftarshift \
  --out "$APK" \
  "$OUT/aligned.apk"
"$BT/apksigner" verify --verbose "$APK"
if [ -x "$BT/aapt" ]; then
  "$BT/aapt" dump badging "$APK" | head -n 20
fi
cp "$APK" "$ROOT/public/daftar-shift.apk"
ls -lh "$APK"
