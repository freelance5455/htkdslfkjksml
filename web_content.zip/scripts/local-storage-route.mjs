import { createReadStream, existsSync, readFileSync } from 'node:fs'
import { resolve } from 'node:path'

// Local-only: serve registered CDN addresses (/manus-storage/...) from the project's own
// copies so dev and `vite preview` work before a checkpoint. The hosted Preview and the
// published site resolve these addresses through the platform storage route instead.
export function localStorageRoute() {
  const handler = (req, res, next) => {
    const url = (req.url ?? '').split('?')[0]
    if (!url.startsWith('/manus-storage/')) return next()
    try {
      const lock = JSON.parse(readFileSync('assets.lock.json', 'utf8'))
      const entry = Object.entries(lock.assets).find(([, a]) => a.path === url)
      const file = entry && resolve(entry[0])
      if (file && existsSync(file)) {
        res.setHeader('Content-Type', 'model/gltf-binary')
        res.setHeader('Cache-Control', 'no-cache')
        return createReadStream(file).pipe(res)
      }
    } catch { /* fall through */ }
    next()
  }
  return {
    name: 'local-storage-route',
    configureServer: (server) => { server.middlewares.use(handler) },
    configurePreviewServer: (server) => { server.middlewares.use(handler) },
  }
}
