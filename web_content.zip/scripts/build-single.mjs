// ─────────────────────────────────────────────────────────────────────────────
// SINGLE-FILE BUILD — bundles the entire React SPA (JS + Tailwind CSS + icon)
// into ONE self-contained dist/index.html with zero external references.
// Opens directly via file:// double-click in Chrome / Android WebView:
//   • One inline IIFE <script> (no ES modules → no CORS / module fetch errors)
//   • One inline <style> with the full compiled Tailwind bundle
//   • Favicon embedded as a data: URI
// Usage: npm run build:single   →  dist/index.html (+ copy at public/standalone.html)
// ─────────────────────────────────────────────────────────────────────────────
import { build } from "esbuild";
import { execFileSync } from "node:child_process";
import { mkdirSync, readFileSync, writeFileSync, copyFileSync } from "node:fs";
import { resolve, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const dist = resolve(root, "dist");
mkdirSync(dist, { recursive: true });

// 1) Compile Tailwind v4 → single minified CSS
console.log("▸ Compiling Tailwind CSS…");
execFileSync(
  "npx",
  ["@tailwindcss/cli", "-i", "src/app/globals.css", "-o", "dist/.single.css", "--minify"],
  { cwd: root, stdio: "inherit" },
);
const css = readFileSync(resolve(dist, ".single.css"), "utf8");

// 2) Bundle the React app → single minified IIFE (no modules, no chunks)
console.log("▸ Bundling React app with esbuild…");
const result = await build({
  entryPoints: [resolve(root, "src/standalone.tsx")],
  bundle: true,
  minify: true,
  format: "iife",
  platform: "browser",
  target: ["chrome90", "es2020"],
  jsx: "automatic",
  write: false,
  legalComments: "none",
  alias: { "@": resolve(root, "src") },
  define: { "process.env.NODE_ENV": '"production"' },
  loader: { ".svg": "dataurl" },
});
// guard against premature </script> termination inside string literals
const js = result.outputFiles[0].text.replace(/<\/script>/gi, "<\\/script>");

// 3) Inline favicon as data URI
const iconSvg = readFileSync(resolve(root, "public/icon.svg"), "utf8");
const iconData = `data:image/svg+xml;base64,${Buffer.from(iconSvg).toString("base64")}`;

// 4) Compose the single self-contained HTML document
const html = `<!DOCTYPE html>
<html lang="he" dir="rtl">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
<meta name="theme-color" content="#0f172a" />
<title>Crypto Day Trading &amp; AI Hub</title>
<link rel="icon" href="${iconData}" />
<style>${css}</style>
</head>
<body class="bg-[#0f172a] text-slate-200 antialiased">
<div id="root"></div>
<script>${js}</script>
</body>
</html>
`;

writeFileSync(resolve(dist, "index.html"), html);
// downloadable copy served by the running app at /standalone.html
copyFileSync(resolve(dist, "index.html"), resolve(root, "public/standalone.html"));
// ship the service worker + icon alongside for the Capacitor APK (webDir=dist):
// under the https://localhost scheme the SW registers and OS notifications work.
copyFileSync(resolve(root, "public/sw.js"), resolve(dist, "sw.js"));
copyFileSync(resolve(root, "public/icon.svg"), resolve(dist, "icon.svg"));

const sizeKb = (Buffer.byteLength(html) / 1024).toFixed(0);
console.log(`✓ dist/index.html written (${sizeKb} KB, fully self-contained)`);
console.log("✓ copy served at /standalone.html — double-click dist/index.html to run offline");
