const bcrypt = require('bcryptjs'), db = require('../db'), { checkPass } = require('../lib/policy');
const [n, p] = process.argv.slice(2);
const pe = /^[\w.-]{3,24}$/.test(n || '') ? checkPass(p, n) : 'username must be 3-24 chars (letters, digits, . _ -)';
if (pe) { console.error('Error: ' + pe + '\nUsage: npm run create-admin -- <username> <password 12-72>'); process.exit(1); }
db.prepare("INSERT INTO users(username,pass_hash,role) VALUES(?,?, 'admin') ON CONFLICT(username) DO UPDATE SET pass_hash=excluded.pass_hash, role='admin'").run(n, bcrypt.hashSync(p, 12));
db.prepare('DELETE FROM sessions WHERE user_id=(SELECT id FROM users WHERE username=?)').run(n);
console.log('Admin ready: ' + n);
