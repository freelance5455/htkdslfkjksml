import fs from 'fs';
import { normalizeArabicString } from '../src/engine/normalization';
import { validateCrosswordLayout } from '../src/engine/CrosswordValidator';
import { CrosswordLayout } from '../src/types/crosswordLayout';

// Load base layout structure
const baseLayout: CrosswordLayout = JSON.parse(fs.readFileSync('./src/data/golden_stage_01.json', 'utf8'));

console.log('Words in base layout and their lengths:');
baseLayout.words.forEach(w => {
  console.log(`Word ${w.id} (${w.direction}): len = ${w.length}, letters = ${w.normalizedAnswer}`);
});
