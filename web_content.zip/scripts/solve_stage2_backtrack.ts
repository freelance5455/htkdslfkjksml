import fs from 'fs';
import { STAGE_02_QUESTIONS } from '../src/data/stage02Questions';
import { normalizeArabicString } from '../src/engine/normalization';
import { validateCrosswordLayout } from '../src/engine/CrosswordValidator';
import {
  CrosswordLayout,
  CrosswordLayoutWord,
  CrosswordLayoutCell,
  LayoutCellCoordinate,
  CrosswordLayoutClue
} from '../src/types/crosswordLayout';

function cleanWord(str: string): string {
  return normalizeArabicString(str.replace(/\s+/g, ''));
}

const words = STAGE_02_QUESTIONS.map((q) => ({
  id: q.id,
  clue: q.clue,
  answer: q.answer,
  norm: cleanWord(q.answer),
  len: cleanWord(q.answer).length
}));

type Dir = 'across' | 'down';

interface Placement {
  word: typeof words[0];
  dir: Dir;
  r: number;
  c: number;
  reversed: boolean;
}

function solveBacktrack(GRID_SIZE: number, timeoutMs = 20000): Placement[] | null {
  const startTime = Date.now();
  let globalBest = 0;

  for (let restart = 0; restart < 5000; restart++) {
    if (Date.now() - startTime > timeoutMs) break;

    const grid: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
    const cellAcross: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
    const cellDown: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));

    function canFitStrict(wStr: string, dir: Dir, r: number, c: number, placedCount: number): { valid: boolean; inters: number } {
      const len = wStr.length;
      if (dir === 'across') {
        if (c + len > GRID_SIZE || r < 0 || r >= GRID_SIZE || c < 0) return { valid: false, inters: 0 };
        if (c > 0 && grid[r][c - 1] !== null) return { valid: false, inters: 0 };
        if (c + len < GRID_SIZE && grid[r][c + len] !== null) return { valid: false, inters: 0 };

        let touches = placedCount === 0;
        let inters = 0;

        for (let k = 0; k < len; k++) {
          const cur = grid[r][c + k];
          if (cur !== null) {
            if (cur !== wStr[k]) return { valid: false, inters: 0 };
            if (cellAcross[r][c + k] !== null) return { valid: false, inters: 0 };
            touches = true;
            inters++;
          } else {
            if (r > 0 && grid[r - 1][c + k] !== null) return { valid: false, inters: 0 };
            if (r < GRID_SIZE - 1 && grid[r + 1][c + k] !== null) return { valid: false, inters: 0 };
          }
        }
        return { valid: touches, inters };
      } else {
        if (r + len > GRID_SIZE || c < 0 || c >= GRID_SIZE || r < 0) return { valid: false, inters: 0 };
        if (r > 0 && grid[r - 1][c] !== null) return { valid: false, inters: 0 };
        if (r + len < GRID_SIZE && grid[r + len][c] !== null) return { valid: false, inters: 0 };

        let touches = placedCount === 0;
        let inters = 0;

        for (let k = 0; k < len; k++) {
          const cur = grid[r + k][c];
          if (cur !== null) {
            if (cur !== wStr[k]) return { valid: false, inters: 0 };
            if (cellDown[r + k][c] !== null) return { valid: false, inters: 0 };
            touches = true;
            inters++;
          } else {
            if (c > 0 && grid[r + k][c - 1] !== null) return { valid: false, inters: 0 };
            if (c < GRID_SIZE - 1 && grid[r + k][c + 1] !== null) return { valid: false, inters: 0 };
          }
        }
        return { valid: touches, inters };
      }
    }

    function applyPlacement(p: Placement) {
      const wStr = p.reversed ? p.word.norm.split('').reverse().join('') : p.word.norm;
      for (let k = 0; k < p.word.len; k++) {
        const cr = p.dir === 'down' ? p.r + k : p.r;
        const cc = p.dir === 'across' ? p.c + k : p.c;
        grid[cr][cc] = wStr[k];
        if (p.dir === 'across') cellAcross[cr][cc] = p.word.id;
        else cellDown[cr][cc] = p.word.id;
      }
    }

    function removePlacement(p: Placement) {
      for (let k = 0; k < p.word.len; k++) {
        const cr = p.dir === 'down' ? p.r + k : p.r;
        const cc = p.dir === 'across' ? p.c + k : p.c;
        if (p.dir === 'across') {
          cellAcross[cr][cc] = null;
          if (cellDown[cr][cc] === null) grid[cr][cc] = null;
        } else {
          cellDown[cr][cc] = null;
          if (cellAcross[cr][cc] === null) grid[cr][cc] = null;
        }
      }
    }

    const placedHistory: Placement[] = [];
    const root = words.find((w) => w.len === 15) || words[0]; // منارة الإسكندرية
    const rootDir: Dir = Math.random() > 0.5 ? 'across' : 'down';
    const rootR = rootDir === 'across' ? Math.floor(GRID_SIZE / 2) : Math.floor((GRID_SIZE - root.len) / 2);
    const rootC = rootDir === 'down' ? Math.floor(GRID_SIZE / 2) : Math.floor((GRID_SIZE - root.len) / 2);

    const rootPlacement: Placement = { word: root, dir: rootDir, r: rootR, c: rootC, reversed: false };
    applyPlacement(rootPlacement);
    placedHistory.push(rootPlacement);

    // Search function with backtracking
    function search(): boolean {
      if (placedHistory.length === words.length) {
        return true;
      }

      if (placedHistory.length > globalBest) {
        globalBest = placedHistory.length;
        console.log(`[Restart ${restart}] New global best: ${globalBest}/${words.length} placed!`);
      }

      const placedIds = new Set(placedHistory.map((p) => p.word.id));
      const unplaced = words.filter((w) => !placedIds.has(w.id));

      type Option = {
        word: typeof words[0];
        dir: Dir;
        r: number;
        c: number;
        reversed: boolean;
        inters: number;
        score: number;
      };

      const allOptions: Option[] = [];

      for (const w of unplaced) {
        for (const dir of ['across', 'down'] as Dir[]) {
          for (const rev of [false, true]) {
            const wStr = rev ? w.norm.split('').reverse().join('') : w.norm;
            for (let r = 0; r < GRID_SIZE; r++) {
              for (let c = 0; c < GRID_SIZE; c++) {
                const res = canFitStrict(wStr, dir, r, c, placedHistory.length);
                if (res.valid) {
                  const midR = dir === 'down' ? r + w.len / 2 : r;
                  const midC = dir === 'across' ? c + w.len / 2 : c;
                  const distCenter = Math.abs(midR - GRID_SIZE / 2) + Math.abs(midC - GRID_SIZE / 2);
                  const revPenalty = rev ? 1.0 : 0;
                  const score = res.inters * 40 + w.len * 2 - distCenter * 0.8 - revPenalty + Math.random() * 3;
                  allOptions.push({ word: w, dir, r, c, reversed: rev, inters: res.inters, score });
                }
              }
            }
          }
        }
      }

      if (allOptions.length === 0) {
        return false;
      }

      // Group options by word to find MRV
      const optionsByWord = new Map<string, Option[]>();
      for (const opt of allOptions) {
        const list = optionsByWord.get(opt.word.id) || [];
        list.push(opt);
        optionsByWord.set(opt.word.id, list);
      }

      // Find the most constrained unplaced word (fewest available options)
      let minWordOptions: Option[] | null = null;
      for (const w of unplaced) {
        const list = optionsByWord.get(w.id);
        if (!list || list.length === 0) {
          return false; // Dead end: an unplaced word has 0 valid placements!
        }
        if (!minWordOptions || list.length < minWordOptions.length) {
          minWordOptions = list;
        }
      }

      if (!minWordOptions) return false;

      // Sort chosen word's options by score descending
      minWordOptions.sort((a, b) => b.score - a.score);

      // Explore top 3 options
      const branchLimit = Math.min(3, minWordOptions.length);
      for (let i = 0; i < branchLimit; i++) {
        const pick = minWordOptions[i];
        const p: Placement = {
          word: pick.word,
          dir: pick.dir,
          r: pick.r,
          c: pick.c,
          reversed: pick.reversed
        };

        applyPlacement(p);
        placedHistory.push(p);

        if (search()) {
          return true;
        }

        placedHistory.pop();
        removePlacement(p);
      }

      return false;
    }

    if (search()) {
      console.log(`🎉 SUCCESS! Solved Stage 2 layout with all ${words.length} words on restart ${restart}!`);
      return placedHistory;
    }
  }

  return null;
}

function buildAndValidate(GRID_SIZE: number, solved: Placement[]): CrosswordLayout | null {
  const gridChars: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
  solved.forEach((p) => {
    const wStr = p.reversed ? p.word.norm.split('').reverse().join('') : p.word.norm;
    for (let k = 0; k < p.word.len; k++) {
      const cr = p.dir === 'down' ? p.r + k : p.r;
      const cc = p.dir === 'across' ? p.c + k : p.c;
      gridChars[cr][cc] = wStr[k];
    }
  });

  const cells: CrosswordLayoutCell[] = [];
  const blackCells: LayoutCellCoordinate[] = [];

  for (let r = 0; r < GRID_SIZE; r++) {
    for (let c = 0; c < GRID_SIZE; c++) {
      const char = gridChars[r][c];
      if (char === null) {
        blackCells.push({ row: r, col: c });
        cells.push({ row: r, column: c, isBlocked: true, letter: '' });
      } else {
        const acrossW = solved.find((p) => p.dir === 'across' && p.r === r && c >= p.c && c < p.c + p.word.len);
        const downW = solved.find((p) => p.dir === 'down' && p.c === c && r >= p.r && r < p.r + p.word.len);
        cells.push({
          row: r,
          column: c,
          isBlocked: false,
          letter: char,
          acrossWordId: acrossW?.word.id,
          downWordId: downW?.word.id
        });
      }
    }
  }

  const layoutWords: CrosswordLayoutWord[] = solved.map((p) => {
    const coords: LayoutCellCoordinate[] = [];
    for (let k = 0; k < p.word.len; k++) {
      coords.push({
        row: p.dir === 'down' ? p.r + k : p.r,
        col: p.dir === 'across' ? p.c + k : p.c
      });
    }

    return {
      id: p.word.id,
      clue: p.word.clue,
      answer: p.word.answer,
      normalizedAnswer: p.word.norm,
      direction: p.dir,
      startRow: p.r,
      startColumn: p.c,
      length: p.word.len,
      cells: coords,
      number: 1,
      reversed: p.reversed
    };
  });

  layoutWords.sort((a, b) => {
    if (a.startRow !== b.startRow) return a.startRow - b.startRow;
    return a.startColumn - b.startColumn;
  });

  layoutWords.forEach((w, idx) => {
    w.number = idx + 1;
    const cell = cells.find((c) => c.row === w.startRow && c.column === w.startColumn);
    if (cell) {
      cell.clueNumber = w.number;
    }
  });

  const clues: CrosswordLayoutClue[] = layoutWords.map((w) => ({
    id: w.id,
    number: w.number,
    direction: w.direction,
    clue: w.clue,
    length: w.length,
    wordId: w.id,
    reversed: w.reversed
  }));

  const layout: CrosswordLayout = {
    gridRows: GRID_SIZE,
    gridColumns: GRID_SIZE,
    cells,
    words: layoutWords,
    clues,
    blackCells
  };

  const validation = validateCrosswordLayout(layout);
  if (validation.isValid) {
    return layout;
  } else {
    console.log('Validation failed:', validation.items.filter((i) => !i.passed));
    return null;
  }
}

async function run() {
  console.log('Starting Backtracking MRV Solver for Stage 2...');
  for (const size of [19, 18, 17, 20]) {
    console.log(`\n--- Testing ${size}x${size} Grid ---`);
    const solution = solveBacktrack(size, 15000);
    if (solution) {
      console.log(`Found candidate solution for ${size}x${size}! Validating...`);
      const layout = buildAndValidate(size, solution);
      if (layout) {
        console.log(`🏆 SUCCESS! Valid golden layout saved to src/data/golden_stage_02.json`);
        fs.writeFileSync('./src/data/golden_stage_02.json', JSON.stringify(layout, null, 2));
        return;
      }
    }
  }
}

run();
