"""Draws the Detox app icon (three glossy balls) and writes every Android size.
Only needed if you want to change the icon: python3 scripts/make-icons.py  (needs Pillow + numpy)."""
import os, numpy as np
from PIL import Image, ImageFilter

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
RES = os.path.join(ROOT, 'resources', 'android', 'res')
hexc = lambda h: np.array([int(h[i:i+2], 16) for i in (1, 3, 5)], np.float32)

def ball(S, cx, cy, R, base, light, dark):
    y, x = np.mgrid[0:S, 0:S].astype(np.float32)
    dx, dy = (x - cx) / R, (y - cy) / R
    r2 = dx * dx + dy * dy
    nz = np.sqrt(np.clip(1 - r2, 0, 1))
    n = np.stack([dx, dy, nz], -1)
    L = np.array([-.45, -.6, .66], np.float32); L /= np.linalg.norm(L)
    diff = np.clip((n * L).sum(-1), 0, 1)
    t = (diff ** .9)[..., None]
    col = dark * (1 - t) + base * t
    t2 = (np.clip((diff - .62) / .38, 0, 1) ** 1.5)[..., None] * .65
    col = col * (1 - t2) + light * t2
    fres = (1 - nz) ** 3; rim = np.clip(dx * .6 + dy * .8, 0, 1)
    col = col + light * .5 * (fres * rim)[..., None] * .8
    Hh = L + np.array([0, 0, 1], np.float32); Hh /= np.linalg.norm(Hh)
    col = col + 255 * ((np.clip((n * Hh).sum(-1), 0, 1) ** 60)[..., None]) * .85
    hd = ((dx + .38) / .30) ** 2 + ((dy + .46) / .19) ** 2
    blob = (np.exp(-hd * 1.6) * .9)[..., None] * .7
    col = col * (1 - blob) + 255 * blob
    a = np.clip((1 - np.sqrt(r2)) * R / 1.6, 0, 1)
    return np.clip(col, 0, 255), a

def over(canvas, col, a):
    a = a[..., None]
    canvas[..., :3] = canvas[..., :3] * (1 - a) + col * a
    canvas[..., 3:] = np.clip(canvas[..., 3:] + a * (1 - canvas[..., 3:]), 0, 1)

def shadow(S, cx, cy, R, strength=.5):
    sh = np.zeros((S, S), np.float32)
    y, x = np.mgrid[0:S, 0:S].astype(np.float32)
    sh[(((x - cx) / (R * .95)) ** 2 + ((y - cy - R * .98) / (R * .22)) ** 2) <= 1] = strength
    return np.asarray(Image.fromarray((sh * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(R * .12)), np.float32) / 255

BLUE = (hexc('#3f7cff'), hexc('#b4daff'), hexc('#1637c8'))
YEL = (hexc('#ffc933'), hexc('#fff3b0'), hexc('#d9780a'))
PUR = (hexc('#9b5cff'), hexc('#e2cdff'), hexc('#4f1bb8'))

def cluster(S, scale=1.0, bg=None):
    """foreground cluster, centred; scale>1 fills more of the canvas (legacy icons)"""
    c = np.zeros((S, S, 4), np.float32)
    if bg is not None: c[..., :3] = bg; c[..., 3] = 1
    k = S / 1024 * scale
    spec = [(PUR, 372, 640, 84), (YEL, 652, 664, 96), (BLUE, 512, 470, 196)]
    # glow behind the big ball
    y, x = np.mgrid[0:S, 0:S].astype(np.float32)
    g = np.exp(-(((x - 512 * k - (S - 1024 * k) / 2) ** 2 + (y - 470 * k - (S - 1024 * k) / 2) ** 2) / (2 * (260 * k) ** 2))) * .30
    over(c, np.broadcast_to(hexc('#6f8cff'), (S, S, 3)), g.astype(np.float32))
    off = (S - 1024 * k) / 2
    for (b, l, d), cx, cy, R in spec:
        cx, cy, R = cx * k + off, cy * k + off, R * k
        over(c, np.zeros((S, S, 3), np.float32), shadow(S, cx, cy, R, .55))
        col, a = ball(S, cx, cy, R, b, l, d)
        over(c, col, a)
    return c

def bg_gradient(S):
    y, x = np.mgrid[0:S, 0:S].astype(np.float32)
    d = np.sqrt(((x - S / 2) / S) ** 2 + ((y - S * .05) / S) ** 2)
    t = np.clip(d / .9, 0, 1)[..., None]
    return hexc('#2a3aa8') * (1 - t) + hexc('#070b25') * t

def save(arr, path, size):
    im = Image.fromarray(np.clip(arr * np.array([1, 1, 1, 255]), 0, 255).astype(np.uint8), 'RGBA')
    if im.size[0] != size: im = im.resize((size, size), Image.LANCZOS)
    os.makedirs(os.path.dirname(path), exist_ok=True); im.save(path)

S = 1024
fg = cluster(S, .78)            # adaptive foreground: keep inside the 66/108 safe zone
legacy = cluster(S, 1.12, bg_gradient(S))
legacy[..., 3] = 1
DENS = {'mdpi': 1, 'hdpi': 1.5, 'xhdpi': 2, 'xxhdpi': 3, 'xxxhdpi': 4}
yy, xx = np.mgrid[0:S, 0:S].astype(np.float32)
circle = (((xx - S / 2) ** 2 + (yy - S / 2) ** 2) <= (S / 2) ** 2).astype(np.float32)
for name, d in DENS.items():
    save(fg, f'{RES}/mipmap-{name}/ic_launcher_foreground.png', int(108 * d))
    save(legacy, f'{RES}/mipmap-{name}/ic_launcher.png', int(48 * d))
    r = legacy.copy(); r[..., 3] = circle
    save(r, f'{RES}/mipmap-{name}/ic_launcher_round.png', int(48 * d))
    # notification glyph: white ball with a highlight cut out
    n = np.zeros((S, S, 4), np.float32); n[..., :3] = 1
    n[..., 3] = ((((xx - 512) ** 2 + (yy - 512) ** 2) <= 400 ** 2) & ~((((xx - 380) / 150) ** 2 + ((yy - 360) / 90) ** 2) <= 1)).astype(np.float32)
    save(n, f'{RES}/drawable-{name}/ic_stat_detox.png', int(24 * d))
os.makedirs(f'{RES}/values', exist_ok=True)
open(f'{RES}/values/ic_launcher_background.xml', 'w').write('<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#0B1130</color>\n</resources>\n')
Image.new('RGB', (64, 64), (7, 11, 37)).save(f'{ROOT}/resources/android/splash.png')
save(legacy, f'{ROOT}/resources/icon-1024.png', 1024)
save(legacy, f'{ROOT}/www/img/icon-192.png', 192)
save(legacy, f'{ROOT}/www/img/icon-512.png', 512)
print('icons written')
