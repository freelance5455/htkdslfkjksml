import zlib, struct, os, math

def png(path, w, h, pixels):
    raw = b""
    for y in range(h):
        raw += b"\x00" + bytes(pixels[y*w*4:(y+1)*w*4])
    def chunk(t, d):
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    data = b"\x89PNG\r\n\x1a\n"
    data += chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))
    data += chunk(b"IDAT", zlib.compress(raw, 9))
    data += chunk(b"IEND", b"")
    open(path, "wb").write(data)

def crown(size):
    px = bytearray(size*size*4)
    def setp(x, y, r, g, b, a=255):
        if 0 <= x < size and 0 <= y < size:
            i = (y*size+x)*4
            if a == 255:
                px[i:i+4] = bytes((r,g,b,a))
            else:
                al = a/255
                px[i] = int(px[i]*(1-al)+r*al); px[i+1] = int(px[i+1]*(1-al)+g*al)
                px[i+2] = int(px[i+2]*(1-al)+b*al); px[i+3] = 255
    # background radial
    c = size/2
    for y in range(size):
        for x in range(size):
            d = math.hypot(x-c, y-c)/c
            r = int(0x1d + 22*max(0,1-d)); g = int(0x14 + 12*max(0,1-d)); b = int(0x2c + 30*max(0,1-d))
            setp(x, y, r, g, b)
    u = size/100.0
    G = (0xe8, 0xc0, 0x6a)
    GD = (0xb8, 0x8c, 0x38)
    # crown band
    for yy in range(int(52*u), int(68*u)):
        for xx in range(int(22*u), int(78*u)):
            setp(xx, yy, G[0], G[1], G[2])
    # crown body (triangle-ish with peaks)
    for yy in range(int(26*u), int(56*u)):
        t = (yy-26*u)/(30*u)
        left = int(22*u + t*6*u)
        right = int(78*u - t*6*u)
        for xx in range(left, right):
            if 22*u <= xx <= 78*u:
                setp(xx, yy, G[0], G[1], G[2])
    # peaks
    for (px0, ph) in ((22, 26), (50, 18), (78, 26)):
        for k in range(int(ph*u)):
            yy = int((ph-k)*u)
            wdt = max(1, int((1 - k/max(1,ph))*5*u)+1)
            for xx in range(int(px0*u - wdt/2), int(px0*u + wdt/2)):
                setp(xx, yy, G[0], G[1], G[2])
    # jewels
    for (jx, jy) in ((50, 44), (34, 48), (66, 48)):
        setp(int(jx*u), int(jy*u), 0xc0, 0x3a, 0x4a)
        setp(int(jx*u)+1, int(jy*u), 0xc0, 0x3a, 0x4a)
        setp(int(jx*u), int(jy*u)+1, 0xc0, 0x3a, 0x4a)
    # base band darker
    for yy in range(int(62*u), int(70*u)):
        for xx in range(int(22*u), int(78*u)):
            setp(xx, yy, GD[0], GD[1], GD[2])
    return px

for folder, size in [("mipmap-mdpi",48),("mipmap-hdpi",72),("mipmap-xhdpi",96),("mipmap-xxhdpi",144),("mipmap-xxxhdpi",192)]:
    d = "android/app/src/main/res/" + folder
    os.makedirs(d, exist_ok=True)
    px = crown(size)
    png(os.path.join(d, "ic_launcher.png"), size, size, px)
    png(os.path.join(d, "ic_launcher_round.png"), size, size, px)
    print(folder, size, "ok")

# splash / background drawable colors
print("icones gerados")
