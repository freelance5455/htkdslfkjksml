@echo off
cd /d "%~dp0.."
where java >nul 2>nul
if errorlevel 1 (
  echo Java 17 or later is not installed.
  exit /b 1
)
call gradlew.bat --no-daemon --stacktrace assembleDebug
if errorlevel 1 exit /b 1
echo.
echo APK: app\build\outputs\apk\debug\app-debug.apk
