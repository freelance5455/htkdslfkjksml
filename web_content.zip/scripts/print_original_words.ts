import fs from 'fs';
import { normalizeArabicString } from '../src/engine/normalization';

const baseLayout = JSON.parse(fs.readFileSync('./src/data/golden_stage_01.json', 'utf8'));

console.log('Original 25 words in Stage 1:');
baseLayout.words.forEach((w: any) => {
  console.log(`- ${w.answer} (${w.length} أحرف) -> ${w.clue}`);
});
