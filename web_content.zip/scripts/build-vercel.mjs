/**
 * Bundles the Vercel API entry point for local end-to-end testing.
 *
 * Vercel compiles `api/[...route].ts` itself, so this output (build/) is only
 * consumed by `scripts/vercel-dev.mjs` and never deployed.
 */
import { rm } from 'node:fs/promises';
import { mkdirSync } from 'node:fs';
import { build } from 'esbuild';

// Older versions emitted the function here. A leftover .js beside the
// checked-in api/[...route].ts makes Vercel fail with conflicting_file_path.
await rm('api/[...route].js', { force: true });
mkdirSync('build', { recursive: true });

await build({
  entryPoints: ['server/vercel.ts'],
  outfile: 'build/vercel-function.mjs',
  bundle: true,
  platform: 'node',
  target: 'node20',
  format: 'esm',
  sourcemap: false,
  logLevel: 'info',
  // libSQL ships browser/Node builds with optional native bindings, so it must
  // be resolved by Node at runtime rather than inlined here.
  external: ['@libsql/client', '@libsql/client/web'],
  banner: {
    js: "import { createRequire as __cr } from 'module'; const require = __cr(import.meta.url);",
  },
});
