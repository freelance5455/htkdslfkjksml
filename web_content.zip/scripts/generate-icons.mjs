import sharp from 'sharp';
import fs from 'fs';
import path from 'path';

const publicDir = path.resolve(import.meta.dirname, '../public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

// 512x512 Standard PWA Icon SVG
const standardSvg = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <linearGradient id="psRimGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#a7f3d0" stop-opacity="0.95" />
      <stop offset="30%" stop-color="#34d399" stop-opacity="0.75" />
      <stop offset="70%" stop-color="#059669" stop-opacity="0.6" />
      <stop offset="100%" stop-color="#022c22" stop-opacity="0.95" />
    </linearGradient>

    <radialGradient id="psBodyGrad" cx="35%" cy="25%" r="85%">
      <stop offset="0%" stop-color="#065f46" />
      <stop offset="40%" stop-color="#064e3b" />
      <stop offset="80%" stop-color="#022c22" />
      <stop offset="100%" stop-color="#011b15" />
    </radialGradient>

    <linearGradient id="psGlossGrad" x1="50%" y1="0%" x2="50%" y2="100%">
      <stop offset="0%" stop-color="#ffffff" stop-opacity="0.45" />
      <stop offset="40%" stop-color="#ffffff" stop-opacity="0.15" />
      <stop offset="100%" stop-color="#ffffff" stop-opacity="0.0" />
    </linearGradient>

    <linearGradient id="psStemGrad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#a7f3d0" />
      <stop offset="25%" stop-color="#34d399" />
      <stop offset="75%" stop-color="#059669" />
      <stop offset="100%" stop-color="#047857" />
    </linearGradient>

    <linearGradient id="psUpperArmGrad" x1="0%" y1="100%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#10b981" />
      <stop offset="50%" stop-color="#34d399" />
      <stop offset="85%" stop-color="#a7f3d0" />
      <stop offset="100%" stop-color="#ffffff" />
    </linearGradient>

    <linearGradient id="psLowerArmGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#059669" />
      <stop offset="55%" stop-color="#10b981" />
      <stop offset="100%" stop-color="#14b8a6" />
    </linearGradient>
  </defs>

  <!-- Base Squircle Shield with Metallic Bevel Rim -->
  <rect
    x="16"
    y="16"
    width="480"
    height="480"
    rx="128"
    fill="url(#psBodyGrad)"
    stroke="url(#psRimGrad)"
    stroke-width="12"
  />

  <!-- Gloss Arc Highlight Layer -->
  <path
    d="M 28 144 C 28 80 80 28 144 28 L 368 28 C 432 28 484 80 484 144 C 484 196 398 256 256 256 C 114 256 28 196 28 144 Z"
    fill="url(#psGlossGrad)"
  />

  <!-- Ambient Occlusion Bottom Vignette -->
  <path
    d="M 32 368 C 32 432 84 484 148 484 L 364 484 C 428 484 480 432 480 368 C 480 316 408 276 256 276 C 104 276 32 316 32 368 Z"
    fill="#011812"
    opacity="0.35"
  />

  <!-- Sculpted 3D 'K' Monogram -->
  <g>
    <!-- Vertical Spine -->
    <rect x="112" y="108" width="66" height="296" rx="33" fill="url(#psStemGrad)" />
    <line
      x1="128"
      y1="128"
      x2="128"
      y2="384"
      stroke="#ffffff"
      stroke-width="8"
      stroke-opacity="0.75"
      stroke-linecap="round"
    />

    <!-- Diagonal Upper Right Arm -->
    <path
      d="M 152 272 L 344 116 C 358 104 380 114 380 132 C 380 144 372 154 362 162 L 208 296 Z"
      fill="url(#psUpperArmGrad)"
    />

    <!-- Diagonal Lower Right Arm -->
    <path
      d="M 160 256 L 356 384 C 368 392 376 406 368 420 C 362 430 348 434 336 426 L 140 292 Z"
      fill="url(#psLowerArmGrad)"
    />

    <!-- Beveled Intersection Nexus Pill -->
    <circle cx="178" cy="276" r="28" fill="#10b981" />
    <circle cx="178" cy="276" r="16" fill="#a7f3d0" />

    <!-- Lens Flare Spark on Upper Apex -->
    <g transform="translate(372, 128)">
      <circle cx="0" cy="0" r="18" fill="#ffffff" opacity="0.95" />
      <polygon points="0,-36 7,-8 36,0 7,8 0,36 -7,8 -36,0 -7,-8" fill="#a7f3d0" />
      <polygon points="0,-22 4,-5 22,0 4,5 0,22 -4,5 -22,0 -4,-5" fill="#ffffff" />
      <circle cx="0" cy="0" r="5" fill="#ffffff" />
    </g>
  </g>
</svg>
`;

// Maskable Icon with safe zone margin (padding)
const maskableSvg = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <radialGradient id="psBgGrad" cx="35%" cy="25%" r="85%">
      <stop offset="0%" stop-color="#065f46" />
      <stop offset="40%" stop-color="#064e3b" />
      <stop offset="80%" stop-color="#022c22" />
      <stop offset="100%" stop-color="#011b15" />
    </radialGradient>
    <linearGradient id="mStemGrad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#a7f3d0" />
      <stop offset="50%" stop-color="#34d399" />
      <stop offset="100%" stop-color="#059669" />
    </linearGradient>
    <linearGradient id="mUpperArmGrad" x1="0%" y1="100%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#10b981" />
      <stop offset="50%" stop-color="#34d399" />
      <stop offset="100%" stop-color="#ffffff" />
    </linearGradient>
    <linearGradient id="mLowerArmGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#059669" />
      <stop offset="100%" stop-color="#14b8a6" />
    </linearGradient>
  </defs>

  <!-- Full Bleed Background for Maskable Icon Safe Zone -->
  <rect width="512" height="512" fill="url(#psBgGrad)" />

  <!-- Centered Scaled K Monogram inside Safe Circle (408px diameter) -->
  <g transform="translate(48, 48) scale(0.8125)">
    <!-- Vertical Spine -->
    <rect x="112" y="108" width="66" height="296" rx="33" fill="url(#mStemGrad)" />
    <line x1="128" y1="128" x2="128" y2="384" stroke="#ffffff" stroke-width="8" stroke-opacity="0.8" stroke-linecap="round" />

    <!-- Diagonal Upper Right Arm -->
    <path d="M 152 272 L 344 116 C 358 104 380 114 380 132 C 380 144 372 154 362 162 L 208 296 Z" fill="url(#mUpperArmGrad)" />

    <!-- Diagonal Lower Right Arm -->
    <path d="M 160 256 L 356 384 C 368 392 376 406 368 420 C 362 430 348 434 336 426 L 140 292 Z" fill="url(#mLowerArmGrad)" />

    <!-- Nexus Center -->
    <circle cx="178" cy="276" r="28" fill="#10b981" />
    <circle cx="178" cy="276" r="16" fill="#a7f3d0" />

    <!-- Lens Flare Spark -->
    <g transform="translate(372, 128)">
      <circle cx="0" cy="0" r="18" fill="#ffffff" opacity="0.95" />
      <polygon points="0,-36 7,-8 36,0 7,8 0,36 -7,8 -36,0 -7,-8" fill="#a7f3d0" />
      <polygon points="0,-22 4,-5 22,0 4,5 0,22 -4,5 -22,0 -4,-5" fill="#ffffff" />
    </g>
  </g>
</svg>
`;

async function generate() {
  fs.writeFileSync(path.join(publicDir, 'icon.svg'), standardSvg);
  console.log('Saved icon.svg');

  await sharp(Buffer.from(standardSvg))
    .resize(512, 512)
    .png()
    .toFile(path.join(publicDir, 'pwa-512x512.png'));
  console.log('Saved pwa-512x512.png');

  await sharp(Buffer.from(standardSvg))
    .resize(192, 192)
    .png()
    .toFile(path.join(publicDir, 'pwa-192x192.png'));
  console.log('Saved pwa-192x192.png');

  await sharp(Buffer.from(standardSvg))
    .resize(180, 180)
    .png()
    .toFile(path.join(publicDir, 'apple-touch-icon.png'));
  console.log('Saved apple-touch-icon.png');

  await sharp(Buffer.from(maskableSvg))
    .resize(512, 512)
    .png()
    .toFile(path.join(publicDir, 'pwa-maskable-512x512.png'));
  console.log('Saved pwa-maskable-512x512.png');

  await sharp(Buffer.from(standardSvg))
    .resize(64, 64)
    .png()
    .toFile(path.join(publicDir, 'favicon.ico'));
  console.log('Saved favicon.ico');

  console.log('All PWA and APK icons generated successfully!');
}

generate().catch((err) => {
  console.error(err);
  process.exit(1);
});
