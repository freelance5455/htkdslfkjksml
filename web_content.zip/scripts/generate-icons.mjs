import fs from 'fs';
import zlib from 'zlib';

function createPng(width, height, getPixel) {
  // RGBA buffer with filter byte 0 at start of each scanline
  const scanlineSize = width * 4 + 1;
  const rawData = Buffer.alloc(height * scanlineSize);
  
  for (let y = 0; y < height; y++) {
    const lineOffset = y * scanlineSize;
    rawData[lineOffset] = 0; // Filter None
    for (let x = 0; x < width; x++) {
      const pxOffset = lineOffset + 1 + x * 4;
      const [r, g, b, a] = getPixel(x, y, width, height);
      rawData[pxOffset] = r;
      rawData[pxOffset + 1] = g;
      rawData[pxOffset + 2] = b;
      rawData[pxOffset + 3] = a;
    }
  }

  const compressed = zlib.deflateSync(rawData);

  function createChunk(type, data) {
    const len = Buffer.alloc(4);
    len.writeUInt32BE(data.length, 0);
    const typeBuf = Buffer.from(type, 'ascii');
    const crcBuf = Buffer.alloc(4);
    
    // CRC-32
    let c = 0xffffffff;
    const update = (buf) => {
      for (let i = 0; i < buf.length; i++) {
        c ^= buf[i];
        for (let j = 0; j < 8; j++) {
          c = (c >>> 1) ^ (-(c & 1) & 0xedb88320);
        }
      }
    };
    update(typeBuf);
    update(data);
    c ^= 0xffffffff;
    crcBuf.writeUInt32BE(c >>> 0, 0);

    return Buffer.concat([len, typeBuf, data, crcBuf]);
  }

  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;  // bit depth
  ihdr[9] = 6;  // RGBA
  ihdr[10] = 0; // compression
  ihdr[11] = 0; // filter
  ihdr[12] = 0; // interlace

  const ihdrChunk = createChunk('IHDR', ihdr);
  const idatChunk = createChunk('IDAT', compressed);
  const iendChunk = createChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

function brandPixel(x, y, w, h, isMaskable = false) {
  const cx = w / 2;
  const cy = h / 2;
  const rCorner = w * 0.22;
  const dx = Math.abs(x - cx);
  const dy = Math.abs(y - cy);
  const innerHalf = w / 2 - rCorner;

  let inRoundedRect = false;
  if (dx <= innerHalf && dy <= h / 2) inRoundedRect = true;
  else if (dy <= innerHalf && dx <= w / 2) inRoundedRect = true;
  else {
    const cornerDx = dx - innerHalf;
    const cornerDy = dy - innerHalf;
    if (cornerDx * cornerDx + cornerDy * cornerDy <= rCorner * rCorner) {
      inRoundedRect = true;
    }
  }

  if (!inRoundedRect && !isMaskable) {
    return [0, 0, 0, 0];
  }

  // Background gradient: slate-900 to slate-950
  const t = (x + y) / (w + h);
  let r = Math.round(30 * (1 - t) + 15 * t);
  let g = Math.round(41 * (1 - t) + 23 * t);
  let b = Math.round(59 * (1 - t) + 42 * t);
  let a = 255;

  // Center emblem: blue-violet gradient circle
  const distCenter = Math.hypot(x - cx, y - cy);
  const emblemRadius = w * 0.28;
  if (distCenter <= emblemRadius) {
    const et = (x - (cx - emblemRadius)) / (emblemRadius * 2);
    r = Math.round(96 * (1 - et) + 192 * et);
    g = Math.round(165 * (1 - et) + 132 * et);
    b = Math.round(250 * (1 - et) + 252 * et);
  }

  return [r, g, b, a];
}

if (!fs.existsSync('public')) {
  fs.mkdirSync('public', { recursive: true });
}

const p192 = createPng(192, 192, (x, y, w, h) => brandPixel(x, y, w, h, false));
fs.writeFileSync('public/pwa-192x192.png', p192);
fs.writeFileSync('public/apple-touch-icon.png', p192);

const p512 = createPng(512, 512, (x, y, w, h) => brandPixel(x, y, w, h, false));
fs.writeFileSync('public/pwa-512x512.png', p512);

const pMaskable = createPng(512, 512, (x, y, w, h) => brandPixel(x, y, w, h, true));
fs.writeFileSync('public/pwa-maskable-512x512.png', pMaskable);

console.log("Icons generated successfully.");

