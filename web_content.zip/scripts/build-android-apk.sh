#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# Build a real Keep Tracked .apk WITHOUT Android Studio.
#
# Requirements (command line only):
#   1. Node 18+
#   2. JDK 17            -> apt install openjdk-17-jdk   (or brew install openjdk@17)
#   3. Android SDK cmdline tools (no Studio):
#        mkdir -p $HOME/android-sdk/cmdline-tools
#        download "commandlinetools-linux-*.zip" from developer.android.com/studio#command-line-tools
#        unzip it into $HOME/android-sdk/cmdline-tools/latest
#        export ANDROID_HOME=$HOME/android-sdk
#        sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"
#
# Usage:
#   CAP_SERVER_URL=https://your-keep-tracked.example.com ./scripts/build-android-apk.sh
# ---------------------------------------------------------------------------
set -euo pipefail

: "${CAP_SERVER_URL:?Set CAP_SERVER_URL to your running Keep Tracked URL}"
command -v java >/dev/null 2>&1 || { echo "✗ Install JDK 17 first"; exit 1; }
[ -n "${ANDROID_HOME:-}" ] || { echo "✗ Set ANDROID_HOME (Android SDK cmdline tools)"; exit 1; }

echo "→ installing Capacitor CLI"
npm i -D @capacitor/core @capacitor/cli @capacitor/android

echo "→ building the web app"
npm run build

echo "→ adding the Android platform (first run only)"
npx cap add android || true

echo "→ syncing web assets + server url ($CAP_SERVER_URL)"
npx cap sync android

echo "→ assembling debug APK with Gradle (no Android Studio involved)"
cd android
./gradlew assembleDebug

APK="$PWD/app/build/outputs/apk/debug/app-debug.apk"
echo
echo "✓ APK ready: $APK"
echo "  copy it to the phone and install (allow unknown sources), or run:"
echo "  adb install -r $APK"
