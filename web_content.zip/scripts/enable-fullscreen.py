from pathlib import Path
import sys

root = Path("android/app/src/main")
files = list(root.rglob("MainActivity.java"))
if not files:
    print("Java MainActivity not found; default system bars will remain.")
    sys.exit(0)

p = files[0]
s = p.read_text(encoding="utf-8")
if "WindowInsetsController" in s:
    print("Immersive mode already configured.")
    sys.exit(0)

s = s.replace(
    "import com.getcapacitor.BridgeActivity;",
    "import com.getcapacitor.BridgeActivity;\\n"
    "import android.os.Build;\\n"
    "import android.os.Bundle;\\n"
    "import android.view.View;\\n"
    "import android.view.WindowInsets;\\n"
    "import android.view.WindowInsetsController;"
)
body = '''
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        hideSystemBars();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    private void hideSystemBars() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                );
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            );
        }
    }
'''
s = s.replace("public class MainActivity extends BridgeActivity {",
              "public class MainActivity extends BridgeActivity {\\n" + body)
p.write_text(s, encoding="utf-8")
print(f"Configured immersive mode in {p}")
