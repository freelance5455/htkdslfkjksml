import { chromium } from '@playwright/test';

const browser = await chromium.launch({ headless: true });
const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });

await page.setContent(`
  <!DOCTYPE html>
  <html>
    <head>
      <style>
        body { margin: 0; background: #000; overflow: hidden; }
        .green-bg {
          position: absolute;
          inset: 0;
          background: #00dd44;
        }
        svg {
          position: absolute;
          inset: 0;
          width: 100%;
          height: 100%;
        }
      </style>
    </head>
    <body>
      <div class="green-bg"></div>
      <svg viewBox="0 0 1000 562.5" preserveAspectRatio="none">
        <path
          fill="#000000"
          fill-rule="evenodd"
          d="
            M 0 0 H 1000 V 562.5 H 0 Z

            M 85 96
            Q 275 66 470 96
            Q 486 102 489 116
            Q 504 300 489 486
            Q 486 500 470 506
            Q 275 536 85 506
            Q 69 500 66 486
            Q 51 300 66 116
            Q 69 102 85 96 Z

            M 530 96
            Q 725 66 915 96
            Q 931 102 934 116
            Q 949 300 934 486
            Q 931 500 915 506
            Q 725 536 530 506
            Q 514 500 511 486
            Q 496 300 511 116
            Q 514 102 530 96 Z
          "
        />
        <line
          x1="500"
          y1="562.5"
          x2="500"
          y2="362"
          stroke="#ffffff"
          stroke-width="2.6"
          stroke-linecap="round"
        />
      </svg>
    </body>
  </html>
`);

await page.screenshot({ path: 'artifacts/test-mask-v3.png' });
await browser.close();
console.log('Saved test-mask-v3.png');
