// Build the offline hadith database from raw Thaqalayn dumps.
// Usage: node scripts/build-data.mjs /path/to/raw
import fs from 'fs';
import zlib from 'zlib';

const RAW = process.argv[2] || '/tmp/h/raw';

const BOOKS = {
  'Al-Kafi-Volume-1-Kulayni': 'الكافي ج١',
  'Al-Kafi-Volume-2-Kulayni': 'الكافي ج٢',
  'Al-Kafi-Volume-3-Kulayni': 'الكافي ج٣',
  'Al-Kafi-Volume-4-Kulayni': 'الكافي ج٤',
  'Al-Kafi-Volume-5-Kulayni': 'الكافي ج٥',
  'Al-Kafi-Volume-6-Kulayni': 'الكافي ج٦',
  'Al-Kafi-Volume-7-Kulayni': 'الكافي ج٧',
  'Al-Kafi-Volume-8-Kulayni': 'الكافي ج٨',
  'Man-La-Yahduruh-al-Faqih-Volume-1-Saduq': 'من لا يحضره الفقيه ج١',
  'Man-La-Yahduruh-al-Faqih-Volume-2-Saduq': 'من لا يحضره الفقيه ج٢',
  'Man-La-Yahduruh-al-Faqih-Volume-3-Saduq': 'من لا يحضره الفقيه ج٣',
  'Man-La-Yahduruh-al-Faqih-Volume-4-Saduq': 'من لا يحضره الفقيه ج٤',
  'Man-La-Yahduruh-al-Faqih-Volume-5-Saduq': 'من لا يحضره الفقيه ج٥',
  'Tahdhib-al-Ahkam-Volume-1-Tusi': 'تهذيب الأحكام ج١',
  'Tahdhib-al-Ahkam-Volume-2-Tusi': 'تهذيب الأحكام ج٢',
  'Tahdhib-al-Ahkam-Volume-3-Tusi': 'تهذيب الأحكام ج٣',
  'Tahdhib-al-Ahkam-Volume-4-Tusi': 'تهذيب الأحكام ج٤',
  'Mujam-al-Ahadith-al-Mutabara-Muhsini': 'معجم الأحاديث المعتبرة',
  'Al-Khisal-Saduq': 'الخصال',
  'Uyun-akhbar-al-Rida-Volume-1-Saduq': 'عيون أخبار الرضا ج١',
};
const bookIds = Object.keys(BOOKS);
const bookNames = bookIds.map((k) => BOOKS[k]);

const GRADERS = {
  'Allamah Baqir al-Majlisi': 'العلامة المجلسي (مرآة العقول)',
  'Ali Akbar al-Ghaffari': 'علي أكبر الغفاري (تعليق التهذيب/الفقيه)',
  'Shaykh Hadi al-Najafi': 'الشيخ هادي النجفي (موسوعة أحاديث أهل البيت)',
  'Shaykh Asif al-Mohseni': 'الشيخ آصف المحسني',
  'Shaykh Baqir al-Behbudi': 'الشيخ البهبودي',
};
const graderNames = Object.values(GRADERS);
const graderKeys = Object.keys(GRADERS);

const strip = (s) => s.replace(/[\u064B-\u065F\u0670\u0640]/g, '');
const norm = (s) =>
  strip(s)
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/\s+/g, ' ');

const T3 = /^(صحيح|صحيح على الظاهر|صحيح ظاهرا|صحيحة الاسناد|صحيح الاسناد|صحيحه الاسناد)$/;
const T2 = /^(حسن كالصحيح|موثق كالصحيح|كالصحيح|صحيح وآخره مرسل|صحيح واخره مرسل)$/;
const T1 =
  /^(حسن|موثق|معتبر|معتبرة الاسناد|معتبره الاسناد|حسن موثق|حسن او موثق|موثق او حسن|كالموثق|حسن على الظاهر|معتبر الاسناد)$/;

const gradeStrs = [];
const gradeIdx = (s) => {
  let i = gradeStrs.indexOf(s);
  if (i < 0) {
    gradeStrs.push(s);
    i = gradeStrs.length - 1;
  }
  return i;
};

function gradeOf(h) {
  let best = { tier: 0 };
  for (const g of h.gradingsFull || []) {
    const gr = norm((g.grade_ar || '').trim()).trim();
    const gk = graderKeys.indexOf(g.author.name_en);
    if (gk < 0) continue;
    let t = 0;
    if (T3.test(gr)) t = 3;
    else if (T2.test(gr)) t = 2;
    else if (T1.test(gr)) t = 1;
    if (t > best.tier) best = { tier: t, grader: gk, str: (g.grade_ar || '').trim().replace(/\s+/g, ' ') };
  }
  return best;
}

// ---------------- Speaker detection -----------------
const MASOOMS = [
  'النبي محمد ﷺ', // 0
  'الإمام علي (ع)', // 1
  'السيدة فاطمة الزهراء (ع)', // 2
  'الإمام الحسن المجتبى (ع)', // 3
  'الإمام الحسين (ع)', // 4
  'الإمام السجاد (ع)', // 5
  'الإمام الباقر (ع)', // 6
  'الإمام الصادق (ع)', // 7
  'الإمام الكاظم (ع)', // 8
  'الإمام الرضا (ع)', // 9
  'الإمام الجواد (ع)', // 10
  'الإمام الهادي (ع)', // 11
  'الإمام العسكري (ع)', // 12
  'الإمام المهدي (عج)', // 13
  'الإمام أبو الحسن (ع) – الكاظم أو الرضا', // 14
  'أحد أهل البيت (ع)', // 15
];
const FATHER = { 1: null, 3: 1, 4: 1, 5: 4, 6: 5, 7: 6, 8: 7, 9: 8, 10: 9, 11: 10, 12: 11, 13: 12 };

function nameToId(ctx) {
  const c = ctx.replace(/[()]/g, ' ').replace(/(^|\s)اب[وا](?=\s)/g, '$1ابي').replace(/\s+/g, ' ').trim();
  const tail = c.slice(-40);
  const has = (re) => re.test(tail);
  if (has(/رسول الله|رسول اللّه|النبي|نبي الله/)) return 0;
  if (has(/فاطمة|فاطمه|الزهراء/)) return 2;
  if (has(/القائم|المهدي|صاحب الزمان|صاحب هذا الامر|الحجة/)) return 13;
  if (has(/علي بن الحسين|زين العابدين|السجاد/)) return 5;
  if (has(/علي بن موسى|الرضا/)) return 9;
  if (has(/علي بن محمد|الهادي|ابي الحسن الثالث/)) return 11;
  if (has(/الحسن بن علي|الحسن المجتبى|الحسن العسكري|ابي محمد الحسن/)) return has(/العسكري/) ? 12 : 3;
  if (has(/ابي عبد الله الحسين|الحسين بن علي|سيد الشهداء/)) return 4;
  if (has(/امير المؤمنين|علي بن ابي طالب/)) return 1;
  if (has(/ابي جعفر الثاني|الجواد|محمد بن علي الجواد/)) return 10;
  if (has(/ابي جعفر|الباقر/)) return 6;
  if (has(/ابي عبد الله|الصادق|جعفر بن محمد/)) return 7;
  if (has(/ابي الحسن الاول|ابي الحسن موسى|ابي ابراهيم|العبد الصالح|الكاظم|العالم|موسى بن جعفر/)) return 8;
  if (has(/ابي الحسن الثاني/)) return 9;
  if (has(/ابي الحسن/)) return 14;
  if (has(/ابي محمد|ابو محمد/)) return 12;
  if (has(/ابيه|ابنه|جده|ابائه/)) return -1; // relative
  if (has(/الحسين/)) return 4;
  if (has(/الحسن/)) return 3;
  return 15;
}

const MARK =
  /(?:\(\s*)?(?:عليه|عليهما|عليها|عليهم)\s*السلام(?:\s*\))?|(?:\(\s*)?صلى الله عليه\s*(?:و\s*)?ا?له(?:\s*و?سلم)?(?:\s*\))?|(?:\(\s*)?صلوات الله عليه(?:\s*\))?|\(\s*(?:ع|ص|عج)\s*\)|(?<=\s)ع(?=\s*[:«]|\s+قال)/g;
const QRE = /(?:^|\s)(?:قال|فقال|قالت|فقالت|قالا|يقول|وقال|يقولان|سمعته يقول)(?=\s|:|«|»|$)/;

function analyze(orig) {
  let n = '';
  const map = [];
  for (let i = 0; i < orig.length; i++) {
    const ch = orig[i];
    if (/[\u064B-\u065F\u0670\u0640]/.test(ch)) continue;
    let c = ch;
    if ('أإآٱ'.includes(c)) c = 'ا';
    else if (c === 'ى') c = 'ي';
    n += c;
    map.push(i);
  }
  map.push(orig.length);
  const marks = [...n.matchAll(MARK)];
  if (!marks.length) return { speaker: -2, split: 0, quoted: [] };
  const first = marks[0];
  const firstEnd = first.index + first[0].length;

  // 1) narrator-style: "... قال سمعت أبا عبد الله (ع) يقول ..." (a قال before the first marker)
  let splitN = -1;
  let limit;
  const before = n.slice(0, first.index);
  const bq = [...before.matchAll(/(?:^|\s)(?:قال|قالت|قالا)(?=\s|:|«|»|$)/g)];
  if (bq.length && bq[0].index > 25) {
    const b = bq[0];
    splitN = b.index + b[0].length;
    limit = firstEnd; // speaker is first marker
  } else {
    const rest = n.slice(firstEnd);
    const qm = QRE.exec(rest);
    if (qm && qm.index < 400) {
      splitN = firstEnd + qm.index + qm[0].length;
      limit = firstEnd + qm.index;
    } else {
      const cm = /^\s*[:«"]/.exec(rest);
      if (cm) {
        splitN = firstEnd + cm[0].length;
        limit = firstEnd;
      } else {
        limit = firstEnd;
      }
    }
  }
  const cands = marks.filter((m) => m.index + m[0].length <= limit + 1);
  let speaker = 15;
  let prev = null;
  for (const m of cands) {
    const ctxStart = Math.max(0, m.index - 45);
    let id = nameToId(n.slice(ctxStart, m.index));
    if (id === -1) id = prev != null && FATHER[prev] != null ? FATHER[prev] : 15;
    speaker = id;
    prev = id;
  }
  let split = 0;
  if (splitN >= 0) {
    let o = map[Math.min(splitN, map.length - 1)];
    while (o < orig.length && /[\s:：«"]/.test(orig[o])) o++;
    split = o;
  }
  const quoted = [];
  const hs = splitN >= 0 ? splitN : firstEnd;
  const head = n.slice(hs, hs + 2500);
  const addQ = (id) => {
    if (id !== speaker && !quoted.includes(id)) quoted.push(id);
  };
  if (/(?:قال|قالت|يقول|عن|روى)\s+(?:رسول الله|النبي)/.test(head) || /^\W*(?:رسول الله|النبي)/.test(head)) addQ(0);
  if (/(?:قال|يقول)\s+(?:امير المؤمنين|علي)\b/.test(head) || /^\W*امير المؤمنين/.test(head)) addQ(1);
  if (/فاطمة|فاطمه|الزهراء/.test(head)) addQ(2);
  if (/القائم|المهدي|صاحب الزمان|صاحب هذا الامر/.test(head)) addQ(13);
  return { speaker, split, quoted };
}

// ---------------- Topics -----------------
const TOPICS = [
  ['food', 'الأكل والطعام', '🍽️', /\b(food|eating|eat|meal|bread|meat|fruit|fruits|dates|honey|vinegar|oil|salt|milk|rice|vegetable|vegetables|dinner|supper|breakfast|cooking|banquet|hospitality|guest|feast|wolf|hunger|full stomach|satiety|dish|bowl|table|cup|stew|sweet|butter|fat|onion|garlic|pomegranate|grapes?|apple|quince|melon|egg|fish|lentils|barley|wheat|flour|dessert|helva)\b/i],
  ['drink', 'الشرب والماء', '💧', /\b(drink|drinking|drinks|water|thirst|beverage|beverages|wine|intoxicant|intoxicants|fuqqa|nabidh|barley water)\b/i],
  ['walk', 'المشي والسفر والطريق', '🚶', /\b(walk|walking|travel|travell?ing|journey|road|roads|riding|ride|mount|camel|horse|donkey|mule|footwear|shoes|sandals|trip|caravan|companion on journey|way)\b/i],
  ['sleep', 'النوم والراحة', '🌙', /\b(sleep|sleeping|bed|bedding|wake|waking|nap|dream|dreams|rest|siesta)\b/i],
  ['dress', 'اللباس والزينة والنظافة', '👕', /\b(cloth|clothes|clothing|dress|garment|garments|wear|wearing|turban|silk|perfume|scent|fragrance|musk|hair|beard|nails?|comb|kohl|antimony|ring|rings|adornment|bath|bathroom|henna|dye|shaving|razor|toothpick|tooth|teeth|cleanliness|beautif|cap|robe|cloak|gold|jewel|mirror|oil of)\b/i],
  ['health', 'الطب والصحة والمرض', '⚕️', /\b(medicine|medical|illness|ill|sick|sickness|disease|diseases|cure|remedy|treatment|health|patient|pain|fever|doctor|physician|cupping|bloodletting|cure|healing|visiting the sick|leprosy|plague|eye|blind|enema|hijama)\b/i],
  ['prayer', 'الصلاة', '🕌', /\b(prayer|prayers|salat|salah|adhan|azan|iqamah|qibla|prostration|bowing|ruku|sajda|sujud|tashahhud|taslim|qunut|takbir|congregation|friday|mosque|mosques|imam of prayer|shortening|traveler's prayer|witr|nafila|prayer of|rak'?ah|rakat|sahw|forgetfulness in prayer|qada|tasbih|nawafil|night prayer|eclipse|rain prayer|jum'?ah|eid prayer)\b/i],
  ['purity', 'الطهارة والوضوء والغسل', '🚿', /\b(purity|purif|ablution|wudu|ghusl|tayammum|najas|impurity|impure|urine|feces|toilet|janabah|janaba|menstruation|menses|haid|hayd|istihada|postnatal|nifas|well|wells|clean|unclean|dirty|dirt|purif|bathing|washing)\b/i],
  ['fasting', 'الصيام وشهر رمضان', '🌙', /\b(fast|fasting|fasts|ramadan|ramadhan|iftar|suhoor|sahur|sawm|saum|expiation of fast|i'?tikaf|itikaf|breaking the fast)\b/i],
  ['zakat', 'الزكاة والخمس والصدقة', '🤲', /\b(zakat|zakah|khums|charity|alms|sadaqa|sadaqah|fitra|fitrah|giving|beggar|begging|poor|needy|donation|spend|spending|endowment|waqf|gift|gifts|generosity|generous|miserly|miser|stinginess)\b/i],
  ['hajj', 'الحج والعمرة', '🕋', /\b(hajj|umrah|umra|pilgrimage|ihram|tawaf|sa'?i|arafat|arafah|mina|muzdalifah|ka'?ba|kaaba|mecca|makkah|sacred mosque|haram|sacrifice|zamzam|black stone|stoning|jamarat|talbiyah|pilgrim|medina|madinah|ziyara|ziyarat|visiting the grave|shrine|karbala)\b/i],
  ['death', 'الموت والقبر والجنازة', '⚰️', /\b(death|dying|dead|die|burial|bury|funeral|grave|graves|shroud|kafan|hanut|coffin|bier|mourning|grief|condolence|barzakh|deceased|corpse|last moment|dying person|talqin|dying|lament|weeping|crying|tears)\b/i],
  ['hereafter', 'يوم القيامة والآخرة والجنة والنار', '⏳', /\b(resurrection|hereafter|judgment|judgement|reckoning|hellfire|hell|paradise|heaven|garden|fire|hour|day of|afterlife|intercession|sirat|scale|scales|accountab|punishment|torment|reward|resurrect|the next world|last day|trumpet|signs of the hour)\b/i],
  ['marriage', 'الزواج والأسرة', '💍', /\b(marriage|marry|married|wife|wives|husband|spouse|women|woman|bride|dowry|mahr|nikah|wedding|temporary marriage|mut'?ah|virgin|polygamy|concubine|slave woman|female slave|intercourse|sexual|chaste|chastity|family|household|mother|father)\b/i],
  ['children', 'الأولاد والتربية والوالدان', '👨‍👧', /\b(child|children|son|sons|daughter|daughters|baby|infant|newborn|birth|born|aqiqah|aqeeqah|circumcision|naming|names|name|parents|parent|kindness to parents|upbringing|orphan|orphans|breastfeeding|nursing|suckling|pregnan|fosterage|relatives|kinship|ties of kinship|womb|uncle|aunt|siblings|brother|sister)\b/i],
  ['divorce', 'الطلاق والعدة والإرث والوصية', '📜', /\b(divorce|divorcing|talaq|iddah|waiting period|inheritance|inherit|heir|heirs|will|wills|bequest|testament|legacy|zihar|li'?an|khul'?|ila|custody|maintenance)\b/i],
  ['trade', 'التجارة والمعاش والمال', '💰', /\b(trade|trading|business|sale|sell|selling|buy|buying|purchase|merchant|market|markets|debt|debts|loan|loans|usury|riba|interest|wealth|money|profit|earning|earnings|livelihood|provision|sustenance|work|labor|labour|craft|profession|occupation|farm|farming|agriculture|land|lands|rent|renting|hire|hiring|partnership|pledge|mortgage|trust|deposit|bankrupt|price|prices|hoarding|measure|weigh|weighing|transaction|contract|contracts|gold|silver|dirham|dinar|income|salary|wage|wages|worker|creditor|debtor|property|rizq|rizk|sustenance)\b/i],
  ['judgment', 'القضاء والحدود والديات', '⚖️', /\b(judge|judges|judging|judgment|judicial|court|testimony|witness|witnesses|oath|oaths|vow|vows|hudud|hadd|prescribed punishment|punishments|retaliation|qisas|blood money|diyah|diya|theft|steal|stealing|adultery|fornication|fornicat|slander|qadhf|murder|kill|killing|crime|compensation|penalty|ruling|disputes?|claim|claims|evidence|lost property|apostate|apostasy|sodomy|homosexual)\b/i],
  ['knowledge', 'العلم والعقل والتعلم', '📚', /\b(knowledge|knowledgeable|science|scholar|scholars|learn|learning|teach|teaching|teacher|education|intellect|reason|wisdom|ignorance|ignorant|aql|jahl|understanding|jurisprudence|fiqh|narrat|hadith|traditions|memoriz|writing|books|student|opinion|qiyas|analogy|knower|thinking|thought|contemplation|reflection|ulama|disagree|differences|ijtihad)\b/i],
  ['ethics', 'الأخلاق والآداب', '🌟', /\b(character|morals|morality|ethics|etiquette|manners|manner|good deeds?|honesty|truthful|truth|lying|lie|liar|trustworthiness|patience|gratitude|thanks|thankful|anger|humility|humble|pride|arrogance|arrogant|envy|jealousy|jealous|backbiting|slander|gossip|forgiveness|forgive|pardon|mercy|compassion|kindness|generosity|modesty|shyness|bashfulness|modest|piety|righteousness|virtue|virtues|vice|vices|sin|sins|greed|covetous|hypocrisy|hypocrite|hypocrites|pretense|showing off|riya|vanity|self|ego|desire|desires|lust|temper|rage|haste|moderation|gentleness|smile|joy|sorrow|worry|anxiety|contentment|content|abstinence|asceticism|zuhd|world|worldly|dunya|vanity of|good behavior|conduct|behavior|bad|evil|good|goodness|justice|oppression|oppressor|tyrant|wrong|injustice|promise|promises|secret|secrets|keeping secrets|trust)\b/i],
  ['faith', 'الإيمان والكفر والتوحيد', '☀️', /\b(belief|believer|believers|faith|disbelief|disbeliever|unbelief|unbeliever|kufr|shirk|polytheism|polytheist|islam|muslim|tawhid|oneness|unity of god|god|allah|attributes|names of allah|creation|created|decree|destiny|fate|qadar|qada|will of god|bada|tawakkul|reliance|trust in god|certainty|yaqin|sincerity|ikhlas|fear of god|taqwa|hope|fear|love of god|worship|obedience|disobedience|hypocr|apostasy|doubt|doubts|guidance|misguidance|signs|proof|proofs|prophet hood|prophethood|prophets|messengers|angels|jinn|satan|devil|iblis|pharaoh|soul|spirit|heart|hearts|sealed)\b/i],
  ['dua', 'الدعاء والذكر وقراءة القرآن', '📿', /\b(supplication|supplications|dua|du'?a|dhikr|remembrance|remember|tasbih|glorification|istighfar|seeking forgiveness|repentance|repent|tawbah|quran|qur'?an|recitation|recite|reciting|surah|verse|verses|ayah|ayat|salawat|blessings upon|invocation|invoke|ask|asking|request|tahlil|hamd|praise|takbir|amulet|prayer for|ta'?awwudh|refuge|dawn|morning|evening)\b/i],
  ['social', 'المعاشرة والجيران والإخوان', '🤝', /\b(neighbor|neighbors|neighbour|neighbours|friend|friends|friendship|brother|brothers|brotherhood|companion|companions|company|visit|visiting|greeting|greetings|salam|salutation|sneezing|handshake|embrace|hospitality|guest|guests|social|people|community|gathering|assembly|meeting|sitting|conversation|speech|talk|talking|silence|speaking|tongue|words|joke|joking|laughter|laugh|play|game|games|gambling|chess|dice|singing|music|poetry|poems|poets|dance|entertainment|slave|slaves|servant|servants|master|freeing|manumission|mukatab|kindness|good relations|believer's rights|rights of|rights|duties|helping|help|assistance|need|needs|favor|favors|good to|doing good|mediation|reconciliation|enmity|hatred|cutting|break|severing|oppress|backbite)\b/i],
  ['jihad', 'الجهاد والحرب والأمر بالمعروف', '🛡️', /\b(jihad|war|wars|battle|battles|fight|fighting|enemy|enemies|soldier|army|prisoners|captives|booty|spoils|fay|anfal|jizya|dhimmi|dhimma|peace treaty|treaty|safe conduct|ribat|martyr|martyrs|martyrdom|enjoining|forbidding|commanding good|rulers|ruler|ruling|governor|governors|authority|caliph|caliphate|government|sultan|king|kings|leader|leaders|leadership|state|politics)\b/i],
  ['imamate', 'الإمامة والولاية', '👑', /\b(imam|imams|imamate|imamah|wilayah|walayah|wilaya|guardian|successor|successors|appointment|ahl al-bayt|ahlulbayt|household of the prophet|prophet's household|family of the prophet|twelve|infallible|infallibility|proof of god|hujja|authority of|ghadir|fatima|fatimah|zahra|hasan|husayn|hussain|ali ibn abi talib|amir al-mu'?minin|commander of the faithful|chosen|sahifa|book of ali|mushaf|jafr|jami'?a|signs of imam|knowledge of the imam|imam's|the imam|imamat|pledge|allegiance|bay'?ah|shia|shi'?a|shiites|followers|lovers|love of ali|enemies of|nasibi|nawasib|rafidi|virtues of)\b/i],
  ['mahdi', 'المهدي والقائم والغيبة وعلامات الظهور', '🌅', /\b(mahdi|qa'?im|occultation|ghayba|ghaybah|reappearance|appearance of the qa'?im|signs of the appearance|sufyani|dajjal|antichrist|return|raj'?a|raj'?ah|awaited|awaiting|expectation|saviour|savior|twelfth|lord of the age|sahib al-zaman|sahib al-amr|riddah|dominion of the family|government of the truth|the one who will rise|rise of|rising)\b/i],
  ['prophets', 'الأنبياء والرسل وسيرتهم', '🌿', /\b(prophet|prophets|messenger|messengers|adam|noah|nuh|abraham|ibrahim|moses|musa|jesus|isa|david|dawud|solomon|sulayman|joseph|yusuf|jacob|ya'?qub|job|ayyub|jonah|yunus|idris|enoch|hud|salih|shu'?ayb|lot|luqman|khidr|dhul-qarnayn|ishmael|isma'?il|isaac|zakariya|yahya|john|muhammad|apostle|mary|maryam|children of israel|israelites|ark|camel of salih|story|stories|events|history|biography|birth of the prophet|conduct of the prophet|sunnah|the prophet's)\b/i],
  ['animals', 'الحيوان والذبائح والصيد', '🐪', /\b(animal|animals|beast|beasts|slaughter|slaughtering|dhabiha|hunt|hunting|game|prey|dog|dogs|cat|cats|bird|birds|sheep|goat|cow|cattle|camel|camels|horse|horses|donkey|mule|pig|swine|fish|fishing|locust|insect|insects|serpent|snake|scorpion|ant|bee|bees|beekeeping|pigeon|chicken|rooster|cock|lawful meat|halal|haram food|carrion|blood|slaughtered|livestock|pasture|riding animals|stable)\b/i],
  ['poverty', 'الفقر والغنى والرزق', '🌾', /\b(poverty|poor|wealth|wealthy|rich|richness|riches|need|needy|sustenance|provision|rizq|rizk|livelihood|hardship|ease|relief|affliction|trial|trials|test|tests|calamity|calamities|adversity|misfortune|tribulation|hunger|thirst|deprivation|luxury|simplicity|asceticism|zuhd|frugality|waste|wastefulness|extravagance|squander|moderation|saving|savings)\b/i],
  ['mosque', 'المساجد وأدابها', '🕌', /\b(mosque|mosques|masjid|house of god|houses of god|sacred mosque|prophet's mosque|minbar|sanctuary|sanctuaries)\b/i],
  ['misc', 'متفرقات وفقه عام', '📖', /(?!)/],
];

// Arabic fallback keywords for hadiths whose chapter title does not match any topic
const AR_FALLBACK = {
  food: /الطعام|الاكل|اكل|خبز|لحم|تمر|عسل|خل|زيت|لبن|فاكهة|مائدة|سمن/,
  drink: /الشراب|شرب|الماء|خمر|مسكر|نبيذ|فقاع/,
  walk: /المشي|سفر|مسافر|الطريق|راكب|ركب|دابة|بعير|نعل/,
  sleep: /النوم|نام|فراش|رؤيا|حلم/,
  dress: /ثوب|لباس|عمامة|حرير|عطر|طيب|مسك|شعر|لحية|ظفر|خاتم|حمام|كحل/,
  health: /مرض|دواء|علاج|طب|شفاء|وجع|حمى|عليل|عيادة/,
  prayer: /صلاة|الصلاة|اذان|اقامة|ركوع|سجود|قبلة|تشهد|مسجد|جماعة|ركعة|ركعات/,
  purity: /وضوء|غسل|تيمم|نجس|بول|جنابة|حيض|طهارة|ماء الحمام/,
  fasting: /صوم|صيام|رمضان|افطار|سحور|الصائم/,
  zakat: /زكاة|خمس|صدقة|الفطرة|فقير|مسكين/,
  hajj: /حج|عمرة|احرام|طواف|سعي|عرفة|منى|الكعبة|مكة|زيارة|قبر الحسين/,
  death: /موت|ميت|جنازة|قبر|كفن|حنوط|دفن|احتضار|الاحتضار/,
  hereafter: /القيامة|الاخرة|الجنة|النار|الحساب|الصراط|الميزان|جهنم|البعث|شفاعة/,
  marriage: /نكاح|تزويج|زوجة|امراة|المراة|مهر|زواج|متعة/,
  children: /ولد|الولد|ابن|ابنة|الوالدين|والدين|عقيقة|رضاع|يتيم|اليتيم/,
  divorce: /طلاق|عدة|ميراث|وصية|ارث|الورثة/,
  trade: /بيع|تجارة|شراء|دين|قرض|ربا|مال|رزق|معيشة|كسب|اجارة|مضاربة|سوق/,
  judgment: /قضاء|حد|حدود|دية|شهادة|يمين|قصاص|سرقة|زنا|قذف|قتل/,
  knowledge: /علم|العلم|عالم|العالم|عقل|العقل|جهل|الجاهل|فقه|حديث|تعلم/,
  ethics: /خلق|صبر|شكر|غضب|تواضع|كبر|حسد|غيبة|كذب|صدق|امانة|حياء|عفو|رحمة|ظلم|عدل|حلم|رياء|نفاق/,
  faith: /ايمان|كفر|شرك|توحيد|يقين|اخلاص|تقوى|توكل|رضا بالقضاء|قدر|عبادة|ملائكة|شيطان/,
  dua: /دعاء|ذكر|تسبيح|استغفار|توبة|قرآن|القران|تلاوة|صلوات|تحميد|تهليل/,
  social: /جار|جيران|صديق|اخ|اخوان|اخوة|صحبة|زيارة المؤمن|سلام|مصافحة|ضيف|عبد|عبيد|مملوك|لعب|شطرنج|غناء|شعر/,
  jihad: /جهاد|حرب|قتال|عدو|غنيمة|فيء|اسير|اسرى|امر بالمعروف|نهي عن المنكر|والي|حاكم|سلطان|امارة/,
  imamate: /امام|امامة|ولاية|وصي|اهل البيت|حجة|علي بن ابي طالب|فاطمة|الحسين|شيعتنا|شيعة/,
  mahdi: /مهدي|قائم|غيبة|ظهور|سفياني|دجال|رجعة|صاحب الامر|صاحب الزمان/,
  prophets: /نبي|الانبياء|رسول|ادم|نوح|ابراهيم|موسى|عيسى|داود|سليمان|يوسف|يعقوب|ايوب|يونس|ادريس/,
  animals: /ذبح|ذبيحة|صيد|كلب|حيوان|بهيمة|شاة|غنم|بقر|ابل|فرس|حمار|جراد|سمك/,
  poverty: /فقر|غنى|الفقر|الغنى|بلاء|شدة|ضيق|فرج|زهد|اسراف|تبذير|قناعة/,
  mosque: /مسجد|المساجد|المنبر/,
};

const topicIds = TOPICS.map((t) => t[0]);

function topicsFor(h, normText) {
  const title = ((h.chapter || '') + ' ' + (h.category || '')).replace(/[‘’']/g, "'");
  const out = [];
  for (let i = 0; i < TOPICS.length - 1; i++) {
    if (TOPICS[i][3].test(title)) out.push(i);
  }
  return out;
}

// Prefer the more specific topics when many match (cap at 3 by specificity priority)
const PRIORITY = [
  'mahdi', 'hajj', 'fasting', 'prayer', 'purity', 'mosque', 'zakat', 'divorce', 'marriage', 'children',
  'judgment', 'death', 'hereafter', 'food', 'drink', 'walk', 'sleep', 'dress', 'health', 'animals', 'trade',
  'jihad', 'prophets', 'imamate', 'dua', 'knowledge', 'poverty', 'social', 'ethics', 'faith',
];
function trim(ids) {
  const ranked = ids.slice().sort((a, b) => PRIORITY.indexOf(TOPICS[a][0]) - PRIORITY.indexOf(TOPICS[b][0]));
  return ranked.slice(0, 3);
}

// ---------------- Main -----------------
const out = [];
const seen = new Set();
const stats = { tiers: [0, 0, 0, 0], files: {} };
let noTopic = 0;

for (const f of fs.readdirSync(RAW)) {
  const arr = JSON.parse(fs.readFileSync(`${RAW}/${f}`, 'utf8'));
  for (const h of arr) {
    const bi = bookIds.indexOf(h.bookId);
    if (bi < 0) continue;
    const g = gradeOf(h);
    if (!g.tier) continue;
    let text = (h.arabicText || '').replace(/^\s*\[[^\]]*\]\s*[^:]{2,40}:\s*/, '').replace(/^\s*\d+\s*[-–—ـ]+\s*/, '').replace(/\s+/g, ' ').trim();
    if (text.length < 25) continue;
    const key = norm(text).slice(0, 400);
    if (seen.has(key)) continue;
    seen.add(key);
    const an = analyze(text);
    const nt = norm(text);
    let ts = topicsFor(h, nt);
    if (!ts.length) {
      // fallback on Arabic matn text
      const matn = norm(text.slice(an.split || 0));
      for (const [k, re] of Object.entries(AR_FALLBACK)) {
        if (re.test(matn)) ts.push(topicIds.indexOf(k));
      }
    }
    ts = trim(ts);
    if (!ts.length) {
      ts = [TOPICS.length - 1];
      noTopic++;
    }
    const gi = gradeIdx(g.str);
    out.push([text, an.split, bi, h.id, g.tier, an.speaker, an.quoted, ts, gi, g.grader]);
    stats.tiers[g.tier]++;
    stats.files[h.bookId] = (stats.files[h.bookId] || 0) + 1;
  }
}

// Stable order: by book then id
out.sort((a, b) => a[2] - b[2] || a[3] - b[3]);

const meta = {
  books: bookNames,
  masoomsNames: MASOOMS,
  topics: TOPICS.map((t) => ({ id: t[0], name: t[1], icon: t[2] })),
  grades: gradeStrs,
  graders: graderNames,
};
const json = JSON.stringify({ meta, h: out });
const gz = zlib.gzipSync(Buffer.from(json), { level: 9 });
fs.mkdirSync('src/data', { recursive: true });
fs.writeFileSync('src/data/hadith.b64.txt', gz.toString('base64'));

const topicCount = {};
const spk = {};
for (const r of out) {
  for (const t of r[7]) topicCount[TOPICS[t][1]] = (topicCount[TOPICS[t][1]] || 0) + 1;
  spk[r[5]] = (spk[r[5]] || 0) + 1;
}
console.log('total', out.length, 'tiers', stats.tiers, 'noTopic', noTopic);
console.log('json MB', (json.length / 1e6).toFixed(2), 'gz MB', (gz.length / 1e6).toFixed(2));
console.log(topicCount);
console.log(Object.entries(spk).map(([k, v]) => `${MASOOMS[k] || k}: ${v}`));
console.log(gradeStrs);
