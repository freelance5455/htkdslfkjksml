// يبني قاعدة بيانات الأحاديث المعتبرة من ملفات JSON المحمّلة من ThaqalaynAPI
// الاستخدام: node scripts/build-data.mjs <مجلد البيانات الخام>
import fs from "fs";
import path from "path";

const DIR = process.argv[2] || "/tmp/data";
const OUT = "src/data/hadiths.json";

const BOOKS = {
  "Al-Kafi-Volume-1-Kulayni": ["الكافي", 1],
  "Al-Kafi-Volume-2-Kulayni": ["الكافي", 2],
  "Al-Kafi-Volume-3-Kulayni": ["الكافي", 3],
  "Al-Kafi-Volume-4-Kulayni": ["الكافي", 4],
  "Al-Kafi-Volume-5-Kulayni": ["الكافي", 5],
  "Al-Kafi-Volume-6-Kulayni": ["الكافي", 6],
  "Al-Kafi-Volume-7-Kulayni": ["الكافي", 7],
  "Al-Kafi-Volume-8-Kulayni": ["الكافي", 8],
  "Man-La-Yahduruh-al-Faqih-Volume-1-Saduq": ["من لا يحضره الفقيه", 1],
  "Man-La-Yahduruh-al-Faqih-Volume-2-Saduq": ["من لا يحضره الفقيه", 2],
  "Man-La-Yahduruh-al-Faqih-Volume-3-Saduq": ["من لا يحضره الفقيه", 3],
  "Man-La-Yahduruh-al-Faqih-Volume-4-Saduq": ["من لا يحضره الفقيه", 4],
  "Man-La-Yahduruh-al-Faqih-Volume-5-Saduq": ["من لا يحضره الفقيه", 5],
  "Tahdhib-al-Ahkam-Volume-1-Tusi": ["تهذيب الأحكام", 1],
  "Tahdhib-al-Ahkam-Volume-2-Tusi": ["تهذيب الأحكام", 2],
  "Tahdhib-al-Ahkam-Volume-3-Tusi": ["تهذيب الأحكام", 3],
  "Tahdhib-al-Ahkam-Volume-4-Tusi": ["تهذيب الأحكام", 4],
  "Mujam-al-Ahadith-al-Mutabara-Muhsini": ["معجم الأحاديث المعتبرة", 0],
  "Al-Khisal-Saduq": ["الخصال", 0],
  "Al-Amali-Mufid": ["الأمالي (المفيد)", 0],
  "Al-Tawhid-Saduq": ["التوحيد", 0],
  "Maani-al-Akhbar-Saduq": ["معاني الأخبار", 0],
  "Uyun-akhbar-al-Rida-Volume-1-Saduq": ["عيون أخبار الرضا", 1],
  "Uyun-akhbar-al-Rida-Volume-2-Saduq": ["عيون أخبار الرضا", 2],
  "Kitab-al-Zuhd-Ahwazi": ["الزهد", 0],
  "Nahj-al-Balagha-Radi": ["نهج البلاغة", 0],
  "Kamal-al-Din-wa-Tamam-al-Nima-Saduq": ["كمال الدين وتمام النعمة", 0],
  "Kitab-al-Ghayba-Tusi": ["الغيبة (الطوسي)", 0],
  "Kitab-al-Ghayba-Numani": ["الغيبة (النعماني)", 0],
};
const bookKeys = Object.keys(BOOKS);

// ---------- تطبيع ----------
const norm = (s) =>
  (s || "")
    .replace(/\uFDF2/g, "الله")
    .replace(/[\u064B-\u065F\u0670\u0640\u06D6-\u06ED]/g, "")
    .replace(/[أإآٱ]/g, "ا")
    .replace(/ى/g, "ي")
    .replace(/\s+/g, " ")
    .trim();

// ---------- الرواة (المعصومون) ----------
const HON = "(?:عليه السلام|عليها السلام|عليهما السلام|عليهم السلام|صلي الله عليه|صلوات الله عليه|\\(ع\\)|\\(ص\\)|ع\\))";
const AB = "اب[يوا]"; // أبي / أبو / أبا
const IMAMS = [
  ["nabi", "النبي محمد ﷺ", /(?:رسول الله|النبي|رسول اللّه)/],
  ["ali", "أمير المؤمنين علي (ع)", /(?:امير المؤمنين|علي بن ابي طالب|امير المومنين|امير المومنين)/],
  ["fatima", "السيدة فاطمة الزهراء (ع)", /(?:فاطمه الزهراء|فاطمه|الزهراء)/],
  ["hasan", "الإمام الحسن المجتبى (ع)", /(?:(?<!(?:ابي|ابا|ابو|بن|ابن) )(?:الحسن بن علي بن ابي طالب|الحسن بن علي|الحسن المجتبي|الامام الحسن|الحسن)(?! (?:بن|الاول|الثاني|الثالث|الرضا|موسي)))/],
  ["husayn", "الإمام الحسين (ع)", /(?:(?<!(?:ابي|ابا|ابو|بن|ابن) )(?:الحسين بن علي|الحسين)(?! بن (?!علي)))/],
  ["sajjad", "الإمام زين العابدين (ع)", /(?:علي بن الحسين|زين العابدين|السجاد)/],
  ["baqir", "الإمام الباقر (ع)", new RegExp("(?:" + AB + " جعفر(?! الثاني)|الباقر)")],
  ["sadiq", "الإمام الصادق (ع)", new RegExp("(?:" + AB + " عبد الله(?! الحسين)|الصادق|جعفر بن محمد)")],
  ["kazim", "الإمام الكاظم (ع)", new RegExp("(?:" + AB + " الحسن موسي|" + AB + " الحسن الاول|العبد الصالح|الكاظم|موسي بن جعفر|" + AB + " ابراهيم)")],
  ["rida", "الإمام الرضا (ع)", new RegExp("(?:" + AB + " الحسن الثاني|" + AB + " الحسن الرضا|الرضا|علي بن موسي)")],
  ["jawad", "الإمام الجواد (ع)", new RegExp("(?:" + AB + " جعفر الثاني|الجواد|" + AB + " جعفر محمد بن علي)")],
  ["hadi", "الإمام الهادي (ع)", new RegExp("(?:" + AB + " الحسن الثالث|الهادي|" + AB + " الحسن علي بن محمد|علي بن محمد العسكري)")],
  ["askari", "الإمام العسكري (ع)", new RegExp("(?:" + AB + " محمد الحسن|العسكري|الحسن بن علي العسكري)")],
  ["mahdi", "الإمام المهدي (عج)", /(?:صاحب الزمان|صاحب الامر|المهدي|الحجه بن الحسن|القايم)/],
  ["abulhasan", "الإمام أبو الحسن (ع)", new RegExp("(?:" + AB + " الحسن)")],
];
// أسبقية التعرف: الأكثر تحديداً أولاً عند التساوي في الموضع
const ORDER = ["hasan", "husayn", "sajjad", "baqir", "sadiq", "kazim", "rida", "jawad", "hadi", "askari", "mahdi", "ali", "fatima", "nabi", "abulhasan"];
const imamIndex = Object.fromEntries(IMAMS.map((x, i) => [x[0], i]));
const compiled = IMAMS.map(([code, , re]) => [
  code,
  new RegExp("(?:" + re.source + ")[^()«»:\\n]{0,14}?\\s*\\(?\\s*" + HON, "g"),
]);

function findSpeaker(n) {
  // يرجع [code, endIndex] لأول معصوم يتبعه صيغة تعظيم
  let best = null;
  for (const [code, re] of compiled) {
    re.lastIndex = 0;
    const m = re.exec(n);
    if (!m) continue;
    const pos = m.index;
    let end = m.index + m[0].length;
    const tm = /^\s*\)/.exec(n.slice(end));
    if (tm) end += tm[0].length;
    if (
      !best ||
      pos < best.pos ||
      (pos === best.pos && ORDER.indexOf(code) < ORDER.indexOf(best.code))
    )
      best = { code, pos, end };
  }
  return best;
}

// ---------- الدرجات ----------
const FLAW = /ضعيف|مجهول|مرسل|مرفوع|مختلف|موقوف|مقطوع|مضمر|لم |سكت|ويحتمل|يحتاط|احتياط|كالسابق|كما مر|كما تقدم|مثل السند|بالسند السابق|مشترك|ابن النضايري|مسل/;
const LIKE = /كالصحيح|كالحسن|كالموثق|في قوه الصحيح|ل?ا? ?يقصر عن الصحيح|ل?ا? ?ينقص عن الصحيح|ل ينقص|ل يقصر|لا يقصر|لا ينقص|معتبر|معتمد|صحيح عندي|صحيح عند ي|حسن عندي|حسن عند ي|تلقاه/;
function tierOf(rawGrade, who) {
  let g = norm(rawGrade).replace(/[()]/g, " ").replace(/\s+/g, " ").trim();
  if (!g || g === "null") return null;
  g = g.replace(/ضعيف على المشهور|ضعيف علي المشهور/g, (m) => m); // يبقى كما هو
  // الشيخ هادي النجفي / المحسني بصيغ مختلفة
  if (/^صحيحه الاسناد|^صحيحه سندا|نقلها الكليني بسنده الصحيح/.test(g)) return 1;
  if (/^حسنه سندا|^من حيث السند حسنه/.test(g)) return 2;
  if (/^موثقه سندا|^من حيث السند موثقه/.test(g)) return 3;
  if (/^معتبره الاسناد|^من حيث السند معتبره/.test(g)) return 4;
  if (/لا يحتاط|احد الطرق معتبر/.test(g) && !/ضعيف|مجهول/.test(g)) return 4;
  if (/^(?:صحيح|حسن|موثق|معتبر)/.test(g) && /(الفضلء|الفضلاء)/.test(g)) {
    return /^صحيح/.test(g) ? 1 : /^حسن/.test(g) ? 2 : /^موثق/.test(g) ? 3 : 4;
  }
  const flawed = FLAW.test(g);
  const like = LIKE.test(g);
  if (flawed) {
    // الأحكام الإيجابية الصريحة لدى المجلسي رغم الضعف المشهور
    if (/(?:معتبر|معتمد|صحيح|حسن) ?عند ?ي|لكنه معتبر|ومعتبر|معتبر$/.test(g) && !/^(?:مرسل|مرفوع|مجهول) /.test(g))
      return 4;
    if (/(?:مجهول|مرسل|ضعيف) (?:كالصحيح|كالحسن|كالموثق)$/.test(g)) return 4;
    return null;
  }
  if (/^صحيح(?! ?ي)/.test(g)) return 1;
  if (/^حسن(?! ?ي)/.test(g)) return /كالصحيح/.test(g) ? 2 : 2;
  if (/^موثق/.test(g)) return 3;
  if (like) return 4;
  if (/^في اعلي مراتب الصحه/.test(g)) return 1;
  if (/^معتبر/.test(g)) return 4;
  return null;
}
const TIERS = ["", "صحيح", "حسن", "موثق", "معتبر", "مأثور"];
const WHO_SHORT = (n) =>
  /المجلسي/.test(n) ? "المجلسي" :
  /البهبودي/.test(n) ? "البهبودي" :
  /المحسني/.test(n) ? "المحسني" :
  /الغفاري/.test(n) ? "الغفاري" :
  /النجفي/.test(n) ? "الشيخ هادي النجفي" : n;

function gradeOf(h) {
  const list = [];
  for (const gr of h.gradingsFull || []) {
    const who = WHO_SHORT(gr.author?.name_ar || "");
    const t = tierOf(gr.grade_ar, who);
    if (t) list.push({ who, t, raw: (gr.grade_ar || "").replace(/\s+/g, " ").trim() });
  }
  if (!list.length) return null;
  list.sort((a, b) => a.t - b.t);
  const best = list[0].t;
  // مصدر التصحيح: من أعطى أفضل درجة أولاً
  const src = [...new Set(list.map((x) => x.who))].slice(0, 3).join("، ");
  return { t: best, src };
}

// ---------- المواضيع ----------
// [الرمز، الاسم، الأيقونة، regex على عنوان الباب بالإنجليزية، regex احتياطي على المتن]
const TOPICS = [
  ["food", "الطعام والشراب", "🍽️", /\bfood|drink|\beat|\bmeal|bread|\bmeat|fruit|drinking water|milk|vinegar|honey|\bwine|intoxicant|\bdates\b|\bsalt\b|olive|butter|cook|\bdish|feast|hunger|sweet|vegetable|banquet|\btable|slaughter|hunting|\brice\b|\bspice|\begg|\bfish|fowl|sheep|beverage|thirst|vessels?\b|\bstew|soup|walnut|pomegranate|grape|melon|cucumber|lentil|onion|garlic|leek|radish|barley|wheat|flour|dough|bowl|spoon|plate|licking|fingers|satiety|gluttony/i, /الطعام|الاكل|الشرب|الخبز|اللحم|اللبن|العسل|الفاكهه|الخل\b|التمر|الجوع|المايده|الزيت|الشبع/],
  ["salat", "الصلاة", "🕌", /prayer|salat|\badhan|iqama|qibla|prostrat|\bruku|bowing|\bsujud|mosque|congregation|tashahhud|taslim|qunut|\bfriday|eclipse|voluntary|nafila|\bdawn|zawal|\brak.a|\bsahw|shortening/i, /الصلاه|الصلوه|الركوع|السجود|الاذان|الاقامه|القبله|المسجد|الجماعه|القنوت|التشهد/],
  ["siyam", "الصيام وشهر رمضان", "🌙", /fasting|\bfast\b|ramadan|\bsawm|iftar|\bfitr|\beid\b|itikaf|retreat/i, /الصيام|الصوم|رمضان|الافطار|الاعتكاف/],
  ["zakat", "الزكاة والخمس والصدقة", "🤲", /zakat|zakah|khums|charity|\balms|sadaqa|spending in the way|endow|waqf|beggar|begging|poor due|\bgiving\b/i, /الزكاه|الخمس|الصدقه|الصدقات|الانفاق|الوقف/],
  ["hajj", "الحج والعمرة", "🕋", /pilgrimage|\bhajj|umrah|ihram|tawaf|\bsa.y\b|\bsafa\b|arafa|\bmina\b|muzdalifa|sacrific|kaaba|ka.ba|zamzam|stoning|muhrim|\bmecca|\bmakka|medina|sacred mosque|sanctuary|black stone|talbiya|pelting|tamattu|ifrad|qiran|hady/i, /الحج\b|العمره|الاحرام|الطواف|عرفه|الكعبه|زمزم|مكه/],
  ["tahara", "الطهارة والوضوء والغسل", "💧", /purity|purif|\bwater\b|\bwudu|ablution|ghusl|tayammum|najas|impur|\burine|menstru|istihada|nifas|\bbath|toilet|latrine|\bclean|janaba|pollut|\bwells?\b|water of|ritual|istinja|excrement|semen|\bblood\b|carrion|dead animal/i, /الطهاره|الوضوء|الغسل|التيمم|النجاسه|البول|الحيض|الجنابه|المرحاض|الاستنجاء|الطهور/],
  ["nikah", "الزواج والمرأة", "💍", /marriage|\bmarry|\bwife|wives|husband|dowry|\bmahr|temporary|bride|nursing|suckl|virgin|women|woman|female|spouse|polygam|concubine|mut.a|maiden|widow|bridal|wedding|slave girl|bondwoman|co-wife|intercourse|sexual|relations with/i, /الزواج|النكاح|الزوجه|المراه|النساء|المهر|الصداق|التزويج|البكر/],
  ["talaq", "الطلاق والعدة", "💔", /divorce|talaq|\biddah|\bidda\b|\bkhul|mubarat|zihar|waiting period|separation|revoc/i, /الطلاق|العده|الخلع|الظهار|اللعان/],
  ["family", "الوالدان والأولاد والأرحام", "👨‍👩‍👧", /parent|\bfather|\bmother|children|\bchild\b|\bson\b|daughter|\bkin\b|kinship|relatives|upbringing|newborn|\bbirth|aqiqa|naming|\borphan|family|offspring|infant|\bboys?\b|\bgirls?\b|breast|weaning|circumcis|womb|pregnan|abortion|miscarr|fetus/i, /الوالدين|الوالد\b|الابويه|الاولاد|الولد|الرحم|الارحام|اليتيم|العقيقه|المولود/],
  ["akhlaq", "الأخلاق والآداب", "🌿", /manner|character|ethic|\banger|pride|arrogan|envy|jealous|\blying\b|\blie\b|\blies\b|truthful|honest|\btrust\b|backbit|slander|humility|humble|modesty|\bshy|stingy|greed|forbear|kindness|oppress|swearing|quarrel|conduct|mercy|compassion|bad temper|good temper|vanity|ostentat|ridicule|mock|rumor|grudge|hatred|malice|miser|fairness|gentl|softness|rudeness|harshness|respect|noble|etiquette|virtue|\bhonou?r\b|dignity|humiliat|abase|contempt|despis|insult|curs|abus|\bvile|obscen|foul|mean\b|generos/i, /الخلق|الاخلاق|الغضب|الكبر|الحسد|الكذب|الصدق|الامانه|الغيبه|التواضع|الحياء|البخل|الحلم|الظلم|الرحمه|الرفق|العفو|الحقد/],
  ["ilm", "العقل والعلم", "📚", /intellect|\breason\b|\bmind\b|knowledge|\blearn|scholar|\bteach|ignoran|student|studying|wisdom|\bilm\b|\bjahl|hadith|narrat|tradition|\bopinion|analog|qiyas|ijtihad|fatwa|jurist|\bfaqih|seeking|sciences?\b|scientist|authorit(?:y|ies) of|reference to/i, /العقل|العلم|العلماء|العالم|المتعلم|الجهل|الحكمه|التفقه|الفقه|الراي|القياس/],
  ["tawhid", "التوحيد والعقيدة", "☀️", /\bgod\b|unity|oneness|monotheis|attributes?\b|names of|\bbelief|disbelief|\bfaith\b|\bkufr|\bshirk|polytheis|will of|decree|destiny|predestin|\bbada\b|\bsoul\b|angel|\bjinn|creation of|createdness|resembl|vision of|seeing god|justice of|misguid|hypocri|\bislam\b|pillar|essence|existence|creator|\bdhat|kursi|throne|\bpen\b|tablet|\bspirit|covenant|nature of|doubt|certain|atheis|materialis|dahri|ghuluww|extremis|exaggerat|innovation|bid.a|intercession of/i, /التوحيد|الايمان|الكفر|الشرك|القضاء والقدر|البداء|الملايكه|الجن\b|الروح|المنافق|الاسلام|العرش|الكرسي|اللوح/],
  ["imama", "الإمامة والولاية وأهل البيت", "⭐", /\bimam|imamate|wilaya|walaya|ahl al-?bayt|infallib|proof of god|prophethood|\bprophet\b|\bprophet.s\b|messenger|apostle|successor|caliph|ghadir|\bshi.a\b|\bshia\b|adherent|enemies of|nasib|love of|obedience to|loyalty|\bahl al|guardian of|\bwasi\b|\bwasiyy|\bsunnah|sunna\b|\bthaqalayn|\bkisa\b|\bmubahala|\bal-?qa.im|\bal-?mahdi|\btwelve|mawlid|nativity|martyrdom of|birth of the|merits of|excellence of|virtues of|attributes of the imam|knowledge of the imam|visit(?:ing)? the (?:grave|tomb)|visitation|ziyar|who claims|wala/i, /الامام|الايمه|الولايه|اهل البيت|الحجه\b|الخلافه|الشيعه|غدير|الوصيه/],
  ["quran", "القرآن الكريم", "📖", /qur.?an|recitation|\bsura\b|\bsurah|\bverse|\bayah|\bayat|tafsir|interpretation of|revelation|mushaf|muhkam|mutashabih|naskh|abrogat|\bsurat/i, /القران|السوره|الايه|التلاوه|المصحف|التفسير/],
  ["dua", "الدعاء والذكر", "🙏", /supplication|\bdua\b|\bduaa\b|dhikr|remembrance|glorific|tasbih|istighfar|salawat|invocation|praying to|\bpraise|thanking|tahlil|takbir|tahmid|litany|rosary|beads|\banswer|call upon|calling upon|seeking help|\bprayers? for|blessings? upon|ask(?:ing)? (?:allah|god)/i, /الدعاء|الذكر|التسبيح|الاستغفار|الصلوات علي|التهليل|التكبير|التحميد|المسبحه/],
  ["tijara", "التجارة والكسب والمعاملات", "⚖️", /\btrade|business|earning|profit|usury|\briba\b|\bsale\b|\bsell|\bbuy|\bdebt|\bloan|\brent\b|rented|partnership|mortgage|pledge|livelihood|provision|market|\bmeasure|\bweigh|\bhire|wages|labou?r|contract|merchant|\bprice|\bgift|deposit|bailment|guarantee|surety|\bagent|fraud|cheat|bargain|commerce|craft|profession|property|\blands?\b|farming|agricultur|cultivat|sowing|\btree|garden|irrigat|orchard|pasture|usurp|wealth|\bmoney|dirham|dinar|invest|seller|buyer|\bsalam\b|creditor|debtor|bankrupt|lost property|found property|lugha|water rights|well-digging|barren|dead land|rahn|sharecrop|musaqat|muzara|share-?cropping|work\b|\bworking|\bworker|servant|employ/i, /التجاره|الكسب|الربا|البيع|الشراء|الدين\b|القرض|الاجاره|الرهن|الرزق|السوق|المكيال|الميزان|الزراعه|المال\b/],
  ["mawt", "الموت والقبر والآخرة", "⏳", /\bdeath|\bdying|\bgrave|barzakh|resurrection|judg(?:e)?ment day|day of judg|hereafter|paradise|\bhell\b|\bfire\b|shroud|burial|funeral|\bdead\b|reckoning|intercession|\bsirat|\bscale|the last day|afterlife|torment|kafan|hanut|\bjanna|\breward|retribution|\breckon|mourning|condolence|lament|weeping|crying|\bgrief|\bgrieving|calamity|calamities|\btrials?\b|afflict|hardship|tribulation|\bangel of death|\bsouls? of|\bsurvival|\bpromise and|threat|\bresurrect|\bday of/i, /الموت|القبر|البرزخ|القيامه|الجنه|النار\b|الكفن|الميت|الحساب|الشفاعه|الصراط|الاخره|الحشر/],
  ["libas", "اللباس والزينة والنظافة", "👔", /\bcloth|\bdress|garment|jewel|\bring\b|perfume|\bscent|\bhair\b|\bbeard|\bcomb\b|beauty|adorn|ornament|\bdye|henna|\bnails?\b|mirror|\bsilk|\bgold\b|\bshoes?\b|sandal|turban|\bcoat|\brobe|fragrance|musk|kohl|antimony|cleanliness|\btooth|\bbrush|siwak|miswak|mustache|\bshav|razor|\btrim|\bveil|hijab|\bcloak|apparel|\bfur\b|\bwool|cotton|silver|jewelry|\bwear|\bworn|\bgarb/i, /اللباس|الثوب|الثياب|الخاتم|الطيب|العطر|اللحيه|المشط|الحناء|الكحل|السواك|الحرير|الذهب|الحذاء|العمامه|الحجاب/],
  ["tibb", "الطب والصحة", "🩺", /medicine|treatment|disease|illness|\bsick|\bhealth|\bcure|cupping|physician|remedy|fever|\bpain|healing|\bdoctor|\beyes?\b|headache|\bwound|plague|epidemic|medical|\bherb|\bdrug|patient|ailment|toothache|leprosy|fracture|bleeding|diarrhea|constipation|stomach|fatigue|insomnia|blindness|\bdeaf|amulet|ruqya|incantation|evil eye|magic|sorcery|\bsoothsay|astrolog|divination|omen|augur|fortune|\btalisman|\bcharm|\bvenom|\bpoison|\bbite|\bsting|\bsnake|\bscorpion|\bbaldness|\bsweat|\bthin|\bobesity|\bfat people|\bbrain|\bphlegm|\bbile|\bblood-letting|\bbloodletting|\benema|\blaxative|\bvomit|\bcough|\bsneez|\byawn|\bcolic|\bhernia|\bhemorrhoid|\bpiles\b|\bulcer|\bleprosy|\bmadness|\binsanity|\bmanic|\bepilep|\bsmallpox|\bmeasles|\bcold\b|\bfebrile/i, /الطب|الدواء|المرض|العلاج|الحجامه|الشفاء|الحمي|الوجع|الرقيه|السحر|الكهانه|التنجيم/],
  ["qada", "القضاء والحدود والديات", "🏛️", /\bjudgments?\b|\bjudges?\b|witness|testimony|hudud|\bpenal|blood money|\bdiya|retaliation|qisas|\btheft|\bthief|fornication|accusation|\bcrime|lawsuit|claimant|dispute|\bcourt|\blashes|\bstoning|amputat|murder|\bkilling|\bkill\b|\binjury|\blimb|apostasy|sodomy|homosex|lesbian|\bpunish|\bfines?\b|ransom|ta.zir|plaintiff|defendant|arbitrat|false testimony|perjur|bribe|\bprison|\bjail|zina|mutilat|assault|\bcompensat|\bliab|\bretaliat|\bavenge|\bvengeance|\btribute|\bdiyah|\barsh\b|\bwounds?\b|\bkilled|\bfoetus|\bfetus|\binjuries/i, /القضاء|القاضي|الشهاده|الحدود|الديه|القصاص|السرقه|الزنا|القتل|البينه|الدعوي|الجنايه|الجراح/],
  ["irth", "الميراث والوصية", "📜", /inherit|\bheirs?\b|\bwills?\b|testament|bequest|bequeath|wasiyya|legacy|\bestate\b|\bshares? of|mirath|executor|trustee/i, /الميراث|الارث|الوصيه|الوارث|الفرايض|التركه|الورثه/],
  ["jihad", "الجهاد والأمر بالمعروف", "⚔️", /jihad|\bfight|\bwar\b|\benem(?:y|ies)\b|commanding|forbid|prisoner|jizya|booty|spoils|battle|\barmy|rebel|bughat|martyr|dhimmi|people of the book|\bjews?\b|christian|zoroast|magian|infidel|unbeliever|kafir|truce|treaty|\braid|expedition|enjoin|prohibit|\bsword|\bweapons?\b|\barms\b|\bspear|\barrow|\bhorsemanship|\bcavalry|\bsoldier|\bfrontier|\bribat|\bsentry|\bpatrol|\bsiege|\bflee|\bflight from|\bfleeing|\bcaptive|\bbanner|\bflag/i, /الجهاد|القتال|الحرب|العدو|الامر بالمعروف|النهي عن المنكر|الاسير|الجزيه|الغنيمه|الشهيد|اليهود|النصاري/],
  ["ashra", "الأخوّة والمعاشرة والجيرة", "🤝", /brother|brotherhood|friend|neighbou?r|\bcompanion|greeting|guest|hospitality|gathering|handshak|embrac|\bkiss|invitation|fraternity|brethren|consult|\badvice|counsel|\bvisit(?:ing)? (?:the|a|brothers?|believers?)|association|meeting|\bcongratulat|\bsalutation/i, /الاخوان|الاخوه|الصديق|الجار\b|الجيران|الضيف|الضيافه|المصافحه|المعانقه|التقبيل|المشوره|النصيحه|المجلس/],
  ["nadhr", "النذر واليمين والكفارات", "🕯️", /\bvows?\b|\boaths?\b|\bswear|expiation|kaffara|\bpromises?\b|\bpledges?\b|\bvowing|\bcovenants?\b|\bkaffarah|\bfidya|\bfidyah|\bintention in/i, /النذر|اليمين|الحلف|الكفاره|الوعد|العهد/],
  ["lahw", "اللهو والغناء والقمار", "🎲", /music|singing|\bsong|\bdance|gambling|\bchess|backgammon|\bgames?\b|entertain|poetry|\bpoets?\b|\bjokes?\b|laugh|joking|\bplay\b|\bplaying|\bidle|\bamusement|\bdraughts|\bdice\b|\bgamble|\blottery|\bbetting|\bwagers?\b|\bpigeon|\bhunting for sport|\bsport|\blute|\bflute|\bdrum|\bmusical|\bsinger|\bdancer|\blaughter|\bcheerful|\bsmile|\bsmiling|\bhumou?r/i, /الغناء|الموسيقي|القمار|الشطرنج|النرد|اللهو|الشعر\b|المزاح|الضحك/],
  ["tawba", "الذنوب والتوبة", "🔄", /\bsin\b|\bsins\b|repent|forgiv|\btawba|disobedien|major sin|minor sin|wrongdoing|atonement|pardon|transgress|offense|guilt|evil deeds|\bevil\b|\bwicked|\bcorrupt|\bimmoral|\bdebauch|\bvice|\bviolat|\bsinner|\bsinful|\bunlawful|\bforbidden things|\bprohibited things|\bharam things|\bshameful/i, /الذنب|الذنوب|التوبه|المعصيه|الكبايز|الكباير|الاستغفار|الخطيه/],
  ["zuhd", "الزهد والدنيا والفقر والغنى", "🪶", /\bworld\b|asceticism|\bzuhd|poverty|\bpoor\b|wealthy|\brich\b|worldly|\bdesire|\bhope|contentment|content with|simplicity|austerity|mundane|dunya|stingy|affluence|luxury|extravagan|wastef|moderation|economy|frugal|thrift|abstinen|renunciation|detachment|ambition|covet|greedy/i, /الزهد|الدنيا|الفقر|الغني\b|الفقير|القناعه|الاقتصاد|الاسراف|الامل\b|الطمع|الحرص|التقتير/],
  ["iman", "الإيمان والتقوى والإخلاص", "💎", /piety|taqwa|\bfear\b|fear of|trust in|tawakkul|certainty|yaqin|sincerity|ikhlas|\bintention|\bniyya|\bdeeds\b|\bworship|riya|show off|reliance|\bpatience|\bsabr|gratitude|shukr|thankful|submission|surrender|resignation|satisfaction|self-accounting|muhasaba|vigilance|spiritual|purification of|\bnafs|devotion|servitude|slavery to god|\bmu.min|\bmumin|\bbeliever|righteous|\bpious|god-fearing|good deeds|good works|good conduct|\bshukr|\bthanks|\bthank|\bscrupul|\bwara.|\bpiety|\bwatchful|\bmindful|\bhumbl|\bkhushu|\bcontemplat|\breflect|\bthinking|\btafakkur|\bmeditat|\bwakeful|\bnight prayer/i, /التقوي|الخوف|الرجاء|التوكل|اليقين|الاخلاص|النيه|الصبر|الشكر|الورع|المومن|المتقين|العباده|الرياء|الخشوع/],
  ["safar", "السفر والمسكن والحيوان", "🧳", /travel|journey|\bsleep|\bhome\b|\bhouses?\b|building|animal|riding|\bpets?\b|horse|camel|\bdogs?\b|cattle|donkey|\bmule|\bcow\b|livestock|beasts|insects|wild\b|dwelling|lodging|\bship|\bsea\b|\bboat|\broad\b|caravan|\brider|\bbees\b|\bants\b|\bcats?\b|\bbirds?\b|dream|sleeping|\bwakeful|\bvision\b|\bvisions\b|\bpigeons?\b|\bdoves?\b|\bfowl|\bpoultry|\bchicken|\bcock\b|\brooster|\bhen\b|\bhens\b|\bcrow|\bsparrow|\bhoopoe|\bfrog|\bfrogs|\bworm|\bworms|\bflies|\bfly\b|\bmosquito|\blice\b|\blouse\b|\bflea|\bbugs?\b|\bcricket|\blocust|\bdung|\bmanure|\bstable|\bbarn|\bcage|\bleash|\bmuzzle|\bfodder|\bfeeding animals|\bgrazing|\bshepherd|\bherd|\bflock|\bpasture/i, /السفر|المسافر|النوم|البيت|الدار\b|الدابه|الخيل|الابل|الكلب|الحيوان|الطريق|المنام|الرويا|الحلم/],
  ["tarikh", "سيرة الأنبياء والتاريخ", "🏺", /\bprophets\b|story of|stories of|\bhistory|\bmoses|\bjesus|\babraham|\bnoah|\badam\b|\bjoseph|\bdavid|\bsolomon|\bjob\b|\bjonah|\bidris|\bhud\b|\bsalih|\bzachariah|\byahya|\bjohn\b|\belijah|\bilyas|\bkhidr|dhul-?qarnayn|\bluqman|\bquraysh|jahiliyya|biography|seerah|\bsira\b|hijra|\bconquest|battle of|campaign|\bahzab|\bbadr|\buhud|\bkhaybar|\bhunayn|\btabuk|\bkarbala|\bashura|saqifa|\bshura|umayyad|abbasid|\bcaliphate|\bnations|\bpeoples|\bbani\b|\bbanu\b|\btribe|\bchildren of israel|\bisrael|\bpharaoh|\bnimrod|\bnamrud|\bqarun|\bhaman|\bsamiri|\bsamaritan|\bbalaam|\bshuayb|\bsaleh|\bishmael|\bismail|\bisaac|\bishaq|\bjacob|\bya.qub|\bsheth|\bseth\b|\bkhalid|\bcain|\babel\b|\bhabil|\bqabil|\bmaryam|\bmary\b|\basiya|\bkhadija|\bayesha|\baisha/i, /الانبياء|قصه|التاريخ|موسي|عيسي|ابراهيم|نوح|ادم\b|يوسف|داود|سليمان|ايوب|يونس|ادريس|لقمان|قريش|الهجره|بدر|احد\b|خيبر|كربلاء|عاشوراء/],
  ["mahdi", "الإمام المهدي والغيبة والظهور", "🌅", /occultation|ghayba|qa.im|mahdi|reappear|appearance of|signs of|hujjat|hujjah|imam of the age|sahib al-?(?:amr|zaman)|raj.a|\bmessiah|dajjal|antichrist|sufyani|yamani|end of time|last days|malahim|portents|signs before|\bfitna|\bfitan|\bapocalyp|\beschatolog|\blast imam|\btwelfth|\bsuccessor of/i, /الغيبه|القايم|المهدي|الظهور|صاحب الزمان|صاحب الامر|الرجعه|الدجال|السفياني|اليماني|الفتن|علامات الظهور|اخر الزمان/],
];

// يعيّن المواضيع: يُفضَّل عنوان الباب ثم التصنيف ثم نص المتن
const SPECIAL_STRICT = new Set(["mahdi"]);
const EXCLUDE_GENERIC = new Set(["akhlaq", "iman", "tarikh", "ashra", "safar", "libas"]);
function topicsFor(h, nText) {
  const chapter = h.chapter || "";
  const cat = h.category || "";
  let scores = [];
  for (const [code, , , reEn] of TOPICS) {
    let s = 0;
    const cm = (chapter.match(reEn) || []).length ? 1 : 0;
    if (cm) s += 5;
    if (reEn.test(cat)) s += 1;
    if (SPECIAL_STRICT.has(code) && !cm) s = 0;
    // الأبواب العامة لا تضيف إلا إذا كانت قوية
    if (s > 0) scores.push([code, s]);
  }
  if (!scores.length) {
    for (const [code, , , , reAr] of TOPICS) {
      if (SPECIAL_STRICT.has(code)) continue;
      const m = nText.match(new RegExp(reAr.source, "g"));
      if (m && m.length) scores.push([code, 0.5 + Math.min(m.length, 5) / 10]);
    }
  }
  scores.sort((a, b) => b[1] - a[1]);
  let picked = scores.slice(0, 2).map((x) => x[0]);
  // إن كان أحد الموضوعات تخصصياً (غير عام) نقدمه
  const specific = picked.filter((c) => !EXCLUDE_GENERIC.has(c));
  if (specific.length) picked = specific.concat(picked.filter((c) => EXCLUDE_GENERIC.has(c))).slice(0, 2);
  return picked.length ? picked : ["misc"];
}

// ---------- قراءة المصادر ----------
const out = [];
const seen = new Set();
const stats = {};
for (let bi = 0; bi < bookKeys.length; bi++) {
  const id = bookKeys[bi];
  const file = path.join(DIR, id + ".json");
  if (!fs.existsSync(file)) continue;
  const arr = JSON.parse(fs.readFileSync(file, "utf8"));
  let kept = 0;
  for (const h of arr) {
    const isNahj = id.startsWith("Nahj");
    const isGhayba = /^(Kamal|Kitab-al-Ghayba)/.test(id);
    let grade = isNahj || isGhayba ? null : gradeOf(h);
    if (isNahj) grade = { t: 5, src: "نهج البلاغة — جمع الشريف الرضي" };
    if (isGhayba) grade = { t: 5, src: "توقيع / مروي عن الإمام المهدي (عج)" };
    if (!grade) continue;
    const raw = (h.arabicText || "").trim();
    if (raw.length < 25) continue;
    if (isNahj && (raw.length < 60 || /^(?:قال )?(?:الشريف|السيد) ?الرضي/.test(norm(raw)))) continue;
    const text = raw.replace(/^\s*\d+\s*[-ـ–.]\s*/, "").replace(/^\[\d+\/\d+\]\s*/, "").replace(/\s+/g, " ").trim();
    const n = norm(text);

    // المتكلّم
    let sp = findSpeaker(n);
    if (isNahj) sp = { code: "ali", pos: 0, end: 0 };
    if (isGhayba && !(sp && sp.code === "mahdi")) continue;
    if (!sp) continue;
    const narr = [sp.code];
    // اقتباسات: معصومون آخرون يُنقل قولهم في المتن
    for (const [code, re] of compiled) {
      if (code === sp.code || code === "abulhasan") continue;
      const src = re.source;
      const q = new RegExp("(?:قال|يقول|قالت|قالا|روي عن|سمعت) (?:" + src + ")", "g");
      const after = n.slice(sp.end);
      if (q.test(after) && !narr.includes(code)) narr.push(code);
    }

    // تفصيل: أبو الحسن
    if (sp.code === "abulhasan") {
      // ممكن الكاظم أو الرضا أو الهادي — نبقيها بصيغة الكنية
    }

    // كشف التكرار بالمتن (آخر 140 حرفاً مطبّعاً بلا مسافات)
    const key = n.replace(/[^\u0621-\u064A]/g, "").slice(-160);
    if (key.length > 40 && seen.has(key)) continue;
    seen.add(key);

    // السند/المتن: نقطة الفصل بعد أول «قال» بعد المعصوم
    let split = 0;
    const tail = n.slice(sp.end, sp.end + 120);
    const qm = /(?:قال|يقول|قالا|فقال|انه قال|ان)[: «]/.exec(tail);
    if (qm) split = sp.end + qm.index + qm[0].length;
    else split = sp.end;
    if (isNahj) split = 0;
    // نحول فهرس الموقع في النص المُطبّع إلى النص الأصلي (قد يختلف الطول) — نستخدم النص المطبّع للعرض إن اختلفت الأطوال
    const useNorm = false;
    let topics = topicsFor(h, n);
    if (sp.code === "mahdi" && !topics.includes("mahdi")) topics = ["mahdi", ...topics.filter((x) => x !== "misc")].slice(0, 2);
    // بدون نسبة تقريبية للفهرس: نحسب الفصل على النص الأصلي بإعادة التطبيع تدريجياً
    let sanadLen = 0;
    {
      let acc = 0;
      let prevSpace = true; // norm() يقص المسافات الأولية
      for (let i = 0; i < text.length; i++) {
        const c = text[i];
        let add;
        if (/[\u064B-\u065F\u0670\u0640\u06D6-\u06ED]/.test(c)) add = 0;
        else if (c === "\uFDF2") { add = 4; prevSpace = false; }
        else if (/\s/.test(c)) { add = prevSpace ? 0 : 1; prevSpace = true; }
        else { add = 1; prevSpace = false; }
        acc += add;
        if (acc >= split) { sanadLen = i + 1; break; }
      }
      // أكمل مع أي تشكيل لاحق
      while (sanadLen < text.length && /[\u064B-\u065F\u0670\u0640\u06D6-\u06ED]/.test(text[sanadLen])) sanadLen++;
      if (sanadLen === 0 || text.length - sanadLen < 15) sanadLen = 0;
    }
    // نزيل التشكيل من السند فقط لتقليل الحجم
    const sanadPlain = text.slice(0, sanadLen).replace(/[\u064B-\u065F\u0670\u0640]/g, "");
    out.push({
      b: bi,
      n: h.id,
      t: sanadPlain + text.slice(sanadLen),
      s: sanadPlain.length,
      m: narr,
      c: topics,
      g: grade.t,
      gs: grade.src,
    });
    kept++;
  }
  stats[id] = kept;
}

// ---------- ترتيب وحفظ ----------
const meta = {
  books: bookKeys.map((k) => BOOKS[k]),
  imams: IMAMS.map(([code, name]) => [code, name]),
  topics: [...TOPICS.map(([code, name, icon]) => [code, name, icon]), ["misc", "متفرقات", "🧩"]],
  tiers: TIERS,
};
fs.mkdirSync(path.dirname(OUT), { recursive: true });
fs.writeFileSync(OUT, JSON.stringify({ meta, items: out }));
console.log("total", out.length);
console.log(stats);
const byImam = {};
for (const o of out) byImam[o.m[0]] = (byImam[o.m[0]] || 0) + 1;
console.log(byImam);
const byTopic = {};
let noTopic = 0;
for (const o of out) { if (!o.c.length) noTopic++; for (const c of o.c) byTopic[c] = (byTopic[c] || 0) + 1; }
console.log(byTopic, "noTopic", noTopic);
const byTier = {};
for (const o of out) byTier[o.g] = (byTier[o.g] || 0) + 1;
console.log(byTier);
console.log("size MB", (fs.statSync(OUT).size / 1e6).toFixed(2));
