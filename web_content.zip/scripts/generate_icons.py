#!/usr/bin/env python3
import os
import struct
import zlib

def create_png(width, height, r, g, b, output_path):
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    
    # Simple PNG generator without PIL
    raw_data = bytearray()
    for y in range(height):
        raw_data.append(0) # filter byte: None
        for x in range(width):
            # Inner border or gold/red gradient
            is_border = (x < 10 or x >= width - 10 or y < 10 or y >= height - 10)
            if is_border:
                raw_data.extend([0xF5, 0x9E, 0x0B, 0xFF]) # Amber/Gold
            else:
                raw_data.extend([r, g, b, 0xFF])
                
    compressed = zlib.compress(bytes(raw_data))
    
    png = bytearray(b'\x89PNG\r\n\x1a\n')
    
    # IHDR
    ihdr_data = struct.pack('>IIBBBBB', width, height, 8, 6, 0, 0, 0)
    ihdr_crc = zlib.crc32(b'IHDR' + ihdr_data)
    png.extend(struct.pack('>I', len(ihdr_data)))
    png.extend(b'IHDR')
    png.extend(ihdr_data)
    png.extend(struct.pack('>I', ihdr_crc))
    
    # IDAT
    idat_crc = zlib.crc32(b'IDAT' + compressed)
    png.extend(struct.pack('>I', len(compressed)))
    png.extend(b'IDAT')
    png.extend(compressed)
    png.extend(struct.pack('>I', idat_crc))
    
    # IEND
    iend_crc = zlib.crc32(b'IEND')
    png.extend(struct.pack('>I', 0))
    png.extend(b'IEND')
    png.extend(struct.pack('>I', iend_crc))
    
    with open(output_path, 'wb') as f:
        f.write(png)
    print(f"Generated {output_path} ({width}x{height})")


if __name__ == '__main__':
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    public_dir = os.path.join(base_dir, 'public')
    
    create_png(192, 192, 0x99, 0x1B, 0x1B, os.path.join(public_dir, 'pwa-192x192.png'))
    create_png(512, 512, 0x99, 0x1B, 0x1B, os.path.join(public_dir, 'pwa-512x512.png'))
    create_png(512, 512, 0x7F, 0x1D, 0x1D, os.path.join(public_dir, 'pwa-maskable-512x512.png'))
    create_png(180, 180, 0x99, 0x1B, 0x1B, os.path.join(public_dir, 'apple-touch-icon.png'))
    create_png(64, 64, 0x99, 0x1B, 0x1B, os.path.join(public_dir, 'favicon.ico'))
