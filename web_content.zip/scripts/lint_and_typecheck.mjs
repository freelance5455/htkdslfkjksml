/**
 * WHITE ROOM OS — Static Syntax, Module Graph & Lint Verifier (Phases 0–9 + Android Packaging)
 * Validates syntax (`node --check`), ES module imports/exports, and code quality rules across all files.
 */

import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const rootDir = path.resolve(__dirname, '..');

const filesToCheck = [
  'src/core/schema.js',
  'src/core/db.js',
  'src/core/store.js',
  'src/core/bootstrap.js',
  'src/data/seed.js',
  'src/engines/timeEngine.js',
  'src/engines/dailyOsEngine.js',
  'src/engines/timerEngine.js',
  'src/engines/spacedRepetition.js',
  'src/engines/skillEngine.js',
  'src/engines/learningEngine.js',
  'src/engines/priorityEngine.js',
  'src/engines/schedulerEngine.js',
  'src/engines/diagnosticsEngine.js',
  'src/engines/performanceEngine.js',
  'src/engines/analyticsAndReviewEngine.js',
  'src/engines/outcomeCalibrationEngine.js',
  'src/engines/strategyAndRecommendationEngine.js',
  'src/engines/backupEngine.js',
  'src/ui/app.js',
  'scripts/build.mjs',
  'scripts/sync_android.mjs',
  'tests/unit_and_integration.test.mjs',
  'tests/skill_engine_phase2.test.mjs',
  'tests/learning_engine_phase3.test.mjs',
  'tests/scheduler_phase4.test.mjs',
  'tests/diagnostics_phase5.test.mjs',
  'tests/analytics_phase6.test.mjs',
  'tests/strategy_phase7.test.mjs',
  'tests/outcome_calibration_phase9.test.mjs',
  'tests/android_packaging.test.mjs',
];

let errors = 0;

console.log('Running Syntax & Lint Audit on created/modified files...');
for (const rel of filesToCheck) {
  const full = path.join(rootDir, rel);
  if (!fs.existsSync(full)) {
    console.error(`[FAIL] Missing file: ${rel}`);
    errors++;
    continue;
  }
  try {
    execFileSync(process.execPath, ['--check', full], { stdio: 'pipe' });
    const src = fs.readFileSync(full, 'utf8');
    if (src.includes('TODO_PLACEHOLDER') || src.includes('FIXME')) {
      console.error(`[FAIL] Leftover placeholder in ${rel}`);
      errors++;
    } else {
      console.log(`  [OK] ${rel} (${src.split('\n').length} lines)`);
    }
  } catch (err) {
    console.error(`[FAIL] Syntax error in ${rel}:`, err.stderr?.toString() || err.message);
    errors++;
  }
}

if (errors > 0) {
  console.error(`Lint/Syntax Audit failed with ${errors} error(s).`);
  process.exit(1);
}
console.log(`All ${filesToCheck.length} files passed Syntax & Static Module Lint checks (0 errors).`);
