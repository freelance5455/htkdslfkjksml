/**
 * WHITE ROOM OS — Build & Bundle Pipeline (Phase 9 Outcome Calibration, Recommendation Effectiveness & Evidence-Based Improvement)
 * Bundles all ES Modules + CSS into:
 * 1. dist/index.html (Capacitor Android webDir target)
 * 2. Deliverable WebApp HTML (white_room_os_phase9.html)
 * 3. Verified JSON Database Backup (white_room_os_phase9_backup.json)
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createWhiteRoomSystem } from '../src/core/bootstrap.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(__dirname, '..');
const outputDir = '/working_dir/c_67864cb0942409d1/artifacts/file_generation/ttl=63d/output';

const moduleOrder = [
  'src/core/schema.js',
  'src/core/db.js',
  'src/core/store.js',
  'src/data/seed.js',
  'src/engines/timeEngine.js',
  'src/engines/dailyOsEngine.js',
  'src/engines/timerEngine.js',
  'src/engines/spacedRepetition.js',
  'src/engines/skillEngine.js',
  'src/engines/learningEngine.js',
  'src/engines/priorityEngine.js',
  'src/engines/schedulerEngine.js',
  'src/engines/diagnosticsEngine.js',
  'src/engines/performanceEngine.js',
  'src/engines/analyticsAndReviewEngine.js',
  'src/engines/outcomeCalibrationEngine.js',
  'src/engines/strategyAndRecommendationEngine.js',
  'src/engines/backupEngine.js',
  'src/core/bootstrap.js',
  'src/ui/app.js',
];

function stripImportsAndExports(code) {
  return code
    .replace(/^\s*import\s+[\s\S]*?from\s+['"][^'"]+['"];?\s*$/gm, '')
    .replace(/^\s*export\s+default\s+/gm, '')
    .replace(/^\s*export\s+(const|let|var|function|async\s+function|class)\s+/gm, '$1 ')
    .replace(/^\s*export\s*\{[\s\S]*?\};?\s*$/gm, '');
}

async function runBuild() {
  const cssContent = fs.readFileSync(path.join(projectRoot, 'src/ui/styles.css'), 'utf8');

  const bundledJsParts = [];
  for (const relPath of moduleOrder) {
    const raw = fs.readFileSync(path.join(projectRoot, relPath), 'utf8');
    bundledJsParts.push(`// === MODULE: ${relPath} ===\n` + stripImportsAndExports(raw));
  }

  const bundledJs = `(function () {\n  'use strict';\n${bundledJsParts.join('\n\n')}\n\n  window.addEventListener('DOMContentLoaded', () => {\n    const root = document.getElementById('app-root');\n    if (root) mountWhiteRoomApp(root);\n  });\n})();`;

  const htmlDocument = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <meta name="theme-color" content="#090d16" />
  <title>WHITE ROOM OS v9.0 — Phase 9 Outcome Calibration & Recommendation Effectiveness</title>
  <style>
${cssContent}
  </style>
</head>
<body>
  <div id="app-root"></div>
  <script>
${bundledJs}
  </script>
</body>
</html>`;

  const distDir = path.join(projectRoot, 'dist');
  fs.mkdirSync(distDir, { recursive: true });
  fs.mkdirSync(outputDir, { recursive: true });

  const distHtmlPath = path.join(distDir, 'index.html');
  const outHtmlPhase9Path = path.join(outputDir, 'white_room_os_phase9.html');

  fs.writeFileSync(distHtmlPath, htmlDocument, 'utf8');
  fs.writeFileSync(outHtmlPhase9Path, htmlDocument, 'utf8');

  // Generate verified Phase 9 seed backup JSON
  const sys = await createWhiteRoomSystem({ forceMemory: true, initialDate: '2026-10-14' });
  const backup = await sys.engines.backupEngine.exportBackup();
  const backupOutPath = path.join(outputDir, 'white_room_os_phase9_backup.json');
  fs.writeFileSync(backupOutPath, JSON.stringify(backup, null, 2), 'utf8');

  console.log(`Phase 9 Build completed successfully:`);
  console.log(` - Dist HTML: ${distHtmlPath} (${htmlDocument.length} bytes)`);
  console.log(` - Output WebApp HTML: ${outHtmlPhase9Path}`);
  console.log(` - Phase 9 Backup JSON: ${backupOutPath} (Schema v${backup.schemaVersion}, Checksum: ${backup.checksum}, Records: ${backup.totalRecords}, Stores: ${Object.keys(backup.stores).length})`);
}

runBuild().catch((err) => {
  console.error('Build failed:', err);
  process.exit(1);
});
