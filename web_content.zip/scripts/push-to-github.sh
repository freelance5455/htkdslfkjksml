#!/usr/bin/env bash
# ==============================================================================
# Push Task Earn Pro to GitHub (subhodipgarai7654-collab/TaskEarnPro)
# Automated APK CI/CD & GitHub Actions Flowrun Setup
# ==============================================================================
set -e

REPO_USER="subhodipgarai7654-collab"
REPO_NAME="TaskEarnPro"
REPO_URL="https://github.com/${REPO_USER}/${REPO_NAME}.git"

echo "=============================================================================="
echo "🚀 Connecting & Pushing Task Earn Pro to GitHub: ${REPO_USER}/${REPO_NAME}"
echo "=============================================================================="

# 1. Initialize git if not already present
if [ ! -d ".git" ]; then
    echo "📦 Initializing local Git repository..."
    git init
fi

# 2. Configure Git user credentials
git config user.name "Subhodip Garai"
git config user.email "subhodipgarai7654@gmail.com"

# 3. Configure Remote URL
if git remote | grep -q "origin"; then
    echo "🔄 Updating existing remote origin to ${REPO_URL}..."
    git remote set-url origin "${REPO_URL}"
else
    echo "🔗 Adding remote origin ${REPO_URL}..."
    git remote add origin "${REPO_URL}"
fi

# 4. Set default branch to main
git branch -M main

# 5. Stage and commit latest code
echo "📝 Staging latest application code & Android APK build files..."
git add .
if git diff-index --quiet HEAD -- 2>/dev/null; then
    echo "ℹ️ No uncommitted changes detected."
else
    git commit -m "feat: Task Earn Pro v2.5.0 Android APK & CI/CD workflow for subhodipgarai7654-collab" || true
fi

echo "=============================================================================="
echo "✅ GitHub Repository Successfully Connected!"
echo "   - Remote URL: ${REPO_URL}"
echo "   - Branch: main"
echo "   - User: ${REPO_USER}"
echo "   - Flowrun Actions: https://github.com/${REPO_USER}/${REPO_NAME}/actions"
echo "   - APK Releases: https://github.com/${REPO_USER}/${REPO_NAME}/releases"
echo "=============================================================================="
echo ""
echo "To push code to GitHub and trigger automatic APK build workflow (flowrun):"
echo "  👉 git push -u origin main"
echo ""
echo "Or if using a GitHub Personal Access Token (PAT):"
echo "  👉 git remote set-url origin https://<YOUR_GITHUB_TOKEN>@github.com/${REPO_USER}/${REPO_NAME}.git"
echo "  👉 git push -u origin main"
echo "=============================================================================="
