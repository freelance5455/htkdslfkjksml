/**
 * Local harness for the Vercel build.
 *
 * Runs the same entry point Vercel compiles (`server/vercel.ts`), backed by a
 * local libSQL file database, so the whole API can be exercised without a
 * hosted account or a Cloudflare runtime.
 *
 *   npm run vercel-dev
 */
import { createServer } from 'node:http';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const port = Number(process.env.PORT || 3100);
const databaseFile = resolve(process.env.LOCAL_DB || '.vercel-local.db');
if (!process.env.NO_DB) process.env.TURSO_DATABASE_URL = process.env.TURSO_DATABASE_URL || `file:${databaseFile}`;
process.env.APP_ENV = 'vercel-local';

const { default: handler } = await import(pathToFileURL(resolve('build/vercel-function.mjs')).href);

const server = createServer((req, res) => {
  handler(req, res).catch((error) => {
    console.error('[vercel-dev]', error);
    if (!res.headersSent) res.writeHead(500, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ error: 'Local harness failure.' }));
  });
});

server.listen(port, '0.0.0.0', () => {
  console.log(`Vercel bundle listening on http://0.0.0.0:${port} (db: ${databaseFile})`);
});
