#!/usr/bin/env python3
"""Rasterize the shift-ledger launcher icon without extra libraries."""
import struct
import sys
import zlib

SIZE = 192


def png(size: int) -> bytes:
    green = (14, 106, 81, 255)
    white = (243, 250, 246, 255)
    radius = 42

    def inside_round(x: int, y: int) -> bool:
        inset = radius
        if inset <= x < size - inset and inset <= y < size - inset:
            return True
        corners = (
            (inset, inset),
            (size - inset - 1, inset),
            (inset, size - inset - 1),
            (size - inset - 1, size - inset - 1),
        )
        for cx, cy in corners:
            if (x - cx) ** 2 + (y - cy) ** 2 <= radius * radius:
                return True
        return False

    def plus(x: int, y: int) -> bool:
        cx = cy = size // 2
        arm = int(size * 0.11)
        reach = int(size * 0.28)
        return (abs(x - cx) <= arm and abs(y - cy) <= reach) or (
            abs(y - cy) <= arm and abs(x - cx) <= reach
        )

    raw = bytearray()
    for y in range(size):
        raw.append(0)
        for x in range(size):
            if inside_round(x, y) and plus(x, y):
                raw.extend(white)
            elif inside_round(x, y):
                raw.extend(green)
            else:
                raw.extend((0, 0, 0, 0))

    def chunk(tag: bytes, data: bytes) -> bytes:
        return (
            struct.pack(">I", len(data))
            + tag
            + data
            + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)
        )

    ihdr = struct.pack(">IIBBBBB", size, size, 8, 6, 0, 0, 0)
    return (
        b"\x89PNG\r\n\x1a\n"
        + chunk(b"IHDR", ihdr)
        + chunk(b"IDAT", zlib.compress(bytes(raw), 9))
        + chunk(b"IEND", b"")
    )


def main() -> None:
    dest = sys.argv[1]
    with open(dest, "wb") as handle:
        handle.write(png(SIZE))


if __name__ == "__main__":
    main()
