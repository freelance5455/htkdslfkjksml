#!/usr/bin/env python3
"""Static and model-resolution checks for Moto Sim V73 Phase 5 audio work.
Requires Python 3 and Node.js. Does not replace hearing the game in a browser/device.
"""
from pathlib import Path
import re, subprocess, sys, json
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'www/index.html').read_text(encoding='utf-8')
checks=[]
def check(label,ok): checks.append((label,bool(ok)))

inline=[]
for i,m in enumerate(re.finditer(r'<script\b([^>]*)>(.*?)</script\s*>',source,re.I|re.S),1):
    attrs,body=m.groups()
    if 'src=' not in attrs.lower() and body.strip():
        inline.append((i,body))
        tmp=ROOT/f'.phase5-audio-inline-{i}.js';tmp.write_text(body,encoding='utf-8')
        result=subprocess.run(['node','--check',str(tmp)],capture_output=True,text=True)
        check(f'inline JavaScript block {i} parses',result.returncode==0)
        if result.returncode: print(result.stderr)
        tmp.unlink(missing_ok=True)
check('three inline JavaScript blocks found',len(inline)==3)
check('all engine profiles can be resolved dynamically','function getEngineSoundProfile(def)' in source and 'function getEngineModelKey(def)' in source)
check('2-stroke firing frequency uses one event per crank revolution','rpm * def.cyls / (isTwoStroke ? 60 : 120)' in source)
check('crank-angle scheduler uses model firing-angle arrays','scheduleCombustionEvents(rpm,throttle,def,profile,now,running,isTwoStroke)' in source and 'def.fireAngle' in source)
check('combustion transient uses filtered noise and a decaying envelope','triggerCombustionPulse(def, profile, atTime, throttle)' in source and "band.type='bandpass'" in source and 'exponentialRampToValueAtTime' in source)
check('factory turbo engines have native turbo sound','factoryTurbo=[\'2JZ\',\'RB26\',\'ROTARY2\',\'ROTARY3\'].includes(model)' in source)
check('supercharged V8 uses a distinct lower whine','factorySuper=model===\'V8SC\'' in source and 'factorySuper? (1250+' in source)
check('sound hint uses resolved model profile','getEngineSoundProfile(ENGINE_DEFS[state.engineType]).label' in source)

# Execute the engine table + sound-profile resolver in Node to ensure every declared engine resolves.
engine_start=source.index('const ENGINE_DEFS = {')
engine_end=source.index('const SPECIAL_ENGINE_TYPES',engine_start)
sound_start=source.index('function getEngineModelKey(def)')
sound_end=source.index('class EngineAudioEngine {',sound_start)
js=source[engine_start:engine_end]+'\n'+source[sound_start:sound_end]+"\nglobalThis.__profiles=Object.entries(ENGINE_DEFS).map(([key,def])=>({key,profile:getEngineSoundProfile(def),model:getEngineModelKey(def)}));\n"
tmp=ROOT/'.phase5-profile-resolution.js';tmp.write_text(js,encoding='utf-8')
run=subprocess.run(['node','-e',f"require({json.dumps(str(tmp))}); console.log(JSON.stringify(globalThis.__profiles.map(x=>({{key:x.key,model:x.model,pitch:x.profile.pitch,low:x.profile.low,grit:x.profile.grit,label:x.profile.label}}))))"],capture_output=True,text=True)
tmp.unlink(missing_ok=True)
profiles=[]
if run.returncode==0:
    try: profiles=json.loads(run.stdout)
    except Exception: pass
check('Node resolves a profile for every engine definition',run.returncode==0 and len(profiles)>=30 and all(isinstance(x.get('pitch'),(int,float)) and isinstance(x.get('low'),(int,float)) for x in profiles))
check('at least 8 distinct sound timbres are generated',len({(round(x.get('pitch',0),2),round(x.get('low',0),2),round(x.get('grit',0),2)) for x in profiles})>=8)
check('36 or more engine definitions remain available',len(profiles)>=36)
for label,ok in checks: print(('PASS' if ok else 'FAIL')+'  '+label)
print(f'\nSummary: {sum(ok for _,ok in checks)}/{len(checks)} checks passed; {len(profiles)} engines resolved.')
if not all(ok for _,ok in checks):
    if run.returncode: print(run.stderr)
    sys.exit(1)
