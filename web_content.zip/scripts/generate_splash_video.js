import sharp from 'sharp';
import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';

const FPS = 60;
const DURATION_SEC = 2.0;
const TOTAL_FRAMES = Math.round(FPS * DURATION_SEC); // 120 frames
const WIDTH = 1080;
const HEIGHT = 1920;
const FRAMES_DIR = path.resolve('temp_frames');

if (!fs.existsSync(FRAMES_DIR)) {
  fs.mkdirSync(FRAMES_DIR, { recursive: true });
}

// Ease out cubic
function easeOutCubic(x) {
  return 1 - Math.pow(1 - x, 3);
}

// Ease in out quad
function easeInOutQuad(x) {
  return x < 0.5 ? 2 * x * x : 1 - Math.pow(-2 * x + 2, 2) / 2;
}

function generateSvgFrame(frameIndex) {
  const t = frameIndex / TOTAL_FRAMES; // 0 to 1
  
  // Phase 1: Intro scale & fade (0 to 0.4)
  let scale = 0.6 + 0.4 * easeOutCubic(Math.min(t / 0.45, 1));
  let opacity = Math.min(t / 0.25, 1);
  
  // Phase 2: Gentle breathing pulse (0.45 to 1.0)
  if (t > 0.45) {
    const pulseT = (t - 0.45) / 0.55;
    scale += Math.sin(pulseT * Math.PI * 2) * 0.035;
  }

  // Rotations
  const ring1Rotation = -28 + t * 45;
  const ring2Rotation = 42 - t * 40;
  const ring3Rotation = t * 360;

  // Particle positions
  const p1Angle = (t * 2 * Math.PI) + 0.3;
  const p1X = 256 + Math.cos(p1Angle) * 165;
  const p1Y = 256 + Math.sin(p1Angle) * 85;

  const p2Angle = (-t * 2 * Math.PI) + 2.5;
  const p2X = 256 + Math.cos(p2Angle) * 155;
  const p2Y = 256 + Math.sin(p2Angle) * 80;

  // Soundwave animation
  const waveShift = Math.sin(t * Math.PI * 4) * 8;
  const coreGlowStdDev = 8 + Math.sin(t * Math.PI * 3) * 4;

  // Text reveal (from 0.4 to 0.8)
  const textOpacity = t < 0.35 ? 0 : Math.min((t - 0.35) / 0.35, 1);
  const textTranslateY = 30 * (1 - easeOutCubic(Math.min(Math.max((t - 0.35) / 0.35, 0), 1)));

  // Shockwave ring pulse at t = 0.45
  let shockwaveRadius = 0;
  let shockwaveOpacity = 0;
  if (t >= 0.4) {
    const shockT = (t - 0.4) / 0.6;
    shockwaveRadius = 145 + shockT * 180;
    shockwaveOpacity = Math.max(0, 1 - shockT) * 0.45;
  }

  return `<svg viewBox="0 0 1080 1920" width="1080" height="1920" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <radialGradient id="bgGlow" cx="50%" cy="45%" r="60%">
        <stop offset="0%" stop-color="#141c38" stop-opacity="0.9" />
        <stop offset="50%" stop-color="#0a0c16" stop-opacity="1" />
        <stop offset="100%" stop-color="#040508" stop-opacity="1" />
      </radialGradient>

      <radialGradient id="sphereCoreGrad" cx="38%" cy="32%" r="65%">
        <stop offset="0%" stop-color="#67e8f9" />
        <stop offset="28%" stop-color="#06b6d4" />
        <stop offset="68%" stop-color="#4f46e5" />
        <stop offset="92%" stop-color="#0f172a" />
        <stop offset="100%" stop-color="#05070f" />
      </radialGradient>

      <linearGradient id="ringGradCyan" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#22d3ee" />
        <stop offset="50%" stop-color="#a855f7" />
        <stop offset="100%" stop-color="#f43f5e" />
      </linearGradient>

      <linearGradient id="ringGradViolet" x1="100%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stop-color="#c084fc" />
        <stop offset="60%" stop-color="#38bdf8" />
        <stop offset="100%" stop-color="#4f46e5" />
      </linearGradient>

      <linearGradient id="whisperWave" x1="0%" y1="50%" x2="100%" y2="50%">
        <stop offset="0%" stop-color="#a5f3fc" stop-opacity="0.3" />
        <stop offset="50%" stop-color="#ffffff" stop-opacity="1" />
        <stop offset="100%" stop-color="#c084fc" stop-opacity="0.3" />
      </linearGradient>

      <filter id="neonGlow" x="-50%" y="-50%" width="200%" height="200%">
        <feGaussianBlur stdDeviation="${coreGlowStdDev}" result="blur" />
        <feMerge>
          <feMergeNode in="blur" />
          <feMergeNode in="SourceGraphic" />
        </feMerge>
      </filter>
    </defs>

    <!-- Deep Midnight Screen Background -->
    <rect width="1080" height="1920" fill="url(#bgGlow)"/>

    <!-- Central Logo Group -->
    <g transform="translate(540, 840) scale(${scale * 1.5}) translate(-256, -256)" opacity="${opacity}">
      
      <!-- Shockwave pulse -->
      ${shockwaveRadius > 0 ? `
        <circle cx="256" cy="256" r="${shockwaveRadius}" stroke="url(#ringGradCyan)" stroke-width="4" fill="none" opacity="${shockwaveOpacity}" />
      ` : ''}

      <!-- Outer Whispering Soundwave Ring -->
      <circle cx="256" cy="256" r="215" stroke="url(#ringGradCyan)" stroke-width="4.5" stroke-dasharray="14 18" opacity="0.6" transform="rotate(${ring3Rotation} 256 256)"/>

      <!-- Orbital Ellipse 1 -->
      <ellipse cx="256" cy="256" rx="205" ry="92" transform="rotate(${ring1Rotation} 256 256)" stroke="url(#ringGradCyan)" stroke-width="8.5" stroke-linecap="round" opacity="0.88"/>

      <!-- Orbital Ellipse 2 -->
      <ellipse cx="256" cy="256" rx="200" ry="86" transform="rotate(${ring2Rotation} 256 256)" stroke="url(#ringGradViolet)" stroke-width="6.5" stroke-dasharray="24 16" opacity="0.75"/>

      <!-- Solid Holographic Sphere Body -->
      <circle cx="256" cy="256" r="145" fill="url(#sphereCoreGrad)" stroke="#38bdf8" stroke-width="6.5" stroke-opacity="0.9"/>

      <!-- Sphere Specular Highlight (Glass Shine) -->
      <ellipse cx="210" cy="190" rx="55" ry="32" transform="rotate(-30 210 190)" fill="#ffffff" fill-opacity="0.45"/>

      <!-- Whispering Voice Waveform -->
      <path d="M 155 256 Q 182 ${208 + waveShift}, 210 256 T 256 256 T 302 256 T 357 256" stroke="url(#whisperWave)" stroke-width="11" stroke-linecap="round" fill="none" filter="url(#neonGlow)"/>
      <path d="M 180 256 Q 220 ${175 + waveShift * 0.7}, 256 256 T 332 256" stroke="#ffffff" stroke-width="6.5" stroke-linecap="round" fill="none" opacity="0.9"/>

      <!-- Center Spark Core -->
      <circle cx="256" cy="256" r="15" fill="#ffffff" filter="url(#neonGlow)" />

      <!-- Orbiting Particle Nodes -->
      <circle cx="${p1X}" cy="${p1Y}" r="12" fill="#22d3ee" filter="url(#neonGlow)"/>
      <circle cx="${p2X}" cy="${p2Y}" r="10" fill="#f43f5e"/>
    </g>

    <!-- App Name Title (Appears at bottom like Instagram splash) -->
    <g transform="translate(540, 1340) translate(0, ${textTranslateY})" opacity="${textOpacity}">
      <text text-anchor="middle" y="0" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" font-size="58" font-weight="800" fill="#ffffff" letter-spacing="2">
        Secret<tspan fill="#22d3ee">Sphere</tspan>
      </text>
      <text text-anchor="middle" y="48" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" font-size="24" font-weight="500" fill="#94a3b8" letter-spacing="4">
        WHERE SECRETS FIND A VOICE
      </text>
    </g>
  </svg>`;
}

async function run() {
  console.log(`Generating ${TOTAL_FRAMES} frames for 2-second video...`);
  
  for (let i = 0; i < TOTAL_FRAMES; i++) {
    const svgStr = generateSvgFrame(i);
    const framePath = path.join(FRAMES_DIR, `frame_${String(i).padStart(4, '0')}.png`);
    await sharp(Buffer.from(svgStr))
      .resize(WIDTH, HEIGHT)
      .png({ quality: 90 })
      .toFile(framePath);
    
    if (i % 30 === 0) {
      console.log(`Rendered frame ${i}/${TOTAL_FRAMES}`);
    }
  }

  console.log('All frames rendered! Compiling silent MP4 video with FFmpeg...');

  const outputPath = path.resolve('public', 'splash.mp4');
  const ffmpegCmd = `ffmpeg -y -framerate ${FPS} -i "${FRAMES_DIR}/frame_%04d.png" -c:v libx264 -profile:v high -level 4.2 -pix_fmt yuv420p -an "${outputPath}"`;
  
  execSync(ffmpegCmd, { stdio: 'inherit' });
  console.log(`Success! Video saved to ${outputPath}`);

  // Cleanup frames
  fs.rmSync(FRAMES_DIR, { recursive: true, force: true });
  console.log('Cleaned up temp frames.');
}

run().catch(err => {
  console.error(err);
  process.exit(1);
});
