import fs from 'fs';
import { normalizeArabicString } from '../src/engine/normalization';
import { validateCrosswordLayout } from '../src/engine/CrosswordValidator';
import { CrosswordLayout, CrosswordLayoutWord, CrosswordLayoutCell, LayoutCellCoordinate, CrosswordLayoutClue } from '../src/types/crosswordLayout';

function cleanWord(str: string): string {
  return normalizeArabicString(str.replace(/\s+/g, ''));
}

const rawQuestions = [
  { id: 'q_01', clue: 'ما اسم المدينة التي كانت عاصمة الدولة العباسية؟', answer: 'بغداد' },
  { id: 'q_02', clue: 'ما أطول نهر في قارة أوروبا؟', answer: 'الفولغا' },
  { id: 'q_03', clue: 'ما العنصر الكيميائي الذي رمزه O؟', answer: 'الأكسجين' },
  { id: 'q_04', clue: 'ما العضو المسؤول بشكل رئيسي عن ضخ الدم إلى أنحاء الجسم؟', answer: 'القلب' },
  { id: 'q_05', clue: 'ما الكوكب المعروف بالكوكب الأحمر؟', answer: 'المريخ' },
  { id: 'q_06', clue: 'من الشاعر الملقب بشاعر النيل؟', answer: 'حافظ إبراهيم' },
  { id: 'q_07', clue: 'ما علامة رفع المثنى؟', answer: 'الألف' },
  { id: 'q_08', clue: 'ما اسم أقدم ملحمة أدبية معروفة في التاريخ؟', answer: 'جلجامش' },
  { id: 'q_09', clue: 'ما السورة التي تُسمى أم الكتاب؟', answer: 'الفاتحة' },
  { id: 'q_10', clue: 'من العالم الذي ارتبط اختراعه بالمصباح الكهربائي المتوهج تجاريًا؟', answer: 'إديسون' },
  { id: 'q_11', clue: 'ما اسم الآلة الموسيقية الوترية العربية التي تشتهر برقبتها الطويلة؟', answer: 'البزق' },
  { id: 'q_12', clue: 'كم عدد اللاعبين الأساسيين في فريق كرة القدم داخل الملعب؟', answer: 'أحد عشر' },
  { id: 'q_13', clue: 'ما أكبر حيوان معروف على سطح الأرض؟', answer: 'الحوت الأزرق' },
  { id: 'q_14', clue: 'ما عاصمة اليابان؟', answer: 'طوكيو' },
  { id: 'q_15', clue: 'من العالم المسلم الذي اشتهر بكتابه "القانون في الطب"؟', answer: 'ابن سينا' },
  { id: 'q_16', clue: 'ما المدينة التي تُعرف بلقب مدينة الألف مئذنة؟', answer: 'القاهرة' },
  { id: 'q_17', clue: 'ما المصطلح الذي يطلق على الارتفاع العام والمستمر في أسعار السلع والخدمات؟', answer: 'التضخم' },
  { id: 'q_18', clue: 'ما الاسم الذي يطلق على النص المكتوب الذي يصف أحداث الفيلم ومشاهده وحواراته؟', answer: 'السيناريو' },
  { id: 'q_19', clue: 'ما اسم التجربة الفكرية التي استخدمها أفلاطون لشرح انتقال الإنسان من عالم الظلال إلى معرفة الحقيقة؟', answer: 'كهف أفلاطون' },
  { id: 'q_20', clue: 'ما اسم السنة التي يكون فيها شهر فبراير 29 يومًا؟', answer: 'كبيسة' },
  { id: 'q_21', clue: 'ما الوحدة الأساسية لقياس شدة التيار الكهربائي؟', answer: 'الأمبير' },
  { id: 'q_22', clue: 'ما اسم المعاهدة التي أنهت حرب الثلاثين عامًا في أوروبا عام 1648؟', answer: 'وستفاليا' },
  { id: 'q_23', clue: 'ما اسم النظام الكتابي الذي اشتهر به السومريون؟', answer: 'المسمارية' },
  { id: 'q_24', clue: 'ما الجهاز الذي يحوّل الطاقة الكهربائية إلى ضوء؟', answer: 'المصباح' },
  { id: 'q_25', clue: 'ما العدد الذي يمثل مجموع المحيطات الكبرى على سطح الأرض؟', answer: 'خمسة' },
];

interface WordInfo {
  id: string;
  clue: string;
  answer: string;
  norm: string;
  len: number;
}

const words: WordInfo[] = rawQuestions.map(q => ({
  id: q.id,
  clue: q.clue,
  answer: q.answer,
  norm: cleanWord(q.answer),
  len: cleanWord(q.answer).length
}));

type Dir = 'across' | 'down';

interface Placement {
  word: WordInfo;
  dir: Dir;
  r: number;
  c: number;
}

// Let's test solving for 15x15
const GRID_SIZE = 15;

function checkAndSolve(): Placement[] | null {
  const grid: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
  const cellDirs: Set<Dir>[][] = Array.from({ length: GRID_SIZE }, () => Array.from({ length: GRID_SIZE }, () => new Set<Dir>()));

  function canFit(w: WordInfo, dir: Dir, r: number, c: number, placedCount: number): boolean {
    const len = w.len;
    if (dir === 'across') {
      if (c + len > GRID_SIZE || r < 0 || r >= GRID_SIZE || c < 0) return false;
      if (c > 0 && grid[r][c - 1] !== null) return false;
      if (c + len < GRID_SIZE && grid[r][c + len] !== null) return false;

      let touches = placedCount === 0;

      for (let k = 0; k < len; k++) {
        const cur = grid[r][c + k];
        if (cur !== null) {
          if (cur !== w.norm[k]) return false;
          if (cellDirs[r][c + k].has('across')) return false;
          touches = true;
        } else {
          if (r > 0 && grid[r - 1][c + k] !== null && !cellDirs[r - 1][c + k].has('down')) return false;
          if (r < GRID_SIZE - 1 && grid[r + 1][c + k] !== null && !cellDirs[r + 1][c + k].has('down')) return false;
        }
      }
      return touches;
    } else {
      if (r + len > GRID_SIZE || c < 0 || c >= GRID_SIZE || r < 0) return false;
      if (r > 0 && grid[r - 1][c] !== null) return false;
      if (r + len < GRID_SIZE && grid[r + len][c] !== null) return false;

      let touches = placedCount === 0;

      for (let k = 0; k < len; k++) {
        const cur = grid[r + k][c];
        if (cur !== null) {
          if (cur !== w.norm[k]) return false;
          if (cellDirs[r + k][c].has('down')) return false;
          touches = true;
        } else {
          if (c > 0 && grid[r + k][c - 1] !== null && !cellDirs[r + k][c - 1].has('across')) return false;
          if (c < GRID_SIZE - 1 && grid[r + k][c + 1] !== null && !cellDirs[r + k][c + 1].has('across')) return false;
        }
      }
      return touches;
    }
  }

  const placed: Placement[] = [];
  let maxPlaced = 0;
  let attempts = 0;

  function backtrack(unplaced: WordInfo[]): Placement[] | null {
    attempts++;
    if (placed.length > maxPlaced) {
      maxPlaced = placed.length;
      console.log(`Max placed: ${maxPlaced}/25 (attempts: ${attempts})`);
    }

    if (unplaced.length === 0) return [...placed];
    if (attempts > 500000) return null; // timeout limit per root

    // Gather valid positions for all unplaced words
    interface WOption {
      word: WordInfo;
      placements: { dir: Dir; r: number; c: number; inters: number }[];
    }

    const options: WOption[] = [];

    for (const w of unplaced) {
      const valid: { dir: Dir; r: number; c: number; inters: number }[] = [];
      for (const dir of ['across', 'down'] as Dir[]) {
        for (let r = 0; r < GRID_SIZE; r++) {
          for (let c = 0; c < GRID_SIZE; c++) {
            if (canFit(w, dir, r, c, placed.length)) {
              let inters = 0;
              for (let k = 0; k < w.len; k++) {
                const cr = dir === 'down' ? r + k : r;
                const cc = dir === 'across' ? c + k : c;
                if (grid[cr][cc] !== null) inters++;
              }
              valid.push({ dir, r, c, inters });
            }
          }
        }
      }

      if (valid.length === 0) return null; // MRV fail: this word has 0 possible placements
      options.push({ word: w, placements: valid });
    }

    // Sort by MRV (fewest placements)
    options.sort((a, b) => a.placements.length - b.placements.length);

    const chosen = options[0];
    const nextUnplaced = unplaced.filter(w => w.id !== chosen.word.id);

    // Sort placements by intersections descending
    chosen.placements.sort((a, b) => b.inters - a.inters);

    for (const pl of chosen.placements) {
      const changes: { r: number; c: number; wasNull: boolean }[] = [];
      for (let k = 0; k < chosen.word.len; k++) {
        const cr = pl.dir === 'down' ? pl.r + k : pl.r;
        const cc = pl.dir === 'across' ? pl.c + k : pl.c;
        const wasNull = grid[cr][cc] === null;
        grid[cr][cc] = chosen.word.norm[k];
        cellDirs[cr][cc].add(pl.dir);
        changes.push({ r: cr, c: cc, wasNull });
      }

      placed.push({ word: chosen.word, dir: pl.dir, r: pl.r, c: pl.c });

      const res = backtrack(nextUnplaced);
      if (res) return res;

      placed.pop();
      for (const ch of changes) {
        cellDirs[ch.r][ch.c].delete(pl.dir);
        if (ch.wasNull) grid[ch.r][ch.c] = null;
      }
    }

    return null;
  }

  // Try placing first word at center
  const firstWord = words.find(w => w.norm === 'حافظابراهيم') || words[0];
  const firstR = 7;
  const firstC = Math.floor((GRID_SIZE - firstWord.len) / 2);

  for (let k = 0; k < firstWord.len; k++) {
    grid[firstR][firstC + k] = firstWord.norm[k];
    cellDirs[firstR][firstC + k].add('across');
  }
  placed.push({ word: firstWord, dir: 'across', r: firstR, c: firstC });

  return backtrack(words.filter(w => w.id !== firstWord.id));
}

const sol = checkAndSolve();
console.log('Result:', sol ? 'FOUND!' : 'NOT FOUND');
