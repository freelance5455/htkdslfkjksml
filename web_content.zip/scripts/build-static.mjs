#!/usr/bin/env node
/**
 * Builds the offline Scoring app as a self-contained static website and
 * packages it for an Android WebView / APK builder.
 *
 * Output:
 *   out/                  raw Next.js static export
 *   scoring-apk-ready/    index.html at the ROOT, ready to zip
 *   scoring-apk-ready.zip index.html at the ZIP ROOT
 *
 * The optional cloud-sync API routes are moved aside during the build because
 * `output: "export"` cannot emit server route handlers. They are always
 * restored afterwards, so the normal server build is unaffected. Core cricket
 * scoring never needed them: match, league and tournament data all live in
 * IndexedDB on the device.
 */
import { execSync } from "node:child_process";
import {
  cpSync,
  existsSync,
  mkdirSync,
  readdirSync,
  renameSync,
  rmSync,
  statSync,
  readFileSync,
} from "node:fs";
import { join, resolve } from "node:path";

const root = resolve(import.meta.dirname, "..");
const apiDir = join(root, "src/app/api");
const apiStash = join(root, ".api-stash");
const outDir = join(root, "out");
const pkgDir = join(root, "scoring-apk-ready");
const zipPath = join(root, "scoring-apk-ready.zip");

function log(msg) {
  console.log(`\x1b[36m[static]\x1b[0m ${msg}`);
}

function restoreApi() {
  if (existsSync(apiStash)) {
    rmSync(apiDir, { recursive: true, force: true });
    renameSync(apiStash, apiDir);
    log("restored API routes");
  }
}

process.on("exit", restoreApi);
process.on("SIGINT", () => {
  restoreApi();
  process.exit(1);
});

try {
  // 1. Clean previous artefacts.
  for (const p of [outDir, pkgDir, zipPath]) rmSync(p, { recursive: true, force: true });

  // 2. Move server-only API routes aside for the export.
  if (existsSync(apiDir)) {
    rmSync(apiStash, { recursive: true, force: true });
    renameSync(apiDir, apiStash);
    log("set aside server API routes (cloud sync is optional)");
  }

  // 3. Static export.
  log("building static export…");
  execSync("npx next build", {
    cwd: root,
    stdio: "inherit",
    env: { ...process.env, STATIC_EXPORT: "1", NEXT_PUBLIC_STATIC_EXPORT: "1" },
  });

  restoreApi();

  if (!existsSync(join(outDir, "index.html"))) {
    throw new Error("export did not produce out/index.html");
  }

  // 4. Copy the export so index.html sits at the package ROOT.
  mkdirSync(pkgDir, { recursive: true });
  for (const entry of readdirSync(outDir)) {
    cpSync(join(outDir, entry), join(pkgDir, entry), { recursive: true });
  }
  log(`packaged into ${pkgDir}/`);

  // 5. Zip with index.html at the ZIP root (contents, not the folder).
  execSync(`cd "${pkgDir}" && zip -qr "${zipPath}" .`, { stdio: "inherit", shell: "/bin/bash" });

  // 6. Verify.
  const listing = execSync(`unzip -Z1 "${zipPath}"`, { encoding: "utf8" })
    .split("\n")
    .filter(Boolean);
  const rootIndex = listing.includes("index.html");
  const hasNext = listing.some((f) => f.startsWith("_next/"));
  const nested = listing.some((f) => /^(scoring-apk-ready|out|project)\//.test(f));

  const size = (p) => {
    let total = 0;
    const walk = (d) => {
      for (const e of readdirSync(d)) {
        const f = join(d, e);
        const st = statSync(f);
        if (st.isDirectory()) walk(f);
        else total += st.size;
      }
    };
    walk(p);
    return (total / 1024 / 1024).toFixed(1);
  };

  // No absolute asset URLs and no dev hosts may survive in the entry HTML.
  const html = readFileSync(join(pkgDir, "index.html"), "utf8");
  const badHost = /localhost|127\.0\.0\.1/.test(html);
  const absoluteAsset = /(?:src|href)="\/_next\//.test(html);

  console.log("");
  log("verification");
  console.log(`   index.html at ZIP root ....... ${rootIndex ? "YES" : "NO"}`);
  console.log(`   _next/ assets in ZIP ......... ${hasNext ? "YES" : "NO"}`);
  console.log(`   nested wrapper folder ........ ${nested ? "YES (bad)" : "no"}`);
  console.log(`   localhost / 127.0.0.1 in HTML  ${badHost ? "YES (bad)" : "no"}`);
  console.log(`   absolute /_next/ asset paths .. ${absoluteAsset ? "YES (bad)" : "no"}`);
  console.log(`   files in ZIP ................. ${listing.length}`);
  console.log(`   package size ................. ${size(pkgDir)} MB`);
  console.log(`   zip .......................... ${zipPath}`);

  if (!rootIndex || !hasNext || nested || badHost || absoluteAsset) {
    throw new Error("static package verification failed");
  }
  console.log("");
  log("scoring-apk-ready.zip is ready for the APK builder ✓");
} catch (err) {
  restoreApi();
  console.error(err instanceof Error ? err.message : err);
  process.exit(1);
}
