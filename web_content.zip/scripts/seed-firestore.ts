import { initializeApp } from 'firebase/app';
import { getFirestore, doc, setDoc, getDoc } from 'firebase/firestore';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const configPath = path.resolve(__dirname, '../firebase-applet-config.json');
const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));

const app = initializeApp(config);
const targetDatabaseId = config.firestoreDatabaseId || 'ai-studio-cubixstudiogloba-56ae10ae-a948-4558-ab74-2c1a5de01e30';
const db = getFirestore(app, targetDatabaseId);

console.log('[Seed] Connecting to named database:', targetDatabaseId, 'in project:', config.projectId);

async function main() {
  try {
    const storePath = path.resolve(__dirname, '../data/store.json');
    const rawData = JSON.parse(fs.readFileSync(storePath, 'utf-8'));

    // Flatten nested arrays in reputationData for Firestore compatibility
    const safeData = JSON.parse(JSON.stringify(rawData));
    if (safeData.reputationData && typeof safeData.reputationData === 'object') {
      for (const sectionKey of Object.keys(safeData.reputationData)) {
        const sec = safeData.reputationData[sectionKey];
        if (sec && Array.isArray(sec.metrics)) {
          sec.metrics = sec.metrics.map((m: unknown) => {
            if (Array.isArray(m)) {
              return { label: String(m[0] || ''), value: String(m[1] || '') };
            }
            return m;
          });
        }
      }
    }

    safeData.lastUpdated = new Date().toISOString();
    safeData.databaseProvider = 'firebase_firestore';
    safeData.databaseId = targetDatabaseId;

    console.log('[Seed] Writing production store to cubix_store/main_store...');
    const mainStoreRef = doc(db, 'cubix_store', 'main_store');
    await setDoc(mainStoreRef, safeData, { merge: true });
    console.log('[Seed] Successfully written to Firestore cubix_store/main_store!');

    // Verify read
    console.log('[Seed] Verifying read from named Firestore database...');
    const snapshot = await getDoc(mainStoreRef);
    if (!snapshot.exists()) {
      throw new Error('Verification failed: Document does not exist after write.');
    }
    const retrieved = snapshot.data();
    console.log('[Seed] Verification SUCCESS!');
    console.log(`[Seed] Found ${retrieved.projects?.length ?? 0} projects, ${retrieved.founders?.length ?? 0} founders, ${retrieved.services?.length ?? 0} services.`);

    // Seed admin record
    console.log('[Seed] Seeding admin record for real1cubix@gmail.com...');
    await setDoc(doc(db, 'admins', 'real1cubix_admin'), {
      email: 'real1cubix@gmail.com',
      role: 'superadmin',
      createdAt: new Date().toISOString()
    }, { merge: true });
    console.log('[Seed] Admin record seeded successfully.');

    process.exit(0);
  } catch (err) {
    console.error('[Seed Error]', err);
    process.exit(1);
  }
}

main();
