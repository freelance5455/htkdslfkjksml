import { STAGE_02_QUESTIONS } from '../src/data/stage02Questions';
import { normalizeArabicString } from '../src/engine/normalization';

function cleanWord(str: string): string {
  return normalizeArabicString(str.replace(/\s+/g, ''));
}

const words = STAGE_02_QUESTIONS.map(q => cleanWord(q.answer));
console.log('Words count:', words.length);
console.log('Total characters:', words.reduce((acc, w) => acc + w.length, 0));

// Check letter frequencies
const letterFreq: { [char: string]: number } = {};
for (const w of words) {
  for (const c of w) {
    letterFreq[c] = (letterFreq[c] || 0) + 1;
  }
}
console.log('Letter frequencies:', Object.entries(letterFreq).sort((a, b) => b[1] - a[1]));

// Check intersections between pairs of words
let pairOverlap = 0;
for (let i = 0; i < words.length; i++) {
  for (let j = i + 1; j < words.length; j++) {
    const setA = new Set(words[i]);
    const setB = new Set(words[j]);
    const common = [...setA].filter(c => setB.has(c));
    if (common.length > 0) pairOverlap++;
  }
}
console.log(`Word pairs with common letters: ${pairOverlap} / ${(words.length * (words.length - 1)) / 2}`);
