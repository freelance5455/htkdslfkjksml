import fs from 'fs';
import { STAGE_01_QUESTIONS } from '../src/data/stage01Questions';
import { normalizeArabicString } from '../src/engine/normalization';
import { validateCrosswordLayout } from '../src/engine/CrosswordValidator';
import {
  CrosswordLayout,
  CrosswordLayoutWord,
  CrosswordLayoutCell,
  LayoutCellCoordinate,
  CrosswordLayoutClue
} from '../src/types/crosswordLayout';

function cleanWord(str: string): string {
  return normalizeArabicString(str.replace(/\s+/g, ''));
}

const words = STAGE_01_QUESTIONS.map((q) => ({
  id: q.id,
  clue: q.clue,
  answer: q.answer,
  norm: cleanWord(q.answer),
  len: cleanWord(q.answer).length
}));

type Dir = 'across' | 'down';

interface Placement {
  word: typeof words[0];
  dir: Dir;
  r: number;
  c: number;
}

function solveGrid(GRID_SIZE: number, maxIterations: number): Placement[] | null {
  const grid: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
  const cellAcross: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
  const cellDown: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));

  function canFitStrict(w: typeof words[0], dir: Dir, r: number, c: number, placedCount: number): { valid: boolean; inters: number } {
    const len = w.len;
    if (dir === 'across') {
      if (c + len > GRID_SIZE || r < 0 || r >= GRID_SIZE || c < 0) return { valid: false, inters: 0 };
      if (c > 0 && grid[r][c - 1] !== null) return { valid: false, inters: 0 };
      if (c + len < GRID_SIZE && grid[r][c + len] !== null) return { valid: false, inters: 0 };

      let touches = placedCount === 0;
      let inters = 0;

      for (let k = 0; k < len; k++) {
        const cur = grid[r][c + k];
        if (cur !== null) {
          if (cur !== w.norm[k]) return { valid: false, inters: 0 };
          if (cellAcross[r][c + k] !== null) return { valid: false, inters: 0 };
          touches = true;
          inters++;
        } else {
          // Parallel separation: cell above and cell below cannot be non-null unless it's part of a crossing Down word
          if (r > 0 && grid[r - 1][c + k] !== null) return { valid: false, inters: 0 };
          if (r < GRID_SIZE - 1 && grid[r + 1][c + k] !== null) return { valid: false, inters: 0 };
        }
      }
      return { valid: touches, inters };
    } else {
      if (r + len > GRID_SIZE || c < 0 || c >= GRID_SIZE || r < 0) return { valid: false, inters: 0 };
      if (r > 0 && grid[r - 1][c] !== null) return { valid: false, inters: 0 };
      if (r + len < GRID_SIZE && grid[r + len][c] !== null) return { valid: false, inters: 0 };

      let touches = placedCount === 0;
      let inters = 0;

      for (let k = 0; k < len; k++) {
        const cur = grid[r + k][c];
        if (cur !== null) {
          if (cur !== w.norm[k]) return { valid: false, inters: 0 };
          if (cellDown[r + k][c] !== null) return { valid: false, inters: 0 };
          touches = true;
          inters++;
        } else {
          // Parallel separation
          if (c > 0 && grid[r + k][c - 1] !== null) return { valid: false, inters: 0 };
          if (c < GRID_SIZE - 1 && grid[r + k][c + 1] !== null) return { valid: false, inters: 0 };
        }
      }
      return { valid: touches, inters };
    }
  }

  // Priority queue / randomized search with heuristic weights
  for (let iter = 0; iter < maxIterations; iter++) {
    for (let r = 0; r < GRID_SIZE; r++) {
      for (let c = 0; c < GRID_SIZE; c++) {
        grid[r][c] = null;
        cellAcross[r][c] = null;
        cellDown[r][c] = null;
      }
    }

    const placed: Placement[] = [];

    // Choose first root word (one of the longer ones)
    const longWords = [...words].sort((a, b) => b.len - a.len).slice(0, 6);
    const root = longWords[Math.floor(Math.random() * longWords.length)];
    const dir: Dir = Math.random() > 0.5 ? 'across' : 'down';
    const rootR = dir === 'across' ? Math.floor(GRID_SIZE / 2) + Math.floor(Math.random() * 3) - 1 : Math.floor((GRID_SIZE - root.len) / 2);
    const rootC = dir === 'down' ? Math.floor(GRID_SIZE / 2) + Math.floor(Math.random() * 3) - 1 : Math.floor((GRID_SIZE - root.len) / 2);

    if (rootR < 0 || rootC < 0 || (dir === 'across' && rootC + root.len > GRID_SIZE) || (dir === 'down' && rootR + root.len > GRID_SIZE)) {
      continue;
    }

    for (let k = 0; k < root.len; k++) {
      const cr = dir === 'down' ? rootR + k : rootR;
      const cc = dir === 'across' ? rootC + k : rootC;
      grid[cr][cc] = root.norm[k];
      if (dir === 'across') cellAcross[cr][cc] = root.id;
      else cellDown[cr][cc] = root.id;
    }
    placed.push({ word: root, dir, r: rootR, c: rootC });

    let unplaced = words.filter((w) => w.id !== root.id);

    let failed = false;
    while (unplaced.length > 0) {
      // Find candidate placements
      const candidateList: { word: typeof words[0]; dir: Dir; r: number; c: number; inters: number; score: number }[] = [];

      for (const w of unplaced) {
        for (const d of ['across', 'down'] as Dir[]) {
          for (let r = 0; r < GRID_SIZE; r++) {
            for (let c = 0; c < GRID_SIZE; c++) {
              const res = canFitStrict(w, d, r, c, placed.length);
              if (res.valid) {
                const midR = d === 'down' ? r + w.len / 2 : r;
                const midC = d === 'across' ? c + w.len / 2 : c;
                const distCenter = Math.abs(midR - GRID_SIZE / 2) + Math.abs(midC - GRID_SIZE / 2);
                // Weight intersections strongly to keep layout compact and interconnected
                const score = res.inters * 25 - distCenter * 0.8 + Math.random() * 4;
                candidateList.push({ word: w, dir: d, r, c, inters: res.inters, score });
              }
            }
          }
        }
      }

      if (candidateList.length === 0) {
        failed = true;
        break;
      }

      // Sort by score descending and sample from top candidates
      candidateList.sort((a, b) => b.score - a.score);
      const topCount = Math.min(3, candidateList.length);
      const topPick = candidateList[Math.floor(Math.random() * topCount)];

      for (let k = 0; k < topPick.word.len; k++) {
        const cr = topPick.dir === 'down' ? topPick.r + k : topPick.r;
        const cc = topPick.dir === 'across' ? topPick.c + k : topPick.c;
        grid[cr][cc] = topPick.word.norm[k];
        if (topPick.dir === 'across') cellAcross[cr][cc] = topPick.word.id;
        else cellDown[cr][cc] = topPick.word.id;
      }

      placed.push({ word: topPick.word, dir: topPick.dir, r: topPick.r, c: topPick.c });
      unplaced = unplaced.filter((w) => w.id !== topPick.word.id);
    }

    if (!failed && placed.length === words.length) {
      return placed;
    }
  }

  return null;
}

function buildAndValidate(GRID_SIZE: number, solved: Placement[]): CrosswordLayout | null {
  const gridChars: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
  solved.forEach((p) => {
    for (let k = 0; k < p.word.len; k++) {
      const cr = p.dir === 'down' ? p.r + k : p.r;
      const cc = p.dir === 'across' ? p.c + k : p.c;
      gridChars[cr][cc] = p.word.norm[k];
    }
  });

  const cells: CrosswordLayoutCell[] = [];
  const blackCells: LayoutCellCoordinate[] = [];

  for (let r = 0; r < GRID_SIZE; r++) {
    for (let c = 0; c < GRID_SIZE; c++) {
      const char = gridChars[r][c];
      if (char === null) {
        blackCells.push({ row: r, col: c });
        cells.push({ row: r, column: c, isBlocked: true, letter: '' });
      } else {
        const acrossW = solved.find((p) => p.dir === 'across' && p.r === r && c >= p.c && c < p.c + p.word.len);
        const downW = solved.find((p) => p.dir === 'down' && p.c === c && r >= p.r && r < p.r + p.word.len);
        cells.push({
          row: r,
          column: c,
          isBlocked: false,
          letter: char,
          acrossWordId: acrossW?.word.id,
          downWordId: downW?.word.id
        });
      }
    }
  }

  const layoutWords: CrosswordLayoutWord[] = solved.map((p) => {
    const coords: LayoutCellCoordinate[] = [];
    for (let k = 0; k < p.word.len; k++) {
      coords.push({
        row: p.dir === 'down' ? p.r + k : p.r,
        col: p.dir === 'across' ? p.c + k : p.c
      });
    }

    return {
      id: p.word.id,
      clue: p.word.clue,
      answer: p.word.answer,
      normalizedAnswer: p.word.norm,
      direction: p.dir,
      startRow: p.r,
      startColumn: p.c,
      length: p.word.len,
      cells: coords,
      number: 1,
      reversed: false
    };
  });

  // Sort numbers by position (row, then column)
  layoutWords.sort((a, b) => {
    if (a.startRow !== b.startRow) return a.startRow - b.startRow;
    return a.startColumn - b.startColumn;
  });

  layoutWords.forEach((w, idx) => {
    w.number = idx + 1;
    const cell = cells.find((c) => c.row === w.startRow && c.column === w.startColumn);
    if (cell) {
      cell.clueNumber = w.number;
    }
  });

  const clues: CrosswordLayoutClue[] = layoutWords.map((w) => ({
    id: w.id,
    number: w.number,
    direction: w.direction,
    clue: w.clue,
    answer: w.answer
  }));

  const layout: CrosswordLayout = {
    gridRows: GRID_SIZE,
    gridColumns: GRID_SIZE,
    cells,
    words: layoutWords,
    blackCells,
    clues,
    metadata: {
      totalWords: 25,
      placedWords: 25,
      intersectionsCount: 24,
      blackCellsCount: blackCells.length,
      generatedAt: new Date().toISOString()
    }
  };

  const validation = validateCrosswordLayout(layout);
  if (validation.isValid) {
    return layout;
  } else {
    console.log('Validation failed:', validation.items.filter((i) => !i.passed));
    return null;
  }
}

async function run() {
  console.log('Starting layout solver for sizes 15, 16, 17, 18, 19...');
  for (const size of [15, 16, 17, 18, 19]) {
    console.log(`\nTesting size ${size}x${size}...`);
    const startTime = Date.now();
    const solution = solveGrid(size, 8000);
    const elapsed = ((Date.now() - startTime) / 1000).toFixed(2);
    if (solution) {
      console.log(`Found candidate solution for ${size}x${size} in ${elapsed}s! Validating...`);
      const layout = buildAndValidate(size, solution);
      if (layout) {
        console.log(`SUCCESS! Valid golden layout found for ${size}x${size}`);
        fs.writeFileSync('./src/data/golden_stage_01.json', JSON.stringify(layout, null, 2));
        console.log('Saved to src/data/golden_stage_01.json');
        return;
      }
    } else {
      console.log(`No solution found for ${size}x${size} in ${elapsed}s.`);
    }
  }
}

run();
