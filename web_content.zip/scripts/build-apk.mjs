import {execFileSync} from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
if(!fs.existsSync(path.join(root,'node_modules','@capacitor','cli')))throw new Error('Run npm install first.');
function command(exe,args,dir=root){console.log('>',exe,...args);execFileSync(exe,args,{cwd:dir,stdio:'inherit'});}
if(!fs.existsSync(path.join(root,'android')))command('npx',['cap','add','android']);
command('npx',['cap','sync','android']);
// Android LAN multiplayer for a local development server may require HTTP cleartext.
// In production, prefer WSS and remove this permission.
const manifest=path.join(root,'android','app','src','main','AndroidManifest.xml');
if(fs.existsSync(manifest)){
 let xml=fs.readFileSync(manifest,'utf8');
 if(!xml.includes('android:usesCleartextTraffic=')){
  xml=xml.replace(/<application\b/, '<application android:usesCleartextTraffic="true"');
  fs.writeFileSync(manifest,xml);
 }
}
const gradlew=process.platform==='win32'?'gradlew.bat':'./gradlew';
command(gradlew,['assembleDebug'],path.join(root,'android'));
console.log('APK:',path.join(root,'android','app','build','outputs','apk','debug','app-debug.apk'));
