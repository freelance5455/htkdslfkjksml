import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import esbuild from 'esbuild';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');
const distAssetsDir = path.resolve(rootDir, 'dist/assets');
const apkDir = path.resolve(rootDir, 'apk');

fs.mkdirSync(apkDir, { recursive: true });

// 1. Build classic non-module IIFE bundle so ZIP-to-APK builders & Android WebView (file://)
// can execute the full React app directly with zero ES-module CORS or TypeScript errors.
await esbuild.build({
  entryPoints: [path.resolve(rootDir, 'src/main.tsx')],
  bundle: true,
  format: 'iife',
  platform: 'browser',
  target: ['es2019', 'chrome80', 'safari13'],
  jsx: 'automatic',
  minify: true,
  define: {
    'process.env.NODE_ENV': '"production"',
  },
  loader: {
    '.css': 'empty',
  },
  outfile: path.resolve(apkDir, 'app.js'),
});

// 2. Copy the Vite-compiled Tailwind CSS into apk/app.css so styles load identically offline.
if (!fs.existsSync(distAssetsDir)) {
  throw new Error('dist/assets not found. Run "npm run build" before "npm run build:apk".');
}

const cssFiles = fs
  .readdirSync(distAssetsDir)
  .filter((file) => file.endsWith('.css'));

if (cssFiles.length === 0) {
  throw new Error('No compiled CSS file found in dist/assets.');
}

const mergedCss = cssFiles
  .map((file) => fs.readFileSync(path.join(distAssetsDir, file), 'utf8'))
  .join('\n');

fs.writeFileSync(path.resolve(apkDir, 'app.css'), mergedCss, 'utf8');

// 3. Mirror apk/ into dist/apk/ so both root ZIP and dist/ ZIP work seamlessly in APK builders.
const distApkDir = path.resolve(rootDir, 'dist/apk');
fs.cpSync(apkDir, distApkDir, { recursive: true, force: true });

console.log(
  `[build-apk] Built apk/app.js (${fs.statSync(path.resolve(apkDir, 'app.js')).size} bytes) and apk/app.css (${fs.statSync(path.resolve(apkDir, 'app.css')).size} bytes)`
);
