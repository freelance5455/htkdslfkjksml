import {execSync} from 'child_process';
import fs from 'fs';
import path from 'path';
import {fileURLToPath} from 'url';
import * as esbuild from 'esbuild';

const rootDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const distDir = path.join(rootDir, 'dist');

console.log('1/3 Building static web bundle without service worker...');
execSync('npx vite build', {
  cwd: rootDir,
  stdio: 'inherit',
  env: {
    ...process.env,
    NO_PWA: 'true',
    VITE_NO_PWA: 'true',
  },
});

console.log('2/3 Converting ES module scripts to WebView/file:// compatible IIFE...');
const indexPath = path.join(distDir, 'index.html');
let html = fs.readFileSync(indexPath, 'utf8');

const scriptMatches = [...html.matchAll(/<script\s+type="module"[^>]*src="([^"]+)"[^>]*><\/script>/g)];
for (const match of scriptMatches) {
  const fullTag = match[0];
  const srcRel = match[1].replace(/^\.\//, '');
  const jsFile = path.join(distDir, srcRel);
  if (fs.existsSync(jsFile)) {
    const rawJs = fs.readFileSync(jsFile, 'utf8').replaceAll(
      'import.meta.url',
      'new URL("./assets/",window.location.href).href'
    );
    const result = await esbuild.transform(rawJs, {
      format: 'iife',
      minify: true,
    });
    fs.writeFileSync(jsFile, result.code, 'utf8');
  }
  html = html.replace(fullTag, `<script defer src="./${srcRel}"></script>`);
}

// Remove crossorigin attribute on CSS links so file:///android_asset/ loads cleanly
html = html.replace(/<link\s+rel="stylesheet"\s+crossorigin\s+href="([^"]+)">/g, '<link rel="stylesheet" href="$1">');

fs.writeFileSync(indexPath, html, 'utf8');
console.log('3/3 Done! dist/ is ready for Android WebView, Cordova, or Capacitor APK packaging.');
