import { chromium } from "playwright";
import fs from "node:fs";

const OUT = "test-output";
fs.mkdirSync(OUT, { recursive: true });
const logs = [];
const browser = await chromium.launch({ args: ["--no-sandbox"] });
let exitCode = 0;

try {
  const context = await browser.newContext({ viewport: { width: 1440, height: 1000 }, locale: "ar-SA", acceptDownloads: true });
  const page = await context.newPage();
  page.on("console", (message) => logs.push(`[console:${message.type()}] ${message.text()}`));
  page.on("pageerror", (error) => logs.push(`[pageerror] ${error.message}`));
  await page.goto("http://localhost:4173/", { waitUntil: "networkidle" });
  await page.waitForTimeout(1400);
  await page.screenshot({ path: `${OUT}/dashboard-desktop.png`, fullPage: false });
  await page.screenshot({ path: `${OUT}/dashboard-full.png`, fullPage: true });

  await page.getByRole("button", { name: /اختبار المحرك/ }).first().click();
  await page.waitForTimeout(1200);
  await page.screenshot({ path: `${OUT}/selftest-idle.png`, fullPage: false });
  const bodyBefore = await page.locator("body").innerText();
  fs.writeFileSync(`${OUT}/selftest-page.txt`, bodyBefore);

  const runButton = page.getByRole("button", { name: /تشغيل الاختبار الفني|تشغيل الاختبار الآن/ }).first();
  if (await runButton.isDisabled()) {
    console.log("ENGINE_UNSUPPORTED");
    await page.screenshot({ path: `${OUT}/selftest-unsupported.png`, fullPage: false });
    exitCode = 2;
  } else {
    await runButton.click();
    try {
      await page.getByText("نجح الاختبار وتم التحقق من MP4").waitFor({ timeout: 240000 });
      console.log("SELFTEST_PASS");
      await page.waitForTimeout(600);
      await page.screenshot({ path: `${OUT}/selftest-pass.png`, fullPage: false });
      const downloadPromise = page.waitForEvent("download", { timeout: 30000 });
      await page.getByRole("button", { name: /^تنزيل$/ }).first().click();
      const download = await downloadPromise;
      await download.saveAs(`${OUT}/quiz-engine-test.mp4`);
      console.log(`DOWNLOADED ${fs.statSync(`${OUT}/quiz-engine-test.mp4`).size} bytes`);
    } catch (error) {
      console.log("SELFTEST_FAIL", error.message);
      await page.screenshot({ path: `${OUT}/selftest-fail.png`, fullPage: false });
      const text = await page.locator("body").innerText();
      fs.writeFileSync(`${OUT}/selftest-fail.txt`, text);
      exitCode = 1;
    }
  }

  const mobile = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, locale: "ar-SA" });
  const mobilePage = await mobile.newPage();
  await mobilePage.goto("http://localhost:4173/", { waitUntil: "networkidle" });
  await mobilePage.waitForTimeout(1200);
  await mobilePage.screenshot({ path: `${OUT}/dashboard-mobile.png`, fullPage: false });
  await mobilePage.getByRole("button", { name: /الأسئلة/ }).first().click();
  await mobilePage.waitForTimeout(800);
  await mobilePage.screenshot({ path: `${OUT}/questions-mobile.png`, fullPage: false });
} catch (error) {
  console.log("TEST_CRASH", error.message);
  exitCode = 1;
} finally {
  fs.writeFileSync(`${OUT}/browser-console.log`, logs.join("\n"));
  await browser.close();
}

process.exit(exitCode);
