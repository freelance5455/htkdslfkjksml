import puppeteer from "puppeteer-core";
import { createServer } from "http";
import { readFileSync, existsSync } from "fs";
import { extname, join } from "path";

const MIME = { ".html": "text/html", ".js": "text/javascript", ".css": "text/css" };
const server = createServer((req, res) => {
  let p = req.url.split("?")[0]; if (p === "/") p = "/index.html";
  const f = join(process.cwd() + "/dist", p);
  if (!existsSync(f)) { res.writeHead(404); res.end(); return; }
  res.writeHead(200, { "Content-Type": MIME[extname(f)] || "text/plain" }); res.end(readFileSync(f));
});
await new Promise((r) => server.listen(4188, r));

const browser = await puppeteer.launch({
  executablePath: "/usr/bin/chromium", headless: "new",
  args: ["--no-sandbox", "--disable-setuid-sandbox", "--use-gl=swiftshader", "--enable-unsafe-swiftshader", "--disable-dev-shm-usage"],
});

async function measure(label, throttle, viewport) {
  const page = await browser.newPage();
  const cdp = await page.target().createCDPSession();
  await cdp.send("Emulation.setCPUThrottlingRate", { rate: throttle });
  await page.setViewport(viewport);
  await page.goto("http://localhost:4188/", { waitUntil: "load" });
  await new Promise((r) => setTimeout(r, 800));
  await page.evaluate(() => { [...document.querySelectorAll("button")].find((b) => b.innerText.includes("Novo Jogo"))?.click(); });
  await new Promise((r) => setTimeout(r, 900));
  // caminha enquanto mede
  await page.keyboard.down("KeyA");
  const stats = await page.evaluate(() => new Promise((resolve) => {
    const frames = [];
    let last = performance.now();
    let n = 0;
    function tick(now) {
      frames.push(now - last); last = now; n++;
      if (n < 180) requestAnimationFrame(tick);
      else {
        frames.sort((a, b) => a - b);
        const avg = frames.reduce((a, b) => a + b, 0) / frames.length;
        resolve({ avg, p95: frames[Math.floor(frames.length * 0.95)], worst: frames[frames.length - 1], fps: 1000 / avg });
      }
    }
    requestAnimationFrame(tick);
  }));
  await page.keyboard.up("KeyA");
  console.log(`${label}: media ${stats.fps.toFixed(1)} fps (${stats.avg.toFixed(2)}ms) | p95 ${stats.p95.toFixed(2)}ms | pior ${stats.worst.toFixed(2)}ms`);
  await page.close();
  return stats;
}

const mob = { width: 412, height: 915, isMobile: true, hasTouch: true, deviceScaleFactor: 2 };
const desk = { width: 1280, height: 720 };

const a = await measure("desktop  1x CPU ", 1, desk);
const b = await measure("celular  4x CPU ", 4, mob);
const c = await measure("celular  6x CPU ", 6, mob);

const okAll = a.fps > 45 && b.fps > 40 && c.fps > 30;
console.log("\nVEREDITO:", okAll ? "PERFORMANCE OK" : "PRECISA OTIMIZAR");
await browser.close();
server.close();
