/**
 * Runtime Verification Suite for JARVIS Task #10
 * Tests Projects, Conversations, Search, Trash/Restore, and Context Engine.
 */

async function runTests() {
  const BASE = 'http://localhost:3000';
  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, testName: string) {
    if (condition) {
      console.log(`✅ [PASS] ${testName}`);
      passed++;
    } else {
      console.error(`❌ [FAIL] ${testName}`);
      failed++;
    }
  }

  console.log('--- Starting JARVIS Task #10 Runtime Verification Suite ---');

  // 1. Health Check
  const healthRes = await fetch(`${BASE}/api/health`).then(r => r.json());
  assert(healthRes.status === 'ok', 'Server health check returns status ok');

  // 2. Database Health & Persistence Check
  const dbHealthRes = await fetch(`${BASE}/api/database/health`).then(r => r.json());
  assert(dbHealthRes.status === 'CONNECTED' && dbHealthRes.provider === 'sqlite', 'Database is CONNECTED with persistent SQLite');
  assert(Number(dbHealthRes.totalTables) >= 10, 'All required persistent tables exist');

  // 3. Create Project
  const createProjRes = await fetch(`${BASE}/api/projects`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      name: 'Project Chronos - Quantum Warp Dynamics',
      description: 'Theoretical framework for warp bubble spacetime curvature.',
      contextBrief: 'Focus on Alcubierre metrics and Casimir negative energy densities.',
    }),
  }).then(r => r.json());

  assert(createProjRes.success === true && createProjRes.project?.id, 'Project created successfully');
  const projectId = createProjRes.project.id;

  // 4. Retrieve Projects List
  const listProjectsRes = await fetch(`${BASE}/api/projects`).then(r => r.json());
  const foundProject = listProjectsRes.projects?.find((p: any) => p.id === projectId);
  assert(Boolean(foundProject), 'Project is listed in GET /api/projects');

  // 5. Update Project
  const updateProjRes = await fetch(`${BASE}/api/projects/${projectId}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      description: 'Updated: Theoretical and computational framework for warp metrics.',
    }),
  }).then(r => r.json());
  assert(updateProjRes.success === true && updateProjRes.project.description.includes('computational'), 'Project updated successfully');

  // 6. Create Conversation Associated with Project
  const createConvRes = await fetch(`${BASE}/api/conversations`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      title: 'Initial Metric Calculations',
      topic: 'Physics',
      projectId: projectId,
    }),
  }).then(r => r.json());

  assert(createConvRes.success === true && createConvRes.conversation?.id, 'Conversation created with project association');
  const convId = createConvRes.conversation.id;
  assert(createConvRes.conversation.projectId === projectId, 'Conversation has correct projectId');

  // 7. Filter Conversations by Project
  const filterConvRes = await fetch(`${BASE}/api/conversations?projectId=${projectId}`).then(r => r.json());
  const matchedInProject = filterConvRes.conversations?.find((c: any) => c.id === convId);
  assert(Boolean(matchedInProject), 'Conversation filtered successfully by projectId');

  // 8. Send Message in Conversation (Trigger Context + Storage)
  const chatRes = await fetch(`${BASE}/api/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      prompt: 'Explain how stress-energy tensors relate to Casimir force boundaries',
      conversationId: convId,
      modelId: 'jarvis-deterministic-offline',
    }),
  }).then(r => r.json());

  assert(chatRes.success === true && chatRes.message?.content, 'Chat execution completed');

  // 9. Search Conversations
  const searchRes = await fetch(`${BASE}/api/conversations/search?q=stress-energy`).then(r => r.json());
  assert(searchRes.conversations?.length > 0, 'Search returned matching conversations');
  const searchHit = searchRes.conversations?.find((r: any) => r.id === convId);
  assert(Boolean(searchHit), 'Search found target conversation');
  assert(Boolean(searchHit?.matchedSnippet), 'Search result contains matchedSnippet');

  // 10. Soft-Delete (Move to Trash)
  const deleteRes = await fetch(`${BASE}/api/conversations/${convId}`, { method: 'DELETE' }).then(r => r.json());
  assert(deleteRes.success === true, 'Conversation moved to trash');

  // 11. Verify excluded from active list
  const activeConvsRes = await fetch(`${BASE}/api/conversations`).then(r => r.json());
  const inActive = activeConvsRes.conversations?.find((c: any) => c.id === convId);
  assert(!inActive, 'Conversation excluded from active conversations list');

  // 12. Verify present in trash list
  const trashConvsRes = await fetch(`${BASE}/api/conversations?isTrashOnly=true`).then(r => r.json());
  const inTrash = trashConvsRes.conversations?.find((c: any) => c.id === convId);
  assert(Boolean(inTrash), 'Conversation present in trash list');

  // 13. Restore from Trash
  const restoreRes = await fetch(`${BASE}/api/conversations/${convId}/restore`, { method: 'POST' }).then(r => r.json());
  assert(restoreRes.success === true, 'Conversation restored successfully');

  // 14. Verify back in active list
  const activeConvsAfterRes = await fetch(`${BASE}/api/conversations`).then(r => r.json());
  const inActiveAfter = activeConvsAfterRes.conversations?.find((c: any) => c.id === convId);
  assert(Boolean(inActiveAfter), 'Restored conversation is back in active list');

  // 15. Auto-titling & Epistemic Classification check
  const { generateConversationTitle } = await import('../server/chat/titleGenerator.ts');
  const generatedTitle = generateConversationTitle('Explain how to build an autonomous multi-agent swarm in TypeScript');
  assert(Boolean(generatedTitle) && generatedTitle.length > 3, `Auto-titler generated title: "${generatedTitle}"`);

  const { classifyPromptCapability } = await import('../server/capabilities/capabilityDiscovery.ts');
  const offlineCheck = classifyPromptCapability('calculate 25 * 40 + sqrt(144)', { hasGeminiApiKey: false });
  assert(offlineCheck.category === 'MATHEMATICAL_CALCULATION' && offlineCheck.isSupported, 'Mathematical calculation classified as supported offline');

  console.log(`\n========================================`);
  console.log(`Verification Complete: ${passed} Passed, ${failed} Failed`);
  console.log(`========================================`);

  if (failed > 0) {
    process.exit(1);
  }
}

runTests().catch(err => {
  console.error('Test runner fatal error:', err);
  process.exit(1);
});
