import puppeteer from "puppeteer";
import { createServer } from "node:http";
import { readFile } from "node:fs/promises";

const html = await readFile(new URL("../dist/index.html", import.meta.url));

const server = createServer((_req, res) => {
  res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
  res.end(html);
});
await new Promise((r) => server.listen(4173, r));

const browser = await puppeteer.launch({
  headless: true,
  args: [
    "--no-sandbox",
    "--disable-setuid-sandbox",
    "--use-gl=angle",
    "--use-angle=swiftshader",
    "--enable-unsafe-swiftshader",
    "--disable-dev-shm-usage",
  ],
});

const page = await browser.newPage();
await page.setViewport({ width: 1280, height: 800 });

const logs = [];
page.on("console", (m) => logs.push(`[${m.type()}] ${m.text()}`));
page.on("pageerror", (e) => logs.push(`PAGEERROR: ${e.message}`));

await page.goto("http://localhost:4173/", { waitUntil: "load", timeout: 60000 });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

await sleep(3500);
await page.screenshot({ path: "shots/01-menu.png" });
console.log("menu rendered");

// start the run
await page.evaluate(() => {
  const btn = [...document.querySelectorAll("button")].find((b) =>
    b.textContent.includes("شروع"),
  );
  btn?.click();
});

await sleep(2500);
await page.screenshot({ path: "shots/02-countdown.png" });
console.log("countdown rendered");

await sleep(3500);
await page.screenshot({ path: "shots/03-play.png" });

// steer around a bit
await page.keyboard.down("ArrowLeft");
await sleep(500);
await page.keyboard.up("ArrowLeft");
await sleep(700);
await page.keyboard.down("ArrowRight");
await sleep(600);
await page.keyboard.up("ArrowRight");
await sleep(300);
await page.keyboard.down("Shift");
await sleep(1200);
await page.keyboard.up("Shift");
await page.screenshot({ path: "shots/04-drive.png" });

const hud = await page.evaluate(() => {
  const text = document.body.innerText.replace(/\s+/g, " ");
  return text.slice(0, 400);
});
console.log("HUD TEXT:", hud);

await sleep(2500);
await page.screenshot({ path: "shots/05-later.png" });

console.log("\n--- console logs ---");
console.log(logs.slice(0, 40).join("\n") || "(no logs)");

await browser.close();
server.close();
