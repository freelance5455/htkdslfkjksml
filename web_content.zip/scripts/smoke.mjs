// End-to-end smoke test: the build must already exist in dist/ (`pnpm build`).
// Serves dist/, boots the game in headless Chromium with a phone viewport and touch, flies with real
// pointer events on the on-screen joystick and throttle, dives into the terrain, checks the crash and
// results screen, retries, and fails on any console error. Screenshots go to ./shots/.
import { spawn } from 'node:child_process'
import { existsSync, mkdirSync } from 'node:fs'
import { chromium } from 'playwright'

const port = 4300 + Math.floor(Math.random() * 500)
const url = `http://127.0.0.1:${port}/`
const out = process.env.SHOTS_DIR ?? 'shots'
mkdirSync(out, { recursive: true })
const server = spawn(process.execPath, ['node_modules/vite/bin/vite.js', 'preview', '--port', String(port), '--strictPort', '--host', '127.0.0.1'], { stdio: 'ignore' })
let browser
const guard = setTimeout(() => fail('timed out'), 170_000)
function cleanup() {
  clearTimeout(guard)
  try { server.kill('SIGTERM') } catch { /* already gone */ }
}
async function fail(msg) {
  console.error(`smoke: FAIL — ${msg}`)
  await browser?.close().catch(() => {})
  cleanup()
  process.exit(1)
}
async function waitForServer() {
  for (let i = 0; i < 60; i += 1) {
    try { if ((await fetch(url)).ok) return } catch { /* not yet */ }
    await new Promise(r => setTimeout(r, 250))
  }
  throw new Error('preview server did not start')
}
const state = page => page.evaluate(() => {
  const g = window.__game
  return { mode: g.game.mode, screen: g.ui.screen, stick: { x: g.input.stick.x, y: g.input.stick.y }, throttle: g.input.throttle, speed: g.game.flight.speed, score: g.game.run.score }
})

try {
  await waitForServer()
  const executablePath = ['/usr/bin/chromium', '/usr/bin/chromium-browser', '/usr/bin/google-chrome'].find(existsSync)
  browser = await chromium.launch({
    executablePath,
    args: ['--ignore-gpu-blocklist', '--use-gl=swiftshader', '--enable-unsafe-swiftshader', '--enable-webgl'],
  })
  const context = await browser.newContext({ viewport: { width: 844, height: 390 }, hasTouch: true, isMobile: true })
  const page = await context.newPage()
  const errors = []
  page.on('console', m => m.type() === 'error' && errors.push(m.text()))
  page.on('pageerror', e => errors.push(String(e)))
  page.on('response', r => r.status() >= 400 && errors.push(`HTTP ${r.status()} ${r.url()}`))
  await page.goto(url)
  await page.waitForFunction(() => window.__game, { timeout: 90_000 })
  await page.waitForSelector('section[data-screen="title"]:not([hidden])', { timeout: 30_000 })
  await page.waitForTimeout(1200)
  if ((await page.locator('html').getAttribute('lang')) !== 'es') await fail('page language is not Spanish')
  await page.screenshot({ path: `${out}/1-title.png` })

  await page.click('[data-act="play"]')
  await page.waitForTimeout(1500)
  if ((await state(page)).mode !== 'playing') await fail('game did not start')
  await page.screenshot({ path: `${out}/2-flight.png` })

  // Real multi-touch: left thumb on the joystick, right thumb on the throttle.
  const cdp = await context.newCDPSession(page)
  const touch = (type, points) => cdp.send('Input.dispatchTouchEvent', { type, touchPoints: points })
  const track = await page.evaluate(() => { const r = document.querySelector('[data-track]').getBoundingClientRect(); return { x: r.x + r.width / 2, top: r.top, bottom: r.bottom } })
  await touch('touchStart', [{ x: 120, y: 280, id: 1 }, { x: track.x, y: track.bottom - 10, id: 2 }])
  await touch('touchMove', [{ x: 175, y: 250, id: 1 }, { x: track.x, y: track.top + 6, id: 2 }])
  await page.waitForTimeout(400)
  const touched = await state(page)
  if (touched.stick.x < 0.5) await fail(`joystick did not register (${JSON.stringify(touched.stick)})`)
  if (touched.throttle < 0.9) await fail(`throttle slider did not register (${touched.throttle})`)
  await page.waitForTimeout(1800)
  await page.screenshot({ path: `${out}/3-touch.png` })
  await touch('touchEnd', [])
  await page.waitForTimeout(200)
  const released = await state(page)
  if (Math.abs(released.stick.x) > 0.01) await fail('joystick did not recentre on release')

  // Dive into the ground: the aircraft must crash and the results appear.
  await page.evaluate(() => window.__game.input.setTouchStick(0, 1))
  let crashed = false
  for (let i = 0; i < 80 && !crashed; i += 1) {
    await page.waitForTimeout(250)
    crashed = (await state(page)).mode !== 'playing'
  }
  if (!crashed) await fail('aircraft did not crash into the terrain')
  await page.waitForSelector('section[data-screen="results"]:not([hidden])', { timeout: 20_000 })
  await page.screenshot({ path: `${out}/4-results.png` })

  // Retry from the results screen.
  await page.click('section[data-screen="results"] [data-act="restart"]')
  await page.waitForTimeout(1200)
  if ((await state(page)).mode !== 'playing') await fail('retry did not restart the flight')

  // Pause and resume.
  await page.click('[data-act="pause"]')
  await page.waitForSelector('section[data-screen="pause"]:not([hidden])', { timeout: 5000 })
  await page.click('[data-act="resume"]')
  await page.waitForTimeout(500)
  if ((await state(page)).mode !== 'playing') await fail('resume did not continue the flight')

  const real = errors.filter(e => !/GPU stall|GL Driver|ReadPixels/.test(e))
  if (real.length) await fail(`console errors:\n${real.join('\n')}`)
  console.log('smoke: OK')
  await browser.close()
  cleanup()
  process.exit(0)
} catch (error) {
  await fail(String(error?.stack ?? error))
}
