// Headless smoke test for the game engine: mocks the canvas + timers and
// plays several full games (perfect type-mode run, a no-input run, pausing,
// tapping the right / wrong tile and using the hint).
//
// Run with:
//   npx esbuild src/game/engine.ts --bundle --format=esm --outfile=build/engine.mjs
//   node scripts/smoke.mjs
import { GameEngine } from "../build/engine.mjs";

const ctxStub = new Proxy(
  {},
  {
    get(target, prop) {
      if (prop in target) return target[prop];
      if (prop === "measureText") return (t) => ({ width: String(t).length * 9 });
      if (prop === "createLinearGradient" || prop === "createRadialGradient")
        return () => ({ addColorStop() {} });
      if (prop === "canvas") return {};
      return () => {};
    },
    set(target, prop, value) {
      target[prop] = value;
      return true;
    },
  },
);

const canvas = {
  width: 0,
  height: 0,
  getContext: () => ctxStub,
  getBoundingClientRect: () => ({ width: 820, height: 520, left: 0, top: 0 }),
};

global.document = {
  createElement: (tag) =>
    tag === "canvas"
      ? { width: 0, height: 0, getContext: () => ctxStub }
      : { style: {} },
  hidden: false,
};

global.ResizeObserver = class {
  observe() {}
  disconnect() {}
};

global.window = global.window ?? {};
global.window.devicePixelRatio = 1;
global.window.requestAnimationFrame = global.requestAnimationFrame;

let rafQueue = [];
let clock = 0;
global.requestAnimationFrame = (cb) => {
  rafQueue.push(cb);
  return rafQueue.length;
};
global.cancelAnimationFrame = () => {};

function step(ms = 16.7) {
  clock += ms;
  const q = rafQueue;
  rafQueue = [];
  for (const cb of q) cb(clock);
}

function makeEngine(cfg) {
  const events = [];
  const engine = new GameEngine(canvas, cfg, {
    onState: () => {},
    onTick: () => {},
    onEvent: (e) => events.push(e),
  });
  return { engine, events };
}

const WORDS = [
  { id: "a", en: "apple", fa: "سیب", sentence: "An apple.", sentenceFa: "یک سیب." },
  { id: "b", en: "bread", fa: "نان", sentence: "Some bread.", sentenceFa: "کمی نان." },
  { id: "c", en: "milk", fa: "شیر", sentence: "I like milk.", sentenceFa: "من شیر دوست دارم." },
  { id: "d", en: "rice", fa: "برنج", sentence: "We eat rice.", sentenceFa: "ما برنج می‌خوریم." },
];

let failures = 0;
function check(name, cond, extra = "") {
  if (cond) {
    console.log(`  ✅ ${name}`);
  } else {
    failures++;
    console.log(`  ❌ ${name} ${extra}`);
  }
}

/* ---------------------------------------------------------------- */
console.log("\n[1] type mode — perfect player");
{
  const { engine, events } = makeEngine({
    mode: "type",
    difficulty: "normal",
    words: WORDS,
    lessonId: "t",
    lessonTitle: "Test",
  });
  engine.start();

  let frames = 0;
  let typed = "";
  let done = false;
  while (frames < 3000 && !done) {
    step();
    frames++;
    const st = engine.getState();
    if (st.answer && st.answer !== typed) {
      typed = st.answer;
      for (const ch of typed.toLowerCase()) engine.pressChar(ch);
    }
    if (events.some((e) => e.type === "gameover")) done = true;
  }
  const over = events.find((e) => e.type === "gameover");
  const corrects = events.filter((e) => e.type === "correct");
  check("game finished", !!over, `frames=${frames}`);
  check("won the lesson", over?.result?.win === true);
  check("all words mastered", over?.result?.mastered === 4);
  check("score > 0", over?.result?.score > 0, `score=${over?.result?.score}`);
  check("4 correct answers", corrects.length === 4, `got ${corrects.length}`);
  check("level increased", corrects.some((e) => e.combo >= 3));
  engine.destroy();
}

/* ---------------------------------------------------------------- */
console.log("\n[2] tap mode — no input (should lose all hearts)");
{
  const { engine, events } = makeEngine({
    mode: "tap",
    difficulty: "normal",
    words: WORDS,
    lessonId: "t",
    lessonTitle: "Test",
  });
  engine.start();
  let frames = 0;
  let done = false;
  while (frames < 4000 && !done) {
    step();
    frames++;
    if (events.some((e) => e.type === "gameover")) done = true;
  }
  const over = events.find((e) => e.type === "gameover");
  const misses = events.filter((e) => e.type === "miss");
  check("game finished", !!over, `frames=${frames}`);
  check("lost (no hearts left)", over?.result?.win === false);
  check("hearts drained (3 misses)", misses.length === 3, `misses=${misses.length}`);
  engine.destroy();
}

/* ---------------------------------------------------------------- */
console.log("\n[3] pause / resume freezes the round timer");
{
  const { engine, events } = makeEngine({
    mode: "tap",
    difficulty: "normal",
    words: WORDS,
    lessonId: "t",
    lessonTitle: "Test",
  });
  engine.start();
  for (let i = 0; i < 200; i++) step();
  engine.pause();
  const before = engine.getState().round;
  const missesBefore = events.filter((e) => e.type === "miss").length;
  for (let i = 0; i < 300; i++) step();
  check("no round advanced while paused", engine.getState().round === before);
  check(
    "no misses while paused",
    events.filter((e) => e.type === "miss").length === missesBefore,
  );
  engine.resume();
  for (let i = 0; i < 200; i++) step();
  check("round resumed", engine.getState().round > before || events.length > 0);
  engine.destroy();
}

/* ---------------------------------------------------------------- */
console.log("\n[4] wrong tap costs points, keeps the round alive");
{
  const { engine, events } = makeEngine({
    mode: "tap",
    difficulty: "normal",
    words: WORDS,
    lessonId: "t",
    lessonTitle: "Test",
  });
  engine.start();
  for (let i = 0; i < 120; i++) step();
  const roundBefore = engine.getState().round;
  engine.tap(5, 5); // empty space
  check("empty-space tap is harmless", events.filter((e) => e.type === "wrong").length === 0);
  check("round still alive", engine.getState().round === roundBefore);
  engine.destroy();
}

/* ---------------------------------------------------------------- */
console.log("\n[5] tap mode — hitting the target tile scores & advances");
{
  const { engine, events } = makeEngine({
    mode: "tap",
    difficulty: "normal",
    words: WORDS,
    lessonId: "t",
    lessonTitle: "Test",
  });
  engine.start();
  for (let i = 0; i < 200; i++) step();
  const target = engine.tiles.find((t) => t.isTarget);
  check("target tile exists", !!target);
  const scoreBefore = engine.getState().score;
  const roundBefore = engine.getState().round;
  engine.tap(target.x + target.w / 2, target.y + target.h / 2);
  const correct = events.find((e) => e.type === "correct");
  check("correct event fired", !!correct);
  check("score increased", engine.getState().score > scoreBefore);
  check("combo started at 1", engine.getState().combo === 1);
  for (let i = 0; i < 120; i++) step();
  check("round advanced", engine.getState().round === roundBefore + 1);
  engine.destroy();
}

/* ---------------------------------------------------------------- */
console.log("\n[6] tap mode — wrong tile penalises but keeps the round");
{
  const { engine, events } = makeEngine({
    mode: "tap",
    difficulty: "normal",
    words: WORDS,
    lessonId: "t",
    lessonTitle: "Test",
  });
  engine.start();
  for (let i = 0; i < 200; i++) step();
  const wrongTile = engine.tiles.find((t) => !t.isTarget);
  check("distractor tile exists", !!wrongTile);
  const roundBefore = engine.getState().round;
  engine.tap(wrongTile.x + wrongTile.w / 2, wrongTile.y + wrongTile.h / 2);
  check("wrong event fired", events.some((e) => e.type === "wrong"));
  check("no correct event", !events.some((e) => e.type === "correct"));
  check("round still alive", engine.getState().round === roundBefore);
  engine.destroy();
}

/* ---------------------------------------------------------------- */
console.log("\n[7] hint reveals a letter in type mode");
{
  const { engine, events } = makeEngine({
    mode: "type",
    difficulty: "normal",
    words: WORDS,
    lessonId: "t",
    lessonTitle: "Test",
  });
  engine.start();
  // answer two words first so the player has some points to spend
  let typed = "";
  let corrects = 0;
  for (let i = 0; i < 800 && corrects < 2; i++) {
    step();
    const st = engine.getState();
    if (st.answer && st.answer !== typed) {
      typed = st.answer;
      for (const ch of typed.toLowerCase()) engine.pressChar(ch);
      corrects++;
    }
  }
  const scoreBefore = engine.getState().score;
  check("score accumulated", scoreBefore > 0, `score=${scoreBefore}`);
  const ok = engine.requestHint();
  check("hint accepted", ok === true);
  check("hint costs 20 points", engine.getState().score === scoreBefore - 20);
  const pattern = engine.getState().hintPattern;
  check("pattern shows one revealed letter", /^[a-zA-Z]•+$/.test(pattern), `pattern=${pattern}`);
  check("hint event fired", events.some((e) => e.type === "hint"));
  engine.destroy();
}

console.log(failures === 0 ? "\nALL CHECKS PASSED ✅\n" : `\n${failures} CHECK(S) FAILED ❌\n`);
process.exit(failures === 0 ? 0 : 1);
