// End-to-end API smoke test against a running wrangler dev server.
// Exercises auth, profile, dashboard, resources/RAG, tests, attempts,
// evaluation, planner, revision and analytics with real HTTP calls.
const BASE = process.env.BASE_URL || 'http://127.0.0.1:8787';
let cookie = '';
let failures = 0;

function log(step, ok, detail = '') {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${step}${detail ? `  — ${detail}` : ''}`);
  if (!ok) failures++;
}

async function call(path, { method = 'GET', body, raw } = {}) {
  const headers = { accept: 'application/json' };
  if (cookie) headers.cookie = cookie;
  if (body !== undefined) headers['content-type'] = 'application/json';
  const res = await fetch(BASE + path, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  const setCookie = res.headers.getSetCookie?.() ?? [];
  const legacy = res.headers.get('set-cookie');
  if (!setCookie.length && legacy) setCookie.push(legacy);
  for (const c of setCookie) {
    if (c.startsWith('em_session=')) cookie = c.split(';')[0];
  }
  const text = await res.text();
  let data;
  try { data = JSON.parse(text); } catch { data = text; }
  return { status: res.status, data, headers: res.headers, raw: text };
}

const email = `student${Date.now()}@example.com`;
const password = 'testpass123';

console.log(`\nEduMentor smoke test → ${BASE}\n`);

// 1. health + seed bank
const health = await call('/api/health');
log('health endpoint', health.status === 200 && health.data.ok === true, `seeds=${health.data.seedQuestions} storage=${health.data.storage} ai=${health.data.ai}`);

// 2. register
const reg = await call('/api/auth/register', { method: 'POST', body: { name: 'Smoke Student', email, password } });
log('register', reg.status === 200 && reg.data.user?.email === email, `status=${reg.status}`);
log('session cookie issued', cookie.length > 20);

// 3. validation rejects weak password
const weak = await call('/api/auth/register', { method: 'POST', body: { name: 'Weak Password', email: `w${Date.now()}@example.com`, password: '123' } });
log('password validation', weak.status === 400 && weak.data?.code === 'weak_password', weak.data?.error);

// 4. onboarding profile
const profile = await call('/api/profile', {
  method: 'PUT',
  body: {
    name: 'Smoke Student', exam: 'cbse10', classLevel: '10', board: 'CBSE',
    examDate: new Date(Date.now() + 60 * 86400000).toISOString().slice(0, 10),
    targetScore: '90%', subjects: ['Mathematics', 'Science'],
    weakSubjects: ['Mathematics'], strongSubjects: ['Science'],
    dailyHours: 3, schoolStart: '07:30', schoolEnd: '14:00', sleepAt: '23:00', wakeAt: '06:30',
    preferredStart: '17:00', preferredEnd: '21:00', learningStyle: 'Step-by-step explanations with worked examples',
    currentPerformance: 'Around 70% in school tests',
  },
});
log('profile creation', profile.status === 200 && profile.data.profile?.onboarded === true, `subjects=${profile.data.profile?.subjects?.length}`);

// 5. sleep validation
const badSleep = await call('/api/profile', {
  method: 'PUT',
  body: { name: 'Smoke Student', exam: 'cbse10', classLevel: '10', examDate: '2026-03-01', targetScore: '90%', subjects: ['Mathematics'], dailyHours: 3, sleepAt: '02:00', wakeAt: '06:00' },
});
log('sleep guard rejects <6h', badSleep.status === 400 && badSleep.data.code === 'insufficient_sleep');

// 6. syllabus tracker seeded
const progress = await call('/api/progress');
log('chapter tracker seeded', progress.status === 200 && (progress.data.progress?.length ?? 0) > 20, `chapters=${progress.data.progress?.length}`);
if (!progress.data.progress?.length) {
  console.log('\nStopping: profile/tracker setup failed, later checks would cascade.\n');
  process.exit(1);
}

// 7. mark a chapter learning
const chapter = progress.data.progress.find((p) => p.subject === 'Mathematics');
const mark = await call('/api/progress', { method: 'PATCH', body: { subject: chapter.subject, chapter: chapter.chapter, status: 'learning' } });
log('chapter status update', mark.status === 200 && mark.data.progress?.status === 'learning');

// 8. dashboard
const dash = await call('/api/dashboard');
log('dashboard computed', dash.status === 200 && dash.data.stats?.chaptersTotal > 0, `prep=${dash.data.stats?.preparation}% study7d=${dash.data.stats?.studyMinutes7d}m`);

// 9. resource ingestion + retrieval
const pages = [
  { page: 1, text: 'Chapter 1 Real Numbers. The Fundamental Theorem of Arithmetic states that every composite number can be expressed as a product of primes, and this factorisation is unique apart from the order of the factors. Euclid\u2019s division lemma: for positive integers a and b there exist unique integers q and r such that a = bq + r, where 0 <= r < b. HCF is the largest number dividing both numbers.' },
  { page: 2, text: 'The least common multiple of two positive integers is the smallest number divisible by both. For any two numbers, HCF multiplied by LCM equals the product of the numbers. Irrational numbers such as the square root of 2 cannot be written as a fraction of integers. Example: prove that root 3 is irrational by contradiction.' },
  { page: 3, text: 'Decimal expansion: a rational number has a terminating decimal expansion if and only if its denominator is of the form 2^n 5^m. Otherwise the expansion is non-terminating and repeating. Practice questions on HCF and LCM appear in board papers for two marks.' },
];
const resource = await call('/api/resources', { method: 'POST', body: { name: 'Smoke — Real Numbers notes', kind: 'notes', subject: 'Mathematics', sizeBytes: 1200, pageCount: 3, pages } });
log('resource indexed', resource.status === 201 && resource.data.resource?.chunkCount >= 2, `chunks=${resource.data.resource?.chunkCount}`);

const search = await call('/api/resources/search?q=' + encodeURIComponent('fundamental theorem of arithmetic prime factorisation'));
log('retrieval returns cited page', search.status === 200 && search.data.chunks?.length > 0 && search.data.chunks[0].page >= 1, `top page=${search.data.chunks?.[0]?.page} resource=${search.data.chunks?.[0]?.resourceName}`);

const emptyResource = await call('/api/resources', { method: 'POST', body: { name: 'Scanned', kind: 'other', pages: [{ page: 1, text: '   ' }] } });
log('empty/scanned PDF rejected clearly', emptyResource.status === 400 && emptyResource.data.code === 'no_text_extracted');

// 10. generate a bank test
const testRes = await call('/api/tests', { method: 'POST', body: { exam: 'cbse10', subjects: ['Mathematics'], difficulty: 'easy', questionCount: 6, durationMinutes: 20, mode: 'bank' } });
const test = testRes.data?.test;
log('test generated from bank', testRes.status === 201 && test?.questionCount >= 4, `questions=${test?.questionCount} marks=${test?.totalMarks} note=${testRes.data?.note || 'none'}`);
log('answers hidden before submission', Array.isArray(testRes.data?.questions) && testRes.data.questions.every((q) => q.correct?.length === 0 && !q.solution));

// 11. start attempt and answer
const attemptRes = await call(`/api/tests/${test.id}/attempts`, { method: 'POST' });
const attempt = attemptRes.data?.attempt;
log('attempt started', attemptRes.status === 201 && attempt?.id > 0);

const answers = {};
for (const [i, q] of testRes.data.questions.entries()) {
  answers[q.id] = { questionId: q.id, response: i % 2 === 0 ? ['A'] : [], numeric: null, timeSpentSeconds: 15, marked: false, visited: true };
}
const saveRes = await call(`/api/attempts/${attempt.id}`, { method: 'PATCH', body: { answers, timeSpentSeconds: 300 } });
log('autosave answers', saveRes.status === 200 && saveRes.data.ok === true);

// 12. submit + evaluation
const submitRes = await call(`/api/attempts/${attempt.id}/submit`, { method: 'POST', body: { answers, timeSpentSeconds: 480 } });
const report = submitRes.data?.report;
log('attempt evaluated', submitRes.status === 200 && report?.evaluated?.length === test.questionCount, `score=${submitRes.data?.attempt?.score}/${submitRes.data?.attempt?.maxScore} accuracy=${submitRes.data?.attempt?.accuracy}%`);
log('report has subject + chapter breakdown', Array.isArray(report?.subjects) && report.subjects.length > 0 && Array.isArray(report?.chapters));
log('improvement plan generated', Array.isArray(report?.improvementPlan) && report.improvementPlan.length > 0, report?.improvementPlan?.[0]?.title);
log('submitted attempt marked', submitRes.data?.attempt?.status === 'submitted' && Boolean(submitRes.data?.attempt?.submittedAt));

// 13. answer key hidden in test list but available in report
const testDetail = await call(`/api/tests/${test.id}`);
log('test marked submitted', testDetail.data?.test?.status === 'submitted' && Boolean(testDetail.data?.submittedAttemptId));

// 14. planner
const planRes = await call('/api/planner/generate', { method: 'POST', body: { days: 7, focusSubjects: ['Mathematics'] } });
const items = planRes.data?.items ?? [];
const studyItems = items.filter((i) => !['break', 'school', 'coaching'].includes(i.kind));
log('planner generated sessions', planRes.status === 200 && studyItems.length > 10, `sessions=${studyItems.length} total=${items.length}`);
const withinWindow = studyItems.every((i) => i.startTime >= '06:30' && i.endTime <= '23:00');
log('sessions respect sleep window', withinWindow);
const firstItem = studyItems[0];
const doneRes = await call(`/api/planner/items/${firstItem.id}`, { method: 'PATCH', body: { status: 'done' } });
log('session completion logs study time', doneRes.status === 200 && doneRes.data.item?.status === 'done');

const reschedule = await call('/api/planner/reschedule', { method: 'POST', body: {} });
log('missed-session reschedule responds', reschedule.status === 200, `moved=${reschedule.data.moved}`);

const goalRes = await call('/api/planner/goals', { method: 'POST', body: { minutes: 45, title: 'Revise Real Numbers' } });
log('daily goal created', goalRes.status === 201 && goalRes.data.goal?.minutes === 45);

// 15. revision from mistakes
const revision = await call('/api/revision');
log('revision queue built', revision.status === 200 && typeof revision.data.totalCards === 'number', `due=${revision.data.dueCount} cards=${revision.data.totalCards} chapters=${revision.data.dueChapters?.length}`);
if (revision.data.cards?.length) {
  const card = revision.data.cards[0];
  const reviewed = await call(`/api/revision/cards/${card.id}/review`, { method: 'POST', body: { grade: 2 } });
  log('flashcard review schedules next due', reviewed.status === 200 && Boolean(reviewed.data.due), `due=${reviewed.data.due} interval=${reviewed.data.intervalDays}d`);
}

const quiz = await call('/api/revision/quiz', { method: 'POST', body: { subject: 'Mathematics', count: 5 } });
log('quick quiz returns questions with solutions', quiz.status === 200 && (quiz.data.questions?.length ?? 0) > 0, `questions=${quiz.data.questions?.length}`);

// 16. question bank + bookmark
const bank = await call('/api/bank?subject=Mathematics&limit=5');
log('question bank filters', bank.status === 200 && bank.data.questions?.length > 0, `total=${bank.data.total}`);
const q = bank.data.questions[0];
const bm = await call(`/api/bank/${q.id}/bookmark`, { method: 'POST' });
log('bookmark toggles', bm.status === 200 && bm.data.bookmarked === true);
const answerRes = await call(`/api/bank/${q.id}/attempt`, { method: 'POST', body: { response: ['A'], numeric: null } });
log('bank answer graded with solution', answerRes.status === 200 && typeof answerRes.data.correct === 'boolean' && answerRes.data.solution.length > 0);

const coll = await call('/api/collections', { method: 'POST', body: { name: 'Smoke — weak chapters' } });
log('collection created', coll.status === 201 && coll.data.collection?.id > 0);
const addItem = await call(`/api/collections/${coll.data.collection.id}/items`, { method: 'POST', body: { questionId: q.id } });
log('question saved to collection', addItem.status === 200 && addItem.data.ok === true);
const collItems = await call(`/api/collections/${coll.data.collection.id}`);
log('collection returns its questions', collItems.status === 200 && collItems.data.questions?.length === 1);
const collList = await call('/api/collections');
log('collection counts update', collList.data.collections?.find((c) => c.id === coll.data.collection.id)?.count === 1);

// 17. analytics
const analytics = await call('/api/analytics');
log('analytics aggregates attempts', analytics.status === 200 && analytics.data.summary?.attempts === 1, `accuracy=${analytics.data.summary?.accuracy}% subjects=${analytics.data.subjects?.length} mistakes=${analytics.data.mistakes?.length}`);
log('study minutes recorded', (analytics.data.summary?.studyMinutes ?? 0) > 0, `${analytics.data.summary?.studyMinutes} min`);

// 18. AI endpoints degrade honestly without a key
const teacher = await call('/api/teacher/chats', { method: 'POST', body: { mode: 'beginner', subject: 'Mathematics', chapter: 'Real Numbers' } });
log('teacher chat creation', teacher.status === 200);
const aiMsg = await call(`/api/teacher/chats/${teacher.data.chat.id}/messages`, { method: 'POST', body: { content: 'Explain Euclid division lemma' } });
log('AI missing key → clear setup error', aiMsg.status === 503 && aiMsg.data.setupRequired === true, aiMsg.data?.error?.slice(0, 70));
const aiTest = await call('/api/tests', { method: 'POST', body: { exam: 'cbse10', subjects: ['Mathematics'], mode: 'ai', questionCount: 3 } });
log('AI test without key blocked', aiTest.status === 503 && aiTest.data.setupRequired === true);
const doubt = await call('/api/doubts', { method: 'POST', body: { question: 'Why is root 2 irrational?' } });
log('doubt solver without key blocked', doubt.status === 503 && doubt.data.setupRequired === true);

// 19. isolation: second account cannot read first account's data
const savedCookie = cookie;
cookie = '';
const otherEmail = `other${Date.now()}@example.com`;
await call('/api/auth/register', { method: 'POST', body: { name: 'Other Student', email: otherEmail, password } });
const otherTests = await call('/api/tests');
log('per-user isolation of tests', otherTests.status === 200 && otherTests.data.tests.length === 0);
const otherDash = await call('/api/dashboard');
log('second user has no profile data', otherDash.data.profile === null);
const foreignAttempt = await call(`/api/attempts/${attempt.id}`);
log('foreign attempt access denied', foreignAttempt.status === 404);
cookie = savedCookie;

// 20. unauthenticated access
const anonCookie = cookie;
cookie = '';
const anon = await call('/api/dashboard');
log('unauthenticated API rejected', anon.status === 401);
cookie = anonCookie;

// 21. login flow + wrong password
const login = await call('/api/auth/login', { method: 'POST', body: { email, password } });
log('login works', login.status === 200 && login.data.user?.email === email);
cookie = '';
const badLogin = await call('/api/auth/login', { method: 'POST', body: { email, password: 'wrongpassword' } });
log('wrong password rejected', badLogin.status === 401);

// 22. guest sign-in: real, isolated account with no credentials
const mainCookie = cookie;
cookie = '';
const guest = await call('/api/auth/guest', { method: 'POST' });
log('guest sign-in works without credentials', guest.status === 200 && guest.data.user?.name === 'Guest', `status=${guest.status}`);
log('guest session cookie issued', cookie.startsWith('em_session='));
const guestMe = await call('/api/auth/me');
log('guest session resolves', guestMe.status === 200 && guestMe.data.user?.name === 'Guest');
const guestTests = await call('/api/tests');
log('guest data is isolated', guestTests.status === 200 && (guestTests.data.tests?.length ?? 0) === 0);
cookie = mainCookie;

console.log(`\n${failures === 0 ? 'ALL CHECKS PASSED' : `${failures} CHECK(S) FAILED`}\n`);
process.exit(failures === 0 ? 0 : 1);
