import { CrosswordDesigner, DesignerQuestionInput } from '../src/engine/CrosswordDesigner';
import { validateCrosswordLayout } from '../src/engine/CrosswordValidator';

const questions: DesignerQuestionInput[] = [
  { id: 'q_01', clue: 'ما اسم المدينة التي كانت عاصمة الدولة العباسية؟', answer: 'بغداد' },
  { id: 'q_02', clue: 'ما أطول نهر في قارة أوروبا؟', answer: 'الفولغا' },
  { id: 'q_03', clue: 'ما العنصر الكيميائي الذي رمزه O؟', answer: 'الاكسجين' },
  { id: 'q_04', clue: 'ما العضو المسؤول بشكل رئيسي عن ضخ الدم إلى أنحاء الجسم؟', answer: 'القلب' },
  { id: 'q_05', clue: 'ما الكوكب المعروف بالكوكب الأحمر؟', answer: 'المريخ' },
  { id: 'q_06', clue: 'من الشاعر الملقب بشاعر النيل؟', answer: 'حافظابراهيم' },
  { id: 'q_07', clue: 'ما علامة رفع المثنى؟', answer: 'الالف' },
  { id: 'q_08', clue: 'ما اسم أقدم ملحمة أدبية معروفة في التاريخ؟', answer: 'ملحمةجلجامش' },
  { id: 'q_09', clue: 'ما السورة التي تُسمى أم الكتاب؟', answer: 'الفاتحة' },
  { id: 'q_10', clue: 'من العالم الذي ارتبط اختراعه بالمصباح الكهربائي المتوهج تجاريًا؟', answer: 'توماساديسون' },
  { id: 'q_11', clue: 'ما اسم الآلة الموسيقية الوترية العربية التي تشتهر برقبتها الطويلة؟', answer: 'العود' },
  { id: 'q_12', clue: 'كم عدد اللاعبين الأساسيين في فريق كرة القدم داخل الملعب؟', answer: 'احدعشر' },
  { id: 'q_13', clue: 'ما أكبر حيوان معروف على سطح الأرض؟', answer: 'الحوتالازرق' },
  { id: 'q_14', clue: 'ما عاصمة اليابان؟', answer: 'طوكيو' },
  { id: 'q_15', clue: 'من العالم المسلم الذي اشتهر بكتابه "القانون في الطب"؟', answer: 'ابنسينا' },
  { id: 'q_16', clue: 'ما المدينة التي تُعرف بلقب مدينة الألف مئذنة؟', answer: 'القاهرة' },
  { id: 'q_17', clue: 'ما المصطلح الذي يطلق على الارتفاع العام والمستمر في أسعار السلع والخدمات؟', answer: 'التضخم' },
  { id: 'q_18', clue: 'ما الاسم الذي يطلق على النص المكتوب الذي يصف أحداث الفيلم ومشاهده وحواراته؟', answer: 'السيناريو' },
  { id: 'q_19', clue: 'ما اسم التجربة الفكرية التي استخدمها أفلاطون لشرح انتقال الإنسان من عالم الظلال إلى معرفة الحقيقة؟', answer: 'كهفافلاطون' },
  { id: 'q_20', clue: 'كم عدد أيام السنة الميلادية العادية؟', answer: 'ثلاثمئةوخمسة' },
  { id: 'q_21', clue: 'ما الغاز الذي تحتاجه معظم الكائنات الحية للتنفس؟', answer: 'الاوكسجين' },
  { id: 'q_22', clue: 'ما اسم المعاهدة التي أنهت حرب الثلاثين عامًا في أوروبا عام 1648؟', answer: 'صلحوستفاليا' },
  { id: 'q_23', clue: 'ما اسم الكتابة التي استخدمها السومريون في بلاد الرافدين؟', answer: 'المسمارية' },
  { id: 'q_24', clue: 'ما الجهاز الذي يحوّل الطاقة الكهربائية إلى ضوء؟', answer: 'المصباح' },
  { id: 'q_25', clue: 'ما العدد الذي يمثل مجموع المحيطات الكبرى على سطح الأرض وفق التصنيف الجغرافي الشائع؟', answer: 'خمسة' }
];

const designer = new CrosswordDesigner();
console.log('Generating layout...');
const result = designer.generateLayout(questions, 5000, 15, 15);
console.log('Placed words count:', result.layout.words.length);
console.log('Validation isValid:', result.validation.isValid);
console.log('Validation errors:', result.validation.errors);
console.log('Validation warnings:', result.validation.warnings);
