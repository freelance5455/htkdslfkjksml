from pathlib import Path
import xml.etree.ElementTree as ET

manifest = Path("android/app/src/main/AndroidManifest.xml")
if not manifest.exists():
    raise SystemExit("AndroidManifest.xml not found; run npx cap add android first.")
ET.register_namespace("android", "http://schemas.android.com/apk/res/android")
A = "{http://schemas.android.com/apk/res/android}"
tree = ET.parse(manifest)
root = tree.getroot()
app = root.find("application")
if app is None:
    raise SystemExit("Manifest has no application element.")
app.set(A+"allowBackup", "false")
app.set(A+"usesCleartextTraffic", "false")
app.set(A+"networkSecurityConfig", "@xml/network_security_config")
# Do not request broad permissions; this app has no need for contacts, SMS, location, camera or microphone.
for node in list(root.findall("uses-permission")):
    name = node.get(A+"name", "")
    if name in {
        "android.permission.READ_CONTACTS", "android.permission.WRITE_CONTACTS",
        "android.permission.SEND_SMS", "android.permission.RECEIVE_SMS",
        "android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION",
        "android.permission.CAMERA", "android.permission.RECORD_AUDIO"
    }:
        root.remove(node)
tree.write(manifest, encoding="utf-8", xml_declaration=True)

res = Path("android/app/src/main/res/xml")
res.mkdir(parents=True, exist_ok=True)
(res/"network_security_config.xml").write_text("""<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
  <base-config cleartextTrafficPermitted="false">
    <trust-anchors><certificates src="system" /></trust-anchors>
  </base-config>
</network-security-config>
""", encoding="utf-8")
print("Android manifest hardened: backups disabled; cleartext HTTP blocked; no unnecessary sensitive permissions.")
