import fs from 'fs';
import { STAGE_02_QUESTIONS } from '../src/data/stage02Questions';
import { normalizeArabicString } from '../src/engine/normalization';
import { validateCrosswordLayout } from '../src/engine/CrosswordValidator';
import {
  CrosswordLayout,
  CrosswordLayoutWord,
  CrosswordLayoutCell,
  LayoutCellCoordinate,
  CrosswordLayoutClue
} from '../src/types/crosswordLayout';

function cleanWord(str: string): string {
  return normalizeArabicString(str.replace(/\s+/g, ''));
}

const words = STAGE_02_QUESTIONS.map((q) => {
  const norm = cleanWord(q.answer);
  return {
    id: q.id,
    clue: q.clue,
    answer: q.answer,
    norm: norm,
    len: norm.length
  };
});

console.log('Total words:', words.length);
words.forEach((w) => {
  console.log(`${w.id}: ${w.answer} => "${w.norm}" (${w.len} letters)`);
});

type Dir = 'across' | 'down';

interface Placement {
  word: typeof words[0];
  dir: Dir;
  r: number;
  c: number;
  reversed: boolean;
}

function solveGrid(GRID_SIZE: number, maxIterations: number): Placement[] | null {
  const sortedWords = [...words].sort((a, b) => b.len - a.len);

  for (let iter = 0; iter < maxIterations; iter++) {
    if (iter > 0 && iter % 5000 === 0) {
      console.log(`Iteration ${iter}...`);
    }

    const grid: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
    const cellAcross: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
    const cellDown: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));

    function canFit(
      wStr: string,
      dir: Dir,
      r: number,
      c: number,
      placedCount: number
    ): { valid: boolean; inters: number } {
      const len = wStr.length;
      if (dir === 'across') {
        if (c + len > GRID_SIZE || r < 0 || r >= GRID_SIZE || c < 0) return { valid: false, inters: 0 };
        if (c > 0 && grid[r][c - 1] !== null) return { valid: false, inters: 0 };
        if (c + len < GRID_SIZE && grid[r][c + len] !== null) return { valid: false, inters: 0 };

        let touches = placedCount === 0;
        let inters = 0;

        for (let k = 0; k < len; k++) {
          const cur = grid[r][c + k];
          if (cur !== null) {
            if (cur !== wStr[k]) return { valid: false, inters: 0 };
            if (cellAcross[r][c + k] !== null) return { valid: false, inters: 0 };
            touches = true;
            inters++;
          } else {
            // Parallel separation: cell above and cell below cannot have letters unless it is a crossing Down word
            if (r > 0 && grid[r - 1][c + k] !== null && cellDown[r - 1][c + k] === null) return { valid: false, inters: 0 };
            if (r < GRID_SIZE - 1 && grid[r + 1][c + k] !== null && cellDown[r + 1][c + k] === null) return { valid: false, inters: 0 };
          }
        }
        return { valid: touches, inters };
      } else {
        if (r + len > GRID_SIZE || c < 0 || c >= GRID_SIZE || r < 0) return { valid: false, inters: 0 };
        if (r > 0 && grid[r - 1][c] !== null) return { valid: false, inters: 0 };
        if (r + len < GRID_SIZE && grid[r + len][c] !== null) return { valid: false, inters: 0 };

        let touches = placedCount === 0;
        let inters = 0;

        for (let k = 0; k < len; k++) {
          const cur = grid[r + k][c];
          if (cur !== null) {
            if (cur !== wStr[k]) return { valid: false, inters: 0 };
            if (cellDown[r + k][c] !== null) return { valid: false, inters: 0 };
            touches = true;
            inters++;
          } else {
            // Parallel separation: cell left and cell right cannot have letters unless it is a crossing Across word
            if (c > 0 && grid[r + k][c - 1] !== null && cellAcross[r + k][c - 1] === null) return { valid: false, inters: 0 };
            if (c < GRID_SIZE - 1 && grid[r + k][c + 1] !== null && cellAcross[r + k][c + 1] === null) return { valid: false, inters: 0 };
          }
        }
        return { valid: touches, inters };
      }
    }

    const placed: Placement[] = [];

    // Root word is one of the top 3 longest words (منارة الإسكندرية len 15, النماذج الأصلية len 14, الريشة الطائرة len 13)
    const rootOptions = sortedWords.slice(0, 3);
    const root = rootOptions[Math.floor(Math.random() * rootOptions.length)];
    const rootDir: Dir = Math.random() > 0.5 ? 'across' : 'down';
    const rootRev = false;
    const rootStr = root.norm;

    const rootR = rootDir === 'across' ? Math.floor(Math.random() * (GRID_SIZE - 6)) + 2 : (root.len === GRID_SIZE ? 0 : Math.floor(Math.random() * (GRID_SIZE - root.len)));
    const rootC = rootDir === 'down' ? Math.floor(Math.random() * (GRID_SIZE - 6)) + 2 : (root.len === GRID_SIZE ? 0 : Math.floor(Math.random() * (GRID_SIZE - root.len)));

    for (let k = 0; k < root.len; k++) {
      const cr = rootDir === 'down' ? rootR + k : rootR;
      const cc = rootDir === 'across' ? rootC + k : rootC;
      grid[cr][cc] = rootStr[k];
      if (rootDir === 'across') cellAcross[cr][cc] = root.id;
      else cellDown[cr][cc] = root.id;
    }
    placed.push({ word: root, dir: rootDir, r: rootR, c: rootC, reversed: rootRev });

    let unplaced = sortedWords.filter((w) => w.id !== root.id);

    let failed = false;
    while (unplaced.length > 0) {
      type Cand = {
        word: typeof words[0];
        dir: Dir;
        r: number;
        c: number;
        reversed: boolean;
        inters: number;
        score: number;
      };

      const candidates: Cand[] = [];

      for (const w of unplaced) {
        for (const d of ['across', 'down'] as Dir[]) {
          for (const rev of [false, true]) {
            const wStr = rev ? w.norm.split('').reverse().join('') : w.norm;
            for (let r = 0; r < GRID_SIZE; r++) {
              for (let c = 0; c < GRID_SIZE; c++) {
                const res = canFit(wStr, d, r, c, placed.length);
                if (res.valid && res.inters >= 1) {
                  const midR = d === 'down' ? r + w.len / 2 : r;
                  const midC = d === 'across' ? c + w.len / 2 : c;
                  const distCenter = Math.abs(midR - GRID_SIZE / 2) + Math.abs(midC - GRID_SIZE / 2);
                  const revPenalty = rev ? 1.5 : 0;
                  const score = res.inters * 30 + w.len * 2 - distCenter * 1.0 - revPenalty + Math.random() * 5;
                  candidates.push({
                    word: w,
                    dir: d,
                    r,
                    c,
                    reversed: rev,
                    inters: res.inters,
                    score
                  });
                }
              }
            }
          }
        }
      }

      if (candidates.length === 0) {
        failed = true;
        break;
      }

      candidates.sort((a, b) => b.score - a.score);
      const pickPoolSize = Math.min(3, candidates.length);
      const pick = candidates[Math.floor(Math.random() * pickPoolSize)];

      const pickStr = pick.reversed ? pick.word.norm.split('').reverse().join('') : pick.word.norm;
      for (let k = 0; k < pick.word.len; k++) {
        const cr = pick.dir === 'down' ? pick.r + k : pick.r;
        const cc = pick.dir === 'across' ? pick.c + k : pick.c;
        grid[cr][cc] = pickStr[k];
        if (pick.dir === 'across') cellAcross[cr][cc] = pick.word.id;
        else cellDown[cr][cc] = pick.word.id;
      }

      placed.push({
        word: pick.word,
        dir: pick.dir,
        r: pick.r,
        c: pick.c,
        reversed: pick.reversed
      });

      unplaced = unplaced.filter((w) => w.id !== pick.word.id);
    }

    if (!failed && placed.length === words.length) {
      console.log(`🎉 Found complete solution on iteration ${iter}!`);
      return placed;
    }
  }

  return null;
}

let solved = solveGrid(15, 60000);
let finalSize = 15;
if (!solved) {
  console.log('Trying 16x16 grid...');
  solved = solveGrid(16, 100000);
  finalSize = 16;
}

if (!solved) {
  console.error('Failed to solve stage 2 layout');
  process.exit(1);
}

// Build Layout Object and Validate
const GRID_SIZE = finalSize;
const gridLetters: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
const acrossMap: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
const downMap: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));

for (const p of solved) {
  const wStr = p.reversed ? p.word.norm.split('').reverse().join('') : p.word.norm;
  for (let k = 0; k < p.word.len; k++) {
    const r = p.dir === 'down' ? p.r + k : p.r;
    const c = p.dir === 'across' ? p.c + k : p.c;
    gridLetters[r][c] = wStr[k];
    if (p.dir === 'across') acrossMap[r][c] = p.word.id;
    else downMap[r][c] = p.word.id;
  }
}

// Clue Numbers
let clueNum = 1;
const wordNumberMap = new Map<string, number>();
const cellNumberMap = new Map<string, number>();

for (let r = 0; r < GRID_SIZE; r++) {
  for (let c = 0; c < GRID_SIZE; c++) {
    if (gridLetters[r][c] === null) continue;

    let hasStart = false;
    const startAcross = solved.find((p) => p.dir === 'across' && p.r === r && p.c === c);
    const startDown = solved.find((p) => p.dir === 'down' && p.r === r && p.c === c);

    if (startAcross) {
      wordNumberMap.set(startAcross.word.id, clueNum);
      hasStart = true;
    }
    if (startDown) {
      wordNumberMap.set(startDown.word.id, clueNum);
      hasStart = true;
    }

    if (hasStart) {
      cellNumberMap.set(`${r}_${c}`, clueNum);
      clueNum++;
    }
  }
}

const cells: CrosswordLayoutCell[] = [];
const blackCells: LayoutCellCoordinate[] = [];

for (let r = 0; r < GRID_SIZE; r++) {
  for (let c = 0; c < GRID_SIZE; c++) {
    const letter = gridLetters[r][c];
    if (letter === null) {
      cells.push({
        row: r,
        column: c,
        isBlocked: true,
        letter: ''
      });
      blackCells.push({ row: r, col: c });
    } else {
      const num = cellNumberMap.get(`${r}_${c}`);
      cells.push({
        row: r,
        column: c,
        isBlocked: false,
        letter,
        number: num,
        acrossWordId: acrossMap[r][c] || undefined,
        downWordId: downMap[r][c] || undefined
      });
    }
  }
}

const layoutWords: CrosswordLayoutWord[] = solved.map((p) => {
  const number = wordNumberMap.get(p.word.id) || 1;
  const wordCells: LayoutCellCoordinate[] = [];
  for (let k = 0; k < p.word.len; k++) {
    const r = p.dir === 'down' ? p.r + k : p.r;
    const c = p.dir === 'across' ? p.c + k : p.c;
    wordCells.push({ row: r, col: c });
  }

  return {
    id: p.word.id,
    clue: p.word.clue,
    answer: p.word.answer,
    normalizedAnswer: p.word.norm,
    direction: p.dir,
    startRow: p.r,
    startColumn: p.c,
    length: p.word.len,
    cells: wordCells,
    number,
    reversed: p.reversed
  };
});

layoutWords.sort((a, b) => {
  if (a.number !== b.number) return a.number - b.number;
  return a.direction === 'across' ? -1 : 1;
});

const clues: CrosswordLayoutClue[] = layoutWords.map((w) => ({
  number: w.number,
  clue: w.clue,
  direction: w.direction,
  length: w.length,
  wordId: w.id,
  reversed: w.reversed
}));

const layout: CrosswordLayout = {
  gridRows: GRID_SIZE,
  gridColumns: GRID_SIZE,
  cells,
  words: layoutWords,
  clues,
  blackCells
};

const validation = validateCrosswordLayout(layout);
console.log('\n--- Validation Result for Stage 2 ---');
console.log('isValid:', validation.isValid);
validation.items.forEach((item) => {
  console.log(`${item.passed ? '✓' : '✗'} ${item.label}: ${item.message}`);
});

if (validation.isValid) {
  fs.writeFileSync('src/data/golden_stage_02.json', JSON.stringify(layout, null, 2), 'utf-8');
  console.log('\n✨ Successfully generated and verified src/data/golden_stage_02.json!');
} else {
  console.error('Validation failed!');
  process.exit(1);
}
