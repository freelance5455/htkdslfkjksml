import puppeteer from "puppeteer-core";
import { createServer } from "http";
import { readFileSync, existsSync } from "fs";
import { extname, join } from "path";

const MIME = { ".html": "text/html", ".js": "text/javascript", ".css": "text/css" };
const server = createServer((req, res) => {
  let p = req.url.split("?")[0]; if (p === "/") p = "/index.html";
  const f = join(process.cwd() + "/dist", p);
  if (!existsSync(f)) { res.writeHead(404); res.end(); return; }
  res.writeHead(200, { "Content-Type": MIME[extname(f)] || "text/plain" }); res.end(readFileSync(f));
});
await new Promise((r) => server.listen(4177, r));
const browser = await puppeteer.launch({ executablePath: "/usr/bin/chromium", headless: "new",
  args: ["--no-sandbox","--use-gl=swiftshader","--enable-unsafe-swiftshader","--disable-dev-shm-usage"] });
const page = await browser.newPage();
await page.setViewport({ width: 1280, height: 720 });
const errs = []; page.on("pageerror", (e) => errs.push(e.message));
let fails = 0;
const check = (n, c, x="") => { console.log((c?"  ok  | ":"  FAIL| ")+n+(x?" ("+x+")":"")); if(!c) fails++; };
const wait = (ms)=>new Promise(r=>setTimeout(r,ms));
const body = () => page.evaluate(()=>document.body.innerText);
const clickText = async (txt) => page.evaluate((t)=>{const b=[...document.querySelectorAll("button")].find(x=>x.innerText.trim().includes(t)); if(b){b.click();return true;} return false;},txt);
const hold = async (k,ms)=>{await page.keyboard.down(k); await wait(ms); await page.keyboard.up(k);};

await page.goto("http://localhost:4177/", { waitUntil: "load" });
await wait(600);
// injeta o saveadvancedo
const state = readFileSync("/tmp/state32.json", "utf8");
await page.evaluate((s) => { localStorage.setItem("caminho_do_poder_save_v1", s); }, state);
await page.reload({ waitUntil: "load" });
await wait(700);
await clickText("Continuar");
await wait(1100);
let t = await body();
check("carrega save avancado (32 missoes)", /LEI 33 \/ 48/i.test(t), (t.match(/LEI \d+ \/ 48/)||[])[0]);
check("pontos restaurados", /2627 pts/.test(t));
check("area Camara do Conselho", /C[ÂA]MARA DO CONSELHO/i.test(t));


// caminha ate o Escribao Aurelio (13,14) - jogador em (13,12)
await hold("KeyS", 500);
await wait(300);
t = await body();
check("prompt do Escribao", /Conversar com Escribão/i.test(t));
await page.keyboard.press("KeyE"); await wait(500); await page.keyboard.press("Space"); await wait(400);
t = await body();
check("missao 33 inicia", /Polegar de Cada Um/i.test(t));
check("primeiro no de dialogo", /Di[ÂA]rio Riscado/i.test(t) || /três/i.test(t));
// escolhe a primeira opcao
await page.evaluate(()=>{const b=[...document.querySelectorAll("button")].find(x=>/^1\./.test(x.innerText.trim())); b?.click();});
await wait(900);
await page.keyboard.press("Space"); await wait(300);
await clickText("Continuar"); await wait(900);
t = await body();
check("passo de coleta do diarioauto-advance (ja tinha no inventario)", /Anel de Selo/i.test(t), (t.match(/Encontre[^:]*:.*/i)||[])[0]);
check("objetivo agora e o anel no Solar", /Solar de Valdessa/i.test(t));
await page.screenshot({ path: "scripts/shot-missao33.png" });

// vai ate o solar pelo mapa e pega o anel
await page.keyboard.press("KeyM"); await wait(500);
const travelOk = await page.evaluate(()=>{const b=[...document.querySelectorAll("button")].find(x=>/solar de valdessa/i.test(x.innerText)); if(b&&!b.disabled){b.click();return true;} return false;});
await wait(900);
t = await body();
check("viaja para o Solar pelo mapa", travelOk && /SOLAR DE VALDESSA/i.test(t), "travelOk="+travelOk);
// caminha ate o anel (24,12)
await hold("KeyD", 3000); await hold("KeyS", 400);
await wait(400);
t = await body();
check("recolhe o Anel de Selo", /Anel de Selo/.test(t) && /recolheu/i.test(t));
await wait(800);
t = await body();
check("missao 33 avanca para o no final", /Escribão|Aurelio|ponto fraco|fraca/i.test(t));
check("sem erros JS", errs.length===0, errs.join(" | "));
await page.screenshot({ path: "scripts/shot-missao33b.png" });
console.log(fails===0 ? "\nFASE FINAL: OK" : `\nFASE FINAL: ${fails} FALHAS`);
await browser.close(); server.close();
if (fails) process.exit(1);
