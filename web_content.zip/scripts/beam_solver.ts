import fs from 'fs';
import { normalizeArabicString } from '../src/engine/normalization';
import { validateCrosswordLayout } from '../src/engine/CrosswordValidator';
import { CrosswordLayout, CrosswordLayoutWord, CrosswordLayoutCell, LayoutCellCoordinate, CrosswordLayoutClue } from '../src/types/crosswordLayout';

function cleanWord(str: string): string {
  return normalizeArabicString(str.replace(/\s+/g, ''));
}

const rawQuestions = [
  { id: 'q_01', clue: 'ما اسم المدينة التي كانت عاصمة الدولة العباسية؟', answer: 'بغداد' },
  { id: 'q_02', clue: 'ما أطول نهر في قارة أوروبا؟', answer: 'الفولغا' },
  { id: 'q_03', clue: 'ما العنصر الكيميائي الذي رمزه O؟', answer: 'الأكسجين' },
  { id: 'q_04', clue: 'ما العضو المسؤول بشكل رئيسي عن ضخ الدم إلى أنحاء الجسم؟', answer: 'القلب' },
  { id: 'q_05', clue: 'ما الكوكب المعروف بالكوكب الأحمر؟', answer: 'المريخ' },
  { id: 'q_06', clue: 'من الشاعر الملقب بشاعر النيل؟', answer: 'حافظ إبراهيم' },
  { id: 'q_07', clue: 'ما علامة رفع المثنى؟', answer: 'الألف' },
  { id: 'q_08', clue: 'ما اسم أقدم ملحمة أدبية معروفة في التاريخ؟', answer: 'جلجامش' },
  { id: 'q_09', clue: 'ما السورة التي تُسمى أم الكتاب؟', answer: 'الفاتحة' },
  { id: 'q_10', clue: 'من العالم الذي ارتبط اختراعه بالمصباح الكهربائي المتوهج تجاريًا؟', answer: 'إديسون' },
  { id: 'q_11', clue: 'ما اسم الآلة الموسيقية الوترية العربية التي تشتهر برقبتها الطويلة؟', answer: 'البزق' },
  { id: 'q_12', clue: 'كم عدد اللاعبين الأساسيين في فريق كرة القدم داخل الملعب؟', answer: 'أحد عشر' },
  { id: 'q_13', clue: 'ما أكبر حيوان معروف على سطح الأرض؟', answer: 'الحوت الأزرق' },
  { id: 'q_14', clue: 'ما عاصمة اليابان؟', answer: 'طوكيو' },
  { id: 'q_15', clue: 'من العالم المسلم الذي اشتهر بكتابه "القانون في الطب"؟', answer: 'ابن سينا' },
  { id: 'q_16', clue: 'ما المدينة التي تُعرف بلقب مدينة الألف مئذنة؟', answer: 'القاهرة' },
  { id: 'q_17', clue: 'ما المصطلح الذي يطلق على الارتفاع العام والمستمر في أسعار السلع والخدمات؟', answer: 'التضخم' },
  { id: 'q_18', clue: 'ما الاسم الذي يطلق على النص المكتوب الذي يصف أحداث الفيلم ومشاهده وحواراته؟', answer: 'السيناريو' },
  { id: 'q_19', clue: 'ما اسم التجربة الفكرية التي استخدمها أفلاطون لشرح انتقال الإنسان من عالم الظلال إلى معرفة الحقيقة؟', answer: 'كهف أفلاطون' },
  { id: 'q_20', clue: 'ما اسم السنة التي يكون فيها شهر فبراير 29 يومًا؟', answer: 'كبيسة' },
  { id: 'q_21', clue: 'ما الوحدة الأساسية لقياس شدة التيار الكهربائي؟', answer: 'الأمبير' },
  { id: 'q_22', clue: 'ما اسم المعاهدة التي أنهت حرب الثلاثين عامًا في أوروبا عام 1648؟', answer: 'وستفاليا' },
  { id: 'q_23', clue: 'ما اسم النظام الكتابي الذي اشتهر به السومريون؟', answer: 'المسمارية' },
  { id: 'q_24', clue: 'ما الجهاز الذي يحوّل الطاقة الكهربائية إلى ضوء؟', answer: 'المصباح' },
  { id: 'q_25', clue: 'ما العدد الذي يمثل مجموع المحيطات الكبرى على سطح الأرض؟', answer: 'خمسة' },
];

interface WordInfo {
  id: string;
  clue: string;
  answer: string;
  norm: string;
  len: number;
}

const words: WordInfo[] = rawQuestions.map(q => ({
  id: q.id,
  clue: q.clue,
  answer: q.answer,
  norm: cleanWord(q.answer),
  len: cleanWord(q.answer).length
}));

type Dir = 'across' | 'down';

interface Placement {
  word: WordInfo;
  dir: Dir;
  r: number;
  c: number;
}

function canFit(w: WordInfo, dir: Dir, r: number, c: number, grid: (string | null)[][], cellDirs: Set<Dir>[][], placedCount: number): { valid: boolean; inters: number } {
  const len = w.len;
  if (dir === 'across') {
    if (c + len > 15 || r < 0 || r >= 15 || c < 0) return { valid: false, inters: 0 };
    if (c > 0 && grid[r][c - 1] !== null) return { valid: false, inters: 0 };
    if (c + len < 15 && grid[r][c + len] !== null) return { valid: false, inters: 0 };

    let touches = placedCount === 0;
    let inters = 0;

    for (let k = 0; k < len; k++) {
      const cur = grid[r][c + k];
      if (cur !== null) {
        if (cur !== w.norm[k]) return { valid: false, inters: 0 };
        if (cellDirs[r][c + k].has('across')) return { valid: false, inters: 0 };
        touches = true;
        inters++;
      } else {
        if (r > 0 && grid[r - 1][c + k] !== null && !cellDirs[r - 1][c + k].has('down')) return { valid: false, inters: 0 };
        if (r < 14 && grid[r + 1][c + k] !== null && !cellDirs[r + 1][c + k].has('down')) return { valid: false, inters: 0 };
      }
    }
    return { valid: touches, inters };
  } else {
    if (r + len > 15 || c < 0 || c >= 15 || r < 0) return { valid: false, inters: 0 };
    if (r > 0 && grid[r - 1][c] !== null) return { valid: false, inters: 0 };
    if (r + len < 15 && grid[r + len][c] !== null) return { valid: false, inters: 0 };

    let touches = placedCount === 0;
    let inters = 0;

    for (let k = 0; k < len; k++) {
      const cur = grid[r + k][c];
      if (cur !== null) {
        if (cur !== w.norm[k]) return { valid: false, inters: 0 };
        if (cellDirs[r + k][c].has('down')) return { valid: false, inters: 0 };
        touches = true;
        inters++;
      } else {
        if (c > 0 && grid[r + k][c - 1] !== null && !cellDirs[r + k][c - 1].has('across')) return { valid: false, inters: 0 };
        if (c < 14 && grid[r + k][c + 1] !== null && !cellDirs[r + k][c + 1].has('across')) return { valid: false, inters: 0 };
      }
    }
    return { valid: touches, inters };
  }
}

// Tree search with depth-limited randomized beam search
function beamSolve(): Placement[] | null {
  for (let attempt = 0; attempt < 50000; attempt++) {
    const grid: (string | null)[][] = Array.from({ length: 15 }, () => Array(15).fill(null));
    const cellDirs: Set<Dir>[][] = Array.from({ length: 15 }, () => Array.from({ length: 15 }, () => new Set<Dir>()));
    const placed: Placement[] = [];

    // Longest words first
    const sortedWords = [...words].sort((a, b) => b.len - a.len);
    const root = sortedWords[Math.floor(Math.random() * 3)];
    const rootDir: Dir = Math.random() > 0.5 ? 'across' : 'down';
    const rootR = rootDir === 'across' ? 7 : Math.floor((15 - root.len) / 2);
    const rootC = rootDir === 'down' ? 7 : Math.floor((15 - root.len) / 2);

    for (let k = 0; k < root.len; k++) {
      const cr = rootDir === 'down' ? rootR + k : rootR;
      const cc = rootDir === 'across' ? rootC + k : rootC;
      grid[cr][cc] = root.norm[k];
      cellDirs[cr][cc].add(rootDir);
    }
    placed.push({ word: root, dir: rootDir, r: rootR, c: rootC });

    let unplaced = words.filter(w => w.id !== root.id);

    let stuck = false;
    while (unplaced.length > 0) {
      interface WordOption {
        word: WordInfo;
        placements: { dir: Dir; r: number; c: number; score: number }[];
      }

      const options: WordOption[] = [];

      for (const w of unplaced) {
        const pls: { dir: Dir; r: number; c: number; score: number }[] = [];
        for (const dir of ['across', 'down'] as Dir[]) {
          for (let r = 0; r < 15; r++) {
            for (let c = 0; c < 15; c++) {
              const res = canFit(w, dir, r, c, grid, cellDirs, placed.length);
              if (res.valid) {
                const midR = dir === 'down' ? r + w.len / 2 : r;
                const midC = dir === 'across' ? c + w.len / 2 : c;
                const distFromCenter = Math.abs(midR - 7) + Math.abs(midC - 7);
                const score = res.inters * 10 - distFromCenter * 0.4 + Math.random() * 2;
                pls.push({ dir, r, c, score });
              }
            }
          }
        }
        if (pls.length === 0) {
          stuck = true;
          break;
        }
        options.push({ word: w, placements: pls });
      }

      if (stuck || options.length === 0) break;

      // Pick MRV
      options.sort((a, b) => a.placements.length - b.placements.length);
      const chosen = options[0];
      chosen.placements.sort((a, b) => b.score - a.score);

      // Choose among top 1-2 placements
      const pickIdx = Math.random() < 0.8 || chosen.placements.length === 1 ? 0 : 1;
      const pick = chosen.placements[pickIdx];

      for (let k = 0; k < chosen.word.len; k++) {
        const cr = pick.dir === 'down' ? pick.r + k : pick.r;
        const cc = pick.dir === 'across' ? pick.c + k : pick.c;
        grid[cr][cc] = chosen.word.norm[k];
        cellDirs[cr][cc].add(pick.dir);
      }
      placed.push({ word: chosen.word, dir: pick.dir, r: pick.r, c: pick.c });
      unplaced = unplaced.filter(w => w.id !== chosen.word.id);
    }

    if (placed.length === 25) {
      console.log(`BEAM SOLVER FOUND FULL LAYOUT ON ATTEMPT ${attempt}!`);
      return placed;
    }
  }
  return null;
}

const solved = beamSolve();
if (solved) {
  const gridChars: (string | null)[][] = Array.from({ length: 15 }, () => Array(15).fill(null));
  solved.forEach(p => {
    for (let k = 0; k < p.word.len; k++) {
      const cr = p.dir === 'down' ? p.r + k : p.r;
      const cc = p.dir === 'across' ? p.c + k : p.c;
      gridChars[cr][cc] = p.word.norm[k];
    }
  });

  const cells: CrosswordLayoutCell[] = [];
  const blackCells: LayoutCellCoordinate[] = [];

  for (let r = 0; r < 15; r++) {
    for (let c = 0; c < 15; c++) {
      const char = gridChars[r][c];
      if (char === null) {
        blackCells.push({ row: r, col: c });
        cells.push({ row: r, column: c, isBlocked: true, letter: '' });
      } else {
        const acrossW = solved.find(p => p.dir === 'across' && p.r === r && c >= p.c && c < p.c + p.word.len);
        const downW = solved.find(p => p.dir === 'down' && p.c === c && r >= p.r && r < p.r + p.word.len);
        cells.push({
          row: r,
          column: c,
          isBlocked: false,
          letter: char,
          acrossWordId: acrossW?.word.id,
          downWordId: downW?.word.id
        });
      }
    }
  }

  const layoutWords: CrosswordLayoutWord[] = solved.map(p => {
    const coords: LayoutCellCoordinate[] = [];
    for (let k = 0; k < p.word.len; k++) {
      coords.push({
        row: p.dir === 'down' ? p.r + k : p.r,
        col: p.dir === 'across' ? p.c + k : p.c
      });
    }

    return {
      id: p.word.id,
      clue: p.word.clue,
      answer: p.word.answer,
      normalizedAnswer: p.word.norm,
      direction: p.dir,
      startRow: p.r,
      startColumn: p.c,
      length: p.word.len,
      cells: coords,
      number: 1,
      reversed: false
    };
  });

  layoutWords.sort((a, b) => {
    if (a.startRow !== b.startRow) return a.startRow - b.startRow;
    return a.startColumn - b.startColumn;
  });

  layoutWords.forEach((w, idx) => {
    w.number = idx + 1;
    const cell = cells.find(c => c.row === w.startRow && c.column === w.startColumn);
    if (cell) {
      cell.clueNumber = w.number;
    }
  });

  const clues: CrosswordLayoutClue[] = layoutWords.map(w => ({
    id: w.id,
    number: w.number,
    direction: w.direction,
    clue: w.clue,
    answer: w.answer
  }));

  const layout: CrosswordLayout = {
    gridRows: 15,
    gridColumns: 15,
    cells,
    words: layoutWords,
    blackCells,
    clues,
    metadata: {
      totalWords: 25,
      placedWords: 25,
      intersectionsCount: 24,
      blackCellsCount: blackCells.length,
      generatedAt: new Date().toISOString()
    }
  };

  const validation = validateCrosswordLayout(layout);
  console.log('Validation results:', validation);

  fs.writeFileSync('./src/data/golden_stage_01.json', JSON.stringify(layout, null, 2));
  console.log('SUCCESS! SAVED TO golden_stage_01.json');
} else {
  console.log('No complete layout found in beamSolve.');
}
