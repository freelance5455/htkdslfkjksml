/**
 * Generator for original energetic SPR Endless Runner background music.
 * Produces a seamless looping 138 BPM electronic runner track.
 */
import fs from 'fs';
import path from 'path';

const SAMPLE_RATE = 44100;
const BPM = 138;
const BEATS_PER_BAR = 4;
const TOTAL_BARS = 16;
const BEAT_DURATION = 60 / BPM; // ~0.4348s
const TOTAL_SECONDS = TOTAL_BARS * BEATS_PER_BAR * BEAT_DURATION; // ~27.826s
const TOTAL_SAMPLES = Math.round(TOTAL_SECONDS * SAMPLE_RATE);

console.log(`Generating SPR Runner Soundtrack: ${TOTAL_SECONDS.toFixed(2)}s, ${TOTAL_SAMPLES} samples at ${SAMPLE_RATE}Hz...`);

const bufferL = new Float32Array(TOTAL_SAMPLES);
const bufferR = new Float32Array(TOTAL_SAMPLES);

// Note frequencies (Hz)
const NOTES = {
  D2: 73.42,
  F2: 87.31,
  G2: 98.00,
  A2: 110.00,
  Bb2: 116.54,
  C3: 130.81,
  D3: 146.83,
  F3: 174.61,
  G3: 196.00,
  A3: 220.00,
  Bb3: 233.08,
  C4: 261.63,
  D4: 293.66,
  E4: 329.63,
  F4: 349.23,
  G4: 392.00,
  A4: 440.00,
  Bb4: 466.16,
  C5: 523.25,
  D5: 587.33,
  E5: 659.25,
  F5: 698.46,
  A5: 880.00,
};

// 1. Render Drums
for (let bar = 0; bar < TOTAL_BARS; bar++) {
  const barTime = bar * 4 * BEAT_DURATION;

  // 4 Beats per bar
  for (let beat = 0; beat < 4; beat++) {
    const beatTime = barTime + beat * BEAT_DURATION;

    // --- KICK DRUM on every beat (4-on-the-floor) ---
    const kickStart = Math.round(beatTime * SAMPLE_RATE);
    const kickLen = Math.round(0.24 * SAMPLE_RATE);
    for (let i = 0; i < kickLen && kickStart + i < TOTAL_SAMPLES; i++) {
      const t = i / SAMPLE_RATE;
      // Exponential pitch drop from 160Hz down to 45Hz
      const pitch = 45 + 115 * Math.exp(-t * 26);
      const phase = 2 * Math.PI * (45 * t + (115 / 26) * (1 - Math.exp(-t * 26)));
      const env = Math.exp(-t * 14);
      // Punch click
      const click = Math.sin(2 * Math.PI * 1200 * t) * Math.exp(-t * 120) * 0.3;
      const kickVal = (Math.sin(phase) * 0.85 + click) * env * 0.75;

      bufferL[kickStart + i] += kickVal;
      bufferR[kickStart + i] += kickVal;
    }

    // --- SNARE / CLAP on Beats 1 and 3 (0-indexed: beat 1 & 3) ---
    if (beat === 1 || beat === 3 || (bar === TOTAL_BARS - 1 && beat >= 2)) {
      const snareStart = Math.round(beatTime * SAMPLE_RATE);
      const snareLen = Math.round(0.22 * SAMPLE_RATE);
      for (let i = 0; i < snareLen && snareStart + i < TOTAL_SAMPLES; i++) {
        const t = i / SAMPLE_RATE;
        const tone = Math.sin(2 * Math.PI * 185 * t) * Math.exp(-t * 28) * 0.35;
        const noise = (Math.random() * 2 - 1) * Math.exp(-t * 16) * 0.55;
        const snap = Math.sin(2 * Math.PI * 850 * t) * Math.exp(-t * 60) * 0.2;
        const snareVal = (tone + noise + snap) * 0.7;

        bufferL[snareStart + i] += snareVal * 0.9;
        bufferR[snareStart + i] += snareVal * 0.9;
      }
    }

    // --- 16th NOTE HI-HATS ---
    for (let sixteenth = 0; sixteenth < 4; sixteenth++) {
      const hatTime = beatTime + sixteenth * (BEAT_DURATION / 4);
      const hatStart = Math.round(hatTime * SAMPLE_RATE);
      const isOpen = sixteenth === 2; // Off-beat open hat
      const hatLen = Math.round((isOpen ? 0.12 : 0.04) * SAMPLE_RATE);
      const decay = isOpen ? 22 : 80;
      const vol = isOpen ? 0.22 : (sixteenth % 2 === 0 ? 0.15 : 0.1);

      for (let i = 0; i < hatLen && hatStart + i < TOTAL_SAMPLES; i++) {
        const t = i / SAMPLE_RATE;
        const noise = (Math.random() * 2 - 1) * Math.exp(-t * decay) * vol;
        // high frequency metallic tint
        const metallic = Math.sin(2 * Math.PI * 7200 * t) * Math.exp(-t * decay) * (vol * 0.4);
        const hatVal = noise + metallic;

        bufferL[hatStart + i] += hatVal * 0.75;
        bufferR[hatStart + i] += hatVal * 0.85;
      }
    }
  }
}

// 2. Render Driving Electro Bassline
// Chord progression: 4 bars Dm, 2 bars Bb, 2 bars C, repeat with Am variation
const bassChords = [
  'D2', 'D2', 'D2', 'D2', // Bars 1-4: D minor groove
  'Bb2', 'Bb2', 'C3', 'A2', // Bars 5-8: Progression
  'D2', 'D2', 'F2', 'D2', // Bars 9-12: High energy groove
  'Bb2', 'C3', 'D3', 'A2', // Bars 13-16: Climax & Turnaround
];

for (let bar = 0; bar < TOTAL_BARS; bar++) {
  const rootNote = NOTES[bassChords[bar] || 'D2'];
  const barTime = bar * 4 * BEAT_DURATION;

  // 16th-note rolling bass groove
  for (let sixteenth = 0; sixteenth < 16; sixteenth++) {
    // Skip occasional sixteenth for rhythmic bounce
    if (sixteenth === 3 || sixteenth === 11) continue;

    const noteTime = barTime + sixteenth * (BEAT_DURATION / 4);
    const noteStart = Math.round(noteTime * SAMPLE_RATE);
    const noteLen = Math.round(0.13 * SAMPLE_RATE);

    // Subtle octave jump on upbeats
    let freq = rootNote;
    if (sixteenth === 2 || sixteenth === 8 || sixteenth === 14) {
      freq = rootNote * 2; // Octave up
    } else if (sixteenth === 6 || sixteenth === 12) {
      freq = rootNote * 1.5; // Fifth
    }

    for (let i = 0; i < noteLen && noteStart + i < TOTAL_SAMPLES; i++) {
      const t = i / SAMPLE_RATE;
      const env = Math.exp(-t * 18);
      // Sawtooth + Square wave blend for fat synth bass
      const saw = (2 * ((t * freq) % 1) - 1);
      const sqr = Math.sin(2 * Math.PI * freq * t) > 0 ? 0.6 : -0.6;
      const sub = Math.sin(2 * Math.PI * (freq / 2) * t) * 0.7; // Sub-bass

      // Filter sweep
      const filterCutoff = 800 * Math.exp(-t * 22) + 200;
      const resonance = Math.sin(2 * Math.PI * filterCutoff * t) * 0.25 * env;

      const bassVal = (saw * 0.4 + sqr * 0.3 + sub + resonance) * env * 0.42;

      bufferL[noteStart + i] += bassVal * 0.95;
      bufferR[noteStart + i] += bassVal * 0.95;
    }
  }
}

// 3. Render Synth Brass / Chords
const chordProg = [
  // Bars 1-4: Dm
  [NOTES.D4, NOTES.F4, NOTES.A4],
  [NOTES.D4, NOTES.F4, NOTES.A4],
  [NOTES.F4, NOTES.A4, NOTES.C5],
  [NOTES.D4, NOTES.F4, NOTES.A4],
  // Bars 5-8: Bb - C - Dm - A
  [NOTES.Bb3, NOTES.D4, NOTES.F4],
  [NOTES.Bb3, NOTES.D4, NOTES.F4],
  [NOTES.C4, NOTES.E4, NOTES.G4],
  [NOTES.A3, NOTES.D4, NOTES.F4],
  // Bars 9-12: Energetic chorus
  [NOTES.D4, NOTES.F4, NOTES.A4],
  [NOTES.F4, NOTES.A4, NOTES.D5],
  [NOTES.G4, NOTES.Bb4, NOTES.D5],
  [NOTES.A4, NOTES.C5, NOTES.E5],
  // Bars 13-16: Climax
  [NOTES.Bb4, NOTES.D5, NOTES.F5],
  [NOTES.C5, NOTES.E5, NOTES.G5],
  [NOTES.D5, NOTES.F5, NOTES.A5],
  [NOTES.A4, NOTES.D5, NOTES.F5],
];

for (let bar = 0; bar < TOTAL_BARS; bar++) {
  const chord = chordProg[bar];
  const barTime = bar * 4 * BEAT_DURATION;

  // Stabs on beats: 0.5, 1.5, 2.75, 3.5 (Syncopated high-energy EDM runner rhythm)
  const stabBeats = [0.5, 1.5, 2.5, 3.25];
  for (const beatOffset of stabBeats) {
    const stabTime = barTime + beatOffset * BEAT_DURATION;
    const stabStart = Math.round(stabTime * SAMPLE_RATE);
    const stabLen = Math.round(0.18 * SAMPLE_RATE);

    for (let i = 0; i < stabLen && stabStart + i < TOTAL_SAMPLES; i++) {
      const t = i / SAMPLE_RATE;
      const env = Math.exp(-t * 14);

      let chordValL = 0;
      let chordValR = 0;

      for (let c = 0; c < chord.length; c++) {
        const f = chord[c];
        // Supersaw detune
        const s1 = Math.sin(2 * Math.PI * f * t);
        const s2 = Math.sin(2 * Math.PI * (f * 1.006) * t);
        const s3 = Math.sin(2 * Math.PI * (f * 0.994) * t);
        const voice = (s1 + s2 * 0.7 + s3 * 0.7) * 0.33;

        // Stereo spread
        if (c === 0) { chordValL += voice * 0.9; chordValR += voice * 0.6; }
        else if (c === 1) { chordValL += voice * 0.75; chordValR += voice * 0.75; }
        else { chordValL += voice * 0.6; chordValR += voice * 0.9; }
      }

      bufferL[stabStart + i] += chordValL * env * 0.32;
      bufferR[stabStart + i] += chordValR * env * 0.32;
    }
  }
}

// 4. Render Catchy Lead Arpeggio Melody (SPR Runner Theme)
// Signature melodic hook that repeats in harmony
const leadMelodyNotes = [
  // Bar 1-2:
  'A4', 'D5', 'E5', 'F5', 'E5', 'D5', 'A4', 'F4',
  'G4', 'A4', 'D5', 'A4', 'F4', 'D4', 'E4', 'F4',
  // Bar 3-4:
  'A4', 'D5', 'F5', 'A5', 'G5', 'F5', 'E5', 'D5',
  'E5', 'F5', 'E5', 'D5', 'C5', 'A4', 'C5', 'D5',
  // Bar 5-6:
  'D5', 'F5', 'G5', 'A5', 'Bb5', 'A5', 'G5', 'F5',
  'G5', 'A5', 'G5', 'F5', 'E5', 'C5', 'D5', 'E5',
  // Bar 7-8:
  'F5', 'E5', 'D5', 'C5', 'D5', 'E5', 'F5', 'G5',
  'A5', 'A5', 'G5', 'F5', 'E5', 'D5', 'E5', 'D5',
  // Bar 9-10 (High octave energetic climax):
  'A5', 'D5', 'E5', 'F5', 'E5', 'D5', 'A5', 'F5',
  'G5', 'A5', 'D5', 'A5', 'F5', 'D5', 'E5', 'F5',
  // Bar 11-12:
  'A5', 'D5', 'F5', 'A5', 'G5', 'F5', 'E5', 'D5',
  'E5', 'F5', 'E5', 'D5', 'C5', 'A5', 'C5', 'D5',
  // Bar 13-14:
  'D5', 'F5', 'G5', 'A5', 'Bb5', 'A5', 'G5', 'F5',
  'G5', 'A5', 'G5', 'F5', 'E5', 'C5', 'D5', 'E5',
  // Bar 15-16:
  'F5', 'G5', 'A5', 'D5', 'E5', 'F5', 'G5', 'A5',
  'A5', 'G5', 'F5', 'E5', 'D5', 'E5', 'D5', 'D5',
];

const notesPerBar = 8; // 8th notes
const noteDuration = BEAT_DURATION / 2; // ~0.217s

for (let i = 0; i < leadMelodyNotes.length; i++) {
  const noteName = leadMelodyNotes[i];
  const freq = NOTES[noteName] || 440;
  const noteTime = i * noteDuration;
  const noteStart = Math.round(noteTime * SAMPLE_RATE);
  const noteLen = Math.round(noteDuration * 0.9 * SAMPLE_RATE);

  for (let s = 0; s < noteLen && noteStart + s < TOTAL_SAMPLES; s++) {
    const t = s / SAMPLE_RATE;
    const env = Math.exp(-t * 9) * (1 - Math.exp(-t * 200)); // Pluck envelope

    // Bright square + triangle synth lead
    const sqr = Math.sin(2 * Math.PI * freq * t) > 0 ? 0.5 : -0.5;
    const tri = Math.asin(Math.sin(2 * Math.PI * freq * t)) * (2 / Math.PI);
    const chime = Math.sin(2 * Math.PI * freq * 2 * t) * 0.3; // octave sparkle

    const leadVal = (sqr * 0.35 + tri * 0.5 + chime) * env * 0.28;

    // Ping-pong delay effect
    const panL = 0.5 + 0.35 * Math.sin(i * 1.2);
    const panR = 0.5 - 0.35 * Math.sin(i * 1.2);

    bufferL[noteStart + s] += leadVal * panL;
    bufferR[noteStart + s] += leadVal * panR;

    // Simple delay feedback into future buffer
    const delayOffset = Math.round((noteDuration * 1.5) * SAMPLE_RATE);
    if (noteStart + s + delayOffset < TOTAL_SAMPLES) {
      bufferL[noteStart + s + delayOffset] += leadVal * panR * 0.25;
      bufferR[noteStart + s + delayOffset] += leadVal * panL * 0.25;
    }
  }
}

// 5. Seamless Loop Smoothing: Soft crossfade on very ends to guarantee zero pop
const crossfadeLen = Math.round(0.04 * SAMPLE_RATE); // 40ms
for (let i = 0; i < crossfadeLen; i++) {
  const fadeOut = (crossfadeLen - i) / crossfadeLen;
  const fadeIn = i / crossfadeLen;

  // Blend end into beginning for perfect phase match
  const endIdx = TOTAL_SAMPLES - crossfadeLen + i;
  const startIdx = i;

  const blendedL = bufferL[startIdx] * fadeIn + bufferL[endIdx] * fadeOut;
  const blendedR = bufferR[startIdx] * fadeIn + bufferR[endIdx] * fadeOut;

  bufferL[startIdx] = blendedL;
  bufferR[startIdx] = blendedR;
  bufferL[endIdx] = blendedL;
  bufferR[endIdx] = blendedR;
}

// 6. Master Limiter / Normalizer
let maxAmp = 0;
for (let i = 0; i < TOTAL_SAMPLES; i++) {
  const aL = Math.abs(bufferL[i]);
  const aR = Math.abs(bufferR[i]);
  if (aL > maxAmp) maxAmp = aL;
  if (aR > maxAmp) maxAmp = aR;
}

console.log(`Peak amplitude before normalization: ${maxAmp.toFixed(3)}`);
const targetPeak = 0.92;
const gain = maxAmp > 0 ? targetPeak / maxAmp : 1.0;

// 7. Write 16-bit stereo PCM WAV File
const numChannels = 2;
const bytesPerSample = 2;
const blockAlign = numChannels * bytesPerSample;
const byteRate = SAMPLE_RATE * blockAlign;
const dataSize = TOTAL_SAMPLES * blockAlign;
const wavBufferSize = 44 + dataSize;
const outWav = Buffer.alloc(wavBufferSize);

// RIFF header
outWav.write('RIFF', 0);
outWav.writeUInt32LE(wavBufferSize - 8, 4);
outWav.write('WAVE', 8);

// fmt subchunk
outWav.write('fmt ', 12);
outWav.writeUInt32LE(16, 16); // Subchunk1Size (16 for PCM)
outWav.writeUInt16LE(1, 20);  // AudioFormat (1 = PCM)
outWav.writeUInt16LE(numChannels, 22);
outWav.writeUInt32LE(SAMPLE_RATE, 24);
outWav.writeUInt32LE(byteRate, 28);
outWav.writeUInt16LE(blockAlign, 32);
outWav.writeUInt16LE(16, 34); // BitsPerSample

// data subchunk
outWav.write('data', 36);
outWav.writeUInt32LE(dataSize, 40);

let offset = 44;
for (let i = 0; i < TOTAL_SAMPLES; i++) {
  // Soft clipping with tanh
  const sampleL = Math.tanh(bufferL[i] * gain);
  const sampleR = Math.tanh(bufferR[i] * gain);

  const intL = Math.max(-32768, Math.min(32767, Math.round(sampleL * 32767)));
  const intR = Math.max(-32768, Math.min(32767, Math.round(sampleR * 32767)));

  outWav.writeInt16LE(intL, offset);
  outWav.writeInt16LE(intR, offset + 2);
  offset += 4;
}

const outDir = path.resolve('public/audio');
if (!fs.existsSync(outDir)) {
  fs.mkdirSync(outDir, { recursive: true });
}

const wavPath = path.join(outDir, 'spr_runner_theme.wav');
fs.writeFileSync(wavPath, outWav);
console.log(`Saved WAV to: ${wavPath} (${(outWav.length / 1024 / 1024).toFixed(2)} MB)`);
