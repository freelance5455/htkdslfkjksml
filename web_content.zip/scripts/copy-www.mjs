// Copies the web app into ./www (Capacitor's webDir). No bundler needed — the app is plain ES modules.
import { cpSync, rmSync, mkdirSync } from 'node:fs';
rmSync('www', { recursive: true, force: true });
mkdirSync('www', { recursive: true });
for (const p of ['index.html', 'manifest.webmanifest', 'sw.js', 'icons', 'src']) cpSync(p, `www/${p}`, { recursive: true });
console.log('www/ ready');
