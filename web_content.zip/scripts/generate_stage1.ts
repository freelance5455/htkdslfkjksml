import fs from 'fs';
import { CrosswordDesigner, DesignerQuestionInput } from '../src/engine/CrosswordDesigner';
import { validateCrosswordLayout } from '../src/engine/CrosswordValidator';

const questions: DesignerQuestionInput[] = [
  { id: 'q_01', clue: 'ما اسم المدينة التي كانت عاصمة الدولة العباسية؟', answer: 'بغداد' },
  { id: 'q_02', clue: 'ما أطول نهر في قارة أوروبا؟', answer: 'الفولغا' },
  { id: 'q_03', clue: 'ما العنصر الكيميائي الذي رمزه O؟', answer: 'الأكسجين' },
  { id: 'q_04', clue: 'ما العضو المسؤول بشكل رئيسي عن ضخ الدم إلى أنحاء الجسم؟', answer: 'القلب' },
  { id: 'q_05', clue: 'ما الكوكب المعروف بالكوكب الأحمر؟', answer: 'المريخ' },
  { id: 'q_06', clue: 'من الشاعر الملقب بشاعر النيل؟', answer: 'حافظ إبراهيم' },
  { id: 'q_07', clue: 'ما علامة رفع المثنى؟', answer: 'الألف' },
  { id: 'q_08', clue: 'ما اسم أقدم ملحمة أدبية معروفة في التاريخ؟', answer: 'ملحمة جلجامش' },
  { id: 'q_09', clue: 'ما السورة التي تُسمى أم الكتاب؟', answer: 'الفاتحة' },
  { id: 'q_10', clue: 'من العالم الذي ارتبط اختراعه بالمصباح الكهربائي المتوهج تجاريًا؟', answer: 'توماس إديسون' },
  { id: 'q_11', clue: 'ما اسم الآلة الموسيقية الوترية العربية التي تشتهر برقبتها الطويلة؟', answer: 'العود' },
  { id: 'q_12', clue: 'كم عدد اللاعبين الأساسيين في فريق كرة القدم داخل الملعب؟', answer: 'أحد عشر' },
  { id: 'q_13', clue: 'ما أكبر حيوان معروف على سطح الأرض؟', answer: 'الحوت الأزرق' },
  { id: 'q_14', clue: 'ما عاصمة اليابان؟', answer: 'طوكيو' },
  { id: 'q_15', clue: 'من العالم المسلم الذي اشتهر بكتابه "القانون في الطب"؟', answer: 'ابن سينا' },
  { id: 'q_16', clue: 'ما المدينة التي تُعرف بلقب مدينة الألف مئذنة؟', answer: 'القاهرة' },
  { id: 'q_17', clue: 'ما المصطلح الذي يطلق على الارتفاع العام والمستمر في أسعار السلع والخدمات؟', answer: 'التضخم' },
  { id: 'q_18', clue: 'ما الاسم الذي يطلق على النص المكتوب الذي يصف أحداث الفيلم ومشاهده وحواراته؟', answer: 'السيناريو' },
  { id: 'q_19', clue: 'ما اسم التجربة الفكرية التي استخدمها أفلاطون لشرح انتقال الإنسان من عالم الظلال إلى معرفة الحقيقة؟', answer: 'كهف أفلاطون' },
  { id: 'q_20', clue: 'ما اسم السنة التي يكون فيها شهر فبراير 29 يومًا؟', answer: 'السنة الكبيسة' },
  { id: 'q_21', clue: 'ما الوحدة الأساسية لقياس شدة التيار الكهربائي؟', answer: 'الأمبير' },
  { id: 'q_22', clue: 'ما اسم المعاهدة التي أنهت حرب الثلاثين عامًا في أوروبا عام 1648؟', answer: 'صلح وستفاليا' },
  { id: 'q_23', clue: 'ما اسم النظام الكتابي الذي اشتهر به السومريون؟', answer: 'المسمارية' },
  { id: 'q_24', clue: 'ما الجهاز الذي يحوّل الطاقة الكهربائية إلى ضوء؟', answer: 'المصباح' },
  { id: 'q_25', clue: 'ما العدد الذي يمثل مجموع المحيطات الكبرى على سطح الأرض؟', answer: 'خمسة' },
];

async function run() {
  console.log('Total questions:', questions.length);
  const designer = new CrosswordDesigner();
  
  let bestResult = null;
  let bestPlaced = 0;
  
  // Try several batches with different random seeds
  for (let attempt = 1; attempt <= 20; attempt++) {
    const result = designer.generateLayout(questions, 200, 15, 15);
    const placed = result.layout.words.length;
    console.log(`Attempt ${attempt}: placed ${placed}/${questions.length}, valid: ${result.validation.isValid}`);
    if (placed > bestPlaced) {
      bestPlaced = placed;
      bestResult = result;
    }
    if (placed === questions.length && result.validation.isValid) {
      console.log('Found 100% complete valid layout!');
      bestResult = result;
      break;
    }
  }

  if (bestResult) {
    console.log(`Best result placed ${bestResult.layout.words.length}/${questions.length}`);
    console.log('Validation:', bestResult.validation);
    
    // Save to golden stage 01
    const stageData = {
      id: 1,
      title: 'المرحلة 1: الطبعة الافتتاحية',
      description: 'أول عدد من الكلمات المتقاطعة للجريدة اليومية - 25 سؤالاً ثقافياً شاملاً',
      gridSize: { rows: 15, cols: 15 },
      words: bestResult.layout.words.map((w, idx) => ({
        id: w.id,
        number: idx + 1,
        clue: w.clue,
        answer: w.answer,
        normalizedAnswer: w.normalizedAnswer,
        direction: w.direction,
        startRow: w.startRow,
        startCol: w.startCol,
        length: w.length,
        cells: w.cells
      })),
      grid: bestResult.layout.grid
    };

    fs.writeFileSync('./src/data/golden_stage_01.json', JSON.stringify(stageData, null, 2));
    console.log('Successfully saved to src/data/golden_stage_01.json');
  }
}

run();
