import { existsSync, mkdirSync, copyFileSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const manifestPath = 'android/app/src/main/AndroidManifest.xml';
let xml = readFileSync(manifestPath, 'utf8');

// TailleurPro launcher icon: copy the prepared PNGs into the generated Android project.
const iconRoot = 'assets/android';
if (!existsSync(iconRoot)) throw new Error('TailleurPro icon assets not found');
for (const density of ['mdpi','hdpi','xhdpi','xxhdpi','xxxhdpi']) {
  const targetDir = join('android','app','src','main','res',`mipmap-${density}`);
  mkdirSync(targetDir, { recursive: true });
  for (const name of ['ic_launcher.png','ic_launcher_round.png']) {
    copyFileSync(join(iconRoot,`mipmap-${density}`,name), join(targetDir,name));
  }
}

// Remove Capacitor's generated adaptive-icon XML so Android cannot keep
// selecting an older adaptive icon instead of our prepared TailleurPro PNGs.
for (const rel of [
  'android/app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml',
  'android/app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml'
]) {
  if (existsSync(rel)) {
    const { unlinkSync } = await import('node:fs');
    unlinkSync(rel);
  }
}

// Ensure Android uses the TailleurPro launcher icon.
const appMatch = xml.match(/<application\b[^>]*>/);
if (!appMatch) throw new Error('Application tag not found in AndroidManifest.xml');
let appTag = appMatch[0];
if (!/\bandroid:icon=/.test(appTag)) appTag = appTag.replace(/>$/, ' android:icon="@mipmap/ic_launcher">');
if (!/\bandroid:roundIcon=/.test(appTag)) appTag = appTag.replace(/>$/, ' android:roundIcon="@mipmap/ic_launcher_round">');
xml = xml.replace(appMatch[0], appTag);

// Native deep link for Supabase e-mail confirmation.
const marker = '<!-- TAILLEURPRO_DEEPLINK -->';
if (!xml.includes(marker)) {
  const filter = `\n        ${marker}\n        <intent-filter>\n            <action android:name="android.intent.action.VIEW" />\n            <category android:name="android.intent.category.DEFAULT" />\n            <category android:name="android.intent.category.BROWSABLE" />\n            <data android:scheme="tailleurpro" android:host="auth" android:pathPrefix="/callback" />\n        </intent-filter>`;
  const activityEnd = '</activity>';
  const activityIndex = xml.indexOf(activityEnd);
  if (activityIndex < 0) throw new Error('Main activity not found in AndroidManifest.xml');
  xml = xml.slice(0, activityIndex) + filter + '\n    ' + xml.slice(activityIndex);
}

// Set a clear Android version for this test build.
const gradlePath = 'android/app/build.gradle';
if (existsSync(gradlePath)) {
  let gradle = readFileSync(gradlePath, 'utf8');
  gradle = gradle.replace(/versionCode\s+\d+/, 'versionCode 7');
  gradle = gradle.replace(/versionName\s+['\"][^'\"]+['\"]/,'versionName \"1.7.2\"');
  writeFileSync(gradlePath, gradle);
}

writeFileSync(manifestPath, xml);
console.log('TailleurPro icon, version and deep link installed successfully.');
