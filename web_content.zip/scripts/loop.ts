import './stub';

const results: string[] = [];
const t = async (name: string, fn: () => void | Promise<void>) => {
  try {
    await fn();
    results.push(`  ✅ ${name}`);
  } catch (e: any) {
    results.push(`  ❌ ${name}: ${e?.message ?? e}`);
    console.error(name, e);
  }
};

const { engine } = await import('../src/game/engine');

// Fake renderer so the simulation can run without WebGL.
const fakeRenderer: any = {
  shadowMap: { enabled: true, type: 0 },
  toneMappingExposure: 1,
  toneMapping: 0,
  outputColorSpace: '',
  domElement: { clientWidth: 1280, clientHeight: 720, width: 1280, height: 720 },
  setPixelRatio() {},
  setSize() {},
  render() {},
};

await t('scene builds (no renderer)', () => {
  (engine as any).renderer = fakeRenderer;
  (engine as any).initScene('medium');
  (engine as any).pmrem = { fromScene: () => ({ texture: {}, dispose() {} }) };
  (engine as any).envTimer = 1e9;
  if (!engine.world) throw new Error('no world');
  if (!engine.playerHuman) throw new Error('no player');
  if (!engine.dog) throw new Error('no dog');
  if (!engine.vehicles.length) throw new Error('no vehicles');
  console.log(
    `     vehicles=${engine.vehicles.length} interiors=${engine.interiors.size} ` +
      `landmarks=${engine.world.interactables.length}`
  );
});

await t('600 simulation steps (no crash)', () => {
  for (let i = 0; i < 600; i++) engine.step(0.016);
  const hud = engine.getHud();
  console.log(
    `     hp=${hud.hp} money=${hud.money} clock=${hud.clock.toFixed(2)} weather=${hud.weather} ` +
      `location=${hud.location} fps=${hud.fps}`
  );
});

await t('player walks out of the villa', () => {
  // move the player to the exit and step until the interior is left
  (engine as any).playerPos.set(0, 0.15, 8.2);
  engine.interact();
  if ((engine as any).currentInterior) throw new Error('still inside the villa');
  console.log('     exterior position:', (engine as any).playerPos.toArray().map((n) => Math.round(n)));
});

await t('entering and driving a vehicle', () => {
  const car = engine.vehicles[0];
  car.heading = 0; // nose pointing down the street
  (engine as any).playerPos.set(car.pos.x + 1.2, 0, car.pos.z);
  engine.interact();
  if (!engine.inVehicle) throw new Error('failed to enter vehicle');
  engine.keys.add('KeyW');
  for (let i = 0; i < 180; i++) engine.step(0.016);
  const kmh = engine.inVehicle.kmh;
  if (kmh < 20) throw new Error('vehicle did not accelerate: ' + kmh.toFixed(1));
  console.log(`     speed after 3s: ${kmh.toFixed(1)} km/h, pos=${car.pos.toArray().map((n) => Math.round(n))}`);
  engine.keys.delete('KeyW');
});

await t('shooting spawns effects', () => {
  engine.interact();
  engine.giveWeapon('eagle');
  engine.selectWeapon('eagle');
  engine.mouseDown = true;
  for (let i = 0; i < 10; i++) engine.step(0.016);
  engine.mouseDown = false;
  const hud = engine.getHud();
  if (hud.ammo === 0) throw new Error('ammo not consumed');
  console.log(`     ammo left: ${hud.ammo}`);
});

await t('police response when wanted', () => {
  (engine as any).addWanted(3);
  for (let i = 0; i < 240; i++) engine.step(0.016);
  const hud = engine.getHud();
  console.log(`     wanted=${hud.wanted} policeCars=${(engine as any).policeCars.length}`);
  if (hud.wanted < 1) throw new Error('wanted level dropped unexpectedly');
});

await t('interior transition (police station)', () => {
  (engine as any).clearWanted();
  (engine as any).enterInterior('police');
  if (!(engine as any).currentInterior) throw new Error('failed to enter police interior');
  for (let i = 0; i < 60; i++) engine.step(0.016);
  console.log('     inside station, hp =', engine.getHud().hp);
});

await t('mission marker + pickups update', () => {
  (engine as any).exitInterior();
  engine.startMission('m1');
  for (let i = 0; i < 120; i++) engine.step(0.016);
  const hud = engine.getHud();
  console.log(`     objective="${hud.objective}" notifications=${hud.notifications.length}`);
});

await t('weather cycle changes state', () => {
  const before = engine.weather;
  (engine as any).weatherTimer = 0.001;
  for (let i = 0; i < 5; i++) engine.step(0.016);
  console.log(`     weather ${before} -> ${engine.weather}, rain=${(engine as any).rainIntensity.toFixed(2)}`);
});

console.log('\nLOOP TEST RESULTS');
console.log(results.join('\n'));
const failed = results.filter((r) => r.includes('❌')).length;
console.log(failed ? `\n${failed} FAILURES` : '\nALL PASSED');
process.exit(failed ? 1 : 0);
