#!/usr/bin/env bash
# Build the Ridgeline Android app.
#   ./scripts/build-android.sh            -> debug APK
#   ./scripts/build-android.sh --release  -> release APK (signing must be configured)
#   ./scripts/build-android.sh --bundle   -> release AAB for Google Play
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

MODE="debug"
if [[ "${1:-}" == "--release" ]]; then MODE="release"; fi
if [[ "${1:-}" == "--bundle" ]]; then MODE="bundle"; fi

echo "Ridgeline · Android build ($MODE)"

if ! command -v java >/dev/null 2>&1; then
  echo "✗ Java not found. Install JDK 21 (Android Studio bundles one) and retry."
  exit 1
fi

if [[ -z "${ANDROID_HOME:-}${ANDROID_SDK_ROOT:-}" ]] && [[ ! -f android/local.properties ]]; then
  echo "✗ Android SDK not found."
  echo "  Install Android Studio, then set ANDROID_HOME or create android/local.properties:"
  echo "  sdk.dir=/path/to/Android/Sdk"
  exit 1
fi

echo "→ Installing web dependencies"
npm install --no-audit --no-fund

echo "→ Building the web game"
npm run build

echo "→ Syncing the native project"
npx cap sync android

echo "→ Compiling with Gradle"
cd android
chmod +x gradlew
case "$MODE" in
  debug)   ./gradlew assembleDebug ;;
  release) ./gradlew assembleRelease ;;
  bundle)  ./gradlew bundleRelease ;;
esac
cd "$ROOT"

if [[ "$MODE" == "debug" ]]; then
  APK="android/app/build/outputs/apk/debug/app-debug.apk"
  cp "$APK" "./ridgeline-debug.apk"
  echo ""
  echo "✓ APK ready: $ROOT/ridgeline-debug.apk"
  echo "  Install on a USB device: adb install -r ridgeline-debug.apk"
else
  echo ""
  echo "✓ Build complete. Outputs:"
  echo "  android/app/build/outputs/apk/release/"
  echo "  android/app/build/outputs/bundle/release/"
fi
