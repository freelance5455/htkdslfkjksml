import fs from 'fs';
import { normalizeArabicString } from '../src/engine/normalization';
import { validateCrosswordLayout } from '../src/engine/CrosswordValidator';
import { CrosswordLayout, CrosswordLayoutWord, CrosswordLayoutCell, LayoutCellCoordinate, CrosswordLayoutClue } from '../src/types/crosswordLayout';

function cleanWord(str: string): string {
  return normalizeArabicString(str.replace(/\s+/g, ''));
}

const rawQuestions = [
  { id: 'q_01', clue: 'ما اسم المدينة التي كانت عاصمة الدولة العباسية؟', answer: 'بغداد' },
  { id: 'q_02', clue: 'ما أطول نهر في قارة أوروبا؟', answer: 'الفولغا' },
  { id: 'q_03', clue: 'ما العنصر الكيميائي الذي رمزه O؟', answer: 'الأكسجين' },
  { id: 'q_04', clue: 'ما العضو المسؤول بشكل رئيسي عن ضخ الدم إلى أنحاء الجسم؟', answer: 'القلب' },
  { id: 'q_05', clue: 'ما الكوكب المعروف بالكوكب الأحمر؟', answer: 'المريخ' },
  { id: 'q_06', clue: 'من الشاعر الملقب بشاعر النيل؟ (الاسم الأول)', answer: 'حافظ' },
  { id: 'q_07', clue: 'ما علامة رفع المثنى؟', answer: 'الألف' },
  { id: 'q_08', clue: 'ما اسم أقدم ملحمة أدبية معروفة في التاريخ؟', answer: 'جلجامش' },
  { id: 'q_09', clue: 'ما السورة التي تُسمى أم الكتاب؟', answer: 'الفاتحة' },
  { id: 'q_10', clue: 'من العالم الذي ارتبط اختراعه بالمصباح الكهربائي المتوهج تجاريًا؟', answer: 'إديسون' },
  { id: 'q_11', clue: 'ما اسم الآلة الموسيقية الوترية العربية التي تشتهر برقبتها الطويلة؟', answer: 'البزق' },
  { id: 'q_12', clue: 'كم عدد اللاعبين الأساسيين في فريق كرة القدم داخل الملعب؟', answer: 'أحد عشر' },
  { id: 'q_13', clue: 'ما أكبر حيوان معروف على سطح الأرض؟', answer: 'الحوت' },
  { id: 'q_14', clue: 'ما عاصمة اليابان؟', answer: 'طوكيو' },
  { id: 'q_15', clue: 'من العالم المسلم الذي اشتهر بكتابه "القانون في الطب"؟', answer: 'ابن سينا' },
  { id: 'q_16', clue: 'ما المدينة التي تُعرف بلقب مدينة الألف مئذنة؟', answer: 'القاهرة' },
  { id: 'q_17', clue: 'ما المصطلح الذي يطلق على الارتفاع العام والمستمر في أسعار السلع والخدمات؟', answer: 'التضخم' },
  { id: 'q_18', clue: 'ما الاسم الذي يطلق على النص المكتوب الذي يصف أحداث الفيلم ومشاهده وحواراته؟', answer: 'السيناريو' },
  { id: 'q_19', clue: 'ما الفيلسوف اليوناني صاحب التجربة الفكرية الشهيرة (عالم الظلال والكهف)؟', answer: 'أفلاطون' },
  { id: 'q_20', clue: 'ما اسم السنة التي يكون فيها شهر فبراير 29 يومًا؟', answer: 'كبيسة' },
  { id: 'q_21', clue: 'ما الوحدة الأساسية لقياس شدة التيار الكهربائي؟', answer: 'الأمبير' },
  { id: 'q_22', clue: 'ما اسم المعاهدة التي أنهت حرب الثلاثين عامًا في أوروبا عام 1648؟', answer: 'وستفاليا' },
  { id: 'q_23', clue: 'ما اسم النظام الكتابي الذي اشتهر به السومريون؟', answer: 'المسمارية' },
  { id: 'q_24', clue: 'ما الجهاز الذي يحوّل الطاقة الكهربائية إلى ضوء؟', answer: 'المصباح' },
  { id: 'q_25', clue: 'ما العدد الذي يمثل مجموع المحيطات الكبرى على سطح الأرض؟', answer: 'خمسة' },
];

const words = rawQuestions.map(q => ({
  id: q.id,
  clue: q.clue,
  answer: q.answer,
  norm: cleanWord(q.answer),
  len: cleanWord(q.answer).length
}));

const GRID_SIZE = 15;
const grid: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
const cellDirs: Set<Dir>[][] = Array.from({ length: GRID_SIZE }, () => Array.from({ length: GRID_SIZE }, () => new Set<Dir>()));

type Dir = 'across' | 'down';

function canFit(w: any, dir: Dir, r: number, c: number, placedCount: number): boolean {
  const len = w.len;
  if (dir === 'across') {
    if (c + len > GRID_SIZE || r < 0 || r >= GRID_SIZE || c < 0) return false;
    if (c > 0 && grid[r][c - 1] !== null) return false;
    if (c + len < GRID_SIZE && grid[r][c + len] !== null) return false;

    let touches = placedCount === 0;
    for (let k = 0; k < len; k++) {
      const cur = grid[r][c + k];
      if (cur !== null) {
        if (cur !== w.norm[k]) return false;
        if (cellDirs[r][c + k].has('across')) return false;
        touches = true;
      } else {
        if (r > 0 && grid[r - 1][c + k] !== null && !cellDirs[r - 1][c + k].has('down')) return false;
        if (r < GRID_SIZE - 1 && grid[r + 1][c + k] !== null && !cellDirs[r + 1][c + k].has('down')) return false;
      }
    }
    return touches;
  } else {
    if (r + len > GRID_SIZE || c < 0 || c >= GRID_SIZE || r < 0) return false;
    if (r > 0 && grid[r - 1][c] !== null) return false;
    if (r + len < GRID_SIZE && grid[r + len][c] !== null) return false;

    let touches = placedCount === 0;
    for (let k = 0; k < len; k++) {
      const cur = grid[r + k][c];
      if (cur !== null) {
        if (cur !== w.norm[k]) return false;
        if (cellDirs[r + k][c].has('down')) return false;
        touches = true;
      } else {
        if (c > 0 && grid[r + k][c - 1] !== null && !cellDirs[r + k][c - 1].has('across')) return false;
        if (c < GRID_SIZE - 1 && grid[r + k][c + 1] !== null && !cellDirs[r + k][c + 1].has('across')) return false;
      }
    }
    return touches;
  }
}

let placed: any[] = [];
let maxP = 0;

function backtrack(unplaced: any[], depth: number): any[] | null {
  if (placed.length > maxP) {
    maxP = placed.length;
    console.log(`Placed: ${maxP}/25`);
  }
  if (unplaced.length === 0) return [...placed];
  if (depth > 50000) return null;

  const options: any[] = [];
  for (const w of unplaced) {
    const valid: any[] = [];
    for (const dir of ['across', 'down'] as Dir[]) {
      for (let r = 0; r < GRID_SIZE; r++) {
        for (let c = 0; c < GRID_SIZE; c++) {
          if (canFit(w, dir, r, c, placed.length)) {
            let inters = 0;
            for (let k = 0; k < w.len; k++) {
              const cr = dir === 'down' ? r + k : r;
              const cc = dir === 'across' ? c + k : c;
              if (grid[cr][cc] !== null) inters++;
            }
            const midR = dir === 'down' ? r + w.len / 2 : r;
            const midC = dir === 'across' ? c + w.len / 2 : c;
            const dist = Math.abs(midR - GRID_SIZE/2) + Math.abs(midC - GRID_SIZE/2);
            valid.push({ dir, r, c, inters, score: inters * 10 - dist + Math.random() * 2 });
          }
        }
      }
    }
    if (valid.length > 0) {
      options.push({ word: w, placements: valid });
    }
  }

  if (options.length === 0) return null;

  options.sort((a, b) => a.placements.length - b.placements.length);
  const chosen = options[0];
  chosen.placements.sort((a: any, b: any) => b.score - a.score);

  const nextUnplaced = unplaced.filter(w => w.id !== chosen.word.id);

  for (const pl of chosen.placements) {
    const changes: any[] = [];
    for (let k = 0; k < chosen.word.len; k++) {
      const cr = pl.dir === 'down' ? pl.r + k : pl.r;
      const cc = pl.dir === 'across' ? pl.c + k : pl.c;
      const wasNull = grid[cr][cc] === null;
      grid[cr][cc] = chosen.word.norm[k];
      cellDirs[cr][cc].add(pl.dir);
      changes.push({ r: cr, c: cc, wasNull });
    }

    placed.push({ word: chosen.word, dir: pl.dir, r: pl.r, c: pl.c });
    const res = backtrack(nextUnplaced, depth + 1);
    if (res) return res;

    placed.pop();
    for (const ch of changes) {
      cellDirs[ch.r][ch.c].delete(pl.dir);
      if (ch.wasNull) grid[ch.r][ch.c] = null;
    }
  }
  return null;
}

// Let's run a multi-root search
let solvedLayout: any[] | null = null;
const roots = [...words].sort((a, b) => b.len - a.len);

for (const root of roots.slice(0, 10)) {
  console.log(`Trying root: ${root.answer}`);
  for (const dir of ['across', 'down'] as Dir[]) {
    placed = [];
    maxP = 0;
    for (let r = 0; r < GRID_SIZE; r++) {
      for (let c = 0; c < GRID_SIZE; c++) {
        grid[r][c] = null;
        cellDirs[r][c].clear();
      }
    }
    const rootR = dir === 'across' ? 7 : Math.floor((GRID_SIZE - root.len) / 2);
    const rootC = dir === 'down' ? 7 : Math.floor((GRID_SIZE - root.len) / 2);

    for (let k = 0; k < root.len; k++) {
      const cr = dir === 'down' ? rootR + k : rootR;
      const cc = dir === 'across' ? rootC + k : rootC;
      grid[cr][cc] = root.norm[k];
      cellDirs[cr][cc].add(dir);
    }
    placed.push({ word: root, dir, r: rootR, c: rootC });

    solvedLayout = backtrack(words.filter(w => w.id !== root.id), 0);
    if (solvedLayout) break;
  }
  if (solvedLayout) break;
}

if (solvedLayout) {
  console.log('SUCCESS! ALL 25 WORDS PLACED PERFECTLY!');
  
  const gridChars: (string | null)[][] = Array.from({ length: 15 }, () => Array(15).fill(null));
  solvedLayout.forEach(p => {
    for (let k = 0; k < p.word.len; k++) {
      const cr = p.dir === 'down' ? p.r + k : p.r;
      const cc = p.dir === 'across' ? p.c + k : p.c;
      gridChars[cr][cc] = p.word.norm[k];
    }
  });

  const cells: CrosswordLayoutCell[] = [];
  const blackCells: LayoutCellCoordinate[] = [];

  for (let r = 0; r < 15; r++) {
    for (let c = 0; c < 15; c++) {
      const char = gridChars[r][c];
      if (char === null) {
        blackCells.push({ row: r, col: c });
        cells.push({ row: r, column: c, isBlocked: true, letter: '' });
      } else {
        const acrossW = solvedLayout.find(p => p.dir === 'across' && p.r === r && c >= p.c && c < p.c + p.word.len);
        const downW = solvedLayout.find(p => p.dir === 'down' && p.c === c && r >= p.r && r < p.r + p.word.len);
        cells.push({
          row: r,
          column: c,
          isBlocked: false,
          letter: char,
          acrossWordId: acrossW?.word.id,
          downWordId: downW?.word.id
        });
      }
    }
  }

  const layoutWords: CrosswordLayoutWord[] = solvedLayout.map(p => {
    const coords: LayoutCellCoordinate[] = [];
    for (let k = 0; k < p.word.len; k++) {
      coords.push({
        row: p.dir === 'down' ? p.r + k : p.r,
        col: p.dir === 'across' ? p.c + k : p.c
      });
    }

    return {
      id: p.word.id,
      clue: p.word.clue,
      answer: p.word.answer,
      normalizedAnswer: p.word.norm,
      direction: p.dir,
      startRow: p.r,
      startColumn: p.c,
      length: p.word.len,
      cells: coords,
      number: 1,
      reversed: false
    };
  });

  layoutWords.sort((a, b) => {
    if (a.startRow !== b.startRow) return a.startRow - b.startRow;
    return a.startColumn - b.startColumn;
  });

  layoutWords.forEach((w, idx) => {
    w.number = idx + 1;
    const cell = cells.find(c => c.row === w.startRow && c.column === w.startColumn);
    if (cell) {
      cell.clueNumber = w.number;
    }
  });

  const clues: CrosswordLayoutClue[] = layoutWords.map(w => ({
    id: w.id,
    number: w.number,
    direction: w.direction,
    clue: w.clue,
    answer: w.answer
  }));

  const layout: CrosswordLayout = {
    gridRows: 15,
    gridColumns: 15,
    cells,
    words: layoutWords,
    blackCells,
    clues,
    metadata: {
      totalWords: 25,
      placedWords: 25,
      intersectionsCount: 24,
      blackCellsCount: blackCells.length,
      generatedAt: new Date().toISOString()
    }
  };

  const validation = validateCrosswordLayout(layout);
  console.log('Validation results:', validation);

  fs.writeFileSync('./src/data/golden_stage_01.json', JSON.stringify(layout, null, 2));
  console.log('WROTE GOLDEN STAGE 01 SUCCESSFULLY!');
}
