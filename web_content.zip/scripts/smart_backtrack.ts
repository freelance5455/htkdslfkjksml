import fs from 'fs';
import { normalizeArabicString } from '../src/engine/normalization';
import { validateCrosswordLayout } from '../src/engine/CrosswordValidator';
import { CrosswordLayout, CrosswordLayoutWord, CrosswordLayoutCell, LayoutCellCoordinate, CrosswordLayoutClue } from '../src/types/crosswordLayout';

function cleanWord(str: string): string {
  return normalizeArabicString(str.replace(/\s+/g, ''));
}

const rawQuestions = [
  { id: 'q_01', clue: 'ما اسم المدينة التي كانت عاصمة الدولة العباسية؟', answer: 'بغداد' },
  { id: 'q_02', clue: 'ما أطول نهر في قارة أوروبا؟', answer: 'الفولغا' },
  { id: 'q_03', clue: 'ما العنصر الكيميائي الذي رمزه O؟', answer: 'الأكسجين' },
  { id: 'q_04', clue: 'ما العضو المسؤول بشكل رئيسي عن ضخ الدم إلى أنحاء الجسم؟', answer: 'القلب' },
  { id: 'q_05', clue: 'ما الكوكب المعروف بالكوكب الأحمر؟', answer: 'المريخ' },
  { id: 'q_06', clue: 'من الشاعر الملقب بشاعر النيل؟', answer: 'حافظ إبراهيم' },
  { id: 'q_07', clue: 'ما علامة رفع المثنى؟', answer: 'الألف' },
  { id: 'q_08', clue: 'ما اسم أقدم ملحمة أدبية معروفة في التاريخ؟', answer: 'جلجامش' },
  { id: 'q_09', clue: 'ما السورة التي تُسمى أم الكتاب؟', answer: 'الفاتحة' },
  { id: 'q_10', clue: 'من العالم الذي ارتبط اختراعه بالمصباح الكهربائي المتوهج تجاريًا؟', answer: 'إديسون' },
  { id: 'q_11', clue: 'ما اسم الآلة الموسيقية الوترية العربية التي تشتهر برقبتها الطويلة؟', answer: 'البزق' },
  { id: 'q_12', clue: 'كم عدد اللاعبين الأساسيين في فريق كرة القدم داخل الملعب؟', answer: 'أحد عشر' },
  { id: 'q_13', clue: 'ما أكبر حيوان معروف على سطح الأرض؟', answer: 'الحوت الأزرق' },
  { id: 'q_14', clue: 'ما عاصمة اليابان؟', answer: 'طوكيو' },
  { id: 'q_15', clue: 'من العالم المسلم الذي اشتهر بكتابه "القانون في الطب"؟', answer: 'ابن سينا' },
  { id: 'q_16', clue: 'ما المدينة التي تُعرف بلقب مدينة الألف مئذنة؟', answer: 'القاهرة' },
  { id: 'q_17', clue: 'ما المصطلح الذي يطلق على الارتفاع العام والمستمر في أسعار السلع والخدمات؟', answer: 'التضخم' },
  { id: 'q_18', clue: 'ما الاسم الذي يطلق على النص المكتوب الذي يصف أحداث الفيلم ومشاهده وحواراته؟', answer: 'السيناريو' },
  { id: 'q_19', clue: 'ما اسم التجربة الفكرية التي استخدمها أفلاطون لشرح انتقال الإنسان من عالم الظلال إلى معرفة الحقيقة؟', answer: 'كهف أفلاطون' },
  { id: 'q_20', clue: 'ما اسم السنة التي يكون فيها شهر فبراير 29 يومًا؟', answer: 'كبيسة' },
  { id: 'q_21', clue: 'ما الوحدة الأساسية لقياس شدة التيار الكهربائي؟', answer: 'الأمبير' },
  { id: 'q_22', clue: 'ما اسم المعاهدة التي أنهت حرب الثلاثين عامًا في أوروبا عام 1648؟', answer: 'وستفاليا' },
  { id: 'q_23', clue: 'ما اسم النظام الكتابي الذي اشتهر به السومريون؟', answer: 'المسمارية' },
  { id: 'q_24', clue: 'ما الجهاز الذي يحوّل الطاقة الكهربائية إلى ضوء؟', answer: 'المصباح' },
  { id: 'q_25', clue: 'ما العدد الذي يمثل مجموع المحيطات الكبرى على سطح الأرض؟', answer: 'خمسة' },
];

interface WordInfo {
  id: string;
  clue: string;
  answer: string;
  norm: string;
  len: number;
}

const words: WordInfo[] = rawQuestions.map(q => ({
  id: q.id,
  clue: q.clue,
  answer: q.answer,
  norm: cleanWord(q.answer),
  len: cleanWord(q.answer).length
}));

type Dir = 'across' | 'down';

interface Placement {
  word: WordInfo;
  dir: Dir;
  r: number;
  c: number;
}

const GRID_SIZE = 15;

function canFit(w: WordInfo, dir: Dir, r: number, c: number, grid: (string | null)[][], cellDirs: Set<Dir>[][], placedCount: number): { valid: boolean; inters: number } {
  const len = w.len;
  if (dir === 'across') {
    if (c + len > GRID_SIZE || r < 0 || r >= GRID_SIZE || c < 0) return { valid: false, inters: 0 };
    if (c > 0 && grid[r][c - 1] !== null) return { valid: false, inters: 0 };
    if (c + len < GRID_SIZE && grid[r][c + len] !== null) return { valid: false, inters: 0 };

    let touches = placedCount === 0;
    let inters = 0;

    for (let k = 0; k < len; k++) {
      const cur = grid[r][c + k];
      if (cur !== null) {
        if (cur !== w.norm[k]) return { valid: false, inters: 0 };
        if (cellDirs[r][c + k].has('across')) return { valid: false, inters: 0 };
        touches = true;
        inters++;
      } else {
        if (r > 0 && grid[r - 1][c + k] !== null && !cellDirs[r - 1][c + k].has('down')) return { valid: false, inters: 0 };
        if (r < GRID_SIZE - 1 && grid[r + 1][c + k] !== null && !cellDirs[r + 1][c + k].has('down')) return { valid: false, inters: 0 };
      }
    }
    return { valid: touches, inters };
  } else {
    if (r + len > GRID_SIZE || c < 0 || c >= GRID_SIZE || r < 0) return { valid: false, inters: 0 };
    if (r > 0 && grid[r - 1][c] !== null) return { valid: false, inters: 0 };
    if (r + len < GRID_SIZE && grid[r + len][c] !== null) return { valid: false, inters: 0 };

    let touches = placedCount === 0;
    let inters = 0;

    for (let k = 0; k < len; k++) {
      const cur = grid[r + k][c];
      if (cur !== null) {
        if (cur !== w.norm[k]) return { valid: false, inters: 0 };
        if (cellDirs[r + k][c].has('down')) return { valid: false, inters: 0 };
        touches = true;
        inters++;
      } else {
        if (c > 0 && grid[r + k][c - 1] !== null && !cellDirs[r + k][c - 1].has('across')) return { valid: false, inters: 0 };
        if (c < GRID_SIZE - 1 && grid[r + k][c + 1] !== null && !cellDirs[r + k][c + 1].has('across')) return { valid: false, inters: 0 };
      }
    }
    return { valid: touches, inters };
  }
}

function solveCrossword(): Placement[] | null {
  const grid: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
  const cellDirs: Set<Dir>[][] = Array.from({ length: GRID_SIZE }, () => Array.from({ length: GRID_SIZE }, () => new Set<Dir>()));

  let placed: Placement[] = [];
  let maxPlaced = 0;
  let attempts = 0;

  function backtrack(unplaced: WordInfo[]): Placement[] | null {
    attempts++;
    if (placed.length > maxPlaced) {
      maxPlaced = placed.length;
      console.log(`Placed: ${maxPlaced}/25 (attempts: ${attempts})`);
    }

    if (unplaced.length === 0) return [...placed];

    // Find valid options for all unplaced words that CAN be placed
    interface Option {
      word: WordInfo;
      placements: { dir: Dir; r: number; c: number; inters: number; score: number }[];
    }

    const options: Option[] = [];

    for (const w of unplaced) {
      const valid: { dir: Dir; r: number; c: number; inters: number; score: number }[] = [];
      for (const dir of ['across', 'down'] as Dir[]) {
        for (let r = 0; r < GRID_SIZE; r++) {
          for (let c = 0; c < GRID_SIZE; c++) {
            const res = canFit(w, dir, r, c, grid, cellDirs, placed.length);
            if (res.valid) {
              const midR = dir === 'down' ? r + w.len / 2 : r;
              const midC = dir === 'across' ? c + w.len / 2 : c;
              const dist = Math.abs(midR - 7) + Math.abs(midC - 7);
              const score = res.inters * 10 - dist * 0.5;
              valid.push({ dir, r, c, inters: res.inters, score });
            }
          }
        }
      }

      if (valid.length > 0) {
        options.push({ word: w, placements: valid });
      }
    }

    if (options.length === 0) return null; // No remaining word can connect

    // Pick the word with the fewest valid placements (MRV among connected words)
    options.sort((a, b) => a.placements.length - b.placements.length);

    const chosen = options[0];
    const nextUnplaced = unplaced.filter(w => w.id !== chosen.word.id);

    // Sort placements by highest score
    chosen.placements.sort((a, b) => b.score - a.score);

    for (const pl of chosen.placements) {
      const changes: { r: number; c: number; wasNull: boolean }[] = [];
      for (let k = 0; k < chosen.word.len; k++) {
        const cr = pl.dir === 'down' ? pl.r + k : pl.r;
        const cc = pl.dir === 'across' ? pl.c + k : pl.c;
        const wasNull = grid[cr][cc] === null;
        grid[cr][cc] = chosen.word.norm[k];
        cellDirs[cr][cc].add(pl.dir);
        changes.push({ r: cr, c: cc, wasNull });
      }

      placed.push({ word: chosen.word, dir: pl.dir, r: pl.r, c: pl.c });

      const res = backtrack(nextUnplaced);
      if (res) return res;

      placed.pop();
      for (const ch of changes) {
        cellDirs[ch.r][ch.c].delete(pl.dir);
        if (ch.wasNull) grid[ch.r][ch.c] = null;
      }
    }

    return null;
  }

  // Try several initial roots and positions
  const roots = [...words].sort((a, b) => b.len - a.len);

  for (const root of roots) {
    console.log(`Starting with root: ${root.answer} (${root.norm})`);
    for (const dir of ['across', 'down'] as Dir[]) {
      for (let pos = 2; pos <= 7; pos++) {
        placed = [];
        attempts = 0;
        for (let r = 0; r < GRID_SIZE; r++) {
          for (let c = 0; c < GRID_SIZE; c++) {
            grid[r][c] = null;
            cellDirs[r][c].clear();
          }
        }

        const startR = dir === 'across' ? pos : Math.floor((GRID_SIZE - root.len) / 2);
        const startC = dir === 'down' ? pos : Math.floor((GRID_SIZE - root.len) / 2);

        for (let k = 0; k < root.len; k++) {
          const cr = dir === 'down' ? startR + k : startR;
          const cc = dir === 'across' ? startC + k : startC;
          grid[cr][cc] = root.norm[k];
          cellDirs[cr][cc].add(dir);
        }
        placed.push({ word: root, dir, r: startR, c: startC });

        const res = backtrack(words.filter(w => w.id !== root.id));
        if (res) return res;
      }
    }
  }

  return null;
}

const solved = solveCrossword();
if (solved) {
  console.log('SUCCESS! ALL 25 WORDS PLACED!');
  const gridChars: (string | null)[][] = Array.from({ length: 15 }, () => Array(15).fill(null));
  solved.forEach(p => {
    for (let k = 0; k < p.word.len; k++) {
      const cr = p.dir === 'down' ? p.r + k : p.r;
      const cc = p.dir === 'across' ? p.c + k : p.c;
      gridChars[cr][cc] = p.word.norm[k];
    }
  });

  const cells: CrosswordLayoutCell[] = [];
  const blackCells: LayoutCellCoordinate[] = [];

  for (let r = 0; r < 15; r++) {
    for (let c = 0; c < 15; c++) {
      const char = gridChars[r][c];
      if (char === null) {
        blackCells.push({ row: r, col: c });
        cells.push({ row: r, column: c, isBlocked: true, letter: '' });
      } else {
        const acrossW = solved.find(p => p.dir === 'across' && p.r === r && c >= p.c && c < p.c + p.word.len);
        const downW = solved.find(p => p.dir === 'down' && p.c === c && r >= p.r && r < p.r + p.word.len);
        cells.push({
          row: r,
          column: c,
          isBlocked: false,
          letter: char,
          acrossWordId: acrossW?.word.id,
          downWordId: downW?.word.id
        });
      }
    }
  }

  const layoutWords: CrosswordLayoutWord[] = solved.map(p => {
    const coords: LayoutCellCoordinate[] = [];
    for (let k = 0; k < p.word.len; k++) {
      coords.push({
        row: p.dir === 'down' ? p.r + k : p.r,
        col: p.dir === 'across' ? p.c + k : p.c
      });
    }

    return {
      id: p.word.id,
      clue: p.word.clue,
      answer: p.word.answer,
      normalizedAnswer: p.word.norm,
      direction: p.dir,
      startRow: p.r,
      startColumn: p.c,
      length: p.word.len,
      cells: coords,
      number: 1,
      reversed: false
    };
  });

  layoutWords.sort((a, b) => {
    if (a.startRow !== b.startRow) return a.startRow - b.startRow;
    return a.startColumn - b.startColumn;
  });

  layoutWords.forEach((w, idx) => {
    w.number = idx + 1;
    const cell = cells.find(c => c.row === w.startRow && c.column === w.startColumn);
    if (cell) {
      cell.clueNumber = w.number;
    }
  });

  const clues: CrosswordLayoutClue[] = layoutWords.map(w => ({
    id: w.id,
    number: w.number,
    direction: w.direction,
    clue: w.clue,
    answer: w.answer
  }));

  const layout: CrosswordLayout = {
    gridRows: 15,
    gridColumns: 15,
    cells,
    words: layoutWords,
    blackCells,
    clues,
    metadata: {
      totalWords: 25,
      placedWords: 25,
      intersectionsCount: 24,
      blackCellsCount: blackCells.length,
      generatedAt: new Date().toISOString()
    }
  };

  const validation = validateCrosswordLayout(layout);
  console.log('Validation results:', validation);

  fs.writeFileSync('./src/data/golden_stage_01.json', JSON.stringify(layout, null, 2));
  console.log('SAVED TO golden_stage_01.json SUCCESSFULLY!');
} else {
  console.log('Solver completed without finding 25/25 on 15x15.');
}
