import { execSync } from 'child_process';
import path from 'path';

const ROOT_DIR = process.cwd();
const buildScript = path.join(ROOT_DIR, 'scripts', 'build-android-apk.sh');

console.log('🚀 Executing Android APK native build & signature pipeline...');
try {
  execSync(`bash "${buildScript}"`, { stdio: 'inherit' });
} catch (error) {
  console.error('❌ Failed to execute build-android-apk.sh:', error);
  process.exit(1);
}
