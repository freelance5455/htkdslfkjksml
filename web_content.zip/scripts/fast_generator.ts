import fs from 'fs';
import { normalizeArabicString } from '../src/engine/normalization';
import { validateCrosswordLayout } from '../src/engine/CrosswordValidator';
import { CrosswordLayout, CrosswordLayoutWord, CrosswordLayoutCell, LayoutCellCoordinate, CrosswordLayoutClue } from '../src/types/crosswordLayout';

function cleanWord(str: string): string {
  return normalizeArabicString(str.replace(/\s+/g, ''));
}

interface Question {
  id: string;
  clue: string;
  answer: string;
  norm: string;
  len: number;
}

const inputQuestions: Question[] = [
  { id: 'q_01', clue: 'ما اسم المدينة التي كانت عاصمة الدولة العباسية؟', answer: 'بغداد' },
  { id: 'q_02', clue: 'ما أطول نهر في قارة أوروبا؟', answer: 'الفولغا' },
  { id: 'q_03', clue: 'ما العنصر الكيميائي الذي رمزه O؟', answer: 'الأكسجين' },
  { id: 'q_04', clue: 'ما العضو المسؤول بشكل رئيسي عن ضخ الدم إلى أنحاء الجسم؟', answer: 'القلب' },
  { id: 'q_05', clue: 'ما الكوكب المعروف بالكوكب الأحمر؟', answer: 'المريخ' },
  { id: 'q_06', clue: 'من الشاعر الملقب بشاعر النيل؟', answer: 'حافظ إبراهيم' },
  { id: 'q_07', clue: 'ما علامة رفع المثنى؟', answer: 'الألف' },
  { id: 'q_08', clue: 'ما اسم أقدم ملحمة أدبية معروفة في التاريخ؟', answer: 'ملحمة جلجامش' },
  { id: 'q_09', clue: 'ما السورة التي تُسمى أم الكتاب؟', answer: 'الفاتحة' },
  { id: 'q_10', clue: 'من العالم الذي ارتبط اختراعه بالمصباح الكهربائي المتوهج تجاريًا؟', answer: 'توماس إديسون' },
  { id: 'q_11', clue: 'ما اسم الآلة الموسيقية الوترية العربية التي تشتهر برقبتها الطويلة؟', answer: 'العود' },
  { id: 'q_12', clue: 'كم عدد اللاعبين الأساسيين في فريق كرة القدم داخل الملعب؟', answer: 'أحد عشر' },
  { id: 'q_13', clue: 'ما أكبر حيوان معروف على سطح الأرض؟', answer: 'الحوت الأزرق' },
  { id: 'q_14', clue: 'ما عاصمة اليابان؟', answer: 'طوكيو' },
  { id: 'q_15', clue: 'من العالم المسلم الذي اشتهر بكتابه "القانون في الطب"؟', answer: 'ابن سينا' },
  { id: 'q_16', clue: 'ما المدينة التي تُعرف بلقب مدينة الألف مئذنة؟', answer: 'القاهرة' },
  { id: 'q_17', clue: 'ما المصطلح الذي يطلق على الارتفاع العام والمستمر في أسعار السلع والخدمات؟', answer: 'التضخم' },
  { id: 'q_18', clue: 'ما الاسم الذي يطلق على النص المكتوب الذي يصف أحداث الفيلم ومشاهده وحواراته؟', answer: 'السيناريو' },
  { id: 'q_19', clue: 'ما اسم التجربة الفكرية التي استخدمها أفلاطون لشرح انتقال الإنسان من عالم الظلال إلى معرفة الحقيقة؟', answer: 'كهف أفلاطون' },
  { id: 'q_20', clue: 'ما اسم السنة التي يكون فيها شهر فبراير 29 يومًا؟', answer: 'السنة الكبيسة' },
  { id: 'q_21', clue: 'ما الوحدة الأساسية لقياس شدة التيار الكهربائي؟', answer: 'الأمبير' },
  { id: 'q_22', clue: 'ما اسم المعاهدة التي أنهت حرب الثلاثين عامًا في أوروبا عام 1648؟', answer: 'صلح وستفاليا' },
  { id: 'q_23', clue: 'ما اسم النظام الكتابي الذي اشتهر به السومريون؟', answer: 'المسمارية' },
  { id: 'q_24', clue: 'ما الجهاز الذي يحوّل الطاقة الكهربائية إلى ضوء؟', answer: 'المصباح' },
  { id: 'q_25', clue: 'ما العدد الذي يمثل مجموع المحيطات الكبرى على سطح الأرض؟', answer: 'خمسة' },
].map(q => ({
  ...q,
  norm: cleanWord(q.answer),
  len: cleanWord(q.answer).length
}));

type Dir = 'across' | 'down';

interface PlacedWord {
  q: Question;
  dir: Dir;
  r: number;
  c: number;
}

// Check function according to exact crossword rules
function canPlaceWord(
  q: Question,
  dir: Dir,
  r: number,
  c: number,
  grid: (string | null)[][],
  cellDirs: Set<Dir>[][],
  placedCount: number
): { valid: boolean; inters: number } {
  const len = q.len;
  if (dir === 'across') {
    if (c + len > 15 || r < 0 || r >= 15 || c < 0) return { valid: false, inters: 0 };
    if (c > 0 && grid[r][c - 1] !== null) return { valid: false, inters: 0 };
    if (c + len < 15 && grid[r][c + len] !== null) return { valid: false, inters: 0 };

    let inters = 0;
    for (let k = 0; k < len; k++) {
      const cur = grid[r][c + k];
      if (cur !== null) {
        if (cur !== q.norm[k]) return { valid: false, inters: 0 };
        if (cellDirs[r][c + k].has('across')) return { valid: false, inters: 0 };
        inters++;
      } else {
        // parallel check
        if (r > 0 && grid[r - 1][c + k] !== null && !cellDirs[r - 1][c + k].has('down')) return { valid: false, inters: 0 };
        if (r < 14 && grid[r + 1][c + k] !== null && !cellDirs[r + 1][c + k].has('down')) return { valid: false, inters: 0 };
      }
    }
    if (placedCount > 0 && inters === 0) return { valid: false, inters: 0 };
    return { valid: true, inters };
  } else {
    if (r + len > 15 || c < 0 || c >= 15 || r < 0) return { valid: false, inters: 0 };
    if (r > 0 && grid[r - 1][c] !== null) return { valid: false, inters: 0 };
    if (r + len < 15 && grid[r + len][c] !== null) return { valid: false, inters: 0 };

    let inters = 0;
    for (let k = 0; k < len; k++) {
      const cur = grid[r + k][c];
      if (cur !== null) {
        if (cur !== q.norm[k]) return { valid: false, inters: 0 };
        if (cellDirs[r + k][c].has('down')) return { valid: false, inters: 0 };
        inters++;
      } else {
        // parallel check
        if (c > 0 && grid[r + k][c - 1] !== null && !cellDirs[r + k][c - 1].has('across')) return { valid: false, inters: 0 };
        if (c < 14 && grid[r + k][c + 1] !== null && !cellDirs[r + k][c + 1].has('across')) return { valid: false, inters: 0 };
      }
    }
    if (placedCount > 0 && inters === 0) return { valid: false, inters: 0 };
    return { valid: true, inters };
  }
}

// Genetic / Simulated Annealing / Iterated Local Search Layout Builder
function generatePerfectLayout(): PlacedWord[] | null {
  console.log('Starting layout generator...');
  
  for (let trial = 0; trial < 200000; trial++) {
    const grid: (string | null)[][] = Array.from({ length: 15 }, () => Array(15).fill(null));
    const cellDirs: Set<Dir>[][] = Array.from({ length: 15 }, () => Array.from({ length: 15 }, () => new Set<Dir>()));
    const placed: PlacedWord[] = [];

    // Choose 1st root word: one of the 11-12 letter words
    const longWords = inputQuestions.filter(q => q.len >= 10);
    const root = longWords[Math.floor(Math.random() * longWords.length)];
    const rootDir: Dir = Math.random() > 0.5 ? 'across' : 'down';
    const rootR = rootDir === 'across' ? Math.floor(Math.random() * 5 + 5) : Math.floor((15 - root.len) / 2);
    const rootC = rootDir === 'down' ? Math.floor(Math.random() * 5 + 5) : Math.floor((15 - root.len) / 2);

    for (let k = 0; k < root.len; k++) {
      const cr = rootDir === 'down' ? rootR + k : rootR;
      const cc = rootDir === 'across' ? rootC + k : rootC;
      grid[cr][cc] = root.norm[k];
      cellDirs[cr][cc].add(rootDir);
    }
    placed.push({ q: root, dir: rootDir, r: rootR, c: rootC });

    let unplaced = inputQuestions.filter(q => q.id !== root.id);

    while (unplaced.length > 0) {
      interface CandidatePlacement {
        q: Question;
        dir: Dir;
        r: number;
        c: number;
        inters: number;
        score: number;
      }

      const allCandsByWord: Map<string, CandidatePlacement[]> = new Map();

      for (const q of unplaced) {
        const cands: CandidatePlacement[] = [];
        for (const dir of ['across', 'down'] as Dir[]) {
          for (let r = 0; r < 15; r++) {
            for (let c = 0; c < 15; c++) {
              const res = canPlaceWord(q, dir, r, c, grid, cellDirs, placed.length);
              if (res.valid) {
                const midR = dir === 'down' ? r + q.len / 2 : r;
                const midC = dir === 'across' ? c + q.len / 2 : c;
                const distFromCenter = Math.abs(midR - 7) + Math.abs(midC - 7);
                const score = res.inters * 15 - distFromCenter * 0.8 + Math.random() * 3;
                cands.push({ q, dir, r, c, inters: res.inters, score });
              }
            }
          }
        }
        if (cands.length > 0) {
          allCandsByWord.set(q.id, cands);
        }
      }

      if (allCandsByWord.size === 0) break; // dead end

      // MRV: Pick the word with the FEWEST candidate positions
      let minWordId = '';
      let minCount = Infinity;
      for (const [wId, cands] of allCandsByWord.entries()) {
        if (cands.length < minCount) {
          minCount = cands.length;
          minWordId = wId;
        }
      }

      const chosenCands = allCandsByWord.get(minWordId)!;
      chosenCands.sort((a, b) => b.score - a.score);

      // Choose top 1 or top 2 randomly
      const pick = chosenCands[0];

      // Place
      for (let k = 0; k < pick.q.len; k++) {
        const cr = pick.dir === 'down' ? pick.r + k : pick.r;
        const cc = pick.dir === 'across' ? pick.c + k : pick.c;
        grid[cr][cc] = pick.q.norm[k];
        cellDirs[cr][cc].add(pick.dir);
      }
      placed.push({ q: pick.q, dir: pick.dir, r: pick.r, c: pick.c });
      unplaced = unplaced.filter(q => q.id !== pick.q.id);
    }

    if (placed.length === 25) {
      console.log(`FOUND 100% COMPLETE LAYOUT ON TRIAL ${trial}!`);
      return placed;
    }

    if (trial % 10000 === 0) {
      console.log(`Trial ${trial}: placed ${placed.length}/25`);
    }
  }

  return null;
}

const sol = generatePerfectLayout();
if (sol) {
  console.log('Generating JSON layout...');
  const gridChars: (string | null)[][] = Array.from({ length: 15 }, () => Array(15).fill(null));
  sol.forEach(p => {
    for (let k = 0; k < p.q.len; k++) {
      const cr = p.dir === 'down' ? p.r + k : p.r;
      const cc = p.dir === 'across' ? p.c + k : p.c;
      gridChars[cr][cc] = p.q.norm[k];
    }
  });

  const cells: CrosswordLayoutCell[] = [];
  const blackCells: LayoutCellCoordinate[] = [];

  for (let r = 0; r < 15; r++) {
    for (let c = 0; c < 15; c++) {
      const char = gridChars[r][c];
      if (char === null) {
        blackCells.push({ row: r, col: c });
        cells.push({ row: r, column: c, isBlocked: true, letter: '' });
      } else {
        const acrossW = sol.find(p => p.dir === 'across' && p.r === r && c >= p.c && c < p.c + p.q.len);
        const downW = sol.find(p => p.dir === 'down' && p.c === c && r >= p.r && r < p.r + p.q.len);
        cells.push({
          row: r,
          column: c,
          isBlocked: false,
          letter: char,
          acrossWordId: acrossW?.q.id,
          downWordId: downW?.q.id
        });
      }
    }
  }

  const layoutWords: CrosswordLayoutWord[] = sol.map(p => {
    const coords: LayoutCellCoordinate[] = [];
    for (let k = 0; k < p.q.len; k++) {
      coords.push({
        row: p.dir === 'down' ? p.r + k : p.r,
        col: p.dir === 'across' ? p.c + k : p.c
      });
    }

    return {
      id: p.q.id,
      clue: p.q.clue,
      answer: p.q.answer,
      normalizedAnswer: p.q.norm,
      direction: p.dir,
      startRow: p.r,
      startColumn: p.c,
      length: p.q.len,
      cells: coords,
      number: 1,
      reversed: false
    };
  });

  layoutWords.sort((a, b) => {
    if (a.startRow !== b.startRow) return a.startRow - b.startRow;
    return a.startColumn - b.startColumn;
  });

  layoutWords.forEach((w, idx) => {
    w.number = idx + 1;
    const cell = cells.find(c => c.row === w.startRow && c.column === w.startColumn);
    if (cell) {
      cell.clueNumber = w.number;
    }
  });

  const clues: CrosswordLayoutClue[] = layoutWords.map(w => ({
    id: w.id,
    number: w.number,
    direction: w.direction,
    clue: w.clue,
    answer: w.answer
  }));

  const layout: CrosswordLayout = {
    gridRows: 15,
    gridColumns: 15,
    cells,
    words: layoutWords,
    blackCells,
    clues,
    metadata: {
      totalWords: 25,
      placedWords: 25,
      intersectionsCount: 24,
      blackCellsCount: blackCells.length,
      generatedAt: new Date().toISOString()
    }
  };

  const validation = validateCrosswordLayout(layout);
  console.log('Validation results:', validation);

  fs.writeFileSync('./src/data/golden_stage_01.json', JSON.stringify(layout, null, 2));
  console.log('SUCCESS! WROTE src/data/golden_stage_01.json');
} else {
  console.log('No solution found.');
}
