const C3 = self.C3;
self.C3_GetObjectRefTable = function () {
	return [
		C3.Plugins.Sprite,
		C3.Behaviors.EightDir,
		C3.Behaviors.scrollto,
		C3.Behaviors.bound,
		C3.Behaviors.Bullet,
		C3.Plugins.Touch,
		C3.Plugins.Mouse,
		C3.Behaviors.Pin,
		C3.Plugins.System.Cnds.OnLayoutStart,
		C3.Behaviors.Pin.Acts.PinByProperties,
		C3.Plugins.Touch.Cnds.OnTouchStart,
		C3.Plugins.Sprite.Acts.SetAngle,
		C3.Plugins.Sprite.Exps.X,
		C3.Plugins.Sprite.Exps.Y,
		C3.Plugins.Touch.Exps.X,
		C3.Plugins.Touch.Exps.Y,
		C3.Plugins.Sprite.Acts.SetPos,
		C3.Plugins.Sprite.Exps.Angle,
		C3.Plugins.Sprite.Acts.Spawn,
		C3.Plugins.System.Cnds.EveryTick,
		C3.Plugins.Mouse.Exps.X,
		C3.Plugins.Mouse.Exps.Y,
		C3.Plugins.System.Cnds.Compare,
		C3.Plugins.Sprite.Acts.SetFlipped,
		C3.Plugins.Sprite.Cnds.OnCollision,
		C3.Plugins.System.Acts.AddVar,
		C3.Plugins.System.Acts.Wait,
		C3.Plugins.Sprite.Acts.Destroy,
		C3.Plugins.System.Cnds.CompareVar
	];
};
self.C3_JsPropNameTable = [
	{"8Direções": 0},
	{CentrarEm: 0},
	{RestritoAoLayout: 0},
	{PEDRO: 0},
	{ARMA: 0},
	{Projétil: 0},
	{PROJETIL: 0},
	{Toque: 0},
	{Mouse: 0},
	{Fixar: 0},
	{BOCAARMA: 0},
	{PORCO: 0},
	{porcoDANOsheet: 0},
	{VIDAINIMIGO: 0}
];

self.InstanceType = {
	PEDRO: class extends self.ISpriteInstance {},
	ARMA: class extends self.ISpriteInstance {},
	PROJETIL: class extends self.ISpriteInstance {},
	Toque: class extends self.IInstance {},
	Mouse: class extends self.IInstance {},
	BOCAARMA: class extends self.ISpriteInstance {},
	PORCO: class extends self.ISpriteInstance {},
	porcoDANOsheet: class extends self.ISpriteInstance {}
}