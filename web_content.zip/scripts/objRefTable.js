const C3 = self.C3;
self.C3_GetObjectRefTable = function () {
	return [
		C3.Plugins.video
	];
};
self.C3_JsPropNameTable = [
	{Видео: 0}
];

self.InstanceType = {
	Видео: class extends self.IWorldInstance {}
}