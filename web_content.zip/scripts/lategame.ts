import { createInitialState, applyChoice, completeMission, checkRequirement, addItem } from "../src/game/engine";
import { MISSIONS } from "../src/game/data/missions";
import { AREA_DEFS } from "../src/game/data/areas";
import { writeFileSync } from "fs";

const state = createInitialState("Testador");
AREA_DEFS.forEach((d) => d.items.forEach((it: any) =>
  state.worldItems.push({ id: `${d.id}_${it.id}`, item: it.item, areaId: d.id, x: it.x, y: it.y })));

// joga as 32 primeiras missoes
for (const m of MISSIONS.slice(0, 32)) {
  state.currentMission = m.id; state.missionStep = 0;
  let nodeId = m.steps[0].kind === "dialogue" ? m.steps[0].node : "";
  let guard = 0;
  while (guard++ < 80) {
    const step = m.steps[state.missionStep];
    if (!step) { completeMission(state, m, false); break; }
    if (step.kind === "collect") { addItem(state, step.item, step.count); state.missionStep++; nodeId = m.steps[state.missionStep]?.kind === "dialogue" ? m.steps[state.missionStep].node : nodeId; continue; }
    if (step.kind === "visit") { state.player.areaId = step.areaId; state.missionStep++; nodeId = m.steps[state.missionStep]?.kind === "dialogue" ? m.steps[state.missionStep].node : nodeId; continue; }
    if (step.kind === "talk") { state.missionStep++; nodeId = m.steps[state.missionStep]?.kind === "dialogue" ? m.steps[state.missionStep].node : nodeId; continue; }
    const node = m.nodes[nodeId];
    if (!node) break;
    const ch = node.choices.find((c) => checkRequirement(state, c));
    if (!ch) break;
    const res = applyChoice(state, m, ch);
    if (res.completed) { completeMission(state, m, res.failed); break; }
    if (ch.next && m.nodes[ch.next]) { nodeId = ch.next; continue; }
    state.missionStep++;
    nodeId = m.steps[state.missionStep]?.kind === "dialogue" ? m.steps[state.missionStep].node : nodeId;
  }
}
// simula o jogador que JA pegou o diario antes da missao 33
addItem(state, "diario", 1);
state.player.areaId = "conselho";
state.player.x = 13; state.player.y = 12;
writeFileSync("/tmp/state32.json", JSON.stringify(state));
console.log("missoes:", state.completedMissions.length, "| atual:", state.currentMission, "| score:", state.score, "| diario no inventario:", state.inventory.find(i=>i.id==="diario")?.count);
