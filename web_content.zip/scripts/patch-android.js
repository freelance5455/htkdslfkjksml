#!/usr/bin/env node
/* Run right after `npx cap add android` (the npm scripts and the GitHub workflow do this for you).
   Installs the Detox icons, notification icon, 8am-reminder permissions, a portrait lock, a dark splash,
   and the Nudge (accessibility service, ball overlay, blocklist). Safe to run again. Needs nothing but Node.
   Pass --require-list to fail when the packed blocklist is missing (the GitHub build does this). */
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const droid = path.join(root, 'android');
const main = path.join(droid, 'app', 'src', 'main');
const res = path.join(main, 'res');
const manifestPath = path.join(main, 'AndroidManifest.xml');
const log = (...a) => console.log('[detox]', ...a);

if (!fs.existsSync(droid)) {
  console.error('[detox] There is no android/ folder yet. Run:  npx cap add android');
  process.exit(1);
}

function copyDir(src, dst) {
  fs.mkdirSync(dst, { recursive: true });
  for (const e of fs.readdirSync(src, { withFileTypes: true })) {
    const s = path.join(src, e.name), d = path.join(dst, e.name);
    if (e.isDirectory()) copyDir(s, d); else fs.copyFileSync(s, d);
  }
}
function step(name, fn) { try { fn(); log('ok  ', name); } catch (e) { log('skip', name, '-', e.message); } }

step('launcher + notification icons', () => {
  copyDir(path.join(root, 'resources', 'android', 'res'), res);
  const any = path.join(res, 'mipmap-anydpi-v26');
  fs.mkdirSync(any, { recursive: true });
  const xml = '<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n' +
    '    <background android:drawable="@color/ic_launcher_background"/>\n    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>\n</adaptive-icon>\n';
  fs.writeFileSync(path.join(any, 'ic_launcher.xml'), xml);
  fs.writeFileSync(path.join(any, 'ic_launcher_round.xml'), xml);
});

step('dark splash screen', () => {
  const splash = path.join(root, 'resources', 'android', 'splash.png');
  let n = 0;
  for (const d of fs.readdirSync(res)) {
    if (!d.startsWith('drawable')) continue;
    const f = path.join(res, d, 'splash.png');
    if (fs.existsSync(f)) { fs.copyFileSync(splash, f); n++; }
  }
  fs.writeFileSync(path.join(res, 'values', 'detox_colors.xml'),
    '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="detox_splash">#070B25</color>\n</resources>\n');
  const stylesPath = path.join(res, 'values', 'styles.xml');
  if (fs.existsSync(stylesPath)) {
    let s = fs.readFileSync(stylesPath, 'utf8');
    if (!s.includes('windowSplashScreenBackground') && /<style name="AppTheme\.NoActionBarLaunch"[^>]*Theme\.SplashScreen[^>]*>/.test(s)) {
      s = s.replace(/(<style name="AppTheme\.NoActionBarLaunch"[^>]*>)/, '$1\n        <item name="windowSplashScreenBackground">@color/detox_splash</item>');
      fs.writeFileSync(stylesPath, s);
    }
  }
  log('     splash images replaced:', n);
});

step('permissions + portrait lock', () => {
  let m = fs.readFileSync(manifestPath, 'utf8');
  const want = ['POST_NOTIFICATIONS', 'VIBRATE', 'USE_EXACT_ALARM', 'SCHEDULE_EXACT_ALARM', 'CAMERA'];
  const add = want.filter(p => !m.includes('android.permission.' + p))
    .map(p => '    <uses-permission android:name="android.permission.' + p + '" />').join('\n');
  if (add) m = m.replace(/<application\b/, add + '\n\n    <application');
  if (!m.includes('android.hardware.camera')) m = m.replace(/<application\b/, '<uses-feature android:name="android.hardware.camera" android:required="false" />\n\n    <application');
  if (!m.includes('screenOrientation')) m = m.replace(/<activity\b/, '<activity android:screenOrientation="portrait"');
  fs.writeFileSync(manifestPath, m);
});

step('nudge: Java code', () => {
  const appId = JSON.parse(fs.readFileSync(path.join(root, 'capacitor.config.json'), 'utf8')).appId;
  const pkgDir = path.join(main, 'java', ...appId.split('.'));
  fs.mkdirSync(pkgDir, { recursive: true });
  const src = path.join(root, 'native', 'android', 'java');
  for (const f of fs.readdirSync(src)) {
    const code = fs.readFileSync(path.join(src, f), 'utf8').replace(/^package app\.detox\.quit;/m, 'package ' + appId + ';');
    fs.writeFileSync(path.join(pkgDir, f), code);
  }
});

step('nudge: service settings and text', () => {
  copyDir(path.join(root, 'native', 'android', 'res'), res);
});

step('nudge: manifest', () => {
  let m = fs.readFileSync(manifestPath, 'utf8');
  if (!m.includes('NudgeService')) {
    const svc = [
      '        <service',
      '            android:name=".NudgeService"',
      '            android:exported="true"',
      '            android:label="Detox nudge"',
      '            android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE">',
      '            <intent-filter>',
      '                <action android:name="android.accessibilityservice.AccessibilityService" />',
      '            </intent-filter>',
      '            <meta-data',
      '                android:name="android.accessibilityservice"',
      '                android:resource="@xml/nudge_service" />',
      '        </service>',
      ''
    ].join('\n');
    m = m.replace(/<\/application>/, svc + '    </application>');
  }
  if (!m.includes('android:scheme="detox"')) {
    const link = [
      '            <intent-filter>',
      '                <action android:name="android.intent.action.VIEW" />',
      '                <category android:name="android.intent.category.DEFAULT" />',
      '                <category android:name="android.intent.category.BROWSABLE" />',
      '                <data android:scheme="detox" />',
      '            </intent-filter>',
      ''
    ].join('\n');
    m = m.replace(/<\/activity>/, link + '        </activity>');
  }
  fs.writeFileSync(manifestPath, m);
});

const listFile = path.join(root, 'resources', 'android', 'nudge', 'sites.bin');
if (fs.existsSync(listFile)) {
  step('nudge: blocklist (' + Math.round(fs.statSync(listFile).size / 8).toLocaleString() + ' sites)', () => {
    const dst = path.join(main, 'assets', 'nudge');
    fs.mkdirSync(dst, { recursive: true });
    fs.copyFileSync(listFile, path.join(dst, 'sites.bin'));
  });
} else if (process.argv.includes('--require-list')) {
  console.error('[detox] The blocklist is missing. Run:  node scripts/build-blocklist.js');
  process.exit(1);
} else {
  log('warn the blocklist is missing, so the nudge will start with no built-in sites. Run: node scripts/build-blocklist.js');
}

log('done. Build with:  cd android && ./gradlew assembleDebug');
