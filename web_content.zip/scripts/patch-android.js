#!/usr/bin/env node
/* Run right after `npx cap add android` (the npm scripts and the GitHub workflow do this for you).
   Installs the Detox icons, notification icon, 8am-reminder permissions, a portrait lock and a dark splash.
   Safe to run again. Needs nothing but Node. */
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const droid = path.join(root, 'android');
const main = path.join(droid, 'app', 'src', 'main');
const res = path.join(main, 'res');
const manifestPath = path.join(main, 'AndroidManifest.xml');
const log = (...a) => console.log('[detox]', ...a);

if (!fs.existsSync(droid)) {
  console.error('[detox] There is no android/ folder yet. Run:  npx cap add android');
  process.exit(1);
}

function copyDir(src, dst) {
  fs.mkdirSync(dst, { recursive: true });
  for (const e of fs.readdirSync(src, { withFileTypes: true })) {
    const s = path.join(src, e.name), d = path.join(dst, e.name);
    if (e.isDirectory()) copyDir(s, d); else fs.copyFileSync(s, d);
  }
}
function step(name, fn) { try { fn(); log('ok  ', name); } catch (e) { log('skip', name, '-', e.message); } }

step('launcher + notification icons', () => {
  copyDir(path.join(root, 'resources', 'android', 'res'), res);
  const any = path.join(res, 'mipmap-anydpi-v26');
  fs.mkdirSync(any, { recursive: true });
  const xml = '<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n' +
    '    <background android:drawable="@color/ic_launcher_background"/>\n    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>\n</adaptive-icon>\n';
  fs.writeFileSync(path.join(any, 'ic_launcher.xml'), xml);
  fs.writeFileSync(path.join(any, 'ic_launcher_round.xml'), xml);
});

step('dark splash screen', () => {
  const splash = path.join(root, 'resources', 'android', 'splash.png');
  let n = 0;
  for (const d of fs.readdirSync(res)) {
    if (!d.startsWith('drawable')) continue;
    const f = path.join(res, d, 'splash.png');
    if (fs.existsSync(f)) { fs.copyFileSync(splash, f); n++; }
  }
  fs.writeFileSync(path.join(res, 'values', 'detox_colors.xml'),
    '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="detox_splash">#070B25</color>\n</resources>\n');
  const stylesPath = path.join(res, 'values', 'styles.xml');
  if (fs.existsSync(stylesPath)) {
    let s = fs.readFileSync(stylesPath, 'utf8');
    if (!s.includes('windowSplashScreenBackground') && /<style name="AppTheme\.NoActionBarLaunch"[^>]*Theme\.SplashScreen[^>]*>/.test(s)) {
      s = s.replace(/(<style name="AppTheme\.NoActionBarLaunch"[^>]*>)/, '$1\n        <item name="windowSplashScreenBackground">@color/detox_splash</item>');
      fs.writeFileSync(stylesPath, s);
    }
  }
  log('     splash images replaced:', n);
});

step('permissions + portrait lock', () => {
  let m = fs.readFileSync(manifestPath, 'utf8');
  const want = ['POST_NOTIFICATIONS', 'VIBRATE', 'USE_EXACT_ALARM', 'SCHEDULE_EXACT_ALARM'];
  const add = want.filter(p => !m.includes('android.permission.' + p))
    .map(p => '    <uses-permission android:name="android.permission.' + p + '" />').join('\n');
  if (add) m = m.replace(/<application\b/, add + '\n\n    <application');
  if (!m.includes('screenOrientation')) m = m.replace(/<activity\b/, '<activity android:screenOrientation="portrait"');
  fs.writeFileSync(manifestPath, m);
});

log('done. Build with:  cd android && ./gradlew assembleDebug');
