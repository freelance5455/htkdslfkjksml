import puppeteer from "puppeteer";
import { createServer } from "node:http";
import { readFile } from "node:fs/promises";

const html = await readFile(new URL("../dist/index.html", import.meta.url));
const server = createServer((_req, res) => {
  res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
  res.end(html);
});
await new Promise((r) => server.listen(4174, r));

const browser = await puppeteer.launch({
  headless: true,
  args: [
    "--no-sandbox",
    "--disable-setuid-sandbox",
    "--use-gl=angle",
    "--use-angle=swiftshader",
    "--enable-unsafe-swiftshader",
    "--disable-dev-shm-usage",
  ],
});

const page = await browser.newPage();
await page.setViewport({ width: 640, height: 400, deviceScaleFactor: 1 });
const logs = [];
page.on("pageerror", (e) => logs.push(`PAGEERROR: ${e.message}`));
await page.goto("http://localhost:4174/", { waitUntil: "load", timeout: 60000 });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
await sleep(3000);

await page.evaluate(() => {
  const btn = [...document.querySelectorAll("button")].find((b) =>
    b.textContent.includes("شروع"),
  );
  btn?.click();
});

// let the countdown finish (software rendering is slow, so give it time)
await sleep(12000);

const state = await page.evaluate(() => {
  const w = window.__world;
  return {
    phase: w.phase,
    speed: w.speed,
    distance: w.distance,
    x: w.x,
    countdown: w.countdown,
    nitro: w.nitro,
    score: w.score,
  };
});
console.log("WORLD:", JSON.stringify(state));

await page.screenshot({
  path: "shots/zoom-1.png",
  clip: { x: 540, y: 300, width: 220, height: 180 },
});
await page.screenshot({
  path: "shots/zoom-2.png",
  clip: { x: 430, y: 430, width: 420, height: 260 },
});
await page.screenshot({ path: "shots/full-late.png" });

console.log(logs.join("\n") || "(no errors)");
await browser.close();
server.close();
