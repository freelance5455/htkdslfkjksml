import fs from 'fs';
import { normalizeArabicString } from '../src/engine/normalization';
import { validateCrosswordLayout } from '../src/engine/CrosswordValidator';
import { CrosswordLayout, CrosswordLayoutWord, CrosswordLayoutCell, LayoutCellCoordinate, CrosswordLayoutClue } from '../src/types/crosswordLayout';

function cleanWord(str: string): string {
  return normalizeArabicString(str.replace(/\s+/g, ''));
}

const rawQuestions = [
  { id: 'q_01', clue: 'ما اسم المدينة التي كانت عاصمة الدولة العباسية؟', answer: 'بغداد' },
  { id: 'q_02', clue: 'ما أطول نهر في قارة أوروبا؟', answer: 'الفولغا' },
  { id: 'q_03', clue: 'ما العنصر الكيميائي الذي رمزه O؟', answer: 'الأكسجين' },
  { id: 'q_04', clue: 'ما العضو المسؤول بشكل رئيسي عن ضخ الدم إلى أنحاء الجسم؟', answer: 'القلب' },
  { id: 'q_05', clue: 'ما الكوكب المعروف بالكوكب الأحمر؟', answer: 'المريخ' },
  { id: 'q_06', clue: 'من الشاعر الملقب بشاعر النيل؟', answer: 'حافظ إبراهيم' },
  { id: 'q_07', clue: 'ما علامة رفع المثنى؟', answer: 'الألف' },
  { id: 'q_08', clue: 'ما اسم أقدم ملحمة أدبية معروفة في التاريخ؟', answer: 'جلجامش' },
  { id: 'q_09', clue: 'ما السورة التي تُسمى أم الكتاب؟', answer: 'الفاتحة' },
  { id: 'q_10', clue: 'من العالم الذي ارتبط اختراعه بالمصباح الكهربائي المتوهج تجاريًا؟', answer: 'إديسون' },
  { id: 'q_11', clue: 'ما اسم الآلة الموسيقية الوترية العربية التي تشتهر برقبتها الطويلة؟', answer: 'البزق' },
  { id: 'q_12', clue: 'كم عدد اللاعبين الأساسيين في فريق كرة القدم داخل الملعب؟', answer: 'أحد عشر' },
  { id: 'q_13', clue: 'ما أكبر حيوان معروف على سطح الأرض؟', answer: 'الحوت الأزرق' },
  { id: 'q_14', clue: 'ما عاصمة اليابان؟', answer: 'طوكيو' },
  { id: 'q_15', clue: 'من العالم المسلم الذي اشتهر بكتابه "القانون في الطب"؟', answer: 'ابن سينا' },
  { id: 'q_16', clue: 'ما المدينة التي تُعرف بلقب مدينة الألف مئذنة؟', answer: 'القاهرة' },
  { id: 'q_17', clue: 'ما المصطلح الذي يطلق على الارتفاع العام والمستمر في أسعار السلع والخدمات؟', answer: 'التضخم' },
  { id: 'q_18', clue: 'ما الاسم الذي يطلق على النص المكتوب الذي يصف أحداث الفيلم ومشاهده وحواراته؟', answer: 'السيناريو' },
  { id: 'q_19', clue: 'ما اسم التجربة الفكرية التي استخدمها أفلاطون لشرح انتقال الإنسان من عالم الظلال إلى معرفة الحقيقة؟', answer: 'كهف أفلاطون' },
  { id: 'q_20', clue: 'ما اسم السنة التي يكون فيها شهر فبراير 29 يومًا؟', answer: 'كبيسة' },
  { id: 'q_21', clue: 'ما الوحدة الأساسية لقياس شدة التيار الكهربائي؟', answer: 'الأمبير' },
  { id: 'q_22', clue: 'ما اسم المعاهدة التي أنهت حرب الثلاثين عامًا في أوروبا عام 1648؟', answer: 'وستفاليا' },
  { id: 'q_23', clue: 'ما اسم النظام الكتابي الذي اشتهر به السومريون؟', answer: 'المسمارية' },
  { id: 'q_24', clue: 'ما الجهاز الذي يحوّل الطاقة الكهربائية إلى ضوء؟', answer: 'المصباح' },
  { id: 'q_25', clue: 'ما العدد الذي يمثل مجموع المحيطات الكبرى على سطح الأرض؟', answer: 'خمسة' },
];

const words = rawQuestions.map(q => ({
  id: q.id,
  clue: q.clue,
  answer: q.answer,
  norm: cleanWord(q.answer),
  len: cleanWord(q.answer).length
}));

type Dir = 'across' | 'down';

function trySolveRandomized(GRID_SIZE: number, maxRestarts: number): any[] | null {
  const grid: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
  const cellAcross: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
  const cellDown: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));

  function canFitStrict(w: any, dir: Dir, r: number, c: number, placedCount: number): { valid: boolean; inters: number } {
    const len = w.len;
    if (dir === 'across') {
      if (c + len > GRID_SIZE || r < 0 || r >= GRID_SIZE || c < 0) return { valid: false, inters: 0 };
      if (c > 0 && grid[r][c - 1] !== null) return { valid: false, inters: 0 };
      if (c + len < GRID_SIZE && grid[r][c + len] !== null) return { valid: false, inters: 0 };

      let touches = placedCount === 0;
      let inters = 0;

      for (let k = 0; k < len; k++) {
        const cur = grid[r][c + k];
        if (cur !== null) {
          if (cur !== w.norm[k]) return { valid: false, inters: 0 };
          if (cellAcross[r][c + k] !== null) return { valid: false, inters: 0 };
          touches = true;
          inters++;
        } else {
          if (r > 0 && grid[r - 1][c + k] !== null) return { valid: false, inters: 0 };
          if (r < GRID_SIZE - 1 && grid[r + 1][c + k] !== null) return { valid: false, inters: 0 };
        }
      }
      return { valid: touches, inters };
    } else {
      if (r + len > GRID_SIZE || c < 0 || c >= GRID_SIZE || r < 0) return { valid: false, inters: 0 };
      if (r > 0 && grid[r - 1][c] !== null) return { valid: false, inters: 0 };
      if (r + len < GRID_SIZE && grid[r + len][c] !== null) return { valid: false, inters: 0 };

      let touches = placedCount === 0;
      let inters = 0;

      for (let k = 0; k < len; k++) {
        const cur = grid[r + k][c];
        if (cur !== null) {
          if (cur !== w.norm[k]) return { valid: false, inters: 0 };
          if (cellDown[r + k][c] !== null) return { valid: false, inters: 0 };
          touches = true;
          inters++;
        } else {
          if (c > 0 && grid[r + k][c - 1] !== null) return { valid: false, inters: 0 };
          if (c < GRID_SIZE - 1 && grid[r + k][c + 1] !== null) return { valid: false, inters: 0 };
        }
      }
      return { valid: touches, inters };
    }
  }

  for (let restart = 0; restart < maxRestarts; restart++) {
    for (let r = 0; r < GRID_SIZE; r++) {
      for (let c = 0; c < GRID_SIZE; c++) {
        grid[r][c] = null;
        cellAcross[r][c] = null;
        cellDown[r][c] = null;
      }
    }

    const placed: any[] = [];
    const root = words[Math.floor(Math.random() * Math.min(5, words.length))];
    const dir: Dir = Math.random() > 0.5 ? 'across' : 'down';
    const rootR = dir === 'across' ? Math.floor(GRID_SIZE / 2) + Math.floor(Math.random() * 3) - 1 : Math.floor((GRID_SIZE - root.len) / 2);
    const rootC = dir === 'down' ? Math.floor(GRID_SIZE / 2) + Math.floor(Math.random() * 3) - 1 : Math.floor((GRID_SIZE - root.len) / 2);

    for (let k = 0; k < root.len; k++) {
      const cr = dir === 'down' ? rootR + k : rootR;
      const cc = dir === 'across' ? rootC + k : rootC;
      grid[cr][cc] = root.norm[k];
      if (dir === 'across') cellAcross[cr][cc] = root.id;
      else cellDown[cr][cc] = root.id;
    }
    placed.push({ word: root, dir, r: rootR, c: rootC });

    let unplaced = words.filter(w => w.id !== root.id);

    let failed = false;
    while (unplaced.length > 0) {
      // Find candidate placements
      const candidateList: { word: any; pl: { dir: Dir; r: number; c: number; inters: number; score: number } }[] = [];

      for (const w of unplaced) {
        for (const d of ['across', 'down'] as Dir[]) {
          for (let r = 0; r < GRID_SIZE; r++) {
            for (let c = 0; c < GRID_SIZE; c++) {
              const res = canFitStrict(w, d, r, c, placed.length);
              if (res.valid) {
                const midR = d === 'down' ? r + w.len / 2 : r;
                const midC = d === 'across' ? c + w.len / 2 : c;
                const dist = Math.abs(midR - GRID_SIZE/2) + Math.abs(midC - GRID_SIZE/2);
                const score = res.inters * 20 - dist * 0.8 + Math.random() * 5;
                candidateList.push({ word: w, pl: { dir: d, r, c, inters: res.inters, score } });
              }
            }
          }
        }
      }

      if (candidateList.length === 0) {
        failed = true;
        break;
      }

      // Sort candidate list by score descending and pick from top 3
      candidateList.sort((a, b) => b.pl.score - a.pl.score);
      const topPick = candidateList[Math.floor(Math.random() * Math.min(3, candidateList.length))];

      for (let k = 0; k < topPick.word.len; k++) {
        const cr = topPick.pl.dir === 'down' ? topPick.pl.r + k : topPick.pl.r;
        const cc = topPick.pl.dir === 'across' ? topPick.pl.c + k : topPick.pl.c;
        grid[cr][cc] = topPick.word.norm[k];
        if (topPick.pl.dir === 'across') cellAcross[cr][cc] = topPick.word.id;
        else cellDown[cr][cc] = topPick.word.id;
      }
      placed.push({ word: topPick.word, dir: topPick.pl.dir, r: topPick.pl.r, c: topPick.pl.c });
      unplaced = unplaced.filter(w => w.id !== topPick.word.id);
    }

    if (!failed && placed.length === words.length) {
      return placed;
    }
  }
  return null;
}

console.log('Testing randomized strict placement...');
for (const size of [17, 18, 19]) {
  const sol = trySolveRandomized(size, 2000);
  if (sol) {
    console.log(`RANDOMIZED STRICT SOLVED FOR ${size}x${size}!`);
    break;
  } else {
    console.log(`Randomized failed for ${size}x${size}`);
  }
}
