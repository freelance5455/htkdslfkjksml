import fs from 'fs';
import { STAGE_02_QUESTIONS } from '../src/data/stage02Questions';
import { normalizeArabicString } from '../src/engine/normalization';
import { validateCrosswordLayout } from '../src/engine/CrosswordValidator';
import {
  CrosswordLayout,
  CrosswordLayoutWord,
  CrosswordLayoutCell,
  LayoutCellCoordinate,
  CrosswordLayoutClue
} from '../src/types/crosswordLayout';

function cleanWord(str: string): string {
  return normalizeArabicString(str.replace(/\s+/g, ''));
}

const words = STAGE_02_QUESTIONS.map((q) => {
  const norm = cleanWord(q.answer);
  return {
    id: q.id,
    clue: q.clue,
    answer: q.answer,
    norm: norm,
    len: norm.length
  };
});

type Dir = 'across' | 'down';

interface Placement {
  word: typeof words[0];
  dir: Dir;
  r: number;
  c: number;
  reversed: boolean;
}

function solveForSize(GRID_SIZE: number, maxIterations = 25000): Placement[] | null {
  const sortedWords = [...words].sort((a, b) => b.len - a.len);

  for (let iter = 0; iter < maxIterations; iter++) {
    const grid: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
    const cellAcross: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
    const cellDown: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));

    function canFitStrict(
      wStr: string,
      dir: Dir,
      r: number,
      c: number,
      placedCount: number
    ): { valid: boolean; inters: number } {
      const len = wStr.length;
      if (dir === 'across') {
        if (c + len > GRID_SIZE || r < 0 || r >= GRID_SIZE || c < 0) return { valid: false, inters: 0 };
        if (c > 0 && grid[r][c - 1] !== null) return { valid: false, inters: 0 };
        if (c + len < GRID_SIZE && grid[r][c + len] !== null) return { valid: false, inters: 0 };

        let touches = placedCount === 0;
        let inters = 0;

        for (let k = 0; k < len; k++) {
          const cur = grid[r][c + k];
          if (cur !== null) {
            if (cur !== wStr[k]) return { valid: false, inters: 0 };
            if (cellAcross[r][c + k] !== null) return { valid: false, inters: 0 };
            touches = true;
            inters++;
          } else {
            if (r > 0 && grid[r - 1][c + k] !== null && cellDown[r - 1][c + k] === null) return { valid: false, inters: 0 };
            if (r < GRID_SIZE - 1 && grid[r + 1][c + k] !== null && cellDown[r + 1][c + k] === null) return { valid: false, inters: 0 };
          }
        }
        return { valid: touches, inters };
      } else {
        if (r + len > GRID_SIZE || c < 0 || c >= GRID_SIZE || r < 0) return { valid: false, inters: 0 };
        if (r > 0 && grid[r - 1][c] !== null) return { valid: false, inters: 0 };
        if (r + len < GRID_SIZE && grid[r + len][c] !== null) return { valid: false, inters: 0 };

        let touches = placedCount === 0;
        let inters = 0;

        for (let k = 0; k < len; k++) {
          const cur = grid[r + k][c];
          if (cur !== null) {
            if (cur !== wStr[k]) return { valid: false, inters: 0 };
            if (cellDown[r + k][c] !== null) return { valid: false, inters: 0 };
            touches = true;
            inters++;
          } else {
            if (c > 0 && grid[r + k][c - 1] !== null && cellAcross[r + k][c - 1] === null) return { valid: false, inters: 0 };
            if (c < GRID_SIZE - 1 && grid[r + k][c + 1] !== null && cellAcross[r + k][c + 1] === null) return { valid: false, inters: 0 };
          }
        }
        return { valid: touches, inters };
      }
    }

    const placed: Placement[] = [];
    const root = sortedWords[Math.floor(Math.random() * 3)];
    const rootDir: Dir = Math.random() > 0.5 ? 'across' : 'down';
    const rootRev = false;
    const rootStr = root.norm;

    const rootR = rootDir === 'across' ? Math.floor(GRID_SIZE / 2) + Math.floor(Math.random() * 3) - 1 : Math.floor((GRID_SIZE - root.len) / 2);
    const rootC = rootDir === 'down' ? Math.floor(GRID_SIZE / 2) + Math.floor(Math.random() * 3) - 1 : Math.floor((GRID_SIZE - root.len) / 2);

    if (rootR < 0 || rootC < 0 || (rootDir === 'across' && rootC + root.len > GRID_SIZE) || (rootDir === 'down' && rootR + root.len > GRID_SIZE)) {
      continue;
    }

    for (let k = 0; k < root.len; k++) {
      const cr = rootDir === 'down' ? rootR + k : rootR;
      const cc = rootDir === 'across' ? rootC + k : rootC;
      grid[cr][cc] = rootStr[k];
      if (rootDir === 'across') cellAcross[cr][cc] = root.id;
      else cellDown[cr][cc] = root.id;
    }
    placed.push({ word: root, dir: rootDir, r: rootR, c: rootC, reversed: rootRev });

    let unplaced = words.filter((w) => w.id !== root.id);
    let failed = false;

    while (unplaced.length > 0) {
      type Cand = {
        word: typeof words[0];
        dir: Dir;
        r: number;
        c: number;
        reversed: boolean;
        inters: number;
        score: number;
      };

      const candList: Cand[] = [];

      for (const w of unplaced) {
        for (const d of ['across', 'down'] as Dir[]) {
          for (const rev of [false, true]) {
            const wStr = rev ? w.norm.split('').reverse().join('') : w.norm;
            for (let r = 0; r < GRID_SIZE; r++) {
              for (let c = 0; c < GRID_SIZE; c++) {
                const res = canFitStrict(wStr, d, r, c, placed.length);
                if (res.valid) {
                  const midR = d === 'down' ? r + w.len / 2 : r;
                  const midC = d === 'across' ? c + w.len / 2 : c;
                  const distCenter = Math.abs(midR - GRID_SIZE / 2) + Math.abs(midC - GRID_SIZE / 2);
                  const revPenalty = rev ? 1.0 : 0;
                  const score = res.inters * 25 + w.len * 1.5 - distCenter * 0.7 - revPenalty + Math.random() * 4;
                  candList.push({ word: w, dir: d, r, c, reversed: rev, inters: res.inters, score });
                }
              }
            }
          }
        }
      }

      if (candList.length === 0) {
        failed = true;
        break;
      }

      candList.sort((a, b) => b.score - a.score);
      const topCount = Math.min(3, candList.length);
      const topPick = candList[Math.floor(Math.random() * topCount)];

      const pickStr = topPick.reversed ? topPick.word.norm.split('').reverse().join('') : topPick.word.norm;
      for (let k = 0; k < topPick.word.len; k++) {
        const cr = topPick.dir === 'down' ? topPick.r + k : topPick.r;
        const cc = topPick.dir === 'across' ? topPick.c + k : topPick.c;
        grid[cr][cc] = pickStr[k];
        if (topPick.dir === 'across') cellAcross[cr][cc] = topPick.word.id;
        else cellDown[cr][cc] = topPick.word.id;
      }

      placed.push({
        word: topPick.word,
        dir: topPick.dir,
        r: topPick.r,
        c: topPick.c,
        reversed: topPick.reversed
      });

      unplaced = unplaced.filter((w) => w.id !== topPick.word.id);
    }

    if (!failed && placed.length === words.length) {
      console.log(`🎉 Found solution for size ${GRID_SIZE}x${GRID_SIZE} on iteration ${iter}!`);
      return placed;
    }
  }

  return null;
}

// Try grid sizes 17, 18, 19, 16
let finalGridSize = 18;
let solved: Placement[] | null = null;

for (const size of [18, 19, 17, 20, 16]) {
  console.log(`Searching for valid crossword in ${size}x${size} grid...`);
  solved = solveForSize(size, 20000);
  if (solved) {
    finalGridSize = size;
    break;
  }
}

if (!solved) {
  console.error('Could not solve layout');
  process.exit(1);
}

// Build and Validate CrosswordLayout
const GRID_SIZE = finalGridSize;
const gridLetters: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
const acrossMap: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
const downMap: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));

for (const p of solved) {
  const wStr = p.reversed ? p.word.norm.split('').reverse().join('') : p.word.norm;
  for (let k = 0; k < p.word.len; k++) {
    const r = p.dir === 'down' ? p.r + k : p.r;
    const c = p.dir === 'across' ? p.c + k : p.c;
    gridLetters[r][c] = wStr[k];
    if (p.dir === 'across') acrossMap[r][c] = p.word.id;
    else downMap[r][c] = p.word.id;
  }
}

let clueNum = 1;
const wordNumberMap = new Map<string, number>();
const cellNumberMap = new Map<string, number>();

for (let r = 0; r < GRID_SIZE; r++) {
  for (let c = 0; c < GRID_SIZE; c++) {
    if (gridLetters[r][c] === null) continue;

    let hasStart = false;
    const startAcross = solved.find((p) => p.dir === 'across' && p.r === r && p.c === c);
    const startDown = solved.find((p) => p.dir === 'down' && p.r === r && p.c === c);

    if (startAcross) {
      wordNumberMap.set(startAcross.word.id, clueNum);
      hasStart = true;
    }
    if (startDown) {
      wordNumberMap.set(startDown.word.id, clueNum);
      hasStart = true;
    }

    if (hasStart) {
      cellNumberMap.set(`${r}_${c}`, clueNum);
      clueNum++;
    }
  }
}

const cells: CrosswordLayoutCell[] = [];
const blackCells: LayoutCellCoordinate[] = [];

for (let r = 0; r < GRID_SIZE; r++) {
  for (let c = 0; c < GRID_SIZE; c++) {
    const letter = gridLetters[r][c];
    if (letter === null) {
      cells.push({
        row: r,
        column: c,
        isBlocked: true,
        letter: ''
      });
      blackCells.push({ row: r, col: c });
    } else {
      const num = cellNumberMap.get(`${r}_${c}`);
      cells.push({
        row: r,
        column: c,
        isBlocked: false,
        letter,
        number: num,
        acrossWordId: acrossMap[r][c] || undefined,
        downWordId: downMap[r][c] || undefined
      });
    }
  }
}

const layoutWords: CrosswordLayoutWord[] = solved.map((p) => {
  const number = wordNumberMap.get(p.word.id) || 1;
  const wordCells: LayoutCellCoordinate[] = [];
  for (let k = 0; k < p.word.len; k++) {
    const r = p.dir === 'down' ? p.r + k : p.r;
    const c = p.dir === 'across' ? p.c + k : p.c;
    wordCells.push({ row: r, col: c });
  }

  return {
    id: p.word.id,
    clue: p.word.clue,
    answer: p.word.answer,
    normalizedAnswer: p.word.norm,
    direction: p.dir,
    startRow: p.r,
    startColumn: p.c,
    length: p.word.len,
    cells: wordCells,
    number,
    reversed: p.reversed
  };
});

layoutWords.sort((a, b) => {
  if (a.number !== b.number) return a.number - b.number;
  return a.direction === 'across' ? -1 : 1;
});

const clues: CrosswordLayoutClue[] = layoutWords.map((w) => ({
  number: w.number,
  clue: w.clue,
  direction: w.direction,
  length: w.length,
  wordId: w.id,
  reversed: w.reversed
}));

const layout: CrosswordLayout = {
  gridRows: GRID_SIZE,
  gridColumns: GRID_SIZE,
  cells,
  words: layoutWords,
  clues,
  blackCells
};

const validation = validateCrosswordLayout(layout);
console.log('\n--- Validation Result for Stage 2 ---');
console.log('Grid Dimensions:', `${GRID_SIZE}x${GRID_SIZE}`);
console.log('isValid:', validation.isValid);
validation.items.forEach((item) => {
  console.log(`${item.passed ? '✓' : '✗'} ${item.label}: ${item.message}`);
});

if (validation.isValid) {
  fs.writeFileSync('src/data/golden_stage_02.json', JSON.stringify(layout, null, 2), 'utf-8');
  console.log('\n✨ Saved golden_stage_02.json successfully!');
} else {
  console.error('Validation failed!');
  process.exit(1);
}
