import fs from 'fs';
import path from 'path';

function createWavHeader(dataLength, sampleRate = 22050, numChannels = 1, bitsPerSample = 16) {
  const byteRate = (sampleRate * numChannels * bitsPerSample) / 8;
  const blockAlign = (numChannels * bitsPerSample) / 8;
  const buffer = Buffer.alloc(44);

  buffer.write('RIFF', 0);
  buffer.writeUInt32LE(36 + dataLength, 4);
  buffer.write('WAVE', 8);
  buffer.write('fmt ', 12);
  buffer.writeUInt32LE(16, 16);
  buffer.writeUInt16LE(1, 20); // PCM format
  buffer.writeUInt16LE(numChannels, 22);
  buffer.writeUInt32LE(sampleRate, 24);
  buffer.writeUInt32LE(byteRate, 28);
  buffer.writeUInt16LE(blockAlign, 32);
  buffer.writeUInt16LE(bitsPerSample, 34);
  buffer.write('data', 36);
  buffer.writeUInt32LE(dataLength, 40);

  return buffer;
}

function generateWav(filename, durationSec, generator) {
  const sampleRate = 22050;
  const numSamples = Math.floor(sampleRate * durationSec);
  const data = Buffer.alloc(numSamples * 2);

  for (let i = 0; i < numSamples; i++) {
    const t = i / sampleRate;
    let sample = generator(t, durationSec);
    sample = Math.max(-1, Math.min(1, sample));
    const intSample = sample < 0 ? sample * 0x8000 : sample * 0x7fff;
    data.writeInt16LE(intSample, i * 2);
  }

  const header = createWavHeader(data.length, sampleRate);
  return Buffer.concat([header, data]);
}

const outDir = path.resolve('android/app/src/main/res/raw');
if (!fs.existsSync(outDir)) {
  fs.mkdirSync(outDir, { recursive: true });
}

// 1. Morning Birds
const morningBirds = generateWav('morning_birds.wav', 3.0, (t) => {
  let s = 0;
  // Bird chirp 1: 0 to 0.4s
  if (t < 0.4) {
    const f = 2400 + Math.sin(t * 35) * 800;
    const env = Math.sin((t / 0.4) * Math.PI);
    s += Math.sin(2 * Math.PI * f * t) * env * 0.7;
  }
  // Bird chirp 2: 0.6 to 1.1s
  if (t >= 0.6 && t < 1.1) {
    const lt = t - 0.6;
    const f = 2800 + Math.sin(lt * 40) * 1000;
    const env = Math.sin((lt / 0.5) * Math.PI);
    s += Math.sin(2 * Math.PI * f * t) * env * 0.65;
  }
  // Bird chirp 3: 1.5 to 2.2s
  if (t >= 1.5 && t < 2.2) {
    const lt = t - 1.5;
    const f = 3200 + Math.sin(lt * 50) * 900;
    const env = Math.sin((lt / 0.7) * Math.PI);
    s += Math.sin(2 * Math.PI * f * t) * env * 0.7;
  }
  return s;
});
fs.writeFileSync(path.join(outDir, 'morning_birds.wav'), morningBirds);

// 2. Flowing Water
const flowingWater = generateWav('flowing_water.wav', 3.0, (t) => {
  // Pink-ish filtered noise + soft gurgle harmonics
  const noise = (Math.random() * 2 - 1) * 0.25;
  const bubble1 = Math.sin(2 * Math.PI * (420 + Math.sin(t * 12) * 50) * t) * 0.2;
  const bubble2 = Math.sin(2 * Math.PI * (580 + Math.cos(t * 16) * 60) * t) * 0.15;
  const stream = Math.sin(2 * Math.PI * 300 * t) * 0.1;
  return (noise + bubble1 + bubble2 + stream) * 0.8;
});
fs.writeFileSync(path.join(outDir, 'flowing_water.wav'), flowingWater);

// 3. Zen Bell
const zenBell = generateWav('zen_bell.wav', 3.0, (t) => {
  const env = Math.exp(-t * 1.5);
  const f1 = Math.sin(2 * Math.PI * 528 * t);
  const f2 = Math.sin(2 * Math.PI * 1056 * t) * 0.4;
  const f3 = Math.sin(2 * Math.PI * 1584 * t) * 0.15;
  return (f1 + f2 + f3) * env * 0.85;
});
fs.writeFileSync(path.join(outDir, 'zen_bell.wav'), zenBell);

// 4. Soft Rain
const softRain = generateWav('soft_rain.wav', 3.0, (t) => {
  const noise = (Math.random() * 2 - 1) * 0.35;
  const pitter1 = Math.sin(2 * Math.PI * 1200 * t) * (Math.random() > 0.98 ? 0.3 : 0.0);
  const pitter2 = Math.sin(2 * Math.PI * 1800 * t) * (Math.random() > 0.97 ? 0.25 : 0.0);
  return (noise + pitter1 + pitter2) * 0.6;
});
fs.writeFileSync(path.join(outDir, 'soft_rain.wav'), softRain);

// 5. Emergency Siren
const emergencySiren = generateWav('emergency_siren.wav', 3.0, (t) => {
  const modFreq = 800 + Math.sin(t * 8) * 350;
  return Math.sin(2 * Math.PI * modFreq * t) * 0.85;
});
fs.writeFileSync(path.join(outDir, 'emergency_siren.wav'), emergencySiren);

console.log('Successfully generated Android alarm tones in android/app/src/main/res/raw/');
