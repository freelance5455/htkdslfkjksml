import './stub';

const results: string[] = [];
const t = async (name: string, fn: () => void | Promise<void>) => {
  const start = Date.now();
  try {
    await fn();
    results.push(`  ✅ ${name} (${Date.now() - start}ms)`);
  } catch (e: any) {
    results.push(`  ❌ ${name}: ${e?.message ?? e}`);
    console.error(name, e);
  }
};

const { World } = await import('../src/game/world');
const { buildLuxuryHouse, buildShopInterior } = await import('../src/game/interiors');
const { Human, Dog } = await import('../src/game/character');
const { Vehicle } = await import('../src/game/vehicles');
const { PedManager, TrafficManager } = await import('../src/game/npc');
const THREE = await import('three');

await t('World.build (city generation)', () => {
  const w = new World('medium');
  w.build();
  if (!w.colliders.length) throw new Error('no colliders generated');
  if (!w.buildingRects.length) throw new Error('no building rects');
  if (!w.interactables.length) throw new Error('no interactables');
  console.log(
    `     colliders=${w.colliders.length} buildings=${w.buildingRects.length} ` +
      `interactables=${w.interactables.length} district=${w.district(0, 0)}`
  );
  w.setNight(1);
  w.update(0.016, 1);
  w.updateWetness(1);
});

await t('World.build (low quality)', () => {
  const w = new World('low');
  w.build();
  console.log(`     colliders=${w.colliders.length}`);
});

await t('Luxury house interior', () => {
  const h = buildLuxuryHouse();
  let meshes = 0;
  h.group.traverse((o) => {
    if ((o as THREE.Mesh).isMesh) meshes++;
  });
  if (meshes < 40) throw new Error('interior looks empty: ' + meshes);
  console.log(`     meshes=${meshes} colliders=${h.colliders.length} lights=${h.lights.length}`);
});

await t('Shop interiors', () => {
  for (const [id, kind, title] of [
    ['phone', 'phone', 'CITY PHONE'],
    ['mod', 'mod', 'TORQUE'],
    ['police', 'police', 'POLICE'],
    ['mall', 'mall', 'MALL'],
  ] as [string, string, string][]) {
    const s = buildShopInterior(id, kind, title, 0x2f9d5b);
    let meshes = 0;
    s.group.traverse((o) => {
      if ((o as THREE.Mesh).isMesh) meshes++;
    });
    if (meshes < 10) throw new Error(`${id} interior empty`);
    console.log(`     ${id}: meshes=${meshes} items=${s.shopItems?.length ?? 0}`);
  }
});

await t('Vehicles', () => {
  for (const type of ['m8', 'sedan', 'suv', 'taxi', 'bus', 'police', 'van', 'ev', 'vip', 'super']) {
    const v = new Vehicle(type, 0x223344, 'TEST-123', type === 'police');
    let meshes = 0;
    v.group.traverse((o) => {
      if ((o as THREE.Mesh).isMesh) meshes++;
    });
    if (meshes < 8) throw new Error(`${type} has too few meshes`);
    v.updateVisual(0.016, 0);
    v.setLightsOn(true);
    v.setBrake(true);
    v.forward();
  }
  console.log('     all 10 vehicle types built');
});

await t('Characters + dog', () => {
  const h = new Human({ shirt: 0x334455 });
  for (const p of ['idle', 'walk', 'run', 'jump', 'sit', 'punch', 'shoot', 'drive', 'dead']) {
    h.setPose(p as any);
    h.update(0.016, 3, true, { aim: 0 });
  }
  const d = new Dog();
  d.update(0.016, 4, false);
  d.update(0.016, 0, true);
  console.log('     human + dog animated');
});

await t('Ped + traffic AI (200 frames)', () => {
  const w = new World('low');
  w.build();
  const peds = new PedManager(w);
  const traffic = new TrafficManager(w);
  const p = new THREE.Vector3(0, 0, 0);
  for (let i = 0; i < 200; i++) {
    peds.update(0.016, p, i * 0.016);
    traffic.update(0.016, p, true);
  }
  console.log(`     peds=${peds.peds.length} trafficCars=${traffic.cars.length}`);
});

await t('World collision queries', () => {
  const w = new World('low');
  w.build();
  const near = w.collidersNear(0, 0);
  if (!near.length) throw new Error('expected colliders downtown');
  const snapped = w.snapToRoad(37, 62);
  console.log(`     nearby=${near.length} snapToRoad=${snapped}`);
});

console.log('\nSMOKE TEST RESULTS');
console.log(results.join('\n'));
const failed = results.filter((r) => r.includes('❌')).length;
console.log(failed ? `\n${failed} FAILURES` : '\nALL PASSED');
process.exit(failed ? 1 : 0);
