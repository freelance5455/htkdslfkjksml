#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
printf '\n== APPRECIATE PLATFORM ==\n'
(cd app && npm test && npm run check && npm run verify)
printf '\n== APPRECIATE AI ==\n'
(cd appreciate-ai && npm run verify)
printf '\n== APPRECIATE CLOUD CONTROL ==\n'
(cd cloud-control && npm run check && npm test)
printf '\n== ALL SOURCE CHECKS PASSED ==\n'
printf 'This verifies source and automated tests only; it does not claim public deployment, production database, live model inference, or device installation.\n'
