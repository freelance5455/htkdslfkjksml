extends Node3D

# ULTIMATE PROTOTYPE: original content, procedural visuals, no assets from reference APK.

var player:CharacterBody3D
var car:CharacterBody3D
var camera:Camera3D
var police:Array[CharacterBody3D]=[]
var civilians:Array[CharacterBody3D]=[]
var traffic:Array[CharacterBody3D]=[]
var cars:Array[CharacterBody3D]=[]
var pickups:Array[Node3D]=[]
var marker:MeshInstance3D

var money=500
var bank=0
var health=100
var armor=25
var wanted=0
var ammo=24
var in_car=false
var mission=0
var mission_done=false
var game_paused=false
var touch=Vector2.ZERO
var weapon="Pistola"
var save_path="user://city_streets_save.json"

var missions=[
    {"title":"Entrega rápida","pos":Vector3(35,0,-35),"reward":250},
    {"title":"Fuga da polícia","pos":Vector3(-45,0,35),"reward":400},
    {"title":"Entrega final","pos":Vector3(55,0,55),"reward":650},
    {"title":"Trabalho especial","pos":Vector3(-55,0,-55),"reward":900}
]

var hud:Label
var notice:Label
var mission_label:Label
var menu_panel:Panel
var shop_panel:Panel

func _ready():
    randomize()
    build_world()
    build_player()
    build_cars()
    build_npcs()
    build_police()
    build_pickups()
    build_ui()
    load_game()
    refresh()

func mat(c:Color,glow=false):
    var m=StandardMaterial3D.new()
    m.albedo_color=c
    if glow:
        m.emission_enabled=true
        m.emission=c
    return m

func box(pos,size,c,solid=true):
    var m=MeshInstance3D.new()
    var b=BoxMesh.new();b.size=size;m.mesh=b;m.position=pos;m.material_override=mat(c)
    add_child(m)
    if solid:
        var body=StaticBody3D.new();body.position=pos
        var cs=CollisionShape3D.new();var sh=BoxShape3D.new();sh.size=size;cs.shape=sh
        body.add_child(cs);add_child(body)

func build_world():
    var env=WorldEnvironment.new()
    var e=Environment.new();e.background_mode=Environment.BG_COLOR
    e.background_color=Color(.30,.50,.70);e.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR
    e.ambient_light_energy=1.0;env.environment=e;add_child(env)
    var sun=DirectionalLight3D.new();sun.rotation_degrees=Vector3(-55,-25,0);sun.light_energy=1.2;add_child(sun)
    # large road grid
    for x in range(-100,101,20): box(Vector3(x,-.5,0),Vector3(7,1,200),Color(.09,.09,.10))
    for z in range(-100,101,20): box(Vector3(0,-.5,z),Vector3(200,1,7),Color(.09,.09,.10))
    # buildings
    for x in range(-90,91,20):
        for z in range(-90,91,20):
            if (x+z)%40!=0:
                var h=5+float(abs(x*7+z*3)%10)
                box(Vector3(x,h/2,z),Vector3(12,h,12),Color(.36+.03*float(abs(x)%4),.36,.34))
    # park
    box(Vector3(-30,.05,-30),Vector3(14,.1,14),Color(.10,.42,.16),false)
    # shop blocks
    box(Vector3(30,2,30),Vector3(12,4,12),Color(.65,.22,.12))
    box(Vector3(-30,2,30),Vector3(12,4,12),Color(.12,.28,.68))
    box(Vector3(30,2,-30),Vector3(12,4,12),Color(.65,.48,.08))
    update_marker()

func update_marker():
    if marker: marker.queue_free()
    if mission>=missions.size(): return
    marker=MeshInstance3D.new()
    var c=CylinderMesh.new();c.top_radius=2;c.bottom_radius=2;c.height=.25
    marker.mesh=c;marker.position=missions[mission].pos+Vector3(0,.15,0)
    marker.material_override=mat([Color(1,.75,.05),Color(.1,.55,1),Color(.1,1,.25),Color(1,.15,.65)][mission],true)
    add_child(marker)

func build_player():
    player=CharacterBody3D.new();player.position=Vector3(0,1,4)
    var m=MeshInstance3D.new();var cap=CapsuleMesh.new();cap.height=1.8;cap.radius=.4;m.mesh=cap
    m.material_override=mat(Color(.10,.35,.85));player.add_child(m)
    var cs=CollisionShape3D.new();var sh=CapsuleShape3D.new();sh.height=1.8;sh.radius=.4;cs.shape=sh;player.add_child(cs)
    add_child(player)
    camera=Camera3D.new();camera.position=Vector3(0,4.8,7);player.add_child(camera);camera.current=true

func make_car(pos,c):
    var v=CharacterBody3D.new();v.position=pos
    var m=MeshInstance3D.new();var b=BoxMesh.new();b.size=Vector3(2.3,.8,4.3);m.mesh=b;m.material_override=mat(c);v.add_child(m)
    add_child(v);cars.append(v);return v

func build_cars():
    car=make_car(Vector3(5,.8,4),Color(.82,.05,.04))
    make_car(Vector3(-25,.8,20),Color(.05,.28,.8))
    make_car(Vector3(25,.8,-20),Color(.9,.55,.03))
    make_car(Vector3(-50,.8,50),Color(.15,.7,.25))
    make_car(Vector3(50,.8,-50),Color(.55,.12,.65))

func build_npcs():
    for p in [Vector3(-10,1,10),Vector3(15,1,-10),Vector3(-45,1,-10),Vector3(45,1,10),Vector3(0,1,-45),Vector3(60,1,0)]:
        var n=CharacterBody3D.new();n.position=p
        var m=MeshInstance3D.new();var c=CapsuleMesh.new();c.height=1.8;c.radius=.4;m.mesh=c
        m.material_override=mat(Color(.65,.25,.55));n.add_child(m)
        var cs=CollisionShape3D.new();var s=CapsuleShape3D.new();s.height=1.8;s.radius=.4;cs.shape=s;n.add_child(cs)
        add_child(n);civilians.append(n)

func build_police():
    for p in [Vector3(-25,1,25),Vector3(25,1,25),Vector3(25,1,-45),Vector3(-55,1,45)]:
        var n=CharacterBody3D.new();n.position=p
        var m=MeshInstance3D.new();var c=CapsuleMesh.new();c.height=1.8;c.radius=.4;m.mesh=c;m.material_override=mat(Color(.03,.06,.12));n.add_child(m)
        var cs=CollisionShape3D.new();var s=CapsuleShape3D.new();s.height=1.8;s.radius=.4;cs.shape=s;n.add_child(cs)
        add_child(n);police.append(n)

func build_pickups():
    for p in [Vector3(10,1,10),Vector3(-10,1,-10),Vector3(50,1,0)]:
        var m=MeshInstance3D.new();var s=SphereMesh.new();s.radius=.35;s.height=.7;m.mesh=s;m.position=p
        m.material_override=mat(Color(1,.8,.05),true);add_child(m);pickups.append(m)

func build_ui():
    var ui=CanvasLayer.new();add_child(ui)
    hud=Label.new();hud.position=Vector2(18,18);hud.add_theme_font_size_override("font_size",21);ui.add_child(hud)
    mission_label=Label.new();mission_label.position=Vector2(18,105);mission_label.add_theme_font_size_override("font_size",20);ui.add_child(mission_label)
    notice=Label.new();notice.position=Vector2(18,150);notice.add_theme_font_size_override("font_size",19);ui.add_child(notice)
    var help=Label.new();help.position=Vector2(18,650);help.text="WASD mover • SHIFT correr • E carro • ESPAÇO ação • M guardar";help.add_theme_font_size_override("font_size",17);ui.add_child(help)
    var cs=[["◀",Vector2(25,520),Vector2(-1,0)],["▶",Vector2(145,520),Vector2(1,0)],["▲",Vector2(85,465),Vector2(0,-1)],["▼",Vector2(85,575),Vector2(0,1)]]
    for d in cs:
        var b=Button.new();b.text=d[0];b.position=d[1];b.size=Vector2(55,55);ui.add_child(b)
        b.button_down.connect(func():touch=d[2]);b.button_up.connect(func():touch=Vector2.ZERO)
    make_button(ui,"CAR",Vector2(1120,535),"_toggle")
    make_button(ui,"AÇÃO",Vector2(1010,535),"_action")
    make_button(ui,"LOJA",Vector2(1010,605),"_shop")
    make_button(ui,"MENU",Vector2(1120,605),"_pause")
    menu_panel=Panel.new();menu_panel.position=Vector2(410,130);menu_panel.size=Vector2(460,390);menu_panel.visible=false;ui.add_child(menu_panel)
    var t=Label.new();t.position=Vector2(70,35);t.text="PAUSA\\n\\nCity Streets 3D\\n\\nM — guardar\\nE — entrar/sair do carro\\nESPAÇO — ação\\n\\nVolta a carregar MENU para continuar.";t.add_theme_font_size_override("font_size",23);menu_panel.add_child(t)
    shop_panel=Panel.new();shop_panel.position=Vector2(430,160);shop_panel.size=Vector2(420,300);shop_panel.visible=false;ui.add_child(shop_panel)
    var st=Label.new();st.position=Vector2(35,25);st.text="LOJA\\n\\nMunições: €50 = +12\\nColete: €150 = +50 proteção\\nReparar carro: €100";st.add_theme_font_size_override("font_size",22);shop_panel.add_child(st)
    var buy=Button.new();buy.text="Comprar munições";buy.position=Vector2(90,150);buy.size=Vector2(240,55);shop_panel.add_child(buy);buy.pressed.connect(_buy_ammo)
    var close=Button.new();close.text="Fechar";close.position=Vector2(145,220);close.size=Vector2(130,50);shop_panel.add_child(close);close.pressed.connect(func():shop_panel.visible=false)

func make_button(ui,text,pos,method):
    var b=Button.new();b.text=text;b.position=pos;b.size=Vector2(90,60);ui.add_child(b);b.pressed.connect(Callable(self,method))

func _physics_process(delta):
    if game_paused:return
    if health<=0:return
    if in_car:drive(delta)
    else:walk(delta)
    police_ai(delta)
    civilian_ai(delta)
    traffic_ai(delta)
    missions()
    pickups_check()
    refresh()
    if Input.is_action_just_pressed("menu"):pause()
    if Input.is_action_just_pressed("action"):action()
    if Input.is_key_pressed(KEY_M):save_game()

func walk(delta):
    var v=Input.get_vector("left","right","forward","back")
    if touch.length()>0:v=touch
    var d=Vector3(v.x,0,v.y);var sp=8 if Input.is_action_pressed("sprint") else 5
    player.velocity.x=d.x*sp;player.velocity.z=d.z*sp;player.move_and_slide()
    if Input.is_action_just_pressed("enter_car"):toggle()

func drive(delta):
    var v=Input.get_vector("left","right","forward","back")
    if touch.length()>0:v=touch
    var d=Vector3(v.x,0,v.y);car.velocity.x=d.x*12;car.velocity.z=d.z*12;car.move_and_slide()
    player.global_position=car.global_position+Vector3(0,1,0)
    if Input.is_action_just_pressed("enter_car"):toggle()

func toggle():
    if not in_car and player.global_position.distance_to(car.global_position)<4:
        in_car=true;wanted=min(5,wanted+1);notice.text="Entraste no carro. Procurado aumentado."
    elif in_car:
        in_car=false;player.global_position=car.global_position+Vector3(2,1,0)

func action():
    if ammo<=0:notice.text="Sem munições — visita a loja.";return
    ammo-=1;wanted=min(5,wanted+1);notice.text=weapon+" usada. Procurado %d/5."%wanted

func police_ai(delta):
    for n in police:
        if wanted>0:
            var d=n.global_position.distance_to(player.global_position)
            if d>3:
                n.velocity=(player.global_position-n.global_position).normalized()*6;n.move_and_slide()
            if d<2.5:
                var dmg=int(20*delta)
                if armor>0:armor=max(0,armor-dmg)
                else:health=max(0,health-dmg)
        else:n.velocity=Vector3.ZERO

func civilian_ai(delta):
    for i in range(civilians.size()):
        var n=civilians[i]
        var dir=Vector3(sin(Time.get_ticks_msec()/1300.0+i),0,cos(Time.get_ticks_msec()/1500.0+i))
        n.velocity=dir*1.2;n.move_and_slide()

func traffic_ai(delta):
    for i in range(traffic.size()):
        var v=traffic[i]
        v.position.x+=2.0*delta
        if v.position.x>100:v.position.x=-100

func missions():
    if mission>=missions.size():return
    if player.global_position.distance_to(missions[mission].pos)<4:
        money+=missions[mission].reward;ammo+=6;wanted=0
        notice.text="Missão concluída! +€%d e +6 munições."%missions[mission].reward
        mission+=1;update_marker()
        save_game()

func pickups_check():
    for p in pickups.duplicate():
        if is_instance_valid(p) and player.global_position.distance_to(p.global_position)<2:
            money+=100;notice.text="Encontraste €100!";pickups.erase(p);p.queue_free()

func _buy_ammo():
    if money>=50:money-=50;ammo+=12;notice.text="Compraste 12 munições."
    else:notice.text="Dinheiro insuficiente."

func _shop():
    shop_panel.visible=!shop_panel.visible

func _pause():
    pause()

func pause():
    game_paused=!game_paused;menu_panel.visible=game_paused;get_tree().paused=game_paused

func refresh():
    hud.text="€ %d | Banco €%d | Vida %d%% | Colete %d | Munições %d | Procurado %d/5"%(money,bank,health,armor,ammo,wanted)
    if mission<missions.size():mission_label.text="MISSÃO %d/%d: %s"%(mission+1,missions.size(),missions[mission].title)
    else:mission_label.text="TODAS AS MISSÕES PRINCIPAIS CONCLUÍDAS"
    if notice.text=="":notice.text="Explora a cidade e procura o próximo marcador."

func save_game():
    var data={"money":money,"bank":bank,"health":health,"armor":armor,"wanted":wanted,"ammo":ammo,"mission":mission,"position":[player.position.x,player.position.y,player.position.z]}
    var f=FileAccess.open(save_path,FileAccess.WRITE)
    if f:f.store_string(JSON.stringify(data))
    notice.text="Jogo guardado."

func load_game():
    if not FileAccess.file_exists(save_path):return
    var f=FileAccess.open(save_path,FileAccess.READ)
    var d=JSON.parse_string(f.get_as_text())
    if typeof(d)==TYPE_DICTIONARY:
        money=int(d.get("money",money));bank=int(d.get("bank",bank));health=int(d.get("health",health))
        armor=int(d.get("armor",armor));wanted=int(d.get("wanted",wanted));ammo=int(d.get("ammo",ammo));mission=int(d.get("mission",mission))
        var p=d.get("position",[])
        if p.size()==3:player.position=Vector3(p[0],p[1],p[2])
        update_marker()
