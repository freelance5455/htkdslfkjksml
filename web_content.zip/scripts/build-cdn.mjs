// No-dependency deployment fallback for restricted/offline build environments.
// For a self-hosted, bundled Netlify build, run npm install && npm run build.
import fs from 'node:fs';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
const root=process.cwd(),compiled=path.join(root,'compiled'),dist=path.join(root,'dist');
fs.mkdirSync(dist,{recursive:true});
try{execFileSync('tsc',['--noEmit','false','--outDir',compiled,'--noEmitOnError','false','--pretty','false'],{cwd:root,stdio:'pipe'});}catch(err){console.warn('TypeScript transpile returned type diagnostics because dependencies may be unavailable; validating emitted JavaScript.');}
const walk=(dir)=>fs.readdirSync(dir,{withFileTypes:true}).flatMap(d=>d.isDirectory()?walk(path.join(dir,d.name)):[path.join(dir,d.name)]);
const files=walk(compiled).filter(f=>f.endsWith('.js'));
if(files.length<7)throw Error('Missing transpiled game source');
for(const file of files){const relative=path.relative(compiled,file),out=path.join(dist,relative);fs.mkdirSync(path.dirname(out),{recursive:true});let contents=fs.readFileSync(file,'utf8');
 contents=contents.replace(/import\s+['"]\.\/styles\.css['"];?/, '');
 contents=contents.replace(/(?:from\s*|import\s*)['"](\.{1,2}\/[^'"]+)['"]/g,(match,rel)=>match.replace(rel,rel+'.js'));
 fs.writeFileSync(out,contents);
}
fs.copyFileSync('src/styles.css',path.join(dist,'styles.css'));
const imports={
 'react':'https://esm.sh/react@18.3.1',
 'react/':'https://esm.sh/react@18.3.1/',
 'react/jsx-runtime':'https://esm.sh/react@18.3.1/jsx-runtime',
 'react-dom':'https://esm.sh/react-dom@18.3.1?external=react',
 'react-dom/client':'https://esm.sh/react-dom@18.3.1/client?external=react',
 'three':'https://esm.sh/three@0.172.0',
 'three/':'https://esm.sh/three@0.172.0/',
 '@react-three/fiber':'https://esm.sh/@react-three/fiber@8.18.0?external=react,react-dom,three',
 '@react-three/fiber/':'https://esm.sh/@react-three/fiber@8.18.0&external=react,react-dom,three/',
 '@react-three/drei':'https://esm.sh/@react-three/drei@9.122.0?external=react,react-dom,three,@react-three/fiber',
 '@react-three/rapier':'https://esm.sh/@react-three/rapier@1.5.0?external=react,react-dom,three,@react-three/fiber',
 'zustand':'https://esm.sh/zustand@5.0.3?external=react',
 'zustand/middleware':'https://esm.sh/zustand@5.0.3/middleware?external=react',
 'lucide-react':'https://esm.sh/lucide-react@0.468.0?external=react'
};
fs.writeFileSync(path.join(dist,'index.html'),`<!doctype html><html lang="en"><head><meta charset="UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/><meta name="theme-color" content="#f5f7f4"/><meta name="description" content="ULTIMATE FC: 3D soccer, team building and ranked play"/><title>ULTIMATE FC</title><link rel="stylesheet" href="./styles.css"/><script type="importmap">${JSON.stringify({imports})}</script></head><body><div id="root"></div><script type="module" src="./main.js"></script></body></html>`);
console.log(`Generated ${files.length} browser modules, dist/index.html and dist/styles.css`);
