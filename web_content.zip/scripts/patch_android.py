#!/usr/bin/env python3
"""Run from the project root AFTER `npx cap add android`.
Adds permissions, signing, print plugin, launcher icon and a plain splash."""
import os, re, glob, shutil

ROOT = os.getcwd()
A = os.path.join(ROOT, 'android')
MAIN = os.path.join(A, 'app', 'src', 'main')
PKG = 'com.amino.hesab'

def rd(p):
    with open(p, encoding='utf-8') as f: return f.read()
def wr(p, t):
    with open(p, 'w', encoding='utf-8') as f: f.write(t)

# 1) manifest: permissions
mf = os.path.join(MAIN, 'AndroidManifest.xml')
t = rd(mf)
t = re.sub(r'[ \t]*<uses-permission[^>]*/>[ \t]*\n?', '', t)
t = re.sub(r'[ \t]*<uses-feature[^>]*/>[ \t]*\n?', '', t)
perms = '''
    <!-- Internet (fonts + number-reading engine download) -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <!-- Camera -->
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-feature android:name="android.hardware.camera" android:required="false" />
    <uses-feature android:name="android.hardware.camera.autofocus" android:required="false" />
    <!-- Files / gallery -->
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="29" />
    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />
    <uses-permission android:name="android.permission.VIBRATE" />
'''
assert '</manifest>' in t
t = t.replace('</manifest>', perms + '</manifest>', 1)
if 'requestLegacyExternalStorage' not in t:
    t = t.replace('<application', '<application\n        android:requestLegacyExternalStorage="true"', 1)
wr(mf, t)
print('manifest ok')

# 2) target SDK 34 (keeps normal status-bar layout on Android 15/16)
vg = os.path.join(A, 'variables.gradle')
if os.path.exists(vg):
    v = rd(vg)
    v = re.sub(r'targetSdkVersion\s*=\s*\d+', 'targetSdkVersion = 34', v)
    wr(vg, v)
    print('targetSdk 34')

# 3) release signing with the fixed key (so updates install over old versions)
bg = os.path.join(A, 'app', 'build.gradle')
g = rd(bg)
if 'amino.keystore' not in g:
    g += '''

android {
    signingConfigs {
        amino {
            storeFile file("$rootDir/../amino.keystore")
            storePassword "AminoKey2026"
            keyAlias "amino"
            keyPassword "AminoKey2026"
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.amino
        }
    }
}
'''
    wr(bg, g)
print('signing ok')

# 4) Java: print plugin + MainActivity
jdir = os.path.join(MAIN, 'java', *PKG.split('.'))
os.makedirs(jdir, exist_ok=True)
for n in ('MainActivity.java', 'AminoPrintPlugin.java'):
    shutil.copy(os.path.join(ROOT, 'native', n), os.path.join(jdir, n))
print('java ok ->', jdir)

# 5) icons (copy everything under res-icons/ into res/)
src = os.path.join(ROOT, 'res-icons')
for dp, _, fs in os.walk(src):
    for f in fs:
        if f == 'splash.png':
            continue
        sp = os.path.join(dp, f)
        rel = os.path.relpath(sp, src)
        dst = os.path.join(MAIN, 'res', rel)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy(sp, dst)

# 6) plain splash (no Capacitor logo)
sp = os.path.join(src, 'splash.png')
n = 0
for p in glob.glob(os.path.join(MAIN, 'res', '**', 'splash.png'), recursive=True):
    shutil.copy(sp, p); n += 1
print('icons ok, splash files replaced:', n)
