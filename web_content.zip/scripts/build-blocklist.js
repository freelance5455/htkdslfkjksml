#!/usr/bin/env node
/* Packs a "hosts"-style blocklist into resources/android/nudge/sites.bin for the Android nudge.

   Usage:
     node scripts/build-blocklist.js                 download the Block List Project adult list
     node scripts/build-blocklist.js path/to/list.txt   use a file you already have
     node scripts/build-blocklist.js https://...     use another list

   Output: sorted 64-bit FNV-1a hashes of every domain, 8 bytes each, big endian (about 4 MB for 500,000 sites).
   The Android code (NudgeCore.java) searches it directly, so the app never loads the list as text. */
const fs = require('fs');
const path = require('path');

const DEFAULT_URLS = [
  'https://blocklistproject.github.io/Lists/porn.txt',
  'https://raw.githubusercontent.com/blocklistproject/Lists/master/porn.txt'
];
const OUT_DIR = path.join(__dirname, '..', 'resources', 'android', 'nudge');

const MASK = (1n << 64n) - 1n;
function hash64(s) {
  let h = 0xcbf29ce484222325n;
  for (const b of Buffer.from(s, 'utf8')) { h ^= BigInt(b); h = (h * 0x100000001b3n) & MASK; }
  return BigInt.asIntN(64, h);
}

function parseDomains(text) {
  const out = new Set();
  const skip = new Set(['localhost', 'localhost.localdomain', 'local', 'broadcasthost', 'ip6-localhost', 'ip6-loopback', '0.0.0.0']);
  for (let line of text.split(/\r?\n/)) {
    const hash = line.indexOf('#');
    if (hash >= 0) line = line.slice(0, hash);
    const parts = line.trim().split(/\s+/).filter(Boolean);
    if (!parts.length) continue;
    let d = parts.length === 1 ? parts[0] : (/^[0-9a-f:.]+$/i.test(parts[0]) ? parts[1] : null);
    if (!d) continue;
    d = d.toLowerCase().replace(/^\*\./, '').replace(/\.$/, '');
    if (skip.has(d) || !/^[a-z0-9-]+(\.[a-z0-9-]+)+$/.test(d) || /^\d+(\.\d+)+$/.test(d)) continue;
    out.add(d);
  }
  return out;
}

function pack(domains) {
  const arr = new BigInt64Array(domains.size);
  let i = 0;
  for (const d of domains) arr[i++] = hash64(d);
  arr.sort();
  const uniq = [];
  for (let k = 0; k < arr.length; k++) if (k === 0 || arr[k] !== arr[k - 1]) uniq.push(arr[k]);
  const buf = Buffer.alloc(uniq.length * 8);
  uniq.forEach((v, k) => buf.writeBigInt64BE(v, k * 8));
  return { buf, count: uniq.length };
}

async function load(src) {
  if (src && !/^https?:\/\//i.test(src)) return fs.readFileSync(src, 'utf8');
  const urls = src ? [src] : DEFAULT_URLS;
  let lastErr;
  for (const u of urls) {
    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        const r = await fetch(u);
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return await r.text();
      } catch (e) { lastErr = e; console.error('[blocklist]', u, 'attempt', attempt, 'failed:', e.message); await new Promise(r => setTimeout(r, 1500 * attempt)); }
    }
  }
  throw lastErr;
}

async function main() {
  const src = process.argv[2];
  const text = await load(src);
  const domains = parseDomains(text);
  if (domains.size < 1000 && !process.env.DETOX_ALLOW_SMALL) {
    throw new Error('Only found ' + domains.size + ' domains. That does not look like the full list.');
  }
  const { buf, count } = pack(domains);
  fs.mkdirSync(OUT_DIR, { recursive: true });
  fs.writeFileSync(path.join(OUT_DIR, 'sites.bin'), buf);
  fs.writeFileSync(path.join(OUT_DIR, 'sites.json'), JSON.stringify({ count, built: new Date().toISOString(), source: src || DEFAULT_URLS[0] }, null, 2) + '\n');
  console.log('[blocklist] packed', count.toLocaleString(), 'sites into', buf.length.toLocaleString(), 'bytes');
}

if (require.main === module) main().catch(e => { console.error('[blocklist] failed:', e.message); process.exit(1); });
module.exports = { hash64, parseDomains, pack };
