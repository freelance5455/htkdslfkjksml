// استرجاع الدخول لو ضاع جهاز التحقق: npm run reset-2fa -- <username>
const db = require('../db'), n = process.argv[2];
if (!n) { console.error('Usage: npm run reset-2fa -- <username>'); process.exit(1); }
const r = db.prepare("UPDATE users SET totp_on=0, totp_secret=NULL, totp_last=0, recovery='[]' WHERE username=?").run(n);
if (!r.changes) { console.error('user not found: ' + n); process.exit(1); }
db.prepare('DELETE FROM sessions WHERE user_id=(SELECT id FROM users WHERE username=?)').run(n);
console.log('2FA disabled for ' + n + ' (sessions cleared)');
