import {
  createInitialState, saveGame, loadGame, clearSave, storage, saveScore, loadScores,
  applyChoice, completeMission, checkRequirement, addItem, computeEnding, addToast, nextMission,
} from "../src/game/engine";
import { MISSIONS, missionById } from "../src/game/data/missions";
import { AREA_DEFS, NPCS_BY_AREA, buildArea } from "../src/game/data/areas";
import { NPCS } from "../src/game/data/npcs";
import { ITEMS } from "../src/game/data/items";

let fail = 0, pass = 0;
const ok = (cond: boolean, msg: string) => {
  if (cond) { pass++; } else { fail++; console.log("  FAIL: " + msg); }
};

// ---------- global/localStorage shim (node has none) ----------
const mem = new Map<string, string>();
(globalThis as any).window = {
  localStorage: {
    getItem: (k: string) => (mem.has(k) ? mem.get(k)! : null),
    setItem: (k: string, v: string) => void mem.set(k, v),
    removeItem: (k: string) => void mem.delete(k),
  },
};
(globalThis as any).localStorage = (globalThis as any).window.localStorage;

console.log("== 1. Integridade dos dados ==");
ok(MISSIONS.length === 48, "deve haver 48 missoes, tem " + MISSIONS.length);
ok(MISSIONS.every((m, i) => m.id === i + 1), "ids das missoes sequenciais");
ok(new Set(MISSIONS.map((m) => m.lawTitle)).size === 48, "titulos de lei unicos");

let nodeProblems = 0;
MISSIONS.forEach((m) => {
  const ids = Object.keys(m.nodes);
  m.steps.forEach((s: any) => {
    if (s.kind === "dialogue" && !ids.includes(s.node)) { nodeProblems++; console.log("   node inexistente em " + m.id + ": " + s.node); }
    if (s.kind === "collect" && !AREA_DEFS.some((d) => d.items.some((i: any) => i.item === s.item))) { nodeProblems++; console.log("   item inexistente em " + m.id + ": " + s.item); }
    if (s.kind === "visit" && !AREA_DEFS.find((d) => d.id === s.areaId)) { nodeProblems++; console.log("   area inexistente em " + m.id); }
    if (s.kind === "talk" && !NPCS.find((n) => n.id === s.npc)) { nodeProblems++; console.log("   npc inexistente em " + m.id); }
  });
  Object.entries(m.nodes).forEach(([nid, node]) => {
    if (!node.choices.length) { nodeProblems++; console.log("   node sem escolhas: " + m.id + "/" + nid); }
    node.choices.forEach((ch) => {
      if (ch.next && !ids.includes(ch.next)) { nodeProblems++; console.log("   next invalido: " + m.id + "/" + nid); }
      (ch.give ?? []).forEach((gv: any) => { if (!ITEMS[gv.item]) nodeProblems++; });
      (ch.take ?? []).forEach((tv: any) => { if (!ITEMS[tv.item]) nodeProblems++; });
    });
  });
});
ok(nodeProblems === 0, "integridade das arvores de dialogo");

console.log("== 2. NPCs, areas e portais ==");
let npcProblems = 0;
Object.entries(NPCS_BY_AREA).forEach(([area, list]) => {
  list.forEach((n) => { if (!NPCS.find((d) => d.id === n.id)) { npcProblems++; console.log("   npc desconhecido em " + area + ": " + n.id); } });
});
ok(npcProblems === 0, "todo NPC posicionado existe");
MISSIONS.forEach((m) => {
  const inArea = (NPCS_BY_AREA[m.areaId] ?? []).some((n) => n.id === m.giverNpc);
  if (!inArea) { fail++; console.log("   doador da missao " + m.id + " nao esta em " + m.areaId); }
});
ok(true, "doadores posicionados");
let walkProblems = 0;
AREA_DEFS.forEach((a) => {
  const built = buildArea(a.id);
  built.portals.forEach((p) => {
    if (p.x < 0 || p.y < 0 || p.x >= built.def.w || p.y >= built.def.h) walkProblems++;
    const dest = buildArea(p.toArea);
    if (p.toX < 0 || p.toY < 0 || p.toX >= dest.def.w || p.toY >= dest.def.h) walkProblems++;
  });
  // destino do portal precisa estar livre e ter saida
  built.portals.forEach((p) => {
    const dest = buildArea(p.toArea);
    if (dest.tiles[p.toY * dest.def.w + p.toX] >= 20) walkProblems++;
    const exit = [[1,0],[-1,0],[0,1],[0,-1]].some(([dx,dy]) => {
      const nx = p.toX+dx, ny = p.toY+dy;
      if (nx<0||ny<0||nx>=dest.def.w||ny>=dest.def.h) return false;
      return dest.tiles[ny*dest.def.w+nx] < 20;
    });
    if (!exit) walkProblems++;
  });
});
ok(walkProblems === 0, "portais dentro dos limites e tiles de origem livres");

console.log("== 3. Progressao das 48 missoes ==");
function playMission(state: any, m: any, pick: (node: any, i: number) => any) {
  state.currentMission = m.id;
  state.missionStep = 0;
  let nodeId = m.steps[0].kind === "dialogue" ? m.steps[0].node : "";
  let guard = 0;
  while (guard++ < 80) {
    const step = m.steps[state.missionStep];
    if (!step) { completeMission(state, m, false); return true; }
    if (step.kind === "collect") { addItem(state, step.item, step.count); state.missionStep++; nodeId = m.steps[state.missionStep]?.kind === "dialogue" ? m.steps[state.missionStep].node : ""; continue; }
    if (step.kind === "visit") { state.player.areaId = step.areaId; state.missionStep++; nodeId = m.steps[state.missionStep]?.kind === "dialogue" ? m.steps[state.missionStep].node : ""; continue; }
    if (step.kind === "talk") { state.missionStep++; nodeId = m.steps[state.missionStep]?.kind === "dialogue" ? m.steps[state.missionStep].node : ""; continue; }
    const node = m.nodes[nodeId];
    if (!node) return false;
    const idx = pick(node, 0);
    const ch = node.choices[idx];
    if (!ch || !checkRequirement(state, ch)) return false;
    const res = applyChoice(state, m, ch);
    if (res.completed) { completeMission(state, m, res.failed); return true; }
    if (ch.next && m.nodes[ch.next]) { nodeId = ch.next; continue; }
    state.missionStep++;
    nodeId = m.steps[state.missionStep]?.kind === "dialogue" ? m.steps[state.missionStep].node : nodeId;
  }
  return false;
}

const state = createInitialState("Testador");
AREA_DEFS.forEach((d) => d.items.forEach((it: any) =>
  state.worldItems.push({ id: `${d.id}_${it.id}`, item: it.item, areaId: d.id, x: it.x, y: it.y })));

let allDone = true;
MISSIONS.forEach((m) => { if (!playMission(state, m, (node) => node.choices.findIndex((c: any) => checkRequirement(state, c)))) allDone = false; });
ok(allDone, "todas as 48 missoes podem ser concluidas");
ok(state.completedMissions.length === 48, "48 missoes concluidas");
ok(state.knownLaws.length === 48, "48 sabedorias desbloqueadas");
ok(state.score > 1000, "pontuacao acumulada: " + state.score);
ok(!!state.ending, "final calculado: " + state.ending);

console.log("== 4. Caminho alternativo (ultima escolha) ==");
const s2 = createInitialState("Alt");
AREA_DEFS.forEach((d) => d.items.forEach((it: any) =>
  s2.worldItems.push({ id: `${d.id}_${it.id}`, item: it.item, areaId: d.id, x: it.x, y: it.y })));
let all2 = true;
MISSIONS.forEach((m) => {
  if (!playMission(s2, m, (node) => {
    for (let i = node.choices.length - 1; i >= 0; i--) if (checkRequirement(s2, node.choices[i])) return i;
    return 0;
  })) all2 = false;
});
ok(all2, "caminho alternativo tambem conclui tudo");
ok(s2.completedMissions.length === 48, "48 missoes no caminho alternativo");
console.log("   final alternativo:", s2.ending, "score", s2.score);

console.log("== 5. Save / Load ==");
clearSave();
ok(loadGame() === null, "sem save no inicio");
const s3 = createInitialState("Guardiao");
AREA_DEFS.forEach((d) => d.items.forEach((it: any) =>
  s3.worldItems.push({ id: `${d.id}_${it.id}`, item: it.item, areaId: d.id, x: it.x, y: it.y })));
playMission(s3, MISSIONS[0], (node) => node.choices.findIndex((c: any) => checkRequirement(s3, c)));
playMission(s3, MISSIONS[1], (node) => node.choices.findIndex((c: any) => checkRequirement(s3, c)));
s3.stats.reputation = 42; s3.stats.wealth = 777; s3.score = 1234;
s3.player.areaId = "mercado"; s3.player.x = 12; s3.player.y = 14;
s3.unlockedAreas.push("ponte");
ok(saveGame(s3), "save gravado");
const loaded = loadGame();
ok(!!loaded, "save carregado");
if (loaded) {
  ok(loaded.playerName === "Guardiao", "nome preservado");
  ok(loaded.score === 1234, "pontos preservados");
  ok(loaded.stats.wealth === 777 && loaded.stats.reputation === 42, "atributos preservados");
  ok(loaded.player.areaId === "mercado" && loaded.player.x === 12, "posicao preservada");
  ok(loaded.completedMissions.length === 2, "missoes concluidas preservadas");
  ok(loaded.currentMission === 3, "missao atual preservada: " + loaded.currentMission);
  ok(loaded.unlockedAreas.includes("ponte"), "regioes liberadas preservadas");
  ok(JSON.stringify(loaded.npcs) === JSON.stringify(s3.npcs), "relacionamentos preservados");
  ok(loaded.worldItems.length === s3.worldItems.length, "itens do mundo preservados");
  ok(loaded.flags.length === s3.flags.length, "flags preservadas");
}
// save sobreposto
s3.score = 9999; saveGame(s3);
ok(loadGame()!.score === 9999, "save sobrescreve corretamente");
// save corrompido
storage.set("caminho_do_poder_save_v1", "{quebrado");
ok(loadGame() === null, "save corrompido devolve null sem crash");
clearSave();

console.log("== 6. Ranking ==");
clearSave();
saveScore({ name: "A", score: 100, ending: "X", laws: 10, date: 1 });
saveScore({ name: "B", score: 300, ending: "Y", laws: 20, date: 2 });
saveScore({ name: "C", score: 200, ending: "Z", laws: 15, date: 3 });
const sc = loadScores();
ok(sc.length === 3 && sc[0].name === "B", "ranking ordenado por pontos");
ok(sc[0].score === 300, "maior pontuacao no topo");

console.log("== 7. Finais ==");
const s4 = createInitialState("Fim");
s4.stats.power = 60; s4.stats.influence = 60; s4.flags.push("coroado");
ok(computeEnding(s4) === "king", "final de rei");
const s5 = createInitialState("Fim");
s5.stats.power = 45; s5.stats.influence = 40;
ok(computeEnding(s5) === "advisor", "final de conselheiro");
const s6 = createInitialState("Fim");
s6.stats.power = 32;
ok(computeEnding(s6) === "shadow", "final de poder sombra");
const s7 = createInitialState("Fim");
s7.stats.wealth = 900;
ok(computeEnding(s7) === "noble", "final de nobre rico");
const s8 = createInitialState("Fim");
s8.stats.reputation = 0; s8.stats.power = 1;
ok(computeEnding(s8) === "ruin", "final de ruina");
const s9 = createInitialState("Fim");
s9.stats.reputation = 40; s9.flags.push("padrinho_da_igreja");
ok(computeEnding(s9) === "dynasty", "final de dinastia");

console.log(`\nRESULTADO: ${pass} ok, ${fail} falhas`);
if (fail > 0) process.exit(1);
