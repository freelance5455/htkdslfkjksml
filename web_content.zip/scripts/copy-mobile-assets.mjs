import { cp, mkdir } from 'node:fs/promises';
import { resolve } from 'node:path';
const root = process.cwd();
const out = resolve(root, 'www');
await mkdir(out, { recursive: true });
for (const item of ['icon.svg', 'manifest.webmanifest', 'sw.js', 'assets']) {
  await cp(resolve(root, item), resolve(out, item), { recursive: true, force: true });
}
console.log('NOOR mobile assets copied to www/');
