import os
import shutil
import zipfile

def create_bundle_zip():
    dist_zip = os.path.join('dist', '002-ai-android-apk-ready.zip')
    root_zip = '002-ai-android-apk-ready.zip'

    print('[002 ZIP] Packaging production assets and Android templates...')
    
    with zipfile.ZipFile(dist_zip, 'w', zipfile.ZIP_DEFLATED) as z:
        # Pack dist folder (into assets_dist)
        if os.path.exists('dist'):
            for root, _, files in os.walk('dist'):
                for f in files:
                    if f.endswith('.zip'):
                        continue
                    file_path = os.path.join(root, f)
                    arc_name = os.path.join('assets_dist', os.path.relpath(file_path, 'dist'))
                    z.write(file_path, arc_name)
                    
        # Pack android folder (into android_template)
        if os.path.exists('android'):
            for root, _, files in os.walk('android'):
                for f in files:
                    file_path = os.path.join(root, f)
                    arc_name = os.path.join('android_template', os.path.relpath(file_path, 'android'))
                    z.write(file_path, arc_name)

    shutil.copyfile(dist_zip, root_zip)
    size_mb = os.path.getsize(dist_zip) / (1024 * 1024)
    print(f'[002 ZIP] Successfully created {dist_zip} ({size_mb:.2f} MB)!')
    print(f'[002 ZIP] Copied to root: {root_zip}')

if __name__ == '__main__':
    create_bundle_zip()
