// نسخة احتياطية متسقة من قاعدة البيانات (آمنة أثناء التشغيل). تحتفظ بآخر BACKUP_KEEP نسخة (الافتراضي 14)
const fs = require('fs'), path = require('path'), db = require('../db');
const dbFile = process.env.DB_PATH || path.join(__dirname, '..', 'data', 'osint.db');
const dir = process.env.BACKUP_DIR || path.join(path.dirname(dbFile), 'backups'), keep = +process.env.BACKUP_KEEP || 14;
fs.mkdirSync(dir, { recursive: true });
const name = 'osint-' + new Date().toISOString().replace(/[:.]/g, '-') + '.db';
db.backup(path.join(dir, name)).then(() => {
  const files = fs.readdirSync(dir).filter(f => /^osint-.*\.db$/.test(f)).sort();
  for (const f of files.slice(0, Math.max(0, files.length - keep))) fs.unlinkSync(path.join(dir, f));
  console.log('backup ok: ' + path.join(dir, name) + ' (kept ' + Math.min(files.length, keep) + ')'); db.close();
}).catch(e => { console.error('backup failed: ' + e.message); process.exit(1); });
