import fs from 'node:fs';
import zlib from 'node:zlib';
import path from 'node:path';

function crc32(buf) {
  let table = [];
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      if (c & 1) c = 0xedb88320 ^ (c >>> 1);
      else c = c >>> 1;
    }
    table[n] = c >>> 0;
  }
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c = table[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ 0xffffffff) >>> 0;
}

function makeChunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const typeBuf = Buffer.from(type, 'ascii');
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])), 0);
  return Buffer.concat([len, typeBuf, data, crc]);
}

function createPng(width, height, isMaskable = false) {
  const rawData = Buffer.alloc(height * (1 + width * 4));
  let offset = 0;

  const cx = width / 2;
  const cy = height / 2;
  const radius = width * 0.44;

  for (let y = 0; y < height; y++) {
    rawData[offset++] = 0; // Filter type 0 (None)
    for (let x = 0; x < width; x++) {
      let r = 217, g = 38, b = 44, a = 255; // #d9262c primary red

      if (isMaskable) {
        // Maskable has full bleed background
        r = 217; g = 38; b = 44; a = 255;
      } else {
        // Rounded squircle container
        const dx = Math.abs(x - cx);
        const dy = Math.abs(y - cy);
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist > radius) {
          a = 0;
        }
      }

      // Draw an inventory box / warehouse cart motif in white in center
      const nx = (x - cx) / (width * 0.32);
      const ny = (y - cy) / (height * 0.32);

      // Box shape (-0.6 to 0.6)
      if (Math.abs(nx) < 0.65 && Math.abs(ny) < 0.65) {
        // Inner box borders or solid icon
        const isBoxBorder = Math.abs(nx) > 0.48 || Math.abs(ny) > 0.48;
        const isCenterLine = Math.abs(nx) < 0.08;
        const isStockBar1 = ny > 0.0 && ny < 0.35 && nx > -0.45 && nx < -0.15;
        const isStockBar2 = ny > -0.25 && ny < 0.35 && nx > -0.1 && nx < 0.2;
        const isStockBar3 = ny > -0.45 && ny < 0.35 && nx > 0.25 && nx < 0.45;

        if (isBoxBorder || isCenterLine || isStockBar1 || isStockBar2 || isStockBar3) {
          r = 255; g = 255; b = 255; a = 255;
        }
      }

      rawData[offset++] = r;
      rawData[offset++] = g;
      rawData[offset++] = b;
      rawData[offset++] = a;
    }
  }

  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 6; // color type RGBA
  ihdr[10] = 0; // compression
  ihdr[11] = 0; // filter
  ihdr[12] = 0; // interlace

  const ihdrChunk = makeChunk('IHDR', ihdr);
  const idatChunk = makeChunk('IDAT', zlib.deflateSync(rawData));
  const iendChunk = makeChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

const publicDir = path.resolve('public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

fs.writeFileSync(path.join(publicDir, 'pwa-192x192.png'), createPng(192, 192, false));
fs.writeFileSync(path.join(publicDir, 'pwa-512x512.png'), createPng(512, 512, false));
fs.writeFileSync(path.join(publicDir, 'pwa-maskable-512x512.png'), createPng(512, 512, true));
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), createPng(180, 180, false));

const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
  <rect width="512" height="512" rx="128" fill="#d9262c"/>
  <rect x="96" y="96" width="320" height="320" rx="36" fill="none" stroke="#ffffff" stroke-width="28"/>
  <rect x="140" y="240" width="56" height="136" rx="8" fill="#ffffff"/>
  <rect x="228" y="180" width="56" height="196" rx="8" fill="#ffffff"/>
  <rect x="316" y="130" width="56" height="246" rx="8" fill="#ffffff"/>
  <path d="M140 210 L256 140 L372 90" stroke="#ffffff" stroke-width="18" stroke-linecap="round" fill="none" stroke-dasharray="8 8"/>
</svg>`;

fs.writeFileSync(path.join(publicDir, 'icon.svg'), svg);
console.log('Icons generated successfully in public/');
