import sharp from 'sharp';
import fs from 'fs';
import path from 'path';

async function generate() {
  const iconSvg = fs.readFileSync('public/icon.svg');
  const maskableSvg = fs.readFileSync('public/icon-maskable.svg');

  await sharp(iconSvg).resize(192, 192).png().toFile('public/pwa-192x192.png');
  console.log('pwa-192x192.png generated');

  await sharp(iconSvg).resize(512, 512).png().toFile('public/pwa-512x512.png');
  console.log('pwa-512x512.png generated');

  await sharp(iconSvg).resize(180, 180).png().toFile('public/apple-touch-icon.png');
  console.log('apple-touch-icon.png generated');

  await sharp(iconSvg).resize(32, 32).png().toFile('public/favicon.ico');
  console.log('favicon.ico generated');

  await sharp(maskableSvg).resize(512, 512).png().toFile('public/pwa-maskable-512x512.png');
  console.log('pwa-maskable-512x512.png generated');
}

generate().catch(console.error);
