import fs from 'fs';
import zlib from 'zlib';

// Minimal pure-JS PNG generator
function createPng(width, height, drawPixel) {
  // RGBA buffer with filter byte per scanline
  const rowSize = 1 + width * 4;
  const rawData = Buffer.alloc(rowSize * height);

  for (let y = 0; y < height; y++) {
    const rowOffset = y * rowSize;
    rawData[rowOffset] = 0; // Filter: None
    for (let x = 0; x < width; x++) {
      const [r, g, b, a] = drawPixel(x, y, width, height);
      const pxOffset = rowOffset + 1 + x * 4;
      rawData[pxOffset] = r;
      rawData[pxOffset + 1] = g;
      rawData[pxOffset + 2] = b;
      rawData[pxOffset + 3] = a;
    }
  }

  const compressed = zlib.deflateSync(rawData);

  function crc32(buf) {
    let crc = -1;
    for (let i = 0; i < buf.length; i++) {
      crc ^= buf[i];
      for (let j = 0; j < 8; j++) {
        crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0);
      }
    }
    return (crc ^ -1) >>> 0;
  }

  function makeChunk(type, data) {
    const lenBuf = Buffer.alloc(4);
    lenBuf.writeUInt32BE(data.length, 0);
    const typeBuf = Buffer.from(type, 'ascii');
    const crcBuf = Buffer.alloc(4);
    const checksum = crc32(Buffer.concat([typeBuf, data]));
    crcBuf.writeUInt32BE(checksum, 0);
    return Buffer.concat([lenBuf, typeBuf, data, crcBuf]);
  }

  const header = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

  // IHDR
  const ihdrData = Buffer.alloc(13);
  ihdrData.writeUInt32BE(width, 0);
  ihdrData.writeUInt32BE(height, 4);
  ihdrData[8] = 8; // bit depth
  ihdrData[9] = 6; // color type: RGBA
  ihdrData[10] = 0; // compression
  ihdrData[11] = 0; // filter
  ihdrData[12] = 0; // interlace

  const ihdrChunk = makeChunk('IHDR', ihdrData);
  const idatChunk = makeChunk('IDAT', compressed);
  const iendChunk = makeChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([header, ihdrChunk, idatChunk, iendChunk]);
}

// Draw elegant icon: deep dark navy background (#090d16), cyan to emerald glowing soundwaves & mic
function renderYiuVoiceIcon(x, y, w, h, isMaskable = false) {
  const nx = (x / w) * 2 - 1;
  const ny = (y / h) * 2 - 1;
  const dist = Math.sqrt(nx * nx + ny * ny);

  // Background
  const bgR = 9;
  const bgG = 13;
  const bgB = 22;

  // Maskable keeps padding
  const scale = isMaskable ? 0.75 : 0.88;
  const sx = nx / scale;
  const sy = ny / scale;

  // Soundwave bars in center
  const bars = [
    { x: -0.55, height: 0.35, color: [6, 182, 212] },    // Cyan
    { x: -0.33, height: 0.65, color: [14, 165, 233] },   // Sky
    { x: -0.11, height: 0.85, color: [56, 189, 248] },   // Light blue
    { x: 0.11, height: 0.75, color: [52, 211, 153] },    // Emerald
    { x: 0.33, height: 0.50, color: [16, 185, 129] },    // Green
    { x: 0.55, height: 0.30, color: [245, 158, 11] },    // Amber
  ];

  let inBar = false;
  let barColor = [255, 255, 255];
  const barWidth = 0.08;

  for (const bar of bars) {
    if (Math.abs(sx - bar.x) <= barWidth / 2 && Math.abs(sy) <= bar.height / 2) {
      inBar = true;
      barColor = bar.color;
      break;
    }
  }

  // Radial subtle glow around center
  const glow = Math.max(0, 1 - dist * 1.1);
  const glowR = Math.round(bgR + glow * 18);
  const glowG = Math.round(bgG + glow * 35);
  const glowB = Math.round(bgB + glow * 55);

  if (inBar) {
    // Round the bar ends slightly
    return [barColor[0], barColor[1], barColor[2], 255];
  }

  // Rounded icon border on non-maskable
  if (!isMaskable && dist > 0.95) {
    return [0, 0, 0, 0]; // Transparent outer corners
  }

  return [glowR, glowG, glowB, 255];
}

const pwa192 = createPng(192, 192, (x, y, w, h) => renderYiuVoiceIcon(x, y, w, h, false));
const pwa512 = createPng(512, 512, (x, y, w, h) => renderYiuVoiceIcon(x, y, w, h, false));
const pwaMaskable = createPng(512, 512, (x, y, w, h) => renderYiuVoiceIcon(x, y, w, h, true));
const appleTouch = createPng(180, 180, (x, y, w, h) => renderYiuVoiceIcon(x, y, w, h, false));

if (!fs.existsSync('./public')) {
  fs.mkdirSync('./public', { recursive: true });
}

fs.writeFileSync('./public/pwa-192x192.png', pwa192);
fs.writeFileSync('./public/pwa-512x512.png', pwa512);
fs.writeFileSync('./public/pwa-maskable-512x512.png', pwaMaskable);
fs.writeFileSync('./public/apple-touch-icon.png', appleTouch);

console.log('Successfully generated all PWA PNG icons!');
