import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';

function createCRC32Table() {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) {
      c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    }
    table[i] = c;
  }
  return table;
}

const crcTable = createCRC32Table();

function crc32(buf) {
  let c = 0xFFFFFFFF;
  for (let i = 0; i < buf.length; i++) {
    c = crcTable[(c ^ buf[i]) & 0xFF] ^ (c >>> 8);
  }
  return (c ^ 0xFFFFFFFF) >>> 0;
}

function makeChunk(type, data) {
  const len = data.length;
  const chunk = Buffer.alloc(12 + len);
  chunk.writeUInt32BE(len, 0);
  chunk.write(type, 4, 4, 'ascii');
  data.copy(chunk, 8);
  const typeAndData = chunk.subarray(4, 8 + len);
  chunk.writeUInt32BE(crc32(typeAndData), 8 + len);
  return chunk;
}

function generatePNG(width, height, isMaskable = false) {
  // Create raw RGB scanlines with filter byte 0
  // Background: Deep vibrant orange/red (#EA580C) with cylinder and flame emblem
  const rowSize = 1 + width * 4;
  const rawData = Buffer.alloc(rowSize * height);

  const cx = width / 2;
  const cy = height / 2;
  const radius = width * 0.45;

  for (let y = 0; y < height; y++) {
    const rowOffset = y * rowSize;
    rawData[rowOffset] = 0; // Filter type 0 (None)

    for (let x = 0; x < width; x++) {
      const pxOffset = rowOffset + 1 + x * 4;
      const dx = x - cx;
      const dy = y - cy;
      const dist = Math.sqrt(dx * dx + dy * dy);

      // Base background: rounded badge or full background for maskable
      let r = 234, g = 88, b = 12, a = 255; // #ea580c (vibrant gas flame orange)

      if (!isMaskable) {
        // Rounded corner badge
        const cornerDist = Math.max(Math.abs(dx) - width * 0.35, 0) ** 2 + Math.max(Math.abs(dy) - height * 0.35, 0) ** 2;
        if (cornerDist > (width * 0.12) ** 2) {
          a = 0;
        }
      }

      if (a > 0) {
        // Darker top/bottom gradient
        const grad = 1 - (y / height) * 0.25;
        r = Math.floor(r * grad);
        g = Math.floor(g * grad);
        b = Math.floor(b * grad);

        // Cylinder Body: rectangle in center
        const cylWidth = width * 0.38;
        const cylTop = height * 0.30;
        const cylBottom = height * 0.82;
        const cylLeft = cx - cylWidth / 2;
        const cylRight = cx + cylWidth / 2;

        if (x >= cylLeft && x <= cylRight && y >= cylTop && y <= cylBottom) {
          // Inside cylinder body
          // Red cylinder #dc2626
          r = 220; g = 38; b = 38;
          // Shading highlight on cylinder
          const cylXNorm = (x - cylLeft) / cylWidth;
          if (cylXNorm > 0.15 && cylXNorm < 0.45) {
            r = Math.min(255, r + 45);
            g = Math.min(255, g + 35);
            b = Math.min(255, b + 35);
          }
          // Ring band in center
          if (Math.abs(y - (cylTop + cylBottom) / 2) < height * 0.02) {
            r = 185; g = 28; b = 28;
          }
        }

        // Cylinder Handle / Collar on top
        if (x >= cx - width * 0.22 && x <= cx + width * 0.22 && y >= height * 0.20 && y <= height * 0.30) {
          if (Math.abs(x - cx) > width * 0.14 || y <= height * 0.23) {
            r = 185; g = 28; b = 28;
          }
        }

        // Valve / Flame in middle top
        const flameDy = y - height * 0.25;
        const flameDx = x - cx;
        if (flameDy >= -height * 0.12 && flameDy <= 0) {
          const flameW = (1 - (-flameDy / (height * 0.12))) * (width * 0.08);
          if (Math.abs(flameDx) <= flameW) {
            // Bright blue/yellow flame
            r = 250; g = 204; b = 21; // golden yellow
          }
        }
      }

      rawData[pxOffset] = r;
      rawData[pxOffset + 1] = g;
      rawData[pxOffset + 2] = b;
      rawData[pxOffset + 3] = a;
    }
  }

  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  // IHDR
  const ihdrData = Buffer.alloc(13);
  ihdrData.writeUInt32BE(width, 0);
  ihdrData.writeUInt32BE(height, 4);
  ihdrData[8] = 8; // bit depth
  ihdrData[9] = 6; // color type RGBA
  ihdrData[10] = 0; // compression
  ihdrData[11] = 0; // filter
  ihdrData[12] = 0; // interlace
  const ihdrChunk = makeChunk('IHDR', ihdrData);

  // IDAT
  const compressed = zlib.deflateSync(rawData);
  const idatChunk = makeChunk('IDAT', compressed);

  // IEND
  const iendChunk = makeChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

const outDir = path.resolve('public');
if (!fs.existsSync(outDir)) {
  fs.mkdirSync(outDir, { recursive: true });
}

fs.writeFileSync(path.join(outDir, 'pwa-192x192.png'), generatePNG(192, 192, false));
fs.writeFileSync(path.join(outDir, 'pwa-512x512.png'), generatePNG(512, 512, false));
fs.writeFileSync(path.join(outDir, 'pwa-maskable-512x512.png'), generatePNG(512, 512, true));
fs.writeFileSync(path.join(outDir, 'apple-touch-icon.png'), generatePNG(180, 180, false));
fs.writeFileSync(path.join(outDir, 'favicon.ico'), generatePNG(64, 64, false));

console.log('PWA icons created successfully in public/');
