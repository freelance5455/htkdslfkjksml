import fs from 'fs';
import path from 'path';
import zlib from 'zlib';

function createTeacherIconPng(width, height) {
  const bytesPerPixel = 4;
  const lineSize = 1 + width * bytesPerPixel;
  const rawData = Buffer.alloc(lineSize * height);

  for (let y = 0; y < height; y++) {
    const lineOffset = y * lineSize;
    rawData[lineOffset] = 0;
    for (let x = 0; x < width; x++) {
      const pxOffset = lineOffset + 1 + x * bytesPerPixel;
      const dx = x - width / 2;
      const dy = y - height / 2;
      const dist = Math.sqrt(dx * dx + dy * dy);

      // Deep dark base
      let r = 18, g = 18, b = 20, a = 255;

      if (dist < width * 0.46) {
        // Rose teacher circle
        r = 225; g = 29; b = 72;
      }
      if (dist < width * 0.44 && dist > width * 0.42) {
        // Gold rim
        r = 251; g = 191; b = 36;
      }
      if (dist < width * 0.28) {
        // Warm teacher skin & face glow
        r = 254; g = 222; b = 201;
      }
      if (dist < width * 0.12) {
        // Gold glasses & eyes
        r = 245; g = 158; b = 11;
      }

      rawData[pxOffset] = r;
      rawData[pxOffset + 1] = g;
      rawData[pxOffset + 2] = b;
      rawData[pxOffset + 3] = a;
    }
  }

  const deflated = zlib.deflateSync(rawData);
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  function makeChunk(type, data) {
    const len = Buffer.alloc(4);
    len.writeUInt32BE(data.length, 0);
    const typeBuf = Buffer.from(type, 'ascii');
    const crcBuf = Buffer.alloc(4);
    const crcData = Buffer.concat([typeBuf, data]);
    const crc = crc32(crcData);
    crcBuf.writeUInt32BE(crc, 0);
    return Buffer.concat([len, typeBuf, data, crcBuf]);
  }

  function crc32(buf) {
    let crc = -1;
    for (let i = 0; i < buf.length; i++) {
      crc = (crc >>> 8) ^ table[(crc ^ buf[i]) & 0xff];
    }
    return (crc ^ -1) >>> 0;
  }

  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let j = 0; j < 8; j++) {
      c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    }
    table[i] = c;
  }

  const ihdrData = Buffer.alloc(13);
  ihdrData.writeUInt32BE(width, 0);
  ihdrData.writeUInt32BE(height, 4);
  ihdrData[8] = 8;
  ihdrData[9] = 6;
  ihdrData[10] = 0;
  ihdrData[11] = 0;
  ihdrData[12] = 0;

  const ihdr = makeChunk('IHDR', ihdrData);
  const idat = makeChunk('IDAT', deflated);
  const iend = makeChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdr, idat, iend]);
}

const publicDir = path.resolve('public');
fs.writeFileSync(path.join(publicDir, 'pwa-192x192.png'), createTeacherIconPng(192, 192));
fs.writeFileSync(path.join(publicDir, 'pwa-512x512.png'), createTeacherIconPng(512, 512));
fs.writeFileSync(path.join(publicDir, 'pwa-maskable-512x512.png'), createTeacherIconPng(512, 512));
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), createTeacherIconPng(180, 180));
console.log('Teacher girl PNG icons refreshed!');
