import fs from 'fs';
import path from 'path';
import zlib from 'zlib';

const publicDir = path.resolve(process.cwd(), 'public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

// 1. Create clean, attractive SVG icon
const svgContent = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#2563eb" />
      <stop offset="50%" stop-color="#4f46e5" />
      <stop offset="100%" stop-color="#1e1b4b" />
    </linearGradient>
    <linearGradient id="screenGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#38bdf8" />
      <stop offset="100%" stop-color="#0284c7" />
    </linearGradient>
  </defs>
  <!-- Background with rounded corners -->
  <rect width="512" height="512" rx="110" fill="url(#bgGrad)" />
  
  <!-- Outer Smartphone Frame -->
  <rect x="140" y="80" width="232" height="352" rx="36" fill="#ffffff" fill-opacity="0.12" stroke="#ffffff" stroke-width="12" />
  
  <!-- Screen Area (LCD) -->
  <rect x="160" y="120" width="192" height="260" rx="18" fill="url(#screenGrad)" />
  
  <!-- Microchip / Spare Parts Circuit Pattern on Screen -->
  <circle cx="210" cy="180" r="14" fill="#ffffff" />
  <circle cx="302" cy="180" r="14" fill="#ffffff" />
  <circle cx="256" cy="250" r="22" fill="#ffffff" />
  <line x1="210" y1="180" x2="256" y2="250" stroke="#ffffff" stroke-width="8" stroke-linecap="round" />
  <line x1="302" y1="180" x2="256" y2="250" stroke="#ffffff" stroke-width="8" stroke-linecap="round" />
  <line x1="256" y1="250" x2="256" y2="330" stroke="#ffffff" stroke-width="8" stroke-linecap="round" />
  <circle cx="256" cy="330" r="12" fill="#facc15" />
  
  <!-- Speaker notch -->
  <rect x="226" y="98" width="60" height="8" rx="4" fill="#ffffff" fill-opacity="0.6" />
  <!-- Home indicator line -->
  <rect x="226" y="396" width="60" height="6" rx="3" fill="#ffffff" fill-opacity="0.6" />
</svg>`;

fs.writeFileSync(path.join(publicDir, 'icon.svg'), svgContent);
fs.writeFileSync(path.join(publicDir, 'favicon.ico'), svgContent);

// Helper function to create raw RGBA PNG image buffer
function createPngBuffer(width, height, isMaskable = false) {
  // Simple CRC32 implementation
  const crcTable = [];
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    }
    crcTable[n] = c >>> 0;
  }
  function crc32(buf) {
    let c = 0xffffffff;
    for (let i = 0; i < buf.length; i++) {
      c = (crcTable[(c ^ buf[i]) & 0xff] ^ (c >>> 8)) >>> 0;
    }
    return (c ^ 0xffffffff) >>> 0;
  }

  function makeChunk(type, data) {
    const len = data.length;
    const chunk = Buffer.alloc(12 + len);
    chunk.writeUInt32BE(len, 0);
    chunk.write(type, 4, 4, 'ascii');
    data.copy(chunk, 8);
    const crc = crc32(chunk.subarray(4, 8 + len));
    chunk.writeUInt32BE(crc, 8 + len);
    return chunk;
  }

  // PNG Header
  const header = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  // IHDR
  const ihdrData = Buffer.alloc(13);
  ihdrData.writeUInt32BE(width, 0);
  ihdrData.writeUInt32BE(height, 4);
  ihdrData[8] = 8; // 8 bits per channel
  ihdrData[9] = 6; // color type RGBA
  ihdrData[10] = 0; // compression
  ihdrData[11] = 0; // filter
  ihdrData[12] = 0; // interlace
  const ihdrChunk = makeChunk('IHDR', ihdrData);

  // Raw image scanlines (each row starts with filter byte 0)
  const scanlines = Buffer.alloc(height * (1 + width * 4));
  let offset = 0;
  const cx = width / 2;
  const cy = height / 2;
  const rCorner = width * 0.22;

  for (let y = 0; y < height; y++) {
    scanlines[offset++] = 0; // None filter
    for (let x = 0; x < width; x++) {
      // Background gradient (blue to indigo)
      const t = (x + y) / (width + height);
      let r = Math.round(37 + (30 - 37) * t);
      let g = Math.round(99 + (27 - 99) * t);
      let b = Math.round(235 + (75 - 235) * t);
      let a = 255;

      // Inner Phone Screen Graphic
      const phoneLeft = width * 0.28;
      const phoneRight = width * 0.72;
      const phoneTop = height * 0.16;
      const phoneBottom = height * 0.84;

      if (x >= phoneLeft && x <= phoneRight && y >= phoneTop && y <= phoneBottom) {
        // Phone frame border
        if (
          x <= phoneLeft + width * 0.03 ||
          x >= phoneRight - width * 0.03 ||
          y <= phoneTop + height * 0.03 ||
          y >= phoneBottom - height * 0.03
        ) {
          r = 255; g = 255; b = 255; a = 230;
        } else {
          // Screen LCD (cyan gradient)
          const screenT = (y - phoneTop) / (phoneBottom - phoneTop);
          r = Math.round(56 + (2 - 56) * screenT);
          g = Math.round(189 + (132 - 189) * screenT);
          b = Math.round(248 + (199 - 248) * screenT);
          a = 255;

          // Circuit dots & connection
          const dx = x - cx;
          const dy = y - cy;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < width * 0.06) {
            r = 255; g = 255; b = 255; a = 255;
          }
        }
      }

      // Rounded mask if not maskable
      if (!isMaskable) {
        const dx = Math.abs(x - cx) - (cx - rCorner);
        const dy = Math.abs(y - cy) - (cy - rCorner);
        if (dx > 0 && dy > 0 && (dx * dx + dy * dy) > rCorner * rCorner) {
          a = 0; // transparent corner
        }
      }

      scanlines[offset++] = r;
      scanlines[offset++] = g;
      scanlines[offset++] = b;
      scanlines[offset++] = a;
    }
  }

  const idatData = zlib.deflateSync(scanlines);
  const idatChunk = makeChunk('IDAT', idatData);
  const iendChunk = makeChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([header, ihdrChunk, idatChunk, iendChunk]);
}

// Generate standard PWA icons
fs.writeFileSync(path.join(publicDir, 'pwa-192x192.png'), createPngBuffer(192, 192, false));
fs.writeFileSync(path.join(publicDir, 'pwa-512x512.png'), createPngBuffer(512, 512, false));
fs.writeFileSync(path.join(publicDir, 'pwa-maskable-512x512.png'), createPngBuffer(512, 512, true));
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), createPngBuffer(180, 180, false));

console.log('Successfully generated PWA icon assets in public/');
