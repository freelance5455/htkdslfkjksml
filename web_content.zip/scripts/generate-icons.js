import fs from 'fs';
import path from 'path';
import { PNG } from 'pngjs';

const publicDir = path.resolve('./public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

// 1. Create public/icon.svg
const svgContent = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0284c7"/>
      <stop offset="100%" stop-color="#0f172a"/>
    </linearGradient>
    <linearGradient id="tGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#38bdf8"/>
      <stop offset="100%" stop-color="#06b6d4"/>
    </linearGradient>
    <linearGradient id="laser" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#00f0ff" stop-opacity="0"/>
      <stop offset="50%" stop-color="#00f0ff" stop-opacity="1"/>
      <stop offset="100%" stop-color="#00f0ff" stop-opacity="0"/>
    </linearGradient>
  </defs>
  <rect width="512" height="512" rx="110" fill="url(#bg)"/>
  <!-- Barcode stylized stripes in background -->
  <g fill="#ffffff" opacity="0.1">
    <rect x="110" y="320" width="16" height="70" rx="4"/>
    <rect x="140" y="320" width="8" height="70" rx="3"/>
    <rect x="160" y="320" width="28" height="70" rx="4"/>
    <rect x="200" y="320" width="12" height="70" rx="3"/>
    <rect x="224" y="320" width="24" height="70" rx="4"/>
    <rect x="260" y="320" width="8" height="70" rx="3"/>
    <rect x="280" y="320" width="32" height="70" rx="4"/>
    <rect x="324" y="320" width="16" height="70" rx="3"/>
    <rect x="352" y="320" width="24" height="70" rx="4"/>
    <rect x="388" y="320" width="14" height="70" rx="3"/>
  </g>
  <!-- Main T lettermark -->
  <path d="M 160 140 H 352 C 365 140 376 151 376 164 C 376 177 365 188 352 188 H 284 V 356 C 284 369 273 380 260 380 C 247 380 236 369 236 356 V 188 H 160 C 147 188 136 177 136 164 C 136 151 147 140 160 140 Z" fill="url(#tGrad)"/>
  <!-- Scan laser line -->
  <rect x="70" y="270" width="372" height="6" fill="url(#laser)"/>
  <!-- Dot accent -->
  <circle cx="340" cy="350" r="16" fill="#38bdf8"/>
</svg>`;

fs.writeFileSync(path.join(publicDir, 'icon.svg'), svgContent);

// Helper to draw clean rounded badge with T and barcode laser
function generateIconPNG(size, isMaskable = false) {
  const png = new PNG({ width: size, height: size });
  const scale = size / 512;
  const padding = isMaskable ? size * 0.12 : 0;
  const innerSize = size - (padding * 2);

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const idx = (size * y + x) << 2;

      // Maskable uses full bleed background, standard has rounded corner
      let inShape = true;
      if (!isMaskable) {
        const radius = 95 * scale;
        const cornerDist = (px, py, cx, cy) => Math.hypot(px - cx, py - cy);
        if (x < radius && y < radius) inShape = cornerDist(x, y, radius, radius) <= radius;
        else if (x > size - radius && y < radius) inShape = cornerDist(x, y, size - radius, radius) <= radius;
        else if (x < radius && y > size - radius) inShape = cornerDist(x, y, radius, size - radius) <= radius;
        else if (x > size - radius && y > size - radius) inShape = cornerDist(x, y, size - radius, size - radius) <= radius;
      }

      if (!inShape) {
        png.data[idx] = 0;
        png.data[idx + 1] = 0;
        png.data[idx + 2] = 0;
        png.data[idx + 3] = 0;
        continue;
      }

      // Background gradient from dark slate #0f172a to cyan #0284c7
      const t = (x + y) / (size * 2);
      const rBg = Math.round(15 * (1 - t) + 2 * t);
      const gBg = Math.round(23 * (1 - t) + 132 * t);
      const bBg = Math.round(42 * (1 - t) + 199 * t);

      let r = rBg;
      let g = gBg;
      let b = bBg;

      // Coordinate mapped to 512x512 space
      const normX = ((x - padding) / innerSize) * 512;
      const normY = ((y - padding) / innerSize) * 512;

      // Draw T letter in center
      // Horizontal bar: 150 <= normX <= 362 && 140 <= normY <= 195
      // Vertical stem: 232 <= normX <= 280 && 195 <= normY <= 365
      const inHorizBar = normX >= 145 && normX <= 367 && normY >= 135 && normY <= 195;
      const inVertStem = normX >= 232 && normX <= 280 && normY >= 185 && normY <= 365;

      // Laser line: normY >= 265 && normY <= 273 && normX >= 80 && normX <= 432
      const inLaser = normY >= 266 && normY <= 272 && normX >= 80 && normX <= 432;

      // Barcode bars at bottom
      const inBarcodeArea = normY >= 310 && normY <= 360;
      const inBarcodeBar = inBarcodeArea && (
        (normX >= 110 && normX <= 126) ||
        (normX >= 140 && normX <= 148) ||
        (normX >= 162 && normX <= 186) ||
        (normX >= 315 && normX <= 330) ||
        (normX >= 345 && normX <= 365) ||
        (normX >= 380 && normX <= 394)
      );

      if (inBarcodeBar) {
        r = Math.min(255, r + 45);
        g = Math.min(255, g + 70);
        b = Math.min(255, b + 90);
      }

      if (inHorizBar || inVertStem) {
        // Cyan-Sky blue gradient
        r = 56;
        g = 189;
        b = 248;
      }

      if (inLaser) {
        // Bright cyan laser
        const laserDist = Math.abs(normX - 256) / 176;
        const laserIntensity = Math.max(0, 1 - laserDist);
        r = Math.round(r * (1 - laserIntensity) + 0 * laserIntensity);
        g = Math.round(g * (1 - laserIntensity) + 240 * laserIntensity);
        b = Math.round(b * (1 - laserIntensity) + 255 * laserIntensity);
      }

      png.data[idx] = r;
      png.data[idx + 1] = g;
      png.data[idx + 2] = b;
      png.data[idx + 3] = 255;
    }
  }

  return PNG.sync.write(png);
}

// Generate icons
fs.writeFileSync(path.join(publicDir, 'pwa-192x192.png'), generateIconPNG(192, false));
fs.writeFileSync(path.join(publicDir, 'pwa-512x512.png'), generateIconPNG(512, false));
fs.writeFileSync(path.join(publicDir, 'pwa-maskable-512x512.png'), generateIconPNG(512, true));
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), generateIconPNG(180, false));
fs.writeFileSync(path.join(publicDir, 'favicon.ico'), generateIconPNG(64, false));

console.log('Successfully generated all PWA & Android app icons in /public');
