import sharp from 'sharp';
import fs from 'fs';
import path from 'path';

const svg = `<svg viewBox="0 0 512 512" width="1024" height="1024" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <!-- Background Gradient -->
    <radialGradient id="bgGrad" cx="50%" cy="50%" r="70%">
      <stop offset="0%" stop-color="#0f152d"/>
      <stop offset="65%" stop-color="#090b14"/>
      <stop offset="100%" stop-color="#05060a"/>
    </radialGradient>

    <!-- Sphere Body Gradient -->
    <radialGradient id="sphereCoreGrad" cx="38%" cy="32%" r="65%">
      <stop offset="0%" stop-color="#67e8f9" />
      <stop offset="28%" stop-color="#06b6d4" />
      <stop offset="68%" stop-color="#4f46e5" />
      <stop offset="92%" stop-color="#0f172a" />
      <stop offset="100%" stop-color="#05070f" />
    </radialGradient>

    <!-- Rings Gradients -->
    <linearGradient id="ringGradCyan" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#22d3ee" />
      <stop offset="50%" stop-color="#a855f7" />
      <stop offset="100%" stop-color="#f43f5e" />
    </linearGradient>

    <linearGradient id="ringGradViolet" x1="100%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#c084fc" />
      <stop offset="60%" stop-color="#38bdf8" />
      <stop offset="100%" stop-color="#4f46e5" />
    </linearGradient>

    <!-- Soundwave Gradient -->
    <linearGradient id="whisperWave" x1="0%" y1="50%" x2="100%" y2="50%">
      <stop offset="0%" stop-color="#a5f3fc" stop-opacity="0.3" />
      <stop offset="50%" stop-color="#ffffff" stop-opacity="1" />
      <stop offset="100%" stop-color="#c084fc" stop-opacity="0.3" />
    </linearGradient>

    <!-- Filter for Glow -->
    <filter id="neonGlowFilter" x="-40%" y="-40%" width="180%" height="180%">
      <feGaussianBlur stdDeviation="8" result="blur" />
      <feMerge>
        <feMergeNode in="blur" />
        <feMergeNode in="SourceGraphic" />
      </feMerge>
    </filter>
  </defs>

  <!-- Dark Obsidian Background -->
  <rect width="512" height="512" fill="url(#bgGrad)"/>
  
  <!-- Outer Whispering Soundwave Ring -->
  <circle cx="256" cy="256" r="215" stroke="url(#ringGradCyan)" stroke-width="4.5" stroke-dasharray="14 18" opacity="0.6"/>

  <!-- Orbital Ellipse 1 (Tilted West-East) -->
  <ellipse cx="256" cy="256" rx="205" ry="92" transform="rotate(-28 256 256)" stroke="url(#ringGradCyan)" stroke-width="8.5" stroke-linecap="round" opacity="0.88"/>

  <!-- Orbital Ellipse 2 (Counter-tilted) -->
  <ellipse cx="256" cy="256" rx="200" ry="86" transform="rotate(42 256 256)" stroke="url(#ringGradViolet)" stroke-width="6.5" stroke-dasharray="24 16" opacity="0.75"/>

  <!-- Solid Holographic Sphere Body -->
  <circle cx="256" cy="256" r="145" fill="url(#sphereCoreGrad)" stroke="#38bdf8" stroke-width="6.5" stroke-opacity="0.9"/>

  <!-- Sphere Specular Highlight (Glass Shine) -->
  <ellipse cx="210" cy="190" rx="55" ry="32" transform="rotate(-30 210 190)" fill="#ffffff" fill-opacity="0.45"/>

  <!-- Internal Secret Frequency / Whispering Voice Waveform -->
  <path d="M 155 256 Q 182 208, 210 256 T 256 256 T 302 256 T 357 256" stroke="url(#whisperWave)" stroke-width="11" stroke-linecap="round" fill="none" filter="url(#neonGlowFilter)"/>
  <path d="M 180 256 Q 220 175, 256 256 T 332 256" stroke="#ffffff" stroke-width="6.5" stroke-linecap="round" fill="none" opacity="0.9"/>

  <!-- Center Energy Core Spark -->
  <circle cx="256" cy="256" r="15" fill="#ffffff" filter="url(#neonGlowFilter)" />

  <!-- Orbiting Secret Nodes (Energy spark particles) -->
  <circle cx="400" cy="178" r="12" fill="#22d3ee" filter="url(#neonGlowFilter)"/>
  <circle cx="120" cy="326" r="10.5" fill="#f43f5e"/>
  <circle cx="348" cy="365" r="9.5" fill="#c084fc"/>
</svg>`;

async function main() {
  const publicDir = path.resolve('public');
  if (!fs.existsSync(publicDir)) {
    fs.mkdirSync(publicDir, { recursive: true });
  }

  // 1. Save SVG
  fs.writeFileSync(path.join(publicDir, 'logo.svg'), svg);
  console.log('Saved logo.svg');

  // 2. Render 1024x1024 PNG
  await sharp(Buffer.from(svg))
    .resize(1024, 1024)
    .png()
    .toFile(path.join(publicDir, 'logo.png'));
  console.log('Saved 1024x1024 logo.png');

  // 3. Copy to icon.png
  fs.copyFileSync(path.join(publicDir, 'logo.png'), path.join(publicDir, 'icon.png'));
  console.log('Saved 1024x1024 icon.png');

  // 4. Transparent foreground version
  const transparentSvg = svg.replace('<rect width="512" height="512" fill="url(#bgGrad)"/>', '');
  await sharp(Buffer.from(transparentSvg))
    .resize(1024, 1024)
    .png()
    .toFile(path.join(publicDir, 'logo-foreground.png'));
  console.log('Saved 1024x1024 logo-foreground.png');
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
