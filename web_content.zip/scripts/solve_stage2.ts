import fs from 'fs';
import { STAGE_02_QUESTIONS } from '../src/data/stage02Questions';
import { normalizeArabicString } from '../src/engine/normalization';
import { validateCrosswordLayout } from '../src/engine/CrosswordValidator';
import {
  CrosswordLayout,
  CrosswordLayoutWord,
  CrosswordLayoutCell,
  LayoutCellCoordinate,
  CrosswordLayoutClue
} from '../src/types/crosswordLayout';

function cleanWord(str: string): string {
  return normalizeArabicString(str.replace(/\s+/g, ''));
}

const rawWords = STAGE_02_QUESTIONS.map((q) => {
  const norm = cleanWord(q.answer);
  return {
    id: q.id,
    clue: q.clue,
    answer: q.answer,
    norm: norm,
    len: norm.length
  };
});

console.log('Words to place:', rawWords.length);
rawWords.forEach((w) => {
  console.log(`${w.id}: ${w.answer} => norm: "${w.norm}" (len: ${w.len})`);
});

type Dir = 'across' | 'down';

interface Placement {
  wordId: string;
  clue: string;
  answer: string;
  norm: string;
  len: number;
  dir: Dir;
  r: number;
  c: number;
  reversed: boolean;
}

function solveStage2(GRID_SIZE: number, maxRestarts = 20000): Placement[] | null {
  const words = [...rawWords].sort((a, b) => b.len - a.len);

  for (let restart = 0; restart < maxRestarts; restart++) {
    if (restart % 1000 === 0 && restart > 0) {
      console.log(`Restart ${restart}...`);
    }

    const grid: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
    const cellAcross: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
    const cellDown: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));

    function canPlace(
      wStr: string,
      dir: Dir,
      r: number,
      c: number,
      placedCount: number
    ): { valid: boolean; inters: number } {
      const len = wStr.length;
      if (dir === 'across') {
        if (c < 0 || c + len > GRID_SIZE || r < 0 || r >= GRID_SIZE) return { valid: false, inters: 0 };
        if (c > 0 && grid[r][c - 1] !== null) return { valid: false, inters: 0 };
        if (c + len < GRID_SIZE && grid[r][c + len] !== null) return { valid: false, inters: 0 };

        let touches = placedCount === 0;
        let inters = 0;

        for (let k = 0; k < len; k++) {
          const cur = grid[r][c + k];
          if (cur !== null) {
            if (cur !== wStr[k]) return { valid: false, inters: 0 };
            if (cellAcross[r][c + k] !== null) return { valid: false, inters: 0 };
            touches = true;
            inters++;
          } else {
            // Parallel isolation: adjacent above/below cannot have letters unless it is a cross
            if (r > 0 && grid[r - 1][c + k] !== null) return { valid: false, inters: 0 };
            if (r < GRID_SIZE - 1 && grid[r + 1][c + k] !== null) return { valid: false, inters: 0 };
          }
        }
        return { valid: touches, inters };
      } else {
        if (r < 0 || r + len > GRID_SIZE || c < 0 || c >= GRID_SIZE) return { valid: false, inters: 0 };
        if (r > 0 && grid[r - 1][c] !== null) return { valid: false, inters: 0 };
        if (r + len < GRID_SIZE && grid[r + len][c] !== null) return { valid: false, inters: 0 };

        let touches = placedCount === 0;
        let inters = 0;

        for (let k = 0; k < len; k++) {
          const cur = grid[r + k][c];
          if (cur !== null) {
            if (cur !== wStr[k]) return { valid: false, inters: 0 };
            if (cellDown[r + k][c] !== null) return { valid: false, inters: 0 };
            touches = true;
            inters++;
          } else {
            // Parallel isolation
            if (c > 0 && grid[r + k][c - 1] !== null) return { valid: false, inters: 0 };
            if (c < GRID_SIZE - 1 && grid[r + k][c + 1] !== null) return { valid: false, inters: 0 };
          }
        }
        return { valid: touches, inters };
      }
    }

    function doPlace(w: typeof words[0], dir: Dir, r: number, c: number, reversed: boolean) {
      const wStr = reversed ? w.norm.split('').reverse().join('') : w.norm;
      const len = wStr.length;
      if (dir === 'across') {
        for (let k = 0; k < len; k++) {
          grid[r][c + k] = wStr[k];
          cellAcross[r][c + k] = w.id;
        }
      } else {
        for (let k = 0; k < len; k++) {
          grid[r + k][c] = wStr[k];
          cellDown[r + k][c] = w.id;
        }
      }
    }

    const placed: Placement[] = [];

    // 1. Place the longest word (q_08 - منارة الإسكندرية, len 15)
    const longest = words[0];
    const firstDir: Dir = Math.random() > 0.5 ? 'across' : 'down';
    const firstR = firstDir === 'across' ? Math.floor(Math.random() * (GRID_SIZE - 4)) : 0;
    const firstC = firstDir === 'across' ? 0 : Math.floor(Math.random() * (GRID_SIZE - 4));
    const firstRev = false;

    doPlace(longest, firstDir, firstR, firstC, firstRev);
    placed.push({
      wordId: longest.id,
      clue: longest.clue,
      answer: longest.answer,
      norm: longest.norm,
      len: longest.len,
      dir: firstDir,
      r: firstR,
      c: firstC,
      reversed: firstRev
    });

    const unplaced = words.slice(1);

    // Iteratively place remaining words using MRV/Best overlap
    while (unplaced.length > 0) {
      type Candidate = {
        wordIdx: number;
        dir: Dir;
        r: number;
        c: number;
        reversed: boolean;
        inters: number;
      };

      const candidates: Candidate[] = [];

      for (let wIdx = 0; wIdx < unplaced.length; wIdx++) {
        const w = unplaced[wIdx];
        const dirs: Dir[] = ['across', 'down'];
        const revOptions = [false, true];

        for (const dir of dirs) {
          for (const rev of revOptions) {
            const wStr = rev ? w.norm.split('').reverse().join('') : w.norm;
            for (let r = 0; r < GRID_SIZE; r++) {
              for (let c = 0; c < GRID_SIZE; c++) {
                const res = canPlace(wStr, dir, r, c, placed.length);
                if (res.valid && res.inters >= 1) {
                  candidates.push({
                    wordIdx: wIdx,
                    dir,
                    r,
                    c,
                    reversed: rev,
                    inters: res.inters
                  });
                }
              }
            }
          }
        }
      }

      if (candidates.length === 0) {
        break; // dead end
      }

      // Sort candidates by highest intersections, then word length
      candidates.sort((a, b) => {
        if (b.inters !== a.inters) return b.inters - a.inters;
        return unplaced[b.wordIdx].len - unplaced[a.wordIdx].len;
      });

      // Pick from top candidates with small randomization
      const topPool = candidates.slice(0, Math.min(6, candidates.length));
      const chosen = topPool[Math.floor(Math.random() * topPool.length)];

      const wordToPlace = unplaced[chosen.wordIdx];
      doPlace(wordToPlace, chosen.dir, chosen.r, chosen.c, chosen.reversed);
      placed.push({
        wordId: wordToPlace.id,
        clue: wordToPlace.clue,
        answer: wordToPlace.answer,
        norm: wordToPlace.norm,
        len: wordToPlace.len,
        dir: chosen.dir,
        r: chosen.r,
        c: chosen.c,
        reversed: chosen.reversed
      });

      unplaced.splice(chosen.wordIdx, 1);
    }

    if (placed.length === 25) {
      console.log(`🎉 SUCCESS! Solved Stage 2 in restart ${restart}!`);
      return placed;
    }
  }

  return null;
}

// Try solving with 15x15 or 16x16
let result = solveStage2(15, 30000);
let finalGridSize = 15;
if (!result) {
  console.log('Trying 16x16 grid...');
  result = solveStage2(16, 50000);
  finalGridSize = 16;
}

if (!result) {
  console.error('Could not solve in given iterations');
  process.exit(1);
}

// Build Layout Object and Validate
const GRID_SIZE = finalGridSize;
const gridLetters: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
const acrossMap: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
const downMap: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));

for (const p of result) {
  const wStr = p.reversed ? p.norm.split('').reverse().join('') : p.norm;
  for (let k = 0; k < p.len; k++) {
    const r = p.dir === 'down' ? p.r + k : p.r;
    const c = p.dir === 'across' ? p.c + k : p.c;
    gridLetters[r][c] = wStr[k];
    if (p.dir === 'across') acrossMap[r][c] = p.wordId;
    else downMap[r][c] = p.wordId;
  }
}

// Compute Clue Numbers based on standard crossword scanning order
let clueNum = 1;
const wordNumberMap = new Map<string, number>();
const cellNumberMap = new Map<string, number>();

for (let r = 0; r < GRID_SIZE; r++) {
  for (let c = 0; c < GRID_SIZE; c++) {
    if (gridLetters[r][c] === null) continue;

    let hasStart = false;
    const startAcross = result.find((p) => p.dir === 'across' && p.r === r && p.c === c);
    const startDown = result.find((p) => p.dir === 'down' && p.r === r && p.c === c);

    if (startAcross) {
      wordNumberMap.set(startAcross.wordId, clueNum);
      hasStart = true;
    }
    if (startDown) {
      wordNumberMap.set(startDown.wordId, clueNum);
      hasStart = true;
    }

    if (hasStart) {
      cellNumberMap.set(`${r}_${c}`, clueNum);
      clueNum++;
    }
  }
}

const cells: CrosswordLayoutCell[] = [];
const blackCells: LayoutCellCoordinate[] = [];

for (let r = 0; r < GRID_SIZE; r++) {
  for (let c = 0; c < GRID_SIZE; c++) {
    const letter = gridLetters[r][c];
    if (letter === null) {
      cells.push({
        row: r,
        column: c,
        isBlocked: true,
        letter: ''
      });
      blackCells.push({ row: r, col: c });
    } else {
      const num = cellNumberMap.get(`${r}_${c}`);
      cells.push({
        row: r,
        column: c,
        isBlocked: false,
        letter,
        number: num,
        acrossWordId: acrossMap[r][c] || undefined,
        downWordId: downMap[r][c] || undefined
      });
    }
  }
}

const words: CrosswordLayoutWord[] = result.map((p) => {
  const number = wordNumberMap.get(p.wordId) || 1;
  const wordCells: LayoutCellCoordinate[] = [];
  for (let k = 0; k < p.len; k++) {
    const r = p.dir === 'down' ? p.r + k : p.r;
    const c = p.dir === 'across' ? p.c + k : p.c;
    wordCells.push({ row: r, col: c });
  }

  return {
    id: p.wordId,
    clue: p.clue,
    answer: p.answer,
    normalizedAnswer: p.norm,
    direction: p.dir,
    startRow: p.r,
    startColumn: p.c,
    length: p.len,
    cells: wordCells,
    number,
    reversed: p.reversed
  };
});

// Sort words by number, then direction
words.sort((a, b) => {
  if (a.number !== b.number) return a.number - b.number;
  return a.direction === 'across' ? -1 : 1;
});

const clues: CrosswordLayoutClue[] = words.map((w) => ({
  number: w.number,
  clue: w.clue,
  direction: w.direction,
  length: w.length,
  wordId: w.id,
  reversed: w.reversed
}));

const layout: CrosswordLayout = {
  gridRows: GRID_SIZE,
  gridColumns: GRID_SIZE,
  cells,
  words,
  clues,
  blackCells
};

// Validate layout
const validation = validateCrosswordLayout(layout);
console.log('\n--- Validation Result for Stage 2 ---');
console.log('isValid:', validation.isValid);
validation.items.forEach((item) => {
  console.log(`${item.passed ? '✓' : '✗'} ${item.label}: ${item.message}`);
});

if (validation.isValid) {
  fs.writeFileSync('src/data/golden_stage_02.json', JSON.stringify(layout, null, 2), 'utf-8');
  console.log('\n✨ Saved golden_stage_02.json successfully!');
} else {
  console.error('Validation failed!');
  process.exit(1);
}
