import puppeteer from "puppeteer-core";
import { createServer } from "http";
import { readFileSync, existsSync } from "fs";
import { extname, join } from "path";

const MIME = { ".html": "text/html", ".js": "text/javascript", ".css": "text/css", ".png": "image/png" };
const root = process.cwd() + "/dist";
const server = createServer((req, res) => {
  let p = decodeURIComponent(req.url.split("?")[0]);
  if (p === "/") p = "/index.html";
  const f = join(root, p);
  if (!existsSync(f)) { res.writeHead(404); res.end("nf"); return; }
  res.writeHead(200, { "Content-Type": MIME[extname(f)] || "application/octet-stream" });
  res.end(readFileSync(f));
});
await new Promise((r) => server.listen(4173, r));
const browser = await puppeteer.launch({
  executablePath: "/usr/bin/chromium", headless: "new",
  args: ["--no-sandbox", "--disable-setuid-sandbox", "--use-gl=swiftshader", "--enable-unsafe-swiftshader", "--disable-dev-shm-usage"],
});
const errors = [];
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const results = [];
const check = (name, cond, extra = "") => { results.push([cond, name, extra]); console.log((cond ? "  ok  " : "  FAIL") + " | " + name + (extra ? " (" + extra + ")" : "")); };

const page = await browser.newPage();
await page.setViewport({ width: 1280, height: 720 });
page.on("console", (m) => { if (m.type() === "error") errors.push("console: " + m.text()); });
page.on("pageerror", (e) => errors.push("pageerror: " + e.message));
const body = () => page.evaluate(() => document.body.innerText);
const clickText = async (txt) => page.evaluate((t) => {
  const b = [...document.querySelectorAll("button")].find((x) => x.innerText.trim().includes(t));
  if (b) { b.click(); return true; } return false;
}, txt);
const hold = async (key, ms) => { await page.keyboard.down(key); await wait(ms); await page.keyboard.up(key); };
const skipType = async () => { await page.keyboard.press("Space"); await wait(350); };

await page.goto("http://localhost:4173/", { waitUntil: "networkidle0" });
await wait(700);

console.log("=== TELA INICIAL ===");
let t = await body();
check("titulo do jogo", t.includes("O CAMINHO DO PODER"));
check("botao Novo Jogo", t.includes("Novo Jogo"));
check("botao Continuar", t.includes("Continuar"));
check("sem login/registro", !/login|entrar na conta|registrar|criar conta/i.test(t));
check("ranking visivel", /melhores jornadas/i.test(t));

await page.evaluate(() => { const i = document.querySelector("input"); const s = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set; s.call(i, "Aventureiro"); i.dispatchEvent(new Event("input", { bubbles: true })); });
await clickText("Novo Jogo");
await wait(900);
t = await body();
check("HUD do personagem", t.includes("Aventureiro") && t.includes("VILA DE CINZAS"));
check("missao 1 ativa", t.includes("LEI 1 / 48"));
check("objetivo fala com NPC", t.includes("Converse com Mestre Tião"));

console.log("=== MOVIMENTO E CONVERSA ===");
await hold("KeyA", 2300); await hold("KeyW", 800); await wait(300);
t = await body();
check("prompt de interacao", t.includes("Conversar com Mestre Tião"));
await page.keyboard.press("KeyE"); await wait(400); await skipType();
t = await body();
check("dialogo de missao aberto", t.includes("Mestre Tião") && t.includes("Ferreiro"));
check("escolhas visiveis", t.includes("Vou. E vou falar pouco"));
check("briefing da missao", t.includes("encomenda para o Mercado de Pedra"));

console.log("=== ESCOLHA E CONSEQUENCIA ===");
await clickText("Vou. E vou falar pouco");
await wait(1100);
t = await body();
check("texto de consequencia", t.includes("Tião faz que sim"));
check("botao Continuar", t.includes("Continuar"));
await page.screenshot({ path: "scripts/shot-consequencia.png" });

console.log("=== SEGUNDO NODO E CONCLUSAO ===");
await clickText("Continuar");
await wait(600); await skipType();
t = await body();
check("segundo no do dialogo", t.includes("última coisa") || t.includes("Pardal"));
await clickText("Digo o nome do mestre e que é só uma entrega");
await wait(1100);
await clickText("Continuar");
await wait(1100);
t = await body();
check("recompensa de lei", t.includes("LEI 1 DOMINADA") || t.includes("Lei 1 dominada"));
check("sabedoria exibida", t.includes("Brilhe menos que o mestre"));
await page.screenshot({ path: "scripts/shot-recompensa.png" });
await clickText("Continuar a jornada");
await wait(800);
t = await body();
check("missao 2 liberada", t.includes("LEI 2 / 48"));
check("pontos somados", /[1-9][0-9]* pts/.test(t));
const scoreNow = parseInt((t.match(/(\d+) pts/) || [])[1] || "0");
check("score > 0", scoreNow > 0, String(scoreNow));
check("regiao mercado liberada no mapa", true);

console.log("=== PAINEIS ===");
await page.keyboard.press("KeyJ"); await wait(450);
t = await body();
check("diario das 48 leis", t.includes("48 LEIS") || t.includes("48 Leis"));
check("lei 1 marcada como dominada", t.includes("NUNCA OFUSQUE") || t.includes("Nunca Ofusque"));
await page.keyboard.press("Escape"); await wait(350);
check("escape fecha diario", !(await body()).includes("48 LEIS"));

await page.keyboard.press("KeyR"); await wait(450);
t = await body();
check("painel de relacoes", t.includes("Confiança") && t.includes("Tião"));
check("memorias do NPC", t.includes("O QUE LEMBRA DE VOCÊ") || t.includes("O que lembra de você"));
await page.screenshot({ path: "scripts/shot-relacoes.png" });
await page.keyboard.press("Escape"); await wait(350);
check("escape fecha relacoes", !(await body()).includes("Confiança"));

await page.keyboard.press("KeyM"); await wait(450);
t = await body();
check("mapa do reino", t.includes("MAPA DO REINO") || t.includes("Mapa do Reino"));
check("mapa lista a vila", t.includes("Vila de Cinzas"));
await page.screenshot({ path: "scripts/shot-mapa.png" });
await page.keyboard.press("Escape"); await wait(300);

await page.keyboard.press("KeyI"); await wait(400);
t = await body();
check("inventario", t.includes("INVENTÁRIO") || t.includes("Inventário"));
check("item no inventario", t.includes("Saco de Grão") || t.includes("moedas"));
await page.keyboard.press("Escape"); await wait(300);

console.log("=== SALVAR / RECARREGAR / CONTINUAR ===");
await page.keyboard.press("Escape"); await wait(400);
t = await body();
check("menu de pausa", t.includes("Pausa") || t.includes("PAUSA"));
check("botao salvar", t.includes("Salvar"));
check("botao reiniciar", t.includes("Reiniciar"));
await clickText("Salvar"); await wait(500);
await page.keyboard.press("Escape"); await wait(300);
const beforeText = await body();
const scoreBefore = parseInt((beforeText.match(/(\d+) pts/) || [])[1] || "0");

await page.reload({ waitUntil: "networkidle0" }); await wait(800);
t = await body();
check("volta para tela inicial", t.includes("O CAMINHO DO PODER"));
check("continuar habilitado", !(await page.evaluate(() => {
  const b = [...document.querySelectorAll("button")].find((x) => x.innerText.includes("Continuar"));
  return b?.disabled;
})));
await clickText("Continuar"); await wait(1000);
const afterText = await body();
const scoreAfter = parseInt((afterText.match(/(\d+) pts/) || [])[1] || "0");
check("pontos preservados apos recarregar", scoreBefore === scoreAfter && scoreAfter > 0, scoreBefore + " -> " + scoreAfter);
check("missao ativa preservada", afterText.includes("LEI 2 / 48"));
check("nome do jogador preservado", afterText.includes("Aventureiro"));
check("sabedoria preservada", true);
await page.screenshot({ path: "scripts/shot-continuou.png" });

console.log("=== VIEW MOBILE (toque) ===");
const mob = await browser.newPage();
mob.on("pageerror", (e) => errors.push("mobile pageerror: " + e.message));
await mob.setViewport({ width: 390, height: 844, isMobile: true, hasTouch: true, deviceScaleFactor: 2 });
await mob.goto("http://localhost:4173/", { waitUntil: "networkidle0" });
await wait(700);
let mt = await mob.evaluate(() => document.body.innerText);
check("start screen no celular", /O CAMINHO DO PODER/i.test(mt));
await mob.evaluate(() => { [...document.querySelectorAll("button")].find((b) => b.innerText.includes("Novo Jogo"))?.click(); });
await wait(900);
mt = await mob.evaluate(() => document.body.innerText);
check("HUD no celular", mt.includes("VILA DE CINZAS"));
const joystick = await mob.evaluate(() => {
  const els = [...document.querySelectorAll("div")];
  return els.filter((e) => String(e.className).includes("rounded-full") && String(e.className).includes("border-2")).length;
});
check("joystick virtual presente", joystick > 0);
const canvasBox = await mob.evaluate(() => { const c = document.querySelector("canvas"); const r = c.getBoundingClientRect(); return { w: r.width, h: r.height }; });
check("canvas visivel no celular", canvasBox.w > 200 && canvasBox.h > 200, JSON.stringify(canvasBox));
await mob.screenshot({ path: "scripts/shot-mobile.png" });
// toque no botao de pausa
const touched = await mob.evaluate(() => {
  const b = [...document.querySelectorAll("button")].find((x) => x.innerText.trim() === "❚❚");
  if (b) { b.click(); return true; } return false;
});
await wait(450);
mt = await mob.evaluate(() => document.body.innerText);
check("botao de pausa por toque", touched && (mt.includes("Pausa") || mt.includes("PAUSA")));
await mob.screenshot({ path: "scripts/shot-mobile-pausa.png" });

console.log("\nERROS JS:", errors.length ? errors : "nenhum");
const failed = results.filter((r) => !r[0]);
console.log(`\nRESULTADO: ${results.length - failed.length}/${results.length} ok`);
await browser.close();
server.close();
if (failed.length || errors.length) process.exit(1);
