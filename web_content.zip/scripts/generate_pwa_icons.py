import struct
import zlib
import os
import math

def write_png(filename, width, height, is_maskable=False):
    # Generates a crisp luxury brand icon with gold metallic AB crest on navy blue
    raw_data = bytearray()
    
    cx, cy = width / 2.0, height / 2.0
    r_outer = width * 0.44
    r_inner = width * 0.38
    r_center = width * 0.30

    for y in range(height):
        raw_data.append(0) # filter byte: None
        for x in range(width):
            dx = x - cx
            dy = y - cy
            dist = math.sqrt(dx * dx + dy * dy)
            
            # Base background navy #081225
            r, g, b = 8, 18, 37
            a = 255

            # Outer gold ring
            if abs(dist - r_outer) < (width * 0.015):
                r, g, b = 226, 192, 103 # Gold
            elif abs(dist - r_inner) < (width * 0.006):
                r, g, b = 184, 146, 48 # Subtle ring
            elif dist < r_center:
                # Radial gradient inside emblem
                norm = dist / r_center
                r = int(17 * (1 - norm) + 10 * norm)
                g = int(34 * (1 - norm) + 22 * norm)
                b = int(68 * (1 - norm) + 48 * norm)
                
                # Check for Stylized AB block in center
                nx = dx / r_center
                ny = dy / r_center
                # Left bar of A
                if -0.55 < nx < -0.35 and -0.45 < ny < 0.45:
                    r, g, b = 245, 220, 140
                # Right bar of A / Left bar of B
                elif -0.1 < nx < 0.1 and -0.45 < ny < 0.45:
                    r, g, b = 226, 192, 103
                # A crossbar
                elif -0.45 < nx < 0.05 and 0.0 < ny < 0.15:
                    r, g, b = 245, 220, 140
                # B loops
                elif 0.05 < nx < 0.45:
                    dist_top = math.sqrt((nx - 0.15)**2 + (ny + 0.2)**2)
                    dist_bot = math.sqrt((nx - 0.15)**2 + (ny - 0.2)**2)
                    if 0.18 < dist_top < 0.28 or 0.18 < dist_bot < 0.28:
                        r, g, b = 226, 192, 103

            raw_data.extend([r, g, b, a])

    def make_chunk(chunk_type, data):
        chunk = chunk_type + data
        crc = zlib.crc32(chunk) & 0xffffffff
        return struct.pack('>I', len(data)) + chunk + struct.pack('>I', crc)

    png_header = b'\x89PNG\r\n\x1a\n'
    ihdr_data = struct.pack('>IIBBBBB', width, height, 8, 6, 0, 0, 0)
    ihdr = make_chunk(b'IHDR', ihdr_data)
    idat = make_chunk(b'IDAT', zlib.compress(bytes(raw_data), 9))
    iend = make_chunk(b'IEND', b'')

    with open(filename, 'wb') as f:
        f.write(png_header + ihdr + idat + iend)

os.makedirs('public', exist_ok=True)
write_png('public/pwa-192x192.png', 192, 192)
write_png('public/pwa-512x512.png', 512, 512)
write_png('public/pwa-maskable-512x512.png', 512, 512, is_maskable=True)
write_png('public/apple-touch-icon.png', 180, 180)
print('PWA icons created successfully.')
