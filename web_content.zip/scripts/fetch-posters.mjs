import "dotenv/config";
import { Client } from "pg";

const SEARCH_TITLES = {
  "the-incredible-hulk": "The Incredible Hulk",
  "captain-america-the-first-avenger": "Captain America: The First Avenger",
  "guardians-of-the-galaxy": "Guardians of the Galaxy",
  "guardians-of-the-galaxy-vol-2": "Guardians of the Galaxy Vol. 2",
  "guardians-of-the-galaxy-vol-3": "Guardians of the Galaxy Vol. 3",
  "shang-chi-and-the-legend-of-the-ten-rings": "Shang-Chi and the Legend of the Ten Rings",
  "doctor-strange-in-the-multiverse-of-madness": "Doctor Strange in the Multiverse of Madness",
  "x-men-origini-wolverine": "X-Men Origins: Wolverine",
  "x-men-l-inizio": "X-Men: First Class",
  "x-men-giorni-di-un-futuro-passato": "X-Men: Days of Future Past",
  "x-men-apocalisse": "X-Men: Apocalypse",
  "venom-la-furia-di-carnage": "Venom: Let There Be Carnage",
  "kraven-il-cacciatore": "Kraven the Hunter",
  "fantastic-4-2005": "Fantastic Four",
  "fantastic-4-silver-surfer": "Fantastic Four: Rise of the Silver Surfer",
  "the-avengers": "The Avengers 2012",
  "avengers-doomsday": "Avengers Doomsday",
  "avengers-secret-wars": "Avengers Secret Wars",
  "spider-man-brand-new-day": "Spider-Man Brand New Day",
};

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function lookup(client, title, year) {
  const query = encodeURIComponent(title);
  const url = `https://v3.sg.media-imdb.com/suggestion/x/${query}.json`;
  try {
    const response = await fetch(url, { headers: { "User-Agent": "MarvelSquad/1.0" } });
    if (!response.ok) return null;
    const data = await response.json();
    const results = (data.d ?? []).filter((item) => item.qid === "movie" || item.q === "feature");
    if (results.length === 0) return null;
    const scored = results
      .map((item) => {
        const image = item.i;
        if (!image?.imageUrl) return null;
        const exactYear = Number(item.y) === Number(year) ? 40 : 0;
        const yearGap = Math.abs(Number(item.y ?? 9999) - Number(year));
        const titleScore = item.l.toLowerCase().startsWith(title.toLowerCase().slice(0, 12)) ? 20 : 0;
        const portrait = image.width > image.height ? 10 : 0;
        return { item, score: exactYear + titleScore + portrait - Math.min(yearGap, 20) };
      })
      .filter(Boolean)
      .sort((a, b) => b.score - a.score);
    return scored[0]?.item ?? null;
  } catch {
    return null;
  }
}

const client = new Client({ connectionString: process.env.DATABASE_URL });
await client.connect();

const { rows } = await client.query("select id, slug, title, year from movies order by sort_index");
console.log(`Trovati ${rows.length} film da coprire`);

const report = [];
for (const row of rows) {
  const searchTitle = SEARCH_TITLES[row.slug] ?? row.title;
  let found = await lookup(client, searchTitle, row.year);
  if (!found) found = await lookup(client, row.title, row.year);
  if (!found) {
    report.push({ slug: row.slug, status: "MISS" });
    console.log(`MISS  ${row.slug} (${row.title})`);
    await sleep(350);
    continue;
  }
  await client.query("update movies set poster_url = $1 where id = $2", [found.i.imageUrl, row.id]);
  report.push({ slug: row.slug, status: "OK", title: found.l, year: found.y });
  console.log(`OK    ${row.slug} -> ${found.l} (${found.y})`);
  await sleep(350);
}

await client.end();
const missing = report.filter((item) => item.status === "MISS");
console.log(`\nCompletati: ${report.length - missing.length}/${report.length}`);
if (missing.length > 0) console.log("Mancanti:", missing.map((item) => item.slug).join(", "));
