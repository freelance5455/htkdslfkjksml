import fs from 'fs';
import { CrosswordLayout } from '../src/types/crosswordLayout';
import { validateCrosswordLayout } from '../src/engine/CrosswordValidator';

const layout: CrosswordLayout = JSON.parse(fs.readFileSync('./src/data/golden_stage_01.json', 'utf8'));

console.log('Words in layout:');
layout.words.forEach(w => {
  console.log(`${w.id} (No. ${w.number}, ${w.direction}): "${w.answer}" (${w.length}) -> ${w.clue}`);
});

console.log('\nTotal words:', layout.words.length);
const val = validateCrosswordLayout(layout);
console.log('Validation passed:', val.isValid);
console.log('Intersections:', val.stats.intersectionsCount);
