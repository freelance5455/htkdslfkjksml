import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const { ZipArchive } = require('archiver');

const rootDir = process.cwd();
const publicDir = path.join(rootDir, 'public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

const outputPath = path.join(publicDir, 'roxy-voice-assistant.zip');
const output = fs.createWriteStream(outputPath);
const archive = new ZipArchive({ zlib: { level: 9 } });

output.on('close', () => {
  console.log(`Zip archive created successfully: ${outputPath} (${archive.pointer()} total bytes)`);
});

archive.on('error', (err: any) => {
  throw err;
});

archive.pipe(output);

// Exclude heavy / internal / cache folders
const ignoreDirs = new Set(['node_modules', 'dist', '.git', '.cache', '.aistudio']);

function addDirectory(currentDir: string, zipPrefix: string) {
  const entries = fs.readdirSync(currentDir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(currentDir, entry.name);
    const relativeZipPath = zipPrefix ? `${zipPrefix}/${entry.name}` : entry.name;

    if (entry.isDirectory()) {
      if (ignoreDirs.has(entry.name)) continue;
      addDirectory(fullPath, relativeZipPath);
    } else {
      if (entry.name.endsWith('.zip')) continue;
      archive.file(fullPath, { name: relativeZipPath });
    }
  }
}

addDirectory(rootDir, '');
archive.finalize();
