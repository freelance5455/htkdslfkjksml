<?php
require_once __DIR__.'/../src/bootstrap.php';
if(PHP_SAPI!=='cli'){http_response_code(403);exit("CLI only\n");}
if($argc<3){fwrite(STDERR,"Usage: php scripts/create_admin.php email password\n");exit(1);}
$email=$argv[1];$pass=$argv[2];
if(!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($pass)<12){fwrite(STDERR,"Use a valid email and password of at least 12 characters.\n");exit(1);}
$q=db()->prepare('INSERT INTO admins(email,password_hash) VALUES(?,?)');$q->execute([$email,password_hash($pass,PASSWORD_DEFAULT)]);echo "Admin created\n";
