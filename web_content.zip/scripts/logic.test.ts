import assert from "node:assert/strict";
import { ArrayBufferTarget, Muxer } from "mp4-muxer";
import { buildTimeline, sceneAt, phaseAt } from "@/lib/timeline";
import { validateProject } from "@/lib/preflight";
import { inspectMp4, validateMp4Blob } from "@/lib/mp4validate";
import { createBlankProject, normalizeProject, newEmptyQuestion } from "@/data/defaults";
import type { MediaMeta, Project } from "@/types";

class StubVideoChunk {
  type: "key" | "delta";
  timestamp: number;
  duration: number;
  byteLength: number;
  data: Uint8Array;
  constructor(init: { type: "key" | "delta"; timestamp: number; duration: number; data: Uint8Array }) {
    this.type = init.type;
    this.timestamp = init.timestamp;
    this.duration = init.duration;
    this.data = init.data;
    this.byteLength = init.data.byteLength;
  }
  copyTo(target: Uint8Array) {
    target.set(this.data);
  }
}
class StubAudioChunk extends StubVideoChunk {}
(globalThis as unknown as { EncodedVideoChunk: typeof StubVideoChunk }).EncodedVideoChunk = StubVideoChunk;
(globalThis as unknown as { EncodedAudioChunk: typeof StubAudioChunk }).EncodedAudioChunk = StubAudioChunk;

let passed = 0;
const results: string[] = [];
function check(name: string, fn: () => void | Promise<void>) {
  return (async () => {
    try {
      await fn();
      passed++;
      results.push(`PASS  ${name}`);
    } catch (error) {
      results.push(`FAIL  ${name}: ${error instanceof Error ? error.message : String(error)}`);
      throw error;
    }
  })();
}

function media(id: string, kind: "audio" | "image", duration?: number): MediaMeta {
  return { id, name: `${id}.mp3`, type: kind === "audio" ? "audio/mpeg" : "image/png", size: 1000, kind, duration, createdAt: Date.now() };
}

function fixtureProject(): Project {
  const project = createBlankProject("اختبار منطق التوقيت");
  project.questions = [
    {
      ...newEmptyQuestion(8),
      id: "q1",
      question: "سؤال عربي أول؟",
      options: ["الرياض", "جدة", "مكة", "الدمام"],
      correct: 0,
      questionAudioId: "aq1",
      optionsAudioId: "ao1",
    },
    {
      ...newEmptyQuestion(5),
      id: "q2",
      question: "سؤال ثانٍ؟",
      options: ["أ", "ب", "ج", "د"],
      correct: 2,
      questionAudioId: "aq2",
      optionsAudioId: "ao2",
    },
  ];
  project.media = {
    aq1: media("aq1", "audio", 5),
    ao1: media("ao1", "audio", 7),
    aq2: media("aq2", "audio", 2.5),
    ao2: media("ao2", "audio", 3.5),
  };
  project.timing = {
    ...project.timing,
    audioMode: "separate",
    questionHoldMs: 400,
    optionsHoldMs: 300,
    nextHoldMs: 500,
    voiceVolume: 80,
  };
  project.questions[0].revealHoldMs = 2000;
  project.questions[1].revealHoldMs = 1200;
  return project;
}

async function main() {
  await check("التوقيت يُحسب من المدة الفعلية للصوت كما في المعادلة المتوقعة", () => {
    const timeline = buildTimeline(fixtureProject());
    assert.equal(timeline.scenes.length, 2);
    const first = timeline.scenes[0].timings;
    assert.equal(Number(first.optionsStart.toFixed(2)), 5.4, "بداية الخيارات = 5 + 0.4");
    assert.equal(Number(first.thinkingStart.toFixed(2)), 12.7, "بداية التفكير = 5.4 + 7 + 0.3");
    assert.equal(Number(first.revealStart.toFixed(2)), 20.7, "كشف الإجابة = 12.7 + 8");
    assert.equal(Number(first.duration.toFixed(2)), 23.2, "نهاية المشهد = 20.7 + 2 + 0.5");
    const second = timeline.scenes[1].timings;
    assert.equal(Number(second.start.toFixed(2)), 23.2, "يبدأ المشهد الثاني بعد الأول مباشرة");
    assert.equal(Number(timeline.totalDuration.toFixed(2)), 36.6);
    assert.equal(timeline.scenes[0].audio[1].start, 5.4, "صوت الخيارات يبدأ مع ظهورها");
    assert.equal(timeline.scenes[0].audio[0].volume, 0.8, "مستوى الصوت يحترم الإعداد");
  });

  await check("مدة صامتة بديلة عند غياب الصوت", () => {
    const project = fixtureProject();
    project.questions = [{ ...project.questions[0], questionAudioId: null, optionsAudioId: null }];
    project.timing.questionSilentMs = 3000;
    project.timing.optionsSilentMs = 3200;
    const scene = buildTimeline(project).scenes[0];
    assert.equal(Number(scene.timings.optionsStart.toFixed(2)), 3.4);
    assert.equal(Number(scene.timings.thinkingStart.toFixed(2)), 6.9);
  });

  await check("وضع الملف الموحّد يقسّم الظهور حسب النسبة", () => {
    const project = fixtureProject();
    project.timing.audioMode = "combined";
    project.timing.combinedSplit = 55;
    project.timing.optionsHoldMs = 300;
    project.questions = [{ ...project.questions[0], combinedAudioId: "ac1" }];
    project.media.ac1 = media("ac1", "audio", 10);
    const scene = buildTimeline(project).scenes[0];
    assert.equal(Number(scene.timings.optionsStart.toFixed(2)), 5.5);
    assert.equal(Number(scene.timings.thinkingStart.toFixed(2)), 10.3);
    assert.equal(scene.audio.length, 1);
  });

  await check("المؤقت ومرحلة الكشف منطقيان", () => {
    const project = fixtureProject();
    const scene = buildTimeline(project).scenes[0];
    assert.equal(phaseAt(scene, scene.timings.thinkingStart + 0.1).label, "وقت التفكير");
    assert.equal(phaseAt(scene, scene.timings.revealStart + 0.1).label, "الإجابة الصحيحة");
    const at = sceneAt(buildTimeline(project), scene.timings.start + 0.2);
    assert.equal(at?.scene.questionId, "q1");
  });

  await check("الفحص المسبق يمنع السؤال الناقص والإجابة الغائبة", () => {
    const project = fixtureProject();
    project.questions[1].options[2] = "";
    project.questions[1].correct = -1;
    const issues = validateProject(project, { availableMedia: new Set(Object.keys(project.media)) });
    assert.ok(issues.some((issue) => issue.level === "error" && issue.message.includes("الخيار 3")));
    assert.ok(issues.some((issue) => issue.level === "error" && issue.message.includes("إجابة صحيحة")));
  });

  await check("الفحص المسبق يكتشف غياب الملف من التخزين", () => {
    const project = fixtureProject();
    const issues = validateProject(project, { availableMedia: new Set(["aq2", "ao2"]) });
    assert.ok(issues.some((issue) => issue.level === "error" && issue.message.includes("غير متاح")));
  });

  await check("استيراد مشروع غير صالح يُرفض", () => {
    assert.throws(() => normalizeProject({ name: "بلا أسئلة" }), /أسئلة/);
    assert.throws(() => normalizeProject(null), /غير صالح/);
  });

  await check("بنية مشروع مستورد دمجه مع الإعدادات الافتراضية", () => {
    const source = fixtureProject();
    const raw = JSON.parse(JSON.stringify(source));
    delete raw.design.background.glow;
    const imported = normalizeProject(raw);
    assert.equal(imported.questions.length, 2);
    assert.equal(imported.design.background.glow, true);
    assert.equal(imported.questions[0].correct, 0);
  });

  await check("قارئ MP4 يميز المسارات ويقرأ البنية", async () => {
    const target = new ArrayBufferTarget();
    const muxer = new Muxer({
      target,
      video: { codec: "avc", width: 720, height: 1280, frameRate: 25 },
      audio: { codec: "aac", numberOfChannels: 2, sampleRate: 48000 },
      fastStart: "in-memory",
    });
    const avcC = new Uint8Array([1, 0x42, 0x00, 0x1e, 0xff, 0xe1, 0x00, 0x04, 0x67, 0x42, 0x00, 0x1e, 0x01, 0x00, 0x04, 0x68, 0xce, 0x3c, 0x80]);
    for (let i = 0; i < 10; i++) {
      const fakeVideoChunk = new StubVideoChunk({
        type: i === 0 ? "key" : "delta",
        timestamp: i * 40_000,
        duration: 40_000,
        data: new Uint8Array([0, 0, 0, 2, 9, 16]),
      });
      muxer.addVideoChunk(fakeVideoChunk as unknown as EncodedVideoChunk, {
        decoderConfig: { codec: "avc1.42E01E", description: avcC },
      } as unknown as EncodedVideoChunkMetadata);
    }
    for (let i = 0; i < 20; i++) {
      const fakeAudio = new StubAudioChunk({
        type: "key",
        timestamp: i * 20_000,
        duration: 20_000,
        data: new Uint8Array(512),
      });
      muxer.addAudioChunk(fakeAudio as unknown as EncodedAudioChunk, {
        decoderConfig: { codec: "mp4a.40.2", sampleRate: 48000, numberOfChannels: 2 },
      } as unknown as EncodedAudioChunkMetadata);
    }
    muxer.finalize();
    const inspection = inspectMp4(target.buffer);
    assert.equal(inspection.hasMoov, true);
    assert.equal(inspection.hasMdat, true);
    assert.equal(inspection.hasVideoTrack, true);
    assert.equal(inspection.hasAudioTrack, true);
    assert.equal(inspection.videoCodec, "avc1");
    assert.equal(inspection.audioCodec, "mp4a");
    const blob = new Blob([target.buffer], { type: "video/mp4" });
    const validation = await validateMp4Blob(blob, { duration: 0.4, width: 720, height: 1280, requireAudio: true });
    assert.ok(validation.checks.some((item) => item.key === "video-track" && item.status === "pass"));
    assert.ok(validation.checks.some((item) => item.key === "audio-track" && item.status === "pass"));
    assert.ok(!validation.checks.some((item) => item.key === "duration" && item.status === "fail"));
  });

  console.log(results.join("\n"));
  console.log(`\n${passed}/${results.length} checks passed`);
}

main().catch(() => {
  console.log(results.join("\n"));
  process.exit(1);
});
