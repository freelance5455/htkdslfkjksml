import fs from 'fs';
import { STAGE_02_QUESTIONS } from '../src/data/stage02Questions';
import { normalizeArabicString } from '../src/engine/normalization';
import { validateCrosswordLayout } from '../src/engine/CrosswordValidator';
import {
  CrosswordLayout,
  CrosswordLayoutWord,
  CrosswordLayoutCell,
  LayoutCellCoordinate,
  CrosswordLayoutClue
} from '../src/types/crosswordLayout';

function cleanWord(str: string): string {
  return normalizeArabicString(str.replace(/\s+/g, ''));
}

interface WordInfo {
  id: string;
  clue: string;
  answer: string;
  norm: string;
  len: number;
}

const words: WordInfo[] = STAGE_02_QUESTIONS.map((q) => {
  const norm = cleanWord(q.answer);
  return {
    id: q.id,
    clue: q.clue,
    answer: q.answer,
    norm,
    len: norm.length
  };
});

type Dir = 'across' | 'down';

interface Placement {
  word: WordInfo;
  dir: Dir;
  r: number;
  c: number;
  reversed: boolean;
}

function canFit(
  wStr: string,
  dir: Dir,
  r: number,
  c: number,
  grid: (string | null)[][],
  cellDirs: Set<Dir>[][],
  GRID_SIZE: number,
  placedCount: number
): { valid: boolean; inters: number } {
  const len = wStr.length;
  if (dir === 'across') {
    if (c + len > GRID_SIZE || r < 0 || r >= GRID_SIZE || c < 0) return { valid: false, inters: 0 };
    if (c > 0 && grid[r][c - 1] !== null) return { valid: false, inters: 0 };
    if (c + len < GRID_SIZE && grid[r][c + len] !== null) return { valid: false, inters: 0 };

    let touches = placedCount === 0;
    let inters = 0;

    for (let k = 0; k < len; k++) {
      const cur = grid[r][c + k];
      if (cur !== null) {
        if (cur !== wStr[k]) return { valid: false, inters: 0 };
        if (cellDirs[r][c + k].has('across')) return { valid: false, inters: 0 };
        touches = true;
        inters++;
      } else {
        if (r > 0 && grid[r - 1][c + k] !== null && !cellDirs[r - 1][c + k].has('down')) return { valid: false, inters: 0 };
        if (r < GRID_SIZE - 1 && grid[r + 1][c + k] !== null && !cellDirs[r + 1][c + k].has('down')) return { valid: false, inters: 0 };
      }
    }
    return { valid: touches, inters };
  } else {
    if (r + len > GRID_SIZE || c < 0 || c >= GRID_SIZE || r < 0) return { valid: false, inters: 0 };
    if (r > 0 && grid[r - 1][c] !== null) return { valid: false, inters: 0 };
    if (r + len < GRID_SIZE && grid[r + len][c] !== null) return { valid: false, inters: 0 };

    let touches = placedCount === 0;
    let inters = 0;

    for (let k = 0; k < len; k++) {
      const cur = grid[r + k][c];
      if (cur !== null) {
        if (cur !== wStr[k]) return { valid: false, inters: 0 };
        if (cellDirs[r + k][c].has('down')) return { valid: false, inters: 0 };
        touches = true;
        inters++;
      } else {
        if (c > 0 && grid[r + k][c - 1] !== null && !cellDirs[r + k][c - 1].has('across')) return { valid: false, inters: 0 };
        if (c < GRID_SIZE - 1 && grid[r + k][c + 1] !== null && !cellDirs[r + k][c + 1].has('across')) return { valid: false, inters: 0 };
      }
    }
    return { valid: touches, inters };
  }
}

function solveMRV(GRID_SIZE: number, maxAttempts = 100000): Placement[] | null {
  const sortedWords = [...words].sort((a, b) => b.len - a.len);

  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    if (attempt > 0 && attempt % 5000 === 0) {
      console.log(`MRV Attempt ${attempt} (size ${GRID_SIZE}x${GRID_SIZE})...`);
    }

    const grid: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
    const cellDirs: Set<Dir>[][] = Array.from({ length: GRID_SIZE }, () => Array.from({ length: GRID_SIZE }, () => new Set<Dir>()));
    const placed: Placement[] = [];

    // Root is one of top longest words (منارة الإسكندرية 15, النماذج الأصلية 14, الريشة الطائرة 13)
    const root = sortedWords[Math.floor(Math.random() * 3)];
    const rootDir: Dir = Math.random() > 0.5 ? 'across' : 'down';
    const rootRev = false;
    const rootStr = root.norm;

    const rootR = rootDir === 'across' ? Math.floor(GRID_SIZE / 2) + (Math.floor(Math.random() * 3) - 1) : Math.floor((GRID_SIZE - root.len) / 2);
    const rootC = rootDir === 'down' ? Math.floor(GRID_SIZE / 2) + (Math.floor(Math.random() * 3) - 1) : Math.floor((GRID_SIZE - root.len) / 2);

    if (rootR < 0 || rootC < 0 || (rootDir === 'across' && rootC + root.len > GRID_SIZE) || (rootDir === 'down' && rootR + root.len > GRID_SIZE)) {
      continue;
    }

    for (let k = 0; k < root.len; k++) {
      const cr = rootDir === 'down' ? rootR + k : rootR;
      const cc = rootDir === 'across' ? rootC + k : rootC;
      grid[cr][cc] = rootStr[k];
      cellDirs[cr][cc].add(rootDir);
    }
    placed.push({ word: root, dir: rootDir, r: rootR, c: rootC, reversed: rootRev });

    let unplaced = words.filter((w) => w.id !== root.id);
    let stuck = false;

    while (unplaced.length > 0) {
      interface CandidateOption {
        word: WordInfo;
        placements: { dir: Dir; r: number; c: number; reversed: boolean; score: number; inters: number }[];
      }

      const options: CandidateOption[] = [];

      for (const w of unplaced) {
        const pls: { dir: Dir; r: number; c: number; reversed: boolean; score: number; inters: number }[] = [];

        for (const dir of ['across', 'down'] as Dir[]) {
          for (const rev of [false, true]) {
            const wStr = rev ? w.norm.split('').reverse().join('') : w.norm;
            for (let r = 0; r < GRID_SIZE; r++) {
              for (let c = 0; c < GRID_SIZE; c++) {
                const res = canFit(wStr, dir, r, c, grid, cellDirs, GRID_SIZE, placed.length);
                if (res.valid && res.inters >= 1) {
                  const midR = dir === 'down' ? r + w.len / 2 : r;
                  const midC = dir === 'across' ? c + w.len / 2 : c;
                  const distFromCenter = Math.abs(midR - GRID_SIZE / 2) + Math.abs(midC - GRID_SIZE / 2);
                  const revPenalty = rev ? 1.5 : 0;
                  const score = res.inters * 20 + w.len * 2 - distFromCenter * 0.8 - revPenalty + Math.random() * 3;
                  pls.push({ dir, r, c, reversed: rev, score, inters: res.inters });
                }
              }
            }
          }
        }

        if (pls.length === 0) {
          stuck = true;
          break;
        }

        options.push({ word: w, placements: pls });
      }

      if (stuck || options.length === 0) break;

      // Pick MRV (word with smallest valid placements)
      options.sort((a, b) => a.placements.length - b.placements.length);
      const chosenWordOption = options[0];

      // Sort placements of chosen word by score
      chosenWordOption.placements.sort((a, b) => b.score - a.score);

      const topPoolSize = Math.min(3, chosenWordOption.placements.length);
      const pick = chosenWordOption.placements[Math.floor(Math.random() * topPoolSize)];

      const pickStr = pick.reversed ? chosenWordOption.word.norm.split('').reverse().join('') : chosenWordOption.word.norm;

      for (let k = 0; k < chosenWordOption.word.len; k++) {
        const cr = pick.dir === 'down' ? pick.r + k : pick.r;
        const cc = pick.dir === 'across' ? pick.c + k : pick.c;
        grid[cr][cc] = pickStr[k];
        cellDirs[cr][cc].add(pick.dir);
      }

      placed.push({
        word: chosenWordOption.word,
        dir: pick.dir,
        r: pick.r,
        c: pick.c,
        reversed: pick.reversed
      });

      unplaced = unplaced.filter((w) => w.id !== chosenWordOption.word.id);
    }

    if (placed.length === words.length) {
      console.log(`🎉 SOLVED! MRV found layout for Stage 2 on attempt ${attempt}!`);
      return placed;
    }
  }

  return null;
}

let result = solveMRV(15, 60000);
let finalGridSize = 15;
if (!result) {
  console.log('Trying 16x16 grid with MRV...');
  result = solveMRV(16, 100000);
  finalGridSize = 16;
}

if (!result) {
  console.error('MRV could not find solution');
  process.exit(1);
}

// Build Layout Object and Validate
const GRID_SIZE = finalGridSize;
const gridLetters: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
const acrossMap: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
const downMap: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));

for (const p of result) {
  const wStr = p.reversed ? p.word.norm.split('').reverse().join('') : p.word.norm;
  for (let k = 0; k < p.word.len; k++) {
    const r = p.dir === 'down' ? p.r + k : p.r;
    const c = p.dir === 'across' ? p.c + k : p.c;
    gridLetters[r][c] = wStr[k];
    if (p.dir === 'across') acrossMap[r][c] = p.word.id;
    else downMap[r][c] = p.word.id;
  }
}

// Clue Numbers
let clueNum = 1;
const wordNumberMap = new Map<string, number>();
const cellNumberMap = new Map<string, number>();

for (let r = 0; r < GRID_SIZE; r++) {
  for (let c = 0; c < GRID_SIZE; c++) {
    if (gridLetters[r][c] === null) continue;

    let hasStart = false;
    const startAcross = result.find((p) => p.dir === 'across' && p.r === r && p.c === c);
    const startDown = result.find((p) => p.dir === 'down' && p.r === r && p.c === c);

    if (startAcross) {
      wordNumberMap.set(startAcross.word.id, clueNum);
      hasStart = true;
    }
    if (startDown) {
      wordNumberMap.set(startDown.word.id, clueNum);
      hasStart = true;
    }

    if (hasStart) {
      cellNumberMap.set(`${r}_${c}`, clueNum);
      clueNum++;
    }
  }
}

const cells: CrosswordLayoutCell[] = [];
const blackCells: LayoutCellCoordinate[] = [];

for (let r = 0; r < GRID_SIZE; r++) {
  for (let c = 0; c < GRID_SIZE; c++) {
    const letter = gridLetters[r][c];
    if (letter === null) {
      cells.push({
        row: r,
        column: c,
        isBlocked: true,
        letter: ''
      });
      blackCells.push({ row: r, col: c });
    } else {
      const num = cellNumberMap.get(`${r}_${c}`);
      cells.push({
        row: r,
        column: c,
        isBlocked: false,
        letter,
        number: num,
        acrossWordId: acrossMap[r][c] || undefined,
        downWordId: downMap[r][c] || undefined
      });
    }
  }
}

const layoutWords: CrosswordLayoutWord[] = result.map((p) => {
  const number = wordNumberMap.get(p.word.id) || 1;
  const wordCells: LayoutCellCoordinate[] = [];
  for (let k = 0; k < p.word.len; k++) {
    const r = p.dir === 'down' ? p.r + k : p.r;
    const c = p.dir === 'across' ? p.c + k : p.c;
    wordCells.push({ row: r, col: c });
  }

  return {
    id: p.word.id,
    clue: p.word.clue,
    answer: p.word.answer,
    normalizedAnswer: p.word.norm,
    direction: p.dir,
    startRow: p.r,
    startColumn: p.c,
    length: p.word.len,
    cells: wordCells,
    number,
    reversed: p.reversed
  };
});

layoutWords.sort((a, b) => {
  if (a.number !== b.number) return a.number - b.number;
  return a.direction === 'across' ? -1 : 1;
});

const clues: CrosswordLayoutClue[] = layoutWords.map((w) => ({
  number: w.number,
  clue: w.clue,
  direction: w.direction,
  length: w.length,
  wordId: w.id,
  reversed: w.reversed
}));

const layout: CrosswordLayout = {
  gridRows: GRID_SIZE,
  gridColumns: GRID_SIZE,
  cells,
  words: layoutWords,
  clues,
  blackCells
};

const validation = validateCrosswordLayout(layout);
console.log('\n--- Validation Result for Stage 2 ---');
console.log('isValid:', validation.isValid);
validation.items.forEach((item) => {
  console.log(`${item.passed ? '✓' : '✗'} ${item.label}: ${item.message}`);
});

if (validation.isValid) {
  fs.writeFileSync('src/data/golden_stage_02.json', JSON.stringify(layout, null, 2), 'utf-8');
  console.log('\n✨ Saved golden_stage_02.json successfully!');
} else {
  console.error('Validation failed!');
  process.exit(1);
}
