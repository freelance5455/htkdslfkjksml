const fs=require('fs'),p='android/app/src/main/AndroidManifest.xml';let x=fs.readFileSync(p,'utf8');
['CAMERA','RECORD_AUDIO','MODIFY_AUDIO_SETTINGS','INTERNET'].forEach(n=>{const l=`<uses-permission android:name="android.permission.${n}" />`;if(!x.includes(`android.permission.${n}"`))x=x.replace('</manifest>',`    ${l}\n</manifest>`)});
fs.writeFileSync(p,x);console.log('permissions patched');
