const fs=require('fs'),p='android/app/src/main/AndroidManifest.xml';let x=fs.readFileSync(p,'utf8');
// التطبيق محلي بالكامل: لا إنترنت ولا نسخ احتياطي تلقائي إلى خدمات خارجية
x=x.replace(/\s*<uses-permission android:name="android.permission.INTERNET"\s*\/>/g,'').replace('android:allowBackup="true"','android:allowBackup="false"');
['RECORD_AUDIO','CAMERA'].forEach(n=>{const l=`<uses-permission android:name="android.permission.${n}" />`;if(!x.includes(`android.permission.${n}"`))x=x.replace('</manifest>',`    ${l}\n</manifest>`)});
['camera','microphone'].forEach(n=>{if(!x.includes(`android.hardware.${n}"`))x=x.replace('</manifest>',`    <uses-feature android:name="android.hardware.${n}" android:required="false" />\n</manifest>`)});
fs.writeFileSync(p,x);console.log('manifest patched');
