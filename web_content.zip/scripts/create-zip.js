import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');

const zip = new JSZip();

// Folders and files to exclude
const EXCLUDE_DIRS = new Set(['node_modules', '.git', 'dist', '.aistudio', '.cache']);
const EXCLUDE_FILES = new Set(['.DS_Store', 'package-lock.json']);

function addDirectoryToZip(dirPath, zipFolder) {
  const items = fs.readdirSync(dirPath);

  for (const item of items) {
    const fullPath = path.join(dirPath, item);
    const stat = fs.statSync(fullPath);

    if (stat.isDirectory()) {
      if (!EXCLUDE_DIRS.has(item)) {
        const subFolder = zipFolder.folder(item);
        addDirectoryToZip(fullPath, subFolder);
      }
    } else {
      if (!EXCLUDE_FILES.has(item) && !item.endsWith('.zip')) {
        const content = fs.readFileSync(fullPath);
        zipFolder.file(item, content);
      }
    }
  }
}

console.log('Packaging SEWORA project into ZIP archive...');
addDirectoryToZip(rootDir, zip);

const publicDir = path.join(rootDir, 'public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

const outputPath = path.join(publicDir, 'sewora-ecommerce-app.zip');

zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE', compressionOptions: { level: 9 } })
  .then((buffer) => {
    fs.writeFileSync(outputPath, buffer);
    const sizeMb = (buffer.length / (1024 * 1024)).toFixed(2);
    console.log(`Success! Created ${outputPath} (${sizeMb} MB)`);
  })
  .catch((err) => {
    console.error('Error generating zip:', err);
    process.exit(1);
  });
