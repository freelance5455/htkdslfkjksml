// src/game/data/items.ts
var ITEMS = {
  pao: {
    id: "pao",
    name: "P\xE3o Fresco",
    icon: "\u{1F35E}",
    kind: "gift",
    desc: "P\xE3o quente da Fornalha. Gasta pouco e compra muita simpatia."
  },
  vinho: {
    id: "vinho",
    name: "Vinho do Porto",
    icon: "\u{1F377}",
    kind: "gift",
    desc: "Um vinho caro. Aperte de m\xE3o e mem\xF3ria longa."
  },
  carta: {
    id: "carta",
    name: "Carta Selada",
    icon: "\u2709\uFE0F",
    kind: "clue",
    desc: "Um selo da Condessa Valdessa. Prova de alguma conspira\xE7\xE3o."
  },
  chave: {
    id: "chave",
    name: "Chave de Ferro",
    icon: "\u{1F5DD}\uFE0F",
    kind: "key",
    desc: "Abre a porta de tr\xE1s da Taverna do Corvo."
  },
  prata: {
    id: "prata",
    name: "Barra de Prata",
    icon: "\u{1FA99}",
    kind: "treasure",
    desc: "Metal fundido que o Tesoureiro reconheceu como sendo do Cofre Real."
  },
  anel: {
    id: "anel",
    name: "Anel de Selo",
    icon: "\u{1F48D}",
    kind: "treasure",
    desc: "Um anel com o bras\xE3o do Duque Oldric. Ningu\xE9m deveria v\xEA-lo."
  },
  mapa: {
    id: "mapa",
    name: "Mapa de Trilhas",
    icon: "\u{1F5FA}\uFE0F",
    kind: "clue",
    desc: "Trilhas de contrabandista marcadas a carv\xE3o. Leva \xE0 Cripta."
  },
  diario: {
    id: "diario",
    name: "Di\xE1rio Riscado",
    icon: "\u{1F4DC}",
    kind: "clue",
    desc: "Contas e nomes. Algu\xE9m cobra por informa\xE7\xF5es na corte."
  },
  sino: {
    id: "sino",
    name: "Sino de Alarme",
    icon: "\u{1F514}",
    kind: "tool",
    desc: "Um sino de bronze. Pode ser tocado para criar um barulho conveniente."
  },
  erva: {
    id: "erva",
    name: "Erva Amarga",
    icon: "\u{1F33F}",
    kind: "tool",
    desc: "Mastigada, clareia a mente. Tamb\xE9m serve para envenenar.",
    use: {
      text: "Voc\xEA mastiga a erva. O mundo fica n\xEDtido e cruel.",
      effects: { intelligence: 2 },
      consume: true
    }
  },
  pocao: {
    id: "pocao",
    name: "Po\xE7\xE3o de Coragem",
    icon: "\u{1F9EA}",
    kind: "tool",
    desc: "Amarga como a desgra\xE7a. Faz o-homem-common hesitar.",
    use: {
      text: "Voc\xEA toma a po\xE7\xE3o. O medo recua um passo.",
      effects: { influence: 2 },
      consume: true
    }
  },
  tocha: {
    id: "tocha",
    name: "Tocha de Resina",
    icon: "\u{1F526}",
    kind: "tool",
    desc: "Queima por uma hora. Revela o que a escurid\xE3o escondia."
  },
  flauta: {
    id: "flauta",
    name: "Flauta do Trovador",
    icon: "\u{1F3B5}",
    kind: "tool",
    desc: "Ismael a deixou com voc\xEA. Uma melodia certa abre portas erradas."
  },
  espada: {
    id: "espada",
    name: "Espada Curta",
    icon: "\u{1F5E1}\uFE0F",
    kind: "tool",
    desc: "A\xE7o simples,punho gasto. Resolve conversas curtas.",
    use: {
      text: "Voc\xEA sacode a l\xE2mina. Ningu\xE9m se aproxima para conferir.",
      effects: { power: 1, reputation: -1 }
    }
  },
  manto: {
    id: "manto",
    name: "Manto Cinzento",
    icon: "\u{1F9E5}",
    kind: "tool",
    desc: "Esconde a silhueta. Terceiro de tr\xEAs para entrar na Casa do Corvo."
  },
  selo: {
    id: "selo",
    name: "Selo Real",
    icon: "\u{1F531}",
    kind: "key",
    desc: "O selo do rei. Com ele, as portas se abrem. E as suspicions tamb\xE9m."
  },
  coroa: {
    id: "coroa",
    name: "Fragmento da Coroa",
    icon: "\u{1F451}",
    kind: "treasure",
    desc: "Uma pe\xE7a da Coroa Partida. H\xE1 quem mate por menos."
  },
  contrato: {
    id: "contrato",
    name: "Contrato Selado",
    icon: "\u{1F4C4}",
    kind: "clue",
    desc: "Um acordo de casamento entre duas casas que se odeiam."
  },
  grao: {
    id: "grao",
    name: "Saco de Gr\xE3o",
    icon: "\u{1F33E}",
    kind: "gift",
    desc: "Cereal do celeiro do rei. Quem o controla controla a fome."
  },
  medalha: {
    id: "medalha",
    name: "Medalha de Ferro",
    icon: "\u{1F396}\uFE0F",
    kind: "tool",
    desc: "Distintivo da guarda muralha. Rosto novo, mesma Doubt."
  },
  cifra: {
    id: "cifra",
    name: "Cifra dos Espi\xF5es",
    icon: "\u{1F510}",
    kind: "key",
    desc: "Mensagens codificadas do Olho do Corvo. Abre a Cripta Sombria."
  },
  licenca: {
    id: "licenca",
    name: "Licen\xE7a de Com\xE9rcio",
    icon: "\u{1F4DC}",
    kind: "key",
    desc: "Uma licen\xE7a do Tesoureiro. Abre o port\xE3o norte sem perguntas."
  }
};
var ITEM_LIST = Object.values(ITEMS);

// src/game/data/laws.ts
var LAWS = [
  {
    id: 1,
    title: "Nunca Ofusque o Mestre",
    short: "Brilhe menos que o rei",
    insight: "Ser med\xEDocre nunca \xE9 virtuoso. Brilhe menos que o mestre e ele o mant\xE9m; brilhe mais e ele o apaga. Fa\xE7a do brilho dele o seu escudo."
  },
  {
    id: 2,
    title: "Nunca Confie Demais nos Amigos; Use os Inimigos",
    short: "Confian\xE7a \xE9 moeda cara",
    insight: "Amigos s\xE3o aliados de circunst\xE2ncia, n\xE3o de sangue. O inimigo \xFAtil \xE9 uma posi\xE7\xE3o: ele serve ao seu objetivo sem pedir o que voc\xEA n\xE3o pode dar."
  },
  {
    id: 3,
    title: "Esconda Suas Inten\xE7\xF5es",
    short: "Ningu\xE9m precisa do seu plano",
    insight: "Quem revela o plano perde a surpresa. Diga o que o interlocutor precisa ouvir e nada do que ele pode usar contra voc\xEA."
  },
  {
    id: 4,
    title: "Diga Sempre Menos do que o Necess\xE1rio",
    short: "O sil\xEAncio \xE9 uma arma",
    insight: "Quem fala muito entrega muni\xE7\xE3o. A frase mais forte \xE9 a que voc\xEA n\xE3o pronuncia, e o sil\xEAncio bem colocado cria medo e respeito."
  },
  {
    id: 5,
    title: "Guarde Sua Reputa\xE7\xE3o com a Sua Vida",
    short: "A reputa\xE7\xE3o \xE9 seu capital",
    insight: "A fortuna pode voltar; a reputa\xE7\xE3o, n\xE3o. Um \xFAnico esc\xE2ndalo apaga anos de bondade e reaparece em cada negocia\xE7\xE3o."
  },
  {
    id: 6,
    title: "Conquiste a Aten\xE7\xE3o a Qualquer Custo",
    short: "Ser notado \xE9 o primeiro passo",
    insight: "Quem ningu\xE9m nota, ningu\xE9m nomeia para o poder. Crie eventos e use a t\xE1tica: a aten\xE7\xE3o \xE9 a moeda com que se paga a entrada."
  },
  {
    id: 7,
    title: "Fa\xE7a Outros Trabalhar e Assuma o Cr\xE9dito",
    short: "O trabalho alheio \xE9 o seu",
    insight: "O m\xE9rito \xE9 uma narrativa. Distribua o esfor\xE7o, controle a hist\xF3ria e pare\xE7a o orquestrador de tudo o que acontece."
  },
  {
    id: 8,
    title: "Fa\xE7a os Outros Virem at\xE9 Voc\xEA",
    short: "Quem busca, submete",
    insight: "Se todos v\xEAm at\xE9 voc\xEA, voc\xEA escolhe o terreno e o momento. Nunca corra atr\xE1s: organize o lugar e espere que venham."
  },
  {
    id: 9,
    title: "Ven\xE7a pela A\xE7\xE3o, Nunca pela Argumenta\xE7\xE3o",
    short: "Argumento \xE9 vento",
    insight: "Discuss\xF5es vencem apenas no papel. O resultado concreto subordina qualquer r\xE9plica, e cala a boca dos c\xE9ticos."
  },
  {
    id: 10,
    title: "Infec\xE7\xE3o: Evite os Infelizes e os Azarados",
    short: "A sorte \xE9 contagiosa",
    insight: "O fracasso se gruda. Amizade com quem nunca prosperou arrasta seu nome para baixo; procure quem tem o impulso e carregue-o."
  },
  {
    id: 11,
    title: "Aprenda a Manter as Pessoas Dependentes de Voc\xEA",
    short: "Quem depende, obedece",
    insight: "Nunca forne\xE7a tudo. Centralize um recurso \u2014 gr\xE3o, transporte, acesso \u2014 e as pessoas passam a depender de voc\xEA para viver."
  },
  {
    id: 12,
    title: "Use Honestidade Seletiva e Generosidade para Desarmar",
    short: "A bondade \xE9 uma isca",
    insight: "Um elogio sincero no momento certo desarma a desconfian\xE7a. D\xEA algo pequeno e verdadeiro, e depois pe\xE7a algo grande."
  },
  {
    id: 13,
    title: "Apele ao Interesse Pr\xF3prio, Nunca \xE0 Miseric\xF3rdia",
    short: "Ningu\xE9m se move por piedade",
    insight: "Ponha o pedido na linguagem do outro: o que ele ganha. Miseric\xF3rdia \xE9 uma d\xEDvida, e toda d\xEDvida cobra juros."
  },
  {
    id: 14,
    title: "Pose-se de Amigo, Trabalhe como Espi\xE3o",
    short: "Amizade \xFAtil, espionagem \xFAtil",
    insight: "A confian\xE7a alheia \xE9 uma porta destrancada. Cuide dela com cuidado e use-a apenas quando o momento for insuper\xE1vel."
  },
  {
    id: 15,
    title: "Esmague o Inimigo por Completo",
    short: "Meio caminho \xE9 fraqueza",
    insight: "O inimigo humilhado volta. N\xE3o deixe vigor restante: termine o que come\xE7ou, ou n\xE3o comece."
  },
  {
    id: 16,
    title: "Use a Aus\xEAncia para Aumentar o Respeito",
    short: "Aus\xEAncia \xE9 presen\xE7a",
    insight: "Quem permanece tem pre\xE7o; quem some tem valor. Afaste-se na hora certa e o valor do que ficou cresce."
  },
  {
    id: 17,
    title: "Mantenha os Outros em Terror Suspenso",
    short: "Seja imprevis\xEDvel",
    insight: "Quem \xE9 previs\xEDvel \xE9 previsto. Varie os gestos, a presen\xE7a e o sil\xEAncio: o medo n\xE3o nasce do perigo, nasce da d\xFAvida."
  },
  {
    id: 18,
    title: "N\xE3o Construa Fortalezas",
    short: "Isolamento \xE9 perigoso",
    insight: "Quem se esconde n\xE3o \xE9 visto, e quem n\xE3o \xE9 visto n\xE3o \xE9 temido. Exponha-se ao fluxo e mantenha o fluxo dependente de voc\xEA."
  },
  {
    id: 19,
    title: "Saiba com Quem Voc\xEA Est\xE1 Lidando",
    short: "N\xE3o ofenda a pessoa errada",
    insight: "Me\xE7a o poder do outro antes de agir. Um homem pequeno pode ser o gatilho de algo imenso."
  },
  {
    id: 20,
    title: "N\xE3o Se Comprometa com Ningu\xE9m",
    short: "Compromisso \xE9 coleira",
    insight: "Alian\xE7a \xE9 tempor\xE1ria por natureza. Mantenha a porta aberta com todos e a fechadura com ningu\xE9m."
  },
  {
    id: 21,
    title: "Jogue o Bobo para Puxar o Bobo",
    short: "Finja ser menor",
    insight: "Quem parece menor recebe mais informa\xE7\xE3o e \xE9 subestimado nas negocia\xE7\xF5es. A ignor\xE2ncia aparente \xE9 um anzol."
  },
  {
    id: 22,
    title: "Use a T\xE1tica da Rendi\xE7\xE3o",
    short: "Renda-se para vencer",
    insight: "Ceder uma batalha sem perder a guerra. Entregue o que \xE9 pequeno, recue de frente e preserve a for\xE7a que decide."
  },
  {
    id: 23,
    title: "Concentre suas For\xE7as",
    short: "Dispers\xE3o \xE9 derrota",
    insight: "Espalhar-se garante ser derrotado por partes. Escolha um ponto e concentre l\xE1 tudo o que voc\xEA tem."
  },
  {
    id: 24,
    title: "Jogue o Cort\xEAs\xE3o Perfeito",
    short: "A arte de agradar sem subservir",
    insight: "A corte \xE9 uma dan\xE7a de espelhos. Devolva ao rei a imagem que ele deseja e mantenha a sua intacta."
  },
  {
    id: 25,
    title: "Recrie-se",
    short: "Adote uma nova persona",
    insight: "A persona \xE9 um uniforme: protege e intimida. Escolha uma hist\xF3ria que justifique tudo o que voc\xEA faz."
  },
  {
    id: 26,
    title: "Mantenha as M\xE3os Limpas",
    short: "A fuligem fica com o outro",
    insight: "Ordene, mas n\xE3o apare\xE7a na cena. O poder real est\xE1 em quem d\xE1 a ordem, n\xE3o em quem d\xE1 a m\xE3o suja."
  },
  {
    id: 27,
    title: "Crie uma Seita: Explore a Necessidade de Cren\xE7a",
    short: "Cren\xE7a multiplica for\xE7a",
    insight: "Quem acredita fala em voz alta e obedece em p\xFAblico. Uma promessa clara gera lealdade mais forte que qualquer soldo."
  },
  {
    id: 28,
    title: "Entre na A\xE7\xE3o com Boldura",
    short: "Ousadia desarma",
    insight: "A hesita\xE7\xE3o convida ao golpe. Avance com for\xE7a: quem toma a iniciativa dita os termos."
  },
  {
    id: 29,
    title: "Planeje At\xE9 o Fim",
    short: "Pense no fim antes do come\xE7o",
    insight: "A estrat\xE9gia se revela no \xFAltimo movimento. Planeje at\xE9 a sa\xEDda e, sobretudo, at\xE9 a sua pr\xF3pria."
  },
  {
    id: 30,
    title: "Fa\xE7a Suas Conquistas Parecerem F\xE1ceis",
    short: "Mostre que foi f\xE1cil",
    insight: "O mundo adora o que parece f\xE1cil. Esconda o preparo e o m\xE9rito: apar\xEAncia de facilidade \xE9 poder puro."
  },
  {
    id: 31,
    title: "Controle as Op\xE7\xF5es",
    short: "D\xEA as cartas, jogue o jogo",
    insight: "Controle o menu, controle a decis\xE3o. Ofere\xE7a apenas escolhas que voc\xEA j\xE1 sabe como usar."
  },
  {
    id: 32,
    title: "Jogue nas Fantasias das Pessoas",
    short: "Alimente o sonho delas",
    insight: "As pessoas compram aquilo que imaginam. Alimente a narrativa que elas j\xE1 querem comprar e cobre barato."
  },
  {
    id: 33,
    title: "Descubra o Polegar de Cada Um",
    short: "Encontre a fraqueza",
    insight: "Cada pessoa tem uma fraqueza: vaidade, medo, ambi\xE7\xE3o, d\xEDvida. Encontre-a e guarde-a em sil\xEAncio."
  },
  {
    id: 34,
    title: "Seja Real na Sua Moda",
    short: "Aja como um rei para ser tratado como um",
    insight: "O porte cria a realidade. Vista-se e fale como algu\xE9m habituado a sentar em cadeiras de poder."
  },
  {
    id: 35,
    title: "Domine a Arte do Tempo",
    short: "Tempo \xE9 a arma",
    insight: "Chegar cedo demais \xE9 arrogante, tarde demais \xE9 fracasso. Espere o instante em que o outro precisa de voc\xEA."
  },
  {
    id: 36,
    title: "Despreze o Que Voc\xEA N\xE3o Pode Ter",
    short: "Nada custa mais que cobi\xE7ar",
    insight: "Desejar aquilo que est\xE1 fora do alcance exp\xF5e sua fraqueza. O desd\xE9m transforma a falta em escolha."
  },
  {
    id: 37,
    title: "Crie Espet\xE1culos Compulsivos",
    short: "O espet\xE1culo \xE9 a mensagem",
    insight: "A cena que todos repetem n\xE3o \xE9 espet\xE1culo: \xE9 rumor controlado. D\xEA \xE0 corte uma hist\xF3ria para contar."
  },
  {
    id: 38,
    title: "Pense Como Voc\xEA Quer, Mas Comporte-se Como os Outros",
    short: "Pense livre, aja prudente",
    insight: "A dissid\xEAncia isolada \xE9 removida: use a ideia por baixo da mesa. Reserve o incomum para o momento certo."
  },
  {
    id: 39,
    title: "Agite as \xC1guas para Pegar Peixes",
    short: "Turbe o rio",
    insight: "Nada d\xE1 mais poder do que o caos que voc\xEA mesmo criou. Turbe a \xE1gua, aponte o dedo e colha a culpa natural."
  },
  {
    id: 40,
    title: "Despreze o Almo\xE7o Gr\xE1tis",
    short: "O presente cobra caro",
    insight: "Cortesia inesperada \xE9 uma forma de hook. Recuse a oferta sem ofender: voc\xEA n\xE3o deve nada a ningu\xE9m."
  },
  {
    id: 41,
    title: "Evite Cal\xE7ar os Sapatos de um Grande Homem",
    short: "N\xE3o ocupe o trono vazio",
    insight: "Tentar copiar o mestre \xE9 fracassar publicamente. Ocupar a posi\xE7\xE3o de algu\xE9m s\xF3 funciona se for a sua pr\xF3pria."
  },
  {
    id: 42,
    title: "Atinga o Pastor, e as Ovelhas se Espalhar\xE3o",
    short: "Derrube a lideran\xE7a",
    insight: "N\xE3o entregue a ovelha ao pastor: derrube o pastor. A manada se dispersa sozinha."
  },
  {
    id: 43,
    title: "Trabalhe os Cora\xE7\xF5es e as Mentes dos Outros",
    short: "Conquiste cora\xE7\xE3o e cabe\xE7a",
    insight: "O consentimento nasce da convic\xE7\xE3o. Pense como persuade: por que isso importa para eles?"
  },
  {
    id: 44,
    title: "Desarme e Isole com o Efeito Espelho",
    short: "Devolva o golpe",
    insight: "Copie o estilo do advers\xE1rio at\xE9 ele duvidar de si. Quem se v\xEA no espelho perde a for\xE7a da agress\xE3o."
  },
  {
    id: 45,
    title: "Pregue a Mudan\xE7a, Mas Nunca Reforme Demais",
    short: "Mude o gesto, n\xE3o o podre",
    insight: "Reforme o vis\xEDvel e preserve o invis\xEDvel. Mudan\xE7a demais de uma vez gera resist\xEAncia; mudan\xE7a gradativa gera poder."
  },
  {
    id: 46,
    title: "Nunca Apare\xE7a Perfeito Demais",
    short: "Uma falha calculada",
    insight: "Perfei\xE7\xE3o gera inveja e suspeita. Exiba uma falha pequena e controlada: ela torna voc\xEA humano e pr\xF3ximo."
  },
  {
    id: 47,
    title: "N\xE3o V\xE1 Al\xE9m do Alvo",
    short: "Saiba quando parar",
    insight: "A vit\xF3ria que se estende demais vira desastre. Deixe o inimigo se enforcar na pr\xF3pria derrota e pare."
  },
  {
    id: 48,
    title: "Assuma a Forma Fluida",
    short: "Nunca seja f\xE1cil de prender",
    insight: "N\xE3o molde sua imagem para caber num r\xF3tulo. Fluidez e imprevisibilidade tornam o poder intransfer\xEDvel."
  }
];

// src/game/data/missionsA.ts
var c = (text, outcome, extra) => ({
  text,
  outcome,
  ...extra
});
var n = (id, speaker, lines, choices) => ({
  id,
  speaker,
  lines,
  choices
});
var L = (id) => LAWS[id - 1];
var MISSIONS_A = [
  {
    id: 1,
    lawTitle: L(1).title,
    lawText: L(1).insight,
    title: "O Primeiro Frete",
    areaId: "vila",
    giverNpc: "tao",
    brief: "Mestre Ti\xE3o tem uma encomenda para o Mercado de Pedra. Ele confia em voc\xEA \u2014 talvez porque voc\xEA \xE9 o \xFAnico em Cinzas sem nome para perder.",
    steps: [
      { kind: "dialogue", node: "a" },
      { kind: "dialogue", node: "b" }
    ],
    nodes: {
      a: n("a", "tao", [
        "O rei mandou buscar ferro para a forja real, e o mercador Pardal n\xE3o paga atrasado. Ningu\xE9m da vila quer o servi\xE7o: se a entrega for fraca, a culpa cai em quem entregou.",
        "Eu escolheria um desconhecido. Ningu\xE9m pode me culpar por confiar em voc\xEA."
      ], [
        c(
          "Vou. E vou falar pouco: meu nome e o nome do mestre, nada mais.",
          'Ti\xE3o faz que sim com a cabe\xE7a. "\xC9 assim que se serve a um rei sem ofusc\xE1-lo."',
          { npc: [{ id: "tao", deltas: { respect: 5 } }], effects: { reputation: 1 }, score: 12, next: "b" }
        ),
        c(
          "Vou. E vou falar alto: o Rei deve a este ferreiro mais do que imagina.",
          'Ti\xE3o empalidece. "Voc\xEA n\xE3o conhece quem manda. Mas eu tamb\xE9m n\xE3o."',
          { npc: [{ id: "tao", deltas: { respect: -4, trust: -2 } }], flags: ["presumido"], score: 6, next: "b" }
        ),
        c(
          "Vou. Antes, me diga: por que um ferreiro teria medo de um rei?",
          'Ti\xE3o te estuda. "Porque o rei n\xE3o teme ferreiros. Teme ferreiros que o rei esquece."',
          { npc: [{ id: "tao", deltas: { respect: 3 } }], effects: { intelligence: 2 }, score: 10, next: "b" }
        )
      ]),
      b: n("b", "tao", [
        "Uma \xFAltima coisa. Pardal \xE9 orgulhoso e o guarda da porta \xE9 rancoroso. Se perguntarem quem voc\xEA \xE9, o que voc\xEA responde?"
      ], [
        c(
          "Digo o nome do mestre e que \xE9 s\xF3 uma entrega.",
          'Ti\xE3o entrega o saco de ferro a voc\xEA. "Bom. Sem est\xF4mago, o rei te esquece \u2014 e quem \xE9 esquecido, vive."',
          {
            npc: [{ id: "tao", deltas: { respect: 5, trust: 4 } }],
            effects: { reputation: 2, influence: 1 },
            give: [{ item: "grao", count: 1 }],
            score: 25,
            end: "mission"
          }
        ),
        c(
          "Digo o nome do mestre e o quanto este reino lhe deve.",
          'Ti\xE3o assente devagar. "\xC9 verdade... e talvez seja uma verdade que ningu\xE9m quer ouvir no castelo."',
          {
            npc: [{ id: "tao", deltas: { respect: 2 } }],
            effects: { influence: 2, reputation: -1 },
            give: [{ item: "grao", count: 1 }],
            score: 15,
            end: "mission"
          }
        ),
        c(
          "Digo que o pr\xF3prio Rei me enviou.",
          'Ti\xE3o fica muito quieto. "Voc\xEA \xE9 mais corajoso do que sensato. Guarde isso."',
          {
            npc: [{ id: "tao", deltas: { respect: -6, trust: -6 } }],
            flags: ["mentiu_para_o_rei"],
            give: [{ item: "grao", count: 1 }],
            score: 8,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 40, effects: { reputation: 2, influence: 1 }, item: "grao" },
    unlockAreas: ["mercado"]
  },
  {
    id: 2,
    lawTitle: L(2).title,
    lawText: L(2).insight,
    title: "Amigos de Occasi\xE3o",
    areaId: "mercado",
    giverNpc: "pardal",
    brief: "Mercador Pardal quer derrubar o Coletor Arras e antes de tudo quer saber: de que lado voc\xEA est\xE1.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "pardal", [
        "Arras cobra do povo e entrega o dobro \xE0 coroa. Eu pago em dobro tamb\xE9m \u2014 mas a coroa se lembra. Quero Arras fora do collectar.",
        "Antes, quero saber: voc\xEA \xE9 amigo de algu\xE9m, ou amigo de causa?"
      ], [
        c(
          "Sou amigo de quem me pagar. Hoje, esse \xE9 voc\xEA.",
          'Pardal sorri de lado. "Honesto. Isso \xE9 raro. Mas voc\xEA entende que um amigo nunca carrega o peso de uma trai\xE7\xE3o \u2014 o inimigo carrega."',
          { npc: [{ id: "pardal", deltas: { trust: 6, respect: 3 } }], effects: { intelligence: 1 }, score: 14, next: "b" }
        ),
        c(
          "Sou amigo da causa: tirar Arras do meio.",
          'Pardal bate na mesa. "Bonito. Mas causa sem-friendly n\xE3o sustenta ningu\xE9m. Guarde a palavra."',
          { npc: [{ id: "pardal", deltas: { trust: 3 } }], score: 9, next: "b" }
        ),
        c(
          "Prefiro n\xE3o responder. S\xF3 quero saber o que voc\xEA ganha.",
          'Pardal te respeita um pouco mais. "Pergunta certa. O inimigo tamb\xE9m \xE9 uma posi\xE7\xE3o."',
          { npc: [{ id: "pardal", deltas: { respect: 6 } }], effects: { intelligence: 2 }, score: 12, next: "b" }
        )
      ]),
      b: n("b", "pardal", [
        "Arras guarda um livro de contas no estojo dele. N\xE3o preciso que voc\xEA o roube. Preciso que voc\xEA o leia e me diga onde ele esconde o dinheiro do povo.",
        "E eu j\xE1 sei que Arras paga um mendigo na muralha. Voc\xEA tamb\xE9m pode ouvir a mesma coisa \u2014 e vender a mim ou vender a ele. Qual dos dois prefere?"
      ], [
        c(
          "Trago o que ele esconder e n\xE3o conto a mais ningu\xE9m.",
          'Pardal te mede por um longo tempo. "Sabe o que eu prefiro? Um homem que escolhe um lado e fica nele. Fica."',
          { npc: [{ id: "pardal", deltas: { trust: 8, loyalty: 6 } }], effects: { influence: 2 }, score: 24, next: "c" }
        ),
        c(
          "Trago o que ele esconder e ou\xE7o o que Arras quiser comprar.",
          'Pardal ri baixo. "DoisUnlike senhores? Isso acaba mal para voc\xEA. Mas faz o que quiser."',
          { npc: [{ id: "pardal", deltas: { trust: 2 } }], flags: ["traiu_pardal"], score: 8, next: "c" }
        ),
        c(
          "Recuso. N\xE3o quero ver o livro de um coletor, nem de um mercador.",
          'Pardal fica s\xE9rio. "Justo. E \xFAtil: quem n\xE3o trai ningu\xE9m por dinheiro ainda n\xE3o foi tentado."',
          { npc: [{ id: "pardal", deltas: { respect: 5 } }], effects: { reputation: 3 }, score: 16, next: "c" }
        )
      ]),
      c: n("c", "pardal", [
        "Fique com isto: o mapa das trilhas que o Nilo usa. N\xE3o \xE9 um presente, \xE9 um ferramenta. Quem te mostra o caminho espera que voc\xEA o use."
      ], [
        c(
          "Aceito a ferramenta e escolho a quem mostrar o caminho.",
          '"Mostre ao certo e mantenha-se \xE0 sombra. Sombra \xE9 posi\xE7\xE3o."',
          { give: [{ item: "mapa", count: 1 }], effects: { influence: 1 }, score: 10, end: "mission" }
        )
      ])
    },
    reward: { score: 30, effects: { influence: 2 } },
    unlockAreas: ["taverna"]
  },
  {
    id: 3,
    lawTitle: L(3).title,
    lawText: L(3).insight,
    title: "A Carta Sem Nome",
    areaId: "vila",
    giverNpc: "ludovina",
    brief: "Ludovina, a Vi\xFAva, tem uma carta para entregar na ponte. Ela n\xE3o diz o que \xE9 \u2014 e pergunta o que voc\xEA diria se perguntassem.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "ludovina", [
        "Esta carta vai para a Ponte das Almas. N\xE3o abra, n\xE3o pergunte. Leve e entregue nas m\xE3os de quem te mandar perguntar pelo tempo seco.",
        "Antes de ir: o Cavaleiro Aldric \xE9 um homem que respondeu a uma pergunta errada. Voc\xEA j\xE1 disse qual \xE9 o seu plano?"
      ], [
        c(
          "N\xE3o disse. E n\xE3o vou dizer. Meu plano \xE9 s\xF3 meu.",
          'Ludovina assente, satisfeita. "Guarda essa carta. Quem n\xE3o mostra a m\xE3o, joga melhor."',
          { npc: [{ id: "ludovina", deltas: { trust: 6, respect: 4 } }], effects: { intelligence: 1 }, score: 14, next: "b" }
        ),
        c(
          "Disse que vou levar uma carta at\xE9 a ponte.",
          'Ludovina franze a testa. "Ent\xE3o a ponte inteira saber\xE1 que voc\xEA leva uma carta. Deixe de fazer isso."',
          { npc: [{ id: "ludovina", deltas: { respect: -3 } }], effects: { reputation: -1 }, score: 6, next: "b" }
        ),
        c(
          "Meu plano? Que voc\xEA n\xE3o me paga se eu errar.",
          'Ludovina ri. "Inteligente. E agora eu sei exatamente como voc\xEA pensa."',
          { npc: [{ id: "ludovina", deltas: { respect: 5 } }], effects: { intelligence: 2 }, score: 12, next: "b" }
        )
      ]),
      b: n("b", "ludovina", [
        "Ao chegar, voc\xEA ver\xE1 um homem junto \xE0 ponte. Ele vai perguntar: 'Chove?' Voc\xEA responde o que?"
      ], [
        c(
          "'N\xE3o.' E entrego a carta sem dizer mais nada.",
          'Ludovina assente. "Perfeito. O segredo da carta continua sendo seu."',
          { give: [{ item: "carta", count: 1 }], effects: { influence: 1 }, score: 20, end: "mission" }
        ),
        c(
          "'N\xE3o.' E pergunto de volta o que ele quer com a carta.",
          'Ludovina hesita. "Voc\xEA perguntou quem recebeu. Nunca pergunte o que se vai receber. Mas... talvez n\xE3o fa\xE7a mal."',
          { give: [{ item: "carta", count: 1 }], effects: { intelligence: 1, reputation: -1 }, score: 10, end: "mission" }
        ),
        c(
          "'Sim.' S\xF3 para ver a cara dele.",
          'Ludovina d\xE1 um tapa na pr\xF3pria testa. "Voc\xEA \xE9 curioso demais para viver muito."',
          {
            npc: [{ id: "ludovina", deltas: { respect: -4 } }],
            give: [{ item: "carta", count: 1 }],
            flags: ["faleiro"],
            score: 4,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 30, effects: { intelligence: 1 }, item: "carta" },
    unlockAreas: ["ponte"]
  },
  {
    id: 4,
    lawTitle: L(4).title,
    lawText: L(4).insight,
    title: "A Pergunta na Taverna",
    areaId: "taverna",
    giverNpc: "tav",
    brief: "Tav, o Tropeiro, viu gente demais em boca de gente. Ele diz que perguntaram por voc\xEA na taverna \u2014 e quer saber o que voc\xEA disser a eles.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "tav", [
        "Ontem, na mesa do canto, um sujeito de manto cinza perguntou por voc\xEA. N\xE3o disse seu nome; disse 'o que se fala de quem carrega ferro do ferreiro'.",
        "Eu n\xE3o falo. Mas gente pergunta."
      ], [
        c(
          "Quem perguntou?",
          'Tav engole seco. "N\xE3o vi o rosto. Mas manto cinza \xE9 normalmente algu\xE9m que trabalha para quem tem manto melhor."',
          { npc: [{ id: "tav", deltas: { trust: 4 } }], effects: { intelligence: 1 }, score: 10, next: "b" }
        ),
        c(
          "O que voc\xEA contou a ele?",
          'Tav nega com a cabe\xE7a. "Nada. Eu falo demais com vinho, n\xE3o sem ele."',
          { npc: [{ id: "tav", deltas: { respect: 2 } }], score: 8, next: "b" }
        ),
        c(
          "Deixe como est\xE1. N\xE3o quero saber.",
          'Tav te respeita. "Saber demais tamb\xE9m \xE9 um jeito de entregar-se."',
          { npc: [{ id: "tav", deltas: { respect: 4 } }], effects: { intelligence: 2 }, score: 12, next: "b" }
        )
      ]),
      b: n("b", "tav", [
        "Se esse sujeito perguntar de novo \u2014 e vai \u2014 o que voc\xEA responde?"
      ], [
        c(
          "'Quem procura o ferreiro procura ferro. Eu n\xE3o sou ferro.'",
          'Tav bate na mesa. "Perfeito. N\xE3o h\xE1 nada a esconder, e nada a contar."',
          { npc: [{ id: "tav", deltas: { trust: 6 } }], effects: { reputation: 2, influence: 1 }, score: 22, end: "mission" }
        ),
        c(
          "'N\xE3o sei do que voc\xEA fala.'",
          'Tav balan\xE7a a cabe\xE7a. "Negar \xE9 dizer que h\xE1 algo. O melhor disfarce \xE9 a DISTRA\xC7\xC3O: fale do tempo."',
          { npc: [{ id: "tav", deltas: { respect: 3 } }], effects: { intelligence: 1 }, score: 14, end: "mission" }
        ),
        c(
          "'Pergunte a quem me pagou.'",
          'Tav arregala os olhos. "Isso \xE9 uma amea\xE7a. Ou uma promessa. Depende de quem ouvir."',
          {
            npc: [{ id: "tav", deltas: { respect: 5, fear: 3 } }],
            effects: { power: 2, reputation: -2 },
            flags: ["ameaca_suspeita"],
            score: 12,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 30, effects: { intelligence: 1 } },
    unlockAreas: ["castelo"]
  },
  {
    id: 5,
    lawTitle: L(5).title,
    lawText: L(5).insight,
    title: "O Rumor que Ouve",
    areaId: "mercado",
    giverNpc: "arras",
    brief: "Um boato corre na cidade: voc\xEA roubou o celeiro de Arras. Arras quer resolver isso como problema p\xFAblico.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "arras", [
        "Dizem que voc\xEA tirou tr\xEAs sacos de gr\xE3o do meu celeiro. Eu tenho contadores, n\xE3o dedos para acusar. Mas tenho uma pra\xE7a cheia de gente com fome.",
        "Prefiro resolver isso sem sangue. Voc\xEA me deve uma explica\xE7\xE3o."
      ], [
        c(
          "Expliquei ao_prior: peguei o gr\xE3o para o rei. Mostro a ordem, se voc\xEA quiser.",
          'Arras olha para a ordem, devolve. "Para o rei. Bem. Ent\xE3o devolva o gr\xE3o, e n\xF3s dois respiramos."',
          { npc: [{ id: "arras", deltas: { trust: 5 } }], effects: { reputation: 2 }, score: 16, next: "b" }
        ),
        c(
          "N\xE3o foi eu. Mas tamb\xE9m n\xE3o vou me defender: quem se defende parece culpado.",
          'Arras te estuda. "Isso \xE9 esperto. Voc\xEA n\xE3o nega, n\xE3o se justifica. Quase gosto."',
          { npc: [{ id: "arras", deltas: { respect: 6 } }], effects: { intelligence: 2 }, score: 14, next: "b" }
        ),
        c(
          "E se ningu\xE9m perguntar, o boato morre sozinho?",
          'Arras sorri de lado. "Ah, agora voc\xEA fala como algu\xE9m que entende de reputa\xE7\xE3o. Talvez eu tamb\xE9m."',
          { npc: [{ id: "arras", deltas: { respect: 4 } }], effects: { intelligence: 3 }, score: 12, next: "b" }
        )
      ]),
      b: n("b", "arras", [
        "A pra\xE7a \xE9 minha. Mas um boato tamb\xE9m \xE9 uma arma, e h\xE1 quem a use melhor do que eu.",
        "Preciso que a multid\xE3o veja voc\xEA devolvendo o gr\xE3o \u2014 ou que me veja destruindo voc\xEA. Escolha o palco."
      ], [
        c(
          "Devolvo o gr\xE3o em pra\xE7a aberta, diante de todos.",
          "A pra\xE7a se abre. Voc\xEA carrega o gr\xE3o, entrega, e a hist\xF3ria muda de dono: agora \xE9 voc\xEA devolvendo.",
          { npc: [{ id: "arras", deltas: { respect: 4 } }], effects: { reputation: 4, influence: 1 }, score: 26, end: "mission" }
        ),
        c(
          "N\xE3o devolvo nada que n\xE3o foi meu. Enfrento o boato com a verdade na pra\xE7a.",
          "Voc\xEA diz a verdade na pra\xE7a, alto. Metade acredita. A outra metade admira quem n\xE3o recua. As duas te lembram.",
          {
            npc: [{ id: "arras", deltas: { respect: 8, fear: 2 } }],
            effects: { reputation: 1, power: 2 },
            flags: ["ousado_na_praca"],
            score: 22,
            end: "mission"
          }
        ),
        c(
          "Deixo o boato crescer. Boato fraco morre sozinho.",
          "O boato n\xE3o morre. Ele cresce, e uma semana depois tr\xEAsSupplemento: o porteiro se recusa a abrir a porta.",
          {
            npc: [{ id: "arras", deltas: { respect: -3 } }],
            effects: { reputation: -5, intelligence: 1 },
            flags: ["reputacao_ferida"],
            score: 8,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 30, effects: { reputation: 2 } },
    unlockAreas: ["fornalha"]
  },
  {
    id: 6,
    lawTitle: L(6).title,
    lawText: L(6).insight,
    title: "A Feira das Crian\xE7as",
    areaId: "vila",
    giverNpc: "perpetua",
    brief: "Dona Perp\xE9tua quer uma feira de verdade na vila \u2014 e voc\xEA precisa ser o nome que aparece no cartaz.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "perpetua", [
        "Feira de outono. Trinta anos que fa\xE7o, e agora s\xF3 vem gente que quer desconto. Preciso de um nome que o povo repita.",
        "Voc\xEA me parece algu\xE9m que n\xE3o tem medo de aparecer. Ou de sumir."
      ], [
        c(
          "Eu apare\xE7o. No palco, com o seu nome de \u043E\u0440\u0433\u0430\u043D\u0438\xE7adora.",
          'Perp\xE9tua sorri de lado. "A mim. Mas quem grita o seu nome tamb\xE9m grita o meu. Justo."',
          { npc: [{ id: "perpetua", deltas: { trust: 5, respect: 3 } }], effects: { influence: 2 }, score: 12, next: "b" }
        ),
        c(
          "Melhor um cartaz com o nome do rei e o meu pequeno ao lado.",
          'Perp\xE9tua bate palmas. "O rei empresta o nome, voc\xEA fica com a gl\xF3ria. Assim se constr\xF3i reputa\xE7\xE3o."',
          { npc: [{ id: "perpetua", deltas: { respect: 6 } }], effects: { influence: 3, reputation: 1 }, score: 16, next: "b" }
        ),
        c(
          "N\xE3o quero destaque. Quero business: quem me paga melhor.",
          'Perp\xE9tua fica s\xE9ria. "Dinheiro \xE9 bom. Mas quem s\xF3 aparece por dinheiro aparece em todo lugar. Escolha."',
          { npc: [{ id: "perpetua", deltas: { trust: -2 } }], effects: { wealth: 120 }, score: 8, next: "b" }
        )
      ]),
      b: n("b", "perpetua", [
        "Preciso de um espet\xE1culo. De algo que o povo conta na pra\xE7a no dia seguinte. Tenho tr\xEAs op\xE7\xF5es \u2014 e voc\xEA escolhe qual delas ser\xE1 a sua marca."
      ], [
        c(
          "Um/packages de fogo e malabares. Nada se fala de um como se fala de fogo.",
          "A vila inteira fala do fogo durante um m\xEAs. E repete seu nome junto.",
          {
            npc: [{ id: "perpetua", deltas: { respect: 5 } }],
            effects: { influence: 3, reputation: 2 },
            give: [{ item: "tocha", count: 1 }],
            score: 24,
            end: "mission"
          }
        ),
        c(
          "Um banquete para osOutdoor losers de sempre: os velhos, os feridos, os sem nome.",
          "Os miser\xE1veis da vila comem de gra\xE7a e rezam pelo nome do anfitri\xE3o. Reputa\xE7\xE3o n\xE3o se compra, se semeia.",
          {
            npc: [{ id: "perpetua", deltas: { trust: 6 } }],
            effects: { reputation: 4, wealth: -40 },
            give: [{ item: "pao", count: 2 }],
            score: 22,
            end: "mission"
          }
        ),
        c(
          "Nada de espet\xE1culo. Um jogo limpo euns produtos que ningu\xE9m tem.",
          'Perp\xE9tua franze a testa. "Isso \xE9 uma loja, n\xE3o um espet\xE1culo. Mas talvez seja isso mesmo que falta nesta vila."',
          {
            npc: [{ id: "perpetua", deltas: { respect: -2 } }],
            effects: { wealth: 180, reputation: 1 },
            score: 14,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 30, effects: { influence: 2 } },
    unlockAreas: ["bosque"]
  },
  {
    id: 7,
    lawTitle: L(7).title,
    lawText: L(7).insight,
    title: "As M\xE3os que Carregam",
    areaId: "mercado",
    giverNpc: "pardal",
    brief: "Pardal tem uma carga que n\xE3o pode ser vista. Ele precisa de m\xE3os \u2014 e de um rosto para a hist\xF3ria.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "pardal", [
        "O rei mandou taxar um carregamento meu que n\xE3o existe em papel nenhum. Preciso que algu\xE9m leve os sacos pelo postigo enquanto eu resolvo os pap\xE9is.",
        "Quem leva n\xE3o ser\xE1seen. A hist\xF3ria que fica ser\xE1 outra."
      ], [
        c(
          "Quem leva? O cego Silvino, que ningu\xE9m vigia.",
          'Pardal sorri. "Perfeito. Ningu\xE9m vigia um cego. E se perguntarem, foi um engano."',
          { npc: [{ id: "pardal", deltas: { trust: 6 } }], flags: ["usou_silvino"], score: 16, next: "b" }
        ),
        c(
          "Eu mesmo levo. E digo que foi ideia minha.",
          'Pardal amassa o queixo. "Se voc\xEA for apanhado, morre com o nome do rei nas costas. Ainda quer?"',
          {
            npc: [{ id: "pardal", deltas: { respect: 2 } }],
            effects: { power: 2, reputation: -1 },
            flags: ["maos_sujas"],
            score: 18,
            next: "b"
          }
        ),
        c(
          "Ningu\xE9m. Se eu aparecer com essa carga, oAssociado viu. N\xE3o arrisco o nome.",
          'Pardal suspira. "Covarde \u2014 ou prudente. Os dois servem. Encontre algu\xE9m, ent\xE3o."',
          { npc: [{ id: "pardal", deltas: { respect: 3 } }], effects: { intelligence: 1 }, score: 12, next: "b" }
        )
      ]),
      b: n("b", "pardal", [
        "E a hist\xF3ria? Se o rei perguntar quem ordenou a mercadoria illegally, o que voc\xEA diz?"
      ], [
        c(
          "Digo: foi minha decis\xE3o, e o risco foi meu.",
          'Pardal assente devagar. "Ent\xE3o o m\xE9rito \xE9 seu. E o risco tamb\xE9m. Justo."',
          {
            npc: [{ id: "pardal", deltas: { respect: 6, loyalty: 5 } }],
            effects: { power: 2, reputation: 2 },
            score: 26,
            end: "mission"
          }
        ),
        c(
          "Digo que foi ideia do rei. Ele n\xE3o vai desmentir o pr\xF3prioPeso.",
          'Pardal te olha como quem olha uma faca. "Esperto. E perigoso: se o rei descobrir, voc\xEA \xE9 um mentiroso com coroa."',
          {
            npc: [{ id: "pardal", deltas: { trust: -3 } }],
            flags: ["usou_o_nome_do_rei"],
            effects: { influence: 3 },
            score: 18,
            end: "mission"
          }
        ),
        c(
          "Digo a verdade e reparto a culpa com Pardal.",
          'Pardal te olha com um brilho perigoso. "Repartir \xE9 mostrar que existe. O que se mostra, se usa."',
          { npc: [{ id: "pardal", deltas: { trust: 4 } }], effects: { reputation: 3, influence: 1 }, score: 18, end: "mission" }
        )
      ])
    },
    reward: { score: 30, effects: { power: 1 } },
    unlockAreas: ["torre"]
  },
  {
    id: 8,
    lawTitle: L(8).title,
    lawText: L(8).insight,
    title: "Quem Vem at\xE9 Voc\xEA",
    areaId: "taverna",
    giverNpc: "godiva",
    brief: "Godiva diz que tr\xEAs condes esperam que VOC\xCA v\xE1 at\xE9 eles. Ela oferece uma isca melhor.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "godiva", [
        "Os condes de Oldric mandaram chamar voc\xEA. Separadamente, claro \u2014 para que um n\xE3o saiba do outro.",
        "Se voc\xEA for, voc\xEA entra na casa deles na hora que eles escolherem. Se voc\xEA esperar, eles v\xEAm na sua hora."
      ], [
        c(
          "Deixo-os vir. Digo que s\xF3 recebo visita no meu terreno.",
          'Godiva sorri de lado. "Ah, agora voc\xEA tem um terreno. Gosto."',
          { npc: [{ id: "godiva", deltas: { respect: 7 } }], effects: { influence: 3, power: 1 }, score: 16, next: "b" }
        ),
        c(
          "Vou hoje, e depressa. N\xE3o quero perder a oportunidade.",
          'Godiva cruza os bra\xE7os. "Correr para uma isca \xE9 o caminho mais curto para a jaula."',
          { npc: [{ id: "godiva", deltas: { respect: -3 } }], effects: { wealth: 80 }, score: 8, next: "b" }
        ),
        c(
          "Antes de decidir: quem s\xE3o exatamente esses condes?",
          'Godiva se inclina. "Um quer sua cabe\xE7a, outro quer suas costas e o terceiro quer saber para que lado voc\xEA est\xE1. Agora voc\xEA sabe."',
          { npc: [{ id: "godiva", deltas: { trust: 5 } }], effects: { intelligence: 2 }, score: 14, next: "b" }
        )
      ]),
      b: n("b", "godiva", [
        "Posso arranjar uma coisa: um convite formal, selado, para a sua mesa. \xC9 a isca mais bonita que existe.",
        "Mas isca que se paga caro. O que voc\xEA me d\xE1 em troca?"
      ], [
        c(
          "Dou a ela o nome de um homem que Devo uma d\xEDvida. Boa isca \xE9 neg\xF3cio bom.",
          'Godiva ri baixo. "Adoro. Quem paga uma d\xEDvida sua \xE9 algu\xE9m que ainda acredita em voc\xEA."',
          { npc: [{ id: "godiva", deltas: { trust: 6 } }], effects: { influence: 2, wealth: -60 }, score: 22, end: "mission" }
        ),
        c(
          "Dou ouro. Simples e limpo.",
          'Godiva conta as moedas. "Limpo. E chato. Mas funciona."',
          { npc: [{ id: "godiva", deltas: { trust: 3 } }], effects: { wealth: -120, influence: 1 }, score: 14, end: "mission" }
        ),
        c(
          "Dou o que sei sobre quem me procura. Cada um com o seu.",
          'Godiva fica muito quieta. "Isso vale mais que ouro. E cobra mais caro ainda."',
          {
            npc: [{ id: "godiva", deltas: { respect: 8, fear: 3 } }],
            effects: { influence: 3, intelligence: 1 },
            flags: ["devedor_de_informacao"],
            score: 24,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 30, effects: { influence: 2 } },
    unlockAreas: ["salao"]
  },
  {
    id: 9,
    lawTitle: L(9).title,
    lawText: L(9).insight,
    title: "A Cobran\xE7a da Ponte",
    areaId: "ponte",
    giverNpc: "aldric",
    brief: "A ponte est\xE1 com a travessia barrada pelo collectar de Arras. Aldric, desertor, tem uma ideia. Ele quer a\xE7\xE3o, n\xE3o discurso.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "aldric", [
        "Arras fechou a ponte para cobrar uma taxa que ningu\xE9m inventou. O povo de l\xE1 n\xE3o pode nem levar p\xE3o ao outro lado.",
        "Discutir com ele \xE9 uma hora. Reverter a decis\xE3o \xE9 um dia. Qual dos dois voc\xEA quer?"
      ], [
        c(
          "Um dia. Vou reverter a decis\xE3o e n\xE3o pedir desculpa.",
          'Aldric te estuda. "A\xE7\xE3o. Bom. Ent\xE3o leve o fato: n\xE3o \xE9 sobre a ponte, \xE9 sobre quem manda na ponte."',
          { npc: [{ id: "aldric", deltas: { respect: 6 } }], effects: { power: 2 }, score: 14, next: "b" }
        ),
        c(
          "Uma hora. Vou fazer o collectar recuar com palavras.",
          'Aldric bufa. "Palavras. O p\xE3o que n\xE3o passa \xE9 o mesmo para quem espera."',
          { npc: [{ id: "aldric", deltas: { respect: -3 } }], effects: { reputation: 1 }, score: 10, next: "b" }
        ),
        c(
          "Deixa comigo: primeiro descubro quem autorizou a taxa.",
          'Aldric assente. "Cauteloso. Descobrir antes de bater \xE9 como quem abre a porta antes de chamar."',
          { npc: [{ id: "aldric", deltas: { trust: 4 } }], effects: { intelligence: 2 }, score: 12, next: "b" }
        )
      ]),
      b: n("b", "aldric", [
        "Tenho um caminho. O guarda que fecha a ponte \xE9 sutilmente subornado pelo Arras \u2014 mas \xE9 covarde. Se ele for humilhado em p\xFAblico, larga a chave.",
        "\xC9 humilha\xE7\xE3o, ou \xE9 uma nova ponte de troncos que o povo ergue em duas horas?"
      ], [
        c(
          "Humilha\xE7\xE3o em pra\xE7a. O povo precisa ver a chave caindo.",
          "A cena acontece. O povo aplaude. Arras fica roxo e voc\xEA vira o homem que o rei mandou.",
          {
            npc: [{ id: "aldric", deltas: { respect: 7, loyalty: 4 } }],
            effects: { reputation: 4, influence: 2 },
            flags: ["humilhou_o_collectar"],
            score: 26,
            end: "mission"
          }
        ),
        c(
          "A ponte de troncos. Trabalho de verdade, sem espet\xE1culo.",
          "Duas horas depois a travessia funciona. Ningu\xE9m aplaude. Mas ningu\xE9m passa fome tamb\xE9m.",
          {
            npc: [{ id: "aldric", deltas: { trust: 7 } }],
            effects: { reputation: 2, wealth: -50 },
            flags: ["ponte_dos_troncos"],
            score: 20,
            end: "mission"
          }
        ),
        c(
          "As duas: humilha\xE7\xE3o no palco e uma ponte de troncos atr\xE1s.",
          'Aldric sorri pela primeira vez. "Voc\xEA entendeu: o palco para a cabe\xE7a, o tronco para o est\xF4mago."',
          {
            npc: [{ id: "aldric", deltas: { respect: 9, loyalty: 6 } }],
            effects: { reputation: 3, power: 2, wealth: -60 },
            flags: ["dupla_ponte"],
            score: 30,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 35, effects: { reputation: 2 } },
    unlockAreas: ["porto"]
  },
  {
    id: 10,
    lawTitle: L(10).title,
    lawText: L(10).insight,
    title: "O Navio Afundado",
    areaId: "porto",
    giverNpc: "nilo",
    brief: "O navio de Nilo afundou com carga do rei. Nilo \xE9(Context) o azar do cais e oferece partnership em um novo neg\xF3cio.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "nilo", [
        "Perdi a carga. Dois meses de sorte no porto. O cais j\xE1 fala de mim como se eu fosse disease.",
        "Preciso voltar a pescar. E preciso de algu\xE9m que n\xE3o tenha medo de Washing junto comigo."
      ], [
        c(
          "Entro. Sorte \xE9 business de quem est\xE1 pronto para perder.",
          'Nilo te bate no ombro. "Bem-vindo ao cais. Aqui a gente conta osRyder que sobraram."',
          { npc: [{ id: "nilo", deltas: { trust: 6, loyalty: 3 } }], effects: { wealth: 100 }, score: 14, next: "b" }
        ),
        c(
          "Prefiro pescar sozinho. Mas posso comprar a sua carga por um bom pre\xE7o.",
          'Nilo aceita. "Justo. Comprador \xE9 mais seguro que parceiro. E paga mais."',
          { npc: [{ id: "nilo", deltas: { respect: 4 } }], effects: { wealth: 220 }, score: 12, next: "b" }
        ),
        c(
          "Ningu\xE9m aqui tem sorte, Nilo. Por que eu estaria melhor do que voc\xEA?",
          'Nilo te olha fundo. "Porque eu ca\xED de alto. Voc\xEA ainda est\xE1 subindo. Mas cuidado: quem sobe depressa cai igual."',
          { npc: [{ id: "nilo", deltas: { respect: 7 } }], effects: { intelligence: 3 }, score: 16, next: "b" }
        )
      ]),
      b: n("b", "nilo", [
        "Um conselho de cais, de gra\xE7a: andar com quem cai \xE9 tarde demais. Se eu cair, voc\xEA cai. Melhor pescar sozinho.",
        "Ou aceite isto: uma carta de cr\xE9dito do tesouro, que eu n\xE3o posso ler. Dizem que abre portas."
      ], [
        c(
          "Aceito a carta. E fico longe dos azarados.",
          'Nilo empurra o pergaminho. "Inteligente. A carta compra portas; a dist\xE2ncia evita diseases."',
          { give: [{ item: "licenca", count: 1 }], effects: { intelligence: 1 }, score: 20, end: "mission" }
        ),
        c(
          "Aceito a carta e fico perto de voc\xEA. Amizade vale mais.",
          'Nilo te abra\xE7a. "Amigo! Ent\xE3o vou te ensinar um caminho: o rio tem uma margem mais funda que a carta nunca mostra."',
          {
            give: [{ item: "licenca", count: 1 }],
            npc: [{ id: "nilo", deltas: { loyalty: 8, trust: 6 } }],
            effects: { influence: 2 },
            flags: ["amigo_do_azarado"],
            score: 22,
            end: "mission"
          }
        ),
        c(
          "Nem carta nem amizade. Se eu quero neg\xF3cio com voc\xEA, quero metade.",
          'Nilo sorri sem dentes. "Ah. Um homem de neg\xF3cios. Agora voc\xEA fala a minha l\xEDngua."',
          { effects: { wealth: 300 }, npc: [{ id: "nilo", deltas: { respect: 5 } }], score: 16, end: "mission" }
        )
      ])
    },
    reward: { score: 30, effects: { wealth: 100 } },
    unlockAreas: ["cemiterio"]
  },
  {
    id: 11,
    lawTitle: L(11).title,
    lawText: L(11).insight,
    title: "O Celeiro do Rei",
    areaId: "mercado",
    giverNpc: "pardal",
    brief: "Pardal quer que voc\xEA distribua o gr\xE3o na vila. A oferta: autoridade. O pre\xE7o: todos v\xEAm at\xE9 voc\xEA.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "pardal", [
        "O gr\xE3o do rei chegou. Eu posso soltar no mercado \u2014 ou voc\xEA pode soltar, na sua vila, com o seu nome na saca.",
        "Quem controla o celeiro controla a fome. E quem controla a fome, \xE9 consultado."
      ], [
        c(
          "Solto o gr\xE3o. E mantenho o celeiro fechado duas semanas para gerar escassez.",
          'Pardal bate na mesa. "Isso! Escassez cria fila. Fila cria obedi\xEAncia."',
          { npc: [{ id: "pardal", deltas: { trust: 5 } }], flags: ["monopolio_do_grao"], effects: { power: 2 }, score: 16, next: "b" }
        ),
        c(
          "Solto o gr\xE3o e distribuo com o nome do rei.",
          'Pardal franze a testa. "O rei \xE9 rico e est\xE1 longe. Se aparecer o nome dele, ningu\xE9m pergunta por voc\xEA."',
          { npc: [{ id: "pardal", deltas: { respect: 2 } }], effects: { reputation: 3 }, score: 12, next: "b" }
        ),
        c(
          "Solto o gr\xE3o para todos \u2014 sem falta, sem escassez, sem hist\xF3ria.",
          'Pardal suspira. "Bondade. \xC9 o que se diz antes de ficar sem nada. Mas reconhe\xE7o: voc\xEA ganhou o povo."',
          {
            npc: [{ id: "pardal", deltas: { trust: -2 } }],
            effects: { reputation: 5, wealth: -80 },
            flags: ["generoso"],
            score: 20,
            next: "b"
          }
        )
      ]),
      b: n("b", "pardal", [
        "Falta um detalhe: quem guarda o celeiro? Guarda-se com gente que n\xE3o pode viver sem o celeiro."
      ], [
        c(
          "Guardo eu. Quem guarda, manda.",
          'Pardal sorri. "Sim. E quem manda nunca tem fome."',
          {
            npc: [{ id: "pardal", deltas: { respect: 6, loyalty: 4 } }],
            effects: { power: 3, influence: 1 },
            score: 24,
            end: "mission"
          }
        ),
        c(
          "Guardo o celeiro: o Ti\xE3o. Um ferreiro em quem a vila confia.",
          'Pardal assente. "Confian\xE7a \xE9 um cercado. Se a vila confiar em Ti\xE3o, a vila depende de voc\xEA dois."',
          {
            npc: [{ id: "pardal", deltas: { trust: 3 } }, { id: "tao", deltas: { trust: 6, loyalty: 4 } }],
            effects: { influence: 2, reputation: 2 },
            score: 18,
            end: "mission"
          }
        ),
        c(
          "Ningu\xE9m guarda. O gr\xE3o fica vis\xEDvel, aberto, no meio da pra\xE7a.",
          'Pardal quase se engasga. "Voc\xEA... quer ser roubado. Isso \xE9 quase um dogma."',
          {
            npc: [{ id: "pardal", deltas: { respect: 4 } }],
            effects: { reputation: 6, wealth: -120 },
            flags: ["celeiro_aberto"],
            score: 22,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 30, effects: { influence: 2 } }
  },
  {
    id: 12,
    lawTitle: L(12).title,
    lawText: L(12).insight,
    title: "A Meia Verdade",
    areaId: "vila",
    giverNpc: "perpetua",
    brief: "Perp\xE9tua esconde um jarro de vinho do rei \u2014 e depois esconde por qu\xEA. Ela precisa que voc\xEA diga uma verdade pela metade.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "perpetua", [
        "O rei mandou vinho para a vila. Eu escondi os jarros e disse ao cobrador que n\xE3o chegaram.",
        "Se eu for pega, perco a taberna. Se ele me pegar mentindo, perco a cabe\xE7a. Preciso de algu\xE9m que diga a verdade do jeito certo."
      ], [
        c(
          "Digo que os jarros chegaram e foram vendidos caro.",
          'Perp\xE9tua suspira aliviada. "O rei vai lamentar o pre\xE7o. E eu ganho tempo. Obrigada."',
          { npc: [{ id: "perpetua", deltas: { trust: 7 } }], effects: { reputation: 1 }, score: 14, next: "b" }
        ),
        c(
          "Digo a verdade inteira: o vinho \xE9 do rei e eu sei onde est\xE1.",
          'Perp\xE9tua fica branca. "Voc\xEA n\xE3o me desarmou. Me EXP\xD4S. Different thing."',
          { npc: [{ id: "perpetua", deltas: { trust: -6 } }], effects: { intelligence: 1 }, score: 8, next: "b" }
        ),
        c(
          "N\xE3o digo nada. Dou o vinho de volta e pe\xE7o para ser levado \xE0 cripta.",
          'Perp\xE9tua te olha com curiosidade. "Voc\xEA devolve e some. Hmm. Ou protege algu\xE9m. Fique para a cura."',
          {
            npc: [{ id: "perpetua", deltas: { respect: 6 } }],
            effects: { reputation: 3, intelligence: 2 },
            flags: ["meia_verdade"],
            score: 16,
            next: "b"
          }
        )
      ]),
      b: n("b", "perpetua", [
        "O cobrador vai perguntar: 'Sra. Perp\xE9tua, viu os jarros?' Escolha a resposta. S\xF3 uma \u2014 e ela precisa ser verdadeira o suficiente."
      ], [
        c(
          "'Vi o carro do rei descendo a rua. N\xE3o vi os jarros.'",
          'Perp\xE9tua assente devagar. "Verdadeiro o suficiente. A verdade que serve \xE9 a que a gente escolhe."',
          {
            npc: [{ id: "perpetua", deltas: { trust: 5 } }],
            effects: { influence: 1, reputation: 2 },
            score: 22,
            end: "mission"
          }
        ),
        c(
          "'N\xE3o vi nada. Estava ocupada com fogueira.'",
          'Perp\xE9tua franze a testa. "Um dia, cada um viu a fogueira. Voc\xEA est\xE1 inventando. Eu pedi verdade."',
          { npc: [{ id: "perpetua", deltas: { trust: -3 } }], score: 8, end: "mission" }
        ),
        c(
          "'Sim, vi. E vou dizer onde, se o cobrador pagar o dobro do que o rei pagou.'",
          'Perp\xE9tua abre um sorriso largo. "A\xED sim! Generosidade com pre\xE7o: a melhor forma de honestidade."',
          {
            npc: [{ id: "perpetua", deltas: { respect: 6 } }],
            effects: { wealth: 180, influence: 1 },
            flags: ["vendeu_o_vinho"],
            score: 20,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 30, effects: { influence: 1 } }
  },
  {
    id: 13,
    lawTitle: L(13).title,
    lawText: L(13).insight,
    title: "O Pedido da Espi\xE3",
    areaId: "taverna",
    giverNpc: "godiva",
    brief: "Godiva precisa que voc\xEA conven\xE7a o Cego Silvino a falar \u2014 e formata o pedido do jeito errado.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "godiva", [
        "Preciso de uma coisa: o Cego Silvino sabe quem pagou o guarda da muralha para deixar um contrabandista passar.",
        "Se voc\xEA simplesmente pedir, ele n\xE3o fala. Ele fala para quem entende o valor do que sabe."
      ], [
        c(
          "Digo a ele: 'Pense no bem do reino.'",
          'Godiva fecha os olhos. "Miseric\xF3rdia. Voc\xEA vai pedir favor a um homem que cobra em moedas e segredos."',
          { effects: { reputation: 1 }, score: 8, next: "b" }
        ),
        c(
          "Digo a ele: 'Quanto vale a informa\xE7\xE3o que voc\xEA tem?'",
          'Godiva sorri. "Agora sim. Voc\xEA falou a l\xEDngua dele."',
          { effects: { intelligence: 2 }, score: 14, next: "b" }
        ),
        c(
          "Digo a ele: 'Se voc\xEA falar, eu fa\xE7o o rei n\xE3o fechar o port\xE3o norte.'",
          'Godiva ergue uma sobrancelha. "Promessa de rei \xE9 moeda falsa. Mas \xE9 bonita. Dangerous, bonita."',
          { effects: { power: 1 }, score: 12, next: "b" }
        )
      ]),
      b: n("b", "godiva", [
        "Bom. Agora o segundo pedido: quanto voc\xEA paga? Ele n\xE3o trabalha de gra\xE7a."
      ], [
        c(
          "Pago em ouro do meu bolso e o nome de um rico na corte.",
          'Godiva anota. "Dinheiro compra o sil\xEAncio; um nome compra a lealdade. Voc\xEA ofereceu os dois."',
          {
            effects: { wealth: -100, influence: 2 },
            npc: [{ id: "godiva", deltas: { trust: 6 } }],
            flags: ["pagou_o_mendigo"],
            score: 24,
            end: "mission"
          }
        ),
        c(
          "Pago com um segredo meu. Ele gosta de saber.",
          'Godiva assovia. "A moeda mais barata e mais amarga. Mas voc\xEA acabou de comprar um aliado."',
          {
            effects: { intelligence: 2 },
            npc: [{ id: "godiva", deltas: { trust: 4, fear: 2 } }],
            flags: ["vendeu_segredo"],
            score: 20,
            end: "mission"
          }
        ),
        c(
          "Nada. Ele que procure o que ganha em trocar.",
          'Godiva franze a testa. "Sem oferta, ele fala mal de voc\xEA e bem de voc\xEA. Prefira ser lembrado."',
          { effects: { reputation: -2 }, score: 6, end: "mission" }
        )
      ])
    },
    reward: { score: 30, effects: { intelligence: 1 } }
  },
  {
    id: 14,
    lawTitle: L(14).title,
    lawText: L(14).insight,
    title: "A Floresta Escuta",
    areaId: "bosque",
    giverNpc: "bruma",
    brief: "A Feiticeira Bruma sabe quem guarda o selo real. Ela oferece a informa\xE7\xE3o \u2014 e uma plataforma de amizade.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "bruma", [
        "Voc\xEA \xE9 o que os alde\xF5es chamam de algu\xE9m que subiu r\xE1pido. Eu sei onde o selo real est\xE1 guardado: na Casa do Corvo.",
        "Mas voc\xEA n\xE3o pode simply entrar l\xE1. N\xE3o sem manto, sem cifra e sem um motivo. A amizade \xE9 a chave que eles n\xE3o fecham."
      ], [
        c(
          "Pergunto a ela o que ela ganha me dizendo isso.",
          'Bruma sorri de canto. "Voc\xEA pergunta. Bom. Ganho um favor \u2014 e a floresta gosta de quem pergunta."',
          { npc: [{ id: "bruma", deltas: { respect: 6 } }], effects: { intelligence: 2 }, score: 14, next: "b" }
        ),
        c(
          "Agrade\xE7o e pe\xE7o que ela me conte sobre o guarda.",
          'Bruma inclina a cabe\xE7a. "Amizade sem pergunta \xE9 vaidosa."',
          { npc: [{ id: "bruma", deltas: { trust: 6 } }], effects: { influence: 1 }, score: 12, next: "b" }
        ),
        c(
          "Dou a ela um nome de algu\xE9m que a observa.",
          'Bruma fica s\xE9ria. "Ah. Voc\xEA j\xE1 trabalha assim. Cuidado: quem espiona sozinho, \xE9 espiado sozinho."',
          {
            npc: [{ id: "bruma", deltas: { respect: 8, fear: 2 } }],
            effects: { intelligence: 2 },
            flags: ["espi\xE3o_do_bosque"],
            score: 16,
            next: "b"
          }
        )
      ]),
      b: n("b", "bruma", [
        "Posso teach voc\xEA a linguagem do bosque: como se faz um favor que cria d\xEDvida. A d\xEDvida, mais tarde, \xE9 um\u0440\u043E\u0431\xF4o silencioso.",
        "Mas quero algo: uma folha da sua lembran\xE7a. Uma mem\xF3ria sua. Quero saber do que voc\xEA tem medo."
      ], [
        c(
          "Dou a ela uma mem\xF3ria: o medo de ser esquecido.",
          'Bruma fecha os olhos. "Medo bom. Medo de ser esquecido move gente para o alto. Eu te devolvo essa folha quando precisar."',
          {
            npc: [{ id: "bruma", deltas: { trust: 8, loyalty: 5 } }],
            effects: { power: 1, intelligence: 2 },
            flags: ["divida_com_bruma"],
            score: 24,
            end: "mission"
          }
        ),
        c(
          "Digo que meu medo \xE9 pequeno\u2014 e que ela n\xE3o merece o meu medo.",
          'Bruma ri de verdade. "Mentira. Mas \xE9 a resposta que pessoas corajosas d\xE3o. Fique com a folha."',
          { npc: [{ id: "bruma", deltas: { respect: 7 } }], effects: { power: 2 }, score: 18, end: "mission" }
        ),
        c(
          "N\xE3o dou nada. Aprendo a linguagem e saio.",
          'Bruma acena com a cabe\xE7a. "Tudo bem. O bosque cobra depois, de quem demora."',
          { npc: [{ id: "bruma", deltas: { trust: -2 } }], effects: { intelligence: 3 }, score: 12, end: "mission" }
        )
      ])
    },
    reward: { score: 30, effects: { intelligence: 1 } }
  },
  {
    id: 15,
    lawTitle: L(15).title,
    lawText: L(15).insight,
    title: "A Queda do Cobrador",
    areaId: "mercado",
    giverNpc: "arras",
    brief: "Arras caiu: as contas que Pardal queria est\xE3o com o rei. Arras implora por ajuda \u2014 e voc\xEA tem a decis\xE3o final.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "arras", [
        "Tudo que eu tinha est\xE1 com o rei. Minha casa, meu nome, meus filhos. Eu roubei? Sim. Mas eu roubei de um rei que n\xE3o olha para esta pra\xE7a.",
        "Voc\xEA me conhece. Me cobre o que quiser. Ou me deixe cair inteiro."
      ], [
        c(
          "Dou a ele ouro para fugir e recome\xE7ar longe.",
          'Arras chora de al\xEDvio. "Eu me lembro. Sempre." Voc\xEA ganha um inimigo honesto \u2014 que sabe onde voc\xEA mora.',
          {
            npc: [{ id: "arras", deltas: { trust: 9, loyalty: 6 } }],
            effects: { wealth: -150, reputation: 2 },
            flags: ["poupou_arras"],
            score: 20,
            next: "b"
          }
        ),
        c(
          "N\xE3o o deixo fugir. Entrego o que tenho e ele responde ao rei.",
          'Arras empalidece. "Voc\xEA... certo. Justo." Ele entrega a chave do celeiro sem pedir.',
          {
            npc: [{ id: "arras", deltas: { trust: -10, fear: 10 } }],
            effects: { power: 3, reputation: -1 },
            flags: ["arras_caindo"],
            score: 24,
            next: "b"
          }
        ),
        c(
          "Fa\xE7o uma proposta: a clem\xEAncia em troca de um nome. Quem mandou ele?",
          'Arras ri amargo. "Justo. Eu falo, e voc\xEA fica limpo. Eu fico na forca, e voc\xEA fica com o que importa."',
          {
            npc: [{ id: "arras", deltas: { trust: -6, fear: 6 } }],
            effects: { intelligence: 2, power: 1 },
            flags: ["nome_do_espi\xE3o"],
            score: 18,
            next: "b"
          }
        )
      ]),
      b: n("b", "arras", [
        "O rei quer uma confiss\xE3o p\xFAblica. Onde ela acontece define o resto: um tribunal, ou o ch\xE3o da sua pra\xE7a."
      ], [
        c(
          "Tribunal. Oficial, lento, com a corte presente.",
          "A confiss\xE3o ecoa no sal\xE3o. Quem est\xE1 na corte ouve o nome \u2014 e pensa duas vezes antes de falar com voc\xEA.",
          { npc: [{ id: "arras", deltas: { fear: 6 } }], effects: { power: 2, influence: 3 }, score: 26, end: "mission" }
        ),
        c(
          "Na pra\xE7a. O povo v\xEA o collectar cair de joelhos.",
          "A pra\xE7a explode em gritos. Voc\xEA \xE9 o homem que derrubou o collectar \u2014 e a coroa n\xE3o gosta de hist\xF3rias de pra\xE7a.",
          {
            npc: [{ id: "arras", deltas: { fear: 12 } }],
            effects: { reputation: 4, power: -1 },
            flags: ["povo_vs_coroa"],
            score: 22,
            end: "mission"
          }
        ),
        c(
          "Nem confiss\xE3o nem pra\xE7a: eu mesmo conto ao rei o que sei, e Arras desaparece vivo.",
          "Voc\xEA resolve tudo sem tribunal. Arras some com a fam\xEDlia. O rei recebe sua vers\xE3o \u2014 e um desaparecimento conveniente.",
          {
            npc: [{ id: "arras", deltas: { trust: 6, loyalty: 8 } }],
            effects: { influence: 3, power: 2 },
            flags: ["arras_desapareceu"],
            score: 24,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 35, effects: { power: 2 } }
  },
  {
    id: 16,
    lawTitle: L(16).title,
    lawText: L(16).insight,
    title: "O Tempo Fora",
    areaId: "mercado",
    giverNpc: "pardal",
    brief: "Pardal implora que voc\xEA fique. Mas quem fica tem pre\xE7o \u2014 e um rei n\xE3o se esquece de quem n\xE3o apareceu.",
    steps: [
      { kind: "dialogue", node: "a" },
      { kind: "visit", areaId: "taverna", hint: "Afaste-se do mercado. N\xE3o diga a ningu\xE9m onde vai." },
      { kind: "talk", npc: "pardal", areaId: "mercado", hint: "Volte ao mercado e converse com Pardal." },
      { kind: "dialogue", node: "b" }
    ],
    nodes: {
      a: n("a", "pardal", [
        "Voc\xEA est\xE1 subindo r\xE1pido demais, e eu gosto de gente que sobe. Mas h\xE1 um problema: voc\xEA aparece em todo lugar.",
        "Um rei que tem dezoito conselhos para assistir n\xE3o se lembra de quem esteve sentado na cadeira ao lado."
      ], [
        c(
          "Desapare\xE7o por um tempo. Sem aviso, sem explica\xE7\xE3o.",
          'Pardal te olha com um brilho envolto. "Suma. E quando voltar, n\xE3o pe\xE7a desculpa por ter sumido: pe\xE7a desculpa por ter voltado."',
          { npc: [{ id: "pardal", deltas: { respect: 7 } }], flags: ["ausencia"], score: 16, next: "b" }
        ),
        c(
          "Fico. Quem some \xE9 fraco; quero estar vis\xEDvel.",
          'Pardal balan\xE7a a cabe\xE7a. "Vis\xEDvel \xE9 bom. Mas o olho que te v\xEA tamb\xE9m te usa."',
          { npc: [{ id: "pardal", deltas: { trust: 3 } }], effects: { influence: 1 }, score: 10, next: "b" }
        ),
        c(
          "Sumo, mas deixo um rumor de que estou doente.",
          'Pardiv franze a testa. "Doente e presente \xE9 o pior dos dois. Me parece que voc\xEA sabe mais do que finge."',
          { npc: [{ id: "pardal", deltas: { respect: 5 } }], effects: { intelligence: 2 }, score: 14, next: "b" }
        )
      ]),
      b: n("b", "pardal", [
        "Voc\xEA voltou. Repare: eu n\xE3o perguntar nada. Tr\xEAsnobles me perguntaram onde voc\xEA estava, e eu disse: 'n\xE3o sei de nada'.",
        "Agora eles est\xE3o perguntando de novo. Mas agora perguntam de voc\xEA para mim. Isso \xE9 respeito novo."
      ], [
        c(
          "N\xE3o devolvo a pergunta. Deixo a falta de resposta trabalhar.",
          'Pardal sorri. "A aus\xEAncia pesa mais do que a presen\xE7a. Voc\xEA est\xE1 aprendendo o of\xEDcio."',
          {
            npc: [{ id: "pardal", deltas: { trust: 5, respect: 5 } }],
            effects: { influence: 3, power: 1 },
            score: 26,
            end: "mission"
          }
        ),
        c(
          "Conto tudo: onde estive e com quem.",
          'Pardal suspira. "Tudo? Always. A pr\xF3xima vez, voc\xEA chega com hist\xF3ria feita. N\xE3o com relat\xF3rio."',
          { npc: [{ id: "pardal", deltas: { respect: -4 } }], effects: { reputation: 1 }, score: 12, end: "mission" }
        ),
        c(
          "Pergunto quem perguntou de voc\xEA. E guardo a resposta.",
          'Pardal te olha com respeito novo. "Sim. Isso \xE9 poder: n\xE3o a resposta, o fato de que voc\xEA a tem."',
          {
            npc: [{ id: "pardal", deltas: { respect: 8, fear: 3 } }],
            effects: { intelligence: 2, power: 2 },
            flags: ["lista_de_quem_perguntou"],
            score: 22,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 40, effects: { influence: 3 } }
  }
];

// src/game/data/missionsB.ts
var L2 = (id) => LAWS[id - 1];
var MISSIONS_B = [
  {
    id: 17,
    lawTitle: L2(17).title,
    lawText: L2(17).insight,
    title: "O Nome que Ningu\xE9m Sabe Dizer",
    areaId: "castelo",
    giverNpc: "condestavel",
    brief: "O Condest\xE1vel Martim tem um problema: quem n\xE3o consegue prever voc\xEA n\xE3o consegue planejar contra voc\xEA. Ele paga por imprevisibilidade.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "condestavel", [
        "Um homem previs\xEDvel \xE9 um homem dobrado. Perdi uma batalha porque sabia que o general viria pelo flanco esquerdo.",
        "Preciso de algu\xE9m no castelo que eu n\xE3o consiga adivinhar. E que n\xE3o me venda por uma moeda."
      ], [
        c(
          "Digo exatamente o que farei, para que ele confie em mim.",
          "Martim te encara. \u201CVoc\xEA acabou de se tornar previs\xEDvel. Mas, pelo menos, \xE9 \xFAtil assim.\u201D",
          {
            npc: [{ id: "condestavel", deltas: { respect: -3, trust: 2 } }],
            effects: { reputation: 1 },
            score: 8,
            next: "b"
          }
        ),
        c(
          "Sorrio e digo: n\xE3o sei. E voc\xEA tamb\xE9m n\xE3o.",
          "Martim ri pela primeira vez. \u201CIsso \xE9 a primeira resposta honesta que recebo neste castelo em um ano.\u201D",
          {
            npc: [{ id: "condestavel", deltas: { respect: 8, fear: 3 } }],
            effects: { intelligence: 2 },
            flags: ["imprevisivel"],
            score: 16,
            next: "b"
          }
        ),
        c(
          "Pergunto quanto ele paga antes de responder qualquer coisa.",
          "Martim estende a m\xE3o. \u201CDuzentos de ouro e um lugar na corte. Ainda est\xE1 na hora de decidir.\u201D",
          { npc: [{ id: "condestavel", deltas: { respect: 4 } }], effects: { wealth: 200 }, score: 12, next: "b" }
        )
      ]),
      b: n("b", "condestavel", [
        "Vou lhe testar: tr\xEAs homens v\xE3o perguntar o que eu quero que o rei acredite sobre os bandidos do norte. Diga uma coisa que eu n\xE3o diria."
      ], [
        c(
          "Digo que o rei j\xE1 mandou buscar os bandidos e que ningu\xE9m vai falar disso.",
          "Martim assente devagar. \u201CO rumor que nega um rumor. Quem nega, mente. \xC9 a minha t\xE1tica. Excelente.\u201D",
          {
            npc: [{ id: "condestavel", deltas: { respect: 6, loyalty: 4 } }],
            effects: { influence: 3, power: 1 },
            flags: ["rumor_duplo"],
            score: 26,
            end: "mission"
          }
        ),
        c(
          "Digo que o rei est\xE1 velho demais para governar a fronteira.",
          "Martim fica branco. \u201CIsso \xE9 verdade, e verdade dita no castelo custa caro. Mas o rei precisa ouvir de algu\xE9m.\u201D",
          {
            npc: [{ id: "condestavel", deltas: { respect: 4, fear: 2 } }],
            effects: { power: 2, reputation: -2 },
            flags: ["revelou_a_idade_do_rei"],
            score: 18,
            end: "mission"
          }
        ),
        c(
          "Digo que os bandidos s\xE3o um pretexto e que o inimigo est\xE1 dentro da corte.",
          "Martim te olha como quem pesa uma espada. \u201CQuem me contou isso n\xE3o importa. Importa que eu acredito.\u201D",
          {
            npc: [{ id: "condestavel", deltas: { respect: 9, fear: 6, loyalty: 5 } }],
            effects: { power: 3, intelligence: 2 },
            flags: ["semeou_o_medo"],
            score: 24,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 45, effects: { power: 2, influence: 1 } },
    unlockAreas: ["trono"]
  },
  {
    id: 18,
    lawTitle: L2(18).title,
    lawText: L2(18).insight,
    title: "A Torre dos Fundos",
    areaId: "trono",
    giverNpc: "rei",
    brief: "O Rei lhe oferece uma torre no castelo, s\xF3 sua, com guardas suas. O presente \xE9 generoso demais.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "rei", [
        "Voc\xEA tem bom olho para as coisas. Eu lhe dou a Torre dos Fundos: suas salas, suas guardas, suas portas.",
        "Ningu\xE9m mexe com voc\xEA ali. \xC9 o que um rei oferece a quem deseja proteger."
      ], [
        c(
          "Aceito. Onde ningu\xE9m me alcan\xE7a, eu trabalho melhor.",
          "O Rei assente satisfeito. \u201CSabia. E quem trabalha sem perturba\xE7\xE3o rende mais.\u201D",
          {
            npc: [{ id: "rei", deltas: { trust: 6, respect: 3 } }],
            effects: { influence: 2, wealth: 100 },
            flags: ["torre_propria"],
            score: 14,
            next: "b"
          }
        ),
        c(
          "Recuso. Prefiro ficar no meio das pessoas que precisam de mim.",
          "O Rei franze a testa. \u201CVoc\xEA recusa um presente meu? Isso \xE9 raro. E cada recusa ensina o outro a pensar duas vezes.\u201D",
          {
            npc: [{ id: "rei", deltas: { respect: 9, trust: -2 } }],
            effects: { reputation: 3, influence: 1 },
            flags: ["recusou_a_torre"],
            score: 18,
            next: "b"
          }
        ),
        c(
          "Aceito, mas digo: guardas minhas, portas do rei.",
          "O Rei sorri de lado. \u201CAh. Voc\xEA aceita e corrige as condi\xE7\xF5es. Vejo que voc\xEA sabe o pre\xE7o das coisas.\u201D",
          {
            npc: [{ id: "rei", deltas: { respect: 7, trust: 4 } }],
            effects: { power: 2, intelligence: 1 },
            flags: ["torre_negociada"],
            score: 20,
            next: "b"
          }
        )
      ]),
      b: n("b", "rei", [
        "Antes de qualquer coisa: o que o povo diz de mim quando n\xE3o estou? N\xE3o minta. Ningu\xE9m mente para o rei; mente para quem est\xE1 perto do rei."
      ], [
        c(
          "Digo que dizem que ele \xE9 justo, e que essa \xE9 a melhor arma de um rei.",
          "O Rei se endireita. \u201CJusti\xE7a \xE9 a imagem que nenhum inimigo consegue borrar. Continue.\u201D",
          {
            npc: [{ id: "rei", deltas: { trust: 6, respect: 4 } }],
            effects: { reputation: 3, influence: 1 },
            score: 22,
            end: "mission"
          }
        ),
        c(
          "Digo que dizem que ele hesita, e que hesita\xE7\xE3o \xE9 um convite.",
          "O Rei fica em sil\xEAncio. Depois: \u201CQuem te disse isso? N\xE3o importa. Eu sei que \xE9 verdade.\u201D",
          {
            npc: [{ id: "rei", deltas: { respect: 8, trust: 3, fear: 3 } }],
            effects: { power: 2, intelligence: 2 },
            flags: ["disse_a_verdade_ao_rei"],
            score: 24,
            end: "mission"
          }
        ),
        c(
          "Digo que dizem que o rei \xE9 forte, e omito o resto.",
          "O Rei estuda seu rosto. \u201CMeia verdade. Voc\xEA protegeu a mim e a voc\xEA mesmo. Vale mais que a verdade inteira.\u201D",
          {
            npc: [{ id: "rei", deltas: { trust: 8, loyalty: 4 } }],
            effects: { influence: 3, reputation: 2 },
            flags: ["meia_verdade_ao_rei"],
            score: 26,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 45, effects: { influence: 2 } },
    unlockAreas: ["conselho"]
  },
  {
    id: 19,
    lawTitle: L2(19).title,
    lawText: L2(19).insight,
    title: "A Gra\xE7a da Rainha",
    areaId: "trono",
    giverNpc: "rainha",
    brief: "A Rainha Clem\xEAncia quer presents algu\xE9m da corte e quer saber se voc\xEA sabe quem \xE9 perigoso.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "rainha", [
        "H\xE1 um homem nesta corte que fala pouco e sorri pouco. Vou observ\xE1-lo para voc\xEA, se voc\xEA me mostrar que sabe quem \xE9.",
        "Tr\xEAs nomes: o Escrib\xE3o Aur\xE9lio, o Duque Oldric e o Prior Sisenando. Qual deles n\xE3o se pode ofender?"
      ], [
        c(
          "O Escrib\xE3o. Ele anota tudo, e o rei l\xEA o que ele escreve.",
          "Clem\xEAncia assente. \u201CCorreto. Um homem que escreve \xE9 mais perigoso que um homem que grita.\u201D",
          { npc: [{ id: "rainha", deltas: { respect: 7, trust: 4 } }], effects: { intelligence: 2 }, score: 16, next: "b" }
        ),
        c(
          "O Duque. Ele tem gente armada e dinheiro para comprar a coroa.",
          "Clem\xEAncia sorri. \u201CErrado. Oldric \xE9 perigoso, sim, mas \xE9 vis\xEDvel. O perigoso \xE9 o que escreve.\u201D",
          { npc: [{ id: "rainha", deltas: { respect: 2 } }], effects: { intelligence: -1 }, score: 10, next: "b" }
        ),
        c(
          "O Prior. A Igreja perdoa, mas tamb\xE9m condena, e o rei ouve a Igreja.",
          "Clem\xEAncia hesita. \u201CBoa resposta. O Prior \xE9 o homem que n\xE3o se pode atacar. Mas n\xE3o \xE9 o que n\xE3o se pode ofender.\u201D",
          { npc: [{ id: "rainha", deltas: { respect: 5 } }], effects: { intelligence: 1 }, score: 12, next: "b" }
        )
      ]),
      b: n("b", "rainha", [
        "Agora o segundo teste. Um cortes\xE3o insultou meu vestido. Quero a sua resposta, a que voc\xEA daria, n\xE3o a que eu daria."
      ], [
        c(
          "Senhora, o vestido ofendeu a vista de quem n\xE3o entende de moda.",
          "Clem\xEAncia gargalha. \u201CPerfeito! Vamos devolver o insulto com juros.\u201D",
          {
            npc: [{ id: "rainha", deltas: { trust: 7, respect: 5 } }],
            effects: { reputation: 2, influence: 2 },
            score: 24,
            end: "mission"
          }
        ),
        c(
          "N\xE3o devolva nada. Deixe-o pensar que a rainha n\xE3o o notou.",
          "Clem\xEAncia inclina a cabe\xE7a. \u201CA maior humilha\xE7\xE3o \xE9 n\xE3o ser notado. Use isso.\u201D",
          {
            npc: [{ id: "rainha", deltas: { trust: 8, loyalty: 5 } }],
            effects: { intelligence: 3, power: 1 },
            flags: ["conselho_da_rainha"],
            score: 26,
            end: "mission"
          }
        ),
        c(
          "Senhora, resolvo isso amanh\xE3 e o cortes\xE3o nem vai saber que aconteceu.",
          "Clem\xEAncia sorri de lado. \u201CVoc\xEA quer que eu pare\xE7a fraca? N\xE3o. Mas quero que ele pare\xE7a fraco. Fa\xE7a.\u201D",
          {
            npc: [{ id: "rainha", deltas: { trust: 6, respect: 4 } }],
            effects: { power: 2, reputation: 1 },
            flags: ["trabalho_sujo_regina"],
            score: 22,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 45, effects: { influence: 2 } },
    unlockAreas: ["capela"]
  },
  {
    id: 20,
    lawTitle: L2(20).title,
    lawText: L2(20).insight,
    title: "Juramentos e Alian\xE7as",
    areaId: "capela",
    giverNpc: "prior",
    brief: "O Prior Sisenando pede que voc\xEA seja padrinho do filho dele: um juramento que o prenderia para sempre.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "prior", [
        "Tenho um pedido, e pe\xE7o antes de prometer: seja padrinho do meu filho. A Igreja proteger\xE1 sua casa, e sua casa me proteger\xE1 dos meus inimigos.",
        "\xC9 uma alian\xE7a antiga. Talvez antiga demais para o seu momento."
      ], [
        c(
          "Aceito. Uma alian\xE7a da Igreja vale mais que ouro.",
          "Sisenando segura suas m\xE3os. \u201CEnt\xE3o a Igreja \xE9 a sua espada. Use com cuidado.\u201D",
          {
            npc: [{ id: "prior", deltas: { trust: 8, loyalty: 6 } }],
            effects: { influence: 2, reputation: 2 },
            flags: ["padrinho_da_igreja"],
            score: 16,
            next: "b"
          }
        ),
        c(
          "Aceito hoje, sem prometer amanh\xE3. Prud\xEAncia n\xE3o \xE9 covardia.",
          "Sisenando sorri. \u201CS\xE1bio. A Igreja aceita o que hoje se oferece.\u201D",
          { npc: [{ id: "prior", deltas: { trust: 4, respect: 5 } }], effects: { intelligence: 2 }, score: 18, next: "b" }
        ),
        c(
          "Recuso. N\xE3o prometo a quem n\xE3o posso abandonar.",
          "Sisenando n\xE3o se ofende. \u201CS\xE1bio. O primeiro que quebra um juramento \xE9 o que mais lembra dele.\u201D",
          {
            npc: [{ id: "prior", deltas: { respect: 8, trust: -2 } }],
            effects: { power: 1, reputation: 1 },
            flags: ["sem_juramento"],
            score: 16,
            next: "b"
          }
        )
      ]),
      b: n("b", "prior", [
        "Diga-me, ent\xE3o, a quem voc\xEA se compromete hoje. N\xE3o para que eu conte a algu\xE9m, apenas para eu saber de quantas pessoas voc\xEA n\xE3o pode depender."
      ], [
        c(
          "Ao rei. Sem condi\xE7\xE3o, sem alternativa.",
          "Sisenando baixa a voz. \u201CVoc\xEA \xE9 do rei. Isso \xE9 bonito e fr\xE1gil. O rei tamb\xE9m muda um dia.\u201D",
          {
            npc: [{ id: "prior", deltas: { trust: 2 } }],
            effects: { power: 2, intelligence: 1 },
            flags: ["homem_do_rei"],
            score: 20,
            end: "mission"
          }
        ),
        c(
          "A ningu\xE9m. Estou no mercado, n\xE3o num trono.",
          "Sisenando parece satisfeito. \u201CPerfeito. Quem n\xE3o pertence a ningu\xE9m pertence a todo mundo.\u201D",
          {
            npc: [{ id: "prior", deltas: { respect: 7 } }],
            effects: { intelligence: 2, influence: 1 },
            flags: ["sem_compromisso"],
            score: 24,
            end: "mission"
          }
        ),
        c(
          "A Deus. E por Deus, a quem estiver ao meu lado quando eu precisar.",
          "Sisenando fecha os olhos. \u201CDeus \xE9 o \xFAnico aliado que n\xE3o pede contas. Mas tamb\xE9m n\xE3o socorre.\u201D",
          {
            npc: [{ id: "prior", deltas: { trust: 6 } }],
            effects: { reputation: 3, wealth: -80 },
            flags: ["juramento_divino"],
            score: 22,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 45, effects: { influence: 1 } },
    unlockAreas: ["cripta"]
  },
  {
    id: 21,
    lawTitle: L2(21).title,
    lawText: L2(21).insight,
    title: "O Escrib\xE3o e o Livro de Contas",
    areaId: "conselho",
    giverNpc: "chanceler",
    brief: "O Chanceler Hon\xF3rio quer que voc\xEA descubra um vazamento nos livros do tesouro, e quer saber se voc\xEA \xE9 burro ou perigoso.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }, { kind: "dialogue", node: "c" }],
    nodes: {
      a: n("a", "chanceler", [
        "Os livros do tesouro n\xE3o fecham. Algu\xE9m tira ouro por dentro. Preciso de olhos novos, e de algu\xE9m que n\xE3o saiba o que est\xE1 procurando.",
        "Voc\xEA parece curioso. N\xE3o se ofenda: curiosidade \xE9 uma forma de intelig\xEAncia."
      ], [
        c(
          "Pergunto: quanto o rei paga por esta investiga\xE7\xE3o?",
          "Hon\xF3rio sorri. \u201CDireto. Gosto disso. O rei paga o dobro por resultados e corta a cabe\xE7a por fracassos.\u201D",
          { npc: [{ id: "chanceler", deltas: { respect: 6 } }], effects: { wealth: 100 }, score: 14, next: "b" }
        ),
        c(
          "Finjo n\xE3o entender nada de livros e pe\xE7o para carregar caixas.",
          "Hon\xF3rio te examina. \u201CMuito bem. O tolo que carrega caixa ouve tudo e n\xE3o avisa.\u201D",
          {
            npc: [{ id: "chanceler", deltas: { respect: 5, fear: 2 } }],
            effects: { intelligence: 2 },
            flags: ["fingiu_ignorancia"],
            score: 18,
            next: "b"
          }
        ),
        c(
          "Digo que n\xE3o quero o ouro: quero saber quem rouba, antes de qualquer coisa.",
          "Hon\xF3rio estreita os olhos. \u201CPerigoso. Mas o tipo perigoso que eu quero.\u201D",
          {
            npc: [{ id: "chanceler", deltas: { respect: 8, trust: 4 } }],
            effects: { power: 1, intelligence: 2 },
            score: 16,
            next: "b"
          }
        )
      ]),
      b: n("b", "chanceler", [
        "Tr\xEAs suspeitos: o Tesoureiro Gaspar, o Escrib\xE3o Aur\xE9lio e o Mercador Pardal. Um deles rouba. Qual voc\xEA acusaria primeiro?"
      ], [
        c(
          "Pardal. Quem lucra mais com um tesouro fraco \xE9 quem deixa o tesouro fraco.",
          "Hon\xF3rio assente. \u201CGosto. Voc\xEA pensa em mecanismo. Mas cuidado: acusar o errado custa caro.\u201D",
          { npc: [{ id: "chanceler", deltas: { respect: 4 } }], flags: ["acusou_pardal"], score: 18, next: "c" }
        ),
        c(
          "Nenhum. Pe\xE7o a lista completa de pagamentos e comparo sozinho.",
          "Hon\xF3rio empurra o livro para voc\xEA. \u201C\xC9 assim que se desmonta uma rede. V\xE1, e n\xE3o conte a ningu\xE9m.\u201D",
          {
            npc: [{ id: "chanceler", deltas: { trust: 6 } }],
            effects: { intelligence: 3 },
            flags: ["investiga_somente"],
            score: 22,
            next: "c"
          }
        ),
        c(
          "Gaspar. Quem cuida do cofre nunca se afasta dele, e sempre pode jurar que n\xE3o viu.",
          "Hon\xF3rio sorri de lado. \u201CSuspeitoso. Mas Gaspar \xE9 homem do rei. Acus\xE1-lo \xE9 um movimento, n\xE3o uma dedu\xE7\xE3o.\u201D",
          { npc: [{ id: "chanceler", deltas: { respect: 5 } }], flags: ["acusou_gaspar"], score: 20, next: "c" }
        )
      ]),
      c: n("c", "chanceler", [
        "Um \xFAltimo ponto. Se o ladr\xE3o for algu\xE9m que voc\xEA n\xE3o pode derrubar, o que se faz?"
      ], [
        c(
          "Guarda-se a verdade. Ela vira arma de reserva.",
          "Hon\xF3rio bate na mesa. \u201CIsso! Conhecimento guardado \xE9 poder guardado.\u201D",
          {
            npc: [{ id: "chanceler", deltas: { trust: 7, respect: 5 } }],
            effects: { intelligence: 2, power: 1 },
            flags: ["arma_de_reserva"],
            score: 26,
            end: "mission"
          }
        ),
        c(
          "Entrega-se tudo ao rei, porque quem guarda segredo um dia o perde.",
          "Hon\xF3rio suspira. \u201CHonesto. E \xFAtil, \xE0s vezes. Mas quem entrega informa\xE7\xE3o tamb\xE9m entrega poder.\u201D",
          {
            npc: [{ id: "chanceler", deltas: { respect: 3 } }],
            effects: { reputation: 2, power: -1 },
            score: 14,
            end: "mission"
          }
        ),
        c(
          "Usa-se a verdade para construir minha posi\xE7\xE3o antes de denunciar.",
          "Hon\xF3rio fica muito quieto. \u201CVoc\xEA n\xE3o \xE9 honesto. Voc\xEA \xE9 esperto. Eu prefiro esperto.\u201D",
          {
            npc: [{ id: "chanceler", deltas: { respect: 9, trust: 3, fear: 3 } }],
            effects: { power: 3, influence: 2 },
            flags: ["sua_posicao"],
            score: 28,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 50, effects: { intelligence: 2 } },
    unlockAreas: ["solar"]
  },
  {
    id: 22,
    lawTitle: L2(22).title,
    lawText: L2(22).insight,
    title: "A Queda do Norte",
    areaId: "conselho",
    giverNpc: "aurelio",
    brief: "Aurelio, o Escrib\xE3o, tem uma not\xEDcia terr\xEDvel: o norte foi perdido. A quest\xE3o \xE9 como entreg\xE1-la.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }, { kind: "dialogue", node: "c" }],
    nodes: {
      a: n("a", "aurelio", [
        "A guarni\xE7\xE3o do norte recuou. Perdemos tr\xEAs vilas e a ponte de ferro. O rei ainda n\xE3o sabe.",
        "Quem leva esta not\xEDcia escolhe o que vem depois dela. \xC9 uma posi\xE7\xE3o, n\xE3o uma tarefa."
      ], [
        c(
          "Levo a not\xEDcia eu mesmo, ao rei, em privado.",
          "Aurelio fecha o livro. \u201CPrivado. Ent\xE3o voc\xEA controla a rea\xE7\xE3o dele. Cuidado com o que deixa de fora.\u201D",
          { npc: [{ id: "aurelio", deltas: { trust: 6, respect: 4 } }], effects: { power: 1 }, score: 14, next: "b" }
        ),
        c(
          "Escrevo tudo com cuidado e entrego ao Chanceler, que sabe falar com o rei.",
          "Aurelio sorri. \u201CCerto. O chanceler sabe a linguagem. Mas a gl\xF3ria ser\xE1 dele.\u201D",
          { npc: [{ id: "aurelio", deltas: { trust: 3 } }], effects: { intelligence: 2 }, score: 12, next: "b" }
        ),
        c(
          "Pergunto se a not\xEDcia \xE9 toda verdade: \xE0s vezes se perde uma vila e se ganha um aliado.",
          "Aurelio ergue os olhos do livro. \u201CPerdeu-se uma vila. Mas o Norte tem um senhor insatisfeito, e isso n\xE3o est\xE1 no relat\xF3rio.\u201D",
          {
            npc: [{ id: "aurelio", deltas: { respect: 7, trust: 4 } }],
            effects: { intelligence: 3 },
            flags: ["sabe_do_norte"],
            score: 18,
            next: "b"
          }
        )
      ]),
      b: n("b", "aurelio", [
        "O rei vai perguntar: quem abandonou o norte? Ter\xE1 de haver um nome. Posso oferecer Arras, que est\xE1 morto e seguro, Aldric, que est\xE1 vivo e \xE9 \xFAtil, ou ningu\xE9m, que \xE9 fraco."
      ], [
        c(
          "Ningu\xE9m. Digo que a guarni\xE7\xE3o recuou por ordem do Condest\xE1vel.",
          "Aurelio assente devagar. \u201CO Condest\xE1vel cair\xE1. Mas cair\xE1 tarde, e voc\xEA ficar\xE1 fora da mira.\u201D",
          {
            npc: [{ id: "aurelio", deltas: { respect: 8, fear: 3 } }],
            effects: { power: 3, reputation: -1 },
            flags: ["culpa_no_condestavel"],
            score: 24,
            next: "c"
          }
        ),
        c(
          "Arras. Est\xE1 morto, tem culpa e n\xE3o se defende.",
          "Aurelio sorri de lado. \u201CMortos s\xE3o os melhores culpados. Ningu\xE9m pergunta nada a um cad\xE1ver.\u201D",
          {
            npc: [{ id: "aurelio", deltas: { respect: 5 } }],
            effects: { power: 2, reputation: -1 },
            flags: ["culpou_arras"],
            score: 20,
            next: "c"
          }
        ),
        c(
          "Aldric. Est\xE1 vivo, sem bandeira, e odeia este governo.",
          "Aurelio para de escrever. \u201CVoc\xEA quer que o rei persiga um desertor, ou que um desertor persiga um rei?\u201D",
          {
            npc: [{ id: "aurelio", deltas: { respect: 9, trust: 3 } }],
            effects: { power: 2, influence: 2 },
            flags: ["alvo_aldric"],
            score: 26,
            next: "c"
          }
        )
      ]),
      c: n("c", "aurelio", [
        "Por \xFAltimo: como voc\xEA leva a not\xEDcia at\xE9 o rei? Sem ela, ela n\xE3o existe."
      ], [
        c(
          "A p\xE9, pelo castelo, \xE0 vista de todos. Que se veja quem traz a not\xEDcia.",
          "Aurelio fecha o livro devagar. \u201CVis\xEDvel. Corajoso. E perigoso: quem traz not\xEDcia boa fica \xFAtil demais.\u201D",
          {
            npc: [{ id: "aurelio", deltas: { respect: 5 } }],
            effects: { reputation: 3, influence: 2 },
            flags: ["noticia_publica"],
            score: 22,
            end: "mission"
          }
        ),
        c(
          "Pela Capela, durante a ora\xE7\xE3o. Ningu\xE9m ouve o que se diz ao lado do altar.",
          "Aurelio sorri. \u201CEloquente. O rei ouve melhor em ora\xE7\xE3o do que em conselho.\u201D",
          {
            npc: [{ id: "aurelio", deltas: { trust: 5 } }],
            effects: { intelligence: 2, power: 1 },
            flags: ["noticia_na_capela"],
            score: 24,
            end: "mission"
          }
        ),
        c(
          "N\xE3o levo. Voc\xEA leva. Eu fico com o documento, e o documento fala quando eu quiser.",
          "Aurelio te olha com admira\xE7\xE3o fria. \u201CIsso \xE9 covardia, ou estrat\xE9gia. O tempo dir\xE1.\u201D",
          {
            npc: [{ id: "aurelio", deltas: { respect: 9, fear: 4, trust: -2 } }],
            effects: { power: 3 },
            flags: ["aurelio_te_espiou"],
            score: 24,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 50, effects: { power: 2 } },
    unlockAreas: ["muralha"]
  },
  {
    id: 23,
    lawTitle: L2(23).title,
    lawText: L2(23).insight,
    title: "Um Posto, Uma Guerra",
    areaId: "muralha",
    giverNpc: "capitao",
    brief: "O Capit\xE3o Dami\xE3o tem um posto na muralha norte e duas frentes de guerra disputam voc\xEA.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "capitao", [
        "Dois problemas: os bandidos que atacam as carro\xE7as de.year e o Lorde do Norte que fecha a fronteira.",
        "Tenho um posto. Um. E voc\xEA n\xE3o pode estar nos dois lugares."
      ], [
        c(
          "Vou para a fronteira. O Lorde do Norte \xE9 a amea\xE7a de verdade.",
          "Dami\xE3o assente. \u201CCorreto. Bandidos se resolvem com espadas; lords se resolvem com outra coisa.\u201D",
          { npc: [{ id: "capitao", deltas: { respect: 6 } }], effects: { power: 2 }, score: 14, next: "b" }
        ),
        c(
          "Vou para as carro\xE7as. Quem corta o p\xE3o da cidade derruba o rei mais r\xE1pido que um ex\xE9rcito.",
          "Dami\xE3o franze a testa, mas concorda. \u201CPragm\xE1tico. \xC0s vezes \xE9 o \xFAnico caminho.\u201D",
          { npc: [{ id: "capitao", deltas: { respect: 3 } }], effects: { reputation: 2 }, score: 12, next: "b" }
        ),
        c(
          "Pergunto: se eu n\xE3o aceitar, quem fica com o posto?",
          "Dami\xE3o sorri de lado. \u201CUm homem chamado Sargento Vargo, que o Chanceler j\xE1 visitou. Mas Vargo n\xE3o perguntaria.\u201D",
          { npc: [{ id: "capitao", deltas: { respect: 5 } }], effects: { intelligence: 2 }, score: 14, next: "b" }
        )
      ]),
      b: n("b", "capitao", [
        "Posso designar voc\xEA ao posto e dar a guarda a quem eu quiser. Escolha o segundo: um homem leal a mim, ou um homem que o rei manda."
      ], [
        c(
          "Um homem do rei. Assim, se o posto virar problema, o problema \xE9 dele.",
          "Dami\xE3o assente. \u201CCerto. Eu te dou o posto e o pr\xF3ximo problema.\u201D",
          {
            npc: [{ id: "capitao", deltas: { trust: 4 } }],
            effects: { power: 2, reputation: 1 },
            flags: ["guarda_do_rei"],
            score: 22,
            end: "mission"
          }
        ),
        c(
          "Um homem seu. Concentra\xE7\xE3o: quem tem o posto tem a guarda e a lealdade.",
          "Dami\xE3o sorri. \u201CAgora sim. Uma pe\xE7a, um dono, uma ordem.\u201D",
          {
            npc: [{ id: "capitao", deltas: { trust: 7, loyalty: 5 } }],
            effects: { power: 3, influence: 1 },
            flags: ["guarda_fiel"],
            score: 26,
            end: "mission"
          }
        ),
        c(
          "Nenhum dos dois: dou a guarda a um homem que s\xF3 responde a mim.",
          "Dami\xE3o fica im\xF3vel. \u201CVoc\xEA quer o posto e quer que eu n\xE3o mande em voc\xEA. Isso \xE9 um golpe, e eu aceito.\u201D",
          {
            npc: [{ id: "capitao", deltas: { respect: 8, fear: 4 } }],
            effects: { power: 3, influence: 2 },
            flags: ["guarda_pessoal"],
            score: 28,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 50, effects: { power: 2 } },
    unlockAreas: ["corvo"]
  },
  {
    id: 24,
    lawTitle: L2(24).title,
    lawText: L2(24).insight,
    title: "O Cort\xEAs\xE3o Perfeito",
    areaId: "trono",
    giverNpc: "sereno",
    brief: "O Bobo Sereno foi criado na corte. Ele lhe ensina a \xFAnica arte que importa: como ser visto sem ser usado.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "sereno", [
        "Voc\xEA sobe r\xE1pido. Eu j\xE1 vi isso antes: sobe r\xE1pido, cai com barulho. Eu ca\xED com o som de uma risada e ainda estou aqui.",
        "Vou te ensinar o jogo: nunca responda o que perguntam. Devolva perguntas."
      ], [
        c(
          "Fa\xE7o uma pergunta: o que o rei mais odeia ouvir?",
          "Sereno para de dan\xE7ar. \u201CBoa. A resposta \xE9: conselhos. O rei odeia ouvir o que ele j\xE1 sabe.\u201D",
          { npc: [{ id: "sereno", deltas: { respect: 7, trust: 5 } }], effects: { intelligence: 2 }, score: 14, next: "b" }
        ),
        c(
          "Pergunto como se sobrevive a uma corte.",
          "Sereno ri. \u201CCom o corpo torto e a voz mansa. Ningu\xE9m lan\xE7a uma flecha em quem parece inofensivo.\u201D",
          { npc: [{ id: "sereno", deltas: { trust: 6 } }], effects: { intelligence: 1, reputation: 1 }, score: 12, next: "b" }
        ),
        c(
          "Digo que tolo n\xE3o \xE9 o meu forte.",
          "Sereno inclina a cabe\xE7a. \u201CNem o meu. Eu n\xE3o sou tolo: sou o \xFAnico que pode dizer a verdade sem perder a cabe\xE7a.\u201D",
          { npc: [{ id: "sereno", deltas: { respect: 5 } }], effects: { power: 1 }, score: 12, next: "b" }
        )
      ]),
      b: n("b", "sereno", [
        "O rei vai perguntar amanh\xE3: em que voc\xEA pensa? Diga uma coisa que n\xE3o revele nada, mas fa\xE7a o rei se sentir lido."
      ], [
        c(
          "Penso no que o rei pensa. Para fazer o que o rei quer.",
          "Sereno bate palmas baixinho. \u201CPerfeito! O rei se sente lido e nada foi dito.\u201D",
          {
            npc: [{ id: "sereno", deltas: { respect: 8 } }],
            effects: { influence: 3, reputation: 2 },
            flags: ["elogio_mestre"],
            score: 26,
            end: "mission"
          }
        ),
        c(
          "Penso em como o reino sobrevive sem mim.",
          "Sereno balan\xE7a a cabe\xE7a. \u201CIsso \xE9 arrog\xE2ncia. E pior: se o rei te limpar, ningu\xE9m vai defender voc\xEA.\u201D",
          {
            npc: [{ id: "sereno", deltas: { respect: 2 } }],
            effects: { power: 1, reputation: -2 },
            flags: ["arrogante_corte"],
            score: 12,
            end: "mission"
          }
        ),
        c(
          "Penso no meu pai, que falhou. E no que eu vou fazer diferente.",
          "Sereno fica s\xE9rio. \u201CIsso \xE9 verdade, e \xE9 sentimental. Cuidado: o rei detesta ser lembrado do que ele mesmo esqueceu.\u201D",
          {
            npc: [{ id: "sereno", deltas: { respect: 4 } }],
            effects: { reputation: 2, intelligence: 1 },
            score: 18,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 50, effects: { influence: 2 } }
  },
  {
    id: 25,
    lawTitle: L2(25).title,
    lawText: L2(25).insight,
    title: "A Nova Persona",
    areaId: "solar",
    giverNpc: "valdessa",
    brief: "A Condessa Valdessa lhe oferece um t\xEDtulo novo: Portador do Rei. Um nome novo apaga um nome velho.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "valdessa", [
        "Voc\xEA \xE9 interessante demais para o nome que tem. Ningu\xE9m com o seu nome deveria ter a sua influ\xEAncia.",
        "Posso lhe dar um: Portador do Rei. Homens que entregam cartas e ordens. Ningu\xE9m pergunta o que h\xE1 dentro."
      ], [
        c(
          "Aceito o t\xEDtulo. E pe\xE7o a lista de quem o usou antes.",
          "Valdessa sorri. \u201CTr\xEAs homens usaram Portador do Rei. Dois est\xE3o mortos. O terceiro trabalha para mim.\u201D",
          {
            npc: [{ id: "valdessa", deltas: { trust: 6, respect: 4 } }],
            effects: { influence: 2, intelligence: 2 },
            flags: ["portador_do_rei"],
            score: 16,
            next: "b"
          }
        ),
        c(
          "Recuso. Prefiro um nome que ningu\xE9m pode me tirar.",
          "Valdessa assente com admira\xE7\xE3o. \u201CInteiro. O nome \xE9 a \xFAnica coisa que ningu\xE9m pode confiscar.\u201D",
          {
            npc: [{ id: "valdessa", deltas: { respect: 8, trust: -2 } }],
            effects: { power: 1, reputation: 2 },
            flags: ["nome_proprio"],
            score: 18,
            next: "b"
          }
        ),
        c(
          "Aceito, mas digo que o t\xEDtulo me serve menos que a d\xEDvida que cria com voc\xEA.",
          "Valdessa ergue uma sobrancelha. \u201CVoc\xEA entende as correntes. Isso me preocupa e me fascina.\u201D",
          {
            npc: [{ id: "valdessa", deltas: { respect: 9, fear: 3 } }],
            effects: { power: 2 },
            flags: ["devedor_da_condessa"],
            score: 20,
            next: "b"
          }
        )
      ]),
      b: n("b", "valdessa", [
        "A persona precisa de uma hist\xF3ria. Escolha a sua, e lembre-se: ela precisa justificar tudo o que voc\xEA fizer de hoje em diante."
      ], [
        c(
          "Sou um homem que serve o rei sem pedir nada. Um servidor puro.",
          "Valdessa assente. \u201CPureza convence at\xE9 os orgulhosos. E \xE9 a mentira mais \xFAtil que existe.\u201D",
          {
            npc: [{ id: "valdessa", deltas: { respect: 5 } }],
            effects: { influence: 3, reputation: 2 },
            flags: ["persona_servidor"],
            score: 26,
            end: "mission"
          }
        ),
        c(
          "Sou um homem que resolve o que ningu\xE9m resolve. Um fazendeiro de problemas.",
          "Valdessa sorri. \u201CIsso explica o dinheiro, o suor e o trabalho sujo. Excelente.\u201D",
          {
            npc: [{ id: "valdessa", deltas: { trust: 5 } }],
            effects: { power: 2, wealth: 150 },
            flags: ["persona_problema"],
            score: 24,
            end: "mission"
          }
        ),
        c(
          "Sou um homem que sabe quem mandou em cada coisa. Um informante.",
          "Valdessa fica muito quieta. \u201CPerigoso. Mas voc\xEA tem a marca de quem j\xE1 ouviu segredos demais.\u201D",
          {
            npc: [{ id: "valdessa", deltas: { respect: 7, fear: 5 } }],
            effects: { intelligence: 3, influence: 1 },
            flags: ["persona_informante"],
            score: 22,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 55, effects: { influence: 2 } }
  },
  {
    id: 26,
    lawTitle: L2(26).title,
    lawText: L2(26).insight,
    title: "A M\xE3o Suja",
    areaId: "porto",
    giverNpc: "nilo",
    brief: "Nilo precisa de algu\xE9m para retirar uma carga proibida da alf\xE2ndega. Ele n\xE3o pode ser visto; voc\xEA pode.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "nilo", [
        "Carga sem selo na alf\xE2ndega do rei. Se o inspetor me pega, perco o cais. Se te pega, voc\xEA perde a reputa\xE7\xE3o.",
        "Preciso de algu\xE9m que a alf\xE2ndega n\xE3o olhe duas vezes."
      ], [
        c(
          "Vou pessoalmente. E depois, ningu\xE9m soube.",
          "Nilo te entrega o mapa. \u201CBoa. E se te pegarem: voc\xEA nunca me viu.\u201D",
          {
            npc: [{ id: "nilo", deltas: { trust: 6, loyalty: 3 } }],
            effects: { power: 1, reputation: -1 },
            flags: ["maos_sujas_2"],
            score: 14,
            next: "b"
          }
        ),
        c(
          "Uso um intermedi\xE1rio: um mendigo, um guerreiro, algu\xE9m sem nome.",
          "Nilo sorri. \u201CA m\xE3o suja \xE9 sempre a de outro.\u201D",
          {
            npc: [{ id: "nilo", deltas: { respect: 6 } }],
            effects: { intelligence: 2, reputation: 1 },
            flags: ["intermediario"],
            score: 20,
            next: "b"
          }
        ),
        c(
          "Recuso. N\xE3o quero me meter com a alf\xE2ndega do rei.",
          "Nilo encolhe os ombros. \u201CLimpo. Exatamente por isso que voc\xEA vai longe.\u201D",
          {
            npc: [{ id: "nilo", deltas: { respect: 4 } }],
            effects: { reputation: 3, influence: 1 },
            flags: ["mao_limpa"],
            score: 18,
            next: "b"
          }
        )
      ]),
      b: n("b", "nilo", [
        "A carga vale mais que o barco. Se algo correr mal, \xE9 preciso um culpado. Voc\xEA conhece um culpado?"
      ], [
        c(
          "Conhe\xE7o. Aquele que rouba do tesouro: se ele for preso, ningu\xE9m pergunta do cais.",
          "Nilo assente. \u201CPerfeito. Inimigo \xFAtil tamb\xE9m \xE9 ferramenta.\u201D",
          {
            npc: [{ id: "nilo", deltas: { respect: 7 } }],
            effects: { power: 2, intelligence: 1 },
            flags: ["culpa_redirecionada"],
            score: 26,
            end: "mission"
          }
        ),
        c(
          "N\xE3o. Se o culpado souber que \xE9 culpado, amanh\xE3 eu sou o culpado.",
          "Nilo assente. \u201CPadr\xE3o. A culpa precisa ser de algu\xE9m que n\xE3o possa dizer que foi escolhido.\u201D",
          { npc: [{ id: "nilo", deltas: { trust: 4 } }], effects: { intelligence: 2 }, score: 20, end: "mission" }
        ),
        c(
          "Uso meu pr\xF3prio nome. Se cair, caio eu, e quem me liga ao rei me protege.",
          "Nilo te olha com admira\xE7\xE3o. \u201CAudacioso. Voc\xEA usa o poder como escudo.\u201D",
          {
            npc: [{ id: "nilo", deltas: { respect: 9, loyalty: 5 } }],
            effects: { power: 3, reputation: 2 },
            flags: ["usou_o_escudo_do_rei"],
            score: 24,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 50, effects: { power: 1 } }
  },
  {
    id: 27,
    lawTitle: L2(27).title,
    lawText: L2(27).insight,
    title: "A Promessa do Bosque",
    areaId: "bosque",
    giverNpc: "bruma",
    brief: "Bruma oferece a voc\xEA uma cren\xE7a, e gente que acredita nela. Cren\xE7a organizada \xE9 um ex\xE9rcito.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "bruma", [
        "No bosque h\xE1 gente que j\xE1 n\xE3o acredita em rei, nem em deus, nem em nada. Precisam de uma coisa em que acreditar.",
        "Eu posso dar a eles uma ideia. E voc\xEA pode dar \xE0 ideia um nome. Ou levar o nome e ficar com a ideia."
      ], [
        c(
          "Fico com a ideia. Voc\xEA fica com a cren\xE7a.",
          "Bruma assente. \u201CEnt\xE3o eles obedecem a voc\xEA, e a mim s\xF3 me devem respeito. Bom neg\xF3cio.\u201D",
          {
            npc: [{ id: "bruma", deltas: { trust: 5 } }],
            effects: { power: 2, influence: 2 },
            flags: ["guarda_da_crenca"],
            score: 16,
            next: "b"
          }
        ),
        c(
          "Fico com o nome e a predicade. Voc\xEA faz o trabalho sujo.",
          "Bruma franze a testa. \u201CA ideia sem nome morre em uma esta\xE7\xE3o. Mas voc\xEA tem raz\xE3o: quem nomeia, manda.\u201D",
          {
            npc: [{ id: "bruma", deltas: { respect: 6 } }],
            effects: { influence: 3, power: 1 },
            flags: ["nome_da_crenca"],
            score: 18,
            next: "b"
          }
        ),
        c(
          "Recuso. N\xE3o quero seitas; quero o trono.",
          "Bruma d\xE1 de ombros. \u201CO trono \xE9 o que voc\xEA diz que quer. Depois voc\xEA vai implorar por um povo.\u201D",
          {
            npc: [{ id: "bruma", deltas: { respect: 4 } }],
            effects: { power: 1, reputation: 1 },
            flags: ["sem_seita"],
            score: 12,
            next: "b"
          }
        )
      ]),
      b: n("b", "bruma", [
        "A cren\xE7a precisa de uma promessa clara e de um ritual. Escolha a promessa, porque o que prometer agora ter\xE1 de entregar."
      ], [
        c(
          "Nenhum mais ter\xE1 fome enquanto eu estiver de p\xE9.",
          "Bruma fecha os olhos. \u201CPromessa de p\xE3o. Concreta. O povo acredita em fome antes de acreditar em Deus.\u201D",
          {
            npc: [{ id: "bruma", deltas: { respect: 7 } }],
            effects: { reputation: 5, wealth: -150 },
            flags: ["promessa_de_pao"],
            score: 26,
            end: "mission"
          }
        ),
        c(
          "O rei \xE9 um homem. Morto, ser\xE1 um m\xE1rtir.",
          "Bruma sorri de canto. \u201CPerigoso e delicioso. Mas o rei vai ouvir isso, e o rei n\xE3o perdoa.\u201D",
          {
            npc: [{ id: "bruma", deltas: { respect: 6 } }],
            effects: { power: 3, reputation: -2 },
            flags: ["promessa_martir"],
            score: 24,
            end: "mission"
          }
        ),
        c(
          "O que se tem de melhor neste reino ser\xE1 para quem serve ao rei.",
          "Bruma franze a testa. \u201CEssa \xE9 a f\xE9 da corte, n\xE3o a sua. Mas \xE9 a f\xE9 que n\xE3o levanta ningu\xE9m do ch\xE3o.\u201D",
          {
            npc: [{ id: "bruma", deltas: { respect: 2 } }],
            effects: { reputation: 2, influence: 1 },
            flags: ["promessa_do_rei"],
            score: 16,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 55, effects: { influence: 2 } }
  },
  {
    id: 28,
    lawTitle: L2(28).title,
    lawText: L2(28).insight,
    title: "A Noite do Port\xE3o",
    areaId: "muralha",
    giverNpc: "capitao",
    brief: "Bandidos atacam o port\xE3o norte na madrugada. Dami\xE3o tem um prisioneiro que talvez tenha a chave, e voc\xEA decide.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "capitao", [
        "A chave do port\xE3o est\xE1 com um prisioneiro. Ele diz que n\xE3o sabe, mas mente mal. Meia-noite, os bandidos chegam.",
        "Preciso da chave e preciso do prisioneiro vivo. As duas coisas, e r\xE1pido."
      ], [
        c(
          "Persu\xE3o o prisioneiro: digo que o rei o perdoa se ajudar.",
          "Dami\xE3o assente. \u201CPromessa de rei \xE9 cara, mas \xE9 a mais falsificada.\u201D",
          { npc: [{ id: "capitao", deltas: { trust: 4 } }], effects: { reputation: 1 }, score: 14, next: "b" }
        ),
        c(
          "Uso medo: digo que o rei viu o que ele fez.",
          "Dami\xE3o sorri. \u201CO medo arruma a chave em cinco minutos. Depois, ele pode ser esquecido.\u201D",
          {
            npc: [{ id: "capitao", deltas: { respect: 5 } }],
            effects: { power: 2, reputation: -1 },
            score: 16,
            next: "b"
          }
        ),
        c(
          "N\xE3o preciso da chave: atraio os bandidos para longe e fecho o port\xE3o de outro lado.",
          "Dami\xE3o arregala os olhos. \u201CCoragem de oficial. Ou loucura.\u201D",
          {
            npc: [{ id: "capitao", deltas: { respect: 8, loyalty: 4 } }],
            effects: { power: 2, reputation: 2 },
            flags: ["isca_no_portao"],
            score: 20,
            next: "b"
          }
        )
      ]),
      b: n("b", "capitao", [
        "Meia-noite chegou. A guarda \xE9 pequena e o rei n\xE3o sabe de nada. Diga o que fazemos."
      ], [
        c(
          "Fechamos o port\xE3o e seguramos. O rei que descubra amanh\xE3.",
          "A noite \xE9 longa, mas o port\xE3o aguenta. Quando amanhece, h\xE1 tr\xEAs feridos e uma vit\xF3ria.",
          {
            npc: [{ id: "capitao", deltas: { respect: 7, loyalty: 5 } }],
            effects: { power: 2, reputation: 3 },
            flags: ["defendeu_o_portao"],
            score: 28,
            end: "mission"
          }
        ),
        c(
          "Deixo o port\xE3o aberto e atraio os bandidos para fora da muralha.",
          "A poeira esconde o corpo. Os bandidos seguem a isca e s\xE3o vistos longe das muralhas. Ningu\xE9m entra. Ningu\xE9m v\xEA quem puxou.",
          {
            npc: [{ id: "capitao", deltas: { respect: 6, fear: 3 } }],
            effects: { power: 3, intelligence: 2 },
            flags: ["isca_no_portao", "mao_suja_3"],
            score: 26,
            end: "mission"
          }
        ),
        c(
          "Abro o port\xE3o e negocio com os bandidos: a carga por uma neutralidade.",
          "Dami\xE3o quase cai da cadeira. \u201CNegociar com bandidos? Eles aceitam. Uma rep\xFAblica de bandidos \xE9 melhor do que nenhuma.\u201D",
          {
            npc: [{ id: "capitao", deltas: { respect: 9, trust: 3 } }],
            effects: { wealth: 200, power: 2, reputation: -2 },
            flags: ["pacto_com_bandidos"],
            score: 24,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 55, effects: { power: 2 } }
  },
  {
    id: 29,
    lawTitle: L2(29).title,
    lawText: L2(29).insight,
    title: "O Fim Antes do Come\xE7o",
    areaId: "conselho",
    giverNpc: "chanceler",
    brief: "O Chanceler lhe pede um plano para derrubar o Duque Oldric, e avisa que voc\xEA s\xF3 tem um movimento.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "chanceler", [
        "Oldric tem armas, ouro e uma filha jovem demais para ser casada. Voc\xEA tem uma ideia e uma chance.",
        "Quero o plano inteiro: como come\xE7a, como termina, e o que acontece com voc\xEA quando acabar."
      ], [
        c(
          "Come\xE7o pela d\xEDvida: descubro de quem Oldric toma emprestado e chacoalho esse algu\xE9m.",
          "Hon\xF3rio assente. \u201CDinheiro \xE9 o sangue do poder. Corte o sangue.\u201D",
          { npc: [{ id: "chanceler", deltas: { respect: 7 } }], effects: { intelligence: 2 }, score: 16, next: "b" }
        ),
        c(
          "Come\xE7o pela filha: caso com ela e fa\xE7o de Oldric meu sogro.",
          "Hon\xF3rio quase sorri. \u201CAmbi\xE7oso. Voc\xEA entra pela fam\xEDlia, que \xE9 mais lento e mais seguro.\u201D",
          {
            npc: [{ id: "chanceler", deltas: { respect: 8 } }],
            effects: { power: 2, influence: 1 },
            flags: ["casamento_com_oldric"],
            score: 18,
            next: "b"
          }
        ),
        c(
          "Come\xE7o por descobrir quem, dentro da corte, fala contra Oldric quando o rei n\xE3o ouve.",
          "Hon\xF3rio fica muito quieto. \u201CPerigoso. Mas \xE9 assim que se derruba algu\xE9m sem sujar as m\xE3os.\u201D",
          {
            npc: [{ id: "chanceler", deltas: { trust: 6, respect: 6 } }],
            effects: { power: 3 },
            flags: ["usa_o_rei"],
            score: 20,
            next: "b"
          }
        )
      ]),
      b: n("b", "chanceler", [
        "Agora o fim. Depois que Oldric cair, o que voc\xEA quer que a corte diga sobre voc\xEA?"
      ], [
        c(
          "Que fui o homem que planejou isso. Nada mais, nada menos.",
          "Hon\xF3rio sorri. \u201CO cr\xE9dito \xE9 o \xFAnico tesouro que n\xE3o precisa ser guardado.\u201D",
          {
            npc: [{ id: "chanceler", deltas: { respect: 6, trust: 4 } }],
            effects: { power: 3, influence: 2 },
            flags: ["credito_total"],
            score: 28,
            end: "mission"
          }
        ),
        c(
          "Que o rei ordenou e eu obedeci. Planos s\xE3o perigosos quando t\xEAm autor.",
          "Hon\xF3rio assente devagar. \u201CSabio. Mas ningu\xE9m vai contar a sua hist\xF3ria. E a hist\xF3ria ser\xE1 mesmo de outro.\u201D",
          {
            npc: [{ id: "chanceler", deltas: { respect: 4 } }],
            effects: { reputation: 3, power: 1 },
            flags: ["anonimato"],
            score: 22,
            end: "mission"
          }
        ),
        c(
          "Que n\xE3o houve plano: foi a vontade do rei se movendo sozinha.",
          "Hon\xF3rio bate na mesa. \u201CPerfeito! Uma m\xE3o invis\xEDvel \xE9 mais forte que uma espada vis\xEDvel.\u201D",
          {
            npc: [{ id: "chanceler", deltas: { respect: 9, trust: 5 } }],
            effects: { power: 3, influence: 3 },
            flags: ["mao_de_deus"],
            score: 30,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 60, effects: { power: 2 } }
  },
  {
    id: 30,
    lawTitle: L2(30).title,
    lawText: L2(30).insight,
    title: "A Vit\xF3ria Trivial",
    areaId: "salao",
    giverNpc: "otavio",
    brief: "O Bar\xE3o Ot\xE1vio venceu um concurso de tiro com uma t\xE9cnica que voc\xEA inventou, e quer que voc\xEA diga que foi ideia dele.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "otavio", [
        "Venci! Nove de nove. E olhe a t\xE9cnica: ser\xE1 que o rei ouviria que foi ideia minha?",
        "Preciso que algu\xE9m diga que a ideia foi minha. Voc\xEA parece algu\xE9m a quem as pessoas acreditariam."
      ], [
        c(
          "Digo que a ideia foi sua. E cobramos por isso.",
          "Ot\xE1vio bate na mesa. \u201CCem moedas por uma frase. Caro e justo.\u201D",
          { npc: [{ id: "otavio", deltas: { trust: 6 } }], effects: { wealth: 150 }, score: 14, next: "b" }
        ),
        c(
          "Digo que foi ideia minha, e que ele ganhou por minha t\xE9cnica.",
          "Ot\xE1vio empalidece. \u201CVoc\xEA est\xE1 me roubando na frente de todo mundo. N\xE3o. N\xE3o vai.\u201D",
          {
            npc: [{ id: "otavio", deltas: { respect: -4, fear: 4 } }],
            effects: { power: 2, reputation: -1 },
            flags: ["roubou_o_credito"],
            score: 18,
            next: "b"
          }
        ),
        c(
          "N\xE3o digo nada. Invento que a ideia veio de um livro antigo que ningu\xE9m l\xEA.",
          "Ot\xE1vio te olha com respeito novo. \u201CMentira elegante. Ningu\xE9m consegue provar a mentira elegante.\u201D",
          { npc: [{ id: "otavio", deltas: { trust: 4, respect: 5 } }], effects: { intelligence: 2 }, score: 16, next: "b" }
        )
      ]),
      b: n("b", "otavio", [
        "O rei vai perguntar como foi, e a corte vai perguntar por que um bar\xE3o ganhou um concurso de guerreiro."
      ], [
        c(
          "Digo que a t\xE9cnica exige anos de treino, e que s\xF3 um nobre teria.",
          "Ot\xE1vio infla o peito. \u201CExato! D\xE9cadas! Ele sai daquela sala maior do que entrou.\u201D",
          {
            npc: [{ id: "otavio", deltas: { trust: 6 } }],
            effects: { influence: 2, reputation: 1 },
            flags: ["fingiu_anos_de_treino"],
            score: 24,
            end: "mission"
          }
        ),
        c(
          "Digo a verdade: a t\xE9cnica era minha e ele me consultou.",
          "Ot\xE1vio empalidece, mas n\xE3o pode brigar. \u201CVoc\xEA \xE9 justo. E justo \xE9 perigoso.\u201D",
          {
            npc: [{ id: "otavio", deltas: { respect: 7, trust: 3 } }],
            effects: { reputation: 4, power: 1 },
            flags: ["honesto_com_otavio"],
            score: 26,
            end: "mission"
          }
        ),
        c(
          "N\xE3o respondo. Deixo o sil\xEAncio: quem n\xE3o responde n\xE3o pode ser desmentido.",
          "Ot\xE1vio engole seco. \u201CVoc\xEA \xE9 assustador. E eu acabei de fazer amizade com um.\u201D",
          {
            npc: [{ id: "otavio", deltas: { respect: 8, fear: 5 } }],
            effects: { power: 2, intelligence: 2 },
            flags: ["silencio_otavio"],
            score: 24,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 55, effects: { influence: 2 } }
  },
  {
    id: 31,
    lawTitle: L2(31).title,
    lawText: L2(31).insight,
    title: "O Cardeal que Voc\xEA Escolhe",
    areaId: "conselho",
    giverNpc: "gaspar",
    brief: "O Tesoureiro Gaspar precisa de um novo coletor de impostos e quer a sua sugest\xE3o, de prop\xF3sito.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "gaspar", [
        "Um coletor novo. O anterior era neutro demais. Preciso de algu\xE9m que recolha e n\xE3o pergunte por qu\xEA.",
        "O rei quer o seu nome na carta. E eu quero saber qual nome voc\xEA vai escrever."
      ], [
        c(
          "Escrevo o name de um homem que me deve dinheiro.",
          "Gaspar assente. \u201CUm devedor endividado \xE9 um homem est\xE1vel. Boa escolha.\u201D",
          {
            npc: [{ id: "gaspar", deltas: { respect: 5 } }],
            effects: { wealth: 120, power: 1 },
            flags: ["nomeou_devedor"],
            score: 16,
            next: "b"
          }
        ),
        c(
          "Escrevo o nome de um homem fraco: obedecer\xE1 e n\xE3o pensar\xE1 duas vezes.",
          "Gaspar sorri. \u201CO fraco \xE9 o melhor cobrador: n\xE3o tem vontade pr\xF3pria para trair voc\xEA.\u201D",
          {
            npc: [{ id: "gaspar", deltas: { respect: 6 } }],
            effects: { power: 2, influence: 1 },
            flags: ["nomeu_fraco"],
            score: 18,
            next: "b"
          }
        ),
        c(
          "Pergunto por que o rei quer o MEU nome na carta.",
          "Gaspar te olha com aprova\xE7\xE3o. \u201CPorque o rei est\xE1 aprendendo a usar voc\xEA. E porque o que voc\xEA sugere vira pol\xEDtica.\u201D",
          { npc: [{ id: "gaspar", deltas: { respect: 8, trust: 4 } }], effects: { intelligence: 2 }, score: 16, next: "b" }
        )
      ]),
      b: n("b", "gaspar", [
        "O jogador precisa de op\xE7\xF5es. Duas, no m\xE1ximo: sen\xE3o o rei decide. Qual par voc\xEA coloca na mesa?"
      ], [
        c(
          "Dois que me devem: um pela d\xEDvida, outro pelo medo.",
          "Gaspar anota. \u201CDois ganchos, uma linha s\xF3. Ningu\xE9m escolhe o homem, escolhe a d\xEDvida.\u201D",
          {
            npc: [{ id: "gaspar", deltas: { respect: 6 } }],
            effects: { power: 3, influence: 1 },
            flags: ["opcoes_dependentes"],
            score: 26,
            end: "mission"
          }
        ),
        c(
          "Um forte e um fraco. Se o forte errar, o fraco obedece. Ou o contr\xE1rio.",
          "Gaspar franze a testa. \u201CDois reis num tabuleiro. Perigoso. Mas, sim, \xE9 assim que se prende um homem.\u201D",
          { npc: [{ id: "gaspar", deltas: { respect: 5 } }], effects: { power: 2 }, score: 22, end: "mission" }
        ),
        c(
          "S\xF3 uma op\xE7\xE3o: a minha pessoa. E eu governo por tr\xE1s dela.",
          "Gaspar quase derruba a pena. \u201CIsso \xE9 tomar o poder inteiro. Se o rei descobrir, acaba. Se funcionar, acaba de outro jeito.\u201D",
          {
            npc: [{ id: "gaspar", deltas: { respect: 9, fear: 6 } }],
            effects: { power: 4, influence: 2 },
            flags: ["homem_de_cena"],
            score: 28,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 60, effects: { power: 2 } }
  },
  {
    id: 32,
    lawTitle: L2(32).title,
    lawText: L2(32).insight,
    title: "O Baile de Valdessa",
    areaId: "solar",
    giverNpc: "duque",
    brief: "O Duque Oldric convida voc\xEA ao grande baile do Solar e quer saber qual fantasia a corte usa para decidir o futuro.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "duque", [
        "Este baile decide mais do que qualquer conselho. Cada fam\xEDlia mostra sua for\xE7a: quem veste ouro e quem veste l\xE3.",
        "Venha. E vista algo que fa\xE7a as pessoas olharem para voc\xEA, e n\xE3o para a minha filha."
      ], [
        c(
          "Visto a armadura que usei na muralha. Ferro e suor.",
          "Oldric franze a testa. \u201CA\xE7o no sal\xE3o? Voc\xEA quer que falem de guerra no meio do brilho.\u201D",
          { npc: [{ id: "duque", deltas: { respect: 5 } }], effects: { power: 1, reputation: 2 }, score: 14, next: "b" }
        ),
        c(
          "Visto ouro. Do seu ouro, se me emprestar.",
          "Oldric sorri de canto. \u201CA corte adora ostenta\xE7\xE3o que n\xE3o d\xF3i a ningu\xE9m.\u201D",
          {
            npc: [{ id: "duque", deltas: { respect: 7 } }],
            effects: { wealth: -200, influence: 2 },
            score: 18,
            next: "b"
          }
        ),
        c(
          "Visto simples e fico no canto. Observo quem \xE9 servido primeiro.",
          "Oldric olha para voc\xEA com respeito novo. \u201CAh, o observador. Cuide dos seus: eles contam mais do que voc\xEA.\u201D",
          {
            npc: [{ id: "duque", deltas: { respect: 8, trust: 3 } }],
            effects: { intelligence: 3 },
            flags: ["observador_do_baile"],
            score: 18,
            next: "b"
          }
        )
      ]),
      b: n("b", "duque", [
        "Diga-me: qual \xE9 a fantasia desta corte? O que eles sonham em ser?"
      ], [
        c(
          "Querem um rei forte que os proteja do mundo, e um herdeiro para o trono.",
          "Oldric bate na mesa. \u201CPerfeito! Ent\xE3o ofere\xE7a um protetor e um herdeiro. Vende-se barato.\u201D",
          {
            npc: [{ id: "duque", deltas: { respect: 7 } }],
            effects: { influence: 3, power: 1 },
            flags: ["vende_seguranca"],
            score: 26,
            end: "mission"
          }
        ),
        c(
          "Querem ser o reino mais rico do mundo. Ouro, festas, bravura.",
          "Oldric ri. \u201CSe a corte sonha em ouro, ofere\xE7a ouro, e o ouro corre atr\xE1s de voc\xEA como sombra.\u201D",
          {
            npc: [{ id: "duque", deltas: { respect: 5 } }],
            effects: { wealth: 250, influence: 1 },
            flags: ["vende_ouro"],
            score: 22,
            end: "mission"
          }
        ),
        c(
          "Querem um herdeiro: um rei jovem, forte, que nas\xE7a pronto.",
          "Oldric fica muito quieto. \u201CAh. Voc\xEA pensa como eu. E quem entregar o herdeiro...\u201D",
          {
            npc: [{ id: "duque", deltas: { respect: 9, fear: 3 } }],
            effects: { power: 3, intelligence: 1 },
            flags: ["herdeiro_no_olhar"],
            score: 28,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 60, effects: { influence: 2 } }
  }
];

// src/game/data/missionsC.ts
var L3 = (id) => LAWS[id - 1];
var MISSIONS_C = [
  {
    id: 33,
    lawTitle: L3(33).title,
    lawText: L3(33).insight,
    title: "O Polegar de Cada Um",
    areaId: "conselho",
    giverNpc: "aurelio",
    brief: "Aurelio quer um dossi\xEA: a fraqueza de tr\xEAs pessoas da corte. Documentos espalhados pelo reino guardam o resto.",
    steps: [
      { kind: "dialogue", node: "a" },
      { kind: "collect", item: "diario", count: 1, hint: "Encontre o Di\xE1rio Riscado na C\xE2mara do Conselho." },
      { kind: "collect", item: "anel", count: 1, hint: "Encontre o Anel de Selo no Solar de Valdessa." },
      { kind: "dialogue", node: "b" }
    ],
    nodes: {
      a: n("a", "aurelio", [
        "Tr\xEAs homens. Tr\xEAs fraquezas. O di\xE1rio do tesouro est\xE1 no meu arm\xE1rio, o anel do Duque foi esquecido no sal\xE3o de Valdessa.",
        "Traga os dois e eu monto o dossi\xEA. Mas cuidado: quem l\xEA o dossi\xEA vira o dossi\xEA."
      ], [
        c(
          "Vou buscar os dois e n\xE3o deixo c\xF3pias.",
          "Aurelio assente. \u201CLeve o que precisa, traga o que importa. E n\xE3o olhe o que n\xE3o precisa.\u201D",
          {
            npc: [{ id: "aurelio", deltas: { trust: 6, respect: 3 } }],
            effects: { intelligence: 1 },
            score: 14
          }
        ),
        c(
          "Pergunto: por que voc\xEA n\xE3o busca voc\xEA mesmo?",
          "Aurelio sorri sem humor. \u201CPorque eu n\xE3o posso ser encontrado com o dossi\xEA. Voc\xEA, sim.\u201D",
          { npc: [{ id: "aurelio", deltas: { respect: 5 } }], effects: { intelligence: 2 }, score: 12 }
        ),
        c(
          "Pergunto quem \xE9 o alvo: tr\xEAs homens s\xE3o muitos.",
          "Aurelio fecha a boca. \u201CJusto. Escolha dois e eu completo o terceiro. Escolha bem.\u201D",
          { npc: [{ id: "aurelio", deltas: { trust: 3 } }], effects: { power: 1 }, score: 10 }
        )
      ]),
      b: n("b", "aurelio", [
        "Agora tenho o dossi\xEA. E voc\xEA tamb\xE9m sabe quem \xE9 fraco: o Duque teme o esc\xE2ndalo, o Tesoureiro teme a auditoria, o Escrib\xE3o teme a pr\xF3pria mem\xF3ria.",
        "Qual desses tr\xEAs voc\xEA usa primeiro?"
      ], [
        c(
          "O Duque. Ele \xE9 o maior, e o maior cai mais alto.",
          "Aurelio empurra o dossi\xEA para voc\xEA. \u201CPoder \xE9 escolher a queda certa.\u201D",
          {
            npc: [{ id: "aurelio", deltas: { trust: 7, respect: 5 } }],
            effects: { power: 3, influence: 2 },
            flags: ["dossie_do_duque"],
            score: 28,
            end: "mission"
          }
        ),
        c(
          "O Tesoureiro. Quem controla o dinheiro controla quem tem medo de passar fome.",
          "Aurelio assente. \u201CO medo financeiro \xE9 o mais \xFAtil: ele n\xE3o se orgulha, n\xE3o resiste.\u201D",
          {
            npc: [{ id: "aurelio", deltas: { trust: 5 } }],
            effects: { wealth: 250, power: 2 },
            flags: ["dossie_do_tesoureiro"],
            score: 26,
            end: "mission"
          }
        ),
        c(
          "Nenhum. Guardo o dossi\xEA e n\xE3o uso. Conhecimento parado \xE9 poder parado.",
          "Aurelio te olha com admira\xE7\xE3o. \u201CVoc\xEA aprendeu. O segredo guardado \xE9 o \xFAnico que n\xE3o pode ser roubado.\u201D",
          {
            npc: [{ id: "aurelio", deltas: { trust: 9, respect: 7 } }],
            effects: { intelligence: 3, power: 1 },
            flags: ["dossie_guardado"],
            score: 30,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 55, effects: { intelligence: 2 } }
  },
  {
    id: 34,
    lawTitle: L3(34).title,
    lawText: L3(34).insight,
    title: "O Traje",
    areaId: "trono",
    giverNpc: "sereno",
    brief: "O Sal\xE3o do Trono tem um protocolo: o rei n\xE3o recebe?nem olha para quem n\xE3o veste como rei.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "sereno", [
        "Hoje \xE9 dia de peti\xE7\xE3o. O rei recebe dez homens e n\xE3o olha para nove. O d\xE9cimo \xE9 o que veste e porta como um rei.",
        "Vamos escolher o seu traje. E aviso: quem se disfar\xE7a de rei por baixo da pele vira rei por cima."
      ], [
        c(
          "Manto de rei, botas de ferro, coroa que n\xE3o \xE9 minha.",
          "Sereno bate palmas. \u201CPerfeito. \xC9 assim que se entra numa corte: parecendo o que quer ser antes de ser.\u201D",
          {
            npc: [{ id: "sereno", deltas: { respect: 7 } }],
            effects: { influence: 2, power: 1 },
            flags: ["traje_de_rei"],
            score: 16,
            next: "b"
          }
        ),
        c(
          "Roupa de cortes\xE3o: seda, joias, sem armadura.",
          "Sereno franze a testa. \u201CCortes\xE3o \xE9 o que o rei usa para se cercar. Voc\xEA quer ser cercado, ou quer ser o centro?\u201D",
          { npc: [{ id: "sereno", deltas: { respect: 3 } }], effects: { influence: 1 }, score: 12, next: "b" }
        ),
        c(
          "Roupa simples, como sempre. O rei que me veja como eu sou.",
          "Sereno balan\xE7a a cabe\xE7a. \u201CO rei v\xEA o que voc\xEA veste, n\xE3o o que voc\xEA \xE9. Ningu\xE9m tem tempo para o que voc\xEA \xE9.\u201D",
          { npc: [{ id: "sereno", deltas: { respect: 4 } }], effects: { reputation: 1 }, score: 10, next: "b" }
        )
      ]),
      b: n("b", "sereno", [
        "E o gesto: quando o rei olhar para voc\xEA, o que voc\xEA faz?"
      ], [
        c(
          "Olho de volta e sustento. Sem desafiar, sem ceder.",
          "Sereno sorri de canto. \u201COlhar sustentado \xE9 a forma mais barata de poder.\u201D",
          {
            npc: [{ id: "sereno", deltas: { respect: 8 } }],
            effects: { power: 2, influence: 2 },
            flags: ["olhar_sustentado"],
            score: 26,
            end: "mission"
          }
        ),
        c(
          "Baixo os olhos e sorrio. Humildade ensaiada.",
          "Sereno assente. \u201CPerfeito. Quem baixa os olhos primeiro aceita o peso do rei sobre os ombros.\u201D",
          {
            npc: [{ id: "sereno", deltas: { respect: 5 } }],
            effects: { reputation: 3, power: 1 },
            flags: ["humildade_ensaiada"],
            score: 22,
            end: "mission"
          }
        ),
        c(
          "Fa\xE7o uma rever\xEAncia profunda e espero que o rei a termine antes de mim.",
          "Sereno bate na pr\xF3pria testa. \u201CBrilhante. Voc\xEA mede o rei por uma rever\xEAncia e descobre o tamanho dele.\u201D",
          {
            npc: [{ id: "sereno", deltas: { respect: 7, trust: 4 } }],
            effects: { intelligence: 2, influence: 2 },
            flags: ["leu_o_rei"],
            score: 28,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 60, effects: { influence: 2 } }
  },
  {
    id: 35,
    lawTitle: L3(35).title,
    lawText: L3(35).insight,
    title: "A Hora Certa",
    areaId: "muralha",
    giverNpc: "vargo",
    brief: "Vargo sabe de um ataque ao celeiro do rei. Sabe tamb\xE9m a hora exata. E sabe que voc\xEA pode n\xE3o estar l\xE1.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "vargo", [
        "Cavaleiros do Lorde do Norte v\xE3o atacar o celeiro do rei depois da meia-noite. Tr\xEAs horas, talvez quatro.",
        "Se voc\xEA contar agora, o rei preparar a guarda e n\xF3s perdemos a noite. Se contar tarde, pode ser tarde demais."
      ], [
        c(
          "Conto agora. Uma vida vale mais que uma vantagem.",
          "Vargo te olha de soslaio. \u201CHonesto. O rei vai dormir tranquilo e voc\xEA vai ser lembrado. Ou esquecido.\u201D",
          {
            npc: [{ id: "vargo", deltas: { trust: 7, respect: 4 } }],
            effects: { reputation: 3, power: 1 },
            flags: ["avisou_cedo"],
            score: 16,
            next: "b"
          }
        ),
        c(
          "Conto na hora certa: quando o ataque come\xE7ar e o rei precisar de um her\xF3i.",
          "Vargo sorri de lado. \u201CAh. Voc\xEA quer estar onde a hist\xF3ria est\xE1 sendo escrita.\u201D",
          {
            npc: [{ id: "vargo", deltas: { respect: 7, fear: 2 } }],
            effects: { power: 2, influence: 1 },
            flags: ["esperou_o_momento"],
            score: 18,
            next: "b"
          }
        ),
        c(
          "N\xE3o aviso. Deixo o celeiro queimar: o rei precisa de um inimigo para se lembrar de quem o salvou.",
          "Vargo empalidece. \u201CIsso \xE9 loucura. Ou \xE9 a coisa mais inteligente que ouvi este ano.\u201D",
          {
            npc: [{ id: "vargo", deltas: { respect: 9, fear: 6 } }],
            effects: { power: 3, reputation: -3 },
            flags: ["deixou_queimar"],
            score: 20,
            next: "b"
          }
        )
      ]),
      b: n("b", "vargo", [
        "Diga o resto: o que eu ganho eu entrego a algu\xE9m. E esse algu\xE9m me deve um lugar na corte."
      ], [
        c(
          "Falo com o rei. Ele me deve um lugar na corte.",
          "Vargo assente. \u201CBom. E n\xE3o minta: quem salva o celeiro recebe o que ningu\xE9m ousa pedir.\u201D",
          {
            npc: [{ id: "vargo", deltas: { trust: 5 } }],
            effects: { power: 3, influence: 2 },
            flags: ["promessa_do_rei"],
            score: 28,
            end: "mission"
          }
        ),
        c(
          "Falo com a Rainha. Ela me deve um lugar na corte.",
          "Vargo arregala os olhos. \u201CA Rainha! Quem protege o celeiro de madrugada a presen\xE7a de um homem real na corte.\u201D",
          {
            npc: [{ id: "vargo", deltas: { respect: 6 } }],
            effects: { power: 3, intelligence: 1 },
            flags: ["promessa_da_rainha"],
            score: 26,
            end: "mission"
          }
        ),
        c(
          "Falo com o Chanceler. O poder real do reino est\xE1 na C\xE2mara do Conselho.",
          "Vargo co\xE7a a cabe\xE7a. \u201CCuidado. O chanceler paga bem, mas cobra caro, e cobra sempre.\u201D",
          {
            npc: [{ id: "vargo", deltas: { trust: 3 } }],
            effects: { power: 2, wealth: 200 },
            flags: ["promessa_do_chanceler"],
            score: 24,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 65, effects: { power: 2 } }
  },
  {
    id: 36,
    lawTitle: L3(36).title,
    lawText: L3(36).insight,
    title: "O Desejo Imposs\xEDvel",
    areaId: "solar",
    giverNpc: "duque",
    brief: "O Duque lhe oferece um peda\xE7o da Coroa Partida. Ningu\xE9m que n\xE3o seja rei pode sequer olhar para ela.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "duque", [
        "A Coroa Partida tem seis peda\xE7os. Este \xE9 um deles: o da Coroa da Alva. Fica com ele.",
        "Nenhum rei aqui o pode usar. Ent\xE3o \xE9 um presente, e presentes n\xE3o obrigam."
      ], [
        c(
          "Aceito o peda\xE7o. E digo que n\xE3o vou usar coroa nenhuma.",
          "Oldric fica im\xF3vel. \u201CDesprezo? Ou estrat\xE9gia?\u201D",
          {
            npc: [{ id: "duque", deltas: { respect: 8, fear: 4 } }],
            effects: { power: 2, intelligence: 1 },
            flags: ["coroa_desejada"],
            score: 16,
            next: "b"
          }
        ),
        c(
          "Recuso. N\xE3o quero o que n\xE3o posso usar.",
          "Oldric sorri de canto. \u201CAh. Ent\xE3o voc\xEA entende o jogo: o que se pode ter n\xE3o \xE9 poder.\u201D",
          {
            npc: [{ id: "duque", deltas: { respect: 7 } }],
            effects: { intelligence: 2, reputation: 1 },
            flags: ["recusou_a_coroa"],
            score: 18,
            next: "b"
          }
        ),
        c(
          "Aceito e digo: guardo at\xE9 poder usar. A desire \xE9 uma d\xEDvida.",
          "Oldric assente devagar. \u201CIsso \xE9 ambi\xE7\xE3o com patience. Raro. E \xFAtil.\u201D",
          {
            npc: [{ id: "duque", deltas: { respect: 8, trust: 4 } }],
            effects: { power: 2, influence: 1 },
            flags: ["coroa_desejada"],
            score: 16,
            next: "b"
          }
        )
      ]),
      b: n("b", "duque", [
        "Agora o teste: h\xE1 um outro peda\xE7o. Est\xE1 com a Valdessa, minha filha. Ningu\xE9m pode compr\xE1-lo.",
        "Como voc\xEA o consegue?"
      ], [
        c(
          "N\xE3o tento. Dizer que n\xE3o quero o que n\xE3o posso ter j\xE1 me deu metade do poder.",
          "Oldric bate na mesa, deliciado. \u201CExcelente! O desd\xE9m \xE9 a \xFAnica arma que o rei n\xE3o pode tirar de voc\xEA.\u201D",
          {
            npc: [{ id: "duque", deltas: { respect: 10, trust: 4 } }],
            effects: { power: 3, intelligence: 2 },
            flags: ["desd\xE9m"],
            score: 28,
            end: "mission"
          }
        ),
        c(
          "Fa\xE7o uma proposta a Valdessa em troca de algo que ela queira mais.",
          "Oldric assente. \u201CNeg\xF3cio. Voc\xEA entende: ningu\xE9m d\xE1 nada de gra\xE7a.\u201D",
          {
            npc: [{ id: "duque", deltas: { respect: 7 } }],
            effects: { power: 2, wealth: 150 },
            flags: ["negociou_a_coroa"],
            score: 24,
            end: "mission"
          }
        ),
        c(
          "Espero. Rei novo, coroa nova, peda\xE7os repartidos.",
          "Oldric empalidece. \u201CVoc\xEA \xE9 muito perigoso quando n\xE3o faz nada.\u201D",
          {
            npc: [{ id: "duque", deltas: { respect: 9, fear: 5 } }],
            effects: { intelligence: 3, power: 1 },
            flags: ["esperou_a_coroa"],
            score: 26,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 65, effects: { influence: 2 } }
  },
  {
    id: 37,
    lawTitle: L3(37).title,
    lawText: L3(37).insight,
    title: "A Estrofe",
    areaId: "salao",
    giverNpc: "ismael",
    brief: "O Trovador Ismael comp\xF5e para a corte. Ele precisa de um tema: a hist\xF3ria que o reino vai repetir por um m\xEAs.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "ismael", [
        "O rei adora uma estrofe sobre a m\xE3e. A corte adora uma estrofe sobre o generalised. O povo adora uma estrofe sobre o p\xE3o.",
        "Uma estrofe se repete, vira rumor, e rumor repetido vira verdade. Qual deles voc\xEA quer que eu cante?"
      ], [
        c(
          "Sobre o rei. Quem ataca o rei ataca a pr\xF3priaimage de perto.",
          "Ismael estala os dedos. \u201CDif\xEDcil de cantar, dif\xEDcil de esquecer. Perfeito.\u201D",
          {
            npc: [{ id: "ismael", deltas: { trust: 5 } }],
            effects: { power: 1, reputation: 2 },
            flags: ["estrofe_do_rei"],
            score: 16,
            next: "b"
          }
        ),
        c(
          "Sobre o povo. O que o povo repete, o rei precisa ouvir.",
          "Ismael ri. \u201CPerigoso e bonito. A corte vai odiar voc\xEA por isso.\u201D",
          {
            npc: [{ id: "ismael", deltas: { trust: 5 } }],
            effects: { reputation: 4, power: -1 },
            flags: ["estrofe_do_povo"],
            score: 18,
            next: "b"
          }
        ),
        c(
          "Sobre mim. Uma hist\xF3ria sobre quem est\xE1 subindo.",
          "Ismael te olha de lado. \u201CAh. Autocelebridade. Cuidado: quem canta a pr\xF3pria.gl\xF3ria vira objeto de zombaria.\u201D",
          {
            npc: [{ id: "ismael", deltas: { respect: 4 } }],
            effects: { influence: 3, reputation: -1 },
            flags: ["estrofe_propria"],
            score: 16,
            next: "b"
          }
        )
      ]),
      b: n("b", "ismael", [
        "E o espet\xE1culo. Preciso de uma cena que o povo veja e n\xE3o entenda. Voc\xEA me d\xE1 a cena?"
      ], [
        c(
          "Um homem carrega um trono vazio pela pra\xE7a, sem explicar por qu\xEA.",
          "Ismael se arrepiou. \u201CIsso \xE9 um espet\xE1culo. O povo vai falar nisso durante anos.\u201D",
          {
            npc: [{ id: "ismael", deltas: { trust: 6 } }],
            effects: { influence: 3, power: 2 },
            flags: ["espetaculo_do_trono"],
            score: 28,
            end: "mission"
          }
        ),
        c(
          "Uma multa escrita no ch\xE3o da pra\xE7a, em letras enormes.",
          "Ismael bate na mesa. \u201CO mesmo valor na rua e no castelo: finalmente o rei fala com a mesma voz nos dois lugares.\u201D",
          {
            npc: [{ id: "ismael", deltas: { trust: 4 } }],
            effects: { reputation: 4, power: 1 },
            flags: ["espetaculo_da_multa"],
            score: 24,
            end: "mission"
          }
        ),
        c(
          "Um baile, com m\xFAsica, com prata nas mesas.",
          "Ismael sorri. \u201CO espet\xE1culo mais antigo: gente feliz em uma sala grande. A corte adora. O povo aplaude.\u201D",
          {
            npc: [{ id: "ismael", deltas: { trust: 3 } }],
            effects: { wealth: -150, reputation: 3, influence: 1 },
            flags: ["espetaculo_do_baile"],
            score: 22,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 65, effects: { influence: 2 } }
  },
  {
    id: 38,
    lawTitle: L3(38).title,
    lawText: L3(38).insight,
    title: "O Reformador",
    areaId: "conselho",
    giverNpc: "gaspar",
    brief: "Gaspar tem uma proposta de reforma: garagem, celeiro, nada de impostos dobrados. A corte teme. O povo quer.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "gaspar", [
        "Reforma: o celeiro vira garagem p\xFAblica, o imposto do sal cai pela metade, e o dinheiro vai para as obras da muralha.",
        "Gosto da ideia? Porque a corte vai perguntar quem est\xE1 por tr\xE1s disso. E a pergunta ter\xE1 resposta."
      ], [
        c(
          "Apoio, e digo abertamente que a ideia \xE9 minha.",
          "Gaspar empalidece. \u201CVoc\xEA acabou de se tornar o homem que a corte quer derrubar. Mas\u2026 \xE9 bonito.\u201D",
          {
            npc: [{ id: "gaspar", deltas: { respect: 6, fear: 3 } }],
            effects: { reputation: 5, power: -1 },
            flags: ["reforma_publica"],
            score: 18,
            next: "b"
          }
        ),
        c(
          "Apoio, mas digo que a ideia \xE9 de um grupo de bons conceelhos.",
          "Gaspar sorri. \u201CAh. O grupo. Todo grupo tem um rosto se algu\xE9m perguntar.\u201D",
          {
            npc: [{ id: "gaspar", deltas: { respect: 7 } }],
            effects: { reputation: 4, influence: 2 },
            flags: ["reforma_anonima"],
            score: 20,
            next: "b"
          }
        ),
        c(
          "Recuso. O rei n\xE3o pediu reformas e a corte n\xE3olikes mudan\xE7as.",
          "Gaspar encolhe os ombros. \u201CSabio. E chato. Mudan\xE7a que n\xE3o \xE9 pedida \xE9 sempre amea\xE7a.\u201D",
          {
            npc: [{ id: "gaspar", deltas: { respect: 4 } }],
            effects: { power: 1, reputation: 1 },
            flags: ["sem_reforma"],
            score: 12,
            next: "b"
          }
        )
      ]),
      b: n("b", "gaspar", [
        "H\xE1 um detalhe: a corte n\xE3o tolera que algu\xE9m pense diferente em p\xFAblico. Como voc\xEA reage quando um conseiller olha de lado?"
      ], [
        c(
          "Sorrio e falo do tempo. Nada de pol\xEDtica, nada de amea\xE7a.",
          "Gaspar assente. \u201COu\xE7a: na corte, o assunto morto \xE9 o assunto mais forte.\u201D",
          {
            npc: [{ id: "gaspar", deltas: { respect: 6 } }],
            effects: { intelligence: 2, influence: 1 },
            flags: ["desvio_de_olhar"],
            score: 26,
            end: "mission"
          }
        ),
        c(
          "Sustento o olhar e mudo de assunto. Mostro que n\xE3o tenho medo e n\xE3o mudo nada.",
          "Gaspar balan\xE7a a cabe\xE7a. \u201CCorajoso. Mas corajoso demais custa caro. Pelo menos voc\xEA \xE9 lembrado.\u201D",
          {
            npc: [{ id: "gaspar", deltas: { respect: 8, fear: 3 } }],
            effects: { power: 2, reputation: -1 },
            flags: ["sustenta_o_olhar"],
            score: 24,
            end: "mission"
          }
        ),
        c(
          "Fa\xE7o o que a corte espera: concordo em p\xFAblico e mudo tudo por baixo.",
          "Gaspar sorri de canto. \u201CPor baixo. Sempre por baixo. \xC9 assim que se vence sem morrer.\u201D",
          {
            npc: [{ id: "gaspar", deltas: { trust: 5 } }],
            effects: { power: 3, reputation: 2 },
            flags: ["concorda_e_muda"],
            score: 26,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 65, effects: { influence: 2 } }
  },
  {
    id: 39,
    lawTitle: L3(39).title,
    lawText: L3(39).insight,
    title: "A \xC1gua Turva",
    areaId: "muralha",
    giverNpc: "capitao",
    brief: "Dami\xE3o perdeu uma carrega de carga para o Lorde do Norte. Ele quer vingan\xE7a, e voc\xEA pode ser o culpado perfeito.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "capitao", [
        "Perdemos um comboio de gr\xE3o para o Lorde do Norte. O rei quer um culpado para o tribunal, e o reino quer uma hist\xF3ria.",
        "Podemos fazer a hist\xF3ria. Voc\xEA pode ser o instrumento, ou pode ser o culpado."
      ], [
        c(
          "Fa\xE7o a hist\xF3ria: invento um ataque e aponto para um homem fraco da corte.",
          "Dami\xE3o sorri. \u201CMentira com sabor. O reino vai acreditar, porque rumor n\xE3o precisa de provas.\u201D",
          {
            npc: [{ id: "capitao", deltas: { trust: 6, respect: 3 } }],
            effects: { power: 2, influence: 1 },
            flags: ["agitou_as_aguas"],
            score: 16,
            next: "b"
          }
        ),
        c(
          "Aceito ser o culpado. Se o reino me queimar, eu ganho algo maior.",
          "Dami\xE3o empalidece. \u201CVoc\xEA \xE9 corajoso ou louco. Mas ningu\xE9m se queima com mais eleg\xE2ncia.\u201D",
          {
            npc: [{ id: "capitao", deltas: { respect: 8, fear: 4 } }],
            effects: { reputation: 3, power: 2 },
            flags: ["falsas_acusacao"],
            score: 18,
            next: "b"
          }
        ),
        c(
          "Recuso. N\xE3o fabrico hist\xF3rias para a corte.",
          "Dami\xE3o suspira. \u201CLimpo. E o Lorde do Norte continua com o nosso gr\xE3o.\u201D",
          {
            npc: [{ id: "capitao", deltas: { respect: 3 } }],
            effects: { reputation: 2, influence: 1 },
            flags: ["sem_falsas_historias"],
            score: 12,
            next: "b"
          }
        )
      ]),
      b: n("b", "capitao", [
        "A hist\xF3ria precisa de um rosto. Um rosto que a corte j\xE1 odeia. Quem voc\xEA escolhe?"
      ], [
        c(
          "O Bar\xE3o Ot\xE1vio. Jovem, rico e beloved por todos. O reino vai acreditar em qualquer coisa sobre ele.",
          "Dami\xE3o bate na mesa. \u201CPerfeito. O herdeiro da corte virando o vil\xE3o: o pueblo vai amar isso.\u201D",
          {
            npc: [{ id: "capitao", deltas: { respect: 7 } }],
            effects: { power: 3, influence: 2, reputation: -1 },
            flags: ["culpa_otavio"],
            score: 28,
            end: "mission"
          }
        ),
        c(
          "O Escrib\xE3o Aur\xE9lio. Ele escreveu o relat\xF3rio da loss. Ningu\xE9m vai acreditar na inoc\xEAncia de quem escreve.",
          "Dami\xE3o ri. \u201CCruel e tecnicamente perfeito. Aur\xE9lio vai saber que foi voc\xEA.\u201D",
          {
            npc: [{ id: "capitao", deltas: { respect: 6 } }],
            effects: { power: 3, intelligence: 1 },
            flags: ["culpa_aurelio"],
            score: 26,
            end: "mission"
          }
        ),
        c(
          "Ningu\xE9m. Deixo a hist\xF3ria se construir sozinha.",
          "Dami\xE3o fica surpreso. \u201CVoc\xEA espera que o boato cres\xE7a sozinho. \xC9 a forma mais limpa e a mais dif\xEDcil.\u201D",
          {
            npc: [{ id: "capitao", deltas: { respect: 8 } }],
            effects: { intelligence: 3, power: 1 },
            flags: ["historia_sozinha"],
            score: 26,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 70, effects: { power: 2 } }
  },
  {
    id: 40,
    lawTitle: L3(40).title,
    lawText: L3(40).insight,
    title: "O Presente",
    areaId: "taverna",
    giverNpc: "taveiro",
    brief: "Um desconhecido deixou uma bolsa de ouro para voc\xEA na mesa da taverna, com um bilhete: n\xE3o pergunte.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "taveiro", [
        "Deixaram isso para voc\xEA. Cem moedas, bem pesadas, e um bilhete que diz: n\xE3o pergunte.",
        "Eu j\xE1 vi esse tipo antes. \xC9 ou um suborno para voc\xEA ficar quieto, ou um teste para ver se voc\xEA morde a isca."
      ], [
        c(
          "Devolvo o ouro. Escrevo no bilhete: n\xE3o aceito presentes sem nome.",
          "O ca\xE7ador sorri de lado. \u201CO bilhete vai voltar, e quem o mandou vai entender que voc\xEA \xE9 um homem dif\xEDcil. Isso vale mais que o ouro.\u201D",
          {
            npc: [{ id: "taveiro", deltas: { trust: 6, respect: 6 } }],
            effects: { reputation: 4, power: 1 },
            flags: ["devolveu_o_presente"],
            score: 18,
            next: "b"
          }
        ),
        c(
          "Aceito o ouro. Um presente n\xE3o \xE9 uma corrente, \xE9 um Opportunity.",
          "O ca\xE7ador balan\xE7a a cabe\xE7a. \u201CVoc\xEA aceita e n\xE3o deve nada? Vai descobrir que devia.\u201D",
          {
            npc: [{ id: "taveiro", deltas: { respect: 2 } }],
            effects: { wealth: 300, influence: 1 },
            flags: ["aceitou_o_presente"],
            score: 14,
            next: "b"
          }
        ),
        c(
          "Pego o ouro e descubro quem mandou.",
          "O ca\xE7ador te olha com respeito novo. \u201CAh. Voc\xEA morde e olha o anzol. Bom. S\xF3 n\xE3o bite o peixe.\u201D",
          {
            npc: [{ id: "taveiro", deltas: { respect: 5 } }],
            effects: { intelligence: 3, wealth: 300 },
            flags: ["aceitou_o_presente", "descobriu_o_doador"],
            score: 20,
            next: "b"
          }
        )
      ]),
      b: n("b", "taveiro", [
        "E o bilhete? Voc\xEA devolve, rasga, guarda?"
      ], [
        c(
          "Rasgo o bilhete e devolvo o ouro.",
          "O ca\xE7ador bate palma. \u201CNada de prova, nada de d\xEDvida. Limpo.\u201D",
          { npc: [{ id: "taveiro", deltas: { respect: 7 } }], effects: { reputation: 3 }, score: 24, end: "mission" }
        ),
        c(
          "Guardo o bilhete em branco e devolvo o ouro com ele.",
          "O ca\xE7ador franze a testa. \u201CVoc\xEA quer uma prova de que recusou. Isso \xE9 esperto e paranoid.\u201D",
          {
            npc: [{ id: "taveiro", deltas: { respect: 5 } }],
            effects: { intelligence: 2, power: 1 },
            flags: ["guardou_o_bilhete"],
            score: 26,
            end: "mission"
          }
        ),
        c(
          "Guardo o ouro e o bilhete. Um dia eu vou precisar de um favor sem nome.",
          "O ca\xE7ador te encara. \u201CVai precisar. E quando precisar, algu\xE9m vai lembrar desta noite.\u201D",
          {
            npc: [{ id: "taveiro", deltas: { respect: 4, fear: 2 } }],
            effects: { wealth: 300, power: 2 },
            flags: ["aceitou_o_presente"],
            score: 18,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 60, effects: { reputation: 2 } }
  },
  {
    id: 41,
    lawTitle: L3(41).title,
    lawText: L3(41).insight,
    title: "O Cal\xE7ado do Rei",
    areaId: "trono",
    giverNpc: "rainha",
    brief: "O rei est\xE1 doente e Clem\xEAncia precisa de um herdeiro. Voc\xEA \xE9 o candidato que ela considera, e n\xE3o likes o que vem depois.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "rainha", [
        "O rei est\xE1 doente. Em quatro esta\xE7\xF5es, talvez menos, o trono fica vago. A corte j\xE1 fala em sucess\xE3o, e fala em voc\xEA.",
        "Quero saber: voc\xEA quer o trono ou quer o que est\xE1 embaixo do trono?"
      ], [
        c(
          "Quero o trono. Sem rodeios.",
          "Clem\xEAncia assente. \u201CDireto. Isso \xE9 rareza. E tamb\xE9m um erro: quem diz que quer o trono nunca o chega a sentar.\u201D",
          {
            npc: [{ id: "rainha", deltas: { respect: 8, fear: 2 } }],
            effects: { power: 3 },
            flags: ["disse_quer_o_trono"],
            score: 18,
            next: "b"
          }
        ),
        c(
          "Quero o poder por tr\xE1s do trono. Um rei precisa de algu\xE9m que segure o peso.",
          "Clem\xEAncia sorri. \u201CAh. Finally, uma resposta que pensa em dois reinados.\u201D",
          {
            npc: [{ id: "rainha", deltas: { trust: 7, respect: 6 } }],
            effects: { power: 3, influence: 2 },
            flags: ["quer_poder_atras"],
            score: 20,
            next: "b"
          }
        ),
        c(
          "N\xE3o sei ainda. E vou saber antes de dizer.",
          "Clem\xEAncia inclina a cabe\xE7a. \u201CS\xE1bio. Quem fala cedo demais na sucess\xE3o fica sem coroa e semurally.\u201D",
          { npc: [{ id: "rainha", deltas: { respect: 7, trust: 4 } }], effects: { intelligence: 2 }, score: 16, next: "b" }
        )
      ]),
      b: n("b", "rainha", [
        "Existe uma coisa que o rei n\xE3o sabe: eu n\xE3o quero um herdeiro. Quero uma voz.",
        "Se voc\xEA aceitar ser essa voz, precisa fazer o que eu digo. Se recusar, precisa continuar sendo ningu\xE9m. Qual dos dois d\xF3i menos?"
      ], [
        c(
          "Aceito ser a voz da Rainha. A Alian\xE7a mais forte do reino.",
          "Clem\xEAncia aperta sua m\xE3o. \u201CEnt\xE3o o rei ter\xE1 um bra\xE7o, e eu terei o outro. Bom.\u201D",
          {
            npc: [{ id: "rainha", deltas: { trust: 8, loyalty: 6 } }],
            effects: { power: 3, influence: 2 },
            flags: ["voz_da_rainha"],
            score: 28,
            end: "mission"
          }
        ),
        c(
          "Recuso. N\xE3o sirvo a duas coroas.",
          "Clem\xEAncia n\xE3o parece ofendida. \u201CEsperto. Um homem com dois donos n\xE3o tem dono nenhum.\u201D",
          {
            npc: [{ id: "rainha", deltas: { respect: 9, trust: -3 } }],
            effects: { reputation: 3, power: 1 },
            flags: ["independente"],
            score: 26,
            end: "mission"
          }
        ),
        c(
          "Aceito, mas em troca quero a Coroa Partida quando o rei faltar.",
          "Clem\xEAncia ri baixo. \u201CAh, negotiate. All right. Voc\xEA \xE9 perigoso e eu gosto disso.\u201D",
          {
            npc: [{ id: "rainha", deltas: { trust: 5, respect: 7, fear: 3 } }],
            effects: { power: 4 },
            flags: ["voz_da_rainha", "negociou_a_coroa"],
            score: 30,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 70, effects: { power: 2 } }
  },
  {
    id: 42,
    lawTitle: L3(42).title,
    lawText: L3(42).insight,
    title: "O Pastor",
    areaId: "conselho",
    giverNpc: "chanceler",
    brief: "A guarni\xE7\xE3o do norte est\xE1 em motim atr\xE1s de um capit\xE3o. Hon\xF3rio quer o motim resolvido. Voc\xEA decide o m\xE9todo.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "chanceler", [
        "A guarni\xE7\xE3o do norte n\xE3o veio para o motim. Veio porque um homem, o Capit\xE3o Bruma, lesou todos.",
        "Mate Bruma e a manada se dispersa. Poupe Bruma e ele leva todos com ele. Qual \xE9 a sua leitura?"
      ], [
        c(
          "Mate-o. Sem pastor, o rebanho se dispersa sozinho.",
          "Hon\xF3rio assente. \u201CDireto. E eu cuido para que a hist\xF3ria seja de um duel, n\xE3o de uma emboscada.\u201D",
          {
            npc: [{ id: "chanceler", deltas: { respect: 8 } }],
            effects: { power: 3, reputation: -2 },
            flags: ["matou_o_pastor"],
            score: 20,
            next: "b"
          }
        ),
        c(
          "N\xE3o mato. Dou a Bruma o que ele quer e o viro pastor meu.",
          "Hon\xF3rio quase cai da cadeira. \u201CVoc\xEA quer comprar o pastor para ter o rebanho. Isso \xE9...\u201D",
          {
            npc: [{ id: "chanceler", deltas: { respect: 9, trust: 3, fear: 3 } }],
            effects: { power: 3, influence: 2 },
            flags: ["comprou_o_pastor"],
            score: 22,
            next: "b"
          }
        ),
        c(
          "Rrego o motim comoublado: promessas de terra e sem sangue.",
          "Hon\xF3rio balan\xE7a a cabe\xE7a. \u201CBelo. Custa caro e n\xE3o resolve a raiz.\u201D",
          {
            npc: [{ id: "chanceler", deltas: { respect: 4 } }],
            effects: { reputation: 3, wealth: -200 },
            flags: ["comprou_o_motim"],
            score: 16,
            next: "b"
          }
        )
      ]),
      b: n("b", "chanceler", [
        "E depois: quando o norte se acalmar, quem fica l\xE1? A pergunta que define quem governa o reino de verdade."
      ], [
        c(
          "Eu fico. Governador do Norte, com o meu nome e a minha gente.",
          "Hon\xF3rio sorri. \u201CAh. O homem que resolve o problema fica com o pr\xEAmio. \xC9 assim que se herda um reino.\u201D",
          {
            npc: [{ id: "chanceler", deltas: { respect: 7, trust: 4 } }],
            effects: { power: 4, influence: 2 },
            flags: ["governador_do_norte"],
            score: 30,
            end: "mission"
          }
        ),
        c(
          "Fica Bruma. E ele me deve a vida, todos os dias.",
          "Hon\xF3rio assente devagar. \u201CUm homem que te deve a vida \xE9 um homem que te obedece. Como voc\xEA pensa.\u201D",
          {
            npc: [{ id: "chanceler", deltas: { respect: 8 } }],
            effects: { power: 3, influence: 1 },
            flags: ["bruma_devendo"],
            score: 28,
            end: "mission"
          }
        ),
        c(
          "Fica o rei. Sem fu, sem pastore: o rei \xE9 o pastor, sempre foi.",
          "Hon\xF3rio te estuda. \u201CS\xE1bio. Mas o rei s\xF3 pode ser pastor se ningu\xE9m souber que o pastor \xE9 uma fiction.\u201D",
          {
            npc: [{ id: "chanceler", deltas: { respect: 6, trust: 2 } }],
            effects: { reputation: 3, power: 1 },
            flags: ["rei_e_o_pastor"],
            score: 22,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 75, effects: { power: 3 } }
  },
  {
    id: 43,
    lawTitle: L3(43).title,
    lawText: L3(43).insight,
    title: "Cora\xE7\xF5es, N\xE3o Cabe\xE7as",
    areaId: "capela",
    giverNpc: "umbelina",
    brief: "Freira Umbelina cuida dos feridos de uma guerra que ningu\xE9m mais lembra. Ela quer que voc\xEA ajude, e por um motivo.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "umbelina", [
        "O hospital est\xE1 cheio de soldados que sobreviveram a uma batalha que o reino j\xE1 esqueceu. Ningu\xE9m os visita.",
        "Quando um homem \xE9 salvo e ningu\xE9m aparece, ele se lembra para sempre. \xC9 assim que se constr\xF3i um ex\xE9rcito sem recrutar ningu\xE9m."
      ], [
        c(
          "Eu os visito. Todos. E levo comida e folhas.",
          "Umbelina sorri. \u201CA mente forget. O cora\xE7\xE3o n\xE3o.\u201D",
          {
            npc: [{ id: "umbelina", deltas: { trust: 8, respect: 6 } }],
            effects: { reputation: 6, wealth: -150 },
            flags: ["heroi_dos_feridos"],
            score: 18,
            next: "b"
          }
        ),
        c(
          "Mando ouro e comida, mas n\xE3o vou. Meu nome n\xE3o pode aparecer em hospital.",
          "Umbelina assente. \u201CSensato. Mas quem n\xE3o aparece tamb\xE9m n\xE3o \xE9 lembrado.\u201D",
          {
            npc: [{ id: "umbelina", deltas: { trust: 3 } }],
            effects: { wealth: -100, reputation: 1 },
            flags: ["doou_sem_aparecer"],
            score: 14,
            next: "b"
          }
        ),
        c(
          "Pergunto por que ela me conta isso. Ningu\xE9m oferece nada sem motivo.",
          "Umbelina sorri de lado. \u201CPorque o Prior me pediu. E porque voc\xEA tem o que eles precisam: cuidado.\u201D",
          { npc: [{ id: "umbelina", deltas: { respect: 6 } }], effects: { intelligence: 2 }, score: 16, next: "b" }
        )
      ]),
      b: n("b", "umbelina", [
        "H\xE1 um soldado que n\xE3o fala com ningu\xE9m. UmCaptain que perdeu tudo. Ele precisa de uma raz\xE3o para voltar a servir."
      ], [
        c(
          "Dou a ele a minha espada e digo que volte quando quiser.",
          "Umbelina fecha os olhos. \u201CO que se d\xE1 em vez de ordem. Isso cria devo\xE7\xE3o.\u201D",
          {
            npc: [{ id: "umbelina", deltas: { trust: 7 } }],
            effects: { power: 3, reputation: 3 },
            flags: ["devocacao_do_soldado"],
            score: 28,
            end: "mission"
          }
        ),
        c(
          "Digo a ele que ele serve a mim, n\xE3o ao rei. Fico com a lealdade dele.",
          "Umbelina te olha de perto. \u201CVoc\xEA n\xE3o quer cora\xE7\xF5es, quer soldados. Isso funciona at\xE9 o dia em que n\xE3o funciona.\u201D",
          {
            npc: [{ id: "umbelina", deltas: { respect: 7, fear: 2 } }],
            effects: { power: 3, influence: 1 },
            flags: ["exercito_proprio"],
            score: 26,
            end: "mission"
          }
        ),
        c(
          "Falo com ele de homem para homem, sobre a dor dele.",
          "Umbelina sorri. \u201CVoc\xEA aprendeu o mais dif\xEDcil. Cora\xE7\xE3o n\xE3o se compra: se conquista.\u201D",
          {
            npc: [{ id: "umbelina", deltas: { trust: 8, respect: 5 } }],
            effects: { reputation: 4, intelligence: 1 },
            flags: ["conversa_no_hospital"],
            score: 26,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 70, effects: { reputation: 3 } }
  },
  {
    id: 44,
    lawTitle: L3(44).title,
    lawText: L3(44).insight,
    title: "O Espelho",
    areaId: "conselho",
    giverNpc: "gaspar",
    brief: "O Chanceler Brant planejou derrubar o Tesoureiro. O plano est\xE1 na sua mesa e voc\xEA pode copi\xE1-lo.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "gaspar", [
        "O chanceler vai me tirar do cargo na pr\xF3xima sess\xE3o. Tenho o plano dele: cartas falsificadas, contas inventadas, um esc\xE2nd\xE3o pequeno.",
        "Posso usar o plano dele contra ele. Ou posso me tornar o espelho dele."
      ], [
        c(
          "Uso o plano dele contra ele. Mesma arma, mesma m\xE3o.",
          "Gaspar sorri. \u201CJusto. Ele meFerrou; eu o ferro.\u201D",
          {
            npc: [{ id: "gaspar", deltas: { trust: 5, fear: 2 } }],
            effects: { power: 2, reputation: -1 },
            flags: ["espelho_agressivo"],
            score: 18,
            next: "b"
          }
        ),
        c(
          "Tiro do plano a pergunta que ele n\xE3o espera: por que agora?",
          "Gaspar empalidece. \u201CVoc\xEA quer que ele serade e se enrede nas pr\xF3prias explica\xE7\xF5es.\u201D",
          {
            npc: [{ id: "gaspar", deltas: { respect: 8 } }],
            effects: { intelligence: 3 },
            flags: ["espelho_neutro"],
            score: 20,
            next: "b"
          }
        ),
        c(
          "Copio o estilo dele: as palavras, o tom, a forma. Falo como ele.",
          "Gaspar te olha como quem olha um espelho quebrado. \u201CIsso \xE9 perigoso. Voc\xEA vai confundi-lo, e talvez a si mesmo.\u201D",
          {
            npc: [{ id: "gaspar", deltas: { respect: 9, fear: 5 } }],
            effects: { power: 3, influence: 2 },
            flags: ["copia_o_chanceler"],
            score: 22,
            next: "b"
          }
        )
      ]),
      b: n("b", "gaspar", [
        "Ele vai perguntar no council: quemare entregou os documentos. Voc\xEA entrega ele mesmo, ou entrega a si mesmo?"
      ], [
        c(
          "Entrego o chanceler. Sem hesitar, sem pensar.",
          "Gaspar fecha os olhos. \u201CPronto. Ele cai. E o pr\xF3ximo rei do conselho senta na cadeira dele.\u201D",
          {
            npc: [{ id: "gaspar", deltas: { trust: 6, respect: 4 } }],
            effects: { power: 3, influence: 1 },
            flags: ["derrubou_o_chanceler"],
            score: 28,
            end: "mission"
          }
        ),
        c(
          "Entrego a mim mesmo. Assumo o roubo e ganho o trono do conselho.",
          "Gaspar empalidece. \u201CCoragem. Ou loucura. Ou a coisa mais esperta de todas.\u201D",
          {
            npc: [{ id: "gaspar", deltas: { respect: 9, trust: 4, fear: 3 } }],
            effects: { power: 4, reputation: 2 },
            flags: ["assumiu_o_roubo"],
            score: 30,
            end: "mission"
          }
        ),
        c(
          "N\xE3o entrego ningu\xE9m. Removo os documentos e deixo os dois se destruindo.",
          "Gaspar sorri de lado. \u201CBrutal. Limpo. E voc\xEA fica com as m\xE3os limpas e a culpa nas delas.\u201D",
          {
            npc: [{ id: "gaspar", deltas: { respect: 7 } }],
            effects: { intelligence: 3, power: 2 },
            flags: ["sem_ninguem"],
            score: 26,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 75, effects: { power: 2 } }
  },
  {
    id: 45,
    lawTitle: L3(45).title,
    lawText: L3(45).insight,
    title: "A Reforma",
    areaId: "capela",
    giverNpc: "prior",
    brief: "O Prior quer um ritual novo na capela: a b\xEAn\xE7\xE3o dos viajantes. \xC9 uma pequena mudan\xE7a que muda a alma do reino.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "prior", [
        "Uma mudan\xE7a pequena: todos os viajantes, ao sair, ser\xE3o aben\xE7oados. Sem mais culto, sem novas leis, sem novos impostos.",
        "Uma vez por semana, a capela enche de gente que n\xE3o \xE9 da corte. E gente que n\xE3o \xE9 da corte fala."
      ], [
        c(
          "Apoio e pe\xE7o que o meu nome seja dito na b\xEAn\xE7\xE3o.",
          "O Prior hesita. \u201CIsso n\xE3o \xE9 uma b\xEAn\xE7\xE3o, \xE9 uma assinatura. Mas... a diferen\xE7a \xE9 pequena.\u201D",
          {
            npc: [{ id: "prior", deltas: { trust: 5, respect: 4 } }],
            effects: { influence: 3, reputation: 3 },
            flags: ["reforma_publica"],
            score: 18,
            next: "b"
          }
        ),
        c(
          "Apoio sem o meu nome. A mudan\xE7a precisa ser da mudan\xE7a, n\xE3o minha.",
          "O Prior sorri. \u201CAh. A reforma mais eficiente \xE9 aquela que ningu\xE9m atribui a ningu\xE9m.\u201D",
          {
            npc: [{ id: "prior", deltas: { trust: 7, respect: 6 } }],
            effects: { reputation: 4, intelligence: 1 },
            flags: ["reforma_an\xF4nima"],
            score: 20,
            next: "b"
          }
        ),
        c(
          "Sugiro algo maior: alterar a missa inteira e abolish o imposto da capela.",
          "O Prior empalidece. \u201CVoc\xEA quer fazer a revolution em um \xFAnico movimento. Isso \xE9 assumido.\u201D",
          {
            npc: [{ id: "prior", deltas: { respect: 8, fear: 3 } }],
            effects: { reputation: 6, power: -2, wealth: -150 },
            flags: ["reforma_radical"],
            score: 22,
            next: "b"
          }
        )
      ]),
      b: n("b", "prior", [
        "A Igreja n\xE3o pode mudar r\xE1pido. A pergunta \xE9: o que voc\xEA muda primeiro?"
      ], [
        c(
          "O ritual vis\xEDvel: a b\xEAn\xE7\xE3o. O invis\xEDvel fica para depois.",
          "O Prior assente. \u201CExato. Mude o gesto, preserve o podre. A Igreja sobrevive a mil anos assim.\u201D",
          {
            npc: [{ id: "prior", deltas: { trust: 7, respect: 6 } }],
            effects: { influence: 2, reputation: 3 },
            flags: ["ritual_visivel"],
            score: 28,
            end: "mission"
          }
        ),
        c(
          "O invis\xEDvel: quem guarda o dinheiro da capela. A alma depois.",
          "O Prior te olha com olhos frios. \u201CCorreto. E ningu\xE9m agradece quem arruma o invis\xEDvel.\u201D",
          {
            npc: [{ id: "prior", deltas: { respect: 8, trust: 4 } }],
            effects: { power: 3, wealth: 200 },
            flags: ["invisivel_primeiro"],
            score: 26,
            end: "mission"
          }
        ),
        c(
          "Nada ainda. Primeiro observo quem ganha com a mudan\xE7a e quem perde.",
          "O Prior sorri. \u201CS\xE1bio. Quem mede o custo antes de mover o bra\xE7o vive mais.\u201D",
          {
            npc: [{ id: "prior", deltas: { respect: 9 } }],
            effects: { intelligence: 3, power: 1 },
            flags: ["esperou_para_medir"],
            score: 26,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 75, effects: { influence: 2 } }
  },
  {
    id: 46,
    lawTitle: L3(46).title,
    lawText: L3(46).insight,
    title: "A Falha",
    areaId: "taverna",
    giverNpc: "taveiro",
    brief: "A corte acredita que voc\xEA \xE9 infal\xEDvel. Isso \xE9 perigoso: a perfei\xE7\xE3o gera inveja. O ca\xE7ador sugere uma falha.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "taveiro", [
        "Voc\xEA nunca errou na frente de ningu\xE9m. Eu vi a corte cochichar sobre isso. Inveja cochichada vira conspira\xE7\xE3o.",
        "Um homem perfeito \xE9 um homem sem defeito. E sem defeito, sem desculpa."
      ], [
        c(
          "Que boato escolho: uma d\xEDvida, uma fofoca, uma mentira?",
          "O ca\xE7ador sorri. \u201CEu escolheria a mentira. Ningu\xE9m perdoa uma mentira: a gente perdoa um erro.\u201D",
          { npc: [{ id: "taveiro", deltas: { respect: 6 } }], effects: { intelligence: 2 }, score: 16, next: "b" }
        ),
        c(
          "Que erro cometemos juntos e deixamos correr. Um erro de verdade.",
          "O ca\xE7ador assente. \u201CMelhor. Um erro que voc\xEA n\xE3o esconde parece escolha, e n\xE3o fraqueza.\u201D",
          { npc: [{ id: "taveiro", deltas: { respect: 7 } }], effects: { reputation: 2 }, score: 18, next: "b" }
        ),
        c(
          "N\xE3o preciso de falha. Sigo infal\xEDvel.",
          "O ca\xE7ador balan\xE7a a cabe\xE7a. \u201CPerfeito. E quando cair, vai ser de uma vez, de muito alto.\u201D",
          {
            npc: [{ id: "taveiro", deltas: { respect: 2, fear: 1 } }],
            effects: { power: 2, reputation: -1 },
            flags: ["perfeito"],
            score: 12,
            next: "b"
          }
        )
      ]),
      b: n("b", "taveiro", [
        "E a quem voc\xEA conta a falha? S\xF3 a quem precisa saber, ou a todos?"
      ], [
        c(
          "Conto a todos, primeiro, antes que inventem uma pior.",
          "O ca\xE7ador bate palma. \u201CExcelente! Quem conta a pr\xF3pria falha escolhe a vers\xE3o dela.\u201D",
          {
            npc: [{ id: "taveiro", deltas: { respect: 7 } }],
            effects: { reputation: 4, power: 1 },
            flags: ["falha_publica"],
            score: 28,
            end: "mission"
          }
        ),
        c(
          "Conto a um s\xF3: o rei. Uma falha conhecida pelo rei \xE9 uma lealdade comprada.",
          "O ca\xE7ador assente. \u201CAh. Voc\xEA compra prote\xE7\xE3o com a pr\xF3pria fraqueza. POUCO de n\xF3s pensa nisso.\u201D",
          {
            npc: [{ id: "taveiro", deltas: { respect: 6 } }],
            effects: { power: 2, influence: 2 },
            flags: ["falha_ao_rei"],
            score: 26,
            end: "mission"
          }
        ),
        c(
          "N\xE3o conto a ningu\xE9m. A falha fica comigo.",
          "O ca\xE7ador te olha. \u201CSegredo guardado \xE9 d\xEDvida guardada. Um dia cobra juros.\u201D",
          {
            npc: [{ id: "taveiro", deltas: { respect: 5 } }],
            effects: { intelligence: 2 },
            flags: ["falha_secreta"],
            score: 24,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 75, effects: { reputation: 2 } }
  },
  {
    id: 47,
    lawTitle: L3(47).title,
    lawText: L3(47).insight,
    title: "Onde Parar",
    areaId: "salao",
    giverNpc: "otavio",
    brief: "O Bar\xE3o Ot\xE1vio venceu. Ele est\xE1 b\xEAbado de gl\xF3ria e quer vingar mais uma vez. Voc\xEA precisa mostrar a linha que n\xE3o se atravessa.",
    steps: [{ kind: "dialogue", node: "a" }, { kind: "dialogue", node: "b" }],
    nodes: {
      a: n("a", "otavio", [
        "Venci! E a corte quer que eu continue. Mais uma: derrubar o Chanceler, humilhar o Duque, tomar o celeiro.",
        "Voc\xEA \xE9 o \xFAnico que me diz a verdade. Ent\xE3o diga: d\xE1 para ir mais longe?"
      ], [
        c(
          "D\xE1. Mas apenas mais longe: o celeiro, e s\xF3. O resto \xE9 gan\xE2ncia.",
          "Ot\xE1vio abre a boca, fecha, abre de novo. \u201C...Justo. Eu queria ouvir isso de algu\xE9m.\u201D",
          {
            npc: [{ id: "otavio", deltas: { trust: 8, respect: 6 } }],
            effects: { power: 2, intelligence: 2 },
            flags: ["sabia_onde_parar"],
            score: 18,
            next: "b"
          }
        ),
        c(
          "N\xE3o d\xE1. Voc\xEA j\xE1 ganhou. Quem ganha demais est\xE1 pronto para a vingan\xE7a.",
          "Ot\xE1vio empalidece. \u201CEu... ...Justo. Maldita seja, voc\xEA tem raz\xE3o.\u201D",
          {
            npc: [{ id: "otavio", deltas: { trust: 6, loyalty: 4 } }],
            effects: { reputation: 3 },
            flags: ["sabia_onde_parar"],
            score: 20,
            next: "b"
          }
        ),
        c(
          "D\xE1, e eu vou junto. Quem para junto nunca fica para tr\xE1s.",
          "Ot\xE1vio bate na mesa. \u201CEnt\xE3o vamos juntos! Duas ambi\xE7\xF5es, uma festa.\u201D",
          {
            npc: [{ id: "otavio", deltas: { respect: 6, trust: 4 } }],
            effects: { power: 3, reputation: -1 },
            flags: ["sempre_mais"],
            score: 16,
            next: "b"
          }
        )
      ]),
      b: n("b", "otavio", [
        "E o celeiro? Voc\xEA o toma para si, ou para ele?"
      ], [
        c(
          "Para o rei. E eu fico com a ger\xEAncia. Poder sem propriedade.",
          "Ot\xE1vio franze a testa. \u201CIsso \xE9... justo. E chato. Mas eu j\xE1 tenho ouro demais.\u201D",
          {
            npc: [{ id: "otavio", deltas: { trust: 5 } }],
            effects: { power: 3, influence: 2, wealth: 150 },
            flags: ["gerente_do_celeiro"],
            score: 28,
            end: "mission"
          }
        ),
        c(
          "Para ele. E eu fico com a lealdade dele. Um por um; um celeiro.",
          "Ot\xE1vio sorri. \u201CAh, voc\xEA \xE9 o pastor e ele \xE9 o carneiro. Eu conhe\xE7o esse jogo.\u201D",
          {
            npc: [{ id: "otavio", deltas: { trust: 7, loyalty: 5 } }],
            effects: { influence: 3, power: 2 },
            flags: ["lealdade_do_bar\xE3o"],
            score: 28,
            end: "mission"
          }
        ),
        c(
          "Para mim. Sem discuss\xE3o. Eu fui quem mandou parar.",
          "Ot\xE1vio engole seco. \u201CEu... claro. Sim. Obviamente.\u201D",
          {
            npc: [{ id: "otavio", deltas: { trust: 3, fear: 4 } }],
            effects: { power: 3, wealth: 200, reputation: -2 },
            flags: ["tomou_o_celeiro"],
            score: 26,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 80, effects: { power: 2 } }
  },
  {
    id: 48,
    lawTitle: L3(48).title,
    lawText: L3(48).insight,
    title: "A \xDAltima Pe\xE7a",
    areaId: "trono",
    giverNpc: "rei",
    brief: "O rei est\xE1 morrendo. A corte se divide. O velho}={ o \xFAltimo golpe n\xE3o \xE9 um golpe: \xE9 a forma como o reino vai lembrar de voc\xEA.",
    steps: [
      { kind: "dialogue", node: "a" },
      { kind: "dialogue", node: "b" },
      { kind: "dialogue", node: "c" },
      { kind: "dialogue", node: "d" }
    ],
    nodes: {
      a: n("a", "rei", [
        "Chegou o fim, e eu sei. Tr\xEAs candidatos ouviram o que vou dizer, e nenhum deles \xE9 digno do que eu carreguei.",
        "Quero ouvir voc\xEA. N\xE3o como cortes\xE3o. Como o homem que subiu da vila de Cinzas sem nunca pedir para ser rei."
      ], [
        c(
          "Falo com a verdade nua, sem enfeite de flores.",
          "O Rei se endireita. \u201CAssim se fala a um homem que vai morrer. N\xE3o me fa\xE7a perder o pouco tempo que me resta.\u201D",
          {
            npc: [{ id: "rei", deltas: { trust: 8, respect: 6 } }],
            effects: { reputation: 3, intelligence: 2 },
            flags: ["verdade_nua"],
            score: 20,
            next: "b"
          }
        ),
        c(
          "Falo com a linguagem do rei: prometo um reino forte e pr\xF3spero.",
          "O Rei balan\xE7a a cabe\xE7a. \u201CBonito. E vazio. Mas \xE9 o que se espera de voc\xEA.\u201D",
          {
            npc: [{ id: "rei", deltas: { respect: 3, trust: -2 } }],
            effects: { reputation: 1 },
            flags: ["discurso_de_rei"],
            score: 14,
            next: "b"
          }
        ),
        c(
          "Pergunto o que ele realmente quer ouvir antes de responder.",
          "O Rei sorri fraco. \u201CAprendeu com o bobos. Eu quero ouvir o que voc\xEA n\xE3o vai dizer.\u201D",
          {
            npc: [{ id: "rei", deltas: { respect: 8, trust: 5 } }],
            effects: { intelligence: 3, influence: 1 },
            flags: ["perguntou_o_rei"],
            score: 22,
            next: "b"
          }
        )
      ]),
      b: n("b", "rei", [
        "O reino tem uma ferida aberta: o selo real. Quem guarda o selo decide o que o rei pode fazer. Ningu\xE9m sabe onde est\xE1.",
        "Pergunta: se voc\xEA encontrasse o selo, o que faria com ele?"
      ], [
        c(
          "Devolvo ao rei. Sem SELO, um homem \xE9 s\xF3 um homem.",
          "O Rei fecha os olhos. \u201CMuito bem. Voc\xEA \xE9 mais honesto do que eu fui.\u201D",
          {
            npc: [{ id: "rei", deltas: { trust: 9, loyalty: 6 } }],
            effects: { reputation: 4, influence: 1 },
            flags: ["devolveu_o_selo"],
            score: 26,
            next: "c"
          }
        ),
        c(
          "Fico com ele. N\xE3o para roubar: para nunca mais ser controlado por um papel.",
          "O Rei ri baixo. \u201CAh. O poder sem dono. Voc\xEA pensa como eu pensava aos trinta.\u201D",
          {
            npc: [{ id: "rei", deltas: { trust: 6, respect: 6 } }],
            effects: { power: 4, intelligence: 2 },
            flags: ["guardou_o_selo"],
            score: 28,
            next: "c"
          }
        ),
        c(
          "Uso o selo para coroar quem eu escolher. \xC9 a \xFAnica forma de acabar com a disputa.",
          "O Rei fica im\xF3vel. \u201CVoc\xEA acabou de dizer que quer ser rei. E ainda tem a coragem de dizer olhando na minha cara.\u201D",
          {
            npc: [{ id: "rei", deltas: { respect: 9, trust: 4, fear: 3 } }],
            effects: { power: 4, influence: 2 },
            flags: ["usou_o_selo"],
            score: 30,
            next: "c"
          }
        )
      ]),
      c: n("c", "rei", [
        "\xDAltima pergunta, e \xE9 a mais dif\xEDcil: o que voc\xEA quer ser lembrado como?"
      ], [
        c(
          "Como o homem que deu paz ao povo, mesmo que a corte o chame de traidor.",
          "O Rei te segura a m\xE3o. \u201CPaz. Then you are the king I never was.\u201D",
          {
            npc: [{ id: "rei", deltas: { trust: 8, loyalty: 5 } }],
            effects: { reputation: 6, power: 1 },
            flags: ["lembrado_como_paz"],
            score: 28,
            next: "d"
          }
        ),
        c(
          "Como o homem que venceu. Sem adjetivos, sem escr\xFApulos.",
          "O Rei assente devagar. \u201CVencer. Bem. Half of history remembers that word.\u201D",
          {
            npc: [{ id: "rei", deltas: { respect: 8, trust: 3 } }],
            effects: { power: 3, influence: 2 },
            flags: ["lembrado_como_vitorioso"],
            score: 28,
            next: "d"
          }
        ),
        c(
          "Como o homem que nunca quis o trono e acabou nele.",
          "O Rei ri e a tosse toma conta. \u201CMentira. Mas \xE9 a melhor mentira que um homem pode morrer dizendo.\u201D",
          {
            npc: [{ id: "rei", deltas: { respect: 7, trust: 4 } }],
            effects: { influence: 3, reputation: 2 },
            flags: ["lembrado_como_humilde"],
            score: 26,
            next: "d"
          }
        )
      ]),
      d: n("d", "rei", [
        "Chegou a hora. H\xE1 quatro caminhos diante de voc\xEA, e o reino vai contar apenas um deles."
      ], [
        c(
          "Tomo a coroa. O reino precisa de uma m\xE3o, e ser\xE1 a minha.",
          "O Rei coloca a coroa na sua m\xE3o. \u201CEnt\xE3o seja rei. E lembre-se: um rei que s\xF3 sabe governar com medo morre pobre.\u201D",
          {
            npc: [{ id: "rei", deltas: { trust: 7, loyalty: 8, respect: 9 } }],
            effects: { power: 6, influence: 5, reputation: 2 },
            flags: ["coroado"],
            score: 60,
            end: "mission"
          }
        ),
        c(
          "Fico ao lado do trono. O rei ser\xE1 meu filho, e a corte minha.",
          "O Rei assente. \u201CUm rei de m\xE1rmore e um rei de verdade. A hist\xF3ria vai me odiar por isso.\u201D",
          {
            npc: [{ id: "rei", deltas: { trust: 6, loyalty: 6, respect: 8 } }],
            effects: { power: 5, influence: 5, wealth: 200 },
            flags: ["poder_atras"],
            score: 55,
            end: "mission"
          }
        ),
        c(
          "Pe\xE7o o luxo de uma casa forte, com terra e gente. Quero um sun Ref\xFAgio.",
          "O Rei suspira. \u201CVoc\xEA n\xE3o quer o reino. Quer um bom lugar nele. Isso... tamb\xE9m \xE9 uma forma de poder.\u201D",
          {
            npc: [{ id: "rei", deltas: { respect: 7, trust: 4 } }],
            effects: { wealth: 500, reputation: 3, power: 2 },
            flags: ["nobre_rico"],
            score: 50,
            end: "mission"
          }
        ),
        c(
          "Renuncio. Levo o que posso e saio do reino antes que me encontrem.",
          'O Rei fecha os olhos. \u201CWisest or the coward. Talvez os dois." Ele aperta sua m\xE3o uma \xFAltima vez.',
          {
            npc: [{ id: "rei", deltas: { respect: 6, trust: 5 } }],
            effects: { wealth: 300, reputation: -4, power: -2 },
            flags: ["renunciou"],
            score: 45,
            end: "mission"
          }
        )
      ])
    },
    reward: { score: 120, effects: { influence: 3, power: 3 } }
  }
];

// src/game/data/missions.ts
var MISSIONS = [...MISSIONS_A, ...MISSIONS_B, ...MISSIONS_C].sort(
  (a, b) => a.id - b.id
);
var TOTAL_MISSIONS = MISSIONS.length;

// src/game/data/npcs.ts
var s = (trust, respect, fear, loyalty, ambition) => ({ trust, respect, fear, loyalty, ambition });
var NPCS = [
  {
    id: "rei",
    name: "Rei Aldredo IV",
    title: "O Rei",
    role: "Soberano de Valdemar",
    areaId: "trono",
    x: 14,
    y: 8,
    palette: { skin: "#e3b083", hair: "#d8d2c4", cloth: "#7a1f2b", accent: "#f0c14b" },
    crown: true,
    bio: "Sobe ao trono aos 42 anos, herdeiro tardio de pai en\xE9rgico. Governa por medo e por necessidade, mas tem fraqueza: odeia parecer fraco.",
    initial: s(5, 40, 55, 60, 30)
  },
  {
    id: "rainha",
    name: "Rainha Clem\xEAncia",
    title: "A Rainha",
    role: "Consorte do Rei Aldredo",
    areaId: "trono",
    x: 8,
    y: 11,
    palette: { skin: "#e8c39e", hair: "#5c3a22", cloth: "#4a2c6b", accent: "#e9d5a0" },
    crown: true,
    bio: "Mais afiada que o|Junco do conselho. Mede o valor de cada nobre em minutos e cobra caro o desrespeito.",
    initial: s(8, 45, 40, 45, 55)
  },
  {
    id: "chanceler",
    name: "Chanceler Hon\xF3rio",
    title: "O Chanceler",
    role: "Chefe da Chancellaria",
    areaId: "conselho",
    x: 9,
    y: 8,
    palette: { skin: "#d9a877", hair: "#2f2a33", cloth: "#2b3a58", accent: "#c0c8d8" },
    bio: "Trinta anos servindo a coroa. Sabe onde cada corpo est\xE1 enterrado e cobra por isso.",
    initial: s(15, 55, 30, 55, 70)
  },
  {
    id: "condestavel",
    name: "Condest\xE1vel Martim",
    title: "O Condest\xE1vel",
    role: "Comandante das Armas",
    areaId: "castelo",
    x: 22,
    y: 15,
    palette: { skin: "#c98f63", hair: "#4b3323", cloth: "#5a5f6b", accent: "#b23a3a" },
    bio: "Guerreiro devoto e medroso de pol\xEDtica. Odeia intrigas mas obedece quem segura o celeiro.",
    initial: s(20, 50, 25, 70, 35)
  },
  {
    id: "capitao",
    name: "Capit\xE3o Dami\xE3o",
    title: "Capit\xE3o da Muralha",
    role: "Guarda das Portas",
    areaId: "muralha",
    x: 16,
    y: 11,
    palette: { skin: "#b9825a", hair: "#1f1b18", cloth: "#3b4b62", accent: "#9aa6b8" },
    bio: "Ex-mercenario. Vende informa\xE7\xE3o e lealdade ao pre\xE7o mais alto, mas nunca trai quem pagou antes.",
    initial: s(10, 35, 40, 40, 50)
  },
  {
    id: "prior",
    name: "Prior Sisenando",
    title: "O Prior",
    role: "Guardi\xE3o da Capela da Coroa",
    areaId: "capela",
    x: 11,
    y: 9,
    palette: { skin: "#e0c3a2", hair: "#c8c8c8", cloth: "#d8d2c0", accent: "#8f7a4a" },
    bio: "Sabe o que foi enterrado sob a capela e por quem. Fala pouco porque ouve demais.",
    initial: s(20, 45, 20, 50, 25)
  },
  {
    id: "valdessa",
    name: "Condessa Valdessa",
    title: "A Condessa",
    role: "Vi\xFAva do Solar de Valdessa",
    areaId: "solar",
    x: 12,
    y: 9,
    palette: { skin: "#e6bd97", hair: "#3a2417", cloth: "#7b2f6b", accent: "#d9b3ff" },
    bio: "A mulher mais ambiciosa do reino. Compra lealdades com ouro e guarda rancor com uma precision de relojoeiro.",
    initial: s(5, 40, 35, 20, 90)
  },
  {
    id: "otavio",
    name: "Bar\xE3o Ot\xE1vio",
    title: "O Bar\xE3o",
    role: "Jovem da Casa de Ornel",
    areaId: "salao",
    x: 16,
    y: 12,
    palette: { skin: "#efc49b", hair: "#c9a227", cloth: "#c26a2c", accent: "#f3d18a" },
    bio: "Jovem, rico e irritantemente frank. Serve de isca perfeita para quem precisa de um erro alheio.",
    initial: s(25, 30, 10, 35, 65)
  },
  {
    id: "gaspar",
    name: "Tesoureiro Gaspar",
    title: "O Tesoureiro",
    role: "Guarda o Cofre Real",
    areaId: "conselho",
    x: 18,
    y: 10,
    palette: { skin: "#d5a375", hair: "#6b6b6b", cloth: "#3d6b4f", accent: "#d4b45a" },
    bio: "Conta at\xE9 os Brokers. Vende d\xEDvidas em sil\xEAncio e anota tudo num ledger.",
    initial: s(12, 40, 25, 50, 45)
  },
  {
    id: "aurelio",
    name: "Escrib\xE3o Aur\xE9lio",
    title: "O Escrib\xE3o",
    role: "Guarda os Registros da Coroa",
    areaId: "conselho",
    x: 13,
    y: 14,
    palette: { skin: "#e2c09a", hair: "#4a3b2a", cloth: "#6b4f7a", accent: "#e0d0b0" },
    hood: true,
    bio: "Anota tudo e esquece de prop\xF3sito. A mem\xF3ria dele \xE9 uma arma que s\xF3 dispara por pagamento.",
    initial: s(18, 30, 15, 40, 40)
  },
  {
    id: "vesper",
    name: "Vesp\xE9r",
    title: "O Olho do Corvo",
    role: "Mestre dos Espi\xF5es",
    areaId: "corvo",
    x: 10,
    y: 8,
    palette: { skin: "#b9a99a", hair: "#1a1a1a", cloth: "#23222b", accent: "#7f7fd0" },
    hood: true,
    bio: "Trabalha para o rei, mas mede a pr\xF3pria sombra. Serve a quem pagar melhor \u2014 e cobra caro.",
    initial: s(0, 45, 60, 15, 85)
  },
  {
    id: "bruma",
    name: "Feiticeira Bruma",
    title: "A Feiticeira",
    role: "Herbanista do Bosque",
    areaId: "bosque",
    x: 32,
    y: 23,
    palette: { skin: "#cfb6a8", hair: "#5d5d6e", cloth: "#4a5b3a", accent: "#9fd08a" },
    hood: true,
    bio: "Sabe o que as pessoas dizem antes de dizerem. Nunca mente, mas escolhe qual verdade vender.",
    initial: s(5, 30, 45, 30, 60)
  },
  {
    id: "nilo",
    name: "Capit\xE3o Nilo",
    title: "O Contrabandista",
    role: "Mestre do Cais",
    areaId: "porto",
    x: 25,
    y: 16,
    palette: { skin: "#c08155", hair: "#2a2620", cloth: "#2e5a52", accent: "#c9a45a" },
    bio: "Controla o que entra e o que sai de Valdemar. A lealdade dele \xE9 comprada por carga.",
    initial: s(10, 35, 30, 35, 70)
  },
  {
    id: "taveiro",
    name: "Ca\xE7ador Taveiro",
    title: "O Ca\xE7ador",
    role: "Guarda da Floresta Real",
    areaId: "taverna",
    x: 8,
    y: 12,
    palette: { skin: "#d29a6c", hair: "#6b4a2a", cloth: "#55603a", accent: "#b08a4a" },
    bio: "Ca\xE7a e fofoca. Sabe o que sai da corte antes do mensageiro.",
    initial: s(25, 25, 5, 40, 30)
  },
  {
    id: "silvino",
    name: "Cego Silvino",
    title: "O Mendigo",
    role: "Voz da Pra\xE7a",
    areaId: "muralha",
    x: 6,
    y: 16,
    palette: { skin: "#c39a74", hair: "#9a9a9a", cloth: "#8a7f5f", accent: "#d6c98f" },
    hood: true,
    bio: "Vende informa\xE7\xE3o por moedas e reza por reis. Ouviu mais segredos do que qualquer escriba.",
    initial: s(15, 15, 10, 30, 25)
  },
  {
    id: "pardal",
    name: "Mercador Pardal",
    title: "O Mercador",
    role: "Dono das Bancas",
    areaId: "mercado",
    x: 18,
    y: 13,
    palette: { skin: "#e8bd8f", hair: "#3b2f22", cloth: "#8a6b3c", accent: "#d9a45a" },
    bio: "Fala pouco e vende caro. Financia quem est\xE1 subindo e abandona quem est\xE1 caindo.",
    initial: s(15, 40, 10, 45, 55)
  },
  {
    id: "vargo",
    name: "Sargento Vargo",
    title: "O Sargento",
    role: "Comanda o Port\xE3o Norte",
    areaId: "muralha",
    x: 23,
    y: 15,
    palette: { skin: "#bd8a5e", hair: "#3f3f3f", cloth: "#4b4f5c", accent: "#8d99ab" },
    bio: "Duro com soldados, mole com subornos. Odeia o Chanceler e n\xE3o esconde isso.",
    initial: s(10, 35, 30, 55, 35)
  },
  {
    id: "fantasma",
    name: "O Apaixonado Sem Nome",
    title: "O Espectro",
    role: "Habita a Cripta",
    areaId: "cripta",
    x: 12,
    y: 9,
    palette: { skin: "#9fb6c9", hair: "#5a6c80", cloth: "#48566b", accent: "#a9d0e8" },
    hood: true,
    bio: "Morreu por causa de um segredo de amor na corte. Ainda guarda a parte que falta.",
    initial: s(30, 35, 20, 50, 20)
  },
  {
    id: "leonor",
    name: "Aia Leonor",
    title: "Aia da Rainha",
    role: "Confidente de Clem\xEAncia",
    areaId: "capela",
    x: 7,
    y: 14,
    palette: { skin: "#f0d0b0", hair: "#a06a2c", cloth: "#9a6bb0", accent: "#f0e0c0" },
    bio: "Chega primeiro, sai por \xFAltimo. Vende lealdade \xE0 Rainha e informa\xE7\xF5es a quem pagar melhor.",
    initial: s(10, 35, 20, 60, 60)
  },
  {
    id: "aldric",
    name: "Cavaleiro Aldric",
    title: "O Desertor",
    role: "Sem bandeira",
    areaId: "ponte",
    x: 21,
    y: 14,
    palette: { skin: "#d29c70", hair: "#a08858", cloth: "#5b5b66", accent: "#a03030" },
    bio: "Largou a armadura real na noite do golpe. Carrega um segredo que ningu\xE9m quis ouvir.",
    initial: s(20, 30, 20, 25, 35)
  },
  {
    id: "bruna",
    name: "Mestra Fornalha Bruna",
    title: "A Mestra da Fornalha",
    role: "Forja e Fumo",
    areaId: "fornalha",
    x: 12,
    y: 10,
    palette: { skin: "#b07a52", hair: "#1c1a18", cloth: "#6b3a24", accent: "#e07a2a" },
    bio: "Funde o metal do rei e ouve tudo que se diz ao p\xE9 da bigorna.",
    initial: s(20, 45, 20, 60, 35)
  },
  {
    id: "duque",
    name: "Duque Oldric",
    title: "O Duque",
    role: "Chefe da Casa de Oldric",
    areaId: "solar",
    x: 21,
    y: 16,
    palette: { skin: "#e3bd94", hair: "#8d8d96", cloth: "#3c3a6b", accent: "#c8b46a" },
    bio: "Poderio e\u8870\u8001. Simula a velhice para esconder a l\xE2mina, e trata a pr\xF3pria hija como arma.",
    initial: s(5, 50, 40, 30, 75)
  },
  {
    id: "arras",
    name: "Coletor Arras",
    title: "O Coletor de Impostos",
    role: "Cobra o povo",
    areaId: "mercado",
    x: 9,
    y: 19,
    palette: { skin: "#d6a878", hair: "#57503f", cloth: "#5c4a2e", accent: "#a8b04a" },
    bio: "Odiado pelo povo, \xFAtil pela coroa. Sabe quem foge de impostos e por qu\xEA.",
    initial: s(10, 20, 25, 55, 35)
  },
  {
    id: "umbelina",
    name: "Freira Umbelina",
    title: "A Freira",
    role: "Guardi\xE3 do Hospital",
    areaId: "capela",
    x: 16,
    y: 13,
    palette: { skin: "#d9b48f", hair: "#4a4a4a", cloth: "#9a9a92", accent: "#e6e0d0" },
    hood: true,
    bio: "Cura feridos e guarda segredos de partos. Ningu\xE9m suspeita dela; \xE9 por isso que ela sabe de tudo.",
    initial: s(25, 40, 5, 55, 25)
  },
  {
    id: "ismael",
    name: "Trovador Ismael",
    title: "O Trovador",
    role: "Voz da Corte",
    areaId: "salao",
    x: 9,
    y: 13,
    palette: { skin: "#c98f63", hair: "#2b1f18", cloth: "#7a3f7a", accent: "#e8c46a" },
    hood: true,
    bio: "Canta o que a corte quer ouvir. Uma estrofe errada muda o humor de um rei.",
    initial: s(30, 30, 10, 40, 45)
  },
  {
    id: "sereno",
    name: "Bobo Sereno",
    title: "O Bobo",
    role: "Brinca e Escuta",
    areaId: "trono",
    x: 22,
    y: 15,
    palette: { skin: "#e5bd94", hair: "#c4442a", cloth: "#b4403a", accent: "#f0d060" },
    bio: "Ningu\xE9m leva a s\xE9rio um tolo \u2014 por isso ele ouve tudo e \xE9 ouvido por todos.",
    initial: s(30, 20, 5, 45, 30)
  },
  {
    id: "tao",
    name: "Mestre Ti\xE3o",
    title: "O Ferreiro",
    role: "Forja armas na Vila",
    areaId: "vila",
    x: 9,
    y: 12,
    palette: { skin: "#c1814f", hair: "#4a3020", cloth: "#6a4a30", accent: "#b08040" },
    bio: "Forja a espada do rei e ouve os boatos da vila antes de virarem rumor na corte.",
    initial: s(20, 30, 5, 45, 30)
  },
  {
    id: "perpetua",
    name: "Dona Perp\xE9tua",
    title: "A Taverneira",
    role: "Dona da Taverna do Corvo",
    areaId: "vila",
    x: 20,
    y: 18,
    palette: { skin: "#e0ac79", hair: "#7a4a2a", cloth: "#8c3b4a", accent: "#e0c070" },
    bio: "A taverna \xE9 a parliament da vila. Quem bebe nela perde a guarda e ganha a hist\xF3ria.",
    initial: s(20, 25, 5, 50, 35)
  },
  {
    id: "ludovina",
    name: "Ludovina, a Vi\xFAva",
    title: "A Vi\xFAva",
    role: "Espia os boatos do bairro",
    areaId: "vila",
    x: 15,
    y: 7,
    palette: { skin: "#e5c4a2", hair: "#8e8e9e", cloth: "#4a4458", accent: "#b9a6d0" },
    hood: true,
    bio: "Enxerga tudo do seu janel\xE3o e cobra barato pelas boas not\xEDcias.",
    initial: s(15, 25, 10, 40, 35)
  },
  {
    id: "tav",
    name: "Tav, o Tropeiro",
    title: "O Tropeiro",
    role: "Corre o reino",
    areaId: "taverna",
    x: 16,
    y: 11,
    palette: { skin: "#c78e60", hair: "#5a4a3a", cloth: "#7a6a4a", accent: "#c0a060" },
    bio: "Conhece todas as estradas e todos os segredos que passam por elas.",
    initial: s(20, 25, 10, 35, 40)
  },
  {
    id: "godiva",
    name: "Godiva",
    title: "A Espi\xE3 de Taverna",
    role: "Vende novidades",
    areaId: "taverna",
    x: 21,
    y: 15,
    palette: { skin: "#e8c0a0", hair: "#5a2a4a", cloth: "#8a2a5a", accent: "#e0a0c0" },
    bio: "Dormiu com tr\xEAs condes e fugiu com o Corvo. Nunca mente, apenas cobra.",
    initial: s(5, 30, 25, 25, 70)
  }
];

// src/game/data/areas.ts
var T = {
  GRASS: 1,
  DIRT: 2,
  STONE: 3,
  WOOD: 4,
  WATER: 5,
  CARPET: 6,
  MARBLE: 7,
  ROAD: 8,
  MOSS: 9,
  DARK: 10,
  SAND: 11,
  GRAVE: 12,
  CRYPT: 13,
  WALL_STONE: 20,
  WALL_WOOD: 21,
  HEDGE: 22,
  TREE: 23,
  ROCK: 24,
  BLOCK: 25
};
var A = (id, name, subtitle, w, h, ground, alt, dark, border, map, music) => ({
  id,
  name,
  subtitle,
  w,
  h,
  ground,
  alt,
  dark,
  border,
  map,
  music,
  floors: [],
  walls: [],
  scatter: [],
  props: [],
  lights: [],
  npcs: [],
  items: []
});
var r = (x, y, w, h, t) => ({ x, y, w, h, t });
var AREA_DEFS = [
  A(
    "vila",
    "Vila de Cinzas",
    "Onde todo ged comeca",
    40,
    30,
    T.GRASS,
    T.DIRT,
    0.12,
    "tree",
    { x: 28, y: 60 },
    "village"
  ),
  A(
    "mercado",
    "Mercado de Pedra",
    "A voz alta da cidade",
    36,
    26,
    T.ROAD,
    T.DIRT,
    0.08,
    "stone",
    { x: 46, y: 56 },
    "town"
  ),
  A(
    "taverna",
    "Taverna do Corvo",
    "Todo segredo tem mesa",
    26,
    20,
    T.WOOD,
    T.DARK,
    0.42,
    "wood",
    { x: 52, y: 70 },
    "tavern"
  ),
  A(
    "ponte",
    "Ponte das Almas",
    "O rio separa o povo do poder",
    30,
    22,
    T.DIRT,
    T.GRASS,
    0.1,
    "tree",
    { x: 16, y: 52 },
    "wild"
  ),
  A(
    "castelo",
    "Castelo Real",
    "Pedra que sussurra ordens",
    40,
    28,
    T.STONE,
    T.DIRT,
    0.14,
    "stone",
    { x: 60, y: 32 },
    "castle"
  ),
  A(
    "trono",
    "Sal\xE3o do Trono",
    "Onde o olhar pesa mais que a espada",
    28,
    20,
    T.MARBLE,
    T.CARPET,
    0.18,
    "stone",
    { x: 62, y: 20 },
    "castle"
  ),
  A(
    "conselho",
    "C\xE2mara do Conselho",
    "Onde os documentos vencem batalhas",
    26,
    18,
    T.DARK,
    T.WOOD,
    0.3,
    "stone",
    { x: 76, y: 32 },
    "castle"
  ),
  A(
    "capela",
    "Capela da Coroa",
    "Luz alta e vontade baixa",
    22,
    18,
    T.MARBLE,
    T.CARPET,
    0.16,
    "stone",
    { x: 46, y: 28 },
    "castle"
  ),
  A(
    "cripta",
    "Cripta Sombria",
    "Os mortos tambem tem segredos",
    24,
    18,
    T.CRYPT,
    T.DARK,
    0.72,
    "stone",
    { x: 44, y: 16 },
    "crypt"
  ),
  A(
    "bosque",
    "Bosque Cin\xE9rea",
    "Onde o bosque escuta",
    42,
    32,
    T.MOSS,
    T.GRASS,
    0.22,
    "tree",
    { x: 18, y: 80 },
    "wild"
  ),
  A(
    "torre",
    "Torre do Sino",
    "Vigia a distancia e a mesagem",
    20,
    20,
    T.STONE,
    T.DARK,
    0.34,
    "stone",
    { x: 76, y: 48 },
    "castle"
  ),
  A(
    "muralha",
    "Muralha Norte",
    "A fronteira entre o reino e o mundo",
    30,
    22,
    T.STONE,
    T.DIRT,
    0.2,
    "stone",
    { x: 86, y: 58 },
    "castle"
  ),
  A(
    "cemiterio",
    "Cemit\xE9rio das Cinzas",
    "A cidade de baixo",
    30,
    24,
    T.GRAVE,
    T.GRASS,
    0.28,
    "hedge",
    { x: 30, y: 38 },
    "wild"
  ),
  A(
    "porto",
    "Cais do Rio",
    "O reino se compra e se vende",
    36,
    24,
    T.WOOD,
    T.WATER,
    0.12,
    "water",
    { x: 8, y: 36 },
    "water"
  ),
  A(
    "fornalha",
    "Fornalha da Cidade",
    "Onde o ferro lembra quem mandou",
    24,
    18,
    T.DARK,
    T.STONE,
    0.38,
    "stone",
    { x: 10, y: 64 },
    "town"
  ),
  A(
    "solar",
    "Solar de Valdessa",
    "Fortuna que nao dorme",
    30,
    22,
    T.MARBLE,
    T.CARPET,
    0.15,
    "stone",
    { x: 88, y: 24 },
    "castle"
  ),
  A(
    "corvo",
    "Casa do Corvo",
    "O preco da verdade",
    20,
    16,
    T.DARK,
    T.WOOD,
    0.62,
    "wood",
    { x: 94, y: 42 },
    "crypt"
  ),
  A(
    "salao",
    "Sal\xE3o dos Banquetes",
    "Dan\xE7as, brindes e agora s",
    28,
    20,
    T.WOOD,
    T.CARPET,
    0.2,
    "stone",
    { x: 68, y: 42 },
    "castle"
  )
];
var byId = (id) => AREA_DEFS.find((a) => a.id === id);
{
  const a = byId("vila");
  a.floors.push(r(12, 10, 16, 10, T.DIRT), r(1, 14, 38, 3, T.DIRT), r(10, 9, 20, 2, T.ROAD));
  a.walls.push(
    r(4, 4, 8, 6, T.WALL_WOOD),
    r(27, 4, 9, 6, T.WALL_WOOD),
    r(4, 21, 8, 6, T.WALL_WOOD),
    r(28, 22, 7, 6, T.WALL_WOOD)
  );
  a.scatter.push({ k: T.TREE, count: 26, seed: 11 });
  a.props.push(
    { k: "well", x: 19, y: 13 },
    { k: "fence", x: 12, y: 20 },
    { k: "fence", x: 13, y: 20 },
    { k: "fence", x: 14, y: 20 },
    { k: "hay", x: 25, y: 25 },
    { k: "cart", x: 33, y: 12 },
    { k: "bench", x: 16, y: 18 },
    { k: "bench", x: 22, y: 18 },
    { k: "flower", x: 18, y: 11 },
    { k: "flower", x: 21, y: 11 },
    { k: "flower", x: 18, y: 16 },
    { k: "flower", x: 21, y: 16 },
    { k: "torch", x: 13, y: 12 },
    { k: "torch", x: 26, y: 12 },
    { k: "sign", x: 11, y: 16 }
  );
  a.lights.push({ x: 13, y: 12, r: 58, c: "#ffb45a" }, { x: 26, y: 12, r: 58, c: "#ffb45a" });
  a.npcs.push(
    { id: "tao", x: 9, y: 12 },
    { id: "perpetua", x: 20, y: 18 },
    { id: "ludovina", x: 15, y: 7 }
  );
}
{
  const a = byId("mercado");
  a.floors.push(r(2, 10, 32, 5, T.ROAD), r(10, 2, 16, 22, T.ROAD), r(2, 2, 8, 24, T.DIRT));
  a.walls.push(r(27, 16, 7, 8, T.WALL_STONE), r(2, 2, 8, 6, T.WALL_STONE));
  a.scatter.push({ k: T.ROCK, count: 8, seed: 33 });
  a.props.push(
    { k: "stall", x: 8, y: 8 },
    { k: "stall", x: 13, y: 8 },
    { k: "stall", x: 18, y: 8 },
    { k: "stall", x: 23, y: 8 },
    { k: "crate", x: 8, y: 7 },
    { k: "crate", x: 24, y: 7 },
    { k: "sack", x: 6, y: 18 },
    { k: "sack", x: 7, y: 19 },
    { k: "statue", x: 18, y: 13 },
    { k: "bench", x: 12, y: 16 },
    { k: "bench", x: 24, y: 16 },
    { k: "torch", x: 5, y: 12 },
    { k: "torch", x: 30, y: 12 },
    { k: "flower", x: 16, y: 20 },
    { k: "flower", x: 20, y: 20 }
  );
  a.lights.push({ x: 5, y: 12, r: 60, c: "#ffb45a" }, { x: 30, y: 12, r: 60, c: "#ffb45a" });
  a.npcs.push(
    { id: "pardal", x: 14, y: 14 },
    { id: "arras", x: 9, y: 19 },
    { id: "tav", x: 24, y: 20 }
  );
}
{
  const a = byId("taverna");
  a.floors.push(r(3, 3, 20, 14, T.WOOD), r(3, 5, 20, 2, T.DARK));
  a.walls.push(r(4, 3, 18, 2, T.BLOCK));
  a.props.push(
    { k: "table", x: 7, y: 9 },
    { k: "table", x: 12, y: 9 },
    { k: "table", x: 17, y: 9 },
    { k: "table", x: 8, y: 14 },
    { k: "table", x: 14, y: 14 },
    { k: "table", x: 19, y: 14 },
    { k: "chair", x: 6, y: 9 },
    { k: "chair", x: 13, y: 9 },
    { k: "chair", x: 18, y: 9 },
    { k: "chair", x: 7, y: 14 },
    { k: "chair", x: 15, y: 14 },
    { k: "barrel", x: 3, y: 8 },
    { k: "barrel", x: 3, y: 9 },
    { k: "barrel", x: 22, y: 8 },
    { k: "shelf", x: 12, y: 6 },
    { k: "torch", x: 4, y: 7 },
    { k: "torch", x: 21, y: 7 },
    { k: "torch", x: 4, y: 16 },
    { k: "torch", x: 21, y: 16 },
    { k: "brazier", x: 12, y: 17 },
    { k: "bench", x: 10, y: 16 },
    { k: "bench", x: 16, y: 16 }
  );
  a.lights.push(
    { x: 4, y: 7, r: 70, c: "#ff9a3c" },
    { x: 21, y: 7, r: 70, c: "#ff9a3c" },
    { x: 4, y: 16, r: 70, c: "#ff9a3c" },
    { x: 21, y: 16, r: 70, c: "#ff9a3c" },
    { x: 12, y: 17, r: 80, c: "#ff7a2a" }
  );
  a.npcs.push(
    { id: "taveiro", x: 8, y: 12 },
    { id: "tav", x: 16, y: 11 },
    { id: "godiva", x: 20, y: 12 }
  );
  a.items.push({ id: "w1", item: "vinho", x: 12, y: 9 });
}
{
  const a = byId("ponte");
  a.floors.push(
    r(0, 9, 30, 5, T.WATER),
    r(13, 7, 5, 9, T.ROAD),
    r(2, 2, 26, 6, T.DIRT),
    r(2, 14, 26, 6, T.DIRT)
  );
  a.walls.push(r(13, 8, 1, 5, T.WALL_STONE), r(17, 8, 1, 5, T.WALL_STONE));
  a.scatter.push({ k: T.TREE, count: 20, seed: 77, on: T.GRASS });
  a.props.push(
    { k: "torch", x: 12, y: 7 },
    { k: "torch", x: 18, y: 7 },
    { k: "torch", x: 12, y: 15 },
    { k: "torch", x: 18, y: 15 },
    { k: "cart", x: 6, y: 6 },
    { k: "bench", x: 24, y: 6 },
    { k: "flower", x: 10, y: 17 },
    { k: "flower", x: 22, y: 4 }
  );
  a.lights.push(
    { x: 12, y: 7, r: 66, c: "#ffb45a" },
    { x: 18, y: 7, r: 66, c: "#ffb45a" },
    { x: 12, y: 15, r: 66, c: "#ffb45a" },
    { x: 18, y: 15, r: 66, c: "#ffb45a" }
  );
  a.npcs.push({ id: "aldric", x: 21, y: 14 });
}
{
  const a = byId("castelo");
  a.floors.push(r(6, 4, 28, 20, T.STONE), r(4, 12, 32, 4, T.DIRT));
  a.walls.push(r(9, 1, 22, 4, T.WALL_STONE), r(2, 4, 5, 9, T.WALL_STONE), r(33, 14, 5, 9, T.WALL_STONE));
  a.scatter.push({ k: T.ROCK, count: 6, seed: 5 });
  a.props.push(
    { k: "banner", x: 12, y: 5 },
    { k: "banner", x: 19, y: 5 },
    { k: "banner", x: 26, y: 5 },
    { k: "statue", x: 10, y: 10 },
    { k: "statue", x: 29, y: 10 },
    { k: "crate", x: 8, y: 20 },
    { k: "crate", x: 9, y: 21 },
    { k: "sack", x: 30, y: 21 },
    { k: "anvil", x: 13, y: 20 },
    { k: "brazier", x: 18, y: 19 },
    { k: "brazier", x: 22, y: 19 },
    { k: "torch", x: 7, y: 13 },
    { k: "torch", x: 32, y: 13 },
    { k: "bench", x: 15, y: 16 }
  );
  a.lights.push(
    { x: 18, y: 19, r: 80, c: "#ff7a2a" },
    { x: 22, y: 19, r: 80, c: "#ff7a2a" },
    { x: 7, y: 13, r: 64, c: "#ffb45a" },
    { x: 32, y: 13, r: 64, c: "#ffb45a" }
  );
  a.npcs.push({ id: "condestavel", x: 22, y: 15 });
}
{
  const a = byId("trono");
  a.floors.push(r(2, 2, 24, 16, T.MARBLE), r(9, 5, 10, 12, T.CARPET));
  a.walls.push(r(11, 2, 6, 2, T.WALL_STONE));
  a.props.push(
    { k: "pillar", x: 5, y: 6 },
    { k: "pillar", x: 5, y: 14 },
    { k: "pillar", x: 23, y: 6 },
    { k: "pillar", x: 23, y: 14 },
    { k: "banner", x: 7, y: 4 },
    { k: "banner", x: 21, y: 4 },
    { k: "throne", x: 14, y: 4 },
    { k: "brazier", x: 8, y: 10 },
    { k: "brazier", x: 20, y: 10 },
    { k: "rug", x: 14, y: 12 },
    { k: "candle", x: 10, y: 3 },
    { k: "candle", x: 18, y: 3 }
  );
  a.lights.push(
    { x: 8, y: 10, r: 78, c: "#ff8a3a" },
    { x: 20, y: 10, r: 78, c: "#ff8a3a" },
    { x: 14, y: 3, r: 70, c: "#ffe08a" }
  );
  a.npcs.push(
    { id: "rei", x: 14, y: 6 },
    { id: "rainha", x: 8, y: 11 },
    { id: "sereno", x: 21, y: 15 }
  );
}
{
  const a = byId("conselho");
  a.floors.push(r(2, 2, 22, 14, T.DARK), r(4, 7, 18, 5, T.WOOD));
  a.walls.push(r(2, 2, 22, 1, T.WALL_STONE));
  a.props.push(
    { k: "table", x: 9, y: 8 },
    { k: "table", x: 13, y: 8 },
    { k: "table", x: 17, y: 8 },
    { k: "chair", x: 9, y: 10 },
    { k: "chair", x: 13, y: 10 },
    { k: "chair", x: 17, y: 10 },
    { k: "shelf", x: 3, y: 4 },
    { k: "shelf", x: 3, y: 6 },
    { k: "shelf", x: 22, y: 4 },
    { k: "shelf", x: 22, y: 6 },
    { k: "banner", x: 13, y: 3 },
    { k: "torch", x: 4, y: 14 },
    { k: "torch", x: 21, y: 14 },
    { k: "chest", x: 22, y: 14 },
    { k: "brazier", x: 12, y: 15 }
  );
  a.lights.push(
    { x: 4, y: 14, r: 68, c: "#ffb45a" },
    { x: 21, y: 14, r: 68, c: "#ffb45a" },
    { x: 12, y: 15, r: 70, c: "#ff8a3a" }
  );
  a.npcs.push(
    { id: "chanceler", x: 9, y: 8 },
    { id: "gaspar", x: 18, y: 11 },
    { id: "aurelio", x: 13, y: 14 }
  );
  a.items.push({ id: "w6", item: "diario", x: 22, y: 14 });
}
{
  const a = byId("capela");
  a.floors.push(r(2, 2, 18, 14, T.MARBLE), r(9, 2, 4, 12, T.CARPET));
  a.walls.push(r(2, 2, 18, 1, T.WALL_STONE));
  a.props.push(
    { k: "altar", x: 11, y: 3 },
    { k: "candle", x: 9, y: 4 },
    { k: "candle", x: 13, y: 4 },
    { k: "bench", x: 7, y: 8 },
    { k: "bench", x: 7, y: 11 },
    { k: "bench", x: 15, y: 8 },
    { k: "bench", x: 15, y: 11 },
    { k: "banner", x: 5, y: 3 },
    { k: "banner", x: 17, y: 3 },
    { k: "torch", x: 3, y: 15 },
    { k: "torch", x: 19, y: 15 },
    { k: "flower", x: 10, y: 12 },
    { k: "flower", x: 12, y: 12 }
  );
  a.lights.push(
    { x: 3, y: 15, r: 62, c: "#ffcf7a" },
    { x: 19, y: 15, r: 62, c: "#ffcf7a" },
    { x: 11, y: 3, r: 70, c: "#ffe8b0" }
  );
  a.npcs.push(
    { id: "prior", x: 11, y: 8 },
    { id: "leonor", x: 6, y: 14 },
    { id: "umbelina", x: 16, y: 14 }
  );
}
{
  const a = byId("cripta");
  a.floors.push(r(2, 2, 20, 14, T.CRYPT));
  a.walls.push(r(2, 2, 20, 1, T.WALL_STONE));
  a.props.push(
    { k: "pillar", x: 5, y: 5 },
    { k: "pillar", x: 5, y: 12 },
    { k: "pillar", x: 18, y: 5 },
    { k: "pillar", x: 18, y: 12 },
    { k: "candle", x: 8, y: 3 },
    { k: "candle", x: 15, y: 3 },
    { k: "candle", x: 8, y: 15 },
    { k: "candle", x: 15, y: 15 },
    { k: "statue", x: 12, y: 4 },
    { k: "chest", x: 3, y: 15 },
    { k: "brazier", x: 12, y: 13 }
  );
  a.lights.push(
    { x: 8, y: 3, r: 52, c: "#ffcf7a" },
    { x: 15, y: 3, r: 52, c: "#ffcf7a" },
    { x: 8, y: 15, r: 52, c: "#ffcf7a" },
    { x: 15, y: 15, r: 52, c: "#ffcf7a" },
    { x: 12, y: 13, r: 66, c: "#ff7a2a" }
  );
  a.npcs.push({ id: "fantasma", x: 12, y: 9 });
}
{
  const a = byId("bosque");
  a.floors.push(r(16, 12, 10, 10, T.DIRT), r(2, 2, 38, 6, T.MOSS));
  a.scatter.push({ k: T.TREE, count: 110, seed: 91, on: T.MOSS }, { k: T.ROCK, count: 12, seed: 12 });
  a.props.push(
    { k: "campfire", x: 21, y: 16 },
    { k: "chest", x: 25, y: 18 },
    { k: "statue", x: 18, y: 18 },
    { k: "bench", x: 23, y: 15 },
    { k: "torch", x: 16, y: 13 },
    { k: "torch", x: 25, y: 13 },
    { k: "flower", x: 19, y: 14 },
    { k: "flower", x: 22, y: 20 }
  );
  a.lights.push(
    { x: 21, y: 16, r: 76, c: "#ff7a2a" },
    { x: 16, y: 13, r: 56, c: "#ffb45a" },
    { x: 25, y: 13, r: 56, c: "#ffb45a" }
  );
  a.npcs.push({ id: "bruma", x: 32, y: 22 });
  a.items.push({ id: "w2", item: "erva", x: 24, y: 19 });
}
{
  const a = byId("torre");
  a.floors.push(r(2, 2, 16, 16, T.STONE), r(6, 6, 8, 8, T.DARK));
  a.walls.push(r(2, 2, 16, 1, T.WALL_STONE));
  a.props.push(
    { k: "pillar", x: 4, y: 5 },
    { k: "pillar", x: 15, y: 5 },
    { k: "pillar", x: 4, y: 14 },
    { k: "pillar", x: 15, y: 14 },
    { k: "banner", x: 10, y: 3 },
    { k: "brazier", x: 10, y: 8 },
    { k: "crate", x: 4, y: 9 },
    { k: "crate", x: 15, y: 9 },
    { k: "torch", x: 6, y: 17 },
    { k: "torch", x: 13, y: 17 }
  );
  a.lights.push(
    { x: 10, y: 8, r: 80, c: "#ff7a2a" },
    { x: 6, y: 17, r: 60, c: "#ffb45a" },
    { x: 13, y: 17, r: 60, c: "#ffb45a" }
  );
  a.npcs.push({ id: "vargo", x: 10, y: 13 });
}
{
  const a = byId("muralha");
  a.floors.push(r(2, 2, 26, 18, T.STONE), r(4, 8, 22, 4, T.DIRT));
  a.walls.push(r(2, 2, 26, 1, T.WALL_STONE), r(2, 19, 26, 1, T.WALL_STONE));
  a.props.push(
    { k: "pillar", x: 4, y: 4 },
    { k: "pillar", x: 12, y: 4 },
    { k: "pillar", x: 20, y: 4 },
    { k: "pillar", x: 4, y: 15 },
    { k: "pillar", x: 12, y: 15 },
    { k: "pillar", x: 20, y: 15 },
    { k: "banner", x: 8, y: 3 },
    { k: "banner", x: 16, y: 3 },
    { k: "crate", x: 25, y: 6 },
    { k: "sack", x: 25, y: 7 },
    { k: "brazier", x: 8, y: 9 },
    { k: "brazier", x: 22, y: 9 },
    { k: "bench", x: 10, y: 12 },
    { k: "torch", x: 5, y: 18 },
    { k: "torch", x: 25, y: 18 }
  );
  a.lights.push(
    { x: 8, y: 9, r: 74, c: "#ff7a2a" },
    { x: 22, y: 9, r: 74, c: "#ff7a2a" },
    { x: 5, y: 18, r: 58, c: "#ffb45a" },
    { x: 25, y: 18, r: 58, c: "#ffb45a" }
  );
  a.npcs.push(
    { id: "capitao", x: 16, y: 11 },
    { id: "vargo", x: 23, y: 14 },
    { id: "silvino", x: 6, y: 16 }
  );
}
{
  const a = byId("cemiterio");
  a.floors.push(r(2, 2, 26, 20, T.GRAVE), r(12, 2, 6, 20, T.DIRT));
  a.walls.push(r(2, 2, 26, 1, T.HEDGE), r(2, 21, 26, 1, T.HEDGE));
  a.props.push(
    { k: "grave", x: 5, y: 5 },
    { k: "grave", x: 8, y: 5 },
    { k: "grave", x: 5, y: 9 },
    { k: "grave", x: 8, y: 9 },
    { k: "grave", x: 20, y: 6 },
    { k: "grave", x: 23, y: 6 },
    { k: "grave", x: 20, y: 11 },
    { k: "grave", x: 23, y: 14 },
    { k: "grave", x: 6, y: 16 },
    { k: "statue", x: 15, y: 10 },
    { k: "torch", x: 11, y: 4 },
    { k: "torch", x: 18, y: 18 },
    { k: "flower", x: 14, y: 6 },
    { k: "flower", x: 16, y: 16 }
  );
  a.lights.push(
    { x: 11, y: 4, r: 58, c: "#9fc8ff" },
    { x: 18, y: 18, r: 58, c: "#9fc8ff" }
  );
  a.npcs.push({ id: "sereno", x: 12, y: 12 });
}
{
  const a = byId("porto");
  a.floors.push(r(2, 12, 32, 10, T.WOOD), r(2, 2, 32, 9, T.WATER));
  a.walls.push(r(2, 2, 1, 20, T.WALL_STONE), r(33, 2, 1, 20, T.WALL_STONE));
  a.props.push(
    { k: "boat", x: 8, y: 6 },
    { k: "boat", x: 20, y: 5 },
    { k: "boat", x: 29, y: 7 },
    { k: "crate", x: 5, y: 14 },
    { k: "crate", x: 6, y: 15 },
    { k: "crate", x: 7, y: 14 },
    { k: "sack", x: 9, y: 17 },
    { k: "sack", x: 10, y: 18 },
    { k: "barrel", x: 26, y: 16 },
    { k: "barrel", x: 27, y: 17 },
    { k: "torch", x: 4, y: 13 },
    { k: "torch", x: 31, y: 13 },
    { k: "torch", x: 15, y: 20 },
    { k: "sign", x: 15, y: 13 }
  );
  a.lights.push(
    { x: 4, y: 13, r: 62, c: "#ffb45a" },
    { x: 31, y: 13, r: 62, c: "#ffb45a" },
    { x: 15, y: 20, r: 62, c: "#ffb45a" }
  );
  a.npcs.push({ id: "nilo", x: 25, y: 15 });
  a.items.push({ id: "w3", item: "contrato", x: 12, y: 19 });
}
{
  const a = byId("fornalha");
  a.floors.push(r(2, 2, 20, 14, T.DARK), r(8, 8, 8, 6, T.STONE));
  a.walls.push(r(2, 2, 20, 1, T.WALL_STONE));
  a.props.push(
    { k: "forge", x: 11, y: 4 },
    { k: "anvil", x: 10, y: 10 },
    { k: "anvil", x: 14, y: 10 },
    { k: "barrel", x: 4, y: 5 },
    { k: "barrel", x: 5, y: 6 },
    { k: "crate", x: 18, y: 4 },
    { k: "crate", x: 19, y: 5 },
    { k: "sack", x: 6, y: 13 },
    { k: "brazier", x: 9, y: 14 },
    { k: "brazier", x: 15, y: 14 },
    { k: "torch", x: 4, y: 9 },
    { k: "torch", x: 19, y: 9 }
  );
  a.lights.push(
    { x: 11, y: 4, r: 90, c: "#ff5a1a" },
    { x: 9, y: 14, r: 66, c: "#ff7a2a" },
    { x: 15, y: 14, r: 66, c: "#ff7a2a" },
    { x: 4, y: 9, r: 56, c: "#ffb45a" },
    { x: 19, y: 9, r: 56, c: "#ffb45a" }
  );
  a.npcs.push({ id: "bruna", x: 12, y: 10 });
}
{
  const a = byId("solar");
  a.floors.push(r(2, 2, 26, 18, T.MARBLE), r(11, 4, 8, 14, T.CARPET));
  a.walls.push(r(2, 2, 26, 1, T.WALL_STONE));
  a.props.push(
    { k: "pillar", x: 5, y: 5 },
    { k: "pillar", x: 5, y: 16 },
    { k: "pillar", x: 24, y: 5 },
    { k: "pillar", x: 24, y: 16 },
    { k: "throne", x: 15, y: 5 },
    { k: "banner", x: 9, y: 3 },
    { k: "banner", x: 21, y: 3 },
    { k: "brazier", x: 8, y: 10 },
    { k: "brazier", x: 22, y: 10 },
    { k: "shelf", x: 3, y: 8 },
    { k: "shelf", x: 3, y: 10 },
    { k: "rug", x: 15, y: 12 },
    { k: "flower", x: 13, y: 16 },
    { k: "flower", x: 17, y: 16 }
  );
  a.lights.push(
    { x: 8, y: 10, r: 80, c: "#ff8a3a" },
    { x: 22, y: 10, r: 80, c: "#ff8a3a" },
    { x: 15, y: 5, r: 64, c: "#ffe08a" }
  );
  a.npcs.push(
    { id: "valdessa", x: 12, y: 9 },
    { id: "duque", x: 21, y: 16 }
  );
  a.items.push({ id: "w4", item: "carta", x: 19, y: 12 }, { id: "w4b", item: "anel", x: 24, y: 12 });
}
{
  const a = byId("corvo");
  a.floors.push(r(2, 2, 16, 12, T.DARK), r(5, 5, 10, 8, T.WOOD));
  a.walls.push(r(2, 2, 16, 1, T.WALL_WOOD));
  a.props.push(
    { k: "table", x: 8, y: 7 },
    { k: "table", x: 12, y: 7 },
    { k: "shelf", x: 3, y: 4 },
    { k: "shelf", x: 3, y: 6 },
    { k: "shelf", x: 3, y: 8 },
    { k: "shelf", x: 16, y: 4 },
    { k: "shelf", x: 16, y: 6 },
    { k: "candle", x: 6, y: 3 },
    { k: "candle", x: 13, y: 3 },
    { k: "candle", x: 6, y: 12 },
    { k: "candle", x: 13, y: 12 },
    { k: "chest", x: 16, y: 12 },
    { k: "brazier", x: 10, y: 10 }
  );
  a.lights.push(
    { x: 6, y: 3, r: 48, c: "#a0c0ff" },
    { x: 13, y: 3, r: 48, c: "#a0c0ff" },
    { x: 6, y: 12, r: 48, c: "#a0c0ff" },
    { x: 13, y: 12, r: 48, c: "#a0c0ff" },
    { x: 10, y: 10, r: 60, c: "#ff7a2a" }
  );
  a.npcs.push({ id: "vesper", x: 10, y: 8 });
  a.items.push({ id: "w5", item: "cifra", x: 16, y: 12 });
}
{
  const a = byId("salao");
  a.floors.push(r(2, 2, 24, 16, T.WOOD), r(10, 2, 8, 16, T.CARPET));
  a.walls.push(r(2, 2, 24, 1, T.WALL_STONE));
  a.props.push(
    { k: "table", x: 6, y: 6 },
    { k: "table", x: 6, y: 11 },
    { k: "table", x: 22, y: 6 },
    { k: "table", x: 22, y: 11 },
    { k: "chair", x: 7, y: 6 },
    { k: "chair", x: 5, y: 6 },
    { k: "chair", x: 7, y: 11 },
    { k: "chair", x: 21, y: 6 },
    { k: "chair", x: 23, y: 11 },
    { k: "banner", x: 8, y: 3 },
    { k: "banner", x: 20, y: 3 },
    { k: "brazier", x: 13, y: 6 },
    { k: "brazier", x: 15, y: 13 },
    { k: "bench", x: 13, y: 17 },
    { k: "torch", x: 4, y: 16 },
    { k: "torch", x: 24, y: 16 }
  );
  a.lights.push(
    { x: 13, y: 6, r: 82, c: "#ff8a3a" },
    { x: 15, y: 13, r: 82, c: "#ff8a3a" },
    { x: 4, y: 16, r: 60, c: "#ffb45a" },
    { x: 24, y: 16, r: 60, c: "#ffb45a" }
  );
  a.npcs.push(
    { id: "otavio", x: 16, y: 12 },
    { id: "ismael", x: 9, y: 13 }
  );
}
var NPCS_BY_AREA = Object.fromEntries(AREA_DEFS.map((a) => [a.id, a.npcs.map((n2) => ({ ...n2 }))]));

// src/game/engine.ts
var AREA_NAME = Object.fromEntries(
  AREA_DEFS.map((a) => [a.id, a.name])
);
function createInitialState(playerName) {
  const npcs = {};
  NPCS.forEach((n2) => {
    npcs[n2.id] = {
      id: n2.id,
      trust: n2.initial.trust,
      respect: n2.initial.respect,
      fear: n2.initial.fear,
      loyalty: n2.initial.loyalty,
      ambition: n2.initial.ambition,
      areaId: n2.areaId,
      x: n2.x,
      y: n2.y,
      alive: true,
      memories: []
    };
  });
  return {
    version: 1,
    started: true,
    player: { x: 19, y: 16, areaId: "vila", facing: "down", anim: 0, moving: false },
    stats: { influence: 5, reputation: 10, intelligence: 8, wealth: 60, power: 2 },
    score: 0,
    inventory: [],
    npcs,
    flags: [],
    memoriesByLaw: {},
    currentMission: 1,
    missionStep: 0,
    completedMissions: [],
    unlockedAreas: ["vila"],
    discoveredAreas: ["vila"],
    knownLaws: [],
    worldItems: [],
    log: [],
    toasts: [],
    floaters: [],
    particles: [],
    gameOver: null,
    ending: null,
    playerName,
    turnCount: 0,
    time: 0
  };
}
var nextMission = (state2) => {
  const done = new Set(state2.completedMissions);
  for (const m of MISSIONS) {
    if (!done.has(m.id)) return m;
  }
  return null;
};
function addItem(state2, id, count = 1) {
  const found = state2.inventory.find((i) => i.id === id);
  if (found) found.count += count;
  else state2.inventory.push({ id, count });
}
function removeItem(state2, id, count = 1) {
  const found = state2.inventory.find((i) => i.id === id);
  if (!found) return false;
  found.count -= count;
  if (found.count <= 0) state2.inventory = state2.inventory.filter((i) => i.id !== id);
  return true;
}
var hasItem = (state2, id) => state2.inventory.some((i) => i.id === id && i.count > 0);
var hasFlag = (state2, f) => state2.flags.includes(f);
function applyEffects(state2, eff) {
  if (!eff) return;
  Object.keys(eff).forEach((k) => {
    state2.stats[k] = Math.max(0, Math.round(state2.stats[k] + (eff[k] ?? 0)));
  });
}
function adjustNpc(state2, id, deltas) {
  const n2 = state2.npcs[id];
  if (!n2) return;
  Object.keys(deltas).forEach((k) => {
    n2[k] = Math.max(0, Math.min(100, n2[k] + (deltas[k] ?? 0)));
  });
}
function addMemory(state2, npcId, text, kind, mission) {
  const n2 = state2.npcs[npcId];
  if (!n2) return;
  n2.memories.unshift({ id: `${mission}-${n2.memories.length}-${text.length}`, text, kind, mission });
  if (n2.memories.length > 12) n2.memories.pop();
}
function addLog(state2, text, tone, mission) {
  state2.log.unshift({ id: state2.log.length + Date.now() + Math.random(), text, tone, mission });
  if (state2.log.length > 60) state2.log.pop();
}
function addToast(state2, text, tone) {
  state2.toasts.push({ id: Date.now() + Math.random(), text, tone, at: Date.now() });
  if (state2.toasts.length > 4) state2.toasts.shift();
}
function checkRequirement(state2, choice) {
  const req = choice.req;
  if (!req) return true;
  if (req.stat) {
    for (const k of Object.keys(req.stat)) {
      if (state2.stats[k] < (req.stat[k] ?? 0)) return false;
    }
  }
  if (req.item && !hasItem(state2, req.item)) return false;
  if (req.flag && !hasFlag(state2, req.flag)) return false;
  if (req.npcTrust) {
    const n2 = state2.npcs[req.npcTrust.id];
    if (!n2 || n2.trust < req.npcTrust.min) return false;
  }
  return true;
}
function applyChoice(state2, mission, choice) {
  applyEffects(state2, choice.effects);
  choice.npc?.forEach((n2) => adjustNpc(state2, n2.id, n2.deltas));
  choice.give?.forEach((g) => addItem(state2, g.item, g.count));
  choice.take?.forEach((t) => removeItem(state2, t.item, t.count));
  choice.flags?.forEach((f) => {
    if (!state2.flags.includes(f)) state2.flags.push(f);
  });
  const scoreGained = choice.score ?? 0;
  state2.score += scoreGained;
  if (choice.npc?.length) {
    const main = choice.npc[0];
    const good = (main.deltas.trust ?? 0) + (main.deltas.respect ?? 0) - (main.deltas.fear ?? 0) > 0;
    const bad = (main.deltas.trust ?? 0) + (main.deltas.respect ?? 0) - (main.deltas.fear ?? 0) < 0;
    addMemory(
      state2,
      main.id,
      choice.text,
      bad ? "bad" : good ? "good" : "info",
      mission.id
    );
  }
  const failed = choice.end === "fail";
  const completed = choice.end === "mission" || failed;
  if (choice.effects) {
    const parts = [];
    Object.keys(choice.effects).forEach((k) => {
      const v = choice.effects[k];
      if (v !== 0) parts.push(`${v > 0 ? "+" : ""}${v} ${k === "wealth" ? "ouro" : k}`);
    });
    if (parts.length) addToast(state2, parts.join("  "), "good");
  }
  if (scoreGained) addToast(state2, `+${scoreGained} pontos de poder`, "gold");
  return { outcome: choice.outcome, completed, failed, scoreGained, statDeltas: choice.effects ?? {} };
}
function completeMission(state2, mission, failed = false) {
  if (!state2.completedMissions.includes(mission.id)) state2.completedMissions.push(mission.id);
  if (!failed) {
    applyEffects(state2, mission.reward.effects);
    state2.score += mission.reward.score;
    if (mission.reward.item) addItem(state2, mission.reward.item, 1);
    if (!state2.knownLaws.includes(mission.id)) state2.knownLaws.push(mission.id);
    mission.unlockAreas?.forEach((a) => {
      if (!state2.unlockedAreas.includes(a)) {
        state2.unlockedAreas.push(a);
        addToast(state2, `Nova regi\xE3o liberada: ${AREA_NAME[a] ?? a}`, "gold");
      }
    });
    addLog(state2, `Lei ${mission.id} dominada: ${mission.lawTitle}`, "gold", mission.id);
  } else {
    addLog(state2, `Lei ${mission.id}: fracasso. A corte vai lembrar.`, "bad", mission.id);
    state2.stats.reputation = Math.max(0, state2.stats.reputation - 3);
  }
  const m = nextMission(state2);
  state2.currentMission = m ? m.id : null;
  state2.missionStep = 0;
  if (!m) {
    state2.ending = computeEnding(state2);
  }
}
function computeEnding(state2) {
  const f = state2.flags;
  const { influence, reputation, wealth, power } = state2.stats;
  if (reputation <= 0 && power <= 10) return "ruin";
  if (f.includes("coroado") && power >= 40) return "king";
  if (power >= 42 && influence >= 38) return "advisor";
  if (power >= 30) return "shadow";
  if (reputation >= 25 && (f.includes("padrinho_da_igreja") || f.includes("herdeiro_no_olhar") || f.includes("promessa_de_pao")))
    return "dynasty";
  if (wealth >= 700) return "noble";
  if (power >= 18) return "shadow";
  return "ruin";
}

// scripts/lategame.ts
import { writeFileSync } from "fs";
var state = createInitialState("Testador");
AREA_DEFS.forEach((d) => d.items.forEach((it) => state.worldItems.push({ id: `${d.id}_${it.id}`, item: it.item, areaId: d.id, x: it.x, y: it.y })));
for (const m of MISSIONS.slice(0, 32)) {
  state.currentMission = m.id;
  state.missionStep = 0;
  let nodeId = m.steps[0].kind === "dialogue" ? m.steps[0].node : "";
  let guard = 0;
  while (guard++ < 80) {
    const step = m.steps[state.missionStep];
    if (!step) {
      completeMission(state, m, false);
      break;
    }
    if (step.kind === "collect") {
      addItem(state, step.item, step.count);
      state.missionStep++;
      nodeId = m.steps[state.missionStep]?.kind === "dialogue" ? m.steps[state.missionStep].node : nodeId;
      continue;
    }
    if (step.kind === "visit") {
      state.player.areaId = step.areaId;
      state.missionStep++;
      nodeId = m.steps[state.missionStep]?.kind === "dialogue" ? m.steps[state.missionStep].node : nodeId;
      continue;
    }
    if (step.kind === "talk") {
      state.missionStep++;
      nodeId = m.steps[state.missionStep]?.kind === "dialogue" ? m.steps[state.missionStep].node : nodeId;
      continue;
    }
    const node = m.nodes[nodeId];
    if (!node) break;
    const ch = node.choices.find((c2) => checkRequirement(state, c2));
    if (!ch) break;
    const res = applyChoice(state, m, ch);
    if (res.completed) {
      completeMission(state, m, res.failed);
      break;
    }
    if (ch.next && m.nodes[ch.next]) {
      nodeId = ch.next;
      continue;
    }
    state.missionStep++;
    nodeId = m.steps[state.missionStep]?.kind === "dialogue" ? m.steps[state.missionStep].node : nodeId;
  }
}
addItem(state, "diario", 1);
state.player.areaId = "conselho";
state.player.x = 13;
state.player.y = 12;
writeFileSync("/tmp/state32.json", JSON.stringify(state));
console.log("missoes:", state.completedMissions.length, "| atual:", state.currentMission, "| score:", state.score, "| diario no inventario:", state.inventory.find((i) => i.id === "diario")?.count);
