#!/usr/bin/env python3
"""Build Raqeeq content JSON from trusted downloaded sources. Do not invent religious text."""

from __future__ import annotations

import html as html_lib
import json
import re
import unicodedata
from pathlib import Path

ROOT = Path("/workspace")
SRC = Path("/tmp/rafeeq-data")
OUT = ROOT / "src" / "content" / "generated"
TAFSIR_DIR = ROOT / "public" / "content" / "tafsir"

AR_NUM = str.maketrans("0123456789", "٠١٢٣٤٥٦٧٨٩")


def ar_digits(n: int) -> str:
    return str(n).translate(AR_NUM)


def strip_bom(s: str) -> str:
    return s.replace("\ufeff", "").strip()


def clean_wiki(text: str) -> str:
    text = text.replace("{{صل}}", "صلى الله عليه وسلم")
    text = text.replace("{{ر}}", "رضي الله عنه")
    text = text.replace("{{رضي الله عنه}}", "رضي الله عنه")
    text = text.replace("{{رضي الله عنها}}", "رضي الله عنها")
    text = text.replace("{{رضي الله عنهما}}", "رضي الله عنهما")
    text = re.sub(r"<!--.*?-->", "", text, flags=re.S)
    prev = None
    while prev != text:
        prev = text
        text = re.sub(r"\{\{[^{}]*\}\}", "", text)
    text = re.sub(r"\[\[([^\]|]+)\|([^\]]+)\]\]", r"\2", text)
    text = re.sub(r"\[\[([^\]]+)\]\]", r"\1", text)
    text = re.sub(r"'{2,}", "", text)
    text = re.sub(r"<br\s*/?>", "\n", text, flags=re.I)
    text = re.sub(r"<[^>]+>", "", text)
    text = html_lib.unescape(text)
    text = re.sub(r"^=+\s*", "", text, flags=re.M)
    text = text.replace("__لاتحريرقسم__", "")
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def split_wiki_sections(raw: str, fallback_title: str) -> list[dict]:
    parts = re.split(r"\n(?=={2,4}\s*)", raw)
    sections: list[dict] = []
    intro_chunks: list[str] = []
    for part in parts:
        m = re.match(r"={2,4}\s*([^=\n]+?)\s*={2,4}\s*\n?(.*)", part, re.S)
        if m:
            title = clean_wiki(m.group(1)).strip(" =")
            body = clean_wiki(m.group(2))
            if body:
                sections.append({"title": title, "body": body})
        else:
            cleaned = clean_wiki(part)
            if cleaned:
                intro_chunks.append(cleaned)
    if intro_chunks:
        intro = "\n\n".join(intro_chunks).strip()
        if intro:
            sections.insert(0, {"title": fallback_title, "body": intro})
    if not sections:
        body = clean_wiki(raw)
        if body:
            sections = [{"title": fallback_title, "body": body}]
    return [s for s in sections if len(s["body"]) > 20]


COUNT_PATTERNS = [
    (re.compile(r"ثلاث(?:اً|ة)?\s+و(?:ثلاث(?:ين)|ثلاثين)"), 33),
    (re.compile(r"مائة\s+مرة|مئة\s+مرة"), 100),
    (re.compile(r"عشر(?:ة)?\s+مرات"), 10),
    (re.compile(r"سبع\s+مرات"), 7),
    (re.compile(r"أربع\s+مرات"), 4),
    (re.compile(r"ثلاث\s+مرات"), 3),
    (re.compile(r"مرتين"), 2),
]


def parse_count(text: str, footnote: str) -> int:
    blob = f"{text} {footnote}"
    for rx, n in COUNT_PATTERNS:
        if rx.search(blob):
            return n
    m = re.search(r"\((\s*مرة(?: واحدة)?\s*)\)", text)
    if m:
        return 1
    return 1


def surah_short_name(name: str) -> str:
    return re.sub(r"^سُورَةُ\s*", "", name).strip()


def build_quran() -> tuple[list[dict], dict]:
    raw = json.loads((SRC / "quran-uthmani.json").read_text(encoding="utf-8"))
    surahs = []
    meta = {"surahs": [], "source": {
        "name": "مصحف المدينة النبوية — الرسم العثماني",
        "publisher": "مجمع الملك فهد لطباعة المصحف الشريف",
        "via": "alquran.cloud edition quran-uthmani (Tanzil)",
        "note": "نص القرآن الكريم من مصدر عثماني مراجع، دون أي تعديل على الألفاظ.",
    }}
    for s in raw["data"]["surahs"]:
        ayahs = []
        for a in s["ayahs"]:
            sajda = a.get("sajda") or False
            ayahs.append({
                "g": a["number"],
                "n": a["numberInSurah"],
                "t": strip_bom(a["text"]),
                "j": a["juz"],
                "p": a["page"],
                "sajda": bool(sajda) if not isinstance(sajda, dict) else True,
            })
        surahs.append({
            "id": s["number"],
            "name": s["name"],
            "shortName": surah_short_name(s["name"]),
            "englishName": s["englishName"],
            "type": "مكية" if s["revelationType"] == "Meccan" else "مدنية",
            "ayahs": ayahs,
        })
        meta["surahs"].append({
            "id": s["number"],
            "name": s["name"],
            "shortName": surah_short_name(s["name"]),
            "englishName": s["englishName"],
            "type": "مكية" if s["revelationType"] == "Meccan" else "مدنية",
            "count": len(ayahs),
            "page": ayahs[0]["p"] if ayahs else 1,
            "juz": ayahs[0]["j"] if ayahs else 1,
        })
    return surahs, meta


def build_tafsir():
    raw = json.loads((SRC / "tafsir.json").read_text(encoding="utf-8"))
    TAFSIR_DIR.mkdir(parents=True, exist_ok=True)
    for s in raw["data"]["surahs"]:
        items = []
        for a in s["ayahs"]:
            items.append({
                "n": a["numberInSurah"],
                "t": strip_bom(a["text"]),
            })
        path = TAFSIR_DIR / f"{s['number']:03d}.json"
        path.write_text(json.dumps({
            "id": s["number"],
            "name": s["name"],
            "edition": "التفسير الميسر — مجمع الملك فهد لطباعة المصحف الشريف",
            "ayahs": items,
        }, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")


QURAN_DUAS = [
    (2, 201, "دعاء خير الدنيا والآخرة"),
    (2, 250, "دعاء الثبات عند لقاء العدو"),
    (2, 286, "دعاء رفع الإصر والرحمة"),
    (3, 8, "دعاء ثبات القلب على الدين"),
    (3, 16, "دعاء المغفرة والوقاية من النار"),
    (3, 38, "دعاء زكريا عليه السلام للذرية"),
    (3, 147, "دعاء النصر على القوم الكافرين"),
    (3, 193, "دعاء الإيمان والمغفرة"),
    (7, 23, "دعاء آدم وحواء عليهما السلام"),
    (14, 40, "دعاء إبراهيم عليه السلام لذريته"),
    (17, 24, "دعاء الرحمة للوالدين"),
    (18, 10, "دعاء أهل الكهف"),
    (20, 25, "دعاء موسى عليه السلام لشرح الصدر"),
    (21, 83, "دعاء أيوب عليه السلام"),
    (21, 87, "دعاء يونس عليه السلام"),
    (25, 74, "دعاء صلاح الذرية وجعلنا للمتقين إماما"),
    (26, 83, "دعاء الحكمة واللحاق بالصالحين"),
    (46, 15, "دعاء بر الوالدين وصلاح الذرية"),
    (59, 10, "دعاء المغفرة للمؤمنين"),
    (66, 8, "دعاء التوبة النصوح"),
    (71, 28, "دعاء نوح عليه السلام للمؤمنين"),
]


def extract_count_label(text: str) -> str:
    m = re.search(r"\(([^)]{2,40})\)\s*$", text.strip())
    return m.group(1).strip() if m else ""


HISN_MAP = {
    "morning": {
        "title": "أذكار الصباح",
        "kind": "adhkar",
        "keys": ["أذكار الصباح والمساء"],
        "blurb": "أذكار الصباح من حصن المسلم، وهي مشتركة مع المساء مع اختلاف ألفاظ الإصباح والإمساء.",
    },
    "evening": {
        "title": "أذكار المساء",
        "kind": "adhkar",
        "keys": ["أذكار الصباح والمساء"],
        "blurb": "أذكار المساء من حصن المسلم، وهي مشتركة مع الصباح مع اختلاف ألفاظ الإصباح والإمساء.",
    },
    "after-prayer": {
        "title": "أذكار بعد الصلاة",
        "kind": "adhkar",
        "keys": ["الأذكار بعد السلام من الصلاة"],
        "blurb": "ما يقال دبر الصلوات المكتوبة.",
    },
    "sleep": {
        "title": "أذكار النوم",
        "kind": "adhkar",
        "keys": ["أذكار النوم"],
        "blurb": "ما يقال عند النوم.",
    },
    "wakeup": {
        "title": "أذكار الاستيقاظ",
        "kind": "adhkar",
        "keys": ["أذكار الاستيقاظ من النوم"],
        "blurb": "ما يقال عند الاستيقاظ من النوم.",
    },
    "travel": {
        "title": "أذكار السفر",
        "kind": "adhkar",
        "keys": [
            "دعاء ركوب الدابة",
            "دعاء السفر",
            "دعاء دخول القرية أو البلدة",
            "دعاء المسافر للمقيم",
            "دعاء المقيم للمسافر",
            "التكبير والتسبيح في سير السفر",
            "دعاء المسافر إذا أسحر",
            "الدعاء إذا نزل منزلا في سفر أو غيره",
            "ذكر الرجوع من السفر",
        ],
        "blurb": "أذكار الركوب والسفر والقدوم.",
    },
    "food": {
        "title": "أذكار الطعام",
        "kind": "adhkar",
        "keys": [
            "الدعاء قبل الطعام",
            "الدعاء عند الفراغ من الطعام",
            "دعاء الضيف لصاحب الطعام",
            "الدعاء لمن سقاه أو إذا أراد ذلك",
            "الدعاء إذا أفطر عند أهل بيت",
            "دعاء الصائم إذا حضر الطعام ولم يفطر",
            "الدعاء عند رؤية باكورة الثمر",
        ],
        "blurb": "أذكار الطعام والشراب.",
    },
    "general": {
        "title": "أذكار عامة",
        "kind": "adhkar",
        "keys": [
            "فضل الذكر",
            "دعاء لبس الثوب",
            "الذكر قبل الوضوء",
            "الذكر بعد الفراغ من الوضوء",
            "الذكر عند الخروج من المنزل",
            "الذكر عند الدخول المنزل",
            "دعاء دخول المسجد",
            "دعاء الخروج من المسجد",
            "أذكار الأذان",
            "التشهد",
            "الاستغفار والتوبة",
            "فضل التسبيح والتحميد ، والتهليل ، والتكبير",
            "كيف كان النبي صلى الله عليه وسلم يسبح ؟",
            "كفارة المجلس ومايختم به المجالس",
            "إفشاء السلام",
        ],
        "blurb": "أذكار متنوعة من حصن المسلم.",
    },
    "dua-sunnah": {
        "title": "أدعية من السنة",
        "kind": "dua",
        "keys": [
            "دعاء الاستخارة",
            "دعاء الهم والحزن",
            "دعاء الكرب",
            "دعاء قنوت الوتر",
            "الدعاء بعد التشهد الأخير وقبل السلام",
            "ما يقول ويفعل من أذنب ذنباً",
            "دعاء طرد الشيطان ووساوسه",
            "دعاء الغضب",
            "ما يقول عند الفزع",
            "الاستغفار والتوبة",
        ],
        "blurb": "أدعية مأثورة من السنة، منحصرة في حصن المسلم.",
    },
    "dua-sick": {
        "title": "أدعية للمريض",
        "kind": "dua",
        "keys": [
            "الدعاء للمريض في عيادته",
            "فضل عيادة المريض",
            "دعاء المريض الذي يئس من حياته",
            "ما يقول من أحس وجعاً في جسده",
            "دعاء من خشي أن يصيب شيئاً بعينه",
        ],
        "blurb": "ما يقال في عيادة المريض والرقية.",
    },
    "dua-travel": {
        "title": "أدعية السفر",
        "kind": "dua",
        "keys": ["دعاء السفر", "دعاء ركوب الدابة", "دعاء دخول القرية أو البلدة"],
        "blurb": "أدعية الركوب والسفر.",
    },
    "dua-distress": {
        "title": "أدعية الكرب والهم",
        "kind": "dua",
        "keys": [
            "دعاء الهم والحزن",
            "دعاء الكرب",
            "دعاء من استصعب عليه أمر",
            "الدعاء حينما يقع مالا يرضاه أو غلب على أمره",
            "دعاء من أصيب بمصيبة",
            "ما يقول عند الفزع",
        ],
        "blurb": "ما يقال عند الهم والكرب والمصيبة.",
    },
    "dua-rizq": {
        "title": "أدعية الرزق",
        "kind": "dua",
        "keys": [
            "الدعاء قضاء الدين",
            "دعاء دخول السوق",
        ],
        "blurb": "أدعية الرزق وقضاء الدين من السنة.",
    },
    "dua-misc": {
        "title": "أدعية متنوعة",
        "kind": "dua",
        "keys": [
            "دعاء الاستخارة",
            "دعاء رؤية الهلال",
            "الدعاء عند إفطار الصائم",
            "دعاء المتزوج لنفسه ودعاء شراء الدابة",
            "دعاء الريح",
            "دعاء الرعد",
            "من أدعية الاستسقاء",
            "الدعاء إذا نزل المطر",
        ],
        "blurb": "أدعية متفرقة من حصن المسلم.",
    },
}


def build_hisn_items(hisn: dict, key: str) -> list[dict]:
    block = hisn.get(key)
    if not block:
        return []
    texts = block.get("text") or []
    notes = block.get("footnote") or []
    items = []
    for i, text in enumerate(texts):
        text = strip_bom(str(text)).strip()
        if not text:
            continue
        note = strip_bom(str(notes[i])) if i < len(notes) else ""
        items.append({
            "id": f"hisn:{key}:{i+1}",
            "title": key,
            "text": text,
            "count": parse_count(text, note),
            "source": note or "حصن المسلم — سعيد بن علي بن وهف القحطاني",
            "book": "حصن المسلم",
        })
    return items


def build_adhkar(quran_surahs: list[dict]) -> dict:
    hisn = json.loads((SRC / "hisn.json").read_text(encoding="utf-8"))
    lists = []
    used_keys = set()

    for list_id, spec in HISN_MAP.items():
        items = []
        for key in spec["keys"]:
            used_keys.add(key)
            for it in build_hisn_items(hisn, key):
                it["listId"] = list_id
                it["id"] = f"{list_id}:{it['id']}"
                items.append(it)
        lists.append({
            "id": list_id,
            "title": spec["title"],
            "kind": spec["kind"],
            "blurb": spec["blurb"],
            "source": "حصن المسلم من أذكار الكتاب والسنة — سعيد بن علي بن وهف القحطاني",
            "items": items,
        })

    # Quranic duas from the actual Uthmani text
    qmap = {s["id"]: s for s in quran_surahs}
    q_items = []
    for sid, ayah, title in QURAN_DUAS:
        s = qmap[sid]
        a = next(x for x in s["ayahs"] if x["n"] == ayah)
        q_items.append({
            "id": f"dua-quran:{sid}:{ayah}",
            "listId": "dua-quran",
            "title": title,
            "text": a["t"],
            "count": 1,
            "source": f"{s['shortName']} {ar_digits(ayah)}",
            "book": "القرآن الكريم",
            "surahId": sid,
            "ayah": ayah,
        })
    lists.append({
        "id": "dua-quran",
        "title": "أدعية من القرآن",
        "kind": "dua",
        "blurb": "أدعية قرآنية بنص المصحف العثماني، مع رقم السورة والآية.",
        "source": "القرآن الكريم — الرسم العثماني",
        "items": q_items,
    })

    parent_keys = [(17, 24), (14, 40), (46, 15)]
    p_items = []
    titles = {
        (17, 24): "دعاء الرحمة للوالدين",
        (14, 40): "دعاء إبراهيم عليه السلام لذريته ولوالديه",
        (46, 15): "دعاء بر الوالدين",
    }
    for sid, ayah in parent_keys:
        s = qmap[sid]
        a = next(x for x in s["ayahs"] if x["n"] == ayah)
        p_items.append({
            "id": f"dua-parents:{sid}:{ayah}",
            "listId": "dua-parents",
            "title": titles[(sid, ayah)],
            "text": a["t"],
            "count": 1,
            "source": f"{s['shortName']} {ar_digits(ayah)}",
            "book": "القرآن الكريم",
            "surahId": sid,
            "ayah": ayah,
        })
    lists.append({
        "id": "dua-parents",
        "title": "أدعية الوالدين",
        "kind": "dua",
        "blurb": "أدعية قرآنية في بر الوالدين.",
        "source": "القرآن الكريم — الرسم العثماني",
        "items": p_items,
    })

    return {
        "source": {
            "name": "حصن المسلم من أذكار الكتاب والسنة",
            "author": "سعيد بن علي بن وهف القحطاني",
            "via": "نسخة JSON مقابلة على المطبوع (دار السجلات) — مستودع asellam/HisnElMuslim",
        },
        "lists": lists,
    }


def build_nawawi() -> dict:
    raw = json.loads((SRC / "nawawi.json").read_text(encoding="utf-8"))
    items = []
    for h in raw["hadiths"]:
        n = int(h.get("hadithnumber") or h.get("arabicnumber") or 0)
        if n <= 0:
            continue
        items.append({
            "id": f"nawawi-{n}",
            "number": n,
            "title": f"الحديث {ar_digits(n)}",
            "body": strip_bom(h["text"]).strip(),
        })
    return {
        "id": "nawawi40",
        "title": "الأربعون النووية",
        "author": "الإمام يحيى بن شرف النووي",
        "category": "hadith",
        "source": "متن الأربعين النووية، من طبعة معتمدة عبر sunnah.com / hadith-api (fawazahmed0)",
        "blurb": "اثنان وأربعون حديثاً في مباني الإسلام وقواعد الأحكام.",
        "sections": items,
    }


def split_usul(raw: str) -> list[dict]:
    text = clean_wiki(raw)
    markers = [
        "اعلم رحمك الله أنه يجب علينا تعلم أربع مسائل",
        "اعلم رحمك الله أنه يجب على كل مسلم ومسلمة، تعلم هذه المسائل الثلاث",
        "اعلم أرشدك الله لطاعته",
        "فإذا قيل لك: ما الأصول الثلاثة",
        "الأصل الأول: معرفة الرب",
        "الأصل الثاني: معرفة دين الإسلام بالأدلة",
        "الأصل الثالث: معرفة نبيكم محمد",
    ]
    # find occurrences
    idxs = []
    for m in markers:
        i = text.find(m)
        if i >= 0:
            idxs.append((i, m[:40]))
    idxs.sort()
    if not idxs:
        return [{"id": "usul-1", "title": "الأصول الثلاثة", "body": text}]
    sections = []
    if idxs[0][0] > 0:
        head = text[: idxs[0][0]].strip()
        if head:
            sections.append({"id": "usul-0", "title": "مقدمة", "body": head})
    titles = [
        "المسائل الأربع",
        "المسائل الثلاث",
        "الملّة",
        "الأصول الثلاثة",
        "الأصل الأول: معرفة الرب",
        "الأصل الثاني: معرفة دين الإسلام",
        "الأصل الثالث: معرفة النبي صلى الله عليه وسلم",
    ]
    for n, (start, _) in enumerate(idxs):
        end = idxs[n + 1][0] if n + 1 < len(idxs) else len(text)
        body = text[start:end].strip()
        title = titles[n] if n < len(titles) else f"فصل {ar_digits(n+1)}"
        sections.append({"id": f"usul-{n+1}", "title": title, "body": body})
    return sections


def build_qawaid(raw: str) -> list[dict]:
    text = clean_wiki(raw)
    parts = re.split(r"(القاعدة\s+\S+)", text)
    sections = []
    if parts and parts[0].strip():
        sections.append({"id": "qawaid-0", "title": "مقدمة", "body": parts[0].strip()})
    i = 1
    n = 1
    while i < len(parts):
        title = parts[i].strip()
        body = parts[i + 1].strip() if i + 1 < len(parts) else ""
        sections.append({"id": f"qawaid-{n}", "title": title, "body": f"{title}\n\n{body}".strip()})
        n += 1
        i += 2
    return sections or [{"id": "qawaid-1", "title": "القواعد الأربع", "body": text}]


def build_tuhfa(raw: str) -> list[dict]:
    texts = re.findall(r">([^<]{2,})<", raw)
    lines: list[str] = []
    for t in texts:
        t = html_lib.unescape(t).strip()
        t = re.sub(r"\s+", " ", t)
        if not re.search(r"[\u0600-\u06FF]", t):
            continue
        if len(t) < 6:
            continue
        if "font" in t.lower():
            continue
        lines.append(t)
    # group: short headings vs couplets
    sections: list[dict] = []
    current_title = "المقدمة"
    couplets: list[str] = []

    def flush():
        if couplets:
            body = "\n".join(couplets)
            sections.append({
                "id": f"tuhfa-{len(sections)+1}",
                "title": current_title,
                "body": body,
            })

    heading_re = re.compile(r"^(النون|الميم|حكم|أقسام|المد|اللام|الإدغام|المثلين|المتقاربين|المتجانسين|الوقف|المقطوع|التاءات|هاء|الخاتمة)")
    for line in lines:
        is_heading = (
            len(line) < 40
            and "  " not in line
            and not re.search(r"[،؛]", line)
            and (
                heading_re.search(line)
                or (not re.search(r"[َُِّْٰٱ]$", line) and " " in line and len(line.split()) <= 5 and "ـ" not in line)
            )
            and not re.search(r"[ىي]\s*$", line)  # poem lines often end with elongated yeh
        )
        # Treat as heading if it looks like a section title (no tatweel, short, no diacritics-heavy poetry)
        tatweel = "ـ" in line
        if not tatweel and len(line) <= 36 and not re.search(r"[َُِْٰ]", line):
            flush()
            couplets = []
            current_title = line
            continue
        couplets.append(line)
    flush()
    return sections or [{"id": "tuhfa-1", "title": "تحفة الأطفال", "body": "\n".join(lines)}]


def build_library() -> list[dict]:
    nawawi = build_nawawi()
    usul_raw = (SRC / "wiki" / "usul.txt").read_text(encoding="utf-8")
    qawaid_raw = (SRC / "wiki" / "qawaid.txt").read_text(encoding="utf-8")
    tuhfa_raw = (SRC / "wiki" / "tuhfa.txt").read_text(encoding="utf-8")
    tawhid_raw = (SRC / "wiki" / "tawhid.txt").read_text(encoding="utf-8")

    usul = {
        "id": "usul-thalatha",
        "title": "الأصول الثلاثة",
        "author": "محمد بن عبد الوهاب",
        "category": "aqeedah",
        "source": "ويكي مصدر — مطبوع ضمن مؤلفات الشيخ محمد بن عبد الوهاب، الجزء الأول",
        "blurb": "معرفة العبد ربه ودينه ونبيه بالأدلة.",
        "sections": split_usul(usul_raw),
    }
    qawaid = {
        "id": "qawaid-arba",
        "title": "القواعد الأربع",
        "author": "محمد بن عبد الوهاب",
        "category": "aqeedah",
        "source": "ويكي مصدر — ضمن مؤلفات الشيخ محمد بن عبد الوهاب",
        "blurb": "أربع قواعد في معرفة التوحيد والشرك.",
        "sections": build_qawaid(qawaid_raw),
    }
    tawhid_sections = split_wiki_sections(tawhid_raw, "مقدمة كتاب التوحيد")
    for i, s in enumerate(tawhid_sections):
        s["id"] = f"tawhid-{i+1}"
    tawhid = {
        "id": "kitab-tawhid",
        "title": "كتاب التوحيد",
        "author": "محمد بن عبد الوهاب",
        "category": "aqeedah",
        "source": "ويكي مصدر — كتاب التوحيد الذي هو حق الله على العبيد",
        "blurb": "أبواب في توحيد العبادة والتحذير من الشرك.",
        "sections": tawhid_sections,
    }
    tuhfa = {
        "id": "tuhfat-atfal",
        "title": "تحفة الأطفال",
        "author": "سليمان الجمزوري",
        "category": "tajweed",
        "source": "ويكي مصدر — تحفة الأطفال في تجويد القرآن، نظم الجمزوري سنة 1198 هـ",
        "blurb": "منظومة في تجويد القرآن للمبتدئين.",
        "sections": build_tuhfa(tuhfa_raw),
    }

    coming = [
        {
            "id": "umdat-ahkam",
            "title": "عمدة الأحكام",
            "author": "عبد الغني المقدسي",
            "category": "hadith",
            "comingSoon": True,
            "source": "سيُضاف من طبعة محققة بعد مراجعة النص كاملًا.",
            "blurb": "أحاديث الأحكام من الصحيحين.",
            "sections": [],
        },
        {
            "id": "bulugh-maram",
            "title": "بلوغ المرام",
            "author": "ابن حجر العسقلاني",
            "category": "hadith",
            "comingSoon": True,
            "source": "مدرج للنسخة القادمة بعد مراجعة النص.",
            "blurb": "منتقى أحاديث الأحكام.",
            "sections": [],
        },
        {
            "id": "wasitiyya",
            "title": "العقيدة الواسطية",
            "author": "ابن تيمية",
            "category": "aqeedah",
            "comingSoon": True,
            "source": "مدرج للنسخة القادمة بعد مراجعة النص.",
            "blurb": "عقيدة أهل السنة والجماعة.",
            "sections": [],
        },
        {
            "id": "ashmawiyya",
            "title": "العشماوية",
            "author": "عبد الباري العشماوي",
            "category": "fiqh",
            "comingSoon": True,
            "source": "سيُضاف من طبعة مالكية محققة مراعاةً للمذهب المالكي.",
            "blurb": "متن في الفقه المالكي.",
            "sections": [],
        },
        {
            "id": "murshid-muin",
            "title": "المرشد المعين",
            "author": "ابن عاشر",
            "category": "fiqh",
            "comingSoon": True,
            "source": "سيُضاف من طبعة مالكية محققة، وهو عمدة التدريس في البيئة الموريتانية.",
            "blurb": "نظم في الضروري من علوم الدين على مذهب مالك.",
            "sections": [],
        },
        {
            "id": "risala-qayrawani",
            "title": "رسالة ابن أبي زيد القيرواني",
            "author": "ابن أبي زيد القيرواني",
            "category": "fiqh",
            "comingSoon": True,
            "source": "مدرج للنسخة القادمة بعد مراجعة النص.",
            "blurb": "أمّ المذهب المالكي.",
            "sections": [],
        },
        {
            "id": "jazariyya",
            "title": "الجزرية",
            "author": "ابن الجزري",
            "category": "tajweed",
            "comingSoon": True,
            "source": "مدرج للنسخة القادمة بعد مراجعة النص.",
            "blurb": "المقدمة الجزرية في التجويد.",
            "sections": [],
        },
    ]

    return [nawawi, usul, qawaid, tawhid, tuhfa, *coming]


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    TAFSIR_DIR.mkdir(parents=True, exist_ok=True)

    print("Quran…")
    surahs, meta = build_quran()
    assert len(surahs) == 114, len(surahs)
    assert sum(len(s["ayahs"]) for s in surahs) == 6236
    (OUT / "quran.json").write_text(json.dumps({"surahs": surahs}, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    (OUT / "quran-meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

    print("Tafsir…")
    build_tafsir()

    print("Adhkar…")
    adhkar = build_adhkar(surahs)
    (OUT / "adhkar.json").write_text(json.dumps(adhkar, ensure_ascii=False, indent=2), encoding="utf-8")

    print("Library…")
    library = build_library()
    (OUT / "library.json").write_text(json.dumps({"books": library}, ensure_ascii=False, indent=2), encoding="utf-8")

    print("done")
    print("quran", (OUT / "quran.json").stat().st_size)
    print("adhkar lists", len(adhkar["lists"]), "items", sum(len(x["items"]) for x in adhkar["lists"]))
    print("books", [(b["id"], len(b["sections"])) for b in library])


if __name__ == "__main__":
    main()
