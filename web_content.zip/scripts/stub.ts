// Minimal DOM stubs so the engine modules can be exercised in Node.
const ctxStub: any = new Proxy(
  {},
  {
    get(_t, k: string) {
      if (k === 'createImageData')
        return (w: number, h: number) => ({ data: new Uint8ClampedArray(w * h * 4), width: w, height: h });
      if (k === 'getImageData')
        return (_x: number, _y: number, w: number, h: number) => ({
          data: new Uint8ClampedArray(w * h * 4),
          width: w,
          height: h,
        });
      if (k === 'createLinearGradient' || k === 'createRadialGradient')
        return () => ({ addColorStop() {} });
      if (k === 'measureText') return () => ({ width: 10 });
      if (k === 'canvas') return { width: 1, height: 1 };
      return () => {};
    },
    set() {
      return true;
    },
  }
);

class FakeCanvas {
  width = 1;
  height = 1;
  style: any = {};
  getContext() {
    return ctxStub;
  }
  addEventListener() {}
  removeEventListener() {}
  getBoundingClientRect() {
    return { left: 0, top: 0, width: 100, height: 100 };
  }
}

const g: any = globalThis;
g.document = {
  createElement: (tag: string) => (tag === 'canvas' ? new FakeCanvas() : { style: {} }),
  body: { appendChild() {}, style: {} },
  addEventListener() {},
  removeEventListener() {},
  exitPointerLock() {},
  pointerLockElement: null,
};
g.window = {
  devicePixelRatio: 1,
  innerWidth: 1280,
  innerHeight: 720,
  addEventListener() {},
  removeEventListener() {},
  matchMedia: () => ({ matches: false }),
  requestAnimationFrame: () => 0,
};
g.navigator = { userAgent: 'node', maxTouchPoints: 0 };
g.localStorage = {
  _d: {} as Record<string, string>,
  getItem(k: string) {
    return this._d[k] ?? null;
  },
  setItem(k: string, v: string) {
    this._d[k] = v;
  },
  removeItem(k: string) {
    delete this._d[k];
  },
};
g.HTMLCanvasElement = FakeCanvas;
g.AudioContext = undefined;
g.requestAnimationFrame = (cb: any) => setTimeout(() => cb(Date.now()), 16) as any;
g.cancelAnimationFrame = (id: any) => clearTimeout(id);
g.performance = g.performance ?? { now: () => Date.now() };

export {};
