// Re-bundles the worker whenever worker/ or shared/ changes (used by dev:watch).
import { build } from 'esbuild';
import { watch } from 'node:fs';

async function rebuild() {
  try {
    await build({
      entryPoints: ['worker/index.ts'],
      bundle: true,
      format: 'esm',
      target: 'es2022',
      platform: 'neutral',
      mainFields: ['module', 'main'],
      conditions: ['workerd', 'worker', 'browser'],
      outfile: 'build/worker.js',
      legalComments: 'none',
      external: ['node:*', 'cloudflare:*'],
      logLevel: 'warning',
    });
    console.log('[worker] rebuilt', new Date().toLocaleTimeString());
  } catch (err) {
    console.error('[worker] build failed', err.message);
  }
}

await rebuild();
for (const dir of ['worker', 'shared']) {
  watch(dir, { recursive: true }, () => rebuild());
}
console.log('[worker] watching worker/ and shared/ for changes');
