import puppeteer from "puppeteer-core";
import { createServer } from "http";
import { readFileSync, existsSync, mkdirSync, rmSync } from "fs";
import { extname, join } from "path";
import { execSync } from "child_process";

const APK = "apk/O-Caminho-do-Poder-1.0.0.apk";
const tmp = "scripts/apk-extract";
rmSync(tmp, { recursive: true, force: true });
mkdirSync(tmp, { recursive: true });
execSync(`unzip -o -j ${APK} "assets/www/*" -d ${tmp}`);
const html = join(process.cwd(), tmp, "index.html");
console.log("Extraido do APK:", html, existsSync(html) ? "OK" : "FALHOU");

const MIME = { ".html": "text/html", ".js": "text/javascript", ".css": "text/css" };
const server = createServer((req, res) => {
  res.writeHead(200, { "Content-Type": "text/html" });
  res.end(readFileSync(html));
});
await new Promise((r) => server.listen(4199, r));

const browser = await puppeteer.launch({
  executablePath: "/usr/bin/chromium", headless: "new",
  args: ["--no-sandbox", "--disable-setuid-sandbox", "--use-gl=swiftshader", "--enable-unsafe-swiftshader", "--disable-dev-shm-usage"],
});
let fails = 0;
const check = (n, c, x = "") => { console.log((c ? "  ok  | " : "  FAIL| ") + n + (x ? " (" + x + ")" : "")); if (!c) fails++; };

for (const mode of ["http", "file"]) {
  console.log(`\n=== MODO ${mode.toUpperCase()} (${mode === "http" ? "origem https do WebView" : "fallback file:// do WebView"}) ===`);
  const page = await browser.newPage();
  await page.setViewport({ width: 412, height: 915, isMobile: true, hasTouch: true });
  const errs = [];
  page.on("pageerror", (e) => errs.push(e.message));
  page.on("console", (m) => { if (m.type() === "error" && !/favicon/i.test(m.text())) errs.push(m.text()); });
  const url = mode === "http" ? "http://localhost:4199/index.html" : "file://" + html;
  await page.goto(url, { waitUntil: "load" });
  await new Promise((r) => setTimeout(r, 1200));
  const t = await page.evaluate(() => document.body.innerText);
  check("abre direto na tela inicial (sem login)", /O CAMINHO DO PODER/i.test(t) && /Novo Jogo/i.test(t));
  check("botao Continuar presente", /Continuar/i.test(t));

  const hooks = await page.evaluate(() => ({
    pause: typeof window.__gamePause, resume: typeof window.__gameResume, back: typeof window.__gameBack,
  }));
  check("hooks nativos presentes", hooks.pause === "function" && hooks.resume === "function" && hooks.back === "function", JSON.stringify(hooks));

  await page.evaluate(() => { [...document.querySelectorAll("button")].find((b) => b.innerText.includes("Novo Jogo"))?.click(); });
  await new Promise((r) => setTimeout(r, 1000));
  const t2 = await page.evaluate(() => document.body.innerText);
  check("entra no jogo", /VILA DE CINZAS/i.test(t2));

  // simula o ciclo de vida do Android
  const saved = await page.evaluate(() => { window.__gamePause(); return !!localStorage.getItem("caminho_do_poder_save_v1"); });
  check("app em segundo plano salva o jogo", saved === true);

  const backRes = await page.evaluate(() => window.__gameBack());
  check("botao voltar do Android nao fecha o jogo sem painel", backRes === false);

  // salva e recarrega
  await page.evaluate(() => { window.__gamePause(); });
  await page.reload({ waitUntil: "load" });
  await new Promise((r) => setTimeout(r, 900));
  const t3 = await page.evaluate(() => document.body.innerText);
  const canContinue = await page.evaluate(() => {
    const b = [...document.querySelectorAll("button")].find((x) => x.innerText.includes("Continuar"));
    return b ? !b.disabled : false;
  });
  if (mode === "http") {
    check("continuar habilitado apos recarregar", canContinue);
    await page.evaluate(() => { [...document.querySelectorAll("button")].find((b) => b.innerText.includes("Continuar"))?.click(); });
    await new Promise((r) => setTimeout(r, 900));
    const t4 = await page.evaluate(() => document.body.innerText);
    check("progresso restaurado (lei 1 ativa)", /LEI 1 \/ 48/i.test(t4));
  } else {
    console.log("  nota | em file:// o Chrome bloqueia localStorage (o jogo usa fallback em memoria, como previsto)");
  }
  check("sem erros de JS", errs.length === 0, errs.join(" | "));
  await page.close();
}

console.log(fails === 0 ? "\nAPK: TODOS OS TESTES OK" : `\nAPK: ${fails} FALHAS`);
await browser.close();
server.close();
if (fails) process.exit(1);
