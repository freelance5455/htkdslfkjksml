/**
 * Builds standalone/index.html — the whole Keep Tracked app (React UI,
 * animations, compiled Tailwind CSS, on-device database) inlined into ONE
 * html file. Use it for real Android packaging:
 *
 *   • Capacitor:  npx cap init … --web-dir standalone   (assets baked into APK)
 *   • Any WebView wrapper / online APK builder that accepts an html file
 *   • Or just open it directly in a browser — works from file://
 *
 * Prerequisite: run `npm run build` once so the Tailwind CSS exists.
 */
import { execFileSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

const root = path.resolve(process.cwd());
const tmp = path.join(root, ".tmp-standalone");
fs.mkdirSync(tmp, { recursive: true });

console.log("→ bundling app with esbuild…");
execFileSync(
  "npx",
  [
    "-y",
    "esbuild",
    "standalone-src/main.tsx",
    "--bundle",
    `--outfile=${path.join(tmp, "app.js")}`,
    "--format=iife",
    "--jsx=automatic",
    "--alias:@=./src",
    "--define:process.env.NODE_ENV=\"production\"",
    "--minify",
    "--target=es2019",
    "--log-level=warning",
  ],
  { stdio: "inherit", cwd: root },
);

const chunksDir = path.join(root, ".next/static/chunks");
if (!fs.existsSync(chunksDir)) {
  throw new Error("Run `npm run build` first — the compiled Tailwind CSS is required.");
}
const cssFiles = fs
  .readdirSync(chunksDir)
  .filter((f) => f.endsWith(".css"))
  .map((f) => path.join(chunksDir, f));
if (!cssFiles.length) throw new Error("No compiled CSS found — run `npm run build` first.");
const css = cssFiles.map((f) => fs.readFileSync(f, "utf8")).join("\n");

let js = fs.readFileSync(path.join(tmp, "app.js"), "utf8");
js = js.replace(/<\/script/gi, "<\\/script");

const html = `<!doctype html>
<html lang="en" data-theme="dark">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover" />
<meta name="theme-color" content="#080b0a" />
<meta name="mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
<title>Keep Tracked</title>
<script>
(function () {
  try {
    var stored = localStorage.getItem("kt-theme");
    var sys = window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
    var mode = stored === "light" || stored === "dark" ? stored : stored === "system" ? sys : "dark";
    document.documentElement.setAttribute("data-theme", mode);
  } catch (e) {
    document.documentElement.setAttribute("data-theme", "dark");
  }
})();
</script>
<style>
${css}
</style>
</head>
<body class="min-h-full bg-bg text-ink antialiased">
<div id="root" style="height:100dvh"></div>
<noscript>Keep Tracked needs JavaScript enabled.</noscript>
<script>
${js}
</script>
</body>
</html>
`;

const outDir = path.join(root, "standalone");
fs.mkdirSync(outDir, { recursive: true });
fs.writeFileSync(path.join(outDir, "index.html"), html);
fs.rmSync(tmp, { recursive: true, force: true });
console.log(`✓ standalone/index.html written (${(html.length / 1024).toFixed(0)} KB, single file, fully offline)`);
