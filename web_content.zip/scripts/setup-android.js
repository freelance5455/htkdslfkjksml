// À lancer une fois après "npx cap add android" : ajoute la permission des notifications (Android 13+).
const fs = require("fs"), path = require("path");
const f = path.join(__dirname, "..", "android", "app", "src", "main", "AndroidManifest.xml");
if (!fs.existsSync(f)) { console.error("android/ introuvable"); process.exit(1); }
let x = fs.readFileSync(f, "utf8");
if (!x.includes("POST_NOTIFICATIONS")) {
  x = x.replace(/<\/manifest>/, '    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />\n</manifest>');
  fs.writeFileSync(f, x); console.log("POST_NOTIFICATIONS ajoutée");
}
