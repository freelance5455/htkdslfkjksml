/**
 * ==============================================================================
 * CHAUFALAND - Minecraft Bedrock Addon (Script API / @minecraft/server-net)
 * Archivo: scripts/main.js
 * Descripción: Conecta el servidor/mundo de Minecraft Bedrock con el puente
 *              WebSocket de CHAUFALAND para sincronizar en tiempo real los
 *              jugadores, coordenadas (X, Y, Z), dimensión, salud y chat.
 * ==============================================================================
 */

import { world, system } from "@minecraft/server";
import { http, HttpRequest, HttpRequestMethod } from "@minecraft/server-net";

// CONFIGURACIÓN DEL PUENTE DE CHAUFALAND
// Cambia esta URL según el dominio o IP configurada en tu panel de control CHAUFALAND
const BRIDGE_WS_URL = "ws://localhost:3000/bedrock-ws";
const BRIDGE_HTTP_FALLBACK = "http://localhost:3000/api/bedrock/event";

// Control de conexión WebSocket y reintentos
let wsClient = null;
let isConnected = false;
let reconnectTimer = null;

// Caché de jugadores activos y sus estados previos
const activePlayers = new Map();

/**
 * Inicializar WebSocket nativo de Bedrock o utilizar Net API
 */
function connectWebSocket() {
  try {
    // Si la plataforma soporta WebSocket global nativo (Bedrock Script API con WebSocket activado)
    if (typeof WebSocket !== "undefined") {
      wsClient = new WebSocket(BRIDGE_WS_URL);

      wsClient.onopen = () => {
        isConnected = true;
        system.run(() => {
          world.sendMessage("§a[CHAUFALAND]§r Puente en tiempo real conectado exitosamente.");
        });

        // Registrar todos los jugadores ya presentes
        for (const player of world.getAllPlayers()) {
          sendPacket("player_join", {
            gamerTag: player.name,
            dimension: player.dimension.id.replace("minecraft:", ""),
            x: Math.round(player.location.x),
            y: Math.round(player.location.y),
            z: Math.round(player.location.z),
            health: getPlayerHealth(player)
          });
        }
      };

      wsClient.onclose = () => {
        isConnected = false;
        scheduleReconnect();
      };

      wsClient.onerror = (err) => {
        isConnected = false;
      };
    } else {
      // Fallback para entornos donde WebSocket no está expuesto en Script API
      isConnected = false;
    }
  } catch (err) {
    isConnected = false;
    scheduleReconnect();
  }
}

function scheduleReconnect() {
  if (reconnectTimer) return;
  reconnectTimer = system.runTimeout(() => {
    reconnectTimer = null;
    connectWebSocket();
  }, 100); // 5 segundos (20 ticks por segundo)
}

/**
 * Enviar paquete de datos al servidor de CHAUFALAND
 */
function sendPacket(event, payload) {
  const messageData = {
    event,
    ...payload,
    timestamp: Date.now()
  };

  const jsonString = JSON.stringify(messageData);

  // Intentar envío por WebSocket
  if (isConnected && wsClient && wsClient.readyState === 1) {
    try {
      wsClient.send(jsonString);
      return;
    } catch (e) {
      isConnected = false;
    }
  }

  // Fallback opcional mediante HTTP POST usando @minecraft/server-net
  try {
    const request = new HttpRequest(BRIDGE_HTTP_FALLBACK);
    request.setMethod(HttpRequestMethod.Post);
    request.setHeader("Content-Type", "application/json");
    request.setBody(jsonString);
    http.request(request).catch(() => {});
  } catch (httpErr) {
    // Silencioso para no saturar consola del servidor
  }
}

/**
 * Obtener salud del jugador de manera segura
 */
function getPlayerHealth(player) {
  try {
    const healthComponent = player.getComponent("minecraft:health");
    return healthComponent ? Math.round(healthComponent.currentValue) : 20;
  } catch (e) {
    return 20;
  }
}

/* ==============================================================================
   LISTENERS DE EVENTOS DE MINECRAFT BEDROCK
   ============================================================================== */

// 1. Detección de entrada de jugador
world.afterEvents.playerSpawn.subscribe((event) => {
  const player = event.player;
  const isInitialSpawn = event.initialSpawn;

  if (isInitialSpawn) {
    const dim = player.dimension.id.replace("minecraft:", "");
    activePlayers.set(player.name, {
      x: player.location.x,
      y: player.location.y,
      z: player.location.z,
      dimension: dim
    });

    sendPacket("player_join", {
      gamerTag: player.name,
      dimension: dim,
      x: Math.round(player.location.x),
      y: Math.round(player.location.y),
      z: Math.round(player.location.z),
      health: getPlayerHealth(player)
    });
  }
});

// 2. Detección de salida de jugador
world.afterEvents.playerLeave.subscribe((event) => {
  const playerName = event.playerName;
  activePlayers.delete(playerName);

  sendPacket("player_leave", {
    gamerTag: playerName
  });
});

// 3. Puente de Chat en tiempo real hacia la Web / App de CHAUFALAND
world.beforeEvents.chatSend.subscribe((event) => {
  const senderName = event.sender.name;
  const message = event.message;

  sendPacket("chat_message", {
    gamerTag: senderName,
    message: message
  });
});

// 4. Telemetría Periódica de Posición y Dimensión (Cada 2 segundos = 40 ticks)
system.runInterval(() => {
  for (const player of world.getAllPlayers()) {
    const loc = player.location;
    const dim = player.dimension.id.replace("minecraft:", "");
    const health = getPlayerHealth(player);

    const prev = activePlayers.get(player.name);
    // Verificar si se movió al menos 1 bloque o cambió de dimensión
    const moved = !prev || 
      Math.abs(prev.x - loc.x) > 1 || 
      Math.abs(prev.y - loc.y) > 1 || 
      Math.abs(prev.z - loc.z) > 1 || 
      prev.dimension !== dim;

    if (moved) {
      activePlayers.set(player.name, {
        x: loc.x,
        y: loc.y,
        z: loc.z,
        dimension: dim
      });

      sendPacket("player_telemetry", {
        gamerTag: player.name,
        dimension: dim,
        x: Math.round(loc.x),
        y: Math.round(loc.y),
        z: Math.round(loc.z),
        health: health
      });
    }
  }
}, 40);

// Iniciar conexión inicial al arrancar el addon
connectWebSocket();
console.warn("[CHAUFALAND Addon] Addon de Bedrock cargado e inicializado.");
