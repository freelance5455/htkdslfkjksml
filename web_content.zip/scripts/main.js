/**
 * CHAUFALAND - Minecraft Bedrock Script API Addon (Behavior Pack)
 * Archivo: scripts/main.js
 * 
 * Conecta el servidor de Minecraft Bedrock con el servidor Web y de Voz
 * mediante WebSockets para transmitir en tiempo real:
 *  - Jugadores conectados / desconectados
 *  - Coordenadas X, Y, Z
 *  - Dimensión actual (Overworld, Nether, The End)
 *  - Puntos de salud / Vida
 * 
 * Requiere:
 *  - Módulos en manifest.json:
 *    "@minecraft/server" versión >= 1.10.0
 *    "@minecraft/server-net" versión >= 1.0.0-beta
 * 
 * Creado para: CHAUFALAND por JuancitoChen23
 */

import { world, system } from "@minecraft/server";
import { http, HttpRequest, HttpRequestMethod } from "@minecraft/server-net";

// CONFIGURACIÓN DEL PUENTE WEBSOCKET / HTTP
// Cambia esta URL por la IP o dominio público de tu servidor de Chaufaland (ej: "http://tu-servidor.com:3000")
const SERVER_HTTP_BASE = "http://127.0.0.1:3000";
const BRIDGE_ENDPOINT = `${SERVER_HTTP_BASE}/api/minecraft/telemetry`;

// Intervalo de envío de telemetría en ticks de Minecraft (20 ticks = 1 segundo, 40 ticks = 2 segundos)
const TELEMETRY_INTERVAL_TICKS = 40;

console.warn("[CHAUFALAND] Addon Script API inicializado correctamente");

/**
 * Función para enviar paquetes JSON al servidor backend de Chaufaland
 */
async function sendPayload(payload) {
  try {
    const request = new HttpRequest(BRIDGE_ENDPOINT);
    request.setMethod(HttpRequestMethod.Post);
    request.setHeaders([
      { name: "Content-Type", value: "application/json" },
      { name: "X-Server-Origin", value: "CHAUFALAND_BEDROCK" }
    ]);
    request.setBody(JSON.stringify(payload));

    const response = await http.request(request);
    if (response.status !== 200) {
      // Silencioso en caso de no estar encendido el backend
    }
  } catch (err) {
    // Si el servidor web está apagado, capturamos el error sin crashear el juego
  }
}

/**
 * Recopila la telemetría de todos los jugadores en línea en el servidor
 */
function collectPlayersTelemetry() {
  const players = world.getAllPlayers();
  if (!players || players.length === 0) return;

  const batch = [];

  for (const player of players) {
    try {
      const loc = player.location;
      const dimId = player.dimension.id.replace("minecraft:", "");
      
      // Obtener salud si está disponible
      let health = 20;
      const healthComp = player.getComponent("minecraft:health");
      if (healthComp && healthComp.currentValue !== undefined) {
        health = Math.round(healthComp.currentValue);
      }

      batch.push({
        gamertag: player.name,
        x: Math.round(loc.x * 10) / 10,
        y: Math.round(loc.y * 10) / 10,
        z: Math.round(loc.z * 10) / 10,
        dimension: dimId,
        health: health
      });
    } catch (e) {
      console.warn(`[CHAUFALAND] Error leyendo datos del jugador ${player.name}: ${e}`);
    }
  }

  if (batch.length > 0) {
    sendPayload({
      type: "telemetry_batch",
      players: batch,
      timestamp: Date.now()
    });
  }
}

// Bucle periódico de telemetría (cada 2 segundos)
system.runInterval(() => {
  collectPlayersTelemetry();
}, TELEMETRY_INTERVAL_TICKS);

// Evento: Jugador entra al mundo
world.afterEvents.playerSpawn.subscribe((event) => {
  const player = event.player;
  const isInitialSpawn = event.initialSpawn;

  if (isInitialSpawn) {
    const loc = player.location;
    const dim = player.dimension.id.replace("minecraft:", "");

    console.warn(`[CHAUFALAND] Jugador conectado: ${player.name}`);

    sendPayload({
      type: "player_join",
      gamertag: player.name,
      x: Math.round(loc.x),
      y: Math.round(loc.y),
      z: Math.round(loc.z),
      dimension: dim
    });
  }
});

// Evento: Jugador sale del mundo
world.afterEvents.playerLeave.subscribe((event) => {
  console.warn(`[CHAUFALAND] Jugador desconectado: ${event.playerName}`);

  sendPayload({
    type: "player_leave",
    gamertag: event.playerName
  });
});
