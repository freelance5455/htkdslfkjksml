import { eq } from "drizzle-orm";
import { db, eventsTable } from "@workspace/db";

const catalog = [
  {
    name: "Skyline Saturdays",
    venue: "The Rooftop",
    address: "23 Red Hills Road, Kingston 10",
    eventDate: new Date("2026-09-05T21:00:00-05:00"),
    endDate: new Date("2026-09-06T02:00:00-05:00"),
    basePriceJmd: 2000,
    serviceFeeJmd: 300,
    doorChargeJmd: 200,
    vibeTags: ["Dancehall", "Rooftop", "Afrobeats"],
    crowdLevel: "Hype",
    crowdLabel: "26–50 people here",
    rating: 4.6,
    reviewCount: 47,
    accent: "#a96cff",
    mark: "SKY",
    latitude: 18.0409,
    longitude: -76.8017,
    description: "Kingston’s best view meets a heavyweight dancehall set. Dress easy, come ready to move.",
  },
  {
    name: "Sunset Soca Social",
    venue: "The Deck",
    address: "8 Trafalgar Road, Kingston 6",
    eventDate: new Date("2026-09-05T18:30:00-05:00"),
    endDate: new Date("2026-09-05T23:30:00-05:00"),
    basePriceJmd: 1500,
    serviceFeeJmd: 200,
    doorChargeJmd: 100,
    vibeTags: ["Soca", "Chill", "Sunset"],
    crowdLevel: "Buzzing",
    crowdLabel: "11–25 people here",
    rating: 4.8,
    reviewCount: 31,
    accent: "#ffd36a",
    mark: "SOC",
    latitude: 18.0062,
    longitude: -76.7871,
    description: "Golden hour, cold drinks, and the kind of soca that keeps the whole deck singing.",
  },
  {
    name: "Dubwise After Dark",
    venue: "Dubwise Jamaica",
    address: "1 Holborn Road, Kingston 10",
    eventDate: new Date("2026-09-05T22:00:00-05:00"),
    endDate: new Date("2026-09-06T03:00:00-05:00"),
    basePriceJmd: 2500,
    serviceFeeJmd: 300,
    doorChargeJmd: 200,
    vibeTags: ["Reggae", "Afterparty", "Late night"],
    crowdLevel: "Packed",
    crowdLabel: "50+ people here",
    rating: 4.4,
    reviewCount: 62,
    accent: "#ff4f9a",
    mark: "DUB",
    latitude: 18.0186,
    longitude: -76.7938,
    description: "A deep, late-night sound system session for people who know where the night really starts.",
  },
];

for (const item of catalog) {
  const existing = await db.select({ id: eventsTable.id }).from(eventsTable).where(eq(eventsTable.name, item.name)).limit(1);
  if (existing[0]) {
    await db.update(eventsTable).set({ ...item, updatedAt: new Date() }).where(eq(eventsTable.id, existing[0].id));
  } else {
    await db.insert(eventsTable).values(item);
  }
}

console.log(`Seeded ${catalog.length} Bounce events.`);
await db.$client.end();