import fs from 'fs';
import path from 'path';

const distDir = path.join(process.cwd(), 'dist');
const indexPath = path.join(distDir, 'index.html');

if (fs.existsSync(indexPath)) {
  let html = fs.readFileSync(indexPath, 'utf-8');

  const assetsDir = path.join(distDir, 'assets');
  if (fs.existsSync(assetsDir)) {
    const files = fs.readdirSync(assetsDir);
    
    // Inline CSS
    files.filter(f => f.endsWith('.css')).forEach(cssFile => {
      const cssPath = path.join(assetsDir, cssFile);
      if (fs.existsSync(cssPath)) {
        const cssContent = fs.readFileSync(cssPath, 'utf-8');
        html = html.replace(
          new RegExp(`<link[^>]*href="[^"]*${cssFile}"[^>]*>`, 'g'),
          `<style>${cssContent}</style>`
        );
      }
    });

    // Inline JS (exclude service worker)
    files.filter(f => f.endsWith('.js') && !f.includes('registerSW') && !f.includes('workbox')).forEach(jsFile => {
      const jsPath = path.join(assetsDir, jsFile);
      if (fs.existsSync(jsPath)) {
        const jsContent = fs.readFileSync(jsPath, 'utf-8');
        html = html.replace(
          new RegExp(`<script[^>]*src="[^"]*${jsFile}"[^>]*></script>`, 'g'),
          `<script>${jsContent}</script>`
        );
      }
    });
  }

  fs.writeFileSync(indexPath, html, 'utf-8');
  console.log('✅ Successfully inlined all assets into single-file dist/index.html.');
}
