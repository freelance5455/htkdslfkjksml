import { chromium } from '@playwright/test';
import assert from 'node:assert/strict';

const browser = await chromium.launch({
  headless: true,
  args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
});
const context = await browser.newContext({ viewport: { width: 1280, height: 720 } });
await context.grantPermissions(['accelerometer', 'gyroscope'], { origin: 'http://localhost:5173' });

const page = await context.newPage();
const errors = [];
page.on('pageerror', err => errors.push(err.message));
page.on('console', msg => { if (msg.type() === 'error') errors.push(msg.text()); });

await page.goto('http://localhost:5173', { waitUntil: 'networkidle' });
await page.waitForTimeout(1000);

// Check Mountain Summit destination exists in menu
assert.equal(await page.title(), 'Rimba VR — Step into Nature');
assert.ok(await page.getByRole('button', { name: 'Select Mountain Summit 🗻' }).isVisible());
assert.equal(await page.locator('.destination').count(), 4);

await page.screenshot({ path: 'artifacts/summit-menu.png' });

// Select Mountain Summit and enter VR Mode
await page.getByRole('button', { name: 'Select Mountain Summit 🗻' }).click();
await page.getByRole('button', { name: 'Explore in VR' }).click();

await page.locator('canvas').waitFor({ timeout: 30000 });
await page.locator('.scene-loading').waitFor({ state: 'detached', timeout: 30000 });
await page.waitForTimeout(1500);

// Verify VR Cardboard lens mask with center divider is visible
assert.equal(await page.locator('.vr-cardboard-mask-overlay').count(), 1);
assert.equal(await page.locator('.scene-error').count(), 0);
await page.screenshot({ path: 'artifacts/summit-vr-view.png' });

// Test forward walking along the mountain peak
await page.keyboard.down('w');
await page.waitForTimeout(2000);
await page.keyboard.up('w');
await page.waitForTimeout(500);
const walked = parseFloat(await page.getByTestId('distance').textContent());
assert.ok(walked > 0.1, `Walk distance should increase, got ${walked}`);

// Test switching back to Mirror Lake map to ensure multi-map switching works
await page.getByRole('button', { name: 'Return to menu' }).click();
await page.waitForTimeout(500);
await page.getByRole('button', { name: /Select Mirror Lake/i }).click();
await page.getByRole('button', { name: 'Explore in VR' }).click();
await page.locator('canvas').waitFor({ timeout: 30000 });
await page.waitForTimeout(1000);
assert.equal(await page.locator('.scene-error').count(), 0);
await page.screenshot({ path: 'artifacts/lake-vr-view.png' });
await page.getByRole('button', { name: 'Return to menu' }).click();

console.log(JSON.stringify({
  result: 'passed',
  mountainSummitWorld: true,
  mapSwitching: true,
  distanceWalked: walked,
  consoleErrors: errors,
}, null, 2));

await browser.close();
assert.equal(errors.length, 0);
