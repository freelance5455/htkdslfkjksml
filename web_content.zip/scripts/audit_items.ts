import { STAGES_DATABASE } from '../src/data/sampleStages';
import { normalizeArabicString } from '../src/engine/normalization';

const userItems = [
  'شوبان',
  'أوماكس',
  'اوماكس',
  'عز الدين أيبك',
  'عز الدين ايبك',
  'أيبك',
  'كاظم الساهر',
  'أحمد زويل',
  'احمد زويل',
  'زويل',
  'عمر المختار',
  'مرسيدس',
  'غزوة الأبواء',
  'الأبواء',
  'غطفان',
  'يوركشاير',
  'يورك شاير'
];

console.log('=== AUDITING USER ITEMS AGAINST STAGES 1 TO 34 ===');
for (let s = 0; s < 34; s++) {
  const stage = STAGES_DATABASE[s];
  for (const q of stage.questions) {
    const qA = normalizeArabicString(q.answer).replace(/\s+/g, '');
    const qC = normalizeArabicString(q.clue);

    for (const item of userItems) {
      const normItem = normalizeArabicString(item).replace(/\s+/g, '');
      if (qA === normItem || (normItem.length > 3 && (qA.includes(normItem) || normItem.includes(qA)))) {
        console.log(`[ANS MATCH] Item: "${item}" in Stage ${stage.id} Q${q.number}: Answer="${q.answer}"`);
      }
      if (normItem.length > 3 && qC.includes(normItem)) {
        console.log(`[CLUE MATCH] Item: "${item}" in Stage ${stage.id} Q${q.number} Clue: "${q.clue}" (Answer="${q.answer}")`);
      }
    }
  }
}
console.log('Audit complete.');
