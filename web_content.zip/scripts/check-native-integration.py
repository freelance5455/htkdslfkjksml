#!/usr/bin/env python3
"""Static acceptance checks for the Space Runner Android bridge + game catalog."""
import csv
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CATALOG = ROOT / "MYKET-PRODUCT-CATALOG-fa.csv"
GAME = ROOT / "src/game/space-runner.js"
NATIVE = ROOT / "android/app/src/main/java/ir/egames/donandefazayi/MainActivity.java"
GRADLE = ROOT / "android/app/build.gradle"
ASSET = ROOT / "android/app/src/main/assets/index.html"
STANDALONE = ROOT / "artifacts/donande-fazayi-v8.0.html"
CATALOG_ASSET = ROOT / "android/app/src/main/assets/MYKET-PRODUCT-CATALOG-fa.csv"

with CATALOG.open(encoding="utf-8-sig", newline="") as handle:
    rows = list(csv.DictReader(handle))
ids = [row["productId"].strip() for row in rows]
types = [row["productType"].strip() for row in rows]
assert len(ids) == 75, f"Expected 75 catalog rows, found {len(ids)}"
assert len(set(ids)) == len(ids), "Duplicate SKU in catalog"
assert types.count("consumable") == 6, f"Expected 6 consumables, found {types.count('consumable')}"
assert types.count("non_consumable") == 69, f"Expected 69 non-consumables, found {types.count('non_consumable')}"
assert all(sku.startswith("sr_") for sku in ids), "Unexpected SKU naming"

js = GAME.read_text(encoding="utf-8")
java = NATIVE.read_text(encoding="utf-8")
gradle = GRADLE.read_text(encoding="utf-8")
manifest = (ROOT / "android/app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
backup_rules = (ROOT / "android/app/src/main/res/xml/backup_rules.xml").read_text(encoding="utf-8")
data_extraction_rules = (ROOT / "android/app/src/main/res/xml/data_extraction_rules.xml").read_text(encoding="utf-8")

# All purchase paths must use catalog IDs; older direct categories were not catalog SKUs.
for token in [
    'storeSku("vip", "royal")',
    'storeSku("no", "ads", "forever")',
    'storeSku("satellite", "companion")',
    'storeSku("gems", gems, price)',
    'storeSku("item", "skin", key)',
    'storeSku("item", "ground", key)',
    'storeSku("item", "aura", key)',
    'storeSku("item", category, key)',
    'storeSku("pack", p.id)',
    'storeSku("offer", o.id)',
]:
    assert token in js, f"Missing expected SKU builder: {token}"
assert 'storeSku("ground", key)' not in js
assert 'storeSku("aura", key)' not in js

# Native bridge must use real SDKs and never accept game-authored success flags.
for token in [
    'implementation \'ir.myket:billing:2.2\'',
    'implementation \'ir.tapsell.plus:tapsell-plus-sdk-android:2.3.3\'',
]:
    assert token in gradle, f"Missing SDK dependency: {token}"
for token in [
    'billing.launchPurchaseFlow',
    'billing.queryInventoryAsync',
    'billing.consumeAsync',
    'purchase.getDeveloperPayload()',
    'purchase.getToken()',
    'TapsellPlus.requestRewardedVideoAd',
    'TapsellPlus.showRewardedVideoAd',
    'public void onRewarded(TapsellPlusAdModel model)',
    'put(out, "rewardEarned", true)',
    'savePendingGrant',
    'markGrantDelivered',
    'myket://details?id=',
]:
    assert token in java, f"Missing native integration requirement: {token}"
assert 'if(window.__SPACE_RUNNER_BILLING_READY === true) syncNativeEntitlements();' in js
assert 'result.status === "pending"' in js
assert 'result.status === "completed" && result.rewardEarned === true' in js
assert 'result.verified === true' in js
assert 'spaceRunnerV83' in js, "Existing local save key must remain in source"

# Monetization policy: player-initiated rewarded video only. Do not add
# interstitial, banner, native, or other unsolicited ad placements.
for label, source in {
    "game JavaScript": js,
    "Android Native": java,
    "Gradle dependencies": gradle,
    "Android manifest": manifest,
    "standalone HTML": STANDALONE.read_text(encoding="utf-8"),
    "Android HTML asset": ASSET.read_text(encoding="utf-8"),
}.items():
    for forbidden in (
        "interstitial", "requestBannerAd", "showBannerAd",
        "requestNativeAd", "showNativeAd", "requestStandardAd", "showStandardAd",
    ):
        assert forbidden.lower() not in source.lower(), (
            f"Forbidden ad format marker {forbidden!r} found in {label}"
        )

sdk_calls = re.findall(r"\bTapsellPlus\.(\w+)\s*\(", java)
assert sorted(sdk_calls) == sorted([
    "initialize", "requestRewardedVideoAd", "showRewardedVideoAd"
]), f"Unexpected Tapsell SDK calls: {sdk_calls}"
assert java.count('case "showRewardedAd"') == 1
assert 'case "showInterstitialAd"' not in java
assert js.count('callSpaceRunnerNative("showRewardedAd"') == 1
assert len(re.findall(r"\bplayAd\s*\(", js)) == 7, (
    "Expected one playAd definition and six explicit reward-flow call sites"
)
for trigger in (
    'el("spinWheelAd").onclick = () =>',
    'on("watchAdGemsMenu", () => playAd(',
    'on("watchAdGemsShop", () => playAd(',
    'on("watchAdContinue", () => tryContinueAd())',
    'on("doubleDaily", () =>',
    'on("doubleLevel", () =>',
):
    assert trigger in js, f"Rewarded ad is missing its explicit player action: {trigger}"
assert 'placementId !== "continue-revive"' in js
assert '"continue-forced"' not in js, "Ad placement must not be described as forced"
assert ASSET.exists() and STANDALONE.exists(), "Standalone or Android HTML asset missing"
assert ASSET.read_bytes() == STANDALONE.read_bytes(), "Android asset is stale; rebuild standalone and recopy"
assert CATALOG_ASSET.exists() and CATALOG_ASSET.read_bytes() == CATALOG.read_bytes(), "Android product catalog is stale"
assert 'android:fullBackupContent="@xml/backup_rules"' in manifest
assert 'android:dataExtractionRules="@xml/data_extraction_rules"' in manifest
assert 'domain="sharedpref" path="space_runner_native_v1.xml"' in backup_rules
assert 'domain="sharedpref" path="space_runner_native_v1.xml"' in data_extraction_rules
assert (ROOT / "android/.gitignore").exists() and "secrets.properties" in (ROOT / "android/.gitignore").read_text()

print("PASS: 75 catalog SKUs (6 consumable / 69 non-consumable), no duplicates")
print("PASS: purchase SKU builders align with catalog conventions")
print("PASS: Myket billing + Tapsell rewarded-ad Native bridge markers present")
print("PASS: no interstitial/banner/native ad formats; rewarded video only")
print("PASS: all six rewarded-ad call sites are bound to explicit player actions")
print("PASS: Myket inventory restore also checks the SKU-specific developer payload")
print("PASS: existing local save key preserved")
print("PASS: Android HTML asset matches standalone game HTML")
print("PASS: Android catalog matches root catalog; native purchase ledger excluded from backup/transfer")
print("NOTE: these are static source checks, not an Android APK build or live SDK/device test")
