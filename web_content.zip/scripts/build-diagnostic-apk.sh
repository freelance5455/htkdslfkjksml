#!/usr/bin/env bash
set -e

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

echo "=============================================================================="
echo "🧪 Building ROOT-CAUSE DIAGNOSTIC Android APK (Minimal HTML Test)..."
echo "=============================================================================="

# 1. Clean assets and prepare minimal test HTML
rm -rf android/app/src/main/assets/public
mkdir -p android/app/src/main/assets/public
mkdir -p public/downloads
mkdir -p dist/downloads

cat << 'EOF' > android/app/src/main/assets/public/index.html
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Android WebView Test</title>
</head>
<body style="background:white;color:black;text-align:center;padding-top:100px;font-family:sans-serif;">
<h1>ANDROID WEBVIEW TEST</h1>
<p>If you can see this, Android WebView is working.</p>
</body>
</html>
EOF

cp android/app/src/main/assets/public/index.html dist/index.html

# 2. Build Android Release APK with Gradle
echo "⚙️ Building Gradle Release APK..."
cd android
chmod +x gradlew
./gradlew assembleRelease
cd ..

# 3. Copy APK to public downloads
RELEASE_APK="android/app/build/outputs/apk/release/app-release.apk"
DOWNLOAD_APK="public/downloads/Task-Earn-Pro-2.apk"

if [ -f "$RELEASE_APK" ]; then
    cp "$RELEASE_APK" "$DOWNLOAD_APK"
    cp "$RELEASE_APK" "public/taskearnpro-release.apk"
    cp "$RELEASE_APK" "dist/downloads/Task-Earn-Pro-2.apk"
    cp "$RELEASE_APK" "dist/taskearnpro-release.apk"
fi

if [ -f "$DOWNLOAD_APK" ]; then
    APK_SIZE=$(ls -lh "$DOWNLOAD_APK" | awk '{print $5}')
    SHA256=$(sha256sum "$DOWNLOAD_APK" | awk '{print $1}')

    echo "=============================================================================="
    echo "🎉 DIAGNOSTIC APK BUILT SUCCESSFULLY!"
    echo "   - APK File: Task-Earn-Pro-2.apk"
    echo "   - Size: $APK_SIZE"
    echo "   - SHA-256: $SHA256"
    echo "   - Download Link: /downloads/Task-Earn-Pro-2.apk"
    echo "=============================================================================="
else
    echo "❌ Error: Release APK build failed!"
    exit 1
fi
