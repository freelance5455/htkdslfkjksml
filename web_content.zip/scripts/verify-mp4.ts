import fs from "node:fs";
import { inspectMp4 } from "@/lib/mp4validate";

const file = process.argv[2] ?? "test-output/quiz-engine-test.mp4";
const buffer = fs.readFileSync(file);
const arrayBuffer = buffer.buffer.slice(buffer.byteOffset, buffer.byteOffset + buffer.byteLength);
const info = inspectMp4(arrayBuffer);
console.log(JSON.stringify({ file, bytes: buffer.length, ...info }, null, 2));
const ok = info.hasMoov && info.hasMdat && info.hasVideoTrack && info.hasAudioTrack && info.duration > 0 && info.videoCodec === "avc1";
console.log(ok ? "VERIFY_PASS" : "VERIFY_FAIL");
process.exit(ok ? 0 : 1);
