#!/usr/bin/env bash
set -e
npm run typecheck
npm test
npm run build
echo "JARVIS verification pipeline: PASS"
