import {
  goldenValidation,
  goldenValidation2,
  goldenValidation3,
  goldenValidation4,
  goldenValidation5,
  goldenValidation6,
  goldenValidation7,
  goldenValidation8,
  goldenValidation9,
  goldenValidation10,
  goldenValidation11,
  goldenValidation12,
  goldenValidation13,
  goldenValidation14,
  goldenValidation15,
  goldenValidation16
} from '../src/data/goldenStageLoader';
import { STAGES_DATABASE } from '../src/data/sampleStages';

const validations = [
  { name: 'Stage 1', v: goldenValidation },
  { name: 'Stage 2', v: goldenValidation2 },
  { name: 'Stage 3', v: goldenValidation3 },
  { name: 'Stage 4', v: goldenValidation4 },
  { name: 'Stage 5', v: goldenValidation5 },
  { name: 'Stage 6', v: goldenValidation6 },
  { name: 'Stage 7', v: goldenValidation7 },
  { name: 'Stage 8', v: goldenValidation8 },
  { name: 'Stage 9', v: goldenValidation9 },
  { name: 'Stage 10', v: goldenValidation10 },
  { name: 'Stage 11', v: goldenValidation11 },
  { name: 'Stage 12', v: goldenValidation12 },
  { name: 'Stage 13', v: goldenValidation13 },
  { name: 'Stage 14', v: goldenValidation14 },
  { name: 'Stage 15', v: goldenValidation15 },
  { name: 'Stage 16', v: goldenValidation16 }
];

let allValid = true;
validations.forEach((item) => {
  console.log(`\n--- ${item.name} VALIDATION ---`);
  console.log(`${item.name} Valid:`, item.v.isValid);
  if (!item.v.isValid) {
    allValid = false;
  }
  item.v.items.forEach((chk) => {
    console.log(`${chk.passed ? '✓' : '✗'} [${chk.label}]: ${chk.message}`);
    if (!chk.passed) {
      allValid = false;
    }
  });
});

console.log('\n--- STAGES DATABASE CHECK ---');
console.log('Total stages in database:', STAGES_DATABASE.length);
for (let i = 0; i < 16; i++) {
  console.log(`Stage ${i + 1}: ${STAGES_DATABASE[i].title} - Questions: ${STAGES_DATABASE[i].questions.length}`);
}

if (allValid) {
  console.log('\n🌟 ALL 16 STAGES VALIDATED WITH 100% MATHEMATICAL PRECISION!');
} else {
  console.error('\n❌ VALIDATION FAILED!');
  process.exit(1);
}

