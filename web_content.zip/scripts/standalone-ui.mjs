import {
  FONTE_EVENTOS,
  estadoVisual,
  filtrarJogos,
  formatarDataHora,
  fundirHistorico,
  nomeLiga,
  numPt,
  processar,
  statsHistorico,
} from "../src/lib/mercado.ts";

const CACHE_EVENTOS = "vision-master-eventos-v2";
const CACHE_HIST = "vision-master-historico-v2";
const COOLDOWN_MS = 15000;
const MAX_CARTOES = 90;
const FIREBASE_DB = "https://login-abc-03-default-rtdb.firebaseio.com";
const CAMINHO = "bot/dados/eventos";

const S = {
  bruto: null,
  historico: [],
  modo: "blindado",
  termo: "",
  desporto: "",
  liga: "",
  data: "",
  ordem: "seguro",
  carregado: false,
  carregando: false,
  erro: "",
  usandoCache: false,
  cacheEm: null,
  aberto: false,
  cooldownAte: 0,
};

let temDados = false;
let carregando = false;
let ultimo = 0;

const $ = (id) => document.getElementById(id);

function el(tag, cls, texto) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (texto != null) e.textContent = texto;
  return e;
}

function ico(d, cls) {
  const s = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  s.setAttribute("viewBox", "0 0 24 24");
  s.setAttribute("fill", "none");
  s.setAttribute("stroke", "currentColor");
  s.setAttribute("stroke-width", "2");
  s.setAttribute("stroke-linecap", "round");
  s.setAttribute("stroke-linejoin", "round");
  s.setAttribute("aria-hidden", "true");
  if (cls) s.setAttribute("class", cls);
  s.innerHTML = d;
  return s;
}

const ICON = {
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
  refresh: '<path d="M21 12a9 9 0 1 1-2.6-6.3"/><path d="M21 3v6h-6"/>',
  history: '<path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/><path d="M12 7v5l3 2"/>',
  x: '<path d="M6 6l12 12M18 6 6 18"/>',
  shield: '<path d="M12 3 20 7v6c0 5-3.4 7.4-8 9-4.6-1.6-8-4-8-9V7l8-4z"/><path d="m9 12 2 2 4-4"/>',
  radio: '<circle cx="12" cy="12" r="2"/><path d="M5.6 8.4a9 9 0 0 0 0 7.2"/><path d="M18.4 8.4a9 9 0 0 1 0 7.2"/>',
};

function iniciais(nome) {
  const partes = nome.trim().split(/\s+/).filter(Boolean);
  if (partes.length > 1) return ((partes[0][0] || "") + (partes[1][0] || "")).toUpperCase();
  return (partes[0] || "?").slice(0, 2).toUpperCase();
}

function matiz(nome) {
  let h = 0;
  for (const c of nome) h = (h * 31 + (c.codePointAt(0) || 0)) % 360;
  return h;
}

function lerCache() {
  try {
    const t = localStorage.getItem(CACHE_EVENTOS);
    if (!t) return null;
    const o = JSON.parse(t);
    if (o && typeof o === "object" && "dados" in o) return o;
  } catch { /* vazio */ }
  return null;
}

function guardarCache(dados) {
  try {
    localStorage.setItem(CACHE_EVENTOS, JSON.stringify({ guardadoEm: Date.now(), dados }));
  } catch { /* quota */ }
}

function lerHistorico() {
  try {
    const raw = localStorage.getItem(CACHE_HIST);
    const arr = raw ? JSON.parse(raw) : [];
    return Array.isArray(arr) ? arr : [];
  } catch {
    return [];
  }
}

function guardarHistorico(itens) {
  try {
    localStorage.setItem(CACHE_HIST, JSON.stringify(itens));
  } catch { /* quota */ }
}

function mensagemErro(erro) {
  return erro && erro.message ? erro.message : "sem resposta do servidor";
}

function comTimeout(promessa, ms) {
  let relogio;
  const limite = new Promise((_, rejeitar) => {
    relogio = setTimeout(() => rejeitar(new Error("ligação expirou")), ms);
  });
  return Promise.race([promessa, limite]).finally(() => clearTimeout(relogio));
}

async function buscarRest() {
  let ultimo;
  for (let i = 0; i < 3; i++) {
    const ctrl = new AbortController();
    const relogio = setTimeout(() => ctrl.abort(), 10000);
    try {
      const resposta = await fetch(FONTE_EVENTOS, { cache: "no-store", signal: ctrl.signal });
      if (!resposta.ok) throw new Error("HTTP " + resposta.status);
      return await resposta.json();
    } catch (erro) {
      ultimo = erro;
      if (i < 2) await new Promise((r) => setTimeout(r, 800 * (i + 1)));
    } finally {
      clearTimeout(relogio);
    }
  }
  throw ultimo;
}

async function buscarEventos() {
  let erroSdk = null;
  const fb = window.firebase;
  if (fb && typeof fb.database === "function") {
    try {
      if (!fb.apps.length) fb.initializeApp({ databaseURL: FIREBASE_DB });
      const snap = await comTimeout(fb.database().ref(CAMINHO).once("value"), 14000);
      return snap.val();
    } catch (erro) {
      erroSdk = erro;
    }
  }
  try {
    return await buscarRest();
  } catch (erroRest) {
    throw new Error((erroSdk ? mensagemErro(erroSdk) + " · " : "") + mensagemErro(erroRest));
  }
}

function aplicar(dados, cache, quando) {
  temDados = true;
  S.bruto = dados;
  S.usandoCache = cache;
  S.cacheEm = quando;
  S.erro = "";
  S.carregado = true;
  if (!cache) guardarCache(dados);
  S.historico = fundirHistorico(processar(dados, Date.now()), S.historico);
  guardarHistorico(S.historico);
  pintar();
}

async function carregar(manual) {
  if (carregando) return;
  if (manual && Date.now() - ultimo < COOLDOWN_MS) return;
  carregando = true;
  S.carregando = true;
  pintarBotao();
  try {
    const dados = await buscarEventos();
    aplicar(dados, false, null);
    ultimo = Date.now();
    S.cooldownAte = Date.now() + COOLDOWN_MS;
  } catch (falha) {
    if (!temDados) {
      const cache = lerCache();
      if (cache) aplicar(cache.dados, true, cache.guardadoEm);
      else {
        S.erro = mensagemErro(falha);
        S.carregado = false;
      }
    } else {
      S.erro = mensagemErro(falha);
    }
    pintar();
  } finally {
    carregando = false;
    S.carregando = false;
    pintarBotao();
  }
}

function relatorio() {
  return processar(S.bruto, Date.now());
}

function filtros(modo) {
  return {
    modo: modo || S.modo,
    termo: S.termo,
    desporto: S.desporto,
    liga: S.liga,
    data: S.data,
    ordem: S.ordem,
  };
}

function pintarBotao() {
  const btn = $("btn-atualizar");
  if (!btn) return;
  btn.replaceChildren();
  const icone = ico(ICON.refresh, S.carregando ? "ico girar" : "ico");
  btn.append(icone);
  const restante = Math.max(0, S.cooldownAte - Date.now());
  btn.append(
    document.createTextNode(
      S.carregando ? " A atualizar" : restante > 0 ? " " + Math.ceil(restante / 1000) + "s" : " Atualizar",
    ),
  );
  btn.disabled = S.carregando || restante > 0;
}

function pintar() {
  const rel = relatorio();
  const base = filtrarJogos(rel.jogos, filtros("todos"), Date.now());
  const visiveis = filtrarJogos(rel.jogos, filtros(), Date.now());
  const nBlind = base.filter((j) => j.sinal.nivel === "blindado").length;
  const nFirme = base.filter((j) => j.sinal.nivel !== "lista").length;
  const selos = rel.jogos.filter((j) => j.sinal.nivel === "blindado").length;
  const taxa = statsHistorico(S.historico, true);

  const stat = (id, valor, tom) => {
    const n = $(id);
    n.textContent = valor;
    n.className = "stat-valor" + (tom ? " " + tom : "");
  };
  stat("stat-odds", S.carregado ? String(rel.jogos.length) : "—", "");
  stat("stat-blind", S.carregado ? String(selos) : "—", "win");
  const tomTaxa = taxa.taxa == null ? "" : taxa.taxa >= 60 ? "win" : taxa.taxa >= 40 ? "warn" : "loss";
  stat("stat-taxa", taxa.taxa == null ? "—" : taxa.taxa + "%", tomTaxa);
  $("stat-nota").textContent = taxa.resolvidos ? taxa.resolvidos + " resolvidos" : "ainda sem fechos";

  const modos = $("modos");
  modos.replaceChildren();
  [
    ["blindado", "Blindados", nBlind],
    ["firme", "Alta confiança", nFirme],
    ["todos", "Com odds", base.length],
  ].forEach(([id, nome, n]) => {
    const b = el("button", "modo" + (S.modo === id ? " ativo" : ""));
    b.type = "button";
    b.setAttribute("role", "tab");
    b.setAttribute("aria-selected", S.modo === id ? "true" : "false");
    b.append(el("span", "modo-nome", nome), el("span", "modo-n", String(n)));
    b.addEventListener("click", () => {
      S.modo = id;
      pintar();
    });
    modos.append(b);
  });

  const select = $("filtro-liga");
  const atual = S.liga;
  const codigos = [...new Set(rel.jogos.map((j) => j.liga))].sort((a, b) =>
    nomeLiga(a).localeCompare(nomeLiga(b), "pt"),
  );
  select.replaceChildren(new Option("Todas as competições", ""));
  codigos.forEach((c) => select.append(new Option(nomeLiga(c), c)));
  select.value = codigos.includes(atual) ? atual : "";
  S.liga = select.value;

  pintarStatus(rel, visiveis.length, visiveis.length > MAX_CARTOES ? visiveis.length : visiveis.length);
  const lista = $("lista");
  lista.replaceChildren();
  if (!S.carregado && !S.erro) {
    for (let i = 0; i < 3; i++) lista.append(el("div", "esqueleto"));
    lista.append(el("p", "aviso", "A carregar só jogos que têm odds…"));
  } else if (S.erro && !rel.jogos.length) {
    const caixa = el("div", "vazio");
    caixa.append(el("p", "vazio-tit", "Não foi possível carregar os jogos."));
    caixa.append(el("p", "vazio-txt", S.erro));
    const tentar = el("button", "btn primario", "Tentar outra vez");
    tentar.type = "button";
    tentar.addEventListener("click", () => carregar(true));
    caixa.append(tentar);
    lista.append(caixa);
  } else if (!visiveis.length) {
    lista.append(vazio(nFirme > 0, base.length > 0));
  } else {
    visiveis.slice(0, MAX_CARTOES).forEach((jogo, i) => lista.append(cartao(jogo, i)));
  }
  pintarBotao();
  pintarHistorico(rel);
  document.body.classList.toggle("drawer-on", S.aberto);
}

function pintarStatus(rel, mostrados, total) {
  const bar = $("status");
  bar.replaceChildren();
  if (!rel.recebidos && !S.erro) return;
  const pill = (texto, tom) => bar.append(el("span", "pill" + (tom ? " " + tom : ""), texto));
  pill("Proteção ativa");
  pill(rel.jogos.length + " com odds à frente", "ok");
  if (rel.semOdds) pill(rel.semOdds + " sem odds, ocultos", "warn");
  if (rel.margemInvalida) pill(rel.margemInvalida + " com margem suspeita", "warn");
  if (S.usandoCache) pill("Cópia local" + (S.cacheEm ? " de " + formatarDataHora(new Date(S.cacheEm)) : ""), "warn");
  if (S.erro && S.carregado) pill("Última ligação falhou", "err");
  if (mostrados < total) pill("A mostrar " + mostrados + " de " + total);
}

function vazio(temFirme, temOdds) {
  const caixa = el("div", "vazio");
  caixa.append(
    el(
      "p",
      "vazio-tit",
      S.modo === "blindado"
        ? "Nenhum jogo passa o selo Blindado com estes filtros."
        : S.modo === "firme"
          ? "Nenhum favorito de alta confiança com estes filtros."
          : "Nenhum jogo com odds corresponde aos filtros.",
    ),
  );
  caixa.append(
    el(
      "p",
      "vazio-txt",
      S.modo === "blindado"
        ? "O mercado não está a oferecer um favorito assim tão claro. Isso é o filtro a trabalhar, não um erro."
        : "Alarga a data, a competição ou a busca.",
    ),
  );
  const acoes = el("div", "vazio-acoes");
  if (S.modo === "blindado" && temFirme) {
    const b = el("button", "btn primario", "Ver alta confiança");
    b.type = "button";
    b.addEventListener("click", () => {
      S.modo = "firme";
      pintar();
    });
    acoes.append(b);
  }
  if (S.modo !== "todos" && temOdds) {
    const b = el("button", "btn", "Ver todos com odds");
    b.type = "button";
    b.addEventListener("click", () => {
      S.modo = "todos";
      pintar();
    });
    acoes.append(b);
  }
  caixa.append(acoes);
  return caixa;
}

function cartao(jogo, i) {
  const s = jogo.sinal;
  const art = el("article", "cartao nivel-" + s.nivel);
  art.style.animationDelay = Math.min(i, 12) * 40 + "ms";

  const topo = el("div", "topo");
  const hora = el("span", "hora");
  hora.append(ico(ICON.clock, "ico"), document.createTextNode(" " + formatarDataHora(new Date(jogo.inicioMs))));
  topo.append(hora, el("span", "tag", jogo.desportoLabel));

  const equipas = el("div", "equipas");
  equipas.append(equipa(jogo.equipaCasa), el("div", "vs", "VS"), equipa(jogo.equipaFora));

  const odds = el("div", "odds" + (s.odds.empate == null ? " duas" : ""));
  odds.append(oddBox("1 · Casa", s.odds.casa, s.lado === "casa"));
  if (s.odds.empate != null) odds.append(oddBox("X · Empate", s.odds.empate, s.lado === "empate"));
  odds.append(oddBox("2 · Fora", s.odds.fora, s.lado === "fora"));

  const det = el("div", "detalhes");
  const pick = el("div", "caixa" + (s.nivel === "lista" ? "" : " pick"));
  pick.append(el("div", "etiqueta", s.nivel === "blindado" ? "Blindado" : s.nivel === "firme" ? "Firme" : "Com odds"));
  pick.append(el("div", "pick-nome", s.nome));
  pick.append(el("div", "pick-sub", "odd " + numPt(s.odd) + " · " + s.prob + "% · índice " + s.score));
  const barra = el("div", "barra");
  const ench = el("div", "barra-in nivel-" + s.nivel);
  ench.style.width = Math.max(0, Math.min(100, s.prob)) + "%";
  barra.append(ench);
  pick.append(barra);

  const comp = el("div", "caixa");
  comp.append(el("div", "etiqueta", "Competição"));
  comp.append(el("div", "comp-nome", jogo.tipoJogo));
  comp.append(el("div", "pick-sub", "2.º " + s.segundoNome + " · " + s.segundoProb + "%"));
  if (jogo.categoria) comp.append(el("div", "fino", jogo.categoria));
  det.append(pick, comp);

  art.append(topo, equipas, odds, det);
  if (s.nivel === "lista" && s.falhas[0]) {
    art.append(el("p", "falha", "Fora do selo: " + s.falhas[0]));
  } else {
    const ul = el("ul", "motivos");
    s.motivos.forEach((m) => {
      const li = el("li");
      li.append(ico(ICON.shield, "ico win"), el("span", "", m));
      ul.append(li);
    });
    art.append(ul);
  }
  return art;
}

function equipa(nome) {
  const box = el("div", "equipa");
  const av = el("div", "avatar", iniciais(nome));
  av.style.setProperty("--h", String(matiz(nome)));
  box.append(av, el("span", "equipa-nome", nome));
  return box;
}

function oddBox(tag, valor, fav) {
  const box = el("div", "odd" + (fav ? " fav" : ""));
  box.append(el("div", "odd-tag", tag), el("div", "odd-val" + (fav ? " win" : ""), numPt(valor)), el("div", "odd-sub", fav ? "favorito" : "\u00a0"));
  return box;
}

function pintarHistorico(rel) {
  const sh = statsHistorico(S.historico);
  $("hs-total").textContent = String(sh.total);
  $("hs-won").textContent = String(sh.won);
  $("hs-lost").textContent = String(sh.lost);
  $("hs-pend").textContent = String(sh.pend);
  const lista = $("hist-lista");
  lista.replaceChildren();
  if (!S.historico.length) {
    lista.append(
      el(
        "p",
        "vazio-txt centro",
        "Ainda sem selos registados. Quando um jogo passar a Blindado ou a alta confiança, fica aqui para ser avaliado no fim.",
      ),
    );
    return;
  }
  const itens = S.historico.map((h) => ({ h, v: estadoVisual(h, rel.estados[h.id]) }));
  const ordenados = [...itens.filter((x) => x.v.tipo === "live"), ...itens.filter((x) => x.v.tipo !== "live")].slice(0, 60);
  ordenados.forEach(({ h, v }) => {
    const item = el("div", "hist" + (v.tipo === "live" ? " live" : ""));
    item.append(el("div", "hist-jogos", h.equipaCasa + " vs " + h.equipaFora));
    item.append(
      el(
        "div",
        "hist-meta",
        h.tipoJogo + " · " + h.palpiteNome + " · odd " + numPt(h.oddUsada) + " · " + (h.nivel === "blindado" ? "Blindado" : "Firme"),
      ),
    );
    const linha = el("div", "hist-linha");
    linha.append(el("span", "", (v.placar ? v.placar.casa + "–" + v.placar.fora + " · " : "") + h.prob + "%"));
    linha.append(selo(v));
    item.append(linha);
    lista.append(item);
  });
}

function selo(v) {
  if (v.tipo === "won") return el("span", "badge ganhou", "GANHOU");
  if (v.tipo === "lost") return el("span", "badge perdeu", "PERDEU");
  if (v.tipo === "push") return el("span", "badge", "ANULADO");
  if (v.tipo === "live") {
    const b = el("span", "badge live");
    b.append(ico(ICON.radio, "ico pulsa"), document.createTextNode(" Live" + (v.minuto ? " · " + v.minuto : "")));
    return b;
  }
  return el("span", "badge pend", "PENDENTE");
}

function abrir(on) {
  S.aberto = on;
  $("drawer").classList.toggle("aberto", on);
  $("backdrop").classList.toggle("aberto", on);
  document.body.style.overflow = on ? "hidden" : "";
}

function ligar() {
  S.historico = lerHistorico();
  $("busca").addEventListener("input", (e) => {
    S.termo = e.target.value;
    pintar();
  });
  $("filtro-desporto").addEventListener("change", (e) => {
    S.desporto = e.target.value;
    pintar();
  });
  $("filtro-liga").addEventListener("change", (e) => {
    S.liga = e.target.value;
    pintar();
  });
  $("filtro-data").addEventListener("change", (e) => {
    S.data = e.target.value;
    pintar();
  });
  $("filtro-ordem").addEventListener("change", (e) => {
    S.ordem = e.target.value;
    pintar();
  });
  $("btn-atualizar").addEventListener("click", () => carregar(true));
  $("btn-historico").addEventListener("click", () => abrir(true));
  $("btn-fechar").addEventListener("click", () => abrir(false));
  $("backdrop").addEventListener("click", () => abrir(false));
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") abrir(false);
  });
  $("busca").parentElement.querySelector(".ico-busca").append(ico(ICON.search, "ico"));
  $("btn-historico").prepend(ico(ICON.history, "ico"));
  pintar();
  carregar(false);
  setInterval(() => carregar(false), 60000);
  setInterval(() => {
    if (S.carregado) pintar();
  }, 30000);
  setInterval(() => {
    if (S.cooldownAte > Date.now()) pintarBotao();
  }, 1000);
}

ligar();
