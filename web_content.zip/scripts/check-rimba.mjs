import { chromium } from '@playwright/test';
import { mkdir } from 'node:fs/promises';
import assert from 'node:assert/strict';

await mkdir('artifacts', { recursive: true });
const browser = await chromium.launch({ headless: true, args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
const errors = [];
const desktop = await browser.newContext({ viewport: { width: 1440, height: 960 } });
await desktop.grantPermissions(['accelerometer', 'gyroscope'], { origin: 'http://localhost:5173' });
await desktop.addInitScript(() => {
  const NativeAudioContext = window.AudioContext;
  window.__rimbaAudioContexts = [];
  window.AudioContext = class extends NativeAudioContext {
    constructor(...options) { super(...options); window.__rimbaAudioContexts.push(this); }
  };
});
const page = await desktop.newPage();
page.on('pageerror', error => errors.push(error.message));
page.on('console', message => { if (message.type() === 'error') errors.push(message.text()); });
await page.goto('http://localhost:5173', { waitUntil: 'networkidle' });
await page.evaluate(() => document.fonts.ready);
await page.waitForTimeout(1100);
await page.screenshot({ path: 'artifacts/menu-desktop.png', fullPage: true });
assert.equal(await page.locator('.destination').count(), 3);
assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > innerWidth), false);
await page.getByRole('button', { name: 'Simpan Hutan Pinus ke favorit' }).click();
await page.getByRole('button', { name: 'Favorit', exact: false }).filter({ has: page.locator('svg') }).first().click();
assert.equal(await page.locator('.destination').count(), 1);
await page.getByRole('button', { name: 'Pilih Hutan Pinus' }).click();
await page.getByRole('button', { name: 'Semua dunia' }).click();
await page.getByRole('button', { name: 'Pilih Danau Cermin' }).click();

await page.locator('aside').getByRole('button', { name: 'Suara alam', exact: true }).click();
await page.getByRole('button', { name: 'Dengarkan suara alam', exact: true }).click();
await page.waitForTimeout(500);
assert.ok(await page.locator('.sound-layer .waveform.is-playing').count() === 3);
assert.equal(await page.evaluate(() => window.__rimbaAudioContexts.some(context => context.state === 'running')), true);
await page.getByRole('switch', { name: 'Aktifkan kicauan burung' }).click();
assert.equal(await page.getByRole('slider', { name: 'Volume kicauan burung' }).inputValue(), '0');
await page.getByRole('switch', { name: 'Aktifkan kicauan burung' }).click();
await page.screenshot({ path: 'artifacts/sounds-desktop.png', fullPage: true });
await page.getByRole('button', { name: 'Jeda suara alam', exact: true }).first().click();

await page.locator('aside').getByRole('button', { name: 'Pengaturan', exact: true }).click();
await page.getByRole('button', { name: 'Layar tunggal', exact: true }).click();
await page.getByRole('button', { name: 'Senja', exact: true }).click();
await page.getByRole('slider', { name: 'Kecepatan berjalan' }).fill('2.2');
await page.reload({ waitUntil: 'networkidle' });
const stored = await page.evaluate(() => JSON.parse(localStorage.getItem('rimba-settings')));
assert.equal(stored.displayMode, 'single');
assert.equal(stored.timeOfDay, 'sunset');
assert.equal(stored.speed, 2.2);
await page.locator('aside').getByRole('button', { name: 'Pengaturan', exact: true }).click();
await page.getByRole('button', { name: 'Atur ulang', exact: true }).click();
await page.getByRole('button', { name: 'Buka panduan' }).click();
assert.equal(await page.locator('dialog[open]').count(), 1);
await page.keyboard.press('Escape');
assert.equal(await page.locator('dialog[open]').count(), 0);
await page.locator('aside').getByRole('button', { name: 'Jelajahi', exact: true }).click();

await page.setViewportSize({ width: 960, height: 640 });
await page.getByRole('button', { name: 'Mulai menjelajah', exact: true }).click();
await page.locator('canvas').waitFor({ timeout: 30000 });
await page.locator('.scene-loading').waitFor({ state: 'detached', timeout: 30000 });
await page.waitForTimeout(1600);
assert.equal(await page.locator('.stereo-divider').count(), 1);
assert.equal(await page.locator('.vr-cardboard-mask-overlay').count(), 1);
assert.equal(await page.locator('.scene-error').count(), 0);
await page.screenshot({ path: 'artifacts/game-stereo.png', timeout: 60000 });
await page.waitForTimeout(300);
const stereoViewport = await page.evaluate(() => {
  const gl = document.querySelector('canvas').getContext('webgl2');
  return Array.from(gl.getParameter(gl.VIEWPORT));
});
assert.equal(stereoViewport[0], 480, 'Right eye must render into the right half');
assert.equal(stereoViewport[2], 480, 'Each eye must occupy exactly half the viewport');
await page.keyboard.down('w');
await page.waitForTimeout(2500);
await page.keyboard.up('w');
await page.waitForTimeout(800);
const walked = parseFloat(await page.getByTestId('distance').textContent());
assert.ok(walked > 0.1, `Keyboard should move player, got ${walked}`);
await page.getByRole('button', { name: 'Kembali ke titik awal' }).click();
await page.waitForTimeout(400);
assert.equal(parseFloat(await page.getByTestId('distance').textContent()), 0);

// Dispatch real DeviceMotionEvent-shaped samples to verify sensor-to-camera wiring.
await page.evaluate(async () => {
  for (let i = 0; i < 40; i += 1) {
    window.dispatchEvent(new DeviceMotionEvent('devicemotion', { acceleration: { x: i % 2 ? 4 : -4, y: 2.5, z: 1 }, interval: 70 }));
    await new Promise(resolve => setTimeout(resolve, 70));
  }
});
await page.waitForTimeout(500);
const sensorWalked = parseFloat(await page.getByTestId('distance').textContent());
assert.ok(sensorWalked > 0.1, `Sensor must move the real camera, got ${sensorWalked}`);
assert.ok(await page.getByRole('button', { name: /Sensor gerakan aktif/ }).count());
await page.waitForTimeout(1100);
await page.getByRole('button', { name: 'Kembali ke titik awal' }).click();
await page.waitForTimeout(350);
await page.evaluate(async () => {
  for (let i = 0; i < 12; i += 1) {
    window.dispatchEvent(new DeviceMotionEvent('devicemotion', { accelerationIncludingGravity: { x: 9.81, y: 0, z: 0 }, interval: 70 }));
    await new Promise(resolve => setTimeout(resolve, 70));
  }
});
assert.equal(parseFloat(await page.getByTestId('distance').textContent()), 0, 'Landscape gravity alone must not cause walking');
await page.evaluate(async () => {
  for (let i = 0; i < 40; i += 1) {
    window.dispatchEvent(new DeviceMotionEvent('devicemotion', { accelerationIncludingGravity: { x: 9.81 + (i % 2 ? 4 : -4), y: 0, z: 0.4 }, interval: 70 }));
    await new Promise(resolve => setTimeout(resolve, 70));
  }
});
await page.waitForFunction(() => !document.querySelector('.walking-dot.active'), undefined, { timeout: 15000 });
await page.waitForTimeout(800);
assert.ok(parseFloat(await page.getByTestId('distance').textContent()) > 0.1, 'Gravity fallback must detect landscape phone movement');
const stopped = parseFloat(await page.getByTestId('distance').textContent());
await page.waitForTimeout(700);
assert.equal(parseFloat(await page.getByTestId('distance').textContent()), stopped, 'Movement must expire without new sensor readings');
await page.getByRole('button', { name: 'Ganti ke layar tunggal' }).click();
await page.waitForFunction(() => {
  const gl = document.querySelector('canvas')?.getContext('webgl2');
  return gl && gl.getParameter(gl.VIEWPORT)[2] === 960;
}, undefined, { timeout: 20000 });
assert.equal(await page.locator('.stereo-divider').count(), 0);
assert.equal(await page.locator('.vr-cardboard-mask-overlay').count(), 0);
const singleViewport = await page.evaluate(() => {
  const gl = document.querySelector('canvas').getContext('webgl2');
  return Array.from(gl.getParameter(gl.VIEWPORT));
});
assert.equal(singleViewport[0], 0);
assert.equal(singleViewport[2], 960, 'Single-eye view must use the whole viewport');
await page.screenshot({ path: 'artifacts/game-single.png' });
await page.getByRole('button', { name: 'Jeda perjalanan' }).click();
await page.keyboard.down('w');
await page.waitForTimeout(500);
await page.keyboard.up('w');
assert.equal(parseFloat(await page.getByTestId('distance').textContent()), stopped);
await page.getByRole('button', { name: 'Lanjutkan perjalanan' }).click();
await page.getByRole('button', { name: 'Pengaturan di dalam game' }).click();
assert.equal(await page.locator('dialog[open]').count(), 1);
await page.getByRole('button', { name: 'Layar terbagi', exact: true }).click();
await page.getByRole('button', { name: 'Senja', exact: true }).click();
await page.getByRole('button', { name: 'Tutup dialog' }).click();
await page.waitForTimeout(800);
assert.equal(parseFloat(await page.getByTestId('distance').textContent()), stopped, 'Lighting changes must preserve journey progress');
await page.getByRole('button', { name: 'Kembali ke menu', exact: true }).click();
await page.getByRole('button', { name: 'Pilih Hutan Pinus' }).click();
await page.getByRole('button', { name: 'Mulai menjelajah', exact: true }).click();
await page.locator('canvas').waitFor();
await page.waitForTimeout(600);
await page.getByRole('button', { name: 'Kembali ke menu', exact: true }).click();

const mobile = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, deviceScaleFactor: 1 });
await mobile.grantPermissions(['accelerometer', 'gyroscope'], { origin: 'http://localhost:5173' });
const phone = await mobile.newPage();
phone.on('pageerror', error => errors.push(error.message));
await phone.goto('http://localhost:5173', { waitUntil: 'networkidle' });
await phone.waitForTimeout(700);
await phone.screenshot({ path: 'artifacts/menu-mobile.png' });
assert.equal(await phone.evaluate(() => document.documentElement.scrollWidth > innerWidth), false);
await phone.getByRole('button', { name: 'Buka menu', exact: true }).click();
await phone.locator('aside').getByRole('button', { name: 'Pengaturan', exact: true }).click();
await phone.getByRole('heading', { name: 'Nyaman, dengan caramu.', exact: true }).waitFor();
await phone.waitForTimeout(350);
await phone.screenshot({ path: 'artifacts/settings-mobile.png', fullPage: true });
assert.equal(await phone.evaluate(() => document.documentElement.scrollWidth > innerWidth), false);
await phone.getByRole('button', { name: 'Rimba beranda' }).click();
await phone.getByRole('button', { name: 'Mulai menjelajah', exact: true }).click();
await phone.locator('canvas').waitFor();
await phone.waitForTimeout(600);
assert.ok(await phone.locator('.portrait-hint').isVisible());
await phone.setViewportSize({ width: 844, height: 390 });
await phone.waitForTimeout(500);
await phone.screenshot({ path: 'artifacts/game-mobile-landscape.png' });
await phone.getByRole('button', { name: 'Kembali ke menu', exact: true }).click();

const denied = await browser.newContext({ viewport: { width: 640, height: 420 } });
await denied.addInitScript(() => {
  localStorage.setItem('rimba-settings', JSON.stringify({ displayMode: 'single', motionEnabled: true }));
  DeviceMotionEvent.requestPermission = () => Promise.resolve('denied');
});
const fallback = await denied.newPage();
fallback.on('pageerror', error => errors.push(error.message));
await fallback.goto('http://localhost:5173', { waitUntil: 'networkidle' });
await fallback.getByRole('button', { name: 'Mulai menjelajah', exact: true }).click();
await fallback.locator('canvas').waitFor();
await fallback.waitForTimeout(400);
assert.ok(await fallback.getByRole('button', { name: /Kontrol manual tersedia/ }).isVisible());
await fallback.keyboard.down('w');
await fallback.waitForTimeout(2000);
await fallback.keyboard.up('w');
await fallback.waitForTimeout(400);
assert.ok(parseFloat(await fallback.getByTestId('distance').textContent()) > 0, 'Denied sensors must not disable manual movement');

console.log(JSON.stringify({ result: 'passed', keyboardDistance: walked, sensorDistance: stopped, desktopAndMobile: true, consoleErrors: errors }, null, 2));
await browser.close();
assert.equal(errors.length, 0, 'Browser console should be free of errors');