import { chromium } from '@playwright/test';
import assert from 'node:assert/strict';

const browser = await chromium.launch({
  headless: true,
  args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
});
const context = await browser.newContext({ viewport: { width: 1280, height: 720 } });
const page = await context.newPage();

await page.goto('http://localhost:5173', { waitUntil: 'domcontentloaded' });
await page.waitForTimeout(1000);

// Check destinations
assert.equal(await page.locator('.destination').count(), 4);
await page.getByRole('button', { name: 'Select Mountain Summit 🗻' }).click();
await page.getByRole('button', { name: 'Explore in VR' }).click();

await page.locator('canvas').waitFor({ timeout: 15000 });
await page.waitForTimeout(2000);

await page.screenshot({ path: 'artifacts/summit-panoramic-view.png' });
console.log('Successfully captured summit panoramic view!');

await browser.close();
