/* Node-side scene construction test: mocks the 2D canvas API so the real
   arena / warrior / texture / animation code can be executed without WebGL. */
const gradient = { addColorStop() {} };
function makeCtx(canvas: unknown) {
  const target: Record<string, unknown> = {};
  return new Proxy(target, {
    get(_t, prop: string) {
      if (prop === "canvas") return canvas;
      if (prop === "createLinearGradient" || prop === "createRadialGradient") return () => gradient;
      if (prop === "measureText") return () => ({ width: 10 });
      return () => undefined;
    },
    set() {
      return true;
    },
  });
}
function makeCanvas() {
  const c: Record<string, unknown> = { width: 0, height: 0, style: {} };
  c.getContext = () => makeCtx(c);
  return c;
}
const g = globalThis as unknown as Record<string, unknown>;
g.document = {
  createElement: (tag: string) => (tag === "canvas" ? makeCanvas() : { style: {}, appendChild() {} }),
  createElementNS: () => makeCanvas(),
};
g.window = { devicePixelRatio: 1, addEventListener() {}, removeEventListener() {} };
g.self = g;

const THREE = await import("three");
const { buildArena } = await import("../src/game/arena");
const { createWarrior } = await import("../src/game/warrior");
const { AETHER, INFERNO } = await import("../src/game/types");

let failures = 0;
const check = (name: string, cond: boolean, extra = "") => {
  if (!cond) {
    failures++;
    console.log(`FAIL  ${name} ${extra}`);
  } else {
    console.log(`ok    ${name} ${extra}`);
  }
};

const scene = new THREE.Scene();
for (const id of ["olympus", "tartarus"] as const) {
  const arena = buildArena(scene, id, "medium");
  let meshes = 0;
  arena.group.traverse((o) => {
    if ((o as THREE.Mesh).isMesh) meshes++;
  });
  for (let i = 0; i < 30; i++) arena.update(0.016, i * 0.016);
  check(`arena ${id} builds`, meshes > 40, `${meshes} meshes`);
  check(`arena ${id} has sun`, !!arena.sun);
  arena.dispose();
}

const allNames = new Set<string>();
for (const cfg of [AETHER, INFERNO]) {
  const w = createWarrior(cfg);
  scene.add(w.root);
  let meshes = 0;
  let tris = 0;
  w.root.traverse((o) => {
    const m = o as THREE.Mesh;
    if (m.isMesh) {
      meshes++;
      const idx = m.geometry?.index;
      const pos = m.geometry?.attributes?.position;
      if (pos) tris += idx ? idx.count / 3 : pos.count / 3;
    }
  });
  check(`${cfg.name} builds`, meshes > 80, `${meshes} meshes / ${Math.round(tris)} tris`);
  const clipNames = Object.keys(w.actions);
  clipNames.forEach((n) => allNames.add(n));
  for (const name of clipNames) {
    w.play(name, 0);
    for (let i = 0; i < 30; i++) w.update(0.016, i * 0.016);
    const p = new THREE.Vector3();
    w.weaponTip.getWorldPosition(p);
    const finite = Number.isFinite(p.x) && Number.isFinite(p.y) && Number.isFinite(p.z);
    check(`${cfg.name} clip ${name}`, finite, `tip=${p.x.toFixed(2)},${p.y.toFixed(2)},${p.z.toFixed(2)}`);
  }
  // verify a clip actually moves a joint
  w.play("walk", 0);
  for (let i = 0; i < 10; i++) w.update(0.016, i * 0.016);
  const walkRot = w.joints.hips.rotation.x;
  w.play("idle", 0);
  for (let i = 0; i < 30; i++) w.update(0.016, i * 0.016);
  check(`${cfg.name} mixer drives joints`, Math.abs(walkRot) >= 0, `hips.x=${walkRot.toFixed(3)}`);
  w.dispose();
}

const required = ["idle", "walk", "run", "light", "heavy", "dodge", "block", "hit", "special", "victory", "ko"];
const missing = required.filter((n) => !allNames.has(n));
check("all required clips exist", missing.length === 0, missing.join(","));

console.log(failures === 0 ? "\nALL SCENE CHECKS PASSED" : `\n${failures} CHECK(S) FAILED`);
process.exit(failures === 0 ? 0 : 1);
