// Renders the App tree on the server to catch runtime errors in components.
//
// Run with:
//   npx esbuild src/App.tsx --bundle --format=esm --jsx=automatic \
//     --outfile=build/app.mjs --external:react --external:react-dom --loader:.css=empty
//   node scripts/render.mjs
import { renderToString } from "react-dom/server";
import { createElement } from "react";
import App from "../build/app.mjs";

const html = renderToString(createElement(App));
const checks = [
  ["renders title", html.includes("واژه‌بار")],
  ["renders lessons", html.includes("My Favorite Food")],
  ["renders modes", html.includes("انتخاب کن")],
  ["renders difficulty", html.includes("سریع")],
  ["renders start button", html.includes("شروع بازی")],
  ["renders score table", html.includes("جدول رکوردها")],
];
let fail = 0;
for (const [name, ok] of checks) {
  console.log(`  ${ok ? "✅" : "❌"} ${name}`);
  if (!ok) fail++;
}
console.log(`\nhtml length: ${html.length}`);
console.log(fail === 0 ? "RENDER OK ✅" : "RENDER FAILED ❌");
process.exit(fail === 0 ? 0 : 1);
