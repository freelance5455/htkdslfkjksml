#!/usr/bin/env python3
# Builds the self-contained playable HTML (artifacts/donande-fazayi-v92.html) from src/game/space-runner.js
import re, os, sys
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
game = open(os.path.join(root, 'src/game/space-runner.js'), encoding='utf-8').read()
assert 'export function boot(root) {' in game
game = game.replace('export function boot(root) {', 'function boot(root) {', 1)
logo = re.search(r'base64,([^"]+)"', open(os.path.join(root, 'src/game/logo-data.ts')).read()).group(1)

FADE, STAY = 800, 2400
html = '''<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover">
<meta name="theme-color" content="#000000">
<meta name="color-scheme" content="dark">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<title>دونده فضایی — نسخه ۹۲</title>
<style>
html,body,#sr-root{margin:0;width:100%;height:100%;overflow:hidden;background:#000;touch-action:none;-webkit-user-select:none;user-select:none;}
#srSplash{position:fixed;top:-60px;left:-60px;right:-60px;bottom:-60px;width:auto;height:auto;z-index:99999;display:flex;align-items:center;justify-content:center;background:#000;color:#d6e4ff;font-family:Tahoma,Arial,sans-serif;overflow:hidden;}
#srLogoBox{position:absolute;top:60px;left:60px;right:60px;bottom:60px;display:flex;align-items:center;justify-content:center;box-sizing:border-box;padding:max(14px,env(safe-area-inset-top)) max(14px,env(safe-area-inset-right)) max(14px,env(safe-area-inset-bottom)) max(14px,env(safe-area-inset-left));overflow:hidden;}
#srLogoImg{width:min(88%,560px);max-width:100%;max-height:78%;object-fit:contain;opacity:0;transform:scale(.94);background:#000;
  transition:opacity __FADE__ms ease-in-out, transform __TOTAL__ms ease-out;}
#srLogoImg.show{opacity:1;transform:scale(1);}
#srLogoImg.out{opacity:0;transform:scale(1.02);}
#srLoading{position:absolute;inset:0;display:none;flex-direction:column;align-items:center;justify-content:center;gap:18px;
  background:radial-gradient(ellipse at 50% 30%, #0d1a3d 0%, #05081a 55%, #020410 100%);opacity:0;transition:opacity 500ms ease-out;}
#srLoading.show{display:flex;}
#srLoading.vis{opacity:1;}
#srLoadTitle{font-size:30px;font-weight:800;letter-spacing:1px;text-shadow:0 0 20px rgba(77,124,255,.65);
  background:linear-gradient(90deg,#7cc7ff,#c9a4ff,#ffd447);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;color:transparent;}
#srLoadSub{font-size:13px;color:#9fb3e0;}
#srBarWrap{width:200px;height:8px;border-radius:8px;background:#101d3d;border:1px solid #2c3f6e;overflow:hidden;}
#srBarFill{height:100%;width:0%;border-radius:8px;background:linear-gradient(90deg,#4d7cff,#7cc7ff,#ffd447);box-shadow:0 0 10px rgba(124,199,255,.7);}
</style>
</head>
<body>
<div id="sr-root"></div>
<div id="srSplash">
  <div id="srLogoBox"><img id="srLogoImg" src="data:image/jpeg;base64,__LOGO__" alt=""></div>
  <div id="srLoading">
    <div id="srLoadTitle">🚀 دونده فضایی</div>
    <div id="srLoadSub">در حال بارگذاری...</div>
    <div id="srBarWrap"><div id="srBarFill"></div></div>
  </div>
</div>
<script>
// توالی پیش از بازی: لوگوی بزرگ (محو شدن + مکث بیشتر) -> صفحه‌ی لودینگ با نوار پیشرفت -> خود بازی
(function(){
  var img = document.getElementById("srLogoImg"), loading = document.getElementById("srLoading"),
      bar = document.getElementById("srBarFill"), splash = document.getElementById("srSplash");
  var FADE = __FADE__, STAY = __STAY__;
  setTimeout(function(){ img.classList.add("show"); }, 60);
  setTimeout(function(){ img.classList.remove("show"); img.classList.add("out"); }, 60 + FADE + STAY);
  setTimeout(function(){
    img.style.display = "none"; document.getElementById("srLogoBox").style.display = "none";
    loading.classList.add("show");
    requestAnimationFrame(function(){ loading.classList.add("vis"); });
    var start = performance.now(), dur = 1450;
    function tick(now){
      var pct = Math.min(100, ((now - start) / dur) * 100);
      bar.style.width = pct + "%";
      if(pct < 100){ requestAnimationFrame(tick); }
      else { setTimeout(function(){ document.documentElement.style.background = "#020511"; document.body.style.background = "#020511"; document.getElementById("sr-root").style.background = "#020511"; splash.remove(); boot(document.getElementById("sr-root")); }, 150); }
    }
    requestAnimationFrame(tick);
  }, 60 + FADE + STAY + FADE);
})();
</script>
<script>
'''
html = html.replace('__FADE__', str(FADE)).replace('__STAY__', str(STAY)).replace('__TOTAL__', str(FADE + STAY))
html = html.replace('__LOGO__', logo) + game + '\n</script>\n</body>\n</html>\n'
out = os.path.join(root, 'artifacts/donande-fazayi-v92.html')
open(out, 'w', encoding='utf-8').write(html)
print('wrote', out, os.path.getsize(out), 'bytes')
