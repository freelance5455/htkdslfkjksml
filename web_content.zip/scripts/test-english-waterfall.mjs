import { chromium } from '@playwright/test';
import assert from 'node:assert/strict';

const browser = await chromium.launch({
  headless: true,
  args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
});
const context = await browser.newContext({ viewport: { width: 1280, height: 720 } });
await context.grantPermissions(['accelerometer', 'gyroscope'], { origin: 'http://localhost:5173' });

const page = await context.newPage();
const errors = [];
page.on('pageerror', err => errors.push(err.message));
page.on('console', msg => { if (msg.type() === 'error') errors.push(msg.text()); });

await page.goto('http://localhost:5173', { waitUntil: 'networkidle' });
await page.waitForTimeout(1000);

// Check English content & new Waterfall world
assert.equal(await page.title(), 'Rimba VR — Step into Nature');
assert.ok(await page.getByRole('button', { name: 'Explore in VR' }).isVisible());
assert.ok(await page.getByRole('button', { name: /Select Emerald Falls/i }).isVisible());
assert.equal(await page.locator('.destination').count(), 4);

await page.screenshot({ path: 'artifacts/english-menu.png' });

// Test Waterfall entry & VR dual-lens view
await page.getByRole('button', { name: /Select Emerald Falls/i }).click();
await page.getByRole('button', { name: 'Explore in VR' }).click();

await page.locator('canvas').waitFor({ timeout: 30000 });
await page.locator('.scene-loading').waitFor({ state: 'detached', timeout: 30000 });
await page.waitForTimeout(1500);

assert.equal(await page.locator('.vr-cardboard-mask-overlay').count(), 1);
assert.equal(await page.locator('.scene-error').count(), 0);
await page.screenshot({ path: 'artifacts/english-waterfall-vr.png' });

// Test forward walking
await page.keyboard.down('w');
await page.waitForTimeout(2000);
await page.keyboard.up('w');
await page.waitForTimeout(500);
const walked = parseFloat(await page.getByTestId('distance').textContent());
assert.ok(walked > 0.1, `Walk distance should increase, got ${walked}`);

// Test settings dialog in English
await page.getByRole('button', { name: 'In-game settings' }).click();
assert.equal(await page.locator('dialog[open]').count(), 1);
assert.ok(await page.getByRole('button', { name: 'Single Screen', exact: true }).isVisible());
await page.getByRole('button', { name: 'Close dialog' }).click();

// Return to menu
await page.getByRole('button', { name: 'Return to menu' }).click();
await page.waitForTimeout(500);

console.log(JSON.stringify({
  result: 'passed',
  waterfallWorld: true,
  language: 'English',
  distanceWalked: walked,
  consoleErrors: errors,
}, null, 2));

await browser.close();
assert.equal(errors.length, 0);
