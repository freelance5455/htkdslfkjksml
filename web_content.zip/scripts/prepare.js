// Copie les bibliothèques (jsPDF, JSZip, SheetJS) et la police Cairo dans www/lib
// pour que l'application fonctionne 100 % hors ligne.
const fs = require("fs"), path = require("path");
const root = path.join(__dirname, ".."), lib = path.join(root, "www", "lib"), fonts = path.join(lib, "fonts");
fs.mkdirSync(fonts, { recursive: true });
const nm = (...p) => path.join(root, "node_modules", ...p);
let bad = 0;
function cp(src, dst) {
  if (!fs.existsSync(src)) { console.error("MANQUANT : " + src); bad++; return false; }
  fs.copyFileSync(src, dst); console.log("OK  " + path.relative(root, dst)); return true;
}
cp(nm("jspdf", "dist", "jspdf.umd.min.js"), path.join(lib, "jspdf.umd.min.js"));
cp(nm("xlsx", "dist", "xlsx.full.min.js"), path.join(lib, "xlsx.full.min.js"));
cp(nm("jszip", "dist", "jszip.min.js"), path.join(lib, "jszip.min.js"));

let css = "";
for (const w of [400, 700]) for (const [sub, range] of [
  ["arabic", "U+0600-06FF,U+200C-200E,U+2010-2011,U+204F,U+2E41,U+FB50-FDFF,U+FE70-FE7F"],
  ["latin", "U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD"]
]) {
  const f = `cairo-${sub}-${w}-normal.woff2`;
  if (cp(nm("@fontsource", "cairo", "files", f), path.join(fonts, f)))
    css += `@font-face{font-family:Cairo;font-style:normal;font-display:swap;font-weight:${w};src:url(fonts/${f}) format("woff2");unicode-range:${range}}\n`;
}
fs.writeFileSync(path.join(lib, "cairo.css"), css);
if (bad) { console.error("\nExécutez d'abord : npm install"); process.exit(1); }
