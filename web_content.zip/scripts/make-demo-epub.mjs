import { writeFileSync } from "node:fs";
import JSZip from "jszip";

const zip = new JSZip();
zip.file("mimetype", "application/epub+zip", { compression: "STORE" });
zip.folder("META-INF")?.file(
  "container.xml",
  `<?xml version="1.0" encoding="UTF-8"?>
<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">
  <rootfiles>
    <rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/>
  </rootfiles>
</container>`,
);

zip.folder("OEBPS")?.file(
  "content.opf",
  `<?xml version="1.0" encoding="UTF-8"?>
<package xmlns="http://www.idpf.org/2007/opf" unique-identifier="bookid" version="2.0">
  <metadata xmlns:dc="http://purl.org/dc/elements/1.1/">
    <dc:identifier id="bookid">folio-demo-1</dc:identifier>
    <dc:title>La casa de la colina</dc:title>
    <dc:creator>Folio</dc:creator>
    <dc:language>es</dc:language>
  </metadata>
  <manifest>
    <item id="ncx" href="toc.ncx" media-type="application/x-dtbncx+xml"/>
    <item id="ch1" href="ch1.xhtml" media-type="application/xhtml+xml"/>
    <item id="ch2" href="ch2.xhtml" media-type="application/xhtml+xml"/>
  </manifest>
  <spine toc="ncx">
    <itemref idref="ch1"/>
    <itemref idref="ch2"/>
  </spine>
</package>`,
);

zip.folder("OEBPS")?.file(
  "toc.ncx",
  `<?xml version="1.0" encoding="UTF-8"?>
<ncx xmlns="http://www.daisy.org/z3986/2005/ncx/" version="2005-1">
  <docTitle><text>La casa de la colina</text></docTitle>
  <navMap>
    <navPoint id="n1" playOrder="1">
      <navLabel><text>El camino</text></navLabel>
      <content src="ch1.xhtml"/>
    </navPoint>
    <navPoint id="n2" playOrder="2">
      <navLabel><text>La ventana</text></navLabel>
      <content src="ch2.xhtml"/>
    </navPoint>
  </navMap>
</ncx>`,
);

zip.folder("OEBPS")?.file(
  "ch1.xhtml",
  `<?xml version="1.0" encoding="UTF-8"?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head><title>El camino</title></head>
<body>
<h1>El camino</h1>
<p>La casa estaba más arriba de lo que recordaba. El sendero había perdido las piedras y ahora era solo un hilo de tierra entre tomillos. Elena subió sin prisa, con el EPUB de su padre en el bolsillo, como si el archivo pesara lo mismo que el libro de papel.</p>
<p>Abajo, el pueblo encendía las primeras luces. Arriba, una ventana seguía esperando.</p>
</body>
</html>`,
);

zip.folder("OEBPS")?.file(
  "ch2.xhtml",
  `<?xml version="1.0" encoding="UTF-8"?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head><title>La ventana</title></head>
<body>
<h1>La ventana</h1>
<p>Dentro no había polvo. Alguien había aireado las habitaciones. Sobre la mesa, una lámpara de aceite y una nota: «Lee en voz alta. La casa escucha mejor así.»</p>
<p>Elena sonrió, abrió el archivo, y por primera vez en años la casa volvió a tener una voz.</p>
</body>
</html>`,
);

const buffer = await zip.generateAsync({
  type: "nodebuffer",
  compression: "DEFLATE",
  mimeType: "application/epub+zip",
});
writeFileSync("/workspace/public/demo.epub", buffer);
console.log("wrote public/demo.epub", buffer.length);
