import { createCanvas, GlobalFonts, ImageData } from "@napi-rs/canvas";
import { initializeCanvas } from "ag-psd";
import fs from "node:fs";
import path from "node:path";
import { buildPsd } from "../src/psd/buildPsd";

const dir = "node_modules/@fontsource/plus-jakarta-sans/files";
for (const w of [200, 300, 400, 700, 800]) {
  GlobalFonts.registerFromPath(path.join(dir, `plus-jakarta-sans-latin-${w}-normal.woff`), "Plus Jakarta Sans");
}
GlobalFonts.registerFromPath(path.join(dir, "plus-jakarta-sans-latin-800-italic.woff"), "Plus Jakarta Sans");

initializeCanvas(
  ((w: number, h: number) => createCanvas(w, h)) as any,
  ((w: number, h: number) => new ImageData(w, h)) as any
);

const size = Number(process.argv[2] || 1932);
const platform = {
  createCanvas: (w: number, h: number) => createCanvas(w, h),
  toPng: async (c: any) => new Uint8Array(c.toBuffer("image/png")),
};

const res = await buildPsd(platform, size, {});
const out = "public/Africas_Business_Heroes_Dr_Gildas_ZODOME.psd";
fs.writeFileSync(out, res.bytes);
fs.writeFileSync("/tmp/preview.png", (res.preview as any).toBuffer("image/png"));
fs.writeFileSync("public/apercu.png", (res.preview as any).toBuffer("image/png"));
console.log("PSD écrit:", out, (res.bytes.length / 1e6).toFixed(2), "Mo", res.spec.length, "lignes de spec");
