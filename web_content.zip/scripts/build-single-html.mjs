import { execFileSync } from 'node:child_process';
import { existsSync, mkdirSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const buildDir = path.join(root, 'dist-standalone-build');
const defaultOutput = path.join(root, 'dist-standalone', 'manara-standalone.html');
const cliArgs = process.argv.slice(2);
const requestedOutput = cliArgs[0] === '--' ? cliArgs[1] : cliArgs[0];
const outputFile = path.resolve(requestedOutput ?? defaultOutput);

function walkFiles(directory) {
  if (!existsSync(directory)) return [];
  return readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
    const absolute = path.join(directory, entry.name);
    return entry.isDirectory() ? walkFiles(absolute) : [absolute];
  });
}

function contentType(file) {
  const extension = path.extname(file).toLowerCase();
  if (extension === '.pdf') return 'application/pdf';
  if (extension === '.png') return 'image/png';
  if (extension === '.jpg' || extension === '.jpeg') return 'image/jpeg';
  if (extension === '.svg') return 'image/svg+xml';
  return 'application/octet-stream';
}

function resolveBuildAsset(assetPath) {
  const cleanPath = decodeURIComponent(assetPath.split(/[?#]/, 1)[0]).replace(/^\/+/, '');
  const absolute = path.resolve(buildDir, cleanPath);
  if (absolute !== buildDir && !absolute.startsWith(`${buildDir}${path.sep}`)) {
    throw new Error(`Refusing to read build asset outside output directory: ${assetPath}`);
  }
  if (!existsSync(absolute)) throw new Error(`Build asset was not found: ${assetPath}`);
  return readFileSync(absolute, 'utf8');
}

rmSync(buildDir, { recursive: true, force: true });
execFileSync(
  'pnpm',
  ['exec', 'vite', 'build', '--mode', 'standalone', '--config', 'vite.singlefile.config.ts'],
  { cwd: root, stdio: 'inherit' },
);

const sourceHtml = path.join(buildDir, 'index.html');
if (!existsSync(sourceHtml)) throw new Error('Standalone Vite build did not produce index.html.');
let html = readFileSync(sourceHtml, 'utf8');

// إزالة الاعتماد على الأيقونات والخطوط الخارجية وPWA في ملف file://.
html = html.replace(/<link\b(?=[^>]*\bhref=["']https:\/\/fonts\.(?:googleapis|gstatic)\.com)[^>]*>\s*/gi, '');
html = html.replace(/<link\b(?=[^>]*\brel=["'](?:manifest|icon|apple-touch-icon)["'])[^>]*>\s*/gi, '');
html = html.replace(/<meta\b(?=[^>]*(?:property|name)=["'](?:og:image|twitter:image)["'])[^>]*>\s*/gi, '');
html = html.replace(/<link\b(?=[^>]*\brel=["']modulepreload["'])[^>]*>\s*/gi, '');

const stylesheetTags = [...html.matchAll(/<link\b(?=[^>]*\brel=["']stylesheet["'])(?=[^>]*\bhref=["']([^"']+)["'])[^>]*>/gi)];
if (stylesheetTags.length === 0) throw new Error('No stylesheet link was found in the standalone build.');
const css = stylesheetTags.map((match) => resolveBuildAsset(match[1])).join('\n');
for (const match of stylesheetTags) html = html.replace(match[0], '');
html = html.replace('</head>', () => `<style>\n${css.replace(/<\/style/gi, '<\\/style')}\n</style>\n</head>`);

const moduleTags = [...html.matchAll(/<script\b(?=[^>]*\btype=["']module["'])(?=[^>]*\bsrc=["']([^"']+)["'])[^>]*>\s*<\/script>/gi)];
if (moduleTags.length !== 1) {
  throw new Error(`Expected one JavaScript entry after inlining chunks; found ${moduleTags.length}.`);
}
const js = resolveBuildAsset(moduleTags[0][1]);
const inlineModule = `<script type="module">\n${js.replace(/<\/script/gi, '<\\/script')}\n</script>`;
html = html.replace(moduleTags[0][0], () => inlineModule);

const filesDirectory = path.join(root, 'public', 'files');
const localFiles = walkFiles(filesDirectory);
if (localFiles.length === 0) throw new Error('No local public/files assets were found to embed.');
const assets = Object.fromEntries(localFiles.map((file) => {
  const relative = path.relative(filesDirectory, file).split(path.sep).join('/');
  const key = `/files/${relative}`;
  const value = `data:${contentType(file)};base64,${readFileSync(file).toString('base64')}`;
  return [key, value];
}));
const registryScript = `<script>window.__MANARA_EMBEDDED_ASSETS__=${JSON.stringify(assets)};</script>`;
if (!html.includes('<script type="module">')) throw new Error('Inlined JavaScript entry was not found.');
html = html.replace('<script type="module">', () => `${registryScript}\n<script type="module">`);

const htmlTagsOnly = html.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, '<script></script>');
const externalAssetTag = /<(?:script|link)\b[^>]+(?:src|href)=["'](?:\.\/)?assets\//i;
const unresolvedBundleAsset = /(?:\.\/)?assets\/[A-Za-z0-9._/-]+/;
if (externalAssetTag.test(htmlTagsOnly) || unresolvedBundleAsset.test(js) || unresolvedBundleAsset.test(css)) {
  throw new Error('The final HTML still references an external build asset.');
}

mkdirSync(path.dirname(outputFile), { recursive: true });
writeFileSync(outputFile, html, 'utf8');
rmSync(buildDir, { recursive: true, force: true });
console.log(`Created ${outputFile}`);
console.log(`Embedded ${localFiles.length} local file(s); output ${(Buffer.byteLength(html) / 1024 / 1024).toFixed(2)} MiB.`);
