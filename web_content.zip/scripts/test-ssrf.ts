import assert from "node:assert/strict";
import { isPrivateOrReservedIp, validateAndNormalizeUrl, SSRFError } from "../src/lib/security/ssrf";

const blockedIps = [
  "127.0.0.1",
  "10.0.0.1",
  "172.16.5.4",
  "192.168.1.10",
  "169.254.169.254",
  "100.64.0.1",
  "::1",
  "fe80::1",
  "fc00::1",
  "::ffff:127.0.0.1",
];

for (const ip of blockedIps) {
  assert.equal(isPrivateOrReservedIp(ip), true, `Expected ${ip} to be blocked`);
}

assert.equal(isPrivateOrReservedIp("93.184.216.34"), false, "Expected public IP to be allowed");

const blockedUrls = [
  "http://localhost:3000",
  "http://127.0.0.1/admin",
  "http://169.254.169.254/latest/meta-data/",
  "file:///etc/passwd",
  "http://user:pass@example.com",
  "http://internal.local",
];

for (const url of blockedUrls) {
  assert.throws(() => validateAndNormalizeUrl(url), SSRFError, `Expected ${url} to throw SSRFError`);
}

const ok = validateAndNormalizeUrl("https://example.com/about#team");
assert.equal(ok.toString(), "https://example.com/about");

console.log("All SSRF unit assertions passed.");
