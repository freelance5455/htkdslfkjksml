import fs from 'fs';
import { STAGE_02_QUESTIONS } from '../src/data/stage02Questions';
import { normalizeArabicString } from '../src/engine/normalization';
import { validateCrosswordLayout } from '../src/engine/CrosswordValidator';
import {
  CrosswordLayout,
  CrosswordLayoutWord,
  CrosswordLayoutCell,
  LayoutCellCoordinate,
  CrosswordLayoutClue
} from '../src/types/crosswordLayout';

function cleanWord(str: string): string {
  return normalizeArabicString(str.replace(/\s+/g, ''));
}

const words = STAGE_02_QUESTIONS.map((q) => ({
  id: q.id,
  clue: q.clue,
  answer: q.answer,
  norm: cleanWord(q.answer),
  len: cleanWord(q.answer).length
}));

type Dir = 'across' | 'down';

interface Placement {
  word: typeof words[0];
  dir: Dir;
  r: number;
  c: number;
  reversed: boolean;
}

function solveUltra(GRID_SIZE: number, timeoutMs = 25000): Placement[] | null {
  const startTime = Date.now();
  let globalBest = 0;
  let attempts = 0;

  while (Date.now() - startTime < timeoutMs) {
    attempts++;
    const grid: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
    const cellAcross: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
    const cellDown: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));

    function canFit(wStr: string, dir: Dir, r: number, c: number): { valid: boolean; inters: number } {
      const len = wStr.length;
      if (dir === 'across') {
        if (c < 0 || c + len > GRID_SIZE || r < 0 || r >= GRID_SIZE) return { valid: false, inters: 0 };
        if (c > 0 && grid[r][c - 1] !== null) return { valid: false, inters: 0 };
        if (c + len < GRID_SIZE && grid[r][c + len] !== null) return { valid: false, inters: 0 };

        let inters = 0;
        for (let k = 0; k < len; k++) {
          const cur = grid[r][c + k];
          if (cur !== null) {
            if (cur !== wStr[k]) return { valid: false, inters: 0 };
            if (cellAcross[r][c + k] !== null) return { valid: false, inters: 0 };
            inters++;
          } else {
            if (r > 0 && grid[r - 1][c + k] !== null) return { valid: false, inters: 0 };
            if (r < GRID_SIZE - 1 && grid[r + 1][c + k] !== null) return { valid: false, inters: 0 };
          }
        }
        return { valid: inters > 0, inters };
      } else {
        if (r < 0 || r + len > GRID_SIZE || c < 0 || c >= GRID_SIZE) return { valid: false, inters: 0 };
        if (r > 0 && grid[r - 1][c] !== null) return { valid: false, inters: 0 };
        if (r + len < GRID_SIZE && grid[r + len][c] !== null) return { valid: false, inters: 0 };

        let inters = 0;
        for (let k = 0; k < len; k++) {
          const cur = grid[r + k][c];
          if (cur !== null) {
            if (cur !== wStr[k]) return { valid: false, inters: 0 };
            if (cellDown[r + k][c] !== null) return { valid: false, inters: 0 };
            inters++;
          } else {
            if (c > 0 && grid[r + k][c - 1] !== null) return { valid: false, inters: 0 };
            if (c < GRID_SIZE - 1 && grid[r + k][c + 1] !== null) return { valid: false, inters: 0 };
          }
        }
        return { valid: inters > 0, inters };
      }
    }

    function applyPlacement(p: Placement) {
      const wStr = p.reversed ? p.word.norm.split('').reverse().join('') : p.word.norm;
      for (let k = 0; k < p.word.len; k++) {
        const cr = p.dir === 'down' ? p.r + k : p.r;
        const cc = p.dir === 'across' ? p.c + k : p.c;
        grid[cr][cc] = wStr[k];
        if (p.dir === 'across') cellAcross[cr][cc] = p.word.id;
        else cellDown[cr][cc] = p.word.id;
      }
    }

    function removePlacement(p: Placement) {
      for (let k = 0; k < p.word.len; k++) {
        const cr = p.dir === 'down' ? p.r + k : p.r;
        const cc = p.dir === 'across' ? p.c + k : p.c;
        if (p.dir === 'across') {
          cellAcross[cr][cc] = null;
          if (cellDown[cr][cc] === null) grid[cr][cc] = null;
        } else {
          cellDown[cr][cc] = null;
          if (cellAcross[cr][cc] === null) grid[cr][cc] = null;
        }
      }
    }

    const placedHistory: Placement[] = [];
    const sortedLongest = [...words].sort((a, b) => b.len - a.len);
    const root = sortedLongest[Math.floor(Math.random() * 4)];
    const rootDir: Dir = Math.random() > 0.5 ? 'across' : 'down';
    const rootR = rootDir === 'across' ? Math.floor(GRID_SIZE / 2) : Math.floor((GRID_SIZE - root.len) / 2);
    const rootC = rootDir === 'down' ? Math.floor(GRID_SIZE / 2) : Math.floor((GRID_SIZE - root.len) / 2);

    const rootPlacement: Placement = { word: root, dir: rootDir, r: rootR, c: rootC, reversed: false };
    applyPlacement(rootPlacement);
    placedHistory.push(rootPlacement);

    // Fast candidate generation by indexing board cells
    function getCandidatesForWord(w: typeof words[0]): { dir: Dir; r: number; c: number; reversed: boolean; inters: number; score: number }[] {
      const candidates: { dir: Dir; r: number; c: number; reversed: boolean; inters: number; score: number }[] = [];
      const seen = new Set<string>();

      for (let r = 0; r < GRID_SIZE; r++) {
        for (let c = 0; c < GRID_SIZE; c++) {
          const boardChar = grid[r][c];
          if (!boardChar) continue;

          for (const rev of [false, true]) {
            const wStr = rev ? w.norm.split('').reverse().join('') : w.norm;
            for (let k = 0; k < wStr.length; k++) {
              if (wStr[k] === boardChar) {
                // If board cell has across word, we can place a down word
                if (cellAcross[r][c] !== null && cellDown[r][c] === null) {
                  const startR = r - k;
                  const startC = c;
                  const key = `down_${startR}_${startC}_${rev}`;
                  if (!seen.has(key)) {
                    seen.add(key);
                    const fit = canFit(wStr, 'down', startR, startC);
                    if (fit.valid) {
                      const distCenter = Math.abs(startR + w.len / 2 - GRID_SIZE / 2) + Math.abs(startC - GRID_SIZE / 2);
                      const score = fit.inters * 40 + w.len * 2 - distCenter * 0.8 - (rev ? 1 : 0) + Math.random() * 2;
                      candidates.push({ dir: 'down', r: startR, c: startC, reversed: rev, inters: fit.inters, score });
                    }
                  }
                }

                // If board cell has down word, we can place an across word
                if (cellDown[r][c] !== null && cellAcross[r][c] === null) {
                  const startR = r;
                  const startC = c - k;
                  const key = `across_${startR}_${startC}_${rev}`;
                  if (!seen.has(key)) {
                    seen.add(key);
                    const fit = canFit(wStr, 'across', startR, startC);
                    if (fit.valid) {
                      const distCenter = Math.abs(startR - GRID_SIZE / 2) + Math.abs(startC + w.len / 2 - GRID_SIZE / 2);
                      const score = fit.inters * 40 + w.len * 2 - distCenter * 0.8 - (rev ? 1 : 0) + Math.random() * 2;
                      candidates.push({ dir: 'across', r: startR, c: startC, reversed: rev, inters: fit.inters, score });
                    }
                  }
                }
              }
            }
          }
        }
      }

      return candidates;
    }

    // Step-by-step greedy search with local lookahead
    let failed = false;
    while (placedHistory.length < words.length) {
      const placedIds = new Set(placedHistory.map((p) => p.word.id));
      const unplaced = words.filter((w) => !placedIds.has(w.id));

      let bestWord: typeof words[0] | null = null;
      let bestCandidates: ReturnType<typeof getCandidatesForWord> | null = null;
      let minCandidateCount = Infinity;

      for (const w of unplaced) {
        const cands = getCandidatesForWord(w);
        if (cands.length === 0) {
          failed = true;
          break;
        }
        if (cands.length < minCandidateCount) {
          minCandidateCount = cands.length;
          bestWord = w;
          bestCandidates = cands;
        }
      }

      if (failed || !bestWord || !bestCandidates || bestCandidates.length === 0) {
        break;
      }

      bestCandidates.sort((a, b) => b.score - a.score);
      const topPick = bestCandidates[Math.floor(Math.random() * Math.min(3, bestCandidates.length))];

      const p: Placement = {
        word: bestWord,
        dir: topPick.dir,
        r: topPick.r,
        c: topPick.c,
        reversed: topPick.reversed
      };

      applyPlacement(p);
      placedHistory.push(p);
    }

    if (placedHistory.length > globalBest) {
      globalBest = placedHistory.length;
      console.log(`[Attempt ${attempts}] New Best: ${globalBest}/${words.length} placed!`);
    }

    if (placedHistory.length === words.length) {
      console.log(`🎉 Found complete solution on attempt ${attempts}!`);
      return placedHistory;
    }
  }

  return null;
}

function buildAndValidate(GRID_SIZE: number, solved: Placement[]): CrosswordLayout | null {
  const gridChars: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
  solved.forEach((p) => {
    const wStr = p.reversed ? p.word.norm.split('').reverse().join('') : p.word.norm;
    for (let k = 0; k < p.word.len; k++) {
      const cr = p.dir === 'down' ? p.r + k : p.r;
      const cc = p.dir === 'across' ? p.c + k : p.c;
      gridChars[cr][cc] = wStr[k];
    }
  });

  const cells: CrosswordLayoutCell[] = [];
  const blackCells: LayoutCellCoordinate[] = [];

  for (let r = 0; r < GRID_SIZE; r++) {
    for (let c = 0; c < GRID_SIZE; c++) {
      const char = gridChars[r][c];
      if (char === null) {
        blackCells.push({ row: r, col: c });
        cells.push({ row: r, column: c, isBlocked: true, letter: '' });
      } else {
        const acrossW = solved.find((p) => p.dir === 'across' && p.r === r && c >= p.c && c < p.c + p.word.len);
        const downW = solved.find((p) => p.dir === 'down' && p.c === c && r >= p.r && r < p.r + p.word.len);
        cells.push({
          row: r,
          column: c,
          isBlocked: false,
          letter: char,
          acrossWordId: acrossW?.word.id,
          downWordId: downW?.word.id
        });
      }
    }
  }

  const layoutWords: CrosswordLayoutWord[] = solved.map((p) => {
    const coords: LayoutCellCoordinate[] = [];
    for (let k = 0; k < p.word.len; k++) {
      coords.push({
        row: p.dir === 'down' ? p.r + k : p.r,
        col: p.dir === 'across' ? p.c + k : p.c
      });
    }

    return {
      id: p.word.id,
      clue: p.word.clue,
      answer: p.word.answer,
      normalizedAnswer: p.word.norm,
      direction: p.dir,
      startRow: p.r,
      startColumn: p.c,
      length: p.word.len,
      cells: coords,
      number: 1,
      reversed: p.reversed
    };
  });

  layoutWords.sort((a, b) => {
    if (a.startRow !== b.startRow) return a.startRow - b.startRow;
    return a.startColumn - b.startColumn;
  });

  layoutWords.forEach((w, idx) => {
    w.number = idx + 1;
    const cell = cells.find((c) => c.row === w.startRow && c.column === w.startColumn);
    if (cell) {
      cell.clueNumber = w.number;
    }
  });

  const clues: CrosswordLayoutClue[] = layoutWords.map((w) => ({
    id: w.id,
    number: w.number,
    direction: w.direction,
    clue: w.clue,
    length: w.length,
    wordId: w.id,
    reversed: w.reversed
  }));

  const layout: CrosswordLayout = {
    gridRows: GRID_SIZE,
    gridColumns: GRID_SIZE,
    cells,
    words: layoutWords,
    clues,
    blackCells
  };

  const validation = validateCrosswordLayout(layout);
  if (validation.isValid) {
    return layout;
  } else {
    console.log('Validation failed:', validation.items.filter((i) => !i.passed));
    return null;
  }
}

async function run() {
  console.log('Running Ultra Fast Indexed Solver...');
  for (const size of [19, 18, 20, 17, 21]) {
    console.log(`\nTesting size ${size}x${size}...`);
    const solution = solveUltra(size, 15000);
    if (solution) {
      const layout = buildAndValidate(size, solution);
      if (layout) {
        console.log(`🏆 SUCCESS! Valid layout for Stage 2 in ${size}x${size} saved to src/data/golden_stage_02.json`);
        fs.writeFileSync('./src/data/golden_stage_02.json', JSON.stringify(layout, null, 2));
        return;
      }
    }
  }
}

run();
