#!/usr/bin/env python3
import sys
import os
import zipfile
import hashlib
import base64
import subprocess
import shutil

def sha256_b64(data: bytes) -> str:
    digest = hashlib.sha256(data).digest()
    return base64.b64encode(digest).decode('utf-8')

def repack_and_sign_apk(input_apk_path, output_apk_path, index_html_content, extra_files=None):
    if extra_files is None:
        extra_files = {}

    pem_key_path = "release_key.pem"
    if not os.path.exists(pem_key_path):
        subprocess.run([
            "openssl", "pkcs12", "-in", "android/app/release.keystore",
            "-nodes", "-passin", "pass:taskearnpro2026", "-out", pem_key_path
        ], check=True)

    temp_dir = "temp_apk_extract"
    if os.path.exists(temp_dir):
        shutil.rmtree(temp_dir)
    os.makedirs(temp_dir, exist_ok=True)

    # 1. Extract existing APK
    with zipfile.ZipFile(input_apk_path, 'r') as zip_ref:
        zip_ref.extractall(temp_dir)

    # 2. Remove old META-INF signature files
    meta_inf_dir = os.path.join(temp_dir, "META-INF")
    if os.path.exists(meta_inf_dir):
        shutil.rmtree(meta_inf_dir)
    os.makedirs(meta_inf_dir, exist_ok=True)

    # 3. Write new index.html to assets/public/index.html
    assets_index = os.path.join(temp_dir, "assets", "public", "index.html")
    os.makedirs(os.path.dirname(assets_index), exist_ok=True)
    with open(assets_index, "w", encoding="utf-8") as f:
        f.write(index_html_content)

    # Write any extra files
    for rel_path, content in extra_files.items():
        full_p = os.path.join(temp_dir, rel_path)
        os.makedirs(os.path.dirname(full_p), exist_ok=True)
        if isinstance(content, str):
            with open(full_p, "w", encoding="utf-8") as f:
                f.write(content)
        elif isinstance(content, bytes):
            with open(full_p, "wb") as f:
                f.write(content)

    # 4. Generate MANIFEST.MF
    manifest_entries = []
    
    # Collect all files except META-INF
    all_files = []
    for root, dirs, files in os.walk(temp_dir):
        for file in files:
            full_path = os.path.join(root, file)
            rel_path = os.path.relpath(full_path, temp_dir).replace("\\", "/")
            if not rel_path.startswith("META-INF"):
                all_files.append((rel_path, full_path))
    
    all_files.sort(key=lambda x: x[0])

    manifest_lines = [
        "Manifest-Version: 1.0",
        "Created-By: 1.0 (TaskEarnPro Custom Signer)",
        ""
    ]

    sf_lines = [
        "Signature-Version: 1.0",
        "Created-By: 1.0 (TaskEarnPro Custom Signer)",
        ""
    ]

    manifest_bytes_for_sf = []

    for rel_path, full_path in all_files:
        with open(full_path, "rb") as f:
            data = f.read()
        digest = sha256_b64(data)

        # Manifest entry
        entry = f"Name: {rel_path}\r\nSHA-256-Digest: {digest}\r\n\r\n"
        manifest_lines.append(f"Name: {rel_path}")
        manifest_lines.append(f"SHA-256-Digest: {digest}")
        manifest_lines.append("")

        # SF entry digest of manifest entry
        entry_bytes = f"Name: {rel_path}\r\nSHA-256-Digest: {digest}\r\n\r\n".encode("utf-8")
        entry_digest = sha256_b64(entry_bytes)

        sf_lines.append(f"Name: {rel_path}")
        sf_lines.append(f"SHA-256-Digest: {entry_digest}")
        sf_lines.append("")

    manifest_content = "\r\n".join(manifest_lines) + "\r\n"
    manifest_path = os.path.join(meta_inf_dir, "MANIFEST.MF")
    with open(manifest_path, "wb") as f:
        f.write(manifest_content.encode("utf-8"))

    # SF file main digest
    manifest_main_digest = sha256_b64(manifest_content.encode("utf-8"))
    sf_lines.insert(2, f"SHA-256-Digest-Manifest: {manifest_main_digest}")

    sf_content = "\r\n".join(sf_lines) + "\r\n"
    sf_path = os.path.join(meta_inf_dir, "TASKEARN.SF")
    with open(sf_path, "wb") as f:
        f.write(sf_content.encode("utf-8"))

    # 5. Sign SF file with OpenSSL to generate TASKEARN.RSA
    rsa_path = os.path.join(meta_inf_dir, "TASKEARN.RSA")
    subprocess.run([
        "openssl", "smime", "-sign",
        "-signer", pem_key_path,
        "-inkey", pem_key_path,
        "-outform", "DER",
        "-noattr",
        "-md", "sha256",
        "-in", sf_path,
        "-out", rsa_path
    ], check=True)

    # 6. Re-zip into output_apk_path
    if os.path.exists(output_apk_path):
        os.remove(output_apk_path)

    with zipfile.ZipFile(output_apk_path, 'w', compression=zipfile.ZIP_DEFLATED) as zip_out:
        for root, dirs, files in os.walk(temp_dir):
            for file in files:
                full_path = os.path.join(root, file)
                rel_path = os.path.relpath(full_path, temp_dir).replace("\\", "/")
                zip_out.write(full_path, rel_path)

    shutil.rmtree(temp_dir)
    print(f"✅ Successfully repacked and signed APK: {output_apk_path}")

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "diagnostic":
        test_html = """<!DOCTYPE html>
<html>
<body style="background:white;color:black;text-align:center;padding-top:100px;font-family:sans-serif;">
<h1>ANDROID WEBVIEW TEST</h1>
<p>If you can see this, Android WebView is working.</p>
</body>
</html>"""
        repack_and_sign_apk("public/downloads/Task-Earn-Pro-2.apk", "public/downloads/Task-Earn-Pro-2.apk", test_html)
        shutil.copy("public/downloads/Task-Earn-Pro-2.apk", "dist/downloads/Task-Earn-Pro-2.apk")
