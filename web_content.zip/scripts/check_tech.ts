import { goldenLayout, goldenLayout2, goldenLayout3, goldenLayout4, goldenLayout5, goldenLayout6, goldenLayout7 } from '../src/data/goldenStageLoader';

const all = [goldenLayout, goldenLayout2, goldenLayout3, goldenLayout4, goldenLayout5, goldenLayout6, goldenLayout7];
console.log('Checking الألياف الضوئية:');
all.forEach((layout, idx) => {
  layout.words.forEach(w => {
    if (w.answer.includes('الألياف') || w.answer.includes('الضوئية')) {
      console.log(`Found in stage ${idx+1}: [${w.clue}] => [${w.answer}]`);
    }
  });
});
