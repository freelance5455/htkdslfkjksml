import JSZip from 'jszip';
import fs from 'fs';
import path from 'path';

const zip = new JSZip();

function addDir(dirPath, zipFolder) {
  const items = fs.readdirSync(dirPath);
  for (const item of items) {
    if (['node_modules', 'dist', '.git', '.tempmediaStorage'].includes(item)) continue;
    const fullPath = path.join(dirPath, item);
    const relPath = path.relative('.', fullPath);
    if (relPath === 'public/salespro-applet.zip') continue;

    const stat = fs.statSync(fullPath);
    if (stat.isDirectory()) {
      addDir(fullPath, zipFolder.folder(item));
    } else {
      zipFolder.file(item, fs.readFileSync(fullPath));
    }
  }
}

addDir('.', zip);

zip.generateNodeStream({ type: 'nodebuffer', streamFiles: true, compression: 'DEFLATE' })
  .pipe(fs.createWriteStream('public/salespro-applet.zip'))
  .on('finish', () => {
    const size = fs.statSync('public/salespro-applet.zip').size;
    console.log('salespro-applet.zip created: ' + (size / 1024).toFixed(1) + ' KB');
  });
