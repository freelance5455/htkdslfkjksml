#!/usr/bin/env python3
"""Repeatable static checks for Moto Sim V73 engineering phase 4.
Requires Python 3 and Node.js. This is not a substitute for a live WebGL/device test.
"""
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
HTML = ROOT / "www" / "index.html"
source = HTML.read_text(encoding="utf-8")
checks = []

def check(label, condition):
    checks.append((label, bool(condition)))

script_blocks = []
for idx, match in enumerate(re.finditer(r"<script\b([^>]*)>(.*?)</script\s*>", source, re.I | re.S), 1):
    attrs, body = match.groups()
    if "src=" not in attrs.lower() and body.strip():
        script_blocks.append((idx, body))
        temp = ROOT / f".phase4-inline-{idx}.js"
        temp.write_text(body, encoding="utf-8")
        result = subprocess.run(["node", "--check", str(temp)], capture_output=True, text=True)
        check(f"inline JavaScript block {idx} parses", result.returncode == 0)
        if result.returncode:
            print(result.stderr)
        temp.unlink(missing_ok=True)

check("exactly three inline JavaScript blocks found", len(script_blocks) == 3)
check("local-space engine bounds helper exists", "function mtGetLocalBounds(target)" in source)
check("local bounds transform world vertices back into engine space", "applyMatrix4(inverse)" in source)
check("factory twin-turbo engines are recognized", "['2JZ','RB26','ROTARY2','ROTARY3'].includes(model)" in source)
check("factory supercharged V8 is recognized", "['V8SC'].includes(model)" in source)
check("saved tune power uses engine-specific boost hardware", "const power=torque*rpm*(boostHardware?boost:1);" in source)
check("engineering diagnostic API is exposed", "window.__mtGetEngineeringAudit=mtGetEngineeringAudit;" in source)
check("native boosted engines can use intercooler upgrades", "if(native.turbo||native.super)return true;" in source)
check("floating fake internal-part fallback is absent", "const fake = mtCreatePartModel" not in source and "root.userData.missingNativeMounts" in source)

start = source.index("const ENGINE_DEFS = {")
end = source.index("\n};\n\nconst SPECIAL_ENGINE_TYPES", start)
engine_block = source[start:end]
keys = re.findall(r"(?<![\w])'([^']+)'\s*:\s*\{", engine_block)
check("all literal engine keys are unique", len(keys) == len(set(keys)))
check("at least 30 engine definitions exist", len(keys) >= 30)

for label, passed in checks:
    print(("PASS" if passed else "FAIL") + "  " + label)
print(f"\nSummary: {sum(ok for _, ok in checks)}/{len(checks)} checks passed; {len(keys)} engine definitions found.")
if not all(ok for _, ok in checks):
    sys.exit(1)
