#!/usr/bin/env python3
import sys
import os
import shutil
from sign_apk import repack_and_sign_apk

def main():
    root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    dist_index = os.path.join(root_dir, "dist", "index.html")
    apk_file = os.path.join(root_dir, "public", "downloads", "Task-Earn-Pro-2.apk")
    
    if not os.path.exists(dist_index):
        print("❌ Error: dist/index.html not found.")
        sys.exit(1)
        
    with open(dist_index, "r", encoding="utf-8") as f:
        html_content = f.read()

    repack_and_sign_apk(apk_file, apk_file, html_content)
    
    dist_apk_dir = os.path.join(root_dir, "dist", "downloads")
    os.makedirs(dist_apk_dir, exist_ok=True)
    shutil.copy(apk_file, os.path.join(dist_apk_dir, "Task-Earn-Pro-2.apk"))
    shutil.copy(apk_file, os.path.join(root_dir, "public", "taskearnpro-release.apk"))
    shutil.copy(apk_file, os.path.join(root_dir, "dist", "taskearnpro-release.apk"))
    print("🎉 App APK repacked and signed successfully with latest single-file bundle!")

if __name__ == "__main__":
    main()
