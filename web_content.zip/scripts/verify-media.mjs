import { chromium } from "playwright";
import fs from "node:fs";

const file = process.argv[2] ?? "test-output/quiz-engine-test.mp4";
const base64 = fs.readFileSync(file).toString("base64");
const browser = await chromium.launch({ args: ["--no-sandbox", "--autoplay-policy=no-user-gesture-required"] });
try {
  const page = await browser.newPage();
  await page.goto("about:blank");
  const result = await page.evaluate(async (b64) => {
    const res = await fetch(`data:video/mp4;base64,${b64}`);
    const buf = await res.arrayBuffer();
    const blob = new Blob([buf], { type: "video/mp4" });
    const url = URL.createObjectURL(blob);
    const video = document.createElement("video");
    video.muted = true;
    video.src = url;
    document.body.appendChild(video);
    const meta = await new Promise((resolve, reject) => {
      video.onloadedmetadata = () => resolve({ duration: video.duration, width: video.videoWidth, height: video.videoHeight });
      video.onerror = () => reject(new Error("video decode failed"));
      setTimeout(() => reject(new Error("metadata timeout")), 20000);
    });
    video.currentTime = Math.min(6.4, meta.duration - 0.4);
    await new Promise((resolve) => {
      video.onseeked = resolve;
      setTimeout(resolve, 8000);
    });
    await new Promise((resolve) => setTimeout(resolve, 500));
    const canvas = document.createElement("canvas");
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext("2d");
    ctx.drawImage(video, 0, 0);
    const pixels = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
    let lum = 0, green = 0, colorful = 0;
    for (let i = 0; i < pixels.length; i += 4) {
      lum += pixels[i] * 0.3 + pixels[i + 1] * 0.59 + pixels[i + 2] * 0.11;
      if (pixels[i + 1] > pixels[i] + 18 && pixels[i + 1] > pixels[i + 2] + 10) green++;
      if (Math.abs(pixels[i] - pixels[i + 1]) + Math.abs(pixels[i + 1] - pixels[i + 2]) > 30) colorful++;
    }
    const count = pixels.length / 4;
    let audio = { decoded: false, rms: 0, duration: 0 };
    try {
      const ac = new OfflineAudioContext(1, 1, 48000);
      const decoded = await ac.decodeAudioData(buf.slice(0));
      let sum = 0;
      const data = decoded.getChannelData(0);
      for (let i = 0; i < data.length; i += 3) sum += data[i] * data[i];
      audio = { decoded: true, rms: Math.sqrt(sum / (data.length / 3)), duration: decoded.duration };
    } catch (err) {
      audio = { decoded: false, rms: 0, duration: 0, error: String(err) };
    }
    const frame = canvas.toDataURL("image/png");
    return {
      meta,
      canvas: { width: canvas.width, height: canvas.height },
      averageLuminance: lum / count,
      greenPixelRatio: green / count,
      colorfulPixelRatio: colorful / count,
      frame,
      audio,
      readyState: video.readyState,
      error: video.error ? video.error.message : null,
    };
  }, base64);
  fs.writeFileSync("test-output/exported-frame.png", Buffer.from(result.frame.split(",")[1], "base64"));
  delete result.frame;
  console.log(JSON.stringify(result, null, 2));
  const okFrame = result.averageLuminance > 6 && result.colorfulPixelRatio > 0.01 && result.greenPixelRatio > 0.002;
  console.log(okFrame ? "FRAME_PASS" : "FRAME_FAIL", result.audio.decoded ? "AUDIO_DECODED" : "AUDIO_DECODE_UNAVAILABLE", result.audio.rms > 0.0005 ? "AUDIO_SIGNAL_PASS" : "AUDIO_SIGNAL_LOW");
  process.exit(okFrame ? 0 : 1);
} finally {
  await browser.close();
}
