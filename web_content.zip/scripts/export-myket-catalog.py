#!/usr/bin/env python3
"""Export the Myket SKU catalog for the current Space Runner source revision.

Run from any working directory:
    python3 scripts/export-myket-catalog.py

The script intentionally derives products and price hints from the checked-in
JavaScript catalog. It does not create products in the Myket developer panel.
"""
from __future__ import annotations

import csv
import math
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SOURCE = ROOT / "src" / "game" / "space-runner.js"
OUTPUT = ROOT / "MYKET-PRODUCT-CATALOG-fa.csv"


def required(pattern: str, text: str, label: str) -> re.Match[str]:
    match = re.search(pattern, text, re.S)
    if not match:
        raise SystemExit(f"Could not parse {label} from {SOURCE}")
    return match


def export() -> list[tuple[str, str, int, str, str]]:
    source = SOURCE.read_text(encoding="utf-8")
    products: list[tuple[str, str, int, str, str]] = [
        ("sr_vip_royal", "non_consumable", 199000, "VIP شاهانه", "مالکیت دائمی"),
        ("sr_no_ads_forever", "non_consumable", 99000, "حذف تبلیغات همیشگی", "مالکیت دائمی"),
        ("sr_satellite_companion", "non_consumable", 70000, "ماهواره همراه", "مالکیت دائمی"),
    ]

    # Gem packs are declared as data-price/data-gems attributes in the shop UI.
    gem_rows = re.findall(r'data-price=\\"(\d+)\\"\s+data-gems=\\"(\d+)\\"', source)
    if not gem_rows:
        # Some source edits may normalize quotes; support the unescaped form too.
        gem_rows = re.findall(r'data-price="(\d+)"\s+data-gems="(\d+)"', source)
    for price_text, gems_text in gem_rows:
        price, gems = int(price_text), int(gems_text)
        products.append((f"sr_gems_{gems}_{price}", "consumable", price,
                         f"بسته {gems} الماس", "تحویل یک‌باره از صف امن"))

    # Read all current cosmetic prices from CAT_ITEMS and the separate SK table.
    cat_match = required(r"const CAT_ITEMS = \{(.*?)\n\};", source, "CAT_ITEMS")
    cat_block = cat_match.group(1)
    categories = ["trail", "jump", "aura", "start", "ground", "filter", "decor"]
    items: dict[tuple[str, str], tuple[str, str, int]] = {}
    for category in categories:
        start = re.search(rf"(?m)^\s*{category}:\s*\[", cat_block)
        if not start:
            continue
        remaining = cat_block[start.end():]
        next_category = re.search(
            r"(?m)^\s*(?:" + "|".join(categories + ["skin"]) + r"): \s*(?:\[|SK_ORDER)",
            remaining,
        )
        segment = remaining[:next_category.start()] if next_category else remaining
        for item in re.finditer(
            r'\{\s*key:"([^"]+)"\s*,\s*name:"([^"]+)"\s*,\s*icon:"[^"]*"\s*,\s*cur:"([a-z]+)"\s*,\s*price:(\d+)',
            segment,
        ):
            key, name, currency, price = item.groups()
            items[(category, key)] = (name, currency, int(price))

    order_match = required(r"const SK_ORDER = \[([^\]]+)\]", source, "SK_ORDER")
    skin_keys = re.findall(r'"([a-z0-9_]+)"', order_match.group(1))
    for key in skin_keys:
        skin_match = re.search(
            rf'(?m)^\s*{re.escape(key)}\s*:\s*\{{[^\n]*?cur:"([a-z]+)"(?:\s*,\s*price:(\d+))?',
            source,
        )
        if not skin_match:
            skin_match = re.search(
                rf'(?m)^SK\.{re.escape(key)}\s*=\s*\{{[^\n]*?cur:"([a-z]+)"(?:\s*,\s*price:(\d+))?',
                source,
            )
        if skin_match:
            line = source[skin_match.start():source.find("\n", skin_match.start())]
            name_match = re.search(r'n:"([^"]+)"', line)
            items[("skin", key)] = (
                name_match.group(1) if name_match else key,
                skin_match.group(1),
                int(skin_match.group(2) or 0),
            )

    gem_value, coin_value = 85, 1.8

    def item_value(category: str, key: str) -> float:
        _name, currency, price = items.get((category, key), (key, "free", 0))
        if currency == "irl":
            return price
        if currency == "gems":
            return price * gem_value
        if currency == "coins":
            return price * coin_value
        return 0.0

    for (category, key), (name, currency, price) in sorted(items.items()):
        if currency == "irl":
            products.append((f"sr_item_{category}_{key}", "non_consumable", price,
                             name, "مالکیت دائمی"))

    pack_discount_match = required(r"const PACK_DISC = \{([^}]+)\}", source, "PACK_DISC")
    pack_discounts = {
        key: int(value)
        for key, value in re.findall(r"(pk_[a-z0-9_]+):(\d+)", pack_discount_match.group(1))
    }
    pack_block = required(r"const PACKS = \[(.*?)\n\];", source, "PACKS").group(1)
    for line in pack_block.splitlines():
        match = re.search(
            r'\{ id:"(pk_[a-z0-9_]+)", name:"([^"]+)", icon:"[^"]+", price:\d+, items:(\[.*?\]), gems:(\d+) \}',
            line,
        )
        if not match:
            continue
        pack_id, name, items_literal, gems_text = match.groups()
        pairs = re.findall(r'\["([a-z]+)","([a-z0-9_]+)"\]', items_literal)
        value = int(gems_text) * gem_value + sum(item_value(c, k) for c, k in pairs)
        price = max(2000, math.floor(value * (1 - pack_discounts[pack_id] / 100) / 100 + 0.5) * 100)
        products.append((f"sr_pack_{pack_id}", "non_consumable", price, name,
                         "مالکیت دائمی + اقلام یک‌باره از صف امن"))

    offer_discount_match = required(r"const OFFER_DISC = \{([^}]+)\}", source, "OFFER_DISC")
    offer_discounts = {
        key: int(value)
        for key, value in re.findall(r"(of_[a-z0-9_]+):(\d+)", offer_discount_match.group(1))
    }
    offer_block = required(r"const OFFERS = \[(.*?)\n\];", source, "OFFERS").group(1)
    up_costs = {
        "jump": [(500, 0), (1000, 0), (1500, 0), (2000, 0), (3000, 0), (4000, 0), (5000, 20), (6000, 40), (8000, 60), (10000, 100)],
        "bold": [(400, 0), (800, 0), (1200, 0), (1600, 0), (2400, 0), (3200, 0), (4000, 15), (4800, 30), (6400, 45), (8000, 75)],
        "dash": [(400, 0), (800, 0), (1200, 0), (1600, 0), (2400, 0), (3200, 0), (4000, 15), (4800, 30), (6400, 45), (8000, 75)],
    }
    for line in offer_block.splitlines():
        match = re.search(
            r'\{ id:"(of_[a-z0-9_]+)", name:"([^"]+)".*?gems:(\d+), coins:(\d+), items:(\[.*?\])(?:, up:\{([^}]+)\})?(?:, power:\[([^]]*)\])?(?:, boost:\{([^}]+)\})? \}',
            line,
        )
        if not match:
            continue
        offer_id, name, gems_text, coins_text, items_literal, up_text, power_text, boost_text = match.groups()
        pairs = re.findall(r'\["([a-z]+)","([a-z0-9_]+)"\]', items_literal)
        value = int(gems_text) * gem_value + int(coins_text) * coin_value
        value += sum(item_value(c, k) for c, k in pairs)
        upgrades = {key: int(level) for key, level in re.findall(r'(jump|bold|dash):\s*(\d+)', up_text or "")}
        for key, level in upgrades.items():
            value += sum(coins * coin_value + gems * gem_value for coins, gems in up_costs[key][:level])
        boosts = {key: int(count) for key, count in re.findall(r'(head|shield|mag|combo):\s*(\d+)', boost_text or "")}
        value += (boosts.get("head", 0) * 150 + boosts.get("shield", 0) * 300 +
                  boosts.get("mag", 0) * 220 + boosts.get("combo", 0) * 180) * coin_value
        if "shield" in (power_text or ""):
            value += round(500 * gem_value / coin_value) * coin_value
        price = max(2000, math.floor(value * (1 - offer_discounts[offer_id] / 100) / 100 + 0.5) * 100)
        products.append((f"sr_offer_{offer_id}", "non_consumable", price, name,
                         "مالکیت دائمی + اقلام یک‌باره از صف امن"))

    unique: list[tuple[str, str, int, str, str]] = []
    seen: set[str] = set()
    for row in products:
        if row[0] in seen:
            raise SystemExit(f"Duplicate SKU generated: {row[0]}")
        if row[2] <= 0:
            raise SystemExit(f"Invalid price for SKU: {row[0]}")
        seen.add(row[0])
        unique.append(row)
    return unique


def main() -> None:
    products = export()
    with OUTPUT.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["productId", "productType", "priceHintToman", "productName", "deliveryMode"])
        writer.writerows(products)
    consumables = sum(row[1] == "consumable" for row in products)
    non_consumables = len(products) - consumables
    print(f"Wrote {len(products)} products: {consumables} consumable, {non_consumables} non-consumable")
    print(f"Output: {OUTPUT}")


if __name__ == "__main__":
    main()
