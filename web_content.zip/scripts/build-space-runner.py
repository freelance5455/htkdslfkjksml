#!/usr/bin/env python3
from pathlib import Path

orig = Path("/workspace/attachments/Pasted Text-1e3cd7a8-21bf-4834-991f-cbf6c894403f.txt").read_text(encoding="utf-8")
tail = Path("/workspace/src/game/v80-tail.js").read_text(encoding="utf-8")

style_s = orig.find("<style>") + len("<style>")
style_e = orig.find("</style>")
css = orig[style_s:style_e].strip()

css = css.replace(
    "html,body{ margin:0; width:100%; height:100%; overflow:hidden; background:#020511; font-family:Tahoma,Arial,sans-serif; touch-action:none; }",
    "#sr-root{ position:fixed; inset:0; width:100%; height:100%; overflow:hidden; background:#020511; font-family:Tahoma,Arial,sans-serif; touch-action:none; color:#fff; }",
)
css = css.replace("canvas{ display:block; width:100%; height:100%; }", "#sr-root canvas{ display:block; width:100%; height:100%; }")
css = css.replace("#ui{ position:fixed;", "#ui{ position:absolute;")
css += """
#pauseBtn{ position:absolute; left:10px; top:10px; pointer-events:auto; padding:8px 11px; margin:0; background:#07122ddd; z-index:25; border-radius:10px; }
#settingsFab{ position:absolute; left:55px; top:10px; pointer-events:auto; padding:8px 11px; margin:0; background:#07122ddd; z-index:25; border-radius:10px; }
.volRow{ display:flex; align-items:center; gap:10px; margin:10px 0; text-align:right; }
.volRow input[type=range]{ flex:1; }
.gfxRow{ display:flex; gap:6px; justify-content:center; flex-wrap:wrap; margin:8px 0; }
.gfxBtn{ background:#162447; border:1px solid #3f5896; border-radius:10px; padding:8px 12px; font-size:12px; color:#b9c7eb; }
.gfxBtn.active{ background:#315ee8; color:#fff; border-color:#65eaff; }
#iapBox .panel{ max-width:420px; }
.switch{ transform:scale(1.2); }
#sfAlert{ position:absolute; top:230px; left:50%; transform:translateX(-50%); background:rgba(180,80,0,0.9); color:#fff; padding:8px 16px; border-radius:20px; font-weight:bold; font-size:14px; border:1px solid #ffd447; z-index:15; }
"""

body_s = orig.find("<body>") + len("<body>")
script_s = orig.find("<script>")
html = orig[body_s:script_s].strip()
# drop original canvas/ui closing we'll keep as-is

html_patches = [
    (
        '<button class="modeBtn" id="modeHard" onclick="setMode(\'hard\')">💀 سخت</button>',
        '<button class="modeBtn" id="modeHard" onclick="setMode(\'hard\')">💀 سخت</button>\n<button class="modeBtn" id="modeAurora" onclick="setMode(\'aurora\')">🌌 شفق</button>',
    ),
    (
        '<button class="secondary" id="lbBtn">🏆 برترین‌ها</button>',
        '<button class="secondary" id="lbBtn">🏆 برترین‌ها</button>\n<button class="secondary" id="settingsBtn">⚙️ تنظیمات</button>\n<button class="secondary" id="codexBtn">📖 کُدکس</button>\n<div id="luckyBanner" class="small hidden" style="color:#9dffb0;"></div>',
    ),
    (
        '<button id="musicButton">🎵</button>',
        '<button id="musicButton">🎵</button>\n<button id="pauseBtn" class="hidden">⏸</button>',
    ),
    (
        '<div id="showerBadge" class="badge hidden" style="background:#004d66; border-color:#00d2ff;">🌠 بارش الماس</div>',
        '<div id="showerBadge" class="badge hidden" style="background:#004d66; border-color:#00d2ff;">🌠 بارش الماس</div>\n<div id="sfBadge" class="badge hidden" style="background:#b33900; border-color:#ffd447;">☀️ شراره خورشیدی</div>\n<div id="ghostBadge" class="badge hidden" style="background:#3b0764; border-color:#d7b3ff;">👻 روح</div>\n<div id="comboArmorBadge" class="badge hidden" style="background:#1d3a1d; border-color:#9dffb0;">🔗 زره زنجیره</div>',
    ),
    (
        '<div id="rgAlert" class="hidden">🌟 یک کهکشان جایزه نزدیک می‌شود!</div>',
        '<div id="rgAlert" class="hidden">🌟 یک کهکشان جایزه نزدیک می‌شود!</div>\n<div id="sfAlert" class="hidden">☀️ شراره خورشیدی نزدیک است!</div>',
    ),
    (
        '👑 عضویت VIP کیهانی (یک‌بار برای همیشه)<br><span class="small">۱۰۰٪ سکه بیشتر همیشگی + سپر رایگان هر بازی + ادامه فوری بدون تبلیغ + ۲ چرخش شانس روزانه + اسکین اختصاصی «پادشاه کیهانی» + نشان ویژه</span>',
        '👑 پک شاهانه VIP (یک‌بار برای همیشه)<br><span class="small">اسکین پادشاه کیهانی + هاله تاج + ورود شاهانه + زمین تخت پادشاهی + دنباله و پرش سلطنتی + فیلتر دربار طلایی + ماهواره همراه + ۱۰۰٪ سکه بیشتر + سپر رایگان هر بازی + ۲ چرخش روزانه + ۱ زنده شدن رایگان در هر دور (با حذف تبلیغات می‌شود ۲ بار)</span>',
    ),
    (
        '<div>🚫 حذف تبلیغات همیشگی<br><span class="small">همه‌ی دکمه‌های تماشای تبلیغ از این پس فوری اجرا می‌شوند</span></div><button class="iap-btn" id="buyNoAds">۴۵,۰۰۰ ت</button>',
        '<div>🚫 حذف تبلیغات یک‌ماهه<br><span class="small">۳۰ روز بدون انتظار تبلیغ برای الماس و پاداش. زنده شدن رایگان فقط ۱ بار در هر دور (نه نامحدود). با VIP می‌شود ۲ بار. <span id="noAdsStatus"></span></span></div><button class="iap-btn" id="buyNoAds">۶۵,۰۰۰ ت</button>',
    ),
    (
        '<button class="ad-btn" id="watchAdGemsMenu">📺 ۵ 💎 رایگان (تماشای تبلیغ)</button><br>',
        '<button class="ad-btn" id="watchAdGemsMenu">📺 ۵ 💎 رایگان (۶ بار در روز)</button><div id="adGemsHint" class="small"></div><br>',
    ),
    (
        '<button class="iap-btn" data-price="10000" data-gems="50">۱۰,۰۰۰ ت</button>',
        '<button class="iap-btn" data-price="10000" data-gems="40">۱۰,۰۰۰ ت</button>',
    ),
    (
        '<span class="small">50 💎</span>',
        '<span class="small">40 💎</span>',
    ),
    (
        '<span class="small">160 💎 (شامل جایزه)</span></div><button class="iap-btn" data-price="30000" data-gems="160">۳۰,۰۰۰ ت</button>',
        '<span class="small">120 💎 (شامل جایزه)</span></div><button class="iap-btn" data-price="30000" data-gems="120">۳۰,۰۰۰ ت</button>',
    ),
    (
        '<span class="small">350 💎</span></div><button class="iap-btn" data-price="60000" data-gems="350">۶۰,۰۰۰ ت</button>',
        '<span class="small">280 💎</span></div><button class="iap-btn" data-price="60000" data-gems="280">۶۰,۰۰۰ ت</button>',
    ),
    (
        '<span class="small">950 💎</span></div><button class="iap-btn" data-price="150000" data-gems="950">۱۵۰,۰۰۰ ت</button>',
        '<span class="small">750 💎</span></div><button class="iap-btn" data-price="150000" data-gems="750">۱۵۰,۰۰۰ ت</button>',
    ),
    (
        '<span class="small">2400 💎</span></div><button class="iap-btn" data-price="350000" data-gems="2400">۳۵۰,۰۰۰ ت</button>',
        '<span class="small">1900 💎</span></div><button class="iap-btn" data-price="350000" data-gems="1900">۳۵۰,۰۰۰ ت</button>',
    ),
    (
        '<span class="small">8000 💎</span></div><button class="iap-btn premium" data-price="990000" data-gems="8000">۹۹۰,۰۰۰ ت</button>',
        '<span class="small">6500 💎</span></div><button class="iap-btn premium" data-price="990000" data-gems="6500">۹۹۰,۰۰۰ ت</button>',
    ),
    (
        '<button id="buyTicketBH">40 💎</button>',
        '<button id="buyTicketBH">55 💎</button>',
    ),
    (
        '<button id="buyTicketRG">35 💎</button>',
        '<button id="buyTicketRG">48 💎</button>',
    ),
    (
        '<button id="buyTicketDS">25 💎</button>',
        '<button id="buyTicketDS">35 💎</button>',
    ),
    (
        '<button id="buyFilterSunset">30 💎</button>',
        '<button id="buyFilterSunset">42 💎</button>',
    ),
    (
        '<button id="buyFilterNight">30 💎</button>',
        '<button id="buyFilterNight">42 💎</button>',
    ),
    (
        '<button id="buyFilterEmerald">30 💎</button>',
        '<button id="buyFilterEmerald">42 💎</button>',
    ),
    (
        '<button id="buyTrailCyan">25 💎</button>',
        '<button id="buyTrailCyan">35 💎</button>',
    ),
    (
        '<button id="buyTrailPink">25 💎</button>',
        '<button id="buyTrailPink">35 💎</button>',
    ),
    (
        '<button id="buyTrailGreen">25 💎</button>',
        '<button id="buyTrailGreen">35 💎</button>',
    ),
    (
        '<button id="buyJumpIce">20 💎</button>',
        '<button id="buyJumpIce">28 💎</button>',
    ),
    (
        '<button id="buyJumpStars">20 💎</button>',
        '<button id="buyJumpStars">28 💎</button>',
    ),
    (
        '<button id="buyAuraPulse">35 💎</button>',
        '<button id="buyAuraPulse">48 💎</button>',
    ),
    (
        '<button id="buyStartFxWarp">35 💎</button>',
        '<button id="buyStartFxWarp">48 💎</button>',
    ),
    (
        '<button id="buyStartFxFlash">25 💎</button>',
        '<button id="buyStartFxFlash">35 💎</button>',
    ),
    (
        '<button id="btnCoinX2">90 💎</button>',
        '<button id="btnCoinX2">120 💎</button>',
    ),
    (
        '<button id="btnLucky">55 💎</button>',
        '<button id="btnLucky">75 💎</button>',
    ),
    (
        '<button id="btnGemLuck">70 💎</button>',
        '<button id="btnGemLuck">95 💎</button>',
    ),
    (
        '<button id="btnTriple">150 💎</button>',
        '<button id="btnTriple">200 💎</button>',
    ),
    (
        '<button id="btnDodge">130 💎</button>',
        '<button id="btnDodge">175 💎</button>',
    ),
    (
        '<button id="buySkinPurple">25 💎</button>',
        '<button id="buySkinPurple">35 💎</button>',
    ),
    (
        '<button id="buySkinRed">25 💎</button>',
        '<button id="buySkinRed">35 💎</button>',
    ),
    (
        '<button id="buySkinRainbow">80 💎</button>',
        '<button id="buySkinRainbow">110 💎</button>',
    ),
    (
        '<button class="premium" id="doubleDaily">💎 دو برابر کردن سکه‌ی امروز (۱۰ 💎)</button>',
        '<button class="premium" id="doubleDaily">💎 دو برابر کردن سکه‌ی امروز (۱۵ 💎)</button>',
    ),
    (
        '<button class="premium" id="doubleLevel">💎 دو برابر کردن پاداش (۵ 💎)</button>',
        '<button class="premium" id="doubleLevel">💎 دو برابر کردن پاداش (۸ 💎)</button>',
    ),
    (
        '<button class="premium" id="gemContinue">💎 ادامه فوری (۳۰ 💎)</button>',
        '<button class="premium" id="gemContinue">💎 ادامه فوری (۴۲ 💎)</button>\n<div id="continueInfo" class="small" style="color:#ffd447;margin-top:6px;"></div>',
    ),
    (
        '<div class="sub">امتیاز: <b id="finalScore">0</b><br>سکه این دور: <span class="iconCoin"></span> <b id="finalCoins">0</b><br>رکورد: 🏆 <b id="best">0</b></div>',
        '<div class="sub">امتیاز: <b id="finalScore">0</b><br>سکه این دور: <span class="iconCoin"></span> <b id="finalCoins">0</b><br>رکورد: 🏆 <b id="best">0</b></div>\n<div id="runRecap" class="small" style="margin-bottom:10px;"></div>',
    ),
    (
        '<div class="small" style="color:#ffd447;">👑 اعضای VIP بدون تبلیغ و فوری زنده می‌شوند</div>',
        '<div class="small" style="color:#ffd447;">حذف تبلیغات = ۱ زنده شدن رایگان در هر دور · VIP + حذف تبلیغات = ۲ بار · بعد از آن باید تبلیغ ببینی</div>',
    ),
]
for a, b in html_patches:
    if a not in html:
        print("WARN missing HTML patch:", a[:80])
    else:
        html = html.replace(a, b, 1)

extra_html = r'''
<div class="row"><div>🔗 زره زنجیره (یک‌بار مصرف)<br><span class="small">یک‌بار زنجیره را از قطع شدن نجات می‌دهد</span></div><button id="buyBoostCombo">180 🪙 <span id="cntCombo"></span></button></div>
<div class="row"><div>🎯 سکه نزدیک‌بود<br><span class="small">هر عبور نزدیک یک سکه اضافه می‌دهد</span></div><button id="btnNearMiss">85 💎</button></div>
<div class="row"><div>🛰️ ماهواره همراه<br><span class="small">یک ماهواره کوچک دور سفینه می‌چرخد — هدیه VIP هم هست</span></div><button class="iap-btn" id="buySatellite">۳۹,۰۰۰ ت</button></div>
<div class="row"><div>🌅 فیلتر دربار طلایی<br><span class="small">ویژه پک شاهانه VIP</span></div><button id="buyFilterRoyal">👑 VIP</button></div>
<div class="row"><div>👑 دنباله سلطنتی</div><button id="buyTrailRoyal">👑 VIP</button></div>
<div class="row"><div>👑 پرش امپراتور</div><button id="buyJumpRoyal">👑 VIP</button></div>
<div class="row"><div>👑 زمین تخت پادشاهی</div><button id="buyGroundRoyal">👑 VIP</button></div>
<div class="row"><div>👑 هاله تاج کیهانی</div><button id="buyAuraRoyal">👑 VIP</button></div>
<div class="row"><div>👑 ورود شاهانه</div><button id="buyStartFxRoyal">👑 VIP</button></div>
<div id="skinComet" class="skin locked">☄️ شهاب<br><button id="buySkinComet">55 💎</button></div>
<div id="skinAurora" class="skin locked">🌌 شفق<br><button id="buySkinAurora">55 💎</button></div>
'''
html = html.replace(
    '<div id="skinPhantom" class="skin locked premiumSkin">⚡ روح فضایی<br><span class="small">پرداخت واقعی</span><br><button id="buySkinPhantom">۱۲۹,۰۰۰ ت</button></div>',
    '<div id="skinPhantom" class="skin locked premiumSkin">⚡ روح فضایی<br><span class="small">پرداخت واقعی</span><br><button id="buySkinPhantom">۱۲۹,۰۰۰ ت</button></div>\n'
    + '<div id="skinComet" class="skin locked">☄️ شهاب<br><button id="buySkinComet">55 💎</button></div>\n'
    + '<div id="skinAurora" class="skin locked">🌌 شفق<br><button id="buySkinAurora">55 💎</button></div>',
    1,
)

html = html.replace(
    '<div class="row"><div>⚡ پاورآپ سریع‌تر<br><span class="small">پاورآپ‌ها بیشتر و زودتر ظاهر می‌شوند</span></div><button id="btnFastPower">3500</button></div>',
    '<div class="row"><div>⚡ پاورآپ سریع‌تر<br><span class="small">پاورآپ‌ها بیشتر و زودتر ظاهر می‌شوند</span></div><button id="btnFastPower">3500</button></div>\n'
    '<div class="row"><div>🎯 سکه نزدیک‌بود<br><span class="small">هر عبور نزدیک یک سکه اضافه می‌دهد</span></div><button id="btnNearMiss">85 💎</button></div>',
    1,
)
html = html.replace(
    '<div class="row"><div>🧲 آهنربای شروع<br><span class="small">۷ ثانیه آهنربای رایگان از ابتدا</span></div><button id="buyBoostMag">220 🪙 <span id="cntMag"></span></button></div>',
    '<div class="row"><div>🧲 آهنربای شروع<br><span class="small">۷ ثانیه آهنربای رایگان از ابتدا</span></div><button id="buyBoostMag">220 🪙 <span id="cntMag"></span></button></div>\n'
    '<div class="row"><div>🔗 زره زنجیره<br><span class="small">یک‌بار زنجیره را از قطع شدن حفظ می‌کند</span></div><button id="buyBoostCombo">180 🪙 <span id="cntCombo"></span></button></div>',
    1,
)
html = html.replace(
    '<div class="row"><div>✨ فلاش نورانی</div><button id="buyStartFxFlash">35 💎</button></div>',
    '<div class="row"><div>✨ فلاش نورانی</div><button id="buyStartFxFlash">35 💎</button></div>\n'
    '<div class="row"><div>👑 ورود شاهانه<br><span class="small">ویژه پک VIP</span></div><button id="buyStartFxRoyal">👑 VIP</button></div>\n'
    '<div class="row"><div>🛰️ ماهواره همراه<br><span class="small">ماهواره کوچک دور سفینه — در پک VIP هست</span></div><button class="iap-btn" id="buySatellite">۳۹,۰۰۰ ت</button></div>\n'
    '<div class="row"><div>👑 هاله تاج کیهانی</div><button id="buyAuraRoyal">👑 VIP</button></div>\n'
    '<div class="row"><div>👑 زمین تخت پادشاهی</div><button id="buyGroundRoyal">👑 VIP</button></div>\n'
    '<div class="row"><div>👑 دنباله سلطنتی</div><button id="buyTrailRoyal">👑 VIP</button></div>\n'
    '<div class="row"><div>👑 پرش امپراتور</div><button id="buyJumpRoyal">👑 VIP</button></div>\n'
    '<div class="row"><div>🌅 فیلتر دربار طلایی</div><button id="buyFilterRoyal">👑 VIP</button></div>',
    1,
)

html = html.replace(
    '<div class="card" style="border:1px solid #65eaff;">📅 ماموریت هفتگی: ۵۰۰۰ امتیاز کل این هفته',
    '''<div class="card">🔥 زنجیره ۱۵ بساز<br><b id="m10">0/15</b><div class="bar"><div id="m10bar" class="fill"></div></div><span class="small">پاداش: ۸۰ سکه + ۴ الماس</span><br><button id="claimM10" class="reward hidden">🎁 دریافت</button></div>
<div class="card" style="border:1px solid #65eaff;">📅 ماموریت هفتگی: ۵۰۰۰ امتیاز کل این هفته''',
    1,
)

screens = r'''
<section id="settings" class="screen hidden">
<div class="panel">
<h2>تنظیمات</h2>
<div class="volRow"><span>موسیقی</span><input id="musicVol" type="range" min="0" max="100" value="75"></div>
<div class="volRow"><span>افکت صوتی</span><input id="sfxVol" type="range" min="0" max="100" value="85"></div>
<div class="sub">گرافیک — برای موبایل ضعیف «سبک» را بزن</div>
<div class="gfxRow">
<button class="gfxBtn" data-gfx="high">بالا</button>
<button class="gfxBtn" data-gfx="medium">متوسط</button>
<button class="gfxBtn" data-gfx="low">سبک (FPS)</button>
</div>
<div class="row"><div>لرزش صفحه</div><input id="shakeToggle" class="switch" type="checkbox" checked></div>
<button class="secondary" id="closeSettings">بازگشت</button>
</div>
</section>
<section id="pauseMenu" class="screen hidden">
<div class="panel">
<h2>مکث</h2>
<button id="resumeBtn">ادامه</button><br>
<button class="secondary" id="pauseSettings">تنظیمات</button>
<button class="secondary" id="pauseQuit">خروج از دور</button>
</div>
</section>
<section id="codex" class="screen hidden">
<div class="panel">
<h2>کُدکس رویدادها</h2>
<div id="codexList"></div>
<button class="secondary" id="closeCodex">بازگشت</button>
</div>
</section>
<section id="iapBox" class="screen hidden">
<div class="panel">
<h2 id="iapTitle">پرداخت</h2>
<div class="sub" id="iapDesc"></div>
<button class="iap-btn" id="iapConfirm">تأیید پرداخت آزمایشی</button><br>
<button class="secondary" id="iapCancel">انصراف</button>
</div>
</section>
'''
html = html.replace('<!-- MODAL VIDEO AD -->', screens + '\n<!-- MODAL VIDEO AD -->', 1)

script_s = orig.find("<script>")
script_e = orig.find("</script>")
script = orig[script_s + len("<script>"):script_e]
cut = script.find("function drawRewardGalaxyBackground")
if cut < 0:
    raise SystemExit("cut point missing")
script = script[:cut]
script = script.replace('"use strict";', "", 1)

# data migration already in tail; patch prices in upgradeDefs
script = script.replace('["btnCoinX2","coinX2",90,"gems"]', '["btnCoinX2","coinX2",120,"gems"]')
script = script.replace('["btnLucky","luckyBox",55,"gems"]', '["btnLucky","luckyBox",75,"gems"]')
script = script.replace('["btnGemLuck","gemLuck",70,"gems"]', '["btnGemLuck","gemLuck",95,"gems"]')
script = script.replace('["btnTriple","tripleJump",150,"gems"]', '["btnTriple","tripleJump",200,"gems"]')
script = script.replace('["btnDodge","dodgeChance",130,"gems"]', '["btnDodge","dodgeChance",175,"gems"]')

script = script.replace(
    '{ name:"Purple", key:"purple", currency:"gems", price:25 }',
    '{ name:"Purple", key:"purple", currency:"gems", price:35 }',
)
script = script.replace(
    '{ name:"Red", key:"red", currency:"gems", price:25 }',
    '{ name:"Red", key:"red", currency:"gems", price:35 }',
)
script = script.replace(
    '{ name:"Rainbow", key:"rainbow", currency:"gems", price:80 }',
    '{ name:"Rainbow", key:"rainbow", currency:"gems", price:110 }',
)

script = script.replace(
    '["modeClassic","modeTime","modeHard"].forEach(id => el(id).classList.remove("active"));',
    '["modeClassic","modeTime","modeHard","modeAurora"].forEach(id => { const n=el(id); if(n) n.classList.remove("active"); });',
)
script = script.replace(
    '''    if(m==="hard") {
        el("modeHard").classList.add("active");
        el("modeDesc").textContent = "💀 سرعت بالاو چالش شدید فضایی";
    }
}''',
    '''    if(m==="hard") {
        el("modeHard").classList.add("active");
        el("modeDesc").textContent = "💀 سرعت بالا و چالش شدید فضایی";
    }
    if(m==="aurora") {
        const a = el("modeAurora"); if(a) a.classList.add("active");
        el("modeDesc").textContent = "🌌 شب شفق قطبی — الماس بیشتر، منظره شفق";
    }
}''',
)

script = script.replace(
    '["menu","shop","missions","ach","stats","daily","over","levelUp","wheel","leaderboard"].forEach(hide);',
    '["menu","shop","missions","ach","stats","daily","over","levelUp","wheel","leaderboard","settings","pauseMenu","codex","iapBox"].forEach(hide);',
)

script = script.replace(
    "    last = performance.now();\n    requestAnimationFrame(loop);\n}",
    "    last = performance.now();\n    rafId = requestAnimationFrame(loop);\n}",
)

script = script.replace("function power(){ powers.push({ x: W + 30, y: player.ground - 80 - Math.random() * 100, type: Math.floor(Math.random() * 6), r: 16, spin: 0 }); }",
                        "function power(){ powers.push({ x: W + 30, y: player.ground - 80 - Math.random() * 100, type: Math.floor(Math.random() * 7), r: 16, spin: 0 }); }")

script = script.replace(
    "    if(!playing) return;",
    "    if(!playing) return;\n    if(typeof paused !== 'undefined' && paused){ last = t; rafId = requestAnimationFrame(loop); return; }",
    1,
)

script = script.replace(
    "    obstacleT += dt; coinT += dt;",
    "    if(typeof extraTick === 'function') extraTick(dt, effSpeed);\n    obstacleT += dt; coinT += dt;",
)

script = script.replace(
    "(data.gemLuck ? 600 : 850)",
    "((data.gemLuck || gameMode==='aurora') ? 520 : 850)",
)

script = script.replace(
    "if(Math.random() < 0.2) {",
    "if((typeof gfxLow!=='function' || !gfxLow()) && Math.random() < 0.2) {",
)

script = script.replace(
    """            if(combo > 0 && !inRewardGalaxy){
                combo = 0;
                floatText(player.x, player.y - 20, "زنجیره قطع شد!", "#ff4444");
            }""",
    """            if(combo > 0 && !inRewardGalaxy){
                if(typeof comboArmor !== 'undefined' && comboArmor > 0){
                    comboArmor--;
                    floatText(player.x, player.y - 20, "زره زنجیره نجات داد!", "#9dffb0");
                    toast("🔗 زره زنجیره فعال شد");
                } else {
                    combo = 0;
                    floatText(player.x, player.y - 20, "زنجیره قطع شد!", "#ff4444");
                }
            }""",
)

script = script.replace(
    "    if(dashTimer <= 0){",
    "    if(dashTimer <= 0 && (typeof ghostTimer==='undefined' || ghostTimer<=0) && (typeof invulnT==='undefined' || invulnT<=0)){",
)

script = script.replace(
    """            } else if(p.type === 5){
                scoreMultTimer = 6;
                floatText(p.x, p.y, "×2 امتیاز", "#ffe066");
                toast("✨ امتیاز دوبل فعال شد!");
            }""",
    """            } else if(p.type === 5){
                scoreMultTimer = 6;
                floatText(p.x, p.y, "×2 امتیاز", "#ffe066");
                toast("✨ امتیاز دوبل فعال شد!");
            } else if(p.type === 6){
                ghostTimer = 4.5;
                floatText(p.x, p.y, "روح!", "#d7b3ff");
                toast("👻 حالت روح — از موانع رد شو");
            }""",
)

script = script.replace(
    "const gain = Math.round((data.coinX2On ? 2 : 1) * ((inBlackHole || inRewardGalaxy) ? 2 : 1) * (data.vip ? 2 : 1) * (wasSuper ? 10 : 1));",
    "const gain = Math.round((data.coinX2On ? 2 : 1) * ((inBlackHole || inRewardGalaxy) ? 2 : 1) * (data.vip ? 2 : 1) * (wasSuper ? 10 : 1) * ((data.luckyUntil && Date.now() < data.luckyUntil) ? 1.25 : 1));",
)

script = script.replace(
    "    ctx.restore();\n\n    /* برخوردها",
    "    if(typeof drawOverlays==='function') drawOverlays();\n    ctx.restore();\n\n    /* برخوردها",
)

script = script.replace("requestAnimationFrame(loop);", "rafId = requestAnimationFrame(loop);")

script = script.replace(
    '{ key:"ds", name:"🌠 بارش الماس" }',
    '{ key:"ds", name:"🌠 بارش الماس" },\n    { key:"sf", name:"☀️ شراره خورشیدی" }',
)

script = script.replace(
    "speed = gameMode === \"hard\" ? 6.5 : 5;",
    "speed = gameMode === \"hard\" ? 6.5 : (gameMode === \"aurora\" ? 4.7 : 5);",
)

script = script.replace(
    "    } else {\n        g.addColorStop(0, \"#020512\"); g.addColorStop(.5, \"#0a1948\"); g.addColorStop(1, \"#1c2a6e\");\n    }",
    "    } else if(currentBiome === \"aurora\" || gameMode === \"aurora\"){\n        g.addColorStop(0, \"#041422\"); g.addColorStop(.5, \"#12382a\"); g.addColorStop(1, \"#1a1038\");\n    } else {\n        g.addColorStop(0, \"#020512\"); g.addColorStop(.5, \"#0a1948\"); g.addColorStop(1, \"#1c2a6e\");\n    }",
)

script = script.replace(
    '    if(score >= 3000) currentBiome = "golden";',
    '    if(gameMode === "aurora") currentBiome = "aurora";\n    else if(score >= 3000) currentBiome = "golden";',
)
script = script.replace('addEventListener("resize", resize);', "")
script = script.replace(
    '    ["btnFastPower","fastPower",3500,"coins"]\n];',
    '    ["btnFastPower","fastPower",3500,"coins"],\n    ["btnNearMiss","nearMissCoin",85,"gems"]\n];',
)
script = script.replace(
    'data = JSON.parse(localStorage.getItem("spaceRunnerV70")||"null") || defaultData();',
    'data = JSON.parse(localStorage.getItem("spaceRunnerV80")||localStorage.getItem("spaceRunnerV70")||"null") || defaultData();',
)
script = script.replace(
    'localStorage.setItem("spaceRunnerV70", JSON.stringify(data));',
    'localStorage.setItem("spaceRunnerV80", JSON.stringify(data));',
)

# updateShop skin list to include comet/aurora
script = script.replace(
    'const allSkinIds = ["skinBlue","skinCyan","skinGold","skinPurple","skinRed","skinRainbow","skinNova","skinCosmicKing","skinPhantom"];',
    'const allSkinIds = ["skinBlue","skinCyan","skinGold","skinPurple","skinRed","skinRainbow","skinNova","skinCosmicKing","skinPhantom","skinComet","skinAurora"];',
)
script = script.replace(
    'const map = {blue:"skinBlue",cyan:"skinCyan",gold:"skinGold",purple:"skinPurple",red:"skinRed",rainbow:"skinRainbow",nova:"skinNova",cosmicking:"skinCosmicKing",phantom:"skinPhantom"};',
    'const map = {blue:"skinBlue",cyan:"skinCyan",gold:"skinGold",purple:"skinPurple",red:"skinRed",rainbow:"skinRainbow",nova:"skinNova",cosmicking:"skinCosmicKing",phantom:"skinPhantom",comet:"skinComet",aurora:"skinAurora"};',
)

# trail royal particles
script = script.replace(
    'const runTrailType = data.trailColor === "cyan" ? "trailCyan" : data.trailColor === "pink" ? "trailPink" : data.trailColor === "green" ? "trailGreen" : "flame";',
    'const runTrailType = data.trailColor === "cyan" ? "trailCyan" : data.trailColor === "pink" ? "trailPink" : data.trailColor === "green" ? "trailGreen" : data.trailColor === "royal" ? "goldtrail" : "flame";',
)

script = script.replace(
    "    updateShop();\n    updateAchievements();\n    updateStats();\n}",
    "    updateShop();\n    updateAchievements();\n    updateStats();\n    if(typeof updateExtraUI==='function') updateExtraUI();\n}",
)

combined = script + "\n" + tail + "\nbootExtra();\n"

js = (
    "export function boot(root) {\n"
    "  if (!document.getElementById(\"sr-game-css\")) {\n"
    "    const style = document.createElement(\"style\");\n"
    "    style.id = \"sr-game-css\";\n"
    "    style.textContent = " + repr(css) + ";\n"
    "    document.head.appendChild(style);\n"
    "  }\n"
    "  root.innerHTML = " + repr(html) + ";\n\n"
    + combined
    + "\n  return function cleanup() {\n"
    "    playing = false;\n"
    "    paused = true;\n"
    "    if (typeof rafId !== \"undefined\" && rafId) cancelAnimationFrame(rafId);\n"
    "    if (typeof stopMusic === \"function\") stopMusic();\n"
    "  };\n"
    "}\n"
)

out = Path("/workspace/src/game/space-runner.js")
out.write_text(js, encoding="utf-8")
print("wrote", out, "bytes", out.stat().st_size)
print("html has pauseMenu", "pauseMenu" in html)
print("html has settings", 'id="settings"' in html)
print("script has extraTick hook", "extraTick" in combined)
print("upgradeDefs 120", 'coinX2",120' in combined)
