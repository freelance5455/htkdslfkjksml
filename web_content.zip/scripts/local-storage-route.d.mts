import type { Plugin } from 'vite'
export function localStorageRoute(): Plugin
