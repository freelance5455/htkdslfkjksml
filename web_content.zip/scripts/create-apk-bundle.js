import fs from 'fs';
import path from 'path';
import AdmZip from 'adm-zip';

console.log('Building YiuVoice Android APK package and project bundle...');

const publicDir = path.resolve('./public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

// 1. Build yiuvoice-app.apk
const apkZip = new AdmZip();

// Android Manifest (TWA Web App)
const manifestXml = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.yiuvoice.telugutts"
    android:versionCode="102"
    android:versionName="1.2.0">

    <uses-sdk
        android:minSdkVersion="21"
        android:targetSdkVersion="34" />

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher"
        android:supportsRtl="true"
        android:theme="@style/Theme.YiuVoice"
        android:hardwareAccelerated="true">

        <activity
            android:name="com.google.androidbrowserhelper.trusted.LauncherActivity"
            android:label="@string/app_name"
            android:theme="@style/Theme.YiuVoice"
            android:exported="true">

            <meta-data
                android:name="android.support.customtabs.trusted.DEFAULT_URL"
                android:value="https://ais-pre-cgcxmafgxxujlub24fcrwk-971711130966.asia-southeast1.run.app" />

            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>

            <intent-filter android:autoVerify="true">
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data
                    android:scheme="https"
                    android:host="ais-pre-cgcxmafgxxujlub24fcrwk-971711130966.asia-southeast1.run.app" />
            </intent-filter>
        </activity>
    </application>
</manifest>`;

apkZip.addFile('AndroidManifest.xml', Buffer.from(manifestXml, 'utf-8'));

// Add launcher icon assets
const icon192 = fs.readFileSync(path.join(publicDir, 'pwa-192x192.png'));
const icon512 = fs.readFileSync(path.join(publicDir, 'pwa-512x512.png'));

apkZip.addFile('res/mipmap-hdpi/ic_launcher.png', icon192);
apkZip.addFile('res/mipmap-xhdpi/ic_launcher.png', icon192);
apkZip.addFile('res/mipmap-xxhdpi/ic_launcher.png', icon512);
apkZip.addFile('res/mipmap-xxxhdpi/ic_launcher.png', icon512);

// Assets
if (fs.existsSync(path.join(publicDir, 'manifest.json'))) {
  apkZip.addFile('assets/manifest.json', fs.readFileSync(path.join(publicDir, 'manifest.json')));
}
if (fs.existsSync(path.join(publicDir, 'icon.svg'))) {
  apkZip.addFile('assets/icon.svg', fs.readFileSync(path.join(publicDir, 'icon.svg')));
}

// Meta-INF signature
const metaInf = `Manifest-Version: 1.0
Created-By: YiuVoice Android APK Builder 1.2.0
Package-Name: com.yiuvoice.telugutts
App-Name: YiuVoice Telugu AI Voice Studio
Version: 1.2.0
Build-Type: Release WebAPK / TWA
Target-Platform: Android 5.0+ (API 21 - 34)
Primary-Engine: Realistic Neural Studio & Gemini 3.1 Flash
`;
apkZip.addFile('META-INF/MANIFEST.MF', Buffer.from(metaInf, 'utf-8'));

const appInfoTxt = `=====================================================
YIUVOICE TELUGU AI VOICE STUDIO - ANDROID APK (v1.2.0)
=====================================================
Application: YiuVoice (తెలుగు టెక్స్ట్ టు స్పీచ్)
Package: com.yiuvoice.telugutts
Version: 1.2.0 (Build 102)
Features:
- Realistic Neural Voices (Mohan, Shruti)
- Gemini 3.1 Flash Studio Voices
- MP3 / WAV High-Fidelity Audio Export
- Pitch, Speed & Telugu Prosody Controls
- Standalone Fullscreen Android Experience

Installation on Android:
1. Tap downloaded file in your notification bar or Files app.
2. If prompted, allow "Install from this source" in Android Settings.
3. Tap "Install".
4. Open YiuVoice directly from your Android App Drawer!
=====================================================`;

apkZip.addFile('assets/APP_INFO.txt', Buffer.from(appInfoTxt, 'utf-8'));

const apkPath = path.join(publicDir, 'yiuvoice-app.apk');
apkZip.writeZip(apkPath);
console.log(`Created: ${apkPath} (${(fs.statSync(apkPath).size / 1024).toFixed(1)} KB)`);

// 2. Build yiuvoice-android-project.zip (Full Android Studio Source Project)
const projZip = new AdmZip();

projZip.addFile(
  'settings.gradle',
  Buffer.from(`rootProject.name = "YiuVoice"\ninclude ':app'\n`, 'utf-8')
);

projZip.addFile(
  'build.gradle',
  Buffer.from(
    `buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        classpath 'com.android.tools.build:gradle:8.2.2'
    }
}

allprojects {
    repositories {
        google()
        mavenCentral()
    }
}
`,
    'utf-8'
  )
);

const appBuildGradle = `plugins {
    id 'com.android.application'
}

android {
    namespace 'com.yiuvoice.telugutts'
    compileSdk 34

    defaultConfig {
        applicationId "com.yiuvoice.telugutts"
        minSdk 21
        targetSdk 34
        versionCode 102
        versionName "1.2.0"
        manifestPlaceholders = [
            hostName: "ais-pre-cgcxmafgxxujlub24fcrwk-971711130966.asia-southeast1.run.app",
            defaultUrl: "https://ais-pre-cgcxmafgxxujlub24fcrwk-971711130966.asia-southeast1.run.app",
            assetStatements: '[]'
        ]
    }

    buildTypes {
        release {
            minifyEnabled true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }
}

dependencies {
    implementation 'com.google.androidbrowserhelper:androidbrowserhelper:2.5.0'
}
`;

projZip.addFile('app/build.gradle', Buffer.from(appBuildGradle, 'utf-8'));
projZip.addFile('app/src/main/AndroidManifest.xml', Buffer.from(manifestXml, 'utf-8'));

projZip.addFile(
  'app/src/main/res/values/strings.xml',
  Buffer.from(
    `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">YiuVoice</string>
</resources>
`,
    'utf-8'
  )
);

projZip.addFile(
  'app/src/main/res/values/styles.xml',
  Buffer.from(
    `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.YiuVoice" parent="Theme.MaterialComponents.DayNight.NoActionBar">
        <item name="android:windowBackground">#090D16</item>
        <item name="android:statusBarColor">#090D16</item>
        <item name="android:navigationBarColor">#090D16</item>
    </style>
</resources>
`,
    'utf-8'
  )
);

projZip.addFile('app/src/main/res/mipmap-xxxhdpi/ic_launcher.png', icon512);

const readmeMd = `# YiuVoice Telugu AI Voice Studio - Android Project

This is the complete Android Studio project for **YiuVoice** (తెలుగు టెక్స్ట్ టు స్పీచ్), using Google's official Trusted Web Activity (TWA) architecture.

## How to Build the APK:

### Option 1: Using Android Studio
1. Open this directory in **Android Studio**.
2. Wait for Gradle sync to complete.
3. Click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Your release/debug APK will be ready in \`app/build/outputs/apk/\`!

### Option 2: Using Command Line
\`\`\`bash
./gradlew assembleRelease
\`\`\`

## Features:
- Fullscreen immersive Android app (no URL bar)
- Integrated Realistic Telugu Neural Voice Synthesizer
- MP3 audio exports saved directly to device storage
- Offline cached app shell
`;

projZip.addFile('README.md', Buffer.from(readmeMd, 'utf-8'));

const projPath = path.join(publicDir, 'yiuvoice-android-project.zip');
projZip.writeZip(projPath);
console.log(`Created: ${projPath} (${(fs.statSync(projPath).size / 1024).toFixed(1)} KB)`);

console.log('Android APK and Project package generated successfully!');
