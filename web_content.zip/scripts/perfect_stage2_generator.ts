import fs from 'fs';
import { STAGE_02_QUESTIONS } from '../src/data/stage02Questions';
import { normalizeArabicString } from '../src/engine/normalization';
import { validateCrosswordLayout } from '../src/engine/CrosswordValidator';
import {
  CrosswordLayout,
  CrosswordLayoutWord,
  CrosswordLayoutCell,
  LayoutCellCoordinate,
  CrosswordLayoutClue
} from '../src/types/crosswordLayout';

function cleanWord(str: string): string {
  return normalizeArabicString(str.replace(/\s+/g, ''));
}

const words = STAGE_02_QUESTIONS.map((q) => ({
  id: q.id,
  clue: q.clue,
  answer: q.answer,
  norm: cleanWord(q.answer),
  len: cleanWord(q.answer).length
}));

type Dir = 'across' | 'down';

interface Placement {
  word: typeof words[0];
  dir: Dir;
  r: number;
  c: number;
}

function solveStage2(GRID_SIZE: number): CrosswordLayout | null {
  const grid: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
  const acrossMap: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
  const downMap: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));

  function canFitStrict(w: typeof words[0], dir: Dir, r: number, c: number, placedCount: number): boolean {
    const len = w.len;
    if (dir === 'across') {
      if (c < 0 || c + len > GRID_SIZE || r < 0 || r >= GRID_SIZE) return false;
      // Cell immediately before and after must be empty (boundary condition)
      if (c > 0 && grid[r][c - 1] !== null) return false;
      if (c + len < GRID_SIZE && grid[r][c + len] !== null) return false;

      let inters = 0;
      for (let k = 0; k < len; k++) {
        const cur = grid[r][c + k];
        if (cur !== null) {
          if (cur !== w.norm[k]) return false; // Letter conflict
          if (acrossMap[r][c + k] !== null) return false; // Already has across word
          inters++;
        } else {
          // Parallel check: top and bottom must be empty unless a vertical word passes through
          if (r > 0 && grid[r - 1][c + k] !== null) return false;
          if (r < GRID_SIZE - 1 && grid[r + 1][c + k] !== null) return false;
        }
      }
      return placedCount === 0 || inters >= 1;
    } else {
      if (r < 0 || r + len > GRID_SIZE || c < 0 || c >= GRID_SIZE) return false;
      // Cell immediately before and after must be empty (boundary condition)
      if (r > 0 && grid[r - 1][c] !== null) return false;
      if (r + len < GRID_SIZE && grid[r + len][c] !== null) return false;

      let inters = 0;
      for (let k = 0; k < len; k++) {
        const cur = grid[r + k][c];
        if (cur !== null) {
          if (cur !== w.norm[k]) return false; // Letter conflict
          if (downMap[r + k][c] !== null) return false; // Already has down word
          inters++;
        } else {
          // Parallel check: left and right must be empty unless a horizontal word passes through
          if (c > 0 && grid[r + k][c - 1] !== null) return false;
          if (c < GRID_SIZE - 1 && grid[r + k][c + 1] !== null) return false;
        }
      }
      return placedCount === 0 || inters >= 1;
    }
  }

  function applyPlacement(p: Placement) {
    for (let k = 0; k < p.word.len; k++) {
      const cr = p.dir === 'down' ? p.r + k : p.r;
      const cc = p.dir === 'across' ? p.c + k : p.c;
      grid[cr][cc] = p.word.norm[k];
      if (p.dir === 'across') acrossMap[cr][cc] = p.word.id;
      else downMap[cr][cc] = p.word.id;
    }
  }

  function removePlacement(p: Placement) {
    for (let k = 0; k < p.word.len; k++) {
      const cr = p.dir === 'down' ? p.r + k : p.r;
      const cc = p.dir === 'across' ? p.c + k : p.c;
      if (p.dir === 'across') {
        acrossMap[cr][cc] = null;
        if (downMap[cr][cc] === null) grid[cr][cc] = null;
      } else {
        downMap[cr][cc] = null;
        if (acrossMap[cr][cc] === null) grid[cr][cc] = null;
      }
    }
  }

  const placed: Placement[] = [];

  // Root word is longest: منارة الإسكندرية (len 15)
  const root = words.find((w) => w.len === 15)!;
  const rootDir: Dir = 'across';
  const rootR = Math.floor(GRID_SIZE / 2);
  const rootC = Math.floor((GRID_SIZE - root.len) / 2);

  const rootP: Placement = { word: root, dir: rootDir, r: rootR, c: rootC };
  applyPlacement(rootP);
  placed.push(rootP);

  // Depth-first search with MRV
  function search(unplaced: typeof words): boolean {
    if (unplaced.length === 0) {
      return true;
    }

    type Cand = { word: typeof words[0]; dir: Dir; r: number; c: number; score: number };
    const candidatesByWord: { word: typeof words[0]; cands: Cand[] }[] = [];

    for (const w of unplaced) {
      const cands: Cand[] = [];
      for (const dir of ['across', 'down'] as Dir[]) {
        for (let r = 0; r < GRID_SIZE; r++) {
          for (let c = 0; c < GRID_SIZE; c++) {
            if (canFitStrict(w, dir, r, c, placed.length)) {
              const midR = dir === 'down' ? r + w.len / 2 : r;
              const midC = dir === 'across' ? c + w.len / 2 : c;
              const distCenter = Math.abs(midR - GRID_SIZE / 2) + Math.abs(midC - GRID_SIZE / 2);
              const score = w.len * 2 - distCenter * 0.8 + Math.random() * 2;
              cands.push({ word: w, dir, r, c, score });
            }
          }
        }
      }

      if (cands.length === 0) {
        return false; // Dead end: a word has 0 possible fits
      }

      candidatesByWord.push({ word: w, cands });
    }

    // Sort words by least number of candidate placements (MRV)
    candidatesByWord.sort((a, b) => a.cands.length - b.cands.length);
    const chosen = candidatesByWord[0];

    chosen.cands.sort((a, b) => b.score - a.score);

    const tryLimit = Math.min(8, chosen.cands.length);
    for (let i = 0; i < tryLimit; i++) {
      const cand = chosen.cands[i];
      const p: Placement = { word: chosen.word, dir: cand.dir, r: cand.r, c: cand.c };
      applyPlacement(p);
      placed.push(p);

      const nextUnplaced = unplaced.filter((w) => w.id !== chosen.word.id);
      if (search(nextUnplaced)) {
        return true;
      }

      placed.pop();
      removePlacement(p);
    }

    return false;
  }

  const unplaced = words.filter((w) => w.id !== root.id);
  if (!search(unplaced)) {
    return null;
  }

  // Convert to CrosswordLayout and validate
  const cells: CrosswordLayoutCell[] = [];
  const blackCells: LayoutCellCoordinate[] = [];

  for (let r = 0; r < GRID_SIZE; r++) {
    for (let c = 0; c < GRID_SIZE; c++) {
      const char = grid[r][c];
      if (char === null) {
        blackCells.push({ row: r, col: c });
        cells.push({ row: r, column: c, isBlocked: true, letter: '' });
      } else {
        cells.push({
          row: r,
          column: c,
          isBlocked: false,
          letter: char,
          acrossWordId: acrossMap[r][c] || undefined,
          downWordId: downMap[r][c] || undefined
        });
      }
    }
  }

  const layoutWords: CrosswordLayoutWord[] = placed.map((p) => {
    const coords: LayoutCellCoordinate[] = [];
    for (let k = 0; k < p.word.len; k++) {
      coords.push({
        row: p.dir === 'down' ? p.r + k : p.r,
        col: p.dir === 'across' ? p.c + k : p.c
      });
    }

    return {
      id: p.word.id,
      clue: p.word.clue,
      answer: p.word.answer,
      normalizedAnswer: p.word.norm,
      direction: p.dir,
      startRow: p.r,
      startColumn: p.c,
      length: p.word.len,
      cells: coords,
      number: 1,
      reversed: false
    };
  });

  layoutWords.sort((a, b) => {
    if (a.startRow !== b.startRow) return a.startRow - b.startRow;
    return a.startColumn - b.startColumn;
  });

  layoutWords.forEach((w, idx) => {
    w.number = idx + 1;
    const cell = cells.find((c) => c.row === w.startRow && c.column === w.startColumn);
    if (cell) {
      cell.clueNumber = w.number;
    }
  });

  const clues: CrosswordLayoutClue[] = layoutWords.map((w) => ({
    id: w.id,
    number: w.number,
    direction: w.direction,
    clue: w.clue,
    length: w.length,
    wordId: w.id,
    reversed: false
  }));

  const layout: CrosswordLayout = {
    gridRows: GRID_SIZE,
    gridColumns: GRID_SIZE,
    cells,
    words: layoutWords,
    clues,
    blackCells
  };

  const validation = validateCrosswordLayout(layout);
  if (validation.isValid) {
    return layout;
  } else {
    console.log('Layout failed validation items:', validation.items.filter((i) => !i.passed));
    return null;
  }
}

async function run() {
  console.log('Running Perfect Stage 2 Generator with rigorous validator constraints...');
  for (const size of [21, 22, 20, 23, 19]) {
    console.log(`Testing grid size ${size}x${size}...`);
    for (let tryNum = 0; tryNum < 20; tryNum++) {
      const layout = solveStage2(size);
      if (layout) {
        console.log(`🏆 FOUND PERFECT STAGE 2 LAYOUT on size ${size}x${size}!`);
        fs.writeFileSync('./src/data/golden_stage_02.json', JSON.stringify(layout, null, 2));
        console.log('Saved to src/data/golden_stage_02.json');
        return;
      }
    }
  }
}

run();
