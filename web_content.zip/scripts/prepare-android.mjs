import { existsSync, mkdirSync, copyFileSync, readFileSync, writeFileSync } from 'node:fs';
import { execSync } from 'node:child_process';

if (!existsSync('android')) {
  execSync('npx cap add android', { stdio: 'inherit' });
}

const iconRoot = 'assets/android';
const androidRes = 'android/app/src/main/res';
const densities = ['mdpi', 'hdpi', 'xhdpi', 'xxhdpi', 'xxxhdpi'];

for (const density of densities) {
  const srcDir = `${iconRoot}/mipmap-${density}`;
  const dstDir = `${androidRes}/mipmap-${density}`;
  if (!existsSync(srcDir)) throw new Error(`Icon assets missing: ${srcDir}`);
  mkdirSync(dstDir, { recursive: true });
  for (const name of ['ic_launcher.png', 'ic_launcher_round.png']) {
    const src = `${srcDir}/${name}`;
    if (!existsSync(src)) throw new Error(`Icon asset missing: ${src}`);
    copyFileSync(src, `${dstDir}/${name}`);
  }
}
