<script id="aw-trq-dhikr-persist">
/* إضافة ذكر داخل صفحة كل فائدة + حفظ تعديل المربعات بشكل ثابت */
(function(){
  'use strict';
  var css = document.createElement('style');
  css.textContent =
    '#awExtraDhikrModal{z-index:100010!important}'+
    '#awxReadingOverlay,.awx-fullscreen{z-index:100020!important}'+
    '.aw-lightbox{z-index:100030!important}'+
    '#trqReaderModal .trq-dhikr-bar{position:sticky;top:0;z-index:6;background:rgba(15,23,42,.96);backdrop-filter:blur(8px);border:1px solid rgba(217,119,6,.45);border-radius:14px;padding:8px 10px;margin-bottom:10px}'+
    '#trqReaderModal .trq-reader-add-dhikr{background:#b45309;border:1px solid #fbbf24;color:#fff;border-radius:12px;padding:10px 12px;font-weight:800;flex-shrink:0}'+
    '.trq-inline-dhikr{margin-bottom:12px}';
  document.head.appendChild(css);

  function cleanCloneHtml(el){
    var clone = el.cloneNode(true);
    clone.querySelectorAll('[contenteditable]').forEach(function(n){
      n.removeAttribute('contenteditable');
      n.classList.remove('aw-editing','aw-edit-on');
    });
    clone.removeAttribute('contenteditable');
    clone.classList.remove('aw-editing');
    return clone.innerHTML;
  }
  window.awCleanEditHtml = cleanCloneHtml;

  function saveTrqEl(el){
    if(!el || !el.getAttribute) return;
    var role = el.getAttribute('data-trq-edit');
    var step = el.closest ? el.closest('[data-trq-step]') : null;
    if(!role || !step) return;
    var sid = step.getAttribute('data-trq-step');
    if(!sid) return;
    try{
      var html = JSON.parse(localStorage.getItem('aw_trq_edits_html')||'{}');
      html[sid+'|'+role] = el.innerHTML;
      localStorage.setItem('aw_trq_edits_html', JSON.stringify(html));
      if(role==='body'){
        var plain = JSON.parse(localStorage.getItem('aw_trq_edits')||'{}');
        plain[sid] = el.innerText || '';
        localStorage.setItem('aw_trq_edits', JSON.stringify(plain));
      }
      if(role==='title'){
        var plainT = JSON.parse(localStorage.getItem('aw_trq_edits')||'{}');
        plainT['title_'+sid] = el.innerText || '';
        localStorage.setItem('aw_trq_edits', JSON.stringify(plainT));
      }
    }catch(e){}
  }
  window.awSyncTrqFields = function(root){
    if(!root || !root.querySelectorAll) return;
    root.querySelectorAll('[data-trq-edit]').forEach(saveTrqEl);
  };
  function saveCardBody(body){
    if(!body) return;
    var card = body.parentElement;
    var key = card && card.getAttribute('data-ekey');
    if(!key) return;
    try{
      var st = JSON.parse(localStorage.getItem('aw_card_edits_v2')||'{}');
      st[key] = cleanCloneHtml(body);
      localStorage.setItem('aw_card_edits_v2', JSON.stringify(st));
      body.setAttribute('data-applied','1');
    }catch(e){}
    window.awSyncTrqFields(body);
  }
  window.awSaveCardBody = saveCardBody;

  function slotHtml(id){
    return '<div class="trq-inline-dhikr aw-no-edit" data-trq-dhikr-slot="'+id+'">'+
      '<div class="trq-dhikr-bar flex items-center justify-between gap-2">'+
        '<span class="text-xs text-amber-200 font-bold">أذكار هذه الفائدة</span>'+
        '<button type="button" class="px-3 py-2 rounded-xl text-xs bg-amber-700 border border-amber-400 text-white font-bold shrink-0" onclick="event.preventDefault();event.stopPropagation();awExtraAdd(\'trqpage_'+id+'\')">＋ إضافة ذكر</button>'+
      '</div>'+
      '<div id="awExtra_trqpage_'+id+'" class="space-y-2"></div>'+
    '</div>';
  }

  window.awInjectTrqDhikr = function(onlyId){
    var nodes = [];
    if(onlyId){
      var one = document.getElementById('trq_body_'+onlyId);
      if(one) nodes = [one];
    } else {
      nodes = Array.prototype.slice.call(document.querySelectorAll('[id^="trq_body_"]'));
    }
    nodes.forEach(function(body){
      if(!body || !body.id) return;
      var id = body.id.slice(9);
      if(!id) return;
      if(!body.querySelector('[data-trq-dhikr-slot="'+id+'"]')){
        body.insertAdjacentHTML('afterbegin', slotHtml(id));
      }
      if(typeof window.awExtraRender==='function'){
        try{ window.awExtraRender('trqpage_'+id); }catch(e){}
      }
    });
    var modal = document.getElementById('trqReaderModal');
    if(!modal) return;
    var b = modal.querySelector('[id^="trq_body_"]');
    var rid = b ? b.id.slice(9) : (onlyId||'');
    if(!rid) return;
    var bar = modal.querySelector('.trq-reader-bar');
    if(bar && !bar.querySelector('.trq-reader-add-dhikr')){
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'trq-reader-add-dhikr';
      btn.textContent = '＋ إضافة ذكر';
      btn.onclick = function(ev){
        ev.preventDefault(); ev.stopPropagation();
        if(typeof window.awExtraAdd==='function') window.awExtraAdd('trqpage_'+rid);
      };
      var close = bar.querySelector('.trq-reader-close');
      if(close) bar.insertBefore(btn, close);
      else bar.appendChild(btn);
    }
  };

  function flushEdits(){
    document.querySelectorAll('[data-trq-edit]').forEach(function(el){
      if(el.getAttribute('contenteditable')==='true' || el.classList.contains('aw-editing')) saveTrqEl(el);
    });
    document.querySelectorAll('.aw-edit-body').forEach(function(body){
      if(body.getAttribute('contenteditable')==='true') saveCardBody(body);
    });
    document.querySelectorAll('[data-trq-edit][contenteditable="true"]').forEach(function(el){
      var body = el.closest('.aw-edit-body');
      if(body) saveCardBody(body);
      saveTrqEl(el);
    });
  }
  window.awFlushBoxEdits = flushEdits;

  document.addEventListener('input', function(ev){
    var t = ev.target;
    if(!t || !t.closest) return;
    var edit = t.getAttribute && t.getAttribute('data-trq-edit') ? t : (t.closest('[data-trq-edit]'));
    if(edit && (edit.getAttribute('contenteditable')==='true' || edit.classList.contains('aw-editing'))){
      clearTimeout(edit._awTrqSave);
      edit._awTrqSave = setTimeout(function(){
        saveTrqEl(edit);
        var body = edit.closest('.aw-edit-body');
        if(body) saveCardBody(body);
      }, 120);
    }
    var body2 = t.classList && t.classList.contains('aw-edit-body') ? t : t.closest('.aw-edit-body');
    if(body2 && body2.getAttribute('contenteditable')==='true'){
      clearTimeout(body2._awCardSave);
      body2._awCardSave = setTimeout(function(){ saveCardBody(body2); }, 120);
    }
  }, true);

  document.addEventListener('focusout', function(ev){
    var t = ev.target;
    if(!t || !t.getAttribute) return;
    if(t.getAttribute('data-trq-edit')){
      saveTrqEl(t);
      var body = t.closest && t.closest('.aw-edit-body');
      if(body) saveCardBody(body);
    } else if(t.classList && t.classList.contains('aw-edit-body')){
      saveCardBody(t);
    }
  }, true);

  window.addEventListener('pagehide', flushEdits);
  document.addEventListener('visibilitychange', function(){ if(document.hidden) flushEdits(); });

  function afterOpen(id){
    setTimeout(function(){
      try{ if(window.awRefreshEditButtons) window.awRefreshEditButtons(); }catch(e){}
      try{ if(window.awTrqRestore) window.awTrqRestore(); }catch(e){}
      try{ window.awInjectTrqDhikr(id); }catch(e){}
    }, 60);
  }

  function hookToggle(){
    var t = window.trqToggle;
    if(typeof t!=='function' || t._dhikrSlot) return;
    var w = function(id){
      var r = t.apply(this, arguments);
      afterOpen(id);
      return r;
    };
    w._dhikrSlot = true;
    window.trqToggle = w;
  }
  function hookClose(){
    var c = window.trqCloseReader;
    if(typeof c!=='function' || c._dhikrSlot) return;
    var w = function(){
      try{ flushEdits(); }catch(e){}
      return c.apply(this, arguments);
    };
    w._dhikrSlot = true;
    window.trqCloseReader = w;
  }
  function hookTab(){
    var s = window.switchTab;
    if(typeof s!=='function' || s._dhikrSlot) return;
    var w = function(tab){
      try{ flushEdits(); }catch(e){}
      var r = s.apply(this, arguments);
      if(tab==='turuq') afterOpen();
      return r;
    };
    w._dhikrSlot = true;
    window.switchTab = w;
  }
  hookToggle(); hookClose(); hookTab();
  setTimeout(function(){ hookToggle(); hookClose(); hookTab(); try{ awInjectTrqDhikr(); }catch(e){} }, 400);
  setTimeout(function(){ hookToggle(); try{ awInjectTrqDhikr(); if(window.awTrqRestore) awTrqRestore(); }catch(e){} }, 1400);
})();
</script>
