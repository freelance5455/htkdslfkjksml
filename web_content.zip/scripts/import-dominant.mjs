#!/usr/bin/env node
/**
 * Upload a local Dominant tree (lua only) into Cloudflare D1 via the Worker API.
 *
 * Usage:
 *   node scripts/import-dominant.mjs \
 *     --dir ../DOMINANT \
 *     --base https://YOUR_WORKER/ACCESS_CODE \
 *     --password YOUR_ADMIN_PASSWORD
 *
 * Only .lua / .luau / .md are uploaded. Skip assets — those stay on GitHub.
 */

import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';

function arg(name, fallback) {
  const i = process.argv.indexOf(`--${name}`);
  if (i === -1) return fallback;
  return process.argv[i + 1] || fallback;
}

const dir = path.resolve(arg('dir', '.'));
const base = (arg('base', '') || '').replace(/\/$/, '');
const password = arg('password', '');

if (!base || !password) {
  console.error('Need --base and --password');
  process.exit(1);
}

const SKIP = new Set(['.git', 'node_modules', 'assets', 'vendor/.gitkeep']);
const OK_EXT = new Set(['.lua', '.luau', '.md', '.json']);

function walk(root, prefix = '') {
  const out = [];
  for (const name of fs.readdirSync(root)) {
    if (name.startsWith('.')) continue;
    const full = path.join(root, name);
    const rel = prefix ? `${prefix}/${name}` : name;
    const st = fs.statSync(full);
    if (st.isDirectory()) {
      if (SKIP.has(name) || SKIP.has(rel)) continue;
      // skip assets folder entirely
      if (name === 'assets') continue;
      out.push(...walk(full, rel));
    } else if (OK_EXT.has(path.extname(name).toLowerCase())) {
      out.push({ path: rel.replace(/\\/g, '/'), full });
    }
  }
  return out;
}

const files = walk(dir);
console.log(`Found ${files.length} source files under ${dir}`);

// login
const loginRes = await fetch(`${base}/api/login`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ password }),
});
if (!loginRes.ok) {
  console.error('Login failed', await loginRes.text());
  process.exit(1);
}
const cookie = loginRes.headers.getSetCookie?.()?.join('; ') || loginRes.headers.get('set-cookie') || '';
console.log('Logged in');

const BATCH = 20;
let uploaded = 0;
for (let i = 0; i < files.length; i += BATCH) {
  const slice = files.slice(i, i + BATCH);
  const payload = {
    files: slice.map((f) => ({
      path: f.path,
      content: fs.readFileSync(f.full, 'utf8'),
    })),
  };
  const res = await fetch(`${base}/api/dominant/import`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Cookie: cookie,
    },
    body: JSON.stringify(payload),
  });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) {
    console.error('Import batch failed', res.status, body);
    process.exit(1);
  }
  uploaded += body.count || 0;
  console.log(`Uploaded ${uploaded}/${files.length}`);
}

console.log('Done. Meta:');
const meta = await fetch(`${base}/api/dominant/meta`, { headers: { Cookie: cookie } });
console.log(await meta.json());
