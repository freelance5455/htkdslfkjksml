import { chromium } from '@playwright/test';
import assert from 'node:assert/strict';

const browser = await chromium.launch({
  headless: true,
  args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
});
const context = await browser.newContext({ viewport: { width: 1280, height: 720 } });
const page = await context.newPage();

await page.goto('http://localhost:5173', { waitUntil: 'networkidle' });
await page.waitForTimeout(1000);

// Select Mountain Summit 🗻
await page.getByRole('button', { name: 'Select Mountain Summit 🗻' }).click();
await page.getByRole('button', { name: 'Explore in VR' }).click();

await page.locator('canvas').waitFor({ timeout: 20000 });
await page.locator('.scene-loading').waitFor({ state: 'detached', timeout: 20000 });
await page.waitForTimeout(2000);

// Capture VR screen looking down at the river, forest, and valley from the summit
await page.screenshot({ path: 'artifacts/summit-valley-view.png' });
console.log('Saved artifacts/summit-valley-view.png');

// Walk forward on summit lookout
await page.keyboard.down('w');
await page.waitForTimeout(1500);
await page.keyboard.up('w');
await page.waitForTimeout(500);
const walked = parseFloat(await page.getByTestId('distance').textContent());
assert.ok(walked > 0.05);

await browser.close();
console.log('Test completed successfully!');
