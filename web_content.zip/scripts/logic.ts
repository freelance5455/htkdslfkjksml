import './stub';

const results: string[] = [];
const t = async (name: string, fn: () => void | Promise<void>) => {
  try {
    await fn();
    results.push(`  ✅ ${name}`);
  } catch (e: any) {
    results.push(`  ❌ ${name}: ${e?.message ?? e}`);
    console.error(name, e);
  }
};

const { engine } = await import('../src/game/engine');
const { MISSIONS, WEAPONS } = await import('../src/game/items');

// The engine normally owns a WebGL renderer; stub the pieces the logic touches.
(engine as any).world = { district: () => 'Test District' };

await t('engine constructs + hud snapshot', () => {
  const hud = engine.getHud();
  if (!hud) throw new Error('no hud');
  if (engine.hud.weapon !== 'fists') throw new Error('default weapon wrong');
});

await t('weapon ownership rules', () => {
  engine.selectWeapon('rpg');
  if (engine.weapon === 'rpg') throw new Error('unowned weapon should not equip');
  engine.giveWeapon('rpg');
  engine.selectWeapon('rpg');
  if (engine.weapon !== 'rpg') throw new Error('owned weapon should equip');
  if (!engine.ownsWeapon('rpg')) throw new Error('ownsWeapon broken');
  engine.selectWeapon('fists');
});

await t('inventory: give / use / heal', () => {
  engine.health = 40;
  engine.giveItem('medkit', 2, true);
  const entry = engine.inventory.find((i) => i.id === 'medkit');
  if (!entry || entry.qty !== 2) throw new Error('item not added');
  engine.useItem('medkit');
  if (engine.health !== 90) throw new Error('medkit did not heal: ' + engine.health);
  const left = engine.inventory.find((i) => i.id === 'medkit');
  if (!left || left.qty !== 1) throw new Error('qty not decremented');
});

await t('inventory: ammo pickups', () => {
  engine.giveItem('pistolammo', 1, true);
  const before = engine.reserve.eagle || 0;
  engine.useItem('pistolammo');
  if ((engine.reserve.eagle || 0) !== before + 40) throw new Error('ammo not added');
});

await t('shop purchase deducts money', () => {
  engine.money = 1000;
  const ok = engine.buyItem('grenade', 450);
  if (!ok) throw new Error('purchase rejected');
  if (engine.money !== 550) throw new Error('money not deducted: ' + engine.money);
  if (!engine.ownsWeapon('grenade')) throw new Error('weapon not granted');
  engine.money = 10;
  if (engine.buyItem('sniper', 4800)) throw new Error('purchase should fail without funds');
  engine.money = 5000;
});

await t('missions: start + complete', () => {
  const m = MISSIONS[0];
  engine.startMission(m.id);
  if (engine.missionIndex !== 0) throw new Error('mission not started');
  engine.playerPos.set(m.target[0], 0, m.target[1]);
  // simulate the completion check
  if (engine.missions[0].state !== 'done') {
    // drive it directly through the same code path used by the update loop
    engine.playerPos.set(m.target[0], 0, m.target[1]);
    (engine as any).updateMissions(0.016);
  }
  if (engine.missions[0].state !== 'done') throw new Error('mission not completed');
  if (engine.money < 5000) throw new Error('reward not paid');
});

await t('save / load round trip', () => {
  engine.money = 7777;
  engine.health = 55;
  engine.playerPos.set(120, 0, -330);
  engine.save(true);
  engine.money = 0;
  engine.health = 1;
  const ok = engine.load();
  if (!ok) throw new Error('load failed');
  if (engine.money !== 7777) throw new Error('money not restored');
  if (engine.health !== 55) throw new Error('hp not restored');
  if (Math.abs(engine.playerPos.x - 120) > 0.01) throw new Error('position not restored');
});

await t('jail: sentence + early release', () => {
  engine.money = 100000;
  engine.jailed = true;
  engine.jailEnd = Date.now() + 3 * 60 * 60 * 1000;
  engine.buyEarlyRelease();
  if (engine.jailed) throw new Error('still jailed');
  if (engine.money !== 75000) throw new Error('bail not charged: ' + engine.money);
});

await t('jail length is exactly 3 hours', () => {
  const hud = engine.getHud();
  if (hud.jailTotal !== 3 * 60 * 60 * 1000) throw new Error('wrong sentence length');
});

await t('quality + volume setters', () => {
  engine.setQuality('low');
  engine.setQuality('high');
  engine.setVolume(0.5);
  engine.setVolume(0.9);
});

await t('weapon definitions are complete', () => {
  for (const id of ['fists', 'eagle', 'sniper', 'rpg', 'grenade', 'smoke']) {
    const w = WEAPONS[id as keyof typeof WEAPONS];
    if (!w) throw new Error('missing weapon ' + id);
    if (!w.name || !w.icon || typeof w.damage !== 'number') throw new Error('bad weapon ' + id);
  }
});

console.log('\nLOGIC TEST RESULTS');
console.log(results.join('\n'));
const failed = results.filter((r) => r.includes('❌')).length;
console.log(failed ? `\n${failed} FAILURES` : '\nALL PASSED');
process.exit(failed ? 1 : 0);
