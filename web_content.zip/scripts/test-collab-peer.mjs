import WebSocket from 'ws';

const ws = new WebSocket('ws://localhost:3000/ws');

ws.on('open', () => {
  console.log('Peer connected to WebSocket server');

  // Join room
  ws.send(
    JSON.stringify({
      type: 'join',
      roomId: 'board-room-seedboardarchitecture',
      peer: {
        id: 'peer-remote-bot',
        name: 'Cosmic Falcon',
        color: '#e11d48',
      },
    })
  );

  setTimeout(() => {
    // Send live cursor
    console.log('Sending live cursor...');
    ws.send(
      JSON.stringify({
        type: 'cursor',
        x: 650,
        y: 220,
      })
    );

    // Send a new collaborative sticky note
    console.log('Sending collaborative sticky note...');
    ws.send(
      JSON.stringify({
        type: 'element-upsert',
        timestamp: Date.now(),
        element: {
          id: 'sticky-remote-collab',
          type: 'sticky',
          x: 480,
          y: 380,
          width: 210,
          height: 150,
          zIndex: 20,
          stickyColor: '#bae6fd',
          strokeColor: '#0284c7',
          text: '🚀 Real-time sync works!\n\nFrom: Cosmic Falcon',
          fontSize: 16,
          fontFamily: 'handwritten',
        },
      })
    );
  }, 1000);

  setTimeout(() => {
    console.log('Simulated peer work complete.');
    ws.close();
    process.exit(0);
  }, 3000);
});

ws.on('message', (msg) => {
  const data = JSON.parse(msg.toString());
  console.log('Peer received message type:', data.type);
});
