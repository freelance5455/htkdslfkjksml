#!/usr/bin/env python3
import os
import zipfile
import shutil

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUTPUT_DIR = os.path.join(ROOT_DIR, 'public', 'downloads')
os.makedirs(OUTPUT_DIR, exist_ok=True)

TARGET_ZIP = os.path.join(OUTPUT_DIR, 'TaskEarnPro.zip')

EXCLUDE_DIRS = {
    'node_modules',
    'dist',
    '.git',
    '.cache',
    'build',
    '.gradle',
    '__pycache__'
}

EXCLUDE_EXTS = {
    '.pyc',
    '.log',
    '.idsig',
    '.zip',
    '.apk'
}

print(f"Creating clean, lightweight ZIP archive from {ROOT_DIR} ...")

with zipfile.ZipFile(TARGET_ZIP, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as zipf:
    for root, dirs, files in os.walk(ROOT_DIR):
        # Prune excluded directories
        dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS and not d.startswith('.')]
        
        rel_root = os.path.relpath(root, ROOT_DIR)
        
        # Avoid including build artifacts inside android assets
        if 'android/app/src/main/assets/public/assets' in rel_root:
            continue
            
        for file in files:
            file_path = os.path.join(root, file)
            
            # Skip any zip or apk or heavy binaries
            if any(file.endswith(ext) for ext in EXCLUDE_EXTS):
                continue
                
            rel_path = os.path.relpath(file_path, ROOT_DIR)
            zipf.write(file_path, rel_path)

file_size_kb = os.path.getsize(TARGET_ZIP) / 1024
file_size_mb = file_size_kb / 1024
print(f"Created {TARGET_ZIP} ({file_size_mb:.2f} MB / {file_size_kb:.0f} KB)")

# Copy to alternate names for convenience
for alt_name in ['task-pro-app.zip', 'TaskEarnPro-source.zip']:
    alt_path = os.path.join(OUTPUT_DIR, alt_name)
    shutil.copy2(TARGET_ZIP, alt_path)

# Also copy to root of public/ for alternate access
for root_public_name in ['TaskEarnPro.zip', 'task-pro-app.zip']:
    root_public_path = os.path.join(ROOT_DIR, 'public', root_public_name)
    shutil.copy2(TARGET_ZIP, root_public_path)
    print(f"Copied to {root_public_path}")
