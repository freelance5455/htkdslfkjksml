import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';

const distDir = path.resolve(process.cwd(), 'dist');
const htmlPath = path.join(distDir, 'index.html');

console.log('[002 APK Prep] Inspecting production build in dist/...');

if (!fs.existsSync(htmlPath)) {
  console.error('[002 APK Prep] Error: dist/index.html not found! Run vite build first.');
  process.exit(1);
}

let html = fs.readFileSync(htmlPath, 'utf8');

// 1. Remove "crossorigin" attributes which cause file:// protocol CORS errors in Android WebView
html = html.replace(/\s+crossorigin(="[^"]*")?/gi, '');

// 2. Remove "nomodule" from polyfills-legacy script so Android WebView can load SystemJS
// if modern ES modules are blocked by file:// CORS
html = html.replace(/<script\s+nomodule\s+id="vite-legacy-polyfill"/i, '<script id="vite-legacy-polyfill"');

// 3. Inject Universal WebView Hybrid Bootloader right after vite-legacy-entry
const universalBootloader = `
    <!-- 002 Universal WebView Bootloader for Android APK (file:// & WebViewAssetLoader support) -->
    <script id="002-webview-universal-bootloader">
      (function() {
        var legacyAttempted = false;
        function checkAndBootLegacy() {
          if (legacyAttempted) return;
          if (window.__002_APP_LOADED__) {
            console.log('[002 AI] Modern ES module bundle loaded successfully.');
            return;
          }
          legacyAttempted = true;
          console.warn('[002 AI] Modern ES module blocked by file:// origin policy. Booting legacy SystemJS bundle...');
          var entry = document.getElementById('vite-legacy-entry');
          if (entry && window.System && typeof window.System.import === 'function') {
            var dataSrc = entry.getAttribute('data-src');
            if (dataSrc) {
              window.System.import(dataSrc).catch(function(err) {
                console.error('[002 AI] Failed to load legacy bundle:', err);
              });
            }
          }
        }

        // Check if modern script executed; if not after DOM load, trigger legacy loader
        if (document.readyState === 'loading') {
          document.addEventListener('DOMContentLoaded', function() {
            setTimeout(checkAndBootLegacy, 60);
          });
        } else {
          setTimeout(checkAndBootLegacy, 60);
        }
        window.addEventListener('load', function() {
          setTimeout(checkAndBootLegacy, 120);
        });
      })();
    </script>
`;

if (html.includes('id="vite-legacy-entry"')) {
  html = html.replace(/(<script[^>]*id="vite-legacy-entry"[^>]*>.*?<\/script>)/is, `$1${universalBootloader}`);
}

fs.writeFileSync(htmlPath, html, 'utf8');
console.log('[002 APK Prep] Successfully patched dist/index.html with relative paths and universal WebView bootloader!');

// Create android/ reference folder
const androidDir = path.resolve(process.cwd(), 'android');
if (!fs.existsSync(androidDir)) {
  fs.mkdirSync(androidDir, { recursive: true });
}

// Write reference MainActivity.kt
const mainActivityContent = `package com.zero_two.ai

import android.annotation.SuppressLint
import android.os.Build
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.PermissionRequest
import androidx.appcompat.app.AppCompatActivity

/**
 * 002 AI Companion - Production Android WebView Activity
 *
 * Configured specifically to prevent blank white screens:
 * 1. Enables JavaScript and DOM Storage (prevents localStorage crashes).
 * 2. Allows file access from file URLs.
 * 3. Handles audio recording / microphone permission requests.
 * 4. Enables WebContentsDebugging in debug builds for chrome://inspect.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        setContentView(webView)

        // Enable Chrome DevTools inspection on your PC via chrome://inspect/#devices
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            WebView.setWebContentsDebuggingEnabled(true)
        }

        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true // CRITICAL: Required for chat history & preferences
        settings.databaseEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true

        // Allow local file access for file:/// scheme loading
        settings.allowFileAccessFromFileURLs = true
        settings.allowUniversalAccessFromFileURLs = true

        settings.mediaPlaybackRequiresUserGesture = false
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true

        webView.webViewClient = object : WebViewClient() {}

        webView.webChromeClient = object : WebChromeClient() {
            // Automatically grant web microphone permissions if Android app has RECORD_AUDIO
            override fun onPermissionRequest(request: PermissionRequest?) {
                request?.let {
                    for (resource in it.resources) {
                        if (resource == PermissionRequest.RESOURCE_AUDIO_CAPTURE) {
                            it.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                            return
                        }
                    }
                    it.grant(it.resources)
                }
            }
        }

        // LOAD APP:
        // Place the contents of the 'dist' folder into: app/src/main/assets/
        // So that index.html is located at: app/src/main/assets/index.html
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
`;

fs.writeFileSync(path.join(androidDir, 'MainActivity.kt'), mainActivityContent, 'utf8');

// Write AndroidManifest.xml template
const manifestContent = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.zero_two.ai">

    <!-- Permissions required for Gemini AI communication and voice recognition -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="002 AI"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.AppCompat.NoActionBar"
        android:usesCleartextTraffic="true">
        <activity
            android:name=".MainActivity"
            android:configChanges="orientation|screenSize|keyboardHidden"
            android:exported="true"
            android:screenOrientation="portrait">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
`;

fs.writeFileSync(path.join(androidDir, 'AndroidManifest.xml'), manifestContent, 'utf8');

// Write README.md for packaging instructions
const readmeContent = `# 002 AI - Android APK Packaging Guide

## Why the original APK showed a blank white screen
1. **ES Module CORS Restriction on \`file://\`**: Chromium WebViews block \`<script type="module" crossorigin>\` when loaded from local \`file://\` paths.
2. **Missing DOM Storage in WebSettings**: Android's default \`WebView\` disables \`domStorageEnabled\`, which crashes \`localStorage\` calls synchronously.
3. **\`nomodule\` suppression**: Chromium suppresses \`<script nomodule>\` because it supports modern JS, so neither module nor nomodule ran.

## What is fixed in this build
- **Universal Hybrid Bootloader**: \`dist/index.html\` boots directly via SystemJS if modern ES modules are blocked by \`file://\` CORS.
- **Safe Storage Fallback**: \`safeStorage.ts\` provides in-memory fallback if \`domStorageEnabled\` is off.
- **Removed \`crossorigin\`**: Prevents CORS null-origin blocks on styles and scripts.
- **Visual Pre-mount Indicator**: Shows 002 branded splash while WebGL and React initialize.
- **React ErrorBoundary**: Catches any rendering failure and displays a diagnostic recovery screen instead of a white page.

## How to assemble the APK in Android Studio
1. In your Android Studio project, copy the **contents of the \`dist\` folder** directly into:
   \`app/src/main/assets/\`
   (You should have \`app/src/main/assets/index.html\` and \`app/src/main/assets/assets/...\`).
2. Replace \`MainActivity.kt\` with the included \`android/MainActivity.kt\`.
3. Ensure \`AndroidManifest.xml\` has \`INTERNET\` and \`RECORD_AUDIO\` permissions.
4. Build APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Gemini Backend Note
The Gemini API key must NEVER be stored in the APK.
Your APK will connect to the backend server via HTTPS (configured in **Settings > Android APK Packaging** or default cloud URL).
`;

fs.writeFileSync(path.join(androidDir, 'README.md'), readmeContent, 'utf8');

console.log('[002 APK Prep] Android Studio templates generated in android/');

// Create the downloadable ZIP archive using Python script
try {
  execSync('python3 scripts/make_apk_zip.py', { stdio: 'inherit' });
} catch (e) {
  console.error('[002 APK Prep] Warning creating zip:', e.message);
}
