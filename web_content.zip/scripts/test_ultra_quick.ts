import { STAGE_02_QUESTIONS } from '../src/data/stage02Questions';
import { normalizeArabicString } from '../src/engine/normalization';

function cleanWord(str: string): string {
  return normalizeArabicString(str.replace(/\s+/g, ''));
}

const words = STAGE_02_QUESTIONS.map((q) => ({
  id: q.id,
  clue: q.clue,
  answer: q.answer,
  norm: cleanWord(q.answer),
  len: cleanWord(q.answer).length
}));

console.log('Words ready:', words.length);

const GRID_SIZE = 19;
const grid: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
const cellAcross: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
const cellDown: (string | null)[][] = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));

const root = words.find((w) => w.len === 15)!;
const rootR = 9;
const rootC = 2;

for (let k = 0; k < root.len; k++) {
  grid[rootR][rootC + k] = root.norm[k];
  cellAcross[rootR][rootC + k] = root.id;
}

console.log('Root placed:', root.norm);

function canFit(wStr: string, dir: 'across' | 'down', r: number, c: number) {
  const len = wStr.length;
  if (dir === 'across') {
    if (c < 0 || c + len > GRID_SIZE || r < 0 || r >= GRID_SIZE) return { valid: false, inters: 0 };
    if (c > 0 && grid[r][c - 1] !== null) return { valid: false, inters: 0 };
    if (c + len < GRID_SIZE && grid[r][c + len] !== null) return { valid: false, inters: 0 };

    let inters = 0;
    for (let k = 0; k < len; k++) {
      const cur = grid[r][c + k];
      if (cur !== null) {
        if (cur !== wStr[k]) return { valid: false, inters: 0 };
        if (cellAcross[r][c + k] !== null) return { valid: false, inters: 0 };
        inters++;
      } else {
        if (r > 0 && grid[r - 1][c + k] !== null) return { valid: false, inters: 0 };
        if (r < GRID_SIZE - 1 && grid[r + 1][c + k] !== null) return { valid: false, inters: 0 };
      }
    }
    return { valid: inters > 0, inters };
  } else {
    if (r < 0 || r + len > GRID_SIZE || c < 0 || c >= GRID_SIZE) return { valid: false, inters: 0 };
    if (r > 0 && grid[r - 1][c] !== null) return { valid: false, inters: 0 };
    if (r + len < GRID_SIZE && grid[r + len][c] !== null) return { valid: false, inters: 0 };

    let inters = 0;
    for (let k = 0; k < len; k++) {
      const cur = grid[r + k][c];
      if (cur !== null) {
        if (cur !== wStr[k]) return { valid: false, inters: 0 };
        if (cellDown[r + k][c] !== null) return { valid: false, inters: 0 };
        inters++;
      } else {
        if (c > 0 && grid[r + k][c - 1] !== null) return { valid: false, inters: 0 };
        if (c < GRID_SIZE - 1 && grid[r + k][c + 1] !== null) return { valid: false, inters: 0 };
      }
    }
    return { valid: inters > 0, inters };
  }
}

// Test second word
const w2 = words.find((w) => w.len === 14)!;
let found = 0;
for (let k = 0; k < w2.norm.length; k++) {
  for (let c = 0; c < GRID_SIZE; c++) {
    if (grid[rootR][c] === w2.norm[k]) {
      const startR = rootR - k;
      const res = canFit(w2.norm, 'down', startR, c);
      if (res.valid) {
        found++;
        console.log(`w2 fit at down (${startR}, ${c}), k=${k}`);
      }
    }
  }
}
console.log('Total valid placements for w2:', found);
