package com.suhbatai.translator

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognizerIntent
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val REQ_MIC = 44
    private val REQ_SPEECH = 45
    private val REQ_CAMERA = 46
    private var pendingSpeechSource = "fa"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.allowFileAccess = true
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(AppBridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
    }

    inner class AppBridge {
        @JavascriptInterface fun startMic(source: String) = runOnUiThread { requestMicAndListen(source) }
        @JavascriptInterface fun startCamera() = runOnUiThread { requestCamera() }
        @JavascriptInterface fun openAccessibility() = runOnUiThread {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        @JavascriptInterface fun openOverlay() = runOnUiThread {
            if (!Settings.canDrawOverlays(this@MainActivity)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
    }

    private fun requestMicAndListen(source: String) {
        pendingSpeechSource = source
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            web.evaluateJavascript("window.nativeMicError && window.nativeMicError('برای استفاده از میکروفون، اجازه دسترسی لازم است.');", null)
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
            return
        }
        launchSpeech(source)
    }

    private fun launchSpeech(source: String) {
        try {
            val language = if (source == "fa") "fa-IR" else "uz-UZ"
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, language)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, language)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PROMPT, if (source == "fa") "به فارسی صحبت کن..." else "O'zbekcha gapiring...")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            startActivityForResult(i, REQ_SPEECH)
        } catch (e: Exception) {
            web.evaluateJavascript("window.nativeMicError && window.nativeMicError('سرویس تشخیص صدا روی این دستگاه در دسترس نیست.');", null)
        }
    }

    private fun requestCamera() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), REQ_CAMERA)
            return
        }
        val i = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (i.resolveActivity(packageManager) != null) startActivityForResult(i, REQ_CAMERA)
        else web.evaluateJavascript("window.nativeCameraError && window.nativeCameraError('دوربین روی این دستگاه در دسترس نیست.');", null)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isEmpty() || grantResults[0] != PackageManager.PERMISSION_GRANTED) {
            web.evaluateJavascript("window.nativeMicError && window.nativeMicError('دسترسی لازم داده نشد.');", null)
            return
        }
        if (requestCode == REQ_MIC) launchSpeech(pendingSpeechSource)
        if (requestCode == REQ_CAMERA) launchCameraAfterPermission()
    }

    private fun launchCameraAfterPermission() {
        val i = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (i.resolveActivity(packageManager) != null) startActivityForResult(i, REQ_CAMERA)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_SPEECH && resultCode == RESULT_OK) {
            val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!text.isNullOrBlank()) web.evaluateJavascript("window.nativeSpeechResult && window.nativeSpeechResult(${JSONObject.quote(text)});", null)
        }
        if (requestCode == REQ_CAMERA && resultCode == RESULT_OK) {
            web.evaluateJavascript("window.nativeCameraResult && window.nativeCameraResult();", null)
        }
    }

    override fun onDestroy() { web.destroy(); super.onDestroy() }
}
