package com.example.farsiuzbekai

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

class MessageAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // فقط متن قابل‌دسترسیِ پنجرهٔ فعال را می‌خواند و هیچ پیامی را خودکار ارسال نمی‌کند.
        // برای نسخهٔ بعدی می‌توان یک دکمهٔ «ترجمه» اضافه کرد که کاربر خودش آن را اجرا کند.
        if (event?.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) return
        val root = rootInActiveWindow ?: return
        val text = collectText(root).trim()
        if (text.isNotEmpty() && text.length < 3000) {
            // عمداً فقط در این مرحله جمع‌آوری محلی انجام می‌شود.
            // ارسال به AI/سرور بدون اقدام کاربر انجام نمی‌شود.
        }
    }

    private fun collectText(node: AccessibilityNodeInfo?): String {
        if (node == null) return ""
        val sb = StringBuilder()
        node.text?.let { if (it.isNotBlank()) sb.append(it).append('\n') }
        for (i in 0 until node.childCount) {
            sb.append(collectText(node.getChild(i)))
        }
        return sb.toString()
    }

    override fun onInterrupt() {}
}
