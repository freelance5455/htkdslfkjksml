import express from 'express';
import {GoogleAuth} from 'google-auth-library';

const app = express();
app.use(express.json({limit:'64kb'}));
app.use((req,res,next)=>{res.setHeader('Access-Control-Allow-Origin','*');res.setHeader('Access-Control-Allow-Headers','Content-Type');res.setHeader('Access-Control-Allow-Methods','POST,OPTIONS');if(req.method==='OPTIONS')return res.sendStatus(204);next();});

const PORT=process.env.PORT||8080;
const PROJECT_ID=process.env.GOOGLE_CLOUD_PROJECT;
const LOCATION=process.env.GOOGLE_CLOUD_LOCATION||'global';
const MODEL=process.env.GOOGLE_TRANSLATION_MODEL||'general/translation-llm';
const MAX_CHARS=Number(process.env.MAX_CHARS||12000);
const auth=new GoogleAuth({scopes:['https://www.googleapis.com/auth/cloud-platform']});

function protectTerms(text, glossaryText) {
  const tokens = [];
  let out = text;
  const entries = String(glossaryText || '').split('|').map(x => x.trim()).filter(Boolean);
  for (const entry of entries) {
    const parts = entry.split('=');
    if (parts.length < 2) continue;
    const source = parts.shift().trim();
    const target = parts.join('=').trim();
    if (!source || !target) continue;
    const token = `SUHBATTERM${tokens.length}X`;
    out = out.split(source).join(token);
    tokens.push([token, target]);
  }
  // Protect URLs, product codes and numeric expressions with stable ASCII tokens.
  out = out.replace(/https?:\/\/\S+|\b\d[\d,.]*%?\b|\b[A-Z]{2,}[A-Z0-9_-]*\b/g, m => {
    const token = `SUHBATPROT${tokens.length}X`;
    tokens.push([token, m]);
    return token;
  });
  return {protectedText: out, tokens};
}
function restore(text, tokens) {
  let out = text;
  for (const [token, value] of tokens) out = out.split(token).join(value);
  return out;
}

app.get('/health',(req,res)=>res.json({ok:true,service:'Suhbat AI',model:MODEL}));
app.post('/translate',async(req,res)=>{
  try{
    const {text,source,target,business=true,glossary=''}=req.body||{};
    if(typeof text!=='string'||!text.trim())return res.status(400).json({error:'متن خالی است.'});
    if(!['fa','uz'].includes(source)||!['fa','uz'].includes(target)||source===target)return res.status(400).json({error:'زبان نامعتبر است.'});
    if(text.length>MAX_CHARS)return res.status(413).json({error:`متن بیش از ${MAX_CHARS} کاراکتر است.`});
    if(!PROJECT_ID)return res.status(500).json({error:'GOOGLE_CLOUD_PROJECT تنظیم نشده است.'});
    const {protectedText,tokens}=protectTerms(text, glossary);
    const content=protectedText;
    const client=await auth.getClient();
    const token=(await client.getAccessToken()).token;
    const parent=`projects/${PROJECT_ID}/locations/${LOCATION}`;
    const url=`https://translation.googleapis.com/v3/${parent}:translateText`;
    const body={contents:[content],mimeType:'text/plain',sourceLanguageCode:source,targetLanguageCode:target,model:`${parent}/models/${MODEL}`};
    const r=await fetch(url,{method:'POST',headers:{Authorization:`Bearer ${token}`,'x-goog-user-project':PROJECT_ID,'Content-Type':'application/json'},body:JSON.stringify(body)});
    const data=await r.json();
    if(!r.ok) return res.status(r.status).json({error:data?.error?.message||'Google Cloud Translation error'});
    const raw=data?.translations?.[0]?.translatedText;
    if(!raw) return res.status(502).json({error:'پاسخ ترجمه نامعتبر است.'});
    res.json({translation:restore(raw,tokens),model:'Translation LLM',source,target,business});
  }catch(e){console.error(e);res.status(500).json({error:'خطای داخلی سرور ترجمه.'});}
});
app.listen(PORT,()=>console.log(`Suhbat AI backend listening on ${PORT}`));
