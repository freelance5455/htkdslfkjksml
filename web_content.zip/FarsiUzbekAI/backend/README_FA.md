# سرور امن Suhbat AI

این پوشه یک سرور واسط برای Suhbat AI است. برنامه اندروید نباید credential سرویس Google Cloud را داخل APK نگه دارد.

## کار سرور
- دریافت متن از برنامه
- حالت تجاری حرفه‌ای
- حفظ عدد، تاریخ، ارز، واحد، URL و کد محصول
- واژه‌نامه اختصاصی کاربر
- ارسال درخواست به Google Cloud Translation LLM
- بازگرداندن ترجمه به برنامه

## راه‌اندازی
1. در Google Cloud یک Project بساز و Cloud Translation API را فعال کن.
2. یک Service Account با دسترسی مناسب Cloud Translation بساز.
3. روی محیط سرور، Application Default Credentials را تنظیم کن.
4. متغیرهای `.env.example` را به متغیرهای محیطی واقعی تبدیل کن.
5. `npm install` و سپس `npm start` را اجرا کن.
6. آدرس `/health` را بررسی کن.
7. همان آدرس سرور را از داخل برنامه Suhbat AI در «تنظیمات اتصال» وارد کن.

Google Cloud Translation Advanced از IAM استفاده می‌کند و API key را برای v3 قبول نمی‌کند؛ بنابراین credential در سرور نگه داشته می‌شود، نه داخل APK.
