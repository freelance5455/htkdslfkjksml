@echo off
cd /d "%~dp0"
call gradlew.bat --no-daemon assembleDebug
if errorlevel 1 (
  echo.
  echo Build failed. Check Android SDK Platform 35 and JDK 17 in Android Studio.
  pause
  exit /b 1
)
echo.
echo APK created at:
echo app\build\outputs\apk\debug\app-debug.apk
pause
