Open this folder in Android Studio.
Requires Android SDK Platform 35 and JDK 17. Build with Build > Build Bundle(s) / APK(s) > Build APK(s).
The WebView loads the offline game bundled at app/src/main/assets/index.html.
