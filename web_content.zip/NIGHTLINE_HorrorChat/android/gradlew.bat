@echo off
setlocal
set "GRADLE_HOME=%USERPROFILE%\.gradle\nightline-gradle-8.9\gradle-8.9"
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  echo Downloading Gradle 8.9 for NIGHTLINE ...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $base=Join-Path $env:USERPROFILE '.gradle\nightline-gradle-8.9'; New-Item -ItemType Directory -Force -Path $base | Out-Null; $zip=Join-Path $env:TEMP 'nightline-gradle-8.9.zip'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-8.9-bin.zip' -OutFile $zip; Expand-Archive -Force $zip $base; Remove-Item $zip -Force"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_HOME%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
