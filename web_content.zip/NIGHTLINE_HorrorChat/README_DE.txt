NIGHTLINE – HORROR CHAT
======================

INHALT
------
index.html       Das vollständige, offline spielbare Horror-Chatspiel.
android/         Android-Studio-Projekt, das das Spiel in einer App-WebView startet.

SPIELEN OHNE APK
----------------
Öffne index.html auf deinem Android-Gerät mit Chrome oder einem anderen modernen
Browser. Das Spiel funktioniert offline; der Spielstand wird lokal gespeichert.

APK ERZEUGEN (ANDROID STUDIO)
-----------------------------
WICHTIG: In der Erstellungsumgebung war kein Android-SDK und kein APK-Compiler
installiert. Deshalb liegt hier ein vollständiges Android-Studio-Projekt, aber
keine bereits kompilierte APK-Datei.

1. Installiere Android Studio auf deinem PC.
2. Entpacke das ZIP und öffne den Ordner NIGHTLINE_HorrorChat/android in Android Studio.
3. Lass Android Studio Gradle synchronisieren. Falls gefragt, installiere Android
   SDK Platform 35 und verwende JDK 17. Gradle 8.9 ist als Startskript enthalten und
   wird beim ersten Build automatisch heruntergeladen.
4. Wähle Build > Build Bundle(s) / APK(s) > Build APK(s). Alternativ kannst du unter
   Windows BUILD_APK.bat im Ordner android doppelklicken.
5. Die APK findest du danach hier:
   android/app/build/outputs/apk/debug/app-debug.apk

Die Debug-APK wird von Android Studio automatisch mit dem Debug-Schlüssel signiert
und kann zum Testen auf deinem Android-Gerät installiert werden. Für eine eigene
Release-Version wähle Build > Generate Signed Bundle / APK und signiere mit deinem
Keystore.

STEUERUNG / FEATURES
--------------------
- Vier Modi: Leicht, Mittel, Schwer und NIGHTMARE
- Acht Chat-Entscheidungen; Ziel: 100 % Vertrauen
- Signal-Störungsleiste als zweite Gefahr
- Credits, Shop und permanente Upgrades innerhalb eines Runs
- Items: Rausch-Absorber, Vertrauenssplitter, Analyse-Chip und Chat-Backup
- Vierte Antwortoption als freischaltbares Upgrade
- Fake-Ad-Boost: rein fiktiv, ohne echte Werbung oder Internetverbindung
- Automatisches lokales Speichern und Fortsetzen

Hinweis: Das Spiel ist ein eigenständiges Horror-Fiktionsspiel. Die Fake-Ad-Funktion
zeigt keine externe Werbung und überträgt keine Daten.
