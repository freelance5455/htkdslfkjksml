@echo off
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
echo Gradle 8.7 is required. Please install/configure Gradle 8.7 in Android Studio/AndroidIDE.
exit /b 1
