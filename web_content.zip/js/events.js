/* events.js — Phase 10: random events (every nation) and dated historical headlines (Old World scenario).
   The player gets a popup with choices; AI nations resolve events silently with a default choice. State: st.ev (saved). */
(function (G) {
  'use strict';
  const nm = id => G.COUNTRIES[id].name;

  G.initEvents = function (st, fresh) {
    if (!st.ev || fresh) st.ev = { last: -999, cd: {}, pending: [], log: [], hist: {} };
    const e = st.ev; e.cd = e.cd || {}; e.pending = e.pending || []; e.log = e.log || []; e.hist = e.hist || {};
  };

  // Size factor so a tiny nation does not get the same flat amounts as a giant (0.5 .. 3).
  G.eventScale = function (id) { return Math.max(0.5, Math.min(3, 0.5 + 0.08 * G.totals(id).provs)); };

  /* ---------- effect engine ---------- */
  // fx keys: gold, manpower, food, steel, coal, oil, rubber (flat, scaled), morale (all armies), research (points),
  //          infamy, rel [target, delta] (target = ctx.t), popPct (all provinces), none
  function scaled(v, k) { return Math.round(v * k); }
  const gK = id => (400 + 190 * (G.COUNTRIES[id].pow || 2)) / 900;                 // gold effects follow the nation's economic weight
  const mP = id => 17000 + 12500 * (G.COUNTRIES[id].pow || 2);                    // manpower effects follow its manpower pool
  G.applyEventFx = function (id, fx, ctx) {
    const st = G.state, c = st.countries[id], k = G.eventScale(id), out = [];
    if (!fx) return out;
    if (fx.gold) { const v = scaled(fx.gold, gK(id)); c.treasury += v; out.push((v > 0 ? '+' : '') + v + ' gold'); }
    if (fx.manpower) { const v = Math.round(fx.manpower * mP(id) / 1000); c.manpower = Math.max(0, c.manpower + v); out.push((v > 0 ? '+' : '') + v + ' manpower'); }
    for (const r of ['food', 'steel', 'coal', 'oil', 'rubber']) if (fx[r]) { const v = scaled(fx[r], k); c.res[r] = Math.max(0, c.res[r] + v); out.push((v > 0 ? '+' : '') + v + ' ' + r); }
    if (fx.morale) { let n = 0; st.armies.forEach(a => { if (a.owner === id) a.units.forEach(u => { u.morale = Math.max(5, Math.min(100, u.morale + fx.morale)); n++; }); }); out.push((fx.morale > 0 ? '+' : '') + fx.morale + ' army morale'); }
    if (fx.research) {
      const t = st.tech[id]; let v = 0;
      if (t && t.active.length) { v = scaled(fx.research, Math.max(1, k)); t.prog[t.active[0]] = (t.prog[t.active[0]] || 0) + v; }
      out.push(v ? '+' + v + ' research' : 'research (no active project)');
    }
    if (fx.infamy) { st.infamy[id] = Math.max(0, (st.infamy[id] || 0) + fx.infamy); out.push((fx.infamy > 0 ? '+' : '') + fx.infamy + ' infamy'); }
    if (fx.rel && ctx && ctx.t && !st.countries[ctx.t].dead) { G.addRelation(id, ctx.t, fx.rel); out.push((fx.rel > 0 ? '+' : '') + fx.rel + ' relations with ' + nm(ctx.t)); }
    if (fx.popPct) {
      G.provinces.forEach(p => { if (!p.sea && st.owners[p.id] === id) p.pop = Math.max(8000, Math.round(p.pop * (1 + fx.popPct / 100))); });
      out.push((fx.popPct > 0 ? '+' : '') + fx.popPct + '% population');
    }
    if (fx.relAll) { Object.keys(st.countries).forEach(o => { if (o !== id && !st.countries[o].dead) G.addRelation(id, o, fx.relAll); }); out.push((fx.relAll > 0 ? '+' : '') + fx.relAll + ' relations with everyone'); }
    G.recompute && G.recompute();
    return out;
  };
  // Preview text for an option (flat numbers scaled for this nation).
  G.describeFx = function (id, fx, ctx) {
    const k = G.eventScale(id), out = [];
    if (!fx) return 'No effect';
    if (fx.gold) out.push((fx.gold > 0 ? '+' : '') + scaled(fx.gold, gK(id)) + ' gold');
    if (fx.manpower) out.push((fx.manpower > 0 ? '+' : '') + Math.round(fx.manpower * mP(id) / 1000) + ' manpower');
    for (const r of ['food', 'steel', 'coal', 'oil', 'rubber']) if (fx[r]) out.push((fx[r] > 0 ? '+' : '') + scaled(fx[r], k) + ' ' + r);
    if (fx.morale) out.push((fx.morale > 0 ? '+' : '') + fx.morale + ' morale');
    if (fx.research) out.push('+' + scaled(fx.research, Math.max(1, k)) + ' research');
    if (fx.infamy) out.push((fx.infamy > 0 ? '+' : '') + fx.infamy + ' infamy');
    if (fx.rel && ctx && ctx.t) out.push((fx.rel > 0 ? '+' : '') + fx.rel + ' relations with ' + nm(ctx.t));
    if (fx.popPct) out.push((fx.popPct > 0 ? '+' : '') + fx.popPct + '% population');
    if (fx.relAll) out.push((fx.relAll > 0 ? '+' : '') + fx.relAll + ' relations with everyone');
    return out.join(' · ') || 'No effect';
  };

  /* ---------- random events ---------- */
  const neighbourOf = (id, st) => {
    const set = {};
    G.provinces.forEach(p => { if (p.sea || st.owners[p.id] !== id) return; p.adj.forEach(n => { const o = st.owners[n]; if (o && o !== id && !st.countries[o].dead) set[o] = 1; }); });
    return Object.keys(set);
  };
  const anyOther = (id, st) => { const l = Object.keys(st.countries).filter(o => o !== id && !st.countries[o].dead); return l.length ? l[Math.floor(G.rand() * l.length)] : null; };
  const atWar = id => G.warsOf(id).length > 0;

  const EV = [
    { id: 'harvest_good', w: 3, title: 'Bumper harvest', text: () => 'Good weather has filled the granaries.', opts: [
      { label: 'Store the surplus', fx: { food: 90 } }, { label: 'Sell abroad', fx: { gold: 120, food: 20 } }], ai: 0 },
    { id: 'harvest_bad', w: 3, title: 'Poor harvest', text: () => 'Drought has cut the harvest. Prices are rising.', opts: [
      { label: 'Buy grain abroad', fx: { gold: -120, food: 60 } }, { label: 'Ration food', fx: { food: -50, manpower: -8 } }], ai: 0 },
    { id: 'strike', w: 3, title: 'Industrial strike', text: () => 'Workers in the factory districts have walked out.', opts: [
      { label: 'Concede to demands', fx: { gold: -150 } }, { label: 'Break the strike', fx: { gold: -40, manpower: -10, infamy: 2 } }], ai: 0 },
    { id: 'boom', w: 2, title: 'Economic boom', text: () => 'Trade and investment are surging.', opts: [
      { label: 'Invest in industry', fx: { gold: 160, steel: 12 } }, { label: 'Fund the army', fx: { gold: 80, manpower: 10 } }], ai: 0 },
    { id: 'mine', w: 2, title: 'Mineral discovery', text: () => 'Surveyors found rich new deposits.', opts: [
      { label: 'Open coal and steel mines', fx: { steel: 35, coal: 40 } }, { label: 'Search for oil', fx: { oil: 22, gold: -60 } }], ai: 0 },
    { id: 'epidemic', w: 2, title: 'Epidemic', text: () => 'Disease is spreading through the cities.', opts: [
      { label: 'Fund hospitals', fx: { gold: -160, manpower: -4 } }, { label: 'Quarantine only', fx: { manpower: -22, popPct: -2 } }], ai: 0 },
    { id: 'parade', w: 2, title: 'Military review', text: () => 'The generals propose a grand review of the troops.', cond: (st, id) => G.armyUnits(id) > 0, opts: [
      { label: 'Hold the parade', fx: { gold: -100, morale: 6 } }, { label: 'Spend on training', fx: { gold: -60, morale: 3, research: 20 } }], ai: 0 },
    { id: 'breakthrough', w: 2, title: 'Scientific breakthrough', text: () => 'Your laboratories report an unexpected advance.', cond: (st, id) => st.tech[id].active.length > 0, opts: [
      { label: 'Fund the project', fx: { gold: -80, research: 60 } }, { label: 'Publish the results', fx: { research: 30, rel: 4 } }], ai: 0, needT: false },
    { id: 'border', w: 3, title: 'Border incident', text: c => 'Shots were exchanged on the border with ' + nm(c.t) + '.', needT: 'nbr', opts: [
      { label: 'Apologise', fx: { rel: 8, infamy: -1 } }, { label: 'Demand compensation', fx: { gold: 80, rel: -10 } }, { label: 'Ignore it', fx: { rel: -3 } }], ai: 2 },
    { id: 'spy', w: 2, title: 'Spy scandal', text: c => 'Agents of ' + nm(c.t) + ' were caught in a government office.', needT: 'any', opts: [
      { label: 'Protest loudly', fx: { rel: -12 } }, { label: 'Quietly expel them', fx: { rel: -4 } }], ai: 1 },
    { id: 'refugees', w: 1, title: 'Refugees arrive', text: () => 'Thousands flee unrest in neighbouring lands.', opts: [
      { label: 'Take them in', fx: { manpower: 14, food: -30, relAll: 2 } }, { label: 'Close the border', fx: { relAll: -2 } }], ai: 1 },
    { id: 'volunteers', w: 2, title: 'Volunteers rally', text: () => 'Patriotic crowds are queuing at the recruiting offices.', cond: (st, id) => atWar(id), opts: [
      { label: 'Enlist them', fx: { manpower: 22 } }, { label: 'Train them first', fx: { manpower: 12, morale: 4, gold: -50 } }], ai: 0 },
    { id: 'weariness', w: 2, title: 'War weariness', text: () => 'Long years of fighting are straining the home front.', cond: (st, id) => atWar(id) && st.day > 400, opts: [
      { label: 'Boost propaganda', fx: { gold: -120, morale: 4 } }, { label: 'Ration the civilians', fx: { food: -40, morale: -3 } }], ai: 0 },
    { id: 'loan', w: 1, title: 'Foreign loan offer', text: c => 'Bankers in ' + nm(c.t) + ' offer easy credit.', needT: 'any', opts: [
      { label: 'Accept the loan', fx: { gold: 220, rel: 6, infamy: 0 } }, { label: 'Decline', fx: { rel: 0 } }], ai: 0 },
    { id: 'flood', w: 1, title: 'Flood damage', text: () => 'Rivers burst their banks and swept away roads and fields.', opts: [
      { label: 'Rebuild at once', fx: { gold: -140 } }, { label: 'Let the locals cope', fx: { food: -40, popPct: -1 } }], ai: 0 }
  ];
  G.RANDOM_EVENTS = EV;

  /* ---------- historical headlines (Old World only) ---------- */
  // who: nations that get a popup choice if the player is one of them; otherwise news only (default option applies).
  const HIST = [
    { id: 'rhineland', y: 1936, m: 2, title: 'Rhineland crisis', who: ['GER', 'FRA', 'GBR'], text: 'German troops enter the demilitarised Rhineland. Paris and London debate their answer.',
      by: { GER: { t: 'FRA', opts: [{ label: 'Hold the line', fx: { rel: -6, morale: 3 } }, { label: 'Offer talks', fx: { rel: 4 } }], ai: 0 },
            FRA: { t: 'GER', opts: [{ label: 'Protest only', fx: { rel: -6 } }, { label: 'Mobilise', fx: { rel: -12, morale: 3, gold: -100 } }], ai: 0 },
            GBR: { t: 'GER', opts: [{ label: 'Seek a settlement', fx: { rel: 5 } }, { label: 'Back France', fx: { rel: -8 } }], ai: 0 } } },
    { id: 'spain', y: 1936, m: 6, title: 'Civil war in Spain', who: ['ESP', 'ITA', 'GER', 'SOV', 'FRA', 'GBR'], text: 'An army revolt splits Spain. Foreign capitals weigh whether to send aid or stay out.',
      by: { ESP: { t: 'FRA', opts: [{ label: 'Rally the loyal provinces', fx: { gold: -120, morale: 4, manpower: 15 } }, { label: 'Appeal abroad', fx: { gold: 80, rel: 6 } }], ai: 0 },
            ITA: { t: 'ESP', opts: [{ label: 'Send aid', fx: { gold: -120, rel: 12 } }, { label: 'Stay out', fx: { rel: 0 } }], ai: 1 },
            GER: { t: 'ESP', opts: [{ label: 'Send aid', fx: { gold: -120, rel: 10, research: 25 } }, { label: 'Stay out', fx: { rel: 0 } }], ai: 1 },
            SOV: { t: 'ESP', opts: [{ label: 'Send aid', fx: { gold: -120, rel: 10 } }, { label: 'Stay out', fx: { rel: 0 } }], ai: 1 },
            FRA: { t: 'ESP', opts: [{ label: 'Non-intervention', fx: { rel: -2 } }, { label: 'Quiet support', fx: { gold: -80, rel: 6 } }], ai: 0 },
            GBR: { t: 'ESP', opts: [{ label: 'Non-intervention', fx: { rel: 0 } }, { label: 'Offer mediation', fx: { rel: 4 } }], ai: 0 } } },
    { id: 'axis', y: 1936, m: 9, title: 'Rome-Berlin understanding', who: ['ITA', 'GER'], text: 'Rome and Berlin announce closer co-operation.',
      by: { ITA: { t: 'GER', opts: [{ label: 'Embrace it', fx: { rel: 22 } }, { label: 'Keep distance', fx: { rel: 6 } }], ai: 0 },
            GER: { t: 'ITA', opts: [{ label: 'Embrace it', fx: { rel: 22 } }, { label: 'Keep distance', fx: { rel: 6 } }], ai: 0 } } },
    { id: 'marco', y: 1937, m: 6, title: 'Clash at Marco Polo Bridge', who: ['JPN', 'CHN'], text: 'A skirmish near Beijing threatens to widen into open war between Japan and China.',
      by: { JPN: { t: 'CHN', opts: [{ label: 'Escalate', fx: { rel: -25, morale: 4, infamy: 4 } }, { label: 'Local settlement', fx: { rel: 6 } }], ai: 0 },
            CHN: { t: 'JPN', opts: [{ label: 'Stand firm', fx: { rel: -20, morale: 5 } }, { label: 'Negotiate', fx: { rel: 6, gold: -60 } }], ai: 0 } } },
    { id: 'anschluss', y: 1938, m: 2, title: 'Pressure on Austria', who: ['GER', 'AUT'], text: 'Berlin presses Vienna for a union of the two German-speaking states.',
      by: { GER: { t: 'AUT', opts: [{ label: 'Press harder', fx: { rel: -20, infamy: 6, morale: 2 } }, { label: 'Ease off', fx: { rel: 6 } }], ai: 0 },
            AUT: { t: 'GER', opts: [{ label: 'Resist', fx: { rel: -10, morale: 4 } }, { label: 'Appease', fx: { rel: 12, gold: -60 } }], ai: 0 } } },
    { id: 'munich', y: 1938, m: 8, title: 'Munich conference', who: ['CZE', 'GER', 'GBR', 'FRA'], text: 'The great powers meet to decide the fate of the Sudetenland.',
      by: { CZE: { t: 'GER', opts: [{ label: 'Mobilise', fx: { rel: -12, morale: 6, gold: -120 } }, { label: 'Seek help', fx: { rel: 4, gold: 60 } }], ai: 0 },
            GER: { t: 'CZE', opts: [{ label: 'Demand more', fx: { rel: -20, infamy: 5 } }, { label: 'Accept a deal', fx: { rel: 6 } }], ai: 0 },
            GBR: { t: 'GER', opts: [{ label: 'Appease', fx: { rel: 12 } }, { label: 'Hold firm', fx: { rel: -8, morale: 2 } }], ai: 0 },
            FRA: { t: 'GER', opts: [{ label: 'Appease', fx: { rel: 10 } }, { label: 'Hold firm', fx: { rel: -8, morale: 2 } }], ai: 0 } } },
    { id: 'pact', y: 1939, m: 7, title: 'Moscow talks', who: ['GER', 'SOV'], text: 'Berlin and Moscow explore a non-aggression arrangement.',
      by: { GER: { t: 'SOV', opts: [{ label: 'Sign a pact', fx: { rel: 30 }, pact: true }, { label: 'Decline', fx: { rel: -5 } }], ai: 0 },
            SOV: { t: 'GER', opts: [{ label: 'Sign a pact', fx: { rel: 30 }, pact: true }, { label: 'Decline', fx: { rel: -5 } }], ai: 0 } } }
  ];
  G.HIST_EVENTS = HIST;

  /* ---------- firing ---------- */
  function pushLog(txt) { const e = G.state.ev; e.log.unshift(G.dateString() + ' — ' + txt); if (e.log.length > 30) e.log.length = 30; }

  function pickTarget(kind, id, st) {
    if (!kind) return null;
    if (kind === 'nbr') { const n = neighbourOf(id, st); return n.length ? n[Math.floor(G.rand() * n.length)] : null; }
    return anyOther(id, st);
  }
  function eventDef(eid) { return EV.find(e => e.id === eid) || null; }

  // Resolve now (AI, or the player after choosing). choice = option index.
  function resolve(id, def, ctx, choice) {
    const opt = def.opts[choice]; if (!opt) return [];
    const out = G.applyEventFx(id, opt.fx, ctx);
    if (opt.pact && ctx && ctx.t) { try { if (!G.hasTreaty('nap', id, ctx.t)) G.signTreaty('nap', id, ctx.t); } catch (e) {} }
    return out;
  }

  function fireRandom(id, st) {
    const e = st.ev, cands = EV.filter(d => (e.cd[id + d.id] || 0) <= st.day && (!d.cond || d.cond(st, id)));
    if (!cands.length) return;
    let tot = 0; cands.forEach(d => { tot += d.w; });
    let r = G.rand() * tot, def = cands[0];
    for (const d of cands) { r -= d.w; if (r <= 0) { def = d; break; } }
    const ctx = { t: pickTarget(def.needT, id, st) };
    if (def.needT && !ctx.t) return;
    e.cd[id + def.id] = st.day + 360;
    if (id === st.player) {
      e.pending.push({ kind: 'random', eid: def.id, t: ctx.t });
      e.last = st.day;
    } else {
      resolve(id, def, ctx, def.ai || 0);
    }
  }

  function fireHistory(st) {
    const e = st.ev, d = st.date;
    for (const h of HIST) {
      if (e.hist[h.id] || d.y < h.y || (d.y === h.y && d.m < h.m)) continue;
      e.hist[h.id] = true;
      if (!st.camp || !st.camp.hist) continue;
      for (const who of h.who) {
        if (st.countries[who].dead) continue;
        const spec = h.by[who]; if (!spec) continue;
        const ctx = { t: spec.t && !st.countries[spec.t].dead ? spec.t : null };
        const def = { opts: spec.opts };
        if (who === st.player) st.ev.pending.push({ kind: 'hist', hid: h.id, who: who, t: ctx.t });
        else resolve(who, def, ctx, spec.ai || 0);
      }
      pushLog('📰 ' + h.title + ' — ' + h.text);
      if (st.player && !h.who.includes(st.player)) G.onHeadline && G.onHeadline(h);
    }
  }

  G.eventsMonth = function () {
    const st = G.state; if (!st || !st.ev || !st.player) return;
    const e = st.ev;
    if (G.scenarioId === 'world') fireHistory(st);
    for (const id of Object.keys(st.countries)) {
      if (st.countries[id].dead) continue;
      if (id === st.player) { if (st.day - e.last >= 45 && G.rand() < 0.4) fireRandom(id, st); }
      else if (G.rand() < 0.12) fireRandom(id, st);
    }
    if (e.pending.length) G.onEventPending && G.onEventPending();
  };

  // The popup spec for the next pending player event: { title, text, opts:[{label, fx, desc}], ctx }.
  G.nextEventSpec = function () {
    const st = G.state, e = st.ev; if (!e || !e.pending.length) return null;
    const p = e.pending[0], pid = st.player;
    let title, text, opts;
    if (p.kind === 'random') { const d = eventDef(p.eid); if (!d) { e.pending.shift(); return G.nextEventSpec(); } title = d.title; text = d.text({ t: p.t }); opts = d.opts; }
    else { const h = HIST.find(x => x.id === p.hid); if (!h) { e.pending.shift(); return G.nextEventSpec(); } title = h.title; text = h.text; opts = h.by[p.who].opts; }
    return { title: title, text: text, hist: p.kind === 'hist', ctx: { t: p.t }, opts: opts.map(o => ({ label: o.label, fx: o.fx, desc: G.describeFx(pid, o.fx, { t: p.t }) })) };
  };
  G.chooseEvent = function (i) {
    const st = G.state, e = st.ev; if (!e.pending.length) return [];
    const p = e.pending.shift(), pid = st.player; let def, label;
    if (p.kind === 'random') def = eventDef(p.eid); else { const h = HIST.find(x => x.id === p.hid); def = { opts: h.by[p.who].opts }; }
    const out = resolve(pid, def, { t: p.t }, i);
    label = def.opts[i].label;
    pushLog((p.kind === 'random' ? def.title : (HIST.find(x => x.id === p.hid) || {}).title) + ': ' + label + (out.length ? ' (' + out.join(', ') + ')' : ''));
    G.logMsg('Event — ' + label + (out.length ? ' (' + out.join(', ') + ')' : ''));
    return out;
  };
})(window.EMP = window.EMP || {});
