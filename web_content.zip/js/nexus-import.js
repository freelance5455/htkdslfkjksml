window.WorkspaceNexusImport=(()=>{
  const gameNames={falloutnv:'Fallout New Vegas',newvegas:'Fallout New Vegas','fallout: new vegas':'Fallout: New Vegas','fallout new vegas':'Fallout New Vegas',fallout3:'Fallout 3',fallout4:'Fallout 4',fallout76:'Fallout 76',skyrimspecialedition:'Skyrim Special Edition',skyrim:'Skyrim',oblivion:'Oblivion',morrowind:'Morrowind',cyberpunk2077:'Cyberpunk 2077',starfield:'Starfield'};
  const clean=value=>value==null?'':String(value).trim();
  const unwrap=input=>{
    if(Array.isArray(input))return input;
    if(!input||typeof input!=='object')return [];
    for(const key of ['mods','results','data','items'])if(Array.isArray(input[key]))return input[key];
    return [input];
  };
  // Our research records keep Nexus identity under research_record. Generic
  // Nexus exports and older captures use modInfo/mod/data or flat objects.
  const sourceObject=item=>item?.research_record||item?.modInfo||item?.mod||item?.data||item;
  function map(item){
    const m=sourceObject(item)||{};
    const domain=clean(m.domain_name||m.domainName||m.game_domain_name||m.gameDomainName||item?.domain_name||m.game||item?.game);
    const modId=m.nexus_mod_id??m.mod_id??m.modId??m.id??item?.nexus_mod_id??item?.mod_id??item?.modId;
    const normalizedDomain=domain.toLowerCase();
    const game=gameNames[normalizedDomain]||clean(m.game_name||m.gameName||m.game||item?.game_name||item?.game||domain);
    const name=clean(m.name||m.mod_name||m.modName||item?.name||item?.mod_name);
    const author=clean(m.author||m.uploaded_by||m.uploadedBy||m.uploader||item?.author);
    const version=clean(m.version||m.mod_version||m.modVersion||item?.version);
    const nestedSummary=item?.summary&&typeof item.summary==='object'?item.summary.short||item.summary.scope:'';
    const summary=clean(m.summary||m.description||nestedSummary||item?.summary);
    let source=clean(m.nexus_url||m.source_url||m.url||item?.nexus_url||item?.source_url||item?.url);
    if(!source&&domain&&modId!==undefined&&modId!==null&&String(modId).trim()){
      const nexusDomain=normalizedDomain==='fallout: new vegas'||normalizedDomain==='fallout new vegas'?'newvegas':domain;
      source=`https://www.nexusmods.com/${nexusDomain}/mods/${modId}`;
    }
    const researchTag=item?.research_record?'Nexus Import, Research Record':String(item?.schema||'').startsWith('modding-workspace-normalized-research')?'Nexus Import, Normalized Research':'Nexus Import';
    return {name,game,status:'Interested',version,installed_version:'',author,source_url:source,installed_path:'',tags:researchTag,notes:summary,archive_reason:''};
  }
  function parse(text){const raw=JSON.parse(text);return unwrap(raw).map(map).filter(mod=>mod.name);}
  const key=mod=>mod.source_url?`url:${mod.source_url.toLowerCase()}`:`fallback:${mod.game.toLowerCase()}|${mod.name.toLowerCase()}|${mod.author.toLowerCase()}`;
  return {parse,key,map};
})();
