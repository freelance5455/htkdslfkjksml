const PatientsController = {
    init: function() {
        this.cacheDOM();
        this.bindEvents();
        this.renderList();
    },

    cacheDOM: function() {
        this.listContainer = document.getElementById('patients-list');
        this.modal = document.getElementById('modal-patient');
        this.form = document.getElementById('form-patient');
        this.btnShowForm = document.getElementById('btn-show-patient-form');
        this.btnCancel = document.getElementById('btn-cancel-patient');
        
        this.inputId = document.getElementById('patient-id');
        this.inputName = document.getElementById('patient-name');
        this.inputPhone = document.getElementById('patient-phone');
        this.modalTitle = document.getElementById('modal-patient-title');
        this.inputSearch = document.getElementById('search-patient');
    },

    bindEvents: function() {
        this.btnShowForm.addEventListener('click', () => this.openModal());
        this.btnCancel.addEventListener('click', () => this.closeModal());
        this.form.addEventListener('submit', (e) => this.savePatient(e));
        this.inputSearch.addEventListener('input', (e) => this.renderList(e.target.value));
    },

    openModal: function(patient = null) {
        if (patient) {
            this.modalTitle.textContent = 'Editar Paciente';
            this.inputId.value = patient.id;
            this.inputName.value = patient.nombre;
            this.inputPhone.value = patient.celular;
        } else {
            this.modalTitle.textContent = 'Nuevo Paciente';
            this.form.reset();
            this.inputId.value = '';
        }
        this.modal.style.display = 'flex';
    },

    closeModal: function() {
        this.modal.style.display = 'none';
        this.form.reset();
    },

    savePatient: function(e) {
        e.preventDefault(); 
        
        const nombre = this.inputName.value.trim();
        const celular = this.inputPhone.value.trim();
        const id = this.inputId.value || Date.now().toString(); 

        if (nombre === "") {
            alert("Por favor, ingresa el nombre del paciente.");
            return;
        }

        if (celular === "") {
            alert("No se ha creado ningún paciente");
            return; 
        }

        const regexCelular = /^\d{10}$/;
        if (!regexCelular.test(celular)) {
            alert("Este número de celular no es válido");
            this.inputPhone.value = ''; 
            this.inputPhone.focus();    
            return; 
        }

        let pacientes = StorageManager.getData('pacientes');

        const celularExistente = pacientes.find(p => p.celular === celular && p.id !== id);
        if (celularExistente) {
            if (celularExistente.nombre.toLowerCase() === nombre.toLowerCase()) {
                alert(`El Paciente (${celularExistente.nombre}) ya está ingresado`);
            } else {
                alert(`Este celular ya corresponde a un paciente diferente (${celularExistente.nombre})`);
            }
            return; 
        }

        if (this.inputId.value) {
            pacientes = pacientes.map(p => p.id === id ? { id, nombre, celular } : p);
        } else {
            pacientes.push({ id, nombre, celular });
        }

        StorageManager.saveData('pacientes', pacientes);
        this.closeModal();
        this.inputSearch.value = '';
        this.renderList();

        // COMUNICACIÓN ENTRE MÓDULOS: Avisamos que se guardó un paciente
        // Esto es clave para que Citas.js actualice su lista desplegable sin recargar la página.
        document.dispatchEvent(new CustomEvent('pacienteGuardado', { detail: { id: id, nombre: nombre } }));
    },

    deletePatient: function(id) {
        // Verificar si el paciente tiene citas antes de eliminar (Protección de Integridad)
        let citas = StorageManager.getData('citas');
        let citasDelPaciente = citas.filter(c => c.pacienteId === id);
        
        if (citasDelPaciente.length > 0) {
            alert("No puedes eliminar este paciente porque tiene citas asignadas. Cancela o elimina sus citas primero.");
            return;
        }

        if (confirm('¿Estás seguro de eliminar este paciente?')) {
            let pacientes = StorageManager.getData('pacientes');
            pacientes = pacientes.filter(p => p.id !== id);
            StorageManager.saveData('pacientes', pacientes);
            this.renderList(this.inputSearch.value);
        }
    },

    renderList: function(filtro = '') {
        let pacientes = StorageManager.getData('pacientes');
        this.listContainer.innerHTML = ''; 

        if (filtro.trim() !== '') {
            const termino = filtro.toLowerCase().trim();
            pacientes = pacientes.filter(p => 
                p.nombre.toLowerCase().includes(termino) || 
                p.celular.includes(termino)
            );
        }

        if (pacientes.length === 0) {
            const mensaje = filtro !== '' 
                ? 'No se encontraron pacientes con esa búsqueda.' 
                : 'No hay pacientes registrados.';
            this.listContainer.innerHTML = `<p style="text-align:center; color:#888;">${mensaje}</p>`;
            return;
        }

        pacientes.forEach(p => {
            const li = document.createElement('li');
            li.className = 'data-item';
            li.innerHTML = `
                <div class="data-item-info">
                    <h4>${p.nombre}</h4>
                    <p>📱 ${p.celular}</p>
                </div>
                <div class="data-item-actions">
                    <div class="action-buttons">
                        <button class="btn-edit" onclick="PatientsController.openModal({id: '${p.id}', nombre: '${p.nombre}', celular: '${p.celular}'})">✏️</button>
                        <button class="btn-delete" onclick="PatientsController.deletePatient('${p.id}')">🗑️</button>
                    </div>
                </div>
            `;
            this.listContainer.appendChild(li);
        });
    }
};

document.addEventListener('DOMContentLoaded', () => {
    PatientsController.init();
});
