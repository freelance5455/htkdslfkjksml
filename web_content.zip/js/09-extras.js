/* Garagem, customizacao, placar, loja e online */
/* ---------- garagem da tela inicial: galpao fechado, longe do mapa, onde o veiculo escolhido fica parado e animado ---------- */
var inGarage=true;
const GAR=(()=>{
  const W=60,D=60,H=18,gx=0,gz=0,gy=500,g=new THREE.Group(),L=[];g.position.set(gx,gy,gz);
  const M=(c,o)=>new THREE.MeshLambertMaterial(Object.assign({color:c},o||{})),B=(w,h,d,m,x,y,z,p)=>{const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);o.position.set(x,y,z);(p||g).add(o);return o};
  const tx=(w,h,fn,rx,ry)=>{const t=canvasTex(w,h,fn);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(rx,ry);return t};
  const lampM=new THREE.MeshBasicMaterial({color:0xfff4d8}),winM=new THREE.MeshBasicMaterial({color:0xbfe0f5}),dk=M(0x2f3129),steel=M(0x4a4d44);
  /* piso de concreto com juntas, manchas de oleo e vaga marcada em amarelo */
  const fl=B(W,.4,D,M(0xffffff,{map:tx(256,256,(x,w,h)=>{x.fillStyle='#6b6d69';x.fillRect(0,0,w,h);for(let i=0;i<900;i++){x.fillStyle=Math.random()<.5?'#777974':'#5d5f5b';x.fillRect(Math.random()*w,Math.random()*h,2,2)}x.strokeStyle='#4a4c49';x.lineWidth=3;x.strokeRect(0,0,w,h)},15,15)}),0,-.2,0);fl.receiveShadow=true;
  const oil=new THREE.MeshBasicMaterial({color:0x2a2b28,transparent:true,opacity:.3,depthWrite:false}),yl=M(0xd9b12a);
  for(let k=0;k<9;k++){const o=new THREE.Mesh(new THREE.CircleGeometry(.8+Math.random()*1.6,14).rotateX(-Math.PI/2),oil);o.position.set((Math.random()-.5)*44,.02,(Math.random()-.5)*44);g.add(o)}
  for(const s of[-1,1]){B(.2,.03,28,yl,s*10,.02,0);B(20,.03,.2,yl,0,.02,s*14)}
  /* paredes de chapa ondulada, rodape de concreto, teto com tesouras e luminarias */
  const wt=M(0xffffff,{map:tx(128,128,(x,w,h)=>{for(let i=0;i<16;i++){x.fillStyle=i%2?'#7f8470':'#757a67';x.fillRect(i*8,0,8,h)}},W/4,3)}),cc=M(0x55574f);
  B(W,H,.6,wt,0,H/2,-D/2-.3);B(W,H,.6,wt,0,H/2,D/2+.3);B(.6,H,D,wt,-W/2-.3,H/2,0);B(.6,H,D,wt,W/2+.3,H/2,0);
  B(W,1.4,.3,cc,0,.7,-D/2+.15);B(W,1.4,.3,cc,0,.7,D/2-.15);B(.3,1.4,D,cc,-W/2+.15,.7,0);B(.3,1.4,D,cc,W/2-.15,.7,0);
  B(W+1,.5,D+1,M(0x3b3e36),0,H+.25,0);for(let i=-3;i<=3;i++)B(W,.45,.45,dk,0,H-.3,i*9);for(const x of[-20,0,20])B(.45,.45,D,dk,x,H-.3,0);
  for(const x of[-15,0,15])for(const z of[-15,0,15]){B(5,.18,1,lampM,x,H-1.4,z);B(.05,.9,.05,dk,x-2,H-.9,z);B(.05,.9,.05,dk,x+2,H-.9,z)}
  const pl=(x,y,z)=>{const l=new THREE.PointLight(0xfff2d8,1.1,75,1);l.position.set(gx+x,gy+y,gz+z);return l};L.push(pl(0,H-3,0),pl(-17,H-3,12),pl(17,H-3,-12));
  /* janelas altas na parede esquerda e portao de enrolar com faixa de perigo na direita */
  for(const z of[-20,-10,0,10,20]){B(.1,2.6,4.2,winM,-W/2+.05,12,z);B(.15,.2,4.6,dk,-W/2+.08,13.4,z);B(.15,.2,4.6,dk,-W/2+.08,10.6,z)}
  B(.2,10,16,M(0xffffff,{map:tx(64,64,(x,w,h)=>{x.fillStyle='#8c8f84';x.fillRect(0,0,w,h);for(let i=0;i<8;i++){x.fillStyle='#6b6e64';x.fillRect(0,i*8+6,w,2)}},1,2)}),W/2-.1,5,0);
  const hz=M(0xffffff,{map:tx(64,64,(x,w,h)=>{x.fillStyle='#d9b12a';x.fillRect(0,0,w,h);x.fillStyle='#1b1b1a';for(let i=-2;i<5;i++){x.beginPath();x.moveTo(i*16,h);x.lineTo(i*16+8,h);x.lineTo(i*16+24,0);x.lineTo(i*16+16,0);x.fill()}},1,10)});
  B(.3,10.6,.6,hz,W/2-.2,5.3,8.3);B(.3,10.6,.6,hz,W/2-.2,5.3,-8.3);B(.3,.6,17.2,hz,W/2-.2,10.4,0);
  /* faixa com o nome do jogo na parede do fundo */
  B(26,5,.1,M(0xffffff,{map:tx(512,100,(x,w,h)=>{x.fillStyle='#262a1c';x.fillRect(0,0,w,h);x.strokeStyle='#d9a21a';x.lineWidth=4;x.strokeRect(6,6,w-12,h-12);x.fillStyle='#e8b020';x.font='700 62px Arial,sans-serif';x.textAlign='center';x.textBaseline='middle';x.fillText('BLINDADOS',w/2,h/2+3)},1,1)}),0,11,-D/2+.1);
  /* estantes com caixas e pneus, tambores, pilhas de pneus, carrinho de ferramentas e ponte rolante */
  const crate=[0x6a5a3a,0x4b5036,0x3c3f36],shelf=(x,z)=>{for(const sx of[-3,3])for(const sz of[-.8,.8])B(.15,4.6,.15,steel,x+sx,2.3,z+sz);
    for(let k=0;k<3;k++){B(6.3,.12,1.8,steel,x,.9+k*1.5,z);for(let i=0;i<4;i++){if(Math.random()<.75)B(1.1,.8,1.1,M(crate[(Math.random()*3)|0]),x-2.3+i*1.5,1.4+k*1.5,z);else{const t=new THREE.Mesh(new THREE.CylinderGeometry(.5,.5,.4,12).rotateX(Math.PI/2),M(0x1b1b1a));t.position.set(x-2.3+i*1.5,1.5+k*1.5,z);g.add(t)}}}};
  for(const x of[-21,-7,7,21])shelf(x,D/2-2.2);
  for(const[x,z,c]of[[-27,-27,0x8a2a1c],[-26,-26,0x2a4a6a],[27,27,0x4b5036],[26,26,0x8a2a1c],[-27,26,0x2a4a6a],[27,-26,0x4b5036],[26,-27,0x8a2a1c]]){const b=new THREE.Mesh(new THREE.CylinderGeometry(.45,.45,1.2,12),M(c));b.position.set(x,.6,z);g.add(b)}
  for(let s=0;s<3;s++)for(let k=0;k<5;k++){const t=new THREE.Mesh(new THREE.CylinderGeometry(.55,.55,.38,14),M(0x1b1b1a));t.position.set(-26+s*1.3,.2+k*.38,12);g.add(t)}
  B(2.2,1.1,1,M(0x9a2a1c),24,.7,-19);B(2.3,.1,1.1,dk,24,1.3,-19);for(let k=0;k<3;k++)B(1.8,.25,.05,dk,24,.5+k*.3,-18.5);
  for(const s of[-1,1])B(.5,.6,D,steel,s*26,H-2.5,0);B(52,.8,1,M(0xd9b12a),0,H-2.6,6);B(2,1,1.6,M(0xd9b12a),0,H-3.5,6);B(.08,3,.08,dk,0,H-5.4,6);B(.5,.4,.4,steel,0,H-7,6);
  return{g,L,x:gx,y:gy,z:gz};
})();
/* a camera fica dentro da garagem, orbitando o veiculo escolhido, que balanca a torre e roda as animacoes de repouso */
function menuCam(now){
  const T=player,asp=innerWidth/innerHeight,wide=asp>1,tn=Math.tan(cam.fov*Math.PI/360),a=now/1000*.3+.6,dt=Math.min(.05,(now-(menuCam.t||now))/1000);menuCam.t=now;
  const C=!!T.corv,gx=C?T.x:GAR.x,gz=C?T.z:GAR.z,gy=C?WATER+.2:GAR.y,r=C?(wide?64:clamp(33/(tn*asp),60,130)):Math.min((wide?16:clamp(6/(tn*asp),16,42))+(T.air?4:0),27);
  /* corveta: sem galpao, o navio aparece no mar aberto e a camera orbita mais longe */
  if(C){if(GAR.g.parent){scene.remove(GAR.g);GAR.L.forEach(l=>scene.remove(l))}}else if(!GAR.g.parent){scene.add(GAR.g);GAR.L.forEach(l=>scene.add(l))}
  if(C){T.yaw=T.hd+Math.sin(now/1000*.45)*.5;T.pitch=.06;T.v=0;place(T)}else{T.g.position.set(gx,gy,gz);T.g.rotation.set(0,T.hd,0);
  if(T.tg&&!T.air){T.tg.rotation.y=Math.sin(now/1000*.45)*.5;T.bp.rotation.x=-.06}}
  if(!T.aerr)try{animTank(T,dt)}catch(e){T.aerr=1}
  const px=gx+Math.sin(a)*r,pz=gz+Math.cos(a)*r;
  cam.position.set(px,gy+(C?16:T.air?6:4.4),pz);
  const fx=gx-px,fz=gz-pz,fl=Math.hypot(fx,fz)||1,sh=wide?tn*asp*r*(menuCard.offsetWidth/innerWidth):0,dy=wide?0:tn*r*(menuCard.offsetHeight/innerHeight);
  cam.lookAt(gx+fz/fl*sh,gy+(C?3:T.air?3:1.4)-dy,gz-fx/fl*sh);
  sun.position.set(gx+sunV.x,gy+sunV.y,gz+sunV.z);sun.target.position.set(gx,gy,gz);
  const sel=document.querySelector('.pick .sel');if(sel&&vnEl.textContent!==sel.textContent)vnEl.textContent=sel.textContent;
}
let last=performance.now();
const errBox=(()=>{const d=document.createElement('div');d.style.cssText='position:fixed;left:8px;right:8px;bottom:8px;z-index:99;background:rgba(120,0,0,.85);color:#fff;font:12px monospace;padding:6px 8px;border-radius:4px;display:none;white-space:pre-wrap;pointer-events:none;max-height:30vh;overflow:hidden';document.body.appendChild(d);return d})();
function showErr(w,e){console.error(e);errBox.style.display='block';errBox.textContent=w+': '+(e&&e.message||e)+'\n'+String(e&&e.stack||'').split('\n').slice(1,4).join('\n')}
window.addEventListener('error',ev=>showErr('Erro',ev.error||ev.message));
function loop(now){
  requestAnimationFrame(loop);const dt=Math.min(.05,(now-last)/1000);last=now;
  if(running){try{update(dt);camUpdate();drawAim(dt);drawBars()}catch(e){showErr('update',e)}}else{retEl.style.display=leadEl.style.display='none';barsEl.style.display='none';if(!started)menuCam(now)}
  flushTerrain();renderer.render(scene,cam);
}
/* ---------- customização: cores, kits e peças (cada peça dá uma pequena vantagem) ---------- */
const SLOTS=[['s','Saias laterais',['Nenhuma','Lisas','Reativa','Grade','Esteiras extras']],['f','Frente do casco',['Nenhuma','Lâmina de dozer','Blindagem reativa','Sacos de areia','Barra de luzes']],['k','Laterais da torre',['Nenhuma','Placas','Blocos reativos']],['r','Traseira da torre',['Nenhuma','Caixas de estiva','Cesto de grade','Antena e holofote','Galões','Sacos de areia']],['u','Teto da torre',['Nenhum','Metralhadora AA','Lançadores de fumaça','Radar']],['m','Cano',['Padrão','Freio de boca','Extrator de fumaça','Camisa térmica','Compensador em T','Ponta cônica']]];
const KITS=[['Padrão','','','000000'],['Urbano','#6d7076','#1e1f22','340332'],['Assalto','#8a7a4a','#3b3322','112111'],['Furtivo','#2f2f33','#0e0e10','101003'],['Guerra','#5b6b3a','#2b2d28','430412']];
let CUST={c:'',a:'',p:{s:0,f:0,k:0,r:0,u:0,m:0}},noCust=0;
try{const o=JSON.parse(localStorage.getItem('blindados_cust2')||'null');if(o&&o.p){CUST.c=o.c||'';CUST.a=o.a||'';for(const x of SLOTS)CUST.p[x[0]]=Math.min(x[2].length-1,+o.p[x[0]]||0)}}catch(x){}
const custStr=()=>(CUST.c||'')+'|'+(CUST.a||'')+'|'+SLOTS.map(x=>CUST.p[x[0]]).join('');
const PERK={s:[null,{a:.04},{a:.06},{a:.05},{a:.03,v:.03}],f:[null,{a:.03,v:.01},{a:.06},{a:.05},{v:.02}],k:[null,{a:.03},{a:.05}],r:[null,{l:.03},{a:.01,l:.02},{l:.04},{v:.04},{a:.03}],u:[null,{l:.02},{a:.05},{l:.05}],m:[null,{l:.04},{l:.03},{l:.03,a:.01},{l:.05},{l:.02}]};
function perkOf(P){const o={arm:0,rld:0,spd:0};for(const k in P){const q=(PERK[k]||[])[P[k]];if(!q)continue;o.arm+=q.a||0;o.rld+=q.l||0;o.spd+=q.v||0}o.arm=Math.min(o.arm,.18);o.rld=Math.min(o.rld,.12);o.spd=Math.min(o.spd,.06);return o}
function perkTxt(){const P={};SLOTS.forEach(x=>P[x[0]]=CUST.p[x[0]]||0);const o=perkOf(P),a=[];if(o.arm)a.push('blindagem +'+Math.round(o.arm*100)+'%');if(o.rld)a.push('recarga +'+Math.round(o.rld*100)+'%');if(o.spd)a.push('velocidade +'+Math.round(o.spd*100)+'%');return a.length?'Bônus das peças: '+a.join(' · '):'Cada peça instalada dá uma pequena vantagem.'}
function applyCust(t,cs){
  if(!t||!cs)return;const[c,ac,pp]=String(cs).split('|'),hex=/^#[0-9a-f]{6}$/i;t.cs=cs;t.cperk=null;if(t.spd0!==undefined)t.spd=t.spd0;
  for(const o of t.cparts||[])if(o.parent)o.parent.remove(o);t.cparts=[];
  if(hex.test(c)&&t.mat&&!t.dead)t.mat.color.set(c);
  if(t.air||t.corv||!t.g||!t.hull||!t.tg||!t.bar||!t.bp)return;
  const P={};SLOTS.forEach((x,i)=>P[x[0]]=Math.min(x[2].length-1,+(pp||'')[i]||0));{const pk=perkOf(P);if(pk.arm||pk.rld||pk.spd){t.cperk=pk;if(t.spd0===undefined)t.spd0=t.spd||1;t.spd=t.spd0*(1+pk.spd)}}if(!Object.values(P).some(v=>v))return;
  const objs=[t.g,t.hull,t.tg,t.bp,t.bar],rs=objs.map(o=>o.rotation.clone()),gp=t.g.position.clone();
  t.g.position.set(0,0,0);for(const o of objs)o.rotation.set(0,0,0);t.g.updateMatrixWorld(true);
  const dk=new THREE.MeshLambertMaterial({color:hex.test(ac)?ac:0x2b2d28}),tan=new THREE.MeshLambertMaterial({color:0x8a7a55}),oli=new THREE.MeshLambertMaterial({color:0x5c6140}),lit=new THREE.MeshBasicMaterial({color:0xfff2b0});
  const add=(p,o)=>{o.traverse(q=>{if(q.isMesh)q.castShadow=true});p.add(o);t.cparts.push(o)};
  const mk=(w,h,d,mt,x,y,z)=>bx(w,h,d,mt||t.mat,x,y,z),cy=(a,b,l,mt,x,y,z)=>{const o=new THREE.Mesh(new THREE.CylinderGeometry(a,b,l,10),mt||dk);o.rotation.x=Math.PI/2;o.position.set(x,y,z);return o};
  const H=(...a)=>add(t.hull,mk(...a)),T=(...a)=>add(t.tg,mk(...a));
  try{
    /* medidas de referência: rodas dão lado, base e comprimento; o casco dá o resto (sem a tripulação inflar a conta) */
    const isUnder=(o,r)=>{for(let p=o;p;p=p.parent)if(p===r)return true;return false};
    const lbox=(b,fr)=>{const o=new THREE.Box3();for(const x of[b.min.x,b.max.x])for(const y of[b.min.y,b.max.y])for(const z of[b.min.z,b.max.z])o.expandByPoint(fr.worldToLocal(new THREE.Vector3(x,y,z)));return o};
    const rc=new THREE.Raycaster(),hullM=[],tgM=[];
    const solid=m=>{for(let p=m;p;p=p.parent)if(!p.visible)return false;const mt=m.material;return !(mt&&mt.transparent&&mt.opacity<.9)};
    t.g.traverse(m=>{if(m.isMesh&&!isUnder(m,t.tg)&&solid(m))hullM.push(m)});t.tg.traverse(m=>{if(m.isMesh&&!isUnder(m,t.bp)&&solid(m))tgM.push(m)});
    const mkRay=(fr,list)=>(o,d)=>{try{rc.near=0;rc.far=90;rc.set(fr.localToWorld(new THREE.Vector3(o[0],o[1],o[2])),new THREE.Vector3(d[0],d[1],d[2]).normalize());const h=rc.intersectObjects(list,false)[0];return h?fr.worldToLocal(h.point.clone()):null}catch(e){return null}};
    const hRay=mkRay(t.hull,hullM),tRay=mkRay(t.tg,tgM);
    const wb=new THREE.Box3();let hw_=0;for(const w of t.wheels||[]){wb.expandByObject(w);hw_=1}
    const hbW=new THREE.Box3();for(const m of hullM)hbW.expandByObject(m);
    const hb=lbox(hbW.isEmpty()?new THREE.Box3().setFromObject(t.hull):hbW,t.hull),wbL=hw_&&!wb.isEmpty()?lbox(wb,t.hull):null,hasW=!!wbL;
    const hw=Math.max(.6,hasW?Math.max(wbL.max.x,-wbL.min.x):hb.max.x),yb=hasW?wbL.min.y:hb.min.y,wh=hasW?wbL.max.y-wbL.min.y:.9;
    const bodyH=Math.max(yb+.8,Math.min(hb.max.y,yb+Math.max(1.2,wh*2.1))),zmin=hasW?wbL.min.z:hb.min.z,zmax=hasW?wbL.max.z:hb.max.z,zl=zmax-zmin,zc=(zmax+zmin)/2,rz=Math.max(hb.min.z,zmin-.8);
    let fz=Math.min(hb.max.z,zmax+.8);
    const fy0=yb+(bodyH-yb)*.5;
    {const p=hRay([0,fy0,zmax+40],[0,0,-1]);if(p&&p.z>zmin&&p.z<zmax+2.5)fz=p.z}
    const topAt=(x,z)=>{const p=hRay([x,60,z],[0,-1,0]);return p&&p.y>yb&&p.y<bodyH+1.4?p.y:bodyH};
    const SXS={};
    for(const sd of[-1,1]){let m=hw;for(const zz of[zc-zl*.25,zc,zc+zl*.25]){const p=hRay([sd*40,yb+(bodyH-yb)*.35,zz],[-sd,0,0]);if(p&&Math.abs(p.x)>hw-.5&&Math.abs(p.x)<hw+1.2)m=Math.max(m,Math.abs(p.x))}SXS[sd]=m+.07}
    const y0=yb+(hasW?wh*.4:.3),y1=Math.min(y0+1.1,Math.max(y0+.35,bodyH*.78)),sh=y1-y0,sy=(y0+y1)/2,sl=Math.min(zl*.78,7);
    /* saias */
    if(P.s)for(const sd of[-1,1]){
      if(P.s===1)H(.12,sh,sl,0,sd*SXS[sd],sy,zc);
      else if(P.s===2){const n=6,w=sl/n;for(let i=0;i<n;i++)H(.2,sh*.9,w*.88,i%2?dk:0,sd*(SXS[sd]+.03),sy,zc-sl/2+w*(i+.5))}
      else if(P.s===3){const n=Math.min(16,Math.round(sl/.25));H(.06,.06,sl,dk,sd*SXS[sd],y1,zc);H(.06,.06,sl,dk,sd*SXS[sd],y0,zc);for(let i=0;i<=n;i++)H(.05,sh,.05,dk,sd*SXS[sd],sy,zc-sl/2+sl*i/n)}
      else{const n=Math.min(9,Math.round(sl/.55));for(let i=0;i<n;i++){H(.14,.2,.46,dk,sd*(SXS[sd]+.03),bodyH*.62,zc-sl/2+sl*(i+.5)/n);H(.14,.2,.46,oli,sd*(SXS[sd]+.03),bodyH*.62+.22,zc-sl/2+sl*(i+.5)/n)}}}
    /* frente do casco */
    if(P.f){const fy=yb+(bodyH-yb)*.5;
      if(P.f===1){const pl=mk(hw*2+.5,(bodyH-yb)*.55,.14,dk,0,yb+(bodyH-yb)*.3,fz+.28);pl.rotation.x=-.18;add(t.hull,pl);for(const sd of[-1,1])H(.1,.12,.7,dk,sd*(hw*.55),yb+(bodyH-yb)*.3,fz+.12)}
      else if(P.f===2){for(let r=0;r<2;r++)for(let i=0;i<5;i++)H(hw*2*.17,.3,.1,(i+r)%2?dk:0,-hw*.8+hw*1.6*i/4,fy+r*.34,fz+.05)}
      else if(P.f===3){for(let r=0;r<2;r++)for(let i=0;i<5-r;i++){const bx_=-hw*.7+hw*1.4*(i+r*.5)/4;H(.5,.26,.34,tan,bx_,topAt(bx_,fz-.55)+.14+r*.26,fz-.55)}}
      else{const by_=topAt(0,fz-.3)+.18;H(hw*1.7,.12,.16,dk,0,by_,fz-.3);for(let i=0;i<4;i++)H(.18,.1,.04,lit,-hw*.65+hw*1.3*i/3,by_,fz-.2);H(.5,.3,.3,dk,0,yb+.35,fz+.15)}}
    /* torre */
    const tb=new THREE.Box3();for(const ch of t.tg.children)if(ch!==t.bp)tb.expandByObject(ch);
    if((P.k||P.r||P.u)&&!tb.isEmpty()){const tL=lbox(tb,t.tg),cz=(tL.min.z+tL.max.z)/2,ylo=tL.min.y,tw=(tL.max.x-tL.min.x)/2,tl=tL.max.z-tL.min.z,hh0=tL.max.y-tL.min.y;
      let roof=null;{const hs=[];for(const fx of[-.35,0,.35])for(const fq of[-.25,.1,.3]){const p=tRay([fx*tw*2,60,cz+fq*tl],[0,-1,0]);if(p)hs.push(p.y)}if(hs.length){hs.sort((a,b)=>a-b);roof=hs[hs.length>>1]}}
      const ytop=roof!==null&&roof>ylo+hh0*.3?roof:ylo+hh0*.85,hh=Math.max(.3,ytop-ylo),yhi=ylo+hh*.7,yc=(ylo+yhi)/2,w=Math.min(2.6,tw*1.6);
      let zb=tL.min.z-.05;{const p=tRay([0,yc,tL.min.z-40],[0,0,1]);if(p&&Math.abs(p.z-tL.min.z)<1.2)zb=p.z-.02}
      let twS=tw;{const q=tRay([40,yc,cz],[-1,0,0]);if(q&&Math.abs(q.x-tw)<.8)twS=Math.abs(q.x)}
      if(P.k)for(const sd of[-1,1]){if(P.k===1)T(.14,hh*.55,Math.max(.8,(tb.max.z-tb.min.z)*.35),0,sd*(twS+.08),yc,cz+.3);else for(let i=0;i<3;i++)T(.18,hh*.4,.34,i%2?dk:0,sd*(twS+.09),yc,cz+.9-i*.42)}
      const R=P.r;
      if(R===1){T(w*.4,.45,.5,dk,-w*.28,yc,zb-.25);T(w*.38,.35,.45,0,w*.25,yc-.05,zb-.23);T(.22,.3,.2,dk,w*.02,yc-.1,zb-.15)}
      else if(R===2){T(w,.06,.7,dk,0,ylo+.2,zb-.35);for(let i=0;i<6;i++)T(.05,.6,.05,dk,-w/2+w*i/5,ylo+.5,zb-.7);for(const sd of[-1,1])T(.05,.05,.7,dk,sd*w/2,ylo+.8,zb-.35);T(w,.05,.05,dk,0,ylo+.8,zb-.7)}
      else if(R===3){const mast=new THREE.Mesh(new THREE.CylinderGeometry(.03,.03,1.5,6),dk);mast.position.set(-w*.3,yhi+.75,zb+.6);add(t.tg,mast);T(.35,.25,.3,dk,w*.3,yhi+.2,zb+.5);T(.26,.18,.04,lit,w*.3,yhi+.2,zb+.5+.17)}
      else if(R===4){for(let i=0;i<4;i++)T(.3,.46,.2,i%2?oli:dk,-w*.36+w*.24*i,yc,zb-.12);T(w*.9,.05,.05,dk,0,yc+.3,zb-.24)}
      else if(R===5){for(let r=0;r<2;r++)for(let i=0;i<4-r;i++)T(.5,.26,.32,tan,-w*.35+w*.7*(i+r*.5)/3,ylo+.25+r*.27,zb-.2)}
      const U=P.u;
      if(U===1){const x=tw*.45,z=cz-.15;T(.3,.2,.3,dk,x,ytop+.08,z);T(.12,.12,.9,dk,x,ytop+.28,z+.35);add(t.tg,cy(.03,.03,.7,0,x,ytop+.28,z+.95));T(.5,.36,.05,dk,x,ytop+.36,z+.15)}
      else if(U===2){for(const sd of[-1,1])for(let i=0;i<4;i++)add(t.tg,cy(.06,.06,.38,0,sd*(twS+.06),ytop-.1,cz+.7-i*.16))}
      else if(U===3){const mast=new THREE.Mesh(new THREE.CylinderGeometry(.04,.04,.7,6),dk);mast.position.set(0,ytop+.35,cz-.3);add(t.tg,mast);T(.9,.05,.45,dk,0,ytop+.75,cz-.3);T(.14,.14,.14,lit,0,ytop+.82,cz-.1)}}
    /* cano */
    const M=P.m;
    if(M){const bb=new THREE.Box3();for(const ch of t.bar.children)if(ch!==t.fl)bb.expandByObject(ch);
      if(!bb.isEmpty()){const tp=t.bar.worldToLocal(new THREE.Vector3((bb.min.x+bb.max.x)/2,(bb.min.y+bb.max.y)/2,bb.max.z)),L=bb.max.z-bb.min.z,r=Math.min(.3,Math.max(.07,(bb.max.x-bb.min.x)/2)),B=(...a)=>add(t.bar,mk(...a)),C=(...a)=>add(t.bar,cy(...a));
        if(M===1){C(r*1.7,r*1.7,.5,0,tp.x,tp.y,tp.z-.3);B(r*4.2,r*.5,.3,dk,tp.x,tp.y,tp.z-.3)}
        else if(M===2){C(r*1.6,r*1.6,L*.14,0,tp.x,tp.y,tp.z-L*.5);C(r*1.3,r*1.3,L*.03,0,tp.x,tp.y,tp.z-L*.6)}
        else if(M===3)C(r*1.3,r*1.3,L*.5,0,tp.x,tp.y,tp.z-L*.45);
        else if(M===4){C(r*1.4,r*1.4,.4,0,tp.x,tp.y,tp.z-.25);B(r*5,r*.8,.14,dk,tp.x,tp.y,tp.z-.25);B(r*.8,r*5,.14,dk,tp.x,tp.y,tp.z-.25)}
        else{C(r*.7,r*1.5,.55,0,tp.x,tp.y,tp.z-.1);for(let i=0;i<3;i++)C(r*1.4,r*1.4,.06,0,tp.x,tp.y,tp.z-.6-i*.25)}}}
  }catch(e){}
  finally{t.g.position.copy(gp);objs.forEach((o,i)=>o.rotation.copy(rs[i]));t.g.updateMatrixWorld(true)}
}
for(const k in VEH){const f=VEH[k];VEH[k]=()=>{const t=f();if(!noCust)applyCust(t,custStr());return t}}
function custSave(){try{localStorage.setItem('blindados_cust2',JSON.stringify(CUST))}catch(x){}custUI();try{setVehicle(curV)}catch(x){}}
let custUI=()=>{};
{const body=document.getElementById('cbody');
  const row=l=>{const p=document.createElement('p');p.className='lbl';p.textContent=l;body.appendChild(p);const d=document.createElement('div');d.className='chips';body.appendChild(d);return d};
  const btn=(d,txt,fn)=>{const b=document.createElement('button');b.textContent=txt;b.onclick=fn;d.appendChild(b);return b};
  const kd=row('Kits prontos');for(const k of KITS)btn(kd,k[0],()=>{CUST.c=k[1];CUST.a=k[2];SLOTS.forEach((x,i)=>CUST.p[x[0]]=+k[3][i]);custSave()});
  btn(kd,'🎲 Aleatório',()=>{const pk=['#5b6b3a','#8a7a4a','#3d5f86','#7a2e2e','#2f2f33','#d8d2c0','#c26a1b','#4a3b6b'];CUST.c=pk[Math.random()*pk.length|0];CUST.a=pk[Math.random()*pk.length|0];for(const x of SLOTS)CUST.p[x[0]]=Math.random()*x[2].length|0;custSave()});
  const colorRow=(lbl,key)=>{const d=row(lbl);for(const c of['#5b6b3a','#8a7a4a','#3d5f86','#7a2e2e','#2f2f33','#d8d2c0','#c26a1b','#4a3b6b']){const b=btn(d,'',()=>{CUST[key]=c;custSave()});b.className='sw';b.style.background=c}
    const i=document.createElement('input');i.type='color';i.className='ccol';i.onchange=()=>{CUST[key]=i.value;custSave()};d.appendChild(i);btn(d,'Padrão',()=>{CUST[key]='';custSave()});return i};
  const ci=colorRow('Cor do tanque','c'),ai=colorRow('Cor das peças','a');
  const chips=SLOTS.map(x=>{const d=row(x[1]);return x[2].map((n,i)=>btn(d,n,()=>{CUST.p[x[0]]=i;custSave()}))});
  const pe=document.createElement('p');pe.className='lbl';pe.style.color='#ffd27a';body.appendChild(pe);
  custUI=()=>{pe.textContent=perkTxt();chips.forEach((L,si)=>L.forEach((b,i)=>b.classList.toggle('on',CUST.p[SLOTS[si][0]]===i)));if(CUST.c)ci.value=CUST.c;if(CUST.a)ai.value=CUST.a};
  custUI();applyCust(player,custStr())}
/* ---------- placar, moedas, objetivos por onda e loja ---------- */
const UP={a:0,r:0};let ST={},OBJ={ty:-1},objM=null,sbT=0,objCache='',nickC='';
const curNick=()=>{const e=document.getElementById('nick');const n=((e&&e.value)||nickC||'').replace(/[<>&"]/g,'').trim().slice(0,12)||'Jogador';if(n!==nickC){nickC=n;try{localStorage.setItem('blindados_nick',n)}catch(x){}}return n};
try{const e=document.getElementById('nick');if(e)e.value=localStorage.getItem('blindados_nick')||''}catch(x){}
const stOf=id=>ST[id]||(ST[id]={n:id==='host'?curNick():'Aliado',k:0,d:0,c:30,a:0,r:0,w:0});
function credit(by,t){const s=stOf(by.remote||'host');s.k++;s.w++;s.c+=6;if(t&&t.boss){const b=60+15*wave,m='Chefe derrotado!';for(const id in ST)ST[id].c+=b;toast(m);netBc({t:'ms',s:m})}}
function objNew(){const ty=wave%2?0:1;let x=player.x+40,z=player.z;
  if(ty===0)for(let k=0;k<60;k++){const a=Math.random()*6.28,d=70+Math.random()*80,X=player.x+Math.cos(a)*d,Z=player.z+Math.sin(a)*d;if(spawnOK(X,Z,10)){x=X;z=Z;break}}
  OBJ={ty,x,z,p:0,g:25+Math.min(20,wave*2),t:85,done:0}}
function objDone(){OBJ.done=1;const b=30+5*wave;for(const id in ST)ST[id].c+=b;const m='Objetivo cumprido!';toast(m);netBc({t:'ms',s:m})}
function waveEnd(){if(OBJ.ty===1&&OBJ.t>0&&!OBJ.done)objDone();const b=15+5*wave;let mv=null;
  for(const id in ST){const s=ST[id];s.c+=b;if(s.w>0&&(!mv||s.w>mv.w))mv=s}
  const m='Onda '+wave+' vencida'+(mv&&Object.keys(ST).length>1?' · MVP: '+mv.n+' ('+mv.w+' abates)':'');
  for(const id in ST)ST[id].w=0;netBc({t:'ms',s:m});setTimeout(()=>toast(m),80)}
const objPack=()=>[OBJ.ty,Math.round(OBJ.x),Math.round(OBJ.z),+OBJ.p.toFixed(1),OBJ.g,Math.round(OBJ.t),OBJ.done];
const objApply=o=>{OBJ={ty:o[0],x:o[1],z:o[2],p:o[3],g:o[4],t:o[5],done:o[6]}};
const stPack=()=>{stOf('host').n=curNick();return Object.keys(ST).map(id=>{const s=ST[id];return[id,s.n,s.k,Math.round(s.d),s.c,s.a,s.r]})};
function stApply(L){ST={};for(const r of L)ST[r[0]]={n:r[1],k:r[2],d:r[3],c:r[4],a:r[5],r:r[6],w:0};const me=ST[NET.me];if(me){UP.a=me.a;UP.r=me.r}}
const allyRingM=new THREE.MeshBasicMaterial({color:0x46ff8a,transparent:true,opacity:.8,side:THREE.DoubleSide,depthWrite:false}),allyRingG={};
/* aliados (time do jogador e amigos online) ganham um anel verde brilhante em volta, para ninguém atirar neles */
function allyRings(){
  allyRingM.opacity=.65+.25*Math.sin(performance.now()/250);
  for(const t of tanks){if(t.isPlayer||!t.g||t.air)continue;const al=t.team===0&&!t.dead;
    if(al&&!t.aRing){const R=Math.round((Math.max(t.L||3,(t.W||1.8)*1.4)+1.5)*4)/4,geo=allyRingG[R]||(allyRingG[R]=new THREE.RingGeometry(R-.55,R,40).rotateX(-Math.PI/2));const m=new THREE.Mesh(geo,allyRingM);m.position.y=.3;m.renderOrder=3;t.g.add(m);t.aRing=m}
    else if(!al&&t.aRing){t.g.remove(t.aRing);t.aRing=null}}
}
function objTick(dt){
  if(!started)return;
  allyRings();
  pbtn.classList.toggle('on',!player.dead&&pauseEl.classList.contains('hide')&&document.getElementById('start').classList.contains('hide')&&document.getElementById('over').classList.contains('hide'));
  if(wave!==lw||kills!==lk){lw=wave;lk=kills;flashScore()}
  {let bt=null;for(const t of tanks)if(t.boss&&!t.dead){bt=t;break}const be=document.getElementById('boss');if(bt){be.style.display='block';be.firstChild.textContent='☠ CHEFE · '+vname(bt);be.lastChild.firstChild.style.width=clamp(bt.hp/mhpOf(bt),0,1)*100+'%'}else be.style.display='none'}
  if(!NET.guest&&OBJ.ty>=0&&!OBJ.done){
    if(OBJ.ty===0){let n=0;for(const t of tanks)if((t.isPlayer||t.remote)&&!t.dead&&Math.hypot(t.x-OBJ.x,t.z-OBJ.z)<24)n++;if(n){OBJ.p+=dt*(1+.25*(n-1));if(OBJ.p>=OBJ.g)objDone()}}
    else OBJ.t=Math.max(0,OBJ.t-dt)}
  const el=document.getElementById('obj');
  if(OBJ.ty<0){el.style.display='none';if(objM)objM.visible=false}
  else{
    {const key=OBJ.x+','+OBJ.z;if(OBJ.ty===0&&key!==objKey){objKey=key;objBuild()}}
    if(objM){objM.visible=OBJ.ty===0;objRing.color.set(OBJ.done?0x3fd25a:0xffd400);objBeam.visible=!OBJ.done}
    let h;if(OBJ.ty===0){if(OBJ.done)h='✔ Zona dominada';else{const a=angDiff(Math.atan2(OBJ.x-player.x,OBJ.z-player.z),player.yaw);h='Segure a zona: '+(OBJ.p|0)+'/'+(OBJ.g|0)+' s · '+Math.round(Math.hypot(OBJ.x-player.x,OBJ.z-player.z))+' m <span style="display:inline-block;transform:rotate('+(-a*57.3).toFixed(0)+'deg)">▲</span>'}}
    else h=OBJ.done?'✔ Relâmpago cumprido':OBJ.t>0?'Relâmpago: limpe a onda em '+OBJ.t+' s':'Relâmpago: tempo esgotado';
    if(h!==objCache){objCache=h;el.innerHTML=h}el.style.display='block'}
  sbT-=dt;if(sbT>0)return;sbT=.25;
  const me=NET.guest?NET.me:'host';stOf('host');const L=Object.keys(ST).sort((a,b)=>ST[b].k-ST[a].k),sb=document.getElementById('sb');
  sb.innerHTML=L.map(id=>{const s=ST[id];return'<div style="color:'+(id===me?'#ffd27a':'#fff')+'"><span>'+s.n+'</span><span>✕'+s.k+' · '+Math.round(s.d)+'</span></div>'}).join('');sb.style.display='block';
  const m=ST[me];
  if(m){if(lc>=0&&m.c>lc)flashSb();lc=m.c}
}
let objKey='',objRing=null,objBeam=null,zonaB=[],zRings=[];
function conformRings(){for(const m of zRings){const p=m.geometry.attributes.position,X=m.position.x,Z=m.position.z;for(let v=0;v<p.count;v++)p.setZ(v,getH(X+p.getX(v),Z-p.getY(v))+.18);p.needsUpdate=true;m.geometry.computeBoundingSphere()}}
function objBuild(){
  if(objM)scene.remove(objM);const g=new THREE.Group(),X=OBJ.x,Z=OBJ.z,R=24,RF=R+3,RB=R+13;
  let sum=getH(X,Z),cnt=1;for(let i=0;i<16;i++){const a=i/16*6.283;for(const f of[1,.5]){sum+=getH(X+Math.cos(a)*R*f,Z+Math.sin(a)*R*f);cnt++}}
  const top=sum/cnt+.25;
  for(const e of zonaB){const bi=buildings.indexOf(e);if(bi>=0)buildings.splice(bi,1);scene.remove(e.m)}zonaB=[];
  /* limpa o terreno da zona e nivela: o veículo anda por cima do concreto, que as crateras destroem */
  for(let i=buildings.length-1;i>=0;i--){const b=buildings[i];if(Math.hypot(b.x-X,b.z-Z)<RF+Math.max(b.w,b.d)/2){scene.remove(b.m);buildings.splice(i,1)}}
  const i0=Math.max(0,Math.floor((X-RB+HALF)/CELL)),i1=Math.min(N,Math.ceil((X+RB+HALF)/CELL)),j0=Math.max(0,Math.floor((Z-RB+HALF)/CELL)),j1=Math.min(N,Math.ceil((Z+RB+HALF)/CELL));
  for(let j=j0;j<=j1;j++)for(let i=i0;i<=i1;i++){const k=j*(N+1)+i,d=Math.hypot(i*CELL-HALF-X,j*CELL-HALF-Z);if(d>RB)continue;
    const w=d<=RF?1:1-sm(RF,RB,d);H[k]=H[k]*(1-w)+top*w;S[k]*=1-w;Rd[k]*=1-w;Zc[k]=Math.max(Zc[k],clamp((R+2-d)/3,0,1))}
  refresh(i0,i1,j0,j1);
  for(let i=trees.length-1;i>=0;i--){const q=trees[i],d=Math.hypot(q.x-X,q.z-Z);if(d<RB&&(d<R+2||Math.abs(q.g.position.y-getH(q.x,q.z))>.6)){scene.remove(q.g);trees.splice(i,1)}}
  for(let i=props.length-1;i>=0;i--){const q=props[i],d=Math.hypot(q.x-X,q.z-Z);if(d<RB&&(d<R+2||Math.abs(q.g.position.y-getH(q.x,q.z))>.6)){scene.remove(q.g);props.splice(i,1)}}
  objRing=new THREE.MeshBasicMaterial({color:0xffd400,side:THREE.DoubleSide});
  const rg=new THREE.Mesh(new THREE.RingGeometry(R-2.4,R-.8,64,1),objRing),cr=new THREE.Mesh(new THREE.RingGeometry(5,5.7,40,1),new THREE.MeshBasicMaterial({color:0xeeeeee,side:THREE.DoubleSide}));
  for(const m of[rg,cr]){m.rotation.x=-Math.PI/2;m.position.set(X,0,Z);g.add(m)}
  zRings=[rg,cr];conformRings();
  /* cerca fechada: 24 postes a cada ~6,4 m (colisão de tanque cobre o vão) e dois portões; cada poste é destrutível */
  const org=new THREE.MeshBasicMaterial({color:0xff7a1a}),NP=24,P=[];
  for(let i=0;i<NP;i++){const a=i*2*Math.PI/NP;P.push(i===0||i===NP/2?null:[X+Math.cos(a)*(R+.5),Z+Math.sin(a)*(R+.5)])}
  for(let i=0;i<NP;i++){if(!P[i])continue;const[x,z]=P[i],base=getH(x,z)-2,ph=top+10-base,pm=lm(0x3b3f45),pg=new THREE.Group();
    const col=new THREE.Mesh(new THREE.BoxGeometry(1.3,ph,1.3),pm);col.position.y=ph/2;pg.add(col);
    const cap=new THREE.Mesh(new THREE.BoxGeometry(2,.6,2),org);cap.position.y=top+10.3-base;pg.add(cap);
    const ft=new THREE.Mesh(new THREE.BoxGeometry(2.4,1,2.4),pm);ft.position.y=top+.2-base;pg.add(ft);
    for(const nb of[1,NP-1]){const Q=P[(i+nb)%NP];if(!Q)continue;const dx=Q[0]-x,dz=Q[1]-z,len=Math.hypot(dx,dz);
      for(const hy of[9,5,2.2]){const bm=new THREE.Mesh(new THREE.BoxGeometry(len/2,.55,.55),pm);bm.position.set(dx/4,top+hy-base,dz/4);bm.rotation.y=-Math.atan2(dz,dx);pg.add(bm)}}
    pg.position.set(x,base,z);pg.traverse(m=>{if(m.isMesh)m.castShadow=true});scene.add(pg);
    const e={m:pg,x,z,w:2.4,d:2.4,h:ph,y:base,hp:70,hp0:70,base:35,base0:35,stilt:false,color:0x3b3f45,mats:[pm],type:'zona',nb:3};buildings.push(e);zonaB.push(e)}
  objBeam=new THREE.Mesh(new THREE.CylinderGeometry(.7,.7,90,8),new THREE.MeshBasicMaterial({color:0xffd400,transparent:true,opacity:.3,depthWrite:false}));objBeam.position.set(X,top+45,Z);g.add(objBeam);
  scene.add(g);objM=g}
{const _cr=crater;crater=function(x,z,R,d){_cr(x,z,R,d);if(objM&&zRings.length&&Math.hypot(x-OBJ.x,z-OBJ.z)<R+30)conformRings()}}
const BOSS=[makeMaus,makeArmata,makeMerk,makeT90,makeTiger,makeAbrams,makeCh2];
function spawnBoss(){
  if(NET.guest)return;const mkf=BOSS[(wave-1)%BOSS.length];
  for(let k=0;k<150;k++){const zc=zoneOf(1),a=Math.random()*6.28,r=8+Math.random()*40,x=zc.x+Math.cos(a)*r,z=zc.z+Math.sin(a)*r;
    if(!spawnOK(x,z,16)||Math.hypot(x-player.x,z-player.z)<90)continue;
    let q;try{q=mkf(0x6a1f1f,0xff2a2a)}catch(e){continue}
    q.hp=300+110*wave;mhpOf(q);q.boss=1;q.armor=(q.armor||1)*.75;q.g.scale.setScalar(1.2);
    q.team=1;q.x=x;q.z=z;q.hd=q.yaw=Math.random()*6.28;q.ai=true;q.cd=3+Math.random()*3;
    for(let i=0;i<16;i++)puff(new THREE.Vector3(x,getH(x,z)+2,z),i%2?0xff2a2a:0x2b2a28,3,6,2,4);
    toast('☠ O CHEFE chegou à onda '+wave);return}
}
function flashScore(){const e=document.getElementById('score');e.classList.add('show');clearTimeout(flashScore.k);flashScore.k=setTimeout(()=>e.classList.remove('show'),3200)}
function flashSb(){const e=document.getElementById('sb');e.classList.add('show');clearTimeout(flashSb.k);flashSb.k=setTimeout(()=>e.classList.remove('show'),4000)}
let lw=-1,lk=-1,lc=-1;
{const _sw=spawnWave;spawnWave=function(){_sw();objNew();spawnBoss()}}
{const _nt=netTick;netTick=function(dt){objTick(dt);_nt(dt)}}
/* ---------- online co-op (WebRTC via PeerJS): o anfitriao simula a partida inteira; cada convidado dirige o proprio blindado e recebe o estado do mundo ---------- */
Math.random=RNG0;
let peerObj=null;
function netMsg(s){const e=document.getElementById('nmsg');if(e)e.textContent=s}
function netLoad(cb){if(window.Peer)return cb();const s=document.createElement('script');s.src='https://cdn.jsdelivr.net/npm/peerjs@1.5.4/dist/peerjs.min.js';s.onload=cb;s.onerror=()=>netMsg('Não foi possível carregar o PeerJS: confira a internet.');document.head.appendChild(s)}
function netBc(m,ex){for(const c of NET.conns)if(c.open&&c.peer!==ex)try{c.send(m)}catch(e){}}
function netSend(m){if(NET.up&&NET.up.open)try{NET.up.send(m)}catch(e){}}
function netOK(){if(!window.RTCPeerConnection){netMsg('Este navegador ou ambiente não permite WebRTC (modo online). Abra o arquivo direto no Chrome, Edge ou Firefox.');return false}if(location.protocol==='blob:'||window.top!==window.self){netMsg('Aviso: a página parece estar dentro de uma janela de pré-visualização, que costuma bloquear a rede. Se travar, salve o arquivo e abra direto no navegador.')}return true}
function netHost(){
  if(NET.on||!netOK())return;NET.on=1;NET.host=1;location.hash='sala='+NET.code;netMsg('Criando a sala…');
  netLoad(()=>{const p=peerObj=new Peer('blindados-'+NET.code);
    clearTimeout(NET.to);NET.to=setTimeout(()=>{if(!p.open)netMsg('Sem resposta do servidor de conexão (0.peerjs.com). Verifique a internet ou se o ambiente bloqueia a rede.')},10000);
    p.on('open',()=>{clearTimeout(NET.to);const f=!/^https?:$/.test(location.protocol),u=location.href.split('#')[0]+'#sala='+NET.code+'&g=1';netMsg(f?'Sala '+NET.code+' pronta. Peça para seus amigos abrirem este mesmo jogo, digitarem o código '+NET.code+' e tocarem em Entrar.':'Sala '+NET.code+' pronta. Link dos amigos (copiado): '+u);if(!f)try{navigator.clipboard.writeText(u)}catch(e){}});
    p.on('error',e=>{netMsg('Erro na sala: '+(e.type||e)+(e.type==='unavailable-id'?' (recarregue a página)':''));if(!NET.conns.length){NET.on=0;NET.host=0}});
    p.on('connection',c=>{NET.conns.push(c);c.on('open',()=>netMsg('Sala '+NET.code+': '+NET.conns.filter(x=>x.open).length+' amigo(s) conectado(s)'));
      c.on('data',m=>netHostData(c,m));
      c.on('close',()=>{NET.conns=NET.conns.filter(x=>x!==c);const q=NET.remotes[c.peer];if(q){scene.remove(q.g);const i=tanks.indexOf(q);if(i>=0)tanks.splice(i,1);delete NET.remotes[c.peer]}delete ST[c.peer];toast('Um jogador saiu da sala')})})});
}
function netJoin(code){
  code=(code||'').toUpperCase().trim();
  if(code){if(!/^[A-Z0-9]{4,6}$/.test(code)){netMsg('Código inválido: use de 4 a 6 letras ou números.');return}if(NET.on&&NET.code!==code){netMsg('Você já está em uma sala.');return}if(!NET.on)NET.code=code}
  if(NET.on||!netOK())return;NET.on=1;NET.guest=1;netMsg('Conectando à sala '+NET.code+'…');
  netLoad(()=>{const p=peerObj=new Peer();p.on('error',e=>netMsg('Erro: '+(e.type||e)+(e.type==='peer-unavailable'?' (a sala não existe: o anfitrião precisa clicar em Criar sala antes)':'')));setTimeout(()=>{if(!p.open)netMsg('Sem resposta do servidor de conexão (0.peerjs.com). Verifique a internet ou se o ambiente bloqueia a rede.')},10000);
    p.on('open',id=>{NET.me=id;const c=NET.up=p.connect('blindados-'+NET.code,{reliable:true,serialization:'json'});
      c.on('open',()=>netMsg('Conectado à sala '+NET.code+'. Escolha o veículo e clique em Jogar.'));
      c.on('data',netGuestData);c.on('close',()=>{toast('Sala encerrada pelo anfitrião');netMsg('Desconectado da sala')});
      setTimeout(()=>{if(!c.open)netMsg('Sala não encontrada: confira o código e se o anfitrião já criou a sala.')},9000)})});
}
function netHostData(c,m){
  if(!m)return;let q=NET.remotes[c.peer];
  if(m.t==='hi'){
    if(q){q.remote=0;if(!q.dead){scene.remove(q.g);const i=tanks.indexOf(q);if(i>=0)tanks.splice(i,1)}}
    let r;try{noCust=1;try{r=VEH[VEH[m.veh]?m.veh:'tank']()}finally{noCust=0}}catch(e){r=makeTank(0x5b6b3a)}
    const b=player.dead?(q||player):player;let x=b.x,z=b.z;
    for(let k=0;k<40;k++){const a=Math.random()*6.28,d=10+Math.random()*14,X=b.x+Math.cos(a)*d,Z=b.z+Math.sin(a)*d;if(spawnOK(X,Z,6)){x=X;z=Z;break}}
    r.team=0;r.x=x;r.z=z;r.hd=r.yaw=b.hd||0;r.remote=c.peer;r.nid=++NET.seq;NET.remotes[c.peer]=r;mhpOf(r);if(r.corv)toSea(r);place(r);
    {const s=stOf(c.peer);s.n=String(m.nick||'Aliado').replace(/[<>&"]/g,'').slice(0,12);r.nick=s.n;r.upA=s.a;if(m.cust)applyCust(r,String(m.cust).slice(0,40))}c.send({t:'sp',x,z,hd:r.hd});toast('Um amigo entrou na batalha');return}
  if(!q)return;
  if(m.t==='st'){if(q.dead)return;q.tx=m.x;q.tz=m.z;q.thd=m.hd;q.tyaw=m.yaw;q.tp=m.p;q.v=m.v;q.st=m.s;if(q.air){q.alt=m.a;q.pit=m.pi;q.rol=m.ro}}
  else if(m.t==='fi'){if(!q.dead&&started){q.cd=0;fire(q)}}
  else if(m.t==='rep'){if(!q.dead){q.hp=Math.min(mhpOf(q),q.hp+mhpOf(q)*.45);if(q.cp)cpRepair(q)}}
}
function netGuestData(m){
  if(!m)return;
  if(m.t==='sn')netApply(m);
  else if(m.t==='sp'){if(started){player.x=m.x;player.z=m.z;player.hd=player.yaw=m.hd;if(player.corv)toSea(player);place(player);camUpdate()}}
  else if(m.t==='ms')toast(m.s);
  else if(m.t==='fi'){const q=NET.px[m.n];if(q&&!q.dead){q.cd=0;fire(q)}}
}
function netSnap(){
  const T=[];for(const t of tanks){if(!t.mkn)continue;const n=t.nid||(t.nid=++NET.seq);
    T.push([n,t.mkn,t.cc||0,t.fc||0,t.team||0,t.ally?1:0,+t.x.toFixed(2),+t.z.toFixed(2),+t.hd.toFixed(3),+t.yaw.toFixed(3),+t.pitch.toFixed(3),+t.v.toFixed(2),+(t.st||0).toFixed(2),Math.round(t.hp),t.dead?1:0,t.remote||0,t.air?+(t.alt||0).toFixed(1):0,+(t.pit||0).toFixed(2),+(t.rol||0).toFixed(2),Math.round(mhpOf(t)),t.isPlayer?curNick():(t.nick||''),t.cs||'',t.boss?1:0])}
  netBc({t:'sn',w:wave,k:kills,T,O:objPack(),S:stPack()});
}
function netApply(m){
  if(m.O)objApply(m.O);if(m.S)stApply(m.S);wave=m.w;kills=m.k;document.getElementById('wv').textContent=wave;document.getElementById('kl').textContent=kills;
  const seen=new Set();
  for(const r of m.T){const[n,mk,cc,fc,tm,al,x,z,hd,yaw,pt,v,st,hp,dead,rem,alt,pit,rol,mh,nk,cs,bs]=r;
    if(rem&&rem===NET.me){if(started&&!player.dead){if(hp<player.hp-.5){hurt=1;shake=Math.max(shake,.4)}player.hp=hp;player.mhp=mh;if(dead){NET.f=1;hpCore(player,1e9);NET.f=0}}continue}
    seen.add(n);let q=NET.px[n];
    if(!q){if(!/^make/.test(mk)||typeof window[mk]!=='function')continue;try{q=window[mk](cc||undefined,fc||undefined)}catch(e){continue}
      q.nid=n;q.proxy=1;q.ai=false;q.x=x;q.z=z;q.hd=hd;q.yaw=yaw;q.mhp=mh;NET.px[n]=q}
    q.nick=nk;if(bs&&!q.boss){q.boss=1;q.g.scale.setScalar(1.2)}if(cs&&cs!==q.cs)applyCust(q,cs);q.tx=x;q.tz=z;q.thd=hd;q.tyaw=yaw;q.tp=pt;q.v=v;q.st=st;q.team=tm;q.ally=!!al;q.hp=hp;if(q.air){q.alt=alt;q.pit=pit;q.rol=rol}
    if(dead&&!q.dead){q.dead=true;q.v=0;q.mat.color.set(0x1c1b19);for(let i=0;i<14;i++)puff(new THREE.Vector3(q.x,q.y+2,q.z),i%2?0x2b2a28:0xff8a1f,2.2,7,2.5,4)}}
  for(const n in NET.px)if(!seen.has(+n)){const q=NET.px[n];scene.remove(q.g);const i=tanks.indexOf(q);if(i>=0)tanks.splice(i,1);delete NET.px[n]}
}
function netSmooth(t,dt){
  if(Math.hypot(t.tx-t.x,t.tz-t.z)>40){t.x=t.tx;t.z=t.tz}
  const k=Math.min(1,dt*14);t.x+=(t.tx-t.x)*k;t.z+=(t.tz-t.z)*k;t.hd+=angDiff(t.thd,t.hd)*k;t.yaw+=angDiff(t.tyaw,t.yaw)*k;t.pitch+=(t.tp-t.pitch)*k;
}
function netTick(dt){
  if(!NET.on)return;NET.snapT-=dt;if(NET.snapT>0)return;
  if(NET.host){NET.snapT=.08;if(NET.conns.length)netSnap()}
  else if(NET.guest&&started&&!player.dead){NET.snapT=.05;const p=player;netSend({t:'st',x:+p.x.toFixed(2),z:+p.z.toFixed(2),hd:+p.hd.toFixed(3),yaw:+p.yaw.toFixed(3),p:+p.pitch.toFixed(3),v:+p.v.toFixed(2),s:+(p.st||0).toFixed(2),a:p.alt,pi:p.pit,ro:p.rol})}
}
/* renascer no co-op: novo blindado perto de onde caiu, sem reiniciar a partida dos outros */
function netRespawn(){
  const o=player;if(!o.dead){scene.remove(o.g);const i=tanks.indexOf(o);if(i>=0)tanks.splice(i,1)}
  try{player=VEH[curV]()}catch(e){showErr('modelo '+curV,e);player=makeTank(0x5b6b3a)}
  player.isPlayer=true;player.upA=UP.a;player.x=o.x+(Math.random()-.5)*10;player.z=o.z+(Math.random()-.5)*10;player.hd=player.yaw=o.hd;
  if(player.corv)toSea(player);place(player);camUpdate();hurt=0;shake=0;firing=false;zoomOn=false;aimLock=null;mhpOf(player);
  document.getElementById('over').classList.add('hide');running=true;
  try{const r=renderer.domElement.requestPointerLock();if(r&&r.catch)r.catch(()=>{})}catch(e){}
  if(NET.guest)netSend({t:'hi',nick:curNick(),cust:custStr(),veh:curV});toast('Você voltou à batalha');
}
{const hb=document.getElementById('nhost'),jb=document.getElementById('njoin'),ci=document.getElementById('ncode');
  ci.addEventListener('keydown',e=>e.stopPropagation());ci.addEventListener('keyup',e=>e.stopPropagation());
  hb.onclick=netHost;jb.onclick=()=>netJoin(ci.value);
  renderer.domElement.addEventListener('click',()=>{if(NET.on&&running&&!locked)try{renderer.domElement.requestPointerLock()}catch(e){}});
  if(/g=1/.test(location.hash))netJoin('')}
{const l=document.getElementById('ldg');l&&l.remove()}requestAnimationFrame(loop);

