document.addEventListener("DOMContentLoaded", function () {
  const PREFIX = "civil3_attendance_";

  const dateInput = document.getElementById("sheetDate");
  const loadButton = document.getElementById("loadSheetBtn");
  const printButton = document.getElementById("printSheetBtn");
  const message = document.getElementById("sheetMessage");
  const tableBody = document.getElementById("sheetTableBody");

  const printedDate = document.getElementById("printedDate");
  const totalCount = document.getElementById("totalCount");
  const presentCount = document.getElementById("presentCount");
  const absentCount = document.getElementById("absentCount");

  if (!dateInput || !loadButton || !printButton || !tableBody) {
    console.error("Attendance Sheet HTML elements are missing.");
    return;
  }

  // Golden button styling
  [loadButton, printButton].forEach(function (button) {
    button.style.background = "#a9854f";
    button.style.color = "#ffffff";
    button.style.border = "1px solid #826238";
    button.style.borderRadius = "10px";
    button.style.padding = "12px 18px";
    button.style.fontWeight = "600";
    button.style.cursor = "pointer";
  });

  function todayString() {
    const now = new Date();

    return [
      now.getFullYear(),
      String(now.getMonth() + 1).padStart(2, "0"),
      String(now.getDate()).padStart(2, "0")
    ].join("-");
  }

  function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, function (character) {
      return {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
      }[character];
    });
  }

  function formatDate(dateString) {
    const parts = dateString.split("-");
    return parts.length === 3
      ? `${parts[2]}-${parts[1]}-${parts[0]}`
      : dateString;
  }

  function getStudents() {
    return Array.isArray(window.STUDENTS) ? window.STUDENTS : [];
  }

  function getAttendance(date) {
    const raw = localStorage.getItem(PREFIX + date);

    if (!raw) return null;

    try {
      const record = JSON.parse(raw);

      if (!record || typeof record !== "object") return null;

      if (record.statuses && typeof record.statuses === "object") {
        return record.statuses;
      }

      const oldStatuses = {};

      Object.entries(record).forEach(function ([id, status]) {
        if (status === "P" || status === "A") {
          oldStatuses[id] = status;
        }
      });

      return oldStatuses;
    } catch (error) {
      console.error("Could not read attendance:", error);
      return null;
    }
  }

  function renderSheet() {
    const date = dateInput.value;
    const students = getStudents();

    if (!date) {
      message.textContent = "Please select a date.";
      return false;
    }

    if (date > todayString()) {
      dateInput.value = todayString();
      message.textContent = "Future dates are not allowed.";
      return false;
    }

    printedDate.textContent = "Date: " + formatDate(date);

    if (students.length === 0) {
      tableBody.innerHTML =
        '<tr><td colspan="3">No students found.</td></tr>';

      totalCount.textContent = "0";
      presentCount.textContent = "0";
      absentCount.textContent = "0";

      message.textContent = "Student list could not be loaded.";
      return false;
    }

    const statuses = getAttendance(date);

    let present = 0;
    let absent = 0;
    let unmarked = 0;

    tableBody.innerHTML = students.map(function (student, index) {
      const status = statuses
        ? statuses[String(student.id)]
        : undefined;

      let label = "Not Marked";

      if (status === "P") {
        label = "Present";
        present++;
      } else if (status === "A") {
        label = "Absent";
        absent++;
      } else {
        unmarked++;
      }

      return `
        <tr>
          <td>${index + 1}</td>
          <td>${escapeHTML(student.name)}</td>
          <td>${label}</td>
        </tr>
      `;
    }).join("");

    totalCount.textContent = students.length;
    presentCount.textContent = present;
    absentCount.textContent = absent;

    if (!statuses) {
      message.textContent =
        "No saved attendance found for this date.";
    } else if (unmarked > 0) {
      message.textContent =
        `${unmarked} student(s) are not marked.`;
    } else {
      message.textContent = "Attendance sheet is ready to print.";
    }

    return Boolean(statuses) && unmarked === 0;
  }

  dateInput.max = todayString();

  if (!dateInput.value) {
    dateInput.value = todayString();
  }

  loadButton.addEventListener("click", function () {
    renderSheet();
  });

  dateInput.addEventListener("change", function () {
    renderSheet();
  });

  printButton.addEventListener("click", function () {
    renderSheet();

    // Open the print dialog directly so the button works
    // even when some attendance marks are still missing.
    try {
      window.print();
    } catch (error) {
      console.error("Print dialog could not open:", error);
      message.textContent =
        "Printing is unavailable in this browser preview. Open the page in your browser and try again.";
    }
  });

  renderSheet();

  console.log("Attendance Sheet initialized.");
});