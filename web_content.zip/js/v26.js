/* UNKNOWN X V26 — Orion Store: outfits, companions and gameplay perks. */
(function(){"use strict";
const items=[
{id:"starter",type:"outfit",name:"زي المستكشف الأساسي",desc:"الزي الأصلي للمغامرات الأولى.",cost:0,icon:"🧥"},
{id:"neon",type:"outfit",name:"بدلة النيون",desc:"بدلة مضيئة مستوحاة من شوارع أوريون.",cost:45,icon:"🦺"},
{id:"shadow",type:"outfit",name:"عباءة الظلال",desc:"مظهر غامض للمستكشفين أصحاب الاكتشافات.",cost:85,icon:"🥷"},
{id:"astral",type:"outfit",name:"درع النجوم",desc:"زي نادر يحمل شارة المجرّة البعيدة.",cost:140,icon:"🛡️"},
{id:"layan",type:"companion",name:"ليان · المرشدة",desc:"ترافقك وتساعدك على فهم مسارات الألغاز.",cost:90,icon:"🧭",skillName:"عين المستكشفة",skill:"تمنحك +5 XP إضافية عند إكمال كل تحدٍ جديد."},
{id:"adam",type:"companion",name:"آدم · المهندس",desc:"خبير أدوات يحوّل التلميحات إلى مساعدة فعّالة.",cost:110,icon:"🛠️",skillName:"تحليل ذكي",skill:"استعمل التلميح من غير خسارة نقاط المكافأة."},
{id:"noor",type:"companion",name:"نور · محللة الأدلة",desc:"تلاحظ التفاصيل التي قد تفوتك أثناء التحقيق.",cost:125,icon:"🔎",skillName:"ملاحظة تلقائية",skill:"بعد محاولتين غير صحيحتين، تعرض لك تلميحاً تلقائياً."}
];
function normalize(s){if(!s.v26||typeof s.v26!=="object"||Array.isArray(s.v26))s.v26={};const v=s.v26;v.owned=Array.isArray(v.owned)?[...new Set(v.owned.filter(id=>items.some(x=>x.id===id&&id!=="starter")))]:[];v.outfit=items.some(x=>x.id===v.outfit&&x.type==="outfit"&&(x.id==="starter"||v.owned.includes(x.id)))?v.outfit:"starter";v.companion=items.some(x=>x.id===v.companion&&x.type==="companion"&&v.owned.includes(x.id))?v.companion:"none";return v}
function active(s){const v=normalize(s);return items.find(x=>x.id===v.companion)||null}
function purchaseOrEquip(s,id){const item=items.find(x=>x.id===id);if(!item)return{status:"invalid"};const v=normalize(s),owned=id==="starter"||v.owned.includes(id);if(!owned){if((Number(s.xp)||0)<item.cost)return{status:"funds",item};s.xp-=item.cost;v.owned.push(id);if(item.type==="outfit")v.outfit=id;else v.companion=id;return{status:"bought",item}}if(item.type==="outfit")v.outfit=id;else v.companion=id;return{status:"equipped",item}}
const api={items,normalize,active,purchaseOrEquip};if(typeof module!=="undefined"&&module.exports)module.exports=api;if(typeof window!=="undefined")window.V26=api;
})();
