/* OPERATION: DISCIPLINE — utilitários puros (datas, validação, escape, hash). Sem DOM. */
(function(){'use strict';
var G=typeof globalThis!=='undefined'?globalThis:window,OD=G.OD=G.OD||{};
var has=function(o,k){return Object.prototype.hasOwnProperty.call(o,k)};
var E=function(m){throw new Error(m)};
var iso=function(d){return new Date(d.getTime()-d.getTimezoneOffset()*6e4).toISOString().slice(0,10)};
var add=function(s,n){var d=new Date(s+'T12:00:00');d.setDate(d.getDate()+n);return iso(d)};
var validDate=function(d){if(typeof d!=='string'||!/^\d{4}-\d\d-\d\d$/.test(d)||d<'2000-01-01'||d>'2100-12-31')return false;var t=new Date(d+'T12:00:00');return !isNaN(t)&&iso(t)===d};
var validTime=function(t){return typeof t==='string'&&/^([01]\d|2[0-3]):[0-5]\d$/.test(t)};
var wkStart=function(t){return add(t,-((new Date(t+'T12:00:00').getDay()+6)%7))};
var isO=function(x){return !!x&&typeof x==='object'&&!Array.isArray(x)};
var isInt=function(x){return Number.isInteger(x)&&Math.abs(x)<=1e9};
var isTs=function(x){return Number.isInteger(x)&&x>=0&&x<=8.64e15};
var str=function(x,max){return typeof x==='string'&&x.length<=max};
/* djb2 (32 bits): mantido por compatibilidade com backups v1/v2. */
var hash=function(s){var h=5381;for(var i=0;i<s.length;i++)h=(h*33^s.charCodeAt(i))>>>0;return h};
/* Checksum v3: djb2 + FNV-1a (64 bits no total). Detecta corrupção/edição acidental; NÃO é assinatura. */
var hash2=function(s){var a=5381,b=0x811c9dc5;for(var i=0;i<s.length;i++){var c=s.charCodeAt(i);a=(a*33^c)>>>0;b=Math.imul(b^c,16777619)>>>0}return 'h2:'+a.toString(16).padStart(8,'0')+b.toString(16).padStart(8,'0')};
var esc=function(t){return String(t).replace(/[&<>"'`\/]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;','`':'&#96;','/':'&#47;'}[c]})};
var clone=function(o){return JSON.parse(JSON.stringify(o))};
OD.U={has:has,E:E,iso:iso,add:add,validDate:validDate,validTime:validTime,wkStart:wkStart,isO:isO,isInt:isInt,isTs:isTs,str:str,hash:hash,hash2:hash2,esc:esc,clone:clone,MAXB:2097152};
})();
