/* UrbaAlerte — utilitaires (aucune dépendance externe) */
(function(w){
'use strict';
const P={
home:'M3 11l9-8 9 8M5 10v10h5v-6h4v6h5V10',map:'M9 4L3 6v14l6-2 6 2 6-2V4l-6 2-6-2zM9 4v14M15 6v14',plus:'M12 5v14M5 12h14',
clock:'M12 7v5l3 2M21 12a9 9 0 11-18 0 9 9 0 0118 0z',user:'M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2M12 11a4 4 0 100-8 4 4 0 000 8z',
bell:'M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 01-3.4 0',
camera:'M23 19a2 2 0 01-2 2H3a2 2 0 01-2-2V8a2 2 0 012-2h4l2-3h6l2 3h4a2 2 0 012 2zM12 17a4 4 0 100-8 4 4 0 000 8z',
video:'M23 7l-7 5 7 5zM3 5h11a2 2 0 012 2v10a2 2 0 01-2 2H3a2 2 0 01-2-2V7a2 2 0 012-2z',
pin:'M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 0118 0zM12 13a3 3 0 100-6 3 3 0 000 6z',
shield:'M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z',
wave:'M2 6c2-3 4-3 6 0s4 3 6 0 4-3 6 0M2 12c2-3 4-3 6 0s4 3 6 0 4-3 6 0M2 18c2-3 4-3 6 0s4 3 6 0 4-3 6 0',
flame:'M8.5 14.5A2.5 2.5 0 0011 12c0-1.4-.5-2-1-3-1.1-2.1-.2-4 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 11-14 0c0-1.2.4-2.4 1-3a2.5 2.5 0 002.5 2.5z',
bolt:'M13 2L3 14h9l-1 8 10-12h-9z',drop:'M12 2.7l5.7 5.6a8 8 0 11-11.4 0z',trash:'M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6M10 11v6M14 11v6',
car:'M5 17h14M3 13l2-6h14l2 6v5H3zM7 17v2M17 17v2M7.5 13.5h.01M16.5 13.5h.01',road:'M4 22L8 2M20 22L16 2M12 4v3M12 11v3M12 18v3',
mountain:'M2 20l7-13 4 7 3-4 6 10z',alert:'M10.3 3.9L1.8 18a2 2 0 001.7 3h17a2 2 0 001.7-3L13.7 3.9a2 2 0 00-3.4 0zM12 9v4M12 17h.01',
sms:'M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2zM8 9h8M8 13h5',wifioff:'M1 1l22 22M16.7 11.1A11 11 0 0121 13.5M5 12.6A11 11 0 0110.7 10M8.5 16.4a6 6 0 016.9-.9M12 20h.01',
check:'M20 6L9 17l-5-5',x:'M18 6L6 18M6 6l12 12',chev:'M9 18l6-6-6-6',chevl:'M15 18l-6-6 6-6',
locate:'M12 2v3M12 19v3M2 12h3M19 12h3M12 17a5 5 0 100-10 5 5 0 000 10z',layers:'M12 2L2 7l10 5 10-5zM2 17l10 5 10-5M2 12l10 5 10-5',
radar:'M19.1 4.9A10 10 0 112 12M15.5 8.5A5 5 0 1012 17M12 12l7-7',
phone:'M22 16.9v3a2 2 0 01-2.2 2 19.8 19.8 0 01-8.6-3.1 19.5 19.5 0 01-6-6A19.8 19.8 0 012.1 4.2 2 2 0 014.1 2h3a2 2 0 012 1.7c.1 1 .4 1.9.7 2.8a2 2 0 01-.5 2.1L8 9.9a16 16 0 006 6l1.3-1.3a2 2 0 012.1-.4c.9.3 1.8.6 2.8.7a2 2 0 011.7 2z',
lock:'M5 11h14v10H5zM8 11V7a4 4 0 018 0v4',eye:'M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12zM12 15a3 3 0 100-6 3 3 0 000 6z',
logout:'M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9',
settings:'M12 15a3 3 0 100-6 3 3 0 000 6zM4 12h2M18 12h2M12 4v2M12 18v2M6.3 6.3l1.4 1.4M16.3 16.3l1.4 1.4M6.3 17.7l1.4-1.4M16.3 7.7l1.4-1.4',
image:'M3 3h18v18H3zM8.5 10a1.5 1.5 0 100-3 1.5 1.5 0 000 3zM21 15l-5-5L5 21',send:'M22 2L11 13M22 2l-7 20-4-9-9-4z',
refresh:'M23 4v6h-6M1 20v-6h6M3.5 9a9 9 0 0114.9-3.4L23 10M1 14l4.6 4.4A9 9 0 0020.5 15',edit:'M12 20h9M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4z',
info:'M12 16v-4M12 8h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z',target:'M12 22a10 10 0 100-20 10 10 0 000 20zM12 18a6 6 0 100-12 6 6 0 000 12zM12 14a2 2 0 100-4 2 2 0 000 4z'};
w.IP=n=>P[n]||P.info;
w.I=(n,cls)=>`<svg class="i ${cls||''}" viewBox="0 0 24 24" aria-hidden="true"><path d="${P[n]||P.info}"/></svg>`;
/* nomenclature (inspirée de la nomenclature du mémoire : voirie, érosion/inondation, réseaux, salubrité, sécurité) */
w.TYPES=[
 {id:'voirie',label:'Voirie dégradée',desc:'Nid-de-poule, route coupée',icon:'road',color:'#fbbf24',code:'VO',w:1.5},
 {id:'erosion',label:'Érosion / ravin',desc:'Glissement de terrain, ravin',icon:'mountain',color:'#ff8a3d',code:'ER',w:3,danger:true},
 {id:'inondation',label:'Inondation',desc:'Eau qui monte, caniveau bouché',icon:'wave',color:'#3b82f6',code:'IN',w:3,danger:true},
 {id:'eau',label:'Eau potable',desc:'Fuite, coupure de réseau',icon:'drop',color:'#22d3ee',code:'EA',w:1},
 {id:'electricite',label:'Électricité',desc:'Panne, câble tombé',icon:'bolt',color:'#a78bfa',code:'EL',w:1.2},
 {id:'salubrite',label:'Dépôt d’ordures',desc:'Décharge sauvage, salubrité',icon:'trash',color:'#34d399',code:'SA',w:1},
 {id:'accident',label:'Accident',desc:'Circulation, blessés',icon:'car',color:'#f472b6',code:'AC',w:2,danger:true},
 {id:'incendie',label:'Incendie',desc:'Feu, fumée',icon:'flame',color:'#ff4d6d',code:'IC',w:2.5,danger:true}];
w.TYPE=id=>TYPES.find(t=>t.id===id)||TYPES[0];
w.STATUTS=['EN_ATTENTE','VALIDE','AFFECTE','EN_COURS','RESOLU','CLOS'];
w.STATUT_LABEL={EN_ATTENTE:'En attente',VALIDE:'Validé',AFFECTE:'Affecté',EN_COURS:'En cours',RESOLU:'Résolu',CLOS:'Clos',REJETE:'Rejeté'};
const $=(s,r)=>(r||document).querySelector(s);const $$=(s,r)=>Array.from((r||document).querySelectorAll(s));
w.$=$;w.$$=$$;
w.esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
w.uid=()=>(crypto.randomUUID?crypto.randomUUID():'id'+Date.now().toString(36)+Math.random().toString(36).slice(2,10));
w.refCode=()=>'UA-'+Math.random().toString(36).slice(2,8).toUpperCase();
w.sleep=ms=>new Promise(r=>setTimeout(r,ms));
w.haversine=(a,b,c,d)=>{const R=6371,r=Math.PI/180,dl=(c-a)*r,dn=(d-b)*r,x=Math.sin(dl/2)**2+Math.cos(a*r)*Math.cos(c*r)*Math.sin(dn/2)**2;return 2*R*Math.asin(Math.sqrt(x))};
w.fmtKm=k=>k<1?Math.round(k*1000)+' m':k.toFixed(k<10?1:0).replace('.',',')+' km';
w.ago=t=>{const s=(Date.now()-t)/1000;if(s<60)return 'à l’instant';if(s<3600)return 'il y a '+Math.floor(s/60)+' min';if(s<86400)return 'il y a '+Math.floor(s/3600)+' h';if(s<86400*30)return 'il y a '+Math.floor(s/86400)+' j';return new Date(t).toLocaleDateString('fr-FR')};
w.fdate=t=>new Date(t).toLocaleString('fr-FR',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'});
/* téléphone RDC : 9 chiffres (8xx / 9xx) → +243… */
w.normPhone=v=>{let d=String(v||'').replace(/[^\d+]/g,'');if(d.startsWith('+243'))d=d.slice(4);else if(d.startsWith('00243'))d=d.slice(5);else if(d.startsWith('243')&&d.length>=12)d=d.slice(3);else if(d.startsWith('0'))d=d.slice(1);d=d.replace(/\D/g,'');return /^[89]\d{8}$/.test(d)?'+243'+d:null};
w.showPhone=p=>p?p.replace(/^(\+243)(\d{3})(\d{3})(\d{3})$/,'$1 $2 $3 $4'):'';
/* mot de passe : PBKDF2 (démo locale — le vrai contrôle se fera côté API) */
w.hashPwd=async(pwd,saltB64)=>{const enc=new TextEncoder();const salt=saltB64?Uint8Array.from(atob(saltB64),c=>c.charCodeAt(0)):crypto.getRandomValues(new Uint8Array(16));
 const key=await crypto.subtle.importKey('raw',enc.encode(pwd),'PBKDF2',false,['deriveBits']);const bits=await crypto.subtle.deriveBits({name:'PBKDF2',salt,iterations:100000,hash:'SHA-256'},key,256);
 const b64=a=>btoa(String.fromCharCode(...new Uint8Array(a)));return {salt:b64(salt),hash:b64(bits)}};
/* toasts */
w.toast=(msg,kind,ms,icon)=>{const box=$('#toasts');const t=document.createElement('div');t.className='toast '+(kind||'');t.innerHTML=(icon?`<span style="color:${kind==='alert'?'var(--amber)':kind==='bad'?'var(--bad)':kind==='ok'?'var(--ok)':'var(--cyan2)'}">${I(icon)}</span>`:'')+`<div style="flex:1;font-size:13.5px">${msg}</div>`;box.appendChild(t);setTimeout(()=>{t.style.transition='opacity .3s,transform .3s';t.style.opacity=0;t.style.transform='translateY(-10px)';setTimeout(()=>t.remove(),320)},ms||3600)};
/* feuilles modales */
w.sheet=(html,opts)=>{opts=opts||{};const v=$('#veil'),s=$('#sheet');s.innerHTML=`<div class="grab"></div>${opts.title?`<div class="hd"><h2>${opts.title}</h2><button class="iconbtn" data-close aria-label="Fermer">${I('x')}</button></div>`:''}<div class="body">${html}</div>`;v.classList.add('on');s.classList.add('on');s._onclose=opts.onclose;
 const close=()=>w.closeSheet();v.onclick=close;$$('[data-close]',s).forEach(b=>b.onclick=close);return s};
w.closeSheet=()=>{const v=$('#veil'),s=$('#sheet');v.classList.remove('on');s.classList.remove('on');const f=s._onclose;s._onclose=null;if(f)try{f()}catch(e){}};
w.vibrate=p=>{try{navigator.vibrate&&navigator.vibrate(p)}catch(e){}};
w.fileToImageBlob=(file,max)=>new Promise((res,rej)=>{const img=new Image();const u=URL.createObjectURL(file);img.onload=()=>{const k=Math.min(1,(max||1280)/Math.max(img.width,img.height));const c=document.createElement('canvas');c.width=Math.round(img.width*k);c.height=Math.round(img.height*k);c.getContext('2d').drawImage(img,0,0,c.width,c.height);c.toBlob(b=>{URL.revokeObjectURL(u);b?res(b):rej(new Error('compression'))},'image/jpeg',.82)};img.onerror=()=>{URL.revokeObjectURL(u);rej(new Error('image'))};img.src=u});
})(window);
