/* ===================================================================
 * VFL.Engine.Match
 * موتور شبیه‌سازی مسابقه.
 *
 * وزن عوامل (طبق مشخصات پروژه):
 *   Overall 40% | Tactics 15% | Form 10% | Fatigue 10% | Home 7%
 *   Substitutions 5% | Red Card 5% | Injury 3% | Luck 5%   (جمع = 100%)
 *
 * Overall/Tactics/Form/Fatigue/Home یک "امتیاز پیش از بازی" می‌سازند.
 * Substitutions/Red Card/Injury/Luck رویدادهای داینامیک داخل بازی هستند
 * که در طول ۹۰ دقیقه به‌صورت تصادفی رخ می‌دهند و روی نتیجه اثر می‌گذارند.
 *
 * این فایل هیچ وابستگی به DOM ندارد — فقط منطق شبیه‌سازی.
 * =================================================================== */
(function (VFL) {
  "use strict";

  VFL.Engine = VFL.Engine || {};

  // وزن‌های موتور (به‌روزرسانی‌شده طبق درخواست کاربر — جمع دقیقاً ۱۰۰٪)
  var WEIGHTS = {
    overall: 0.60,            // قدرت تیم
    tactics: 0.15,            // تاکتیک
    formEnergyFatigue: 0.10,  // فرم + انرژی/خستگی (یک دسته ترکیبی طبق درخواست جدید)
    home: 0.05,               // میزبانی
    substitutions: 0.03,      // تعویض و تغییرات تاکتیکی
    redCard: 0.03,            // کارت قرمز
    injury: 0.01,             // مصدومیت
    luck: 0.03                // شانس و اتفاقات غیرمنتظره
  };

  var TACTICS_BASELINE = 70; // بدون سیستم تاکتیک هنوز — مقدار خنثی یکسان برای هر دو تیم
  var LEAGUE_AVG_GOALS = 1.35; // میانگین گل هر تیم در هر بازی، برای کالیبره کردن مدل

  function rand() { return Math.random(); }
  function randInt(min, max) { return Math.floor(rand() * (max - min + 1)) + min; }
  function choice(arr) { return arr[randInt(0, arr.length - 1)]; }
  function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }

  // نمونه‌گیری پواسون (الگوریتم ناقص) برای تعداد گل مورد انتظار
  function poissonSample(lambda) {
    if (lambda <= 0) return 0;
    var L = Math.exp(-lambda), k = 0, p = 1;
    do { k++; p *= rand(); } while (p > L);
    return k - 1;
  }

  function weightedPick(items, weightFn) {
    var total = 0;
    for (var i = 0; i < items.length; i++) total += Math.max(0.01, weightFn(items[i]));
    var r = rand() * total;
    for (var j = 0; j < items.length; j++) {
      r -= Math.max(0.01, weightFn(items[j]));
      if (r <= 0) return items[j];
    }
    return items[items.length - 1];
  }

  var ATTACK_POS = { CF: 5, SS: 4.5, LW: 4, RW: 4, AM: 3.5, CM: 2, LM: 2, RM: 2, DM: 1, CB: 0.4, LB: 0.6, RB: 0.6, GK: 0 };
  var CREATIVE_POS = { AM: 5, CM: 4, LM: 3, RM: 3, LW: 3.5, RW: 3.5, CF: 2, SS: 2.5, DM: 2, CB: 0.3, LB: 1, RB: 1, GK: 0 };

  // ---------------------------------------------------------------
  // آماده‌سازی ترکیب تیم (۱۱ بازیکن برتر) در صورت وجود دیتابیس بازیکن
  // ---------------------------------------------------------------
  function pickLineup(squad, customLineup) {
    if (!squad || squad.length === 0) return null;

    // اگر کاربر ترکیب اصلی/نیمکت را دستی چیده باشد، همان استفاده می‌شود
    if (customLineup && customLineup.starters && customLineup.starters.length > 0) {
      var byId = {};
      squad.forEach(function (p) { byId[p.id] = p; });
      var starters = customLineup.starters.map(function (id) { return byId[id]; }).filter(Boolean);
      if (starters.length > 0) {
        var benchIds = (customLineup.bench && customLineup.bench.length)
          ? customLineup.bench
          : squad.map(function (p) { return p.id; }).filter(function (id) { return customLineup.starters.indexOf(id) === -1; });
        var bench = benchIds.map(function (id) { return byId[id]; }).filter(Boolean).slice(0, 7);
        return { starters: starters, bench: bench };
      }
    }

    // در غیر این صورت، موتور به‌صورت خودکار ۱۱ بازیکن برتر بر اساس Overall را انتخاب می‌کند
    var sorted = squad.slice().sort(function (a, b) { return b.overall - a.overall; });
    var starters2 = sorted.slice(0, Math.min(11, sorted.length));
    var bench2 = sorted.slice(starters2.length, Math.min(starters2.length + 7, sorted.length));
    return { starters: starters2, bench: bench2 };
  }

  function effectiveOverall(teamStaticOverall, squad) {
    if (!squad || squad.length === 0) return teamStaticOverall;
    var top = squad.slice().sort(function (a, b) { return b.overall - a.overall; }).slice(0, 11);
    var sum = top.reduce(function (s, p) { return s + p.overall; }, 0);
    return sum / top.length;
  }

  function formToScore(formArray) {
    if (!formArray || formArray.length === 0) return 50; // خنثی برای اولین بازی فصل
    var pts = formArray.reduce(function (s, r) { return s + (r === "W" ? 3 : r === "D" ? 1 : 0); }, 0);
    return (pts / (formArray.length * 3)) * 100;
  }

  // ---------------------------------------------------------------
  // امتیاز ترکیبی پیش از بازی برای یک تیم (Overall+Tactics+Form+Fatigue+Home)
  // ---------------------------------------------------------------
  function preMatchScore(opts) {
    var fatigueScore = 100 - opts.fatiguePre;
    var formEnergyFatigueScore = (opts.form + fatigueScore) / 2;
    var homeScore = opts.isHome ? 100 : 50;
    return (
      opts.overall * WEIGHTS.overall +
      TACTICS_BASELINE * WEIGHTS.tactics +
      formEnergyFatigueScore * WEIGHTS.formEnergyFatigue +
      homeScore * WEIGHTS.home
    );
  }

  /**
   * شبیه‌سازی کامل یک مسابقه.
   * @param {Object} params
   *   home/away: { teamId, teamName, overall, squad (ممکن است null باشد), form (آرایه W/D/L), fatiguePre }
   * @returns {Object} گزارش کامل مسابقه
   */
  VFL.Engine.simulateMatch = function (params) {
    var home = params.home, away = params.away;

    var homeLineup = pickLineup(home.squad, home.customLineup);
    var awayLineup = pickLineup(away.squad, away.customLineup);

    var homeScore = preMatchScore({
      overall: effectiveOverall(home.overall, home.squad),
      form: formToScore(home.form), fatiguePre: home.fatiguePre || 0, isHome: true
    });
    var awayScore = preMatchScore({
      overall: effectiveOverall(away.overall, away.squad),
      form: formToScore(away.form), fatiguePre: away.fatiguePre || 0, isHome: false
    });

    // --- لاک (Luck) ۵٪ : نویز تصادفی مستقل برای هر تیم ---
    var homeLuck = 1 + (rand() * 2 - 1) * WEIGHTS.luck * 2; // تا ±10٪
    var awayLuck = 1 + (rand() * 2 - 1) * WEIGHTS.luck * 2;

    var timeline = [];
    var addEvent = function (minute, type, text, meta) {
      timeline.push({ minute: minute, type: type, text: text, meta: meta || null });
    };

    addEvent(0, "kickoff", "شروع بازی");

    // --- تعیین گل‌های مورد انتظار (xG) ---
    var strengthTotal = homeScore + awayScore;
    var homeShare = strengthTotal > 0 ? homeScore / strengthTotal : 0.5;
    var awayShare = 1 - homeShare;

    var homeXG = LEAGUE_AVG_GOALS * (homeShare * 2) * homeLuck;
    var awayXG = LEAGUE_AVG_GOALS * (awayShare * 2) * awayLuck;

    // --- کارت قرمز داینامیک ۵٪ ---
    var redCardTeams = { home: false, away: false };
    [{ side: "home", team: home, lineup: homeLineup }, { side: "away", team: away, lineup: awayLineup }].forEach(function (entry) {
      if (rand() < 0.08) { // ~۸٪ احتمال یک کارت قرمز در طول مسابقه برای هر تیم
        var minute = randInt(15, 88);
        var player = entry.lineup ? choice(entry.lineup.starters) : null;
        redCardTeams[entry.side] = true;
        addEvent(minute, "red_card",
          (player ? player.name : entry.team.teamName) + " اخراج شد", { side: entry.side, playerId: player ? player.id : null });
        // اخراج، xG تیم را برای باقی‌مانده بازی کاهش و تیم مقابل را کمی افزایش می‌دهد
        var remainingFactor = (90 - minute) / 90;
        if (entry.side === "home") { homeXG *= (1 - 0.35 * remainingFactor); awayXG *= (1 + 0.15 * remainingFactor); }
        else { awayXG *= (1 - 0.35 * remainingFactor); homeXG *= (1 + 0.15 * remainingFactor); }
      }
    });

    // --- مصدومیت داینامیک ۳٪ ---
    var injuredPlayers = [];
    [{ side: "home", team: home, lineup: homeLineup }, { side: "away", team: away, lineup: awayLineup }].forEach(function (entry) {
      if (entry.lineup && rand() < 0.20) {
        var minute = randInt(5, 85);
        var player = choice(entry.lineup.starters);
        injuredPlayers.push({ side: entry.side, playerId: player.id, minute: minute });
        addEvent(minute, "injury", player.name + " دچار مصدومیت شد", { side: entry.side, playerId: player.id });
        if (entry.lineup.bench.length > 0) {
          var sub = entry.lineup.bench.shift();
          addEvent(minute + 1, "substitution", "تعویض اجباری: " + sub.name + " به‌جای " + player.name, { side: entry.side, out: player.id, in: sub.id });
        }
      }
    });

    // --- تعویض‌های تاکتیکی ۵٪ (سه تعویض عادی هر تیم، دقیقه ۵۵ تا ۸۵) ---
    [{ side: "home", lineup: homeLineup }, { side: "away", lineup: awayLineup }].forEach(function (entry) {
      if (!entry.lineup) return;
      var subCount = Math.min(3, entry.lineup.bench.length);
      for (var i = 0; i < subCount; i++) {
        var minute = randInt(55, 85);
        var outPlayer = choice(entry.lineup.starters);
        var inPlayer = entry.lineup.bench.shift();
        if (!inPlayer) break;
        addEvent(minute, "substitution", "تعویض: " + inPlayer.name + " به‌جای " + outPlayer.name, { side: entry.side, out: outPlayer.id, in: inPlayer.id });
      }
    });

    homeXG = Math.max(0.1, homeXG);
    awayXG = Math.max(0.1, awayXG);

    var homeGoals = poissonSample(homeXG);
    var awayGoals = poissonSample(awayXG);

    // --- گل‌ها را در جدول زمانی پخش کن و گلزن/پاس‌گل تعیین کن ---
    function scorePlayerPool(lineup) {
      if (!lineup) return null;
      return lineup.starters.concat(lineup.bench.slice(0, 0)); // فقط بازیکنانی که در زمین بودند به‌طور ساده از starters
    }

    function recordGoal(side, teamMeta, lineup, minute) {
      var scorer = null, assist = null, ownGoal = false;
      if (lineup) {
        var pool = lineup.starters;
        // ~۳٪ احتمال گل به خودی از تیم مقابل
        if (rand() < 0.03) ownGoal = true;
        scorer = weightedPick(pool, function (pl) { return (ATTACK_POS[pl.position] || 1) * (pl.overall / 50); });
        if (rand() < 0.65) {
          var assistPool = pool.filter(function (pl) { return pl.id !== scorer.id; });
          if (assistPool.length) {
            assist = weightedPick(assistPool, function (pl) { return (CREATIVE_POS[pl.position] || 1) * (pl.overall / 50); });
          }
        }
      }
      var text;
      if (ownGoal) {
        text = "گل به خودی به نفع " + teamMeta.teamName;
      } else if (scorer) {
        text = "⚽ گل " + scorer.name + " (" + teamMeta.teamName + ")" + (assist ? " — پاس‌گل: " + assist.name : "");
      } else {
        text = "⚽ گل " + teamMeta.teamName;
      }
      addEvent(minute, "goal", text, { side: side, scorerId: scorer ? scorer.id : null, assistId: assist ? assist.id : null, ownGoal: ownGoal });
      return { scorerId: scorer ? scorer.id : null, assistId: assist ? assist.id : null, ownGoal: ownGoal };
    }

    var goalEvents = [];
    for (var hg = 0; hg < homeGoals; hg++) {
      var hMin = randInt(1, 90);
      goalEvents.push({ minute: hMin, sideScored: "home", info: recordGoal("home", home, homeLineup, hMin) });
    }
    for (var ag = 0; ag < awayGoals; ag++) {
      var aMin = randInt(1, 90);
      goalEvents.push({ minute: aMin, sideScored: "away", info: recordGoal("away", away, awayLineup, aMin) });
    }

    // --- کارت‌های زرد پراکنده ---
    var totalYellows = randInt(1, 7);
    var yellowPlayers = [];
    for (var y = 0; y < totalYellows; y++) {
      var ySide = rand() < 0.5 ? "home" : "away";
      var yLineup = ySide === "home" ? homeLineup : awayLineup;
      var yTeam = ySide === "home" ? home : away;
      var yMinute = randInt(3, 90);
      var yPlayer = yLineup ? choice(yLineup.starters) : null;
      yellowPlayers.push({ side: ySide, playerId: yPlayer ? yPlayer.id : null });
      addEvent(yMinute, "yellow_card", (yPlayer ? yPlayer.name : yTeam.teamName) + " کارت زرد گرفت", { side: ySide, playerId: yPlayer ? yPlayer.id : null });
    }

    addEvent(45, "half_time", "پایان نیمه اول");
    addEvent(90, "full_time", "سوت پایان");
    timeline.sort(function (a, b) { return a.minute - b.minute; });

    // --- آمار تیمی ---
    function buildTeamStats(share, xg, goals, lineup) {
      var possession = Math.round(45 + share * 20); // بین ~۳۵ تا ۶۵
      var bigChances = Math.max(goals, randInt(1, 5));
      var shots = bigChances + randInt(3, 10);
      var shotsOnTarget = Math.min(shots, goals + randInt(1, 5));
      var corners = randInt(2, 9);
      var fouls = randInt(6, 15);
      var offsides = randInt(0, 4);
      return {
        possession: possession, shots: shots, shotsOnTarget: shotsOnTarget,
        passes: randInt(280, 620), passAccuracy: randInt(72, 91),
        corners: corners, fouls: fouls, offsides: offsides,
        xG: Math.round(xg * 100) / 100, bigChances: bigChances
      };
    }

    var homeStats = buildTeamStats(homeShare, homeXG, homeGoals, homeLineup);
    var awayStats = buildTeamStats(awayShare, awayXG, awayGoals, awayLineup);
    // نرمال‌سازی امکان تصرف توپ تا مجموع ۱۰۰ شود
    var possTotal = homeStats.possession + awayStats.possession;
    homeStats.possession = Math.round((homeStats.possession / possTotal) * 100);
    awayStats.possession = 100 - homeStats.possession;
    // سیو دروازه‌بان هر تیم = شوت‌های در چارچوب حریف منهای گل‌هایی که همان حریف زده
    homeStats.saves = Math.max(0, awayStats.shotsOnTarget - awayGoals);
    awayStats.saves = Math.max(0, homeStats.shotsOnTarget - homeGoals);
    homeStats.yellowCards = yellowPlayers.filter(function (yc) { return yc.side === "home"; }).length;
    awayStats.yellowCards = yellowPlayers.filter(function (yc) { return yc.side === "away"; }).length;
    homeStats.redCards = redCardTeams.home ? 1 : 0;
    awayStats.redCards = redCardTeams.away ? 1 : 0;

    // --- امتیاز بازیکنان و برترین بازیکن مسابقه ---
    var playerRatings = {};
    function ratePlayers(lineup, side) {
      if (!lineup) return;
      var used = lineup.starters;
      used.forEach(function (pl) {
        var rating = 6.0;
        goalEvents.forEach(function (g) { if (g.info.scorerId === pl.id) rating += 1.0; if (g.info.assistId === pl.id) rating += 0.6; });
        yellowPlayers.forEach(function (yc) { if (yc.playerId === pl.id) rating -= 0.5; });
        if (redCardTeams[side] && rand() < 0.15) rating -= 1.2;
        rating += (rand() * 0.6 - 0.3);
        playerRatings[pl.id] = Math.round(clamp(rating, 3, 10) * 10) / 10;
      });
    }
    ratePlayers(homeLineup, "home");
    ratePlayers(awayLineup, "away");

    var motmId = null, motmRating = -1;
    Object.keys(playerRatings).forEach(function (pid) {
      if (playerRatings[pid] > motmRating) { motmRating = playerRatings[pid]; motmId = pid; }
    });

    return {
      homeGoals: homeGoals,
      awayGoals: awayGoals,
      timeline: timeline,
      teamStats: { home: homeStats, away: awayStats },
      playerRatings: playerRatings,
      goalEvents: goalEvents,
      yellowCards: yellowPlayers,
      redCards: Object.keys(redCardTeams).filter(function (s) { return redCardTeams[s]; }),
      injuries: injuredPlayers,
      motm: motmId,
      motmRating: motmId ? motmRating : null
    };
  };
})(window.VFL || (window.VFL = {}));
