'use strict';
/* ================= update loop ================= */
function skyColors(sh){
 const dayK=clamp((sh+.18)/.5,0,1);
 const c=C(0x070b24).lerp(C(0x7ec8ff),dayK);
 const dusk=clamp(1-Math.abs(sh-.02)/.22,0,1)*.65;c.lerp(C(0xff8f5a),dusk);
 return {c,dayK};
}
function update(dt){
 /* time */
 tod+=dt/1200;if(tod>=1){tod-=1;day++;}
 const ang=tod*6.2832,sh=Math.sin(ang);
 const {c,dayK}=skyColors(sh);if(WTK==='nether')c.lerp(C(0x4a1008),.85);scene.background=c;
 skyMat.uniforms.bot.value.copy(c);skyMat.uniforms.top.value.copy(C(0x02051a)).lerp(C(0x2f78d8),dayK);sky.position.copy(camera.position);
 if(camUnder){scene.fog.color.set(0x1b6fae);scene.fog.near=1;scene.fog.far=30;scene.background=C(0x1b6fae);}else{scene.fog.color.copy(c);scene.fog.near=35;scene.fog.far=100;}
 hemi.intensity=lerp(.28,.95,dayK);sun.intensity=lerp(0,1.05,dayK);moon.intensity=lerp(.42,0,dayK);
 stars.material.opacity=clamp((.1-sh)*4,0,1);
 const night=sh<-.05;
 $('dayV').textContent=day;$('clockL').textContent=sh>.55?'ظهيرة':sh>.1?(Math.cos(ang)>0?'صباح':'عصر'):sh>-.05?'غروب':'ليل';
 const cx=camera.position.x,cz=camera.position.z;
 const sd=new T.Vector3(Math.cos(ang),sh,.3).normalize();
 const sx0=P?Math.round(P.x):0,sy0=P?Math.round(P.y):0,sz0=P?Math.round(P.z):0;sun.position.set(sx0+sd.x*100,sy0+sd.y*100,sz0+sd.z*100);sun.castShadow=sh>.04;
 if(P){sun.target.position.set(sx0,sy0,sz0);moon.position.set(P.x-sd.x*100,P.y-sd.y*100+30,P.z-sd.z*100);moon.target.position.set(P.x,P.y,P.z);}
 sunMesh.position.copy(camera.position).add(sd.clone().multiplyScalar(300));moonMesh.position.copy(camera.position).add(sd.clone().multiplyScalar(-300));
 stars.position.copy(camera.position);
 caveLight.position.set(P?P.x:0,(P?P.y:0)+3,P?P.z:0);caveLight.intensity=Cave.on?1.6:0;
 if(Cave.on){scene.fog.color.set(0x0a0b10);scene.fog.near=4;scene.fog.far=34;scene.background=C(0x0a0b10);hemi.intensity=.18;sun.intensity=0;moon.intensity=0;}
 waveT+=dt;water.position.set(Math.round(cx/4)*4,-.35,Math.round(cz/4)*4);updateWaves();wtex.offset.x=waveT*.012;wtex.offset.y=waveT*.017;lavaTex.offset.x=waveT*.006;lavaTex.offset.y=-waveT*.004;
 lavaMat.color.setRGB(1,.66+.1*Math.sin(waveT*1.7),.4+.06*Math.sin(waveT*2.3));glowMat.color.setRGB(.86+.14*Math.sin(waveT*2.1),.86+.14*Math.sin(waveT*1.6+1),.86);
 for(const g of clouds.children){g.position.x+=dt*2.5;if(g.position.x>cx+260)g.position.x-=520;if(g.position.x<cx-260)g.position.x+=520;if(g.position.z>cz+260)g.position.z-=520;if(g.position.z<cz-260)g.position.z+=520;}
 clouds.children.forEach(g=>{});
 if(!playing||!P||P.dead)return;

 /* movement */
 const [fx,fz]=fwd(),rx=-Math.cos(camYaw),rz=Math.sin(camYaw);
 let ix=joy.dx,iz=-joy.dy;
 if(keys.KeyW||keys.ArrowUp)iz+=1;if(keys.KeyS||keys.ArrowDown)iz-=1;if(keys.KeyD||keys.ArrowRight)ix+=1;if(keys.KeyA||keys.ArrowLeft)ix-=1;
 const il=Math.hypot(ix,iz);if(il>1){ix/=il;iz/=il;}
 const gRaw0=hAt(P.x,P.z),waterW=!Cave.on&&WT.liquid==='water',lavaW=!Cave.on&&WT.liquid==='lava';
 const dep=waterW?clamp((-.35-gRaw0)/1.1,0,1):0;const wade=dep>.3;
 const runOn=(runHeld||keys.ControlLeft||keys.KeyR)&&il>.2&&!P.swim&&!P.fly&&(creative||P.food>4);P.run=runOn;
 let sp=(P.fly?13:(P.swim?4.4:6.2*(1-.42*dep)))*(1+pk('spd'));
 if(runOn)sp*=1.55;
 if(lavaW&&gRaw0<-.3)sp*=.5;
 const mx=(fx*iz+rx*ix),mz=(fz*iz+rz*ix);
 P.x+=mx*sp*dt;P.z+=mz*sp*dt;
 if(Cave.on){const dx=P.x-Cave.cur.cx,dz=P.z-Cave.cur.cz,d=Math.hypot(dx,dz);if(d>Cave.R-1){P.x=Cave.cur.cx+dx/d*(Cave.R-1);P.z=Cave.cur.cz+dz/d*(Cave.R-1);}}
 camera.fov+=((runOn?72:62)-camera.fov)*Math.min(1,dt*6);camera.updateProjectionMatrix();
 P.mv=Math.hypot(mx,mz);
 if(P.mv>.1){const ty=Math.atan2(mx,mz);let d=ty-P.yaw;d=Math.atan2(Math.sin(d),Math.cos(d));P.yaw+=d*Math.min(1,dt*12);}
 if(P.cool>0)P.cool-=dt;if(P.swing>0)P.swing=Math.max(0,P.swing-dt*3.2);
 if(atkHeld||keys.KeyJ)useItem();
 /* collisions */
 nearProps(P.x,P.z,p=>{if(!p.solid)return;const dx=P.x-p.x,dz=P.z-p.z,d=Math.hypot(dx,dz),R=p.r+.4;if(d<R&&d>.001){P.x=p.x+dx/d*R;P.z=p.z+dz/d*R;}});
 pushOutBoxes(P,.4);pushOutBlocks(P,.36);
 for(const b of built){if(b.type!=='wall')continue;const dx=P.x-b.x,dz=P.z-b.z;if(Math.abs(dx)<b.hx+.4&&Math.abs(dz)<b.hz+.4&&P.y<b.y+2.5){const ox=b.hx+.4-Math.abs(dx),oz=b.hz+.4-Math.abs(dz);if(ox<oz)P.x+=Math.sign(dx||1)*ox;else P.z+=Math.sign(dz||1)*oz;}}
 /* vertical */
 const WL=-.35,gRaw=Math.max(hAt(P.x,P.z),topBlockUnder(P.x,P.z,P.y)),gh=Cave.on?Cave.y:((waterW||WT.void)?gRaw:Math.max(gRaw,-.5));
 const wasSwim=P.swim;
 if(P.fly)P.swim=false;
 else if(waterW&&!P.swim&&gRaw<-1.45){P.swim=true;P.vy=0;P.y=Math.max(P.y,WL-.2);splash(P);toast('أنت تغرق! اضغط «سباحة» للأعلى لتتنفس');}
 else if(P.swim&&(!waterW||gRaw>-1.1)){P.swim=false;P.y=Math.max(gh,P.y-.3);}
 if(P.swim!==wasSwim)setSwimUI(P.swim);
 if(P.fly){P.vy=(jump?9:0)-(down||keys.ShiftLeft?9:0);P.y+=P.vy*dt;if(P.y<gh)P.y=gh;}
 else if(P.swim){
  const up=jump,dn=down||keys.ShiftLeft;
  P.y+=(up?4.2:dn?-3.6:-1.5)*dt;
  if(P.y>WL-.12)P.y=WL-.12;
  if(P.y<gRaw+.35)P.y=gRaw+.35;
  P.vy=0;P.ground=false;
  if(!creative){
   if(P.y<WL-.55){const was=P.air;P.air=Math.max(0,P.air-dt*9*(1-pk('air')));if(was>30&&P.air<=30)toast('الهواء ينفد! اضغط «سباحة» للأعلى');if(P.air<=0)hurt(dt*14,true);}
   else P.air=Math.min(100,P.air+dt*45);
  }
 }
 else{
  const y0=P.y,wg=P.ground;P.vy-=28*(WT.grav||1)*dt;P.y+=P.vy*dt;
  if(P.y<=gh){if(P.vy<-17&&!creative&&!P.fly)hurt((-P.vy-17)*5*(1-Math.min(1,pk('nofall'))));P.y=(wg&&gh-y0>.05&&gh-y0<1.3)?Math.min(gh,y0+dt*9):gh;P.vy=0;P.ground=true;}else P.ground=false;
  if(jump&&P.ground){P.vy=(wade?8:10)*(1+pk('jump'));P.ground=false;}
  headBump(P);
  if(runOn&&!creative)P.food-=dt*.25;
  P.air=Math.min(100,P.air+dt*60);
 }
 if(WT.void&&!Cave.on&&P.y<-40&&!P.fly){P.x=spawn.x;P.z=spawn.z;P.y=heightAt(spawn.x,spawn.z)+1;P.vy=0;if(!creative)hurt(15);toast('سقطت في الفراغ!');}
 /* lava / caves / villagers */
 if(!creative||true){
  let burn=lavaW&&gRaw<-.25&&P.y<-.1;
  scanProps(P.x,P.z,p=>{if(p.type==='lava'){if(Math.hypot(P.x-p.x,P.z-p.z)<p.r&&P.y<p.y+.5)burn=true;}
   else if(p.type==='cave'&&!Cave.on&&P.caveCd<=0&&p.drObj&&p.drObj.open>.8&&!P.fly&&P.ground&&P.y-hAt(P.x,P.z)<.6&&Math.hypot(P.x-p.drObj.x,P.z-p.drObj.z)<1.15)enterCave(p);
   else if(p.type==='portal'&&Cave.on&&P.caveCd<=0&&Math.hypot(P.x-p.x,P.z-p.z)<1.6)exitCave();
   else if(p.type==='crystal'&&p.hp>0&&false){}});
  if(P.caveCd>0)P.caveCd-=dt;
  if(burn){P.burn=(P.burn||0)+dt;hurt(dt*28,true);if(P.burn>.25){P.burn=0;const v=$('vig');v.style.opacity=1;setTimeout(()=>v.style.opacity=0,160);particles(P.x,P.y+1,P.z,0xff7a1a,4);beep(90,.1,'sawtooth',.05);}}
  let nv=null,nvd=3.6;for(const e of ents)if(e.kind==='villager'){const d=Math.hypot(e.x-P.x,e.z-P.z);if(d<nvd){nvd=d;nv=e;}}
  nearVillager=nv;$('bTalk').style.display=nv&&!P.swim?'grid':'none';
  let ni=null,nd=3.6;
  if(!Cave.on){const pcx=Math.floor(P.x/CH),pcz=Math.floor(P.z/CH);for(let a=-1;a<=1;a++)for(let b=-1;b<=1;b++){const c2=chunks.get((pcx+a)+','+(pcz+b));if(c2)for(const d of c2.doors){if(d.kind==='chest'&&d.opened)continue;const dd=Math.hypot(d.x-P.x,d.z-P.z);if(dd<nd){nd=dd;ni=d;}}}}
  nearInter=ni;nearBlk=nearBlockInteract();const ut=nearBlk?(BT[nearBlk.t].table?'صناعة':(nearBlk.open?'إغلاق':'فتح')):(ni?(ni.kind==='chest'?'افتح الصندوق':(ni.t?'إغلاق':'فتح')):'');
  if(ut!==lastUT){lastUT=ut;$('bUse').textContent=ut;}$('bUse').style.display=(ni||nearBlk)&&!P.swim?'grid':'none';
  updateDoors(dt);
 }
 /* needs */
 if(!creative){
  P.food-=dt*.33*(1-pk('hungry'));if(P.food<=0){P.food=0;hurt(dt*2.2,true);}
  else if(P.food>55&&P.hp<100&&P.air>0)P.hp=Math.min(100,P.hp+dt*1.6*(1+pk('regen')));
  for(const b of built)if(b.type==='fire'&&Math.hypot(b.x-P.x,b.z-P.z)<5&&P.hp<100)P.hp=Math.min(100,P.hp+dt*4);
 }
 hudBars();
 /* spawning */
 spawnTimer-=dt;
 if(spawnTimer<=0){spawnTimer=1.2;
  const zc=ents.filter(e=>e.kind==='zombie'||e.kind==='skeleton').length,ac=ents.length-zc;const inRv=!Cave.on&&ravD(P.x,P.z)>2.5;
  const hostile=Cave.on||WTK==='nether';
  const zmax=Cave.on?3:(hostile?4:(night?Math.min(2+Math.floor(day/2),5):(inRv?3:0)));
  const vil=ents.filter(e=>e.kind==='villager').length;
  if(zc<zmax)trySpawn((Cave.on&&Math.random()<.45)||(!Cave.on&&Math.random()<(inRv?.5:.2))?'skeleton':'zombie',Cave.on?10:26,Cave.on?24:42);
  if(!Cave.on&&WT.liquid==='water'&&!WT.void){const fc=ents.filter(e=>e.aqua).length;if(fc<7)for(let i=0;i<6;i++){const a=Math.random()*6.283,d=14+Math.random()*30,x=P.x+Math.cos(a)*d,z=P.z+Math.sin(a)*d;if(heightAt(x,z)<-2){spawnEnt('fish',x,z);break;}}}
  if(!Cave.on&&WTK!=='nether'&&ents.filter(e=>e.fly).length<4){const a=Math.random()*6.283,d=15+Math.random()*35;const x=P.x+Math.cos(a)*d,z=P.z+Math.sin(a)*d;if(heightAt(x,z)>-5)spawnEnt('bird',x,z);}
  if(!Cave.on&&WT.animals.length&&ac-vil-ents.filter(e=>e.aqua||e.fly).length<12){const k=WT.animals[Math.floor(Math.random()*WT.animals.length)];trySpawn(Math.random()<WT.bear*.3?'bear':k,24,46);}
 }
 /* entities */
 for(let i=ents.length-1;i>=0;i--){const e=ents[i];entUpdate(e,dt,night,sh);}
 /* projectiles */
 for(let i=projs.length-1;i>=0;i--){
  const q=projs[i];q.life-=dt;q.v.y-=q.g*dt;
  const steps=3;let dead=q.life<=0;
  for(let s=0;s<steps&&!dead;s++){
   q.p.addScaledVector(q.v,dt/steps);
   if(q.p.y<hAt(q.p.x,q.p.z))dead=true;
   if(blockSolidAt(q.p.x,q.p.y,q.p.z)){dead=true;break;}
   if(q.hostile){if(Math.hypot(P.x-q.p.x,P.z-q.p.z)<.7&&Math.abs(P.y+1-q.p.y)<1.1){hurt(q.dmg);dead=true;}}
   else for(const e of ents){const cy=e.y+(e.ch?1.1:.6);if(Math.hypot(e.x-q.p.x,e.z-q.p.z)<e.r&&Math.abs(cy-q.p.y)<(e.ch?1.1:.6)){dmgEnt(e,q.dmg,q.v.x*.05,q.v.z*.05);dead=true;break;}}
   for(const b of built){if(b.type==='wall'&&Math.abs(q.p.x-b.x)<b.hx&&Math.abs(q.p.z-b.z)<b.hz&&q.p.y<b.y+2.4&&q.p.y>b.y){dead=true;}}
  }
  q.m.position.copy(q.p);if(!q.gun&&q.v.lengthSq()>0)q.m.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),q.v.clone().normalize());
  if(dead){if(q.ex)explode(q.p);scene.remove(q.m);projs.splice(i,1);}
 }
 /* fire light + flames */
 let nf=null,nd=30;
 for(const b of built){if(b.type!=='fire')continue;const d=Math.hypot(b.x-P.x,b.z-P.z);if(d<nd){nd=d;nf=b;}
  const f=b.mesh.getObjectByName('flame');if(f)f.scale.set(.3+Math.random()*.06,.8+Math.random()*.2,.3+Math.random()*.06);}
 if(nf){fireLight.position.set(nf.x,nf.y+1.2,nf.z);fireLight.intensity=1.6+Math.random()*.4;}else fireLight.intensity=0;
 autoSave(dt);
 if(playerChar&&playerChar.aura)animAura(playerChar,performance.now()/1000);
 /* net sync */
 netT-=dt;if(netT<=0){netT=.1;Net.send({t:'pos',x:+P.x.toFixed(2),y:+P.y.toFixed(2),z:+P.z.toFixed(2),yaw:+P.yaw.toFixed(2),sw:P.swim?1:0,ar:S.armor||''});}
 updateChunks(P.x,P.z,2);flushBlocks(3);updateGhost();updateShells(dt);
}
let spawnTimer=2,netT=0,nearVillager=null,runHeld=false,nearInter=null,lastUT='',nearBlk=null;
function doInteract(){
 if(nearBlk&&playing&&!P.dead){if(BT[nearBlk.t].table){renderCraft();$('craft').classList.add('on');}else toggleDoorBlock(nearBlk);return;}
 const d=nearInter;if(!d||!playing||P.dead)return;
 if(d.kind==='chest'){if(d.opened)return;d.opened=true;d.t=1;const n=Math.round(12+Math.random()*28);if(!creative)addCoins(n);giveInv('iron',3);giveInv('arrow',8);giveInv('coal',2);if(Math.random()<.5)giveInv('gold',1);if(Math.random()<.25)giveInv('diamond',1);toast('وجدت كنزاً! +'+n+' عملة');beep(880,.3,'triangle',.07);refreshHud();cloud.event('chest',n);return;}
 d.t=d.t?0:1;beep(d.t?200:150,.12,'square',.05);
}
$('bUse').addEventListener('click',doInteract);
addEventListener('keydown',e=>{if(e.code==='KeyX'&&!typing())doInteract();});
function trySpawn(kind,dmin,dmax){
 for(let i=0;i<6;i++){const a=Math.random()*6.283,d=dmin+Math.random()*(dmax-dmin),x=P.x+Math.cos(a)*d,z=P.z+Math.sin(a)*d,h=hAt(x,z);
  if(Cave.on){if(Math.hypot(x-Cave.cur.cx,z-Cave.cur.cz)>Cave.R-3)continue;}else if(h<.6||h>30)continue;
  if((kind==='zombie'||kind==='skeleton')&&built.some(b=>b.type==='fire'&&Math.hypot(b.x-x,b.z-z)<12))continue;
  spawnEnt(kind,x,z);return;}
}
function hurt(d,silent){
 if(creative||P.dead)return;d*=1-armorRed();P.hp-=d;
 if(!silent){const v=$('vig');v.style.opacity=1;setTimeout(()=>v.style.opacity=0,200);beep(110,.15,'sawtooth',.06);}
 if(P.hp<=0){P.hp=0;P.dead=true;$('dead').classList.add('on');}
}
function entUpdate(e,dt,night,sh){
 const dp=Math.hypot(P.x-e.x,P.z-e.z);
 if(dp>85&&e.kind!=='villager'){removeEnt(e);return;}
 e.flash=Math.max(0,e.flash-dt);if(e.burn>0){e.burn-=dt;e.hp-=dt*3;e.flash=.1;if(Math.random()<.2)particles(e.x,e.y+1,e.z,0xff7a1a,1);if(e.hp<=0){dmgEnt(e,.001,0,0);return;}}const em=e.flash>0?0x992222:0x000000;for(const m of e.mats)m.emissive.setHex(em);
 let dx=0,dz=0,spd=0;
 if(e.fly||e.aqua){
  e.t-=dt;if(e.t<=0){e.t=2+Math.random()*4;e.ya+=(Math.random()-.5)*2.4;}
  const fl=e.flee>0;if(fl){e.flee-=dt;e.ya=Math.atan2(e.x-P.x,e.z-P.z);}
  const sp=e.sp*(fl?2:1),nx=e.x+Math.sin(e.ya)*sp*dt,nz=e.z+Math.cos(e.ya)*sp*dt;
  if(e.aqua){if(heightAt(nx,nz)<-1.6&&WT.liquid==='water'){e.x=nx;e.z=nz;}else e.ya+=2.2;e.y=-.95-.3*Math.abs(Math.sin(e.ph0=e.ph0||0));e.ph+=dt*8;e.g.rotation.z=Math.sin(e.ph)*.12;}
  else{e.x=nx;e.z=nz;e.y=Math.max(hAt(e.x,e.z),0)+e.alt+Math.sin(performance.now()/600+e.ph0)*.5;e.ph+=dt*14;if(e.wings)e.wings.forEach((w,i)=>{w.rotation.z=(i?1:-1)*Math.sin(e.ph)*.7;});}
  e.g.position.set(e.x,e.y,e.z);e.g.rotation.y=e.ya;e.mv=0;return;
 }
 if(e.kind==='zombie'){
  if(sh>.25&&!Cave.on&&WTK!=='nether'&&ravD(e.x,e.z)<2.5){e.hp-=dt*1.3;if(e.hp<=0){particles(e.x,e.y+1,e.z,0x666666,8);removeEnt(e);return;}}
  let scared=false;for(const b of built)if(b.type==='fire'&&Math.hypot(b.x-e.x,b.z-e.z)<8){dx=e.x-b.x;dz=e.z-b.z;spd=e.sp*1.2;scared=true;break;}
  if(!scared){
   if(dp<38&&!P.dead){dx=P.x-e.x;dz=P.z-e.z;spd=e.sp*(night?1.15:.8);if(dp<1.5){spd=0;e.cool-=dt;if(e.cool<=0){e.cool=1;hurt((7+Math.min(day,6))*(e.dm||1));if(e.tox&&!creative){P.food=Math.max(0,P.food-6);}if(e.fireHit)P.burn=0;}}}
   else{e.t-=dt;if(e.t<=0){e.t=2+Math.random()*3;e.wx=Math.random()-.5;e.wz=Math.random()-.5;}dx=e.wx||0;dz=e.wz||0;spd=e.sp*.3;}
  }
 }else if(e.kind==='skeleton'){
  if(sh>.25&&!Cave.on&&WTK!=='nether'&&ravD(e.x,e.z)<2.5){e.hp-=dt*1.3;if(e.hp<=0){particles(e.x,e.y+1,e.z,0x999999,8);removeEnt(e);return;}}
  if(dp<24&&!P.dead){dx=P.x-e.x;dz=P.z-e.z;spd=dp>9?e.sp:(dp<5?-e.sp*.8:0);e.yaw=Math.atan2(P.x-e.x,P.z-e.z);e.shotT-=dt;
   if(e.shotT<=0&&dp<20){e.shotT=2+Math.random();const d=new T.Vector3(P.x-e.x,P.y+1.2-(e.y+1.4),P.z-e.z);d.y+=dp*.06;d.normalize();const m=new T.Mesh(GM.cyl,new T.MeshLambertMaterial({color:0xd9c79a}));m.scale.set(.03,.9,.03);m.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),d);const o=new T.Vector3(e.x,e.y+1.4,e.z);m.position.copy(o);scene.add(m);projs.push({m,p:o.clone(),v:d.clone().multiplyScalar(26),g:4,dmg:6+Math.min(day,4),life:2.5,hostile:1});beep(330,.08,'triangle',.04);}}
  else{e.t-=dt;if(e.t<=0){e.t=2+Math.random()*3;e.wx=Math.random()-.5;e.wz=Math.random()-.5;}dx=e.wx||0;dz=e.wz||0;spd=e.sp*.3;}
 }else if(e.kind==='bear'){
  if(dp<22&&!P.dead){dx=P.x-e.x;dz=P.z-e.z;spd=e.sp;if(dp<2.3){spd=0;e.cool-=dt;if(e.cool<=0){e.cool=1.2;hurt(15);}}}
  else{e.t-=dt;if(e.t<=0){e.t=2+Math.random()*4;e.wx=Math.random()-.5;e.wz=Math.random()-.5;}dx=e.wx||0;dz=e.wz||0;spd=e.sp*.25;}
 }else if(e.kind==='villager'){
  const hd=Math.hypot(e.hx-e.x,e.hz-e.z);
  if(dp<4)spd=0;else if(hd>7){dx=e.hx-e.x;dz=e.hz-e.z;spd=e.sp*.6;}else{e.t-=dt;if(e.t<=0){e.t=2+Math.random()*4;e.wx=Math.random()-.5;e.wz=Math.random()-.5;}dx=e.wx||0;dz=e.wz||0;spd=e.sp*.35;}
 }else{
  e.t-=dt;
  if(e.flee>0){e.flee-=dt;dx=e.x-P.x;dz=e.z-P.z;spd=e.sp*1.8;}
  else{if(e.t<=0){e.t=2+Math.random()*4;if(Math.random()<.4){e.wx=0;e.wz=0;}else{e.wx=Math.random()-.5;e.wz=Math.random()-.5;}}dx=e.wx||0;dz=e.wz||0;spd=e.sp*.5;}
 }
 const l=Math.hypot(dx,dz);
 if(l>.01&&spd!==0){dx/=l;dz/=l;const nx=e.x+dx*spd*dt,nz=e.z+dz*spd*dt;
  const okH=!entBlockedByBlocks(nx,nz,e.y)&&!boxBlocked(nx,nz,.5)&&(Cave.on?Math.hypot(nx-Cave.cur.cx,nz-Cave.cur.cz)<Cave.R-1:(WT.liquid==='lava'?true:heightAt(nx,nz)>.2));if(okH){e.x=nx;e.z=nz;if(e.kind!=='skeleton')e.yaw=Math.atan2(dx,dz);}else{e.t=0;e.wx=-dx;e.wz=-dz;}
 }else spd=0;
 e.mv=spd;e.y=Cave.on?Cave.y:Math.max(hAt(e.x,e.z),-.45);
 e.ph+=dt*Math.abs(spd)*3.2;
 e.g.position.set(e.x,e.y,e.z);
 let d=e.yaw-e.g.rotation.y;d=Math.atan2(Math.sin(d),Math.cos(d));e.g.rotation.y+=d*Math.min(1,dt*8);
 if(e.ch){e.ch.legL.rotation.x=Math.sin(e.ph)*.7;e.ch.legR.rotation.x=-Math.sin(e.ph)*.7;
  if(e.kind==='villager'){const tt=performance.now()/1000+e.hx;
   if(dp<4.5){e.yaw=Math.atan2(P.x-e.x,P.z-e.z);e.ch.armL.rotation.x=Math.sin(tt)*.05;e.ch.armR.rotation.x=-2.3+Math.sin(tt*5)*.35;}
   else{const sw=Math.sin(e.ph)*.55;e.ch.armL.rotation.x=-sw+Math.sin(tt*1.3)*.04;e.ch.armR.rotation.x=sw+Math.sin(tt*1.1)*.04;}
   e.ch.g.position.y=e.y+(spd>0?Math.abs(Math.sin(e.ph))*.04:Math.sin(tt*1.6)*.012);
  }}
 else if(e.legs){const a=Math.sin(e.ph)*.7;e.legs[0].rotation.x=a;e.legs[3].rotation.x=a;e.legs[1].rotation.x=-a;e.legs[2].rotation.x=-a;}
}
function animatePlayer(dt){
 if(!P||!playerChar)return;const ch=playerChar;
 ch.g.rotation.order='YXZ';
 ch.hold.visible=!P.swim;
 if(P.swim){
  P.ph+=dt*(P.mv>.1?7:2.5);
  const sx=Math.sin(P.yaw),sz=Math.cos(P.yaw),bob=Math.sin(performance.now()/380)*.04;
  ch.g.rotation.x=1.3;ch.g.rotation.y=P.yaw;
  ch.g.position.set(P.x-sx*1.16,P.y-.32+bob,P.z-sz*1.16);
  const w=Math.sin(P.ph);
  ch.armL.rotation.x=-2.5+w*.9;ch.armR.rotation.x=-2.5-w*.9;
  ch.legL.rotation.x=Math.sin(P.ph*1.7)*.5;ch.legR.rotation.x=-Math.sin(P.ph*1.7)*.5;
  ch.g.visible=!P.dead;return;
 }
 ch.g.rotation.x=0;
 ch.g.position.set(P.x,P.y,P.z);ch.g.rotation.y=P.yaw;
 P.ph+=dt*P.mv*9;const w=Math.sin(P.ph)*.85*Math.min(1,P.mv);
 const it=ITEMS[curId()];const armed=it&&(it.type==='melee'||it.type==='ranged')&&curId()!=='fist';
 ch.legL.rotation.x=w;ch.legR.rotation.x=-w;ch.armL.rotation.x=-w*.8;
 const rest=armed?(it.type==='ranged'?-1.5:-.9):w*.8;
 ch.armR.rotation.x=rest-(P.swing>0?Math.sin(P.swing*Math.PI)*1.8:0);
 ch.g.position.y+=(P.mv>.1&&P.ground?Math.abs(Math.sin(P.ph))*.05:0);
 ch.g.visible=!P.dead;
}
function animateOthers(dt){
 for(const o of Net.others.values()){
  if(o.tx===undefined)continue;const dx=o.tx-o.x,dz=o.tz-o.z;const mv=Math.hypot(dx,dz);
  const k=Math.min(1,dt*10);o.x+=dx*k;o.y+=(o.ty-o.y)*k;o.z+=dz*k;
  let d=o.tyaw-o.yaw;d=Math.atan2(Math.sin(d),Math.cos(d));o.yaw+=d*k;
  o.ph+=mv*2.2;animAura(o.ch,performance.now()/1000);const w=Math.sin(o.ph)*.8*Math.min(1,mv*4);
  o.ch.g.rotation.order='YXZ';
  if(o.sw){const sx=Math.sin(o.yaw),sz=Math.cos(o.yaw),tt=performance.now();o.ch.g.rotation.x=1.3;o.ch.g.rotation.y=o.yaw;o.ch.g.position.set(o.x-sx*1.16,o.y-.32,o.z-sz*1.16);const ww=Math.sin(tt/260);o.ch.armL.rotation.x=-2.5+ww*.9;o.ch.armR.rotation.x=-2.5-ww*.9;o.ch.legL.rotation.x=Math.sin(tt/150)*.5;o.ch.legR.rotation.x=-Math.sin(tt/150)*.5;continue;}
  o.ch.g.rotation.x=0;
  o.ch.g.position.set(o.x,o.y,o.z);o.ch.g.rotation.y=o.yaw;o.ch.legL.rotation.x=w;o.ch.legR.rotation.x=-w;o.ch.armL.rotation.x=-w*.8;o.ch.armR.rotation.x=w*.8;
 }
}
function updateCamera(dt){
 if(!playing&&P){
  // menu stage: orbit around the character
  const t=performance.now()/4000;const px=P.x,py=P.y,pz=P.z;
  camera.position.set(px+Math.sin(t)*5.2,py+2.4,pz+Math.cos(t)*5.2);camera.lookAt(px+1.2*Math.cos(t),py+1.5,pz-1.2*Math.sin(t));
  if(playerChar){playerChar.g.position.set(px,py,pz);playerChar.g.rotation.y=t+Math.PI;}
  return;
 }
 if(!P)return;
 const dist=6.2,cp=Math.cos(camPitch),sp=Math.sin(camPitch);
 const hx=P.x,hy=P.y+(P.swim?.9:1.8),hz=P.z;
 let cx=hx-Math.sin(camYaw)*cp*dist,cy=hy+sp*dist,cz=hz-Math.cos(camYaw)*cp*dist;
 {const L=boxList(hx,hz);if(L&&L.length){for(let st=.12;st<=1.001;st+=.08){const qx=hx+(cx-hx)*st,qy=hy+(cy-hy)*st,qz=hz+(cz-hz)*st;let hit=false;for(const b of L){if(b.d&&b.d.open>.5)continue;if(qy>b.y0&&qy<b.y1&&inBoxXZ(b,qx,qz,.25)){hit=true;break;}}if(hit){const k=Math.max(.1,st-.14);cx=hx+(cx-hx)*k;cy=hy+(cy-hy)*k;cz=hz+(cz-hz)*k;break;}}}}
 const gh=hAt(cx,cz)+.6;if(cy<gh)cy=gh;if(Cave.on&&cy>Cave.y+8)cy=Cave.y+8;
 camera.position.set(cx,cy,cz);camUnder=!Cave.on&&WT.liquid==='water'&&cy<-.4&&heightAt(cx,cz)<-.4;$('uw').style.opacity=camUnder?1:0;camera.lookAt(hx-Math.cos(camYaw)*.9,hy-.2,hz+Math.sin(camYaw)*.9);
}
let last=performance.now();
function frame(now){
 requestAnimationFrame(frame);
 const dt=Math.min(.05,(now-last)/1000);last=now;
 if(!world.ready){return;}
 if(!playing)updateChunks(P.x,P.z,1);
 update(dt);
 for(let i=parts.length-1;i>=0;i--){const q=parts[i];q.life-=dt;q.vy-=14*dt;q.m.position.x+=q.vx*dt;q.m.position.y+=q.vy*dt;q.m.position.z+=q.vz*dt;if(q.life<=0){scene.remove(q.m);q.m.material.dispose();parts.splice(i,1);}}
 animatePlayer(dt);animateOthers(dt);renderPreview(dt);
 updateCamera(dt);
 renderer.render(scene,camera);
}

