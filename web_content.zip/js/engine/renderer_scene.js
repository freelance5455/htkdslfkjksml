'use strict';
/* ================= renderer / scene ================= */
const canvas=$('c');
const renderer=new T.WebGLRenderer({canvas,antialias:true,powerPreference:'high-performance'});
renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,1.75));
renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFSoftShadowMap;
const scene=new T.Scene();
const camera=new T.PerspectiveCamera(62,1,.3,420);
scene.fog=new T.Fog(0x7ec8ff,35,100);
const hemi=new T.HemisphereLight(0xdff0ff,0x55663a,.9);scene.add(hemi);
const sun=new T.DirectionalLight(0xfff2d0,1);scene.add(sun);scene.add(sun.target);
sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);{const sc=sun.shadow.camera;sc.left=-46;sc.right=46;sc.top=46;sc.bottom=-46;sc.near=1;sc.far=260;}sun.shadow.bias=-.0008;
const skyMat=new T.ShaderMaterial({uniforms:{top:{value:new T.Color(0x2f78d8)},bot:{value:new T.Color(0xbfe3ff)}},vertexShader:'varying float h;void main(){h=normalize(position).y;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}',fragmentShader:'uniform vec3 top;uniform vec3 bot;varying float h;void main(){float t=smoothstep(-0.05,0.65,h);gl_FragColor=vec4(mix(bot,top,t),1.0);}',side:T.BackSide,depthWrite:false,fog:false});
const sky=new T.Mesh(new T.SphereGeometry(380,16,10),skyMat);sky.renderOrder=-10;sky.frustumCulled=false;scene.add(sky);
const moon=new T.DirectionalLight(0x6a86ff,0);scene.add(moon);scene.add(moon.target);
const fireLight=new T.PointLight(0xff9a3d,0,22,2);scene.add(fireLight);
let ROT=false;
const rootEl=$('root');
function resize(){
 const W=window.innerWidth,H=window.innerHeight;ROT=H>W;
 const w=ROT?H:W,h=ROT?W:H;
 rootEl.style.width=w+'px';rootEl.style.height=h+'px';rootEl.style.setProperty('--vw',(w/100)+'px');rootEl.style.setProperty('--vh',(h/100)+'px');rootEl.classList.toggle('short',h<=420);
 rootEl.style.transform=ROT?'translateX('+W+'px) rotate(90deg)':'none';
 renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();
}
function pt(e){return ROT?{x:e.clientY,y:window.innerWidth-e.clientX}:{x:e.clientX,y:e.clientY};}
window.addEventListener('orientationchange',()=>setTimeout(resize,150));
window.addEventListener('resize',resize);resize();

const sunMesh=new T.Mesh(new T.SphereGeometry(14,10,8),new T.MeshBasicMaterial({color:0xfff1a8,fog:false}));
const moonMesh=new T.Mesh(new T.SphereGeometry(10,10,8),new T.MeshBasicMaterial({color:0xe6ecff,fog:false}));
scene.add(sunMesh,moonMesh);
const starGeo=new T.BufferGeometry();{const a=[];for(let i=0;i<500;i++){const u=Math.random()*2-1,t=Math.random()*6.283,r=Math.sqrt(1-u*u);a.push(r*Math.cos(t)*380,Math.abs(u)*380+10,r*Math.sin(t)*380);}starGeo.setAttribute('position',new T.Float32BufferAttribute(a,3));}
const stars=new T.Points(starGeo,new T.PointsMaterial({color:0xffffff,size:2.2,sizeAttenuation:false,transparent:true,opacity:0,fog:false}));scene.add(stars);
const wtex=(()=>{const c=document.createElement('canvas');c.width=c.height=128;const x=c.getContext('2d');x.fillStyle='#808080';x.fillRect(0,0,128,128);
 for(let i=0;i<90;i++){const px=Math.random()*128,py=Math.random()*128,r=4+Math.random()*10;const g=x.createRadialGradient(px,py,0,px,py,r);g.addColorStop(0,'rgba(255,255,255,.55)');g.addColorStop(1,'rgba(128,128,128,0)');x.fillStyle=g;x.fillRect(px-r,py-r,r*2,r*2);}
 const t=new T.CanvasTexture(c);t.wrapS=t.wrapT=T.RepeatWrapping;t.repeat.set(70,70);return t;})();
const water=new T.Mesh(new T.PlaneGeometry(288,288,72,72),new T.MeshPhongMaterial({color:0x2c98d8,transparent:true,opacity:.8,shininess:100,specular:0x99ccff,bumpMap:wtex,bumpScale:1.5}));
water.rotation.x=-Math.PI/2;scene.add(water);
let waveT=0,waveF=0;
function updateWaves(){
 const lava=water.material===lavaMat,g=water.geometry,pa=g.attributes.position,t=waveT*(lava?.3:1),A=lava?.045:.075,px=water.position.x,pz=water.position.z;
 for(let i=0;i<pa.count;i++){const wx=px+pa.getX(i),wz=pz-pa.getY(i);
  pa.setZ(i,Math.sin(wx*.33+t*1.4)*A+Math.sin(wz*.47-t*1.1)*A*.8+Math.sin((wx+wz)*.19+t*.8)*A*1.2+Math.sin((wx-wz)*.5+t*2.1)*A*.3);}
 pa.needsUpdate=true;if(!lava&&(waveF++&1)===0)g.computeVertexNormals();
}
const clouds=new T.Group();scene.add(clouds);
{const cm=new T.MeshLambertMaterial({color:0xffffff,flatShading:true,transparent:true,opacity:.92});
 for(let i=0;i<16;i++){const g=new T.Group();const n=3+Math.floor(Math.random()*3);for(let k=0;k<n;k++){const m=new T.Mesh(new T.IcosahedronGeometry(1,0),cm);const s=8+Math.random()*9;m.scale.set(s*1.4,s*.6,s);m.position.set(k*9-n*4,Math.random()*3,Math.random()*6-3);g.add(m);}
  g.position.set(Math.random()*500-250,70+Math.random()*30,Math.random()*500-250);clouds.add(g);}}

