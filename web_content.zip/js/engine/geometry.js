'use strict';
/* ================= geometry helpers (merged low-poly props) ================= */
const GN={ico:new T.IcosahedronGeometry(1,0).toNonIndexed(),cone:new T.ConeGeometry(1,1,6,1).toNonIndexed(),cyl:new T.CylinderGeometry(1,1,1,6,1).toNonIndexed(),dode:new T.DodecahedronGeometry(1,0).toNonIndexed()};
const GM={sph:new T.SphereGeometry(1,10,8),cyl:new T.CylinderGeometry(1,1,1,8),ico:new T.IcosahedronGeometry(1,0),cone:new T.ConeGeometry(1,1,8)};
const _m=new T.Matrix4(),_q=new T.Quaternion(),_e=new T.Euler(),_s=new T.Vector3(),_p=new T.Vector3(),_v=new T.Vector3();
function part(b,geo,x,y,z,sx,sy,sz,ry,col){
 _p.set(x,y,z);_s.set(sx,sy,sz);_q.setFromEuler(_e.set(0,ry||0,0));_m.compose(_p,_q,_s);
 const pa=geo.attributes.position;
 for(let i=0;i<pa.count;i++){_v.fromBufferAttribute(pa,i).applyMatrix4(_m);b.p.push(_v.x,_v.y,_v.z);b.c.push(col.r,col.g,col.b);}
}
function bufMesh(b,mat){const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(b.p,3));g.setAttribute('color',new T.Float32BufferAttribute(b.c,3));g.computeVertexNormals();return new T.Mesh(g,mat);}
const propMat=new T.MeshLambertMaterial({vertexColors:true,flatShading:true});
const terrMat=new T.MeshLambertMaterial({vertexColors:true,flatShading:true});

