'use strict';
/* ================= terrain chunks / world types / caves ================= */
const CH=32,RES=16,RAD=3;
GN.box=new T.BoxGeometry(1,1,1).toNonIndexed();
const chunks=new Map();const deadSet=new Set();
const cc=h=>new T.Color(h);
const WTYPES={
 forest:{n:'غابة',liquid:'water',wet:0xb9a66c,deep:0x6d8aa0,sand:0xe6d79c,g:[0x74c452,0x4fa03f,0x3b8a3a],rock:0x8d939c,peak:0xf4f8ff,sky:0x7ec8ff,animals:['deer','pig','rabbit','cow','sheep','fox'],bear:.25,village:.07,
  pick:(h,dn,r)=>r>.996?'cave':(r>.995&&h>8)?'lava':(h<30&&r<(.15+Math.max(0,dn-.42)*2.2))?'tree':(r>.9&&r<.945)?'rock':(r>.945&&r<.965)?'ore':(r>.965&&r<.98)?'bush':(r>.55&&h<22)?'flower':null},
 desert:{n:'صحراء',liquid:'water',wet:0xcfb06a,deep:0xa8905a,sand:0xefdfa5,g:[0xe6c97d,0xd8b768,0xcaa355],rock:0xb98f5a,peak:0xe8d4a0,sky:0x9fd4ff,animals:['camel','rabbit','camel','rabbit'],bear:0,village:.07,
  pick:(h,dn,r)=>r>.996?'cave':(r>.99&&h>3&&r<.994)?'lava':r<.045?'cactus':r<.075?'deadbush':(r>.9&&r<.94)?'rock':(r>.94&&r<.96)?'ore':null},
 snow:{n:'ثلج',liquid:'water',wet:0xcfe3ee,deep:0x6d8fae,sand:0xe8f1f7,g:[0xf4f8ff,0xe6eff7,0xd7e5f0],rock:0x9aa6b4,peak:0xffffff,sky:0xa9d4f5,animals:['rabbit','fox','fox','deer'],bear:.5,village:.05,snowy:1,
  pick:(h,dn,r)=>r>.996?'cave':(h<30&&r<(.08+Math.max(0,dn-.45)*1.6))?'tree':(r>.9&&r<.945)?'rock':(r>.945&&r<.965)?'ore':null},
 nether:{n:'الجحيم',liquid:'lava',wet:0x3a1410,deep:0x1a0806,sand:0x4a1c14,g:[0x5a1f16,0x4a1812,0x3a120e],rock:0x2a2a30,peak:0x55302a,sky:0x3a0d0a,fixed:1,animals:[],bear:0,village:0,
  pick:(h,dn,r)=>r>.996?'cave':(r>.985&&r<.992)?'lava':r<.07?'basalt':r<.1?'deadtree':(r>.9&&r<.93)?'ore':(r>.93&&r<.96)?'rock':null}
};
const FP=WTYPES.forest.pick,RP=(h,dn,r)=>r>.996?'cave':(r>.9&&r<.945)?'rock':(r>.945&&r<.965)?'ore':null;
const BIGW={
 neon:{n:'نيون الفجر',amp:1.2,grav:.55,liquid:'water',wet:0x3a2a7a,deep:0x1a1050,sand:0x8a6aff,g:[0x7a3cff,0x5a2fd6,0x4a25b0],rock:0x5a4a9a,peak:0xff9aff,sky:0x1a0b3a,animals:['rabbit','deer'],pick:FP},
 flip:{n:'العالم المقلوب',inv:1,grav:1,liquid:'water',wet:0x7ad89a,deep:0x3a9a6a,sand:0xe8f8c8,g:[0x4aa8e8,0x3a8cd0,0x2f78b8],rock:0xc8d868,peak:0xffe27a,sky:0x7adf7a,animals:['pig','rabbit'],pick:FP},
 tiny:{n:'الكواكب الصغيرة',islands:{s:70,r:26,h:15},void:1,grav:.6,liquid:'none',wet:0x6a5a3a,deep:0x1a1a2a,sand:0xd8c88a,g:[0x6ad46a,0x4aa84a,0x3a8a3a],rock:0x8a8a9a,peak:0xffffff,sky:0x0a0f2a,animals:['rabbit','pig'],pick:FP},
 mars:{n:'المريخ الأحمر',amp:.9,grav:.38,liquid:'none',wet:0x8a3a1a,deep:0x5a2410,sand:0xc8683a,g:[0xc8583a,0xb44a2e,0xa03e26],rock:0x7a3a2a,peak:0xe8a878,sky:0xd98a5a,animals:[],pick:RP},
 ice:{n:'قمر الجليد',amp:1,grav:.3,liquid:'water',wet:0xdff1fa,deep:0x8fb8d8,sand:0xf4fbff,g:[0xf4f8ff,0xe0eef8,0xcfe2f2],rock:0x9ab0c8,peak:0xffffff,sky:0x050818,snowy:1,animals:['rabbit','fox'],pick:RP},
 volcano:{n:'كوكب البراكين',amp:1.3,grav:1,liquid:'lava',wet:0x3a1410,deep:0x1a0806,sand:0x4a1c14,g:[0x4a2a22,0x3a1f1a,0x2a1612],rock:0x2a2a30,peak:0x7a3a2a,sky:0x4a1208,fixed:1,animals:[],pick:WTYPES.nether.pick},
 sky:{n:'جزر السحاب',islands:{s:130,r:46,h:12},void:1,grav:.8,liquid:'none',wet:0xdfe8c0,deep:0x6a8a5a,sand:0xe8e0b0,g:[0x8ad46a,0x6ab84a,0x4a9a3a],rock:0xb8bcc8,peak:0xffffff,sky:0xbfe6ff,animals:['sheep','rabbit','deer'],pick:FP},
 glow:{n:'الغابة المتوهجة',amp:1,grav:.9,liquid:'water',wet:0x3a8a8a,deep:0x1a4a6a,sand:0xa8f0e0,g:[0xff7ac8,0xe05ab0,0x30d0c0],rock:0x6a5a8a,peak:0xffe0ff,sky:0x14283a,animals:['deer','rabbit','fox'],pick:FP},
 dino:{n:'عصر الديناصورات',amp:1.5,grav:1.1,liquid:'water',wet:0x8a9a50,deep:0x4a6a3a,sand:0xc8c080,g:[0x4a9a2a,0x3a8a22,0x2f7a1c],rock:0x7a7a60,peak:0xd8e0a0,sky:0xb8d070,animals:['cow','pig','deer','camel'],bear:.3,pick:FP},
 crystal:{n:'كوكب البلّور',amp:.35,flatw:1,grav:.7,liquid:'none',wet:0x6a8ad8,deep:0x3a4a9a,sand:0xb8d8ff,g:[0x5ad8e8,0x3ab8d8,0x2a98c8],rock:0xa8b8ff,peak:0xffffff,sky:0x2a1a4a,animals:['rabbit'],pick:RP}
};
for(const k in BIGW){const w=BIGW[k];w.big=1;w.bear=w.bear||0;w.village=0;WTYPES[k]=w;}
for(const k in WTYPES){const w=WTYPES[k];w.c={wet:cc(w.wet),deep:cc(w.deep),sand:cc(w.sand),g:w.g.map(cc),rock:cc(w.rock),peak:cc(w.peak)};}
let WTK='forest',WT=WTYPES.forest;
const waterMat=water.material;
const lavaTex=(()=>{const c=document.createElement('canvas');c.width=c.height=128;const x=c.getContext('2d');x.fillStyle='#d8420e';x.fillRect(0,0,128,128);
 for(let i=0;i<70;i++){const px=Math.random()*128,py=Math.random()*128,r=5+Math.random()*12;const g=x.createRadialGradient(px,py,0,px,py,r);g.addColorStop(0,i%3?'rgba(255,214,70,.9)':'rgba(110,20,0,.8)');g.addColorStop(1,'rgba(216,66,14,0)');x.fillStyle=g;x.fillRect(px-r,py-r,r*2,r*2);}
 const t=new T.CanvasTexture(c);t.wrapS=t.wrapT=T.RepeatWrapping;t.repeat.set(70,70);return t;})();
const lavaMat=new T.MeshBasicMaterial({map:lavaTex,color:0xffb060});
function setWorldType(k){WTK=WTYPES[k]?k:'forest';WT=WTYPES[WTK];water.material=WT.liquid==='lava'?lavaMat:waterMat;water.visible=WT.liquid!=='none';}
const glowMat=new T.MeshBasicMaterial({vertexColors:true});
function groundCol(x,z,h,out){
 const W=WT.c,n=vnoise(x*.2,z*.2);
 if(h<-0.2){out.copy(W.wet).lerp(W.deep,clamp(-h/9,0,1));}
 else if(h<0.9){out.copy(W.sand);}
 else if(h>36){out.copy(W.peak);}
 else if(h>26){out.copy(W.rock).lerp(W.peak,(h-26)/10);}
 else{out.copy(W.g[0]).lerp(W.g[1],vnoise(x*.03+9,z*.03+9)).lerp(W.g[2],Math.max(0,fbm(x*.02+500,z*.02+500,3)-.5)*1.6);}
 out.multiplyScalar(.93+n*.14);
}
const at=(p,ox,oz)=>[p.x+ox*Math.cos(p.ry||0)+oz*Math.sin(p.ry||0),p.z-ox*Math.sin(p.ry||0)+oz*Math.cos(p.ry||0)];
const ADD={
 tree(b,p){const s=p.s,v=p.v;
  part(b,GN.cyl,p.x,p.y+.9*s,p.z,.24*s,1.8*s,.24*s,0,C(0x7a5232));
  if(p.pine){for(let i=0;i<3;i++){const f=1-i*.26;const top=(p.y>27||p.snowy)&&i>=1;part(b,GN.cone,p.x,p.y+(1.9+i*1.05)*s,p.z,1.3*s*f,1.7*s,1.3*s*f,v*6,top?C(0xf2f6ff):C(0x2f7a4a).offsetHSL(0,0,(v-.5)*.08));}}
  else{const lc=C(0x58b04a).offsetHSL((v-.5)*.06,0,(v-.5)*.1);
   part(b,GN.ico,p.x,p.y+2.6*s,p.z,1.3*s,1.15*s,1.3*s,v*6,lc);
   part(b,GN.ico,p.x+.6*s,p.y+2.1*s,p.z+.2*s,.85*s,.75*s,.85*s,v*3,lc.clone().offsetHSL(0,0,.04));}
 },
 rock(b,p){part(b,GN.dode,p.x,p.y+.45*p.s,p.z,.95*p.s,.7*p.s,.85*p.s,p.v*6,C(p.rc||0x8b9098).offsetHSL(0,0,(p.v-.5)*.1));},
 ore(b,p){part(b,GN.dode,p.x,p.y+.45*p.s,p.z,.95*p.s,.7*p.s,.85*p.s,p.v*6,C(0x7d727a));
  for(let i=0;i<4;i++){part(b,GN.ico,p.x+Math.cos(i*1.7+p.v*9)*.5*p.s,p.y+.55*p.s+(i%2)*.2,p.z+Math.sin(i*1.7+p.v*9)*.45*p.s,.2,.2,.2,0,C(0xe8923a));}},
 bush(b,p){part(b,GN.ico,p.x,p.y+.35*p.s,p.z,.65*p.s,.5*p.s,.65*p.s,p.v*6,C(0x3f9a47));
  for(let i=0;i<3;i++)part(b,GN.ico,p.x+Math.cos(i*2.1)*.4*p.s,p.y+.55*p.s,p.z+Math.sin(i*2.1)*.4*p.s,.1,.1,.1,0,C(0xd8284a));},
 flower(b,p){part(b,GN.cyl,p.x,p.y+.15,p.z,.025,.3,.025,0,C(0x3f8a3a));part(b,GN.ico,p.x,p.y+.34,p.z,.11,.09,.11,0,C(p.col));},
 cactus(b,p){const s=p.s,g=C(0x3f8f45);part(b,GN.cyl,p.x,p.y+1*s,p.z,.22*s,2*s,.22*s,0,g);part(b,GN.cyl,p.x+.42*s,p.y+1.3*s,p.z,.12*s,.8*s,.12*s,0,g);part(b,GN.cyl,p.x-.4*s,p.y+1.0*s,p.z,.12*s,.6*s,.12*s,0,g);},
 deadbush(b,p){for(let i=0;i<4;i++)part(b,GN.cyl,p.x+Math.cos(i*1.6)*.12,p.y+.25,p.z+Math.sin(i*1.6)*.12,.03,.5+i*.05,.03,i,C(0x8a6a3a));},
 basalt(b,p){const s=p.s;part(b,GN.cyl,p.x,p.y+1.8*s,p.z,.6*s,3.6*s,.6*s,p.v*6,C(0x2b2b33));part(b,GN.cone,p.x,p.y+3.9*s,p.z,.55*s,.7*s,.55*s,p.v*6,C(0x3a3a46));},
 deadtree(b,p){const s=p.s;part(b,GN.cyl,p.x,p.y+1.2*s,p.z,.18*s,2.4*s,.18*s,0,C(0x2a1a14));part(b,GN.cyl,p.x+.4*s,p.y+2*s,p.z,.08*s,1*s,.08*s,0,C(0x2a1a14));part(b,GN.cyl,p.x-.35*s,p.y+1.6*s,p.z+.1,.08*s,.9*s,.08*s,0,C(0x2a1a14));},
 lava(b,p,bg){part(b,GN.cyl,p.x,p.y+.04,p.z,p.r*1.15,.08,p.r*1.15,0,C(0x2b1a14));part(bg,GN.cyl,p.x,p.y+.1,p.z,p.r,.14,p.r,0,C(0xff6a1a));part(bg,GN.cyl,p.x,p.y+.12,p.z,p.r*.55,.14,p.r*.55,0,C(0xffc23a));},
 cave(b,p,bg){const R=C(0x6b7078);let [x,z]=lw(p,-2.6,0);part(b,GN.dode,x,p.y+1.7,z,1.5,2.2,1.5,p.v*6,R);[x,z]=lw(p,2.6,0);part(b,GN.dode,x,p.y+1.7,z,1.5,2.2,1.5,p.v*5,R);
  [x,z]=lw(p,0,0);part(b,GN.dode,x,p.y+3.9,z,3.6,1.3,1.6,p.ry,R);
  [x,z]=lw(p,0,-3.4);part(b,GN.dode,x,p.y+2,z,6.2,4.4,3.8,p.v*3,C(0x636870));[x,z]=lw(p,-3.2,-2);part(b,GN.dode,x,p.y+1.2,z,2.2,2.2,2.2,p.v*2,R);[x,z]=lw(p,3.2,-2);part(b,GN.dode,x,p.y+1.2,z,2.2,2.4,2.2,p.v*4,R);
  [x,z]=lw(p,0,-.7);part(b,GN.box,x,p.y+1.6,z,3.3,3.2,.5,p.ry,C(0x050507));
  [x,z]=lw(p,-2.3,1.3);part(bg,GN.ico,x,p.y+2.6,z,.2,.3,.2,0,C(0xffa02e));[x,z]=lw(p,2.3,1.3);part(bg,GN.ico,x,p.y+2.6,z,.2,.3,.2,0,C(0xffa02e));},
 house(b,p,bg){
  const W=C(WALLC).offsetHSL(0,0,(p.v-.5)*.08),ST=C(0x8b9098),WD=C(0x8a5a2b),RF=C(0x8a3b2c),GL=C(0x9fd0ff),BR=C(0x6b4423);
  for(const sg of p.segs){if(sg.door||sg.nr||sg.noCol)continue;const [x,z]=lw(p,sg.cx,sg.cz);part(b,GN.box,x,p.y+(sg.y0+sg.y1)/2,z,sg.w,sg.y1-sg.y0,sg.d,p.ry,W);}
  part(b,GN.box,p.x,p.y-.8,p.z,9.4,1.9,9.4,p.ry,ST);part(b,GN.box,p.x,p.y+.06,p.z,8.2,.12,8.2,p.ry,WD);
  for(const sx of[-1,1])for(const sz of[-1,1]){const [x,z]=lw(p,sx*4.5,sz*4.5);part(b,GN.box,x,p.y+1.8,z,.5,3.6,.5,p.ry,BR);}
  for(let i=0;i<4;i++)part(b,GN.box,p.x,p.y+4.05+i*.8,p.z,10.6-i*2.5,.9,10.6-i*2.5,p.ry,RF);
  for(const sx of[-1,1]){const [x,z]=lw(p,sx*4.52,0);part(b,GN.box,x,p.y+2,z,.1,1,1.4,p.ry,GL);}
  let [x,z]=lw(p,0,-4.52);part(b,GN.box,x,p.y+2,z,1.4,1,.1,p.ry,GL);
  [x,z]=lw(p,-3,-3);part(b,GN.box,x,p.y+.4,z,1.7,.5,2.5,p.ry,C(0xa83a3a));[x,z]=lw(p,-3,-3.95);part(b,GN.box,x,p.y+.75,z,1.4,.2,.6,p.ry,C(0xf4f4f4));
  [x,z]=lw(p,2.6,-2.8);part(b,GN.box,x,p.y+.8,z,1.7,.1,1.1,p.ry,WD);for(const [a,c] of [[-.7,-.4],[.7,-.4],[-.7,.4],[.7,.4]]){const [x2,z2]=lw(p,2.6+a,-2.8+c);part(b,GN.box,x2,p.y+.4,z2,.1,.8,.1,p.ry,BR);}
  [x,z]=lw(p,3.4,-.6);part(b,GN.box,x,p.y+.45,z,.9,.9,.7,p.ry,WD);
  [x,z]=lw(p,0,-3.9);part(bg,GN.ico,x,p.y+2.9,z,.2,.2,.2,0,C(0xffd27a));[x,z]=lw(p,0,4.9);part(bg,GN.ico,x+.0,p.y+2.7,z,.14,.2,.14,0,C(0xffa02e));},
 castle(b,p,bg){
  const ST=C(0x9aa0a8).offsetHSL(0,0,(p.v-.5)*.05),DK=C(0x6d737c),RD=C(0x8a2b2b),WD=C(0x8a5a2b);
  for(const sg of p.segs){if(sg.door||sg.nr||sg.noCol)continue;const [x,z]=lw(p,sg.cx,sg.cz);part(b,GN.box,x,p.y+(sg.y0+sg.y1)/2,z,sg.w,sg.y1-sg.y0,sg.d,p.ry,ST);}
  part(b,GN.box,p.x,p.y-1.4,p.z,29.8,3,29.8,p.ry,DK);part(b,GN.box,p.x,p.y+.05,p.z,26.8,.1,26.8,p.ry,C(0x7d838b));
  let [x,z]=lw(p,0,-6);part(b,GN.box,x,p.y+.12,z,9,.1,9,p.ry,WD);
  for(const sx of[-1,1])for(const sz of[-1,1]){[x,z]=lw(p,sx*14,sz*14);part(b,GN.cyl,x,p.y+5.5,z,3.3,11,3.3,0,ST);part(b,GN.cyl,x,p.y+11.2,z,3.7,.8,3.7,0,DK);part(b,GN.cone,x,p.y+13.4,z,3.7,4.2,3.7,0,RD);}
  for(let i=-12;i<=12;i+=2){[x,z]=lw(p,i,-13.4);part(b,GN.box,x,p.y+7.55,z,1.1,1.1,1.2,p.ry,ST);if(Math.abs(i)>3){[x,z]=lw(p,i,13.4);part(b,GN.box,x,p.y+7.55,z,1.1,1.1,1.2,p.ry,ST);}[x,z]=lw(p,-13.4,i);part(b,GN.box,x,p.y+7.55,z,1.2,1.1,1.1,p.ry,ST);[x,z]=lw(p,13.4,i);part(b,GN.box,x,p.y+7.55,z,1.2,1.1,1.1,p.ry,ST);}
  [x,z]=lw(p,0,14.05);part(b,GN.box,x,p.y+5.9,z,2.2,1.6,.15,p.ry,RD);
  [x,z]=lw(p,-3,14.2);part(bg,GN.ico,x,p.y+3.4,z,.25,.35,.25,0,C(0xffa02e));[x,z]=lw(p,3,14.2);part(bg,GN.ico,x,p.y+3.4,z,.25,.35,.25,0,C(0xffa02e));
  for(let i=0;i<3;i++)part(b,GN.box,...lw(p,0,-6).reduce((a,v,k)=>k?a:[v],[]).concat([p.y+8.7+i*.9,lw(p,0,-6)[1],11.4-i*3.2,.95,11.4-i*3.2,p.ry,DK]));
  part(b,GN.cone,lw(p,0,-6)[0],p.y+12.4,lw(p,0,-6)[1],5.6,3.2,5.6,0,RD);
  [x,z]=lw(p,-4.5,-9);part(bg,GN.ico,x,p.y+2.4,z,.2,.2,.2,0,C(0xffd27a));[x,z]=lw(p,4.5,-9);part(bg,GN.ico,x,p.y+2.4,z,.2,.2,.2,0,C(0xffd27a));},
 well(b,p,bg){part(b,GN.cyl,p.x,p.y+.5,p.z,1.2,1,1.2,0,C(0x8b9098));part(bg,GN.cyl,p.x,p.y+.95,p.z,.95,.05,.95,0,C(0x2c98d8));part(b,GN.cyl,p.x-1,p.y+1.6,p.z,.07,1.8,.07,0,C(0x6b4423));part(b,GN.cyl,p.x+1,p.y+1.6,p.z,.07,1.8,.07,0,C(0x6b4423));},
 rockwall(b,p){const c=C(0x3a3d46).offsetHSL(0,0,(p.v-.5)*.06);part(b,GN.dode,p.x,p.y+p.s*.55,p.z,p.s,p.s*.9,p.s,p.v*6,c);part(b,GN.dode,p.x,p.y+p.s*1.5,p.z,p.s*.8,p.s*.8,p.s*.8,p.v*3,c);},
 stalag(b,p){part(b,GN.cone,p.x,p.y+p.s*.8,p.z,p.s*.35,p.s*1.6,p.s*.35,p.v*6,C(0x6a6f78));},
 crystal(b,p,bg){part(b,GN.dode,p.x,p.y+.4,p.z,.8,.6,.8,p.v*6,C(0x4a4e58));for(let i=0;i<3;i++)part(bg,GN.ico,p.x+Math.cos(i*2.1)*.3,p.y+.9+i*.1,p.z+Math.sin(i*2.1)*.3,.16,.55,.16,0,C(i%2?0xb48cff:0x5fe9ff));},
 mush(b,p,bg){part(b,GN.cyl,p.x,p.y+.2,p.z,.05,.4,.05,0,C(0xeeeeee));part(bg,GN.ico,p.x,p.y+.45,p.z,.2,.12,.2,0,C(0x7dffb0));},
 portal(b,p,bg){const g=C(0x5de6b0);part(bg,GN.cyl,p.x-1.5,p.y+1.6,p.z,.18,3.2,.18,0,g);part(bg,GN.cyl,p.x+1.5,p.y+1.6,p.z,.18,3.2,.18,0,g);part(bg,GN.box,p.x,p.y+3.3,p.z,3.4,.2,.2,0,g);part(bg,GN.box,p.x,p.y+1.6,p.z,2.8,3,.05,0,C(0x1f7a5a));}
};
const PCOL=[0xff6b8b,0xffd23d,0xffffff,0xb48cff,0xff9a3d];
const SOLID={tree:.55,rock:0,ore:0,cactus:.5,basalt:.7,deadtree:.5};
const bpCh=new Set();
function buildChunk(cx,cz){
 const n=RES+1,pos=new Float32Array(n*n*3),col=new Float32Array(n*n*3),idx=[];const c=new T.Color();
 for(let j=0;j<n;j++)for(let i=0;i<n;i++){
  const x=cx*CH+i*CH/RES,z=cz*CH+j*CH/RES,h=heightAt(x,z),k=j*n+i;
  pos[k*3]=x;pos[k*3+1]=h;pos[k*3+2]=z;groundCol(x,z,h,c);col[k*3]=c.r;col[k*3+1]=c.g;col[k*3+2]=c.b;
 }
 for(let j=0;j<RES;j++)for(let i=0;i<RES;i++){const a=j*n+i,b=a+1,d=a+n,e=d+1;idx.push(a,d,b,b,d,e);}
 const g=new T.BufferGeometry();g.setAttribute('position',new T.BufferAttribute(pos,3));g.setAttribute('color',new T.BufferAttribute(col,3));g.setIndex(idx);g.computeVertexNormals();
 const terrain=new T.Mesh(g,terrMat);terrain.receiveShadow=true;terrain.castShadow=true;scene.add(terrain);
 const rng=mulberry(hashStr(cx+','+cz)^(SEED*7919));let props=[];
 for(let k=0;k<46;k++){
  const x=cx*CH+rng()*CH,z=cz*CH+rng()*CH,h=heightAt(x,z),dn=fbm(x*.02+500,z*.02+500,3),r=rng(),v=rng();
  if(h<1.1||h>40)continue;
  const type=WT.pick(h,dn,r,v);if(!type)continue;
  const s=.8+v*.8;
  const p={id:k,type,x,y:h,z,s,v,hp:({tree:6,bush:2,cactus:5,basalt:12,deadtree:6,deadbush:1,flower:0,cave:0,lava:0})[type]??8,pine:WT.snowy||h>15||dn>.62,snowy:WT.snowy,rc:WT.rock,col:PCOL[Math.floor(v*5)%5],solid:type in SOLID,r:(SOLID[type]||.8*s)||.8*s,ry:rng()*6.28};
  if(type==='lava')p.r=1.6+v*1.6;
  if(type==='cave'){p.cid=hashStr(cx+','+cz+','+k+SEED)%900+1;}
  if(deadSet.has(cx+','+cz+','+k))p.dead=true;
  props.push(p);
 }
 let vill=null,nid=1100;
 const placeB=(type,x,z,ry)=>{
  const R=type==='house'?4.5:type==='castle'?12:0,hs=[[0,0],[1,1],[1,-1],[-1,1],[-1,-1]].map(o=>heightAt(x+o[0]*R,z+o[1]*R));
  const mx=Math.max(...hs),mn=Math.min(...hs);
  if(mx-mn>(type==='house'?1.2:2.2)||mn<1.4)return null;
  const p={id:nid++,type,x,y:mx,z,s:1,v:rng(),ry,hp:9999,unb:1,solid:false,r:0};setupBuilding(p);return p;};
 const cl=(x,z,R)=>{props=props.filter(p=>Math.hypot(p.x-x,p.z-z)>R);};
 if(WT.village&&rng()<WT.village*1.6){
  const vx=cx*CH+CH/2+(rng()-.5)*4,vz=cz*CH+CH/2+(rng()-.5)*4,vh=heightAt(vx,vz);
  if(vh>1.4&&vh<16){
   const hs=[];[[15,0],[-15,0],[0,15],[0,-15]].forEach(o=>{const p=placeB('house',vx+o[0],vz+o[1],Math.atan2(-o[0],-o[1]));if(p)hs.push(p);});
   if(hs.length>=2){
    cl(vx,vz,22);for(const h of hs)props.push(h);
    props.push({id:1001,type:'well',x:vx,y:vh,z:vz,s:1,v:.5,hp:9999,unb:1,solid:true,r:1.4,ry:0});
    vill=[[vx+4,vz+3],[vx-4,vz-4],[vx+3,vz-5],[vx-5,vz+4]].slice(0,2+hs.length);
   }
  }
 }else if(WTK!=='nether'&&rng()<.035){
  const p=placeB('castle',cx*CH+CH/2,cz*CH+CH/2,Math.floor(rng()*4)*Math.PI/2);
  if(p){cl(p.x,p.z,24);props.push(p);}
 }
 for(const p of props){if(p.type==='cave'){p.ry=Math.floor(p.v*4)*Math.PI/2;setupBuilding(p);}}
 const ch={cx,cz,terrain,props,pm:null,lm:null,vill,vEnts:[],doors:[],bps:[],boxes:[]};
 for(const p of props){if(p.segs){ch.bps.push(p);for(const b of p.boxes)ch.boxes.push(b);}}
 {const BR=b=>b.type==='castle'?20:9.5,isB=b=>b.type==='house'||b.type==='castle';
  const mine=ch.bps.filter(isB);if(ch.bps.length)bpCh.add(ch);
  const bl=[];for(const c2 of bpCh)for(const b of c2.bps)if(isB(b))bl.push(b);
  if(bl.length)ch.props=ch.props.filter(q=>q.segs||bl.every(b=>Math.hypot(q.x-b.x,q.z-b.z)>BR(b)+(q.r||0)));
  if(mine.length)for(const [k2,c2] of chunks){if(c2===ch||Math.abs(c2.cx-cx)>1||Math.abs(c2.cz-cz)>1)continue;const n0=c2.props.length;c2.props=c2.props.filter(q=>q.segs||mine.every(b=>Math.hypot(q.x-b.x,q.z-b.z)>BR(b)+(q.r||0)));if(c2.props.length!==n0)rebuildProps(c2);}}
 makeDoors(ch);rebuildProps(ch);return ch;
}
function rebuildProps(ch){
 if(ch.pm){scene.remove(ch.pm);ch.pm.geometry.dispose();ch.pm=null;}
 if(ch.lm){scene.remove(ch.lm);ch.lm.geometry.dispose();ch.lm=null;}
 const b={p:[],c:[]},bg={p:[],c:[]};for(const p of ch.props){if(!p.dead&&ADD[p.type])ADD[p.type](b,p,bg);}
 if(b.p.length){ch.pm=bufMesh(b,propMat);ch.pm.castShadow=true;ch.pm.receiveShadow=true;scene.add(ch.pm);}
 if(bg.p.length){ch.lm=bufMesh(bg,glowMat);scene.add(ch.lm);}
}
function dropChunk(k){const ch=chunks.get(k);bpCh.delete(ch);scene.remove(ch.terrain);ch.terrain.geometry.dispose();if(ch.pm){scene.remove(ch.pm);ch.pm.geometry.dispose();}if(ch.lm){scene.remove(ch.lm);ch.lm.geometry.dispose();}for(const e of ch.vEnts)removeEnt(e);for(const d of ch.doors)scene.remove(d.mesh);chunks.delete(k);}
function updateChunks(px,pz,budget){
 const pcx=Math.floor(px/CH),pcz=Math.floor(pz/CH),need=[];
 for(let dz=-RAD;dz<=RAD;dz++)for(let dx=-RAD;dx<=RAD;dx++){const d=dx*dx+dz*dz;if(d>(RAD+.5)*(RAD+.5))continue;const k=(pcx+dx)+','+(pcz+dz);if(!chunks.has(k))need.push([d,pcx+dx,pcz+dz,k]);}
 need.sort((a,b)=>a[0]-b[0]);
 for(let i=0;i<need.length&&i<budget;i++){const ch=buildChunk(need[i][1],need[i][2]);chunks.set(need[i][3],ch);if(ch.vill)for(const v of ch.vill)ch.vEnts.push(spawnEnt('villager',v[0],v[1]));}
 for(const [k,ch] of chunks){if(Math.max(Math.abs(ch.cx-pcx),Math.abs(ch.cz-pcz))>RAD+1)dropChunk(k);}
}
function clearWorld(){for(const k of Array.from(chunks.keys()))dropChunk(k);deadSet.clear();}
/* ---- buildings: collision boxes, floors, doors ---- */
const WALLC=0xb58a58;
const SEG=(cx,cz,w,d,y0,y1,col,o)=>Object.assign({cx,cz,w,d,y0,y1,col},o||{});
function lw(p,cx,cz){const c=Math.cos(p.ry||0),s=Math.sin(p.ry||0);return [p.x+cx*c+cz*s,p.z-cx*s+cz*c];}
function worldBox(p,sg){const hw=sg.w/2,hd=sg.d/2;let x0=1e9,x1=-1e9,z0=1e9,z1=-1e9;
 for(const [a,b] of [[-hw,-hd],[hw,-hd],[hw,hd],[-hw,hd]]){const [x,z]=lw(p,sg.cx+a,sg.cz+b);x0=Math.min(x0,x);x1=Math.max(x1,x);z0=Math.min(z0,z);z1=Math.max(z1,z);}
 return {x0,x1,z0,z1,y0:p.y+sg.y0,y1:p.y+sg.y1};}
function houseSegs(){const H=3.6,t=.4,h=4.5,dw=.95,W=WALLC;const a=[
 SEG(0,-h+t/2,2*h,t,0,H,W),SEG(-h+t/2,0,t,2*h,0,H,W),SEG(h-t/2,0,t,2*h,0,H,W),
 SEG(-(h+dw)/2,h-t/2,h-dw,t,0,H,W),SEG((h+dw)/2,h-t/2,h-dw,t,0,H,W),SEG(0,h-t/2,2*dw,t,2.7,H,W),
 SEG(0,h-t/2,2*dw,t,0,2.7,W,{door:1,col2:0x6b4423})];
 for(let i=0;i<4;i++){const w=10.6-i*2.5;a.push(SEG(0,0,w,w,3.6+i*.8,4.5+i*.8,0,{noCol:1,nr:1}));}return a;}
function castleSegs(){const T_=1.2,h=14,a=[
 SEG(0,-h+T_/2,2*h,T_,0,7),SEG(-h+T_/2,0,T_,2*h,0,7),SEG(h-T_/2,0,T_,2*h,0,7),
 SEG(-8,h-T_/2,12,T_,0,7),SEG(8,h-T_/2,12,T_,0,7),SEG(0,h-T_/2,4,T_,4.6,7),SEG(0,h-T_/2,4,T_,0,4.6,0,{door:1,col2:0x4a3220,big:1}),
 SEG(0,-11+.25,10,.5,0,8),SEG(-5+.25,-6,.5,10,0,8),SEG(5-.25,-6,.5,10,0,8),
 SEG(-3,-1.25,4,.5,0,8),SEG(3,-1.25,4,.5,0,8),SEG(0,-1.25,2,.5,2.8,8),SEG(0,-1.25,2,.5,0,2.8,0,{door:1,col2:0x6b4423}),
 SEG(0,-6,9,9,8,12,0,{noCol:1,nr:1})];
 for(const sx of[-1,1])for(const sz of[-1,1])a.push(SEG(sx*14,sz*14,6,6,0,11,0,{nr:1}));return a;}
function caveSegs(){return [SEG(-2.6,0,1.8,1.6,0,3.4,0,{nr:1}),SEG(2.6,0,1.8,1.6,0,3.4,0,{nr:1}),SEG(0,-3.2,6.4,3.6,0,4.4,0,{nr:1}),SEG(0,0,3.4,.8,0,3.4,0,{door:1,nr:1,cave:1})];}
function setupBuilding(p){
 p.segs=p.type==='house'?houseSegs():p.type==='castle'?castleSegs():caveSegs();
 p.boxes=[];p.doorsDef=[];
 for(const sg of p.segs){const b=worldBox(p,sg);if(sg.noCol)b.noCol=1;if(sg.door)b.dr=true;p.boxes.push(b);if(sg.door)p.doorsDef.push({sg,b});}
 p.fl=p.type==='house'?[SEG(0,0,8.2,8.2,0,0)]:p.type==='castle'?[SEG(0,0,26.8,26.8,0,0),SEG(0,-6,9,9,0,0)]:[];
 p.fl=p.fl.map(sg=>{const b=worldBox(p,sg);b.y=p.y+.12;return b;});
}
function makeDoorMesh(w,h,col,big){
 const g=new T.Group(),m=new T.Mesh(new T.BoxGeometry(w,h,big?.3:.16),new T.MeshLambertMaterial({color:col,flatShading:true}));m.position.set(w/2,h/2,0);m.castShadow=true;g.add(m);
 for(let i=1;i<(big?4:3);i++){const r=new T.Mesh(new T.BoxGeometry(w*.96,.1,(big?.36:.2)),new T.MeshLambertMaterial({color:0x2a1a10,flatShading:true}));r.position.set(w/2,h*i/(big?4:3),0);g.add(r);}
 const k=new T.Mesh(new T.SphereGeometry(.09,6,5),new T.MeshLambertMaterial({color:0xd9b34a}));k.position.set(w-.2,h*.45,big?.2:.12);g.add(k);return g;}
function makeDoors(ch){
 for(const p of ch.bps){
  for(const d of p.doorsDef){
   const sg=d.sg,[cx,cz]=lw(p,sg.cx,sg.cz),o={kind:sg.cave?'cave':'door',p,x:cx,z:cz,open:0,t:0,w:sg.w,h:sg.y1,b:d.b};
   if(sg.cave){o.mesh=makeDoorMesh(3.2,3.3,0x4a4e58,true);o.mesh.children[0].position.x=0;o.mesh.position.set(cx,p.y,cz);o.mesh.rotation.y=p.ry;for(let i=1;i<o.mesh.children.length-1;i++)o.mesh.children[i].position.x=0;o.mesh.children[o.mesh.children.length-1].position.x=1.4;p.drObj=o;}
   else{const [hx,hz]=lw(p,sg.cx-sg.w/2,sg.cz);o.hx=hx;o.hz=hz;o.mesh=makeDoorMesh(sg.w,sg.y1,sg.col2||0x6b4423,sg.big);o.mesh.position.set(hx,p.y+.1,hz);o.mesh.rotation.y=p.ry;}
   d.b.d=o;scene.add(o.mesh);ch.doors.push(o);
  }
  if(p.type==='castle'){
   const [x,z]=lw(p,0,-9.6),g=new T.Group(),M=c=>new T.MeshLambertMaterial({color:c,flatShading:true});
   const base=new T.Mesh(new T.BoxGeometry(1.4,.7,.8),M(0x7a4a1e));base.position.y=.4;g.add(base);
   const lid=new T.Group();lid.position.set(0,.75,-.4);const lm=new T.Mesh(new T.BoxGeometry(1.4,.25,.8),M(0x9a6a2e));lm.position.set(0,.12,.4);lid.add(lm);g.add(lid);
   const band=new T.Mesh(new T.BoxGeometry(.15,.78,.85),M(0xd9b34a));band.position.y=.4;g.add(band);
   g.position.set(x,p.y+.12,z);g.rotation.y=p.ry;scene.add(g);ch.doors.push({kind:'chest',p,x,z,mesh:g,lid,opened:false,open:0,t:0});
  }
 }
}
function updateDoors(dt){
 for(const ch of chunks.values())for(const d of ch.doors){
  if(d.kind==='chest'){if(d.t&&d.open<1){d.open=Math.min(1,d.open+dt*2.2);d.lid.rotation.x=-d.open*1.9;}continue;}
  const k=Math.min(1,dt*4);d.open+=(d.t-d.open)*k;if(Math.abs(d.t-d.open)<.01)d.open=d.t;
  if(d.kind==='cave')d.mesh.position.y=d.p.y+d.open*3.1;else d.mesh.rotation.y=d.p.ry+d.open*1.75;
 }
}
function inBoxXZ(b,x,z,r){return x>b.x0-r&&x<b.x1+r&&z>b.z0-r&&z<b.z1+r;}
function boxList(x,z){
 if(!bpCh.size)return null;const cx=Math.floor(x/CH),cz=Math.floor(z/CH);let out=null;
 for(const c of bpCh){if(Math.abs(c.cx-cx)<=1&&Math.abs(c.cz-cz)<=1){if(!out)out=c.boxes;else{if(out===c.boxes)continue;out=out.concat(c.boxes);}}}
 return out;}
function boxBlocked(x,z,r,y){const L=boxList(x,z);if(!L)return false;for(const b of L){if(b.noCol||(b.d&&b.d.open>.5))continue;if(y!==undefined&&(y>b.y1||y+1.5<b.y0))continue;if(inBoxXZ(b,x,z,r))return true;}return false;}
function pushOutBoxes(P,r){
 const L=boxList(P.x,P.z);if(!L)return;
 for(const b of L){if(b.noCol||(b.d&&b.d.open>.5))continue;if(P.y>b.y1-.3||P.y+1.7<b.y0)continue;
  const cx=clamp(P.x,b.x0,b.x1),cz=clamp(P.z,b.z0,b.z1),dx=P.x-cx,dz=P.z-cz,d=Math.hypot(dx,dz);
  if(d<r){if(d>.001){P.x=cx+dx/d*r;P.z=cz+dz/d*r;}else{const l=P.x-b.x0,rr=b.x1-P.x,t=P.z-b.z0,bb=b.z1-P.z,m=Math.min(l,rr,t,bb);if(m===l)P.x=b.x0-r;else if(m===rr)P.x=b.x1+r;else if(m===t)P.z=b.z0-r;else P.z=b.z1+r;}}}
}
function hAt(x,z){
 if(Cave.on)return Cave.y;
 let h=heightAt(x,z);
 if(bpCh.size)for(const ch of bpCh)for(const p of ch.bps){if(Math.abs(p.x-x)>26||Math.abs(p.z-z)>26)continue;for(const f of p.fl){if(x>f.x0&&x<f.x1&&z>f.z0&&z<f.z1&&f.y>h)h=f.y;}}
 return h;
}
function eachChunkProp(x,z,fn,all){
 if(Cave.on){for(const p of Cave.cur.props)if(!p.dead&&(all||p.hp>0))fn(p,Cave.cur);return;}
 const pcx=Math.floor(x/CH),pcz=Math.floor(z/CH);
 for(let dz=-1;dz<=1;dz++)for(let dx=-1;dx<=1;dx++){const ch=chunks.get((pcx+dx)+','+(pcz+dz));if(ch)for(const p of ch.props)if(!p.dead&&(all||p.hp>0))fn(p,ch);}
}
const nearProps=(x,z,fn)=>eachChunkProp(x,z,fn,false);
const scanProps=(x,z,fn)=>eachChunkProp(x,z,fn,true);

/* ---- caves (separate underground area) ---- */
const Cave={on:false,id:0,y:-300,R:34,cur:null,cache:new Map()};
const caveLight=new T.PointLight(0xffcf9a,0,34,1.5);scene.add(caveLight);
function genCave(id){
 if(Cave.cache.has(id))return Cave.cache.get(id);
 const cx=6000+(id%40)*160,cz=6000+Math.floor(id/40)*160,rng=mulberry(id*7919+13),R=Cave.R,y0=Cave.y,props=[];let k=0;
 const add=(type,x,z,o)=>props.push(Object.assign({id:k++,type,x,y:y0,z,s:1,v:rng(),hp:0,solid:false,r:.8,ry:0},o||{}));
 const spot=(min)=>{for(let i=0;i<20;i++){const a=rng()*6.283,d=min+rng()*(R-min-6);const x=cx+Math.cos(a)*d,z=cz+Math.sin(a)*d;if(Math.hypot(x-cx,z-(cz-6))>5)return [x,z];}return [cx+12,cz+12];};
 for(let i=0;i<30;i++){const a=i/30*6.2832;add('rockwall',cx+Math.cos(a)*(R+2),cz+Math.sin(a)*(R+2),{s:6+rng()*3,hp:9999,unb:1});}
 for(let i=0;i<14;i++){const [x,z]=spot(8);add('stalag',x,z,{s:1.4+rng()*1.6,hp:9999,unb:1,solid:true,r:.9});}
 for(let i=0;i<16;i++){const [x,z]=spot(7);add('ore',x,z,{s:1,hp:8,solid:true,r:.9});}
 for(let i=0;i<7;i++){const [x,z]=spot(7);add('crystal',x,z,{hp:10,solid:true,r:.8});}
 for(let i=0;i<3;i++){const [x,z]=spot(12);add('lava',x,z,{r:2.5+rng()*2});}
 for(let i=0;i<10;i++){const [x,z]=spot(5);add('mush',x,z,{});}
 add('portal',cx,cz-6,{});
 const g=new T.Group(),M=col=>new T.MeshLambertMaterial({color:col,flatShading:true});
 const fl=new T.Mesh(new T.CircleGeometry(R+4,28),M(0x3a3d46));fl.rotation.x=-Math.PI/2;fl.position.set(cx,y0,cz);
 const ce=new T.Mesh(new T.CircleGeometry(R+14,28),M(0x2b2e36));ce.rotation.x=Math.PI/2;ce.position.set(cx,y0+10,cz);
 const wl=new T.Mesh(new T.CylinderGeometry(R+3,R+3,10,24,1,true),new T.MeshLambertMaterial({color:0x2e3138,side:T.BackSide}));wl.position.set(cx,y0+5,cz);
 g.add(fl,ce,wl);
 const o={cx,cz,props,pm:null,lm:null,shell:g,vill:null,vEnts:[]};Cave.cache.set(id,o);return o;
}
function caveEnv(on){for(const m of [sky,water,clouds,sunMesh,moonMesh,stars])m.visible=!on;}
function enterCave(p){
 if(Cave.on||P.caveCd>0)return;
 const cv=genCave(p.cid||1);
 P.ret={x:p.x,z:p.z,ry:p.ry||0};Cave.on=true;Cave.id=p.cid||1;Cave.cur=cv;
 scene.add(cv.shell);rebuildProps(cv);caveEnv(true);
 for(const e of ents.slice())removeEnt(e);
 P.x=cv.cx;P.z=cv.cz;P.y=Cave.y;P.vy=0;P.swim=false;P.caveCd=2.5;setSwimUI(false);
 toast('دخلت الكهف');beep(120,.4,'sawtooth',.05);
}
function exitCave(){
 const cv=Cave.cur;if(!cv)return;
 scene.remove(cv.shell);if(cv.pm){scene.remove(cv.pm);cv.pm=null;}if(cv.lm){scene.remove(cv.lm);cv.lm=null;}
 Cave.on=false;caveEnv(false);caveLight.intensity=0;
 for(const e of ents.slice())removeEnt(e);
 const r=P.ret||{x:0,z:0,ry:0};P.x=r.x+Math.sin(r.ry)*3.6;P.z=r.z+Math.cos(r.ry)*3.6;P.y=heightAt(P.x,P.z);P.vy=0;P.caveCd=2.5;
 toast('خرجت من الكهف');
}


