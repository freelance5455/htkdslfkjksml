'use strict';
/* ================= noise / world ================= */
let SEED=1;
function rnd2(ix,iz){let h=(Math.imul(ix,374761393)+Math.imul(iz,668265263)+Math.imul(SEED,1274126177))|0;h=Math.imul(h^(h>>>13),1274126177);h^=h>>>16;return (h>>>0)/4294967296;}
function vnoise(x,z){const ix=Math.floor(x),iz=Math.floor(z),fx=x-ix,fz=z-iz;const u=fx*fx*(3-2*fx),v=fz*fz*(3-2*fz);
 return lerp(lerp(rnd2(ix,iz),rnd2(ix+1,iz),u),lerp(rnd2(ix,iz+1),rnd2(ix+1,iz+1),u),v);}
function fbm(x,z,o){let a=1,f=1,s=0,n=0;for(let i=0;i<(o||4);i++){s+=vnoise(x*f,z*f)*a;n+=a;a*=.5;f*=2;}return s/n;}
function ravD(x,z){
 return 0; /* ravines disabled by request */
 if(WT.islands||WT.flatw)return 0;
 const r=Math.abs(fbm(x*.011+500,z*.011-200,3)-.5);const w=.014;
 return r<w?Math.pow(1-r/w,1.6)*10:0;
}
const hsh2=(a,b)=>{const s=Math.sin(a*12.9898+b*78.233)*43758.5453;return s-Math.floor(s);};
function heightAt(x,z){
 const b=fbm(x*.007+100,z*.007+100,4), m=fbm(x*.03,z*.03,3),A=WT.amp||1;
 const mount=Math.max(0,fbm(x*.005-300,z*.005-300,3)-.56)*150;
 if(WT.islands){const S=WT.islands.s,cx=Math.round(x/S),cz=Math.round(z/S),hh=hsh2(cx,cz);const ix=cx*S+(hsh2(cz,cx)-.5)*S*.25,iz=cz*S+(hsh2(cx+7,cz-3)-.5)*S*.25;
  const R=WT.islands.r*(.65+hh*.55),r=Math.hypot(x-ix,z-iz);if(r>=R)return -80;const k=1-Math.pow(r/R,2);return k*WT.islands.h*(.6+hh*.7)+(m-.5)*3*k+.4;}
 let h=(b-.5)*46*A+(m-.5)*7+mount*A;
 if(WT.volc)h+=volcAdd(x,z);
 if(WT.inv)h=-h+4;
 if(h>1.5){const c=Math.min(ravD(x,z),h-1);h-=c;}
 return h;
}
function hashStr(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return h>>>0;}
function mulberry(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;}}

