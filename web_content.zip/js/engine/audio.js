'use strict';
/* ================= audio ================= */
let AC=null;
function acx(){try{if(!AC)AC=new (window.AudioContext||window.webkitAudioContext)();return AC;}catch(e){return null;}}
function noiseBurst(d,vol,freq,type,q){try{const A=acx();if(!A)return;const n=Math.max(1,(A.sampleRate*d)|0),buf=A.createBuffer(1,n,A.sampleRate),a=buf.getChannelData(0);for(let i=0;i<n;i++)a[i]=(Math.random()*2-1)*Math.pow(1-i/n,2);
 const s=A.createBufferSource();s.buffer=buf;const f=A.createBiquadFilter();f.type=type||'bandpass';f.frequency.value=freq||1000;f.Q.value=q||1;const g=A.createGain();g.gain.value=vol||.1;s.connect(f);f.connect(g);g.connect(A.destination);s.start();}catch(e){}}
function slide(f0,f1,d,type,vol){try{const A=acx();if(!A)return;const o=A.createOscillator(),g=A.createGain();o.type=type||'sawtooth';o.frequency.setValueAtTime(f0,A.currentTime);o.frequency.exponentialRampToValueAtTime(Math.max(20,f1),A.currentTime+d);g.gain.value=vol||.05;g.gain.exponentialRampToValueAtTime(.0001,A.currentTime+d);o.connect(g);g.connect(A.destination);o.start();o.stop(A.currentTime+d);}catch(e){}}
let _sfxT={};
function sfx(k,v){const n=performance.now();if(_sfxT[k]&&n-_sfxT[k]<(k==='step'?120:60))return;_sfxT[k]=n;
 switch(k){
  case 'wood':noiseBurst(.1,.16,800,'bandpass',2);beep(130,.09,'square',.05);break;
  case 'crack':noiseBurst(.4,.2,500,'bandpass',1);slide(220,60,.35,'sawtooth',.06);setTimeout(()=>noiseBurst(.25,.12,300,'lowpass'),260);break;
  case 'stone':noiseBurst(.07,.14,2600,'bandpass',3);beep(760,.05,'triangle',.04);break;
  case 'place':beep(210,.07,'square',.05);noiseBurst(.05,.08,700);break;
  case 'break':noiseBurst(.14,.16,900,'bandpass',1.5);beep(150,.09,'square',.04);break;
  case 'step':noiseBurst(.045,.05,v||600,'bandpass',1.2);break;
  case 'splash':noiseBurst(.35,.14,1400,'bandpass',.8);break;
  case 'hurt':slide(240,90,.18,'sawtooth',.07);noiseBurst(.08,.1,500);break;
  case 'groan':slide(130,70,.55,'sawtooth',.05);break;
  case 'roar':slide(120,45,.9,'sawtooth',.09);noiseBurst(.7,.08,200,'lowpass');break;
  case 'coin':beep(988,.07,'triangle',.05);setTimeout(()=>beep(1319,.12,'triangle',.05),70);break;
  case 'click':beep(640,.035,'square',.025);break;
  case 'shot':noiseBurst(.16,.22,2400,'bandpass',.7);slide(180,50,.14,'sawtooth',.08);break;
  case 'bow':noiseBurst(.08,.08,3000,'highpass');slide(500,200,.1,'triangle',.04);break;
  case 'boom':noiseBurst(.7,.32,260,'lowpass');slide(90,30,.6,'sawtooth',.1);break;
  case 'rumble':noiseBurst(1.3,.16,110,'lowpass');slide(55,35,1.2,'sawtooth',.05);break;
  case 'door':slide(180,120,.15,'square',.05);noiseBurst(.06,.06,500);break;
  case 'munch':noiseBurst(.06,.1,1800,'bandpass',2);setTimeout(()=>noiseBurst(.06,.1,1500,'bandpass',2),110);break;
  case 'jump':slide(260,420,.09,'triangle',.03);break;
  case 'pop':beep(420,.06,'triangle',.04);break;
  case 'sizzle':noiseBurst(.25,.1,3500,'highpass');break;
 }}
function beep(f,d,type,vol){try{if(!AC)AC=new (window.AudioContext||window.webkitAudioContext)();const o=AC.createOscillator(),g=AC.createGain();o.type=type||'square';o.frequency.value=f;g.gain.value=vol||.04;g.gain.exponentialRampToValueAtTime(.0001,AC.currentTime+d);o.connect(g);g.connect(AC.destination);o.start();o.stop(AC.currentTime+d);}catch(e){}}

