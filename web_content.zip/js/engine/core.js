'use strict';

'use strict';
const T=THREE;
const $=id=>document.getElementById(id);
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const lerp=(a,b,t)=>a+(b-a)*t;
const C=h=>new T.Color(h);

