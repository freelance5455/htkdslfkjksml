'use strict';
/* ================= characters ================= */
const mat=(c,em)=>new T.MeshLambertMaterial({color:c,flatShading:true,emissive:0x000000});
function makeChar(k){
 const g=new T.Group(),mats=[];const M=c=>{const m=mat(c);mats.push(m);return m;};
 const sc=k.big?1.12:1;
 const body=new T.Mesh(GM.cyl,M(k.body));body.scale.set(.4,.95,.3);body.position.y=1.2;
 const chest=new T.Mesh(GM.sph,M(k.body));chest.scale.set(.5,.5,.36);chest.position.y=1.5;
 g.add(body,chest);
 if(k.robe){const r=new T.Mesh(new T.CylinderGeometry(.42,.78,1.5,10),M(k.body));r.position.y=.85;g.add(r);}
 const head=new T.Mesh(GM.sph,M(k.skin));head.scale.set(.4,.4,.4);head.position.y=2.0;g.add(head);
 const eyeM=new T.MeshBasicMaterial({color:k.zombie?0xb30000:0x111111});
 for(const sx of[-1,1]){const e=new T.Mesh(GM.sph,eyeM);e.scale.set(.06,.07,.05);e.position.set(.14*sx,2.04,.36);g.add(e);}
 if(k.big){for(const sx of[-1,1]){const e=new T.Mesh(GM.sph,eyeM);e.scale.set(.12,.16,.06);e.position.set(.17*sx,2.04,.34);g.add(e);}}
 const hm=k.hatC!==undefined?M(k.hatC):null;
 if(k.hat==='cap'){const h=new T.Mesh(GM.sph,hm);h.scale.set(.43,.26,.43);h.position.y=2.2;g.add(h);const v=new T.Mesh(GM.cyl,hm);v.scale.set(.26,.04,.2);v.position.set(0,2.16,.4);g.add(v);}
 else if(k.hat==='helm'){const h=new T.Mesh(GM.sph,hm);h.scale.set(.46,.44,.46);h.position.y=2.1;g.add(h);const p=new T.Mesh(GM.cone,M(0xd13b3b));p.scale.set(.08,.4,.08);p.position.y=2.6;g.add(p);}
 else if(k.hat==='band'){const h=new T.Mesh(GM.cyl,hm);h.scale.set(.42,.1,.42);h.position.y=2.1;g.add(h);const t=new T.Mesh(GM.cyl,hm);t.scale.set(.06,.08,.5);t.position.set(.2,2.1,-.4);g.add(t);}
 else if(k.hat==='cone'){const h=new T.Mesh(GM.cone,hm);h.scale.set(.5,.9,.5);h.position.y=2.65;g.add(h);const b=new T.Mesh(GM.cyl,hm);b.scale.set(.7,.05,.7);b.position.y=2.2;g.add(b);}
 else if(k.hat==='pirate'){const h=new T.Mesh(GM.sph,hm);h.scale.set(.62,.3,.4);h.position.y=2.25;g.add(h);const s=new T.Mesh(GM.ico,M(0xffffff));s.scale.set(.1,.1,.02);s.position.set(0,2.27,.38);g.add(s);}
 else if(k.hat==='crown'){const h=new T.Mesh(new T.CylinderGeometry(.34,.4,.22,6),hm);h.position.y=2.42;g.add(h);for(let i=0;i<5;i++){const a=i/5*6.283;const t=new T.Mesh(GM.cone,hm);t.scale.set(.07,.2,.07);t.position.set(Math.cos(a)*.34,2.62,Math.sin(a)*.34);g.add(t);}}
 else if(k.hat==='antenna'){const a=new T.Mesh(GM.cyl,M(0x888888));a.scale.set(.03,.35,.03);a.position.y=2.55;g.add(a);const b=new T.Mesh(GM.sph,hm);b.scale.set(.09,.09,.09);b.position.y=2.76;g.add(b);}
 const mkLimb=(x,y,len,r,col,ball)=>{const p=new T.Group();p.position.set(x,y,0);const m=new T.Mesh(GM.cyl,M(col));m.scale.set(r,len,r);m.position.y=-len/2;p.add(m);const f=new T.Mesh(GM.sph,M(ball));f.scale.set(r*1.2,r*1.2,r*1.2);f.position.y=-len;p.add(f);g.add(p);return p;};
 const armL=mkLimb(-.56,1.62,.8,.14,k.body,k.skin),armR=mkLimb(.56,1.62,.8,.14,k.body,k.skin);
 const legL=mkLimb(-.2,.78,.78,.17,k.pants,0x2a2a2a),legR=mkLimb(.2,.78,.78,.17,k.pants,0x2a2a2a);
 const hold=new T.Group();hold.position.y=-.8;armR.add(hold);
 g.scale.setScalar(sc);
 g.traverse(o=>{if(o.isMesh)o.castShadow=true;});
 return {g,armL,armR,legL,legR,hold,mats,head};
}
function heldMesh(id){
 const g=new T.Group();const M=c=>new T.MeshLambertMaterial({color:c,flatShading:true});
 if(id==='sword'){const b=new T.Mesh(GM.cyl,M(0xdfe6f0));b.scale.set(.06,.95,.02);b.position.y=-.5;g.add(b);const gd=new T.Mesh(GM.cyl,M(0xc9a23a));gd.scale.set(.2,.05,.06);gd.position.y=-.05;g.add(gd);}
 else if(id==='axe'){const h=new T.Mesh(GM.cyl,M(0x7a5232));h.scale.set(.05,.9,.05);h.position.y=-.4;g.add(h);const hd=new T.Mesh(GM.ico,M(0xaab3bf));hd.scale.set(.28,.2,.05);hd.position.set(.2,-.75,0);g.add(hd);}
 else if(id==='bow'){const a=new T.Mesh(new T.TorusGeometry(.45,.035,5,12,Math.PI),M(0x8a5a2b));a.rotation.z=-Math.PI/2;a.rotation.y=Math.PI/2;a.position.y=-.45;g.add(a);const s=new T.Mesh(GM.cyl,M(0xeeeeee));s.scale.set(.01,.9,.01);s.position.y=-.45;g.add(s);}
 else if(id==='gun'){const a=new T.Mesh(GM.cyl,M(0x30343c));a.scale.set(.07,.5,.07);a.position.y=-.35;g.add(a);const b=new T.Mesh(GM.cyl,M(0x5a3b22));b.scale.set(.08,.22,.08);b.position.set(0,-.15,-.12);b.rotation.x=.4;g.add(b);}
 return g;
}

