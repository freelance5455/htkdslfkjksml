"use strict";

window.WindowManager = {

    windows: new Map(),
    nextId: 1,
    zIndex: 100,

    create(options = {}) {

        const id = "window-" + this.nextId++;

        const win = document.createElement("div");

        win.className = "nexora-window";

        win.dataset.windowId = id;

        win.style.left = (options.x ?? 120) + "px";
        win.style.top = (options.y ?? 80) + "px";
        win.style.width = (options.width ?? 650) + "px";
        win.style.height = (options.height ?? 450) + "px";
        win.style.zIndex = ++this.zIndex;

        const icon = options.icon ?? "◈";
        const title = options.title ?? "Nexora App";

        win.innerHTML = `
            <div class="window-titlebar">

                <div class="window-icon">
                    ${icon}
                </div>

                <div class="window-title">
                    ${title}
                </div>

                <div class="window-controls">

                    <button
                        class="window-button minimize"
                        type="button"
                        aria-label="Minimize"
                    >−</button>

                    <button
                        class="window-button maximize"
                        type="button"
                        aria-label="Maximize"
                    >□</button>

                    <button
                        class="window-button close"
                        type="button"
                        aria-label="Close"
                    >×</button>

                </div>

            </div>

            <div class="window-content"></div>

            <div class="window-resize resize-n"></div>
            <div class="window-resize resize-s"></div>
            <div class="window-resize resize-e"></div>
            <div class="window-resize resize-w"></div>

            <div class="window-resize resize-ne"></div>
            <div class="window-resize resize-nw"></div>
            <div class="window-resize resize-se"></div>
            <div class="window-resize resize-sw"></div>
        `;

        const content = win.querySelector(".window-content");

        if (options.content instanceof HTMLElement) {
            content.appendChild(options.content);
        } else {
            content.innerHTML = options.content ?? "";
        }

        const desktop = document.getElementById("desktop");

        if (!desktop) {
            console.error("Nexora: desktop not found.");
            return null;
        }

        desktop.appendChild(win);

        const data = {

            id,

            appId: options.appId ?? id,

            element: win,

            title,

            icon,

            maximized: false,

            minimized: false,

            taskbarItem: null,

            oldPosition: null,

            minWidth: options.minWidth ?? 280,

            minHeight: options.minHeight ?? 180,

            mobile: window.innerWidth <= 700,

            onClose: options.onClose ?? null,

            onFocus: options.onFocus ?? null

        };

        this.windows.set(id, data);

        this.setupButtons(data);
        this.setupDragging(data);
        this.setupResizing(data);
        this.setupFocus(data);
        this.createTaskbarItem(data);

        this.focus(data);

        if (data.mobile) {
            this.applyMobileWindow(data);
        }

        return data;
    },

    applyMobileWindow(data) {

        const win = data.element;

        win.style.left = "8px";
        win.style.top = "8px";
        win.style.width = "calc(100vw - 16px)";
        win.style.height = "calc(100vh - 82px)";

    },

    createTaskbarItem(data) {

        const taskbar = document.getElementById("taskbarApps");

        if (!taskbar) return;

        const button = document.createElement("button");

        button.className = "taskbar-app active";

        button.dataset.windowId = data.id;

        button.title = data.title;

        button.innerHTML = `
            <span class="taskbar-app-icon">
                ${data.icon}
            </span>

            <span class="taskbar-app-title">
                ${data.title}
            </span>
        `;

        button.addEventListener("click", () => {

            if (data.minimized) {

                data.minimized = false;

                data.element.classList.remove("minimized");

            }

            this.focus(data);

        });

        taskbar.appendChild(button);

        data.taskbarItem = button;

    },

    updateTaskbar(data) {

        if (!data.taskbarItem) return;

        data.taskbarItem.classList.toggle(
            "minimized",
            data.minimized
        );

        data.taskbarItem.classList.toggle(
            "active",
            !data.minimized
        );

    },

    setupButtons(data) {

        const win = data.element;

        win.querySelector(".close").addEventListener(
            "click",
            event => {

                event.stopPropagation();

                this.close(data);

            }
        );

        win.querySelector(".minimize").addEventListener(
            "click",
            event => {

                event.stopPropagation();

                this.minimize(data);

            }
        );

        win.querySelector(".maximize").addEventListener(
            "click",
            event => {

                event.stopPropagation();

                this.maximize(data);

            }
        );

    },

    setupFocus(data) {

        data.element.addEventListener(
            "pointerdown",
            () => {

                this.focus(data);

            },
            true
        );

    },

    focus(data) {

        if (!data || !data.element) return;

        data.minimized = false;

        data.element.classList.remove("minimized");

        data.element.style.zIndex = ++this.zIndex;

        for (const other of this.windows.values()) {

            if (other.taskbarItem) {

                other.taskbarItem.classList.remove("active");

            }

        }

        if (data.taskbarItem) {

            data.taskbarItem.classList.add("active");

            data.taskbarItem.classList.remove("minimized");

        }

        if (typeof data.onFocus === "function") {

            data.onFocus(data);

        }

    },

    minimize(data) {

        data.minimized = true;

        data.element.classList.add("minimized");

        this.updateTaskbar(data);

    },

    maximize(data) {

        if (!data.maximized) {

            data.oldPosition = {

                left: data.element.style.left,
                top: data.element.style.top,
                width: data.element.style.width,
                height: data.element.style.height

            };

            data.element.classList.add("maximized");

            data.maximized = true;

        } else {

            data.element.classList.remove("maximized");

            if (data.oldPosition) {

                data.element.style.left =
                    data.oldPosition.left;

                data.element.style.top =
                    data.oldPosition.top;

                data.element.style.width =
                    data.oldPosition.width;

                data.element.style.height =
                    data.oldPosition.height;

            }

            data.maximized = false;

        }

        this.focus(data);

    },

    close(data) {

        if (!data) return;

        if (typeof data.onClose === "function") {

            try {
                data.onClose(data);
            } catch (error) {
                console.error(error);
            }

        }

        data.element.classList.add("closing");

        setTimeout(() => {

            data.element.remove();

            if (data.taskbarItem) {
                data.taskbarItem.remove();
            }

            this.windows.delete(data.id);

        }, 160);

    },

    findByAppId(appId) {

        for (const data of this.windows.values()) {

            if (data.appId === appId) {

                return data;

            }

        }

        return null;

    },

    get(id) {

        return this.windows.get(id) ?? null;

    },

    closeAll() {

        for (const data of [...this.windows.values()]) {

            this.close(data);

        }

    },

    setupDragging(data) {

        const win = data.element;
        const titlebar = win.querySelector(".window-titlebar");

        let dragging = false;

        let pointerId = null;

        let offsetX = 0;
        let offsetY = 0;

        titlebar.addEventListener(
            "pointerdown",
            event => {

                if (event.target.closest(".window-button")) {
                    return;
                }

                if (data.maximized) {
                    return;
                }

                if (event.pointerType === "mouse" && event.button !== 0) {
                    return;
                }

                dragging = true;

                pointerId = event.pointerId;

                const rect = win.getBoundingClientRect();

                offsetX =
                    event.clientX - rect.left;

                offsetY =
                    event.clientY - rect.top;

                titlebar.setPointerCapture(pointerId);

                this.focus(data);

                event.preventDefault();

            }
        );

        titlebar.addEventListener(
            "pointermove",
            event => {

                if (!dragging) return;

                if (event.pointerId !== pointerId) return;

                const desktop =
                    document.getElementById("desktop");

                const desktopRect =
                    desktop.getBoundingClientRect();

                const rect =
                    win.getBoundingClientRect();

                let x =
                    event.clientX -
                    desktopRect.left -
                    offsetX;

                let y =
                    event.clientY -
                    desktopRect.top -
                    offsetY;

                const maxX =
                    desktopRect.width -
                    Math.min(rect.width, desktopRect.width);

                const maxY =
                    desktopRect.height -
                    Math.min(rect.height, desktopRect.height);

                x = Math.max(0, Math.min(x, maxX));
                y = Math.max(0, Math.min(y, maxY));

                win.style.left = x + "px";
                win.style.top = y + "px";

            }
        );

        const stop = event => {

            if (!dragging) return;

            if (
                pointerId !== null &&
                event.pointerId !== undefined &&
                event.pointerId !== pointerId
            ) {
                return;
            }

            dragging = false;

            try {
                titlebar.releasePointerCapture(pointerId);
            } catch {}

            pointerId = null;

        };

        titlebar.addEventListener("pointerup", stop);
        titlebar.addEventListener("pointercancel", stop);

        titlebar.addEventListener(
            "dblclick",
            event => {

                if (event.target.closest(".window-button")) {
                    return;
                }

                this.maximize(data);

            }
        );

    },

    setupResizing(data) {

        const win = data.element;

        const handles =
            win.querySelectorAll(".window-resize");

        handles.forEach(handle => {

            let resizing = false;
            let pointerId = null;

            let startX = 0;
            let startY = 0;

            let startLeft = 0;
            let startTop = 0;

            let startWidth = 0;
            let startHeight = 0;

            handle.addEventListener(
                "pointerdown",
                event => {

                    if (data.maximized) return;

                    resizing = true;

                    pointerId =
                        event.pointerId;

                    const rect =
                        win.getBoundingClientRect();

                    const desktop =
                        document
                            .getElementById("desktop")
                            .getBoundingClientRect();

                    startX = event.clientX;
                    startY = event.clientY;

                    startLeft =
                        rect.left -
                        desktop.left;

                    startTop =
                        rect.top -
                        desktop.top;

                    startWidth =
                        rect.width;

                    startHeight =
                        rect.height;

                    handle.setPointerCapture(pointerId);

                    this.focus(data);

                    event.preventDefault();

                }
            );

            handle.addEventListener(
                "pointermove",
                event => {

                    if (!resizing) return;

                    if (event.pointerId !== pointerId) {
                        return;
                    }

                    const dx =
                        event.clientX - startX;

                    const dy =
                        event.clientY - startY;

                    const type =
                        [...handle.classList]
                            .find(x =>
                                x.startsWith("resize-")
                            )
                            ?.replace("resize-", "");

                    let left = startLeft;
                    let top = startTop;

                    let width = startWidth;
                    let height = startHeight;

                    if (type.includes("e")) {
                        width = startWidth + dx;
                    }

                    if (type.includes("s")) {
                        height = startHeight + dy;
                    }

                    if (type.includes("w")) {

                        width =
                            startWidth - dx;

                        left =
                            startLeft + dx;

                    }

                    if (type.includes("n")) {

                        height =
                            startHeight - dy;

                        top =
                            startTop + dy;

                    }

                    width =
                        Math.max(
                            data.minWidth,
                            width
                        );

                    height =
                        Math.max(
                            data.minHeight,
                            height
                        );

                    win.style.left =
                        left + "px";

                    win.style.top =
                        top + "px";

                    win.style.width =
                        width + "px";

                    win.style.height =
                        height + "px";

                }
            );

            const stop = () => {

                resizing = false;
                pointerId = null;

            };

            handle.addEventListener("pointerup", stop);
            handle.addEventListener("pointercancel", stop);

        });

    }

};

window.addEventListener(
    "resize",
    () => {

        for (const data of WindowManager.windows.values()) {

            data.mobile =
                window.innerWidth <= 700;

            if (data.mobile && !data.maximized) {

                WindowManager.applyMobileWindow(data);

            }

        }

    }
);

console.log("Nexora Window Manager loaded.");