/* النسخ الاحتياطي إلى Google Drive عبر Apps Script */
(function(){
  function setupMobileNavigation(){
    const nav=document.querySelector('nav');
    const header=document.querySelector('header');
    if(!nav || !header || document.getElementById('mobileNavToggle')) return;
    const toggle=document.createElement('button');
    toggle.id='mobileNavToggle';
    toggle.type='button';
    toggle.className='mobile-nav-toggle';
    toggle.setAttribute('aria-expanded','false');
    toggle.setAttribute('aria-controls','appMainNav');
    toggle.innerHTML='<span class="menu-icon">☰</span><span>القائمة</span><span class="menu-chevron">⌄</span>';
    nav.id='appMainNav';
    header.insertAdjacentElement('afterend',toggle);
    const setOpen=(open)=>{
      document.body.classList.toggle('mobile-menu-open',open);
      toggle.setAttribute('aria-expanded',String(open));
      toggle.querySelector('.menu-chevron').textContent=open?'⌃':'⌄';
    };
    toggle.addEventListener('click',()=>setOpen(!document.body.classList.contains('mobile-menu-open')));
    nav.addEventListener('click',(e)=>{
      if(e.target.closest('button')) setOpen(false);
    });
    window.addEventListener('resize',()=>{
      if(window.innerWidth>760) setOpen(false);
    });
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',setupMobileNavigation);
  else setupMobileNavigation();
})();
