// =====================================================
// NetEarn Pro
// PREMIUM LOADER
// FINAL STABLE VERSION
//
// FIRESTORE SOURCE:
// users/{uid}.verified
//
// true  → Premium Card OFF
// false → Premium Card ON
//
// IMPORTANT:
// • Only verified field controls Premium Card
// • No verificationStatus
// • No verificationPaid
// • No animation
// • No fade
// • No remove()
// • No re-add()
// • No setTimeout()
// • No interval
// • Back / Forward safe
// • Refresh safe
// =====================================================

import { auth } from "./firebase.js";

import {
    onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";


// =====================================================
// ELEMENTS
// =====================================================

const section =
    document.getElementById("premiumSection");

const card =
    document.getElementById("premiumCard");


// =====================================================
// CACHE
// =====================================================

const LAST_UID_KEY =
    "netearn_last_premium_uid";


function getCacheKey(uid) {

    return (
        "netearn_premium_verified_" +
        uid
    );

}


// =====================================================
// HIDE PREMIUM CARD
// =====================================================

function hideCard() {

    if (section) {

        section.style.setProperty(
            "display",
            "none",
            "important"
        );

        section.style.setProperty(
            "visibility",
            "hidden",
            "important"
        );

    }


    if (card) {

        card.style.setProperty(
            "display",
            "none",
            "important"
        );

        card.style.setProperty(
            "visibility",
            "hidden",
            "important"
        );

    }

}


// =====================================================
// SHOW PREMIUM CARD
// =====================================================

function showCard() {

    if (section) {

        section.style.setProperty(
            "display",
            "block",
            "important"
        );

        section.style.setProperty(
            "visibility",
            "visible",
            "important"
        );

    }


    if (card) {

        card.style.setProperty(
            "display",
            "flex",
            "important"
        );

        card.style.setProperty(
            "visibility",
            "visible",
            "important"
        );

    }

}


// =====================================================
// CACHE READ
// =====================================================

function getCachedState(uid) {

    if (!uid) {

        return null;

    }


    try {

        const value =
            localStorage.getItem(
                getCacheKey(uid)
            );


        if (value === "true") {

            return true;

        }


        if (value === "false") {

            return false;

        }

    }

    catch (error) {

        console.warn(
            "⚠️ Premium cache read failed:",
            error
        );

    }


    return null;

}


// =====================================================
// CACHE SAVE
// =====================================================

function saveCachedState(
    uid,
    verified
) {

    if (!uid) {

        return;

    }


    try {

        localStorage.setItem(
            getCacheKey(uid),
            verified === true
                ? "true"
                : "false"
        );


        localStorage.setItem(
            LAST_UID_KEY,
            uid
        );

    }

    catch (error) {

        console.warn(
            "⚠️ Premium cache save failed:",
            error
        );

    }

}


// =====================================================
// LAST UID
// =====================================================

function getLastUid() {

    try {

        return String(
            localStorage.getItem(
                LAST_UID_KEY
            ) || ""
        ).trim();

    }

    catch (error) {

        return "";

    }

}


// =====================================================
// APPLY STATE
// =====================================================

function applyState(verified) {

    if (verified === true) {

        hideCard();

        return;

    }


    if (verified === false) {

        showCard();

        return;

    }

}


// =====================================================
// INITIAL CACHE RESTORE
// =====================================================

(function restoreCachedState() {

    const lastUid =
        getLastUid();


    if (!lastUid) {

        return;

    }


    const cached =
        getCachedState(lastUid);


    if (cached === null) {

        return;

    }


    applyState(cached);


    console.log(
        cached
            ? "🟢 Cached VERIFIED state restored"
            : "🔴 Cached NOT VERIFIED state restored"
    );

})();


// =====================================================
// RECEIVE DASHBOARD USER DATA
// =====================================================
// Dashboard already loads users/{uid}.verified. Reuse that
// result instead of making a second Firestore request.

function loadPremiumFromUserData(payload) {

    const user = payload?.user || auth.currentUser;
    const data = payload?.data;

    if (!user || !data) {
        return;
    }

    try {
        localStorage.setItem(LAST_UID_KEY, user.uid);
    } catch (error) {
        console.warn("⚠️ UID cache failed:", error);
    }

    const verified = data.verified === true;

    saveCachedState(user.uid, verified);
    applyState(verified);

    console.log(
        verified
            ? "🟢 VERIFIED → Premium OFF"
            : "🔴 NOT VERIFIED → Premium ON"
    );
}

// The dashboard dispatches this event after its single user-document
// read completes. This removes the duplicate Firestore read.
window.addEventListener(
    "netearn:user-data-ready",
    (event) => loadPremiumFromUserData(event.detail),
    { passive: true }
);

// If the dashboard event has not arrived yet, restore cache immediately.
// Do not perform another Firestore read here.
if (auth.currentUser) {
    const cached = getCachedState(auth.currentUser.uid);
    if (cached !== null) {
        applyState(cached);
    }
}

// Keep Firebase auth listener only for logout state. It no longer reads Firestore.
onAuthStateChanged(auth, (user) => {
    if (!user) {
        hideCard();
    }
});


// =====================================================
// VERIFY BUTTON
// =====================================================

window.goVerify =
function () {

    window.location.href =
        "verification-details.html";

};


// =====================================================
// FINAL LOG
// =====================================================

console.log(
    "✅ NetEarn Pro Premium Loader — FINAL STABLE"
);