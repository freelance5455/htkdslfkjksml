/**
 * Snake Escape — Advanced Collision & Puzzle Mechanism Checker
 * Handles boundaries, walls, snakes, gates, bridges, movable blocks, and traps.
 */
(function() {
  'use strict';

  class CollisionSystem {
    /**
     * Checks if coordinate is inside grid boundaries
     */
    isInsideGrid(x, y, grid) {
      return x >= 0 && x < grid.cols && y >= 0 && y < grid.rows;
    }

    /**
     * Checks if coordinate hits any stone wall
     */
    isWall(x, y, walls) {
      if (!walls || !walls.length) return false;
      return walls.some(w => w.x === x && w.y === y);
    }

    /**
     * Checks if coordinate hits a closed gate
     */
    isClosedGate(x, y, gates) {
      if (!gates || !gates.length) return false;
      return gates.some(g => g.x === x && g.y === y && !g.isOpen);
    }

    /**
     * Checks if coordinate is on an inactive bridge (acts as a pit/chasm)
     */
    isInactiveBridge(x, y, bridges) {
      if (!bridges || !bridges.length) return false;
      return bridges.some(b => b.x === x && b.y === y && !b.active);
    }

    /**
     * Retrieves movable block at given coordinates
     */
    getBlockAt(x, y, blocks) {
      if (!blocks || !blocks.length) return null;
      return blocks.find(b => b.x === x && b.y === y) || null;
    }

    /**
     * Checks whether a movable block can be pushed 1 cell further in (dx, dy)
     */
    canPushBlock(block, dx, dy, state) {
      const nextX = block.x + dx;
      const nextY = block.y + dy;
      const { grid, walls, gates, bridges, blocks: allBlocks, snakes } = state;

      // 1. Must be inside grid
      if (!this.isInsideGrid(nextX, nextY, grid)) return false;

      // 2. Cannot push into a wall
      if (this.isWall(nextX, nextY, walls)) return false;

      // 3. Cannot push into a closed gate
      if (this.isClosedGate(nextX, nextY, gates)) return false;

      // 4. Cannot push into an inactive bridge
      if (this.isInactiveBridge(nextX, nextY, bridges)) return false;

      // 5. Cannot push into another block
      if (allBlocks && allBlocks.some(b => b.id !== block.id && b.x === nextX && b.y === nextY)) return false;

      // 6. Cannot push into any snake segment
      if (snakes) {
        for (const s of snakes) {
          if (s.escaped) continue;
          if (s.segments.some(seg => seg.x === nextX && seg.y === nextY)) return false;
        }
      }

      return true;
    }

    /**
     * Checks if coordinate hits another snake or this snake's body
     */
    isBlockedBySnake(x, y, snakes, activeSnakeId) {
      for (const snake of snakes) {
        if (snake.escaped) continue;

        const segments = snake.segments || [];
        for (let i = 0; i < segments.length; i++) {
          const seg = segments[i];
          if (seg.x === x && seg.y === y) {
            // If it's the active snake's tail segment and the snake is moving,
            // the tail will vacate this cell unless trapped
            if (snake.id === activeSnakeId && i === segments.length - 1 && segments.length > 1) {
              continue;
            }
            return true;
          }
        }
      }
      return false;
    }

    /**
     * Retrieves active trap at coordinate (if deadly)
     */
    getDeadlyTrapAt(x, y, traps) {
      if (!traps || !traps.length) return null;
      return traps.find(t => t.x === x && t.y === y && t.state === 'active') || null;
    }

    /**
     * Full move validation check for active snake
     */
    isValidMove(snake, nextX, nextY, state, allSnakes, direction) {
      const { grid, walls, gates, bridges, blocks, traps } = state;

      // 1. Grid boundary
      if (!this.isInsideGrid(nextX, nextY, grid)) {
        return { valid: false, reason: 'boundary' };
      }

      // 2. Wall collision
      if (this.isWall(nextX, nextY, walls)) {
        return { valid: false, reason: 'wall' };
      }

      // 3. Closed gate collision
      if (this.isClosedGate(nextX, nextY, gates)) {
        return { valid: false, reason: 'gate' };
      }

      // 4. Inactive bridge (pit) collision
      if (this.isInactiveBridge(nextX, nextY, bridges)) {
        return { valid: false, reason: 'bridge' };
      }

      // 5. Reversing onto neck (cannot move 180 degrees backward into own neck)
      if (snake.segments && snake.segments.length > 1) {
        const neck = snake.segments[1];
        if (neck && neck.x === nextX && neck.y === nextY) {
          return { valid: false, reason: 'reverse' };
        }
      }

      // 6. Movable Block Check (Sokoban mechanic)
      const block = this.getBlockAt(nextX, nextY, blocks);
      if (block) {
        let dx = 0, dy = 0;
        if (direction === 'UP') dy = -1;
        else if (direction === 'DOWN') dy = 1;
        else if (direction === 'LEFT') dx = -1;
        else if (direction === 'RIGHT') dx = 1;

        if (this.canPushBlock(block, dx, dy, { grid, walls, gates, bridges, blocks, snakes: allSnakes })) {
          return { valid: true, pushBlock: block, pushDx: dx, pushDy: dy };
        } else {
          return { valid: false, reason: 'blocked_block' };
        }
      }

      // 7. Snake collision (cannot crash into other snakes or own body)
      if (this.isBlockedBySnake(nextX, nextY, allSnakes, snake.id)) {
        return { valid: false, reason: 'snake' };
      }

      // Check if moving into a trap
      const trap = this.getDeadlyTrapAt(nextX, nextY, traps);
      if (trap) {
        return { valid: true, hitsTrap: trap };
      }

      return { valid: true };
    }

    /**
     * Check if snake head reached designated exit portal
     */
    hasReachedExit(snakeHead, exitCoord) {
      if (!exitCoord) return false;
      return snakeHead.x === exitCoord.x && snakeHead.y === exitCoord.y;
    }
  }

  window.SnakeEscape = window.SnakeEscape || {};
  window.SnakeEscape.collision = new CollisionSystem();
})();
