/* تب آمار: لیگ و مدال‌ها، نمودار ۷ روزه، مرور هفته، تقویم ۲۸ روزه، زمان هر درس، روند آزمون، تاریخچه‌ی ثبت‌ها با ویرایش، ماه‌به‌ماه، دفترچه و حافظه‌ی مشاور. */
(function () {
  'use strict';
  var App = (window.App = window.App || {});
  var u = App.u;
  var D = App.D;
  var st = App.study;
  var ch = App.chart;
  var gm = App.gamify;
  var S = function () { return App.S; };
  var WD_SHORT = ['ی', 'د', 'س', 'چ', 'پ', 'ج', 'ش'];

  App.views.stat = function () {
    var h = App.upgradeNotice();
    h += leagueCard();
    h += weekCard();
    h += reviewCard();
    h += calendarCard();
    h += subjectCard();
    h += examCard();
    h += historyCard();
    h += medalCard();
    h += monthlyCard();
    h += journalCard();
    h += memoryCard();
    h += dataCard();
    return h;
  };

  // ---- لیگ، کاپ هفتگی و خلاصه ----
  function leagueCard() {
    var L = gm.league();
    var cups = gm.weekCups(4).map(function (w, k) {
      var label = w.cur ? 'این هفته' : (k === 1 ? 'هفته‌ی قبل' : u.jd(w.s, false, false) + ' به بعد');
      return '<div class="li"><span>' + u.esc(label) + '</span><span>' + (w.c ? '<b class="cup">' + w.c + '</b> ' : '') + '<span class="mu">' + u.fa(Math.round(w.r * 100)) + '٪ از هدف هفته</span></span></div>';
    }).join('');
    var nearTxt = gm.nearMedal();
    var body = '<div class="league-top"><div class="big accent" aria-label="لیگ ' + u.esc(L.name) + '">' + L.ic + ' ' + u.esc(L.name) + '</div><div class="mu">' + u.fa(L.x) + ' امتیاز' +
      (L.next != null ? ' · تا لیگ بعد ' + u.fa(L.next - L.x) + ' امتیاز مانده' : ' · بالاترین لیگ') + '</div></div>' +
      App.bar(L.pct, 'league-bar') +
      '<div class="grid3 mt">' + statBox(u.hours(st.recent(7).filter(st.isStudy).reduce(function (a, l) { return a + l.m; }, 0)), 'مطالعه‌ی ۷ روز') +
      statBox(u.fa(st.streak()), 'روز پشت‌سرهم') + statBox(u.fa(st.longestStreak()), 'رکورد زنجیره') + '</div>' +
      '<h3 class="sub-h">کاپ هفتگی</h3>' + cups + (nearTxt ? '<p class="line mt">' + u.esc(nearTxt) + '</p>' : '') +
      '<p class="mu">امتیاز از مطالعه، تست، آزمون، ضعف‌های رفع‌شده، گزارش روزانه و دفترچه ساخته می‌شود.</p>';
    return App.card('🏆 لیگ و کاپ', body, { key: 'stat|league', open: true });
  }
  function statBox(big, label) { return '<div class="inner center"><div class="big">' + big + '</div><div class="mu">' + u.esc(label) + '</div></div>'; }

  // ---- نمودار ۷ روزه و خلاصه ----
  function weekCard() {
    var days = [], vals = [], labels = [];
    for (var k = 6; k >= 0; k--) {
      var iso = u.addDays(u.todayISO(), -k);
      days.push(iso);
      vals.push(st.dayStat(iso).s);
      labels.push(WD_SHORT[new Date(iso + 'T12:00:00').getDay()]);
    }
    var sum = vals.reduce(function (a, b) { return a + b; }, 0);
    var cls = st.dayStat(u.todayISO()).c;
    var week = u.sum(st.recent(7).filter(function (l) { return !st.isStudy(l); }), function (l) { return l.m; });
    var goalWeek = (S().goal || D.DEFAULT_GOAL) * 7;
    return App.card('📊 مطالعه‌ی ۷ روز', ch.bars({ values: vals, labels: labels, goal: S().goal || D.DEFAULT_GOAL, label: 'مطالعه‌ی ۷ روز اخیر' }) +
      '<p class="mu">خط نارنجی هدف روزانه است. جمع مطالعه: ' + u.hm(sum) + ' از هدف ' + u.hm(goalWeek) + ' (' + u.pct(goalWeek ? sum / goalWeek * 100 : 0) + ')؛ کلاس هفته: ' + u.hours(week) + '.</p>' +
      (cls ? '<p class="mu">امروز ' + u.hm(cls) + ' کلاس ثبت شده است.</p>' : ''), { key: 'stat|week', open: true });
  }

  // ---- مرور هفته ----
  function reviewCard() {
    var w = st.weekReview();
    return App.card('🗞 مرور هفته', '<div class="li-list">' + w.L.map(function (x) { return '<div class="line">' + u.esc(x) + '</div>'; }).join('') + '</div>' +
      '<h3 class="sub-h">پیشنهادها</h3>' + w.sg.map(function (x) { return '<div class="line">• ' + u.esc(x) + '</div>'; }).join('') +
      '<div class="q-row mt"><button type="button" class="sm" data-act="week-copy">📋 کپی برای چت دیگر</button>' +
      App.sm('🤖 تحلیل هفته با مشاور', 'ai-ask', { q: 'week', tab: 'stat' }) + '</div>', { key: 'stat|review', open: true });
  }
  App.act['week-copy'] = function () {
    u.copyText(st.weekText()).then(function (ok) { App.toast(ok ? 'مرور هفته کپی شد ✅' : 'کپی انجام نشد'); });
  };

  // ---- تقویم ۲۸ روزه ----
  function calendarCard() {
    var goal = S().goal || D.DEFAULT_GOAL;
    var cells = '';
    var lead = (new Date(u.addDays(u.todayISO(), -27) + 'T12:00:00').getDay() + 1) % 7; // شنبه = ستون اول
    for (var i = 0; i < lead; i++) cells += '<span class="cal-d blank" aria-hidden="true"></span>';
    for (var k = 27; k >= 0; k--) {
      var iso = u.addDays(u.todayISO(), -k);
      var m = st.dayStat(iso).s, r = goal ? m / goal : 0;
      var lvl = m <= 0 ? 0 : r < 0.25 ? 1 : r < 0.5 ? 2 : r < 0.75 ? 3 : r < 1 ? 4 : 5;
      var lab = u.jd(iso, false, true) + ': ' + (m ? u.hm(m) + ' مطالعه' : 'بدون مطالعه');
      cells += '<span class="cal-d l' + lvl + (k === 0 ? ' today' : '') + '" title="' + u.esc(lab) + '" aria-label="' + u.esc(lab) + '">' + u.fa(+u.jparts(iso)[2]) + '</span>';
    }
    var heads = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'].map(function (x) { return '<span class="cal-h" aria-hidden="true">' + x + '</span>'; }).join('');
    return App.card('🗓 تقویم ۲۸ روز', '<div class="cal" role="group" aria-label="تقویم مطالعه ۲۸ روز">' + heads + cells + '</div>' +
      '<div class="legend-row mu">' + [0, 1, 2, 3, 4, 5].map(function (l) { return '<span class="cal-d l' + l + ' sw" aria-hidden="true"></span>'; }).join('') + '<span>کم تا رسیدن به هدف روزانه</span></div>' +
      '<p class="mu">روز پررنگ‌تر یعنی به هدف روزانه نزدیک‌تر بودی. هر روز امروز با خط کادر مشخص شده است.</p>', { key: 'stat|cal', open: true });
  }

  // ---- زمان هر درس (۳۰ روز اخیر) ----
  function subjectCard() {
    var by = {};
    st.recent(30).filter(st.isStudy).forEach(function (l) { by[l.s] = (by[l.s] || 0) + l.m; });
    var items = Object.keys(by).filter(function (k) { return by[k] > 0; }).map(function (k) { return { label: k || 'بدون درس', value: by[k] }; })
      .sort(function (a, b) { return b.value - a.value; }).slice(0, 8);
    return App.card('🥧 زمان هر درس (۳۰ روز)', ch.donut(items) + '<p class="mu">فقط مطالعه‌ی درس‌ها؛ کلاس جداگانه حساب می‌شود.</p>', { key: 'stat|subj', open: false });
  }

  // ---- آزمون: روند، میانگین هر درس، زمان ----
  function examCard() {
    var list = App.exam.trend();
    var line = ch.line(list.slice(-12).map(function (e) { return { label: u.jd(e.d) + ' ' + e.n, y: e.p }; }));
    var avgs = App.exam.subjectAverages();
    var ts = App.exam.timeStats();
    var pr = App.exam.predict();
    var body = line +
      (pr.value != null ? '<div class="predict mt"><b>برآورد تقریبی درصد کنکور: ' + u.fa(Math.round(pr.value)) + '٪</b><div class="mu">' + u.esc(pr.note) + ' این عدد تخمین است، نتیجه‌ی قطعی نیست.</div></div>' : '') +
      (avgs.length ? '<h3 class="sub-h">میانگین هر درس</h3>' + avgs.map(function (x) {
        return '<div class="li"><span>' + u.esc(x.s) + ' <span class="mu">(' + u.fa(x.n) + ' آزمون)</span></span><span>' + u.pct(x.p) + '</span></div>' + App.bar(x.p);
      }).join('') : '') +
      (ts.count ? '<p class="mu mt">میانگین زمان هر سؤال: ' + u.fa(ts.perQuestion) + ' دقیقه · آزمون‌های بالای زمان مجاز: ' + u.fa(ts.overLimit) + '</p>' : '');
    return App.card('🧪 روند آزمون‌ها', body, { key: 'stat|exam', open: true });
  }

  // ---- تاریخچه‌ی ثبت‌ها با ناوبری روز و ویرایش ----
  function historyCard() {
    var f = App.form('hist', { d: u.todayISO() });
    if (!u.isISO(f.d) || f.d > u.todayISO()) f.d = u.todayISO();
    var list = S().logs.filter(function (l) { return l.d === f.d; }).sort(function (a, b) { return b.id - a.id; });
    var rows = list.length ? list.map(function (l) {
      return '<div class="li"><span>' + (l.k === 'c' ? '🏫 کلاس ' : '') + u.esc(l.s || '—') + ' (' + u.esc(D.GN[l.g] || '') + ')' + (l.c ? ' · ' + u.esc(st.chName(l.g, l.s, l.c)) : '') +
        '<br><span class="mu">' + u.fa(l.m) + ' دقیقه · ' + u.fa(l.t) + ' تست' + (l.ok != null ? ' · ✔' + u.fa(l.ok) + '/' + u.fa(l.t) : '') + (l.q ? ' · تمرکز ' + u.fa(l.q) + '/۴' : '') + '</span></span>' +
        '<span class="row0">' + App.sm('✏️', 'log-edit', { key: l.id }, 'icon-btn') + App.sm('🗑', 'log-del', { key: l.id }, 'icon-btn') + '</span></div>';
    }).join('') : '<p class="mu">برای این روز ثبتی نیست.</p>';
    var nav = '<div class="row0 space wrap"><button type="button" class="sm" data-act="hist-nav" data-v="-1" aria-label="روز قبل">→ روز قبل</button>' +
      '<b aria-live="polite">' + u.esc(u.jd(f.d, true, true)) + '</b>' +
      '<button type="button" class="sm" data-act="hist-nav" data-v="1"' + (f.d >= u.todayISO() ? ' disabled' : '') + ' aria-label="روز بعد">روز بعد ←</button></div>';
    return App.card('📒 تاریخچه‌ی ثبت‌ها', nav + rows, { key: 'stat|hist', open: true });
  }
  App.act['hist-nav'] = function (el) {
    var f = App.form('hist', { d: u.todayISO() });
    var next = u.addDays(f.d, +el.getAttribute('data-v') || 0);
    f.d = next > u.todayISO() ? u.todayISO() : next;
    App.render();
  };
  App.act['log-edit'] = function (el) {
    var id = el.getAttribute('data-key');
    var l = S().logs.find(function (x) { return String(x.id) === String(id); });
    if (!l) return;
    var subs = D.subjects(l.g).map(function (x) { return [x.name, x.name]; });
    if (l.s && subs.every(function (x) { return x[0] !== l.s; })) subs.unshift([l.s, l.s]);
    App.openModal('ویرایش ثبت', '<div class="grid2">' +
      '<div class="field"><label for="le-m">دقیقه</label><input id="le-m" type="text" inputmode="numeric" value="' + u.esc(u.pd(l.m || 0)) + '"></div>' +
      '<div class="field"><label for="le-t">تعداد تست</label><input id="le-t" type="text" inputmode="numeric" value="' + u.esc(u.pd(l.t || 0)) + '"></div></div>' +
      '<div class="grid2"><div class="field"><label for="le-ok">درست</label><input id="le-ok" type="text" inputmode="numeric" value="' + u.esc(l.ok != null ? u.pd(l.ok) : '') + '" placeholder="اختیاری"></div>' +
      '<div class="field"><label for="le-s">درس</label><select id="le-s">' + App.opts(subs, l.s) + '</select></div></div>' +
      '<div class="row0 wrap mt"><button type="button" class="btn" data-act="log-edit-save" data-key="' + u.esc(String(l.id)) + '">ذخیره</button><button type="button" class="sm" data-act="close-modal">انصراف</button></div>');
  };
  App.act['log-edit-save'] = function (el) {
    var id = el.getAttribute('data-key');
    var l = S().logs.find(function (x) { return String(x.id) === String(id); });
    if (!l) { App.closeModal(); return; }
    var m = u.int(val('le-m'), 0, 1440, null), t = u.int(val('le-t'), 0, 5000, null);
    var okRaw = val('le-ok');
    var ok = okRaw === '' ? undefined : u.int(okRaw, 0, t == null ? l.t : t, null);
    if (m == null || t == null || (okRaw !== '' && ok == null)) { App.alert('مقدارها را درست وارد کن (ok نباید از تعداد تست بیشتر باشد)'); return; }
    if (!m && !t) { App.alert('زمان یا تعداد تست را وارد کن'); return; }
    l.m = m; l.t = t;
    if (ok === undefined) delete l.ok; else l.ok = ok;
    var sel = document.getElementById('le-s');
    if (sel && sel.value) l.s = sel.value;
    App.save(); App.closeModal(); App.render(); App.toast('ویرایش ذخیره شد');
  };
  function val(id) { var e = document.getElementById(id); return e ? String(e.value || '').trim() : ''; }

  // ---- مدال‌ها ----
  function medalCard() {
    var rows = gm.MEDALS.map(function (m) {
      var k = gm.tierOf(m), v = +m.v() || 0;
      var nx = m.t[k + 1];
      var pct = nx ? Math.min(100, Math.round((v / nx) * 100)) : 100;
      return '<div class="li medal-row"><span><b>' + m.i + ' ' + u.esc(m.n) + '</b> ' + (k >= 0 ? '<span class="pill">' + gm.TIERS[k] + '</span>' : '<span class="mu">هنوز مدال نگرفته‌ای</span>') +
        '<br><span class="mu">' + u.fa(Math.floor(v)) + ' ' + u.esc(m.u) + (nx ? ' · سطح بعد: ' + u.fa(nx) : ' · بالاترین سطح') + '</span></span></div>' + App.bar(pct, 'thin');
    }).join('');
    return App.card('🏅 مدال‌ها', rows, { key: 'stat|medal', open: false });
  }

  // ---- ماه‌به‌ماه ----
  function monthlyCard() {
    var M = st.monthly();
    if (!M.length) return App.card('📆 پیشرفت ماه‌به‌ماه', '<p class="mu">بعد از چند روز ثبت، جدول ماهانه اینجا ظاهر می‌شود.</p>', { key: 'stat|month', open: false });
    var head = '<tr><th scope="col">ماه</th><th scope="col">مطالعه</th><th scope="col">کلاس</th><th scope="col">تست</th><th scope="col">روز فعال</th><th scope="col">آزمون</th><th scope="col">میانگین٪</th></tr>';
    var body = M.map(function (x) {
      return '<tr><th scope="row">' + u.esc(x.month) + '</th><td>' + u.fa(x.study_hours) + '</td><td>' + u.fa(x.class_hours) + '</td><td>' + u.fa(x.tests) + '</td><td>' + u.fa(x.active_days) + '</td><td>' + u.fa(x.exams) + '</td><td>' + (x.avg_exam_percent == null ? '—' : u.fa(x.avg_exam_percent)) + '</td></tr>';
    }).join('');
    return App.card('📆 پیشرفت ماه‌به‌ماه', '<div class="table-wrap"><table class="tbl"><caption class="sr">جمع ماهانه‌ی مطالعه، کلاس، تست و آزمون</caption><thead>' + head + '</thead><tbody>' + body + '</tbody></table></div>', { key: 'stat|month', open: false });
  }

  // ---- دفترچه و حافظه ----
  function journalCard() {
    var list = S().jr.slice().reverse();
    var f = App.form('jr', { k: 'n', t: '' });
    var rows = list.length ? list.map(function (x) {
      return '<div class="li"><span class="mu">' + u.esc(u.jd(x.d, true)) + ' · ' + App.JK(x.k) + '</span>' + App.sm('🗑', 'jr-del', { key: x.id }, 'icon-btn') + '</div><div class="line">' + u.esc(x.t) + '</div>';
    }).join('') : '<p class="mu">هنوز یادداشتی نداری. از تب امروز یا برنامه می‌توانی بنویسی.</p>';
    return App.card('📓 دفترچه‌ی کامل', rows, { key: 'stat|jr', open: false });
  }
  function memoryCard() {
    var list = (S().mem || []).slice().reverse();
    var rows = list.length ? list.map(function (x) {
      return '<div class="li"><span><span class="mu">' + u.esc(u.jd(x.d, true)) + '</span><br>' + u.esc(x.t) + '</span>' + App.sm('🗑', 'mem-del', { key: x.id }, 'icon-btn') + '</div>';
    }).join('') : '<p class="mu">حافظه‌ی مشاور خالی است.</p>';
    return App.card('🧠 حافظه‌ی مشاور', '<p class="mu">چیزهایی که می‌خواهی مشاور همیشه بداند (مثلاً «صبح‌ها کار نمی‌کنم»). هر کدام را بخواهی می‌توانی حذف کنی؛ مشاور فقط وقتی لازم باشد از اینها استفاده می‌کند.</p>' +
      rows + '<label class="field mt" for="mem-in"><span>یادداشت تازه برای مشاور</span></label><textarea id="mem-in" class="ta" maxlength="1200" aria-label="یادداشت تازه برای مشاور"></textarea>' +
      '<div class="q-row"><button type="button" class="sm accent" data-act="mem-add">افزودن به حافظه</button></div>', { key: 'stat|mem', open: false });
  }
  App.act['mem-add'] = function () {
    var r = st.addMemory(val('mem-in'));
    if (!r) { App.alert('متن یادداشت را بنویس'); return; }
    App.save(); App.render(); App.toast('به حافظه‌ی مشاور اضافه شد');
  };
  App.act['mem-del'] = function (el) {
    st.delById(S().mem, el.getAttribute('data-key')); App.save(); App.render();
  };

  // ---- داده‌ها: حجم تقریبی روی دستگاه ----
  function dataCard() {
    var s = S();
    var kb = Math.round(JSON.stringify(s).length / 1024);
    return App.card('🗄 داده‌ها روی این دستگاه', '<div class="grid3">' +
      statBox(u.fa(s.logs.length), 'ثبت مطالعه') + statBox(u.fa(s.exams.length), 'آزمون') + statBox(u.fa(kb), 'کیلوبایت') + '</div>' +
      '<p class="mu mt">داده‌ها فقط در همین مرورگر یا برنامه‌اند. برای نگه‌داری، از تنظیمات یک پشتیبان بگیر.</p>', { key: 'stat|data', open: false });
  }
})();
