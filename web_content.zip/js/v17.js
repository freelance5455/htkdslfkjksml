/* UNKNOWN X V17 — verified puzzle generation engine + playable lab (additive layer; V16 code untouched except 2 registration hooks) */
(function(){"use strict";
const V={};
const rng=seed=>{let a=seed>>>0;return()=>{a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}};
const pick=(r,a)=>a[Math.floor(r()*a.length)];
const shuffle=(r,a)=>{a=a.slice();for(let i=a.length-1;i>0;i--){const j=Math.floor(r()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};
const LV={easy:{n:3,sym:6,obj:4,sus:3,xp:15},normal:{n:4,sym:8,obj:6,sus:4,xp:25},hard:{n:5,sym:8,obj:8,sus:5,xp:40}};
const LVN={easy:"سهل",normal:"متوسط",hard:"صعب"},TYPES={cipher:"قفل التشفير الميكانيكي",hidden:"البحث عن الأشياء",detective:"لغز التحقيق"};
/* ---- Mechanical cipher lock ---- */
const sum=d=>d.reduce((a,b)=>a+b,0);
const sat=(c,d)=>c.t==="par"?d[c.i]%2===c.v:c.t==="gt"?d[c.i]>d[c.j]:c.t==="sum"?sum(d)===c.v:d[c.i]===c.v;
const ctext=c=>c.t==="par"?`القرص ${c.i+1} رقمه ${c.v?"فردي":"زوجي"}`:c.t==="gt"?`رقم القرص ${c.i+1} أكبر من رقم القرص ${c.j+1}`:c.t==="sum"?`مجموع الأرقام كلها = ${c.v}`:`القرص ${c.i+1} = ${c.v}`;
const allCodes=(n,s)=>{let o=[[]];for(let k=0;k<n;k++){const x=[];for(const p of o)for(let v=0;v<s;v++)x.push(p.concat(v));o=x}return o};
const prune=(p,v)=>{for(let k=p.clues.length-1;k>=0;k--){const c=p.clues.filter((_,x)=>x!==k);if(v({...p,clues:c}))p.clues=c}return p};
const same=(a,b)=>a.length===b.length&&a.every((v,i)=>v===b[i]);
V.verifyCipher=p=>{const m=allCodes(p.n,p.sym).filter(d=>p.clues.every(c=>sat(c,d)));return m.length===1&&same(m[0],p.code)};
V.genCipher=(seed,lv)=>{const L=LV[lv];for(let t=0;t<30;t++){const r=rng(seed+t*7919),code=Array.from({length:L.n},()=>Math.floor(r()*L.sym));let cand=allCodes(L.n,L.sym);const clues=[];
 for(let g=0;g<80&&cand.length>1;g++){const i=Math.floor(r()*L.n),j=(i+1+Math.floor(r()*(L.n-1)))%L.n;
  const o=[{t:"par",i,v:code[i]%2},{t:"gt",i,j},{t:"sum",v:sum(code)}];if(lv==="easy"||g>=6)o.push({t:"eq",i,v:code[i]});
  const c=pick(r,o.filter(x=>sat(x,code))),nx=cand.filter(d=>sat(c,d));if(nx.length<cand.length){cand=nx;clues.push(c)}}
 const p=prune({type:"cipher",lv,seed,n:L.n,sym:L.sym,code,clues},V.verifyCipher);if(V.verifyCipher(p))return p}
 throw new Error("cipher generation failed")};
/* ---- Hidden objects ---- */
const OBJ=[["🗝️","المفتاح"],["📖","الكتاب"],["✉️","الرسالة"],["🏺","القطعة الأثرية"],["🪙","العملة"],["🔍","العدسة"],["⏰","الساعة"],["💍","الخاتم"],["🕯️","الشمعة"],["🧭","البوصلة"]];
V.verifyHidden=p=>p.items.length>=3&&new Set(p.items.map(i=>i.name)).size===p.items.length&&p.items.every((a,i)=>a.x>=6&&a.x<=94&&a.y>=6&&a.y<=54&&p.items.every((b,j)=>i===j||Math.hypot(a.x-b.x,a.y-b.y)>=14));
V.genHidden=(seed,lv)=>{const L=LV[lv],r=rng(seed),pos=[];let g=0;
 while(pos.length<L.obj&&g++<5000){const x=8+r()*84,y=8+r()*44;if(pos.every(q=>Math.hypot(q.x-x,q.y-y)>=14.5))pos.push({x,y})}
 if(pos.length<L.obj)throw new Error("hidden placement failed");
 const p={type:"hidden",lv,seed,items:shuffle(r,OBJ).slice(0,L.obj).map((o,i)=>({e:o[0],name:o[1],x:+pos[i].x.toFixed(1),y:+pos[i].y.toFixed(1)})),
  clutter:Array.from({length:26},()=>({x:+(r()*100).toFixed(1),y:+(r()*60).toFixed(1),w:+(3+r()*9).toFixed(1),h:+(3+r()*9).toFixed(1),o:+(.15+r()*.3).toFixed(2)}))};
 if(!V.verifyHidden(p))throw new Error("hidden verification failed");return p};
/* ---- Detective deduction ---- */
const SUS=["سالم","ليلى","كريم","نورة","ياسر","هدى"],ROOMS=["المكتبة","المختبر","القبو","الشرفة","الخزنة","المطبخ"];
const perms=n=>n===1?[[0]]:perms(n-1).flatMap(p=>Array.from({length:n},(_,k)=>[...p.slice(0,k),n-1,...p.slice(k)]));
const dsat=(c,p)=>c.t==="in"?p[c.s]===c.r:p[c.s]!==c.r;
V.verifyDetective=p=>{const m=perms(p.names.length).filter(q=>p.clues.every(c=>dsat(c,q)));return m.length===1&&same(m[0],p.truth)&&p.rooms[p.truth[p.culprit]]==="الخزنة"};
V.genDetective=(seed,lv)=>{const n=LV[lv].sus;for(let t=0;t<30;t++){const r=rng(seed+t*104729),names=shuffle(r,SUS).slice(0,n),rooms=shuffle(r,ROOMS.filter(x=>x!=="الخزنة")).slice(0,n-1).concat("الخزنة"),truth=shuffle(r,[...Array(n).keys()]);let cand=perms(n);const clues=[];
 for(let g=0;g<120&&cand.length>1;g++){const s=Math.floor(r()*n),c=r()<.35?{t:"in",s,r:truth[s]}:{t:"not",s,r:pick(r,[...Array(n).keys()].filter(x=>x!==truth[s]))},nx=cand.filter(q=>dsat(c,q));if(nx.length<cand.length){cand=nx;clues.push(c)}}
 const culprit=truth.indexOf(rooms.indexOf("الخزنة")),p=prune({type:"detective",lv,seed,names,rooms,truth,clues,culprit},V.verifyDetective);if(V.verifyDetective(p))return p}
 throw new Error("detective generation failed")};
V.gen={cipher:V.genCipher,hidden:V.genHidden,detective:V.genDetective};
V.sanitize=s=>{s=s&&typeof s==="object"&&!Array.isArray(s)?s:{};const done={},ach={},ok=o=>o&&typeof o==="object"&&!Array.isArray(o)?Object.keys(o):[];ok(s.done).forEach(k=>{if(/^[a-z]+_(easy|normal|hard)_\d+$/.test(k))done[k]=1});ok(s.ach).forEach(k=>{if(/^[a-z]+$/.test(k))ach[k]=1});return{runs:(Array.isArray(s.runs)?s.runs:[]).filter(r=>r&&typeof r.type==="string"&&LV[r.lv]&&Number.isFinite(r.seed)).slice(-200),done,ach}};
V.rng=rng;V.shuffle=shuffle;V.same=same;V.ctext=ctext;V.TYPES=TYPES;V.ext={};V.reg=(n,l,e)=>{TYPES[n]=l;V.gen[n]=e.gen;V.ext[n]=e};
V.LV=LV;
if(typeof module!=="undefined"&&module.exports)module.exports=V;
if(typeof window==="undefined"||typeof document==="undefined")return;
window.V17=V;
/* ---- UI layer (uses V16 globals: state, save, log, toast, showModal, closeModal, esc, todayKey) ---- */
let cur=null,ac=null;
const s17=()=>(state.v17=V.sanitize(state.v17));
const sfx=k=>{try{if(!state.settings.sound)return;ac=ac||new(window.AudioContext||window.webkitAudioContext)();const f={ok:[523,784],bad:[180],open:[392,523,659,880]}[k];f.forEach((hz,i)=>{const o=ac.createOscillator(),g=ac.createGain(),t=ac.currentTime+i*.09;o.frequency.value=hz;o.type=k==="bad"?"sawtooth":"triangle";g.gain.setValueAtTime(.08,t);g.gain.exponentialRampToValueAtTime(.001,t+.25);o.connect(g);g.connect(ac.destination);o.start(t);o.stop(t+.3)})}catch(e){}};
const finish=p=>{const s=s17(),id=`${p.type}_${p.lv}_${p.seed}`,first=!s.done[id];s.runs.push({type:p.type,lv:p.lv,seed:p.seed,at:Date.now()});s.runs=s.runs.slice(-200);let xp=0;
 if(first){s.done[id]=1;xp=LV[p.lv].xp;state.xp+=xp;state.cityCredits+=Math.round(xp/5)}
 log("V17 · "+TYPES[p.type],LVN[p.lv]+(first?` +${xp} XP`:" (إعادة)"));save();sfx("open");if(V.fx)V.fx();return xp};
const hash=str=>[...str].reduce((a,c)=>(a*31+c.charCodeAt(0))>>>0,7);
const head=(p)=>`<div class="eyebrow">V17 · ${TYPES[p.type]} · ${LVN[p.lv]} · #${p.seed}</div>`;
const closeBtn=`<button class="btn" data-v17="close">إغلاق</button>`,foot=`<div class="hero-actions">${closeBtn}</div>`;
function view(){const c=cur,p=c.p;let h=head(p);const E=V.ext[p.type];if(E)return E.view(c,h,closeBtn);
 if(p.type==="cipher"){h+=`<h2>افتح القفل</h2><div>${p.clues.map(x=>`<div class="clue">• ${esc(ctext(x))}</div>`).join("")}</div><div class="v17-dials">${c.d.map((v,i)=>`<div class="v17-dial"><button class="btn" data-v17="dial:${i}:1" aria-label="زيادة">▲</button><b>${v}</b><button class="btn" data-v17="dial:${i}:-1" aria-label="إنقاص">▼</button></div>`).join("")}</div><div class="hero-actions"><button class="btn" data-v17="try">فتح القفل</button>${closeBtn}</div>`+(c.msg?`<p class="v17-msg">${esc(c.msg)}</p>`:"")}
 else if(p.type==="hidden"){h+=`<h2>اعثر على الأشياء (${c.f.length}/${p.items.length})</h2><svg id="v17scene" viewBox="0 0 100 60" role="img" aria-label="مشهد البحث">${p.clutter.map(k=>`<rect x="${k.x}" y="${k.y}" width="${k.w}" height="${k.h}" rx="1" fill="#6be59a" opacity="${k.o}"/>`).join("")}${p.items.map((o,i)=>`<text x="${o.x}" y="${o.y+2}" font-size="6" text-anchor="middle" opacity="${c.f.includes(i)?1:.5}">${o.e}</text>${c.f.includes(i)?`<circle cx="${o.x}" cy="${o.y}" r="5" fill="none" stroke="#b7ff55" stroke-width=".6"/>`:""}`).join("")}${c.h>=0?`<circle cx="${p.items[c.h].x}" cy="${p.items[c.h].y}" r="9" fill="none" stroke="#ffd36b" stroke-width=".8"/>`:""}</svg><p>${p.items.map((o,i)=>`<span class="clue">${c.f.includes(i)?"✓":"•"} ${esc(o.name)}</span>`).join(" ")}</p><div class="hero-actions"><button class="btn" data-v17="hint">تلميح</button>${closeBtn}</div>`}
 else h+=`<h2>من كان في الخزنة؟</h2>${p.clues.map(x=>`<div class="clue">• ${esc(p.names[x.s])} ${x.t==="in"?"كان في":"لم يكن في"} ${esc(p.rooms[x.r])}</div>`).join("")}<p>كل متهم كان في غرفة مختلفة. اختر الفاعل:</p><div class="hero-actions">${p.names.map((n,i)=>`<button class="btn" data-v17="ask:${i}">${esc(n)}</button>`).join("")}</div>`+(c.msg?`<p class="v17-msg">${esc(c.msg)}</p>`:"")+foot;
 return h}
const refresh=()=>{showModal(view());const E=V.ext[cur.p.type];if(E&&E.after)E.after(cur)};
function start(type,lv,seed){try{const p=V.gen[type](seed,lv);cur={p,d:Array(p.n||0).fill(0),f:[],h:-1,msg:"",...(V.ext[type]&&V.ext[type].init?V.ext[type].init(p):{})};refresh()}catch(e){console.error("V17",e);toast("تعذّر توليد مرحلة قابلة للحل، حاول مرة أخرى")}}
function won(){const xp=finish(cur.p);cur.msg=`✔ أحسنت! ${xp?`+${xp} XP`:"(إعادة بلا مكافأة)"}`;refresh();const pg=document.querySelector(".nav-btn.active");if(pg&&pg.dataset.page==="v17")render("v17")}
V.api={refresh,won,sfx,cur:()=>cur};
V.page=()=>{const s=s17(),n=t=>s.runs.filter(r=>r.type===t).length;
 return `<div class="eyebrow">V17 · UNKNOWN X LAB</div><h1>مختبر V17</h1><p>كل مرحلة تُولَّد برمجياً ثم يتحقق النظام من أن لها حلاً واحداً قبل عرضها. يمكن إعادة أي مرحلة بنفس الرقم.</p><div class="field"><label for="v17lv">الصعوبة</label><select id="v17lv">${Object.keys(LVN).map(k=>`<option value="${k}">${LVN[k]}</option>`).join("")}</select></div><div class="v17-grid">${Object.keys(TYPES).map(t=>`<div class="v17-card"><h3>${TYPES[t]}</h3><small>لعبت ${n(t)} مرة</small><div class="hero-actions"><button class="btn" data-v17="new:${t}">مرحلة جديدة</button><button class="btn" data-v17="daily:${t}">التحدي اليومي</button></div></div>`).join("")}</div><p>إجمالي المراحل المنجزة: ${Object.keys(s.done).length}</p>`};
document.addEventListener("click",e=>{
 const tgt=e.target&&e.target.closest?e.target:(e.target&&e.target.parentElement)||null;
 const sc=tgt&&tgt.closest&&tgt.closest("#v17scene");
 if(sc&&cur&&cur.p.type==="hidden"){const r=sc.getBoundingClientRect(),x=(e.clientX-r.left)/r.width*100,y=(e.clientY-r.top)/r.height*60,i=cur.p.items.findIndex((o,k)=>!cur.f.includes(k)&&Math.hypot(o.x-x,o.y-y)<=7);
  if(i<0){sfx("bad");return}cur.f.push(i);cur.h=-1;sfx("ok");if(cur.f.length===cur.p.items.length)won();else refresh();return}
 const b=tgt&&tgt.closest&&tgt.closest("[data-v17]");if(!b)return;const [a,x,y]=b.dataset.v17.split(":");
 if(a==="close")return closeModal();
 if(a==="new"||a==="daily"){const lvEl=document.querySelector("#v17lv");const lv=lvEl&&lvEl.value||"easy";if(!lvEl&&typeof toast==="function")toast("تعذّر تحديد الصعوبة، سيُستخدم المستوى السهل");start(x,lv,a==="daily"?hash(todayKey()+x+lv):Date.now()%1e9);return}
 if(!cur)return;
 {const E=V.ext[cur.p.type];if(E&&E.act&&E.act(a,x,y,cur))return}
 if(a==="dial"){cur.d[+x]=(cur.d[+x]+ +y+cur.p.sym)%cur.p.sym;cur.msg="";refresh()}
 else if(a==="try"){if(same(cur.d,cur.p.code))won();else{cur.msg="القفل لم يفتح — راجع الأدلة";sfx("bad");refresh()}}
 else if(a==="ask"){if(+x===cur.p.culprit)won();else{cur.msg="هذا الاستنتاج يناقض الأدلة. أعد القراءة.";sfx("bad");refresh()}}
 else if(a==="hint"){const i=cur.p.items.findIndex((o,k)=>!cur.f.includes(k));if(i>=0){cur.h=i;state.hintsUsed=(state.hintsUsed||0)+1;save();refresh()}}
});
})();
