/**
 * mole SDK - measurement only.
 *
 * Authoritative copy lives in the mole repo (sdk/mole.js). Sites carry a copy;
 * edit it here, then sync - do not fix it in place on one site.
 *
 * The SDK knows nothing about pages, placements or creatives. It only reads
 * three DOM attributes, so adding a slot or reworking a layout never touches
 * this file:
 *
 *   <div data-mole="s_xxxxxxxx">              container -> impression on view
 *     <a data-mole-creative="a386918"         clickable -> click
 *        data-mole-index="2">…</a>
 *   </div>
 *
 * data-mole-hint is for humans reading the HTML and is never reported.
 */
(function (w, d) {
    'use strict';

    var ENDPOINT = w.MOLE_ENDPOINT || '';
    if (!ENDPOINT) {
        return;   // Not configured (dev, or a site that has not been wired up yet).
    }

    var SEEN_KEY = 'mole_seen';
    var seen = null;

    /** Impressions are deduped per session per slot; sessionStorage never leaves the browser. */
    function alreadySeen(sid) {
        if (seen === null) {
            try {
                seen = JSON.parse(w.sessionStorage.getItem(SEEN_KEY) || '{}');
            } catch (e) {
                seen = {};
            }
        }
        if (seen[sid]) {
            return true;
        }
        seen[sid] = 1;
        try {
            w.sessionStorage.setItem(SEEN_KEY, JSON.stringify(seen));
        } catch (e) {
            /* private mode: dedup degrades, reporting still works */
        }
        return false;
    }

    function impression(sid) {
        var url = ENDPOINT + '/px/i/' + sid;
        if (w.navigator && w.navigator.sendBeacon) {
            w.navigator.sendBeacon(url);
        } else {
            new Image().src = url;
        }
    }

    /**
     * Origin-bound events. text/plain keeps this a CORS simple request, so no
     * preflight round trip - sendBeacon sends text/plain by default anyway.
     */
    function post(payload) {
        var body = JSON.stringify(payload);
        try {
            if (w.navigator && w.navigator.sendBeacon) {
                w.navigator.sendBeacon(ENDPOINT + '/px/e.php', body);
                return;
            }
            var xhr = new XMLHttpRequest();
            xhr.open('POST', ENDPOINT + '/px/e.php', true);
            xhr.setRequestHeader('Content-Type', 'text/plain;charset=UTF-8');
            xhr.send(body);
        } catch (e) {
            /* measurement must never break a placement */
        }
    }

    function event(sid, type, creative, index) {
        if (!sid) {
            return;
        }
        post({
            s: sid,
            e: type,
            k: creative || '',
            i: index || 0,
            v: w.MOLE_VER || 0,
            t: ''
        });
    }

    var io = null;
    if (w.IntersectionObserver) {
        io = new w.IntersectionObserver(function (entries) {
            for (var i = 0; i < entries.length; i++) {
                if (!entries[i].isIntersecting) {
                    continue;
                }
                var el = entries[i].target;
                io.unobserve(el);
                var sid = el.getAttribute('data-mole');
                if (sid && !alreadySeen(sid)) {
                    impression(sid);
                }
            }
        }, { threshold: 0.5 });
    }

    /**
     * Wire up every slot container currently in the DOM. Safe to call repeatedly -
     * placements injected later (the payload-driven ones) just call scan() again.
     */
    function scan() {
        if (!io) {
            return;   // No IntersectionObserver: report nothing rather than redefine
        }             // "impression" as "rendered". Keeping the metric honest matters
                      // more than covering a handful of ancient browsers.
        var nodes = d.querySelectorAll('[data-mole]');
        for (var i = 0; i < nodes.length; i++) {
            if (!nodes[i].__moleBound) {
                nodes[i].__moleBound = 1;
                io.observe(nodes[i]);
            }
        }
    }

    // One delegated listener for the whole document: containers come and go,
    // this does not care. Capture phase so a placement's own handler (or a
    // navigation) cannot cancel the report.
    d.addEventListener('click', function (ev) {
        var node = ev.target;
        while (node && node !== d.body) {
            if (node.hasAttribute && node.hasAttribute('data-mole-creative')) {
                var host = node.closest ? node.closest('[data-mole]') : null;
                if (host) {
                    event(
                        host.getAttribute('data-mole'),
                        'c',
                        node.getAttribute('data-mole-creative'),
                        parseInt(node.getAttribute('data-mole-index') || '0', 10)
                    );
                }
                return;
            }
            node = node.parentNode;
        }
    }, true);

    w.mole = { scan: scan, event: event, impression: impression };

    if (d.readyState === 'loading') {
        d.addEventListener('DOMContentLoaded', scan);
    } else {
        scan();
    }
})(window, document);
