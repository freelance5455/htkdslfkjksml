/* تنظیمات: ظاهر و قلم، دکمه‌ی رفتن به کلید و مدل مشاور، پشتیبان (خروجی، ورودی با پیش‌نمایش، پشتیبان‌های چرخشی)، پاک‌کردن داده‌ها. */
(function () {
  'use strict';
  var App = (window.App = window.App || {});
  var u = App.u;
  var store = App.store;
  var bk = App.backup;
  var S = function () { return App.S; };
  var THEMES = [['system', 'سیستم'], ['light', 'روشن'], ['dark', 'تاریک']];
  var FONTS = [['n', 'عادی'], ['l', 'بزرگ'], ['xl', 'خیلی بزرگ']];
  var pending = null; // بسته‌ی پشتیبان بررسی‌شده، تا وقتی کاربر تأیید کند

  // ---- ظاهر ----
  App.applyPrefs = function () {
    var root = document.documentElement, s = S();
    var th = s.theme === 'light' || s.theme === 'dark' ? s.theme : 'system';
    root.setAttribute('data-theme', th);
    root.setAttribute('data-fs', s.fs === 'l' || s.fs === 'xl' ? s.fs : 'n');
    var dark = th === 'dark' || (th === 'system' && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches);
    var meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', dark ? '#131412' : '#0f766e');
    var b = document.getElementById('theme-btn');
    if (b) {
      var lab = th === 'light' ? 'روشن' : th === 'dark' ? 'تاریک' : 'خودکار';
      b.textContent = '🌓 ' + lab;
      b.setAttribute('aria-label', 'تغییر تم، الان: ' + lab);
    }
  };
  App.act['theme-cycle'] = function () {
    var cur = S().theme === 'light' || S().theme === 'dark' ? S().theme : 'system';
    S().theme = cur === 'system' ? 'light' : cur === 'light' ? 'dark' : 'system';
    App.save(); App.applyPrefs(); App.render();
  };
  App.act['set-theme'] = function (el) {
    var v = el.getAttribute('data-v');
    S().theme = v === 'light' || v === 'dark' ? v : 'system';
    App.save(); App.applyPrefs(); App.render();
  };
  App.act['set-fs'] = function (el) {
    var v = el.getAttribute('data-v');
    S().fs = v === 'l' || v === 'xl' ? v : 'n';
    App.save(); App.applyPrefs(); App.render();
  };

  // ---- هوش مصنوعی: کلید و مدل Claude در تب مشاور است؛ اینجا فقط دکمه‌ای برای رفتن به آنجاست ----
  App.act['open-ai-setup'] = function () { App.go('ai'); };

  // ---- نمای تنظیمات ----
  App.views.settings = function () {
    var s = S();
    var th = s.theme === 'light' || s.theme === 'dark' ? s.theme : 'system';
    var fs = s.fs === 'l' || s.fs === 'xl' ? s.fs : 'n';
    var h = App.upgradeNotice() + App.storageNotice();
    var look = App.card('🎨 ظاهر', '<div class="mu">تم</div><div class="chips-row" role="group" aria-label="تم">' +
      THEMES.map(function (x) { return '<button type="button" class="sm' + (th === x[0] ? ' accent' : '') + '" aria-pressed="' + (th === x[0]) + '" data-act="set-theme" data-v="' + x[0] + '">' + x[1] + '</button>'; }).join('') + '</div>' +
      '<div class="mu mt">اندازه‌ی قلم</div><div class="chips-row" role="group" aria-label="اندازه‌ی قلم">' +
      FONTS.map(function (x) { return '<button type="button" class="sm' + (fs === x[0] ? ' accent' : '') + '" aria-pressed="' + (fs === x[0]) + '" data-act="set-fs" data-v="' + x[0] + '">' + x[1] + '</button>'; }).join('') + '</div>', { key: 'set|look', open: true });

    // هوش مصنوعی: کلید و مدل در تب مشاور است؛ اینجا فقط یک دکمه برای رفتن به آنجا
    h += App.card(null, '<div class="row0 wrap"><button type="button" class="btn accent" data-act="open-ai-setup">🤖 کلید و مدل مشاور</button></div>');
    h += App.remind.settingsCard();

    h += backupCard();
    h += look;
    var about = App.card('🗄 داده‌ها و حریم خصوصی', '<p class="mu">مشاور تحصیلی من، نسخه ۲. داده‌ها فقط روی همین دستگاه ذخیره می‌شوند و به سرور فرستاده نمی‌شوند؛ فقط وقتی از مشاور هوشمند استفاده کنی، متن گفتگو و خلاصه‌ی وضعیت فقط به سرویس هوش مصنوعی‌ای که خودت انتخاب کرده‌ای فرستاده می‌شود.</p>', { key: 'set|about', open: false });
    h += about;
    h += App.card('⚠️ منطقه‌ی خطر: پاک‌کردن همه‌ی داده‌ها', '<p class="mu">همه‌ی مطالعه، آزمون، برنامه و یادداشت‌ها پاک می‌شود. قبل از آن یک پشتیبان محلی گرفته می‌شود. تنظیمات ظاهر و هوش مصنوعی می‌ماند.</p>' +
      '<button type="button" class="btn danger" data-act="reset-all">پاک‌کردن همه‌ی داده‌ها</button>', { key: 'set|reset', open: false, cls: 'danger-card' });
    return h;
  };
  // ---- پشتیبان ----
  function backupCard() {
    var s = S();
    var last = s.lb ? u.dayDiff(s.lb, u.todayISO()) : null;
    var snaps = bk.snapshots();
    var lastTxt = s.lb ? 'آخرین پشتیبان: ' + u.jd(s.lb, true, false) + (last ? ' (' + u.fa(last) + ' روز پیش)' : ' (امروز)') : 'هنوز پشتیبانی گرفته نشده است.';
    var snapHtml = snaps.length ? snaps.map(function (x, k) {
      var when = x.at ? u.jd(x.at.slice(0, 10), true, false) + ' · ' + u.pd(new Date(x.at).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Tehran' })) : '';
      return '<div class="li"><span>' + u.esc(when) + '<br><span class="mu">' + u.esc(x.note) + ' · ' + u.fa(x.logs) + ' ثبت · ' + u.fa(x.exams) + ' آزمون</span></span>' +
        App.sm('بازیابی', 'snap-restore', { key: k }) + '</div>';
    }).join('') + '<div class="q-row"><button type="button" class="sm" data-act="snap-clear">پاک‌کردن پشتیبان‌های محلی</button></div>' : '<p class="mu">پشتیبان محلی خودکار (هر ۱۲ ساعت، تا ۵ نسخه) هنوز ساخته نشده است.</p>';
    return App.card('💾 پشتیبان و بازیابی', '<p class="mu">' + lastTxt + '</p>' +
      '<p class="mu">فایل پشتیبان هیچ کلیدی ندارد و امن است. می‌توانی آن را نگه داری یا روی دستگاه دیگری بارگذاری کنی.</p>' +
      '<div class="q-row"><button type="button" class="btn" data-act="bk-export">⬇️ دانلود پشتیبان</button><button type="button" class="sm" data-act="bk-show">نمایش متن برای کپی</button><button type="button" class="sm" data-act="open-import">📂 بارگذاری پشتیبان</button></div>' +
      '<h3 class="sub-h">پشتیبان‌های محلی</h3>' + snapHtml, { key: 'set|backup', open: true });
  }
  // شیء خروجی بدون کلید؛ متن را هم می‌شود نشان داد یا کپی کرد (برای WebView که دانلود نمی‌دهد)
  App.act['bk-export'] = function () {
    var text = bk.exportText();
    var name = 'moshaver-' + u.todayISO() + '.json';
    try {
      var blob = new Blob([text], { type: 'application/json' });
      var url = URL.createObjectURL(blob);
      var a = document.createElement('a');
      a.href = url; a.download = name; a.rel = 'noopener';
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(function () { URL.revokeObjectURL(url); }, 4000);
    } catch (e) { /* دانلود در این محیط ممکن نیست؛ کاربر می‌تواند متن را نشان بدهد */ }
    S().lb = u.todayISO(); App.save(); App.render();
    App.toast('پشتیبان ساخته شد. اگر دانلود نشد، «نمایش متن برای کپی» را بزن.', { ms: 6000 });
  };
  App.act['bk-show'] = function () {
    var text = bk.exportText();
    App.openModal('متن پشتیبان', '<p class="mu">این متن را کپی کن و در فایلی با پسوند json ذخیره کن.</p>' +
      '<textarea class="ta tall" id="bk-text" readonly dir="ltr" aria-label="متن پشتیبان">' + u.esc(text) + '</textarea>' +
      '<div class="row0 wrap"><button type="button" class="btn" data-act="bk-copy">📋 کپی متن</button><button type="button" class="sm" data-act="close-modal">بستن</button></div>');
  };
  App.act['bk-copy'] = function () {
    var el = document.getElementById('bk-text');
    var text = el ? el.value : bk.exportText();
    u.copyText(text).then(function (ok) {
      if (!ok && el) { el.focus(); el.select(); }
      App.toast(ok ? 'کپی شد ✅' : 'کپی خودکار نشد؛ متن را انتخاب و کپی کن');
    });
  };

  // بارگذاری: از فایل یا از متنی که چسبانده می‌شود، اول پیش‌نمایش، بعد ادغام یا جایگزینی
  App.act['open-import'] = function () {
    pending = null;
    App.openModal('بارگذاری پشتیبان', '<p class="mu">فایل پشتیبان (json) را انتخاب کن یا متنش را اینجا بچسبان. اول پیش‌نمایش می‌بینی، بعد تأیید می‌کنی.</p>' +
      '<div class="field"><label for="imp-file">فایل</label><input id="imp-file" type="file" accept=".json,application/json,text/plain"></div>' +
      '<div class="field"><label for="imp-txt">یا متن پشتیبان</label><textarea id="imp-txt" class="ta" dir="ltr" placeholder="{ &quot;version&quot;: 2, ..."></textarea></div>' +
      '<div class="row0 wrap"><button type="button" class="btn" data-act="imp-check">بررسی و پیش‌نمایش</button><button type="button" class="sm" data-act="close-modal">انصراف</button></div>' +
      '<div id="imp-out" role="region" aria-live="polite" aria-label="پیش‌نمایش پشتیبان"></div>');
  };
  function readFile(file) {
    return new Promise(function (resolve, reject) {
      if (file.size > 20 * 1024 * 1024) { reject(new Error('فایل خیلی بزرگ است (بیشتر از ۲۰ مگابایت).')); return; }
      var fr = new FileReader();
      fr.onload = function () { resolve(String(fr.result || '')); };
      fr.onerror = function () { reject(new Error('فایل خوانده نشد.')); };
      fr.readAsText(file);
    });
  }
  App.act['imp-check'] = function () {
    var out = document.getElementById('imp-out');
    var fileEl = document.getElementById('imp-file');
    var txtEl = document.getElementById('imp-txt');
    var file = fileEl && fileEl.files && fileEl.files[0];
    var go = function (text) {
      var r = bk.parse(text);
      if (!r.ok) { pending = null; if (out) out.innerHTML = '<p class="bad" role="alert">' + u.esc(r.error) + '</p>'; return; }
      pending = r;
      var info = bk.preview(r.data);
      var rows = Object.keys(info.counts).filter(function (k) { return info.counts[k].total > 0; }).map(function (k) {
        var c = info.counts[k];
        return '<li>' + u.esc(c.label) + ': <b>' + u.fa(c.total) + '</b> <span class="mu">(جدید: ' + u.fa(c.fresh) + ')</span></li>';
      }).join('');
      var range = info.range ? '<p class="mu">بازه‌ی ثبت‌ها: ' + u.esc(u.jd(info.range.from)) + ' تا ' + u.esc(u.jd(info.range.to)) + '</p>' : '';
      if (out) out.innerHTML = (r.warn ? '<p class="notice-inline">' + u.esc(r.warn) + '</p>' : '') +
        (r.legacy ? '<p class="notice-inline">این فایل از نسخه‌ی قدیمی است. هر کلید یا تنظیم قدیمی‌ای که داشته باشد، نادیده گرفته می‌شود.</p>' : '') +
        '<h3 class="sub-h">پیش‌نمایش</h3>' + (rows ? '<ul class="legend">' + rows + '</ul>' : '<p class="mu">موردی برای ثبت پیدا نشد.</p>') + range +
        '<fieldset class="mt"><legend>روش ورود</legend>' +
        '<label class="check" for="imp-merge"><input id="imp-merge" type="radio" name="imp-mode" value="merge" checked><span>ادغام: موارد تازه اضافه می‌شوند، موارد موجود دست نمی‌خورند</span></label>' +
        '<label class="check" for="imp-replace"><input id="imp-replace" type="radio" name="imp-mode" value="replace"><span>جایگزینی: داده‌های فعلی با این پشتیبان عوض می‌شوند</span></label></fieldset>' +
        '<div class="row0 wrap mt"><button type="button" class="btn accent" data-act="imp-apply">✅ ثبت پشتیبان</button></div>' +
        '<p class="mu">قبل از ثبت، یک پشتیبان محلی از وضعیت فعلی گرفته می‌شود.</p>';
    };
    if (file) {
      readFile(file).then(go, function (e) { pending = null; if (out) out.innerHTML = '<p class="bad" role="alert">' + u.esc(e.message) + '</p>'; });
    } else {
      go(txtEl ? txtEl.value : '');
    }
  };
  App.act['imp-apply'] = function () {
    if (!pending) { App.alert('اول پشتیبان را بررسی کن'); return; }
    var sel = document.querySelector('input[name="imp-mode"]:checked');
    var mode = sel && sel.value === 'replace' ? 'replace' : 'merge';
    if (mode === 'replace' && !App.confirm('همه‌ی داده‌های فعلی با این پشتیبان عوض می‌شوند. ادامه می‌دهی؟ (قبل از آن یک پشتیبان محلی گرفته می‌شود.)')) return;
    try {
      bk.apply(pending.data, mode);
    } catch (e) {
      App.alert('ثبت پشتیبان انجام نشد. داده‌های قبلی دست نخورده‌اند.');
      App.logError(e);
      return;
    }
    pending = null;
    App.closeModal();
    App.applyPrefs();
    App.render();
    App.toast(mode === 'replace' ? 'داده‌ها با پشتیبان جایگزین شدند' : 'پشتیبان ادغام شد');
  };
  App.act['snap-restore'] = function (el) {
    var k = +el.getAttribute('data-key');
    if (!App.confirm('به این پشتیبان محلی برگردی؟ وضعیت فعلی هم قبلش ذخیره می‌شود.')) return;
    if (!bk.restoreSnapshot(k)) { App.alert('این پشتیبان خوانده نشد'); return; }
    App.applyPrefs(); App.render(); App.toast('پشتیبان بازیابی شد');
  };
  App.act['snap-clear'] = function () {
    if (!App.confirm('همه‌ی پشتیبان‌های محلی پاک شوند؟')) return;
    bk.clearSnapshots(); App.render(); App.toast('پشتیبان‌های محلی پاک شدند');
  };
  App.act['reset-all'] = function () {
    if (!App.confirm('همه‌ی داده‌ها پاک می‌شود. ادامه می‌دهی؟')) return;
    bk.snapshot('پیش از پاک‌کردن همه‌ی داده‌ها');
    var keep = { ai: bk.aiPart(S()), theme: S().theme, fs: S().fs };
    App.S = store.defaults();
    bk.keepAi(App.S, keep.ai);
    App.S.theme = keep.theme || 'system';
    App.S.fs = keep.fs || 'n';
    App.S.rs = 0;
    App.save();
    App.applyPrefs();
    App.ui.vp = [];
    App.render();
    App.toast('داده‌ها پاک شد. پشتیبان محلی قبل از آن ذخیره شد.', { ms: 6000 });
  };
})();
