/* =============================================================
   LAMPION POS · js/auth.js
   Pengganti includes/auth.php
   -------------------------------------------------------------
   - Login/logout multi-user (permission-based)
   - Sliding expiry sesi: idle 4 jam, batas keras 16 jam
     (padanan session_touch())
   - can(perm) / current_user() / current_permissions()
   - Hash password memakai WebCrypto SHA-256 + salt per-user.
     CATATAN: ini BUKAN bcrypt (PHP password_hash). Karena database
     kini 100% lokal di perangkat pengguna dan tidak ada server,
     risiko dipindahkan ke penguncian perangkat. Hash tetap dipakai
     supaya password tidak pernah tersimpan sebagai plaintext.
   ============================================================= */
(function (global) {
  'use strict';

  var DB = global.LPDB;
  var db = DB.db;
  var PHP = global.LPHP;

  var SESSION_LS_KEY = 'lpos_sid';
  var ctx = { user: null, perms: [], via: 'none' };

  /* =============================================================
     Hash password (WebCrypto) — JS tidak punya bcrypt bawaan
     ============================================================= */
  function toHex(buf) {
    var arr = new Uint8Array(buf);
    var s = '';
    for (var i = 0; i < arr.length; i++) {
      s += ('0' + arr[i].toString(16)).slice(-2);
    }
    return s;
  }

  function sha256Hex(text) {
    var enc = new TextEncoder();
    var data = enc.encode(text);
    if (global.crypto && crypto.subtle) {
      return crypto.subtle.digest('SHA-256', data).then(toHex);
    }
    return Promise.resolve(fallbackHash(text));
  }

  /** fallback dipakai hanya bila WebCrypto tidak tersedia (WebView lama) */
  function fallbackHash(text) {
    var h = 0x811c9dc5;
    for (var i = 0; i < text.length; i++) {
      h ^= text.charCodeAt(i);
      h = (h * 0x01000193) >>> 0;
    }
    var out = '';
    for (var k = 0; k < 4; k++) {
      out += ('0000000' + (h >>> 0).toString(16)).slice(-8);
      h = (h * 31 + k + 7) >>> 0;
    }
    return out;
  }

  /** Buat hash tersimpan: sha256(salt + ':' + password) */
  function hashPassword(password, salt) {
    return sha256Hex(String(salt) + ':' + String(password));
  }

  /**
   * Verifikasi password. Mendukung dua format tersimpan:
   *  - "sha256$<salt>$<hash>"  (format JS baru)
   *  - "$2y$..."               (hash bcrypt sisa migrasi dari PHP)
   *    -> tidak bisa diverifikasi di browser; pemanggil diminta
   *       reset password lewat menu Pengguna.
   */
  function verifyPassword(password, stored) {
    stored = String(stored || '');
    if (stored.indexOf('sha256$') === 0) {
      var parts = stored.split('$');
      var want = parts[2];
      return hashPassword(password, parts[1]).then(function (got) {
        return got === want;
      });
    }
    return Promise.resolve(false);
  }

  function makeStoredHash(password) {
    var salt = DB.randomHex(8);
    return hashPassword(password, salt).then(function (h) {
      return 'sha256$' + salt + '$' + h;
    });
  }

  /* =============================================================
     Sesi (padanan $_SESSION) — disimpan di localStorage
     ============================================================= */
  function readSession() {
    var raw = null;
    try { raw = localStorage.getItem(SESSION_LS_KEY); } catch (e) { raw = null; }
    if (!raw) { return null; }
    try { return JSON.parse(raw); } catch (e2) { return null; }
  }

  function writeSession(sess) {
    try { localStorage.setItem(SESSION_LS_KEY, JSON.stringify(sess)); } catch (e) { /* noop */ }
  }

  function endSession() {
    try { localStorage.removeItem(SESSION_LS_KEY); } catch (e) { /* noop */ }
    ctx = { user: null, perms: [], via: 'none' };
  }

  /** Akhiri sesi karena kedaluwarsa (padanan session_end_expired) */
  function endExpired() {
    endSession();
    PHP.flashSet('warn', 'Sesi berakhir karena tidak ada aktivitas. Silakan masuk kembali.');
  }

  /* =============================================================
     Permissions (padanan role_permissions + can())
     role_key 'admin' -> ['*'] = semua permission
     ============================================================= */
  function rolePermissions(roleId, roleKey) {
    if (roleKey === 'admin') { return Promise.resolve(['*']); }
    return db.role_permissions.where('role_id').equals(roleId).toArray()
      .then(function (rps) {
        if (rps.length === 0) { return []; }
        var ids = rps.map(function (r) { return r.permission_id; });
        return db.permissions.where('id').anyOf(ids).toArray();
      })
      .then(function (perms) {
        return perms.map(function (p) { return p.pkey; }).sort();
      });
  }

  /* =============================================================
     Sumber kebenaran user: ambil ulang dari DB (users + roles)
     ============================================================= */
  function loadUserById(uid) {
    return db.users.get(Number(uid)).then(function (u) {
      if (!u) { return null; }
      if (Number(u.is_active) !== 1) { return null; }
      return db.roles.get(Number(u.role_id)).then(function (role) {
        if (!role) { return null; }
        var roleKey = String(role.name).toLowerCase().replace(/\s+/g, '_');
        var user = {
          id: Number(u.id),
          username: String(u.username),
          name: String(u.name),
          role_id: Number(u.role_id),
          role_name: String(role.name),
          role_key: roleKey
        };
        return rolePermissions(user.role_id, roleKey).then(function (perms) {
          return { user: user, perms: perms };
        });
      });
    });
  }

  /**
   * Konteks auth aktif (padanan auth_context()).
   * @returns {Promise<{user:Object|null, perms:Array, via:string}>}
   */
  function authContext() {
    if (ctx.user !== null && ctx.via !== 'none') {
      return Promise.resolve(ctx);
    }
    var sess = readSession();
    if (!sess || !sess.uid) {
      ctx = { user: null, perms: [], via: 'none' };
      return Promise.resolve(ctx);
    }
    return loadUserById(sess.uid).then(function (res) {
      if (!res) {
        endSession();
        return { user: null, perms: [], via: 'none' };
      }
      ctx = { user: res.user, perms: res.perms, via: 'session' };
      return ctx;
    });
  }

  /* =============================================================
     Sliding expiry (padanan session_touch())
       idle  > 4 jam  -> sesi berakhir
       total > 16 jam -> sesi berakhir (batas keras)
     ============================================================= */
  function sessionTouch() {
    var sess = readSession();
    if (!sess || !sess.uid) { return false; }
    var now = Math.floor(Date.now() / 1000);
    var seen = Number(sess.last_seen || 0);
    var started = Number(sess.started_at || 0);

    if (seen === 0 || started === 0) {
      sess.last_seen = now;
      sess.started_at = now;
      writeSession(sess);
      return true;
    }
    if ((now - seen) > DB.CFG.SESSION_IDLE_SECONDS
      || (now - started) > DB.CFG.SESSION_ABSOLUTE_SECONDS) {
      endExpired();
      return false;
    }
    sess.last_seen = now;
    writeSession(sess);
    return true;
  }

  /* =============================================================
     current_user() / current_permissions() / can()
     ============================================================= */
  function currentUser() { return ctx.user; }
  function currentPermissions() { return ctx.perms.slice(); }

  /** can('pos.order') — padanan can() di PHP */
  function can(perm) {
    if (!ctx.user) { return false; }
    if (ctx.perms.indexOf('*') !== -1) { return true; }
    return ctx.perms.indexOf(String(perm)) !== -1;
  }

  /* =============================================================
     Login (padanan auth_validate_login + do_login)
     ============================================================= */
  function validateLogin(username, password) {
    username = String(username || '').trim();
    if (username === '' || String(password) === '') {
      return Promise.resolve({ ok: false, msg: 'Username dan password wajib diisi.' });
    }
    return db.users.where('username').equals(username).first().then(function (u) {
      /* pesan seragam supaya tidak membocorkan username mana yang ada */
      if (!u) {
        return { ok: false, msg: 'Username atau password salah.' };
      }
      if (Number(u.is_active) !== 1) {
        return { ok: false, msg: 'Akun ini non-aktif. Hubungi Admin.' };
      }
      var isBcrypt = String(u.password).indexOf('$2') === 0;
      return verifyPassword(password, u.password).then(function (good) {
        if (!good) {
          if (isBcrypt) {
            return { ok: false, msg: 'Akun ini berasal dari versi PHP — reset password lewat menu Pengguna.' };
          }
          return { ok: false, msg: 'Username atau password salah.' };
        }
        return loadUserById(u.id).then(function (res) {
          if (!res) { return { ok: false, msg: 'Akun ini non-aktif. Hubungi Admin.' }; }
          return { ok: true, user: res.user, perms: res.perms };
        });
      });
    });
  }

  function doLogin(username, password) {
    return validateLogin(username, password).then(function (res) {
      if (!res.ok) { return res; }
      var now = Math.floor(Date.now() / 1000);
      /* padanan session_regenerate_id(true) -> ID sesi baru tiap login */
      writeSession({
        sid: DB.randomHex(16),
        uid: res.user.id,
        started_at: now,
        last_seen: now
      });
      ctx = { user: res.user, perms: res.perms, via: 'session' };
      return PHP.logActivity('login', res.user.username, { role: res.user.role_name })
        .then(function () {
          return { ok: true, role_key: res.user.role_key };
        });
    });
  }

  function doLogout() {
    var u = ctx.user;
    var log = Promise.resolve();
    if (u) {
      log = PHP.logActivity('logout', String(u.username || ''), { id: Number(u.id || 0) });
    }
    return log.then(function () { endSession(); });
  }

  /* =============================================================
     Halaman mendarat (padanan landing_page()) — permission pertama
     yang dimiliki user dipakai supaya tidak ada redirect loop.
     ============================================================= */
  var LANDING_ORDER = [
    ['dashboard.view', 'index.html'],
    ['pos.order', 'pos.html'],
    ['menu.view', 'menu.html'],
    ['inventory.view', 'inventory.html'],
    ['sales.view', 'sales.html'],
    ['settings.manage', 'settings.html'],
    ['users.manage', 'users.html']
  ];

  function landingPage() {
    if (!ctx.user) { return 'login.html'; }
    for (var i = 0; i < LANDING_ORDER.length; i++) {
      if (can(LANDING_ORDER[i][0])) { return LANDING_ORDER[i][1]; }
    }
    return 'login.html';
  }

  global.LPAUTH = {
    authContext: authContext,
    sessionTouch: sessionTouch,
    currentUser: currentUser,
    currentPermissions: currentPermissions,
    can: can,
    doLogin: doLogin,
    doLogout: doLogout,
    validateLogin: validateLogin,
    makeStoredHash: makeStoredHash,
    rolePermissions: rolePermissions,
    landingPage: landingPage,
    endSession: endSession,
    endExpired: endExpired
  };

  /* daftarkan pengambil user ke helper log (menghindari circular dep) */
  PHP.setUserGetter(currentUser);
})(window);
