const WS_AUTH_KEY='ws_local_session';
const PAGE_RULES={dashboard:['Agent','Administrateur','Superviseur','Développeur'],operations:['Agent','Administrateur','Superviseur','Développeur'],operation:['Agent','Administrateur','Superviseur','Développeur'],reports:['Agent','Administrateur','Superviseur','Développeur'],stock:['Agent','Administrateur','Superviseur','Développeur'],cash:['Administrateur','Superviseur','Développeur'],notifications:['Agent','Administrateur','Superviseur','Développeur'],settings:['Agent','Administrateur','Superviseur','Développeur'],users:['Développeur']};
function getSession(){try{return JSON.parse(localStorage.getItem(WS_AUTH_KEY)||'null')}catch{return null}}
function saveSession(s,remember=true){const raw=JSON.stringify(s);if(remember)localStorage.setItem(WS_AUTH_KEY,raw);else sessionStorage.setItem(WS_AUTH_KEY,raw)}
function clearSession(){localStorage.removeItem(WS_AUTH_KEY);sessionStorage.removeItem(WS_AUTH_KEY)}
function readSession(){let s=getSession();if(s)return s;try{return JSON.parse(sessionStorage.getItem(WS_AUTH_KEY)||'null')}catch{return null}}
async function login(identifier,password,remember){const key=String(identifier||'').trim().toLowerCase();if(!key||!password)return false;const users=await dbAll('users');const hash=await sha256(password);const u=users.find(x=>(String(x.username||x.id||'').toLowerCase()===key||String(x.email||'').toLowerCase()===key)&&x.active!==false&&x.passwordHash===hash);if(!u)return false;const user={id:u.id,username:u.username||u.id.toLowerCase(),name:u.name||u.full_name||u.id,role:u.role,email:u.email||'',photo:u.photo||'',active:true};saveSession({user,loginAt:Date.now(),deviceId:getDeviceId()},remember);await dbPut('audit',{id:WS.uid('AUD'),action:'login',userId:user.id,createdAt:Date.now(),device:navigator.userAgent.slice(0,120),local:true});return true}
async function currentUser(){return readSession()?.user||null}
function logout(){clearSession();location.href='index.html'}
async function requireAuth(){const u=await currentUser();if(!u){location.href='index.html';return null}const page=document.body.dataset.page||'dashboard',allowed=PAGE_RULES[page];if(allowed&&!allowed.includes(u.role)){location.replace('dashboard.html');return null}return u}
function isDev(u){return u?.role==='Développeur'}
function isSupervisor(u){return u?.role==='Administrateur'||u?.role==='Superviseur'||isDev(u)}
function can(u,cap){if(isDev(u))return true;if(isSupervisor(u))return ['operation','operations','reports','stock','cash','notifications'].includes(cap);return ['operation','operations','reports','stock','notifications'].includes(cap)}
function getDeviceId(){let id=localStorage.getItem('ws_device_id');if(!id){id='DEV-'+crypto.randomUUID();localStorage.setItem('ws_device_id',id)}return id}
