// CIVIL 3 access prompts. NOTE: client-side prompts are not a substitute for server/database security.
(function () {
  const STUDENT_PASSWORD = "CIVIL3";
  const ADMIN_PASSWORD = "ONLY CHANGE ME";
  const page = location.pathname.toLowerCase();
  const isManageStudents = page.endsWith("/students.html");
  const accessKey = "civil3_access_ok";
  const adminKey = "civil3_admin_ok";

  function deny(message) {
    document.body.innerHTML = "<main style=\"font-family:Arial,sans-serif;max-width:520px;margin:15vh auto;padding:24px;text-align:center;color:#332819\"><h2>CIVIL 3 Attendance Portal</h2><p>" + message + "</p><button onclick=\"location.reload()\" style=\"padding:12px 18px;background:#a9854f;color:white;border:0;border-radius:8px\">Try Again</button></main>";
  }

  if (sessionStorage.getItem(accessKey) !== "yes") {
    const entered = prompt("CIVIL 3 Portal\nEnter shared password:");
    if (entered !== STUDENT_PASSWORD) { deny("Incorrect password. Access denied."); return; }
    sessionStorage.setItem(accessKey, "yes");
  }

  if (isManageStudents && sessionStorage.getItem(adminKey) !== "yes") {
    const entered = prompt("Admin access required\nEnter Admin password:");
    if (entered !== ADMIN_PASSWORD) { deny("Admin password incorrect. Manage Students is restricted."); return; }
    sessionStorage.setItem(adminKey, "yes");
  }

  window.CIVIL3_AUTH = {
    requireAdmin: function () {
      if (sessionStorage.getItem(adminKey) === "yes") return true;
      const entered = prompt("Admin password required to save/change attendance:");
      if (entered === ADMIN_PASSWORD) { sessionStorage.setItem(adminKey, "yes"); return true; }
      alert("Wrong Admin password. Attendance was not saved.");
      return false;
    }
  };
})();
