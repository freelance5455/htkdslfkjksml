// CIVIL 3 access screen compatible with Android WebView (does not use prompt()).
// Note: front-end passwords are not secure authentication; use a backend for real protection.
(function () {
  const STUDENT_PASSWORD = "CIVIL3";
  const ADMIN_PASSWORD = "ONLY CHANGE ME";
  const accessKey = "civil3_access_ok";
  const adminKey = "civil3_admin_ok";
  const isManageStudents = location.pathname.toLowerCase().endsWith("/students.html");

  function passwordScreen(title, message, onSubmit) {
    const overlay = document.createElement('div');
    overlay.id = 'civil3-auth-overlay';
    overlay.style.cssText = 'position:fixed;inset:0;z-index:2147483647;background:#f5f7fa;display:flex;align-items:center;justify-content:center;padding:22px;font-family:Arial,sans-serif;';
    overlay.innerHTML = '<form style="width:100%;max-width:380px;background:white;border:1px solid #e3e8ef;border-radius:20px;padding:26px;box-shadow:0 12px 40px #102a4320;box-sizing:border-box">' +
      '<h2 style="margin:0 0 8px;color:#0d47a1">CIVIL 3 Attendance</h2>' +
      '<h3 style="margin:0 0 8px;color:#102a43"></h3><p style="color:#526273;font-size:14px"></p>' +
      '<input type="password" autocomplete="off" placeholder="Enter password" aria-label="Password" style="width:100%;box-sizing:border-box;padding:14px;border:1px solid #cbd5e1;border-radius:10px;font-size:16px;margin:8px 0 14px">' +
      '<p class="auth-error" style="color:#b42318;min-height:18px;font-size:14px;margin:0 0 10px"></p>' +
      '<button type="submit" style="width:100%;padding:14px;border:0;border-radius:10px;background:#0d47a1;color:white;font-size:16px;font-weight:bold">Continue</button></form>';
    overlay.querySelector('h3').textContent = title;
    overlay.querySelector('form p').textContent = message;
    document.body.appendChild(overlay);
    const input = overlay.querySelector('input');
    input.focus();
    overlay.querySelector('form').addEventListener('submit', function (e) {
      e.preventDefault();
      const result = onSubmit(input.value);
      if (result) overlay.remove();
      else { overlay.querySelector('.auth-error').textContent = 'Incorrect password. Please try again.'; input.value = ''; input.focus(); }
    });
  }

  function requireStudentAccess(next) {
    if (sessionStorage.getItem(accessKey) === 'yes') { next(); return; }
    passwordScreen('Student access', 'Enter the shared class password to view the portal.', function (value) {
      if (value !== STUDENT_PASSWORD) return false;
      sessionStorage.setItem(accessKey, 'yes'); next(); return true;
    });
  }

  function requireAdminAccess(next) {
    if (sessionStorage.getItem(adminKey) === 'yes') { next(); return; }
    passwordScreen('Admin access', 'Enter the admin password to manage students or change attendance.', function (value) {
      if (value !== ADMIN_PASSWORD) return false;
      sessionStorage.setItem(adminKey, 'yes'); next(); return true;
    });
  }

  window.CIVIL3_AUTH = {
    requireAdmin: function () {
      if (sessionStorage.getItem(adminKey) === 'yes') return true;
      requireAdminAccess(function () {});
      return false;
    }
  };

  requireStudentAccess(function () {
    if (isManageStudents) requireAdminAccess(function () {});
  });
})();
