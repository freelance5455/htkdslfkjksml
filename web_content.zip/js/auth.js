async function sb(){return window.WS_SUPABASE_READY?await window.WS_SUPABASE_READY:null}
async function cacheProfile(p){if(!p?.id)return;await dbPut('authCache',{id:p.id,profile:p,cachedAt:Date.now()})}
async function getCachedProfile(id){const x=await dbGet('authCache',id);return x?.profile||null}
async function getProfileById(id){const c=await sb();if(c&&navigator.onLine){const {data,error}=await c.from('profiles').select('*').eq('id',id).maybeSingle();if(error)throw error;if(data){await cacheProfile(data);await dbPut('profiles',data)}return data}return getCachedProfile(id)}
function normalizeProfile(p,id,email){const name=(p?.name||p?.full_name||email?.split('@')[0]||'Utilisateur').trim();const active=(p?.active??p?.is_active)!==false;return {...p,id,email,name,active,is_active:active,full_name:p?.full_name||name}}
async function currentUser(){const c=await sb();if(!c)return null;let s=null;try{const r=await c.auth.getSession();s=r.data?.session}catch(e){}if(!s?.user)return null;try{const p=await getProfileById(s.user.id);if(!p||((p.active ?? p.is_active)===false))return null;return normalizeProfile(p,s.user.id,s.user.email)}catch(e){const p=await getCachedProfile(s.user.id);if(!p||((p.active ?? p.is_active)===false))return null;return normalizeProfile(p,s.user.id,s.user.email)}}
async function logout(){const c=await sb();try{await c?.auth.signOut()}finally{location.href='index.html'}}
async function login(email,password,remember){const c=await sb();if(!c)throw new Error('Connexion Supabase indisponible');const {data,error}=await c.auth.signInWithPassword({email:email.trim(),password});if(error)throw error;const p=await getProfileById(data.user.id);if(!p||((p.active ?? p.is_active)===false)){await c.auth.signOut();throw new Error('Profil WONDER SHIFT absent ou désactivé.');}await cacheProfile(p);await dbPut('profiles',p);if(remember)localStorage.setItem('ws_remember','1');else localStorage.removeItem('ws_remember');return normalizeProfile(p,data.user.id,data.user.email)}
async function requireAuth(){const u=await currentUser();if(!u){location.href='index.html';return null}return u}
function isDev(u){return u?.role==='Développeur'}
function isSupervisor(u){return u?.role==='Superviseur'||isDev(u)}
function isAgent(u){return u?.role==='Agent'}
function canPage(u,page){if(isDev(u))return true;if(isSupervisor(u))return ['dashboard','operations','operation','reports','stock','cash','notifications','settings','users'].includes(page);return ['dashboard','operations','operation','reports','notifications','settings'].includes(page)}
