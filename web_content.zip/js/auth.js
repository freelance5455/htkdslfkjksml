/**
 * BD BLOOD DONATION - Authentication Controller
 * Real Firebase Authentication, Google Sign-in, Profile sync in Firestore
 */

import { 
  auth, 
  db, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signInWithPopup, 
  googleProvider,
  sendPasswordResetEmail, 
  signOut, 
  onAuthStateChanged,
  doc, 
  getDoc, 
  setDoc, 
  updateDoc,
  serverTimestamp 
} from './firebase-config.js';
import { 
  showToast, 
  isValidBdPhone, 
  isValidEmail, 
  checkPasswordStrength 
} from './utils.js';

let currentUser = null;
let currentUserProfile = null;
const authListeners = [];

export function getCurrentUser() {
  return currentUser;
}

export function getCurrentUserProfile() {
  return currentUserProfile;
}

export function onAuthChanged(callback) {
  authListeners.push(callback);
  // Immediate trigger if state already resolved
  if (currentUser !== undefined) {
    callback(currentUser, currentUserProfile);
  }
  return () => {
    const idx = authListeners.indexOf(callback);
    if (idx > -1) authListeners.splice(idx, 1);
  };
}

function notifyAuthListeners() {
  authListeners.forEach(cb => {
    try {
      cb(currentUser, currentUserProfile);
    } catch (e) {
      console.error('[Auth Listener Error]', e);
    }
  });
}

// Subscribe to Firebase Auth state
onAuthStateChanged(auth, async (user) => {
  currentUser = user;
  if (user) {
    await fetchUserProfile(user.uid);
  } else {
    currentUserProfile = null;
    notifyAuthListeners();
  }
});

export async function fetchUserProfile(uid) {
  try {
    const userRef = doc(db, 'users', uid);
    const snap = await getDoc(userRef);
    if (snap.exists()) {
      currentUserProfile = { id: snap.id, ...snap.data() };
      // Update last active
      updateDoc(userRef, { lastActive: serverTimestamp() }).catch(() => {});
    } else {
      currentUserProfile = null;
    }
  } catch (error) {
    console.warn('[Fetch Profile]', error.message);
  }
  notifyAuthListeners();
  return currentUserProfile;
}

/**
 * Register with Email and Password
 */
export async function registerWithEmail({
  fullName,
  email,
  phone,
  password,
  confirmPassword,
  bloodGroup,
  division,
  district,
  upazila
}) {
  // Validations
  if (!fullName || fullName.trim().length < 3) {
    throw new Error('দয়া করে আপনার সম্পূর্ণ নাম সঠিকভাবে লিখুন (কমপক্ষে ৩ অক্ষর)।');
  }
  if (!isValidEmail(email)) {
    throw new Error('সঠিক ইমেইল ঠিকানা প্রদান করুন।');
  }
  if (!isValidBdPhone(phone)) {
    throw new Error('সঠিক ১১ ডিজিটের বাংলাদেশি মোবাইল নম্বর দিন (যেমন: 017XXXXXXXX)।');
  }
  const pwdCheck = checkPasswordStrength(password);
  if (!pwdCheck.valid) {
    throw new Error(pwdCheck.messageBn);
  }
  if (password !== confirmPassword) {
    throw new Error('পাসওয়ার্ড এবং কনফার্ম পাসওয়ার্ড মিলছে না।');
  }
  if (!bloodGroup) {
    throw new Error('রক্তের গ্রুপ নির্বাচন করা বাধ্যতামূলক।');
  }
  if (!division || !district) {
    throw new Error('আপনার বিভাগ ও জেলা নির্বাচন করুন।');
  }

  // 1. Firebase Auth create
  const userCredential = await createUserWithEmailAndPassword(auth, email.trim(), password);
  const user = userCredential.user;

  // 2. Save user profile into Firestore
  const profileData = {
    uid: user.uid,
    fullName: fullName.trim(),
    email: email.trim().toLowerCase(),
    phone: phone.trim(),
    bloodGroup,
    division,
    district,
    upazila: upazila || '',
    isAvailable: true,
    donationCount: 0,
    ratingCount: 0,
    ratingSum: 0,
    averageRating: 5.0,
    photoURL: user.photoURL || '',
    createdAt: serverTimestamp(),
    lastActive: serverTimestamp()
  };

  await setDoc(doc(db, 'users', user.uid), profileData);
  currentUserProfile = profileData;
  showToast('রেজিস্ট্রেশন সফল হয়েছে! স্বাগতম।', 'success');
  return user;
}

/**
 * Login with Email and Password
 */
export async function loginWithEmail(email, password) {
  if (!isValidEmail(email)) {
    throw new Error('সঠিক ইমেইল ঠিকানা প্রদান করুন।');
  }
  if (!password) {
    throw new Error('পাসওয়ার্ড প্রদান করুন।');
  }

  const cred = await signInWithEmailAndPassword(auth, email.trim(), password);
  await fetchUserProfile(cred.user.uid);
  showToast('স্বাগতম! আপনি সফলভাবে লগইন করেছেন।', 'success');
  return cred.user;
}

/**
 * Google Sign-In
 */
export async function loginWithGoogle() {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    const user = result.user;
    
    // Check if user document already exists
    const userRef = doc(db, 'users', user.uid);
    const snap = await getDoc(userRef);

    if (!snap.exists()) {
      // First time Google user: save default baseline profile
      const newProfile = {
        uid: user.uid,
        fullName: user.displayName || 'রক্তদাতা বন্ধু',
        email: user.email || '',
        phone: user.phoneNumber || '',
        bloodGroup: '', // Needs profile completion
        division: '',
        district: '',
        upazila: '',
        isAvailable: true,
        donationCount: 0,
        ratingCount: 0,
        ratingSum: 0,
        averageRating: 5.0,
        photoURL: user.photoURL || '',
        createdAt: serverTimestamp(),
        lastActive: serverTimestamp(),
        needsProfileCompletion: true
      };
      await setDoc(userRef, newProfile);
      currentUserProfile = newProfile;
      showToast('গুগল দিয়ে লগইন সফল হয়েছে! অনুগ্রহ করে প্রোফাইল সম্পূর্ণ করুন।', 'info');
    } else {
      currentUserProfile = { id: snap.id, ...snap.data() };
      showToast('গুগল দিয়ে সফলভাবে লগইন হয়েছে।', 'success');
    }

    notifyAuthListeners();
    return user;
  } catch (error) {
    if (error.code === 'auth/popup-closed-by-user') {
      throw new Error('গুগল লগইন পপআপ বন্ধ করা হয়েছে।');
    }
    throw error;
  }
}

/**
 * Send Password Reset Email
 */
export async function sendPasswordReset(email) {
  if (!isValidEmail(email)) {
    throw new Error('পাসওয়ার্ড রিসেটের জন্য একটি সঠিক ইমেইল দিন।');
  }
  await sendPasswordResetEmail(auth, email.trim());
  showToast('পাসওয়ার্ড রিসেট লিংক আপনার ইমেইলে পাঠানো হয়েছে।', 'success');
}

/**
 * Logout
 */
export async function logoutUser() {
  await signOut(auth);
  currentUser = null;
  currentUserProfile = null;
  showToast('লগআউট সফল হয়েছে।', 'info');
  notifyAuthListeners();
}

/**
 * Update Donor Availability toggle
 */
export async function toggleDonorAvailability(isAvailable) {
  if (!currentUser) throw new Error('আপনাকে লগইন করতে হবে।');
  const userRef = doc(db, 'users', currentUser.uid);
  await updateDoc(userRef, {
    isAvailable: Boolean(isAvailable),
    lastActive: serverTimestamp()
  });
  if (currentUserProfile) {
    currentUserProfile.isAvailable = Boolean(isAvailable);
  }
  notifyAuthListeners();
  showToast(isAvailable ? 'আপনি এখন রক্তদানে প্রস্তুত হিসেবে চিহ্নিত।' : 'আপনার স্ট্যাটাস এখন অনুপলব্ধ।', 'success');
}
