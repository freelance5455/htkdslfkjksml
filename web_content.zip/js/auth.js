import { auth, db } from "./firebase.js";

import {
createUserWithEmailAndPassword
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";


import {
doc,
setDoc,
serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";



// ==========================
// Password Eye System
// ==========================


const togglePassword =
document.getElementById("togglePassword");


if(togglePassword){

togglePassword.onclick = ()=>{

const password =
document.getElementById("password");


password.type =
password.type === "password"
? "text"
: "password";


};

}



const toggleConfirmPassword =
document.getElementById("toggleConfirmPassword");


if(toggleConfirmPassword){

toggleConfirmPassword.onclick = ()=>{


const confirmPassword =
document.getElementById("confirmPassword");


confirmPassword.type =
confirmPassword.type === "password"
? "text"
: "password";


};

}




// ==========================
// Password Strength
// ==========================


const passwordInput =
document.getElementById("password");


const strength =
document.getElementById("passwordStrength");



if(passwordInput){


passwordInput.addEventListener("input",()=>{


let value =
passwordInput.value;


if(value.length < 6){

strength.innerHTML =
"🔴 Weak Password";

strength.style.color="red";


}

else if(value.length < 10){

strength.innerHTML =
"🟡 Medium Password";

strength.style.color="orange";


}

else{

strength.innerHTML =
"🟢 Strong Password";

strength.style.color="green";


}


});


}




// ==========================
// Register System
// ==========================



const registerBtn =
document.getElementById("registerBtn");



registerBtn.addEventListener("click", async()=>{


const name =
document.getElementById("name").value.trim();


const username =
document.getElementById("username").value.trim();


const email =
document.getElementById("email").value.trim();


const phone =
document.getElementById("phone").value.trim();


const password =
document.getElementById("password").value;


const confirmPassword =
document.getElementById("confirmPassword").value;


const referral =
document.getElementById("referral").value.trim();



const terms =
document.getElementById("terms").checked;



// Validation


if(
!name ||
!username ||
!email ||
!phone ||
!password ||
!confirmPassword
){

alert("Please complete all required fields.");

return;

}



if(!terms){

alert("Please accept Terms & Conditions.");

return;

}



if(password.length < 6){

alert("Password must contain at least 6 characters.");

return;

}



if(password !== confirmPassword){

alert("Password does not match.");

return;

}




// Loading


registerBtn.innerHTML =
"⏳ Creating Account...";


registerBtn.disabled = true;




try{


const userCredential =
await createUserWithEmailAndPassword(
auth,
email,
password
);



const user =
userCredential.user;



await setDoc(

doc(db,"users",user.uid),

{


uid:user.uid,


name:name,


username:username,


email:email,


phone:phone,


referralCode:referral,



balance:0,


totalEarning:0,


totalReferrals:0,


premium:false,


verified:false,


banned:false,


role:"user",


createdAt:serverTimestamp()


}


);




await alert(
"🎉 Registration Successful!"
);



// Redirect Login


setTimeout(()=>{


window.location.href="index.html";


},1500);



}

catch(error){



registerBtn.innerHTML =
"🚀 Create My Account";


registerBtn.disabled=false;



if(error.code === 
"auth/email-already-in-use"){

alert(
"❌ Email already registered."
);

}

else{

alert(error.message);

}


}



});