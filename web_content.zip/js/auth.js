/**
 * auth.js
 * Autenticação e controle de sessão.
 *
 * LIMITAÇÃO HONESTA E IMPORTANTE:
 * Como não existe backend/servidor neste projeto, a "sessão" e as verificações
 * de permissão aqui rodam inteiramente no navegador (localStorage). Isso é
 * suficiente para estruturar a ARQUITETURA (rotas protegidas por perfil,
 * separação de responsabilidades) mas NÃO é uma barreira de segurança real:
 * qualquer pessoa com acesso ao DevTools do navegador pode alterar os dados.
 * Uma implementação de produção exige que login e toda verificação de
 * permissão aconteçam num servidor. Isto está documentado no README.
 *
 * A senha não é salva em texto puro: é aplicado SHA-256 + salt por usuário
 * (via Web Crypto API, nativa do navegador). Isso reduz o risco óbvio de
 * "abrir localStorage e ver a senha", mas continua sem valor de segurança
 * real num contexto 100% client-side.
 */
const Auth = (function(){

  const SESSION_KEY = () => storageKey('session');

  async function _hashSenha(senha, salt){
    const enc = new TextEncoder().encode(salt + ':' + senha);
    const buf = await crypto.subtle.digest('SHA-256', enc);
    return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2,'0')).join('');
  }
  function _gerarSalt(){
    return Array.from(crypto.getRandomValues(new Uint8Array(12))).map(b=>b.toString(16).padStart(2,'0')).join('');
  }

  return {
    /** Cria um novo usuário (anfitrião ou profissional) + sessão ativa. */
    async signUp({ nome, email, telefone, tipo_usuario, senha, cpf, dadosProfissional }){
      const existente = DB.findOne('users', u => u.email.toLowerCase() === email.toLowerCase());
      if(existente) throw new Error('Já existe uma conta com este e-mail.');

      const salt = _gerarSalt();
      const senha_hash = salt + '$' + await _hashSenha(senha, salt);

      const cpfUsuario = tipo_usuario === 'profissional' ? (dadosProfissional && dadosProfissional.cpf) : cpf;
      const usuario = DB.insert('users', Models.novoUsuario({ nome, email, telefone, tipo_usuario, senha_hash, cpf: cpfUsuario }));

      const avisos = [];
      if(tipo_usuario === 'profissional'){
        const dp = dadosProfissional || {};
        // O cadastro do profissional (perfil + categoria) NUNCA pode ficar
        // bloqueado por causa de mídia (selfie/documentos): no DEV, documentos
        // não são obrigatórios (ver README) e a selfie pode ser reenviada
        // depois pelo perfil. Por isso cada etapa de mídia é isolada: se uma
        // falhar (ex.: estouro de cota do localStorage), o cadastro continua.
        let providerCriado;
        try{
          providerCriado = DB.insert('providers', Models.novoProvider({
            user_id: usuario.id, cpf: dp.cpf, rg: dp.rg, data_nascimento: dp.data_nascimento,
            endereco: dp.endereco, cidade: dp.cidade, selfie: dp.selfie, categorias: dp.categorias,
          }));
        }catch(e){
          avisos.push('Não foi possível salvar a selfie agora (' + e.message + '). Você pode reenviá-la depois pelo seu perfil.');
          providerCriado = DB.insert('providers', Models.novoProvider({
            user_id: usuario.id, cpf: dp.cpf, rg: dp.rg, data_nascimento: dp.data_nascimento,
            endereco: dp.endereco, cidade: dp.cidade, selfie: '', categorias: dp.categorias,
          }));
        }
        if(dp.documentos){
          Object.entries(dp.documentos).forEach(([tipo, arquivo]) => {
            if(!arquivo) return;
            try{
              ProvidersService.enviarDocumento(usuario.id, tipo, arquivo);
            }catch(e){
              avisos.push('Não foi possível enviar um dos documentos agora (' + e.message + '). Você pode reenviá-lo depois.');
            }
          });
        }
      }

      // Sessão primeiro (crítico para o redirecionamento funcionar) — depois
      // auditoria (só um registro informativo). Nenhuma das duas pode travar
      // um cadastro cujo usuário já foi criado com sucesso.
      try{ this._criarSessao(usuario); }catch(e){ avisos.push('Conta criada, mas não foi possível iniciar sua sessão automaticamente. Faça login com seu e-mail e senha.'); }
      try{ AuditLogService.registrar({ user_id: usuario.id, acao: 'cadastro', entidade: 'users', entidade_id: usuario.id, dados_novos: { email, tipo_usuario } }); }catch(e){ /* auditoria é informativa; não bloqueia o cadastro */ }
      usuario._avisos = avisos; // uso interno da tela de cadastro (não é campo persistido)
      return usuario;
    },

    /** Autentica por e-mail + senha. */
    async login(email, senha){
      const usuario = DB.findOne('users', u => u.email.toLowerCase() === (email||'').toLowerCase());
      if(!usuario) throw new Error('E-mail ou senha incorretos.');
      if(usuario.status !== 'ativo') throw new Error('Esta conta está suspensa. Fale com o suporte.');

      const [salt, hashSalvo] = usuario.senha_hash.split('$');
      const hashDigitado = await _hashSenha(senha, salt);
      if(hashDigitado !== hashSalvo) throw new Error('E-mail ou senha incorretos.');

      AuditLogService.registrar({ user_id: usuario.id, acao: 'login', entidade: 'users', entidade_id: usuario.id });
      this._criarSessao(usuario);
      return usuario;
    },

    logout(){
      const sessao = this.getSessao();
      if(sessao) AuditLogService.registrar({ user_id: sessao.id, acao: 'logout', entidade: 'users', entidade_id: sessao.id });
      localStorage.removeItem(SESSION_KEY());
    },

    _criarSessao(usuario){
      const sessao = { id: usuario.id, nome: usuario.nome, email: usuario.email, telefone: usuario.telefone, cpf: usuario.cpf || '', tipo_usuario: usuario.tipo_usuario };
      localStorage.setItem(SESSION_KEY(), JSON.stringify(sessao));
    },

    /** Retorna { id, nome, email, tipo_usuario } do usuário logado, ou null. */
    getSessao(){
      const raw = localStorage.getItem(SESSION_KEY());
      return raw ? JSON.parse(raw) : null;
    },

    /** Redireciona para login.html se não houver sessão ativa. */
    exigirLogin(){
      const s = this.getSessao();
      if(!s){ window.location.href = 'login.html'; return null; }
      return s;
    },

    /** Redireciona se o usuário logado não tiver um dos perfis permitidos. */
    exigirPerfil(...perfis){
      const s = this.exigirLogin();
      if(!s) return null;
      if(!perfis.includes(s.tipo_usuario)){
        window.location.href = 'index.html';
        return null;
      }
      return s;
    },
  };
})();
