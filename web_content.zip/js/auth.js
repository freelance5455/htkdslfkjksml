
function adminLogin(){let pin=prompt('Enter demo admin passcode (demo only):');if(pin!=='MAXADMIN26')return toast('Incorrect demo passcode.');sessionStorage.setItem('ffmax_admin','yes');toast('Admin demo access granted.');setTimeout(()=>location.reload(),500)}
function isAdmin(){return sessionStorage.getItem('ffmax_admin')==='yes'}
