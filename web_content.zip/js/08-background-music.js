(() => {
    const music = document.getElementById('ffm26-background-music');
    let playsInCycle = 0;
    try {
        const savedMuted = localStorage.getItem('ffm26_music_muted');
        const savedVolume = localStorage.getItem('ffm26_music_volume');
        music.muted = savedMuted === '1';
        const initialVolume = savedVolume === null ? 70 : Math.max(0, Math.min(100, Number(savedVolume) || 0));
        music.volume = initialVolume / 100;
        const muteToggle = document.getElementById('music-muted-toggle');
        const volumeControl = document.getElementById('music-volume-control');
        const volumeLabel = document.getElementById('music-volume-value');
        if (muteToggle) muteToggle.checked = music.muted;
        if (volumeControl) volumeControl.value = initialVolume;
        if (volumeLabel) volumeLabel.textContent = initialVolume + '%';
    } catch (_) {}
    let musicStarted = false;
    let restartTimer = null;

    music.addEventListener('ended', () => {
        playsInCycle += 1;
        if (playsInCycle < 3) {
            music.currentTime = 0;
            music.play().catch(() => {});
        } else {
            playsInCycle = 0;
            restartTimer = window.setTimeout(() => {
                music.currentTime = 0;
                music.play().catch(() => {});
            }, 2000);
        }
    });

    // Mobile browsers usually require a user gesture before audio can start.
    const startMusic = () => {
        if (musicStarted) return;
        music.play().then(() => {
            musicStarted = true;
            document.removeEventListener('pointerdown', startMusic);
            document.removeEventListener('keydown', startMusic);
            document.removeEventListener('touchstart', startMusic);
        }).catch(() => {});
    };
    document.addEventListener('pointerdown', startMusic, { passive: true });
    document.addEventListener('keydown', startMusic);
    document.addEventListener('touchstart', startMusic, { passive: true });
})();
