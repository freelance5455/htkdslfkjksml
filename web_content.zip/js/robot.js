/* يمكن هدف؟ — "روبو": the animated analyst (built from the original robot artwork, layered) */
(function () {
  const IMG_W = 427, IMG_H = 640;
  const PIVOT = { x: 138, y: 325 };          // shoulder of the raised arm
  const HAND = { x: 62, y: 238 };            // palm centre in the artwork
  const BASE = Math.atan2(HAND.y - PIVOT.y, HAND.x - PIVOT.x);

  /* ---------------- voice (Web Speech API, Arabic) ---------------- */
  const voice = {
    enabled: false, ready: false, v: null,
    pick() {
      if (!('speechSynthesis' in window)) return null;
      const vs = speechSynthesis.getVoices() || [];
      const ar = vs.filter(x => /^ar/i.test(x.lang));
      this.v = ar.find(x => /SA|AE|EG/i.test(x.lang) && /google|natural|neural|online/i.test(x.name)) || ar.find(x => /google|natural|neural|online/i.test(x.name)) || ar[0] || null;
      this.ready = true; return this.v;
    },
    has() { if (!this.ready) this.pick(); return !!this.v; },
    cancel() { try { speechSynthesis.cancel(); } catch (e) {} },
    speak(text, { rate = 1.02, pitch = 1.1, onend, onboundary } = {}) {
      if (!this.enabled || !('speechSynthesis' in window)) return false;
      if (!this.ready) this.pick();
      const u = new SpeechSynthesisUtterance(text.replace(/[«»"]/g, '').replace(/xG/g, 'إكس جي'));
      u.lang = (this.v && this.v.lang) || 'ar-SA'; if (this.v) u.voice = this.v;
      u.rate = rate; u.pitch = pitch;
      if (onend) { u.onend = onend; u.onerror = onend; }
      if (onboundary) u.onboundary = onboundary;
      speechSynthesis.speak(u); return true;
    },
  };
  if ('speechSynthesis' in window) speechSynthesis.onvoiceschanged = () => voice.pick();

  /* ---------------- robot figure ---------------- */
  function figureHTML() {
    return `<div class="robo-fig">
      <img class="robo-body" src="assets/robot-body.webp" alt="" draggable="false">
      <img class="robo-arm" src="assets/robot-arm.webp" alt="" draggable="false">
      <svg class="robo-face" viewBox="0 0 ${IMG_W} ${IMG_H}" aria-hidden="true">
        <g class="robo-lids"><ellipse cx="183.5" cy="177.5" rx="24" ry="25"/><ellipse cx="270.5" cy="191.5" rx="24" ry="25"/></g>
        <g class="robo-mouth"><ellipse cx="224" cy="225" rx="17" ry="10" fill="#241116"/><ellipse cx="224" cy="230" rx="10" ry="4.5" fill="#c4555f"/></g>
        <g class="robo-led"><circle cx="251" cy="38" r="9"/></g>
      </svg>
    </div><div class="robo-shadow"></div>`;
  }

  function create(host, { size = 220, wave = false } = {}) {
    const el = document.createElement('div');
    el.className = 'robo'; el.style.setProperty('--rw', size + 'px');
    el.innerHTML = figureHTML();
    host.appendChild(el);
    const arm = el.querySelector('.robo-arm');
    let angle = 0, talkTok = 0, beam = null, follow = 0, ptTimer = 0;

    const setAngle = (deg, ms = 650) => { angle = deg; arm.style.transition = `transform ${ms}ms cubic-bezier(.3,.9,.3,1.1)`; arm.style.transform = `rotate(${deg}deg)`; };
    function handPoint(deg = angle) {
      const r = el.querySelector('.robo-fig').getBoundingClientRect();
      const k = r.width / IMG_W, th = deg * Math.PI / 180;
      const vx = HAND.x - PIVOT.x, vy = HAND.y - PIVOT.y;
      return { x: r.left + (PIVOT.x + vx * Math.cos(th) - vy * Math.sin(th)) * k, y: r.top + (PIVOT.y + vx * Math.sin(th) + vy * Math.cos(th)) * k };
    }
    function angleTo(tx, ty) {
      const r = el.querySelector('.robo-fig').getBoundingClientRect(); const k = r.width / IMG_W;
      const px = r.left + PIVOT.x * k, py = r.top + PIVOT.y * k;
      let d = (Math.atan2(ty - py, tx - px) - BASE) * 180 / Math.PI;
      while (d > 180) d -= 360; while (d < -180) d += 360;
      return Math.max(-125, Math.min(40, d));
    }
    function attachBeam(svg) { beam = svg; }
    function drawBeam(target) {
      if (!beam) return;
      const line = beam.querySelector('line'), dot = beam.querySelector('circle.tip'), ring = beam.querySelector('circle.ring');
      if (!target) { beam.classList.remove('on'); return; }
      const br = beam.getBoundingClientRect(); const h = handPoint();
      const tr = target.getBoundingClientRect(); const tx = tr.left + tr.width / 2, ty = tr.top + tr.height / 2;
      line.setAttribute('x1', h.x - br.left); line.setAttribute('y1', h.y - br.top); line.setAttribute('x2', tx - br.left); line.setAttribute('y2', ty - br.top);
      dot.setAttribute('cx', tx - br.left); dot.setAttribute('cy', ty - br.top);
      ring.setAttribute('cx', tx - br.left); ring.setAttribute('cy', ty - br.top); ring.setAttribute('r', Math.min(30, Math.max(tr.width, tr.height) / 2 + 6));
      beam.classList.add('on');
    }
    /* point the hand at an element; the beam follows it while it moves */
    function point(target, { hold = 0 } = {}) {
      cancelAnimationFrame(follow); clearTimeout(ptTimer); el.classList.remove('waving');
      if (!target) { setAngle(0); drawBeam(null); el.classList.remove('pointing'); return; }
      el.classList.add('pointing');
      const t0 = performance.now();
      const loop = () => {
        const tr = target.getBoundingClientRect();
        const a = angleTo(tr.left + tr.width / 2, tr.top + tr.height / 2);
        if (Math.abs(a - angle) > 0.6) setAngle(a, performance.now() - t0 < 50 ? 650 : 120);
        drawBeam(target);
        if (target.isConnected && (!hold || performance.now() - t0 < hold)) follow = requestAnimationFrame(loop);
      };
      setAngle(angleTo(target.getBoundingClientRect().left + target.getBoundingClientRect().width / 2, target.getBoundingClientRect().top + target.getBoundingClientRect().height / 2));
      ptTimer = setTimeout(() => { follow = requestAnimationFrame(loop); }, 420);
    }
    function doWave(on = true) { cancelAnimationFrame(follow); clearTimeout(ptTimer); drawBeam(null); arm.style.transition = ''; arm.style.transform = ''; angle = 0; el.classList.toggle('waving', on); el.classList.remove('pointing'); }
    function talking(on) { el.classList.toggle('talking', on); }
    /* say: types into bubble + speaks (if voice on). resolves when finished */
    function say(text, bubble, { rate, pitch } = {}) {
      const tok = ++talkTok;
      voice.cancel();
      return new Promise(res => {
        let done = false, typed = false, spoken = !voice.enabled;
        const finish = () => { if (tok !== talkTok) return res(false); if (typed && spoken && !done) { done = true; talking(false); setTimeout(() => res(true), 350); } };
        talking(true);
        if (bubble) {
          bubble.classList.add('show');
          const t = bubble.querySelector('.bt') || bubble; t.textContent = '';
          let i = 0; const per = voice.enabled && voice.has() ? 42 : 34;
          const step = () => {
            if (tok !== talkTok) return;
            i = Math.min(text.length, i + 2); t.textContent = text.slice(0, i);
            if (i < text.length) setTimeout(step, per * 2); else { typed = true; if (!voice.enabled || !voice.has()) setTimeout(() => { spoken = true; finish(); }, 900 + text.length * 22); finish(); }
          };
          step();
        } else typed = true;
        if (voice.enabled && voice.has()) {
          let ended = false;
          const end = () => { if (ended) return; ended = true; spoken = true; finish(); };
          voice.speak(text, { rate, pitch, onend: end });
          setTimeout(end, 2500 + text.length * 110); // safety
        } else if (!bubble) setTimeout(() => { spoken = true; finish(); }, 800 + text.length * 50);
      });
    }
    function stop() { talkTok++; voice.cancel(); talking(false); cancelAnimationFrame(follow); clearTimeout(ptTimer); drawBeam(null); }
    if (wave) doWave(true);
    return { el, say, point, wave: doWave, stop, attachBeam, talking, setAngle };
  }

  /* ---------------- splash / welcome ---------------- */
  function splash(onDone) {
    const s = document.createElement('div');
    s.className = 'splash'; s.setAttribute('role', 'dialog'); s.setAttribute('aria-label', 'شاشة الترحيب');
    s.innerHTML = `<div class="sp-lights" aria-hidden="true"><i></i><i></i><i></i></div>
      <div class="sp-pitch" aria-hidden="true"></div>
      <div class="sp-center">
        <div class="sp-robot" id="spRobot"></div>
        <div class="sp-bubble bubble"><span class="bt"></span></div>
        <h1 class="sp-title">يمكن هدف<span>؟</span></h1>
        <p class="sp-tag">محللك الذكي لكل مباراة: مباشر، أهداف، تشكيلات، تحليل وتوقعات</p>
        <div class="sp-actions"><button class="btn btn-lg" id="spGo">يلا نبدأ</button><button class="btn btn-ghost" id="spMute">ادخل بدون صوت</button></div>
        <div class="sp-load"><i></i></div>
      </div>`;
    document.body.appendChild(s);
    const r = create(s.querySelector('#spRobot'), { size: Math.min(260, window.innerHeight * 0.32), wave: true });
    const bubble = s.querySelector('.sp-bubble');
    const greet = 'هلا بيك! آني روبو، محللك الذكي. أشرحلك كل مباراة، أتوقعلك النتيجة، وأجيبلك الأهداف أول بأول.';
    setTimeout(() => r.say(greet, bubble), 500);
    let closed = false;
    const close = withVoice => {
      if (closed) return; closed = true;
      voice.enabled = !!withVoice;
      if (withVoice) { voice.pick(); r.stop(); voice.speak('يلا! نبدأ.'); }
      s.classList.add('out');
      setTimeout(() => { r.stop(); s.remove(); onDone && onDone(withVoice); }, 650);
    };
    s.querySelector('#spGo').onclick = () => close(true);
    s.querySelector('#spMute').onclick = () => close(false);
    const auto = setTimeout(() => close(false), 14000);
    s.addEventListener('click', () => clearTimeout(auto), { once: true });
    s.querySelector('#spGo').focus();
  }

  YH.robot = { create, splash, voice };
})();
