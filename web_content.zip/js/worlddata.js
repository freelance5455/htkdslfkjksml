/* worlddata.js — Phase 9 scenario "Old World 1936": a simplified real-world map (Americas, Europe, Africa, Middle East, Asia, Australia).
   Coastlines come from landdata.js (Natural Earth 1:50m land, public domain, simplified); borders come from weighted seed points per country, so they are
   approximate by design. Country colours are original; flags are drawn by flags.js (c. 1936 designs).
   The map is turned into provinces + sea zones by world.js (polygon mode). */
(function (G) {
  'use strict';
  G.SCENARIOS = G.SCENARIOS || {};

  const P = a => { const o = []; for (let i = 0; i < a.length; i += 2) o.push([a[i], a[i + 1]]); return o; };

  /* ---------- coastlines: G.NE_LAND from landdata.js (Natural Earth, public domain) ---------- */

  /* ---------- terrain / resource features: [lon, lat, radius°, kind-or-resource, value] ---------- */
  const TERR = [
    ['mountain', 10, 46.5, 3.2], ['mountain', 0, 42.7, 2], ['mountain', 24, 47, 3], ['mountain', 44, 42.3, 3], ['mountain', 59, 60, 2.5], ['mountain', 59, 53, 2.5],
    ['mountain', 13, 63, 3.5], ['mountain', 15, 67, 2.5], ['mountain', 85, 29, 5], ['mountain', 90, 33, 7], ['mountain', 80, 42, 4], ['mountain', 88, 49, 4], ['mountain', 49, 32, 3],
    ['mountain', -3, 32.5, 4], ['mountain', 38, 9, 4], ['mountain', -70, -20, 3.5], ['mountain', -72, -35, 3], ['mountain', -74, -5, 2.5], ['mountain', -75, 3, 2], ['mountain', -108, 45, 6],
    ['mountain', -115, 55, 3], ['mountain', -120, 38, 3], ['mountain', -105, 25, 5], ['mountain', 138, 36, 1.8], ['mountain', 100, 28, 3], ['mountain', 68, 35, 4], ['mountain', 40, 38.5, 3],
    ['desert', 0, 25, 11], ['desert', 15, 23, 10], ['desert', 28, 24, 8], ['desert', 45, 23, 10], ['desert', 105, 43, 8], ['desert', 84, 39, 6], ['desert', 22, -23, 6], ['desert', 133, -25, 12],
    ['desert', 57, 32, 5], ['desert', 71, 27, 3], ['desert', -69.5, -24, 3], ['desert', -108, 31, 5], ['desert', -116, 39, 4], ['desert', 40, 33, 4], ['desert', 60, 42, 5], ['desert', 120, -23, 6],
    ['forest', 100, 60, 25], ['forest', 60, 62, 10], ['forest', -62, -4, 12], ['forest', 22, 0, 8], ['forest', 102, 17, 7], ['forest', 110, 0, 6], ['forest', -100, 55, 15], ['forest', 17, 62, 4],
    ['forest', 130, 52, 8], ['forest', -125, 52, 6], ['forest', -85, 33, 4], ['forest', -75, 48, 5], ['forest', 8, 5, 5], ['forest', 36, 62, 6], ['forest', 14, 50, 2],
    ['marsh', 28, 52, 2.5], ['marsh', -90, 30, 2], ['marsh', 88, 23, 2], ['marsh', 105, 10, 2], ['marsh', -50, 0, 2], ['marsh', 31, 8, 3], ['marsh', 75, 62, 5],
    ['res', 102, 5, 5, 'rubber', 4], ['res', 107, -5, 4, 'rubber', 4], ['res', 105, 12, 4, 'rubber', 3], ['res', -60, -5, 5, 'rubber', 3], ['res', 22, 0, 6, 'rubber', 3], ['res', 115, 1, 4, 'rubber', 3],
    ['res', 49, 31, 4, 'oil', 6], ['res', 49, 26, 3, 'oil', 5], ['res', 49.5, 40.3, 2.5, 'oil', 5], ['res', 26, 45, 2, 'oil', 4], ['res', -97, 32, 3, 'oil', 6], ['res', -98, 36, 2, 'oil', 4], ['res', -119, 35, 2, 'oil', 4],
    ['res', -67, 9, 3, 'oil', 5], ['res', 104, -2, 3, 'oil', 3], ['res', 115, 0, 3, 'oil', 3], ['res', -98, 21, 2.5, 'oil', 4], ['res', 95, 20, 2, 'oil', 2], ['res', 143, 51, 1.5, 'oil', 2], ['res', 45.7, 43.3, 2, 'oil', 3], ['res', 56, 59, 3, 'oil', 2],
    ['res', 7, 51.3, 2, 'steel', 5], ['res', 18.5, 50.3, 2, 'steel', 4], ['res', 38, 48, 3, 'steel', 5], ['res', 60, 56, 3, 'steel', 5], ['res', -2, 53, 2, 'steel', 4], ['res', 6, 49, 1.5, 'steel', 4],
    ['res', -79, 40.5, 3, 'steel', 6], ['res', -85, 42, 3, 'steel', 5], ['res', 123, 42, 3, 'steel', 4], ['res', 135, 35, 2, 'steel', 3], ['res', 20, 67.8, 2, 'steel', 4], ['res', 33.4, 47.9, 2, 'steel', 4],
    ['res', 14, 50, 2, 'steel', 3], ['res', -87, 33.5, 2, 'steel', 3], ['res', 113, 37, 3, 'steel', 3], ['res', 86, 23, 3, 'steel', 3], ['res', 28, -26, 3, 'steel', 3], ['res', -44, -20, 3, 'steel', 3], ['res', 151, -33, 2, 'steel', 3],
    ['res', 7, 51.3, 2, 'coal', 5], ['res', 18.5, 50.3, 2, 'coal', 5], ['res', 38, 48, 3, 'coal', 5], ['res', -2, 53, 2, 'coal', 5], ['res', -81, 37.5, 3, 'coal', 5], ['res', 113, 37, 3, 'coal', 4], ['res', 123, 42, 3, 'coal', 3],
    ['res', 86, 23, 3, 'coal', 3], ['res', 28, -26, 3, 'coal', 3], ['res', 151, -33, 2, 'coal', 3], ['res', 60, 56, 3, 'coal', 3], ['res', 135, 35, 2, 'coal', 2],
    ['res', 32, 49, 5, 'food', 5], ['res', -62, -34, 6, 'food', 5], ['res', -95, 41, 6, 'food', 5], ['res', -103, 51, 4, 'food', 4], ['res', 2, 47, 3, 'food', 4], ['res', 74, 31, 3, 'food', 4], ['res', 115, 35, 4, 'food', 4],
    ['res', 31, 27, 1.5, 'food', 5], ['res', 22, 45, 3, 'food', 4], ['res', 126, 45, 3, 'food', 3], ['res', 101, 15, 3, 'food', 4], ['res', 110, -7, 2, 'food', 4], ['res', 80, 22, 4, 'food', 3], ['res', 118, 30, 3, 'food', 4]
  ];

  /* ---------- sea zones (anchors; each sea cell joins the nearest anchor by flood-fill) ---------- */
  const SEAS = [
    ['Norwegian Sea', 2, 66], ['Barents Sea', 40, 71.5], ['North Sea', 3, 56], ['Baltic Sea', 19, 57.5], ['Gulf of Bothnia', 21, 63], ['Western Approaches', -8, 49], ['Bay of Biscay', -5, 45.5],
    ['North Atlantic', -30, 55], ['Central Atlantic', -35, 35], ['Mid-Atlantic', -25, 20], ['West African Coast', -20, 8], ['South Atlantic', -20, -15], ['Gulf of Cadiz', -10, 35],
    ['Western Mediterranean', 3, 39], ['Tyrrhenian Sea', 12, 39.5], ['Central Mediterranean', 17, 35], ['Adriatic Sea', 16, 42.5], ['Aegean Sea', 25, 38.5], ['Eastern Mediterranean', 31, 34],
    ['Black Sea', 34, 43.5], ['Red Sea', 38, 20], ['Gulf of Aden', 48, 12], ['Arabian Sea', 63, 15], ['Persian Gulf', 52, 27], ['Bay of Bengal', 88, 14], ['Malacca Sea', 98, 6], ['South China Sea', 113, 12],
    ['East China Sea', 124, 28], ['Yellow Sea', 121, 36], ['Sea of Japan', 135, 40], ['Philippine Sea', 135, 18], ['Sea of Okhotsk', 148, 55], ['North Pacific', 150, 45],
    ['Gulf of Alaska', -140, 55], ['Pacific Northwest', -128, 44], ['Baja Waters', -118, 25], ['Eastern Pacific', -118, 8], ['South Pacific', -100, -20], ['Southeast Pacific', -88, -35],
    ['Gulf of Mexico', -91, 25], ['Caribbean Sea', -75, 15], ['Western Atlantic', -60, 33], ['Labrador Sea', -55, 57], ['Hudson Bay', -86, 60], ['Newfoundland Banks', -50, 45], ['Sargasso Sea', -55, 25],
    ['Indian Ocean', 70, 0], ['Southern Indian Ocean', 70, -25], ['Mozambique Channel', 41, -18], ['Banda Sea', 125, -7], ['Timor Sea', 125, -14], ['Coral Sea', 152, -15], ['Tasman Sea', 155, -35],
    ['Bight of Guinea', 2, 2], ['Southeast Atlantic', 4, -25], ['Indian Ocean West', 55, -5], ['Java Sea', 110, -4], ['Great Australian Bight', 128, -37], ['West Australian Sea', 105, -22], ['Celebes Sea', 122, 4], ['Coastal Tasmania', 146, -41]
  ].map(a => ({ name: a[0], lon: a[1], lat: a[2] }));

  /* ---------- countries ---------- */
  const hsl = (h, s, l) => { s /= 100; l /= 100; const k = n => (n + h / 30) % 12, a = s * Math.min(l, 1 - l), f = n => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1))); const x = v => Math.round(255 * v).toString(16).padStart(2, '0'); return '#' + x(f(0)) + x(f(8)) + x(f(4)); };
  const PAT = ['h', 'v', 'x'];
  const city = s => s.split(';').map(c => { const a = c.split(','); return [a[0], +a[1], +a[2]]; });
  const seeds = s => s.split(';').map(c => c.split(',').map(Number));
  const RAW = [
    // id, name, adj, gov, pow, color(optional hue), seeds (lon,lat[,weight[,popMult]]), cities
    ['GBR', 'United Kingdom', 'British', 'Constitutional Monarchy', 5, '#c0505a', '-0.5,51.5,0,1.5;-2.5,53.5,0,1.4;-4,56.5,0,0.9;78,22,0,1.6;75,28,0,1.6;84,25,0,1.7;73,19,0,1.4;78,14,0,1.4;80.5,7.5;93,22,0,0.9;98,16;100,6;35.2,31.8;36.5,31.3;30,14,0,0.5;8,9,0,0.8;-1,6;37,0,0,0.5;33,-10,0,0.4;29,-18,0,0.4;151,-36,0,0.1;-5.4,36.1',
      'London,-0.1,51.5;Manchester,-2.2,53.5;Birmingham,-1.9,52.5;Edinburgh,-3.2,55.9;Glasgow,-4.3,55.9;Cardiff,-3.2,51.5;Delhi,77.2,28.6;Calcutta,88.4,22.6;Bombay,72.9,19;Madras,80.3,13;Lahore,74.3,31.5;Rangoon,96.2,16.8;Singapore,103.8,1.3;Jerusalem,35.2,31.8;Khartoum,32.5,15.6;Lagos,3.4,6.5;Nairobi,36.8,-1.3;Colombo,79.9,6.9;Hyderabad,78.5,17.4;Dhaka,90.4,23.8;Karachi,67,24.9;Allahabad,81.8,25.4;Nagpur,79.1,21.1;Lucknow,80.9,26.8;Kuala Lumpur,101.7,3.1;Accra,-0.2,5.6;Salisbury,31,-17.8;Amman,35.9,31.9;Gibraltar,-5.4,36.1'],
    ['FRA', 'France', 'French', 'Republic', 4, '#3a6fb5', '2.3,48.8;-1,47;4.5,45.5;1.5,44;5,49.8;3,36.5,0,0.8;0,33,0,0.5;6,30,0,0.3;-6,32,0,0.7;9.5,34;-5,14,0,0.4;3,16,0,0.3;-10,15;12,14,0,0.3;15,5,0,0.3;37,35,0,0.8;106,16,0,1.1;105,22,0,1.2;105,11,0,1.0;47,-19',
      'Paris,2.3,48.9;Lyon,4.8,45.8;Marseille,5.4,43.3;Bordeaux,-0.6,44.8;Lille,3.1,50.6;Nantes,-1.6,47.2;Strasbourg,7.8,48.6;Toulouse,1.4,43.6;Algiers,3,36.8;Oran,-0.6,35.7;Casablanca,-7.6,33.6;Tunis,10.2,36.8;Dakar,-17.4,14.7;Damascus,36.3,33.5;Saigon,106.7,10.8;Hanoi,105.8,21;Tananarive,47.5,-18.9;Constantine,6.6,36.4;Fez,-5,34;Bamako,-8,12.6;Niamey,2.1,13.5;Fort Lamy,15,12.1;Hue,107.6,16.5;Beirut,35.5,33.9;Aleppo,37.2,36.2;Brazzaville,15.3,-4.3;Tamanrasset,5.5,22.8;Agadir,-9.6,30.4'],
    ['GER', 'Germany', 'German', 'Fascist State', 5, '#6a6a6a', '13,52.5;9.5,53.7;11,48.5;7.5,51;13.5,50.8;10.5,50.5;21,54.5', 'Berlin,13.4,52.5;Hamburg,10,53.6;Munich,11.6,48.1;Cologne,7,50.9;Dresden,13.7,51;Frankfurt,8.7,50.1;Königsberg,20.5,54.7;Stuttgart,9.2,48.8;Hanover,9.7,52.4;Breslau,17,51.1'],
    ['ITA', 'Italy', 'Italian', 'Fascist State', 3, '#4e9a5a', '12.5,42;9,45.2;14.5,40.8;14,37.5;9,40;16.5,39;15,32,0,0.4;20,30,0,0.3;18,25,0,0.2;40,8,0,0.7;45,3,0,0.4;38,13;11,44',
      'Rome,12.5,41.9;Milan,9.2,45.5;Naples,14.3,40.9;Turin,7.7,45.1;Palermo,13.4,38.1;Cagliari,9.1,39.2;Florence,11.2,43.8;Bari,16.9,41.1;Tripoli,13.2,32.9;Benghazi,20.1,32.1;Addis Ababa,38.7,9;Asmara,38.9,15.3;Mogadishu,45.3,2;Venice,12.3,45.4;Sirte,16.6,31.2;Harar,42.1,9.3'],
    ['ESP', 'Spain', 'Spanish', 'Republic', 2, '#d0a232', '-3.7,40.4;-1,38.5;-6,37.5;-3,43;2,41.5;-6,39', 'Madrid,-3.7,40.4;Barcelona,2.2,41.4;Seville,-6,37.4;Valencia,-0.4,39.5;Bilbao,-2.9,43.3;Zaragoza,-0.9,41.7;Badajoz,-6.9,38.9'],
    ['POR', 'Portugal', 'Portuguese', 'Republic', 1, '#2f8f6f', '-8.3,40;-8,38;17,-12;15,-17;35,-16;34,-22', 'Lisbon,-9.1,38.7;Porto,-8.6,41.2;Luanda,13.2,-8.8;Lourenço Marques,32.6,-25.9;Beira,34.8,-19.8;Huambo,15.7,-12.8'],
    ['BEL', 'Belgium', 'Belgian', 'Constitutional Monarchy', 1, '#e0c24a', '4.5,50.8;23,-3,0,0.6;27,-9,0,0.5;20,3,0,0.4;28,2', 'Brussels,4.4,50.8;Leopoldville,15.3,-4.3;Elisabethville,27.5,-11.7;Stanleyville,25.2,0.5;Luluabourg,22.4,-5.9'],
    ['NED', 'Netherlands', 'Dutch', 'Constitutional Monarchy', 1, '#e07a2c', '5.2,52.2;101,-0.5,0,0.8;104,-3;110,-7.3,0,1.8;107,-6.5,0,1.8;114,-1,0,0.5;121,-2;139,-5,0,0.3;118,-8.2', 'Amsterdam,4.9,52.4;Batavia,106.8,-6.2;Medan,98.7,3.6;Surabaya,112.7,-7.2;Palembang,104.8,-3;Makassar,119.4,-5.1;Banjarmasin,114.6,-3.3;Hollandia,140.7,-2.5;Bandung,107.6,-6.9;Padang,100.4,-1'],
    ['POL', 'Poland', 'Polish', 'Republic', 2, '#c8506e', '21,52;19.5,50.3;23.5,50.5;18,52.5;17,51;22,54', 'Warsaw,21,52.2;Krakow,19.9,50;Lodz,19.5,51.8;Poznan,16.9,52.4;Lwow,24,49.8;Vilna,25.3,54.7;Gdynia,18.5,54.5;Katowice,19,50.3'],
    ['CZE', 'Czechoslovakia', 'Czechoslovak', 'Republic', 2, '#5aa0c8', '14.5,50;17,49;19,48.8', 'Prague,14.4,50.1;Brno,16.6,49.2;Bratislava,17.1,48.1;Pilsen,13.4,49.7'],
    ['AUT', 'Austria', 'Austrian', 'Republic', 1, '#b04040', '14,47.5', 'Vienna,16.4,48.2;Salzburg,13,47.8;Graz,15.4,47.1'],
    ['HUN', 'Hungary', 'Hungarian', 'Constitutional Monarchy', 1, '#8a6a3a', '19,47.2;21.5,47.5', 'Budapest,19,47.5;Debrecen,21.6,47.5;Szeged,20.1,46.2;Pecs,18.2,46.1'],
    ['ROM', 'Romania', 'Romanian', 'Constitutional Monarchy', 2, '#d4a73a', '25,45.5;24,47;27,46.5;22,45', 'Bucharest,26.1,44.4;Cluj,23.6,46.8;Iasi,27.6,47.2;Ploesti,26,44.9;Timisoara,21.2,45.8;Constanta,28.6,44.2'],
    ['YUG', 'Yugoslavia', 'Yugoslav', 'Constitutional Monarchy', 2, '#5a78b0', '20.5,44.5;16,45.5;21,42;19,42.5', 'Belgrade,20.5,44.8;Zagreb,16,45.8;Skopje,21.4,42;Sarajevo,18.4,43.9;Ljubljana,14.5,46.1;Split,16.4,43.5'],
    ['BUL', 'Bulgaria', 'Bulgarian', 'Constitutional Monarchy', 1, '#4e8f4e', '25,42.5;27,43.5', 'Sofia,23.3,42.7;Varna,27.9,43.2;Plovdiv,24.7,42.1'],
    ['GRE', 'Greece', 'Greek', 'Constitutional Monarchy', 1, '#4a8ad0', '22.5,38.5;22,40.7;24.5,35.3', 'Athens,23.7,37.98;Salonika,22.9,40.6;Larissa,22.4,39.6;Crete,24.9,35.3;Patras,21.7,38.2'],
    ['TUR', 'Turkey', 'Turkish', 'Republic', 2, '#c84a3a', '32.8,39.9;29,41;37,37.5;41,39;28,37.5;35,41;39,36.5,0,0.8', 'Ankara,32.9,39.9;Istanbul,29,41;Izmir,27.1,38.4;Adana,35.3,37;Erzurum,41.3,39.9;Samsun,36.3,41.3;Konya,32.5,37.9;Diyarbakir,40.2,37.9'],
    ['SWE', 'Sweden', 'Swedish', 'Constitutional Monarchy', 2, '#3a8ac0', '16,59.5;15,63;19,67;14,56.5', 'Stockholm,18.1,59.3;Gothenburg,12,57.7;Malmö,13,55.6;Kiruna,20.2,67.9;Sundsvall,17.3,62.4'],
    ['NOR', 'Norway', 'Norwegian', 'Constitutional Monarchy', 1, '#b83a4a', '10,60;8,63;15,67;22,70', 'Oslo,10.7,59.9;Bergen,5.3,60.4;Trondheim,10.4,63.4;Narvik,17.4,68.4;Tromsø,19,69.6'],
    ['FIN', 'Finland', 'Finnish', 'Republic', 1, '#e8e8f0', '25,61;27,64;27,68', 'Helsinki,24.9,60.2;Tampere,23.8,61.5;Viipuri,28.7,60.7;Oulu,25.5,65;Rovaniemi,25.7,66.5'],
    ['DEN', 'Denmark', 'Danish', 'Constitutional Monarchy', 1, '#c84a58', '10,56;12,55.5;-19,64.8;-42,72;-50,66', 'Copenhagen,12.6,55.7;Aarhus,10.2,56.2;Reykjavik,-21.9,64.1'],
    ['BAL', 'Baltic States', 'Baltic', 'Republic', 1, '#7a9a6a', '24,55;24.5,57;25,59', 'Kaunas,23.9,54.9;Riga,24.1,56.9;Tallinn,24.7,59.4;Libau,21,56.5'],
    ['SOV', 'Soviet Union', 'Soviet', 'Communist State', 5, '#b02a2a',
      '37.6,55.7;30,59.9;30.5,50.4;44,48;49.8,40.4;60,57;73,55;83,55;92,56;104,52;130,50;69,41;74,43;60,40;55,43;40,45;42,43;45,40;40,64.5;85,66,0,0.4;100,65,0,0.3;125,62,0,0.3;150,60,0,0.3;160,56,0,0.3;170,64,0,0.2;110,58;65,48;70,52;35,53;48,56;56,51;118,53;135,48;142,47;140,58;30,56;38,50;33,45',
      'Moscow,37.6,55.8;Leningrad,30.3,59.9;Kiev,30.5,50.4;Stalingrad,44.5,48.7;Baku,49.9,40.4;Sverdlovsk,60.6,56.8;Omsk,73.4,55;Novosibirsk,83,55;Krasnoyarsk,92.9,56;Irkutsk,104.3,52.3;Khabarovsk,135,48.5;Tashkent,69.2,41.3;Alma-Ata,76.9,43.2;Ashkhabad,58.4,37.9;Tbilisi,44.8,41.7;Yerevan,44.5,40.2;Archangel,40.5,64.5;Kharkov,36.2,50;Odessa,30.7,46.5;Minsk,27.6,53.9;Kuibyshev,50.1,53.2;Chelyabinsk,61.4,55.2;Magnitogorsk,59,53.4;Yakutsk,129.7,62;Vladivostok,131.9,43.1;Murmansk,33,68.9;Gorky,44,56.3;Rostov,39.7,47.2;Sevastopol,33.5,44.6;Dnepropetrovsk,35,48.5;Voronezh,39.2,51.7;Karaganda,73.1,49.8;Semipalatinsk,80.2,50.4;Chita,113.5,52;Magadan,150.8,59.6;Norilsk,88.2,69.3;Vorkuta,64,67.5;Petropavlovsk,69.1,54.9;Tomsk,84.9,56.5;Ulan-Ude,107.6,51.8;Sakhalin,142.7,50'],
    ['EGY', 'Egypt', 'Egyptian', 'Constitutional Monarchy', 2, '#d8b858', '31.2,30;32.5,25;28,28;33,29;30,22', 'Cairo,31.2,30;Alexandria,29.9,31.2;Aswan,32.9,24.1;Suez,32.5,30;Luxor,32.6,25.7'],
    ['SAU', 'Saudi Arabia', 'Saudi', 'Absolute Monarchy', 2, '#3a7a4a', '46.7,24.7;40,21.5;44,18;49,27;38,28;52,20;45,15;57,20,0,0.5', 'Riyadh,46.7,24.6;Mecca,39.8,21.4;Jeddah,39.2,21.5;Dhahran,50.1,26.3;Medina,39.6,24.5;Sanaa,44.2,15.4;Muscat,58.4,23.6;Aden,45,12.8'],
    ['IRQ', 'Iraq', 'Iraqi', 'Constitutional Monarchy', 1, '#6a8a3a', '44.4,33.3;43,36;47,31', 'Baghdad,44.4,33.3;Basra,47.8,30.5;Mosul,43.1,36.3;Kirkuk,44.4,35.5'],
    ['PER', 'Persia', 'Persian', 'Absolute Monarchy', 2, '#4a9a8a', '51.4,35.7;59,36.3;48,31;53,29.6;57,31;46,37.5;61,28,0,0.5', 'Tehran,51.4,35.7;Tabriz,46.3,38.1;Isfahan,51.7,32.7;Shiraz,52.5,29.6;Meshed,59.6,36.3;Ahvaz,48.7,31.3;Kerman,57.1,30.3;Zahedan,60.9,29.5'],
    ['AFG', 'Afghanistan', 'Afghan', 'Absolute Monarchy', 1, '#7a5a8a', '69,34.5;65,36;66,32', 'Kabul,69.2,34.5;Kandahar,65.7,31.6;Herat,62.2,34.3;Mazar,67.1,36.7'],
    ['CHN', 'China', 'Chinese', 'Republic', 3, '#d8a830',
      '118.8,32;121.5,31.2;114,30.5;106.5,29.5;104,30.7;113.3,23.1;116.4,39.9;112,37.9;109,34.3;103,36;101,26;107,26.5;120,29;118,25;87,43,0,0.3;89,31,0,0.2;96,36,0,0.3;102,40.5,0,0.3;116,36;112,33;110,28;105,34;108,38;114,26;118,36,0,1.2;122,41',
      'Nanking,118.8,32;Shanghai,121.5,31.2;Hankow,114.3,30.6;Chungking,106.5,29.6;Chengtu,104,30.7;Canton,113.3,23.1;Peking,116.4,39.9;Taiyuan,112.5,37.9;Sian,108.9,34.3;Lanchow,103.8,36;Kunming,102.7,25;Kweiyang,106.7,26.6;Hangchow,120.2,30.3;Foochow,119.3,26;Urumchi,87.6,43.8;Lhasa,91.1,29.7;Sining,101.8,36.6;Tsinan,117,36.7;Chengchow,113.6,34.7;Changsha,113,28.2;Sining2,102,40;Paoting,115.5,38.9;Tientsin,117.2,39.1;Tsingtao,120.4,36.1;Nanchang,115.9,28.7;Kaifeng,114.3,34.8;Yenan,109.5,36.6;Ningpo,121.5,29.9'],
    ['MNG', 'Mongolia', 'Mongolian', 'Communist State', 1, '#4a6aa8', '106.9,47.9;100,46;112,47;98,49', 'Ulan Bator,106.9,47.9;Kobdo,91.6,48;Choibalsan,114.5,48;Altai,96.3,46.4'],
    ['JPN', 'Japan', 'Japanese', 'Empire', 4, '#e8e0d0', '139.7,35.7;135.5,34.7;132,34;131,33;141,38.3;141.3,43;127,37.5,0,0.8;121,24;125.3,43.9,0,0.8;123.4,41.8,0,0.8;126.6,45.8,0,0.8;121,45,0,0.5',
      'Tokyo,139.7,35.7;Osaka,135.5,34.7;Nagoya,136.9,35.2;Hiroshima,132.5,34.4;Fukuoka,130.4,33.6;Sendai,141,38.3;Sapporo,141.3,43.1;Seoul,127,37.6;Pusan,129,35.1;Heijo,125.7,39;Taihoku,121.5,25;Hsinking,125.3,43.9;Mukden,123.4,41.8;Harbin,126.6,45.8;Jehol,118,41;Dairen,121.6,38.9;Kagoshima,130.5,31.6;Niigata,139,37.9'],
    ['SIA', 'Siam', 'Siamese', 'Constitutional Monarchy', 1, '#a05a8a', '100.5,13.8;100,17;102,15;99,10', 'Bangkok,100.5,13.8;Chiang Mai,98.9,18.8;Korat,102.1,14.9;Songkhla,100.6,7.2'],
    ['AUS', 'Australia', 'Australian', 'Constitutional Monarchy', 2, '#d0883a', '135,-25;145,-30;120,-28;130,-15;150,-25;143,-20;116,-32;151,-34,0,1.5;146,-37,0,1.3', 'Canberra,149.1,-35.3;Sydney,151.2,-33.9;Melbourne,145,-37.8;Brisbane,153,-27.5;Perth,115.9,-32;Adelaide,138.6,-34.9;Darwin,130.8,-12.5;Alice Springs,133.9,-23.7;Townsville,146.8,-19.3;Kalgoorlie,121.5,-30.7'],
    ['SAF', 'South Africa', 'South African', 'Constitutional Monarchy', 2, '#4a9a50', '25,-28;18,-30;28,-25;20,-22;31,-27;22,-33', 'Pretoria,28.2,-25.7;Cape Town,18.4,-33.9;Johannesburg,28,-26.2;Durban,31,-29.9;Windhoek,17.1,-22.6;Kimberley,24.8,-28.7;Bloemfontein,26.2,-29.1'],
    ['USA', 'United States', 'American', 'Republic', 5, '#3a5aa8',
      '-77,38.9,0,1.3;-74,40.7,0,1.5;-87.6,41.9,0,1.3;-95.4,29.8;-97,32.8;-105,39.7,0,0.7;-122.3,47.6;-118.2,34;-122.4,37.8;-84.4,33.7;-83,42.3,0,1.3;-93.3,45;-94.6,39;-90,30;-71,42.4,0,1.2;-111.9,40.8,0,0.6;-112,33.4,0,0.6;-149.9,61.2,0,0.1;-85,38;-80,35;-100,45;-100,35;-92,35;-76,42;-108,35;121,14.6,0,1.1;124,10,0,0.8;121,17,0,0.8;125,7,0,0.6',
      'Washington,-77,38.9;New York,-74,40.7;Chicago,-87.6,41.9;Houston,-95.4,29.8;Dallas,-97,32.8;Denver,-105,39.7;Seattle,-122.3,47.6;Los Angeles,-118.2,34;San Francisco,-122.4,37.8;Atlanta,-84.4,33.7;Detroit,-83,42.3;Minneapolis,-93.3,45;Kansas City,-94.6,39;New Orleans,-90,30;Boston,-71,42.4;Salt Lake City,-111.9,40.8;Phoenix,-112,33.4;Anchorage,-149.9,61.2;Louisville,-85.7,38.2;Charlotte,-80.8,35.2;Omaha,-96,41.3;Pittsburgh,-80,40.4;St. Louis,-90.2,38.6;Memphis,-90,35.1;Buffalo,-78.9,42.9;Albuquerque,-106.6,35.1;Dakota,-100,45;Oklahoma City,-97.5,35.5;Manila,121,14.6;Cebu,123.9,10.3;Davao,125.5,7.1;Baguio,120.6,16.4'],
    ['CAN', 'Canada', 'Canadian', 'Constitutional Monarchy', 3, '#c8403a', '-75.7,45.4;-79.4,43.7;-73.6,45.5;-97.1,49.9;-113.5,53.5;-123.1,49.3;-114.4,62.5;-100,58;-65,46;-70,52;-90,52;-120,58;-55,48;-105,52', 'Ottawa,-75.7,45.4;Toronto,-79.4,43.7;Montreal,-73.6,45.5;Winnipeg,-97.1,49.9;Edmonton,-113.5,53.5;Vancouver,-123.1,49.3;Yellowknife,-114.4,62.5;Churchill,-94.2,58.8;Halifax,-63.6,44.6;Quebec,-71.2,46.8;Regina,-104.6,50.4;St Johns,-52.7,47.6;Whitehorse,-135,60.7;Calgary,-114,51'],
    ['MEX', 'Mexico', 'Mexican', 'Republic', 2, '#3a8a5a', '-99.1,19.4;-103.3,20.7;-100.3,25.7;-106,28.6;-110,28;-89.6,20.9;-96,17;-92.9,17;-112,25;-115,30', 'Mexico City,-99.1,19.4;Guadalajara,-103.3,20.7;Monterrey,-100.3,25.7;Chihuahua,-106,28.6;Hermosillo,-110.9,29.1;Merida,-89.6,21;Oaxaca,-96.7,17.1;Tuxtla,-93.1,16.8;La Paz,-110.3,24.1;Tijuana,-117,32.5;Veracruz,-96.1,19.2'],
    ['CAM', 'Central America', 'Central American', 'Republic', 1, '#c0a060', '-88,14.5;-84,10.5;-80,8.9;-86,12.5', 'Guatemala,-90.5,14.6;San Salvador,-89.2,13.7;Managua,-86.3,12.1;San Jose,-84.1,9.9;Panama,-79.5,9;Tegucigalpa,-87.2,14.1'],
    ['CUB', 'Cuba', 'Cuban', 'Republic', 1, '#4aa0b0', '-82,22.8;-77,20.5;-72.5,19', 'Havana,-82.4,23.1;Santiago,-75.8,20;Camaguey,-77.9,21.4;Port-au-Prince,-72.3,18.5;Santo Domingo,-69.9,18.5'],
    ['VEN', 'Venezuela', 'Venezuelan', 'Military Junta', 1, '#d8c040', '-66.9,10.5;-63,8;-67,6', 'Caracas,-66.9,10.5;Maracaibo,-71.6,10.6;Ciudad Bolivar,-63.5,8.1;San Cristobal,-72.2,7.8'],
    ['COL', 'Colombia', 'Colombian', 'Republic', 1, '#b8a030', '-74,4.7;-75.5,6.2;-74.5,10;-76.5,3', 'Bogota,-74.1,4.7;Medellin,-75.6,6.2;Cartagena,-75.5,10.4;Cali,-76.5,3.4'],
    ['PRU', 'Peru', 'Peruvian', 'Military Junta', 1, '#a04a4a', '-77,-12;-75,-6;-71,-14;-66,-17;-79,-5;-79,-2', 'Lima,-77,-12;Cuzco,-72,-13.5;La Paz,-68.1,-16.5;Quito,-78.5,-0.2;Iquitos,-73.2,-3.7;Arequipa,-71.5,-16.4'],
    ['BRA', 'Brazil', 'Brazilian', 'Military Junta', 3, '#3a9a3a', '-47.9,-15.8;-43,-22.9;-46.6,-23.5;-38.5,-12.9;-60,-3;-52,-5;-55,-10;-51,-30;-35,-8;-48.5,-1.4;-65,-9;-58,-18;-44,-5;-53,-25', 'Rio de Janeiro,-43.2,-22.9;Sao Paulo,-46.6,-23.5;Brasilia,-47.9,-15.8;Salvador,-38.5,-13;Manaus,-60,-3.1;Belem,-48.5,-1.5;Recife,-34.9,-8;Porto Alegre,-51.2,-30;Fortaleza,-38.5,-3.7;Cuiaba,-56,-15.6;Curitiba,-49.3,-25.4;Goiania,-49.3,-16.7;Sao Luis,-44.3,-2.5;Porto Velho,-63.9,-8.8'],
    ['ARG', 'Argentina', 'Argentine', 'Republic', 2, '#7ab0d8', '-58.4,-34.6;-64,-31.4;-68.8,-32.9;-65,-38;-58,-27;-71,-33.5;-70,-23;-72,-38;-62,-24', 'Buenos Aires,-58.4,-34.6;Cordoba,-64.2,-31.4;Mendoza,-68.8,-32.9;Bahia Blanca,-62.3,-38.7;Asuncion,-57.6,-25.3;Santiago,-70.6,-33.4;Montevideo,-56.2,-34.9;Antofagasta,-70.4,-23.6;Tucuman,-65.2,-26.8;Rosario,-60.7,-32.9;Valdivia,-73.2,-39.8;Salta,-65.4,-24.8']
  ];

  const countries = {}, names = {};
  RAW.forEach((r, i) => {
    const hue = (i * 47) % 360;
    const pow = r[4];
    const col = r[5] || hsl(hue, 50, 48);
    const cities = city(r[7]);
    const oilTable = { USA: 90, SOV: 70, ROM: 45, PER: 40, VEN: 45, IRQ: 25, SAU: 25, NED: 30, GBR: 25, MEX: 25, JPN: 4 };
    countries[r[0]] = {
      id: r[0], name: r[1], adj: r[2], color: col,
      flag: [col, hsl((hue + 180) % 360, 35, 90), PAT[i % 3]],
      gov: r[3], pow: pow, seeds: seeds(r[6]),
      treasury: 300 + 190 * pow, manpower: 17000 + 12500 * pow,
      res: { steel: 15 + 24 * pow, coal: 20 + 20 * pow, oil: oilTable[r[0]] != null ? oilTable[r[0]] : 8 + 3 * pow, food: 60 + 22 * pow },
      cities: cities, cap: cities[0]
    };
  });
  // special manpower boosts for the giants
  countries.CHN.manpower = 85000; countries.SOV.manpower = 90000; countries.CHN.treasury = 700; countries.SOV.treasury = 1400;
  countries.USA.treasury = 1600; countries.GER.treasury = 1300; countries.GBR.treasury = 1500;

  G.SCENARIOS.world = {
    id: 'world', name: 'Old World 1936 — real map', blurb: '44 nations · real world map: Americas, Europe, Africa, Middle East, Asia · colonies and navies matter · 1 Jan 1936',
    type: 'poly', startYear: 1936, avgCell: 33,
    bounds: { lon0: -168, lon1: 180, lat0: -56, lat1: 76 }, kx: 9.1, proj: 'miller',
    land: G.NE_LAND, terr: TERR, seaAnchors: SEAS, countries: countries,
    straits: [
      { a: 'Baltic Sea', b: 'North Sea', name: 'Danish Straits', at: [11, 56] },
      { a: 'Black Sea', b: 'Aegean Sea', name: 'Turkish Straits', at: [28.5, 41] },
      { a: 'Eastern Mediterranean', b: 'Red Sea', name: 'Suez Canal', at: [32.5, 30.5] },
      { a: 'Western Mediterranean', b: 'Gulf of Cadiz', name: 'Strait of Gibraltar', at: [-5.5, 36] },
      { a: 'Caribbean Sea', b: 'Eastern Pacific', name: 'Panama Canal', at: [-79.8, 9] },
      { a: 'Adriatic Sea', b: 'Central Mediterranean', name: 'Strait of Otranto', at: [18.5, 40.2] },
      { a: 'Persian Gulf', b: 'Arabian Sea', name: 'Strait of Hormuz', at: [56.3, 26.3] },
      { a: 'Gulf of Bothnia', b: 'Baltic Sea', name: 'Åland Sea', at: [20, 60] }
    ],
    relations: [['GBR', 'FRA', 25], ['GBR', 'GER', -15], ['FRA', 'GER', -30], ['GER', 'POL', -35], ['GER', 'SOV', -35], ['SOV', 'POL', -25], ['SOV', 'JPN', -30], ['JPN', 'CHN', -50], ['JPN', 'USA', -15],
      ['ITA', 'GER', 20], ['ITA', 'GBR', -10], ['ITA', 'FRA', -15], ['ITA', 'YUG', -15], ['USA', 'GBR', 25], ['USA', 'FRA', 15], ['USA', 'CAN', 40], ['GBR', 'CAN', 40], ['GBR', 'AUS', 40], ['GBR', 'SAF', 30], ['GBR', 'EGY', 5],
      ['GER', 'CZE', -30], ['GER', 'AUT', -10], ['HUN', 'ROM', -30], ['HUN', 'CZE', -25], ['TUR', 'GRE', -15], ['BUL', 'ROM', -15], ['BUL', 'GRE', -15], ['ESP', 'POR', 5], ['FRA', 'CZE', 20], ['FRA', 'POL', 15], ['FIN', 'SOV', -30],
      ['CHN', 'SOV', -10], ['MNG', 'SOV', 40], ['MNG', 'JPN', -30], ['SAU', 'GBR', -5], ['IRQ', 'GBR', 10], ['PER', 'SOV', -10], ['AFG', 'GBR', -15], ['AFG', 'SOV', -5], ['BRA', 'ARG', -20], ['PRU', 'COL', -20], ['VEN', 'COL', -10], ['MEX', 'USA', -10]],
    // coastal strongpoint hint: ports start with level 1 for every coastal province (economy.js) — capitals get 2
    startNote: 'Real geography, simplified. Colonies are provinces of their mother country — protect the sea lanes.'
  };

  // Province naming for polygon scenarios.
  G.nameFromCities = function (c, lon, lat, used) {
    let best = null, bd = 1e9;
    for (const ct of c.cities) {
      if (used[ct[0]]) continue;
      const d = (ct[1] - lon) * (ct[1] - lon) * 0.6 + (ct[2] - lat) * (ct[2] - lat);
      if (d < bd) { bd = d; best = ct; }
    }
    if (best && bd < 160) { used[best[0]] = true; return best[0]; }
    return null;
  };
})(window.EMP = window.EMP || {});
