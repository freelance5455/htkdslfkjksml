'use strict';

const TTT = (() => {
  const WINS = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
  let board = Array(9).fill('');
  let turn = 'X';
  let over = false;
  let scores = { X: 0, O: 0 };
  let started = false;
  let cells = [];

  function build() {
    const wrap = document.getElementById('ttt-board');
    wrap.innerHTML = '';
    cells = [];
    for (let i = 0; i < 9; i++) {
      const c = document.createElement('button');
      c.className = 'ttt-cell';
      c.setAttribute('aria-label', 'cell ' + (i + 1));
      c.addEventListener('click', () => play(i));
      wrap.appendChild(c);
      cells.push(c);
    }
  }

  function ensureStarted() { if (!started) { started = true; build(); newRound(); } }

  function newRound() {
    board = Array(9).fill('');
    turn = 'X';
    over = false;
    cells.forEach(c => { c.textContent = ''; c.className = 'ttt-cell'; c.disabled = false; });
    updateUI();
  }

  function play(i) {
    if (over || board[i]) return;
    board[i] = turn;
    cells[i].textContent = turn;
    cells[i].classList.add(turn === 'X' ? 'x' : 'o');
    cells[i].disabled = true;

    const win = WINS.find(w => w.every(k => board[k] === turn));
    if (win) {
      over = true;
      scores[turn]++;
      win.forEach(k => cells[k].classList.add('win'));
      updateUI();
      setTimeout(() => {
        App.showModal(turn === 'X' ? '🔵' : '🔴', 'Player ' + (turn === 'X' ? '1' : '2') + ' wins!',
          'Score  ' + scores.X + ' – ' + scores.O, newRound);
      }, 260);
      return;
    }
    if (board.every(v => v)) {
      over = true;
      updateUI();
      setTimeout(() => App.showModal('🤝', "It's a draw", 'Score  ' + scores.X + ' – ' + scores.O, newRound), 260);
      return;
    }
    turn = turn === 'X' ? 'O' : 'X';
    updateUI();
  }

  function updateUI() {
    document.getElementById('ttt-p1-score').textContent = scores.X;
    document.getElementById('ttt-p2-score').textContent = scores.O;
    const t = document.getElementById('ttt-turn');
    if (over) { t.textContent = 'Round finished'; t.style.color = '#94a3b8'; }
    else {
      t.textContent = 'Player ' + (turn === 'X' ? '1' : '2') + "'s turn";
      t.style.color = turn === 'X' ? '#38bdf8' : '#fb7185';
    }
    document.getElementById('ttt-p1-card').style.boxShadow = (!over && turn === 'X') ? '0 0 0 2px #38bdf8' : '';
    document.getElementById('ttt-p2-card').style.boxShadow = (!over && turn === 'O') ? '0 0 0 2px #fb7185' : '';
  }

  function reset() { newRound(); }

  function statText() {
    if (!started) return '—';
    return 'P1 ' + scores.X + ' · P2 ' + scores.O;
  }

  return { ensureStarted, reset, statText };
})();