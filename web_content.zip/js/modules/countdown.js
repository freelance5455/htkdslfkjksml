/**
 * Motor de Contagem Regressiva e Sistema de Animação de Dígitos
 * Gerencia cálculos temporais, unidades, rollSlot (Web Animations API) e atualizações visuais de progresso.
 * Preserva integralmente o horário virtual OFF/NOW(), marcos (milestones), modos e unidades.
 * Totalmente compatível com Android WebView (file:// e http://).
 */
(function(root){
  var E = {};

  /**
   * Cálculo temporal do estado da contagem regressiva
   * @param {Object} it - Item de contagem atual { date, time, created, ... }
   * @param {number} now - Timestamp atual (obtido via NOW(), considerando o offset OFF)
   * @param {Object} prefs - Preferências ativas { secs, unit, mode, ... }
   * @param {Function} tgtFn - Função de conversão do item para objeto Date
   * @param {Function} padFn - Função utilitária de formatação com zero à esquerda
   * @returns {Object} Resultado do cálculo de exibição e progresso
   */
  E.compute = function(it, now, prefs, tgtFn, padFn){
    var r = { over: false, cls: "", b: "", sub: "", unit: "", pct: 0, d: 0, h: 0, m: 0, sec: 0, secs: -1 };
    if (!it) {
      r.cls = "t";
      r.b = "Olá";
      r.unit = "toque para criar sua contagem";
      r.pct = 1;
      return r;
    }

    var t = tgtFn(it).getTime();
    var diff = t - now;

    if (diff <= 0) {
      r.over = true;
      r.pct = 1;
      return r;
    }

    var s = Math.floor(diff / 1000);
    var S = prefs.secs;
    r.secs = s;
    r.d = Math.floor(s / 86400);
    r.h = Math.floor(s % 86400 / 3600);
    r.m = Math.floor(s % 3600 / 60);
    r.sec = s % 60;

    var U = prefs.unit || "d";
    if (U !== "d") {
      var HH = Math.floor(s / 3600);
      var MM = Math.floor(s / 60);
      if (U === "h") {
        r.b = (HH < 10 ? padFn(HH) : HH) + ":" + padFn(r.m) + (S ? ":" + padFn(r.sec) : "");
        r.unit = HH === 1 ? "hora" : "horas";
      } else if (U === "ms") {
        r.b = S ? MM + ":" + padFn(r.sec) : String(MM);
        r.unit = MM === 1 ? "minuto" : "minutos";
      } else {
        r.b = String(s);
        r.unit = s === 1 ? "segundo" : "segundos";
      }
      var L0 = r.b.length;
      r.cls = L0 <= 3 ? "" : L0 <= 5 ? "s" : L0 <= 8 ? "t" : L0 <= 11 ? "t2" : "t3";
      r.sub = "";
    } else if (r.d >= 1) {
      r.b = String(r.d);
      r.unit = r.d === 1 ? "dia" : "dias";
      r.sub = padFn(r.h) + ":" + padFn(r.m) + (S ? ":" + padFn(r.sec) : "");
      if (r.b.length > 3) r.cls = "s";
    } else if (r.h >= 1) {
      r.cls = "t";
      r.b = padFn(r.h) + ":" + padFn(r.m) + (S ? ":" + padFn(r.sec) : "");
      r.unit = "horas";
    } else if (S) {
      r.cls = "t";
      r.b = padFn(r.m) + ":" + padFn(r.sec);
      r.unit = "minutos";
    } else {
      r.b = String(r.m);
      r.unit = r.m === 1 ? "minuto" : "minutos";
    }

    if (prefs.mode === "compact") r.sub = "";
    var c = it.created || now;
    r.pct = Math.min(1, Math.max(0, (now - c) / ((t - c) || 1)));
    return r;
  };

  /**
   * Animação de rolagem de dígito individual (slot machine) via Web Animations API
   */
  E.rollSlot = function(slot, ch, isAnim, isReduce){
    var n = document.createElement("span");
    n.className = "g";
    n.textContent = ch;
    var olds = slot.querySelectorAll(".g");
    if (!isAnim || isReduce || !olds.length) {
      slot.textContent = "";
      slot.appendChild(n);
      return;
    }
    for (var i = 0; i < olds.length - 1; i++) slot.removeChild(olds[i]);
    var old = olds[olds.length - 1];
    n.style.position = "absolute";
    n.style.left = "0";
    n.style.top = ".12em";
    slot.appendChild(n);
    var o = { duration: 700, easing: "cubic-bezier(.22,1,.36,1)", fill: "both" };
    old.animate([{ transform: "translateY(0)", opacity: 1 }, { transform: "translateY(-100%)", opacity: 0 }], o);
    n.animate([{ transform: "translateY(100%)", opacity: 0 }, { transform: "translateY(0)", opacity: 1 }], o).onfinish = function(){
      if (old.parentNode) old.parentNode.removeChild(old);
      n.style.position = "";
      n.style.left = "";
      n.style.top = "";
    };
  };

  /**
   * Atualização de múltiplos dígitos roláveis em um elemento container
   */
  E.roll = function(el, text, isAnim, isReduce){
    var kids = el.children;
    while (kids.length > text.length) el.removeChild(el.firstChild);
    while (kids.length < text.length) {
      var s = document.createElement("span");
      s.className = "slot";
      el.insertBefore(s, el.firstChild);
    }
    for (var i = 0; i < text.length; i++) {
      var ch = text.charAt(i);
      if (kids[i].getAttribute("data-c") === ch) continue;
      kids[i].setAttribute("data-c", ch);
      E.rollSlot(kids[i], ch, isAnim, isReduce);
    }
  };

  /**
   * Atualização dos 4 estilos de indicadores de progresso:
   * Linha com transform scaleX, Anel circular SVG com strokeDashoffset, Barras discretas e Pontos.
   */
  E.setProg = function(pct, els, state){
    var rem = 1 - pct;
    if (els.bar) els.bar.style.transform = "scaleX(" + rem.toFixed(4) + ")";
    if (els.pc) els.pc.style.strokeDashoffset = (157.08 * pct).toFixed(2);
    var nb = Math.ceil(rem * 24 - 1e-6);
    var nd = Math.ceil(rem * 16 - 1e-6);
    var i, k;
    if (els.pbars && nb !== state.lastBars) {
      state.lastBars = nb;
      k = els.pbars.children;
      for (i = 0; i < k.length; i++) k[i].classList.toggle("on", i < nb);
    }
    if (els.pdots && nd !== state.lastDots) {
      state.lastDots = nd;
      k = els.pdots.children;
      for (i = 0; i < k.length; i++) k[i].classList.toggle("on", i < nd);
    }
  };

  root.AppCountdown = E;
})(typeof window !== "undefined" ? window : this);
