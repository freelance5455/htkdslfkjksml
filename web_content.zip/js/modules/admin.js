/* ==========================================================================
   Contagem Regressiva — Módulo de Administração (AppAdmin)
   Fase 5: Autenticação por PIN, Rate Limiting, Time Warp, Backup e Auditoria
   Compatível com scripts tradicionais e Android WebView (file://)
   ========================================================================== */

(function(root) {
  'use strict';

  var ADM = {};

  var U = (root && root.AppUtils) || (typeof window !== 'undefined' ? window.AppUtils : null) || {};

  /**
   * Formata deslocamento temporal do Time Warp (em ms) para texto legível.
   * Exemplo: +1d 2h, −30s, +0
   * @param {number} ms - Deslocamento em milissegundos
   * @returns {string} String formatada
   */
  ADM.fmtOff = function(ms) {
    var s = ms < 0 ? "−" : "+",
        a = Math.abs(ms),
        d = Math.floor(a / 864e5),
        h = Math.floor(a % 864e5 / 36e5),
        m = Math.floor(a % 36e5 / 6e4),
        sec = Math.floor(a % 6e4 / 1e3),
        p = [];
    if (d) p.push(d + "d");
    if (h) p.push(h + "h");
    if (m) p.push(m + "min");
    if (sec && !d) p.push(sec + "s");
    return s + (p.join(" ") || "0");
  };

  /**
   * Verifica se o PIN informado confere com o hash salvo.
   * @param {string} pin - PIN em texto plano
   * @param {string} storedHash - Hash armazenado
   * @returns {boolean}
   */
  ADM.verifyPin = function(pin, storedHash) {
    if (!storedHash) return true;
    var hashFn = (U && U.hash) || (root && root.AppUtils && root.AppUtils.hash) || (typeof window !== 'undefined' && typeof window.hash === 'function' ? window.hash : null);
    if (!hashFn) return false;
    return hashFn(pin) === storedHash;
  };

  /**
   * Calcula o tempo de espera (lockout) em segundos após falhas consecutivas de PIN.
   * A partir de 3 falhas: espera progressiva 30s, 60s, 120s... até máx 900s (15 min).
   * @param {number} fails - Número de falhas
   * @returns {number} Tempo de espera em segundos
   */
  ADM.calcLockout = function(fails) {
    var f = fails || 0;
    return f >= 3 ? Math.min(900, 30 * Math.pow(2, f - 3)) : 0;
  };

  /**
   * Analisa, valida e sanitiza o arquivo de backup importado em JSON.
   * @param {string} txt - Texto JSON do backup
   * @returns {Object} { ok: boolean, data?: Object, prefs?: Object, profile?: Object, admin?: Object, media?: Object, error?: string }
   */
  ADM.parseBackup = function(txt) {
    var o;
    try {
      o = JSON.parse(txt);
    } catch (e) {
      return { ok: false, error: "invalid_json" };
    }

    if (!o || typeof o !== "object" || !o.data || !Array.isArray(o.data.items)) {
      return { ok: false, error: "invalid_schema" };
    }

    var uidFn = (U && U.uid) || (root && root.AppUtils && root.AppUtils.uid) || function() {
      return Math.random().toString(36).slice(2, 10);
    };

    var items = o.data.items.filter(function(i) {
      return i && /^\d{4}-\d{2}-\d{2}$/.test(i.date) && /^\d{2}:\d{2}$/.test(i.time);
    }).slice(0, 60).map(function(i) {
      return {
        id: String(i.id || uidFn()).slice(0, 24),
        name: String(i.name || "").slice(0, 40),
        date: i.date,
        time: i.time,
        created: +i.created || Date.now(),
        phrase: String(i.phrase || "").slice(0, 60)
      };
    });

    var nd = {
      items: items,
      active: items.length ? items[0].id : null
    };

    if (o.data.active && items.some(function(i) { return i.id === o.data.active; })) {
      nd.active = o.data.active;
    }

    var okImgFn = (U && U.okImg) || (root && root.AppUtils && root.AppUtils.okImg) || function(u) {
      return typeof u === "string" && (u.startsWith("data:image/") || u.startsWith("blob:") || /^(https?:\/\/|\/)/.test(u));
    };

    var pr = null;
    if (o.profile && typeof o.profile === "object") {
      pr = Object.assign({}, o.profile);
      if (!okImgFn(pr.avatar)) pr.avatar = "";
      if (!okImgFn(pr.banner)) pr.banner = "";
    }

    var ad = null;
    if (o.admin && typeof o.admin === "object") {
      ad = Object.assign({}, o.admin);
    }

    var prefs = null;
    if (o.prefs && typeof o.prefs === "object") {
      prefs = Object.assign({}, o.prefs);
    }

    var media = null;
    if (o.media && typeof o.media === "object") {
      media = Object.assign({}, o.media);
    }

    return {
      ok: true,
      data: nd,
      prefs: prefs,
      profile: pr,
      admin: ad,
      media: media
    };
  };

  /**
   * Constrói a carga padrão do backup para exportação (v6).
   * Oculta o PIN e esvazia o log de auditoria por segurança.
   * @param {Object} data - Dados de contagens
   * @param {Object} prefs - Preferências gerais
   * @param {Object} profile - Dados do perfil
   * @param {Object} admin - Configurações administrativas
   * @param {Object} mediaBlobsMap - Mapa de mídias em DataURL
   * @returns {Object}
   */
  ADM.buildBackup = function(data, prefs, profile, admin, mediaBlobsMap) {
    var admClean = Object.assign({}, admin || {}, { pin: "", log: [] });
    return {
      v: 6,
      data: data,
      prefs: prefs,
      profile: profile,
      media: mediaBlobsMap || {},
      admin: admClean
    };
  };

  /**
   * Operações sobre a lista de contagens no painel admin:
   * op: -1 (subir), 1 (descer), 0 (duplicar), 9 (apagar)
   * @param {Array} items - Array de contagens
   * @param {number} ix - Índice do item
   * @param {number} op - Código da operação
   * @param {number} maxLimit - Limite máximo de contagens permitido
   * @returns {Object} { items: Array, changed: boolean, error?: string, added?: Object, deleted?: Object }
   */
  ADM.itemOp = function(items, ix, op, maxLimit) {
    var a = (items || []).slice();
    var it = a[ix];
    if (!it) return { items: a, changed: false };

    if (op === -1 && ix > 0) {
      a.splice(ix, 1);
      a.splice(ix - 1, 0, it);
      return { items: a, changed: true };
    } else if (op === 1 && ix < a.length - 1) {
      a.splice(ix, 1);
      a.splice(ix + 1, 0, it);
      return { items: a, changed: true };
    } else if (op === 0) {
      var max = maxLimit || 30;
      if (a.length >= max) {
        return { items: a, changed: false, error: "limit" };
      }
      var uidFn = (U && U.uid) || (root && root.AppUtils && root.AppUtils.uid) || function() {
        return Math.random().toString(36).slice(2, 10);
      };
      var clone = Object.assign({}, it, {
        id: uidFn(),
        created: Date.now(),
        name: (it.name || "Contagem") + " (cópia)"
      });
      a.splice(ix + 1, 0, clone);
      return { items: a, changed: true, added: clone };
    } else if (op === 9) {
      a.splice(ix, 1);
      return { items: a, changed: true, deleted: it };
    }

    return { items: a, changed: false };
  };

  /**
   * Cria entrada para o log de auditoria administrativa.
   * @param {string} msg - Mensagem de registro
   * @returns {Object} { t: number, m: string }
   */
  ADM.createLogEntry = function(msg) {
    return {
      t: Date.now(),
      m: String(msg || "")
    };
  };

  root.AppAdmin = ADM;
})(typeof window !== "undefined" ? window : this);
