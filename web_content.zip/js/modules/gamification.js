/**
 * Sistema de Gamificação: Conquistas (Badges), Níveis, XP e Streaks
 * Preserva integralmente o catálogo de 20 insígnias, fórmulas de XP, contagem de dias e progresso.
 * Compatível com scripts tradicionais e Android WebView.
 */
(function(root){
  var G = {};

  /**
   * Catálogo canônico das 20 conquistas
   */
  G.BD = [
    {id:"pio",i:"hourglass_top",c:["#7c5cff","#3b82f6"],n:"Pioneiro",d:"Criar a primeira contagem",p:function(ctx){return[ctx.data.items.length,1]}},
    {id:"pla",i:"calendar_month",c:["#22c1c3","#6d5dfc"],n:"Planejador",d:"Ter 3 contagens",p:function(ctx){return[ctx.data.items.length,3]}},
    {id:"col",i:"collections_bookmark",c:["#e879f9","#8b5cf6"],n:"Colecionador",d:"Ter 8 contagens",p:function(ctx){return[ctx.data.items.length,8]}},
    {id:"pon",i:"task_alt",c:["#43c59e","#2a6f97"],n:"Pontual",d:"Ter uma contagem concluída",p:function(ctx){return[ctx.nDone(),1]}},
    {id:"foto",i:"photo_camera",c:["#ff7a59","#ff3d81"],n:"Retratista",d:"Adicionar uma foto de perfil",p:function(ctx){return[ctx.PRO.avatarM?1:0,1]}},
    {id:"art",i:"palette",c:["#f5a623","#ed4245"],n:"Artista",d:"Personalizar 3 itens do visual",p:function(ctx){return[ctx.nPers(),3]}},
    {id:"mid",i:"movie",c:["#3b82f6","#22c1c3"],n:"Multimídia",d:"Usar um GIF ou vídeo no perfil",p:function(ctx){return[ctx.hasMov()?1:0,1]}},
    {id:"lin",i:"link",c:["#43c59e","#22c1c3"],n:"Conectado",d:"Adicionar um link ao perfil",p:function(ctx){return[(ctx.PRO.links||[]).filter(function(l){return ctx.normUrl(l.u)}).length,1]}},
    {id:"con",i:"local_fire_department",c:["#f5a623","#ff7a59"],n:"Constante",d:"Sequência de 3 dias seguidos",p:function(ctx){return[ctx.streak(),3]}},
    {id:"mar",i:"bolt",c:["#fde68a","#f59e0b"],n:"Maratonista",d:"Sequência de 7 dias seguidos",p:function(ctx){return[ctx.streak(),7]}},
    {id:"vet",i:"military_tech",c:["#a3a3a3","#525252"],n:"Veterano",d:"Completar 30 dias de perfil",p:function(ctx){return[Math.floor((Date.now()-ctx.PRO.joined)/864e5),30]}},
    {id:"tes",i:"science",c:["#8b5cf6","#3b82f6"],n:"Testador",d:"Usar a viagem no tempo",p:function(ctx){return[ctx.PRO.warped?1:0,1]}},
    {id:"soc",i:"ios_share",c:["#ff3d81","#8b5cf6"],n:"Compartilhador",d:"Compartilhar o cartão de perfil",p:function(ctx){return[ctx.PRO.shares,1]}},
    {id:"adm",i:"admin_panel_settings",c:["#ed4245","#7c5cff"],n:"Administrador",d:"Abrir o painel de administrador",p:function(ctx){return[ctx.PRO.wasAdmin?1:0,1]}},
    {id:"hon",i:"workspace_premium",c:["#fde68a","#b8892f"],n:"Honorário",d:"Concedida por um administrador",p:function(){return[0,1]}},
    {id:"owl",s:1,i:"bedtime",c:["#3b3b8f","#7c5cff"],n:"Coruja",d:"Abrir o app de madrugada",p:function(ctx){return[ctx.PRO.flags.owl?1:0,1]}},
    {id:"live",s:1,i:"alarm_on",c:["#ed4245","#f5a623"],n:"Na hora H",d:"Ver uma contagem chegar ao vivo",p:function(ctx){return[ctx.PRO.flags.live?1:0,1]}},
    {id:"exp",s:1,i:"explore",c:["#22c1c3","#3b82f6"],n:"Explorador",d:"Visitar todas as áreas do app",p:function(ctx){var n=0;["settings","edit","admin","share","focus"].forEach(function(k){if(ctx.PRO.flags["v_"+k])n++});return[n,5]}},
    {id:"fie",s:1,i:"favorite",c:["#ff3d81","#f5a623"],n:"Fiel",d:"Usar o app em 30 dias diferentes",p:function(ctx){return[Object.keys(ctx.PRO.days).length,30]}},
    {id:"det",s:1,i:"manage_search",c:["#a3a3a3","#7c5cff"],n:"Detetive",d:"Encontrar a entrada escondida do admin",p:function(ctx){return[ctx.PRO.flags.det?1:0,1]}}
  ];

  /**
   * Cálculo de sequência (streak) em dias consecutivos
   */
  G.calcStreak = function(pro, dstrFn){
    if(pro.stkSet != null) return pro.stkSet;
    var n = 0, d = new Date();
    while(pro.days && pro.days[dstrFn(d.getTime())]){
      n++;
      d.setDate(d.getDate() - 1);
    }
    return n;
  };

  /**
   * Verificação de conquistas naturais (conquistadas por mérito)
   */
  G.isNat = function(b, ctx){
    var p = b.p(ctx);
    return p[0] >= p[1];
  };

  /**
   * Verificação se a conquista foi ganha (mérito ou concessão admin)
   */
  G.isEarned = function(b, ctx){
    if(ctx.ADM.grant && ctx.ADM.grant.indexOf(b.id) > -1) return true;
    return G.isNat(b, ctx);
  };

  /**
   * Lista de IDs de conquistas obtidas
   */
  G.earnedIds = function(ctx){
    return G.BD.filter(function(b){ return G.isEarned(b, ctx); }).map(function(b){ return b.id; });
  };

  /**
   * Lista de IDs de conquistas conquistadas naturalmente
   */
  G.natIds = function(ctx){
    return G.BD.filter(function(b){ return G.isNat(b, ctx); }).map(function(b){ return b.id; });
  };

  /**
   * Informações completas de XP e Nível
   */
  G.xpInfo = function(pro, data, natIdsList, nDoneVal){
    var xp = pro.xpSet != null ? pro.xpSet :
      natIdsList.length * 40 +
      Object.keys(pro.days || {}).length * 6 +
      data.items.length * 8 +
      nDoneVal * 15 +
      (pro.shares || 0) * 5;
    var L = 1 + Math.floor(Math.sqrt(xp / 30));
    var lo = 30 * (L - 1) * (L - 1);
    var hi = 30 * L * L;
    return {
      xp: xp,
      L: L,
      hi: hi,
      p: (xp - lo) / (hi - lo || 1)
    };
  };

  root.AppGamification = G;
})(typeof window !== "undefined" ? window : this);
