/* ==========================================================================
   Contagem Regressiva — Módulo de Exportação (AppExport)
   Fase 5: Estúdio de Exportação, Renderização em Canvas (Story, Square, Wide),
           Composição Visual, Temas Adaptativos e Pontes de Compartilhamento
   Compatível com scripts tradicionais e Android WebView (file://)
   ========================================================================== */

(function(root) {
  'use strict';

  var EX = {};

  var U = (root && root.AppUtils) || (typeof window !== 'undefined' ? window.AppUtils : null) || {};
  var M = (root && root.AppMedia) || (typeof window !== 'undefined' ? window.AppMedia : null) || {};
  var C = (root && root.AppCountdown) || (typeof window !== 'undefined' ? window.AppCountdown : null) || {};
  var G = (root && root.AppGamification) || (typeof window !== 'undefined' ? window.AppGamification : null) || {};

  /** Formatos suportados no estúdio de exportação [largura, altura] */
  EX.FMT = {
    story: [1080, 1920],
    square: [1080, 1080],
    wide: [1920, 1080]
  };

  /** Modos de mesclagem padrão suportados no canvas */
  EX.BLEND_MODES = [
    "normal", "multiply", "screen", "overlay", "soft-light",
    "hard-light", "color-dodge", "color-burn", "difference",
    "exclusion", "hue", "luminosity"
  ];

  /* ----- Cores adaptativas e contraste ----- */

  EX.toHsl = function(h) {
    var n = parseInt(h.slice(1), 16),
        r = (n >> 16) / 255,
        g = (n >> 8 & 255) / 255,
        b = (n & 255) / 255,
        mx = Math.max(r, g, b),
        mn = Math.min(r, g, b),
        l = (mx + mn) / 2,
        d = mx - mn,
        s = d ? d / (1 - Math.abs(2 * l - 1)) : 0,
        hh = 0;
    if (d) {
      if (mx === r) hh = ((g - b) / d) % 6;
      else if (mx === g) hh = (b - r) / d + 2;
      else hh = (r - g) / d + 4;
      hh *= 60;
      if (hh < 0) hh += 360;
    }
    return [hh, s, l];
  };

  EX.fromHsl = function(h, s, l) {
    var c = (1 - Math.abs(2 * l - 1)) * s,
        x = c * (1 - Math.abs(h / 60 % 2 - 1)),
        m = l - c / 2,
        r = 0, g = 0, b = 0;
    if (h < 60) { r = c; g = x; }
    else if (h < 120) { r = x; g = c; }
    else if (h < 180) { g = c; b = x; }
    else if (h < 240) { g = x; b = c; }
    else if (h < 300) { r = x; b = c; }
    else { r = c; b = x; }
    return "#" + ((1 << 24) + (Math.round((r + m) * 255) << 16) + (Math.round((g + m) * 255) << 8) + Math.round((b + m) * 255)).toString(16).slice(1);
  };

  EX.lum = function(h) {
    var n = parseInt(h.slice(1), 16),
        a = [n >> 16, n >> 8 & 255, n & 255].map(function(v) {
          v /= 255;
          return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
        });
    return 0.2126 * a[0] + 0.7152 * a[1] + 0.0722 * a[2];
  };

  EX.contrast = function(a, b) {
    var x = EX.lum(a), y = EX.lum(b);
    return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05);
  };

  EX.inkOf = function(hex, dk) {
    var mixHexFn = (U && U.mixHex) || (root && root.AppUtils && root.AppUtils.mixHex) || function(a, b, w) { return a; };
    var c = EX.toHsl(hex),
        bg = mixHexFn(dk ? "#131313" : "#f3f3f3", hex, 0.14),
        s = Math.min(0.65, Math.max(0.32, c[1])),
        l = dk ? 0.8 : 0.3,
        k = EX.fromHsl(c[0], s, l),
        n = 0;
    while (EX.contrast(k, bg) < 5 && n++ < 14) {
      l = Math.min(0.97, Math.max(0.05, l + (dk ? 0.025 : -0.025)));
      k = EX.fromHsl(c[0], s, l);
    }
    return k;
  };

  EX.exTheme = function(o, isDarkFn) {
    var checkDark = (typeof isDarkFn === "function") ? isDarkFn : function() {
      if (typeof window !== "undefined" && window.isDark) return window.isDark();
      if (typeof document !== "undefined") return document.documentElement.getAttribute("data-theme") !== "light";
      return true;
    };
    var dk = o.theme === "auto" ? checkDark() : o.theme === "dark";
    return {
      dk: dk,
      base: dk ? "#131313" : "#f3f3f3",
      bg0: dk ? "#000000" : "#ffffff",
      bg2: dk ? "#171717" : "#f0f0f0",
      tx: dk ? "#f5f5f5" : "#0a0a0a",
      mu: dk ? "rgba(245,245,245,.64)" : "rgba(10,10,10,.6)",
      ln: dk ? "rgba(245,245,245,.14)" : "rgba(10,10,10,.12)"
    };
  };

  /* ----- Primitivas de renderização Canvas ----- */

  EX.exReset = function(x) {
    x.setTransform(1, 0, 0, 1, 0, 0);
    x.globalAlpha = 1;
    x.globalCompositeOperation = "source-over";
    try { x.filter = "none"; } catch (e) {}
    x.shadowBlur = 0;
    x.shadowColor = "transparent";
    x.textAlign = "left";
    x.textBaseline = "alphabetic";
    try { x.letterSpacing = "0px"; } catch (e) {}
    x.clearRect(0, 0, x.canvas.width, x.canvas.height);
  };

  EX.rrect = function(x, a, b, w, h, r) {
    x.beginPath();
    if (x.roundRect) x.roundRect(a, b, w, h, r);
    else x.rect(a, b, w, h);
  };

  EX.star = function(x, px, py, r) {
    x.beginPath();
    x.moveTo(px, py - r);
    x.quadraticCurveTo(px, py, px + r, py);
    x.quadraticCurveTo(px, py, px, py + r);
    x.quadraticCurveTo(px, py, px - r, py);
    x.quadraticCurveTo(px, py, px, py - r);
    x.fill();
  };

  EX.seeded = function(n) {
    var s = n >>> 0 || 1;
    return function() {
      s = (s * 1664525 + 1013904223) >>> 0;
      return s / 4294967296;
    };
  };

  EX.fxStatic = function(x, W, H, P, sc, T) {
    var k = P.effect,
        i, px, py, s,
        R = EX.seeded(7),
        counts = { sparkles: 26, stars: 60, embers: 44, snow: 70, petals: 30, rain: 90 },
        n = Math.round((counts[k] || 0) * (P.fxInt || 0) / 70);

    if (k === "none") return;
    var rgbaFn = (U && U.rgba) || (root && root.AppUtils && root.AppUtils.rgba) || function(c, a) { return c; };

    if (k === "aurora") {
      for (i = 0; i < 3; i++) {
        var gx = W * (0.15 + 0.35 * i),
            g = x.createRadialGradient(gx, H * 0.1, 0, gx, H * 0.1, W * 0.7);
        g.addColorStop(0, rgbaFn(i === 1 ? P.pb : P.pa, Math.min(0.9, 0.5 * (P.fxInt || 0) / 70)));
        g.addColorStop(1, "rgba(0,0,0,0)");
        x.fillStyle = g;
        x.fillRect(0, 0, W, H * 0.7);
      }
      return;
    }

    for (i = 0; i < n; i++) {
      px = R() * W;
      py = R() * H;
      s = 0.5 + R();
      if (k === "sparkles") {
        x.globalAlpha = 0.5 + R() * 0.5;
        x.fillStyle = T.dk ? "#fff" : P.pa;
        EX.star(x, px, py, (2 + 6 * s) * sc);
      } else if (k === "stars") {
        x.globalAlpha = 0.3 + R() * 0.6;
        x.fillStyle = T.dk ? "#fff" : P.pa;
        x.beginPath();
        x.arc(px, py, (0.8 * s + 0.4) * sc, 0, 6.283);
        x.fill();
      } else if (k === "embers") {
        x.globalAlpha = 0.4 + R() * 0.5;
        x.fillStyle = "#ffb347";
        x.beginPath();
        x.arc(px, py, (1.2 + s) * sc, 0, 6.283);
        x.fill();
      } else if (k === "snow") {
        x.globalAlpha = 0.7;
        x.fillStyle = T.dk ? "#fff" : "#9bb8ff";
        x.beginPath();
        x.arc(px, py, (1 + s * 1.4) * sc, 0, 6.283);
        x.fill();
      } else if (k === "petals") {
        x.globalAlpha = 0.8;
        x.fillStyle = "#ffb7d5";
        x.save();
        x.translate(px, py);
        x.rotate(R() * 6.28);
        x.beginPath();
        x.ellipse(0, 0, (3 + s * 2) * sc, (1.6 + s) * sc, 0, 0, 6.283);
        x.fill();
        x.restore();
      } else if (k === "rain") {
        x.globalAlpha = 0.35;
        x.strokeStyle = T.dk ? "#bcd0ff" : "#5b7bd6";
        x.lineWidth = sc;
        x.beginPath();
        x.moveTo(px, py);
        x.lineTo(px - 2 * sc, py + 11 * sc);
        x.stroke();
      }
    }
    x.globalAlpha = 1;
  };

  EX.drawRing = function(x, ax, ay, ar, P, card, sc) {
    var k = P.ring, g;
    if (k === "none") return;
    if (k === "gradient" || k === "orbit") {
      g = x.createLinearGradient(ax - ar, ay - ar, ax + ar, ay + ar);
      g.addColorStop(0, P.pa);
      g.addColorStop(1, P.pb);
      x.fillStyle = g;
      x.beginPath();
      x.arc(ax, ay, ar + 10 * sc, 0, 6.283);
      x.fill();
      x.fillStyle = card;
      x.beginPath();
      x.arc(ax, ay, ar + 4 * sc, 0, 6.283);
      x.fill();
      return;
    }
    if (k === "glow") {
      x.save();
      x.shadowColor = P.pa;
      x.shadowBlur = 30 * sc;
      x.fillStyle = card;
      x.beginPath();
      x.arc(ax, ay, ar + 5 * sc, 0, 6.283);
      x.fill();
      x.restore();
    }
    if (k === "double") {
      x.fillStyle = card;
      x.beginPath();
      x.arc(ax, ay, ar + 14 * sc, 0, 6.283);
      x.fill();
      x.strokeStyle = P.pa;
      x.lineWidth = 3 * sc;
      x.beginPath();
      x.arc(ax, ay, ar + 8 * sc, 0, 6.283);
      x.stroke();
      return;
    }
    x.fillStyle = card;
    x.beginPath();
    x.arc(ax, ay, ar + (k === "glow" ? 5 : 6) * sc, 0, 6.283);
    x.fill();
  };

  EX.drawDot = function(x, px, py, r, s, card, sc) {
    var col = { online: "#3ba55c", idle: "#f5a623", dnd: "#ed4245", off: "#80848e" }[s] || "#3ba55c";
    x.fillStyle = card;
    x.beginPath();
    x.arc(px, py, r + 4 * sc, 0, 6.283);
    x.fill();
    x.fillStyle = col;
    x.beginPath();
    x.arc(px, py, r, 0, 6.283);
    x.fill();
    x.fillStyle = card;
    if (s === "dnd") {
      EX.rrect(x, px - r * 0.5, py - r * 0.15, r, r * 0.3, r * 0.15);
      x.fill();
    } else if (s === "off") {
      x.beginPath();
      x.arc(px, py, r * 0.5, 0, 6.283);
      x.fill();
    } else if (s === "idle") {
      x.beginPath();
      x.arc(px - r * 0.32, py - r * 0.32, r * 0.55, 0, 6.283);
      x.fill();
    }
  };

  EX.chipDraw = function(x, t, px, py, fs, fam, fg, bg, pad) {
    x.font = "600 " + fs + "px " + fam;
    var w = x.measureText(t).width + pad * 2,
        h = fs * 1.9;
    x.fillStyle = bg;
    EX.rrect(x, px, py - h * 0.72, w, h, h * 0.38);
    x.fill();
    x.fillStyle = fg;
    x.fillText(t, px + pad, py);
    return w;
  };

  EX.wrapT = function(x, t, mx, lh, x0, y0, max) {
    var w = t.split(" "), l = "", n = 0, i, tt;
    for (i = 0; i < w.length; i++) {
      tt = l ? l + " " + w[i] : w[i];
      if (x.measureText(tt).width > mx && l) {
        x.fillText(l, x0, y0 + n * lh);
        n++;
        l = w[i];
        if (n >= max) return;
      } else {
        l = tt;
      }
    }
    x.fillText(l, x0, y0 + n * lh);
  };

  /* ----- Renderização de Cartões ----- */

  /**
   * Renderiza o cartão de perfil completo em um elemento canvas.
   * @param {HTMLCanvasElement} c - Canvas destino
   * @param {Object} o - Opções de exportação
   * @param {Object} [deps] - Injeção de dependências e estado
   * @returns {Promise}
   */
  EX.drawProfile = function(c, o, deps) {
    var P = (deps && deps.PRO) || (typeof window !== 'undefined' ? window.PRO : null) || {};
    var MED = (deps && deps.MED) || (typeof window !== 'undefined' ? window.MED : null) || {};
    var data = (deps && deps.data) || (typeof window !== 'undefined' ? window.data : null) || { items: [] };
    var loadImgFn = (deps && deps.loadImg) || (typeof window !== 'undefined' ? window.loadImg : null);
    var drawCoverFn = (deps && deps.drawCover) || (M && M.drawCover) || (root && root.AppMedia && root.AppMedia.drawCover) || (typeof window !== 'undefined' ? window.drawCover : null);
    var shownBadgesFn = (deps && deps.shownBadges) || (typeof window !== 'undefined' ? window.shownBadges : null) || function() { return []; };
    var xpInfoFn = (deps && deps.xpInfo) || (G && G.xpInfo) || (root && root.AppGamification && root.AppGamification.xpInfo) || (typeof window !== 'undefined' ? window.xpInfo : null) || function() { return { L: 1, xp: 0, p: 0 }; };
    var streakFn = (deps && deps.streak) || (typeof window !== 'undefined' ? window.streak : null) || function() { return 0; };
    var nDoneFn = (deps && deps.nDone) || (typeof window !== 'undefined' ? window.nDone : null) || function() { return 0; };
    var init1Fn = (deps && deps.init1) || (typeof window !== 'undefined' ? window.init1 : null) || function() { return (P.user || "U").charAt(0).toUpperCase(); };
    var isDarkFn = (deps && deps.isDark) || (typeof window !== 'undefined' ? window.isDark : null);
    var normUrlFn = (U && U.normUrl) || (root && root.AppUtils && root.AppUtils.normUrl) || function(u) { return u; };
    var hostOfFn = (U && U.hostOf) || (root && root.AppUtils && root.AppUtils.hostOf) || function(u) { return u; };
    var mixHexFn = (U && U.mixHex) || (root && root.AppUtils && root.AppUtils.mixHex) || function(a, b, w) { return a; };
    var rgbaFn = (U && U.rgba) || (root && root.AppUtils && root.AppUtils.rgba) || function(c, a) { return c; };

    var seq = (deps && deps.seq != null) ? deps.seq : (typeof window !== 'undefined' ? window.exSeq : 0);
    var Wd = c.width, Hd = c.height, T = EX.exTheme(o, isDarkFn), wide = o.fmt === "wide", sq = o.fmt === "square", sc = Math.min(Wd, Hd) / 390;

    var pick = function(k) {
      var item = MED[k];
      return item ? (item.t === "image" ? item.url : item.still) : "";
    };

    if (!loadImgFn) {
      loadImgFn = function(u) {
        return new Promise(function(res) {
          if (!u) { res(null); return; }
          var im = new Image();
          im.onload = function() { res(im); };
          im.onerror = function() { res(null); };
          im.src = u;
        });
      };
    }

    return Promise.all([
      loadImgFn(pick("banner")),
      loadImgFn(pick("avatar")),
      loadImgFn(o.pbg && P.pbgM ? pick("pbg") : "")
    ]).then(function(r) {
      if ((deps && typeof deps.getSeq === "function" ? deps.getSeq() : ((typeof window !== 'undefined' && window.exSeq != null) ? window.exSeq : seq)) !== seq) return;
      var x = c.getContext("2d"),
          fam = (typeof window !== 'undefined' && typeof window.getComputedStyle === 'function') ? window.getComputedStyle(document.body).fontFamily : 'system-ui, sans-serif',
          c1 = mixHexFn(T.base, P.pa || "#7c5cff", 0.14),
          c2 = mixHexFn(T.base, P.pb || "#ff5c8a", 0.12),
          i;

      var ink = EX.inkOf(P.pa || "#7c5cff", T.dk),
          inkbg = rgbaFn(ink, 0.16),
          inkbd = rgbaFn(ink, 0.36),
          fok = (typeof document !== 'undefined') ? document.documentElement.classList.contains("fontok") : false;

      EX.exReset(x);

      var g = x.createLinearGradient(0, 0, 0, Hd);
      g.addColorStop(0, c1);
      g.addColorStop(1, c2);
      x.fillStyle = g;
      x.fillRect(0, 0, Wd, Hd);

      if (r[2]) {
        var S2 = P.pbgS || {},
            bl = EX.BLEND_MODES.indexOf(S2.blend) > -1 ? S2.blend : "normal",
            bp = Math.max(0, +S2.blur || 0) * sc,
            pd = bp * 2;
        x.save();
        x.globalAlpha = Math.min(1, Math.max(0, (+S2.op || 100) / 100));
        x.globalCompositeOperation = bl === "normal" ? "source-over" : bl;
        try {
          x.filter = "blur(" + bp + "px) brightness(" + (+S2.bri || 100) + "%) saturate(" + (+S2.sat || 100) + "%)";
        } catch (e) {}
        drawCoverFn(x, r[2], P.pbgM, -pd, -pd, Wd + pd * 2, Hd + pd * 2);
        x.restore();
      }

      var bw = wide ? Math.round(Wd * 0.4) : Wd,
          bh = wide ? Hd : Math.round(Hd * (sq ? 0.36 : 0.375)),
          bc = document.createElement("canvas");
      bc.width = bw;
      bc.height = bh;

      var bx = bc.getContext("2d"),
          bg = bx.createLinearGradient(0, 0, bw, bh);
      bg.addColorStop(0, P.pa || "#7c5cff");
      bg.addColorStop(1, P.pb || "#ff5c8a");
      bx.fillStyle = bg;
      bx.fillRect(0, 0, bw, bh);

      if (r[0] && P.bannerM) drawCoverFn(bx, r[0], P.bannerM, 0, 0, bw, bh);

      bx.globalCompositeOperation = "destination-in";
      var mg = wide ? bx.createLinearGradient(0, 0, bw, 0) : bx.createLinearGradient(0, 0, 0, bh);
      mg.addColorStop(0, "#000");
      mg.addColorStop(wide ? 0.6 : 0.34, "#000");
      mg.addColorStop(wide ? 0.85 : 0.66, "rgba(0,0,0,.6)");
      mg.addColorStop(1, "rgba(0,0,0,0)");
      bx.fillStyle = mg;
      bx.fillRect(0, 0, bw, bh);
      x.drawImage(bc, 0, 0);

      EX.fxStatic(x, Wd, Hd, P, sc, T);

      var ar = wide ? 118 : (sq ? 104 : Math.round(Wd * 0.135)),
          x0 = wide ? Math.round(Wd * 0.46) : Math.round(Wd * 0.065),
          ax = x0 + ar + 10,
          ay = wide ? Math.round(Hd * 0.24) : bh,
          mw = Wd - x0 - Math.round(Wd * 0.05);

      EX.drawRing(x, ax, ay, ar, P, c1, sc);

      x.save();
      x.beginPath();
      x.arc(ax, ay, ar, 0, 6.283);
      x.clip();

      var ag = x.createLinearGradient(ax - ar, ay - ar, ax + ar, ay + ar);
      ag.addColorStop(0, P.pa || "#7c5cff");
      ag.addColorStop(1, P.pb || "#ff5c8a");
      x.fillStyle = ag;
      x.fillRect(ax - ar, ay - ar, ar * 2, ar * 2);

      if (r[1] && P.avatarM) {
        drawCoverFn(x, r[1], P.avatarM, ax - ar, ay - ar, ar * 2, ar * 2);
      } else {
        x.fillStyle = "#fff";
        x.font = "600 " + Math.round(ar * 0.9) + "px " + fam;
        x.textAlign = "center";
        x.textBaseline = "middle";
        x.fillText(init1Fn(), ax, ay + 4);
        x.textAlign = "left";
        x.textBaseline = "alphabetic";
      }
      x.restore();

      EX.drawDot(x, ax + ar * 0.72, ay + ar * 0.72, ar * 0.19, P.status || "online", c1, sc);

      var y = ay + ar + Math.round(sc * (wide ? 30 : 36)),
          can = function(h) { return y + h <= Hd - Math.round(sc * 34); },
          ns = wide ? 100 : (sq ? 72 : 88),
          us = wide ? 44 : (sq ? 34 : 42),
          bs = wide ? 38 : (sq ? 32 : 38);

      var nm = P.display || "Sem nome",
          nf = {
            serif: "italic 500 " + ns + "px Georgia,serif",
            mono: "600 " + Math.round(ns * 0.88) + "px ui-monospace,Menlo,monospace"
          }[P.nameStyle];

      x.font = nf || ("600 " + ns + "px " + fam);
      var nw = Math.min(mw - (P.verified ? ns : 0), x.measureText(nm).width);

      if (P.nameStyle === "grad") {
        var ng = x.createLinearGradient(x0, 0, x0 + nw, 0);
        ng.addColorStop(0, P.pa || "#7c5cff");
        ng.addColorStop(1, P.pb || "#ff5c8a");
        x.fillStyle = ng;
      } else {
        x.fillStyle = T.tx;
      }

      if (P.nameStyle === "glow") {
        x.shadowColor = P.pa || "#7c5cff";
        x.shadowBlur = 22 * sc;
      }

      x.fillText(nm, x0, y, mw);
      x.shadowBlur = 0;
      x.shadowColor = "transparent";

      if (P.verified) {
        var vr = ns * 0.28,
            vx = x0 + nw + vr + 14 * sc,
            vy = y - ns * 0.3;
        x.fillStyle = P.pa || "#7c5cff";
        x.beginPath();
        x.arc(vx, vy, vr, 0, 6.283);
        x.fill();
        x.strokeStyle = "#fff";
        x.lineWidth = Math.max(3, vr * 0.2);
        x.lineCap = "round";
        x.beginPath();
        x.moveTo(vx - vr * 0.4, vy);
        x.lineTo(vx - vr * 0.1, vy + vr * 0.32);
        x.lineTo(vx + vr * 0.45, vy - vr * 0.3);
        x.stroke();
      }

      y += us + Math.round(sc * 10);
      x.fillStyle = T.mu;
      x.font = "400 " + us + "px " + fam;
      x.fillText((P.user || "usuario") + (P.pronouns ? " · " + P.pronouns : ""), x0, y, mw);

      var cx = x0, cy = y + Math.round(us * 1.5), fs = Math.round(us * 0.72), any = false;

      if (P.tag) {
        cx += EX.chipDraw(x, P.tag, cx, cy, fs, fam, T.tx, rgbaFn(P.pa || "#7c5cff", 0.2), fs * 0.6) + 14 * sc;
        any = true;
      }
      if (P.role) {
        cx += EX.chipDraw(x, P.role, cx, cy, fs, fam, "#fff", P.pa || "#7c5cff", fs * 0.6) + 14 * sc;
        any = true;
      }
      if (P.statusText && cx < x0 + mw * 0.6) {
        EX.chipDraw(x, P.statusText.slice(0, 28), cx, cy, fs, fam, T.tx, rgbaFn(T.tx, 0.08), fs * 0.6);
        any = true;
      }
      if (any) y = cy + Math.round(us * 0.6);

      var xi = xpInfoFn(), sk = streakFn();

      if (o.level && can(us * 3)) {
        y += Math.round(us * 1.6);
        x.fillStyle = T.tx;
        x.font = "600 " + Math.round(us * 0.95) + "px " + fam;
        x.fillText("Nível " + xi.L, x0, y);
        if (sk > 0) {
          var st2 = sk + (sk === 1 ? " dia seguido" : " dias seguidos");
          x.fillStyle = ink;
          x.font = "500 " + Math.round(us * 0.85) + "px " + fam;
          x.textAlign = "right";
          x.fillText(st2, x0 + mw, y);
          x.textAlign = "left";
        }
        y += Math.round(us * 0.55);
        var bh2 = Math.max(8, sc * 3);
        x.fillStyle = rgbaFn(T.tx, 0.1);
        EX.rrect(x, x0, y, mw, bh2, bh2 / 2);
        x.fill();

        var lg = x.createLinearGradient(x0, 0, x0 + mw, 0);
        lg.addColorStop(0, P.pa || "#7c5cff");
        lg.addColorStop(1, P.pb || "#ff5c8a");
        x.fillStyle = lg;
        EX.rrect(x, x0, y, Math.max(bh2, mw * Math.min(1, Math.max(0, xi.p))), bh2, bh2 / 2);
        x.fill();
        y += bh2;
      }

      var lines = wide ? 4 : (sq ? 2 : 5);
      if (o.bio && P.bio && can(bs * 2.5)) {
        y += Math.round(bs * 1.7);
        x.fillStyle = T.tx;
        x.font = "400 " + bs + "px " + fam;
        EX.wrapT(x, P.bio, mw, Math.round(bs * 1.4), x0, y, lines);
        y += Math.round(bs * 1.4) * (Math.min(lines, Math.ceil(x.measureText(P.bio).width / mw)));
      }

      var lk = (P.links || []).map(function(l) {
        return { n: l.n, u: normUrlFn(l.u) };
      }).filter(function(l) {
        return l.u;
      }).slice(0, wide ? 3 : (sq ? 2 : 4));

      if (o.links && lk.length && can(fs * 3)) {
        y += Math.round(fs * 2.1);
        var lx = x0;
        for (i = 0; i < lk.length; i++) {
          var lt = (lk[i].n || hostOfFn(lk[i].u)).slice(0, 18);
          x.font = "600 " + fs + "px " + fam;
          var lw = x.measureText(lt).width + fs * 1.2;
          if (lx + lw > x0 + mw) break;
          lx += EX.chipDraw(x, lt, lx, y, fs, fam, T.tx, rgbaFn(T.tx, 0.08), fs * 0.6) + 12 * sc;
        }
        y += Math.round(fs * 0.6);
      }

      var done = nDoneFn(),
          tile = wide ? 100 : (sq ? 86 : 108),
          stH = Math.round(tile * 1.15);

      if (o.stats && !sq && can(stH + tile + 80)) {
        y += Math.round(sc * 16);
        var gp = Math.round(sc * 8),
            cw = (mw - gp * 2) / 3,
            sv = [
              [data.items.length, "CONTAGENS"],
              [done, "CONCLUÍDAS"],
              [Object.keys(P.days || {}).length, "DIAS DE USO"]
            ];
        for (i = 0; i < 3; i++) {
          var sx = x0 + i * (cw + gp);
          x.fillStyle = rgbaFn(T.tx, 0.06);
          EX.rrect(x, sx, y, cw, stH, sc * 10);
          x.fill();
          x.textAlign = "center";
          x.fillStyle = T.tx;
          x.font = "600 " + Math.round(stH * 0.38) + "px " + fam;
          x.fillText(String(sv[i][0]), sx + cw / 2, y + stH * 0.52);
          x.fillStyle = T.mu;
          x.font = "600 " + Math.round(stH * 0.14) + "px " + fam;
          x.fillText(sv[i][1], sx + cw / 2, y + stH * 0.82);
          x.textAlign = "left";
        }
        y += stH;
      }

      var bd = shownBadgesFn().slice(0, wide ? 8 : 7),
          by = Math.max(y + Math.round(sc * 22), Hd - Math.round(tile * (wide ? 2.2 : (sq ? 2.3 : 2.6)))),
          bxx = x0;

      if (o.badges && bd.length && by + tile < Hd - Math.round(sc * 30)) {
        for (i = 0; i < bd.length; i++) {
          x.fillStyle = inkbg;
          EX.rrect(x, bxx, by, tile, tile, Math.round(tile * 0.3));
          x.fill();
          x.strokeStyle = inkbd;
          x.lineWidth = Math.max(2, sc * 0.7);
          EX.rrect(x, bxx, by, tile, tile, Math.round(tile * 0.3));
          x.stroke();
          if (fok) {
            x.fillStyle = ink;
            x.font = '400 ' + Math.round(tile * 0.56) + 'px "Material Symbols Rounded"';
            x.textAlign = "center";
            x.textBaseline = "middle";
            try { x.fontVariationSettings = '"FILL" 1'; } catch (e) {}
            x.fillText(bd[i].i, bxx + tile / 2, by + tile / 2 + 2);
            x.textAlign = "left";
            x.textBaseline = "alphabetic";
          }
          bxx += tile + Math.round(sc * 7);
        }
      }

      x.fillStyle = T.mu;
      x.font = "500 " + Math.round(sc * 10) + "px " + fam;
      x.textAlign = "center";
      try { x.letterSpacing = Math.round(sc * 2) + "px"; } catch (e) {}
      x.fillText("CONTAGEM REGRESSIVA", wide ? x0 + mw / 2 : Wd / 2, Hd - Math.round(sc * 16));
      x.textAlign = "left";
    });
  };

  /**
   * Renderiza o cartão de contagem regressiva em um elemento canvas.
   * @param {HTMLCanvasElement} c - Canvas destino
   * @param {Object} o - Opções de exportação
   * @param {Object} [deps] - Injeção de dependências e estado
   * @returns {Promise}
   */
  EX.drawCount = function(c, o, deps) {
    var findFn = (deps && deps.find) || (typeof window !== 'undefined' ? window.find : null);
    var st = (deps && deps.st) || (typeof window !== 'undefined' ? window.st : null);
    var it = (o.cid && findFn ? findFn(o.cid) : null) || st;

    var toastFn = (deps && deps.toast) || (typeof window !== 'undefined' ? window.toast : function(){});
    if (!it) {
      toastFn("Crie uma contagem primeiro");
      return Promise.resolve();
    }

    var MED = (deps && deps.MED) || (typeof window !== 'undefined' ? window.MED : null) || {};
    var prefs = (deps && deps.prefs) || (typeof window !== 'undefined' ? window.prefs : null) || { fw: "mid", size: 100, prog: "line" };
    var loadImgFn = (deps && deps.loadImg) || (typeof window !== 'undefined' ? window.loadImg : null);
    var drawCoverFn = (deps && deps.drawCover) || (M && M.drawCover) || (root && root.AppMedia && root.AppMedia.drawCover) || (typeof window !== 'undefined' ? window.drawCover : null);
    var computeFn = (deps && deps.compute) || (C && C.compute) || (root && root.AppCountdown && root.AppCountdown.compute) || (typeof window !== 'undefined' ? window.compute : null);
    var tgtFn = (deps && deps.tgt) || (U && U.tgt) || (root && root.AppUtils && root.AppUtils.tgt) || (typeof window !== 'undefined' ? window.tgt : null);
    var hexOkFn = (deps && deps.hexOk) || (U && U.hexOk) || (root && root.AppUtils && root.AppUtils.hexOk) || (typeof window !== 'undefined' ? window.hexOk : null);
    var mixHexFn = (U && U.mixHex) || (root && root.AppUtils && root.AppUtils.mixHex) || function(a, b, w) { return a; };
    var rgbaFn = (U && U.rgba) || (root && root.AppUtils && root.AppUtils.rgba) || function(c, a) { return c; };
    var PH = (deps && deps.PH) || (typeof window !== 'undefined' ? window.PH : null) || ["Cada segundo conta"];
    var idxFn = (deps && deps.idx) || (typeof window !== 'undefined' ? window.idx : null) || function() { return 0; };
    var isDarkFn = (deps && deps.isDark) || (typeof window !== 'undefined' ? window.isDark : null);

    var seq = (deps && deps.seq != null) ? deps.seq : (typeof window !== 'undefined' ? window.exSeq : 0);
    var Wd = c.width, Hd = c.height, T = EX.exTheme(o, isDarkFn),
        col = (hexOkFn && hexOkFn(it.col)) ? it.col : "",
        acc = col || T.tx,
        wide = o.fmt === "wide",
        sc = Math.min(Wd, Hd) / 390;

    var mediaItem = MED["cb_" + it.id],
        su = (o.cBg && it.bg === "image" && mediaItem) ? (mediaItem.t === "image" ? mediaItem.url : mediaItem.still) : "";

    if (!loadImgFn) {
      loadImgFn = function(u) {
        return new Promise(function(res) {
          if (!u) { res(null); return; }
          var im = new Image();
          im.onload = function() { res(im); };
          im.onerror = function() { res(null); };
          im.src = u;
        });
      };
    }

    return loadImgFn(su).then(function(im) {
      if ((deps && typeof deps.getSeq === "function" ? deps.getSeq() : ((typeof window !== 'undefined' && window.exSeq != null) ? window.exSeq : seq)) !== seq) return;
      var x = c.getContext("2d"),
          fam = (typeof window !== 'undefined' && typeof window.getComputedStyle === 'function') ? window.getComputedStyle(document.body).fontFamily : 'system-ui, sans-serif',
          fw = { light: 300, mid: 400, bold: 600 }[prefs.fw] || 300,
          fok = (typeof document !== 'undefined') ? document.documentElement.classList.contains("fontok") : false,
          i;

      var r = (computeFn && computeFn.length <= 1) ? computeFn(it) : (computeFn ? computeFn(it, (typeof window !== 'undefined' && typeof window.NOW === 'function' ? window.NOW() : Date.now()), prefs, tgtFn, (U && U.pad) || function(n){return n<10?"0"+n:String(n)}) : { over: false, b: "", sub: "", unit: "", pct: 0, d: 0, h: 0, m: 0, sec: 0, secs: 0 });
      var cx = Wd / 2;
      EX.exReset(x);

      var g = x.createRadialGradient(cx, Hd * 0.4, 0, cx, Hd * 0.4, Math.max(Wd, Hd) * 0.8);
      g.addColorStop(0, T.bg2);
      g.addColorStop(1, T.bg0);
      x.fillStyle = g;
      x.fillRect(0, 0, Wd, Hd);

      if (o.cBg && it.bg && it.bg !== "none") {
        var bo = Math.min(1, Math.max(0.1, (it.bgO == null ? 45 : it.bgO) / 100)),
            bc2 = col || "#7c5cff";
        if (it.bg === "aurora") {
          x.save();
          x.globalAlpha = Math.min(1, bo * 1.1);
          [
            [0.1, 0.05, 0.7, bc2],
            [0.95, 0.95, 0.8, mixHexFn(bc2, "#ffffff", 0.45)]
          ].forEach(function(a) {
            var rg = x.createRadialGradient(Wd * a[0], Hd * a[1], 0, Wd * a[0], Hd * a[1], Math.max(Wd, Hd) * a[2]);
            rg.addColorStop(0, rgbaFn(a[3], 0.85));
            rg.addColorStop(1, rgbaFn(a[3], 0));
            x.fillStyle = rg;
            x.fillRect(0, 0, Wd, Hd);
          });
          x.restore();
        } else if (it.bg === "grid") {
          x.save();
          x.globalAlpha = bo;
          x.strokeStyle = rgbaFn(bc2, 0.55);
          x.lineWidth = Math.max(1, sc * 0.8);
          var gs = 34 * sc;
          x.beginPath();
          for (i = 0; i < Wd; i += gs) {
            x.moveTo(i, 0); x.lineTo(i, Hd);
          }
          for (i = 0; i < Hd; i += gs) {
            x.moveTo(0, i); x.lineTo(Wd, i);
          }
          x.stroke();
          x.restore();
          var vg = x.createRadialGradient(cx, Hd * 0.45, 0, cx, Hd * 0.45, Math.max(Wd, Hd) * 0.6);
          vg.addColorStop(0, rgbaFn(T.bg0, 0));
          vg.addColorStop(1, rgbaFn(T.bg0, 1));
          x.fillStyle = vg;
          x.fillRect(0, 0, Wd, Hd);
        } else if (it.bg === "image" && im && it.bgM) {
          x.save();
          x.globalAlpha = bo;
          drawCoverFn(x, im, it.bgM, 0, 0, Wd, Hd);
          x.restore();
          var dm = x.createLinearGradient(0, 0, 0, Hd);
          dm.addColorStop(0, rgbaFn(T.bg0, 0.9));
          dm.addColorStop(0.3, rgbaFn(T.bg0, 0));
          dm.addColorStop(0.7, rgbaFn(T.bg0, 0));
          dm.addColorStop(1, rgbaFn(T.bg0, 0.9));
          x.fillStyle = dm;
          x.fillRect(0, 0, Wd, Hd);
        }
      }

      var big = r.over ? "Chegou" : r.b,
          k0 = r.over ? "t" : r.cls,
          fac = { "": 0.4, s: 0.3, t: 0.2, t2: 0.15, t3: 0.11 }[k0] || 0.2,
          sz = Math.min(Wd, wide ? Hd * 1.5 : Wd) * fac * ((prefs.size || 100) / 100);

      var setF = function(s) {
        x.font = fw + " " + s + "px " + fam;
        try { x.letterSpacing = (-s * 0.03) + "px"; } catch (e) {}
      };
      setF(sz);
      while (x.measureText(big).width > Wd * 0.84 && sz > 30) {
        sz -= 4;
        setF(sz);
      }

      var by = Hd * (wide ? 0.46 : 0.43),
          ty = by - sz * 0.62 - sc * 30;

      x.textAlign = "center";
      x.fillStyle = T.tx;
      x.textBaseline = "middle";
      x.fillText(big, cx, by);
      x.textBaseline = "alphabetic";

      try { x.letterSpacing = Math.round(sc * 3) + "px"; } catch (e) {}
      var uy = by + sz * 0.5 + sc * 26;
      x.fillStyle = T.mu;
      x.font = "400 " + Math.round(sc * 15) + "px " + fam;
      x.fillText((r.over ? "o grande dia" : r.unit).toUpperCase(), cx, uy);

      var yy = uy;
      if (r.sub && !r.over) {
        yy = uy + sc * 44;
        x.fillStyle = T.tx;
        x.globalAlpha = 0.85;
        x.font = fw + " " + Math.round(sc * 28) + "px " + fam;
        try { x.letterSpacing = "0px"; } catch (e) {}
        x.fillText(r.sub, cx, yy);
        x.globalAlpha = 1;
      }

      if (o.cName) {
        var nm = (it.name || "Faltam").toUpperCase(),
            nfs = Math.round(sc * 15),
            ic = (it.ico && fok) ? it.ico : "";
        x.font = "500 " + nfs + "px " + fam;
        var tw = x.measureText(nm).width,
            iw = ic ? nfs * 1.9 : 0,
            sx0 = cx - (tw + iw) / 2;
        x.textAlign = "left";
        x.fillStyle = T.mu;
        if (ic) {
          x.save();
          x.font = '400 ' + Math.round(nfs * 1.5) + 'px "Material Symbols Rounded"';
          x.fillStyle = acc;
          x.fillText(ic, sx0, ty + nfs * 0.2);
          x.restore();
        }
        x.fillStyle = T.mu;
        x.font = "500 " + nfs + "px " + fam;
        x.fillText(nm, sx0 + iw, ty);
        x.textAlign = "center";
      }

      try { x.letterSpacing = "0px"; } catch (e) {}
      if (o.cPhrase) {
        var ph = it.phrase || PH[(Math.floor(Date.now() / 864e5) + Math.max(0, idxFn(it.id))) % PH.length];
        yy += sc * (r.sub ? 62 : 70);
        x.fillStyle = T.mu;
        x.font = "400 " + Math.round(sc * 17) + "px " + fam;
        x.fillText(ph, cx, yy, Wd * 0.8);
      }

      if (o.cProg) {
        yy += sc * 62;
        var rem = 1 - r.pct, pw = Wd * 0.42;
        x.fillStyle = rgbaFn(acc, 0.18);
        var pk = prefs.prog;
        if (pk === "ring") {
          var rr = sc * 26;
          x.strokeStyle = rgbaFn(acc, 0.18);
          x.lineWidth = sc * 3;
          x.beginPath();
          x.arc(cx, yy + rr * 0.4, rr, 0, 6.283);
          x.stroke();
          x.strokeStyle = acc;
          x.lineCap = "round";
          x.beginPath();
          x.arc(cx, yy + rr * 0.4, rr, -Math.PI / 2, -Math.PI / 2 + 6.283 * rem);
          x.stroke();
          yy += rr;
        } else if (pk === "bars") {
          var nb = 24, lit = Math.ceil(rem * nb - 1e-6), bw2 = sc * 2, gp = sc * 7, x1 = cx - (nb * gp) / 2;
          for (i = 0; i < nb; i++) {
            x.fillStyle = i < lit ? acc : rgbaFn(acc, 0.18);
            EX.rrect(x, x1 + i * gp, yy - sc * 12, bw2, sc * 24, bw2 / 2);
            x.fill();
          }
        } else if (pk === "dots") {
          var nd = 16, lt = Math.ceil(rem * nd - 1e-6), dg = sc * 13, x2 = cx - (nd * dg) / 2 + dg / 2;
          for (i = 0; i < nd; i++) {
            x.fillStyle = i < lt ? acc : rgbaFn(acc, 0.18);
            x.beginPath();
            x.arc(x2 + i * dg, yy, sc * 3, 0, 6.283);
            x.fill();
          }
        } else {
          var lh = Math.max(5, sc * 2);
          x.fillStyle = rgbaFn(acc, 0.18);
          EX.rrect(x, cx - pw / 2, yy - lh / 2, pw, lh, lh / 2);
          x.fill();
          x.fillStyle = acc;
          EX.rrect(x, cx - pw / 2, yy - lh / 2, Math.max(lh, pw * rem), lh, lh / 2);
          x.fill();
        }
      }

      if (o.cDate && tgtFn) {
        yy += sc * 54;
        x.fillStyle = T.mu;
        x.font = "400 " + Math.round(sc * 13) + "px " + fam;
        x.fillText(tgtFn(it).toLocaleDateString("pt-BR", { weekday: "long", day: "numeric", month: "long", year: "numeric" }) + " · " + it.time, cx, yy, Wd * 0.9);
      }

      x.fillStyle = T.mu;
      x.globalAlpha = 0.7;
      x.font = "500 " + Math.round(sc * 10) + "px " + fam;
      try { x.letterSpacing = Math.round(sc * 2) + "px"; } catch (e) {}
      x.fillText("CONTAGEM REGRESSIVA", cx, Hd - Math.round(sc * 16));
      x.globalAlpha = 1;
    });
  };

  /* ----- Formatação de nome de arquivo e pontes de compartilhamento ----- */

  /**
   * Gera nome de arquivo padronizado para a imagem gerada.
   * @param {string} kind - "profile" ou "count"
   * @param {string} rawName - Nome base
   * @returns {string} Nome formatado
   */
  EX.fileName = function(kind, rawName) {
    var n = rawName != null ? rawName : (kind === "profile" ? "perfil" : "contagem");
    var slug = String(n)
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "") || "imagem";
    return (kind === "profile" ? "perfil-" : "contagem-") + slug + ".png";
  };

  /**
   * Salva imagem via link de download no navegador.
   * @param {string} dataUrl - URL base64 ou blob
   * @param {string} name - Nome do arquivo
   * @param {Function} [toastFn] - Callback de feedback
   */
  EX.anchor = function(dataUrl, name, toastFn) {
    try {
      var a = document.createElement("a");
      a.href = dataUrl;
      a.download = name;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } catch (e) {}
    var toast = toastFn || (typeof window !== 'undefined' ? window.toast : function(){});
    toast("Se nada acontecer, use a tela cheia e faça uma captura de tela");
  };

  /**
   * Ponte de compatibilidade nativa com Android (Capacitor / Cordova / Web Share / Fallback).
   * @param {Blob} blob - Imagem PNG em formato Blob
   * @param {string} name - Nome do arquivo
   * @param {boolean} share - true se deve abrir diálogo de compartilhamento, false para salvar
   * @param {Object} [callbacks] - { toast, anchor }
   */
  EX.bridge = function(blob, name, share, callbacks) {
    var b2dFn = (U && U.b2d) || (root && root.AppUtils && root.AppUtils.b2d) || (typeof window !== 'undefined' ? window.b2d : null);
    var toastFn = (callbacks && callbacks.toast) || (typeof window !== 'undefined' ? window.toast : function(){});
    var anchorFn = (callbacks && callbacks.anchor) || function(d, n) { EX.anchor(d, n, toastFn); };

    if (!b2dFn) {
      if (typeof URL !== 'undefined' && URL.createObjectURL) {
        anchorFn(URL.createObjectURL(blob), name);
      }
      return;
    }

    b2dFn(blob).then(function(d) {
      var C = (typeof window !== 'undefined' && window.Capacitor && window.Capacitor.Plugins) ? window.Capacitor.Plugins : null;
      try {
        if (C && C.Filesystem) {
          C.Filesystem.writeFile({
            path: name,
            data: d.split(",")[1],
            directory: share ? "CACHE" : "DOCUMENTS"
          }).then(function(r) {
            if (share && C.Share) {
              C.Share.share({ title: name, url: r.uri });
            } else {
              toastFn("Imagem salva em Documentos");
            }
          }).catch(function() {
            anchorFn(d, name);
          });
          return;
        }

        if (share && typeof window !== 'undefined' && window.plugins && window.plugins.socialsharing) {
          window.plugins.socialsharing.shareWithOptions(
            { files: [d] },
            function() {},
            function() { anchorFn(d, name); }
          );
          return;
        }
      } catch (e) {}

      anchorFn(d, name);
    });
  };

  root.AppExport = EX;
})(typeof window !== "undefined" ? window : this);
