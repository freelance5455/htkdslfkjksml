/**
 * Gerenciador de Mídia e Enquadramento (Cropper)
 * Controle de enquadramento, proporções de aspecto, zoom, pan e persistência de mídias.
 * Totalmente compatível com Android WebView (file:// e http://).
 */
(function(root){
  var M = {};

  /**
   * Cálculo matemático de enquadramento de mídia (clampM)
   * Garante que o zoom (z), o ponto focal (fx, fy) e as proporções (ri/rb) respeitem os limites do container.
   */
  M.clampM = function(m, rb){
    var ri = m.ri || 1;
    var z = m.z || 1;
    var wp = z * Math.max(1, ri / rb);
    var hp = z * Math.max(1, rb / ri);
    var hx = Math.min(0.5, 0.5 / wp);
    var hy = Math.min(0.5, 0.5 / hp);
    m.fx = Math.min(1 - hx, Math.max(hx, m.fx == null ? 0.5 : m.fx));
    m.fy = Math.min(1 - hy, Math.max(hy, m.fy == null ? 0.5 : m.fy));
    return { wp: wp, hp: hp };
  };

  /**
   * Aplicação do layout de estilos CSS (--w, --h, --l, --t) no elemento container de mídia
   */
  M.layMw = function(el, getMetaFn, getMedFn){
    var k = el.getAttribute("data-k");
    var m = getMetaFn(k);
    if (!m || !getMedFn(k)) return;
    var w = el.clientWidth;
    var h = el.clientHeight;
    if (!w || !h) return;
    var c = M.clampM(m, w / h);
    var s = el.style;
    s.setProperty("--w", c.wp * 100 + "%");
    s.setProperty("--h", c.hp * 100 + "%");
    s.setProperty("--l", (50 - m.fx * c.wp * 100) + "%");
    s.setProperty("--t", (50 - m.fy * c.hp * 100) + "%");
  };

  /**
   * HTML de placeholder para container de mídia
   */
  M.mwHTML = function(k, still){
    return '<div class="mw" data-k="' + k + '"' + (still ? " data-still" : "") + '></div>';
  };

  /**
   * Renderização de imagem com cobertura mantendo o crop e enquadramento em Canvas 2D
   */
  M.drawCover = function(x, im, m, dx, dy, dw, dh){
    var rb = dw / dh;
    var ri = im.naturalWidth / im.naturalHeight;
    var z = m.z || 1;
    var wp = z * Math.max(1, ri / rb);
    var hp = z * Math.max(1, rb / ri);
    var hx = Math.min(0.5, 0.5 / wp);
    var hy = Math.min(0.5, 0.5 / hp);
    var fx0 = Math.min(1 - hx, Math.max(hx, m.fx == null ? 0.5 : m.fx));
    var fy0 = Math.min(1 - hy, Math.max(hy, m.fy == null ? 0.5 : m.fy));
    var sw = im.naturalWidth / wp;
    var sh = im.naturalHeight / hp;
    x.drawImage(im, fx0 * im.naturalWidth - sw / 2, fy0 * im.naturalHeight - sh / 2, sw, sh, dx, dy, dw, dh);
  };

  root.AppMedia = M;
})(typeof window !== "undefined" ? window : this);
