/* ============================================================
   environment.js — endless open world
   city · highway · tunnel · bridge · day/night · rain/fog
   ============================================================ */
'use strict';

const ENV = {
  segLen: 60,
  segCount: 34,
  laneW: 3.6,
  lanes: [-3.6, 0, 3.6],
  oncomingLanes: [9.4, 13.0, 16.6],
  leftBound: -5.4,
  rightBound: 5.4,
  medianX: 5.95,
  farRailX: 18.6,
};

const ZONE_CYCLE = 16;
function zoneForIndex(i) {
  const m = ((i % ZONE_CYCLE) + ZONE_CYCLE) % ZONE_CYCLE;
  if (m < 6) return 'CITY';
  if (m < 10) return 'HIGHWAY';
  if (m < 12) return 'TUNNEL';
  return 'BRIDGE';
}

class Environment {
  constructor(scene, renderer, envMap) {
    this.scene = scene;
    this.renderer = renderer;
    this.envMap = envMap;
    this.segments = [];
    this.timeOfDay = 19.2;
    this.autoTime = true;
    this.weatherName = 'clear';
    this.wet = 0.05;
    this.rainAmount = 0;
    this.night = 0.3;
    this.quality = 'high';
    this.bounds = { left: ENV.leftBound, right: ENV.rightBound };
    this._flash = 0;
    this._lastFlash = 0;

    this._buildSky();
    this._buildLights();
    this._buildTextures();
    this._buildGround();
    this._buildSegments();
    this._buildRain();
    this.setWeather('clear');
  }

  /* ================= SKY ================= */
  _buildSky() {
    this.skyUniforms = {
      topColor: { value: new THREE.Color(0x0b1026) },
      midColor: { value: new THREE.Color(0x5a4a70) },
      bottomColor: { value: new THREE.Color(0xf2a15a) },
      sunColor: { value: new THREE.Color(0xffd9a0) },
      sunDir: { value: new THREE.Vector3(0, 0.2, -1).normalize() },
      sunAmt: { value: 1.0 },
    };
    const mat = new THREE.ShaderMaterial({
      uniforms: this.skyUniforms,
      vertexShader: `
        varying vec3 vDir;
        void main() {
          vDir = position;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }`,
      fragmentShader: `
        uniform vec3 topColor, midColor, bottomColor, sunColor, sunDir;
        uniform float sunAmt;
        varying vec3 vDir;
        void main() {
          vec3 d = normalize(vDir);
          float h = clamp(d.y, -1.0, 1.0);
          vec3 col = h > 0.0
            ? mix(midColor, topColor, pow(h, 0.62))
            : mix(midColor, bottomColor, pow(-h, 0.55));
          float s = max(dot(d, normalize(sunDir)), 0.0);
          col += sunColor * pow(s, 260.0) * sunAmt * 1.4;
          col += sunColor * pow(s, 9.0) * sunAmt * 0.06;
          gl_FragColor = vec4(col, 1.0);
        }`,
      side: THREE.BackSide, depthWrite: false, fog: false,
    });
    this.sky = new THREE.Mesh(new THREE.SphereGeometry(760, 28, 16), mat);
    this.sky.renderOrder = -10;
    this.scene.add(this.sky);

    const glow = AD.glowTexture('rgba(255,240,200,1)', 'rgba(255,180,80,0)');
    this.sunSprite = new THREE.Sprite(new THREE.SpriteMaterial({
      map: glow, color: 0xffe2a8, transparent: true, opacity: 0.9,
      depthWrite: false, blending: THREE.AdditiveBlending, fog: false,
    }));
    this.sunSprite.scale.set(110, 110, 1);
    this.scene.add(this.sunSprite);

    this.moonSprite = new THREE.Sprite(new THREE.SpriteMaterial({
      map: glow, color: 0xbcd2ff, transparent: true, opacity: 0.7,
      depthWrite: false, blending: THREE.AdditiveBlending, fog: false,
    }));
    this.moonSprite.scale.set(52, 52, 1);
    this.scene.add(this.moonSprite);

    // stars
    const N = 900;
    const pos = new Float32Array(N * 3);
    for (let i = 0; i < N; i++) {
      const a = Math.random() * Math.PI * 2;
      const y = Math.random() * 0.9 + 0.05;
      const r = Math.sqrt(1 - y * y);
      pos[i * 3] = Math.cos(a) * r * 680;
      pos[i * 3 + 1] = y * 680;
      pos[i * 3 + 2] = Math.sin(a) * r * 680;
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    this.stars = new THREE.Points(g, new THREE.PointsMaterial({
      color: 0xdfe8ff, size: 2.2, transparent: true, opacity: 0,
      depthWrite: false, fog: false, sizeAttenuation: false,
    }));
    this.scene.add(this.stars);

    this.scene.fog = new THREE.Fog(0x35284a, 60, 620);
  }

  _buildLights() {
    this.hemi = new THREE.HemisphereLight(0x5a6fa8, 0x1a1410, 0.8);
    this.scene.add(this.hemi);
    this.sun = new THREE.DirectionalLight(0xffb37a, 1.5);
    this.sun.position.set(-80, 90, -40);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(1024, 1024);
    this.sun.shadow.camera.left = -38;
    this.sun.shadow.camera.right = 38;
    this.sun.shadow.camera.top = 38;
    this.sun.shadow.camera.bottom = -38;
    this.sun.shadow.camera.near = 1;
    this.sun.shadow.camera.far = 260;
    this.sun.shadow.bias = -0.0006;
    this.scene.add(this.sun);
    this.scene.add(this.sun.target);
    this.ambient = new THREE.AmbientLight(0x8a9ac0, 0.18);
    this.scene.add(this.ambient);
  }

  setQuality(q) {
    this.quality = q;
    const high = q === 'high';
    this.sun.castShadow = high;
    this.sun.shadow.mapSize.set(high ? 2048 : 1024, high ? 2048 : 1024);
    if (this.sun.shadow.map) { this.sun.shadow.map.dispose(); this.sun.shadow.map = null; }
    if (this.rainGeo) {
      this.rainGeo.setDrawRange(0, high ? this.rainCount * 2 : Math.floor(this.rainCount * 0.45) * 2);
    }
  }

  setEnvMap(map) { this.envMap = map; }

  /* ================= TEXTURES ================= */
  _buildTextures() {
    // asphalt with lane markings
    const W = 256, H = 256;
    const roadTex = AD.canvasTexture(W, H, (g) => {
      g.fillStyle = '#23262b'; g.fillRect(0, 0, W, H);
      for (let i = 0; i < 1400; i++) {
        const v = 26 + Math.random() * 30;
        g.fillStyle = `rgba(${v},${v},${v + 3},0.55)`;
        g.fillRect(Math.random() * W, Math.random() * H, 1.5, 1.5);
      }
      const xToPx = (x) => ((x - ENV.leftBound) / (ENV.rightBound - ENV.leftBound)) * W;
      g.fillStyle = '#e8e8e8';
      g.fillRect(xToPx(-5.05) - 2, 0, 4, H);
      g.fillRect(xToPx(5.05) - 2, 0, 4, H);
      for (const lx of [-1.8, 1.8]) {
        for (let y = 0; y < H; y += 34) g.fillRect(xToPx(lx) - 1.6, y, 3.2, 19);
      }
      // subtle tyre marks
      g.fillStyle = 'rgba(0,0,0,0.16)';
      g.fillRect(xToPx(-3.6) - 18, 0, 8, H);
      g.fillRect(xToPx(-3.6) + 10, 0, 8, H);
      g.fillRect(xToPx(0) - 18, 0, 8, H);
      g.fillRect(xToPx(0) + 10, 0, 8, H);
    });
    roadTex.repeat.set(1, 1);
    this.roadMat = new THREE.MeshStandardMaterial({
      map: roadTex, roughness: 0.92, metalness: 0.02,
      envMap: this.envMap, envMapIntensity: 0.2,
    });

    const grassTex = AD.canvasTexture(64, 64, (g) => {
      g.fillStyle = '#141a12'; g.fillRect(0, 0, 64, 64);
      for (let i = 0; i < 400; i++) {
        const v = 14 + Math.random() * 20;
        g.fillStyle = `rgb(${v * 0.7},${v + 4},${v * 0.6})`;
        g.fillRect(Math.random() * 64, Math.random() * 64, 2, 2);
      }
    }, 20, 20);
    this.grassMat = new THREE.MeshStandardMaterial({ map: grassTex, roughness: 1, color: 0x4a5a44 });

    const cityTex = AD.canvasTexture(64, 64, (g) => {
      g.fillStyle = '#181a1e'; g.fillRect(0, 0, 64, 64);
      for (let i = 0; i < 300; i++) {
        const v = 22 + Math.random() * 22;
        g.fillStyle = `rgb(${v},${v},${v + 2})`;
        g.fillRect(Math.random() * 64, Math.random() * 64, 2, 2);
      }
    }, 18, 18);
    this.cityGroundMat = new THREE.MeshStandardMaterial({ map: cityTex, roughness: 0.95, color: 0x555a60 });

    this.waterMat = new THREE.MeshStandardMaterial({
      color: 0x0a2a44, metalness: 0.85, roughness: 0.12,
      envMap: this.envMap, envMapIntensity: 1.4,
    });

    // building facade with lit windows
    this.buildingTex = AD.canvasTexture(128, 256, (g) => {
      g.fillStyle = '#20242c'; g.fillRect(0, 0, 128, 256);
      const lit = ['#ffd48a', '#ffe9b8', '#9fd4ff', '#ffb36b', '#d9f0ff'];
      for (let y = 6; y < 250; y += 14) {
        for (let x = 6; x < 122; x += 16) {
          const on = Math.random() < 0.44;
          g.fillStyle = on ? lit[(Math.random() * lit.length) | 0] : '#0a0c11';
          g.fillRect(x, y, 10, 8);
          if (on) {
            g.fillStyle = 'rgba(255,255,255,0.25)';
            g.fillRect(x + 1, y + 1, 8, 2);
          }
        }
      }
      // floor separators
      g.fillStyle = 'rgba(0,0,0,0.35)';
      for (let y = 0; y < 256; y += 14) g.fillRect(0, y, 128, 2);
    });
    this.buildingTex.wrapS = this.buildingTex.wrapT = THREE.RepeatWrapping;

    this.buildingMat = new THREE.MeshStandardMaterial({
      map: this.buildingTex, vertexColors: true,
      emissive: 0xffffff, emissiveMap: this.buildingTex, emissiveIntensity: 0.4,
      roughness: 0.82, metalness: 0.12,
    });
    this.propsMat = new THREE.MeshStandardMaterial({
      vertexColors: true, roughness: 0.66, metalness: 0.38,
      envMap: this.envMap, envMapIntensity: 0.35,
    });
    this.lampMat = new THREE.MeshStandardMaterial({
      color: 0xfff0c0, emissive: 0xffdf8a, emissiveIntensity: 1.8,
      roughness: 0.35, metalness: 0.1,
    });
    this.neonMat = new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false });
    this.sigRed = new THREE.MeshStandardMaterial({ color: 0x330000, emissive: 0xff1a08, emissiveIntensity: 0.1, roughness: 0.4 });
    this.sigAmber = new THREE.MeshStandardMaterial({ color: 0x2a1a00, emissive: 0xffa000, emissiveIntensity: 0.1, roughness: 0.4 });
    this.sigGreen = new THREE.MeshStandardMaterial({ color: 0x002a10, emissive: 0x00ff66, emissiveIntensity: 0.1, roughness: 0.4 });

    this.buildingTints = [0xffffff, 0xd8dde6, 0xb9c1cc, 0xc7bda8, 0x9fb0c0, 0xcfc6d6];
  }

  _boxUV(g, w, h, d, scale = 8) {
    const uv = g.attributes.uv;
    const su = [d / scale, d / scale, w / scale, w / scale, w / scale, w / scale];
    const sv = [h / scale, h / scale, d / scale, d / scale, h / scale, h / scale];
    for (let f = 0; f < 6; f++) {
      for (let v = 0; v < 4; v++) {
        const i = f * 4 + v;
        uv.setXY(i, uv.getX(i) * su[f], uv.getY(i) * sv[f]);
      }
    }
    uv.needsUpdate = true;
    return g;
  }

  /* ================= GROUND ================= */
  _buildGround() {
    const tex = AD.canvasTexture(64, 64, (g) => {
      g.fillStyle = '#0d0f0c'; g.fillRect(0, 0, 64, 64);
      for (let i = 0; i < 300; i++) {
        const v = 10 + Math.random() * 16;
        g.fillStyle = `rgb(${v},${v + 2},${v})`;
        g.fillRect(Math.random() * 64, Math.random() * 64, 3, 3);
      }
    }, 40, 200);
    this.groundMat = new THREE.MeshStandardMaterial({ map: tex, roughness: 1, color: 0x2a3028 });
    this.ground = new THREE.Mesh(new THREE.PlaneGeometry(1600, 4000), this.groundMat);
    this.ground.rotation.x = -Math.PI / 2;
    this.ground.position.set(0, -0.9, -1500);
    this.ground.receiveShadow = true;
    this.scene.add(this.ground);

    // static shared geometries
    this.geoRoad = new THREE.PlaneGeometry(ENV.rightBound - ENV.leftBound, ENV.segLen);
    this.geoGround = new THREE.PlaneGeometry(90, ENV.segLen);
    this.geoBox = new THREE.BoxGeometry(1, 1, 1);
  }

  /* ================= SEGMENTS ================= */
  _buildSegments() {
    for (let i = 0; i < ENV.segCount; i++) {
      const seg = new THREE.Group();
      const z = -i * ENV.segLen;
      seg.position.z = z;
      seg.userData.worldIdx = i;
      seg.userData.zone = zoneForIndex(i);

      // road surface
      const road = new THREE.Mesh(this.geoRoad, this.roadMat);
      road.rotation.x = -Math.PI / 2;
      road.position.set(0, 0, -ENV.segLen / 2);
      road.receiveShadow = true;
      seg.add(road);

      // oncoming carriageway
      const road2 = new THREE.Mesh(this.geoRoad, this.roadMat);
      road2.rotation.x = -Math.PI / 2;
      road2.position.set(13.0, 0, -ENV.segLen / 2);
      seg.add(road2);

      // shoulder / water
      const ground = new THREE.Mesh(this.geoGround, this.grassMat);
      ground.rotation.x = -Math.PI / 2;
      ground.position.set(6, -0.04, -ENV.segLen / 2);
      ground.receiveShadow = true;
      seg.add(ground);
      seg.userData.ground = ground;

      // decor containers
      const decor = new THREE.Group();
      seg.add(decor);
      seg.userData.decor = decor;
      seg.userData.signal = null;

      this.scene.add(seg);
      this.segments.push(seg);
      this._decorate(seg, i);
    }
    this.total = ENV.segLen * ENV.segCount;
  }

  _clearDecor(seg) {
    const decor = seg.userData.decor;
    if (!decor) return;
    for (const child of decor.children.slice()) {
      /* dispose geometry only — materials are shared across every segment */
      child.traverse((o) => { if (o.geometry) o.geometry.dispose(); });
      decor.remove(child);
    }
    seg.userData.signal = null;
  }

  _decorate(seg, worldIdx) {
    this._clearDecor(seg);
    const zone = zoneForIndex(worldIdx);
    seg.userData.zone = zone;
    const decor = seg.userData.decor;
    const rng = AD.seeded(worldIdx * 7919 + 13);
    const z0 = -ENV.segLen / 2;

    const structParts = [];   // building textured geometry
    const propParts = [];     // vertex-colored solid props
    const lampParts = [];     // emissive lamps
    const neonParts = [];     // unlit neon
    const redParts = [], amberParts = [], greenParts = [];

    const add = (parts, geo, color, x, y, z, rx, ry, rz, sx, sy, sz) => {
      parts.push(AD.P(geo, color, x, y, z, rx, ry, rz, sx, sy, sz));
    };

    // ground material per zone
    const ground = seg.userData.ground;
    if (zone === 'BRIDGE') {
      ground.material = this.waterMat;
      ground.position.y = -0.16;
    } else if (zone === 'CITY') {
      ground.material = this.cityGroundMat;
      ground.position.y = -0.04;
    } else if (zone === 'TUNNEL') {
      ground.material = this.cityGroundMat;
      ground.position.y = -0.04;
    } else {
      ground.material = this.grassMat;
      ground.position.y = -0.04;
    }

    // ---- median barrier + rails ----
    add(propParts, new THREE.BoxGeometry(0.6, 0.95, ENV.segLen), 0x6a6e75, ENV.medianX, 0.47, z0);
    add(propParts, new THREE.BoxGeometry(0.16, 0.36, ENV.segLen), 0x9aa0aa, ENV.leftBound - 0.3, 0.66, z0);
    add(propParts, new THREE.BoxGeometry(0.16, 0.36, ENV.segLen), 0x9aa0aa, ENV.farRailX, 0.66, z0);
    for (let p = 0; p < 4; p++) {
      const pz = z0 - p * (ENV.segLen / 4);
      add(propParts, new THREE.BoxGeometry(0.1, 0.8, 0.1), 0x9aa0aa, ENV.leftBound - 0.3, 0.38, pz);
      add(propParts, new THREE.BoxGeometry(0.1, 0.8, 0.1), 0x9aa0aa, ENV.farRailX, 0.38, pz);
    }

    // ---- streetlights (all zones except tunnel) ----
    if (zone !== 'TUNNEL') {
      for (const side of [-1, 1]) {
        const x = side < 0 ? ENV.leftBound - 1.5 : ENV.farRailX + 1.2;
        add(propParts, new THREE.CylinderGeometry(0.08, 0.12, 9, 6), 0x3c4148, x, 4.5, z0);
        add(propParts, new THREE.BoxGeometry(2.2, 0.09, 0.09), 0x3c4148,
          x + (side < 0 ? 1.0 : -1.0), 8.9, z0);
        add(lampParts, new THREE.BoxGeometry(0.8, 0.14, 0.3), 0xffe9b0,
          x + (side < 0 ? 2.0 : -2.0), 8.82, z0);
      }
    }

    // ---- city ----
    if (zone === 'CITY') {
      // sidewalk + curb
      add(propParts, new THREE.BoxGeometry(2.6, 0.18, ENV.segLen), 0x3a3d42, ENV.leftBound - 2.2, 0.09, z0);
      add(propParts, new THREE.BoxGeometry(2.6, 0.18, ENV.segLen), 0x3a3d42, ENV.farRailX + 2.0, 0.09, z0);
      for (let b = 0; b < 3; b++) {
        for (const side of [-1, 1]) {
          if (rng() < 0.18) continue;
          const h = 16 + rng() * 52;
          const w = 9 + rng() * 12;
          const d = 12 + rng() * 10;
          const x = side < 0 ? -(16 + rng() * 26 + w / 2) : (24 + rng() * 26 + w / 2);
          const z = z0 - ENV.segLen * 0.3 + b * ENV.segLen / 3;
          const tint = this.buildingTints[(rng() * this.buildingTints.length) | 0];
          const g = this._boxUV(new THREE.BoxGeometry(w, h, d), w, h, d, 8);
          structParts.push(AD.P(g, tint, x, h / 2, z));
          // rooftop unit
          add(propParts, new THREE.BoxGeometry(w * 0.3, 1.6, d * 0.3), 0x2a2d33, x, h + 0.8, z);
        }
      }
      // neon billboards
      if (rng() < 0.7) {
        const neonCols = [0xff2266, 0x22ddff, 0xffaa22, 0x88ff44, 0xff44aa];
        const board = new THREE.BoxGeometry(7.5, 3.6, 0.35);
        const x = rng() < 0.5 ? -13 : 25;
        const y = 7 + rng() * 7;
        const z = z0 - rng() * 40;
        neonParts.push(AD.P(board, neonCols[(rng() * neonCols.length) | 0], x, y, z, 0, Math.PI / 2, 0));
        add(propParts, new THREE.BoxGeometry(0.25, y, 0.25), 0x25282e, x, y / 2, z);
      }
      // traffic signal gantry every 4 segments
      if (worldIdx % 4 === 1) {
        const gz = z0 - 18;
        add(propParts, new THREE.BoxGeometry(0.16, 6.5, 0.16), 0x34383f, -6.8, 3.25, gz);
        add(propParts, new THREE.BoxGeometry(0.16, 6.5, 0.16), 0x34383f, 6.8, 3.25, gz);
        add(propParts, new THREE.BoxGeometry(13.8, 0.16, 0.16), 0x34383f, 0, 6.4, gz);
        add(propParts, new THREE.BoxGeometry(1.9, 0.55, 0.35), 0x15171c, -2.1, 6.0, gz);
        redParts.push(AD.P(new THREE.SphereGeometry(0.17, 10, 8), 0xffffff, -2.7, 6.0, gz + 0.2));
        amberParts.push(AD.P(new THREE.SphereGeometry(0.17, 10, 8), 0xffffff, -2.1, 6.0, gz + 0.2));
        greenParts.push(AD.P(new THREE.SphereGeometry(0.17, 10, 8), 0xffffff, -1.5, 6.0, gz + 0.2));
      }
    }

    // ---- highway ----
    if (zone === 'HIGHWAY') {
      for (let t = 0; t < 7; t++) {
        const side = rng() < 0.5 ? -1 : 1;
        const x = side < 0 ? -(13 + rng() * 30) : (23 + rng() * 30);
        const z = z0 - rng() * ENV.segLen;
        const s = 0.7 + rng() * 0.8;
        add(propParts, new THREE.CylinderGeometry(0.16 * s, 0.24 * s, 1.8 * s, 5), 0x3a2c1c, x, 0.9 * s, z);
        add(propParts, new THREE.ConeGeometry(1.6 * s, 3.6 * s, 7), 0x1d3a1e, x, 3.0 * s, z);
      }
      // distant hills
      if (worldIdx % 2 === 0) {
        add(propParts, new THREE.ConeGeometry(28 + rng() * 30, 22 + rng() * 18, 7), 0x16201a,
          -90 - rng() * 60, 8, z0 - rng() * 40);
        add(propParts, new THREE.ConeGeometry(30 + rng() * 30, 26 + rng() * 18, 7), 0x16201a,
          100 + rng() * 70, 9, z0 - rng() * 40);
      }
    }

    // ---- tunnel ----
    if (zone === 'TUNNEL') {
      const wallH = 6.2;
      add(propParts, new THREE.BoxGeometry(0.6, wallH, ENV.segLen), 0x2c3038, ENV.leftBound - 1.0, wallH / 2, z0);
      add(propParts, new THREE.BoxGeometry(0.6, wallH, ENV.segLen), 0x2c3038, ENV.farRailX + 1.2, wallH / 2, z0);
      add(propParts, new THREE.BoxGeometry(ENV.farRailX + 3.2, 0.5, ENV.segLen), 0x24272d, 6.4, wallH, z0);
      // ceiling lights
      for (let i = 0; i < 4; i++) {
        add(lampParts, new THREE.BoxGeometry(1.6, 0.1, 0.35), 0xfff2c0, 1.0, wallH - 0.32, z0 - i * 15);
      }
      // portal arches at zone edges
      const prev = zoneForIndex(worldIdx - 1);
      const next = zoneForIndex(worldIdx + 1);
      if (prev !== 'TUNNEL') {
        add(propParts, new THREE.BoxGeometry(1.2, 7.6, 1.2), 0x3a3f48, -6.4, 3.8, z0 + 0.2);
        add(propParts, new THREE.BoxGeometry(1.2, 7.6, 1.2), 0x3a3f48, 19.2, 3.8, z0 + 0.2);
        add(propParts, new THREE.BoxGeometry(27, 1.2, 1.2), 0x3a3f48, 6.4, 7.4, z0 + 0.2);
      }
      if (next !== 'TUNNEL') {
        add(propParts, new THREE.BoxGeometry(1.2, 7.6, 1.2), 0x3a3f48, -6.4, 3.8, z0 - ENV.segLen);
        add(propParts, new THREE.BoxGeometry(1.2, 7.6, 1.2), 0x3a3f48, 19.2, 3.8, z0 - ENV.segLen);
        add(propParts, new THREE.BoxGeometry(27, 1.2, 1.2), 0x3a3f48, 6.4, 7.4, z0 - ENV.segLen);
      }
    }

    // ---- bridge ----
    if (zone === 'BRIDGE') {
      // deck edge beams
      add(propParts, new THREE.BoxGeometry(0.4, 1.2, ENV.segLen), 0x6f747c, ENV.leftBound - 1.0, 0.1, z0);
      add(propParts, new THREE.BoxGeometry(0.4, 1.2, ENV.segLen), 0x6f747c, ENV.farRailX + 1.0, 0.1, z0);
      for (let i = 0; i < 5; i++) {
        add(propParts, new THREE.BoxGeometry(0.12, 1.1, 0.12), 0x9aa0aa, ENV.leftBound - 0.3, 1.0, z0 - i * 12);
        add(propParts, new THREE.BoxGeometry(0.12, 1.1, 0.12), 0x9aa0aa, ENV.farRailX, 1.0, z0 - i * 12);
      }
      // suspension towers
      if (worldIdx % 2 === 0) {
        for (const x of [-7.4, 20.6]) {
          add(propParts, new THREE.BoxGeometry(1.4, 18, 1.4), 0x8a9099, x, 9, z0);
          add(propParts, new THREE.BoxGeometry(0.9, 1.0, 1.0), 0x8a9099, x, 17.4, z0);
        }
        add(propParts, new THREE.BoxGeometry(29.4, 0.8, 0.8), 0x8a9099, 6.6, 17.2, z0);
        // cables
        for (let i = 0; i < 6; i++) {
          const dz = 4 + i * 8;
          const a = new THREE.Vector3(-7.4, 17.0, z0);
          const b = new THREE.Vector3(-4.6, 0.8, z0 - dz);
          propParts.push(this._cable(a, b, 0.035, 0x4a4f58));
          const c = new THREE.Vector3(20.6, 17.0, z0);
          const d = new THREE.Vector3(17.2, 0.8, z0 - dz);
          propParts.push(this._cable(c, d, 0.035, 0x4a4f58));
        }
      }
    }

    // ---- build merged meshes ----
    const addMerged = (parts, mat) => {
      if (!parts.length) return;
      const m = new THREE.Mesh(AD.merge(parts), mat);
      decor.add(m);
    };
    addMerged(structParts, this.buildingMat);
    addMerged(propParts, this.propsMat);
    addMerged(lampParts, this.lampMat);
    addMerged(neonParts, this.neonMat);
    if (redParts.length) {
      const sig = new THREE.Group();
      const r = new THREE.Mesh(AD.merge(redParts), this.sigRed);
      const a = new THREE.Mesh(AD.merge(amberParts), this.sigAmber);
      const g = new THREE.Mesh(AD.merge(greenParts), this.sigGreen);
      sig.add(r, a, g);
      decor.add(sig);
      seg.userData.signal = sig;
    }
  }

  _cable(a, b, r, color) {
    const dir = new THREE.Vector3().subVectors(b, a);
    const len = dir.length();
    const g = new THREE.CylinderGeometry(r, r, len, 4);
    const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.clone().normalize());
    g.applyQuaternion(q);
    g.translate((a.x + b.x) / 2, (a.y + b.y) / 2, (a.z + b.z) / 2);
    return { geo: g, color };
  }

  /* ================= RAIN ================= */
  _buildRain() {
    this.rainCount = 1300;
    const pos = new Float32Array(this.rainCount * 2 * 3);
    this._rainX = new Float32Array(this.rainCount);
    this._rainY = new Float32Array(this.rainCount);
    this._rainZ = new Float32Array(this.rainCount);
    this._rainS = new Float32Array(this.rainCount);
    for (let i = 0; i < this.rainCount; i++) {
      this._rainX[i] = AD.rand(-40, 40);
      this._rainY[i] = AD.rand(0, 30);
      this._rainZ[i] = AD.rand(-40, 40);
      this._rainS[i] = AD.rand(32, 48);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    this.rainGeo = geo;
    this.rain = new THREE.LineSegments(geo, new THREE.LineBasicMaterial({
      color: 0xa8c8e8, transparent: true, opacity: 0.32, depthWrite: false,
    }));
    this.rain.frustumCulled = false;
    this.scene.add(this.rain);
  }

  /* ================= SETTINGS ================= */
  setWeather(name) {
    if (!WEATHER[name]) name = 'clear';
    this.weatherName = name;
    const w = WEATHER[name];
    this._weather = w;
    this.rainAmount = w.rain;
    this.wet = w.wet;
  }

  setTime(hours) {
    this.timeOfDay = ((hours % 24) + 24) % 24;
    this.autoTime = false;
    this._updateSky(true);
  }

  /* ================= UPDATE ================= */
  update(dt, playerPos, cameraPos) {
    if (this.autoTime) {
      this.timeOfDay = (this.timeOfDay + dt * 0.045) % 24;
    }
    this._updateSky(false);

    // recycle
    const pz = playerPos ? playerPos.z : 0;
    const behindZ = pz + ENV.segLen * 1.6;
    for (const seg of this.segments) {
      if (seg.position.z > behindZ) {
        seg.position.z -= this.total;
        const idx = Math.round(-seg.position.z / ENV.segLen);
        seg.userData.worldIdx = idx;
        this._decorate(seg, idx);
      }
    }

    /* cull segments that sit far beyond the fog — recycling still runs above,
       so they reappear fully built when the player gets close. */
    const visAhead = 800;
    const visBehind = 150;
    for (const seg of this.segments) {
      const sz = seg.position.z;
      seg.visible = sz <= pz + visBehind && sz >= pz - visAhead;
    }

    // sky follows player
    const px = playerPos ? playerPos.x : 0;
    const cz = cameraPos ? cameraPos.z : pz;
    this.sky.position.set(px, 0, cz);
    this.stars.position.set(px, 0, cz);
    this.sunSprite.position.set(px + this._sunDir.x * 620, this._sunDir.y * 620, cz + this._sunDir.z * 620);
    this.moonSprite.position.set(px - this._sunDir.x * 620, -this._sunDir.y * 620, cz - this._sunDir.z * 620);

    // shadow rig follows player
    this.sun.position.set(px + this._sunDir.x * 110, Math.max(18, this._sunDir.y * 110), pz + this._sunDir.z * 110 - 20);
    this.sun.target.position.set(px, 0, pz - 10);
    this.sun.target.updateMatrixWorld();

    // signal phases
    const phase = (performance.now() / 1000) % 12;
    this.sigGreen.emissiveIntensity = phase < 6 ? 3.2 : 0.08;
    this.sigAmber.emissiveIntensity = phase >= 6 && phase < 7.5 ? 3.2 : 0.08;
    this.sigRed.emissiveIntensity = phase >= 7.5 ? 3.2 : 0.08;

    // rain
    this._updateRain(dt, px, pz);

    // ground follows
    this.ground.position.z = pz - 1500;

    // wet road
    const wet = this.wet;
    this.roadMat.roughness = 0.92 - wet * 0.55;
    this.roadMat.metalness = wet * 0.32;
    this.roadMat.envMapIntensity = 0.15 + wet * 1.1;

    // lightning in storms
    if (this.weatherName === 'storm') {
      this._lastFlash -= dt;
      if (this._lastFlash <= 0) {
        this._lastFlash = AD.rand(4, 11);
        this._flash = 0.5;
      }
    }
    if (this._flash > 0) {
      this._flash -= dt * 3.5;
      this.sun.intensity += this._flash * 2.2;
      this.hemi.intensity += this._flash * 1.2;
    }
  }

  _updateSky(force) {
    const t = this.timeOfDay;
    const angle = ((t - 6) / 12) * Math.PI;
    const elev = Math.sin(angle);
    const dayF = AD.clamp(elev, 0, 1);
    const nightF = AD.clamp(-elev, 0, 1);
    const duskF = AD.clamp(1 - Math.abs(elev) * 3.2, 0, 1);
    const weather = this._weather || WEATHER.clear;
    const dim = weather.dim;
    this.night = nightF;

    const sunDir = this._sunDir || new THREE.Vector3();
    sunDir.set(Math.cos(angle) * 0.72, Math.max(-0.6, elev), -0.42).normalize();
    this._sunDir = sunDir;

    const cTop = new THREE.Color(0x050814).lerp(new THREE.Color(0x2b6fd6), dayF);
    cTop.lerp(new THREE.Color(0x3a2a5a), duskF * 0.55);
    const cMid = new THREE.Color(0x0a1230).lerp(new THREE.Color(0x87b8ef), dayF);
    cMid.lerp(new THREE.Color(0xb05a6a), duskF * 0.65);
    const cBot = new THREE.Color(0x131a2e).lerp(new THREE.Color(0xd8e6f5), dayF);
    cBot.lerp(new THREE.Color(0xff9a5a), duskF * 0.75);

    if (weather.name === 'Rain' || weather.name === 'Storm') {
      cTop.lerp(new THREE.Color(0x2a3540), 0.6);
      cMid.lerp(new THREE.Color(0x3f4c58), 0.6);
      cBot.lerp(new THREE.Color(0x6a7884), 0.6);
    } else if (weather.name === 'Fog') {
      cTop.lerp(new THREE.Color(0x6a7280), 0.5);
      cMid.lerp(new THREE.Color(0x8a929e), 0.5);
      cBot.lerp(new THREE.Color(0xaab0ba), 0.5);
    }

    this.skyUniforms.topColor.value.copy(cTop);
    this.skyUniforms.midColor.value.copy(cMid);
    this.skyUniforms.bottomColor.value.copy(cBot);
    this.skyUniforms.sunDir.value.copy(sunDir);
    this.skyUniforms.sunColor.value.setHex(duskF > 0.35 ? 0xff9a5a : 0xfff0c8);
    this.skyUniforms.sunAmt.value = 0.25 + dayF * 0.9 + duskF * 0.8;

    const sunLightColor = new THREE.Color(0xff9a5a).lerp(new THREE.Color(0xfff2d8), dayF);
    this.sun.color.copy(sunLightColor);
    this.sun.intensity = (0.12 + dayF * 2.0 + duskF * 0.55) * dim;
    this.hemi.color.copy(cMid);
    this.hemi.groundColor.setHex(0x1a1410);
    this.hemi.intensity = (0.18 + dayF * 0.75 + duskF * 0.3) * dim;
    this.ambient.intensity = 0.1 + dayF * 0.16;

    // moon light at night
    if (nightF > 0.2) {
      this.sun.intensity = Math.max(this.sun.intensity, nightF * 0.28);
      this.sun.color.lerp(new THREE.Color(0x9db8e8), nightF * 0.8);
    }

    this.stars.material.opacity = nightF * 0.9;
    this.stars.visible = nightF > 0.04;
    this.sunSprite.material.opacity = AD.clamp(elev * 2 + 0.5, 0, 1) * 0.85;
    this.moonSprite.material.opacity = nightF * 0.7;
    this.lampMat.emissiveIntensity = 0.35 + nightF * 3.2;
    this.buildingMat.emissiveIntensity = 0.18 + nightF * 1.35;

    const fogCol = cBot.clone().lerp(new THREE.Color(0x8892a0), weather.name === 'Fog' ? 0.7 : 0.25);
    if (nightF > 0.4) fogCol.lerp(new THREE.Color(0x0c1220), nightF * 0.55);
    this.scene.fog.color.copy(fogCol);
    this.scene.fog.near = weather.fogNear;
    this.scene.fog.far = weather.fogFar * (0.7 + dayF * 0.3);
    this.scene.background = null;
  }

  _updateRain(dt, px, pz) {
    const amount = this.rainAmount;
    const active = amount > 0.01;
    this.rain.visible = active;
    if (!active) return;
    const arr = this.rainGeo.attributes.position.array;
    const speed = 42;
    for (let i = 0; i < this.rainCount; i++) {
      this._rainY[i] -= speed * dt;
      this._rainX[i] -= 4 * dt;
      if (this._rainY[i] < 0) {
        this._rainY[i] = AD.rand(22, 34);
        this._rainX[i] = AD.rand(-42, 42);
        this._rainZ[i] = AD.rand(-42, 42);
      }
      const x = px + this._rainX[i];
      const y = this._rainY[i];
      const z = pz + this._rainZ[i];
      arr[i * 6] = x;
      arr[i * 6 + 1] = y;
      arr[i * 6 + 2] = z;
      arr[i * 6 + 3] = x + 0.06;
      arr[i * 6 + 4] = y + 1.3;
      arr[i * 6 + 5] = z;
    }
    this.rainGeo.attributes.position.needsUpdate = true;
    this.rain.material.opacity = 0.18 + amount * 0.22;
  }

  /* ================= QUERIES ================= */
  zoneAt(z) {
    const idx = Math.round(-z / ENV.segLen);
    return zoneForIndex(idx);
  }

  nearestLane(x) {
    let best = ENV.lanes[0], bd = 1e9;
    for (const l of ENV.lanes) {
      const d = Math.abs(l - x);
      if (d < bd) { bd = d; best = l; }
    }
    return best;
  }

  get gripMul() {
    return 1 - this.wet * 0.18;
  }
}
