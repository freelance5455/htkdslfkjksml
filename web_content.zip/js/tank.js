// ===== wrecks, repairable player tank, floating markers =====
const wrecks = [];
let PT = null;
const marks = new Map();

function repairTank() {
  if (PT || !wrecks.length) return false;
  let bi = 0, bd = 1e9; wrecks.forEach((w, i) => { const d = Math.hypot(w.x - P.pos.x, w.z - P.pos.z); if (d < bd) { bd = d; bi = i; } });
  const w = wrecks.splice(bi, 1)[0];
  w.mats[0].color.setHex(0x5f7a3e); w.mats[1].color.setHex(0x23241f);
  PT = { g: w.g, turret: w.turret, x: w.x, z: w.z, yaw: w.yaw, tyaw: w.tyaw, hp: tankMaxHp(), maxHp: tankMaxHp(), cd: 0, mg: 0, v: 0, nitro: 0, nitroCd: 0, fixCd: 0, ap: false };
  PT.g.position.set(w.x, 0, w.z); PT.g.rotation.y = w.yaw; PT.g.visible = true;
  message('TANK ONARILDI', 'E İLE BİN');
  return true;
}
function tankNear() { return !!PT && !P.inTank && !P.dead && Math.hypot(P.pos.x - PT.x, P.pos.z - PT.z) < 6.5; }
function enterTank() {
  if (!tankNear()) return; P.inTank = true; P.trigger = false; P.adsHeld = false; P.yaw = PT.tyaw - Math.PI; P.pitch = 0; P.vx = P.vz = 0; PT.fp = false;
  setFov(75); $('cross').style.opacity = 1; SND.pickup();
}
function exitTank() {
  if (!P.inTank) return; P.inTank = false; P.trigger = false; P.adsHeld = false;
  PT.g.visible = true; $('tankfp').style.opacity = 0; reloadBar(-1); setFov(75);
  const a = PT.yaw + Math.PI / 2; P.pos.set(PT.x + Math.sin(a) * 4, 0, PT.z + Math.cos(a) * 4); moveEntity(P.pos, 0, 0, .42, 0);
  hudAmmo();
}
function clearTanks() { for (const w of wrecks) scene.remove(w.g); wrecks.length = 0; if (PT) { scene.remove(PT.g); PT = null; } P.inTank = false; for (const [k, m] of marks) m.remove(); marks.clear(); }
function destroyPlayerTank() {
  const t = PT; $('tankfp').style.opacity = 0; reloadBar(-1); explode(t.x, 1.5, t.z, 9, 0, 'enemy'); scene.remove(t.g); PT = null;
  if (P.inTank) { exitTank(); P.pos.set(t.x + 3, 0, t.z); damagePlayer(20); }
  message('TANKIN YOK EDİLDİ', '');
}
function tankHit(d) {
  PT.hp -= d * .6; P.shake += .25; SND.hurt(); flashHurt(.5);
  if (PT.hp <= 0) destroyPlayerTank();
}
function tankMaxHp() { return 600 + 150 * P.up.tank.arm; }
function setFov(f) { if (Math.abs(camera.fov - f) > .05) { camera.fov = f; camera.updateProjectionMatrix(); PSU.uScale.value = renderer.domElement.height / (2 * Math.tan(THREE.MathUtils.degToRad(f) / 2)); } }
function tankRepairKit() {
  const t = PT; if (!t || !P.inTank) return;
  if (t.fixCd > 0) { feedLine('TAMİR HAZIR DEĞİL ' + Math.ceil(t.fixCd) + ' sn', ''); return; }
  if (t.hp >= t.maxHp) return;
  t.hp = Math.min(t.maxHp, t.hp + t.maxHp * .35); t.fixCd = 25; SND.pickup(); feedLine('TANK ONARILDI +%35', '');
  for (let i = 0; i < 12; i++) glow.emit(t.x + rand(-1.5, 1.5), 2, t.z + rand(-2, 2), 0, rand(2, 4), 0, .6, .5, .1, [.5, 1, .6], [.2, .8, .3], .9, 0, 0, 1);
}
function tankToggleAmmo() { if (PT && P.inTank) { PT.ap = !PT.ap; feedLine(PT.ap ? 'ZIRH DELİCİ MERMİ' : 'YÜKSEK PATLAYICI MERMİ', ''); SND.reload(); } }
function tankDrive(dt) {
  const t = PT; updateAim(); t.maxHp = tankMaxHp();
  if (mouse.free && !isTouch) { P.yaw -= (Math.abs(mouse.nx) > .12 ? mouse.nx : 0) * 2.2 * dt; P.pitch -= (Math.abs(mouse.ny) > .12 ? mouse.ny : 0) * 1.4 * dt; }
  P.yaw -= lookDX; P.pitch -= lookDY; lookDX = lookDY = 0; P.pitch = clamp(P.pitch, -.45, .55);
  P.shake = Math.max(0, P.shake - dt * 3); t.cd = Math.max(0, t.cd - dt); t.mg = Math.max(0, t.mg - dt); t.nitro = Math.max(0, (t.nitro || 0) - dt); t.nitroCd = Math.max(0, (t.nitroCd || 0) - dt); t.fixCd = Math.max(0, (t.fixCd || 0) - dt);
  const fp = !!t.fp;
  if (K.Space && t.nitroCd <= 0) { t.nitro = 2.5; t.nitroCd = 14; SND.alert(); message('NİTRO', ''); }
  const fi = (K.KeyW || K.ArrowUp ? 1 : 0) - (K.KeyS || K.ArrowDown ? 1 : 0) - touchIn.my, si = (K.KeyD || K.ArrowRight ? 1 : 0) - (K.KeyA || K.ArrowLeft ? 1 : 0) + touchIn.mx;
  t.yaw -= si * 1.1 * dt * (fi < 0 ? -1 : 1);
  t.v += (fi * 6.5 * (t.nitro > 0 ? 1.9 : 1) - t.v) * Math.min(1, dt * 1.6);
  const tmp = { x: t.x, z: t.z }; moveEntity(tmp, Math.sin(t.yaw) * t.v * dt, Math.cos(t.yaw) * t.v * dt, 2.4, 0, true); t.x = tmp.x; t.z = tmp.z;
  if (t.nitro > 0 && Math.abs(t.v) > 3) for (let i = 0; i < 2; i++) glow.emit(t.x - Math.sin(t.yaw) * 3.4 + rand(-.8, .8), 1, t.z - Math.cos(t.yaw) * 3.4 + rand(-.8, .8), 0, rand(.5, 1.5), 0, .35, 1, .2, C_FIRE0, C_FIRE1, .9, 0, 0, 1);
  t.tyaw = P.yaw + Math.PI;
  t.g.position.set(t.x, 0, t.z); t.g.rotation.y = t.yaw; t.turret.rotation.y = t.tyaw - t.yaw; t.g.visible = !fp;
  P.pos.set(t.x, 0, t.z); P.vx = Math.sin(t.yaw) * t.v; P.vz = Math.cos(t.yaw) * t.v;
  const cp = Math.cos(P.pitch), dir = new THREE.Vector3(-Math.sin(P.yaw) * cp, Math.sin(P.pitch), -Math.cos(P.yaw) * cp), sh = P.shake * .05;
  if (fp) camera.position.set(t.x + dir.x * .4 + (Math.random() - .5) * sh, 2.45 + (Math.random() - .5) * sh, t.z + dir.z * .4);
  else camera.position.set(t.x - dir.x * 9 + (Math.random() - .5) * sh, Math.max(1.2, 3.6 - dir.y * 9), t.z - dir.z * 9);
  camera.rotation.set(fp ? P.pitch : P.pitch - .04, P.yaw, 0); setFov(fp ? 52 : 75);
  $('tankfp').style.opacity = fp ? 1 : 0;
  const res = castRay(camera.position, dir, 300, false, true), at = res ? res.t : 150;
  const aim = camera.position.clone().addScaledVector(dir, at), mo = new THREE.Vector3(t.x + Math.sin(t.tyaw) * 5.2, 2.0, t.z + Math.cos(t.tyaw) * 5.2);
  const rld = 2.2 * (1 - .1 * P.up.tank.rld), gm = 1 + .15 * P.up.tank.gun;
  if (P.trigger && t.cd <= 0) {
    t.cd = rld; const d = aim.clone().sub(mo).normalize(); spawnRocket(mo, d, 'player', t.ap ? 120 : 85, true);
    const pr = proj[proj.length - 1]; pr.ap = !!t.ap; pr.dm = gm;
    SND.shot('tank'); muzzleFx(mo.x, mo.y, mo.z, 3); P.shake += .6; smoke.emit(mo.x, mo.y, mo.z, 0, .5, 0, 1.2, 1, 3, C_SMOKE1, C_SMOKE1, .5, 0, 0, 1);
  }
  if (P.adsHeld && t.mg <= 0) {
    t.mg = .085; const d = aim.clone().sub(mo).normalize(); d.x += rand(-.015, .015); d.y += rand(-.015, .015); d.z += rand(-.015, .015); d.normalize();
    const r = castRay(mo, d, 300, false, true), tt = r ? r.t : 300, ex = mo.x + d.x * tt, ey = mo.y + d.y * tt, ez = mo.z + d.z * tt;
    tracer(mo.x, mo.y, mo.z, ex, ey, ez, 0xffd48a, 320); SND.shot('mg');
    if (r && r.kind === 'enemy') { hurtEnemy(r.e, 16 * gm * P.dmgMult * (r.e.type === 'tank' ? .2 : r.head ? 2.6 : 1), { head: r.head, from: mo }); hitMarker(r.head, r.e.dead); if (r.e.type !== 'tank') bloodPuff(ex, ey, ez); else sparks(ex, ey, ez, 3, 4); }
    else if (r) impactFx({ x: ex, y: ey, z: ez }, r, d);
  }
  $('scope').style.opacity = 0; $('rdot').style.opacity = 0; VMS.forEach(v => v.visible = false);
  setT(H.wn, 'TANK · ZIRH ' + Math.ceil(t.hp) + '/' + t.maxHp); H.ammo.innerHTML = (t.ap ? 'DELİCİ ' : 'HE ') + '<span>' + (t.cd > 0 ? t.cd.toFixed(1) + ' sn' : 'HAZIR') + '</span>';
  setT(H.gren, 'NİTRO ' + (t.nitroCd > 0 ? Math.ceil(t.nitroCd) + 'sn' : 'HAZIR') + ' · TAMİR ' + (t.fixCd > 0 ? Math.ceil(t.fixCd) + 'sn' : 'HAZIR'));
  if (t.cd > 0) reloadBar(t.cd / rld, t.cd.toFixed(1) + ' sn'); else reloadBar(-1);
  $('cross').style.setProperty('--g', '14px');
}
function updateWrecks(dt) {
  for (const w of wrecks) {
    w.t += dt; if (w.t > 40) continue;
    if (Math.random() < dt * 8) { glow.emit(w.x + rand(-1.5, 1.5), 2.2, w.z + rand(-2, 2), 0, rand(1, 3), 0, .7, 1.4, .3, C_FIRE0, C_FIRE1, .9, 0, -1, 1); }
    if (Math.random() < dt * 5) smoke.emit(w.x + rand(-1, 1), 2.4, w.z + rand(-1, 1), rand(-.3, .3), rand(1.5, 3), rand(-.3, .3), 3, 1.2, 5, C_SMOKE0, C_SMOKE1, .6, 0, -.3, .3);
  }
}
const _mv = new THREE.Vector3();
function updateMarks() {
  const list = [];
  for (const e of enemies) {
    if (e.dead) continue;
    if (e.type === 'tank') list.push({ key: e, x: e.x, z: e.z, y: 3.8, hp: e.hp / e.maxHp, label: 'TANK', cls: '', edge: true });
    else list.push({ key: e, x: e.x, z: e.z, y: e.type === 'heavy' ? 2.5 : 2.15, hp: e.hp / e.maxHp, label: '', cls: 'sm' + (e.type === 'sniper' ? ' snip' : ''), max: 55 });
  }
  if (PT && !P.inTank) list.push({ key: PT, x: PT.x, z: PT.z, y: 3.8, hp: PT.hp / PT.maxHp, label: 'TANKIN · E', cls: 'friend', edge: true });
  if (airdrop) list.push({ key: airdrop, x: airdrop.x, z: airdrop.z, y: 3, hp: -1, label: 'İKRAM · E', cls: 'friend', edge: true });
  for (const w of wrecks) list.push({ key: w, x: w.x, z: w.z, y: 3.8, hp: -1, label: 'YIKIK TANK', cls: 'friend' });
  const keys = new Set(list.map(l => l.key)), W = canvas.clientWidth, Hh = canvas.clientHeight;
  for (const [k, el] of marks) if (!keys.has(k)) { el.remove(); marks.delete(k); }
  for (const l of list) {
    let el = marks.get(l.key);
    if (!el) { el = document.createElement('div'); el.className = 'mk ' + l.cls; el.innerHTML = '<i>▼</i><span class="t"></span><span class="bar"><u></u></span>'; $('marks').appendChild(el); marks.set(l.key, el); }
    const d = Math.hypot(l.x - P.pos.x, l.z - P.pos.z); _mv.set(l.x, l.y, l.z).project(camera);
    let sx = (_mv.x * .5 + .5) * W, sy = (-_mv.y * .5 + .5) * Hh, rot = 0, onEdge = false;
    const behind = _mv.z > 1, out = behind || sx < 20 || sx > W - 20 || sy < 40 || sy > Hh - 20;
    let vis = d < (l.max || 170) && !(P.inTank && l.key === PT);
    if (vis && out) {
      if (l.edge) {
        let ax = _mv.x, ay = _mv.y; if (behind) { ax = -ax; ay = -ay; if (Math.abs(ax) < .01 && Math.abs(ay) < .01) ay = -1; }
        const m = Math.max(Math.abs(ax) / .88, Math.abs(ay) / .8, 1e-6); ax /= m; ay /= m;
        sx = (ax * .5 + .5) * W; sy = (-ay * .5 + .5) * Hh; rot = Math.atan2(ax, ay) * 180 / Math.PI; onEdge = true;
      } else vis = false;
    }
    el.style.display = vis ? '' : 'none'; if (!vis) continue;
    el.style.transform = onEdge ? `translate(${sx}px,${sy}px) translate(-50%,-50%)` : `translate(${sx}px,${sy}px) translate(-50%,-100%)`;
    el.firstChild.style.transform = onEdge ? `rotate(${rot}deg)` : '';
    el.firstChild.style.display = l.cls.indexOf('sm') >= 0 ? 'none' : '';
    const t = el.children[1], txt = l.label ? l.label + ' · ' + Math.round(d) + 'm' : ''; if (t._t !== txt) { t.textContent = txt; t._t = txt; }
    const bar = el.children[2]; bar.style.display = l.hp < 0 ? 'none' : ''; if (l.hp >= 0) bar.firstChild.style.width = Math.max(0, l.hp * 100) + '%';
  }
}
