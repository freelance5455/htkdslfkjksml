"use strict";

/* ---------- تخزين آمن ---------- */
const Store = (() => {
  let prefix = "mafia_elite_";

  function setPrefix(value) {
    prefix = value;
  }

  function get(key, fallback) {
    try {
      const raw = localStorage.getItem(prefix + key);
      return raw === null ? fallback : JSON.parse(raw);
    } catch (error) {
      return fallback;
    }
  }

  function set(key, value) {
    try {
      localStorage.setItem(prefix + key, JSON.stringify(value));
      return true;
    } catch (error) {
      return false;
    }
  }

  function remove(key) {
    try {
      localStorage.removeItem(prefix + key);
    } catch (error) {
      /* تجاهل */
    }
  }

  return { setPrefix, get, set, remove };
})();

/* ---------- تفضيلات التطبيق ---------- */
const Prefs = (() => {
  const DEFAULTS = { sound: true, volume: 70, animations: true, speed: "normal" };
  const SPEEDS = { slow: 0.7, normal: 0.4, fast: 0.2 };
  let current = null;

  function sanitize(raw) {
    const out = { ...DEFAULTS };
    if (raw && typeof raw === "object") {
      if (typeof raw.sound === "boolean") out.sound = raw.sound;
      if (Number.isFinite(raw.volume)) out.volume = Math.min(100, Math.max(0, Math.round(raw.volume)));
      if (typeof raw.animations === "boolean") out.animations = raw.animations;
      if (Object.prototype.hasOwnProperty.call(SPEEDS, raw.speed)) out.speed = raw.speed;
    }
    return out;
  }

  function apply() {
    if (!document.body) return;
    document.body.classList.toggle("no-anim", !current.animations);
    document.documentElement.style.setProperty("--speed", SPEEDS[current.speed] + "s");
  }

  function load() {
    current = sanitize(Store.get("prefs", null));
    apply();
    return current;
  }

  function get() {
    if (!current) load();
    return current;
  }

  function set(patch) {
    current = sanitize({ ...get(), ...patch });
    Store.set("prefs", current);
    apply();
    return current;
  }

  function reset() {
    Store.remove("prefs");
    current = sanitize(null);
    apply();
    return current;
  }

  return { load, get, set, reset };
})();

/* ---------- الإحصائيات ---------- */
const Stats = (() => {
  const KEY = "stats";
  const MAX_HISTORY = 30;

  function empty() {
    return {
      games: 0,
      townWins: 0,
      mafiaWins: 0,
      neutralWins: 0,
      draws: 0,
      mafiaRoleCount: 0,
      roleCounts: {},
      history: [],
    };
  }

  function num(value) {
    return Number.isFinite(value) && value >= 0 ? Math.floor(value) : 0;
  }

  function sanitize(raw) {
    const out = empty();
    if (!raw || typeof raw !== "object") return out;
    ["games", "townWins", "mafiaWins", "neutralWins", "draws", "mafiaRoleCount"].forEach((key) => {
      out[key] = num(raw[key]);
    });
    if (raw.roleCounts && typeof raw.roleCounts === "object") {
      Object.keys(raw.roleCounts).forEach((id) => {
        if (Roles.get(id)) out.roleCounts[id] = num(raw.roleCounts[id]);
      });
    }
    if (Array.isArray(raw.history)) {
      out.history = raw.history
        .filter((h) => h && typeof h === "object")
        .slice(0, MAX_HISTORY)
        .map((h) => ({
          date: num(h.date),
          players: num(h.players),
          winner: typeof h.winner === "string" ? h.winner : "none",
          rounds: num(h.rounds),
        }));
    }
    return out;
  }

  function get() {
    return sanitize(Store.get(KEY, null));
  }

  function record(summary, winner) {
    const stats = get();
    stats.games += 1;
    if (winner === "town") stats.townWins += 1;
    else if (winner === "mafia") stats.mafiaWins += 1;
    else if (winner === "lone_killer" || winner === "clown") stats.neutralWins += 1;
    else stats.draws += 1;

    summary.roles.forEach((id) => {
      stats.roleCounts[id] = (stats.roleCounts[id] || 0) + 1;
      if (Roles.get(id).team === "mafia") stats.mafiaRoleCount += 1;
    });

    stats.history.unshift({
      date: Date.now(),
      players: summary.playerCount,
      winner,
      rounds: summary.rounds,
    });
    stats.history = stats.history.slice(0, MAX_HISTORY);
    Store.set(KEY, stats);
    return stats;
  }

  // تُسجَّل كل لعبة منتهية مرة واحدة فقط (والإنهاء اليدوي لا يُسجَّل)
  function recordFromGame() {
    const result = Game.getResult();
    if (!result || result.forced) return false;
    if (!Game.markRecorded()) return false;
    const summary = Game.getMatchSummary();
    if (!summary) return false;
    record(summary, result.winner);
    return true;
  }

  function clear() {
    Store.remove(KEY);
  }

  return { get, record, recordFromGame, clear };
})();

/* ---------- حفظ اللعبة ---------- */
const Saver = (() => {
  const KEY = "save";
  const CHECKPOINTS = [
    "reveal-handover",
    "reveal-done",
    "night-intro",
    "night-dawn",
    "day-discussion",
    "day-result",
  ];

  function save() {
    const data = Game.exportState();
    if (!data) return false;
    return Store.set(KEY, { version: 1, savedAt: Date.now(), data });
  }

  function load() {
    const pack = Store.get(KEY, null);
    return pack && pack.version === 1 && pack.data ? pack.data : null;
  }

  function exists() {
    return load() !== null;
  }

  function clear() {
    Store.remove(KEY);
  }

  // حفظ تلقائي عند الشاشات العامة فقط، ومسح الحفظ عند نهاية اللعبة
  function onScreen(name) {
    if (name === "win") {
      clear();
      return;
    }
    if (CHECKPOINTS.includes(name) && Game.hasActiveMatch()) save();
  }

  return { save, load, exists, clear, onScreen };
})();