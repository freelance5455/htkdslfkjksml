
const STORAGE_KEY = "sanawy_plus_data";

const DB_NAME = "SanawyPlusFiles";
const DB_VERSION = 1;
const STORE_NAME = "attachments";

// البيانات الافتراضية
function getDefaultData() {
    return {
        user: null,
        subjects: [],
        achievements: [],
        points: 0,
        settings: {
            theme: "dark"
        }
    };
}

// قراءة البيانات المحفوظة
function getData() {
    try {
        const saved = JSON.parse(
            localStorage.getItem(STORAGE_KEY)
        );

        if (!saved || typeof saved !== "object") {
            return getDefaultData();
        }

        return {
            user: saved.user || null,

            subjects: Array.isArray(saved.subjects)
                ? saved.subjects
                : [],

            achievements: Array.isArray(saved.achievements)
                ? saved.achievements
                : [],

            points: Number(saved.points) || 0,

            settings: {
                theme: saved.settings?.theme || "dark"
            }
        };

    } catch (error) {
        console.error("Data loading error:", error);
        return getDefaultData();
    }
}

// حفظ البيانات تلقائيًا
function saveData(data) {
    try {
        localStorage.setItem(
            STORAGE_KEY,
            JSON.stringify(data)
        );

        return true;

    } catch (error) {
        console.error("Data saving error:", error);

        if (typeof notify === "function") {
            notify("تعذر حفظ البيانات. مساحة التخزين قد تكون ممتلئة.");
        }

        return false;
    }
}

// ================================
// قاعدة بيانات المرفقات
// ================================

// فتح قاعدة بيانات الملفات
function openFilesDB() {
    return new Promise((resolve, reject) => {
        if (!("indexedDB" in window)) {
            reject(new Error("IndexedDB غير مدعوم في هذا المتصفح"));
            return;
        }

        const request = indexedDB.open(
            DB_NAME,
            DB_VERSION
        );

        request.onupgradeneeded = () => {
            const db = request.result;

            if (!db.objectStoreNames.contains(STORE_NAME)) {
                db.createObjectStore(STORE_NAME, {
                    keyPath: "id"
                });
            }
        };

        request.onsuccess = () => {
            resolve(request.result);
        };

        request.onerror = () => {
            reject(request.error);
        };

        request.onblocked = () => {
            reject(new Error("قاعدة البيانات مشغولة"));
        };
    });
}

// ================================
// حفظ المرفقات
// ================================

async function saveAttachment(id, file) {
    const db = await openFilesDB();

    return new Promise((resolve, reject) => {
        const transaction = db.transaction(
            STORE_NAME,
            "readwrite"
        );

        transaction.objectStore(STORE_NAME).put({
            id,
            name: file.name,
            type: file.type,
            size: file.size,
            file
        });

        transaction.oncomplete = () => {
            db.close();
            resolve(true);
        };

        transaction.onerror = () => {
            const error = transaction.error;

            db.close();
            reject(error);
        };

        transaction.onabort = () => {
            const error = transaction.error;

            db.close();
            reject(error || new Error("تم إلغاء حفظ الملف"));
        };
    });
}

// ================================
// قراءة المرفقات
// ================================

async function getAttachment(id) {
    const db = await openFilesDB();

    return new Promise((resolve, reject) => {
        const transaction = db.transaction(
            STORE_NAME,
            "readonly"
        );

        const request = transaction
            .objectStore(STORE_NAME)
            .get(id);

        request.onsuccess = () => {
            resolve(request.result || null);
        };

        request.onerror = () => {
            reject(request.error);
        };

        transaction.oncomplete = () => {
            db.close();
        };

        transaction.onerror = () => {
            db.close();
            reject(transaction.error);
        };
    });
}

// ================================
// حذف المرفقات
// ================================

async function deleteAttachment(id) {
    const db = await openFilesDB();

    return new Promise((resolve, reject) => {
        const transaction = db.transaction(
            STORE_NAME,
            "readwrite"
        );

        transaction.objectStore(STORE_NAME).delete(id);

        transaction.oncomplete = () => {
            db.close();
            resolve(true);
        };

        transaction.onerror = () => {
            const error = transaction.error;

            db.close();
            reject(error);
        };

        transaction.onabort = () => {
            const error = transaction.error;

            db.close();
            reject(error || new Error("تعذر حذف الملف"));
        };
    });
}
