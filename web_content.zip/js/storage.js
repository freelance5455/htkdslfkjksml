const StorageManager = {
    init: function() {
        if (!localStorage.getItem('pacientes')) {
            localStorage.setItem('pacientes', JSON.stringify([])); 
        }
        if (!localStorage.getItem('citas')) {
            localStorage.setItem('citas', JSON.stringify([]));
        }
        console.log("Base de datos local inicializada.");
    },

    getData: function(coleccion) {
        const datosTexto = localStorage.getItem(coleccion);
        if (datosTexto) {
            return JSON.parse(datosTexto); 
        } else {
            return [];
        }
    },

    saveData: function(coleccion, datos) {
        const datosTexto = JSON.stringify(datos);
        localStorage.setItem(coleccion, datosTexto);
    }
};

StorageManager.init();
