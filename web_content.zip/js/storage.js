/* AStore: بديل متزامن الواجهة لـ localStorage، مخزّن فعلياً في IndexedDB.
   - تُحمَّل كل البيانات في الذاكرة عند الإقلاع، والكتابة تُرسَل فوراً إلى IndexedDB.
   - ترحيل لمرة واحدة من localStorage (مع إبقاء النسخة القديمة كشبكة أمان).
   - إن تعذّر IndexedDB يعمل التطبيق على localStorage كما كان. */
const AStore=(function(){
 const DB_NAME='ayman_cashflow_db',STORE='kv',MIG='__migrated_from_localstorage_v1';
 const cache=new Map();let db=null,mode='pending',warned=false;
 const ls=(function(){try{return window.localStorage}catch(e){return null}})();
 function warn(msg){console.error('AStore:',msg);if(!warned){warned=true;try{alert('تحذير: تعذّر حفظ البيانات في تخزين المتصفح.\nخذ نسخة احتياطية الآن.\n'+msg)}catch(e){}}}
 function openDb(){return new Promise(function(res,rej){
  if(typeof indexedDB==='undefined'||!indexedDB){rej(new Error('IndexedDB غير متاح'));return}
  var r;try{r=indexedDB.open(DB_NAME,1)}catch(e){rej(e);return}
  r.onupgradeneeded=function(){var d=r.result;if(!d.objectStoreNames.contains(STORE))d.createObjectStore(STORE)};
  r.onsuccess=function(){res(r.result)};
  r.onerror=function(){rej(r.error||new Error('فشل فتح IndexedDB'))};
  r.onblocked=function(){rej(new Error('IndexedDB محجوب'))};
 })}
 function loadAll(d){return new Promise(function(res,rej){
  var t=d.transaction(STORE,'readonly'),s=t.objectStore(STORE),k=s.getAllKeys(),v=s.getAll();
  t.oncomplete=function(){res(k.result.map(function(key,i){return [key,v.result[i]]}))};
  t.onerror=t.onabort=function(){rej(t.error||new Error('فشل قراءة IndexedDB'))};
 })}
 function putMany(d,entries){return new Promise(function(res,rej){
  var t=d.transaction(STORE,'readwrite'),s=t.objectStore(STORE);
  entries.forEach(function(e){s.put(e[1],e[0])});
  t.oncomplete=function(){res()};
  t.onerror=t.onabort=function(){rej(t.error||new Error('فشلت الكتابة'))};
 })}
 function write(op,key,val){
  if(mode!=='idb'){if(ls){try{if(op==='put')ls.setItem(key,val);else ls.removeItem(key)}catch(e){warn(e.message)}}return}
  try{
   var t=db.transaction(STORE,'readwrite'),s=t.objectStore(STORE);
   if(op==='put')s.put(val,key);else s.delete(key);
   t.onerror=t.onabort=function(){warn('فشل الحفظ: '+((t.error&&t.error.message)||''))};
  }catch(e){warn(e.message)}
 }
 async function requestPersist(){
  try{
   if(typeof navigator==='undefined'||!navigator.storage||!navigator.storage.persist)return null;
   if(navigator.storage.persisted&&await navigator.storage.persisted())return true;
   return await navigator.storage.persist();
  }catch(e){return null}
 }
 const api={
  getItem:function(k){return cache.has(k)?cache.get(k):null},
  setItem:function(k,v){k=String(k);v=String(v);cache.set(k,v);write('put',k,v)},
  removeItem:function(k){k=String(k);cache.delete(k);write('del',k)},
  key:function(i){var a=Array.from(cache.keys());return i>=0&&i<a.length?a[i]:null},
  get length(){return cache.size},
  get mode(){return mode},
  requestPersist:requestPersist,
  migratedAt:function(){return cache.get(MIG)||null},
  status:async function(){
   var o={mode:mode,persisted:null,usage:null,quota:null,migratedAt:cache.get(MIG)||null};
   try{if(typeof navigator!=='undefined'&&navigator.storage){
    if(navigator.storage.persisted)o.persisted=await navigator.storage.persisted();
    if(navigator.storage.estimate){var e=await navigator.storage.estimate();o.usage=e.usage;o.quota=e.quota}
   }}catch(e){}
   return o;
  },
  legacyKeys:function(){var a=[];if(ls){for(var i=0;i<ls.length;i++){var k=ls.key(i);if(k&&k.indexOf('ayman_')===0)a.push(k)}}return a},
  removeLegacy:function(){var a=api.legacyKeys();a.forEach(function(k){ls.removeItem(k)});return a.length}
 };
 api.ready=(async function(){
  try{
   db=await openDb();
   (await loadAll(db)).forEach(function(e){cache.set(e[0],e[1])});
   if(!cache.has(MIG)){
    var mig=[];
    if(ls){for(var i=0;i<ls.length;i++){var k=ls.key(i);if(k&&k.indexOf('ayman_')===0&&!cache.has(k))mig.push([k,ls.getItem(k)])}}
    mig.push([MIG,new Date().toISOString()]);
    await putMany(db,mig);
    mig.forEach(function(e){cache.set(e[0],e[1])});
   }
   mode='idb';
  }catch(e){
   console.warn('AStore: العودة إلى localStorage —',e&&e.message);
   mode='localStorage';db=null;
   if(ls){for(var j=0;j<ls.length;j++){var kk=ls.key(j);if(kk)cache.set(kk,ls.getItem(kk))}}
  }
  requestPersist();
 })();
 return api;
})();
function aymanFmtBytes(n){if(n==null)return 'غير متاح';return n>=1048576?(n/1048576).toFixed(1)+' MB':(n/1024).toFixed(1)+' KB'}
async function aymanStorageRefresh(){
 var el=document.getElementById('storageStatus');if(!el)return;
 var s=await AStore.status();
 var kind=s.mode==='idb'?'IndexedDB ✓':'localStorage (احتياطي — تعذّر استخدام IndexedDB)';
 var pers=s.persisted===true?'دائم ✓ — لن يمسحه المتصفح تلقائياً عند نقص المساحة':s.persisted===false?'غير مضمون — قد يمسحه المتصفح عند نقص المساحة':'غير مدعوم في هذا المتصفح';
 var used=s.usage!=null?(aymanFmtBytes(s.usage)+(s.quota?' من '+aymanFmtBytes(s.quota):'')):'غير متاح';
 var mig=s.migratedAt?new Date(s.migratedAt).toLocaleString('ar-EG'):'—';
 var legacy=AStore.legacyKeys().length;
 el.innerHTML='نوع التخزين: <b>'+kind+'</b><br>الحماية من المسح التلقائي: <b>'+pers+'</b><br>المساحة المستخدمة: <b>'+used+'</b><br>تاريخ الترحيل من localStorage: <b>'+mig+'</b><br>نسخة localStorage القديمة: <b>'+(legacy?legacy+' عنصر (محفوظة كشبكة أمان)':'غير موجودة')+'</b>';
}
async function aymanStoragePersist(){
 var r=await AStore.requestPersist();
 if(r===true)alert('تم تفعيل التخزين الدائم.');
 else if(r===false)alert('لم يمنح المتصفح التخزين الدائم. في Chrome يُمنح غالباً عند تثبيت التطبيق على الشاشة الرئيسية أو تفعيل الإشعارات أو كثرة الاستخدام. استمر في أخذ نسخ احتياطية.');
 else alert('هذا المتصفح لا يدعم طلب التخزين الدائم.');
 aymanStorageRefresh();
}
function aymanStorageCleanOld(){
 if(AStore.mode!=='idb'){alert('لا يمكن الحذف الآن لأن التطبيق يعمل على التخزين الاحتياطي.');return}
 var n=AStore.legacyKeys().length;if(!n){alert('لا توجد نسخة قديمة.');return}
 if(!confirm('سيتم حذف '+n+' عنصر قديم من localStorage. بياناتك الحالية محفوظة في IndexedDB.\nتأكد أنك فحصت التطبيق وأخذت نسخة احتياطية JSON. هل تريد المتابعة؟'))return;
 AStore.removeLegacy();aymanStorageRefresh();
}
