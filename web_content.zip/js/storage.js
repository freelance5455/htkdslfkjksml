/**
 * Snake Escape — Storage Module
 * Handles local storage persistence with error-safe fallback for private browsing.
 */
(function() {
  'use strict';

  const STORAGE_KEY = 'snakeEscapeProgress';

  const DEFAULT_DATA = {
    currentLevel: 1,
    unlockedMaxLevel: 1,
    completedLevels: {}, // { [levelId]: { stars: number, bestMoves: number, bestTime: number, bestScore: number } }
    totalStars: 0,
    hintsRemaining: 3,
    settings: {
      soundEnabled: true,
      musicEnabled: true,
      vibrationEnabled: true,
      darkMode: false,
      language: 'en'
    }
  };

  class StorageManager {
    constructor() {
      this.isAvailable = this._checkAvailability();
      this.memoryStore = {};
      this.data = this.loadProgress();
    }

    _checkAvailability() {
      try {
        const testKey = '__snake_storage_test__';
        localStorage.setItem(testKey, '1');
        localStorage.removeItem(testKey);
        return true;
      } catch (e) {
        console.warn('LocalStorage unavailable, falling back to memory store.');
        return false;
      }
    }

    loadProgress() {
      if (this.isAvailable) {
        try {
          const raw = localStorage.getItem(STORAGE_KEY);
          if (raw) {
            const parsed = JSON.parse(raw);
            return {
              ...DEFAULT_DATA,
              ...parsed,
              settings: {
                ...DEFAULT_DATA.settings,
                ...(parsed.settings || {})
              }
            };
          }
        } catch (e) {
          console.error('Failed to parse localStorage data, resetting defaults:', e);
        }
      }
      return JSON.parse(JSON.stringify(DEFAULT_DATA));
    }

    saveProgress() {
      if (this.isAvailable) {
        try {
          localStorage.setItem(STORAGE_KEY, JSON.stringify(this.data));
        } catch (e) {
          console.error('Failed to save to localStorage:', e);
        }
      }
    }

    isLevelUnlocked(levelId) {
      if (levelId === 1 || levelId === 999) return true;
      if (levelId <= this.data.unlockedMaxLevel) return true;
      const prevLevel = this.data.completedLevels[levelId - 1];
      return !!(prevLevel && prevLevel.stars > 0);
    }

    saveLevelComplete(levelId, stars, moves, score = 0, time = 0) {
      if (levelId === 999) {
        // Daily challenge completion
        this.data.dailyCompleted = { stars, moves, score, time, date: new Date().toISOString().split('T')[0] };
        this.saveProgress();
        return;
      }

      const existing = this.data.completedLevels[levelId] || { stars: 0, bestMoves: Infinity, bestTime: Infinity, bestScore: 0 };
      const newStars = Math.max(existing.stars, stars);
      const newBestMoves = Math.min(existing.bestMoves, moves);
      const newBestTime = Math.min(existing.bestTime || Infinity, time || Infinity);
      const newBestScore = Math.max(existing.bestScore || 0, score || 0);

      this.data.completedLevels[levelId] = {
        stars: newStars,
        bestMoves: newBestMoves,
        bestTime: newBestTime === Infinity ? 0 : newBestTime,
        bestScore: newBestScore
      };

      // Recalculate total stars
      let total = 0;
      for (const id in this.data.completedLevels) {
        total += this.data.completedLevels[id].stars || 0;
      }
      this.data.totalStars = total;

      // Unlock next level up to 60
      const nextLevel = levelId + 1;
      if (nextLevel <= 120 && nextLevel > this.data.unlockedMaxLevel) {
        this.data.unlockedMaxLevel = nextLevel;
      }
      this.data.currentLevel = Math.min(120, nextLevel);

      this.saveProgress();
    }

    getSetting(key) {
      return this.data.settings[key];
    }

    setSetting(key, val) {
      this.data.settings[key] = val;
      this.saveProgress();
    }

    resetProgress() {
      this.data = JSON.parse(JSON.stringify(DEFAULT_DATA));
      this.saveProgress();
    }
  }

  window.SnakeEscape = window.SnakeEscape || {};
  window.SnakeEscape.storage = new StorageManager();
})();
