/* OPERATION: DISCIPLINE — persistência: gravação verificada, transações, recuperação, restauração atômica. Sem DOM. */
(function(){'use strict';
var OD=globalThis.OD,U=OD.U,R=OD.Rules,Sc=OD.Schema,E=U.E;
var sErr=function(m){var e=new Error(m);e.storage=true;return e};
var BAK=function(k){return k+'-bak'};
/* Grava e confere por leitura. Antes de substituir, guarda o conteúdo anterior em <key>-bak (cópia automática verificada). */
function persist(st,key,S){if(!st)throw sErr('Armazenamento local indisponível.');var j=JSON.stringify(S);
 try{var old=st.getItem(key);if(old!=null)st.setItem(BAK(key),old);st.setItem(key,j);if(st.getItem(key)!==j)throw new Error('gravação não confirmada')}
 catch(x){throw sErr('Falha ao gravar no armazenamento ('+(x.message||x)+').')}return j}
var revOf=function(raw){try{var o=JSON.parse(raw);return o&&Number.isInteger(o.rev)?o.rev:0}catch(e){return -1}};
/* Transação: opera numa CÓPIA, valida o resultado, grava e confere. Só então devolve o novo estado. Qualquer erro deixa o estado atual intacto.
   Proteção contra sobrescrita: se o armazenamento foi alterado por outra instância (revisão diferente), recusa. */
function transact(st,key,S,fn,today,opt){opt=opt||{};if(!st)throw sErr('Armazenamento local indisponível.');
 var raw;try{raw=st.getItem(key)}catch(x){throw sErr('Não foi possível ler o armazenamento ('+(x.message||x)+').')}
 if(raw!=null&&revOf(raw)!==(S.rev|0)){var e=new Error('Os dados foram alterados fora desta tela (outra janela?). Reinicie o aplicativo antes de continuar. Nada foi alterado.');e.stale=true;throw e}
 var W=U.clone(S),clock=function(){return today},C=R.mk(W,clock);fn(C);C.post(today);
 var V;try{V=Sc.validate(W)}catch(x){throw new Error('Operação recusada: o resultado violaria a integridade dos dados ('+x.message+').')}
 V.rev=S.rev|0;var changed=JSON.stringify(V)!==JSON.stringify(S);
 if(!changed&&!opt.force)return{S:S,C:R.mk(S,clock),changed:false};
 V.rev=(S.rev|0)+1;persist(st,key,V);return{S:V,C:R.mk(V,clock),changed:true}}
var parseStored=function(raw){var o=JSON.parse(raw),notes=[];if(!(U.isO(o)&&o.v>=2))notes=Sc.migrate(o);return{S:Sc.validate(o),notes:notes,v:o.v}};
function loadState(st,key){var base=function(S,warn,blocked,notes,migrated){return{S:S,warn:warn,blocked:blocked,notes:notes||[],migrated:!!migrated}};
 if(!st)return base(R.empty(),'Armazenamento local indisponível: alterações serão recusadas para não parecerem salvas.',true);
 var raw;try{raw=st.getItem(key)}catch(e){return base(R.empty(),'Não foi possível ler o armazenamento local: alterações serão recusadas.',true)}
 if(raw==null)return base(R.empty(),'',false);
 try{var p=parseStored(raw);return base(p.S,'',false,p.notes,p.v<Sc.VERSION||p.notes.length>0)}
 catch(err){
  /* 1) preserva o conteúdo ilegível; 2) tenta a cópia automática verificada; 3) senão inicia vazio e avisa. */
  var kept=true,ck=st.getItem('od-corrupt')==null?'od-corrupt':'od-corrupt-'+Date.now();try{st.setItem(ck,raw);if(st.getItem(ck)!==raw)kept=false}catch(_){kept=false}
  if(!kept)return base(R.empty(),'Dados salvos ilegíveis ('+err.message+') e NÃO foi possível preservá-los: alterações bloqueadas. A integridade dos dados não pôde ser confirmada.',true);
  var bakRaw=null;try{bakRaw=st.getItem(BAK(key))}catch(_){}
  if(bakRaw!=null){try{var b=parseStored(bakRaw);b.S.rev=Math.max(b.S.rev,0);var j=JSON.stringify(b.S);st.setItem(key,j);if(st.getItem(key)!==j)throw new Error('gravação não confirmada');
   return base(b.S,'Dados principais ilegíveis ('+err.message+'). Recuperado da última cópia automática VERIFICADA; a última alteração pode ter sido perdida. Original preservado em "'+ck+'".',false,b.notes)}catch(_){}}
  try{st.removeItem(key);if(st.getItem(key)!=null)throw new Error('x')}catch(_){return base(R.empty(),'Dados salvos ilegíveis e não foi possível limpar o armazenamento: alterações bloqueadas. A integridade dos dados não pôde ser confirmada. Cópia em "'+ck+'".',true)}
  return base(R.empty(),'Dados salvos ilegíveis ('+err.message+'). A integridade dos dados NÃO pôde ser confirmada. Cópia preservada em "'+ck+'"; iniciado vazio. Restaure um backup se tiver.',false)}}
/* Restauração atômica: valida → guarda cópia → grava → confere. Se falhar, o armazenamento volta ao anterior e o chamador mantém o estado em memória. */
function restore(st,key,prevKey,cur,n){if(!st)E('Armazenamento local indisponível');var old=JSON.stringify(cur);n=Object.assign({},n,{rev:(cur.rev|0)+1});var nw=JSON.stringify(n);
 try{st.setItem(prevKey,old)}catch(e){E('Sem espaço para a cópia de segurança: restauração cancelada')}
 try{st.setItem(key,nw);if(st.getItem(key)!==nw)throw new Error('gravação não confirmada')}catch(e){try{st.setItem(key,old)}catch(_){}E('Falha ao gravar ('+(e.message||e)+'): restauração cancelada, estado anterior preservado')}
 return n}
function undo(st,key,prevKey){if(!st)E('Armazenamento local indisponível');var raw=st.getItem(prevKey);if(raw==null)E('Não há cópia anterior');var p=Sc.validate(JSON.parse(raw)),cr=st.getItem(key);p.rev=Math.max(0,cr==null?0:revOf(cr))+1;persist(st,key,p);try{st.removeItem(prevKey)}catch(e){}return p}
OD.Store={persist:persist,transact:transact,loadState:loadState,restore:restore,undo:undo};
})();
