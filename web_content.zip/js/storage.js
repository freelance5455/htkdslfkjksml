(function () {
  "use strict";
  const DB_NAME = "mobile-code-studio";
  const DB_VERSION = 1;
  const STORE = "state";
  let dbPromise = null;
  let memory = {};
  let persistent = false;

  function openDB() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      let req;
      try { req = indexedDB.open(DB_NAME, DB_VERSION); }
      catch (e) { return reject(e); }
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
      req.onblocked = () => reject(new Error("blocked"));
    });
    return dbPromise;
  }

  async function probe() {
    try {
      const db = await openDB();
      persistent = !!db;
    } catch (e) { persistent = false; }
    return persistent;
  }

  async function get(key) {
    if (persistent) {
      try {
        const db = await openDB();
        return await new Promise((resolve, reject) => {
          const tx = db.transaction(STORE, "readonly");
          const r = tx.objectStore(STORE).get(key);
          r.onsuccess = () => resolve(r.result);
          r.onerror = () => reject(r.error);
        });
      } catch (e) { persistent = false; }
    }
    return memory[key];
  }

  async function set(key, value) {
    if (persistent) {
      try {
        const db = await openDB();
        await new Promise((resolve, reject) => {
          const tx = db.transaction(STORE, "readwrite");
          tx.objectStore(STORE).put(value, key);
          tx.oncomplete = () => resolve();
          tx.onerror = () => reject(tx.error);
        });
        return true;
      } catch (e) { persistent = false; }
    }
    memory[key] = value;
    return false;
  }

  async function clear() {
    memory = {};
    if (persistent) {
      try {
        const db = await openDB();
        await new Promise((resolve, reject) => {
          const tx = db.transaction(STORE, "readwrite");
          tx.objectStore(STORE).clear();
          tx.oncomplete = () => resolve();
          tx.onerror = () => reject(tx.error);
        });
      } catch (e) {}
    }
  }

  window.Storage = { probe, get, set, clear, isPersistent: () => persistent };
})();