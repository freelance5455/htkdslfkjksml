/* =================================
   GAMEHUB - STORAGE SYSTEM
   ================================= */


const GameHubStorage = {


    /* =================================
       GAME LIST
       ================================= */

    gameNames: {

        ticTacToe: "⭕ Tic-Tac-Toe",

        memory: "🧠 Memory Match",

        reaction: "⚡ Reaction Test",

        numberGuess: "🎯 Number Guess",

        mathChallenge: "🧮 Math Challenge"

    },


    /* =================================
       ACHIEVEMENT DEFINITIONS
       ================================= */

    achievementDefinitions: {

        firstGame: {
            name: "First Game",
            icon: "🎮",
            description: "Play your first game"
        },

        scoreHunter: {
            name: "Score Hunter",
            icon: "⭐",
            description: "Reach 100 total score"
        },

        gameAddict: {
            name: "Game Addict",
            icon: "🔥",
            description: "Play 10 games"
        },

        levelUp: {
            name: "Level Up",
            icon: "🚀",
            description: "Reach Level 5"
        },

        masterPlayer: {
            name: "Master Player",
            icon: "🏆",
            description: "Reach 500 total score"
        }

    },


    /* =================================
       DEFAULT DATA
       ================================= */

    createDefaultData() {

        return {

            totalScore: 0,

            gamesPlayed: 0,

            xp: 0,

            level: 1,


            gameScores: {

                ticTacToe: 0,

                memory: 0,

                reaction: 0,

                numberGuess: 0,

                mathChallenge: 0

            },


            achievements: [],


            settings: {

                darkMode: true,

                sound: true

            },


            recentGames: []

        };

    },


    /* =================================
       GET DATA
       ================================= */

    getData() {

        const savedData =
            localStorage.getItem(
                "gameHubData"
            );


        /* =================================
           FIRST TIME
           ================================= */

        if (!savedData) {

            const newData =
                this.createDefaultData();

            this.saveData(newData);

            return newData;

        }


        try {

            const data =
                JSON.parse(savedData);


            /* =================================
               BASIC DATA SAFETY
               ================================= */

            if (
                typeof data.totalScore !==
                "number" ||
                !Number.isFinite(
                    data.totalScore
                )
            ) {

                data.totalScore = 0;

            }


            if (
                typeof data.gamesPlayed !==
                "number" ||
                !Number.isFinite(
                    data.gamesPlayed
                )
            ) {

                data.gamesPlayed = 0;

            }


            if (
                typeof data.xp !==
                "number" ||
                !Number.isFinite(
                    data.xp
                )
            ) {

                data.xp = 0;

            }


            if (
                typeof data.level !==
                "number" ||
                !Number.isFinite(
                    data.level
                ) ||
                data.level < 1
            ) {

                data.level = 1;

            }


            /* =================================
               GAME SCORES
               ================================= */

            if (
                !data.gameScores ||
                typeof data.gameScores !==
                "object"
            ) {

                data.gameScores = {};

            }


            const gameKeys = [
                "ticTacToe",
                "memory",
                "reaction",
                "numberGuess",
                "mathChallenge"
            ];


            gameKeys.forEach(
                gameName => {

                    if (
                        typeof data
                            .gameScores[gameName] !==
                        "number" ||
                        !Number.isFinite(
                            data.gameScores[gameName]
                        )
                    ) {

                        data.gameScores[gameName] =
                            0;

                    }

                }
            );


            /* =================================
               ACHIEVEMENTS
               ================================= */

            if (
                !Array.isArray(
                    data.achievements
                )
            ) {

                data.achievements = [];

            }


            /* Remove invalid achievement IDs */

            data.achievements =
                data.achievements.filter(
                    achievement => {

                        return Object.prototype
                            .hasOwnProperty.call(
                                this.achievementDefinitions,
                                achievement
                            );

                    }
                );


            /* Remove duplicate achievements */

            data.achievements =
                [
                    ...new Set(
                        data.achievements
                    )
                ];


            /* =================================
               RECENT GAMES
               ================================= */

            if (
                !Array.isArray(
                    data.recentGames
                )
            ) {

                data.recentGames = [];

            }


            data.recentGames =
                data.recentGames
                    .filter(game => {

                        return gameKeys.includes(
                            game
                        );

                    })
                    .slice(0, 5);


            /* =================================
               SETTINGS
               ================================= */

            if (
                !data.settings ||
                typeof data.settings !==
                "object"
            ) {

                data.settings = {};

            }


            if (
                typeof data.settings.darkMode !==
                "boolean"
            ) {

                data.settings.darkMode = true;

            }


            if (
                typeof data.settings.sound !==
                "boolean"
            ) {

                data.settings.sound = true;

            }


            return data;

        }


        catch (error) {

            console.error(
                "GameHub data error:",
                error
            );


            const newData =
                this.createDefaultData();


            this.saveData(
                newData
            );


            return newData;

        }

    },


    /* =================================
       SAVE DATA
       ================================= */

    saveData(data) {

        try {

            localStorage.setItem(
                "gameHubData",
                JSON.stringify(data)
            );

        }

        catch (error) {

            console.error(
                "GameHub save error:",
                error
            );

        }

    },


    /* =================================
       UPDATE DATA
       ================================= */

    updateData(changes) {

        const data =
            this.getData();


        Object.assign(
            data,
            changes
        );


        this.saveData(
            data
        );


        return data;

    },


    /* =================================
       GAME NAME
       ================================= */

    getGameName(gameName) {

        return (
            this.gameNames[gameName] ||
            gameName
        );

    },


    /* =================================
       SOUND SETTING
       ================================= */

    isSoundEnabled() {

        const data =
            this.getData();


        return (
            data.settings.sound === true
        );

    },


    /* =================================
       DARK MODE SETTING
       ================================= */

    isDarkModeEnabled() {

        const data =
            this.getData();


        return (
            data.settings.darkMode === true
        );

    },


    /* =================================
       ACHIEVEMENT CHECK
       ================================= */

    checkAchievements(data) {

        const newAchievements = [];


        /* =================================
           FIRST GAME
           ================================= */

        if (
            data.gamesPlayed >= 1 &&
            !data.achievements.includes(
                "firstGame"
            )
        ) {

            data.achievements.push(
                "firstGame"
            );


            newAchievements.push(
                "firstGame"
            );

        }


        /* =================================
           SCORE HUNTER
           ================================= */

        if (
            data.totalScore >= 100 &&
            !data.achievements.includes(
                "scoreHunter"
            )
        ) {

            data.achievements.push(
                "scoreHunter"
            );


            newAchievements.push(
                "scoreHunter"
            );

        }


        /* =================================
           GAME ADDICT
           ================================= */

        if (
            data.gamesPlayed >= 10 &&
            !data.achievements.includes(
                "gameAddict"
            )
        ) {

            data.achievements.push(
                "gameAddict"
            );


            newAchievements.push(
                "gameAddict"
            );

        }


        /* =================================
           LEVEL UP
           ================================= */

        if (
            data.level >= 5 &&
            !data.achievements.includes(
                "levelUp"
            )
        ) {

            data.achievements.push(
                "levelUp"
            );


            newAchievements.push(
                "levelUp"
            );

        }


        /* =================================
           MASTER PLAYER
           ================================= */

        if (
            data.totalScore >= 500 &&
            !data.achievements.includes(
                "masterPlayer"
            )
        ) {

            data.achievements.push(
                "masterPlayer"
            );


            newAchievements.push(
                "masterPlayer"
            );

        }


        return newAchievements;

    },


    /* =================================
       GET ACHIEVEMENT INFORMATION
       ================================= */

    getAchievementInfo(
        achievementId
    ) {

        return (
            this.achievementDefinitions[
                achievementId
            ] || null
        );

    },


    /* =================================
       GET UNLOCKED ACHIEVEMENT COUNT
       ================================= */

    getAchievementCount() {

        const data =
            this.getData();


        return data.achievements.length;

    },


    /* =================================
       GET TOTAL ACHIEVEMENT COUNT
       ================================= */

    getTotalAchievementCount() {

        return Object.keys(
            this.achievementDefinitions
        ).length;

    },


    /* =================================
       GET XP PROGRESS
       ================================= */

    getXPProgress() {

        const data =
            this.getData();


        const currentLevel =
            data.level;


        const levelStartXP =
            (currentLevel - 1) * 100;


        const levelEndXP =
            currentLevel * 100;


        const xpInsideLevel =
            data.xp -
            levelStartXP;


        const xpNeeded =
            levelEndXP -
            levelStartXP;


        let progress =
            (
                xpInsideLevel /
                xpNeeded
            ) * 100;


        progress =
            Math.max(
                0,
                Math.min(
                    100,
                    progress
                )
            );


        return {

            currentXP: data.xp,

            level: currentLevel,

            levelStartXP:
                levelStartXP,

            nextLevelXP:
                levelEndXP,

            progress:
                Math.round(progress)

        };

    },


    /* =================================
       ADD SCORE
       ================================= */

    addScore(
        gameName,
        score
    ) {

        const data =
            this.getData();


        /* =================================
           SCORE SAFETY
           ================================= */

        const safeScore =
            Math.max(
                0,
                Number(score) || 0
            );


        /* =================================
           TOTAL SCORE
           ================================= */

        data.totalScore +=
            safeScore;


        /* =================================
           GAMES PLAYED
           ================================= */

        data.gamesPlayed += 1;


        /* =================================
           BEST SCORE
           ================================= */

        if (
            data.gameScores[gameName] ===
            undefined
        ) {

            data.gameScores[gameName] =
                0;

        }


        if (
            safeScore >
            data.gameScores[gameName]
        ) {

            data.gameScores[gameName] =
                safeScore;

        }


        /* =================================
           XP
           ================================= */

        data.xp +=
            safeScore;


        /* =================================
           LEVEL
           ================================= */

        data.level =
            Math.floor(
                data.xp / 100
            ) + 1;


        /* =================================
           RECENT GAMES
           ================================= */

        data.recentGames.unshift(
            gameName
        );


        data.recentGames =
            data.recentGames.slice(
                0,
                5
            );


        /* =================================
           ACHIEVEMENTS
           ================================= */

        const newAchievements =
            this.checkAchievements(
                data
            );


        /* =================================
           SAVE
           ================================= */

        this.saveData(
            data
        );


        /* =================================
           RESULT
           ================================= */

        return {

            data: data,

            newAchievements:
                newAchievements

        };

    },


    /* =================================
       RESET DATA
       ================================= */

    resetData() {

        const newData =
            this.createDefaultData();


        this.saveData(
            newData
        );


        return newData;

    }

};