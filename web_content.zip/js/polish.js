/* Polish: stability, audio, mobile UX, PWA */
(()=>{
const $=s=>document.querySelector(s),gv=$('#gv');
const safe=f=>{try{return f()}catch(e){}};
/* 1) errors: never fail silently, never spam */
let lastErr=0;
const report=()=>{const n=Date.now();if(n-lastErr<5000)return;lastErr=n;safe(()=>toast('صار خطأ بسيط، جرّب مرة ثانية','err'))};
addEventListener('error',report);addEventListener('unhandledrejection',report);
/* 2) audio: keep context alive on mobile (Chrome suspends it) */
const wake=()=>safe(()=>{if(typeof AC!=='undefined'&&AC&&AC.state==='suspended')AC.resume()});
['pointerdown','keydown','touchend'].forEach(e=>addEventListener(e,wake,{passive:true}));
document.addEventListener('visibilitychange',()=>safe(()=>{if(typeof AC==='undefined'||!AC)return;document.hidden?AC.suspend():AC.resume()}));
/* 3) Android back button / Esc closes the game instead of leaving the page */
let pushed=false;
const closeGame=()=>{const x=$('#gx');if(x&&gv&&!gv.hidden)x.click()};
if(gv)new MutationObserver(()=>{
  if(!gv.hidden&&!pushed){history.pushState({g:1},'');pushed=true;lock(true)}
  else if(gv.hidden&&pushed){pushed=false;lock(false);if(history.state&&history.state.g)history.back()}
}).observe(gv,{attributes:true,attributeFilter:['hidden']});
addEventListener('popstate',()=>{if(pushed&&gv&&!gv.hidden){pushed=false;closeGame()}});
addEventListener('keydown',e=>{if(e.key==='Escape')closeGame()});
/* 4) keep screen on while playing */
let wl=null;
const lock=async on=>{safe(async()=>{if(on&&navigator.wakeLock){wl=await navigator.wakeLock.request('screen')}else if(wl){await wl.release();wl=null}})};
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&gv&&!gv.hidden)lock(true)});
/* 5) theme-color follows the active theme */
const tc=$('#tc'),sync=()=>safe(()=>{tc.content=getComputedStyle(document.documentElement).getPropertyValue('--bg').trim()||'#0a0713'});
new MutationObserver(sync).observe(document.documentElement,{attributes:true,attributeFilter:['data-t']});sync();
/* 6) protect saved progress from being evicted */
safe(()=>navigator.storage&&navigator.storage.persist&&navigator.storage.persist());
/* 7) offline + installable */
if('serviceWorker'in navigator&&location.protocol.startsWith('http'))addEventListener('load',()=>navigator.serviceWorker.register('sw.js').catch(()=>{}));
})();
