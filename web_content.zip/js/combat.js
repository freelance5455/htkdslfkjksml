/* combat.js — Phase 3: battles, casualties, retreat, occupation, capital capture, fortifications, reinforcements. */
(function (G) {
  'use strict';

  G.FORT_MAX = 3;
  G.techBonus = function (owner) { return 1; };   // superseded by per-unit G.unitTech (tech.js)

  // Deterministic, saveable random numbers (st.rs).
  G.rand = function () {
    const st = G.state;
    st.rs = (Math.imul(st.rs >>> 0, 1664525) + 1013904223) >>> 0;
    return st.rs / 4294967296;
  };

  /* ---------- supply ---------- */
  // Depth = provinces between the army and the nearest province owned by its country.
  G.supplyDepth = function (a) {
    const st = G.state, P = G.provinces;
    if (st.owners[a.prov] === a.owner || (G.allied && G.allied(st.owners[a.prov], a.owner))) return 0;
    const seaCap = G.seaSupply && G.seaSupply(a) ? 2 : 6;     // a beachhead with naval superiority is supplied from the sea
    let frontier = [a.prov], seen = { [a.prov]: true };
    for (let d = 1; d <= 6; d++) {
      const next = [];
      for (const p of frontier) for (const n of P[p].adj) {
        if (seen[n]) continue; seen[n] = true;
        if (st.owners[n] === a.owner || (G.allied && G.allied(st.owners[n], a.owner))) return Math.min(d, seaCap);
        next.push(n);
      }
      frontier = next;
    }
    return seaCap;
  };
  G.supply = function (a) { return Math.min(1, Math.max(0.5, 1 - 0.15 * (1 - G.techEff(a.owner, 'supply')) * G.supplyDepth(a) + (G.hasTrait(a, 'Logistician') ? 0.1 : 0))); };

  /* ---------- battles ---------- */
  G.atWarWithOwner = function (country, prov) { const o = G.state.owners[prov]; return o && o !== country && G.atWar(country, o); };
  G.battleAt = function (prov) {
    const st = G.state, o = st.owners[prov]; if (!o) return null;
    const here = G.armiesAt(prov); if (here.length < 2) return null;
    const att = here.filter(a => a.owner !== o && G.atWar(a.owner, o));
    const def = here.filter(a => !att.includes(a) && (a.owner === o || att.some(x => G.atWar(x.owner, a.owner))));
    return att.length && def.length ? { prov: prov, att: att, def: def } : null;
  };
  G.inBattle = function (a) { return !!G.battleAt(a.prov); };
  G.activeBattles = function () {
    const seen = {}, out = [];
    for (const a of G.state.armies) {
      if (seen[a.prov]) continue; seen[a.prov] = true;
      const b = G.battleAt(a.prov); if (b) out.push(b);
    }
    return out;
  };

  // Combat strength of one side. Terrain, fortification and defender bonus apply to defenders.
  G.sideFire = function (armies, defending, prov, opposing) {
    const P = G.provinces[prov];
    let fire = 0;
    for (const a of armies) {
      const g = G.generalOf(a), sup = G.supply(a);
      const gm = (1 + 0.05 * (g ? g.skill : 0)) * (g && ((g.trait === 'Aggressive' && !defending) || (g.trait === 'Defender' && defending)) ? 1.1 : 1);
      for (const u of a.units) {
        const d = G.UNITS[u.type], s = u.men / d.men;
        const orgf = 0.5 + 0.5 * (u.org / d.org), morf = 0.6 + 0.4 * (u.morale / 100);
        const base = defending ? 0.6 * d.def + 0.4 * d.atk : 0.6 * d.atk + 0.4 * d.def;
        fire += base * s * orgf * morf * gm * (u.type === 'artillery' && g && g.trait === 'Gunner' ? 1.15 : 1) * sup * G.unitTech(a.owner, u.type, defending) * (!defending && a.landing && a.landing.until >= G.state.day ? 0.75 : 1);
      }
    }
    if (!defending && armies.length && G.navalSupportFire) fire += G.navalSupportFire(armies[0].owner, prov);
    if (defending) {
      const sappers = opposing && opposing.some(a => a.units.some(u => u.type === 'engineers'));
      const siege = opposing ? Math.min(0.6, Math.max.apply(null, [0].concat(opposing.map(a => G.techEff(a.owner, 'siege'))))) : 0;
      const fort = G.provinces[prov].fort * (sappers ? 0.5 : 1) * (1 - siege);
      fire *= G.TERRAIN[P.terrain].def * (1 + 0.15 * fort);
    }
    return fire;
  };

  function sideOrg(armies) {
    let o = 0, n = 0;
    armies.forEach(a => a.units.forEach(u => { o += u.org / G.UNITS[u.type].org; n++; }));
    return n ? o / n : 0;
  }
  function applyLosses(armies, men, org, mor) {
    let totMen = 0, totOrg = 0, lost = 0;
    armies.forEach(a => a.units.forEach(u => { totMen += u.men; totOrg += G.UNITS[u.type].org; }));
    if (!totMen) return 0;
    for (const a of armies) {
      for (const u of a.units) {
        const d = G.UNITS[u.type], loss = Math.min(u.men, men * (u.men / totMen));
        u.men -= loss; lost += loss;
        u.org = Math.max(0, u.org - org * (d.org / totOrg));
        u.morale = Math.max(0, u.morale - mor);
      }
      a.units = a.units.filter(u => u.men >= 1);
    }
    return Math.round(lost);
  }

  // Where does a beaten army go? Nearest friendly province without enemies, preferring the way home.
  G.retreatProvince = function (a) {
    const st = G.state, P = G.provinces, cap = G.COUNTRIES[a.owner].capitalId, here = P[a.prov];
    const cand = here.adj.filter(n => (st.owners[n] === a.owner || (G.allied && G.allied(st.owners[n], a.owner))) && !G.armiesAt(n).some(x => x.owner !== a.owner && G.atWar(x.owner, a.owner)));
    if (!cand.length) return null;
    cand.sort((x, y) => Math.hypot(P[x].cx - P[cap].cx, P[x].cy - P[cap].cy) - Math.hypot(P[y].cx - P[cap].cx, P[y].cy - P[cap].cy));
    return cand[0];
  };

  function retreatSide(armies, prov) {
    let destroyed = 0;
    for (const a of armies.slice()) {
      const to = G.retreatProvince(a);
      if (to == null) { G.removeArmy(a); destroyed++; continue; }
      a.prov = to; a.path = []; a.progress = 0; a.goal = null;
      a.units.forEach(u => { const d = G.UNITS[u.type]; u.org = Math.max(d.org * 0.1, u.org * 0.7); u.morale = Math.max(5, u.morale - 10); });
    }
    return destroyed;
  }

  G.combatDay = function () {
    const st = G.state;
    st.battleRec = st.battleRec || {};
    for (const b of G.activeBattles()) {
      const jit = () => 0.9 + G.rand() * 0.2;
      const fa = G.sideFire(b.att, false, b.prov, b.def) * jit();
      const fd = G.sideFire(b.def, true, b.prov, b.att) * jit();
      const ratioA = Math.min(3, fd / Math.max(0.1, fa)), ratioD = Math.min(3, fa / Math.max(0.1, fd));
      const la = applyLosses(b.att, fd * 6, fd * 0.9, 1 + ratioA * 1.5);
      const ld = applyLosses(b.def, fa * 6, fa * 0.9, 1 + ratioD * 1.5);
      const rec = st.battleRec[b.prov] = st.battleRec[b.prov] || { days: 0, attLoss: 0, defLoss: 0 };
      rec.days++; rec.attLoss += la; rec.defLoss += ld;
      // armies emptied by casualties disappear
      [b.att, b.def].forEach(list => list.forEach(a => { if (!a.units.length) G.removeArmy(a); }));
      const att = b.att.filter(a => a.units.length), def = b.def.filter(a => a.units.length);
      const oa = sideOrg(att), od = sideOrg(def);
      const attBroken = !att.length || oa < 0.25, defBroken = !def.length || od < 0.25;
      if (!attBroken && !defBroken) continue;
      const attLoses = attBroken && (!defBroken || oa <= od);
      const loserC = attLoses ? b.att[0].owner : st.owners[b.prov], winnerC = attLoses ? st.owners[b.prov] : b.att[0].owner;
      const gone = retreatSide(attLoses ? att : def, b.prov);
      (attLoses ? def : att).forEach(a => a.units.forEach(u => { u.morale = Math.min(100, u.morale + 5); }));
      const rep = 'Battle of ' + G.provinces[b.prov].name + ': ' + G.COUNTRIES[winnerC].name + ' victorious over ' + G.COUNTRIES[loserC].name +
        ' (losses ' + rec.attLoss + ' attackers / ' + rec.defLoss + ' defenders' + (gone ? ', ' + gone + ' army destroyed' : '') + ')';
      delete st.battleRec[b.prov];
      G.logMsg(rep);
      if (winnerC === st.player || loserC === st.player) G.onBattleEnd && G.onBattleEnd(b.prov, winnerC, loserC, rep);
    }
  };

  /* ---------- occupation and conquest ---------- */
  G.occupationNeed = function (prov) { const p = G.provinces[prov]; return 8 + 4 * p.fort + (p.capital ? 4 : 0); };

  G.occupationDay = function () {
    const st = G.state; st.occ = st.occ || {};
    const byProv = {};
    for (const a of st.armies) (byProv[a.prov] = byProv[a.prov] || []).push(a);
    for (const k in st.occ) if (!byProv[k]) delete st.occ[k];
    for (const k in byProv) {
      const prov = +k, o = st.owners[prov]; if (!o || G.provinces[prov].sea) continue;
      const here = byProv[k];
      const att = here.filter(a => a.owner !== o && G.atWar(a.owner, o));
      const def = here.some(a => a.owner === o || att.some(x => G.atWar(x.owner, a.owner)));
      if (!att.length || def) { delete st.occ[prov]; continue; }
      let by = att[0].owner, best = -1;
      att.forEach(a => { const m = G.armySummary(a).men; if (m > best) { best = m; by = a.owner; } });
      const rec = st.occ[prov];
      if (!rec || rec.by !== by) st.occ[prov] = { by: by, days: 1 };
      else rec.days++;
      if (st.occ[prov].days >= G.occupationNeed(prov)) G.transferProvince(prov, by);
    }
  };

  G.transferProvince = function (prov, newOwner) {
    const st = G.state, old = st.owners[prov], P = G.provinces[prov];
    if (!old || old === newOwner) return;
    st.owners[prov] = newOwner; delete st.occ[prov];
    P.fort = Math.max(0, P.fort - 1);
    // refund recruitment and fort building tied to the lost province
    const q = st.queues[old] || [];
    q.filter(it => it.prov === prov).forEach(it => G.cancelRecruit(old, it.id));
    G.refundBuildsIn(prov);
    G.navalPortLost && G.navalPortLost(prov, old);
    st.fortQ = (st.fortQ || []).filter(f => { if (f.prov !== prov) return true; st.countries[f.owner].treasury += f.cost; return false; });
    const wasCap = G.COUNTRIES[old].capitalId === prov;
    G.logMsg(G.COUNTRIES[newOwner].name + ' conquered ' + P.name + ' from ' + G.COUNTRIES[old].name + (wasCap ? ' — CAPITAL CAPTURED' : ''));
    G.recompute();
    const left = G.provinces.filter(p => !p.sea && st.owners[p.id] === old);
    if (wasCap) {
      const co = st.countries[old], cn = st.countries[newOwner];
      const loot = Math.round(co.treasury * 0.25); co.treasury -= loot; cn.treasury += loot;
      P.capital = false;
      if (left.length) {
        left.sort((a, b) => b.pop - a.pop);
        left[0].capital = true; G.COUNTRIES[old].capitalId = left[0].id; G.COUNTRIES[old].capital = left[0].name;
        G.armiesAt(left[0].id); st.armies.filter(a => a.owner === old).forEach(a => a.units.forEach(u => { u.morale = Math.max(0, u.morale - 10); }));
      }
    }
    if (!left.length) G.eliminate(old, newOwner);
    // armies with a standing campaign goal keep marching
    st.armies.filter(a => a.prov === prov && a.owner === newOwner && a.goal != null && a.goal !== prov && !a.path.length).forEach(a => G.orderMove(a, a.goal));
    G.onCapture && G.onCapture(prov, newOwner, old, wasCap);
  };

  /* ---------- fortifications ---------- */
  G.fortCost = function (prov) { return 120 * (G.provinces[prov].fort + 1); };
  G.fortDays = function (prov) {
    const base = 20 * (G.provinces[prov].fort + 1);
    const eng = G.armiesAt(prov).some(a => a.owner === G.state.owners[prov] && a.units.some(u => u.type === 'engineers'));
    return eng ? Math.ceil(base / 2) : base;
  };
  G.canBuildFort = function (owner, prov) {
    const st = G.state, p = G.provinces[prov], c = st.countries[owner];
    if (st.owners[prov] !== owner || p.sea) return { ok: false, msg: 'Not your province' };
    if (p.fort >= G.FORT_MAX) return { ok: false, msg: 'Maximum fortification level' };
    if (p.fort + 1 > G.fortLevelAllowed(owner)) return { ok: false, msg: 'Research ' + (p.fort + 1 === 2 ? 'Fortifications II' : 'Fortifications III') + ' first' };
    if ((st.fortQ || []).some(f => f.prov === prov)) return { ok: false, msg: 'Already under construction' };
    if (G.battleAt(prov)) return { ok: false, msg: 'Battle in progress' };
    if (c.treasury < G.fortCost(prov)) return { ok: false, msg: 'Not enough gold' };
    return { ok: true };
  };
  G.buildFort = function (owner, prov) {
    const chk = G.canBuildFort(owner, prov); if (!chk.ok) return chk;
    const st = G.state; st.fortQ = st.fortQ || [];
    const cost = G.fortCost(prov), days = G.fortDays(prov);
    st.countries[owner].treasury -= cost;
    st.fortQ.push({ prov: prov, owner: owner, left: days, total: days, cost: cost });
    return { ok: true, days: days };
  };
  G.fortDay = function () {
    const st = G.state; if (!st.fortQ) return;
    for (let i = 0; i < st.fortQ.length;) {
      const f = st.fortQ[i];
      if (G.battleAt(f.prov)) { i++; continue; }
      f.left--;
      if (f.left <= 0) {
        G.provinces[f.prov].fort = Math.min(G.FORT_MAX, G.provinces[f.prov].fort + 1);
        if (f.owner === st.player) G.logMsg('Fortification completed at ' + G.provinces[f.prov].name + ' (level ' + G.provinces[f.prov].fort + ')');
        st.fortQ.splice(i, 1);
      } else i++;
    }
  };

  /* ---------- reinforcements ---------- */
  G.reinforceDay = function () {
    const st = G.state;
    for (const a of st.armies) {
      if (st.owners[a.prov] !== a.owner || G.inBattle(a)) continue;
      const c = st.countries[a.owner];
      for (const u of a.units) {
        const d = G.UNITS[u.type], need = d.men - u.men; if (need <= 0) continue;
        let add = Math.min(need, Math.ceil(d.men * 0.01 * G.techMult(a.owner, 'reinforce')), Math.floor(c.manpower), Math.floor(c.treasury / 0.02));
        for (const k in d.equip) add = Math.min(add, Math.floor((c.equip[k] || 0) / (d.equip[k] / d.men)));   // replacements need equipment
        if (add <= 0) continue;
        u.men += add; c.manpower -= add; c.treasury -= add * 0.02;
        for (const k in d.equip) c.equip[k] -= add * (d.equip[k] / d.men);
      }
    }
  };

  G.warDay = function () {
    G.combatDay();
    G.occupationDay();
    G.fortDay();
    G.reinforceDay();
    G.warAIDay && G.warAIDay();
    G.diplomacyDay && G.diplomacyDay();
    G.intelDay && G.intelDay();
    G.techDay && G.techDay();
  };
})(window.EMP = window.EMP || {});
