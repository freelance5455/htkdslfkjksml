'use strict';
let players=[],bullets=[],parts=[],player=null,aliveN=0,state='lobby',time=0,mode=MODES[0],z={},cam={x:0,y:0},hurt=0,shake=0,specT=null,rdt=.016;
const keys={};

function mkP(name,bot,team,out){
  return{name,bot,team,out,x:0,y:0,vx:0,vy:0,r:13,hp:100,armor:0,ang:rnd(0,TAU),
    sl:[{id:'pistol',mag:12},null],cur:0,res:bot?90:60,inv:{bandage:2,medkit:0,grenade:0,smoke:0,gloo:1},
    cd:0,rl:0,heal:null,throwCd:0,glCd:0,alive:true,kills:0,flash:0,hitT:0,lastHit:-9,wt:0,mv:0,
    skin:null,gskin:'#8fd8ff',pet:'',perk:'',
    t:0,tgt:null,tgtLos:false,wp:null,wpT:0,react:0,skill:rnd(.35,.95),sdir:1,sT:0,pk:0,lx:0,ly:0,avoidT:0,avoidA:0,wantMove:false,loot:null,rest:0,gT:rnd(3,8),dmgDone:0};
}
const curS=p=>p.sl[p.cur],curW=p=>WP[p.sl[p.cur].id];
function feed(a,b){
  const d=document.createElement('div');d.innerHTML=a+' <i>›</i> '+b;
  const f=$('feed');f.appendChild(d);while(f.children.length>4)f.removeChild(f.firstChild);
  setTimeout(()=>d.remove(),5600);
}
let toastT=0;
function toast(t){const e=$('toast');e.textContent=t;e.classList.add('on');clearTimeout(toastT);toastT=setTimeout(()=>e.classList.remove('on'),1500)}
function sndAt(k,x,y){const d=Math.hypot(x-cam.x,y-cam.y);snd(k,clamp(1-d/700,0,1))}
function spark(x,y,c,n){if(parts.length>400)return;for(let i=0;i<n;i++){const a=rnd(0,TAU),s=rnd(30,140);parts.push({x,y,z:rnd(8,26),vx:Math.cos(a)*s,vy:Math.sin(a)*s,l:rnd(.15,.4),c})}}

/* ---------- shooting ---------- */
function shoot(p){
  const s=curS(p);
  if(!s||p.cd>0||p.rl>0||p.heal)return false;
  if(s.mag<=0){startReload(p);return false}
  const w=WP[s.id];
  s.mag--;p.cd=w.rate;p.flash=.07;
  const sm=p.bot?(1.9-p.skill*1.1):1;
  for(let k=0;k<w.pel;k++){
    const a=p.ang+(Math.random()*2-1)*w.spr*sm,sp=w.sp*(.95+Math.random()*.1);
    bullets.push({x:p.x+Math.cos(p.ang)*20,y:p.y+Math.sin(p.ang)*20,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,d:w.dmg,l:w.range,o:p,sp,xb:w.cls==='xb'});
  }
  if(w.cls!=='xb'||true)sndAt(w.snd,p.x,p.y);
  if(p===player&&!isTouch)shake=Math.max(shake,w.cls==='sn'||w.cls==='sg'?.35:.08);
  if(s.mag<=0&&p.res>0)startReload(p);
  return true;
}
function startReload(p){
  const s=curS(p);if(!s||p.rl>0||p.heal)return;
  const w=WP[s.id];if(s.mag>=w.mag||p.res<=0)return;
  p.rl=w.rl;p.rls=s;if(p===player)snd('reload');
}
function finishReload(p){
  const s=p.rls;p.rls=null;if(!s||s!==curS(p))return;
  const w=WP[s.id],take=Math.min(w.mag-s.mag,p.res);s.mag+=take;p.res-=take;
}
function swapW(p){
  if(!p.sl[1-p.cur]||p.heal)return;
  p.cur=1-p.cur;p.rl=0;p.rls=null;p.cd=Math.max(p.cd,.3);if(p===player)snd('click');
}

/* ---------- healing ---------- */
function startHeal(p,type){
  if(p.heal){p.heal=null;if(p===player)toast('हीलिंग रोकी');return}
  if(p.inv[type]<=0){if(p===player)toast(type==='bandage'?'बैंडेज नहीं है':'मेडकिट नहीं है');return}
  const cap=type==='bandage'?75:100;
  if(p.hp>=cap){if(p===player)toast(type==='bandage'?'हेल्थ 75 से ऊपर है, मेडकिट लगाओ':'हेल्थ पूरी है');return}
  p.heal={type,t:0,T:type==='bandage'?2.0:4.0};p.rl=0;p.rls=null;
}
function updHeal(p,dt){
  const hl=p.heal;if(!hl)return;
  hl.t+=dt;
  if(hl.t>=hl.T){
    p.inv[hl.type]--;
    const amt=(hl.type==='bandage'?25:100)*(p.perk==='heal'?1.2:1);
    p.hp=Math.min(hl.type==='bandage'?75:100,p.hp+amt);
    if(hl.type==='medkit')p.hp=100;
    p.heal=null;if(p===player){snd('heal');toast('हेल्थ मिली')}
  }
}

/* ---------- throwables & gloo wall ---------- */
function throwN(p,type){
  if(p.inv[type]<=0||p.throwCd>0){if(p===player&&p.inv[type]<=0)toast(type==='grenade'?'ग्रेनेड नहीं है':'स्मोक नहीं है');return}
  p.inv[type]--;p.throwCd=.7;p.heal=null;
  const sp=330;
  nades.push({x:p.x,y:p.y,vx:Math.cos(p.ang)*sp,vy:Math.sin(p.ang)*sp,age:0,fuse:type==='grenade'?2.3:1.1,type,o:p});
  sndAt('throw',p.x,p.y);
}
function updNades(dt){
  for(let i=nades.length-1;i>=0;i--){
    const n=nades[i];n.age+=dt;n.fuse-=dt;
    const nx=n.x+n.vx*dt,ny=n.y+n.vy*dt;
    if(blocked(nx,n.y)||hitDyn(nx,n.y))n.vx*=-.45;else n.x=nx;
    if(blocked(n.x,ny)||hitDyn(n.x,ny))n.vy*=-.45;else n.y=ny;
    n.vx*=Math.max(0,1-2.4*dt);n.vy*=Math.max(0,1-2.4*dt);
    if(n.fuse<=0){
      if(n.type==='grenade')explode(n.x,n.y,n.o);else{smokes.push({x:n.x,y:n.y,r:10,t:11,mr:95});sndAt('gloo',n.x,n.y)}
      nades.splice(i,1);
    }
  }
  for(let i=smokes.length-1;i>=0;i--){const s=smokes[i];s.t-=dt;s.r=Math.min(s.mr,s.r+90*dt);if(s.t<=0)smokes.splice(i,1)}
  for(let i=fxs.length-1;i>=0;i--){fxs[i].t+=dt;if(fxs[i].t>.6)fxs.splice(i,1)}
}
function explode(x,y,o){
  fxs.push({x,y,t:0});sndAt('boom',x,y);
  const R=125;
  for(const p of players){
    if(!p.alive)continue;const d=Math.hypot(p.x-x,p.y-y);if(d>R)continue;
    if(o&&p.team===o.team&&p!==o)continue;
    hurtP(p,100*(1-d/R)*(p===o?.6:1)+4,o);
  }
  for(let i=glooW.length-1;i>=0;i--){const w=glooW[i];if(Math.hypot(w.x-x,w.y-y)<R)damageGloo(i,220)}
  for(let i=0;i<14;i++)spark(x,y,pick(['#ffb347','#ff7a3d','#ffe27a']),1);
  shake=Math.max(shake,clamp(1-Math.hypot(cam.x-x,cam.y-y)/700,0,1)*1.1);
}
function placeGloo(p){
  if(p.inv.gloo<=0||p.glCd>0){if(p===player&&p.inv.gloo<=0)toast('ग्लू वॉल नहीं है');return}
  p.inv.gloo--;p.glCd=.6;p.heal=null;
  glooW.push({x:p.x+Math.cos(p.ang)*48,y:p.y+Math.sin(p.ang)*48,a:p.ang+Math.PI/2,hl:38,ht:7,hp:260,t:30,col:p.gskin,hit:0});
  sndAt('gloo',p.x,p.y);
}
function damageGloo(i,d){
  const w=glooW[i];w.hp-=d;w.hit=.12;
  if(w.hp<=0){spark(w.x,w.y,w.col,14);glooW.splice(i,1)}
}
function updGloo(dt){for(let i=glooW.length-1;i>=0;i--){const w=glooW[i];w.t-=dt;w.hit-=dt;if(w.t<=0){spark(w.x,w.y,w.col,8);glooW.splice(i,1)}}}

/* ---------- damage & death ---------- */
function hurtP(p,d,src){
  if(!p.alive)return;
  if(p.armor>0){const a=Math.min(p.armor,d*.5);p.armor-=a;d-=a}
  p.hp-=d;p.hitT=.12;p.lastHit=time;
  if(src&&src!==p)src.dmgDone+=d;
  if(p===player){hurt=.5;snd('hit',.7)}else if(src===player)snd('hit',.5);
  if(p.hp<=0)kill(p,src);
}
function kill(v,src){
  if(!v.alive)return;
  v.alive=false;v.hp=0;aliveN--;v.heal=null;
  if(src&&src!==v)src.kills++;
  feed(src&&src!==v?src.name:'ज़ोन',v.name);
  spark(v.x,v.y,'#ff5d6c',16);
  for(const s of v.sl)if(s&&s.id!=='pistol')loot.push({x:v.x+rnd(-14,14),y:v.y+rnd(-14,14),t:s.id,q:1});
  loot.push({x:v.x+rnd(-14,14),y:v.y+rnd(-14,14),t:'ammo',q:Math.min(60,Math.max(20,v.res))});
  for(const k of ['medkit','grenade','bandage'])if(v.inv[k]>0)loot.push({x:v.x+rnd(-16,16),y:v.y+rnd(-16,16),t:k,q:v.inv[k]});
  if(v===player&&specT===null)specT=null;
  checkEnd();
}
function checkEnd(){
  if(state!=='play')return;
  const tm=new Set();let mine=false;
  for(const p of players)if(p.alive){tm.add(p.team);if(p.team===player.team)mine=true}
  if(!mine)endMatch(tm.size+1);
  else if(tm.size===1)endMatch(1);
}

/* ---------- loot ---------- */
function take(p,l){
  const t=l.t,w=WP[t];
  if(w){
    if(!p.sl[1]){p.sl[1]={id:t,mag:w.mag};p.res=Math.min(240,p.res+24);if(p===player)toast(w.n+' उठाई');return true}
    const cs=curS(p);
    if(w.tier>WP[cs.id].tier){
      if(cs.id!=='pistol')loot.push({x:p.x+rnd(-10,10),y:p.y+rnd(-10,10),t:cs.id,q:1,np:p});
      p.sl[p.cur]={id:t,mag:w.mag};p.rl=0;p.rls=null;p.res=Math.min(240,p.res+24);if(p===player)toast(w.n+' उठाई');return true;
    }
    return false;
  }
  const q=l.q||1;
  switch(t){
    case'ammo':if(p.res>=240)return false;p.res=Math.min(240,p.res+q);if(p===player)toast('गोलियाँ +'+q);return true;
    case'bandage':case'medkit':case'grenade':case'smoke':case'gloo':{
      const cap={bandage:8,medkit:3,grenade:5,smoke:4,gloo:6}[t];if(p.inv[t]>=cap)return false;
      p.inv[t]=Math.min(cap,p.inv[t]+q);if(p===player){snd('pick');toast({bandage:'बैंडेज',medkit:'मेडकिट',grenade:'ग्रेनेड',smoke:'स्मोक',gloo:'ग्लू वॉल'}[t]+' +'+q)}return true}
    case'vest':if(p.armor>=100)return false;p.armor=Math.min(100,p.armor+50);if(p===player)toast('आर्मर +50');return true;
  }
  return false;
}
function pickups(p){
  for(let i=loot.length-1;i>=0;i--){
    const l=loot[i],dx=l.x-p.x,dy=l.y-p.y;
    if(dx*dx+dy*dy<28*28&&l.np!==p&&take(p,l))loot.splice(i,1);
  }
}
function needLoot(b,l){
  const t=l.t,w=WP[t];
  if(w)return !b.sl[1]||w.tier>WP[curS(b).id].tier;
  switch(t){case'ammo':return b.res<90;case'bandage':return b.inv.bandage<3;case'medkit':return b.inv.medkit<1;case'grenade':return b.inv.grenade<2;case'smoke':return b.inv.smoke<1;case'gloo':return b.inv.gloo<2;case'vest':return b.armor<50}
  return false;
}
