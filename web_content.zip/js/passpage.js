$(function () {
  let pin = "";
  const CORRECT_PIN = "2509";

  $(".passpage").hide();
  $(".container").hide();

  // Заставка 3 секунды
  setTimeout(function () {
    $(".loader").fadeOut(200, function () {
      $(".passpage").fadeIn(200);
    });
  }, 3000);

  function renderPin() {
    $(".pin-dot").removeClass("filled");
    $(".pin-dot").each(function (index) {
      if (index < pin.length) {
        $(this).addClass("filled");
      }
    });
  }

  function shakePin() {
    const w = $(".pin-wrap");
    if (!w.length) return;
    const seq = ["-8px", "8px", "-6px", "6px", "-3px", "3px", "0"];
    w.css("transition", "transform 0.08s");
    seq.forEach(function (off, i) {
      setTimeout(function () { w.css("transform", "translateX(" + off + ")"); }, i * 60);
    });
    setTimeout(function () { w.css({ transition: "", transform: "" }); }, seq.length * 60 + 50);
  }

  function unlockScreen() {
    setTimeout(function () {
      $(".passpage").fadeOut(200, function () {
        $(".container").fadeIn(200);
      });
    }, 200);
  }

  // Используем только click, чтобы избежать дублирования касаний
  $(".pin-number").on("click", function () {
    const num = $(this).data("number").toString();
    if (pin.length < 4) {
      pin += num;
      renderPin();

      if (pin.length === 4) {
        setTimeout(function () {
          if (pin === CORRECT_PIN) {
            unlockScreen();
          } else {
            shakePin();
            pin = "";
            renderPin();
          }
        }, 100);
      }
    }
  });

  $("#deleteBtn").on("click", function () {
    if (pin.length > 0) {
      pin = pin.slice(0, -1);
      renderPin();
    }
  });
});