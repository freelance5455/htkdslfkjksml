// ===== SECRETS: a hidden shrine that awakens an OP power-up =====
// Placed on the ground, far south-west, past the Shadow Clan camp.

const AETHER_POS = { x: -90, z: -205 };

function buildAetherShrine() {
  const group = new THREE.Group();
  const mat = new THREE.MeshStandardMaterial({ color: 0xf0d060, emissive: 0xf0d060, emissiveIntensity: 1, flatShading: true });

  const ring = new THREE.Mesh(new THREE.TorusGeometry(1.4, 0.18, 8, 16), mat);
  ring.rotation.x = Math.PI / 2;
  ring.position.y = 1.2;
  group.add(ring);

  const core = new THREE.Mesh(new THREE.IcosahedronGeometry(0.7, 0), mat);
  core.position.y = 1.2;
  group.add(core);

  const plinth = new THREE.Mesh(new THREE.CylinderGeometry(0.9, 1.1, 1, 8), new THREE.MeshStandardMaterial({ color: 0x3a3a3a, flatShading: true }));
  plinth.position.y = 0.5;
  plinth.castShadow = true;
  plinth.receiveShadow = true;
  group.add(plinth);

  group.userData = { core, ring };
  return group;
}

const aetherShrine = buildAetherShrine();
aetherShrine.position.set(AETHER_POS.x, heightAt(AETHER_POS.x, AETHER_POS.z), AETHER_POS.z);
scene.add(aetherShrine);

let aetherAwakened = false;
let aetherPhase = 0;

function updateAetherShrine(dt) {
  aetherPhase += dt;
  aetherShrine.userData.core.rotation.y += dt * 1.2;
  aetherShrine.userData.ring.rotation.z += dt * 0.8;
  aetherShrine.scale.setScalar(1 + Math.sin(aetherPhase * 1.5) * 0.08);

  if (aetherAwakened) return;
  const dist = Math.hypot(player.position.x - AETHER_POS.x, player.position.z - AETHER_POS.z);
  if (dist < 3) {
    aetherAwakened = true;
    playerMaxHp = 500;
    playerHp = 500;
    playerDamage = 25;
    rapidFire = true;
    player.userData.bodyMat.color.setHex(0xf0d060);
    playerAura.material.color.setHex(0xf0d060);
    playerAura.scale.setScalar(1.7);
    showToast('An ancient power surges through you...\nAETHER AWAKENED', 4200);
    playAetherSound();
  }
}
