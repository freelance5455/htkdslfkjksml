/* =========================================================
   NetEarn Pro
   Welcome Page JavaScript
========================================================= */


"use strict";


/* =========================================================
   DOM ELEMENTS
========================================================= */

const menuButton =
    document.getElementById("menuButton");

const mobileMenu =
    document.getElementById("mobileMenu");

const currentYear =
    document.getElementById("currentYear");



/* =========================================================
   MOBILE MENU
========================================================= */

if (menuButton && mobileMenu) {

    menuButton.addEventListener(
        "click",
        function () {

            const isOpen =
                mobileMenu.classList.contains("open");


            if (isOpen) {

                closeMenu();

            } else {

                openMenu();

            }

        }
    );

}



/* =========================================================
   OPEN MENU
========================================================= */

function openMenu() {

    if (!menuButton || !mobileMenu) {
        return;
    }


    mobileMenu.classList.add("open");

    menuButton.classList.add("active");

    menuButton.setAttribute(
        "aria-expanded",
        "true"
    );

}



/* =========================================================
   CLOSE MENU
========================================================= */

function closeMenu() {

    if (!menuButton || !mobileMenu) {
        return;
    }


    mobileMenu.classList.remove("open");

    menuButton.classList.remove("active");

    menuButton.setAttribute(
        "aria-expanded",
        "false"
    );

}



/* =========================================================
   MOBILE MENU LINKS
========================================================= */

const mobileMenuLinks =
    document.querySelectorAll(
        ".mobile-menu a"
    );


mobileMenuLinks.forEach(
    function (link) {

        link.addEventListener(
            "click",
            function () {

                closeMenu();

            }
        );

    }
);



/* =========================================================
   CLOSE MENU WHEN CLICKING OUTSIDE
========================================================= */

document.addEventListener(
    "click",
    function (event) {

        if (
            !menuButton ||
            !mobileMenu
        ) {
            return;
        }


        const clickedInsideMenu =
            mobileMenu.contains(event.target);


        const clickedMenuButton =
            menuButton.contains(event.target);


        if (
            !clickedInsideMenu &&
            !clickedMenuButton
        ) {

            closeMenu();

        }

    }
);



/* =========================================================
   ESC KEY CLOSE MENU
========================================================= */

document.addEventListener(
    "keydown",
    function (event) {

        if (event.key === "Escape") {

            closeMenu();

        }

    }
);



/* =========================================================
   CURRENT YEAR
========================================================= */

if (currentYear) {

    currentYear.textContent =
        new Date().getFullYear();

}



/* =========================================================
   SMOOTH INTERNAL NAVIGATION
========================================================= */

const internalLinks =
    document.querySelectorAll(
        'a[href^="#"]'
    );


internalLinks.forEach(
    function (link) {

        link.addEventListener(
            "click",
            function (event) {

                const targetId =
                    link.getAttribute("href");


                if (
                    !targetId ||
                    targetId === "#"
                ) {
                    return;
                }


                const target =
                    document.querySelector(
                        targetId
                    );


                if (!target) {
                    return;
                }


                event.preventDefault();


                const header =
                    document.querySelector(
                        ".welcome-header"
                    );


                const headerHeight =
                    header
                        ? header.offsetHeight
                        : 0;


                const targetPosition =
                    target.getBoundingClientRect().top +
                    window.scrollY -
                    headerHeight -
                    10;


                window.scrollTo({

                    top:
                        targetPosition,

                    behavior:
                        "smooth"

                });


                closeMenu();

            }
        );

    }
);



/* =========================================================
   SERVICE CARDS
========================================================= */

const serviceCards =
    document.querySelectorAll(
        ".service-card"
    );


serviceCards.forEach(
    function (card) {

        card.addEventListener(
            "click",
            function (event) {

                /*
                 * These cards are informational
                 * on the public welcome page.
                 *
                 * Actual work access will remain
                 * inside the logged-in system.
                 */

                event.preventDefault();

            }
        );

    }
);



/* =========================================================
   PAGE READY
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        closeMenu();

    }
);

/* ==================================================
   NETEARN PRO PREMIUM INTRO
================================================== */

(function () {

    const intro =
        document.getElementById("netearnIntro");

    if (!intro) {
        return;
    }


    const introSeen =
        sessionStorage.getItem(
            "netearnWelcomeIntroSeen"
        );


    // এই session-এ আগেই দেখা হলে
    // সরাসরি hide করে দেবে
    if (introSeen === "true") {

        intro.classList.add(
            "intro-hide"
        );

        return;

    }


    // প্রথমবার দেখানো
    sessionStorage.setItem(
        "netearnWelcomeIntroSeen",
        "true"
    );


    // Premium intro শেষ হওয়ার পর
    // Welcome Page দেখাবে
    setTimeout(() => {

        intro.classList.add(
            "intro-hide"
        );

    }, 3500);


})();