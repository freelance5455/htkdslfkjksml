(function () {
  "use strict";

  const editor = document.getElementById("editor");
  const highlightEl = document.getElementById("highlight");
  const gutter = document.getElementById("gutter");
  const scrollEl = document.getElementById("editor-scroll");
  const statusPos = document.getElementById("status-pos");
  const statusLang = document.getElementById("status-lang");
  const statusSize = document.getElementById("status-size");

  let currentLang = "html";
  let showLines = true;
  let autoClose = true;
  let onChangeCb = null;
  let undoStack = [];
  let redoStack = [];
  let lastSnapshot = "";
  let composing = false;
  let savedScroll = { top: 0, left: 0, pos: 0 };

  function getValue() { return editor.value; }

  function setValue(v, lang) {
    editor.value = v || "";
    if (lang) currentLang = lang;
    lastSnapshot = editor.value;
    undoStack = [editor.value];
    redoStack = [];
    render();
  }

  function setLang(lang) {
    currentLang = lang;
    statusLang.textContent = (lang || "txt").toUpperCase();
    render();
  }

  function render() {
    const code = editor.value;
    highlightEl.innerHTML = window.Highlighter.highlight(code, currentLang) + "\n";
    updateGutter(code);
    updatePos();
    statusSize.textContent = code.length + " حرف";
  }

  function updateGutter(code) {
    if (!showLines) { gutter.classList.add("hidden"); return; }
    gutter.classList.remove("hidden");
    const lines = code.split("\n").length;
    let g = "";
    for (let i = 1; i <= lines; i++) g += i + "\n";
    gutter.textContent = g;
  }

  function updatePos() {
    const pos = editor.selectionStart;
    const before = editor.value.slice(0, pos);
    const line = before.split("\n").length;
    const col = pos - before.lastIndexOf("\n");
    statusPos.textContent = "سطر " + line + "، عمود " + col;
  }

  function syncScroll() {
    highlightEl.style.transform = "translate(" + -scrollEl.scrollLeft + "px," + -scrollEl.scrollTop + "px)";
    gutter.scrollTop = scrollEl.scrollTop;
    savedScroll.top = scrollEl.scrollTop;
    savedScroll.left = scrollEl.scrollLeft;
  }

  function pushUndo() {
    const v = editor.value;
    if (v === lastSnapshot) return;
    undoStack.push(v);
    if (undoStack.length > 200) undoStack.shift();
    redoStack = [];
    lastSnapshot = v;
  }

  function undo() {
    if (undoStack.length <= 1) return;
    redoStack.push(undoStack.pop());
    editor.value = undoStack[undoStack.length - 1];
    lastSnapshot = editor.value;
    render();
    if (onChangeCb) onChangeCb();
  }

  function redo() {
    if (!redoStack.length) return;
    const v = redoStack.pop();
    undoStack.push(v);
    editor.value = v;
    lastSnapshot = v;
    render();
    if (onChangeCb) onChangeCb();
  }

  function insertText(text) {
    const start = editor.selectionStart;
    const end = editor.selectionEnd;
    editor.value = editor.value.slice(0, start) + text + editor.value.slice(end);
    editor.selectionStart = editor.selectionEnd = start + text.length;
    render();
    if (onChangeCb) onChangeCb();
  }

  function handleKey(e) {
    const start = editor.selectionStart;
    const end = editor.selectionEnd;
    const val = editor.value;

    if (e.key === "Tab") { e.preventDefault(); insertText("  "); return; }

    if (e.key === "Enter") {
      e.preventDefault();
      const before = val.slice(0, start);
      const lineStart = before.lastIndexOf("\n") + 1;
      const line = before.slice(lineStart);
      const indent = (line.match(/^[ \t]*/) || [""])[0];
      let extra = "";
      const trimmed = line.trimEnd();
      if (/[{\[(<]$/.test(trimmed)) extra = "  ";
      insertText("\n" + indent + extra);
      return;
    }

    if (autoClose) {
      const pairs = { "(": ")", "[": "]", "{": "}", '"': '"', "'": "'", "`": "`" };
      if (pairs[e.key]) {
        e.preventDefault();
        const sel = val.slice(start, end);
        insertText(e.key + sel + pairs[e.key]);
        editor.selectionStart = editor.selectionEnd = start + 1 + sel.length;
        return;
      }
    }

    if (e.key === "Backspace" && start === end && start > 0) {
      const prev = val[start - 1];
      const next = val[start];
      if (autoClose && ((prev === "(" && next === ")") || (prev === "[" && next === "]") ||
          (prev === "{" && next === "}") || (prev === '"' && next === '"') ||
          (prev === "'" && next === "'"))) {
        e.preventDefault();
        editor.value = val.slice(0, start - 1) + val.slice(start + 1);
        editor.selectionStart = editor.selectionEnd = start - 1;
        render();
        if (onChangeCb) onChangeCb();
      }
    }
  }

  editor.addEventListener("input", () => {
    if (composing) return;
    render();
    if (onChangeCb) onChangeCb();
  });
  editor.addEventListener("compositionstart", () => { composing = true; });
  editor.addEventListener("compositionend", () => { composing = false; render(); if (onChangeCb) onChangeCb(); });
  editor.addEventListener("keydown", handleKey);
  editor.addEventListener("keyup", updatePos);
  editor.addEventListener("click", updatePos);
  editor.addEventListener("scroll", syncScroll);
  scrollEl.addEventListener("scroll", syncScroll);

  document.addEventListener("keydown", (e) => {
    const mod = e.ctrlKey || e.metaKey;
    if (!mod) return;
    if (e.key === "s") { e.preventDefault(); document.getElementById("btn-save").click(); }
    else if (e.key === "z" && !e.shiftKey) { e.preventDefault(); undo(); }
    else if ((e.key === "z" && e.shiftKey) || e.key === "y") { e.preventDefault(); redo(); }
  });

  window.Editor = {
    getValue, setValue, setLang, render, undo, redo, pushUndo, insertText,
    onChange: (cb) => { onChangeCb = cb; },
    setShowLines: (v) => { showLines = v; render(); },
    setAutoClose: (v) => { autoClose = v; },
    focus: () => editor.focus(),
    getTextarea: () => editor,
    getScroll: () => savedScroll,
    restoreScroll: () => {
      scrollEl.scrollTop = savedScroll.top;
      scrollEl.scrollLeft = savedScroll.left;
      syncScroll();
    },
    setSelection: (start, end) => {
      editor.focus();
      editor.selectionStart = start;
      editor.selectionEnd = end;
      updatePos();
    },
    getSelection: () => ({ start: editor.selectionStart, end: editor.selectionEnd }),
  };
})();