/* عکس در گفتگو: کوچک‌سازی تا ۱۶۰۰ پیکسل (JPEG ۰٫۸۵)، ساخت بندانگشتی، حذف، محدودیت تعداد و حجم، و پیام‌های فارسی برای فرمت‌های نامناسب (HEIC). */
(function () {
  'use strict';
  var App = (window.App = window.App || {});
  var u = App.u;
  var ai = (App.ai = App.ai || {});
  var MAX_PHOTOS = 4;
  var MAX_SIDE = 1600;
  var JPEG_Q = 0.85;
  var THUMB_SIDE = 160;
  var MAX_FILE = 15 * 1024 * 1024;
  var MAX_B64 = 4.5 * 1024 * 1024;
  var seq = 0;
  ai.pending = [];

  var MSG = {
    heic: 'عکس HEIC آیفون در این مرورگر باز نشد. در آیفون: تنظیمات دوربین ← فرمت‌ها ← «بیشترین سازگاری» را بزن، یا عکس را از گالری با «اشتراک» به صورت JPEG بفرست، یا اسکرین‌شات بگیر.',
    type: 'این فرمت عکس پشتیبانی نمی‌شود. JPEG، PNG یا WebP بفرست.',
    big: 'فایل عکس خیلی بزرگ است (بیشتر از ۱۵ مگابایت). عکس کوچک‌تری بفرست.',
    decode: 'این عکس خوانده نشد. یک بار دیگر امتحان کن یا عکس دیگری بفرست.',
    count: 'حداکثر ' + u.fa(MAX_PHOTOS) + ' عکس در هر پیام می‌شود.',
    total: 'حجم عکس‌ها زیاد است. یکی از عکس‌ها را حذف کن یا عکس کم‌حجم‌تری بفرست.',
    canvas: 'این مرورگر پردازش عکس را پشتیبانی نمی‌کند.'
  };
  function isHeic(f) {
    return /hei[cf]/i.test(f.type || '') || /\.(heic|heif)$/i.test(f.name || '');
  }

  // باز کردن عکس؛ اگر createImageBitmap نبود، از عنصر img استفاده می‌شود
  function decode(file) {
    if (typeof createImageBitmap === 'function') {
      return createImageBitmap(file).then(function (bmp) {
        return { w: bmp.width, h: bmp.height, src: bmp, close: function () { if (bmp.close) bmp.close(); } };
      });
    }
    return new Promise(function (resolve, reject) {
      var url = URL.createObjectURL(file);
      var img = new Image();
      img.onload = function () {
        resolve({ w: img.naturalWidth, h: img.naturalHeight, src: img, close: function () { URL.revokeObjectURL(url); } });
      };
      img.onerror = function () { URL.revokeObjectURL(url); reject(new Error('decode')); };
      img.src = url;
    });
  }
  function drawTo(d, w, h) {
    var c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    var ctx = c.getContext && c.getContext('2d');
    if (!ctx) throw new Error(MSG.canvas);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, w, h);
    ctx.drawImage(d.src, 0, 0, w, h);
    return c;
  }
  function processOne(file) {
    if (file.size > MAX_FILE) return Promise.reject(new Error(MSG.big));
    if (file.type && !/^image\//i.test(file.type) && !isHeic(file)) return Promise.reject(new Error(MSG.type));
    return decode(file).then(function (d) {
      var s = Math.min(1, MAX_SIDE / Math.max(d.w || 1, d.h || 1));
      var w = Math.max(1, Math.round(d.w * s)), h = Math.max(1, Math.round(d.h * s));
      var full = drawTo(d, w, h).toDataURL('image/jpeg', JPEG_Q);
      var tw = Math.min(THUMB_SIDE, w), th = Math.max(1, Math.round(h * tw / w));
      var thumb = drawTo(d, tw, th).toDataURL('image/jpeg', 0.7);
      if (d.close) d.close();
      seq++;
      return { id: 'ph' + seq + '-' + (Date.now() % 100000), name: String(file.name || 'عکس').slice(0, 60), mime: 'image/jpeg', b64: full.slice(full.indexOf(',') + 1), thumb: thumb, w: w, h: h };
    }, function () {
      throw new Error(isHeic(file) ? MSG.heic : MSG.decode);
    });
  }

  // افزودن عکس‌ها به پیام بعدی؛ خطاها فارسی و جدا از هم نشان داده می‌شوند
  ai.addPhotos = function (list) {
    var files = Array.prototype.slice.call(list || []);
    if (!files.length) return Promise.resolve();
    var room = MAX_PHOTOS - ai.pending.length;
    var errs = [];
    if (room <= 0) { App.alert(MSG.count); return Promise.resolve(); }
    if (files.length > room) errs.push(MSG.count);
    var chain = Promise.resolve();
    files.slice(0, room).forEach(function (f) {
      chain = chain.then(function () {
        return processOne(f).then(function (p) {
          var total = ai.pending.reduce(function (a, x) { return a + x.b64.length; }, 0) + p.b64.length;
          if (total > MAX_B64) { errs.push(MSG.total); return; }
          ai.pending.push(p);
        }, function (e) {
          var known = Object.keys(MSG).map(function (k) { return MSG[k]; });
          errs.push(e && known.indexOf(e.message) >= 0 ? e.message : MSG.decode);
        });
      });
    });
    return chain.then(function () {
      errs.filter(function (x, i, a) { return a.indexOf(x) === i; }).forEach(function (m) { App.alert(m); });
      App.render();
    });
  };

  App.act['chat-photo'] = function () {
    // پیش از باز شدن گالری اجازه گرفته می‌شود؛ فقط عکس‌های انتخاب‌شده فرستاده می‌شوند
    if (!App.confirm('برای انتخاب عکس، گالری باز می‌شود. فقط عکس‌هایی که خودت انتخاب کنی برای مشاور فرستاده می‌شوند. اجازه می‌دهی؟')) return;
    var f = document.getElementById('chat-file');
    if (f) f.click();
  };
  App.act['chat-photo-x'] = function (el) {
    var id = el.getAttribute('data-key');
    ai.pending = ai.pending.filter(function (p) { return p.id !== id; });
    App.render();
  };
  document.addEventListener('change', function (e) {
    var el = e.target;
    if (!el || el.id !== 'chat-file') return;
    var p = ai.addPhotos(el.files);
    p.then(function () { try { el.value = ''; } catch (x) { /* ignore */ } });
  }, false);
})();
