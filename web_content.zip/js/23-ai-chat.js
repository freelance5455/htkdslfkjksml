/* گفتگو با مشاور: حلقه‌ی ابزار، پنجره‌ی گفتگو (تب و برگه‌ی شناور)، پرسش‌های آماده، تجزیه‌ی متن و تحلیل آزمون. */
(function () {
  'use strict';
  var App = (window.App = window.App || {});
  var u = App.u;
  var D = App.D;
  var st = App.study;
  var pl = App.plan;
  var ai = (App.ai = App.ai || {});
  var ui = App.ui;
  var S = function () { return App.S; };
  var MAX_MSGS = 40;

  // یک خط راهنما وقتی کلید نیست؛ در برگه‌ی شناور به صفحه‌ی مشاور هدایت می‌کند
  function aiStatusLine(compact) {
    if (ai.configured()) return '';
    var n = ai.config().name;
    return compact ? 'برای گفتگو، کلید «' + n + '» را در صفحه‌ی مشاور وارد کن.' : 'برای گفتگو، کلید «' + n + '» را بالا وارد کن.';
  }

  // پرسش‌های آماده: کلید، برچسب، متن
  var QB = [
    ['analysis', '📊 تحلیل وضعیت', 'وضعیت امروز و کل برنامه‌ام را تحلیل کن: نقاط قوت، ضعف‌های اصلی و سه کار مشخص برای فردا. اگر داده کم است بگو.'],
    ['plan', '📅 برنامه‌ی امروز', 'برنامه‌ی امروزم را دقیق‌تر کن (ساعت‌به‌ساعت)، با توجه به کارهای ثابت، آزمون‌های پیش‌رو و ضعف‌ها. اگر تغییر لازم بود، آن را به‌صورت پیشنهاد گروهی بده.'],
    ['wplan', '🗓 برنامه‌ی هفته', 'برای هفته‌ی بعد یک برنامه‌ی مطالعاتی بنویس. در پایان، برنامه را داخل یک بلوک ```json به شکل {"weekly":[{"day":0,"s0":"HH:MM","e0":"HH:MM","t":"عنوان","k":"study"}]} بده. day از ۰ (یکشنبه) تا ۶ (شنبه) است و k یکی از study، class یا other است.'],
    ['motiv', '😓 انگیزه ندارم', 'انگیزه‌ام کم است. گفتگویی کوتاه، واقع‌بینانه و همدلانه بکن و یک قدم کوچک برای امروز بده.'],
    ['commit', '🔁 تعهد فردا', 'برای فردا یک تعهد کوچک و قابل اندازه‌گیری (زمان، درس، تعداد تست) پیشنهاد بده. اگر موافق بودم، با ابزار ثبتش کن.'],
    ['backlog', '📌 جبران عقب‌افتادگی', 'عقب‌افتادگی‌ها و نقاط ضعف باز مرا ببین و یک برنامه‌ی جبران دو هفته‌ای بده.'],
    ['tech', '🧠 روش مطالعه', 'برای درس‌هایی که بیشتر ایراد دارم، روش مطالعه‌ی بهتری پیشنهاد بده و یک مثال کوتاه بزن.'],
    ['weakfind', '🎯 پیدا کردن ضعف‌ها', 'از روی آزمون‌ها و خطاهایم، نقاط ضعف مهم را پیدا کن. اگر موارد تازه‌ای هست، آن‌ها را به‌صورت پیشنهاد گروهی (add_weak_point) بده.'],
    ['examsall', '🧪 تحلیل همه‌ی آزمون‌ها', 'روند همه‌ی آزمون‌هایم را تحلیل کن: کدام درس‌ها بالا رفته‌اند، کدام پایین، و برای آزمون بعدی چه کنم؟'],
    ['quiz', '📝 پیشنهاد آزمون تستی', 'بر اساس ضعف‌هایم، یک پیشنهاد آزمون تستی کوتاه بده (درس، فصل، تعداد سؤال). آزمون را فقط وقتی بساز که خواستم.'],
    ['week', '🗞 مرور هفته', 'مرور هفته‌ام را تحلیل کن و برای هفته‌ی بعد سه کار مشخص پیشنهاد بده.'],
    ['konkur', '🎯 برآورد زمان کنکور', 'با توجه به تاریخ کنکور و ساختار آزمون ریاضی (۴۰ سؤال در ۷۰ دقیقه)، زمان و تعداد تست لازم در هفته را برآورد کن. تقریبی بودنش را بگو.']
  ];
  var QB_BY = {};
  QB.forEach(function (q) { QB_BY[q[0]] = q; });

  // ---- پیام‌ها ----
  function addMsg(role, text, extra) {
    var m = { id: u.uid(), r: role, c: String(text == null ? '' : text).slice(0, 8000) };
    if (extra && extra.imgs) m.imgs = extra.imgs;
    if (extra && extra.acts && extra.acts.length) m.acts = extra.acts;
    S().chat = (S().chat || []).concat([m]).slice(-MAX_MSGS);
    App.save();
    return m;
  }
  function findMsg(id) {
    return (S().chat || []).find(function (m) { return String(m.id) === String(id); }) || null;
  }
  function findAct(uid) {
    var hit = null;
    (S().chat || []).forEach(function (m) {
      (m.acts || []).forEach(function (a) { if (a.uid && a.uid === uid) hit = a; });
    });
    return hit;
  }

  // تاریخچه‌ی متنی برای مدل: فقط متن، بدون پیام‌های خطا، با ادغام پیام‌های هم‌نقش
  function buildHistory() {
    var list = (S().chat || []).filter(function (m) { return m.c && m.c.indexOf('⚠️') !== 0; }).slice(-12);
    var out = [];
    list.forEach(function (m) {
      var role = m.r === 'user' ? 'user' : 'assistant';
      var text = m.c + (m.imgs ? '\n[' + m.imgs + ' عکس پیوست بود]' : '');
      if (out.length && out[out.length - 1].role === role) out[out.length - 1].content += '\n\n' + text;
      else out.push({ role: role, content: text });
    });
    while (out.length && out[0].role !== 'user') out.shift();
    if (out.length && out[out.length - 1].role === 'user') out.pop();
    return out;
  }

  function makeAct(name, out) {
    if (out.nav) return { name: 'nav:' + out.nav, label: out.label, ok: 1, uid: '' };
    if (out.proposal) return { name: 'proposal', label: out.label, ok: 1, uid: out.proposal };
    return { name: String(name).slice(0, 40), label: out.label || name, ok: out.ok ? 1 : 0, uid: out.uid || '' };
  }

  // ---- ارسال و حلقه‌ی ابزار ----
  ai.send = function (text, o) {
    o = o || {};
    var t = String(text == null ? '' : text).trim();
    var photos = ai.pending.slice();
    if (!t && !photos.length) { App.toast('چیزی بنویس یا عکس بفرست'); return; }
    if (ai.busy) { App.toast('مشاور هنوز پاسخ می‌دهد؛ کمی صبر کن'); return; }
    if (ui.tab !== 'ai') ui.sheet = true;
    App.form('chatf', {}).txt = '';
    ai.pending = [];
    if (!ai.configured()) {
      addMsg('user', t || '(عکس)', photos.length ? { imgs: photos.length } : null);
      addMsg('assistant', '⚠️ ' + aiStatusLine(ui.tab !== 'ai'));
      ui.chatScroll = true;
      App.render();
      return;
    }
    var history = buildHistory();
    addMsg('user', t || 'این عکس را بررسی کن.', photos.length ? { imgs: photos.length } : null);
    var content = photos.map(function (p) {
      return { type: 'image', source: { type: 'base64', media_type: p.mime || 'image/jpeg', data: p.b64 } };
    });
    content.push({ type: 'text', text: t || 'این عکس را بررسی کن.' });
    var messages = history.concat([{ role: 'user', content: content }]);
    var acts = [], steps = 0, done = false;
    ai.busy = true;
    ui.chatScroll = true;
    App.render();

    function finish(text) {
      if (done) return;
      done = true;
      addMsg('assistant', text, { acts: acts });
      ai.busy = false;
      ui.chatScroll = true;
      App.save();
      App.render();
    }
    function step() {
      steps++;
      if (steps > ai.MAX_STEPS) { finish('⚠️ به حد مجاز مراحل رسیدم. درخواست را کوچک‌تر یا مشخص‌تر کن.'); return Promise.resolve(); }
      return ai.request({
        max_tokens: ai.MAX_TOKENS,
        system: ai.system(),
        messages: messages,
        tools: ai.toolDefs()
      }).then(function (r) {
        if (!r.ok) { finish('⚠️ ' + r.error); return; }
        var blocks = Array.isArray(r.data.content) ? r.data.content : [];
        var uses = blocks.filter(function (b) { return b && b.type === 'tool_use' && b.name; });
        if (uses.length) {
          messages.push({ role: 'assistant', content: blocks });
          var results = uses.map(function (tu) {
            var out = ai.runTool(tu.name, tu.input, {});
            if (out.label && out.label !== tu.name) acts.push(makeAct(tu.name, out));
            return { type: 'tool_result', tool_use_id: tu.id, content: JSON.stringify(out.result).slice(0, 4000), is_error: !out.ok };
          });
          messages.push({ role: 'user', content: results });
          return step();
        }
        finish(ai.textOf(r.data) || 'پاسخی نداشتم؛ دوباره بپرس.');
      });
    }
    step().catch(function (e) {
      App.logError(e);
      finish('⚠️ خطای داخلی در مشاور. کارت‌های بالا نشان می‌دهند چه چیزی تغییر کرده است.');
    });
  };

  // پرسش آماده: از هر تب
  ai.quick = function (q, o) {
    o = o || {};
    if (q === 'examprep' && o.key) return ai.askExam(o.key);
    var item = QB_BY[q];
    if (!item) return;
    ai.send(item[2], { quick: q });
  };

  // تحلیل یک آزمون
  ai.askExam = function (id) {
    var e = S().exams.find(function (x) { return String(x.id) === String(id); });
    if (!e) { App.alert('این آزمون پیدا نشد'); return; }
    var subs = (e.sub || []).map(function (x) { return x.s + ': ' + x.c + ' از ' + x.t; }).join('، ');
    var txt = 'آزمون «' + (e.n || 'بی‌نام') + '» به تاریخ ' + u.jd(e.d) + ': ' + e.c + ' درست، ' + e.w + ' غلط از ' + e.t + ' (' + e.p + '٪)' +
      (e.z ? '، تراز ' + e.z : '') + (subs ? '. تفکیک درس‌ها: ' + subs : '') + (e.tu ? '. زمان صرف‌شده: ' + e.tu + ' دقیقه' : '') + '. ' +
      'تحلیل کن: نقاط قوت و ضعف، الگوی احتمالی خطا، و سه کار مشخص برای آزمون بعدی. فقط از همین داده‌ها استفاده کن.';
    ai.send(txt, { quick: 'exam' });
  };

  // توضیح یک سؤال تستی (بر پایه‌ی کلید و متن سؤال)
  ai.explainQuestion = function (quizId, i) {
    var q = (S().quizzes || []).find(function (x) { return String(x.id) === String(quizId); });
    if (!q || !q.questions[i]) { App.alert('این سؤال پیدا نشد'); return; }
    var item = q.questions[i];
    var last = (q.attempts || [])[q.attempts.length - 1];
    var mine = last && last.ans ? String(last.ans).charAt(i) : '';
    var txt = 'از آزمون تستی «' + q.title + '»، سؤال ' + u.fa(i + 1) + ': کلید درست ' + item.a + (item.q ? '، متن سؤال: ' + item.q : '') +
      (mine ? '، پاسخ من: ' + mine : '') + '. کوتاه و گام‌به‌گام توضیح بده چرا پاسخ درست همین است و خطای احتمالی من چه بوده (حداکثر ۸ جمله). ' +
      (item.q ? '' : 'متن سؤال را ندارم؛ اگر موضوع معلوم است، بر اساس آن توضیح بده و بگو متن سؤال را بفرستم تا دقیق‌تر شود.');
    ai.send(txt, { quick: 'explain' });
  };

  // ---- تجزیه‌ی متن آزاد و برنامه (بدون ابزار؛ خروجی JSON و پیش‌نمایش) ----
  function subjectsLine() { return D.allSubjects().join('، '); }
  function voiceSystem() {
    return 'تو تبدیل‌کنندهٔ متن فارسی یک دانش‌آموز به فهرست ثبت‌ها هستی. فقط یک آرایه‌ی JSON داخل بلوک ```json بده و هیچ توضیح دیگری ننویس. ' +
      'هر عنصر یکی از این شکل‌هاست: ' +
      '{"k":"log","s":"درس","m":دقیقه,"t":تعداد تست,"ok":تعداد درست,"c":false}؛ ' +
      '{"k":"todo","t":"متن"}؛ {"k":"bl","s":"درس","t":"متن"}؛ {"k":"wk","s":"درس","t":"متن"}؛ {"k":"jr","jk":"p|w|n","t":"متن"}؛ ' +
      '{"k":"exam","s":"درس یا خالی","t":تعداد سؤال,"c":درست,"w":غلط,"z":تراز}؛ {"k":"goal","m":دقیقه}؛ {"k":"wake","v":"HH:MM"}؛ {"k":"sleep","v":"HH:MM"}؛ ' +
      '{"k":"busy","t":"عنوان","s0":"HH:MM","e0":"HH:MM","r":"all یا today یا رقم 0 تا 6 (0 یکشنبه)"}؛ {"k":"tstart","s":"درس","c":false}؛ {"k":"tstop"}. ' +
      'کلید c در log یعنی کلاس. نام درس را دقیقاً از این فهرست بگیر: ' + subjectsLine() + '. اگر چیزی نبود، آرایه‌ی خالی [] بده.';
  }
  function programSystem() {
    return 'تو تبدیل‌کنندهٔ برنامه‌ی مطالعاتی یا جدول آزمون به JSON هستی. فقط یک JSON داخل بلوک ```json بده. ' +
      'اگر برنامه‌ی هفتگی است: {"weekly":[{"day":0 تا 6 (0 یکشنبه، 6 شنبه),"s0":"HH:MM","e0":"HH:MM","t":"عنوان","k":"study|class|other"}]}. ' +
      'اگر آزمون‌های آینده است: [{"k":"ex2","n":"نام","d":"YYYY-MM-DD میلادی","r":[{"g":پایه,"s":"درس دقیق","a":فصل از,"b":فصل تا}]}]. ' +
      'نام درس را دقیقاً از این فهرست بگیر: ' + subjectsLine() + '. اگر چیزی نبود، [] بده.';
  }
  ai.parseVoice = function (txt) {
    if (!ai.configured()) { App.act['vp-go'](); return; }
    App.toast('مشاور در حال خواندن متن است…');
    ai.oneShot(voiceSystem(), txt, { max: 1500 }).then(function (r) {
      if (!r.ok) { App.alert(r.error); return; }
      var J = pl.jsonOf(r.text);
      var list = Array.isArray(J) ? pl.normActs(J) : [];
      if (!list.length) { App.alert('چیزی پیدا نشد؛ جمله‌ها را کامل‌تر بگو.'); return; }
      App.ui.vp = list;
      App.render();
    });
  };
  ai.parseProgram = function (t) {
    if (!ai.configured()) { App.act['prog-go'](); return; }
    App.toast('مشاور در حال خواندن برنامه است…');
    ai.oneShot(programSystem(), t, { max: 3000 }).then(function (r) {
      if (!r.ok) { App.alert(r.error); return; }
      var J = pl.jsonOf(r.text);
      if (J && J.weekly) {
        if (!App.confirm('برنامه‌ی هفتگی فعلی با این برنامه جایگزین شود؟')) return;
        var n = pl.wpApply(J); App.save(); App.render();
        App.toast(n ? '✅ برنامه‌ی هفتگی ثبت شد (' + u.fa(n) + ' بلوک)' : 'برنامه‌ی هفتگی معتبر پیدا نشد');
        return;
      }
      var list = Array.isArray(J) ? pl.normActs(J) : [];
      if (!list.length) { App.alert('ساختار برنامه پیدا نشد؛ روز و ساعت را واضح‌تر بنویس یا از پرامپت PDF استفاده کن.'); return; }
      App.ui.vp = list;
      App.go('today');
      App.toast('پیش‌نمایش در کارت 🎙 امروز آماده است؛ بررسی کن و «ثبت همه» را بزن', { ms: 6000 });
    });
  };
  ai.hasJSON = function (text) { return !!pl.jsonOf(text); };

  // ---- اجزای گفتگو ----
  function renderAct(a) {
    if (a.name === 'proposal') {
      var p = ai.proposals[a.uid];
      if (p && p.status === 'pending') {
        return '<div class="act-card proposal"><div><b>📋 پیشنهاد گروهی (' + u.fa(p.changes.length) + ' مورد)</b><p>' + u.esc(p.summary) + '</p></div>' +
          '<div class="row0 wrap">' + App.sm('✅ اعمال همه', 'ai-apply', { key: a.uid }, 'accent') + App.sm('✕ لغو', 'ai-cancel', { key: a.uid }) + '</div></div>';
      }
      return '<div class="act-card"><span class="mu">' + u.esc(a.label) + '</span></div>';
    }
    if (a.name.indexOf('nav:') === 0) {
      var tabName = a.name.slice(4), names = { today: 'امروز', plan: 'برنامه', subj: 'دروس', exam: 'آزمون', stat: 'آمار', timer: 'تایمر', settings: 'تنظیمات' };
      return '<div class="act-card">' + App.sm('▶ رفتن به ' + (names[tabName] || ''), 'ai-go', { tab: tabName }, 'accent') + '</div>';
    }
    var undo = a.uid && ai.undoAvailable(a.uid) ? App.sm('↩️ برگردان', 'ai-undo', { key: a.uid }) : '';
    return '<div class="act-card ' + (a.ok ? 'ok' : 'fail') + '"><span>' + u.esc(a.label) + '</span>' + undo + '</div>';
  }
  function renderMsg(m) {
    var user = m.r === 'user';
    var imgs = m.imgs ? '<div class="mu">📷 ' + u.fa(m.imgs) + ' عکس پیوست</div>' : '';
    var text = user ? '<div class="msg-text">' + u.esc(m.c).replace(/\n/g, '<br>') + '</div>' : '<div class="msg-text md">' + ai.md(m.c) + '</div>';
    var acts = (m.acts || []).map(renderAct).join('');
    var tools = user ? '' : '<div class="msg-tools">' + App.sm('📋 کپی', 'chat-copy', { key: m.id }) + App.sm('🧠 ذخیره در حافظه', 'chat-mem', { key: m.id }) +
      (ai.hasJSON(m.c) ? App.sm('🗓 ثبت JSON', 'chat-json', { key: m.id }) : '') + '</div>';
    return '<article class="msg ' + (user ? 'user' : 'assistant') + '" aria-label="' + (user ? 'پیام تو' : 'پاسخ مشاور') + '">' +
      '<div class="msg-who mu">' + (user ? '🙋 تو' : '💬 مشاور') + '</div>' + imgs + text + acts + tools + '</article>';
  }

  // پنجره‌ی گفتگو (تب و برگه‌ی شناور): وضعیت، پرسش‌های آماده، گفتگو، کادر پیام
  App.views.chatPanel = function (o) {
    o = o || {};
    var compact = !!o.compact;
    var f = App.form('chatf', { txt: '' });
    var list = S().chat || [];
    var welcome = 'سلام! من مشاور تحصیلی تو هستم. دربارهٔ برنامه، درس‌ها، آزمون‌ها یا انگیزه حرف بزن.' +
      (ai.configured() ? '\n\nمی‌توانم با ابزار، ثبت‌ها را هم برایت انجام دهم؛ هر تغییر بزرگ را اول نشانت می‌دهم و تا تأیید نکنی اعمال نمی‌شود.' : '');
    var body = list.length ? list.map(renderMsg).join('') : '<div class="msg assistant"><div class="msg-text md">' + ai.md(welcome) + '</div></div>';
    if (ai.busy) body += '<div class="msg assistant typing" role="status"><span class="mu">در حال پاسخ</span><span class="dots" aria-hidden="true"><i></i><i></i><i></i></span><span class="mu typing-note">ممکن است چند ثانیه طول بکشد</span></div>';
    var quick = (compact ? QB.slice(0, 5) : QB).map(function (q) { return App.sm(q[1], 'ai-ask', { q: q[0] }, 'qchip'); }).join('');
    var thumbs = ai.pending.length ? '<div class="chat-thumbs" aria-label="عکس‌های پیوست">' + ai.pending.map(function (p) {
      return '<figure class="thumb"><img src="' + p.thumb + '" alt="عکس پیوست: ' + u.esc(p.name) + '"><figcaption class="sr">' + u.esc(p.name) + '</figcaption>' +
        '<button type="button" class="thumb-x" data-act="chat-photo-x" data-key="' + u.esc(p.id) + '" aria-label="حذف این عکس">✕</button></figure>';
    }).join('') + '</div>' : '';
    var line = aiStatusLine(compact);
    // صفحه‌ی کامل: متن وضعیت یک دکمه‌ی کوچک است؛ با لمس، تنظیمات مشاور باز می‌شود
    var notice = !line ? '' : compact ? '<div class="notice-inline" role="status">' + u.esc(line) + ' ' + App.sm('🔑 صفحه‌ی مشاور', 'ai-go', { tab: 'ai' }) + '</div>' :
      '<div class="ai-tipline" role="status"><button type="button" class="cz-pill ai-tip" data-act="ai-open-setup" title="' + u.esc(line) + '" aria-label="' + u.esc(line) + '">🔑 کلید و مدل</button></div>';
    var model = (ai.config() || {}).model || 'مدل';
    var clear = !compact && list.length ? '<button type="button" class="cz-round chat-clear" data-act="chat-clear" aria-label="پاک‌کردن گفتگو" title="پاک‌کردن گفتگو">🗑</button>' : '';
    return '<div class="chat' + (compact ? ' chat-compact' : '') + '">' + notice +
      '<div class="chips-row chat-quick" role="group" aria-label="پرسش‌های آماده">' + quick + '</div>' +
      '<div class="chat-log" id="chat-log" role="log" aria-live="polite" aria-relevant="additions" aria-label="گفتگو با مشاور">' + body + '</div>' +
      '<div class="composer">' + thumbs +
        '<textarea id="chat-in" class="ta chat-ta" data-f="chatf.txt" rows="2" maxlength="4000" placeholder="بپرس، بنویس یا عکس برنامه‌ات را بفرست…" aria-label="پیام به مشاور">' + u.esc(f.txt) + '</textarea>' +
        '<div class="cz-bar">' +
          '<div class="cz-left">' +
            '<button type="button" class="cz-round" data-act="chat-photo" aria-label="افزودن عکس" title="عکس">＋</button>' +
            '<button type="button" class="cz-round" data-act="chat-mic" aria-label="میکروفون" title="میکروفون">🎙</button>' +
            clear +
            (compact ? '' : '<button type="button" class="cz-pill" data-act="ai-open-setup" dir="ltr" title="تغییر مدل یا سرویس">' + u.esc(model) + '</button>') +
          '</div>' +
          '<button type="button" class="cz-send chat-send" data-act="chat-send" aria-label="ارسال"' + (ai.busy ? ' disabled' : '') + '>➤</button>' +
        '</div>' +
        '<input type="file" id="chat-file" accept="image/*" multiple hidden>' +
      '</div></div>';
  };
  // ---- کنش‌ها ----
  App.act['ai-ask'] = function (el) {
    var q = el.getAttribute('data-q');
    var key = el.getAttribute('data-key');
    ai.quick(q, { key: key });
  };
  App.act['chat-send'] = function () { ai.send(App.form('chatf', {}).txt); };
  App.act['chat-mic'] = function (el) { if (App.voice) App.voice.toggle(el, 'chat-in', 'chatf.txt'); };
  App.act['chat-clear'] = function () {
    if (!App.confirm('گفتگو پاک شود؟ (داده‌های مطالعه دست نمی‌خورد)')) return;
    S().chat = [];
    App.save(); App.render();
  };
  App.act['chat-copy'] = function (el) {
    var m = findMsg(el.getAttribute('data-key'));
    if (!m) return;
    u.copyText(m.c).then(function (ok) { App.toast(ok ? 'کپی شد ✅' : 'کپی انجام نشد'); });
  };
  App.act['chat-mem'] = function (el) {
    var m = findMsg(el.getAttribute('data-key'));
    if (!m) return;
    var r = st.addMemory(m.c.slice(0, 240));
    if (!r) { App.alert('ذخیره نشد'); return; }
    App.save(); App.toast('به حافظه‌ی مشاور اضافه شد');
  };
  App.act['chat-json'] = function (el) {
    var m = findMsg(el.getAttribute('data-key'));
    var J = m ? pl.jsonOf(m.c) : null;
    if (!J) { App.alert('JSON معتبری در این پیام پیدا نشد'); return; }
    if (J.weekly) {
      if (!App.confirm('برنامه‌ی هفتگی فعلی با این جایگزین شود؟')) return;
      var n = pl.wpApply(J); App.save(); App.render();
      App.toast(n ? '✅ برنامه‌ی هفتگی ثبت شد' : 'برنامه‌ی معتبر نبود');
      return;
    }
    if (Array.isArray(J)) {
      App.ui.vp = pl.normActs(J);
      App.go('today');
      App.toast('پیش‌نمایش در کارت 🎙 امروز؛ بررسی و ثبت کن', { ms: 6000 });
      return;
    }
    App.alert('ساختار JSON شناخته نشد');
  };
  App.act['ai-undo'] = function (el) {
    var uid = el.getAttribute('data-key');
    var r = ai.undo(uid);
    if (!r.ok) { App.alert(r.error); App.render(); return; }
    var a = findAct(uid);
    if (a) { a.uid = ''; a.ok = 0; a.label = '↩️ برگردانده شد: ' + a.label; }
    App.save(); App.render(); App.toast('برگردانده شد');
  };
  App.act['ai-apply'] = function (el) {
    var pid = el.getAttribute('data-key');
    var r = ai.applyProposal(pid);
    var a = findAct(pid);
    if (!r.ok) { App.alert(r.error); if (a) { a.name = 'proposal-done'; } App.save(); App.render(); return; }
    if (a) {
      a.name = 'proposal-done';
      a.ok = r.failed.length ? 0 : 1;
      a.label = '✅ اعمال شد: ' + u.fa(r.done) + ' مورد' + (r.failed.length ? ' · ' + u.fa(r.failed.length) + ' مورد نشد' : '') + ' — ' + ai.proposals[pid].summary;
      a.uid = r.uid || '';
    }
    App.save(); App.render();
    App.toast('پیشنهاد اعمال شد: ' + u.fa(r.done) + ' مورد', { action: r.uid ? { label: '↩️ برگردان همه', fn: function () { App.act['ai-undo']({ getAttribute: function () { return r.uid; } }); } } : undefined });
  };
  App.act['ai-cancel'] = function (el) {
    var pid = el.getAttribute('data-key');
    ai.cancelProposal(pid);
    var a = findAct(pid);
    if (a) { a.name = 'proposal-done'; a.ok = 0; a.label = '↩️ لغو شد — ' + (ai.proposals[pid] ? ai.proposals[pid].summary : a.label); }
    App.save(); App.render();
  };
  App.act['ai-go'] = function (el) { App.go(el.getAttribute('data-tab')); };

  // اسکرول گفتگو به آخرین پیام، بعد از رندرهایی که خودِ گفتگو باعثشان است
  App.afterRender = function () {
    if (!ui.chatScroll) return;
    ui.chatScroll = false;
    var l = document.getElementById('chat-log');
    if (l) l.scrollTop = l.scrollHeight;
  };
  // Ctrl+Enter در کادر گفتگو: ارسال
  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Enter' || !(e.ctrlKey || e.metaKey)) return;
    var el = e.target;
    if (!el || el.id !== 'chat-in') return;
    e.preventDefault();
    ai.send(App.form('chatf', {}).txt);
  });
})();
