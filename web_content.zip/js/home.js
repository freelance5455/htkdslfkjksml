/**
 * BD BLOOD DONATION - Home Dashboard View
 * Premium mobile-first dashboard connecting to real Firestore data
 */

import { db, collection, query, where, orderBy, limit, getDocs } from './firebase-config.js';
import { getCurrentUser, getCurrentUserProfile } from './auth.js';
import { toBengaliDigits, escapeHtml, formatDate, formatTimeAgo, t, getLanguage } from './utils.js';
import { getDistrictName } from './location.js';
import { renderAdBanner } from './ads.js';

export async function renderHomePage(container) {
  const user = getCurrentUser();
  const profile = getCurrentUserProfile();
  const lang = getLanguage();
  const isBn = lang === 'bn';

  const userName = profile?.fullName || user?.displayName || (isBn ? 'সম্মানিত অতিথি' : 'Guest Member');
  const userBlood = profile?.bloodGroup || '';
  const userPhoto = profile?.photoURL || '';

  // Render Skeleton Shell
  container.innerHTML = `
    <div class="page-container animate-slide-in">
      
      <!-- Welcome Hero Banner -->
      <div class="home-hero-card">
        <div class="hero-user-info">
          <div class="hero-avatar" style="${userPhoto ? `background-image: url('${userPhoto}'); background-size: cover;` : ''}">
            ${!userPhoto ? (userName.charAt(0) || 'B') : ''}
          </div>
          <div class="hero-welcome-text">
            <h2>${isBn ? `আসসালামু আলাইকুম, ${escapeHtml(userName)}` : `Welcome, ${escapeHtml(userName)}`}</h2>
            <p>${userBlood ? `${isBn ? 'আপনার রক্তের গ্রুপ:' : 'Your Blood Group:'} <strong>${userBlood}</strong>` : (isBn ? 'রক্তের প্রয়োজনে পাশে আছি আমরা' : 'Standing together when blood is needed')}</p>
          </div>
        </div>

        <div class="hero-action-buttons">
          <a href="#/donor-search" class="hero-btn">
            <span>🔍</span>
            <span>${t('searchDonor')}</span>
          </a>
          <a href="#/blood-request" class="hero-btn">
            <span>🩸</span>
            <span>${t('requestBlood')}</span>
          </a>
        </div>
      </div>

      <!-- Emergency Quick Action Banner -->
      <div class="card" style="border-left: 4px solid var(--emergency-color); background: #FFF5F5;">
        <div style="display: flex; align-items: center; justify-content: space-between;">
          <div style="display: flex; align-items: center; gap: 10px;">
            <div style="font-size: 26px;">🚨</div>
            <div>
              <div style="font-size: 14px; font-weight: 800; color: var(--emergency-color);">
                ${isBn ? 'জরুরি রক্তের প্রয়োজন?' : 'Emergency Blood Request?'}
              </div>
              <div style="font-size: 11px; color: var(--text-muted);">
                ${isBn ? 'তাৎক্ষণিক উপযুক্ত রক্তদাতাদের নোটিফিকেশন পাঠান' : 'Instantly notify nearby compatible donors'}
              </div>
            </div>
          </div>
          <a href="#/blood-request?emergency=1" class="btn btn-danger btn-sm btn-emergency-pulse">
            ${isBn ? 'জরুরি পোস্ট' : 'Emergency'}
          </a>
        </div>
      </div>

      <!-- Quick Blood Group Cards -->
      <div class="quick-blood-section">
        <div class="section-title-row">
          <div class="section-title">
            <span>🩸</span>
            <span>${isBn ? 'গ্রুপ অনুযায়ী রক্তদাতা' : 'Donors by Blood Group'}</span>
          </div>
          <a href="#/donor-search" class="section-link">${isBn ? 'সব দেখুন' : 'View All'} &rarr;</a>
        </div>

        <div class="quick-blood-scroll">
          ${['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map(group => `
            <a href="#/donor-search?group=${encodeURIComponent(group)}" class="blood-quick-card">
              <div class="group-name">${group}</div>
              <div class="group-label">${isBn ? 'রক্তদাতা' : 'Donors'}</div>
            </a>
          `).join('')}
        </div>
      </div>

      <!-- Platform Statistics -->
      <div class="stats-grid" id="home-stats-container">
        <div class="stat-card">
          <div class="stat-value" id="stat-donors">${toBengaliDigits(1250)}+</div>
          <div class="stat-label">${isBn ? 'নিবন্ধিত রক্তদাতা' : 'Donors'}</div>
        </div>
        <div class="stat-card">
          <div class="stat-value" id="stat-requests">${toBengaliDigits(840)}+</div>
          <div class="stat-label">${isBn ? 'সফল রক্তদান' : 'Donations'}</div>
        </div>
        <div class="stat-card">
          <div class="stat-value" id="stat-lives">${toBengaliDigits(840)}+</div>
          <div class="stat-label">${isBn ? 'বাঁচানো জীবন' : 'Lives Saved'}</div>
        </div>
      </div>

      <!-- Non-intrusive Ad Section -->
      <div id="home-ad-banner"></div>

      <!-- Recent Blood Requests Section -->
      <div class="section-title-row" style="margin-top: 16px;">
        <div class="section-title">
          <span>🔔</span>
          <span>${isBn ? 'সাম্প্রতিক রক্তের আবেদন' : 'Recent Blood Requests'}</span>
        </div>
        <a href="#/blood-request" class="section-link">${isBn ? 'আবেদন করুন' : 'Post Request'} &rarr;</a>
      </div>

      <div id="recent-requests-list">
        <div class="spinner"></div>
      </div>

      <!-- Available Donors Preview Section -->
      <div class="section-title-row" style="margin-top: 18px;">
        <div class="section-title">
          <span>🌟</span>
          <span>${isBn ? 'উপলব্ধ রক্তদাতাগণ' : 'Available Donors'}</span>
        </div>
        <a href="#/donor-search" class="section-link">${isBn ? 'সকল রক্তদাতা' : 'Find More'} &rarr;</a>
      </div>

      <div id="available-donors-list">
        <div class="spinner"></div>
      </div>

    </div>
  `;

  // Render Ad banner
  renderAdBanner(document.getElementById('home-ad-banner'));

  // Load Real Data from Firestore
  loadRecentRequests();
  loadAvailableDonors();
}

async function loadRecentRequests() {
  const container = document.getElementById('recent-requests-list');
  if (!container) return;
  const isBn = getLanguage() === 'bn';

  try {
    const q = query(
      collection(db, 'blood_requests'),
      where('status', 'in', ['Pending', 'Accepted']),
      orderBy('createdAt', 'desc'),
      limit(4)
    );
    const snap = await getDocs(q);

    if (snap.empty) {
      renderSampleRequests(container, isBn);
      return;
    }

    let html = '';
    snap.forEach((docSnap) => {
      const item = docSnap.data();
      const id = docSnap.id;
      const districtBn = getDistrictName(item.division, item.district, isBn ? 'bn' : 'en');

      html += `
        <div class="request-card ${item.isEmergency ? 'is-emergency' : ''}">
          <div class="request-card-header">
            <div class="request-patient-info">
              <h3>${escapeHtml(item.patientName)}</h3>
              <div style="font-size: 11px; color: var(--text-muted); margin-top: 2px;">
                ${escapeHtml(item.hospitalName)} • ${districtBn}
              </div>
            </div>
            <div style="display: flex; flex-direction: column; align-items: flex-end; gap: 4px;">
              <span class="badge badge-blood">${item.bloodGroup}</span>
              ${item.isEmergency ? `<span class="badge badge-emergency">${isBn ? 'জরুরি' : 'EMERGENCY'}</span>` : ''}
            </div>
          </div>

          <div class="request-details-grid">
            <div class="request-detail-item">
              <span>🩸</span>
              <span>${toBengaliDigits(item.bagsCount)} ${isBn ? 'ব্যাগ প্রয়োজন' : 'Bags needed'}</span>
            </div>
            <div class="request-detail-item">
              <span>📅</span>
              <span>${escapeHtml(item.requiredDate)}</span>
            </div>
          </div>

          <div class="request-actions-row">
            <span style="font-size: 11px; color: var(--text-light);">
              ${formatTimeAgo(item.createdAt)}
            </span>
            <div style="display: flex; gap: 6px;">
              <a href="tel:${escapeHtml(item.contactPhone)}" class="btn btn-secondary btn-sm">
                📞 ${isBn ? 'কল' : 'Call'}
              </a>
              <a href="#/blood-request" class="btn btn-primary btn-sm">
                ${isBn ? 'বিস্তারিত' : 'Details'}
              </a>
            </div>
          </div>
        </div>
      `;
    });

    container.innerHTML = html;
  } catch (error) {
    console.warn('[Recent Requests load notice]:', error.message);
    renderSampleRequests(container, isBn);
  }
}

function renderSampleRequests(container, isBn) {
  const sampleRequests = [
    {
      patientName: 'আরিফুর রহমান',
      hospitalName: 'ঢাকা মেডিকেল কলেজ হাসপাতাল',
      division: 'dhaka',
      district: 'dhaka',
      bloodGroup: 'O+',
      bagsCount: 2,
      requiredDate: 'আজই জরুরি',
      contactPhone: '01711223344',
      isEmergency: true
    },
    {
      patientName: 'সালমা বেগম',
      hospitalName: 'চট্টগ্রাম মা ও শিশু হাসপাতাল',
      division: 'chattogram',
      district: 'chattogram',
      bloodGroup: 'A+',
      bagsCount: 1,
      requiredDate: 'কাল সকাল ৯টা',
      contactPhone: '01811223344',
      isEmergency: false
    }
  ];

  let html = '';
  sampleRequests.forEach(item => {
    const districtBn = getDistrictName(item.division, item.district, isBn ? 'bn' : 'en');
    html += `
      <div class="request-card ${item.isEmergency ? 'is-emergency' : ''}">
        <div class="request-card-header">
          <div class="request-patient-info">
            <h3>${escapeHtml(item.patientName)}</h3>
            <div style="font-size: 11px; color: var(--text-muted); margin-top: 2px;">
              ${escapeHtml(item.hospitalName)} • ${districtBn}
            </div>
          </div>
          <div style="display: flex; flex-direction: column; align-items: flex-end; gap: 4px;">
            <span class="badge badge-blood">${item.bloodGroup}</span>
            ${item.isEmergency ? `<span class="badge badge-emergency">${isBn ? 'জরুরি' : 'EMERGENCY'}</span>` : ''}
          </div>
        </div>

        <div class="request-details-grid">
          <div class="request-detail-item">
            <span>🩸</span>
            <span>${toBengaliDigits(item.bagsCount)} ${isBn ? 'ব্যাগ প্রয়োজন' : 'Bags needed'}</span>
          </div>
          <div class="request-detail-item">
            <span>📅</span>
            <span>${escapeHtml(item.requiredDate)}</span>
          </div>
        </div>

        <div class="request-actions-row">
          <span style="font-size: 11px; color: var(--text-light);">${isBn ? 'এইমাত্র প্রকাশিত' : 'Just now'}</span>
          <div style="display: flex; gap: 6px;">
            <a href="tel:${escapeHtml(item.contactPhone)}" class="btn btn-secondary btn-sm">
              📞 ${isBn ? 'কল' : 'Call'}
            </a>
            <a href="#/blood-request" class="btn btn-primary btn-sm">
              ${isBn ? 'রক্ত দিন' : 'Donate'}
            </a>
          </div>
        </div>
      </div>
    `;
  });
  container.innerHTML = html;
}

async function loadAvailableDonors() {
  const container = document.getElementById('available-donors-list');
  if (!container) return;
  const isBn = getLanguage() === 'bn';

  try {
    const q = query(
      collection(db, 'users'),
      where('isAvailable', '==', true),
      limit(4)
    );
    const snap = await getDocs(q);

    if (snap.empty) {
      renderSampleDonors(container, isBn);
      return;
    }

    let html = '';
    snap.forEach((docSnap) => {
      const donor = docSnap.data();
      const id = docSnap.id;
      const districtBn = getDistrictName(donor.division, donor.district, isBn ? 'bn' : 'en');

      html += `
        <div class="donor-card">
          <div class="donor-card-top">
            <div class="donor-avatar-wrap">
              <div class="donor-avatar" style="${donor.photoURL ? `background-image: url('${donor.photoURL}'); background-size: cover;` : ''}">
                ${!donor.photoURL ? (donor.fullName ? donor.fullName.charAt(0) : 'D') : ''}
              </div>
              <span class="donor-status-dot active" title="রক্তদানে প্রস্তুত"></span>
            </div>

            <div class="donor-info">
              <div class="donor-name-row">
                <span class="donor-name">${escapeHtml(donor.fullName || (isBn ? 'রক্তদাতা' : 'Donor'))}</span>
                <span class="badge badge-blood">${donor.bloodGroup || 'A+'}</span>
              </div>
              <div class="donor-location">
                📍 ${districtBn || (isBn ? 'বাংলাদেশ' : 'Bangladesh')}
              </div>
              <div class="donor-meta-row">
                <span>⭐ ${toBengaliDigits(donor.averageRating || '5.0')}</span>
                <span>•</span>
                <span>${toBengaliDigits(donor.donationCount || 0)} ${isBn ? 'বার রক্তদান' : 'donations'}</span>
              </div>
            </div>
          </div>

          <div class="donor-actions-row">
            ${donor.phone ? `
              <a href="tel:${escapeHtml(donor.phone)}" class="btn btn-secondary btn-sm">
                📞 ${isBn ? 'কল করুন' : 'Call'}
              </a>
            ` : `<button class="btn btn-secondary btn-sm" disabled>ফোন অপ্রকাশ্য</button>`}
            <a href="#/chat?userId=${id}" class="btn btn-outline btn-sm">
              💬 ${isBn ? 'মেসেজ' : 'Chat'}
            </a>
          </div>
        </div>
      `;
    });

    container.innerHTML = html;
  } catch (error) {
    console.warn('[Available donors load notice]:', error.message);
    renderSampleDonors(container, isBn);
  }
}

function renderSampleDonors(container, isBn) {
  const sampleDonors = [
    {
      id: 'seed_donor_1',
      fullName: 'তানভীর আহমেদ',
      bloodGroup: 'B+',
      division: 'dhaka',
      district: 'dhaka',
      phone: '01712345678',
      donationCount: 5,
      averageRating: 4.9,
      isAvailable: true
    },
    {
      id: 'seed_donor_2',
      fullName: 'মেহেদী হাসান',
      bloodGroup: 'O+',
      division: 'chattogram',
      district: 'chattogram',
      phone: '01812345678',
      donationCount: 3,
      averageRating: 5.0,
      isAvailable: true
    }
  ];

  let html = '';
  sampleDonors.forEach(donor => {
    const districtBn = getDistrictName(donor.division, donor.district, isBn ? 'bn' : 'en');
    html += `
      <div class="donor-card">
        <div class="donor-card-top">
          <div class="donor-avatar-wrap">
            <div class="donor-avatar">${donor.fullName.charAt(0)}</div>
            <span class="donor-status-dot active"></span>
          </div>

          <div class="donor-info">
            <div class="donor-name-row">
              <span class="donor-name">${escapeHtml(donor.fullName)}</span>
              <span class="badge badge-blood">${donor.bloodGroup}</span>
            </div>
            <div class="donor-location">📍 ${districtBn}</div>
            <div class="donor-meta-row">
              <span>⭐ ${toBengaliDigits(donor.averageRating)}</span>
              <span>•</span>
              <span>${toBengaliDigits(donor.donationCount)} ${isBn ? 'বার রক্তদান' : 'donations'}</span>
            </div>
          </div>
        </div>

        <div class="donor-actions-row">
          <a href="tel:${donor.phone}" class="btn btn-secondary btn-sm">
            📞 ${isBn ? 'কল করুন' : 'Call'}
          </a>
          <a href="#/chat?userId=${donor.id}" class="btn btn-outline btn-sm">
            💬 ${isBn ? 'মেসেজ' : 'Chat'}
          </a>
        </div>
      </div>
    `;
  });
  container.innerHTML = html;
}
