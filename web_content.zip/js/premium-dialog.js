/* NetEarn Pro - Central Premium Dialog System */
(function () {
  'use strict';

  if (window.NetEarnDialog) return;

  const state = { queue: [], active: null };
  const dialogCssHref = (() => {
    const script = document.currentScript;
    if (script && script.src) {
      return new URL('../css/premium-dialog.css', script.src).href;
    }
    return 'css/premium-dialog.css';
  })();

  const escapeHtml = (value) => String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');

  const formatMessage = (value) => escapeHtml(value)
    .replace(/\r?\n/g, '<br>')
    .replace(/  /g, '&nbsp; ');

  function classify(message, kind) {
    const text = String(message || '').toLowerCase();
    if (kind === 'prompt') return 'input';
    if (/logout|delete|reject|remove|disable|cancel|বাতিল|ডিলিট|রিজেক্ট|মুছে|বন্ধ/.test(text)) return 'danger';
    if (/warning|⚠|সতর্ক|নিশ্চিত/.test(text)) return 'warning';
    if (/error|failed|fail|invalid|wrong|not found|does not|cannot|could not|সমস্যা|ভুল|ব্যর্থ|হয়নি|হয়নি|সঠিক নয়|সঠিক নয়|মিল নেই|দুর্বল|পাওয়া যায়নি|পাওয়া যায়নি|যায়নি|যায়নি|যাচাই করা যাচ্ছে না|পূরণ করুন/.test(text)) return 'error';
    if (/success|successful|সফল|completed|complete|সম্পন্ন|approved|approve/.test(text)) return 'success';
    return 'info';
  }

  function iconFor(type) {
    return ({
      success: '✓',
      error: '!',
      warning: '!',
      danger: '↗',
      input: '⌕',
      info: 'i'
    })[type] || 'i';
  }

  function titleFor(message, kind, type) {
    const text = String(message || '').toLowerCase();
    if (kind === 'prompt') {
      if (/password/.test(text)) return 'Security Check';
      if (/email/.test(text)) return 'Email Confirmation';
      if (/কারণ/.test(text)) return 'Rejection Reason';
      return 'Enter Information';
    }
    if (type === 'danger') return 'Please Confirm';
    if (type === 'success') return 'Success';
    if (type === 'error') return 'Something went wrong';
    if (type === 'warning') return 'Please Confirm';
    return 'NetEarn Pro';
  }

  function actionLabel(message, kind, type) {
    const text = String(message || '').toLowerCase();
    if (kind === 'prompt') return 'Continue';
    if (/logout/.test(text)) return 'Logout';
    if (/delete|ডিলিট|মুছে/.test(text)) return 'Delete';
    if (/reject|রিজেক্ট/.test(text)) return 'Reject';
    if (/approve|approve করবেন/.test(text)) return 'Approve';
    if (/submit/.test(text)) return 'Submit';
    if (type === 'danger') return 'Confirm';
    return 'OK';
  }

  function ensureStyles() {
    if (document.getElementById('nepPremiumDialogStyles')) return;
    const link = document.createElement('link');
    link.id = 'nepPremiumDialogStyles';
    link.rel = 'stylesheet';
    link.href = dialogCssHref;
    document.head.appendChild(link);
  }

  function ensureRoot() {
    let root = document.getElementById('nepPremiumDialogRoot');
    if (root) return root;
    if (!document.body) return null;
    root = document.createElement('div');
    root.id = 'nepPremiumDialogRoot';
    root.className = 'nep-dialog-root';
    root.innerHTML = '<div class="nep-dialog-backdrop"></div><div class="nep-dialog-stage" aria-live="assertive"></div>';
    document.body.appendChild(root);
    return root;
  }

  function closeActive(result) {
    const current = state.active;
    if (!current) return;
    state.active = null;
    const root = document.getElementById('nepPremiumDialogRoot');
    if (root) root.classList.remove('is-open');
    setTimeout(() => {
      if (root) root.querySelector('.nep-dialog-stage').innerHTML = '';
      current.resolve(result);
      showNext();
    }, 160);
  }

  function showNext() {
    if (state.active || !state.queue.length) return;
    const item = state.queue.shift();
    state.active = item;
    ensureStyles();
    const root = ensureRoot();
    if (!root) {
      document.addEventListener('DOMContentLoaded', showNext, { once: true });
      return;
    }
    const type = classify(item.message, item.kind);
    const isCurrentPassword = item.kind === 'prompt' && String(item.message || '').trim() === 'Current Password';
    const isPassword = item.kind === 'prompt' && /password/i.test(String(item.message || ''));
    const title = titleFor(item.message, item.kind, type);
    const primary = actionLabel(item.message, item.kind, type);
    const inputType = isPassword ? 'password' : 'text';

    root.querySelector('.nep-dialog-stage').innerHTML = isCurrentPassword ? `
      <section class="nep-dialog-card nep-dialog-input nep-dialog-current-password" role="dialog" aria-modal="true" aria-labelledby="nepDialogTitle">
        <div class="nep-current-password-title" id="nepDialogTitle">🔐 <span>Current Password</span></div>
        <div class="nep-current-password-subtitle">আপনার বর্তমান Password দিন</div>
        <div class="nep-dialog-input-wrap nep-current-password-wrap">
          <input id="nepDialogInput" class="nep-dialog-input" type="password" autocomplete="current-password" placeholder="•••••••••" />
          <button id="nepPasswordToggle" class="nep-password-toggle" type="button" aria-label="Show password">👁</button>
        </div>
        <div class="nep-dialog-actions">
          <button class="nep-dialog-btn nep-dialog-cancel" type="button">Cancel</button>
          <button class="nep-dialog-btn nep-dialog-primary" type="button">Continue</button>
        </div>
      </section>` : `
      <section class="nep-dialog-card nep-dialog-${type}" role="dialog" aria-modal="true" aria-labelledby="nepDialogTitle">
        <button class="nep-dialog-close" type="button" aria-label="Close">×</button>
        <div class="nep-dialog-icon nep-dialog-icon-${type}">${iconFor(type)}</div>
        <div class="nep-dialog-title" id="nepDialogTitle">${escapeHtml(title)}</div>
        <div class="nep-dialog-message">${formatMessage(item.message)}</div>
        ${item.kind === 'prompt' ? `<div class="nep-dialog-input-wrap"><input id="nepDialogInput" class="nep-dialog-input" type="${inputType}" autocomplete="${isPassword ? 'current-password' : 'off'}" /></div>` : ''}
        <div class="nep-dialog-actions">
          <button class="nep-dialog-btn nep-dialog-cancel" type="button">${item.kind === 'alert' ? 'OK' : 'Cancel'}</button>
          ${item.kind === 'alert' ? '' : `<button class="nep-dialog-btn nep-dialog-primary" type="button">${escapeHtml(primary)}</button>`}
        </div>
      </section>`;

    root.classList.toggle('nep-profile-dialog', location.pathname.toLowerCase().endsWith('/profile.html') || location.pathname.toLowerCase().endsWith('profile.html'));
    root.classList.toggle('nep-settings-dialog', location.pathname.toLowerCase().endsWith('/settings.html') || location.pathname.toLowerCase().endsWith('settings.html'));
    root.classList.toggle('nep-work-services-dialog', /(?:typing(?:-work)?|editing(?:-work)?|formfill(?:-work)?|tasks|submit-task|dailybonus)\.html$/i.test(location.pathname));
    root.classList.toggle('nep-withdraw-dialog', location.pathname.toLowerCase().endsWith('/withdraw.html') || location.pathname.toLowerCase().endsWith('withdraw.html'));
    root.classList.toggle('nep-welcome-bonus-dialog', location.pathname.toLowerCase().endsWith('/welcomebonus.html') || location.pathname.toLowerCase().endsWith('welcomebonus.html'));
    root.classList.toggle('nep-dialog-alert', item.kind === 'alert');
    root.classList.add('is-open');
    const card = root.querySelector('.nep-dialog-card');
    const cancel = root.querySelector('.nep-dialog-cancel');
    const primaryBtn = root.querySelector('.nep-dialog-primary');
    const close = root.querySelector('.nep-dialog-close');
    const input = root.querySelector('#nepDialogInput');
    const passwordToggle = root.querySelector('#nepPasswordToggle');

    const finish = (value) => closeActive(value);
    cancel.addEventListener('click', () => finish(item.kind === 'alert' ? true : (item.kind === 'prompt' ? null : false)));
    if (close) close.addEventListener('click', () => finish(item.kind === 'alert' ? true : (item.kind === 'prompt' ? null : false)));
    if (passwordToggle && input) passwordToggle.addEventListener('click', () => { input.type = input.type === 'password' ? 'text' : 'password'; passwordToggle.textContent = input.type === 'password' ? '👁' : '🙈'; });
    if (primaryBtn) primaryBtn.addEventListener('click', () => finish(item.kind === 'prompt' ? (input ? input.value : '') : true));
    if (input) {
      setTimeout(() => input.focus(), 40);
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') finish(input.value);
        if (e.key === 'Escape') finish(null);
      });
    }
    card.addEventListener('click', (e) => e.stopPropagation());
    root.querySelector('.nep-dialog-backdrop').onclick = () => finish(item.kind === 'alert' ? true : (item.kind === 'prompt' ? null : false));
  }

  function enqueue(kind, message) {
    return new Promise((resolve) => {
      state.queue.push({ kind, message: String(message ?? ''), resolve });
      showNext();
    });
  }

  window.NetEarnDialog = {
    alert(message) { return enqueue('alert', message); },
    confirm(message) { return enqueue('confirm', message); },
    prompt(message) { return enqueue('prompt', message); }
  };

  // Redirect existing native alert() calls without touching their business logic.
  window.alert = function (message) {
    return window.NetEarnDialog.alert(message);
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', ensureStyles, { once: true });
  } else {
    ensureStyles();
  }
})();
