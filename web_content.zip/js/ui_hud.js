'use strict';
/* ---------- in-match HUD ---------- */
const lastTxt={};
function setT(id,v){if(lastTxt[id]!==v){lastTxt[id]=v;$(id).textContent=v}}
function hudUpdate(){
  if(state==='lobby'||!player)return;
  setT('alive',aliveN);setT('kills',player.kills);
  $('hpb').style.width=clamp(player.hp,0,100)+'%';$('arb').style.width=clamp(player.armor,0,100)+'%';
  const s=curS(player),w=WP[s.id],o=player.sl[1-player.cur];
  setT('wtxt',w.n+'  '+s.mag+' / '+player.res+(o?'   ['+WP[o.id].n+']':''));
  const iv=player.inv;
  for(const [id,k] of [['bBand','bandage'],['bMed','medkit'],['bGren','grenade'],['bSmk','smoke'],['bGloo','gloo']]){
    const e=$(id),n=iv[k];e.querySelector('.bd').textContent=n;e.classList.toggle('off',n<=0);
  }
  for(const [id,k,l] of [['cBand','bandage','बैंडेज [H]'],['cMed','medkit','मेडकिट [J]'],['cGren','grenade','ग्रेनेड [G]'],['cSmk','smoke','स्मोक [T]'],['cGloo','gloo','ग्लू वॉल [C]']])
    setT(id,l+' ×'+iv[k]);
  const out=Math.hypot(player.x-z.cx,player.y-z.cy)>z.r;
  let msg;
  if(!player.alive)msg='तुम आउट हो, टीममेट को देख रहे हो';
  else if(out)msg='ज़ोन के बाहर! तुरंत अंदर जाओ';
  else if(z.stage==='wait'){const t=Math.max(0,z.t);msg='ज़ोन '+Math.floor(t/60)+':'+String(Math.floor(t%60)).padStart(2,'0')+' में सिकुड़ेगा'}
  else if(z.stage==='shrink')msg='ज़ोन सिकुड़ रहा है';
  else msg='आख़िरी ज़ोन';
  setT('zmsg',msg);$('zmsg').classList.toggle('bad',out);
  setT('wxl',mp.n+' · '+({clear:'साफ़ मौसम',rain:'बारिश',snow:'बर्फ़बारी',blizzard:'बर्फ़ीला तूफ़ान',sand:'रेतीली आँधी',ash:'राख और धुआँ',mist:'धुंध'}[mp.wx]||''));
  $('bAuto').classList.toggle('on',!!set.autoFire);
  skillHud();
}

/* ---------- lobby stage ---------- */
const lc=$('lc'),lx=lc.getContext('2d');let lobbyT=0,lps=[];
for(let i=0;i<40;i++)lps.push({x:Math.random(),y:Math.random(),s:rnd(.3,1),r:Math.random()});
function lobbyDraw(dt){
  lobbyT+=dt;
  const d=Math.min(devicePixelRatio||1,2),w=lc.clientWidth,hh=lc.clientHeight;
  if(!w||!hh)return;
  if(lc.width!==Math.round(w*d)||lc.height!==Math.round(hh*d)){lc.width=Math.round(w*d);lc.height=Math.round(hh*d)}
  lx.setTransform(d,0,0,d,0,0);
  const bg=lx.createLinearGradient(0,0,0,hh);bg.addColorStop(0,'#241a5e');bg.addColorStop(.55,'#12123a');bg.addColorStop(1,'#1a0f33');lx.fillStyle=bg;lx.fillRect(0,0,w,hh);
  // diagonal pattern
  lx.save();lx.strokeStyle='rgba(120,110,255,.07)';lx.lineWidth=18;for(let i=-hh;i<w+hh;i+=70){lx.beginPath();lx.moveTo(i,0);lx.lineTo(i+hh*.7,hh);lx.stroke()}lx.restore();
  // spot
  const sp=lx.createRadialGradient(w/2,hh*.12,10,w/2,hh*.12,hh*.95);sp.addColorStop(0,'rgba(255,214,140,.32)');sp.addColorStop(1,'rgba(255,214,140,0)');lx.fillStyle=sp;lx.beginPath();lx.moveTo(w/2-30,0);lx.lineTo(w/2+30,0);lx.lineTo(w/2+hh*.55,hh);lx.lineTo(w/2-hh*.55,hh);lx.fill();
  const cy=hh*.84,sc=Math.min(hh*.64/52,w*.55/30);
  // floor ring
  lx.strokeStyle='rgba(255,179,71,.65)';lx.lineWidth=3;lx.beginPath();lx.ellipse(w/2,cy+2,sc*30,sc*8,0,0,TAU);lx.stroke();
  const fg=lx.createRadialGradient(w/2,cy,4,w/2,cy,sc*30);fg.addColorStop(0,'rgba(255,179,71,.35)');fg.addColorStop(1,'rgba(255,179,71,0)');lx.fillStyle=fg;lx.beginPath();lx.ellipse(w/2,cy,sc*30,sc*8,0,0,TAU);lx.fill();
  for(const p of lps){p.y-=dt*.03*p.s;if(p.y<0){p.y=1;p.x=Math.random()}lx.fillStyle=`rgba(255,220,150,${.15+.25*Math.abs(Math.sin(lobbyT+p.r*9))})`;lx.beginPath();lx.arc(p.x*w,p.y*hh,1.2+p.s*1.8,0,TAU);lx.fill()}
  const o=myLook(),sk=ITEMS[prof.eq.w],pt=ITEMS[prof.eq.p];
  const lb=lobbyBounce(sc);lx.save();lx.translate(w/2+Math.sin(lobbyT*.7)*3+lb[0],lb[1]);
  drawChar(lx,o,0,cy,sc,.35,lobbyT,{front:true,idle:true,gun:'ranger',gcol:sk&&sk.col||null,glow:true,noShadow:false});
  lx.restore();
  lobbyExtra(w,hh,cy,sc,dt);
  if(pt)drawPet(lx,pt.kind,w/2+sc*30,cy+sc*3,sc*.55,lobbyT);
}
function refreshBars(){
  $('lGold').textContent=prof.gold;$('lGems').textContent=prof.gems;
  $('lName').textContent=prof.name;$('lLvl').textContent='Lv '+level();
  $('lXp').style.width=(prof.xp%100)+'%';
  const m=MAPS[prof.map],md=MODES.find(x=>x.id===prof.mode)||MODES[0];
  $('lMode').textContent=md.n;$('lMap').textContent=m.n+' · '+(m.size/1000).toFixed(1)+' किमी';
}
function showLobby(){
  state='lobby';$('lobby').hidden=false;$('end').hidden=true;$('pause').hidden=true;$('hud').hidden=true;
  refreshBars();
}
function showEnd(place,r){
  $('rt').textContent=place===1?'तुम जीत गए!':'#'+place+' स्थान';
  $('rt').style.color=place===1?'var(--accent)':'var(--fg)';
  const t=Math.floor(time);
  $('rs').innerHTML=r.k+' किल · '+Math.floor(t/60)+':'+String(t%60).padStart(2,'0')+' तक टिके<br>इनाम: <b>+'+r.gold+' गोल्ड</b>'+(r.gems?' · <b>+'+r.gems+' डायमंड</b>':'')+' · <b>+'+r.xp+' XP</b>';
  $('end').hidden=false;
}
function claimDaily(){
  const d=new Date().toDateString();
  if(prof.daily===d){toast('आज का बोनस ले चुके हो');return}
  prof.daily=d;prof.gold+=200;prof.gems+=10;save();refreshBars();snd('heal');toast('डेली बोनस: +200 गोल्ड, +10 डायमंड');
}
