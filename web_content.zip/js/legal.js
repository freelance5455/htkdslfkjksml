/**
 * legal.js — Termos de Uso / Política de Privacidade (modal reaproveitável).
 * Chame `montarModalLegal()` uma vez por página (feito automaticamente pelo
 * utils.js) e use `abrirModal('termos')` / `abrirModal('privacidade')`.
 */
const TEXTOS_JURIDICOS = {
  termos: {
    titulo: 'Termos de Uso',
    html: `
      <p><b>1. Natureza da plataforma.</b> O Anjo da Guarda é exclusivamente uma plataforma
      intermediadora, que conecta Anfitriões/Proprietários, Profissionais de serviço e
      Locadores/Locatários de roupas de cama. O Anjo da Guarda não presta os serviços
      anunciados, não é empregador de nenhum Profissional e não é proprietário de nenhum
      item locado.</p>
      <p><b>2. Isenção de responsabilidade.</b> O Anjo da Guarda não se responsabiliza por
      roubo, furto, danos materiais ou pessoais, acidentes, inadimplência, atraso,
      má prestação do serviço ou qualquer conduta inadequada de qualquer usuário.</p>
      <p><b>3. Cadastro e veracidade.</b> Cada usuário é responsável pela veracidade dos
      dados informados no cadastro.</p>
      <p><b>4. Imóveis e roupas de cama.</b> O Anjo da Guarda apenas aproxima as partes.
      Não guarda, não higieniza e não é proprietário de nenhum item ou imóvel anunciado.</p>
      <p><b>5. Taxas.</b> Nesta fase, o Anfitrião/Cliente paga uma taxa de conveniência de 5%
      sobre o valor do serviço contratado.</p>
      <p><b>6. Aceite.</b> Ao concluir o cadastro, o usuário declara ter lido e concordado
      integralmente com estes Termos de Uso.</p>
    `
  },
  privacidade: {
    titulo: 'Política de Privacidade',
    html: `
      <p><b>1. Conformidade com a LGPD.</b> O Anjo da Guarda trata os dados pessoais dos
      usuários em conformidade com a Lei Geral de Proteção de Dados (Lei nº 13.709/2018).</p>
      <p><b>2. Dados coletados.</b> Nome, e-mail, telefone e, quando aplicável, dados do
      imóvel ou do perfil profissional.</p>
      <p><b>3. Finalidade.</b> Viabilizar a conexão entre as partes e o funcionamento da
      plataforma.</p>
      <p><b>4. Compartilhamento.</b> Apenas entre as partes diretamente envolvidas em cada
      negociação. Não vendemos dados a terceiros.</p>
      <p><b>5. Segurança.</b> Este é um protótipo em evolução: enquanto os dados estiverem
      armazenados localmente no navegador (fase atual), não há garantia de segurança de
      um backend real — isso será endereçado nas próximas etapas do projeto.</p>
      <p><b>6. Direitos do titular.</b> O usuário pode solicitar a correção ou exclusão de
      seus dados a qualquer momento.</p>
    `
  }
};

const TERMO_INTERMEDIACAO = {
  versao: '1.0',
  titulo: 'Termo de Intermediação e Responsabilidades',
  html: `
    <p><b>1. Papel de intermediação.</b> O Anjo da Guarda atua exclusivamente como
    intermediador entre Anfitriões e Profissionais. Não presta os serviços, não é
    proprietário do imóvel nem dos itens declarados, e não garante o estado de
    conservação além do que foi informado pelas partes.</p>
    <p><b>2. Informações verdadeiras.</b> O Anfitrião declara que as informações do
    imóvel (endereço, ambientes, inventário, condições de acesso) são verdadeiras e
    atualizadas. Informações incorretas podem gerar divergência e responsabilidade
    do Anfitrião, conforme já previsto no protocolo de divergência da plataforma.</p>
    <p><b>3. Responsabilidades das partes.</b> Anfitrião e Profissional respondem
    diretamente um perante o outro por danos, atrasos, cancelamentos ou condutas
    inadequadas. O Anjo da Guarda não assume essas responsabilidades.</p>
    <p><b>4. Alterações somente dentro da plataforma.</b> Qualquer alteração de
    escopo, preço, horário ou quantidade deve ser feita pelos canais formais do
    Anjo da Guarda (alteração formal, chat oficial), nunca por fora.</p>
    <p><b>5. Evidências e auditoria.</b> Fotos, vídeos, GPS, checklist e mensagens
    trocadas dentro da plataforma podem ser usados como evidência em uma eventual
    divergência, e ficam registrados em auditoria.</p>
    <p><b>6. Direitos legais não renunciáveis.</b> Nada neste termo limita direitos
    garantidos por lei (como o Código de Defesa do Consumidor, quando aplicável) ou
    impede as partes de buscarem as vias legais cabíveis.</p>
    <p class="text-[11px] text-muted mt-3">Versão ${'1.0'} — este termo pode ser
    atualizado; uma nova versão exigirá novo aceite.</p>
  `,
};

/**
 * Termo aceito pelo PROFISSIONAL ao concluir a vistoria de ENTRADA (antes de
 * iniciar a faxina). Vinculado ao service_request_id específico — cada
 * serviço exige um novo aceite, mesmo que o profissional já tenha aceito em
 * serviços anteriores.
 */
const TERMO_VISTORIA_ENTRADA = {
  versao: '1.0',
  titulo: 'Termo de Responsabilidade — Vistoria de Entrada',
  html: `
    <p><b>1. Confirmação da vistoria.</b> Ao aceitar este termo, o Profissional
    confirma que realizou pessoalmente a vistoria de entrada do imóvel, com
    vídeo contínuo gravado no momento, testando lâmpadas, tomadas, eletrônicos,
    equipamentos e os itens do inventário declarados pelo Anfitrião.</p>
    <p><b>2. Registro do estado encontrado.</b> Toda avaria, defeito ou item
    faltante identificado nesta vistoria deve ter sido registrado no checklist
    e/ou reportado como divergência antes do início da faxina.</p>
    <p><b>3. Responsabilização por danos não reportados.</b> O Profissional
    reconhece que qualquer dano causado durante a faxina que não tenha sido
    identificado e reportado nesta vistoria de entrada será de sua
    responsabilidade perante o Anfitrião, conforme o Termo de Intermediação e
    Responsabilidades da plataforma.</p>
    <p><b>4. Evidência.</b> O vídeo, as fotos, as respostas do checklist e este
    aceite ficam vinculados a este serviço específico e podem ser usados como
    evidência em caso de divergência.</p>
    <p class="text-[11px] text-muted mt-3">Versão ${'1.0'} — aceite obrigatório
    a cada serviço, antes de liberar o início da faxina.</p>
  `,
};

/**
 * Termo aceito pelo PROFISSIONAL ao concluir a vistoria de SAÍDA (finalização
 * da faxina, após a pós-vistoria com vídeo). Também vinculado ao
 * service_request_id específico.
 */
const TERMO_VISTORIA_SAIDA = {
  versao: '1.0',
  titulo: 'Termo de Finalização — Vistoria de Saída',
  html: `
    <p><b>1. Confirmação da vistoria de saída.</b> Ao aceitar este termo, o
    Profissional confirma que realizou a vistoria de saída ao final da faxina,
    com novo vídeo contínuo gravado no momento, repetindo os testes de
    lâmpadas, tomadas, eletrônicos, equipamentos e itens relevantes do
    inventário, comparando com o estado registrado na entrada.</p>
    <p><b>2. Veracidade do estado final.</b> O Profissional declara que o
    checklist de pós-vistoria e as observações refletem fielmente o estado do
    imóvel ao término do serviço.</p>
    <p><b>3. Encerramento do serviço.</b> Este aceite, junto ao vídeo e ao
    checklist de pós-vistoria, encerra o registro de vistoria do serviço e
    libera o envio da finalização para confirmação do Anfitrião.</p>
    <p class="text-[11px] text-muted mt-3">Versão ${'1.0'} — aceite obrigatório
    a cada serviço, antes de liberar o botão "Finalizar serviço".</p>
  `,
};


function montarModalLegal(){
  if(document.getElementById('modalJuridico')) return;
  const div = document.createElement('div');
  div.innerHTML = `
    <div class="modal-overlay" id="modalJuridico" onclick="fecharModalFundo(event)">
      <div class="modal-box">
        <div class="flex justify-between items-center mb-3">
          <h3 class="text-[17px] font-bold" id="modalTitulo">Termos de Uso</h3>
          <button onclick="fecharModal()" class="text-xl" style="color:var(--muted)">✕</button>
        </div>
        <div id="modalConteudo" class="text-[13.5px] text-muted space-y-3 leading-relaxed"></div>
      </div>
    </div>
  `;
  document.body.appendChild(div.firstElementChild);
}

function abrirModal(chave){
  montarModalLegal();
  const dados = TEXTOS_JURIDICOS[chave];
  document.getElementById('modalTitulo').innerText = dados.titulo;
  document.getElementById('modalConteudo').innerHTML = dados.html;
  document.getElementById('modalJuridico').classList.add('show');
}
function fecharModal(){
  const m = document.getElementById('modalJuridico');
  if(m) m.classList.remove('show');
}
function fecharModalFundo(e){ if(e.target.id === 'modalJuridico') fecharModal(); }
