/* English legal texts rendered inside the app and into privacy.html / terms.html.
   Templates: the publisher must fill js/config.js and have counsel review before launch. */
(function (EP) {
  const c = EP.config;
  const esc = s => String(s).replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
  const contact = c.supportEmail ? esc(c.supportEmail) : '[support e-mail]';
  const who = esc(c.companyName) + ', ' + esc(c.companyAddress);
  const sec = (h, ...ps) => '<h3>' + h + '</h3>' + ps.map(p => '<p>' + p + '</p>').join('');

  EP.legal = {
    privacy: () =>
      sec('Who we are', 'The publisher of ' + esc(c.appName) + ' is ' + who + '. Contact: ' + contact + '.') +
      sec('Short version', 'The app has no user accounts, no analytics and no advertising. Your trips, expenses, notes and settings are stored only on your device (browser or app storage). We do not receive them.') +
      sec('Data stored on your device', 'Trips, itinerary items, expenses, booking notes, packing lists, saved places, language, default currency, plan status and your consent record. You can export or delete all of it at any time under More → Your data. Uninstalling the app or clearing its storage also removes it.') +
      sec('Optional online features', 'These are off by default and start only after you switch on “Online features” (during setup or in More). When on, your device connects directly to third parties, which receive your IP address and the data needed for the request: <strong>Open-Meteo (open-meteo.com)</strong> for city search (your search text) and weather forecasts (coordinates of the place you open); <strong>OpenStreetMap services, including Overpass (overpass-api.de) and openstreetmap.org</strong>, for places lists and the map (coordinates of the place you open); <strong>Wikipedia / Wikimedia (wikipedia.org, upload.wikimedia.org)</strong> for photos of places (the place name); <strong>Frankfurter (frankfurter.app)</strong> for European Central Bank reference exchange rates. External links you tap (maps, booking or transport sites) open third-party websites governed by their own privacy policies. The publisher does not control those services.') +
      sec('Legal basis (EU/EEA/UK)', 'Local storage is necessary to provide the features you request. Online features rely on your consent, which you can withdraw by switching them off.') +
      sec('Retention', 'We hold no copy of your data. On your device it remains until you delete it.') +
      sec('Your rights', 'Because the data stays on your device you control it directly: access and portability (export), rectification (edit), erasure (delete all). For other questions, or to complain, contact us or your local data-protection authority.') +
      sec('Sensitive information', 'Do not enter passport, identity-card or payment-card numbers in notes. The app is not designed to protect such data.') +
      sec('Children', 'The app is not directed at children under 16.') +
      sec('Payments', 'If paid plans are offered, payments are handled by an external payment provider. The app does not see or store your card details.') +
      sec('Changes', 'We may update this policy; the in-app version is current. Last updated: ' + esc(c.buildDate) + '.'),
    terms: () =>
      sec('1. The service', esc(c.appName) + ' is a planning aid for trips in Europe, provided by ' + who + '. It is not a travel agent, tour operator, booking platform, navigation system or source of legal, medical or safety advice.') +
      sec('2. No bookings', 'The app does not make, hold or confirm reservations. Links open independent third-party sites; any purchase is a contract between you and that provider. Booking notes are your own notes and are not verified.') +
      sec('3. Accuracy', 'Prices, times, costs and totals are entries made by you, estimates, or reference data (for example exchange rates and emergency numbers) and may be inaccurate, incomplete or out of date. Confirm anything important with official sources, including entry requirements, safety advice and emergency numbers, before relying on it.') +
      sec('4. Your content', 'You own what you enter. You are responsible for backing it up (More → Your data → Export).') +
      sec('5. Acceptable use', 'Do not misuse the app, attempt to disrupt third-party services it connects to, or use it unlawfully.') +
      sec('6. Plans and payment', 'Free and paid plans differ in the limits and features shown in the app. Paid plans, where available, are sold through an external checkout. Statutory consumer rights, including any right of withdrawal, are not affected.') +
      sec('7. Third-party data', 'Map data © OpenStreetMap contributors (ODbL). Weather data and city search by Open-Meteo.com (CC BY 4.0; GeoNames). Photos from Wikipedia / Wikimedia Commons under their respective licences. Exchange rates: European Central Bank reference rates via Frankfurter. These services are provided by others without any guarantee of availability.') +
      sec('8. Warranty and liability', 'To the extent permitted by law the app is provided “as is” without warranty, and the publisher is not liable for losses arising from reliance on information in the app, from third-party sites or from loss of locally stored data. Nothing limits liability that cannot be limited by law, including for intent, gross negligence or injury to life, body or health.') +
      sec('9. Changes and law', 'We may change these terms or the app; continued use after a change means you accept it where the law allows. Governing law and venue: [jurisdiction], subject to mandatory consumer protections in your country of residence.') +
      sec('10. Contact', who + ' · ' + contact + '. Last updated: ' + esc(c.buildDate) + '.')
  };
})(window.EP = window.EP || {});
