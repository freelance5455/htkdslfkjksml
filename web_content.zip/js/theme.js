(function () {
  'use strict';
  const P = (window.Pith = window.Pith || {});
  const U = P.util;
  const h = U.h;
  const T = (P.theme = {});

  const base = {
    replyBubble: '#00000000', bubbleRadius: 20, fontScale: 1, bgImage: null, bgDim: 0.35,
  };
  T.BUILTIN = [
    Object.assign({}, base, { id: 'celery', name: 'Celery', dark: false, builtIn: true, accent: '#7a2e6eff', bg: '#f2f4eeff', sidebar: '#e6eadfff', surface: '#fafbf7ff', userBubble: '#dce3d3ff', userText: '#18211bff', text: '#18211bff', muted: '#637067ff', input: '#fafbf7ff', border: '#d2d9cbff', code: '#e9ede3ff' }),
    Object.assign({}, base, { id: 'mist', name: 'Mist', dark: false, builtIn: true, accent: '#2f6f9fff', bg: '#f4f6f8ff', sidebar: '#e9edf1ff', surface: '#ffffffff', userBubble: '#dfe7eeff', userText: '#14202aff', text: '#14202aff', muted: '#66788aff', input: '#ffffffff', border: '#d3dce4ff', code: '#eaeff3ff' }),
    Object.assign({}, base, { id: 'moss', name: 'Moss', dark: true, builtIn: true, accent: '#d08fdbff', bg: '#0f1411ff', sidebar: '#131a16ff', surface: '#19211cff', userBubble: '#212c25ff', userText: '#e4ebe5ff', text: '#e4ebe5ff', muted: '#8a988fff', input: '#19211cff', border: '#26322bff', code: '#151d18ff' }),
    Object.assign({}, base, { id: 'graphite', name: 'Graphite', dark: true, builtIn: true, accent: '#e2b455ff', bg: '#121212ff', sidebar: '#171717ff', surface: '#1c1c1cff', userBubble: '#2a2a2aff', userText: '#ecececff', text: '#ecececff', muted: '#9a9a9aff', input: '#1c1c1cff', border: '#2e2e2eff', code: '#191919ff' }),
  ];

  // Colour fields shown in the editor, in order.
  T.FIELDS = [
    ['accent', 'Accent'], ['bg', 'Background'], ['sidebar', 'Sidebar'], ['surface', 'Menus and sheets'],
    ['userBubble', 'Your bubble'], ['userText', 'Your bubble text'], ['replyBubble', 'Reply bubble', true],
    ['text', 'Text'], ['muted', 'Secondary text'], ['input', 'Input bar'], ['border', 'Borders'], ['code', 'Code blocks'],
  ];

  const state = T.state = Object.assign({ mode: 'system', lightId: 'celery', darkId: 'moss', custom: [] }, P.store.getJSON('theme', {}));
  const save = () => P.store.setJSON('theme', state);
  const all = () => T.BUILTIN.concat(state.custom);
  const find = (id) => all().find((t) => t.id === id);
  const media = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;

  T.all = all;
  T.find = find;
  T.systemDark = () => !!(media && media.matches);
  T.effectiveDark = () => state.mode === 'dark' || (state.mode === 'system' && T.systemDark());
  T.current = function () {
    const dark = T.effectiveDark();
    return find(dark ? state.darkId : state.lightId) || T.BUILTIN[dark ? 2 : 0];
  };
  T.isActive = (spec) => spec.id === state.lightId || spec.id === state.darkId;

  const bgUrls = new Map();
  async function bgUrl(id) {
    if (!id) return null;
    if (!bgUrls.has(id)) bgUrls.set(id, await P.media.url(id));
    return bgUrls.get(id);
  }

  // Applies a theme to :root (or to a preview element) as CSS variables.
  T.apply = async function (spec, el) {
    const root = el || document.documentElement;
    const set = (k, v) => root.style.setProperty(k, v);
    set('--accent', spec.accent);
    set('--on-accent', U.onColor(spec.accent));
    set('--bg', spec.bg);
    set('--sidebar', spec.sidebar);
    set('--surface', spec.surface);
    set('--user-bubble', spec.userBubble);
    set('--user-text', spec.userText);
    set('--reply-bubble', spec.replyBubble);
    set('--text', spec.text);
    set('--muted', spec.muted);
    set('--input', spec.input);
    set('--border', spec.border);
    set('--code', spec.code);
    const ra = U.parseHex(spec.replyBubble);
    set('--reply-pad', ra && ra.a > 0.01 ? '14px' : '0px');
    set('--radius', spec.bubbleRadius + 'px');
    set('--scale', String(spec.fontScale));
    set('--bg-dim', String(spec.bgDim));
    const url = await bgUrl(spec.bgImage);
    set('--bg-img', url ? `url("${url}")` : 'none');
    if (!el) {
      root.dataset.theme = spec.dark ? 'dark' : 'light';
      root.style.colorScheme = spec.dark ? 'dark' : 'light';
      const meta = document.querySelector('meta[name="theme-color"]');
      if (meta) meta.setAttribute('content', spec.bg.slice(0, 7));
    }
  };

  T.applyCurrent = () => T.apply(T.current());
  T.setMode = function (mode) { state.mode = mode; save(); T.applyCurrent(); };
  T.select = function (spec) {
    if (spec.dark) state.darkId = spec.id; else state.lightId = spec.id;
    if (state.mode !== 'system' || spec.dark !== T.effectiveDark()) state.mode = spec.dark ? 'dark' : 'light';
    save();
    T.applyCurrent();
  };
  T.upsert = function (spec) {
    const i = state.custom.findIndex((t) => t.id === spec.id);
    if (i >= 0) state.custom[i] = spec; else state.custom.push(spec);
    save();
  };
  T.remove = function (spec) {
    state.custom = state.custom.filter((t) => t.id !== spec.id);
    if (state.lightId === spec.id) state.lightId = 'celery';
    if (state.darkId === spec.id) state.darkId = 'moss';
    if (spec.bgImage) P.media.remove(spec.bgImage);
    save();
    T.applyCurrent();
  };
  T.duplicate = (spec, name) => Object.assign({}, spec, { id: U.uid(), name: name || spec.name + ' copy', builtIn: false });
  if (media) {
    const onChange = () => { if (state.mode === 'system') T.applyCurrent(); };
    if (media.addEventListener) media.addEventListener('change', onChange); else if (media.addListener) media.addListener(onChange);
  }

  // ---------------------------------------------------------------- colour picker
  const PRESETS = ['#7a2e6e', '#d08fdb', '#b3261e', '#e2703a', '#e2b455', '#6b8e23', '#2e7d5b', '#2f6f9f', '#3b4cca', '#111111', '#6b6b6b', '#f2f2f2'];

  T.picker = function (initial, opts) {
    const o = opts || {};
    const c0 = U.parseHex(initial) || { r: 0, g: 0, b: 0, a: 1 };
    const hsv = U.rgbToHsv(c0.r, c0.g, c0.b);
    hsv.a = c0.a;

    const svThumb = h('div', { class: 'cp-thumb' });
    const sv = h('div', { class: 'cp-sv' }, svThumb);
    const hueThumb = h('div', { class: 'cp-thumb' });
    const hue = h('div', { class: 'cp-bar cp-hue' }, hueThumb);
    const alphaThumb = h('div', { class: 'cp-thumb' });
    const alpha = h('div', { class: 'cp-bar cp-alpha' }, h('div', { class: 'cp-alpha-fill' }), alphaThumb);
    const swatch = h('div', { class: 'cp-swatch' }, h('div', { class: 'cp-swatch-fill' }));
    const hex = h('input', { class: 'input cp-hex', spellcheck: 'false', autocapitalize: 'characters', maxlength: '9', 'aria-label': 'Hex colour' });

    const rgb = () => U.hsvToRgb(hsv.h, hsv.s, hsv.v);
    const current = () => { const c = rgb(); return U.toHex({ r: c.r, g: c.g, b: c.b, a: o.alpha ? hsv.a : 1 }); };

    function paint(fromHex) {
      const c = rgb();
      const solid = `rgb(${Math.round(c.r)},${Math.round(c.g)},${Math.round(c.b)})`;
      const pure = U.hsvToRgb(hsv.h, 1, 1);
      sv.style.backgroundColor = `rgb(${Math.round(pure.r)},${Math.round(pure.g)},${Math.round(pure.b)})`;
      svThumb.style.left = hsv.s * 100 + '%';
      svThumb.style.top = (1 - hsv.v) * 100 + '%';
      svThumb.style.background = solid;
      hueThumb.style.left = (hsv.h / 360) * 100 + '%';
      hueThumb.style.background = `hsl(${hsv.h},100%,50%)`;
      alpha.style.setProperty('--cp-solid', solid);
      alphaThumb.style.left = hsv.a * 100 + '%';
      alphaThumb.style.background = U.withAlpha(U.toHex({ r: c.r, g: c.g, b: c.b, a: 1 }), hsv.a);
      swatch.firstChild.style.background = o.alpha ? U.withAlpha(U.toHex({ r: c.r, g: c.g, b: c.b, a: 1 }), hsv.a) : solid;
      if (!fromHex) {
        const full = current();
        hex.value = (o.alpha ? full : full.slice(0, 7)).toUpperCase().replace('#', '');
      }
    }

    let queued = false;
    function emit(fromHex) {
      paint(fromHex);
      if (queued) return;
      queued = true;
      requestAnimationFrame(() => { queued = false; if (o.onChange) o.onChange(current()); });
    }

    function drag(el, fn) {
      el.addEventListener('pointerdown', (e) => {
        e.preventDefault();
        try { el.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
        fn(e);
        const move = (ev) => fn(ev);
        const up = () => { el.removeEventListener('pointermove', move); el.removeEventListener('pointerup', up); el.removeEventListener('pointercancel', up); };
        el.addEventListener('pointermove', move);
        el.addEventListener('pointerup', up);
        el.addEventListener('pointercancel', up);
      });
    }
    const frac = (e, el, axis) => {
      const r = el.getBoundingClientRect();
      return U.clamp(axis === 'y' ? (e.clientY - r.top) / r.height : (e.clientX - r.left) / r.width, 0, 1);
    };
    drag(sv, (e) => { hsv.s = frac(e, sv, 'x'); hsv.v = 1 - frac(e, sv, 'y'); emit(); });
    drag(hue, (e) => { hsv.h = frac(e, hue, 'x') * 359.999; emit(); });
    drag(alpha, (e) => { hsv.a = frac(e, alpha, 'x'); emit(); });

    hex.addEventListener('input', () => {
      const v = hex.value.replace('#', '').trim();
      if (!(v.length === 6 || (o.alpha && v.length === 8))) return;
      const c = U.parseHex(v);
      if (!c) return;
      const n = U.rgbToHsv(c.r, c.g, c.b);
      hsv.h = n.h; hsv.s = n.s; hsv.v = n.v;
      if (o.alpha && v.length === 8) hsv.a = c.a;
      emit(true);
    });

    const presets = h('div', { class: 'cp-presets' }, PRESETS.map((p) => h('button', {
      type: 'button', class: 'cp-preset', style: { background: p }, 'aria-label': p,
      onclick: () => {
        const c = U.parseHex(p);
        const n = U.rgbToHsv(c.r, c.g, c.b);
        hsv.h = n.h; hsv.s = n.s; hsv.v = n.v;
        emit();
      },
    })));

    const root = h('div', { class: 'cp' }, sv, hue, o.alpha ? alpha : null, h('div', { class: 'cp-row' }, swatch, h('div', { class: 'cp-hexwrap' }, h('span', null, '#'), hex)), presets);
    paint();
    return root;
  };
})();
