export const THEMES = [
  "Candy", "Classic Elite", "Midnight", "Academic", "Neon", "Glass",
  "Sunset", "Forest", "Ocean", "Aurora", "Gold"
];

export const FONT_SCALES = { "Small": 0.85, "Normal": 1.0, "Large": 1.15, "Extra Large": 1.3 };

export function applyTheme(themeName, fontScaleName) {
  const theme = THEMES.includes(themeName) ? themeName : "Candy";
  const scale = FONT_SCALES[fontScaleName] ?? 1.0;
  document.documentElement.setAttribute("data-theme", theme);
  document.documentElement.style.fontSize = Math.max(10, Math.round(16 * scale)) + "px";
}
