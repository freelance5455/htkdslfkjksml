import test from 'node:test';
import assert from 'node:assert/strict';
import { 
  isValidBdPhone, 
  canDonateTo, 
  toBengaliDigits, 
  checkPasswordStrength,
  normalizeBdPhone 
} from './utils.js';
import { 
  getDivisions, 
  getDistricts, 
  getUpazilas, 
  getDistrictName 
} from './location.js';

test('Bangladesh phone number validation tests', () => {
  assert.equal(isValidBdPhone('01712345678'), true);
  assert.equal(isValidBdPhone('+8801812345678'), true);
  assert.equal(isValidBdPhone('8801912345678'), true);
  assert.equal(isValidBdPhone('01300000000'), true);
  assert.equal(isValidBdPhone('01400000000'), true);
  assert.equal(isValidBdPhone('01500000000'), true);
  assert.equal(isValidBdPhone('01600000000'), true);

  // Invalid numbers
  assert.equal(isValidBdPhone('01212345678'), false); // invalid operator 012
  assert.equal(isValidBdPhone('0171234567'), false); // too short
  assert.equal(isValidBdPhone('017123456789'), false); // too long
  assert.equal(isValidBdPhone('abcdefghijk'), false);
});

test('Phone normalization', () => {
  assert.equal(normalizeBdPhone('+8801712345678'), '01712345678');
  assert.equal(normalizeBdPhone('8801712345678'), '01712345678');
  assert.equal(normalizeBdPhone('01712345678'), '01712345678');
});

test('Blood compatibility matrix tests', () => {
  // O- can donate to anyone
  assert.equal(canDonateTo('O-', 'A+'), true);
  assert.equal(canDonateTo('O-', 'AB+'), true);
  assert.equal(canDonateTo('O-', 'O-'), true);
  assert.equal(canDonateTo('O-', 'B-'), true);

  // AB+ can receive from anyone
  assert.equal(canDonateTo('A+', 'AB+'), true);
  assert.equal(canDonateTo('B+', 'AB+'), true);
  assert.equal(canDonateTo('O+', 'AB+'), true);

  // Incompatible tests
  assert.equal(canDonateTo('A+', 'B+'), false);
  assert.equal(canDonateTo('B+', 'A+'), false);
  assert.equal(canDonateTo('AB+', 'O+'), false);
});

test('Bengali digits conversion tests', () => {
  assert.equal(toBengaliDigits(12345), '১২৩৪৫');
  assert.equal(toBengaliDigits('01719'), '০১৭১৯');
});

test('Password strength validation', () => {
  assert.equal(checkPasswordStrength('12345').valid, false);
  assert.equal(checkPasswordStrength('123456').valid, true);
  assert.equal(checkPasswordStrength('MyStrongPass#1').valid, true);
});

test('Bangladesh administrative hierarchy tests', () => {
  const divisions = getDivisions();
  assert.equal(divisions.length, 8);
  assert.ok(divisions.some(d => d.id === 'dhaka'));
  assert.ok(divisions.some(d => d.id === 'chattogram'));

  const dhakaDistricts = getDistricts('dhaka');
  assert.ok(dhakaDistricts.length >= 10);
  assert.ok(dhakaDistricts.some((dst: { id: string }) => dst.id === 'dhaka'));

  const dhakaUpazilas = getUpazilas('dhaka');
  assert.ok(dhakaUpazilas.length > 5);
  assert.ok(dhakaUpazilas.some((u: { id: string }) => u.id === 'dhanmondi' || u.id === 'mirpur'));

  assert.equal(getDistrictName('dhaka', 'dhaka', 'bn'), 'ঢাকা');
  assert.equal(getDistrictName('dhaka', 'dhaka', 'en'), 'Dhaka');
});
