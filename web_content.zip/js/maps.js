// ===== maps: 6 themed battlefields (a new one every 5 waves) =====
let MAP = null, MAPI = 0;
const sandb = (x, z) => sandbags(x, z, rr(3, 6), SR() < .5), crt = (x, z) => crate(x, z, rr(1, 1.5), SR() < .4), brl = (x, z) => barrel(x, z, SR() < .25), jer = (x, z) => jersey(x, z, SR() < .5), wrk = (x, z) => wreck(x, z, SR() < .5);
const MAPS = [
  { name: 'KÜL KÖYÜ', sub: 'Gün batımı · yıkık köy', vehicle: 'plane', fog: 0xb57c52, fogD: .0085, sunDir: [-.55, .30, -.78], sunCol: 0xffb06a, sunI: 1.9, hemi: [0xa59ab8, 0x3b2a1f, .95], dust: [.55, .45, .33], hill: 1,
    sky: { hor: [.71, .486, .32], mid: [.55, .36, .38], top: [.12, .15, .26], sunC: [1, .6, .25], cd: [.22, .16, .19], cl: [1, .6, .35], kind: 'ruins', sil: [.12, .09, .09], plume: [.07, .25, .12, .5], glow: 0xff7a22 },
    ground: { base: '#51482f', inn: [.95, .9, .8], out: [.72, .95, .6] }, wall: 0xffffff, bld: { n: 13, h: [3.6, 6], ruin: .85 }, weather: null,
    props: [[22, sandb, 2.5], [24, crt, 1.5], [32, brl, 1], [12, jer, 2.5], [14, (x, z) => hedgehog(x, z), 1.5], [7, wrk, 4], [36, (x, z) => deadTree(x, z), 1.5]], ring: (x, z) => hedgehog(x, z) },
  { name: 'KUM FIRTINASI', sub: 'Öğle güneşi · çöl kasabası', vehicle: 'heli', fog: 0xe0b878, fogD: .0072, sunDir: [.3, .62, -.5], sunCol: 0xfff0c8, sunI: 2.4, hemi: [0xcfd8e8, 0x8a6a40, 1.0], dust: [.8, .68, .45], hill: 1.4,
    sky: { hor: [.93, .78, .55], mid: [.75, .72, .7], top: [.32, .52, .78], sunC: [1, .9, .6], cd: [.8, .7, .6], cl: [.98, .9, .78], cloud: .35, kind: 'mesas', sil: [.55, .38, .24], plume: [.09, .35, .5, .35], glow: 0xffa040 },
    ground: { base: '#b79a62', cols: ['#c4a56a', '#a88a52', '#d2b57a', '#9a7d48', '#b99c60'], sp1: '#7a6238', sp2: '#e6cf98', inn: [1, .95, .8], out: [.95, .85, .65] }, wall: 0xf0cf9a, bld: { n: 11, h: [3.2, 5.4], ruin: .8 }, weather: 'sand',
    props: [[22, sandb, 2.5], [26, (x, z) => cactus(x, z), 1.2], [12, (x, z) => palm(x, z), 1.5], [16, (x, z) => boulder(x, z, 'sandst'), 2], [18, crt, 1.5], [18, brl, 1], [9, wrk, 4], [10, sandPatch, 2.5]], ring: (x, z) => boulder(x, z, 'sandst', 1.3) },
  { name: 'BUZ HATTI', sub: 'Kar fırtınası · dağ geçidi', vehicle: 'truck', fog: 0xcfdbe8, fogD: .0105, sunDir: [-.35, .35, .6], sunCol: 0xdfeaff, sunI: 1.5, hemi: [0xbcd0f0, 0x6a7a8a, 1.15], dust: [.9, .93, 1], hill: 1.3,
    sky: { hor: [.82, .88, .95], mid: [.62, .72, .85], top: [.3, .45, .7], sunC: [.9, .95, 1], cd: [.7, .76, .85], cl: [1, 1, 1], cloud: .7, kind: 'mountains', sil: [.62, .72, .86], plume: [.58, .2, .72, .3], glow: 0xaad0ff },
    ground: { base: '#dfe8f0', cols: ['#e9f0f6', '#c8d6e4', '#f4f8fb', '#b4c4d6'], sp1: '#8aa0b8', sp2: '#ffffff', inn: [1, 1, 1], out: [.9, .95, 1] }, wall: 0xaebfd0, bld: { n: 9, h: [3.4, 5.2], ruin: .75 }, weather: 'snow',
    props: [[40, (x, z) => pine(x, z, true), 1.5], [16, drift, 2.5], [14, (x, z) => boulder(x, z, 'ice'), 2], [14, sandb, 2.5], [14, crt, 1.5], [10, jer, 2.5], [6, wrk, 4]], ring: (x, z) => pine(x, z, true) },
  { name: 'GECE ŞEHRİ', sub: 'Gece · neon harabeler', vehicle: 'gunship', fog: 0x0d1424, fogD: .0098, sunDir: [.4, .45, .5], sunCol: 0x8aa4ff, sunI: 1.25, hemi: [0x6070a0, 0x1a1a28, .95], dust: [.4, .4, .45], hill: .8,
    sky: { hor: [.08, .1, .18], mid: [.04, .06, .12], top: [.01, .02, .06], sunC: [.5, .6, .9], cd: [.03, .04, .08], cl: [.2, .25, .4], cloud: .5, stars: 1, kind: 'city', sil: [.04, .05, .09], plume: [.6, .3, .1, .35], glow: 0xff3a90 },
    ground: { base: '#2a2c33', cols: ['#30333b', '#23252b', '#3a3d46', '#1c1e23'], sp1: '#101216', sp2: '#585c68', inn: [.8, .82, .9], out: [.6, .65, .78] }, wall: 0x8a90a4, neon: true, bld: { n: 15, h: [6, 14], ruin: .6 }, weather: null,
    props: [[16, (x, z) => lamp(x, z), 1.5], [16, crt, 1.5], [26, brl, 1], [16, jer, 2.5], [14, sandb, 2.5], [10, wrk, 4]], ring: (x, z) => jersey(x, z, Math.abs(x) > Math.abs(z)) },
  { name: 'ORMAN BATAKLIĞI', sub: 'Sisli orman · yosunlu kalıntılar', vehicle: 'hover', fog: 0x6f8a62, fogD: .0135, sunDir: [.2, .4, -.7], sunCol: 0xd8f0a0, sunI: 1.3, hemi: [0x90b080, 0x2a3a1c, 1.05], dust: [.35, .38, .25], hill: 1.2,
    sky: { hor: [.55, .68, .5], mid: [.4, .55, .45], top: [.2, .35, .35], sunC: [.9, 1, .6], cd: [.3, .42, .35], cl: [.7, .85, .6], cloud: .8, kind: 'jungle', sil: [.18, .3, .16], plume: [.3, .3, .35, .3], glow: 0x80ff90 },
    ground: { base: '#2f3f22', cols: ['#34462a', '#273619', '#41522f', '#2a2a18', '#3a4a26'], sp1: '#15200e', sp2: '#6a7a42', inn: [.85, .95, .75], out: [.6, .8, .5] }, wall: 0x8aa078, bld: { n: 8, h: [3, 5], ruin: .95 }, weather: 'fireflies',
    props: [[48, (x, z) => jtree(x, z), 1.5], [18, (x, z) => boulder(x, z, 'rock'), 2], [12, (x, z) => palm(x, z), 1.5], [14, sandb, 2.5], [12, crt, 1.5], [8, wrk, 4], [18, (x, z) => deadTree(x, z), 1.5]], ring: (x, z) => jtree(x, z) },
  { name: 'KIZIL KRATER', sub: 'Kıyamet · yanardağ platosu', vehicle: 'plane', fog: 0x5a1a10, fogD: .0108, sunDir: [-.2, .2, -.9], sunCol: 0xff6a30, sunI: 2.0, hemi: [0xc06050, 0x301008, .95], dust: [.3, .2, .16], hill: 1.6,
    sky: { hor: [.9, .3, .08], mid: [.55, .12, .1], top: [.12, .03, .05], sunC: [1, .4, .1], cd: [.1, .03, .03], cl: [1, .35, .1], cloud: .85, kind: 'volcano', sil: [.1, .04, .03], plume: [.02, .3, .1, .55], glow: 0xff4a10 },
    ground: { base: '#1c1412', cols: ['#26181a', '#14100f', '#3a1a12', '#1a1210'], sp1: '#0a0606', sp2: '#a03a18', inn: [.9, .6, .5], out: [.5, .3, .25] }, wall: 0x7a4a3a, bld: { n: 9, h: [3.4, 6], ruin: .95 }, weather: 'ash',
    props: [[26, (x, z) => lavaRock(x, z), 2], [18, crt, 1.5], [26, brl, 1], [14, sandb, 2.5], [12, wrk, 4], [30, (x, z) => deadTree(x, z), 1.5], [10, jer, 2.5]], ring: (x, z) => boulder(x, z, 'lava', 1.4) }
];
const MAP_ARENA = Object.assign({}, MAPS[1], { name: 'ARENA', sub: 'Kapalı stadyum · takım savaşı', vehicle: 'plane', pit: true, pitR: 52, weather: null, fog: 0xc9d4e0, fogD: .0048, sunDir: [-.35, .72, -.45], sunCol: 0xfff4de, sunI: 2.5, hemi: [0xcfdcf0, 0x6a6a60, 1.1], bld: { n: 0, h: [3, 4], ruin: 0 }, props: [], ring: () => { }, wall: 0xd8dde4 });
MAP_ARENA.sky = Object.assign({}, MAPS[1].sky, { hor: [.8, .86, .95], mid: [.62, .74, .92], top: [.28, .48, .8], kind: 'mesas', sil: [.5, .55, .62], glow: 0xffffff });
MAP_ARENA.ground = Object.assign({}, MAPS[1].ground, { base: '#8c8f93', cols: ['#9a9da1', '#808388', '#a5a8ac', '#74777c'], sp1: '#5a5d62', sp2: '#c4c7cb', inn: [1, 1, 1], out: [.9, .92, .96] });
function loadMap(i) {
  if (i === 'arena') { MAPI = 0; MAP = MAP_ARENA; ARENA = MAP_ARENA.pitR; SR = mulberry(4242); i = 1; } else { i = clamp(i, 0, MAPS.length - 1); MAPI = i; MAP = MAPS[i]; ARENA = 97; SR = mulberry(1337 + i * 977); } clearWorld();
  SUN_DIR.set(...MAP.sunDir).normalize();
  scene.fog.color.setHex(MAP.fog); scene.fog.density = MAP.fogD;
  hemi.color.setHex(MAP.hemi[0]); hemi.groundColor.setHex(MAP.hemi[1]); hemi.intensity = MAP.hemi[2]; sun.color.setHex(MAP.sunCol); sun.intensity = MAP.sunI;
  for (const ps of [smoke, glow]) { const u = ps.mesh.material.uniforms; u.uFogC.value.setHex(MAP.fog); u.uFogD.value = MAP.fogD; }
  C_DUST[0] = MAP.dust[0]; C_DUST[1] = MAP.dust[1]; C_DUST[2] = MAP.dust[2];
  MATS.brick.color.setHex(MAP.wall); MATS.concrete.color.setHex(i === 2 ? 0xcfd8e4 : i === 3 ? 0x9aa0b4 : i === 5 ? 0x8a6a5a : 0xffffff);
  buildWorld();
  // weapon accents
  document.documentElement.style.setProperty('--map', '#' + MAP.fog.toString(16).padStart(6, '0'));
}
// weather particles around the camera
let wxT = 0;
function updateWeather(dt) {
  if (typeof gfx !== 'undefined' && gfx === 0) return;
  if (!MAP || !MAP.weather) return; const c = camera.position, w = MAP.weather;
  wxT += dt; let n = Math.floor(wxT * 70); if (n < 1) return; wxT -= n / 70; n = Math.min(n, 4);
  for (let i = 0; i < n; i++) {
    const a = Math.random() * 6.283, r = Math.sqrt(Math.random()) * 26, x = c.x + Math.cos(a) * r, z = c.z + Math.sin(a) * r;
    if (w === 'snow') smoke.emit(x, c.y + rand(4, 12), z, rand(-.8, .2), -rand(1.4, 2.4), rand(-.4, .4), 6, .09, .09, [1, 1, 1], [1, 1, 1], .85, .85, 0, 0);
    else if (w === 'sand') smoke.emit(x, rand(.3, 3.5), z, rand(7, 10), rand(-.1, .3), rand(1, 3), 2.2, .5, 1.1, [.85, .72, .5], [.85, .72, .5], .0, .28, 0, 0);
    else if (w === 'ash') { smoke.emit(x, c.y + rand(6, 14), z, rand(-1, 1), -rand(.8, 1.6), rand(-1, 1), 7, .12, .1, [.2, .18, .18], [.1, .08, .08], .8, .0, 0, 0); if (Math.random() < .4) glow.emit(x, rand(.5, 6), z, rand(-.5, .5), rand(.6, 1.6), rand(-.5, .5), 3.5, .14, .02, [1, .6, .2], [1, .2, .05], .9, 0, 0, 0); }
    else if (w === 'fireflies') { if (Math.random() < .25) glow.emit(x, rand(.6, 3.5), z, rand(-.3, .3), rand(-.1, .3), rand(-.3, .3), 5, .2, .05, [.7, 1, .4], [.5, 1, .3], .0, .9, 0, .5); }
  }
}
