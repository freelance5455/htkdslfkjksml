/* ============================================================
   AETHERVALE — In-canvas HUD (pixel style)
   ============================================================ */
const HUD = {
  panel(ctx, x, y, w, h, alpha) {
    ctx.fillStyle = `rgba(14,11,20,${alpha === undefined ? 0.82 : alpha})`;
    ctx.fillRect(x, y, w, h);
    ctx.strokeStyle = 'rgba(214,188,255,0.28)';
    ctx.lineWidth = 1;
    ctx.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1);
    ctx.fillStyle = 'rgba(214,188,255,0.5)';
    ctx.fillRect(x + 1, y + 1, 3, 1); ctx.fillRect(x + 1, y + 1, 1, 3);
    ctx.fillRect(x + w - 4, y + h - 2, 3, 1); ctx.fillRect(x + w - 2, y + h - 4, 1, 3);
  },
  text(ctx, s, x, y, col, size, align) {
    ctx.font = `600 ${size || 6}px "Press Start 2P", monospace`;
    ctx.textAlign = align || 'left';
    ctx.fillStyle = '#0c0912';
    ctx.fillText(s, x + 1, y + 1);
    ctx.fillStyle = col || '#ece7f5';
    ctx.fillText(s, x, y);
    ctx.textAlign = 'left';
  },
  bar(ctx, x, y, w, h, ratio, col, bg) {
    ctx.fillStyle = bg || 'rgba(8,6,14,0.85)';
    ctx.fillRect(x - 1, y - 1, w + 2, h + 2);
    ctx.fillStyle = 'rgba(255,255,255,0.06)';
    ctx.fillRect(x, y, w, h);
    ctx.fillStyle = col;
    ctx.fillRect(x, y, Math.max(0, Math.round(w * Math.max(0, Math.min(1, ratio)))), h);
    ctx.fillStyle = 'rgba(255,255,255,0.22)';
    ctx.fillRect(x, y, Math.max(0, Math.round(w * Math.max(0, Math.min(1, ratio)))), 1);
  },

  draw(ctx, cam) {
    const P = Game.player;
    if (!P) return;
    // ---- top-left: vitals
    this.panel(ctx, 6, 6, 152, 40);
    this.text(ctx, `Lv ${P.level}`, 11, 16, '#ffd24d', 7);
    this.text(ctx, Game.cls.name.toUpperCase().slice(0, 18), 44, 16, '#cbbcf0', 5);
    this.bar(ctx, 11, 21, 140, 5, P.hp / P.stats.hp, '#e0524f');
    this.text(ctx, `${Math.max(0, Math.round(P.hp))}/${P.stats.hp}`, 81, 26, '#ffffff', 5, 'center');
    this.bar(ctx, 11, 31, 140, 3, P.xp / P.xpNext, '#61b7ff');
    this.text(ctx, `XP ${Math.round(P.xp)}/${P.xpNext}`, 11, 41, '#8fa6d8', 5);
    this.text(ctx, `${fmt(P.gold)} G`, 151, 41, '#ffd24d', 5, 'right');

    // ---- skill / potion cooldowns
    const cdx = 6, cdy = 50;
    const slots = [
      { key: 'Q', cd: P.skillCd, max: 7, col: '#c07bff', label: 'SKILL' },
      { key: 'F', cd: P.potionCd, max: 1.2, col: '#6fe08a', label: 'RAMUAN' },
    ];
    slots.forEach((s, i) => {
      const x = cdx + i * 34;
      this.panel(ctx, x, cdy, 30, 24, 0.8);
      this.text(ctx, s.key, x + 15, cdy + 11, s.cd > 0 ? '#6b6480' : s.col, 7, 'center');
      this.text(ctx, s.label, x + 15, cdy + 20, s.cd > 0 ? '#5b5470' : '#b9b0d4', 4, 'center');
      if (s.cd > 0) {
        ctx.fillStyle = 'rgba(8,6,14,0.72)';
        ctx.fillRect(x + 1, cdy + 1, 28, Math.round(22 * (s.cd / s.max)));
      }
    });

    // ---- bioma + waktu (kanan atas)
    const b = World.biomeAtPx(P.x, P.y);
    const mm = Math.floor(Game.elapsed / 60), ss = Math.floor(Game.elapsed % 60);
    const narrow = G.VW < 430, shortH = G.VH < 235;
    const bw = narrow ? 112 : 126, bcx = G.VW - 6 - bw / 2;
    this.panel(ctx, G.VW - 6 - bw, 6, bw, 34);
    this.text(ctx, b.name.toUpperCase().slice(0, narrow ? 17 : 22), bcx, 16, '#9ef7ff', narrow ? 5 : 6, 'center');
    this.text(ctx, REALM_LABEL[b.realm].toUpperCase(), bcx, 25, '#8f89a8', 4, 'center');
    this.text(ctx, `${String(mm).padStart(2, '0')}:${String(ss).padStart(2, '0')} / ${STORY.est}:00 · ${Math.round(P.x / 16)},${Math.round(P.y / 16)}`, bcx, 35, '#b9b0d4', 4, 'center');

    // ---- minimap
    const mmS = shortH ? 54 : narrow ? 68 : 76;
    this.drawMinimap(ctx, G.VW - 6 - mmS, 44, mmS, mmS);

    // ---- pelacak kisah (satu alur, tanpa bab)
    const q = Game.quest, s = q.cur();
    if (s && !q.finished) {
      const qw = Math.min(170, Math.round(G.VW * 0.46));
      const qx = G.VW - 6 - qw, qy = shortH ? 44 + mmS + 4 : narrow ? 122 : 126;
      const lines = this.wrap(ctx, s.text, qw - 12, 5).slice(0, shortH ? 2 : 3);
      const qh = 20 + lines.length * 8;
      this.panel(ctx, qx, qy, qw, qh);
      this.text(ctx, `KISAH · ${q.step + 1}/${q.total()}`, qx + 6, qy + 11, '#ffd24d', 5);
      lines.forEach((w, i) => this.text(ctx, w, qx + 6, qy + 22 + i * 8, '#ece7f5', 5));
      this.text(ctx, q.progressText(), qx + qw - 4, qy + qh - 3, '#6fe08a', 5, 'right');
      const pw = Math.max(1, Math.floor((qw - 12) / q.total()) - 1);
      STORY.steps.forEach((_, i) => {
        ctx.fillStyle = i < q.step ? '#6fe08a' : i === q.step ? '#ffd24d' : 'rgba(255,255,255,0.18)';
        ctx.fillRect(qx + 6 + i * (pw + 1), qy + 4, pw, 2);
      });
    }

    // ---- objective arrow
    const tgt = q.objectiveTarget();
    if (tgt) {
      const dx = tgt[0] - P.x, dy = tgt[1] - P.y, dist = Math.hypot(dx, dy);
      if (dist > 110) {
        const a = Math.atan2(dy, dx);
        const cx = G.VW / 2 + Math.cos(a) * 66, cy = G.VH / 2 + Math.sin(a) * 52;
        ctx.save();
        ctx.translate(cx, cy); ctx.rotate(a);
        ctx.fillStyle = 'rgba(255,210,77,0.9)';
        ctx.beginPath(); ctx.moveTo(6, 0); ctx.lineTo(-4, -4); ctx.lineTo(-4, 4); ctx.closePath(); ctx.fill();
        ctx.restore();
        this.text(ctx, Math.round(dist / 16) + 'm', cx, cy + 14, '#ffd24d', 5, 'center');
      }
    }

    // ---- interaction prompt
    const npc = Game.nearestNpc();
    if (npc && !Game.dialog && !Game.activePanel) {
      const def = NPC_LINES[npc.id];
      const label = `[E] Bicara — ${def.name} · ${def.role}`;
      ctx.font = '600 6px "Press Start 2P", monospace';
      const w = ctx.measureText(label).width + 14;
      this.panel(ctx, G.VW / 2 - w / 2, G.VH - 44, w, 16);
      this.text(ctx, label, G.VW / 2, G.VH - 33, '#ffe9b8', 6, 'center');
    }

    // ---- petunjuk kendali
    if (!document.body.classList.contains('touch-on')) {
      this.text(ctx, 'WASD gerak · SPASI serang · Q/R/C skill · E bicara · I tas · M peta · ESC jeda', G.VW / 2, G.VH - 4, 'rgba(220,214,240,0.5)', 4, 'center');
    }

    // ---- penghitung FPS
    if (Game.settings.showFps) {
      const dm = DLSS_MODES[Game.settings.dlss] || DLSS_MODES.off;
      const cap = Game.settings.fpsCap ? Game.settings.fpsCap : '∞';
      // di layar sempit penghitung pindah ke kiri bawah agar tidak menimpa petunjuk kendali
      // di layar sempit penghitung pindah ke kiri; saat kendali sentuh aktif ia naik
      // di atas joystick supaya tidak tertutup tombol
      const fw = 128, low = G.VW < 470;
      const touch = document.body.classList.contains('touch-on');
      const fx = low ? 6 : Math.round(G.VW / 2 - fw / 2);
      const fy = low ? (touch ? Math.max(90, G.VH - 168) : G.VH - 24) : 6;
      const col = Game.fps >= 55 ? '#6fe08a' : Game.fps >= 28 ? '#ffd24d' : '#e0524f';
      this.panel(ctx, fx, fy, fw, 14, 0.7);
      this.text(ctx, `${Game.fps} FPS / ${cap}`, fx + 6, fy + 10, col, 5);
      this.text(ctx, `${G.VW}x${G.VH} ${dm.scale < 1 ? 'DLSS' : 'NATIVE'}`, fx + fw - 5, fy + 10, '#b9b0d4', 4, 'right');
    }

    // ---- toasts
    let ty0 = 84;
    Game.toasts.forEach(t => {
      const alpha = t.t > 3.6 ? 1 - (t.t - 3.6) / 0.9 : 1;
      ctx.globalAlpha = Math.max(0, alpha);
      const maxW = Math.min(250, G.VW * (narrow ? 0.42 : 0.48));
      const lines = this.wrap(ctx, t.msg, maxW, 5).slice(0, 3);
      let wide = 0;
      ctx.font = '600 5px "Press Start 2P", monospace';
      for (const l of lines) wide = Math.max(wide, ctx.measureText(l).width);
      const h = 5 + lines.length * 8;
      this.panel(ctx, 8, ty0, wide + 12, h, 0.8);
      lines.forEach((l, j) => this.text(ctx, l, 14, ty0 + 9 + j * 8, t.color, 5));
      ty0 += h + 3;
      ctx.globalAlpha = 1;
    });

    if (Game.paused) {
      ctx.fillStyle = 'rgba(8,6,14,0.72)'; ctx.fillRect(0, 0, G.VW, G.VH);
      this.text(ctx, 'JEDA', G.VW / 2, G.VH / 2 - 6, '#ffd24d', 12, 'center');
      this.text(ctx, 'Tekan ESC atau tombol JEDA untuk lanjut', G.VW / 2, G.VH / 2 + 10, '#cbbcf0', 5, 'center');
      this.text(ctx, 'Kemajuanmu sudah tersimpan otomatis', G.VW / 2, G.VH / 2 + 22, '#8fe8c0', 5, 'center');
    }
  },

  wrap(ctx, text, maxW, size) {
    ctx.font = `600 ${size}px "Press Start 2P", monospace`;
    const words = text.split(' '); const lines = []; let line = '';
    for (const w of words) {
      const t = line ? line + ' ' + w : w;
      if (ctx.measureText(t).width > maxW && line) { lines.push(line); line = w; }
      else line = t;
    }
    if (line) lines.push(line);
    return lines;
  },

  _mm: null, _mmT: -9, _mmX: 0, _mmY: 0,
  minimapCanvas(px, py, size, span) {
    // span = jumlah tile yang tercakup; digambar ulang saat pemain bergerak jauh
    const tx = Math.round(px / 16), ty = Math.round(py / 16);
    if (this._mm && Game.time - this._mmT < 0.45 && Math.abs(tx - this._mmX) < 4 && Math.abs(ty - this._mmY) < 4) return this._mm;
    if (!this._mm) { this._mm = document.createElement('canvas'); this._mm.width = size; this._mm.height = size; }
    const g = this._mm.getContext('2d');
    const step = span / size;            // tile per piksel minimap
    g.clearRect(0, 0, size, size);
    for (let py2 = 0; py2 < size; py2 += 2) {
      for (let px2 = 0; px2 < size; px2 += 2) {
        const wtx = Math.round(tx + (px2 - size / 2) * step), wty = Math.round(ty + (py2 - size / 2) * step);
        const b = World.biomeAt(wtx, wty);
        g.fillStyle = World.inTown(wtx, wty, 0) ? '#e8d9a8' : (b.fluid ? b.water : b.ground[1]);
        g.fillRect(px2, py2, 2, 2);
      }
    }
    this._mmT = Game.time; this._mmX = tx; this._mmY = ty;
    return this._mm;
  },
  drawMinimap(ctx, x, y, w, h) {
    const P = Game.player;
    const span = 128;                    // 128 tile lebar pandangan minimap
    this.panel(ctx, x, y, w, h, 0.85);
    const size = w - 4;
    ctx.drawImage(this.minimapCanvas(P.x, P.y, size, span), x + 2, y + 2);
    const sc = size / span / 16;         // piksel minimap per piksel dunia
    const cx = x + 2 + size / 2, cy = y + 2 + size / 2;
    const plot = (wx, wy, col, s) => {
      const mx = cx + (wx - P.x) * sc, my = cy + (wy - P.y) * sc;
      if (mx < x + 2 || my < y + 2 || mx > x + w - 2 || my > y + h - 2) return;
      ctx.fillStyle = col; ctx.fillRect(Math.round(mx), Math.round(my), s, s);
    };
    for (const e of Game.enemies) if (!e.dead) plot(e.x, e.y, e.def_boss ? '#ff3d6b' : e.aggro ? '#ff6b6b' : '#c98a8a', e.def_boss ? 3 : 1);
    for (const n of World.NPCS) plot(n.x, n.y, n.village ? '#8fe8c0' : '#9ef7ff', 2);
    // penanda sarang bos & pusat dusun
    if (typeof Lairs !== 'undefined' && Lairs.site) plot(Lairs.site.x, Lairs.site.y, Math.floor(Game.time * 3) % 2 ? '#ff9a6b' : '#ffd24d', 3);
    if (typeof Villages !== 'undefined' && Villages.sites) for (const v of Villages.sites) plot(v.x, v.y, '#f5b53c', 2);
    const tgt = Game.quest.objectiveTarget();
    if (tgt) plot(tgt[0], tgt[1], Math.floor(Game.time * 3) % 2 ? '#ffd24d' : '#ff9a3d', 3);
    ctx.fillStyle = '#ffffff'; ctx.fillRect(Math.round(cx) - 1, Math.round(cy) - 1, 3, 3);
    this.text(ctx, 'PETA [M]', x + w / 2, y + h - 3, 'rgba(220,214,240,0.6)', 4, 'center');
  },

  drawDialog(ctx) {
    const d = Game.dialog;
    const h = 62;
    this.panel(ctx, 20, G.VH - h - 16, G.VW - 40, h, 0.93);
    const def = NPC_LINES[d.npc] || { name: d.name || 'Penduduk', role: d.role || 'Warga Dusun', tint: '#9ef7ff', idle: [''] };
    // portrait
    const img = Art.humanoid({ key: 'npc' + d.npc, skin: '#e8b98a', hair: '#3a2c28', tunic: def.tint, pants: '#3b3550' }, 0, 0);
    ctx.save();
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(img, 0, 0, 16, 20, 26, G.VH - h - 10, 32, 40);
    ctx.restore();
    this.text(ctx, d.name, 64, G.VH - h - 2, def.tint, 7);
    this.text(ctx, d.role, 64, G.VH - h + 8, '#8f89a8', 5);
    const lines = this.wrap(ctx, d.lines[d.idx] || '', G.VW - 108, 6);
    lines.slice(0, 3).forEach((l, i) => this.text(ctx, l, 64, G.VH - h + 24 + i * 11, '#ece7f5', 6));
    this.text(ctx, `[SPASI] ${d.idx + 1}/${d.lines.length}`, G.VW - 28, G.VH - 24, '#ffd24d', 5, 'right');
  },

  drawCutscene(ctx, c) {
    ctx.fillStyle = 'rgba(6,4,12,0.9)'; ctx.fillRect(0, 0, G.VW, G.VH);
    // decorative rift
    const t = Game.time;
    for (let i = 0; i < 40; i++) {
      const a = i / 40 * Math.PI * 2 + t * 0.2;
      const r = 40 + Math.sin(t + i) * 8;
      ctx.fillStyle = `rgba(${140 + i}, ${90 + i}, 255, 0.18)`;
      ctx.fillRect(G.VW / 2 + Math.cos(a) * r * 2.2, 74 + Math.sin(a) * r * 0.6, 3, 3);
    }
    this.text(ctx, c.title, G.VW / 2, 60, '#ffd24d', 10, 'center');
    const lines = this.wrap(ctx, c.lines[c.idx] || '', G.VW - 120, 6);
    lines.forEach((l, i) => this.text(ctx, l, G.VW / 2, 120 + i * 14, '#ece7f5', 6, 'center'));
    this.text(ctx, `[SPASI / klik] lanjut  ·  ${c.idx + 1}/${c.lines.length}`, G.VW / 2, G.VH - 24, '#9b93b8', 5, 'center');
  },
};
