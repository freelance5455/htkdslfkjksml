// =====================================
// CIVIL 3 - STUDENT DATABASE
// =====================================

const STUDENT_STORAGE_KEY = "civil3_students_v1";

const DEFAULT_STUDENTS = [
    { id: 1, name: "Gaggan Ram" },
    { id: 2, name: "Gursewak" },
    { id: 3, name: "Jaiveer Singh" },
    { id: 4, name: "Mandeep Kaur" },
    { id: 5, name: "Manish Kumar" },
    { id: 6, name: "Nishant" },
    { id: 7, name: "Nitya Jashwani" },
    { id: 8, name: "Rajat" },
    { id: 9, name: "Sachin" },
    { id: 10, name: "Sahil" },
    { id: 11, name: "Sandy Kumar" },
    { id: 12, name: "Sonu" },
    { id: 13, name: "Umesh Kumar" },
    { id: 14, name: "Adrish" },
    { id: 15, name: "Abhishek Kumar" },
    { id: 16, name: "Ahilesh" },
    { id: 17, name: "Bhumika" },
    { id: 18, name: "Brij Mohan" },
    { id: 19, name: "Darsh Sahilot" },
    { id: 20, name: "Dhruv" },
    { id: 21, name: "Harshit Rewar" },
    { id: 22, name: "Komal" },
    { id: 23, name: "Lavish" },
    { id: 24, name: "Mr. Deep Singh" },
    { id: 25, name: "Pankaj Kumar" },
    { id: 26, name: "Raman" }
];

// Load saved students or initialize the default list.
function loadStudents() {
    try {
        const saved = localStorage.getItem(STUDENT_STORAGE_KEY);

        if (saved !== null) {
            const parsed = JSON.parse(saved);

            if (
                Array.isArray(parsed) &&
                parsed.every(student =>
                    student &&
                    Number.isInteger(student.id) &&
                    typeof student.name === "string"
                )
            ) {
                return parsed;
            }
        }
    } catch (error) {
        console.error("Could not load students:", error);
    }

    const initialStudents = DEFAULT_STUDENTS.map(student => ({
        ...student
    }));

    localStorage.setItem(
        STUDENT_STORAGE_KEY,
        JSON.stringify(initialStudents)
    );

    return initialStudents;
}

// Global roster used by Attendance and other pages.
var STUDENTS = loadStudents();

// Keep a global reference for other scripts.
window.STUDENTS = STUDENTS;

// Save the current roster.
function saveStudents() {
    localStorage.setItem(
        STUDENT_STORAGE_KEY,
        JSON.stringify(STUDENTS)
    );

    window.STUDENTS = STUDENTS;
}

// Get the next unused student ID.
function getNextStudentId() {
    if (STUDENTS.length === 0) {
        return 1;
    }

    return Math.max(...STUDENTS.map(student => student.id)) + 1;
}

// Add a new student.
function addStudent(name) {
    const cleanName = name.trim();

    if (!cleanName) {
        throw new Error("Please enter a student name.");
    }

    const student = {
        id: getNextStudentId(),
        name: cleanName
    };

    STUDENTS.push(student);
    saveStudents();

    return student;
}

// Edit a student's name without changing their ID.
function updateStudent(id, name) {
    const cleanName = name.trim();

    if (!cleanName) {
        throw new Error("Please enter a student name.");
    }

    const student = STUDENTS.find(item => item.id === Number(id));

    if (!student) {
        throw new Error("Student not found.");
    }

    student.name = cleanName;
    saveStudents();

    return student;
}

// Delete a student by ID.
function deleteStudent(id) {
    const index = STUDENTS.findIndex(
        student => student.id === Number(id)
    );

    if (index === -1) {
        throw new Error("Student not found.");
    }

    STUDENTS.splice(index, 1);
    saveStudents();
}

// Make functions available to the student manager.
window.saveStudents = saveStudents;
window.getNextStudentId = getNextStudentId;
window.addStudent = addStudent;
window.updateStudent = updateStudent;
window.deleteStudent = deleteStudent;

console.log("CIVIL 3 student database loaded:", STUDENTS.length);