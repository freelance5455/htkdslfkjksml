'use strict';
/* ================= network (PeerJS: no server needed) ================= */
const IN_PREVIEW=location.protocol!=='file:'&&/claude|anthropic/i.test(location.hostname);
const NOON='الأونلاين لا يعمل داخل المعاينة. حمّل الملف وافتح index.html في Chrome.';
const NONET='تعذّر الاتصال. تأكد من الإنترنت. وإن كنت داخل تطبيق Claude فافتح index.html في Chrome.';
const PEER_OPTS={config:{iceServers:[
 {urls:'stun:stun.l.google.com:19302'},{urls:'stun:global.stun.twilio.com:3478'},
 {urls:'turn:openrelay.metered.ca:80',username:'openrelayproject',credential:'openrelayproject'},
 {urls:'turn:openrelay.metered.ca:443?transport=tcp',username:'openrelayproject',credential:'openrelayproject'}]}};
function roomPeerId(name,code){const k=name.trim().toLowerCase()+'|'+String(code).trim();return 'ardk1-'+hashStr(k).toString(36)+hashStr(k+'#s').toString(36);}
const Net={role:null,peer:null,conn:null,conns:new Map(),players:new Map(),builds:new Map(),id:null,ok:false,others:new Map(),room:'',code:'',mode:'survival',timer:null,nextId:1,
 listPlayers(){return [...this.players.values()].map(p=>({id:p.id,name:p.name,skin:p.skin,ar:p.ar||'',x:p.x,y:p.y,z:p.z,yaw:p.yaw,sw:p.sw?1:0}));},
 send(o){
  if(this.role==='client'){if(this.conn&&this.conn.open)try{this.conn.send(o);}catch(e){}}
  else if(this.role==='host')this.hostRecv(0,o);
 },
 bcast(o,except){for(const [id,c] of this.conns){if(id!==except&&c.open)try{c.send(o);}catch(e){}}},
 hostRecv(id,m){
  if(!m||typeof m!=='object')return;
  if(m.t==='pos'){const p=this.players.get(id);if(p){p.x=+m.x||0;p.y=+m.y||0;p.z=+m.z||0;p.yaw=+m.yaw||0;p.sw=m.sw?1:0;p.ar=String(m.ar||'').slice(0,10);}}
  else if(m.t==='chat'){const p=this.players.get(id);if(!p)return;const o={t:'chat',n:p.name,m:String(m.m).slice(0,120)};this.bcast(o);netHandle(o);}
  else if(m.t==='gift'){const p=this.players.get(id);if(!p)return;const c=Math.max(0,Math.min(200,m.c|0));if(!c)return;const o={t:'gift',from:p.name,to:String(m.to||'').slice(0,24),c};this.bcast(o);netHandle(o);}
  else if(m.t==='build'&&m.p){this.builds.set(m.p.id,m.p);this.bcast(m,id);if(id!==0)netHandle(m);}
  else if(m.t==='unbuild'){this.builds.delete(m.id);this.bcast(m,id);if(id!==0)netHandle(m);}
 },
 startHost(){clearInterval(this.timer);this.timer=setInterval(()=>{const list=this.listPlayers();this.bcast({t:'state',p:list,tod,day});setOthers(list);},100);},
 close(){
  clearInterval(this.timer);try{if(this.peer)this.peer.destroy();}catch(e){}
  this.peer=null;this.conn=null;this.conns.clear();this.players.clear();this.builds.clear();this.role=null;this.ok=false;this.id=null;
  for(const o of this.others.values())scene.remove(o.ch.g);this.others.clear();
  $('bChat').style.display='none';$('chat').classList.remove('on');$('roomTag').style.display='none';
 }
};
function hostRoom(name,code,mode,wt){
 return new Promise((res,rej)=>{
  if(IN_PREVIEW||typeof Peer==='undefined'){rej(new Error(NOON));return;}
  Net.close();let peer,settled=false;
  try{peer=new Peer(roomPeerId(name,code),PEER_OPTS);}catch(e){rej(new Error(NONET));return;}
  const to=setTimeout(()=>{if(!settled){settled=true;try{peer.destroy();}catch(e){}rej(new Error(NONET));}},12000);
  peer.on('open',()=>{
   if(settled)return;settled=true;clearTimeout(to);
   Net.role='host';Net.peer=peer;Net.id=0;Net.ok=true;Net.room=name;Net.code=code;Net.mode=mode;Net.wt=wt||'forest';Net.nextId=1;
   Net.players=new Map([[0,{id:0,name:S.name,skin:S.skin,x:0,y:0,z:0,yaw:0,sw:0}]]);Net.builds=new Map();
   Net.startHost();res();
  });
  peer.on('error',err=>{
   if(!settled){settled=true;clearTimeout(to);try{peer.destroy();}catch(e){}rej(new Error(err&&err.type==='unavailable-id'?'هذه الغرفة موجودة بالفعل. غيّر الاسم أو الرمز.':NONET));}
  });
  peer.on('connection',conn=>{
   let id=null;
   conn.on('data',m=>{
    if(!m||typeof m!=='object')return;
    if(m.t==='join'&&id===null){
     id=Net.nextId++;let nm=String(m.name||'لاعب').slice(0,14);
     if([...Net.players.values()].some(p=>p.name===nm))nm+=id;
     Net.players.set(id,{id,name:nm,skin:String(m.skin||'explorer'),x:0,y:0,z:0,yaw:0,sw:0});Net.conns.set(id,conn);
     try{conn.send({t:'joined',id,seed:Net.room,mode:Net.mode,wt:Net.wt,tod,day,players:Net.listPlayers(),builds:[...Net.builds.values()]});}catch(e){}
     toast(nm+' انضم إلى الغرفة');
    }else if(id!==null)Net.hostRecv(id,m);
   });
   conn.on('close',()=>{if(id!==null){const p=Net.players.get(id);Net.players.delete(id);Net.conns.delete(id);if(p)toast(p.name+' غادر الغرفة');}});
  });
 });
}
function joinRoom(name,code){
 return new Promise((res,rej)=>{
  if(IN_PREVIEW||typeof Peer==='undefined'){rej(new Error(NOON));return;}
  Net.close();let peer,done=false,to=null;
  try{peer=new Peer(undefined,PEER_OPTS);}catch(e){rej(new Error(NONET));return;}
  const fail=m=>{if(!done){done=true;clearTimeout(to);try{peer.destroy();}catch(e){}rej(new Error(m));}};
  to=setTimeout(()=>fail('انتهت المهلة. تأكد من اسم الغرفة والرمز والإنترنت.'),14000);
  peer.on('error',err=>fail(err&&err.type==='peer-unavailable'?'الغرفة غير موجودة أو الرمز خاطئ. تأكد أن صاحب الغرفة داخل اللعبة.':NONET));
  peer.on('open',()=>{
   const conn=peer.connect(roomPeerId(name,code),{reliable:true});
   conn.on('open',()=>{try{conn.send({t:'join',name:S.name,skin:S.skin});}catch(e){}});
   conn.on('error',()=>fail('تعذّر الاتصال بالغرفة.'));
   conn.on('data',m=>{
    if(!m||typeof m!=='object')return;
    if(m.t==='joined'&&!done){done=true;clearTimeout(to);Net.role='client';Net.peer=peer;Net.conn=conn;Net.id=m.id;Net.ok=true;Net.room=name;Net.code=code;Net.mode=m.mode;Net.wt=m.wt||'forest';res(m);}
    else if(done)netHandle(m);
   });
   conn.on('close',()=>{if(Net.role==='client'){toast('أُغلقت الغرفة');Net.close();}else fail('تعذّر الاتصال بالغرفة.');});
  });
 });
}
function chatLine(t){const l=$('chatLog');const d=document.createElement('div');d.textContent=t;l.appendChild(d);while(l.children.length>6)l.removeChild(l.firstChild);setTimeout(()=>{if(d.parentNode)d.remove();},12000);}
function openChat(){const i=$('chatIn');i.style.display='block';i.focus();}
$('bChat').addEventListener('click',openChat);
$('chatIn').addEventListener('keydown',e=>{if(e.key==='Enter'){const v=e.target.value.trim();if(v)Net.send({t:'chat',m:v});e.target.value='';e.target.style.display='none';e.target.blur();kbHide();}});
function nameTag(text){const c=document.createElement('canvas');c.width=256;c.height=64;const x=c.getContext('2d');x.fillStyle='rgba(8,12,34,.7)';x.fillRect(0,8,256,48);x.font='bold 30px Cairo,sans-serif';x.textAlign='center';x.fillStyle='#fff';x.fillText(text,128,44);const t=new T.CanvasTexture(c);const sp=new T.Sprite(new T.SpriteMaterial({map:t,depthTest:false,transparent:true,fog:false}));sp.scale.set(2.4,.6,1);sp.position.y=3.1;sp.renderOrder=5;return sp;}
function setOthers(list){
 const seen=new Set();
 for(const p of list){if(p.id===Net.id)continue;seen.add(p.id);
  let o=Net.others.get(p.id);
  if(!o){const ch=makeChar(skinById(p.skin));decorChar(ch,p.skin,'');ch.g.add(nameTag(p.name||'لاعب'));scene.add(ch.g);o={ch,name:p.name,x:p.x,y:p.y,z:p.z,yaw:p.yaw,ph:0};Net.others.set(p.id,o);}
  o.tx=p.x;o.ty=p.y;o.tz=p.z;o.tyaw=p.yaw;o.sw=p.sw;if((p.ar||'')!==(o.ar||'')){o.ar=p.ar||'';addArmor(o.ch,o.ar);}
 }
 for(const [id,o] of Net.others){if(!seen.has(id)){scene.remove(o.ch.g);Net.others.delete(id);}}
 if(Net.ok)$('onlineV').textContent=(Net.others.size+1)+' لاعب';
}
function netHandle(m){
 if(m.t==='state'){setOthers(m.p||[]);if(Net.role==='client'&&typeof m.tod==='number'){tod=m.tod;day=m.day||day;}}
 else if(m.t==='chat')chatLine(m.n+': '+m.m);
 else if(m.t==='gift')gotGift(m);
 else if(m.t==='build'){if(m.p&&!built.find(b=>b.id===m.p.id))addPiece(m.p);}
 else if(m.t==='unbuild')removePiece(m.id);
}

