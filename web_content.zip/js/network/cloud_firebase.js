'use strict';
/* ================= cloud (Firebase Realtime Database over REST) ================= */
const FBC=window.FIREBASE_CONFIG||{databaseURL:''};
const FB_ON=!!(FBC.databaseURL&&/^https:\/\//.test(FBC.databaseURL));
const cloud={
 on:FB_ON,es:null,last:0,evQ:[],
 url(p){return FBC.databaseURL.replace(/\/$/,'')+'/'+p+'.json'+(FBC.auth?'?auth='+encodeURIComponent(FBC.auth):'');},
 async put(p,d,keep){if(!FB_ON)return false;try{const r=await fetch(this.url(p),{method:'PUT',body:JSON.stringify(d),keepalive:!!keep});return r.ok;}catch(e){return false;}},
 async post(p,d){if(!FB_ON)return false;try{const r=await fetch(this.url(p),{method:'POST',body:JSON.stringify(d)});return r.ok;}catch(e){return false;}},
 async get(p){if(!FB_ON)return null;try{const r=await fetch(this.url(p));if(!r.ok)return null;return await r.json();}catch(e){return null;}},
 payload(){return {v:2,name:S.name,coins:S.coins,owned:S.owned,skin:S.skin,stock:S.stock||[],armors:S.armors||[],armor:S.armor||'',gift:S.gift||null,quests:S.quests||null,playSec:S.playSec|0,prog:S.prog||{},friends:S.friends,t:Date.now()};},
 push(){if(!S.token||!FB_ON)return;const n=Date.now();if(n-this.last<8000)return;this.last=n;this.put('saves/'+S.token,this.payload());},
 event(type,info){if(!S.consent||!S.token)return;const e={t:Date.now(),type,info:info||'',n:S.name||''};if(!FB_ON)return;this.post('telemetry/'+S.token+'/events',e);},
 status(st){if(!S.consent||!S.token||!FB_ON)return;this.put('telemetry/'+S.token+'/status',{name:S.name,state:st,playSec:S.playSec|0,coins:S.coins,mode:Net.ok?'online':((typeof WT!=='undefined'&&WT&&WT.big&&playing)?'big':'offline'),t:Date.now()},st==='offline');},
 listen(){
  this.unlisten();if(!FB_ON||!S.token||typeof EventSource==='undefined')return;
  try{
   const es=new EventSource(this.url('players/'+S.token+'/bonus'));this.es=es;
   const h=ev=>{try{const m=JSON.parse(ev.data);const d=m&&m.data;if(d&&typeof d==='object'&&d.id&&d.id!==S.bonusSeen&&+d.coins>0)giveBonus(d);}catch(e){}};
   es.addEventListener('put',h);es.addEventListener('patch',h);
   const eb=new EventSource(this.url('players/'+S.token+'/ban'));const ea=new EventSource(this.url('players/'+S.token+'/adjust'));this.es2=[eb,ea];
   const hb=ev=>{try{const m=JSON.parse(ev.data);if(m&&m.path==='/'&&m.data===true)banGame();}catch(e){}};eb.addEventListener('put',hb);
   const ha=ev=>{try{const m=JSON.parse(ev.data);const d=m&&m.data;if(d&&typeof d==='object'&&d.id&&d.id!==S.adjSeen&&isFinite(+d.set)){S.adjSeen=d.id;S.coins=Math.max(0,Math.min(1e7,Math.floor(+d.set)));save();refreshHud();toast('تم تعديل رصيدك من المالك: '+S.coins);const m2=$('homeCoins');if(m2)m2.textContent=S.coins;}}catch(e){}};ea.addEventListener('put',ha);ea.addEventListener('patch',ha);
  }catch(e){}
 },
 unlisten(){if(this.es){try{this.es.close();}catch(e){}this.es=null;}if(this.es2){for(const x of this.es2){try{x.close();}catch(e){}}this.es2=null;}}
};
function banGame(){try{cloud.unlisten();}catch(e){}try{Net.close();}catch(e){}world.started=false;playing=false;S.banned=1;showMenu(true,'vBan');}
function giveBonus(d){
 S.bonusSeen=d.id;cloud.put('players/'+S.token+'/ack',d.id);const n=Math.max(0,Math.min(1e6,Math.floor(+d.coins)));S.coins+=n;save();
 $('bonusTxt').textContent='مبروك! حصلت على '+n+' عملة من المالك'+(d.msg?'\n'+String(d.msg).slice(0,120):'');
 $('bonus').classList.add('on');beep(880,.3,'triangle',.07);refreshHud();cloud.event('bonus',n);
 const m=$('menuCoins');if(m)m.textContent='العملات: '+S.coins;const hc=$('homeCoins');if(hc)hc.textContent=S.coins;
}
$('bonusOk').addEventListener('click',()=>$('bonus').classList.remove('on'));
/* ---- recovery token ---- */
function newToken(){
 const A='ABCDEFGHJKMNPQRSTUVWXYZ23456789',rnd=n=>{let s='';const u=new Uint8Array(n);try{crypto.getRandomValues(u);}catch(e){for(let i=0;i<n;i++)u[i]=Math.random()*256;}for(let i=0;i<n;i++)s+=A[u[i]%A.length];return s;};
 return 'FL-'+rnd(4)+'-'+rnd(4);
}
const tokRe=/^FL-[A-Z0-9]{4}-[A-Z0-9]{4}$/;
async function restoreByToken(tok){
 tok=String(tok||'').trim().toUpperCase();if(!tokRe.test(tok))return {ok:false,err:'الرمز غير صحيح. الشكل: FL-XXXX-XXXX'};
 for(const n in DB.accounts){if(DB.accounts[n].token===tok){loadAcc(n);return {ok:true,src:'local'};}}
 const d=await cloud.get('saves/'+tok);
 if(d&&d.name){const a={coins:d.coins|0,owned:d.owned||['explorer'],skin:d.skin||'explorer',friends:d.friends||[],reqIn:[],reqOut:[],recent:[],token:tok,stock:d.stock||[],armors:d.armors||[],armor:d.armor||'',gift:d.gift||null,quests:d.quests||null,playSec:d.playSec|0,prog:d.prog||{},consent:true};
  let nm=d.name;if(DB.accounts[nm])nm=nm+'2';DB.accounts[nm]=a;loadAcc(nm);return {ok:true,src:'cloud'};}
 return {ok:false,err:FB_ON?'لم يتم العثور على حساب بهذا الرمز.':'لا يوجد حفظ سحابي مفعّل، ولا يوجد هذا الرمز على هذا الجهاز.'};
}
/* ---- secret character (hash only is stored in the file) ---- */
const SECRET_SHA='b811ae0988efb335da42e6568fe633a8f53c1224c26e6c847c52fb94848bc433',SECRET_FNV='nuhskw';
function fnv(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return (h>>>0).toString(36);}
async function checkSecret(code){
 const n=String(code||'').trim().toLowerCase().replace(/\s+/g,'');if(!n)return false;
 const s='ard|'+n;
 try{if(window.crypto&&crypto.subtle){const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s));const hex=Array.from(new Uint8Array(b)).map(x=>x.toString(16).padStart(2,'0')).join('');return hex===SECRET_SHA;}}catch(e){}
 return fnv(s)===SECRET_FNV;
}
/* ---- recharge packs ---- */
const PACKS=[{c:500,dt:1},{c:1000,dt:2},{c:2000,dt:3.5},{c:5000,dt:5.7},{c:8000,dt:7},{c:12000,dt:11.3}];
let packSel=1;
const ORDER_OK='تم إرسال طلبك بنجاح! سيتواصل معك المالك على الخاص لإتمام عملية التحويل وشحن العملات في حسابك فوراً';
function renderPacks(){
 const box=$('packs');box.innerHTML='';
 PACKS.forEach((p,i)=>{const b=document.createElement('button');b.className='pack'+(i===packSel?' on':'');b.innerHTML='<b>'+p.c+'</b><span>'+p.dt+' DT</span>';b.addEventListener('click',()=>{packSel=i;renderPacks();});box.appendChild(b);});
}
async function sendOrder(){
 const name=$('oName').value.trim(),phone=$('oPhone').value.trim(),plat=$('oPlat').value,handle=$('oHandle').value.trim();
 const say2=t=>{$('orderMsg').textContent=t;$('orderMsg').className='msg2';};
 if(name.length<2){say2('اكتب اسمك');return;}
 if(!/^[+0-9 ]{6,16}$/.test(phone)){say2('اكتب رقم هاتف صحيحاً');return;}
 if(handle.length<2){say2('اكتب معرّف حسابك في المنصة');return;}
 if(!$('oConsent').checked){say2('يجب الموافقة على إرسال البيانات للمالك');return;}
 const p=PACKS[packSel];
 const o={name,phone,platform:plat,handle,coins:p.c,priceDT:p.dt,account:S.name,token:S.token,t:Date.now(),status:'new'};
 $('oSend').disabled=true;say2('جارٍ الإرسال…');
 const ok=await cloud.post('orders',o);
 $('oSend').disabled=false;
 if(ok){$('orderMsg').textContent=ORDER_OK;$('orderMsg').className='msg2 good';cloud.event('order',p.c);}
 else{
  const txt='طلب شحن: '+p.c+' عملة ('+p.dt+' DT)\nالاسم: '+name+'\nالهاتف: '+phone+'\n'+plat+': '+handle+'\nالحساب: '+S.name+'\nالرمز: '+S.token;
  $('orderMsg').textContent=FB_ON?'تعذّر الإرسال. تحقق من الإنترنت وحاول مجدداً.':'الإرسال التلقائي غير مفعّل في هذه النسخة (لم تُضبط قاعدة البيانات). انسخ الطلب وأرسله للمالك يدوياً.';
  $('orderMsg').className='msg2';
  try{navigator.clipboard.writeText(txt);}catch(e){}
  $('orderCopy').style.display='block';$('orderCopy').onclick=()=>{try{navigator.clipboard.writeText(txt);toast('تم النسخ');}catch(e){}};
 }
}
/* ---- autosave of progress ---- */
const worldKey=()=>[world.room||'',world.wt||'forest',world.mode||'survival'].join('|');
function snapshot(){
 if(!S.name||!P||!world.started||Net.ok)return;
 S.prog=S.prog||{};
 S.prog[worldKey()]={inv:INV,tools:TOOLS,hp:P.hp,food:P.food,pos:Cave.on?P.ret&&{x:P.ret.x,y:0,z:P.ret.z}:{x:P.x,y:P.y,z:P.z},built:built.map(b=>({id:b.id,type:b.type,x:b.x,y:b.y,z:b.z,ry:b.ry})),blk:[...BLK.values()].slice(0,5000).map(b=>({b:1,x:b.x,y:b.y,z:b.z,k:b.t,o:b.o,open:b.open?1:0,top:b.top?1:0})),dead:Array.from(deadSet),tod,day,t:Date.now()};
 const keys=Object.keys(S.prog);if(keys.length>8){keys.sort((a,b)=>S.prog[a].t-S.prog[b].t);delete S.prog[keys[0]];}
}
function restoreSnapshot(){
 const s=S.prog&&S.prog[worldKey()];if(!s||Net.ok)return;
 try{
  for(const k of s.dead||[])deadSet.add(k);
  for(const [k,ch] of chunks){for(const p of ch.props){if(deadSet.has(ch.cx+','+ch.cz+','+p.id))p.dead=true;}rebuildProps(ch);}
  Object.assign(INV,s.inv||{});for(const k in (s.tools||{}))TOOLS[k]=1;
  if(s.pos&&isFinite(s.pos.x)){P.x=s.pos.x;P.z=s.pos.z;P.y=heightAt(P.x,P.z);updateChunks(P.x,P.z,99);}
  P.hp=s.hp||100;P.food=s.food||100;tod=s.tod||tod;day=s.day||day;
  for(const b of s.built||[])addPiece(b);for(const b of s.blk||[])addPiece(b);
 }catch(e){}
}
let autoT=0;
function autoSave(dt){
 if(!S.name||!playing)return;
 S.playSec=(S.playSec||0)+dt;S.sessSec=(S.sessSec||0)+dt;
 if(Math.floor(S.playSec/60)>Math.floor((S.playSec-dt)/60))questEv('play',1);
 autoT+=dt;if(autoT>10){autoT=0;snapshot();save();cloud.push();cloud.status('online');}
}
document.addEventListener('click',e=>{const b=e.target.closest&&e.target.closest('button');if(b)sfx('click');},true);
addEventListener('pagehide',()=>{try{snapshot();save();cloud.last=0;cloud.status('offline');}catch(e){}});
document.addEventListener('visibilitychange',()=>{if(document.hidden){try{snapshot();save();}catch(e){}}});

