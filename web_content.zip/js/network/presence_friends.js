'use strict';
/* ================= presence / friends ================= */
const nk=n=>String(n||'').trim().toLowerCase();
const uid=n=>'ardku-'+hashStr('u|'+nk(n)).toString(36)+hashStr('v|'+nk(n)).toString(36);
const isFriend=n=>S.friends.some(f=>nk(f)===nk(n));
const inList=(a,n)=>a.some(f=>nk(f)===nk(n));
const dropFrom=(a,n)=>a.filter(f=>nk(f)!==nk(n));
const Pres={peer:null,ok:false,name:'',st:'',retry:null,flushT:null,tries:0,waits:new Map(),status:{},
 start(){
  if(!S.name)return;
  if(this.peer&&this.name===S.name)return;
  this.stop();this.name=S.name;
  if(IN_PREVIEW||typeof Peer==='undefined'){this.st='off';updateFriendsUI();return;}
  this.st='connecting';updateFriendsUI();
  let p;try{p=new Peer(uid(S.name),PEER_OPTS);}catch(e){this.st='err';updateFriendsUI();return;}
  this.peer=p;const nm=this.name;
  p.on('open',()=>{this.ok=true;this.tries=0;this.st='on';updateFriendsUI();this.flush();clearInterval(this.flushT);this.flushT=setInterval(()=>this.flush(),20000);});
  p.on('error',err=>{
   const ty=err&&err.type;
   if(ty==='peer-unavailable'){const m=/peer\s+(\S+)/.exec(err.message||'');if(m&&this.waits.has(m[1]))this.waits.get(m[1])(false);return;}
   this.ok=false;
   if(ty==='unavailable-id'){this.tries++;this.st=this.tries>6?'taken':'connecting';}
   else this.st='err';
   updateFriendsUI();
   clearTimeout(this.retry);
   if(this.st!=='taken')this.retry=setTimeout(()=>{if(S.name===nm){const pp=this.peer;this.peer=null;try{pp&&pp.destroy();}catch(e){}this.name='';this.start();}},ty==='unavailable-id'?7000:12000);
  });
  p.on('disconnected',()=>{this.ok=false;try{p.reconnect();}catch(e){}});
  p.on('connection',c=>this.onConn(c));
 },
 stop(){clearTimeout(this.retry);clearInterval(this.flushT);try{if(this.peer)this.peer.destroy();}catch(e){}this.peer=null;this.ok=false;this.name='';this.st='';this.status={};},
 send(name,msg,cb){
  if(!this.ok||!this.peer){cb&&cb(false);return;}
  const id=uid(name);let done=false,c=null,to=null;
  const fin=(ok,data)=>{if(done)return;done=true;clearTimeout(to);if(this.waits.get(id)===fin)this.waits.delete(id);try{c&&c.close();}catch(e){}cb&&cb(ok,data);};
  to=setTimeout(()=>fin(false),6000);this.waits.set(id,fin);
  msg.from=S.name;
  try{c=this.peer.connect(id,{reliable:true});}catch(e){fin(false);return;}
  c.on('open',()=>{try{c.send(msg);}catch(e){fin(false);}});
  c.on('data',d=>fin(true,d));
  c.on('error',()=>fin(false));
 },
 onConn(c){
  c.on('data',m=>{
   if(!m||typeof m!=='object')return;
   const from=String(m.from||'').trim().slice(0,14);const ack=o=>{try{c.send(o);}catch(e){}};
   if(m.t==='ping'){ack({t:'pong',room:(Net.ok&&isFriend(from))?{name:Net.room,code:Net.code,mode:Net.mode}:null});}
   else if(m.t==='freq'){this.onFreq(from);ack({t:'ok'});}
   else if(m.t==='facc'){this.onAcc(from);ack({t:'ok'});}
   else if(m.t==='frem'){this.onRem(from);ack({t:'ok'});}
   else if(m.t==='invite'){if(isFriend(from))showInvite(from,String(m.room||''),String(m.code||''));ack({t:'ok'});}
  });
 },
 addFriend(n){if(!isFriend(n))S.friends.push(n);S.reqIn=dropFrom(S.reqIn,n);S.reqOut=dropFrom(S.reqOut,n);save();updateFriendsUI();},
 onFreq(from){
  if(!from||nk(from)===nk(S.name))return;
  if(isFriend(from)){this.send(from,{t:'facc'});return;}
  if(inList(S.reqOut,from)){this.addFriend(from);this.send(from,{t:'facc'});toast('أصبحت صديقاً لـ '+from);return;}
  if(!inList(S.reqIn,from)){S.reqIn.push(from);save();toast(from+' أرسل لك طلب صداقة');}
  updateFriendsUI();
 },
 onAcc(from){if(inList(S.reqOut,from)){this.addFriend(from);toast(from+' قبل طلب الصداقة');}},
 onRem(from){S.friends=dropFrom(S.friends,from);S.reqIn=dropFrom(S.reqIn,from);S.reqOut=dropFrom(S.reqOut,from);save();updateFriendsUI();},
 request(name,cb){
  name=String(name||'').trim().slice(0,14);
  if(!name)return cb('اكتب اسم حساب صديقك');
  if(nk(name)===nk(S.name))return cb('لا يمكنك إضافة نفسك');
  if(isFriend(name))return cb('هذا الشخص صديقك بالفعل');
  if(inList(S.reqIn,name)){this.accept(name);return cb('تم قبول طلبه، أصبحتما صديقين');}
  if(!inList(S.reqOut,name)){S.reqOut.push(name);save();}
  updateFriendsUI();
  if(!this.ok)return cb('تم حفظ الطلب وسيُرسل عندما تتصل الخدمة');
  this.send(name,{t:'freq'},ok=>cb(ok?'تم إرسال طلب الصداقة':'صديقك غير متصل الآن. الطلب محفوظ وسيصله عندما يفتح اللعبة.'));
 },
 accept(name){this.addFriend(name);this.send(name,{t:'facc'});toast('أصبحت صديقاً لـ '+name);},
 decline(name){S.reqIn=dropFrom(S.reqIn,name);save();updateFriendsUI();},
 cancel(name){S.reqOut=dropFrom(S.reqOut,name);save();updateFriendsUI();},
 remove(name){S.friends=dropFrom(S.friends,name);save();this.send(name,{t:'frem'});delete this.status[nk(name)];updateFriendsUI();},
 flush(){if(!this.ok)return;for(const n of S.reqOut.slice())this.send(n,{t:'freq'});},
 refresh(){
  if(!this.ok){updateFriendsUI();return;}
  for(const n of S.friends.slice())this.send(n,{t:'ping'},(ok,d)=>{this.status[nk(n)]=ok&&d&&d.t==='pong'?{on:true,room:d.room||null}:{on:false};updateFriendsUI();});
 },
 invite(name){
  if(!Net.ok){toast('ادخل غرفة أولاً');return;}
  this.send(name,{t:'invite',room:Net.room,code:Net.code},ok=>toast(ok?'تم إرسال الدعوة إلى '+name:name+' غير متصل'));
 }
};
let invTimer=null,invRoom=null;
function showInvite(from,room,code){
 if(!room)return;invRoom={room,code};
 $('invTxt').textContent=from+' يدعوك إلى الغرفة «'+room+'»';
 $('invite').classList.add('on');beep(700,.15,'triangle');
 clearTimeout(invTimer);invTimer=setTimeout(()=>$('invite').classList.remove('on'),30000);
}
$('invNo').addEventListener('click',()=>$('invite').classList.remove('on'));
$('invYes').addEventListener('click',()=>{$('invite').classList.remove('on');if(invRoom)enterRoom('j',invRoom.room,invRoom.code);});

function updateFriendsUI(){
 const n=S.reqIn.length;$('frBadge').textContent=n?'('+n+')':'';
 const st={off:'غير متاح في المعاينة، افتح الملف في Chrome',connecting:'جارٍ الاتصال…',on:'متصل',taken:'اسم الحساب مستخدم الآن من جهاز آخر',err:'تعذّر الاتصال بخدمة الأصدقاء، نعيد المحاولة'}[Pres.st]||'';
 $('presSt').textContent=st;
 if(!$('vFriends').classList.contains('on'))return;
 const row=(name,dot,sub,btns)=>{
  const d=document.createElement('div');d.className='frow';
  d.innerHTML='<i class="dot'+(dot?' on':'')+'"></i><b></b><small></small>';
  d.querySelector('b').textContent=name;d.querySelector('small').textContent=sub||'';
  for(const [t,cls,fn] of btns){const b=document.createElement('button');b.textContent=t;if(cls)b.className=cls;b.addEventListener('click',fn);d.appendChild(b);}
  return d;
 };
 const fill=(id,arr,mk,empty)=>{const box=$(id);box.innerHTML='';if(!arr.length){const e=document.createElement('div');e.className='note';e.textContent=empty;box.appendChild(e);return;}for(const x of arr)box.appendChild(mk(x));};
 fill('reqIn',S.reqIn,x=>row(x,0,'',[['قبول','ok',()=>Pres.accept(x)],['رفض','no',()=>Pres.decline(x)]]),'لا توجد طلبات واردة.');
 fill('reqOut',S.reqOut,x=>row(x,0,'بانتظار القبول',[['إلغاء','no',()=>Pres.cancel(x)]]),'لا توجد طلبات مرسلة.');
 fill('flist',S.friends,x=>{
  const s=Pres.status[nk(x)];const on=!!(s&&s.on);
  const btns=[];
  if(on&&s.room&&!(Net.ok&&Net.room===s.room.name))btns.push(['انضم','ok',()=>enterRoom('j',s.room.name,s.room.code)]);
  if(on&&Net.ok)btns.push(['دعوة','',()=>Pres.invite(x)]);
  btns.push(['حذف','no',()=>Pres.remove(x)]);
  return row(x,on,on?(s.room?'في غرفة «'+s.room.name+'»':'متصل'):(s?'غير متصل':'…'),btns);
 },'لا يوجد أصدقاء بعد. أضف صديقاً باسم حسابه.');
}
$('fadd').addEventListener('click',()=>{Pres.request($('fname').value,m=>{say(m);$('fname').value='';});});
$('fname').addEventListener('keydown',e=>{if(e.key==='Enter')$('fadd').click();});
$('frefresh').addEventListener('click',()=>Pres.refresh());

