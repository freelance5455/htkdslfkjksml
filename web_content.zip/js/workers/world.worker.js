// Worker del mundo (módulo). Genera trozos de terreno, agua, vegetación y colisiones sin bloquear la interfaz.
// Entrada:  { type: 'chunk', id, cx, cz, lod, opts }
// Salida:   { type: 'ready' } | { type: 'chunk', id, result } | { type: 'error', id, message }
import { generateChunk, transferList } from '../world/chunkGen.js';

self.onmessage = (event) => {
  const m = event.data;
  if (!m || m.type !== 'chunk') return;
  try {
    const result = generateChunk(m.cx, m.cz, m.lod, m.opts);
    self.postMessage({ type: 'chunk', id: m.id, result }, transferList(result));
  } catch (err) {
    self.postMessage({ type: 'error', id: m.id, message: err?.message || String(err) });
  }
};

self.postMessage({ type: 'ready' });
