/* Danos, desabamento, progressao e som */
/* ===== SISTEMA DE DANOS POR COMPONENTES: motor, esteiras/rodas, torre, canhao, combustivel e blindagem =====
   Estado em t.cp (criado no 1o impacto). Efeitos usam 2 pools fixos de particulas (2 draw calls no total). */
let dmP=null;
const CPFX=(()=>{
  const ST=13,mk=(n,add,tint)=>{const P=new Float32Array(n*3),C=new Float32Array(n*3),S=new Float32Array(n),A=new Float32Array(n),g=new THREE.BufferGeometry();
    g.setAttribute('position',new THREE.BufferAttribute(P,3));g.setAttribute('col',new THREE.BufferAttribute(C,3));g.setAttribute('siz',new THREE.BufferAttribute(S,1));g.setAttribute('alp',new THREE.BufferAttribute(A,1));
    const m=new THREE.ShaderMaterial({uniforms:{sc:{value:600}},
      vertexShader:'attribute vec3 col;attribute float siz;attribute float alp;uniform float sc;varying vec3 vC;varying float vA;void main(){vC=col;vA=alp;vec4 mv=modelViewMatrix*vec4(position,1.0);gl_PointSize=min(siz*sc/max(-mv.z,.5),96.0);gl_Position=projectionMatrix*mv;}',
      fragmentShader:'varying vec3 vC;varying float vA;void main(){vec2 c=gl_PointCoord-vec2(.5);float d=dot(c,c)*4.0;if(d>1.0)discard;float f=1.0-d;gl_FragColor=vec4(vC,vA*f*f);}',
      transparent:true,depthWrite:false,blending:add?THREE.AdditiveBlending:THREE.NormalBlending});
    const o=new THREE.Points(g,m);o.frustumCulled=false;o.renderOrder=6;scene.add(o);
    return{n,P,C,S,A,Z:new Float32Array(n*ST),g,m,tint,h:0,live:0,dirty:false}},
  sm=mk(420,false,true),fp=mk(240,true,false),
  em=(p,x,y,z,vx,vy,vz,s0,gr,life,r,g,b,a,gv,dr)=>{const i=p.h,o=i*ST,Z=p.Z;p.h=(i+1)%p.n;if(Z[o]<=0)p.live++;
    Z[o]=life;Z[o+1]=life;Z[o+2]=vx;Z[o+3]=vy;Z[o+4]=vz;Z[o+5]=s0;Z[o+6]=gr;Z[o+7]=r;Z[o+8]=g;Z[o+9]=b;Z[o+10]=a;Z[o+11]=gv;Z[o+12]=dr;
    p.P[i*3]=x;p.P[i*3+1]=y;p.P[i*3+2]=z;p.S[i]=s0;p.A[i]=a;p.C[i*3]=r;p.C[i*3+1]=g;p.C[i*3+2]=b;p.dirty=true},
  up=(p,dt,k,c)=>{if(!p.live&&!p.dirty)return;const Z=p.Z,P=p.P,C=p.C,S=p.S,A=p.A;let live=0;
    for(let i=0;i<p.n;i++){const o=i*ST;let L=Z[o];if(L<=0)continue;L-=dt;
      if(L<=0){Z[o]=0;A[i]=0;S[i]=0;continue}
      Z[o]=L;live++;const f=1-Math.min(1,dt*Z[o+12]),q=i*3;Z[o+3]-=Z[o+11]*dt;Z[o+2]*=f;Z[o+3]*=f;Z[o+4]*=f;
      P[q]+=Z[o+2]*dt;P[q+1]+=Z[o+3]*dt;P[q+2]+=Z[o+4]*dt;
      const t=L/Z[o+1],dx=P[q]-c.x,dy=P[q+1]-c.y,dz=P[q+2]-c.z,d2=dx*dx+dy*dy+dz*dz;let a=Z[o+10]*t;
      S[i]=Math.max(.01,Z[o+5]+Z[o+6]*(1-t));if(d2>32400)a*=Math.max(0,1.7-Math.sqrt(d2)/260);A[i]=a;
      if(p.tint){C[q]=Z[o+7]*k;C[q+1]=Z[o+8]*k;C[q+2]=Z[o+9]*k}}
    p.live=live;p.dirty=false;p.g.attributes.position.needsUpdate=p.g.attributes.col.needsUpdate=p.g.attributes.siz.needsUpdate=p.g.attributes.alp.needsUpdate=true};
  const R=Math.random;
  return{
    smoke:(x,y,z,s,life,sh,a,u)=>em(sm,x+(R()-.5)*.3,y,z+(R()-.5)*.3,(R()-.5)*.7+.25,u+R()*.5,(R()-.5)*.7,s,s*2.2,life,sh,sh*.98,sh*.95,a,-.25,.6),
    fire:(x,y,z,s,life)=>em(fp,x,y,z,(R()-.5)*.8,1.4+R()*1.4,(R()-.5)*.8,s,-s*.75,life,1,.45+R()*.4,.08,.9,-.6,.5),
    spark:(x,y,z,sp,n)=>{for(let i=0;i<n;i++)em(fp,x,y,z,(R()-.5)*sp,R()*sp*.8+1,(R()-.5)*sp,.2,-.12,.25+R()*.3,1,.8,.35,1,14,.3)},
    flash:(x,y,z,s)=>em(fp,x,y,z,0,0,0,s,s*.5,.16,1,.7,.25,.9,0,0),
    upd:dt=>{const b=scene.background,k=Math.min(1,.28+(b.r*.3+b.g*.59+b.b*.11)*.95),v=renderer.domElement.height/(2*Math.tan(cam.fov*Math.PI/360));
      sm.m.uniforms.sc.value=fp.m.uniforms.sc.value=v;up(sm,dt,k,cam.position);up(fp,dt,1,cam.position)}};
})();
const CPK=['mot','esq','dir','tor','can','com','bld'],CPMSG={mot:['Motor danificado!','MOTOR DESTRUÍDO!'],tor:['Giro da torre lento!','Torre emperrada!'],can:['Canhão danificado: falhas de tiro!','Canhão inutilizado!'],com:['Tanque de combustível furado!','Combustível destruído!']},
  CPZF={f:.55,s:1,r:1.25,tf:.7,ts:1,tb:1.1},CPCH=new THREE.Color(0x24221e),_P=new THREE.Vector3(),_Q=new THREE.Vector3(),_R=new THREE.Vector3(),_W=new THREE.Vector3(),ZN={k:'f',az:0,tur:false,lx:0};
const cpWheeled=t=>!!(t.stry||t.agmv||t.pant||t.aven||t.boxer||t.gua||t.casc||t.amr||t.roo||t.astros),cpModern=t=>!!(t.pzh||t.stry||t.cv90||t.pant||t.gep||t.t80||t.merk||t.boxer||t.t90||t.arm14||t.abrams||t.leo||t.ch2||t.pl01||t.stk||t.ku||t.amr||t.roo||t.gua);
function cpMsg(t,k,z){if(k==='esq'||k==='dir'){const s=k==='esq'?'esquerd':'direit';return cpWheeled(t)?'Rodas '+s+'as '+(z?'destruídas!':'danificadas!'):'Esteira '+s+'a '+(z?'rompida!':'danificada!')}return CPMSG[k][z]}
function cpInit(t){return t.cp={mot:100,esq:100,dir:100,tor:100,can:100,com:100,bld:100,fu:100,fire:0,fz:0,fx:0,ext:cpModern(t)?1:0,stall:0,sk:0,t:0,tt:{},e1:0,e2:0,e3:0,e4:0,e5:0,e6:0,e7:0,fix:0,mob:1,tmob:1,drift:0,tilt:0,
  mhp:mhpOf(t),yl:t.yaw,c0:t.mat.color.clone(),dec:[],tk:[0,0],tm:[null,null],by:null,dirty:0}}
function cpToast(D,k,m){if(D.t-(D.tt[k]===undefined?-9:D.tt[k])>5){D.tt[k]=D.t;toast(m)}}
function cpSrc(t,by){let dx=by?by.x-t.x:0,dz=by?by.z-t.z:1;const l=Math.hypot(dx,dz)||1;return _P.set(t.x+dx/l*2.3,t.y+1.2+Math.random()*.6,t.z+dz/l*2.3)}
/* regiao atingida: casco (frente/lado/traseira) ou torre (frente/lado/traseira), medida no referencial do veiculo */
function cpZone(t,P){_Q.copy(P);t.g.worldToLocal(_Q);
  if(_Q.y>(t.TY||1.5)+.12){_R.copy(P);t.tg.worldToLocal(_R);const az=Math.atan2(_R.x,_R.z),aa=Math.abs(az);ZN.k=aa<.9?'tf':aa>2.3?'tb':'ts';ZN.az=az;ZN.tur=true;ZN.lx=_R.x}
  else{const az=Math.atan2(_Q.x,_Q.z),aa=Math.abs(az);ZN.k=aa<.75?'f':aa>2.3?'r':'s';ZN.az=az;ZN.tur=false;ZN.lx=_Q.x}return ZN}
function cpHit(t,D,a,by){
  const bl=D.bld,arm=t.armor||1,mul=1+(1-bl/100)*.35,R=Math.random;if(by&&by!==t)D.by=by;
  if(a<3){D.bld=Math.max(0,bl-a*arm*.1);D.dirty=1;if(by&&D.t-D.sk>.15){D.sk=D.t;cpSrc(t,by);CPFX.spark(_P.x,_P.y,_P.z,3,2)}return a*mul}
  const P=dmP||cpSrc(t,by),Z=cpZone(t,P),k=Z.k,pen=a*arm*CPZF[k]*(.85+R()*.3)*1.9,ks=['mot','esq','dir','tor','can','com'],o0=ks.map(q=>D[q]),h=(q,v)=>{D[q]=Math.max(0,D[q]-v)};
  D.bld=Math.max(0,bl-pen*.45);D.dirty=1;
  if(pen>=10){
    if(k==='f'){if(R()<.3)h('mot',pen*.5);if(R()<.22)h(R()<.5?'esq':'dir',pen*.45);if(R()<.12)h('com',pen*.35)}
    else if(k==='s'){h(Z.lx>0?'esq':'dir',pen*(.8+R()*.4));if(R()<.45)h('com',pen*.7);if(R()<.3)h('mot',pen*.35)}
    else if(k==='r'){h('mot',pen*(.8+R()*.4));if(R()<.6)h('com',pen*.9);if(R()<.2)h(R()<.5?'esq':'dir',pen*.3)}
    else if(k==='tf'){if(R()<.75)h('can',pen*.95);if(R()<.5)h('tor',pen*.45)}
    else if(k==='ts'){h('tor',pen*(.8+R()*.4));if(R()<.25)h('can',pen*.3)}
    else{h('tor',pen*.8);if(R()<.3)h('can',pen*.3)}
    let ig=k==='r'?.1+.35*(1-D.mot/100)+.25*(1-D.com/100):k==='s'?.05+.5*(1-D.com/100):k==='tb'?.16+.2*(1-D.tor/100):.03+.15*(1-D.com/100);
    ig*=clamp(pen/45,.4,1.5);if(D.com<=0)ig=Math.max(ig,.55);if(D.fire<=0&&R()<ig)cpIgnite(t,D,Z.tur?1:0)}
  _W.copy(P).lerp(v2.set(t.x,t.y+1.3,t.z),.5);
  if(pen>=10){CPFX.flash(_W.x,_W.y,_W.z,1.8+pen*.02);CPFX.spark(_W.x,_W.y,_W.z,6,8);CPFX.smoke(_W.x,_W.y,_W.z,.9,1.6,.12,.8,2);CPFX.smoke(_W.x,_W.y,_W.z,.7,1.2,.3,.6,1.5);if(pen>=14)cpChunk(_W.x,_W.y,_W.z,3,.4);cpDecal(t,D,Z,pen)}
  else{CPFX.spark(_W.x,_W.y,_W.z,5,5);CPFX.smoke(_W.x,_W.y,_W.z,.5,.8,.6,.5,1);if(R()<.5)cpDecal(t,D,Z,pen)}
  let msg=null;
  for(let i=0;i<6;i++){const n=D[ks[i]];if(o0[i]>0&&n<=0){msg=cpMsg(t,ks[i],1);cpChunk(t.x,t.y+1.6,t.z,5,.5);CPFX.smoke(_W.x,_W.y,_W.z,1.3,2.4,.05,.85,2.5)}else if(!msg&&o0[i]>=75&&n<75)msg=cpMsg(t,ks[i],0)}
  if(msg&&t.isPlayer)toast(msg);
  return a*mul}
function cpIgnite(t,D,z){D.fire=11+Math.random()*7;D.fz=z;D.fx=0;if(t.isPlayer)toast(D.ext?'INCÊNDIO! Extintor automático acionando':'INCÊNDIO! Entre na água ou pegue uma caixa de reparo')}
function cpOut(t,D,m){D.fire=0;if(t.isPlayer&&m)toast(m)}
function cpField(t,D){let w=null,wv=40;for(const k of['esq','dir','mot','tor','can'])if(D[k]<wv){wv=D[k];w=k}if(!w)return;D[w]=Math.min(40,D[w]+18);D.dirty=1;if(t.isPlayer)toast('Equipe reparou: '+(w==='mot'?'motor':w==='tor'?'torre':w==='can'?'canhão':cpWheeled(t)?'rodas':'esteira'))}
/* a cada frame, por veiculo ferido: giro da torre, mobilidade, vazamento, fogo, reparo de campo e fumaca */
function cpTick(t,dt){
  const D=t.cp,R=Math.random;D.t+=dt;
  if(D.tor<85){const r=D.tor<=0?.04:.12+2.6*Math.pow(D.tor/100,1.5),m=r*dt;t.yaw=D.yl+clamp(angDiff(t.yaw,D.yl),-m,m)}D.yl=t.yaw;
  const eL=D.esq,eR=D.dir,mn=Math.min(eL,eR),mx=Math.max(eL,eR);
  if(D.mot>0&&D.mot<45&&D.fu>0){if(D.stall>0)D.stall-=dt;else if(R()<dt*(45-D.mot)/45*.45){D.stall=.7+R()*1.1;if(t.isPlayer)cpToast(D,'st','Motor falhando!')}}else D.stall=0;
  D.mob=D.stall>0?0:(D.mot<=0?0:.3+.7*D.mot/100)*(D.fu<=0?0:D.fu<12?.5:1)*(mx<=0?0:mn<=0?.22:.35+.65*(eL+eR)/200);
  D.tmob=mx<=0?.5:mn<=0?.55:1-.3*(1-(eL+eR)/200);D.drift=(eR-eL)/100*.8*clamp(t.v/8,-1,1);D.tilt=(eL-eR)/100*.09;
  if(D.com<60&&D.fu>0){D.fu=Math.max(0,D.fu-(60-D.com)/60*2.4*dt*(D.fire>0?2:1));if(D.fu<=0&&t.isPlayer)cpToast(D,'fu','Sem combustível!')}
  if(D.fire>0){D.fx+=dt;D.fire-=dt*(D.com<30&&D.fu>0?.5:1);D.mot=Math.max(0,D.mot-dt*(D.fz?.5:2.5));D.com=Math.max(0,D.com-dt*1.5);D.dirty=1;
    if(D.ext&&D.fx>3){D.ext=0;cpOut(t,D,'Extintor automático apagou o fogo')}else if(t.wet>.8)cpOut(t,D,'Fogo apagado pela água');else if(D.fire<=0)cpOut(t,D,'Incêndio apagado');
    hpCore(t,D.mhp*(D.fz?.012:.016)*dt,D.by,true);if(t.dead)return}
  if(Math.abs(t.v)<.6&&D.fire<=0){D.fix+=dt;if(D.fix>=9){D.fix=0;cpField(t,D)}}else D.fix=Math.max(0,D.fix-dt*.5);
  if(D.dirty){D.dirty=0;t.mat.color.copy(D.c0).lerp(CPCH,(1-D.bld/100)*.75);cpTracks(t,D)}
  const pd=Math.hypot(t.x-player.x,t.z-player.z);if(pd>230)return;
  const lod=pd>110?2:1,L=t.L||3,W=t.W||2;
  if(D.mot<90||(D.fire>0&&!D.fz)){D.e1-=dt;if(D.e1<=0){const sv=Math.max(.15,1-D.mot/100);D.e1=(.17+R()*.1)*lod*(1.3-sv*.6);t.g.localToWorld(_W.set((R()-.5)*1.4,1.75,-L*.72));CPFX.smoke(_W.x,_W.y,_W.z,.9+sv*1.6,2+sv*2.4,sv<.45?.6:.1,.65+sv*.3,1.8+sv*1.6)}}
  if(D.fire>0){D.e2-=dt;if(D.e2<=0){D.e2=.03*lod;(D.fz?t.tg:t.g).localToWorld(D.fz?_W.set((R()-.5)*.8,.95,-.3+(R()-.5)*.8):_W.set((R()-.5)*1.2,1.7,-L*.7+(R()-.5)*1.2));CPFX.fire(_W.x,_W.y,_W.z,1.2+R()*.7,.6+R()*.4);if(R()<.8)CPFX.smoke(_W.x,_W.y+.6,_W.z,1.7,3.4,.08,.9,3)}}
  for(let i=0;i<2;i++){const v=i?D.dir:D.esq,k=i?'e3':'e4';if(v<85&&Math.abs(t.v)>.8){D[k]-=dt;if(D[k]<=0){D[k]=(.09+R()*.06)*lod;t.g.localToWorld(_W.set((i?-1:1)*(W+.3),.25,-L*.3+(R()-.5)*L));CPFX.smoke(_W.x,_W.y,_W.z,.8+(1-v/100)*.6,.9,.5,.6,.9);if(v<60)CPFX.spark(_W.x,_W.y,_W.z,5,v<=0?6:2)}}}
  if(D.tor<80){D.e5-=dt;if(D.e5<=0){D.e5=(.3+R()*.2)*lod;t.tg.localToWorld(_W.set((R()-.5)*.8,.9,-.4+(R()-.5)*.6));CPFX.smoke(_W.x,_W.y,_W.z,.5,1.6,D.tor<=0?.1:.5,.5,1.4);if(D.tor<=0&&R()<.35)CPFX.spark(_W.x,_W.y,_W.z,2.5,2)}}
  if(D.can<75){D.e6-=dt;if(D.e6<=0){D.e6=(.35+R()*.3)*lod;t.bp.getWorldPosition(_W);_W.addScaledVector(dirOf(t.yaw,t.pitch),t.mz||4.3);CPFX.smoke(_W.x,_W.y,_W.z,.35,1.1,D.can<=0?.12:.55,.45,.9)}}
  if(D.com<75&&D.fu>0){D.e7-=dt;if(D.e7<=0){D.e7=(.22+R()*.2)*lod;t.g.localToWorld(_W.set((R()<.5?-1:1)*(W-.2),.35,-L*.55*R()));CPFX.smoke(_W.x,_W.y,_W.z,.28,.9,.05,.6,.15)}}
}
/* depois do place(): casco pende para o lado da esteira ruim e o cano entorta */
function cpPost(t){const D=t.cp;if(D.tilt)t.g.rotation.z+=D.tilt;if(D.can<45)t.bp.rotation.x+=(45-D.can)/45*.06}
const cpTkG=new THREE.BoxGeometry(1,.1,3.2),cpTkM=new THREE.MeshLambertMaterial({color:0x232420});
function cpTracks(t,D){const wh=cpWheeled(t);
  for(let i=0;i<2;i++){const v=i?D.dir:D.esq,s=v<=0?2:v<45?1:0;if(D.tk[i]===s)continue;D.tk[i]=s;let m=D.tm[i];
    if(s&&!m){m=D.tm[i]=new THREE.Mesh(cpTkG,cpTkM);t.g.add(m)}if(!m)continue;m.visible=s>0;m.scale.set(wh?.5:1,1,wh?.55:1);const sd=i?-1:1,L=t.L||3,W=(t.W||2)+.3;
    if(s===1){m.position.set(sd*W,.22,-L*.55);m.rotation.set(0,sd*.12,-sd*.7)}else if(s===2){m.position.set(sd*(W+.45),.08,-L*1.05);m.rotation.set(0,sd*.2,0)}}}
const cpDecT=canvasTex(64,64,(x,w,h)=>{const g=x.createRadialGradient(32,32,2,32,32,31);g.addColorStop(0,'rgba(8,8,6,.95)');g.addColorStop(.35,'rgba(14,12,10,.75)');g.addColorStop(1,'rgba(20,18,14,0)');x.fillStyle=g;x.fillRect(0,0,w,h);
  x.strokeStyle='rgba(120,116,104,.55)';x.lineWidth=1.5;x.beginPath();x.arc(32,32,8,0,7);x.stroke();x.fillStyle='rgba(0,0,0,.95)';x.beginPath();x.arc(32,32,6,0,7);x.fill()});
const cpDG=new THREE.PlaneGeometry(1,1),cpDM=new THREE.MeshBasicMaterial({map:cpDecT,transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-3,polygonOffsetUnits:-3}),CPDS=[],cpDebM=new THREE.MeshLambertMaterial({color:0x2b2a27});
function cpDrop(m){if(m.parent)m.parent.remove(m);const i=CPDS.indexOf(m);if(i>=0)CPDS.splice(i,1)}
/* marca de impacto na regiao atingida (maximo 6 por veiculo e 70 no jogo) */
function cpDecal(t,D,Z,pen){const L=t.L||3,W=(t.W||2)+.25,R=Math.random,s=clamp(.4+pen*.012,.4,1.2)*(.8+R()*.4);let par,x,y,z,ry;
  if(Z.tur){par=t.tg;x=Math.sin(Z.az)*1.15;z=Math.cos(Z.az)*1.15;y=.25+R()*.5;ry=Z.az}
  else{par=t.g;y=.5+R()*.8;if(Z.k==='f'){x=(R()-.5)*2.2;z=L*.94;ry=0}else if(Z.k==='r'){x=(R()-.5)*2.2;z=-L*.97;ry=Math.PI}else{const sd=Z.lx>0?1:-1;x=sd*W;z=(R()-.5)*L*1.4;ry=sd*Math.PI/2}}
  const m=new THREE.Mesh(cpDG,cpDM);m.position.set(x,y,z);m.rotation.y=ry;m.scale.setScalar(s);par.add(m);D.dec.push(m);CPDS.push(m);
  if(D.dec.length>10)cpDrop(D.dec.shift());if(CPDS.length>110)cpDrop(CPDS[0])}
function cpChunk(x,y,z,n,sz){for(let i=0;i<n;i++){const m=new THREE.Mesh(dg,cpDebM),s=sz*(.6+Math.random());m.scale.set(s,s*.5,s*1.4);m.position.set(x,y,z);m.rotation.set(Math.random()*3,Math.random()*3,0);scene.add(m);
  debris.push({m,s,t:7,v:new THREE.Vector3((Math.random()-.5)*9,3+Math.random()*5,(Math.random()-.5)*9)})}while(debris.length>260)scene.remove(debris.shift().m)}
const cpDmg=t=>!!t.cp&&(t.cp.fire>0||['mot','esq','dir','tor','can','com'].some(k=>t.cp[k]<35));
function cpRepair(t){const D=t.cp;if(!D)return;for(const k of CPK)D[k]=Math.min(100,D[k]+(k==='bld'?45:60));D.fu=100;D.fire=0;D.stall=0;D.ext=cpModern(t)?1:0;D.dirty=1;for(const m of D.dec.splice(0))cpDrop(m)}
/* tiro: falhas, recarga lenta e dispersao conforme o dano do canhao */
function cpJam(t){const D=t.cp,c=D.can;if(c>=85)return false;
  if(c<=0||Math.random()<(1-c/100)*.55){t.bp.getWorldPosition(v1);v1.addScaledVector(dirOf(t.yaw,t.pitch),t.mz||4.3);CPFX.smoke(v1.x,v1.y,v1.z,.7,1,.15,.8,1.5);CPFX.spark(v1.x,v1.y,v1.z,3,3);sfx(.1*near(v1),.08);
    t.cd+=1.1+Math.random()*1.2+(c<=0?1.5:0);if(t.isPlayer)cpToast(D,'jam','Falha de tiro!');return true}
  t.cd+=(1-c/100)*.8*(t.rld||2);return false}
function cpDir(t){const sp=Math.max(0,1-t.cp.can/85)*.045;return dirOf(t.yaw+(Math.random()-.5)*2*sp,t.pitch+(Math.random()-.5)*sp)}
/* painel de componentes do jogador (aparece depois do primeiro dano) */
const cpEl=document.getElementById('cpd'),CPL={mot:'MOT',esq:'ESQ',dir:'DIR',tor:'TOR',can:'CAN',com:'COM',bld:'BLD'};let cpHT=0,cpHS='';
function cpHud(dt){const D=player.cp;
  if(!D||player.dead||!running){if(cpHS){cpHS='';cpEl.className='hud'}return}
  cpHT-=dt;if(cpHT>0)return;cpHT=.15;let s=D.fire>0?'F':'',any=D.fire>0;const c=[];
  for(const k of CPK){const v=k==='com'?Math.min(D.com,D.fu):D[k],q=v<=0?'x':v<34?'r':v<67?'y':'g';c.push(q);s+=q;if(v<90)any=true}
  if(!any){if(cpHS){cpHS='';cpEl.className='hud'}return}
  if(s===cpHS)return;cpHS=s;
  if(!cpEl.firstChild)cpEl.innerHTML=CPK.map(k=>'<b>'+CPL[k]+'</b>').join('')+'<b class="f">FOGO</b>';
  CPK.forEach((k,i)=>{cpEl.children[i].className=c[i]});cpEl.className='hud on'+(D.fire>0?' fire':'')}
function fire(t){
  if(NET.host&&NET.conns.length&&!t.bfi&&!t.proxy)netBc({t:'fi',n:t.nid||(t.nid=++NET.seq)},t.remote);
  if(t.cp&&cpJam(t))return;
  if(t.boxer&&!t.bfi){t.bn=2;t.bt=.11}
  if(t.cv90&&!t.bfi){t.bn=2;t.bt=.13}
  if(t.gep&&!t.bfi){t.bn=4;t.bt=.07}
  if(t.zsu&&!t.bfi){t.bn=4;t.bt=.06}
  if(t.pz1&&!t.bfi){t.bn=2;t.bt=.09}
  if(t.l3&&!t.bfi){t.bn=2;t.bt=.1}
  if(t.t27&&!t.bfi){t.bn=2;t.bt=.11}
  if(t.corv&&!t.bfi){t.bn=2;t.bt=.14}
  if(t.pant&&!t.bfi){t.bn=2;t.bt=.06}
  if(t.aven&&!t.bfi){if(t.lk&&!t.lk.dead&&t.mcd<=0)return stingerFire(t);t.bn=3;t.bt=.07}
  if(t.pzh&&!t.bfi){t.bn=2;t.bt=.8}
  if(t.stry)return towFire(t);
  if(t.astros)return salvo(t);
  if(t.abv)return miclic(t);
  if(t.h225){if(!t.isPlayer&&Math.random()<.3){t.sv=4;t.sT=0;return}return chFire(t)}
  if(t.ap)return apFire(t);if(t.ch47)return chFire(t);
  const d=t.cp?cpDir(t):dirOf(t.yaw,t.pitch);t.bp.getWorldPosition(v1);v1.addScaledVector(d,t.mz||4.3);if(t.abrams||t.tiger||t.cannon)return abramsFire(t,d);
  const m=new THREE.Mesh(sg,t===player?shellP:shellE);m.position.copy(v1);scene.add(m);
  shells.push({m,v:d.multiplyScalar(SPEED),owner:t,age:0});t.recoil=1;
  for(let i=0;i<4;i++)puff(v1,0xd8d0c0,.9,3,.5,.5);snd('cannon',.55*near(v1));
}
function damage(t,a,by){
  if(NET.guest||t.dead)return;
  const D=t.cp||(a>=.3&&!t.air&&!t.corv?cpInit(t):null);if(D)a=cpHit(t,D,a,by);
  hpCore(t,a,by,false);
}
function hpCore(t,a,by,q){
  if(NET.guest&&!NET.f)return;if(t.dead)return;a*=(t.armor||1)*(t.cperk?1-t.cperk.arm:1);t.hp-=a;if(by&&by!==t&&(by.isPlayer||by.remote)&&!t.isPlayer&&!t.remote&&!t.ally)stOf(by.remote||'host').d+=a;
  if(!q){
  if(t.isPlayer){hurt=1;shake=Math.max(shake,Math.min(1.4,a/10))}
  if(t.isPlayer&&by&&by!==t)dmgDir(by);if(by&&by.isPlayer&&!t.isPlayer)hitMark();
  }
  if(t.hp<=0){
    t.hp=0;t.dead=true;t.v=0;t.mat.color.set(0x1c1b19);
    for(let i=0;i<14;i++)puff(new THREE.Vector3(t.x,t.y+2,t.z),i%2?0x2b2a28:0xff8a1f,2.2,7,2.5,4);
    if(by&&by!==t)feed(by,t);if(t.isPlayer)gameOver();else if(by&&(by.isPlayer||by.remote)){kills++;credit(by,t);document.getElementById('kl').textContent=kills;onKill()}
  }
}
function boom(p,owner,k=1){
  const R=12*k;
  if(p.y<getH(p.x,p.z)+7)crater(p.x,p.z,7.5*k,3.4*k);
  for(let i=0;i<10;i++)puff(p,i%2?0xffd36b:0xff8a2e,2,6,.6,3);
  for(let i=0;i<12;i++)puff(p,0x3a3835,2.6,6,2.2,4);
  sfx(near(p),.8);
  for(const t of tanks){const d=Math.hypot(p.x-t.x,p.y-(t.y+1),p.z-t.z);if(d<R&&hostile(t,owner)&&!t.dead){dmP=p;damage(t,(60*(1-d/R)+(d<3.5?20:0))*k,owner);dmP=null}}
  for(let i=buildings.length-1;i>=0;i--){
    const b=buildings[i],d=Math.hypot(p.x-b.x,p.z-b.z),reach=R+Math.max(b.w,b.d)/2;
    if(d<reach){
      const dmg=90*(1-d/reach);b.hp-=dmg;
      if(p.y-b.y<clamp(b.h*.32,4.5,9))b.base-=dmg*(b.stilt?1.6:1); /* tiro na base: estrutura cede */
      if(b.base<=0&&b.h>=4)topple(b,p,owner);
      else if(b.hp<=0)destroyB(b);
      else{scorch(b,.82);crumble(b);if(b.base<b.base0*.75)breach(b,p)}
    }
  }
  bridgeBlast(p,R,k,owner);
  for(let i=trees.length-1;i>=0;i--)if(Math.hypot(p.x-trees[i].x,p.z-trees[i].z)<9)killTree(trees[i]);
  for(let i=props.length-1;i>=0;i--)if(Math.hypot(p.x-props[i].x,p.z-props[i].z)<8)killProp(props[i]);
  shake=Math.max(shake,1.6*near(p));
}
const ruinM=new THREE.MeshLambertMaterial({color:0x3a342d});
function destroyB(b){
  scene.remove(b.m);{const bi=buildings.indexOf(b);if(bi>=0)buildings.splice(bi,1)}
  const mat=new THREE.MeshLambertMaterial({color:b.color}),n=clamp(Math.round(b.w*b.d/5)+8,10,30);
  for(let i=0;i<n;i++){
    const m=new THREE.Mesh(dg,mat),s=.6+Math.random()*1.6;
    m.scale.set(s,s*(.5+Math.random()),s);m.castShadow=true;
    m.position.set(b.x+(Math.random()-.5)*b.w,b.y+Math.random()*b.h,b.z+(Math.random()-.5)*b.d);m.rotation.set(Math.random()*3,Math.random()*3,0);
    scene.add(m);debris.push({m,s,t:14,v:new THREE.Vector3((Math.random()-.5)*14,6+Math.random()*10,(Math.random()-.5)*14)});
  }
  const ru=new THREE.Mesh(dg,ruinM);ru.scale.set(b.w*.85,.5+Math.random()*.7,b.d*.85);ru.position.set(b.x,getH(b.x,b.z)+.1,b.z);ru.rotation.y=(Math.random()-.5)*.3;ru.receiveShadow=true;scene.add(ru);
  for(let i=0;i<10;i++)puff(new THREE.Vector3(b.x,b.y+b.h/2,b.z),0xb9b0a0,3,8,2.6,3);
  while(debris.length>260){const o=debris.shift();scene.remove(o.m)}
}
/* ---------- desabamento: base destruida derruba o predio, que pode esmagar quem estiver embaixo ---------- */
function ramOf(t){return t.m109?1.5:t.zsu?1:t.maus?3:t.cro?1.9:t.pzh?1.5:t.merk?1.7:t.t80?1.45:t.t90||t.t72?1.45:t.t35?2.2:t.mk1?1.9:t.ch2||t.abrams||t.tiger?1.7:t.leo||t.arm14||t.pl01||t.stk?1.5:t.jp||t.su?1.3:t.sher||t.t34?1:0}
const falling=[],breachM=new THREE.MeshLambertMaterial({color:0x14110e}),rubM=new THREE.MeshLambertMaterial({color:0x8a8478}),boxK=new THREE.BoxGeometry(1,1,1);
function breach(b,p){
  if((b.nb||0)>=3)return;b.nb=(b.nb||0)+1;
  const dx=p.x-b.x,dz=p.z-b.z,hw=b.w/2,hd=b.d/2,fx=Math.abs(dx)/hw>Math.abs(dz)/hd,s=1.6+Math.random()*1.6,hh=Math.min(3.4,b.h*.5),g=new THREE.Group();
  const hole=new THREE.Mesh(boxK,breachM);
  if(fx){const sx=Math.sign(dx)||1;hole.scale.set(.5,hh,s);hole.position.set(sx*(hw+.03),hh/2,clamp(dz,-hd+s/2,hd-s/2));
    for(let i=0;i<5;i++){const r=new THREE.Mesh(boxK,rubM),q=.25+Math.random()*.55;r.scale.set(q,q*.8,q);r.position.set(sx*(hw+.4+Math.random()*1.2),q*.4,hole.position.z+(Math.random()-.5)*(s+1.4));r.rotation.set(Math.random()*3,Math.random()*3,Math.random()*3);g.add(r)}}
  else{const sz=Math.sign(dz)||1;hole.scale.set(s,hh,.5);hole.position.set(clamp(dx,-hw+s/2,hw-s/2),hh/2,sz*(hd+.03));
    for(let i=0;i<5;i++){const r=new THREE.Mesh(boxK,rubM),q=.25+Math.random()*.55;r.scale.set(q,q*.8,q);r.position.set(hole.position.x+(Math.random()-.5)*(s+1.4),q*.4,sz*(hd+.4+Math.random()*1.2));r.rotation.set(Math.random()*3,Math.random()*3,Math.random()*3);g.add(r)}}
  g.add(hole);g.traverse(m=>{if(m.isMesh)m.castShadow=true});b.m.add(g);
  for(let i=0;i<6;i++)puff(v3.set(p.x,b.y+1.5,p.z),0x8a8478,2.4,4,1.8,2);
}
function topple(b,p,owner){
  const bi=buildings.indexOf(b);if(bi>=0)buildings.splice(bi,1);
  let dx=p.x-b.x,dz=p.z-b.z,l=Math.hypot(dx,dz);
  if(l<.6){dx=Math.random()-.5;dz=Math.random()-.5;l=Math.hypot(dx,dz)||1}
  dx/=l;dz/=l;
  const ext=Math.abs(dx)*b.w/2+Math.abs(dz)*b.d/2,wd=Math.abs(dz)*b.w+Math.abs(dx)*b.d,pv=new THREE.Group();
  pv.position.set(b.x+dx*ext,b.y,b.z+dz*ext);scene.add(pv);pv.attach(b.m);
  falling.push({b,pv,dx,dz,ax:new THREE.Vector3(dz,0,-dx),th:.04,w:.12,L:b.h,wd,px:pv.position.x,pz:pv.position.z,hit:new Set(),own:owner,t:0});
  const c=v3.set(b.x,b.y+1.5,b.z);
  for(let i=0;i<12;i++)puff(c,i%2?0x8a8478:0x3a3835,3.2,6,2.4,3);
  for(let i=0;i<8;i++){const m=new THREE.Mesh(dg,new THREE.MeshLambertMaterial({color:b.color})),s=.5+Math.random()*1.1;m.scale.set(s,s*.7,s);m.position.set(b.x+dx*ext*.9+(Math.random()-.5)*b.w,b.y+Math.random()*2.5,b.z+dz*ext*.9+(Math.random()-.5)*b.d);scene.add(m);debris.push({m,s,t:9,v:new THREE.Vector3(dx*(2+Math.random()*5)+(Math.random()-.5)*5,2+Math.random()*5,dz*(2+Math.random()*5)+(Math.random()-.5)*5)})}
  shake=Math.max(shake,1.5*near(c));sfx(near(c),.7);
  if(owner&&owner.isPlayer)toast(b.type==='agua'?'A caixa d\'água desabou!':'A base cedeu: o prédio está caindo!');
}
function landB(f){
  const b=f.b,dx=f.dx,dz=f.dz,L=f.L,hw=f.wd/2;
  scene.remove(f.pv);
  const mat=new THREE.MeshLambertMaterial({color:b.color}),n=clamp(Math.round(b.w*b.d/4)+14,16,34);
  for(let i=0;i<n;i++){
    const u=Math.random()*L,lat=(Math.random()-.5)*f.wd,x=f.px+dx*u-dz*lat,z=f.pz+dz*u+dx*lat,m=new THREE.Mesh(dg,mat),s=.5+Math.random()*1.4;
    m.scale.set(s,s*(.4+Math.random()*.8),s);m.castShadow=true;m.position.set(x,getH(x,z)+.6,z);m.rotation.set(Math.random()*3,Math.random()*3,0);scene.add(m);
    debris.push({m,s,t:16,v:new THREE.Vector3((Math.random()-.5)*5+dx*Math.random()*4,2+Math.random()*5,(Math.random()-.5)*5+dz*Math.random()*4)});
  }
  for(const k of[.2,.5,.8]){
    const u=L*k,x=f.px+dx*u,z=f.pz+dz*u,ru=new THREE.Mesh(dg,ruinM);
    ru.scale.set(f.wd*.85,.5+Math.random()*.9,L*.32);ru.position.set(x,getH(x,z)+.1,z);ru.rotation.y=Math.atan2(dx,dz);ru.receiveShadow=true;scene.add(ru);
  }
  const wat=b.type==='agua';
  for(let i=0;i<16;i++){const u=Math.random()*L,x=f.px+dx*u,z=f.pz+dz*u;puff(v3.set(x,getH(x,z)+1,z),wat&&i%2?0x9fd0ea:0xb9b0a0,3.2,7,2.8,3)}
  for(let i=trees.length-1;i>=0;i--){const q=trees[i],rx=q.x-f.px,rz=q.z-f.pz,s=rx*dx+rz*dz,lat=Math.abs(-rx*dz+rz*dx);if(s>-1&&s<L&&lat<hw+1.5)killTree(q)}
  for(let i=props.length-1;i>=0;i--){const q=props[i],rx=q.x-f.px,rz=q.z-f.pz,s=rx*dx+rz*dz,lat=Math.abs(-rx*dz+rz*dx);if(s>-1&&s<L&&lat<hw+1.5)killProp(q)}
  for(let i=buildings.length-1;i>=0;i--){const q=buildings[i],rx=q.x-f.px,rz=q.z-f.pz,s=rx*dx+rz*dz,lat=Math.abs(-rx*dz+rz*dx);
    if(s>0&&s<L&&lat<hw+q.w/2){q.hp-=70;if(q.hp<=0)destroyB(q);else{scorch(q,.8);crumble(q)}}}
  const c=v3.set(f.px+dx*L*.5,b.y,f.pz+dz*L*.5);shake=Math.max(shake,2.6*near(c));sfx(near(c),.9);
  while(debris.length>260){const o=debris.shift();scene.remove(o.m)}
}
function fallUpdate(dt){
  for(let i=falling.length-1;i>=0;i--){
    const f=falling[i];f.t+=dt;
    f.w+=dt*(1.3+3.8*Math.sin(f.th))*clamp(14/f.b.h,.45,1.2);f.th+=f.w*dt; /* prédio alto cai mais devagar */
    const done=f.th>=1.5;if(done)f.th=1.5708;
    f.pv.quaternion.setFromAxisAngle(f.ax,f.th);
    const sn=Math.sin(f.th),tn=Math.tan(f.th),reach=f.L*sn;
    for(const t of tanks){
      if(t.dead||f.hit.has(t))continue;
      const rx=t.x-f.px,rz=t.z-f.pz,s=rx*f.dx+rz*f.dz,lat=Math.abs(-rx*f.dz+rz*f.dx);
      if(s>-1.5&&s<reach+1&&lat<f.wd/2+1.6&&s/Math.max(.05,tn)<4){
        f.hit.add(t);const a=clamp(f.b.hp0,35,110)*(1-.35*clamp(s/f.L,0,1));
        dmP=new THREE.Vector3(t.x+f.dx*1.5,t.y+4,t.z+f.dz*1.5);damage(t,a,f.own);dmP=null;t.v*=.2;
        v3.set(t.x,t.y+2,t.z);for(let k=0;k<8;k++)puff(v3,k%2?0x8a8478:0x3a3835,2.4,5,1.6,3);
        if(t.isPlayer)toast('Esmagado pelo prédio que caiu!');
      }
    }
    if(Math.random()<dt*12){const u=Math.random()*f.L*sn,x=f.px+f.dx*u,z=f.pz+f.dz*u;puff(v3.set(x,getH(x,z)+Math.max(.5,u/Math.max(.1,tn)),z),0xb9b0a0,2.2,3,1.6,1)}
    if(done){landB(f);falling.splice(i,1)}
  }
}
function splash(p){v3.set(p.x,WATER+.2,p.z);for(let i=0;i<8;i++)puff(v3,i%2?0xe6f3fa:0xb7d8ea,2,5,.9,6);sfx(.35*near(v3),.25)}

/* ===== progressao, comandos do time, suprimentos, barras, som e clima ===== */
const vname=t=>t.m2lt?'M2 Light Tank':t.t27?'T-27':t.l3?'L3/35':t.pz1?'Panzer I':t.zsu?'ZSU-23-4 Shilka':t.m109?'M109':t.cro?'Churchill Crocodile':t.pzh?'PzH 2000':t.corv?'Corveta':t.pant?'Pantsir-S1':t.aven?'AN/TWQ-1 Avenger':t.h225?'H225M Caracal':t.cv90?'CV90':t.stry?'M1134 Stryker ATGM':t.agmv?'M1297 AGMV':t.gep?'Gepard 1A2':t.ch47?'CH-47 Chinook':t.ap?'AH-64 Apache':t.merk?'Merkava Mk 4':t.boxer?'Boxer CRV':t.t80?'T-80BVM':t.t90?'T-90A':t.t72?'T-72B':t.arm14?'T-14 Armata':t.roo?'Rooikat':t.amr?'AMX-10RC':t.su?'SU-100':t.amx?'AMX-13':t.ku?'SK-105':t.maus?'Maus':t.sher?'Sherman':t.ch2?'Challenger 2':t.stk?'Strv 103':t.jp?'Jagdpanther':t.hz?'Hetzer':t.t34?'T-34/85':t.t35?'T-35':t.leo?'Leopard 2A6':t.pl01?'PL-01':t.gua?'Guarani':t.m270?'M270':t.casc?'Cascavel':t.stuart?'Stuart':t.mk1?'Mark I':t.tiger?'Tiger I':t.abrams?'Abrams':t.astros?'ASTROS':t.abv?'M1150':'Tanque';
const tcol=t=>t.idle?'#9fb0bd':(t.ally||t.isPlayer)?'#ffd27a':t.team===5?'#ff7ac8':t.team===4?'#b06cff':t.team===2?'#4aa3ff':t.team===3?'#3fd25a':'#ff6a4a';
const mhpOf=t=>t.mhp||(t.mhp=Math.max(t.hp,60));
let cmd='attack',ammoT=0;
/* progressao salva no aparelho */
const SAVE_K='blindados_save_v1';let save={kills:0,wave:0,best:0,games:0};
try{const s=JSON.parse(localStorage.getItem(SAVE_K)||'null');if(s&&typeof s.kills==='number')save=Object.assign(save,s)}catch(e){}
const persist=()=>{try{localStorage.setItem(SAVE_K,JSON.stringify(save))}catch(e){}};
const UNL={m2:12,t27:6,l3:8,pz1:10,zsu:95,m109:125,cro:75,pzh:130,corv:30,pant:70,aven:55,tank:0,gep:65,arm:150,stuart:0,mk1:10,casc:20,gua:35,abrams:50,tiger:75,m270:100,astros:140,abv:180,t34:25,pl:60,t35:85,leo:120,hz:45,stk:130,jp:155,ch2:145,sher:15,maus:200,su:165,amx:40,ku:70,amr:95,roo:135,t72:55,t90:110,t80:90,mk4:150,bxr:105,ap:160,ch47:170,cv90:115,agmv:20,stry:125,h225:150};
const RANKS=[[0,'Recruta'],[5,'Soldado'],[15,'Cabo'],[30,'Sargento'],[60,'Subtenente'],[100,'Tenente'],[160,'Capitão'],[240,'Major'],[350,'Coronel'],[500,'General']];
const rankOf=k=>{let r=RANKS[0][1];for(const x of RANKS)if(k>=x[0])r=x[1];return r};
const TESTE=true; /* modo de teste: todos os veículos liberados; troque por false para voltar à progressão */
const unlocked=q=>TESTE||save.kills>=(UNL[q]||0);
function refreshProg(){
  for(const q in VID){const b=document.getElementById(VID[q]);if(!b.dataset.n)b.dataset.n=b.textContent;const u=unlocked(q);b.disabled=!u;b.style.opacity=u?1:.45;b.textContent=u?b.dataset.n:'🔒 '+b.dataset.n+' · '+UNL[q]}
  const e=document.getElementById('prog');if(e)e.textContent='Patente: '+rankOf(save.kills)+' · Abates totais: '+save.kills+' · Recorde: '+save.best+' abates, onda '+save.wave;
}
refreshProg();
function onKill(){
  save.kills++;save.best=Math.max(save.best,kills);
  for(const q in UNL)if(UNL[q]>0&&UNL[q]===save.kills)toast('Desbloqueado: '+document.getElementById(VID[q]).dataset.n);
  persist();refreshProg();
}
/* registro de abates, marcador de acerto e seta de dano */
const feedEl=document.getElementById('feed'),dmgW=document.getElementById('dmgw'),barsEl=document.getElementById('bars'),cmdEl=document.getElementById('cmds'),barPool=[];
function feed(by,t){const d=document.createElement('div');d.innerHTML='<b style="color:'+tcol(by)+'">'+vname(by)+'</b> ✕ <b style="color:'+tcol(t)+'">'+vname(t)+'</b>';feedEl.appendChild(d);while(feedEl.children.length>4)feedEl.removeChild(feedEl.firstChild);setTimeout(()=>d.remove(),5500)}
function hitMark(){retEl.classList.add('hit');clearTimeout(hitMark.h);hitMark.h=setTimeout(()=>retEl.classList.remove('hit'),140)}
function dmgDir(by){const a=angDiff(Math.atan2(by.x-player.x,by.z-player.z),player.yaw),d=document.createElement('div');d.className='dmg';d.style.transform='rotate('+(-a*57.3).toFixed(0)+'deg)';dmgW.appendChild(d);setTimeout(()=>d.remove(),1500)}
/* barras de vida e distancia sobre os veiculos */
function drawBars(){
  barsEl.style.display='block';let n=0;
  if(!player.dead){const L=[];for(const t of tanks){if(t.dead||t.isPlayer)continue;const d=Math.hypot(t.x-player.x,t.z-player.z);if(d<260)L.push([d,t])}
    L.sort((a,b)=>a[0]-b[0]);
    for(const [d,t] of L){if(n>=14)break;const s=toScr(t.x,t.y+(t.gua||t.m270?4.2:3.6),t.z);if(!s)continue;
      let e=barPool[n];if(!e){e=document.createElement('div');e.className='hb';e.innerHTML='<span></span><u><i></i></u>';barsEl.appendChild(e);barPool[n]=e}
      e.style.display='block';e.style.transform='translate('+s[0].toFixed(0)+'px,'+s[1].toFixed(0)+'px) translate(-50%,-100%)';
      const i=e.lastChild.firstChild;i.style.width=clamp(t.hp/mhpOf(t),0,1)*100+'%';i.style.background=tcol(t);
      e.firstChild.textContent=(t.boss?'☠ CHEFE · ':'')+(t.nick?t.nick+' · ':'')+vname(t)+' '+Math.round(d)+'m';e.style.opacity=clamp(1.4-d/200,.35,1);n++}}
  for(let k=n;k<barPool.length;k++)barPool[k].style.display='none';
}
/* comandos do time: 1 seguir, 2 atacar, 3 defender */
function setCmd(c){cmd=c;for(const b of cmdEl.children)b.classList.toggle('sel',b.dataset.c===c);toast({follow:'Time: seguir você',attack:'Time: atacar',hold:'Time: defender a posição'}[c])}
for(const b of cmdEl.children){b.addEventListener('touchstart',e=>{e.stopPropagation();e.preventDefault();setCmd(b.dataset.c)},{passive:false});b.addEventListener('mousedown',e=>e.stopPropagation());b.addEventListener('click',()=>setCmd(b.dataset.c))}
/* caixas de suprimento: verde repara, dourada acelera a recarga */
const crates=[],crateQ=[],crBox=new THREE.BoxGeometry(1.8,1.2,1.8),crPil=new THREE.CylinderGeometry(.25,.25,14,8),crA=new THREE.BoxGeometry(1.2,.06,.34),crB=new THREE.BoxGeometry(.34,.06,1.2);
function addCrate(kind,ax,az,rad){
  for(let k=0;k<100;k++){
    const a=Math.random()*6.28,r=rad*(.3+Math.random()*.7),x=ax+Math.cos(a)*r,z=az+Math.sin(a)*r;
    if(!spawnOK(x,z,8)||getH(x,z)<2)continue;
    const rep=kind==='rep',g=new THREE.Group(),b0=new THREE.Mesh(crBox,new THREE.MeshLambertMaterial({color:rep?0xf2f2ea:0x6b7a3a})),cm=new THREE.MeshLambertMaterial({color:rep?0xd6342a:0xffc400});
    b0.position.y=.7;const c1=new THREE.Mesh(crA,cm),c2=new THREE.Mesh(crB,cm);c1.position.y=c2.position.y=1.33;b0.add(c1,c2);c1.position.y=c2.position.y=.63;
    const pil=new THREE.Mesh(crPil,new THREE.MeshBasicMaterial({color:rep?0x5cff7a:0xffd040,transparent:true,opacity:.35,depthWrite:false}));pil.position.y=7;
    b0.castShadow=true;g.add(b0,pil);g.position.set(x,getH(x,z),z);scene.add(g);crates.push({g,b0,kind,x,z,ph:Math.random()*6});return;
  }
}
function spawnCrates(){addCrate('rep',0,0,50);addCrate('mun',0,0,50);for(let k=0;k<6;k++)addCrate(k%2?'mun':'rep',0,0,HALF-70)}
function crateUpdate(dt,now){
  for(let i=crates.length-1;i>=0;i--){const c=crates[i];c.b0.rotation.y+=dt*1.2;c.b0.position.y=.7+Math.sin(now*2+c.ph)*.15;
    let who=null;
    for(const t of tanks){if(t.dead)continue;if(!t.isPlayer&&(c.kind!=='rep'||(t.hp>=.7*mhpOf(t)&&!cpDmg(t))))continue;if(Math.hypot(t.x-c.x,t.z-c.z)<4.2){who=t;break}}
    if(who){
      if(c.kind==='rep'){if(NET.guest&&who.isPlayer)netSend({t:'rep'});who.hp=Math.min(mhpOf(who),who.hp+mhpOf(who)*.45);cpRepair(who);if(who.isPlayer)toast('Reparo: blindagem +45%'+(who.cp?' e sistemas restaurados':''))}
      else{ammoT=25;who.cd=0;if(who.stry){who.tow=12;for(let i=0;i<2;i++)if(!who.rdy[i])who.rt2[i]=Math.min(who.rt2[i],1.5)}toast('Munição reforçada: recarga 2x mais rápida por 25 s')}
      for(let k=0;k<8;k++)puff(v3.set(c.x,getH(c.x,c.z)+1,c.z),c.kind==='rep'?0x7dff9a:0xffd040,1.2,4,.8,3);
      scene.remove(c.g);crates.splice(i,1);crateQ.push(40);
    }
  }
  for(let i=crateQ.length-1;i>=0;i--){crateQ[i]-=dt;if(crateQ[i]<=0){crateQ.splice(i,1);addCrate(Math.random()<.5?'rep':'mun',0,0,HALF-70)}}
  ammoT=Math.max(0,ammoT-dt);
}
/* som por tipo de arma, motor do jogador e chuva */
function snd(kind,vol){
  if(vol<.015)return;
  try{ac=ac||new AudioContext();const T=ac.currentTime,out=ac.destination;
    const noise=(len,type,f0,f1,v,q)=>{const n=ac.sampleRate*len|0,b=ac.createBuffer(1,n,ac.sampleRate),d=b.getChannelData(0);for(let i=0;i<n;i++)d[i]=(Math.random()*2-1)*Math.pow(1-i/n,2);const s=ac.createBufferSource(),f=ac.createBiquadFilter(),g=ac.createGain();s.buffer=b;f.type=type;f.frequency.setValueAtTime(f0,T);f.frequency.exponentialRampToValueAtTime(f1,T+len);if(q)f.Q.value=q;g.gain.value=v;s.connect(f);f.connect(g);g.connect(out);s.start(T)};
    const tone=(type,f0,f1,len,v)=>{const o=ac.createOscillator(),g=ac.createGain();o.type=type;o.frequency.setValueAtTime(f0,T);o.frequency.exponentialRampToValueAtTime(f1,T+len);g.gain.setValueAtTime(v,T);g.gain.exponentialRampToValueAtTime(.001,T+len);o.connect(g);g.connect(out);o.start(T);o.stop(T+len)};
    if(kind==='mg'){noise(.09,'bandpass',2800,1500,vol*1.4,1.2);tone('square',220,90,.05,vol*.25)}
    else if(kind==='rocket'){noise(1.1,'bandpass',500,2600,vol*.9,.8);tone('sawtooth',90,300,.5,vol*.15)}
    else if(kind==='light'){noise(.25,'lowpass',1500,300,vol,.7);tone('sine',200,70,.2,vol*.6)}
    else if(kind==='heavy'){noise(.55,'lowpass',700,120,vol,.7);tone('sine',90,28,.6,vol)}
    else{noise(.35,'lowpass',1000,200,vol,.7);tone('sine',130,42,.38,vol*.8)}
  }catch(e){}
}
let eng=null,rainS=null;
function engineUpdate(dt){
  if(!ac)return;
  if(!eng){const o=ac.createOscillator(),o2=ac.createOscillator(),f=ac.createBiquadFilter(),g=ac.createGain();o.type='sawtooth';o2.type='square';f.type='lowpass';f.frequency.value=260;g.gain.value=0;o.connect(f);o2.connect(f);f.connect(g);g.connect(ac.destination);o.start();o2.start();eng={o,o2,g,f}}
  const T=ac.currentTime;
  if(!running||player.dead){eng.g.gain.setTargetAtTime(0,T,.1);return}
  const base=player.m2lt?70:player.t27?85:player.l3?90:player.pz1?80:player.zsu?62:player.m109?55:player.cro?44:player.pzh?76:player.stry?70:player.cv90?74:player.agmv?60:player.gep?84:player.merk?88:player.boxer?72:player.t80?64:player.t90?64:player.t72?58:player.arm14?96:player.roo?74:player.amr?70:player.su?62:player.amx?90:player.ku?82:player.maus?30:player.sher?68:player.ch2?80:player.stk?70:player.jp?64:player.hz?80:player.leo?88:player.pl01?100:player.t34?58:player.t35?36:player.abrams?95:player.tiger?42:player.mk1?32:player.stuart?60:player.m270?50:player.astros?56:player.abv?48:player.gua?64:player.casc?66:50;
  const sp=Math.min(1,Math.abs(player.v)/14),thr=(keys.KeyW||keys.KeyS||Math.abs(stick.y)>.15)?1:0,fr=base*(1+sp*1.1+thr*.15);
  eng.o.frequency.setTargetAtTime(fr,T,.08);eng.o2.frequency.setTargetAtTime(fr*.5,T,.08);eng.f.frequency.setTargetAtTime(180+sp*320,T,.1);
  eng.g.gain.setTargetAtTime((.012+.03*sp+.012*thr)*(player.abrams?.7:1),T,.1);
}
/* ciclo de dia e noite, chuva e neblina */
const DAYLEN=330,envC={day:new THREE.Color(0xa9cde6),dusk:new THREE.Color(0xe8955f),night:new THREE.Color(0x0a1128),gray:new THREE.Color(0x929ba6)},tmpC=new THREE.Color(),tmpGray=new THREE.Color(),sunV=new THREE.Vector3(60,110,40);
const hemi=scene.children.find(o=>o.isHemisphereLight);
let tod=.22;const wx={cur:'clear',next:70+Math.random()*50,rw:0,fw:0};
const headl=new THREE.SpotLight(0xfff2cf,0,150,.55,.55,1);scene.add(headl,headl.target);
const RN=450,rainP=new Float32Array(RN*6),rainG=new THREE.BufferGeometry();
for(let i=0;i<RN;i++){const x=(Math.random()-.5)*70,y=Math.random()*40,z=(Math.random()-.5)*70;rainP.set([x,y,z,x,y-1.8,z],i*6)}
rainG.setAttribute('position',new THREE.BufferAttribute(rainP,3));
const rain=new THREE.LineSegments(rainG,new THREE.LineBasicMaterial({color:0xbfd0e0,transparent:true,opacity:0,fog:false,depthWrite:false}));rain.frustumCulled=false;rain.visible=false;scene.add(rain);
function envUpdate(dt){
  tod=(tod+dt/DAYLEN)%1;const a=tod*6.2832,k=clamp((Math.sin(a)+.55)/.5,0,1),dusk=1-Math.abs(k*2-1);
  wx.next-=dt;
  if(wx.next<=0){wx.next=50+Math.random()*80;const r=Math.random(),nc=r<.5?'clear':r<.8?'rain':'fog';if(nc!==wx.cur){wx.cur=nc;if(started)toast(nc==='rain'?'Começou a chover':nc==='fog'?'A neblina está fechando':'O tempo abriu')}}
  const u=Math.min(1,dt*.35);wx.rw+=((wx.cur==='rain'?1:0)-wx.rw)*u;wx.fw+=((wx.cur==='fog'?1:0)-wx.fw)*u;
  const gy=Math.max(wx.rw*.55,wx.fw*.7);
  tmpC.copy(envC.night).lerp(envC.day,k).lerp(envC.dusk,dusk*.55);tmpC.lerp(tmpGray.copy(envC.gray).multiplyScalar(.25+.75*k),gy);
  scene.background.copy(tmpC);scene.fog.color.copy(tmpC);scene.fog.near=120-70*wx.rw-100*wx.fw;scene.fog.far=430-170*wx.rw-280*wx.fw;
  sun.intensity=.95*k*(1-.5*gy);sun.color.setHex(0xfff0cf).lerp(envC.dusk,dusk*.6);hemi.intensity=.3+.5*k*(1-.3*gy);
  sunV.set(Math.cos(a)*90,Math.max(.4,Math.sin(a)+.3)*120,45);
  {const nl=clamp((.62-k)/.45,0,1)*.95;if(Math.abs(nl-litK)>.02){litK=nl;for(const m of litMats)m.emissiveIntensity=nl}}headl.intensity=(1-k)*2.4;headl.position.set(player.x,player.y+3.2,player.z);headl.target.position.set(player.x+Math.sin(player.yaw)*40,player.y+1,player.z+Math.cos(player.yaw)*40);
  rain.visible=wx.rw>.03;rain.material.opacity=.55*wx.rw;
  if(rain.visible){rain.position.copy(cam.position);for(let i=0;i<RN;i++){let y=rainP[i*6+1]-dt*40;if(y<0)y+=40;rainP[i*6+1]=y;rainP[i*6+4]=y-1.8}rainG.attributes.position.needsUpdate=true}
  if(ac&&!rainS&&wx.rw>.05){const n=ac.sampleRate*2|0,b=ac.createBuffer(1,n,ac.sampleRate),d=b.getChannelData(0);for(let i=0;i<n;i++)d[i]=Math.random()*2-1;const s=ac.createBufferSource(),f=ac.createBiquadFilter(),g=ac.createGain();s.buffer=b;s.loop=true;f.type='bandpass';f.frequency.value=3000;g.gain.value=0;s.connect(f);f.connect(g);g.connect(ac.destination);s.start();rainS=g}
  if(rainS)rainS.gain.setTargetAtTime(running?.05*wx.rw:0,ac.currentTime,.3);
}
/* predios que desabam em partes */
function shed(b,n){for(let i=0;i<n;i++){const m=new THREE.Mesh(dg,new THREE.MeshLambertMaterial({color:b.color})),s=.5+Math.random()*1.2;m.scale.set(s,s*.7,s);m.position.set(b.x+(Math.random()-.5)*b.w,b.y+b.h*(.6+Math.random()*.4),b.z+(Math.random()-.5)*b.d);scene.add(m);debris.push({m,s,t:9,v:new THREE.Vector3((Math.random()-.5)*5,1+Math.random()*3,(Math.random()-.5)*5)})}}
function crumble(b){
  const f=b.hp/(b.hp0||b.hp);
  if(f<.6&&!b.s1){b.s1=1;b.m.rotation.z=(Math.random()<.5?1:-1)*.035;b.m.rotation.x=(Math.random()-.5)*.05;shed(b,5);for(let i=0;i<5;i++)puff(v3.set(b.x,b.y+b.h*.7,b.z),0xb9b0a0,3,5,2,2)}
  if(f<.3&&!b.s2){b.s2=1;b.m.rotation.z*=2.2;b.m.rotation.x*=2;b.m.position.y-=b.h*.07;shed(b,9);for(let i=0;i<8;i++)puff(v3.set(b.x,b.y+b.h*.5,b.z),0x8a8478,3.5,6,2.6,3)}
}
function extras(dt){
  const now=performance.now()/1000;envUpdate(dt);crateUpdate(dt,now);engineUpdate(dt);fallUpdate(dt);
  if(wave>save.wave){save.wave=wave;persist();refreshProg()}
}

