// Efeito de chuva estilizada
const rain = document.getElementById("rain");
for (let i = 0; i < 42; i++) {
  const drop = document.createElement("span");
  drop.className = "drop";
  drop.style.left = Math.random() * 100 + "%";
  drop.style.height = (20 + Math.random() * 55) + "px";
  drop.style.animationDuration = (1.2 + Math.random() * 2.4) + "s";
  drop.style.animationDelay = Math.random() * 2 + "s";
  rain.appendChild(drop);
}

// Tenta abrir o Free Fire instalado normalmente.
function launchFreefire() {
  const status = document.getElementById("gameStatus");
  status.textContent = "ABRINDO...";
  window.location.href =
    "intent://#Intent;scheme=freefire;package=com.dts.freefireth;end";
  setTimeout(() => { status.textContent = "AGUARDANDO"; }, 2500);
}
