document.addEventListener('DOMContentLoaded', function() {
  console.log('Project SamuraiFight is ready!');
});