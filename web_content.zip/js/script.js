document.addEventListener('DOMContentLoaded', function() {
  console.log('Project Mezaxtin is ready!');
});