document.addEventListener('DOMContentLoaded', function() {
  console.log('Project alam is ready!');
});