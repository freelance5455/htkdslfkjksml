document.addEventListener('DOMContentLoaded', function() {
  console.log('Project Test Booking is ready!');
});