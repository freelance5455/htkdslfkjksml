document.addEventListener('DOMContentLoaded', function() {
  console.log('Project MegaCat is ready!');
});