document.addEventListener('DOMContentLoaded', function() {
  console.log('Project mazaxtin is ready!');
});