document.addEventListener('DOMContentLoaded', function() {
  console.log('Project booking test is ready!');
});