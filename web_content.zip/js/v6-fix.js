(function(){
  'use strict';
  let activeSubject = 'Autres';
  let activeSubjectId = '';

  function toast(msg){
    if(typeof window.showToast === 'function') return window.showToast(msg);
    const el=document.createElement('div'); el.textContent=msg;
    Object.assign(el.style,{position:'fixed',bottom:'90px',left:'50%',transform:'translateX(-50%)',zIndex:9999,background:'#111827',color:'#fff',padding:'12px 16px',borderRadius:'12px'});
    document.body.appendChild(el); setTimeout(()=>el.remove(),2200);
  }
  function openModal(){
    const m=document.getElementById('subjectModal');
    if(m){m.classList.add('open');m.classList.remove('hidden');}
  }
  function closeModal(){
    const m=document.getElementById('subjectModal');
    if(m){m.classList.remove('open');m.classList.add('hidden');}
  }
  async function refreshFolder(){
    const box=document.getElementById('modalDocuments'); if(!box) return;
    try{
      const docs=window.MSLDocumentsV3 && window.MSLDocumentsV3.getAll ? await window.MSLDocumentsV3.getAll() : [];
      const list=docs.filter(d=>(d.subject||'Autres')===activeSubject);
      if(!list.length){box.innerHTML='<div class="empty-state">Aucun document dans cette matière.</div>';return;}
      box.innerHTML=list.map(d=>`<div class="doc-row"><div><b>${escapeHtml(d.name||'Document')}</b><small>${d.type==='application/pdf'?'📄 PDF':'🖼️ Image'} · ${escapeHtml(activeSubject)}</small></div><button class="icon-btn" data-folder-open="${Number(d.id)}">Ouvrir</button></div>`).join('');
      box.querySelectorAll('[data-folder-open]').forEach(b=>b.addEventListener('click',()=>window.MSLDocumentsV3?.openDocument?.(Number(b.dataset.folderOpen))));
    }catch(e){console.error(e);box.innerHTML='<div class="empty-state">Impossible de charger les documents.</div>';}
  }
  function escapeHtml(s){return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));}

  window.openSubjectFolder=function(id,name){
    activeSubjectId=id||''; activeSubject=name||id||'Autres';
    const title=document.getElementById('modalSubjectName'); if(title) title.textContent=activeSubject;
    ['subjectCameraInput','subjectGalleryInput','subjectPdfInput'].forEach(x=>{const el=document.getElementById(x);if(el)el.value='';});
    openModal(); refreshFolder();
  };

  async function handleFiles(input){
    const files=input.files;
    if(!files || !files.length) return;
    if(!window.MSLDocumentsV3?.importFiles){toast('Bibliothèque de fichiers indisponible');return;}
    try{
      await window.MSLDocumentsV3.importFiles(files,activeSubject);
      toast(files.length>1 ? files.length+' fichiers ajoutés à '+activeSubject : 'Fichier ajouté à '+activeSubject);
      input.value='';
      await refreshFolder();
      if(window.refreshDocuments) await window.refreshDocuments();
    }catch(e){console.error(e);toast('Erreur pendant l’import du fichier');}
  }

  document.addEventListener('DOMContentLoaded',function(){
    document.getElementById('closeSubjectModal')?.addEventListener('click',closeModal);
    document.getElementById('subjectModal')?.addEventListener('click',e=>{if(e.target.id==='subjectModal')closeModal();});
    ['subjectCameraInput','subjectGalleryInput','subjectPdfInput'].forEach(id=>{
      const input=document.getElementById(id); if(input) input.addEventListener('change',()=>handleFiles(input));
    });
  });
})();
