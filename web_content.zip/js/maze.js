/**
 * Snake Escape — Advanced SVG Maze & Entity Renderer
 * Dynamically builds 3D stone walls, mossy floor, bridges, traps, switches,
 * portals, gates, movable blocks, keys, collectibles, exits, and animated hints.
 */
(function() {
  'use strict';

  const PORTAL_COLORS = {
    green: { ring: '#39ff14', glow: 'rgba(57, 255, 20, 0.8)', arrow: '#baff66', core: '#144d06' },
    blue: { ring: '#00f3ff', glow: 'rgba(0, 243, 255, 0.8)', arrow: '#a8f8ff', core: '#062647' },
    orange: { ring: '#ff9900', glow: 'rgba(255, 153, 0, 0.8)', arrow: '#ffd280', core: '#451c04' },
    purple: { ring: '#cc33ff', glow: 'rgba(204, 51, 255, 0.8)', arrow: '#f0b3ff', core: '#2c0733' }
  };

  const KEY_COLORS = {
    green: '#39ff14',
    blue: '#00f3ff',
    gold: '#ffd700',
    purple: '#cc33ff'
  };

  class MazeRenderer {
    constructor(svgElement) {
      this.svg = svgElement;
      this.level = null;
      this.cellSize = 40;
      this.hintData = null;
    }

    initLevel(level) {
      this.level = level;
      this.hintData = null;
      this.updateDimensions();
    }

    updateDimensions() {
      if (!this.level || !this.svg) return;
      const { cols, rows } = this.level.grid;
      const container = this.svg.parentElement;
      const rect = container ? container.getBoundingClientRect() : { width: 360, height: 360 };
      const size = Math.min(rect.width || 360, rect.height || 360);
      this.cellSize = size / Math.max(cols, rows);
      this.svg.setAttribute('viewBox', `0 0 ${cols * this.cellSize} ${rows * this.cellSize}`);
    }

    setHintPath(hint) {
      this.hintData = hint;
    }

    clearHintPath() {
      this.hintData = null;
    }

    /**
     * Converts touch or click client coordinates to logical grid {x, y}
     */
    clientToGrid(clientX, clientY) {
      if (!this.svg || !this.level) return null;
      const pt = this.svg.createSVGPoint();
      pt.x = clientX;
      pt.y = clientY;
      const svgP = pt.matrixTransform(this.svg.getScreenCTM().inverse());
      const gx = Math.floor(svgP.x / this.cellSize);
      const gy = Math.floor(svgP.y / this.cellSize);

      if (gx >= 0 && gx < this.level.grid.cols && gy >= 0 && gy < this.level.grid.rows) {
        return { x: gx, y: gy };
      }
      return null;
    }

    render(snakes = []) {
      if (!this.svg || !this.level) return;
      this.svg.innerHTML = '';
      const { cols, rows } = this.level.grid;
      const cs = this.cellSize;

      // --- 1. SVG Definitions & Filters ---
      const defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
      defs.innerHTML = `
        <filter id="wallShadow" x="-10%" y="-10%" width="120%" height="130%">
          <feDropShadow dx="0" dy="4" stdDeviation="3" flood-color="#020804" flood-opacity="0.8"/>
        </filter>
        <filter id="glowFilter" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="3" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>
        <radialGradient id="exitGlowGrad" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stop-color="#ffffff" stop-opacity="0.9"/>
          <stop offset="50%" stop-color="#00f3ff" stop-opacity="0.5"/>
          <stop offset="100%" stop-color="#00f3ff" stop-opacity="0"/>
        </radialGradient>
      `;
      this.svg.appendChild(defs);

      // --- 2. Ground / Floor Grid Layer ---
      const floorGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
      floorGroup.setAttribute('class', 'board-floor');

      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          const tile = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
          tile.setAttribute('x', c * cs);
          tile.setAttribute('y', r * cs);
          tile.setAttribute('width', cs);
          tile.setAttribute('height', cs);
          tile.setAttribute('fill', (r + c) % 2 === 0 ? '#102519' : '#0c1e13');
          tile.setAttribute('stroke', '#163623');
          tile.setAttribute('stroke-width', '1');
          floorGroup.appendChild(tile);

          // Subtle moss speckles on select tiles
          if ((c * 7 + r * 13) % 11 === 0) {
            const mossDot = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
            mossDot.setAttribute('cx', c * cs + cs * 0.7);
            mossDot.setAttribute('cy', r * cs + cs * 0.3);
            mossDot.setAttribute('r', cs * 0.08);
            mossDot.setAttribute('fill', '#2d6323');
            mossDot.setAttribute('opacity', '0.6');
            floorGroup.appendChild(mossDot);
          }
        }
      }
      this.svg.appendChild(floorGroup);

      // --- 3. Bridges Layer (Inactive chasm vs active wooden bridge) ---
      if (this.level.bridges && this.level.bridges.length > 0) {
        const bridgesGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        bridgesGroup.setAttribute('class', 'board-bridges');

        this.level.bridges.forEach(br => {
          const bx = br.x * cs;
          const by = br.y * cs;
          const brG = document.createElementNS('http://www.w3.org/2000/svg', 'g');

          if (!br.active) {
            // Inactive: Dark bottomless pit
            const pit = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
            pit.setAttribute('x', bx + 2);
            pit.setAttribute('y', by + 2);
            pit.setAttribute('width', cs - 4);
            pit.setAttribute('height', cs - 4);
            pit.setAttribute('fill', '#040905');
            pit.setAttribute('stroke', '#132117');
            pit.setAttribute('stroke-width', '2');
            pit.setAttribute('rx', 3);
            brG.appendChild(pit);

            // Pit depth lines
            const line = document.createElementNS('http://www.w3.org/2000/svg', 'path');
            line.setAttribute('d', `M ${bx + 6} ${by + 6} L ${bx + cs - 6} ${by + cs - 6} M ${bx + cs - 6} ${by + 6} L ${bx + 6} ${by + cs - 6}`);
            line.setAttribute('stroke', '#0c1810');
            line.setAttribute('stroke-width', '2');
            brG.appendChild(line);
          } else {
            // Active: Sturdy wooden plank bridge
            const wood = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
            wood.setAttribute('x', bx + 2);
            wood.setAttribute('y', by + 2);
            wood.setAttribute('width', cs - 4);
            wood.setAttribute('height', cs - 4);
            wood.setAttribute('fill', '#6d4825');
            wood.setAttribute('stroke', '#412711');
            wood.setAttribute('stroke-width', '2');
            wood.setAttribute('rx', 4);
            brG.appendChild(wood);

            // Planks
            for (let p = 1; p < 4; p++) {
              const plank = document.createElementNS('http://www.w3.org/2000/svg', 'line');
              plank.setAttribute('x1', bx + 3);
              plank.setAttribute('y1', by + (cs * p / 4));
              plank.setAttribute('x2', bx + cs - 3);
              plank.setAttribute('y2', by + (cs * p / 4));
              plank.setAttribute('stroke', '#351f0b');
              plank.setAttribute('stroke-width', '2');
              brG.appendChild(plank);
            }
          }
          bridgesGroup.appendChild(brG);
        });
        this.svg.appendChild(bridgesGroup);
      }

      // --- 4. Traps Layer (Spikes & Poison Vents) ---
      if (this.level.traps && this.level.traps.length > 0) {
        const trapsGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        trapsGroup.setAttribute('class', 'board-traps');

        this.level.traps.forEach(trap => {
          const tx = trap.x * cs;
          const ty = trap.y * cs;
          const trapG = document.createElementNS('http://www.w3.org/2000/svg', 'g');

          // Metal base plate
          const plate = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
          plate.setAttribute('x', tx + 4);
          plate.setAttribute('y', ty + 4);
          plate.setAttribute('width', cs - 8);
          plate.setAttribute('height', cs - 8);
          plate.setAttribute('fill', '#26292b');
          plate.setAttribute('stroke', '#42494d');
          plate.setAttribute('stroke-width', '1.5');
          plate.setAttribute('rx', 3);
          trapG.appendChild(plate);

          if (trap.type === 'spikes' && trap.state === 'active') {
            // Deadly raised metal spikes
            const spikeOffsets = [
              [0.28, 0.28], [0.72, 0.28],
              [0.5, 0.5],
              [0.28, 0.72], [0.72, 0.72]
            ];
            spikeOffsets.forEach(([ox, oy]) => {
              const spike = document.createElementNS('http://www.w3.org/2000/svg', 'polygon');
              const sx = tx + cs * ox;
              const sy = ty + cs * oy;
              spike.setAttribute('points', `${sx},${sy - cs * 0.18} ${sx - cs * 0.09},${sy + cs * 0.08} ${sx + cs * 0.09},${sy + cs * 0.08}`);
              spike.setAttribute('fill', '#d32f2f');
              spike.setAttribute('stroke', '#ffffff');
              spike.setAttribute('stroke-width', '1');
              trapG.appendChild(spike);
            });
          } else if (trap.type === 'poison') {
            // Bubbling green poison vent
            const gas = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
            gas.setAttribute('cx', tx + cs / 2);
            gas.setAttribute('cy', ty + cs / 2);
            gas.setAttribute('r', cs * 0.3);
            gas.setAttribute('fill', 'rgba(124, 252, 0, 0.45)');
            gas.setAttribute('stroke', '#7cfc00');
            gas.setAttribute('stroke-width', '2');
            gas.setAttribute('stroke-dasharray', '3 2');
            trapG.appendChild(gas);
          }

          trapsGroup.appendChild(trapG);
        });
        this.svg.appendChild(trapsGroup);
      }

      // --- 5. Pressure Switches Layer ---
      if (this.level.switches && this.level.switches.length > 0) {
        const switchGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        switchGroup.setAttribute('class', 'board-switches');

        this.level.switches.forEach(sw => {
          const sx = sw.x * cs + cs / 2;
          const sy = sw.y * cs + cs / 2;
          const swG = document.createElementNS('http://www.w3.org/2000/svg', 'g');

          // Stone outer pedestal
          const outer = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
          outer.setAttribute('cx', sx);
          outer.setAttribute('cy', sy);
          outer.setAttribute('r', cs * 0.38);
          outer.setAttribute('fill', '#26342a');
          outer.setAttribute('stroke', '#16231a');
          outer.setAttribute('stroke-width', '2');
          swG.appendChild(outer);

          // Inner glowing button
          const inner = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
          inner.setAttribute('cx', sx);
          inner.setAttribute('cy', sy);
          inner.setAttribute('r', cs * (sw.pressed ? 0.22 : 0.28));
          inner.setAttribute('fill', sw.pressed ? '#00f3ff' : '#ffaa00');
          inner.setAttribute('stroke', sw.pressed ? '#ffffff' : '#b37400');
          inner.setAttribute('stroke-width', '2');
          if (sw.pressed) {
            inner.setAttribute('filter', 'url(#glowFilter)');
          }
          swG.appendChild(inner);

          switchGroup.appendChild(swG);
        });
        this.svg.appendChild(switchGroup);
      }

      // --- 6. Teleport Portals Layer (Paired) ---
      if (this.level.portals && this.level.portals.length > 0) {
        const portalGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        portalGroup.setAttribute('class', 'board-teleport-portals');

        this.level.portals.forEach(p => {
          const px = p.x * cs + cs / 2;
          const py = p.y * cs + cs / 2;
          const pColor = PORTAL_COLORS[p.color] || PORTAL_COLORS.green;
          const pG = document.createElementNS('http://www.w3.org/2000/svg', 'g');
          pG.setAttribute('class', 'portal-pulse-anim');

          // Outer aura
          const aura = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
          aura.setAttribute('cx', px);
          aura.setAttribute('cy', py);
          aura.setAttribute('r', cs * 0.44);
          aura.setAttribute('fill', pColor.glow);
          aura.setAttribute('opacity', '0.45');
          pG.appendChild(aura);

          // Ethereal center
          const core = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
          core.setAttribute('cx', px);
          core.setAttribute('cy', py);
          core.setAttribute('r', cs * 0.36);
          core.setAttribute('fill', pColor.core);
          core.setAttribute('stroke', pColor.ring);
          core.setAttribute('stroke-width', '3');
          core.setAttribute('stroke-dasharray', '5 3');
          pG.appendChild(core);

          // Spiral vortex icon
          const vortex = document.createElementNS('http://www.w3.org/2000/svg', 'path');
          vortex.setAttribute('d', `M ${px} ${py - cs * 0.22} A ${cs * 0.22} ${cs * 0.22} 0 0 1 ${px + cs * 0.22} ${py} A ${cs * 0.16} ${cs * 0.16} 0 0 1 ${px} ${py + cs * 0.16} A ${cs * 0.1} ${cs * 0.1} 0 0 1 ${px - cs * 0.1} ${py}`);
          vortex.setAttribute('fill', 'none');
          vortex.setAttribute('stroke', pColor.arrow);
          vortex.setAttribute('stroke-width', '2.5');
          vortex.setAttribute('stroke-linecap', 'round');
          pG.appendChild(vortex);

          portalGroup.appendChild(pG);
        });
        this.svg.appendChild(portalGroup);
      }

      // --- 7. Exit Portals Layer ---
      const exitsGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
      exitsGroup.setAttribute('class', 'board-exits');

      snakes.forEach(snake => {
        const exit = snake.exit;
        if (!exit) return;
        const colorKey = snake.color || 'green';
        const pColor = PORTAL_COLORS[colorKey] || PORTAL_COLORS.green;
        const cx = exit.x * cs + cs / 2;
        const cy = exit.y * cs + cs / 2;

        const exitG = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        exitG.setAttribute('class', 'portal-pulse-anim');

        // Outer glow
        const glowCircle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        glowCircle.setAttribute('cx', cx);
        glowCircle.setAttribute('cy', cy);
        glowCircle.setAttribute('r', cs * 0.44);
        glowCircle.setAttribute('fill', pColor.glow);
        glowCircle.setAttribute('opacity', '0.4');
        exitG.appendChild(glowCircle);

        // Ring
        const ring = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        ring.setAttribute('cx', cx);
        ring.setAttribute('cy', cy);
        ring.setAttribute('r', cs * 0.38);
        ring.setAttribute('fill', '#05140b');
        ring.setAttribute('stroke', pColor.ring);
        ring.setAttribute('stroke-width', '3');
        ring.setAttribute('stroke-dasharray', '5 3');
        exitG.appendChild(ring);

        // Exit Chevron Arrow Icon
        const arrow = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        arrow.setAttribute('d', `M ${cx - cs * 0.12} ${cy - cs * 0.16} L ${cx + cs * 0.12} ${cy} L ${cx - cs * 0.12} ${cy + cs * 0.16}`);
        arrow.setAttribute('fill', 'none');
        arrow.setAttribute('stroke', pColor.arrow);
        arrow.setAttribute('stroke-width', '3');
        arrow.setAttribute('stroke-linecap', 'round');
        arrow.setAttribute('stroke-linejoin', 'round');
        arrow.setAttribute('class', 'portal-arrow-anim');
        exitG.appendChild(arrow);

        exitsGroup.appendChild(exitG);
      });
      this.svg.appendChild(exitsGroup);

      // --- 8. Locked Gates Layer ---
      if (this.level.gates && this.level.gates.length > 0) {
        const gatesGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        gatesGroup.setAttribute('class', 'board-gates');

        this.level.gates.forEach(gate => {
          if (gate.isOpen) return; // Open gates become empty walkable paths

          const gx = gate.x * cs;
          const gy = gate.y * cs;
          const gColor = KEY_COLORS[gate.color || 'gold'] || KEY_COLORS.gold;
          const gateG = document.createElementNS('http://www.w3.org/2000/svg', 'g');

          // Gate background
          const bg = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
          bg.setAttribute('x', gx + 2);
          bg.setAttribute('y', gy + 2);
          bg.setAttribute('width', cs - 4);
          bg.setAttribute('height', cs - 4);
          bg.setAttribute('fill', '#1a221d');
          bg.setAttribute('stroke', gColor);
          bg.setAttribute('stroke-width', '2');
          bg.setAttribute('rx', 4);
          gateG.appendChild(bg);

          // Portcullis Bars
          for (let b = 1; b <= 3; b++) {
            const bar = document.createElementNS('http://www.w3.org/2000/svg', 'line');
            bar.setAttribute('x1', gx + (cs * b / 4));
            bar.setAttribute('y1', gy + 4);
            bar.setAttribute('x2', gx + (cs * b / 4));
            bar.setAttribute('y2', gy + cs - 4);
            bar.setAttribute('stroke', gColor);
            bar.setAttribute('stroke-width', '3');
            bar.setAttribute('stroke-linecap', 'round');
            gateG.appendChild(bar);
          }

          // Lock Icon in center
          const lock = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
          lock.setAttribute('cx', gx + cs / 2);
          lock.setAttribute('cy', gy + cs / 2);
          lock.setAttribute('r', cs * 0.15);
          lock.setAttribute('fill', gColor);
          gateG.appendChild(lock);

          gatesGroup.appendChild(gateG);
        });
        this.svg.appendChild(gatesGroup);
      }

      // --- 9. Movable Blocks Layer (Sokoban) ---
      if (this.level.blocks && this.level.blocks.length > 0) {
        const blocksGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        blocksGroup.setAttribute('class', 'board-blocks');
        blocksGroup.setAttribute('filter', 'url(#wallShadow)');

        this.level.blocks.forEach(block => {
          const bx = block.x * cs;
          const by = block.y * cs;
          const blkG = document.createElementNS('http://www.w3.org/2000/svg', 'g');

          // Carved stone block
          const base = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
          base.setAttribute('x', bx + 3);
          base.setAttribute('y', by + 3);
          base.setAttribute('width', cs - 6);
          base.setAttribute('height', cs - 6);
          base.setAttribute('rx', 5);
          base.setAttribute('fill', '#4f5e53');
          base.setAttribute('stroke', '#242f27');
          base.setAttribute('stroke-width', '2');
          blkG.appendChild(base);

          // Ancient engraved glyph
          const glyph = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
          glyph.setAttribute('x', bx + cs * 0.28);
          glyph.setAttribute('y', by + cs * 0.28);
          glyph.setAttribute('width', cs * 0.44);
          glyph.setAttribute('height', cs * 0.44);
          glyph.setAttribute('fill', 'none');
          glyph.setAttribute('stroke', '#78937e');
          glyph.setAttribute('stroke-width', '2');
          blkG.appendChild(glyph);

          blocksGroup.appendChild(blkG);
        });
        this.svg.appendChild(blocksGroup);
      }

      // --- 10. Collectible Keys Layer ---
      if (this.level.keys && this.level.keys.length > 0) {
        const keysGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        keysGroup.setAttribute('class', 'board-keys');

        this.level.keys.forEach(key => {
          if (key.collected) return;
          const kx = key.x * cs + cs / 2;
          const ky = key.y * cs + cs / 2;
          const kColor = KEY_COLORS[key.color || 'gold'] || KEY_COLORS.gold;
          const keyG = document.createElementNS('http://www.w3.org/2000/svg', 'g');
          keyG.setAttribute('class', 'key-float-anim');

          // Key ring
          const ring = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
          ring.setAttribute('cx', kx - cs * 0.12);
          ring.setAttribute('cy', ky);
          ring.setAttribute('r', cs * 0.16);
          ring.setAttribute('fill', 'none');
          ring.setAttribute('stroke', kColor);
          ring.setAttribute('stroke-width', '3');
          keyG.appendChild(ring);

          // Key shaft
          const shaft = document.createElementNS('http://www.w3.org/2000/svg', 'line');
          shaft.setAttribute('x1', kx);
          shaft.setAttribute('y1', ky);
          shaft.setAttribute('x2', kx + cs * 0.28);
          shaft.setAttribute('y2', ky);
          shaft.setAttribute('stroke', kColor);
          shaft.setAttribute('stroke-width', '3');
          shaft.setAttribute('stroke-linecap', 'round');
          keyG.appendChild(shaft);

          // Key teeth
          const tooth1 = document.createElementNS('http://www.w3.org/2000/svg', 'line');
          tooth1.setAttribute('x1', kx + cs * 0.2);
          tooth1.setAttribute('y1', ky);
          tooth1.setAttribute('x2', kx + cs * 0.2);
          tooth1.setAttribute('y2', ky + cs * 0.12);
          tooth1.setAttribute('stroke', kColor);
          tooth1.setAttribute('stroke-width', '2.5');
          keyG.appendChild(tooth1);

          keysGroup.appendChild(keyG);
        });
        this.svg.appendChild(keysGroup);
      }

      // --- 11. Collectibles Layer (Stars, Gems, Coins) ---
      if (this.level.collectibles && this.level.collectibles.length > 0) {
        const colGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        colGroup.setAttribute('class', 'board-collectibles');

        this.level.collectibles.forEach(col => {
          if (col.collected) return;
          const cx = col.x * cs + cs / 2;
          const cy = col.y * cs + cs / 2;
          const itemG = document.createElementNS('http://www.w3.org/2000/svg', 'g');
          itemG.setAttribute('class', 'collectible-anim');

          if (col.type === 'star') {
            const star = document.createElementNS('http://www.w3.org/2000/svg', 'path');
            star.setAttribute('d', `M ${cx} ${cy - cs * 0.26} L ${cx + cs * 0.08} ${cy - cs * 0.08} L ${cx + cs * 0.26} ${cy - cs * 0.08} L ${cx + cs * 0.12} ${cy + cs * 0.04} L ${cx + cs * 0.17} ${cy + cs * 0.22} L ${cx} ${cy + cs * 0.12} L ${cx - cs * 0.17} ${cy + cs * 0.22} L ${cx - cs * 0.12} ${cy + cs * 0.04} L ${cx - cs * 0.26} ${cy - cs * 0.08} L ${cx - cs * 0.08} ${cy - cs * 0.08} Z`);
            star.setAttribute('fill', '#ffd700');
            star.setAttribute('stroke', '#b8860b');
            star.setAttribute('stroke-width', '1.5');
            itemG.appendChild(star);
          } else if (col.type === 'gem') {
            const gem = document.createElementNS('http://www.w3.org/2000/svg', 'polygon');
            gem.setAttribute('points', `${cx},${cy - cs * 0.25} ${cx + cs * 0.22},${cy - cs * 0.1} ${cx + cs * 0.16},${cy + cs * 0.22} ${cx - cs * 0.16},${cy + cs * 0.22} ${cx - cs * 0.22},${cy - cs * 0.1}`);
            gem.setAttribute('fill', '#00f3ff');
            gem.setAttribute('stroke', '#ffffff');
            gem.setAttribute('stroke-width', '1.5');
            itemG.appendChild(gem);
          } else {
            // Coin
            const coin = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
            coin.setAttribute('cx', cx);
            coin.setAttribute('cy', cy);
            coin.setAttribute('r', cs * 0.22);
            coin.setAttribute('fill', '#ffbb00');
            coin.setAttribute('stroke', '#8a6200');
            coin.setAttribute('stroke-width', '2');
            itemG.appendChild(coin);
          }

          colGroup.appendChild(itemG);
        });
        this.svg.appendChild(colGroup);
      }

      // --- 12. 3D Stone Maze Walls Layer ---
      const wallsGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
      wallsGroup.setAttribute('class', 'board-walls');
      wallsGroup.setAttribute('filter', 'url(#wallShadow)');

      (this.level.walls || []).forEach(w => {
        const wx = w.x * cs;
        const wy = w.y * cs;
        const wallBlock = document.createElementNS('http://www.w3.org/2000/svg', 'g');

        // Wall base stone
        const base = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
        base.setAttribute('x', wx + 2);
        base.setAttribute('y', wy + 2);
        base.setAttribute('width', cs - 4);
        base.setAttribute('height', cs - 4);
        base.setAttribute('rx', 4);
        base.setAttribute('fill', '#38493d');
        base.setAttribute('stroke', '#222f27');
        base.setAttribute('stroke-width', '2');
        wallBlock.appendChild(base);

        // 3D Bevel Highlight (Top-left)
        const hl = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        hl.setAttribute('d', `M ${wx + 3} ${wy + cs - 4} L ${wx + 3} ${wy + 3} L ${wx + cs - 4} ${wy + 3}`);
        hl.setAttribute('fill', 'none');
        hl.setAttribute('stroke', '#54705c');
        hl.setAttribute('stroke-width', '2');
        wallBlock.appendChild(hl);

        // Moss patch on stone top
        const moss = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        moss.setAttribute('d', `M ${wx + 6} ${wy + 4} Q ${wx + cs * 0.5} ${wy + 8} ${wx + cs - 6} ${wy + 4} Z`);
        moss.setAttribute('fill', '#4ca32d');
        moss.setAttribute('opacity', '0.75');
        wallBlock.appendChild(moss);

        wallsGroup.appendChild(wallBlock);
      });
      this.svg.appendChild(wallsGroup);

      // --- 13. Dynamic Hint Breadcrumbs Layer ---
      if (this.hintData && this.hintData.path && this.hintData.path.length > 1) {
        const hintGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        hintGroup.setAttribute('class', 'board-hint-trail');

        let d = `M ${this.hintData.path[0].x * cs + cs / 2} ${this.hintData.path[0].y * cs + cs / 2}`;
        for (let i = 1; i < this.hintData.path.length; i++) {
          d += ` L ${this.hintData.path[i].x * cs + cs / 2} ${this.hintData.path[i].y * cs + cs / 2}`;
        }

        const hintLine = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        hintLine.setAttribute('d', d);
        hintLine.setAttribute('fill', 'none');
        hintLine.setAttribute('stroke', '#00f3ff');
        hintLine.setAttribute('stroke-width', '4.5');
        hintLine.setAttribute('stroke-linecap', 'round');
        hintLine.setAttribute('stroke-linejoin', 'round');
        hintLine.setAttribute('stroke-dasharray', '6 4');
        hintLine.setAttribute('class', 'hint-path-line');
        hintGroup.appendChild(hintLine);

        // Next cell pulse indicator
        const next = this.hintData.nextStep;
        if (next) {
          const pulse = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
          pulse.setAttribute('cx', next.x * cs + cs / 2);
          pulse.setAttribute('cy', next.y * cs + cs / 2);
          pulse.setAttribute('r', cs * 0.35);
          pulse.setAttribute('fill', 'none');
          pulse.setAttribute('stroke', '#00f3ff');
          pulse.setAttribute('stroke-width', '3');
          pulse.setAttribute('class', 'hint-pulse-anim');
          hintGroup.appendChild(pulse);
        }

        this.svg.appendChild(hintGroup);
      }

      // --- 14. Snakes Layer ---
      snakes.forEach(snake => {
        snake.render(this.svg, cs);
      });
    }
  }

  window.SnakeEscape = window.SnakeEscape || {};
  window.SnakeEscape.MazeRenderer = MazeRenderer;
})();
