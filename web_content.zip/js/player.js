// Original low-poly player representation: a cylinder body + sphere head.
// Deliberately simple placeholder geometry for Stage 1 - swap in a real
// original character model/skin system in a later stage.
const PlayerMesh = {
  create(color = 0xff6b4a) {
    const group = new THREE.Group();

    const body = new THREE.Mesh(
      new THREE.CylinderGeometry(0.4, 0.4, 1.4, 12),
      new THREE.MeshStandardMaterial({ color })
    );
    body.position.y = 0.9;

    const head = new THREE.Mesh(
      new THREE.SphereGeometry(0.35, 12, 12),
      new THREE.MeshStandardMaterial({ color: 0xffd9a0 })
    );
    head.position.y = 1.75;

    group.add(body, head);
    return group;
  },
};
