/**
 * Snake Escape — Advanced Player Controller, Mechanics Engine & Full State History
 * Handles step/glide movement, Sokoban block pushes, keys, gates, switches, portals,
 * bridges, traps, collectibles, and complete undo/reset snapshots.
 */
(function() {
  'use strict';

  class PlayerController {
    constructor() {
      this.activeSnakeId = null;
      this.historyStack = [];
      this.movesCount = 0;
      this.score = 0;
    }

    init(snakes) {
      this.historyStack = [];
      this.movesCount = 0;
      this.score = 0;

      // Select first non-escaped snake
      const firstAvailable = snakes.find(s => !s.escaped);
      this.activeSnakeId = firstAvailable ? firstAvailable.id : null;
      this._updateSelectionState(snakes);
    }

    getActiveSnake(snakes) {
      if (!this.activeSnakeId) {
        const first = snakes.find(s => !s.escaped);
        if (first) this.activeSnakeId = first.id;
      }
      return snakes.find(s => s.id === this.activeSnakeId) || null;
    }

    selectSnake(snakeId, snakes) {
      const target = snakes.find(s => s.id === snakeId);
      if (target && !target.escaped) {
        this.activeSnakeId = snakeId;
        this._updateSelectionState(snakes);
        return true;
      }
      return false;
    }

    _updateSelectionState(snakes) {
      snakes.forEach(s => {
        s.isSelected = (s.id === this.activeSnakeId && !s.escaped);
      });
    }

    /**
     * Captures a complete deep-cloned state snapshot for Undo/Reset
     */
    _createSnapshot(snakes, state) {
      return {
        activeSnakeId: this.activeSnakeId,
        movesCount: this.movesCount,
        score: this.score,
        snakeStates: snakes.map(s => ({
          id: s.id,
          segments: JSON.parse(JSON.stringify(s.segments)),
          direction: s.direction,
          headRotation: s.headRotation,
          escaped: s.escaped,
          isDead: s.isDead
        })),
        keys: JSON.parse(JSON.stringify(state.keys || [])),
        gates: JSON.parse(JSON.stringify(state.gates || [])),
        switches: JSON.parse(JSON.stringify(state.switches || [])),
        blocks: JSON.parse(JSON.stringify(state.blocks || [])),
        bridges: JSON.parse(JSON.stringify(state.bridges || [])),
        traps: JSON.parse(JSON.stringify(state.traps || [])),
        collectibles: JSON.parse(JSON.stringify(state.collectibles || []))
      };
    }

    /**
     * Executes player movement in given direction ('UP', 'DOWN', 'LEFT', 'RIGHT')
     */
    tryMove(direction, snakes, levelState, collision, audio, anim, callbacks = {}) {
      const activeSnake = this.getActiveSnake(snakes);
      if (!activeSnake || activeSnake.isMoving || activeSnake.escaped || activeSnake.isDead) {
        return false;
      }

      let dx = 0, dy = 0;
      switch (direction) {
        case 'UP': dy = -1; break;
        case 'DOWN': dy = 1; break;
        case 'LEFT': dx = -1; break;
        case 'RIGHT': dx = 1; break;
        default: return false;
      }

      const isGlide = levelState.movementMode === 'glide';

      if (isGlide) {
        return this._executeGlideMove(direction, dx, dy, activeSnake, snakes, levelState, collision, audio, anim, callbacks);
      } else {
        return this._executeStepMove(direction, dx, dy, activeSnake, snakes, levelState, collision, audio, anim, callbacks);
      }
    }

    /**
     * Single step movement
     */
    _executeStepMove(direction, dx, dy, activeSnake, snakes, levelState, collision, audio, anim, callbacks) {
      const head = activeSnake.getHead();
      const targetX = head.x + dx;
      const targetY = head.y + dy;

      const check = collision.isValidMove(activeSnake, targetX, targetY, levelState, snakes, direction);

      if (!check.valid) {
        if (check.reason === 'wall' || check.reason === 'boundary' || check.reason === 'snake' || check.reason === 'gate' || check.reason === 'blocked_block') {
          audio.playWallBump();
          anim.vibrate(30);
        }
        return false;
      }

      // Save complete snapshot to undo stack
      this.historyStack.push(this._createSnapshot(snakes, levelState));
      this.movesCount++;

      // Handle Movable Block Push
      if (check.pushBlock) {
        check.pushBlock.x += check.pushDx;
        check.pushBlock.y += check.pushDy;
        audio.playPushBlock();
        anim.vibrate(25);
      }

      // Turn vs Straight Sound
      if (activeSnake.direction !== direction) {
        audio.playTurn();
      } else {
        audio.playMove();
      }

      if (callbacks.onMoveCountChange) {
        callbacks.onMoveCountChange(this.movesCount);
      }

      // Animate Snake Step
      activeSnake.moveTo(targetX, targetY, 140, () => {
        this._processCellInteractions(activeSnake, targetX, targetY, snakes, levelState, collision, audio, anim, callbacks);
      });

      return true;
    }

    /**
     * Glide mode: continuous sliding in direction until an obstacle or trigger is encountered
     */
    _executeGlideMove(direction, dx, dy, activeSnake, snakes, levelState, collision, audio, anim, callbacks) {
      const head = activeSnake.getHead();
      const firstCheck = collision.isValidMove(activeSnake, head.x + dx, head.y + dy, levelState, snakes, direction);
      if (!firstCheck.valid) {
        audio.playWallBump();
        anim.vibrate(30);
        return false;
      }

      // Save complete snapshot
      this.historyStack.push(this._createSnapshot(snakes, levelState));
      this.movesCount++;

      if (callbacks.onMoveCountChange) {
        callbacks.onMoveCountChange(this.movesCount);
      }

      audio.playMove();

      // Slide step-by-step
      const slideNext = () => {
        if (activeSnake.escaped || activeSnake.isDead) return;

        const curHead = activeSnake.getHead();
        const nextX = curHead.x + dx;
        const nextY = curHead.y + dy;

        const check = collision.isValidMove(activeSnake, nextX, nextY, levelState, snakes, direction);
        if (!check.valid) {
          // Stopped by obstacle
          audio.playWallBump();
          if (callbacks.onMoveComplete) callbacks.onMoveComplete();
          return;
        }

        if (check.pushBlock) {
          check.pushBlock.x += check.pushDx;
          check.pushBlock.y += check.pushDy;
          audio.playPushBlock();
        }

        activeSnake.moveTo(nextX, nextY, 95, () => {
          const stop = this._processCellInteractions(activeSnake, nextX, nextY, snakes, levelState, collision, audio, anim, callbacks);
          if (!stop && !activeSnake.escaped && !activeSnake.isDead) {
            slideNext();
          } else {
            if (callbacks.onMoveComplete) callbacks.onMoveComplete();
          }
        });
      };

      slideNext();
      return true;
    }

    /**
     * Processes switches, keys, gates, portals, traps, collectibles, and exits
     * @returns {boolean} True if snake should stop sliding (in glide mode)
     */
    _processCellInteractions(activeSnake, cellX, cellY, snakes, levelState, collision, audio, anim, callbacks) {
      let shouldStop = false;

      // 1. Collectible Item (star / coin / gem / fruit)
      if (levelState.collectibles) {
        const item = levelState.collectibles.find(c => !c.collected && c.x === cellX && c.y === cellY);
        if (item) {
          item.collected = true;
          this.score += (item.points || 150);
          audio.playCollectItem();
          anim.vibrate(20);
        }
      }

      // 2. Key Pickup
      if (levelState.keys) {
        const key = levelState.keys.find(k => !k.collected && k.x === cellX && k.y === cellY);
        if (key) {
          key.collected = true;
          audio.playCollectKey();
          anim.vibrate([30, 40]);

          // Open all gates matching this key color
          if (levelState.gates) {
            levelState.gates.forEach(g => {
              if (g.requiresKey === key.color || g.color === key.color) {
                g.isOpen = true;
              }
            });
            audio.playGateOpen();
          }
          shouldStop = true;
        }
      }

      // 3. Pressure Switch Activation
      if (levelState.switches) {
        const sw = levelState.switches.find(s => s.x === cellX && s.y === cellY);
        if (sw) {
          sw.pressed = true;
          audio.playSwitch();
          anim.vibrate(35);

          // Activate switch target mechanism
          if (sw.targetType === 'gate' && levelState.gates) {
            levelState.gates.forEach(g => {
              if (!sw.targetId || g.id === sw.targetId) {
                g.isOpen = true;
              }
            });
            audio.playGateOpen();
          } else if (sw.targetType === 'bridge' && levelState.bridges) {
            levelState.bridges.forEach(b => {
              if (!sw.targetId || b.id === sw.targetId) {
                b.active = true;
              }
            });
          } else if (sw.targetType === 'trap' && levelState.traps) {
            levelState.traps.forEach(t => {
              if (!sw.targetId || t.id === sw.targetId) {
                t.state = 'inactive';
              }
            });
          }
          shouldStop = true;
        }
      }

      // 4. Teleport Portals
      if (levelState.portals && levelState.portals.length >= 2) {
        const portal = levelState.portals.find(p => p.x === cellX && p.y === cellY && p.active !== false);
        if (portal) {
          // Find matching pair
          const partner = levelState.portals.find(p => p.id !== portal.id && (p.pairId === portal.pairId || p.color === portal.color));
          if (partner) {
            activeSnake.teleportHead(partner.x, partner.y);
            audio.playPortalTeleport();
            anim.vibrate([40, 60, 40]);
            shouldStop = true;
          }
        }
      }

      // 5. Deadly Traps
      const deadlyTrap = collision.getDeadlyTrapAt(cellX, cellY, levelState.traps);
      if (deadlyTrap) {
        activeSnake.isDead = true;
        audio.playTrapSnap();
        audio.playLevelFailed();
        anim.vibrate([80, 100, 80]);

        if (callbacks.onLevelFailed) {
          callbacks.onLevelFailed('Snake fell into a deadly trap!');
        }
        return true;
      }

      // 6. Exit Portal
      if (collision.hasReachedExit(activeSnake.getHead(), activeSnake.exit)) {
        activeSnake.escaped = true;
        activeSnake.isSelected = false;
        audio.playPortalEscape();
        anim.vibrate([40, 50, 40]);

        // Auto-select next available snake
        const nextSnake = snakes.find(s => !s.escaped && !s.isDead);
        if (nextSnake) {
          this.activeSnakeId = nextSnake.id;
          this._updateSelectionState(snakes);
        }

        if (callbacks.onSnakeEscaped) {
          callbacks.onSnakeEscaped(activeSnake);
        }
        return true;
      }

      if (callbacks.onMoveComplete) {
        callbacks.onMoveComplete();
      }

      return shouldStop;
    }

    /**
     * Reverts to previous complete state snapshot
     */
    undo(snakes, levelState, audio, anim, callbacks = {}) {
      if (!this.historyStack.length) return false;

      const last = this.historyStack.pop();

      // Restore active snake & counters
      this.activeSnakeId = last.activeSnakeId;
      this.movesCount = last.movesCount;
      this.score = last.score;

      // Restore snakes
      last.snakeStates.forEach(savedState => {
        const snake = snakes.find(s => s.id === savedState.id);
        if (snake) {
          snake.segments = JSON.parse(JSON.stringify(savedState.segments));
          snake.prevSegments = JSON.parse(JSON.stringify(savedState.segments));
          snake.direction = savedState.direction;
          snake.headRotation = savedState.headRotation;
          snake.escaped = savedState.escaped;
          snake.isDead = savedState.isDead;
          snake.isMoving = false;
        }
      });

      this._updateSelectionState(snakes);

      // Restore puzzle entities
      levelState.keys = JSON.parse(JSON.stringify(last.keys));
      levelState.gates = JSON.parse(JSON.stringify(last.gates));
      levelState.switches = JSON.parse(JSON.stringify(last.switches));
      levelState.blocks = JSON.parse(JSON.stringify(last.blocks));
      levelState.bridges = JSON.parse(JSON.stringify(last.bridges));
      levelState.traps = JSON.parse(JSON.stringify(last.traps));
      levelState.collectibles = JSON.parse(JSON.stringify(last.collectibles));

      audio.playUndo();
      anim.vibrate(25);

      if (callbacks.onMoveCountChange) {
        callbacks.onMoveCountChange(this.movesCount);
      }
      if (callbacks.onUndo) {
        callbacks.onUndo();
      }
      return true;
    }

    /**
     * Resets level completely to initial configuration
     */
    reset(snakes, initialLevelData) {
      this.historyStack = [];
      this.movesCount = 0;
      this.score = 0;

      // Re-instantiate snakes
      snakes.length = 0;
      initialLevelData.snakes.forEach(data => {
        snakes.push(new window.SnakeEscape.Snake(data));
      });

      this.init(snakes);
    }
  }

  window.SnakeEscape = window.SnakeEscape || {};
  window.SnakeEscape.PlayerController = PlayerController;
})();
