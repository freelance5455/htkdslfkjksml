// ===== player, weapons, viewmodel, projectiles, explosions, pickups =====
const EYE = 1.68;
const enemies = [], proj = [], pickups = [];
const G = { state: 'menu', wave: 0, score: 0, kills: 0, heads: 0, chain: 0, chainT: 0, queue: [], spawnT: 0, breakT: 0, waveActive: false, time: 0 };
const WEAPONS = [
  { id: 'rifle', name: 'M4 KARABİNA', mag: 30, reserve: 150, dmg: 26, rate: 0.085, auto: true, spread: 0.016, adsMul: 0.22, reload: 2.0, kick: 0.0075, bloom: 0.0035 },
  { id: 'shotgun', name: 'POMPALI', mag: 6, reserve: 24, dmg: 15, pellets: 9, rate: 0.85, auto: false, spread: 0.055, adsMul: 0.6, reload: 2.4, kick: 0.045, bloom: 0.01 },
  { id: 'rpg', name: 'RPG-7', mag: 1, reserve: 4, dmg: 260, rate: 0.6, auto: false, spread: 0.004, adsMul: 0.3, reload: 2.6, kick: 0.05, bloom: 0 },
  { id: 'smg', name: 'MP7 SMG', mag: 40, reserve: 200, dmg: 17, rate: 0.058, auto: true, spread: 0.024, adsMul: 0.35, reload: 1.7, kick: 0.0042, bloom: 0.002 },
  { id: 'sniper', name: 'KESKİN NİŞANCI', mag: 5, reserve: 25, dmg: 170, rate: 1.1, auto: false, spread: 0.0025, adsMul: 0.04, reload: 2.8, kick: 0.03, bloom: 0 },
  { id: 'minigun', name: 'MİNİGUN', mag: 200, reserve: 600, dmg: 13, rate: 0.042, auto: true, spread: 0.034, adsMul: 0.7, reload: 5.0, kick: 0.0018, bloom: 0.001, drop: true, spin: true },
  { id: 'plasma', name: 'PLAZMA TÜFEĞİ', mag: 30, reserve: 120, dmg: 44, rate: 0.1, auto: true, spread: 0.005, adsMul: 0.3, reload: 2.2, kick: 0.004, bloom: 0.001, drop: true, splash: 3.2, tcol: 0x66ddff },
  { id: 'pistol', name: 'TABANCA', mag: 15, reserve: 90, dmg: 24, rate: 0.14, auto: false, spread: 0.012, adsMul: 0.3, reload: 1.5, kick: 0.012, bloom: 0.006, gg: true },
  { id: 'knife', name: 'KARAMBİT', mag: 1, reserve: 0, dmg: 300, rate: 0.36, auto: true, spread: 0, adsMul: 1, reload: 1, kick: 0, bloom: 0, gg: true }
];
const NW = WEAPONS.length;
// weapon variants: a new tier unlocks with every map
const VAR_NAMES = {
  rifle: ['M4 KARABİNA', 'M4A1 TAKTİK', 'HK416', 'SCAR-H', 'AUG A3', 'KIZIL ŞAHİN'],
  shotgun: ['POMPALI', 'POMPALI PRO', 'SPAS-12', 'AUTO-12', 'KSG', 'EJDERHA NEFESİ'],
  rpg: ['RPG-7', 'RPG-7V2', 'PG-29', 'JAVELİN-S', 'THOR', 'KIYAMET'],
  smg: ['MP7 SMG', 'MP7A2', 'P90', 'VECTOR', 'KRISS', 'FIRTINA'],
  sniper: ['KESKİN NİŞANCI', 'M24', 'BARRETT M82', 'AWM', 'CHEYTAC', 'HAYALET'],
  minigun: ['MİNİGUN', 'MİNİGUN MK2', 'GATLING', 'VULCAN', 'HELLFIRE', 'KIYAMET GÜNÜ'],
  plasma: ['PLAZMA TÜFEĞİ', 'PLAZMA MK2', 'İYON TÜFEĞİ', 'FOTON', 'NOVA', 'SİNGULARİTE'],
  pistol: ['TABANCA', 'TABANCA', 'TABANCA', 'TABANCA', 'TABANCA', 'TABANCA'],
  knife: ['KARAMBİT', 'KARAMBİT', 'KARAMBİT', 'KARAMBİT', 'KARAMBİT', 'KARAMBİT']
};
const VAR_COL = [0x3a3f44, 0x3a78d8, 0x39b86a, 0x9a5be0, 0xf08a22, 0xe8402c];
function wname(i) { const gl = ggOf(i); if (gl) return gl.n; return VAR_NAMES[WEAPONS[i].id][P.variant ? P.variant[i] : 0]; }
WEAPONS.forEach(w => { w.zoom = w.id === 'knife' ? 75 : w.id === 'pistol' ? 56 : w.id === 'rpg' ? 58 : w.id === 'minigun' ? 62 : w.id === 'plasma' ? 46 : w.id === 'sniper' ? 20 : w.id === 'smg' ? 56 : w.id === 'shotgun' ? 58 : 52; });
const ATT = {
  holo: { slot: 'sight', name: 'Holografik Dürbün', desc: 'Birleşik: 5x yakınlaştırma, saçılma -%65, kırmızı nokta', cost: 0, craft: 1, fx: s => { s.adsMul *= .35; s.zoom = Math.min(s.zoom, 18); s.scopeView = true; s.dot = true; } },
  ml: { slot: 'muzzle', name: 'Namlu Sistemi', desc: 'Birleşik: susturuculu, hasar +%15, saçılma -%20', cost: 0, craft: 1, fx: s => { s.quiet = true; s.dmg *= 1.15; s.spread *= .8; s.kick *= .8; } },
  drum: { slot: 'mag', name: 'Tambur Şarjör', desc: 'Birleşik: kapasite x1.8, şarjör süresi -%30', cost: 0, craft: 1, fx: s => { s.mag = Math.ceil(s.mag * 1.8); s.reload *= .7; } },
  pro: { slot: 'grip', name: 'Pro Dipçik', desc: 'Birleşik: geri tepme -%60, saçılma -%25', cost: 0, craft: 1, fx: s => { s.kick *= .4; s.bloom *= .4; s.spread *= .75; } },
  brake: { slot: 'muzzle', name: 'Süper Fren', desc: 'Birleşik: geri tepme -%75, saçılma -%15', cost: 0, craft: 1, fx: s => { s.kick *= .25; s.spread *= .85; s.bloom *= .5; } },
  smart: { slot: 'under', name: 'Akıllı Bağlantı', desc: 'Birleşik: saçılma -%40, yayılma -%70, geri tepme -%40', cost: 0, craft: 1, fx: s => { s.spread *= .6; s.bloom *= .3; s.kick *= .6; } },
  ex: { slot: 'ammo', name: 'Patlayıcı Uç', desc: 'Birleşik: hasar +%45, parlak iz', cost: 0, craft: 1, fx: s => { s.dmg *= 1.45; s.tcol = 0xff7a30; } },
  quantum: { slot: 'sight', name: 'Kuantum Nişangâh', desc: 'Birleşik: 8x yakınlaştırma, saçılma -%75', cost: 0, craft: 1, fx: s => { s.adsMul *= .25; s.zoom = Math.min(s.zoom, 12); s.scopeView = true; } },
  rapid: { slot: 'mag', name: 'Işık Hızlı Şarjör', desc: 'Birleşik: şarjör süresi -%65, kapasite +%40', cost: 0, craft: 1, fx: s => { s.reload *= .35; s.mag = Math.ceil(s.mag * 1.4); } },
  grip2: { slot: 'grip', name: 'Komando Tutamağı', desc: 'Birleşik: geri tepme -%65, saçılma -%30', cost: 0, craft: 1, fx: s => { s.kick *= .35; s.spread *= .7; s.bloom *= .5; } },
  dragon: { slot: 'ammo', name: 'Ejderha Mermisi', desc: 'Birleşik: hasar +%55, geri tepme +%10', cost: 0, craft: 1, fx: s => { s.dmg *= 1.55; s.kick *= 1.1; s.tcol = 0xff4a20; } },
  omega: { slot: 'muzzle', name: 'Omega Namlu', desc: 'Efsanevi: sessiz, hasar +%35, saçılma -%35, geri tepme -%50', cost: 0, craft: 1, fx: s => { s.quiet = true; s.dmg *= 1.35; s.spread *= .65; s.kick *= .5; } },
  nova: { slot: 'sight', name: 'Nova Nişangâh', desc: 'Efsanevi: 10x yakınlaştırma, saçılma -%85, hasar +%10', cost: 0, craft: 1, fx: s => { s.adsMul *= .15; s.zoom = Math.min(s.zoom, 10); s.scopeView = true; s.dot = true; s.dmg *= 1.1; } },
  overdrive: { slot: 'mag', name: 'Aşırı Yük Şarjör', desc: 'Efsanevi: kapasite x2.2, şarjör süresi -%75', cost: 0, craft: 1, fx: s => { s.mag = Math.ceil(s.mag * 2.2); s.reload *= .25; } },
  titan: { slot: 'grip', name: 'Titan Dipçik', desc: 'Efsanevi: geri tepme -%85, saçılma -%45', cost: 0, craft: 1, fx: s => { s.kick *= .15; s.bloom *= .2; s.spread *= .55; } },
  apex: { slot: 'ammo', name: 'Apex Mermisi', desc: 'Efsanevi: hasar x2, iz parlak mor', cost: 0, craft: 1, fx: s => { s.dmg *= 2; s.tcol = 0xd070ff; } },
  flash: { slot: 'muzzle', name: 'Alev Gizleyici', desc: 'Geri tepme -%25, namlu alevi azalır', cost: 450, fx: s => { s.kick *= .75; } },
  comp: { slot: 'muzzle', name: 'Kompansatör', desc: 'Geri tepme -%35, saçılma -%10', cost: 550, fx: s => { s.kick *= .65; s.spread *= .9; } },
  acog: { slot: 'sight', name: 'ACOG 2.5x', desc: 'Orta yakınlaştırma, saçılma -%35', cost: 650, fx: s => { s.adsMul *= .65; s.zoom = Math.min(s.zoom, 34); } },
  quick: { slot: 'mag', name: 'Çift Şarjör', desc: 'Şarjör süresi -%30, kapasite +%20', cost: 800, fx: s => { s.reload *= .7; s.mag = Math.ceil(s.mag * 1.2); } },
  angled: { slot: 'grip', name: 'Açılı Tutamak', desc: 'Geri tepme -%25, saçılma -%10', cost: 500, fx: s => { s.kick *= .75; s.spread *= .9; } },
  laser: { slot: 'under', name: 'Lazer Hedefleyici', desc: 'Saçılma -%18, yayılma -%20', cost: 600, fx: s => { s.spread *= .82; s.bloom *= .8; } },
  bipod: { slot: 'under', name: 'İki Ayak', desc: 'Geri tepme -%30, nişanda daha stabil', cost: 650, fx: s => { s.kick *= .7; s.adsMul *= .85; } },
  ap: { slot: 'ammo', name: 'Zırh Delici Mermi', desc: 'Hasar +%15, tanklara karşı daha etkili', cost: 900, fx: s => { s.dmg *= 1.15; s.ap = true; s.tcol = 0xffe070; } },
  hp: { slot: 'ammo', name: 'Boşluklu Uç', desc: 'Hasar +%22, geri tepme +%8', cost: 850, fx: s => { s.dmg *= 1.22; s.kick *= 1.08; s.tcol = 0xffb0a0; } },
  inc: { slot: 'ammo', name: 'Yakıcı Mermi', desc: 'Hasar +%10, ateş izi', cost: 800, fx: s => { s.dmg *= 1.1; s.tcol = 0xff8a30; } },
  sup: { slot: 'muzzle', name: 'Susturucu', desc: 'Ses ve namlu alevi azalır, geri tepme -%20', cost: 600, fx: s => { s.quiet = true; s.kick *= .8; s.dmg *= .95; } },
  long: { slot: 'muzzle', name: 'Uzun Namlu', desc: 'Hasar +%15, saçılma -%20', cost: 700, fx: s => { s.dmg *= 1.15; s.spread *= .8; } },
  dot: { slot: 'sight', name: 'Kırmızı Nokta', desc: 'Nişanda saçılma -%30, nokta görünümü', cost: 400, fx: s => { s.adsMul *= .7; s.dot = true; s.zoom = Math.min(s.zoom, 46); } },
  scope: { slot: 'sight', name: '4x Dürbün', desc: 'Nişanda yakınlaştırma, saçılma -%50', cost: 900, fx: s => { s.adsMul *= .5; s.zoom = Math.min(s.zoom, 22); s.scopeView = true; } },
  magx: { slot: 'mag', name: 'Genişletilmiş Şarjör', desc: 'Şarjör kapasitesi +%50', cost: 500, fx: s => { s.mag = Math.ceil(s.mag * 1.5); } },
  fastmag: { slot: 'mag', name: 'Hızlı Şarjör', desc: 'Şarjör değiştirme -%40 süre', cost: 500, fx: s => { s.reload *= .6; } },
  stock: { slot: 'grip', name: 'Stabil Dipçik', desc: 'Geri tepme -%45, yayılma -%40', cost: 450, fx: s => { s.kick *= .55; s.bloom *= .6; } },
  vgrip: { slot: 'grip', name: 'Dik Tutamak', desc: 'Saçılma -%15, geri tepme -%20', cost: 450, fx: s => { s.spread *= .85; s.kick *= .8; } }
};
const SLOT_NAMES = { muzzle: 'NAMLU', sight: 'NİŞANGÂH', mag: 'ŞARJÖR', grip: 'DİPÇİK / TUTAMAK', under: 'ALT PARÇA', ammo: 'MERMİ' };
// crafting: two parts make one stronger part; the strongest parts need crafted parts
const RECIPES = [
  ['sup', 'long', 'ml', 150], ['dot', 'scope', 'holo', 150], ['magx', 'fastmag', 'drum', 150], ['stock', 'vgrip', 'pro', 150],
  ['flash', 'comp', 'brake', 150], ['laser', 'bipod', 'smart', 150], ['ap', 'hp', 'ex', 150], ['acog', 'scope', 'quantum', 150], ['quick', 'fastmag', 'rapid', 150], ['angled', 'vgrip', 'grip2', 150], ['inc', 'ap', 'dragon', 150],
  ['ml', 'brake', 'omega', 450], ['holo', 'quantum', 'nova', 450], ['drum', 'rapid', 'overdrive', 450], ['pro', 'grip2', 'titan', 450], ['smart', 'ex', 'apex', 450]
];
const _wsc = [];
function invalidateWS() { _wsc.length = 0; }
function WS(i) {
  if (_wsc[i]) return _wsc[i];
  const s = Object.assign({}, WEAPONS[i]), a = P.att[i] || {};
  { const gl = ggOf(i); if (gl) { Object.assign(s, gl.w); s.name = gl.n; return _wsc[i] = s; } }
  if (s.id !== 'rpg') for (const k in a) if (a[k]) ATT[a[k]].fx(s);
  const vt = (P.variant && P.variant[i]) || 0; s.name = VAR_NAMES[s.id][vt];
  s.dmg *= 1 + .16 * vt; s.mag = Math.ceil(s.mag * (1 + .08 * vt)); s.reload *= 1 - .04 * vt; s.spread *= 1 - .05 * vt; s.rate *= 1 - .03 * vt;
  const lv = (P.up && P.up.wlv[i]) || 0;
  s.dmg *= 1 + .1 * lv; s.mag = Math.ceil(s.mag * (1 + .08 * lv)); s.reload *= 1 - .05 * lv; s.spread *= 1 - .04 * lv; s.kick *= 1 - .04 * lv;
  s.dmg *= P.dmgMult; s.reload *= 1 - .1 * (P.up ? P.up.rl || 0 : 0); return _wsc[i] = s;
}
const RB = { box: $('rbar'), fill: $('rbarFill'), txt: $('rbarTxt') };
function reloadBar(frac, txt) { if (frac < 0) { if (RB.box.style.display !== 'none') RB.box.style.display = 'none'; return; } RB.box.style.display = 'block'; RB.fill.style.width = (frac * 100) + '%'; if (RB.txt._t !== txt) { RB.txt.textContent = txt; RB.txt._t = txt; } }
const P = {
  pos: new THREE.Vector3(0, 0, 2), vx: 0, vz: 0, vy: 0, onGround: true, yaw: 0, pitch: 0, hp: 100, maxHp: 100, armor: 0, maxArmor: 100, money: 0, molo: 0, air: 0, dmgMult: 1, regen: false, sinceHurt: 0, owned: [true, true, true, false, false, false, false, false, false], att: [{}, {}, {}, {}, {}, {}, {}, {}, {}], variant: [0, 0, 0, 0, 0, 0, 0, 0, 0], spin: 0, gg: null, ggArch: -1, kt: 9, ktype: 0, kHit: false, kIdle: 0, kFlipT: -1, kFlipK: 0, attInv: {}, lootNear: null, merchNear: false, dead: false, deadT: 0,
  cur: 0, wInsp: -1, kSpin: -1, kKind: 'ads', kAdsPrev: false, ws: [], gren: 3, fireT: 0, reload: 0, swT: 0, nextWeap: 0, ads: 0, adsHeld: false, trigger: false, semiReady: true,
  bloom: 0, rc: 0, shake: 0, stepD: 0, dryT: 0, grenT: 0, hurtT: 0, flashVM: 0, sprint: false, bobT: 0, swayX: 0, swayY: 0,
  fwd: new THREE.Vector3(), right: new THREE.Vector3(), upv: new THREE.Vector3()
};
function resetPlayer() {
  P.ggSet = null; P.gg = null; P.ggArch = -1; P.pos.set(0, 0, 2); P.vx = P.vz = P.vy = 0; P.yaw = 0; P.pitch = 0; P.inTank = false; P.hp = 100; P.maxHp = 100; P.armor = 0; P.maxArmor = 100; P.money = 200; P.molo = 1; P.air = 0; P.dmgMult = 1; P.regen = false; P.sinceHurt = 0; P.owned = [true, true, true, false, false, false, false, false, false]; P.att = [{}, {}, {}, {}, {}, {}, {}, {}, {}]; P.variant = [0, 0, 0, 0, 0, 0, 0, 0, 0]; P.gg = null; P.ggArch = -1; P.kt = 9; P.kHit = false; P.kIdle = 0; P.kFlipT = -1; P.spin = 0; P.attInv = {}; invalidateWS(); P.dead = false; P.deadT = 0; P.cur = 0; P.gren = 3;
  P.fireT = P.reload = P.swT = P.bloom = P.rc = P.shake = P.hurtT = 0; P.ads = 0; P.trigger = false; P.semiReady = true;
  P.ws = WEAPONS.map(w => ({ ammo: w.mag, reserve: w.reserve }));
  P.stance = 0; P.eyeH = EYE; P.sprintT = 0; P.throwT = 0; P.nextWeap = 0; P.swT = .45; P.lootNear = null;
  P.slideT = 0; P.slideRoll = 0; P.boostT = 0; P.up = { spd: 0, rl: 0, vamp: 0, wlv: [0, 0, 0, 0, 0, 0, 0, 0, 0], arm: 0, hp: 0, gren: 0, molo: 0, mag: 0, rare: { dmg: 0, hp: 0, arm: 0 }, tank: { arm: 0, gun: 0, rld: 0 } };
  recomputeStats(); P.hp = P.maxHp; P.armor = 0;
}
function recomputeStats() {
  const u = P.up, r = u.rare;
  P.maxHp = 100 + 25 * u.hp + 100 * r.hp; P.maxArmor = 100 + 25 * u.arm + (r.arm ? 50 + 50 * r.arm : 0); P.dmgMult = [1, 1.35, 1.7, 2.1][r.dmg] * (P.boostT > 0 ? 1.6 : 1);
  P.regen = r.hp > 0; P.hp = Math.min(P.hp, P.maxHp); P.armor = Math.min(P.armor, P.maxArmor); invalidateWS();
}
resetPlayer();

// ---- viewmodel ----
const vmSun = new THREE.DirectionalLight(0xffc890, 1.4); vmSun.position.set(-1, 1, .5);
vmScene.add(new THREE.HemisphereLight(0xffe0c0, 0x403028, 1.1), vmSun);
const vmFlash = new THREE.PointLight(0xffa850, 0, 3); vmScene.add(vmFlash);
const VM = new THREE.Group(); vmScene.add(VM);
const vmM = {
  gun: new THREE.MeshStandardMaterial({ color: 0x2b2e31, roughness: .5, metalness: .35 }),
  poly: new THREE.MeshStandardMaterial({ color: 0x171717, roughness: .7 }),
  wood: new THREE.MeshStandardMaterial({ color: 0x6a4527, roughness: .8 }),
  sleeve: new THREE.MeshStandardMaterial({ color: 0x4a5236, roughness: 1 }),
  glove: new THREE.MeshStandardMaterial({ color: 0x23211d, roughness: .9 }),
  green: new THREE.MeshStandardMaterial({ color: 0x4d5a3a, roughness: .7, metalness: .2 }),
  red: new THREE.MeshBasicMaterial({ color: 0xff2a1a })
};
function vmMesh(g, geo, mat, x, y, z, rx = 0, ry = 0, rz = 0) { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.rotation.set(rx, ry, rz); g.add(m); return m; }
function limb(g, a, b, r, mat) {
  const d = new THREE.Vector3().subVectors(b, a), len = d.length();
  const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r * 1.1, len, 8), mat);
  m.position.copy(a).add(b).multiplyScalar(.5); m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.normalize()); g.add(m);
}
const BX = (w, h, d) => new THREE.BoxGeometry(w, h, d), CY = (r, l, s = 10) => new THREE.CylinderGeometry(r, r, l, s);
// right hand stays on the grip (child of the gun); the left hand is a separate rig so it can leave the gun to fetch mags
function arms(g, lh, rh) {
  g.userData.lh = new THREE.Vector3(...lh);
  limb(g, new THREE.Vector3(rh[0] + .2, rh[1] - .3, rh[2] + .5), new THREE.Vector3(...rh), .042, vmM.sleeve);
  vmMesh(g, BX(.07, .085, .09), vmM.glove, rh[0], rh[1], rh[2]);
}
function accent(g, w, y, z, len) { const mat = new THREE.MeshStandardMaterial({ color: VAR_COL[0], roughness: .35, metalness: .6 }); vmMesh(g, BX(w, .012, len), mat, 0, y, z); g.userData.acc = mat; }
function magPts(R, M, belt, C) {
  return [[0, R], [.1, [M[0], M[1] - .015, M[2] - .09]], [.18, [M[0], M[1] - .055, M[2] - .01]], [.3, [M[0], M[1] - .355, M[2] + .04]], [.36, [M[0], M[1] - .41, M[2] + .1]], [.4, [belt[0], belt[1] + .04, belt[2]]], [.46, belt],
    [.58, [M[0], M[1] - .275, M[2] + .03]], [.66, [M[0], M[1] - .085, M[2]]], [.7, [M[0], M[1] - .055, M[2] - .01]], [.76, [M[0], M[1] - .06, M[2] - .02]], [.8, C], [.86, [C[0], C[1], C[2] + .09]], [.9, C], [1, R]];
}
function mkRifle() {
  const g = new THREE.Group();
  vmMesh(g, BX(.055, .095, .34), vmM.gun, 0, 0, -.05); vmMesh(g, BX(.05, .06, .22), vmM.poly, 0, -.005, -.32);
  vmMesh(g, CY(.011, .32), vmM.gun, 0, .012, -.56, Math.PI / 2); vmMesh(g, CY(.016, .06), vmM.gun, 0, .012, -.72, Math.PI / 2);
  const mag = vmMesh(g, BX(.04, .14, .07), vmM.poly, 0, -.115, -.03, .25); vmMesh(g, BX(.04, .1, .05), vmM.poly, 0, -.095, .1, -.35);
  vmMesh(g, BX(.05, .085, .26), vmM.poly, 0, -.01, .29); vmMesh(g, BX(.008, .05, .008), vmM.gun, 0, .07, -.64);
  vmMesh(g, BX(.04, .03, .05), vmM.gun, 0, .065, .02); vmMesh(g, BX(.012, .012, .004), vmM.red, 0, .088, .02);
  accent(g, .058, .05, -.1, .2);
  const dropMag = vmMesh(g, BX(.04, .14, .07), vmM.poly, 0, -.115, -.03, .25); dropMag.visible = false;
  arms(g, [0, -.05, -.3], [0, -.11, .09]);
  Object.assign(g.userData, { style: 'rifle', mag, dropMag, magBase: { x: 0, y: -.115, z: -.03, rx: .25 }, muzzle: new THREE.Vector3(0, .012, -.76), hip: new THREE.Vector3(.2, -.2, -.42), ads: new THREE.Vector3(0, -.083, -.3) });
  g.userData.hpts = magPts([0, -.05, -.3], [0, -.115, -.03], [-.13, -.6, .2], [.02, .09, .06]);
  return g;
}
function mkShotgun() {
  const g = new THREE.Group();
  vmMesh(g, BX(.06, .09, .3), vmM.gun, 0, 0, -.02); vmMesh(g, CY(.016, .85), vmM.gun, 0, .02, -.5, Math.PI / 2);
  vmMesh(g, CY(.014, .55), vmM.gun, 0, -.025, -.38, Math.PI / 2); const pump = vmMesh(g, BX(.055, .05, .2), vmM.wood, 0, -.03, -.3);
  vmMesh(g, BX(.055, .1, .3), vmM.wood, 0, -.03, .26, .15); vmMesh(g, BX(.008, .03, .008), vmM.red, 0, .045, -.88);
  accent(g, .064, .048, -.05, .2);
  const shell = vmMesh(g, CY(.012, .06, 8), vmM.red, 0, 0, 0); shell.visible = false;
  arms(g, [0, -.04, -.3], [0, -.1, .08]);
  Object.assign(g.userData, { style: 'shell', pump, shell, muzzle: new THREE.Vector3(0, .02, -.95), hip: new THREE.Vector3(.2, -.21, -.42), ads: new THREE.Vector3(0, -.085, -.32) });
  return g;
}
function mkRPG() {
  const g = new THREE.Group();
  vmMesh(g, CY(.045, .95, 12), vmM.green, 0, 0, -.1, Math.PI / 2); vmMesh(g, new THREE.ConeGeometry(.07, .18, 12), vmM.gun, 0, 0, .42, -Math.PI / 2);
  const w = vmMesh(g, new THREE.ConeGeometry(.055, .3, 12), vmM.green, 0, 0, -.75, Math.PI / 2); g.userData.war = w; g.userData.warBase = w.position.clone();
  vmMesh(g, BX(.03, .07, .05), vmM.poly, 0, -.09, -.05, .2); vmMesh(g, BX(.02, .05, .06), vmM.gun, 0, .06, -.12);
  accent(g, .04, .047, -.3, .25);
  arms(g, [0, -.075, -.28], [0, -.11, .05]);
  Object.assign(g.userData, { style: 'rpg', muzzle: new THREE.Vector3(0, 0, -.85), hip: new THREE.Vector3(.22, -.17, -.45), ads: new THREE.Vector3(.02, -.08, -.38) });
  return g;
}
function mkSMG() {
  const g = mkRifle(); g.scale.set(1, 1, .78); const u = g.userData;
  Object.assign(u, { style: 'smg', muzzle: new THREE.Vector3(0, .012, -.6), hip: new THREE.Vector3(.2, -.2, -.4), ads: new THREE.Vector3(0, -.083, -.27) });
  return g;
}
function mkSniper() {
  const g = mkRifle(); vmMesh(g, CY(.03, .3), vmM.gun, 0, .09, -.02, Math.PI / 2); vmMesh(g, CY(.036, .05), vmM.poly, 0, .09, -.18, Math.PI / 2); g.scale.set(1, 1, 1.3);
  Object.assign(g.userData, { style: 'bolt', muzzle: new THREE.Vector3(0, .012, -.98), hip: new THREE.Vector3(.2, -.21, -.46), ads: new THREE.Vector3(0, -.1, -.3) });
  const bolt = new THREE.Group(); bolt.position.set(.034, .035, .09); g.add(bolt);
  vmMesh(bolt, CY(.007, .07), vmM.gun, 0, 0, 0, Math.PI / 2); vmMesh(bolt, BX(.045, .009, .009), vmM.gun, .024, -.006, .02); vmMesh(bolt, new THREE.SphereGeometry(.014, 8, 6), vmM.poly, .05, -.012, .02);
  g.userData.bolt = bolt; g.userData.boltBase = bolt.position.clone(); return g;
}
function mkMinigun() {
  const g = new THREE.Group(), box = new THREE.MeshStandardMaterial({ color: 0x4a5236, roughness: .6, metalness: .3 });
  vmMesh(g, BX(.1, .12, .32), vmM.gun, 0, 0, 0); vmMesh(g, BX(.07, .06, .22), vmM.poly, 0, .08, .05); vmMesh(g, BX(.1, .1, .12), vmM.poly, 0, 0, .2);
  const spinG = new THREE.Group(); spinG.position.set(0, 0, -.16); g.add(spinG);
  for (let i = 0; i < 6; i++) { const a = i / 6 * 6.283; vmMesh(spinG, CY(.011, .66, 8), vmM.gun, Math.cos(a) * .036, Math.sin(a) * .036, -.33, Math.PI / 2); }
  vmMesh(spinG, CY(.052, .05, 12), vmM.poly, 0, 0, -.18, Math.PI / 2); vmMesh(spinG, CY(.052, .05, 12), vmM.poly, 0, 0, -.62, Math.PI / 2); vmMesh(spinG, CY(.02, .5, 8), vmM.gun, 0, 0, -.33, Math.PI / 2);
  const mag = vmMesh(g, BX(.14, .13, .22), box, -.1, -.1, .02); vmMesh(g, CY(.016, .2, 6), vmM.gun, -.05, -.05, .0, 0, 0, 1.0);
  vmMesh(g, BX(.04, .1, .05), vmM.poly, 0, -.1, .12); vmMesh(g, BX(.03, .1, .05), vmM.poly, 0, -.09, -.2);
  accent(g, .104, .063, .0, .24);
  const dropMag = vmMesh(g, BX(.14, .13, .22), box, -.1, -.1, .02); dropMag.visible = false;
  arms(g, [0, -.09, -.2], [0, -.12, .12]);
  Object.assign(g.userData, { style: 'mg', mag, dropMag, spinG, magBase: { x: -.1, y: -.1, z: .02, rx: 0 }, muzzle: new THREE.Vector3(0, 0, -.98), hip: new THREE.Vector3(.2, -.22, -.52), ads: new THREE.Vector3(0, -.12, -.46) });
  g.userData.hpts = magPts([0, -.09, -.2], [-.1, -.1, .02], [-.22, -.62, .2], [0, .05, .0]);
  return g;
}
function mkPlasma() {
  const g = new THREE.Group(), cy = new THREE.MeshBasicMaterial({ color: 0x66ddff }), body = new THREE.MeshStandardMaterial({ color: 0x20252b, roughness: .3, metalness: .8 });
  vmMesh(g, BX(.05, .1, .45), body, 0, 0, -.1); vmMesh(g, BX(.045, .07, .2), vmM.poly, 0, -.005, .26);
  for (const sx of [-1, 1]) vmMesh(g, BX(.012, .014, .42), body, sx * .028, .02, -.46);
  vmMesh(g, CY(.016, .34, 8), cy, 0, .018, -.42, Math.PI / 2); vmMesh(g, CY(.03, .04, 10), cy, 0, .018, -.64, Math.PI / 2); vmMesh(g, BX(.03, .03, .08), body, 0, .07, .02);
  const mag = vmMesh(g, CY(.028, .12, 10), cy, 0, -.09, -.02); mag.rotation.x = 0; vmMesh(g, BX(.04, .03, .06), body, 0, -.055, -.02);
  accent(g, .054, .052, -.05, .16);
  const dropMag = vmMesh(g, CY(.028, .12, 10), cy, 0, -.09, -.02); dropMag.visible = false;
  arms(g, [0, -.05, -.32], [0, -.11, .1]);
  Object.assign(g.userData, { style: 'cell', mag, dropMag, magBase: { x: 0, y: -.09, z: -.02, rx: 0 }, muzzle: new THREE.Vector3(0, .018, -.68), hip: new THREE.Vector3(.2, -.2, -.42), ads: new THREE.Vector3(0, -.08, -.3) });
  g.userData.hpts = magPts([0, -.05, -.32], [0, -.09, -.02], [-.12, -.58, .2], [0, -.05, -.32]);
  return g;
}

function mkPistol() {
  const g = new THREE.Group(), steel = new THREE.MeshStandardMaterial({ color: 0x2a2d31, roughness: .35, metalness: .8 });
  const slide = vmMesh(g, BX(.036, .046, .22), steel, 0, .02, -.1); vmMesh(g, BX(.034, .036, .17), vmM.poly, 0, -.022, -.07); vmMesh(g, CY(.009, .05, 8), vmM.gun, 0, .018, -.235, Math.PI / 2);
  vmMesh(g, BX(.04, .105, .058), vmM.poly, 0, -.085, .035, .2); vmMesh(g, BX(.006, .012, .006), vmM.gun, 0, .047, -.2); vmMesh(g, BX(.014, .012, .006), vmM.gun, 0, .047, .0); vmMesh(g, BX(.004, .004, .004), vmM.red, 0, .054, -.2);
  vmMesh(g, BX(.03, .02, .06), vmM.poly, 0, -.04, -.01); accent(g, .038, .0445, -.08, .12);
  const mag = vmMesh(g, BX(.03, .09, .045), vmM.gun, 0, -.13, .04, .2); const dropMag = vmMesh(g, BX(.03, .09, .045), vmM.gun, 0, -.13, .04, .2); dropMag.visible = false;
  arms(g, [-.012, -.095, -.01], [0, -.1, .045]);
  Object.assign(g.userData, { style: 'pistol', mag, dropMag, slide, slideBase: slide.position.z, magBase: { x: 0, y: -.13, z: .04, rx: .2 }, muzzle: new THREE.Vector3(0, .018, -.27), hip: new THREE.Vector3(.17, -.17, -.34), ads: new THREE.Vector3(0, -.065, -.26) });
  g.userData.hpts = magPts([-.012, -.095, -.01], [0, -.13, .04], [-.1, -.5, .2], [0, .02, -.02]);
  return g;
}
function mkKnife() {
  const g = new THREE.Group(), blade = new THREE.MeshStandardMaterial({ color: 0xcfd6dc, roughness: .18, metalness: .95 }), spine = new THREE.MeshStandardMaterial({ color: 0x15171a, roughness: .4, metalness: .7 }), grip = new THREE.MeshStandardMaterial({ color: 0x1c1f22, roughness: .8, metalness: .1 });
  // the knife hangs on a pivot at its finger ring so it can spin around the finger while the hand stays put
  const piv = new THREE.Group(); piv.position.set(0, 0, .105); const K = new THREE.Group(); K.position.set(0, 0, -.105); piv.add(K); g.add(piv);
  vmMesh(K, BX(.03, .034, .13), grip, 0, 0, .03);
  for (let i = 0; i < 5; i++) vmMesh(K, BX(.032, .01, .008), spine, 0, .002, -.01 + i * .024);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(.026, .006, 8, 18), blade); ring.position.set(0, 0, .105); ring.rotation.y = Math.PI / 2; K.add(ring);
  const bl = new THREE.Group(); bl.position.set(0, .006, -.035); K.add(bl); const R = .105, N = 9;
  for (let i = 0; i < N; i++) { const a = i * .24, a2 = (i + 1) * .24, z = -R * Math.sin(a), y = -R * (1 - Math.cos(a)), w = lerp(.034, .004, i / N), seg = vmMesh(bl, BX(.0045, w, .03), blade, 0, y - (.034 - w) * .0, z, -a - .12);
    vmMesh(bl, BX(.006, .007, .03), spine, 0, y + w * .5, z, -a - .12); }
  // gloved hand: palm, four fingers that wrap the grip (and open up while the knife spins), thumb, and a finger through the ring
  const gl = vmM.glove, fing = [];
  vmMesh(g, BX(.04, .04, .1), gl, .05, -.03, .026);
  for (let i = 0; i < 4; i++) {
    const f = new THREE.Group(); f.position.set(.03, -.027, -.012 + i * .024); g.add(f);
    vmMesh(f, BX(.056, .019, .021), gl, -.028, 0, 0); vmMesh(f, BX(.019, .05, .021), gl, -.0575, .025, 0); vmMesh(f, BX(.04, .019, .021), gl, -.044, .0535, 0); fing.push(f);
  }
  const th = new THREE.Group(); th.position.set(.035, 0, -.024); g.add(th); vmMesh(th, BX(.016, .06, .018), gl, 0, -.005, 0, 0, 0, .15); vmMesh(th, BX(.018, .018, .055), gl, -.024, .03, .012, 0, .25, 0);
  limb(g, new THREE.Vector3(.05, -.03, .07), new THREE.Vector3(.02, -.0, .105), .011, gl); vmMesh(g, BX(.075, .016, .016), gl, .012, 0, .105);
  limb(g, new THREE.Vector3(.13, -.3, .32), new THREE.Vector3(.055, -.035, .08), .047, vmM.sleeve);
  g.userData.lh = new THREE.Vector3(0, -.3, .1);
  Object.assign(g.userData, { style: 'knife', ring, piv, fing, thumb: th, muzzle: new THREE.Vector3(0, 0, -.2), hip: new THREE.Vector3(.17, -.19, -.36), ads: new THREE.Vector3(.17, -.19, -.36) });
  return g;
}
const VMS = [mkRifle(), mkShotgun(), mkRPG(), mkSMG(), mkSniper(), mkMinigun(), mkPlasma(), mkPistol(), mkKnife()];
VMS.forEach(m => { VM.add(m); m.visible = false; });
const vmFlashSpr = new THREE.Sprite(new THREE.SpriteMaterial({ map: TEX_FLASH, blending: THREE.AdditiveBlending, depthTest: false, transparent: true }));
vmFlashSpr.scale.setScalar(.3); vmFlashSpr.visible = false; vmScene.add(vmFlashSpr);

// ---- left hand rig ----
const LH = new THREE.Group(); vmScene.add(LH);
const lhGlove = vmMesh(LH, BX(.075, .065, .11), vmM.glove, 0, 0, 0), lhArm = new THREE.Mesh(new THREE.CylinderGeometry(.042, .05, 1, 8), vmM.sleeve); LH.add(lhArm);
const LH_E = new THREE.Vector3(-.3, -.66, .16), HAND = new THREE.Vector3(), _kv = new THREE.Vector3(), _lw = new THREE.Vector3(), _le = new THREE.Vector3(), _ld2 = new THREE.Vector3(), _lq = new THREE.Quaternion(), _yv = new THREE.Vector3(0, 1, 0);
function placeLeftHand(vm) {
  vm.updateMatrixWorld(true); _lw.copy(HAND); vm.localToWorld(_lw); vm.getWorldQuaternion(_lq);
  lhGlove.position.copy(_lw); lhGlove.quaternion.copy(_lq);
  _ld2.copy(LH_E).sub(_lw); const dist = _ld2.length() || 1, len = Math.min(dist, .72); _ld2.multiplyScalar(1 / dist); _le.copy(_lw).addScaledVector(_ld2, len);
  lhArm.position.copy(_lw).addScaledVector(_ld2, len * .5 + .03); lhArm.scale.set(1, len, 1); lhArm.quaternion.setFromUnitVectors(_yv, _ld2);
}
function keyed(k, pts) {
  if (k <= pts[0][0]) return _kv.set(...pts[0][1]);
  for (let i = 1; i < pts.length; i++) if (k <= pts[i][0]) { const a = pts[i - 1], b = pts[i], u = sstep(a[0], b[0], k); return _kv.set(lerp(a[1][0], b[1][0], u), lerp(a[1][1], b[1][1], u), lerp(a[1][2], b[1][2], u)); }
  return _kv.set(...pts[pts.length - 1][1]);
}

function resetParts(ud) {
  if (ud.mag) { const b = ud.magBase; ud.mag.position.set(b.x, b.y, b.z); ud.mag.rotation.set(b.rx, 0, 0); ud.mag.visible = true; }
  if (ud.dropMag) ud.dropMag.visible = false;
  if (ud.pump) ud.pump.position.z = -.3;
  if (ud.shell) ud.shell.visible = false;
  if (ud.war) ud.war.position.copy(ud.warBase);
  if (ud.bolt) { ud.bolt.position.copy(ud.boltBase); ud.bolt.rotation.set(0, 0, 0); }
}
const MAG_O = new THREE.Vector3(0, .055, .01), ROLL = { rifle: .55, smg: 1.0, bolt: .35, mg: .22, cell: .45 };
const _p1 = new THREE.Vector3(), _p2 = new THREE.Vector3(), _p3 = new THREE.Vector3();
function reloadAnim(vm, ud, k, w) {
  const st = ud.style || 'rifle';
  if (st === 'shell') { // roll the gun over, feed shells one by one from the pouch, then pump
    const t = sstep(0, .1, k) * (1 - sstep(.72, .8, k));
    vm.rotation.z += t * .95; vm.position.y += t * .03; vm.position.x -= t * .08; vm.position.z += t * .03; vm.rotation.x += t * .12;
    const R = [0, -.04, -.3], port = [0, -.075, -.02], pouch = [-.12, -.42, .12];
    if (k < .1) HAND.set(lerp(R[0], port[0], sstep(0, .1, k)), lerp(R[1], port[1], sstep(0, .1, k)), lerp(R[2], port[2], sstep(0, .1, k)));
    else if (k < .74) {
      const ph = (k - .1) / .64 * 4, f = ph % 1; let u;
      if (f < .4) u = 1 - (1 - sstep(0, .4, f)); else if (f < .5) u = 1; else if (f < .9) u = 1 - sstep(.5, .9, f); else u = 0;
      HAND.set(lerp(port[0], pouch[0], u), lerp(port[1], pouch[1], u) + (f > .9 ? .012 : 0), lerp(port[2], pouch[2], u));
      if (f > .45 && f < .93) { ud.shell.visible = true; ud.shell.position.copy(HAND).add(_p1.set(0, .03, -.01)); ud.shell.rotation.set(1.2, 0, .3); vm.position.y -= Math.sin((f - .45) * 6) * .004; }
      if (f >= .9) vm.rotation.x += Math.sin((f - .9) * 31.4) * .03;
    } else if (k < .84) HAND.set(lerp(port[0], R[0], sstep(.74, .84, k)), lerp(port[1], R[1], sstep(.74, .84, k)), lerp(port[2], R[2], sstep(.74, .84, k)));
    else HAND.set(0, -.04, ud.pump ? ud.pump.position.z : -.3);
    if (k > .76) { const f = (k - .76) / .24, j = Math.sin(f * Math.PI); ud.pump.position.z = -.3 + j * .13; vm.rotation.x += j * .05; vm.position.z += j * .015; if (k > .84) HAND.z = ud.pump.position.z; }
    return;
  }
  if (st === 'rpg') { // tube dips, warhead comes from the pouch, is carried to the muzzle and rammed home
    const t = sstep(0, .15, k) * (1 - sstep(.85, 1, k));
    vm.rotation.x += t * .55; vm.position.y -= t * .08; vm.position.z += t * .08; vm.rotation.z += t * .12;
    const pts = [[0, [0, -.075, -.28]], [.14, [-.1, -.35, .1]], [.24, [-.14, -.55, .15]], [.3, [-.14, -.55, .15]], [.4, [-.06, -.2, -.5]], [.5, [0, -.02, -1.1]], [.54, [0, -.02, -1.1]], [.66, [0, -.02, -.9]], [.8, [0, -.075, -.28]], [1, [0, -.075, -.28]]];
    HAND.copy(keyed(k, pts));
    ud.war.visible = k > .3;
    if (k > .3 && k < .5) { ud.war.position.copy(HAND).add(_p1.set(0, .06, .0)); }
    else if (k >= .5) { const u = sstep(.54, .66, k); ud.war.position.set(0, 0, lerp(-1.12, ud.warBase.z, u)); ud.war.position.y = lerp(.04, 0, u); }
    if (k > .6 && k < .72) { const j = Math.sin((k - .6) / .12 * Math.PI); vm.position.z += j * .05; vm.rotation.x -= j * .08; }
    return;
  }
  const roll = ROLL[st] || .55, t = sstep(0, .12, k) * (1 - sstep(.88, 1, k));
  vm.position.y -= t * (st === 'mg' ? .12 : .08); vm.rotation.z += t * roll; vm.rotation.x += t * .2; vm.position.x -= t * (st === 'smg' ? .07 : .04); if (st === 'smg') { vm.position.y += t * .12; vm.rotation.y -= t * .3; }
  HAND.copy(keyed(k, ud.hpts));
  const m = ud.mag, b = ud.magBase;
  if (m) {
    const held1 = k > .18 && k < .38, held2 = k >= .46 && k < .7;
    m.visible = !(k >= .38 && k < .46);
    if (held1) { m.position.copy(HAND).add(MAG_O); m.rotation.x = b.rx + sstep(.18, .34, k) * .6; }
    else if (held2) { m.position.copy(HAND).add(MAG_O); m.rotation.x = b.rx + (1 - sstep(.5, .66, k)) * .6; }
    if (ud.dropMag && k > .38 && k < .56) { const q = k - .38, p0 = keyed(.38, ud.hpts); ud.dropMag.visible = true; ud.dropMag.position.set(p0.x + MAG_O.x, p0.y + MAG_O.y - q * q * 11, p0.z + MAG_O.z + q * .35); ud.dropMag.rotation.set(b.rx + 1 + q * 6, 0, q * 4); keyed(k, ud.hpts); }
  }
  if (k > .66 && k < .74) { const j = Math.sin((k - .66) / .08 * Math.PI); vm.position.z += j * .03; vm.position.y += j * .01; }
  if (st === 'bolt' && ud.bolt) {
    const lift = sstep(.74, .8, k) * (1 - sstep(.94, .98, k)), back = sstep(.8, .87, k) * (1 - sstep(.87, .93, k));
    ud.bolt.rotation.z = -lift * 1.1; ud.bolt.position.z = ud.boltBase.z + back * .13;
    if (k > .72 && k < .96) { const bw = lerp(0, 1, sstep(.72, .76, k)) * (1 - sstep(.94, .98, k)); _p2.copy(ud.bolt.position).add(_p3.set(.05, -.012 + lift * .035, .02)); HAND.x = lerp(HAND.x, _p2.x, bw); HAND.y = lerp(HAND.y, _p2.y, bw); HAND.z = lerp(HAND.z, _p2.z, bw); }
    vm.rotation.z -= lift * .08; vm.position.z += back * .02;
  } else if (k > .78 && k < .92) { const j = Math.sin((k - .78) / .14 * Math.PI); vm.position.z += j * .035; vm.rotation.x -= j * .05; }
}


function karaSpin(kind) {
  if (G.state === 'playing' && !P.dead && !P.inTank && kind === 'ins' && WEAPONS[P.cur].id !== 'knife' && P.reload <= 0 && P.swT <= 0 && P.wInsp < 0) { P.wInsp = 0; return; }
  if (G.state !== 'playing' || P.dead || P.inTank || WEAPONS[P.cur].id !== 'knife' || P.swT > 0 || P.kt < .4) return;
  P.kSpin = 0; P.kKind = kind; P.kFlipT = -1; SND.whoosh();
}
function knifeAnim(vm, ud, dt) {
  const piv = ud.piv; piv.rotation.set(0, 0, 0); let curl = 1;
  P.kt += dt; P.kIdle = (P.kt < .6 || P.swT > 0 || P.throwT > 0) ? 0 : P.kIdle + dt;
  if (P.kHit && P.kt > .11) { P.kHit = false; knifeHit(); }
  vm.rotation.x += .1; vm.rotation.y += .12;
  vm.position.y += Math.sin(performance.now() / 700) * .003;
  if (P.swT > 0) P.kSpin = -1;
  if (P.adsHeld && !P.kAdsPrev) karaSpin('ads'); P.kAdsPrev = P.adsHeld;
  if (P.kFlipT < 0 && P.kSpin < 0 && P.kIdle > 4.2) { P.kFlipT = 0; P.kIdle = 0; P.kFlipK = (P.kFlipK + 1) % 3; }
  if (P.kFlipT >= 0) {
    P.kFlipT += dt; const u = P.kFlipT / 1.5; if (u >= 1) P.kFlipT = -1; else {
      const e = sstep(0, 1, u), j = Math.sin(Math.PI * u);
      if (P.kFlipK === 0) { piv.rotation.x -= Math.PI * 4 * e; curl = 1 - sstep(.05, .15, u) * (1 - sstep(.72, .88, u)); vm.position.y += j * .06; vm.position.z += j * .03; }                                     // ring spin around the finger
      else if (P.kFlipK === 1) { vm.rotation.z += Math.PI * 2 * e; vm.rotation.y -= j * .5; vm.position.x -= j * .1; vm.position.y += j * .05; }       // twirl
      else { vm.rotation.x -= Math.PI * 2 * e; vm.rotation.z += Math.PI * 2 * sstep(.3, 1, u); vm.position.y += j * .1; vm.position.x -= j * .06; }       // double flip
    }
  }
  if (P.kSpin >= 0) {
    const ins = P.kKind === 'ins', dur = ins ? (COS.skin ? 3.8 : 3.1) : 1.8; P.kSpin += dt; P.kIdle = 0; const u = P.kSpin / dur;
    if (u >= 1) P.kSpin = -1; else {
      const eo = t => 1 - Math.pow(1 - t, 3);
      if (!ins) {
        // right click: lift the karambit, spin it on the finger ring, then snap it into the grip
        const lift = sstep(0, .14, u) * (1 - sstep(.84, 1, u)), s = eo(clamp((u - .1) / .62, 0, 1));
        vm.position.y += lift * .07; vm.position.z += lift * .05; vm.position.x -= lift * .035;
        piv.rotation.x -= Math.PI * 6 * s; curl = 1 - sstep(.08, .16, u) * (1 - sstep(.66, .78, u)); vm.rotation.z += Math.sin(u * 38) * .07 * lift * (1 - s); vm.position.x += Math.sin(u * 30) * .012 * lift * (1 - s);
        if (u > .72) { const c = (u - .72) / .28; vm.rotation.x += Math.sin(c * Math.PI * 2.5) * Math.exp(-c * 4) * .38; vm.position.z -= Math.sin(Math.min(1, c * 3) * Math.PI) * .05; vm.rotation.z += (1 - sstep(0, .5, c)) * .35 * (1 - c); }
      } else {
        skinInsp(vm, u);
        // inspect: tilt the blade toward the camera, roll it over, ring-spin, then regrip
        const a = sstep(0, .13, u) * (1 - sstep(.9, 1, u)), s = eo(clamp((u - .46) / .34, 0, 1));
        vm.position.y += a * .05; vm.position.z += a * .07; vm.position.x -= a * .02; vm.rotation.y -= a * (1.1 + Math.sin(u * 9) * .08); vm.rotation.z += a * .9;
        vm.rotation.z += sstep(.2, .44, u) * Math.PI * 2; piv.rotation.x -= Math.PI * 4 * s; curl = 1 - sstep(.44, .5, u) * (1 - sstep(.78, .84, u)); vm.position.y += Math.sin(Math.PI * clamp((u - .46) / .34, 0, 1)) * .05;
        if (u > .82) { const c = (u - .82) / .18; vm.rotation.x += Math.sin(c * Math.PI * 2.5) * Math.exp(-c * 4) * .3; vm.position.z -= Math.sin(Math.min(1, c * 3) * Math.PI) * .04; }
      }
    }
  }
  if (P.kt < .36) {
    const u = sstep(0, 1, P.kt / .36), j = Math.sin(Math.PI * u), T = P.ktype;
    if (T === 0) { vm.rotation.y += lerp(.9, -1.2, u); vm.position.x += lerp(.13, -.28, u); vm.rotation.z += lerp(-.6, .5, u); vm.position.z -= j * .13; }
    else if (T === 1) { vm.rotation.y += lerp(-.9, 1.1, u); vm.position.x += lerp(-.22, .22, u); vm.rotation.z += lerp(.6, -.5, u); vm.position.z -= j * .13; }
    else if (T === 2) { vm.rotation.x += lerp(1.0, -1.0, u); vm.position.y += lerp(.16, -.17, u); vm.position.z -= j * .14; vm.rotation.z += j * .3; }
    else { vm.position.z -= j * .3; vm.rotation.x -= j * .2; vm.position.y += j * .02; vm.rotation.y += j * .15; }
  }
  ud.fing.forEach((f, i) => f.rotation.z = (1 - curl) * (1.15 + i * .08)); ud.thumb.rotation.z = (1 - curl) * .55;
}

// ---- rays ----
function rayOBB(o, d, cx, cy, cz, yaw, hx, hy, hz) {
  const c = Math.cos(yaw), s = Math.sin(yaw), ox = o.x - cx, oz = o.z - cz;
  const lo = { x: ox * c - oz * s, y: o.y - cy, z: ox * s + oz * c }, ld = { x: d.x * c - d.z * s, y: d.y, z: d.x * s + d.z * c };
  return rayBox(lo, ld, -hx, -hy, -hz, hx, hy, hz);
}
function castRay(o, d, max, hitPlayer, hitEnemies) {
  let best = max, res = null;
  if (d.y < -1e-6) { const t = -o.y / d.y; if (t > 0 && t < best) { best = t; res = { kind: 'ground', t }; } }
  for (let i = 0; i < colliders.length; i++) { const c = colliders[i], t = rayBox(o, d, c.x0, 0, c.z0, c.x1, c.h, c.z1); if (t !== null && t < best) { best = t; res = { kind: 'world', t, c }; } }
  if (hitEnemies) for (const e of enemies) {
    if (e.dead) continue;
    if (e.type === 'tank') {
      const tc = Math.cos(e.tyaw), ts = Math.sin(e.tyaw);
      let t = rayOBB(o, d, e.x, .7, e.z, e.yaw, 2.4, .75, 3.4);
      if (t !== null && t < best) { best = t; res = { kind: 'enemy', t, e, head: false, part: 'hull' }; }
      t = rayOBB(o, d, e.x - ts * .2, 1.85, e.z - tc * .2, e.tyaw, 1.15, .45, 1.4);
      if (t !== null && t < best) { best = t; res = { kind: 'enemy', t, e, head: false, part: 'turret' }; }
      continue;
    }
    let t = rayCyl(o, d, e.x, e.z, e.hitR, e.y, e.y + e.bodyH);
    if (t !== null && t < best) { best = t; res = { kind: 'enemy', t, e, head: false }; }
    if (e.headR) { t = raySphere(o, d, e.x, e.y + e.headY, e.z, e.headR); if (t !== null && t < best) { best = t; res = { kind: 'enemy', t, e, head: true }; } }
  }
  if (hitPlayer && !P.dead) { const t = P.inTank ? rayCyl(o, d, P.pos.x, P.pos.z, 2.2, 0, 2.4) : rayCyl(o, d, P.pos.x, P.pos.z, .5, P.pos.y, P.pos.y + P.eyeH + .12); if (t !== null && t < best) { best = t; res = { kind: 'player', t }; } }
  return res;
}
function updateAim() {
  const cy = Math.cos(P.yaw), sy = Math.sin(P.yaw), cp = Math.cos(P.pitch), sp = Math.sin(P.pitch);
  P.fwd.set(-sy * cp, sp, -cy * cp); P.right.set(cy, 0, -sy); P.upv.crossVectors(P.right, P.fwd).normalize();
}
const _o = new THREE.Vector3(), _d = new THREE.Vector3();
function coneDir(spread) {
  const a = Math.random() * 6.283, r = Math.sqrt(Math.random()) * spread;
  return _d.copy(P.fwd).addScaledVector(P.right, Math.cos(a) * r).addScaledVector(P.upv, Math.sin(a) * r).normalize();
}
function impactFx(p, res, d) {
  if (res.kind === 'ground') dustPuff(p.x, .1, p.z, 5, C_DUST, 1.1, 2.2);
  else { dustPuff(p.x, p.y, p.z, 4, [.6, .58, .54], .8, 1.5); sparks(p.x - d.x * .05, p.y, p.z - d.z * .05, 4, 4); }
}

// ---- weapons ----
function spreadNow() {
  const w = WS(P.cur), mv = Math.hypot(P.vx, P.vz) / 5.4;
  return (w.spread * (1 + mv * 1.1 + (P.onGround ? 0 : 2) + P.sprintT) + P.bloom) * lerp(1, w.adsMul, P.ads) * (P.stance === 1 ? .78 : P.stance === 2 ? .55 : 1);
}
function knifeHit() {
  const w = WS(P.cur); let hit = false, fx = -Math.sin(P.yaw), fz = -Math.cos(P.yaw);
  for (const e of enemies) { if (e.dead || e.type === 'tank') continue; const dx = e.x - P.pos.x, dz = e.z - P.pos.z, dd = Math.hypot(dx, dz), d = dd - e.hitR; if (d < 2.3 && (dx * fx + dz * fz) / (dd || 1) > .3) { hurtEnemy(e, w.dmg, { from: { x: P.pos.x, z: P.pos.z }, head: false }); bloodPuff(e.x, 1.3, e.z); hitMarker(false, e.dead); hit = true; } }
  if (hit) { P.shake += .18; SND.thump && SND.thump(); }
}
function tryFire() {
  if (P.dead || P.swT > 0 || P.reload > 0 || P.fireT > 0 || P.sprintT > .45) return false;
  const w = WS(P.cur), s = P.ws[P.cur];
  if (w.id === 'knife') { P.kSpin = -1; P.kt = 0; P.ktype = (P.ktype + 1) % 4; P.kHit = true; P.kFlipT = -1; P.fireT = w.rate; SND.whoosh(); return true; }
  if (w.spin && P.spin < .8) return false;
  if (s.ammo <= 0) { if (s.reserve > 0) startReload(); else if (P.dryT <= 0) { P.dryT = .35; SND.click(); } return false; }
  s.ammo--; P.fireT = w.rate;
  updateAim();
  _o.set(P.pos.x, P.pos.y + P.eyeH, P.pos.z);
  const sp = spreadNow(), mx = _o.x + P.fwd.x * .9 + P.right.x * .17, my = _o.y + P.fwd.y * .9 - .13, mz = _o.z + P.fwd.z * .9 + P.right.z * .17;
  if (w.id === 'rpg') {
    spawnRocket(_o.clone().addScaledVector(P.fwd, .8), P.fwd.clone(), 'player'); SND.shot('rpg'); P.shake += .35;
    for (let i = 0; i < 10; i++) smoke.emit(_o.x - P.fwd.x, _o.y - .3, _o.z - P.fwd.z, rand(-1, 1) * 3 - P.fwd.x * 4, rand(-.5, 1), rand(-1, 1) * 3 - P.fwd.z * 4, .8, .5, 2, C_SMOKE1, C_SMOKE1, .5, 0, 0, 2);
  } else {
    const n = w.pellets || 1;
    for (let i = 0; i < n; i++) {
      const d = coneDir(sp).clone(), res = castRay(_o, d, 400, false, true);
      const t = res ? res.t : 400, ex = _o.x + d.x * t, ey = _o.y + d.y * t, ez = _o.z + d.z * t;
      if (i < 4 || n === 1) tracer(mx, my, mz, ex, ey, ez, COS.trc !== null ? COS.trc : (w.tcol || 0xffd48a), 320);
      if (res) {
        if (res.kind === 'enemy') {
          const e = res.e; let dmg = w.dmg * (res.head ? 2.6 : 1);
          if (e.type === 'tank') { dmg *= (res.part === 'turret' ? .35 : .15) * (w.ap ? 2.2 : 1) * (w.splash ? 2 : 1); sparks(ex, ey, ez, 5, 5); } else bloodPuff(ex, ey, ez);
          if (n > 1) dmg *= clamp(1.25 - t / 30, .25, 1);
          hurtEnemy(e, dmg, { head: res.head, from: _o });
          hitMarker(res.head, e.dead);
        } else impactFx({ x: ex, y: ey, z: ez }, res, d);
        if (w.splash) plasmaBurst(ex, ey, ez, w.splash, w.dmg * .55);
      }
    }
    SND.shot(w.quiet ? 'sup' : (w.id === 'smg' || w.id === 'pistol') ? 'rifle' : w.id); P.shake += w.id === 'shotgun' ? .25 : .05;
    P.pitch += w.kick * rand(.7, 1.3) * (1 - P.ads * .4); P.yaw += rand(-.5, .5) * w.kick * .6; P.bloom = Math.min(.05, P.bloom + w.bloom);
  }
  P.rc = Math.min(1, P.rc + (w.id === 'rifle' ? .35 : 1));
  P.flashVM = w.quiet ? .015 : .05; if (!w.quiet) { flashLight.position.set(mx, my, mz); flashT = .05; muzzleFx(mx, my, mz, 1.1); }
  if (w.auto === false) P.semiReady = false;
  if (s.ammo <= 0 && s.reserve > 0 && w.id !== 'rpg') setTimeout(() => { if (!P.dead && G.state === 'playing') startReload(); }, 250);
  hudAmmo(); return true;
}
function plasmaBurst(x, y, z, r, dmg) {
  for (let i = 0; i < 9; i++) { const a = rand(0, 6.28); glow.emit(x, y, z, Math.cos(a) * rand(1, 4), rand(.5, 3), Math.sin(a) * rand(1, 4), rand(.2, .45), .5, .05, [.4, .85, 1], [.1, .3, 1], 1, 0, -1, 1.5); }
  glow.emit(x, y, z, 0, 0, 0, .18, r * .9, r * .2, [.6, .95, 1], [.2, .5, 1], .9, 0, 0, 0);
  for (const e of enemies) { if (e.dead) continue; const d = Math.hypot(e.x - x, e.y + 1 - y, e.z - z) - e.hitR; if (d < r) hurtEnemy(e, dmg * (1 - d / r) * (e.type === 'tank' ? .3 : 1), { boom: true, ix: (e.x - x) * 2, iz: (e.z - z) * 2 }); }
}
function startReload() {
  const w = WS(P.cur), s = P.ws[P.cur];
  if (P.reload > 0 || P.swT > 0 || s.ammo >= w.mag || s.reserve <= 0) return;
  P.reload = w.reload; SND.reload();
}
function finishReload() {
  const w = WS(P.cur), s = P.ws[P.cur], n = Math.min(w.mag - s.ammo, s.reserve);
  s.ammo += n; s.reserve -= n; hudAmmo();
}
function switchWeapon(i) {
  if (i === P.cur || i < 0 || i >= NW || !P.owned[i] || P.dead || P.swT > 0) return;
  P.nextWeap = i; P.swT = .45; P.reload = 0;
}
function throwGrenade() {
  if (P.gren <= 0 || P.grenT > 0 || P.dead) return;
  P.gren--; P.grenT = 1; P.throwT = .4; updateAim(); SND.gren();
  const m = new THREE.Mesh(CY(.05, .13, 8), vmM.green); scene.add(m);
  const v = P.fwd.clone().multiplyScalar(17).add(new THREE.Vector3(0, 4.5, 0)); v.x += P.vx * .5; v.z += P.vz * .5;
  proj.push({ kind: 'gren', mesh: m, pos: new THREE.Vector3(P.pos.x, P.pos.y + P.eyeH - .1, P.pos.z).addScaledVector(P.fwd, .6), vel: v, t: 2.3, owner: 'player' });
  hudAmmo();
}

function throwMolotov() {
  if (P.molo <= 0 || P.grenT > 0 || P.dead) return;
  P.molo--; P.grenT = 1; P.throwT = .4; updateAim(); SND.gren();
  const m = new THREE.Mesh(CY(.05, .22, 8), new THREE.MeshStandardMaterial({ color: 0x4a6a3a, roughness: .3 })); scene.add(m);
  const v = P.fwd.clone().multiplyScalar(15).add(new THREE.Vector3(0, 4, 0)); v.x += P.vx * .5; v.z += P.vz * .5;
  proj.push({ kind: 'molo', mesh: m, pos: new THREE.Vector3(P.pos.x, P.pos.y + P.eyeH - .1, P.pos.z).addScaledVector(P.fwd, .6), vel: v, t: 3, owner: 'player' });
  hudAmmo();
}
const fires = [];
function startFire(x, z) { fires.push({ x, z, r: 4.2, t: 7 + 2.5 * P.up.molo, m: 1 + .25 * P.up.molo }); SND.boom(x, z, false); boomLight.position.set(x, 1.5, z); boomT = .3; for (let i = 0; i < 20; i++) { const a = rand(0, 6.28), r = rand(0, 3); glow.emit(x + Math.cos(a) * r, .3, z + Math.sin(a) * r, 0, rand(2, 5), 0, rand(.5, 1), 1.2, .2, C_FIRE0, C_FIRE1, .9, 0, -1, .5); } }
function updateFires(dt) {
  for (let i = fires.length - 1; i >= 0; i--) {
    const f = fires[i]; f.t -= dt;
    for (let k = 0; k < 5; k++) { const a = rand(0, 6.28), r = Math.sqrt(Math.random()) * f.r; glow.emit(f.x + Math.cos(a) * r, .15, f.z + Math.sin(a) * r, 0, rand(1, 2.6), 0, rand(.4, .8), 1, .15, C_FIRE0, C_FIRE1, .8, 0, -1, .4); }
    if (Math.random() < dt * 8) smoke.emit(f.x + rand(-2, 2), .5, f.z + rand(-2, 2), 0, rand(1.5, 3), 0, 2.5, .8, 3, C_SMOKE0, C_SMOKE1, .4, 0, -.2, .3);
    for (const e of enemies) if (!e.dead && Math.hypot(e.x - f.x, e.z - f.z) < f.r + e.hitR) hurtEnemy(e, (e.type === 'tank' ? 15 : 42) * dt * P.dmgMult * f.m, {});
    if (!P.dead && Math.hypot(P.pos.x - f.x, P.pos.z - f.z) < f.r) damagePlayer(14 * dt);
    if (f.t <= 0) fires.splice(i, 1);
  }
}
// ---- hold-to-aim previews (grenade / molotov arc, airstrike marker) ----
const AIM = { kind: null, tx: 0, tz: 0, ok: false }, AIM_N = 64, aimPos = new Float32Array(AIM_N * 3), aimGeo = new THREE.BufferGeometry();
aimGeo.setAttribute('position', new THREE.BufferAttribute(aimPos, 3));
const aimLine = new THREE.Line(aimGeo, new THREE.LineBasicMaterial({ color: 0xffe27a, transparent: true, opacity: .95, fog: false, depthTest: false })); aimLine.frustumCulled = false; aimLine.visible = false; aimLine.renderOrder = 5; scene.add(aimLine);
const aimRing = new THREE.Mesh(new THREE.RingGeometry(.86, 1, 48).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: 0xff5030, transparent: true, opacity: .85, side: THREE.DoubleSide, depthWrite: false, fog: false })); aimRing.frustumCulled = false; aimRing.visible = false; scene.add(aimRing);
const aimDot = new THREE.Mesh(new THREE.CircleGeometry(.14, 16).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: 0xffe27a, transparent: true, opacity: .9, fog: false, depthWrite: false })); aimDot.visible = false; scene.add(aimDot);
function aimHide() { aimLine.visible = aimRing.visible = aimDot.visible = false; }
function aimBegin(kind) {
  if (G.state !== 'playing' || P.dead || P.inTank || AIM.kind) return;
  if (kind === 'gren' && (P.gren <= 0 || P.grenT > 0)) return; if (kind === 'molo' && (P.molo <= 0 || P.grenT > 0)) return; if (kind === 'air' && P.air <= 0) { hint('Hava saldırın kalmadı'); setTimeout(() => hint(''), 1200); return; }
  AIM.kind = kind; AIM.ok = false;
}
function aimEnd() {
  const k = AIM.kind; AIM.kind = null; aimHide(); if (k === 'air') hint(''); if (!k || G.state !== 'playing' || P.dead || P.inTank) return;
  if (k === 'gren') throwGrenade(); else if (k === 'molo') throwMolotov(); else if (k === 'air') useAirstrike(AIM.ok ? AIM.tx : undefined, AIM.tz);
}
function aimUpdate(dt) {
  if (!AIM.kind) return;
  if (G.state !== 'playing' || P.dead || P.inTank) { AIM.kind = null; aimHide(); return; }
  updateAim(); const k = AIM.kind, tt = performance.now() / 1000;
  if (k === 'air') {
    const o = { x: P.pos.x, y: P.pos.y + P.eyeH, z: P.pos.z }, r = castRay(o, P.fwd, 160, false, false), t = r ? r.t : 60;
    AIM.tx = o.x + P.fwd.x * t; AIM.tz = o.z + P.fwd.z * t; AIM.ok = true; aimLine.visible = false;
    aimRing.visible = aimDot.visible = true; aimRing.position.set(AIM.tx, .15, AIM.tz); aimDot.position.set(AIM.tx, .16, AIM.tz); aimRing.scale.setScalar(19 + Math.sin(tt * 6) * 1.2); aimRing.material.color.setHex(0xff3a24);
    const nm = hintAir(P.pos.x - AIM.tx, P.pos.z - AIM.tz); if (nm) hint(nm); return;
  }
  const sp = k === 'gren' ? [17, 4.5] : [15, 4], pos = new THREE.Vector3(P.pos.x, P.pos.y + P.eyeH - .1, P.pos.z).addScaledVector(P.fwd, .6), vel = P.fwd.clone().multiplyScalar(sp[0]).add(new THREE.Vector3(0, sp[1], 0)); vel.x += P.vx * .5; vel.z += P.vz * .5;
  let n = 0, end = false; const h = .035;
  for (; n < AIM_N; n++) {
    aimPos[n * 3] = pos.x; aimPos[n * 3 + 1] = pos.y; aimPos[n * 3 + 2] = pos.z; if (end) continue;
    vel.y -= 18 * h; pos.addScaledVector(vel, h);
    if (pos.y < .12) { pos.y = .12; end = true; }
    else for (const c of colliders) if (pos.y < c.h && pos.x > c.x0 - .1 && pos.x < c.x1 + .1 && pos.z > c.z0 - .1 && pos.z < c.z1 + .1) { end = true; break; }
  }
  aimGeo.attributes.position.needsUpdate = true; aimLine.visible = true; aimLine.material.color.setHex(k === 'gren' ? 0xffe27a : 0xffa040);
  aimRing.visible = aimDot.visible = true; aimRing.position.set(pos.x, .12, pos.z); aimDot.position.set(pos.x, .13, pos.z); aimRing.scale.setScalar(k === 'gren' ? 8 : 4.2); aimRing.material.color.setHex(k === 'gren' ? 0xff4030 : 0xff8a20);
}
function hintAir(dx, dz) { const d = Math.hypot(dx, dz); return d < 22 ? 'DİKKAT: hedef çok yakın! (' + Math.round(d) + ' m)' : ''; }
// ---- airstrike: bomber flyover ----
const strikes = [], sbombs = [];
function buildBomber() {
  const g = new THREE.Group(), m = new THREE.MeshStandardMaterial({ color: 0x5b6068, metalness: .5, roughness: .5 }), d = new THREE.MeshStandardMaterial({ color: 0x24272b, metalness: .3, roughness: .6 });
  const add = (w, h, dd, mat, x, y, z, ry) => { const q = new THREE.Mesh(new THREE.BoxGeometry(w, h, dd), mat); q.position.set(x, y, z); if (ry) q.rotation.y = ry; g.add(q); return q; };
  add(2.4, 2.2, 22, m, 0, 0, 0); add(1.6, 1.4, 5, d, 0, .3, -12); add(30, .35, 5.5, m, 0, -.3, 1); add(11, .3, 3, m, 0, .3, 9.5); add(.3, 4, 3.4, m, 0, 2.2, 9.6);
  for (const x of [-5, 5]) { add(1.5, 1.5, 4.5, d, x, -1.2, -1); const gl = new THREE.Sprite(new THREE.SpriteMaterial({ map: TEX_SOFT, color: 0xffa050, blending: THREE.AdditiveBlending, transparent: true, depthWrite: false, fog: false })); gl.scale.setScalar(5); gl.position.set(x, -1.2, 2.6); g.add(gl); }
  g.scale.setScalar(1.15); return g;
}
function useAirstrike(tx, tz) {
  if (P.air <= 0 || P.dead) return;
  if (tx === undefined) { updateAim(); const o = { x: P.pos.x, y: P.pos.y + P.eyeH, z: P.pos.z }, r = castRay(o, P.fwd, 160, false, false), t = r ? r.t : 60; tx = o.x + P.fwd.x * t; tz = o.z + P.fwd.z * t; }
  P.air--; hudAmmo(); message('HAVA SALDIRISI', 'ÇEKİL! BOMBARDIMAN UÇAĞI YOLDA'); SND.alert(); if (SND.jet) SND.jet();
  for (let i = 0; i < 40; i++) smoke.emit(tx, .2, tz, rand(-1, 1), rand(8, 14), rand(-1, 1), rand(3, 5), .6, 2.5, [1, .15, .1], [1, .3, .2], .8, 0, 0, .3);
  const ang = rand(0, 6.283), dx = Math.cos(ang), dz = Math.sin(ang), V = 120, Y = 58, T = Math.sqrt(2 * (Y - .5) / 18), L = V * T + 230;
  const g = buildBomber(); g.rotation.y = Math.atan2(-dx, -dz); scene.add(g);
  const ring = new THREE.Mesh(new THREE.RingGeometry(.9, 1, 48).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: 0xff3a24, transparent: true, opacity: .8, side: THREE.DoubleSide, depthWrite: false, fog: false })); ring.position.set(tx, .15, tz); ring.scale.setScalar(19); scene.add(ring);
  const bombs = []; for (let i = 0; i < 16; i++) bombs.push({ s: L - V * T + (i - 7.5) * 5.2, lat: rand(-7, 7) });
  strikes.push({ g, ring, tx, tz, dx, dz, V, Y, T, L, t: 0, bombs, bi: 0 });
}
function updateStrikes(dt) {
  for (let i = strikes.length - 1; i >= 0; i--) {
    const s = strikes[i]; s.t += dt; const d = s.V * s.t;
    s.g.position.set(s.tx - s.dx * s.L + s.dx * d, s.Y, s.tz - s.dz * s.L + s.dz * d); s.g.rotation.z = Math.sin(s.t * 1.7) * .04;
    s.ring.scale.setScalar(19 + Math.sin(s.t * 6) * 1.2); s.ring.material.opacity = .45 + .35 * Math.sin(s.t * 8) ** 2;
    while (s.bi < s.bombs.length && d >= s.bombs[s.bi].s) {
      const b = s.bombs[s.bi++], m = new THREE.Mesh(CY(.22, .8, 8), new THREE.MeshStandardMaterial({ color: 0x2c3036, metalness: .5, roughness: .5 })); m.position.copy(s.g.position); m.position.y -= 1.6; scene.add(m);
      sbombs.push({ m, pos: m.position.clone(), vel: new THREE.Vector3(s.dx * s.V - s.dz * b.lat / s.T, -2, s.dz * s.V + s.dx * b.lat / s.T) }); if (s.bi === 1) SND.whoosh();
    }
    if (d > s.L + 320) { scene.remove(s.g); scene.remove(s.ring); strikes.splice(i, 1); }
  }
  for (let i = sbombs.length - 1; i >= 0; i--) {
    const b = sbombs[i]; b.vel.y -= 18 * dt; b.pos.addScaledVector(b.vel, dt); b.m.position.copy(b.pos); b.m.rotation.x = Math.atan2(-b.vel.y, Math.hypot(b.vel.x, b.vel.z)); b.m.rotation.y = Math.atan2(b.vel.x, b.vel.z);
    if (b.pos.y <= .5) { scene.remove(b.m); sbombs.splice(i, 1); explode(b.pos.x, .5, b.pos.z, 8, 300 * P.dmgMult, 'player'); }
  }
}
function clearStrikes() { for (const s of strikes) { scene.remove(s.g); scene.remove(s.ring); } strikes.length = 0; for (const b of sbombs) scene.remove(b.m); sbombs.length = 0; AIM.kind = null; aimHide(); }

// ---- projectiles ----
function spawnRocket(pos, dir, owner, speed, big) {
  const m = new THREE.Group();
  const b = new THREE.Mesh(CY(big ? .12 : .06, big ? .9 : .6, 8).rotateX(Math.PI / 2), vmM.green); m.add(b);
  const tip = new THREE.Mesh(new THREE.ConeGeometry(big ? .12 : .06, .25, 8).rotateX(-Math.PI / 2), vmM.gun); tip.position.z = big ? .55 : .4; m.add(tip);
  m.position.copy(pos); m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), dir); scene.add(m);
  proj.push({ kind: big ? (owner === 'player' ? 'pshell' : 'shell') : 'rocket', mesh: m, pos: pos.clone(), vel: dir.clone().multiplyScalar(speed || 70), t: 6, owner });
}
function updateProjectiles(dt) {
  for (let i = proj.length - 1; i >= 0; i--) {
    const p = proj[i]; p.t -= dt; let boom = false, bp = null;
    if (p.kind === 'gren' || p.kind === 'molo') {
      p.vel.y -= 18 * dt; p.pos.addScaledVector(p.vel, dt);
      if (p.pos.y < .12) { p.pos.y = .12; p.vel.y = Math.abs(p.vel.y) * .35; p.vel.x *= .7; p.vel.z *= .7; if (p.vel.y < 1) p.vel.y = 0; }
      for (const c of colliders) if (p.pos.y < c.h && p.pos.x > c.x0 - .1 && p.pos.x < c.x1 + .1 && p.pos.z > c.z0 - .1 && p.pos.z < c.z1 + .1) {
        const l = p.pos.x - c.x0, r = c.x1 - p.pos.x, t = p.pos.z - c.z0, b = c.z1 - p.pos.z, m = Math.min(l, r, t, b);
        if (m === l) { p.pos.x = c.x0 - .1; p.vel.x = -Math.abs(p.vel.x) * .4; } else if (m === r) { p.pos.x = c.x1 + .1; p.vel.x = Math.abs(p.vel.x) * .4; }
        else if (m === t) { p.pos.z = c.z0 - .1; p.vel.z = -Math.abs(p.vel.z) * .4; } else { p.pos.z = c.z1 + .1; p.vel.z = Math.abs(p.vel.z) * .4; }
      }
      p.mesh.position.copy(p.pos); p.mesh.rotation.x += dt * 8;
      if (p.t <= 0 || (p.kind === 'molo' && p.pos.y <= .13)) { boom = true; bp = p.pos; }
    } else {
      const step = p.vel.length() * dt, d = p.vel.clone().normalize();
      const res = castRay(p.pos, d, step, p.owner === 'enemy', p.owner === 'player');
      if (res) { boom = true; bp = p.pos.clone().addScaledVector(d, Math.max(0, res.t - .3)); }
      else {
        p.pos.addScaledVector(p.vel, dt); p.mesh.position.copy(p.pos);
        if (p.owner === 'player') for (const e of enemies) { if (e.dead) continue; if (Math.hypot(e.x - p.pos.x, e.y + 1 - p.pos.y, e.z - p.pos.z) < (e.type === 'tank' ? 3.4 : 1.3)) { boom = true; bp = p.pos.clone(); break; } }
      }
      smoke.emit(p.pos.x, p.pos.y, p.pos.z, rand(-.3, .3), rand(-.3, .3), rand(-.3, .3), 1.4, .3, 1.4, C_SMOKE1, C_SMOKE1, .45, 0, 0, 1);
      glow.emit(p.pos.x, p.pos.y, p.pos.z, 0, 0, 0, .15, .6, .1, C_FIRE0, C_FIRE1, 1, 0, 0, 0);
      if (p.t <= 0) { boom = true; bp = p.pos; }
    }
    if (boom) {
      scene.remove(p.mesh); proj.splice(i, 1);
      if (p.kind === 'gren') explode(bp.x, bp.y, bp.z, 8, 150 * (1 + .25 * P.up.gren) * P.dmgMult, 'player');
      else if (p.kind === 'rocket') explode(bp.x, bp.y, bp.z, 7, 260 * P.dmgMult, 'player');
      else if (p.kind === 'pshell') explode(bp.x, bp.y, bp.z, p.ap ? 3.5 : 7, (p.ap ? 420 : 230) * (p.dm || 1) * P.dmgMult, 'player');
      else if (p.kind === 'molo') startFire(bp.x, bp.z);
      else explode(bp.x, bp.y, bp.z, 6, 40, 'enemy');
    }
  }
}
function explode(x, y, z, radius, dmg, src) {
  const big = radius >= 7;
  for (let i = 0; i < 34; i++) { const a = rand(0, 6.28), s = rand(1, 7) * radius / 5; glow.emit(x, y + .3, z, Math.cos(a) * s, rand(.5, 6), Math.sin(a) * s, rand(.4, .9), radius * .5, radius * .15, C_FIRE0, C_FIRE1, 1, 0, -1, 2); }
  for (let i = 0; i < 26; i++) { const a = rand(0, 6.28), s = rand(1, 4); smoke.emit(x, y + .5, z, Math.cos(a) * s, rand(1, 5), Math.sin(a) * s, rand(2, 4), 1.5, radius * 1.1, C_SMOKE0, C_SMOKE1, .6, 0, -.8, .9); }
  for (let i = 0; i < 24; i++) { const a = rand(0, 6.28), s = rand(4, 14); smoke.emit(x, y + .2, z, Math.cos(a) * s, rand(4, 12), Math.sin(a) * s, rand(1, 1.8), .18, .12, [.15, .12, .1], [.15, .12, .1], 1, 1, 18, .2); }
  for (let i = 0; i < 20; i++) { const a = i / 20 * 6.28; smoke.emit(x, .3, z, Math.cos(a) * radius * 1.2, .5, Math.sin(a) * radius * 1.2, .9, 1.5, 3.5, C_DUST, C_DUST, .5, 0, 0, 3.5); }
  boomLight.position.set(x, y + 1.5, z); boomT = .5;
  if (y < 2) scorch(x, z, radius * 1.1);
  SND.boom(x, z, big);
  const dp = Math.hypot(x - P.pos.x, z - P.pos.z); P.shake = Math.max(P.shake, clamp(1.6 - dp / 28, 0, 1.6));
  for (const e of enemies) {
    if (e.dead || src === 'enemy') continue;
    const d = Math.max(0, Math.hypot(e.x - x, e.y + 1 - y, e.z - z) - e.hitR);
    if (d < radius) {
      let f = 1 - d / radius; if (blocked(x, Math.max(y, .8), z, e.x, e.y + 1, e.z)) f *= .4;
      const dx = e.x - x, dz = e.z - z, l = Math.hypot(dx, dz) + .01;
      hurtEnemy(e, dmg * f, { boom: true, ix: dx / l * 9 * f, iz: dz / l * 9 * f });
      hitMarker(false, e.dead);
    }
  }
  const d = Math.hypot(P.pos.x - x, P.pos.y + 1 - y, P.pos.z - z);
  if (d < radius && !P.dead && dmg > 0) {
    let f = 1 - d / radius; if (blocked(x, Math.max(y, .8), z, P.pos.x, P.pos.y + 1, P.pos.z)) f *= .4;
    damagePlayer(dmg * f * (src === 'player' ? .5 : DIFF.dmg), x, z);
  }
}

// ---- pickups ----
const pkMat = { ammo: new THREE.MeshStandardMaterial({ color: 0x55633a, roughness: .8 }), med: new THREE.MeshStandardMaterial({ color: 0xe8e4d8, roughness: .8 }), armor: new THREE.MeshStandardMaterial({ color: 0x3f6fa8, roughness: .6 }), cash: new THREE.MeshStandardMaterial({ color: 0x3f8a3a, roughness: .5 }), cross: new THREE.MeshBasicMaterial({ color: 0xd83a2a }), band: new THREE.MeshBasicMaterial({ color: 0xe8b33a }) };
function dropPickup(x, z, type) {
  const g = new THREE.Group(), body = new THREE.Mesh(BX(.7, .45, .45), type === 'med' ? pkMat.med : type === 'armor' ? pkMat.armor : type === 'cash' ? pkMat.cash : pkMat.ammo); body.castShadow = true; g.add(body);
  if (type === 'med') { g.add(new THREE.Mesh(BX(.5, .06, .14), pkMat.cross).translateY(.24)); g.add(new THREE.Mesh(BX(.14, .06, .5), pkMat.cross).translateY(.24)); }
  else g.add(new THREE.Mesh(BX(.12, .47, .47), pkMat.band));
  const beam = new THREE.Mesh(new THREE.CylinderGeometry(.35, .35, 6, 10, 1, true), new THREE.MeshBasicMaterial({ color: type === 'med' ? 0xff5a4a : type === 'armor' ? 0x5aa8ff : type === 'cash' ? 0x66ff77 : 0xbfe070, transparent: true, opacity: .22, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide }));
  beam.position.y = 3; g.add(beam);
  g.position.set(x, .6, z); scene.add(g); pickups.push({ g, type, x, z, t: 45, ph: Math.random() * 6 });
}
function updatePickups(dt) {
  for (let i = pickups.length - 1; i >= 0; i--) {
    const k = pickups[i]; k.t -= dt; k.ph += dt * 2; k.g.position.y = .6 + Math.sin(k.ph) * .12; k.g.rotation.y += dt;
    k.g.visible = k.t > 8 || Math.floor(k.t * 5) % 2 === 0;
    const mr = [0, 7, 11, 16][P.up.mag];
    if (mr && !P.dead) { const dx = P.pos.x - k.x, dz = P.pos.z - k.z, d = Math.hypot(dx, dz); if (d < mr && d > .6) { const st = Math.min(d, (12 + (mr - d)) * dt); k.x += dx / d * st; k.z += dz / d * st; k.g.position.x = k.x; k.g.position.z = k.z; } }
    if (!P.dead && Math.hypot(P.pos.x - k.x, P.pos.z - k.z) < 1.7) {
      if (k.type === 'cash') { const c = randi(40, 140); P.money += c; feedLine('+$' + c, ''); hudAmmo(); }
      else if (k.type === 'med') { P.hp = Math.min(P.maxHp, P.hp + 40); feedLine('+40 SAĞLIK', ''); hudHealth(); }
      else if (k.type === 'armor') { P.armor = Math.min(P.maxArmor, P.armor + 50); feedLine('+50 ZIRH', ''); hudHealth(); }
      else { if (ggOn() && P.ggArch >= 0 && P.ggArch !== 8) { P.ws[P.ggArch].reserve += Math.ceil(WS(P.ggArch).mag * 2); } P.ws[0].reserve += 60; P.ws[1].reserve += 8; if (P.owned[3]) P.ws[3].reserve += 40; if (P.owned[4]) P.ws[4].reserve += 5; if (P.owned[5]) P.ws[5].reserve += 120; if (P.owned[6]) P.ws[6].reserve += 30; if (Math.random() < .5) P.ws[2].reserve += 1; P.gren = Math.min(6, P.gren + 1); feedLine('CEPHANE ALINDI', ''); hudAmmo(); }
      SND.pickup(); k.t = 0;
    }
    if (k.t <= 0) { scene.remove(k.g); pickups.splice(i, 1); }
  }
}

// ---- loot crates (press E) ----
let merchant = null;
const lootBoxes = [], lootMat = new THREE.MeshStandardMaterial({ color: 0x8a6a2a, roughness: .6, metalness: .3 }), lootBand = new THREE.MeshBasicMaterial({ color: 0xffc040 });
function spawnLoot(n) {
  for (let i = 0; i < n; i++) {
    let x = 0, z = 0, ok = false;
    for (let t = 0; t < 40 && !ok; t++) { const a = rand(0, 6.283), r = rand(10, 85); x = Math.cos(a) * r; z = Math.sin(a) * r; ok = free(x, z, 1.5) || colliders.every(c => !(x > c.x0 - 1.2 && x < c.x1 + 1.2 && z > c.z0 - 1.2 && z < c.z1 + 1.2)); }
    if (!ok) continue;
    const g = new THREE.Group(), b = new THREE.Mesh(BX(.9, .6, .6), lootMat); b.castShadow = true; g.add(b);
    g.add(new THREE.Mesh(BX(.12, .62, .62), lootBand)); const lid = new THREE.Mesh(BX(.92, .12, .62), lootBand); lid.position.y = .36; g.add(lid);
    const beam = new THREE.Mesh(new THREE.CylinderGeometry(.4, .4, 8, 10, 1, true), new THREE.MeshBasicMaterial({ color: 0xffc040, transparent: true, opacity: .25, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide })); beam.position.y = 4; g.add(beam);
    g.position.set(x, .3, z); g.rotation.y = rand(0, 6); scene.add(g); lootBoxes.push({ g, x, z });
  }
}
function openLoot(k) {
  scene.remove(k.g); lootBoxes.splice(lootBoxes.indexOf(k), 1); SND.pickup();
  const pool = ['med', 'ammo', 'ammo', 'armor', 'med', 'cash', 'cash', 'armor'], n = randi(2, 4);
  for (let i = 0; i < n; i++) { const a = i / n * 6.283 + rand(0, 1); dropPickup(k.x + Math.cos(a) * 1.4, k.z + Math.sin(a) * 1.4, pool[randi(0, pool.length - 1)]); }
  if (Math.random() < .5) P.gren = Math.min(6, P.gren + 1); feedLine('SANDIK AÇILDI', ''); hudAmmo();
}
function updateLoot(dt) {
  let near = null; updateAirdrop(dt);
  for (const k of lootBoxes) { k.g.rotation.y += dt * .4; if (Math.hypot(P.pos.x - k.x, P.pos.z - k.z) < (isTouch ? 2 : 2.6)) near = k; }
  if (near && isTouch) { openLoot(near); near = null; }
  if (P.dropNear && isTouch) openAirdrop();
  const mn = merchant && Math.hypot(P.pos.x - merchant.x, P.pos.z - merchant.z) < 3.4;
  if (mn && isTouch && !P.shopAuto) { P.shopAuto = true; openShop(); } if (!mn) P.shopAuto = false;
  P.merchNear = !!mn;
  hint(P.dead ? '' : P.inTank ? 'WASD sür · SOL TIK top · SAĞ TIK makineli · E çık' : mn ? 'E : TÜCCARLA KONUŞ' : P.dropNear ? 'E : İKRAM KUTUSUNU AÇ' : near ? 'E : SANDIĞI AÇ' : tankNear() ? 'E : TANKA BİN' : ''); P.lootNear = near;
}
function clearLoot() { for (const k of lootBoxes) scene.remove(k.g); lootBoxes.length = 0; clearAirdrop(); }

// ---- input ----
const K = {}, touchIn = { mx: 0, my: 0 }, mouse = { nx: 0, ny: 0, lock: false, free: false };
let lookDX = 0, lookDY = 0;

// ---- player update ----
function doCrouch() {
  if (P.inTank || !P.onGround || P.dead) return;
  if (P.slideT > 0) return;
  if (P.sprintT > .6 && P.stance === 0 && Math.hypot(P.vx, P.vz) > 5) { // slide
    const l = Math.hypot(P.vx, P.vz); P.slideT = 1.4; P.slideDx = P.vx / l; P.slideDz = P.vz / l; P.stance = 1; SND.land(); P.shake += .1; return;
  }
  P.stance = P.stance === 1 ? 0 : 1;
}
function updatePlayer(dt) {
  updateAim(); if (P.boostT > 0) { P.boostT -= dt; if (P.boostT <= 0) { recomputeStats(); feedLine('HASAR GÜÇLENDİRİCİ BİTTİ', ''); } }
  if (P.dead) {
    reloadBar(-1); if (P.deadT === 0) { P.deadRoll = Math.random() < .5 ? -1 : 1; P.deadP0 = P.pitch; P.deadH = P.eyeH; P.hurtT = 0; }
    P.deadT += dt; const t = P.deadT, k = Math.min(1, t / 1.15), ek = 1 - Math.pow(1 - k, 3), bounce = Math.max(0, Math.sin((t - 1.05) * 11)) * .06 * Math.exp(-(t - 1.05) * 5) * (t > 1.05 ? 1 : 0);
    // knees give way, the body drops backwards and the last thing seen is the sky
    const cx = P.pos.x + P.fwd.x * -.9 * ek, cz = P.pos.z + P.fwd.z * -.9 * ek, cy = P.pos.y + lerp(P.deadH, .28, ek) + bounce + Math.sin(k * Math.PI) * .12;
    camera.position.set(cx, cy, cz); P.pitch = lerp(P.deadP0, .95, ek); camera.rotation.set(P.pitch + Math.sin(t * 2.2) * .02 * ek, P.yaw + P.deadRoll * ek * .35, P.deadRoll * ek * .45);
    canvas.style.filter = 'grayscale(' + Math.min(.9, t * .6).toFixed(2) + ') contrast(1.12) brightness(' + (1 - Math.min(.5, Math.max(0, t - 2.2) * .5)).toFixed(2) + ')';
    const fd = $('fade'); fd.style.transition = 'none'; fd.style.opacity = clamp((t - 2.6) / 1.0, 0, 1);
    const dvm = VMS[P.cur], dud = dvm.userData; VMS.forEach((m, i) => m.visible = i === P.cur && t < 1.3); LH.visible = t < 1.3;
    if (t < 1.3) { dvm.position.copy(dud.hip); dvm.rotation.set(0, 0, 0); resetParts(dud); const kk = Math.min(1, t / .8); dvm.position.y -= kk * kk * .9; dvm.position.x += kk * .3; dvm.rotation.x += kk * 1.3; dvm.rotation.z += kk * .9; HAND.copy(dud.lh); placeLeftHand(dvm); vmCam.fov = 58; vmCam.updateProjectionMatrix(); }
    if (P.deadT > 3.6 && G.state === 'playing') { if (G.arena) respawnPlayer(); else gameOver(); } return;
  }
  if (P.inTank && PT) { tankDrive(dt); return; }
  const w = WS(P.cur);
  P.eyeH = lerp(P.eyeH, P.slideT > 0 ? .78 : [EYE, 1.12, .5][P.stance], Math.min(1, dt * 12));
  if (P.throwT > 0) P.throwT -= dt;
  if (mouse.free && !isTouch) { P.yaw -= (Math.abs(mouse.nx) > .12 ? mouse.nx : 0) * 2.8 * dt; P.pitch -= (Math.abs(mouse.ny) > .12 ? mouse.ny : 0) * 1.8 * dt; }
  P.yaw -= lookDX; P.pitch -= lookDY; lookDX = lookDY = 0; P.pitch = clamp(P.pitch, -1.45, 1.45);
  P.fireT = Math.max(0, P.fireT - dt); P.dryT = Math.max(0, P.dryT - dt); P.grenT = Math.max(0, P.grenT - dt); P.hurtT = Math.max(0, P.hurtT - dt);
  P.bloom = Math.max(0, P.bloom - dt * .05); P.rc = Math.max(0, P.rc - dt * 7); P.shake = Math.max(0, P.shake - dt * 3);
  P.flashVM = Math.max(0, P.flashVM - dt);
  if (P.reload > 0) { P.reload -= dt; if (P.reload <= 0) finishReload(); }
  if (P.swT > 0) { const was = P.swT; P.swT -= dt; if (was > .22 && P.swT <= .22) { P.cur = P.nextWeap; hudAmmo(); } }
  const adsWant = (P.adsHeld && P.reload <= 0 && P.swT <= 0) ? 1 : 0; P.ads = lerp(P.ads, adsWant, Math.min(1, dt * 12));
  // move
  const fi = (K.KeyW || K.ArrowUp ? 1 : 0) - (K.KeyS || K.ArrowDown ? 1 : 0) - touchIn.my, si = (K.KeyD || K.ArrowRight ? 1 : 0) - (K.KeyA || K.ArrowLeft ? 1 : 0) + touchIn.mx;
  let wx = -Math.sin(P.yaw) * fi + Math.cos(P.yaw) * si, wz = -Math.cos(P.yaw) * fi - Math.sin(P.yaw) * si; const wl = Math.hypot(wx, wz); if (wl > 1) { wx /= wl; wz /= wl; }
  P.sprint = !!(K.ShiftLeft || K.ShiftRight || touchIn.my < -.92) && fi > 0 && P.ads < .3 && P.stance === 0 && !P.trigger && P.swT <= 0;
  P.sprintT = lerp(P.sprintT, P.sprint ? 1 : 0, Math.min(1, dt * (P.sprint ? 9 : 15)));
  const spd = (P.sprint ? 8.4 : (P.ads > .5 ? 3 : 5.4)) * [1, .55, .28][P.stance] * (1 + .08 * P.up.spd) * (w.spin && P.spin > .3 ? .55 : 1), ac = P.onGround ? 11 : 2.5;
  if (P.slideT > 0) {
    P.slideT -= dt; const u = Math.max(0, P.slideT / 1.4), sl = 3 + 14 * Math.pow(u, 1.5);
    if (K.Space || !P.onGround) { if (K.Space && P.slideT > .3) { P.vy = 5.2; P.onGround = false; P.stance = 0; } P.slideT = 0; }
    const sd = si * dt * .9; const c = Math.cos(sd), s = Math.sin(sd), nx = P.slideDx * c - P.slideDz * s; P.slideDz = P.slideDx * s + P.slideDz * c; P.slideDx = nx;
    P.vx = P.slideDx * sl; P.vz = P.slideDz * sl; if (Math.random() < dt * 28) dustPuff(P.pos.x - P.slideDx * .4, .1, P.pos.z - P.slideDz * .4, 1, C_DUST, .9, 1.6);
  } else {
    P.vx += (wx * spd - P.vx) * Math.min(1, dt * ac); P.vz += (wz * spd - P.vz) * Math.min(1, dt * ac);
  }
  P.slideRoll = lerp(P.slideRoll, P.slideT > 0 ? 1 : 0, Math.min(1, dt * 10));
  moveEntity(P.pos, P.vx * dt, P.vz * dt, .42, P.pos.y);
  if (K.Space && P.onGround) { if (P.stance > 0) { P.stance = 0; K.Space = false; } else { P.vy = 6.4; P.onGround = false; } }
  P.vy -= 19 * dt; P.pos.y += P.vy * dt;
  const gh = groundAt(P.pos.x, P.pos.z, P.pos.y);
  if (P.pos.y <= gh) { if (!P.onGround && P.vy < -5) { SND.land(); P.shake += .12; } P.pos.y = gh; P.vy = 0; P.onGround = true; } else P.onGround = false;
  const sp = Math.hypot(P.vx, P.vz);
  if (P.onGround && sp > 1) { P.stepD += sp * dt; P.bobT += sp * dt * 1.5; if (P.stepD > (P.sprint ? 2.4 : 1.9)) { P.stepD = 0; SND.step(); } }
  // minigun barrels spin up while the trigger is held
  if (w.spin) P.spin += clamp((P.trigger && P.reload <= 0 && P.swT <= 0 && P.ws[P.cur].ammo > 0 ? 1 : 0) - P.spin, -dt * .8, dt * 1.6); else P.spin = Math.max(0, P.spin - dt * 2);
  // fire
  if (P.trigger && (w.auto || P.semiReady)) tryFire();
  if (!P.trigger) P.semiReady = true;
  // camera
  const bob = Math.sin(P.bobT) * .035 * Math.min(1, sp / 5) * (1 - P.ads * .7), sh = P.shake * .03;
  camera.position.set(P.pos.x + (Math.random() - .5) * sh, P.pos.y + P.eyeH + Math.abs(bob) + (Math.random() - .5) * sh, P.pos.z + (Math.random() - .5) * sh);
  camera.rotation.set(P.pitch + P.rc * .012, P.yaw, -P.slideRoll * .07);
  const fov = lerp(75, w.zoom, P.ads) + P.sprintT * 4;
  if (Math.abs(camera.fov - fov) > .05) { camera.fov = fov; camera.updateProjectionMatrix(); PSU.uScale.value = renderer.domElement.height / (2 * Math.tan(THREE.MathUtils.degToRad(fov) / 2)) / 1; }
  // viewmodel
  VMS.forEach((m, i) => m.visible = i === P.cur && !P.inTank && !((w.id === 'sniper' || w.scopeView) && P.ads > .7)); LH.visible = VMS[P.cur].visible && VMS[P.cur].userData.style !== 'knife';
  const sv = w.id === 'sniper' || w.scopeView; $('scope').style.opacity = sv ? clamp((P.ads - .6) * 2.5, 0, 1) : 0; $('rdot').style.opacity = w.dot && !sv ? clamp((P.ads - .5) * 2, 0, 1) : 0;
  if (P.regen) { P.sinceHurt += dt; if (P.sinceHurt > 5 && P.hp < P.maxHp) { P.hp = Math.min(P.maxHp, P.hp + 3 * dt); hudHealth(); } }
  const vm = VMS[P.cur], ud = vm.userData;
  vm.position.copy(ud.hip).lerp(ud.ads, P.ads);
  const t = performance.now() / 1000, mvf = Math.min(1, sp / 5.4) * (1 - P.ads * .8);
  vm.position.x += Math.sin(P.bobT) * .012 * mvf + Math.sin(t * 1.3) * .0015; vm.position.y += Math.abs(Math.cos(P.bobT)) * .01 * mvf + Math.sin(t * 1.7) * .0015;
  vm.position.z += P.rc * (P.cur === 1 ? .09 : P.cur === 2 ? .12 : .035);
  vm.rotation.set(P.rc * (P.cur === 0 ? .04 : .2), 0, 0);
  const sp1 = P.sprintT; if (sp1 > .01) { vm.rotation.y += .5 * sp1; vm.rotation.x += .15 * sp1; vm.rotation.z += .2 * sp1; vm.position.y -= .07 * sp1; vm.position.x -= .06 * sp1; }
  if (P.stance === 2) vm.position.y -= .01;
  if (P.slideRoll > .01) { vm.rotation.z += P.slideRoll * .35; vm.position.y -= P.slideRoll * .04; vm.position.x -= P.slideRoll * .05; }
  resetParts(ud); HAND.copy(ud.lh);
  COS.skin = COS.skins[w.id] || null;
  const skn = applySkin(vm, ud, dt);
  if (ud.acc && !skn) { const tv = P.variant[P.cur] || 0, pc = (ggOf(P.cur) && ggOf(P.cur).col !== undefined) ? ggOf(P.cur).col : COS.paint !== null && tv < 4 ? COS.paint : VAR_COL[tv]; ud.acc.color.setHex(pc); ud.acc.emissive.setHex(tv >= 4 || COS.paint !== null ? pc : 0); ud.acc.emissiveIntensity = .45; }
  if (ud.spinG) ud.spinG.rotation.z += P.spin * dt * 40;
  if (P.reload > 0) reloadAnim(vm, ud, 1 - P.reload / w.reload, w);
  if (P.swT > 0) { const u = 1 - P.swT / .45, off = u < .5 ? sstep(0, 1, u * 2) : 1 - sstep(0, 1, (u - .5) * 2); vm.position.y -= off * .5; vm.rotation.x += off; vm.position.x += off * .12; }
  if (P.wInsp >= 0) {
    if (P.trigger || P.reload > 0 || P.swT > 0 || P.ads > .3 || P.sprintT > .3) P.wInsp = -1; else {
      P.wInsp += dt; const u = P.wInsp / (COS.skin ? 3.8 : 3.0); if (u >= 1) P.wInsp = -1; else {
        skinInsp(vm, u);
        const a = sstep(0, .16, u) * (1 - sstep(.86, 1, u)), r = sstep(.3, .62, u);
        vm.position.y += a * .035; vm.position.z += a * .05; vm.position.x -= a * .06;
        vm.rotation.y -= a * (.95 + Math.sin(u * 7) * .1); vm.rotation.z += a * .35 + r * Math.PI * 2 * .0; vm.rotation.x += a * .12 - Math.sin(Math.PI * r) * .55;
        vm.rotation.y += sstep(.5, .8, u) * a * 1.9;
      }
    }
  }
  if (P.throwT > 0) { const u = 1 - P.throwT / .4, s2 = Math.sin(Math.PI * u); vm.position.y -= s2 * .15; vm.rotation.x += s2 * .5; }
  if (ud.style === 'knife') knifeAnim(vm, ud, dt); if (ud.slide) ud.slide.position.z = ud.slideBase + Math.min(.045, P.rc * .05);
  placeLeftHand(vm);
  if (ud.war && !(P.reload > 0 && P.cur === 2)) ud.war.visible = P.ws[2].ammo > 0;
  if (P.reload > 0) reloadBar(P.reload / w.reload, P.reload.toFixed(1) + ' sn'); else if (P.swT > 0) reloadBar(P.swT / .45, 'KUŞANIYOR'); else reloadBar(-1);
  vmCam.fov = lerp(58, 46, P.ads); vmCam.updateProjectionMatrix();
  const fl = P.flashVM > 0;
  vmFlashSpr.visible = fl; vmFlash.intensity = fl ? 2.2 : 0;
  if (fl) { const mp = vm.localToWorld(ud.muzzle.clone()); vmFlashSpr.position.copy(mp); vmFlash.position.copy(mp); vmFlashSpr.scale.setScalar(.22 + Math.random() * .12); }
  // crosshair
  $('cross').style.setProperty('--g', (5 + spreadNow() * 420) + 'px'); $('cross').style.opacity = 1 - P.ads * .6;
}
