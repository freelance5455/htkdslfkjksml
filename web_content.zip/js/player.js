class Player {
  constructor(scene, camera, isLocal = true) {
    this.scene = scene;
    this.camera = camera;
    this.isLocal = isLocal;

    this.health = 100;
    this.maxHealth = 100;
    this.armor = 50;
    this.maxArmor = 100;
    this.alive = true;
    this.kills = 0;

    this.position = new THREE.Vector3(0, 1.6, 0);
    this.velocity = new THREE.Vector3();
    this.rotationY = 0;
    this.pitch = 0;

    this.speed = 7.5;
    this.sprintMult = 1.7;
    this.crouchMult = 0.55;
    this.jumpForce = 7.5;
    this.gravity = 22;

    this.isGrounded = true;
    this.isCrouching = false;
    this.isSprinting = false;
    this.isAiming = false;
    this.height = 1.7;
    this.radius = 0.4;

    this.weapons = [
      createWeaponInstance('pistol'),
      null
    ];
    this.currentWeaponIndex = 0;
    this.weaponMesh = null;

    this.moveInput = { x: 0, z: 0 };
    this.lookInput = { x: 0, y: 0 };
    this.spawnProtectUntil = 0;

    this.mesh = this.createMesh();
    scene.add(this.mesh);

    this.cameraOffset = new THREE.Vector3(0, 1.8, 4.2);
    this.cameraTarget = new THREE.Vector3();
  }

  createMesh() {
    const group = new THREE.Group();

    // Body (cylinder compatible with Three r128)
    const bodyGeo = new THREE.CylinderGeometry(0.32, 0.35, 1.0, 10);
    const bodyMat = new THREE.MeshStandardMaterial({
      color: 0x2a6fdb,
      roughness: 0.7,
      metalness: 0.2
    });
    const body = new THREE.Mesh(bodyGeo, bodyMat);
    body.position.y = 1.0;
    body.castShadow = true;
    group.add(body);
    this.bodyMesh = body;

    // Head
    const headGeo = new THREE.SphereGeometry(0.28, 12, 10);
    const headMat = new THREE.MeshStandardMaterial({ color: 0xf5d0a9, roughness: 0.6 });
    const head = new THREE.Mesh(headGeo, headMat);
    head.position.y = 1.7;
    head.castShadow = true;
    group.add(head);
    this.headMesh = head;

    // Arms
    const armGeo = new THREE.CylinderGeometry(0.09, 0.09, 0.55, 8);
    const armMat = new THREE.MeshStandardMaterial({ color: 0x2a6fdb });
    const leftArm = new THREE.Mesh(armGeo, armMat);
    leftArm.position.set(-0.45, 1.15, 0);
    leftArm.rotation.z = 0.25;
    group.add(leftArm);

    const rightArm = new THREE.Mesh(armGeo, armMat);
    rightArm.position.set(0.45, 1.15, 0);
    rightArm.rotation.z = -0.25;
    group.add(rightArm);
    this.rightArm = rightArm;

    // Legs
    const legGeo = new THREE.CylinderGeometry(0.11, 0.12, 0.7, 8);
    const legMat = new THREE.MeshStandardMaterial({ color: 0x1a1a2e });
    const leftLeg = new THREE.Mesh(legGeo, legMat);
    leftLeg.position.set(-0.18, 0.35, 0);
    group.add(leftLeg);
    const rightLeg = new THREE.Mesh(legGeo, legMat);
    rightLeg.position.set(0.18, 0.35, 0);
    group.add(rightLeg);

    group.position.copy(this.position);
    return group;
  }

  get currentWeapon() {
    return this.weapons[this.currentWeaponIndex];
  }

  update(dt, keys, touch, mapBounds) {
    if (!this.alive) return;

    // Movement from joystick / keys
    let mx = this.moveInput.x;
    let mz = this.moveInput.z;

    if (Math.abs(mx) < 0.05) mx = 0;
    if (Math.abs(mz) < 0.05) mz = 0;

    const moving = Math.abs(mx) > 0.05 || Math.abs(mz) > 0.05;
    let speed = this.speed;
    if (this.isSprinting && moving && !this.isCrouching) speed *= this.sprintMult;
    if (this.isCrouching) speed *= this.crouchMult;

    // Direction relative to camera yaw
    const yaw = this.rotationY;
    const forward = new THREE.Vector3(-Math.sin(yaw), 0, -Math.cos(yaw));
    const right = new THREE.Vector3(Math.cos(yaw), 0, -Math.sin(yaw));

    const moveDir = new THREE.Vector3();
    moveDir.addScaledVector(forward, mz);
    moveDir.addScaledVector(right, mx);
    if (moveDir.length() > 1) moveDir.normalize();

    this.velocity.x = moveDir.x * speed;
    this.velocity.z = moveDir.z * speed;

    // Jump
    if (this.wantJump && this.isGrounded) {
      this.velocity.y = this.jumpForce;
      this.isGrounded = false;
      this.wantJump = false;
    }

    // Gravity
    this.velocity.y -= this.gravity * dt;
    this.position.x += this.velocity.x * dt;
    this.position.y += this.velocity.y * dt;
    this.position.z += this.velocity.z * dt;

    // Ground
    if (this.position.y <= this.height * (this.isCrouching ? 0.6 : 0.5)) {
      this.position.y = this.height * (this.isCrouching ? 0.6 : 0.5);
      this.velocity.y = 0;
      this.isGrounded = true;
    }

    // Map bounds (simple)
    const bound = mapBounds || 95;
    this.position.x = Utils.clamp(this.position.x, -bound, bound);
    this.position.z = Utils.clamp(this.position.z, -bound, bound);

    // Look
    const sens = (window.gameSettings?.sensitivity || 1.2) * 0.004;
    this.rotationY -= this.lookInput.x * sens;
    this.pitch -= this.lookInput.y * sens;
    this.pitch = Utils.clamp(this.pitch, -0.9, 0.7);

    // Mesh
    this.mesh.position.copy(this.position);
    this.mesh.rotation.y = this.rotationY;
    this.mesh.scale.y = this.isCrouching ? 0.7 : 1;

    // Camera third person
    if (this.isLocal && this.camera) {
      const offset = this.cameraOffset.clone();
      if (this.isAiming) {
        offset.z = 2.2;
        offset.y = 1.5;
        offset.x = 0.6;
      }
      offset.applyAxisAngle(new THREE.Vector3(0, 1, 0), this.rotationY);
      const desired = this.position.clone().add(offset);
      this.camera.position.lerp(desired, 1 - Math.pow(0.001, dt));

      this.cameraTarget.set(
        this.position.x - Math.sin(this.rotationY) * 10,
        this.position.y + 1.2 + this.pitch * 3,
        this.position.z - Math.cos(this.rotationY) * 10
      );
      this.camera.lookAt(this.cameraTarget);
    }

    // Reload finish
    const w = this.currentWeapon;
    if (w && w.reloading && performance.now() / 1000 > w.reloadEnd) {
      const need = w.magSize - w.ammo;
      const take = Math.min(need, w.reserve);
      w.ammo += take;
      w.reserve -= take;
      w.reloading = false;
    }
  }

  tryShoot(now) {
    const w = this.currentWeapon;
    if (!w || !this.alive || w.reloading) return null;
    if (w.ammo <= 0) {
      this.startReload();
      return null;
    }
    if (now - w.lastShot < w.fireRate) return null;

    w.lastShot = now;
    w.ammo--;
    AudioManager.shoot(w.type);

    // Recoil
    this.pitch += (Math.random() - 0.3) * w.recoil;
    this.rotationY += (Math.random() - 0.5) * w.recoil * 0.5;

    return {
      origin: this.getMuzzlePosition(),
      direction: this.getAimDirection(),
      weapon: w,
      damage: w.damage,
      range: w.range,
      spread: this.isAiming ? w.spread * 0.4 : w.spread
    };
  }

  getMuzzlePosition() {
    const pos = this.position.clone();
    pos.y += this.isCrouching ? 1.0 : 1.35;
    pos.x -= Math.sin(this.rotationY) * 0.6;
    pos.z -= Math.cos(this.rotationY) * 0.6;
    return pos;
  }

  getAimDirection() {
    const dir = new THREE.Vector3(
      -Math.sin(this.rotationY) * Math.cos(this.pitch),
      this.pitch,
      -Math.cos(this.rotationY) * Math.cos(this.pitch)
    );
    dir.normalize();
    return dir;
  }

  startReload() {
    const w = this.currentWeapon;
    if (!w || w.reloading || w.ammo >= w.magSize || w.reserve <= 0) return;
    w.reloading = true;
    w.reloadEnd = performance.now() / 1000 + w.reloadTime;
    AudioManager.reload();
  }

  switchWeapon() {
    if (this.weapons[1]) {
      this.currentWeaponIndex = 1 - this.currentWeaponIndex;
    }
  }

  takeDamage(amount) {
    if (!this.alive) return;
    // Spawn protection
    if (performance.now() / 1000 < this.spawnProtectUntil) return;
    let remaining = amount;
    if (this.armor > 0) {
      const absorbed = Math.min(this.armor, remaining * 0.6);
      this.armor -= absorbed;
      remaining -= absorbed;
    }
    this.health -= remaining;
    AudioManager.damage();
    if (this.health <= 0) {
      this.health = 0;
      this.alive = false;
      this.mesh.visible = false;
    }
  }

  heal(amount) {
    this.health = Math.min(this.maxHealth, this.health + amount);
  }

  addArmor(amount) {
    this.armor = Math.min(this.maxArmor, this.armor + amount);
  }

  pickupWeapon(weaponId) {
    const inst = createWeaponInstance(weaponId);
    if (!this.weapons[1]) {
      this.weapons[1] = inst;
      this.currentWeaponIndex = 1;
    } else {
      this.weapons[this.currentWeaponIndex] = inst;
    }
    AudioManager.pickup();
  }

  addAmmo(amount) {
    const w = this.currentWeapon;
    if (w) {
      w.reserve += amount;
      AudioManager.pickup();
    }
  }
}
