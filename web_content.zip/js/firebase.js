// Firebase App
import { initializeApp } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-app.js";

import { 
    getAuth 
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";

import {
    getFirestore
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";


// Firebase Config

const firebaseConfig = {
  apiKey: "AIzaSyCmbW-V8xREhFaKovICTBB7IBO5MkzVNPk",
  authDomain: "netearn-3cb32.firebaseapp.com",
  projectId: "netearn-3cb32",
  storageBucket: "netearn-3cb32.firebasestorage.app",
  messagingSenderId: "591455170358",
  appId: "1:591455170358:web:8ad16aeaf0c86b212d0d97"
};


// Initialize Firebase

const app = initializeApp(firebaseConfig);


// Export

export const auth = getAuth(app);

export const db = getFirestore(app);
