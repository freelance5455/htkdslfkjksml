(function () {

  "use strict";

  var firebaseConfig = {

    apiKey:
      "AIzaSyDhM8YszgogzaJNPHCmYTakOlDGkYrh2NM",

    authDomain:
      "mesh-9a4f1.firebaseapp.com",

    projectId:
      "mesh-9a4f1",

    storageBucket:
      "mesh-9a4f1.firebasestorage.app",

    messagingSenderId:
      "631820121108",

    appId:
      "1:631820121108:web:457c9a1e16cbf320392301"

  };

  if (!firebase.apps.length) {
    firebase.initializeApp(
      firebaseConfig
    );
  }

  var auth =
    firebase.auth();
  // Member sessions persist across app restarts until the member explicitly signs out.
  auth.setPersistence(firebase.auth.Auth.Persistence.LOCAL).catch(function(e){ console.warn("MESH auth persistence setup failed", e); });

  var db =
    firebase.firestore();

  var storage =
    firebase.storage();

  var currentUser = null;

  function emit(name, detail) {

    document.dispatchEvent(
      new CustomEvent(
        name,
        {
          detail: detail || {}
        }
      )
    );

  }

  function friendlyError(error) {

    if (!error) {
      return "Something went wrong.";
    }

    switch (error.code) {

      case "auth/email-already-in-use":
        return "This email is already registered. Try signing in instead.";

      case "auth/invalid-email":
        return "Please enter a valid email address.";

      case "auth/weak-password":
        return "Password is too weak. Use at least 6 characters.";

      case "auth/user-not-found":
        return "No account was found with this email.";

      case "auth/wrong-password":
        return "Incorrect password. Check it and try again.";

      case "auth/invalid-credential":
        return "We couldn't sign you in. If you haven't registered with MESH using this email, create an account first. Otherwise, check your email and password.";

      case "auth/too-many-requests":
        return "Too many attempts. Please wait and try again.";

      case "auth/network-request-failed":
        return "Network error. Check your internet connection.";

      case "auth/popup-closed-by-user":
        return "Google sign-in was cancelled.";

      default:
        return error.message ||
          "Authentication failed. Please try again.";

    }

  }

  /*
   * GET PROFILE
   */
  async function getUserProfile(uid) {

    if (!uid) {
      return null;
    }

    var snap =
      await db
        .collection("users")
        .doc(uid)
        .get();

    if (!snap.exists) {
      return null;
    }

    return snap.data();

  }

  /*
   * CREATE INITIAL PROFILE
   */
  async function createUserProfile(
    user,
    name
  ) {

    if (!user) {
      throw new Error(
        "No Firebase user."
      );
    }

    var ref =
      db
        .collection("users")
        .doc(user.uid);

    var existing =
      await ref.get();

    if (existing.exists) {
      return existing.data();
    }

    var profile = {

      uid:
        user.uid,

      fullName:
        name ||
        user.displayName ||
        "",

      email:
        user.email ||
        "",

      photoURL:
        user.photoURL ||
        "",

      universityId: "",
      university: "",

      facultyId: "",
      faculty: "",

      departmentId: "",
      department: "",

      level: "",

      interests: [],

      onboardingCompleted:
        false,

      verificationStatus: "pending",
      inviteCodeUsed: "",

      createdAt:
        firebase.firestore.FieldValue.serverTimestamp(),

      updatedAt:
        firebase.firestore.FieldValue.serverTimestamp()

    };

    await ref.set(profile);

    return profile;

  }

  /*
   * SIGN UP
   *
   * IMPORTANT:
   * Firebase account creation happens first.
   *
   * The auth-success event is dispatched immediately
   * after Firebase confirms account creation.
   *
   * Firestore profile creation is then attempted separately.
   */
  async function signUp(
    name,
    email,
    password,
    inviteCode,
    username
  ) {
    var result;
    try {
      inviteCode = String(inviteCode || "").trim().toUpperCase();
      if (!inviteCode) throw new Error("A valid MESH pilot invite code is required.");
      var inviteRef = db.collection("inviteCodes").doc(inviteCode);
      var inviteSnap = await inviteRef.get();
      var preInvite = inviteSnap.exists ? (inviteSnap.data() || {}) : {};
      var preReusable = preInvite.codeType === "university_launch" || preInvite.reusable === true;
      if (!inviteSnap.exists || preInvite.active !== true || (!preReusable && preInvite.used === true) || (preInvite.expiresAt && preInvite.expiresAt.toDate && preInvite.expiresAt.toDate() < new Date())) {
        throw new Error("That invite code is invalid, expired, or already used. Ask a MESH admin for a new code.");
      }

      result =
        await auth.createUserWithEmailAndPassword(
          email,
          password
        );

      var user =
        result.user;

      /*
       * Update Firebase display name.
       */
      if (
        user &&
        name &&
        typeof user.updateProfile === "function"
      ) {

        try {

          await user.updateProfile({
            displayName: name
          });

        } catch (profileError) {

          console.warn(
            "MESH: Firebase display name update failed:",
            profileError
          );

        }

      }

      // Private pilot codes are single-use; university launch codes are reusable and university-bound.
      await db.runTransaction(async function(tx) {
        var freshInvite = await tx.get(inviteRef);
        if (!freshInvite.exists) throw new Error("This invite code was not found.");
        var codeData = freshInvite.data() || {};
        var reusable = codeData.codeType === "university_launch" || codeData.reusable === true;
        if (codeData.active !== true || (!reusable && codeData.used === true)) throw new Error("This invite code is disabled or has already been used.");
        if (codeData.expiresAt && codeData.expiresAt.toDate && codeData.expiresAt.toDate() < new Date()) throw new Error("This invite code has expired.");
        var userRef = db.collection("users").doc(user.uid);
        var stamp = firebase.firestore.FieldValue.serverTimestamp();
        if (reusable) {
          tx.update(inviteRef, { usageCount: firebase.firestore.FieldValue.increment(1), lastUsedAt: stamp, updatedAt: stamp });
          tx.set(inviteRef.collection("redemptions").doc(user.uid), { uid:user.uid, email:user.email||"", name:name||user.displayName||"", universityId:codeData.universityId||"", redeemedAt:stamp, source:"signup" });
        } else {
          tx.update(inviteRef, { used:true, usedBy:user.uid, usedByEmail:user.email||"", usedByName:name||user.displayName||"", usedAt:stamp });
        }
        tx.set(userRef, { uid:user.uid, fullName:name || user.displayName || "", username:String(username||"").trim().toLowerCase(), email:user.email || "", photoURL:user.photoURL || "", universityId:"", university:"", facultyId:"", faculty:"", departmentId:"", department:"", level:"", interests:[], onboardingCompleted:false, verificationStatus:"not_required", verificationRequestStatus:"not_submitted", inviteCodeUsed:inviteCode, pilotAccessGranted:true, launchCodeUniversityId:reusable?(codeData.universityId||""):(codeData.universityId||""), launchCodeUniversityName:reusable?(codeData.universityName||""):(codeData.universityName||""), inviteCodeType:reusable?"university_launch":"pilot", createdAt:firebase.firestore.FieldValue.serverTimestamp(), updatedAt:stamp }, {merge:true});
      });
      emit("mesh:auth-success", { user:user, isNewUser:true });

    } catch (error) {
      // If Firebase Auth created the account but the invite/profile transaction failed,
      // remove the just-created account when possible to avoid an orphaned registration.
      if (result && result.user && auth.currentUser && auth.currentUser.uid === result.user.uid) {
        try { await result.user.delete(); } catch (cleanupError) { console.warn("MESH: Could not clean up incomplete registration", cleanupError); }
      }
      console.error(
        "MESH: Sign up failed:",
        error
      );

      emit(
        "mesh:auth-error",
        {
          error: error,
          message: friendlyError(error)
        }
      );

    }

  }

  /*
   * SIGN IN
   */
  async function signIn(
    email,
    password
  ) {

    try {

      var result =
        await auth.signInWithEmailAndPassword(
          email,
          password
        );

      emit(
        "mesh:auth-success",
        {
          user: result.user,
          isNewUser: false
        }
      );

    } catch (error) {

      console.error(
        "MESH: Sign in failed:",
        error
      );

      emit(
        "mesh:auth-error",
        {
          error: error,
          message: friendlyError(error)
        }
      );

    }

  }

  /*
   * GOOGLE
   */
  async function signInWithGoogle() {
    try {
      var provider = new firebase.auth.GoogleAuthProvider();
      provider.setCustomParameters({ prompt: "select_account" });
      // Redirect works in Android WebViews where signInWithPopup often never returns.
      await auth.signInWithRedirect(provider);
    } catch (error) {
      console.error("MESH: Google sign-in failed:", error);
      emit("mesh:auth-error", { error:error, message:friendlyError(error) });
    }
  }

  // Finish the OAuth redirect after Firebase restores the app page.
  auth.getRedirectResult().then(async function(result) {
    if (!result || !result.user) return;
    var user = result.user, additional = result.additionalUserInfo;
    var isNewUser = !!(additional && additional.isNewUser === true);
    try {
      var existing = await getUserProfile(user.uid);
      if (!existing && isNewUser) {
        // Google-created accounts are still required to redeem a MESH pilot code before onboarding.
        await createUserProfile(user, user.displayName || "");
      }
      emit("mesh:auth-success", { user:user, isNewUser:isNewUser || !(existing && existing.onboardingCompleted) });
    } catch (profileError) {
      console.error("MESH: Google profile setup failed:", profileError);
      emit("mesh:auth-error", { error:profileError, message:"Google sign-in succeeded, but your MESH profile could not be loaded. Please retry." });
    }
  }).catch(function(error) {
    if (error && error.code !== "auth/no-auth-event") {
      console.error("MESH: Google redirect result failed:", error);
      emit("mesh:auth-error", { error:error, message:friendlyError(error) });
    }
  });

  /*
   * PASSWORD RESET
   */
  async function resetPassword(email) {

    try {

      await auth.sendPasswordResetEmail(email, { url: window.location.origin + window.location.pathname, handleCodeInApp: false });

      emit(
        "mesh:password-reset-sent",
        {
          email: email
        }
      );

    } catch (error) {

      console.error(
        "MESH: Password reset failed:",
        error
      );

      emit(
        "mesh:auth-error",
        {
          error: error,
          message: friendlyError(error)
        }
      );

    }

  }

  /*
   * SAVE ONBOARDING
   */
  async function saveOnboardingProfile(
    data
  ) {

    var user =
      auth.currentUser;

    if (!user) {
      throw new Error(
        "You are not signed in."
      );
    }

    var ref =
      db
        .collection("users")
        .doc(user.uid);

    /*
     * Merge means we don't destroy
     * other profile information.
     */
    await ref.set(

      {

        fullName:
          ((await getUserProfile(user.uid)) || {}).fullName || user.displayName || "",

        universityId:
          data.universityId || "",

        university:
          data.university || "",

        facultyId:
          data.facultyId || "",

        faculty:
          data.faculty || "",

        departmentId:
          data.departmentId || "",

        department:
          data.department || "",

        level:
          data.level || "",

        levelId:
          data.levelId || "",

        interests:
          Array.isArray(data.interests)
            ? data.interests
            : [],

        onboardingCompleted:
          true,

        updatedAt:
          firebase.firestore.FieldValue.serverTimestamp()

      },

      {
        merge: true
      }

    );

    return true;

  }

  /*
   * GENERIC CONTENT HELPERS
   */
  async function getCollection(collectionName, options) {
    var ref = db.collection(collectionName);
    options = options || {};
    if (options.where) {
      options.where.forEach(function (condition) {
        ref = ref.where(condition[0], condition[1], condition[2]);
      });
    }
    var snap = await ref.limit(options.limit || 100).get();
    return snap.docs.map(function (doc) {
      return Object.assign({ id: doc.id }, doc.data());
    });
  }

  async function getCollectionByField(collectionName, field, value, limit) {
    return getCollection(collectionName, {
      where: [[field, "==", value]],
      limit: limit || 100
    });
  }

  async function redeemPilotCode(code) {
    var user = auth.currentUser;
    if (!user) throw new Error("Please sign in before redeeming a pilot code.");
    code = String(code || "").trim().toUpperCase();
    if (!(/^[A-HJ-NP-Z2-9]{5}-[A-HJ-NP-Z2-9]{5}$/.test(code) || /^[A-Z]{2,5}-MESH$/.test(code))) {
      throw new Error("Incorrect code format. Use XXXXX-XXXXX for private pilot codes, or a university launch code such as ABU-MESH.");
    }
    var inviteRef = db.collection("inviteCodes").doc(code), userRef = db.collection("users").doc(user.uid);
    await db.runTransaction(async function(tx) {
      var inviteSnap = await tx.get(inviteRef);
      if (!inviteSnap.exists) throw new Error("This code wasn't found. Check it and try again.");
      var invite = inviteSnap.data() || {}, reusable = invite.codeType === "university_launch" || invite.reusable === true;
      if (invite.active !== true) throw new Error("This code has been disabled. Ask the MESH team for help.");
      if (!reusable && invite.used === true) throw new Error("This pilot code has already been redeemed. Ask the MESH team for another code.");
      if (invite.expiresAt && invite.expiresAt.toDate && invite.expiresAt.toDate() < new Date()) throw new Error("This code has expired.");
      var userSnap = await tx.get(userRef), existing = userSnap.exists ? userSnap.data() : {};
      if (existing.inviteCodeUsed) throw new Error("A code has already been redeemed on this account.");
      var stamp = firebase.firestore.FieldValue.serverTimestamp();
      if (reusable) {
        tx.update(inviteRef, { usageCount: firebase.firestore.FieldValue.increment(1), lastUsedAt: stamp, updatedAt: stamp });
        tx.set(inviteRef.collection("redemptions").doc(user.uid), { uid:user.uid, email:user.email||"", name:user.displayName||existing.fullName||existing.name||"", universityId:invite.universityId||"", redeemedAt:stamp, source:"existing-account" });
      } else {
        tx.update(inviteRef, { used:true, usedBy:user.uid, usedByEmail:user.email||"", usedByName:user.displayName||existing.fullName||existing.name||"", usedAt:stamp });
      }
      tx.set(userRef, { inviteCodeUsed:code, pilotAccessGranted:true, inviteCodeType:reusable?"university_launch":"pilot", launchCodeUniversityId:invite.universityId||"", launchCodeUniversityName:invite.universityName||"", updatedAt:stamp }, {merge:true});
    });
    return true;
  }

  async function updateUserProfile(updates) {
    var user = auth.currentUser;
    if (!user) throw new Error("You are not signed in.");
    var source = Object.assign({}, updates || {});
    // Academic placement is assigned during onboarding, never through profile editing.
    ["uid","email","role","isAdmin","universityId","university","facultyId","faculty","departmentId","department","level","levelId","onboardingCompleted","pilotAccessGranted","inviteCodeUsed","launchCodeUniversityId","launchCodeUniversityName","createdAt","verificationStatus"].forEach(function(k){ delete source[k]; });
    var allowed = {};
    ["fullName","displayName","username","bio","photoURL","avatarStyle","interests"].forEach(function(k){ if(Object.prototype.hasOwnProperty.call(source,k)) allowed[k]=source[k]; });
    if (allowed.username !== undefined) {
      allowed.username = String(allowed.username || "").trim().toLowerCase().replace(/^@/,"");
      if (!/^[a-z0-9_]{3,24}$/.test(allowed.username)) throw new Error("Username must be 3–24 characters using letters, numbers, or underscores.");
    }
    var userRef = db.collection("users").doc(user.uid);
    var stamp = firebase.firestore.FieldValue.serverTimestamp();
    await db.runTransaction(async function(tx) {
      var currentSnap = await tx.get(userRef);
      var current = currentSnap.exists ? currentSnap.data() : {};
      var payload = Object.assign({}, allowed);
      if (payload.username !== undefined && payload.username !== (current.username || "")) {
        if (current.usernameChanged === true || current.usernameChangeCount >= 1) throw new Error("Your username can only be changed once.");
        var claimRef = db.collection("usernameClaims").doc(payload.username);
        var claimSnap = await tx.get(claimRef);
        if (claimSnap.exists && claimSnap.data().uid !== user.uid) throw new Error("That username is already taken. Please choose another.");
        tx.set(claimRef, { uid:user.uid, username:payload.username, createdAt:stamp });
        payload.usernameChanged = true;
        payload.usernameChangeCount = 1;
      }
      tx.set(userRef, Object.assign({}, payload, { updatedAt:stamp }), { merge:true });
    });
    return getUserProfile(user.uid);
  }

  async function getAdminProfile(uid) {
    if (!uid) return null;
    var snap = await db.collection("admins").doc(uid).get();
    return snap.exists ? Object.assign({ uid: uid }, snap.data()) : null;
  }

  async function saveDocument(collectionName, id, data) {
    var ref = id ? db.collection(collectionName).doc(id) : db.collection(collectionName).doc();
    var payload = Object.assign({}, data, {
      updatedAt: firebase.firestore.FieldValue.serverTimestamp()
    });
    if (!id) payload.createdAt = firebase.firestore.FieldValue.serverTimestamp();
    await ref.set(payload, { merge: true });
    return Object.assign({ id: ref.id }, data);
  }

  async function deleteDocument(collectionName, id) {
    await db.collection(collectionName).doc(id).delete();
    return true;
  }

  /*
   * SIGN OUT
   */
  async function signOut() {

    try {

      await auth.signOut();

      emit(
        "mesh:logout-success"
      );

    } catch (error) {

      console.error(
        "MESH: Sign out failed:",
        error
      );

      emit(
        "mesh:auth-error",
        {
          error: error,
          message: friendlyError(error)
        }
      );

    }

  }

  /*
   * AUTH STATE
   */
  auth.onAuthStateChanged(
    function (user) {

      currentUser =
        user || null;

      emit(
        "mesh:auth-state",
        {
          user: user || null
        }
      );

    }
  );

  window.MESH_FIREBASE = {

    auth: auth,

    db: db,

    storage: storage,

    signUp: signUp,

    signIn: signIn,

    signInWithGoogle:
      signInWithGoogle,

    resetPassword:
      resetPassword,

    signOut:
      signOut,

    getUserProfile:
      getUserProfile,

    getCollection:
      getCollection,

    getCollectionByField:
      getCollectionByField,

    updateUserProfile:
      updateUserProfile,
    redeemPilotCode:
      redeemPilotCode,

    getAdminProfile:
      getAdminProfile,

    saveDocument:
      saveDocument,

    deleteDocument:
      deleteDocument,

    createUserProfile:
      createUserProfile,

    saveOnboardingProfile:
      saveOnboardingProfile,

    getCurrentUser:
      function () {
        return currentUser ||
          auth.currentUser;
      }

  };

})();