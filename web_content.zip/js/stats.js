/* جنة القرآن v6 — الإنجازات والتحليلات وسجل النشاط وآخر مواضعي */
'use strict';
/* تتبّع الآيات المقروءة: كل آية تبقى ظاهرة ≥ ٢ ثانية تُحتسب */
const TOT=6236;let SEEN=(ls.get('seenAll','')+'0'.repeat(TOT)).slice(0,TOT).split('');
let SDY=ls.get('sdy',{d:'',g:[]});if(SDY.d!=td())SDY={d:td(),g:[]};const SDS=new Set(SDY.g);let SV=0,IO=null;const TM=new Map();
function flushSeen(){ls.set('seenAll',SEEN.join(''));ls.set('sdy',{d:SDY.d,g:[...SDS]})}
const dflush=(()=>{let t;return()=>{clearTimeout(t);t=setTimeout(flushSeen,2500)}})();
function markSeen(s,a){const g=gidx(s,a);if(SDY.d!=td()){SDY={d:td(),g:[]};SDS.clear()}
  if(!SDS.has(g)){SDS.add(g);logAdd('ay');const h=ls.get('hh',Array(24).fill(0));h[new Date().getHours()]++;ls.set('hh',h);const ss=ls.get('ss',{});ss[s]=(ss[s]||0)+1;ls.set('ss',ss)}
  if(SEEN[g-1]!='1'){SEEN[g-1]='1'}dflush();checkBadges()}
function watchReader(){if(!('IntersectionObserver' in window)||!S.cur||!$('.qt'))return;if(IO)IO.disconnect();TM.forEach(clearTimeout);TM.clear();const s=S.cur;
  IO=new IntersectionObserver(es=>es.forEach(e=>{const a=+e.target.id.slice(1);if(e.isIntersecting){if(!TM.has(a))TM.set(a,setTimeout(()=>{TM.delete(a);if(S.cur==s)markSeen(s,a)},2000))}else if(TM.has(a)){clearTimeout(TM.get(a));TM.delete(a)}}),{threshold:.7});
  document.querySelectorAll('.ay[id^=a]').forEach(e=>IO.observe(e))}
{const _o=openS;openS=async function(s,a){await _o(s,a);try{await names();watchReader();logPos('read',{s,a:a||1})}catch(e){}}}
/* الصفحات في المصحف */
{const _m=mushaf;mushaf=function(n){_m(n);clearTimeout(S._pgt);const p=Math.max(1,Math.min(604,+n||1));S._pgt=setTimeout(()=>{const k=td()+':'+p,d=ls.get('pgd',{d:'',p:[]});const D=d.d==td()?d:{d:td(),p:[]};if(!D.p.includes(p)){D.p.push(p);ls.set('pgd',D);logAdd('pg')}logPos('page',p);checkBadges()},6000)}}
/* الاستماع */
setInterval(()=>{if(au&&!au.paused&&!au.ended&&au.src&&cur){logAdd('ls',5);const r=REC[S.rec][1],rs=ls.get('rst',{});rs[r]=(rs[r]||0)+5;ls.set('rst',rs);const h=ls.get('hh',Array(24).fill(0));h[new Date().getHours()]+=.1;ls.set('hh',h)}},5000);
/* ربط الأحداث الموجودة */
{const _w=wirdDone;wirdDone=function(){const k0=ls.get('khatm',0);_w();logAdd('wd');const k1=ls.get('khatm',0);if(k1>k0){addCert('khatma','ختمة القرآن الكريم','أتمّ قراءة القرآن كاملًا')}checkBadges()}}
{const _d=dayAdd;dayAdd=function(k){_d(k);if(k>0)logAdd('hf');checkBadges()}}
{const _r=revDone;revDone=function(s){_r(s);const m=ls.get('mem',{});if(m[s]&&m[s].lv>=5)addCert('hifz-'+s,'إتقان حفظ سورة '+nm(s),'أتقن حفظ سورة '+nm(s)+' ومراجعتها');checkBadges()}}
{const _h=hifzGo;hifzGo=async function(){try{logPos('hifz',{s:+$('#hs').value,a:+$('#ha').value,b:+$('#hb').value})}catch(e){}return _h()}}
{const _t=taf;taf=async function(s,a,ed){logPos('taf',{s,a});return _t(s,a,ed)}}
/* الإنجازات */
function streak(){const L=ls.get('log',{}),act=d=>{const x=L[d];return x&&((x.ay||0)>0||(x.ls||0)>=60||(x.pg||0)>0||(x.wd||0)>0||(x.nt||0)>0||(x.hf||0)>0)};
  let cur=0,d=td();if(!act(d))d=addDays(d,-1);while(act(d)){cur++;d=addDays(d,-1)}
  const ds=Object.keys(L).filter(act).sort();let best=0,run=0,prev=null;ds.forEach(x=>{run=prev&&dayN(x)-dayN(prev)==1?run+1:1;if(run>best)best=run;prev=x});return{cur,best:Math.max(best,cur)}}
const sumLog=k=>Object.values(ls.get('log',{})).reduce((a,x)=>a+(x[k]||0),0);
const seenCnt=()=>SEEN.filter(x=>x=='1').length;
const nNotes=()=>Object.values(ls.get('lib',{it:{}}).it).filter(x=>x.nt||x.td).length;
const nBm=()=>Object.values(ls.get('lib',{it:{}}).it).filter(x=>x.bm).length;
const BADGES=[
['first','🌱','أول خطوة','اقرأ آية واحدة',()=>[seenCnt(),1]],
['ay1','📗','١٠٠ آية','اقرأ ١٠٠ آية مختلفة',()=>[seenCnt(),100]],
['ay2','📘','١٠٠٠ آية','اقرأ ألف آية مختلفة',()=>[seenCnt(),1000]],
['ay3','📙','نصف القرآن','اقرأ ٣١١٨ آية مختلفة',()=>[seenCnt(),3118]],
['ay4','🏔','القرآن كله','اقرأ كل الآيات (٦٢٣٦)',()=>[seenCnt(),6236]],
['st3','🔥','٣ أيام متتالية','واظب ٣ أيام',()=>[streak().best,3]],
['st7','🔥','أسبوع كامل','واظب ٧ أيام',()=>[streak().best,7]],
['st30','🌕','٣٠ يومًا','واظب ٣٠ يومًا',()=>[streak().best,30]],
['st100','👑','١٠٠ يوم','واظب ١٠٠ يوم',()=>[streak().best,100]],
['ls1','🎧','ساعة استماع','استمع ٦٠ دقيقة',()=>[Math.floor(sumLog('ls')/60),60]],
['ls2','🎶','١٠ ساعات','استمع ٦٠٠ دقيقة',()=>[Math.floor(sumLog('ls')/60),600]],
['ls3','📻','٥٠ ساعة','استمع ٣٠٠٠ دقيقة',()=>[Math.floor(sumLog('ls')/60),3000]],
['kh1','🏆','أول ختمة','أتمم ختمة',()=>[ls.get('khatm',0),1]],
['kh3','🏆','٣ ختمات','أتمم ٣ ختمات',()=>[ls.get('khatm',0),3]],
['hf1','🧠','سورة محفوظة','أضف سورة للمراجعة',()=>[Object.keys(ls.get('mem',{})).length,1]],
['hf5','🧠','٥ سور','أضف ٥ سور للمراجعة',()=>[Object.keys(ls.get('mem',{})).length,5]],
['hf20','🧠','٢٠ سورة','أضف ٢٠ سورة للمراجعة',()=>[Object.keys(ls.get('mem',{})).length,20]],
['nt5','📝','متدبّر','دوّن ٥ ملاحظات أو تدبّرات',()=>[nNotes(),5]],
['nt25','📖','صاحب خواطر','دوّن ٢٥ ملاحظة',()=>[nNotes(),25]],
['bm10','🔖','قارئ منظّم','١٠ علامات مرجعية',()=>[nBm(),10]],
['pg50','📄','٥٠ صفحة','تصفّح ٥٠ صفحة من المصحف',()=>[sumLog('pg'),50]]];
let BQ=0;function checkBadges(){clearTimeout(BQ);BQ=setTimeout(()=>{try{const E=ls.get('bdg',{});let neu=0;BADGES.forEach(b=>{const p=b[4]();if(p[0]>=p[1]&&!E[b[0]]){E[b[0]]=td();neu++;toast('🏅 شارة جديدة: '+b[2])}});if(neu)ls.set('bdg',E);
  const st=streak();if(st.cur>=30&&!ls.get('c30')){ls.set('c30',1);addCert('streak30','٣٠ يومًا متتالية مع القرآن','واظب على القرآن ثلاثين يومًا متتالية')}}catch(e){}},400)}
function badges(){enter('more');const E=ls.get('bdg',{});v.innerHTML=head('🏅 إنجازاتي')+`<div class="sub">${AR(Object.keys(E).length)} / ${AR(BADGES.length)} شارة</div>`+BADGES.map(b=>{const p=b[4](),ok=!!E[b[0]],pc=Math.min(100,Math.round(p[0]/p[1]*100));return `<div class="badge ${ok?'':'off'}"><div class="ic">${b[1]}</div><div class="f1"><div class="t">${b[2]}</div><div class="sub" style="text-align:right">${b[3]}${ok?' · ✔ '+E[b[0]]:''}</div>${ok?'':`<div class="pbar"><i style="width:${pc}%"></i></div><div class="sub" style="text-align:right">${AR(Math.min(p[0],p[1]))} / ${AR(p[1])}</div>`}</div></div>`}).join('')+`<button class="o w" onclick="certs()">🎓 شهاداتي</button>`}
/* الشهادات */
function addCert(id,title,detail){const C=ls.get('certs',[]);if(C.some(c=>c.id==id&&id.startsWith('hifz')))return;C.unshift({id:id+'@'+td(),type:id,title,detail,date:td()});ls.set('certs',C);toast('🎓 حصلت على شهادة: '+title)}
function certs(){enter('more');const C=ls.get('certs',[]);v.innerHTML=head('🎓 شهاداتي')+`<label class="lb">الاسم على الشهادة</label><input id="un" class="in" value="${esc(ls.get('uname',''))}" placeholder="اكتب اسمك" onchange="ls.set('uname',this.value.trim())">`+(C.map((c,i)=>`<button class="card" onclick="certView(${i})">🎓 <b>${esc(c.title)}</b><div class="sub" style="text-align:right">${c.date}</div></button>`).join('')||'<p class="mt">تحصل على شهادة عند إتمام ختمة، أو إتقان سورة، أو ٣٠ يومًا متتالية.</p>')}
async function certCanvas(c){const W=1600,H=1130,cv=document.createElement('canvas');cv.width=W;cv.height=H;const x=cv.getContext('2d');try{await document.fonts.load('60px Amiri');await document.fonts.load('30px Cairo')}catch(e){}
  const g=x.createLinearGradient(0,0,W,H);g.addColorStop(0,'#fffdf5');g.addColorStop(1,'#f3e6bd');x.fillStyle=g;x.fillRect(0,0,W,H);x.strokeStyle='#b08d3b';x.lineWidth=14;x.strokeRect(36,36,W-72,H-72);x.lineWidth=3;x.strokeRect(66,66,W-132,H-132);x.strokeStyle='#185e46';x.strokeRect(80,80,W-160,H-160);
  x.textAlign='center';x.direction='rtl';x.fillStyle='#185e46';x.font='700 96px Amiri';x.fillText('شهادة إنجاز',W/2,250);x.fillStyle='#b08d3b';x.font='34px Cairo';x.fillText('جنة القرآن',W/2,310);
  x.fillStyle='#333';x.font='40px Cairo';x.fillText('تشهد جنة القرآن بأن',W/2,430);const nmx=ls.get('uname','')||'قارئ القرآن';x.fillStyle='#185e46';x.font='700 84px Amiri';x.fillText(nmx,W/2,550);
  x.fillStyle='#333';x.font='40px Cairo';x.fillText('قد حقّق الإنجاز التالي:',W/2,650);x.fillStyle='#8a6a16';x.font='700 62px Amiri';x.fillText(c.title,W/2,760);x.fillStyle='#555';x.font='34px Cairo';x.fillText(c.detail,W/2,830);
  x.fillStyle='#333';x.font='32px Cairo';x.fillText(c.date+' م  ·  '+hj(),W/2,930);x.fillStyle='#185e46';x.font='30px Cairo';x.fillText('«وَرَتِّلِ الْقُرْآنَ تَرْتِيلًا»',W/2,1010);x.fillStyle='#b08d3b';x.font='26px Cairo';x.fillText(OWNER_NAME,W/2,1060);return cv}
async function certView(i){const c=ls.get('certs',[])[i];if(!c)return;enter('more');v.innerHTML=head('🎓 الشهادة')+LD;const cv=await certCanvas(c);v.innerHTML=head('🎓 الشهادة')+`<div id="cvh"></div><div class="row"><button class="b" id="cs">↗️ مشاركة</button><button class="o" id="cd_">⬇️ حفظ الصورة</button></div><button class="o w" onclick="certs()">كل الشهادات</button>`;cv.className='cert';$('#cvh').appendChild(cv);
  const bl=()=>new Promise(r=>cv.toBlob(r,'image/png'));$('#cs').onclick=async()=>shareBlob('certificate.png',await bl(),c.title);$('#cd_').onclick=async()=>dl('certificate.png',await bl())}
/* التحليلات وسجل النشاط */
function lastDays(n){const L=ls.get('log',{}),o=[];for(let i=n-1;i>=0;i--){const d=addDays(td(),-i);o.push({d,...(L[d]||{})})}return o}
function barsHtml(arr,k,cls){const m=Math.max(1,...arr.map(x=>x[k]||0));return `<div class="bars">${arr.map(x=>`<i class="${x.d==td()?'t':''}" title="${x.d}: ${Math.round(x[k]||0)}" style="height:${Math.round((x[k]||0)/m*100)}%"></i>`).join('')}</div><div class="lbls">${arr.map((x,i)=>`<span>${arr.length<=14||i%5==0?x.d.slice(8):''}</span>`).join('')}</div>`}
async function analytics(n){await names();enter('more');n=n||7;const A=lastDays(n),sum=k=>A.reduce((a,x)=>a+(x[k]||0),0),st=streak(),pcs=Math.round(seenCnt()/TOT*1000)/10;
  const ss=Object.entries(ls.get('ss',{})).sort((a,b)=>b[1]-a[1]).slice(0,5),rs=Object.entries(ls.get('rst',{})).sort((a,b)=>b[1]-a[1])[0],hh=ls.get('hh',Array(24).fill(0)),ph=hh.indexOf(Math.max(...hh)),act=A.filter(x=>(x.ay||0)||(x.ls||0)>=60||(x.pg||0)).length;
  const T=ls.get('log',{})[td()]||{};
  v.innerHTML=head('📊 تحليلات القرآن')+`<div class="seg">${[[7,'أسبوع'],[30,'شهر'],[90,'٣ أشهر']].map(r=>`<button class="${r[0]==n?'on':''}" onclick="analytics(${r[0]})">${r[1]}</button>`).join('')}</div>
  <div class="grid2"><div class="tile"><span>🔥</span>${AR(st.cur)} يوم متتالٍ<div class="sub">أفضل: ${AR(st.best)}</div></div><div class="tile"><span>📖</span>${AR(T.ay||0)} آية اليوم<div class="sub">${AR(Math.round((T.ls||0)/60))} دقيقة استماع</div></div><div class="tile"><span>📅</span>${AR(act)} / ${AR(n)} يوم نشاط</div><div class="tile"><span>🎯</span>${AR(pcs)}٪ من القرآن قرأتَ<div class="sub">${AR(seenCnt())} / ${AR(TOT)}</div></div></div>
  <h3>الآيات المقروءة يوميًا</h3>${barsHtml(A,'ay')}<div class="sub">المجموع ${AR(sum('ay'))} · المعدل ${AR((sum('ay')/n).toFixed(1))} يوميًا</div>
  <h3>دقائق الاستماع</h3>${barsHtml(A.map(x=>({d:x.d,m:Math.round((x.ls||0)/60)})),'m')}<div class="sub">المجموع ${AR(Math.round(sum('ls')/60))} دقيقة</div>
  <div class="card"><b>📈 ملخص</b><div class="sub" style="text-align:right">صفحات المصحف: ${AR(sum('pg'))} · ورد منجز: ${AR(sum('wd'))} يوم · آيات محفوظة اليوم: ${AR(T.hf||0)} · تدبّرات وملاحظات: ${AR(sum('nt'))}</div></div>
  <div class="card"><b>🏷 أكثر السور قراءةً</b><div class="sub" style="text-align:right">${ss.length?ss.map(x=>esc(nm(+x[0]))+' ('+AR(x[1])+')').join(' · '):'لا بيانات بعد'}</div></div>
  <div class="card"><b>🎙 أكثر قارئ استماعًا</b><div class="sub" style="text-align:right">${rs?esc(rs[0])+' — '+AR(Math.round(rs[1]/60))+' دقيقة':'لا بيانات بعد'}</div></div>
  <div class="card"><b>⏰ وقتك الأنشط</b><div class="sub" style="text-align:right">${hh[ph]>0?'حوالي الساعة '+AR(ph)+':٠٠':'لا بيانات بعد'}</div></div>
  <div class="row"><button class="o" onclick="badges()">🏅 الإنجازات</button><button class="o" onclick="certs()">🎓 الشهادات</button><button class="o" onclick="positions()">🔖 آخر مواضعي</button></div>`}
/* آخر مواضعي */
function positions(){enter('more');const p=ls.get('pos',{}),ar=ls.get('ares'),last=ls.get('last'),m=[];
  const card=(ic,t,desc,fn)=>`<button class="card" onclick="${fn}">${ic} <b>${t}</b><div class="sub" style="text-align:right">${desc}</div></button>`;
  let h=head('📍 آخر مواضعي');
  h+=last?card('📖','القراءة',esc(nm(last[0]))+' · آية '+AR(last[1]),`openS(${last[0]},${last[1]})`):'';
  h+=ar?card('🎧','الاستماع',esc(nm(ar.s))+(ar.m=='a'?' · آية '+AR(ar.a):' · '+fmt(ar.t))+' · '+esc((REC.find(r=>r[0]==ar.rid)||[0,''])[1]),'resumeListen()'):'';
  h+=p.hifz?card('🧠','الحفظ',esc(nm(p.hifz.s))+' · آيات '+AR(p.hifz.a)+'–'+AR(p.hifz.b),`hifz(${p.hifz.s})`):'';
  h+=p.page?card('📄','المصحف','صفحة '+AR(p.page),`mushaf(${p.page})`):'';
  h+=p.taf?card('📚','التفسير',esc(nm(p.taf.s))+' · آية '+AR(p.taf.a),`openS(${p.taf.s},${p.taf.a})`):'';
  v.innerHTML=h+(h.includes('card')?'':'<p class="mt">ستظهر مواضعك هنا بعد أن تقرأ أو تستمع.</p>')}
checkBadges();
