/* OPERATION: DISCIPLINE — estatísticas, consulta (busca/filtro/ordenação) e atribuição de XP por período. Sem DOM. */
(function(){'use strict';
var OD=globalThis.OD,U=OD.U,G=OD.G,R=OD.Rules;
var norm=function(s){return String(s||'').normalize('NFD').replace(/[̀-ͯ]/g,'').toLowerCase()};
/* Data a que um lançamento de XP pertence: missão → data da missão; bônus → o dia; desafio → dia em que foi conquistado. */
var xpDate=function(S,x,byId){var q;
 if(q=/^MC:(\d+)$/.exec(x.r)){var m=byId[+q[1]];return m?m.date:U.iso(new Date(x.t))}
 if(q=/^B:(\d{4}-\d\d-\d\d):/.exec(x.r))return q[1];
 return U.iso(new Date(x.t))};
var byIdMap=function(S){var o={};S.m.forEach(function(m){o[m.id]=m});return o};
var xpBetween=function(S,from,to){var b=byIdMap(S);return S.l.filter(function(x){var d=xpDate(S,x,b);return d>=from&&d<=to}).reduce(function(a,x){return a+x.a},0)};
var xpOnDay=function(S,d){var b=byIdMap(S);return S.l.filter(function(x){return xpDate(S,x,b)===d})};
var stats=function(S,from,to){
 var rows=R.cnt(S,S.m.filter(function(m){return m.date>=from&&m.date<=to})),done=rows.filter(function(m){return m.s==='C'}).length,
 failed=rows.filter(function(m){return m.s==='F'||m.s==='X'}).length,pending=rows.filter(R.open).length,
 g=function(f){var o=Object.create(null);rows.forEach(function(m){var k=f(m),r=o[k]=o[k]||[0,0];r[1]++;if(m.s==='C')r[0]++});return o},dy=g(function(m){return m.date}),
 days=Object.keys(dy).map(function(k){return[k,dy[k]]}).sort(function(a,b){return b[1][0]/b[1][1]-a[1][0]/a[1][1]||b[1][1]-a[1][1]||a[0].localeCompare(b[0])});
 return{total:rows.length,done:done,failed:failed,pending:pending,rate:rows.length?done/rows.length:0,days:days.length,avg:days.length?done/days.length:0,best:days[0],worst:days[days.length-1],
  rest:Object.keys(S.r).filter(function(d){return d>=from&&d<=to}).length,perfect:Object.keys(S.d).filter(function(d){return d>=from&&d<=to&&S.d[d]==='PERFECT'}).length,
  xp:xpBetween(S,from,to),byDf:g(function(m){return m.df}),byCat:g(function(m){return m.cat||0}),weekly:g(function(m){return U.wkStart(m.date)}),monthly:g(function(m){return m.date.slice(0,7)})}};
/* Consulta de missões. o: {date, all, text, s, cat, df, pr, main, sort}. s: ''|'open'|P|A|C|F|X|R */
var query=function(S,o){o=o||{};var t=norm(o.text).trim(),l=S.m.filter(function(m){
  if(!o.all&&m.date!==o.date)return false;
  if(o.s==='open'?!R.open(m):o.s&&m.s!==o.s)return false;
  if(o.cat!=null&&o.cat!==''&&(m.cat||0)!==+o.cat)return false;
  if(o.df&&m.df!==o.df)return false;if(o.pr&&m.pr!==o.pr)return false;if(o.main&&!m.main)return false;
  return !t||norm(m.title+' '+m.desc+' '+m.reason).indexOf(t)>=0});
 var po={H:0,M:1,L:2},byTime=function(a,b){return (b.main-a.main)||(a.time||'99').localeCompare(b.time||'99')||a.id-b.id},sort=o.sort||(S.cfg&&S.cfg.sort)||'time';
 l.sort(function(a,b){var d=o.all?a.date.localeCompare(b.date):0;if(d)return o.all?-d:d;
  if(sort==='priority')return po[a.pr]-po[b.pr]||byTime(a,b);if(sort==='xp')return b.xp-a.xp||byTime(a,b);if(sort==='title')return norm(a.title).localeCompare(norm(b.title))||a.id-b.id;return byTime(a,b)});
 return l};
OD.Stats={stats:stats,query:query,xpDate:xpDate,xpBetween:xpBetween,xpOnDay:xpOnDay,norm:norm};
})();
