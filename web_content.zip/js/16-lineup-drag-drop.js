/* ---- drag & drop lineup swapping (pitch <-> bench, pitch <-> pitch, bench <-> bench) ---- */
(function () {
  const L = (...a) => ffmL.apply(null, a);
  const st = document.createElement('style');
  st.textContent = '#screen-tactics .swap-control-box>div,#screen-tactics .swap-control-box>button:not(#best-xi-btn){display:none!important}' +
    '#screen-tactics .pitch-player,#screen-tactics .pl-cell[data-idx]{-webkit-user-select:none;user-select:none;-webkit-touch-callout:none;cursor:grab}' +
    '#screen-tactics .pitch-player{touch-action:none}' +
    '.drag-src{opacity:.35;filter:grayscale(.6)}.drop-hot{outline:3px dashed #ffd23f;outline-offset:2px;background:rgba(255,210,63,.18);border-radius:6px}' +
    '#drag-ghost{position:fixed;z-index:99999;pointer-events:none;opacity:.92;transform:translate(-50%,-50%) scale(1.1);filter:drop-shadow(0 6px 6px rgba(0,0,0,.5))}' +
    '#drag-hint{font-size:12px;color:#9fb3d9;text-align:center;width:100%;flex-basis:100%}';
  document.head.appendChild(st);

  function tag() { // mark every card with its squad index (re-run after each render)
    const pf = document.getElementById('pitch-field'); if (!pf) return;
    pf.querySelectorAll('.pitch-player').forEach((e, i) => e.dataset.idx = i);
    const bc = document.getElementById('bench-list-container');
    if (bc) [...bc.children].forEach((e, i) => { e.dataset.idx = 11 + i; });
    const box = document.querySelector('#screen-tactics .swap-control-box');
    if (box && !document.getElementById('drag-hint')) { const h = document.createElement('div'); h.id = 'drag-hint'; box.insertBefore(h, box.firstChild); }
    const h = document.getElementById('drag-hint');
    if (h) h.textContent = '✋ ' + L('اسحب لاعبًا وأفلته فوق لاعب آخر لتبديل مكانيهما', 'Drag a player and drop him onto another to swap places', 'Glisse un joueur sur un autre pour échanger leurs places', 'Arrastra un jugador sobre otro para intercambiarlos', 'Arraste um jogador sobre outro para trocá-los', 'Ziehe einen Spieler auf einen anderen, um sie zu tauschen', 'Bir oyuncuyu sürükleyip başkasının üstüne bırakarak yer değiştir');
  }
  const _rtp = window.renderTacticalPitch;
  window.renderTacticalPitch = function () { const r = _rtp.apply(this, arguments); try { tag(); } catch (_) {} return r; };

  let D = null; // active gesture
  const cardOf = (el) => el && el.closest ? el.closest('#screen-tactics .pitch-player[data-idx], #screen-tactics .pl-cell[data-idx]') : null;
  function clear() {
    if (!D) return; clearTimeout(D.timer); cancelAnimationFrame(D.raf);
    if (D.ghost) D.ghost.remove(); if (D.src) D.src.classList.remove('drag-src'); if (D.hot) D.hot.classList.remove('drop-hot');
    try { if (D.src && D.src.releasePointerCapture) D.src.releasePointerCapture(D.id); } catch (_) {}
    D = null;
  }
  function beginDrag() {
    if (!D || D.on) return; D.on = true;
    const r = D.src.getBoundingClientRect(), g = D.src.cloneNode(true); g.id = 'drag-ghost'; g.removeAttribute('data-idx'); g.className += ' ';
    g.style.width = r.width + 'px'; g.style.left = D.x + 'px'; g.style.top = D.y + 'px'; g.style.bottom = 'auto'; g.style.margin = '0';
    document.body.appendChild(g); D.ghost = g; D.src.classList.add('drag-src');
    if (navigator.vibrate) { try { navigator.vibrate(12); } catch (_) {} }
    const loop = () => { if (!D || !D.on) return; const h = innerHeight; if (D.y < 80) scrollBy(0, -14); else if (D.y > h - 80) scrollBy(0, 14); D.raf = requestAnimationFrame(loop); };
    D.raf = requestAnimationFrame(loop);
  }
  function hit(x, y) {
    if (D.ghost) D.ghost.style.display = 'none';
    const el = document.elementFromPoint(x, y); if (D.ghost) D.ghost.style.display = '';
    const c = cardOf(el); return c && c !== D.src ? c : null;
  }
  document.addEventListener('pointerdown', (e) => {
    if (D) clear();
    if (e.button != null && e.button > 0) return;
    const c = cardOf(e.target); if (!c) return;
    D = { src: c, id: e.pointerId, x: e.clientX, y: e.clientY, sx: e.clientX, sy: e.clientY, on: false, touch: e.pointerType !== 'mouse', bench: c.classList.contains('pl-cell') };
    // bench cards live on a vertically scrolling page: touch needs a short press-and-hold; pitch cards / mouse drag right away
    if (D.touch && D.bench) D.timer = setTimeout(beginDrag, 260);
  }, true);
  document.addEventListener('pointermove', (e) => {
    if (!D || e.pointerId !== D.id) return;
    D.x = e.clientX; D.y = e.clientY; const mv = Math.hypot(D.x - D.sx, D.y - D.sy);
    if (!D.on) {
      if (D.touch && D.bench) { if (mv > 10) { clearTimeout(D.timer); D = null; } return; } // user is scrolling
      if (mv > 6) beginDrag(); else return;
    }
    if (!D) return;
    e.preventDefault(); D.ghost.style.left = D.x + 'px'; D.ghost.style.top = D.y + 'px';
    const t = hit(D.x, D.y); if (t !== D.hot) { if (D.hot) D.hot.classList.remove('drop-hot'); if (t) t.classList.add('drop-hot'); D.hot = t; }
  }, true);
  const finish = (e, cancel) => {
    if (!D || e.pointerId !== D.id) return;
    const on = D.on, a = +D.src.dataset.idx; let b = -1;
    if (on && !cancel) { const t = hit(e.clientX, e.clientY); if (t) b = +t.dataset.idx; }
    clear();
    if (on && b >= 0 && a !== b) swap(a, b);
  };
  document.addEventListener('pointerup', (e) => finish(e, false), true);
  document.addEventListener('pointercancel', (e) => finish(e, true), true);
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') clear(); });
  document.addEventListener('contextmenu', (e) => { if (cardOf(e.target)) e.preventDefault(); }, true);
  document.addEventListener('touchmove', (e) => { if (D && D.on && e.cancelable) e.preventDefault(); }, { passive: false });
  // clicking right after a drag must not trigger anything else
  document.addEventListener('click', (e) => { if (window.__ffmDragJust && cardOf(e.target)) { e.stopPropagation(); e.preventDefault(); } }, true);

  function swap(a, b) {
    const team = state.teams[matchContext.myTeamId]; if (!team || !team.players[a] || !team.players[b]) return;
    const t = team.players[a]; team.players[a] = team.players[b]; team.players[b] = t;
    team.players.forEach((p, i) => { if (p) p.onBench = i >= 11; });
    window.__ffmDragJust = true; setTimeout(() => { window.__ffmDragJust = false; }, 350);
    saveGame(); renderTacticalPitch();
    try { if (window.FFMSfx && FFMSfx.click) FFMSfx.click(); } catch (_) {}
    requestAnimationFrame(() => [a, b].forEach(i => { const e = document.querySelector('#screen-tactics [data-idx="' + i + '"]'); if (e && e.animate) e.animate([{ transform: 'scale(1.25)', filter: 'brightness(1.5)' }, { transform: 'scale(1)', filter: 'none' }], { duration: 320, easing: 'ease-out' }); }));
  }
  window.ffmDragSwap = swap;
})();
