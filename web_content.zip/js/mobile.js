/* mobile.js — تعداد کارت‌های دست را در متغیر CSS به نام --n روی #hand می‌نویسد
   تا css/mobile.css هم‌پوشانی کارت‌ها را طوری حساب کند که همه در عرض صفحه جا شوند.
   (تابع draw در app.js هر بار همه کارت‌ها را از نو می‌سازد؛ MutationObserver آن را می‌گیرد.) */
(function(){
  'use strict';
  var hand=document.getElementById('hand');
  if(!hand||!window.MutationObserver)return;
  function sync(){ hand.style.setProperty('--n',String(hand.children.length||1)); }
  new MutationObserver(sync).observe(hand,{childList:true});
  sync();
})();
