// ===== CONTROLS: touch joystick, look-drag, buttons, keyboard fallback =====
// ===== AUDIO: procedural sound via Web Audio -- no files to load or license =====

let cameraYaw = 0;

const touchState = {
  moveX: 0, moveY: 0,
  firing: false, fireCd: 0,
  jumpQueued: false,
  enterQueued: false,
};

const isTouchDevice = ('ontouchstart' in window) || (navigator.maxTouchPoints > 0);

function setupTouchControls() {
  const joyBase = document.getElementById('joystickBase');
  const joyStick = document.getElementById('joystickStick');
  let joyId = null, joyRect = null;

  function joyMove(x, y) {
    if (joyId === null || !joyRect) return;
    const cx = joyRect.left + joyRect.width / 2;
    const cy = joyRect.top + joyRect.height / 2;
    let dx = x - cx, dy = y - cy;
    const maxR = joyRect.width / 2;
    const dist = Math.hypot(dx, dy);
    if (dist > maxR) { dx = (dx / dist) * maxR; dy = (dy / dist) * maxR; }
    joyStick.style.transform = `translate(${dx}px, ${dy}px)`;
    touchState.moveX = dx / maxR;
    touchState.moveY = dy / maxR;
  }
  function joyEnd() {
    joyId = null; joyRect = null;
    joyStick.style.transform = 'translate(0px, 0px)';
    touchState.moveX = 0; touchState.moveY = 0;
  }
  joyBase.addEventListener('touchstart', e => {
    e.preventDefault();
    const t = e.changedTouches[0];
    joyId = t.identifier;
    joyRect = joyBase.getBoundingClientRect();
    joyMove(t.clientX, t.clientY);
  }, { passive: false });
  joyBase.addEventListener('touchmove', e => {
    e.preventDefault();
    for (const t of e.changedTouches) if (t.identifier === joyId) joyMove(t.clientX, t.clientY);
  }, { passive: false });
  joyBase.addEventListener('touchend', e => {
    e.preventDefault();
    for (const t of e.changedTouches) if (t.identifier === joyId) joyEnd();
  }, { passive: false });

  const lookZone = document.getElementById('lookZone');
  let lookId = null, lastX = 0;
  lookZone.addEventListener('touchstart', e => {
    e.preventDefault();
    const t = e.changedTouches[0];
    lookId = t.identifier; lastX = t.clientX;
  }, { passive: false });
  lookZone.addEventListener('touchmove', e => {
    e.preventDefault();
    for (const t of e.changedTouches) {
      if (t.identifier === lookId) {
        cameraYaw -= (t.clientX - lastX) * 0.006;
        lastX = t.clientX;
      }
    }
  }, { passive: false });
  lookZone.addEventListener('touchend', e => {
    for (const t of e.changedTouches) if (t.identifier === lookId) lookId = null;
  });

  document.getElementById('btnFire').addEventListener('touchstart', e => { e.preventDefault(); touchState.firing = true; }, { passive: false });
  document.getElementById('btnFire').addEventListener('touchend', e => { e.preventDefault(); touchState.firing = false; }, { passive: false });
  document.getElementById('btnJump').addEventListener('touchstart', e => { e.preventDefault(); touchState.jumpQueued = true; }, { passive: false });
  document.getElementById('btnEnter').addEventListener('touchstart', e => { e.preventDefault(); touchState.enterQueued = true; }, { passive: false });
}
if (isTouchDevice) setupTouchControls();

// ---- Keyboard + mouse fallback, handy for testing on a desktop browser ----
const keys = {};
window.addEventListener('keydown', e => {
  keys[e.key.toLowerCase()] = true;
  if (e.key === ' ') touchState.jumpQueued = true;
  if (e.key.toLowerCase() === 'e') touchState.enterQueued = true;
});
window.addEventListener('keyup', e => { keys[e.key.toLowerCase()] = false; });

let mouseLooking = false;
renderer.domElement.addEventListener('mousedown', () => { mouseLooking = true; touchState.firing = true; });
window.addEventListener('mouseup', () => { mouseLooking = false; touchState.firing = false; });
window.addEventListener('mousemove', e => { if (mouseLooking) cameraYaw -= e.movementX * 0.004; });

function applyKeyboardMovement() {
  if (isTouchDevice) return;
  let mx = 0, my = 0;
  if (keys['w']) my -= 1;
  if (keys['s']) my += 1;
  if (keys['a']) mx -= 1;
  if (keys['d']) mx += 1;
  const len = Math.hypot(mx, my) || 1;
  touchState.moveX = mx / len;
  touchState.moveY = my / len;
}

// ---- Procedural audio ----
let audioCtx = null;
let soundOn = true;
let musicOn = true;
let musicGain = null;

function initAudio() {
  if (audioCtx) return;
  audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  startAmbientMusic();
}

function beep(freq, duration, type, peak) {
  if (!audioCtx || !soundOn) return;
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  osc.type = type || 'square';
  osc.frequency.value = freq;
  gain.gain.setValueAtTime(0.0001, audioCtx.currentTime);
  gain.gain.exponentialRampToValueAtTime(peak || 0.2, audioCtx.currentTime + 0.01);
  gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + duration);
  osc.connect(gain);
  gain.connect(audioCtx.destination);
  osc.start();
  osc.stop(audioCtx.currentTime + duration + 0.02);
}

function playShoot() { beep(180, 0.09, 'sawtooth', 0.18); }
function playHit() { beep(90, 0.12, 'square', 0.2); }
function playJump() { beep(340, 0.12, 'sine', 0.15); }
function playFootstep() { beep(70, 0.05, 'sine', 0.06); }

function startAmbientMusic() {
  if (!audioCtx) return;
  const osc1 = audioCtx.createOscillator();
  const osc2 = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  osc1.type = 'sine'; osc1.frequency.value = 110;
  osc2.type = 'sine'; osc2.frequency.value = 165;
  gain.gain.value = musicOn ? 0.05 : 0;
  osc1.connect(gain); osc2.connect(gain);
  gain.connect(audioCtx.destination);
  osc1.start(); osc2.start();

  const lfo = audioCtx.createOscillator();
  const lfoGain = audioCtx.createGain();
  lfo.frequency.value = 0.08;
  lfoGain.gain.value = 0.02;
  lfo.connect(lfoGain);
  lfoGain.connect(gain.gain);
  lfo.start();

  musicGain = gain;
}

function setSoundOn(on) { soundOn = on; }
function setMusicOn(on) {
  musicOn = on;
  if (musicGain) musicGain.gain.value = on ? 0.05 : 0;
}
