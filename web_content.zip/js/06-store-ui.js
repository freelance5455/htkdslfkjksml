/* ================= FFM 26 Store (المتجر) — UI + logic ================= */
(function () {
  const D = window.FFMStoreData;
  const $ = (id) => document.getElementById(id);
  const fmt = (n) => Number(n).toLocaleString('en-US');
  const pct = (u) => (u / 10).toFixed(1) + '%';
    /* ---------- i18n (ar / en / fr) ---------- */
  const lang = () => (typeof state !== 'undefined' && state.lang) || 'ar';
  const CN = { // country names en / fr
    BR:['Brazil','Brésil'],AR:['Argentina','Argentine'],FR:['France','France'],ES:['Spain','Espagne'],PT:['Portugal','Portugal'],EN:['England','Angleterre'],DE:['Germany','Allemagne'],IT:['Italy','Italie'],MA:['Morocco','Maroc'],DZ:['Algeria','Algérie'],TN:['Tunisia','Tunisie'],EG:['Egypt','Égypte'],
    SN:['Senegal','Sénégal'],NG:['Nigeria','Nigeria'],GH:['Ghana','Ghana'],CI:['Ivory Coast','Côte d\'Ivoire'],ML:['Mali','Mali'],CM:['Cameroon','Cameroun'],NL:['Netherlands','Pays-Bas'],BE:['Belgium','Belgique'],HR:['Croatia','Croatie'],CH:['Switzerland','Suisse'],SE:['Sweden','Suède'],DK:['Denmark','Danemark'],
    NO:['Norway','Norvège'],PL:['Poland','Pologne'],UA:['Ukraine','Ukraine'],UY:['Uruguay','Uruguay'],CO:['Colombia','Colombie'],CL:['Chile','Chili'],MX:['Mexico','Mexique'],US:['USA','États-Unis'],CA:['Canada','Canada'],JP:['Japan','Japon'],KR:['South Korea','Corée du Sud'],CN:['China','Chine'],SA:['Saudi Arabia','Arabie saoudite'],TR:['Turkey','Turquie'],IR:['Iran','Iran'],QA:['Qatar','Qatar']
  };
  const POSN = { GK:['Goalkeepers','Gardiens'],CB:['Centre-Backs','Défenseurs centraux'],LB:['Left-Backs','Arrières gauches'],RB:['Right-Backs','Arrières droits'],CDM:['Defensive Mids','Milieux défensifs'],CM:['Midfielders','Milieux'],CAM:['Playmakers','Meneurs de jeu'],LW:['Left Wingers','Ailiers gauches'],RW:['Right Wingers','Ailiers droits'],ST:['Strikers','Attaquants'] };
  const REGN = { nafrica:['North Africa','Afrique du Nord'],wafrica:['West & Central Africa','Afrique de l\'Ouest et centrale'],seurope:['Southern Europe','Europe du Sud'],weurope:['Western Europe','Europe de l\'Ouest'],neurope:['Northern & Eastern Europe','Europe du Nord et de l\'Est'],samerica:['South America','Amérique du Sud'],namerica:['North America','Amérique du Nord'],easia:['East Asia','Asie de l\'Est'],mideast:['Middle East','Moyen-Orient'],mix:['Stars From Around The World','Stars du monde entier'] };
  const AGEN = { a17:['Rising Talents','Jeunes talents'],a20:['Promising Players','Espoirs'],a22:['Rising Stars','Étoiles montantes'],a24:['Breakout Generation','Génération montante'],a26:['Peak Years','Années de forme'],a28:['Full Strength','Pleine force'],a30:['Golden Experience','Expérience dorée'],a32:['The Leaders','Les leaders'],a34:['The Veterans','Les vétérans'],a36:['The Legends','Les légendes'] };
  const TIERN = [['Common','Commun'],['Silver','Argent'],['Gold','Or'],['Rare','Rare'],['Epic','Épique'],['Legendary','Légendaire'],['Legend','Légende'],['Rare Legend','Légende rare'],['Icon','Icône']];
  const SECN = { leg:['Legend Packs','Packs Légendes','حزم نخبة غالية الثمن: تقييمات من 92 إلى 94 فقط، وبطاقات بنفسجية لامعة','Expensive elite packs: ratings from 92 to 94 only, with shiny purple cards.','Packs d\'élite coûteux : notes de 92 à 94 uniquement, avec des cartes violettes brillantes.'],
    nat:['National Packs','Packs nationaux','كل حزمة تضم لاعبي منتخب واحد فقط، وعلم الدولة في خلفية الحزمة وبطاقات لاعبيها','Each pack holds players of a single nation only; the national flag is the background of the pack and its cards.','Chaque pack ne contient que des joueurs d\'une seule nation ; le drapeau est en fond du pack et des cartes.'],
    pos:['Position Packs','Packs par poste','كل حزمة تضم لاعبين من مركز واحد فقط: حراس، مدافعون، وسط، مهاجمون...','Each pack holds players of one position only: keepers, defenders, midfielders, strikers…','Chaque pack ne contient que des joueurs d\'un seul poste : gardiens, défenseurs, milieux, attaquants…'],
    reg:['Region Packs','Packs par région','لاعبون من دول منطقة جغرافية واحدة، وكل بطاقة تحمل علم بلد اللاعب','Players from the countries of one geographic region; every card shows the player\'s national flag.','Joueurs des pays d\'une même région ; chaque carte porte le drapeau du joueur.'],
    age:['Age Packs','Packs par âge','كل حزمة تضم لاعبين ضمن فئة عمرية محددة، من المواهب الناشئة إلى المخضرمين','Each pack holds players in a set age range, from young talents to veterans.','Chaque pack contient des joueurs d\'une tranche d\'âge précise, des jeunes talents aux vétérans.'],
    xch:['Token Exchange','Échange de jetons','بدّل التوكن بقسائم فتح الحزم: 1 قسيمة = 4,000 توكن','Swap tokens for pack-opening vouchers: 1 voucher = 4,000 tokens.','Échangez des jetons contre des bons d\'ouverture : 1 bon = 4 000 jetons.'] };
  const XT = {"CN": {"BR": ["Brasil", "Brasil", "Brasilien", "Brezilya"], "AR": ["Argentina", "Argentina", "Argentinien", "Arjantin"], "FR": ["Francia", "França", "Frankreich", "Fransa"], "ES": ["España", "Espanha", "Spanien", "İspanya"], "PT": ["Portugal", "Portugal", "Portugal", "Portekiz"], "EN": ["Inglaterra", "Inglaterra", "England", "İngiltere"], "DE": ["Alemania", "Alemanha", "Deutschland", "Almanya"], "IT": ["Italia", "Itália", "Italien", "İtalya"], "MA": ["Marruecos", "Marrocos", "Marokko", "Fas"], "DZ": ["Argelia", "Argélia", "Algerien", "Cezayir"], "TN": ["Túnez", "Tunísia", "Tunesien", "Tunus"], "EG": ["Egipto", "Egito", "Ägypten", "Mısır"], "SN": ["Senegal", "Senegal", "Senegal", "Senegal"], "NG": ["Nigeria", "Nigéria", "Nigeria", "Nijerya"], "GH": ["Ghana", "Gana", "Ghana", "Gana"], "CI": ["Costa de Marfil", "Costa do Marfim", "Elfenbeinküste", "Fildişi Sahili"], "ML": ["Malí", "Mali", "Mali", "Mali"], "CM": ["Camerún", "Camarões", "Kamerun", "Kamerun"], "NL": ["Países Bajos", "Países Baixos", "Niederlande", "Hollanda"], "BE": ["Bélgica", "Bélgica", "Belgien", "Belçika"], "HR": ["Croacia", "Croácia", "Kroatien", "Hırvatistan"], "CH": ["Suiza", "Suíça", "Schweiz", "İsviçre"], "SE": ["Suecia", "Suécia", "Schweden", "İsveç"], "DK": ["Dinamarca", "Dinamarca", "Dänemark", "Danimarka"], "NO": ["Noruega", "Noruega", "Norwegen", "Norveç"], "PL": ["Polonia", "Polónia", "Polen", "Polonya"], "UA": ["Ucrania", "Ucrânia", "Ukraine", "Ukrayna"], "UY": ["Uruguay", "Uruguai", "Uruguay", "Uruguay"], "CO": ["Colombia", "Colômbia", "Kolumbien", "Kolombiya"], "CL": ["Chile", "Chile", "Chile", "Şili"], "MX": ["México", "México", "Mexiko", "Meksika"], "US": ["EE. UU.", "EUA", "USA", "ABD"], "CA": ["Canadá", "Canadá", "Kanada", "Kanada"], "JP": ["Japón", "Japão", "Japan", "Japonya"], "KR": ["Corea del Sur", "Coreia do Sul", "Südkorea", "Güney Kore"], "CN": ["China", "China", "China", "Çin"], "SA": ["Arabia Saudí", "Arábia Saudita", "Saudi-Arabien", "Suudi Arabistan"], "TR": ["Turquía", "Turquia", "Türkei", "Türkiye"], "IR": ["Irán", "Irão", "Iran", "İran"], "QA": ["Catar", "Catar", "Katar", "Katar"]}, "POSN": {"GK": ["Porteros", "Guarda-redes", "Torhüter", "Kaleciler"], "CB": ["Defensas centrales", "Defesas centrais", "Innenverteidiger", "Stoperler"], "LB": ["Laterales izquierdos", "Laterais esquerdos", "Linksverteidiger", "Sol bekler"], "RB": ["Laterales derechos", "Laterais direitos", "Rechtsverteidiger", "Sağ bekler"], "CDM": ["Mediocentros defensivos", "Médios defensivos", "Defensive Mittelfeldspieler", "Defansif orta saha"], "CM": ["Centrocampistas", "Médios", "Mittelfeldspieler", "Orta saha oyuncuları"], "CAM": ["Mediapuntas", "Médios ofensivos", "Spielmacher", "Oyun kurucular"], "LW": ["Extremos izquierdos", "Extremos esquerdos", "Linksaußen", "Sol kanatlar"], "RW": ["Extremos derechos", "Extremos direitos", "Rechtsaußen", "Sağ kanatlar"], "ST": ["Delanteros", "Avançados", "Stürmer", "Forvetler"]}, "REGN": {"nafrica": ["Norte de África", "Norte de África", "Nordafrika", "Kuzey Afrika"], "wafrica": ["África occidental y central", "África Ocidental e Central", "West- und Zentralafrika", "Batı ve Orta Afrika"], "seurope": ["Sur de Europa", "Sul da Europa", "Südeuropa", "Güney Avrupa"], "weurope": ["Europa occidental", "Europa Ocidental", "Westeuropa", "Batı Avrupa"], "neurope": ["Norte y este de Europa", "Norte e Leste da Europa", "Nord- und Osteuropa", "Kuzey ve Doğu Avrupa"], "samerica": ["Sudamérica", "América do Sul", "Südamerika", "Güney Amerika"], "namerica": ["Norteamérica", "América do Norte", "Nordamerika", "Kuzey Amerika"], "easia": ["Asia oriental", "Ásia Oriental", "Ostasien", "Doğu Asya"], "mideast": ["Oriente Medio", "Médio Oriente", "Naher Osten", "Orta Doğu"], "mix": ["Estrellas de todo el mundo", "Estrelas de todo o mundo", "Stars aus aller Welt", "Dünyanın dört bir yanından yıldızlar"]}, "AGEN": {"a17": ["Jóvenes talentos", "Jovens talentos", "Junge Talente", "Genç yetenekler"], "a20": ["Promesas", "Promessas", "Hoffnungsträger", "Gelecek vaat edenler"], "a22": ["Estrellas emergentes", "Estrelas emergentes", "Aufstrebende Stars", "Yükselen yıldızlar"], "a24": ["Generación de despegue", "Geração de arranque", "Durchstarter-Generation", "Atılım kuşağı"], "a26": ["Años de plenitud", "Anos de plenitude", "Beste Jahre", "Zirve yılları"], "a28": ["Plena fuerza", "Força total", "Volle Kraft", "Tam güç"], "a30": ["Experiencia dorada", "Experiência dourada", "Goldene Erfahrung", "Altın tecrübe"], "a32": ["Los líderes", "Os líderes", "Die Anführer", "Liderler"], "a34": ["Los veteranos", "Os veteranos", "Die Veteranen", "Veteranlar"], "a36": ["Las leyendas", "As lendas", "Die Legenden", "Efsaneler"]}, "TIERN": [["Común", "Comum", "Gewöhnlich", "Sıradan"], ["Plata", "Prata", "Silber", "Gümüş"], ["Oro", "Ouro", "Gold", "Altın"], ["Rara", "Rara", "Selten", "Nadir"], ["Épica", "Épica", "Episch", "Destansı"], ["Legendaria", "Lendária", "Legendär", "Efsanevi"], ["Leyenda", "Lenda", "Legende", "Efsane"], ["Leyenda rara", "Lenda rara", "Seltene Legende", "Nadir efsane"], ["Icono", "Ícone", "Ikone", "İkon"]], "TRAITN": {"clinical": ["Definidor letal", "Finalizador letal", "Eiskalter Vollstrecker", "Soğukkanlı Golcü"], "passer": ["Pasador de precisión", "Passador de precisão", "Präzisionspasser", "Hassas pasör"], "tackler": ["Entrada firme", "Desarmador forte", "Starker Zweikämpfer", "Güçlü top çalıcı"], "speed": ["Velocista", "Velocista", "Sprinter", "Hız canavarı"], "keeper": ["Reflejos rápidos", "Reflexos rápidos", "Schnelle Reflexe", "Hızlı refleksler"]}, "SECN": {"leg": ["Sobres de leyendas", "Pacotes de lendas", "Legenden-Packs", "Efsane Paketleri", "Sobres de élite caros: solo valoraciones de 92 a 94, con cartas moradas brillantes.", "Pacotes de elite caros: apenas classificações de 92 a 94, com cartas roxas brilhantes.", "Teure Elite-Packs: nur Wertungen von 92 bis 94, mit glänzenden lila Karten.", "Pahalı elit paketler: yalnızca 92 ile 94 arası puanlar ve parlak mor kartlar."], "nat": ["Sobres nacionales", "Pacotes nacionais", "Nationen-Packs", "Ulusal Paketler", "Cada sobre trae jugadores de una sola selección; la bandera del país es el fondo del sobre y de sus cartas.", "Cada pacote traz jogadores de uma só seleção; a bandeira do país é o fundo do pacote e das suas cartas.", "Jedes Pack enthält nur Spieler einer Nation; die Landesflagge ist der Hintergrund von Pack und Karten.", "Her paket tek bir ülkenin oyuncularını içerir; ülke bayrağı paketin ve kartlarının arka planıdır."], "pos": ["Sobres por posición", "Pacotes por posição", "Positions-Packs", "Mevki Paketleri", "Cada sobre trae jugadores de una sola posición: porteros, defensas, centrocampistas, delanteros…", "Cada pacote traz jogadores de uma só posição: guarda-redes, defesas, médios, avançados…", "Jedes Pack enthält nur Spieler einer Position: Torhüter, Verteidiger, Mittelfeldspieler, Stürmer …", "Her paket tek bir mevkiden oyuncular içerir: kaleciler, defans, orta saha, forvetler…"], "reg": ["Sobres por región", "Pacotes por região", "Regionen-Packs", "Bölge Paketleri", "Jugadores de países de una misma región geográfica; cada carta muestra la bandera del jugador.", "Jogadores de países de uma mesma região geográfica; cada carta mostra a bandeira do jogador.", "Spieler aus Ländern einer geografischen Region; jede Karte zeigt die Flagge des Spielers.", "Aynı coğrafi bölgedeki ülkelerin oyuncuları; her kart oyuncunun bayrağını taşır."], "age": ["Sobres por edad", "Pacotes por idade", "Alters-Packs", "Yaş Paketleri", "Cada sobre trae jugadores de un rango de edad concreto, desde jóvenes talentos hasta veteranos.", "Cada pacote traz jogadores de uma faixa etária definida, dos jovens talentos aos veteranos.", "Jedes Pack enthält Spieler einer bestimmten Altersgruppe, von jungen Talenten bis zu Veteranen.", "Her paket belirli bir yaş aralığından oyuncular içerir; genç yeteneklerden veteranlara kadar."], "xch": ["Canje de fichas", "Troca de fichas", "Token-Tausch", "Jeton Takası", "Cambia fichas por vales para abrir sobres: 1 vale = 4000 fichas.", "Troque fichas por vales de abertura: 1 vale = 4000 fichas.", "Tausche Tokens gegen Pack-Gutscheine: 1 Gutschein = 4.000 Tokens.", "Jetonları paket açma kuponlarıyla takas et: 1 kupon = 4.000 jeton."]}, "TR": [["Tienda", "Loja", "Shop", "Mağaza"], ["Vale de apertura de sobres", "Vale de abertura de pacotes", "Pack-Gutschein", "Paket Açma Kuponu"], ["Fichas", "Fichas", "Tokens", "Jeton"], ["Compra sobres con vales de apertura 🎟️ — cambia fichas por vales en la sección «Canje de fichas».", "Compre pacotes com vales de abertura 🎟️ — troque fichas por vales na secção «Troca de fichas».", "Kaufe Packs mit Pack-Gutscheinen 🎟️ — tausche Tokens im Bereich „Token-Tausch“ gegen Gutscheine.", "Paketleri açma kuponlarıyla satın al 🎟️ — jetonları «Jeton Takası» bölümünde kuponla değiştir."], ["Jugadores de la tienda", "Jogadores da loja", "Shop-Spieler", "Mağaza Oyuncuları"], ["Jugadores que obtuviste de los sobres", "Jogadores que obteve dos pacotes", "Spieler, die du aus Packs erhalten hast", "Paketlerden elde ettiğin oyuncular"], ["Volver", "Voltar", "Zurück", "Geri"], ["Valoración", "Classificação", "Wertung", "Puan"], ["Precio", "Preço", "Preis", "Fiyat"], ["Abrir sobre", "Abrir pacote", "Pack öffnen", "Paketi aç"], ["vale(s)", "vale(s)", "Gutschein(e)", "kupon"], ["Detalles del sobre", "Detalhes do pacote", "Pack-Details", "Paket Detayları"], ["Detalles", "Detalhes", "Details", "Detaylar"], ["No disponible (0 %)", "Indisponível (0%)", "Nicht verfügbar (0 %)", "Mevcut değil (%0)"], ["No hay cartas con esta valoración en este sobre", "Não há cartas com esta classificação neste pacote", "Keine Karten mit dieser Wertung in diesem Pack", "Bu pakette bu puanda kart yok"], ["Valoración mín.", "Classificação mín.", "Min. Wertung", "En düşük puan"], ["Valoración máx.", "Classificação máx.", "Max. Wertung", "En yüksek puan"], ["Total", "Total", "Gesamt", "Toplam"], ["Vales insuficientes", "Vales insuficientes", "Nicht genug Gutscheine", "Yetersiz kupon"], ["Necesitas {p} vale(s) para abrir este sobre; tu saldo es {b}.<br>Cambia fichas por vales en «Canje de fichas».", "Precisa de {p} vale(s) para abrir este pacote; o seu saldo é {b}.<br>Troque fichas por vales em «Troca de fichas».", "Du brauchst {p} Gutschein(e), um dieses Pack zu öffnen; dein Guthaben ist {b}.<br>Tausche Tokens im „Token-Tausch“ gegen Gutscheine.", "Bu paketi açmak için {p} kupon gerekiyor; bakiyen {b}.<br>Jetonları «Jeton Takası»nda kuponla değiştir."], ["Abriendo sobre…", "A abrir pacote…", "Pack wird geöffnet …", "Paket açılıyor…"], ["Saltar ⏭", "Saltar ⏭", "Überspringen ⏭", "Atla ⏭"], ["Probabilidad de este nivel en el sobre", "Probabilidade deste nível no pacote", "Chance auf diese Stufe im Pack", "Bu seviyenin pakette çıkma şansı"], ["Contrato de {n} partidos • renovable", "Contrato de {n} jogos • renovável", "{n}-Spiele-Vertrag • verlängerbar", "{n} maçlık sözleşme • yenilenebilir"], ["Contrato: {n} partidos • renovable", "Contrato: {n} jogos • renovável", "Vertrag: {n} Spiele • verlängerbar", "Sözleşme: {n} maç • yenilenebilir"], ["➕ Añadir a la plantilla", "➕ Adicionar ao plantel", "➕ Zum Kader hinzufügen", "➕ Kadroya ekle"], ["🎟️ Abrir otro ({p})", "🎟️ Abrir outro ({p})", "🎟️ Noch eins öffnen ({p})", "🎟️ Bir tane daha aç ({p})"], ["Cerrar", "Fechar", "Schließen", "Kapat"], ["Vales insuficientes para abrir otro sobre.", "Vales insuficientes para abrir outro pacote.", "Nicht genug Gutscheine für ein weiteres Pack.", "Bir paket daha açmak için kupon yetmiyor."], ["Aviso", "Aviso", "Hinweis", "Uyarı"], ["Este jugador ya está en tu plantilla.", "Este jogador já está no seu plantel.", "Dieser Spieler ist bereits in deinem Kader.", "Bu oyuncu zaten kadronda."], ["Sin hueco", "Sem espaço", "Kein Platz", "Yer yok"], ["No hay ningún suplente que se pueda reemplazar.", "Não há nenhum suplente que possa ser substituído.", "Es gibt keinen Ersatzspieler, der ersetzt werden kann.", "Değiştirilebilecek yedek oyuncu yok."], ["✔ Añadido", "✔ Adicionado", "✔ Hinzugefügt", "✔ Eklendi"], ["✔ Jugador añadido", "✔ Jogador adicionado", "✔ Spieler hinzugefügt", "✔ Oyuncu eklendi"], ["{a} ({r}) se ha unido a tu plantilla (n.º {n}).<br>Tamaño de la plantilla: {c}.<br>Contrato: 10 partidos — ponlo en la alineación desde la pantalla de táctica.", "{a} ({r}) juntou-se ao seu plantel (n.º {n}).<br>Tamanho do plantel: {c}.<br>Contrato: 10 jogos — coloque-o na equipa a partir do ecrã de tática.", "{a} ({r}) ist deinem Kader beigetreten (Nr. {n}).<br>Kadergröße: {c}.<br>Vertrag: 10 Spiele — stelle ihn im Taktik-Bildschirm auf.", "{a} ({r}) kadrona katıldı (no. {n}).<br>Kadro sayısı: {c}.<br>Sözleşme: 10 maç — onu taktik ekranından ilk 11'e al."], ["Plantilla completa", "Plantel completo", "Kader voll", "Kadro dolu"], ["Tu plantilla llegó a {n} jugadores. Primero vende algunos desde «Vender jugadores».", "O seu plantel chegou a {n} jogadores. Venda alguns primeiro em «Vender jogadores».", "Dein Kader hat {n} Spieler erreicht. Verkaufe zuerst einige unter „Spieler verkaufen“.", "Kadron {n} oyuncuya ulaştı. Önce «Oyuncu sat» bölümünden bazılarını sat."], ["✔ En tu plantilla", "✔ No seu plantel", "✔ In deinem Kader", "✔ Kadronda"], ["Aún no has conseguido ningún jugador de la tienda.", "Ainda não obteve nenhum jogador da loja.", "Du hast noch keinen Spieler aus dem Shop erhalten.", "Henüz mağazadan oyuncu edinmedin."], ["Canje de fichas", "Troca de fichas", "Token-Tausch", "Jeton Takası"], ["1 vale de apertura = {t} fichas", "1 vale de abertura = {t} fichas", "1 Pack-Gutschein = {t} Tokens", "1 paket açma kuponu = {t} jeton"], ["Canjear", "Trocar", "Tauschen", "Takas et"], ["Fichas insuficientes", "Fichas insuficientes", "Nicht genug Tokens", "Yetersiz jeton"], ["Necesitas {t} fichas; tu saldo es {b}.", "Precisa de {t} fichas; o seu saldo é {b}.", "Du brauchst {t} Tokens; dein Guthaben ist {b}.", "{t} jeton gerekiyor; bakiyen {b}."], ["Canje completado", "Troca concluída", "Tausch abgeschlossen", "Takas tamamlandı"], ["Se descontaron {t} fichas y se añadieron {v} vale(s).<br>🪙 {a} • 🎟️ {b}", "Foram descontadas {t} fichas e adicionados {v} vale(s).<br>🪙 {a} • 🎟️ {b}", "{t} Tokens abgezogen und {v} Gutschein(e) hinzugefügt.<br>🪙 {a} • 🎟️ {b}", "{t} jeton düşüldü ve {v} kupon eklendi.<br>🪙 {a} • 🎟️ {b}"], ["Elige al jugador a reemplazar", "Escolha o jogador a substituir", "Wähle den Spieler zum Ersetzen", "Değiştirilecek oyuncuyu seç"], ["Titular", "Titular", "Stammspieler", "İlk 11"], ["Banquillo", "Banco", "Bank", "Yedek"], ["Cancelar", "Cancelar", "Abbrechen", "İptal"], ["Rasgo", "Traço", "Eigenschaft", "Yetenek"], ["¡Garantía de suerte activada!", "Garantia de sorte ativada!", "Glücksgarantie ausgelöst!", "Şans garantisi devreye girdi!"], ["Garantía de suerte: {n}/{m} — al llegar al límite tu próximo sobre tendrá una valoración mayor garantizada", "Garantia de sorte: {n}/{m} — ao atingir o limite, o seu próximo pacote terá uma classificação superior garantida", "Glücksgarantie: {n}/{m} — am Limit ist dir im nächsten Pack eine höhere Wertung garantiert", "Şans garantisi: {n}/{m} — sınıra ulaşınca bir sonraki paketinde daha yüksek puan garantili"], ["Las probabilidades de arriba son la tirada normal; la garantía de suerte actúa además de ellas (el contador se ve en la pantalla del sobre).", "As probabilidades acima são o sorteio normal; a garantia de sorte atua para além delas (o contador aparece no ecrã do pacote).", "Die obigen Chancen sind der normale Wurf; die Glücksgarantie wirkt zusätzlich (Zähler im Pack-Bildschirm).", "Yukarıdaki olasılıklar normal çekilişe aittir; şans garantisi bunların üzerine eklenir (sayaç paket ekranında görünür)."], ["Ofertas por tiempo limitado", "Ofertas por tempo limitado", "Zeitlich begrenzte Angebote", "Sınırlı süreli teklifler"], ["Oferta -{d} %", "Oferta -{d}%", "Angebot -{d} %", "Teklif -%{d}"], ["♻️ Fusionar duplicados", "♻️ Fundir duplicados", "♻️ Duplikate verschmelzen", "♻️ Kopyaları birleştir"], ["No hay cartas duplicadas.", "Não há cartas duplicadas.", "Keine doppelten Karten.", "Kopya kart yok."], ["Se fusionaron {n} cartas duplicadas: 🔩 {s} fragmentos y 🪙 {t} fichas.", "Foram fundidas {n} cartas duplicadas: 🔩 {s} fragmentos e 🪙 {t} fichas.", "{n} doppelte Karten verschmolzen: 🔩 {s} Splitter und 🪙 {t} Tokens.", "{n} kopya kart birleştirildi: 🔩 {s} parça ve 🪙 {t} jeton."], ["OK", "OK", "OK", "Tamam"], ["años", "anos", "J.", "yaş"]], "TEMPL": {"pack": ["Sobre de {n}", "Pacote de {n}", "{n}-Pack", "{n} Paketi"], "leg": ["Sobre de leyendas de {n}", "Pacote de lendas de {n}", "Legenden-Pack {n}", "{n} Efsane Paketi"], "tl_leg": ["Leyendas de {n} — valoración 92 a 94", "Lendas de {n} — classificação 92 a 94", "Legenden aus {n} — Wertung 92 bis 94", "{n} efsaneleri — puan 92 ile 94"], "tl_nat": ["Todos los jugadores de {n}", "Todos os jogadores de {n}", "Alle Spieler aus {n}", "Tüm {n} oyuncuları"], "tl_pos": ["Solo jugadores {p}", "Apenas jogadores {p}", "Nur {p}-Spieler", "Yalnızca {p} oyuncuları"], "tl_reg": ["Países: ", "Países: ", "Länder: ", "Ülkeler: "], "tl_age": ["Jugadores de {a} a {b} años", "Jogadores dos {a} aos {b} anos", "Spieler im Alter von {a} bis {b} Jahren", "{a} - {b} yaş arası oyuncular"]}};
  const LI = { en: 1, fr: 2, es: 3, pt: 4, de: 5, tr: 6 };
  const LIDX = { ar: 0, en: 1, fr: 2, es: 3, pt: 4, de: 5, tr: 6 };
  const NEWL = l => l !== 'ar' && l !== 'en' && l !== 'fr';
  [['CN', CN], ['POSN', POSN], ['REGN', REGN], ['AGEN', AGEN]].forEach(p => { Object.keys(p[1]).forEach(k => { p[1][k] = p[1][k].concat(XT[p[0]][k] || [p[1][k][0], p[1][k][0], p[1][k][0], p[1][k][0]]); }); });
  TIERN.forEach((r, i) => { TIERN[i] = r.concat(XT.TIERN[i]); });
  function secName(sec) { const r = SECN[sec.id], l = lang(); return l === 'ar' ? sec.name : (NEWL(l) ? XT.SECN[sec.id][LI[l] - 3] : r[LI[l] - 1]); }
  function secDesc(sec) { const r = SECN[sec.id], l = lang(); return l === 'ar' ? r[2] : (NEWL(l) ? XT.SECN[sec.id][4 + LI[l] - 3] : r[2 + LI[l]]); }
  function countryName(c) { return lang() === 'ar' ? (D.COUNTRY_AR[c] || c) : (CN[c] ? CN[c][LI[lang()] - 1] : c); }
  function tierName(i) { return lang() === 'ar' ? D.TIERS[i].name : TIERN[i][LI[lang()] - 1]; }
  function packName(p) {
    const l = lang(); if (l === 'ar') return p.name; const k = LI[l] - 1;
    let n; if (p.theme === 'nat') n = CN[p.countries[0]][k]; else if (p.theme === 'pos') n = POSN[p.posCode][k]; else if (p.theme === 'reg') n = REGN[p.id.slice(4)][k]; else if (p.theme === 'leg') n = CN[p.countries[0]][k]; else n = AGEN[p.id.slice(4)][k];
    if (NEWL(l)) { const i = LI[l] - 3; return XT.TEMPL[p.theme === 'leg' ? 'leg' : 'pack'][i].replace('{n}', n); }
    if (p.theme === 'leg') return l === 'en' ? n + ' Legends Pack' : 'Pack Légendes ' + n;
    return l === 'en' ? n + ' Pack' : 'Pack ' + n;
  }
  function tagline(p) {
    const l = lang(), k = LI[l] - 1; if (l === 'ar') return p.tagline;
    if (NEWL(l)) {
      const i = LI[l] - 3, T = XT.TEMPL, cn = c => CN[c][k];
      if (p.theme === 'leg') return T.tl_leg[i].replace('{n}', cn(p.countries[0]));
      if (p.theme === 'nat') return T.tl_nat[i].replace('{n}', cn(p.countries[0]));
      if (p.theme === 'pos') return T.tl_pos[i].replace('{p}', p.posCode);
      if (p.theme === 'reg') return T.tl_reg[i] + p.countries.map(cn).join(', ');
      return T.tl_age[i].replace('{a}', p.age[0]).replace('{b}', p.age[1]);
    }
    if (p.theme === 'leg') return l === 'en' ? 'Legends of ' + CN[p.countries[0]][k] + ' — rating 92 to 94' : 'Légendes de ' + CN[p.countries[0]][k] + ' — note 92 à 94';
    if (p.theme === 'nat') return (l === 'en' ? 'All ' : 'Tous les joueurs de ').concat(CN[p.countries[0]][k]) + (l === 'en' ? ' players' : '');
    if (p.theme === 'pos') return l === 'en' ? 'Only ' + p.posCode + ' players' : 'Uniquement des joueurs ' + p.posCode;
    if (p.theme === 'reg') return (l === 'en' ? 'Countries: ' : 'Pays : ') + p.countries.map(c => CN[c][k]).join(', ');
    return l === 'en' ? `Players aged ${p.age[0]} to ${p.age[1]}` : `Joueurs de ${p.age[0]} à ${p.age[1]} ans`;
  }
  const TR = {
    store: ['المتجر', 'Store', 'Boutique'], vchTitle: ['قسيمة فتح الحزم', 'Pack Opening Voucher', 'Bon d\'ouverture de packs'], tokens: ['توكن', 'Tokens', 'Jetons'],
    intro: ['اشترِ الحزم بقسائم فتح الحزم 🎟️ — وبدّل التوكن بالقسائم من قسم «مبادلة التوكن».', 'Buy packs with Pack Opening Vouchers 🎟️ — swap tokens for vouchers in the “Token Exchange” section.', 'Achetez des packs avec des bons d\'ouverture 🎟️ — échangez vos jetons contre des bons dans « Échange de jetons ».'],
    invT: ['لاعبو المتجر', 'Store Players', 'Joueurs de la boutique'], invD: ['اللاعبون الذين حصلت عليهم من الحزم', 'Players you obtained from packs', 'Joueurs obtenus dans les packs'],
    back: ['رجوع', 'Back', 'Retour'], rating: ['التقييم', 'Rating', 'Note'], price: ['السعر', 'Price', 'Prix'], openPack: ['فتح الحزمة', 'Open Pack', 'Ouvrir le pack'], voucherWord: ['قسيمة', 'voucher(s)', 'bon(s)'],
    details: ['تفاصيل الحزمة', 'Pack Details', 'Détails du pack'], detailsOf: ['تفاصيل', 'Details', 'Détails'], unavail: ['غير متاحة (0%)', 'Not available (0%)', 'Indisponible (0%)'], noCards: ['لا توجد بطاقات بهذا التقييم في هذه الحزمة', 'No cards of this rating in this pack', 'Aucune carte de cette note dans ce pack'],
    minR: ['أقل تقييم', 'Min rating', 'Note min'], maxR: ['أعلى تقييم', 'Max rating', 'Note max'], total: ['المجموع', 'Total', 'Total'],
    noVch: ['قسائم غير كافية', 'Not enough vouchers', 'Bons insuffisants'], needVch: ['تحتاج {p} قسيمة لفتح هذه الحزمة، ورصيدك {b}.<br>بدّل التوكن بقسائم من قسم «مبادلة التوكن».', 'You need {p} voucher(s) to open this pack; your balance is {b}.<br>Swap tokens for vouchers in “Token Exchange”.', 'Il faut {p} bon(s) pour ouvrir ce pack ; votre solde est {b}.<br>Échangez des jetons dans « Échange de jetons ».'],
    opening: ['جارٍ فتح الحزمة…', 'Opening pack…', 'Ouverture du pack…'], skip: ['تخطي ⏭', 'Skip ⏭', 'Passer ⏭'], prob: ['احتمال هذه الفئة في الحزمة', 'Chance of this tier in the pack', 'Probabilité de cette catégorie'],
    contract: ['عقد {n} مباريات • قابل للتجديد', '{n}-match contract • renewable', 'Contrat de {n} matchs • renouvelable'], contractI: ['عقد: {n} مباريات • قابل للتجديد', 'Contract: {n} matches • renewable', 'Contrat : {n} matchs • renouvelable'],
    join: ['➕ ضم إلى الفريق', '➕ Add to squad', '➕ Ajouter à l\'équipe'], again: ['🎟️ فتح أخرى ({p})', '🎟️ Open another ({p})', '🎟️ En ouvrir un autre ({p})'], close: ['إغلاق', 'Close', 'Fermer'],
    noMore: ['رصيد القسائم لا يكفي لفتح حزمة أخرى.', 'Not enough vouchers to open another pack.', 'Pas assez de bons pour ouvrir un autre pack.'],
    notice: ['تنبيه', 'Notice', 'Information'], already: ['هذا اللاعب موجود بالفعل في فريقك.', 'This player is already in your squad.', 'Ce joueur est déjà dans votre équipe.'],
    noRoom: ['لا يوجد مكان', 'No room', 'Pas de place'], noRoomB: ['لا يوجد لاعب احتياطي يمكن استبداله.', 'There is no substitute that can be replaced.', 'Aucun remplaçant ne peut être remplacé.'],
    joined: ['✔ تم الضم', '✔ Added', '✔ Ajouté'], joinedT: ['✔ تم ضم اللاعب', '✔ Player added', '✔ Joueur ajouté'],
    joinedB: ['{a} ({r}) انضم إلى فريقك (رقم #{n}).<br>إجمالي اللاعبين: {c}.<br>العقد: 10 مباريات — يمكنك وضعه في التشكيلة من شاشة التكتيك.', '{a} ({r}) joined your squad (#{n}).<br>Squad size: {c}.<br>Contract: 10 matches — put him in the lineup from the tactics screen.', '{a} ({r}) rejoint votre équipe (n°{n}).<br>Effectif : {c}.<br>Contrat : 10 matchs — placez-le dans la composition depuis l\'écran tactique.'],
    fullT: ['الفريق ممتلئ', 'Squad full', 'Effectif complet'], fullB: ['وصل فريقك إلى {n} لاعب. بِع بعض اللاعبين من «بيع اللاعبين» أولًا.', 'Your squad reached {n} players. Sell some players first from “Sell players”.', 'Votre effectif atteint {n} joueurs. Vendez d\'abord des joueurs.'],
    inSquad: ['✔ ضمن فريقك', '✔ In your squad', '✔ Dans votre équipe'], noInv: ['لم تحصل على أي لاعب من المتجر بعد.', 'You have not obtained any player from the store yet.', 'Vous n\'avez encore obtenu aucun joueur de la boutique.'],
    xchT: ['مبادلة التوكن', 'Token Exchange', 'Échange de jetons'], rate: ['1 قسيمة فتح حزم = {t} توكن', '1 pack-opening voucher = {t} tokens', '1 bon d\'ouverture = {t} jetons'], xchBtn: ['مبادلة', 'Exchange', 'Échanger'],
    noTok: ['توكن غير كافٍ', 'Not enough tokens', 'Jetons insuffisants'], noTokB: ['تحتاج {t} توكن، ورصيدك {b}.', 'You need {t} tokens; your balance is {b}.', 'Il faut {t} jetons ; votre solde est {b}.'],
    xchDone: ['تمت المبادلة', 'Exchange complete', 'Échange effectué'], xchDoneB: ['تم خصم {t} توكن وإضافة {v} قسيمة.<br>🪙 {a} • 🎟️ {b}', '{t} tokens deducted and {v} voucher(s) added.<br>🪙 {a} • 🎟️ {b}', '{t} jetons déduits et {v} bon(s) ajouté(s).<br>🪙 {a} • 🎟️ {b}'],
    pickT: ['اختر اللاعب الذي سيحل مكانه', 'Choose the player to replace', 'Choisissez le joueur à remplacer'], starter: ['أساسي', 'Starter', 'Titulaire'], bench: ['احتياط', 'Bench', 'Remplaçant'], cancel: ['إلغاء', 'Cancel', 'Annuler'],
    traitL: ['السمة', 'Trait', 'Trait'], pityOn: ['ضمان الحظ فعّال في هذه الفتحة!', 'Luck guarantee triggered!', 'Garantie de chance activée !'],
    pityL: ['ضمان الحظ: {n}/{m} — عند الوصول يُضمن تقييم أعلى في الفتحة التالية', 'Luck guarantee: {n}/{m} — at the limit your next pack is guaranteed a higher rating', 'Garantie de chance : {n}/{m} — à la limite, le prochain pack garantit une note plus haute'],
    pityNote: ['النسب أعلاه هي السحب العادي؛ ضمان الحظ يعمل فوقها ويُظهر عدّاده في شاشة الحزمة.', 'The odds above are the normal roll; the luck guarantee works on top of them (counter shown on the pack screen).', 'Les probabilités ci-dessus sont le tirage normal ; la garantie de chance s\'ajoute (compteur sur l\'écran du pack).'],
    offers: ['عروض محدودة الوقت', 'Limited-time offers', 'Offres limitées'], offTag: ['عرض -{d}%', 'Offer -{d}%', 'Offre -{d}%'],
    merge: ['♻️ دمج المكررين', '♻️ Merge duplicates', '♻️ Fusionner les doublons'], mergeNone: ['لا توجد بطاقات مكررة.', 'No duplicate cards.', 'Aucune carte en double.'], mergeDone: ['تم دمج {n} بطاقة مكررة وحصلت على 🔩 {s} قطعة و🪙 {t} توكن.', '{n} duplicate cards merged: 🔩 {s} shards and 🪙 {t} tokens.', '{n} doublons fusionnés : 🔩 {s} pièces et 🪙 {t} jetons.'],
    ok: ['حسناً', 'OK', 'OK'], yrs: ['سنة', 'yrs', 'ans']
  };
  function t(k, v) { const r = TR[k]; let s = r[LIDX[lang()] == null ? 0 : LIDX[lang()]]; if (v) for (const x in v) s = s.split('{' + x + '}').join(v[x]); return s; }

  const TIER_COL = ['#b0b7c3', '#d9dee8', '#ffd24a', '#35e0ff', '#c04bff', '#ff3b3b', '#c58bff', '#d9a6ff', '#f3d0ff'];
  let busy = false, curSec = null, curPack = null, lastToast = null;

  function store() {
    if (!state.store || typeof state.store !== 'object') state.store = {};
    const s = state.store;
    if (!Number.isFinite(s.vouchers) || s.vouchers < 0) s.vouchers = 0;
    if (!Array.isArray(s.inventory)) s.inventory = [];
    if (!Number.isFinite(s.opened)) s.opened = 0;
    if (s.inventory.some(x => !x.nm2)) { // one-time: alter first name + surname of older saved cards
      const pls = (state.teams && state.teams.team_1 && state.teams.team_1.players) || [];
      s.inventory.forEach(x => { if (!x.nm2) { const nn = D.altName(x.name); pls.forEach(q => { if (q && q.storeUid === x.uid) q.name = nn; }); x.name = nn; x.nm2 = 1; } });
    }
    if (!Number.isFinite(s.uid)) s.uid = 1;
    return s;
  }

  /* ----- limited-time offers (2h slots), pity, traits ----- */
  const SLOT = 7200000, nowMs = () => (window.FFMEng ? FFMEng.now() : Date.now());
  function srnd(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
  function offers() {
    const sl = Math.floor(nowMs() / SLOT), r = srnd(sl * 7919 + 13);
    const norm = D.PACKS.filter(p => p.theme !== 'leg' && p.price >= 2), leg = D.PACKS.filter(p => p.theme === 'leg');
    return { end: (sl + 1) * SLOT, list: [{ id: norm[Math.floor(r() * norm.length)].id, disc: 0.5 }, { id: leg[Math.floor(r() * leg.length)].id, disc: 0.25 }] };
  }
  function vprice(p) { const o = offers().list.find(x => x.id === p.id); return o ? Math.max(1, Math.ceil(p.price * (1 - o.disc))) : p.price; }
  const TRAIT_BY_POS = { GK: 'keeper', CB: 'tackler', LB: 'tackler', RB: 'tackler', CDM: 'tackler', CM: 'passer', CAM: 'passer', LW: 'speed', RW: 'speed', ST: 'clinical' };
  Object.keys(TR).forEach((k, i) => { TR[k] = TR[k].concat(XT.TR[i]); });
  const TRAITN = { clinical: ['التسديد الحاسم', 'Clinical Finisher', 'Finisseur clinique'], passer: ['التمرير الدقيق', 'Precision Passer', 'Passeur précis'], tackler: ['الاعتراض القوي', 'Strong Tackler', 'Tacle puissant'], speed: ['السرعة الخارقة', 'Speedster', 'Fusée'], keeper: ['ردود الفعل السريعة', 'Quick Reflexes', 'Réflexes rapides'] };
  Object.keys(TRAITN).forEach(k => { TRAITN[k] = TRAITN[k].concat(XT.TRAITN[k]); });
  const traitName = k => { const r = TRAITN[k]; if (!r) return k; const q = r[LIDX[lang()] == null ? 0 : LIDX[lang()]]; return q == null ? r[1] : q; };
  function rollWithPity(p) {
    const s = store(); s.pity = s.pity || { n: 0, l: 0 };
    const need = p.theme === 'leg' ? (s.pity.l >= 5 ? 7 : 0) : (s.pity.n >= 9 ? 4 : 0); let r, forced = false;
    if (need) {
      const minT = Math.max(p.minTier, need); let sum = 0; for (let k = minT; k < D.TIERS.length; k++) sum += p.units[k];
      let x = D.rndInt(sum), tier = minT; for (let k = minT; k < D.TIERS.length; k++) { if (x < p.units[k]) { tier = k; break; } x -= p.units[k]; }
      const pl = p.pool[tier]; r = { tier, player: pl[D.rndInt(pl.length)] }; forced = true;
    } else r = D.rollPack(p);
    if (p.theme === 'leg') s.pity.l = r.tier >= 7 ? 0 : s.pity.l + 1; else s.pity.n = r.tier >= 4 ? 0 : s.pity.n + 1;
    r.forced = forced; return r;
  }
  function mkItem(p, tier, player, extra) {
    const s = store();
    const it = Object.assign({}, player, { uid: s.uid++, tier, pack: p.id, packName: p.name, contractMatches: 10, renewable: true, joined: false, nm2: 1 }, extra || {});
    if (!it.trait && tier >= 7) it.trait = TRAIT_BY_POS[it.pos];
    return it;
  }
  window.FFMStoreGrant = function (o) { // {tier, packId?, trait?}
    const s = store(); let p = o.packId ? D.PACK_BY_ID[o.packId] : null;
    if (!p) { const c = D.PACKS.filter(q => q.pool[o.tier] && q.pool[o.tier].length); p = c[D.rndInt(c.length)]; }
    const pl = p.pool[o.tier], it = mkItem(p, o.tier, pl[D.rndInt(pl.length)], o.trait ? { trait: o.trait } : (o.autoTrait ? { trait: TRAIT_BY_POS[pl[0].pos] } : null));
    if (o.autoTrait) it.trait = TRAIT_BY_POS[it.pos];
    s.inventory.push(it); it.gift = true; return it;
  };

  function refresh() {
    const s = store();
    document.querySelectorAll('.st-vouch-n').forEach(e => e.textContent = fmt(s.vouchers));
    document.querySelectorAll('.st-tok-n').forEach(e => e.textContent = fmt(state.tokens));
    const act = document.querySelector('.screen.active');
    if (act && act.id === 'screen-store-exchange') renderExchange();
    if (act && act.id === 'screen-store-pack' && curPack) renderPackBtns();
  }
  const _utd = window.updateTokenDisplay;
  window.updateTokenDisplay = function () { _utd(); try { refresh(); } catch (e) {} };

  function headerHTML(title, back) {
    return `<div class="st-head"><div class="st-title">${title}</div>
      <div class="st-chip" title="${t('vchTitle')}">🎟️ <b class="st-vouch-n">0</b></div></div>
      <div class="st-sub"><span>🪙 <b class="st-tok-n">0</b> ${t('tokens')}</span></div>`;
  }

  /* ---------- card ---------- */
  function cardHTML(p, opts) {
    opts = opts || {};
    const col = TIER_COL[p.tier != null ? p.tier : tierOf(p.rating)];
    const tn = p.tier != null ? p.tier : tierOf(p.rating);
    const leg = tn >= 6;
    return `<div class="st-card t${tn}${leg ? ' leg' : ''}${opts.big ? ' big' : ''}" style="--tc:${col};${leg ? '' : `background-image:linear-gradient(180deg,rgba(0,0,0,.15),rgba(0,0,0,.72)),url(${D.flagURL(p.nat)})`}">
      ${p.trait ? '<i class="trait-tri"></i>' : ''}<div class="st-c-top"><span class="st-c-r">${p.rating}</span><span class="st-c-pos">${p.pos}</span></div>
      <img class="st-c-flag" src="${D.flagURL(p.nat)}" alt="">
      <div class="st-c-ava">${D.avatarSVG(p.name, col)}</div>
      <div class="st-c-name">${p.name}</div>
      <div class="st-c-age">${countryName(p.nat)} • ${p.age} ${t('yrs')}</div></div>`;
  }
  function tierOf(r) { for (let i = D.TIERS.length - 1; i >= 0; i--) if (r >= D.TIERS[i].lo) return i; return 0; }

  window.ffmPitchCard = function (p) {
    const ti = tierOf(p.rating), nm = String(p.name).split(' ').pop();
    const bg = p.nat ? `background-image:linear-gradient(180deg,rgba(0,0,0,.15),rgba(0,0,0,.7)),url(${D.flagURL(p.nat)});` : '';
    return `<div class="pc-card${p.legend ? ' leg' : ''}" style="--tc:${p.legend ? TIER_COL[7] : TIER_COL[ti]};${p.legend ? '' : bg}">${p.trait ? '<i class="trait-tri"></i>' : ''}<span class="pc-r">${p.rating}</span><span class="pc-n">#${p.number}</span><span class="pc-ava">${D.avatarSVG(p.name, p.legend ? TIER_COL[7] : TIER_COL[ti])}</span><span class="pc-name">${nm}</span></div>`;
  };

  /* ---------- modal / toast ---------- */
  function modal(title, body, ok) {
    $('st-modal-title').innerHTML = title; $('st-modal-body').innerHTML = body;
    $('st-modal').style.display = 'flex';
    $('st-modal-ok').textContent = ok || t('ok');
  }
  window.stCloseModal = function () { $('st-modal').style.display = 'none'; };

  /* ---------- screens ---------- */
  window.openStore = function () {
    store(); $('st-home').innerHTML = headerHTML('🛒 ' + t('store')) + `<div class="st-intro">${t('intro')}</div>` + offersHTML() +
      D.SECTIONS.map((sec, i) => `<button class="godot-btn st-sec st-sec${i}" onclick="stOpenSection(${i})"><span class="st-sec-ic">${sec.icon}</span><span class="st-sec-tx"><b>${secName(sec)}</b><small>${secDesc(sec)}</small></span></button>`).join('') +
      `<button class="godot-btn st-sec" onclick="stOpenInventory()"><span class="st-sec-ic">📦</span><span class="st-sec-tx"><b>${t('invT')}</b><small>${t('invD')} (${store().inventory.length})</small></span></button>
       <div class="back-bar"><button class="godot-btn" onclick="showScreen('screen-main-menu')">${t('back')}</button></div>`;
    showScreen('screen-store'); refresh();
  };

  function offersHTML() {
    const o = offers();
    return `<div class="st-offers"><div class="st-off-h">⏱ ${t('offers')} <b class="st-off-t" data-end="${o.end}"></b></div>` + o.list.map(x => { const p = D.PACK_BY_ID[x.id]; return `<button class="godot-btn st-offbtn" onclick="stOpenPack('${p.id}')">${packName(p)} • ${t('offTag', { d: x.disc * 100 })} • 🎟️ <s>${p.price}</s> ${vprice(p)}</button>`; }).join('') + '</div>';
  }
  setInterval(() => { document.querySelectorAll('.st-off-t').forEach(e => { const ms = Math.max(0, +e.dataset.end - nowMs()), m = Math.floor(ms / 60000), sec = Math.floor(ms / 1000) % 60; e.textContent = Math.floor(m / 60) + ':' + String(m % 60).padStart(2, '0') + ':' + String(sec).padStart(2, '0'); }); }, 1000);
  window.stOpenSection = function (i) {
    const sec = D.SECTIONS[i]; curSec = i;
    if (sec.id === 'xch') { renderExchange(); showScreen('screen-store-exchange'); refresh(); return; }
    const packs = D.PACKS.filter(p => p.secIdx === i);
    $('st-section').innerHTML = headerHTML(sec.icon + ' ' + secName(sec)) + `<div class="st-intro">${secDesc(sec)}</div><div class="st-grid">` +
      packs.map(p => `<button class="st-pack${p.theme === 'leg' ? ' leg' : ''}" onclick="stOpenPack('${p.id}')" style="--c1:${p.colors[0]};--c2:${p.colors[1]}">
        <img src="${D.packArtURL(p)}" alt=""><b>${packName(p)}</b><small>${p.minRating}–${p.maxRating} ⭐</small><span class="st-price">🎟️ ${vprice(p)}</span></button>`).join('') +
      `</div><div class="back-bar"><button class="godot-btn" onclick="openStore()">${t('back')}</button></div>`;
    showScreen('screen-store-section'); refresh();
  };

  function renderPackBtns() {
    const p = curPack, s = store();
    $('st-open-btn').innerHTML = `🎟️ ${t('openPack')} (${vprice(p)} ${t('voucherWord')})`;
    $('st-open-btn').classList.toggle('st-dim', s.vouchers < vprice(p));
  }

  window.stOpenPack = function (id) {
    const p = D.PACK_BY_ID[id]; curPack = p;
    const sc = $('screen-store-pack');
    sc.style.backgroundImage = `linear-gradient(180deg,rgba(8,10,30,.55),rgba(8,10,30,.85)),url(${D.bgURL(p)})`;
    $('st-pack-body').innerHTML = headerHTML(packName(p)) + `<div class="st-pack-hero"><img src="${D.packArtURL(p)}" alt=""></div>
      <div class="st-pack-name">${packName(p)}</div><div class="st-intro">${tagline(p)}</div>
      <div class="st-pack-info"><span>${t('rating')}: ${p.minRating}–${p.maxRating}</span><span>${t('price')}: 🎟️ ${vprice(p)}</span></div>
      ${(offers().list.find(x => x.id === p.id)) ? `<div class="st-offtag">🔥 ${t('offTag', { d: offers().list.find(x => x.id === p.id).disc * 100 })}</div>` : ''}<div class="st-intro">${t('pityL', { n: p.theme === 'leg' ? (store().pity || { l: 0 }).l : (store().pity || { n: 0 }).n, m: p.theme === 'leg' ? 5 : 9 })}</div>
      <button id="st-open-btn" class="godot-btn st-big" onclick="stOpenNow()"></button>
      <button class="godot-btn" style="width:100%;background:#2b4a8a" onclick="stDetails('${p.id}')">${t('details')}</button>
      <div class="back-bar"><button class="godot-btn" onclick="stOpenSection(${p.secIdx})">${t('back')}</button></div>`;
    showScreen('screen-store-pack'); renderPackBtns(); refresh();
  };

  window.stDetails = function (id) {
    const p = D.PACK_BY_ID[id];
    const rows = D.TIERS.map((tr, i) => {
      if ((p.theme === 'leg') !== (i >= 6)) return '';
      const u = p.units[i], ex = p.pool[i];
      const avail = i >= p.minTier;
      return `<div class="st-row" style="--tc:${TIER_COL[i]}"><div class="st-row-h"><b style="color:${TIER_COL[i]}">${tierName(i)} • ${tr.lo === tr.hi ? tr.lo : tr.lo + '–' + tr.hi}</b>${avail ? ' <small style="color:#9fb3d9">(' + ex.length + ')</small>' : ''}
        <span class="st-pct">${avail ? pct(u) : t('unavail')}</span></div>
        <div class="st-bar"><i style="width:${u / 10}%"></i></div>
        <div class="st-ex">${avail ? ex.map(c => cardHTML(Object.assign({ tier: i }, c))).join('') : '<small>' + t('noCards') + '</small>'}</div></div>`;
    }).join('');
    $('st-details-body').innerHTML = headerHTML(t('detailsOf') + ': ' + packName(p)) +
      `<div class="st-pack-info"><span>${t('minR')}: ${p.minRating}</span><span>${t('maxR')}: ${p.maxRating}</span><span>${t('price')}: 🎟️ ${vprice(p)}</span></div>` + rows +
      `<div class="st-intro">${t('pityNote')}</div><div class="st-total">${t('total')}: ${pct(p.units.reduce((a, b) => a + b, 0))}</div>
       <div class="back-bar"><button class="godot-btn" onclick="stOpenPack('${p.id}')">${t('back')}</button></div>`;
    showScreen('screen-store-details'); refresh();
  };

  /* ---------- opening ---------- */
  window.stOpenNow = function (free) {
    if (busy || !curPack) return;
    const s = store(), p = curPack, cost = free === true ? 0 : vprice(p);
    if (s.vouchers < cost) { ffmShort('vch', '🎟️ ' + t('noVch'), t('needVch', { p: cost, b: s.vouchers })); return; }
    busy = true;
    const res = rollWithPity(p);            // real roll first
    s.vouchers -= cost; s.opened++;
    const item = mkItem(p, res.tier, res.player);
    s.inventory.push(item);
    saveGame(); refresh();
    if (window.FFMEng) { FFMEng.event('pack', 1); if (free === true) FFMEng.event('free', 1); if (res.tier >= 6) FFMEng.event('legend', 1); }
    animate(p, res.tier, item, res.forced);
  };
  window.FFMStoreOpenFree = function (id) { curPack = D.PACK_BY_ID[id]; window.stOpenNow(true); };

  function animate(p, tier, item, forced) {
    const ov = $('st-open'); ov.className = 'st-open'; ov.style.display = 'flex';
    ov.innerHTML = `<div class="st-stage"><img class="st-packimg" src="${D.packArtURL(p)}" alt=""><div class="st-msg">جارٍ فتح الحزمة…</div></div><button class="st-skip" id="st-skip">${t('skip')}</button>`;
    const stage = ov.querySelector('.st-stage'), img = ov.querySelector('.st-packimg'), msg = ov.querySelector('.st-msg');
    let done = false; const timers = [];
    const at = (ms, f) => timers.push(setTimeout(f, ms));
    img.classList.add('shake'); if (window.FFMSfx) FFMSfx.play('pack');
    const reveal = () => {
      if (done) return; done = true; timers.forEach(clearTimeout);
      const col = TIER_COL[tier];
      ov.style.setProperty('--tc', col);
      if (window.FFMSfx) FFMSfx.play(tier >= 6 ? 'legend' : tier >= 3 ? 'rare' : 'card');
      ov.classList.add('flash', 'rev' + tier); if (tier >= 3) ov.classList.add('quake');
      stage.innerHTML = `<div class="st-rays" style="--tc:${col}"></div>` + sparks(tier) +
        `<div class="st-flip">${cardHTML(item, { big: true })}</div>
         <div class="st-res"><b style="color:${col}">${tierName(tier)} • ${item.rating}</b><br><small>${t('prob')}: ${pct(p.units[tier])}</small>
         <div class="st-contract">📝 ${t('contract', { n: item.contractMatches })}</div>${item.trait ? `<div class="st-contract" style="color:#ff9a9a">🔺 ${t('traitL')}: ${traitName(item.trait)}</div>` : ''}${forced ? `<div class="st-contract" style="color:#ffe08a">✨ ${t('pityOn')}</div>` : ''}</div>
         <div class="st-res-btns" id="st-res-btns"></div>`;
      const sk = $('st-skip'); if (sk) sk.style.display = 'none';
      const s = store();
      $('st-res-btns').innerHTML = `<button class="godot-btn" id="st-join" onclick="stJoin(${item.uid})">${t('join')}</button>
        <button class="godot-btn ${s.vouchers < vprice(p) ? 'st-dim' : ''}" style="background:#2b4a8a" onclick="stAgain()">${t('again', { p: vprice(p) })}</button>
        <button class="godot-btn" style="background:#555" onclick="stCloseOpen()">${t('close')}</button>`;
      setTimeout(() => { busy = false; }, 400);
    };
    $('st-skip').onclick = reveal;
    // build-up: bands climb up to the REAL tier
    at(1500, () => { img.classList.remove('shake'); img.classList.add('burst'); if (window.FFMSfx) FFMSfx.play('whoosh'); });
    const seq = []; for (let t = tier >= 6 ? 6 : 0; t <= tier; t++) seq.push(t);
    const steps = seq.length > 4 ? seq.filter((t, i) => i % 2 === 0 || t === tier) : seq;
    steps.forEach((t, i) => at(1900 + i * 420, () => {
      ov.style.setProperty('--tc', TIER_COL[t]); ov.classList.remove('pulse'); void ov.offsetWidth; ov.classList.add('pulse');
      msg.innerHTML = `<span style="color:${TIER_COL[t]}">${tierName(t)}</span>`;
    }));
    at(1900 + steps.length * 420 + 500, reveal);
  }
  function sparks(tier) {
    const n = 14 + tier * 10; let h = '';
    for (let i = 0; i < n; i++) { const a = Math.random() * 6.283, d = 90 + Math.random() * 170; h += `<i class="st-sp" style="--x:${Math.cos(a) * d | 0}px;--y:${Math.sin(a) * d | 0}px;--dl:${(Math.random() * .3).toFixed(2)}s"></i>`; }
    return h;
  }
  window.stCloseOpen = function () { if (busy) return; $('st-open').style.display = 'none'; $('st-open').innerHTML = ''; refresh(); const a = document.querySelector('.screen.active'); if (a && a.id === 'screen-store-inventory') stOpenInventory(); };
  window.stAgain = function () { if (busy) return; const s = store(); if (s.vouchers < vprice(curPack)) { $('st-open').style.display = 'none'; ffmShort('vch', '🎟️ ' + t('noVch'), t('noMore')); return; } $('st-open').style.display = 'none'; stOpenNow(); };


  /* ---------- hand-over cutscene: man in black suit gives the new player his numbered shirt ---------- */
  const DIG = { 0: '111101101101111', 1: '010110010010111', 2: '111001111100111', 3: '111001111001111', 4: '101101111001001', 5: '111100111001111', 6: '111100111101111', 7: '111001001001001', 8: '111101111101111', 9: '111101111001111' };
  function joinScene(name, num, done) {
    const old = document.getElementById('st-join-scene'); if (old) old.remove();
    const W = 160, H = 110, ov = document.createElement('div'); ov.id = 'st-join-scene';
    ov.style.cssText = 'position:fixed;inset:0;z-index:100001;background:#05070d;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px';
    ov.innerHTML = '<canvas width="' + W + '" height="' + H + '" style="width:min(96vw,calc(96vh*1.45),640px);image-rendering:pixelated;border:3px solid #111;box-shadow:0 0 0 3px #3a4a7a"></canvas><div id="sjs-cap" style="font:bold 18px \'Courier New\',monospace;color:#ffd23f;text-shadow:2px 2px 0 #000;text-align:center;min-height:24px;padding:0 10px"></div><button class="godot-btn" id="sjs-skip" style="width:auto!important;padding:8px 22px!important;font-size:16px!important">' + t('skip') + '</button>';
    document.body.appendChild(ov);
    const cv = ov.querySelector('canvas'), c = cv.getContext('2d'), cap = ov.querySelector('#sjs-cap');
    c.imageSmoothingEnabled = false;
    const O = '#12141c', GY = 96, KIT = { shirt: '#2d6cdf', stripe: '#ffffff', short: '#ffffff', sock: '#2d6cdf' };
    const digits = (str, x, y, sc, col) => { c.fillStyle = col; let cx = x; for (const ch of String(str)) { const m = DIG[ch]; for (let i = 0; i < 15; i++) if (m[i] === '1') c.fillRect(cx + (i % 3) * sc, y + ((i / 3) | 0) * sc, sc, sc); cx += 4 * sc; } };
    const numW = (str, sc) => String(str).length * 4 * sc - sc;
    function person(x, y, o, fr, arm) {
      c.fillStyle = 'rgba(0,0,0,.35)'; c.fillRect(x - 5, y - 1, 11, 3);
      const lh = fr === 0 ? 5 : fr === 1 ? 3 : 5, rh = fr === 1 ? 5 : fr === 0 ? 3 : 5;
      c.fillStyle = O; c.fillRect(x - 4, y - 6, 4, 7); c.fillRect(x, y - 6, 4, 7);
      c.fillStyle = o.sock; c.fillRect(x - 3, y - lh, 2, lh); c.fillRect(x + 1, y - rh, 2, rh);
      c.fillStyle = o.shoe || '#e9e9e9'; c.fillRect(x - 3, y - 1, 2, 1); c.fillRect(x + 1, y - 1, 2, 1);
      c.fillStyle = O; c.fillRect(x - 5, y - 15, 10, 10);
      c.fillStyle = o.short; c.fillRect(x - 4, y - 7, 8, 3);
      c.fillStyle = o.shirt; c.fillRect(x - 4, y - 14, 8, 7);
      if (o.stripe) { c.fillStyle = o.stripe; c.fillRect(x - 3, y - 14, 1, 7); c.fillRect(x - 1, y - 14, 1, 7); c.fillRect(x + 1, y - 14, 1, 7); }
      if (o.suit) { c.fillStyle = '#f4f4f4'; c.fillRect(x - 1, y - 14, 2, 4); c.fillStyle = '#c62828'; c.fillRect(x, y - 13, 1, 4); }
      if (o.num != null) digits(o.num, x - ((numW(o.num, 1) / 2) | 0), y - 13, 1, '#fff');
      const sw = fr === 0 ? 1 : fr === 1 ? -1 : 0;
      c.fillStyle = O; c.fillRect(x - 7, y - 13 + sw, 3, 6); c.fillRect(x + 4, y - 13 - sw, 3, 6);
      c.fillStyle = o.shirt; c.fillRect(x - 6, y - 12 + sw, 2, 2); c.fillRect(x + 4, y - 12 - sw, 2, 2);
      c.fillStyle = o.skin; c.fillRect(x - 6, y - 10 + sw, 2, 2); c.fillRect(x + 4, y - 10 - sw, 2, 2);
      if (arm) { c.fillStyle = O; c.fillRect(x + 4, y - 13, 9, 4); c.fillStyle = o.shirt; c.fillRect(x + 4, y - 12, 7, 2); c.fillStyle = o.skin; c.fillRect(x + 11, y - 12, 2, 2); }
      c.fillStyle = O; c.fillRect(x - 4, y - 21, 8, 8);
      c.fillStyle = o.skin; c.fillRect(x - 3, y - 20, 6, 6);
      c.fillStyle = o.hair; c.fillRect(x - 3, y - 20, 6, 2);
      c.fillStyle = '#1b1b24'; c.fillRect(x - 2, y - 17, 1, 1); c.fillRect(x + 1, y - 17, 1, 1);
      if (o.suit) { c.fillStyle = '#000'; c.fillRect(x - 3, y - 18, 6, 2); }
    }
    function shirtBig(cx0, cy0, sc, num) {
      const x = Math.round(cx0 - 12 * sc), y = Math.round(cy0 - 11 * sc), r = (a, b, w, h, col) => { c.fillStyle = col; c.fillRect(x + a * sc, y + b * sc, w * sc, h * sc); };
      r(-1, 0, 26, 24, O); r(0, 1, 24, 22, KIT.shirt);
      r(-1, -1, 8, 8, O); r(17, -1, 8, 8, O); r(0, 0, 6, 6, KIT.shirt); r(18, 0, 6, 6, KIT.shirt);
      r(8, 0, 8, 2, '#0e3b8c'); r(0, 1, 24, 1, '#ffffff');
      r(2, 7, 1, 15, '#ffffff'); r(21, 7, 1, 15, '#ffffff');
      const nw = numW(num, 1) ; digits(num, Math.round(cx0 - nw * sc / 2), y + 8 * sc, sc, '#ffffff');
    }
    const man = { shirt: '#15161b', short: '#15161b', sock: '#15161b', shoe: '#000', skin: '#e0b48a', hair: '#111', suit: true };
    const ply = { shirt: '#8a8f9c', short: '#4a4f5c', sock: '#8a8f9c', skin: '#c68a5a', hair: '#2a1a10' };
    let fin = false, t0 = performance.now(), raf = 0;
    const finish = () => { if (fin) return; fin = true; cancelAnimationFrame(raf); ov.remove(); done(); };
    ov.querySelector('#sjs-skip').onclick = finish;
    const ease = (v) => v * v * (3 - 2 * v), cl = (v) => Math.max(0, Math.min(1, v));
    const PX = 112, MX1 = 70;
    function frame(now) {
      if (fin) return; const T = (now - t0) / 1000;
      // stadium backdrop
      c.fillStyle = '#10172a'; c.fillRect(0, 0, W, 34);
      for (let i = 0; i < 52; i++) { const cx0 = (i * 37) % W, cy0 = 4 + ((i * 17) % 26); c.fillStyle = ['#c62828', '#1565c0', '#f9a825', '#eceff1', '#2e7d32'][i % 5]; c.fillRect(cx0, cy0 + (Math.sin(T * 6 + i) > .6 ? -1 : 0), 2, 3); }
      c.fillStyle = '#1c2540'; c.fillRect(0, 31, W, 4);
      for (let y = 35; y < H; y += 8) { c.fillStyle = ((y - 35) / 8 | 0) % 2 ? '#2f8f3a' : '#37a044'; c.fillRect(0, y, W, 8); }
      c.fillStyle = 'rgba(255,255,255,.7)'; c.fillRect(0, 60, W, 1);
      // phases
      const walk = cl(T / 1.7), mx = -12 + (MX1 + 12) * ease(walk), mfr = walk < 1 ? ((T * 8) | 0) & 1 : 2;
      const hand = T > 1.7 && T < 2.4, show = T >= 2.1 && T < 4.2;
      const celeb = T >= 4.6 ? Math.abs(Math.sin((T - 4.6) * 9)) * 4 * cl(1 - (T - 4.6) / 1.4) : 0;
      const wearing = T >= 4.4;
      person(mx, GY, man, mfr, hand);
      person(PX, GY - celeb, wearing ? Object.assign({}, ply, KIT, { num: num }) : ply, 2);
      if (T < 2.1 && T > 1.2) { const k = cl((T - 1.2) / .9); c.fillStyle = O; c.fillRect(Math.round(mx + 12 + k * 0), GY - 15, 7, 6); c.fillStyle = KIT.shirt; c.fillRect(Math.round(mx + 13), GY - 14, 5, 4); }
      if (show) {
        const a = cl((T - 2.1) / .5), b = cl((T - 3.7) / .5), sc = 1 + 1.6 * ease(a) * (1 - ease(b)) + .0, cx0 = (mx + 10) + ((PX - mx - 10) * ease(b)) * 1, cy0 = (GY - 12) + (-44 - (-12)) * ease(a) * (1 - ease(b));
        shirtBig(cx0, cy0, Math.max(.4, sc * (1 - .75 * ease(b))), num);
      }
      cap.textContent = T < 1.7 ? '' : T < 4.4 ? name : '#' + num + '  ' + name;
      if (T > 6.2) { finish(); return; }
      raf = requestAnimationFrame(frame);
    }
    raf = requestAnimationFrame(frame);
  }

  /* ---------- join squad ---------- */
  window.stJoin = function (uid) {
    if (busy) return;
    const s = store(), it = s.inventory.find(x => x.uid === uid);
    if (!it) return;
    const pl = state.teams.team_1.players;
    if (it.joined && pl.some(q => q.storeUid === uid)) { modal(t('notice'), t('already')); return; }
    if (pl.length >= window.FFM_MAX_SQUAD) { modal(t('fullT'), t('fullB', { n: window.FFM_MAX_SQUAD })); return; }
    busy = true; setTimeout(() => { busy = false; }, 400);
    const np = window.ffmAddPlayer({ trait: it.trait || undefined, name: it.name, rating: it.rating, contractMatches: 10, storePlayer: true, storeUid: uid, nat: it.nat, pos: it.pos, age: it.age, legend: it.tier >= 6 });
    it.joined = true; it.squadNumber = np.number;
    saveGame();
    const b = $('st-join'); if (b) { b.textContent = t('joined'); b.classList.add('st-dim'); }
    const after = () => { modal(t('joinedT'), t('joinedB', { a: it.name, r: it.rating, n: np.number, c: pl.length }));
      const a = document.querySelector('.screen.active'); if (a && a.id === 'screen-store-inventory') stOpenInventory(); };
    try { joinScene(it.name, np.number, after); } catch (e) { after(); }
  };

  window.stMerge = function () {
    const s = store(), seen = new Set(), keep = [], dup = [];
    const sorted = s.inventory.slice().sort((a, b) => (b.joined ? 1 : 0) - (a.joined ? 1 : 0));
    sorted.forEach(it => { const k = it.name + '|' + it.nat + '|' + it.rating; if (!seen.has(k)) { seen.add(k); keep.push(it); } else if (!it.joined && !it.gift) dup.push(it); else keep.push(it); });
    if (!dup.length) { modal(t('merge'), t('mergeNone')); return; }
    const SH = [1, 1, 2, 3, 5, 8, 15, 20, 30]; let sh = 0, tk = 0;
    dup.forEach(it => { sh += SH[it.tier] || 1; tk += it.rating * 5; });
    const ids = new Set(dup.map(x => x.uid)); s.inventory = s.inventory.filter(x => !ids.has(x.uid));
    s.shards = (s.shards || 0) + sh; state.tokens += tk; saveGame(); updateTokenDisplay();
    if (window.FFMEng) FFMEng.event('merge', dup.length);
    modal('♻️ ' + t('merge'), t('mergeDone', { n: dup.length, s: sh, t: fmt(tk) })); stOpenInventory();
  };
  window.stOpenInventory = function () {
    const s = store(), inv = s.inventory.slice().reverse();
    const sq = state.teams.team_1.players;
    $('st-inv-body').innerHTML = headerHTML('📦 ' + t('invT')) + `<button class="godot-btn" style="width:100%;margin-bottom:8px;background:#6a1b9a" onclick="stMerge()">${t('merge')}</button>` + (inv.length ? `<div class="st-inv">` + inv.map(it => {
      const live = it.joined ? sq.find(q => q.storeUid === it.uid) : null;
      const c = live ? live.contractMatches : it.contractMatches;
      return `<div class="st-inv-i">${cardHTML(it)}<div class="st-inv-t"><small>${packName(D.PACK_BY_ID[it.pack] || { theme: 'x', name: it.packName })}</small>
        <div>📝 ${t('contractI', { n: c })}</div>
        ${it.joined ? '<div style="color:#9affb7">' + t('inSquad') + '</div>' : `<button class="godot-btn" onclick="stJoin(${it.uid})">${t('join')}</button>`}</div></div>`;
    }).join('') + `</div>` : '<div class="st-intro">' + t('noInv') + '</div>') +
      `<div class="back-bar"><button class="godot-btn" onclick="openStore()">${t('back')}</button></div>`;
    showScreen('screen-store-inventory'); refresh();
  };

  /* ---------- exchange ---------- */
  function renderExchange() {
    $('st-xch-body').innerHTML = headerHTML('🪙 ' + t('xchT')) +
      `<div class="st-intro">${t('rate', { t: fmt(D.TOKENS_PER_VOUCHER) })}</div>` +
      D.EXCHANGE.map(o => `<div class="st-xrow ${state.tokens < o.tokens ? 'st-dim' : ''}"><div class="st-xo"><b>🪙 ${fmt(o.tokens)}</b> ➜ <b>🎟️ ${o.vouchers}</b></div>
        <button class="godot-btn" onclick="stExchange(${o.n})">${t('xchBtn')}</button></div>`).join('') +
      `<div class="back-bar"><button class="godot-btn" onclick="openStore()">${t('back')}</button></div>`;
    refresh0();
  }
  function refresh0() {
    const s = store();
    document.querySelectorAll('.st-vouch-n').forEach(e => e.textContent = fmt(s.vouchers));
    document.querySelectorAll('.st-tok-n').forEach(e => e.textContent = fmt(state.tokens));
  }
  window.stExchange = function (n) {
    if (busy) return;
    const o = D.EXCHANGE[n - 1]; if (!o) return;
    busy = true; setTimeout(() => { busy = false; }, 500);
    const s = store();
    if (!Number.isFinite(state.tokens) || state.tokens < o.tokens) { ffmShort('tok', '❌ ' + t('noTok'), t('noTokB', { t: fmt(o.tokens), b: fmt(state.tokens || 0) })); return; }
    state.tokens -= o.tokens; s.vouchers += o.vouchers;
    saveGame(); updateTokenDisplay(); renderExchange();
    modal('✔ ' + t('xchDone'), t('xchDoneB', { t: fmt(o.tokens), v: o.vouchers, a: fmt(state.tokens), b: fmt(s.vouchers) }));
  };

  /* ---------- DOM ---------- */
  const mk = (id, cls, html) => { const d = document.createElement('div'); d.id = id; d.className = cls; d.innerHTML = html || ''; return d; };
  const cont = $('game-container');
  const afterEl = $('screen-main-menu');
  [['screen-store', '<div id="st-home"></div>'], ['screen-store-section', '<div id="st-section"></div>'], ['screen-store-pack', '<div id="st-pack-body"></div>'],
   ['screen-store-details', '<div id="st-details-body"></div>'], ['screen-store-exchange', '<div id="st-xch-body"></div>'], ['screen-store-inventory', '<div id="st-inv-body"></div>']]
    .forEach(([id, h]) => cont.appendChild(mk(id, 'screen store-screen', h)));
  document.body.appendChild(mk('st-open', 'st-open'));
  document.body.appendChild(mk('st-modal', 'st-modal', '<div class="st-mbox"><h3 id="st-modal-title"></h3><div id="st-modal-body"></div><button id="st-modal-ok" class="godot-btn" style="width:100%;margin-top:12px" onclick="stCloseModal()">OK</button></div>'));

  /* ---------- full player cards (contracts / sales / market / bench) ---------- */
  window.ffmFullCard = function (p) {
    const ti = tierOf(p.rating), leg = p.legend || ti >= 6;
    const bg = (!leg && p.nat) ? `background-image:linear-gradient(180deg,rgba(0,0,0,.15),rgba(0,0,0,.72)),url(${D.flagURL(p.nat)});` : '';
    return `<div class="st-card pl-card t${ti}${leg ? ' leg' : ''}" style="--tc:${leg ? TIER_COL[7] : TIER_COL[ti]};${bg}">${p.trait ? '<i class="trait-tri"></i>' : ''}
      <div class="st-c-top"><span class="st-c-r">${p.rating}</span><span class="st-c-pos">${p.pos || (p.number != null ? '#' + p.number : '')}</span></div>
      ${p.nat ? `<img class="st-c-flag" src="${D.flagURL(p.nat)}" alt="">` : ''}<div class="st-c-ava">${D.avatarSVG(p.name, leg ? TIER_COL[7] : TIER_COL[ti])}</div>
      <div class="st-c-name">${p.name}</div><div class="st-c-age">${p.number != null ? '#' + p.number : ''}${p.age ? ' • ' + p.age : ''}${p.lvl ? ' • Lv' + p.lvl : ''}${p.upg ? ' • +' + p.upg : ''}</div></div>`;
  };
  const strip = (id) => { const e = $(id); e.className = 'pl-strip'; e.style.cssText = ''; return e; };
  window.openPlayerContracts = function () {
    const list = strip('player-contracts-list');
    list.innerHTML = state.teams.team_1.players.map((p, i) => {
      const exp = p.contractMatches <= 0;
      const btns = (p.eventPlayer || p.contractRenewable === false) ? (exp ? tx('expired_label') : tx('active_label'))
        : (exp && !p.onBench ? `<button class="godot-btn" onclick="renewPlayerContract(${i})">${tx('renew_label')}</button><button class="godot-btn" onclick="benchExpiredPlayer(${i})">${tx('bench_label')}</button>` : (exp ? tx('expired_label') : tx('active_label')));
      return `<div class="pl-cell">${ffmFullCard(p)}<div class="pl-info" style="color:${exp ? '#ff7777' : '#7fe9ff'}">${tx('contract_label')}: ${p.contractMatches} ${tx('matches_label')}${p.onBench ? ' • ' + tx('bench_label') : ''}</div>${p.eventPlayer ? `<div class="pl-info" style="color:#9affb7">${tx('player_contract_nonrenewable')}</div>` : ''}<div class="pl-btns">${btns}</div></div>`;
    }).join('');
    showScreen('screen-contracts');
  };
  window.openPlayerSales = function () {
    const list = strip('player-sales-list');
    list.innerHTML = state.teams.team_1.players.map((p, i) => {
      const price = ffmSellPrice(p);
      return `<div class="pl-cell">${ffmFullCard(p)}<div class="pl-info">${tx('sale_price_label')}: ${price} ${tx('tokens_label')}</div><div class="pl-btns"><button class="godot-btn" onclick="sellCareerPlayer(${i})">${tx('sell_action')}</button></div></div>`;
    }).join('');
    showScreen('screen-player-sales');
  };
  window.openTransferMarket = function () {
    const c = strip('market-players-container');
    c.innerHTML = '';
    for (let i = 0; i < 4; i++) {
      let r = 75 + Math.floor(Math.random() * 17); if (r > 91) r = 91;
      const cost = r * 3, nm = fakeFirstNames[Math.floor(Math.random() * fakeFirstNames.length)] + ' ' + fakeLastNames[Math.floor(Math.random() * fakeLastNames.length)];
      const d = document.createElement('div'); d.className = 'pl-cell';
      d.innerHTML = `${ffmFullCard({ name: nm, rating: r })}<div class="pl-btns"><button class="godot-btn" onclick="buyPlayer('${nm}', ${r}, ${cost})">🪙 ${cost}</button></div>`;
      c.appendChild(d);
    }
    showScreen('screen-market');
  };
  function rebuildBench() {
    const bc = $('bench-list-container'); if (!bc || !state.teams.team_1) return;
    const team = state.teams[matchContext.myTeamId] || state.teams.team_1;
    bc.className = 'pl-strip'; bc.innerHTML = '';
    for (let i = 11; i < team.players.length; i++) { const d = document.createElement('div'); d.className = 'pl-cell'; d.innerHTML = ffmFullCard(team.players[i]); bc.appendChild(d); }
  }
  const _rtp = window.renderTacticalPitch;
  window.renderTacticalPitch = function () { _rtp.apply(this, arguments); rebuildBench(); };

  const _al = window.applyLanguage;
  function storeBtn() { const b = $('store-open-btn'); if (b) b.textContent = '🛒 ' + t('store'); }
  window.applyLanguage = function (l) { _al(l); storeBtn(); };
  storeBtn();
  window.FFMStore = { cardHTML, countryName, vprice, traitName, TRAITN, offers, store, openPack: (id) => { stOpenPack(id); }, refresh };
})();
