// ===== skins.js: weapon skins — textures + glowing materials, 5 rarities, their own inspect flourishes =====
const SKIN_TIERS = [
  { n: 'NADİR', col: 0x3ddc5a, tcol: 0x5dff7a }, { n: 'EPİK', col: 0xa44cff, tcol: 0xc080ff }, { n: 'GİZEMLİ', col: 0xff2a2a, tcol: 0xff5040 },
  { n: 'EFSANEVİ', col: 0xffc830, tcol: 0xffd860 }, { n: 'VAR OLMAYAN', col: 0xff66ff, tcol: 0xff88ff, grad: 'linear-gradient(90deg,#ff3a3a,#ffb83a,#f6ff3a,#3aff6a,#3ac8ff,#7a3aff,#ff3ad8)' }
];
const SKIN_DEFS = [
  { id: 's_orman', n: 'Orman Ruhu', tier: 0, cost: 1200, st: 'camo', c: ['#2f4a22', '#4f7a34', '#1a2a12'], rough: .6, metal: .3, d: 'Yoğun orman kamuflajı' },
  { id: 's_zehir', n: 'Zehirli Pullar', tier: 0, cost: 1500, st: 'scales', c: ['#0f5a2a', '#3dff7a', '#1a8a46'], rough: .35, metal: .6, d: 'Parlayan yılan derisi' },
  { id: 's_uv', n: 'Ultraviyole', tier: 1, cost: 3000, st: 'grid', c: ['#1a0a33', '#b46cff', '#ff7ae8'], rough: .3, metal: .7, d: 'Neon devre çizgileri · yan ışık şeridi' },
  { id: 's_galaksi', n: 'Galaksi Tozu', tier: 1, cost: 3600, st: 'stars', c: ['#100826', '#8a4cff', '#e8d0ff'], rough: .25, metal: .75, d: 'Yıldızlı derin uzay · yan ışık şeridi' },
  { id: 's_kan', n: 'Kanlı Çatlak', tier: 2, cost: 6000, st: 'cracks', c: ['#12060a', '#ff2a2a', '#ffb0a0'], rough: .4, metal: .5, d: 'Nabız gibi atan kızıl damarlar' },
  { id: 's_alev', n: 'Cehennem Alevi', tier: 2, cost: 7000, st: 'flame', c: ['#1a0604', '#ff3a10', '#ffd040'], rough: .4, metal: .5, d: 'Sürekli yanan silah' },
  { id: 's_ejder', n: 'Altın Ejder', tier: 3, cost: 12000, st: 'scales', c: ['#7a5a10', '#ffe070', '#c8981c'], rough: .18, metal: 1, d: 'Katı altın ejder pulları · fırlat-yakala incelemesi' },
  { id: 's_firavun', n: 'Firavun Hazinesi', tier: 3, cost: 14000, st: 'ornate', c: ['#8a6414', '#fff0a0', '#d8a420'], rough: .15, metal: 1, d: 'Süslü altın işleme · fırlat-yakala incelemesi' },
  { id: 's_prizma', n: 'Prizma Boşluk', tier: 4, cost: 30000, st: 'prism', c: ['#000', '#fff', '#fff'], rough: .12, metal: .9, d: 'Gerçekte var olmayan renkler · süzülen inceleme' },
  { id: 's_nova', n: 'Gökkuşağı Nova', tier: 4, cost: 38000, st: 'iri', c: ['#000', '#fff', '#fff'], rough: .1, metal: .95, d: 'Akışkan gökkuşağı · süzülen inceleme' }
];
function skinTex(def) {
  try {
    const cv = document.createElement('canvas'); cv.width = cv.height = 256; const x = cv.getContext('2d'), [a, b, c] = def.c, R = (n) => Math.random() * n;
    x.fillStyle = a; x.fillRect(0, 0, 256, 256);
    if (def.st === 'camo') { for (let i = 0; i < 46; i++) { x.fillStyle = i % 3 ? b : c; x.beginPath(); x.ellipse(R(256), R(256), 14 + R(30), 8 + R(18), R(3), 0, 6.3); x.fill(); } }
    else if (def.st === 'scales' || def.st === 'ornate') {
      for (let r = 0; r < 18; r++) for (let q = -1; q < 10; q++) { const px = q * 28 + (r % 2) * 14, py = r * 14; x.strokeStyle = b; x.lineWidth = 2; x.fillStyle = (q + r) % 3 ? a : c; x.beginPath(); x.arc(px, py, 14, 0, Math.PI); x.fill(); x.stroke(); }
      if (def.st === 'ornate') { x.strokeStyle = b; x.lineWidth = 3; for (let i = 0; i < 6; i++) { x.beginPath(); x.moveTo(0, i * 48); x.lineTo(256, i * 48 + 30); x.stroke(); } for (let i = 0; i < 5; i++) { x.fillStyle = b; x.save(); x.translate(30 + i * 50, 128); x.rotate(.785); x.fillRect(-9, -9, 18, 18); x.restore(); } }
    }
    else if (def.st === 'grid') { x.strokeStyle = b; x.lineWidth = 2; for (let i = 0; i < 9; i++) { x.beginPath(); x.moveTo(i * 32, 0); x.lineTo(i * 32, 256); x.moveTo(0, i * 32); x.lineTo(256, i * 32); x.stroke(); } for (let i = 0; i < 26; i++) { x.fillStyle = c; x.beginPath(); x.arc(Math.floor(R(8)) * 32, Math.floor(R(8)) * 32, 4, 0, 6.3); x.fill(); } }
    else if (def.st === 'stars') { const g = x.createRadialGradient(128, 128, 10, 128, 128, 180); g.addColorStop(0, b); g.addColorStop(1, a); x.globalAlpha = .55; x.fillStyle = g; x.fillRect(0, 0, 256, 256); x.globalAlpha = 1; for (let i = 0; i < 160; i++) { x.fillStyle = c; x.globalAlpha = .4 + R(.6); x.fillRect(R(256), R(256), 1 + R(2), 1 + R(2)); } x.globalAlpha = 1; }
    else if (def.st === 'cracks') { for (let k = 0; k < 14; k++) { let px = R(256), py = R(256); x.beginPath(); x.moveTo(px, py); for (let s = 0; s < 8; s++) { px += R(60) - 30; py += R(60) - 30; x.lineTo(px, py); } x.strokeStyle = b; x.lineWidth = 4; x.stroke(); x.strokeStyle = c; x.lineWidth = 1.2; x.stroke(); } }
    else if (def.st === 'flame') { const g = x.createLinearGradient(0, 256, 0, 0); g.addColorStop(0, c); g.addColorStop(.45, b); g.addColorStop(1, a); x.fillStyle = g; x.fillRect(0, 0, 256, 256); x.fillStyle = a; for (let i = 0; i < 12; i++) { x.beginPath(); x.moveTo(i * 22 - 8, 0); x.lineTo(i * 22 + 10 + R(10), 80 + R(110)); x.lineTo(i * 22 + 30, 0); x.fill(); } }
    else if (def.st === 'prism') { const g = x.createLinearGradient(0, 0, 256, 256); for (let i = 0; i <= 12; i++) g.addColorStop(i / 12, 'hsl(' + (i * 30) + ',100%,55%)'); x.fillStyle = g; x.fillRect(0, 0, 256, 256); x.globalAlpha = .35; x.fillStyle = '#fff'; for (let i = 0; i < 8; i++) x.fillRect(0, i * 32, 256, 8); x.globalAlpha = 1; }
    else { for (let i = 0; i < 70; i++) { x.fillStyle = 'hsla(' + R(360) + ',100%,60%,.55)'; x.beginPath(); x.arc(R(256), R(256), 14 + R(40), 0, 6.3); x.fill(); } }
    const t = new THREE.CanvasTexture(cv); if (t) { t.wrapS = t.wrapT = THREE.RepeatWrapping; } return t;
  } catch (e) { return null; }
}
const SKINS = {};
function skinGet(id) {
  if (SKINS[id]) return SKINS[id]; const def = SKIN_DEFS.find(s => s.id === id); if (!def) return null;
  const tex = skinTex(def), tc = SKIN_TIERS[def.tier].col, mk = (col, em, ei, mt, rg, map) => { const m = new THREE.MeshStandardMaterial({ color: col, roughness: rg, metalness: mt, emissive: em, emissiveIntensity: ei }); if (map) m.map = map; return m; };
  const rb = def.tier === 4, hx = s => parseInt(s.slice(1), 16);
  const sk = { id, def, tier: def.tier, tex,
    main: mk(0xffffff, rb ? 0xffffff : tc, def.tier === 0 ? .08 : .22, def.metal, def.rough, tex),
    alt: mk(def.tier === 4 ? 0xaaaaaa : 0x888888, tc, def.tier ? .12 : .02, Math.min(1, def.metal + .1), def.rough + .1, tex),
    glow: new THREE.MeshStandardMaterial({ color: tc, emissive: tc, emissiveIntensity: 1.6, roughness: .3, metalness: 0 }) };
  return SKINS[id] = sk;
}
function skinRole(mat, ud) { return mat === ud.acc ? 'glow' : (mat === vmM.gun || mat === vmM.green) ? 'main' : (mat === vmM.poly || mat === vmM.wood) ? 'alt' : mat === vmM.red ? 'glow' : null; }
let _skinCur = null;
function applySkin(vm, ud, dt) {
  const sk = COS.skin ? skinGet(COS.skin) : null, key = sk ? sk.id : '';
  if (ud.skinKey !== key) {
    ud.skinKey = key;
    vm.traverse(m => { if (!m.isMesh) return; const u = m.userData; if (u.orn) return; if (u.om === undefined) { u.om = m.material; u.role = skinRole(m.material, ud); u.skip = !!(m.material.transparent || m.material.opacity < 1 || m.material === vmM.glove || m.material === vmM.sleeve); } const r = sk ? (u.role || (sk.tier >= 3 && !u.skip ? 'alt' : null)) : null; m.material = r ? sk[r] : u.om; });
    skinOrn(vm, ud, sk);
    if (sk && ud.style !== 'knife' && ud.muzzle && !ud.skinFx && sk.tier >= 1) {
      const len = Math.abs(ud.muzzle.z) + .1, fx = new THREE.Mesh(new THREE.BoxGeometry(.008, .008, len), sk.glow); fx.position.set(0, .11, (ud.muzzle.z + .2) / 2); vm.add(fx); ud.skinFx = fx;
    }
    if (ud.skinFx) { ud.skinFx.visible = !!sk && sk.tier >= 1; if (sk) ud.skinFx.material = sk.glow; }
  }
  if (!sk) return null; skinOrnUpd(ud, performance.now() / 1000); const t = performance.now() / 1000, ins = P.wInsp >= 0 || P.kSpin >= 0 ? 1 : 0;
  if (sk.tier === 4) { const h = (t * .22) % 1; sk.main.emissive.setHSL(h, 1, .38); sk.alt.emissive.setHSL((h + .5) % 1, 1, .3); sk.glow.color.setHSL((h + .25) % 1, 1, .6); sk.glow.emissive.setHSL((h + .25) % 1, 1, .6); sk.main.emissiveIntensity = .5; sk.alt.emissiveIntensity = .4; if (sk.tex) sk.tex.offset.x = (t * .12) % 1; }
  else if (sk.tier === 2) { const hb = Math.pow(Math.max(0, Math.sin(t * 2.6)), 6); sk.main.emissiveIntensity = .25 + hb * .9 + ins * .3; sk.glow.emissiveIntensity = 1.2 + hb * 2; }
  else if (sk.tier === 1) { sk.main.emissiveIntensity = .22 + Math.sin(t * 2) * .1 + ins * .3; }
  else if (sk.tier === 3) { sk.main.emissiveIntensity = .2 + Math.sin(t * 1.6) * .08 + ins * .35; }
  return sk;
}
// extra inspect motion per rarity, added on top of the basic inspect (u 0..1)
function skinInsp(vm, u) {
  const sk = COS.skin ? skinGet(COS.skin) : null; if (!sk) return; const a = sstep(0, .14, u) * (1 - sstep(.88, 1, u)), T = sk.tier;
  if (T === 1) { vm.rotation.z += sstep(.22, .62, u) * Math.PI * 2; }
  else if (T === 2) { vm.position.z += a * .09; vm.position.x += Math.sin(u * 70) * .004 * a; vm.rotation.x += Math.sin(u * 55) * .01 * a; }
  else if (T === 3) { const w = sstep(.3, .72, u); vm.position.y += Math.sin(Math.PI * w) * .2; vm.rotation.x -= Math.PI * 2 * w; }
  else if (T === 4) { const w = sstep(.28, .74, u); vm.position.y += Math.sin(u * Math.PI * 2) * .04 * a + Math.sin(Math.PI * w) * .16; vm.rotation.x -= Math.PI * 2 * w; vm.rotation.z += sstep(.2, .6, u) * Math.PI * 2; vm.position.x += Math.sin(u * 9) * .03 * a; }
}

// legendary + nonexistent skins rebuild the weapon's silhouette: glowing rings, wings, a crest and orbiting crystals
function skinOrn(vm, ud, sk) {
  if (!ud.orn) {
    const g = new THREE.Group(), mz = ud.muzzle || new THREE.Vector3(0, 0, -.5), knife = ud.style === 'knife', add = (geo, role, x, y, z, rx, ry, rz) => { const m = new THREE.Mesh(geo, null); m.userData.orn = true; m.userData.role = role; m.position.set(x, y, z); m.rotation.set(rx || 0, ry || 0, rz || 0); g.add(m); return m; };
    const rings = [], wings = [], crystals = [];
    if (!knife) {
      for (const f of [.3, .55, .8]) rings.push(add(new THREE.TorusGeometry(.042, .007, 8, 22), 'glow', mz.x, mz.y, mz.z * f));
      for (const sx of [-1, 1]) wings.push(add(new THREE.BoxGeometry(.11, .006, .2), 'main', mz.x + sx * .07, mz.y + .035, mz.z * .38, 0, sx * .35, sx * .5));
      add(new THREE.BoxGeometry(.01, .05, .24), 'main', mz.x, mz.y + .06, mz.z * .5);
      add(new THREE.BoxGeometry(.012, .012, Math.abs(mz.z) * .9), 'glow', mz.x, mz.y - .045, mz.z * .5);
    }
    const orb = new THREE.Group(); orb.position.set(mz.x, mz.y, mz.z * (knife ? .1 : .45)); g.add(orb);
    for (let i = 0; i < 5; i++) { const m = new THREE.Mesh(new THREE.OctahedronGeometry(.016 + (i % 2) * .006), null); m.userData.orn = true; m.userData.role = 'glow'; orb.add(m); crystals.push(m); }
    vm.add(g); ud.orn = { g, rings, wings, crystals, orb, knife };
  }
  const o = ud.orn; o.g.visible = !!sk && sk.tier >= 3;
  if (sk) o.g.traverse(m => { if (m.isMesh) m.material = sk[m.userData.role] || sk.glow; });
  if (sk) o.crystals.forEach((c, i) => c.visible = i < (sk.tier === 4 ? 5 : 3));
}
function skinOrnUpd(ud, t) {
  const o = ud.orn; if (!o || !o.g.visible) return;
  o.orb.rotation.y = t * 1.8; o.orb.rotation.x = Math.sin(t * .9) * .4;
  o.crystals.forEach((c, i) => { const a = i / 5 * 6.283, r = o.knife ? .09 : .09 + (i % 2) * .03; c.position.set(Math.cos(a) * r, Math.sin(a * 2 + t) * .03, Math.sin(a) * r); c.rotation.set(t * 2 + i, t * 1.5, 0); });
  o.rings.forEach((r, i) => r.scale.setScalar(1 + Math.sin(t * 3 + i * 1.4) * .12));
  o.wings.forEach((w, i) => w.rotation.z = (i ? 1 : -1) * (.5 + Math.sin(t * 1.4) * .12));
}
