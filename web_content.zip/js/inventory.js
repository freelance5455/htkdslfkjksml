/**
 * Panchal Business Manager - Inventory & Multi-Warehouse Module
 * Manages Products, Services, SKU/Barcode, HSN/SAC, Alternate Units & Conversion,
 * Multi-Warehouse Stock, Low Stock Alerts, Stock Valuation & Movement History.
 */
(function (global) {
  "use strict";

  const I18N = {
    en: {
      addItemBtn: "+ Add Item",
      warehousesBtn: "Warehouses",
      stockAdjustBtn: "Stock In/Out",
      stockReportBtn: "Stock Report",
      exportCsvBtn: "Export CSV",
      searchPlaceholder: "Search item name, SKU or HSN...",
      filterAll: "All",
      filterProducts: "Products",
      filterServices: "Services",
      filterLowStock: "Low Stock",
      kpiTotalItems: "Total Items",
      kpiLowStock: "Low Stock Alerts",
      kpiStockValue: "Stock Value",
      emptyTitle: "No inventory items yet",
      emptyDesc: "Add products or services with SKU, HSN, GST rate and warehouse stock.",
      typeProduct: "Product",
      typeService: "Service",
      saleRateLabel: "Sale",
      purchaseRateLabel: "Purchase",
      stockLabel: "Stock",
      lowStockAlert: "Low Stock",
      btnEdit: "Edit",
      btnDelete: "Delete",
      btnStock: "Stock",
      modalAddItem: "Add Product / Service",
      modalEditItem: "Edit Item",
      fieldName: "Item Name *",
      fieldType: "Item Type",
      fieldSku: "SKU / Barcode (optional)",
      fieldHsn: "HSN / SAC Code (optional)",
      fieldUnit: "Base Unit",
      fieldAltUnit: "Alternate Unit (optional)",
      fieldConvFactor: "1 Alt Unit = ? Base Units",
      fieldSalePrice: "Sale Price (₹) *",
      fieldPurchasePrice: "Purchase Price (₹)",
      fieldGstRate: "GST Rate (%)",
      fieldOpeningStock: "Opening Stock Qty",
      fieldWarehouse: "Warehouse",
      fieldLowStockLimit: "Low Stock Alert Level",
      errNameReq: "Item name must be at least 2 characters.",
      confirmDeleteTitle: "Delete Item?",
      confirmDeleteMsg: "Delete this item from inventory?",
      toastSaved: "Item saved.",
      toastDeleted: "Item deleted.",
      modalStockTitle: "Stock In / Out / Transfer",
      fieldMoveType: "Movement Type",
      moveIn: "Stock In (+)",
      moveOut: "Stock Out (-)",
      moveTransfer: "Warehouse Transfer",
      fieldFromWh: "From Warehouse",
      fieldToWh: "To Warehouse",
      fieldQty: "Quantity (in Base Unit or Alt Unit) *",
      fieldEntryUnit: "Entry Unit",
      fieldReason: "Notes / Reason",
      errQtyInvalid: "Quantity must be greater than 0.",
      errSameWh: "Source and destination warehouses must be different.",
      toastStockUpdated: "Stock updated.",
      modalWhTitle: "Manage Warehouses",
      fieldWhName: "Warehouse / Godown Name *",
      fieldWhLoc: "Location (optional)",
      addWhBtn: "+ Add Warehouse",
      toastWhSaved: "Warehouse added.",
      errLastWh: "At least one warehouse must remain.",
      stockReportTitle: "Stock Valuation & Movements",
      printPdfBtn: "Print / PDF",
      saveBtn: "Save",
      cancelBtn: "Cancel",
      deleteBtn: "Delete"
    },
    hi: {
      addItemBtn: "+ नया आइटम",
      warehousesBtn: "गोदाम",
      stockAdjustBtn: "स्टॉक इन/आउट",
      stockReportBtn: "स्टॉक रिपोर्ट",
      exportCsvBtn: "CSV डाउनलोड",
      searchPlaceholder: "आइटम, SKU या HSN कोड खोजें...",
      filterAll: "सभी",
      filterProducts: "सामान (Products)",
      filterServices: "सेवाएँ (Services)",
      filterLowStock: "कम स्टॉक",
      kpiTotalItems: "कुल आइटम",
      kpiLowStock: "कम स्टॉक अलर्ट",
      kpiStockValue: "स्टॉक कीमत",
      emptyTitle: "इन्वेंटरी खाली है",
      emptyDesc: "SKU, HSN, GST दर और गोदाम स्टॉक के साथ पहला प्रोडक्ट या सर्विस जोड़ें।",
      typeProduct: "प्रोडक्ट",
      typeService: "सर्विस",
      saleRateLabel: "बिक्री",
      purchaseRateLabel: "खरीद",
      stockLabel: "स्टॉक",
      lowStockAlert: "कम स्टॉक",
      btnEdit: "बदलें",
      btnDelete: "हटाएँ",
      btnStock: "स्टॉक",
      modalAddItem: "नया आइटम / सर्विस जोड़ें",
      modalEditItem: "आइटम बदलें",
      fieldName: "आइटम का नाम *",
      fieldType: "प्रकार",
      fieldSku: "SKU / बारकोड (वैकल्पिक)",
      fieldHsn: "HSN / SAC कोड (वैकल्पिक)",
      fieldUnit: "मुख्य यूनिट (Base Unit)",
      fieldAltUnit: "वैकल्पिक यूनिट (जैसे Box)",
      fieldConvFactor: "1 वैकल्पिक यूनिट = ? मुख्य यूनिट",
      fieldSalePrice: "बिक्री दर (₹) *",
      fieldPurchasePrice: "खरीद दर (₹)",
      fieldGstRate: "GST दर (%)",
      fieldOpeningStock: "शुरुआती स्टॉक (Opening Qty)",
      fieldWarehouse: "गोदाम (Warehouse)",
      fieldLowStockLimit: "कम स्टॉक चेतावनी सीमा",
      errNameReq: "आइटम का नाम कम से कम 2 अक्षर का होना चाहिए।",
      confirmDeleteTitle: "आइटम हटाएँ?",
      confirmDeleteMsg: "क्या आप इस आइटम को इन्वेंटरी से हटाना चाहते हैं?",
      toastSaved: "आइटम सेव हो गया।",
      toastDeleted: "आइटम हटा दिया गया।",
      modalStockTitle: "स्टॉक इन / आउट / ट्रांसफ़र",
      fieldMoveType: "प्रक्रिया चुनें",
      moveIn: "स्टॉक जमा (Stock In +)",
      moveOut: "स्टॉक कम (Stock Out -)",
      moveTransfer: "गोदाम ट्रांसफ़र",
      fieldFromWh: "किस गोदाम से",
      fieldToWh: "किस गोदाम में",
      fieldQty: "मात्रा (Qty) *",
      fieldEntryUnit: "यूनिट चुनें",
      fieldReason: "विवरण / कारण",
      errQtyInvalid: "मात्रा 0 से बड़ी होनी चाहिए।",
      errSameWh: "दोनों गोदाम अलग-अलग होने चाहिए।",
      toastStockUpdated: "स्टॉक अपडेट हो गया।",
      modalWhTitle: "गोदाम प्रबंधन (Warehouses)",
      fieldWhName: "गोदाम का नाम *",
      fieldWhLoc: "पता / लोकेशन (वैकल्पिक)",
      addWhBtn: "+ गोदाम जोड़ें",
      toastWhSaved: "गोदाम जुड़ गया।",
      errLastWh: "कम से कम एक गोदाम रहना ज़रूरी है।",
      stockReportTitle: "स्टॉक वैल्यू व मूवमेंट रिपोर्ट",
      printPdfBtn: "प्रिंट / PDF",
      saveBtn: "सेव करें",
      cancelBtn: "रद्द करें",
      deleteBtn: "हटाएँ"
    }
  };

  const viewState = {
    search: "",
    filter: "all",
    items: [],
    warehouses: []
  };

  function tr(key) {
    const lang = global.PBM_APP.getLang();
    return (I18N[lang] && I18N[lang][key]) || I18N.en[key] || key;
  }

  function getTotalStock(item) {
    if (item.type === "SERVICE") return 0;
    const map = item.stockByWarehouse || {};
    return Object.keys(map).reduce(function (sum, whId) {
      return sum + (Number(map[whId]) || 0);
    }, 0);
  }

  function isLowStock(item) {
    if (item.type === "SERVICE") return false;
    const min = Number(item.minStock) || 0;
    return min > 0 && getTotalStock(item) <= min;
  }

  function getSummary(businessId) {
    return global.PBM_DB.getByBusiness("items", businessId).then(function (items) {
      let lowStockCount = 0;
      let totalValue = 0;
      items.forEach(function (item) {
        if (item.type !== "SERVICE") {
          const qty = getTotalStock(item);
          totalValue += Math.max(0, qty) * (Number(item.purchasePrice) || Number(item.salePrice) || 0);
          if (isLowStock(item)) lowStockCount += 1;
        }
      });
      return {
        totalItems: items.length,
        lowStockCount: lowStockCount,
        totalValue: Math.round(totalValue * 100) / 100
      };
    });
  }

  function adjustStock(businessId, itemId, warehouseId, qtyDelta, reason, refId) {
    return global.PBM_DB.getOne("items", itemId).then(function (item) {
      if (!item || item.type === "SERVICE") return null;
      const stockMap = Object.assign({}, item.stockByWarehouse || {});
      const targetWh = warehouseId || Object.keys(stockMap)[0] || "default";
      const prevQty = Number(stockMap[targetWh]) || 0;
      stockMap[targetWh] = Math.round((prevQty + Number(qtyDelta)) * 1000) / 1000;
      item.stockByWarehouse = stockMap;
      item.updatedAt = new Date().toISOString();

      const moveRecord = {
        id: global.PBM_DB.generateId("stk"),
        businessId: businessId,
        itemId: itemId,
        itemName: item.name,
        warehouseId: targetWh,
        qtyDelta: Number(qtyDelta),
        reason: reason || "Adjustment",
        refId: refId || "",
        createdAt: item.updatedAt,
        updatedAt: item.updatedAt
      };

      return Promise.all([
        global.PBM_DB.put("items", item),
        global.PBM_DB.put("stockMovements", moveRecord)
      ]);
    });
  }

  function openWarehousesModal() {
    const app = global.PBM_APP;
    const businessId = app.getActiveBusinessId();

    global.PBM_DB.getByBusiness("warehouses", businessId).then(function (warehouses) {
      const listHtml = warehouses
        .map(function (w) {
          return `
            <div class="ledger-row">
              <div class="ledger-row-main">
                <div class="ledger-row-title">${app.escapeHtml(w.name)}</div>
                <div class="list-item-meta">${app.escapeHtml(w.location || "-")}</div>
              </div>
              <div class="ledger-row-right">
                ${
                  warehouses.length > 1
                    ? `<button class="mini-danger-btn" type="button" data-del-wh="${app.escapeHtml(w.id)}">${tr("deleteBtn")}</button>`
                    : ""
                }
              </div>
            </div>
          `;
        })
        .join("");

      const html = `
        <form id="whForm" class="form-grid" novalidate>
          <div id="whFormError" class="form-error hidden"></div>
          <div class="form-row-2">
            <div class="form-group">
              <label class="form-label" for="whNameInput">${tr("fieldWhName")}</label>
              <input id="whNameInput" class="form-input" type="text" required />
            </div>
            <div class="form-group">
              <label class="form-label" for="whLocInput">${tr("fieldWhLoc")}</label>
              <input id="whLocInput" class="form-input" type="text" />
            </div>
          </div>
          <button class="primary-btn" type="submit">${tr("addWhBtn")}</button>
        </form>
        <div class="ledger-list" style="margin-top: 14px;">${listHtml}</div>
      `;

      app.openModal(tr("modalWhTitle"), html);

      document.getElementById("whForm").addEventListener("submit", function (event) {
        event.preventDefault();
        const name = document.getElementById("whNameInput").value.trim();
        const loc = document.getElementById("whLocInput").value.trim();
        if (name.length < 2) {
          const err = document.getElementById("whFormError");
          err.textContent = tr("fieldWhName");
          err.classList.remove("hidden");
          return;
        }
        const now = new Date().toISOString();
        global.PBM_DB.put("warehouses", {
          id: global.PBM_DB.generateId("wh"),
          businessId: businessId,
          name: name,
          location: loc,
          isDefault: false,
          createdAt: now,
          updatedAt: now
        }).then(function () {
          app.showToast(tr("toastWhSaved"), false);
          openWarehousesModal();
          app.renderCurrentRoute();
        });
      });

      document.querySelectorAll("[data-del-wh]").forEach(function (btn) {
        btn.addEventListener("click", function () {
          const whId = btn.getAttribute("data-del-wh");
          if (warehouses.length <= 1) {
            app.showToast(tr("errLastWh"), true);
            return;
          }
          global.PBM_DB.remove("warehouses", whId).then(function () {
            openWarehousesModal();
            app.renderCurrentRoute();
          });
        });
      });
    });
  }

  function openStockAdjustModal(preselectedItemId) {
    const app = global.PBM_APP;
    const productItems = viewState.items.filter(function (i) { return i.type !== "SERVICE"; });
    if (productItems.length === 0 || viewState.warehouses.length === 0) {
      app.showToast(tr("emptyTitle"), true);
      return;
    }

    const itemOptions = productItems
      .map(function (i) {
        return `<option value="${app.escapeHtml(i.id)}" ${i.id === preselectedItemId ? "selected" : ""}>${app.escapeHtml(i.name)} (${getTotalStock(i)} ${app.escapeHtml(i.unit || "Pcs")})</option>`;
      })
      .join("");

    const whOptions = viewState.warehouses
      .map(function (w) {
        return `<option value="${app.escapeHtml(w.id)}">${app.escapeHtml(w.name)}</option>`;
      })
      .join("");

    const html = `
      <form id="stockAdjForm" class="form-grid" novalidate>
        <div id="stockAdjErr" class="form-error hidden"></div>
        <div class="form-group">
          <label class="form-label" for="adjItemSelect">${tr("fieldName")}</label>
          <select id="adjItemSelect" class="form-select">${itemOptions}</select>
        </div>
        <div class="form-row-2">
          <div class="form-group">
            <label class="form-label" for="adjMoveType">${tr("fieldMoveType")}</label>
            <select id="adjMoveType" class="form-select">
              <option value="IN">${tr("moveIn")}</option>
              <option value="OUT">${tr("moveOut")}</option>
              <option value="TRANSFER">${tr("moveTransfer")}</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label" for="adjUnitMode">${tr("fieldEntryUnit")}</label>
            <select id="adjUnitMode" class="form-select"></select>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label" for="adjQtyInput">${tr("fieldQty")}</label>
          <input id="adjQtyInput" class="form-input" type="number" min="0.01" step="0.01" required />
        </div>
        <div class="form-row-2">
          <div class="form-group">
            <label class="form-label" for="adjFromWh">${tr("fieldFromWh")}</label>
            <select id="adjFromWh" class="form-select">${whOptions}</select>
          </div>
          <div class="form-group hidden" id="adjToWhWrap">
            <label class="form-label" for="adjToWh">${tr("fieldToWh")}</label>
            <select id="adjToWh" class="form-select">${whOptions}</select>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label" for="adjReasonInput">${tr("fieldReason")}</label>
          <input id="adjReasonInput" class="form-input" type="text" />
        </div>
        <div class="modal-actions">
          <button id="adjCancelBtn" class="secondary-btn" type="button">${tr("cancelBtn")}</button>
          <button class="primary-btn" type="submit">${tr("saveBtn")}</button>
        </div>
      </form>
    `;

    app.openModal(tr("modalStockTitle"), html);
    document.getElementById("adjCancelBtn").addEventListener("click", app.closeModal);

    const itemSel = document.getElementById("adjItemSelect");
    const unitModeSel = document.getElementById("adjUnitMode");
    const moveTypeEl = document.getElementById("adjMoveType");
    const toWhWrap = document.getElementById("adjToWhWrap");

    function refreshUnitOpts() {
      const itm = productItems.find(function (i) { return i.id === itemSel.value; }) || productItems[0];
      let opts = `<option value="1">${app.escapeHtml(itm.unit || "Pcs")} (Base)</option>`;
      if (itm.altUnit && Number(itm.conversionFactor) > 0) {
        opts += `<option value="${Number(itm.conversionFactor)}">${app.escapeHtml(itm.altUnit)} (= ${Number(itm.conversionFactor)} ${app.escapeHtml(itm.unit || "Pcs")})</option>`;
      }
      unitModeSel.innerHTML = opts;
    }
    refreshUnitOpts();
    itemSel.addEventListener("change", refreshUnitOpts);

    moveTypeEl.addEventListener("change", function () {
      toWhWrap.classList.toggle("hidden", moveTypeEl.value !== "TRANSFER");
    });

    document.getElementById("stockAdjForm").addEventListener("submit", function (event) {
      event.preventDefault();
      const errBox = document.getElementById("stockAdjErr");
      const itemId = itemSel.value;
      const moveType = moveTypeEl.value;
      const rawQty = parseFloat(document.getElementById("adjQtyInput").value);
      const mult = parseFloat(unitModeSel.value) || 1;
      const qty = Math.round(rawQty * mult * 1000) / 1000;
      const fromWh = document.getElementById("adjFromWh").value;
      const toWh = document.getElementById("adjToWh").value;
      const reason = document.getElementById("adjReasonInput").value.trim() || moveType;

      if (!rawQty || rawQty <= 0) {
        errBox.textContent = tr("errQtyInvalid");
        errBox.classList.remove("hidden");
        return;
      }

      if (moveType === "TRANSFER" && fromWh === toWh) {
        errBox.textContent = tr("errSameWh");
        errBox.classList.remove("hidden");
        return;
      }

      const businessId = app.getActiveBusinessId();
      let promise;
      if (moveType === "IN") {
        promise = adjustStock(businessId, itemId, fromWh, qty, reason, "");
      } else if (moveType === "OUT") {
        promise = adjustStock(businessId, itemId, fromWh, -qty, reason, "");
      } else {
        promise = adjustStock(businessId, itemId, fromWh, -qty, "Transfer Out: " + reason, "").then(function () {
          return adjustStock(businessId, itemId, toWh, qty, "Transfer In: " + reason, "");
        });
      }

      promise.then(function () {
        return global.PBM_DB.logAudit(businessId, "STOCK_" + moveType, "item", itemId + " qty " + qty);
      }).then(function () {
        app.closeModal();
        app.showToast(tr("toastStockUpdated"), false);
        app.renderCurrentRoute();
      });
    });
  }

  function openStockReportModal() {
    const app = global.PBM_APP;
    const businessId = app.getActiveBusinessId();

    global.PBM_DB.getByBusiness("stockMovements", businessId).then(function (movements) {
      const sortedMoves = movements.sort(function (a, b) {
        return (b.createdAt || "").localeCompare(a.createdAt || "");
      });
      const itemMap = {};
      viewState.items.forEach(function (i) { itemMap[i.id] = i.name; });
      const whMap = {};
      viewState.warehouses.forEach(function (w) { whMap[w.id] = w.name; });

      const valuationRows = viewState.items
        .filter(function (i) { return i.type !== "SERVICE"; })
        .map(function (i) {
          const qty = getTotalStock(i);
          const rate = Number(i.purchasePrice) || Number(i.salePrice) || 0;
          const val = Math.round(Math.max(0, qty) * rate * 100) / 100;
          return { name: i.name, unit: i.unit || "Pcs", qty: qty, rate: rate, value: val };
        });
      const totalVal = valuationRows.reduce(function (s, r) { return s + r.value; }, 0);

      const valHtml = valuationRows
        .map(function (r) {
          return `
            <div class="ledger-row">
              <div class="ledger-row-main">
                <div class="ledger-row-title">${app.escapeHtml(r.name)}</div>
                <div class="list-item-meta">${r.qty} ${app.escapeHtml(r.unit)} × ${app.formatCurrency(r.rate)}</div>
              </div>
              <div class="ledger-row-right tabular-nums">${app.formatCurrency(r.value)}</div>
            </div>
          `;
        })
        .join("");

      const movesHtml = sortedMoves.slice(0, 60)
        .map(function (m) {
          const name = m.itemName || itemMap[m.itemId] || m.itemId;
          const wh = whMap[m.warehouseId] || "Godown";
          return `
            <div class="ledger-row">
              <div class="ledger-row-main">
                <div class="ledger-row-title">${app.escapeHtml(name)} (${app.escapeHtml(wh)})</div>
                <div class="list-item-meta">${app.escapeHtml((m.createdAt || "").slice(0, 10))} · ${app.escapeHtml(m.reason || "")}</div>
              </div>
              <div class="ledger-row-right tabular-nums ${m.qtyDelta >= 0 ? "text-receivable" : "text-payable"}">${m.qtyDelta >= 0 ? "+" : ""}${m.qtyDelta}</div>
            </div>
          `;
        })
        .join("");

      const html = `
        <div class="form-grid">
          <div class="ledger-summary-box">
            <strong>${tr("kpiStockValue")}</strong>
            <strong class="tabular-nums">${app.formatCurrency(totalVal)}</strong>
          </div>
          <div class="btn-row">
            <button id="stkRptPrintBtn" class="primary-btn" type="button">${tr("printPdfBtn")}</button>
            <button id="stkRptCsvBtn" class="secondary-btn" type="button">${tr("exportCsvBtn")}</button>
          </div>
          <strong style="font-size:0.9rem;">Stock Valuation</strong>
          <div class="ledger-list">${valHtml || `<div class="info-note">-</div>`}</div>
          <strong style="font-size:0.9rem;margin-top:8px;">Recent Stock Movements (${sortedMoves.length})</strong>
          <div class="ledger-list">${movesHtml || `<div class="info-note">-</div>`}</div>
        </div>
      `;

      app.openModal(tr("stockReportTitle"), html);

      document.getElementById("stkRptCsvBtn").addEventListener("click", function () {
        const lines = [["Date", "Item", "Warehouse", "Qty Delta", "Reason"]];
        sortedMoves.forEach(function (m) {
          lines.push([
            (m.createdAt || "").slice(0, 10),
            '"' + String(m.itemName || itemMap[m.itemId] || "").replace(/"/g, '""') + '"',
            '"' + String(whMap[m.warehouseId] || "").replace(/"/g, '""') + '"',
            m.qtyDelta,
            '"' + String(m.reason || "").replace(/"/g, '""') + '"'
          ]);
        });
        const blob = new Blob([lines.map(function (r) { return r.join(","); }).join("\n")], { type: "text/csv;charset=utf-8;" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "stock-movements-report.csv";
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
      });

      document.getElementById("stkRptPrintBtn").addEventListener("click", function () {
        const biz = app.getActiveBusiness();
        const tbl = valuationRows
          .map(function (r) {
            return `<tr><td>${app.escapeHtml(r.name)}</td><td style="text-align:right;">${r.qty} ${app.escapeHtml(r.unit)}</td><td style="text-align:right;">${app.formatCurrency(r.rate)}</td><td style="text-align:right;">${app.formatCurrency(r.value)}</td></tr>`;
          })
          .join("");
        global.PBM_PRINT.printHtmlDocument(`
          <div class="print-sheet">
            <h2>${app.escapeHtml(biz ? biz.name : "Business")} — Stock Valuation Report</h2>
            <p>Date: ${new Date().toISOString().slice(0, 10)}</p>
            <table class="print-table">
              <thead><tr><th>Item</th><th style="text-align:right;">Stock</th><th style="text-align:right;">Rate</th><th style="text-align:right;">Value</th></tr></thead>
              <tbody>${tbl}</tbody>
            </table>
            <div class="print-totals"><div><strong>Total Stock Value:</strong><strong>${app.formatCurrency(totalVal)}</strong></div></div>
          </div>
        `);
      });
    });
  }

  function openItemFormModal(existingItem) {
    const app = global.PBM_APP;
    const isEdit = Boolean(existingItem);
    const defaultWhId = viewState.warehouses[0] ? viewState.warehouses[0].id : "default";
    const item = existingItem || {
      name: "",
      type: "PRODUCT",
      sku: "",
      hsn: "",
      unit: "Pcs",
      altUnit: "",
      conversionFactor: 1,
      salePrice: 0,
      purchasePrice: 0,
      gstRate: 18,
      minStock: 5,
      stockByWarehouse: {}
    };

    const whOptions = viewState.warehouses
      .map(function (w) {
        return `<option value="${app.escapeHtml(w.id)}">${app.escapeHtml(w.name)}</option>`;
      })
      .join("");

    const units = ["Pcs", "Box", "Set", "Kg", "SqFt", "Meter", "Litre", "Bag", "Job"];
    const unitOptions = units
      .map(function (u) {
        return `<option value="${u}" ${item.unit === u ? "selected" : ""}>${u}</option>`;
      })
      .join("");

    const altUnitOptions = `<option value="">-- None --</option>` + units
      .map(function (u) {
        return `<option value="${u}" ${item.altUnit === u ? "selected" : ""}>${u}</option>`;
      })
      .join("");

    const gstRates = [0, 5, 12, 18, 28];
    const gstOptions = gstRates
      .map(function (r) {
        return `<option value="${r}" ${Number(item.gstRate) === r ? "selected" : ""}>${r}%</option>`;
      })
      .join("");

    const html = `
      <form id="itemForm" class="form-grid" novalidate>
        <div id="itemFormErr" class="form-error hidden"></div>
        <div class="form-group">
          <label class="form-label" for="itemNameInput">${tr("fieldName")}</label>
          <input id="itemNameInput" class="form-input" type="text" required value="${app.escapeHtml(item.name)}" />
        </div>
        <div class="form-row-2">
          <div class="form-group">
            <label class="form-label" for="itemTypeSelect">${tr("fieldType")}</label>
            <select id="itemTypeSelect" class="form-select">
              <option value="PRODUCT" ${item.type !== "SERVICE" ? "selected" : ""}>${tr("typeProduct")}</option>
              <option value="SERVICE" ${item.type === "SERVICE" ? "selected" : ""}>${tr("typeService")}</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label" for="itemUnitSelect">${tr("fieldUnit")}</label>
            <select id="itemUnitSelect" class="form-select">${unitOptions}</select>
          </div>
        </div>
        <div class="form-row-2">
          <div class="form-group">
            <label class="form-label" for="itemAltUnitSelect">${tr("fieldAltUnit")}</label>
            <select id="itemAltUnitSelect" class="form-select">${altUnitOptions}</select>
          </div>
          <div class="form-group">
            <label class="form-label" for="itemConvInput">${tr("fieldConvFactor")}</label>
            <input id="itemConvInput" class="form-input" type="number" min="1" step="0.01" value="${Number(item.conversionFactor) || 1}" />
          </div>
        </div>
        <div class="form-row-2">
          <div class="form-group">
            <label class="form-label" for="itemSkuInput">${tr("fieldSku")}</label>
            <input id="itemSkuInput" class="form-input" type="text" value="${app.escapeHtml(item.sku)}" />
          </div>
          <div class="form-group">
            <label class="form-label" for="itemHsnInput">${tr("fieldHsn")}</label>
            <input id="itemHsnInput" class="form-input" type="text" value="${app.escapeHtml(item.hsn)}" />
          </div>
        </div>
        <div class="form-row-2">
          <div class="form-group">
            <label class="form-label" for="itemSaleInput">${tr("fieldSalePrice")}</label>
            <input id="itemSaleInput" class="form-input" type="number" min="0" step="0.01" value="${Number(item.salePrice) || 0}" />
          </div>
          <div class="form-group">
            <label class="form-label" for="itemPurchaseInput">${tr("fieldPurchasePrice")}</label>
            <input id="itemPurchaseInput" class="form-input" type="number" min="0" step="0.01" value="${Number(item.purchasePrice) || 0}" />
          </div>
        </div>
        <div class="form-row-2">
          <div class="form-group">
            <label class="form-label" for="itemGstSelect">${tr("fieldGstRate")}</label>
            <select id="itemGstSelect" class="form-select">${gstOptions}</select>
          </div>
          <div class="form-group" id="itemMinStockWrap">
            <label class="form-label" for="itemMinStockInput">${tr("fieldLowStockLimit")}</label>
            <input id="itemMinStockInput" class="form-input" type="number" min="0" step="1" value="${Number(item.minStock) || 0}" />
          </div>
        </div>
        ${
          !isEdit
            ? `
          <div class="form-row-2" id="itemOpeningWrap">
            <div class="form-group">
              <label class="form-label" for="itemOpeningStockInput">${tr("fieldOpeningStock")}</label>
              <input id="itemOpeningStockInput" class="form-input" type="number" min="0" step="0.01" value="0" />
            </div>
            <div class="form-group">
              <label class="form-label" for="itemWhSelect">${tr("fieldWarehouse")}</label>
              <select id="itemWhSelect" class="form-select">${whOptions}</select>
            </div>
          </div>
        `
            : ""
        }
        <div class="modal-actions">
          <button id="itemCancelBtn" class="secondary-btn" type="button">${tr("cancelBtn")}</button>
          <button class="primary-btn" type="submit">${tr("saveBtn")}</button>
        </div>
      </form>
    `;

    app.openModal(isEdit ? tr("modalEditItem") : tr("modalAddItem"), html);
    document.getElementById("itemCancelBtn").addEventListener("click", app.closeModal);

    const typeSelect = document.getElementById("itemTypeSelect");
    function toggleProductFields() {
      const isSvc = typeSelect.value === "SERVICE";
      document.getElementById("itemMinStockWrap").classList.toggle("hidden", isSvc);
      const openWrap = document.getElementById("itemOpeningWrap");
      if (openWrap) openWrap.classList.toggle("hidden", isSvc);
    }
    typeSelect.addEventListener("change", toggleProductFields);
    toggleProductFields();

    document.getElementById("itemForm").addEventListener("submit", function (event) {
      event.preventDefault();
      const errBox = document.getElementById("itemFormErr");
      const name = document.getElementById("itemNameInput").value.trim();
      const type = typeSelect.value;
      const unit = document.getElementById("itemUnitSelect").value;
      const altUnit = document.getElementById("itemAltUnitSelect").value;
      const conversionFactor = Math.max(1, parseFloat(document.getElementById("itemConvInput").value) || 1);
      const sku = document.getElementById("itemSkuInput").value.trim();
      const hsn = document.getElementById("itemHsnInput").value.trim();
      const salePrice = Math.max(0, parseFloat(document.getElementById("itemSaleInput").value) || 0);
      const purchasePrice = Math.max(0, parseFloat(document.getElementById("itemPurchaseInput").value) || 0);
      const gstRate = parseFloat(document.getElementById("itemGstSelect").value) || 0;
      const minStock = type === "SERVICE" ? 0 : Math.max(0, parseFloat(document.getElementById("itemMinStockInput").value) || 0);

      if (name.length < 2) {
        errBox.textContent = tr("errNameReq");
        errBox.classList.remove("hidden");
        return;
      }

      const businessId = app.getActiveBusinessId();
      const now = new Date().toISOString();
      let stockMap = Object.assign({}, item.stockByWarehouse || {});

      if (!isEdit && type !== "SERVICE") {
        const openingQty = Math.max(0, parseFloat(document.getElementById("itemOpeningStockInput").value) || 0);
        const whId = document.getElementById("itemWhSelect").value || defaultWhId;
        stockMap[whId] = openingQty;
      }

      const record = {
        id: isEdit ? item.id : global.PBM_DB.generateId("itm"),
        businessId: businessId,
        name: name,
        type: type,
        unit: unit,
        altUnit: altUnit,
        conversionFactor: conversionFactor,
        sku: sku,
        hsn: hsn,
        salePrice: salePrice,
        purchasePrice: purchasePrice,
        gstRate: gstRate,
        minStock: minStock,
        stockByWarehouse: stockMap,
        createdAt: isEdit ? item.createdAt : now,
        updatedAt: now
      };

      global.PBM_DB.put("items", record)
        .then(function () {
          return global.PBM_DB.logAudit(businessId, isEdit ? "UPDATE" : "CREATE", "item", record.name);
        })
        .then(function () {
          app.closeModal();
          app.showToast(tr("toastSaved"), false);
          app.renderCurrentRoute();
        });
    });
  }

  function exportItemsCsv() {
    const lines = [["Name", "Type", "SKU", "HSN", "Unit", "Alt Unit", "Conversion", "Sale Price", "Purchase Price", "GST %", "Total Stock"]];
    viewState.items.forEach(function (i) {
      lines.push([
        '"' + String(i.name || "").replace(/"/g, '""') + '"',
        i.type,
        i.sku || "",
        i.hsn || "",
        i.unit || "Pcs",
        i.altUnit || "",
        Number(i.conversionFactor || 1),
        Number(i.salePrice || 0).toFixed(2),
        Number(i.purchasePrice || 0).toFixed(2),
        Number(i.gstRate || 0),
        getTotalStock(i)
      ]);
    });
    const blob = new Blob([lines.map(function (r) { return r.join(","); }).join("\n")], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "inventory-export.csv";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
  }

  function renderItemsList(container) {
    const app = global.PBM_APP;
    const query = viewState.search.trim().toLowerCase();
    const whMap = {};
    viewState.warehouses.forEach(function (w) { whMap[w.id] = w.name; });

    const filtered = viewState.items.filter(function (item) {
      if (viewState.filter === "product" && item.type === "SERVICE") return false;
      if (viewState.filter === "service" && item.type !== "SERVICE") return false;
      if (viewState.filter === "low" && !isLowStock(item)) return false;
      if (query) {
        const hay = [item.name, item.sku, item.hsn].join(" ").toLowerCase();
        return hay.indexOf(query) !== -1;
      }
      return true;
    });

    if (filtered.length === 0) {
      container.innerHTML = `
        <div class="card">
          <h3 class="card-title">${tr("emptyTitle")}</h3>
          <p class="card-subtitle">${tr("emptyDesc")}</p>
        </div>
      `;
      return;
    }

    container.innerHTML = filtered
      .map(function (item) {
        const isSvc = item.type === "SERVICE";
        const totalQty = getTotalStock(item);
        const low = isLowStock(item);
        const convText =
          !isSvc && item.altUnit && Number(item.conversionFactor) > 1
            ? " (" + (totalQty / Number(item.conversionFactor)).toFixed(2) + " " + app.escapeHtml(item.altUnit) + ")"
            : "";
        const whBreakdown = isSvc
          ? ""
          : Object.keys(item.stockByWarehouse || {})
              .map(function (whId) {
                return (whMap[whId] || "Godown") + ": " + item.stockByWarehouse[whId];
              })
              .join(" · ");

        return `
          <div class="list-item-card">
            <div class="list-item-top">
              <div>
                <h3 class="list-item-title">${app.escapeHtml(item.name)}</h3>
                <div class="list-item-meta">
                  ${isSvc ? tr("typeService") : tr("typeProduct")}${item.sku ? " · SKU: " + app.escapeHtml(item.sku) : ""}${item.hsn ? " · HSN: " + app.escapeHtml(item.hsn) : ""} · GST ${Number(item.gstRate) || 0}%
                </div>
                <div class="list-item-meta">
                  ${tr("saleRateLabel")}: ${app.formatCurrency(item.salePrice)} · ${tr("purchaseRateLabel")}: ${app.formatCurrency(item.purchasePrice)}
                </div>
                ${whBreakdown ? `<div class="list-item-meta">${app.escapeHtml(whBreakdown)}</div>` : ""}
              </div>
              <div style="text-align:right;">
                ${
                  isSvc
                    ? `<span class="list-item-meta">${tr("typeService")}</span>`
                    : `<div class="kpi-value tabular-nums ${low ? "text-payable" : "text-receivable"}" style="font-size:1.05rem;">${totalQty} ${app.escapeHtml(item.unit || "Pcs")}</div>
                       ${convText ? `<div class="list-item-meta">${convText}</div>` : ""}
                       ${low ? `<div class="list-item-meta text-payable">${tr("lowStockAlert")}</div>` : `<div class="list-item-meta">${tr("stockLabel")}</div>`}`
                }
              </div>
            </div>
            <div class="btn-row">
              ${!isSvc ? `<button class="primary-btn" type="button" data-itm-stk="${app.escapeHtml(item.id)}">${tr("btnStock")}</button>` : ""}
              <button class="secondary-btn" type="button" data-itm-edit="${app.escapeHtml(item.id)}">${tr("btnEdit")}</button>
              <button class="danger-btn" type="button" data-itm-del="${app.escapeHtml(item.id)}">${tr("btnDelete")}</button>
            </div>
          </div>
        `;
      })
      .join("");

    container.querySelectorAll("[data-itm-stk]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        openStockAdjustModal(btn.getAttribute("data-itm-stk"));
      });
    });

    container.querySelectorAll("[data-itm-edit]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        const id = btn.getAttribute("data-itm-edit");
        const found = viewState.items.find(function (i) { return i.id === id; });
        if (found) openItemFormModal(found);
      });
    });

    container.querySelectorAll("[data-itm-del]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        const id = btn.getAttribute("data-itm-del");
        const found = viewState.items.find(function (i) { return i.id === id; });
        if (!found) return;
        app.confirmDialog({
          title: tr("confirmDeleteTitle"),
          message: tr("confirmDeleteMsg"),
          confirmText: tr("deleteBtn"),
          isDanger: true
        }).then(function (ok) {
          if (!ok) return;
          global.PBM_DB.remove("items", id).then(function () {
            app.showToast(tr("toastDeleted"), false);
            app.renderCurrentRoute();
          });
        });
      });
    });
  }

  function render(viewContainer, contextStripHtml) {
    const app = global.PBM_APP;
    const businessId = app.getActiveBusinessId();

    return global.PBM_DB.ensureBusinessMasters(businessId)
      .then(function () {
        return Promise.all([
          global.PBM_DB.getByBusiness("items", businessId),
          global.PBM_DB.getByBusiness("warehouses", businessId),
          getSummary(businessId)
        ]);
      })
      .then(function (results) {
        viewState.items = results[0].sort(function (a, b) {
          return (a.name || "").localeCompare(b.name || "");
        });
        viewState.warehouses = results[1];
        const summary = results[2];

        viewContainer.innerHTML = `
          ${contextStripHtml}
          <div class="kpi-grid">
            <div class="kpi-card">
              <div class="kpi-label">${tr("kpiTotalItems")}</div>
              <div class="kpi-value tabular-nums">${summary.totalItems}</div>
            </div>
            <div class="kpi-card">
              <div class="kpi-label">${tr("kpiLowStock")}</div>
              <div class="kpi-value tabular-nums ${summary.lowStockCount > 0 ? "text-payable" : ""}">${summary.lowStockCount}</div>
            </div>
            <div class="kpi-card">
              <div class="kpi-label">${tr("kpiStockValue")}</div>
              <div class="kpi-value tabular-nums">${app.formatCurrency(summary.totalValue)}</div>
            </div>
          </div>

          <div class="card">
            <div class="toolbar-row">
              <input id="invSearchInput" class="form-input" type="search" placeholder="${tr("searchPlaceholder")}" value="${app.escapeHtml(viewState.search)}" />
              <button id="addItemBtn" class="primary-btn" type="button">${tr("addItemBtn")}</button>
            </div>
            <div class="btn-row" style="margin-top: 10px;">
              <button id="manageWhBtn" class="secondary-btn" type="button">${tr("warehousesBtn")} (${viewState.warehouses.length})</button>
              <button id="quickStockBtn" class="secondary-btn" type="button">${tr("stockAdjustBtn")}</button>
              <button id="stockReportBtn" class="secondary-btn" type="button">${tr("stockReportBtn")}</button>
              <button id="exportInvCsvBtn" class="secondary-btn" type="button">${tr("exportCsvBtn")}</button>
            </div>
            <div class="segmented-bar">
              <button class="seg-btn ${viewState.filter === "all" ? "active" : ""}" data-inv-filter="all" type="button">${tr("filterAll")} (${viewState.items.length})</button>
              <button class="seg-btn ${viewState.filter === "product" ? "active" : ""}" data-inv-filter="product" type="button">${tr("filterProducts")}</button>
              <button class="seg-btn ${viewState.filter === "service" ? "active" : ""}" data-inv-filter="service" type="button">${tr("filterServices")}</button>
              <button class="seg-btn ${viewState.filter === "low" ? "active" : ""}" data-inv-filter="low" type="button">${tr("filterLowStock")} (${summary.lowStockCount})</button>
            </div>
          </div>

          <div id="invListWrap" class="list-stack"></div>
        `;

        const listWrap = document.getElementById("invListWrap");
        renderItemsList(listWrap);

        document.getElementById("addItemBtn").addEventListener("click", function () {
          openItemFormModal(null);
        });
        document.getElementById("manageWhBtn").addEventListener("click", openWarehousesModal);
        document.getElementById("quickStockBtn").addEventListener("click", function () {
          openStockAdjustModal(null);
        });
        document.getElementById("stockReportBtn").addEventListener("click", openStockReportModal);
        document.getElementById("exportInvCsvBtn").addEventListener("click", exportItemsCsv);

        document.getElementById("invSearchInput").addEventListener("input", function (event) {
          viewState.search = event.target.value;
          renderItemsList(listWrap);
        });

        viewContainer.querySelectorAll("[data-inv-filter]").forEach(function (btn) {
          btn.addEventListener("click", function () {
            viewState.filter = btn.getAttribute("data-inv-filter");
            viewContainer.querySelectorAll("[data-inv-filter]").forEach(function (b) {
              b.classList.toggle("active", b === btn);
            });
            renderItemsList(listWrap);
          });
        });
      });
  }

  global.PBM_INVENTORY = {
    render: render,
    getSummary: getSummary,
    adjustStock: adjustStock,
    getTotalStock: getTotalStock
  };
})(window);
