/* =============================================================
   LAMPION POS · js/ui.js
   Pengganti includes/layout/topbar.php, sidebar.php, footer.php
   -------------------------------------------------------------
   Karena tidak ada include PHP lagi, chrome (topbar + sidebar)
   dibangun oleh JavaScript dan disuntikkan ke halaman.
   Menu yang tidak diizinkan permission otomatis disembunyikan
   (padanan `if (can('...'))` di sidebar.php).
   ============================================================= */
(function (global) {
  'use strict';

  /* ---------- ikon SVG inline (padanan includes/layout/icons.php) ---------- */
  var SVG = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" ' +
    'stroke-width="2" stroke-linecap="round" stroke-linejoin="round">';
  var ICONS = {
    dashboard: SVG + '<rect x="3" y="3" width="7" height="9"/><rect x="14" y="3" width="7" height="5"/><rect x="14" y="12" width="7" height="9"/><rect x="3" y="16" width="7" height="5"/></svg>',
    pos: SVG + '<circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.7 13.4a2 2 0 0 0 2 1.6h9.7a2 2 0 0 0 2-1.6L23 6H6"/></svg>',
    menu: SVG + '<path d="M3 6h18M3 12h18M3 18h18"/></svg>',
    category: SVG + '<path d="M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z"/></svg>',
    inventory: SVG + '<path d="M21 8V21H3V8M1 3h22v5H1zM10 12h4"/></svg>',
    sales: SVG + '<path d="M12 1v22M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>',
    users: SVG + '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/></svg>',
    settings: SVG + '<circle cx="12" cy="12" r="3"/><path d="M12 1v3M12 20v3M4.2 4.2l2.1 2.1M17.7 17.7l2.1 2.1M1 12h3M20 12h3M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1"/></svg>',
    activity: SVG + '<path d="M12 8v4l3 3"/><circle cx="12" cy="12" r="9"/></svg>',
    logout: SVG + '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/></svg>',
    expand: SVG + '<path d="M8 3H5a2 2 0 0 0-2 2v3M16 3h3a2 2 0 0 1 2 2v3M8 21H5a2 2 0 0 1-2-2v-3M16 21h3a2 2 0 0 0 2-2v-3"/></svg>',
    compress: SVG + '<path d="M8 3v3a2 2 0 0 1-2 2H3M16 3v3a2 2 0 0 0 2 2h3M8 21v-3a2 2 0 0 0-2-2H3M16 21v-3a2 2 0 0 1 2-2h3"/></svg>',
    receipt: SVG + '<path d="M6 2h12v20l-3-2-3 2-3-2-3 2z"/><path d="M9 7h6M9 11h6M9 15h4"/></svg>',
    cash: SVG + '<rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2.5"/></svg>',
    chart: SVG + '<path d="M3 3v18h18"/><path d="M7 15l4-5 3 3 5-7"/></svg>'
  };

  /* ---------- definisi menu (padanan sidebar.php) ---------- */
  var MENU = [
    { grp: 'Utama' },
    { href: 'index.html', label: 'Ringkasan', icon: 'dashboard', perm: 'dashboard.view' },
    { href: 'pos.html', label: 'Kasir', icon: 'pos', perm: 'pos.order' },
    { grp: 'Master' },
    { href: 'menu.html', label: 'Menu', icon: 'menu', perm: 'menu.view' },
    { href: 'category.html', label: 'Kategori', icon: 'category', perm: 'category.view' },
    { href: 'inventory.html', label: 'Inventory', icon: 'inventory', perm: 'inventory.view' },
    { grp: 'Laporan' },
    { href: 'sales.html', label: 'Penjualan', icon: 'sales', perm: 'sales.view' },
    { href: 'activity.html', label: 'Activity Log', icon: 'activity', perm: 'activity.view' },
    { grp: 'Sistem' },
    { href: 'users.html', label: 'Pengguna', icon: 'users', perm: 'users.manage' },
    { href: 'roles.html', label: 'Peran & Akses', icon: 'users', perm: 'roles.manage' },
    { href: 'settings.html', label: 'Pengaturan', icon: 'settings', perm: 'settings.manage' }
  ];

  function can(p) { return global.LPAUTH.can(p); }

  /** Bangun HTML topbar (padanan topbar.php).
   *  Tombol menu selalu ada; CSS menyembunyikannya di layar lebar
   *  dan pada halaman tanpa sidebar (body.no-sidebar). */
  function topbarHTML(storeName) {
    return '' +
      '<button class="nav-toggle" id="nav-toggle" aria-label="Menu">&#9776;</button>' +
      '<a class="brand" href="' + global.LPAUTH.landingPage() + '">' +
      '<img src="assets/app-icon-192.png" alt=""><span>' + global.LPHP.esc(storeName) + '</span></a>' +
      '<div class="spacer"></div>' +
      '<button class="tb-icon" id="btn-fullscreen" type="button" ' +
      'title="Layar penuh" aria-label="Layar penuh">' + ICONS.expand + '</button>' +
      '<button class="tb-icon tb-logout" id="btn-logout" type="button" ' +
      'title="Keluar" aria-label="Keluar">' + ICONS.logout + '</button>';
  }

  /** Bangun HTML sidebar (menyembunyikan item tanpa permission) */
  function sidebarHTML(active) {
    var html = '<nav class="sidebar" id="sidebar">';
    MENU.forEach(function (m) {
      if (m.grp) {
        html += '<div class="grp">' + global.LPHP.esc(m.grp) + '</div>';
        return;
      }
      if (m.perm && !can(m.perm)) { return; }
      var cls = (active === m.href) ? ' class="active"' : '';
      html += '<a href="' + m.href + '"' + cls + '>' + (ICONS[m.icon] || '') +
        ' ' + global.LPHP.esc(m.label) + '</a>';
    });
    return html + '</nav>';
  }


  /**
   * Suntikkan chrome (topbar + sidebar) ke halaman.
   * @param {string} active nama file halaman aktif
   * @param {Object} [opts] { noSidebar:true } = halaman TANPA navigasi
   *        sama sekali (mis. layar Kasir, yang butuh ruang penuh).
   *
   * Sidebar adalah PANEL GESER (overlay) di semua ukuran layar:
   * tersembunyi secara bawaan, dibuka lewat tombol menu di topbar.
   */
  function mountChrome(active, opts) {
    opts = opts || {};
    var noSidebar = !!opts.noSidebar;
    var host = document.getElementById('chrome');
    var page = document.getElementById('page');

    if (noSidebar) { document.body.classList.add('no-sidebar'); }

    global.LPDB.getSetting('store_name', 'Lampion POS').then(function (nm) {
      var name = String(nm || 'Lampion POS');

      if (host) {
        host.className = 'topbar';
      } else {
        host = document.createElement('div');
        host.className = 'topbar';
        host.id = 'chrome';
        document.body.insertBefore(host, document.body.firstChild);
      }
      host.innerHTML = topbarHTML(name);

      /* sidebar + lapisan gelap; keduanya di luar #page agar tidak
         ikut terpengaruh tata letak konten */
      if (page && !noSidebar) {
        document.body.insertAdjacentHTML('beforeend',
          '<div class="nav-backdrop" id="nav-backdrop"></div>');
        document.body.insertAdjacentHTML('beforeend', sidebarHTML(active));
      }

      /* tombol keluar */
      var lo = document.getElementById('btn-logout');
      if (lo) {
        lo.addEventListener('click', function (e) {
          e.preventDefault();
          global.LP.logout();
        });
      }

      /* tombol layar penuh (tersedia di semua halaman) */
      bindFullscreenButton();

      /* ---------- buka/tutup panel navigasi ---------- */
      bindNavDrawer();
    });
  }

  /** Atur buka/tutup panel navigasi geser */
  function bindNavDrawer() {
    var tg = document.getElementById('nav-toggle');
    var side = document.getElementById('sidebar');
    var backdrop = document.getElementById('nav-backdrop');
    if (!tg || !side) { return; }

    function close() { document.body.classList.remove('nav-open'); }
    function toggle() { document.body.classList.toggle('nav-open'); }

    tg.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      toggle();
    });

    /* klik lapisan gelap -> tutup */
    if (backdrop) { backdrop.addEventListener('click', close); }

    /* klik tautan menu -> tutup panel (halaman akan berpindah) */
    side.addEventListener('click', function (e) {
      if (e.target.closest('a')) { close(); }
    });

    /* tombol Esc -> tutup */
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') { close(); }
    });
  }

  /* =============================================================
     Layar penuh (kios)
     ============================================================= */

  function fsElement() {
    return document.fullscreenElement
      || document.webkitFullscreenElement
      || document.mozFullScreenElement
      || null;
  }

  function fsSupported() {
    var el = document.documentElement;
    return !!(el.requestFullscreen || el.webkitRequestFullscreen || el.mozRequestFullScreen);
  }

  /** Masuk/keluar layar penuh */
  function toggleFullscreen() {
    if (!fsSupported()) { return false; }
    var el = document.documentElement;
    if (fsElement()) {
      var exit = document.exitFullscreen || document.webkitExitFullscreen
        || document.mozCancelFullScreen;
      if (exit) { exit.call(document); }
      return true;
    }
    var req = el.requestFullscreen || el.webkitRequestFullscreen || el.mozRequestFullScreen;
    if (req) {
      /* beberapa browser mengembalikan Promise yang bisa ditolak */
      try {
        var p = req.call(el);
        if (p && typeof p.catch === 'function') { p.catch(function () { /* diabaikan */ }); }
      } catch (e) { /* diabaikan */ }
    }
    return true;
  }

  /** Minta layar penuh sekali (dipakai mode kios saat halaman dibuka) */
  function enableFullscreen() {
    if (!fsSupported()) { return; }
    /* Browser hanya mengizinkan fullscreen setelah ada interaksi pengguna.
       Jadi kita coba sekali, lalu pasang pemicu pada sentuhan pertama. */
    toggleFullscreen();
    if (fsElement()) { return; }
    var once = function () {
      document.removeEventListener('click', once, true);
      document.removeEventListener('touchstart', once, true);
      toggleFullscreen();
    };
    document.addEventListener('click', once, true);
    document.addEventListener('touchstart', once, true);
  }

  /** Pasang tombol layar penuh di topbar & jaga ikonnya tetap benar */
  function bindFullscreenButton() {
    var btn = document.getElementById('btn-fullscreen');
    if (!btn) { return; }

    if (!fsSupported()) { btn.style.display = 'none'; return; }

    btn.addEventListener('click', function () { toggleFullscreen(); });

    var sync = function () {
      var on = !!fsElement();
      btn.innerHTML = on ? ICONS.compress : ICONS.expand;
      btn.title = on ? 'Keluar layar penuh' : 'Layar penuh';
      btn.setAttribute('aria-label', btn.title);
      document.body.classList.toggle('is-fullscreen', on);
    };
    sync();
    ['fullscreenchange', 'webkitfullscreenchange', 'mozfullscreenchange']
      .forEach(function (ev) { document.addEventListener(ev, sync); });
  }

  /* ---------- helper ikon & tampilan ---------- */
  function icon(name) { return ICONS[name] || ''; }

  function statusBadge(status) {
    var map = {
      paid: ['ok', 'Lunas'], hold: ['warn', 'Ditahan'], canceled: ['err', 'Dibatalkan']
    };
    var m = map[status] || ['mute', status];
    return '<span class="badge ' + m[0] + '">' + global.LPHP.esc(m[1]) + '</span>';
  }

  function emptyRow(colspan, title, sub) {
    return '<tr><td colspan="' + colspan + '"><div class="empty-state"><b>' +
      global.LPHP.esc(title) + '</b>' + global.LPHP.esc(sub || '') + '</div></td></tr>';
  }

  function useBadge(active) {
    return active
      ? '<span class="badge ok">Aktif</span>'
      : '<span class="badge mute">Non-aktif</span>';
  }

  /* ---------- modal dinamis ---------- */
  function modal(opts) {
    var id = 'md-' + global.LPDB.randomHex(4);
    var html = '' +
      '<div class="modal-overlay" id="' + id + '">' +
      '<div class="modal" style="max-width:' + (opts.width || 520) + 'px">' +
      '<div class="modal-head"><h3>' + global.LPHP.esc(opts.title || '') + '</h3>' +
      '<button class="x" type="button" data-x>&times;</button></div>' +
      '<div class="modal-body">' + (opts.body || '') + '</div>' +
      '<div class="modal-foot">' + (opts.foot ||
        '<button class="btn" data-x type="button">Tutup</button>') + '</div>' +
      '</div></div>';
    var wrap = document.createElement('div');
    wrap.innerHTML = html;
    var el = wrap.firstChild;
    document.body.appendChild(el);

    function close() {
      el.classList.remove('open');
      setTimeout(function () {
        if (el.parentNode) { el.parentNode.removeChild(el); }
      }, 180);
    }
    el.querySelectorAll('[data-x]').forEach(function (b) {
      b.addEventListener('click', close);
    });
    el.addEventListener('click', function (e) { if (e.target === el) { close(); } });

    global.LP.openModal(el);
    return { el: el, close: close };
  }

  global.LPUI = {
    ICONS: ICONS,
    MENU: MENU,
    icon: icon,
    mountChrome: mountChrome,
    statusBadge: statusBadge,
    emptyRow: emptyRow,
    useBadge: useBadge,
    modal: modal,
    /* layar penuh (kios) */
    toggleFullscreen: toggleFullscreen,
    enableFullscreen: enableFullscreen,
    isFullscreen: function () { return !!fsElement(); },
    fullscreenSupported: fsSupported
  };
})(window);
