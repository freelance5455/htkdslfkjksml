const UI = {
  showScreen(id) {
    document.querySelectorAll('.screen').forEach(el => el.classList.remove('active'));
    document.getElementById(id).classList.add('active');
  },
  setMatchmakingCount(found, min, max) {
    document.getElementById('mm-count').textContent =
      `PLAYERS FOUND: ${found}/${max} (min ${min} to start)`;
  },
  setCountdown(sec) {
    document.getElementById('mm-countdown').textContent =
      sec > 0 ? `MATCH STARTING IN ${sec}` : '';
  },
  setHealth(hp) {
    document.getElementById('health-fill').style.width = Math.max(hp, 0) + '%';
  },
  setRoomTag(text) {
    document.getElementById('room-tag').textContent = text;
  },
  showEliminated() {
    document.getElementById('eliminated-banner').classList.add('active');
  },
  hideEliminated() {
    document.getElementById('eliminated-banner').classList.remove('active');
  },
  hideVictory() {
    document.getElementById('victory-banner').classList.remove('active');
  },
  showVictory(data) {
    const el = document.getElementById('victory-banner');
    el.querySelector('.headline').textContent = data.winner
      ? `#1 LAST SURVIVOR: ${data.winner.username}`
      : 'MATCH ENDED';
    el.classList.add('active');
  },
  setDebug(text) {
    document.getElementById('debug-panel').textContent = text;
  },
};
