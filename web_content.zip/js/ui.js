/* ============================================================
   AETHERVALE — DOM interface: home screen & all shop panels
   ============================================================ */
const UI = {
  root: null, home: null, modal: null, panelBody: null, panelTitle: null,
  sel: { enhance: null, socket: null, enchant: null, invTab: 'gear', invSel: null,
         ah: { q: '', type: 'all', rarity: 'all', sort: 'value', chart: 'm_stone', tab: 'buy' },
         inherit: { src: null, dst: null }, lastEnchant: null },

  /* ---------------- layar muat (loading) ---------------- */
  initBoot() {
    this.bootEl = document.getElementById('boot');
    this.loginEl = document.getElementById('login');
    this.home.classList.add('hidden');
    this.loginEl.classList.add('hidden');
    this.bootEl.classList.remove('hidden');
    this.bootEl.innerHTML = `
      <div class="boot-inner">
        ${this.logoSVG()}
        <h1 class="title">AETHERVALE</h1>
        <p class="boot-sub">MMORPG Piksel Dunia Terbuka Tanpa Batas</p>
        <div class="bar"><i id="bootBar"></i></div>
        <p class="boot-step" id="bootStep">Menyalakan mesin…</p>
        <p class="boot-tip" id="bootTip"></p>
      </div>`;
    const tips = [
      'Musuh tidak akan menyerang lebih dulu — kaulah yang memilih pertarungan.',
      'Dunia tidak punya tepi: petak baru terbentuk otomatis saat kau melewati batas lama.',
      'Simpan Gulungan Perlindungan untuk tempaan +6 ke atas.',
      'Ada 64 bioma dari Samudra Beku sampai End Highlands.',
    ];
    document.getElementById('bootTip').textContent = tips[Math.floor(Math.random() * tips.length)];
    const tasks = [
      ['Menyiapkan atlas piksel', () => { for (const c of CLASSES) Art.humanoid({ key: 'pre' + c.id, skin: '#e8b98a', hair: '#2f2420', tunic: c.tint, pants: '#38304a', weapon: true }, 0, 0); }],
      ['Menyusun tabel bioma', () => { let n = 0; for (const k in BIOMES) { Art.tree(k, 0); n++; } return n; }],
      ['Membentuk Kota Serambi', () => { for (const b of World.BUILDINGS) Art.building(b.kind); }],
      ['Merender petak awal dunia', () => { for (let cy = -2; cy <= 2; cy++) for (let cx = -2; cx <= 2; cx++) World.getT(cx * World.CH, cy * World.CH); }],
      ['Menyiapkan ikon barang', () => { let i = 0; for (const k in ITEMS) { if (i++ > 40) break; Art.itemIcon(ITEMS[k], 24); } }],
      ['Menyetel pasar lelang', () => { }],
      ['Mengunci bingkai layar penuh', () => Game.applyResolution()],
    ];
    let i = 0;
    const bar = document.getElementById('bootBar'), step = document.getElementById('bootStep');
    const next = () => {
      if (i >= tasks.length) {
        bar.style.width = '100%'; step.textContent = 'Siap.';
        setTimeout(() => this.showPresents(), 420);
        return;
      }
      const [label, fn] = tasks[i];
      step.textContent = label + '…';
      bar.style.width = Math.round((i / tasks.length) * 100) + '%';
      setTimeout(() => { try { fn(); } catch (e) { console.warn(e); } i++; next(); }, 190);
    };
    next();
  },

  /* ---------------- layar "wappy games present" ---------------- */
  showPresents() {
    this.bootEl.classList.add('hidden');
    const el = this.loginEl;
    el.classList.remove('hidden');
    el.classList.add('presents');
    el.innerHTML = `
      <div class="presents-inner">
        <div class="pr-logo">${this.logoSVG()}</div>
        <h2 class="pr-name">WAPPY GAMES</h2>
        <p class="pr-word">PRESENT</p>
      </div>`;
    let done = false;
    const go = () => {
      if (done) return; done = true;
      el.classList.add('fade');
      setTimeout(() => {
        el.classList.add('hidden'); el.classList.remove('presents', 'fade');
        el.innerHTML = '';
        this.showHome(); this.syncAccount();
      }, 480);
    };
    el.onclick = go;
    setTimeout(go, 2600);
  },
  syncAccount() {
    const el = document.getElementById('accountChip');
    if (!el) return;
    const inf = (typeof Save !== 'undefined' && Save.info()) || null;
    if (inf) {
      el.innerHTML = `<b>Simpanan otomatis</b> · ${inf.cls} Lv ${inf.level} · ${inf.time} · ${inf.when}
        <button class="btn tiny" id="btnWipe">HAPUS SIMPANAN</button>`;
      const w = document.getElementById('btnWipe');
      if (w) w.onclick = () => { Save.clear(); this.syncAccount(); if (UI.refreshContinue) UI.refreshContinue(); };
    } else {
      el.innerHTML = `<b>Belum ada simpanan</b> · kemajuanmu tersimpan otomatis setiap 15 detik saat bermain`;
    }
  },

  /* ---------------- home ---------------- */
  initHome() {
    this.root = document.getElementById('ui');
    this.home = document.getElementById('home');
    this.modal = document.getElementById('modal');
    this.home.innerHTML = `
      <div class="home-inner">
        <div class="logo-row">
          ${this.logoSVG()}
          <div>
            <h1 class="title">AETHERVALE</h1>
            <p class="subtitle">MMORPG Piksel Dunia Tanpa Batas · Satu Kisah Utuh ±27 Menit</p>
          </div>
        </div>
        <p class="pitch">Lonceng Serambi pecah dan kabut Aether merangkak turun. Dunia dibentuk tanpa tepi — 64 bioma
        dari Samudra Beku sampai End Highlands terus tersusun saat kau berjalan. Musuh hanya melawan bila kau serang lebih dulu.</p>
        <div class="account-chip" id="accountChip"></div>
        <div class="class-grid" id="classGrid"></div>
        <div class="home-actions">
          <button class="btn primary" id="btnStart">MAIN</button>
          <button class="btn" id="btnSettings">PENGATURAN</button>
          <button class="btn" id="btnFull">LAYAR PENUH</button>
          <button class="btn" id="btnHelp">PANDUAN</button>
          <button class="btn" id="btnFeat">FITUR</button>
        </div>
        <div class="home-note" id="homeNote">Pilih kelas lalu tekan MAIN — kisahnya langsung berjalan tanpa bab. Suara aktif setelah klik pertama.
        <span class="touch-hint"> Di ponsel: pakai joystick kiri untuk berjalan dan tombol kanan untuk aksi — mode lanskap lebih luas.</span></div>
      </div>`;
    const grid = document.getElementById('classGrid');
    grid.innerHTML = CLASSES.map((c, i) => `
      <button class="class-card${i === 0 ? ' active' : ''}" data-cls="${c.id}">
        <span class="cc-dot" style="background:${c.tint}"></span>
        <span class="cc-name">${c.name}</span>
        <span class="cc-blurb">${c.blurb}</span>
        <span class="cc-stats">HP ${c.hp} · ATK ${c.atk} · DEF ${c.def} · KRIT ${c.crit}%</span>
        <span class="cc-skill">${c.skill}</span>
      </button>`).join('');
    let chosen = CLASSES[0].id;
    grid.querySelectorAll('.class-card').forEach(b => b.onclick = () => {
      grid.querySelectorAll('.class-card').forEach(x => x.classList.remove('active'));
      b.classList.add('active'); chosen = b.dataset.cls; Audio2.init(); Audio2.sfx('ui');
    });
    document.getElementById('btnStart').onclick = () => { Audio2.init(); Audio2.sfx('ok'); Game.start(chosen); };
    document.getElementById('btnSettings').onclick = () => { Audio2.init(); this.openPanel('settings'); };
    document.getElementById('btnFull').onclick = () => { Audio2.init(); Game.toggleBigScreen(); };
    document.getElementById('btnHelp').onclick = () => { Audio2.init(); this.openPanel('help'); };
    document.getElementById('btnFeat').onclick = () => { Audio2.init(); this.openPanel('features'); };
    this.syncAccount();
    this.applyTouchMode();
  },
  onResize() { this.applyTouchMode(); },
  applyTouchMode() {
    const mode = Game.settings.touchControls;
    const coarse = matchMedia('(hover:none) and (pointer:coarse)').matches;
    const on = mode === 'always' || (mode === 'auto' && coarse);
    document.body.classList.toggle('touch-on', on);
  },
  updateFpsBadge() {
    const el = document.getElementById('fpsBadge');
    if (!el) return;
    const show = Game.settings.showFps && Game.state !== 'play';
    el.classList.toggle('hidden', !show);
    if (show) el.textContent = `${Game.fps} FPS · ${G.VW}×${G.VH}`;
  },
  logoSVG() {
    return `<svg class="logo" viewBox="0 0 48 48" aria-label="Lambang Aethervale" fill="none">
      <rect x="4" y="4" width="40" height="40" stroke="currentColor" stroke-width="2"/>
      <path d="M24 10 L36 34 H12 Z" stroke="currentColor" stroke-width="2"/>
      <path d="M24 20 V38" stroke="currentColor" stroke-width="2"/>
      <circle cx="24" cy="17" r="3" fill="currentColor"/>
    </svg>`;
  },
  hideHome() { this.home.classList.add('hidden'); },
  showHome() { this.home.classList.remove('hidden'); },

  renderHomeCanvas(ctx, t) {
    // animated pixel landscape
    const g = ctx.createLinearGradient(0, 0, 0, G.VH);
    g.addColorStop(0, '#1a1030'); g.addColorStop(0.45, '#3b2258'); g.addColorStop(1, '#6b3a5a');
    ctx.fillStyle = g; ctx.fillRect(0, 0, G.VW, G.VH);
    for (let i = 0; i < 60; i++) {
      const x = (i * 71) % G.VW, y = (i * 37) % 110;
      ctx.globalAlpha = 0.3 + 0.7 * Math.abs(Math.sin(t * 0.8 + i));
      ctx.fillStyle = '#ffeccd'; ctx.fillRect(x, y, 1, 1);
    }
    ctx.globalAlpha = 1;
    // moon — soft radial glow + pixel disc
    const mx = G.VW - 78, my = 46, mr = 13;
    const gl = ctx.createRadialGradient(mx, my, 2, mx, my, mr * 3.4);
    gl.addColorStop(0, 'rgba(255,240,210,0.6)');
    gl.addColorStop(0.45, 'rgba(255,225,185,0.2)');
    gl.addColorStop(1, 'rgba(255,220,180,0)');
    ctx.fillStyle = gl; ctx.fillRect(mx - mr * 3.4, my - mr * 3.4, mr * 6.8, mr * 6.8);
    for (let y = -mr; y <= mr; y++) {
      const w = Math.floor(Math.sqrt(mr * mr - y * y));
      ctx.fillStyle = y < -mr * 0.35 ? '#fffdf6' : '#fff3da';
      ctx.fillRect(mx - w, my + y, w * 2, 1);
    }
    ctx.fillStyle = 'rgba(190,160,120,0.35)';
    ctx.fillRect(mx - 4, my - 3, 4, 3); ctx.fillRect(mx + 3, my + 2, 3, 3); ctx.fillRect(mx - 1, my + 6, 2, 2);
    // mountains
    const layers = [{ c: '#2a1c3e', h: 90, s: 0.9 }, { c: '#382451', h: 120, s: 1.3 }, { c: '#46305f', h: 150, s: 1.8 }];
    layers.forEach((L, li) => {
      ctx.fillStyle = L.c;
      for (let x = 0; x < G.VW; x += 4) {
        const hh = L.h + Math.sin((x + li * 40) * 0.02 + li) * 22 + Math.sin(x * 0.07) * 6;
        ctx.fillRect(x, hh, 4, G.VH - hh);
      }
    });
    // ground silhouette + trees
    ctx.fillStyle = '#1d1430'; ctx.fillRect(0, G.VH - 52, G.VW, 52);
    for (let i = 0; i < 16; i++) {
      const x = (i * 43 + 10) % G.VW;
      const sway = Math.sin(t * 1.2 + i) * 1.2;
      ctx.fillStyle = '#120d20';
      ctx.fillRect(x + sway, G.VH - 76, 3, 26);
      ctx.fillRect(x - 6 + sway, G.VH - 86, 15, 14);
      ctx.fillRect(x - 3 + sway, G.VH - 94, 9, 10);
    }
    // fireflies
    for (let i = 0; i < 26; i++) {
      const x = (i * 97 + Math.sin(t * 0.5 + i) * 30) % G.VW;
      const y = G.VH - 40 - ((i * 31) % 50) + Math.cos(t + i) * 6;
      ctx.globalAlpha = 0.4 + 0.6 * Math.abs(Math.sin(t * 2 + i));
      ctx.fillStyle = '#ffe483'; ctx.fillRect(x, y, 2, 2);
      ctx.globalAlpha = 1;
    }
    // hero + mist
    const img = Art.humanoid({ key: 'homehero', skin: '#e8b98a', hair: '#2f2420', tunic: '#6fa8ff', pants: '#38304a', weapon: true }, 0, Math.floor(t * 3) % 4);
    ctx.drawImage(img, 0, 0, 16, 20, Math.round(G.VW * 0.74), G.VH - 78, 32, 40);
    ctx.fillStyle = 'rgba(150,120,220,0.16)';
    for (let i = 0; i < 6; i++) ctx.fillRect(0, G.VH - 60 + i * 9, G.VW, 4);
  },

  /* ---------------- touch pad (phones / tablets) ---------------- */
  initTouchPad() {
    const root = document.getElementById('ui');
    const btns = [
      ['SERANG', 'atk'], ['Q', 'KeyQ'], ['E', 'KeyE'], ['F', 'KeyF'],
      ['TAS', 'KeyI'], ['MISI', 'KeyJ'], ['PETA', 'KeyM'],
    ];
    root.innerHTML = `
      <div class="joystick" id="joy"><i class="jknob" id="joyKnob"></i><span>GERAK</span></div>
      <div class="touchpad">
        ${btns.map(([l, c]) => `<button class="tbtn${c === 'atk' ? ' big' : ''}" data-code="${c}">${l}</button>`).join('')}
      </div>
      <button class="fsbtn" id="btnFsPlay" title="Layar penuh">⛶</button>
      <div class="fps-badge hidden" id="fpsBadge"></div>`;
    // joystick (sentuh + tetikus)
    const joy = document.getElementById('joy'), knob = document.getElementById('joyKnob');
    let active = false, cx = 0, cy = 0;
    const R = 34;
    const move = (px, py) => {
      let dx = px - cx, dy = py - cy;
      const d = Math.hypot(dx, dy);
      if (d > R) { dx = dx / d * R; dy = dy / d * R; }
      knob.style.transform = `translate(${dx}px, ${dy}px)`;
      const n = Math.max(0, Math.min(1, (d - 4) / R));
      const k = d ? n / d : 0;
      Input.touchVec.x = (px - cx) * k; Input.touchVec.y = (py - cy) * k;
    };
    const stop = () => { active = false; knob.style.transform = 'translate(0,0)'; Input.touchVec.x = 0; Input.touchVec.y = 0; };
    joy.addEventListener('pointerdown', e => {
      e.preventDefault(); Audio2.init();
      const r = joy.getBoundingClientRect();
      cx = r.left + r.width / 2; cy = r.top + r.height / 2;
      active = true; joy.setPointerCapture(e.pointerId); move(e.clientX, e.clientY);
    });
    joy.addEventListener('pointermove', e => { if (active) { e.preventDefault(); move(e.clientX, e.clientY); } });
    joy.addEventListener('pointerup', stop);
    joy.addEventListener('pointercancel', stop);
    joy.addEventListener('lostpointercapture', stop);
    document.getElementById('btnFsPlay').onclick = e => { e.preventDefault(); Game.toggleBigScreen(); };
    root.querySelectorAll('.tbtn').forEach(b => {
      const code = b.dataset.code;
      const fire = e => {
        e.preventDefault();
        Audio2.init();
        if (code === 'atk') { Input.keys['Space'] = true; setTimeout(() => { Input.keys['Space'] = false; }, 200); }
        else if (code === 'KeyQ') { Input.just['KeyQ'] = true; setTimeout(() => { Input.just['KeyQ'] = false; }, 60); Game.skill(); }
        else Game.onKey(code);
      };
      b.addEventListener('touchstart', fire, { passive: false });
      b.addEventListener('click', fire);
    });
  },

  /* ---------------- HUD sync (called by game) ---------------- */
  syncHUD() {},
  syncQuest() {},

  togglePause() {
    Game.paused = !Game.paused;
    Audio2.sfx('ui');
  },

  /* ---------------- modal shell ---------------- */
  openPanel(kind) {
    if (Game.state === 'cutscene') return;
    Game.activePanel = kind;
    Audio2.sfx('ui');
    this.modal.classList.remove('hidden');
    this.modal.innerHTML = `
      <div class="sheet" data-kind="${kind}">
        <header class="sheet-head">
          <h2 id="sheetTitle"></h2>
          <button class="btn small" id="closeSheet">TUTUP [ESC]</button>
        </header>
        <div class="sheet-body" id="sheetBody"></div>
        <footer class="sheet-foot"><span id="goldFoot"></span><span id="msgFoot"></span></footer>
      </div>`;
    document.getElementById('closeSheet').onclick = () => this.closePanel();
    this.modal.onclick = e => { if (e.target === this.modal) this.closePanel(); };
    this.render();
  },
  closePanel() { Game.activePanel = null; this.modal.classList.add('hidden'); this.modal.innerHTML = ''; Audio2.sfx('ui'); },
  msg(text, ok) {
    const m = document.getElementById('msgFoot');
    if (m) { m.textContent = text; m.className = ok === false ? 'bad' : ok === true ? 'good' : ''; }
  },
  render() {
    const kind = Game.activePanel; if (!kind) return;
    const titles = {
      inventory: 'Tas & Karakter', auction: 'Balai Lelang — Pasar Pemain', shop: 'Toko Tama',
      enhance: 'Pandai Besi Borin — Penempaan (+1 … +10)', socket: 'Tukang Permata Wen — Soket Permata',
      enchant: 'Perapal Ilya — Sihir Peralatan', inherit: 'Balai Warisan Nadia — Transfer Status',
      quest: 'Jurnal Kisah', map: 'Peta Aethervale', help: 'Panduan Bermain', features: 'Fitur Permainan',
      settings: 'Pengaturan — Grafik & Kendali',
    };
    document.getElementById('sheetTitle').textContent = titles[kind] || kind;
    const gf = document.getElementById('goldFoot');
    if (gf && Game.player) gf.innerHTML = `<b>${fmt(Game.player.gold)}</b> Gold · Daya Tempur <b>${fmt(Game.player.power || 0)}</b> · Lv ${Game.player.level}`;
    const body = document.getElementById('sheetBody');
    body.innerHTML = this['view_' + kind] ? this['view_' + kind]() : '';
    if (this['wire_' + kind]) this['wire_' + kind]();
  },

  /* ---------------- shared bits ---------------- */
  icon(item, size) {
    const c = Art.itemIcon(item, size || 24);
    return `<img class="icon" width="${size || 24}" height="${size || 24}" src="${c.toDataURL()}" alt="">`;
  },
  instCard(inst, opts) {
    opts = opts || {};
    const t = tpl(inst);
    const st = itemStats(inst);
    const socks = (inst.sockets || []).map(g => g
      ? `<span class="sock filled" style="--c:${GEMS[g].color}" title="${GEMS[g].name}: ${GEMS[g].desc}"></span>`
      : `<span class="sock"></span>`).join('');
    return `
      <div class="item-card ${opts.active ? 'active' : ''}" data-uid="${inst.uid}" style="--rc:${itemColor(inst)}">
        <div class="ic-top">${this.icon(t, 28)}
          <div class="ic-name">
            <b style="color:${itemColor(inst)}">${itemName(inst)}</b>
            <small>${SLOTS[t.type] || t.type} · ${RARITY[t.rarity || 'common'].name} · T${t.tier || 1}${opts.equipped ? ' · <span class="eqd">DIPAKAI</span>' : ''}</small>
          </div>
          <div class="ic-power">${fmt(itemPower(inst))}</div>
        </div>
        <div class="ic-stats">${Object.keys(st).map(k => `<span>${statLine(k, st[k])}</span>`).join('')}</div>
        ${inst.enchant ? `<div class="ic-ench" style="color:${inst.enchant.color}">✦ ${inst.enchant.name} ${inst.enchant.grade} — +${inst.enchant.val}${STAT_SUFFIX[inst.enchant.stat] || ''} ${STAT_LABEL[inst.enchant.stat]}</div>` : ''}
        ${(inst.sockets || []).length ? `<div class="ic-socks">${socks}</div>` : ''}
      </div>`;
  },
  gearPicker(selectedUid, idPrefix, filterType) {
    const P = Game.player;
    const eq = Object.keys(P.equip).filter(s => P.equip[s]).map(s => ({ inst: P.equip[s], eq: true }));
    const inv = Inv.gearList().map(i => ({ inst: i, eq: false }));
    let all = eq.concat(inv);
    if (filterType) all = all.filter(x => tpl(x.inst).type === filterType);
    if (!all.length) return `<p class="empty">Tidak ada peralatan yang cocok. Cari drop atau beli di Balai Lelang.</p>`;
    return `<div class="picker">${all.map(x => `
      <button class="pick ${String(selectedUid) === String(x.inst.uid) ? 'on' : ''}" data-pick="${idPrefix}" data-uid="${x.inst.uid}">
        ${this.icon(tpl(x.inst), 20)}
        <span class="pk-name" style="color:${itemColor(x.inst)}">${itemName(x.inst)}</span>
        <span class="pk-tag">${x.eq ? 'dipakai' : SLOTS[tpl(x.inst).type]}</span>
      </button>`).join('')}</div>`;
  },
  wirePicker(prefix, cb) {
    this.modal.querySelectorAll(`[data-pick="${prefix}"]`).forEach(b => b.onclick = () => {
      cb(Number(b.dataset.uid)); Audio2.sfx('ui'); this.render();
    });
  },

  /* ---------------- Inventory / character ---------------- */
  view_inventory() {
    const P = Game.player;
    const tabs = [['gear', 'Peralatan'], ['mat', 'Bahan & Permata'], ['all', 'Semua']];
    let items = P.inv;
    if (this.sel.invTab === 'gear') items = P.inv.filter(isGear);
    else if (this.sel.invTab === 'mat') items = P.inv.filter(i => !isGear(i));
    const sel = this.sel.invSel ? Inv.byUid(this.sel.invSel) : null;
    const s = P.stats;
    return `
    <div class="cols two">
      <section>
        <h3>Karakter — ${Game.cls.name}</h3>
        <div class="statbox">
          ${['hp', 'atk', 'def', 'crit', 'critdmg', 'life', 'haste', 'spd'].map(k =>
            `<div><span>${STAT_LABEL[k]}</span><b>${Math.round((s[k] || 0) * 10) / 10}${STAT_SUFFIX[k] || ''}</b></div>`).join('')}
        </div>
        <h3>Slot Peralatan</h3>
        <div class="slots">
          ${Object.keys(SLOTS).map(slot => {
            const it = P.equip[slot];
            return `<div class="slot ${it ? 'filled' : ''}" data-slot="${slot}">
              <div class="sl-label">${SLOTS[slot]}</div>
              ${it ? `${this.icon(tpl(it), 24)}<div class="sl-name" style="color:${itemColor(it)}">${itemName(it)}</div>
                      <button class="btn tiny" data-unequip="${slot}">LEPAS</button>`
                  : `<div class="sl-empty">kosong</div>`}
            </div>`;
          }).join('')}
        </div>
      </section>
      <section>
        <h3>Tas (${P.inv.length} slot terpakai)</h3>
        <div class="tabs">${tabs.map(([k, n]) => `<button class="tab ${this.sel.invTab === k ? 'on' : ''}" data-invtab="${k}">${n}</button>`).join('')}</div>
        <div class="grid-items">
          ${items.length ? items.map(i => `
            <button class="gi ${this.sel.invSel === i.uid ? 'on' : ''}" data-inv="${i.uid}" style="--rc:${itemColor(i)}" title="${tpl(i).name}">
              ${this.icon(tpl(i), 28)}
              ${i.qty > 1 ? `<span class="qty">${i.qty}</span>` : ''}
              ${(i.plus || 0) > 0 ? `<span class="plus">+${i.plus}</span>` : ''}
            </button>`).join('') : '<p class="empty">Tas kosong di kategori ini.</p>'}
        </div>
        ${sel ? `
          <div class="detail">
            ${isGear(sel) ? this.instCard(sel, { equipped: Object.values(P.equip).some(e => e && e.uid === sel.uid) }) : `
              <div class="item-card" style="--rc:${itemColor(sel)}">
                <div class="ic-top">${this.icon(tpl(sel), 28)}
                  <div class="ic-name"><b style="color:${itemColor(sel)}">${tpl(sel).name}${sel.qty > 1 ? ' x' + sel.qty : ''}</b>
                  <small>${tpl(sel).type === 'gem' ? 'Permata' : tpl(sel).type === 'potion' ? 'Konsumsi' : 'Bahan'} · ${RARITY[tpl(sel).rarity].name}</small></div>
                </div>
                <div class="ic-ench">${tpl(sel).desc || ''}</div>
              </div>`}
            <div class="row">
              ${isGear(sel) && !Object.values(P.equip).some(e => e && e.uid === sel.uid) ? `<button class="btn primary" id="doEquip">PAKAI</button>` : ''}
              ${tpl(sel).type === 'potion' ? `<button class="btn primary" id="doDrink">MINUM</button>` : ''}
              <button class="btn" id="doSell">JUAL CEPAT — ${fmt(Math.round(itemValue(sel) * (Market.price[sel.tid] || 1) * 0.85))} G</button>
            </div>
          </div>` : '<p class="hint">Klik sebuah barang untuk melihat detail.</p>'}
      </section>
    </div>`;
  },
  wire_inventory() {
    this.modal.querySelectorAll('[data-invtab]').forEach(b => b.onclick = () => { this.sel.invTab = b.dataset.invtab; this.render(); });
    this.modal.querySelectorAll('[data-inv]').forEach(b => b.onclick = () => { this.sel.invSel = Number(b.dataset.inv); Audio2.sfx('ui'); this.render(); });
    this.modal.querySelectorAll('[data-unequip]').forEach(b => b.onclick = () => { Inv.unequip(b.dataset.unequip); Audio2.sfx('ui'); this.render(); });
    const eq = document.getElementById('doEquip');
    if (eq) eq.onclick = () => { Inv.equip(this.sel.invSel); Audio2.sfx('ok'); this.msg('Peralatan dipakai.', true); this.render(); };
    const dr = document.getElementById('doDrink');
    if (dr) dr.onclick = () => { Game.usePotion(); this.render(); };
    const sl = document.getElementById('doSell');
    if (sl) sl.onclick = () => {
      const inst = Inv.byUid(this.sel.invSel);
      if (Object.values(Game.player.equip).some(e => e && e.uid === inst.uid)) { this.msg('Lepas dulu dari slot sebelum dijual.', false); return; }
      const v = Market.quickSell(inst, 1);
      Audio2.sfx('coin'); this.msg(`Terjual ${fmt(v)} G.`, true);
      if (!Inv.byUid(this.sel.invSel)) this.sel.invSel = null;
      this.render();
    };
  },

  /* ---------------- Auction House ---------------- */
  view_auction() {
    const f = this.sel.ah;
    let ls = Market.listings.slice();
    if (f.q) ls = ls.filter(l => ITEMS[l.tid].name.toLowerCase().includes(f.q.toLowerCase()));
    if (f.type !== 'all') ls = ls.filter(l => {
      const t = ITEMS[l.tid].type;
      return f.type === 'gear' ? !!SLOTS[t] : f.type === t;
    });
    if (f.rarity !== 'all') ls = ls.filter(l => (ITEMS[l.tid].rarity || 'common') === f.rarity);
    ls.sort((a, b) => f.sort === 'price' ? a.price - b.price : f.sort === 'priceD' ? b.price - a.price
      : f.sort === 'name' ? ITEMS[a.tid].name.localeCompare(ITEMS[b.tid].name)
      : itemPower(b.inst) - itemPower(a.inst));
    const chartTid = f.chart;
    const trend = Market.trend(chartTid);
    return `
    <div class="cols auction">
      <section class="ah-left">
        <div class="tabs">
          <button class="tab ${f.tab === 'buy' ? 'on' : ''}" data-ahtab="buy">BELI (${Market.listings.length})</button>
          <button class="tab ${f.tab === 'sell' ? 'on' : ''}" data-ahtab="sell">JUAL / TITIP</button>
          <button class="tab ${f.tab === 'mine' ? 'on' : ''}" data-ahtab="mine">TITIPANKU (${Market.consigned.length})</button>
        </div>
        ${f.tab === 'buy' ? `
        <div class="filters">
          <input id="ahq" placeholder="Cari nama barang…" value="${f.q}">
          <select id="ahtype">
            ${[['all', 'Semua jenis'], ['gear', 'Peralatan'], ['mat', 'Bahan'], ['gem', 'Permata'], ['potion', 'Konsumsi']]
              .map(([v, n]) => `<option value="${v}" ${f.type === v ? 'selected' : ''}>${n}</option>`).join('')}
          </select>
          <select id="ahrar">
            ${[['all', 'Semua mutu']].concat(Object.keys(RARITY).map(k => [k, RARITY[k].name]))
              .map(([v, n]) => `<option value="${v}" ${f.rarity === v ? 'selected' : ''}>${n}</option>`).join('')}
          </select>
          <select id="ahsort">
            ${[['value', 'Daya tertinggi'], ['price', 'Harga termurah'], ['priceD', 'Harga termahal'], ['name', 'Nama A-Z']]
              .map(([v, n]) => `<option value="${v}" ${f.sort === v ? 'selected' : ''}>${n}</option>`).join('')}
          </select>
        </div>
        <div class="table">
          <div class="tr th"><span>Barang</span><span>Penjual</span><span>Pasar</span><span>Harga</span><span></span></div>
          ${ls.length ? ls.map(l => {
            const base = ITEMS[l.tid].price * (l.qty || 1);
            const dev = Math.round((l.price / Math.max(1, itemValue(l.inst) * (Market.price[l.tid] || 1)) - 1) * 100);
            void base;
            return `<div class="tr">
              <span class="cell-item">${this.icon(ITEMS[l.tid], 22)}
                <span><b style="color:${itemColor(l.inst)}">${itemName(l.inst)}${l.qty > 1 ? ' x' + l.qty : ''}</b>
                <small>${isGear(l.inst) ? Object.entries(itemStats(l.inst)).map(([k, v]) => `${STAT_LABEL[k].slice(0, 4)} +${Math.round(v)}`).join(' · ') : (ITEMS[l.tid].desc || '')}</small></span></span>
              <span class="muted">${l.seller}</span>
              <span class="${(Market.price[l.tid] || 1) > 1 ? 'up' : 'down'}">${Math.round((Market.price[l.tid] || 1) * 100)}%</span>
              <span class="price">${fmt(l.price)} G<small class="${dev > 0 ? 'bad' : 'good'}">${dev > 0 ? '+' : ''}${dev}%</small></span>
              <span><button class="btn tiny ${Game.player.gold >= l.price ? 'primary' : ''}" data-buy="${l.id}">BELI</button>
                    <button class="btn tiny ghost" data-chart="${l.tid}">GRAFIK</button></span>
            </div>`;
          }).join('') : '<p class="empty">Tidak ada barang yang cocok dengan filter.</p>'}
        </div>` : f.tab === 'sell' ? `
        <p class="hint">Jual cepat (85% harga pasar, langsung) atau titip lelang (harga penuh, pajak 5%, terjual seiring waktu).</p>
        <div class="table">
          <div class="tr th"><span>Barang</span><span>Nilai pasar</span><span>Aksi</span></div>
          ${Game.player.inv.length ? Game.player.inv.map(i => `
            <div class="tr">
              <span class="cell-item">${this.icon(tpl(i), 22)}<span><b style="color:${itemColor(i)}">${itemName(i)}${i.qty > 1 ? ' x' + i.qty : ''}</b>
              <small>${isGear(i) ? 'Daya ' + fmt(itemPower(i)) : (tpl(i).desc || '')}</small></span></span>
              <span class="price">${fmt(Market.suggested(i, 1))} G</span>
              <span><button class="btn tiny" data-qsell="${i.uid}">JUAL CEPAT</button>
                    <button class="btn tiny primary" data-consign="${i.uid}">TITIP</button></span>
            </div>`).join('') : '<p class="empty">Tas kosong.</p>'}
        </div>` : `
        <div class="table">
          <div class="tr th"><span>Barang</span><span>Harga pasang</span><span>Status</span><span></span></div>
          ${Market.consigned.length ? Market.consigned.map(c => `
            <div class="tr"><span class="cell-item">${this.icon(ITEMS[c.tid], 22)}<b style="color:${itemColor(c.inst)}">${itemName(c.inst)}${c.qty > 1 ? ' x' + c.qty : ''}</b></span>
            <span class="price">${fmt(c.price)} G</span>
            <span class="muted">${c.priceRatio > 1.1 ? 'kemahalan — lambat' : c.priceRatio < 0.9 ? 'murah — cepat laku' : 'wajar'}</span>
            <span><button class="btn tiny" data-cancel="${c.id}">TARIK</button></span></div>`).join('')
            : '<p class="empty">Belum ada barang yang kau titipkan.</p>'}
        </div>`}
      </section>
      <aside class="ah-right">
        <h3>Indeks Pasar</h3>
        <div class="chart-head">
          <span>${ITEMS[chartTid].name}</span>
          <b class="${trend >= 0 ? 'up' : 'down'}">${trend >= 0 ? '▲' : '▼'} ${Math.abs(trend * 100).toFixed(1)}%</b>
        </div>
        <canvas id="ahChart" width="300" height="120"></canvas>
        <div class="chip-row">
          ${['m_stone', 'm_stone_hi', 'm_protect', 'm_enchant', 'm_essence', 'g_ruby', 'p_potion'].map(id =>
            `<button class="chip ${chartTid === id ? 'on' : ''}" data-chart="${id}">${ITEMS[id].name}</button>`).join('')}
        </div>
        <h3>Kabar Pasar</h3>
        <ul class="news">${Market.news.map(n => `<li>${n}</li>`).join('')}</ul>
        <p class="hint">Harga bergerak tiap beberapa detik: kelangkaan menaikkan, banjir pasokan menurunkan. Beli murah, tempa, jual mahal.</p>
      </aside>
    </div>`;
  },
  wire_auction() {
    const f = this.sel.ah;
    this.modal.querySelectorAll('[data-ahtab]').forEach(b => b.onclick = () => { f.tab = b.dataset.ahtab; this.render(); });
    const q = document.getElementById('ahq');
    if (q) q.oninput = () => { f.q = q.value; const p = q.selectionStart; this.render(); const n = document.getElementById('ahq'); if (n) { n.focus(); n.setSelectionRange(p, p); } };
    ['ahtype:type', 'ahrar:rarity', 'ahsort:sort'].forEach(pair => {
      const [id, key] = pair.split(':');
      const el = document.getElementById(id);
      if (el) el.onchange = () => { f[key] = el.value; this.render(); };
    });
    this.modal.querySelectorAll('[data-buy]').forEach(b => b.onclick = () => {
      const r = Market.buy(Number(b.dataset.buy));
      this.msg(r.msg, r.ok); Audio2.sfx(r.ok ? 'coin' : 'fail'); this.render();
    });
    this.modal.querySelectorAll('[data-chart]').forEach(b => b.onclick = () => { f.chart = b.dataset.chart; this.render(); });
    this.modal.querySelectorAll('[data-qsell]').forEach(b => b.onclick = () => {
      const inst = Inv.byUid(Number(b.dataset.qsell));
      const v = Market.quickSell(inst, 1);
      this.msg(`Jual cepat: ${fmt(v)} G masuk.`, true); Audio2.sfx('coin'); this.render();
    });
    this.modal.querySelectorAll('[data-consign]').forEach(b => b.onclick = () => {
      const inst = Inv.byUid(Number(b.dataset.consign));
      const price = Market.suggested(inst, 1);
      Market.consign(inst, price, 1);
      this.msg(`Dititipkan di lelang seharga ${fmt(price)} G.`, true); Audio2.sfx('ui'); this.render();
    });
    this.modal.querySelectorAll('[data-cancel]').forEach(b => b.onclick = () => { Market.cancelConsign(Number(b.dataset.cancel)); this.render(); });
    this.drawChart();
  },
  drawChart() {
    const cv = document.getElementById('ahChart'); if (!cv) return;
    const ctx = cv.getContext('2d');
    const h = Market.hist[this.sel.ah.chart] || [];
    ctx.clearRect(0, 0, cv.width, cv.height);
    ctx.fillStyle = '#15111f'; ctx.fillRect(0, 0, cv.width, cv.height);
    const min = Math.min(...h) * 0.98, max = Math.max(...h) * 1.02;
    ctx.strokeStyle = 'rgba(255,255,255,0.08)';
    for (let i = 0; i <= 4; i++) { const y = 10 + i * (cv.height - 24) / 4; ctx.beginPath(); ctx.moveTo(8, y); ctx.lineTo(cv.width - 8, y); ctx.stroke(); }
    const X = i => 8 + i * (cv.width - 16) / Math.max(1, h.length - 1);
    const Y = v => cv.height - 14 - (v - min) / Math.max(0.001, max - min) * (cv.height - 26);
    // area
    const grad = ctx.createLinearGradient(0, 0, 0, cv.height);
    const rising = h[h.length - 1] >= h[0];
    grad.addColorStop(0, rising ? 'rgba(111,224,138,0.4)' : 'rgba(224,82,79,0.4)');
    grad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.beginPath(); ctx.moveTo(X(0), cv.height - 14);
    h.forEach((v, i) => ctx.lineTo(X(i), Y(v)));
    ctx.lineTo(X(h.length - 1), cv.height - 14); ctx.closePath();
    ctx.fillStyle = grad; ctx.fill();
    ctx.beginPath(); h.forEach((v, i) => i ? ctx.lineTo(X(i), Y(v)) : ctx.moveTo(X(i), Y(v)));
    ctx.strokeStyle = rising ? '#6fe08a' : '#e0524f'; ctx.lineWidth = 2; ctx.stroke();
    // last point
    ctx.fillStyle = '#ffd24d'; ctx.fillRect(X(h.length - 1) - 2, Y(h[h.length - 1]) - 2, 4, 4);
    ctx.fillStyle = 'rgba(236,231,245,0.7)'; ctx.font = '10px "JetBrains Mono", monospace';
    ctx.fillText(`${Math.round(max * 100)}%`, 10, 12);
    ctx.fillText(`${Math.round(min * 100)}%`, 10, cv.height - 4);
    ctx.textAlign = 'right';
    ctx.fillText(`harga dasar ${fmt(ITEMS[this.sel.ah.chart].price)} G`, cv.width - 10, 12);
    ctx.textAlign = 'left';
  },

  /* ---------------- Shop ---------------- */
  view_shop() {
    return `<p class="hint">Harga tetap (125% harga dasar) — aman saat pasar sedang gila.</p>
    <div class="grid-shop">
      ${Shop.stock.map(tid => {
        const t = ITEMS[tid]; const price = Math.round(t.price * 1.25);
        return `<div class="shop-card" style="--rc:${RARITY[t.rarity || 'common'].color}">
          ${this.icon(t, 32)}
          <b style="color:${RARITY[t.rarity || 'common'].color}">${t.name}</b>
          <small>${t.desc || ''}</small>
          <div class="row">
            <span class="price">${fmt(price)} G</span>
            <button class="btn tiny primary" data-shop="${tid}" data-q="1">x1</button>
            <button class="btn tiny" data-shop="${tid}" data-q="5">x5</button>
          </div>
          <small class="muted">punya: ${Inv.count(tid)}</small>
        </div>`;
      }).join('')}
    </div>`;
  },
  wire_shop() {
    this.modal.querySelectorAll('[data-shop]').forEach(b => b.onclick = () => {
      const r = Shop.buy(b.dataset.shop, Number(b.dataset.q));
      this.msg(r.msg, r.ok); Audio2.sfx(r.ok ? 'coin' : 'fail'); this.render();
    });
  },

  /* ---------------- Enhancement ---------------- */
  view_enhance() {
    const uid = this.sel.enhance;
    const inst = uid ? Inv.byUid(uid) : null;
    const info = inst ? Enhance.info(inst) : null;
    const stNow = inst ? itemStats(inst) : null;
    let stNext = null;
    if (inst && info) {
      const clone = JSON.parse(JSON.stringify(inst)); clone.plus++;
      stNext = itemStats(clone);
    }
    const prot = this.sel.protect;
    return `
    <div class="cols two">
      <section>
        <h3>1 · Pilih peralatan</h3>
        ${this.gearPicker(uid, 'enh')}
        <h3>Tabel Peluang Tempaan</h3>
        <div class="table small">
          <div class="tr th"><span>Dari</span><span>Sukses</span><span>Turun</span><span>Hancur</span><span>Bahan</span></div>
          ${ENHANCE.map((e, i) => `<div class="tr ${inst && inst.plus === i ? 'hl' : ''}">
            <span>+${i} → +${i + 1}</span><span class="good">${Math.round(e.rate * 100)}%</span>
            <span class="warn">${Math.round(e.down * 100)}%</span><span class="bad">${Math.round(e.brk * 100)}%</span>
            <span class="muted">${e.qty}x ${ITEMS[e.stone].name}</span></div>`).join('')}
        </div>
      </section>
      <section>
        <h3>2 · Tempa</h3>
        ${inst ? `
          ${this.instCard(inst, {})}
          ${info ? `
          <div class="compare">
            <div><h4>Sekarang +${inst.plus}</h4>${Object.keys(stNow).map(k => `<span>${statLine(k, stNow[k])}</span>`).join('')}</div>
            <div class="arrow">→</div>
            <div><h4 class="good">Jadi +${info.next}</h4>${Object.keys(stNext).map(k => `<span class="good">${statLine(k, stNext[k])}</span>`).join('')}</div>
          </div>
          <div class="cost">
            <div><span>Peluang sukses</span><b class="good">${Math.round(info.rate * 100)}%</b></div>
            <div><span>Turun level</span><b class="warn">${Math.round(info.down * 100)}%</b></div>
            <div><span>Hancur</span><b class="bad">${prot ? '0% (dilindungi)' : Math.round(info.brk * 100) + '%'}</b></div>
            <div><span>Biaya</span><b>${fmt(info.gold)} G</b></div>
            <div><span>Bahan</span><b class="${Inv.count(info.stone) >= info.qty ? 'good' : 'bad'}">${Inv.count(info.stone)}/${info.qty} ${ITEMS[info.stone].name}</b></div>
          </div>
          <label class="check"><input type="checkbox" id="useProt" ${prot ? 'checked' : ''} ${Inv.count('m_protect') ? '' : 'disabled'}>
            Pakai Gulungan Perlindungan (punya ${Inv.count('m_protect')}) — item tidak hancur & tidak turun level saat gagal</label>
          <div class="row">
            <button class="btn primary big" id="doEnhance">TEMPA (+${info.next})</button>
            <button class="btn" id="doEnhance10">TEMPA SAMPAI GAGAL</button>
          </div>` : `<p class="hint good">Sudah +10 — tempaan maksimum tercapai.</p>`}
          <div class="log" id="enhLog">${(this.enhLog || []).map(l => `<div style="color:${l.c}">${l.t}</div>`).join('')}</div>
        ` : `<p class="hint">Pilih peralatan di kiri untuk mulai menempa. Tempaan menaikkan seluruh status dasar item.</p>`}
      </section>
    </div>`;
  },
  wire_enhance() {
    this.wirePicker('enh', uid => { this.sel.enhance = uid; });
    const cb = document.getElementById('useProt');
    if (cb) cb.onchange = () => { this.sel.protect = cb.checked; this.render(); };
    const run = (repeat) => {
      let guard = 0;
      const once = () => {
        const r = Enhance.attempt(this.sel.enhance, this.sel.protect);
        if (!r.ok) { this.msg(r.msg, false); Audio2.sfx('fail'); return false; }
        this.enhLog = this.enhLog || [];
        const color = r.result === 'up' ? '#6fe08a' : r.result === 'break' ? '#ff6b6b' : r.result === 'down' ? '#ffb02e' : '#cbbcf0';
        this.enhLog.unshift({ t: r.msg, c: color });
        if (this.enhLog.length > 8) this.enhLog.pop();
        this.msg(r.msg, r.result === 'up');
        Audio2.sfx(r.result === 'up' ? 'ok' : r.result === 'break' ? 'break' : 'fail');
        if (r.result === 'break') { this.sel.enhance = null; return false; }
        if (r.result === 'up') { Game.floater(Game.player.x, Game.player.y - 34, '+' + r.inst.plus + '!', '#ffd24d', true); }
        return r.result === 'up';
      };
      if (!repeat) once();
      else { while (once() && guard++ < 30) { /* keep going while succeeding */ } }
      this.render();
    };
    const b1 = document.getElementById('doEnhance'); if (b1) b1.onclick = () => run(false);
    const b2 = document.getElementById('doEnhance10'); if (b2) b2.onclick = () => run(true);
  },

  /* ---------------- Socketing ---------------- */
  view_socket() {
    const uid = this.sel.socket;
    const inst = uid ? Inv.byUid(uid) : null;
    const gems = Object.keys(GEMS).filter(g => Inv.count(g) > 0);
    return `
    <div class="cols two">
      <section>
        <h3>1 · Pilih peralatan</h3>
        ${this.gearPicker(uid, 'sock')}
        <h3>Permata di tas</h3>
        ${gems.length ? `<div class="gem-list">${gems.map(g => `
          <div class="gem-row" style="--c:${GEMS[g].color}">
            ${this.icon(ITEMS[g], 24)}
            <span><b style="color:${GEMS[g].color}">${GEMS[g].name}</b><small>${GEMS[g].desc}</small></span>
            <span class="muted">x${Inv.count(g)}</span>
          </div>`).join('')}</div>`
          : '<p class="empty">Belum punya permata. Beli di Balai Lelang / Toko, atau jatuh dari monster.</p>'}
      </section>
      <section>
        <h3>2 · Pasang permata</h3>
        ${inst ? `
          ${this.instCard(inst, {})}
          <div class="socket-board">
            ${inst.sockets.length ? inst.sockets.map((g, i) => `
              <div class="sock-slot ${g ? 'filled' : ''}" style="--c:${g ? GEMS[g].color : 'transparent'}">
                <div class="ss-title">Slot ${i + 1}</div>
                ${g ? `<div class="ss-gem">${this.icon(ITEMS[g], 24)}<b style="color:${GEMS[g].color}">${GEMS[g].name}</b><small>${GEMS[g].desc}</small></div>
                  <div class="row"><button class="btn tiny" data-pull="${i}" data-keep="1">LEPAS UTUH (450 G)</button>
                  <button class="btn tiny ghost" data-pull="${i}" data-keep="0">CABUT PAKSA (80 G)</button></div>`
                : `<div class="ss-empty">kosong</div>
                   <select data-slot="${i}" class="gemsel">
                     <option value="">— pilih permata —</option>
                     ${gems.map(g => `<option value="${g}">${GEMS[g].name} — ${GEMS[g].desc}</option>`).join('')}
                   </select>
                   <button class="btn tiny primary" data-set="${i}">PASANG (${fmt(60 + (tpl(inst).tier || 1) * 40)} G)</button>`}
              </div>`).join('') : '<p class="hint">Item ini tidak punya slot. Lubangi slot baru di bawah.</p>'}
          </div>
          <div class="row">
            <button class="btn" id="doDrill">LUBANGI SLOT BARU — ${fmt(800 + inst.sockets.length * 900)} G + 2 Batu Tempa Agung (70% sukses)</button>
          </div>
        ` : '<p class="hint">Pilih peralatan untuk melihat slot permatanya.</p>'}
      </section>
    </div>`;
  },
  wire_socket() {
    this.wirePicker('sock', uid => { this.sel.socket = uid; });
    this.modal.querySelectorAll('[data-set]').forEach(b => b.onclick = () => {
      const i = Number(b.dataset.set);
      const sel = this.modal.querySelector(`select[data-slot="${i}"]`);
      if (!sel.value) { this.msg('Pilih permata dulu.', false); return; }
      const r = Socket.set(this.sel.socket, i, sel.value);
      this.msg(r.msg, r.ok); Audio2.sfx(r.ok ? 'ok' : 'fail'); this.render();
    });
    this.modal.querySelectorAll('[data-pull]').forEach(b => b.onclick = () => {
      const r = Socket.pull(this.sel.socket, Number(b.dataset.pull), b.dataset.keep === '1');
      this.msg(r.msg, r.ok); Audio2.sfx(r.ok ? 'ui' : 'fail'); this.render();
    });
    const d = document.getElementById('doDrill');
    if (d) d.onclick = () => { const r = Socket.drill(this.sel.socket); this.msg(r.msg, r.ok); Audio2.sfx(r.ok ? 'ok' : 'fail'); this.render(); };
  },

  /* ---------------- Enchantment ---------------- */
  view_enchant() {
    const uid = this.sel.enchant;
    const inst = uid ? Inv.byUid(uid) : null;
    const le = this.sel.lastEnchant;
    const cost = inst ? 150 + (tpl(inst).tier || 1) * 90 : 0;
    return `
    <div class="cols two">
      <section>
        <h3>1 · Pilih peralatan</h3>
        ${this.gearPicker(uid, 'ench')}
        <h3>Kemungkinan Sihir</h3>
        <div class="table small">
          <div class="tr th"><span>Sihir</span><span>Status</span><span>Rentang</span><span>Bobot</span></div>
          ${ENCHANTS.map(e => `<div class="tr"><span>${e.name}</span><span class="muted">${STAT_LABEL[e.stat]}</span>
            <span>+${e.rolls[0]}–${e.rolls[1]}${STAT_SUFFIX[e.stat] || ''}</span><span class="muted">${e.w}</span></div>`).join('')}
        </div>
        <div class="grades">${ENCHANT_GRADE.map(g => `<span style="color:${g.color}">Tingkat ${g.name} — ${Math.round((g.t[1] - g.t[0]) * 100)}%</span>`).join('')}</div>
      </section>
      <section>
        <h3>2 · Rapal sihir</h3>
        ${inst ? `
          ${this.instCard(inst, {})}
          <div class="cost">
            <div><span>Biaya</span><b>${fmt(cost)} G</b></div>
            <div><span>Gulungan Sihir</span><b class="${Inv.count('m_enchant') ? 'good' : 'bad'}">${Inv.count('m_enchant')}</b></div>
            <div><span>Sihir sekarang</span><b style="color:${inst.enchant ? inst.enchant.color : '#8f89a8'}">${inst.enchant ? `${inst.enchant.name} ${inst.enchant.grade} (+${inst.enchant.val}${STAT_SUFFIX[inst.enchant.stat] || ''})` : 'belum ada'}</b></div>
          </div>
          <p class="hint">Merapal ulang menimpa sihir lama dengan hasil acak. Kalau hasil baru lebih buruk, kau masih bisa memulihkan yang lama sekali dengan 250 G.</p>
          <div class="row">
            <button class="btn primary big" id="doEnchant">RAPAL SIHIR</button>
            ${le && le.uid === inst.uid && le.prev ? `<button class="btn" id="doRevert">PULIHKAN SIHIR LAMA — 250 G</button>` : ''}
          </div>
          ${le && le.uid === inst.uid ? `
          <div class="compare">
            <div><h4>Lama</h4>${le.prev ? `<span style="color:${le.prev.color}">${le.prev.name} ${le.prev.grade} +${le.prev.val}${STAT_SUFFIX[le.prev.stat] || ''}</span>` : '<span class="muted">tidak ada</span>'}</div>
            <div class="arrow">→</div>
            <div><h4>Baru</h4><span style="color:${le.nw.color}">${le.nw.name} ${le.nw.grade} +${le.nw.val}${STAT_SUFFIX[le.nw.stat] || ''}</span></div>
          </div>` : ''}
        ` : '<p class="hint">Pilih peralatan untuk merapal sihir pasif acak.</p>'}
      </section>
    </div>`;
  },
  wire_enchant() {
    this.wirePicker('ench', uid => { this.sel.enchant = uid; this.sel.lastEnchant = null; });
    const b = document.getElementById('doEnchant');
    if (b) b.onclick = () => {
      const r = Enchantment.apply(this.sel.enchant);
      if (!r.ok) { this.msg(r.msg, false); Audio2.sfx('fail'); return; }
      this.sel.lastEnchant = { uid: this.sel.enchant, prev: r.prev, nw: r.nw };
      this.msg(r.msg, true); Audio2.sfx(r.nw.gradeIdx >= 3 ? 'level' : 'ok'); this.render();
    };
    const rv = document.getElementById('doRevert');
    if (rv) rv.onclick = () => {
      if (Game.player.gold < 250) { this.msg('Gold tidak cukup.', false); return; }
      Game.player.gold -= 250;
      const inst = Inv.byUid(this.sel.enchant);
      inst.enchant = this.sel.lastEnchant.prev;
      this.sel.lastEnchant = null;
      Game.recalc(); this.msg('Sihir lama dipulihkan.', true); Audio2.sfx('ui'); this.render();
    };
  },

  /* ---------------- Inheritance ---------------- */
  view_inherit() {
    const s = this.sel.inherit;
    const src = s.src ? Inv.byUid(s.src) : null;
    const pv = (s.src && s.dst) ? Inherit.preview(s.src, s.dst) : null;
    return `
    <div class="cols three">
      <section>
        <h3>1 · Item lama (sumber)</h3>
        <p class="hint">Item ini akan lenyap setelah warisan berpindah.</p>
        ${this.gearPicker(s.src, 'isrc')}
      </section>
      <section>
        <h3>2 · Item baru (tujuan)</h3>
        <p class="hint">${src ? `Harus slot yang sama: <b>${SLOTS[tpl(src).type]}</b>` : 'Pilih sumber dulu.'}</p>
        ${src ? this.gearPicker(s.dst, 'idst', tpl(src).type) : ''}
      </section>
      <section>
        <h3>3 · Warisan</h3>
        ${pv && pv.ok ? `
          <div class="compare vertical">
            <div>${this.instCard(pv.src, {})}</div>
            <div class="arrow big">⇩</div>
            <div>${this.instCard(pv.dst, {})}</div>
          </div>
          <div class="cost">
            <div><span>Tempaan pindah</span><b class="good">+${pv.plus}${pv.loss ? ` (turun ${pv.loss} karena tempaan ekstrem)` : ''}</b></div>
            <div><span>Permata pindah</span><b>${pv.gems.length ? pv.gems.map(g => GEMS[g].name).join(', ') : 'tidak ada'}${pv.gemsLost ? ` · ${pv.gemsLost} hilang (slot tujuan kurang)` : ''}</b></div>
            <div><span>Sihir pindah</span><b>${pv.enchant ? `${pv.enchant.name} ${pv.enchant.grade}` : 'tidak ada'}</b></div>
            <div><span>Biaya</span><b>${fmt(pv.cost)} G</b></div>
            <div><span>Esensi Warisan</span><b class="${Inv.count('m_essence') >= pv.essence ? 'good' : 'bad'}">${Inv.count('m_essence')}/${pv.essence}</b></div>
          </div>
          <button class="btn primary big" id="doInherit">WARISKAN SEKARANG</button>
        ` : `<p class="hint">${pv ? pv.msg : 'Pilih item sumber dan tujuan untuk melihat pratinjau perpindahan tempaan, permata, dan sihir.'}</p>`}
      </section>
    </div>`;
  },
  wire_inherit() {
    this.wirePicker('isrc', uid => { this.sel.inherit.src = uid; if (this.sel.inherit.dst === uid) this.sel.inherit.dst = null; });
    this.wirePicker('idst', uid => { this.sel.inherit.dst = uid; });
    const b = document.getElementById('doInherit');
    if (b) b.onclick = () => {
      const r = Inherit.execute(this.sel.inherit.src, this.sel.inherit.dst);
      this.msg(r.msg, r.ok);
      Audio2.sfx(r.ok ? 'level' : 'fail');
      if (r.ok) { this.sel.inherit.src = null; }
      this.render();
    };
  },

  /* ---------------- Quest journal ---------------- */
  view_quest() {
    const q = Game.quest;
    return `<div class="journal">
      <article class="chap active">
        <h3>${STORY.title} <small>satu alur utuh · ±${STORY.est} menit · ${q.step}/${q.total()} tujuan</small></h3>
        <p class="intro">${STORY.opening}</p>
        <ol>${STORY.steps.map((st, i) => {
          const cls = q.finished || i < q.step ? 'done' : i === q.step ? 'now' : '';
          const show = i <= q.step || q.finished;
          return `<li class="${cls}">${show ? st.text : 'Belum terungkap'}
            ${cls === 'now' ? `<b>${q.progressText()}</b>` : cls === 'done' ? '✔' : ''}
            ${show && st.story ? `<span class="muted"> — ${st.story}</span>` : ''}
            ${show && st.reward ? `<span class="reward-inline">Hadiah: ${fmt(st.reward.gold || 0)} G${(st.reward.items || []).length ? ' · ' + st.reward.items.map(([t, n]) => `${ITEMS[t].name} x${n}`).join(', ') : ''}</span>` : ''}
          </li>`;
        }).join('')}</ol>
      </article>
    </div>`;
  },

  /* ---------------- Map ---------------- */
  view_map() {
    return `<div class="map-wrap"><canvas id="bigmap" width="620" height="620"></canvas>
      <div class="legend">
        <h3>Posisi</h3>
        <div class="lg" id="mapPos"></div>
        <h3>Penanda</h3>
        <div class="lg"><span class="sw" style="background:#ffffff"></span>Kamu</div>
        <div class="lg"><span class="sw" style="background:#ffd24d"></span>Tujuan kisah</div>
        <div class="lg"><span class="sw" style="background:#e8d9a8"></span>Kota Serambi</div>
        <div class="lg"><span class="sw" style="background:#ff6b6b"></span>Arena bos</div>
        <h3>Alam</h3>
        ${Object.keys(REALM_LABEL).map(r => `<div class="lg"><span class="sw" style="background:${r === 'nether' ? '#75322c' : r === 'end' ? '#ded6ae' : r === 'cave' ? '#3f6b45' : '#548a45'}"></span>${REALM_LABEL[r]}</div>`).join('')}
        <p class="hint">Dunia tidak punya tepi — peta ini memperlihatkan 512 tile di sekitarmu dan terus berubah saat kau menjelajah.</p>
      </div></div>`;
  },
  wire_map() {
    const cv = document.getElementById('bigmap'); if (!cv) return;
    const ctx = cv.getContext('2d');
    const P = Game.player;
    const span = 512;                          // tile tercakup
    const px = 4;                              // piksel per sampel
    const step = span / (cv.width / px);
    const ptx = Math.round(P.x / 16), pty = Math.round(P.y / 16);
    ctx.fillStyle = '#0e0b14'; ctx.fillRect(0, 0, cv.width, cv.height);
    for (let y = 0; y < cv.height; y += px) {
      for (let x = 0; x < cv.width; x += px) {
        const wtx = Math.round(ptx + (x / px - cv.width / px / 2) * step);
        const wty = Math.round(pty + (y / px - cv.height / px / 2) * step);
        const b = World.biomeAt(wtx, wty);
        ctx.fillStyle = World.inTown(wtx, wty, 0) ? '#e8d9a8' : (b.fluid ? b.water : b.ground[1]);
        ctx.fillRect(x, y, px, px);
      }
    }
    const taken = [];                          // cegah label bertumpuk di peta
    const plot = (wx, wy, col, size, label) => {
      const x = cv.width / 2 + (wx / 16 - ptx) / step * px;
      const y = cv.height / 2 + (wy / 16 - pty) / step * px;
      if (x < 0 || y < 0 || x > cv.width || y > cv.height) return;
      ctx.fillStyle = col; ctx.fillRect(x - size / 2, y - size / 2, size, size);
      if (!label) return;
      ctx.font = '600 11px "JetBrains Mono", monospace'; ctx.textAlign = 'center';
      const w = ctx.measureText(label).width;
      let ly = y - 8;
      for (let guard = 0; guard < 8; guard++) {
        const clash = taken.some(t => Math.abs(t.y - ly) < 12 && Math.abs(t.x - x) < (t.w + w) / 2 + 6);
        if (!clash) break;
        ly += (y > cv.height / 2 ? -13 : 13);  // geser menjauh sampai bebas
      }
      // jaga label tetap di dalam kanvas peta
      ly = Math.max(12, Math.min(cv.height - 4, ly));
      const lx = Math.max(w / 2 + 3, Math.min(cv.width - w / 2 - 3, x));
      taken.push({ x: lx, y: ly, w });
      ctx.fillStyle = 'rgba(12,9,18,0.9)';
      ctx.fillText(label, lx + 1, ly + 1);
      ctx.fillStyle = col; ctx.fillText(label, lx, ly);
    };
    plot(World.TOWN.cx * 16, World.TOWN.cy * 16, '#e8d9a8', 12, 'SERAMBI');
    for (const k in World.ARENAS) {
      const a = World.ARENAS[k];
      plot(a[0] * 16, a[1] * 16, '#ff6b6b', 9, ENEMIES[k] ? ENEMIES[k].name.split(',')[0].toUpperCase() : k.toUpperCase());
    }
    for (const k in World.LANDMARKS) {
      if (k === 'forest' || k === 'hot') continue;
      const m = World.LANDMARKS[k];
      plot(m[0] * 16, m[1] * 16, '#9ef7ff', 7, k.toUpperCase());
    }
    const tgt = Game.quest.objectiveTarget();
    if (tgt) plot(tgt[0], tgt[1], '#ffd24d', 10, 'TUJUAN');
    plot(P.x, P.y, '#ffffff', 10, 'KAMU');
    const pos = document.getElementById('mapPos');
    const b = World.biomeAtPx(P.x, P.y);
    if (pos) pos.innerHTML = `<span class="sw" style="background:${b.ground[1]}"></span>${b.name} · ${REALM_LABEL[b.realm]} · ${ptx}, ${pty} · ${World.loadedChunks} petak dimuat`;
  },

  /* ---------------- Pengaturan ---------------- */
  view_settings() {
    const S = Game.settings;
    const row = (label, desc, ctrl) => `<div class="set-row"><div><b>${label}</b><small>${desc}</small></div><div class="set-ctrl">${ctrl}</div></div>`;
    const seg = (name, opts, cur) => opts.map(([v, l]) => `<button class="btn small seg${String(v) === String(cur) ? ' active' : ''}" data-set="${name}" data-val="${v}">${l}</button>`).join('');
    return `<div class="settings">
      ${row('Batas FPS', 'Buka kunci frame rate. "Tanpa batas" mengikuti kecepatan layarmu.',
        seg('fpsCap', [[30, '30'], [60, '60'], [120, '120'], [0, 'Tanpa batas']], S.fpsCap))}
      ${row('DLSS 4 (Neural Upscaling)', 'Render internal diperkecil lalu diperbesar dengan penajaman — FPS naik, tepian sedikit lebih lembut. Ini implementasi upscaling di dalam game, bukan DLSS resmi NVIDIA (butuh GPU RTX + driver).',
        seg('dlss', Object.keys(DLSS_MODES).map(k => [k, DLSS_MODES[k].label.replace('DLSS 4 · ', '')]), S.dlss))}
      ${row('Penghitung FPS', 'Tampilkan FPS, resolusi internal, dan mode upscaling di layar.',
        seg('showFps', [[1, 'Tampil'], [0, 'Sembunyi']], S.showFps ? 1 : 0))}
      ${row('Ukuran piksel', 'Makin besar = sprite lebih besar, area pandang lebih sempit.',
        seg('pixelZoom', [[2, 'Kecil'], [3, 'Sedang'], [4, 'Besar']], S.pixelZoom))}
      ${row('Kendali sentuh (HP)', 'Joystick + tombol aksi. "Selalu" memunculkannya juga di desktop.',
        seg('touchControls', [['auto', 'Otomatis'], ['always', 'Selalu'], ['off', 'Mati']], S.touchControls))}
      ${row('Musik', 'Iringan prosedural yang berubah menurut bioma.', seg('music', [[1, 'Hidup'], [0, 'Mati']], S.music ? 1 : 0))}
      ${row('Efek suara', 'Serangan, tempaan, dan dentang lelang.', seg('sfx', [[1, 'Hidup'], [0, 'Mati']], S.sfx ? 1 : 0))}
      ${row('Layar penuh', 'Bingkai permainan memenuhi seluruh layar perangkat.', '<button class="btn small" id="setFull">AKTIFKAN</button>')}
      <p class="hint" id="setInfo"></p>
    </div>`;
  },
  wire_settings() {
    const S = Game.settings;
    const info = () => {
      const dm = DLSS_MODES[S.dlss];
      const el = document.getElementById('setInfo');
      if (el) el.textContent = `Resolusi internal sekarang ${G.VW}×${G.VH} · ${dm.label} · batas ${S.fpsCap || 'tanpa batas'} FPS · ${Game.fps} FPS terukur.`;
    };
    this.modal.querySelectorAll('[data-set]').forEach(b => b.onclick = () => {
      const k = b.dataset.set; let v = b.dataset.val;
      if (['fpsCap', 'pixelZoom'].includes(k)) v = parseInt(v, 10);
      if (['showFps', 'music', 'sfx'].includes(k)) v = v === '1';
      S[k] = v;
      if (k === 'music') { Audio2.musicOn = v; if (!v && Audio2.ctx) Audio2.step = 0; }
      if (k === 'sfx') Audio2.sfxOn = v;
      if (k === 'dlss' || k === 'pixelZoom') Game.applyResolution();
      if (k === 'touchControls') this.applyTouchMode();
      Audio2.sfx('ui');
      this.render();
      setTimeout(info, 60);
    });
    const f = document.getElementById('setFull');
    if (f) f.onclick = () => Game.toggleBigScreen();
    info();
  },

  view_help() {
    return `<div class="doc">
      <h3>Kendali</h3>
      <ul>
        <li><b>WASD / panah</b> atau <b>joystick di kiri bawah</b> — bergerak (joystick jalan di ponsel maupun desktop)</li>
        <li><b>SPASI / klik kiri</b> — serang (arah sesuai hadapmu)</li>
        <li><b>Q / R / C</b> — tiga slot skill aktif (atur isinya di panel Kemampuan)</li>
        <li><b>E</b> — bicara dengan NPC & membuka toko/balai</li>
        <li><b>F</b> — minum ramuan · <b>I</b> tas · <b>J</b> jurnal kisah · <b>M</b> peta</li>
        <li><b>K</b> kemampuan · <b>T</b> tempa bos · <b>B</b> Boss Clash · <b>N</b> bestiari · <b>ESC</b> jeda/tutup</li>
        <li>Di ponsel: joystick kiri, tombol SERANG, S1–S3 untuk skill, dan tombol <b>JEDA</b></li>
        <li><b>Simpan otomatis:</b> kemajuanmu ditulis tiap 15 detik dan saat kau menjeda atau berpindah tab — tekan LANJUTKAN di layar utama untuk meneruskan</li>
      </ul>
      <h3>Alur bermain</h3>
      <ol>
        <li>Tekan MAIN dan kisah langsung berjalan — satu alur utuh tanpa bab, ${''}16 tujuan berurutan sampai tamat.</li>
        <li><b>Musuh pasif:</b> mereka hanya mengejar dan menyerang setelah kau melukai mereka. Lari cukup jauh dan mereka tenang lagi.</li>
        <li>Monster menjatuhkan gold, bahan tempa, permata, dan gulungan.</li>
        <li>Naikkan status lewat empat sistem: <b>lelang</b>, <b>tempaan +10</b>, <b>permata & sihir</b>, dan <b>warisan status</b>.</li>
        <li>Peta tidak punya tepi: lewati batas lama dan petak baru langsung dibentuk, lengkap dengan bioma, pohon, dan musuhnya.</li>
        <li>Makin jauh dari kota, makin kuat musuhnya — juga makin besar hadiahnya.</li>
        <li>Tumbang berarti kehilangan 10% gold dan bangkit di Kota Serambi. Tidak ada game over permanen.</li>
      </ol>
      <h3>Tips bertahan</h3>
      <ul>
        <li>Tempa senjata dulu sampai +3/+4 — biayanya murah dan tanpa risiko hancur.</li>
        <li>Simpan Gulungan Perlindungan untuk +6 ke atas, di situlah item bisa lenyap.</li>
        <li>Jual bahan berlebih saat indeks pasar di atas 110%.</li>
      </ul>
    </div>`;
  },
  view_features() {
    return `<div class="doc">
      <h3>1 · Balai Lelang (pasar pemain)</h3>
      <p>Daftar jual-beli yang berputar terus, harga bergerak tiap beberapa detik mengikuti kelangkaan dan kabar pasar.
      Ada grafik fluktuasi harga per komoditas, filter jenis/mutu/urutan, pencarian nama, jual cepat 85%, dan titip lelang dengan pajak 5%.</p>
      <h3>2 · Penempaan +1 … +10</h3>
      <p>Setiap tingkat butuh Batu Tempa (atau Batu Tempa Agung di +7 ke atas) plus gold. Mulai +4 ada risiko turun level,
      mulai +6 item bisa hancur. Gulungan Perlindungan mencegah keduanya.</p>
      <h3>3 · Permata & Sihir</h3>
      <p>Soket: pasang Rubi, Safir, Topas, Zamrud, Oniks, Garnet untuk kritis, serap darah, kecepatan, HP, pertahanan, atau serangan.
      Bisa melubangi slot tambahan (70% sukses). Sihir: gulungan memberi efek pasif acak dengan tingkat I sampai V.</p>
      <h3>4 · Pewarisan status</h3>
      <p>Dapat senjata tier lebih tinggi? Pindahkan tingkat tempaan, permata, dan sihir dari item lama ke item baru dengan
      Esensi Warisan — tanpa mengulang tempaan dari +0. Item lama lenyap sebagai tumbal.</p>
      <h3>Dunia tanpa batas & bioma</h3>
      <p>Dunia dibentuk prosedural per petak: begitu kau melewati batas yang sudah dibuat, petak baru langsung dirender di depanmu —
      tanpa loading, tanpa dinding peta. Bioma dipilih dari noise suhu, kelembapan, dan kontinental.</p>
      ${BIOME_GROUPS.map(g => `<p><b>${g.label}:</b> ${g.ids.map(id => BIOMES[id].name).join(', ')}.</p>`).join('')}
      <h3>Kisah & pengaturan</h3>
      <p>Satu alur kisah utuh (${STORY.steps.length} tujuan, ±${STORY.est} menit) tanpa bab — tekan MAIN dan langsung bermain.
      Menu pengaturan di layar utama mengatur batas FPS (30/60/120/tanpa batas), upscaling DLSS 4 dalam game, penghitung FPS,
      ukuran piksel, dan kendali sentuh. Sebelum layar utama ada layar muat lalu layar pembuka WAPPY GAMES, dan kemajuanmu tersimpan otomatis sehingga bisa dilanjutkan kapan saja.</p>
    </div>`;
  },

  /* ---------------- ending ---------------- */
  showEnding() {
    Game.state = 'ended';
    const mm = Math.floor(Game.elapsed / 60), ss = Math.floor(Game.elapsed % 60);
    const s = Game.stats;
    this.modal.classList.remove('hidden');
    this.modal.innerHTML = `
      <div class="sheet ending">
        <header class="sheet-head"><h2>Kisah Selesai — Kabut Surut</h2></header>
        <div class="sheet-body">
          <p class="ending-text">${STORY.ending} Pasar dibuka kembali, pandai besi menyalakan tungku, dan nama
          petualang masuk ke lempeng batu di gerbang kota.</p>
          <div class="statbox big">
            <div><span>Waktu tamat</span><b>${String(mm).padStart(2, '0')}:${String(ss).padStart(2, '0')}</b></div>
            <div><span>Target cerita</span><b>${STORY.est}:00</b></div>
            <div><span>Level akhir</span><b>${Game.player.level}</b></div>
            <div><span>Daya tempur</span><b>${fmt(Game.player.power)}</b></div>
            <div><span>Monster tumbang</span><b>${s.kills}</b></div>
            <div><span>Bos dikalahkan</span><b>${s.bosses}</b></div>
            <div><span>Tempaan berhasil</span><b>${s.enhanceOk}/${s.enhanceTry}</b></div>
            <div><span>Permata dipasang</span><b>${s.socketed}</b></div>
            <div><span>Sihir dirapal</span><b>${s.enchanted}</b></div>
            <div><span>Warisan status</span><b>${s.inherited}</b></div>
            <div><span>Transaksi pasar</span><b>${s.bought} beli / ${s.sold} jual</b></div>
            <div><span>Kali tumbang</span><b>${s.deaths}</b></div>
          </div>
          <p class="hint">Dunia tetap terbuka dan tetap tak berbatas — terus berjalan ke Nether, The End, atau gua Kelam Dalam, atau mulai ulang dengan kelas lain.</p>
        </div>
        <footer class="sheet-foot">
          <button class="btn primary" id="endContinue">LANJUT JELAJAH</button>
          <button class="btn" id="endRestart">MULAI ULANG</button>
        </footer>
      </div>`;
    document.getElementById('endContinue').onclick = () => { this.modal.classList.add('hidden'); this.modal.innerHTML = ''; Game.state = 'play'; };
    document.getElementById('endRestart').onclick = () => { location.reload(); };
  },
};
