/**
 * Snake Escape — UI & Screen Flow Manager
 * Controls screen transitions, modals, World-based level select cards,
 * gameplay HUD updates, key inventory bar, and toast alerts.
 */
(function() {
  'use strict';

  const WORLD_NAMES = {
    1: 'Jungle Basics',
    2: 'Ancient Ruins',
    3: 'Mystic Jungle',
    4: 'Danger Zone',
    5: 'Snake Temple',
    6: 'Master Escape',
    7: 'Canopy Trials',
    8: 'Temple Machines',
    9: 'Primal Labyrinth',
    10: 'Grand Escape',
    11: 'Volcanic Roots',
    12: 'Eternal Canopy'
  };

  class UIManager {
    constructor() {
      this.currentScreen = null;
      this.activeModals = new Set();
      this.toastContainer = null;
    }

    init() {
      this.toastContainer = document.getElementById('toast-container');
    }

    /**
     * Smoothly transitions to specified screen
     */
    showScreen(screenId) {
      const screens = document.querySelectorAll('.screen');
      screens.forEach(s => {
        s.classList.remove('active');
      });

      this.hideAllModals();

      const target = document.getElementById(`screen-${screenId}`);
      if (target) {
        target.classList.add('active');
        this.currentScreen = screenId;
      } else {
        console.error(`[UIManager] Screen screen-${screenId} not found!`);
      }
    }

    /**
     * Opens a modal overlay with backdrop blur
     */
    showModal(modalId) {
      const modal = document.getElementById(modalId);
      if (modal) {
        modal.classList.add('active');
        this.activeModals.add(modalId);
      }
    }

    /**
     * Hides a modal overlay
     */
    hideModal(modalId) {
      const modal = document.getElementById(modalId);
      if (modal) {
        modal.classList.remove('active');
        this.activeModals.delete(modalId);
      }
    }

    hideAllModals() {
      this.activeModals.forEach(id => this.hideModal(id));
      this.activeModals.clear();
    }

    /**
     * Displays a temporary toast notification
     */
    showToast(message) {
      if (!this.toastContainer) return;

      const toast = document.createElement('div');
      toast.className = 'toast';
      toast.textContent = message;

      this.toastContainer.appendChild(toast);
      setTimeout(() => {
        if (toast.parentNode) {
          toast.parentNode.removeChild(toast);
        }
      }, 2500);
    }

    /**
     * Formats seconds into MM:SS
     */
    formatTime(seconds) {
      const mins = Math.floor(seconds / 60);
      const secs = seconds % 60;
      return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
    }

    /**
     * Updates gameplay HUD header, move count, timer, and inventory
     */
    updateHUD(levelId, snakesRemaining, moves = 0, parMoves = 15, timerSeconds = 0, worldNum = 1, keys = []) {
      const titleEl = document.getElementById('game-hud-level-num');
      if (titleEl) {
        if (levelId === 999) {
          titleEl.textContent = 'Daily Challenge';
        } else {
          titleEl.textContent = `Lvl ${levelId} • W${worldNum}`;
        }
      }

      const snakesEl = document.getElementById('game-hud-snakes-count');
      if (snakesEl) {
        snakesEl.textContent = `🐍 ${snakesRemaining}`;
      }

      const movesEl = document.getElementById('game-hud-moves-count');
      if (movesEl) {
        movesEl.textContent = `Moves: ${moves}/${parMoves}`;
      }

      const timerEl = document.getElementById('game-hud-timer-count');
      if (timerEl) {
        timerEl.textContent = `⏱️ ${this.formatTime(timerSeconds)}`;
      }

      // Keys inventory bar
      const keysContainer = document.getElementById('game-hud-keys-bar');
      if (keysContainer) {
        keysContainer.innerHTML = '';
        if (keys && keys.length > 0) {
          keys.forEach(k => {
            const keySpan = document.createElement('span');
            keySpan.className = `key-badge ${k.collected ? 'collected' : 'uncollected'}`;
            keySpan.style.color = k.color === 'gold' ? '#ffd700' : (k.color === 'blue' ? '#00f3ff' : '#39ff14');
            keySpan.textContent = k.collected ? `🔑 ${k.color}` : `🔒 ${k.color}`;
            keysContainer.appendChild(keySpan);
          });
        }
      }
    }

    updateHintBadge(count) {
      const badge = document.getElementById('hint-count-badge');
      if (badge) {
        badge.textContent = count;
      }
    }

    /**
     * Renders golden stars into a target row
     */
    renderStars(container, earnedCount, totalCount = 3) {
      if (!container) return;
      container.innerHTML = '';

      for (let i = 0; i < totalCount; i++) {
        const isFilled = i < earnedCount;
        const star = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        star.setAttribute('viewBox', '0 0 24 24');
        star.setAttribute('class', `star-icon ${isFilled ? 'star-burst' : 'empty'}`);
        star.style.animationDelay = `${i * 0.15}s`;
        star.innerHTML = '<path fill="currentColor" d="M12 17.27 18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/>';
        container.appendChild(star);
      }
    }

    /**
     * Renders Level Select Grid for the selected world
     */
    renderLevelGrid(worldNum, storage, progress, onSelectLevel) {
      const grid = document.getElementById('level-select-grid');
      if (!grid) return;
      grid.innerHTML = '';

      const allLevels = window.SnakeEscape.LEVELS || [];
      const filtered = allLevels.filter(l => l.world === Number(worldNum));

      filtered.forEach(lvl => {
        const card = document.createElement('button');
        card.className = 'level-card';
        card.setAttribute('aria-label', `Level ${lvl.id}: ${lvl.name}`);

        const isUnlocked = progress.isUnlocked(lvl.id);
        const stars = progress.getLevelStars(lvl.id);
        const isCurrent = (lvl.id === storage.data.currentLevel);

        if (!isUnlocked) {
          card.classList.add('locked');
          card.innerHTML = `
            <span class="lvl-num">${lvl.id}</span>
            <svg class="lock-icon" viewBox="0 0 24 24" fill="currentColor">
              <path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"/>
            </svg>
          `;
        } else {
          if (isCurrent) card.classList.add('current');
          let starHtml = '';
          for (let s = 0; s < 3; s++) {
            starHtml += `<svg class="${s < stars ? 'filled' : 'empty'}" viewBox="0 0 24 24" fill="currentColor"><path d="M12 17.27 18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>`;
          }

          card.innerHTML = `
            <span class="lvl-num">${lvl.id}</span>
            <div class="lvl-stars">${starHtml}</div>
          `;

          card.addEventListener('click', () => {
            if (onSelectLevel) onSelectLevel(lvl.id);
          });
        }

        grid.appendChild(card);
      });

      // Update progress stats in header bar
      const countEl = document.getElementById('level-select-progress-num');
      if (countEl) {
        countEl.textContent = `${progress.getCompletedCount()} / ${allLevels.length}`;
      }

      const starsEl = document.getElementById('level-select-stars-num');
      if (starsEl) {
        starsEl.textContent = `${progress.getTotalStars()}`;
      }
    }
  }

  window.SnakeEscape = window.SnakeEscape || {};
  window.SnakeEscape.ui = new UIManager();
  window.SnakeEscape.WORLD_NAMES = WORLD_NAMES;
})();
