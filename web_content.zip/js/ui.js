class UIManager {
  constructor(game) {
    this.game = game;
    this.joystick = {
      active: false,
      startX: 0,
      startY: 0,
      dx: 0,
      dy: 0,
      id: null
    };
    this.lookTouch = {
      active: false,
      lastX: 0,
      lastY: 0,
      id: null
    };
    this.buttons = {};
    this.setupControls();
    this.setupMenus();
  }

  setupMenus() {
    document.getElementById('btn-play').onclick = () => this.game.startGame();
    document.getElementById('btn-characters').onclick = () => this.showScreen('character-select');
    document.getElementById('btn-shop').onclick = () => this.showScreen('shop-screen');
    document.getElementById('btn-settings').onclick = () => this.showScreen('settings-screen');

    document.getElementById('btn-back-char').onclick = () => this.showScreen('main-menu');
    document.getElementById('btn-back-shop').onclick = () => this.showScreen('main-menu');
    document.getElementById('btn-back-settings').onclick = () => {
      this.applySettings();
      this.showScreen('main-menu');
    };

    document.getElementById('btn-restart-win').onclick = () => this.game.startGame();
    document.getElementById('btn-menu-win').onclick = () => this.game.returnToMenu();
    document.getElementById('btn-restart-lose').onclick = () => this.game.startGame();
    document.getElementById('btn-menu-lose').onclick = () => this.game.returnToMenu();

    // Characters
    const chars = [
      { name: 'Raven', color: '#2a6fdb' },
      { name: 'Shadow', color: '#1a1a2e' },
      { name: 'Blaze', color: '#e74c3c' },
      { name: 'Nova', color: '#9b59b6' }
    ];
    const grid = document.getElementById('char-grid');
    chars.forEach((c, i) => {
      const card = document.createElement('div');
      card.className = 'char-card' + (i === 0 ? ' selected' : '');
      card.innerHTML = `<div class="preview" style="background:${c.color}"></div><div class="name">${c.name}</div>`;
      card.onclick = () => {
        document.querySelectorAll('.char-card').forEach(el => el.classList.remove('selected'));
        card.classList.add('selected');
        this.game.selectedChar = i;
      };
      grid.appendChild(card);
    });

    // Sensitivity display
    const sens = document.getElementById('setting-sensitivity');
    sens.oninput = () => {
      document.getElementById('sens-value').textContent = parseFloat(sens.value).toFixed(1);
    };
  }

  applySettings() {
    window.gameSettings = {
      quality: document.getElementById('setting-quality').value,
      sensitivity: parseFloat(document.getElementById('setting-sensitivity').value),
      volume: parseFloat(document.getElementById('setting-volume').value),
      difficulty: document.getElementById('setting-difficulty').value
    };
    AudioManager.setVolume(window.gameSettings.volume);
    if (this.game.renderer) {
      this.game.applyQuality(window.gameSettings.quality);
    }
  }

  showScreen(id) {
    ['main-menu', 'character-select', 'settings-screen', 'shop-screen',
     'victory-screen', 'defeat-screen'].forEach(s => {
      document.getElementById(s).classList.add('hidden');
    });
    if (id) document.getElementById(id).classList.remove('hidden');
  }

  showHUD(show) {
    document.getElementById('game-hud').classList.toggle('hidden', !show);
  }

  setupControls() {
    const zone = document.getElementById('joystick-zone');
    const stick = document.getElementById('joystick-stick');
    const base = document.getElementById('joystick-base');

    const onStart = (e) => {
      e.preventDefault();
      const t = e.changedTouches ? e.changedTouches[0] : e;
      const rect = base.getBoundingClientRect();
      this.joystick.active = true;
      this.joystick.id = t.identifier;
      this.joystick.startX = rect.left + rect.width / 2;
      this.joystick.startY = rect.top + rect.height / 2;
      this.updateStick(t.clientX, t.clientY);
    };

    const onMove = (e) => {
      if (!this.joystick.active) return;
      e.preventDefault();
      const touches = e.changedTouches || [e];
      for (const t of touches) {
        if (t.identifier === this.joystick.id || !e.changedTouches) {
          this.updateStick(t.clientX, t.clientY);
        }
      }
    };

    const onEnd = (e) => {
      const touches = e.changedTouches || [e];
      for (const t of touches) {
        if (t.identifier === this.joystick.id || !e.changedTouches) {
          this.joystick.active = false;
          this.joystick.dx = 0;
          this.joystick.dy = 0;
          stick.style.transform = 'translate(-50%, -50%)';
          if (this.game.player) {
            this.game.player.moveInput.x = 0;
            this.game.player.moveInput.z = 0;
          }
        }
      }
    };

    zone.addEventListener('touchstart', onStart, { passive: false });
    zone.addEventListener('touchmove', onMove, { passive: false });
    zone.addEventListener('touchend', onEnd, { passive: false });
    zone.addEventListener('touchcancel', onEnd, { passive: false });

    // Look controls - right side of screen (except buttons)
    const hud = document.getElementById('game-hud');
    hud.addEventListener('touchstart', (e) => {
      for (const t of e.changedTouches) {
        if (t.clientX > window.innerWidth * 0.45 && !this.isOnButton(t)) {
          this.lookTouch.active = true;
          this.lookTouch.id = t.identifier;
          this.lookTouch.lastX = t.clientX;
          this.lookTouch.lastY = t.clientY;
        }
      }
    }, { passive: false });

    hud.addEventListener('touchmove', (e) => {
      if (!this.lookTouch.active) return;
      for (const t of e.changedTouches) {
        if (t.identifier === this.lookTouch.id) {
          const dx = t.clientX - this.lookTouch.lastX;
          const dy = t.clientY - this.lookTouch.lastY;
          this.lookTouch.lastX = t.clientX;
          this.lookTouch.lastY = t.clientY;
          if (this.game.player) {
            this.game.player.lookInput.x = dx;
            this.game.player.lookInput.y = dy;
          }
        }
      }
    }, { passive: false });

    hud.addEventListener('touchend', (e) => {
      for (const t of e.changedTouches) {
        if (t.identifier === this.lookTouch.id) {
          this.lookTouch.active = false;
          if (this.game.player) {
            this.game.player.lookInput.x = 0;
            this.game.player.lookInput.y = 0;
          }
        }
      }
    }, { passive: false });

    // Buttons
    this.bindButton('btn-shoot', 'shoot');
    this.bindButton('btn-aim', 'aim');
    this.bindButton('btn-jump', 'jump');
    this.bindButton('btn-crouch', 'crouch');
    this.bindButton('btn-reload', 'reload');
    this.bindButton('btn-switch', 'switch');
    this.bindButton('btn-interact', 'interact');
    this.bindButton('btn-sprint', 'sprint');
  }

  isOnButton(t) {
    const els = document.elementsFromPoint(t.clientX, t.clientY);
    return els.some(el => el.classList.contains('ctrl-btn') || el.id === 'joystick-zone' || el.id === 'joystick-base' || el.id === 'joystick-stick');
  }

  updateStick(x, y) {
    const max = 40;
    let dx = x - this.joystick.startX;
    let dy = y - this.joystick.startY;
    const len = Math.sqrt(dx * dx + dy * dy);
    if (len > max) {
      dx = (dx / len) * max;
      dy = (dy / len) * max;
    }
    this.joystick.dx = dx / max;
    this.joystick.dy = dy / max;

    const stick = document.getElementById('joystick-stick');
    stick.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;

    if (this.game.player) {
      this.game.player.moveInput.x = this.joystick.dx;
      this.game.player.moveInput.z = -this.joystick.dy;
    }
  }

  bindButton(id, action) {
    const btn = document.getElementById(id);
    if (!btn) return;

    const start = (e) => {
      e.preventDefault();
      e.stopPropagation();
      btn.classList.add('active');
      this.buttons[action] = true;
      this.handleAction(action, true);
    };
    const end = (e) => {
      e.preventDefault();
      e.stopPropagation();
      this.buttons[action] = false;
      this.handleAction(action, false);
      // Sprint is toggle - keep visual if still active
      if (action === 'sprint' && this.game.player && this.game.player.isSprinting) {
        btn.classList.add('active');
      } else if (action !== 'sprint') {
        btn.classList.remove('active');
      } else {
        btn.classList.remove('active');
      }
    };

    btn.addEventListener('touchstart', start, { passive: false });
    btn.addEventListener('touchend', end, { passive: false });
    btn.addEventListener('touchcancel', end, { passive: false });
    // Mouse support for desktop testing
    btn.addEventListener('mousedown', start);
    btn.addEventListener('mouseup', end);
    btn.addEventListener('mouseleave', end);
  }

  handleAction(action, pressed) {
    const p = this.game.player;
    if (!p) return;

    switch (action) {
      case 'jump':
        if (pressed) p.wantJump = true;
        break;
      case 'crouch':
        if (pressed) p.isCrouching = !p.isCrouching;
        break;
      case 'sprint':
        if (pressed) {
          p.isSprinting = !p.isSprinting;
          const btn = document.getElementById('btn-sprint');
          if (btn) btn.classList.toggle('active', p.isSprinting);
        }
        break;
      case 'aim':
        p.isAiming = pressed;
        break;
      case 'reload':
        if (pressed) p.startReload();
        break;
      case 'switch':
        if (pressed) p.switchWeapon();
        break;
      case 'interact':
        if (pressed) this.game.tryPickup();
        break;
      case 'shoot':
        // handled in game loop while held
        break;
    }
  }

  updateHUD() {
    const g = this.game;
    if (!g.player) return;

    document.getElementById('health-fill').style.width = g.player.health + '%';
    document.getElementById('health-text').textContent = Math.ceil(g.player.health);
    document.getElementById('armor-fill').style.width = g.player.armor + '%';
    document.getElementById('armor-text').textContent = Math.ceil(g.player.armor);

    document.getElementById('alive-count').textContent = g.aliveCount;
    document.getElementById('kill-count').textContent = g.player.kills;
    if (g.zone) document.getElementById('zone-timer').textContent = g.zone.getTimerText();

    const w = g.player.currentWeapon;
    if (w) {
      document.getElementById('current-weapon').textContent = w.reloading ? 'Recarregando...' : w.name;
      document.getElementById('ammo-count').textContent = `${w.ammo} / ${w.reserve}`;
    }

    // Minimap
    this.drawMinimap();
  }

  drawMinimap() {
    const canvas = document.getElementById('minimap');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const s = 120;
    ctx.clearRect(0, 0, s, s);

    // Background
    ctx.fillStyle = 'rgba(20,40,20,0.8)';
    ctx.beginPath();
    ctx.arc(60, 60, 58, 0, Math.PI * 2);
    ctx.fill();

    const scale = 0.55;
    const g = this.game;
    if (!g.player) return;

    const px = g.player.position.x;
    const pz = g.player.position.z;

    // Zone
    if (g.zone) {
      ctx.strokeStyle = '#00f0ff';
      ctx.lineWidth = 2;
      ctx.beginPath();
      const zr = g.zone.radius * scale;
      const zx = 60 + (g.zone.center.x - px) * scale;
      const zz = 60 + (g.zone.center.z - pz) * scale;
      ctx.arc(zx, zz, zr, 0, Math.PI * 2);
      ctx.stroke();
    }

    // Bots
    ctx.fillStyle = '#e74c3c';
    g.bots.forEach(b => {
      if (!b.alive) return;
      const x = 60 + (b.position.x - px) * scale;
      const z = 60 + (b.position.z - pz) * scale;
      if (x > 5 && x < 115 && z > 5 && z < 115) {
        ctx.beginPath();
        ctx.arc(x, z, 3, 0, Math.PI * 2);
        ctx.fill();
      }
    });

    // Player
    ctx.fillStyle = '#00f0ff';
    ctx.beginPath();
    ctx.arc(60, 60, 4, 0, Math.PI * 2);
    ctx.fill();

    // Direction
    ctx.strokeStyle = '#fff';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(60, 60);
    ctx.lineTo(60 - Math.sin(g.player.rotationY) * 12, 60 - Math.cos(g.player.rotationY) * 12);
    ctx.stroke();
  }

  showVictory(kills) {
    document.getElementById('final-kills').textContent = kills;
    this.showHUD(false);
    this.showScreen('victory-screen');
    AudioManager.win();
  }

  showDefeat(position, kills) {
    document.getElementById('final-position').textContent = '#' + position;
    document.getElementById('final-kills-d').textContent = kills;
    this.showHUD(false);
    this.showScreen('defeat-screen');
    AudioManager.lose();
  }
}
