(function () {
  'use strict';
  const P = (window.Pith = window.Pith || {});
  const U = P.util;
  const h = U.h;
  const UI = (P.ui = {});

  // ---------------------------------------------------------------- overlay stack
  // Every overlay (sheet, dialog, full-screen view, drawer) is a history entry so the
  // Android back button closes the top-most one instead of leaving the app.
  const stack = [];
  let depth = 0, ignore = false, syncTimer = null;

  function syncHistory() {
    clearTimeout(syncTimer);
    syncTimer = setTimeout(() => {
      const extra = depth - stack.length;
      if (extra > 0) {
        ignore = true;
        depth = stack.length;
        try { history.go(-extra); } catch (e) { ignore = false; }
        setTimeout(() => { ignore = false; }, 500);
      }
    }, 60);
  }
  window.addEventListener('popstate', () => {
    if (ignore) { ignore = false; return; }
    if (depth > 0) { depth--; const e = stack.pop(); if (e) e.dispose(); }
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && stack.length) stack[stack.length - 1].close();
  });

  UI.register = function (entry) {
    stack.push(entry);
    try { history.pushState({ pith: 1 }, ''); depth++; } catch (e) { /* no history API */ }
    const base = entry.close;
    entry.close = function () {
      const i = stack.indexOf(entry);
      if (i < 0) return;
      stack.splice(i, 1);
      syncHistory();
      entry.dispose();
    };
    return entry;
  };
  UI.hasOverlay = () => stack.length > 0;

  function mount(el, onDismiss) {
    document.getElementById('layer').append(el);
    requestAnimationFrame(() => requestAnimationFrame(() => el.classList.add('open')));
    let closed = false;
    const entry = {
      el,
      dispose() {
        if (closed) return;
        closed = true;
        el.classList.remove('open');
        setTimeout(() => el.remove(), 240);
        if (onDismiss) onDismiss();
      },
    };
    return UI.register(entry);
  }
  UI.mount = mount;

  // ---------------------------------------------------------------- dialogs
  UI.prompt = function (o) {
    return new Promise((resolve) => {
      let done = false;
      const finish = (v) => { if (done) return; done = true; entry.close(); resolve(v); };
      const input = o.multiline
        ? h('textarea', { class: 'input', rows: 5, placeholder: o.placeholder || '' })
        : h('input', { class: 'input', type: 'text', placeholder: o.placeholder || '', autocomplete: 'off' });
      input.value = o.value || '';
      if (!o.multiline) input.addEventListener('keydown', (e) => { if (e.key === 'Enter') finish(input.value.trim()); });
      const wrap = h('div', { class: 'modal-wrap', onclick: (e) => { if (e.target === wrap) finish(null); } },
        h('div', { class: 'modal', role: 'dialog', 'aria-modal': 'true' },
          h('h3', null, o.title),
          o.description ? h('p', { class: 'muted small' }, o.description) : null,
          input,
          h('div', { class: 'modal-actions' },
            h('button', { class: 'btn ghost', onclick: () => finish(null) }, 'Cancel'),
            h('button', { class: 'btn primary', onclick: () => finish(input.value.trim()) }, o.confirm || 'Save'))));
      const entry = mount(wrap, () => finish(null));
      setTimeout(() => { input.focus(); input.setSelectionRange && input.setSelectionRange(input.value.length, input.value.length); }, 120);
    });
  };

  UI.confirm = function (o) {
    return new Promise((resolve) => {
      let done = false;
      const finish = (v) => { if (done) return; done = true; entry.close(); resolve(v); };
      const wrap = h('div', { class: 'modal-wrap', onclick: (e) => { if (e.target === wrap) finish(false); } },
        h('div', { class: 'modal', role: 'alertdialog', 'aria-modal': 'true' },
          h('h3', null, o.title),
          o.message ? h('p', { class: 'muted' }, o.message) : null,
          h('div', { class: 'modal-actions' },
            h('button', { class: 'btn ghost', onclick: () => finish(false) }, 'Cancel'),
            h('button', { class: 'btn ' + (o.danger === false ? 'primary' : 'danger'), onclick: () => finish(true) }, o.confirm || 'Delete'))));
      const entry = mount(wrap, () => finish(false));
    });
  };

  // ---------------------------------------------------------------- sheets
  UI.sheet = function (o) {
    const wrap = h('div', { class: 'sheet-wrap', onclick: (e) => { if (e.target === wrap) entry.close(); } },
      h('div', { class: 'sheet', role: 'dialog', 'aria-modal': 'true' },
        h('div', { class: 'grabber' }),
        o.title ? h('h3', { class: 'sheet-title' }, o.title) : null,
        o.content));
    const entry = mount(wrap, o.onClose);
    return entry;
  };

  UI.actionSheet = function (title, items) {
    let entry;
    const list = h('div', { class: 'sheet-list' }, items.filter(Boolean).map((it) => h('button', {
      class: 'sheet-item' + (it.danger ? ' danger' : ''),
      onclick: () => { entry.close(); setTimeout(() => it.onClick && it.onClick(), 30); },
    }, it.icon ? U.icon(it.icon) : null, h('span', { class: 'grow' }, it.label), it.hint ? h('span', { class: 'muted small' }, it.hint) : null, it.checked ? U.icon('check') : null)));
    entry = UI.sheet({ title, content: list });
    return entry;
  };

  // Radio-style chooser with a label and hint per option.
  UI.choose = function (title, options, selected, onPick) {
    let entry;
    const list = h('div', { class: 'sheet-list' }, options.map((o) => h('button', {
      class: 'sheet-item two-line',
      onclick: () => { entry.close(); onPick(o.id); },
    }, h('span', { class: 'grow' }, h('span', { class: 'line1' }, o.label), h('span', { class: 'line2' }, o.hint || '')), o.id === selected ? U.icon('check') : null)));
    entry = UI.sheet({ title, content: list });
  };

  UI.textSheet = function (o) {
    let entry;
    const area = h('textarea', { class: 'input', rows: 7, placeholder: o.placeholder || '' });
    area.value = o.value || '';
    const body = h('div', { class: 'sheet-pad' },
      o.description ? h('p', { class: 'muted small' }, o.description) : null,
      area,
      h('div', { class: 'modal-actions' }, h('button', { class: 'btn primary', onclick: () => { o.onSave(area.value.trim()); entry.close(); } }, 'Save')));
    entry = UI.sheet({ title: o.title, content: body });
    setTimeout(() => area.focus(), 150);
  };

  // ---------------------------------------------------------------- full-screen views
  UI.view = function (o) {
    const body = h('div', { class: 'view-body' });
    const title = h('h2', { class: 'view-title' }, o.title);
    const actions = h('div', { class: 'view-actions' });
    const el = h('section', { class: 'view', role: 'dialog' },
      h('header', { class: 'view-head' },
        h('button', { class: 'icon-btn', 'aria-label': 'Back', onclick: () => ctl.back() }, U.icon('chevron-left')),
        title, actions),
      body);
    const ctl = {
      el, body, actions,
      setTitle: (t) => { title.textContent = t; },
      close: () => entry.close(),
      back: () => (o.onBack ? o.onBack(ctl) : entry.close()),
    };
    const entry = mount(el, o.onClose);
    o.build(body, ctl);
    return ctl;
  };
})();
