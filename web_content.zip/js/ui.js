/* ui.js — start screen, top bar, province/country panel, menu (save/load), toasts. */
(function (G) {
  'use strict';
  const $ = id => document.getElementById(id);
  const fmt = n => Math.round(n).toLocaleString('en-US');
  const sgn = n => (n >= 0 ? '+' : '') + n.toFixed(1);
  let panelTab = 'province', toastT = null;

  G.toast = function (msg) {
    const t = $('toast'); t.textContent = msg; t.classList.add('show');
    clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), 2200);
  };

  /* ---------- in-game confirm (window.confirm is blocked in many Android WebView wrappers) ---------- */
  G.confirmBox = function (msg, yesLabel, onYes) {
    const old = document.getElementById('confirm'); if (old) old.remove();
    const d = document.createElement('div'); d.id = 'confirm';
    d.innerHTML = '<div class="cbox"><p></p><div class="row"><button id="cf-no">Cancel</button><button id="cf-yes" class="danger"></button></div></div>';
    d.querySelector('p').textContent = msg; d.querySelector('#cf-yes').textContent = yesLabel || 'Confirm';
    document.getElementById('app').appendChild(d);
    d.querySelector('#cf-no').onclick = () => d.remove();
    d.querySelector('#cf-yes').onclick = () => { d.remove(); onYes && onYes(); };
  };

  /* ---------- modal ---------- */
  function openModal(html) { $('modal-box').innerHTML = html; $('modal').classList.remove('hidden'); }
  function closeModal() { $('modal').classList.add('hidden'); }
  G.closeModal = closeModal;

  /* ---------- start screen ---------- */
  let startMode = 'campaign';
  G.showStart = function (scId) {
    ['topbar','mapctl','sidebar','minimap','panel'].forEach(i => $(i).classList.add('hidden')); G.resizeMap && G.resizeMap();
    let pick = null;
    const sc = scId || G.scenarioId || 'empires';
    G.newGame(null, sc);
    const counts = {};
    G.provinces.forEach(p => { if (!p.sea) { const o = G.state.owners[p.id]; counts[o] = (counts[o] || 0) + 1; } });
    const list = Object.values(G.COUNTRIES).sort((a, b) => (b.pow || 0) - (a.pow || 0) || a.name.localeCompare(b.name));
    const cards = list.map(c => '<div class="card" data-id="' + c.id + '"><img src="' + G.flagURL(c.id) + '"><div><b>' + c.name + '</b><small>' + c.gov + '<br>' + (counts[c.id] || 0) + ' provinces · 👥 ' + fmt(c.manpower) + '</small></div></div>').join('');
    const hasSave = G.SAVE_SLOTS.some(s => G.slotInfo(s));
    const scs = Object.keys(G.SCENARIOS).map(k => '<button data-sc="' + k + '" class="' + (k === sc ? 'on' : '') + '">' + G.SCENARIOS[k].name + '</button>').join('');
    openModal('<div class="start"><div class="st-left"><div class="st-scroll"><h1>EMPIRES</h1><div class="tagline">WORLD AT WAR — Final Release</div>' +
      '<h3>Scenario</h3><div class="tabs" id="st-sc">' + scs + '</div><div class="dim" style="font-size:12px;margin:2px 0 4px">' + (G.scenario.blurb || '') + '</div>' +
      '<h3>Game mode</h3><div class="tabs" id="st-mode"><button data-m="campaign" class="' + (startMode === 'campaign' ? 'on' : '') + '">Campaign</button><button data-m="sandbox" class="' + (startMode === 'sandbox' ? 'on' : '') + '">Sandbox</button></div><div class="dim" style="font-size:12px;margin:2px 0 4px">' + (startMode === 'campaign' ? 'Win by dominating the map, by alliance, or finish top-ranked at the end date.' : 'No victory or defeat. Goals and events still happen.') + '</div></div>' +
      '<div class="row"><button class="primary" id="st-go" disabled>① Pick a nation →</button>' +
      '<button id="st-load"' + (hasSave ? '' : ' disabled') + '>Load Game</button><button id="st-help">How to play</button></div></div>' +
      '<div class="st-right"><h3>Choose your nation (' + list.length + ')</h3><div class="cards">' + cards + '</div></div></div>');
    document.querySelectorAll('#st-sc button').forEach(b => b.onclick = () => G.showStart(b.dataset.sc));
    document.querySelectorAll('#st-mode button').forEach(b => b.onclick = () => { startMode = b.dataset.m; G.showStart(sc); });
    document.querySelectorAll('.card').forEach(el => el.onclick = () => {
      pick = el.dataset.id;
      document.querySelectorAll('.card').forEach(x => x.classList.toggle('sel', x === el));
      $('st-go').disabled = false; $('st-go').textContent = '▶ Start as ' + G.COUNTRIES[pick].name;
    });
    $('st-go').onclick = () => { if (pick) G.beginGame(pick, sc, startMode); };
    $('st-load').onclick = () => G.showSlots('load', true);
    $('st-help').onclick = () => G.showHelp(true);
  };

  G.showHelp = function (fromStart) {
    openModal('<h3>How to play</h3><div class="help">' +
      '• <b>Pan</b>: drag with one finger (or mouse). <b>Zoom</b>: pinch (or mouse wheel / + − buttons).<br>' +
      '• <b>Tap a province</b> to inspect it; the <b>Country</b> tab shows its owner. Tap the sea to deselect.<br>' +
      '• <b>Time</b>: ▶ play/pause, − / + change speed. The game starts paused.<br>' +
      '• Treasury, manpower and resources grow from the provinces your nation owns.<br>' +
      '• 🗺 cycles map modes: Political, Terrain, Diplomacy, Naval, Economy. ⤢ fits the whole map.<br>• <b>Navy</b> (⚓): build ships in a coastal province with a Port and Shipyard, group them into fleets, sail between sea zones (tap the sea to select a zone), blockade enemy ports, and carry armies in Transports: load at a port, sail, then Land at a coast (⚔ if enemy-held). Armies have a ⛴ Sail button. Straits close to fleets of nations at war with the controller.<br>' +
      '• <b>Armies</b>: tap an army icon (flag banner) to select it; ➜ Move then tap a destination in your territory. ⚔ Army Command recruits units, shows the queue, armies and generals.<br>' +
      '• <b>AI</b>: other nations plan wars, build armies, gather forces before attacking, ally against strong neighbours and make peace. Menu → AI difficulty (Easy / Normal / Hard) sets how soon and how often they attack.<br>' +
      '• <b>Diplomacy (🤝)</b>: improve relations, sign non-aggression pacts, alliances, military access and trade agreements, answer offers in the Inbox, and negotiate peace terms. Allies are called to arms when a partner is attacked; breaking a pact costs reputation.<br>' +
      '• <b>War</b>: open a nation in the Country tab to ⚔ declare war or 🕊 propose a ceasefire. Armies can then march into enemy provinces; a battle starts when they meet defenders, and a province changes hands after your army holds it unopposed for several days. 🏰 Fortifications make provinces harder to take.<br>' +
      '• <b>Industry</b> (🏭): factories, equipment production, construction, tax policy and the resource market. Units need equipment from your factories; food, steel, oil and rubber shortages slow production and hurt morale.<br>' +
      '• ☰ Menu: save to 3 slots, load, autosave (every game month), new game.<br>' +
      '<br>• <b>Goals (🎯)</b>: three national goals at a time pay gold and manpower; the screen also shows your victory progress and the ranking. <b>Events</b> arrive every month or two with choices; the game pauses until you decide. In Campaign mode you win by dominating the map, by alliance, or by finishing top-ranked at the end date; Sandbox has no end.<br><br><i>Empires — World at War, final release.</i></div>' +
      '<div class="row"><button id="hp-back">' + (fromStart ? 'Back' : 'Close') + '</button></div>');
    $('hp-back').onclick = () => fromStart ? G.showStart() : closeModal();
  };

  /* ---------- game start ---------- */
  G.beginGame = function (id, scenario, mode) {
    closeModal();
    G.newGame(id, scenario || G.scenarioId, { mode: mode || 'campaign' });
    G.selected = G.COUNTRIES[id].capitalId;
    afterLoad(true);
  };
  function afterLoad(focus) {
    ['topbar','mapctl','sidebar','minimap'].forEach(i => $(i).classList.remove('hidden')); G.resizeMap && G.resizeMap();
    G.resizeMap && G.resizeMap();
    const pid = G.state.player;
    $('tb-flag').src = G.flagURL(pid); $('tb-name').textContent = G.COUNTRIES[pid].name;
    if (focus && G.selected != null) { G.fitView(); G.focusProvince(G.selected); }
    G.onSelect(G.selected);
    G.updateTopBar(); G.requestDraw();
    G.toast('Welcome, ruler of ' + G.COUNTRIES[pid].name);
    G.resumeEvents && G.resumeEvents();
  }
  G.afterLoad = afterLoad;

  /* ---------- top bar ---------- */
  G.updateTopBar = function () {
    const st = G.state; if (!st) return;
    const c = st.countries[st.player];
    $('tb-date').textContent = G.dateString();
    $('tb-gold').textContent = fmt(c.treasury); $('tb-gold-d').textContent = sgn(c.dIncome) + '/d';
    $('tb-man').textContent = fmt(c.manpower); $('tb-man-d').textContent = sgn(c.dManpower) + '/d';
    for (const r of G.RESOURCES) $('tb-' + r).textContent = fmt(c.res[r]);
    G.warBadge && G.warBadge();
    $('tb-food').parentElement.classList.toggle('warn', !!c.starving);
    $('tb-gold').parentElement.classList.toggle('warn', !!c.broke);
    $('btn-pause').textContent = st.paused ? '▶' : '⏸';
    $('speedlbl').textContent = G.SPEEDS[st.speedIdx] + '×';
  };

  /* ---------- panel ---------- */
  function cell(label, val) { return '<div class="cell"><span>' + label + '</span>' + val + '</div>'; }

  G.onSelect = function (id) {
    const panel = $('panel');
    if (G.selArmy != null) { G.showArmyPanel(); return; }
    if (G.selFleet != null) { G.showFleetPanel(); return; }
    if (id == null && G.selZone != null) { G.onZoneSelect(G.selZone); return; }
    if (id == null) { panel.classList.add('hidden'); return; }
    panel.classList.remove('hidden');
    renderPanel();
    requestAnimationFrame(() => G.ensureVisible(id));
  };

  function renderPanel() {
    const st = G.state, id = G.selected; if (id == null) return;
    const p = G.provinces[id], oid = st.owners[id], c = G.COUNTRIES[oid], cs = st.countries[oid];
    const mine = oid === st.player;
    let h = '<div class="ph"><img src="' + G.flagURL(oid) + '"><div><h2>' + (panelTab === 'province' ? p.name : c.name) +
      (p.capital && panelTab === 'province' ? '<span class="tag">CAPITAL</span>' : '') + '</h2><div class="sub">' +
      (panelTab === 'province' ? 'Province of ' + c.name + (mine ? ' (you)' : '') : c.gov) + '</div></div>' +
      '<button class="x" id="p-close">✕</button></div>' +
      '<div class="tabs"><button data-t="province" class="' + (panelTab === 'province' ? 'on' : '') + '">Province</button>' +
      '<button data-t="country" class="' + (panelTab === 'country' ? 'on' : '') + '">Country</button></div>';
    if (panelTab === 'province') {
      const T = G.TERRAIN[p.terrain];
      h += G.provinceWarHtml(id) + G.provinceIntelHtml(id) + G.provinceEconHtml(id) + '<div class="grid">' + cell('Terrain', T.name) + cell('Population', fmt(p.pop)) +
        cell('Income', '💰 ' + p.income + ' /day') + cell('Manpower', '👥 +' + p.manpower + '/mo') +
        cell('Infrastructure', '▮'.repeat(p.infra) + '▯'.repeat(5 - p.infra)) + cell('Fortification', p.fort ? 'Level ' + p.fort : 'None') +
        cell('Defense bonus', '×' + T.def.toFixed(1)) + cell('Movement cost', '×' + T.move.toFixed(1)) +
        cell('Steel / Coal', p.res.steel + ' / ' + p.res.coal) + cell('Oil / Food', p.res.oil + ' / ' + p.res.food) +
        cell('Coastal', (p.coastal || (p.seaZones && p.seaZones.length)) ? 'Yes' : 'No') + '</div>' + (G.provincePortHtml ? G.provincePortHtml(id) : '');
      h += '<div class="chips"><span style="font-size:12px;color:var(--dim);align-self:center">Neighbours:</span>' +
        p.adj.map(n => '<span class="chip" data-n="' + n + '">' + G.provinces[n].name + '</span>').join('') + '</div>';
    } else {
      const own = G.provinces.filter(q => !q.sea && st.owners[q.id] === oid);
      const iv = (v, f) => oid === st.player ? (f || fmt)(v) : G.intelVal(oid, v, f);
      h += G.countryWarHtml(oid) + '<div class="grid">' + cell('Capital', c.capital) + cell('Provinces', own.length) +
        cell('Treasury', iv(cs.treasury)) + cell('Income', iv(cs.dIncome, sgn) + '/day') +
        cell('Manpower', iv(cs.manpower)) + cell('Growth', iv(cs.dManpower, sgn) + '/day') +
        cell('Steel / Coal', iv(cs.res.steel) + ' / ' + iv(cs.res.coal)) + cell('Oil / Food', iv(cs.res.oil) + ' / ' + iv(cs.res.food)) + '</div>' +
        (oid !== st.player ? '<div class="eqline">🕵 Intel on ' + c.name + ': ' + Math.round(G.intelLevel(st.player, oid)) + '%' + (G.intelLevel(st.player, oid) < 50 ? ' — build a network (🕵) to see exact figures and armies' : '') + '</div>' : '') +
        '<div class="chips">' + own.map(q => '<span class="chip" data-n="' + q.id + '">' + q.name + '</span>').join('') + '</div>';
    }
    if (panelTab === 'province') h += G.provinceArmyHtml(id);
    $('panel-body').innerHTML = h;
    if (panelTab === 'province') { G.bindProvinceArmy(id); G.bindProvinceWar(id); G.bindProvinceEcon(id); G.bindProvinceIntel(id); G.bindProvincePort && G.bindProvincePort(id); } else G.bindCountryWar(oid);
    $('p-close').onclick = () => { G.selected = null; G.requestDraw(); $('panel').classList.add('hidden'); };
    document.querySelectorAll('#panel-body .tabs button').forEach(b => b.onclick = () => { panelTab = b.dataset.t; renderPanel(); });
    document.querySelectorAll('#panel-body .chip[data-n]').forEach(ch => ch.onclick = () => {
      G.selected = +ch.dataset.n; G.focusProvince(G.selected); renderPanel(); G.requestDraw();
    });
  }
  G.refreshPanel = function () {
    if (G.selArmy != null) { if (!G.moveMode) G.renderArmyPanel(); return; }
    if (G.selFleet != null) { if (!G.fleetMoveMode) G.renderFleetPanel(); return; }
    if (G.selZone != null && G.selected == null) { G.renderZonePanel(); return; }
    if (G.selected != null && !$('panel').classList.contains('hidden')) renderPanel(); };

  /* ---------- menu / save-load ---------- */
  G.showMenu = function () {
    const wasPaused = G.state.paused; G.setPaused(true); G.updateTopBar();
    openModal('<h3>Menu</h3><div class="row" style="flex-direction:column;align-items:stretch">' +
      '<button class="primary" id="m-resume">Resume</button><button id="m-save">Save game</button><button id="m-load">Load game</button>' +
      '<button id="m-diff">AI difficulty: ' + G.diff().name + '</button>' + (G.scenarioId === 'world' && G.state.camp ? '<button id="m-hist">Historical events: ' + (G.state.camp.hist ? 'On' : 'Off') + '</button>' : '') + '<button id="m-help">How to play</button><button id="m-cred">Credits</button><button id="m-new">Quit to nation select</button></div>');
    $('m-resume').onclick = () => { closeModal(); G.setPaused(wasPaused); G.updateTopBar(); };
    $('m-save').onclick = () => G.showSlots('save');
    $('m-load').onclick = () => G.showSlots('load');
    $('m-diff').onclick = () => { const o = G.DIFF_ORDER, i = (o.indexOf(G.state.difficulty || 'normal') + 1) % o.length; G.state.difficulty = o[i]; $('m-diff').textContent = 'AI difficulty: ' + G.diff().name; G.toast('AI difficulty: ' + G.diff().name); };
    $('m-help').onclick = () => G.showHelp(false);
    $('m-cred').onclick = () => G.showCredits();
    const mh = $('m-hist'); if (mh) mh.onclick = () => { G.state.camp.hist = !G.state.camp.hist; mh.textContent = 'Historical events: ' + (G.state.camp.hist ? 'On' : 'Off'); };
    $('m-new').onclick = () => { G.showStart(); };
  };

  G.showSlots = function (mode, fromStart) {
    const slots = mode === 'save' ? ['1', '2', '3'] : G.SAVE_SLOTS;
    let h = '<h3>' + (mode === 'save' ? 'Save game' : 'Load game') + '</h3>';
    for (const s of slots) {
      const i = G.slotInfo(s);
      h += '<div class="slot"><div class="info"><b>' + (s === 'auto' ? 'Autosave' : 'Slot ' + s) + '</b><br><small>' +
        (i ? G.COUNTRIES[i.player].name + ' · ' + G.dateString(i.date) + ' · saved ' + new Date(i.savedAt).toLocaleString() : 'Empty') +
        '</small></div><button data-s="' + s + '"' + (mode === 'load' && !i ? ' disabled' : '') + '>' + (mode === 'save' ? 'Save' : 'Load') + '</button></div>';
    }
    h += '<div class="row"><button id="sl-back">Back</button></div>';
    openModal(h);
    document.querySelectorAll('#modal-box .slot button').forEach(b => b.onclick = () => {
      if (mode === 'save') {
        const r = G.saveGame(b.dataset.s);
        G.toast(r.ok ? 'Game saved' : 'Save failed: ' + r.msg); G.showSlots('save');
      } else {
        const r = G.loadGame(b.dataset.s);
        if (r.ok) { closeModal(); afterLoad(false); G.toast('Game loaded'); } else G.toast(r.msg);
      }
    });
    $('sl-back').onclick = () => fromStart ? G.showStart() : (G.state ? G.showMenu() : G.showStart());
  };

  /* ---------- buttons ---------- */
  G.bindUI = function () {
    $('btn-pause').onclick = () => { G.setPaused(!G.state.paused); G.updateTopBar(); };
    $('btn-faster').onclick = () => { G.setSpeed(G.state.speedIdx + 1); G.updateTopBar(); };
    $('btn-slower').onclick = () => { G.setSpeed(G.state.speedIdx - 1); G.updateTopBar(); };
    $('btn-menu').onclick = G.showMenu;
    $('btn-country').onclick = () => {
      const pid = G.state.player, cap = G.provinces[G.COUNTRIES[pid].capitalId];
      G.selArmy = null; G.selFleet = null; G.selZone = null; G.selected = cap.id; panelTab = 'country';
      G.focusProvince(cap.id); G.onSelect(cap.id); G.requestDraw();
    };
    const fs = () => { try { const d = document.documentElement; (d.requestFullscreen ? d.requestFullscreen() : Promise.reject()).then(() => screen.orientation && screen.orientation.lock && screen.orientation.lock('landscape')).catch(() => {}); } catch (e) {} };
    $('rot-fs').onclick = () => { fs(); };
    $('rot-skip').onclick = () => $('rotate').classList.add('skip');
    G.bindArmyUI();
    G.bindEconomyUI();
    G.bindDiplomacyUI();
    G.bindIntelUI();
    G.bindTechUI();
    G.bindNavalUI();
    G.bindCampaignUI && G.bindCampaignUI();
    $('z-in').onclick = () => G.zoomAt($('map').clientWidth / 2, $('map').clientHeight / 2, 1.3);
    $('z-out').onclick = () => G.zoomAt($('map').clientWidth / 2, $('map').clientHeight / 2, 1 / 1.3);
    $('z-fit').onclick = () => G.fitView();
    $('z-mode').onclick = () => {
      const m = G.MAP_MODES, i = (m.indexOf(G.mapMode || 'political') + 1) % m.length;
      G.mapMode = m[i]; G.toast('Map mode: ' + G.MAP_MODE_NAMES[G.mapMode]); G.requestDraw();
    };
    window.addEventListener('keydown', e => {
      if (!G.state || !G.state.player) return;
      if (e.code === 'Space') { e.preventDefault(); $('btn-pause').click(); }
    });
  };
})(window.EMP = window.EMP || {});
