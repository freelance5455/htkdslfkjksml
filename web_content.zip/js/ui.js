"use strict";

const UI = (() => {
  const listeners = [];

  function onScreen(fn) {
    listeners.push(fn);
  }

  function showScreen(name) {
    const target = document.querySelector(`[data-screen="${name}"]`);
    if (!target) {
      console.error("شاشة غير موجودة:", name);
      return false;
    }
    document.querySelectorAll(".screen").forEach((s) => s.classList.remove("active"));
    target.classList.add("active");
    document.body.dataset.screen = name;
    window.scrollTo(0, 0);
    listeners.forEach((fn) => {
      try {
        fn(name);
      } catch (error) {
        console.error(error);
      }
    });
    return true;
  }

  let toastTimer = null;
  function toast(message, duration = 2200) {
    const el = document.getElementById("toast");
    if (!el) return;
    el.textContent = message;
    el.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove("show"), duration);
  }

  // زر بضغطتين للتأكيد
  let confirmState = { key: null, btn: null, text: "", timer: null };

  function resetTwoTap() {
    clearTimeout(confirmState.timer);
    if (confirmState.btn) confirmState.btn.textContent = confirmState.text;
    confirmState = { key: null, btn: null, text: "", timer: null };
  }

  function twoTap(key, btn, idleText, confirmText, action) {
    if (confirmState.key === key) {
      resetTwoTap();
      action();
      return;
    }
    resetTwoTap();
    confirmState = { key, btn, text: idleText, timer: setTimeout(resetTwoTap, 3000) };
    btn.textContent = confirmText;
  }

  return { showScreen, toast, onScreen, twoTap };
})();