// ===== Interface: HUD, painéis, entrada =====
const $ = (id) => document.getElementById(id);
let hotbarSig = '';

function bar(id, v) { const el = $(id); el.querySelector('i').style.width = clamp(v, 0, 100) + '%'; el.querySelector('b').textContent = Math.round(v); el.classList.toggle('crit', v < 25); }
function updateHUD() {
  if (G.mode === 'title') return;
  const p = G.player, di = dayInfo(G.t);
  bar('b-hp', p.hp); bar('b-fome', p.fome); bar('b-sede', p.sede); bar('b-en', p.energia);
  const hh = Math.floor(di.hour), mm = Math.floor((di.hour - hh) * 60);
  const ph = { amanhecer: 'Amanhecer', dia: 'Dia', entardecer: 'Entardecer', noite: 'Noite' }[di.phase];
  $('clock').innerHTML = '<b>Dia ' + di.day + '</b> · ' + String(hh).padStart(2, '0') + ':' + String(mm).padStart(2, '0') + ' · ' + ph +
    '<br><span>Maré ' + (isLowTide() ? 'baixa' : 'alta') + ' · ' + ({ limpo: 'Céu limpo', sol: 'Sol forte', chuva: 'Chuva' })[G.weather] + '</span>';
  const fx = [];
  const b = G.W.biome[tileIdx(p.x, p.y)];
  fx.push('<span class="chip">' + BIOME_NAME[b] + '</span>');
  if (p.warm) fx.push('<span class="chip good">Aquecido</span>');
  if (p.cold) fx.push('<span class="chip bad">Frio</span>');
  if (p.heat > 1) fx.push('<span class="chip warn">Calor ×' + p.heat + ' sede</span>');
  if (p.eff.indisp > 0) fx.push('<span class="chip bad">Indisposição ' + fmtTime(p.eff.indisp) + '</span>');
  if (p.eff.veneno > 0) fx.push('<span class="chip bad">Veneno ' + Math.ceil(p.eff.veneno) + 's</span>');
  if (p.eff.sangue) fx.push('<span class="chip bad">Sanguessugas</span>');
  if (p.torch > 0) fx.push('<span class="chip warn">Tocha ' + fmtTime(p.torch) + '</span>');
  if (p.running) fx.push('<span class="chip">Correndo</span>');
  if (inGas(p.x, p.y)) fx.push('<span class="chip ' + (hasItem('mascara') ? 'good' : 'bad') + '">Gás' + (hasItem('mascara') ? ' (máscara)' : '') + '</span>');
  $('effects').innerHTML = fx.join('');
  const w = weight();
  $('weight').innerHTML = 'Carga <b>' + w.toFixed(1) + '</b> / ' + cargaMax() + ' kg' + (w > cargaLim() ? ' · <em>parado</em>' : w > cargaMax() ? ' · <em>sobrecarregado</em>' : '');
  $('weight').classList.toggle('over', w > cargaMax());
  // prompt
  const a = getAction(G.curTarget);
  const pr = $('prompt');
  if (G.mode === 'play' && a) {
    pr.className = 'prompt show' + (a.can ? '' : ' no');
    pr.innerHTML = a.can ? '<kbd>E</kbd> ' + a.label + (a.time ? ' <small>' + a.time + ' s · segure</small>' : '') : a.label;
  } else pr.className = 'prompt';
  // fabricação
  const cp = $('craftprog');
  if (G.craft) { cp.style.display = 'flex'; cp.querySelector('span').textContent = 'Fabricando ' + recipeName(G.craft.r); cp.querySelector('i').style.width = (G.craft.t / G.craft.r.t) * 100 + '%'; }
  else cp.style.display = 'none';
  $('fps').textContent = fps + ' fps';
  // barra rápida
  const sig = JSON.stringify([G.inv.hot.slice(0, G.inv.hotN), G.sel]);
  if (sig !== hotbarSig) { hotbarSig = sig; renderHotbar(); }
  drawMinimap();
  if (G.ui.open && G.ui.dirty) renderPanel();
  if (G.ui.open && G.ui.tab === 'craft') { const cq = $('cq'); if (cq) cq.textContent = G.craft ? 'Fabricando ' + recipeName(G.craft.r) + ' · ' + Math.ceil(G.craft.r.t - G.craft.t) + ' s' : 'Nada em fabricação'; }
  if (G.ui.map) drawBigMap();
}
function slotHTML(s, key, extra) {
  if (!s) return '<button class="slot empty ' + (extra || '') + '" data-slot="' + key + '"></button>';
  const it = ITEMS[s.id];
  let sub = '';
  if (s.dur != null) sub = '<u style="width:' + (s.dur / it.tool.dur) * 100 + '%"></u>';
  let badge = s.n > 1 ? '<span class="n">' + s.n + '</span>' : '';
  if (it.cont) badge = '<span class="n ' + (s.doses ? (s.clean ? 'clean' : 'dirty') : '') + '">' + s.doses + '/' + it.cont + '</span>';
  return '<button class="slot ' + (extra || '') + '" data-slot="' + key + '" title="' + it.n + '"><img src="' + iconURL(s.id) + '" alt="">' + badge + sub + '</button>';
}
function renderHotbar() {
  let h = '';
  for (let i = 0; i < G.inv.hotN; i++) h += slotHTML(G.inv.hot[i], 'h-' + i, i === G.sel ? 'sel' : '').replace('</button>', '<span class="k">' + (i + 1) + '</span></button>');
  $('hotbar').innerHTML = h;
  const s = selectedSlot();
  $('hotname').textContent = s ? ITEMS[s.id].n + (ITEMS[s.id].food || ITEMS[s.id].cont || ITEMS[s.id].light || ITEMS[s.id].heal || s.id === 'sinalizador' ? ' · Q para usar' : '') : '';
}

// ---------- Painel ----------
function openPanel(tab) {
  G.ui.open = true; G.ui.tab = tab || G.ui.tab; G.ui.dirty = true; G.gather = null;
  $('panel').classList.add('show'); renderPanel();
}
function closePanel() { G.ui.open = false; G.chest = null; G.ui.selKey = null; $('panel').classList.remove('show'); }
function renderPanel() {
  G.ui.dirty = false;
  document.querySelectorAll('#tabs button').forEach((b) => b.classList.toggle('on', b.dataset.tab === G.ui.tab));
  const body = $('pbody');
  if (G.ui.tab === 'inv') body.innerHTML = invHTML();
  else if (G.ui.tab === 'craft') body.innerHTML = craftHTML();
  else if (G.ui.tab === 'diary') body.innerHTML = diaryHTML();
  else body.innerHTML = testHTML();
}
function invHTML() {
  const I = G.inv; let h = '<div class="inv"><div class="invcol">';
  h += '<h3>Barra rápida <small>ferramentas aqui são usadas automaticamente</small></h3><div class="grid">';
  for (let i = 0; i < I.hotN; i++) h += slotHTML(I.hot[i], 'h-' + i, G.ui.selKey === 'h-' + i ? 'picked' : '');
  h += '</div><h3>Bolsos <small>' + I.pocketN + ' espaços</small></h3><div class="grid">';
  for (let i = 0; i < I.pocketN; i++) h += slotHTML(I.pocket[i], 'p-' + i, G.ui.selKey === 'p-' + i ? 'picked' : '');
  h += '</div>';
  if (G.chest) { h += '<h3>Baú de madeira <small>24 espaços · não conta no peso</small></h3><div class="grid">'; for (let i = 0; i < 24; i++) h += slotHTML(G.chest.items[i], 'c-' + i, G.ui.selKey === 'c-' + i ? 'picked' : ''); h += '</div>'; }
  const w = weight();
  h += '<div class="wbar"><span>Carga ' + w.toFixed(1) + ' / ' + cargaMax() + ' kg (limite ' + cargaLim() + ')</span><i style="width:' + clamp((w / cargaLim()) * 100, 0, 100) + '%" class="' + (w > cargaMax() ? 'over' : '') + '"></i></div>';
  h += '<h3>Equipamento</h3><div class="ups">';
  for (const [k, u] of Object.entries(UPGRADES)) h += '<div class="up ' + (I.ups[k] ? 'on' : '') + '"><b>' + u.n + '</b><span>' + (I.ups[k] ? 'Equipado · ' : 'Não fabricado · ') + u.d + '</span></div>';
  h += '<div class="up ' + (hasItem('mascara') ? 'on' : '') + '"><b>Máscara de gás</b><span>' + (hasItem('mascara') ? 'Carregando' : 'Não fabricada') + ' · protege do gás vulcânico</span></div>';
  h += '</div></div><div class="detail">' + detailHTML() + '</div></div>';
  return h;
}
function detailHTML() {
  const r = G.ui.selKey && slotRef(G.ui.selKey);
  if (!r || !r.s) return '<p class="muted">Clique num item para ver detalhes. Clique em outro espaço para mover, trocar ou empilhar.</p><p class="muted small">Dica: abrir o inventário não pausa o jogo.</p>';
  const s = r.s, it = ITEMS[s.id];
  let h = '<div class="dhead"><img src="' + iconURL(s.id) + '" alt=""><div><b>' + it.n + (s.dried ? ' (seco)' : '') + '</b><span>' + s.n + ' × ' + it.w + ' kg</span></div></div>';
  if (it.d) h += '<p>' + it.d + '</p>';
  if (it.food) h += '<p class="small">+' + it.food.f + ' fome' + (it.food.s ? ' · +' + it.food.s + ' sede' : '') + (it.food.raw ? ' · cru: ' + Math.round(it.food.raw * 100) + '% de indisposição' : '') + (it.food.tox ? ' · ' + Math.round(it.food.tox * 100) + '% tóxica' : '') + '</p>';
  if (s.spoil) h += '<p class="small">Estraga em ' + fmtTime(s.spoil - G.t) + '</p>';
  if (s.dur != null) h += '<p class="small">Durabilidade ' + s.dur + '/' + it.tool.dur + ' · tier ' + it.tool.t + '</p>';
  if (it.cont) h += '<p class="small">' + s.doses + '/' + it.cont + ' doses' + (s.doses ? (s.clean ? ' · água limpa' : ' · não tratada (ferva na fogueira)') : '') + '</p>';
  h += '<div class="acts">';
  const inChest = r.key[0] === 'c';
  if (!inChest && (it.food || it.heal || it.light || it.cont || s.id === 'sinalizador')) h += '<button data-act="use">Usar</button>';
  if (!inChest && r.key[0] === 'p') h += '<button data-act="tohot">Para a barra</button>';
  if (!inChest && r.key[0] === 'h') h += '<button data-act="topocket">Para os bolsos</button>';
  if (G.chest && !inChest) h += '<button data-act="store">Guardar no baú</button>';
  if (inChest) h += '<button data-act="take">Pegar</button>';
  if (!inChest) h += '<button data-act="drop" class="ghost">Largar</button>';
  return h + '</div>';
}
function craftHTML() {
  let h = '<div class="cq" id="cq"></div><p class="muted small">Receitas aparecem quando você já teve todos os ingredientes em mãos. Estações precisam estar a até 3 passos.</p>';
  for (const tier of [1, 2, 3]) {
    h += '<h3>' + TIER_NAME[tier] + '</h3><div class="rlist">';
    let unknown = 0;
    for (const r of RECIPES.filter((x) => x.tier === tier)) {
      if (!G.known.has(r.id)) { unknown++; continue; }
      const st = craftState(r);
      const icon = r.out ? iconURL(r.out) : r.place ? iconURL({ fogueira: 'graveto', cama: 'folha', abrigo: 'folha', bancada: 'tora', coletor: 'pote', secador: 'corda_cipo', forno: 'argila', bau: 'tora' }[r.place]) : r.up ? iconURL('pano') : iconURL('pote');
      const ing = Object.entries(r.ing).map(([id, n]) => { const c = countItem(id); return '<span class="ing ' + (c >= n ? 'ok' : '') + '">' + ITEMS[id].n + ' ' + Math.min(c, 99) + '/' + n + '</span>'; }).join('');
      const tag = r.place ? 'Construção' : r.up ? 'Melhoria' : r.st === 'fogueira' ? 'Fogueira' : '';
      h += '<div class="rc ' + (st.ok ? 'ok' : '') + '"><img src="' + icon + '" alt=""><div class="ri"><b>' + recipeName(r) + (tag ? ' <em>' + tag + '</em>' : '') + '</b><div>' + (ing || '<span class="ing">Pote ou cantil com água não tratada</span>') + '</div><span class="why">' + (r.st ? 'Estação: ' + STATION_NAME[r.st] + ' · ' : '') + r.t + ' s' + (st.ok ? '' : ' · ' + st.why) + '</span></div><button data-craft="' + r.id + '" ' + (st.ok ? '' : 'disabled') + '>Fabricar</button></div>';
    }
    if (unknown) h += '<div class="rc unknown"><div class="ri"><b>' + unknown + ' receita' + (unknown > 1 ? 's' : '') + ' por descobrir</b><span class="why">Explore e colete materiais novos</span></div></div>';
    h += '</div>';
  }
  return h;
}
function diaryHTML() {
  let h = '<p class="muted small">Páginas de outro náufrago espalhadas pela ilha. ' + G.pages.size + ' de 8 encontradas.</p><div class="pages">';
  for (let i = 0; i < 8; i++) h += G.pages.has(i) ? '<div class="pg"><b>Página ' + (i + 1) + '</b><p>' + PAGES[i] + '</p></div>' : '<div class="pg missing"><b>Página ' + (i + 1) + '</b><p>Ainda não encontrada.</p></div>';
  return h + '</div>';
}
function testHTML() {
  const T2 = G.tel, mins = (s) => (s == null ? '—' : fmtTime(s));
  const ev = (k) => (T2.ev[k] ? T2.ev[k].t : null);
  const row = (label, val, goal, ok) => '<tr><td>' + label + '</td><td><b>' + val + '</b></td><td>' + goal + '</td><td class="' + (ok == null ? '' : ok ? 'ok' : 'bad') + '">' + (ok == null ? 'em andamento' : ok ? 'na meta' : 'alerta') + '</td></tr>';
  const sess = T2.session, invPct = sess > 0 ? (T2.invOpen / sess) * 100 : 0;
  const bios = Object.keys(T2.biomes).length, sedeDeaths = T2.deaths.filter((d) => d.cause === 'sede').length;
  let h = '<p class="muted small">Métricas da seção 9.2 do documento de design, medidas nesta partida. Tempo de sessão: <b>' + fmtTime(sess) + '</b>.</p>';
  h += '<table class="tm"><thead><tr><th>Métrica</th><th>Valor</th><th>Meta</th><th>Status</th></tr></thead><tbody>';
  h += row('Tempo até a primeira ferramenta', mins(ev('primeira_ferramenta')), '< 5:00', ev('primeira_ferramenta') == null ? (sess > 600 ? false : null) : ev('primeira_ferramenta') < 300);
  h += row('Tempo até a primeira fogueira', mins(ev('primeira_fogueira')), '< 18:00', ev('primeira_fogueira') == null ? (sess > 1080 ? false : null) : ev('primeira_fogueira') < 1080);
  h += row('Mortes por sede', sedeDeaths, '0–1', sedeDeaths <= 1);
  h += row('Chegada ao tier 2 (bancada)', mins(ev('tier2')), '≤ 75:00', ev('tier2') == null ? (sess > 4500 ? false : null) : ev('tier2') <= 4500);
  h += row('Biomas visitados', bios + ' de 5', '≥ 3 em 60 min', bios >= 3 ? true : sess > 3600 ? false : null);
  h += row('Tempo com inventário aberto', invPct.toFixed(1) + '%', '< 12%', sess < 60 ? null : invPct < 12);
  h += row('Mapa revelado', revealedPct() + '%', '—', null);
  h += '</tbody></table>';
  h += '<h3>Marcos</h3><ul class="log">' + (Object.values(T2.ev).sort((a, b) => a.t - b.t).map((e) => '<li><b>' + fmtTime(e.t) + '</b> ' + e.label + '</li>').join('') || '<li class="muted">Nenhum ainda</li>') + '</ul>';
  h += '<h3>Mortes</h3><ul class="log">' + (T2.deaths.map((d) => '<li><b>' + fmtTime(d.t) + '</b> ' + CAUSE[d.cause] + '</li>').join('') || '<li class="muted">Nenhuma</li>') + '</ul>';
  h += '<h3>Status ao anoitecer</h3><ul class="log">' + (T2.nights.map((n) => '<li>Dia ' + n.dia + ': vida ' + n.vida + ', fome ' + n.fome + ', sede ' + n.sede + (n.fogueira ? ', com fogueira' : ', sem fogueira') + '</li>').join('') || '<li class="muted">Ainda não anoiteceu</li>') + '</ul>';
  h += '<h3>Itens largados por falta de espaço</h3><p>' + T2.dropped + '</p>';
  h += '<h3>Receitas fabricadas</h3><ul class="log">' + (T2.crafted.slice(-14).map((c) => '<li><b>' + fmtTime(c.t) + '</b> ' + c.n + '</li>').join('') || '<li class="muted">Nenhuma</li>') + '</ul>';
  return h;
}
function panelClick(e) {
  const tb = e.target.closest('#tabs button'); if (tb) { G.ui.tab = tb.dataset.tab; G.ui.selKey = null; renderPanel(); return; }
  if (e.target.closest('#pclose')) { closePanel(); return; }
  const cb = e.target.closest('[data-craft]'); if (cb) { startCraft(cb.dataset.craft); renderPanel(); return; }
  const sl = e.target.closest('[data-slot]');
  if (sl) {
    const key = sl.dataset.slot;
    if (!$('panel').classList.contains('show')) { // clique na barra rápida do HUD
      G.sel = +key.split('-')[1]; renderHotbar(); return;
    }
    const cur = G.ui.selKey;
    if (cur && cur !== key) { moveSlot(cur, key); G.ui.selKey = null; }
    else if (cur === key) G.ui.selKey = null;
    else if (slotRef(key).s) G.ui.selKey = key;
    renderPanel(); return;
  }
  const ab = e.target.closest('[data-act]');
  if (ab) {
    const r = slotRef(G.ui.selKey); if (!r || !r.s) return;
    const act = ab.dataset.act;
    if (act === 'use') { useSlot(r); if (!r.arr[r.i]) G.ui.selKey = null; }
    if (act === 'drop') { dropPile([r.s]); r.arr[r.i] = null; G.ui.selKey = null; toast('Itens largados no chão', 'info'); }
    if (act === 'tohot' || act === 'topocket' || act === 'store' || act === 'take') {
      const dest = act === 'tohot' ? ['h', G.inv.hotN] : act === 'topocket' ? ['p', G.inv.pocketN] : act === 'store' ? ['c', 24] : null;
      if (dest) {
        const arr = dest[0] === 'h' ? G.inv.hot : dest[0] === 'p' ? G.inv.pocket : G.chest.items;
        let idx = -1; for (let i = 0; i < dest[1]; i++) if (!arr[i]) { idx = i; break; }
        if (idx < 0) toast('Sem espaço livre', 'warn'); else { moveSlot(G.ui.selKey, dest[0] + '-' + idx); G.ui.selKey = null; }
      } else {
        const s = r.s, left = addItem(s.id, s.n, s.dur != null || s.spoil || s.doses != null ? s : null);
        if (left > 0) { s.n = left; toast('Não coube tudo (espaço ou peso)', 'warn'); } else { r.arr[r.i] = null; G.ui.selKey = null; }
        checkRecipes();
      }
    }
    G.ui.dirty = true; renderPanel();
  }
}
function moveSlot(a, b) {
  const A = slotRef(a), Bs = slotRef(b); if (!A || !Bs || !A.s) return;
  const sa = A.s, sb = Bs.s;
  if (a[0] === 'c' && b[0] !== 'c') { // do baú para o inventário: checar peso
    const extra = ITEMS[sa.id].w * sa.n - (sb ? ITEMS[sb.id].w * sb.n : 0);
    if (weight() + extra > cargaLim()) { toast('Peso demais para pegar isso', 'warn'); return; }
  }
  if (sb && sb.id === sa.id && ITEMS[sa.id].st > 1 && !sa.dried && !sb.dried) {
    const room = ITEMS[sa.id].st - sb.n, mv = Math.min(room, sa.n); sb.n += mv; sa.n -= mv; if (sa.n <= 0) A.arr[A.i] = null;
  } else { A.arr[A.i] = sb; Bs.arr[Bs.i] = sa; }
  G.seen.add(sa.id); checkRecipes(); G.ui.dirty = true;
}

// ---------- Página / fim ----------
function showPage(i) {
  $('pagetext').textContent = PAGES[i]; $('pagenum').textContent = 'Página ' + (i + 1) + ' de 8';
  $('pagemodal').classList.add('show');
}
function showEnd(won, cause) {
  const T2 = G.tel, el = $('endscreen');
  $('endtitle').textContent = won ? 'Resgatado' : 'Fim da linha';
  $('endsub').textContent = won ? 'Um navio viu o sinalizador no dia ' + dayInfo(G.t).day + '. Você escapou da ilha.' : 'Causa: ' + CAUSE[cause] + '. Sem uma cama, não há onde acordar.';
  const ev = (k) => (T2.ev[k] ? fmtTime(T2.ev[k].t) : '—');
  $('endstats').innerHTML = '<div><span>Tempo de sessão</span><b>' + fmtTime(T2.session) + '</b></div><div><span>Primeira ferramenta</span><b>' + ev('primeira_ferramenta') + '</b></div><div><span>Primeira fogueira</span><b>' + ev('primeira_fogueira') + '</b></div><div><span>Tier 2</span><b>' + ev('tier2') + '</b></div><div><span>Biomas visitados</span><b>' + Object.keys(T2.biomes).length + '/5</b></div><div><span>Páginas</span><b>' + G.pages.size + '/8</b></div><div><span>Receitas fabricadas</span><b>' + T2.crafted.length + '</b></div><div><span>Mortes</span><b>' + T2.deaths.length + '</b></div>';
  el.classList.add('show'); el.classList.toggle('won', won);
}

// ---------- Mapa ----------
function drawMinimap() {
  const c = $('minimap'), g = c.getContext('2d'), p = G.player;
  g.imageSmoothingEnabled = false;
  g.clearRect(0, 0, c.width, c.height);
  g.drawImage(mapC, 0, 0, c.width, c.height); g.drawImage(fogC, 0, 0, c.width, c.height);
  const sx = c.width / MW, sy = c.height / MH;
  for (const m of G.markers) { g.fillStyle = MARK[m.t].c; g.fillRect(m.x * sx - 2, m.y * sy - 2, 4, 4); }
  for (const n of G.nodes) if (n && !n.gone && n.struct && G.revealed[n.ty * MW + n.tx]) { g.fillStyle = '#f2c14e'; g.fillRect(n.tx * sx - 1, n.ty * sy - 1, 3, 3); }
  g.fillStyle = '#fff'; g.beginPath(); g.arc((p.x / TS) * sx, (p.y / TS) * sy, 3, 0, 7); g.fill();
  g.strokeStyle = '#c0452e'; g.lineWidth = 1.5; g.stroke();
}
const MARK = { agua: { n: 'Água', c: '#5ad0ff' }, perigo: { n: 'Perigo', c: '#ff5a4a' }, recurso: { n: 'Recurso', c: '#f2c14e' }, base: { n: 'Acampamento', c: '#7fe07f' } };
function toggleMap() {
  G.ui.map = !G.ui.map; $('bigmap').classList.toggle('show', G.ui.map);
  if (G.ui.map) { renderMarkerBtns(); drawBigMap(); }
}
function renderMarkerBtns() {
  $('mkbtns').innerHTML = Object.entries(MARK).map(([k, m]) => '<button data-mk="' + k + '" class="' + (G.ui.markerType === k ? 'on' : '') + '"><i style="background:' + m.c + '"></i>' + m.n + '</button>').join('');
}
function drawBigMap() {
  const c = $('mapcanvas'), g = c.getContext('2d'), p = G.player;
  g.imageSmoothingEnabled = false; g.clearRect(0, 0, c.width, c.height);
  g.drawImage(mapC, 0, 0, c.width, c.height); g.drawImage(fogC, 0, 0, c.width, c.height);
  const sx = c.width / MW, sy = c.height / MH;
  for (const n of G.nodes) if (n && !n.gone && G.revealed[n.ty * MW + n.tx] && (n.struct || n.type === 'mirante' || n.type === 'fonte_termal' || n.type === 'naufragio')) {
    g.fillStyle = n.struct ? '#f2c14e' : n.type === 'mirante' ? '#ffffff' : n.type === 'fonte_termal' ? '#9ff' : '#8a5a32';
    g.fillRect(n.tx * sx - 3, n.ty * sy - 3, 6, 6);
  }
  if (G.revealed[G.W.spring[1] * MW + G.W.spring[0]]) { g.fillStyle = '#6ccfe0'; g.strokeStyle = '#fff'; g.lineWidth = 2; g.beginPath(); g.arc(G.W.spring[0] * sx, G.W.spring[1] * sy, 6, 0, 7); g.fill(); g.stroke(); }
  for (const m of G.markers) { g.fillStyle = MARK[m.t].c; g.strokeStyle = '#111'; g.lineWidth = 2; g.beginPath(); g.moveTo(m.x * sx, m.y * sy); g.lineTo(m.x * sx - 6, m.y * sy - 12); g.lineTo(m.x * sx + 6, m.y * sy - 12); g.closePath(); g.fill(); g.stroke(); }
  g.fillStyle = '#fff'; g.strokeStyle = '#c0452e'; g.lineWidth = 3; g.beginPath(); g.arc((p.x / TS) * sx, (p.y / TS) * sy, 6, 0, 7); g.fill(); g.stroke();
  $('mapinfo').textContent = revealedPct() + '% da ilha explorada';
}
function mapClick(e, remove) {
  const c = $('mapcanvas'), r = c.getBoundingClientRect();
  const x = ((e.clientX - r.left) / r.width) * MW, y = ((e.clientY - r.top) / r.height) * MH;
  const near = G.markers.findIndex((m) => Math.hypot(m.x - x, m.y - y) < 3);
  if (near >= 0) G.markers.splice(near, 1);
  else if (!remove) G.markers.push({ x, y, t: G.ui.markerType });
  drawBigMap();
}

// ---------- Entrada ----------
function keyDown(code, e) {
  if (G.mode === 'title') return;
  if ($('pagemodal').classList.contains('show') && (code === 'Escape' || code === 'KeyE' || code === 'Enter' || code === 'Space')) { $('pagemodal').classList.remove('show'); return; }
  if (code === 'Escape') {
    if (G.ui.map) return toggleMap();
    if (G.ui.open) return closePanel();
    if (G.mode === 'play') return pauseGame(true);
    if (G.mode === 'paused') return pauseGame(false);
  }
  if (G.mode !== 'play') return;
  if (code === 'Tab' || code === 'KeyI') { if (e) e.preventDefault(); G.ui.open && G.ui.tab === 'inv' ? closePanel() : openPanel('inv'); return; }
  if (code === 'KeyC') { G.ui.open && G.ui.tab === 'craft' ? closePanel() : openPanel('craft'); return; }
  if (code === 'KeyJ') { G.ui.open && G.ui.tab === 'diary' ? closePanel() : openPanel('diary'); return; }
  if (code === 'KeyP') { G.ui.open && G.ui.tab === 'test' ? closePanel() : openPanel('test'); return; }
  if (code === 'KeyM') return toggleMap();
  if (code === 'KeyN') { const m = AudioSys.toggle(); $('btn-sound').textContent = m ? 'Som: off' : 'Som: on'; return; }
  if (/^Digit[1-6]$/.test(code)) { const i = +code.slice(5) - 1; if (i < G.inv.hotN) { G.sel = i; renderHotbar(); } return; }
  if (code === 'KeyE') { if (!G.gather) tryInteract(false); return; }
  if (code === 'KeyF') return attack();
  if (code === 'KeyQ') { useSlot({ arr: G.inv.hot, i: G.sel }); return; }
}
function pauseGame(on) {
  G.mode = on ? 'paused' : 'play'; $('pause').classList.toggle('show', on);
}
function initInput() {
  addEventListener('keydown', (e) => {
    if (['Tab', 'Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) e.preventDefault();
    const rep = keys[e.code]; keys[e.code] = true;
    if (!rep) keyDown(e.code, e);
  });
  addEventListener('keyup', (e) => { keys[e.code] = false; });
  addEventListener('blur', () => { for (const k in keys) keys[k] = false; });
  canvas.addEventListener('mousedown', (e) => { if (G.mode === 'play' && e.button === 0) attack(); });
  canvas.addEventListener('wheel', (e) => { if (G.mode !== 'play') return; G.sel = (G.sel + (e.deltaY > 0 ? 1 : -1) + G.inv.hotN) % G.inv.hotN; renderHotbar(); }, { passive: true });
  $('panel').addEventListener('click', panelClick);
  $('hotbar').addEventListener('click', panelClick);
  $('hotbar').addEventListener('dblclick', (e) => { const sl = e.target.closest('[data-slot]'); if (sl) useSlot(slotRef(sl.dataset.slot)); });
  $('btn-inv').onclick = () => (G.ui.open ? closePanel() : openPanel('inv'));
  $('btn-craft').onclick = () => openPanel('craft');
  $('btn-map').onclick = toggleMap;
  $('btn-sound').onclick = () => { const m = AudioSys.toggle(); $('btn-sound').textContent = m ? 'Som: off' : 'Som: on'; };
  $('btn-pause').onclick = () => pauseGame(true);
  $('mapcanvas').addEventListener('click', (e) => mapClick(e, false));
  $('mapcanvas').addEventListener('contextmenu', (e) => { e.preventDefault(); mapClick(e, true); });
  $('mkbtns').addEventListener('click', (e) => { const b = e.target.closest('[data-mk]'); if (b) { G.ui.markerType = b.dataset.mk; renderMarkerBtns(); } });
  $('mapclose').onclick = toggleMap;
  $('minimap').onclick = toggleMap;
  $('pageclose').onclick = () => $('pagemodal').classList.remove('show');
  $('resume').onclick = () => pauseGame(false);
  $('restart').onclick = () => { pauseGame(false); restart(); };
  $('endrestart').onclick = restart;
  $('start').onclick = startGame;
  // toque
  const coarse = matchMedia('(pointer: coarse)').matches || 'ontouchstart' in window;
  if (coarse) document.body.classList.add('touch');
  const joy = $('joy'), knob = $('knob'); let jid = null, jc = null;
  joy.addEventListener('touchstart', (e) => { const t = e.changedTouches[0]; jid = t.identifier; const r = joy.getBoundingClientRect(); jc = { x: r.left + r.width / 2, y: r.top + r.height / 2 }; e.preventDefault(); }, { passive: false });
  addEventListener('touchmove', (e) => { for (const t of e.changedTouches) if (t.identifier === jid) { let dx = (t.clientX - jc.x) / 50, dy = (t.clientY - jc.y) / 50; const l = Math.hypot(dx, dy); if (l > 1) { dx /= l; dy /= l; } G.joy = { x: dx, y: dy }; G.joyRun = l > 1.25; knob.style.transform = 'translate(' + dx * 34 + 'px,' + dy * 34 + 'px)'; } }, { passive: true });
  addEventListener('touchend', (e) => { for (const t of e.changedTouches) if (t.identifier === jid) { jid = null; G.joy = null; G.joyRun = false; knob.style.transform = ''; } });
  const tb = (id, down, up) => { const el = $(id); el.addEventListener('touchstart', (e) => { e.preventDefault(); down(); }, { passive: false }); el.addEventListener('touchend', (e) => { e.preventDefault(); up && up(); }); el.addEventListener('mousedown', down); el.addEventListener('mouseup', () => up && up()); };
  tb('t-e', () => { G.touchE = true; if (!G.gather) tryInteract(false); }, () => { G.touchE = false; });
  tb('t-f', attack); tb('t-q', () => useSlot({ arr: G.inv.hot, i: G.sel }));
  tb('t-run', () => { G.joyRun = !G.joyRun; $('t-run').classList.toggle('on', G.joyRun); });
}
function startGame() {
  AudioSys.init();
  newGame();
  G.mode = 'play'; checkRecipes(true);
  $('title').classList.remove('show'); $('hud').classList.add('show');
  hotbarSig = ''; updateHUD();
  setTimeout(() => toast('Você acorda na praia, ao lado dos destroços do navio. Encontre água primeiro', 'info'), 400);
  setTimeout(() => toast('Segure E perto de recursos para coletar. C abre a fabricação', 'info'), 2600);
}
function restart() {
  $('endscreen').classList.remove('show'); closePanel(); if (G.ui.map) toggleMap();
  startGame();
}

window.addEventListener('load', async () => {
  canvas = $('game'); ctx = canvas.getContext('2d');
  lightC = document.createElement('canvas'); lctx = lightC.getContext('2d');
  resize(); addEventListener('resize', resize);
  newGame(); G.mode = 'title';
  initInput();
  try { await document.fonts.ready; } catch (e) {}
  requestAnimationFrame(frame);
});
