/* عارض الصور: سحب، تكبير بإصبعين، نقر مزدوج */
window.Viewer = (function () {
  var el = document.getElementById('viewer');
  var stage = document.getElementById('stage');
  var counter = document.getElementById('counter');
  var MAX = 5;

  var list = [], index = 0;
  var slides = [];                 // [السابقة, الحالية, التالية]
  var scale = 1, tx = 0, ty = 0;   // حالة التكبير
  var pointers = new Map();
  var g = null;                    // الإيماءة الحالية
  var lastTap = 0, lastTapX = 0, lastTapY = 0, tapTimer = null;
  var busy = false;

  for (var i = 0; i < 3; i++) {
    var d = document.createElement('div');
    d.className = 'slide';
    d.appendChild(new Image());
    stage.appendChild(d);
    slides.push(d);
  }
  function img(k) { return slides[k].firstChild; }

  function width() { return stage.clientWidth; }

  /* الاتجاه من اليمين إلى اليسار: التالية موضوعة على اليسار */
  function place(dx, dy, animate) {
    slides.forEach(function (s, k) {
      s.style.transition = animate ? 'transform .25s ease-out' : 'none';
      s.style.transform = 'translate3d(' + ((1 - k) * (width() + 16) + dx) + 'px,' + (k === 1 ? dy : 0) + 'px,0)';
    });
  }

  function paint(animate) {
    img(1).style.transition = animate ? 'transform .22s ease-out' : 'none';
    img(1).style.transform = 'translate3d(' + tx + 'px,' + ty + 'px,0) scale(' + scale + ')';
    document.getElementById('zoomOut').disabled = scale <= 1;
    document.getElementById('zoomIn').disabled = scale >= MAX;
  }

  function resetZoom() { scale = 1; tx = ty = 0; }

  function render() {
    resetZoom();
    [index - 1, index, index + 1].forEach(function (n, k) {
      var item = list[n], im = img(k);
      im.style.transition = im.style.transform = '';
      if (item) { im.src = 'images/full/' + item.f; im.alt = 'صورة ' + (n + 1); }
      else { im.removeAttribute('src'); im.alt = ''; }
    });
    counter.textContent = (index + 1) + ' من ' + list.length;
    place(0, 0, false);
    paint(false);
  }

  /* منع خروج الصورة المكبرة عن حدود الشاشة */
  function clamp() {
    var item = list[index];
    var W = stage.clientWidth, H = stage.clientHeight;
    var fit = Math.min(W / item.w, H / item.h);
    var maxX = Math.max(0, (item.w * fit * scale - W) / 2);
    var maxY = Math.max(0, (item.h * fit * scale - H) / 2);
    tx = Math.min(maxX, Math.max(-maxX, tx));
    ty = Math.min(maxY, Math.max(-maxY, ty));
  }

  /* التكبير حول نقطة محددة (إحداثيات بالنسبة لمركز الشاشة) */
  function zoomTo(s, cx, cy, animate) {
    s = Math.min(MAX, Math.max(1, s));
    tx = cx - (cx - tx) * s / scale;
    ty = cy - (cy - ty) * s / scale;
    scale = s;
    clamp();
    paint(animate);
  }

  function go(step) {
    if (busy) return;
    if (!list[index + step]) { place(0, 0, true); return; }
    busy = true;
    resetZoom(); paint(true);
    place(step * (width() + 16), 0, true);
    setTimeout(function () { index += step; render(); busy = false; }, 260);
  }

  function center(x, y) { return { x: x - stage.clientWidth / 2, y: y - stage.clientHeight / 2 }; }

  function pinchInfo() {
    var p = Array.from(pointers.values());
    var c = center((p[0].x + p[1].x) / 2, (p[0].y + p[1].y) / 2);
    return { d: Math.hypot(p[0].x - p[1].x, p[0].y - p[1].y) || 1, x: c.x, y: c.y };
  }

  function startDrag(p) { g = { type: 'drag', x: p.x, y: p.y, tx: tx, ty: ty, time: Date.now(), axis: null, dx: 0, dy: 0 }; }

  stage.addEventListener('pointerdown', function (e) {
    if (busy) return;
    stage.setPointerCapture(e.pointerId);
    pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pointers.size === 1) startDrag(pointers.get(e.pointerId));
    else if (pointers.size === 2) { place(0, 0, false); g = { type: 'pinch', last: pinchInfo() }; }
  });

  stage.addEventListener('pointermove', function (e) {
    if (!pointers.has(e.pointerId) || !g) return;
    var p = { x: e.clientX, y: e.clientY };
    pointers.set(e.pointerId, p);
    if (g.type === 'pinch' && pointers.size >= 2) {
      var now = pinchInfo();
      tx += now.x - g.last.x; ty += now.y - g.last.y;
      zoomTo(scale * now.d / g.last.d, now.x, now.y, false);
      g.last = now;
    } else if (g.type === 'drag') {
      g.dx = p.x - g.x; g.dy = p.y - g.y;
      if (!g.axis && Math.hypot(g.dx, g.dy) > 8) g.axis = Math.abs(g.dx) > Math.abs(g.dy) ? 'x' : 'y';
      if (!g.axis) return;
      if (scale > 1) { tx = g.tx + g.dx; ty = g.ty + g.dy; clamp(); paint(false); }
      else if (g.axis === 'x') {
        var edge = !list[index + (g.dx > 0 ? 1 : -1)];
        place(edge ? g.dx * 0.3 : g.dx, 0, false);
      } else place(0, Math.max(0, g.dy), false);
    }
  });

  function end(e) {
    if (!pointers.delete(e.pointerId) || !g) return;
    if (g.type === 'pinch') {
      if (pointers.size === 1) { startDrag(pointers.values().next().value); g.axis = 'pinched'; }
      else if (pointers.size >= 2) g.last = pinchInfo();
      else g = null;
      return;
    }
    var d = g; g = null;
    if (e.type === 'pointercancel') { if (scale === 1) place(0, 0, true); return; }
    if (!d.axis) { tap(e.clientX, e.clientY); return; }
    if (scale > 1 || d.axis === 'pinched') return;
    var fast = Date.now() - d.time < 300;
    if (d.axis === 'x') {
      if (Math.abs(d.dx) > width() * 0.25 || (fast && Math.abs(d.dx) > 40)) go(d.dx > 0 ? 1 : -1);
      else place(0, 0, true);
    } else if (d.dy > 110) Screens.back();
    else place(0, 0, true);
  }
  stage.addEventListener('pointerup', end);
  stage.addEventListener('pointercancel', end);

  function tap(x, y) {
    var now = Date.now();
    if (now - lastTap < 300 && Math.hypot(x - lastTapX, y - lastTapY) < 40) {
      clearTimeout(tapTimer); lastTap = 0;
      var c = center(x, y);
      zoomTo(scale > 1 ? 1 : 2.5, c.x, c.y, true);
    } else {
      lastTap = now; lastTapX = x; lastTapY = y;
      tapTimer = setTimeout(function () { el.classList.toggle('clean'); }, 300);
    }
  }

  document.getElementById('zoomIn').addEventListener('click', function () { zoomTo(scale * 1.5, 0, 0, true); });
  document.getElementById('zoomOut').addEventListener('click', function () { zoomTo(scale / 1.5, 0, 0, true); });
  document.getElementById('playPuzzle').addEventListener('click', function () { Puzzle.open(list[index]); });
  stage.addEventListener('wheel', function (e) {
    e.preventDefault();
    var c = center(e.clientX, e.clientY);
    zoomTo(scale * (e.deltaY < 0 ? 1.15 : 1 / 1.15), c.x, c.y, false);
  }, { passive: false });
  document.addEventListener('keydown', function (e) {
    if (Screens.top() !== 'viewer') return;
    if (e.key === 'ArrowLeft') go(1);
    if (e.key === 'ArrowRight') go(-1);
  });
  window.addEventListener('resize', function () { if (!el.hidden) { resetZoom(); place(0, 0, false); paint(false); } });

  return {
    open: function (items, i) {
      list = items; index = i; busy = false; pointers.clear(); g = null;
      el.classList.remove('clean');
      Screens.open('viewer', function () {
        clearTimeout(tapTimer);
        if (window.Gallery) Gallery.reveal(list[index]);
      });
      render();
    }
  };
})();
