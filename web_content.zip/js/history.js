import { money, getDateValue } from "./shared-utils.js";
// =====================================================
// NetEarn Pro
// Premium Wallet History
//
// IMPORTANT:
// Existing Firestore transaction system is NOT changed.
// This page only READS existing transactions.
// =====================================================


import {
    auth,
    db
} from "./firebase.js";


import {
    onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";


import {
    collection,
    query,
    where,
    getDocs
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";



// =====================================================
// HELPERS
// =====================================================
function escapeHTML(value) {

    return String(
        value ?? ""
    )
        .replace(
            /&/g,
            "&amp;"
        )
        .replace(
            /</g,
            "&lt;"
        )
        .replace(
            />/g,
            "&gt;"
        )
        .replace(
            /"/g,
            "&quot;"
        )
        .replace(
            /'/g,
            "&#039;"
        );

}
function formatDate(date) {

    if (!date) {

        return "Date unavailable";

    }


    return date.toLocaleString(
        "en-GB",
        {
            day: "2-digit",
            month: "short",
            year: "numeric",
            hour: "2-digit",
            minute: "2-digit"
        }
    );

}



// =====================================================
// LOAD HISTORY
// =====================================================


async function loadHistory(uid) {

    const historyList =
        document.getElementById(
            "historyList"
        );


    if (!historyList) {

        return;

    }


    try {

        const historyQuery =
            query(

                collection(
                    db,
                    "transactions"
                ),

                where(
                    "uid",
                    "==",
                    uid
                )

            );


        const snapshot =
            await getDocs(
                historyQuery
            );


        const transactions = [];


        snapshot.forEach(
            transactionDoc => {

                const data =
                    transactionDoc.data();


                transactions.push({

                    id:
                        transactionDoc.id,

                    amount:
                        Number(
                            data.amount || 0
                        ),

                    type:
                        String(
                            data.type ||
                            "credit"
                        )
                        .trim()
                        .toLowerCase(),

                    reason:
                        String(
                            data.reason ||
                            "Wallet Transaction"
                        ),

                    status:
                        String(
                            data.status ||
                            "Completed"
                        ),

                    createdAt:
                        getDateValue(
                            data.createdAt
                        )

                });

            }
        );



        // =================================================
        // NEWEST FIRST
        // =================================================

        transactions.sort(
            (a, b) => {

                const aTime =
                    a.createdAt
                        ?.getTime() || 0;


                const bTime =
                    b.createdAt
                        ?.getTime() || 0;


                return (
                    bTime -
                    aTime
                );

            }
        );



        // =================================================
        // SUMMARY
        // =================================================

        let totalCredit = 0;

        let totalDebit = 0;


        transactions.forEach(
            transaction => {

                if (
                    transaction.type ===
                    "credit"
                ) {

                    totalCredit +=
                        transaction.amount;

                }

                else if (
                    transaction.type ===
                    "debit"
                ) {

                    totalDebit +=
                        transaction.amount;

                }

            }
        );



        const totalTransactions =
            document.getElementById(
                "totalTransactions"
            );


        const totalCreditBox =
            document.getElementById(
                "totalCredit"
            );


        const totalDebitBox =
            document.getElementById(
                "totalDebit"
            );


        if (totalTransactions) {

            totalTransactions.innerText =
                transactions.length;

        }


        if (totalCreditBox) {

            totalCreditBox.innerText =
                money(totalCredit);

        }


        if (totalDebitBox) {

            totalDebitBox.innerText =
                money(totalDebit);

        }



        // =================================================
        // EMPTY
        // =================================================

        if (!transactions.length) {

            historyList.innerHTML = `

                <div class="empty-history">

                    <div class="empty-icon">
                        —
                    </div>

                    <h3>
                        No Transaction Yet
                    </h3>

                    <p>
                        Your wallet transaction history
                        will appear here.
                    </p>

                </div>

            `;

            return;

        }



        // =================================================
        // RENDER
        // =================================================

        historyList.innerHTML =
            transactions
                .map(
                    createHistoryHTML
                )
                .join("");


        console.log(
            "✅ Wallet History Loaded:",
            transactions.length
        );

    }


    catch (error) {

        console.error(
            "❌ Wallet History Error:",
            error
        );


        historyList.innerHTML = `

            <div class="empty-history">

                <div class="empty-icon">
                    !
                </div>

                <h3>
                    History Load Failed
                </h3>

                <p>
                    Transaction history এখন
                    load করা যাচ্ছে না।
                </p>

            </div>

        `;

    }

}



// =====================================================
// CREATE HISTORY CARD
// =====================================================


function createHistoryHTML(
    transaction
) {

    const isCredit =
        transaction.type ===
        "credit";


    const amountClass =
        isCredit
            ? "credit"
            : "debit";


    const sign =
        isCredit
            ? "+"
            : "-";


    const status =
        transaction.status
            .toLowerCase();


    let statusClass =
        "history-status";


    if (
        status.includes(
            "complete"
        ) ||
        status.includes(
            "approve"
        ) ||
        status === "success"
    ) {

        statusClass +=
            " status-approved";

    }

    else if (
        status.includes(
            "reject"
        ) ||
        status.includes(
            "fail"
        )
    ) {

        statusClass +=
            " status-rejected";

    }

    else {

        statusClass +=
            " status-pending";

    }



    return `

        <article
            class="premium-history-card"
        >

            <div class="history-card-top">


                <div>

                    <div
                        class="
                            history-type
                            ${amountClass}
                        "
                    >

                        ${isCredit
                            ? "CREDIT"
                            : "DEBIT"
                        }

                    </div>


                    <h4>
                        ${escapeHTML(
                            transaction.reason
                        )}
                    </h4>

                </div>



                <div
                    class="
                        history-amount
                        ${amountClass}
                    "
                >

                    ${sign}
                    ${money(
                        transaction.amount
                    )}

                </div>


            </div>



            <div class="history-card-bottom">


                <div>

                    <span>
                        Status
                    </span>

                    <strong
                        class="${statusClass}"
                    >
                        ${escapeHTML(
                            transaction.status
                        )}
                    </strong>

                </div>



                <div>

                    <span>
                        Date
                    </span>

                    <strong>

                        ${escapeHTML(
                            formatDate(
                                transaction.createdAt
                            )
                        )}

                    </strong>

                </div>


            </div>


        </article>

    `;

}



// =====================================================
// AUTH
// =====================================================


onAuthStateChanged(

    auth,

    async user => {

        if (!user) {

            window.location.href =
                "index.html";

            return;

        }


        console.log(
            "🟢 History User:",
            user.uid
        );


        await loadHistory(
            user.uid
        );

    }

);


console.log(
    "======================================="
);

console.log(
    "🟢 NetEarn Pro Premium History Ready"
);

console.log(
    "======================================="
);