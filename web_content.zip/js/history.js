// ==========================================
// CIVIL 3 - ATTENDANCE HISTORY
// ==========================================

document.addEventListener("DOMContentLoaded", function () {

    const STORAGE_PREFIX = "civil3_attendance_";

    const historyTotal = document.getElementById("historyTotal");
    const historyList = document.getElementById("historyList");
    const historyMessage = document.getElementById("historyMessage");

    const historyDetails = document.getElementById("historyDetails");
    const detailsTitle = document.getElementById("detailsTitle");
    const detailsPresent = document.getElementById("detailsPresent");
    const detailsAbsent = document.getElementById("detailsAbsent");
    const detailsList = document.getElementById("detailsList");
    const closeDetails = document.getElementById("closeDetails");

    let records = [];

    function escapeHTML(value) {
        return String(value).replace(/[&<>"']/g, function (character) {
            const entities = {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#39;"
            };

            return entities[character];
        });
    }

    function formatDate(dateString) {
        const date = new Date(dateString + "T00:00:00");

        if (Number.isNaN(date.getTime())) {
            return dateString;
        }

        return date.toLocaleDateString("en-IN", {
            day: "2-digit",
            month: "short",
            year: "numeric"
        });
    }

    function getStatuses(record) {
        // New format: { date, locked, savedAt, statuses: { id: P/A } }
        if (
            record &&
            record.statuses &&
            typeof record.statuses === "object"
        ) {
            return record.statuses;
        }

        // Older format: { id: P/A }
        return record || {};
    }

    function loadRecords() {
        records = [];

        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);

            if (!key || !key.startsWith(STORAGE_PREFIX)) {
                continue;
            }

            const dateFromKey = key.substring(STORAGE_PREFIX.length);

            try {
                const saved = JSON.parse(localStorage.getItem(key));

                if (!saved || typeof saved !== "object") {
                    continue;
                }

                const statuses = getStatuses(saved);

                const presentCount = Object.values(statuses).filter(
                    status => status === "P"
                ).length;

                const absentCount = Object.values(statuses).filter(
                    status => status === "A"
                ).length;

                // Only show records that have at least one saved status.
                if (presentCount + absentCount === 0) {
                    continue;
                }

                records.push({
                    date: saved.date || dateFromKey,
                    savedAt: saved.savedAt || "",
                    locked: saved.locked === true,
                    statuses: statuses,
                    present: presentCount,
                    absent: absentCount
                });

            } catch (error) {
                console.error("Could not read attendance record:", key, error);
            }
        }

        records.sort((a, b) => b.date.localeCompare(a.date));
    }

    function renderHistory() {
        loadRecords();

        historyTotal.textContent = records.length;
        historyMessage.textContent = "";

        if (records.length === 0) {
            historyList.innerHTML = `
                <div class="empty-state">
                    <i class="fa-solid fa-calendar-xmark"></i>
                    <p>No saved attendance records found.</p>
                </div>
            `;
            return;
        }

        historyList.innerHTML = records.map(function (record) {
            const safeDate = escapeHTML(record.date);

            return `
                <article class="student-row">
                    <div class="student-avatar">
                        <i class="fa-solid fa-calendar-check"></i>
                    </div>

                    <div class="student-info">
                        <h3>${escapeHTML(formatDate(record.date))}</h3>
                        <p>
                            Present: ${record.present}
                            &nbsp; | &nbsp;
                            Absent: ${record.absent}
                        </p>
                    </div>

                    <button
                        type="button"
                        class="btn btn-outline view-history"
                        data-date="${safeDate}"
                    >
                        View
                    </button>
                </article>
            `;
        }).join("");
    }

    function showDetails(date) {
        const record = records.find(item => item.date === date);

        if (!record) {
            return;
        }

        detailsTitle.textContent = "Attendance — " + formatDate(record.date);
        detailsPresent.textContent = record.present;
        detailsAbsent.textContent = record.absent;

        const students = Array.isArray(window.STUDENTS)
            ? window.STUDENTS
            : [];

        const statuses = record.statuses;

        const entries = Object.entries(statuses);

        if (entries.length === 0) {
            detailsList.innerHTML = `
                <div class="empty-state">
                    <p>No student statuses found in this record.</p>
                </div>
            `;
        } else {
            detailsList.innerHTML = entries.map(function ([id, status]) {
                const student = students.find(
                    item => String(item.id) === String(id)
                );

                const name = student
                    ? student.name
                    : "Student ID " + id;

                const label = status === "P"
                    ? "Present"
                    : status === "A"
                        ? "Absent"
                        : "Not marked";

                return `
                    <article class="student-row">
                        <div class="student-avatar">
                            <i class="fa-solid fa-user-graduate"></i>
                        </div>

                        <div class="student-info">
                            <h3>${escapeHTML(name)}</h3>
                            <p>${label}</p>
                        </div>
                    </article>
                `;
            }).join("");
        }

        historyDetails.hidden = false;
        historyDetails.scrollIntoView({
            behavior: "smooth",
            block: "start"
        });
    }

    historyList.addEventListener("click", function (event) {
        const button = event.target.closest(".view-history");

        if (button) {
            showDetails(button.dataset.date);
        }
    });

    if (closeDetails) {
        closeDetails.addEventListener("click", function () {
            historyDetails.hidden = true;
        });
    }

    renderHistory();

    console.log("Attendance History loaded. Records:", records.length);

});