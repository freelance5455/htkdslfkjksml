/* نمودارهای SVG بدون کتابخانه‌ی بیرونی. رنگ‌ها با کلاس‌های CSS (برای تم روشن/تاریک). */
(function () {
  'use strict';
  var App = (window.App = window.App || {});
  var u = App.u;
  var ch = (App.chart = {});

  // ستونی؛ values: عدد، labels: متن زیر هر ستون، goal: خط هدف (اختیاری)
  ch.bars = function (o) {
    var values = o.values || [], labels = o.labels || [];
    var W = 320, H = 150, pad = 26, base = H - 28, top = 14;
    var max = Math.max.apply(null, [1, o.goal || 0].concat(values));
    var n = values.length || 1, slot = (W - pad * 2) / n, bw = Math.max(6, slot * 0.6);
    var parts = [];
    values.forEach(function (v, i) {
      var h = Math.max(2, (v / max) * (base - top));
      var x = pad + i * slot + (slot - bw) / 2;
      parts.push('<rect class="bar-fill" x="' + x.toFixed(1) + '" y="' + (base - h).toFixed(1) + '" width="' + bw.toFixed(1) + '" height="' + h.toFixed(1) + '" rx="4"><title>' + u.esc((labels[i] || '') + ': ' + u.fa(v) + ' دقیقه') + '</title></rect>');
      if (v > 0) parts.push('<text class="ch-num" x="' + (x + bw / 2).toFixed(1) + '" y="' + (base - h - 4).toFixed(1) + '" text-anchor="middle">' + u.fa(v) + '</text>');
      parts.push('<text class="ch-lbl" x="' + (x + bw / 2).toFixed(1) + '" y="' + (H - 8) + '" text-anchor="middle">' + u.esc(labels[i] || '') + '</text>');
    });
    if (o.goal) {
      var gy = base - (o.goal / max) * (base - top);
      parts.push('<line class="goal-line" x1="' + pad + '" x2="' + (W - pad) + '" y1="' + gy.toFixed(1) + '" y2="' + gy.toFixed(1) + '"/>');
    }
    var sum = values.reduce(function (a, b) { return a + b; }, 0);
    return '<svg class="chart" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="' + u.esc(o.label || 'نمودار ستونی') + ': جمع ' + u.fa(sum) + ' دقیقه" preserveAspectRatio="xMidYMid meet">' + parts.join('') + '</svg>';
  };

  // دونات: items: [{label, value}]
  ch.donut = function (items) {
    var total = items.reduce(function (a, b) { return a + b.value; }, 0);
    if (!total) return '<p class="mu">داده‌ای برای نمودار نیست.</p>';
    var R = 40, C = 2 * Math.PI * R, off = 0, parts = [];
    items.forEach(function (it, i) {
      var len = it.value / total * C;
      parts.push('<circle class="seg c' + (i % 8) + '" cx="50" cy="50" r="' + R + '" fill="none" stroke-width="16" stroke-dasharray="' + len.toFixed(2) + ' ' + (C - len).toFixed(2) + '" stroke-dashoffset="' + (-off).toFixed(2) + '" transform="rotate(-90 50 50)"><title>' + u.esc(it.label + ': ' + u.fa(it.value) + ' دقیقه') + '</title></circle>');
      off += len;
    });
    var legend = items.map(function (it, i) {
      return '<li><span class="dot c' + (i % 8) + '" aria-hidden="true"></span>' + u.esc(it.label) + ' <b>' + u.fa(Math.round(it.value / 60 * 10) / 10) + ' ساعت</b> <span class="mu">(' + u.fa(Math.round(it.value / total * 100)) + '٪)</span></li>';
    }).join('');
    return '<div class="donut-wrap"><svg class="chart donut" viewBox="0 0 100 100" role="img" aria-label="نمودار دایره‌ای زمان مطالعه به تفکیک درس">' + parts.join('') + '<text x="50" y="54" text-anchor="middle" class="ch-big">' + u.fa(Math.round(total / 60 * 10) / 10) + '</text></svg><ul class="legend">' + legend + '</ul></div>';
  };

  // خط روند درصد: points: [{label, y}] با بازه‌ی ۰ تا ۱۰۰
  ch.line = function (points) {
    if (points.length < 2) return '<p class="mu">برای نمودار روند حداقل ۲ آزمون لازم است.</p>';
    var W = 320, H = 150, padX = 16, padT = 16, padB = 26;
    var n = points.length;
    var xy = points.map(function (p, i) {
      var x = padX + i * (W - padX * 2) / (n - 1);
      var y = padT + (1 - u.clamp(p.y, 0, 100) / 100) * (H - padT - padB);
      return { x: x, y: y, p: p };
    });
    var poly = xy.map(function (q) { return q.x.toFixed(1) + ',' + q.y.toFixed(1); }).join(' ');
    var dots = xy.map(function (q) {
      return '<circle class="dot-pt" cx="' + q.x.toFixed(1) + '" cy="' + q.y.toFixed(1) + '" r="4"><title>' + u.esc(q.p.label + ': ' + u.pct(q.p.y)) + '</title></circle><text class="ch-num" x="' + q.x.toFixed(1) + '" y="' + (q.y - 8).toFixed(1) + '" text-anchor="middle">' + u.fa(Math.round(q.p.y)) + '</text>';
    }).join('');
    var grid = [0, 50, 100].map(function (v) {
      var y = padT + (1 - v / 100) * (H - padT - padB);
      return '<line class="grid" x1="' + padX + '" x2="' + (W - padX) + '" y1="' + y.toFixed(1) + '" y2="' + y.toFixed(1) + '"/><text class="ch-lbl" x="2" y="' + (y + 3).toFixed(1) + '">' + u.fa(v) + '</text>';
    }).join('');
    var last = xy[xy.length - 1].p;
    return '<svg class="chart" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="روند درصد آزمون‌ها، آخرین: ' + u.esc(u.pct(last.y)) + '">' + grid + '<polyline class="trend" points="' + poly + '" fill="none"/>' + dots + '</svg>';
  };

  // نقشه‌ی حرارتی: rows: [{n, d, cells[]}], cols: [names]
  ch.heat = function (rows, cols) {
    if (!rows.length || !cols.length) return '<p class="mu">هنوز آزمونی با تفکیک درس نیست.</p>';
    var head = '<tr><th scope="col">آزمون</th>' + cols.map(function (c) { return '<th scope="col">' + u.esc(c) + '</th>'; }).join('') + '</tr>';
    var body = rows.map(function (r) {
      return '<tr><th scope="row">' + u.esc(r.n) + '<span class="mu"> · ' + u.esc(u.jd(r.d)) + '</span></th>' + r.cells.map(function (v, i) {
        if (v == null) return '<td class="hc na" aria-label="بدون داده">—</td>';
        var lvl = Math.round(u.clamp(v, 0, 100) / 20);
        return '<td class="hc l' + lvl + '" aria-label="' + u.esc(cols[i] + ': ' + u.pct(v)) + '">' + u.fa(Math.round(v)) + '</td>';
      }).join('') + '</tr>';
    }).join('');
    return '<div class="heat-wrap"><table class="heat"><caption class="sr">نقشه‌ی درصد هر درس در آزمون‌های اخیر</caption><thead>' + head + '</thead><tbody>' + body + '</tbody></table></div>';
  };

  // حلقه‌ی پیشرفت
  ch.ring = function (p, label) {
    p = u.clamp(p || 0, 0, 100);
    var C = 2 * Math.PI * 42;
    return '<div class="ring-wrap"><svg class="ring" viewBox="0 0 100 100" width="124" height="124" role="img" aria-label="' + u.esc(label || 'پیشرفت') + ': ' + u.fa(Math.round(p)) + ' درصد"><circle cx="50" cy="50" r="42" class="ring-bg" fill="none" stroke-width="9"/><circle cx="50" cy="50" r="42" class="ring-fg" fill="none" stroke-width="9" stroke-linecap="round" stroke-dasharray="' + (C * p / 100).toFixed(2) + ' ' + C.toFixed(2) + '" transform="rotate(-90 50 50)"/><text x="50" y="57" text-anchor="middle" class="ch-big">' + u.fa(Math.round(p)) + '٪</text></svg><div class="mu">' + u.esc(label || 'از هدف روزانه') + '</div></div>';
  };
})();
