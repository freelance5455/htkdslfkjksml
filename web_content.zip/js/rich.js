/* texto formatado: negrito, itálico, sublinhado e lista; guarda HTML limpo (só b, i, u, br, p, ul, ol, li) */
const rich=(()=>{const OK={B:'b',STRONG:'b',I:'i',EM:'i',U:'u',BR:'br',UL:'ul',OL:'ol',LI:'li',P:'p',DIV:'p'};
function clean(h){const t=document.createElement('template');t.innerHTML=h;const w=n=>{let o='';for(const c of n.childNodes){if(c.nodeType==3)o+=esc(c.textContent);else if(c.nodeType==1){const k=OK[c.tagName],i=w(c);o+=k=='br'?'<br>':k?`<${k}>${i}</${k}>`:i}}return o};return w(t.content)}
function toHtml(s){s=String(s||'');const h=/<[a-z]/i.test(s)?clean(s):esc(s).replace(/\n/g,'<br>');return h.replace(/<[^>]*>|&nbsp;/g,'').trim()?h:''}
const BT=[['bold','<b>B</b>','Negrito'],['italic','<i>I</i>','Itálico'],['underline','<u>U</u>','Sublinhado'],['insertUnorderedList','<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M9 6h11M9 12h11M9 18h11"/><circle cx="4.5" cy="6" r="1" fill="currentColor"/><circle cx="4.5" cy="12" r="1" fill="currentColor"/><circle cx="4.5" cy="18" r="1" fill="currentColor"/></svg>','Lista']];
const field=(a,l,h,cls='',ph='')=>`<div class="${cls}"><label>${l}</label><div class="rt"><div class="rt-ed" contenteditable="true"${ph?` data-ph="${ph.replace(/"/g,'&quot;')}"`:''} ${a}>${toHtml(h)}</div><div class="rt-bar">${BT.map(([c,i,t])=>`<button type="button" data-cmd="${c}" title="${t}" aria-label="${t}" aria-pressed="false">${i}</button>`).join('')}</div></div></div>`;
/* estado visual (botão ativo) conforme o texto onde está o cursor/seleção */
function sync(){const sel=document.getSelection(),n=sel&&sel.anchorNode,el=n&&(n.nodeType==1?n:n.parentElement),ed=el&&el.closest?el.closest('.rt-ed'):null;
document.querySelectorAll('.rt-bar [data-cmd]').forEach(b=>{let on=false;try{on=!!ed&&b.closest('.rt')==ed.closest('.rt')&&document.queryCommandState(b.dataset.cmd)}catch{}b.classList.toggle('on',on);b.setAttribute('aria-pressed',on)})}
document.addEventListener('selectionchange',sync);
document.addEventListener('mousedown',e=>{if(e.target.closest('.rt-bar'))e.preventDefault()});
document.addEventListener('click',e=>{const b=e.target.closest('[data-cmd]');if(!b)return;const ed=b.closest('.rt').querySelector('.rt-ed');ed.focus();document.execCommand(b.dataset.cmd);ed.dispatchEvent(new Event('input',{bubbles:true}));sync()});
document.addEventListener('paste',e=>{if(!e.target.closest||!e.target.closest('.rt-ed'))return;e.preventDefault();document.execCommand('insertText',false,e.clipboardData.getData('text/plain'))});
return{clean,toHtml,field}})();
