import { clamp } from './rig.js';

const MP_VERSION = '0.10.14';
const MP_BASE = `https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@${MP_VERSION}`;
const MODEL_URL = 'https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task';

/** Filtro One-Euro: suaviza sem criar latência perceptível em movimentos rápidos. */
class OneEuro {
  constructor() { this.x = null; this.dx = 0; this.t = 0; }
  static alpha(cut, dt) { const tau = 1 / (2 * Math.PI * cut); return 1 / (1 + tau / dt); }
  filter(v, t, minCut, beta) {
    if (this.x === null) { this.x = v; this.t = t; return v; }
    const dt = Math.max((t - this.t) / 1000, 1 / 240);
    this.t = t;
    const rawDx = (v - this.x) / dt;
    this.dx += OneEuro.alpha(1, dt) * (rawDx - this.dx);
    const cut = minCut + beta * Math.abs(this.dx);
    this.x += OneEuro.alpha(cut, dt) * (v - this.x);
    return this.x;
  }
  reset() { this.x = null; }
}

export const DEFAULT_SETTINGS = {
  mirror: true, smooth: 0.55,
  headGain: 1.0, eyeGain: 1.0, mouthGain: 1.0, browGain: 1.0,
  invX: false, invY: false, invZ: false,
  blinkLo: 0.25, blinkHi: 0.65,
};

const smoothstep = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };

export class Tracker {
  constructor(video, settings) {
    this.video = video;
    this.s = settings;
    this.running = false;
    this.landmarker = null;
    this.filters = {};
    this.neutral = { AngleX: 0, AngleY: 0, AngleZ: 0 };
    this.raw = { yaw: 0, pitch: 0, roll: 0 };
    this.out = null;        // últimos valores de parâmetros rastreados
    this.lastSeen = 0;
    this.fps = 0;
    this.onStatus = () => {};
    this._lastVideoTime = -1;
  }

  async start() {
    this.onStatus('Pedindo acesso à câmera…');
    if (!navigator.mediaDevices?.getUserMedia)
      throw new Error('Câmera indisponível. Abra o app por HTTPS (ou localhost).');
    this.stream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 }, frameRate: { ideal: 30 } },
      audio: false,
    });
    this.video.srcObject = this.stream;
    await this.video.play();

    if (!this.landmarker) {
      this.onStatus('Baixando modelo de rastreamento (≈4 MB, só na 1ª vez)…');
      const { FaceLandmarker, FilesetResolver } = await import(`${MP_BASE}/vision_bundle.mjs`);
      const fileset = await FilesetResolver.forVisionTasks(`${MP_BASE}/wasm`);
      const make = delegate => FaceLandmarker.createFromOptions(fileset, {
        baseOptions: { modelAssetPath: MODEL_URL, delegate },
        runningMode: 'VIDEO', numFaces: 1,
        outputFaceBlendshapes: true, outputFacialTransformationMatrixes: true,
      });
      try { this.landmarker = await make('GPU'); }
      catch (e) { console.warn('GPU indisponível, usando CPU', e); this.landmarker = await make('CPU'); }
    }
    this.running = true;
    this.onStatus('Rastreando');
    this._loop();
  }

  stop() {
    this.running = false;
    this.stream?.getTracks().forEach(t => t.stop());
    this.stream = null;
    this.video.srcObject = null;
    this.out = null;
    Object.values(this.filters).forEach(f => f.reset());
    this.onStatus('Parado');
  }

  _loop() {
    if (!this.running) return;
    const v = this.video;
    if (v.readyState >= 2 && v.currentTime !== this._lastVideoTime) {
      this._lastVideoTime = v.currentTime;
      const now = performance.now();
      try {
        const res = this.landmarker.detectForVideo(v, now);
        this.process(res, now);
      } catch (e) { console.warn(e); }
      this.fps = this.fps * 0.9 + (1000 / Math.max(1, performance.now() - (this._t0 || now - 33))) * 0.1;
      this._t0 = now;
    }
    if (v.requestVideoFrameCallback) v.requestVideoFrameCallback(() => this._loop());
    else requestAnimationFrame(() => this._loop());
  }

  calibrate() {
    this.neutral = {
      AngleX: this.raw.yaw, AngleY: this.raw.pitch, AngleZ: this.raw.roll,
    };
  }

  _f(key, v, t, kind) {
    const f = this.filters[key] || (this.filters[key] = new OneEuro());
    const s = this.s.smooth;
    const minCut = 8 * (1 - s) + 0.4;
    return f.filter(v, t, minCut, kind === 'angle' ? 0.04 : 0.8);
  }

  /** Converte o resultado do MediaPipe em valores de parâmetros do rig. */
  process(res, t) {
    if (!res?.faceLandmarks?.length) { this.out = null; return; }
    this.lastSeen = t;
    const s = this.s;

    // ---- pose da cabeça (matriz 4x4 coluna-major) ----
    const d = res.facialTransformationMatrixes?.[0]?.data;
    let yaw = 0, pitch = 0, roll = 0;
    if (d) {
      const R = 180 / Math.PI;
      yaw = Math.asin(clamp(d[8], -1, 1)) * R;
      pitch = Math.atan2(-d[9], d[10]) * R;
      roll = Math.atan2(-d[4], d[0]) * R;
      if (pitch > 90) pitch -= 180; else if (pitch < -90) pitch += 180;
    }
    this.raw = { yaw, pitch, roll };
    const sgn = (inv) => (inv ? -1 : 1) * (s.mirror ? 1 : -1);
    const angle = (key, val, neutral, inv, mirrorsToo) => {
      const k = (mirrorsToo ? sgn(inv) : (inv ? -1 : 1));
      return this._f(key, (val - neutral) * k * s.headGain, t, 'angle');
    };
    const AngleX = angle('ax', yaw, this.neutral.AngleX, s.invX, true);
    const AngleY = angle('ay', pitch, this.neutral.AngleY, s.invY, false);
    const AngleZ = angle('az', roll, this.neutral.AngleZ, s.invZ, true);

    // ---- blendshapes ----
    const bs = {};
    for (const c of res.faceBlendshapes?.[0]?.categories || []) bs[c.categoryName] = c.score;
    const g = n => bs[n] || 0;
    // No modo espelho, o olho "E" do modelo (esquerda da tela) = olho esquerdo do usuário.
    const L = s.mirror ? 'Left' : 'Right', Rr = s.mirror ? 'Right' : 'Left';
    const open = side => 1 - smoothstep(s.blinkLo, s.blinkHi, g('eyeBlink' + side) * s.eyeGain);
    const brow = side => clamp(((g('browOuterUp' + side) + g('browInnerUp') * 0.5) * 1.6 - g('browDown' + side) * 1.6) * s.browGain, -1, 1);

    // olhar: positivo = para a direita da tela
    const lookRight = (g('eyeLookOutRight') + g('eyeLookInLeft') - g('eyeLookInRight') - g('eyeLookOutLeft')) / 2;
    const lookUp = (g('eyeLookUpLeft') + g('eyeLookUpRight') - g('eyeLookDownLeft') - g('eyeLookDownRight')) / 2;
    const smile = (g('mouthSmileLeft') + g('mouthSmileRight')) / 2;
    const frown = (g('mouthFrownLeft') + g('mouthFrownRight')) / 2;
    const jaw = clamp(g('jawOpen') * 1.5 * s.mouthGain, 0, 1);
    const pucker = g('mouthPucker');

    const out = {
      AngleX, AngleY, AngleZ,
      EyeLOpen: this._f('eL', open(L), t, 'bs'),
      EyeROpen: this._f('eR', open(Rr), t, 'bs'),
      EyeBallX: this._f('bx', clamp(lookRight * 1.6 * (s.mirror ? 1 : -1) * s.eyeGain, -1, 1), t, 'bs'),
      EyeBallY: this._f('by', clamp(lookUp * 1.6 * s.eyeGain, -1, 1), t, 'bs'),
      BrowLY: this._f('bl', brow(L), t, 'bs'),
      BrowRY: this._f('br', brow(Rr), t, 'bs'),
      MouthOpen: this._f('mo', jaw, t, 'bs'),
      MouthForm: this._f('mf', clamp((smile * 2.2 - frown * 2 - pucker * 0.6) * s.mouthGain, -1, 1), t, 'bs'),
      Cheek: this._f('ch', clamp(smile * 2.5 - 0.2, 0, 1), t, 'bs'),
    };
    // Extras para o pacote de boca (só são usados se o parâmetro existir no modelo)
    const funnel = g('mouthFunnel'), stretch = (g('mouthStretchLeft') + g('mouthStretchRight')) / 2;
    const mx = (s.mirror ? 1 : -1) * (g('mouthRight') - g('mouthLeft'));
    out.MouthU = this._f('mu', clamp((pucker * 1.8 - funnel * 0.3) * s.mouthGain, 0, 1), t, 'bs');
    out.MouthO = this._f('mO', clamp((funnel * 1.8 + jaw * 0.2) * s.mouthGain, 0, 1), t, 'bs');
    out.MouthI = this._f('mi', clamp((stretch * 2.2 + smile * 0.6) * s.mouthGain, 0, 1), t, 'bs');
    out.TongueOut = this._f('tg', clamp(g('tongueOut') * 1.8, 0, 1), t, 'bs');
    out.MouthX = this._f('mx', clamp(mx * 2.2, -1, 1), t, 'bs');
    out.CheekPuff = this._f('cp', clamp(g('cheekPuff') * 1.8, 0, 1), t, 'bs');
    out.BodyX = clamp(AngleX / 3, -10, 10);
    for (const k of ['EyeLOpen', 'EyeROpen', 'MouthOpen', 'Cheek']) out[k] = clamp(out[k], 0, 1);
    this.out = out;
  }

  get active() { return this.running && this.out && performance.now() - this.lastSeen < 400; }
}
