// ===== Ícones procedurais dos itens =====
const ICON_CACHE = {};
function iconURL(id) {
  if (ICON_CACHE[id]) return ICON_CACHE[id];
  const c = document.createElement('canvas'); c.width = c.height = 48;
  const g = c.getContext('2d');
  drawIcon(g, ITEMS[id] ? ITEMS[id].ic : ['stone', '#888']);
  ICON_CACHE[id] = c.toDataURL();
  return ICON_CACHE[id];
}
function blob(g, x, y, r, col, seed) {
  g.beginPath();
  for (let i = 0; i <= 8; i++) {
    const a = (i / 8) * Math.PI * 2, rr = r * (0.8 + hash2(i, seed || 1, 3) * 0.35);
    const px = x + Math.cos(a) * rr, py = y + Math.sin(a) * rr * 0.85;
    i ? g.lineTo(px, py) : g.moveTo(px, py);
  }
  g.closePath(); g.fillStyle = col; g.fill();
}
function drawIcon(g, ic) {
  const [s, c] = ic;
  g.lineCap = 'round'; g.lineJoin = 'round';
  const handle = () => { g.strokeStyle = '#7a5230'; g.lineWidth = 4; g.beginPath(); g.moveTo(14, 40); g.lineTo(34, 10); g.stroke(); };
  switch (s) {
    case 'stick': g.strokeStyle = c; g.lineWidth = 4; g.beginPath(); g.moveTo(10, 38); g.lineTo(38, 12); g.moveTo(24, 25); g.lineTo(30, 32); g.stroke(); break;
    case 'fiber': g.strokeStyle = c; g.lineWidth = 2.5; for (let i = 0; i < 4; i++) { g.beginPath(); g.moveTo(12 + i * 7, 40); g.quadraticCurveTo(6 + i * 9, 22, 18 + i * 6, 8); g.stroke(); } break;
    case 'leaf': g.fillStyle = c; g.beginPath(); g.moveTo(8, 40); g.quadraticCurveTo(6, 10, 40, 8); g.quadraticCurveTo(38, 38, 8, 40); g.fill(); g.strokeStyle = shade(c, -0.2); g.lineWidth = 2; g.beginPath(); g.moveTo(10, 38); g.lineTo(36, 12); g.stroke(); break;
    case 'vine': g.strokeStyle = c; g.lineWidth = 3; g.beginPath(); g.moveTo(24, 6); g.bezierCurveTo(6, 18, 42, 28, 22, 42); g.stroke(); g.fillStyle = '#7fb069'; for (const [x, y] of [[16, 14], [32, 24], [20, 34]]) { g.beginPath(); g.ellipse(x, y, 5, 3, 0.6, 0, 7); g.fill(); } break;
    case 'resin': g.fillStyle = c; g.beginPath(); g.moveTo(24, 6); g.quadraticCurveTo(40, 30, 24, 40); g.quadraticCurveTo(8, 30, 24, 6); g.fill(); g.fillStyle = 'rgba(255,255,255,.5)'; g.beginPath(); g.ellipse(20, 26, 3, 6, 0.3, 0, 7); g.fill(); break;
    case 'log': g.fillStyle = c; g.fillRect(8, 16, 30, 16); g.fillStyle = '#c9925a'; g.beginPath(); g.ellipse(38, 24, 5, 8, 0, 0, 7); g.fill(); g.strokeStyle = '#8a5a32'; g.lineWidth = 1.5; g.beginPath(); g.ellipse(38, 24, 2.5, 4, 0, 0, 7); g.stroke(); break;
    case 'pebble': blob(g, 24, 26, 10, c, 2); g.fillStyle = 'rgba(255,255,255,.25)'; g.beginPath(); g.arc(20, 22, 3, 0, 7); g.fill(); break;
    case 'stone': blob(g, 24, 26, 16, c, 5); blob(g, 20, 22, 6, shade(c, 0.1), 4); break;
    case 'flint': g.fillStyle = c; g.beginPath(); g.moveTo(10, 34); g.lineTo(22, 8); g.lineTo(38, 18); g.lineTo(32, 40); g.closePath(); g.fill(); g.fillStyle = '#9fb4c8'; g.beginPath(); g.moveTo(22, 8); g.lineTo(28, 20); g.lineTo(38, 18); g.fill(); break;
    case 'obsidian': g.fillStyle = c; g.beginPath(); g.moveTo(24, 4); g.lineTo(38, 22); g.lineTo(26, 44); g.lineTo(10, 24); g.closePath(); g.fill(); g.strokeStyle = '#8a7ab8'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(24, 4); g.lineTo(22, 30); g.stroke(); break;
    case 'sulfur': g.fillStyle = c; for (const [x, y, r] of [[18, 28, 9], [30, 24, 8], [24, 34, 7]]) { g.beginPath(); g.moveTo(x, y - r); g.lineTo(x + r, y); g.lineTo(x, y + r); g.lineTo(x - r, y); g.fill(); } break;
    case 'clay': blob(g, 24, 28, 15, c, 9); g.fillStyle = shade(c, 0.12); g.beginPath(); g.ellipse(20, 24, 6, 3, 0, 0, 7); g.fill(); break;
    case 'cloth': g.fillStyle = c; g.beginPath(); g.moveTo(8, 12); g.lineTo(40, 8); g.lineTo(38, 40); g.lineTo(10, 38); g.closePath(); g.fill(); g.strokeStyle = '#a89878'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(10, 24); g.lineTo(38, 22); g.stroke(); break;
    case 'rope': g.strokeStyle = c; g.lineWidth = 4; g.beginPath(); g.arc(24, 24, 13, 0, 7); g.stroke(); g.beginPath(); g.arc(24, 24, 7, 0, 7); g.stroke(); break;
    case 'metal': g.fillStyle = c; g.fillRect(10, 14, 28, 20); g.fillStyle = '#c08050'; g.fillRect(14, 18, 6, 4); g.fillRect(26, 26, 8, 4); break;
    case 'shell': g.fillStyle = c; g.beginPath(); g.moveTo(24, 40); g.lineTo(8, 18); g.quadraticCurveTo(24, 2, 40, 18); g.closePath(); g.fill(); g.strokeStyle = '#c8a898'; g.lineWidth = 1.5; for (const x of [16, 24, 32]) { g.beginPath(); g.moveTo(24, 40); g.lineTo(x, 12); g.stroke(); } break;
    case 'coal': blob(g, 24, 26, 13, c, 6); g.fillStyle = '#555'; g.beginPath(); g.arc(20, 22, 3, 0, 7); g.fill(); break;
    case 'shellhalf': g.fillStyle = c; g.beginPath(); g.arc(24, 22, 15, 0, Math.PI); g.fill(); g.fillStyle = '#f2ead8'; g.beginPath(); g.ellipse(24, 22, 15, 4, 0, 0, 7); g.fill(); break;
    case 'herb': g.strokeStyle = '#5c8a3a'; g.lineWidth = 2.5; g.beginPath(); g.moveTo(24, 42); g.lineTo(24, 14); g.stroke(); g.fillStyle = c; for (const [x, y, a] of [[18, 30, -0.6], [30, 26, 0.6], [18, 20, -0.6], [30, 16, 0.6]]) { g.beginPath(); g.ellipse(x, y, 7, 3.5, a, 0, 7); g.fill(); } g.fillStyle = '#b57ad0'; g.beginPath(); g.arc(24, 11, 3.5, 0, 7); g.fill(); break;
    case 'blade': g.fillStyle = c; g.beginPath(); g.moveTo(10, 38); g.lineTo(38, 8); g.lineTo(30, 30); g.closePath(); g.fill(); g.strokeStyle = '#8a7ab8'; g.lineWidth = 1.5; g.stroke(); break;
    case 'coconut': g.fillStyle = c; g.beginPath(); g.arc(24, 26, 15, 0, 7); g.fill(); g.fillStyle = '#3e2a16'; for (const [x, y] of [[19, 20], [27, 20], [23, 27]]) { g.beginPath(); g.arc(x, y, 2.4, 0, 7); g.fill(); } break;
    case 'berry': g.fillStyle = '#4f9a46'; g.beginPath(); g.ellipse(24, 12, 9, 4, 0, 0, 7); g.fill(); g.fillStyle = c; for (const [x, y] of [[17, 24], [29, 24], [23, 33], [31, 34], [15, 34]]) { g.beginPath(); g.arc(x, y, 6, 0, 7); g.fill(); } break;
    case 'meat': case 'meatc': g.fillStyle = c; g.beginPath(); g.ellipse(22, 26, 14, 11, -0.4, 0, 7); g.fill(); g.fillStyle = '#efe6d2'; g.beginPath(); g.arc(36, 14, 4, 0, 7); g.fill(); g.strokeStyle = '#efe6d2'; g.lineWidth = 4; g.beginPath(); g.moveTo(30, 20); g.lineTo(36, 14); g.stroke(); if (s === 'meatc') { g.strokeStyle = 'rgba(60,30,10,.5)'; g.lineWidth = 2; g.beginPath(); g.moveTo(14, 24); g.lineTo(26, 32); g.moveTo(16, 18); g.lineTo(28, 26); g.stroke(); } break;
    case 'fish': case 'fishc': g.fillStyle = c; g.beginPath(); g.ellipse(22, 24, 14, 8, 0, 0, 7); g.fill(); g.beginPath(); g.moveTo(34, 24); g.lineTo(44, 14); g.lineTo(44, 34); g.fill(); g.fillStyle = '#222'; g.beginPath(); g.arc(14, 22, 2, 0, 7); g.fill(); if (s === 'fishc') { g.strokeStyle = 'rgba(60,30,10,.6)'; g.lineWidth = 2; for (const x of [18, 24, 30]) { g.beginPath(); g.moveTo(x, 17); g.lineTo(x - 3, 31); g.stroke(); } } break;
    case 'egg': g.fillStyle = c; g.beginPath(); g.ellipse(24, 26, 11, 14, 0, 0, 7); g.fill(); g.fillStyle = 'rgba(255,255,255,.5)'; g.beginPath(); g.ellipse(20, 20, 3, 5, 0, 0, 7); g.fill(); break;
    case 'root': g.strokeStyle = c; g.lineWidth = 5; g.beginPath(); g.moveTo(24, 8); g.quadraticCurveTo(30, 24, 20, 40); g.stroke(); g.lineWidth = 2.5; g.beginPath(); g.moveTo(26, 20); g.lineTo(36, 30); g.moveTo(24, 28); g.lineTo(12, 34); g.stroke(); break;
    case 'axe': handle(); g.fillStyle = c; g.beginPath(); g.moveTo(28, 8); g.quadraticCurveTo(44, 10, 42, 24); g.lineTo(32, 18); g.closePath(); g.fill(); break;
    case 'pick': handle(); g.strokeStyle = c; g.lineWidth = 5; g.beginPath(); g.moveTo(18, 8); g.quadraticCurveTo(34, 6, 44, 20); g.stroke(); break;
    case 'spear': g.strokeStyle = '#7a5230'; g.lineWidth = 3.5; g.beginPath(); g.moveTo(8, 42); g.lineTo(34, 14); g.stroke(); g.fillStyle = c; g.beginPath(); g.moveTo(42, 6); g.lineTo(30, 14); g.lineTo(34, 18); g.closePath(); g.fill(); break;
    case 'knife': g.strokeStyle = '#7a5230'; g.lineWidth = 5; g.beginPath(); g.moveTo(10, 40); g.lineTo(20, 30); g.stroke(); g.fillStyle = c; g.beginPath(); g.moveTo(20, 30); g.lineTo(40, 8); g.lineTo(26, 32); g.closePath(); g.fill(); break;
    case 'torch': g.strokeStyle = '#7a5230'; g.lineWidth = 5; g.beginPath(); g.moveTo(18, 42); g.lineTo(28, 18); g.stroke(); g.fillStyle = c; g.beginPath(); g.moveTo(30, 4); g.quadraticCurveTo(40, 16, 30, 20); g.quadraticCurveTo(20, 16, 30, 4); g.fill(); g.fillStyle = '#fff2b0'; g.beginPath(); g.arc(29, 15, 3, 0, 7); g.fill(); break;
    case 'bandage': g.fillStyle = c; g.save(); g.translate(24, 24); g.rotate(-0.6); g.fillRect(-16, -7, 32, 14); g.fillStyle = '#c0452e'; g.fillRect(-3, -7, 6, 14); g.restore(); break;
    case 'mask': g.fillStyle = c; g.beginPath(); g.ellipse(24, 26, 15, 11, 0, 0, 7); g.fill(); g.fillStyle = '#333'; g.beginPath(); g.arc(24, 30, 5, 0, 7); g.fill(); g.strokeStyle = '#a89878'; g.lineWidth = 2; g.beginPath(); g.moveTo(9, 24); g.lineTo(4, 18); g.moveTo(39, 24); g.lineTo(44, 18); g.stroke(); break;
    case 'flare': g.fillStyle = c; g.fillRect(18, 14, 12, 28); g.fillStyle = '#f0e0c0'; g.fillRect(18, 22, 12, 4); g.fillStyle = '#ffcc40'; g.beginPath(); g.moveTo(24, 2); g.quadraticCurveTo(32, 10, 24, 14); g.quadraticCurveTo(16, 10, 24, 2); g.fill(); break;
    case 'cup': g.fillStyle = c; g.beginPath(); g.moveTo(10, 16); g.lineTo(38, 16); g.quadraticCurveTo(36, 40, 24, 40); g.quadraticCurveTo(12, 40, 10, 16); g.fill(); g.fillStyle = '#5aa8c8'; g.beginPath(); g.ellipse(24, 17, 13, 3, 0, 0, 7); g.fill(); break;
    case 'pot': g.fillStyle = c; g.beginPath(); g.moveTo(16, 10); g.lineTo(32, 10); g.lineTo(30, 16); g.quadraticCurveTo(44, 26, 32, 42); g.lineTo(16, 42); g.quadraticCurveTo(4, 26, 18, 16); g.closePath(); g.fill(); g.strokeStyle = shade(c, -0.15); g.lineWidth = 2; g.beginPath(); g.moveTo(10, 28); g.lineTo(38, 28); g.stroke(); break;
    case 'canteen': case 'canteen_broken': g.fillStyle = c; g.beginPath(); g.arc(24, 28, 14, 0, 7); g.fill(); g.fillStyle = '#555'; g.fillRect(20, 6, 8, 9); g.strokeStyle = '#d9cdb4'; g.lineWidth = 2.5; g.beginPath(); g.arc(24, 28, 9, 0, 7); g.stroke(); if (s === 'canteen_broken') { g.strokeStyle = '#2a1a10'; g.lineWidth = 2; g.beginPath(); g.moveTo(14, 20); g.lineTo(22, 30); g.lineTo(18, 38); g.stroke(); } break;
    default: blob(g, 24, 26, 14, c, 1);
  }
}

// ===== Desenho dos nós no mundo =====
function drawShadow(ctx, x, y, rx, ry) { ctx.fillStyle = 'rgba(0,0,0,.22)'; ctx.beginPath(); ctx.ellipse(x, y, rx, ry, 0, 0, 7); ctx.fill(); }
function drawNode(ctx, n, t, low) {
  const x = n.x, y = n.y, h = n.h || 0.5;
  if (n.dep) {
    if (NODES[n.type].deplete === 'toco') { drawShadow(ctx, x, y + 4, 9, 4); ctx.fillStyle = '#6a4424'; ctx.beginPath(); ctx.ellipse(x, y, 7, 5, 0, 0, 7); ctx.fill(); ctx.fillStyle = '#c9925a'; ctx.beginPath(); ctx.ellipse(x, y - 2, 6, 3.5, 0, 0, 7); ctx.fill(); }
    return;
  }
  switch (n.type) {
    case 'arvore': {
      drawShadow(ctx, x + 6, y + 6, 22, 9);
      ctx.fillStyle = '#5a3a22'; ctx.fillRect(x - 3.5, y - 18, 7, 22);
      const g = ['#2c5e2a', '#3a7334', '#4c8a40'];
      for (let k = 0; k < 3; k++) { ctx.fillStyle = g[k]; ctx.beginPath(); ctx.arc(x + (k - 1) * 5 * (h - 0.5) * 2, y - 26 - k * 5, 19 - k * 4, 0, 7); ctx.fill(); }
      ctx.fillStyle = 'rgba(255,255,220,.12)'; ctx.beginPath(); ctx.arc(x - 6, y - 38, 6, 0, 7); ctx.fill();
      break;
    }
    case 'arvore_mangue': {
      drawShadow(ctx, x + 4, y + 5, 18, 7);
      ctx.strokeStyle = '#5a4430'; ctx.lineWidth = 2;
      for (const dx of [-8, -3, 3, 8]) { ctx.beginPath(); ctx.moveTo(x, y - 10); ctx.quadraticCurveTo(x + dx, y - 6, x + dx * 1.2, y + 4); ctx.stroke(); }
      ctx.fillStyle = '#5a4430'; ctx.fillRect(x - 2.5, y - 20, 5, 12);
      ctx.fillStyle = '#3c6a40'; ctx.beginPath(); ctx.arc(x, y - 26, 14, 0, 7); ctx.fill(); ctx.fillStyle = '#4c7c4c'; ctx.beginPath(); ctx.arc(x - 4, y - 30, 8, 0, 7); ctx.fill();
      break;
    }
    case 'coqueiro': {
      drawShadow(ctx, x + 10, y + 4, 18, 6);
      ctx.strokeStyle = '#8a6a44'; ctx.lineWidth = 5; ctx.beginPath(); ctx.moveTo(x, y + 2); ctx.quadraticCurveTo(x + 10 * (h - 0.3), y - 18, x + 4, y - 40); ctx.stroke();
      const tx = x + 4, ty = y - 40, sw = Math.sin(t * 1.3 + x) * 0.08;
      ctx.strokeStyle = '#3f8a3a'; ctx.lineWidth = 4;
      for (let k = 0; k < 6; k++) { const a = (k / 6) * Math.PI * 2 + sw; ctx.beginPath(); ctx.moveTo(tx, ty); ctx.quadraticCurveTo(tx + Math.cos(a) * 14, ty + Math.sin(a) * 8 - 8, tx + Math.cos(a) * 24, ty + Math.sin(a) * 12 + 4); ctx.stroke(); }
      for (let k = 0; k < (n.coco || 0); k++) { ctx.fillStyle = '#6b4a2a'; ctx.beginPath(); ctx.arc(tx - 3 + k * 4, ty + 4, 3.2, 0, 7); ctx.fill(); }
      break;
    }
    case 'samambaia': { ctx.strokeStyle = '#3f8a3a'; ctx.lineWidth = 3; for (let k = 0; k < 6; k++) { const a = -Math.PI / 2 + (k - 2.5) * 0.4; ctx.beginPath(); ctx.moveTo(x, y + 4); ctx.quadraticCurveTo(x + Math.cos(a) * 8, y + Math.sin(a) * 8, x + Math.cos(a) * 15, y + Math.sin(a) * 13 + 4); ctx.stroke(); } break; }
    case 'cipoal': { ctx.fillStyle = '#5a3a22'; ctx.fillRect(x - 2, y - 18, 4, 22); ctx.strokeStyle = '#5c8a3a'; ctx.lineWidth = 2; for (const dx of [-7, 0, 7]) { ctx.beginPath(); ctx.moveTo(x, y - 18); ctx.quadraticCurveTo(x + dx, y - 8, x + dx * 0.6, y + 2); ctx.stroke(); } ctx.fillStyle = '#6e9a40'; ctx.beginPath(); ctx.arc(x, y - 18, 6, 0, 7); ctx.fill(); break; }
    case 'arbusto': case 'frutas': case 'erva': {
      const base = n.type === 'erva' ? '#6a9a5a' : n.type === 'frutas' ? '#3a7334' : '#8a8a4a';
      drawShadow(ctx, x, y + 4, 10, 4);
      ctx.fillStyle = base; ctx.beginPath(); ctx.arc(x - 5, y - 2, 7, 0, 7); ctx.arc(x + 5, y - 2, 7, 0, 7); ctx.arc(x, y - 7, 7, 0, 7); ctx.fill();
      if (n.type === 'frutas') { ctx.fillStyle = '#c0304a'; for (const [a, b] of [[-5, -4], [4, -1], [0, -9], [6, -7]]) { ctx.beginPath(); ctx.arc(x + a, y + b, 2.2, 0, 7); ctx.fill(); } }
      if (n.type === 'erva') { ctx.fillStyle = '#b57ad0'; for (const [a, b] of [[-4, -8], [4, -6]]) { ctx.beginPath(); ctx.arc(x + a, y + b, 2, 0, 7); ctx.fill(); } }
      if (n.type === 'arbusto') { ctx.strokeStyle = '#6a5a32'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(x - 6, y); ctx.lineTo(x - 10, y - 10); ctx.moveTo(x + 4, y); ctx.lineTo(x + 9, y - 11); ctx.stroke(); }
      break;
    }
    case 'graveto': ctx.strokeStyle = '#8a5a32'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(x - 8, y + 2); ctx.lineTo(x + 6, y - 3); ctx.moveTo(x - 4, y - 4); ctx.lineTo(x + 7, y + 4); ctx.stroke(); break;
    case 'pedra_solta': ctx.fillStyle = '#9a988f'; ctx.beginPath(); ctx.ellipse(x, y, 5, 3.5, 0.3, 0, 7); ctx.fill(); ctx.fillStyle = '#b4b2aa'; ctx.beginPath(); ctx.ellipse(x + 6, y + 3, 3, 2, 0, 0, 7); ctx.fill(); break;
    case 'conchas': ctx.fillStyle = '#f0d8c8'; ctx.beginPath(); ctx.arc(x, y, 3.5, Math.PI, 0); ctx.fill(); ctx.fillStyle = '#e8b8a8'; ctx.beginPath(); ctx.arc(x + 6, y + 3, 2.5, Math.PI, 0); ctx.fill(); break;
    case 'rocha': case 'rocha_vulc': case 'silex': case 'obsidiana': {
      const col = { rocha: '#8d8b84', rocha_vulc: '#5a4a46', silex: '#5d6b78', obsidiana: '#231d2c' }[n.type];
      drawShadow(ctx, x + 3, y + 5, 15, 6);
      ctx.fillStyle = col; ctx.beginPath(); ctx.moveTo(x - 14, y + 4); ctx.lineTo(x - 10, y - 10); ctx.lineTo(x + 2, y - 15); ctx.lineTo(x + 13, y - 6); ctx.lineTo(x + 14, y + 4); ctx.closePath(); ctx.fill();
      ctx.fillStyle = shade(col, 0.12); ctx.beginPath(); ctx.moveTo(x - 10, y - 10); ctx.lineTo(x + 2, y - 15); ctx.lineTo(x + 2, y - 4); ctx.closePath(); ctx.fill();
      if (n.type === 'silex') { ctx.fillStyle = '#a8c0d8'; ctx.fillRect(x - 4, y - 8, 3, 3); ctx.fillRect(x + 6, y - 3, 3, 3); }
      if (n.type === 'obsidiana') { ctx.strokeStyle = '#9a7ad8'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(x - 6, y - 8); ctx.lineTo(x + 4, y); ctx.stroke(); }
      break;
    }
    case 'enxofre': ctx.fillStyle = '#e8d23a'; for (const [a, b, r] of [[-5, 0, 5], [4, -2, 6], [0, 4, 4]]) { ctx.beginPath(); ctx.moveTo(x + a, y + b - r); ctx.lineTo(x + a + r, y + b); ctx.lineTo(x + a, y + b + r); ctx.lineTo(x + a - r, y + b); ctx.fill(); } break;
    case 'argila': ctx.fillStyle = '#a0603e'; ctx.beginPath(); ctx.ellipse(x, y, 13, 7, 0, 0, 7); ctx.fill(); ctx.fillStyle = '#b8744e'; ctx.beginPath(); ctx.ellipse(x - 3, y - 2, 6, 3, 0, 0, 7); ctx.fill(); break;
    case 'raizes': ctx.strokeStyle = '#8a6440'; ctx.lineWidth = 2.5; for (const d of [-8, -2, 5]) { ctx.beginPath(); ctx.moveTo(x + d, y - 8); ctx.quadraticCurveTo(x + d + 6, y, x + d - 2, y + 6); ctx.stroke(); } break;
    case 'ninho': ctx.strokeStyle = '#8a6a3a'; ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(x, y, 10, 6, 0, 0, 7); ctx.stroke(); ctx.fillStyle = '#efe6d2'; ctx.beginPath(); ctx.ellipse(x - 3, y - 1, 3, 3.8, 0, 0, 7); ctx.ellipse(x + 3, y, 3, 3.8, 0, 0, 7); ctx.fill(); break;
    case 'toca': ctx.fillStyle = '#7a6440'; ctx.beginPath(); ctx.ellipse(x, y, 7, 4, 0, 0, 7); ctx.fill(); ctx.fillStyle = '#d0603a'; const o = Math.sin(t * 2 + x) * 2; ctx.beginPath(); ctx.arc(x + 4 + o, y - 3, 3, 0, 7); ctx.fill(); break;
    case 'poca': if (!low) return; ctx.fillStyle = 'rgba(60,150,180,.85)'; ctx.beginPath(); ctx.ellipse(x, y, 14, 9, 0, 0, 7); ctx.fill(); ctx.fillStyle = 'rgba(20,50,60,.55)'; const fx = Math.sin(t * 1.7 + y) * 6; ctx.beginPath(); ctx.ellipse(x + fx, y, 5, 2, 0, 0, 7); ctx.fill(); break;
    case 'madeira_flut': if (!low) return; ctx.save(); ctx.translate(x, y); ctx.rotate(0.4); ctx.fillStyle = '#9a8a70'; ctx.fillRect(-14, -3.5, 28, 7); ctx.restore(); break;
    case 'caixa': case 'bau_navio': case 'bau': {
      drawShadow(ctx, x + 2, y + 6, 13, 4);
      ctx.fillStyle = n.type === 'bau_navio' ? '#6a4424' : '#8a6038'; ctx.fillRect(x - 11, y - 10, 22, 16);
      ctx.fillStyle = n.type === 'bau_navio' ? '#c0a040' : '#5a3a20'; ctx.fillRect(x - 11, y - 4, 22, 2.5); ctx.fillRect(x - 2, y - 6, 4, 5);
      if (n.type === 'caixa') { ctx.strokeStyle = '#5a3a20'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(x - 11, y - 10); ctx.lineTo(x + 11, y + 6); ctx.stroke(); }
      break;
    }
    case 'pagina': { const b = Math.sin(t * 3) * 1.5; ctx.fillStyle = 'rgba(255,240,180,.35)'; ctx.beginPath(); ctx.arc(x, y + b, 12, 0, 7); ctx.fill(); ctx.fillStyle = '#f4ecd4'; ctx.save(); ctx.translate(x, y + b); ctx.rotate(-0.2); ctx.fillRect(-6, -8, 12, 15); ctx.fillStyle = '#8a7a5a'; for (let k = 0; k < 4; k++) ctx.fillRect(-4, -5 + k * 3, 8, 1); ctx.restore(); break; }
    case 'mirante': drawShadow(ctx, x + 3, y + 6, 16, 6); ctx.fillStyle = '#7a786c'; ctx.beginPath(); ctx.moveTo(x - 15, y + 5); ctx.lineTo(x - 6, y - 24); ctx.lineTo(x + 6, y - 28); ctx.lineTo(x + 15, y + 5); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#c0452e'; ctx.fillRect(x + 4, y - 44, 2, 18); ctx.beginPath(); ctx.moveTo(x + 6, y - 44); ctx.lineTo(x + 16, y - 40); ctx.lineTo(x + 6, y - 36); ctx.fill(); break;
    case 'fonte_termal': for (let k = 0; k < 3; k++) { const a = ((t * 0.4 + k / 3) % 1); ctx.fillStyle = 'rgba(255,255,255,' + (0.35 * (1 - a)) + ')'; ctx.beginPath(); ctx.arc(x + (k - 1) * 8, y - a * 26, 5 + a * 6, 0, 7); ctx.fill(); } break;
    case 'naufragio': {
      ctx.save(); ctx.translate(x, y); ctx.rotate(-0.25);
      ctx.fillStyle = 'rgba(0,0,0,.2)'; ctx.beginPath(); ctx.ellipse(6, 8, 52, 16, 0, 0, 7); ctx.fill();
      ctx.fillStyle = '#5a3a22'; ctx.beginPath(); ctx.moveTo(-50, -6); ctx.quadraticCurveTo(0, 22, 52, -10); ctx.lineTo(40, -18); ctx.lineTo(-40, -16); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = '#3e2614'; ctx.lineWidth = 2; for (const k of [-24, -6, 12, 30]) { ctx.beginPath(); ctx.moveTo(k, -16); ctx.lineTo(k + 2, 6); ctx.stroke(); }
      ctx.fillStyle = '#6a4a2a'; ctx.fillRect(-4, -60, 5, 46); ctx.fillStyle = '#d9cdb4'; ctx.beginPath(); ctx.moveTo(1, -58); ctx.lineTo(26, -40); ctx.lineTo(1, -30); ctx.fill();
      ctx.restore(); break;
    }
    case 'fogueira': {
      drawShadow(ctx, x, y + 4, 13, 5);
      ctx.fillStyle = '#777'; for (let k = 0; k < 7; k++) { const a = (k / 7) * Math.PI * 2; ctx.beginPath(); ctx.arc(x + Math.cos(a) * 10, y + Math.sin(a) * 6, 3, 0, 7); ctx.fill(); }
      ctx.strokeStyle = '#5a3a22'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(x - 7, y + 2); ctx.lineTo(x + 7, y - 3); ctx.moveTo(x - 7, y - 3); ctx.lineTo(x + 7, y + 2); ctx.stroke();
      for (let k = 0; k < 3; k++) { const f = Math.sin(t * 9 + k * 2) * 2; ctx.fillStyle = ['#e85a2a', '#f0a030', '#ffe08a'][k]; ctx.beginPath(); ctx.moveTo(x - 7 + k * 2.5, y); ctx.quadraticCurveTo(x + f, y - 22 + k * 5, x + 7 - k * 2.5, y); ctx.fill(); }
      break;
    }
    case 'cama': ctx.fillStyle = '#4f8a40'; ctx.beginPath(); ctx.ellipse(x, y, 16, 9, 0, 0, 7); ctx.fill(); ctx.strokeStyle = '#3a7334'; ctx.lineWidth = 1.5; for (let k = -2; k <= 2; k++) { ctx.beginPath(); ctx.moveTo(x - 14, y + k * 3); ctx.lineTo(x + 14, y + k * 3 - 1); ctx.stroke(); } break;
    case 'abrigo': {
      drawShadow(ctx, x + 4, y + 6, 26, 8);
      ctx.strokeStyle = '#5a3a22'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(x - 22, y + 6); ctx.lineTo(x, y - 30); ctx.lineTo(x + 22, y + 6); ctx.stroke();
      ctx.fillStyle = '#4c8a40'; ctx.beginPath(); ctx.moveTo(x - 24, y + 2); ctx.lineTo(x, y - 32); ctx.lineTo(x + 24, y + 2); ctx.lineTo(x + 16, y + 2); ctx.lineTo(x, y - 20); ctx.lineTo(x - 16, y + 2); ctx.closePath(); ctx.fill();
      break;
    }
    case 'bancada': drawShadow(ctx, x + 2, y + 6, 18, 5); ctx.fillStyle = '#7a5230'; ctx.fillRect(x - 17, y - 12, 34, 9); ctx.fillStyle = '#5a3a22'; ctx.fillRect(x - 15, y - 3, 4, 9); ctx.fillRect(x + 11, y - 3, 4, 9); ctx.fillStyle = '#8d8b84'; ctx.fillRect(x - 8, y - 16, 7, 4); ctx.fillStyle = '#6a7a8a'; ctx.fillRect(x + 3, y - 15, 6, 3); break;
    case 'coletor': ctx.fillStyle = '#b06a45'; ctx.beginPath(); ctx.ellipse(x, y, 9, 7, 0, 0, 7); ctx.fill(); ctx.fillStyle = n.water ? '#5aa8c8' : '#5a3a22'; ctx.beginPath(); ctx.ellipse(x, y - 3, 7, 3, 0, 0, 7); ctx.fill(); ctx.fillStyle = 'rgba(79,154,70,.85)'; ctx.beginPath(); ctx.moveTo(x - 18, y - 16); ctx.lineTo(x + 18, y - 16); ctx.lineTo(x + 6, y - 6); ctx.lineTo(x - 6, y - 6); ctx.closePath(); ctx.fill(); break;
    case 'secador': ctx.strokeStyle = '#5a3a22'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(x - 14, y + 5); ctx.lineTo(x - 14, y - 18); ctx.moveTo(x + 14, y + 5); ctx.lineTo(x + 14, y - 18); ctx.moveTo(x - 15, y - 16); ctx.lineTo(x + 15, y - 16); ctx.stroke(); ctx.fillStyle = '#c08a4a'; for (const k of [-8, 0, 8]) { ctx.beginPath(); ctx.ellipse(x + k, y - 10, 2.5, 5, 0, 0, 7); ctx.fill(); } break;
    case 'forno': drawShadow(ctx, x + 2, y + 6, 17, 6); ctx.fillStyle = '#a0603e'; ctx.beginPath(); ctx.arc(x, y - 4, 16, Math.PI, 0); ctx.lineTo(x + 16, y + 4); ctx.lineTo(x - 16, y + 4); ctx.fill(); ctx.fillStyle = '#2a1a10'; ctx.beginPath(); ctx.arc(x, y + 2, 7, Math.PI, 0); ctx.fill(); ctx.fillStyle = 'rgba(255,140,40,' + (0.6 + Math.sin(t * 6) * 0.2) + ')'; ctx.beginPath(); ctx.arc(x, y + 2, 4.5, Math.PI, 0); ctx.fill(); break;
    case 'pilha': ctx.fillStyle = '#8a6038'; ctx.beginPath(); ctx.ellipse(x, y, 9, 5, 0, 0, 7); ctx.fill(); ctx.fillStyle = '#d9cdb4'; ctx.fillRect(x - 5, y - 6, 7, 5); ctx.fillStyle = '#8d8b84'; ctx.beginPath(); ctx.arc(x + 4, y - 3, 3, 0, 7); ctx.fill(); break;
  }
}

function drawPlayer(ctx, p, t, heldId) {
  const bob = p.moving ? Math.sin(t * 14) * 1.5 : 0;
  drawShadow(ctx, p.x, p.y + 6, 9, 4);
  const fx = p.face.x, fy = p.face.y;
  // pernas
  ctx.fillStyle = '#3a4a5a';
  const step = p.moving ? Math.sin(t * 14) * 3 : 0;
  ctx.fillRect(p.x - 5, p.y - 2 + step * 0.3, 4, 8); ctx.fillRect(p.x + 1, p.y - 2 - step * 0.3, 4, 8);
  // corpo
  ctx.fillStyle = '#d9cdb4'; ctx.beginPath(); ctx.ellipse(p.x, p.y - 8 + bob, 8, 9, 0, 0, 7); ctx.fill();
  ctx.fillStyle = '#c0452e'; ctx.fillRect(p.x - 8, p.y - 6 + bob, 16, 2.5);
  // ferramenta
  if (heldId && ITEMS[heldId]) {
    const swing = p.swing > 0 ? Math.sin((1 - p.swing / 0.35) * Math.PI) * 1.2 : 0;
    const ang = Math.atan2(fy, fx) + swing - 0.6;
    ctx.save(); ctx.translate(p.x + fx * 6, p.y - 8 + bob); ctx.rotate(ang);
    ctx.strokeStyle = '#7a5230'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(16, 0); ctx.stroke();
    ctx.fillStyle = ITEMS[heldId].ic[1]; ctx.fillRect(13, -3, 5, 6);
    ctx.restore();
  }
  // cabeça
  ctx.fillStyle = '#c8935e'; ctx.beginPath(); ctx.arc(p.x + fx * 1.5, p.y - 21 + bob, 6.5, 0, 7); ctx.fill();
  ctx.fillStyle = '#3a2414'; ctx.beginPath(); ctx.arc(p.x + fx * 1.5 - fx * 2, p.y - 23 + bob - (fy < 0 ? 0 : 1.5), 6.5, Math.PI, 0); ctx.fill();
  if (fy >= 0) { ctx.fillStyle = '#222'; ctx.fillRect(p.x + fx * 3 - 3, p.y - 21 + bob, 1.8, 1.8); ctx.fillRect(p.x + fx * 3 + 1.5, p.y - 21 + bob, 1.8, 1.8); }
  if (p.torch > 0) {
    ctx.strokeStyle = '#7a5230'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.moveTo(p.x - 9, p.y - 6); ctx.lineTo(p.x - 12, p.y - 20); ctx.stroke();
    const f = Math.sin(t * 12) * 1.5; ctx.fillStyle = '#f0a030'; ctx.beginPath(); ctx.moveTo(p.x - 16, p.y - 20); ctx.quadraticCurveTo(p.x - 12 + f, p.y - 34, p.x - 8, p.y - 20); ctx.fill();
  }
}

function drawEnemy(ctx, e, t) {
  if (e.kind === 'crab') {
    drawShadow(ctx, e.x, e.y + 4, 9, 3);
    const w = Math.sin(t * 16 + e.x) * 1.5;
    ctx.strokeStyle = '#a0301e'; ctx.lineWidth = 1.5;
    for (const s of [-1, 1]) for (let k = 0; k < 3; k++) { ctx.beginPath(); ctx.moveTo(e.x + s * 5, e.y + k * 2 - 2); ctx.lineTo(e.x + s * (10 + w), e.y + k * 3); ctx.stroke(); }
    ctx.fillStyle = e.hurt > 0 ? '#fff' : '#d0482a'; ctx.beginPath(); ctx.ellipse(e.x, e.y, 8, 5.5, 0, 0, 7); ctx.fill();
    ctx.fillStyle = '#e05a3a'; ctx.beginPath(); ctx.arc(e.x - 9, e.y - 5, 3.5, 0, 7); ctx.arc(e.x + 9, e.y - 5, 3.5, 0, 7); ctx.fill();
    ctx.fillStyle = '#111'; ctx.fillRect(e.x - 3, e.y - 6, 1.5, 1.5); ctx.fillRect(e.x + 1.5, e.y - 6, 1.5, 1.5);
  } else if (e.kind === 'snake') {
    ctx.strokeStyle = e.hurt > 0 ? '#fff' : '#4a7a2a'; ctx.lineWidth = 4.5; ctx.beginPath();
    for (let k = 0; k <= 10; k++) { const px = e.x - 14 + k * 2.8, py = e.y + Math.sin(k * 0.9 + t * (e.alert ? 6 : 1.5)) * 4; k ? ctx.lineTo(px, py) : ctx.moveTo(px, py); }
    ctx.stroke(); ctx.fillStyle = '#3a6a1a'; ctx.beginPath(); ctx.arc(e.x + 15, e.y + Math.sin(10 * 0.9 + t * (e.alert ? 6 : 1.5)) * 4, 4, 0, 7); ctx.fill();
  }
}
