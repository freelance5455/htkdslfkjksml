'use strict';
const cv=$('c'),ctx=cv.getContext('2d');
const nc=document.createElement('canvas'),nx=nc.getContext('2d');
let wxp=[],petP={x:0,y:0},flashT=0,RQ=[];

function resize(){
  DPR=Math.min(devicePixelRatio||1,QL().dpr);VW=cv.clientWidth;VH=cv.clientHeight;
  cv.width=Math.round(VW*DPR);cv.height=Math.round(VH*DPR);nc.width=Math.max(1,Math.round(cv.width*(mp&&mp.night?1:0)));nc.height=Math.max(1,Math.round(cv.height*(mp&&mp.night?1:0)));
  S=Math.max(.55,Math.min(VW,VH)/470)*set.zoom;
}

/* ---------- weather ---------- */
function wxInit(){
  wxp=[];const q=QL(),t=mp.wx;
  const n=Math.round(({rain:260,snow:150,blizzard:360,sand:150,ash:90,mist:0,clear:0}[t]||0)*q.wx);
  for(let i=0;i<n;i++)wxp.push({x:Math.random(),y:Math.random(),s:rnd(.6,1.4),r:Math.random()});
}
function drawWeather(){
  const t=mp.wx,q=QL();
  const W=VW,H=VH;
  if(t==='rain'){
    ctx.strokeStyle='rgba(190,210,235,.5)';ctx.lineWidth=1.2;ctx.beginPath();
    for(const p of wxp){p.y+=rdt*p.s*1.6;p.x-=rdt*.12*p.s;if(p.y>1){p.y=-.05;p.x=Math.random()*1.2}if(p.x<0)p.x+=1.1;const x=p.x*W,y=p.y*H;ctx.moveTo(x,y);ctx.lineTo(x-3,y+14*p.s)}
    ctx.stroke();ctx.fillStyle='rgba(20,30,50,.12)';ctx.fillRect(0,0,W,H);
  }else if(t==='snow'||t==='blizzard'){
    const bl=t==='blizzard';ctx.fillStyle='rgba(255,255,255,.85)';
    for(const p of wxp){p.y+=rdt*p.s*(bl?.45:.16);p.x+=rdt*(bl?.35:.03*Math.sin(p.r*20+time))*p.s;if(p.y>1){p.y=-.03;p.x=Math.random()}if(p.x>1.05)p.x=-.05;ctx.beginPath();ctx.arc(p.x*W,p.y*H,(bl?1.6:2.2)*p.s,0,TAU);ctx.fill()}
    if(bl){ctx.fillStyle='rgba(220,232,245,.22)';ctx.fillRect(0,0,W,H)}
  }else if(t==='sand'){
    ctx.strokeStyle='rgba(224,190,120,.35)';ctx.lineWidth=1.4;ctx.beginPath();
    for(const p of wxp){p.x+=rdt*p.s*.9;p.y+=rdt*.02;if(p.x>1.05){p.x=-.05;p.y=Math.random()}const x=p.x*W,y=p.y*H;ctx.moveTo(x,y);ctx.lineTo(x-18*p.s,y-1)}
    ctx.stroke();ctx.fillStyle='rgba(214,168,96,.16)';ctx.fillRect(0,0,W,H);
  }else if(t==='ash'){
    for(const p of wxp){p.y+=rdt*p.s*.07;p.x+=rdt*.04*Math.sin(p.r*9+time*.7);if(p.y>1){p.y=-.03;p.x=Math.random()}ctx.fillStyle=p.r>.8?'rgba(255,120,40,.8)':'rgba(30,26,30,.65)';ctx.beginPath();ctx.arc(p.x*W,p.y*H,1.5+p.s,0,TAU);ctx.fill()}
    ctx.fillStyle='rgba(60,30,30,.12)';ctx.fillRect(0,0,W,H);
  }else if(t==='mist'){
    for(let i=0;i<3;i++){const cx=((time*.01*(i+1)+i*.37)%1.4-.2)*W,cy=H*(.25+i*.28);const g=ctx.createRadialGradient(cx,cy,10,cx,cy,Math.max(W,H)*.5);g.addColorStop(0,'rgba(215,230,225,.2)');g.addColorStop(1,'rgba(215,230,225,0)');ctx.fillStyle=g;ctx.fillRect(0,0,W,H)}
    ctx.fillStyle='rgba(200,220,215,.1)';ctx.fillRect(0,0,W,H);
  }
}
function drawNight(f){
  const q=QL();
  if(!q.night){ctx.fillStyle='rgba(6,10,30,.5)';ctx.fillRect(0,0,VW,VH);return}
  nx.globalCompositeOperation='source-over';nx.setTransform(1,0,0,1,0,0);nx.clearRect(0,0,nc.width,nc.height);
  nx.fillStyle='rgba(4,8,28,.74)';nx.fillRect(0,0,nc.width,nc.height);
  nx.globalCompositeOperation='destination-out';
  const k=DPR*S;
  const L=(wx,wy,r,a)=>{const sx=(wx-cam.x)*k+nc.width/2,sy=(wy-cam.y)*k+nc.height/2,R=r*k;if(sx<-R||sy<-R||sx>nc.width+R||sy>nc.height+R)return;const g=nx.createRadialGradient(sx,sy,R*.1,sx,sy,R);g.addColorStop(0,`rgba(0,0,0,${a})`);g.addColorStop(1,'rgba(0,0,0,0)');nx.fillStyle=g;nx.beginPath();nx.arc(sx,sy,R,0,TAU);nx.fill()};
  L(f.x,f.y-18,340,.95);
  for(const p of players)if(p.alive&&p.flash>0)L(p.x,p.y-20,150,.8);
  for(const hs of houses)if(hs.x>cam.x-VW/S&&hs.x<cam.x+VW/S&&hs.y>cam.y-VH/S&&hs.y<cam.y+VH/S)L(hs.cx,hs.cy,Math.max(hs.w,hs.h)*.8,.55*hs.ra+.2);
  for(const fx of fxs)L(fx.x,fx.y,260,.9);
  ctx.setTransform(1,0,0,1,0,0);ctx.drawImage(nc,0,0);ctx.setTransform(DPR,0,0,DPR,0,0);
  if(mp.night){ctx.fillStyle='rgba(60,40,160,.07)';ctx.fillRect(0,0,VW,VH)}
}

/* ---------- world objects ---------- */
function drawTree(t){
  const c=ctx,x=t.x,y=t.y,cr=t.cr;
  c.fillStyle='rgba(0,0,0,.24)';c.beginPath();c.ellipse(x+cr*.3,y+3,cr*.9,cr*.35,0,0,TAU);c.fill();
  switch(t.ty){
    case'pine':c.fillStyle='#4a3524';c.fillRect(x-2.5,y-14,5,14);
      for(let i=0;i<3;i++){const w=cr*(1.05-i*.25),by=y-10-i*cr*.62;c.fillStyle=['#27503a','#2f6246','#3a7653'][i];c.beginPath();c.moveTo(x-w,by);c.lineTo(x,by-cr*1.05);c.lineTo(x+w,by);c.closePath();c.fill()}
      if(mp.det==='snow'){c.fillStyle='rgba(255,255,255,.8)';c.beginPath();c.moveTo(x-cr*.4,y-10-2*cr*.62-cr*.55);c.lineTo(x,y-10-2*cr*.62-cr*1.05);c.lineTo(x+cr*.4,y-10-2*cr*.62-cr*.55);c.fill()}break;
    case'palm':c.strokeStyle='#7a5a38';c.lineWidth=4;c.beginPath();c.moveTo(x,y);c.quadraticCurveTo(x+cr*.3,y-cr*.9,x+cr*.1,y-cr*1.7);c.stroke();
      c.strokeStyle='#2f8a46';c.lineWidth=3;const px=x+cr*.1,py=y-cr*1.7,sw=Math.sin(time*1.4+t.s*9)*3;
      for(let i=0;i<7;i++){const a=i/7*TAU;c.beginPath();c.moveTo(px,py);c.quadraticCurveTo(px+Math.cos(a)*cr*.7,py+Math.sin(a)*cr*.25-cr*.45,px+Math.cos(a)*cr*1.15+sw,py+Math.sin(a)*cr*.5+5);c.stroke()}break;
    case'cactus':c.fillStyle='#3f8a52';rr(c,x-4,y-cr*1.5,8,cr*1.5,4);c.fill();rr(c,x-12,y-cr*1.0,6,cr*.55,3);c.fill();rr(c,x+6,y-cr*1.2,6,cr*.6,3);c.fill();c.fillRect(x-12,y-cr*.5,8,4);c.fillRect(x+4,y-cr*.65,8,4);break;
    case'dead':c.strokeStyle='#5a4a3a';c.lineWidth=3.5;c.beginPath();c.moveTo(x,y);c.lineTo(x,y-cr*1.4);c.moveTo(x,y-cr*.8);c.lineTo(x-cr*.6,y-cr*1.4);c.moveTo(x,y-cr*1);c.lineTo(x+cr*.55,y-cr*1.6);c.stroke();break;
    default:{const acacia=t.ty==='acacia';
      c.fillStyle='#4a3524';c.fillRect(x-3,y-(acacia?34:22),6,acacia?34:22);
      const top=y-(acacia?36:30);
      if(acacia){c.fillStyle='#6d8a3a';c.beginPath();c.ellipse(x,top,cr*1.5,cr*.55,0,0,TAU);c.fill();c.fillStyle='#86a548';c.beginPath();c.ellipse(x-cr*.2,top-3,cr,cr*.35,0,0,TAU);c.fill()}
      else{const dk=mp.g[2];c.fillStyle='#2b5532';c.beginPath();c.arc(x,top,cr,0,TAU);c.fill();c.fillStyle='#3b7342';c.beginPath();c.arc(x-cr*.15,top-cr*.2,cr*.72,0,TAU);c.fill();c.fillStyle='#55955c';c.beginPath();c.arc(x-cr*.32,top-cr*.34,cr*.3,0,TAU);c.fill()}}
  }
}
function drawWall(w,f){
  const c=ctx,H=w.H;
  let a=1;
  if((w.fl|0)===(f.fl|0)){const hs=w.hs;
    if(hs&&f.x>hs.x&&f.x<hs.x+hs.w&&f.y>hs.y&&f.y<hs.y+hs.h){if(w.y+w.h>f.y+4)a=.4}
    else if(w.y+w.h>f.y&&w.x-12<f.x&&w.x+w.w+12>f.x&&w.y+w.h-H<f.y+4&&w.y-H<f.y)a=.4}
  if(a<1)c.globalAlpha=a;
  c.fillStyle=mp.wl[0];c.fillRect(w.x,w.y+w.h-H,w.w,H);
  c.fillStyle='rgba(0,0,0,.18)';c.fillRect(w.x,w.y+w.h-5,w.w,5);
  if(mp.urb&&w.w>70&&w.h<20){c.fillStyle='rgba(255,240,170,.55)';for(let x=w.x+14;x<w.x+w.w-14;x+=26)c.fillRect(x,w.y+w.h-H+8,10,H*.35)}
  c.fillStyle=mp.wl[1];c.fillRect(w.x,w.y-H,w.w,w.h);
  c.fillStyle='rgba(255,255,255,.14)';c.fillRect(w.x,w.y-H,w.w,2);
  c.globalAlpha=1;
}
function drawSlab(hs){
  const c=ctx;c.fillStyle=mp.fl;c.fillRect(hs.x,hs.y,hs.w,hs.h);
  c.fillStyle='rgba(30,20,5,.14)';for(let y=hs.y+18;y<hs.y+hs.h;y+=18)c.fillRect(hs.x,y,hs.w,2);
  c.fillStyle='rgba(0,0,0,.25)';c.fillRect(hs.x,hs.y+hs.h-3,hs.w,3);
}
function drawPads(hs,l){
  if(hs.nf<2)return;const c=ctx;
  for(let t=l-1;t<=l;t++){
    if(t<0||t>=hs.nf-1)continue;
    const s=stairPos(hs,t),up=t===l,col=up?'#6fb7ff':'#ffb347';
    c.fillStyle=up?'rgba(111,183,255,.3)':'rgba(255,179,71,.3)';c.fillRect(s.x-22,s.y-22,44,44);
    c.strokeStyle=col;c.lineWidth=2;c.strokeRect(s.x-22,s.y-22,44,44);
    c.globalAlpha=.5;c.beginPath();for(let i=-14;i<=14;i+=7){c.moveTo(s.x-20,s.y+i);c.lineTo(s.x+20,s.y+i)}c.stroke();c.globalAlpha=1;
    c.fillStyle='#fff';c.beginPath();
    if(up){c.moveTo(s.x,s.y-10);c.lineTo(s.x-9,s.y+8);c.lineTo(s.x+9,s.y+8)}else{c.moveTo(s.x,s.y+10);c.lineTo(s.x-9,s.y-8);c.lineTo(s.x+9,s.y-8)}
    c.fill();
  }
}
function drawHouse(hs,f,q){
  const c=ctx,Q=hs.q;Q.sort((a,b)=>a.y-b.y);
  for(let l=0;l<=hs.vf;l++){
    c.save();c.translate(0,-l*FH);
    if(l>0)drawSlab(hs);
    drawPads(hs,l);if(l===0)drawGates(hs);
    for(const r of Q)if(r.fl===l&&(r.k===0||l===hs.vf))drawItem(r,f,q);
    c.restore();
  }
}
function drawLoot(l,tm){
  const w=WP[l.t],tier=w?w.tier:0;
  const nl=NEWL[l.t];
  let col=w?RAR[Math.min(4,tier)][1]:l.t==='ammo'?'#ffd36b':l.t==='bandage'?'#ffffff':l.t==='medkit'?'#ff6b7d':l.t==='grenade'?'#8bd16b':l.t==='smoke'?'#b9c4cc':l.t==='gloo'?'#8fd8ff':'#6fb7ff';
  if(nl)col=nl.c;
  const c=ctx;c.save();c.translate(l.x,l.y);
  c.globalAlpha=.3+.14*Math.sin(tm*4+l.y);c.fillStyle=col;c.beginPath();c.arc(0,0,16,0,TAU);c.fill();c.globalAlpha=1;
  c.fillStyle='rgba(0,0,0,.4)';c.beginPath();c.arc(0,1,10.5,0,TAU);c.fill();
  if(nl){c.font='15px sans-serif';c.textAlign='center';c.fillStyle='#fff';c.fillText(nl.e,0,5.5)}
  else if(w){drawGunIcon(c,l.t,0,0,.14,null)}
  else if(l.t==='ammo'){c.fillStyle=col;for(let i=-1;i<=1;i++){rr(c,i*5-1.8,-6,3.6,12,1.8);c.fill()}}
  else if(l.t==='bandage'){c.rotate(-.6);c.fillStyle='#fff';rr(c,-8,-3.5,16,7,3.5);c.fill();c.fillStyle='#e23b52';c.fillRect(-1.2,-3.5,2.4,7)}
  else if(l.t==='medkit'){c.fillStyle='#fff';rr(c,-8,-6,16,12,2.5);c.fill();c.fillStyle='#e23b52';c.fillRect(-1.8,-4.5,3.6,9);c.fillRect(-4.5,-1.8,9,3.6)}
  else if(l.t==='grenade'){c.fillStyle='#4d7a3e';c.beginPath();c.ellipse(0,1.5,5.5,6.5,0,0,TAU);c.fill();c.fillStyle='#222';c.fillRect(-2,-7,4,3)}
  else if(l.t==='smoke'){c.fillStyle='#9aa6ae';rr(c,-4.5,-6,9,12,2);c.fill();c.fillStyle='#e8eef2';c.fillRect(-4.5,-2,9,3)}
  else if(l.t==='gloo'){c.fillStyle='#8fd8ff';rr(c,-7,-6,14,12,2);c.fill();c.fillStyle='rgba(255,255,255,.55)';c.fillRect(-5,-4,5,3)}
  else{c.fillStyle=col;c.beginPath();c.moveTo(0,-8);c.lineTo(7,-5);c.lineTo(6,3);c.lineTo(0,9);c.lineTo(-6,3);c.lineTo(-7,-5);c.closePath();c.fill();c.fillStyle='rgba(255,255,255,.4)';c.fillRect(-1,-5,2,10)}
  c.restore();
}
function drawGloo(w){
  const c=ctx;c.save();c.translate(w.x,w.y);c.rotate(w.a);
  c.fillStyle='rgba(0,0,0,.22)';c.fillRect(-w.hl+6,-w.ht+8,w.hl*2,w.ht*2);
  const H=34,fl=w.hit>0;
  for(let i=0;i<=H;i+=3){c.globalAlpha=.9;c.fillStyle=fl?'#ffffff':w.col;c.fillRect(-w.hl,-w.ht-i,w.hl*2,w.ht*2);c.globalAlpha=.25;c.fillStyle='#000';c.fillRect(-w.hl,w.ht-i-1,w.hl*2,1.5)}
  c.globalAlpha=.9;c.fillStyle=fl?'#fff':w.col;c.fillRect(-w.hl,-w.ht-H,w.hl*2,w.ht*2);
  c.fillStyle='rgba(255,255,255,.5)';c.fillRect(-w.hl+4,-w.ht-H+1,w.hl*1.2,2.5);
  c.globalAlpha=1;
  c.restore();
  const p=w.hp/260;if(p<1){c.fillStyle='rgba(0,0,0,.5)';c.fillRect(w.x-16,w.y-52,32,3);c.fillStyle='#8fd8ff';c.fillRect(w.x-16,w.y-52,32*p,3)}
}
function drawPlayer(p,f,q){
  const c=ctx,isMe=p===player,mate=p.team===player.team&&!isMe;
  const s=curS(p),op={mv:p.mv,gun:s.id,gcol:p.skin,flash:p.flash,hit:p.hitT,armor:p.armor,glow:q.glow>0};
  if(isMe||mate){c.strokeStyle=isMe?'rgba(255,255,255,.85)':'rgba(111,183,255,.9)';c.lineWidth=2;c.beginPath();c.ellipse(p.x,p.y+1,17,7,0,0,TAU);c.stroke()}
  drawPlayerBody(c,p,op,isMe);
  if(!isMe&&!(p.camo>0)){
    c.fillStyle='rgba(0,0,0,.55)';c.fillRect(p.x-15,p.y-62,30,4);
    c.fillStyle=mate?'#6fb7ff':p.hp>40?'#7bd88f':'#ff5d6c';c.fillRect(p.x-15,p.y-62,30*clamp(p.hp/100,0,1),4);
    c.font='600 10px Hind,system-ui,sans-serif';c.textAlign='center';c.fillStyle=mate?'#9fcfff':'rgba(255,255,255,.88)';c.fillText(p.name,p.x,p.y-67);
  }
  const prog=p.heal?p.heal.t/p.heal.T:p.rl>0?1-p.rl/(WP[(p.rls||s).id].rl):-1;
  if(prog>=0&&(isMe||mate)){c.strokeStyle=p.heal?'#7bd88f':'#ffd36b';c.lineWidth=3;c.beginPath();c.arc(p.x,p.y-72,8,-Math.PI/2,-Math.PI/2+TAU*prog);c.stroke();c.strokeStyle='rgba(255,255,255,.25)';c.lineWidth=1;c.beginPath();c.arc(p.x,p.y-72,8,0,TAU);c.stroke()}
}

/* ---------- main draw ---------- */
function draw(){
  const q=QL(),k=DPR*S;
  let f=player;if(!player.alive)f=specT||player;
  ctx.setTransform(DPR,0,0,DPR,0,0);ctx.fillStyle='#0d130e';ctx.fillRect(0,0,VW,VH);
  const sxk=shake>0?rnd(-1,1)*shake*7:0,syk=shake>0?rnd(-1,1)*shake*7:0;
  ctx.setTransform(k,0,0,k,DPR*VW/2-cam.x*k+sxk*DPR,DPR*VH/2-cam.y*k+syk*DPR);
  const vx0=cam.x-VW/2/S-70,vx1=cam.x+VW/2/S+70,vy0=cam.y-VH/2/S-70,vy1=cam.y+VH/2/S+130;
  ctx.imageSmoothingEnabled=true;ctx.drawImage(ground,0,0,MAP,MAP);
  ctx.strokeStyle='#0b0f0c';ctx.lineWidth=14;ctx.strokeRect(-7,-7,MAP+14,MAP+14);
  if(q.fx>=2){ctx.strokeStyle='rgba(255,255,255,.22)';ctx.lineWidth=2;for(const l of lakes){if(l.x+l.r<vx0||l.x-l.r>vx1||l.y+l.r<vy0||l.y-l.r>vy1)continue;for(let i=0;i<4;i++){const ph=(time*.25+i/4)%1;ctx.beginPath();ctx.arc(l.x,l.y,l.r*(.3+ph*.65),0,TAU);ctx.globalAlpha=1-ph;ctx.stroke()}ctx.globalAlpha=1}}
    if(q.shadow){ctx.fillStyle='rgba(0,0,0,.24)';for(const w of walls)if(!w.fl&&w.x<vx1&&w.x+w.w>vx0&&w.y<vy1&&w.y+w.h>vy0)ctx.fillRect(w.x+w.H*.35,w.y+w.H*.3,w.w,w.h)}
  RQ.length=0;
  for(const hs of houses){hs.q=null;if(hs.x<vx1&&hs.x+hs.w>vx0&&hs.y-hs.H*hs.nf<vy1&&hs.y+hs.h>vy0){hs.q=[];const fin=f.x>hs.x&&f.x<hs.x+hs.w&&f.y>hs.y&&f.y<hs.y+hs.h;hs.vf=hs.nf===1?0:fin?(f.fl|0):hs.nf-1;RQ.push({k:5,y:hs.y+hs.h,o:hs})}}
  const inV=(x,y)=>x>vx0&&x<vx1&&y>vy0&&y<vy1;
  const put=(k,x,y,o,fl)=>{const h=hsAt(x,y);if(h&&h.q)h.q.push({k,y,o,fl:fl|0});else RQ.push({k,y,o})};
  for(const w of walls)if(w.hs.q)w.hs.q.push({k:0,y:w.y+w.h,o:w,fl:w.fl|0});
  for(const t of trees)if(t.x>vx0-30&&t.x<vx1+30&&t.y>vy0&&t.y<vy1+60)RQ.push({k:1,y:t.y,o:t});
  for(const l of loot)if(inV(l.x,l.y))put(8,l.x,l.y,l,l.fl);
  for(const p of players)if(p.alive&&inV(p.x,p.y))put(2,p.x,p.y,p,p.fl);
  for(const w of glooW)put(3,w.x,w.y,w,w.fl);
  for(const n of nades)put(4,n.x,n.y,n,n.fl);
  for(const b of bullets)put(7,b.x,b.y,b,b.fl);
  if(player.alive&&player.pet){petP.x=lerp(petP.x||player.x-30,player.x-34,Math.min(1,rdt*3));petP.y=lerp(petP.y||player.y+10,player.y+14,Math.min(1,rdt*3));RQ.push({k:6,y:petP.y,o:petP})}
  RQ.sort((a,b)=>a.y-b.y);
  for(const r of RQ)drawItem(r,f,q);
  drawAbilityFx(f);
  if(player.alive&&state==='play'){AutoAimController.drawWorld(ctx);FireButtonDrag.drawWorld(ctx,player)}   // lock ring + drag aim line
  // smoke & explosions & sparks
  for(const s of smokes){ctx.globalAlpha=clamp(s.t/3,0,.62);for(let i=0;i<7;i++){const a=i/7*TAU+s.x,rr2=s.r*(.45+.35*Math.sin(i*2.1+time*.6));ctx.fillStyle=i&1?'#c8d0d6':'#aab4bb';ctx.beginPath();ctx.arc(s.x+Math.cos(a)*rr2*.55,s.y-18+Math.sin(a)*rr2*.35,rr2*.6,0,TAU);ctx.fill()}ctx.globalAlpha=1}
  for(const e of fxs){const a=e.t/.6;const g=ctx.createRadialGradient(e.x,e.y-8,4,e.x,e.y-8,130*Math.min(1,a*2.2+.15));g.addColorStop(0,`rgba(255,240,170,${1-a})`);g.addColorStop(.5,`rgba(255,120,40,${.7*(1-a)})`);g.addColorStop(1,'rgba(255,80,20,0)');ctx.fillStyle=g;ctx.beginPath();ctx.arc(e.x,e.y-8,130,0,TAU);ctx.fill()}
  for(const p of parts){ctx.globalAlpha=clamp(p.l*4,0,1);ctx.fillStyle=p.c;ctx.fillRect(p.x-1.5,p.y-p.z-1.5,3,3)}
  ctx.globalAlpha=1;
  // zone
  ctx.fillStyle='rgba(130,30,70,.34)';ctx.beginPath();ctx.rect(-4000,-4000,MAP+8000,MAP+8000);ctx.arc(z.cx,z.cy,z.r,0,TAU);ctx.fill('evenodd');
  ctx.strokeStyle='#ff5d6c';ctx.lineWidth=5;ctx.beginPath();ctx.arc(z.cx,z.cy,z.r,0,TAU);ctx.stroke();
  if(z.stage==='wait'){ctx.strokeStyle='rgba(255,255,255,.75)';ctx.lineWidth=4;ctx.setLineDash([16,12]);ctx.beginPath();ctx.arc(z.tx,z.ty,z.tr,0,TAU);ctx.stroke();ctx.setLineDash([])}
  // screen space
  ctx.setTransform(DPR,0,0,DPR,0,0);
  if(q.fx&&mp.tint){ctx.fillStyle=mp.tint;ctx.fillRect(0,0,VW,VH)}
  if(mp.night)drawNight(f);
  drawWeather();
  if(q.fx){const g=ctx.createRadialGradient(VW/2,VH/2,Math.min(VW,VH)*.35,VW/2,VH/2,Math.max(VW,VH)*.78);g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,'rgba(0,0,0,.38)');ctx.fillStyle=g;ctx.fillRect(0,0,VW,VH)}
  if(hurt>0){const g=ctx.createRadialGradient(VW/2,VH/2,Math.min(VW,VH)*.3,VW/2,VH/2,Math.max(VW,VH)*.72);g.addColorStop(0,'rgba(255,40,70,0)');g.addColorStop(1,`rgba(255,40,70,${clamp(hurt,0,.5)})`);ctx.fillStyle=g;ctx.fillRect(0,0,VW,VH)}
  drawMini(f);
  if(touchUIOn()&&state==='play'){
    const s=stk.mv,R=SR*joyK(),bx=s.id!==null?s.ox:joyBase()[0],by=s.id!==null?s.oy:joyBase()[1],jo=joyOp();
    ctx.strokeStyle=`rgba(255,255,255,${(s.id!==null?.45:.16)*jo})`;ctx.lineWidth=2;ctx.beginPath();ctx.arc(bx,by,R,0,TAU);ctx.stroke();
    ctx.fillStyle=`rgba(255,255,255,${(s.id!==null?.32:.1)*jo})`;ctx.beginPath();ctx.arc(s.id!==null?s.px:bx,s.id!==null?s.py:by,22*joyK(),0,TAU);ctx.fill();
  }
}
function drawMini(f){
  const m=Math.min(116,VW*.27),x=VW-m-14,y=14,k=m/MAP;
  ctx.save();ctx.fillStyle='rgba(20,28,24,.8)';rr(ctx,x-3,y-3,m+6,m+6,8);ctx.fill();rr(ctx,x,y,m,m,5);ctx.clip();
  ctx.drawImage(ground,x,y,m,m);
  ctx.fillStyle='#ff3b3b';for(const hs of houses)for(const g of hs.gates)ctx.fillRect(x+g.x*k-1.4,y+g.y*k-1.4,2.8,2.8);
  ctx.strokeStyle='#ff5d6c';ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(x+z.cx*k,y+z.cy*k,z.r*k,0,TAU);ctx.stroke();
  if(z.stage==='wait'){ctx.strokeStyle='#fff';ctx.beginPath();ctx.arc(x+z.tx*k,y+z.ty*k,z.tr*k,0,TAU);ctx.stroke()}
  if(player.alive&&(player.perk==='radar'||player.radarT>0)){ctx.fillStyle='#ff5d6c';for(const p of players)if(p.alive&&p.team!==player.team&&Math.hypot(p.x-player.x,p.y-player.y)<(player.radarT>0?9e9:420)){ctx.beginPath();ctx.arc(x+p.x*k,y+p.y*k,2.4,0,TAU);ctx.fill()}}
  ctx.fillStyle='#6fb7ff';for(const p of players)if(p.alive&&p.team===player.team&&p!==player){ctx.beginPath();ctx.arc(x+p.x*k,y+p.y*k,2.6,0,TAU);ctx.fill()}
  ctx.translate(x+f.x*k,y+f.y*k);ctx.rotate(f.ang);ctx.fillStyle='#ffb347';ctx.beginPath();ctx.moveTo(6,0);ctx.lineTo(-4,4);ctx.lineTo(-4,-4);ctx.closePath();ctx.fill();
  ctx.restore();
}

function drawItem(r,f,q){
  const o=r.o;
  switch(r.k){
      case 0:drawWall(o,f);break;
      case 1:{
        let fade=o.y>f.y&&Math.abs(o.x-f.x)<o.cr*1.1&&o.y-50-o.cr<f.y;
        if(fade)ctx.globalAlpha=.45;drawTree(o);ctx.globalAlpha=1;break}
      case 2:drawPlayer(o,f,q);break;
      case 3:drawGloo(o);break;
      case 4:{const a=Math.min(1,o.age/.7),z2=6+24*Math.sin(a*Math.PI);ctx.fillStyle='rgba(0,0,0,.3)';ctx.beginPath();ctx.ellipse(o.x,o.y,5,2.5,0,0,TAU);ctx.fill();ctx.fillStyle=o.type==='grenade'?'#4d7a3e':'#9aa6ae';ctx.beginPath();ctx.arc(o.x,o.y-z2,5,0,TAU);ctx.fill();ctx.fillStyle=o.fuse<.5&&((time*14|0)&1)?'#ff5d6c':'#222';ctx.fillRect(o.x-1.5,o.y-z2-7,3,3);break}
      case 5:drawHouse(o,f,q);break;
      case 8:drawLoot(o,time);break;
      case 6:drawPet(ctx,player.pet,o.x,o.y,1.15,time);break;
      case 7:{const m=Math.hypot(o.vx,o.vy)||1,L=Math.min(24,o.sp*.026);
        ctx.lineCap='round';ctx.lineWidth=2.6;ctx.strokeStyle=o.xb?'rgba(210,190,140,.95)':'rgba(255,232,150,.95)';ctx.beginPath();ctx.moveTo(o.x,o.y-24);ctx.lineTo(o.x-o.vx/m*L,o.y-24-o.vy/m*L);ctx.stroke();
        if(q.glow){ctx.globalCompositeOperation='lighter';ctx.fillStyle='rgba(255,190,80,.35)';ctx.beginPath();ctx.arc(o.x,o.y-24,5,0,TAU);ctx.fill();ctx.globalCompositeOperation='source-over'}break}
  }
}
