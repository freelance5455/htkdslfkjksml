"use strict";

const Night = (() => {
  const TRANSITIONS = {
    handover: ["action"],
    action: ["result", "transition"],
    result: ["transition"],
    transition: ["handover", "resolving"],
    resolving: ["done"],
    done: [],
  };

  function canTransition(from, to) {
    return Array.isArray(TRANSITIONS[from]) && TRANSITIONS[from].includes(to);
  }

  function create(aliveIds, number, shuffleFn) {
    return {
      number,
      order: shuffleFn(aliveIds),
      index: 0,
      phase: "handover",
      actions: {},
      jammed: [],
      outcome: null,
    };
  }

  function isSuspicious(role) {
    return role.team === "mafia" && role.id !== "lawyer";
  }

  function pick(list) {
    return list.map((p) => ({ id: p.id, name: p.name }));
  }

  // ما الذي يظهر للاعب في دوره؟
  function describeTurn(role, ctx) {
    const { player, alive, memory, jammed } = ctx;
    const others = alive.filter((p) => p.id !== player.id);

    if (jammed) {
      return {
        kind: "jammed",
        title: "🔮 سُحرت!",
        prompt: "تم تعطيل قدرتك هذه الليلة بتعويذة الساحر.",
        targets: [],
        allowSkip: false,
      };
    }

    let result;
    switch (role.id) {
      case "mafia":
        result = {
          kind: "kill",
          title: "🔪 اختر الضحية",
          prompt: "من تريد تصفيته الليلة؟ (القرار بأغلبية المافيا)",
          targets: pick(others.filter((p) => p.team !== "mafia")),
          allowSkip: false,
        };
        break;
      case "lone_killer":
        result = {
          kind: "kill",
          title: "🗡️ اختر الضحية",
          prompt: "من تريد تصفيته الليلة؟ أنت تعمل وحدك.",
          targets: pick(others),
          allowSkip: false,
        };
        break;
      case "detective":
        result = {
          kind: "investigate",
          title: "🔍 اختر من تفحصه",
          prompt: "ستعرف إن كان مشبوهًا أم بريئًا.",
          targets: pick(others),
          allowSkip: false,
        };
        break;
      case "doctor":
        result = {
          kind: "protect",
          title: "🩺 اختر من تحميه",
          prompt: memory.doctorSelfUsed
            ? "استخدمت حماية نفسك من قبل، فاختر غيرك."
            : "يمكنك حماية نفسك مرة واحدة فقط في اللعبة.",
          targets: pick(memory.doctorSelfUsed ? others : alive),
          allowSkip: false,
        };
        break;
      case "guard":
        result = {
          kind: "guard",
          title: "🛡️ اختر من تحرسه",
          prompt: "إن هوجم من تحرسه فستموت بدلًا منه. لا يمكنك حراسة نفس الشخص ليلتين متتاليتين.",
          targets: pick(others.filter((p) => p.id !== memory.guardLastTarget)),
          allowSkip: false,
        };
        break;
      case "informant":
        if (!memory.informantUsed) {
          result = {
            kind: "inform",
            title: "🕵️ اختر من تكشف دوره",
            prompt: "لديك فرصة واحدة فقط في اللعبة.",
            targets: pick(others),
            allowSkip: true,
            skipLabel: "⏭️ سأحتفظ بفرصتي لاحقًا",
          };
        }
        break;
      case "witch":
        if (!memory.witchUsed) {
          result = {
            kind: "silence",
            title: "🔮 اختر من تسحره",
            prompt: "سيُمنع من التصويت نهارًا وتُعطَّل قدرته الليلة التالية. تعويذة واحدة فقط.",
            targets: pick(others),
            allowSkip: true,
            skipLabel: "⏭️ سأحتفظ بتعويذتي لاحقًا",
          };
        }
        break;
      default:
        break;
    }

    if (!result) {
      result = {
        kind: "decoy",
        title: "🌙 ليلة هادئة",
        prompt: "اختر من تشك فيه. اختيارك لا يؤثر على اللعبة، والهدف إخفاء من يملك قدرة.",
        targets: pick(others),
        allowSkip: false,
      };
    }

    if (result.kind !== "decoy" && result.targets.length === 0) {
      result.allowSkip = true;
    }
    return result;
  }

  // الهدف الأكثر تكرارًا، وعند التعادل يُختار عشوائيًا
  function plurality(values, randomInt) {
    if (values.length === 0) return null;
    const counts = new Map();
    values.forEach((v) => counts.set(v, (counts.get(v) || 0) + 1));
    const max = Math.max(...counts.values());
    const top = [...counts.entries()].filter((entry) => entry[1] === max).map((entry) => entry[0]);
    return top[randomInt(top.length)];
  }

  // حسم نتيجة الليل
  function resolve(night, randomInt) {
    const actions = Object.values(night.actions);

    const mafiaVotes = actions
      .filter((a) => a.kind === "kill" && a.roleId === "mafia" && a.target !== null)
      .map((a) => a.target);

    const attacks = [];
    const mafiaTarget = plurality(mafiaVotes, randomInt);
    if (mafiaTarget !== null) attacks.push(mafiaTarget);

    actions
      .filter((a) => a.kind === "kill" && a.roleId === "lone_killer" && a.target !== null)
      .forEach((a) => attacks.push(a.target));

    const protectedIds = actions
      .filter((a) => a.kind === "protect" && a.target !== null)
      .map((a) => a.target);
    const guard = actions.find((a) => a.kind === "guard" && a.target !== null) || null;
    const witch = actions.find((a) => a.kind === "silence" && a.target !== null) || null;

    const deaths = [];
    attacks.forEach((targetId) => {
      let victim = targetId;
      if (guard && guard.target === victim) victim = guard.actorId;
      if (protectedIds.includes(victim)) return;
      if (!deaths.includes(victim)) deaths.push(victim);
    });

    return {
      deaths,
      guardTarget: guard ? guard.target : null,
      silencedId: witch ? witch.target : null,
    };
  }

  return { TRANSITIONS, canTransition, create, describeTurn, plurality, resolve, isSuspicious };
})();