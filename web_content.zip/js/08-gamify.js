/* انگیزه: مدال‌ها (سطح‌بندی)، لیگ بر پایه‌ی امتیاز، کاپ هفتگی. */
(function () {
  'use strict';
  var App = (window.App = window.App || {});
  var u = App.u;
  var st = App.study;
  var gm = (App.gamify = {});
  var S = function () { return App.S; };

  gm.TIERS = ['🥉 برنز', '🥈 نقره', '🥇 طلا', '💎 الماس'];
  gm.LEAGUES = [['برنزی', '🥉', 0], ['نقره‌ای', '🥈', 1000], ['طلایی', '🥇', 3000], ['پلاتینیوم', '💠', 7000], ['الماس', '💎', 15000], ['قهرمان', '👑', 30000]];

  function studyMin() { return u.sum(S().logs.filter(st.isStudy), function (l) { return l.m; }); }
  function classMin() { return u.sum(S().logs.filter(function (l) { return !st.isStudy(l); }), function (l) { return l.m; }); }
  function adhDays() {
    return Object.keys(S().wd || {}).filter(function (d) { var a = App.plan.adh(d); return a && a.p >= 80; }).length;
  }
  gm.MEDALS = [
    { i: '⏱', n: 'ساعت مطالعه', v: function () { return studyMin() / 60; }, t: [10, 50, 150, 400], u: 'ساعت' },
    { i: '📝', n: 'تست‌زن', v: function () { return u.sum(S().logs, function (l) { return l.t; }); }, t: [100, 500, 1500, 4000], u: 'تست' },
    { i: '🔥', n: 'استمرار', v: function () { return st.longestStreak(); }, t: [3, 7, 21, 60], u: 'روز پیاپی' },
    { i: '🏫', n: 'کلاس‌رو', v: function () { return classMin() / 60; }, t: [5, 20, 60, 150], u: 'ساعت کلاس' },
    { i: '🧪', n: 'آزمون‌باز', v: function () { return S().exams.length; }, t: [1, 5, 12, 25], u: 'آزمون' },
    { i: '📈', n: 'درصد آزمون', v: function () { return Math.max.apply(null, [0].concat(S().exams.map(function (e) { return e.p; }))); }, t: [40, 60, 75, 90], u: 'درصد (بهترین آزمون)' },
    { i: '🎯', n: 'ضعف‌شکن', v: function () { return S().wk.filter(function (x) { return x.ok; }).length; }, t: [1, 3, 7, 15], u: 'ضعف رفع‌شده' },
    { i: '📌', n: 'جبران‌گر', v: function () { return S().bl.filter(function (x) { return x.ok; }).length; }, t: [1, 5, 12, 30], u: 'عقب‌افتادگی جبران‌شده' },
    { i: '✅', n: 'هدف‌رسان', v: function () { return st.goalDays(); }, t: [3, 10, 30, 80], u: 'روز رسیدن به هدف' },
    { i: '📋', n: 'گزارش‌دهنده', v: function () { return Object.keys(S().ci || {}).length; }, t: [3, 10, 30, 80], u: 'گزارش روزانه' },
    { i: '📓', n: 'دفترنویس', v: function () { return S().jr.length; }, t: [3, 10, 30, 80], u: 'یادداشت' },
    { i: '📅', n: 'پایبند به برنامه', v: adhDays, t: [3, 10, 30, 80], u: 'روز با ۸۰٪ پایبندی' }
  ];
  gm.MEDALS.forEach(function (m, k) { m.id = 'm' + k; });
  gm.tierOf = function (m) {
    var v = m.v(), k = -1;
    m.t.forEach(function (x, i) { if (v >= x) k = i; });
    return k;
  };
  gm.xp = function () {
    return Math.round(studyMin() / 6 + u.sum(S().logs, function (l) { return l.t; }) + classMin() / 12 + S().exams.length * 50 +
      S().wk.filter(function (x) { return x.ok; }).length * 100 + S().bl.filter(function (x) { return x.ok; }).length * 30 +
      st.goalDays() * 40 + S().jr.length * 5 + Object.keys(S().ci || {}).length * 15 + st.longestStreak() * 20);
  };
  gm.league = function () {
    var x = gm.xp(), i = 0;
    gm.LEAGUES.forEach(function (l, k) { if (x >= l[2]) i = k; });
    var nx = gm.LEAGUES[i + 1];
    return { x: x, i: i, name: gm.LEAGUES[i][0], ic: gm.LEAGUES[i][1], next: nx ? nx[2] : null, pct: nx ? Math.round((x - gm.LEAGUES[i][2]) / (nx[2] - gm.LEAGUES[i][2]) * 100) : 100 };
  };
  // کاپ هفتگی: هفته از شنبه شروع می‌شود
  gm.weekCups = function (n) {
    var out = [], t = new Date(), dss = (t.getDay() + 1) % 7;
    for (var k = 0; k < n; k++) {
      var s0 = new Date(t); s0.setDate(t.getDate() - dss - 7 * k);
      var e0 = new Date(s0); e0.setDate(s0.getDate() + 6);
      var si = u.iso(s0), ei = u.iso(e0);
      var m = u.sum(S().logs.filter(function (l) { return st.isStudy(l) && l.d >= si && l.d <= ei; }), function (l) { return l.m; });
      var r = m / (S().goal * 7);
      out.push({ s: si, m: m, r: r, c: r >= 1 ? '🥇' : r >= 0.75 ? '🥈' : r >= 0.5 ? '🥉' : '', cur: k === 0 });
    }
    return out;
  };
  gm.nearMedal = function () {
    var best = null, br = 0;
    gm.MEDALS.forEach(function (m) {
      var k = gm.tierOf(m), nx = m.t[k + 1];
      if (nx == null) return;
      var v = +m.v(), r = v / nx;
      if (r >= 0.7 && r < 1 && r > br) { br = r; best = { m: m, k: k, nx: nx, v: v }; }
    });
    return best ? 'نزدیک مدال ' + gm.TIERS[best.k + 1] + ' «' + best.m.n + '» هستی: ' + u.fa(Math.ceil(best.nx - best.v)) + ' ' + best.m.u + ' مانده 🏅' : '';
  };
  // اعلان ارتقای مدال یا لیگ (بعد از هر رندر)
  gm.check = function () {
    var cur = {};
    gm.MEDALS.forEach(function (m) { cur[m.id] = gm.tierOf(m); });
    var L = gm.league();
    if (!S().md) { S().md = cur; S().lg = L.i; return []; }
    var up = [];
    gm.MEDALS.forEach(function (m) {
      var prev = S().md[m.id] == null ? -1 : S().md[m.id];
      if (cur[m.id] > prev) up.push(m.i + ' ' + m.n + ' — ' + gm.TIERS[cur[m.id]]);
    });
    if (S().lg != null && L.i > S().lg) up.push('🏆 ارتقا به لیگ ' + L.name + ' ' + L.ic);
    var changed = up.length || S().lg !== L.i || gm.MEDALS.some(function (m) { return cur[m.id] !== S().md[m.id]; });
    S().md = cur;
    S().lg = L.i;
    return changed ? up : [];
  };
})();
