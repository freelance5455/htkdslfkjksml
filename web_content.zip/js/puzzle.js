/* لعبة التركيب: اضغط على قطعتين لتبديلهما */
window.Puzzle = (function () {
  var board = document.getElementById('board');
  var msg = document.getElementById('puzzleMsg');
  var movesEl = document.getElementById('moves');
  var item, n = 3, order = [], picked = -1, moves = 0, solved = false;

  function shuffle() {
    order = [];
    for (var i = 0; i < n * n; i++) order.push(i);
    do {
      for (var j = order.length - 1; j > 0; j--) {
        var k = Math.floor(Math.random() * (j + 1)), t = order[j];
        order[j] = order[k]; order[k] = t;
      }
      // نتأكد أن أغلب القطع ليست في مكانها
    } while (order.filter(function (v, i) { return v === i; }).length > 1);
  }

  function draw() {
    var maxW = Math.min(window.innerWidth - 24, 640);
    var maxH = window.innerHeight * (window.innerHeight < 520 ? 0.55 : 0.52);
    var r = Math.min(maxW / item.w, maxH / item.h);
    var w = Math.floor(item.w * r / n), h = Math.floor(item.h * r / n);
    board.style.gridTemplateColumns = 'repeat(' + n + ',' + w + 'px)';
    board.style.gridAutoRows = h + 'px';
    board.classList.toggle('solved', solved);
    board.innerHTML = '';
    order.forEach(function (piece, pos) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'piece' + (pos === picked ? ' picked' : '');
      b.setAttribute('aria-label', 'قطعة ' + (pos + 1));
      b.style.backgroundImage = 'url("images/full/' + item.f + '")';
      b.style.backgroundSize = (w * n) + 'px ' + (h * n) + 'px';
      b.style.backgroundPosition = (-(piece % n) * w) + 'px ' + (-Math.floor(piece / n) * h) + 'px';
      b.addEventListener('click', function () { pick(pos); });
      board.appendChild(b);
    });
    movesEl.textContent = 'الحركات: ' + moves;
  }

  function pick(pos) {
    if (solved) return;
    if (picked < 0) { picked = pos; Sound.beep(67); }
    else if (picked === pos) picked = -1;
    else {
      var t = order[pos]; order[pos] = order[picked]; order[picked] = t;
      picked = -1; moves++; Sound.beep(74);
      if (order.every(function (v, i) { return v === i; })) win();
    }
    draw();
  }

  function win() {
    solved = true;
    msg.textContent = 'برافو! ركّبت الصورة في ' + moves + ' حركة 🎉';
    Sound.win();
    var box = document.getElementById('confetti');
    for (var i = 0; i < 40; i++) {
      var c = document.createElement('i');
      c.textContent = i % 3 ? '🧀' : '⭐';
      c.style.left = Math.random() * 100 + '%';
      c.style.animationDelay = Math.random() * 0.9 + 's';
      box.appendChild(c);
    }
    setTimeout(function () { box.innerHTML = ''; }, 3600);
  }

  function start(level) {
    n = level; picked = -1; moves = 0; solved = false;
    msg.textContent = 'اضغط على قطعتين لتبديل مكانهما';
    document.querySelectorAll('[data-level]').forEach(function (b) {
      b.classList.toggle('on', Number(b.dataset.level) === n);
    });
    shuffle(); draw();
  }

  document.querySelectorAll('[data-level]').forEach(function (b) {
    b.addEventListener('click', function () { start(Number(b.dataset.level)); });
  });
  window.addEventListener('resize', function () { if (Screens.top() === 'puzzle') draw(); });

  return {
    open: function (it) {
      item = it;
      document.getElementById('hint').src = 'images/full/' + it.f;
      Screens.open('puzzle', function () { document.getElementById('confetti').innerHTML = ''; });
      start(n);
    }
  };
})();
