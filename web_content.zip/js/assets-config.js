// Every asset the game loads (paths are relative to index.html). Replace a file in assets/ to change a model or texture.
const ASSETS={
 "farmer": "assets/models/farmer.glb",
 "zombie": "assets/models/zombie.glb",
 "brute": "assets/models/brute.glb",
 "dog": "assets/models/dog.glb",
 "car": "assets/models/car.glb",
 "ztex": "assets/textures/zombie_atlas.png",
 "brtex": "assets/textures/brute_atlas.png",
 "dogtex": "assets/textures/dog_atlas.png",
 "cartex": "assets/textures/car_atlas.png",
 "world": {
  "defs": {
   "CommonTree_3": [
    0.5,
    0.6,
    2,
    0.9,
    1.25
   ],
   "Pine_1": [
    0.55,
    0.6,
    2,
    0.9,
    1.25
   ],
   "Pine_5": [
    0.5,
    0.5,
    2,
    0.9,
    1.2
   ],
   "DeadTree_3": [
    0.5,
    0.2,
    2,
    0.7,
    1.0
   ],
   "Bush_Common": [
    0,
    1.2,
    2,
    0.8,
    1.2
   ],
   "Bush_Common_Flowers": [
    0,
    0.9,
    2,
    0.8,
    1.1
   ],
   "Fern_1": [
    0,
    1.6,
    1,
    0.3,
    0.5
   ],
   "Plant_1_Big": [
    0,
    0.8,
    1,
    0.5,
    0.8
   ],
   "Flower_3_Group": [
    0,
    3.1,
    1,
    0.5,
    0.75
   ],
   "Flower_4_Group": [
    0,
    2.4,
    1,
    0.45,
    0.7
   ],
   "Mushroom_Common": [
    0,
    1,
    1,
    1,
    1.8
   ],
   "Rock_Medium_1": [
    1.1,
    0.7,
    2,
    0.6,
    1.3
   ],
   "Rock_Medium_2": [
    1.0,
    0.6,
    2,
    0.6,
    1.2
   ],
   "Rock_Medium_3": [
    1.2,
    0.5,
    2,
    0.6,
    1.2
   ],
   "Pebble_Round_1": [
    0,
    3,
    1,
    1.5,
    2.5
   ],
   "RockPath_Square_Small_2": [
    0,
    0,
    1,
    1,
    1
   ],
   "RockPath_Round_Small_1": [
    0,
    0,
    1,
    1,
    1
   ]
  },
  "glb": {
   "CommonTree_3": "assets/world/CommonTree_3.glb",
   "Pine_1": "assets/world/Pine_1.glb",
   "Pine_5": "assets/world/Pine_5.glb",
   "DeadTree_3": "assets/world/DeadTree_3.glb",
   "Bush_Common": "assets/world/Bush_Common.glb",
   "Bush_Common_Flowers": "assets/world/Bush_Common_Flowers.glb",
   "Fern_1": "assets/world/Fern_1.glb",
   "Plant_1_Big": "assets/world/Plant_1_Big.glb",
   "Flower_3_Group": "assets/world/Flower_3_Group.glb",
   "Flower_4_Group": "assets/world/Flower_4_Group.glb",
   "Mushroom_Common": "assets/world/Mushroom_Common.glb",
   "Rock_Medium_1": "assets/world/Rock_Medium_1.glb",
   "Rock_Medium_2": "assets/world/Rock_Medium_2.glb",
   "Rock_Medium_3": "assets/world/Rock_Medium_3.glb",
   "Pebble_Round_1": "assets/world/Pebble_Round_1.glb",
   "RockPath_Square_Small_2": "assets/world/RockPath_Square_Small_2.glb",
   "RockPath_Round_Small_1": "assets/world/RockPath_Round_Small_1.glb"
  },
  "tex": {
   "Bark_DeadTree": "assets/textures/Bark_DeadTree.jpg",
   "Bark_NormalTree": "assets/textures/Bark_NormalTree.jpg",
   "Flowers": "assets/textures/Flowers.png",
   "Leaves": "assets/textures/Leaves.png",
   "Leaves_NormalTree": "assets/textures/Leaves_NormalTree.png",
   "Leaves_Pine": "assets/textures/Leaves_Pine.png",
   "Leaves_TwistedTree": "assets/textures/Leaves_TwistedTree.png",
   "Mushrooms": "assets/textures/Mushrooms.jpg",
   "PathRocks": "assets/textures/PathRocks.jpg",
   "Rocks": "assets/textures/Rocks.jpg"
  }
 }
};
