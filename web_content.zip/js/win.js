"use strict";

const Win = (() => {
  const RESULTS = {
    town: { title: "🏛️ فاز المواطنون!", text: "تم القضاء على كل المافيا والتهديدات." },
    mafia: { title: "🔪 فازت المافيا!", text: "سيطرت المافيا على المدينة." },
    lone_killer: { title: "🗡️ فاز القاتل المنفرد!", text: "بقي القاتل المنفرد وحيدًا في المدينة." },
    clown: { title: "🤡 فاز المهرج!", text: "نجح المهرج في دفعكم لاستبعاده!" },
    none: { title: "🕯️ لا ناجين", text: "سقط الجميع، ولا فائز في هذه اللعبة." },
  };

  function teamOf(player) {
    return Roles.get(player.roleId).team;
  }

  function build(winner, players) {
    let winners = [];
    if (winner === "town") winners = players.filter((p) => teamOf(p) === "town");
    else if (winner === "mafia") winners = players.filter((p) => teamOf(p) === "mafia");
    else if (winner === "lone_killer") winners = players.filter((p) => p.roleId === "lone_killer");
    else if (winner === "clown") winners = players.filter((p) => p.roleId === "clown");
    return {
      over: true,
      winner,
      winnerIds: winners.map((p) => p.id),
      title: RESULTS[winner].title,
      text: RESULTS[winner].text,
    };
  }

  // هل انتهت اللعبة؟ (الترتيب مهم لمنع أي فوز خاطئ)
  function check(players, flags) {
    const alive = players.filter((p) => p.alive);
    const mafiaAlive = alive.filter((p) => teamOf(p) === "mafia").length;
    const loneAlive = alive.filter((p) => p.roleId === "lone_killer").length;
    const others = alive.length - mafiaAlive;

    if (flags && flags.clownVotedOut) return build("clown", players);
    if (alive.length === 0) return build("none", players);
    if (mafiaAlive === 0 && loneAlive === 0) return build("town", players);
    if (mafiaAlive >= others) return build("mafia", players);
    if (mafiaAlive === 0 && loneAlive > 0 && alive.length <= 2) return build("lone_killer", players);
    return { over: false };
  }

  return { check };
})();