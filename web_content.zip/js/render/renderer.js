/* Renderer – kreslí celé herní pole na jeden canvas a převádí myš/dotyk na políčka.
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  var D = BD.render.draw, TT = BD.systems.towers.TYPES, TAU = D.TAU;

  function Renderer(canvas) {
    this.cv = canvas; this.ctx = null; this.cell = 32; this.dpr = 1; this.W = 0; this.H = 0;
    this.VW = 0; this.VH = 0; this.vx = 0; this.vy = 0; this.zoomed = false; this.big = false; this.fitCell = 32;
  }
  var P = Renderer.prototype;

  /* přizpůsobí velikost plátna prostoru (stage) a rozměrům hry; cell = px na buňku (1 věž = SUB×SUB buněk), +2 buňky okraj */
  var BIG_CELL = 14;      // když by se celé pole vešlo jen s buňkou menší než tohle, je mapa „velká“ a jde přiblížit
  var ZOOM_CELL = 28;     // velikost buňky v přiblíženém pohledu (1 věž = 2 buňky)
  P.fit = function (stage, game, aw, ah) {
    var availW = aw || (stage && stage.clientWidth), availH = ah || (stage && stage.clientHeight);
    if (!stage || !availW || !availH) return false;
    var pad = 20, ew = game.w + 2, eh = game.h + 2;
    this.dpr = window.devicePixelRatio || 1;
    this.fitCell = Math.max(4, Math.floor(Math.min((availW - pad) / ew, (availH - pad) / eh)));
    this.big = this.fitCell < BIG_CELL;
    var keepCx = this.W ? (this.vx + this.VW / 2) / this.W : 0.5, keepCy = this.H ? (this.vy + this.VH / 2) / this.H : 0.5;
    if (this.big && this.zoomed) this.cell = Math.max(this.fitCell, Math.min(ZOOM_CELL, Math.floor(4096 / (ew * this.dpr))));
    else { this.cell = this.fitCell; this.zoomed = this.zoomed && this.big; }
    this.W = this.cell * ew; this.H = this.cell * eh;
    this.VW = Math.min(this.W, Math.floor(availW - pad)); this.VH = Math.min(this.H, Math.floor(availH - pad));
    if (!(this.big && this.zoomed)) { this.VW = this.W; this.VH = this.H; }
    this.cv.width = Math.round(this.VW * this.dpr); this.cv.height = Math.round(this.VH * this.dpr);
    this.cv.style.width = this.VW + 'px'; this.cv.style.height = this.VH + 'px';
    this.setView(keepCx * this.W - this.VW / 2, keepCy * this.H - this.VH / 2);
    this.ctx = this.cv.getContext('2d');
    return true;
  };
  /* přiblížení (jen u velkých map) / celá mapa; volá se před fit */
  P.setZoom = function (on) { this.zoomed = !!on; };
  P.setView = function (x, y) {
    this.vx = Math.max(0, Math.min(this.W - this.VW, x)); this.vy = Math.max(0, Math.min(this.H - this.VH, y));
  };
  P.panBy = function (dx, dy) { if (this.zoomed) this.setView(this.vx + dx, this.vy + dy); };
  /* vystředí pohled na bod v buňkách pole (0..w, 0..h) */
  P.centerOn = function (x, y) { this.setView((x + 1) * this.cell - this.VW / 2, (y + 1) * this.cell - this.VH / 2); };
  /* viditelná část v souřadnicích 0..1 celé mapy */
  P.viewRect = function () { return { x: this.vx / this.W, y: this.vy / this.H, w: this.VW / this.W, h: this.VH / this.H }; };

  /* poloha ukazatele v buňkách pole (desetinná; mimo pole i záporná) */
  P.pointer = function (ev) {
    var r = this.cv.getBoundingClientRect();
    return { x: (ev.clientX - r.left + this.vx) / this.cell - 1, y: (ev.clientY - r.top + this.vy) / this.cell - 1 };
  };
  /* { cell:[x,y] buňka pod ukazatelem, pos:[x,y] levý horní roh věže vystředěné na ukazatel } nebo null mimo pole */
  P.cellOf = function (ev, game) {
    var q = this.pointer(ev), x = Math.floor(q.x), y = Math.floor(q.y), n = game.sub;
    if (x < 0 || y < 0 || x >= game.w || y >= game.h) return null;
    var px = BD.util.clamp(Math.round(q.x - n / 2), 0, game.w - n), py = BD.util.clamp(Math.round(q.y - n / 2), 0, game.h - n);
    return { cell: [x, y], pos: [px, py] };
  };

  function label(ctx, txt, x, y, color, size) {
    ctx.font = '600 ' + size + 'px Sora, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
    ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(0,0,0,.7)'; ctx.strokeText(txt, x, y);
    ctx.fillStyle = color; ctx.fillText(txt, x, y);
  }

  /* o = { selId, hover:{cell,pos}, shop, show:{range,path,grid} } */
  P.draw = function (game, o) {
    var ctx = this.ctx; if (!ctx) return;
    var c = this.cell, show = o.show, U = c * game.sub;
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    ctx.clearRect(0, 0, this.VW, this.VH);
    var F = BD.render.field;
    if (this._lvRef !== game.level) { this._lvRef = game.level; this._lvId = (this._lvId || 0) + 1; }
    var layer = F.layer(this, this._lvId + '|' + c + '|' + this.dpr + '|' + (show.grid ? 1 : 0), this.W, this.H, this.dpr,
      function (cx) { F.base(cx, game.level, c, { grid: show.grid, gates: false }); });          // statická vrstva: podlaha, zdi, skály (brány jsou jen díry ve zdi)
    ctx.drawImage(layer, this.vx * this.dpr, this.vy * this.dpr, this.VW * this.dpr, this.VH * this.dpr, 0, 0, this.VW, this.VH);
    ctx.save(); ctx.translate(c - this.vx, c - this.vy);
    F.orbs(ctx, game.level, c);
    if (show.path) {
      ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.lineWidth = Math.max(1.5, U * 0.1);
      ctx.strokeStyle = 'rgba(240,191,76,.5)'; ctx.setLineDash([U * 0.12, U * 0.22]);
      game.level.spawns.forEach(function (s, k) {
        var pth = game.previewPath(k); if (pth.length < 2) return;
        ctx.beginPath(); pth.forEach(function (q, n) { var px = (q[0] + .5) * c, py = (q[1] + .5) * c; n ? ctx.lineTo(px, py) : ctx.moveTo(px, py); }); ctx.stroke();
      });
      ctx.restore();
    }

    var st = o.selId ? game.byId(o.selId) : null;
    if (st && show.range) {
      ctx.beginPath(); ctx.arc((st.x + st.size / 2) * c, (st.y + st.size / 2) * c, st.s.range * c, 0, TAU);
      ctx.fillStyle = 'rgba(240,191,76,.07)'; ctx.fill(); ctx.strokeStyle = 'rgba(240,191,76,.5)'; ctx.lineWidth = 1.5; ctx.stroke();
    }
    game.towers.forEach(function (t) { D.tower(ctx, t, c); });
    if (st) {
      D.rr(ctx, st.x * c + 1, st.y * c + 1, st.size * c - 2, st.size * c - 2, U * 0.25); ctx.strokeStyle = '#f0bf4c'; ctx.lineWidth = 2.5; ctx.stroke();
      var m = game.findMerge(st);
      if (m) {
        var pulse = 0.55 + 0.45 * Math.sin(performance.now() / 220);
        ctx.save(); ctx.setLineDash([8, 6]); ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(240,191,76,' + pulse + ')';
        D.rr(ctx, m.x * c - 2, m.y * c - 2, m.size * c + 4, m.size * c + 4, U * 0.3); ctx.stroke(); ctx.restore();
      }
    }
    /* náhled stavby: dosah + barevný čtverec + délka cesty před → po (ve věžích) */
    var hv = o.hover;
    if (hv && o.shop && !game.towerAt(hv.cell[0], hv.cell[1])) {
      var T = TT[o.shop], ck = game.canPlace(o.shop, hv.pos[0], hv.pos[1]), n = game.sub;
      var hx = hv.pos[0] * c, hy = hv.pos[1] * c, S = n * c, rng = T.base && T.base.range ? T.base.range * n : 0;
      if (show.range && rng) { ctx.beginPath(); ctx.arc(hx + S / 2, hy + S / 2, rng * c, 0, TAU); ctx.fillStyle = 'rgba(255,255,255,.05)'; ctx.fill(); ctx.strokeStyle = 'rgba(255,255,255,.3)'; ctx.lineWidth = 1; ctx.stroke(); }
      D.rr(ctx, hx + 1, hy + 1, S - 2, S - 2, S * 0.22); ctx.fillStyle = ck.ok ? D.hexA(T.color, 0.55) : 'rgba(229,107,97,.55)'; ctx.fill();
      ctx.strokeStyle = ck.ok ? T.color : '#e56b61'; ctx.lineWidth = 2; ctx.stroke();
      var ty = hy > U * 1.2 ? hy - 4 : hy + S + U * 0.5, fs = Math.max(11, U * 0.34);
      if (ck.ok && show.pathLen) {
        var after = game.pathLensIfBlocked(hv.pos[0], hv.pos[1])[0], before = game.pathLen(0), f = function (v) { return Math.round(v / n * 10) / 10; };
        label(ctx, f(before) + ' → ' + f(after), hx + S / 2, ty, after > before ? '#f0bf4c' : '#e9e5db', fs);
      } else if (!ck.ok) label(ctx, ck.reason, hx + S / 2, ty, '#e56b61', fs);
    }
    game.enemies.forEach(function (e) { D.enemy(ctx, e, c); });
    game.shots.forEach(function (s) { D.shot(ctx, s, c); });
    game.fx.forEach(function (f) { D.fx(ctx, f, c); });
    ctx.restore();
  };

  /* minimapka: celá mapa zmenšená + věže, nepřátelé a rámeček právě viditelné části; cv = canvas minimapky */
  P.drawMini = function (cv, game) {
    if (!this._layer) return;
    var ctx = cv.getContext('2d'), w = cv.clientWidth, h = cv.clientHeight, dpr = this.dpr;
    if (cv.width !== Math.round(w * dpr)) { cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr); }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, w, h);
    ctx.drawImage(this._layer, 0, 0, w, h);
    var k = w / this.W, c = this.cell * k;                                   // px minimapky na buňku
    ctx.save(); ctx.translate(c, c);
    game.towers.forEach(function (t) { ctx.fillStyle = TT[t.type].color; ctx.fillRect(t.x * c, t.y * c, Math.max(2, t.size * c), Math.max(2, t.size * c)); });
    ctx.fillStyle = '#ff7a9c';
    game.enemies.forEach(function (e) { ctx.fillRect(e.x * c - 1, e.y * c - 1, 2.5, 2.5); });
    ctx.restore();
    var v = this.viewRect();
    ctx.lineWidth = 1.5; ctx.strokeStyle = '#f0bf4c'; ctx.fillStyle = 'rgba(240,191,76,.12)';
    ctx.fillRect(v.x * w, v.y * h, v.w * w, v.h * h); ctx.strokeRect(v.x * w + .75, v.y * h + .75, v.w * w - 1.5, v.h * h - 1.5);
  };

  BD.render.Renderer = Renderer;
})(window.BD);
