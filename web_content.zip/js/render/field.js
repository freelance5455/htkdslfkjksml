/* Field – společné kreslení hracího pole (podlaha, okraj s bránami, zdi, skály, cílová koule). Používá ho hra i editor.
   Plátno má rozměr (W+2)×(H+2) buněk: kolem pole je 1 buňka silný okraj, v něm jsou brány.
   Souřadnice pole (0,0) leží v plátně na (c,c) – po volání base() se pro kreslení nad polem dělá ctx.translate(c, c).
   Statická vrstva (podlaha, zdi, skály) se dá kreslit jednou do cache (layer), animovaná koule cíle se kreslí zvlášť.
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  var D = BD.render.draw, G = BD.systems.grid, TAU = Math.PI * 2;
  var WALL = '#2a3a44', LIT = '#6f8c9e', DARK = '#476071', FLOOR_A = '#1b2a25', FLOOR_B = '#172420', ROCK = '#4a5368';

  function size(level) { return { W: level.w * BD.SUB, H: level.h * BD.SUB }; }

  /* ---------- skály: souvislé skupiny se slévají do jednoho kamene ---------- */
  /* vrátí obdélníky [l,t,r,b,rtl,rtr,rbr,rbl,topFree,botFree] v buňkách; buňky se stejným číslem skupiny (3. prvek) a společnou hranou splynou */
  function rockRects(rocks, pad, rad) {
    var grp = {}, i, out = [];
    for (i = 0; i < rocks.length; i++) if (rocks[i][2] > 0) grp[rocks[i][0] + ',' + rocks[i][1]] = rocks[i][2];
    function same(r, dx, dy) { var g = r[2]; return g > 0 && grp[(r[0] + dx) + ',' + (r[1] + dy)] === g; }
    for (i = 0; i < rocks.length; i++) {
      var r = rocks[i], x = r[0], y = r[1];
      var N = same(r, 0, -1), E = same(r, 1, 0), S = same(r, 0, 1), W = same(r, -1, 0);
      out.push([x + (W ? 0 : pad), y + (N ? 0 : pad), x + 1 - (E ? 0 : pad), y + 1 - (S ? 0 : pad),
        !N && !W ? rad : 0, !N && !E ? rad : 0, !S && !E ? rad : 0, !S && !W ? rad : 0, !N, !S]);
    }
    return out;
  }
  function roundRectPath(ctx, l, t, r, b, tl, tr, br, bl) {
    ctx.moveTo(l + tl, t); ctx.lineTo(r - tr, t); if (tr) ctx.arcTo(r, t, r, t + tr, tr); else ctx.lineTo(r, t);
    ctx.lineTo(r, b - br); if (br) ctx.arcTo(r, b, r - br, b, br); else ctx.lineTo(r, b);
    ctx.lineTo(l + bl, b); if (bl) ctx.arcTo(l, b, l, b - bl, bl); else ctx.lineTo(l, b);
    ctx.lineTo(l, t + tl); if (tl) ctx.arcTo(l, t, l + tl, t, tl); else ctx.lineTo(l, t);
    ctx.closePath();
  }
  /* stejný tvar jako SVG cesta (pro náhledy); jednotky = buňky * u */
  function rockPath(rects, u) {
    var d = [];
    rects.forEach(function (q) {
      var l = q[0] * u, t = q[1] * u, r = q[2] * u, b = q[3] * u, tl = q[4] * u, tr = q[5] * u, br = q[6] * u, bl = q[7] * u;
      d.push('M' + (l + tl) + ' ' + t + 'H' + (r - tr) + (tr ? 'A' + tr + ' ' + tr + ' 0 0 1 ' + r + ' ' + (t + tr) : '') + 'V' + (b - br) + (br ? 'A' + br + ' ' + br + ' 0 0 1 ' + (r - br) + ' ' + b : '') +
        'H' + (l + bl) + (bl ? 'A' + bl + ' ' + bl + ' 0 0 1 ' + l + ' ' + (b - bl) : '') + 'V' + (t + tl) + (tl ? 'A' + tl + ' ' + tl + ' 0 0 1 ' + (l + tl) + ' ' + t : '') + 'Z');
    });
    return d.join('');
  }
  function drawRocks(ctx, rocks, c) {
    var pad = Math.max(0.6, c * 0.07) / c, rects = rockRects(rocks, pad, 0.36), i, q;
    ctx.fillStyle = ROCK; ctx.beginPath();
    for (i = 0; i < rects.length; i++) { q = rects[i]; roundRectPath(ctx, q[0] * c, q[1] * c, q[2] * c, q[3] * c, q[4] * c, q[5] * c, q[6] * c, q[7] * c); }
    ctx.fill();
    for (i = 0; i < rects.length; i++) {
      q = rects[i];
      if (q[8]) { ctx.fillStyle = 'rgba(255,255,255,.15)'; ctx.beginPath(); roundRectPath(ctx, (q[0] + (q[4] ? 0.2 : 0.05)) * c, (q[1] + 0.1) * c, (q[2] - (q[5] ? 0.2 : 0.05)) * c, (q[1] + 0.26) * c, c * 0.08, c * 0.08, c * 0.08, c * 0.08); ctx.fill(); }
      if (q[9]) { ctx.fillStyle = 'rgba(0,0,0,.22)'; ctx.fillRect((q[0] + (q[7] ? 0.18 : 0)) * c, (q[3] - 0.13) * c, (q[2] - q[0] - (q[7] ? 0.18 : 0) - (q[6] ? 0.18 : 0)) * c, c * 0.1); }
    }
  }

  /* ---------- zdi a okraj: jedna plocha s čistou hranicí (bez opakující se textury) ---------- */
  function drawWallMass(ctx, solid, EW, EH, c) {
    var lw = Math.max(1, Math.round(c * 0.16)), sh = c * 0.75, x, y;
    function S(a, b) { return a < 0 || b < 0 || a >= EW || b >= EH || solid[b * EW + a] === 1; }
    function band(x0, y0, x1, y1, gx0, gy0, gx1, gy1, alpha) {
      var g = ctx.createLinearGradient(gx0, gy0, gx1, gy1); g.addColorStop(0, 'rgba(0,0,0,' + alpha + ')'); g.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = g; ctx.fillRect(x0, y0, x1 - x0, y1 - y0);
    }
    /* 1) měkký stín vržený na podlahu (světlo shora zleva → silnější stín vpravo a dole) */
    for (y = 0; y < EH; y++) for (x = 0; x < EW; x++) {
      if (!solid[y * EW + x]) continue;
      var px = x * c, py = y * c;
      if (!S(x, y + 1)) band(px, py + c, px + c, py + c + sh, 0, py + c, 0, py + c + sh, 0.38);
      if (!S(x + 1, y)) band(px + c, py, px + c + sh, py + c, px + c, 0, px + c + sh, 0, 0.3);
      if (!S(x, y - 1)) band(px, py - sh, px + c, py, 0, py, 0, py - sh, 0.14);
      if (!S(x - 1, y)) band(px - sh, py, px, py + c, px, 0, px - sh, 0, 0.12);
    }
    /* 2) plná plocha */
    ctx.fillStyle = WALL;
    for (y = 0; y < EH; y++) for (x = 0; x < EW; x++) if (solid[y * EW + x]) ctx.fillRect(x * c, y * c, c, c);
    /* 3) hranice jen tam, kde zeď sousedí s podlahou (nahoře a vlevo světlá, dole a vpravo tmavší) */
    for (y = 0; y < EH; y++) for (x = 0; x < EW; x++) {
      if (!solid[y * EW + x]) continue;
      var l = x * c, t = y * c, r = l + c, b = t + c, n = !S(x, y - 1), e = !S(x + 1, y), s = !S(x, y + 1), w = !S(x - 1, y);
      if (n) { ctx.fillStyle = LIT; ctx.fillRect(l, t, c, lw); }
      if (w) { ctx.fillStyle = LIT; ctx.fillRect(l, t, lw, c); }
      if (s) { ctx.fillStyle = DARK; ctx.fillRect(l, b - lw, c, lw); }
      if (e) { ctx.fillStyle = DARK; ctx.fillRect(r - lw, t, lw, c); }
      /* vnitřní (vydutý) roh: obě strany jsou zeď, jen úhlopříčka je podlaha → doplň čtvereček hranice */
      if (!n && !w && !S(x - 1, y - 1)) { ctx.fillStyle = LIT; ctx.fillRect(l, t, lw, lw); }
      if (!n && !e && !S(x + 1, y - 1)) { ctx.fillStyle = LIT; ctx.fillRect(r - lw, t, lw, lw); }
      if (!s && !w && !S(x - 1, y + 1)) { ctx.fillStyle = DARK; ctx.fillRect(l, b - lw, lw, lw); }
      if (!s && !e && !S(x + 1, y + 1)) { ctx.fillStyle = DARK; ctx.fillRect(r - lw, b - lw, lw, lw); }
    }
  }

  /* ---------- statická vrstva ---------- */
  /* opts: { grid:bool, gates:bool (barevné šipky bran – editor/náhled; ve hře jsou brány jen díry ve zdi) } */
  function base(ctx, level, c, opts) {
    opts = opts || {};
    var z = size(level), W = z.W, H = z.H, EW = W + 2, EH = H + 2, x, y, m = G.baseMaps(level);
    /* podlaha pod celým plátnem (kvůli stínům a branám) */
    for (y = 0; y < EH; y++) for (x = 0; x < EW; x++) { ctx.fillStyle = (x + y) & 1 ? FLOOR_A : FLOOR_B; ctx.fillRect(x * c, y * c, c, c); }
    if (opts.grid) {
      ctx.lineWidth = 1; ctx.beginPath(); ctx.strokeStyle = 'rgba(255,255,255,.04)';
      for (x = 0; x <= W; x++) if (x % BD.SUB) { ctx.moveTo((x + 1) * c + .5, c); ctx.lineTo((x + 1) * c + .5, (H + 1) * c); }
      for (y = 0; y <= H; y++) if (y % BD.SUB) { ctx.moveTo(c, (y + 1) * c + .5); ctx.lineTo((W + 1) * c, (y + 1) * c + .5); }
      ctx.stroke(); ctx.beginPath(); ctx.strokeStyle = 'rgba(255,255,255,.08)';       // hrubší čáry = hranice věží
      for (x = 0; x <= W; x += BD.SUB) { ctx.moveTo((x + 1) * c + .5, c); ctx.lineTo((x + 1) * c + .5, (H + 1) * c); }
      for (y = 0; y <= H; y += BD.SUB) { ctx.moveTo(c, (y + 1) * c + .5); ctx.lineTo((W + 1) * c, (y + 1) * c + .5); }
      ctx.stroke();
    }
    var solid = new Uint8Array(EW * EH);
    for (var i = 0; i < EW * EH; i++) {
      var gx = i % EW - 1, gy = ((i / EW) | 0) - 1, ring = gx < 0 || gy < 0 || gx >= W || gy >= H;
      solid[i] = (ring && !m.gate[i]) || m.wall[i] ? 1 : 0;
    }
    drawWallMass(ctx, solid, EW, EH, c);
    ctx.save(); ctx.translate(c, c); drawRocks(ctx, level.rocks, c); ctx.restore();
    if (opts.gates) {
      level.spawns.forEach(function (g) { gateDraw(ctx, g, W, H, c, false); });
      if (G.isOrb(level.exit)) {
        ctx.save(); ctx.translate(c, c); ctx.fillStyle = 'rgba(240,191,76,.16)';
        level.exit.orb.forEach(function (p) { ctx.fillRect(p[0] * c, p[1] * c, c, c); }); ctx.restore();
      } else gateDraw(ctx, level.exit, W, H, c, true);
    }
  }

  /* brána (jen editor/náhled): barevný průchod + šipka dovnitř (vstup, červená) / ven (cíl, žlutá) */
  function gateDraw(ctx, g, W, H, c, isExit) {
    var cells = G.gateCells(g, W, H), col = isExit ? '#f0bf4c' : '#e56b61', dir = G.SIDES[g.side], i;
    for (i = 0; i < cells.length; i++) {
      var gx = (cells[i][0] + 1) * c, gy = (cells[i][1] + 1) * c;
      ctx.fillStyle = isExit ? 'rgba(240,191,76,.26)' : 'rgba(229,107,97,.26)'; ctx.fillRect(gx, gy, c, c);
    }
    var mid = cells[Math.floor((cells.length - 1) / 2)], cx = (mid[0] + 1.5) * c, cy = (mid[1] + 1.5) * c;
    if (cells.length % 2 === 0) { if (dir[0]) cy += c / 2; else cx += c / 2; }
    var sx = isExit ? -dir[0] : dir[0], sy = isExit ? -dir[1] : dir[1], r = c * 0.42;
    ctx.save(); ctx.translate(cx, cy); ctx.rotate(Math.atan2(sy, sx)); ctx.fillStyle = col;
    ctx.beginPath(); ctx.moveTo(r, 0); ctx.lineTo(-r * 0.6, -r * 0.7); ctx.lineTo(-r * 0.6, r * 0.7); ctx.closePath(); ctx.fill(); ctx.restore();
  }

  /* cache statické vrstvy: owner = objekt, kam se vrstva uloží; key = cokoli, co se změní při změně obsahu */
  function layer(owner, key, wpx, hpx, dpr, fn) {
    if (!owner._layer || owner._layerKey !== key) {
      var cv = owner._layer || document.createElement('canvas');
      cv.width = Math.round(wpx * dpr); cv.height = Math.round(hpx * dpr);
      var cx = cv.getContext('2d'); cx.setTransform(dpr, 0, 0, dpr, 0, 0); fn(cx);
      owner._layer = cv; owner._layerKey = key;
    }
    return owner._layer;
  }

  /* ---------- cíl: pulzující perlová koule ---------- */
  function rnd(n) { var s = Math.sin(n * 12.9898 + 78.233) * 43758.5453; return s - Math.floor(s); }

  function drawOrb(ctx, b, c, t) {
    var pul = Math.sin(t * 2.3), R0 = b.r * c, R = R0 * (1 + 0.07 * pul), cx = b.cx * c, cy = b.cy * c + Math.sin(t * 1.6) * R0 * 0.07, i, k, a, g;
    ctx.save(); ctx.translate(cx, cy);

    /* záře kolem (aditivně) + paprsky */
    ctx.globalCompositeOperation = 'lighter';
    g = ctx.createRadialGradient(0, 0, R * 0.55, 0, 0, R * 2.7);
    g.addColorStop(0, 'rgba(130,205,255,' + (0.5 + 0.15 * pul) + ')'); g.addColorStop(0.35, 'rgba(190,120,255,.24)'); g.addColorStop(0.7, 'rgba(255,140,220,.08)'); g.addColorStop(1, 'rgba(120,120,255,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, R * 2.7, 0, TAU); ctx.fill();
    for (i = 0; i < 9; i++) {
      a = t * 0.35 + i * TAU / 9; var len = R * (1.55 + 0.45 * Math.sin(t * 1.7 + i * 1.9));
      g = ctx.createLinearGradient(Math.cos(a) * R, Math.sin(a) * R, Math.cos(a) * len, Math.sin(a) * len);
      g.addColorStop(0, 'rgba(190,225,255,.32)'); g.addColorStop(1, 'rgba(190,225,255,0)');
      ctx.strokeStyle = g; ctx.lineWidth = Math.max(1, R * 0.09); ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(Math.cos(a) * R, Math.sin(a) * R); ctx.lineTo(Math.cos(a) * len, Math.sin(a) * len); ctx.stroke();
    }
    ctx.globalCompositeOperation = 'source-over';

    /* tělo koule */
    ctx.save(); ctx.beginPath(); ctx.arc(0, 0, R, 0, TAU); ctx.clip();
    g = ctx.createRadialGradient(-R * 0.3, -R * 0.35, R * 0.05, 0, 0, R);
    g.addColorStop(0, '#f6fbff'); g.addColorStop(0.22, '#cfe8ff'); g.addColorStop(0.55, '#8fb8f5'); g.addColorStop(0.85, '#8d78e0'); g.addColorStop(1, '#4c51b8');
    ctx.fillStyle = g; ctx.fillRect(-R, -R, R * 2, R * 2);
    /* duhová perleť – dva protiběžné kuželové přechody */
    if (ctx.createConicGradient) {
      var cols = ['#ff9fd8', '#8fe9ff', '#b79cff', '#ffd3a1', '#8dffd6', '#ff9fd8'];
      for (k = 0; k < 2; k++) {
        g = ctx.createConicGradient(k ? -t * 0.45 : t * 0.6, 0, 0);
        for (i = 0; i < cols.length; i++) g.addColorStop(i / (cols.length - 1), cols[(i + k * 2) % cols.length]);
        ctx.globalAlpha = k ? 0.38 : 0.62; ctx.globalCompositeOperation = k ? 'screen' : 'source-over';
        ctx.fillStyle = g; ctx.fillRect(-R, -R, R * 2, R * 2);
      }
      ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
    }
    /* točící se mlhavé pásy uvnitř */
    ctx.globalCompositeOperation = 'lighter'; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    for (k = 0; k < 3; k++) {
      ctx.beginPath();
      for (i = 0; i <= 26; i++) {
        var u = i / 26, rr = R * (0.12 + 0.82 * u), an = t * (0.5 + k * 0.08) + k * 2.094 + u * 3.1;
        var px = Math.cos(an) * rr, py = Math.sin(an) * rr * 0.92;
        i ? ctx.lineTo(px, py) : ctx.moveTo(px, py);
      }
      ctx.strokeStyle = 'rgba(255,255,255,' + (0.09 + 0.03 * k) + ')'; ctx.lineWidth = Math.max(1, R * (0.2 - k * 0.04)); ctx.stroke();
    }
    /* plazmová síť: body kroužící uvnitř, spojené čárami (jako energie ve sféře) */
    var pts = [];
    for (i = 0; i < 9; i++) {
      var an2 = t * (0.4 + rnd(i) * 0.7) * (i % 2 ? 1 : -1) + rnd(i + 20) * TAU, rd = R * (0.15 + 0.7 * rnd(i + 40));
      pts.push([Math.cos(an2) * rd, Math.sin(an2) * rd]);
    }
    ctx.lineWidth = Math.max(0.6, R * 0.025);
    for (i = 0; i < pts.length; i++) for (k = i + 1; k < pts.length; k++) {
      var dd = Math.hypot(pts[i][0] - pts[k][0], pts[i][1] - pts[k][1]);
      if (dd < R * 0.78) { ctx.strokeStyle = 'rgba(190,235,255,' + (0.55 * (1 - dd / (R * 0.78))) + ')'; ctx.beginPath(); ctx.moveTo(pts[i][0], pts[i][1]); ctx.lineTo(pts[k][0], pts[k][1]); ctx.stroke(); }
    }
    ctx.fillStyle = 'rgba(255,255,255,.8)';
    for (i = 0; i < pts.length; i++) { ctx.beginPath(); ctx.arc(pts[i][0], pts[i][1], Math.max(0.8, R * 0.032), 0, TAU); ctx.fill(); }
    /* zářící jádro */
    g = ctx.createRadialGradient(0, 0, 0, 0, 0, R * 0.42);
    g.addColorStop(0, 'rgba(255,255,255,' + (0.38 + 0.18 * pul) + ')'); g.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = g; ctx.fillRect(-R, -R, R * 2, R * 2);
    ctx.globalCompositeOperation = 'source-over';
    /* třpytky na povrchu (blikají) */
    for (i = 0; i < 7; i++) {
      var ta = rnd(i + 70) * TAU, tr = R * (0.2 + 0.62 * rnd(i + 90)), al = Math.max(0, Math.sin(t * (1.8 + rnd(i + 110) * 2) + i * 2.3)), s = R * (0.05 + 0.08 * al);
      if (al < 0.25) continue;
      var sx = Math.cos(ta) * tr, sy = Math.sin(ta) * tr;
      ctx.strokeStyle = 'rgba(255,255,255,' + (0.9 * al) + ')'; ctx.lineWidth = Math.max(0.8, R * 0.025);
      ctx.beginPath(); ctx.moveTo(sx - s, sy); ctx.lineTo(sx + s, sy); ctx.moveTo(sx, sy - s); ctx.lineTo(sx, sy + s); ctx.stroke();
    }
    /* okraj koule (fresnel) */
    g = ctx.createRadialGradient(0, 0, R * 0.62, 0, 0, R);
    g.addColorStop(0, 'rgba(120,190,255,0)'); g.addColorStop(1, 'rgba(110,200,255,.6)');
    ctx.fillStyle = g; ctx.fillRect(-R, -R, R * 2, R * 2);
    /* odlesk */
    g = ctx.createRadialGradient(-R * 0.38, -R * 0.45, 0, -R * 0.38, -R * 0.45, R * 0.42);
    g.addColorStop(0, 'rgba(255,255,255,.85)'); g.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(-R * 0.38, -R * 0.45, R * 0.38, R * 0.24, -0.6, 0, TAU); ctx.fill();
    ctx.restore();                                         // konec ořezu

    /* světelný obrys + elektrické výboje na okraji */
    ctx.globalCompositeOperation = 'lighter';
    ctx.strokeStyle = 'rgba(150,225,255,.75)'; ctx.lineWidth = Math.max(1, R * 0.06); ctx.beginPath(); ctx.arc(0, 0, R, 0, TAU); ctx.stroke();
    var bucket = Math.floor(t * 12);
    ctx.lineWidth = Math.max(0.8, R * 0.04); ctx.strokeStyle = 'rgba(170,235,255,.85)';
    for (i = 0; i < 6; i++) {
      var ea = rnd(bucket * 7 + i) * TAU, el = R * (0.14 + 0.28 * rnd(bucket * 5 + i + 3)), ex = Math.cos(ea) * R, ey = Math.sin(ea) * R;
      ctx.beginPath(); ctx.moveTo(ex, ey);
      for (k = 1; k <= 4; k++) { var f = k / 4, jx = (rnd(bucket + i * 9 + k) - 0.5) * R * 0.16, jy = (rnd(bucket + i * 13 + k + 5) - 0.5) * R * 0.16; ctx.lineTo(Math.cos(ea) * (R + el * f) + jx, Math.sin(ea) * (R + el * f) + jy); }
      ctx.stroke();
    }
    /* jiskry kroužící kolem */
    for (i = 0; i < 12; i++) {
      var oa = t * (0.5 + rnd(i) * 0.5) * (i % 2 ? 1 : -1) + rnd(i + 5) * TAU, orr = R * (1.12 + 0.55 * rnd(i + 30)), tw = 0.5 + 0.5 * Math.sin(t * 3 + i * 1.7);
      ctx.fillStyle = 'rgba(200,235,255,' + (0.25 + 0.6 * tw) + ')';
      ctx.beginPath(); ctx.arc(Math.cos(oa) * orr, Math.sin(oa) * orr, Math.max(0.8, R * (0.03 + 0.03 * tw)), 0, TAU); ctx.fill();
    }
    ctx.restore();
  }

  /* všechny koule cíle; volat po ctx.translate(c, c) (souřadnice pole) */
  function orbs(ctx, level, c, t) {
    if (!G.isOrb(level.exit)) return;
    if (t === undefined) t = (typeof performance !== 'undefined' ? performance.now() : Date.now()) / 1000;
    G.orbBlobs(level.exit.orb).forEach(function (b) { drawOrb(ctx, b, c, t); });
  }

  BD.render.field = { base: base, layer: layer, orbs: orbs, size: size, rockRects: rockRects, rockPath: rockPath };
})(window.BD);
