/* Sprite – vlastní vzhled nepřátel a věží ze Studia: strom vrstev (kruh, prstenec, elipsa, obdélník, mnohoúhelník, hvězda, skupina)
   s barevným přechodem, okrajem, stínem a animací (otáčí se za cílem / točí se / pulzuje / houpe se).
   Pořadí v poli nodes = od spodní vrstvy po horní; děti se kreslí nad rodičem a dědí jeho posun, otočení i velikost.
   Jednotka: 1 = poloměr nepřítele, u věže polovina její velikosti. Souřadnice x doprava, y dolů; „hlaveň“ věže míří doprava (+x).
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  var TAU = Math.PI * 2;
  var TYPES = ['group', 'circle', 'ring', 'ellipse', 'rect', 'poly', 'star', 'ref'];
  var ANIMS = ['none', 'aim', 'spin', 'pulse', 'bob'];
  var COLOR_RE = /^(#[0-9a-fA-F]{6}([0-9a-fA-F]{2})?|rgba?\(\s*\d{1,3}\s*,\s*\d{1,3}\s*,\s*\d{1,3}\s*(,\s*[01]?(\.\d+)?\s*)?\))$/;
  var LIMIT = { nodes: 160, depth: 6, refs: 30 };         // nodes: největší počet vrstev jednoho vzhledu; refs: kolik odkazů na šablony smí obsahovat
  var NAMES = { group: 'Skupina', circle: 'Kruh', ring: 'Prstenec', ellipse: 'Elipsa', rect: 'Obdélník', poly: 'Mnohoúhelník', star: 'Hvězda', ref: 'Šablona' };

  function uid() { return 'n' + Math.random().toString(36).slice(2, 7); }
  function num(v, a, b, d) { v = Number(v); return isFinite(v) ? Math.min(b, Math.max(a, v)) : d; }
  function color(v, d) { return typeof v === 'string' && COLOR_RE.test(v.trim()) ? v.trim() : d; }

  /* nový uzel s rozumnými výchozími hodnotami */
  function node(type, o) {
    var n = { id: uid(), name: NAMES[type] || type, type: type, x: 0, y: 0, rot: 0, w: 1, h: 1, alpha: 1, visible: true,
      fill: { t: 'solid', stops: [[0, '#8fd0ff'], [1, '#2e8dc0']], angle: 90, fx: -0.3, fy: -0.3 },
      stroke: { c: '#ffffff', w: 0.06, a: 1 }, shadow: { c: '#000000', b: 0, x: 0, y: 0 }, anim: { t: 'none', speed: 1, amp: 0.1 }, children: [] };
    if (type === 'group' || type === 'ref') { n.fill.t = 'none'; n.stroke.w = 0; }
    if (type === 'ref') n.ref = '';
    if (type === 'rect') { n.w = 1.2; n.h = 0.5; n.cr = 0.1; }
    if (type === 'ellipse') { n.w = 1.4; n.h = 0.8; }
    if (type === 'ring') { n.thick = 0.15; n.fill.t = 'solid'; n.fill.stops = [[0, '#ffffff'], [1, '#ffffff']]; n.stroke.w = 0; }
    if (type === 'poly') n.n = 6;
    if (type === 'star') { n.n = 5; n.inner = 0.5; }
    if (o) for (var k in o) n[k] = o[k];
    return n;
  }

  /* ---------- úpravy stromu ---------- */
  function walk(list, fn, parent, depth) { for (var i = 0; i < list.length; i++) { fn(list[i], parent, list, i, depth || 0); if (list[i].children) walk(list[i].children, fn, list[i], (depth || 0) + 1); } }
  function find(sp, id) { var r = null; walk(sp.nodes, function (n, p, list, i) { if (n.id === id) r = { node: n, parent: p, list: list, index: i }; }); return r; }
  function count(sp) { var c = 0; walk(sp.nodes, function () { c++; }); return c; }
  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function reid(n) { n.id = uid(); (n.children || []).forEach(reid); return n; }

  /* šablona (uzel typu 'ref'): kreslí se obsah šablony ze Studia, uvnitř šablony už další odkaz být nemůže */
  function resolve(id) { return BD.studio && BD.studio.tplSprite ? BD.studio.tplSprite(id) : null; }
  function refCount(sp) { var c = 0; walk(sp.nodes, function (n) { if (n.type === 'ref') c++; }); return c; }

  /* ---------- kreslení ---------- */
  function build(ctx, n) {
    var w = n.w / 2, h = (n.type === 'circle' || n.type === 'ring' || n.type === 'poly' || n.type === 'star' ? n.w : n.h) / 2, i, a, k;
    ctx.beginPath();
    if (n.type === 'circle') ctx.arc(0, 0, w, 0, TAU);
    else if (n.type === 'ellipse') ctx.ellipse(0, 0, Math.max(0.001, w), Math.max(0.001, h), 0, 0, TAU);
    else if (n.type === 'ring') { ctx.arc(0, 0, w, 0, TAU); ctx.moveTo(Math.max(0, w - n.thick), 0); ctx.arc(0, 0, Math.max(0, w - (n.thick || 0.15)), 0, TAU, true); }
    else if (n.type === 'rect') {
      var r = Math.min(n.cr || 0, w, h), x = -w, y = -h;
      ctx.moveTo(x + r, y); ctx.arcTo(x + 2 * w, y, x + 2 * w, y + 2 * h, r); ctx.arcTo(x + 2 * w, y + 2 * h, x, y + 2 * h, r); ctx.arcTo(x, y + 2 * h, x, y, r); ctx.arcTo(x, y, x + 2 * w, y, r); ctx.closePath();
    } else if (n.type === 'poly') {
      k = Math.max(3, n.n | 0); for (i = 0; i < k; i++) { a = -Math.PI / 2 + i * TAU / k; if (i) ctx.lineTo(Math.cos(a) * w, Math.sin(a) * w); else ctx.moveTo(Math.cos(a) * w, Math.sin(a) * w); } ctx.closePath();
    } else if (n.type === 'star') {
      k = Math.max(3, n.n | 0); for (i = 0; i < k * 2; i++) { a = -Math.PI / 2 + i * Math.PI / k; var rr = i % 2 ? w * (n.inner || 0.5) : w; if (i) ctx.lineTo(Math.cos(a) * rr, Math.sin(a) * rr); else ctx.moveTo(Math.cos(a) * rr, Math.sin(a) * rr); } ctx.closePath();
    }
  }
  function paint(ctx, f, n) {
    if (!f || f.t === 'none') return null;
    var w = n.w / 2, h = (n.type === 'circle' || n.type === 'ring' || n.type === 'poly' || n.type === 'star' ? n.w : n.h) / 2, e = Math.max(w, h, 0.001);
    if (f.t === 'solid' || !f.stops || f.stops.length < 2) return (f.stops && f.stops[0] && f.stops[0][1]) || '#888888';
    var g;
    if (f.t === 'linear') { var a = (f.angle || 0) * Math.PI / 180, dx = Math.cos(a) * e, dy = Math.sin(a) * e; g = ctx.createLinearGradient(-dx, -dy, dx, dy); }
    else g = ctx.createRadialGradient((f.fx || 0) * w, (f.fy || 0) * h, 0, 0, 0, e * 1.0);
    f.stops.forEach(function (s) { g.addColorStop(Math.min(1, Math.max(0, s[0])), s[1]); });
    return g;
  }

  /* draw(ctx, sprite, cx, cy, unitPx, state, opts)
     state {t, aim, alpha};  opts {pick:{x,y}, rec:{}, sel:id}  → vrací id nejvyšší vrstvy pod bodem pick */
  function draw(ctx, sp, cx, cy, u, state, opts) {
    state = state || {}; opts = opts || {};
    var picked = null, t = state.t || 0, refId = null, active = {}, rdepth = 0, budget = 6000;     // refId: právě se kreslí obsah šablony vloženého uzlu (výběr a tažení patří celému uzlu); active / rdepth / budget hlídají zacyklení a přehnaně velké vnořování šablon
    function one(n, parentAlpha, inOnly) {
      if (n.visible === false) return;
      if (refId && --budget < 0) return;
      var onlyOk = !opts.only || inOnly || n.id === opts.only;     // opts.only: zkouší se trefit jen tento uzel (a jeho potomky)
      var m0 = opts.rec && !refId ? ctx.getTransform() : null;
      if (m0) opts.rec[n.id] = m0;
      ctx.save();
      ctx.translate(n.x || 0, n.y || 0); if (n.rot) ctx.rotate(n.rot * Math.PI / 180);
      if (n.flip) ctx.scale(1, -1);                                      // zrcadlení (po otočení, před animací → animace se zrcadlí také)
      var an = n.anim || {}, sp0 = an.speed || 1;
      if (an.t === 'aim') ctx.rotate(state.aim || 0);
      else if (an.t === 'spin') ctx.rotate(t * sp0);
      else if (an.t === 'pulse') { var k = 1 + (an.amp || 0.1) * Math.sin(t * sp0 * 3); ctx.scale(k, k); }
      else if (an.t === 'bob') ctx.translate(0, (an.amp || 0.1) * Math.sin(t * sp0 * 3));
      var al = parentAlpha * (n.alpha == null ? 1 : n.alpha);
      if (n.type === 'ref') {
        {
          var tp = !active[n.ref] && rdepth < 6 ? resolve(n.ref) : null, k = Math.max(0.01, n.w == null ? 1 : n.w);
          if (tp) { var outer = refId; ctx.save(); ctx.scale(k, k); if (!outer) refId = n.id; active[n.ref] = 1; rdepth++; tp.nodes.forEach(function (c) { one(c, al, onlyOk); }); rdepth--; delete active[n.ref]; refId = outer; ctx.restore(); }
          else if (!refId && opts.rec && !opts.pick) { ctx.save(); ctx.setLineDash([0.08, 0.08]); ctx.lineWidth = 0.03; ctx.strokeStyle = '#ff6b61'; ctx.beginPath(); ctx.arc(0, 0, 0.4 * k, 0, TAU); ctx.moveTo(-0.28 * k, -0.28 * k); ctx.lineTo(0.28 * k, 0.28 * k); ctx.stroke(); ctx.restore(); }
        }
      } else if (n.type !== 'group') {
        build(ctx, n);
        var fs = paint(ctx, n.fill, n), st = n.stroke, sh = n.shadow;
        if (opts.pick) {
          if (!onlyOk) { /* mimo omezení */ }
          else if ((fs && ctx.isPointInPath(opts.pick.x, opts.pick.y, 'evenodd')) || (st && st.w > 0 && ctx.isPointInStroke(opts.pick.x, opts.pick.y))) picked = refId || n.id;
          else if (!fs && !(st && st.w > 0) && ctx.isPointInPath(opts.pick.x, opts.pick.y, 'evenodd')) picked = refId || n.id;
        } else {
          ctx.globalAlpha = al;
          if (sh && sh.b > 0 || (sh && (sh.x || sh.y))) { ctx.shadowColor = sh.c; ctx.shadowBlur = (sh.b || 0) * u; ctx.shadowOffsetX = (sh.x || 0) * u; ctx.shadowOffsetY = (sh.y || 0) * u; }
          if (fs) { ctx.fillStyle = fs; ctx.fill(n.type === 'ring' ? 'evenodd' : 'nonzero'); }
          if (st && st.w > 0) { ctx.shadowColor = 'transparent'; if (!fs && sh && sh.b > 0) { ctx.shadowColor = sh.c; } ctx.globalAlpha = al * (st.a == null ? 1 : st.a); ctx.lineWidth = st.w; ctx.strokeStyle = st.c; ctx.lineJoin = 'round'; ctx.stroke(); }
          ctx.shadowColor = 'transparent'; ctx.shadowBlur = 0; ctx.shadowOffsetX = 0; ctx.shadowOffsetY = 0; ctx.globalAlpha = 1;
        }
      }
      (n.children || []).forEach(function (c) { one(c, al, onlyOk); });
      if (!opts.pick && !refId && (opts.sels ? opts.sels[n.id] : opts.sel === n.id)) {                            // výběr: čárkovaný obrys
        var sc = Math.hypot(ctx.getTransform().a, ctx.getTransform().b) || 1;
        if (n.type === 'group' || n.type === 'ref') { ctx.beginPath(); ctx.arc(0, 0, 0.12, 0, TAU); ctx.moveTo(-0.2, 0); ctx.lineTo(0.2, 0); ctx.moveTo(0, -0.2); ctx.lineTo(0, 0.2); } else build(ctx, n);
        ctx.setLineDash([5 / sc, 4 / sc]); ctx.lineWidth = 1.6 / sc; ctx.strokeStyle = opts.sel === n.id || !opts.sel ? '#f0bf4c' : '#9ad0ff'; ctx.stroke(); ctx.setLineDash([]);
      }
      ctx.restore();
    }
    ctx.save(); ctx.translate(cx, cy); ctx.scale(u, u);
    if (opts.rec) opts.rec.__root = ctx.getTransform();
    sp.nodes.forEach(function (n) { one(n, state.alpha == null ? 1 : state.alpha, false); });
    ctx.restore();
    return picked;
  }

  /* ---------- šablony: z dnešního vzhledu hry vytvoří upravitelný sprite ---------- */
  function shade() { return BD.render.draw.shade.apply(null, arguments); }
  function hexA() { return BD.render.draw.hexA.apply(null, arguments); }
  function toHex(rgb) { var m = String(rgb).match(/\d+/g); return '#' + m.slice(0, 3).map(function (v) { return ('0' + (+v).toString(16)).slice(-2); }).join(''); }
  function enemyTemplate(def) {
    var c = def.color || '#e077c0';
    var body = node('circle', { name: 'Tělo', w: 2, fill: { t: 'radial', stops: [[0, toHex(shade(c, 0.6))], [1, c]], angle: 90, fx: -0.35, fy: -0.35 }, stroke: { c: toHex(shade(c, 0.35)), w: 0.09, a: 1 } });
    var hi = node('ellipse', { name: 'Odlesk', x: -0.3, y: -0.38, rot: -34, w: 0.5, h: 0.28, fill: { t: 'solid', stops: [[0, 'rgba(255,255,255,0.55)'], [1, 'rgba(255,255,255,0.55)']] }, stroke: { c: '#ffffff', w: 0, a: 1 } });
    return { v: 1, nodes: [body, hi] };
  }
  function towerTemplate(def) {
    var c = def.color || '#f0c419', role = def.role || 'shot', i, kids = [];
    function bub(name, x, y, r, col) { return node('circle', { name: name, x: x, y: y, w: r * 2, fill: { t: 'radial', stops: [[0, toHex(shade(col, 0.55))], [1, col]], angle: 90, fx: -0.35, fy: -0.35 }, stroke: { c: '#ffffff', w: r * 0.28, a: 0.85 } }); }
    var corners = [];
    for (i = 0; i < 4; i++) corners.push(bub('Roh ' + (i + 1), (i % 2 ? 1 : -1) * 0.66, (i > 1 ? 1 : -1) * 0.66, 0.3, '#2e8dc0'));
    var disc = node('circle', { name: 'Podstavec', w: 1.44, fill: { t: 'solid', stops: [[0, '#1d6485'], [1, '#1d6485']] }, stroke: { c: '#ffffff', w: 0.1, a: 1 } });
    var core = bub('Jádro', 0, 0, 0.36, c);
    var head = node('group', { name: 'Hlava', anim: { t: role === 'shot' ? 'aim' : 'spin', speed: 0.6, amp: 0.1 } });
    if (role === 'shot') head.children.push(node('rect', { name: 'Hlaveň', x: 0.4, y: 0, w: 0.7, h: 0.2, cr: 0.08, fill: { t: 'linear', stops: [[0, toHex(shade(c, 0.4))], [1, c]], angle: 90 }, stroke: { c: '#ffffff', w: 0.04, a: 0.8 } }));
    for (i = 0; i < 2; i++) { var a = i * Math.PI; head.children.push(bub('Satelit ' + (i + 1), Math.cos(a) * 0.5, Math.sin(a) * 0.5, 0.15, toHex(shade(c, 0.1)))); }
    head.children.unshift(core);
    return { v: 1, nodes: corners.concat([disc, head]) };
  }


  /* ---------- nástroje: zrcadlení a opakování kolem středu ---------- */
  function r2(v) { return Math.round(v * 100) / 100; }
  function wrap(a) { a = ((a + 180) % 360 + 360) % 360 - 180; return r2(a); }
  /* zrcadlový obraz uzlu podle přímky procházející (cx,cy) pod úhlem th (stupně; 0 = vodorovná, 90 = svislá) */
  function mirrored(n, cx, cy, th) {
    var c = reid(clone(n)), a = th * Math.PI / 180, dx = (n.x || 0) - cx, dy = (n.y || 0) - cy, c2 = Math.cos(2 * a), s2 = Math.sin(2 * a);
    c.x = r2(cx + c2 * dx + s2 * dy); c.y = r2(cy + s2 * dx - c2 * dy);
    c.rot = wrap(2 * th - (n.rot || 0)); if (n.flip) delete c.flip; else c.flip = true;
    return c;
  }
  /* kopie otočené kolem středu (cx,cy): n kusů celkem (včetně originálu), rozložených po úhlu sweep */
  function radial(n, cx, cy, count, sweep) {
    var out = [], step = sweep >= 360 ? sweep / count : sweep / Math.max(1, count - 1);
    for (var k = 1; k < count; k++) {
      var f = k * step * Math.PI / 180, dx = (n.x || 0) - cx, dy = (n.y || 0) - cy, c = reid(clone(n));
      c.x = r2(cx + Math.cos(f) * dx - Math.sin(f) * dy); c.y = r2(cy + Math.sin(f) * dx + Math.cos(f) * dy); c.rot = wrap((n.rot || 0) + k * step);
      c.name = (n.name + ' ' + (k + 1)).slice(0, 24); out.push(c);
    }
    return out;
  }

  /* ---------- čištění (z postupu i z importu) ---------- */
  function cleanNode(n, depth, counter) {
    if (!n || typeof n !== 'object' || TYPES.indexOf(n.type) < 0 || counter.n >= LIMIT.nodes) return null;
    if (n.type === 'ref' && (counter.noRef || counter.refs >= LIMIT.refs)) return null;                 // v šabloně další šablona být nesmí; odkazů je omezený počet
    counter.n++; if (n.type === 'ref') counter.refs++;
    var o = { id: /^[a-z0-9_]{1,12}$/.test(n.id) ? n.id : uid(), name: String(n.name == null ? NAMES[n.type] : n.name).slice(0, 24), type: n.type,
      x: num(n.x, -6, 6, 0), y: num(n.y, -6, 6, 0), rot: num(n.rot, -720, 720, 0), w: num(n.w, 0, 8, 1), h: num(n.h, 0, 8, 1), alpha: num(n.alpha, 0, 1, 1), visible: n.visible !== false, children: [] };
    if (n.flip) o.flip = true;
    if (n.type === 'ref') o.ref = /^[a-z][a-z0-9_]{1,19}$/.test(String(n.ref)) ? String(n.ref) : '';
    if (n.type === 'rect') o.cr = num(n.cr, 0, 4, 0);
    if (n.type === 'ring') o.thick = num(n.thick, 0.01, 4, 0.15);
    if (n.type === 'poly' || n.type === 'star') o.n = Math.round(num(n.n, 3, 24, 5));
    if (n.type === 'star') o.inner = num(n.inner, 0.1, 0.95, 0.5);
    var f = n.fill || {}, stops = Array.isArray(f.stops) ? f.stops.slice(0, 5).map(function (s) { return Array.isArray(s) ? [num(s[0], 0, 1, 0), color(s[1], '#888888')] : null; }).filter(Boolean) : [];
    if (stops.length < 2) stops = [[0, '#888888'], [1, '#444444']];
    o.fill = { t: ['none', 'solid', 'linear', 'radial'].indexOf(f.t) >= 0 ? f.t : 'solid', stops: stops, angle: num(f.angle, -360, 360, 90), fx: num(f.fx, -1, 1, 0), fy: num(f.fy, -1, 1, 0) };
    var s = n.stroke || {}; o.stroke = { c: color(s.c, '#ffffff'), w: num(s.w, 0, 0.6, 0), a: num(s.a, 0, 1, 1) };
    var h = n.shadow || {}; o.shadow = { c: color(h.c, '#000000'), b: num(h.b, 0, 3, 0), x: num(h.x, -2, 2, 0), y: num(h.y, -2, 2, 0) };
    var a = n.anim || {}; o.anim = { t: ANIMS.indexOf(a.t) >= 0 ? a.t : 'none', speed: num(a.speed, -20, 20, 1), amp: num(a.amp, 0, 1, 0.1) };
    if (n.type !== 'ref' && depth < LIMIT.depth && Array.isArray(n.children)) n.children.forEach(function (c) { var k = cleanNode(c, depth + 1, counter); if (k) o.children.push(k); });
    return o;
  }
  function sanitize(sp, opts) {
    if (!sp || typeof sp !== 'object' || !Array.isArray(sp.nodes)) return null;
    var counter = { n: 0, refs: 0, noRef: !!(opts && opts.noRef) }, out = { v: 1, nodes: [] };
    sp.nodes.forEach(function (n) { var k = cleanNode(n, 0, counter); if (k) out.nodes.push(k); });
    return out.nodes.length ? out : null;
  }

  BD.render.sprite = { draw: draw, node: node, walk: walk, find: find, count: count, refCount: refCount, resolve: resolve, clone: clone, reid: reid, sanitize: sanitize, uid: uid,
    mirrored: mirrored, radial: radial, enemyTemplate: enemyTemplate, towerTemplate: towerTemplate, TYPES: TYPES, ANIMS: ANIMS, NAMES: NAMES, LIMIT: LIMIT };
})(window.BD);
