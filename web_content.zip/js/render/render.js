/* Renderer canvas + partikel. Tanpa emoji: semua objek digambar sebagai bentuk + penanda huruf (warna bukan satu-satunya pembeda). */
(function (g) {
  'use strict';
  const SU = g.SU, C = SU.config, K = C.CELL;
  const THEMES = {
    classic: { snake: '#2ecc71', head: '#27ae60', bg: '#0a1f2e', grid: 'rgba(255,255,255,0.05)', bomb: '#c0392b', text: '#ffffff' },
    dark: { snake: '#5d7a96', head: '#34495e', bg: '#1c1c1c', grid: 'rgba(255,255,255,0.04)', bomb: '#7f8c8d', text: '#ecf0f1' },
    forest: { snake: '#27ae60', head: '#2ecc71', bg: '#1b4d3e', grid: 'rgba(255,255,255,0.05)', bomb: '#8b4513', text: '#ecf0f1' },
    neon: { snake: '#00ffcc', head: '#00ccff', bg: '#0a0a2a', grid: 'rgba(0,255,255,0.06)', bomb: '#ff0066', text: '#ffffff' },
    light: { snake: '#4CAF50', head: '#2e7d32', bg: '#F0E68C', grid: 'rgba(0,0,0,0.12)', bomb: '#a0784a', text: '#000000' },
    special: { snake: '#FF0000', head: '#B71C1C', bg: '#388E3C', grid: 'rgba(255,255,255,0.12)', bomb: '#FFEB3B', text: '#ffffff' }
  };
  const FX = (SU.fx = {
    list: [], reduced: false,
    add: function (p) { if (FX.list.length < C.MAX_PARTICLES) FX.list.push(p); },
    text: function (x, y, t, color) { FX.add({ k: 't', x: x * K + K / 2, y: y * K + K / 2, vx: (Math.random() - 0.5), vy: -1.6, life: 1, t: t, c: color || '#f1c40f' }); },
    burst: function (x, y, color, n) {
      if (FX.reduced) return; n = Math.min(n || 10, 16);
      for (let i = 0; i < n; i++) { const a = Math.random() * 6.283, sp = 1 + Math.random() * 2; FX.add({ k: 'd', x: x * K + K / 2, y: y * K + K / 2, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: 1, c: color }); }
    },
    fireworks: function (grid) { if (FX.reduced) return; for (let i = 0; i < 6; i++) FX.burst(Math.random() * grid, Math.random() * grid, 'hsl(' + Math.floor(Math.random() * 360) + ',90%,60%)', 12); },
    update: function (dt) {
      const k = dt * 60;
      FX.list = FX.list.filter(function (p) { p.x += p.vx * k; p.y += p.vy * k; p.vy += 0.06 * k; p.life -= 0.03 * k; return p.life > 0; });
    },
    clear: function () { FX.list = []; }
  });

  function draw(ctx, s, themeId, opts) {
    const th = THEMES[themeId] || THEMES.classic, grid = s ? s.grid : C.GRID0, size = grid * K;
    if (ctx.canvas.width !== size) { ctx.canvas.width = size; ctx.canvas.height = size; }
    ctx.globalAlpha = 1; ctx.fillStyle = th.bg; ctx.fillRect(0, 0, size, size);
    ctx.strokeStyle = th.grid; ctx.lineWidth = 1; ctx.beginPath();
    for (let i = 0; i <= grid; i++) { ctx.moveTo(i * K + 0.5, 0); ctx.lineTo(i * K + 0.5, size); ctx.moveTo(0, i * K + 0.5); ctx.lineTo(size, i * K + 0.5); }
    ctx.stroke();
    if (!s) return;
    const now = opts && opts.now || 0, cx = function (v) { return v * K + K / 2; };
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    const label = function (t, x, y, col, px) { ctx.fillStyle = col; ctx.font = 'bold ' + (px || 10) + 'px sans-serif'; ctx.fillText(t, cx(x), cx(y)); };
    const disc = function (x, y, col, r) { ctx.fillStyle = col; ctx.beginPath(); ctx.arc(cx(x), cx(y), r || K / 2 - 2, 0, 6.283); ctx.fill(); };

    if (s.slowZone) { const z = s.slowZone; ctx.fillStyle = 'rgba(52,152,219,0.3)'; ctx.fillRect(z.x * K, z.y * K, z.size * K, z.size * K); ctx.strokeStyle = '#3498db'; ctx.setLineDash([4, 3]); ctx.strokeRect(z.x * K + 1, z.y * K + 1, z.size * K - 2, z.size * K - 2); ctx.setLineDash([]); label('LAMBAT', z.x + z.size / 2 - 0.5, z.y + z.size / 2 - 0.5, th.text, 8); }
    s.ice.forEach(function (c) { ctx.fillStyle = 'rgba(236,240,241,0.55)'; ctx.fillRect(c.x * K, c.y * K, K, K); ctx.strokeStyle = '#7fb3d5'; ctx.beginPath(); ctx.moveTo(c.x * K + 3, c.y * K + K - 3); ctx.lineTo(c.x * K + K - 3, c.y * K + 3); ctx.stroke(); });
    if (s.portal) [s.portal.entry, s.portal.exit].forEach(function (c, i) { disc(c.x, c.y, '#9b59b6'); ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(cx(c.x), cx(c.y), K / 4, 0, 6.283); ctx.stroke(); ctx.lineWidth = 1; label(i ? 'K' : 'M', c.x, c.y, '#fff', 7); });
    const f = s.food;
    if (f) {
      if (f.rare) { ctx.strokeStyle = '#f1c40f'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(cx(f.x), cx(f.y), K / 2 - 1, 0, 6.283); ctx.stroke(); ctx.lineWidth = 1; }
      disc(f.x, f.y, f.color, K / 2 - 3.5); label(String(f.points), f.x, f.y, '#fff', 9);
      if (f.moving) { ctx.fillStyle = '#fff'; ctx.fillRect(f.x * K + K - 4, f.y * K + 1, 3, 3); }
    }
    if (s.coin) { disc(s.coin.x, s.coin.y, '#ffcc00'); ctx.strokeStyle = '#b8860b'; ctx.beginPath(); ctx.arc(cx(s.coin.x), cx(s.coin.y), K / 4, 0, 6.283); ctx.stroke(); }
    if (s.meteor) { ctx.globalAlpha = 0.6 + Math.sin(now / 150) * 0.3; ctx.fillStyle = '#7f8c8d'; ctx.fillRect(s.meteor.x * K + 1, s.meteor.y * K + 1, K - 2, K - 2); ctx.strokeStyle = '#e74c3c'; ctx.beginPath(); ctx.moveTo(s.meteor.x * K + 3, s.meteor.y * K + 3); ctx.lineTo(s.meteor.x * K + K - 3, s.meteor.y * K + K - 3); ctx.moveTo(s.meteor.x * K + K - 3, s.meteor.y * K + 3); ctx.lineTo(s.meteor.x * K + 3, s.meteor.y * K + K - 3); ctx.stroke(); ctx.globalAlpha = 1; }
    s.bombs.forEach(function (b) { disc(b.x, b.y, th.bomb); label('B', b.x, b.y, '#fff'); });
    s.powerUps.forEach(function (p) { const pw = SU.engine.POWERS[p.type]; if (p.life < 3 && Math.floor(now / 200) % 2) return; disc(p.x, p.y, pw.color); label(pw.tag, p.x, p.y, '#fff', 9); });
    if (s.box) { ctx.fillStyle = '#f1c40f'; ctx.fillRect(s.box.x * K + 1, s.box.y * K + 1, K - 2, K - 2); label('?', s.box.x, s.box.y, '#000', 11); }
    if (s.shadow) { ctx.fillStyle = 'rgba(0,0,0,0.75)'; ctx.fillRect(s.shadow.x * K, s.shadow.y * K, K, K); ctx.fillStyle = '#fff'; ctx.fillRect(s.shadow.x * K + 3, s.shadow.y * K + 4, 3, 3); ctx.fillRect(s.shadow.x * K + K - 6, s.shadow.y * K + 4, 3, 3); }

    const E = SU.engine, ghost = E.isActive(s, 'ghost'), slide = E.sliding(s);
    ctx.globalAlpha = ghost ? 0.5 : 1;
    for (let i = s.snake.length - 1; i > 0; i--) {
      const seg = s.snake[i], r = i / s.snake.length;
      ctx.fillStyle = slide ? 'hsl(210,100%,' + (60 - r * 10) + '%)' : s.fury > 0 ? 'hsl(0,100%,' + (50 + r * 10) + '%)' : th.snake;
      ctx.beginPath(); ctx.roundRect(seg.x * K + 1, seg.y * K + 1, K - 2, K - 2, 4); ctx.fill();
    }
    const h = s.snake[0], d = s.dir;
    ctx.fillStyle = E.isActive(s, 'shield') ? E.POWERS.shield.color : s.fury > 0 ? '#ff2d2d' : th.head;
    ctx.beginPath(); ctx.roundRect(h.x * K, h.y * K, K, K, 4); ctx.fill();
    if (E.isActive(s, 'shield')) { ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(cx(h.x), cx(h.y), K / 2 + 1, 0, 6.283); ctx.stroke(); ctx.lineWidth = 1; }
    ctx.fillStyle = '#fff';
    const ox = d.y !== 0 ? 4 : (d.x > 0 ? 11 : 4), oy = d.x !== 0 ? 4 : (d.y > 0 ? 11 : 4);
    const e1 = d.x !== 0 ? { x: ox, y: 4 } : { x: 4, y: oy }, e2 = d.x !== 0 ? { x: ox, y: 11 } : { x: 11, y: oy };
    [e1, e2].forEach(function (e) { ctx.beginPath(); ctx.arc(h.x * K + e.x, h.y * K + e.y, 1.6, 0, 6.283); ctx.fill(); });
    ctx.globalAlpha = 1;
    FX.list.forEach(function (p) {
      ctx.globalAlpha = Math.max(0, p.life);
      if (p.k === 't') { ctx.fillStyle = p.c; ctx.font = 'bold 14px sans-serif'; ctx.fillText(p.t, p.x, p.y); }
      else { ctx.fillStyle = p.c; ctx.beginPath(); ctx.arc(p.x, p.y, 2.5, 0, 6.283); ctx.fill(); }
    });
    ctx.globalAlpha = 1;
  }
  SU.render = { draw: draw, THEMES: THEMES };
  /* Polyfill roundRect untuk WebView lama (path tertutup & aman dipakai dengan fill()). */
  if (g.CanvasRenderingContext2D && !g.CanvasRenderingContext2D.prototype.roundRect) {
    g.CanvasRenderingContext2D.prototype.roundRect = function (x, y, w, h, r) {
      r = Math.min(r || 0, w / 2, h / 2); this.moveTo(x + r, y); this.arcTo(x + w, y, x + w, y + h, r); this.arcTo(x + w, y + h, x, y + h, r);
      this.arcTo(x, y + h, x, y, r); this.arcTo(x, y, x + w, y, r); this.closePath();
    };
  }
})(typeof window !== 'undefined' ? window : globalThis);
