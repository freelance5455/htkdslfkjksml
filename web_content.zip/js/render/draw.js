/* Kreslení primitiv na canvas – věž, bublina, střela, efekty.
   Souřadnice objektů jsou v „buňkách“, c = velikost buňky v pixelech.
   Používá hra i animované pozadí menu.
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  var TT = BD.systems.towers.TYPES, ET = BD.systems.enemies.TYPES;
  var TAU = Math.PI * 2;

  function shade(hex, a) {
    var n = parseInt(hex.slice(1), 16), r = n >> 16, g = (n >> 8) & 255, b = n & 255;
    var t = a < 0 ? 0 : 255, p = Math.abs(a);
    r = Math.round(r + (t - r) * p); g = Math.round(g + (t - g) * p); b = Math.round(b + (t - b) * p);
    return 'rgb(' + r + ',' + g + ',' + b + ')';
  }
  function shadeHex(hex, a) {
    var m = shade(hex, a).match(/\d+/g);
    return '#' + m.map(function (v) { return ('0' + (+v).toString(16)).slice(-2); }).join('');
  }
  function hexA(hex, a) { var n = parseInt(hex.slice(1), 16); return 'rgba(' + (n >> 16) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')'; }

  function rr(ctx, x, y, w, h, r) {
    r = Math.min(r, w / 2, h / 2);
    ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
  }

  /* věž: tmavý kruh s bílým okrajem, modré bublinky v rozích, barevné jádro, drobné bublinky = hloubka ve stromě vylepšení */
  function bubble(ctx, x, y, r, col) {
    var g = ctx.createRadialGradient(x - r * 0.35, y - r * 0.35, r * 0.1, x, y, r);
    g.addColorStop(0, shade(col, 0.55)); g.addColorStop(1, col);
    ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fillStyle = g; ctx.fill();
    ctx.lineWidth = Math.max(1, r * 0.14); ctx.strokeStyle = 'rgba(255,255,255,.85)'; ctx.stroke();
  }
  function tower(ctx, t, c) {
    var D = TT[t.type], U = c * BD.SUB, s = t.size / BD.SUB, x = t.x * c, y = t.y * c, S = t.size * c, cx = x + S / 2, cy = y + S / 2;
    var TW = BD.systems.towers, bi = D.parent && TW.TYPES[D.parent] && TW.TYPES[D.parent].parent !== undefined && D.parent !== 'base' ? TW.children(D.parent).findIndex(function (d) { return d.id === D.id; }) : -1, col = D.color;
    var depth = 0; for (var pd = D; pd && pd.parent && depth < 12; pd = TW.TYPES[pd.parent]) depth++;                     // hloubka ve stromě (základna 0, druh 1, jeho vylepšení 2…)
    if (bi === 1) col = shadeHex(col, 0.18); else if (bi === 2) col = shadeHex(col, -0.18);
    var k = Math.min(s, 2), R = S * 0.36;
    var i;
    var spr = BD.systems.towers.look(t);
    if (spr) {                                             // vlastní vzhled (Studio / data věže): otáčí se podle t.angle; podle úrovně a větve se může měnit
      BD.render.sprite.draw(ctx, spr, cx, cy, S / 2, { t: clock(), aim: D.role === 'shot' ? t.angle : 0 });
    } else {
      for (i = 0; i < 4; i++) bubble(ctx, x + (i % 2 ? S - S * 0.17 : S * 0.17), y + (i > 1 ? S - S * 0.17 : S * 0.17), S * 0.15, '#2e8dc0');
      ctx.beginPath(); ctx.arc(cx, cy, R, 0, TAU); ctx.fillStyle = '#1d6485'; ctx.fill();
      ctx.lineWidth = Math.max(2, S * 0.05) + (t.tier ? 1.5 : 0); ctx.strokeStyle = '#fff'; ctx.stroke();
      ctx.save(); ctx.translate(cx, cy);
      var core = R * 0.5;
      if (D.role === 'burst') {
        ctx.lineWidth = Math.max(1.5, S * 0.03); ctx.strokeStyle = 'rgba(255,255,255,.35)';
        ctx.beginPath(); ctx.arc(0, 0, R * 0.78, 0, TAU); ctx.stroke();
      } else if (D.role === 'shot' && D.onlyGhost) {
        ctx.lineWidth = Math.max(1.5, S * 0.03); ctx.strokeStyle = 'rgba(255,255,255,.35)';
        ctx.beginPath(); ctx.arc(0, 0, R * 0.8, 0, TAU); ctx.stroke(); ctx.beginPath(); ctx.arc(0, 0, R * 0.62, 0, TAU); ctx.stroke();
      }
      bubble(ctx, 0, 0, core, col);
      var n = D.role === 'boost' ? 4 : Math.max(1, Math.min(8, depth + 1));              /* satelity kolem jádra */
      var sr = core * (D.role === 'boost' ? 0.34 : 0.42), orb = core + sr * 0.45;
      var a0 = D.role === 'shot' ? t.angle : 0;
      for (i = 0; i < n; i++) {
        var a = a0 + i * TAU / n + (D.role === 'boost' ? Math.PI / 4 : 0);
        bubble(ctx, Math.cos(a) * orb, Math.sin(a) * orb, sr, D.role === 'boost' ? '#ff6a4d' : shade(col, 0.1));
      }
      ctx.restore();
    }
    for (i = 0; i < t.tier; i++) {
      ctx.beginPath(); ctx.arc(cx, cy, R + U * 0.1 * (i + 1) * k * 0.6, 0, TAU);
      ctx.strokeStyle = 'rgba(255,255,255,.3)'; ctx.lineWidth = 1.5; ctx.stroke();
    }
    if (t.s && t.hp < t.s.hp) {                            /* poškozená věž: pruh životů */
      var hp = Math.max(0, t.hp / t.s.hp), bw = S * 0.7;
      ctx.fillStyle = 'rgba(0,0,0,.65)'; ctx.fillRect(cx - bw / 2, y - 2, bw, 4);
      ctx.fillStyle = hp > 0.5 ? '#40b89a' : hp > 0.25 ? '#e3a23a' : '#e56b61'; ctx.fillRect(cx - bw / 2, y - 2, bw * hp, 4);
    }
    if (t.boost > 1) {                                     /* zesílená věž: žlutý proužek nahoře */
      ctx.fillStyle = '#f0bf4c'; ctx.fillRect(cx - S * 0.18, y + S * 0.02, S * 0.36, Math.max(2, S * 0.05));
    }
  }

  function clock() { return (typeof performance !== 'undefined' ? performance.now() : Date.now()) / 1000; }

  function enemy(ctx, e, c) {
    var B = ET[e.type], r = B.r * c, x = e.x * c, y = e.y * c;
    if (B.ghost) ctx.globalAlpha = 0.6;
    if (B.sprite) {                                       // vlastní vzhled ze Studia
      BD.render.sprite.draw(ctx, B.sprite, x, y, r, { t: clock() + (e.id || 0) * 0.37, aim: 0, alpha: 1 });
      if (e.slow > 0) { ctx.beginPath(); ctx.arc(x, y, r + 2.5, 0, TAU); ctx.strokeStyle = '#7fe3cf'; ctx.lineWidth = 1.5; ctx.setLineDash([3, 3]); ctx.stroke(); ctx.setLineDash([]); }
      ctx.globalAlpha = 1; enemyBar(ctx, e, x, y, r); return;
    }
    var gr = ctx.createRadialGradient(x - r * 0.35, y - r * 0.35, r * 0.1, x, y, r);
    gr.addColorStop(0, shade(B.color, 0.6)); gr.addColorStop(1, hexA(B.color, 0.92));
    ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fillStyle = gr; ctx.fill();
    ctx.lineWidth = e.type === 'boss' ? 3 : 1.5; ctx.strokeStyle = shade(B.color, 0.35); ctx.stroke();
    ctx.beginPath(); ctx.ellipse(x - r * 0.3, y - r * 0.38, r * 0.25, r * 0.14, -0.6, 0, TAU); ctx.fillStyle = 'rgba(255,255,255,.55)'; ctx.fill();
    if (e.slow > 0) {
      ctx.beginPath(); ctx.arc(x, y, r + 2.5, 0, TAU); ctx.strokeStyle = '#7fe3cf'; ctx.lineWidth = 1.5;
      ctx.setLineDash([3, 3]); ctx.stroke(); ctx.setLineDash([]);
    }
    ctx.globalAlpha = 1;
    enemyBar(ctx, e, x, y, r);
  }
  function enemyBar(ctx, e, x, y, r) {
    if (e.hp < e.maxhp) {
      var w = Math.max(r * 2, 14), p = Math.max(0, e.hp / e.maxhp), by = y - r - 7;
      ctx.fillStyle = 'rgba(0,0,0,.6)'; ctx.fillRect(x - w / 2, by, w, 3.5);
      ctx.fillStyle = p > 0.5 ? '#40b89a' : p > 0.25 ? '#e3a23a' : '#e56b61'; ctx.fillRect(x - w / 2, by, w * p, 3.5);
    }
  }

  function shot(ctx, s, c) {
    var R = BD.render.ammo, am = R && s.am ? R.get(s.am) : null;
    if (am && R.shot(ctx, s, am, c, clock())) return;                      // vlastní tvar střely; jinak původní kulička
    ctx.beginPath(); ctx.arc(s.x * c, s.y * c, c * BD.SUB * (s.splash ? 0.13 : 0.075) * (1 + 0.5 * s.big), 0, TAU);
    ctx.fillStyle = shade(s.color, 0.5); ctx.fill();
  }

  function fx(ctx, f, c) {
    if (f.t < 0) return;                                  // zpožděný efekt ještě nezačal
    var p = f.t / f.life;
    if (f.kind === 'ammo') {                                // výstřel / dopad střeliva
      var R = BD.render.ammo, am = R.get(f.am); R.phase(ctx, am[f.ph], f.x * c, f.y * c, c, p, f.aim || 0, clock()); return;
    }
    if (f.kind === 'pop') {
      ctx.beginPath(); ctx.arc(f.x * c, f.y * c, c * BD.SUB * (0.15 + (f.big ? 1.2 : 0.5) * p), 0, TAU);
      ctx.strokeStyle = hexA(f.color, 1 - p); ctx.lineWidth = 2.5; ctx.stroke();
    } else if (f.kind === 'ring') {
      ctx.beginPath(); ctx.arc(f.x * c, f.y * c, c * f.r * (0.3 + 0.7 * p), 0, TAU);
      ctx.fillStyle = hexA(f.color, 0.18 * (1 - p)); ctx.fill(); ctx.strokeStyle = hexA(f.color, 0.8 * (1 - p)); ctx.lineWidth = 2; ctx.stroke();
    } else if (f.kind === 'flash') {                        // atomovka: celoplošný záblesk
      ctx.globalAlpha = Math.max(0, 0.9 * (1 - p) * (1 - p)); ctx.fillStyle = f.color; ctx.fillRect(-5000, -5000, 10000, 10000); ctx.globalAlpha = 1;
    } else if (f.kind === 'meteor') {                       // meteorit padá šikmo shora doleva
      var d = 7 * BD.SUB * (1 - p), hx = (f.x - d * 0.45) * c, hy = (f.y - d) * c, tx = hx - c * BD.SUB * 1.4 * 0.45, ty = hy - c * BD.SUB * 1.4;
      var g = ctx.createLinearGradient(tx, ty, hx, hy); g.addColorStop(0, 'rgba(255,140,60,0)'); g.addColorStop(1, 'rgba(255,200,120,.95)');
      ctx.strokeStyle = g; ctx.lineWidth = Math.max(3, c * 0.45); ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(tx, ty); ctx.lineTo(hx, hy); ctx.stroke(); ctx.lineCap = 'butt';
      ctx.beginPath(); ctx.arc(hx, hy, Math.max(3, c * 0.38), 0, TAU); ctx.fillStyle = '#fff1c9'; ctx.fill();
    } else if (f.kind === 'zap') {                          // nepřítel útočí na věž
      ctx.strokeStyle = hexA(f.color, 1 - p); ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(f.x * c, f.y * c); ctx.lineTo(f.x2 * c, f.y2 * c); ctx.stroke();
    } else if (f.kind === 'text') {
      ctx.globalAlpha = 1 - p; ctx.font = '700 ' + Math.max(10, c * BD.SUB * 0.36) + 'px Sora, sans-serif';
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = f.color;
      ctx.fillText(f.text, f.x * c, (f.y - p * 1.4) * c); ctx.globalAlpha = 1;
    }
  }

  BD.render.draw = { shade: shade, hexA: hexA, rr: rr, tower: tower, enemy: enemy, shot: shot, fx: fx, TAU: TAU };
})(window.BD);
