/* Střelivo – společné kreslení fází (výstřel / let / dopad) pro hru i Studio.
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  var SP = BD.render.sprite, TAU = Math.PI * 2;
  function clamp(v, a, b) { return Math.min(b, Math.max(a, v)); }
  function lerp(a, b, k) { return a + (b - a) * k; }
  function get(id) { var A = BD.data.ammo; return (id && A[id]) || A.default; }

  /* nakreslí tvar fáze se středem (cx,cy) [px]; cell = px na buňku; k = 0..1 průběh fáze; aim = směr (rad) */
  function phase(ctx, ph, cx, cy, cell, k, aim, t, extra) {
    if (!ph || !ph.sprite || !ph.sprite.nodes) return false;
    k = clamp(k, 0, 1);
    var s = lerp(ph.s0 == null ? 1 : ph.s0, ph.s1 == null ? 1 : ph.s1, k), a = lerp(ph.a0 == null ? 1 : ph.a0, ph.a1 == null ? 1 : ph.a1, k);
    var r = lerp(ph.r0 || 0, ph.r1 || 0, k) * Math.PI / 180 + (extra || 0);
    if (a <= 0.003 || s <= 0.003) return true;
    ctx.save(); ctx.translate(cx, cy); ctx.rotate(aim + r);
    SP.draw(ctx, ph.sprite, 0, 0, (ph.size || 1) / 2 * s * cell, { t: t || 0, aim: 0, alpha: a });
    ctx.restore(); return true;
  }
  /* střela za letu: spin = otáček/s, stopa = ztmavlé kopie na minulých pozicích */
  function shot(ctx, sh, am, cell, clock) {
    var ph = am.shot; if (!ph || !ph.sprite) return false;
    var ang = (sh.ang || 0), spin = (ph.spin || 0) * TAU * (sh.age || 0), lift = sh.lift ? -sh.lift * cell : 0;
    if (ph.trail > 0 && sh.trail) {
      var n = sh.trail.length;
      for (var i = 0; i < n; i++) {
        var p = sh.trail[i], f = (i + 1) / (n + 1);
        ctx.save(); ctx.translate(p.x * cell, p.y * cell + (p.l ? -p.l * cell : 0)); ctx.rotate(p.a + spin);
        SP.draw(ctx, ph.sprite, 0, 0, ph.size / 2 * (0.4 + 0.6 * f) * cell, { t: clock, aim: 0, alpha: 0.5 * f }); ctx.restore();
      }
    }
    ctx.save(); ctx.translate(sh.x * cell, sh.y * cell + lift); ctx.rotate(ang + spin);
    SP.draw(ctx, ph.sprite, 0, 0, ph.size / 2 * cell, { t: clock, aim: 0 }); ctx.restore(); return true;
  }
  BD.render.ammo = { get: get, phase: phase, shot: shot, clamp: clamp, lerp: lerp };
})(window.BD);
