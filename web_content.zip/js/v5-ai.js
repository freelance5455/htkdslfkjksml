
/* My Study Life V5 - AI workspace
   Local-first UI. Optional secure backend endpoint can be configured.
   Never put a private API key in this file or inside the APK.
*/
const AI_HISTORY_KEY="msl_ai_history";
let aiMode="explain";
let aiImageFile=null;

function aiEsc(s){return String(s||"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function getAiHistory(){try{return JSON.parse(localStorage.getItem(AI_HISTORY_KEY)||"[]")}catch{return[]}}
function saveAiHistory(h){localStorage.setItem(AI_HISTORY_KEY,JSON.stringify(h.slice(0,12)))}

function buildPrompt(){
 const prompt=document.getElementById("aiPrompt")?.value.trim()||"";
 const subject=document.getElementById("aiSubject")?.value||"auto";
 const level=document.getElementById("aiLevel")?.value||"terminale";
 const labels={explain:"Explique clairement",solve:"Résous étape par étape",summary:"Fais une fiche de révision structurée",quiz:"Crée un mini-quiz avec corrections"};
 return `${labels[aiMode]||labels.explain}. Niveau: ${level}. Matière: ${subject}. ${prompt||"Analyse l'image fournie et aide-moi à comprendre."}`;
}

function renderHistory(){
 const box=document.getElementById("aiHistoryList");if(!box)return;
 const h=getAiHistory();
 box.innerHTML=h.length?h.map((x,i)=>`
  <button class="v5-history-item" data-history="${i}">
   <span>${x.mode==="solve"?"📸":x.mode==="summary"?"📝":x.mode==="quiz"?"🎯":"🧠"}</span>
   <span><strong>${aiEsc(x.title)}</strong><small>${aiEsc(x.date)}</small></span><span>›</span>
  </button>`).join(""):'<div class="v4-empty">Aucune demande enregistrée.</div>';
}

async function fileToDataURL(file){
 return new Promise((resolve,reject)=>{
  const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(file);
 })
}

async function callSecureEndpoint(payload){
 const endpoint=localStorage.getItem("msl_ai_endpoint");
 if(!endpoint)return null;
 try{
  const r=await fetch(endpoint,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
  if(!r.ok)throw new Error("HTTP "+r.status);
  return await r.json();
 }catch(e){
  console.warn("AI endpoint:",e);return {error:"Connexion au service IA impossible."};
 }
}

function localDemoResponse(){
 const text={
  explain:"Mode IA prêt. Pour obtenir une vraie réponse générée, connecte l'application à ton serveur IA sécurisé.",
  solve:"Mode résolution prêt. Ajoute une photo claire de l'exercice puis connecte un service IA sécurisé pour recevoir une résolution étape par étape.",
  summary:"Mode fiche de révision prêt. La V5 préparera la structure de la fiche dès qu'un service IA sécurisé sera connecté.",
  quiz:"Mode quiz prêt. Un service IA connecté pourra générer des questions adaptées à ta matière et ton niveau."
 };
 return `<div class="v5-demo-box"><strong>${aiEsc(text[aiMode])}</strong><p>Ta demande est correctement préparée. Aucune clé secrète n'est stockée dans l'application.</p></div>`;
}

async function sendAi(){
 const btn=document.getElementById("aiSendBtn");
 const result=document.getElementById("aiResult");
 const body=document.getElementById("aiResultBody");
 const title=document.getElementById("aiResultTitle");
 if(!btn||!result||!body)return;
 btn.disabled=true;btn.textContent="Préparation…";
 const prompt=buildPrompt();
 let imageData=null;
 if(aiImageFile){
  try{imageData=await fileToDataURL(aiImageFile)}catch{}
 }
 const payload={mode:aiMode,prompt,subject:document.getElementById("aiSubject")?.value,level:document.getElementById("aiLevel")?.value,image:imageData};
 const response=await callSecureEndpoint(payload);
 result.classList.remove("hidden");
 if(response&&!response.error){
  title.textContent=response.title||"Réponse IA";
  body.innerHTML=response.html||`<pre class="v5-plain-result">${aiEsc(response.text||JSON.stringify(response))}</pre>`;
 }else{
  title.textContent="Demande préparée";
  body.innerHTML=response?.error?`<div class="v5-demo-box"><strong>${aiEsc(response.error)}</strong>${localDemoResponse()}</div>`:localDemoResponse();
 }
 const history=getAiHistory();
 history.unshift({mode:aiMode,title:prompt.slice(0,80)||"Nouvelle demande",date:new Date().toLocaleString("fr-FR"),preview:body.innerText.slice(0,180),result:body.innerHTML});
 saveAiHistory(history);renderHistory();
 btn.disabled=false;btn.textContent="✦ Préparer ma demande";
}

function setImage(file){
 if(!file||!file.type.startsWith("image/"))return;
 aiImageFile=file;
 const img=document.getElementById("aiPreviewImg");
 const box=document.getElementById("aiImagePreview");
 if(img)img.src=URL.createObjectURL(file);
 box?.classList.remove("hidden");
}
function clearImage(){
 aiImageFile=null;document.getElementById("aiImageInput").value="";
 document.getElementById("aiImagePreview")?.classList.add("hidden");
}

document.addEventListener("DOMContentLoaded",()=>{
 document.querySelectorAll(".v5-mode").forEach(b=>b.addEventListener("click",()=>{
  document.querySelectorAll(".v5-mode").forEach(x=>x.classList.remove("active"));b.classList.add("active");aiMode=b.dataset.aiMode;
  const p=document.getElementById("aiPrompt");if(p)p.placeholder={explain:"Exemple : Explique-moi cette notion simplement…",solve:"Exemple : Résous cet exercice étape par étape…",summary:"Exemple : Fais une fiche avec les définitions et formules…",quiz:"Exemple : Fais-moi 10 questions pour réviser…"}[aiMode];
 }));
 const input=document.getElementById("aiImageInput");
 document.getElementById("aiGalleryBtn")?.addEventListener("click",()=>input?.click());
 document.getElementById("aiCameraBtn")?.addEventListener("click",()=>{if(input){input.setAttribute("capture","environment");input.click()}});
 input?.addEventListener("change",e=>setImage(e.target.files?.[0]));
 document.getElementById("removeAiImage")?.addEventListener("click",clearImage);
 document.getElementById("aiSendBtn")?.addEventListener("click",sendAi);
 document.getElementById("clearAiHistory")?.addEventListener("click",()=>{localStorage.removeItem(AI_HISTORY_KEY);renderHistory()});
 document.getElementById("copyAiResult")?.addEventListener("click",async()=>{try{await navigator.clipboard.writeText(document.getElementById("aiResultBody").innerText);toast("Réponse copiée.")}catch{toast("Copie non disponible.")}});
 document.getElementById("aiHistoryList")?.addEventListener("click",e=>{
  const b=e.target.closest("[data-history]");if(!b)return;
  const x=getAiHistory()[Number(b.dataset.history)];if(!x)return;
  document.getElementById("aiResult").classList.remove("hidden");document.getElementById("aiResultTitle").textContent="Demande précédente";document.getElementById("aiResultBody").innerHTML=x.result||`<p>${aiEsc(x.preview)}</p>`;
 });
 renderHistory();
});
