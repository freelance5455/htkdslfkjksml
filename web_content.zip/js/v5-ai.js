/* My Study Life - Study IA Hub
   One interface, multiple providers, shared context/history.
   API secrets should be kept on a secure backend for a public APK.
*/
const AI_STATE_KEY='msl_ai_hub_state_v1';
const AI_HISTORY_KEY='msl_ai_history';
let aiMode='explain';
let aiImageFile=null;
let aiPdfFile=null;
let aiBusy=false;

const AI_PROVIDERS={
  gemini:{name:'Gemini',icon:'✦',kind:'gemini',hint:'Google AI',defaultModel:'gemini-3.1-flash-lite-preview'},
  grok:{name:'Grok',icon:'𝕏',kind:'openai-compatible',hint:'xAI',defaultModel:'grok-4.1-fast',defaultEndpoint:'https://api.x.ai/v1/chat/completions'},
  openai:{name:'OpenAI',icon:'◉',kind:'openai-compatible',hint:'OpenAI',defaultModel:'',defaultEndpoint:'https://api.openai.com/v1/chat/completions'},
  custom:{name:'Autre IA',icon:'◎',kind:'custom',hint:'Serveur compatible',defaultModel:'',defaultEndpoint:''}
};

function aiEsc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function getState(){try{return JSON.parse(localStorage.getItem(AI_STATE_KEY)||'{}')}catch{return{}}}
function saveState(s){localStorage.setItem(AI_STATE_KEY,JSON.stringify(s));}
function getHistory(){try{return JSON.parse(localStorage.getItem(AI_HISTORY_KEY)||'[]')}catch{return[]}}
function saveHistory(h){localStorage.setItem(AI_HISTORY_KEY,JSON.stringify(h.slice(0,20)));}
function provider(){return getState().provider||'gemini'}
function providerInfo(){return AI_PROVIDERS[provider()]||AI_PROVIDERS.gemini}
function configFor(id){const s=getState();const x=AI_PROVIDERS[id]||{};return s.configs?.[id]||{model:x.defaultModel||'',endpoint:x.defaultEndpoint||'',key:''}}
function toastSafe(msg){if(typeof toast==='function')toast(msg);else console.log(msg)}

function buildPrompt(){
 const p=document.getElementById('aiPrompt')?.value.trim()||'';
 const subject=document.getElementById('aiSubject')?.value||'auto';
 const level=document.getElementById('aiLevel')?.value||'terminale';
 const labels={explain:'Explique clairement et pédagogiquement',solve:'Résous étape par étape en montrant les calculs',summary:'Transforme le contenu en fiche de révision structurée',quiz:'Crée un quiz progressif avec corrections'};
 return `${labels[aiMode]||labels.explain}. Niveau scolaire: ${level}. Matière: ${subject}. ${p||'Analyse le document fourni et aide-moi à comprendre.'}`;
}

function renderProviderStrip(){
 const box=document.getElementById('aiProviderStrip');if(!box)return;
 const active=provider();
 box.innerHTML=Object.entries(AI_PROVIDERS).map(([id,x])=>`<button class="ai-provider-chip ${id===active?'active':''}" data-provider="${id}"><span>${x.icon}</span><b>${aiEsc(x.name)}</b><small>${aiEsc(x.hint)}</small></button>`).join('');
 box.querySelectorAll('[data-provider]').forEach(b=>b.addEventListener('click',()=>selectProvider(b.dataset.provider)));
 const label=document.getElementById('aiActiveProvider');if(label){const x=providerInfo();label.innerHTML=`${x.icon} ${aiEsc(x.name)}`;}
}

function selectProvider(id){
 if(!AI_PROVIDERS[id])return;
 const s=getState();s.provider=id;saveState(s);renderProviderStrip();renderProviderPanel();
 toastSafe(`${AI_PROVIDERS[id].name} est maintenant le moteur actif.`);
}

function renderProviderPanel(){
 const s=getState(), id=provider(), c=configFor(id), x=providerInfo();
 const model=document.getElementById('aiModelInput'); const endpoint=document.getElementById('aiEndpointInput'); const key=document.getElementById('aiKeyInput');
 if(model)model.value=c.model||x.defaultModel||'';
 if(endpoint)endpoint.value=c.endpoint||'';
 if(key)key.value=c.key||'';
 const name=document.getElementById('aiSettingsProvider');if(name)name.textContent=`${x.icon} ${x.name}`;
 const hint=document.getElementById('aiProviderHint');if(hint)hint.textContent=id==='custom'?'Ton serveur peut appeler n’importe quelle IA et garder les clés côté serveur.':`Connexion ${x.name}. Pour une APK publique, utilise de préférence ton serveur sécurisé.`;
 const direct=document.getElementById('aiKeyRow'); if(direct)direct.classList.toggle('hidden',id==='custom');
}

function saveProviderConfig(){
 const id=provider(),s=getState();s.configs=s.configs||{};s.configs[id]={model:document.getElementById('aiModelInput')?.value.trim()||'',endpoint:document.getElementById('aiEndpointInput')?.value.trim()||'',key:document.getElementById('aiKeyInput')?.value.trim()||''};saveState(s);renderProviderPanel();toastSafe(`Configuration ${AI_PROVIDERS[id].name} enregistrée.`);
}

async function fileData(file){if(!file)return null;return new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result);r.onerror=rej;r.readAsDataURL(file)})}
function dataPart(dataUrl){const m=String(dataUrl||'').match(/^data:([^;]+);base64,(.+)$/);return m?{mime:m[1],data:m[2]}:null}

async function callBackend(payload){
 const c=configFor('custom'); if(!c.endpoint)return {error:'Aucun serveur personnalisé configuré.'};
 try{const r=await fetch(c.endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});const d=await r.json().catch(()=>({}));return r.ok?d:{error:d.error||`Erreur HTTP ${r.status}`};}catch(e){return{error:'Serveur IA inaccessible.'}}
}

async function callGemini(payload,c){
 if(!c.key)return{error:'Clé Gemini non configurée.'};
 const model=c.model||AI_PROVIDERS.gemini.defaultModel;
 const endpoint=c.endpoint||`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;
 const context=payload.conversation?.length?`\n\nCONTEXTE DE LA CONVERSATION PARTAGÉE:\n${payload.conversation.map((x,i)=>`[${i+1}] ${x.provider}: ${x.request}\nRéponse précédente: ${x.response}`).join('\n\n')}\n`:'';
 const parts=[{text:payload.prompt+context}];
 const img=dataPart(payload.image),pdf=dataPart(payload.pdf);
 if(img)parts.push({inline_data:{mime_type:img.mime,data:img.data}});
 if(pdf)parts.push({inline_data:{mime_type:pdf.mime,data:pdf.data}});
 try{const r=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':c.key},body:JSON.stringify({contents:[{parts}],generationConfig:{temperature:.25}})});const d=await r.json().catch(()=>({}));if(!r.ok)return{error:d?.error?.message||`Erreur HTTP ${r.status}`};const t=d?.candidates?.[0]?.content?.parts?.map(x=>x.text||'').join('\n').trim();return t?{text:t}: {error:'Gemini n’a renvoyé aucun texte.'};}catch(e){return{error:'Connexion Gemini impossible.'}}
}

async function callCompatible(payload,c,id){
 if(!c.key)return{error:`Clé ${AI_PROVIDERS[id].name} non configurée.`};
 const endpoint=c.endpoint||AI_PROVIDERS[id].defaultEndpoint||'';if(!endpoint)return{error:`URL API ${AI_PROVIDERS[id].name} non configurée.`};
 const context=payload.conversation?.length?`\n\nCONTEXTE DE LA CONVERSATION PARTAGÉE:\n${payload.conversation.map((x,i)=>`[${i+1}] ${x.provider}: ${x.request}\nRéponse précédente: ${x.response}`).join('\n\n')}\n`:'';
 const content=[{type:'text',text:payload.prompt+context}];
 if(payload.image)content.push({type:'image_url',image_url:{url:payload.image}});
 try{const r=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${c.key}`},body:JSON.stringify({model:c.model,messages:[{role:'user',content}],temperature:.25})});const d=await r.json().catch(()=>({}));if(!r.ok)return{error:d?.error?.message||`Erreur HTTP ${r.status}`};const t=d?.choices?.[0]?.message?.content;return t?{text:t}:{error:'Le fournisseur n’a renvoyé aucun texte.'};}catch(e){return{error:`Connexion ${AI_PROVIDERS[id].name} impossible.`}}
}

async function askAI(payload){
 const id=provider(),c=configFor(id);
 if(id==='custom')return callBackend(payload);
 if(id==='gemini')return callGemini(payload,c);
 return callCompatible(payload,c,id);
}

async function askWithFallback(payload){
 const result=await askAI(payload);if(!result?.error)return result;
 const s=getState();const fallback=s.fallback;
 if(fallback&&fallback!==provider()&&AI_PROVIDERS[fallback]){const original=s.provider;s.provider=fallback;saveState(s);renderProviderStrip();renderProviderPanel();const second=await askAI(payload);s.provider=original;saveState(s);renderProviderStrip();renderProviderPanel();if(!second?.error)return {...second,fallbackUsed:fallback};}
 return result;
}

function setFilePreview(file,type){
 if(type==='image'){aiImageFile=file;const img=document.getElementById('aiPreviewImg');if(img)img.src=URL.createObjectURL(file);document.getElementById('aiImagePreview')?.classList.remove('hidden');}
 else {aiPdfFile=file;const box=document.getElementById('aiPdfPreview');if(box){box.classList.remove('hidden');box.innerHTML=`📄 <b>${aiEsc(file.name)}</b><button id="removeAiPdf" class="v5-remove-inline">✕</button>`;document.getElementById('removeAiPdf').onclick=clearPdf;}}
}
function clearImage(){aiImageFile=null;const i=document.getElementById('aiImageInput');const c=document.getElementById('aiCameraInput');if(i)i.value='';if(c)c.value='';document.getElementById('aiImagePreview')?.classList.add('hidden')}
function clearPdf(){aiPdfFile=null;const i=document.getElementById('aiPdfInput');if(i)i.value='';document.getElementById('aiPdfPreview')?.classList.add('hidden')}

function renderHistory(){
 const box=document.getElementById('aiHistoryList');if(!box)return;const h=getHistory();
 box.innerHTML=h.length?h.map((x,i)=>`<button class="v5-history-item" data-history="${i}"><span>${aiEsc(x.icon||'✦')}</span><span><strong>${aiEsc(x.title)}</strong><small>${aiEsc(x.date)} · ${aiEsc(x.provider||'IA')}</small></span><span>›</span></button>`).join(''):'<div class="v4-empty">Aucune demande enregistrée.</div>';
}

async function sendAi(){
 if(aiBusy)return;aiBusy=true;const btn=document.getElementById('aiSendBtn');const body=document.getElementById('aiResultBody');const result=document.getElementById('aiResult');const title=document.getElementById('aiResultTitle');
 if(btn){btn.disabled=true;btn.textContent='✦ Réflexion en cours…'}
 try{
  const payload={mode:aiMode,prompt:buildPrompt(),subject:document.getElementById('aiSubject')?.value||'auto',level:document.getElementById('aiLevel')?.value||'terminale',image:await fileData(aiImageFile),pdf:await fileData(aiPdfFile),conversation:getHistory().slice(0,6).reverse().map(x=>({provider:x.provider,title:x.title,request:x.request||'',response:x.response||x.preview||''}))};
  const r=await askWithFallback(payload);result.classList.remove('hidden');
  if(r&&!r.error){title.textContent=`${providerInfo().icon} Réponse IA${r.fallbackUsed?' · secours':''}`;body.innerHTML=r.html||`<div class="v5-answer">${aiEsc(r.text||'').replace(/\n/g,'<br>')}</div>`;}
  else{title.textContent='Connexion IA';body.innerHTML=`<div class="v5-demo-box"><strong>${aiEsc(r?.error||'Configuration requise.')}</strong><p>Choisis un moteur, configure sa connexion, puis relance la demande.</p><button class="btn primary" id="openAiSettingsInline">⚙ Configurer l’IA</button></div>`;document.getElementById('openAiSettingsInline')?.addEventListener('click',openAiSettings);}
  const h=getHistory();h.unshift({mode:aiMode,icon:providerInfo().icon,provider:providerInfo().name,title:payload.prompt.slice(0,75)||'Nouvelle demande',date:new Date().toLocaleString('fr-FR'),request:payload.prompt,response:body.innerText.slice(0,6000),preview:body.innerText.slice(0,200),result:body.innerHTML});saveHistory(h);renderHistory();
 }catch(e){result.classList.remove('hidden');body.innerHTML='<div class="v5-demo-box"><strong>Une erreur est survenue.</strong><p>Réessaie avec une autre configuration IA.</p></div>'}finally{aiBusy=false;if(btn){btn.disabled=false;btn.textContent='✦ Envoyer à l’IA'}}
}

function openAiSettings(){document.getElementById('aiSettingsPanel')?.classList.remove('hidden');renderProviderPanel();document.getElementById('aiSettingsPanel')?.scrollIntoView({behavior:'smooth',block:'nearest'})}
function closeAiSettings(){document.getElementById('aiSettingsPanel')?.classList.add('hidden')}

function initAI(){
 document.querySelectorAll('.v5-mode').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.v5-mode').forEach(x=>x.classList.remove('active'));b.classList.add('active');aiMode=b.dataset.aiMode}));
 document.getElementById('aiGalleryBtn')?.addEventListener('click',()=>{const i=document.getElementById('aiImageInput');if(i){i.removeAttribute('capture');i.click()}});
 document.getElementById('aiCameraBtn')?.addEventListener('click',()=>document.getElementById('aiCameraInput')?.click());
 document.getElementById('aiPdfBtn')?.addEventListener('click',()=>document.getElementById('aiPdfInput')?.click());
 document.getElementById('aiImageInput')?.addEventListener('change',e=>setFilePreview(e.target.files?.[0],'image'));
 document.getElementById('aiCameraInput')?.addEventListener('change',e=>setFilePreview(e.target.files?.[0],'image'));
 document.getElementById('aiPdfInput')?.addEventListener('change',e=>setFilePreview(e.target.files?.[0],'pdf'));
 document.getElementById('removeAiImage')?.addEventListener('click',clearImage);
 document.getElementById('aiSendBtn')?.addEventListener('click',sendAi);
 document.getElementById('openAiSettings')?.addEventListener('click',openAiSettings);
 document.getElementById('closeAiSettings')?.addEventListener('click',closeAiSettings);
 document.getElementById('saveAiProvider')?.addEventListener('click',saveProviderConfig);
 document.getElementById('clearAiHistory')?.addEventListener('click',()=>{localStorage.removeItem(AI_HISTORY_KEY);renderHistory()});
 document.getElementById('aiFallbackSelect')?.addEventListener('change',e=>{const s=getState();s.fallback=e.target.value;saveState(s)});
 document.getElementById('aiHistoryList')?.addEventListener('click',e=>{const b=e.target.closest('[data-history]');if(!b)return;const x=getHistory()[Number(b.dataset.history)];if(!x)return;document.getElementById('aiResult')?.classList.remove('hidden');document.getElementById('aiResultTitle').textContent=`${x.icon||'✦'} ${x.provider||'IA'}`;document.getElementById('aiResultBody').innerHTML=x.result||`<p>${aiEsc(x.preview)}</p>`});
 document.getElementById('copyAiResult')?.addEventListener('click',async()=>{try{await navigator.clipboard.writeText(document.getElementById('aiResultBody')?.innerText||'');toastSafe('Réponse copiée.')}catch{toastSafe('Copie non disponible.')}});
 renderProviderStrip();renderProviderPanel();renderHistory();
 const s=getState();const f=document.getElementById('aiFallbackSelect');if(f)f.value=s.fallback||'none';
}
document.addEventListener('DOMContentLoaded',initAI);
