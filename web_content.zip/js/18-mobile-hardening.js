/* ===== Mobile hardening (added): no selection / context menu / zoom ===== */
(function(){
  var ok=function(t){return t&&t.closest&&t.closest('input,textarea');};
  ['contextmenu','selectstart','dragstart','copy','cut'].forEach(function(ev){
    document.addEventListener(ev,function(e){ if(!ok(e.target)) e.preventDefault(); },{capture:true,passive:false});
  });
  ['gesturestart','gesturechange','gestureend'].forEach(function(ev){
    document.addEventListener(ev,function(e){e.preventDefault();},{passive:false});
  });
  var last=0;
  document.addEventListener('touchend',function(e){
    var n=Date.now(); if(n-last<300 && !ok(e.target)) e.preventDefault(); last=n;
  },{passive:false});
  document.addEventListener('touchmove',function(e){ if(e.touches&&e.touches.length>1) e.preventDefault(); },{passive:false});
  document.addEventListener('keydown',function(e){
    if((e.ctrlKey||e.metaKey)&&['+','-','=','0'].indexOf(e.key)>-1) e.preventDefault();
  });
  document.addEventListener('wheel',function(e){ if(e.ctrlKey) e.preventDefault(); },{passive:false});
  try{ var sel=function(){var s=getSelection&&getSelection(); if(s&&s.rangeCount&&!ok(document.activeElement)) s.removeAllRanges();};
       document.addEventListener('selectionchange',sel);}catch(_){}


  /* Android WebView: blob downloads (save backup) go through the native bridge */
  document.addEventListener('click',function(e){
    var a=e.target&&e.target.closest&&e.target.closest('a[download]');
    if(!a||!window.AndroidBridge||!AndroidBridge.saveFile||!/^blob:/.test(a.href)) return;
    e.preventDefault();
    fetch(a.href).then(function(r){return r.blob();}).then(function(b){
      var fr=new FileReader();
      fr.onload=function(){AndroidBridge.saveFile(a.download||'FFM26_Save.ffm',String(fr.result).split(',')[1]||'');};
      fr.readAsDataURL(b);
    }).catch(function(){});
  },true);

  /* Landscape during a live match; free rotation in menus */
  function setOri(land){
    try{ if(window.AndroidBridge&&AndroidBridge.setLandscape){AndroidBridge.setLandscape(!!land);return;} }catch(_){}
    try{ if(land){ var r=screen.orientation&&screen.orientation.lock&&screen.orientation.lock('landscape'); if(r&&r.catch)r.catch(function(){}); }
         else if(screen.orientation&&screen.orientation.unlock){screen.orientation.unlock();} }catch(_){}
  }
  window.addEventListener('load',function(){
    var lm=document.getElementById('live-match'); if(!lm||!window.MutationObserver) return;
    var was=false;
    new MutationObserver(function(){ var on=lm.classList.contains('on'); if(on!==was){was=on;setOri(on);} })
      .observe(lm,{attributes:true,attributeFilter:['class']});
  });
  if('serviceWorker' in navigator && /^https?:/.test(location.protocol)){
    window.addEventListener('load',function(){navigator.serviceWorker.register('sw.js').catch(function(){});});
  }
})();
