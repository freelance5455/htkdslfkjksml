(function () {
  'use strict';
  const P = (window.Pith = window.Pith || {});
  const U = P.util;
  const S = (P.state = {
    chats: [],
    activeId: null,
    profile: null,
    prefs: Object.assign({ haptics: true, textModel: 'gemini-3.8-flash', imageModel: 'gemini-nano-banana-2.1', instructions: '', sidebarOpen: true }, P.store.getJSON('prefs', {})),
    pending: [],
    imageMode: false,
    editingId: null,
    gens: new Map(),
    jump: null,
    highlightId: null,
  });
  P.prefs = S.prefs;

  // Tiny pub/sub: topics are 'list', 'chat', 'composer', 'profile'.
  const subs = {};
  S.on = (topic, fn) => { (subs[topic] = subs[topic] || new Set()).add(fn); return () => subs[topic].delete(fn); };
  S.emit = (topic, data) => { (subs[topic] || []).forEach((fn) => { try { fn(data); } catch (e) { console.error(e); } }); };

  S.newChatObj = (title) => ({ id: U.uid(), title: title || 'New chat', titleAuto: true, pinned: false, system: '', createdAt: Date.now(), updatedAt: Date.now(), messages: [] });
  S.byId = (id) => S.chats.find((c) => c.id === id) || null;
  S.active = () => S.byId(S.activeId);
  S.isBusy = (id) => S.gens.has(id);
  S.sorted = () => S.chats.slice().sort((a, b) => (a.pinned !== b.pinned ? (a.pinned ? -1 : 1) : b.updatedAt - a.updatedAt));

  S.load = async function () {
    await P.store.init();
    try { S.chats = (await P.store.all('chats')) || []; } catch (e) { S.chats = []; }
    for (const chat of S.chats) {
      chat.messages = chat.messages.filter((m) => !(m.status === 'streaming' && !m.text && !(m.attachments || []).length));
      chat.messages.forEach((m) => { if (m.status === 'streaming') { m.status = 'error'; m.error = 'This reply was interrupted.'; } });
    }
    S.profile = P.store.getJSON('profile', null);
  };

  const timers = new Map();
  S.saveChat = function (chat) {
    clearTimeout(timers.get(chat.id));
    timers.set(chat.id, setTimeout(() => { timers.delete(chat.id); P.store.put('chats', chat).catch(() => U.toast('Could not save this chat (storage is full).')); }, 350));
  };
  S.flush = function () {
    timers.forEach((t, id) => {
      clearTimeout(t);
      const chat = S.byId(id);
      if (chat) P.store.put('chats', chat).catch(() => {});
    });
    timers.clear();
  };
  S.savePrefs = () => P.store.setJSON('prefs', S.prefs);
  S.saveProfile = () => { if (!P.store.setJSON('profile', S.profile)) U.toast('Could not save your profile.'); };
  document.addEventListener('visibilitychange', () => { if (document.hidden) S.flush(); });
  window.addEventListener('pagehide', S.flush);
})();
