window.WorkspaceState={records:{active:[],archived:[]},view:'table',route:{screen:'home',page:'home',world:'fallout',game:'fallout-4',gameFilter:''}};
