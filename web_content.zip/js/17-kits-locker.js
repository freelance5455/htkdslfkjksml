(function () {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const LI = { ar: 0, en: 1, fr: 2, es: 3, pt: 4, de: 5, tr: 6 };
  const L = function () { const i = LI[state.lang]; const v = arguments[i == null ? 1 : i]; return v == null ? arguments[1] : v; };
  const fmt = (n) => Number(n).toLocaleString('en-US');
  const nm = (arr) => { const v = arr[LI[state.lang]]; return v == null ? arr[1] : v; };
  const T = (ar, en, fr, es, pt, de, tr) => [ar, en, fr, es, pt, de, tr];
  const grid = (fn) => { const a = []; for (let y = 0; y < 7; y++) for (let x = 0; x < 8; x++) a.push(fn(x, y)); return a; };
  const hash = (x, y) => ((x * 7 + y * 13 + ((x * y) % 5)) % 4);

  const RAR = [T('نادر', 'Rare', 'Rare', 'Raro', 'Raro', 'Selten', 'Nadir'), T('ملحمي', 'Epic', 'Épique', 'Épico', 'Épico', 'Episch', 'Epik'), T('أسطوري', 'Legendary', 'Légendaire', 'Legendario', 'Lendário', 'Legendär', 'Efsanevi'), T('خرافي', 'Mythic', 'Mythique', 'Mítico', 'Mítico', 'Mythisch', 'Mitik')];
  const RCOL = ['#4aa3ff', '#b36bff', '#ffb300', '#ff4d6d'];

  const KITS = [
    { id: 'basic', nat: 0, rar: -1, price: 0, name: T('القميص الأساسي', 'Classic Blue', 'Bleu classique', 'Azul clásico', 'Azul clássico', 'Klassisch Blau', 'Klasik Mavi'), shirt: '#2d6cdf', stripe: '#ffffff', sleeve: '#2d6cdf', short: '#ffffff', sock: '#2d6cdf', grid: null },
    // ---- national kits (the flag covers the whole shirt) ----
    { id: 'esp', nat: 1, rar: 0, price: 6000, name: T('إسبانيا', 'Spain', 'Espagne', 'España', 'Espanha', 'Spanien', 'İspanya'), shirt: '#c60b1e', sleeve: '#c60b1e', short: '#1b2a6b', sock: '#c60b1e', grid: grid((x, y) => (y < 2 || y > 4) ? '#c60b1e' : '#ffc400') },
    { id: 'fra', nat: 1, rar: 0, price: 7000, name: T('فرنسا', 'France', 'France', 'Francia', 'França', 'Frankreich', 'Fransa'), shirt: '#1c3f94', sleeve: '#1c3f94', short: '#ffffff', sock: '#e4002b', grid: grid((x) => x < 3 ? '#1c3f94' : x < 5 ? '#ffffff' : '#e4002b') },
    { id: 'ita', nat: 1, rar: 0, price: 7500, name: T('إيطاليا', 'Italy', 'Italie', 'Italia', 'Itália', 'Italien', 'İtalya'), shirt: '#009246', sleeve: '#0a3a9a', short: '#ffffff', sock: '#0a3a9a', grid: grid((x) => x < 3 ? '#009246' : x < 5 ? '#ffffff' : '#ce2b37') },
    { id: 'ger', nat: 1, rar: 0, price: 8000, name: T('ألمانيا', 'Germany', 'Allemagne', 'Alemania', 'Alemanha', 'Deutschland', 'Almanya'), shirt: '#dd0000', sleeve: '#111111', short: '#ffffff', sock: '#111111', grid: grid((x, y) => y < 2 ? '#111111' : y < 5 ? '#dd0000' : '#ffce00') },
    { id: 'ned', nat: 1, rar: 0, price: 9000, name: T('هولندا', 'Netherlands', 'Pays-Bas', 'Países Bajos', 'Países Baixos', 'Niederlande', 'Hollanda'), shirt: '#ffffff', sleeve: '#f36c21', short: '#f36c21', sock: '#f36c21', grid: grid((x, y) => y < 2 ? '#ae1c28' : y < 5 ? '#ffffff' : '#21468b') },
    { id: 'jpn', nat: 1, rar: 0, price: 10000, name: T('اليابان', 'Japan', 'Japon', 'Japón', 'Japão', 'Japan', 'Japonya'), shirt: '#ffffff', sleeve: '#ffffff', short: '#1b2a6b', sock: '#ffffff', grid: grid((x, y) => ((x - 3.5) * (x - 3.5) + (y - 3) * (y - 3) <= 3.6) ? '#bc002d' : '#ffffff') },
    { id: 'por', nat: 1, rar: 1, price: 12000, name: T('البرتغال', 'Portugal', 'Portugal', 'Portugal', 'Portugal', 'Portugal', 'Portekiz'), shirt: '#ff0000', sleeve: '#ff0000', short: '#006600', sock: '#ff0000', grid: grid((x, y) => (x >= 2 && x <= 4 && y >= 2 && y <= 4 && !((x === 2 || x === 4) && (y === 2 || y === 4))) ? '#ffe000' : x < 3 ? '#006600' : '#ff0000') },
    { id: 'mar', nat: 1, rar: 1, price: 14000, name: T('المغرب', 'Morocco', 'Maroc', 'Marruecos', 'Marrocos', 'Marokko', 'Fas'), shirt: '#c1272d', sleeve: '#c1272d', short: '#006233', sock: '#c1272d', grid: grid((x, y) => ((x >= 3 && x <= 4 && y >= 1 && y <= 5) || (y >= 2 && y <= 4 && x >= 2 && x <= 5)) ? '#006233' : '#c1272d') },
    { id: 'arg', nat: 1, rar: 1, price: 16000, name: T('الأرجنتين', 'Argentina', 'Argentine', 'Argentina', 'Argentina', 'Argentinien', 'Arjantin'), shirt: '#75aadb', sleeve: '#75aadb', short: '#111111', sock: '#ffffff', grid: grid((x) => [1, 0, 1, 0, 0, 1, 0, 1][x] ? '#75aadb' : '#ffffff') },
    { id: 'bra', nat: 1, rar: 2, price: 18000, name: T('البرازيل', 'Brazil', 'Brésil', 'Brasil', 'Brasil', 'Brasilien', 'Brezilya'), shirt: '#ffdf00', sleeve: '#ffdf00', short: '#1b3f9a', sock: '#ffffff', grid: grid((x, y) => { const dx = Math.abs(x - 3.5) / 3.5, dy = Math.abs(y - 3) / 3; if ((x - 3.5) * (x - 3.5) + (y - 3) * (y - 3) <= 1.7) return '#002776'; return dx + dy <= 1.02 ? '#ffdf00' : '#009c3b'; }) },
    // ---- special designs ----
    { id: 'red', nat: 0, rar: 0, price: 12000, name: T('خطوط حمراء', 'Red Stripes', 'Rayures rouges', 'Rayas rojas', 'Listras vermelhas', 'Rote Streifen', 'Kırmızı Çizgiler'), shirt: '#d32f2f', sleeve: '#d32f2f', short: '#111111', sock: '#d32f2f', grid: grid((x) => x % 2 === 0 ? '#d32f2f' : '#ffffff') },
    { id: 'hoop', nat: 0, rar: 0, price: 13000, name: T('حلقات خضراء', 'Green Hoops', 'Cerceaux verts', 'Aros verdes', 'Aros verdes', 'Grüne Ringe', 'Yeşil Halkalar'), shirt: '#1b8a3a', sleeve: '#1b8a3a', short: '#ffffff', sock: '#1b8a3a', grid: grid((x, y) => y % 2 === 0 ? '#1b8a3a' : '#ffffff') },
    { id: 'chk', nat: 0, rar: 1, price: 16000, name: T('مربعات سماوية', 'Sky Checker', 'Damier ciel', 'Damero celeste', 'Xadrez celeste', 'Himmelkaro', 'Gökyüzü Damalı'), shirt: '#7ec8ff', sleeve: '#7ec8ff', short: '#ffffff', sock: '#7ec8ff', grid: grid((x, y) => (((x >> 1) + (y >> 1)) % 2) ? '#7ec8ff' : '#ffffff') },
    { id: 'blk', nat: 0, rar: 1, price: 20000, name: T('أسود وذهبي', 'Black & Gold', 'Noir & or', 'Negro y oro', 'Preto e dourado', 'Schwarz-Gold', 'Siyah & Altın'), shirt: '#1a1a1a', sleeve: '#111111', short: '#111111', sock: '#f4c20d', grid: grid((x, y) => ((x - y + 14) % 6 < 2) ? '#f4c20d' : '#16161a') },
    { id: 'pur', nat: 0, rar: 1, price: 24000, name: T('أرجواني ملكي', 'Royal Purple', 'Violet royal', 'Púrpura real', 'Roxo real', 'Königslila', 'Kraliyet Moru'), shirt: '#5b2a9e', sleeve: '#f2c230', short: '#5b2a9e', sock: '#5b2a9e', grid: grid((x, y) => (y === 0 && x >= 2 && x <= 5) || (x >= 3 && x <= 4 && y >= 3 && y <= 4) ? '#f2c230' : (x === 0 || x === 7) ? '#7a45c4' : '#5b2a9e') },
    { id: 'sun', nat: 0, rar: 2, price: 30000, name: T('غروب الشمس', 'Sunset', 'Coucher de soleil', 'Atardecer', 'Pôr do sol', 'Sonnenuntergang', 'Gün Batımı'), shirt: '#f4511e', sleeve: '#ff8f00', short: '#4a148c', sock: '#d81b60', grid: grid((x, y) => ['#ffd54f', '#ffb300', '#ff8f00', '#f4511e', '#d81b60', '#8e24aa', '#4a148c'][y]) },
    { id: 'cam', nat: 0, rar: 2, price: 36000, name: T('تمويه', 'Urban Camo', 'Camouflage', 'Camuflaje', 'Camuflagem', 'Tarnmuster', 'Kamuflaj'), shirt: '#4b5320', sleeve: '#4b5320', short: '#2f3519', sock: '#4b5320', grid: grid((x, y) => ['#4b5320', '#6b7a3a', '#2f3519', '#8f9a5a'][hash(x, y)]) },
    { id: 'gal', nat: 0, rar: 3, price: 48000, name: T('المجرة', 'Galaxy', 'Galaxie', 'Galaxia', 'Galáxia', 'Galaxie', 'Galaksi'), shirt: '#1a1650', sleeve: '#3a1c71', short: '#0d0b2e', sock: '#3a1c71', grid: grid((x, y) => ((x * 5 + y * 3) % 7 === 0) ? '#ffffff' : ((x * 3 + y * 5) % 11 === 0) ? '#9ad1ff' : ((x + y * 2) % 5 === 0) ? '#3a1c71' : '#0d0b2e') },
    { id: 'gld', nat: 0, rar: 3, price: 60000, name: T('الأسطورة الذهبية', 'Golden Legend', 'Légende dorée', 'Leyenda dorada', 'Lenda dourada', 'Goldene Legende', 'Altın Efsane'), shirt: '#f4c430', sleeve: '#c99a1e', short: '#111111', sock: '#f4c430', grid: grid((x, y) => (y === 0 && (x === 3 || x === 4)) ? '#111111' : (x === 0 || x === 7) ? '#c99a1e' : ((x + y) % 4 === 0) ? '#fff1a8' : '#f4c430') },
    { id: 'dia', nat: 0, rar: 3, price: 80000, name: T('الألماس', 'Diamond', 'Diamant', 'Diamante', 'Diamante', 'Diamant', 'Elmas'), shirt: '#0aa6c4', sleeve: '#0aa6c4', short: '#e6fbff', sock: '#0aa6c4', grid: grid((x, y) => { const d = Math.abs(x - 3.5) + Math.abs(y - 3) * 1.2; return d <= 1.6 ? '#7defff' : d <= 3.2 ? '#e6fbff' : '#0aa6c4'; }) }
  ];
  const byId = (id) => KITS.find(k => k.id === id) || KITS[0];
  function ks() { const e = FFMEng.eng(); const k = e.kits = e.kits || { own: ['basic'], eq: 'basic' }; if (!k.own || !k.own.includes('basic')) k.own = ['basic'].concat(k.own || []); if (!KITS.some(x => x.id === k.eq) || !k.own.includes(k.eq)) k.eq = 'basic'; return k; }
  window.FFMKit = { list: KITS, byId, forMatch() { try { return byId(ks().eq); } catch (e) { return KITS[0]; } } };

  /* ---------- player sprite: same drawing as the match ---------- */
  const O = '#12141c';
  function drawPlayer(c, k, sx, sy, fr) {
    const skin = '#f1c9a0', hair = '#2a1a10', sleeve = k.sleeve || k.shirt;
    c.fillStyle = 'rgba(0,0,0,.3)'; c.fillRect(sx - 4, sy - 1, 9, 3);
    const lh = fr === 0 ? 5 : (fr === 1 ? 3 : 5), rh = fr === 1 ? 5 : (fr === 0 ? 3 : 5);
    c.fillStyle = O; c.fillRect(sx - 4, sy - 6, 4, 7); c.fillRect(sx, sy - 6, 4, 7);
    c.fillStyle = k.sock; c.fillRect(sx - 3, sy - lh, 2, lh); c.fillRect(sx + 1, sy - rh, 2, rh);
    c.fillStyle = '#e9e9e9'; c.fillRect(sx - 3, sy - 1, 2, 1); c.fillRect(sx + 1, sy - 1, 2, 1);
    c.fillStyle = O; c.fillRect(sx - 5, sy - 15, 10, 10);
    c.fillStyle = k.short; c.fillRect(sx - 4, sy - 7, 8, 3);
    c.fillStyle = k.shirt; c.fillRect(sx - 4, sy - 14, 8, 7);
    if (k.grid) for (let i = 0; i < 56; i++) { c.fillStyle = k.grid[i]; c.fillRect(sx - 4 + (i % 8), sy - 14 + ((i / 8) | 0), 1, 1); }
    else if (k.stripe) { c.fillStyle = k.stripe; c.fillRect(sx - 3, sy - 14, 1, 7); c.fillRect(sx - 1, sy - 14, 1, 7); c.fillRect(sx + 1, sy - 14, 1, 7); }
    const sw = fr === 0 ? 1 : (fr === 1 ? -1 : 0);
    c.fillStyle = O; c.fillRect(sx - 7, sy - 13 + sw, 3, 6); c.fillRect(sx + 4, sy - 13 - sw, 3, 6);
    c.fillStyle = sleeve; c.fillRect(sx - 6, sy - 12 + sw, 2, 2); c.fillRect(sx + 4, sy - 12 - sw, 2, 2);
    c.fillStyle = skin; c.fillRect(sx - 6, sy - 10 + sw, 2, 2); c.fillRect(sx + 4, sy - 10 - sw, 2, 2);
    c.fillStyle = O; c.fillRect(sx - 4, sy - 21, 8, 8);
    c.fillStyle = skin; c.fillRect(sx - 3, sy - 20, 6, 6);
    c.fillStyle = hair; c.fillRect(sx - 3, sy - 20, 6, 2);
    c.fillStyle = '#1b1b24'; c.fillRect(sx - 2, sy - 17, 1, 1); c.fillRect(sx + 1, sy - 17, 1, 1);
  }
  function drawMini(cv, k) {
    const c = cv.getContext('2d'); c.imageSmoothingEnabled = false; c.clearRect(0, 0, 16, 12);
    c.fillStyle = O; c.fillRect(0, 1, 16, 5); c.fillRect(3, 0, 10, 11);
    c.fillStyle = k.sleeve || k.shirt; c.fillRect(1, 2, 3, 3); c.fillRect(12, 2, 3, 3);
    c.fillStyle = k.shirt; c.fillRect(4, 1, 8, 9);
    if (k.grid) { for (let i = 0; i < 56; i++) { c.fillStyle = k.grid[i]; c.fillRect(4 + (i % 8), 2 + ((i / 8) | 0), 1, 1); } c.fillStyle = k.grid[(3)]; c.fillRect(4, 9, 8, 1); }
    else { c.fillStyle = k.stripe; c.fillRect(5, 1, 1, 9); c.fillRect(7, 1, 1, 9); c.fillRect(9, 1, 1, 9); c.fillRect(11, 1, 1, 9); c.fillStyle = k.shirt; c.fillRect(4, 1, 1, 0); }
    c.fillStyle = O; c.fillRect(6, 0, 4, 1); c.fillStyle = 'rgba(255,255,255,.35)'; c.fillRect(6, 1, 4, 1);
  }

  /* ---------- screens ---------- */
  const mk = (id) => { const sc = document.createElement('div'); sc.id = id; sc.className = 'screen store-screen'; sc.innerHTML = '<div id="' + id + '-body"></div>'; document.getElementById('game-container').appendChild(sc); return sc; };
  mk('screen-custom'); mk('screen-locker');
  const backTxt = () => L('رجوع', 'Back', 'Retour', 'Volver', 'Voltar', 'Zurück', 'Geri');
  const head = (title) => `<div class="st-head"><div class="st-title">${title}</div></div><div class="st-sub"><span>🪙 <b>${fmt(state.tokens)}</b></span></div>`;

  window.customOpen = function () {
    $('screen-custom-body').innerHTML = head('🎨 ' + L('تخصيص', 'Customize', 'Personnaliser', 'Personalizar', 'Personalizar', 'Anpassen', 'Özelleştir')) +
      `<button class="godot-btn" style="width:100%;margin-bottom:12px;font-size:18px;min-height:64px" onclick="lockerOpen()">👕 ${L('غرفة الملابس', 'Locker Room', 'Vestiaire', 'Vestuario', 'Vestiário', 'Umkleidekabine', 'Soyunma Odası')}</button>` +
      `<div class="back-bar"><button class="godot-btn" onclick="showScreen('screen-career')">${backTxt()}</button></div>`;
    showScreen('screen-custom'); window.scrollTo(0, 0);
  };

  let sel = 'basic', anim = 0;
  function actionHTML() {
    const k = byId(sel), s = ks(), own = s.own.includes(k.id);
    if (s.eq === k.id) return `<button class="godot-btn st-dim" style="width:100%" disabled>✔ ${L('مُطبَّق', 'Equipped', 'Équipé', 'Equipado', 'Equipado', 'Angelegt', 'Giyildi')}</button>`;
    if (own) return `<button class="godot-btn" style="width:100%;background:#1abf62" onclick="lockerEquip()">${L('تطبيق', 'Equip', 'Équiper', 'Equipar', 'Equipar', 'Anlegen', 'Giy')}</button>`;
    return `<button class="godot-btn ${state.tokens < k.price ? 'st-dim' : ''}" style="width:100%;background:#b8860b" onclick="lockerBuy()">🛒 ${L('شراء', 'Buy', 'Acheter', 'Comprar', 'Comprar', 'Kaufen', 'Satın al')} · 🪙 ${fmt(k.price)}</button>`;
  }
  function lockerRender() {
    const s = ks(), k = byId(sel);
    let list = '';
    KITS.forEach(x => {
      const own = s.own.includes(x.id), rc = x.rar < 0 ? '#9aa4b8' : RCOL[x.rar], tag = x.rar < 0 ? '' : nm(RAR[x.rar]);
      list += `<div class="kit-row" data-k="${x.id}" onclick="lockerSel('${x.id}')" style="display:flex;gap:8px;align-items:center;background:#111;padding:6px;margin-bottom:6px;border:2px solid ${x.id === sel ? 'var(--accent-color)' : '#333'};cursor:pointer"><canvas width="16" height="12" data-m="${x.id}" style="width:48px;height:36px;image-rendering:pixelated;flex:0 0 48px"></canvas><div style="flex:1;min-width:0;font-size:12px;line-height:1.35;text-align:start"><b>${nm(x.name)}</b><br><span style="color:${rc}">${x.nat ? '🏳️ ' + L('وطني', 'National', 'National', 'Nacional', 'Nacional', 'National', 'Ulusal') : (x.rar < 0 ? '' : '✨')} ${tag}</span><br>${s.eq === x.id ? '<span style="color:#7dff9a">✔ ' + L('مُطبَّق', 'Equipped', 'Équipé', 'Equipado', 'Equipado', 'Angelegt', 'Giyildi') + '</span>' : own ? '<span style="color:#7dff9a">' + L('مملوك', 'Owned', 'Possédé', 'Tuyo', 'Possuído', 'Im Besitz', 'Sahip') + '</span>' : '🪙 ' + fmt(x.price)}</div></div>`;
    });
    $('screen-locker-body').innerHTML = head('👕 ' + L('غرفة الملابس', 'Locker Room', 'Vestiaire', 'Vestuario', 'Vestiário', 'Umkleidekabine', 'Soyunma Odası')) +
      `<div style="display:flex;gap:10px;align-items:flex-start"><div style="flex:0 0 42%;max-width:190px"><div style="background:linear-gradient(#10172a 0 45%,#2f8f3a 45%);border:3px solid #111;box-shadow:0 0 0 2px #3a4a7a;padding:6px 0"><canvas id="lk-player" width="40" height="44" style="width:100%;image-rendering:pixelated;display:block"></canvas></div><div id="lk-name" style="text-align:center;font-weight:bold;margin:8px 0 6px">${nm(k.name)}</div><div id="lk-act">${actionHTML()}</div></div>` +
      `<div id="lk-list" style="flex:1;max-height:62vh;overflow-y:auto;padding-inline-end:2px">${list}</div></div>` +
      `<div class="back-bar"><button class="godot-btn" onclick="customOpen()">${backTxt()}</button></div>`;
    document.querySelectorAll('#screen-locker canvas[data-m]').forEach(cv => drawMini(cv, byId(cv.dataset.m)));
  }
  window.lockerOpen = function () { sel = ks().eq; lockerRender(); showScreen('screen-locker'); window.scrollTo(0, 0); startAnim(); };
  window.lockerSel = function (id) { sel = id; const sc = $('lk-list'), top = sc ? sc.scrollTop : 0; lockerRender(); const n = $('lk-list'); if (n) n.scrollTop = top; };
  window.lockerEquip = function () { const s = ks(); if (!s.own.includes(sel)) return; s.eq = sel; try { saveGame(); } catch (e) {} lockerRender(); };
  window.lockerBuy = function () {
    const k = byId(sel), s = ks(); if (s.own.includes(k.id)) return;
    if (state.tokens < k.price) return ffmShort('tok', L('توكن غير كافٍ', 'Not enough tokens', 'Jetons insuffisants', 'Fichas insuficientes', 'Fichas insuficientes', 'Nicht genug Tokens', 'Yetersiz jeton'), L(`تحتاج ${fmt(k.price)} توكن`, `You need ${fmt(k.price)} tokens`, `Il faut ${fmt(k.price)} jetons`, `Necesitas ${fmt(k.price)} fichas`, `Precisa de ${fmt(k.price)} fichas`, `Du brauchst ${fmt(k.price)} Tokens`, `${fmt(k.price)} jeton gerekli`));
    ffmConfirm(L(`شراء «${nm(k.name)}» مقابل ${fmt(k.price)} توكن؟`, `Buy "${nm(k.name)}" for ${fmt(k.price)} tokens?`, `Acheter « ${nm(k.name)} » pour ${fmt(k.price)} jetons ?`, `¿Comprar «${nm(k.name)}» por ${fmt(k.price)} fichas?`, `Comprar «${nm(k.name)}» por ${fmt(k.price)} fichas?`, `„${nm(k.name)}“ für ${fmt(k.price)} Tokens kaufen?`, `"${nm(k.name)}" ${fmt(k.price)} jetona satın alınsın mı?`), () => {
      if (state.tokens < k.price || s.own.includes(k.id)) return;
      state.tokens -= k.price; s.own.push(k.id); s.eq = k.id;
      try { updateTokenDisplay(); } catch (e) {} try { saveGame(); } catch (e) {}
      lockerRender();
    });
  };
  function startAnim() {
    const my = ++anim; let t0 = performance.now();
    (function f(now) {
      if (my !== anim) return; const cv = $('lk-player'); const sc = $('screen-locker');
      if (!cv || !sc || !sc.classList.contains('active')) { if (!sc || !sc.classList.contains('active')) { setTimeout(() => { if (my === anim && sc && sc.classList.contains('active')) f(performance.now()); }, 300); } else requestAnimationFrame(f); return; }
      const c = cv.getContext('2d'); c.imageSmoothingEnabled = false; c.clearRect(0, 0, 40, 44);
      const fr = ((((now - t0) / 380) | 0) % 4); drawPlayer(c, byId(sel), 20, 38, fr === 3 ? 2 : fr === 2 ? 2 : fr);
      requestAnimationFrame(f);
    })(t0);
  }
})();
