/**
 * pricingService.js
 * Motor de precificação por REGRAS CONFIGURÁVEIS (ver pricingConfig.js).
 * Não usa machine learning. Cada cálculo registra os componentes utilizados
 * (`componentes`) para que, no futuro, esses registros alimentem uma análise
 * estatística real.
 *
 * Retorna sempre a separação exigida:
 *  - valorAnfitriao   → o que o anfitrião paga (inclui taxa de conveniência)
 *  - valorServico     → valor do serviço em si (sem a taxa de conveniência)
 *  - comissaoPlataforma
 *  - valorProfissional → o que o profissional recebe (valorServico - comissão)
 *  - taxaConveniencia
 *  - componentes      → trilha de auditoria do cálculo
 */
const PricingService = {

  /**
   * @param {Object} dados
   *  categoria: 'Limpeza' | 'Pequenos Reparos' | 'Roupa de cama / Enxoval'
   *  data: 'YYYY-MM-DD', horario: 'HH:MM'
   *  urgencia: uma das URGENCIAS
   *  limpeza?: { tipo, quartos, banheiros, camas, cozinha, sala, varanda }
   *  enxoval?: { quantidade }
   *  reparo?: { necessitaAvaliacao }
   */
  calcular(dados){
    const cfg = PRICING_CONFIG;
    const componentes = [];
    let necessitaAvaliacao = false;
    let subtotal = 0;

    // ---------- Preço base por categoria ----------
    if(dados.categoria === CATEGORIAS_SERVICO.LIMPEZA){
      const tipo = (dados.limpeza && dados.limpeza.tipo) || 'outro';
      const base = cfg.precoBase.Limpeza[tipo] ?? cfg.precoBase.Limpeza['outro'];
      subtotal += base;
      componentes.push({ fator:'preco_base', descricao:`Limpeza (${tipo})`, valor: base });

      const l = dados.limpeza || {};
      const extraQuartos = Math.max(0, (l.quartos||0) - 1) * cfg.acrescimoPorQuarto;
      const extraBanheiros = Math.max(0, (l.banheiros||0) - 1) * cfg.acrescimoPorBanheiro;
      const extraCamas = Math.max(0, (l.camas||0) - 1) * cfg.acrescimoPorCama;
      const ambientesExtra = ['cozinha','sala','varanda'].filter(a => l[a]).length * cfg.acrescimoAmbienteExtra;

      if(extraQuartos) componentes.push({ fator:'quartos_extra', descricao:`+${l.quartos-1} quarto(s)`, valor: extraQuartos });
      if(extraBanheiros) componentes.push({ fator:'banheiros_extra', descricao:`+${l.banheiros-1} banheiro(s)`, valor: extraBanheiros });
      if(extraCamas) componentes.push({ fator:'camas_extra', descricao:`+${l.camas-1} cama(s)`, valor: extraCamas });
      if(ambientesExtra) componentes.push({ fator:'ambientes_extra', descricao:'Cozinha/sala/varanda', valor: ambientesExtra });

      subtotal += extraQuartos + extraBanheiros + extraCamas + ambientesExtra;
    }

    else if(dados.categoria === CATEGORIAS_SERVICO.REPAROS){
      necessitaAvaliacao = !!(dados.reparo && dados.reparo.necessitaAvaliacao);
      if(necessitaAvaliacao){
        componentes.push({ fator:'preco_base', descricao:'Necessita avaliação/orçamento', valor: 0 });
      } else {
        const base = 80; // reparo simples padrão, sem avaliação
        subtotal += base;
        componentes.push({ fator:'preco_base', descricao:'Reparo simples (estimado)', valor: base });
      }
    }

    else if(dados.categoria === CATEGORIAS_SERVICO.ENXOVAL){
      const qtd = (dados.enxoval && dados.enxoval.quantidade) || 1;
      const valor = qtd * cfg.precoBase['Roupa de cama / Enxoval'].porKit;
      subtotal += valor;
      componentes.push({ fator:'preco_base', descricao:`${qtd} kit(s) de enxoval`, valor });
    }

    // ---------- Multiplicadores (não se aplicam quando "necessita avaliação") ----------
    if(!necessitaAvaliacao){
      const dataObj = dados.data ? new Date(dados.data + 'T' + (dados.horario||'12:00')) : null;

      if(dataObj){
        const diaSemana = dataObj.getDay(); // 0=domingo, 6=sábado
        if(diaSemana === 0 || diaSemana === 6){
          const acr = subtotal * (cfg.multiplicadorFimDeSemana - 1);
          subtotal *= cfg.multiplicadorFimDeSemana;
          componentes.push({ fator:'fim_de_semana', descricao:'Fim de semana', valor: Math.round(acr*100)/100 });
        }

        const mmdd = String(dataObj.getMonth()+1).padStart(2,'0') + '-' + String(dataObj.getDate()).padStart(2,'0');
        if(cfg.feriadosFixos.includes(mmdd)){
          const acr = subtotal * (cfg.multiplicadorFeriado - 1);
          subtotal *= cfg.multiplicadorFeriado;
          componentes.push({ fator:'feriado', descricao:'Feriado nacional', valor: Math.round(acr*100)/100 });
        }

        const mes = dataObj.getMonth()+1;
        if(cfg.mesesTemporadaAlta.includes(mes)){
          const acr = subtotal * (cfg.multiplicadorTemporadaAlta - 1);
          subtotal *= cfg.multiplicadorTemporadaAlta;
          componentes.push({ fator:'temporada_alta', descricao:'Temporada alta (verão)', valor: Math.round(acr*100)/100 });
        }
      }

      if(dados.horario){
        const hora = Number(dados.horario.split(':')[0]);
        if(hora < 7 || hora >= 19){
          const acr = subtotal * (cfg.multiplicadorForaHorarioComercial - 1);
          subtotal *= cfg.multiplicadorForaHorarioComercial;
          componentes.push({ fator:'fora_horario', descricao:'Fora do horário comercial', valor: Math.round(acr*100)/100 });
        }
      }

      const multUrgencia = cfg.multiplicadorUrgencia[dados.urgencia] || 1;
      if(multUrgencia !== 1){
        const acr = subtotal * (multUrgencia - 1);
        subtotal *= multUrgencia;
        componentes.push({ fator:'urgencia', descricao:dados.urgencia, valor: Math.round(acr*100)/100 });
      }
    }

    subtotal = Math.round(subtotal * 100) / 100;

    const comissaoPct = cfg.comissaoPlataforma[dados.categoria] ?? 0.15;
    const comissaoPlataforma = necessitaAvaliacao ? 0 : Math.round(subtotal * comissaoPct * 100) / 100;
    const taxaConveniencia = necessitaAvaliacao ? 0 : Math.round(subtotal * cfg.taxaConveniencia * 100) / 100;
    const valorProfissional = Math.round((subtotal - comissaoPlataforma) * 100) / 100;
    const valorAnfitriao = Math.round((subtotal + taxaConveniencia) * 100) / 100;

    return {
      necessitaAvaliacao,
      valorServico: subtotal,
      comissaoPlataforma,
      taxaConveniencia,
      valorProfissional,
      valorAnfitriao,
      componentes,
      calculadoEm: new Date().toISOString(),
    };
  },

  /**
   * Ajuste informativo (não altera o valor cobrado do anfitrião): quanto o
   * profissional efetivamente recebe líquido de deslocamento, para exibir na
   * tela de oportunidades. distanciaKm pode ser null quando não há geo.
   */
  aplicarDeslocamento(valorProfissional, distanciaKm){
    if(distanciaKm == null) return { valorLiquido: valorProfissional, deducaoDeslocamento: 0 };
    const kmCobrados = Math.max(0, distanciaKm - PRICING_CONFIG.kmIsentosDeslocamento);
    const deducao = Math.round(kmCobrados * PRICING_CONFIG.deducaoPorKmDeslocamento * 100) / 100;
    return {
      valorLiquido: Math.max(0, Math.round((valorProfissional - deducao)*100)/100),
      deducaoDeslocamento: deducao,
    };
  },
};
