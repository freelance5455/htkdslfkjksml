/**
 * Snake Escape — Animation & Particle FX Engine
 * Manages celebration confetti, floating fireflies, star bursts, and haptic feedback.
 */
(function() {
  'use strict';

  class AnimationEngine {
    constructor() {
      this.activeParticles = [];
    }

    /**
     * Spawns a celebration shower of colorful confetti
     */
    triggerConfetti(container = document.body, count = 45) {
      const colors = ['#2ecc71', '#3498db', '#f1c40f', '#e67e22', '#e74c3c', '#9b59b6', '#1abc9c'];

      for (let i = 0; i < count; i++) {
        const piece = document.createElement('div');
        piece.className = 'confetti-particle';

        const left = Math.random() * 100;
        const color = colors[Math.floor(Math.random() * colors.length)];
        const size = Math.random() * 8 + 6;
        const duration = Math.random() * 2 + 2; // 2 to 4s
        const delay = Math.random() * 0.5;

        piece.style.left = `${left}vw`;
        piece.style.backgroundColor = color;
        piece.style.width = `${size}px`;
        piece.style.height = `${size * 1.4}px`;
        piece.style.setProperty('--fall-duration', `${duration}s`);
        piece.style.animationDelay = `${delay}s`;

        container.appendChild(piece);

        // Remove element after animation completes
        setTimeout(() => {
          if (piece.parentNode) {
            piece.parentNode.removeChild(piece);
          }
        }, (duration + delay) * 1000);
      }
    }

    /**
     * Creates glowing floating fireflies inside a container
     */
    createFireflies(container, count = 12) {
      if (!container) return;
      container.innerHTML = '';

      for (let i = 0; i < count; i++) {
        const firefly = document.createElement('div');
        firefly.className = 'firefly-particle';

        const size = Math.random() * 4 + 3;
        const top = Math.random() * 95;
        const left = Math.random() * 95;
        const duration = Math.random() * 4 + 4;
        const delay = Math.random() * 5;

        firefly.style.width = `${size}px`;
        firefly.style.height = `${size}px`;
        firefly.style.top = `${top}%`;
        firefly.style.left = `${left}%`;
        firefly.style.animation = `fireflyDrift ${duration}s ease-in-out ${delay}s infinite alternate`;

        container.appendChild(firefly);
      }
    }

    /**
     * Triggers vibration if enabled and supported by browser
     */
    vibrate(pattern = 35) {
      const storage = window.SnakeEscape && window.SnakeEscape.storage;
      if (storage && !storage.getSetting('vibrationEnabled')) return;

      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        try {
          navigator.vibrate(pattern);
        } catch (e) {
          // Ignore vibration permission denials
        }
      }
    }
  }

  window.SnakeEscape = window.SnakeEscape || {};
  window.SnakeEscape.animation = new AnimationEngine();
})();
