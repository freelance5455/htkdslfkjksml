/**
 * Panchal Business Manager - Real Offline PDF Generator, Print Engine,
 * Document Preview & Template Switcher, Digital Signature Pad & PDF Share
 */
(function (global) {
  "use strict";

  function sanitizeFileName(name) {
    return (
      String(name || "document")
        .replace(/[^a-zA-Z0-9._-]+/g, "_")
        .replace(/^_+|_+$/g, "") || "document"
    );
  }

  function ensurePdfFileName(baseName) {
    const clean = sanitizeFileName(baseName);
    return clean.toLowerCase().endsWith(".pdf") ? clean : clean + ".pdf";
  }

  function openSignaturePadModal(title, existingDataUrl, onSave) {
    const app = global.PBM_APP;
    const isHi = app.getLang() === "hi";
    const html = `
      <div class="form-grid">
        <div class="list-item-meta">${isHi ? "नीचे अपनी उंगली या माउस से हस्ताक्षर (Sign) करें:" : "Draw signature below using finger or pointer:"}</div>
        <canvas id="sigCanvas" class="sig-canvas" width="440" height="180"></canvas>
        <div class="modal-actions">
          <button id="sigClearBtn" class="secondary-btn" type="button">${isHi ? "साफ़ करें" : "Clear"}</button>
          <button id="sigSaveBtn" class="primary-btn" type="button">${isHi ? "हस्ताक्षर सेव करें" : "Save Signature"}</button>
        </div>
      </div>
    `;

    app.openModal(title || (isHi ? "डिजिटल हस्ताक्षर" : "Digital Signature"), html);

    const canvas = document.getElementById("sigCanvas");
    const ctx = canvas.getContext("2d");
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    if (existingDataUrl) {
      const img = new Image();
      img.onload = function () {
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      };
      img.src = existingDataUrl;
    }

    let drawing = false;
    let hasStroke = false;

    function getPos(evt) {
      const rect = canvas.getBoundingClientRect();
      const clientX = evt.touches ? evt.touches[0].clientX : evt.clientX;
      const clientY = evt.touches ? evt.touches[0].clientY : evt.clientY;
      return {
        x: ((clientX - rect.left) / rect.width) * canvas.width,
        y: ((clientY - rect.top) / rect.height) * canvas.height
      };
    }

    function startDraw(evt) {
      evt.preventDefault();
      drawing = true;
      hasStroke = true;
      const p = getPos(evt);
      ctx.beginPath();
      ctx.moveTo(p.x, p.y);
    }

    function moveDraw(evt) {
      if (!drawing) return;
      evt.preventDefault();
      const p = getPos(evt);
      ctx.lineWidth = 2.5;
      ctx.lineCap = "round";
      ctx.strokeStyle = "#0f172a";
      ctx.lineTo(p.x, p.y);
      ctx.stroke();
    }

    function endDraw() {
      drawing = false;
    }

    canvas.addEventListener("mousedown", startDraw);
    canvas.addEventListener("mousemove", moveDraw);
    canvas.addEventListener("mouseup", endDraw);
    canvas.addEventListener("mouseleave", endDraw);
    canvas.addEventListener("touchstart", startDraw, { passive: false });
    canvas.addEventListener("touchmove", moveDraw, { passive: false });
    canvas.addEventListener("touchend", endDraw);

    document.getElementById("sigClearBtn").addEventListener("click", function () {
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      hasStroke = false;
    });

    document.getElementById("sigSaveBtn").addEventListener("click", function () {
      const dataUrl = hasStroke ? canvas.toDataURL("image/png") : existingDataUrl || "";
      app.closeModal();
      if (typeof onSave === "function") {
        onSave(dataUrl);
      }
    });
  }

  function waitForImages(container) {
    const imgs = Array.from(container.querySelectorAll("img"));
    if (imgs.length === 0) return Promise.resolve();
    return Promise.all(
      imgs.map(function (img) {
        if (img.complete) return Promise.resolve();
        return new Promise(function (resolve) {
          img.addEventListener("load", resolve, { once: true });
          img.addEventListener("error", resolve, { once: true });
          setTimeout(resolve, 1500);
        });
      })
    );
  }

  function generatePdfFromHtml(documentHtml, fileNameHint, options) {
    const opts = options || {};
    const fileName = ensurePdfFileName(fileNameHint || "Panchal_Document");
    const isThermal = Boolean(opts.isThermal) || documentHtml.indexOf("max-width:330px") !== -1;

    if (typeof global.html2canvas !== "function" || !global.jspdf || !global.jspdf.jsPDF) {
      return Promise.reject(new Error("Offline PDF engine is still loading or unavailable."));
    }

    const stage = document.createElement("div");
    stage.className = "pbm-pdf-stage";
    stage.style.width = isThermal ? "360px" : "840px";
    stage.style.padding = "12px";
    stage.innerHTML = documentHtml;
    document.body.appendChild(stage);

    const target = stage.querySelector(".print-sheet") || stage;

    return waitForImages(stage)
      .then(function () {
        return new Promise(function (resolve) {
          requestAnimationFrame(function () {
            requestAnimationFrame(resolve);
          });
        });
      })
      .then(function () {
        return global.html2canvas(target, {
          scale: 2,
          useCORS: true,
          allowTaint: true,
          backgroundColor: "#ffffff",
          logging: false,
          windowWidth: isThermal ? 360 : 860
        });
      })
      .then(function (canvas) {
        const jsPDF = global.jspdf.jsPDF;

        if (isThermal) {
          const pdfWidth = 80;
          const margin = 3;
          const imgWidth = pdfWidth - margin * 2;
          const imgHeight = Math.max(60, (canvas.height * imgWidth) / canvas.width);
          const pdf = new jsPDF({
            orientation: "p",
            unit: "mm",
            format: [pdfWidth, imgHeight + margin * 2],
            compress: true
          });
          pdf.addImage(canvas.toDataURL("image/png"), "PNG", margin, margin, imgWidth, imgHeight, undefined, "FAST");
          return {
            blob: pdf.output("blob"),
            fileName: fileName,
            pageCount: 1
          };
        }

        const pdf = new jsPDF({
          orientation: "p",
          unit: "mm",
          format: "a4",
          compress: true
        });
        const pageWidth = pdf.internal.pageSize.getWidth();
        const pageHeight = pdf.internal.pageSize.getHeight();
        const margin = 8;
        const contentWidthMm = pageWidth - margin * 2;
        const contentHeightMm = pageHeight - margin * 2;
        const pageSliceHeightPx = Math.max(1, Math.floor((canvas.width * contentHeightMm) / contentWidthMm));

        let offsetY = 0;
        let pageIndex = 0;

        while (offsetY < canvas.height) {
          const sliceHeight = Math.min(pageSliceHeightPx, canvas.height - offsetY);
          const sliceCanvas = document.createElement("canvas");
          sliceCanvas.width = canvas.width;
          sliceCanvas.height = sliceHeight;
          const sliceCtx = sliceCanvas.getContext("2d");
          sliceCtx.fillStyle = "#ffffff";
          sliceCtx.fillRect(0, 0, sliceCanvas.width, sliceCanvas.height);
          sliceCtx.drawImage(canvas, 0, offsetY, canvas.width, sliceHeight, 0, 0, canvas.width, sliceHeight);

          const sliceHeightMm = (sliceHeight * contentWidthMm) / canvas.width;
          if (pageIndex > 0) {
            pdf.addPage();
          }
          pdf.addImage(
            sliceCanvas.toDataURL("image/png"),
            "PNG",
            margin,
            margin,
            contentWidthMm,
            sliceHeightMm,
            undefined,
            "FAST"
          );

          offsetY += sliceHeight;
          pageIndex += 1;
        }

        return {
          blob: pdf.output("blob"),
          fileName: fileName,
          pageCount: pageIndex
        };
      })
      .finally(function () {
        if (stage.parentNode) {
          stage.parentNode.removeChild(stage);
        }
      });
  }

  function triggerBlobDownload(blob, fileName) {
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = fileName;
    link.style.display = "none";
    document.body.appendChild(link);
    link.click();
    setTimeout(function () {
      if (link.parentNode) link.parentNode.removeChild(link);
      URL.revokeObjectURL(url);
    }, 1500);
  }

  function downloadPdfFromHtml(documentHtml, fileNameHint, options) {
    const app = global.PBM_APP;
    const isHi = app && app.getLang() === "hi";
    if (app) {
      app.showToast(isHi ? "PDF तैयार हो रहा है..." : "Generating PDF...", false);
    }

    return generatePdfFromHtml(documentHtml, fileNameHint, options)
      .then(function (res) {
        triggerBlobDownload(res.blob, res.fileName);
        if (app) {
          app.showToast(
            isHi ? `PDF डाउनलोड हो गया: ${res.fileName}` : `PDF downloaded: ${res.fileName}`,
            false
          );
        }
        return res;
      })
      .catch(function (err) {
        if (app) {
          app.showToast(
            (isHi ? "PDF बनाने में त्रुटि: " : "PDF error: ") + (err && err.message ? err.message : "Failed"),
            true
          );
        }
        throw err;
      });
  }

  function sharePdfFromHtml(documentHtml, fileNameHint, title, summaryText, options) {
    const app = global.PBM_APP;
    const isHi = app && app.getLang() === "hi";
    if (app) {
      app.showToast(isHi ? "शेयर के लिए PDF तैयार हो रहा है..." : "Preparing PDF to share...", false);
    }

    return generatePdfFromHtml(documentHtml, fileNameHint, options)
      .then(function (res) {
        const pdfFile =
          typeof File === "function"
            ? new File([res.blob], res.fileName, { type: "application/pdf" })
            : null;

        const canSharePdf =
          pdfFile &&
          typeof navigator.share === "function" &&
          typeof navigator.canShare === "function" &&
          navigator.canShare({ files: [pdfFile] });

        if (canSharePdf) {
          return navigator
            .share({
              title: title || res.fileName,
              text: summaryText || title || res.fileName,
              files: [pdfFile]
            })
            .then(function () {
              if (app) {
                app.showToast(isHi ? "PDF शेयर हो गया।" : "PDF shared successfully.", false);
              }
            })
            .catch(function (err) {
              if (err && err.name === "AbortError") {
                return;
              }
              // Fallback if Web Share with files was blocked by iframe/WebView
              triggerBlobDownload(res.blob, res.fileName);
              if (app) {
                app.showToast(
                  isHi
                    ? `PDF डाउनलोड हो गया (${res.fileName}) — अब WhatsApp में अटैच करके भेजें।`
                    : `PDF saved (${res.fileName}) — attach it in WhatsApp to share.`,
                  false
                );
              }
            });
        }

        // Browser does not support file sharing directly: download real PDF & notify user
        triggerBlobDownload(res.blob, res.fileName);
        if (navigator.clipboard && navigator.clipboard.writeText && summaryText) {
          navigator.clipboard.writeText(summaryText).catch(function () {});
        }
        if (app) {
          app.showToast(
            isHi
              ? `PDF डाउनलोड हो गया (${res.fileName}) — फाइल मैनेजर/Downloads से WhatsApp पर भेजें।`
              : `PDF downloaded (${res.fileName}) — attach from Downloads to share on WhatsApp.`,
            false
          );
        }
        return res;
      })
      .catch(function (err) {
        if (app) {
          app.showToast(
            (isHi ? "PDF शेयर विफल: " : "PDF share failed: ") + (err && err.message ? err.message : "Failed"),
            true
          );
        }
      });
  }

  function triggerNativePrint(documentHtml) {
    let printRoot = document.getElementById("pbmPrintRoot");
    if (!printRoot) {
      printRoot = document.createElement("div");
      printRoot.id = "pbmPrintRoot";
      printRoot.className = "print-only-root";
      document.body.appendChild(printRoot);
    }
    printRoot.innerHTML = documentHtml;

    // Try isolated print iframe first for cleaner output inside Android/WebView iframes
    try {
      let frame = document.getElementById("pbmHiddenPrintFrame");
      if (frame && frame.parentNode) {
        frame.parentNode.removeChild(frame);
      }
      frame = document.createElement("iframe");
      frame.id = "pbmHiddenPrintFrame";
      frame.style.position = "fixed";
      frame.style.right = "0";
      frame.style.bottom = "0";
      frame.style.width = "0";
      frame.style.height = "0";
      frame.style.border = "0";
      document.body.appendChild(frame);

      const frameDoc = frame.contentDocument || (frame.contentWindow && frame.contentWindow.document);
      if (frameDoc) {
        frameDoc.open();
        frameDoc.write(`<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Print Document</title>
  <style>
    @page { size: auto; margin: 8mm; }
    body { margin: 0; padding: 8px; background: #fff; color: #0f172a; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; }
    .print-sheet { max-width: 820px; margin: 0 auto; }
    .print-head { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #0f172a; padding-bottom: 10px; margin-bottom: 12px; }
    .print-party { padding: 8px 10px; border: 1px solid #cbd5e1; border-radius: 6px; margin-bottom: 12px; font-size: 13px; }
    .print-table { width: 100%; border-collapse: collapse; font-size: 12.5px; }
    .print-table th, .print-table td { border: 1px solid #cbd5e1; padding: 6px 8px; text-align: left; }
    .print-table th { background-color: #f1f5f9; }
    .print-totals { margin-top: 12px; margin-left: auto; max-width: 280px; font-size: 13px; }
    .print-totals > div { display: flex; justify-content: space-between; padding: 3px 0; }
    .print-footer { margin-top: 24px; display: flex; justify-content: space-between; align-items: flex-end; }
  </style>
</head>
<body>${documentHtml}</body>
</html>`);
        frameDoc.close();
        setTimeout(function () {
          try {
            frame.contentWindow.focus();
            frame.contentWindow.print();
          } catch (e) {
            window.print();
          }
        }, 180);
        return;
      }
    } catch (e) {
      // Fall back to window.print
    }

    setTimeout(function () {
      window.print();
    }, 120);
  }

  function printHtmlDocument(documentHtml, fileNameHint) {
    const app = global.PBM_APP;
    if (!app || typeof app.openModal !== "function") {
      triggerNativePrint(documentHtml);
      return;
    }

    const isHi = app.getLang() === "hi";
    const resolvedName = fileNameHint || "Panchal_Report_" + new Date().toISOString().slice(0, 10);

    const modalHtml = `
      <div class="form-grid">
        <div class="btn-row">
          <button id="rptPdfDownloadBtn" class="primary-btn" type="button">${isHi ? "PDF डाउनलोड करें" : "Download PDF"}</button>
          <button id="rptPdfShareBtn" class="secondary-btn" type="button">${isHi ? "PDF शेयर (WhatsApp)" : "Share PDF"}</button>
          <button id="rptNativePrintBtn" class="secondary-btn" type="button">${isHi ? "सिस्टम प्रिंट" : "Print"}</button>
        </div>
        <div class="pbm-preview-paper">
          <div id="rptPreviewWrap">${documentHtml}</div>
        </div>
      </div>
    `;

    app.openModal(isHi ? "रिपोर्ट प्रीव्यू व PDF" : "Document Preview & PDF", modalHtml);

    const dlBtn = document.getElementById("rptPdfDownloadBtn");
    if (dlBtn) {
      dlBtn.addEventListener("click", function () {
        downloadPdfFromHtml(documentHtml, resolvedName);
      });
    }

    const shBtn = document.getElementById("rptPdfShareBtn");
    if (shBtn) {
      shBtn.addEventListener("click", function () {
        sharePdfFromHtml(documentHtml, resolvedName, resolvedName, resolvedName);
      });
    }

    const prBtn = document.getElementById("rptNativePrintBtn");
    if (prBtn) {
      prBtn.addEventListener("click", function () {
        triggerNativePrint(documentHtml);
      });
    }
  }

  function buildVoucherPrintHtml(voucher, business, party, template) {
    if (global.PBM_TEMPLATES && typeof global.PBM_TEMPLATES.renderDocumentHtml === "function") {
      return global.PBM_TEMPLATES.renderDocumentHtml(voucher, business, party, template);
    }
    const app = global.PBM_APP;
    return `<div class="print-sheet"><h2>${app.escapeHtml(voucher.voucherNo)}</h2></div>`;
  }

  function buildVoucherSummaryText(voucher, business, party) {
    const cur = voucher.currencySymbol || "₹";
    return (
      (business ? business.name + "\n" : "") +
      (voucher.voucherType || "Document") + ": " + (voucher.voucherNo || "") + "\n" +
      "Date: " + (voucher.date || "") + "\n" +
      "Party: " + (voucher.partyName || (party && party.name) || "-") + "\n" +
      "Total Amount: " + cur + Number(voucher.grandTotal || voucher.amount || 0).toFixed(2)
    );
  }

  function resolveVoucherTemplate(voucher) {
    const app = global.PBM_APP;
    const businessId = app.getActiveBusinessId();
    if (!global.PBM_TEMPLATES) {
      return Promise.resolve({ templates: [], docSettings: {}, selectedTpl: null });
    }
    return Promise.all([
      global.PBM_TEMPLATES.getTemplatesForBusiness(businessId),
      global.PBM_DB.getByBusiness("docSettings", businessId)
    ]).then(function (results) {
      const templates = results[0];
      const docSettings =
        results[1][0] ||
        (global.PBM_DB.getDefaultDocSettings ? global.PBM_DB.getDefaultDocSettings(businessId) : {});
      const selectedTpl = global.PBM_TEMPLATES.resolveTemplateForVoucher(voucher, templates, docSettings);
      return { templates: templates, docSettings: docSettings, selectedTpl: selectedTpl };
    });
  }

  function downloadVoucherPdf(voucher, business, party) {
    return resolveVoucherTemplate(voucher).then(function (ctx) {
      const html = buildVoucherPrintHtml(voucher, business, party, ctx.selectedTpl);
      const isThermal = ctx.selectedTpl && (ctx.selectedTpl.paper === "THERMAL" || ctx.selectedTpl.layout === "thermal");
      return downloadPdfFromHtml(html, voucher.voucherNo || voucher.voucherType || "Document", {
        isThermal: isThermal
      });
    });
  }

  function shareVoucherPdf(voucher, business, party) {
    return resolveVoucherTemplate(voucher).then(function (ctx) {
      const html = buildVoucherPrintHtml(voucher, business, party, ctx.selectedTpl);
      const isThermal = ctx.selectedTpl && (ctx.selectedTpl.paper === "THERMAL" || ctx.selectedTpl.layout === "thermal");
      const summaryText = buildVoucherSummaryText(voucher, business, party);
      return sharePdfFromHtml(
        html,
        voucher.voucherNo || voucher.voucherType || "Document",
        voucher.voucherNo || "Document",
        summaryText,
        { isThermal: isThermal }
      );
    });
  }

  function openDocumentPreviewModal(voucher, business, party, onTemplateChanged) {
    const app = global.PBM_APP;
    const isHi = app.getLang() === "hi";

    resolveVoucherTemplate(voucher).then(function (ctx) {
      const templates = ctx.templates;
      const docSettings = ctx.docSettings || {};
      let selectedTpl = ctx.selectedTpl;
      let workingVoucher = Object.assign({}, voucher);
      const docCat =
        global.PBM_TEMPLATES && typeof global.PBM_TEMPLATES.getDocCategory === "function"
          ? global.PBM_TEMPLATES.getDocCategory(voucher.voucherType)
          : "INVOICE";
      let showAllTemplates = false;

      const tcPacks =
        (global.PBM_TEMPLATES && Array.isArray(global.PBM_TEMPLATES.READYMADE_TC_PACKS)
          ? global.PBM_TEMPLATES.READYMADE_TC_PACKS
          : []);

      const tcPackChipsHtml = tcPacks
        .map(function (pk) {
          return `<button type="button" class="secondary-btn" data-pv-tc-pack="${app.escapeHtml(pk.id)}" style="min-height:30px;padding:4px 8px;font-size:0.74rem;font-weight:700;">${app.escapeHtml(pk.label)}</button>`;
        })
        .join("");

      const termsBank = Array.isArray(docSettings.termsLibrary) && docSettings.termsLibrary.length
        ? docSettings.termsLibrary
        : [
            "1. Goods once sold will not be taken back without prior approval.",
            "2. Custom furniture orders require 50% advance; balance before dispatch.",
            "3. All disputes subject to local jurisdiction only.",
            "4. Quotation valid for 15 days from date of issue."
          ];

      const tcChipsHtml = termsBank
        .map(function (clause, idx) {
          const shortLbl = clause.length > 36 ? clause.slice(0, 36) + "..." : clause;
          return `<button type="button" class="secondary-btn" data-pv-tc-add="${idx}" style="min-height:30px;padding:4px 8px;font-size:0.73rem;">+ ${app.escapeHtml(shortLbl)}</button>`;
        })
        .join("");

      function getFilteredTemplates() {
        if (showAllTemplates) return templates;
        const matched = templates.filter(function (t) {
          if (docCat === "QUOTATION") return t.category === "QUOTATION";
          if (docCat === "RECEIPT") return t.category === "RECEIPT" || t.category === "INVOICE";
          if (docCat === "OTHER") return t.category === "OTHER" || t.category === "INVOICE";
          return t.category === "INVOICE";
        });
        if (selectedTpl && !matched.some(function (t) { return t.id === selectedTpl.id; })) {
          matched.unshift(selectedTpl);
        }
        return matched.length ? matched : templates;
      }

      const html = `
        <div class="form-grid">
          <div class="form-group">
            <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:6px;flex-wrap:wrap;">
              <label class="form-label" for="pvTplSelect" style="margin:0;">${isHi ? "रेडीमेड प्रोफेशनल डिज़ाइन चुनें" : "Choose Readymade Design Gallery"}</label>
              <button id="pvToggleAllBtn" type="button" class="secondary-btn" style="min-height:28px;padding:3px 10px;font-size:0.74rem;">
                ${isHi ? `सभी डिज़ाइन देखें (${templates.length})` : `Show All (${templates.length})`}
              </button>
            </div>
            <div id="pvGalleryStrip" style="display:flex;gap:8px;overflow-x:auto;padding:4px 2px 8px;"></div>
            <select id="pvTplSelect" class="form-select"></select>
          </div>
          <div class="form-group">
            <label class="form-label" for="pvNotesInput">${isHi ? "नियम व शर्तें (Readymade & Editable T&C)" : "Terms & Conditions (Readymade & Editable T&C)"}</label>
            ${tcPackChipsHtml ? `<div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:6px;">${tcPackChipsHtml}</div>` : ""}
            <textarea id="pvNotesInput" class="form-textarea" rows="3" placeholder="${isHi ? "यहाँ नियम व शर्तें लिखें या बदलें..." : "Edit terms & conditions for this document..."}">${app.escapeHtml(workingVoucher.notes || "")}</textarea>
            <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:6px;">${tcChipsHtml}</div>
          </div>
          <div class="btn-row">
            <button id="pvPdfBtn" class="primary-btn" type="button">${isHi ? "PDF डाउनलोड करें" : "Download PDF"}</button>
            <button id="pvShareBtn" class="secondary-btn" type="button">${isHi ? "PDF शेयर (WhatsApp)" : "Share PDF"}</button>
            <button id="pvPrintBtn" class="secondary-btn" type="button">${isHi ? "प्रिंट करें" : "Print"}</button>
            <button id="pvSaveDesignBtn" class="secondary-btn" type="button">${isHi ? "डिज़ाइन व T&C सेव करें" : "Save Design & T&C"}</button>
          </div>
          <div class="pbm-preview-paper">
            <div id="pvPreviewWrap"></div>
          </div>
        </div>
      `;

      app.openModal((voucher.voucherNo || "Document") + " — " + (isHi ? "प्रीव्यू व PDF" : "Preview & PDF"), html);

      function renderGalleryStrip() {
        const list = getFilteredTemplates();
        const stripEl = document.getElementById("pvGalleryStrip");
        const selEl = document.getElementById("pvTplSelect");
        const hasThumb = global.PBM_TEMPLATES && typeof global.PBM_TEMPLATES.renderTemplateMiniThumb === "function";

        if (selEl) {
          selEl.innerHTML = list
            .map(function (t) {
              return `<option value="${app.escapeHtml(t.id)}" ${selectedTpl && t.id === selectedTpl.id ? "selected" : ""}>${app.escapeHtml(t.name)}</option>`;
            })
            .join("");
        }

        if (stripEl) {
          stripEl.innerHTML = list
            .map(function (t) {
              const isAct = selectedTpl && t.id === selectedTpl.id;
              const thumb = hasThumb ? global.PBM_TEMPLATES.renderTemplateMiniThumb(t) : "";
              return `
                <button
                  type="button"
                  data-pv-tpl-card="${app.escapeHtml(t.id)}"
                  style="min-width:132px;max-width:142px;flex:0 0 auto;text-align:left;padding:6px;border-radius:10px;border:${isAct ? "2px solid " + (t.accent || "#0f4c81") : "1px solid var(--border-hairline)"};background:${isAct ? "var(--bg-canvas)" : "var(--bg-surface)"};cursor:pointer;display:flex;flex-direction:column;gap:5px;"
                >
                  ${thumb}
                  <div style="font-size:0.73rem;font-weight:700;color:var(--text-primary);line-height:1.2;white-space:normal;">${app.escapeHtml(t.name)}</div>
                </button>
              `;
            })
            .join("");

          stripEl.querySelectorAll("[data-pv-tpl-card]").forEach(function (cardBtn) {
            cardBtn.addEventListener("click", function () {
              const cid = cardBtn.getAttribute("data-pv-tpl-card");
              selectedTpl = templates.find(function (t) { return t.id === cid; }) || selectedTpl;
              renderGalleryStrip();
              renderPreview();
            });
          });
        }
      }

      function renderPreview() {
        document.getElementById("pvPreviewWrap").innerHTML = buildVoucherPrintHtml(workingVoucher, business, party, selectedTpl);
      }

      renderGalleryStrip();
      renderPreview();

      const toggleAllBtn = document.getElementById("pvToggleAllBtn");
      if (toggleAllBtn) {
        toggleAllBtn.addEventListener("click", function () {
          showAllTemplates = !showAllTemplates;
          toggleAllBtn.textContent = showAllTemplates
            ? (isHi ? `${docCat} डिज़ाइन दिखाएँ` : `Only ${docCat}`)
            : (isHi ? `सभी डिज़ाइन देखें (${templates.length})` : `Show All (${templates.length})`);
          renderGalleryStrip();
        });
      }

      const selEl = document.getElementById("pvTplSelect");
      if (selEl) {
        selEl.addEventListener("change", function () {
          selectedTpl = templates.find(function (t) { return t.id === selEl.value; }) || selectedTpl;
          renderGalleryStrip();
          renderPreview();
        });
      }

      const notesInput = document.getElementById("pvNotesInput");
      if (notesInput) {
        notesInput.addEventListener("input", function () {
          workingVoucher.notes = notesInput.value;
          renderPreview();
        });
      }

      document.querySelectorAll("[data-pv-tc-pack]").forEach(function (pkBtn) {
        pkBtn.addEventListener("click", function () {
          const pkId = pkBtn.getAttribute("data-pv-tc-pack");
          const pk = tcPacks.find(function (p) { return p.id === pkId; });
          if (pk && notesInput) {
            notesInput.value = pk.lines.join("\n");
            workingVoucher.notes = notesInput.value;
            renderPreview();
          }
        });
      });

      document.querySelectorAll("[data-pv-tc-add]").forEach(function (chipBtn) {
        chipBtn.addEventListener("click", function () {
          const idx = parseInt(chipBtn.getAttribute("data-pv-tc-add"), 10);
          const clause = termsBank[idx];
          if (!clause || !notesInput) return;
          const current = notesInput.value.trim();
          if (current.indexOf(clause) === -1) {
            notesInput.value = current ? current + "\n" + clause : clause;
            workingVoucher.notes = notesInput.value;
            renderPreview();
          }
        });
      });

      document.getElementById("pvSaveDesignBtn").addEventListener("click", function () {
        if (!selectedTpl) return;
        const updated = Object.assign({}, workingVoucher, {
          templateId: selectedTpl.id,
          notes: notesInput ? notesInput.value.trim() : workingVoucher.notes,
          updatedAt: new Date().toISOString()
        });
        global.PBM_DB.put("vouchers", updated).then(function () {
          app.showToast(isHi ? "डिज़ाइन व T&C इस डॉक्यूमेंट पर सेव हो गए।" : "Design & T&C saved to document.", false);
          if (typeof onTemplateChanged === "function") onTemplateChanged(updated);
        });
      });

      document.getElementById("pvPdfBtn").addEventListener("click", function () {
        const docHtml = buildVoucherPrintHtml(workingVoucher, business, party, selectedTpl);
        const isThermal = selectedTpl && (selectedTpl.paper === "THERMAL" || selectedTpl.layout === "thermal");
        downloadPdfFromHtml(docHtml, workingVoucher.voucherNo || "Document", { isThermal: isThermal });
      });

      document.getElementById("pvShareBtn").addEventListener("click", function () {
        const docHtml = buildVoucherPrintHtml(workingVoucher, business, party, selectedTpl);
        const isThermal = selectedTpl && (selectedTpl.paper === "THERMAL" || selectedTpl.layout === "thermal");
        const summaryText = buildVoucherSummaryText(workingVoucher, business, party);
        sharePdfFromHtml(docHtml, workingVoucher.voucherNo || "Document", workingVoucher.voucherNo || "Document", summaryText, {
          isThermal: isThermal
        });
      });

      document.getElementById("pvPrintBtn").addEventListener("click", function () {
        triggerNativePrint(buildVoucherPrintHtml(workingVoucher, business, party, selectedTpl));
      });
    });
  }

  function shareText(title, text) {
    const app = global.PBM_APP;
    if (navigator.share) {
      navigator.share({ title: title, text: text }).catch(function () {
        // User cancelled share sheet
      });
      return;
    }

    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(function () {
        app.showToast(app.getLang() === "hi" ? "मैसेज कॉपी हो गया — WhatsApp पर पेस्ट करें।" : "Summary copied — paste into WhatsApp.", false);
      });
    } else {
      app.openModal(title, `<textarea class="form-textarea" readonly>${app.escapeHtml(text)}</textarea>`);
    }
  }

  global.PBM_PRINT = {
    openSignaturePadModal: openSignaturePadModal,
    generatePdfFromHtml: generatePdfFromHtml,
    downloadPdfFromHtml: downloadPdfFromHtml,
    sharePdfFromHtml: sharePdfFromHtml,
    downloadVoucherPdf: downloadVoucherPdf,
    shareVoucherPdf: shareVoucherPdf,
    triggerNativePrint: triggerNativePrint,
    printHtmlDocument: printHtmlDocument,
    buildVoucherPrintHtml: buildVoucherPrintHtml,
    openDocumentPreviewModal: openDocumentPreviewModal,
    shareText: shareText
  };
})(window);
