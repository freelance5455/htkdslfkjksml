'use strict';
/* ============ قسم الصيدلية ============ */
let mQ = '';

PAGES.ph_pend = {
  title: 'الوصفات بانتظار الصرف', live: true,
  render() {
    const P = D.prescriptions.filter(r => r.status === 'pending').sort((a, b) => a.ts - b.ts), t = today();
    const sold = D.dispenses.filter(d => d.date === t);
    const low = D.medicines.filter(m => m.qty < 10 && !(m.expiry && m.expiry < t)).length, exp = D.medicines.filter(m => m.expiry && m.expiry < t).length;
    $('page').innerHTML =
      '<div class="stats">' + stat('file', 'وصفات بالانتظار', P.length) + stat('pill', 'أصناف مصروفة اليوم', sum(sold, d => d.qty), 'g') + stat('alert', 'أصناف منخفضة المخزون', low, 'n') + stat('alert', 'منتهية الصلاحية', exp, 'n') + '</div>' +
      (P.map(r => '<div class="card"><div class="card-h"><div class="av num">' + r.patientNo + '</div><div class="grow"><div class="t" style="font-weight:700;color:var(--navy)">' + esc(r.patientName) + '</div><div class="mut num">' + r.date + ' · ' + hm(r.ts) + (r.doctorName ? ' · د. ' + esc(r.doctorName) : '') + '</div></div>' + badge('بانتظار الصرف', 'warn') + '</div>' +
        r.items.map(i => { const m = get('medicines', i.medId), ex = m && m.expiry && m.expiry < t, ok = m && m.qty >= i.qty && !ex;
          return '<div class="row" style="padding:.55rem .8rem"><div class="grow"><b>' + esc(i.name) + '</b> <span class="mut">× <span class="num">' + i.qty + '</span></span><div class="mut">' + esc(i.dosage) + '</div></div>' + (ok ? badge('متاح ' + m.qty, 'ok') : badge(ex ? 'منتهي الصلاحية' : !m ? 'غير موجود' : 'المتاح ' + m.qty, 'err')) + '</div>'; }).join('') +
        '<div class="btns" style="margin-top:.7rem"><button class="btn ok" onclick="dispenseRx(' + r.id + ')">' + ic('pill', 'sm') + 'صرف الوصفة</button><button class="btn ghost" onclick="printRx(' + r.id + ')">' + ic('printer', 'sm') + 'طباعة</button></div></div>').join('') || '<div class="card">' + empty('file', 'لا توجد وصفات بانتظار الصرف') + '</div>');
  }
};
async function dispenseRx(id, partial) {
  const j = await safe(() => api('/api/dispense', { rxId: id, partial: !!partial })); if (!j) return;
  if (j.ok === false) {
    if (j.canPartial) { if (await ask('أصناف غير متاحة أو منتهية: ' + j.short.join('، ') + '\nهل تريد صرف المتاح فقط؟', { ok: 'صرف المتاح', title: 'نقص في المخزون' })) return dispenseRx(id, true); return; }
    return toast('لا يمكن الصرف: ' + j.short.join('، ') + ' (غير متوفر أو منتهي)', 'err');
  }
  toast('تم الصرف وخُصمت الكميات من المخزون');
}

/* ---------- المخزون ---------- */
PAGES.ph_inv = {
  title: 'مخزون الأدوية', live: false,
  onData(s) { if (s === 'medicines') mDraw(); },
  render() {
    $('page').innerHTML = pagehead('المخزون', '<button class="btn accent" onclick="medForm()">' + ic('plus', 'sm') + 'دواء جديد</button>') +
      '<div class="card"><input id="mq" class="input" placeholder="ابحث بالاسم التجاري أو العلمي أو الشركة أو الباركود… (مثال: Amox)" value="' + esc(mQ) + '" oninput="mQ=this.value;mDraw()" autocomplete="off"><div class="mut" style="margin-top:.6rem"><span class="warnx">■ برتقالي</span> الكمية أقل من 10 · <span class="errx">■ أحمر</span> منتهي الصلاحية</div></div><div id="mtbl"></div>';
    mDraw();
  }
};
function mDraw() {
  const e = $('mtbl'); if (!e) return; const q = mQ.trim().toLowerCase(), t = today();
  let L = [...D.medicines];
  if (q) {
    const st = m => m.tradeName.toLowerCase().startsWith(q) || (m.scientificName || '').toLowerCase().startsWith(q);
    L = L.filter(m => [m.tradeName, m.scientificName, m.manufacturer, m.barcode].some(x => (x || '').toLowerCase().includes(q))).sort((a, b) => (+st(b)) - (+st(a)) || a.tradeName.localeCompare(b.tradeName));
  } else L.sort((a, b) => a.tradeName.localeCompare(b.tradeName));
  e.innerHTML = '<div class="tbl-wrap"><table class="tbl" style="min-width:760px"><tr><th>الاسم التجاري</th><th>الاسم العلمي</th><th>الشركة</th><th>الباركود</th><th>الكمية</th><th>الانتهاء</th><th>السعر</th><th></th></tr>' +
    (L.map(m => { const ex = m.expiry && m.expiry < t, lw = m.qty < 10;
      return '<tr class="' + (ex ? 'exp' : lw ? 'low' : '') + '"><td><b>' + esc(m.tradeName) + '</b></td><td>' + esc(m.scientificName) + '</td><td>' + esc(m.manufacturer) + '</td><td><span class="ltr num">' + esc(m.barcode) + '</span></td><td><b class="num">' + m.qty + '</b> ' + (ex ? '' : lw ? badge('منخفض', 'warn') : '') + '</td><td class="num">' + esc(m.expiry) + ' ' + (ex ? badge('منتهي', 'err') : '') + '</td><td class="num">' + num(m.price) + '</td><td style="text-align:end;white-space:nowrap"><button class="btn ghost sm icon" onclick="medForm(' + m.id + ')" aria-label="تعديل">' + ic('edit', 'sm') + '</button> <button class="btn ghost sm icon" onclick="delMed(' + m.id + ')" aria-label="حذف">' + ic('trash', 'sm') + '</button></td></tr>'; }).join('') || '<tr><td colspan="8">' + empty('box', q ? 'لا توجد أدوية مطابقة' : 'لا توجد أدوية في المخزون بعد') + '</td></tr>') + '</table></div>';
}
function medForm(id) {
  const m = id ? get('medicines', id) : {};
  openModal(mhead(id ? 'تعديل دواء' : 'دواء جديد') +
    '<div class="grid g2"><div class="field"><label>الاسم التجاري *</label><input id="m_t" value="' + esc(m.tradeName) + '"></div><div class="field"><label>الاسم العلمي</label><input id="m_s" value="' + esc(m.scientificName) + '"></div>' +
    '<div class="field"><label>الشركة المصنعة</label><input id="m_m" value="' + esc(m.manufacturer) + '"></div><div class="field"><label>الباركود</label><input id="m_b" class="ltr" style="direction:ltr;text-align:left" value="' + esc(m.barcode) + '"></div>' +
    '<div class="field"><label>الكمية المتاحة *</label><input id="m_q" type="number" min="0" value="' + esc(m.qty) + '" inputmode="numeric"></div><div class="field"><label>تاريخ الانتهاء</label><input id="m_e" type="date" value="' + esc(m.expiry) + '"></div>' +
    '<div class="field"><label>سعر البيع *</label><input id="m_p" type="number" min="0" step="any" value="' + esc(m.price) + '" inputmode="decimal"></div></div>' +
    '<div class="btns"><button class="btn" onclick="saveMed(' + (id || 0) + ')">حفظ</button><button class="btn ghost" onclick="closeModal()">إلغاء</button></div>');
}
async function saveMed(id) {
  const t = $('m_t').value.trim(); if (!t || $('m_q').value === '' || $('m_p').value === '') return toast('الاسم والكمية والسعر مطلوبة', 'err');
  const m = { tradeName: t, scientificName: $('m_s').value.trim(), manufacturer: $('m_m').value.trim(), barcode: $('m_b').value.trim(), qty: +$('m_q').value, expiry: $('m_e').value, price: +$('m_p').value }; if (id) m.id = id;
  if (!await safe(() => put('medicines', m))) return; closeModal(); toast('تم الحفظ'); mDraw();
}
async function delMed(id) {
  const m = get('medicines', id);
  if (!await ask('حذف «' + m.tradeName + '» من المخزون؟', { danger: true, ok: 'حذف' })) return;
  await safe(() => del('medicines', id)); mDraw();
}

/* ---------- المبيعات ---------- */
PAGES.ph_sales = {
  title: 'تقرير المبيعات', live: true,
  render() {
    const R = D.dispenses.filter(filt(FL.sales)).sort((a, b) => b.ts - a.ts), items = sum(R, d => d.qty), tot = sum(R, d => d.total);
    window._salesRows = R;
    $('page').innerHTML = pagehead('المبيعات — ' + periodLabel(FL.sales), '<button class="btn ghost" onclick="printSales(window._salesRows,periodLabel(FL.sales))"' + (R.length ? '' : ' disabled') + '>' + ic('printer', 'sm') + 'طباعة التقرير</button>') + filterBar('sales') +
      '<div class="stats">' + stat('pill', 'عدد الأصناف المباعة', items) + stat('bars', 'إجمالي القيمة', num(tot) + ' <small>' + esc(S.settings.currency) + '</small>', 'g') + '</div>' +
      '<div class="tbl-wrap"><table class="tbl"><tr><th>الوقت</th><th>المريض</th><th>الدواء</th><th>الكمية</th><th>السعر</th><th>الإجمالي</th></tr>' +
      (R.map(d => '<tr><td class="num">' + d.date + ' · ' + hm(d.ts) + '</td><td>' + d.patientNo + ' — ' + esc(d.patientName) + '</td><td>' + esc(d.name) + '</td><td class="num">' + d.qty + '</td><td class="num">' + num(d.price) + '</td><td class="num"><b>' + num(d.total) + '</b></td></tr>').join('') || '<tr><td colspan="6">' + empty('bars', 'لا توجد مبيعات في هذه الفترة') + '</td></tr>') + '</table></div>';
  }
};
