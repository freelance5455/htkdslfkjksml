/* flags.js — Phase 9.2: national flags (c. 1936) for the Old World scenario, drawn with canvas shapes (no image files).
   Each flag is drawn on a 90 x 60 unit canvas. Where the 1936 flag carried a political emblem (Germany, Italy, Spain's
   old arms...) a plain historical or neutral design is used instead. Detailed coats of arms are reduced to simple shapes. */
(function (G) {
  'use strict';
  const F = {};
  const W = 90, H = 60;
  const R = (c, col, x, y, w, h) => { c.fillStyle = col; c.fillRect(x, y, w, h); };
  const hs = (c, cols, w) => { const n = cols.length, hh = H / n; cols.forEach((k, i) => R(c, k, 0, i * hh, W, hh + 0.3)); };
  const vs = (c, cols) => { const n = cols.length, ww = W / n; cols.forEach((k, i) => R(c, k, i * ww, 0, ww + 0.3, H)); };
  const hw = (c, cols, ws) => { let y = 0; const t = ws.reduce((a, b) => a + b, 0); cols.forEach((k, i) => { const hh = H * ws[i] / t; R(c, k, 0, y, W, hh + 0.3); y += hh; }); };
  const circle = (c, col, x, y, r) => { c.fillStyle = col; c.beginPath(); c.arc(x, y, r, 0, 6.2832); c.fill(); };
  const poly = (c, col, pts) => { c.fillStyle = col; c.beginPath(); pts.forEach((p, i) => i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1])); c.closePath(); c.fill(); };
  const star = (c, col, x, y, r, n, rot) => {
    n = n || 5; rot = rot == null ? -Math.PI / 2 : rot; c.fillStyle = col; c.beginPath();
    for (let i = 0; i < n * 2; i++) { const a = rot + i * Math.PI / n, rr = i % 2 ? r * (n === 5 ? 0.382 : 0.5) : r; i ? c.lineTo(x + rr * Math.cos(a), y + rr * Math.sin(a)) : c.moveTo(x + rr * Math.cos(a), y + rr * Math.sin(a)); }
    c.closePath(); c.fill();
  };
  const crescent = (c, col, bg, x, y, r, off) => { circle(c, col, x, y, r); circle(c, bg, x + off, y, r * 0.8); };
  const nordic = (c, bg, outer, inner, ix) => {
    R(c, bg, 0, 0, W, H); ix = ix || 32;
    if (outer) { R(c, outer, ix - 11, 0, 22, H); R(c, outer, 0, 19, W, 22); R(c, inner, ix - 5, 0, 10, H); R(c, inner, 0, 25, W, 10); }
    else { R(c, inner, ix - 6, 0, 12, H); R(c, inner, 0, 24, W, 12); }
  };
  // Union Jack inside the box (x,y,w,h)
  const jack = (c, x, y, w, h) => {
    c.save(); c.beginPath(); c.rect(x, y, w, h); c.clip(); c.translate(x, y); c.scale(w / 60, h / 30);
    R(c, '#1c2f7a', 0, 0, 60, 30);
    c.strokeStyle = '#fff'; c.lineWidth = 6; c.beginPath(); c.moveTo(0, 0); c.lineTo(60, 30); c.moveTo(60, 0); c.lineTo(0, 30); c.stroke();
    c.strokeStyle = '#c8202f'; c.lineWidth = 2.2; c.beginPath(); c.moveTo(0, 0); c.lineTo(60, 30); c.moveTo(60, 0); c.lineTo(0, 30); c.stroke();
    R(c, '#fff', 0, 11, 60, 8); R(c, '#fff', 26, 0, 8, 30); R(c, '#c8202f', 0, 12.8, 60, 4.4); R(c, '#c8202f', 27.8, 0, 4.4, 30);
    c.restore();
  };

  F.GBR = c => jack(c, 0, 0, W, H);
  F.FRA = c => vs(c, ['#1f3f9a', '#f4f4f4', '#d0262e']);
  F.GER = c => hs(c, ['#111111', '#f4f4f4', '#c8202f']);
  F.ITA = c => vs(c, ['#1b8a45', '#f4f4f4', '#d0262e']);
  F.ESP = c => hw(c, ['#c8202f', '#f2c230', '#6b2a7a'], [1, 1, 1]);
  F.POR = c => { R(c, '#1b7a3a', 0, 0, 36, H); R(c, '#d0262e', 36, 0, 54, H); circle(c, '#f2c230', 36, 30, 9); circle(c, '#fff', 36, 30, 5.5); R(c, '#d0262e', 33, 27, 6, 6); };
  F.BEL = c => vs(c, ['#111111', '#f2c230', '#d0262e']);
  F.NED = c => hs(c, ['#c8202f', '#f4f4f4', '#264a9e']);
  F.POL = c => hs(c, ['#f4f4f4', '#d0262e']);
  F.CZE = c => { hs(c, ['#f4f4f4', '#d0262e']); poly(c, '#1f3f9a', [[0, 0], [45, 30], [0, 60]]); };
  F.AUT = c => hs(c, ['#c8202f', '#f4f4f4', '#c8202f']);
  F.HUN = c => hs(c, ['#c8202f', '#f4f4f4', '#2f7a43']);
  F.ROM = c => vs(c, ['#27479c', '#f2c230', '#d0262e']);
  F.YUG = c => hs(c, ['#27479c', '#f4f4f4', '#c8202f']);
  F.BUL = c => hs(c, ['#f4f4f4', '#2a8a4a', '#c8202f']);
  F.GRE = c => {
    for (let i = 0; i < 9; i++) R(c, i % 2 ? '#f4f4f4' : '#2a52a8', 0, i * H / 9, W, H / 9 + 0.3);
    R(c, '#2a52a8', 0, 0, 33.4, 33.4); R(c, '#f4f4f4', 13.4, 0, 6.6, 33.4); R(c, '#f4f4f4', 0, 13.4, 33.4, 6.6);
  };
  F.TUR = c => { R(c, '#d8222c', 0, 0, W, H); crescent(c, '#fff', '#d8222c', 35, 30, 15, 5); star(c, '#fff', 52, 30, 7, 5, 0); };
  F.SWE = c => nordic(c, '#1e5aa8', null, '#f2c230', 32);
  F.NOR = c => nordic(c, '#c8202f', '#f4f4f4', '#26406e', 32);
  F.FIN = c => nordic(c, '#f4f4f4', null, '#2a4a9a', 32);
  F.DEN = c => nordic(c, '#c8202f', null, '#f4f4f4', 32);
  F.BAL = c => hs(c, ['#3b78c0', '#111111', '#f4f4f4']);
  F.SOV = c => {
    R(c, '#c8202f', 0, 0, W, H); const y = '#f2c230';
    star(c, y, 18, 13, 7, 5);
    c.strokeStyle = y; c.lineWidth = 2.4; c.beginPath(); c.arc(16, 33, 9, 3.4, 5.9); c.stroke();
    c.lineWidth = 2.4; c.beginPath(); c.moveTo(9, 40); c.lineTo(24, 26); c.stroke();
    c.beginPath(); c.moveTo(12, 28); c.lineTo(22, 40); c.stroke(); R(c, y, 8.5, 26, 7, 3.4);
  };
  F.EGY = c => { R(c, '#1f8a4a', 0, 0, W, H); crescent(c, '#fff', '#1f8a4a', 36, 30, 16, 5); [0, 1, 2].forEach(i => star(c, '#fff', 52 + 0 * i, 20 + i * 10, 4.2, 5)); };
  F.SAU = c => { R(c, '#1f8a4a', 0, 0, W, H); R(c, '#f4f4f4', 14, 41, 62, 3); poly(c, '#f4f4f4', [[78, 42.5], [66, 38.5], [66, 46.5]]);
    c.strokeStyle = '#f4f4f4'; c.lineWidth = 2.4; c.beginPath(); for (let i = 0; i < 8; i++) { const x = 17 + i * 7; c.moveTo(x, 24); c.quadraticCurveTo(x + 3.5, 14 + (i % 2) * 5, x + 7, 24); } c.stroke(); };
  F.IRQ = c => { hs(c, ['#111111', '#f4f4f4', '#1f8a4a']); poly(c, '#c8202f', [[0, 0], [45, 30], [0, 60]]); star(c, '#fff', 11, 24, 4, 7); star(c, '#fff', 11, 36, 4, 7); };
  F.PER = c => { hs(c, ['#2a9a4a', '#f4f4f4', '#d0262e']); circle(c, '#e8b83a', 45, 30, 7.5); circle(c, '#f4f4f4', 45, 30, 4); };
  F.AFG = c => { vs(c, ['#111111', '#c8202f', '#1f8a4a']); circle(c, '#f4f4f4', 45, 30, 9); circle(c, '#c8202f', 45, 30, 5.5); };
  F.CHN = c => {
    R(c, '#d8222c', 0, 0, W, H); R(c, '#1f3f9a', 0, 0, 45, 30);
    c.fillStyle = '#fff'; c.beginPath();
    for (let i = 0; i < 24; i++) { const a = i * Math.PI / 12 - Math.PI / 2, r = i % 2 ? 7 : 12.5; i ? c.lineTo(22.5 + r * Math.cos(a), 15 + r * Math.sin(a)) : c.moveTo(22.5 + r * Math.cos(a), 15 + r * Math.sin(a)); }
    c.closePath(); c.fill(); circle(c, '#1f3f9a', 22.5, 15, 6.4); circle(c, '#fff', 22.5, 15, 5.2);
  };
  F.MNG = c => { vs(c, ['#d0262e', '#2a5ab0', '#d0262e']); const y = '#f2c230'; circle(c, y, 15, 17, 3); poly(c, y, [[15, 22], [11, 32], [19, 32]]); R(c, y, 7, 36, 16, 2); R(c, y, 7, 11, 2, 25); R(c, y, 21, 11, 2, 25); };
  F.JPN = c => { R(c, '#f6f6f6', 0, 0, W, H); circle(c, '#c8202f', 45, 30, 18); };
  F.SIA = c => hw(c, ['#c8202f', '#f4f4f4', '#27346e', '#f4f4f4', '#c8202f'], [1, 1, 2, 1, 1]);
  F.AUS = c => {
    R(c, '#1c2f7a', 0, 0, W, H); jack(c, 0, 0, 45, 30);
    star(c, '#fff', 22.5, 46, 6, 7); [[66, 10], [58, 26], [74, 28], [66, 46]].forEach(p => star(c, '#fff', p[0], p[1], 3.6, 7)); star(c, '#fff', 70, 36, 2, 5);
  };
  F.SAF = c => { hs(c, ['#e07a1e', '#f4f4f4', '#27479c']); jack(c, 38, 21, 14, 18); circle(c, '#e07a1e', 33, 30, 3.4); circle(c, '#c8202f', 57, 30, 3.4); };
  F.USA = c => {
    for (let i = 0; i < 13; i++) R(c, i % 2 ? '#f4f4f4' : '#c8202f', 0, i * H / 13, W, H / 13 + 0.3);
    R(c, '#27346e', 0, 0, 38, 32);
    c.fillStyle = '#fff'; for (let r = 0; r < 6; r++) for (let q = 0; q < (r % 2 ? 5 : 6); q++) { c.beginPath(); c.arc(4.5 + q * 6.2 + (r % 2 ? 3.1 : 0), 4.2 + r * 5.2, 1.3, 0, 6.3); c.fill(); }
  };
  F.CAN = c => { R(c, '#c8202f', 0, 0, W, H); jack(c, 0, 0, 45, 30); R(c, '#f4f4f4', 56, 18, 20, 24); R(c, '#c8202f', 58, 20, 16, 9); R(c, '#2a8a4a', 58, 31, 16, 9); circle(c, '#f2c230', 66, 24, 2.4); };
  F.MEX = c => { vs(c, ['#1b8a45', '#f4f4f4', '#d0262e']); circle(c, '#8a6a3a', 45, 30, 8); circle(c, '#2a8a4a', 45, 33, 4); };
  F.CAM = c => hw(c, ['#4a90d0', '#f4f4f4', '#4a90d0'], [1, 1, 1]);
  F.CUB = c => { for (let i = 0; i < 5; i++) R(c, i % 2 ? '#f4f4f4' : '#27479c', 0, i * H / 5, W, H / 5 + 0.3); poly(c, '#d0262e', [[0, 0], [40, 30], [0, 60]]); star(c, '#fff', 13, 30, 8, 5); };
  F.VEN = c => { hs(c, ['#f2c230', '#27479c', '#d0262e']); for (let i = 0; i < 7; i++) { const a = Math.PI * (0.15 + 0.7 * i / 6); star(c, '#fff', 45 - 24 * Math.cos(a), 36 - 14 * Math.sin(a) + 2, 2.2, 5); } };
  F.COL = c => hw(c, ['#f2c230', '#27479c', '#d0262e'], [2, 1, 1]);
  F.PRU = c => vs(c, ['#d0262e', '#f4f4f4', '#d0262e']);
  F.BRA = c => { R(c, '#1b8a45', 0, 0, W, H); poly(c, '#f2c230', [[45, 5], [84, 30], [45, 55], [6, 30]]); circle(c, '#27479c', 45, 30, 14);
    c.save(); c.beginPath(); c.arc(45, 30, 14, 0, 6.3); c.clip(); c.strokeStyle = '#f4f4f4'; c.lineWidth = 3; c.beginPath(); c.moveTo(28, 26); c.quadraticCurveTo(45, 34, 62, 28); c.stroke(); c.restore();
    [[38, 24], [48, 22], [52, 31], [41, 36], [45, 28]].forEach(p => star(c, '#fff', p[0], p[1], 1.6, 5)); };
  F.ARG = c => { hs(c, ['#78b4e0', '#f4f4f4', '#78b4e0']); star(c, '#e8b83a', 45, 30, 5, 16, 0); circle(c, '#e8b83a', 45, 30, 3.4); };

  G.REAL_FLAGS = F;
  G.drawRealFlag = function (c, x, y, w, h, id) {
    const fn = F[id]; if (!fn) return false;
    c.save(); c.translate(x, y); c.scale(w / W, h / H); c.beginPath(); c.rect(0, 0, W, H); c.clip();
    fn(c); c.restore();
    c.save(); c.strokeStyle = 'rgba(0,0,0,.55)'; c.lineWidth = 1; c.strokeRect(x + .5, y + .5, w - 1, h - 1); c.restore();
    return true;
  };
})(window.EMP = window.EMP || {});
