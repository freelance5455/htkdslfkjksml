(function () {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const LI = { ar: 0, en: 1, fr: 2, es: 3, pt: 4, de: 5, tr: 6 };
  const L = function () { const i = LI[state.lang]; const v = arguments[i == null ? 1 : i]; return v == null ? arguments[1] : v; };
  const fmt = (n) => Number(n).toLocaleString('en-US');
  const MAXL = 8;
  const cost = (n) => 4000 * Math.pow(2, n - 1);            // upgrade to level n
  const needTier = (n) => 9 - n;                              // level n needs tier <= 9-n
  const tokPct = (n) => 10 * n, xpBon = (n) => 6 * n;
  const NAMES = [
    ['ملعب الحي', 'Local Pitch', 'Terrain de quartier', 'Campo de barrio', 'Campo de bairro', 'Bolzplatz', 'Mahalle Sahası'],
    ['ملعب المجتمع', 'Community Ground', 'Stade communal', 'Campo comunitario', 'Campo comunitário', 'Gemeindeplatz', 'Belediye Sahası'],
    ['ملعب البلدة', 'Town Stadium', 'Stade municipal', 'Estadio municipal', 'Estádio municipal', 'Stadtstadion', 'Şehir Stadyumu'],
    ['ملعب المدينة', 'City Ground', 'Stade de la ville', 'Estadio de la ciudad', 'Estádio da cidade', 'Städtische Arena', 'Şehir Arenası'],
    ['الملعب الإقليمي', 'Regional Stadium', 'Stade régional', 'Estadio regional', 'Estádio regional', 'Regionalstadion', 'Bölge Stadyumu'],
    ['ملعب الدوري', 'League Arena', 'Arène de la ligue', 'Arena de la liga', 'Arena da liga', 'Liga-Arena', 'Lig Arenası'],
    ['الملعب الوطني', 'National Stadium', 'Stade national', 'Estadio nacional', 'Estádio nacional', 'Nationalstadion', 'Ulusal Stadyum'],
    ['الساحة الكبرى', 'Grand Arena', 'Grande arène', 'Gran arena', 'Grande arena', 'Große Arena', 'Büyük Arena'],
    ['المعبد الذهبي', 'Golden Colosseum', 'Colisée doré', 'Coliseo dorado', 'Coliseu dourado', 'Goldenes Kolosseum', 'Altın Kolezyum']
  ];
  const nm = (n) => { const r = NAMES[n], v = r[LI[state.lang]]; return v == null ? r[1] : v; };
  function st() { const e = FFMEng.eng(); e.stad = e.stad || { lvl: 0 }; e.stad.lvl = Math.max(0, Math.min(MAXL, e.stad.lvl | 0)); return e.stad; }
  const lvl = () => st().lvl;

  /* ---------- pixel-art stadium (top-down), distinct for every level ---------- */
  function stadSVG(n, px) {
    const plate = ['#6a5a3e', '#3f6a3a', '#3d6240', '#47505e', '#3f4a5c', '#2f3b52', '#2a3550', '#1f2f5e', '#3a2f12'][n];
    const seatA = ['', '#8a8f97', '#8f9aa8', '#8c97b8', '#7f9cd0', '#8fb0e6', '#a9c4f2', '#bcd2ff', '#f1d27a'][n];
    const seatB = ['', '#5d626a', '#626d7d', '#5d6a8e', '#4f6fa6', '#5a7fc2', '#6f90d4', '#7c9fe6', '#c79a2e'][n];
    const side = [0, 3, 4, 6, 8, 10, 12, 14, 16][n], end = [0, 0, 3, 4, 6, 7, 9, 10, 12][n];
    let r = 7 + n * 13; const rnd = () => (r = (r * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff;
    let o = '', R = (x, y, w, h, c, op) => { o += `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${c}"${op ? ` opacity="${op}"` : ''}/>`; };
    R(0, 0, 64, 64, plate);
    if (n >= 1 && n <= 2) for (let i = 0; i < 40; i++) R((rnd() * 62) | 0, (rnd() * 62) | 0, 1, 1, '#4d7a45');
    if (n === 0) for (let i = 0; i < 50; i++) R((rnd() * 62) | 0, (rnd() * 62) | 0, 1, 1, rnd() > .5 ? '#7d6a48' : '#574a30');
    // stands
    const L0 = 19 - side, R0 = 45, T0 = 13 - end, B0 = 51;
    const stand = (x, y, w, h, vert) => {
      R(x, y, w, h, seatA);
      for (let i = 0; i < (vert ? w : h); i += 2) vert ? R(x + i, y, 1, h, seatB) : R(x, y + i, w, 1, seatB);
      if (n >= 3) { const m = vert ? (w / 2) | 0 : (h / 2) | 0; vert ? R(x, y, m, h, seatB, .35) : R(x, y, w, m, seatB, .35); }
      if (n >= 5) for (let i = 0; i < w * h / 7; i++) R(x + ((rnd() * w) | 0), y + ((rnd() * h) | 0), 1, 1, ['#d9443a', '#f4f4f4', '#f2c230', '#2f73d9'][(rnd() * 4) | 0]);
    };
    if (side) { stand(L0, 13, side, 38, true); stand(R0, 13, side, 38, true); }
    if (end) { stand(19, T0, 26, end, false); stand(19, B0, 26, end, false); }
    if (n >= 4) { [[L0, T0], [R0, T0], [L0, B0], [R0, B0]].forEach(([x, y]) => R(x, y, side, end, seatB)); }
    // roof / rim
    if (n >= 5) { const x0 = L0, y0 = T0 || 13, w = (R0 + side) - L0, h = (B0 + end) - y0; o += `<rect x="${x0 + .5}" y="${y0 + .5}" width="${w - 1}" height="${h - 1}" fill="none" stroke="${n >= 8 ? '#f6d86b' : '#e7ecf2'}" stroke-width="1"/>`; }
    if (n >= 6) { R(L0, 13, (side / 2) | 0, 38, '#e8eef7', .28); R(R0 + (side / 2 | 0), 13, side - (side / 2 | 0), 38, '#e8eef7', .28); }
    if (n >= 7) { R(L0 + 1, T0 + 1, 3, 1, '#2f73d9'); R(R0 + side - 4, B0 + end - 2, 3, 1, '#2f73d9'); for (let i = 0; i < 6; i++) R(21 + i * 4, T0 + 1, 2, 1, i % 2 ? '#f4f4f4' : '#2f73d9'); }
    if (n >= 8) { R(L0, T0, 2, 2, '#f6d86b'); R(R0 + side - 2, T0, 2, 2, '#f6d86b'); R(L0, B0 + end - 2, 2, 2, '#f6d86b'); R(R0 + side - 2, B0 + end - 2, 2, 2, '#f6d86b'); R(30, 1, 4, 1, '#f6d86b'); }
    if (n >= 4) { R(28, Math.max(0, T0 - 1) + (n >= 6 ? 2 : 0), 8, 2, '#10161f'); R(29, Math.max(0, T0 - 1) + (n >= 6 ? 2 : 0), 6, 1, '#39d0ff'); }
    if (n >= 6) { R(29, 62, 6, 2, '#10161f'); R(31, 62, 2, 1, '#f6d86b'); }
    // pitch
    R(19, 13, 26, 38, '#e9edf2');
    for (let i = 0; i < 12; i++) R(20, 14 + i * 3, 24, 3, i % 2 ? '#3e9a46' : '#46a94e');
    const ln = '#f1f6ee';
    o += `<g fill="none" stroke="${ln}" stroke-width="1"><rect x="20.5" y="14.5" width="23" height="35"/><line x1="20.5" y1="32" x2="43.5" y2="32"/><circle cx="32" cy="32" r="4.5"/><rect x="26.5" y="14.5" width="11" height="5"/><rect x="26.5" y="44.5" width="11" height="5"/></g>`;
    R(31, 31, 2, 2, ln);
    // floodlights
    const pts = n >= 5 ? [[1, 1], [59, 1], [1, 59], [59, 59]] : n >= 3 ? [[1, 1], [59, 59]] : [];
    pts.forEach(([x, y]) => { R(x, y, 3, 3, '#1a2230'); R(x + 1, y + 1, 1, 1, n >= 7 ? '#fff6a8' : '#d8dee9'); if (n >= 7) R(x - 1 + (x > 30 ? 0 : 0), y - 1, 5, 5, '#fff6a8', .22); });
    if (n >= 8) o += `<rect x=".5" y=".5" width="63" height="63" fill="none" stroke="#f6d86b" stroke-width="1"/>`;
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="${px}" height="${px}" shape-rendering="crispEdges" style="image-rendering:pixelated;display:block">${o}</svg>`;
  }


  /* ---------- rotatable pixel view: the 2D top-down map is extruded by a height map and re-projected while you drag ---------- */
  const SRC = 64, VIEW = 176;
  let vw = null;
  function heightMap(n) {
    const side = [0, 3, 4, 6, 8, 10, 12, 14, 16][n], end = [0, 0, 3, 4, 6, 7, 9, 10, 12][n], L0 = 19 - side, R0 = 45, T0 = 13 - end, B0 = 51;
    const rise = 1.5 + n * 0.55, H = new Float32Array(SRC * SRC);
    for (let y = 0; y < SRC; y++) for (let x = 0; x < SRC; x++) {
      let h = 0;
      if (side && y >= 13 && y < 51) {
        if (x >= L0 && x < 19) h = 1 + (19 - x) / side * rise;
        else if (x >= R0 && x < R0 + side) h = 1 + (x - R0 + 1) / side * rise;
      }
      if (end && x >= 19 && x < 45) {
        if (y >= T0 && y < 13) h = Math.max(h, 1 + (13 - y) / end * rise);
        else if (y >= B0 && y < B0 + end) h = Math.max(h, 1 + (y - B0 + 1) / end * rise);
      }
      if (n >= 4 && side && end) {
        const inL = x >= L0 && x < 19, inR = x >= R0 && x < R0 + side, inT = y >= T0 && y < 13, inB = y >= B0 && y < B0 + end;
        if ((inL || inR) && (inT || inB)) { const dx = inL ? (19 - x) / side : (x - R0 + 1) / side, dy = inT ? (13 - y) / end : (y - B0 + 1) / end; h = 1 + Math.max(dx, dy) * rise; }
      }
      if (n >= 6 && h > 0) h += 1.6;                                   // roof overhang
      if (n >= 3) { for (const [px, py] of (n >= 5 ? [[1, 1], [59, 1], [1, 59], [59, 59]] : [[1, 1], [59, 59]])) if (x >= px && x < px + 3 && y >= py && y < py + 3) h = 11 + n * 0.3; }
      H[y * SRC + x] = h;
    }
    return H;
  }
  function startView(n) {
    const cv = $('stad-3d'); if (!cv) return;
    const img = new Image();
    img.onload = () => {
      const o = document.createElement('canvas'); o.width = o.height = SRC; const oc = o.getContext('2d'); oc.imageSmoothingEnabled = false; oc.drawImage(img, 0, 0, SRC, SRC);
      const px = oc.getImageData(0, 0, SRC, SRC).data, H = heightMap(n);
      const cx = cv.getContext('2d'); cx.imageSmoothingEnabled = false;
      const S = 2.35, bs = Math.ceil(S * 1.5);
      const cells = []; for (let y = 0; y < SRC; y++) for (let x = 0; x < SRC; x++) { const i = y * SRC + x; cells.push({ dx: x + .5 - 32, dy: y + .5 - 32, h: H[i], c: [px[i * 4], px[i * 4 + 1], px[i * 4 + 2]] }); }
      vw = { yaw: .5, tilt: .72, vyaw: 0, drag: null, idle: 0 };
      const V = vw;
      cv.onpointerdown = (e) => { e.preventDefault(); try { cv.setPointerCapture(e.pointerId); } catch (_) {} V.drag = { x: e.clientX, y: e.clientY }; V.vyaw = 0; };
      cv.onpointermove = (e) => { if (!V.drag) return; const dx = e.clientX - V.drag.x, dy = e.clientY - V.drag.y; V.drag = { x: e.clientX, y: e.clientY }; V.yaw += dx * 0.012; V.vyaw = dx * 0.012; V.tilt = Math.max(.45, Math.min(.95, V.tilt + dy * 0.004)); V.idle = 0; };
      cv.onpointerup = cv.onpointercancel = () => { V.drag = null; };
      let last = performance.now();
      (function frame(t) {
        if (vw !== V || $('stad-3d') !== cv) return;
        const dt = Math.min(.05, (t - last) / 1000); last = t;
        if (!V.drag) { V.idle += dt; V.yaw += V.vyaw; V.vyaw *= .93; if (V.idle > 1.5) V.yaw += dt * .35; }
        const sc = document.getElementById('screen-stad'); if (sc && sc.classList.contains('active')) draw(V);
        requestAnimationFrame(frame);
      })(last);
      function draw(V) {
        const cs = Math.cos(V.yaw), sn = Math.sin(V.yaw), K = S * (0.25 + 0.95 * (1 - V.tilt));
        cx.fillStyle = '#0b0f1c'; cx.fillRect(0, 0, VIEW, VIEW);
        const pts = cells.map(c => { const rx = cs * c.dx - sn * c.dy, ry = sn * c.dx + cs * c.dy; return { x: VIEW / 2 + rx * S, y: VIEW / 2 + 6 + ry * S * V.tilt, h: c.h, c: c.c, d: ry }; });
        pts.sort((a, b) => a.d - b.d || a.h - b.h);
        const bh = Math.ceil(bs * V.tilt) + 1;
        for (const p of pts) {
          const sx = Math.round(p.x - bs / 2), top = Math.round(p.y - p.h * K - bh / 2);
          if (p.h > 0) { const wall = Math.round(p.h * K); cx.fillStyle = 'rgb(' + (p.c[0] * .55 | 0) + ',' + (p.c[1] * .55 | 0) + ',' + (p.c[2] * .6 | 0) + ')'; cx.fillRect(sx, top + bh, bs, wall); }
          cx.fillStyle = 'rgb(' + p.c[0] + ',' + p.c[1] + ',' + p.c[2] + ')'; cx.fillRect(sx, top, bs, bh);
        }
      }
    };
    img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(stadSVG(n, SRC));
  }

  /* ---------- screen ---------- */
  const sc = document.createElement('div'); sc.id = 'screen-stad'; sc.className = 'screen store-screen'; sc.innerHTML = '<div id="stad-body"></div>';
  document.getElementById('game-container').appendChild(sc);
  const backTxt = () => L('رجوع', 'Back', 'Retour', 'Volver', 'Voltar', 'Zurück', 'Geri');
  function bonusLines(n) {
    if (!n) return L('لا مكافآت بعد — طوّر الملعب!', 'No bonuses yet — upgrade the stadium!', 'Pas encore de bonus — améliorez le stade !', 'Aún sin bonos: ¡mejora el estadio!', 'Ainda sem bónus — melhore o estádio!', 'Noch keine Boni — baue das Stadion aus!', 'Henüz bonus yok — stadyumu geliştir!');
    return L(`+${tokPct(n)}% توكن عند الفوز`, `+${tokPct(n)}% tokens on a win`, `+${tokPct(n)} % de jetons en cas de victoire`, `+${tokPct(n)}% de fichas al ganar`, `+${tokPct(n)}% de fichas ao vencer`, `+${tokPct(n)} % Tokens bei einem Sieg`, `Galibiyette +%${tokPct(n)} jeton`) + '<br>' +
      L(`+${xpBon(n)} نقطة XP عند الفوز`, `+${xpBon(n)} XP on a win`, `+${xpBon(n)} XP en cas de victoire`, `+${xpBon(n)} XP al ganar`, `+${xpBon(n)} XP ao vencer`, `+${xpBon(n)} XP bei einem Sieg`, `Galibiyette +${xpBon(n)} XP`);
  }
  function render() {
    const n = lvl(), b = $('stad-body'); if (!b) return;
    const head = `<div class="st-head"><div class="st-title">🏟️ ${L('الملعب', 'Stadium', 'Stade', 'Estadio', 'Estádio', 'Stadion', 'Stadyum')}</div></div><div class="st-sub"><span>🪙 <b>${fmt(state.tokens)}</b></span></div>`;
    let h = head + `<div style="background:#111;border:2px solid var(--accent-color);padding:10px;text-align:center;margin-bottom:10px"><div id="stad-wrap" style="display:flex;justify-content:center;position:relative"><div id="stad-box" style="position:relative;display:flex;justify-content:center"><canvas id="stad-3d" width="176" height="176" style="width:min(88vw,352px);height:min(88vw,352px);image-rendering:pixelated;touch-action:none;cursor:grab;background:#0b0f1c"></canvas><button id="stad-zoom" type="button" class="godot-btn" style="position:absolute;top:6px;right:6px;width:auto!important;min-width:44px;height:40px;padding:0 10px!important;font-size:20px!important;z-index:2">⤢</button></div></div><div style="font-size:11px;color:#8da2c8;margin-top:4px">✋ ${L('اسحب لتدوير الملعب وتغيير زاوية الرؤية', 'Drag to rotate the stadium and change the view', 'Glisse pour faire pivoter le stade et changer la vue', 'Arrastra para girar el estadio y cambiar la vista', 'Arraste para girar o estádio e mudar a vista', 'Ziehen, um das Stadion zu drehen und die Ansicht zu ändern', 'Stadyumu döndürmek ve görünümü değiştirmek için sürükle')}</div>` +
      `<div style="font-size:18px;font-weight:bold;margin-top:8px;color:var(--accent-color)">${nm(n)}</div><div style="font-size:13px;color:#aaa">${L('المستوى', 'Level', 'Niveau', 'Nivel', 'Nível', 'Stufe', 'Seviye')} ${n} / ${MAXL}</div>` +
      `<div style="font-size:14px;margin-top:6px;color:#9fe39f">${bonusLines(n)}</div></div>`;
    if (n < MAXL) {
      const k = n + 1, ok = true;
      h += `<div style="background:#111;padding:10px;margin-bottom:10px;display:flex;gap:10px;align-items:center"><div style="flex:0 0 96px;${ok ? '' : 'opacity:.55'}">${stadSVG(k, 96)}</div><div style="flex:1;text-align:start;font-size:13px">` +
        `<b>${L('التالي', 'Next', 'Suivant', 'Siguiente', 'Seguinte', 'Nächste Stufe', 'Sonraki')}: ${nm(k)}</b><br><span style="color:#9fe39f">${bonusLines(k).replace('<br>', ' • ')}</span><br>` +
        `${L('التكلفة', 'Cost', 'Coût', 'Coste', 'Custo', 'Kosten', 'Maliyet')}: 🪙 ${fmt(cost(k))}` +
        (ok ? '' : `<br><span style="color:#ff9a9a">🔒 ${L(`يتطلب الصعود إلى الدرجة ${needTier(k)}`, `Requires reaching Tier ${needTier(k)}`, `Nécessite d'atteindre le niveau ${needTier(k)}`, `Requiere llegar a la División ${needTier(k)}`, `Requer chegar à divisão ${needTier(k)}`, `Erfordert den Aufstieg in Liga ${needTier(k)}`, `${needTier(k)}. lige ulaşmayı gerektirir`)}</span>`) + `</div></div>` +
        `<button class="godot-btn" style="width:100%;margin-bottom:10px;${ok ? '' : 'opacity:.6'}" onclick="stadUpgrade()">⬆️ ${L('تطوير الملعب', 'Upgrade stadium', 'Améliorer le stade', 'Mejorar estadio', 'Melhorar estádio', 'Stadion ausbauen', 'Stadyumu geliştir')}</button>`;
    } else h += `<div style="background:#111;padding:12px;margin-bottom:10px;text-align:center;color:#f6d86b;font-weight:bold">★ ${L('وصلت لأقصى مستوى!', 'Maximum level reached!', 'Niveau maximum atteint !', '¡Nivel máximo alcanzado!', 'Nível máximo atingido!', 'Höchste Stufe erreicht!', 'Maksimum seviyeye ulaştın!')} ★</div>`;
    h += `<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-bottom:12px">` +
      Array.from({ length: MAXL }, (_, i) => i + 1).map(k => `<div style="background:#111;padding:4px;text-align:center;font-size:10px;border:1px solid ${k <= n ? 'var(--accent-color)' : '#333'};${k > n ? 'opacity:.55' : ''}">${stadSVG(k, 56)}<div>${k <= n ? '✔' : '🪙 ' + (cost(k) >= 1000 ? (cost(k) / 1000) + 'K' : cost(k))}</div></div>`).join('') + `</div>`;
    h += `<div class="back-bar"><button class="godot-btn" onclick="showScreen('screen-career')">${backTxt()}</button></div>`;
    b.innerHTML = h; startView(n);
    { const z = $('stad-zoom'), box = $('stad-box'), cv = $('stad-3d'); if (z) z.onclick = () => {
        const on = !box.__full; box.__full = on;
        if (on) { box.style.cssText = 'position:fixed;inset:0;z-index:99999;background:#0b0f1c;display:flex;align-items:center;justify-content:center'; cv.style.width = cv.style.height = 'min(100vw,100vh)'; z.textContent = '✕  ' + L('إغلاق', 'Close', 'Fermer', 'Cerrar', 'Fechar', 'Schließen', 'Kapat'); z.style.position = 'fixed'; z.style.top = 'calc(env(safe-area-inset-top,0px) + 56px)'; z.style.right = '12px'; z.style.height = '48px'; z.style.fontSize = '18px'; z.style.zIndex = '100000'; }
        else { box.style.cssText = 'position:relative;display:flex;justify-content:center'; cv.style.width = cv.style.height = 'min(88vw,352px)'; z.textContent = '⤢'; z.style.position = 'absolute'; z.style.top = '6px'; z.style.right = '6px'; z.style.height = '40px'; z.style.fontSize = '20px'; }
      }; }
  }
  window.stadOpen = function () { render(); showScreen('screen-stad'); window.scrollTo(0, 0); };
  window.stadUpgrade = function () {
    const n = lvl(), k = n + 1; if (n >= MAXL) return;
    const c = cost(k);
    if (state.tokens < c) return ffmShort('tok', L('توكن غير كافٍ', 'Not enough tokens', 'Jetons insuffisants', 'Fichas insuficientes', 'Fichas insuficientes', 'Nicht genug Tokens', 'Yetersiz jeton'), L(`تحتاج 🪙 ${fmt(c)} لتطوير الملعب.`, `You need 🪙 ${fmt(c)} to upgrade the stadium.`, `Il faut 🪙 ${fmt(c)} pour améliorer le stade.`, `Necesitas 🪙 ${fmt(c)} para mejorar el estadio.`, `Precisa de 🪙 ${fmt(c)} para melhorar o estádio.`, `Du brauchst 🪙 ${fmt(c)}, um das Stadion auszubauen.`, `Stadyumu geliştirmek için 🪙 ${fmt(c)} gerekiyor.`));
    ffmConfirm(L(`تطوير الملعب إلى «${nm(k)}» مقابل ${fmt(c)} توكن؟`, `Upgrade the stadium to "${nm(k)}" for ${fmt(c)} tokens?`, `Améliorer le stade en « ${nm(k)} » pour ${fmt(c)} jetons ?`, `¿Mejorar el estadio a «${nm(k)}» por ${fmt(c)} fichas?`, `Melhorar o estádio para «${nm(k)}» por ${fmt(c)} fichas?`, `Stadion zu „${nm(k)}“ ausbauen für ${fmt(c)} Tokens?`, `Stadyumu «${nm(k)}» seviyesine ${fmt(c)} jetonla geliştir?`), function () {
      if (state.tokens < c) return;
      state.tokens -= c; st().lvl = k; try { updateTokenDisplay(); } catch (e) {} try { saveGame(); } catch (e) {}
      if (window.FFMSfx) FFMSfx.play('upgrade');
      render(); ffmDialog({ title: '🏟️ ' + nm(k), body: '<div style="display:flex;justify-content:center;margin-bottom:8px">' + stadSVG(k, 140) + '</div>' + bonusLines(k), buttons: [{ label: 'OK' }] });
    });
  };

  /* ---------- match bonus ---------- */
  const _sm = window.startMatchSimulation;
  window.startMatchSimulation = function () {
    _sm.apply(this, arguments);
    try {
      const n = lvl(), pop = $('result-popup'); if (!n || !pop || pop.style.display !== 'flex' || matchContext.type === 'friendly') return;
      const m = String($('popup-score').innerText).match(/(\d+)\D+(\d+)/); if (!m || +m[1] <= +m[2]) return;
      const base = parseInt($('popup-tokens-earned').innerText) || 0, extra = Math.round(base * tokPct(n) / 100);
      state.tokens += extra; $('popup-tokens-earned').innerText = base + extra; try { updateTokenDisplay(); } catch (e) {}
      const p = FFMEng.eng().pass; if (p) p.xp = Math.min(3000, (p.xp || 0) + xpBon(n));
      const d = $('popup-teams-details'); if (d) d.innerText += ' • 🏟️ ' + L(`الملعب: +${extra} توكن، +${xpBon(n)} XP`, `Stadium: +${extra} tokens, +${xpBon(n)} XP`, `Stade : +${extra} jetons, +${xpBon(n)} XP`, `Estadio: +${extra} fichas, +${xpBon(n)} XP`, `Estádio: +${extra} fichas, +${xpBon(n)} XP`, `Stadion: +${extra} Tokens, +${xpBon(n)} XP`, `Stadyum: +${extra} jeton, +${xpBon(n)} XP`);
      saveGame();
    } catch (e) { console.error(e); }
  };

  /* ---------- career-screen buttons (translated) ---------- */
  function labels() {
    const set = (id, t) => { const e = $(id); if (e) e.textContent = t; };
    set('cr-cup', '🏆 ' + L('الكأس', 'Cups', 'Coupes', 'Copas', 'Taças', 'Pokale', 'Kupalar'));
    set('cr-goals', '🎯 ' + L('الأهداف', 'Goals', 'Objectifs', 'Objetivos', 'Objetivos', 'Ziele', 'Hedefler'));
    set('cr-tact', '⚙️ ' + L('التكتيك', 'Tactics', 'Tactique', 'Táctica', 'Tática', 'Taktik', 'Taktik'));
    set('cr-stad', '🏟️ ' + L('تطوير الملعب', 'Stadium upgrade', 'Améliorer le stade', 'Mejorar estadio', 'Melhorar estádio', 'Stadion-Ausbau', 'Stadyum geliştirme') + ' (' + lvl() + '/' + MAXL + ')');
  }
  const _al = window.applyLanguage;
  window.applyLanguage = function () { _al.apply(this, arguments); labels(); };
  const _ec = window.enterCareerMode;
  window.enterCareerMode = function () { _ec.apply(this, arguments); labels(); };
  window.FFMStad = { svg: stadSVG, level: lvl, cost, names: nm };
  labels();
})();
