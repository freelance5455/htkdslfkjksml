/* =====================================================
   NetEarn Pro
   Support Center
   FINAL CLEAN support.js

   PART 1 / 3

   Firebase Auth + Firestore
   Support Ticket
   Ticket Creation
   Ticket Loading
   Ticket List Rendering
   Ticket Details
===================================================== */

import { auth, db } from "./firebase.js";

import {
    onAuthStateChanged,
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";

import {
    collection,
    addDoc,
    query,
    where,
    getDocs,
    doc,
    updateDoc,
    serverTimestamp,
    arrayUnion,
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";


// =====================================================
// CONFIG
// =====================================================

const SUPPORT_COLLECTION = "supportTickets";


// =====================================================
// ELEMENTS
// =====================================================

const supportForm =
    document.getElementById("supportForm");

const supportCategory =
    document.getElementById("supportCategory");

const supportSubject =
    document.getElementById("supportSubject");

const supportMessage =
    document.getElementById("supportMessage");

const transactionId =
    document.getElementById("transactionId");

const submitSupportBtn =
    document.getElementById("submitSupportBtn");

const ticketList =
    document.getElementById("ticketList");

const messageCount =
    document.getElementById("messageCount");


// =====================================================
// MODAL ELEMENTS
// =====================================================

const ticketDetailsModal =
    document.getElementById("ticketDetailsModal");

const ticketDetailsOverlay =
    document.getElementById("ticketDetailsOverlay");

const closeTicketDetailsBtn =
    document.getElementById("closeTicketDetailsBtn");

const closeTicketDetailsBtn2 =
    document.getElementById("closeTicketDetailsBtn2");

const detailTicketId =
    document.getElementById("detailTicketId");

const detailTicketCategory =
    document.getElementById("detailTicketCategory");

const detailTicketStatus =
    document.getElementById("detailTicketStatus");

const detailTicketDate =
    document.getElementById("detailTicketDate");

const detailTransactionId =
    document.getElementById("detailTransactionId");

const detailTicketSubject =
    document.getElementById("detailTicketSubject");

const detailTicketMessage =
    document.getElementById("detailTicketMessage");

const adminReplySection =
    document.getElementById("adminReplySection");

const detailAdminReply =
    document.getElementById("detailAdminReply");

const waitingReplySection =
    document.getElementById("waitingReplySection");

const ticketDetailsTitle =
    document.getElementById("ticketDetailsTitle");


// =====================================================
// USER REPLY ELEMENTS
// =====================================================

const userReplySection =
    document.getElementById("userReplySection");

const userReplyMessage =
    document.getElementById("userReplyMessage");

const userReplyCount =
    document.getElementById("userReplyCount");

const sendUserReplyBtn =
    document.getElementById("sendUserReplyBtn");


// =====================================================
// OFFICIAL SUPPORT
// =====================================================

const whatsappSupport =
    document.getElementById("whatsappSupport");

const telegramSupport =
    document.getElementById("telegramSupport");


// =====================================================
// OFFICIAL SUPPORT URL
// =====================================================

const WHATSAPP_SUPPORT_URL = "#";

const TELEGRAM_SUPPORT_URL = "#";


// =====================================================
// APP STATE
// =====================================================

let currentUser = null;

let currentOpenTicket = null;


// =====================================================
// AUTH STATE
// =====================================================

onAuthStateChanged(
    auth,
    async (user) => {

        if (!user) {

            window.location.href =
                "login.html";

            return;
        }

        currentUser = user;

        console.log(
            "✅ Support User:",
            currentUser.uid
        );

        await loadMyTickets();

        // Open a specific Support Ticket only after Firebase Auth
        // has established currentUser. This prevents the URL ticket
        // flow from running too early during module initialization.
        if (getTicketIdFromUrl()) {

            await openTicketFromUrl();

        }

    }
);


// =====================================================
// OFFICIAL SUPPORT LINKS
// =====================================================

if (whatsappSupport) {

    whatsappSupport.href =
        WHATSAPP_SUPPORT_URL;

}

if (telegramSupport) {

    telegramSupport.href =
        TELEGRAM_SUPPORT_URL;

}


// =====================================================
// MESSAGE CHARACTER COUNT
// =====================================================

if (supportMessage && messageCount) {

    supportMessage.addEventListener(
        "input",
        () => {

            messageCount.textContent =
                supportMessage.value.length;

        }
    );

}


// =====================================================
// USER REPLY CHARACTER COUNT
// =====================================================

if (userReplyMessage && userReplyCount) {

    userReplyMessage.addEventListener(
        "input",
        () => {

            userReplyCount.textContent =
                userReplyMessage.value.length +
                " / 1000";

        }
    );

}


// =====================================================
// QUICK HELP
// =====================================================

document
    .querySelectorAll(".help-card")
    .forEach(card => {

        card.addEventListener(
            "click",
            () => {

                const category =
                    card.dataset.category;

                if (supportCategory) {

                    supportCategory.value =
                        category;

                }

                const requestSection =
                    document.getElementById(
                        "supportRequest"
                    );

                if (requestSection) {

                    requestSection.scrollIntoView({
                        behavior: "smooth",
                        block: "start"
                    });

                }

                setTimeout(
                    () => {

                        if (supportSubject) {

                            supportSubject.focus();

                        }

                    },
                    500
                );

            }
        );

    });


// =====================================================
// SUBMIT BUTTON STATE
// =====================================================

function setSubmitState(
    loading = false
) {

    if (!submitSupportBtn) {
        return;
    }

    submitSupportBtn.disabled =
        loading;

    if (loading) {

        submitSupportBtn.innerHTML = `

            <span>
                ⏳ Sending Request...
            </span>

            <span class="submit-arrow">
                …
            </span>

        `;

    }
    else {

        submitSupportBtn.innerHTML = `

            <span>
                📩 Submit Support Request
            </span>

            <span class="submit-arrow">
                →
            </span>

        `;

    }

}


// =====================================================
// CREATE TICKET ID
// =====================================================

function createTicketId() {

    const now =
        Date.now()
            .toString()
            .slice(-7);

    const random =
        Math.floor(
            100 +
            Math.random() * 900
        );

    return (
        "NEP-" +
        now +
        "-" +
        random
    );

}


// =====================================================
// SUBMIT SUPPORT REQUEST
// =====================================================

if (supportForm) {

    supportForm.addEventListener(
        "submit",
        async event => {

            event.preventDefault();

            if (!currentUser) {

                alert(
                    "❌ আপনার Account Login করা নেই।"
                );

                return;
            }


            // =========================================
            // VALUES
            // =========================================

            const category =
                supportCategory?.value
                    ?.trim() || "";

            const subject =
                supportSubject?.value
                    ?.trim() || "";

            const message =
                supportMessage?.value
                    ?.trim() || "";

            const transaction =
                transactionId?.value
                    ?.trim() || "";


            // =========================================
            // VALIDATION
            // =========================================

            if (!category) {

                alert(
                    "⚠️ Problem Category নির্বাচন করুন।"
                );

                supportCategory?.focus();

                return;
            }

            if (!subject) {

                alert(
                    "⚠️ সমস্যার Subject লিখুন।"
                );

                supportSubject?.focus();

                return;
            }

            if (subject.length < 3) {

                alert(
                    "⚠️ Subject একটু বিস্তারিত লিখুন।"
                );

                supportSubject?.focus();

                return;
            }

            if (subject.length > 100) {

                alert(
                    "⚠️ Subject সর্বোচ্চ 100 অক্ষর হতে পারবে।"
                );

                return;
            }

            if (!message) {

                alert(
                    "⚠️ আপনার সমস্যার বিস্তারিত লিখুন।"
                );

                supportMessage?.focus();

                return;
            }

            if (message.length < 10) {

                alert(
                    "⚠️ সমস্যাটি কমপক্ষে 10 অক্ষরে বিস্তারিত লিখুন।"
                );

                supportMessage?.focus();

                return;
            }

            if (message.length > 1000) {

                alert(
                    "⚠️ Problem Details সর্বোচ্চ 1000 অক্ষর হতে পারবে।"
                );

                return;
            }

            if (transaction.length > 100) {

                alert(
                    "⚠️ Transaction ID সর্বোচ্চ 100 অক্ষর হতে পারবে।"
                );

                return;
            }


            // =========================================
            // CONFIRM
            // =========================================

            const confirmed =
                await NetEarnDialog.confirm(
                    "📩 আপনার Support Request Submit করবেন?"
                );

            if (!confirmed) {
                return;
            }


            setSubmitState(true);


            try {

                // =====================================
                // CREATE TICKET ID
                // =====================================

                const ticketId =
                    createTicketId();


                // =====================================
                // INITIAL CONVERSATION
                // =====================================

                const initialConversation = [

                    {
                        sender: "user",

                        uid:
                            currentUser.uid,

                        email:
                            currentUser.email || "",

                        message:
                            message,

                        createdAt:
                            new Date()
                    }

                ];


                // =====================================
                // CREATE FIRESTORE TICKET
                // =====================================

                await addDoc(
                    collection(
                        db,
                        SUPPORT_COLLECTION
                    ),
                    {

                        ticketId:

                            ticketId,

                        uid:

                            currentUser.uid,

                        userUid:

                            currentUser.uid,

                        /*
                         * Compatibility field
                         */
                        userId:

                            currentUser.uid,

                        email:

                            currentUser.email || "",

                        category:

                            category,

                        subject:

                            subject,

                        message:

                            message,

                        transactionId:

                            transaction,

                        status:

                            "Open",

                        adminReply:

                            "",

                        userReply:

                            "",

                        conversation:

                            initialConversation,

                        lastReplyBy:

                            "user",

                        createdAt:

                            serverTimestamp(),

                        updatedAt:

                            serverTimestamp()

                    }
                );


                // =====================================
                // SUCCESS
                // =====================================

                alert(
                    "✅ Support Request সফলভাবে Submit হয়েছে.\n\n" +
                    "Ticket ID: " +
                    ticketId
                );


                // =====================================
                // RESET FORM
                // =====================================

                supportForm.reset();

                if (messageCount) {

                    messageCount.textContent =
                        "0";

                }

                setSubmitState(false);


                // =====================================
                // RELOAD TICKETS
                // =====================================

                await loadMyTickets();

            }
            catch (error) {

                console.error(
                    "❌ Support Request Error:",
                    error
                );

                console.error(
                    "Error Code:",
                    error.code
                );

                console.error(
                    "Error Message:",
                    error.message
                );

                alert(
                    "❌ Support Request Submit করা যায়নি.\n\n" +
                    "Error: " +
                    (
                        error.message ||
                        "Unknown error"
                    )
                );

                setSubmitState(false);

            }

        }
    );

}


// =====================================================
// LOAD MY TICKETS
// =====================================================

async function loadMyTickets() {

    if (
        !currentUser ||
        !ticketList
    ) {

        return;
    }


    ticketList.innerHTML = `

        <div class="empty-tickets">

            <div>
                ⏳
            </div>

            <strong>
                Loading Tickets...
            </strong>

            <p>
                আপনার Support Request
                খোঁজা হচ্ছে।
            </p>

        </div>

    `;


    try {

        // Keep the Phase 12 single-read optimization: fetch only the
        // current user's tickets, then sort locally by createdAt.
        const ticketsQuery =
            query(

                collection(
                    db,
                    SUPPORT_COLLECTION
                ),

                where(
                    "uid",
                    "==",
                    currentUser.uid
                )

            );


        const snapshot =
            await getDocs(
                ticketsQuery
            );


        if (snapshot.empty) {

            showEmptyTickets();

            return;
        }


        const tickets = [];


        snapshot.forEach(
            ticketDoc => {

                const data =
                    ticketDoc.data();

                data._docId =
                    ticketDoc.id;

                tickets.push(
                    data
                );

            }
        );


        tickets.sort(
            (a, b) => {

                return (
                    getTimestampMillis(
                        b.createdAt
                    ) -
                    getTimestampMillis(
                        a.createdAt
                    )
                );

            }
        );


        renderTicketList(
            tickets
        );

    }
    catch (error) {

        console.error(
            "❌ Ticket Load Error:",
            error
        );


        if (ticketList) {

            ticketList.innerHTML = `

                <div class="empty-tickets">

                    <div>
                        ⚠️
                    </div>

                    <strong>
                        Ticket Load করা যায়নি
                    </strong>

                    <p>
                        ${escapeHtml(
                            error.message ||
                            "Unknown error"
                        )}
                    </p>

                </div>

            `;

        }

    }

}


// =====================================================
// RENDER TICKET LIST
// =====================================================

function renderTicketList(
    tickets
) {

    if (!ticketList) {
        return;
    }


    ticketList.innerHTML = "";


    tickets.forEach(
        ticket => {

            renderTicket(
                ticket
            );

        }
    );

}

// =====================================================
// EMPTY TICKETS
// =====================================================

function showEmptyTickets() {

    if (!ticketList) {
        return;
    }


    ticketList.innerHTML = `

        <div class="empty-tickets">

            <div>
                🎫
            </div>

            <strong>
                No Support Ticket
            </strong>

            <p>
                আপনার কোনো Support Request
                থাকলে এখানে দেখা যাবে।
            </p>

        </div>

    `;

}


// =====================================================
// RENDER SINGLE TICKET
// =====================================================

function renderTicket(
    data
) {

    if (!ticketList) {
        return;
    }


    const status =
        String(
            data.status ||
            "Open"
        );


    const statusClass =
        getStatusClass(
            status
        );


    const createdDate =
        formatDate(
            data.createdAt
        );


    const ticket =
        document.createElement(
            "div"
        );


    ticket.className =
        "ticket-card";


    ticket._ticketData =
        data;


    ticket.innerHTML = `

        <div class="ticket-top">

            <div>

                <div class="ticket-title">

                    ${escapeHtml(
                        data.subject ||
                        "Support Request"
                    )}

                </div>

                <div class="ticket-category">

                    ${escapeHtml(
                        data.category ||
                        "Other"
                    )}

                    •

                    ${escapeHtml(
                        data.ticketId ||
                        "N/A"
                    )}

                </div>

            </div>


            <span
                class="ticket-status ${statusClass}"
            >

                ${escapeHtml(
                    status
                )}

            </span>

        </div>


        <div
            style="
                margin-top:10px;
                color:#59677b;
                font-size:11px;
                line-height:1.6;
            "
        >

            ${escapeHtml(
                data.message ||
                ""
            )}

        </div>


        ${
            data.adminReply
            ?
            `

                <div
                    style="
                        margin-top:11px;
                        padding:10px;
                        border-radius:11px;
                        background:#edfdf5;
                        color:#087b4f;
                        font-size:11px;
                        line-height:1.6;
                    "
                >

                    <strong>
                        👨‍💼 Admin Reply
                    </strong>

                    <div
                        style="
                            margin-top:4px;
                        "
                    >

                        ${escapeHtml(
                            data.adminReply
                        )}

                    </div>

                </div>

            `
            :
            ""
        }


        <div
            style="
                margin-top:9px;
                color:#98a3b2;
                font-size:9px;
            "
        >

            ${createdDate}

        </div>


        <div
            style="
                margin-top:9px;
                color:#1769ff;
                font-size:10px;
                font-weight:700;
            "
        >

            👆 Tap to view ticket details

        </div>

    `;


    ticket.addEventListener(
        "click",
        () => {

            openTicketDetails(
                ticket._ticketData
            );

        }
    );


    ticketList.appendChild(
        ticket
    );

}


// =====================================================
// OPEN TICKET DETAILS
// =====================================================

function openTicketDetails(
    data
) {

    if (!ticketDetailsModal) {
        return;
    }


    currentOpenTicket =
        data;


    if (detailTicketId) {

        detailTicketId.textContent =
            data.ticketId ||
            "N/A";

    }


    if (detailTicketCategory) {

        detailTicketCategory.textContent =
            data.category ||
            "Other";

    }


    if (detailTicketStatus) {

        const status =
            String(
                data.status ||
                "Open"
            );


        detailTicketStatus.textContent =
            status;


        detailTicketStatus.className =
            "detail-status " +
            getStatusClass(
                status
            );

    }


    if (detailTicketDate) {

        detailTicketDate.textContent =
            formatDate(
                data.createdAt
            );

    }


    if (detailTransactionId) {

        detailTransactionId.textContent =
            data.transactionId ||
            "Not Provided";

    }


    if (detailTicketSubject) {

        detailTicketSubject.textContent =
            data.subject ||
            "Support Request";

    }


    if (detailTicketMessage) {

        detailTicketMessage.textContent =
            data.message ||
            "";

    }


    if (ticketDetailsTitle) {

        ticketDetailsTitle.textContent =
            data.subject ||
            "Ticket Details";

    }


    const adminReply =
        String(
            data.adminReply ||
            ""
        ).trim();


    if (
        adminReply &&
        adminReplySection
    ) {

        adminReplySection.classList.remove(
            "hidden"
        );


        if (detailAdminReply) {

            detailAdminReply.textContent =
                adminReply;

        }

    }
    else {

        adminReplySection?.classList.add(
            "hidden"
        );

        if (detailAdminReply) {

            detailAdminReply.textContent =
                "";

        }

    }


    if (
        !adminReply &&
        waitingReplySection
    ) {

        waitingReplySection.classList.remove(
            "hidden"
        );

    }
    else {

        waitingReplySection?.classList.add(
            "hidden"
        );

    }


    createUserReplyInterface(
        data
    );


    ticketDetailsModal.classList.remove(
        "hidden"
    );


    ticketDetailsModal.setAttribute(
        "aria-hidden",
        "false"
    );


    document.body.style.overflow =
        "hidden";

}

// =====================================================
// NetEarn Pro
// Support Center
// FINAL CLEAN support.js
//
// PART 2 / 3
//
// Conversation History
// Dynamic User Reply
// Send User Reply
// Ticket Close Handling
// Modal Close
// =====================================================


// =====================================================
// CREATE USER REPLY INTERFACE
// =====================================================

function createUserReplyInterface(
    data
) {

    if (!ticketDetailsModal) {
        return;
    }


    const box =
        ticketDetailsModal.querySelector(
            ".ticket-details-box"
        );


    if (!box) {
        return;
    }


    // =================================================
    // REMOVE OLD DYNAMIC UI
    // =================================================

    const oldReply =
        box.querySelector(
            ".dynamic-user-reply-system"
        );


    if (oldReply) {

        oldReply.remove();

    }


    const oldConversation =
        box.querySelector(
            ".dynamic-conversation-system"
        );


    if (oldConversation) {

        oldConversation.remove();

    }


    // =================================================
    // CONVERSATION DATA
    // =================================================

    const conversation =
        Array.isArray(
            data.conversation
        )
        ?
        data.conversation
        :
        [];


    // =================================================
    // CONVERSATION HISTORY
    // =================================================

    if (conversation.length > 0) {

        const conversationSection =
            document.createElement(
                "div"
            );


        conversationSection.className =
            "dynamic-conversation-system conversation-list";


        conversation.forEach(
            item => {

                const message =
                    document.createElement(
                        "div"
                    );


                const sender =
                    item.sender === "admin"
                    ?
                    "admin"
                    :
                    "user";


                message.className =
                    "conversation-message " +
                    sender;


                const label =
                    sender === "admin"
                    ?
                    "👨‍💼 Admin"
                    :
                    "👤 You";


                message.innerHTML =

                    '<span class="conversation-message-label">' +

                    label +

                    '</span>' +

                    '<div class="conversation-message-text">' +

                    escapeHtml(
                        item.message ||
                        ""
                    ) +

                    '</div>' +

                    '<span class="conversation-message-date">' +

                    formatDate(
                        item.createdAt
                    ) +

                    '</span>';


                conversationSection.appendChild(
                    message
                );

            }
        );


        const footer =
            box.querySelector(
                ".ticket-details-footer"
            );


        if (footer) {

            box.insertBefore(
                conversationSection,
                footer
            );

        }
        else {

            box.appendChild(
                conversationSection
            );

        }

    }


    // =================================================
    // CHECK TICKET STATUS
    // =================================================

    const status =
        String(
            data.status ||
            "Open"
        )
        .toLowerCase()
        .trim();


    const isClosed =
        status === "closed" ||
        status === "resolved";


    if (isClosed) {

        return;

    }


    // =================================================
    // USER REPLY BOX
    // =================================================

    const replySection =
        document.createElement(
            "div"
        );


    replySection.className =
        "dynamic-user-reply-system user-reply-section";


    replySection.innerHTML = `

        <span
            class="detail-section-label"
        >

            💬 Reply to Support

        </span>


        <textarea
            id="dynamicUserReplyText"
            class="user-reply-textarea"
            maxlength="1000"
            rows="4"
            placeholder="Admin-কে আপনার অতিরিক্ত তথ্য বা উত্তর লিখুন..."
        ></textarea>


        <div
            class="user-reply-bottom"
        >

            <span
                id="dynamicUserReplyCount"
            >

                0 / 1000

            </span>


            <button
                type="button"
                id="dynamicSendUserReplyBtn"
                class="send-user-reply-btn"
            >

                📩 Send Reply

            </button>

        </div>

    `;


    const footer =
        box.querySelector(
            ".ticket-details-footer"
        );


    if (footer) {

        box.insertBefore(
            replySection,
            footer
        );

    }
    else {

        box.appendChild(
            replySection
        );

    }


    // =================================================
    // REPLY ELEMENTS
    // =================================================

    const replyTextarea =
        replySection.querySelector(
            "#dynamicUserReplyText"
        );


    const replyCount =
        replySection.querySelector(
            "#dynamicUserReplyCount"
        );


    const sendReplyBtn =
        replySection.querySelector(
            "#dynamicSendUserReplyBtn"
        );


    // =================================================
    // CHARACTER COUNT
    // =================================================

    if (
        replyTextarea &&
        replyCount
    ) {

        replyTextarea.addEventListener(
            "input",
            () => {

                replyCount.textContent =
                    replyTextarea.value.length +
                    " / 1000";

            }
        );

    }


    // =================================================
    // SEND REPLY BUTTON
    // =================================================

    if (sendReplyBtn) {

        sendReplyBtn.addEventListener(
            "click",
            async () => {

                await sendUserReply(
                    data,
                    replyTextarea,
                    sendReplyBtn
                );

            }
        );

    }

}


// =====================================================
// SEND USER REPLY
// =====================================================

async function sendUserReply(
    ticketData,
    textarea,
    button
) {

    // =================================================
    // AUTH CHECK
    // =================================================

    if (!currentUser) {

        alert(
            "❌ আপনার Account Login করা নেই।"
        );

        return;
    }


    // =================================================
    // TICKET CHECK
    // =================================================

    if (!ticketData) {

        alert(
            "❌ Ticket পাওয়া যায়নি।"
        );

        return;
    }


    // =================================================
    // DOCUMENT ID CHECK
    // =================================================

    if (!ticketData._docId) {

        alert(
            "❌ Ticket Document ID পাওয়া যায়নি।"
        );


        console.error(
            "Missing Ticket Document ID:",
            ticketData
        );


        return;
    }


    // =================================================
    // STATUS CHECK
    // =================================================

    const status =
        String(
            ticketData.status ||
            "Open"
        )
        .toLowerCase()
        .trim();


    if (
        status === "closed" ||
        status === "resolved"
    ) {

        alert(
            "🔒 এই Support Ticket বন্ধ করা হয়েছে।"
        );

        return;
    }


    // =================================================
    // GET MESSAGE
    // =================================================

    const message =
        textarea
            ?
            textarea.value.trim()
            :
            "";


    // =================================================
    // VALIDATION
    // =================================================

    if (!message) {

        alert(
            "⚠️ আপনার Reply লিখুন।"
        );

        textarea?.focus();

        return;
    }


    if (message.length < 3) {

        alert(
            "⚠️ Reply কমপক্ষে 3 অক্ষরের হতে হবে।"
        );

        textarea?.focus();

        return;
    }


    if (message.length > 1000) {

        alert(
            "⚠️ Reply সর্বোচ্চ 1000 অক্ষর হতে পারবে।"
        );

        return;
    }


    // =================================================
    // CONFIRM
    // =================================================

    const confirmed =
        await NetEarnDialog.confirm(
            "📩 এই Reply টি Admin-এর কাছে পাঠাবেন?"
        );


    if (!confirmed) {

        return;

    }


    // =================================================
    // BUTTON LOADING
    // =================================================

    const originalText =
        button
            ?
            button.innerHTML
            :
            "";


    if (button) {

        button.disabled =
            true;

        button.innerHTML =
            "⏳ Sending...";

    }


    try {

        // =============================================
        // TICKET REFERENCE
        // =============================================

        const ticketRef =
            doc(
                db,
                SUPPORT_COLLECTION,
                ticketData._docId
            );


        // =============================================
        // CONVERSATION MESSAGE
        // =============================================

        const conversationMessage = {

            sender:
                "user",

            uid:
                currentUser.uid,

            email:
                currentUser.email || "",

            message:
                message,

            createdAt:
                new Date()

        };


        // =============================================
        // FIRESTORE UPDATE
        // =============================================

        await updateDoc(
            ticketRef,
            {

                conversation:
                    arrayUnion(
                        conversationMessage
                    ),


                // Compatibility field
                userReply:
                    message,


                lastReplyBy:
                    "user",


                lastReplyAt:
                    serverTimestamp(),


                /*
                 * User আবার reply করলে
                 * ticket Open হবে।
                 */
                status:
                    "Open",


                updatedAt:
                    serverTimestamp()

            }
        );


        // =============================================
        // SUCCESS
        // =============================================

        alert(
            "✅ আপনার Reply সফলভাবে পাঠানো হয়েছে।"
        );


        // =============================================
        // CLOSE MODAL
        // =============================================

        closeTicketDetails();


        // =============================================
        // RELOAD TICKETS
        // =============================================

        await loadMyTickets();

    }
    catch (error) {

        console.error(
            "❌ User Reply Error:",
            error
        );


        console.error(
            "Error Code:",
            error.code
        );


        console.error(
            "Error Message:",
            error.message
        );


        alert(
            "❌ Reply পাঠানো যায়নি।\n\n" +
            "Error: " +
            (
                error.message ||
                "Unknown error"
            )
        );


        // =============================================
        // RESTORE BUTTON
        // =============================================

        if (button) {

            button.disabled =
                false;

            button.innerHTML =
                originalText;

        }

    }

}


// =====================================================
// CLOSE TICKET DETAILS MODAL
// =====================================================

function closeTicketDetails() {

    if (!ticketDetailsModal) {

        return;

    }


    ticketDetailsModal.classList.add(
        "hidden"
    );


    ticketDetailsModal.setAttribute(
        "aria-hidden",
        "true"
    );


    document.body.style.overflow =
        "";


    currentOpenTicket =
        null;


    // =================================================
    // REMOVE DYNAMIC CONVERSATION
    // =================================================

    const box =
        ticketDetailsModal.querySelector(
            ".ticket-details-box"
        );


    if (box) {

        const dynamicConversation =
            box.querySelector(
                ".dynamic-conversation-system"
            );


        if (dynamicConversation) {

            dynamicConversation.remove();

        }


        const dynamicReply =
            box.querySelector(
                ".dynamic-user-reply-system"
            );


        if (dynamicReply) {

            dynamicReply.remove();

        }

    }

}


// =====================================================
// CLOSE BUTTON — HEADER
// =====================================================

if (closeTicketDetailsBtn) {

    closeTicketDetailsBtn.addEventListener(
        "click",
        closeTicketDetails
    );

}


// =====================================================
// CLOSE BUTTON — FOOTER
// =====================================================

if (closeTicketDetailsBtn2) {

    closeTicketDetailsBtn2.addEventListener(
        "click",
        closeTicketDetails
    );

}


// =====================================================
// CLOSE MODAL — OVERLAY
// =====================================================

if (ticketDetailsOverlay) {

    ticketDetailsOverlay.addEventListener(
        "click",
        closeTicketDetails
    );

}


// =====================================================
// ESC KEY — CLOSE MODAL
// =====================================================

document.addEventListener(
    "keydown",
    event => {

        if (
            event.key === "Escape" &&
            ticketDetailsModal &&
            !ticketDetailsModal.classList.contains(
                "hidden"
            )
        ) {

            closeTicketDetails();

        }

    }
);

// =====================================================
// NetEarn Pro
// Support Center
// FINAL CLEAN support.js
//
// PART 3 / 3
//
// Utility Functions
// Status Class
// Timestamp Handling
// Date Formatting
// HTML Safety
// Official Support Links
// Notification → Support Ticket Redirect
// =====================================================


// =====================================================
// GET STATUS CLASS
// =====================================================

function getStatusClass(
    status
) {

    const normalized =
        String(
            status ||
            "Open"
        )
        .toLowerCase()
        .trim();


    if (
        normalized === "closed"
    ) {

        return "status-closed";

    }


    if (
        normalized === "resolved"
    ) {

        return "status-resolved";

    }


    if (
        normalized === "pending"
    ) {

        return "status-pending";

    }


    if (
        normalized === "rejected"
    ) {

        return "status-rejected";

    }


    if (
        normalized === "open"
    ) {

        return "status-open";

    }


    return "status-open";

}


// =====================================================
// GET TIMESTAMP MILLISECONDS
// =====================================================

function getTimestampMillis(
    timestamp
) {

    if (!timestamp) {

        return 0;

    }


    // Firebase Timestamp
    if (
        typeof timestamp.toMillis ===
        "function"
    ) {

        return timestamp.toMillis();

    }


    // JavaScript Date
    if (
        timestamp instanceof Date
    ) {

        return timestamp.getTime();

    }


    // Firestore Timestamp-like object
    if (
        typeof timestamp.seconds ===
        "number"
    ) {

        return (
            timestamp.seconds * 1000
        );

    }


    // Numeric timestamp
    if (
        typeof timestamp ===
        "number"
    ) {

        return timestamp;

    }


    // String date
    if (
        typeof timestamp ===
        "string"
    ) {

        const parsed =
            new Date(
                timestamp
            ).getTime();


        return isNaN(parsed)
            ?
            0
            :
            parsed;

    }


    return 0;

}


// =====================================================
// FORMAT DATE
// =====================================================

function formatDate(
    timestamp
) {

    const millis =
        getTimestampMillis(
            timestamp
        );


    if (!millis) {

        return "Date unavailable";

    }


    try {

        return new Date(
            millis
        ).toLocaleString(
            "en-BD",
            {
                year:
                    "numeric",

                month:
                    "short",

                day:
                    "numeric",

                hour:
                    "2-digit",

                minute:
                    "2-digit",

                hour12:
                    true
            }
        );

    }
    catch (error) {

        console.error(
            "Date Format Error:",
            error
        );


        return "";

    }

}


// =====================================================
// ESCAPE HTML
// =====================================================

function escapeHtml(
    value
) {

    return String(
        value ?? ""
    )
    .replace(
        /&/g,
        "&amp;"
    )
    .replace(
        /</g,
        "&lt;"
    )
    .replace(
        />/g,
        "&gt;"
    )
    .replace(
        /"/g,
        "&quot;"
    )
    .replace(
        /'/g,
        "&#039;"
    );

}


// =====================================================
// OFFICIAL SUPPORT LINKS
// =====================================================

if (whatsappSupport) {

    if (
        WHATSAPP_SUPPORT_URL &&
        WHATSAPP_SUPPORT_URL !== "#"
    ) {

        whatsappSupport.href =
            WHATSAPP_SUPPORT_URL;

    }
    else {

        whatsappSupport.href =
            "#";

    }

}


if (telegramSupport) {

    if (
        TELEGRAM_SUPPORT_URL &&
        TELEGRAM_SUPPORT_URL !== "#"
    ) {

        telegramSupport.href =
            TELEGRAM_SUPPORT_URL;

    }
    else {

        telegramSupport.href =
            "#";

    }

}


// =====================================================
// NOTIFICATION → SUPPORT TICKET
// =====================================================
//
// এই system-এর কাজ:
//
// Dashboard notification থেকে user যদি
// Support Reply notification-এ click করে,
// তাহলে:
//
// notifications.js
//        ↓
// support.html?ticketId=XXXXX
//        ↓
// support.js
//        ↓
// নির্দিষ্ট Ticket খুঁজবে
//        ↓
// Ticket Details সরাসরি খুলবে
//
// =====================================================


// =====================================================
// GET TICKET ID FROM URL
// =====================================================

function getTicketIdFromUrl() {

    try {

        const params =
            new URLSearchParams(
                window.location.search
            );


        return (
            params.get(
                "ticketId"
            ) ||
            params.get(
                "ticket"
            ) ||
            ""
        ).trim();

    }
    catch (error) {

        console.error(
            "URL Ticket ID Error:",
            error
        );


        return "";

    }

}


// =====================================================
// OPEN TICKET FROM URL
// =====================================================

async function openTicketFromUrl() {

    const ticketId =
        getTicketIdFromUrl();


    // -------------------------------------------------
    // No ticket ID
    // -------------------------------------------------

    if (!ticketId) {

        return;

    }


    // -------------------------------------------------
    // User not ready
    // -------------------------------------------------

    if (!currentUser) {

        return;

    }


    try {

        console.log(
            "🔎 Opening Support Ticket:",
            ticketId
        );


        // =================================================
        // FIND TICKET
        // =================================================

        const ticketQuery =
            query(

                collection(
                    db,
                    SUPPORT_COLLECTION
                ),

                where(
                    "uid",
                    "==",
                    currentUser.uid
                ),

                where(
                    "ticketId",
                    "==",
                    ticketId
                )

            );


        const snapshot =
            await getDocs(
                ticketQuery
            );


        // =================================================
        // TICKET NOT FOUND
        // =================================================

        if (
            snapshot.empty
        ) {

            console.warn(
                "Support Ticket not found:",
                ticketId
            );


            alert(
                "⚠️ এই Support Ticket পাওয়া যায়নি।"
            );


            return;

        }


        // =================================================
        // GET FIRST MATCH
        // =================================================

        const ticketDoc =
            snapshot.docs[0];


        const data =
            ticketDoc.data();


        data._docId =
            ticketDoc.id;


        // =================================================
        // OPEN TICKET
        // =================================================

        openTicketDetails(
            data
        );


        // =================================================
        // REMOVE QUERY FROM ADDRESS BAR
        // =================================================

        try {

            window.history.replaceState(
                {},
                document.title,
                window.location.pathname
            );

        }
        catch (historyError) {

            console.warn(
                "History update failed:",
                historyError
            );

        }

    }
    catch (error) {

        console.error(
            "❌ Open Ticket From URL Error:",
            error
        );


        alert(
            "❌ Support Ticket খুলতে সমস্যা হয়েছে।"
        );

    }

}


// =====================================================
// AUTO OPEN NOTIFICATION TICKET
// =====================================================
//
// IMPORTANT:
//
// Part 1-এর auth listener-এর ভিতরে
// loadMyTickets() এর পরে
// openTicketFromUrl() call করা যাবে।
//
// তবে auth listener যদি Part 1-এ already
// openTicketFromUrl() call করে থাকে,
// এখানে দ্বিতীয়বার call করার প্রয়োজন নেই।
//
// এই safety check ব্যবহার করা হচ্ছে যাতে
// currentUser পাওয়া যাওয়ার পর system কাজ করে।
// =====================================================

// =====================================================
// SUPPORT PAGE READY LOG
// =====================================================

console.log(
    "✅ NetEarn Pro Support Center loaded successfully."
);


// =====================================================
// FINAL SAFETY CHECK
// =====================================================

window.addEventListener(
    "error",
    event => {

        console.error(
            "❌ Support Page Error:",
            event.error ||
            event.message
        );

    }
);