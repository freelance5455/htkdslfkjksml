/* UNKNOWN X V17 phase 2 — photo tile puzzle, linked gears, explorable 3D room (raycaster). Engine is pure/testable; UI via V17.ext */
(function(){"use strict";
const V=typeof module!=="undefined"&&module.exports?require("./v17.js"):window.V17;
const R4=[[1,0],[-1,0],[0,1],[0,-1]],sum0=a=>a.every(v=>v===0);
/* ---- Photo (tile) puzzle: scrambled by legal moves + parity check ---- */
const PH={easy:{n:3,m:30},normal:{n:3,m:120},hard:{n:4,m:200}};
const solvedT=n=>[...Array(n*n).keys()].map(i=>(i+1)%(n*n));
V.verifyPhoto=p=>{const n=p.n,t=p.tiles;if(t.length!==n*n||[...t].sort((a,b)=>a-b).some((v,i)=>v!==i)||t.every((v,i)=>v===solvedT(n)[i]))return false;
 let inv=0;const f=t.filter(v=>v);for(let i=0;i<f.length;i++)for(let j=i+1;j<f.length;j++)if(f[i]>f[j])inv++;
 const br=n-Math.floor(t.indexOf(0)/n);return n%2?inv%2===0:(br%2?inv%2===0:inv%2===1)};
V.genPhoto=(seed,lv)=>{const{n,m}=PH[lv];for(let a=0;a<20;a++){const r=V.rng(seed+a*31),t=solvedT(n);let b=n*n-1,last=-1;const path=[b];
 for(let i=0;i<m;i++){const o=R4.map(([dx,dy])=>[b%n+dx,Math.floor(b/n)+dy]).filter(([x,y])=>x>=0&&y>=0&&x<n&&y<n).map(([x,y])=>y*n+x).filter(q=>q!==last),q=o[Math.floor(r()*o.length)];[t[b],t[q]]=[t[q],t[b]];last=b;b=q;path.push(q)}
 const p={type:"photo",lv,seed,n,tiles:t,sol:path.slice(0,-1).reverse()};if(V.verifyPhoto(p))return p}throw new Error("photo generation failed")};
/* ---- Linked gears: click gear i => i+1, neighbour i+1 -1; BFS proves solvable ---- */
const GC={easy:{n:3,k:3,m:4},normal:{n:4,k:4,m:7},hard:{n:5,k:4,m:10}};
V.clickGears=(g,i,k)=>{g[i]=(g[i]+1)%k;if(i+1<g.length)g[i+1]=(g[i+1]+k-1)%k};
const bfs=(g,k)=>{const q=[[g.slice(),0,[]]],seen=new Set([g.join("")]);for(let h=0;h<q.length;h++){const[s,d,w]=q[h];if(sum0(s))return[d,w];for(let i=0;i<s.length;i++){const t=s.slice();V.clickGears(t,i,k);const y=t.join("");if(!seen.has(y)){seen.add(y);q.push([t,d+1,[...w,i]])}}}return[-1,[]]};
V.solveGears=(g,k)=>bfs(g,k)[0];V.pathGears=(g,k)=>bfs(g,k)[1];
V.verifyGears=p=>p.start.length===p.n&&p.start.every(v=>Number.isInteger(v)&&v>=0&&v<p.k)&&!sum0(p.start)&&p.par>0&&V.solveGears(p.start,p.k)===p.par;
V.genGears=(seed,lv)=>{const{n,k,m}=GC[lv];for(let a=0;a<30;a++){const r=V.rng(seed+a*17),g=Array(n).fill(0);
 for(let i=0;i<m;i++){const c=Math.floor(r()*n);g[c]=(g[c]+k-1)%k;if(c+1<n)g[c+1]=(g[c+1]+1)%k}
 if(sum0(g))continue;const p={type:"gears",lv,seed,n,k,start:g,par:V.solveGears(g,k)};if(V.verifyGears(p))return p}throw new Error("gears generation failed")};
/* ---- 3D room: grid map, seeded object placement, reachability proof, movement/interaction ---- */
const reach=(m,open)=>{const s=new Set(["1,1"]),q=[[1,1]];for(const[x,y]of q)for(const[a,b]of R4){const nx=x+a,ny=y+b,ch=m[ny]&&m[ny][nx];if(!s.has(nx+","+ny)&&(ch==="."||(open&&ch==="D"))){s.add(nx+","+ny);q.push([nx,ny])}}return s};
const adj=(s,x,y)=>R4.some(([a,b])=>s.has((x+a)+","+(y+b)));
const find=(m,ch)=>{for(let y=0;y<m.length;y++){const x=m[y].indexOf(ch);if(x>=0)return[x,y]}return null};
V.verifyRoom=p=>{const m=p.map;if(!V.verifyCipher({...p,type:"cipher"})||m[1][1]!==".")return false;const T=find(m,"T"),D=find(m,"D"),K=find(m,"K");if(!T||!D||!K)return false;const c=reach(m,false),o=reach(m,true);return adj(c,...T)&&adj(c,...D)&&!adj(c,...K)&&adj(o,...K)};
V.genRoom=(seed,lv)=>{for(let a=0;a<40;a++){const r=V.rng(seed+a*13),base=V.genCipher(seed+a,lv),m=Array.from({length:8},(_,y)=>Array.from({length:10},(_,x)=>y%7===0||x%9===0||y===4?"#":"."));
 m[4][2+Math.floor(r()*6)]="D";const T=()=>{let x,y;do{x=1+Math.floor(r()*8);y=1+Math.floor(r()*3)}while(x===1&&y===1);return[x,y]};
 const[tx,ty]=T();m[ty][tx]="T";m[5+Math.floor(r()*2)][1+Math.floor(r()*8)]="K";
 const p={...base,type:"room",lv,seed,map:m.map(w=>w.join("")),start:{x:1.5,y:1.5,a:.7}};if(V.verifyRoom(p))return p}throw new Error("room generation failed")};
V.roomMove=(c,k)=>{const m=c.map;if(k==="l")c.a-=.3;else if(k==="r")c.a+=.3;
 else if(k==="f"||k==="b"){const s=k==="f"?.25:-.25,dx=Math.cos(c.a)*s,dy=Math.sin(c.a)*s,nx=c.x+dx+Math.sign(dx)*.18,ny=c.y+dy+Math.sign(dy)*.18;if(m[c.y|0][nx|0]===".")c.x+=dx;if(m[ny|0][c.x|0]===".")c.y+=dy}
 else if(k==="u"){const ch=m[(c.y+Math.sin(c.a)*.9)|0][(c.x+Math.cos(c.a)*.9)|0];return ch==="."?"":ch}return null};
/* ---- registration (UI parts only run in the browser) ---- */
const msg=c=>c.msg?`<p class="v17-msg">${c.msg}</p>`:"";
const art=p=>{const r=V.rng(p.seed),hu=Math.floor(r()*360);let s=`<rect width="60" height="60" fill="hsl(${hu},45%,12%)"/><circle cx="${10+r()*40|0}" cy="${8+r()*10|0}" r="${5+r()*4|0}" fill="hsl(${(hu+40)%360},90%,60%)"/>`;
 for(let i=0;i<9;i++){const w=4+r()*6,h=14+r()*30,x=i*6.6-1;s+=`<rect x="${x}" y="${60-h}" width="${w}" height="${h}" fill="hsl(${(hu+200)%360},40%,${8+i%3*5}%)"/>`;for(let k=0;k<5;k++)s+=`<rect x="${x+1}" y="${60-h+2+k*5}" width="1.2" height="1.6" fill="#ffd36b" opacity="${r()<.5?.9:.2}"/>`}return s};
V.reg("photo","لغز الصور (إعادة ترتيب)",{gen:V.genPhoto,init:p=>({t:p.tiles.slice(),moves:0}),
 view:(c,h,x)=>{const p=c.p,n=p.n,u=60/n;return h+`<h2>أعد ترتيب الصورة (<span id="v17mv">${c.moves}</span> حركة)</h2><svg width="0" height="0" style="position:absolute"><defs><g id="v17art">${art(p)}</g></defs></svg><div class="v17-board" style="grid-template-columns:repeat(${n},1fr)">${c.t.map((v,i)=>v?`<button class="v17-tile" data-v17="tile:${i}" aria-label="قطعة ${v}"><svg viewBox="${((v-1)%n)*u} ${Math.floor((v-1)/n)*u} ${u} ${u}"><use href="#v17art"/></svg><i>${v}</i></button>`:`<span class="v17-tile v17-blank"></span>`).join("")}</div>${msg(c)}<div class="hero-actions">${x}</div>`},
 act:(a,i,_,c)=>{if(a!=="tile")return false;const n=c.p.n,b=c.t.indexOf(0),q=+i;if(Math.abs((b%n)-(q%n))+Math.abs(Math.floor(b/n)-Math.floor(q/n))!==1){V.api.sfx("bad");return true}
  [c.t[b],c.t[q]]=[c.t[q],c.t[b]];c.moves++;V.api.sfx("ok");if(c.t.every((v,k)=>v===solvedT(n)[k]))V.api.won();else V.api.refresh();return true}});
V.reg("gears","آلية التروس المتصلة",{gen:V.genGears,init:p=>({g:p.start.slice(),moves:0}),
 view:(c,h,x)=>`${h}<h2>أعد كل التروس إلى العلامة العليا (<span id="v17mv">${c.moves}</span> حركة · الأمثل ${c.p.par})</h2><p>كل ترس تضغطه يدور، والترس المجاور له يدور بالعكس.</p><div class="v17-gears">${c.g.map((v,i)=>`<button class="v17-gear" data-v17="gear:${i}" aria-label="ترس ${i+1}: ${v}"><span style="transform:rotate(${v*360/c.p.k}deg)">⚙<b>▲</b></span><small>${v}</small></button>`).join("")}</div>${msg(c)}<div class="hero-actions">${x}</div>`,
 act:(a,i,_,c)=>{if(a!=="gear")return false;V.clickGears(c.g,+i,c.p.k);c.moves++;V.api.sfx("ok");if(sum0(c.g))return V.api.won(),true;
  document.querySelectorAll(".v17-gear").forEach((b,j)=>{b.firstChild.style.transform=`rotate(${c.g[j]*360/c.p.k}deg)`;b.lastChild.textContent=c.g[j]});const mv=document.getElementById("v17mv");if(mv)mv.textContent=c.moves;return true}});
const COL={"#":[60,140,110],T:[60,200,230],D:[255,110,110],K:[255,211,107]};
function draw(c){const cv=document.getElementById("v17cv");if(!cv)return;const g=cv.getContext("2d"),W=cv.width,H=cv.height,m=c.map;g.fillStyle="#0b1512";g.fillRect(0,0,W,H/2);g.fillStyle="#13231d";g.fillRect(0,H/2,W,H/2);
 for(let x=0;x<W;x+=2){const a=c.a+(x/W-.5)*1.05,dx=Math.cos(a)+1e-9,dy=Math.sin(a)+1e-9,ddx=Math.abs(1/dx),ddy=Math.abs(1/dy);let mx=c.x|0,my=c.y|0,sx=dx<0?-1:1,sy=dy<0?-1:1,tx=(dx<0?c.x-mx:mx+1-c.x)*ddx,ty=(dy<0?c.y-my:my+1-c.y)*ddy,side=0,ch="#";
  for(let i=0;i<24;i++){if(tx<ty){tx+=ddx;mx+=sx;side=0}else{ty+=ddy;my+=sy;side=1}ch=m[my][mx];if(ch!==".")break}
  const d=Math.max(.15,(side?ty-ddy:tx-ddx)*Math.cos(a-c.a)),h=H/d*.8,sh=Math.max(.25,1-d/9)*(side?.75:1),k=COL[ch]||COL["#"];g.fillStyle=`rgb(${k[0]*sh|0},${k[1]*sh|0},${k[2]*sh|0})`;g.fillRect(x,(H-h)/2,2,h)}}
const dials=c=>`<div class="v17-dials">${c.d.map((v,i)=>`<div class="v17-dial"><button class="btn" data-v17="dial:${i}:1">▲</button><b>${v}</b><button class="btn" data-v17="dial:${i}:-1">▼</button></div>`).join("")}</div>`;
function go(c,k){const r=V.roomMove(c,k);if(r===null){draw(c);return}c.msg=r==="T"?"":r==="D"?"":r==="K"?"":"لا شيء للتفاعل هنا";
 if(r==="T")c.mode="clues";else if(r==="D")c.mode="lock";else if(r==="K"){c.mode="done";c.map[(c.y+Math.sin(c.a)*.9)|0][(c.x+Math.cos(c.a)*.9)|0]=".";return V.api.won()}V.api.refresh()}
V.reg("room","غرفة 3D مقفلة",{gen:V.genRoom,init:p=>({mode:"walk",map:p.map.map(s=>s.split("")),x:p.start.x,y:p.start.y,a:p.start.a}),after:c=>{if(c.mode==="walk")draw(c)},
 view:(c,h,x)=>c.mode==="done"?`${h}<h2>خرجت بالقطعة الأثرية</h2>${msg(c)}<div class="hero-actions">${x}</div>`:c.mode==="clues"?`${h}<h2>الطرفية: سجل الباب</h2>${c.p.clues.map(q=>`<div class="clue">• ${V.ctext(q)}</div>`).join("")}<div class="hero-actions"><button class="btn" data-v17="back">رجوع</button></div>`:c.mode==="lock"?`${h}<h2>قفل الباب</h2>${dials(c)}${msg(c)}<div class="hero-actions"><button class="btn" data-v17="try">فتح</button><button class="btn" data-v17="back">رجوع</button></div>`
  :`${h}<h2>استكشف الغرفة: ابحث عن الطرفية الزرقاء ثم الباب الأحمر</h2><canvas id="v17cv" width="240" height="135"></canvas><div class="v17-pad"><button data-v17="mv:l" aria-label="يسار">⟲</button><button data-v17="mv:f" aria-label="للأمام">▲</button><button data-v17="mv:r" aria-label="يمين">⟳</button><button data-v17="mv:b" aria-label="للخلف">▼</button><button data-v17="mv:u">تفاعل</button></div>${msg(c)}<div class="hero-actions">${x}</div>`,
 act:(a,k,_,c)=>{if(a==="mv"){go(c,k);return true}if(a==="back"){c.mode="walk";c.msg="";V.api.refresh();return true}
  if(a==="try"){if(V.same(c.d,c.p.code)){const D=find(c.map.map(w=>w.join("")),"D");c.map[D[1]][D[0]]=".";c.mode="walk";c.msg="انفتح الباب! ادخل وخذ القطعة الأثرية (الذهبية).";V.api.sfx("open")}else{c.msg="الرمز خاطئ";V.api.sfx("bad")}V.api.refresh();return true}return false}});
if(typeof document!=="undefined")document.addEventListener("keydown",e=>{const c=V.api&&V.api.cur();if(!c||c.p.type!=="room"||c.mode!=="walk"||!document.getElementById("v17cv"))return;const k={ArrowUp:"f",ArrowDown:"b",ArrowLeft:"l",ArrowRight:"r"," ":"u",Enter:"u"}[e.key];if(k){e.preventDefault();go(c,k)}});
})();
