// ===== GAMEPLAY: movement, camera, shooting, vehicle, targets, menu, main loop =====

let gameStarted = false;
let inVehicle = false;
let vehicleYaw = 0;
let vehicleSpeed = 0;
let verticalVel = 0;
let grounded = true;
let muzzleTimer = 0;
const bullets = []; // short-lived visual tracers; hits are resolved instantly via raycast

const clock = new THREE.Clock();
const raycaster = new THREE.Raycaster();

camera.position.set(0, 6, -10);
camera.lookAt(0, 1, 0);

const muzzleFlashMesh = new THREE.Mesh(
  new THREE.SphereGeometry(0.15, 6, 6),
  new THREE.MeshBasicMaterial({ color: 0xffdd66, transparent: true })
);
muzzleFlashMesh.visible = false;
scene.add(muzzleFlashMesh);

const tracerMat = new THREE.LineBasicMaterial({ color: 0xfff2b0, transparent: true });

function spawnTracer(origin, dir, dist) {
  const end = origin.clone().add(dir.clone().multiplyScalar(dist));
  const geo = new THREE.BufferGeometry().setFromPoints([origin, end]);
  const line = new THREE.Line(geo, tracerMat.clone());
  line.userData.life = 6;
  scene.add(line);
  bullets.push(line);
}

function updateMovementOnFoot(dt) {
  const moveVec = new THREE.Vector3(touchState.moveX, 0, -touchState.moveY);
  const moving = moveVec.length() > 0.05;

  if (moving) {
    moveVec.normalize();
    moveVec.applyAxisAngle(new THREE.Vector3(0, 1, 0), cameraYaw);
    playerBody.velocity.x = moveVec.x * 6;
    playerBody.velocity.z = moveVec.z * 6;
    player.rotation.y = Math.atan2(moveVec.x, moveVec.z);
  } else {
    playerBody.velocity.x *= 0.8;
    playerBody.velocity.z *= 0.8;
  }

  if (touchState.jumpQueued) {
    touchState.jumpQueued = false;
    if (grounded) { verticalVel = 8; grounded = false; playJump(); }
  }
  verticalVel -= 20 * dt;
  let jumpOffset = (player.userData.jumpOffset || 0) + verticalVel * dt;
  if (jumpOffset <= 0) { jumpOffset = 0; verticalVel = 0; grounded = true; }
  player.userData.jumpOffset = jumpOffset;
  playerBody.velocity.y = 0;

  player.position.x = playerBody.position.x;
  player.position.z = playerBody.position.z;
  const groundY = heightAt(player.position.x, player.position.z);
  player.position.y = groundY + jumpOffset;
  playerBody.position.y = groundY + 1;

  const speed = Math.hypot(playerBody.velocity.x, playerBody.velocity.z);
  if (speed > 0.3 && grounded) {
    player.userData.walkPhase += dt * 8;
    const swing = Math.sin(player.userData.walkPhase) * 0.6;
    player.userData.legL.rotation.x = swing;
    player.userData.legR.rotation.x = -swing;
    player.userData.armL.rotation.x = -swing;
    player.userData.armR.rotation.x = swing;
    if (Math.abs(swing) < 0.05 && !player.userData.stepPlayed) {
      playFootstep();
      player.userData.stepPlayed = true;
    } else if (Math.abs(swing) > 0.15) {
      player.userData.stepPlayed = false;
    }
  } else {
    player.userData.legL.rotation.x *= 0.8;
    player.userData.legR.rotation.x *= 0.8;
    player.userData.armL.rotation.x *= 0.8;
    player.userData.armR.rotation.x *= 0.8;
  }
}

function updateVehicle() {
  const throttle = -touchState.moveY;
  const steer = touchState.moveX;

  vehicleSpeed += throttle * 0.25;
  vehicleSpeed *= 0.98;
  vehicleSpeed = Math.max(-8, Math.min(18, vehicleSpeed));

  if (Math.abs(vehicleSpeed) > 0.5) {
    vehicleYaw -= steer * 0.03 * Math.sign(vehicleSpeed);
  }

  const dir = new THREE.Vector3(Math.sin(vehicleYaw), 0, Math.cos(vehicleYaw));
  vehicleBody.velocity.x = dir.x * vehicleSpeed;
  vehicleBody.velocity.z = dir.z * vehicleSpeed;
  vehicleBody.velocity.y = 0;
  vehicleBody.angularVelocity.set(0, 0, 0);
  vehicleBody.quaternion.setFromEuler(0, vehicleYaw, 0);

  vehicle.position.x = vehicleBody.position.x;
  vehicle.position.z = vehicleBody.position.z;
  vehicle.position.y = heightAt(vehicle.position.x, vehicle.position.z) + 0.05;
  vehicle.rotation.y = vehicleYaw;
  vehicleBody.position.y = vehicle.position.y + 0.5;

  player.position.copy(vehicle.position);
  player.position.y += 1.3;
  player.rotation.y = vehicleYaw;
}

function updateCamera(dt) {
  const target = inVehicle ? vehicle.position : player.position;
  const back = inVehicle ? 8 : 6;
  const up = inVehicle ? 4 : 3;
  const lookHeight = inVehicle ? 2.2 : 1.5;

  const offset = new THREE.Vector3(0, up, -back);
  offset.applyAxisAngle(new THREE.Vector3(0, 1, 0), cameraYaw);
  const desired = new THREE.Vector3().copy(target).add(offset);
  desired.y += 1;

  const smoothing = 1 - Math.pow(0.001, dt);
  camera.position.lerp(desired, smoothing);
  const lookAt = new THREE.Vector3().copy(target);
  lookAt.y += lookHeight;
  camera.lookAt(lookAt);
}

function findTargetFromObject(obj) {
  while (obj) {
    const found = targets.find(t => t.mesh === obj);
    if (found) return found;
    obj = obj.parent;
  }
  return null;
}

function registerHit(target) {
  target.hp -= 1;
  playHit();
  target.hitFlash = 10;
  if (target.hp <= 0) {
    target.alive = false;
    target.mesh.visible = false;
    target.respawnTimer = 240;
  }
}

function tryShoot() {
  if (touchState.fireCd > 0) return;
  touchState.fireCd = 12;
  playShoot();
  muzzleTimer = 4;

  const yaw = inVehicle ? vehicleYaw : player.rotation.y;
  const origin = (inVehicle ? vehicle.position : player.position).clone();
  origin.y += inVehicle ? 1.6 : 1.4;
  const dir = new THREE.Vector3(Math.sin(yaw), 0, Math.cos(yaw));

  raycaster.set(origin, dir);
  const liveMeshes = targets.filter(t => t.alive).map(t => t.mesh);
  if (dragonState.alive) liveMeshes.push(dragon);
  const hits = raycaster.intersectObjects(liveMeshes, true);

  let dist = 50;
  if (hits.length > 0) {
    dist = hits[0].distance;
    let obj = hits[0].object;
    while (obj && obj !== dragon && !targets.find(t => t.mesh === obj)) obj = obj.parent;
    if (obj === dragon) registerDragonHit();
    else {
      const target = findTargetFromObject(obj);
      if (target) registerHit(target);
    }
  }
  spawnTracer(origin, dir, dist);
}

function tryToggleVehicle() {
  if (inVehicle) {
    inVehicle = false;
    player.visible = true;
    player.position.copy(vehicle.position);
    player.position.x += 2;
    playerBody.position.set(player.position.x, player.position.y + 1, player.position.z);
    playerBody.velocity.set(0, 0, 0);
  } else {
    const d = player.position.distanceTo(vehicle.position);
    if (d < 4) {
      inVehicle = true;
      player.visible = false;
      vehicleYaw = player.rotation.y;
    }
  }
}

function updateHUD() {
  const alive = targets.filter(t => t.alive).length;
  const healthFill = document.getElementById('healthFill');
  if (healthFill) healthFill.style.width = Math.max(0, (playerHp / playerMaxHp) * 100) + '%';
  const dragonStatus = dragonState.alive ? 'circling the village' : 'driven off';
  document.getElementById('hudText').innerText =
    (inVehicle ? 'Driving' : 'On foot') + ' \u00b7 Targets standing: ' + alive + '/' + targets.length +
    ' \u00b7 Dragon: ' + dragonStatus;
}

// ---- Start menu wiring ----
document.getElementById('btnPlay').addEventListener('click', () => {
  document.getElementById('startMenu').style.display = 'none';
  initAudio();
  gameStarted = true;
});
document.getElementById('btnSound').addEventListener('click', function () {
  setSoundOn(!soundOn);
  this.innerText = 'SFX: ' + (soundOn ? 'On' : 'Off');
});
document.getElementById('btnMusic').addEventListener('click', function () {
  setMusicOn(!musicOn);
  this.innerText = 'Music: ' + (musicOn ? 'On' : 'Off');
});

// ---- Main loop ----
function animate() {
  requestAnimationFrame(animate);
  const dt = Math.min(clock.getDelta(), 0.05);

  if (!gameStarted) {
    renderer.render(scene, camera);
    return;
  }

  if (!isTouchDevice) applyKeyboardMovement();

  world.step(1 / 60, dt, 3);

  if (touchState.enterQueued) { touchState.enterQueued = false; tryToggleVehicle(); }

  if (inVehicle) updateVehicle(); else updateMovementOnFoot(dt);
  updateCamera(dt);
  updateAura(dt);
  updateDragon(dt);
  updateVillagers(dt);

  if (playerHp <= 0) {
    playerHp = playerMaxHp;
    player.position.set(0, heightAt(0, 0), 0);
    playerBody.position.set(0, 3, 0);
    playerBody.velocity.set(0, 0, 0);
  }

  if (touchState.fireCd > 0) touchState.fireCd--;
  if (touchState.firing) tryShoot();

  if (muzzleTimer > 0) {
    muzzleTimer--;
    const yaw = inVehicle ? vehicleYaw : player.rotation.y;
    const origin = (inVehicle ? vehicle.position : player.position).clone();
    origin.y += inVehicle ? 1.6 : 1.4;
    origin.add(new THREE.Vector3(Math.sin(yaw), 0, Math.cos(yaw)));
    muzzleFlashMesh.position.copy(origin);
    muzzleFlashMesh.material.opacity = muzzleTimer / 4;
    muzzleFlashMesh.visible = true;
  } else {
    muzzleFlashMesh.visible = false;
  }

  for (let i = bullets.length - 1; i >= 0; i--) {
    const l = bullets[i];
    l.userData.life--;
    l.material.opacity = Math.max(l.userData.life / 6, 0);
    if (l.userData.life <= 0) { scene.remove(l); bullets.splice(i, 1); }
  }

  targets.forEach(t => {
    if (!t.alive) {
      t.respawnTimer--;
      if (t.respawnTimer <= 0) {
        t.alive = true; t.hp = 3; t.mesh.visible = true; t.mesh.scale.setScalar(1);
      }
    } else if (t.hitFlash > 0) {
      t.hitFlash--;
      const s = 1 + Math.sin((10 - t.hitFlash) * 0.6) * 0.15;
      t.mesh.scale.setScalar(Math.max(s, 1));
    } else {
      t.mesh.scale.setScalar(1);
    }
  });

  sun.target.position.copy(inVehicle ? vehicle.position : player.position);

  updateHUD();
  renderer.render(scene, camera);
}
animate();
