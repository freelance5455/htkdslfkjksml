/* Zombie Night - three.js compatibility layer.
   The game was written for three.js r128; this file lets it run on the bundled three.js r160 (no internet / CDN needed). */
(function(){
  var T=THREE,A=window.THREE_ADDONS||{};
  T.GLTFLoader=A.GLTFLoader;T.SkeletonUtils=A.SkeletonUtils;
  if(T.ColorManagement)T.ColorManagement.enabled=false;            // same colour handling as r128
  Object.defineProperty(T.Texture.prototype,'encoding',{configurable:true,
    get:function(){return this.colorSpace===T.SRGBColorSpace?3001:3000},
    set:function(v){this.colorSpace=(v===3001)?T.SRGBColorSpace:T.NoColorSpace}});
  Object.defineProperty(T.WebGLRenderer.prototype,'outputEncoding',{configurable:true,
    get:function(){return this.outputColorSpace===T.SRGBColorSpace?3001:3000},
    set:function(v){this.outputColorSpace=(v===3001)?T.SRGBColorSpace:T.LinearSRGBColorSpace}});
  // r160 measures skinned meshes in their posed state; r128 used the plain geometry box (the game's size maths expects that)
  T.Box3.prototype.expandByObject=function(object,precise){
    object.updateWorldMatrix(false,false);
    var g=object.geometry;
    if(g!==undefined){if(g.boundingBox===null)g.computeBoundingBox();this.union(new T.Box3().copy(g.boundingBox).applyMatrix4(object.matrixWorld))}
    var ch=object.children;for(var i=0;i<ch.length;i++)this.expandByObject(ch[i],precise);
    return this};
  var R=T.WebGLRenderer;                                              // same light brightness as r128
  function Renderer(p){var r=new R(p);try{r.useLegacyLights=true}catch(e){}return r}
  Renderer.prototype=R.prototype;
  try{T.WebGLRenderer=Renderer}catch(e){Object.defineProperty(T,'WebGLRenderer',{value:Renderer})}
})();
