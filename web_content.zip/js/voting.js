"use strict";

const Voting = (() => {
  const TRANSITIONS = {
    discussion: ["nomination"],
    nomination: ["handover"],
    handover: ["action"],
    action: ["transition"],
    transition: ["handover", "tally"],
    tally: ["handover", "result"],
    result: ["done"],
    done: [],
  };

  function canTransition(from, to) {
    return Array.isArray(TRANSITIONS[from]) && TRANSITIONS[from].includes(to);
  }

  // جولة تصويت جديدة
  function create(voterIds, candidateIds, round, shuffleFn) {
    return {
      round,
      candidates: candidateIds.slice(),
      order: shuffleFn(voterIds),
      index: 0,
      votes: [],
    };
  }

  // ما الذي يظهر للمصوّت؟
  function describeVote(ctx) {
    const { voter, candidates, silenced } = ctx;
    if (silenced) {
      return {
        kind: "silenced",
        title: "🔮 مُنعت من التصويت",
        prompt: "أصابتك تعويذة الساحر، فلا يُحتسب صوتك اليوم.",
        targets: [],
        allowAbstain: false,
      };
    }
    return {
      kind: "vote",
      title: "🗳️ صوّت سريًا",
      prompt: "اختر من تريد استبعاده، أو امتنع عن التصويت.",
      targets: candidates.filter((c) => c.id !== voter.id).map((c) => ({ id: c.id, name: c.name })),
      allowAbstain: true,
    };
  }

  // حساب الأصوات (الامتناع لا يُحتسب)
  function tally(votes, candidateIds) {
    const counts = {};
    candidateIds.forEach((id) => { counts[id] = 0; });
    votes.forEach((vote) => {
      if (vote.target !== null && Object.prototype.hasOwnProperty.call(counts, vote.target)) {
        counts[vote.target] += vote.weight;
      }
    });
    const values = candidateIds.map((id) => counts[id]);
    const max = values.length ? Math.max(...values) : 0;
    const top = max > 0 ? candidateIds.filter((id) => counts[id] === max) : [];
    const total = values.reduce((sum, v) => sum + v, 0);
    return { counts, total, max, top };
  }

  // ماذا نفعل بعد الحساب؟
  function decide(tallyResult, options) {
    if (tallyResult.top.length === 0) return "none";
    if (tallyResult.top.length === 1) return "eliminate";
    if (options.tieRule === "revote" && !options.revoteDone) return "revote";
    return "none";
  }

  return { TRANSITIONS, canTransition, create, describeVote, tally, decide };
})();