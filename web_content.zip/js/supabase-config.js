// Fill in these two values after creating your Supabase project.
// The publishable key is safe to expose because the database only permits public reads.
window.HSL_SUPABASE_CONFIG = {
  url: "https://usdoofzvvmhyxjruqvis.supabase.co",
  publishableKey: "sb_publishable_svwB19mvHd_oVKpCibUnFA_PbulSaRg"
};
