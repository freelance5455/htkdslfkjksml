(function () {
  'use strict';
  const P = (window.Pith = window.Pith || {});
  const U = P.util;
  const h = U.h;
  const icon = U.icon;
  const S = P.state;
  const C = P.chat;
  const UI = P.ui;
  const V = (P.views = {});
  const els = {};
  const wide = () => window.matchMedia('(min-width: 900px)').matches;
  const finePointer = () => window.matchMedia('(pointer: fine)').matches;
  const userName = () => (S.profile && S.profile.name) || 'You';

  V.mark = function (size) {
    const span = h('span', { class: 'mark', style: { width: size + 'px', height: size + 'px' } });
    span.innerHTML = '<svg viewBox="0 0 24 24" width="100%" height="100%"><circle cx="12" cy="12" r="9.3" fill="none" stroke="currentColor" stroke-width="3.2"/><circle cx="12" cy="12" r="3.7" fill="var(--accent)"/></svg>';
    return span;
  };

  V.avatar = function (size) {
    const p = S.profile;
    const el = h('span', { class: 'avatar', style: { width: size + 'px', height: size + 'px', fontSize: size * 0.42 + 'px' } });
    if (p && p.photo) el.append(h('img', { src: p.photo, alt: '' }));
    else el.textContent = ((p && p.name) || '?').trim().charAt(0).toUpperCase() || '?';
    return el;
  };

  function mediaImg(att, cls) {
    const img = h('img', { class: cls, alt: att.name });
    img.addEventListener('load', () => { if (stick && els.messages) scrollBottom(false); });
    P.media.url(att.id).then((u) => { if (u) img.src = u; else img.classList.add('broken'); });
    return img;
  }

  // ================================================================ shell
  let drawer = null;

  V.openSidebar = function () {
    if (wide()) {
      document.body.classList.remove('sidebar-collapsed');
      S.prefs.sidebarOpen = true; S.savePrefs();
    } else if (!drawer) {
      document.body.classList.add('drawer-open');
      drawer = UI.register({ dispose() { document.body.classList.remove('drawer-open'); drawer = null; } });
    }
  };
  V.closeSidebar = function () {
    if (wide()) {
      document.body.classList.add('sidebar-collapsed');
      S.prefs.sidebarOpen = false; S.savePrefs();
    } else if (drawer) drawer.close();
  };
  const dismissDrawer = () => { if (!wide() && drawer) drawer.close(); };

  V.build = function () {
    const app = document.getElementById('app');
    app.textContent = '';

    els.list = h('div', { class: 'side-list' });
    els.profile = h('button', { class: 'side-foot', onclick: () => { dismissDrawer(); V.openSettings(); } });
    els.sidebar = h('aside', { id: 'sidebar', 'aria-label': 'Chats' },
      h('div', { class: 'side-head' }, V.mark(22), h('span', { class: 'brand' }, 'Pith'),
        h('button', { class: 'icon-btn collapse', 'aria-label': 'Hide sidebar', onclick: V.closeSidebar }, icon('chevron-left'))),
      h('div', { class: 'side-nav' },
        h('button', { class: 'nav-btn', onclick: () => { U.haptic(6); C.newChat(); dismissDrawer(); } }, icon('compose'), 'New chat'),
        h('button', { class: 'nav-btn', onclick: () => { dismissDrawer(); V.openSearch(); } }, icon('search'), 'Search chats')),
      els.list,
      els.profile);

    els.title = h('div', { class: 'tb-title' }, 'New chat');
    els.more = h('button', { class: 'icon-btn', 'aria-label': 'Chat options', onclick: () => { const c = S.active(); if (c) chatMenu(c); } }, icon('more'));
    els.topbar = h('header', { id: 'topbar' },
      h('button', { class: 'icon-btn menu-btn', 'aria-label': 'Chats', onclick: V.openSidebar }, icon('menu')),
      els.title,
      h('button', { class: 'icon-btn', 'aria-label': 'New chat', onclick: () => C.newChat() }, icon('compose')),
      els.more);

    els.messages = h('div', { id: 'messages', tabindex: '-1' });
    els.jump = h('button', { id: 'jump', 'aria-label': 'Jump to latest', onclick: () => scrollBottom(true) }, icon('chevron-down'));
    els.stage = h('section', { id: 'stage' }, h('div', { class: 'chat-bg' }), els.messages, els.jump);
    els.composer = h('footer', { id: 'composer' });

    app.append(els.sidebar, h('div', { id: 'scrim', onclick: dismissDrawer }), h('main', { id: 'main' }, els.topbar, els.stage, els.composer));
    if (wide() && S.prefs.sidebarOpen === false) document.body.classList.add('sidebar-collapsed');

    let lastInput = 0;
    ['touchstart', 'touchmove', 'wheel', 'pointerdown', 'keydown'].forEach((t) => els.messages.addEventListener(t, () => { lastInput = Date.now(); }, { passive: true }));
    els.messages.addEventListener('scroll', () => {
      const m = els.messages;
      const near = m.scrollHeight - m.scrollTop - m.clientHeight < 140;
      if (near) stick = true;
      else if (Date.now() - lastInput < 1500) stick = false;
      els.jump.classList.toggle('show', !stick);
    }, { passive: true });
    els.messages.addEventListener('click', (e) => {
      const btn = e.target.closest && e.target.closest('.code-copy');
      if (!btn) return;
      const code = btn.closest('.code').querySelector('code').textContent;
      U.copy(code).then((ok) => {
        U.haptic(8);
        btn.textContent = ok ? 'Copied' : 'Copy failed';
        setTimeout(() => { btn.textContent = 'Copy'; }, 1600);
      });
    });

    // Swipe from the left edge to open the drawer, swipe left on it to close.
    let sx = null, sy = 0, fromEdge = false, inDrawer = false;
    document.addEventListener('touchstart', (e) => {
      if (wide()) return;
      const t = e.touches[0];
      sx = t.clientX; sy = t.clientY;
      fromEdge = sx < 22 && !UI.hasOverlay();
      inDrawer = !!(drawer && e.target.closest && e.target.closest('#sidebar'));
    }, { passive: true });
    document.addEventListener('touchend', (e) => {
      if (sx == null) return;
      const t = e.changedTouches[0];
      const dx = t.clientX - sx, dy = Math.abs(t.clientY - sy);
      if (fromEdge && dx > 70 && dy < 60) V.openSidebar();
      else if (inDrawer && dx < -70 && dy < 60) dismissDrawer();
      sx = null;
    }, { passive: true });

    window.addEventListener('resize', U.debounce(() => {
      if (wide()) { if (drawer) drawer.close(); document.body.classList.toggle('sidebar-collapsed', S.prefs.sidebarOpen === false); }
      else document.body.classList.remove('sidebar-collapsed');
    }, 100));

    S.on('list', renderList);
    S.on('profile', () => { renderList(); });
    S.on('chat', onChatEvent);
    S.on('composer', renderComposer);

    buildComposer();
    renderList();
    V.renderMessages({ scroll: 'bottom' });
    renderTopbar();
    renderComposer();
  };

  // ================================================================ sidebar
  function renderList() {
    const box = els.list;
    box.textContent = '';
    const chats = S.sorted();
    if (!chats.length) box.append(h('p', { class: 'side-empty' }, 'Your conversations will appear here.'));
    let current = null;
    chats.forEach((c) => {
      const label = c.pinned ? 'Pinned' : U.bucketLabel(c.updatedAt);
      if (label !== current) { box.append(h('div', { class: 'side-group' }, label)); current = label; }
      const item = h('div', { class: 'chat-item' + (c.id === S.activeId ? ' active' : ''), role: 'button', tabindex: '0',
        onclick: () => { if (Date.now() - (item._lpAt || 0) < 700) return; U.haptic(6); C.open(c.id); dismissDrawer(); },
        onkeydown: (e) => { if (e.key === 'Enter') item.click(); } },
        h('span', { class: 'ci-title' }, c.title),
        c.pinned ? h('span', { class: 'ci-pin' }, icon('pin')) : null,
        h('button', { class: 'ci-more', 'aria-label': 'Options for ' + c.title, onclick: (e) => { e.stopPropagation(); chatActions(c); } }, icon('more')));
      U.onLongPress(item, () => { U.haptic(12); chatActions(c); });
      box.append(item);
    });
    els.profile.textContent = '';
    els.profile.append(V.avatar(38), h('span', { class: 'sf-name' }, userName()), icon('sliders'));
  }

  function chatActions(c) {
    UI.actionSheet(c.title, [
      { icon: 'edit', label: 'Rename', onClick: async () => { const t = await UI.prompt({ title: 'Rename chat', value: c.title }); if (t) C.rename(c, t); } },
      { icon: 'pin', label: c.pinned ? 'Unpin' : 'Pin to top', onClick: () => C.togglePin(c) },
      { icon: 'trash', label: 'Delete', danger: true, onClick: () => confirmDelete(c) },
    ]);
  }

  async function confirmDelete(c) {
    const ok = await UI.confirm({ title: 'Delete this chat?', message: 'The conversation and its attachments will be removed from this device.' });
    if (ok) C.deleteChat(c);
  }

  // ================================================================ top bar
  function chatMenu(c) {
    UI.actionSheet(c.title, [
      { icon: 'edit', label: 'Rename', onClick: async () => { const t = await UI.prompt({ title: 'Rename chat', value: c.title }); if (t) C.rename(c, t); } },
      { icon: 'pin', label: c.pinned ? 'Unpin' : 'Pin to top', onClick: () => C.togglePin(c) },
      { icon: 'sliders', label: 'Instructions for this chat', onClick: () => UI.textSheet({ title: 'Instructions for this chat', description: 'Pith follows these in this conversation only. Leave empty to use your default instructions.', value: c.system, placeholder: 'For example: Answer in short bullet points.', onSave: (t) => C.setSystem(c, t) }) },
      { icon: 'file', label: 'Export as text', onClick: () => exportChat(c, 'text') },
      { icon: 'download', label: 'Export as PDF', onClick: () => exportChat(c, 'pdf') },
      { icon: 'copy', label: 'Copy conversation', onClick: async () => { const ok = await U.copy(P.exporter.transcript(c, userName())); U.toast(ok ? 'Conversation copied.' : 'Could not copy.'); } },
      { icon: 'trash', label: 'Delete', danger: true, onClick: () => confirmDelete(c) },
    ]);
  }

  async function exportChat(c, kind) {
    const base = c.title.replace(/[\\/:*?"<>|\r\n]/g, '').trim().slice(0, 60) || 'chat';
    try {
      U.toast(kind === 'pdf' ? 'Preparing PDF…' : 'Preparing text file…');
      const blob = kind === 'pdf' ? await P.exporter.pdf(c, userName()) : P.exporter.text(c, userName());
      const how = await U.deliver(blob, base + (kind === 'pdf' ? '.pdf' : '.md'));
      if (how === 'downloaded') U.toast('Saved to your downloads.');
    } catch (e) { U.toast('Export failed: ' + e.message); }
  }

  function renderTopbar() {
    const c = S.active();
    els.title.textContent = c ? c.title : 'New chat';
    els.more.style.display = c ? '' : 'none';
  }

  // ================================================================ messages
  let stick = true;
  const rows = new Map();

  function scrollBottom(smooth) {
    const m = els.messages;
    stick = true;
    els.jump.classList.remove('show');
    if (smooth && m.scrollTo) m.scrollTo({ top: m.scrollHeight, behavior: 'smooth' });
    else m.scrollTop = m.scrollHeight;
  }

  function onChatEvent(e) {
    renderList();
    renderTopbar();
    const kind = e && e.kind;
    if (kind === 'title') return;
    if (kind === 'highlight') { U.$$('.row.hl', els.messages).forEach((r) => r.classList.remove('hl')); return; }
    const chat = S.active();
    if (kind === 'full' || !kind) { V.renderMessages(e || {}); renderComposer(); return; }
    if (!chat || (e.chatId && e.chatId !== chat.id)) return;
    const m = chat.messages.find((x) => x.id === e.msgId);
    if (!m) return;
    if (kind === 'append') {
      if (els.messages.classList.contains('empty')) { V.renderMessages({ scroll: 'bottom' }); return; }
      const idx = chat.messages.indexOf(m);
      const prev = chat.messages[idx - 1];
      if (prev && rows.has(prev.id)) swapRow(chat, prev, idx - 1);
      const row = rowEl(chat, m, idx);
      rows.set(m.id, row);
      els.messages.append(row);
      if (stick) scrollBottom(false);
    } else if (kind === 'update') {
      swapRow(chat, m, chat.messages.indexOf(m));
      if (stick) scrollBottom(false);
    } else if (kind === 'stream') {
      const row = rows.get(m.id);
      const body = row && row.querySelector('.body');
      if (!body) return;
      body.innerHTML = P.md.render(m.text, { streaming: true });
      if (stick) scrollBottom(false);
    }
  }

  function swapRow(chat, m, idx) {
    const old = rows.get(m.id);
    const fresh = rowEl(chat, m, idx);
    if (old) old.replaceWith(fresh); else els.messages.append(fresh);
    rows.set(m.id, fresh);
  }

  V.renderMessages = function (opt) {
    const chat = S.active();
    const box = els.messages;
    box.textContent = '';
    rows.clear();
    if (!chat || !chat.messages.length) {
      box.classList.add('empty');
      box.append(emptyState());
      stick = true;
      els.jump.classList.remove('show');
      return;
    }
    box.classList.remove('empty');
    chat.messages.forEach((m, i) => { const row = rowEl(chat, m, i); rows.set(m.id, row); box.append(row); });
    const jump = opt && opt.scroll === 'jump' && S.jump;
    if (jump && rows.has(jump)) {
      const row = rows.get(jump);
      row.classList.add('hl');
      requestAnimationFrame(() => row.scrollIntoView({ block: 'center' }));
      S.jump = null;
      stick = false;
    } else if ((opt && opt.scroll === 'bottom') || stick) {
      requestAnimationFrame(() => scrollBottom(false));
      stick = true;
    }
    els.jump.classList.toggle('show', !stick);
  };

  function emptyState() {
    const starters = [
      ['Explain how tides work in plain language', false],
      ['Help me word a polite no to an invitation', false],
      ['Create an image of a lighthouse in morning fog', true],
    ];
    const first = userName().split(' ')[0];
    return h('div', { class: 'empty-state' },
      h('h1', null, `Hello, ${first}`),
      h('p', null, 'Ask a question, attach a file, or describe a picture.'),
      starters.map(([t, img]) => h('button', { class: 'starter', onclick: () => C.usePrompt(t, img) }, t)));
  }

  function rowEl(chat, m, idx) {
    const prev = chat.messages[idx - 1];
    const newDay = !prev || !U.sameDay(prev.ts, m.ts);
    const isLast = idx === chat.messages.length - 1;
    const fresh = Date.now() - m.ts < 900;
    const row = h('div', { class: 'row' + (fresh ? ' fresh' : '') + (S.highlightId === m.id ? ' hl' : ''), 'data-id': m.id },
      newDay ? h('div', { class: 'day' }, U.dayLabel(m.ts)) : null,
      m.role === 'user' ? userMsg(chat, m) : assistantMsg(chat, m, isLast, idx));
    return row;
  }

  function attachmentsEl(m, openImage) {
    const imgs = (m.attachments || []).filter((a) => a.kind === 'image');
    const files = (m.attachments || []).filter((a) => a.kind !== 'image');
    return [
      imgs.length ? h('div', { class: 'atts' }, imgs.map((a) => { const i = mediaImg(a, 'att-img' + (imgs.length === 1 ? ' single' : '')); i.addEventListener('click', () => openImage(a)); return i; })) : null,
      files.map((a) => h('div', { class: 'file-chip' }, icon(a.kind === 'pdf' ? 'file' : a.kind === 'audio' ? 'audio' : 'file'), h('span', { class: 'fc-name' }, a.name), h('span', { class: 'fc-size' }, U.fmtSize(a.size)))),
    ];
  }

  function userMsg(chat, m) {
    const busy = S.isBusy(chat.id);
    const wrap = h('div', { class: 'msg user' },
      attachmentsEl(m, (a) => V.openImage(a)),
      m.text ? h('div', { class: 'bubble', onclick: () => wrap.classList.toggle('show-actions') }, m.text) : null,
      h('div', { class: 'meta' },
        m.status === 'queued' ? h('span', { class: 'queued' }, icon('clock'), 'Waiting for connection') : null,
        h('span', null, U.timeLabel(m.ts))),
      h('div', { class: 'uactions' },
        m.text ? act('copy', 'Copy', () => copyText(m.text)) : null,
        !busy ? act('edit', 'Edit and resend', () => { wrap.classList.remove('show-actions'); C.beginEdit(m); }) : null,
        act('trash', 'Delete', () => C.deleteMessage(chat, m))));
    return wrap;
  }

  async function copyText(t) {
    const ok = await U.copy(t);
    U.haptic(8);
    U.toast(ok ? 'Copied' : 'Could not copy');
  }

  function act(name, label, fn) {
    return h('button', { class: 'act', title: label, 'aria-label': label, onclick: (e) => { e.stopPropagation(); fn(); } }, icon(name));
  }

  function assistantMsg(chat, m, isLast, idx) {
    const gen = S.gens.get(chat.id);
    const streaming = !!(gen && gen.msgId === m.id);
    const trigger = chat.messages[idx - 1];
    const body = h('div', { class: 'md body' });
    if (m.text) body.innerHTML = P.md.render(m.text, { streaming });
    else if (streaming) body.append(h('span', { class: 'pulse' }), trigger && trigger.imageReq ? h('span', { class: 'making' }, 'Creating your image…') : null);
    const imgs = (m.attachments || []).filter((a) => a.kind === 'image');
    const first = imgs[0];
    return h('div', { class: 'msg assistant' },
      body,
      imgs.map((a) => { const i = mediaImg(a, 'gen-img'); i.addEventListener('click', () => V.openImage(a)); return i; }),
      m.status === 'error' && m.error ? h('div', { class: 'err' }, icon('alert'), h('span', null, m.error),
        !S.isBusy(chat.id) ? h('button', { class: 'btn small', onclick: () => C.regenerate(chat.id, m.id) }, 'Try again') : null) : null,
      !streaming ? h('div', { class: 'actions' },
        m.text ? act('copy', 'Copy', () => copyText(m.text)) : null,
        first ? act('share', 'Share image', async () => { const b = await P.media.blob(first.id); if (b) U.deliver(b, 'pith-image.' + (first.mime.split('/')[1] || 'png').replace('jpeg', 'jpg')); }) : null,
        first ? act('brush', 'Edit this image', () => { C.editImage(first); U.toast('Describe the change you want.'); }) : null,
        isLast && !S.isBusy(chat.id) && m.status === 'done' ? act('refresh', 'Regenerate', () => C.regenerate(chat.id, m.id)) : null,
        act('trash', 'Delete', async () => { if (await UI.confirm({ title: 'Delete this reply?' })) C.deleteMessage(chat, m); }),
        h('span', { class: 'grow' }),
        h('span', { class: 'time' }, U.timeLabel(m.ts))) : null);
  }

  // ================================================================ image viewer
  V.openImage = function (att) {
    const img = mediaImg(att, 'viewer-img');
    let entry;
    const el = h('div', { class: 'viewer' },
      h('div', { class: 'viewer-bar' },
        h('button', { class: 'icon-btn light', 'aria-label': 'Close', onclick: () => entry.close() }, icon('x')),
        h('span', { class: 'grow vname' }, att.name),
        h('button', { class: 'icon-btn light', 'aria-label': 'Share or save', onclick: async () => { const b = await P.media.blob(att.id); if (b) U.deliver(b, att.name.replace(/\s+/g, '-') + '.' + ((att.mime || 'image/png').split('/')[1] || 'png').replace('jpeg', 'jpg')); } }, icon('share'))),
      img);
    img.addEventListener('dblclick', () => img.classList.toggle('zoom'));
    entry = UI.mount(el);
  };

  // ================================================================ composer
  let ta, sendBtn, strip, banner, offline;
  function buildComposer() {
    ta = h('textarea', { rows: '1', placeholder: 'Message Pith', 'aria-label': 'Message', spellcheck: 'true' });
    const grow = () => { ta.style.height = 'auto'; ta.style.height = Math.min(ta.scrollHeight, 168) + 'px'; };
    ta.addEventListener('input', () => { grow(); updateSend(); });
    ta.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey && !e.isComposing && finePointer()) { e.preventDefault(); sendOrStop(); }
    });
    P.composer = {
      getText: () => ta.value,
      setText: (t) => { ta.value = t; grow(); updateSend(); },
      focus: () => { ta.focus(); },
    };
    banner = h('div', { class: 'banners' });
    strip = h('div', { class: 'strip' });
    offline = h('div', { class: 'offline' }, icon('clock'), 'You are offline. Queued messages send when the connection returns.');
    sendBtn = h('button', { class: 'round send', 'aria-label': 'Send', onclick: sendOrStop }, icon('arrow-up'));
    const plus = h('button', { class: 'round plus', 'aria-label': 'Add attachment', onclick: attachSheet }, icon('plus'));
    els.composer.append(h('div', { class: 'composer-inner' }, offline, banner, strip, h('div', { class: 'box' }, plus, ta, sendBtn)));
  }

  function sendOrStop() {
    if (S.isBusy(S.activeId)) C.stop(); else C.send();
  }

  function updateSend() {
    const busy = S.isBusy(S.activeId);
    const ready = ta.value.trim().length > 0 || S.pending.length > 0;
    sendBtn.classList.toggle('ready', busy || ready);
    sendBtn.disabled = !busy && !ready;
    sendBtn.replaceChildren(icon(busy ? 'stop' : 'arrow-up'));
    sendBtn.setAttribute('aria-label', busy ? 'Stop' : 'Send');
  }

  function renderComposer() {
    if (!ta) return;
    ta.placeholder = S.imageMode ? 'Describe the image' : 'Message Pith';
    banner.textContent = '';
    if (S.editingId) banner.append(bannerEl('edit', 'Editing message', () => C.cancelEdit()));
    if (S.imageMode) banner.append(bannerEl('image', 'Image mode: your next message creates a picture', () => C.toggleImageMode()));
    strip.textContent = '';
    strip.classList.toggle('has', S.pending.length > 0);
    S.pending.forEach((a) => {
      const inner = a.kind === 'image'
        ? mediaImg(a, 'pend-img')
        : h('div', { class: 'pend-file' }, icon(a.kind === 'audio' ? 'audio' : 'file'), h('span', null, a.name));
      strip.append(h('div', { class: 'pend' }, inner, h('button', { class: 'pend-x', 'aria-label': 'Remove ' + a.name, onclick: () => C.removePending(a.id) }, icon('x'))));
    });
    const chat = S.active();
    offline.classList.toggle('show', !!(chat && C.hasQueued(chat)));
    updateSend();
  }

  function bannerEl(ic, text, onClose) {
    return h('div', { class: 'banner' }, icon(ic), h('span', { class: 'grow' }, text), h('button', { class: 'icon-btn small', 'aria-label': 'Dismiss', onclick: onClose }, icon('x')));
  }

  function attachSheet() {
    U.haptic(8);
    let entry;
    const pick = (inputId) => { entry.close(); const input = document.getElementById(inputId); input.value = ''; setTimeout(() => input.click(), 60); };
    const tile = (ic, label, fn) => h('button', { class: 'tile', onclick: fn }, h('span', { class: 'tile-ic' }, icon(ic)), h('span', null, label));
    entry = UI.sheet({
      title: null,
      content: h('div', { class: 'tiles' },
        tile('camera', 'Camera', () => pick('in-camera')),
        tile('image', 'Gallery', () => pick('in-gallery')),
        tile('file', 'Files', () => pick('in-files')),
        tile('brush', S.imageMode ? 'Text mode' : 'Create image', () => { entry.close(); C.toggleImageMode(); })),
    });
  }

  // ================================================================ search
  V.openSearch = function () {
    UI.view({
      title: 'Search',
      build(body, ctl) {
        const input = h('input', { class: 'input', type: 'search', placeholder: 'Search all chats', autocomplete: 'off', 'aria-label': 'Search all chats' });
        const out = h('div', { class: 'search-out' });
        const hint = (t) => h('p', { class: 'muted center pad' }, t);
        out.append(hint('Search titles and messages across every conversation.'));
        const run = U.debounce(() => {
          const q = input.value.trim();
          out.textContent = '';
          if (q.length < 2) { out.append(hint('Search titles and messages across every conversation.')); return; }
          const hits = C.search(q);
          if (!hits.length) { out.append(hint(`Nothing matches "${q}".`)); return; }
          hits.forEach((hit) => {
            const snippet = hit.msgId ? h('div', { class: 'hit-snip' }, hit.snippet.slice(0, hit.start), h('mark', null, hit.snippet.slice(hit.start, hit.end)), hit.snippet.slice(hit.end)) : null;
            out.append(h('button', { class: 'hit', onclick: () => { ctl.close(); C.open(hit.chat.id, hit.msgId); } },
              h('div', { class: 'hit-head' }, h('span', { class: 'hit-title' }, hit.chat.title), h('span', { class: 'muted small' }, U.dayLabel(hit.chat.updatedAt))), snippet));
          });
        }, 200);
        input.addEventListener('input', run);
        body.append(h('div', { class: 'search-bar' }, input), out);
        setTimeout(() => input.focus(), 250);
      },
    });
  };
})();
