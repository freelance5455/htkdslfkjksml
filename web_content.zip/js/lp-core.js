/* =============================================================
   LAMPION POS · js/lp.js
   Pengganti lapisan HTTP + api/*.php
   -------------------------------------------------------------
   KUNCI KONVERSI:
   Semua kode lama memanggil `LP.api('api/orders.php', {...})`.
   Daripada menulis ulang seluruh pos.js, fungsi LP.api() di sini
   DI-OVERRIDE menjadi router lokal: 'api/orders.php' dipetakan ke
   fungsi JavaScript LPAPI.orders(). Jadi tidak ada lagi request
   jaringan/PHP, tapi kontrak pemanggilan tetap sama.
   ============================================================= */
(function (global) {
  'use strict';

  /* PENTING: jangan simpan referensi modul di sini.
     lp-core.js dimuat SEBELUM auth.js, jadi `global.LPAUTH` masih
     undefined saat baris ini dijalankan. Ambil saat dipanggil saja
     supaya urutan pemuatan script tidak jadi masalah. */
  function PHP() { return global.LPHP; }
  function AUTH() { return global.LPAUTH; }

  /* ---------- peta endpoint: file .php -> fungsi JS ---------- */
  var ROUTES = {
    'api/auth.php': 'auth',
    'api/menus.php': 'menus',
    'api/categories.php': 'categories',
    'api/orders.php': 'orders',
    'api/sales.php': 'sales',
    'api/dashboard.php': 'dashboard',
    'api/inventory.php': 'inventory',
    'api/settings.php': 'settings',
    'api/display.php': 'display',
    'api/promo.php': 'promo',
    'api/menu_import.php': 'menuImport',
    'api/users.php': 'users'
  };

  /** Normalisasi URL: 'api/orders.php?x=1' -> 'api/orders.php' */
  function routeName(url) {
    var path = String(url || '').split('?')[0].replace(/^\.\//, '');
    return ROUTES[path] || null;
  }

  /** Query string -> object (padanan $_GET) */
  function parseQuery(url) {
    var out = {};
    var qs = String(url || '').split('?')[1];
    if (!qs) { return out; }
    qs.split('&').forEach(function (pair) {
      if (pair === '') { return; }
      var i = pair.indexOf('=');
      var k = i === -1 ? pair : pair.slice(0, i);
      var v = i === -1 ? '' : pair.slice(i + 1);
      try {
        out[decodeURIComponent(k)] = decodeURIComponent(v.replace(/\+/g, ' '));
      } catch (e) {
        out[k] = v;
      }
    });
    return out;
  }

  /* =============================================================
     Response — padanan json_out()/json_error()
     Fungsi API mengembalikan { status, data } sehingga LP.api bisa
     mereproduksi persis perilaku fetch + res.ok + data.error.
     ============================================================= */
  function ok(data) {
    return { status: 200, data: Object.assign({ ok: true }, data || {}) };
  }

  function fail(msg, status) {
    return { status: status || 400, data: { ok: false, error: String(msg) } };
  }

  /* =============================================================
     Gerbang auth — padanan require_api_auth() / require_api_permission()
     ============================================================= */
  function guard(perms) {
    return AUTH().authContext().then(function (c) {
      if (!c.user) {
        return { error: { status: 401, data: { ok: false, error: 'Sesi berakhir. Silakan masuk kembali.' } } };
      }
      /* padanan session_touch(): perpanjang sesi saat ada aktivitas user */
      AUTH().sessionTouch();
      for (var i = 0; i < (perms || []).length; i++) {
        if (!AUTH().can(perms[i])) {
          return { error: { status: 403, data: { ok: false, error: 'Akses ditolak untuk aksi ini.' } } };
        }
      }
      return { ctx: c };
    });
  }

  /* =============================================================
     Router utama — dipanggil LP.api(url, opts)
     opts = { method, body }   (body: string JSON, sama seperti fetch)
     ============================================================= */
  function dispatch(url, opts) {
    var name = routeName(url);
    if (!name) {
      return Promise.resolve(fail('Endpoint tidak dikenal: ' + url, 404));
    }
    var handler = global.LPAPI && global.LPAPI[name];
    if (!handler) {
      return Promise.resolve(fail('Handler JS untuk ' + name + ' belum dimuat.', 500));
    }

    var method = String((opts && opts.method) || 'GET').toUpperCase();
    var payload = {};
    if (opts && opts.body) {
      if (typeof opts.body === 'string') {
        try { payload = JSON.parse(opts.body); } catch (e) { payload = {}; }
      } else {
        payload = opts.body;
      }
    }

    return Promise.resolve()
      .then(function () {
        return handler({
          method: method,
          query: parseQuery(url),
          body: payload,
          url: url
        });
      })
      .catch(function (err) {
        return fail((err && err.message) ? err.message : 'Terjadi kesalahan internal.', 500);
      });
  }

  /* =============================================================
     LP.api() — pengganti fetch() di assets/js/app.js lama.
     Mengembalikan data JSON langsung, melempar Error bila gagal
     (persis seperti versi PHP supaya try/catch lama tetap jalan).
     ============================================================= */
  function api(url, opts) {
    opts = opts || {};
    return dispatch(url, opts).then(function (res) {
      if (res.status === 401) {
        /* padanan redirect ke login.php di app.js lama */
        AUTH().endSession();
        PHP().flashSet('warn', 'Sesi berakhir. Silakan masuk kembali.');
        setTimeout(function () { global.location.href = 'login.html'; }, 50);
        throw new Error('login');
      }
      if (res.status === 403) {
        throw new Error(res.data.error || 'Akses ditolak.');
      }
      if (res.status >= 400) {
        throw new Error((res.data && res.data.error) || ('Server error ' + res.status));
      }
      return res.data;
    });
  }

  /** Versi mentah: mengembalikan { status, data } tanpa melempar */
  function apiRaw(url, opts) {
    return dispatch(url, opts);
  }

  global.LPCORE = {
    ROUTES: ROUTES,
    routeName: routeName,
    parseQuery: parseQuery,
    ok: ok,
    fail: fail,
    guard: guard,
    dispatch: dispatch,
    api: api,
    apiRaw: apiRaw
  };
})(window);
