                                 
                                                                               
                                                                         
                                                                      

(function (S) {

    'use strict';

    var incoming = null;
    var active = null;
    var staticEl = null;
    var timerNode = null;
    var device = null;

    var ringTimer = 0;
    var tickTimer = 0;
    var staticTimer = 0;
    var buzzTimer = 0;
    var caller = null;
    var missed = 0;

    function contact(id) {
        return (S.SCENARIO && S.SCENARIO.contacts[id]) || { name: 'Número desconhecido', avatar: '👁️' };
    }

    function stopRing() {
        clearTimeout(ringTimer);
        ringTimer = 0;
    }

    function stopTick() {
        clearInterval(tickTimer);
        tickTimer = 0;
    }

                                                                              
                                                                              
                      
    function shake(mode) {
        device.classList.remove('is-ringing', 'is-in-call');
        if (mode) device.classList.add(mode);

        clearInterval(buzzTimer);
        buzzTimer = 0;
        if (navigator.vibrate) {
            navigator.vibrate(0);
            if (mode === 'is-ringing') buzzTimer = setInterval(function () {
                if (!S.device || !S.device.isVibrationEnabled || S.device.isVibrationEnabled()) {
                    navigator.vibrate([220, 140]);
                }
            }, 720);
        }
    }

                                                                        
                                       
    function log(contactId, type, note) {
        var who = contact(contactId);

        S.bridge.emit('telefone', 'log', {
            name: who.name,
            avatar: who.avatar,
            type: type,
            time: S.time(),
            note: note || ''
        });

        S.notifications.push({
            app: 'telefone',
            type: 'call',
            title: who.name,
            text: note || type,
            icon: 'phone',
            accent: 'var(--app-telefone)'
        });
    }

    S.calls = {

        init: function () {
            incoming = S.$('#callIn');
            active = S.$('#callActive');
            staticEl = S.$('#callStatic');
            timerNode = S.$('#callTimer');
            device = S.$('#device');
        },

                                         

        ring: function (contactId) {
            if (S.INCOMING_CALLS_ENABLED === false) return;
            if (caller) return;

            var who = contact(contactId);
            caller = { id: contactId, name: who.name, avatar: who.avatar };

            S.$('#callInAvatar').textContent = who.avatar;
            S.$('#callInName').textContent = who.name;
            S.$('#callActiveAvatar').textContent = who.avatar;
            S.$('#callActiveName').textContent = who.name;
            timerNode.textContent = '00:00';

            incoming.classList.add('is-open', 'is-ringing');
            shake('is-ringing');
            S.haptic(60);

                                                       
            ringTimer = setTimeout(function () {
                S.calls.decline(true);
            }, S.TIMING.ring);
        },

        answer: function () {
            if (!caller) return;
            stopRing();

            incoming.classList.remove('is-ringing');
            incoming.classList.remove('is-open');
            active.classList.add('is-open');
                                                                            
            shake('is-in-call');

            var started = Date.now();
            tickTimer = setInterval(function () {
                timerNode.textContent = S.duration(Date.now() - started);
            }, 1000);

            log(caller.id, 'Recebida', 'Chamada em curso');

                                                           
            staticTimer = setTimeout(function () {
                staticEl.hidden = false;

                staticTimer = setTimeout(function () {
                    staticEl.hidden = true;
                    S.calls.hangUp();
                }, 3000);
            }, S.TIMING.callStatic);
        },

        decline: function (missedCall) {
            if (!caller) return;
            stopRing();

            incoming.classList.remove('is-ringing');
            incoming.classList.remove('is-open');
            shake(null);

            if (missedCall) missed += 1;
            S.notifications.setBadge('telefone', missed);

            log(caller.id, 'Perdida', missedCall ? 'Chamada não atendida' : 'Chamada recusada');
            caller = null;
        },

        hangUp: function () {
            if (!caller) return;

            stopTick();
            clearTimeout(staticTimer);
            staticTimer = 0;
            staticEl.hidden = true;
            active.classList.remove('is-open');
            shake(null);

            log(caller.id, 'Encerrada', 'Ligação encerrada');
            caller = null;
        },

                                                                  
        request: function (payload) {
            if (S.INCOMING_CALLS_ENABLED === false) return;
            S.calls.ring((payload && payload.contact) || 'desconhecido');
        },

        missed: function () {
            return missed;
        },

                                                     
        clearMissed: function () {
            missed = 0;
            S.notifications.setBadge('telefone', 0);
        }

    };

})(window.Celular = window.Celular || {});
