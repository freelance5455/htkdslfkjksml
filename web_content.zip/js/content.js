window.KJ=window.KJ||{};
KJ.CONTENT={
 categories:{
 junior:["Makan & minum","Sekolah","Main & game","Beli barang","Berbagi","Lain-lain"],
 remaja:["Makanan & minuman","Transport","Sekolah","Game & hiburan","Pulsa & kuota","Pakaian & aksesori","Hobi","Hadiah & berbagi","Lain-lain"],
 senior:["Makanan & minuman","Transport","Sekolah","Game & hiburan","Pulsa & kuota","Pakaian & aksesori","Hobi","Hadiah & berbagi","Langganan","Lain-lain"]
 },
 income:["Uang saku","Hadiah atau angpao","Kerja sampingan","Jual barang","Lainnya"],
 lessons:{
 junior:[
 ["Kebutuhan dan keinginan","Kebutuhan adalah hal penting seperti makan dan sekolah. Keinginan adalah hal yang kita suka, tetapi bisa ditunda.","Kebutuhan","Mainan baru selalu kebutuhan","Keinginan"],
 ["Kenapa menabung","Menabung berarti menyimpan sebagian uang untuk tujuan nanti. Mulai sedikit demi sedikit juga berarti.","Menyimpan uang untuk tujuan","Menghabiskan semua uang","Meminjam setiap hari"],
 ["Tiga kantong","Jajan untuk kebutuhan harian, Tabung untuk rencana, dan Berbagi untuk membantu orang lain.","Jajan, Tabung, Berbagi","Jajan semua","Simpan semua di Jajan"],
 ["Membandingkan harga","Sebelum membeli, bandingkan harga dan kualitas. Harga paling murah belum tentu paling cocok.","Bandingkan harga dan kualitas","Pilih yang paling mahal","Beli tanpa melihat harga"],
 ["Uang pinjaman","Uang pinjaman harus dikembalikan sesuai janji. Pikirkan dulu sebelum meminjam.","Mengembalikannya sesuai janji","Menganggapnya hadiah","Melupakannya"],
 ["Catatan uang","Catatan membuat kita tahu uang masuk dan keluar. Catat segera agar tidak lupa.","Membantu memahami uang","Membuat uang bertambah sendiri","Menghapus pengeluaran"]
 ],
 remaja:[
 ["Anggaran sederhana","Anggaran adalah rencana membagi uang untuk kebutuhan, keinginan, dan tabungan.","Rencana penggunaan uang","Daftar barang mahal","Jumlah uang teman"],
 ["Beli sekarang atau menabung","Aturan tunggu 24 jam membantu kita berpikir sebelum membeli barang yang tidak mendesak.","Berhenti dan pikirkan dulu","Langsung checkout","Meminjam uang"],
 ["Diskon dan flash sale","Diskon tetap membuat kita mengeluarkan uang. Periksa harga akhir dan apakah barang memang dibutuhkan.","Periksa kebutuhan dan harga akhir","Beli sebanyak mungkin","Percaya hitung mundur"],
 ["Top-up game","Pembelian dalam aplikasi memakai uang sungguhan. Tentukan batas dan minta izin sesuai aturan keluarga.","Tetapkan batas belanja","Isi saldo tanpa rencana","Gunakan uang kebutuhan"],
 ["Dana darurat kecil","Dana darurat disimpan untuk kebutuhan mendadak, bukan untuk belanja rutin.","Keperluan tak terduga","Jajan harian","Mengikuti tren"],
 ["Tunai dan uang digital","Keduanya alat pembayaran. Uang digital perlu PIN dan OTP yang dijaga rahasia.","Jaga PIN dan OTP","Bagikan kode OTP","Gunakan jaringan sembarang"]
 ],
 senior:[
 ["Inflasi","Inflasi adalah kenaikan harga barang dan jasa secara umum. Akibatnya, uang yang sama bisa membeli lebih sedikit.","Daya beli uang menurun","Semua harga selalu turun","Uang bertambah otomatis"],
 ["Bunga majemuk","Bunga majemuk adalah bunga yang dihitung dari pokok dan bunga yang sudah terkumpul. Ini contoh matematika, bukan janji hasil.","Bunga ikut menghasilkan bunga","Bunga selalu tetap","Tidak ada risiko"],
 ["Paylater dan pinjol","Pinjaman dapat memiliki bunga, biaya, dan denda. Baca seluruh ketentuan dan pahami risiko sebelum mengambil keputusan.","Hitung seluruh biaya dan risiko","Lihat cicilan saja","Pinjam untuk semua keinginan"],
 ["Penipuan keuangan","Phishing dan hadiah palsu mencoba mengambil data atau uang. Jangan berikan PIN, OTP, atau kata sandi.","Jangan bagikan data rahasia","Klik semua tautan","Kirim OTP untuk hadiah"],
 ["Bank dan e-wallet","Pahami biaya, keamanan akun, dan cara menghubungi penyedia resmi. PIN dan OTP bersifat rahasia.","Jaga PIN dan OTP","Catat PIN di tempat umum","Bagikan akses"],
 ["Penghasilan pertama","Saat menerima penghasilan, catat jumlahnya dan buat rencana untuk kebutuhan, tabungan, serta tujuan.","Buat rencana dan catat","Habiskan semuanya","Ikuti investasi yang belum dipahami"]
 ]}
};
