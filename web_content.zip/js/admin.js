'use strict';
/* ============ قسم الإدارة ============ */
const ROLE_TONE = { admin: 'amber', reception: 'info', doctor: 'ok', lab: 'warn', pharmacy: '' };
const roleBadge = r => badge(ROLE_AR[r] || r, ROLE_TONE[r] || '');
const sum = (a, f) => a.reduce((s, x) => s + f(x), 0);

/* ---------- لوحة التحكم ---------- */
PAGES.dash = {
  title: 'لوحة التحكم', live: true,
  render() {
    const f = filt(FL.dash), ps = new Set();
    D.patients.filter(f).forEach(p => ps.add(p.no)); D.queue.filter(f).forEach(q => ps.add(q.patientNo)); D.visits.filter(f).forEach(v => ps.add(v.patientNo));
    const lr = D.labRequests.filter(f).length, lc = D.labRequests.filter(r => r.status === 'done' && f({ date: r.doneDate })).length;
    const dl = D.dispenses.filter(f), items = sum(dl, d => d.qty), sales = sum(dl, d => d.total);
    const waiting = D.queue.filter(q => q.date === today() && q.status === 'waiting').length;
    const A = D.activities.filter(f).sort((a, b) => b.ts - a.ts).slice(0, 50);
    const icn = { patient: ['userplus', ''], queue: ['list', ''], visit: ['stetho', 'g'], lab: ['flask', 'b'], labdone: ['check', 'g'], rx: ['file', ''], disp: ['pill', 'n'] };
    $('page').innerHTML = filterBar('dash') +
      '<div class="stats">' +
      stat('users', 'المرضى — ' + periodLabel(FL.dash), ps.size) + stat('clock', 'في انتظار الطبيب الآن', waiting, 'b') +
      stat('flask', 'طلبات المعمل', lr, 'n') + stat('check', 'فحوصات مكتملة', lc, 'g') +
      stat('pill', 'أصناف مصروفة', items) + stat('bars', 'إجمالي المبيعات', num(sales) + ' <small>' + esc(S.settings.currency) + '</small>', 'g') + '</div>' +
      '<div class="grid" style="grid-template-columns:minmax(260px,1fr) minmax(300px,1.6fr);align-items:start">' +
      '<div class="card"><div class="card-h"><h3>' + ic('wifi') + 'الأجهزة المتصلة الآن</h3>' + badge(S.devices.length, 'ok') + '</div>' +
      (S.devices.length ? S.devices.map(d => '<div class="row"><div class="av lt">' + esc(initial(d.name)) + '</div><div class="grow"><div class="t">' + esc(d.name) + '</div><div class="mut">منذ ' + hm(d.since) + '</div></div>' + roleBadge(d.role) + '</div>').join('') : empty('wifi', 'لا توجد أجهزة متصلة')) + '</div>' +
      '<div class="card"><div class="card-h"><h3>' + ic('history') + 'آخر الأنشطة</h3></div>' +
      (A.map(a => { const i = icn[a.type] || ['pulse', '']; return '<div class="row" style="padding:.55rem .8rem"><div style="width:36px;height:36px;border-radius:10px;background:var(--bg);color:var(--navy-3);display:grid;place-items:center;flex:none">' + ic(i[0], 'sm') + '</div><div class="grow">' + esc(a.text) + '</div><span class="mut num">' + hm(a.ts) + (FL.dash.mode === 'all' ? ' · ' + a.date : '') + '</span></div>'; }).join('') || empty('history', 'لا توجد أنشطة في هذه الفترة')) + '</div></div>';
  }
};

/* ---------- المستخدمون ---------- */
PAGES.users = {
  title: 'المستخدمون وبيانات الدخول', live: true,
  render() {
    $('page').innerHTML =
      '<div class="card" style="background:var(--navy);border-color:var(--navy);color:#fff"><div class="card-h" style="margin:0"><div class="av" style="background:var(--amber);color:var(--navy)">' + esc(initial(S.me.name)) + '</div><div class="grow"><div style="font-weight:700;color:#fff">حسابك: ' + esc(S.me.name) + '</div><div style="color:#AEB5D3;font-size:.88rem">اسم المستخدم: <span class="ltr">' + esc(S.me.username) + '</span> — يمكنك تغيير اسم المستخدم وكلمة المرور في أي وقت</div></div><button class="btn accent" onclick="userForm(' + S.me.id + ')">' + ic('key', 'sm') + 'تغيير بياناتي</button></div></div>' +
      pagehead('حسابات الأقسام', '<button class="btn" onclick="userForm()">' + ic('plus', 'sm') + 'مستخدم جديد</button>') +
      '<div class="alertbox info">' + ic('info') + '<div>كل مستخدم يدخل من شاشة الدخول نفسها فتفتح له واجهة قسمه تلقائياً. المدير وحده يُنشئ الحسابات ويعدّلها.</div></div>' +
      '<div class="tbl-wrap"><table class="tbl"><tr><th>الاسم</th><th>اسم المستخدم</th><th>القسم</th><th>الحالة</th><th></th></tr>' +
      S.users.map(u => '<tr><td><b>' + esc(u.name) + '</b>' + (u.id === S.me.id ? ' ' + badge('أنت', 'plain amber') : '') + '</td><td><span class="ltr">' + esc(u.username) + '</span></td><td>' + roleBadge(u.role) + '</td><td>' + (u.active ? badge('نشط', 'ok') : badge('معطّل', 'err')) + '</td><td style="text-align:end;white-space:nowrap"><button class="btn ghost sm icon" onclick="userForm(' + u.id + ')" title="تعديل" aria-label="تعديل">' + ic('edit', 'sm') + '</button> ' + (u.id === S.me.id ? '' : '<button class="btn ghost sm icon" onclick="delUser(' + u.id + ')" title="حذف" aria-label="حذف">' + ic('trash', 'sm') + '</button>') + '</td></tr>').join('') +
      '</table></div>';
  }
};
function userForm(id) {
  const u = id ? S.users.find(x => x.id === id) : { role: 'reception', active: true };
  openModal(mhead(id ? 'تعديل مستخدم' : 'مستخدم جديد') +
    '<div class="grid g2"><div class="field"><label>الاسم الظاهر *</label><input id="u_name" value="' + esc(u.name) + '" placeholder="مثال: سارة أحمد"></div>' +
    '<div class="field"><label>اسم المستخدم *</label><input id="u_user" class="ltr" style="direction:ltr;text-align:left" value="' + esc(u.username) + '" autocapitalize="none" spellcheck="false"></div>' +
    '<div class="field"><label>القسم *</label><select id="u_role">' + Object.keys(ROLE_AR).map(r => '<option value="' + r + '"' + (u.role === r ? ' selected' : '') + '>' + ROLE_AR[r] + '</option>').join('') + '</select></div>' +
    '<div class="field"><label>كلمة المرور ' + (id ? '(اتركها فارغة للإبقاء)' : '*') + '</label><input id="u_pass" type="text" class="ltr" style="direction:ltr;text-align:left" autocomplete="new-password" placeholder="' + (id ? '••••' : '') + '"></div></div>' +
    '<label class="toggle" style="margin:.2rem 0 1rem"><input type="checkbox" id="u_act"' + (u.active ? ' checked' : '') + '>الحساب نشط</label>' +
    '<div class="btns"><button class="btn" onclick="saveUser(' + (id || 0) + ')">حفظ</button><button class="btn ghost" onclick="closeModal()">إلغاء</button></div>');
}
async function saveUser(id) {
  const b = { id: id || undefined, name: $('u_name').value, username: $('u_user').value, role: $('u_role').value, password: $('u_pass').value || undefined, active: $('u_act').checked };
  const j = await safe(() => api('/api/users/save', b)); if (!j) return;
  S.users = j.users;
  if (id === S.me.id) { S.me.name = b.name.trim(); S.me.username = b.username.trim(); const m = document.querySelector('.me .mn'); if (m) m.textContent = S.me.name; }
  closeModal(); toast('تم الحفظ'); renderPage();
}
async function delUser(id) {
  const u = S.users.find(x => x.id === id);
  if (!await ask('حذف حساب «' + u.name + '» نهائياً؟', { danger: true, ok: 'حذف' })) return;
  const j = await safe(() => api('/api/users/del', { id })); if (!j) return; S.users = j.users; toast('تم الحذف'); renderPage();
}

/* ---------- الطباعة والترويسة ---------- */
let PD = null;
PAGES.print = {
  title: 'الطباعة والترويسة', live: false,
  render() {
    PD = JSON.parse(JSON.stringify(S.settings.print));
    const f = (k, l, ph, ltr) => '<div class="field"><label>' + l + '</label><input value="' + esc(PD[k]) + '" placeholder="' + (ph || '') + '" oninput="pdSet(\'' + k + '\',this.value)"' + (ltr ? ' class="ltr" style="direction:ltr;text-align:left"' : '') + '></div>';
    $('page').innerHTML =
      '<div class="grid" style="grid-template-columns:minmax(300px,1fr) minmax(320px,1.15fr);align-items:start">' +
      '<div class="card"><div class="card-h"><h3>' + ic('printer') + 'بيانات الترويسة</h3></div>' +
      '<div class="alertbox info">' + ic('info') + '<div>الاسم العربي يظهر أعلى اليمين، والشعار في المنتصف، والاسم الإنجليزي أعلى اليسار — في كل المستندات المطبوعة.</div></div>' +
      '<div class="grid g2">' + f('nameAr', 'اسم المجمع بالعربية', '') + f('nameEn', 'اسم المجمع بالإنجليزية', '', true) + f('subAr', 'سطر تحت الاسم العربي (اختياري)', 'مثال: عيادات تخصصية') + f('subEn', 'سطر تحت الاسم الإنجليزي', 'Specialist Clinics', true) + '</div>' +
      f('address', 'الموقع / العنوان', 'الخرطوم — شارع ...') +
      '<div class="grid g2">' + f('phone1', 'رقم الهاتف 1', '', true) + f('phone2', 'رقم الهاتف 2', '', true) + f('email', 'البريد الإلكتروني', '', true) + f('licence', 'رقم الترخيص (اختياري)', '') + '</div>' +
      f('footer', 'سطر أسفل المستند', '') +
      '<label class="toggle" style="margin:.3rem 0 1rem"><input type="checkbox" ' + (PD.showLogo ? 'checked' : '') + ' onchange="pdSet(\'showLogo\',this.checked)">إظهار الشعار في الترويسة</label>' +
      '<div class="lbl">الشعار</div><div class="btns" style="margin-bottom:1.1rem"><button class="btn ghost sm" onclick="$(\'pdfile\').click()">' + ic('upload', 'sm') + 'رفع شعار جديد</button><button class="btn ghost sm" onclick="pdSet(\'logo\',\'\')">استعادة الشعار الأصلي</button><input type="file" id="pdfile" accept="image/*" hidden onchange="pdLogo(this)"></div>' +
      '<div class="btns"><button class="btn" onclick="savePrint()">' + ic('check', 'sm') + 'حفظ الإعدادات</button><button class="btn ghost" onclick="pdTest()">' + ic('printer', 'sm') + 'طباعة تجريبية</button></div></div>' +
      '<div class="card"><div class="card-h"><h3>' + ic('eye') + 'معاينة مباشرة</h3></div><div class="prevw" id="lhprev"></div></div></div>';
    pdDraw();
  }
};
function pdDraw() { const e = $('lhprev'); if (e) e.innerHTML = letterhead(PD) + '<div class="pt">عنوان المستند</div><div style="height:90px;border:1px dashed #d6d9e5;border-radius:8px;display:grid;place-items:center;color:#9aa1ba;font-size:13px">محتوى المستند</div>' + (PD.footer ? '<div style="text-align:center;font-size:11.5px;color:#555;border-top:1px solid #ccc;margin-top:12px;padding-top:6px">' + esc(PD.footer) + '</div>' : ''); }
function pdSet(k, v) { PD[k] = v; pdDraw(); }
function pdLogo(inp) {
  const f = inp.files[0]; inp.value = ''; if (!f) return;
  const rd = new FileReader();
  rd.onload = () => {
    const im = new Image();
    im.onload = () => {
      const s = Math.min(1, 700 / Math.max(im.width, im.height)), c = document.createElement('canvas');
      c.width = Math.round(im.width * s); c.height = Math.round(im.height * s);
      const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(im, 0, 0, c.width, c.height);
      PD.logo = c.toDataURL('image/png'); pdDraw(); toast('تم تحديث الشعار — اضغط حفظ لتثبيته');
    };
    im.onerror = () => toast('تعذر قراءة الصورة', 'err'); im.src = rd.result;
  };
  rd.readAsDataURL(f);
}
async function savePrint() {
  const j = await safe(() => api('/api/settings', { print: PD })); if (!j) return;
  S.settings = j.settings; applyBrand(); toast('تم حفظ إعدادات الطباعة');
}
function pdTest() {
  const keep = S.settings.print; S.settings.print = PD;
  printDoc('صفحة تجريبية', '<p style="margin-top:20px">هذه معاينة للترويسة كما ستظهر في الوصفات وتقارير المعمل وبقية المستندات.</p>');
  setTimeout(() => { S.settings.print = keep; }, 400);
}

/* ---------- النظام والشبكة ---------- */
PAGES.system = {
  title: 'النظام والشبكة', live: false,
  onData(s) { if (s === 'presence') drawDevs(); },
  async render() {
    let info = null; try { info = await api('/api/info'); } catch (e) { }
    const port = info ? info.port : (location.port || 3000);
    const urls = (info ? info.ips : []).map(ip => 'http://' + ip + ':' + port);
    $('page').innerHTML =
      '<div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(320px,1fr));align-items:start">' +
      '<div class="card"><div class="card-h"><h3>' + ic('wifi') + 'عناوين الاتصال بالخادم</h3></div>' +
      '<p class="mut" style="margin-bottom:.8rem">افتح أحد هذه العناوين من أي هاتف أو حاسوب على نفس الواي فاي، أو أدخله في تطبيق الهاتف عند أول تشغيل.</p>' +
      (urls.length ? urls.map(u => '<div class="url"><code>' + esc(u) + '</code><button class="btn soft sm icon" onclick="copyText(\'' + esc(u) + '\')" aria-label="نسخ">' + ic('copy', 'sm') + '</button></div>').join('') : '<div class="alertbox">' + ic('alert') + '<div>لم يُعثر على شبكة محلية. تأكد أن هذا الجهاز متصل بالواي فاي أو الراوتر.</div></div>') +
      '<div class="alertbox info" style="margin-top:.8rem">' + ic('info') + '<div>يُفضّل تثبيت عنوان هذا الجهاز من إعدادات الراوتر (DHCP Reservation) حتى لا يتغيّر.</div></div></div>' +
      '<div class="card"><div class="card-h"><h3>' + ic('users') + 'الأجهزة المتصلة</h3></div><div id="devs"></div></div>' +
      '<div class="card"><div class="card-h"><h3>' + ic('db') + 'النسخ الاحتياطي والاسترجاع</h3></div>' +
      '<p class="mut" style="margin-bottom:1rem">يحفظ الخادم نسخة تلقائية يومية آخر 14 يوماً داخل مجلد البيانات. ويمكنك هنا تنزيل نسخة كاملة (مرضى، مستخدمون، مخزون، إعدادات) أو استرجاع نسخة سابقة على أي جهاز.</p>' +
      '<div class="btns"><button class="btn" onclick="doBackup()">' + ic('download', 'sm') + 'نسخ احتياطي Backup</button><button class="btn ghost" onclick="$(\'rfile\').click()">' + ic('upload', 'sm') + 'استرجاع Restore</button><input type="file" id="rfile" hidden accept=".db,.json" onchange="doRestore(this)"></div>' +
      (info ? '<p class="mut" style="margin-top:1rem">مجلد البيانات على الخادم:<br><span class="ltr num" style="font-size:.82rem">' + esc(info.dataDir) + '</span></p>' : '') + '</div></div>';
    drawDevs();
  }
};
function drawDevs() {
  const e = $('devs'); if (!e) return;
  e.innerHTML = S.devices.length ? S.devices.map(d => '<div class="row"><div class="av lt">' + esc(initial(d.name)) + '</div><div class="grow"><div class="t">' + esc(d.name) + '</div><div class="mut">متصل منذ ' + hm(d.since) + '</div></div>' + roleBadge(d.role) + '</div>').join('') : empty('wifi', 'لا توجد أجهزة متصلة');
}
function copyText(t) {
  const ok = () => toast('تم النسخ');
  if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(t).then(ok, () => toast('تعذر النسخ', 'err'));
  else { const a = document.createElement('textarea'); a.value = t; a.style.position = 'fixed'; a.style.opacity = 0; document.body.appendChild(a); a.select(); try { document.execCommand('copy'); ok(); } catch (e) { toast('تعذر النسخ', 'err'); } a.remove(); }
}
async function doBackup() {
  try {
    const r = await fetch(BASE + '/api/backup', { headers: { Authorization: 'Bearer ' + S.token } });
    if (!r.ok) throw new Error('فشل إنشاء النسخة');
    const blob = await r.blob(), d = new Date(nowTs()), name = 'clinic_backup_' + ymd(d) + '_' + pad(d.getHours()) + '-' + pad(d.getMinutes()) + '.db';
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 8000); toast('تم إنشاء النسخة: ' + name);
  } catch (e) { toast(e.message, 'err'); }
}
async function doRestore(inp) {
  const f = inp.files[0]; inp.value = ''; if (!f) return; let j;
  try { j = JSON.parse(await f.text()); } catch (e) { return toast('الملف غير صالح', 'err'); }
  if (j.app !== 'tasneem-clinic') return toast('هذا الملف ليس نسخة احتياطية لهذا النظام', 'err');
  if (!await ask('سيتم استبدال جميع البيانات الحالية (المرضى والمخزون والمستخدمين والإعدادات) ببيانات النسخة:\n' + f.name + '\nسيُحفظ نسخة من البيانات الحالية قبل الاستبدال.', { danger: true, ok: 'استرجاع', title: 'استرجاع نسخة احتياطية' })) return;
  const r = await safe(() => api('/api/restore', j)); if (r) toast('تم استرجاع البيانات بنجاح');
}
