import { db } from "./supabase.js";

const $ = (s, root = document) => root.querySelector(s);
const $$ = (s, root = document) => [...root.querySelectorAll(s)];
const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const money = (v) => new Intl.NumberFormat("ar-EG", { maximumFractionDigits: 2 }).format(Number(v) || 0) + " ج.م";
const fmt = (v) => new Date(v).toLocaleString("ar-EG", { dateStyle:"medium", timeStyle:"short" });
const ST = { pending:"جديد", confirmed:"مؤكد", preparing:"قيد التجهيز", ready_for_pickup:"جاهز للاستلام", completed:"تم التسليم", cancelled:"ملغي" };
const ST_ORDER = ["pending","confirmed","preparing","ready_for_pickup","completed"];
const PAY = { cash:"كاش عند الاستلام", vodafone_cash:"فودافون كاش", instapay:"InstaPay" };
const PS = { unpaid:"غير مدفوع", pending_review:"إيصال للمراجعة", paid:"مدفوع ✓", rejected:"إيصال مرفوض" };

let orders = [], products = [], workers = [], selectedOrder = null, currentView = "orders", owner = false, searchTimer = null, audioCtx = null, booting = false, uiBound = false, realtimeBound = false;

function toast(message){ const e=$("#toast"); e.textContent=message; e.classList.add("show"); setTimeout(()=>e.classList.remove("show"),2600); }
function sayForm(id,text,good=false){ const e=$(id); if(!e)return; e.textContent=text; e.className="form-message"+(good?" good":""); }
function audioUnlock(){ try{ audioCtx ||= new (window.AudioContext||window.webkitAudioContext)(); if(audioCtx.state==="suspended") audioCtx.resume(); }catch{} }
function beep(){ try{ audioUnlock(); const o=audioCtx.createOscillator(),g=audioCtx.createGain(); o.connect(g);g.connect(audioCtx.destination);o.frequency.value=780;g.gain.setValueAtTime(.14,audioCtx.currentTime);g.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+.45);o.start();o.stop(audioCtx.currentTime+.45);}catch{} }
function open(id){ const d=$(id); if(d?.showModal)d.showModal(); }
function close(id){ const d=$(id); if(d?.close)d.close(); }

async function boot(){
  if (booting) return;
  booting = true;
  try {
    const { data:{ session }, error:sessionError } = await db.auth.getSession();
    if (sessionError) throw sessionError;
    if (!session) { showLogin(); return; }

    const [{ data:isAdmin, error:adminError },{ data:isOwner, error:ownerError }] = await Promise.all([db.rpc("is_admin"), db.rpc("is_owner")]);
    if (adminError || ownerError) throw (adminError || ownerError);
    if (!isAdmin) {
      await db.auth.signOut();
      showLogin("الحساب ده مش مصرح له بدخول لوحة التحكم.");
      return;
    }

    owner = !!isOwner;
    $("#login").hidden=true;
    $("#app").hidden=false;
    $("#accountEmail").textContent=session.user.email||"حساب الإدارة";
    $("#roleBadge").textContent=owner?"المالك":"عامل";
    $("#navWorkers").hidden=!owner;
    if (!uiBound) { bindUI(); uiBound=true; }
    await refreshAll();
    if (!realtimeBound) { subscribe(); realtimeBound=true; }
  } catch (error) {
    console.error(error);
    if ($("#app").hidden) showLogin("تعذر التحقق من جلسة الدخول. أعد المحاولة."); else toast("تعذر تحديث البيانات، أعد المحاولة.");
  } finally {
    booting = false;
  }
}
function showLogin(message=""){ $("#login").hidden=false; $("#app").hidden=true; $("#loginMsg").textContent=message; }
async function refreshAll(){ const started=Date.now(); await Promise.all([loadOrders(),loadProducts(), owner?loadWorkers():Promise.resolve()]); const e=$("#syncState"); if(e) e.textContent=`● آخر مزامنة ${new Date().toLocaleTimeString("ar-EG",{hour:"2-digit",minute:"2-digit"})}`; if(Date.now()-started>1200) toast("تم تحديث لوحة الإدارة ✓"); }
async function loadOrders(){
  const { data,error }=await db.from("orders").select("*").order("created_at",{ascending:false}).limit(500); if(error){toast("تعذر تحميل الطلبات");return;} orders=data||[]; renderOrders(); renderStats(); if(selectedOrder) renderOrderDetail(selectedOrder.id); }
async function loadProducts(){ const {data,error}=await db.from("products").select("*").order("sort_order").order("created_at",{ascending:false}); if(error){toast("تعذر تحميل المنتجات");return;} products=data||[]; renderProducts(); updateProductCounts(); }
async function loadWorkers(){ const {data,error}=await db.rpc("list_admin_workers"); if(error){toast("تعذر تحميل العاملين");return;} workers=data||[]; renderWorkers(); }
async function loadReports(){
  const [w,m]=await Promise.all([db.rpc("sales_report",{p_from:new Date(Date.now()-7*86400000).toISOString()}),db.rpc("sales_report",{p_from:new Date(Date.now()-30*86400000).toISOString()})]);
  return {week:w.data||{},month:m.data||{}};
}
function renderStats(){
  const today=new Date().toDateString(); const todayOrders=orders.filter(o=>new Date(o.created_at).toDateString()===today); const openOrders=orders.filter(o=>!['completed','cancelled'].includes(o.status));
  const stats=[
    ["طلبات جديدة",orders.filter(o=>o.status==='pending').length,"🛎"],
    ["إيصالات للمراجعة",orders.filter(o=>o.payment_status==='pending_review').length,"💳"],
    ["قيد التنفيذ",openOrders.length,"⚙️"],
    ["طلبات اليوم",todayOrders.length,"📅"],
    ["مبيعات اليوم",money(todayOrders.filter(o=>o.status!=='cancelled').reduce((a,o)=>a+Number(o.total),0)),"↗"]
  ];
  $("#stats").innerHTML=stats.map(([l,v,i])=>`<div class="metric"><span>${i}</span><div><b>${v}</b><small>${l}</small></div></div>`).join("");
  loadReports().then(({week,month})=>{ $("#revenue7").textContent=money(week.revenue||0); $("#revenue30").textContent=money(month.revenue||0); $("#topProduct").textContent=month.top_products?.[0]?.name||"—"; });
}
function orderFilter(){
  const tab=$("#orderFilter").value; const q=$("#orderSearch").value.trim().toLowerCase();
  return orders.filter(o=>{ const matchesTab=tab==='all'||(tab==='open'&&!['completed','cancelled'].includes(o.status))||(tab==='pending'&&o.status==='pending')||(tab==='payment'&&o.payment_status==='pending_review')||(tab==='done'&&o.status==='completed'); const hay=`${o.id} ${o.customer_name} ${o.phone} ${o.tracking_code} ${o.notes||""}`.toLowerCase(); return matchesTab&&hay.includes(q); });
}
function renderOrders(){ const list=$("#orderList"),arr=orderFilter(); if(!arr.length){list.innerHTML='<div class="empty-state">لا توجد طلبات مطابقة.</div>';return;} list.innerHTML=arr.map(o=>`<button class="order-card ${selectedOrder?.id===o.id?'selected':''}" data-order="${o.id}"><div class="order-head"><b>#${o.id}</b><span class="status ${esc(o.status)}">${esc(ST[o.status]||o.status)}</span></div><strong>${esc(o.customer_name)}</strong><div class="order-info"><span>📱 ${esc(o.phone)}</span><span>${fmt(o.created_at)}</span></div>${o.notes?'<div class="note-flag">📝 فيه ملاحظات من العميل</div>':''}<div class="order-foot"><span>${esc(o.tracking_code)}</span><b>${money(o.total)}</b></div>${o.payment_status==='pending_review'?'<em class="alert-dot">إيصال جديد</em>':''}</button>`).join(""); }
function renderOrderDetail(id){ const o=orders.find(x=>x.id===id); if(!o){$("#orderDetail").innerHTML='<div class="empty-state">اختر طلبًا.</div>';return;} selectedOrder=o; renderOrders();
  const idx=ST_ORDER.indexOf(o.status); const next=idx>=0?(ST_ORDER[idx+1]||null):null;
  $("#orderDetail").innerHTML=`<div class="detail-title"><div><small>طلب ${esc(o.tracking_code)}</small><h2>#${o.id}</h2></div><span class="status ${esc(o.status)}">${esc(ST[o.status])}</span></div>
  <div class="customer-card"><div><span>العميل</span><b>${esc(o.customer_name)}</b></div><div><span>الموبايل</span><b dir="ltr">${esc(o.phone)}</b></div><div><span>التاريخ</span><b>${fmt(o.created_at)}</b></div><div><span>الدفع</span><b>${esc(PAY[o.payment_method]||o.payment_method)}</b></div></div>
  ${renderCustomerNotes(o)}
  <div class="detail-section"><div class="section-title"><h3>الأصناف</h3><span>${(o.items||[]).length} أصناف</span></div>${(o.items||[]).map(i=>`<div class="item-row"><div><b>${esc(i.name)}</b><small>${i.size||i.color?esc([i.size,i.color].filter(Boolean).join(' • '))+" • ":''}× ${esc(i.qty)}</small></div><b>${money(Number(i.price)*Number(i.qty))}</b></div>`).join("")}<div class="total-row"><span>الإجمالي</span><b>${money(o.total)}</b></div></div>
  <div class="detail-section"><div class="section-title"><h3>الحالة</h3><span>${esc(PS[o.payment_status]||'')}</span></div><div class="status-actions"><select id="detailStatus">${["pending","confirmed","preparing","ready_for_pickup","completed","cancelled"].map(s=>`<option value="${s}" ${s===o.status?'selected':''}>${ST[s]}</option>`).join("")}</select><button id="saveStatus" class="primary-btn">حفظ الحالة</button>${next?`<button id="nextStatus" class="outline-btn">→ ${ST[next]}</button>`:''}</div></div>
  <div class="detail-section"><div class="section-title"><h3>ملاحظات الإدارة</h3></div><textarea id="adminNotes" rows="4" placeholder="ملاحظات داخلية فقط…">${esc(o.admin_notes||'')}</textarea><button id="saveNotes" class="outline-btn full">حفظ الملاحظات</button></div>
  ${renderFiles(o)}
  <div class="detail-section"><div class="section-title"><h3>الدفع</h3><span class="pay-badge ${esc(o.payment_status)}">${esc(PS[o.payment_status]||'')}</span></div>${o.payment_method!=='cash'?`<div class="payment-review"><p>المبلغ المطلوب الآن <b>${money(o.pay_now)}</b></p><div id="receiptBox" class="receipt-box">${o.receipt_path?'<span class="muted">جارٍ تحميل الإيصال…</span>':'<p class="muted">العميل لسه مرفعش إيصال التحويل.</p>'}</div><div class="payment-actions"><button class="primary-btn" id="confirmPay">✅ تأكيد الدفع</button><button class="outline-btn" id="rejectPay">رفض الإيصال</button></div></div>`:'<p class="muted">الدفع عند الاستلام.</p>'}</div>`;
  hydrateFiles(o); const bind=(sel,fn)=>{ const el=$(sel); if(el) el.onclick=fn; }; bind("#saveStatus",saveOrderStatus); bind("#saveNotes",saveOrderNotes); bind("#confirmPay",()=>setPayment('paid')); bind("#rejectPay",()=>setPayment('rejected')); bind("#nextStatus",()=>{ $("#detailStatus").value=next; saveOrderStatus(); });
}
function renderCustomerNotes(o){
  const raw=String(o.notes||"").trim(); if(!raw) return "";
  const rows=raw.split(" • ").map(s=>s.trim()).filter(Boolean).map(p=>{
    const m=p.match(/https?:\/\/\S+/);
    if(m) return `<a class="note-line" target="_blank" rel="noopener" href="${esc(m[0])}">🗺️ فتح الموقع على الخريطة ↗</a>`;
    return `<div class="note-line">${esc(p)}</div>`;
  }).join("");
  return `<div class="detail-section customer-notes"><div class="section-title"><h3>📝 ملاحظات العميل</h3></div>${rows}</div>`;
}
function renderFiles(o){ if(!(o.design_paths||[]).length) return ''; return `<div class="detail-section"><div class="section-title"><h3>الملفات</h3></div><div id="fileLinks" class="file-links"><span class="muted">جارٍ تجهيز الروابط…</span></div></div>`; }
async function hydrateFiles(o){
  const items=[]; if(o.receipt_path) items.push({path:o.receipt_path,label:'إيصال الدفع',receipt:true}); (o.design_paths||[]).forEach((p,i)=>items.push({path:p,label:`تصميم ${i+1}`}));
  if(!items.length) return;
  const box=$("#fileLinks"), rbox=$("#receiptBox"); const nodes=[]; let receiptHtml="", firstError="";
  await Promise.all(items.map(async(x)=>{
    const {data,error}=await db.storage.from('order-files').createSignedUrl(x.path,3600);
    if(error||!data?.signedUrl){ firstError=firstError||(error?.message||'تعذر إنشاء رابط الملف'); if(x.receipt) receiptHtml=`<p class="file-error">تعذر تحميل الإيصال: ${esc(error?.message||'')}</p>`; return; }
    const url=esc(data.signedUrl); const isPdf=/\.pdf$/i.test(x.path);
    const html=isPdf?`<a class="file-link" target="_blank" rel="noopener" href="${url}">↗ ${esc(x.label)} (PDF)</a>`:`<a class="file-thumb" target="_blank" rel="noopener" href="${url}"><img src="${url}" alt="${esc(x.label)}" loading="lazy"><span>${esc(x.label)} ↗</span></a>`;
    if(x.receipt) receiptHtml=html; else nodes.push({label:x.label,html});
  }));
  if(rbox && o.receipt_path) rbox.innerHTML=receiptHtml||'<p class="file-error">تعذر تحميل الإيصال.</p>';
  if(box){ const designs=nodes.sort((p,q)=>p.label.localeCompare(q.label)).map(n=>n.html).join(''); box.innerHTML=designs||(firstError?`<span class="file-error">تعذر تحميل الملفات: ${esc(firstError)}</span>`:'<span class="muted">لا توجد ملفات تصميم.</span>'); }
}
async function saveOrderStatus(){ const id=selectedOrder.id; const status=$("#detailStatus").value; const {error}=await db.from('orders').update({status}).eq('id',id); if(error)return toast('تعذر تغيير الحالة'); toast('تم تحديث الحالة ✓'); await loadOrders(); }
async function saveOrderNotes(){ const id=selectedOrder.id; const admin_notes=$("#adminNotes").value.trim(); const {error}=await db.from('orders').update({admin_notes}).eq('id',id); if(error)return toast('تعذر حفظ الملاحظات'); toast('تم حفظ الملاحظات ✓'); await loadOrders(); }
async function setPayment(payment_status){ const id=selectedOrder.id; const {error}=await db.from('orders').update({payment_status}).eq('id',id); if(error)return toast('تعذر تحديث الدفع'); toast(payment_status==='paid'?'تم تأكيد الدفع ✓':'تم رفض الإيصال'); await loadOrders(); }
function renderProducts(){ const q=$("#productSearch").value.trim().toLowerCase(); const st=$("#productState").value; const cat=$("#productCategory")?.value||"all"; const arr=products.filter(p=>(st==='all'||(st==='active'?p.active:!p.active))&&(cat==='all'||p.category===cat)&&(`${p.name} ${p.category} ${p.id}`.toLowerCase().includes(q))); $("#productsGrid").innerHTML=arr.length?arr.map(p=>`<article class="admin-product ${p.active?'':'off'}"><div class="admin-product-image">${p.image_url?`<img src="${esc(p.image_url)}" alt="">`:`<div class="fallback-art" style="--c:${esc(p.color||'#16764b')}">ف</div>`}<span>${p.active?'ظاهر':'متوقف'}</span></div><div class="admin-product-body"><div><small>${esc(p.category)}</small><h3>${esc(p.name)}</h3></div><div class="admin-product-meta"><b>${money(p.price)}</b><code>${esc(p.id)}</code></div><p>${esc(p.description||'بدون وصف')}</p><div class="admin-actions"><button class="outline-btn" data-edit-product="${esc(p.id)}">تعديل</button><button class="outline-btn" data-toggle-product="${esc(p.id)}">${p.active?'إيقاف':'تفعيل'}</button><button class="danger-btn" data-delete-product="${esc(p.id)}">حذف</button></div></div></article>`).join(''):'<div class="empty-state">لا توجد منتجات مطابقة.</div>'; }
function updateProductCounts(){ const on=products.filter(p=>p.active).length; $("#productsCount").textContent=`${products.length} منتج • ${on} ظاهر`; const sel=$("#productCategory"); if(sel){ const current=sel.value||"all"; const cats=[...new Set(products.map(p=>String(p.category||"").trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b,"ar")); sel.innerHTML=`<option value="all">كل الأقسام (${cats.length})</option>`+cats.map(c=>`<option value="${esc(c)}">${esc(c)}</option>`).join(""); sel.value=cats.includes(current)?current:"all"; }}
function openProductForm(id=null){ const p=id?products.find(x=>String(x.id)===String(id)):null; const f=$("#productForm"); f.reset(); $("#productEditId").value=p?.id||""; $("#productTitle").textContent=p?'تعديل المنتج':'منتج جديد'; $("#pfId").value=p?.id||""; $("#pfId").readOnly=!!p; $("#pfName").value=p?.name||""; $("#pfCategory").value=p?.category||""; $("#pfPrice").value=p?.price??""; $("#pfSort").value=p?.sort_order??0; $("#pfColor").value=/^#[0-9a-f]{6}$/i.test(p?.color||'')?p.color:'#16764b'; $("#pfImageUrl").value=p?.image_url||""; $("#pfDescription").value=p?.description||""; $("#pfSizes").value=(p?.sizes||[]).join(', '); $("#pfColors").value=(p?.colors||[]).join(', '); $("#pfActive").checked=p?p.active:true; $("#pfMsg").textContent=''; open('#productDialogAdmin'); }
async function saveProduct(e){ e.preventDefault(); const id=$("#pfId").value.trim(); const isNew=!$("#productEditId").value; if(!id)return sayForm('#pfMsg','المعرّف مطلوب.'); if(!/^[A-Za-z0-9_-]+$/.test(id))return sayForm('#pfMsg','المعرّف لازم يكون إنجليزي بدون مسافات.'); const file=$("#pfImageFile").files[0]; let imageUrl=$("#pfImageUrl").value.trim(); sayForm('#pfMsg','جارٍ الحفظ…'); if(file){ if(!['image/jpeg','image/png','image/webp'].includes(file.type)||file.size>5*1024*1024)return sayForm('#pfMsg','الصورة لازم JPG/PNG/WebP وأقل من 5 ميجا.'); const path=`products/${id}-${Date.now()}.${file.type.split('/')[1]}`; const {error}=await db.storage.from('product-images').upload(path,file,{contentType:file.type,upsert:false}); if(error)return sayForm('#pfMsg','تعذر رفع الصورة.'); imageUrl=db.storage.from('product-images').getPublicUrl(path).data.publicUrl; }
  const row={name:$("#pfName").value.trim(),category:$("#pfCategory").value.trim(),price:Number($("#pfPrice").value),description:$("#pfDescription").value.trim(),color:$("#pfColor").value,sort_order:Number($("#pfSort").value)||0,image_url:imageUrl||null,sizes:splitList($("#pfSizes").value),colors:splitList($("#pfColors").value),active:$("#pfActive").checked};
  const {error}=isNew?await db.from('products').insert({id,...row}):await db.from('products').update(row).eq('id',id); if(error)return sayForm('#pfMsg',error.message); close('#productDialogAdmin'); toast('تم حفظ المنتج وتزامنه ✓'); await loadProducts(); }
function splitList(v){return String(v||'').split(',').map(x=>x.trim()).filter(Boolean);}
async function toggleProduct(id){ const p=products.find(x=>x.id===id); if(!p)return; const {error}=await db.from('products').update({active:!p.active}).eq('id',id); if(error)return toast('تعذر تحديث المنتج'); await loadProducts(); toast(p.active?'تم إيقاف المنتج':'تم تفعيل المنتج'); }
async function deleteProduct(id){ if(!confirm('حذف المنتج نهائيًا؟ يفضل إيقافه بدل الحذف.'))return; const {error}=await db.from('products').delete().eq('id',id); if(error)return toast('تعذر حذف المنتج'); await loadProducts(); toast('تم حذف المنتج'); }
function renderWorkers(){ const grid=$("#workersGrid"); if(!workers.length){ grid.innerHTML='<div class="empty-state">مفيش عاملين مضافين حاليًا.</div>'; return; } grid.innerHTML=workers.map(w=>`<article class="worker-card"><div class="worker-avatar">${esc((w.email||'؟').charAt(0).toUpperCase())}</div><div class="worker-main"><b>${esc(w.email)}</b><span>${esc(w.role==='manager'?'مدير':'عامل')} • ${w.active?'مفعّل':'موقوف'}</span><small>أضيف ${fmt(w.added_at)}</small></div><div class="admin-actions"><button class="outline-btn" data-worker-toggle="${esc(w.user_id)}">${w.active?'إيقاف':'تفعيل'}</button><button class="outline-btn" data-worker-role="${esc(w.user_id)}">${w.role==='manager'?'جعله عامل':'جعله مدير'}</button><button class="danger-btn" data-worker-remove="${esc(w.user_id)}">حذف</button></div></article>`).join(''); }
async function addWorker(){ const email=$("#workerEmail").value.trim(); const role=$("#workerRole").value; if(!email)return sayForm('#workerMsg','اكتب إيميل الحساب.'); const {error}=await db.rpc('add_admin_worker',{p_email:email,p_role:role}); if(error)return sayForm('#workerMsg',error.message.includes('user not found')?'الحساب ده مش موجود في Authentication. أنشئه أولًا.':error.message); $("#workerEmail").value=''; sayForm('#workerMsg','تمت إضافة العامل ✓',true); await loadWorkers(); }
async function workerAction(userId,action){ const w=workers.find(x=>x.user_id===userId); if(!w)return; let error=null; if(action==='toggle')({error}=await db.rpc('set_admin_worker',{p_user_id:userId,p_active:!w.active,p_role:w.role})); if(action==='role')({error}=await db.rpc('set_admin_worker',{p_user_id:userId,p_active:w.active,p_role:w.role==='manager'?'worker':'manager'})); if(action==='remove')({error}=await db.rpc('remove_admin_worker',{p_user_id:userId})); if(error)return toast(error.message); await loadWorkers(); toast('تم تحديث العامل ✓'); }
async function loadPaymentSettings(){ const {data,error}=await db.rpc('get_payment_settings'); if(error)return toast('تعذر تحميل إعدادات الدفع'); $("#payVFOn").checked=data.vodafone_enabled; $("#payVF").value=data.vodafone_number; $("#payIPOn").checked=data.instapay_enabled; $("#payIP").value=data.instapay_address; $("#payDeposit").value=data.deposit_percent; }
async function savePayment(e){ e.preventDefault(); const vf=$("#payVF").value.replace(/\s/g,''); if(vf&&!/^01[0125]\d{8}$/.test(vf))return sayForm('#payMsg','رقم فودافون كاش غير صحيح.'); const {error}=await db.rpc('save_payment_settings',{p_vodafone:vf,p_instapay:$("#payIP").value.trim(),p_deposit:Number($("#payDeposit").value)||0,p_vf_on:$("#payVFOn").checked,p_ip_on:$("#payIPOn").checked}); if(error)return sayForm('#payMsg',error.message); close('#paymentDialog'); toast('تم حفظ إعدادات الدفع ✓'); }
async function loadCoupons(){ const {data,error}=await db.from('coupons').select('*').order('created_at',{ascending:false}); const box=$("#couponsList"); if(error){box.innerHTML='<div class="empty-state">تعذر تحميل أكواد الخصم.</div>';return;} if(!data?.length){box.innerHTML='<div class="empty-state">لا توجد أكواد خصم.</div>';return;} box.innerHTML=data.map(c=>`<article class="coupon-card"><div><b dir="ltr">${esc(c.code)}</b><span class="pay-badge ${c.active?'paid':'unpaid'}">${c.active?'مفعّل':'متوقف'}</span><small>${c.discount_type==='percent'?esc(c.discount_value)+'%':esc(c.discount_value)+' ج.م'} • مستخدم ${esc(c.used_count)}${c.max_uses?'/'+esc(c.max_uses):''}</small></div><div class="admin-actions"><button class="outline-btn" data-coupon-toggle="${esc(c.code)}">${c.active?'إيقاف':'تفعيل'}</button><button class="danger-btn" data-coupon-delete="${esc(c.code)}">حذف</button></div></article>`).join(''); }
async function saveCoupon(e){ e.preventDefault(); const form=e.currentTarget; const code=$("#cpCode").value.trim().toUpperCase(); const row={discount_type:$("#cpType").value,discount_value:Number($("#cpValue").value),min_order_total:Number($("#cpMin").value)||0,max_uses:$("#cpMax").value?Number($("#cpMax").value):null,starts_at:$("#cpFrom").value?new Date($("#cpFrom").value).toISOString():null,ends_at:$("#cpTo").value?new Date($("#cpTo").value).toISOString():null,active:$("#cpActive").checked}; if(!code)return sayForm('#cpMsg','الكود مطلوب.'); const {error}=await db.from('coupons').upsert({code,...row},{onConflict:'code'}); if(error)return sayForm('#cpMsg',error.message); form.reset(); $("#cpActive").checked=true; $("#cpMsg").textContent=''; close('#couponDialog'); toast('تم حفظ كود الخصم ✓'); await loadCoupons(); }
async function toggleCoupon(code){ const {data}=await db.from('coupons').select('active').eq('code',code).maybeSingle(); if(!data)return; const {error}=await db.from('coupons').update({active:!data.active}).eq('code',code); if(error)return toast('تعذر تحديث الكود'); toast(data.active?'تم إيقاف الكود':'تم تفعيل الكود'); await loadCoupons(); }
async function deleteCoupon(code){ if(!confirm('حذف كود الخصم '+code+' نهائيًا؟'))return; const {error}=await db.from('coupons').delete().eq('code',code); if(error)return toast('تعذر حذف الكود'); toast('تم حذف الكود'); await loadCoupons(); }
async function loadNotify(){ const {data,error}=await db.rpc('get_notify_settings'); if(error)return toast('تعذر تحميل الإشعارات'); $("#notifyEnabled").checked=data.enabled; $("#notifyPhone").value=data.phone||''; $("#notifyHook").value=data.webhook_url||''; }
async function saveNotify(e){ e.preventDefault(); const {error}=await db.rpc('save_notify_settings',{p_enabled:$("#notifyEnabled").checked,p_phone:$("#notifyPhone").value.trim(),p_apikey:$("#notifyKey").value.trim(),p_webhook:$("#notifyHook").value.trim()}); if(error)return sayForm('#notifyMsg',error.message); $("#notifyKey").value=''; close('#notifyDialog'); toast('تم حفظ الإشعارات ✓'); }
async function testNotify(){ const {error}=await db.rpc('send_test_notification'); toast(error?'تعذر إرسال التجربة':'تم إرسال رسالة التجربة ✓'); }
function switchView(view){ currentView=view; $$(".view").forEach(e=>e.hidden=e.dataset.view!==view); $$("#nav button[data-view]").forEach(b=>b.classList.toggle('active',b.dataset.view===view)); const title={orders:'إدارة الطلبات',products:'كتالوج المنتجات',workers:'العاملين',settings:'إعدادات المتجر'}[view]||'لوحة التحكم'; $("#viewTitle").textContent=title; if(view==='workers')loadWorkers(); if(view==='products')loadProducts(); }
function bindUI(){
  $$("#nav button[data-view]").forEach(b=>b.onclick=()=>switchView(b.dataset.view)); $("#refreshBtn").onclick=refreshAll; $("#logoutBtn").onclick=async()=>{await db.auth.signOut();showLogin('تم تسجيل الخروج.');}; $("#soundBtn").onclick=audioUnlock;
  $("#orderSearch").oninput=()=>{clearTimeout(searchTimer);searchTimer=setTimeout(renderOrders,120)}; $("#orderFilter").onchange=()=>{ $$("#orderQuickFilters .quick-chip").forEach(b=>b.classList.toggle("active",b.dataset.orderQuick===$("#orderFilter").value)); renderOrders(); }; $$("#orderQuickFilters .quick-chip").forEach(b=>b.onclick=()=>{ $("#orderFilter").value=b.dataset.orderQuick; $$("#orderQuickFilters .quick-chip").forEach(x=>x.classList.toggle("active",x===b)); renderOrders(); }); $("#orderList").onclick=(e)=>{const b=e.target.closest('[data-order]');if(b)renderOrderDetail(Number(b.dataset.order))};
  $("#productSearch").oninput=renderProducts; $("#productState").onchange=renderProducts; $("#productCategory").onchange=renderProducts; $("#newProductBtn").onclick=()=>openProductForm(); $("#productForm").onsubmit=saveProduct; $("#closeProductAdmin").onclick=()=>close('#productDialogAdmin'); $("#cancelProductAdmin").onclick=()=>close('#productDialogAdmin'); $("#productsGrid").onclick=(e)=>{const ed=e.target.closest('[data-edit-product]'),tg=e.target.closest('[data-toggle-product]'),dl=e.target.closest('[data-delete-product]');if(ed)openProductForm(ed.dataset.editProduct);if(tg)toggleProduct(tg.dataset.toggleProduct);if(dl)deleteProduct(dl.dataset.deleteProduct)};
  $("#addWorkerBtn").onclick=addWorker; $("#workersGrid").onclick=(e)=>{const t=e.target.closest('[data-worker-toggle]'),r=e.target.closest('[data-worker-role]'),d=e.target.closest('[data-worker-remove]');if(t)workerAction(t.dataset.workerToggle,'toggle');if(r)workerAction(r.dataset.workerRole,'role');if(d)workerAction(d.dataset.workerRemove,'remove')};
  $("#paymentSettingsBtn").onclick=async()=>{await loadPaymentSettings();open('#paymentDialog')}; $("#paymentForm").onsubmit=savePayment; $("#couponBtn").onclick=async()=>{await loadCoupons();open('#couponDialog')}; $("#couponForm").onsubmit=saveCoupon; $("#couponsList").onclick=(e)=>{const t=e.target.closest('[data-coupon-toggle]'),d=e.target.closest('[data-coupon-delete]');if(t)toggleCoupon(t.dataset.couponToggle);if(d)deleteCoupon(d.dataset.couponDelete)}; $("#notifyBtn").onclick=async()=>{await loadNotify();open('#notifyDialog')}; $("#notifyForm").onsubmit=saveNotify; $("#notifyTest").onclick=testNotify;
  $$("[data-close-dialog]").forEach(b=>b.onclick=()=>close('#'+b.dataset.closeDialog));
  if(location.hash==='#products')switchView('products'); else if(location.hash==='#workers')switchView('workers'); else switchView('orders');
}
function subscribe(){ db.channel('admin-orders').on('postgres_changes',{event:'*',schema:'public',table:'orders'},async(payload)=>{const isNew=payload.eventType==='INSERT';if(isNew)beep();await loadOrders();toast(isNew?'🆕 طلب جديد':'تم تحديث الطلبات');}).subscribe(); db.channel('admin-products').on('postgres_changes',{event:'*',schema:'public',table:'products'},async()=>{await loadProducts();toast('تمت مزامنة المنتجات ✓');}).subscribe(); }
$("#loginForm").onsubmit=async(e)=>{
  e.preventDefault();
  const f=new FormData(e.currentTarget);
  const btn=e.currentTarget.querySelector('button[type="submit"]');
  if (btn) btn.disabled=true;
  $("#loginMsg").textContent='جارٍ التحقق…';
  const {error}=await db.auth.signInWithPassword({email:String(f.get('email')||'').trim(),password:String(f.get('password')||'')});
  if(error){
    $("#loginMsg").textContent='البريد الإلكتروني أو كلمة المرور غير صحيحة.';
    if (btn) btn.disabled=false;
    return;
  }
  await boot();
  if (btn) btn.disabled=false;
};

db.auth.onAuthStateChange((event)=>{
  if(event === 'SIGNED_OUT') showLogin();
  if(event === 'SIGNED_IN' && $("#app").hidden) setTimeout(()=>boot(),0);
});

document.addEventListener("keydown",(e)=>{ if(e.key==="Escape"){ $(".admin-modal[open]")?.close?.(); } if(e.key==="r" && (e.ctrlKey||e.metaKey)){ e.preventDefault(); refreshAll(); } if(e.key==="1" && (e.ctrlKey||e.metaKey)){ e.preventDefault(); switchView("orders"); } if(e.key==="2" && (e.ctrlKey||e.metaKey)){ e.preventDefault(); switchView("products"); } });
document.addEventListener("DOMContentLoaded",boot);
