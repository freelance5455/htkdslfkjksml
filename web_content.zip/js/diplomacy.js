/* diplomacy.js — Phase 5: relations, treaties (non-aggression, alliance, military access, trade, guarantee),
   call-to-arms, peace negotiations with terms, offers inbox and AI diplomacy.
   (AI never starts wars on its own yet — that comes with the full AI in Phase 8.) */
(function (G) {
  'use strict';

  const key = (a, b) => a < b ? a + '|' + b : b + '|' + a;
  G.dkey = key;

  G.TREATY = {
    nap:       { name: 'Non-aggression pact',      icon: '🕊', sym: true,  days: 365, rel: 5 },
    alliance:  { name: 'Alliance',                 icon: '🤝', sym: true,  rel: 15 },
    access:    { name: 'Military access',          icon: '🪖', sym: false, rel: 3 },
    trade:     { name: 'Trade agreement',          icon: '📦', sym: true,  rel: 5 },
    guarantee: { name: 'Guarantee of independence', icon: '🛡', sym: false, rel: 8 }
  };
  G.TREATY_TYPES = ['nap', 'alliance', 'access', 'trade', 'guarantee'];
  const DEMOCRATIC = ['Constitutional Monarchy', 'Republic', 'Parliamentary Democracy', 'Federation'];
  const MAX_ALLIES_AI = 2, MAX_ALLIES = 3, MAX_TRADE = 3;
  G.TRADE_CAP_BONUS = 80; G.TRADE_GOLD_BONUS = 3;

  const alive = () => Object.keys(G.state.countries).filter(id => !G.state.countries[id].dead);
  const cname = id => G.COUNTRIES[id].name;

  /* ---------- state ---------- */
  G.initDiplomacy = function (st, fresh) {
    st.treaties = st.treaties || [];
    st.infamy = st.infamy || {};
    st.offers = st.offers || [];
    st.dipCd = st.dipCd || {};
    st.nextTid = st.nextTid || 1;
    st.rel = st.rel || {};
    const ids = Object.keys(G.COUNTRIES);
    for (const id of ids) if (st.infamy[id] == null) st.infamy[id] = 0;
    if (fresh || !Object.keys(st.rel).length) {
      let s = 7771; const rnd = () => { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; return s / 4294967296; };
      const border = {};
      G.provinces.forEach((p, i) => {
        if (p.sea) return;
        p.adj.forEach(n => { const q = G.provinces[n]; if (!q.sea && q.owner !== p.owner) border[key(p.owner, q.owner)] = true; });
      });
      for (let i = 0; i < ids.length; i++) for (let j = i + 1; j < ids.length; j++) {
        const a = ids[i], b = ids[j], ga = G.COUNTRIES[a].gov, gb = G.COUNTRIES[b].gov;
        const da = DEMOCRATIC.includes(ga), db = DEMOCRATIC.includes(gb);
        let r = (da === db ? 10 : -10) + (ga === 'Fascist State' && db ? -10 : 0) + (gb === 'Fascist State' && da ? -10 : 0);
        if (border[key(a, b)]) r -= 8;
        r += Math.round((rnd() - 0.5) * 30);
        st.rel[key(a, b)] = Math.max(-100, Math.min(100, r));
      }
      // scenario-specific historical relations
      ((G.scenario && G.scenario.relations) || []).forEach(x => {
        if (G.COUNTRIES[x[0]] && G.COUNTRIES[x[1]]) st.rel[key(x[0], x[1])] = Math.max(-100, Math.min(100, (st.rel[key(x[0], x[1])] || 0) + x[2]));
      });
    }
  };

  G.relation = function (a, b) { return a === b ? 100 : (G.state.rel[key(a, b)] || 0); };
  G.addRelation = function (a, b, d) {
    const k = key(a, b);
    G.state.rel[k] = Math.max(-100, Math.min(100, (G.state.rel[k] || 0) + d));
  };

  /* ---------- treaties ---------- */
  G.hasTreaty = function (type, a, b) {
    const sym = G.TREATY[type].sym;
    return G.state.treaties.find(t => t.type === type && (sym ? ((t.a === a && t.b === b) || (t.a === b && t.b === a)) : (t.a === a && t.b === b))) || null;
  };
  G.treatiesOf = function (id) { return G.state.treaties.filter(t => t.a === id || t.b === id); };
  G.allied = function (a, b) { return a !== b && !!G.hasTreaty('alliance', a, b); };
  G.alliesOf = function (id) { return G.state.treaties.filter(t => t.type === 'alliance' && (t.a === id || t.b === id)).map(t => t.a === id ? t.b : t.a); };
  G.tradePartners = function (id) { return (G.state.treaties || []).filter(t => t.type === 'trade' && (t.a === id || t.b === id)).length; };
  // May `visitor` stand in provinces owned by `owner`?
  G.hasAccess = function (owner, visitor) { return G.allied(owner, visitor) || !!G.hasTreaty('access', owner, visitor); };

  G.signTreaty = function (type, a, b) {
    const st = G.state, T = G.TREATY[type];
    const t = { id: st.nextTid++, type: type, a: a, b: b, start: st.day, end: T.days ? st.day + T.days : null };
    st.treaties.push(t);
    G.addRelation(a, b, T.rel);
    if (type === 'alliance') st.treaties = st.treaties.filter(x => !(x.type === 'guarantee' && ((x.a === a && x.b === b) || (x.a === b && x.b === a))));
    G.logMsg(T.icon + ' ' + T.name + ': ' + cname(a) + (T.sym ? ' & ' : ' → ') + cname(b));
    if (type === 'trade' || type === 'alliance') G.refreshBudget && G.refreshBudget();
    G.onTreatyChange && G.onTreatyChange(t, true);
    return t;
  };

  // reason: 'cancel' (by one side, may cost reputation), 'war', 'expire', 'lapse'
  G.cancelTreaty = function (id, by, reason) {
    const st = G.state, i = st.treaties.findIndex(t => t.id === id); if (i < 0) return { ok: false, msg: 'No such treaty' };
    const t = st.treaties[i], T = G.TREATY[t.type];
    st.treaties.splice(i, 1);
    const other = t.a === by ? t.b : t.a;
    if (reason === 'cancel' && by && (t.type === 'nap' || t.type === 'alliance')) {
      st.infamy[by] = Math.min(100, (st.infamy[by] || 0) + 8);
      G.addRelation(by, other, -15);
    }
    G.logMsg(T.icon + ' ' + T.name + ' between ' + cname(t.a) + ' and ' + cname(t.b) + (reason === 'expire' ? ' expired' : reason === 'lapse' ? ' lapsed' : reason === 'war' ? ' ended by war' : ' cancelled by ' + cname(by)));
    if (t.type === 'access' || t.type === 'alliance') G.expelForeignArmies();
    G.refreshBudget && G.refreshBudget();
    G.onTreatyChange && G.onTreatyChange(t, false);
    return { ok: true };
  };

  /* ---------- opinion and proposals ---------- */
  function strength(id) {
    return G.state.armies.filter(a => a.owner === id).reduce((s, a) => s + G.armySummary(a).men, 0) + G.state.countries[id].provCount * 400;
  }
  function sharedEnemy(a, b) { const wa = G.warsOf(a); return G.warsOf(b).some(x => wa.includes(x)); }
  function neighbours(a, b) {
    return G.provinces.some(p => !p.sea && G.state.owners[p.id] === a && p.adj.some(n => G.state.owners[n] === b));
  }

  // How `judge` sees `other` (positive = friendly), with a human-readable breakdown.
  G.opinion = function (judge, other) {
    const st = G.state, parts = [];
    const rel = G.relation(judge, other); parts.push(['Relations', rel]);
    const inf = Math.round(-0.4 * (st.infamy[other] || 0)); if (inf) parts.push(['Reputation (aggressor)', inf]);
    if (sharedEnemy(judge, other)) parts.push(['Common enemy', 15]);
    const mutualAllies = G.alliesOf(judge).filter(x => G.allied(x, other)).length; if (mutualAllies) parts.push(['Mutual allies', 8 * mutualAllies]);
    if (G.hasTreaty('guarantee', other, judge)) parts.push(['They guarantee us', 8]);
    return { score: parts.reduce((s, p) => s + p[1], 0), parts: parts };
  };

  const NEED = { nap: 0, alliance: 35, access: 15, trade: -5, guarantee: -20 };

  // Would `to` accept `type` proposed by `from`?  (For 'guarantee', `from` guarantees `to`.)
  G.diplomacyEval = function (type, from, to) {
    const st = G.state;
    if (from === to) return { ok: false, msg: 'Invalid' };
    if (G.isDead(from) || G.isDead(to)) return { ok: false, msg: 'That nation no longer exists' };
    if (G.atWar(from, to)) return { ok: false, msg: 'At war' };
    if (G.hasTreaty(type, from, to)) return { ok: false, msg: 'Already in force' };
    if (type === 'access' && G.allied(from, to)) return { ok: false, msg: 'Allies already share access' };
    if (type === 'guarantee' && G.allied(from, to)) return { ok: false, msg: 'Allies already defend each other' };
    if (type === 'alliance') {
      const cap = to === st.player ? MAX_ALLIES : MAX_ALLIES_AI;
      if (G.alliesOf(to).length >= cap || G.alliesOf(from).length >= (from === st.player ? MAX_ALLIES : MAX_ALLIES_AI)) return { ok: false, msg: 'Too many alliances' };
    }
    if (type === 'trade' && (G.tradePartners(from) >= MAX_TRADE || G.tradePartners(to) >= MAX_TRADE)) return { ok: false, msg: 'Trade agreement limit reached (' + MAX_TRADE + ')' };
    const cd = st.dipCd['p|' + type + '|' + from + '|' + to] || 0;
    if (cd > st.day) return { ok: false, msg: 'They recently refused — try again in ' + (cd - st.day) + ' days' };
    const op = G.opinion(to, from), parts = op.parts.slice();
    if (type === 'nap' && neighbours(from, to)) parts.push(['Shared border (security)', 8]);
    if (type === 'nap' && strength(from) > 1.5 * strength(to)) parts.push(['They fear you', 6]);
    if (type === 'alliance' && G.hasTreaty('nap', from, to)) parts.push(['Existing pact', 8]);
    if (type === 'alliance' && G.warsOf(to).length) parts.push(['Needs support at war', 10]);
    if (type === 'access' && G.hasTreaty('nap', from, to)) parts.push(['Existing pact', 5]);
    if (type === 'trade') parts.push(['Mutual profit', 10]);
    if (type === 'guarantee') parts.push(['Protection offered', 15]);
    const score = parts.reduce((s, p) => s + p[1], 0), need = NEED[type];
    return { ok: score >= need, score: score, need: need, parts: parts, msg: score >= need ? '' : cname(to) + ' declines (' + Math.round(score) + ' / ' + need + ' needed)' };
  };

  G.propose = function (type, from, to) {
    const st = G.state, ev = G.diplomacyEval(type, from, to);
    if (ev.score == null) return ev;          // hard refusal
    if (!ev.ok) { st.dipCd['p|' + type + '|' + from + '|' + to] = st.day + 15; return ev; }
    G.signTreaty(type, from, to);
    return { ok: true, score: ev.score, need: ev.need, parts: ev.parts, msg: '' };
  };

  /* ---------- relation actions ---------- */
  G.IMPROVE_COST = 30;
  G.improveRelations = function (from, to) {
    const st = G.state, c = st.countries[from], k = 'imp|' + from + '|' + to;
    if (G.atWar(from, to)) return { ok: false, msg: 'At war' };
    if ((st.dipCd[k] || 0) > st.day) return { ok: false, msg: 'Wait ' + (st.dipCd[k] - st.day) + ' more days' };
    if (c.treasury < G.IMPROVE_COST) return { ok: false, msg: 'Not enough gold' };
    c.treasury -= G.IMPROVE_COST; st.dipCd[k] = st.day + 20; G.addRelation(from, to, 8);
    return { ok: true };
  };
  G.sendGift = function (from, to, gold) {
    const st = G.state, c = st.countries[from];
    if (G.atWar(from, to)) return { ok: false, msg: 'At war' };
    if (c.treasury < gold) return { ok: false, msg: 'Not enough gold' };
    c.treasury -= gold; st.countries[to].treasury += gold; G.addRelation(from, to, Math.min(25, Math.round(gold / 20)));
    return { ok: true };
  };

  /* ---------- war hooks (called from war.js) ---------- */
  G.diplomacyWarCheck = function (a, b, opts) {
    if (opts && opts.call) return { ok: true };
    if (G.allied(a, b)) return { ok: false, msg: 'You are allied with ' + cname(b) + ' — cancel the alliance first (Diplomacy)' };
    const nap = G.hasTreaty('nap', a, b);
    if (nap) return { ok: false, msg: 'Non-aggression pact with ' + cname(b) + ' — cancel it first (costs reputation)' };
    return { ok: true };
  };

  G.afterWarDeclared = function (a, b, opts) {
    const st = G.state, call = !!(opts && opts.call);
    // war ends trade / access / pacts / guarantees between the belligerents
    st.treaties.filter(t => (t.a === a && t.b === b) || (t.a === b && t.b === a)).forEach(t => G.cancelTreaty(t.id, null, 'war'));
    G.addRelation(a, b, -30);
    if (!call) {
      st.infamy[a] = Math.min(100, (st.infamy[a] || 0) + 15);
      G.alliesOf(b).forEach(x => G.addRelation(a, x, -12));
    }
    G.expelForeignArmies();
    // defenders' allies and guarantors are called to arms
    const defenders = G.alliesOf(b).concat(st.treaties.filter(t => t.type === 'guarantee' && t.b === b).map(t => t.a));
    defenders.forEach(x => {
      if (x === a || G.isDead(x) || G.atWar(x, a) || G.allied(x, a)) return;
      if (x === st.player) G.toast && G.toast('🛡 Your partner ' + cname(b) + ' was attacked — you are at war with ' + cname(a));
      G.declareWar(x, a, { call: true });
      G.logMsg(cname(x) + ' honours its pledge to ' + cname(b));
    });
    // the attacker's allies may join (AI: usually; the player gets a call to arms)
    G.alliesOf(a).forEach(y => {
      if (y === b || G.isDead(y) || G.atWar(y, b) || G.allied(y, b) || G.hasTreaty('nap', y, b)) return;
      if (y === st.player) {
        if (!st.offers.some(o => o.type === 'join' && o.from === a && o.target === b)) {
          st.offers.push({ id: st.nextTid++, type: 'join', from: a, to: y, target: b, expires: st.day + 15 });
          G.toast && G.toast('📯 ' + cname(a) + ' calls you to arms against ' + cname(b) + ' (Diplomacy)');
        }
      } else if (G.rand() < 0.7) { G.declareWar(y, b, { call: true }); G.logMsg(cname(y) + ' joins its ally ' + cname(a)); }
    });
  };

  /* ---------- peace negotiations ---------- */
  function wsKey(a, b) { return key(a, b); }
  function menOf(id) { return G.state.armies.filter(a => a.owner === id).reduce((s, a) => s + G.armySummary(a).men, 0); }

  // War score from `a`'s point of view against `b`, -100..100.
  G.warScore = function (a, b) {
    const st = G.state, w = st.wars[wsKey(a, b)]; if (!w) return 0;
    let s = 0;
    const at = {}; for (const x of st.armies) { const m = at[x.prov] || (at[x.prov] = {}); m[x.owner] = true; }
    G.provinces.forEach(p => {
      if (p.sea) return;
      const o = st.owners[p.id], h = at[p.id] || {};
      const cap = (o && G.COUNTRIES[o].capitalId === p.id) ? 2 : 1;
      if (o === b && ((h[a] && !h[b]) || (st.occ[p.id] && st.occ[p.id].by === a))) s += 10 * cap;
      if (o === a && ((h[b] && !h[a]) || (st.occ[p.id] && st.occ[p.id].by === b))) s -= 10 * cap;
    });
    s += 8 * ((w.provs[b] - st.countries[b].provCount) - (w.provs[a] - st.countries[a].provCount));
    const ma = menOf(a), mb = menOf(b);
    s += 30 * (ma - mb) / Math.max(1, ma + mb);
    return Math.max(-100, Math.min(100, Math.round(s)));
  };
  G.exhaustion = function (a, b) { const w = G.state.wars[wsKey(a, b)]; return w ? Math.min(20, Math.round((G.state.day - w.start) / 9)) : 0; };

  G.provPeaceCost = function (prov) {
    const p = G.provinces[prov], o = G.state.owners[prov];
    return 12 + (p.pop > 60000 ? 4 : 0) + (G.COUNTRIES[o].capitalId === prov ? 23 : 0);
  };

  // terms: { demand: [prov ids owned by other], concede: [prov ids owned by proposer], indemnity: gold paid by other (negative = proposer pays) }
  G.peaceEval = function (proposer, other, terms) {
    const st = G.state, parts = [];
    const score = G.warScore(proposer, other), exh = G.exhaustion(proposer, other);
    let cost = 0;
    (terms.demand || []).forEach(p => { cost += G.provPeaceCost(p); });
    (terms.concede || []).forEach(p => { cost -= 0.8 * G.provPeaceCost(p); });
    const ind = terms.indemnity || 0; cost += ind / 25;
    parts.push(['War score', score], ['War weariness', exh], ['Price of terms', -Math.round(cost)]);
    const total = score + exh + 5 - cost; parts.push(['Base willingness', 5]);
    let ok = total >= 0, msg = ok ? '' : cname(other) + ' rejects these terms';
    const w0 = st.wars[wsKey(proposer, other)];
    if (w0 && st.day - w0.start < 14) { ok = false; msg = 'Too early — the war must last at least 14 days (' + (14 - (st.day - w0.start)) + ' left)'; }
    if ((terms.demand || []).length && st.countries[other].provCount - terms.demand.length < 1) { ok = false; msg = 'Cannot take their last province'; }
    if (ind > 0 && st.countries[other].treasury < ind) { ok = false; msg = cname(other) + " can't pay that much"; }
    if (ind < 0 && st.countries[proposer].treasury < -ind) { ok = false; msg = 'You lack the gold'; }
    return { ok: ok, total: total, parts: parts, msg: msg, score: score };
  };

  G.makePeace = function (proposer, other, terms, truceDays) {
    const st = G.state; terms = terms || {};
    if (!G.atWar(proposer, other)) return { ok: false, msg: 'Not at war' };
    const ev = G.peaceEval(proposer, other, terms); if (!ev.ok) return ev;
    const ind = terms.indemnity || 0;
    if (ind > 0) { st.countries[other].treasury -= ind; st.countries[proposer].treasury += ind; }
    else if (ind < 0) { st.countries[proposer].treasury += ind; st.countries[other].treasury -= ind; }
    G.endWar(proposer, other, truceDays || ((terms.demand || terms.concede || []).length || ind ? 120 : 60));
    (terms.demand || []).forEach(p => { if (st.owners[p] === other) G.transferProvince(p, proposer); });
    (terms.concede || []).forEach(p => { if (st.owners[p] === proposer) G.transferProvince(p, other); });
    G.addRelation(proposer, other, 6);
    G.expelForeignArmies();
    return { ok: true, ev: ev };
  };

  /* ---------- offers inbox (AI → player) ---------- */
  G.pendingOffers = function () { return G.state.offers.filter(o => o.to === G.state.player); };
  G.acceptOffer = function (id) {
    const st = G.state, i = st.offers.findIndex(o => o.id === id); if (i < 0) return { ok: false, msg: 'Offer expired' };
    const o = st.offers[i]; st.offers.splice(i, 1);
    if (o.type === 'join') {
      if (G.isDead(o.target) || G.atWar(o.to, o.target)) return { ok: false, msg: 'No longer relevant' };
      const r = G.declareWar(o.to, o.target, { call: true });
      return r.ok ? { ok: true, msg: 'You joined the war against ' + cname(o.target) } : r;
    }
    if (o.type === 'peace') {
      if (!G.atWar(o.to, o.from)) return { ok: false, msg: 'No longer at war' };
      const t = o.terms || {};
      // the offering AI's terms are binding; apply directly
      const ind = t.indemnity || 0;
      if (ind > 0) { const pay = Math.min(ind, st.countries[o.to].treasury); st.countries[o.to].treasury -= pay; st.countries[o.from].treasury += pay; }
      if (ind < 0) { const pay = Math.min(-ind, st.countries[o.from].treasury); st.countries[o.from].treasury -= pay; st.countries[o.to].treasury += pay; }
      G.endWar(o.from, o.to, 120);
      (t.demand || []).forEach(p => { if (st.owners[p] === o.to) G.transferProvince(p, o.from); });
      (t.concede || []).forEach(p => { if (st.owners[p] === o.from) G.transferProvince(p, o.to); });
      G.expelForeignArmies();
      return { ok: true, msg: 'Peace with ' + cname(o.from) };
    }
    const ev = G.diplomacyEval(o.type, o.from, o.to);
    if (ev.score == null) return ev;
    G.signTreaty(o.type, o.from, o.to);
    return { ok: true, msg: G.TREATY[o.type].name + ' signed with ' + cname(o.from) };
  };
  G.declineOffer = function (id) {
    const st = G.state, i = st.offers.findIndex(o => o.id === id); if (i < 0) return;
    const o = st.offers[i]; st.offers.splice(i, 1);
    if (o.type !== 'join' && o.type !== 'peace') G.addRelation(o.from, o.to, -1);
  };

  /* ---------- AI diplomacy ---------- */
  function aiOfferTreaties(day) {
    const st = G.state, me = st.player; if (!me || st.countries[me].dead) return;
    if (st.offers.filter(o => o.to === me).length >= 4) return;
    for (const c of alive()) {
      if (c === me || G.atWar(c, me)) continue;
      if (G.rand() > 0.35) continue;
      for (const type of ['alliance', 'trade', 'nap']) {
        if (st.offers.some(o => o.from === c && o.type === type)) continue;
        const ev = G.diplomacyEval(type, me, c);          // would c accept it? then c is willing to offer it
        if (ev.score == null || !ev.ok || ev.score < NEED[type] + 8) continue;
        st.offers.push({ id: st.nextTid++, type: type, from: c, to: me, expires: day + 20 });
        G.toast && G.toast('📨 ' + cname(c) + ' proposes: ' + G.TREATY[type].name);
        G.onOffer && G.onOffer();
        return;
      }
    }
  }

  function aiTreatiesBetweenAIs() {
    const st = G.state, ais = alive().filter(c => c !== st.player);
    for (const c of ais) {
      if (G.rand() > 0.3) continue;
      const d = ais[Math.floor(G.rand() * ais.length)];
      if (d === c) continue;
      for (const type of ['alliance', 'trade', 'nap']) {
        const e1 = G.diplomacyEval(type, c, d), e2 = G.diplomacyEval(type, d, c);
        if (e1.score != null && e2.score != null && e1.ok && e2.ok) { G.signTreaty(type, c, d); break; }
      }
    }
  }

  function aiPeaceOffers() {
    const st = G.state, me = st.player;
    for (const k in st.wars) {
      const w = st.wars[k], a = w.a, b = w.b, len = st.day - w.start;
      const sa = G.warScore(a, b);
      if (a !== me && b !== me) {                       // AI vs AI: end stalled or decided wars
        if (len < 45) continue;
        const win = sa >= 25 ? a : sa <= -25 ? b : null, lose = win === a ? b : a;
        if (win) {
          const dem = G.provinces.filter(p => !p.sea && st.owners[p.id] === lose && G.armiesAt(p.id).some(x => x.owner === win)).map(p => p.id).slice(0, 2);
          const terms = { demand: dem };
          if (G.peaceEval(win, lose, terms).ok) { G.makePeace(win, lose, terms); continue; }
        }
        if (len > 100 || Math.abs(sa) < 25 && len > 70) G.makePeace(a, b, {}, 90);
        continue;
      }
      const ai = a === me ? b : a, sAI = a === me ? -sa : sa;
      if (st.offers.some(o => o.type === 'peace' && o.from === ai)) continue;
      if ((st.dipCd['peace|' + ai] || 0) > st.day) continue;
      let terms = null;
      if (sAI >= 30 && len > 60) {
        const dem = G.provinces.filter(p => !p.sea && st.owners[p.id] === me && G.armiesAt(p.id).some(x => x.owner === ai)).map(p => p.id).slice(0, 2);
        terms = { demand: dem.length ? dem : [], indemnity: dem.length ? 0 : 100 };
      } else if (sAI <= -30 && len > 45) terms = {};
      else if (len > 120 && Math.abs(sAI) < 30) terms = {};
      if (terms) {
        st.offers.push({ id: st.nextTid++, type: 'peace', from: ai, to: me, terms: terms, expires: st.day + 20 });
        st.dipCd['peace|' + ai] = st.day + 30;
        G.toast && G.toast('🕊 ' + cname(ai) + ' offers peace terms (Diplomacy)');
        G.onOffer && G.onOffer();
      }
    }
  }

  /* ---------- daily / monthly ---------- */
  G.diplomacyDay = function () {
    const st = G.state;
    // offers expire
    st.offers = st.offers.filter(o => o.expires > st.day && !G.isDead(o.from));
    if (st.day % 5 === 2) aiPeaceOffers();
    // pacts expire
    st.treaties.filter(t => t.end != null && t.end <= st.day).forEach(t => G.cancelTreaty(t.id, null, 'expire'));
    if (st.day % 30 === 12) { aiOfferTreaties(st.day); aiTreatiesBetweenAIs(); }
  };

  G.diplomacyMonth = function () {
    const st = G.state, ids = Object.keys(G.COUNTRIES);
    for (let i = 0; i < ids.length; i++) for (let j = i + 1; j < ids.length; j++) {
      const a = ids[i], b = ids[j]; if (G.isDead(a) || G.isDead(b)) continue;
      let d = 0; const r = G.relation(a, b);
      if (G.atWar(a, b)) d = -2;
      else {
        d += r > 0 ? -1 : r < 0 ? 1 : 0;                 // drift toward neutral
        if (G.hasTreaty('nap', a, b)) d += 0.5;
        if (G.allied(a, b)) d += 1.5;
        if (G.hasTreaty('trade', a, b)) d += 1;
        if (sharedEnemy(a, b)) d += 1;
      }
      if (d) G.addRelation(a, b, d);
    }
    for (const id of ids) st.infamy[id] = Math.max(0, (st.infamy[id] || 0) - 3);
    // AI partners that fall out lapse their agreements
    st.treaties.filter(t => ['alliance', 'nap', 'trade'].includes(t.type)).forEach(t => {
      const lim = t.type === 'alliance' ? -10 : -35;
      if (G.relation(t.a, t.b) < lim) {
        const by = t.a !== st.player ? t.a : t.b;
        if (t.a !== st.player || t.b !== st.player) G.cancelTreaty(t.id, null, 'lapse');
      }
    });
  };

  // Elimination: strip treaties and offers of a dead nation.
  G.diplomacyPurge = function (id) {
    const st = G.state;
    st.treaties.filter(t => t.a === id || t.b === id).forEach(t => G.cancelTreaty(t.id, null, 'lapse'));
    st.offers = st.offers.filter(o => o.from !== id && o.to !== id && o.target !== id);
  };
})(window.EMP = window.EMP || {});
