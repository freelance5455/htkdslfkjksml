/* =========================
   音效
========================= */

function playSound(type){
  try{
    const AC=window.AudioContext||window.webkitAudioContext;
    if(!AC)return;

    if(!audioCtx)audioCtx=new AC();
    if(audioCtx.state==='suspended')audioCtx.resume();

    const now=audioCtx.currentTime;

    function tone(freq,duration,wave='sine',volume=.12,endFreq=null,delay=0){
      const osc=audioCtx.createOscillator();
      const gain=audioCtx.createGain();

      osc.type=wave;
      osc.frequency.setValueAtTime(Math.max(1,freq),now+delay);

      if(endFreq!==null){
        osc.frequency.exponentialRampToValueAtTime(
          Math.max(1,endFreq),
          now+delay+duration
        );
      }

      gain.gain.setValueAtTime(.001,now+delay);
      gain.gain.exponentialRampToValueAtTime(
        Math.max(.001,volume),
        now+delay+.015
      );
      gain.gain.exponentialRampToValueAtTime(
        .001,
        now+delay+duration
      );

      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start(now+delay);
      osc.stop(now+delay+duration+.03);
    }

    switch(type){
      case'hammer':
        tone(520,.12,'square',.1,240);
        tone(170,.1,'triangle',.1,90,.08);
        break;
      case'shield':
        tone(330,.18,'sine',.08,660);
        tone(660,.25,'sine',.07,880,.1);
        break;
      case'rocket':
        tone(250,.42,'sawtooth',.09,75);
        tone(520,.22,'triangle',.06,160,.08);
        break;
      case'explosion':
        tone(100,.24,'sawtooth',.13,38);
        tone(65,.18,'triangle',.12,30,.05);
        break;
      case'cake':
        tone(520,.12,'sine',.09,650);
        tone(660,.12,'sine',.09,780,.1);
        tone(790,.18,'sine',.08,990,.2);
        break;
      case'flowers':
        tone(523,.13,'sine',.08,659);
        tone(659,.13,'sine',.08,784,.12);
        tone(784,.2,'sine',.08,1047,.24);
        break;
      case'punch':
      case'counter':
        tone(190,.12,'square',.1,70);
        tone(620,.12,'sawtooth',.09,160,.1);
        break;
      case'duck':
        tone(300,.16,'square',.08,180);
        tone(210,.12,'triangle',.08,110,.1);
        break;
      case'stun':
        tone(700,.12,'sine',.09,1000);
        tone(1000,.12,'sine',.08,650,.12);
        tone(650,.15,'sine',.07,420,.24);
        break;
      case'sword':
        tone(850,.12,'sawtooth',.08,300);
        tone(440,.18,'triangle',.08,880,.08);
        break;
      case'curse':
        tone(240,.22,'sawtooth',.08,120);
        tone(420,.25,'triangle',.07,180,.12);
        break;
    }
  }catch(e){}
}

/* =========================
   通用战斗辅助函数
========================= */

function log(message,type='system'){
  const el=document.createElement('div');
  el.className='entry '+type;
  el.textContent=message;
  $('logList').prepend(el);
}

function alive(arr){
  return arr.filter(unit=>unit.hp>0);
}

function getUnit(id){
  return s?[...s.allies,...s.enemies].find(unit=>unit.id===id):null;
}

function bar(unit){
  const pct=Math.max(0,Math.min(100,unit.hp/unit.max*100));

  return `
    <div class="hp-row">
      <span>HP</span>
      <strong>${unit.hp} / ${unit.max}</strong>
    </div>
    <div class="bar">
      <div class="fill" style="width:${pct}%"></div>
    </div>
  `;
}
