/* OPERATION: DISCIPLINE — gamificação: XP, níveis, patentes, conquistas, desafios semanais, histórico de progressão. */
(function(){'use strict';
var OD=globalThis.OD,U=OD.U;
var B={S:10,M:20,H:35,C:50},MAIN_XP=30,PERF_XP=50,CH_XP=100,MAX_LEVEL=100;
var xpOf=function(df,main){return B[df]+(main?MAIN_XP:0)};
/* XP acumulado necessário para ALCANÇAR o nível L. Avançar do nível L exige 100+25(L-1). */
var thr=function(L){return 100*(L-1)+25*(L-1)*(L-2)/2};
var need=function(L){return 100+25*(L-1)};
var lvl=function(x){var L=1;while(L<MAX_LEVEL&&x>=thr(L+1))L++;return L};
var RANKS=[['Recruta',1,5],['Soldado',6,10],['Cabo',11,20],['Sargento',21,35],['Oficial',36,50],['Comandante',51,75],['Elite',76,99],['Lenda',100,100]];
var rank=function(L){for(var i=0;i<RANKS.length;i++)if(L<=RANKS[i][2])return RANKS[i][0];return 'Lenda'};
/* [id, nome, descrição, fato, alvo] */
var ACH=[['FIRST','Primeiro Passo','Conclua 1 missão','mis',1],['M10','Operador','Conclua 10 missões','mis',10],['M50','Veterano','Conclua 50 missões','mis',50],['M100','Centurião','Conclua 100 missões','mis',100],['X1K','Mil de XP','Acumule 1.000 XP','xp',1000],['X10K','Dez Mil','Acumule 10.000 XP','xp',10000],['S7','Semana de Ferro','Sequência de 7 dias','st',7],['S30','Mês Implacável','Sequência de 30 dias','st',30],['L10','Cabo','Alcance o nível 10','lv',10],['L50','Oficial','Alcance o nível 50','lv',50],['P1','Dia Perfeito','Encerre 1 dia perfeito','pf',1],['P10','Dez Perfeitos','Encerre 10 dias perfeitos','pf',10],['W1','Desafio Semanal','Conclua um desafio semanal','wk',1]];
/* Desafios semanais (seg–dom). Cada um concede 100 XP.
   O e E: baseados em missões concluídas (irreversíveis) → recompensa única, nunca estornada.
   D: baseado em dias perfeitos ENCERRADOS → como o dia pode ser reaberto, a recompensa é sincronizada (estornada se deixar de valer). */
var CH=[
 {k:'O',cat:'Operacional',title:'Operação semanal',desc:'Conclua 15 missões na semana',target:15,pfx:'W',rev:false},
 {k:'D',cat:'Disciplina',title:'Semana disciplinada',desc:'Encerre 3 dias perfeitos na semana',target:3,pfx:'WD',rev:true},
 {k:'E',cat:'Especial',title:'Alto impacto',desc:'Conclua 3 missões Difíceis ou Críticas na semana',target:3,pfx:'WE',rev:false}];
var weekDays=function(ws){var a=[];for(var i=0;i<7;i++)a.push(U.add(ws,i));return a};
var chValue=function(S,k,ws){var we=U.add(ws,6);
 if(k==='D')return Object.keys(S.d).filter(function(d){return d>=ws&&d<=we&&S.d[d]==='PERFECT'}).length;
 return S.m.filter(function(m){return m.s==='C'&&m.date>=ws&&m.date<=we&&(k==='O'||m.df==='H'||m.df==='C')}).length};
var chRef=function(c,ws){return c.pfx+':'+ws};
var chPaid=function(S,c,ws){var p=c.pfx+':'+ws;return S.l.filter(function(x){return c.rev?x.r.indexOf(p+':')===0:x.r===p}).reduce(function(a,x){return a+x.a},0)};
var challenges=function(S,ws){return CH.map(function(c){var v=chValue(S,c.k,ws);return{k:c.k,cat:c.cat,title:c.title,desc:c.desc,target:c.target,value:v,done:v>=c.target,paid:chPaid(S,c,ws)>0,xp:CH_XP}})};
var total=function(S){return Math.max(0,S.l.reduce(function(a,x){return a+x.a},0))};
/* Histórico de progressão derivado do extrato de XP (fonte da verdade). */
var progression=function(S){var l=S.l.map(function(x,i){return[x,i]}).sort(function(a,b){return a[0].t-b[0].t||a[1]-b[1]}),cum=0,L=1,out=[];
 l.forEach(function(p){cum+=p[0].a;var n=lvl(Math.max(0,cum));for(;L<n;){L++;out.push({level:L,rank:rank(L),t:p[0].t,xp:thr(L)})}if(n<L)L=n});return out};
OD.G={B:B,MAIN_XP:MAIN_XP,PERF_XP:PERF_XP,CH_XP:CH_XP,MAX_LEVEL:MAX_LEVEL,xpOf:xpOf,thr:thr,need:need,lvl:lvl,rank:rank,RANKS:RANKS,ACH:ACH,CH:CH,chValue:chValue,chRef:chRef,chPaid:chPaid,challenges:challenges,total:total,progression:progression,weekDays:weekDays};
})();
