// =====================================================
// NetEarn Pro Withdraw System
// FINAL FAST CLEAN VERSION
// Firebase + Auth + Fast Cache + Secure Withdraw
// =====================================================


import { auth, db } from "./firebase.js";


import {
    onAuthStateChanged
}
from
"https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";


import {
    doc,
    getDoc,
    collection,
    addDoc,
    updateDoc,
    serverTimestamp
}
from
"https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";



// =====================================================
// ELEMENTS
// =====================================================

const balanceBox =
    document.getElementById("availableBalance");

const method =
    document.getElementById("method");

const number =
    document.getElementById("number");

const amount =
    document.getElementById("amount");

const withdrawBtn =
    document.getElementById("withdrawBtn");

const minimumWithdrawText =
    document.getElementById("minimumWithdrawText");



// =====================================================
// STATE
// =====================================================

let currentUser = null;

let userData = null;

let siteSettings = {

    minimumWithdraw: 100,

    withdrawFee: 0

};

let authSessionToken = 0;

let submitting = false;



// =====================================================
// CONFIG
// =====================================================

const CONFIG = {

    loginPage: "index.html",

    walletPage: "wallet.html",

    cachePrefix: "netearnWithdraw_"

};



// =====================================================
// SAFE NUMBER
// =====================================================

function safeNumber(value, fallback = 0) {

    const numberValue =
        Number(value);

    return Number.isFinite(numberValue)
        ? numberValue
        : fallback;

}



// =====================================================
// GET USER BALANCE
// Supports existing balance + mainBalance
// =====================================================

function getUserBalance(data) {

    if (!data) {
        return 0;
    }


    // Current Withdraw system
    if (
        data.balance !== undefined &&
        data.balance !== null
    ) {

        return safeNumber(
            data.balance
        );

    }


    // NetEarn Pro main balance support
    if (
        data.mainBalance !== undefined &&
        data.mainBalance !== null
    ) {

        return safeNumber(
            data.mainBalance
        );

    }


    return 0;

}



// =====================================================
// CACHE KEY
// IMPORTANT:
// Cache is USER-SPECIFIC
// =====================================================

function getCacheKey(uid) {

    return (
        CONFIG.cachePrefix +
        uid
    );

}



// =====================================================
// SAVE FAST WITHDRAW CACHE
// =====================================================

function saveWithdrawCache() {

    if (
        !currentUser ||
        !userData
    ) {

        return;

    }


    try {

        const cache = {

            uid:
                currentUser.uid,

            balance:
                getUserBalance(userData),

            userData: {

                verified:
                    userData.verified === true,

                withdrawEnabled:
                    userData.withdrawEnabled !== false,

                username:
                    userData.username ||
                    "",

                name:
                    userData.name ||
                    ""

            },

            savedAt:
                Date.now()

        };


        sessionStorage.setItem(

            getCacheKey(
                currentUser.uid
            ),

            JSON.stringify(cache)

        );

    }

    catch (error) {

        console.warn(
            "⚠️ Withdraw cache save failed:",
            error
        );

    }

}



// =====================================================
// LOAD FAST WITHDRAW CACHE
// =====================================================

function loadWithdrawCache(uid) {

    if (!uid) {
        return;
    }


    try {

        const cached =
            sessionStorage.getItem(
                getCacheKey(uid)
            );


        if (!cached) {
            return;
        }


        const cache =
            JSON.parse(cached);


        // ---------------------------------------------
        // UID SAFETY
        // ---------------------------------------------

        if (
            !cache ||
            cache.uid !== uid
        ) {

            return;

        }


        // ---------------------------------------------
        // SHOW CACHED BALANCE
        // ---------------------------------------------

        if (balanceBox) {

            balanceBox.textContent =
                "৳" +
                safeNumber(
                    cache.balance
                );

        }


        console.log(
            "⚡ Withdraw balance loaded from cache"
        );

    }

    catch (error) {

        console.warn(
            "⚠️ Withdraw cache error:",
            error
        );

    }

}



// =====================================================
// SHOW BALANCE
// =====================================================

function showBalance() {

    if (!balanceBox) {
        return;
    }


    const balance =
        getUserBalance(
            userData
        );


    balanceBox.textContent =
        "৳" +
        balance;


}



// =====================================================
// SHOW MINIMUM WITHDRAW
// =====================================================

function updateMinimumWithdraw() {

    const minimumWithdraw =
        safeNumber(
            siteSettings.minimumWithdraw,
            100
        );


    if (minimumWithdrawText) {

        minimumWithdrawText.textContent =
            "Minimum withdrawal amount is ৳" +
            minimumWithdraw +
            ".";

    }


    if (amount) {

        amount.min =
            minimumWithdraw;

        amount.placeholder =
            "Minimum ৳" +
            minimumWithdraw;

    }

}



// =====================================================
// WITHDRAW ACCESS UI
// =====================================================

function updateWithdrawAccess() {

    if (!userData) {
        return;
    }


    const verified =
        userData.verified === true;


    // =================================================
    // NOT VERIFIED
    // =================================================

    if (!verified) {

        if (method) {
            method.disabled = true;
        }

        if (number) {
            number.disabled = true;
        }

        if (amount) {
            amount.disabled = true;
        }


        if (withdrawBtn) {

            withdrawBtn.disabled = true;

            withdrawBtn.innerText =
                "🔒 Account Verification Required";

        }

        return;

    }


    // =================================================
    // VERIFIED
    // =================================================

    if (method) {
        method.disabled = false;
    }

    if (number) {
        number.disabled = false;
    }

    if (amount) {
        amount.disabled = false;
    }


    if (withdrawBtn) {

        withdrawBtn.disabled = false;

        withdrawBtn.innerText =
            "Submit Withdraw Request";

    }

}



// =====================================================
// LOAD USER + SETTINGS
// FAST PARALLEL LOAD
// =====================================================

async function loadWithdrawData(
    user,
    sessionToken
) {

    try {

        // =================================================
        // LOAD BOTH AT THE SAME TIME
        // =================================================

        const [
            userSnap,
            settingsSnap
        ] = await Promise.all([

            getDoc(
                doc(
                    db,
                    "users",
                    user.uid
                )
            ),

            getDoc(
                doc(
                    db,
                    "settings",
                    "main"
                )
            )

        ]);


        // =================================================
        // AUTH SESSION SAFETY
        // =================================================

        if (
            sessionToken !== authSessionToken ||
            !auth.currentUser ||
            auth.currentUser.uid !== user.uid
        ) {

            console.warn(
                "⚠️ Old withdraw session ignored."
            );

            return;

        }


        // =================================================
        // USER DOCUMENT CHECK
        // =================================================

        if (!userSnap.exists()) {

            console.error(
                "❌ User data not found."
            );

            await alert(
                "User data not found."
            );

            return;

        }


        // =================================================
        // STORE USER DATA
        // =================================================

        userData =
            userSnap.data();


        // =================================================
        // LOAD ADMIN SETTINGS
        // =================================================

        if (
            settingsSnap.exists()
        ) {

            siteSettings = {

                ...siteSettings,

                ...settingsSnap.data()

            };

        }


        // =================================================
        // UPDATE UI
        // =================================================

        showBalance();

        updateMinimumWithdraw();

        updateWithdrawAccess();


        // =================================================
        // SAVE FRESH CACHE
        // =================================================

        saveWithdrawCache();


        console.log(
            "✅ Withdraw data loaded:",
            user.uid
        );

    }

    catch (error) {

        console.error(
            "❌ Withdraw Load Error:",
            error
        );


        if (withdrawBtn) {

            withdrawBtn.disabled =
                true;

            withdrawBtn.innerText =
                "Unable to Load Account";

        }

    }

}



// =====================================================
// AUTH START
// =====================================================

onAuthStateChanged(
    auth,
    async user => {

        const sessionToken =
            ++authSessionToken;


        // =================================================
        // LOGGED OUT
        // =================================================

        if (!user) {

            currentUser = null;

            userData = null;

            window.location.replace(
                CONFIG.loginPage
            );

            return;

        }


        // =================================================
        // CURRENT USER
        // =================================================

        currentUser =
            user;


        // =================================================
        // ⚡ INSTANT CACHE
        // =================================================

        loadWithdrawCache(
            user.uid
        );


        // =================================================
        // FIREBASE REFRESH
        // =================================================

        await loadWithdrawData(
            user,
            sessionToken
        );

    }
);



// =====================================================
// WITHDRAW REQUEST
// =====================================================

withdrawBtn?.addEventListener(
    "click",
    async () => {

        // =================================================
        // DOUBLE CLICK PROTECTION
        // =================================================

        if (submitting) {
            return;
        }


        try {

            // =================================================
            // USER DATA CHECK
            // =================================================

            if (
                !currentUser ||
                !userData
            ) {

                await alert(
                    "Please wait..."
                );

                return;

            }


            // =================================================
            // AUTH SAFETY
            // =================================================

            if (
                !auth.currentUser ||
                auth.currentUser.uid !==
                    currentUser.uid
            ) {

                await alert(
                    "Session expired. Please login again."
                );

                return;

            }


            // =================================================
            // ACCOUNT VERIFICATION
            // =================================================

            if (
                userData.verified !== true
            ) {

                await alert(
                    "🔒 আগে Account Verification সম্পন্ন করুন।\n\n" +
                    "Verification সম্পন্ন হওয়ার পর Withdraw করতে পারবেন।"
                );

                return;

            }


            // =================================================
            // ADMIN WITHDRAW STATUS
            // =================================================

            if (
                userData.withdrawEnabled === false
            ) {

                await alert(
                    "❌ Withdraw is currently disabled by Admin."
                );

                return;

            }


            // =================================================
            // AMOUNT
            // =================================================

            const withdrawAmount =
                safeNumber(
                    amount?.value,
                    NaN
                );
                
                
                // =================================
// PAYMENT METHOD VALIDATION
// =================================

const selectedMethod =
    method?.value || "";


if (!selectedMethod) {

    await alert(
        "💳 Please select a Payment Method."
    );

    method?.focus();

    return;

}


            // =================================================
            // ACCOUNT NUMBER
            // =================================================

            const accountNumber =
                number?.value.trim() || "";


            // =================================================
            // ACCOUNT NUMBER CHECK
            // =================================================

            if (
                accountNumber === ""
            ) {

                await alert(
                    "Enter Account Number"
                );

                number?.focus();

                return;

            }


            // =================================================
            // AMOUNT CHECK
            // =================================================

            if (
                !Number.isFinite(
                    withdrawAmount
                ) ||
                withdrawAmount <= 0
            ) {

                await alert(
                    "Enter a valid withdraw amount."
                );

                amount?.focus();

                return;

            }


            // =================================================
            // MINIMUM WITHDRAW
            // =================================================

            const minimumWithdraw =
                safeNumber(
                    siteSettings.minimumWithdraw,
                    100
                );


            if (
                withdrawAmount <
                minimumWithdraw
            ) {

                await alert(
                    "Minimum Withdraw ৳" +
                    minimumWithdraw
                );

                return;

            }


            // =================================================
            // CURRENT BALANCE
            // =================================================

            const currentBalance =
                getUserBalance(
                    userData
                );


            // =================================================
            // BALANCE CHECK
            // =================================================

            if (
                withdrawAmount >
                currentBalance
            ) {

                await alert(
                    "Insufficient Balance"
                );

                return;

            }


            // =================================================
            // LOCK BUTTON
            // =================================================

            submitting = true;

            withdrawBtn.disabled =
                true;

            withdrawBtn.innerText =
                "Submitting...";


            // =================================================
            // CREATE WITHDRAW REQUEST
            // =================================================

            await addDoc(

                collection(
                    db,
                    "withdrawRequests"
                ),

                {

                    uid:
                        currentUser.uid,

                    // Keep existing field
                    userId:
                        currentUser.uid,

                    name:
                        userData.name ||
                        userData.username ||
                        "",

                    username:
                        userData.username ||
                        "",

                    email:
                        currentUser.email ||
                        "",

                    method:
    selectedMethod,

                    number:
                        accountNumber,

                    amount:
                        withdrawAmount,

                    transaction:
                        "",

                    status:
                        "Pending",

                    createdAt:
                        serverTimestamp()

                }

            );


            // =================================================
            // UPDATE USER BALANCE
            // =================================================

            const newBalance =
                currentBalance -
                withdrawAmount;


            await updateDoc(

                doc(
                    db,
                    "users",
                    currentUser.uid
                ),

                {

                    balance:
                        newBalance,

                    pendingWithdraw:
                        safeNumber(
                            userData.pendingWithdraw
                        ) +
                        withdrawAmount

                }

            );


            // =================================================
            // UPDATE LOCAL STATE
            // =================================================

            userData.balance =
                newBalance;


            // =================================================
            // UPDATE CACHE
            // =================================================

            saveWithdrawCache();


            // =================================================
            // UPDATE UI
            // =================================================

            showBalance();

// =================================================
            // SUCCESS
            // =================================================

            await alert(
                "✅ Withdraw Request Submitted Successfully"
            );


            window.location.replace(
                CONFIG.walletPage
            );

        }

        catch (error) {

            console.error(
                "❌ Withdraw Error:",
                error
            );


            await alert(
                "❌ Withdraw Failed\n\n" +
                (
                    error?.message ||
                    "Unknown error"
                )
            );


            submitting = false;


            updateWithdrawAccess();

        }

    }
);



// =====================================================
// START
// =====================================================

console.log(
    "⚡ NetEarn Pro Withdraw System — FAST VERSION Loaded"
);