"use strict";

const MenuUI = (() => {
  const WINNER_LABELS = {
    town: "🏛️ المواطنون",
    mafia: "🔪 المافيا",
    lone_killer: "🗡️ القاتل المنفرد",
    clown: "🤡 المهرج",
    none: "🕯️ لا ناجين",
  };

  const $ = (id) => document.getElementById(id);

  function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }

  /* ---------- الاستكمال ---------- */
  function refreshContinue() {
    $("btn-continue").disabled = !Saver.exists();
  }

  function resume() {
    const data = Saver.load();
    if (!data) {
      UI.toast("لا توجد لعبة محفوظة");
      refreshContinue();
      return;
    }
    const res = Game.importState(data);
    if (!res.ok) {
      Saver.clear();
      refreshContinue();
      UI.toast("ملف الحفظ تالف وتم حذفه");
      return;
    }
    switch (res.target) {
      case "reveal":
        Reveal.start();
        break;
      case "night":
        NightUI.start();
        break;
      case "dawn":
        UI.toast("تم الاستكمال من بداية النهار", 3000);
        DayUI.start();
        break;
      case "over":
        WinUI.show();
        break;
      default:
        UI.toast("تعذر الاستكمال");
    }
  }

  /* ---------- الإحصائيات ---------- */
  function statCard(label, value) {
    const card = el("div", "stat-card");
    card.append(el("b", "", String(value)), el("small", "", label));
    return card;
  }

  function renderStats() {
    const stats = Stats.get();
    const body = $("stats-body");
    body.innerHTML = "";

    const grid = el("div", "stats-grid");
    grid.append(
      statCard("عدد الألعاب", stats.games),
      statCard("مرات الفوز", stats.games - stats.draws),
      statCard("فوز المواطنين", stats.townWins),
      statCard("فوز المافيا", stats.mafiaWins),
      statCard("فوز المستقلين", stats.neutralWins),
      statCard("مرات لعب المافيا", stats.mafiaRoleCount)
    );
    body.appendChild(grid);

    body.appendChild(el("h3", "stats-title", "🎭 أكثر الأدوار ظهورًا"));
    const top = Object.entries(stats.roleCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5);
    if (top.length === 0) {
      body.appendChild(el("p", "placeholder-note", "لا بيانات بعد"));
    }
    top.forEach(([id, count]) => {
      const role = Roles.get(id);
      const row = el("div", "stats-row");
      row.append(el("span", "", `${role.icon} ${role.name}`), el("b", "", String(count)));
      body.appendChild(row);
    });

    body.appendChild(el("h3", "stats-title", "🕘 آخر الألعاب"));
    if (stats.history.length === 0) {
      body.appendChild(el("p", "placeholder-note", "لا توجد ألعاب مسجلة بعد"));
    }
    stats.history.forEach((game) => {
      const date = new Date(game.date).toLocaleDateString("ar");
      const row = el("div", "stats-row");
      row.append(
        el("span", "", `${date} — ${game.players} لاعبين`),
        el("span", "", `${WINNER_LABELS[game.winner] || game.winner} (${game.rounds} جولة)`)
      );
      body.appendChild(row);
    });
  }

  /* ---------- الإعدادات ---------- */
  function renderSettings() {
    const prefs = Prefs.get();
    $("set-sound").checked = prefs.sound;
    $("set-volume").value = String(prefs.volume);
    $("set-anim").checked = prefs.animations;
    $("set-speed").value = prefs.speed;
  }

  function onScreen(name) {
    if (name === "win") Stats.recordFromGame();
    else if (name === "home") refreshContinue();
    else if (name === "stats") renderStats();
    else if (name === "settings") renderSettings();
  }

  function init() {
    UI.onScreen(onScreen);

    $("set-sound").addEventListener("change", (e) => Prefs.set({ sound: e.target.checked }));
    $("set-volume").addEventListener("input", (e) => Prefs.set({ volume: Number(e.target.value) }));
    $("set-volume").addEventListener("change", () => Sound.play("tap"));
    $("set-anim").addEventListener("change", (e) => Prefs.set({ animations: e.target.checked }));
    $("set-speed").addEventListener("change", (e) => Prefs.set({ speed: e.target.value }));
    $("btn-sound-test").addEventListener("click", () => Sound.play("reveal"));

    const resetBtn = $("btn-settings-reset");
    resetBtn.addEventListener("click", () =>
      UI.twoTap("reset", resetBtn, "♻️ إعادة ضبط الإعدادات", "⚠️ اضغط مرة أخرى للتأكيد", () => {
        Prefs.reset();
        renderSettings();
        UI.toast("تمت إعادة ضبط الإعدادات");
      })
    );

    const clearBtn = $("btn-stats-clear");
    clearBtn.addEventListener("click", () =>
      UI.twoTap("clear-stats", clearBtn, "🗑️ مسح الإحصائيات", "⚠️ اضغط مرة أخرى للتأكيد", () => {
        Stats.clear();
        renderStats();
        UI.toast("تم مسح الإحصائيات");
      })
    );
  }

  return { init, resume };
})();