(function () {
  'use strict';
  const P = (window.Pith = window.Pith || {});
  const M = (P.md = {});
  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  // ================================================================ syntax highlighting
  const words = (s) => new Set(s.split(/\s+/).filter(Boolean));
  const CLIKE_KW = words(`abstract as async await break case catch class const constructor continue default defer delete do else enum export extends extern final finally fn for from func function go goto if impl implements import in instanceof interface internal is lateinit let match mod mut namespace new of open operator override package private protected pub public readonly ref return sealed select static struct super suspend switch this throw trait try type typealias typeof union unsafe use using val var virtual void volatile when where while with yield`);
  const CLIKE_LIT = words('true false null nil undefined NaN Infinity None self');
  const PY_KW = words('and as assert async await break class continue def del elif else except finally for from global if import in is lambda nonlocal not or pass raise return try while with yield match case');
  const PY_LIT = words('True False None self cls');
  const SH_KW = words('if then else elif fi for while until do done case esac in function select time return exit export local readonly declare echo cd set unset source alias');
  const SQL_KW = words('select from where insert into values update set delete create table drop alter add column index primary key foreign references join left right inner outer full cross on group by order having limit offset union all distinct as and or not null is in like between exists case when then else end count sum avg min max with view if default unique check constraint');
  const LIT_NONE = new Set();

  const RE = {
    clikeComment: '(\\/\\/[^\\n]*|\\/\\*[\\s\\S]*?(?:\\*\\/|$))',
    hashComment: '(#[^\\n]*)',
    sqlComment: '(--[^\\n]*|\\/\\*[\\s\\S]*?(?:\\*\\/|$))',
    clikeString: '("(?:[^"\\\\\\n]|\\\\.)*"?|\'(?:[^\'\\\\\\n]|\\\\.)*\'?|`(?:[^`\\\\]|\\\\.)*`?)',
    pyString: '("""[\\s\\S]*?(?:"""|$)|\'\'\'[\\s\\S]*?(?:\'\'\'|$)|"(?:[^"\\\\\\n]|\\\\.)*"?|\'(?:[^\'\\\\\\n]|\\\\.)*\'?)',
    number: '(\\b0x[\\da-fA-F]+\\b|\\b\\d+(?:\\.\\d+)?(?:e[+-]?\\d+)?\\b)',
    word: '([A-Za-z_$][\\w$]*)',
  };
  const family = (comment, string, kw, lit, ci) => ({
    re: new RegExp(`${comment}|${string}|${RE.number}|${RE.word}`, 'g'),
    kw, lit, ci: !!ci,
  });
  const FAMILIES = {
    clike: family(RE.clikeComment, RE.clikeString, CLIKE_KW, CLIKE_LIT),
    python: family(RE.hashComment, RE.pyString, PY_KW, PY_LIT),
    shell: family(RE.hashComment, RE.clikeString, SH_KW, LIT_NONE),
    sql: family(RE.sqlComment, RE.clikeString, SQL_KW, words('true false null'), true),
    config: family(RE.hashComment, RE.clikeString, LIT_NONE, words('true false null yes no on off')),
  };
  const ALIAS = {
    js: 'clike', javascript: 'clike', jsx: 'clike', ts: 'clike', typescript: 'clike', tsx: 'clike', java: 'clike',
    kotlin: 'clike', kt: 'clike', c: 'clike', cpp: 'clike', 'c++': 'clike', cs: 'clike', csharp: 'clike', 'c#': 'clike',
    go: 'clike', golang: 'clike', rust: 'clike', rs: 'clike', swift: 'clike', dart: 'clike', php: 'clike', scala: 'clike',
    python: 'python', py: 'python', bash: 'shell', sh: 'shell', shell: 'shell', zsh: 'shell', console: 'shell',
    sql: 'sql', yaml: 'config', yml: 'config', toml: 'config', ini: 'config', properties: 'config',
  };

  function tokenize(code, fam) {
    const re = fam.re;
    re.lastIndex = 0;
    let out = '', last = 0, m;
    while ((m = re.exec(code))) {
      if (m.index > last) out += esc(code.slice(last, m.index));
      const t = m[0];
      let cls = null;
      if (m[1] !== undefined) cls = 'c';
      else if (m[2] !== undefined) cls = 's';
      else if (m[3] !== undefined) cls = 'n';
      else {
        const key = fam.ci ? t.toLowerCase() : t;
        if (fam.kw.has(key)) cls = 'k';
        else if (fam.lit.has(t)) cls = 'l';
        else if (code[re.lastIndex] === '(') cls = 'f';
        else if (/^[A-Z][a-z0-9_]+[A-Za-z0-9_]*$/.test(t)) cls = 't';
      }
      out += cls ? `<span class="tk-${cls}">${esc(t)}</span>` : esc(t);
      last = re.lastIndex;
      if (!t.length) re.lastIndex++;
    }
    return out + esc(code.slice(last));
  }

  function highlightJson(code) {
    const re = /("(?:[^"\\\n]|\\.)*"?)(\s*:)?|(-?\b\d+(?:\.\d+)?(?:e[+-]?\d+)?\b)|\b(true|false|null)\b/g;
    let out = '', last = 0, m;
    while ((m = re.exec(code))) {
      out += esc(code.slice(last, m.index));
      if (m[1] !== undefined) out += `<span class="tk-${m[2] ? 'a' : 's'}">${esc(m[1])}</span>${esc(m[2] || '')}`;
      else if (m[3] !== undefined) out += `<span class="tk-n">${esc(m[3])}</span>`;
      else out += `<span class="tk-l">${esc(m[4])}</span>`;
      last = re.lastIndex;
    }
    return out + esc(code.slice(last));
  }

  function highlightMarkup(code) {
    const re = /(<!--[\s\S]*?(?:-->|$))|(<\/?[A-Za-z][\w:-]*)|(\s)([\w:-]+)(?==)|("[^"]*"?|'[^']*'?)|(\/?>)/g;
    let out = '', last = 0, m;
    while ((m = re.exec(code))) {
      out += esc(code.slice(last, m.index));
      if (m[1] !== undefined) out += `<span class="tk-c">${esc(m[1])}</span>`;
      else if (m[2] !== undefined) out += `<span class="tk-k">${esc(m[2])}</span>`;
      else if (m[4] !== undefined) out += `${m[3]}<span class="tk-a">${esc(m[4])}</span>`;
      else if (m[5] !== undefined) out += `<span class="tk-s">${esc(m[5])}</span>`;
      else out += `<span class="tk-k">${esc(m[6])}</span>`;
      last = re.lastIndex;
    }
    return out + esc(code.slice(last));
  }

  function highlightCss(code) {
    const re = /(\/\*[\s\S]*?(?:\*\/|$))|("(?:[^"\\\n]|\\.)*"?|'(?:[^'\\\n]|\\.)*'?)|(@[\w-]+)|([\w-]+)(?=\s*:)|(#[0-9a-fA-F]{3,8}\b|-?\d*\.?\d+(?:px|em|rem|%|vh|vw|s|ms|deg)?\b)/g;
    let out = '', last = 0, m;
    while ((m = re.exec(code))) {
      out += esc(code.slice(last, m.index));
      const cls = m[1] !== undefined ? 'c' : m[2] !== undefined ? 's' : m[3] !== undefined ? 'k' : m[4] !== undefined ? 'a' : 'n';
      out += `<span class="tk-${cls}">${esc(m[0])}</span>`;
      last = re.lastIndex;
    }
    return out + esc(code.slice(last));
  }

  M.highlight = function (code, lang) {
    const l = String(lang || '').toLowerCase();
    try {
      if (l === 'json' || l === 'jsonc') return highlightJson(code);
      if (l === 'html' || l === 'xml' || l === 'svg' || l === 'xhtml') return highlightMarkup(code);
      if (l === 'css' || l === 'scss' || l === 'less') return highlightCss(code);
      const fam = FAMILIES[ALIAS[l]];
      if (fam) return tokenize(code, fam);
    } catch (e) { /* fall back to plain text */ }
    return esc(code);
  };

  // ================================================================ markdown
  function codeBlock(code, lang, open) {
    const tooBig = open && code.length > 8000;
    const html = tooBig ? esc(code) : M.highlight(code, lang);
    return `<div class="code"><div class="code-head"><span>${esc(lang || 'code')}</span><button class="code-copy" type="button">Copy</button></div><pre><code>${html}</code></pre></div>`;
  }

  function inline(src) {
    const stash = [];
    const keep = (html) => { stash.push(html); return '\u0000' + (stash.length - 1) + '\u0000'; };
    const links = [];
    let s = String(src);
    s = s.replace(/``([^`]+?)``/g, (m, c) => keep('<code>' + esc(c.trim()) + '</code>'));
    s = s.replace(/`([^`\n]+)`/g, (m, c) => keep('<code>' + esc(c) + '</code>'));
    s = esc(s);
    s = s.replace(/!?\[([^\]\n]+)\]\(([^)\s]+)(?:\s+&quot;[^&]*&quot;)?\)/g, (m, text, url) => {
      if (!/^(https?:|mailto:|#)/i.test(url)) return text;
      links.push(url);
      return '\u0001' + (links.length - 1) + '\u0002' + text + '\u0003';
    });
    s = s.replace(/(^|[\s(])(https?:\/\/[^\s<)]+[^\s<).,;:!?])/g, (m, pre, url) => {
      links.push(url);
      return pre + '\u0001' + (links.length - 1) + '\u0002' + url + '\u0003';
    });
    s = s.replace(/\*\*(?=\S)([\s\S]*?\S)\*\*/g, '<strong>$1</strong>');
    s = s.replace(/(^|[^\w])__(?=\S)([\s\S]*?\S)__(?![\w])/g, '$1<strong>$2</strong>');
    s = s.replace(/(^|[^*\w])\*(?=[^\s*])([^*\n]*?[^\s*])\*(?!\*)/g, '$1<em>$2</em>');
    s = s.replace(/(^|[^\w])_(?=[^\s_])([^_\n]*?[^\s_])_(?![\w])/g, '$1<em>$2</em>');
    s = s.replace(/~~(?=\S)([\s\S]*?\S)~~/g, '<del>$1</del>');
    s = s.replace(/\u0001(\d+)\u0002/g, (m, i) => `<a href="${links[+i]}" target="_blank" rel="noopener noreferrer">`).replace(/\u0003/g, '</a>');
    s = s.replace(/\u0000(\d+)\u0000/g, (m, i) => stash[+i]);
    return s.replace(/\n/g, '<br>');
  }

  const LI = /^(\s*)([-*+]|\d{1,9}[.)])\s+(.*)$/;
  const FENCE_OPEN = /^\s{0,3}(`{3,}|~{3,})\s*([^\s`]*)[^`]*$/;
  const HR = /^\s{0,3}([-*_])(?:\s*\1){2,}\s*$/;
  const HEADING = /^\s{0,3}(#{1,6})\s+(.*?)\s*#*\s*$/;
  const TABLE_SEP = /^\s*\|?\s*:?-{1,}:?\s*(\|\s*:?-{1,}:?\s*)*\|?\s*$/;
  const blank = (l) => /^\s*$/.test(l);
  const leading = (l) => l.length - l.trimStart().length;

  function readFence(lines, i, opts) {
    const m = lines[i].match(FENCE_OPEN);
    const fence = m[1], lang = m[2], indent = leading(lines[i]);
    const body = [];
    let closed = false;
    i++;
    while (i < lines.length) {
      const l = lines[i];
      const c = l.match(/^\s{0,3}(`{3,}|~{3,})\s*$/);
      if (c && c[1][0] === fence[0] && c[1].length >= fence.length) { closed = true; i++; break; }
      body.push(l.slice(Math.min(indent, leading(l))));
      i++;
    }
    return { html: codeBlock(body.join('\n'), lang, !closed && opts.streaming), next: i };
  }

  function startsBlock(lines, i) {
    const l = lines[i];
    return FENCE_OPEN.test(l) || HEADING.test(l) || HR.test(l) || /^\s{0,3}>/.test(l) || LI.test(l) ||
      (l.includes('|') && i + 1 < lines.length && TABLE_SEP.test(lines[i + 1]) && lines[i + 1].includes('-'));
  }

  function readList(lines, start, opts) {
    const items = [];
    let i = start;
    while (i < lines.length) {
      const l = lines[i];
      const m = l.match(LI);
      if (m && !HR.test(l)) {
        items.push({ indent: m[1].replace(/\t/g, '    ').length, ordered: /\d/.test(m[2]), num: parseInt(m[2], 10), parts: [{ text: [m[3]] }] });
        i++;
        continue;
      }
      if (blank(l)) {
        let j = i + 1;
        while (j < lines.length && blank(lines[j])) j++;
        if (items.length && j < lines.length && (LI.test(lines[j]) || leading(lines[j]) > 0)) { i = j; continue; }
        break;
      }
      if (items.length && leading(l) > 0) {
        const item = items[items.length - 1];
        if (FENCE_OPEN.test(l)) {
          const fence = readFence(lines, i, opts);
          item.parts.push({ html: fence.html });
          i = fence.next;
          continue;
        }
        const lastPart = item.parts[item.parts.length - 1];
        if (lastPart.text) lastPart.text.push(l.trim());
        else item.parts.push({ text: [l.trim()] });
        i++;
        continue;
      }
      break;
    }
    return { html: buildList(items), next: i };
  }

  function buildList(items) {
    let html = '';
    const stack = [];
    items.forEach((it) => {
      const tag = it.ordered ? 'ol' : 'ul';
      while (stack.length && it.indent < stack[stack.length - 1].indent) html += '</li></' + stack.pop().tag + '>';
      const top = stack[stack.length - 1];
      if (!top || it.indent > top.indent) {
        html += '<' + tag + (it.ordered && it.num !== 1 ? ` start="${it.num}"` : '') + '>';
        stack.push({ indent: it.indent, tag });
      } else {
        html += '</li>';
        if (top.tag !== tag) { html += `</${top.tag}><${tag}>`; stack[stack.length - 1] = { indent: top.indent, tag }; }
      }
      html += '<li>' + it.parts.map((p) => (p.html ? p.html : inline(p.text.join('\n')))).join('');
    });
    while (stack.length) html += '</li></' + stack.pop().tag + '>';
    return html;
  }

  function cells(line) {
    let t = line.trim();
    if (t.startsWith('|')) t = t.slice(1);
    if (t.endsWith('|')) t = t.slice(0, -1);
    return t.split('|').map((c) => c.trim());
  }

  function readTable(lines, i) {
    const head = cells(lines[i]);
    const aligns = cells(lines[i + 1]).map((c) => (c.startsWith(':') && c.endsWith(':') ? 'center' : c.endsWith(':') ? 'right' : c.startsWith(':') ? 'left' : ''));
    let j = i + 2;
    const rows = [];
    while (j < lines.length && !blank(lines[j]) && lines[j].includes('|')) { rows.push(cells(lines[j])); j++; }
    const cell = (tag, text, k) => `<${tag}${aligns[k] ? ` style="text-align:${aligns[k]}"` : ''}>${inline(text || '')}</${tag}>`;
    const html = '<div class="tbl"><table><thead><tr>' + head.map((c, k) => cell('th', c, k)).join('') + '</tr></thead><tbody>' +
      rows.map((r) => '<tr>' + head.map((_, k) => cell('td', r[k], k)).join('') + '</tr>').join('') + '</tbody></table></div>';
    return { html, next: j };
  }

  function blocks(lines, opts) {
    const out = [];
    let i = 0;
    while (i < lines.length) {
      const line = lines[i];
      if (blank(line)) { i++; continue; }
      if (FENCE_OPEN.test(line)) { const r = readFence(lines, i, opts); out.push(r.html); i = r.next; continue; }
      let m = line.match(HEADING);
      if (m) { out.push(`<h${m[1].length}>${inline(m[2])}</h${m[1].length}>`); i++; continue; }
      if (HR.test(line)) { out.push('<hr>'); i++; continue; }
      if (/^\s{0,3}>/.test(line)) {
        const quoted = [];
        while (i < lines.length && /^\s{0,3}>/.test(lines[i])) { quoted.push(lines[i].replace(/^\s{0,3}>\s?/, '')); i++; }
        out.push('<blockquote>' + blocks(quoted, opts) + '</blockquote>');
        continue;
      }
      if (LI.test(line)) { const r = readList(lines, i, opts); out.push(r.html); i = r.next; continue; }
      if (line.includes('|') && i + 1 < lines.length && TABLE_SEP.test(lines[i + 1]) && lines[i + 1].includes('-')) {
        const r = readTable(lines, i); out.push(r.html); i = r.next; continue;
      }
      const para = [line];
      i++;
      while (i < lines.length && !blank(lines[i]) && !startsBlock(lines, i)) { para.push(lines[i]); i++; }
      out.push('<p>' + inline(para.join('\n')) + '</p>');
    }
    return out.join('');
  }

  M.render = function (text, opts) {
    return blocks(String(text || '').replace(/\r\n?/g, '\n').split('\n'), opts || {});
  };
  M.escape = esc;
})();
