/* =========================
   角色与敌人创建
========================= */

function makeAlly(id){
  const c=characterData[id];

  const u={
    id:c.id,
    name:c.name,
    icon:c.icon,
    hp:c.max,
    max:c.max,
    baseMax:c.max,
    acted:false,
    stun:0,
    reduction:0,
    guard:false,
    tempMaxHp:0,
    cursed:false
  };

  if(id==='tuffy')u.healUsedThisRound=false;

  if(id==='swordsman'){
    u.guardCd=0;
    u.guardUsedThisRound=false;
  }

  return u;
}

function makeDuck(id,name,isFollower=false){
  return {
    id,
    name,
    icon:'🦆',
    hp:100,
    max:100,
    acted:false,
    first:false,
    type:'duck',
    isFollower,
    hateTarget:null,
    hateTurns:0,
    attackCursePending:false
  };
}

function makeEnemies(level){
  let enemies;

  if(level===2){
    enemies=[1,2,3].map(n=>makeDuck('duck'+n,'鸭皇'+n));
  }else if(level===3){
    enemies=[
      makeDuck('duck','鸭皇'),
      {
        id:'captain',
        name:'鸭皇队长',
        icon:'🚩',
        hp:200,
        max:200,
        acted:false,
        type:'captain',
        charge:0
      }
    ];
  }else if(level===4){
    enemies=[
      {
        id:'mistress',
        name:'女主人',
        icon:'👩‍🦰',
        hp:150,
        max:150,
        acted:false,
        type:'mistress',
        charge:0
      },
      {
        id:'captain',
        name:'鸭皇队长',
        icon:'🚩',
        hp:200,
        max:200,
        acted:false,
        type:'captain',
        charge:0
      },
      {
        id:'box',
        name:'拳头盒子',
        icon:'🥊',
        hp:150,
        max:150,
        acted:false,
        first:false,
        type:'box'
      }
    ];
  }else{
    enemies=[
      makeDuck('duck','鸭皇'),
      {
        id:'box',
        name:'拳头盒子',
        icon:'🥊',
        hp:150,
        max:150,
        acted:false,
        first:false,
        type:'box'
      }
    ];
  }

  // 战斗开始时所有敌人都没有仇恨，也没有攻击力诅咒。
  return enemies.map(enemy=>({
    hateTarget:null,
    hateTurns:0,
    attackCursePending:false,
    ...enemy
  }));
}

function initial(){
  return {
    allies:selectedTeam.map(makeAlly),
    enemies:makeEnemies(selectedLevel),
    phase:'player',
    round:1,
    done:false,
    token:battleToken,
    resultPending:false
  };
}
