// =====================================================
// NetEarn Pro - Ultra Fast Team System
// Referral Based L1 → L5
// FINAL CLEAN VERSION — PART 1/2
// =====================================================

import {
    auth,
    db
} from "./firebase.js";

import {
    onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";

import {
    collection,
    query,
    where,
    getDocs,
    doc,
    getDoc
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";


// =====================================================
// DOM
// =====================================================

const teamList =
    document.getElementById("teamList");

const searchInput =
    document.getElementById("searchInput");

const clearSearch =
    document.getElementById("clearSearch");

const emptyState =
    document.getElementById("emptyState");

const errorState =
    document.getElementById("errorState");

const retryBtn =
    document.getElementById("retryBtn");

const inviteBtn =
    document.getElementById("inviteBtn");

const teamLoading =
    document.getElementById("teamLoading");

const resultInfo =
    document.getElementById("resultInfo");

const totalTeam =
    document.getElementById("totalTeam");

const verifiedTeam =
    document.getElementById("verifiedTeam");

const pendingTeam =
    document.getElementById("pendingTeam");

const lockedTeam =
    document.getElementById("lockedTeam");

const levelButtons =
    document.querySelectorAll(
        ".level-filter-btn"
    );


// =====================================================
// STATE
// =====================================================

let members = [];

let currentLevel = "all";

let currentUser = null;

let isLoading = false;

const TEAM_CACHE_PREFIX = "netearnpro_team_cache_";
const USER_SESSION_CACHE_KEY = "netearnUserSessionCache";


// =====================================================
// CACHE
// =====================================================

// User data cache
const userCache =
    new Map();


function getTeamCacheKey(uid) {

    return (
        TEAM_CACHE_PREFIX +
        String(uid || "")
    );

}


function loadTeamCache(uid) {

    if (!uid) {
        return null;
    }

    try {

        const raw =
            sessionStorage.getItem(
                getTeamCacheKey(uid)
            );

        if (!raw) {
            return null;
        }

        const parsed =
            JSON.parse(raw);

        return Array.isArray(parsed)
            ? parsed
            : null;

    } catch (_) {

        return null;

    }

}


function saveTeamCache(uid, data) {

    if (!uid || !Array.isArray(data)) {
        return;
    }

    try {

        sessionStorage.setItem(
            getTeamCacheKey(uid),
            JSON.stringify(data)
        );

    } catch (_) {

        // Cache is only an optimization.
    }

}


// Referral cache
const referralCache =
    new Map();


// =====================================================
// UI — LOADING
// =====================================================

function showLoading() {

    isLoading = true;

    if (teamLoading) {

        teamLoading.style.display =
            "flex";

    }

    if (teamList) {

        teamList.innerHTML =
            "";

    }

    if (emptyState) {

        emptyState.style.display =
            "none";

    }

    if (errorState) {

        errorState.style.display =
            "none";

    }

    if (resultInfo) {

        resultInfo.textContent =
            "Loading team...";

    }

}


// =====================================================
// HIDE LOADING
// =====================================================

function hideLoading() {

    if (teamLoading) {

        teamLoading.style.display =
            "none";

    }

}


// =====================================================
// ERROR
// =====================================================

function showError(error = null) {

    hideLoading();

    if (teamList) {

        teamList.innerHTML =
            "";

    }

    if (emptyState) {

        emptyState.style.display =
            "none";

    }

    if (errorState) {

        errorState.style.display =
            "flex";

    }

    const code =
        error?.code ||
        "unknown";

    const message =
        error?.message ||
        "Unknown error";

    if (resultInfo) {

        resultInfo.textContent =
            `Team Error: ${code}`;

    }

    console.error(
        "🔥 TEAM ERROR",
        {
            code,
            message,
            error
        }
    );

}


// =====================================================
// HIDE ERROR
// =====================================================

function hideError() {

    if (errorState) {

        errorState.style.display =
            "none";

    }

}


// =====================================================
// GET USER DATA
// =====================================================

async function getUserData(uid) {

    if (!uid) {

        return null;

    }


    // ---------------------------------------------
    // CACHE
    // ---------------------------------------------

    if (
        userCache.has(uid)
    ) {

        return userCache.get(uid);

    }


    try {

        const userRef =
            doc(
                db,
                "users",
                uid
            );


        const snapshot =
            await getDoc(
                userRef
            );


        if (
            !snapshot.exists()
        ) {

            userCache.set(
                uid,
                null
            );

            return null;

        }


        const data = {

            uid: uid,

            ...snapshot.data()

        };


        userCache.set(
            uid,
            data
        );


        return data;

    }

    catch (error) {

        console.error(
            "❌ User Data Error:",
            uid,
            error
        );

        return null;

    }

}


// =====================================================
// GET REFERRALS
// =====================================================

async function getReferrals(
    referrerUid
) {

    if (!referrerUid) {

        return [];

    }


    // ---------------------------------------------
    // CACHE
    // ---------------------------------------------

    if (
        referralCache.has(
            referrerUid
        )
    ) {

        return referralCache.get(
            referrerUid
        );

    }


    try {

        const referralsRef =
            collection(
                db,
                "referrals"
            );


        const q =
            query(
                referralsRef,

                where(
                    "referrerUid",
                    "==",
                    referrerUid
                )
            );


        const snapshot =
            await getDocs(q);


        const rawReferrals = [];


        snapshot.forEach(
            referralDoc => {

                const data =
                    referralDoc.data();


                // ---------------------------------
                // Ignore inactive
                // ---------------------------------

                if (
                    data.status &&
                    String(
                        data.status
                    )
                    .trim()
                    .toLowerCase() !==
                    "active"
                ) {

                    return;

                }


                const uid =
                    String(
                        data.referredUserUid ||
                        ""
                    ).trim();


                if (!uid) {

                    return;

                }


                rawReferrals.push({

                    uid: uid,

                    referralCode:
                        data.referralCode ||
                        "",

                    referredUserId:
                        data.referredUserId ||
                        "",

                    referredUsername:
                        data.referredUsername ||
                        "",

                    createdAt:
                        data.createdAt ||
                        null

                });

            }
        );


        // =================================================
        // LOAD ALL USERS IN PARALLEL
        // =================================================

        const userResults =
            await Promise.all(
                rawReferrals.map(
                    item =>
                        getUserData(
                            item.uid
                        )
                )
            );


        const result = [];


        rawReferrals.forEach(
            (item, index) => {

                const childUser =
                    userResults[index];


                // -----------------------------------------
                // VERIFIED
                // -----------------------------------------

                const verified =
                    childUser?.verified === true ||
                    String(
                        childUser?.verified ||
                        ""
                    )
                    .trim()
                    .toLowerCase() ===
                    "true";


                // -----------------------------------------
                // BLOCKED
                // -----------------------------------------

                const blocked =
                    childUser?.blocked === true ||
                    String(
                        childUser?.blocked ||
                        ""
                    )
                    .trim()
                    .toLowerCase() ===
                    "true";


                // -----------------------------------------
                // USER ID
                // -----------------------------------------

                const userId =
                    childUser?.userId ||
                    childUser?.id ||
                    item.referredUserId ||
                    "";


                // -----------------------------------------
                // USERNAME
                // -----------------------------------------

                const username =
                    childUser?.username ||
                    item.referredUsername ||
                    "Unknown";


                result.push({

                    uid:
                        item.uid,

                    userId:
                        userId,

                    username:
                        username,

                    referralCode:
                        item.referralCode ||
                        childUser?.referralCode ||
                        "",

                    verified:
                        verified,

                    blocked:
                        blocked,

                    createdAt:
                        item.createdAt

                });

            }
        );


        referralCache.set(
            referrerUid,
            result
        );


        return result;

    }

    catch (error) {

        console.error(
            "❌ GET REFERRALS ERROR:",
            referrerUid,
            error
        );

        throw error;

    }

}


// =====================================================
// DATE FORMAT
// =====================================================

function formatDate(
    timestamp
) {

    if (!timestamp) {

        return "N/A";

    }


    try {

        let date;


        if (
            typeof timestamp.toDate ===
            "function"
        ) {

            date =
                timestamp.toDate();

        }

        else {

            date =
                new Date(timestamp);

        }


        if (
            Number.isNaN(
                date.getTime()
            )
        ) {

            return "N/A";

        }


        return date.toLocaleDateString(
            "en-GB",
            {
                day: "2-digit",
                month: "short",
                year: "numeric"
            }
        );

    }

    catch {

        return "N/A";

    }

}


// =====================================================
// INITIALS
// =====================================================

function getInitials(
    username
) {

    const name =
        String(
            username ||
            "User"
        ).trim();


    if (!name) {

        return "U";

    }


    const parts =
        name.split(
            /\s+/
        );


    if (
        parts.length >= 2
    ) {

        return (
            parts[0][0] +
            parts[1][0]
        )
        .toUpperCase();

    }


    return name
        .substring(0, 2)
        .toUpperCase();

}


// =====================================================
// ESCAPE HTML
// =====================================================

function escapeHTML(
    value
) {

    return String(
        value ?? ""
    )
    .replace(
        /&/g,
        "&amp;"
    )
    .replace(
        /</g,
        "&lt;"
    )
    .replace(
        />/g,
        "&gt;"
    )
    .replace(
        /"/g,
        "&quot;"
    )
    .replace(
        /'/g,
        "&#039;"
    );

}


// =====================================================
// LOAD TEAM — ONLY ONE VERSION
// =====================================================

async function loadTeam() {

    if (
        !currentUser ||
        isLoading
    ) {

        return;

    }


    // Lock the refresh immediately. When cached data is available,
    // the old code left isLoading=false while Firebase refreshed in
    // the background, allowing another load to start concurrently.
    isLoading = true;


    const cachedMembers =
        loadTeamCache(
            currentUser.uid
        );

    const hasCache =
        Array.isArray(cachedMembers);

    // Shared user cache is available immediately on every page.
    // It provides the user's referral count while the full team tree
    // refreshes silently in the background.
    try {
        const rawUser = sessionStorage.getItem(USER_SESSION_CACHE_KEY);
        const sessionUser = rawUser ? JSON.parse(rawUser) : null;
        if (sessionUser?.uid === currentUser.uid && sessionUser?.data) {
            const data = sessionUser.data;
            const cachedTotal = Number(data.totalReferrals ?? data.referralCount);
            if (Number.isFinite(cachedTotal)) {
                if (totalTeam) totalTeam.textContent = String(cachedTotal);
                if (resultInfo && !hasCache) {
                    resultInfo.textContent = `${cachedTotal} total referral${cachedTotal === 1 ? "" : "s"}`;
                }
            }
        }
    } catch (_) {}


    // ⚡ Show the last known team immediately.
    // Firebase refresh continues in the background.
    if (hasCache) {

        members =
            cachedMembers;

        updateSummary();
        hideLoading();
        hideError();
        applyFilters();

    } else {

        showLoading();

    }


    try {

        // Build the fresh result separately. Never append fresh members
        // to the cached array, otherwise refreshes can duplicate the
        // same team and make Total / Verified / Pending / Locked change.
        const freshMembers = [];


        const addedUsers =
            new Set();


        // =================================================
        // CURRENT USER
        // =================================================

        // ⚡ The current-user existence check and the first L1
        // referral query are independent. Start them together so
        // the team traversal does not wait for an extra read round-trip.
        const [rootUser, firstLevelReferrals] =
            await Promise.all([
                getUserData(
                    currentUser.uid
                ),
                getReferrals(
                    currentUser.uid
                )
            ]);


        if (!rootUser) {

            throw new Error(
                "Current user document not found"
            );

        }


        // =================================================
        // START FROM L1
        // =================================================

        let parentUids = [

            currentUser.uid

        ];


        // =================================================
        // L1 → L5
        // =================================================

        for (
            let level = 1;
            level <= 5;
            level++
        ) {

            if (
                parentUids.length === 0
            ) {

                break;

            }


            // =================================================
            // LOAD ALL PARENTS IN PARALLEL
            // =================================================

            const referralGroups =
                level === 1
                    ? [firstLevelReferrals]
                    : await Promise.all(
                        parentUids.map(
                            uid =>
                                getReferrals(
                                    uid
                                )
                        )
                    );


            const nextParentUids =
                new Set();


            // =================================================
            // PROCESS
            // =================================================

            referralGroups.forEach(
                referrals => {

                    referrals.forEach(
                        referral => {

                            const uid =
                                String(
                                    referral.uid ||
                                    ""
                                ).trim();


                            if (!uid) {

                                return;

                            }


                            // ---------------------------------
                            // NEVER SHOW CURRENT USER
                            // ---------------------------------

                            if (
                                uid ===
                                currentUser.uid
                            ) {

                                return;

                            }


                            // ---------------------------------
                            // DUPLICATE PROTECTION
                            // ---------------------------------

                            if (
                                addedUsers.has(
                                    uid
                                )
                            ) {

                                return;

                            }


                            addedUsers.add(
                                uid
                            );


                            // ---------------------------------
                            // ADD MEMBER
                            // ---------------------------------

                            freshMembers.push({

                                uid:
                                    uid,

                                username:
                                    referral.username ||
                                    "Unknown",

                                userId:
                                    referral.userId ||
                                    "",

                                verified:
                                    referral.verified ===
                                    true,

                                blocked:
                                    referral.blocked ===
                                    true,

                                level:
                                    level,

                                joinDate:
                                    formatDate(
                                        referral.createdAt
                                    )

                            });


                            // ---------------------------------
                            // NEXT LEVEL
                            // ---------------------------------

                            nextParentUids.add(
                                uid
                            );

                        }
                    );

                }
            );


            parentUids =
                Array.from(
                    nextParentUids
                );

        }


        // =================================================
        // SORT
        // =================================================

        freshMembers.sort(
            (a, b) => {

                if (
                    a.level !==
                    b.level
                ) {

                    return (
                        a.level -
                        b.level
                    );

                }


                return String(
                    a.username ||
                    ""
                )
                .localeCompare(
                    String(
                        b.username ||
                        ""
                    )
                );

            }
        );


        // =================================================
        // SUMMARY
        // =================================================

        members = freshMembers;

        updateSummary();


        // =================================================
        // SHOW RESULTS IMMEDIATELY
        // =================================================

        hideLoading();

        hideError();

        applyFilters();

        // ⚡ Persist the rendered team so the next navigation
        // can paint immediately before Firebase finishes.
        saveTeamCache(
            currentUser.uid,
            members
        );


        console.log(
            "⚡ Ultra Fast Team Loaded:",
            members.length
        );

    }

    catch (error) {

        showError(
            error
        );

    }

    finally {

        isLoading = false;

    }

}


// =====================================================
// SUMMARY
// =====================================================

function updateSummary() {

    let verified = 0;

    let pending = 0;

    let locked = 0;


    members.forEach(
        member => {

            if (
                member.blocked === true
            ) {

                locked++;

            }

            else if (
                member.verified === true
            ) {

                verified++;

            }

            else {

                pending++;

            }

        }
    );


    if (totalTeam) {

        totalTeam.textContent =
            members.length;

    }


    if (verifiedTeam) {

        verifiedTeam.textContent =
            verified;

    }


    if (pendingTeam) {

        pendingTeam.textContent =
            pending;

    }


    if (lockedTeam) {

        lockedTeam.textContent =
            locked;

    }

}

// =====================================================
// APPLY FILTERS
// =====================================================

function applyFilters() {

    const keyword =
        String(
            searchInput?.value ||
            ""
        )
        .trim()
        .toLowerCase();


    let result =
        members;


    // =================================================
    // LEVEL FILTER
    // =================================================

    if (
        currentLevel !==
        "all"
    ) {

        result =
            members.filter(
                member =>
                    String(
                        member.level
                    ) ===
                    String(
                        currentLevel
                    )
            );

    }


    // =================================================
    // SEARCH
    // =================================================

    if (keyword) {

        result =
            result.filter(
                member => {

                    const username =
                        String(
                            member.username ||
                            ""
                        )
                        .toLowerCase();


                    const userId =
                        String(
                            member.userId ||
                            ""
                        )
                        .toLowerCase();


                    return (
                        username.includes(
                            keyword
                        ) ||
                        userId.includes(
                            keyword
                        )
                    );

                }
            );

    }


    displayTeam(
        result
    );

}


// =====================================================
// DISPLAY TEAM
// =====================================================

function displayTeam(
    list
) {

    if (!teamList) {

        return;

    }


    teamList.innerHTML =
        "";


    const searching =
        Boolean(
            searchInput?.value.trim()
        ) ||
        currentLevel !==
        "all";


    // =================================================
    // RESULT INFO
    // =================================================

    if (resultInfo) {

        if (searching) {

            resultInfo.textContent =
                `${list.length} member${
                    list.length === 1
                        ? ""
                        : "s"
                } found`;

        }

        else {

            resultInfo.textContent =
                `${members.length} team member${
                    members.length === 1
                        ? ""
                        : "s"
                }`;

        }

    }


    // =================================================
    // EMPTY
    // =================================================

    if (
        list.length === 0
    ) {

        if (emptyState) {

            emptyState.style.display =
                "flex";

        }

        return;

    }


    if (emptyState) {

        emptyState.style.display =
            "none";

    }


    // =================================================
    // DOCUMENT FRAGMENT
    // =================================================

    const fragment =
        document.createDocumentFragment();


    // =================================================
    // CREATE CARDS
    // =================================================

    list.forEach(
        member => {

            const article =
                document.createElement(
                    "article"
                );


            article.className =
                "member-card";


            if (
                member.blocked
            ) {

                article.classList.add(
                    "is-locked"
                );

            }


            // =================================================
            // STATUS
            // =================================================

            let statusClass =
                "pending";

            let statusText =
                "⏳ Pending";


            if (
                member.blocked
            ) {

                statusClass =
                    "locked";

                statusText =
                    "🔒 Locked";

            }

            else if (
                member.verified
            ) {

                statusClass =
                    "verified";

                statusText =
                    "✓ Verified";

            }


            // =================================================
            // INITIALS
            // =================================================

            const initials =
                getInitials(
                    member.username
                );


            // =================================================
            // CARD
            // =================================================

            article.innerHTML = `

                <div class="member-avatar">
                    ${escapeHTML(
                        initials
                    )}
                </div>


                <div class="member-info">

                    <div class="member-top-row">

                        <h3>
                            ${escapeHTML(
                                member.username ||
                                "Unknown"
                            )}
                        </h3>


                        <span class="level-badge">
                            L${member.level}
                        </span>

                    </div>


                    <p class="member-id">

                        ID:
                        ${escapeHTML(
                            member.userId ||
                            "N/A"
                        )}

                    </p>


                    <div class="member-meta">

                        <span
                            class="status-badge ${statusClass}"
                        >
                            ${statusText}
                        </span>


                        <span class="join-date">

                            ${escapeHTML(
                                member.joinDate ||
                                "N/A"
                            )}

                        </span>

                    </div>

                </div>


                <a
                    href="team-details.html?id=${encodeURIComponent(
                        member.uid
                    )}"
                    class="view-btn"
                    aria-label="View ${escapeHTML(
                        member.username ||
                        "User"
                    )}"
                >
                    View
                </a>

            `;


            fragment.appendChild(
                article
            );

        }
    );


    // =================================================
    // ONE DOM UPDATE
    // =================================================

    teamList.appendChild(
        fragment
    );

}


// =====================================================
// LEVEL FILTER
// =====================================================

levelButtons.forEach(
    button => {

        button.addEventListener(
            "click",
            () => {

                const selectedLevel =
                    button.dataset.level ||
                    "all";


                if (
                    selectedLevel ===
                    currentLevel
                ) {

                    return;

                }


                levelButtons.forEach(
                    btn => {

                        btn.classList.remove(
                            "active"
                        );

                    }
                );


                button.classList.add(
                    "active"
                );


                currentLevel =
                    selectedLevel;


                applyFilters();

            }
        );

    }
);


// =====================================================
// SEARCH
// =====================================================

let searchTimer =
    null;


searchInput?.addEventListener(
    "input",
    () => {

        if (clearSearch) {

            clearSearch.style.display =
                searchInput.value
                    ? "flex"
                    : "none";

        }


        clearTimeout(
            searchTimer
        );


        searchTimer =
            setTimeout(
                () => {

                    applyFilters();

                },
                80
            );

    }
);


// =====================================================
// CLEAR SEARCH
// =====================================================

clearSearch?.addEventListener(
    "click",
    () => {

        if (searchInput) {

            searchInput.value =
                "";

        }


        if (clearSearch) {

            clearSearch.style.display =
                "none";

        }


        applyFilters();


        searchInput?.focus();

    }
);


// =====================================================
// INVITE
// =====================================================

inviteBtn?.addEventListener(
    "click",
    async () => {

        if (!currentUser) {

            return;

        }


        try {

            const userData =
                await getUserData(
                    currentUser.uid
                );


            const code =
                String(
                    userData?.referralCode ||
                    ""
                ).trim();


            if (!code) {

                alert(
                    "Referral Code পাওয়া যায়নি।"
                );

                return;

            }


            const text =
`Join NetEarn Pro 🚀

আমার Referral Code:
${code}

NetEarn Pro-তে join করে আমার referral code ব্যবহার করুন।`;


            // =================================================
            // NATIVE SHARE
            // =================================================

            if (
                navigator.share
            ) {

                try {

                    await navigator.share({

                        title:
                            "Join NetEarn Pro",

                        text:
                            text

                    });

                    return;

                }

                catch (error) {

                    if (
                        error?.name ===
                        "AbortError"
                    ) {

                        return;

                    }

                }

            }


            // =================================================
            // CLIPBOARD
            // =================================================

            if (
                navigator.clipboard &&
                window.isSecureContext
            ) {

                await navigator.clipboard
                    .writeText(
                        text
                    );


                alert(
                    "✅ Invite message copied"
                );


                return;

            }


            alert(
                text
            );

        }

        catch (error) {

            console.error(
                "❌ Invite Error:",
                error
            );

        }

    }
);


// =====================================================
// RETRY
// =====================================================

retryBtn?.addEventListener(
    "click",
    () => {

        if (!isLoading) {

            // Clear cached referral data
            // so retry gets fresh data.

            referralCache.clear();


            loadTeam();

        }

    }
);


// =====================================================
// AUTH
// =====================================================

onAuthStateChanged(
    auth,
    user => {

        if (!user) {

            window.location.href =
                "index.html";

            return;

        }


        currentUser =
            user;


        // =================================================
        // START IMMEDIATELY
        // =================================================

        loadTeam();

    }
);


// =====================================================
// FINAL LOG
// =====================================================

console.log(
    "⚡ NetEarn Pro — Ultra Fast Team System Loaded"
);