// ===== team.js: AI squad mates, arena (team deathmatch / gun game) logic =====
const allies = [], _ap = new THREE.Vector3();
const ARENA_A = [-35, 0], ARENA_B = [35, 0];
function makeAlly(i, x, z) {
  const f = friendlySoldier(); scene.add(f.g);
  const a = { i, g: f.g, legs: f.legs, x, z, yaw: -Math.PI / 2, hp: 100, dead: false, deadT: 0, respT: 0, fireT: rand(.4, 1.4), burst: 0, los: false, losT: rand(0, .3), tgt: null, tgtT: 0, walk: Math.random() * 6, strafeDir: Math.random() < .5 ? -1 : 1, strafeT: rand(1, 3), avoidT: 0, avoidDir: 1, lastX: x, lastZ: z, chkT: 0, stuckN: 0, fallA: 0 };
  a.g.position.set(x, 0, z); allies.push(a); if (ggOn()) aiInit(a);
  else { a.tag = makeTag(); a.g.add(a.tag.sp); }
  return a;
}
function clearAllies() { for (const a of allies) scene.remove(a.g); allies.length = 0; }
function spawnSquad(n) {
  clearAllies(); for (let i = 0; i < n; i++) { if (G.arena) makeAlly(i, ARENA_A[0] + 2.5 + (i % 2) * 2, (i - (n - 1) / 2) * 4); else makeAlly(i, P.pos.x + (i - 1) * 2.5, P.pos.z + 3 + i * .5); }
}
function allyRespawn(a) {
  a.dead = false; a.hp = 100; a.g.rotation.set(0, 0, 0); a.deadT = 0; a.tgt = null;
  if (G.arena) { a.x = ARENA_A[0] + rand(-2, 3); a.z = rand(-14, 14); } else { a.x = P.pos.x + rand(-4, 4); a.z = P.pos.z + rand(2, 6); }
  a.g.position.set(a.x, 0, a.z); a.g.visible = true;
}
function hurtAlly(a, d, src) {
  if (a.dead) return; a.hp -= d; bloodPuff(a.x, 1.2, a.z); a.flashT = .25;
  if (a.hp <= 0) { a.dead = true; a.deadT = 0; a.respT = G.arena ? 6 : 12; a.fallA = src ? Math.atan2(a.x - src.x, a.z - src.z) : 0; feedLine('YAPAY ZEKA ASKER DÜŞTÜ', ''); if (G.mode === 'tdm') tdmScore('B'); if (src && src.type) aiKill(src); }
}
function allyHit(e, d, from, by) {
  if (e.dead) return; e.hp -= d; e.alert = true; if (e.hp <= 0) killEnemy(e, { from, ally: true, by });
}
function updateAllies(dt) {
  for (const a of allies) {
    if (a.tag) { a.tag.sp.visible = !a.dead; if (!a.dead) tagUpd(a, true); }
    if (a.dead) {
      a.deadT += dt; const k = Math.min(1, a.deadT * 2.4); a.g.rotation.set(0, 0, 0); a.g.rotation.y = a.yaw; a.g.rotateOnWorldAxis(_ap.set(Math.cos(a.fallA), 0, -Math.sin(a.fallA)), 1.5 * k); a.g.position.set(a.x, .1 * k, a.z);
      a.respT -= dt; if (a.respT <= 0 && (G.arena || !G.waveActive || a.respT < -6)) allyRespawn(a); continue;
    }
    // target: nearest enemy with a clear line, else nearest at all
    a.tgtT -= dt; if (a.tgtT <= 0 || (a.tgt && a.tgt.dead)) {
      a.tgtT = .35; let best = null, bd = 1e9, bl = null, bld = 1e9;
      for (const e of enemies) { if (e.dead) continue; const d = Math.hypot(e.x - a.x, e.z - a.z); if (d < bd) { bd = d; best = e; } if (d < 55 && d < bld && !blocked(a.x, 1.3, a.z, e.x, e.type === 'tank' ? 2 : 1.2, e.z)) { bld = d; bl = e; } }
      a.tgt = bl || best; a.los = !!bl;
    }
    const t = a.tgt && !a.tgt.dead ? a.tgt : null, td = t ? Math.hypot(t.x - a.x, t.z - a.z) : 0;
    const pd = Math.hypot(P.pos.x - a.x, P.pos.z - a.z);
    // movement
    let mx = 0, mz = 0, sp = 3.9, face = a.yaw;
    a.strafeT -= dt; if (a.strafeT <= 0) { a.strafeDir = Math.random() < .5 ? -1 : 1; a.strafeT = rand(1, 2.6); }
    if (t) { const fx = (t.x - a.x) / (td || 1), fz = (t.z - a.z) / (td || 1); face = Math.atan2(fx, fz);
      if (a.los) { const want = td > 26 ? 1 : td < 10 ? -.7 : 0; mx = fx * want - fz * a.strafeDir * .55; mz = fz * want + fx * a.strafeDir * .55; }
      else if (pd < 38) { mx = fx; mz = fz; } }
    if (pd > 9 && (!a.los || pd > 30)) { const fx = (P.pos.x - a.x) / pd, fz = (P.pos.z - a.z) / pd; mx = mx * .3 + fx; mz = mz * .3 + fz; if (!t) face = Math.atan2(fx, fz); }
    else if (!t && pd < 4) { mx = (a.x - P.pos.x) * .3; mz = (a.z - P.pos.z) * .3; }
    if (a.avoidT > 0) { a.avoidT -= dt; const fx = mx, fz = mz; mx = -fz * a.avoidDir + fx * .2; mz = fx * a.avoidDir + fz * .2; }
    const ml = Math.hypot(mx, mz); if (ml > 1) { mx /= ml; mz /= ml; }
    const ox = a.x, oz = a.z; _ap.set(a.x, 0, a.z); moveEntity(_ap, mx * sp * dt, mz * sp * dt, .45, 0, false); a.x = _ap.x; a.z = _ap.z;
    a.chkT += dt; if (a.chkT > .8) { const moved = Math.hypot(a.x - a.lastX, a.z - a.lastZ); if (ml > .3 && moved < .8) { a.avoidT = 1.2; a.avoidDir = Math.random() < .5 ? -1 : 1; } a.lastX = a.x; a.lastZ = a.z; a.chkT = 0; }
    a.yaw += clamp(angDiff(a.yaw, face), -7 * dt, 7 * dt); a.g.rotation.set(0, a.yaw, 0);
    const mv = Math.hypot(a.x - ox, a.z - oz) / dt; a.walk += mv * dt * 2.2; const sw = Math.sin(a.walk) * .7 * Math.min(1, mv / 2); a.legs[0].rotation.x = sw; a.legs[1].rotation.x = -sw; a.g.position.set(a.x, Math.abs(Math.cos(a.walk)) * .03 * Math.min(1, mv / 2), a.z);
    // shooting
    if (t && a.los && td < 55) {
      a.fireT -= dt;
      if (a.fireT <= 0) {
        if (a.burst <= 0) a.burst = randi(3, 6); a.burst--;
        const mox = a.x + Math.sin(a.yaw) * .6, moz = a.z + Math.cos(a.yaw) * .6, ty = t.type === 'tank' ? 1.8 : 1.15, hitP = clamp(.5 - td * .009, .1, .42) * (t.type === 'tank' ? .8 : 1);
        const hit = Math.random() < hitP, jx = hit ? 0 : rand(-1.2, 1.2), jz = hit ? 0 : rand(-1.2, 1.2);
        tracer(mox, 1.3, moz, t.x + jx, ty + (hit ? 0 : rand(-.4, .4)), t.z + jz, 0x7ac8ff, 220); muzzleFx(mox, 1.3, moz, .6); SND.shot('rifle', a.x, a.z);
        if (hit) { const dm = (t.type === 'tank' ? 4 : t.type === 'heavy' ? 11 : 15) * (1 + (DIFFS.indexOf(DIFF) * .0)); allyHit(t, a.gdm && ggOn() ? a.gdm * 1.4 : dm, { x: a.x, z: a.z }, a); }
        a.fireT = a.burst > 0 ? (a.gri || .14) : rand(.9, 2);
      }
    }
  }
}
// ---------- arena modes ----------
function tdmScore(team) {
  if (G.mode !== 'tdm' || G.arenaEnd) return; if (team === 'A') G.tdmA++; else G.tdmB++; arenaHud();
  if (G.tdmA >= G.tdmGoal) { G.arenaEnd = true; setTimeout(() => { if (G.state === 'playing') winGame(); }, 900); }
  else if (G.tdmB >= G.tdmGoal) { G.arenaEnd = true; setTimeout(() => { if (G.state === 'playing') gameOver('YENİLDİN', 'Takım geri çekildi'); }, 900); }
}
function arenaHud() { if (G.mode === 'tdm') setT(H.wave, 'TAKIM ' + G.tdmA + '  —  ' + G.tdmB + ' DÜŞMAN · İLK ' + G.tdmGoal); }
function arenaStart() {
  G.arena = true; G.arenaEnd = false; G.tdmA = 0; G.tdmB = 0; G.tdmGoal = 30; G.botT = []; G.botCarry = []; P.protT = 0;
  const nb = 4; for (let i = 0; i < nb; i++) spawnBot(i);
  P.pos.set(ARENA_A[0], 0, 0); P.yaw = -Math.PI / 2; P.pitch = 0; arenaHud();
}
function spawnBot(i) { const heavy = false && DIFF.hp >= 2 && Math.random() < .2; spawnEnemy(heavy ? 'heavy' : 'soldier', [ARENA_B[0] + rand(-3, 3), rand(-18, 18)]); }
function updateArena(dt) {
  if (G.arenaEnd) return;
  const alive = enemies.filter(e => !e.dead).length + G.botT.length;
  if (alive < 4) G.botT.push(3.2 + Math.random() * 1.5);
  for (let i = G.botT.length - 1; i >= 0; i--) { G.botT[i] -= dt; if (G.botT[i] <= 0) { G.botT.splice(i, 1); spawnBot(); } }
  P.protT = Math.max(0, (P.protT || 0) - dt);
  setT(H.left, G.mode === 'tdm' ? 'ARENA · HEDEF ' + G.tdmGoal : 'ARENA · SİLAH OYUNU');
  setT(H.score, String(G.score));
}
function respawnPlayer() {
  P.dead = false; P.deadT = 0; P.hp = P.maxHp; P.armor = Math.max(P.armor, 0); P.pos.set(ARENA_A[0] + rand(-2, 3), 0, rand(-12, 12)); P.yaw = -Math.PI / 2; P.pitch = 0; P.vx = P.vz = P.vy = 0; P.protT = 2.5; P.eyeH = EYE; P.stance = 0;
  canvas.style.filter = ''; $('fade').style.transition = 'none'; $('fade').style.opacity = 0; for (const s of P.ws) s.reserve += 20;
  const s = P.ws[P.cur]; if (s) s.ammo = WS(P.cur).mag; P.swT = .45; P.nextWeap = P.cur; hudHealth(); hudAmmo(); message('YENİDEN DOĞDUN', 'KORUMA 2 SN');
}

// ---------- ai gun-game levels + name/health tags ----------
function makeTag() {
  const c = document.createElement('canvas'); c.width = 160; c.height = 56; const tex = new THREE.CanvasTexture(c);
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, depthTest: false, transparent: true })); sp.scale.set(2.4, .84, 1); sp.position.y = 2.35; sp.renderOrder = 10;
  return { c, ctx: c.getContext('2d'), tex, sp, key: '' };
}
function tagUpd(f, ally) {
  const t = f.tag; if (!t) return; const frac = ally ? clamp(f.hp / 100, 0, 1) : 0, nm = ggOn() && f.ggLv !== undefined ? GG[f.ggLv].n : '';
  const key = nm + '|' + Math.round(frac * 20) + '|' + (f.flashT > 0 ? 1 : 0); if (f.flashT > 0) f.flashT -= .016; if (key === t.key) return; t.key = key;
  const x = t.ctx; x.clearRect(0, 0, 160, 56); x.textAlign = 'center';
  if (nm) { x.font = 'bold 20px sans-serif'; x.lineWidth = 4; x.strokeStyle = 'rgba(0,0,0,.8)'; x.strokeText(nm, 80, 22); x.fillStyle = ally ? '#9fd4ff' : '#ff9a80'; x.fillText(nm, 80, 22); }
  if (ally) { x.fillStyle = 'rgba(0,0,0,.65)'; x.fillRect(20, 32, 120, 14); x.fillStyle = frac > .5 ? '#4fc3ff' : frac > .25 ? '#ffc04a' : '#ff4a3a'; x.fillRect(22, 34, 116 * frac, 10); }
  t.tex.needsUpdate = true;
}
function aiSet(f) {
  const w = GG[Math.min(f.ggLv, GG.length - 2)].w; f.gdm = clamp(w.dmg * (w.pellets ? w.pellets * .35 : 1) * .35, 5, 30); f.gri = clamp(w.rate * 1.4, .09, .6);
  if (f.type) f.dmg = f.gdm;
}
function aiInit(f, carry) {
  f.ggLv = carry ? carry.lv : 0; f.ggK = carry ? carry.k : 0; aiSet(f);
  if (!f.tag) { f.tag = makeTag(); f.g.add(f.tag.sp); } f.tag.key = ''; tagUpd(f, !f.type);
}
function aiKill(f) {
  if (!ggOn() || !f || f.ggLv === undefined || f.dead) return;
  f.ggK++; if (f.ggK >= GG_NEED && f.ggLv < GG.length - 2) { f.ggLv++; f.ggK = 0; aiSet(f); if (f.tag) f.tag.key = ''; }
}
