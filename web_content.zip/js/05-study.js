/* منطق مطالعه: ثبت‌ها، فصل‌ها، زنجیره، تحلیل، ضعف‌ها، عقب‌افتادگی‌ها، کارها، دفترچه، حافظه، مرور فاصله‌دار. */
(function () {
  'use strict';
  var App = (window.App = window.App || {});
  var u = App.u;
  var D = App.D;
  var store = App.store;
  var st = (App.study = {});
  var S = function () { return App.S; };
  var RVI = [1, 3, 7, 14];

  st.isStudy = function (l) { return l.k !== 'c'; };
  st.logsOn = function (iso) { return S().logs.filter(function (l) { return l.d === iso; }); };
  st.recent = function (n) {
    var x = u.addDays(u.todayISO(), -n);
    return S().logs.filter(function (l) { return l.d >= x; });
  };
  st.dayStat = function (iso) {
    var a = st.logsOn(iso);
    return { s: u.sum(a.filter(st.isStudy), function (l) { return l.m; }), c: u.sum(a.filter(function (l) { return !st.isStudy(l); }), function (l) { return l.m; }), t: u.sum(a, function (l) { return l.t; }) };
  };
  st.streak = function () {
    var ds = {};
    S().logs.forEach(function (l) { if (st.isStudy(l) && l.m > 0) ds[l.d] = 1; });
    var d = new Date(), n = 0;
    if (!ds[u.iso(d)]) d.setDate(d.getDate() - 1);
    while (ds[u.iso(d)]) { n++; d.setDate(d.getDate() - 1); }
    return n;
  };
  st.longestStreak = function () {
    var days = {};
    S().logs.forEach(function (l) { if (st.isStudy(l)) days[l.d] = 1; });
    var list = Object.keys(days).sort(), best = 0, run = 0, prev = null;
    list.forEach(function (d) {
      run = prev && u.dayDiff(prev, d) === 1 ? run + 1 : 1;
      best = Math.max(best, run);
      prev = d;
    });
    return best;
  };
  st.goalDays = function () {
    var m = {};
    S().logs.forEach(function (l) { if (st.isStudy(l)) m[l.d] = (m[l.d] || 0) + l.m; });
    return Object.keys(m).filter(function (d) { return m[d] >= S().goal; }).length;
  };
  st.daysToKonkur = function () {
    if (!S().cd) return null;
    return Math.ceil((new Date(S().cd + 'T23:59:00') - new Date()) / 864e5);
  };

  // ---- ثبت مطالعه ----
  st.addLog = function (o) {
    var rec = store.cleanLog(o, S().mg);
    if (!rec) return null;
    S().logs.push(rec);
    S().logs.sort(function (a, b) { return a.d < b.d ? -1 : a.d > b.d ? 1 : a.id - b.id; });
    return rec;
  };
  st.delLog = function (id) {
    var i = S().logs.findIndex(function (x) { return String(x.id) === String(id); });
    if (i < 0) return null;
    return S().logs.splice(i, 1)[0];
  };

  // ---- فصل‌ها ----
  st.chKey = function (g, s) { return String(g) + s; };
  st.chCount = function (g, s) {
    var k = st.chKey(g, s);
    if (S().chn && S().chn[k] != null) return S().chn[k];
    var base = D.subMap(g)[s] || 0;
    return base + ((S().extra && S().extra[k]) || 0);
  };
  st.chName = function (g, s, i) {
    if (!i) return 'بدون فصل';
    var custom = (S().cn || {})[st.chKey(g, s) + '|' + i];
    return custom || D.baseTitle(g, s, i) || 'فصل ' + u.pd(i);
  };
  st.setChCount = function (g, s, n) {
    S().chn = S().chn || {};
    S().chn[st.chKey(g, s)] = u.clamp(Math.round(n), 0, D.MAX_CH);
  };
  st.renameCh = function (g, s, i, name) {
    S().cn = S().cn || {};
    var k = st.chKey(g, s) + '|' + i;
    var v = String(name || '').trim().slice(0, 30);
    if (v) S().cn[k] = v; else delete S().cn[k];
  };
  st.chStat = function (g, s, c) {
    var L = S().logs.filter(function (l) { return l.g == g && l.s === s && l.c === c; });
    var A = L.filter(function (l) { return l.ok != null; });
    return {
      sm: u.sum(L.filter(st.isStudy), function (l) { return l.m; }),
      cm: u.sum(L.filter(function (l) { return !st.isStudy(l); }), function (l) { return l.m; }),
      t: u.sum(L, function (l) { return l.t; }),
      ans: u.sum(A, function (l) { return l.t; }),
      ok: u.sum(A, function (l) { return l.ok; })
    };
  };
  // دقت به تفکیک فصل (حداقل تعداد تست برای ارزیابی)
  st.autoWeak = function (min, th) {
    min = min || 10; th = th || 0.6;
    var M = {};
    S().logs.forEach(function (l) {
      if (l.ok == null || !(l.t > 0) || !l.c) return;
      var k = l.g + '|' + l.s + '|' + l.c;
      var o = M[k] = M[k] || { g: l.g, s: l.s, c: l.c, a: 0, ok: 0 };
      o.a += l.t; o.ok += l.ok;
    });
    return Object.keys(M).map(function (k) { return M[k]; })
      .filter(function (o) { return o.a >= min && o.ok / o.a < th; })
      .map(function (o) { return Object.assign({}, o, { p: Math.round(o.ok / o.a * 100) }); })
      .sort(function (a, b) { return a.p - b.p; });
  };
  // فصل‌هایی که بیشترین غلط را داشته‌اند
  st.errRank = function () {
    var M = {};
    S().logs.forEach(function (l) {
      if (l.ok == null || !(l.t > 0) || !l.c) return;
      var k = l.g + '|' + l.s + '|' + l.c;
      var o = M[k] = M[k] || { g: l.g, s: l.s, c: l.c, t: 0, ok: 0 };
      o.t += l.t; o.ok += l.ok;
    });
    return Object.keys(M).map(function (k) {
      var o = M[k];
      return Object.assign({}, o, { wrong: o.t - o.ok, p: Math.round(o.ok / o.t * 100) });
    }).filter(function (o) { return o.wrong > 0; })
      .sort(function (a, b) { return b.wrong - a.wrong || a.p - b.p; }).slice(0, 5);
  };
  st.covOf = function (r) {
    var tot = 0, done = 0, miss = [];
    for (var c = r.a; c <= r.b; c++) {
      tot++;
      var m = u.sum(S().logs.filter(function (l) { return l.s === r.s && l.c === c && st.isStudy(l) && (!r.g || l.g == r.g); }), function (l) { return l.m; });
      if (m > 0) done++; else miss.push(c);
    }
    return { tot: tot, done: done, miss: miss };
  };

  // ---- نقاط ضعف ----
  st.weakRank = function () {
    var R = st.recent(10);
    return App.D.allSubjects().map(function (s) {
      var m = u.sum(R.filter(function (l) { return l.s === s && st.isStudy(l); }), function (l) { return l.m; });
      var e = S().exams.filter(function (x) { return x.s === s; }).slice(-3).map(function (x) { return x.p; });
      var p = e.length ? u.avg(e) : null;
      return { s: s, m: m, p: p, sc: (p === null ? 50 : 100 - p) + (120 - Math.min(m, 120)) / 2 };
    }).sort(function (a, b) { return b.sc - a.sc; });
  };
  st.addWeak = function (o) {
    S().wk = S().wk || [];
    var w = { id: u.uid(), s: u.clip(o.s || '', 40), t: u.clip(String(o.t || '').trim(), 200), v: u.clamp(+o.v || 2, 1, 3), m: u.clamp(+o.m || 10, 0, 100), ok: 0, d: u.todayISO() };
    if (!w.t) return null;
    S().wk.push(w);
    return w;
  };
  st.bumpWeak = function (id, delta) {
    var x = S().wk.find(function (y) { return String(y.id) === String(id); });
    if (!x) return null;
    x.m = u.clamp(x.m + delta, 0, 100);
    (x.h = x.h || []).push({ d: u.todayISO(), m: x.m });
    if (x.m >= 100) { x.ok = 1; x.od = u.todayISO(); }
    return x;
  };
  st.delById = function (list, id) {
    var i = list.findIndex(function (x) { return String(x.id) === String(id); });
    return i < 0 ? null : list.splice(i, 1)[0];
  };

  // ---- کارهای امروز، عقب‌افتادگی، دفترچه، حافظه ----
  st.todosOn = function (iso) { return S().todos.filter(function (x) { return x.d === iso; }); };
  // due: پیگیری (روز فهرست = سررسید)، at: ساعت یادآوری
  st.addTodo = function (text, iso, due, at) {
    var t = String(text || '').trim().slice(0, 200);
    if (!t) return null;
    var o = { id: u.uid(), d: due || iso || u.todayISO(), t: t, o: 0 };
    if (due) { o.due = due; if (at) o.at = at; }
    S().todos.push(o);
    return o;
  };
  st.addBacklog = function (o) {
    var t = String(o.t || '').trim().slice(0, 200);
    if (!t) return null;
    var b = { id: u.uid(), s: u.clip(o.s || '', 40), t: t, u: o.u ? 1 : 0, ok: 0, d: u.todayISO() };
    S().bl.push(b);
    return b;
  };
  st.addJournal = function (k, text) {
    var t = String(text || '').trim().slice(0, 1000);
    if (!t) return null;
    var j = { id: u.uid(), d: u.todayISO(), k: ['p', 'w', 'n'].indexOf(k) >= 0 ? k : 'n', t: t };
    S().jr.push(j);
    return j;
  };
  st.addMemory = function (text) {
    var t = String(text || '').trim().slice(0, 1200);
    if (!t) return null;
    var m = { id: u.uid(), d: u.todayISO(), t: t };
    S().mem = S().mem || [];
    S().mem.push(m);
    return m;
  };

  // ---- مرور فاصله‌دار ----
  st.revDue = function () {
    var t = u.todayISO(), DN = (S().rvd || {})[t] || {}, seen = {}, out = [];
    S().logs.forEach(function (l) {
      if (!st.isStudy(l) || !l.c || !l.s) return;
      RVI.forEach(function (n) {
        var due = u.addDays(l.d, n);
        if (due !== t) return;
        var k = l.g + '|' + l.s + '|' + l.c + '|' + n;
        if (seen[k] || DN[k]) return;
        seen[k] = 1;
        out.push({ k: k, s: l.s, g: l.g, c: l.c, n: n });
      });
    });
    return out;
  };
  st.revDone = function (k) {
    var t = u.todayISO();
    S().rvd = S().rvd || {};
    S().rvd[t] = S().rvd[t] || {};
    S().rvd[t][k] = 1;
  };

  // ---- تحلیل هوشمند (قوانین ساده بر پایه‌ی داده) ----
  st.insights = function () {
    var o = [], R = st.recent(14), w = st.weakRank(), d = st.daysToKonkur();
    var n = new Set(st.recent(7).filter(st.isStudy).map(function (l) { return l.d; })).size;
    o.push(n >= 6 ? '✅ این هفته ' + u.fa(n) + ' روز از ۷ روز درس خوندی؛ ثباتت عالیه.' : '⚠️ این هفته فقط ' + u.fa(n) + ' روز مطالعه ثبت شده؛ ثبات از زمان زیاد مهم‌تره. حتی روز شلوغ ۶۰ دقیقه بخون.');
    var cl = {}, sd = {};
    R.forEach(function (l) { var q = st.isStudy(l) ? sd : cl; q[l.s] = (q[l.s] || 0) + l.m; });
    Object.keys(cl).filter(function (k) { return cl[k] >= 60 && (sd[k] || 0) < cl[k] * 0.5; }).slice(0, 3).forEach(function (k) {
      o.push('📚 «' + k + '»: ' + u.hours(cl[k]) + ' کلاس داشتی ولی مطالعه‌ی خودت کمتر از نصفشه. همون روز ۳۰ تا ۴۵ دقیقه مرور و تست بزن.');
    });
    var z = w.filter(function (x) { return x.m === 0; }).slice(0, 3).map(function (x) { return x.s; });
    if (z.length) o.push('🕳 ۱۰ روز اخیر مطالعه نداشتی: ' + z.join('، '));
    var ex = S().exams;
    if (ex.length > 1) {
      var a = ex.slice(-3).map(function (e) { return e.p; }), x = a[a.length - 1] - a[0];
      o.push(x >= 3 ? '📈 درصد آزمون‌هات رو به بالاست.' : x <= -3 ? '📉 درصد آزمون‌های اخیر افت کرده؛ ببین مشکل از مبحثه یا مدیریت زمان.' : '➖ درصدهات تقریباً ثابته؛ برای جهش، غلط‌هات رو تحلیل کن.');
    }
    var e = ex[ex.length - 1];
    if (e) {
      if (e.c + e.w && e.w / (e.c + e.w) > 0.35) o.push('✘ در آخرین آزمون غلط‌هات زیاد بود؛ با نمره منفی، سؤال مطمئن نیستی رو نزن.');
      if ((e.t - e.c - e.w) / e.t > 0.3) o.push('⬜ بیش از ۳۰٪ سؤال‌ها رو نزدی؛ تست با زمان‌سنج تمرین کن.');
    }
    if (w[0]) o.push('🎯 اولویت امروز: «' + w[0].s + '»' + (w[0].p !== null ? ' (میانگین آزمون ' + u.pct(w[0].p) + ')' : '') + '.');
    var aw0 = st.autoWeak()[0];
    if (aw0) o.push('📉 دقت پایین: ' + aw0.s + ' ' + st.chName(aw0.g, aw0.s, aw0.c) + ' (' + u.pct(aw0.p) + ' از ' + u.fa(aw0.a) + ' تست)');
    var bo = S().bl.filter(function (x) { return !x.ok; });
    if (bo.length) o.push('📌 ' + u.fa(bo.length) + ' کار عقب‌افتاده داری؛ اولویت: «' + bo.slice().sort(function (a, b) { return b.u - a.u; })[0].t + '»');
    var qs = R.filter(function (l) { return l.q; }).map(function (l) { return l.q; });
    if (qs.length >= 3) o.push(u.avg(qs) < 2.3 ? '😞 کیفیت تمرکزت این روزها پایینه؛ جلسه‌ها رو کوتاه‌تر (۴۵ دقیقه) و گوشی رو دور کن.' : '🙂 تمرکزت در جلسه‌ها خوبه؛ ادامه بده.');
    if (d !== null && d > 0) o.push('⏳ ' + u.fa(d) + ' روز تا آزمون مانده؛ روزی حدود ' + u.fa(Math.round(S().goal / 6) / 10) + ' ساعت ادامه بده.');
    return o;
  };

  // پیگیری: هشدارهای کوتاه برای امروز (اولویت با کارهای باز)
  st.followUps = function () {
    var o = [], n = new Date(), nm = n.getHours() * 60 + n.getMinutes();
    var today = u.todayISO(), yday = u.addDays(today, -1);
    var ds = st.dayStat(today), y = st.dayStat(yday);
    if (S().logs.length && !y.s && !y.c && !y.t) o.push('دیروز هیچ ثبتی نداشتی؛ امروز جبران کن 💪');
    if (nm >= 720 && !ds.s && !ds.t) o.push('امروز هنوز مطالعه‌ای ثبت نکرده‌ای. همین الان ۳۰ دقیقه شروع کن ⏱');
    else if (nm >= 1200 && ds.s < S().goal) o.push('تا هدف امروز ' + u.fa(S().goal - ds.s) + ' دقیقه مانده. قبل از خواب ثبت کن 🌙');
    var td = st.todosOn(today).filter(function (x) { return !x.o; });
    if (td.length) o.push(u.fa(td.length) + ' کار امروز انجام نشده: «' + td[0].t + '»');
    var bl = S().bl.filter(function (x) { return !x.ok; }).sort(function (a, b) { return b.u - a.u; });
    if (bl.length) o.push('عقب‌افتاده: «' + bl[0].t + '» (' + bl[0].s + ')');
    if (n.getDay() === 5) o.push('مرور هفته آماده است؛ در تب آمار ببین 📅');
    var hr = n.getHours();
    if (hr >= 19 && !(S().ci || {})[today]) o.push('گزارش پایان روز را ثبت کن 📝');
    var ws = S().wk.filter(function (x) { return !x.ok; }).sort(function (a, b) { return b.v - a.v; });
    if (ws.length) {
      var w0 = ws[0], lh = (w0.h || []).slice(-1)[0], age = Math.floor((Date.now() - new Date((lh ? lh.d : w0.d) + 'T12:00:00')) / 864e5);
      if (age >= 3) o.push('روی ضعف «' + w0.t + '» ' + u.fa(age) + ' روز است کار نکرده‌ای 🎯');
    }
    if (hr >= 18 && !ds.s && st.streak() >= 3) o.push('زنجیره‌ی ' + u.fa(st.streak()) + ' روزه‌ات در خطر است 🔥 امروز حداقل ۳۰ دقیقه بخوان');
    var nmd = App.gamify && App.gamify.nearMedal ? App.gamify.nearMedal() : '';
    if (nmd) o.push(nmd);
    var ue = App.exam && App.exam.upcoming ? App.exam.upcoming()[0] : null;
    if (ue) {
      var R = ue.r || [], cv = R.map(st.covOf), T = u.sum(cv, function (x) { return x.tot; }), Dn = u.sum(cv, function (x) { return x.done; });
      o.push('آزمون «' + ue.n + '» ' + u.fa(App.exam.days(ue)) + ' روز دیگر است' + (T ? ' · ' + u.fa(Math.round(Dn / T * 100)) + '٪ محدوده را خوانده‌ای' : ''));
    }
    var c = App.plan && App.plan.curBlock ? App.plan.curBlock() : null;
    if (c) o.push('الان طبق برنامه: ' + c);
    o.push('کارهایی که انجام دادی را ثبت کن ✍️');
    return o;
  };

  // مرور هفته
  st.weekReview = function () {
    var R = st.recent(7), h = function (x) { return u.fa(+(x / 60).toFixed(1)); };
    var stm = u.sum(R.filter(st.isStudy), function (l) { return l.m; });
    var cm = u.sum(R.filter(function (l) { return !st.isStudy(l); }), function (l) { return l.m; });
    var tt = u.sum(R, function (l) { return l.t; });
    var A = R.filter(function (l) { return l.ok != null; });
    var ans = u.sum(A, function (l) { return l.t; }), ok = u.sum(A, function (l) { return l.ok; });
    var goal = S().goal * 7, by = {};
    R.filter(st.isStudy).forEach(function (l) { by[l.s] = (by[l.s] || 0) + l.m; });
    var top = Object.keys(by).map(function (k) { return [k, by[k]]; }).sort(function (a, b) { return b[1] - a[1]; })[0];
    var low = D.allSubjects().map(function (s) { return [s, by[s] || 0]; }).sort(function (a, b) { return a[1] - b[1]; })[0];
    var w0 = u.addDays(u.todayISO(), -7);
    var ex = S().exams.filter(function (e) { return e.d >= w0; });
    var dn = S().wk.filter(function (x) { return x.ok && x.od && x.od >= w0; }).length;
    var cup = App.gamify ? App.gamify.weekCups(1)[0].c : '';
    var L = ['📖 مطالعه: ' + h(stm) + ' ساعت از هدف ' + h(goal) + ' (' + u.fa(Math.round(stm / goal * 100)) + '٪) ' + cup, '🏫 کلاس: ' + h(cm) + ' ساعت (جدا از مطالعه)', '📝 ' + u.fa(tt) + ' تست' + (ans ? ' · دقت ' + u.fa(Math.round(ok / ans * 100)) + '٪' : '')];
    if (top) L.push('⭐ بیشترین مطالعه: ' + top[0] + ' (' + h(top[1]) + ' ساعت)');
    if (low && low[1] === 0) L.push('🕳 مطالعه‌ی صفر: ' + low[0]);
    if (ex.length) L.push('🧪 ' + u.fa(ex.length) + ' آزمون · میانگین ' + u.fa(Math.round(u.avg(ex.map(function (e) { return e.p; })))) + '٪');
    var a7 = App.plan ? App.plan.adh7() : null;
    if (a7 != null) L.push('📅 پایبندی به برنامه: ' + u.fa(a7) + '٪');
    if (dn) L.push('🎯 ' + u.fa(dn) + ' ضعف رفع شد');
    var sg = [];
    if (stm < goal * 0.6) sg.push('هدف روزانه را کمی کمتر کن یا یک ساعت ثابت برای مطالعه بگذار.');
    if (ans && ok / ans < 0.6) sg.push('روی دقت کار کن: بعد از هر ۱۰ تست، غلط‌ها را مرور کن.');
    if (cm > stm) sg.push('کلاس بیشتر از مطالعه است؛ بعد از هر کلاس ۳۰ دقیقه مرور بگذار.');
    if (a7 != null && a7 < 60) sg.push('برنامه‌ی هفتگی را سبک‌تر کن تا قابل‌انجام باشد.');
    if (!sg.length) sg.push('همین روند را نگه دار و یک ضعف باز را هدف بگیر.');
    return { L: L, sg: sg };
  };
  st.weekText = function () { var w = st.weekReview(); return w.L.join('\n') + '\n' + w.sg.join('\n'); };

  // ماه به ماه (بر پایه‌ی تاریخ شمسی)
  st.monthly = function () {
    var M = {};
    function g(k) { return M[k] = M[k] || { k: k, sm: 0, cm: 0, t: 0, days: {}, ex: [], tz: [] }; }
    function ym(iso) { var j = u.jparts(iso); return j[0] * 100 + j[1]; }
    S().logs.forEach(function (l) {
      var o = g(ym(l.d));
      if (st.isStudy(l)) { o.sm += l.m; o.days[l.d] = 1; } else o.cm += l.m;
      o.t += l.t;
    });
    S().exams.forEach(function (e) { var o = g(ym(e.d)); o.ex.push(e.p); if (e.z) o.tz.push(e.z); });
    return Object.keys(M).map(function (k) { return M[k]; }).sort(function (a, b) { return a.k - b.k; }).map(function (o) {
      return {
        month: u.JM[o.k % 100 - 1] + ' ' + u.pd(Math.floor(o.k / 100)), k: o.k,
        study_hours: +(o.sm / 60).toFixed(1), class_hours: +(o.cm / 60).toFixed(1), tests: o.t,
        active_days: Object.keys(o.days).length, exams: o.ex.length,
        avg_exam_percent: o.ex.length ? Math.round(u.avg(o.ex)) : null, avg_taraz: o.tz.length ? Math.round(u.avg(o.tz)) : null
      };
    });
  };
})();
