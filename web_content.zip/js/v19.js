/* UNKNOWN X V19 — ORION SIGNAL SCANNER. Additive daily mini-expedition. */
(function(){
"use strict";
const sectors=["الشمال","الشمال الشرقي","الشرق","الجنوب الشرقي","الجنوب","الغرب"];
const arrows=["↑","↗","→","↘","↓","←"];
function day(){return typeof todayKey==="function"?todayKey():localDay()}
function localDay(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`}
function sequence(key){let seed=0;for(const c of String(key))seed=(seed*33+c.charCodeAt(0))>>>0;const out=[];for(let i=0;i<3;i++){seed=(seed*1664525+1013904223)>>>0;let n=(seed>>>16)%sectors.length;if(out.length&&n===out[out.length-1])n=(n+2)%sectors.length;out.push(n)}return out}
function normalizeRecord(s){if(!s.v19||typeof s.v19!=="object"||Array.isArray(s.v19))s.v19={};const v=s.v19;v.day=typeof v.day==="string"?v.day:"";v.claimed=typeof v.claimed==="string"?v.claimed:"";v.step=Number.isFinite(Number(v.step))?Math.max(0,Math.min(3,Math.floor(Number(v.step)))):0;return v}
function panel(){const s=normalizeRecord(state),key=day(),done=s.claimed===key,step=s.day===key?s.step:0,seq=sequence(key);return `<section class="v19-scanner" aria-label="رادار الإشارات"><div class="v19-scan-head"><div><span class="eyebrow">V19 · DEEP SIGNAL PROTOCOL</span><h2>رادار الإشارات السرّي</h2><p>التقط ثلاث إشارات مخفية حول أوريون. تتغير مواقعها كل يوم.</p></div><div class="v19-radar" aria-hidden="true"><i></i><b>X</b></div></div><div class="v19-scan-status"><span>الإشارات الملتقطة</span><strong>${done?3:step}/3</strong><div class="v19-track" role="progressbar" aria-valuemin="0" aria-valuemax="3" aria-valuenow="${done?3:step}"><i style="width:${(done?3:step)*100/3}%"></i></div></div><p class="v19-clue" id="v19Clue" aria-live="polite">${done?"اكتمل مسح اليوم! عُد غداً لاكتشاف إشارات جديدة.":`الإشارة ${step+1}: وجّه الرادار نحو ${sectors[seq[step]]}.`}</p><div class="v19-sector-grid">${sectors.map((name,i)=>`<button type="button" class="v19-sector" data-v19-sector="${i}" ${done?"disabled":""} aria-label="الاتجاه ${name}"><span>${arrows[i]}</span><small>${name}</small></button>`).join("")}</div><div class="v19-scan-foot"><span>المكافأة: +35 XP · +10 رصيد</span><small>${done?"المكافأة مستلمة":"المكافأة مرة واحدة يومياً"}</small></div></section>`}
function refresh(){const content=document.getElementById("content");if(content&&content.querySelector(".orion-page")){const old=content.querySelector(".v19-scanner");if(old)old.remove();content.querySelector(".orion-page").insertAdjacentHTML("beforeend",panel())}}
function applyPick(s,n,key){
 const v=normalizeRecord(s);if(v.claimed===key)return {status:"claimed",step:3};
 if(v.day!==key){v.day=key;v.step=0}
 const seq=sequence(key),step=v.step;
 if(!Number.isInteger(Number(n))||Number(n)!==seq[step])return {status:"wrong",step};
 v.step=step+1;
 if(v.step===3){v.claimed=key;s.xp=(Number(s.xp)||0)+35;s.cityCredits=(Number(s.cityCredits)||0)+10;return {status:"complete",step:3}}
 return {status:"correct",step:v.step};
}
function pick(n){const result=applyPick(state,n,day());if(result.status==="wrong"){if(typeof toast==="function")toast("إشارة خاطئة — أعد قراءة اتجاه الرادار");return}if(result.status==="claimed")return;if(result.status==="complete"){if(typeof log==="function")log("V19 · رادار أوريون","تم التقاط الإشارات الثلاث · +35 XP");if(typeof toast==="function")toast("نجاح المسح! +35 XP و+10 رصيد")}if(typeof save==="function")save();refresh()}
const api={panel,sequence,sectors,applyPick,normalizeRecord};if(typeof module!=="undefined"&&module.exports)module.exports=api;
if(typeof window!=="undefined"){const old=window.V18&&window.V18.page;if(old)window.V18.page=function(){return old()+panel()};document.addEventListener("click",e=>{const b=e.target.closest&&e.target.closest("[data-v19-sector]");if(b&&!b.disabled)pick(Number(b.dataset.v19Sector))})}
})();
