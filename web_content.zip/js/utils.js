export const uid=()=>crypto.randomUUID?.()||"id-"+Date.now()+"-"+Math.random().toString(16).slice(2);
export const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
export const formatDuration=s=>{s=Math.max(0,Math.round(s));const m=Math.floor(s/60),r=s%60;return `${m} min${r?` ${r}s`:""}`};
export const today=()=>new Date().toISOString().slice(0,10);
export const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
export const formatDate=iso=>new Intl.DateTimeFormat("pt-PT",{dateStyle:"medium"}).format(new Date(iso));
export function toast(msg){const x=document.createElement("div");x.className="toast";x.textContent=msg;document.body.append(x);setTimeout(()=>x.remove(),2600)}
export const sum=a=>a.reduce((x,y)=>x+y,0);