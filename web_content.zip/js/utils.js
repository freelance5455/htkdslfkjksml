const WS={money:n=>`${Number(n||0).toLocaleString('fr-FR')} FC`,date:d=>new Date(d||Date.now()).toLocaleDateString('fr-FR'),dateTime:d=>new Date(d||Date.now()).toLocaleString('fr-FR'),esc:v=>String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m])),uid:(p='ID')=>`${p}-${Date.now().toString(36)}-${crypto.getRandomValues(new Uint32Array(1))[0].toString(36)}`,initials:n=>(n||'?').split(/\s+/).map(x=>x[0]).join('').slice(0,2).toUpperCase(),toast:t=>{const d=document.createElement('div');d.className='toast';d.textContent=t;document.body.appendChild(d);setTimeout(()=>d.remove(),2800)},download:(name,blob)=>{const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)},csv:(name,rows)=>{const csv='\uFEFF'+rows.map(r=>r.map(x=>`"${String(x??'').replace(/"/g,'""')}"`).join(';')).join('\n');WS.download(name,new Blob([csv],{type:'text/csv;charset=utf-8'}))},json:(name,data)=>WS.download(name,new Blob([JSON.stringify(data,null,2)],{type:'application/json'}))};

async function sha256(value){
  const data=new TextEncoder().encode(String(value??''));
  const digest=await crypto.subtle.digest('SHA-256',data);
  return Array.from(new Uint8Array(digest)).map(b=>b.toString(16).padStart(2,'0')).join('');
}
