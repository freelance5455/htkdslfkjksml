/* ============================================================
   utils.js — shared helpers: math, geometry, textures
   BADAL 3D EXTREME RACING
   ============================================================ */
'use strict';

const AD = {
  clamp(v, a, b) { return v < a ? a : v > b ? b : v; },
  lerp(a, b, t) { return a + (b - a) * t; },
  damp(a, b, k, dt) { return AD.lerp(a, b, 1 - Math.exp(-k * dt)); },
  rand(a, b) { return a + Math.random() * (b - a); },
  randInt(a, b) { return Math.floor(AD.rand(a, b + 1)); },
  choice(arr) { return arr[(Math.random() * arr.length) | 0]; },
  sign(v) { return v < 0 ? -1 : 1; },

  seeded(seed) {
    let s = seed >>> 0;
    return function () {
      s |= 0; s = (s + 0x6D2B79F5) | 0;
      let t = Math.imul(s ^ (s >>> 15), 1 | s);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  },

  /* transform a geometry in place */
  xform(geo, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0, sx = 1, sy = 1, sz = 1) {
    const m = new THREE.Matrix4();
    const q = new THREE.Quaternion().setFromEuler(new THREE.Euler(rx, ry, rz));
    m.compose(new THREE.Vector3(x, y, z), q, new THREE.Vector3(sx, sy, sz));
    geo.applyMatrix4(m);
    return geo;
  },

  /* build a merge-part from geometry + color + transform */
  P(geo, color, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0, sx = 1, sy = 1, sz = 1) {
    AD.xform(geo, x, y, z, rx, ry, rz, sx, sy, sz);
    return { geo, color };
  },

  paint(geo, color) {
    const c = new THREE.Color(color);
    const n = geo.attributes.position.count;
    const arr = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) { arr[i * 3] = c.r; arr[i * 3 + 1] = c.g; arr[i * 3 + 2] = c.b; }
    geo.setAttribute('color', new THREE.BufferAttribute(arr, 3));
    return geo;
  },

  merge(parts) {
    const geos = [];
    for (const p of parts) {
      let g = p.geo.index ? p.geo.toNonIndexed() : p.geo.clone();
      if (!g.attributes.normal) g.computeVertexNormals();
      if (p.color !== undefined) AD.paint(g, p.color);
      if (!g.attributes.uv) {
        const n = g.attributes.position.count;
        g.setAttribute('uv', new THREE.BufferAttribute(new Float32Array(n * 2), 2));
      }
      geos.push(g);
    }
    let total = 0;
    for (const g of geos) total += g.attributes.position.count;
    const pos = new Float32Array(total * 3);
    const nor = new Float32Array(total * 3);
    const uv = new Float32Array(total * 2);
    const col = new Float32Array(total * 3);
    let o = 0;
    for (const g of geos) {
      const n = g.attributes.position.count;
      pos.set(g.attributes.position.array, o * 3);
      nor.set(g.attributes.normal.array, o * 3);
      uv.set(g.attributes.uv.array, o * 2);
      if (g.attributes.color) col.set(g.attributes.color.array, o * 3);
      else col.fill(1, o * 3, (o + n) * 3);
      o += n;
    }
    const out = new THREE.BufferGeometry();
    out.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    out.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
    out.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
    out.setAttribute('color', new THREE.BufferAttribute(col, 3));
    out.computeBoundingSphere();
    for (const g of geos) g.dispose();
    for (const p of parts) if (p.geo) p.geo.dispose();
    return out;
  },

  /* box with tapered top (car cabins / hoods) */
  taperBox(w, h, d, topX = 1, topZ = 1, shiftX = 0, shiftZ = 0) {
    const g = new THREE.BoxGeometry(w, h, d);
    const p = g.attributes.position;
    for (let i = 0; i < p.count; i++) {
      if (p.getY(i) > 0) {
        p.setX(i, p.getX(i) * topX + shiftX);
        p.setZ(i, p.getZ(i) * topZ + shiftZ);
      }
    }
    g.computeVertexNormals();
    return g;
  },

  disposeObject(root) {
    if (!root) return;
    root.traverse((o) => {
      if (o.geometry) o.geometry.dispose();
      if (o.material) {
        const mats = Array.isArray(o.material) ? o.material : [o.material];
        for (const m of mats) {
          if (m.map && m.map.dispose) m.map.dispose();
          if (m.emissiveMap && m.emissiveMap.dispose) m.emissiveMap.dispose();
          m.dispose();
        }
      }
    });
    if (root.parent) root.parent.remove(root);
  },

  canvasTexture(w, h, draw, repeatX = 1, repeatY = 1) {
    const c = document.createElement('canvas');
    c.width = w; c.height = h;
    draw(c.getContext('2d'), w, h);
    const t = new THREE.CanvasTexture(c);
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.repeat.set(repeatX, repeatY);
    t.anisotropy = 4;
    return t;
  },

  gradientTexture(stops, w = 4, h = 128) {
    return AD.canvasTexture(w, h, (g) => {
      const grd = g.createLinearGradient(0, 0, 0, h);
      for (const [p, c] of stops) grd.addColorStop(p, c);
      g.fillStyle = grd; g.fillRect(0, 0, w, h);
    });
  },

  glowTexture(inner = 'rgba(255,255,255,1)', outer = 'rgba(255,255,255,0)') {
    return AD.canvasTexture(64, 64, (g) => {
      const grd = g.createRadialGradient(32, 32, 1, 32, 32, 31);
      grd.addColorStop(0, inner);
      grd.addColorStop(0.35, inner.replace(/[\d.]+\)$/, '0.55)'));
      grd.addColorStop(1, outer);
      g.fillStyle = grd; g.fillRect(0, 0, 64, 64);
    });
  },

  softShadowTexture() {
    return AD.canvasTexture(64, 128, (g) => {
      const grd = g.createRadialGradient(32, 64, 3, 32, 64, 62);
      grd.addColorStop(0, 'rgba(0,0,0,0.85)');
      grd.addColorStop(0.55, 'rgba(0,0,0,0.4)');
      grd.addColorStop(1, 'rgba(0,0,0,0)');
      g.fillStyle = grd; g.fillRect(0, 0, 64, 128);
    });
  },

  formatTime(sec) {
    sec = Math.max(0, sec);
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return m + ':' + (s < 10 ? '0' : '') + s;
  },
  formatNum(n) { return Math.round(n).toLocaleString('en-US'); },
  pad(n, l = 2) { return String(n).padStart(l, '0'); },

  /* count up for HUD numbers */
  formatSpeed(n) { return String(Math.round(Math.abs(n))); },
};
