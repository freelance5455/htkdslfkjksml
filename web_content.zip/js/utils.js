/**
 * BD BLOOD DONATION - Utility Functions & i18n
 */

// Current language state: 'bn' (Bengali default) or 'en'
let currentLanguage = typeof localStorage !== 'undefined' ? (localStorage.getItem('bd_blood_lang') || 'bn') : 'bn';

export function getLanguage() {
  return currentLanguage;
}

export function setLanguage(lang) {
  currentLanguage = lang;
  if (typeof localStorage !== 'undefined') {
    localStorage.setItem('bd_blood_lang', lang);
  }
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('language_changed', { detail: { lang } }));
  }
}

// Translations dictionary
export const I18N = {
  bn: {
    appName: 'বিডি ব্লাড ডোনেশন',
    tagline: 'রক্তের প্রয়োজনে, পাশে আছি আমরা।',
    developer: 'ইবনা মাহমুদ রবিন',
    devEmail: 'robinokh@gmail.com',
    emergency: 'জরুরি রক্ত প্রয়োজন!',
    home: 'হোম',
    findDonors: 'রক্তদাতা',
    bloodRequests: 'অনুরোধ',
    notifications: 'নোটিফিকেশন',
    profile: 'প্রোফাইল',
    searchDonor: 'রক্তদাতা খুঁজুন',
    requestBlood: 'রক্তের আবেদন',
    emergencyRequest: 'জরুরি আবেদন',
    availableDonors: 'উপলব্ধ রক্তদাতা',
    recentRequests: 'সাম্প্রতিক আবেদন',
    available: 'রক্তদানে প্রস্তুত',
    notAvailable: 'আপাতত অনুপলব্ধ',
    donations: 'বার রক্তদান',
    rating: 'রেটিং',
    bags: 'ব্যাগ',
    hospital: 'হাসপাতাল',
    requiredDate: 'প্রয়োজনের তারিখ',
    callNow: 'কল করুন',
    chat: 'মেসেজ করুন',
    accept: 'রক্ত দিতে চাই',
    cancel: 'বাতিল',
    confirm: 'নিশ্চিত করুন',
    save: 'সংরক্ষণ করুন',
    submit: 'সাবমিট করুন',
    login: 'লগইন করুন',
    register: 'রেজিস্ট্রেশন করুন',
    logout: 'লগআউট',
    forgotPassword: 'পাসওয়ার্ড ভুলে গেছেন?'
  },
  en: {
    appName: 'BD BLOOD DONATION',
    tagline: 'Standing together when blood is needed.',
    developer: 'Ibna Mahmud Robin',
    devEmail: 'robinokh@gmail.com',
    emergency: 'Emergency Blood Needed!',
    home: 'Home',
    findDonors: 'Find Donors',
    bloodRequests: 'Requests',
    notifications: 'Notifications',
    profile: 'Profile',
    searchDonor: 'Search Donor',
    requestBlood: 'Request Blood',
    emergencyRequest: 'Emergency Request',
    availableDonors: 'Available Donors',
    recentRequests: 'Recent Requests',
    available: 'Available to Donate',
    notAvailable: 'Currently Unavailable',
    donations: 'Donations',
    rating: 'Rating',
    bags: 'Bags',
    hospital: 'Hospital',
    requiredDate: 'Required Date',
    callNow: 'Call Now',
    chat: 'Message',
    accept: 'I Want to Donate',
    cancel: 'Cancel',
    confirm: 'Confirm',
    save: 'Save',
    submit: 'Submit',
    login: 'Login',
    register: 'Register',
    logout: 'Logout',
    forgotPassword: 'Forgot Password?'
  }
};

export function t(key) {
  const lang = currentLanguage;
  if (I18N[lang] && I18N[lang][key]) {
    return I18N[lang][key];
  }
  return I18N.en[key] || key;
}

// Bengali digit conversion
export function toBengaliDigits(num) {
  if (num === null || num === undefined) return '';
  const numStr = String(num);
  if (currentLanguage !== 'bn') return numStr;
  const bnDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  return numStr.replace(/[0-9]/g, (digit) => bnDigits[Number(digit)]);
}

// Bangladesh Phone Number Validation (013, 014, 015, 016, 017, 018, 019)
export function isValidBdPhone(phone) {
  if (!phone) return false;
  const cleaned = phone.replace(/[\s\-\(\)]/g, '');
  // Accepts 017XXXXXXXX or +88017XXXXXXXX or 88017XXXXXXXX
  const bdRegex = /^(?:\+8801|8801|01)[3-9]\d{8}$/;
  return bdRegex.test(cleaned);
}

// Format Phone for display/linking
export function normalizeBdPhone(phone) {
  if (!phone) return '';
  let cleaned = phone.replace(/[\s\-\(\)]/g, '');
  if (cleaned.startsWith('+88')) {
    cleaned = cleaned.substring(3);
  } else if (cleaned.startsWith('88')) {
    cleaned = cleaned.substring(2);
  }
  return cleaned;
}

// Email format validation
export function isValidEmail(email) {
  if (!email) return false;
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email.trim());
}

// Password strength check (min 6 chars, alphanumeric)
export function checkPasswordStrength(password) {
  if (!password || password.length < 6) {
    return { valid: false, messageBn: 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।', messageEn: 'Password must be at least 6 characters.' };
  }
  return { valid: true };
}

// Blood compatibility matrix
export const BLOOD_COMPATIBILITY = {
  'A+': ['A+', 'A-', 'O+', 'O-'],
  'A-': ['A-', 'O-'],
  'B+': ['B+', 'B-', 'O+', 'O-'],
  'B-': ['B-', 'O-'],
  'AB+': ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'], // Universal Recipient
  'AB-': ['AB-', 'A-', 'B-', 'O-'],
  'O+': ['O+', 'O-'],
  'O-': ['O-'] // Universal Donor
};

export function canDonateTo(donorGroup, recipientGroup) {
  const allowed = BLOOD_COMPATIBILITY[recipientGroup] || [];
  return allowed.includes(donorGroup);
}

// Toast notification helper
export function showToast(message, type = 'info', duration = 3500) {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast toast-${type} animate-slide-in`;
  
  let iconHtml = 'ℹ️';
  if (type === 'success') iconHtml = '✓';
  if (type === 'error') iconHtml = '✕';
  if (type === 'warning') iconHtml = '⚠️';

  toast.innerHTML = `
    <span class="toast-icon">${iconHtml}</span>
    <span class="toast-message">${escapeHtml(message)}</span>
    <button class="toast-close" aria-label="Close">&times;</button>
  `;

  toast.querySelector('.toast-close').addEventListener('click', () => {
    toast.remove();
  });

  container.appendChild(toast);

  setTimeout(() => {
    toast.classList.add('toast-fade-out');
    setTimeout(() => toast.remove(), 400);
  }, duration);
}

// Global Modal Dialog
export function showModal({ title, body, confirmText = 'OK', cancelText = '', onConfirm = null, onCancel = null, isDanger = false }) {
  const modalContainer = document.getElementById('modal-container');
  if (!modalContainer) return;

  modalContainer.innerHTML = `
    <div class="modal-backdrop"></div>
    <div class="modal-dialog animate-scale-up" role="document">
      <div class="modal-header">
        <h3 class="modal-title">${escapeHtml(title)}</h3>
        <button class="modal-close-btn" id="modal-close" aria-label="Close">&times;</button>
      </div>
      <div class="modal-body">
        ${body}
      </div>
      <div class="modal-footer">
        ${cancelText ? `<button class="btn btn-secondary" id="modal-btn-cancel">${escapeHtml(cancelText)}</button>` : ''}
        <button class="btn ${isDanger ? 'btn-danger' : 'btn-primary'}" id="modal-btn-confirm">${escapeHtml(confirmText)}</button>
      </div>
    </div>
  `;

  modalContainer.classList.remove('hidden');

  const cleanup = () => {
    modalContainer.classList.add('hidden');
    modalContainer.innerHTML = '';
  };

  const closeBtn = document.getElementById('modal-close');
  if (closeBtn) {
    closeBtn.addEventListener('click', () => {
      cleanup();
      if (onCancel) onCancel();
    });
  }

  const cancelBtn = document.getElementById('modal-btn-cancel');
  if (cancelBtn) {
    cancelBtn.addEventListener('click', () => {
      cleanup();
      if (onCancel) onCancel();
    });
  }

  const confirmBtn = document.getElementById('modal-btn-confirm');
  if (confirmBtn) {
    confirmBtn.addEventListener('click', async () => {
      if (onConfirm) {
        await onConfirm();
      }
      cleanup();
    });
  }
}

export function closeModal() {
  const modalContainer = document.getElementById('modal-container');
  if (modalContainer) {
    modalContainer.classList.add('hidden');
    modalContainer.innerHTML = '';
  }
}

// HTML escape helper
export function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

// Relative time formatting
export function formatTimeAgo(dateInput) {
  if (!dateInput) return '';
  const date = dateInput.toDate ? dateInput.toDate() : new Date(dateInput);
  const now = new Date();
  const diffSec = Math.floor((now - date) / 1000);

  const isBn = currentLanguage === 'bn';

  if (diffSec < 60) return isBn ? 'এইমাত্র' : 'Just now';
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return isBn ? `${toBengaliDigits(diffMin)} মিনিট আগে` : `${diffMin}m ago`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return isBn ? `${toBengaliDigits(diffHr)} ঘণ্টা আগে` : `${diffHr}h ago`;
  const diffDays = Math.floor(diffHr / 24);
  if (diffDays < 30) return isBn ? `${toBengaliDigits(diffDays)} দিন আগে` : `${diffDays}d ago`;
  
  return formatDate(date);
}

export function formatDate(dateInput) {
  if (!dateInput) return '';
  const date = dateInput.toDate ? dateInput.toDate() : new Date(dateInput);
  const isBn = currentLanguage === 'bn';
  
  const options = { year: 'numeric', month: 'short', day: 'numeric' };
  const str = date.toLocaleDateString(isBn ? 'bn-BD' : 'en-US', options);
  return isBn ? toBengaliDigits(str) : str;
}
