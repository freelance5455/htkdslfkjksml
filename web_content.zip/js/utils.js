/**
 * utils.js — funções compartilhadas por todas as páginas.
 */
function refreshIcons(){
  if(window.lucide) lucide.createIcons();
}

function iniciais(nome){
  return (nome||'').split(' ').filter(Boolean).slice(0,2).map(p=>p[0].toUpperCase()).join('');
}

function formatarData(dataISO){
  if(!dataISO) return '—';
  const d = new Date(dataISO);
  if(isNaN(d)) return dataISO;
  return d.toLocaleDateString('pt-BR');
}

function formatarCpf(cpf){
  if(!cpf) return 'Não informado';
  const digitos = String(cpf).replace(/\D/g,'');
  if(digitos.length !== 11) return cpf;
  return digitos.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
}

/**
 * Lê um arquivo de imagem e devolve um data URL JPEG redimensionado/comprimido
 * (evita estourar a cota do localStorage com fotos de câmera em alta resolução).
 * Se o arquivo não for imagem (ex.: PDF) ou o canvas falhar por qualquer
 * motivo, cai no fallback de leitura crua (FileReader simples).
 */
function comprimirImagem(file){
  const { FOTO_MAX_DIMENSAO_PX, FOTO_QUALIDADE } = window.APP_CONFIG.LIMITES_ARQUIVO;
  return new Promise((resolve, reject) => {
    if(!file.type || !file.type.startsWith('image/')){
      return lerArquivoCru(file).then(resolve).catch(reject);
    }
    const leitor = new FileReader();
    leitor.onerror = () => reject(new Error('Não foi possível ler o arquivo selecionado.'));
    leitor.onload = ev => {
      const img = new Image();
      img.onerror = () => resolve(ev.target.result); // fallback: usa a imagem original
      img.onload = () => {
        try{
          const maior = Math.max(img.width, img.height);
          const escala = maior > FOTO_MAX_DIMENSAO_PX ? FOTO_MAX_DIMENSAO_PX / maior : 1;
          const canvas = document.createElement('canvas');
          canvas.width = Math.round(img.width * escala);
          canvas.height = Math.round(img.height * escala);
          const ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          resolve(canvas.toDataURL('image/jpeg', FOTO_QUALIDADE));
        }catch(e){
          resolve(ev.target.result); // fallback: canvas indisponível — usa original
        }
      };
      img.src = ev.target.result;
    };
    leitor.readAsDataURL(file);
  });
}
function lerArquivoCru(file){
  return new Promise((resolve, reject) => {
    const leitor = new FileReader();
    leitor.onload = ev => resolve(ev.target.result);
    leitor.onerror = () => reject(new Error('Não foi possível ler o arquivo selecionado.'));
    leitor.readAsDataURL(file);
  });
}

/** Valida o tamanho de um arquivo (MB) antes de tentar lê-lo/guardá-lo. */
function validarTamanhoArquivo(file, maxMB){
  const mb = file.size / (1024*1024);
  if(mb > maxMB){
    return `Arquivo muito grande (${mb.toFixed(1)}MB). O limite deste ambiente de testes é ${maxMB}MB.`;
  }
  return null;
}

function mostrarToast(msg){
  let t = document.getElementById('toast');
  if(!t){
    t = document.createElement('div');
    t.className = 'toast';
    t.id = 'toast';
    document.body.appendChild(t);
  }
  t.innerText = msg;
  t.classList.add('show');
  clearTimeout(window._toastTimeout);
  window._toastTimeout = setTimeout(()=> t.classList.remove('show'), 2600);
}

/** Mostra a tag "DEV" no canto da tela quando ENV !== 'prod'. */
function mostrarEnvTag(){
  if(window.APP_CONFIG && window.APP_CONFIG.ENV !== 'prod'){
    const tag = document.createElement('div');
    tag.className = 'env-tag';
    tag.innerText = 'AMBIENTE DEV';
    document.body.appendChild(tag);
  }
}

/** Preenche o rodapé de navegação/perfil com o nome do usuário logado, se houver. */
function aplicarSessaoNoCabecalho(){
  const sessao = Auth.getSessao();
  document.querySelectorAll('[data-sessao-nome]').forEach(el => {
    el.innerText = sessao ? sessao.nome : '';
  });
  document.querySelectorAll('[data-sessao-iniciais]').forEach(el => {
    el.innerText = sessao ? iniciais(sessao.nome) : '';
  });
}

/** Atualiza o badge do sino de notificações (se existir na página). */
function atualizarBadgeNotificacoes(userId){
  const badge = document.getElementById('notifBadge');
  if(!badge || !window.NotificationsService) return;
  const qtd = NotificationsService.naoLidas(userId);
  badge.innerText = qtd > 9 ? '9+' : String(qtd);
  badge.classList.toggle('hidden', qtd === 0);
}

/**
 * Página inicial (home) correta para cada tipo de usuário — centralizada aqui
 * para não espalhar mapas "tipo → página" divergentes por vários arquivos.
 * Anfitrião e Morador/Residente reaproveitam toda a base de imóveis/solicitações,
 * mas cada perfil tem sua própria home (home-anfitriao.html / home-morador.html).
 */
function homeDoPerfil(tipoUsuario){
  const destinos = { anfitriao:'home-anfitriao.html', morador:'home-morador.html', profissional:'oportunidades.html', administrador:'admin.html' };
  return destinos[tipoUsuario] || 'index.html';
}

document.addEventListener('DOMContentLoaded', () => {
  mostrarEnvTag();
  refreshIcons();
});
