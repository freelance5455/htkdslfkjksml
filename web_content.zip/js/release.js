/* Release save/submit/status, downloads, per-release loaders */

function routeNoteHandoffText(rel,tracks){
  const lines=[
    'IMPOSED ENTERTAINMENT — INTERNAL DISTRIBUTION HANDOFF',
    'IMPORTANT: INTERNAL STAFF DOCUMENT. Use this as a human-readable checklist; all release details and files must be entered manually in the distributor portal.',
    '',
    'RELEASE DETAILS',
    'Label name: Imposed Entertainment (confirm exact label name registered in RouteNote)',
    `Release title: ${rel.title||''}`,
    `Primary artist: ${rel.artist_name||''}`,
    `Release type: ${rel.release_type||''}`,
    `Genre: ${rel.genre||''}`,
    `Planned release date: ${rel.release_date||'Confirm in RouteNote'}`,
    `C-line: ${rel.c_line||'TO CONFIRM / ENTER'}`,
    `P-line: ${rel.p_line||'TO CONFIRM / ENTER'}`,`Language: ${rel.language||'English'}`,`Previously released: ${rel.previously_released?'Yes, original date '+(rel.original_release_date||'?'):'No'}`,`Artist rights declaration: ${rel.rights_confirmed?'Confirmed':'NOT CONFIRMED'}`,
    `Territory preference: ${rel.territory||'Worldwide'}`,
    `Portal store preferences: ${(Array.isArray(rel.stores)?rel.stores:[]).join(', ')||'Choose in RouteNote'}`,
    '',
    'TRACKS'
  ];
  (tracks||[]).forEach((t,i)=>lines.push(`${i+1}. ${t.title||''}${t.version&&t.version!=='Original'?` (${t.version})`:''}`,`   ISRC: ${t.isrc||'Leave blank if RouteNote should assign / confirm'}`,`   Explicit: ${t.explicit?'YES':'No'}   Featuring: ${t.featured_artists||'-'}   Writers: ${t.songwriters||'-'}`,`   Portal audio filename: ${(t.audio_path||'').split('/').pop()||'Missing'}`));
  lines.push('','MANUAL ROUTENOTE CHECKLIST',
    '[ ] Create or open the release in RouteNote; enter existing UPC only if one is already assigned.',
    '[ ] Enter album details, primary artists, genre, language, original release date, release date, copyright and phonogram lines.',
    '[ ] Download and upload every track individually; enter track titles, versions, artist credits and ISRCs.',
    '[ ] Upload the artwork file.',
    '[ ] Select the actual RouteNote stores and territories. Portal preferences are not synced.',
    '[ ] Review metadata and rights, accept RouteNote terms, then submit to RouteNote moderation.',
    '[ ] Only then mark this release “Sent to distributor” in the portal.',
    '[ ] Mark “Live” only after confirming the release is available on the relevant stores.',
    '',
    'DISTRIBUTOR UPLOAD REQUIREMENTS (check the current official guide before upload)',
    '- Audio: stereo FLAC or MP3; 44.1 kHz; 16-bit FLAC or 320 kbps MP3.',
    '- Artwork: JPG, RGB, exactly 3000 × 3000 px, less than 25 MB.',
    '- Artwork must not contain URLs, contact/social handles, pricing, barcodes or unlicensed/copyrighted imagery.',
    '- Current RouteNote guidance describes release titles up to 15 words and track titles up to 12 words.',
    '',
    'Official references:',
    'https://support.routenote.com/kb-article/how-do-i-create-a-release-on-routenote/',
    'https://support.routenote.com/kb-article/what-are-the-audio-file-requirements/',
    'https://support.routenote.com/kb-article/what-are-the-album-artwork-requirements/',
    'https://support.routenote.com/kb-article/routenote-style-guide/'
  );
  return lines.join('\n');
}

  async function saveProfileName(){const name=prompt('Display name',profile.display_name||''); if(name===null)return; const {data,error}=await sb.from('profiles').update({display_name:name.trim()}).eq('id',profile.id).select().single(); if(error)throw error; profile=data; toast('Profile updated','success'); render();}
  async function createRelease(status='Draft'){ if(busy)return; busy=true; try{validateBasics(); const payload={owner_id:session.user.id,band_id:draft.bandId||null,title:draft.title.trim(),artist_name:draft.artist.trim(),release_type:draft.releaseType,genre:draft.genre,release_date:draft.releaseDate||null,c_line:draft.cLine.trim(),p_line:draft.pLine.trim(),language:draft.language,previously_released:!!draft.prevReleased,original_release_date:draft.prevReleased?(draft.origDate||null):null,rights_confirmed:!!draft.rights,rights_confirmed_at:draft.rights?new Date().toISOString():null,territory:draft.territory,stores:draft.stores,status}; let id=draft.id; const isNew=!id; let res; if(id)res=await sb.from('releases').update(payload).eq('id',id).select().single(); else res=await sb.from('releases').insert(payload).select().single(); if(res.error)throw res.error; id=res.data.id; draft.id=id; if(isNew) await sb.from('release_events').insert({release_id:id,actor_id:session.user.id,event_type:'draft_saved',note:''}); return res.data; } finally{busy=false;} }
  function validateBasics(){if(!draft.title.trim())throw new Error('Release title is required.');if(!draft.artist.trim())throw new Error('Artist / project is required.');}
  async function storageUsage(){ const uid=session.user.id; let total=0; for(const b of ['artwork','audio','documents']){ const {data:dirs}=await sb.storage.from(b).list(uid,{limit:1000}); for(const d of dirs||[]){ const {data:fs}=await sb.storage.from(b).list(`${uid}/${d.name}`,{limit:1000}); (fs||[]).forEach(f=>total+=Number(f.metadata&&f.metadata.size||0)); } } return total; }
  async function showUsage(){ const el=$('#st-usage'); if(!el)return; try{ const u=await storageUsage(), q=QUOTA(), p=Math.min(100,u/q*100); el.innerHTML=isAdmin()?`<b>Label account</b><span>${fmtMB(u)} used. Label uploads are not capped.</span>`:`<b>${fmtMB(u)} of ${fmtMB(q)} used</b><div class="bar"><i style="width:${p}%"></i></div><span>Drafts you delete free their space. Max 50 MB per audio file.</span>`; }catch(e){ el.textContent='Could not read usage.'; } }
  async function saveDraft(){
    if(busy) return false;
    const rel=await createRelease('Draft'); if(!rel) return false;
    busy=true;
    try{
      const id=draft.id, user=rel.owner_id, upd={};
      if(!isAdmin()){ const pend=(draft.artworkFile?draft.artworkFile.size:0)+draft.tracks.reduce((t,x)=>t+(x.file?x.file.size:0),0); if(pend){ const used=await storageUsage(); if(used+pend>QUOTA()) throw new Error(`Not enough storage: ${fmtMB(used)} used of ${fmtMB(QUOTA())}. Delete an old draft or ask the label for more space.`); } }
      if(draft.artworkFile){const ext=(draft.artworkFile.name.split('.').pop()||'jpg').toLowerCase(), p=`${user}/${id}/artwork.${ext}`; const up=await sb.storage.from('artwork').upload(p,draft.artworkFile,{upsert:true,contentType:draft.artworkFile.type}); if(up.error)throw new Error('Artwork upload failed: '+up.error.message); if(draft.artworkPath&&draft.artworkPath!==p) await sb.storage.from('artwork').remove([draft.artworkPath]); draft.artworkPath=p; draft.artworkFile=null; upd.artwork_path=p;}
      const rows=[];
      for(let i=0;i<draft.tracks.length;i++){const t=draft.tracks[i]; let path=t.path||null;
        if(t.file){const ext=(t.file.name.split('.').pop()||'wav').toLowerCase(); path=`${user}/${id}/track-${String(i+1).padStart(2,'0')}.${ext}`; const u=await sb.storage.from('audio').upload(path,t.file,{upsert:true,contentType:t.file.type||'audio/mpeg'}); if(u.error)throw new Error(`Audio upload failed for track ${i+1}: `+u.error.message); if(t.path&&t.path!==path) await sb.storage.from('audio').remove([t.path]); t.path=path; t.file=null;}
        rows.push({release_id:id,track_number:i+1,title:t.title.trim()||'Untitled track',version:t.version.trim(),isrc:t.isrc.trim(),explicit:!!t.explicit,featured_artists:(t.featured||'').trim(),songwriters:(t.writers||'').trim(),audio_path:path});}
      const oldRows=await sb.from('release_tracks').select('id').eq('release_id',id); if(oldRows.error)throw new Error('Could not read tracks: '+oldRows.error.message);
      if(rows.length){const tr=await sb.from('release_tracks').insert(rows); if(tr.error)throw new Error('Could not save tracks: '+tr.error.message);}
      const oldIds=(oldRows.data||[]).map(x=>x.id); if(oldIds.length){const d=await sb.from('release_tracks').delete().in('id',oldIds); if(d.error)throw new Error('Could not replace old tracks: '+d.error.message);}
      try{ const dir=`${user}/${id}`, keep=new Set(rows.map(x=>x.audio_path).filter(Boolean)); const {data:fl}=await sb.storage.from('audio').list(dir); const orphan=(fl||[]).map(f=>`${dir}/${f.name}`).filter(p=>!keep.has(p)); if(orphan.length) await sb.storage.from('audio').remove(orphan); }catch(_){}
      if(Object.keys(upd).length){const ur=await sb.from('releases').update(upd).eq('id',id); if(ur.error)throw new Error('Could not link artwork: '+ur.error.message);}
      await loadReleases(); return true;
    }catch(e){console.error(e);toast(e.message||'Could not save draft','error');return false;}
    finally{busy=false;}
  }
  async function openDraft(id){
    const r=releases.find(x=>x.id===id); if(!r)return;
    const {data,error}=await sb.from('release_tracks').select('*').eq('release_id',id).order('track_number'); if(error)return toast(error.message,'error');
    draft={id:r.id,title:r.title||'',artist:r.artist_name||'',bandId:r.band_id||'',releaseType:r.release_type||'Single',genre:r.genre||'Rock',releaseDate:r.release_date||'',cLine:r.c_line||'',pLine:r.p_line||'',language:r.language||'English',prevReleased:!!r.previously_released,origDate:r.original_release_date||'',rights:!!r.rights_confirmed,territory:r.territory||'Worldwide',stores:Array.isArray(r.stores)?r.stores:[...STORES],artworkFile:null,artworkPreview:'',artworkPath:r.artwork_path||'',tracks:(data&&data.length?data:[null]).map(t=>t?{title:t.title==='Untitled track'?'':t.title,version:t.version||'',isrc:t.isrc||'',explicit:!!t.explicit,featured:t.featured_artists||'',writers:t.songwriters||'',file:null,fileName:'',path:t.audio_path||'',duration:null}:newTrack()),status:'Draft'};
    wizardStep=1; view='builder'; render();
  }
  async function submitRelease(){
    if(busy) return;
    try{
      validateBasics();
      if(!draft.releaseDate)throw new Error('Release date is required before submission.');
      if(!draft.stores.length)throw new Error('Select at least one store.');
      if(!draft.rights)throw new Error('Please confirm the rights declaration before submitting.');
      if(draft.prevReleased&&!draft.origDate)throw new Error('Add the original release date, or untick Previously released.');
      if(draft.tracks.some(t=>!(t.writers||'').trim()))throw new Error('Every track needs its songwriter / composer credit.');
      if(!draft.artworkFile&&!draft.artworkPath)throw new Error('Artwork is required.');
      if(!draft.tracks.length||draft.tracks.some(t=>!t.title.trim()||(!t.file&&!t.path)))throw new Error('Every track needs a title and audio file.');
      if(rnProblems().length)throw new Error(rnProblems()[0]);
      if(!(await saveDraft())) return;
      busy=true;
      const releaseId=draft.id, user=session.user.id;
      const metadata={schema:'imposed-entertainment/v1',release:{title:draft.title,artist:draft.artist,releaseType:draft.releaseType,genre:draft.genre,releaseDate:draft.releaseDate,cLine:draft.cLine,pLine:draft.pLine,language:draft.language,previouslyReleased:!!draft.prevReleased,originalReleaseDate:draft.origDate||null,rightsConfirmed:!!draft.rights,territory:draft.territory,stores:draft.stores},tracks:draft.tracks.map((t,i)=>({number:i+1,title:t.title,version:t.version,isrc:t.isrc,explicit:!!t.explicit,featuredArtists:t.featured||'',songwriters:t.writers||'',fileName:t.fileName||(t.path||'').split('/').pop()}))};
      const metaPath=`${user}/${releaseId}/metadata.json`;
      const mu=await sb.storage.from('documents').upload(metaPath,new Blob([JSON.stringify(metadata,null,2)],{type:'application/json'}),{upsert:true,contentType:'application/json'}); if(mu.error)throw new Error('Metadata upload failed: '+mu.error.message);
      const ur=await sb.from('releases').update({artwork_path:draft.artworkPath,metadata_path:metaPath,status:'Submitted'}).eq('id',releaseId); if(ur.error)throw new Error('Could not mark submitted: '+ur.error.message);
      await sb.from('release_events').insert({release_id:releaseId,actor_id:user,event_type:'submitted',note:'Release submitted with artwork, audio and metadata.'});
      toast('Release submitted to Imposed Entertainment','success'); await loadReleases(); view=backTarget(); draft=freshDraft(); wizardStep=1; render();
    }catch(e){console.error(e);toast(e.message||'Submission failed','error');}finally{busy=false;}
  }

  async function setStatus(id,status,note=''){const {error}=await sb.from('releases').update({status,review_note:(status==='Changes Requested'||status==='Rejected')?note:null}).eq('id',id);if(error)throw error;await sb.from('release_events').insert({release_id:id,actor_id:session.user.id,event_type:status.toLowerCase().replaceAll(' ','_'),note});await loadReleases();selected=releases.find(x=>x.id===id)||selected;toast(`Release marked ${status.toLowerCase()}`,'success');render();if(view==='release')loadTracks();}
  const safeName=x=>String(x||'').replace(/[\\/:*?"<>|]+/g,'').trim();
  const fileExt=p=>(String(p||'').split('.').pop()||'').toLowerCase();
  function metaText(r,tr){const L=['RELEASE',`Title: ${r.title}`,`Primary artist: ${r.artist_name}`,`Release type: ${r.release_type}`,`Release date: ${r.release_date||''}`,`Genre: ${r.genre||''}`,`Territory: ${r.territory||''}`,`C-line: ${r.c_line||''}`,`P-line: ${r.p_line||''}`,`Language: ${r.language||''}`,`Previously released: ${r.previously_released?'Yes, '+(r.original_release_date||''):'No'}`,`Rights confirmed: ${r.rights_confirmed?'Yes':'No'}`,'','TRACKS'];tr.forEach(t=>L.push(`${t.track_number}. ${t.title}${t.version&&t.version!=='Original'?` (${t.version})`:''} | ISRC: ${t.isrc||''} | Explicit: ${t.explicit?'Yes':'No'} | Featuring: ${t.featured_artists||''} | Writers: ${t.songwriters||''}`));return L.join('\n');}
  async function copyText(t){try{await navigator.clipboard.writeText(t);toast('Copied to clipboard','success');}catch(_){window.prompt('Copy this text',t);}}
  async function download(bucket,path,name){const {data,error}=await sb.storage.from(bucket).createSignedUrl(path,300,{download:name});if(error)throw error;const a=document.createElement('a');a.href=data.signedUrl;a.download=name;document.body.appendChild(a);a.click();a.remove();toast('Download started','success');}
  async function loadCover(){const r=selected,el=$('.detail-cover');if(!r||!r.artwork_path||!el)return;const {data}=await sb.storage.from('artwork').createSignedUrl(r.artwork_path,600);if(data&&data.signedUrl)el.innerHTML=`<img loading="lazy" decoding="async" src="${esc(data.signedUrl)}" alt="Cover art">`;}
  async function loadEvents(){ if(!selected) return; const el=$('#detail-activity'); if(!el) return; const {data}=await sb.from('release_events').select('*').eq('release_id',selected.id).order('created_at',{ascending:false}); el.innerHTML=(data||[]).map(e=>`<div class="tl-item"><i></i><div><b>${esc(isAdmin()?String(e.event_type||'').replaceAll('_',' '):(e.event_type==='sent_to_distributor'?'processing started':String(e.event_type||'').replaceAll('_',' ')))}</b>${e.note&&(isAdmin()||e.event_type!=='sent_to_distributor')?`<p>${esc(e.note)}</p>`:''}<small>${ago(e.created_at)}</small></div></div>`).join('')||'<div class="muted">No activity yet.</div>'; }
  async function loadTracks(){if(!selected)return;const el=$('#detail-tracks');if(!el)return;loadCover();const {data,error}=await sb.from('release_tracks').select('*').eq('release_id',selected.id).order('track_number');if(error){el.innerHTML=`<div class="error-box">${esc(error.message)}</div>`;return;}detailTracks=data||[];el.innerHTML=(data||[]).map((t,i)=>`<div class="track-summary"><span>${t.track_number}</span><div><b>${esc(t.title)}</b><small>${esc(t.version||'Original')} ${t.isrc?`· ${esc(t.isrc)}`:''}${t.explicit?' · Explicit':''}${t.featured_artists?` · feat. ${esc(t.featured_artists)}`:''}</small></div>${isAdmin()?`<button class=\"copy-btn\" data-action=\"copy\" data-text=\"${esc(t.title)}\">Title</button>${t.isrc?`<button class=\"copy-btn\" data-action=\"copy\" data-text=\"${esc(t.isrc)}\">ISRC</button>`:''}`:''}<span>${t.audio_path?'Audio uploaded':'No audio'}</span>${(isAdmin()||selected.owner_id===session.user.id||selected.band_id)?`<span class="track-tools">${t.audio_path?`<button class="secondary" data-action="dl-audio" data-i="${i}">Download</button>`:''}<button class="copy-btn" data-action="copy" data-text="${esc(`${t.title}${t.version&&t.version!=='Original'?` (${t.version})`:''}${t.isrc?` | ISRC ${t.isrc}`:''}`)}">Copy</button></span>`:''}</div>`).join('')||'<div class="muted">No tracks.</div>'; loadEvents(); loadExtras();}
