"use strict";
const CP_DASH_TEXT={
 fa:{progressHint:"مقایسه پیشرفت واقعی با پیشرفت برنامه‌ای بر اساس اطلاعات ثبت‌شده",activeProject:"پروژه فعال",allProjects:"همه پروژه‌ها",actual:"پیشرفت واقعی",planned:"پیشرفت برنامه‌ای",quickAccess:"مرکز دسترسی سریع",quickAccessHint:"بخش موردنظر را انتخاب کنید؛ محتوا در فضای مرکزی باز می‌شود و با بازگشت به داشبورد برمی‌گردید",modulesCount:"همه بخش‌ها",noProjects:"هنوز پروژه‌ای ثبت نشده است. از بخش پروژه‌ها اولین پروژه را ایجاد کنید.",noTasks:"فعالیت زمان‌بندی‌شده‌ای برای این پروژه ثبت نشده است.",plannedUnknown:"برای محاسبه پیشرفت برنامه‌ای، تاریخ شروع و پایان فعالیت‌ها را وارد کنید.",actualUnknown:"برای محاسبه پیشرفت واقعی، درصد انجام فعالیت‌ها را ثبت کنید.",groupProjects:"پروژه و مشتری",groupPlanning:"برنامه‌ریزی و اجرا",groupMoney:"مالی و قراردادها",groupResources:"منابع و کارگاه",groupInsights:"گزارش و تنظیمات"},
 en:{progressHint:"Compare actual progress with the schedule using recorded task data",activeProject:"Active project",allProjects:"All projects",actual:"Actual progress",planned:"Planned progress",quickAccess:"Quick access center",quickAccessHint:"Choose a module to open it in the main workspace. Use Back to return to the dashboard.",modulesCount:"All modules",noProjects:"No projects yet. Create your first project in Projects.",noTasks:"No scheduled tasks have been recorded for this project.",plannedUnknown:"Add task start and finish dates to calculate planned progress.",actualUnknown:"Record task completion percentages to calculate actual progress.",groupProjects:"Projects & clients",groupPlanning:"Planning & execution",groupMoney:"Finance & contracts",groupResources:"Resources & site",groupInsights:"Reports & settings"},
 ar:{progressHint:"قارن التقدم الفعلي بالمخطط وفق بيانات المهام المسجلة",activeProject:"المشروع النشط",allProjects:"كل المشاريع",actual:"التقدم الفعلي",planned:"التقدم المخطط",quickAccess:"الوصول السريع",quickAccessHint:"اختر وحدة لفتحها في مساحة العمل الرئيسية. استخدم الرجوع للعودة إلى لوحة التحكم.",modulesCount:"كل الوحدات",noProjects:"لا توجد مشاريع بعد. أنشئ أول مشروع من قسم المشاريع.",noTasks:"لا توجد مهام مجدولة لهذا المشروع.",plannedUnknown:"أضف تاريخ بداية ونهاية المهام لحساب التقدم المخطط.",actualUnknown:"سجّل نسب إنجاز المهام لحساب التقدم الفعلي.",groupProjects:"المشاريع والعملاء",groupPlanning:"التخطيط والتنفيذ",groupMoney:"المالية والعقود",groupResources:"الموارد والموقع",groupInsights:"التقارير والإعدادات"}
};
function cpDashText(key){const lang=(typeof d!=='undefined'&&d.lang)||document.documentElement.lang||'en';const custom=(CP_DASH_TEXT[lang]||{})[key];if(custom)return custom;const source=(CP_DASH_TEXT.en&&CP_DASH_TEXT.en[key])||key;return typeof window.cpTr==='function'?window.cpTr(source,lang):source}
function cpDashApplyText(){document.querySelectorAll('[data-cp-dash]').forEach(el=>{el.textContent=cpDashText(el.getAttribute('data-cp-dash'))});const sel=$('dashboardProjectFilter');if(sel&&sel.options.length)sel.options[0].textContent=cpDashText('allProjects')}
const CP_MODULE_GROUPS=[
 {key:'groupProjects',ids:['projects','clients','leads']},
 {key:'groupPlanning',ids:['schedule','dailyLogs','rfis','submittals','punchList','safetyForms','drawings']},
 {key:'groupMoney',ids:['finance','accounts','estimates','contracts','changeOrders','invoices','tenders']},
 {key:'groupResources',ids:['team','timeEntries','materials','inventory','equipment','suppliers','documents']},
 {key:'groupInsights',ids:['reports','smartEstimate','notifications','settings']}
];
function renderDashboard(){
 refreshNotifications();cpDashApplyText();
 const left=$("moduleGridLeft"),right=$("moduleGridRight");if(left)left.innerHTML="";if(right)right.innerHTML="";
 const groups=CP_MODULE_GROUPS.map(g=>({...g,items:g.ids.map(id=>MODS.find(m=>m[0]===id)).filter(Boolean)})).filter(g=>g.items.length);
 groups.forEach((group,index)=>{const host=index%2===0?left:right;if(!host)return;const panel=document.createElement('section');panel.className='cp-module-group';panel.dataset.g=group.key;const h=document.createElement('h4');h.textContent=cpDashText(group.key);panel.appendChild(h);group.items.forEach(([id,ic])=>{const c=document.createElement('button');c.type='button';c.className='cp-module-key';c.dataset.mod=id;c.setAttribute('aria-label',titleOf(id));c.innerHTML=`<span class="cp-module-icon" aria-hidden="true">${ic}</span><span class="cp-module-copy"><strong>${esc(titleOf(id))}</strong><small>${esc(descOf(id))}</small></span><span class="cp-module-arrow" aria-hidden="true">↗</span>`;c.onclick=()=>openModule(id);panel.appendChild(c)});host.appendChild(panel)});
 const filter=$('dashboardProjectFilter');if(filter){const prior=filter.value;filter.innerHTML=`<option value="all">${esc(cpDashText('allProjects'))}</option>`+(d.projects||[]).map(p=>`<option value="${esc(p.id)}">${esc(p.name||cpDashText('Unnamed project'))}</option>`).join('');if([...filter.options].some(o=>o.value===prior))filter.value=prior}
 renderDashboardProgress();
 $("dashProjects").textContent=fmtNum(d.projects.length);$("dashClients").textContent=fmtNum(d.clients.length);
 $("dashIncome").textContent=money(sum(d.finance.filter(x=>x.type==="income"),x=>toBase(x.amount,x.currency)));
 $("dashExpense").textContent=money(sum(d.finance.filter(x=>x.type==="expense"),x=>toBase(x.amount,x.currency)));
 if($("connectedProjects"))$("connectedProjects").textContent=fmtNum(d.projects.length);
 if($("connectedStock"))$("connectedStock").textContent=fmtNum(sum([...stockMap().values()],x=>x.in-x.out));
 if($("connectedTools"))$("connectedTools").textContent=fmtNum(d.equipment.length);
 if($("connectedUnits"))$("connectedUnits").textContent=t(d.unitSystem);
 if($('connectedSync'))$('connectedSync').textContent=(d.sync?.enabled?t('cloudReady'):t('offlineReady'));
 if($('connectedPending'))$('connectedPending').textContent=fmtNum(d.sync?.pending||0);
 const overdueInv=d.invoices.filter(x=>x.status!=="paid"&&x.dueDate&&new Date(x.dueDate)<new Date()).length;
 const overdueTasks=d.schedule.filter(x=>x.status!=="done"&&x.dueDate&&new Date(x.dueDate)<new Date()).length;
 const openChanges=d.changeOrders.filter(x=>!['approved','rejected'].includes(x.status)).length;
 const lowStock=[...stockMap().values()].filter(x=>(x.in-x.out)<=x.minStock).length;
 if($('attentionInvoices'))$('attentionInvoices').textContent=fmtNum(overdueInv);if($('attentionTasks'))$('attentionTasks').textContent=fmtNum(overdueTasks);if($('attentionChanges'))$('attentionChanges').textContent=fmtNum(openChanges);if($('attentionStock'))$('attentionStock').textContent=fmtNum(lowStock);
}
function cpTaskActual(task){if(task.status==='done'||task.status==='completed')return 100;if(task.percentComplete!==undefined&&task.percentComplete!==null&&task.percentComplete!=='')return Math.max(0,Math.min(100,Number(task.percentComplete)||0));if(task.status==='open')return 0;return null}
function cpTaskWeight(task){const n=Number(task.durationDays);if(Number.isFinite(n)&&n>0)return n;const s=task.startDate?new Date(task.startDate):null,e=task.dueDate?new Date(task.dueDate):null;return s&&e&&Number.isFinite(+s)&&Number.isFinite(+e)&&e>=s?Math.max(1,Math.ceil((e-s)/86400000)+1):1}
function cpWeightedPercent(items,valueFn){let total=0,weight=0;items.forEach(item=>{const v=valueFn(item);if(v===null||!Number.isFinite(v))return;const w=cpTaskWeight(item);total+=v*w;weight+=w});return weight?Math.round(total/weight):null}
function cpTaskPlanned(task,now){const start=task.startDate?new Date(task.startDate):null,end=task.dueDate?new Date(task.dueDate):null;if(!start||!end||!Number.isFinite(+start)||!Number.isFinite(+end)||end<start)return null;if(now<start)return 0;if(now>=end)return 100;return Math.max(0,Math.min(100,Math.round(((now-start)/(end-start||1))*100)))}
function renderDashboardProgress(){
 const host=$("dashboardProgress");if(!host)return;
 const projects=Array.isArray(d.projects)?d.projects:[],tasks=Array.isArray(d.schedule)?d.schedule:[],filter=$('dashboardProjectFilter')?.value||'all';
 if(!projects.length){host.innerHTML=`<div class="cp-progress-empty">🏗️ ${esc(cpDashText('noProjects'))}</div>`;return}
 const chosen=filter==='all'?projects:projects.filter(p=>String(p.id)===String(filter));
 const rows=chosen.map(p=>{const list=tasks.filter(x=>String(x.project)===String(p.id));const actual=list.length?cpWeightedPercent(list,cpTaskActual):null;const planned=cpWeightedPercent(list,x=>cpTaskPlanned(x,new Date()));const dated=list.filter(x=>cpTaskPlanned(x,new Date())!==null).length;return{name:String(p.name||cpDashText('Unnamed project')),id:p.id,actual,planned,count:list.length,dated}});
 host.innerHTML=rows.map(x=>`<article class="cp-progress-row"><div class="cp-progress-label"><strong>${esc(x.name)}</strong><span>${x.actual===null?'—':fmtNum(x.actual)+'%'}</span></div>${x.count?`<div class="cp-progress-metric"><span>${esc(cpDashText('actual'))}</span><div class="cp-progress-track" role="progressbar" aria-label="${esc(cpDashText('actual'))}: ${esc(x.name)}" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${x.actual??0}"><span class="cp-bar-actual" style="width:${x.actual??0}%"></span></div></div><div class="cp-progress-metric"><span>${esc(cpDashText('planned'))}</span><div class="cp-progress-track" role="progressbar" aria-label="${esc(cpDashText('planned'))}: ${esc(x.name)}" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${x.planned??0}"><span class="cp-bar-planned" style="width:${x.planned??0}%"></span></div></div><div class="cp-progress-foot">${fmtNum(x.count)} · ${x.actual===null?esc(cpDashText('actualUnknown')):''} ${x.planned===null?esc(cpDashText('plannedUnknown')):fmtNum(x.dated)+' '+cpDashText('dated tasks')}</div>`:`<div class="cp-progress-foot">${esc(cpDashText('noTasks'))}</div>`}</article>`).join('');
}
