// ============================================================
// DOWNLOADS — the ONE place every file (PDF, CSV, TXT) leaves the app.
// Every download ends by asking the phone for a "Download complete"
// notification (see native-bridge.js).
// ============================================================
function downloadBlobFile(filename, blob){
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  if ('download' in a) {
    a.href = url; a.download = filename; a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 3000);
  } else {
    window.open(url, '_blank');                        // very old WebViews
  }
  NativeBridge.notifyDownloaded(filename);             // notification-bar entry (when allowed)
}

function downloadText(filename, mime, text){
  downloadBlobFile(filename, new Blob([text], { type: mime }));
}
