// ---------- Mobile hardware/gesture back-button support ----------
// The phone's back button (or edge-swipe gesture) is the way to go back a
// page, by detecting which page is currently showing and calling that same
// navigation function. The hub's own on-screen "⬅ Back" button (below) does
// NOT appear in this map — it goes through history.back() instead, which
// lands right back here, so both the hardware button and the on-screen one
// always behave identically.
const VIEW_BACK_ACTIONS = {
  groupView: () => showHubView(),
  drillView: () => {
    if (currentGroupType === 'date') { showDateView(); runDateFilter(currentSelectedDateStr); }
    else showGroupView(currentGroupType, currentGroupFacilityLabel);
  },
  searchView: () => showHubView(),
  dateView: () => showHubView(),
  stockView: () => showHubView(),
  qrResultView: () => showHubView(),
  defaulterChildrenView: () => showHubView(),
  defByAddressView: () => showDefaulterChildrenView(),
  defByVaccineView: () => showDefaulterChildrenView(),
  defDetailView: () => {
    if (defDetailReturnTo === 'defByVaccineView') showDefByVaccineView();
    else if (defDetailReturnTo === 'defaulterChildrenView') showDefaulterChildrenView();
    else showDefByAddressView();
  },
  hubView: () => goToMainMenu(),
};

// Upload-view sub-panels that sit outside the hub/group/drill navigation
// stack above and simply toggle their own visibility.
const QR_AND_FILE_PANEL_IDS = ['qrDeleteView', 'qrCodeSection', 'savedFilesSection'];

function activeResultsViewId(){
  return ALL_VIEW_IDS.find(id => { const el = document.getElementById(id); return el && el.style.display !== 'none'; });
}

function goBackOneStep(){
  if (resultsWrap && resultsWrap.style.display !== 'none') {
    const activeId = activeResultsViewId();
    const action = activeId && VIEW_BACK_ACTIONS[activeId];
    if (action) { action(); return true; }
    goToMainMenu();
    return true;
  }
  for (const id of QR_AND_FILE_PANEL_IDS) {
    const el = document.getElementById(id);
    if (el && el.style.display !== 'none') { el.style.display = 'none'; window.scrollTo(0, 0); return true; }
  }
  return false; // Home screen with nothing open — caller (popstate handler below) asks for exit confirmation instead of leaving silently
}

// ---------- Back button: go back INSIDE the app, never exit by accident ----------
//
// How it works: the app keeps a small STACK of "trap" entries on top of the
// browser history (TRAP_BUFFER of them, not just one). The phone's back button
// (or edge-swipe) therefore always lands on one of our own entries instead of
// leaving the app; the handler then steps back one screen (goBackOneStep).
// Only on the very first screen with nothing open does it ask "Do you want to exit?".
//
// WHY A STACK (the "app closes after going back twice" bug): the old version
// kept exactly ONE trap and put a new one back only AFTER the back press had
// been processed. On the big result pages the phone is busy drawing long lists,
// so the second back press could arrive before the new trap existed — the
// phone then saw an empty history and closed the app. Also, Chrome/WebView
// treat history entries that were pushed without a real tap as "skippable",
// which made the same thing happen. Now:
//   • traps are pushed from inside real taps (pointerup / click) — those count
//     as user gestures, so they are never skipped;
//   • up to TRAP_BUFFER traps are stored ahead of time, so even fast repeated
//     back presses always find one;
//   • each entry remembers its own number (idx), so we always know exactly how
//     many steps back were really taken, and duplicate events (popstate +
//     hashchange for one press, echoes of our own pushes) are ignored.
//
// Two fallbacks make this work inside app wrappers (WebView builds):
//   • some WebViews refuse history.pushState → the trap is made with the URL
//     #hash instead (hashMode: "#epi<idx>");
//   • wrappers based on Capacitor/Cordova send the hardware back key as their
//     own event → NativeBridge.onNativeBack() routes it to the same handler
//     (no history involved at all).
const TRAP_BUFFER = 6;       // traps kept ready behind the current page (refilled on every tap)
const TRAP_MIN = 2;          // refilled at once, even without a tap, when fewer than this are left
let exitConfirmed = false;   // true between "Yes, Exit" and the final back press
let exitDialogOpen = false;
let hashMode = false;        // true once history.pushState turned out to be unusable
let navIdx = 0;              // which of OUR history entries is current (0 = the page's own first entry)

// The idx of the history entry the phone is showing right now.
function readNavIdx(){
  if (hashMode) {
    const m = /^#epi(\d+)$/.exec(location.hash || '');
    return m ? parseInt(m[1], 10) : 0;
  }
  const st = history.state;
  return (st && st.epiNav && typeof st.idx === 'number') ? st.idx : 0;
}

// Adds ONE trap entry on top of the current one.
function pushAppNavState(){
  const next = navIdx + 1;
  if (!hashMode) {
    try { history.pushState({ epiNav: true, idx: next }, '', ''); navIdx = next; return true; }
    catch (e) { hashMode = true; }                     // sandboxed / data: pages
  }
  try { navIdx = next; location.hash = '#epi' + next; return true; }
  catch (e) { navIdx = next - 1; return false; }
}

// Makes sure at least `target` trap entries are stored behind the current page.
function topUpTraps(target){
  let guard = 0;
  while (navIdx < target && guard++ < 12) { if (!pushAppNavState()) break; }
}

// One physical back press can fire both "popstate" and "hashchange", and our
// own pushes fire them too — the idx comparison filters all of that out.
function onHistoryBack(ev){
  // popstate carries the state of the very entry that event is about — using it (instead of
  // "whatever is current by now") keeps several quick back presses counted one by one.
  const idx = (!hashMode && ev && ev.type === 'popstate')
    ? ((ev.state && ev.state.epiNav && typeof ev.state.idx === 'number') ? ev.state.idx : 0)
    : readNavIdx();
  if (idx === navIdx) return;                          // echo of our own push / duplicate event
  if (idx > navIdx) { navIdx = idx; return; }          // a "forward" move: nothing to do
  navIdx = idx;                                        // a real step back
  if (exitConfirmed) return;                           // person already said "Yes, Exit"
  if (navIdx < TRAP_MIN) topUpTraps(TRAP_MIN);         // re-arm FIRST, so the next press can't slip through
  // An open dialog (Delete?/Clear All?/Share or Download?/Card or Print?) is
  // not tracked by goBackOneStep below, so without this check the press would
  // fall straight through to page navigation — and on the Insert/Delete main
  // page, where most of these dialogs live, that meant landing on "nothing
  // open" and popping the exit-app confirmation ON TOP of the dialog the
  // person only meant to dismiss. Closing the dialog itself takes priority.
  if (closeTopModal()) return;
  if (!goBackOneStep()) confirmExitApp();
}

// The hardware back key delivered as a native event (Capacitor / Cordova).
function onNativeBackPressed(){
  if (exitConfirmed) return;
  if (closeTopModal()) return;
  if (!goBackOneStep()) confirmExitApp();
}

async function confirmExitApp(){
  if (exitDialogOpen) return;
  exitDialogOpen = true;
  const goExit = await confirmDialog('Do you want to exit the app?', 'Yes, Exit');
  exitDialogOpen = false;
  if (!goExit) return;                                 // "No": the traps are still armed (and refilled on the tap), nothing changes
  if (NativeBridge.exitApp()) return;                  // wrapper can close the app itself
  // A plain WebView cannot be closed from JavaScript. Step off ALL our traps so
  // the NEXT back press leaves the app, and tell the person so.
  exitConfirmed = true;
  backupMsg('Press the back button once more to exit.');
  if (navIdx > 0) history.go(-navIdx); else history.back();
  // Changed your mind? Any tap puts the traps back and the app carries on.
  document.addEventListener('pointerdown', function rearm(){
    if (exitConfirmed) { exitConfirmed = false; navIdx = readNavIdx(); topUpTraps(TRAP_MIN); }
  }, { once: true, capture: true });
}

// "❌ Close App" — lives only on the Insert/Delete main menu (uploadView),
// so the app is only ever closed deliberately from there, the same way the
// back button's exit confirmation already only fires from that page.
const btnCloseApp = document.getElementById('btnCloseApp');
if (btnCloseApp) btnCloseApp.addEventListener('click', () => confirmExitApp());

// Every real tap tops the trap stack back up to TRAP_BUFFER. This is what keeps
// the app safe from fast repeated back presses; pushes made here happen inside
// a genuine user gesture, so the phone never treats them as skippable.
function refillTrapsOnGesture(){
  if (exitConfirmed) return;
  if (navIdx < TRAP_BUFFER) topUpTraps(TRAP_BUFFER);
}

function initBackButton(){
  // After a reload the phone keeps the old history entries (and their idx) — pick up where they left off.
  try {
    const st = history.state;
    if (st && st.epiNav && typeof st.idx === 'number') navIdx = st.idx;
    else { const m = /^#epi(\d+)$/.exec(location.hash || ''); if (m) { hashMode = true; navIdx = parseInt(m[1], 10); } }
  } catch (e) {}
  // Arm the first trap once the page has FINISHED loading. (A #hash change made while
  // the page is still loading REPLACES the current history entry instead of adding
  // one, which would leave no trap at all in hashMode.) The rest are added by taps.
  const armFirst = () => topUpTraps(1);
  if (document.readyState === 'complete') armFirst();
  else window.addEventListener('load', () => setTimeout(armFirst, 0), { once: true });
  window.addEventListener('popstate', onHistoryBack);
  window.addEventListener('hashchange', onHistoryBack);
  window.addEventListener('pageshow', e => { if (e.persisted) { navIdx = readNavIdx(); topUpTraps(1); } });
  ['pointerup', 'click', 'touchend'].forEach(t => window.addEventListener(t, refillTrapsOnGesture, true));
  NativeBridge.onNativeBack(onNativeBackPressed);
}
