// ============================================================
// NATIVE BRIDGE — everything that talks to the phone / the app wrapper
// (AppMint, Capacitor, Cordova, or a plain browser) lives in this one file.
//
//   NativeBridge.notifyDownloaded(name)  → "Download complete" entry in the
//                                          phone's notification bar
//   NativeBridge.primeNotifications()    → asks for notification permission
//                                          (call it from a tap)
//   NativeBridge.exitApp()               → real app exit, if the wrapper has one
//   NativeBridge.onNativeBack(fn)        → the wrapper's own hardware-back event
//   NativeBridge.init()                  → start-up hooks (called from main.js)
//
// Every feature tries the native route first and quietly falls back, so the
// same files keep working in a normal browser too. Nothing here may ever
// stop a download or a screen from working — every call is wrapped in try/catch.
// ============================================================
const NativeBridge = (function(){
  const capPlugins = () => (window.Capacitor && window.Capacitor.Plugins) ? window.Capacitor.Plugins : null;
  const cordovaLocal = () => (window.cordova && window.cordova.plugins && window.cordova.plugins.notification && window.cordova.plugins.notification.local) || null;

  let swReg = null;

  // Ask for notification permission. Browsers only allow this from a tap,
  // so it is called from the Share/Download choice and the export buttons.
  async function primeNotifications(){
    try {
      const P = capPlugins();
      if (P && P.LocalNotifications && P.LocalNotifications.requestPermissions) {
        await P.LocalNotifications.requestPermissions();
        return;
      }
      const c = cordovaLocal();
      if (c && c.requestPermission) { c.requestPermission(function(){}); return; }
      if ('Notification' in window && Notification.permission === 'default') {
        await Notification.requestPermission();
      }
    } catch (e) { /* notifications are a bonus — never block the download */ }
  }

  // Shows "Download complete — <file name>" in the notification bar.
  // Returns which route worked ('capacitor' | 'cordova' | 'service-worker' | 'page'),
  // or null when this phone/wrapper does not allow notifications.
  async function notifyDownloaded(filename){
    const title = 'Download complete';
    const body = `${filename} — saved to your Downloads folder`;
    const id = Date.now() % 2147483647;
    try {
      const P = capPlugins();
      if (P && P.LocalNotifications && P.LocalNotifications.schedule) {
        await P.LocalNotifications.schedule({ notifications: [{ id, title, body, schedule: { at: new Date(Date.now() + 250) } }] });
        return 'capacitor';
      }
    } catch (e) {}
    try {
      const c = cordovaLocal();
      if (c && c.schedule) { c.schedule({ id, title, text: body, foreground: true }); return 'cordova'; }
    } catch (e) {}
    try {
      if ('Notification' in window && Notification.permission === 'granted') {
        let reg = swReg;
        if (!reg && navigator.serviceWorker && navigator.serviceWorker.getRegistration) reg = await navigator.serviceWorker.getRegistration();
        if (reg && reg.showNotification) {
          await reg.showNotification(title, { body, tag: 'epi-download-' + id });
          return 'service-worker';
        }
        new Notification(title, { body, tag: 'epi-download-' + id });
        return 'page';
      }
    } catch (e) {}
    return null;
  }

  // True when the wrapper closed the app for us. In a plain WebView JavaScript
  // is not allowed to close the app, so the caller falls back to "press back
  // once more".
  function exitApp(){
    try { const P = capPlugins(); if (P && P.App && P.App.exitApp) { P.App.exitApp(); return true; } } catch (e) {}
    try { if (navigator.app && navigator.app.exitApp) { navigator.app.exitApp(); return true; } } catch (e) {}
    return false;
  }

  // Wrappers built on Capacitor / Cordova deliver the hardware back key as
  // their own event instead of a browser history step.
  function onNativeBack(handler){
    try { const P = capPlugins(); if (P && P.App && P.App.addListener) P.App.addListener('backButton', handler); } catch (e) {}
    try { document.addEventListener('backbutton', function(ev){ if (ev && ev.preventDefault) ev.preventDefault(); handler(); }, false); } catch (e) {}
  }

  function init(){
    // Service worker = the way a web page shows a notification on Android.
    // It only exists on http(s) origins; on file:// it is simply skipped.
    try {
      if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) {
        navigator.serviceWorker.register('sw.js').then(function(r){ swReg = r; }).catch(function(){});
      }
    } catch (e) {}
  }

  return { primeNotifications, notifyDownloaded, exitApp, onNativeBack, init };
})();
