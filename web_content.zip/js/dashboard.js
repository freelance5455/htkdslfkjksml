const cfg=window.DARRELL_CONFIG, box=document.getElementById("bookings"), statusEl=document.getElementById("status");
async function load(){
 statusEl.textContent="Loading…";
 if(cfg.SUPABASE_URL.includes("PASTE_")){statusEl.textContent="Connect Supabase in js/config.js to enable the dashboard.";return}
 try{
  const r=await fetch(cfg.SUPABASE_URL+"/rest/v1/bookings?select=*&order=created_at.desc",{headers:{"apikey":cfg.SUPABASE_ANON_KEY,"Authorization":"Bearer "+cfg.SUPABASE_ANON_KEY}});
  if(!r.ok) throw 0; const rows=await r.json();
  total.textContent=rows.length; pending.textContent=rows.filter(x=>x.status==="pending").length; accepted.textContent=rows.filter(x=>x.status==="accepted").length;
  box.innerHTML=rows.length?rows.map(x=>`<article class="booking"><div><b>${esc(x.customer_name)}</b><p>${esc(x.phone)} • ${esc(x.date)} at ${esc(x.time)} • ${x.guests} guest(s)</p><small>${esc(x.special_request||"No special request")}</small></div><div class="actions"><span class="pill ${x.status}">${x.status}</span><button onclick="changeStatus('${x.id}','accepted')">Accept</button><button onclick="changeStatus('${x.id}','rejected')">Reject</button></div></article>`).join(""):"<p>No bookings yet.</p>";
  statusEl.textContent="";
 }catch(e){statusEl.textContent="Could not load bookings. Check your Supabase URL, key and policies."}
}
async function changeStatus(id,status){
 const r=await fetch(cfg.SUPABASE_URL+"/rest/v1/bookings?id=eq."+encodeURIComponent(id),{method:"PATCH",headers:{"apikey":cfg.SUPABASE_ANON_KEY,"Authorization":"Bearer "+cfg.SUPABASE_ANON_KEY,"Content-Type":"application/json"},body:JSON.stringify({status})});
 if(!r.ok) alert("Update failed. Check Supabase policies."); else load();
}
function esc(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
refresh.onclick=load; load(); setInterval(load,15000);