window.pageInit=async function(u){
 const c=document.querySelector('#content');
 let period='day',custom=null;
 function localKey(v){const d=v instanceof Date?v:new Date(v);return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`}
 function mondayStart(now){const d=new Date(now);d.setHours(0,0,0,0);const day=d.getDay();const diff=day===0?-6:1-day;d.setDate(d.getDate()+diff);return d}
 function range(){const now=new Date();if(period==='custom'&&custom)return [new Date(custom[0]+'T00:00:00'),new Date(custom[1]+'T23:59:59')];if(period==='week'){const s=mondayStart(now);return [s,now]}const s=new Date(now);s.setHours(0,0,0,0);if(period==='month')s.setDate(1);if(period==='quarter')s.setMonth(Math.floor(now.getMonth()/3)*3,1);if(period==='semester')s.setMonth(now.getMonth()<6?0:6,1);if(period==='year')s.setMonth(0,1);return [s,now]}
 function allowedPeriods(){return u.role==='Agent'?['day','week']:['day','week','month','quarter','semester','year','custom']}
 function safeText(v){return String(v??'').replace(/€/g,'EUR')}
 function cp1252(s){
   const map={'€':0x80,'‚':0x82,'ƒ':0x83,'„':0x84,'…':0x85,'†':0x86,'‡':0x87,'ˆ':0x88,'‰':0x89,'Š':0x8A,'‹':0x8B,'Œ':0x8C,'Ž':0x8E,'‘':0x91,'’':0x92,'“':0x93,'”':0x94,'•':0x95,'–':0x96,'—':0x97,'˜':0x98,'™':0x99,'š':0x9A,'›':0x9B,'œ':0x9C,'ž':0x9E,'Ÿ':0x9F,'À':0xC0,'Á':0xC1,'Â':0xC2,'Ã':0xC3,'Ä':0xC4,'Å':0xC5,'Æ':0xC6,'Ç':0xC7,'È':0xC8,'É':0xC9,'Ê':0xCA,'Ë':0xCB,'Ì':0xCC,'Í':0xCD,'Î':0xCE,'Ï':0xCF,'Ð':0xD0,'Ñ':0xD1,'Ò':0xD2,'Ó':0xD3,'Ô':0xD4,'Õ':0xD5,'Ö':0xD6,'×':0xD7,'Ø':0xD8,'Ù':0xD9,'Ú':0xDA,'Û':0xDB,'Ü':0xDC,'Ý':0xDD,'Þ':0xDE,'ß':0xDF,'à':0xE0,'á':0xE1,'â':0xE2,'ã':0xE3,'ä':0xE4,'å':0xE5,'æ':0xE6,'ç':0xE7,'è':0xE8,'é':0xE9,'ê':0xEA,'ë':0xEB,'ì':0xEC,'í':0xED,'î':0xEE,'ï':0xEF,'ð':0xF0,'ñ':0xF1,'ò':0xF2,'ó':0xF3,'ô':0xF4,'õ':0xF5,'ö':0xF6,'÷':0xF7,'ø':0xF8,'ù':0xF9,'ú':0xFA,'û':0xFB,'ü':0xFC,'ý':0xFD,'þ':0xFE,'ÿ':0xFF};
   let out=''; for(const ch of String(s??'')){const code=ch.codePointAt(0); if(code<128)out+=String.fromCharCode(code); else if(map[ch]!==undefined)out+=String.fromCharCode(map[ch]); else if(ch==='₣')out+='FC'; else out+='?';} return out;
 }
 function pdfEscape(s){return cp1252(s).replace(/\\/g,'\\\\').replace(/\(/g,'\\(').replace(/\)/g,'\\)')}
 function buildPdf(title,start,end,rec,dep,active,groups){
   const lines=[]; const add=(t,size=10,bold=false)=>lines.push({t:safeText(t),size,bold});
   add('WONDER SHIFT',18,true); add(title,13,true); add(`Periode : ${WS.date(start)} -> ${WS.date(end)}`,9); add(`Genere le : ${WS.dateTime(new Date())}`,9); add('',5);
   add(`Recettes : ${WS.money(rec)}    Depenses : ${WS.money(dep)}    Solde : ${WS.money(rec-dep)}`,10,true); add(`Nombre d operations : ${active.length}`,10); add('',8);
   add('DETAIL PAR TACHE',11,true); add('Tache                         Recettes       Depenses       Operations',9,true); add('--------------------------------------------------------------------------',8);
   Object.entries(groups).sort((a,b)=>b[1].rec-a[1].rec).forEach(([t,g])=>{let name=safeText(t); if(name.length>28)name=name.slice(0,25)+'...'; add(`${name.padEnd(30)} ${String(WS.money(g.rec)).padStart(14)} ${String(WS.money(g.dep)).padStart(14)} ${String(g.n).padStart(12)}`,9)});
   add('',8); add('OPERATIONS',11,true); add('Date       Type       Agent                    Tache / Service              Montant',9,true); add('--------------------------------------------------------------------------------',8);
   active.forEach(o=>{let d=localKey(o.date||o.createdAt);let type=String(o.type||'').padEnd(10).slice(0,10);let ag=safeText(o.agent||'').padEnd(24).slice(0,24);let task=safeText(o.task||o.service||'').padEnd(28).slice(0,28);add(`${d}  ${type} ${ag} ${task} ${String(WS.money(o.total)).padStart(12)}`,8)});
   const pageH=760, top=790,bottom=45; const pages=[]; let cur=[],y=top; for(const ln of lines){const h=ln.size+5;if(y-h<bottom){pages.push(cur);cur=[];y=top}cur.push({...ln,y});y-=h} if(cur.length)pages.push(cur);
   const objs=[]; const addObj=s=>{objs.push(s);return objs.length}; const font=addObj('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');
   const pageIds=[]; const contentIds=[];
   pages.forEach(pg=>{let stream='';pg.forEach(ln=>{stream+=`BT /${ln.bold?'F2':'F1'} ${ln.size} Tf 45 ${ln.y} Td (${pdfEscape(ln.t)}) Tj ET\n`}); const cid=addObj(`<< /Length ${stream.length} >>\nstream\n${stream}endstream`);contentIds.push(cid);pageIds.push(addObj(''))});
   const pagesId=addObj(''); const catalogId=addObj('');
   const f2=addObj('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');
   objs[font-1]=objs[font-1];
   pages.forEach((pg,i)=>{objs[pageIds[i]-1]=`<< /Type /Page /Parent ${pagesId} 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 ${font} 0 R /F2 ${f2} 0 R >> >> /Contents ${contentIds[i]} 0 R >>`});
   objs[pagesId-1]=`<< /Type /Pages /Kids [${pageIds.map(id=>id+' 0 R').join(' ')}] /Count ${pageIds.length} >>`;
   objs[catalogId-1]=`<< /Type /Catalog /Pages ${pagesId} 0 R >>`;
   let pdf='%PDF-1.4\n%âãÏÓ\n',offsets=[0]; for(let i=0;i<objs.length;i++){offsets[i+1]=pdf.length;pdf+=`${i+1} 0 obj\n${objs[i]}\nendobj\n`}
   const xref=pdf.length;pdf+=`xref\n0 ${objs.length+1}\n0000000000 65535 f \n`;for(let i=1;i<offsets.length;i++)pdf+=String(offsets[i]).padStart(10,'0')+' 00000 n \n';pdf+=`trailer\n<< /Size ${objs.length+1} /Root ${catalogId} 0 R >>\nstartxref\n${xref}\n%%EOF`;
   return new TextEncoder().encode(pdf);
 }
 async function draw(){
   const [start,end]=range(),all=await dbAll('operations'),sk=localKey(start),ek=localKey(end),active=activeOperations(all).filter(o=>{const k=localKey(o.date||o.createdAt);return k>=sk&&k<=ek}),rec=active.filter(o=>o.type==='Recette').reduce((a,o)=>a+Number(o.total),0),dep=active.filter(o=>o.type==='Dépense').reduce((a,o)=>a+Number(o.total),0),groups={};
   active.forEach(o=>{groups[o.task||'Sans tâche']??={rec:0,dep:0,n:0};groups[o.task||'Sans tâche'].n++;groups[o.task||'Sans tâche'][o.type==='Recette'?'rec':'dep']+=Number(o.total)});
   const buttons=allowedPeriods().map(p=>`<button data-p="${p}" class="${period===p?'active':''}">${({day:'Jour',week:'Semaine',month:'Mois',quarter:'Trimestre',semester:'Semestre',year:'Année',custom:'Personnalisé'})[p]}</button>`).join('');
   c.innerHTML=`<div class="periods">${buttons}</div><div class="grid"><div class="card kpi"><div class="kpi-head"><span>Recettes</span><span class="kpi-icon">₣</span></div><div class="metric">${WS.money(rec)}</div></div><div class="card kpi"><div class="kpi-head"><span>Dépenses</span><span class="kpi-icon">−</span></div><div class="metric">${WS.money(dep)}</div></div><div class="card kpi"><div class="kpi-head"><span>Solde</span><span class="kpi-icon">✓</span></div><div class="metric">${WS.money(rec-dep)}</div></div><div class="card kpi"><div class="kpi-head"><span>Opérations</span><span class="kpi-icon">▣</span></div><div class="metric">${active.length}</div></div></div><div class="card section"><div class="section-head"><div><h2>Rapport d'activité</h2><div class="muted">Données locales · ${WS.date(start)} → ${WS.date(end)}</div></div><div class="actions"><button class="secondary" id="csv">Excel/CSV</button><button class="primary" id="pdf">Télécharger PDF</button></div></div><div class="table-wrap"><table class="table"><thead><tr><th>Tâche</th><th>Recettes</th><th>Dépenses</th><th>Opérations</th></tr></thead><tbody>${Object.entries(groups).sort((a,b)=>b[1].rec-a[1].rec).map(([t,g])=>`<tr><td>${WS.esc(t)}</td><td>${WS.money(g.rec)}</td><td>${WS.money(g.dep)}</td><td>${g.n}</td></tr>`).join('')||'<tr><td colspan="4" class="empty">Aucune donnée.</td></tr>'}</tbody></table></div></div>`;
   c.querySelectorAll('[data-p]').forEach(b=>b.onclick=()=>{if(b.dataset.p==='custom'){const s=prompt('Date de début (AAAA-MM-JJ)',custom?.[0]||''),e=prompt('Date de fin (AAAA-MM-JJ)',custom?.[1]||'');if(!s||!e||s>e)return WS.toast('Dates invalides.');custom=[s,e]}else period=b.dataset.p;draw()});
   c.querySelector('#csv').onclick=()=>WS.csv('wonder-shift-rapport.csv',[['Tâche','Type','Agent','Client','Montant','Date'],...active.map(o=>[o.task,o.type,o.agent,o.client,o.total,WS.dateTime(o.date)])]);
   c.querySelector('#pdf').onclick=()=>{try{const bytes=buildPdf(`Rapport ${period==='day'?'du jour':period==='week'?'hebdomadaire':'d activite'}`,start,end,rec,dep,active,groups);const blob=new Blob([bytes],{type:'application/pdf'});const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`WONDER_SHIFT_RAPPORT_${period.toUpperCase()}_${localKey(start)}.pdf`;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),2000);WS.toast('PDF téléchargé.')}catch(e){console.error(e);WS.toast('Impossible de générer le PDF.')}};
 }
 draw();
}
