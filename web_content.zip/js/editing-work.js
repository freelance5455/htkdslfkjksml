// =======================================
// NetEarn Pro
// Photo Editing Work System V4
// Firebase Auth + Firestore
// Cloudinary Image Upload
// Admin Task Image + Download
// User Edited Image Submission
//
// IMPORTANT:
// - Uses Firestore Auto-ID for every submission
// - Does NOT block because an old taskSubmissions document exists
// - Keeps current-page duplicate protection
// - Consumes exactly 1 task chance
// - Submission status = pending
// =======================================


import {
    auth,
    db
} from "./firebase.js";
import { getBusinessSettings, getConfiguredTaskReward } from "./business-settings.js";


import {
    onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";


import {
    doc,
    getDoc,
    collection,
    serverTimestamp,
    query,
    where,
    getDocs,
    runTransaction
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";


// =======================================
// CLOUDINARY CONFIG
// =======================================

const CLOUDINARY_CONFIG = {

    cloudName:
        "dvwpyztw",

    uploadPreset:
        "netearn_upload",

    resourceType:
        "image"

};


// =======================================
// ELEMENTS
// =======================================

const timerBox =
    document.getElementById("timer");


const imageUpload =
    document.getElementById("imageUpload");


const previewImage =
    document.getElementById("previewImage");


const imageStatus =
    document.getElementById("imageStatus");


const submitBtn =
    document.getElementById("submitEditingBtn");


const taskImage =
    document.getElementById("taskImage");


const taskImagePlaceholder =
    document.getElementById(
        "taskImagePlaceholder"
    );


// =======================================
// APP STATE
// =======================================

let currentUser = null;

let currentTask = null;

let currentTaskId = null;

let remainingSeconds = 30 * 60;

let timerInterval = null;

let selectedImageFile = null;

let taskSubmitting = false;

let taskExpired = false;

let taskCompleted = false;


// =======================================
// TASK CONFIG
// =======================================

const TASK_CONFIG = {

    taskType:
        "photo_editing",

    taskName:
        "Photo Editing Task",

    reward:
        40,

    time:
        30 * 60

};


// =======================================
// GET TASK IMAGE URL
// =======================================

function getTaskImageURL(task) {

    if (!task) {

        return "";

    }


    const possibleURL =
        task.taskImage ||
        task.imageUrl ||
        task.sourceImage ||
        task.image ||
        "";


    if (
        typeof possibleURL !==
        "string"
    ) {

        return "";

    }


    return possibleURL.trim();

}


// =======================================
// CLOUDINARY UPLOAD EDITED IMAGE
// =======================================

async function uploadEditedImage(file) {

    // ===================================
    // NO FILE
    // ===================================

    if (!file) {

        throw new Error(
            "NO_IMAGE"
        );

    }


    // ===================================
    // IMAGE TYPE
    // ===================================

    if (
        !file.type ||
        !file.type.startsWith("image/")
    ) {

        throw new Error(
            "INVALID_IMAGE"
        );

    }


    // ===================================
    // MAX SIZE
    // ===================================

    const maxSize =
        10 * 1024 * 1024;


    if (
        file.size >
        maxSize
    ) {

        throw new Error(
            "IMAGE_TOO_LARGE"
        );

    }


    // ===================================
    // CLOUDINARY URL
    // ===================================

    const uploadURL =
        `https://api.cloudinary.com/v1_1/` +
        `${CLOUDINARY_CONFIG.cloudName}/` +
        `${CLOUDINARY_CONFIG.resourceType}/upload`;


    // ===================================
    // FORM DATA
    // ===================================

    const formData =
        new FormData();


    formData.append(
        "file",
        file
    );


    formData.append(
        "upload_preset",
        CLOUDINARY_CONFIG.uploadPreset
    );


    formData.append(
        "tags",
        "neteearn,photo_editing"
    );


    // ===================================
    // UPLOAD
    // ===================================

    let response;


    try {

        response =
            await fetch(
                uploadURL,
                {

                    method:
                        "POST",

                    body:
                        formData

                }
            );

    }

    catch (error) {

        console.error(
            "❌ Cloudinary Network Error:",
            error
        );


        throw new Error(
            "CLOUDINARY_NETWORK_ERROR"
        );

    }


    // ===================================
    // RESPONSE
    // ===================================

    let result;


    try {

        result =
            await response.json();

    }

    catch (error) {

        console.error(
            "❌ Cloudinary Invalid Response:",
            error
        );


        throw new Error(
            "CLOUDINARY_UPLOAD_ERROR"
        );

    }


    // ===================================
    // CLOUDINARY ERROR
    // ===================================

    if (
        !response.ok ||
        !result.secure_url
    ) {

        console.error(
            "❌ Cloudinary Upload Failed:",
            result
        );


        throw new Error(
            "CLOUDINARY_UPLOAD_ERROR"
        );

    }


    // ===================================
    // SUCCESS
    // ===================================

    console.log(
        "✅ Cloudinary Upload Successful:",
        result
    );


    return {

        imageURL:
            result.secure_url,

        publicId:
            result.public_id ||
            null,

        assetId:
            result.asset_id ||
            null,

        version:
            result.version ||
            null,

        resourceType:
            result.resource_type ||
            "image"

    };

}


// =======================================
// SHOW ASSIGNED IMAGE
// =======================================

function showAssignedImage() {

    if (!taskImage) {

        console.warn(
            "⚠️ taskImage element not found."
        );

        return;

    }


    if (!currentTask) {

        console.warn(
            "⚠️ currentTask not available."
        );

        return;

    }


    const imageURL =
        getTaskImageURL(
            currentTask
        );


    console.log(
        "🖼️ Assigned Image URL:",
        imageURL
    );


    // ===================================
    // NO IMAGE
    // ===================================

    if (!imageURL) {

        taskImage.removeAttribute(
            "src"
        );


        taskImage.style.display =
            "none";


        if (taskImagePlaceholder) {

            taskImagePlaceholder.style.display =
                "block";


            taskImagePlaceholder.innerHTML = `

                <div style="
                    text-align:center;
                    padding:30px 15px;
                ">

                    <div style="
                        font-size:42px;
                        margin-bottom:10px;
                    ">
                        🖼️
                    </div>

                    <p style="
                        font-weight:700;
                        margin:0 0 6px;
                    ">
                        Assigned Image Not Available
                    </p>

                    <small>
                        Admin has not assigned an image yet.
                    </small>

                </div>

            `;

        }


        return;

    }


    // ===================================
    // RESET
    // ===================================

    taskImage.removeAttribute(
        "src"
    );


    taskImage.alt =
        "Assigned Task Image";


    taskImage.style.width =
        "100%";


    taskImage.style.maxWidth =
        "700px";


    taskImage.style.maxHeight =
        "500px";


    taskImage.style.height =
        "auto";


    taskImage.style.objectFit =
        "contain";


    taskImage.style.borderRadius =
        "16px";


    taskImage.style.margin =
        "0 auto";


    taskImage.style.background =
        "#f8fafc";


    taskImage.style.display =
        "none";


    // ===================================
    // LOADING
    // ===================================

    if (taskImagePlaceholder) {

        taskImagePlaceholder.style.display =
            "block";


        taskImagePlaceholder.innerHTML = `

            <div style="
                text-align:center;
                padding:30px 15px;
            ">

                <div style="
                    font-size:42px;
                    margin-bottom:10px;
                ">
                    ⏳
                </div>

                <p style="
                    font-weight:700;
                    margin:0 0 6px;
                ">
                    Loading Assigned Image...
                </p>

                <small>
                    Please wait...
                </small>

            </div>

        `;

    }


    // ===================================
    // IMAGE LOAD
    // ===================================

    taskImage.onload =
        () => {

            console.log(
                "✅ Assigned Task Image Loaded"
            );


            taskImage.style.display =
                "block";


            if (taskImagePlaceholder) {

                taskImagePlaceholder.style.display =
                    "none";

            }

        };


    // ===================================
    // IMAGE ERROR
    // ===================================

    taskImage.onerror =
        () => {

            console.error(
                "❌ Assigned Task Image Failed:",
                imageURL
            );


            taskImage.removeAttribute(
                "src"
            );


            taskImage.style.display =
                "none";


            if (taskImagePlaceholder) {

                taskImagePlaceholder.style.display =
                    "block";


                taskImagePlaceholder.innerHTML = `

                    <div style="
                        text-align:center;
                        padding:30px 15px;
                    ">

                        <div style="
                            font-size:42px;
                            margin-bottom:10px;
                        ">
                            ❌
                        </div>

                        <p style="
                            font-weight:700;
                            margin:0 0 6px;
                        ">
                            Image Could Not Be Loaded
                        </p>

                        <small>
                            Admin-এর image URL check করুন।
                        </small>

                    </div>

                `;

            }

        };


    // ===================================
    // LOAD IMAGE
    // ===================================

    taskImage.src =
        imageURL;

}


// =======================================
// SHOW DOWNLOAD BUTTON
// =======================================

function showDownloadButton() {

    if (!currentTask) {

        return;

    }


    const imageURL =
        getTaskImageURL(
            currentTask
        );


    if (!imageURL) {

        return;

    }


    const imageBox =
        document.querySelector(
            ".source-image-box"
        );


    if (!imageBox) {

        console.warn(
            "⚠️ .source-image-box not found."
        );

        return;

    }


    // ===================================
    // REMOVE OLD BUTTON
    // ===================================

    imageBox
        .querySelectorAll(
            "#downloadTaskImageBtn, #downloadImageBtn"
        )
        .forEach(
            button => {
                button.remove();
            }
        );


    // ===================================
    // CREATE BUTTON
    // ===================================

    const downloadBtn =
        document.createElement("a");


    downloadBtn.id =
        "downloadTaskImageBtn";


    downloadBtn.href =
        imageURL;


    downloadBtn.target =
        "_blank";


    downloadBtn.rel =
        "noopener noreferrer";


    downloadBtn.download =
        "";


    downloadBtn.textContent =
        "⬇️ Download Image";


    // ===================================
    // STYLE
    // ===================================

    downloadBtn.style.display =
        "flex";


    downloadBtn.style.alignItems =
        "center";


    downloadBtn.style.justifyContent =
        "center";


    downloadBtn.style.gap =
        "8px";


    downloadBtn.style.width =
        "100%";


    downloadBtn.style.maxWidth =
        "700px";


    downloadBtn.style.margin =
        "16px auto 0";


    downloadBtn.style.padding =
        "14px 18px";


    downloadBtn.style.border =
        "0";


    downloadBtn.style.borderRadius =
        "14px";


    downloadBtn.style.background =
        "linear-gradient(135deg,#2563eb,#7c3aed)";


    downloadBtn.style.color =
        "#ffffff";


    downloadBtn.style.textDecoration =
        "none";


    downloadBtn.style.fontSize =
        "15px";


    downloadBtn.style.fontWeight =
        "800";


    downloadBtn.style.cursor =
        "pointer";


    downloadBtn.style.boxShadow =
        "0 8px 22px rgba(37,99,235,.20)";


    // ===================================
    // ADD
    // ===================================

    imageBox.appendChild(
        downloadBtn
    );

}


// =======================================
// UPDATE TASK UI
// =======================================

function updateTaskUI() {

    if (!currentTask) {

        return;

    }


    // ===================================
    // TASK TITLE
    // ===================================

    const taskName =
        currentTask.title ||
        currentTask.name ||
        currentTask.taskName ||
        "Photo Editing Task";


    TASK_CONFIG.taskName =
        taskName;


    // ===================================
    // REWARD
    // ===================================

    TASK_CONFIG.reward =
        getConfiguredTaskReward(currentTask);


    // ===================================
    // TIME
    // ===================================

    const taskMinutes =
        Number(
            currentTask.timeLimit ||
            currentTask.time ||
            30
        );


    TASK_CONFIG.time =
        (
            taskMinutes > 0
                ? taskMinutes
                : 30
        ) * 60;


    remainingSeconds =
        TASK_CONFIG.time;


    // ===================================
    // TASK TITLE UI
    // ===================================

    const taskTitleElement =
        document.querySelector(
            ".active-card h2"
        );


    if (taskTitleElement) {

        taskTitleElement.textContent =
            taskName;

    }


    // ===================================
    // PAGE TITLE
    // ===================================

    const pageTitle =
        document.querySelector(
            ".work-header h1"
        );


    if (pageTitle) {

        pageTitle.textContent =
            taskName;

    }


    // ===================================
    // DESCRIPTION
    // ===================================

    const description =
        currentTask.description ||
        "";


    const instructionText =
        document.querySelector(
            ".instruction-box p"
        );


    if (
        instructionText &&
        description
    ) {

        instructionText.textContent =
            description;

    }


    // ===================================
    // REWARD UI
    // ===================================

    const rewardStrong =
        document.querySelector(
            ".reward-card strong"
        );


    if (rewardStrong) {

        rewardStrong.textContent =
            "৳" +
            TASK_CONFIG.reward;

    }


    // ===================================
    // TIME UI
    // ===================================

    const timeStrong =
        document.querySelector(
            ".time-card strong"
        );


    if (timeStrong) {

        timeStrong.textContent =
            taskMinutes +
            " Min";

    }


    // ===================================
    // IMAGE
    // ===================================

    showAssignedImage();


    // ===================================
    // DOWNLOAD
    // ===================================

    showDownloadButton();

}


// =======================================
// LOAD ACTIVE EDITING TASK
// =======================================

async function loadEditingTask() {

    const tasksRef =
        collection(
            db,
            "tasks"
        );


    const taskQuery =
        query(

            tasksRef,

            where(
                "category",
                "==",
                "Photo Editing"
            ),

            where(
                "status",
                "==",
                "Active"
            )

        );


    const settingsPromise =
        getBusinessSettings({ force: true });

    const snapshot =
        await getDocs(
            taskQuery
        );


    if (
        snapshot.empty
    ) {

        throw new Error(
            "NO_EDITING_TASK"
        );

    }


    // ===================================
    // FIND TASK WITH IMAGE
    // ===================================

    let taskDoc =
        null;


    for (
        const docSnap of snapshot.docs
    ) {

        const data =
            docSnap.data();


        const assignedImage =
            getTaskImageURL(
                data
            );


        if (assignedImage) {

            taskDoc =
                docSnap;

            break;

        }

    }


    if (!taskDoc) {

        throw new Error(
            "NO_TASK_IMAGE"
        );

    }


    // ===================================
    // SAVE TASK
    // ===================================

    currentTaskId =
        taskDoc.id;


    currentTask =
        taskDoc.data();

    const businessSettings = await settingsPromise;
    currentTask.reward = getConfiguredTaskReward(currentTask, businessSettings);


    // ===================================
    // NORMALIZE IMAGE
    // ===================================

    currentTask.taskImage =
        getTaskImageURL(
            currentTask
        );


    // ===================================
    // CATEGORY
    // ===================================

    if (
        currentTask.category !==
        "Photo Editing"
    ) {

        throw new Error(
            "INVALID_TASK"
        );

    }


    // ===================================
    // STATUS
    // ===================================

    if (
        currentTask.status !==
        "Active"
    ) {

        throw new Error(
            "TASK_INACTIVE"
        );

    }


    // ===================================
    // IMAGE
    // ===================================

    if (
        !currentTask.taskImage
    ) {

        throw new Error(
            "NO_TASK_IMAGE"
        );

    }


    // ===================================
    // UI
    // ===================================

    updateTaskUI();


    console.log(
        "✅ Editing Task Loaded:",
        currentTaskId
    );


    console.log(
        "🖼️ Image:",
        currentTask.taskImage
    );

}


// =======================================
// USER IMAGE PREVIEW
// =======================================

imageUpload?.addEventListener(
    "change",
    async () => {

        const file =
            imageUpload.files?.[0] ||
            null;


        // ===================================
        // NO FILE
        // ===================================

        if (!file) {

            selectedImageFile =
                null;


            if (imageStatus) {

                imageStatus.textContent =
                    "No image selected";

                imageStatus.style.color =
                    "";

            }


            if (previewImage) {

                previewImage.src =
                    "";

                previewImage.style.display =
                    "none";

            }


            return;

        }


        // ===================================
        // IMAGE TYPE
        // ===================================

        if (
            !file.type ||
            !file.type.startsWith("image/")
        ) {

            await NetEarnDialog.alert(
                "❌ Valid image file নির্বাচন করুন।"
            );


            imageUpload.value =
                "";


            selectedImageFile =
                null;


            if (imageStatus) {

                imageStatus.textContent =
                    "No image selected";

                imageStatus.style.color =
                    "";

            }


            if (previewImage) {

                previewImage.src =
                    "";

                previewImage.style.display =
                    "none";

            }


            return;

        }


        // ===================================
        // SIZE
        // ===================================

        const maxSize =
            10 * 1024 * 1024;


        if (
            file.size >
            maxSize
        ) {

            await NetEarnDialog.alert(
                "❌ Image size must be 10 MB or less."
            );


            imageUpload.value =
                "";


            selectedImageFile =
                null;


            if (imageStatus) {

                imageStatus.textContent =
                    "No image selected";

                imageStatus.style.color =
                    "";

            }


            if (previewImage) {

                previewImage.src =
                    "";

                previewImage.style.display =
                    "none";

            }


            return;

        }


        // ===================================
        // SAVE FILE
        // ===================================

        selectedImageFile =
            file;


        // ===================================
        // STATUS
        // ===================================

        if (imageStatus) {

            imageStatus.textContent =
                "Image Selected ✅";


            imageStatus.style.color =
                "#15803d";

        }


        // ===================================
        // PREVIEW
        // ===================================

        const reader =
            new FileReader();


        reader.onload =
            (event) => {

                if (!previewImage) {

                    return;

                }


                previewImage.src =
                    event.target.result;


                previewImage.style.display =
                    "block";

            };


        reader.onerror =
            () => {

                if (previewImage) {

                    previewImage.src =
                        "";

                    previewImage.style.display =
                        "none";

                }


                if (imageStatus) {

                    imageStatus.textContent =
                        "Unable to preview image";

                    imageStatus.style.color =
                        "#dc2626";

                }

            };


        reader.readAsDataURL(
            file
        );

    }
);


// =======================================
// START TASK
// =======================================

function startTask() {

    taskExpired =
        false;


    taskSubmitting =
        false;


    taskCompleted =
        false;


    remainingSeconds =
        TASK_CONFIG.time;


    if (submitBtn) {

        submitBtn.disabled =
            false;


        submitBtn.textContent =
            "🚀 Submit Editing Task";

    }


    if (imageUpload) {

        imageUpload.disabled =
            false;

    }


    updateTimer();

    startTimer();

}


// =======================================
// START TIMER
// =======================================

function startTimer() {

    if (timerInterval) {

        clearInterval(
            timerInterval
        );

    }


    timerInterval =
        setInterval(
            updateTimer,
            1000
        );

}


// =======================================
// UPDATE TIMER
// =======================================

function updateTimer() {

    if (!timerBox) {

        return;

    }


    const minutes =
        Math.floor(
            remainingSeconds / 60
        );


    const seconds =
        remainingSeconds % 60;


    timerBox.textContent =
        String(minutes)
            .padStart(2, "0")
        +
        ":"
        +
        String(seconds)
            .padStart(2, "0");


    if (
        remainingSeconds <= 0
    ) {

        finishTimer();

        return;

    }


    remainingSeconds--;

}


// =======================================
// TIMER FINISHED
// =======================================

function finishTimer() {

    if (timerInterval) {

        clearInterval(
            timerInterval
        );


        timerInterval =
            null;

    }


    taskExpired =
        true;


    if (imageUpload) {

        imageUpload.disabled =
            true;

    }


    if (submitBtn) {

        submitBtn.disabled =
            true;


        submitBtn.textContent =
            "⏳ Time Finished";

    }


    alert(
        "⏳ Task Time Finished!\n\nআপনার Task-এর সময় শেষ হয়েছে।"
    );

}


// =======================================
// SUBMIT BUTTON
// =======================================

submitBtn?.addEventListener(
    "click",
    submitTask
);


// =======================================
// SUBMIT TASK
// =======================================

async function submitTask() {

    // ===================================
    // CURRENT PAGE DUPLICATE PROTECTION
    // ===================================

    if (
        taskSubmitting ||
        taskCompleted
    ) {

        return;

    }


    // ===================================
    // TIMER
    // ===================================

    if (taskExpired) {

        await NetEarnDialog.alert(
            "⏳ Task-এর সময় শেষ হয়ে গেছে।"
        );

        return;

    }


    // ===================================
    // USER
    // ===================================

    if (!currentUser) {

        await NetEarnDialog.alert(
            "⚠️ User authentication পাওয়া যায়নি।"
        );

        return;

    }

// ===================================
    // TASK
    // ===================================

    if (!currentTaskId) {

        await NetEarnDialog.alert(
            "⚠️ Editing Task পাওয়া যায়নি।"
        );

        return;

    }


    // ===================================
    // IMAGE
    // ===================================

    if (!selectedImageFile) {

        await NetEarnDialog.alert(
            "📤 আগে আপনার edited image upload করুন।"
        );

        return;

    }


    // ===================================
    // CONFIRM
    // ===================================

    const confirmed =
        await NetEarnDialog.confirm(
            "আপনি কি এই edited image Submit করতে চান?\n\nSubmit করার পর আর পরিবর্তন করা যাবে না।"
        );


    if (!confirmed) {

        return;

    }


    // ===================================
    // SUBMITTING
    // ===================================

    taskSubmitting =
        true;


    if (submitBtn) {

        submitBtn.disabled =
            true;


        submitBtn.textContent =
            "⏳ Uploading...";

    }


    try {

        // =================================
        // USER REF
        // =================================

        const userRef =
            doc(
                db,
                "users",
                currentUser.uid
            );


        // =================================
        // TASK REF
        // =================================

        const latestTaskRef =
            doc(
                db,
                "tasks",
                currentTaskId
            );


        // =================================
        // FRESH USER
        // =================================

        // User and current task are independent fresh reads.
        // Start both together so submission validation does not wait
        // for one Firestore read before beginning the other.
        const [freshSnap, latestTaskSnap] =
            await Promise.all([
                getDoc(userRef),
                getDoc(latestTaskRef)
            ]);


        if (
            !freshSnap.exists()
        ) {

            throw new Error(
                "USER_NOT_FOUND"
            );

        }


        const freshData =
            freshSnap.data();


        // =================================
        // VERIFIED
        // =================================

        const verified =
            freshData.verified === true ||
            freshData.verified === "true";


        if (!verified) {

            throw new Error(
                "NOT_VERIFIED"
            );

        }


        // =================================
        // CHANCE
        // =================================

        const freshChance =
            Number(
                freshData.taskChance ||
                0
            );


        if (
            freshChance < 1
        ) {

            throw new Error(
                "NO_CHANCE"
            );

        }


        // =================================
        // SELECTED TASK
        // =================================

        const selectedTask =
            freshData.selectedTask ||
            "";


        if (
            selectedTask &&
            selectedTask !== "editing"
        ) {

            throw new Error(
                "OTHER_TASK"
            );

        }


        // =================================
        // FRESH TASK
        // =================================

        if (
            !latestTaskSnap.exists()
        ) {

            throw new Error(
                "TASK_NOT_FOUND"
            );

        }


        const latestTask =
            latestTaskSnap.data();

        // Use the current Admin Panel Photo Editing reward
        // for the user-facing submission confirmation.
        const confirmationSettings =
            await getBusinessSettings({ force: true });

        latestTask.reward =
            getConfiguredTaskReward(
                latestTask,
                confirmationSettings
            );


        // =================================
        // TASK STATUS
        // =================================

        if (
            latestTask.status !==
            "Active"
        ) {

            throw new Error(
                "TASK_INACTIVE"
            );

        }


        // =================================
        // CATEGORY
        // =================================

        if (
            latestTask.category !==
            "Photo Editing"
        ) {

            throw new Error(
                "INVALID_TASK"
            );

        }


        // =================================
        // TASK IMAGE
        // =================================

        const latestTaskImage =
            getTaskImageURL(
                latestTask
            );


        if (!latestTaskImage) {

            throw new Error(
                "NO_TASK_IMAGE"
            );

        }


        // =================================
        // CLOUDINARY UPLOAD
        // =================================

        if (submitBtn) {

            submitBtn.textContent =
                "☁️ Uploading Image...";

        }


        const uploaded =
            await uploadEditedImage(
                selectedImageFile
            );


        // =================================
        // PREPARE AUTO-ID SUBMISSION REF
        // =================================
        //
        // IMPORTANT:
        // Firestore will generate a NEW unique ID.
        //
        // We intentionally DO NOT use:
        //
        // uid_taskId
        //
        // because that old logic caused
        // ALREADY_SUBMITTED problems.
        //
        // =================================

        const submissionRef =
            doc(
                collection(
                    db,
                    "taskSubmissions"
                )
            );


        console.log(
            "🆕 New Submission ID:",
            submissionRef.id
        );


        // =================================
        // FIRESTORE TRANSACTION
        // =================================

        if (submitBtn) {

            submitBtn.textContent =
                "⏳ Saving Submission...";

        }


        await runTransaction(

            db,

            async (transaction) => {

                // =========================
                // READS FIRST
                // =========================

                const userSnapshot =
                    await transaction.get(
                        userRef
                    );


                const taskSnapshot =
                    await transaction.get(
                        latestTaskRef
                    );


                // =========================
                // USER EXISTS
                // =========================

                if (
                    !userSnapshot.exists()
                ) {

                    throw new Error(
                        "USER_NOT_FOUND"
                    );

                }


                // =========================
                // TASK EXISTS
                // =========================

                if (
                    !taskSnapshot.exists()
                ) {

                    throw new Error(
                        "TASK_NOT_FOUND"
                    );

                }


                const latestUser =
                    userSnapshot.data();


                const transactionTask =
                    taskSnapshot.data();


                // =========================
                // VERIFIED
                // =========================

                const latestVerified =
                    latestUser.verified === true ||
                    latestUser.verified === "true";


                if (!latestVerified) {

                    throw new Error(
                        "NOT_VERIFIED"
                    );

                }


                // =========================
                // CHANCE
                // =========================

                const latestChance =
                    Number(
                        latestUser.taskChance ||
                        0
                    );


                if (
                    latestChance < 1
                ) {

                    throw new Error(
                        "NO_CHANCE"
                    );

                }


                // =========================
                // SELECTED TASK
                // =========================

                const latestSelectedTask =
                    latestUser.selectedTask ||
                    "";


                if (
                    latestSelectedTask &&
                    latestSelectedTask !== "editing"
                ) {

                    throw new Error(
                        "OTHER_TASK"
                    );

                }


                // =========================
                // TASK STATUS
                // =========================

                if (
                    transactionTask.status !==
                    "Active"
                ) {

                    throw new Error(
                        "TASK_INACTIVE"
                    );

                }


                // =========================
                // TASK CATEGORY
                // =========================

                if (
                    transactionTask.category !==
                    "Photo Editing"
                ) {

                    throw new Error(
                        "INVALID_TASK"
                    );

                }


                // =========================
                // TASK IMAGE
                // =========================

                const transactionTaskImage =
                    getTaskImageURL(
                        transactionTask
                    );


                if (!transactionTaskImage) {

                    throw new Error(
                        "NO_TASK_IMAGE"
                    );

                }


                // =========================
                // REWARD
                // =========================

                const businessSettings = await getBusinessSettings({ force: true });
                const reward =
                    getConfiguredTaskReward(transactionTask, businessSettings);


                // =========================
                // CREATE SUBMISSION
                // =========================
                //
                // NEW AUTO-ID EVERY TIME
                //
                // =========================

                transaction.set(

                    submissionRef,

                    {

                        userUid:
                            currentUser.uid,

                        userId:
                            latestUser.userId ||
                            null,

                        username:
                            latestUser.username ||
                            null,

                        taskId:
                            currentTaskId,

                        taskType:
                            "photo_editing",

                        taskName:
                            transactionTask.title ||
                            transactionTask.name ||
                            transactionTask.taskName ||
                            "Photo Editing Task",

                        reward:
                            reward,

                        taskImage:
                            transactionTaskImage,

                        editedImage:
                            uploaded.imageURL,

                        editedImagePath:
                            null,

                        cloudinaryPublicId:
                            uploaded.publicId,

                        cloudinaryAssetId:
                            uploaded.assetId,

                        cloudinaryVersion:
                            uploaded.version,

                        cloudinaryResourceType:
                            uploaded.resourceType,

                        fileName:
                            selectedImageFile.name,

                        fileType:
                            selectedImageFile.type,

                        fileSize:
                            selectedImageFile.size,

                        status:
                            "pending",

                        submittedAt:
                            serverTimestamp()

                    }

                );


                // =========================
                // CONSUME ONE CHANCE
                // =========================

                transaction.update(

                    userRef,

                    {

                        taskChance:
                            latestChance - 1,

                        selectedTask:
                            null,

                        completedTasks:
                            Number(
                                latestUser.completedTasks ||
                                0
                            ) + 1

                    }

                );

            }

        );

        // =================================
        // STOP TIMER
        // =================================

        if (timerInterval) {

            clearInterval(
                timerInterval
            );


            timerInterval =
                null;

        }


        // =================================
        // COMPLETE
        // =================================

        taskCompleted =
            true;


        if (imageUpload) {

            imageUpload.disabled =
                true;

        }


        if (submitBtn) {

            submitBtn.disabled =
                true;


            submitBtn.textContent =
                "✅ Task Submitted";

        }


        // =================================
        // SUCCESS
        // =================================

        await NetEarnDialog.alert(

            "🎉 Photo Editing Task Successfully Submitted!\n\n" +

            "Reward: ৳" +

            Number(
                latestTask.reward ||
                40
            ) +

            "\n\n" +

            "Status: Pending Admin Approval\n\n" +

            "Approval হলে Reward আপনার Balance-এ যোগ হবে।"

        );


        // =================================
        // DASHBOARD
        // =================================

        window.location.href =
            "dashboard.html";

    }


    catch (error) {

        console.error(
            "❌ Editing Submit Error:",
            error
        );


        taskSubmitting =
            false;


        if (submitBtn) {

            submitBtn.disabled =
                false;


            submitBtn.textContent =
                "🚀 Submit Editing Task";

        }


        // =================================
        // CLOUDINARY NETWORK
        // =================================

        if (
            error.message ===
            "CLOUDINARY_NETWORK_ERROR"
        ) {

            await NetEarnDialog.alert(
                "🌐 Image upload করা যায়নি। Internet connection check করুন।"
            );

            return;

        }


        // =================================
        // CLOUDINARY ERROR
        // =================================

        if (
            error.message ===
            "CLOUDINARY_UPLOAD_ERROR"
        ) {

            await NetEarnDialog.alert(
                "☁️ Image Cloudinary-তে upload করা যায়নি। Upload preset এবং Cloud name check করুন।"
            );

            return;

        }


        // =================================
        // TASK NOT FOUND
        // =================================

        if (
            error.message ===
            "TASK_NOT_FOUND"
        ) {

            await NetEarnDialog.alert(
                "⚠️ এই Editing Task আর available নেই।"
            );


            window.location.href =
                "editing.html";


            return;

        }


        // =================================
        // TASK INACTIVE
        // =================================

        if (
            error.message ===
            "TASK_INACTIVE"
        ) {

            await NetEarnDialog.alert(
                "⚠️ Admin এই Task বর্তমানে বন্ধ করে দিয়েছেন।"
            );


            window.location.href =
                "editing.html";


            return;

        }


        // =================================
        // INVALID TASK
        // =================================

        if (
            error.message ===
            "INVALID_TASK"
        ) {

            await NetEarnDialog.alert(
                "⚠️ Invalid Photo Editing Task।"
            );


            window.location.href =
                "editing.html";


            return;

        }


        // =================================
        // NO TASK IMAGE
        // =================================

        if (
            error.message ===
            "NO_TASK_IMAGE"
        ) {

            await NetEarnDialog.alert(
                "🖼️ Admin এই Task-এর image assign করেনি।"
            );


            window.location.href =
                "editing.html";


            return;

        }


        // =================================
        // NO IMAGE
        // =================================

        if (
            error.message ===
            "NO_IMAGE"
        ) {

            await NetEarnDialog.alert(
                "📤 আগে edited image upload করুন।"
            );

            return;

        }


        // =================================
        // INVALID IMAGE
        // =================================

        if (
            error.message ===
            "INVALID_IMAGE"
        ) {

            await NetEarnDialog.alert(
                "❌ Valid image file নির্বাচন করুন।"
            );

            return;

        }


        // =================================
        // IMAGE TOO LARGE
        // =================================

        if (
            error.message ===
            "IMAGE_TOO_LARGE"
        ) {

            await NetEarnDialog.alert(
                "❌ Image size 10 MB-এর বেশি হতে পারবে না।"
            );

            return;

        }


        // =================================
        // NO CHANCE
        // =================================

        if (
            error.message ===
            "NO_CHANCE"
        ) {

            await NetEarnDialog.alert(
                "👥 আপনার Task Chance শেষ হয়ে গেছে।"
            );


            window.location.href =
                "dashboard.html";


            return;

        }


        // =================================
        // NOT VERIFIED
        // =================================

        if (
            error.message ===
            "NOT_VERIFIED"
        ) {

            await NetEarnDialog.alert(
                "🔒 আপনার Account Verify করা হয়নি।"
            );


            window.location.href =
                "dashboard.html";


            return;

        }


        // =================================
        // OTHER TASK
        // =================================

        if (
            error.message ===
            "OTHER_TASK"
        ) {

            await NetEarnDialog.alert(
                "🔒 আপনার অন্য একটি Task selected আছে।"
            );


            window.location.href =
                "dashboard.html";


            return;

        }


        // =================================
        // USER NOT FOUND
        // =================================

        if (
            error.message ===
            "USER_NOT_FOUND"
        ) {

            await NetEarnDialog.alert(
                "⚠️ User data পাওয়া যায়নি।"
            );


            window.location.href =
                "dashboard.html";


            return;

        }


        // =================================
        // UNKNOWN
        // =================================

        await NetEarnDialog.alert(
            "❌ Task Submit করা যায়নি।\n\nদয়া করে আবার চেষ্টা করুন।"
        );

    }

}


// =======================================
// DISABLE TASK
// =======================================

function disableTask() {

    if (imageUpload) {

        imageUpload.disabled =
            true;

    }


    if (submitBtn) {

        submitBtn.disabled =
            true;

    }


    if (timerInterval) {

        clearInterval(
            timerInterval
        );


        timerInterval =
            null;

    }

}


// =======================================
// AUTH + TASK VALIDATION
// =======================================

onAuthStateChanged(

    auth,

    async (user) => {

        // =================================
        // NOT LOGGED IN
        // =================================

        if (!user) {

            window.location.href =
                "index.html";

            return;

        }


        currentUser =
            user;


        try {

            // =============================
            // USER REF
            // =============================

            const userRef =
                doc(
                    db,
                    "users",
                    user.uid
                );


            // =============================
            // USER SNAPSHOT
            // =============================

            const snap =
                await getDoc(
                    userRef
                );


            if (
                !snap.exists()
            ) {

                throw new Error(
                    "USER_NOT_FOUND"
                );

            }


            const userData =
                snap.data();


            // =============================
            // VERIFIED
            // =============================

            const verified =
                userData.verified === true ||
                userData.verified === "true";


            if (!verified) {

                throw new Error(
                    "NOT_VERIFIED"
                );

            }


            // =============================
            // TASK CHANCE
            // =============================

            const taskChance =
                Number(
                    userData.taskChance ||
                    0
                );


            if (
                taskChance < 1
            ) {

                throw new Error(
                    "NO_CHANCE"
                );

            }

// =============================
            // SELECTED TASK
            // =============================

            const selectedTask =
                userData.selectedTask ||
                "";


            if (
                selectedTask &&
                selectedTask !== "editing"
            ) {

                throw new Error(
                    "OTHER_TASK"
                );

            }


            // =============================
            // LOAD TASK
            // =============================

            await loadEditingTask();


            // =============================
            // START TASK
            // =============================

            startTask();

        }


        catch (error) {

            console.error(
                "❌ Editing Work Validation Error:",
                error
            );


            disableTask();


            // =============================
            // NOT VERIFIED
            // =============================

            if (
                error.message ===
                "NOT_VERIFIED"
            ) {

                await NetEarnDialog.alert(
                    "🔒 আপনার Account এখনো Verify করা হয়নি।"
                );

            }


            // =============================
            // NO CHANCE
            // =============================

            else if (
                error.message ===
                "NO_CHANCE"
            ) {

                await NetEarnDialog.alert(
                    "👥 আপনার কোনো Task Chance নেই।"
                );

            }


            // =============================
            // OTHER TASK
            // =============================

            else if (
                error.message ===
                "OTHER_TASK"
            ) {

                await NetEarnDialog.alert(
                    "🔒 আপনার অন্য একটি Task বর্তমানে selected আছে।"
                );

            }


            // =============================
            // NO EDITING TASK
            // =============================

            else if (
                error.message ===
                "NO_EDITING_TASK"
            ) {

                await NetEarnDialog.alert(
                    "📭 বর্তমানে কোনো Active Photo Editing Task নেই।"
                );

            }


            // =============================
            // NO TASK IMAGE
            // =============================

            else if (
                error.message ===
                "NO_TASK_IMAGE"
            ) {

                await NetEarnDialog.alert(
                    "🖼️ Admin এখনো এই Task-এর image assign করেনি।"
                );

            }


            // =============================
            // TASK INACTIVE
            // =============================

            else if (
                error.message ===
                "TASK_INACTIVE"
            ) {

                await NetEarnDialog.alert(
                    "⚠️ Admin এই Task বর্তমানে বন্ধ করে দিয়েছেন।"
                );

            }


            // =============================
            // USER NOT FOUND
            // =============================

            else if (
                error.message ===
                "USER_NOT_FOUND"
            ) {

                await NetEarnDialog.alert(
                    "⚠️ User data পাওয়া যায়নি।"
                );

            }


            // =============================
            // UNKNOWN
            // =============================

            else {

                await NetEarnDialog.alert(
                    "⚠️ Task access পাওয়া যায়নি।"
                );

            }


            window.location.href =
                "dashboard.html";

        }

    }

);


// =======================================
// CLEANUP
// =======================================

window.addEventListener(

    "beforeunload",

    () => {

        if (timerInterval) {

            clearInterval(
                timerInterval
            );


            timerInterval =
                null;

        }

    }

);


// =======================================
// READY
// =======================================

console.log(
    "✅ NetEarn Pro Photo Editing Work V4 Loaded"
);

console.log(
    "☁️ Cloudinary Upload Enabled"
);

console.log(
    "🆕 Firestore Auto-ID Submission System Enabled"
);