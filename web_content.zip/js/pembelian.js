// ======================================================
// PEMBELIAN / FAKTUR
// File: js/pembelian.js
//
// Fungsi utama:
// 1. Memilih distributor
// 2. Mencari barang dari Data Barang
// 3. Menambahkan barang ke faktur
// 4. Menghitung total faktur
// 5. Stok otomatis bertambah saat faktur disimpan
// 6. Harga beli terakhir diperbarui
// 7. Distributor terakhir diperbarui
// 8. Riwayat harga disimpan
// 9. Faktur disimpan ke dataFaktur
// 10. Selalu menggunakan dataBarang terbaru
// ======================================================


// ======================================================
// DATA SEMENTARA ITEM FAKTUR
// ======================================================

let itemFaktur = [];


// ======================================================
// MEMBUKA FORM FAKTUR
// ======================================================

function tampilkanFormFaktur() {

    const form = document.getElementById("formFaktur");

    if (!form) {
        return;
    }

    form.style.display = "block";


    // Tanggal hari ini
    const sekarang = new Date();

    const tahun = sekarang.getFullYear();

    const bulan = String(
        sekarang.getMonth() + 1
    ).padStart(2, "0");

    const hari = String(
        sekarang.getDate()
    ).padStart(2, "0");

    const tanggalHariIni =
        `${tahun}-${bulan}-${hari}`;


    const tanggalInput =
        document.getElementById("tanggalFaktur");

    if (tanggalInput) {
        tanggalInput.value = tanggalHariIni;
    }


    // Muat daftar distributor terbaru
    muatDistributor();


    // Bersihkan item lama
    itemFaktur = [];


    // Pastikan daftar item kosong
    const daftar =
        document.getElementById("daftarItemFaktur");

    if (daftar) {
        daftar.innerHTML = "";
    }


    // Reset pencarian barang
    resetPencarianBarang();


    // Tampilkan total awal
    hitungTotalFaktur();
}


// ======================================================
// MEMUAT DATA DISTRIBUTOR
// ======================================================

function muatDistributor() {

    const select =
        document.getElementById("distributorFaktur");

    if (!select) {
        return;
    }


    const data =
        JSON.parse(
            localStorage.getItem("dataDistributor") || "[]"
        );


    if (data.length === 0) {

        select.innerHTML = `
            <option value="">
                Belum ada distributor
            </option>
        `;

        return;
    }


    select.innerHTML = `
        <option value="">
            -- Pilih Distributor --
        </option>
    `;


    data.forEach(function(distributor) {

        select.innerHTML += `
            <option value="${distributor.id}">
                ${escapeHtml(distributor.nama)}
            </option>
        `;

    });
}


// ======================================================
// PENCARIAN BARANG
// ======================================================

function cariBarangFaktur() {

    const input =
        document.getElementById("cariBarangFaktur");

    const hasil =
        document.getElementById("hasilCariBarang");

    if (!input || !hasil) {
        return;
    }


    const kata =
        input.value.trim().toLowerCase();


    hasil.innerHTML = "";


    if (kata === "") {
        return;
    }


    // SELALU AMBIL DATA BARANG TERBARU
    // dari localStorage
    const dataBarang =
        JSON.parse(
            localStorage.getItem("dataBarang") || "[]"
        );


    // Hanya tampilkan data barang yang benar-benar
    // memiliki ID dan masih ada di database
    const dataValid =
        dataBarang.filter(function(barang) {

            return (
                barang &&
                barang.id !== undefined &&
                barang.id !== null
            );

        });


    const ditemukan =
        dataValid
        .filter(function(barang) {

            const kode =
                String(barang.kode || "")
                    .toLowerCase();

            const nama =
                String(barang.nama || "")
                    .toLowerCase();

            return (
                kode.includes(kata) ||
                nama.includes(kata)
            );

        })
        .slice(0, 10);


    if (ditemukan.length === 0) {

        hasil.innerHTML = `
            <div class="hasil-cari-item">
                Barang tidak ditemukan.
            </div>
        `;

        return;
    }


    hasil.innerHTML =
        ditemukan.map(function(barang) {

            return `
                <div
                    class="hasil-cari-item"
                    onclick="pilihBarangFaktur(${Number(barang.id)})">

                    <div class="hasil-cari-nama">
                        ${escapeHtml(barang.nama)}
                    </div>

                    <div class="hasil-cari-info">

                        ${escapeHtml(barang.kode || "")}

                        • ${escapeHtml(barang.satuan || "")}

                        • Stok:
                        ${Number(barang.stok || 0)}

                    </div>

                </div>
            `;

        }).join("");
}


// ======================================================
// MEMILIH BARANG DARI HASIL PENCARIAN
// ======================================================

function pilihBarangFaktur(id) {

    // Ambil data barang TERBARU
    const dataBarang =
        JSON.parse(
            localStorage.getItem("dataBarang") || "[]"
        );


    // Cari berdasarkan ID
    const barang =
        dataBarang.find(function(item) {

            return (
                item &&
                Number(item.id) === Number(id)
            );

        });


    // Jika barang sudah dihapus
    if (!barang) {

        alert(
            "Data barang sudah tidak tersedia karena telah dihapus."
        );

        // Bersihkan hasil pencarian
        const hasil =
            document.getElementById("hasilCariBarang");

        if (hasil) {
            hasil.innerHTML = "";
        }

        return;
    }


    // Pastikan elemen tersedia
    const inputBarang =
        document.getElementById("barangFaktur");

    const inputCari =
        document.getElementById("cariBarangFaktur");

    const hasil =
        document.getElementById("hasilCariBarang");

    const barangTerpilih =
        document.getElementById("barangTerpilih");

    const namaBarangTerpilih =
        document.getElementById("namaBarangTerpilih");

    const infoBarangTerpilih =
        document.getElementById("infoBarangTerpilih");

    const hargaBeli =
        document.getElementById("hargaBeliFaktur");


    // Simpan ID barang yang dipilih
    if (inputBarang) {

        inputBarang.value =
            barang.id;

    }


    // Tampilkan nama pada kotak pencarian
    if (inputCari) {

        inputCari.value =
            barang.nama || "";

    }


    // Hilangkan hasil pencarian
    if (hasil) {

        hasil.innerHTML =
            "";

    }


    // Tampilkan barang terpilih
    if (barangTerpilih) {

        barangTerpilih.style.display =
            "block";

    }


    if (namaBarangTerpilih) {

        namaBarangTerpilih.textContent =
            barang.nama || "";

    }


    if (infoBarangTerpilih) {

        infoBarangTerpilih.textContent =
            `${barang.kode || ""} • ${barang.satuan || ""} • Stok ${Number(barang.stok || 0)}`;

    }


    // Harga beli terakhir otomatis
    if (hargaBeli) {

        hargaBeli.value =
            Number(barang.hargaBeli || 0);

    }
}


// ======================================================
// RESET PENCARIAN BARANG
// ======================================================

function resetPencarianBarang() {

    const input =
        document.getElementById("cariBarangFaktur");

    const hasil =
        document.getElementById("hasilCariBarang");

    const terpilih =
        document.getElementById("barangTerpilih");

    const barangId =
        document.getElementById("barangFaktur");

    const qty =
        document.getElementById("qtyFaktur");

    const harga =
        document.getElementById("hargaBeliFaktur");


    if (input) {
        input.value = "";
    }

    if (hasil) {
        hasil.innerHTML = "";
    }

    if (terpilih) {
        terpilih.style.display = "none";
    }

    if (barangId) {
        barangId.value = "";
    }

    if (qty) {
        qty.value = "";
    }

    if (harga) {
        harga.value = "";
    }
}


// ======================================================
// TAMBAH ITEM KE FAKTUR
// ======================================================

function tambahItemFaktur() {

    const barangIdElement =
        document.getElementById("barangFaktur");

    const qtyElement =
        document.getElementById("qtyFaktur");

    const hargaElement =
        document.getElementById("hargaBeliFaktur");


    const barangId =
        barangIdElement
        ? barangIdElement.value
        : "";


    const qty =
        qtyElement
        ? Number(qtyElement.value)
        : 0;


    const harga =
        hargaElement
        ? Number(hargaElement.value)
        : 0;


    // Barang wajib dipilih
    if (!barangId) {

        alert(
            "Cari dan pilih barang terlebih dahulu."
        );

        return;
    }


    // Qty wajib lebih dari 0
    if (!qty || qty <= 0) {

        alert(
            "Jumlah barang harus lebih dari 0."
        );

        return;
    }


    // Harga tidak boleh negatif
    if (harga < 0) {

        alert(
            "Harga beli tidak boleh negatif."
        );

        return;
    }


    // Ambil data barang terbaru
    const dataBarang =
        JSON.parse(
            localStorage.getItem("dataBarang") || "[]"
        );


    // Pastikan barang masih ada
    const barang =
        dataBarang.find(function(item) {

            return (
                item &&
                Number(item.id) === Number(barangId)
            );

        });


    if (!barang) {

        alert(
            "Barang tersebut sudah dihapus dari Data Barang."
        );

        resetPencarianBarang();

        return;
    }


    // ==================================================
    // CEK APAKAH BARANG SUDAH ADA DI FAKTUR
    // ==================================================

    const sudahAda =
        itemFaktur.find(function(item) {

            return (
                Number(item.barangId) ===
                Number(barangId)
            );

        });


    if (sudahAda) {

        // Jika sudah ada,
        // tambahkan qty dan gunakan harga terbaru
        sudahAda.qty += qty;

        sudahAda.harga = harga;

    }

    else {

        // Barang baru
        itemFaktur.push({

            barangId:
                Number(barang.id),

            kode:
                barang.kode,

            nama:
                barang.nama,

            satuan:
                barang.satuan,

            qty:
                qty,

            harga:
                harga

        });

    }


    // Tampilkan item
    tampilkanItemFaktur();


    // Bersihkan form pencarian
    resetPencarianBarang();
}


// ======================================================
// MENAMPILKAN ITEM FAKTUR
// ======================================================

function tampilkanItemFaktur() {

    const container =
        document.getElementById(
            "daftarItemFaktur"
        );


    if (!container) {
        return;
    }


    if (itemFaktur.length === 0) {

        container.innerHTML = `
            <div class="faktur-kosong">
                Belum ada barang dalam faktur.
            </div>
        `;

        hitungTotalFaktur();

        return;
    }


    let html = "";


    itemFaktur.forEach(function(item, index) {

        html += `
            <div class="item-faktur">

                <div>
                    <strong>
                        ${escapeHtml(item.nama)}
                    </strong>
                </div>

                <div class="info-item-faktur">

                    ${escapeHtml(item.kode || "")}
                    •
                    ${escapeHtml(item.satuan || "")}

                </div>


                <label>
                    Jumlah
                </label>

                <input
                    type="number"
                    min="1"
                    value="${Number(item.qty || 0)}"
                    onchange="ubahQtyItem(${index}, this.value)"
                >


                <label>
                    Harga Beli
                </label>

                <input
                    type="number"
                    min="0"
                    value="${Number(item.harga || 0)}"
                    onchange="ubahHargaItem(${index}, this.value)"
                >


                <div class="subtotal-item">

                    Total:

                    <strong>
                        ${formatRupiah(
                            Number(item.qty || 0) *
                            Number(item.harga || 0)
                        )}
                    </strong>

                </div>


                <button
                    type="button"
                    class="tombol-hapus-item"
                    onclick="hapusItemFaktur(${index})">

                    🗑️ Hapus

                </button>

            </div>
        `;

    });


    container.innerHTML =
        html;


    hitungTotalFaktur();
}


// ======================================================
// UBAH QTY ITEM
// ======================================================

function ubahQtyItem(index, nilai) {

    if (!itemFaktur[index]) {
        return;
    }


    const qty =
        Number(nilai);


    if (qty <= 0) {

        alert(
            "Jumlah harus lebih dari 0."
        );

        tampilkanItemFaktur();

        return;
    }


    itemFaktur[index].qty =
        qty;


    tampilkanItemFaktur();
}


// ======================================================
// UBAH HARGA ITEM
// ======================================================

function ubahHargaItem(index, nilai) {

    if (!itemFaktur[index]) {
        return;
    }


    const harga =
        Number(nilai);


    if (harga < 0) {

        alert(
            "Harga tidak boleh negatif."
        );

        tampilkanItemFaktur();

        return;
    }


    itemFaktur[index].harga =
        harga;


    tampilkanItemFaktur();
}


// ======================================================
// HAPUS ITEM
// ======================================================

function hapusItemFaktur(index) {

    if (
        index < 0 ||
        index >= itemFaktur.length
    ) {
        return;
    }


    itemFaktur.splice(
        index,
        1
    );


    tampilkanItemFaktur();
}


// ======================================================
// HITUNG TOTAL FAKTUR
// ======================================================

function hitungTotalFaktur() {

    let total = 0;


    itemFaktur.forEach(function(item) {

        total +=
            Number(item.qty || 0) *
            Number(item.harga || 0);

    });


    const totalElement =
        document.getElementById(
            "totalFaktur"
        );


    if (totalElement) {

        totalElement.innerText =
            formatRupiah(total);

    }
}


// ======================================================
// SIMPAN FAKTUR
// ======================================================

function simpanFaktur() {

    const nomorElement =
        document.getElementById(
            "nomorFaktur"
        );


    const tanggalElement =
        document.getElementById(
            "tanggalFaktur"
        );


    const distributorElement =
        document.getElementById(
            "distributorFaktur"
        );


    const nomor =
        nomorElement
        ? nomorElement.value.trim()
        : "";


    const tanggal =
        tanggalElement
        ? tanggalElement.value
        : "";


    const distributorId =
        distributorElement
        ? distributorElement.value
        : "";


    // ==================================================
    // VALIDASI
    // ==================================================

    if (!nomor) {

        alert(
            "Nomor faktur wajib diisi."
        );

        return;
    }


    if (!tanggal) {

        alert(
            "Tanggal faktur wajib diisi."
        );

        return;
    }


    if (!distributorId) {

        alert(
            "Pilih distributor terlebih dahulu."
        );

        return;
    }


    if (itemFaktur.length === 0) {

        alert(
            "Tambahkan minimal satu barang ke faktur."
        );

        return;
    }


    // ==================================================
    // AMBIL DATABASE TERBARU
    // ==================================================

    let barang =
        JSON.parse(
            localStorage.getItem("dataBarang") || "[]"
        );


    let distributor =
        JSON.parse(
            localStorage.getItem("dataDistributor") || "[]"
        );


    let faktur =
        JSON.parse(
            localStorage.getItem("dataFaktur") || "[]"
        );


    // ==================================================
    // CEK SEMUA ITEM MASIH ADA
    // ==================================================

    for (let item of itemFaktur) {

        const barangMasihAda =
            barang.some(function(b) {

                return (
                    b &&
                    Number(b.id) ===
                    Number(item.barangId)
                );

            });


        if (!barangMasihAda) {

            alert(
                `Barang "${item.nama}" sudah dihapus dari Data Barang. Silakan hapus barang tersebut dari faktur lalu pilih barang yang tersedia.`
            );

            return;
        }


        if (!item.barangId) {

            alert(
                "Ada barang yang belum dipilih."
            );

            return;
        }


        if (Number(item.qty) <= 0) {

            alert(
                "Jumlah barang harus lebih dari 0."
            );

            return;
        }


        if (Number(item.harga) < 0) {

            alert(
                "Harga barang tidak boleh negatif."
            );

            return;
        }

    }


    // ==================================================
    // CEK NOMOR FAKTUR DUPLIKAT
    // ==================================================

    const nomorSudahAda =
        faktur.some(function(f) {

            return (
                String(f.nomor || "")
                    .toLowerCase() ===
                nomor.toLowerCase()
            );

        });


    if (nomorSudahAda) {

        alert(
            "Nomor faktur tersebut sudah digunakan."
        );

        return;
    }


    // ==================================================
    // CARI DISTRIBUTOR
    // ==================================================

    const distributorData =
        distributor.find(function(d) {

            return (
                String(d.id) ===
                String(distributorId)
            );

        });


    if (!distributorData) {

        alert(
            "Distributor tidak ditemukan."
        );

        return;
    }


    // ==================================================
    // BUAT DETAIL FAKTUR
    // ==================================================

    let detail = [];

    let total = 0;


    itemFaktur.forEach(function(item) {

        const indexBarang =
            barang.findIndex(function(b) {

                return (
                    b &&
                    Number(b.id) ===
                    Number(item.barangId)
                );

            });


        if (indexBarang === -1) {
            return;
        }


        const barangLama =
            barang[indexBarang];


        const hargaSebelumnya =
            Number(
                barangLama.hargaBeli || 0
            );


        const hargaBaru =
            Number(
                item.harga || 0
            );


        const qty =
            Number(
                item.qty || 0
            );


        const subtotal =
            qty *
            hargaBaru;


        total +=
            subtotal;


        // ==================================================
        // ANALISIS PERUBAHAN HARGA
        // ==================================================

        let statusHarga =
            "sama";


        let selisihHarga =
            0;


        if (hargaSebelumnya > 0) {

            selisihHarga =
                hargaBaru -
                hargaSebelumnya;


            if (selisihHarga > 0) {

                statusHarga =
                    "naik";

            }

            else if (selisihHarga < 0) {

                statusHarga =
                    "turun";

            }

        }


        // ==================================================
        // SIMPAN DETAIL
        // ==================================================

        detail.push({

            barangId:
                barangLama.id,

            kode:
                barangLama.kode,

            nama:
                barangLama.nama,

            satuan:
                barangLama.satuan,

            qty:
                qty,

            harga:
                hargaBaru,

            subtotal:
                subtotal,

            hargaSebelumnya:
                hargaSebelumnya,

            selisihHarga:
                selisihHarga,

            statusHarga:
                statusHarga

        });


        // ==================================================
        // STOK BERTAMBAH
        // ==================================================

        barang[indexBarang].stok =
            Number(
                barang[indexBarang].stok || 0
            ) +
            qty;


        // ==================================================
        // HARGA BELI TERAKHIR
        // ==================================================

        barang[indexBarang].hargaBeli =
            hargaBaru;


        // ==================================================
        // DISTRIBUTOR TERAKHIR
        // ==================================================

        barang[indexBarang].distributorTerakhir =
            distributorData.nama;


        barang[indexBarang].distributorTerakhirId =
            distributorId;


        // ==================================================
        // RIWAYAT HARGA
        // ==================================================

        if (
            !Array.isArray(
                barang[indexBarang].riwayatHarga
            )
        ) {

            barang[indexBarang].riwayatHarga =
                [];

        }


        barang[indexBarang].riwayatHarga.push({

            tanggal:
                tanggal,

            nomorFaktur:
                nomor,

            distributorId:
                distributorId,

            distributorNama:
                distributorData.nama,

            harga:
                hargaBaru,

            hargaSebelumnya:
                hargaSebelumnya,

            selisih:
                selisihHarga,

            status:
                statusHarga

        });

    });


    // ==================================================
    // PASTIKAN ADA DETAIL
    // ==================================================

    if (detail.length === 0) {

        alert(
            "Barang dalam faktur tidak ditemukan."
        );

        return;
    }


    // ==================================================
    // BUAT DATA FAKTUR
    // ==================================================

    const dataFakturBaru = {

        id:
            Date.now(),

        nomor:
            nomor,

        tanggal:
            tanggal,

        distributorId:
            distributorId,

        distributorNama:
            distributorData.nama,

        detail:
            detail,

        subtotal:
            total,

        total:
            total,

        totalRetur:
            0,

        totalDibayar:
            0,

        sisa:
            total,

        status:
            "belum"

    };


    // ==================================================
    // SIMPAN KE DATABASE
    // ==================================================

    faktur.push(
        dataFakturBaru
    );


    localStorage.setItem(
        "dataBarang",
        JSON.stringify(barang)
    );


    localStorage.setItem(
        "dataFaktur",
        JSON.stringify(faktur)
    );


    // ==================================================
    // BERHASIL
    // ==================================================

    alert(
        "Faktur berhasil disimpan.\n\n" +
        "Stok barang otomatis bertambah."
    );


    // ==================================================
    // RESET
    // ==================================================

    itemFaktur = [];


    const form =
        document.getElementById(
            "formFaktur"
        );

    if (form) {

        form.style.display =
            "none";

    }


    if (nomorElement) {

        nomorElement.value =
            "";

    }


    if (distributorElement) {

        distributorElement.value =
            "";

    }


    resetPencarianBarang();


    tampilkanItemFaktur();


    tampilkanDaftarFaktur();
}


// ======================================================
// MENAMPILKAN DAFTAR FAKTUR
// ======================================================

function tampilkanDaftarFaktur() {

    const container =
        document.getElementById(
            "daftarFaktur"
        );


    if (!container) {
        return;
    }


    let faktur =
        JSON.parse(
            localStorage.getItem("dataFaktur") || "[]"
        );


    const inputCari =
        document.getElementById(
            "cariFaktur"
        );


    const selectFilter =
        document.getElementById(
            "filterStatus"
        );


    const pencarian =
        inputCari
        ? inputCari.value
            .trim()
            .toLowerCase()
        : "";


    const filter =
        selectFilter
        ? selectFilter.value
        : "semua";


    // ==================================================
    // FILTER
    // ==================================================

    faktur =
        faktur.filter(function(f) {

            const nomor =
                String(
                    f.nomor || ""
                ).toLowerCase();


            const distributor =
                String(
                    f.distributorNama || ""
                ).toLowerCase();


            const cocokCari =
                nomor.includes(
                    pencarian
                ) ||
                distributor.includes(
                    pencarian
                );


            const cocokStatus =
                filter === "semua" ||
                f.status === filter;


            return (
                cocokCari &&
                cocokStatus
            );

        });


    // Faktur terbaru di atas
    faktur.sort(function(a, b) {

        return (
            Number(b.id || 0) -
            Number(a.id || 0)
        );

    });


    if (faktur.length === 0) {

        container.innerHTML = `
            <div class="faktur-kosong">
                🧾 Belum ada faktur.
            </div>
        `;

        return;
    }


    // ==================================================
    // TABEL
    // ==================================================

    let html = `

        <div class="tabel-faktur">

            <table>

                <thead>

                    <tr>

                        <th>No</th>

                        <th>Faktur</th>

                        <th>Tanggal</th>

                        <th>Distributor</th>

                        <th>Total</th>

                        <th>Status</th>

                        <th>Aksi</th>

                    </tr>

                </thead>

                <tbody>

    `;


    faktur.forEach(function(f, index) {

        let statusText =
            "";


        if (
            f.status ===
            "lunas"
        ) {

            statusText =
                "🟢 Lunas";

        }

        else if (
            f.status ===
            "sebagian"
        ) {

            statusText =
                "🟡 Sebagian";

        }

        else {

            statusText =
                "🔴 Belum Lunas";

        }


        html += `

            <tr>

                <td>
                    ${index + 1}
                </td>

                <td>
                    <strong>
                        ${escapeHtml(
                            f.nomor
                        )}
                    </strong>
                </td>

                <td>
                    ${escapeHtml(
                        f.tanggal
                    )}
                </td>

                <td>
                    ${escapeHtml(
                        f.distributorNama
                    )}
                </td>

                <td>
                    ${formatRupiah(
                        f.total
                    )}
                </td>

                <td>
                    ${statusText}
                </td>

                <td>

                    <button
                        class="tombol-detail"
                        onclick="bukaDetailFaktur(${Number(f.id)})">

                        👁️ Detail

                    </button>

                </td>

            </tr>

        `;

    });


    html += `

                </tbody>

            </table>

        </div>

    `;


    container.innerHTML =
        html;
}


// ======================================================
// MEMBUKA DETAIL FAKTUR
// ======================================================

function bukaDetailFaktur(id) {

    localStorage.setItem(
        "fakturDetailId",
        id
    );


    location.href =
        "detail-faktur.html";
}


// ======================================================
// FORMAT RUPIAH
// ======================================================

function formatRupiah(angka) {

    return (
        "Rp " +
        Number(angka || 0)
            .toLocaleString("id-ID")
    );
}


// ======================================================
// ESCAPE HTML
// ======================================================

function escapeHtml(teks) {

    return String(
        teks || ""
    )
    .replace(
        /&/g,
        "&amp;"
    )
    .replace(
        /</g,
        "&lt;"
    )
    .replace(
        />/g,
        "&gt;"
    )
    .replace(
        /"/g,
        "&quot;"
    )
    .replace(
        /'/g,
        "&#039;"
    );
}


// ======================================================
// EVENT SAAT HALAMAN DIBUKA
// ======================================================

document.addEventListener(
    "DOMContentLoaded",
    function() {

        tampilkanDaftarFaktur();


        // Aktifkan pencarian barang
        const inputBarang =
            document.getElementById(
                "cariBarangFaktur"
            );


        if (inputBarang) {

            inputBarang.addEventListener(
                "input",
                cariBarangFaktur
            );

        }


        // Cek parameter URL
        const parameter =
            new URLSearchParams(
                window.location.search
            );


        const aksi =
            parameter.get("aksi");


        if (
            aksi ===
            "tambah"
        ) {

            tampilkanFormFaktur();

        }


        if (
            aksi ===
            "daftar"
        ) {

            tampilkanDaftarFaktur();

        }

    }
);