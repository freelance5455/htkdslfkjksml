/* If the jQuery CDN is unreachable (offline), keep the game working without background effects */
if(!window.jQuery){window.fxRoute=function(){};}
