/* UrbaAlerte — écrans : onboarding, auth, accueil, carte, historique, profil */
(function(w){
'use strict';
const UA=w.UA,S=UA.S,C=w.URBA_CONFIG,ACT=UA.ACT,R=UA.R;
const ILL=[['collines-aube','Collines de Mont-Ngafula au lever du jour'],['vallee-lukaya','Vallée de la Lukaya'],['quartier-colline','Quartier sur colline'],['erosion-ravin','Ravinement : un risque à surveiller'],['reseau-alerte','Réseau d’alerte citoyen']];
UA.photos=async()=>{if(UA._ph)return UA._ph;const out=[];
 for(let i=1;i<=8;i++){const src='assets/photos/mont-ngafula-'+i+'.jpg';if(await new Promise(r=>{const m=new Image();m.onload=()=>r(1);m.onerror=()=>r(0);m.src=src}))out.push({src,t:'Mont-Ngafula',real:1})}
 ILL.forEach(a=>out.push({src:'assets/illustrations/'+a[0]+'.jpg',t:a[1]}));return UA._ph=out};
UA.mediaURL=async id=>{UA._mu=UA._mu||{};if(UA._mu[id])return UA._mu[id];const m=await DB.get('media',id);if(!m)return null;return UA._mu[id]=URL.createObjectURL(m.blob)};
UA.li=(r,opt)=>{const t=TYPE(r.type);opt=opt||{};return `<div class="li card" data-act="open" data-id="${r.id}"><div class="ic" style="color:${t.color};border-color:${t.color}66;background:${t.color}1c" data-th="${r.id}">${I(t.icon)}</div><div class="t"><b>${esc(t.label)} ${r.demo?'<span class="demo">DÉMO</span>':''}</b><span>${opt.dist?fmtKm(UA.dist(r))+' · ':''}${ago(r.created)}${r.sync==='pending'?' · <span style="color:var(--warn)">en attente d’envoi</span>':''}</span></div><span class="st ${r.status}">${STATUT_LABEL[r.status]}</span></div>`};
UA.fillThumbs=root=>{$$('[data-th]',root).forEach(async el=>{const r=S.reports.find(x=>x.id===el.dataset.th);if(!r||!r.mediaIds||!r.mediaIds.length)return;const m=await DB.get('media',r.mediaIds[0]);if(!m)return;
 if(m.kind==='image'){const u=await UA.mediaURL(m.id);el.outerHTML=`<img class="thumb" src="${u}" alt="">`}})};
function paint(id,html){const sc=$('#s-'+id),s=sc.querySelector('.scroll'),y=s?s.scrollTop:0;sc.innerHTML=html;const n=sc.querySelector('.scroll');if(n)n.scrollTop=y;UA.fillThumbs(sc)}
const first=n=>(n||'').trim().split(/\s+/)[0]||'';
R.refresh=()=>{const s=S.screen;if(s==='home')R.home();else if(s==='history')R.history();else if(s==='profile')R.profile();else if(s==='map'&&UA.map)UA.mapSync()};
GEO.onChange(g=>{if(UA.map){UA.map.user=g.last;UA.map.dirty=true}if(S.screen==='home')R.home()});

/* ---------- onboarding ---------- */
const SL=[['onb-signaler','Signalez en quelques secondes','Photo, vidéo et description : alertez les services de la commune sur une voirie dégradée, une érosion, une inondation…'],
 ['onb-localiser','Localisation automatique','Votre position GPS est ajoutée à chaque signalement pour que les équipes interviennent au bon endroit.'],
 ['onb-alerte','Alertes dans un rayon de 5 km','Soyez prévenu des incidents proches de vous, et gardez le contact par SMS même sans internet.']];
let oi=0;
R.onb=()=>{const sc=$('#s-onb');sc.className='screen onb on';sc.innerHTML=`<div style="width:100%;display:flex;justify-content:space-between;align-items:center"><span class="eyebrow">UrbaAlerte</span><button class="btn gh sm" data-act="onbSkip">Passer</button></div>`+
 SL.map((s,i)=>`<div class="slide ${i===oi?'on':''}"><img class="an" src="assets/anim/${s[0]}.svg" alt=""><h1>${s[1]}</h1><p>${s[2]}</p></div>`).join('')+
 `<div style="width:100%"><div class="dots" style="justify-content:center;margin:0 0 18px">${SL.map((_,i)=>`<i class="${i===oi?'on':''}"></i>`).join('')}</div><button class="btn pri blk" data-act="onbNext">${oi===SL.length-1?'Commencer':'Suivant'} ${I('chev')}</button></div>`};
ACT.onbNext=()=>{if(oi<SL.length-1){oi++;R.onb()}else ACT.onbSkip()};
ACT.onbSkip=()=>{S.cfg.onbDone=true;UA.saveCfg();UA.go('auth')};

/* ---------- authentification ---------- */
let tab='reg',fails=0,lockUntil=0;
R.auth=()=>{const sc=$('#s-auth');sc.className='screen auth on';
 sc.innerHTML=`<div class="scroll" style="padding-bottom:30px"><div style="text-align:center;margin-top:8px"><img class="logo" src="assets/icons/icon-192.png" alt="UrbaAlerte"><h1 style="margin-top:14px">UrbaAlerte</h1><div class="eyebrow" style="margin-top:4px">Kinshasa · Signalement citoyen</div></div>
 <div class="tabs"><button class="${tab==='reg'?'on':''}" data-act="tab" data-t="reg">Inscription</button><button class="${tab==='log'?'on':''}" data-act="tab" data-t="log">Connexion</button></div>
 <form id="af" novalidate autocomplete="on">
 ${tab==='reg'?`<label class="field"><span>Nom complet</span><div class="in" data-f="name">${I('user')}<input name="name" autocomplete="name" placeholder="Ex. Jean-Paul Mukendi" maxlength="60"></div><div class="hint" data-e="name"></div></label>`:''}
 <label class="field"><span>Numéro de téléphone</span><div class="in" data-f="phone">${I('phone')}<span class="mono mut" style="font-size:13px">+243</span><input name="phone" type="tel" inputmode="tel" autocomplete="tel" placeholder="8X XXX XXXX" maxlength="16"></div><div class="hint" data-e="phone"></div></label>
 <label class="field"><span>Mot de passe</span><div class="in" data-f="pwd">${I('lock')}<input name="pwd" type="password" autocomplete="${tab==='reg'?'new-password':'current-password'}" placeholder="${tab==='reg'?'6 caractères minimum':'Votre mot de passe'}"><button type="button" data-act="eye" aria-label="Afficher">${I('eye')}</button></div><div class="hint" data-e="pwd"></div></label>
 ${tab==='reg'?`<label class="field"><span>Confirmer le mot de passe</span><div class="in" data-f="pwd2">${I('lock')}<input name="pwd2" type="password" autocomplete="new-password" placeholder="Répétez le mot de passe"></div><div class="hint" data-e="pwd2"></div></label>`:''}
 <div class="hint bad" id="aerr" style="min-height:18px;margin-bottom:8px"></div>
 <button class="btn pri blk" type="submit" id="abtn">${tab==='reg'?'Créer mon compte':'Se connecter'} ${I('chev')}</button></form>
 <p class="hint" style="text-align:center;margin-top:16px">${API.enabled?'Connecté au serveur UrbaAlerte.':'Mode démonstration : le compte est conservé uniquement sur cet appareil.'}</p></div>`;
 $('#af').addEventListener('submit',submitAuth)};
ACT.tab=b=>{tab=b.dataset.t;R.auth()};
ACT.eye=b=>{const i=b.parentNode.querySelector('input');i.type=i.type==='password'?'text':'password'};
function bad(f,msg){const p=$(`[data-f="${f}"]`),h=$(`[data-e="${f}"]`);if(p)p.classList.add('err');if(h){h.textContent=msg;h.classList.add('bad')}return false}
async function submitAuth(e){e.preventDefault();const f=e.target,v=n=>f.elements[n]?f.elements[n].value.trim():'';
 $$('.in.err').forEach(x=>x.classList.remove('err'));$$('[data-e]').forEach(x=>{x.textContent='';x.classList.remove('bad')});$('#aerr').textContent='';
 let ok=true;const name=v('name').replace(/\s+/g,' '),phone=normPhone(v('phone')),pwd=f.elements.pwd.value;
 if(tab==='reg'&&(name.split(' ').length<2||name.length<5))ok=bad('name','Saisissez votre nom complet (prénom et nom).');
 if(!phone)ok=bad('phone','Numéro RDC invalide (ex. 81 234 5678).');
 if(pwd.length<6)ok=bad('pwd','Au moins 6 caractères.');
 if(tab==='reg'&&f.elements.pwd2.value!==pwd)ok=bad('pwd2','Les mots de passe ne correspondent pas.');
 if(!ok)return;const btn=$('#abtn');btn.disabled=true;
 try{
  if(tab==='reg'){const users=await DB.all('users');if(users.some(u=>u.phone===phone)){btn.disabled=false;return bad('phone','Ce numéro est déjà inscrit — connectez-vous.')}
   let remote=null;if(API.enabled&&UA.online()){try{remote=await API.register(name,phone,pwd);API.token=remote.token||null}catch(er){btn.disabled=false;$('#aerr').textContent='Serveur indisponible ou inscription refusée ('+er.message+').';return}}
   const h=await hashPwd(pwd);const user={id:(remote&&remote.user&&remote.user.id)||uid(),name,phone,salt:h.salt,hash:h.hash,created:Date.now()};await DB.put('users',user);toast('Compte créé — bienvenue '+esc(first(name)),'ok',3000,'check');await UA.enter(user)}
  else{if(Date.now()<lockUntil){btn.disabled=false;$('#aerr').textContent='Trop d’essais. Réessayez dans '+Math.ceil((lockUntil-Date.now())/1000)+' s.';return}
   let user=(await DB.all('users')).find(u=>u.phone===phone);
   if(API.enabled&&UA.online()){try{const r=await API.login(phone,pwd);API.token=r.token||null;if(!user){user={id:(r.user&&r.user.id)||uid(),name:(r.user&&(r.user.nom_complet||r.user.name))||'Citoyen',phone,created:Date.now()};await DB.put('users',user)}await UA.enter(user);return}catch(er){if(er.status===401||er.status===400){btn.disabled=false;$('#aerr').textContent='Téléphone ou mot de passe incorrect.';return}}}
   if(!user){btn.disabled=false;$('#aerr').textContent='Aucun compte pour ce numéro — créez un compte.';return}
   const h=await hashPwd(pwd,user.salt);if(h.hash!==user.hash){fails++;if(fails>=5){lockUntil=Date.now()+30000;fails=0}btn.disabled=false;return bad('pwd','Téléphone ou mot de passe incorrect.')}
   fails=0;await UA.enter(user)}
 }catch(er){console.error(er);btn.disabled=false;$('#aerr').textContent='Erreur : '+er.message}}

/* ---------- permissions ---------- */
R.permSheet=()=>{S.cfg.permAsked=true;UA.saveCfg();sheet(`<div style="text-align:center"><img src="assets/anim/pulse-alert.svg" style="width:150px" alt=""><h2 style="margin:6px 0">Activer la localisation et les alertes</h2><p class="mut" style="margin:0 0 18px">UrbaAlerte utilise votre position pour géolocaliser vos signalements et vous prévenir des incidents dans un rayon de ${S.cfg.radius} km.</p><button class="btn pri blk" data-act="perm">${I('locate')} Autoriser</button><button class="btn gh blk" style="margin-top:10px" data-close>Plus tard</button></div>`)};
ACT.perm=async()=>{closeSheet();try{await GEO.once()}catch(e){toast(esc(e.message),'bad',4000,'alert')}
 try{if('Notification' in w&&Notification.permission==='default')await Notification.requestPermission()}catch(e){}R.refresh()};

/* ---------- accueil ---------- */
R.home=async()=>{const u=S.user;if(!u)return;const p=UA.pos(),near=S.reports.filter(r=>r.status!=='REJETE'&&r.status!=='CLOS'&&r.status!=='RESOLU'&&UA.dist(r)<=S.cfg.radius).sort((a,b)=>UA.dist(a)-UA.dist(b));
 const mine=UA.mine(),zones=UA.zones(),inZone=GEO.last?RISK.at(zones,p.lat,p.lng):null,un=UA.unread();
 const gs=GEO.status==='ok'&&GEO.last&&GEO.last.src==='gps'?['','GPS actif'+(GEO.last.acc?' ±'+Math.round(GEO.last.acc)+' m':'')]:GEO.status==='loading'?['warn','Localisation…']:['off','GPS indisponible'];
 const ph=await UA.photos();const hi=(UA._hi=UA._hi||0)%ph.length;
 paint('home',`<div class="scroll"><div class="top"><div><div class="eyebrow">Mont-Ngafula · Kinshasa</div><h1>Bonjour, ${esc(first(u.name))}</h1></div><button class="iconbtn" data-act="alerts" aria-label="Alertes">${I('bell')}${un?`<span class="badge">${un}</span>`:''}</button></div>
 <div class="chips"><span class="chip ${gs[0]}"><i class="d"></i>${gs[1]}</span><span class="chip ${UA.online()?'':'off'}"><i class="d"></i>${UA.online()?'En ligne':'Hors ligne'}</span><span class="chip">${I('radar').replace('class="i ','class="i " style="width:14px;height:14px" data-x="')}Rayon ${S.cfg.radius} km</span></div>
 <div class="hero hud" id="hero"><img class="bg" src="${ph[hi].src}" alt=""><span class="tag chip">${ph[hi].real?'Photo':'Illustration'}</span><div class="in"><div class="eyebrow">Commune pilote</div><h2 style="font-size:22px;margin-top:2px">${esc(ph[hi].t)}</h2><div class="dots">${ph.slice(0,6).map((_,i)=>`<i class="${i===hi%6?'on':''}"></i>`).join('')}</div></div></div>
 <button class="sig" data-act="report"><span class="pl">${I('plus')}</span><span><b>Signaler un incident</b><small>Photo · vidéo · position GPS automatique</small></span></button>
 ${inZone?`<div class="card" style="padding:12px 14px;margin-bottom:12px;border-color:${inZone.color}88;display:flex;gap:12px;align-items:center"><span style="color:${inZone.color}">${I('alert')}</span><div style="font-size:13px"><b>Vous êtes dans une zone à risque ${inZone.level.toLowerCase()}</b><br><span class="mut">${inZone.count} signalement${inZone.count>1?'s':''} récent${inZone.count>1?'s':''} · ${esc(TYPE(inZone.dom).label)}</span></div></div>`:''}
 <div class="grid2"><div class="card stat" data-go="history"><div class="n" style="color:var(--cyan2)">${mine.length}</div><div class="l">Mes signalements</div></div>
 <div class="card stat" data-go="map"><div class="n" style="color:var(--amber)">${near.length}</div><div class="l">Incidents actifs à ${S.cfg.radius} km</div></div>
 <div class="card stat" data-act="zones"><div class="n" style="color:var(--bad)">${zones.length}</div><div class="l">Zones à risques</div></div>
 <div class="card stat" data-act="alerts"><div class="n">${un}</div><div class="l">Alertes non lues</div></div></div>
 <div class="sec"><h2>Autour de vous</h2><a data-go="map">Voir la carte</a></div>
 ${near.length?near.slice(0,4).map(r=>UA.li(r,{dist:1})).join(''):`<div class="card empty">Aucun incident actif dans votre rayon.</div>`}
 <div class="card hud" style="padding:16px;margin-top:6px;display:flex;gap:14px;align-items:center"><div class="ic" style="color:var(--cyan2);border-color:var(--line2);background:rgba(34,211,238,.1)">${I('sms')}</div><div style="flex:1"><b>Alerte par SMS</b><div class="mut" style="font-size:12.5px">Pas d’internet ? Envoyez votre signalement par SMS.</div></div><button class="btn gh sm" data-act="sms">Ouvrir</button></div>
 <div class="sec"><h2>Mont-Ngafula en images</h2></div><div class="photo-strip">${ph.map(a=>`<div class="ph"><img src="${a.src}" alt="" loading="lazy"><span>${esc(a.t)}${a.real?'':' · illustration'}</span></div>`).join('')}</div></div>`);
 clearTimeout(UA._ht);UA._ht=setTimeout(()=>{if(S.screen==='home'){UA._hi=hi+1;R.home()}},9000)};
UA.leave.home=()=>clearTimeout(UA._ht);

/* ---------- alertes ---------- */
ACT.alerts=()=>{const list=S.alerts.slice(0,30);sheet(list.length?list.map(a=>`<div class="li card" data-act="open" data-id="${a.rid}"><div class="ic" style="color:${a.kind==='near'?'var(--amber)':'var(--ok)'};border-color:currentColor;background:rgba(255,255,255,.04)">${I(a.kind==='near'?'bell':'check')}</div><div class="t"><b style="white-space:normal">${esc(a.text)}</b><span>${ago(a.t)}</span></div></div>`).join(''):`<div class="empty"><img src="assets/anim/pulse-alert.svg" alt=""><p>Aucune alerte pour le moment.<br>Vous serez prévenu des incidents dans un rayon de ${S.cfg.radius} km.</p></div>`,{title:'Alertes'});
 let ch=false;S.alerts.forEach(a=>{if(!a.read){a.read=true;ch=true;DB.put('alerts',a)}});if(ch)setTimeout(R.refresh,50)};

/* ---------- carte ---------- */
let miniSel=null;
R.map=()=>{const sc=$('#s-map');if(!UA.map){const p=UA.pos();
 sc.innerHTML=`<div id="mapbox" style="position:absolute;inset:0"></div>
 <div class="mapui maptop"><div class="card"><span class="live"><i></i>TEMPS RÉEL</span><span class="mono mut" id="mcount" style="font-size:12px"></span></div><button class="iconbtn" data-act="alerts" style="background:rgba(7,16,42,.82)">${I('bell')}<span class="badge" id="mbadge" style="display:none"></span></button></div>
 <div class="mapui" style="top:calc(var(--sat) + 68px);left:0;right:0;padding:0 12px"><div class="chips" id="mchips"></div></div>
 <div class="mapui mapside" style="top:calc(var(--sat) + 124px)"><button class="iconbtn" data-act="locate" aria-label="Ma position">${I('locate')}</button><button class="iconbtn" id="brisk" data-act="risk" aria-label="Zones à risques">${I('flame')}</button><button class="iconbtn" id="brad" data-act="rad" aria-label="Rayon">${I('radar')}</button><button class="iconbtn" data-act="zones" aria-label="Liste des zones">${I('layers')}</button></div>
 <div class="legend card" id="legend" style="top:calc(var(--sat) + 124px)"><b>Zones à risques</b><div class="bar"></div><div style="display:flex;justify-content:space-between"><span>Modéré</span><span>Critique</span></div><div class="dim" style="margin-top:4px;font-size:10px">Indicatif · données citoyennes</div></div>
 <div class="attrib">${esc(C.TILE_ATTRIB)}</div><div class="mapui sheetmini card" id="mini" style="display:none"></div>`;
 S.showRisk=true;S.showRad=true;
 UA.map=new UMap($('#mapbox'),{lat:p.lat,lng:p.lng,zoom:14,tileUrl:C.TILE_URL,onTap:(m)=>{miniSel=m?m.id:null;UA.map.selected=miniSel;showMini()}});
 UA.map.layers.push((g,m)=>{if(!S.showRisk)return;UA.zones().forEach(z=>{const c=m.px(z.lat,z.lng),r=Math.max(26,RISK.STEP*111320*.9/m.mpp());if(c.x<-r||c.y<-r||c.x>m.w+r||c.y>m.h+r)return;const gr=g.createRadialGradient(c.x,c.y,0,c.x,c.y,r);gr.addColorStop(0,z.color+'99');gr.addColorStop(.6,z.color+'44');gr.addColorStop(1,z.color+'00');g.fillStyle=gr;g.beginPath();g.arc(c.x,c.y,r,0,Math.PI*2);g.fill()})});
 UA.map.user=GEO.last;UA.map.radius=S.cfg.radius;$('#legend').classList.add('on');$('#brisk').classList.add('on');$('#brad').classList.add('on')}
 UA.map.user=GEO.last;UA.map.radius=S.showRad?S.cfg.radius:null;UA.map.start();UA.mapSync();
 if(!GEO.last)GEO.once().then(g=>UA.map.flyTo(g.lat,g.lng,14)).catch(()=>{})};
UA.leave.map=()=>{if(UA.map)UA.map.stop()};
UA.mapSync=()=>{if(!UA.map)return;const f=S.filter;const list=S.reports.filter(r=>r.status!=='REJETE'&&(!f||r.type===f));
 UA.map.markers=list.map(r=>{const t=TYPE(r.type);return{id:r.id,lat:r.lat,lng:r.lng,color:t.color,icon:t.icon,mine:S.user&&r.userId===S.user.id,fresh:r.fresh}});
 const c=$('#mchips');if(c)c.innerHTML=`<span class="chip ${!f?'on':''}" data-act="flt" data-t="">Tous</span>`+TYPES.map(t=>`<span class="chip ${f===t.id?'on':''}" data-act="flt" data-t="${t.id}" style="${f===t.id?'':'color:'+t.color}">${I(t.icon).replace('class="i ','class="i " style="width:15px;height:15px" data-x="')}${esc(t.label.split(' ')[0])}</span>`).join('');
 const mc=$('#mcount');if(mc)mc.textContent=list.length+' incidents';const un=UA.unread(),b=$('#mbadge');if(b){b.style.display=un?'grid':'none';b.textContent=un}UA.map.dirty=true;showMini()};
UA.selectMarker=id=>{miniSel=id;if(UA.map)UA.map.selected=id;showMini()};
function showMini(){const el=$('#mini');if(!el)return;const r=S.reports.find(x=>x.id===miniSel);if(!r){el.style.display='none';return}const t=TYPE(r.type);
 el.style.display='block';el.innerHTML=`<div style="display:flex;gap:12px;align-items:center"><div class="ic" style="color:${t.color};border-color:${t.color}66;background:${t.color}1c">${I(t.icon)}</div><div style="flex:1;min-width:0"><b>${esc(t.label)}</b> ${r.demo?'<span class="demo">DÉMO</span>':''}<div class="mut" style="font-size:12px">${fmtKm(UA.dist(r))} · ${ago(r.created)}</div></div><span class="st ${r.status}">${STATUT_LABEL[r.status]}</span></div><p class="mut" style="font-size:13px;margin:10px 0;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden">${esc(r.desc)}</p><button class="btn pri blk sm" data-act="open" data-id="${r.id}">Voir le détail ${I('chev')}</button>`}
ACT.flt=b=>{S.filter=b.dataset.t||null;UA.mapSync()};
ACT.locate=async()=>{try{const g=await GEO.once();UA.map.flyTo(g.lat,g.lng,15)}catch(e){toast(esc(e.message),'bad',3500,'alert');const p=UA.pos();UA.map.flyTo(p.lat,p.lng,14)}};
ACT.risk=b=>{S.showRisk=!S.showRisk;b.classList.toggle('on',S.showRisk);$('#legend').classList.toggle('on',S.showRisk);UA.map.dirty=true};
ACT.rad=b=>{S.showRad=!S.showRad;b.classList.toggle('on',S.showRad);UA.map.radius=S.showRad?S.cfg.radius:null};
ACT.zones=()=>{const z=UA.zones();sheet(`<p class="mut" style="margin:0 0 12px;font-size:12.5px">Zones calculées à partir de la densité et de la gravité des signalements récents des 30 derniers jours (grille ≈ 500 m). <b>Indicatif</b> : ce n’est pas une donnée officielle.</p>`+
 (z.length?z.slice(0,12).map(x=>{const t=TYPE(x.dom),d=haversine(UA.pos().lat,UA.pos().lng,x.lat,x.lng);return `<div class="li card" data-act="zfocus" data-lat="${x.lat}" data-lng="${x.lng}"><div class="ic" style="color:${x.color};border-color:${x.color}77;background:${x.color}1c">${I(t.icon)}</div><div class="t"><b>Zone ${x.level.toLowerCase()} · ${esc(t.label)}</b><span>${x.count} signalements · à ${fmtKm(d)}</span></div>${I('chev')}</div>`}).join(''):'<div class="empty">Aucune zone à risque détectée.</div>'),{title:'Zones à risques'})};
ACT.zfocus=b=>{closeSheet();UA.go('map');setTimeout(()=>UA.map.flyTo(+b.dataset.lat,+b.dataset.lng,16),200)};

/* ---------- historique ---------- */
let hf='all';
R.history=()=>{const all=UA.mine(),done=['RESOLU','CLOS','REJETE'];const l=all.filter(r=>hf==='all'||(hf==='act'?!done.includes(r.status):done.includes(r.status)));
 paint('history',`<div class="scroll"><div class="top"><div><div class="eyebrow">Mon activité</div><h1>Historique</h1></div><button class="iconbtn" data-act="alerts">${I('bell')}</button></div>
 <div class="chips"><span class="chip ${hf==='all'?'on':''}" data-act="hf" data-t="all">Tous (${all.length})</span><span class="chip ${hf==='act'?'on':''}" data-act="hf" data-t="act">En cours</span><span class="chip ${hf==='done'?'on':''}" data-act="hf" data-t="done">Terminés</span></div>
 ${l.length?l.map(r=>UA.li(r)).join(''):`<div class="empty"><img src="assets/anim/pulse-alert.svg" alt=""><p>${all.length?'Aucun signalement dans cette catégorie.':'Vous n’avez encore rien signalé.'}</p><button class="btn hot" data-act="report">${I('plus')} Faire un signalement</button></div>`}</div>`)};
ACT.hf=b=>{hf=b.dataset.t;R.history()};

/* ---------- profil ---------- */
R.profile=()=>{const u=S.user;if(!u)return;const m=UA.mine(),ini=u.name.split(' ').map(x=>x[0]).slice(0,2).join('').toUpperCase(),res=m.filter(r=>['RESOLU','CLOS'].includes(r.status)).length;
 const perm='Notification' in w?Notification.permission:'unsupported';
 paint('profile',`<div class="scroll"><div class="top"><div><div class="eyebrow">Mon compte</div><h1>Profil</h1></div><button class="iconbtn" data-act="editname" aria-label="Modifier">${I('edit')}</button></div>
 <div style="text-align:center"><div class="avatar">${esc(ini)}</div><h2 style="margin-top:12px">${esc(u.name)}</h2><div class="mut mono" style="font-size:13px">${showPhone(u.phone)}</div><div class="mut" style="font-size:12px;margin-top:2px">Membre depuis le ${new Date(u.created).toLocaleDateString('fr-FR')}</div></div>
 <div class="grid2" style="margin:18px 0"><div class="card stat"><div class="n" style="color:var(--cyan2)">${m.length}</div><div class="l">Signalements</div></div><div class="card stat"><div class="n" style="color:var(--ok)">${res}</div><div class="l">Résolus</div></div></div>
 <div class="card" style="padding:4px 16px">
 <div class="row"><div><b>Notifications de proximité</b><div class="mut" style="font-size:12px">${perm==='granted'?'Autorisées sur cet appareil':perm==='denied'?'Bloquées dans les réglages du téléphone':'Autorisation requise'}</div></div><button class="sw ${S.cfg.push?'on':''}" data-act="push" aria-label="Notifications"></button></div>
 <div class="row" style="display:block"><div style="display:flex;justify-content:space-between"><b>Rayon d’alerte</b><span class="mono" id="rv" style="color:var(--cyan2)">${S.cfg.radius} km</span></div><input type="range" min="1" max="10" step="1" value="${S.cfg.radius}" id="rr" aria-label="Rayon"></div>
 <div class="row" style="display:block"><b>Numéro de la passerelle SMS</b><div class="in" style="margin-top:8px;min-height:46px">${I('sms')}<input id="gw" type="tel" placeholder="+243…" value="${esc(S.cfg.gateway)}"></div><div class="hint">Numéro de la plateforme qui reçoit les alertes SMS hors ligne.</div></div>
 ${API.enabled?'':`<div class="row"><div><b>Simulation de démonstration</b><div class="mut" style="font-size:12px">Nouveaux incidents fictifs et avancement de vos signalements</div></div><button class="sw ${S.cfg.sim?'on':''}" data-act="sim" aria-label="Simulation"></button></div>`}
 </div>
 <div style="display:grid;gap:10px;margin-top:16px"><button class="btn gh blk" data-act="zones">${I('flame')} Zones à risques</button>${API.enabled?'':`<button class="btn gh blk" data-act="recenter">${I('target')} Recentrer les données démo ici</button>`}<button class="btn dng blk" data-act="logout">${I('logout')} Se déconnecter</button></div>
 <p class="hint" style="text-align:center;margin-top:18px">UrbaAlerte v${C.VERSION} · ${API.enabled?'Connecté à l’API':'Mode démonstration locale'}<br>Mont-Ngafula · Kinshasa</p></div>`);
 const rr=$('#rr');if(rr)rr.oninput=()=>{S.cfg.radius=+rr.value;$('#rv').textContent=rr.value+' km';UA.saveCfg()};
 const gw=$('#gw');if(gw)gw.onchange=()=>{S.cfg.gateway=gw.value.trim();UA.saveCfg();toast('Numéro enregistré','ok',2000,'check')}};
ACT.push=async()=>{if(!S.cfg.push){if('Notification' in w&&Notification.permission==='default')try{await Notification.requestPermission()}catch(e){}S.cfg.push=true}else S.cfg.push=false;UA.saveCfg();R.profile()};
ACT.sim=()=>{S.cfg.sim=!S.cfg.sim;UA.saveCfg();R.profile()};
ACT.logout=()=>UA.logout();
ACT.recenter=async()=>{const rs=S.reports.filter(r=>r.demo);for(const r of rs)await DB.del('reports',r.id);S.reports=S.reports.filter(r=>!r.demo);const c=UA.pos();for(const r of DEMO.seed(c)){await DB.put('reports',r);S.reports.push(r)}S._z=null;toast('Données démo régénérées autour de votre position','ok',3000,'check');R.profile()};
ACT.editname=()=>{sheet(`<label class="field"><span>Nom complet</span><div class="in">${I('user')}<input id="nn" value="${esc(S.user.name)}" maxlength="60"></div></label><button class="btn pri blk" data-act="savename">Enregistrer</button>`,{title:'Modifier mon nom'})};
ACT.savename=async()=>{const n=$('#nn').value.trim().replace(/\s+/g,' ');if(n.split(' ').length<2){toast('Saisissez prénom et nom','bad',2500,'alert');return}S.user.name=n;await DB.put('users',S.user);closeSheet();R.profile()};
})(window);
