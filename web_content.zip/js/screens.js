/* إدارة الشاشات وزر الرجوع في Android */
window.Screens = (function () {
  var stack = [];        // الشاشات المفتوحة بالترتيب
  var going = false;     // لمنع الضغط المزدوج على الرجوع

  function open(id, onClose) {
    document.getElementById(id).hidden = false;
    document.body.classList.add('locked');
    stack.push({ id: id, onClose: onClose });
    history.pushState({ depth: stack.length }, '');
  }

  function closeTop() {
    var s = stack.pop();
    if (!s) return;
    document.getElementById(s.id).hidden = true;
    if (s.onClose) s.onClose();
    if (!stack.length) document.body.classList.remove('locked');
  }

  function back() {
    if (!stack.length || going) return;
    going = true;
    history.back();
  }

  window.addEventListener('popstate', function (e) {
    going = false;
    var depth = (e.state && e.state.depth) || 0;
    while (stack.length > depth) closeTop();
  });

  // للأدوات المبنية على Cordova
  document.addEventListener('deviceready', function () {
    document.addEventListener('backbutton', function () {
      if (stack.length) back();
      else if (navigator.app) navigator.app.exitApp();
    }, false);
  });

  document.querySelectorAll('[data-back]').forEach(function (b) { b.addEventListener('click', back); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') back(); });

  return {
    open: open,
    back: back,
    top: function () { return stack.length ? stack[stack.length - 1].id : null; }
  };
})();
