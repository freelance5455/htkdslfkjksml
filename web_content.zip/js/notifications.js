// =====================================================
// NetEarn Pro
// NOTIFICATIONS SYSTEM
// FINAL CLEAN + FAST + PREMIUM
//
// Firestore Collection:
// notifications
//
// Required fields:
// userUid
// title
// message
// createdAt
// read
//
// IMPORTANT:
// • Existing Firebase structure preserved
// • userUid preserved
// • createdAt preserved
// • read preserved
// • No artificial delay
// • UI renders before read updates
// =====================================================


import {
    auth,
    db
} from "./firebase.js";


import {
    onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";


import {
    collection,
    query,
    where,
    getDocs,
    doc,
    updateDoc
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";


// =====================================================
// ELEMENT
// =====================================================

const notificationList =
    document.getElementById(
        "notificationList"
    );


// =====================================================
// ICONS
// =====================================================

const bellIcon = `
    <svg
        viewBox="0 0 24 24"
        width="19"
        height="19"
        fill="none"
        stroke="currentColor"
        stroke-width="2"
        stroke-linecap="round"
        stroke-linejoin="round"
        aria-hidden="true">

        <path
            d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9">
        </path>

        <path
            d="M13.73 21a2 2 0 0 1-3.46 0">
        </path>

    </svg>
`;


const clockIcon = `
    <svg
        viewBox="0 0 24 24"
        width="13"
        height="13"
        fill="none"
        stroke="currentColor"
        stroke-width="2"
        stroke-linecap="round"
        stroke-linejoin="round"
        aria-hidden="true">

        <circle
            cx="12"
            cy="12"
            r="9">
        </circle>

        <path
            d="M12 7v5l3 2">
        </path>

    </svg>
`;


const alertIcon = `
    <svg
        viewBox="0 0 24 24"
        width="27"
        height="27"
        fill="none"
        stroke="currentColor"
        stroke-width="2"
        stroke-linecap="round"
        stroke-linejoin="round"
        aria-hidden="true">

        <path
            d="M10.3 3.7 2.7 17a2 2 0 0 0 1.7 3h15.2a2 2 0 0 0 1.7-3L13.7 3.7a2 2 0 0 0-3.4 0Z">
        </path>

        <path
            d="M12 9v4">
        </path>

        <path
            d="M12 17h.01">
        </path>

    </svg>
`;


// =====================================================
// AUTH
// =====================================================

onAuthStateChanged(
    auth,
    async (user) => {

        if (!user) {

            window.location.href =
                "index.html";

            return;

        }


        await loadNotifications(
            user.uid
        );

    }
);


// =====================================================
// ⚡ NOTIFICATION CACHE
// =====================================================
function restoreNotificationCache(uid) {
    try {
        const raw = localStorage.getItem(`netearnNotificationsCache_${uid}`);
        if (!raw) return false;
        const cached = JSON.parse(raw);
        if (!cached || !cached.html) return false;
        notificationList.innerHTML = cached.html;
        return true;
    } catch (_) {
        return false;
    }
}

function saveNotificationCache(uid, html) {
    try {
        localStorage.setItem(`netearnNotificationsCache_${uid}`, JSON.stringify({
            html, cachedAt: Date.now()
        }));
    } catch (_) {}
}

// =====================================================
// LOAD NOTIFICATIONS
// =====================================================

async function loadNotifications(uid) {

    if (!notificationList) {
        return;
    }


    try {

        // ⚡ Show the last rendered notification list immediately.
        const hasCachedNotifications = restoreNotificationCache(uid);

        // =================================================
        // FIRESTORE QUERY
        // =================================================

        const notificationsRef =
            collection(
                db,
                "notifications"
            );


        const q =
            query(
                notificationsRef,
                where(
                    "userUid",
                    "==",
                    uid
                )
            );


        // =================================================
        // GET DATA
        // =================================================

        const snapshot =
            await getDocs(q);


        // =================================================
        // SORT NEWEST FIRST
        // =================================================

        const notifications =
            snapshot.docs.sort(
                (a, b) => {

                    const dataA =
                        a.data();

                    const dataB =
                        b.data();


                    const timeA =
                        dataA.createdAt?.seconds ||
                        0;


                    const timeB =
                        dataB.createdAt?.seconds ||
                        0;


                    return (
                        timeB - timeA
                    );

                }
            );


        // =================================================
        // NO NOTIFICATION
        // =================================================

        if (
            notifications.length === 0
        ) {

            showEmpty();

            return;

        }


        // =================================================
        // RENDER ALL FIRST
        // =================================================

        notificationList.innerHTML =
            notifications
                .map(
                    renderNotification
                )
                .join("");

        // Save the successful render for instant next visit.
        saveNotificationCache(
            uid,
            notificationList.innerHTML
        );


        // =================================================
        // MARK UNREAD AS READ
        // =================================================

        markNotificationsAsRead(
            notifications
        );


    }

    catch (error) {

        console.error(
            "❌ Notification Load Error:",
            error
        );


        showError();

    }

}


// =====================================================
// RENDER NOTIFICATION
// =====================================================

function renderNotification(
    docSnap
) {

    const data =
        docSnap.data();


    // =================================================
    // SAFE VALUES
    // =================================================

    const title =
        escapeHTML(
            data.title || "Notification"
        );


    const message =
        escapeHTML(
            data.message || ""
        );


    const date =
        formatDate(
            data.createdAt
        );


    const isUnread =
        data.read === false;


    const unreadClass =
        isUnread
            ? " unread"
            : "";


    const unreadBadge =
        isUnread
            ?
            `<span class="unread-badge">
                NEW
            </span>`
            :
            "";


    // =================================================
    // CARD
    // =================================================

    return `

        <article
            class="notice-card${unreadClass}"
            data-id="${docSnap.id}"
        >

            <div class="notice-top">


                <div class="notice-icon">

                    ${bellIcon}

                </div>


                <div class="notice-content">


                    <div class="notice-title">

                        ${title}

                        ${unreadBadge}

                    </div>


                    <div class="notice-message">

                        ${message}

                    </div>


                </div>


            </div>


            <div class="notice-date">

                ${clockIcon}

                <span>
                    ${date}
                </span>

            </div>


        </article>

    `;

}


// =====================================================
// MARK AS READ
// =====================================================

function markNotificationsAsRead(
    notifications
) {

    const unread =
        notifications.filter(
            (docSnap) =>
                docSnap.data().read === false
        );


    if (
        unread.length === 0
    ) {

        return;

    }


    Promise.allSettled(

        unread.map(
            (docSnap) => {

                return updateDoc(

                    doc(
                        db,
                        "notifications",
                        docSnap.id
                    ),

                    {
                        read: true
                    }

                );

            }
        )

    )
    .then(() => {

        console.log(
            `✅ ${unread.length} notification(s) marked as read.`
        );

    })
    .catch((error) => {

        console.warn(
            "⚠️ Read status update failed:",
            error
        );

    });

}


// =====================================================
// DATE FORMAT
// =====================================================

function formatDate(
    timestamp
) {

    if (
        !timestamp ||
        typeof timestamp.toDate !== "function"
    ) {

        return "";

    }


    try {

        return timestamp
            .toDate()
            .toLocaleString(
                "en-BD",
                {
                    dateStyle: "medium",
                    timeStyle: "short"
                }
            );

    }

    catch (error) {

        return "";

    }

}


// =====================================================
// EMPTY STATE
// =====================================================

function showEmpty() {

    notificationList.innerHTML = `

        <div class="notification-empty">


            <div class="empty-icon">

                ${bellIcon}

            </div>


            <h3>
                No Notifications
            </h3>


            <p>
                নতুন কোনো notification এখনো আসেনি।
            </p>


        </div>

    `;

}


// =====================================================
// ERROR STATE
// =====================================================

function showError() {

    notificationList.innerHTML = `

        <div class="notification-error">


            <div class="error-icon">

                ${alertIcon}

            </div>


            <h3>
                Failed to Load
            </h3>


            <p>
                Notifications load করা যায়নি।
                আবার চেষ্টা করুন।
            </p>


        </div>

    `;

}


// =====================================================
// HTML SAFETY
// =====================================================

function escapeHTML(
    value
) {

    return String(value)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}


// =====================================================
// FINAL LOG
// =====================================================

console.log(
    "✅ NetEarn Pro Notifications — PROFESSIONAL PREMIUM VERSION LOADED"
);