/**
 * BD BLOOD DONATION - Notification Center & Real-Time View
 * Handles live push/in-app notifications, badge counts, and read/clear actions.
 */

import { 
  db, 
  collection, 
  doc, 
  query, 
  where, 
  orderBy, 
  limit, 
  onSnapshot, 
  updateDoc, 
  deleteDoc, 
  getDocs 
} from './firebase-config.js';
import { getCurrentUser } from './auth.js';
import { formatTimeAgo, escapeHtml, showToast, getLanguage } from './utils.js';

let unreadCount = 0;
const countListeners = [];

export function onUnreadCountChanged(callback) {
  countListeners.push(callback);
  callback(unreadCount);
  return () => {
    const idx = countListeners.indexOf(callback);
    if (idx > -1) countListeners.splice(idx, 1);
  };
}

function notifyCountListeners() {
  countListeners.forEach(cb => cb(unreadCount));
}

export function subscribeNotifications(userId, onUpdate) {
  if (!userId) return () => {};

  const q = query(
    collection(db, 'notifications'),
    where('recipientId', '==', userId),
    orderBy('createdAt', 'desc'),
    limit(40)
  );

  return onSnapshot(
    q,
    (snapshot) => {
      const items = [];
      let unread = 0;
      snapshot.forEach(docSnap => {
        const data = { id: docSnap.id, ...docSnap.data() };
        if (!data.read) unread++;
        items.push(data);
      });
      unreadCount = unread;
      notifyCountListeners();
      if (onUpdate) onUpdate(items, unread);
    },
    (err) => {
      console.warn('[Notifications Listener Error]', err.message);
    }
  );
}

export async function markNotificationAsRead(notifId) {
  try {
    const ref = doc(db, 'notifications', notifId);
    await updateDoc(ref, { read: true });
  } catch (e) {
    console.warn('[Mark Read Error]', e.message);
  }
}

export async function markAllNotificationsAsRead(userId) {
  try {
    const q = query(
      collection(db, 'notifications'),
      where('recipientId', '==', userId),
      where('read', '==', false)
    );
    const snap = await getDocs(q);
    const promises = snap.docs.map(d => updateDoc(doc(db, 'notifications', d.id), { read: true }));
    await Promise.all(promises);
    unreadCount = 0;
    notifyCountListeners();
    showToast('সব নোটিফিকেশন পড়া হিসেবে চিহ্নিত হয়েছে।', 'success');
  } catch (e) {
    console.warn('[Mark All Read Error]', e.message);
  }
}

export async function deleteNotification(notifId) {
  try {
    await deleteDoc(doc(db, 'notifications', notifId));
  } catch (e) {
    console.warn('[Delete Notification Error]', e.message);
  }
}

/**
 * Render Notifications Page
 */
export async function renderNotificationsPage(container) {
  const user = getCurrentUser();
  const isBn = getLanguage() === 'bn';

  if (!user) {
    container.innerHTML = `
      <div class="page-container animate-slide-in">
        <div class="empty-state card">
          <div class="empty-state-icon">🔔</div>
          <div class="empty-state-title">${isBn ? 'লগইন প্রয়োজন' : 'Login Required'}</div>
          <div class="empty-state-desc">${isBn ? 'আপনার নোটিফিকেশনসমূহ দেখতে দয়া করে লগইন করুন।' : 'Please login to view notifications.'}</div>
          <a href="#/login" class="btn btn-primary btn-sm" style="margin-top: 10px;">${isBn ? 'লগইন করুন' : 'Login'}</a>
        </div>
      </div>
    `;
    return;
  }

  container.innerHTML = `
    <div class="page-container animate-slide-in">
      <div class="page-header-title">
        <span>🔔 ${isBn ? 'নোটিফিকেশন সেন্টার' : 'Notifications'}</span>
        <button id="mark-all-read-btn" class="btn btn-secondary btn-sm" style="font-size: 11px;">
          ✓ ${isBn ? 'সব পড়া হয়েছে' : 'Mark All Read'}
        </button>
      </div>

      <div id="notifications-list-container">
        <div class="spinner"></div>
      </div>
    </div>
  `;

  document.getElementById('mark-all-read-btn').addEventListener('click', async () => {
    await markAllNotificationsAsRead(user.uid);
  });

  const listContainer = document.getElementById('notifications-list-container');

  // Live real-time subscription
  const unsubscribe = subscribeNotifications(user.uid, (items) => {
    if (!listContainer) return;

    if (items.length === 0) {
      listContainer.innerHTML = `
        <div class="empty-state card">
          <div class="empty-state-icon">🔕</div>
          <div class="empty-state-title">${isBn ? 'কোনো নোটিফিকেশন নেই' : 'No Notifications'}</div>
          <div class="empty-state-desc">${isBn ? 'আপনার জন্য এই মুহূর্তে নতুন কোনো বিজ্ঞপ্তি বা অনুরোধ নেই।' : 'No notifications for you right now.'}</div>
        </div>
      `;
      return;
    }

    let html = '';
    items.forEach(item => {
      let icon = '🔔';
      if (item.type === 'emergency_request') icon = '🚨';
      else if (item.type === 'matching_request') icon = '🩸';
      else if (item.type === 'request_accepted') icon = '🎉';
      else if (item.type === 'new_chat_message') icon = '💬';
      else if (item.type === 'rating_received') icon = '⭐';
      else if (item.type === 'donation_completed') icon = '❤️';

      html += `
        <div class="notification-item ${item.read ? '' : 'unread'}" data-id="${item.id}" data-type="${item.type}" data-request-id="${item.requestId || ''}" data-conv-id="${item.conversationId || ''}">
          <div class="notification-icon-box">${icon}</div>
          <div class="notification-text-box">
            <div class="notification-title">${escapeHtml(item.title)}</div>
            <div class="notification-desc">${escapeHtml(item.message)}</div>
            <div class="notification-time">${formatTimeAgo(item.createdAt)}</div>
          </div>
          <button class="toast-close btn-del-notif" data-id="${item.id}" title="${isBn ? 'মুছুন' : 'Delete'}" style="color:var(--text-light);">&times;</button>
        </div>
      `;
    });

    listContainer.innerHTML = html;

    // Attach click events
    listContainer.querySelectorAll('.notification-item').forEach(el => {
      el.addEventListener('click', async (e) => {
        if (e.target.classList.contains('btn-del-notif')) return;
        const notifId = el.dataset.id;
        const reqId = el.dataset.requestId;
        const convId = el.dataset.convId;

        await markNotificationAsRead(notifId);

        if (convId) {
          window.location.hash = `#/chat?convId=${convId}`;
        } else if (reqId) {
          window.location.hash = `#/my-requests`;
        }
      });
    });

    listContainer.querySelectorAll('.btn-del-notif').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        await deleteNotification(btn.dataset.id);
      });
    });
  });

  // Store cleanup for SPA unmount
  container._unsubscribe = unsubscribe;
}
