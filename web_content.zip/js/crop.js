/* recorte da foto: arrastar para posicionar + zoom livre */
let CR=null,drag=null;const cc=$('#cc');
/* só aceita imagens que o navegador sabe abrir; confirma pelo conteúdo real do ficheiro (não só pela extensão) */
async function kind(f){try{const b=new Uint8Array(await f.slice(0,16).arrayBuffer()),s=String.fromCharCode(...b);
if(b[0]==0x89&&s.slice(1,4)=='PNG')return'png';if(b[0]==0xFF&&b[1]==0xD8)return'jpg';if(s.slice(0,3)=='GIF')return'gif';if(s.slice(0,4)=='RIFF'&&s.slice(8,12)=='WEBP')return'webp';if(s.slice(0,2)=='BM')return'bmp'}catch{}return''}
async function photo(file){if(!file)return;
if(file.size>25e6){alert('A imagem é demasiado grande (máximo 25 MB).');return}
if(!await kind(file)){alert('Formato não suportado. Use uma imagem JPG, PNG, WEBP, GIF ou BMP.');return}
const u=URL.createObjectURL(file),im=new Image();
im.onerror=()=>{URL.revokeObjectURL(u);alert('Não foi possível abrir esta imagem. Tente outra (JPG ou PNG).')};
im.onload=()=>{URL.revokeObjectURL(u);if(!im.width||!im.height||im.width*im.height>80e6){alert('Imagem inválida ou demasiado grande.');return}
const s=Math.min(1,1000/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=Math.max(1,Math.round(im.width*s));c.height=Math.max(1,Math.round(im.height*s));
const g=c.getContext('2d');g.fillStyle='#fff';g.fillRect(0,0,c.width,c.height);g.drawImage(im,0,0,c.width,c.height);
D.photoOrig=c.toDataURL('image/jpeg',.88);D.photoT=null;openCrop(D.photoOrig,null)};
im.src=u}
function openCrop(src,t){const im=new Image();im.onload=()=>{CR={img:im,z:t?t.z:1,x:t?t.x:0,y:t?t.y:0};$('#cz').value=CR.z;$('#crop').hidden=false;paintTo(cc,280,1)};im.onerror=()=>{$('#crop').hidden=true};im.src=src}
function paintTo(c,s,k){const g=c.getContext('2d'),im=CR.img,b=Math.max(s/im.width,s/im.height)*CR.z,w=im.width*b,h=im.height*b;g.fillStyle='#fff';g.fillRect(0,0,s,s);g.drawImage(im,(s-w)/2+CR.x*k,(s-h)/2+CR.y*k,w,h)}
const paint=()=>paintTo(cc,280,1);
$('#cz').oninput=e=>{CR.z=+e.target.value;paint()};
cc.onwheel=e=>{e.preventDefault();const z=$('#cz');z.value=+z.value*(e.deltaY<0?1.06:.94);CR.z=+z.value;paint()};
cc.onpointerdown=e=>{drag={x:e.clientX,y:e.clientY,ox:CR.x,oy:CR.y};cc.setPointerCapture(e.pointerId)};
cc.onpointermove=e=>{if(!drag)return;const k=280/cc.getBoundingClientRect().width;CR.x=drag.ox+(e.clientX-drag.x)*k;CR.y=drag.oy+(e.clientY-drag.y)*k;paint()};
cc.onpointerup=()=>drag=null;
$('#ck').onclick=()=>{const c=document.createElement('canvas');c.width=c.height=400;paintTo(c,400,400/280);D.photo=c.toDataURL('image/jpeg',.9);D.photoT={z:CR.z,x:CR.x,y:CR.y};$('#crop').hidden=true;build();up()};
$('#cx').onclick=()=>{$('#crop').hidden=true;if(!D.photo)D.photoOrig=''};
