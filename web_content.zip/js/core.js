/* Config, constants, state variables, small helpers (esc, $, icon, toast) */

  const C = window.IMPOSED_CONFIG || {};
  const ready = Boolean(window.supabase && C.SUPABASE_URL && !C.SUPABASE_URL.includes('PASTE_') && C.SUPABASE_ANON_KEY && !C.SUPABASE_ANON_KEY.includes('PASTE_'));
  const sb = ready ? window.supabase.createClient(C.SUPABASE_URL, C.SUPABASE_ANON_KEY) : null;

  const STORES = ['Spotify','Apple Music','iTunes','YouTube Music','Amazon Music','Deezer','TIDAL','Pandora','Napster','iHeartRadio','Claro Musica','JioSaavn','Anghami','KKBox','NetEase','Tencent','TikTok','Facebook','Instagram','Snapchat','CapCut','Pinterest','Nuuday','ROXi','Kuack Media','Qobuz','Joox','Boomplay','Trebel','Melon','Flo','Bugs','Genie','Vibe'];
  const GENRES = ['Electronic','Rock','Metal','Metalcore','Hip Hop','Pop','Alternative','Ambient','Other'];
  const TYPES = ['Single','EP','Album','Mixtape'];
  const STATUSES = ['Draft','Submitted','Changes Requested','Approved','Sent to distributor','Live','Rejected'];

  const isAdminRole = r => ['admin','label_admin'].includes(String(r||'').trim().toLowerCase());
  const isAdmin = () => !!profile && isAdminRole(profile.role);
  const GICON = '<svg width="18" height="18" viewBox="0 0 48 48" aria-hidden="true"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/><path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/></svg>';
  const greet = () => { const h=new Date().getHours(); return h<12?'Good morning':h<18?'Good afternoon':'Good evening'; };
  const firstName = () => String((profile&&(profile.display_name||profile.full_name))||'').split(' ')[0];
  let session = null;
  let profile = null;
  let releases = [];
  let users = [];
  let invites = [];
  let filter = 'All';
  let inbox = [], announcements = [], earnings = [], recentEvents = [];
  let inviteRole = 'artist';
  let detailTracks = [];
  let bands = [], bandMembers = [], bandInvites = [], myBandInvites = [], bandId = null;
  let invite = null;
  let view = 'dashboard';
  let selected = null;
  let mobile = false;
  let authMode = 'login';
  let wizardStep = 1;
  let draft = freshDraft();
  let busy = false;
  let search = '';
  let toastTimer;

  function newTrack(){ return {title:'',version:'',isrc:'',explicit:false,featured:'',writers:'',file:null,fileName:'',path:'',duration:null}; }
  function freshDraft() {
    return { id:null, title:'', artist:'', bandId:'', releaseType:'Single', genre:'Rock', releaseDate:'', cLine:'', pLine:'', language:'English', prevReleased:false, origDate:'', rights:false, territory:'Worldwide', stores:[...STORES], artworkFile:null, artworkPreview:'', artworkPath:'', tracks:[newTrack()], status:'Draft' };
  }
  const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
  const $ = s => document.querySelector(s);
  const icon = (name,size=18) => { const p={bell:'<path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/>',compass:'<circle cx="12" cy="12" r="9"/><path d="m15.5 8.5-2 5-5 2 2-5z"/>',disc:'<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="2"/><path d="M12 4v6"/>',home:'<path d="m3 10 9-7 9 7"/><path d="M5 9v11h14V9"/><path d="M9 20v-6h6v6"/>',plus:'<path d="M12 5v14M5 12h14"/>',search:'<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',settings:'<path d="M12 2v3M12 19v3M4.9 4.9 7 7M17 17l2.1 2.1M2 12h3M19 12h3M4.9 19.1 7 17M17 7l2.1-2.1"/><circle cx="12" cy="12" r="4"/>',menu:'<path d="M4 6h16M4 12h16M4 18h16"/>',x:'<path d="m6 6 12 12M18 6 6 18"/>',check:'<path d="m5 12 4 4L19 6"/>',arrow:'<path d="M5 12h14M13 6l6 6-6 6"/>',back:'<path d="M19 12H5M11 18l-6-6 6-6"/>',upload:'<path d="M12 16V4M7 9l5-5 5 5"/><path d="M5 20h14"/>',image:'<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="8.5" cy="9" r="1.5"/><path d="m21 15-5-5L5 20"/>',file:'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/>',users:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/>',logout:'<path d="M10 17l5-5-5-5M15 12H3"/><path d="M21 19V5a2 2 0 0 0-2-2h-6"/>',shield:'<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/>',eye:'<path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12z"/><circle cx="12" cy="12" r="2.5"/>',trash:'<path d="M4 7h16M10 11v6M14 11v6M6 7l1 14h10l1-14M9 7V4h6v3"/>',globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3.2 3 14.8 0 18M12 3c-3 3.2-3 14.8 0 18"/>',mail:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',lock:'<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',refresh:'<path d="M20 11a8 8 0 0 0-14.9-4L3 10"/><path d="M3 5v5h5M4 13a8 8 0 0 0 14.9 4L21 14"/><path d="M21 19v-5h-5"/>',download:'<path d="M12 3v12m0 0 5-5m-5 5-5-5M4 21h16"/>',edit:'<path d="m4 20 4.5-1 10-10a2.1 2.1 0 0 0-3-3l-10 10L4 20z"/><path d="m14.5 7.5 2 2"/>'}; return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${p[name]||''}</svg>`; };
  const statusClass = s => ({Draft:'neutral',Submitted:'blue','Changes Requested':'amber',Approved:'green','Sent to distributor':'blue',Live:'green',Rejected:'red'}[s]||'neutral');
  const currentLocale = () => ({en:'en-GB',es:'es-ES',fr:'fr-FR',de:'de-DE',pt:'pt-PT',pl:'pl-PL'}[(window.IE_I18N&&window.IE_I18N.language)||'en']||'en-GB');
  const formatNumber = (value, options={}) => Number(value||0).toLocaleString(currentLocale(),options);
  const dateFmt = d => d ? new Date(d+'T12:00:00').toLocaleDateString(currentLocale(),{day:'numeric',month:'short',year:'numeric'}) : 'No date';
  /* Artists never see distributor wording; the label does. */
  const statusLabel = s => (!isAdmin() && s==='Sent to distributor') ? 'Processing' : s;
  const typing = () => /^(INPUT|TEXTAREA|SELECT)$/.test((document.activeElement&&document.activeElement.tagName)||'');
  function toast(msg,type='info'){ const r=$('#toast-root'); if(!r)return; r.innerHTML=`<div class="toast ${type}"><span class="toast-dot"></span><span>${esc(msg)}</span></div>`; clearTimeout(toastTimer); toastTimer=setTimeout(()=>r.innerHTML='',4000); }

  /* Hash routing: refresh stays on the same page */
  const ROUTES=['dashboard','settings','earnings','notifications','bands','roster','discover','discography'];
  function syncHash(){ let h=ROUTES.includes(view)?'#/'+view:(view==='release'&&selected?'#/release/'+selected.id:''); if(h&&location.hash!==h) history.replaceState(null,'',location.pathname+location.search+h); }
  function restoreRoute(){ const m=location.hash.match(/^#\/([a-z]+)(?:\/([\w-]+))?/); if(!m) return false; if(m[1]==='release'&&m[2]){ const r=releases.find(x=>x.id===m[2]); if(r){ selected=r; view='release'; return true; } return false; } if(ROUTES.includes(m[1])&&!(m[1]==='roster'&&!isAdmin())){ view=m[1]; return true; } return false; }
  const QUOTA=()=>((window.IMPOSED_CONFIG&&window.IMPOSED_CONFIG.ARTIST_QUOTA_MB)||150)*1048576;
  const MAX_FILE=50*1048576, fmtMB=b=>(b/1048576).toFixed(1)+' MB';
