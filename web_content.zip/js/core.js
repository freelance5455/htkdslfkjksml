// ===== core: utils, renderer, scene, sky, textures, batching, collision =====
const $ = id => document.getElementById(id);
const rand = (a, b) => a + Math.random() * (b - a);
const randi = (a, b) => Math.floor(rand(a, b + 1));
const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
const lerp = (a, b, t) => a + (b - a) * t;
const sstep = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
function angDiff(a, b) { let d = b - a; while (d > Math.PI) d -= Math.PI * 2; while (d < -Math.PI) d += Math.PI * 2; return d; }
function mulberry(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
let SR = mulberry(1337);
const rr = (a, b) => a + SR() * (b - a);
function h2(x, y) { const s = Math.sin(x * 127.1 + y * 311.7) * 43758.5453; return s - Math.floor(s); }
function vn(x, y) { const ix = Math.floor(x), iy = Math.floor(y), fx = x - ix, fy = y - iy, u = fx * fx * (3 - 2 * fx), v = fy * fy * (3 - 2 * fy); return lerp(lerp(h2(ix, iy), h2(ix + 1, iy), u), lerp(h2(ix, iy + 1), h2(ix + 1, iy + 1), u), v); }

let isTouch = matchMedia('(pointer:coarse)').matches;
if (isTouch) document.body.classList.add('touch');
let ARENA = 97;
const FOG = 0xb57c52, FOG_D = 0.0085;
const SUN_DIR = new THREE.Vector3(-0.55, 0.30, -0.78).normalize();

const appEl = $('app'), canvas = $('c');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: !isTouch, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, isTouch ? 1.5 : 1.75));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.autoClear = false;

const scene = new THREE.Scene();
scene.fog = new THREE.FogExp2(FOG, FOG_D);
const camera = new THREE.PerspectiveCamera(75, 1, 0.1, 700);
camera.rotation.order = 'YXZ';
scene.add(camera);

const vmScene = new THREE.Scene();
const vmCam = new THREE.PerspectiveCamera(58, 1, 0.01, 10);
const PSU = { uScale: { value: 1 } };
function resize() {
  const w = appEl.clientWidth || innerWidth, h = appEl.clientHeight || innerHeight;
  renderer.setSize(w, h, false);
  camera.aspect = vmCam.aspect = w / h;
  camera.updateProjectionMatrix(); vmCam.updateProjectionMatrix();
  PSU.uScale.value = renderer.domElement.height / (2 * Math.tan(THREE.MathUtils.degToRad(camera.fov) / 2));
}
addEventListener('resize', resize);

// lights
const hemi = new THREE.HemisphereLight(0xa59ab8, 0x3b2a1f, 0.95); scene.add(hemi);
const sun = new THREE.DirectionalLight(0xffb06a, 1.9);
sun.castShadow = true;
sun.shadow.mapSize.set(isTouch ? 1024 : 2048, isTouch ? 1024 : 2048);
{ const sc = sun.shadow.camera; sc.left = -60; sc.right = 60; sc.top = 60; sc.bottom = -60; sc.near = 1; sc.far = 320; }
sun.shadow.bias = -0.0006; sun.shadow.normalBias = 0.05;
scene.add(sun, sun.target);
const boomLight = new THREE.PointLight(0xff9a45, 0, 60, 2); scene.add(boomLight);
const flashLight = new THREE.PointLight(0xffb060, 0, 18, 2); scene.add(flashLight);

// canvas textures
function cvs(s) { const c = document.createElement('canvas'); c.width = c.height = s; return c; }
function mkTex(c, srgb) {
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());
  return t;
}
function wrapDraw(g, s, x, y, r, fn) {
  for (const ox of [-s, 0, s]) for (const oy of [-s, 0, s]) {
    if (x + ox + r < 0 || x + ox - r > s || y + oy + r < 0 || y + oy - r > s) continue;
    fn(x + ox, y + oy);
  }
}
function groundTex(T) {
  T = T || {}; const s = 512, c = cvs(s), g = c.getContext('2d');
  g.fillStyle = T.base || '#51482f'; g.fillRect(0, 0, s, s);
  const cols = T.cols || ['#5b5233', '#4a4129', '#665a38', '#3f4a2c', '#554a30', '#6a5a3e', '#3a3324', '#4c5530'];
  for (let i = 0; i < 2600; i++) {
    const x = Math.random() * s, y = Math.random() * s, r = 2 + Math.random() * 16;
    g.globalAlpha = 0.1 + Math.random() * 0.18; g.fillStyle = cols[i % cols.length];
    wrapDraw(g, s, x, y, r, (px, py) => { g.beginPath(); g.arc(px, py, r, 0, 6.283); g.fill(); });
  }
  for (let i = 0; i < 9000; i++) {
    g.globalAlpha = 0.25; g.fillStyle = Math.random() < 0.5 ? (T.sp1 || '#2c2618') : (T.sp2 || '#7a6a48');
    g.fillRect(Math.random() * s, Math.random() * s, 1 + Math.random() * 2, 1 + Math.random() * 2);
  }
  return mkTex(c);
}
function brickTex() {
  const s = 256, c = cvs(s), g = c.getContext('2d');
  g.fillStyle = '#8d8575'; g.fillRect(0, 0, s, s);
  const rowH = 16, bw = 32;
  for (let r = 0; r < s / rowH; r++) {
    const off = (r % 2) * bw / 2;
    for (let x = -bw; x < s + bw; x += bw) {
      const l = 26 + Math.random() * 14, hue = 8 + Math.random() * 12, sat = 35 + Math.random() * 15;
      g.fillStyle = `hsl(${hue},${sat}%,${l}%)`;
      g.fillRect(x + off + 1, r * rowH + 1, bw - 2, rowH - 2);
    }
  }
  for (let i = 0; i < 14; i++) { g.globalAlpha = 0.35; g.fillStyle = '#b9ad98'; g.fillRect(Math.random() * s, Math.random() * s, 20 + Math.random() * 50, 10 + Math.random() * 30); }
  for (let i = 0; i < 10; i++) { const x = Math.random() * s, y = Math.random() * s, gr = g.createRadialGradient(x, y, 2, x, y, 40); gr.addColorStop(0, 'rgba(10,8,6,.5)'); gr.addColorStop(1, 'rgba(10,8,6,0)'); g.globalAlpha = 1; g.fillStyle = gr; g.fillRect(x - 40, y - 40, 80, 80); }
  g.globalAlpha = 1;
  return mkTex(c);
}
function noiseTex(base, a, b, extra) {
  const s = 256, c = cvs(s), g = c.getContext('2d');
  g.fillStyle = base; g.fillRect(0, 0, s, s);
  for (let i = 0; i < 4000; i++) { g.globalAlpha = 0.18; g.fillStyle = Math.random() < 0.5 ? a : b; const r = 1 + Math.random() * 4; g.fillRect(Math.random() * s, Math.random() * s, r, r); }
  g.globalAlpha = 1;
  if (extra) extra(g, s);
  return mkTex(c);
}
function woodTex() {
  return noiseTex('#7a5a36', '#54391f', '#9a774a', (g, s) => {
    g.fillStyle = '#2a1c0e';
    for (let y = 0; y < s; y += 32) g.fillRect(0, y, s, 2);
    g.strokeStyle = 'rgba(30,18,6,.7)'; g.lineWidth = 6; g.strokeRect(0, 0, s, s);
  });
}
function sandTex() {
  return noiseTex('#a39166', '#7d6d49', '#c2b182', (g, s) => {
    g.strokeStyle = 'rgba(60,48,28,.7)'; g.lineWidth = 3;
    for (let y = 0; y < s; y += 64) for (let x = 0; x < s; x += 64) { const o = (y / 64 % 2) * 32; g.strokeRect(x + o + 2, y + 2, 60, 60); }
  });
}
function craterTex() {
  const c = cvs(128), g = c.getContext('2d');
  const gr = g.createRadialGradient(64, 64, 4, 64, 64, 62);
  gr.addColorStop(0, 'rgba(12,9,6,.95)'); gr.addColorStop(.55, 'rgba(22,16,10,.8)'); gr.addColorStop(.8, 'rgba(60,46,28,.5)'); gr.addColorStop(1, 'rgba(60,46,28,0)');
  g.fillStyle = gr; g.fillRect(0, 0, 128, 128);
  return new THREE.CanvasTexture(c);
}
function softTex() {
  const c = cvs(64), g = c.getContext('2d');
  const gr = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = gr; g.fillRect(0, 0, 64, 64);
  return new THREE.CanvasTexture(c);
}
function flashTex() {
  const c = cvs(128), g = c.getContext('2d');
  const gr = g.createRadialGradient(64, 64, 0, 64, 64, 64);
  gr.addColorStop(0, 'rgba(255,255,230,1)'); gr.addColorStop(.25, 'rgba(255,200,90,.8)'); gr.addColorStop(1, 'rgba(255,120,20,0)');
  g.fillStyle = gr; g.fillRect(0, 0, 128, 128);
  g.translate(64, 64); g.fillStyle = 'rgba(255,230,160,.85)';
  for (let i = 0; i < 6; i++) { g.rotate(Math.PI / 3 + 0.2); g.beginPath(); g.moveTo(0, -3); g.lineTo(62, 0); g.lineTo(0, 3); g.fill(); }
  return new THREE.CanvasTexture(c);
}
const TEX_SOFT = softTex(), TEX_FLASH = flashTex();

function stdMat(map, color) { return new THREE.MeshStandardMaterial({ map: map || null, color: color || 0xffffff, roughness: 0.95, metalness: 0.02, vertexColors: true }); }
const MATS = {
  brick: stdMat(brickTex()), concrete: stdMat(noiseTex('#8a877e', '#5f5d57', '#a9a69b')),
  wood: stdMat(woodTex()), sand: stdMat(sandTex()),
  metal: stdMat(noiseTex('#555a52', '#2c302b', '#6e7468')), rust: stdMat(noiseTex('#4a3a2e', '#2a1c14', '#6b4b34')),
  dark: stdMat(null, 0x2a2622),
  leaf: stdMat(noiseTex('#3f6a2c', '#2a4a1c', '#5a8a3a')), pine: stdMat(noiseTex('#24402e', '#162a1e', '#34583c')), snow: stdMat(noiseTex('#e8eef4', '#c4d0dc', '#ffffff')),
  cactus: stdMat(noiseTex('#4a7a3a', '#35602a', '#62923f')), rock: stdMat(noiseTex('#6e6a62', '#4a4640', '#8a857a')), lava: stdMat(noiseTex('#2a1e1a', '#14100e', '#4a2418')),
  sandst: stdMat(noiseTex('#c9a56e', '#a88450', '#e0c08a')), ice: stdMat(noiseTex('#9ec4dc', '#7ea8c4', '#c4e0f0')),
  neon: new THREE.MeshBasicMaterial({ vertexColors: true })
};

// batching of static geometry
const WORLD = []; // every mesh that belongs to the current map
class Batch {
  constructor(mat, shadows = true) { this.mat = mat; this.sh = shadows; this.p = []; this.n = []; this.u = []; this.c = []; this.i = []; this.v = 0; }
  add(geo, m, t) {
    geo = geo.clone(); geo.applyMatrix4(m);
    const p = geo.attributes.position.array, n = geo.attributes.normal.array, u = geo.attributes.uv.array;
    const col = Array.isArray(t) ? t : [t || 1, t || 1, t || 1];
    for (let k = 0; k < p.length; k++) { this.p.push(p[k]); this.n.push(n[k]); }
    for (let k = 0; k < u.length; k++) this.u.push(u[k]);
    for (let k = 0; k < p.length / 3; k++) this.c.push(col[0], col[1], col[2]);
    if (geo.index) { const ix = geo.index.array; for (let k = 0; k < ix.length; k++) this.i.push(ix[k] + this.v); }
    else for (let k = 0; k < p.length / 3; k++) this.i.push(k + this.v);
    this.v += p.length / 3; geo.dispose();
  }
  build() {
    if (!this.v) return;
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(this.p, 3));
    g.setAttribute('normal', new THREE.Float32BufferAttribute(this.n, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(this.u, 2));
    g.setAttribute('color', new THREE.Float32BufferAttribute(this.c, 3));
    g.setIndex(new THREE.BufferAttribute(new Uint32Array(this.i), 1));
    const m = new THREE.Mesh(g, this.mat); m.castShadow = this.sh; m.receiveShadow = this.sh;
    scene.add(m); WORLD.push(m);
    this.p = []; this.n = []; this.u = []; this.c = []; this.i = []; this.v = 0;
  }
}
const B = {}; for (const k in MATS) B[k] = new Batch(MATS[k]);

function scaleUV(g, w, h, d, s) {
  const uv = g.attributes.uv, dims = [[d, h], [d, h], [w, d], [w, d], [w, h], [w, h]];
  const ou = Math.random(), ov = Math.random();
  for (let f = 0; f < 6; f++) for (let k = 0; k < 4; k++) { const i = f * 4 + k; uv.setXY(i, uv.getX(i) * dims[f][0] * s + ou, uv.getY(i) * dims[f][1] * s + ov); }
}
const _m4 = new THREE.Matrix4(), _e = new THREE.Euler(), _q = new THREE.Quaternion(), _v = new THREE.Vector3(), _s1 = new THREE.Vector3(1, 1, 1);
function boxAt(b, x0, y0, z0, x1, y1, z1, uvs, tint) {
  const w = x1 - x0, h = y1 - y0, d = z1 - z0, g = new THREE.BoxGeometry(w, h, d);
  scaleUV(g, w, h, d, uvs || 0.5);
  b.add(g, _m4.makeTranslation((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2), tint === undefined ? rr(0.85, 1.1) : tint);
  g.dispose();
}
function boxRot(b, cx, cy, cz, w, h, d, ry, uvs, tint, rx = 0, rz = 0) {
  const g = new THREE.BoxGeometry(w, h, d); scaleUV(g, w, h, d, uvs || 0.5);
  _q.setFromEuler(_e.set(rx, ry, rz));
  b.add(g, _m4.compose(_v.set(cx, cy, cz), _q, _s1), tint === undefined ? rr(0.85, 1.1) : tint);
  g.dispose();
}
function cylAt(b, cx, cy, cz, rt, rb, h, seg, tint, rx = 0, rz = 0) {
  const g = new THREE.CylinderGeometry(rt, rb, h, seg);
  _q.setFromEuler(_e.set(rx, 0, rz));
  b.add(g, _m4.compose(_v.set(cx, cy, cz), _q, _s1), tint === undefined ? rr(0.85, 1.1) : tint);
  g.dispose();
}

// ===== collision =====
const colliders = [];
function col(x0, z0, x1, z1, h, soft) { colliders.push({ x0, x1, z0, z1, h, soft: !!soft }); }
function moveEntity(pos, dx, dz, r, feetY, isTank) {
  pos.x += dx; pos.z += dz;
  for (let i = 0; i < colliders.length; i++) {
    const c = colliders[i];
    if (c.h <= feetY + 0.45 || (isTank && c.soft)) continue;
    if (pos.x < c.x0 - r || pos.x > c.x1 + r || pos.z < c.z0 - r || pos.z > c.z1 + r) continue;
    const cx = clamp(pos.x, c.x0, c.x1), cz = clamp(pos.z, c.z0, c.z1);
    const ox = pos.x - cx, oz = pos.z - cz, d2 = ox * ox + oz * oz;
    if (d2 < r * r) {
      if (d2 > 1e-8) { const d = Math.sqrt(d2), k = (r - d) / d; pos.x += ox * k; pos.z += oz * k; }
      else {
        const l = pos.x - c.x0, rt = c.x1 - pos.x, t = pos.z - c.z0, bt = c.z1 - pos.z, m = Math.min(l, rt, t, bt);
        if (m === l) pos.x = c.x0 - r; else if (m === rt) pos.x = c.x1 + r; else if (m === t) pos.z = c.z0 - r; else pos.z = c.z1 + r;
      }
    }
  }
  const rad = Math.hypot(pos.x, pos.z), lim = ARENA - r;
  if (rad > lim) { pos.x *= lim / rad; pos.z *= lim / rad; }
}
function groundAt(x, z, feetY) {
  let g = 0;
  for (let i = 0; i < colliders.length; i++) {
    const c = colliders[i];
    if (x >= c.x0 && x <= c.x1 && z >= c.z0 && z <= c.z1 && c.h <= feetY + 0.5 && c.h > g) g = c.h;
  }
  return g;
}
function rayBox(o, d, x0, y0, z0, x1, y1, z1) {
  let tmin = 0, tmax = 1e9;
  const O = [o.x, o.y, o.z], D = [d.x, d.y, d.z], mn = [x0, y0, z0], mx = [x1, y1, z1];
  for (let a = 0; a < 3; a++) {
    if (Math.abs(D[a]) < 1e-9) { if (O[a] < mn[a] || O[a] > mx[a]) return null; }
    else {
      let t1 = (mn[a] - O[a]) / D[a], t2 = (mx[a] - O[a]) / D[a];
      if (t1 > t2) { const t = t1; t1 = t2; t2 = t; }
      if (t1 > tmin) tmin = t1; if (t2 < tmax) tmax = t2;
      if (tmin > tmax) return null;
    }
  }
  return tmin;
}
function raySphere(o, d, cx, cy, cz, r) {
  const ox = o.x - cx, oy = o.y - cy, oz = o.z - cz, b = ox * d.x + oy * d.y + oz * d.z, c = ox * ox + oy * oy + oz * oz - r * r, disc = b * b - c;
  if (disc < 0) return null; const t = -b - Math.sqrt(disc); return t >= 0 ? t : (c < 0 ? 0 : null);
}
function rayCyl(o, d, cx, cz, r, y0, y1) {
  const ox = o.x - cx, oz = o.z - cz, a = d.x * d.x + d.z * d.z;
  if (a < 1e-9) return null;
  const b = 2 * (ox * d.x + oz * d.z), c = ox * ox + oz * oz - r * r, disc = b * b - 4 * a * c;
  if (disc < 0) return null;
  const sq = Math.sqrt(disc);
  for (const t of [(-b - sq) / (2 * a), (-b + sq) / (2 * a)]) {
    if (t < 0) continue; const y = o.y + d.y * t; if (y >= y0 && y <= y1) return t;
  }
  return null;
}
function blocked(ax, ay, az, bx, by, bz) {
  const dx = bx - ax, dy = by - ay, dz = bz - az, len = Math.hypot(dx, dy, dz);
  if (len < 0.01) return false;
  const o = { x: ax, y: ay, z: az }, d = { x: dx / len, y: dy / len, z: dz / len };
  for (let i = 0; i < colliders.length; i++) {
    const c = colliders[i];
    const t = rayBox(o, d, c.x0, 0, c.z0, c.x1, c.h, c.z1);
    if (t !== null && t > 0.001 && t < len) return true;
  }
  return false;
}
