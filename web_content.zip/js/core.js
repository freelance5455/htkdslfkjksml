/* OPERATION: DISCIPLINE — fachada do núcleo (agrega os módulos). Carregar depois de util, gamification, rules, stats, schema, storage, backup. */
(function(){'use strict';
var OD=globalThis.OD,U=OD.U,G=OD.G,R=OD.Rules,St=OD.Store,B=OD.Backup,Sc=OD.Schema;
OD.Core={mk:R.mk,empty:R.empty,validate:Sc.validate,migrate:Sc.migrate,parse:B.parse,persist:St.persist,transact:St.transact,loadState:St.loadState,restore:St.restore,undo:St.undo,
 ACH:G.ACH,iso:U.iso,add:U.add,thr:G.thr,lvl:G.lvl,rank:G.rank,B:G.B,esc:U.esc,hash:U.hash,validDate:U.validDate,validTime:U.validTime,wkStart:U.wkStart,MAXB:U.MAXB};
if(typeof module!=='undefined')module.exports=OD.Core;
})();
