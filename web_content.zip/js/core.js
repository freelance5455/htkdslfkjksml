const $=s=>document.querySelector(s),LS='cvb3',fr=$('#fr');
const esc=s=>String(s??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
const LV={20:'Básico',40:'Elementar',60:'Intermédio',80:'Avançado',100:'Fluente / Nativo'},SL={20:'Iniciante',40:'Razoável',60:'Bom',80:'Muito bom',100:'Excelente'};
const DT={personal:'Dados pessoais',profile:'Perfil profissional',experience:'Experiência profissional',education:'Formação académica',extra:'Atividades extracurriculares',skills:'Habilidades e competências',languages:'Idiomas',projects:'Projectos',certificates:'Certificações e cursos',hobbies:'Interesses pessoais',references:'Referências profissionais',additional:'Informações adicionais',custom:'Secções personalizadas',signature:'Assinatura'};
const FM={Arial:"Arial,'CV Arial',Helvetica,sans-serif",Calibri:"Calibri,'CV Calibri',Carlito,sans-serif",'Courier New':"'Courier New','CV Courier',monospace",Garamond:"Garamond,'CV Garamond','EB Garamond',serif",Georgia:"Georgia,'CV Georgia',serif",'Times New Roman':"'Times New Roman','CV Times',Times,serif",'Trebuchet MS':"'Trebuchet MS','CV Trebuchet',sans-serif"};
const FCSS=[['Arial','arial'],['Calibri','calibri'],['Courier','cour'],['Garamond','gara'],['Georgia','georgia'],['Times','times'],['Trebuchet','trebuc']].map(([n,u])=>`@font-face{font-family:'CV ${n}';src:url(fonts/${u}.ttf)}`).join('');
const E=()=>({photo:'',photoOrig:'',photoT:null,titles:{},full_name:'',job_title:'',email:'',phone:'',location:'',district:'',website:'',address:'',linkedin:'',professional_summary:'',projects:'',additional_information:'',experience:[],education:[],languages:[],custom_sections:[],skills:[],certificates:[],hobbies:[],nationality:'',marital_status:'',birth_date:'',gender:'',order:null,extra:[],references:[],pshow:[],pfields:[],signature:{city:'',date:'',img:'',mode:'',text:''}});
/* níveis: 5 passos de 20 % (dados antigos de 4 passos são convertidos); estado civil acompanha o sexo */
const LM={25:'20',50:'60',75:'80',100:'100',20:'20',40:'40',60:'60',80:'80'};
const MSL={M:['Solteiro','Casado','Divorciado','Viúvo'],F:['Solteira','Casada','Divorciada','Viúva'],N:['Solteiro(a)','Casado(a)','Divorciado(a)','Viúvo(a)']};
const gk=g=>g=='Masculino'?'M':g=='Feminino'?'F':'N';
const msFix=(m,g)=>{for(const l of Object.values(MSL)){const i=l.indexOf(m);if(i>=0)return MSL[gk(g)][i]}return''};
/* LinkedIn: guarda só o nome de utilizador; aceita o link completo (https://www.linkedin.com/in/nome/?x=1, pt.linkedin.com/in/nome, in/nome, @nome) */
const liUser=v=>{v=String(v||'').trim();if(!v)return'';const m=/linkedin\.com\/(?:in|pub)\/([^\/?#\s]+)/i.exec(v);
if(m)v=m[1];else v=v.replace(/^(?:https?:\/\/)?(?:[\w-]+\.)?linkedin\.com\/?/i,'').replace(/^(?:in|pub)\//i,'').replace(/\s+/g,'');
v=v.split(/[\/?#]/)[0].replace(/^@/,'');try{v=decodeURIComponent(v)}catch{}return v};
/* datas: mês e ano escolhidos em listas (sm/sy = início, em/ey = fim, cur = Presente); o texto mostrado no CV é composto aqui */
const MN=['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'],MFULL=['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
const MP={jan:1,janeiro:1,fev:2,fevereiro:2,feb:2,february:2,mar:3,marco:3,march:3,abr:4,abril:4,apr:4,april:4,mai:5,maio:5,may:5,jun:6,junho:6,june:6,jul:7,julho:7,july:7,ago:8,agosto:8,aug:8,august:8,set:9,setembro:9,sep:9,sept:9,september:9,out:10,outubro:10,oct:10,october:10,nov:11,novembro:11,november:11,dez:12,dezembro:12,dec:12,december:12};
/* lê texto antigo ("Jan 2022", "2019", "03/2018"); devolve null se não o entender (nesse caso o texto é mantido como está) */
function pdate(t){t=String(t||'').trim();if(!t)return{m:'',y:''};let y='',m=0,r=t.normalize('NFD').replace(/[\u0300-\u036f]/g,'');const ym=/(?:19|20)\d{2}/.exec(r);if(ym){y=ym[0];r=r.replace(ym[0],' ')}
const nm=/^\s*(\d{1,2})\s*[\/.\-]\s*$/.exec(r);if(nm&&y){m=+nm[1];r=' '}
else{const w=r.toLowerCase().match(/[a-z]+/);if(w&&MP[w[0]]){m=MP[w[0]];r=r.replace(new RegExp(w[0],'i'),' ')}}
r=r.replace(/\bde\b/gi,' ');if(r.replace(/[\s\/.,\-–—]/g,'')||(!y&&!m)||m>12)return null;return{m:m?String(m):'',y}}
const PRES=/^(presente|atual|actual|atualidade|actualidade|em curso|hoje|agora|present|current|now)\.?$/i;
function fixDates(x){if('sm' in x)return;const s=pdate(x.start_date);x.sm=s?s.m:'';x.sy=s?s.y:'';if(s)x.start_date='';
const e=String(x.end_date||'').trim();x.em='';x.ey='';x.cur=false;if(PRES.test(e)){x.cur=true;x.end_date=''}else{const q=pdate(e);if(q){x.em=q.m;x.ey=q.y;x.end_date=''}}}
const dpart=(m,y)=>[+m?MN[+m-1]:'',y||''].filter(Boolean).join(' ');
const fix=d=>{d.district=d.district||'';d.signature={city:'',date:'',img:'',mode:'',text:'',...(d.signature||{})};d.custom_sections=(d.custom_sections||[]).map(x=>({kind:'text',...x}));d.pshow=d.pshow||[];d.pfields=d.pfields||[];d.skills=(d.skills||[]).map(s=>typeof s=='string'?{name:s,level:'60'}:s);for(const n of['skills','languages'])(d[n]||[]).forEach(x=>{x.level=LM[x.level]||'60'});d.extra=d.extra||[];d.references=d.references||[];d.titles=d.titles||{};d.marital_status=msFix(d.marital_status,d.gender);
if(typeof d.linkedin!='string')d.linkedin='';d.linkedin=liUser(d.linkedin);if(!d.linkedin&&/linkedin\.com\/(?:in|pub)\//i.test(d.website||'')){d.linkedin=liUser(d.website);d.website=''}
for(const n of['experience','education','extra'])d[n]=(d[n]||[]).map(x=>{fixDates(x);return x});return d};
/* ordem das secções (definida ao arrastar no editor); só reordena secções que partilham o mesmo contentor no modelo */
const DEF=['profile','experience','education','extra','skills','languages','projects','certificates','hobbies','references','additional','custom','signature'];
const ORD=()=>{const o=(D.order||[]).filter(k=>DEF.includes(k));DEF.forEach(k=>o.includes(k)||o.push(k));return o};
const SIDE=()=>(MAN.find(x=>x.id==T)||{}).side;
const PLC=k=>{const sd=SIDE(),v=((D.place||{})[T]||{})[k];return sd&&sd.can.includes(k)&&(v=='side'||v=='main')?v:''};
function reorder(html){const d=new DOMParser().parseFromString(html,'text/html'),o=ORD(),rk=k=>{const i=o.indexOf(k);return i<0?99:i},ps=new Set();
/* mover secções entre a coluna principal e a barra lateral (só nos modelos com "side" no manifest.json) */
const sd=SIDE();if(sd){const bx=d.querySelector(sd.box),mn=d.querySelector(sd.main);
if(bx&&mn)[...d.querySelectorAll('[data-sec]')].forEach(e=>{const w=PLC(e.dataset.sec);if(!w)return;const to=w=='side'?bx:mn;if(e.closest(sd.box)==bx&&w=='side'||e.closest(sd.main)==mn&&w=='main')return;
if(sd.scls){e.classList.remove(w=='side'?sd.mcls:sd.scls);e.classList.add(w=='side'?sd.scls:sd.mcls)}
const sib=[...to.children].filter(x=>x.dataset&&x.dataset.sec),nx=sib.find(x=>rk(x.dataset.sec)>rk(e.dataset.sec));
if(nx)nx.before(e);else if(sib.length)sib[sib.length-1].after(e);else to.append(e)})}
d.querySelectorAll('[data-sec]').forEach(e=>ps.add(e.parentElement));
ps.forEach(p=>{const ch=[...p.children].filter(e=>e.dataset.sec),s=[...ch].sort((a,b)=>rk(a.dataset.sec)-rk(b.dataset.sec));if(ch.length<2||s.every((e,i)=>e==ch[i]))return;
const m=ch.map(e=>{const c=d.createComment('');e.replaceWith(c);return c});m.forEach((c,i)=>c.replaceWith(s[i]))});
return'<!doctype html>'+d.documentElement.outerHTML}
let D=E(),T='',S={},TP={},MAN=[],LAST='',tm;
try{const s=JSON.parse(localStorage[LS]);D=fix({...E(),...s.D});T=s.T||'';S=s.S||{}}catch{}
/* motor de modelos (subconjunto de Handlebars): {{x}} {{{x}}} {{a.b}} {{#if}}..{{else}}..{{/if}} {{#each}}..{{/each}} */
const get=(c,p)=>p.split('.').reduce((a,k)=>a==null?a:a[k],c);
function parse(t){const k=t.split(/(\{\{\{[\s\S]*?\}\}\}|\{\{[\s\S]*?\}\})/);let i=0;function b(){const n=[];while(i<k.length){const s=k[i++];let m=/^\{\{\{\s*([\s\S]*?)\s*\}\}\}$/.exec(s);if(m){n.push(['r',m[1]]);continue}
m=/^\{\{\s*([\s\S]*?)\s*\}\}$/.exec(s);if(!m){if(s)n.push(['t',s]);continue}const x=m[1];
if(/^#(each|if) /.test(x)){const p=x.slice(1).split(' '),r=b();n.push([p[0],p.slice(1).join(' '),r[0],r[1]])}else if(x[0]=='/')return[n,null];else if(x=='else'){const r=b();return[n,r[0]]}else n.push(['v',x])}return[n,null]}return b()[0]}
function R(n,c){return n.map(x=>{if(x[0]=='t')return x[1];if(x[0]=='v')return esc(get(c,x[1]));if(x[0]=='r')return get(c,x[1])??'';const v=get(c,x[1]);
if(x[0]=='if')return(Array.isArray(v)?v.length:v)?R(x[2],c):R(x[3]||[],c);return(v||[]).map(it=>R(x[2],typeof it=='object'?it:{this:it})).join('')}).join('')}
function ctx(){const d=JSON.parse(JSON.stringify(D)),w=(d.full_name.match(/\p{L}+/gu)||[]).filter((_,i,a)=>i==0||i==a.length-1);delete d.photoOrig;
d.initials=w.map(x=>x[0].toUpperCase()).join('')||'CV';d.t={...DT,...d.titles};
d.languages=d.languages.filter(l=>l.name).map(l=>({...l,level_label:LV[l.level]}));d.skills=d.skills.filter(s=>s.name).map(s=>({...s,level_label:SL[s.level]}));d.skills_text=d.skills.map(s=>s.name).join(', ');
for(const k of['professional_summary','projects','additional_information'])d[k]=rich.toHtml(d[k]);
for(const n of['experience','education','extra']){d[n]=d[n].filter(x=>Object.values(x).some(Boolean));d[n].forEach(x=>{x.description=rich.toHtml(x.description);
const a=(x.sm||x.sy)?dpart(x.sm,x.sy):(x.start_date||''),b=x.cur?'Presente':((x.em||x.ey)?dpart(x.em,x.ey):(x.end_date||''));x.start_date=a;x.end_date=b;x.dates=[a,b].filter(Boolean).join(' — ');x.dates_h=[a,b].filter(Boolean).join(' - ')})}
d.linkedin_url=d.linkedin?'linkedin.com/in/'+d.linkedin:'';
d.custom_sections=d.custom_sections.map(x=>{const k=x.kind||'text',o={title:x.title||'',kind:k,k_text:k=='text',k_exp:k=='experience',k_skills:k=='skills',k_list:k=='list',text:'',items:[],skl:[],lst:[]};
if(k=='text')o.text=rich.toHtml(x.text);
if(k=='experience')o.items=(x.items||[]).filter(i=>Object.values(i).some(Boolean)).map(i=>{const a=(i.sm||i.sy)?dpart(i.sm,i.sy):(i.start_date||''),b=i.cur?'Presente':((i.em||i.ey)?dpart(i.em,i.ey):(i.end_date||''));return{job_title:i.job_title||'',company:i.company||'',location:i.location||'',description:rich.toHtml(i.description),dates:[a,b].filter(Boolean).join(' — '),dates_h:[a,b].filter(Boolean).join(' - ')}});
if(k=='skills')o.skl=(x.skills||[]).filter(s=>s.name).map(s=>({name:s.name,level:LM[s.level]||'60',level_label:SL[LM[s.level]||'60']}));
if(k=='list')o.lst=(x.list||[]).map(v=>String(v||'').trim()).filter(Boolean);
o.has=!!(o.title||o.text||o.items.length||o.skl.length||o.lst.length);return o}).filter(x=>x.has);
d.location=[D.location,D.district].map(v=>(v||'').trim()).filter(Boolean).join(' - ');delete d.district;const sg=D.signature||{},sd0=/^(\d{4})-(\d{2})-(\d{2})$/.exec(sg.date||'');d.sig_line=[(sg.city||'').trim(),sd0?new Date(+sd0[1],+sd0[2]-1,+sd0[3]).toLocaleDateString('pt-PT',{day:'numeric',month:'long',year:'numeric'}):''].filter(Boolean).join(', ');d.sig_img=sg.img||'';d.sig=!!(d.sig_line||d.sig_img);delete d.signature;
d.references=d.references.filter(x=>Object.values(x).some(Boolean));
const bm=/^(\d{4})-(\d{2})-(\d{2})$/.exec(d.birth_date),bd=bm?new Date(+bm[1],+bm[2]-1,+bm[3]).toLocaleDateString('pt-PT',{day:'numeric',month:'long',year:'numeric'}):'';
d.pinfo_list=[['birth','Data de nascimento',bd],['nationality','Nacionalidade',d.nationality],['marital','Estado civil',d.marital_status],['gender','Sexo',d.gender]].filter(x=>x[2]).map(([kind,label,value])=>({kind,label,value}));
(d.pfields||[]).filter(x=>x.l||x.v).forEach(x=>d.pinfo_list.push({kind:'custom',label:x.l||'',value:x.l&&x.v?x.l+': '+x.v:(x.v||x.l),plain:x.v||x.l}));return d}
/* tema (variáveis CSS aplicadas ao <html> da pré-visualização) */
const def=k=>((TP[T].css.match(new RegExp('--'+k+':\\s*([^;]+);'))||[])[1]||'').trim();
const hex6=c=>/^#[0-9a-f]{3}$/i.test(c)?'#'+[...c.slice(1)].map(x=>x+x).join(''):/^#[0-9a-f]{6}$/i.test(c)?c:'#000000';
/* cor: hex <-> HSV (usado pelo seletor de cores e pelo gradiente) */
const h2v=c=>{c=hex6(c);const r=parseInt(c.slice(1,3),16)/255,g=parseInt(c.slice(3,5),16)/255,b=parseInt(c.slice(5,7),16)/255,M=Math.max(r,g,b),m=Math.min(r,g,b),d=M-m;let H=0;if(d){H=M==r?((g-b)/d)%6:M==g?(b-r)/d+2:(r-g)/d+4;H=(H*60+360)%360}return{h:H,s:M?d/M:0,v:M}};
const v2h=({h,s,v})=>{const f=n=>{const k=(n+h/60)%6;return v-v*s*Math.max(0,Math.min(k,4-k,1))};return'#'+[f(5),f(3),f(1)].map(x=>Math.round(x*255).toString(16).padStart(2,'0')).join('')};
const g2=p=>{const c=h2v(p);return v2h(c.s<.15?{...c,v:c.v>.5?c.v-.3:c.v+.3}:{h:(c.h+35)%360,s:c.s,v:c.v})};
const GC=()=>{const m=MAN.find(x=>x.id==T);return!!(S.grad&&m&&m.gradient)};
const grad=()=>{const p=hex6(S.primary||def('primary')),q=hex6(S.primary2||g2(p));return`linear-gradient(${S.ga??135}deg,${p},${q})`};
function vars(){const ff=S.font&&FM[S.font],m={primary:S.primary,text:S.text,paper:S.paper,font:ff,serif:ff,fs:S.fs&&S.fs+'pt',lh:S.lh,gap:S.gap&&S.gap+'px','photo-r':S.shape,grad:GC()&&grad(),mx:S.mx&&S.mx+'mm'};return Object.entries(m).filter(([,v])=>v).map(([k,v])=>`--${k}:${v}`)}
const attrs=()=>`class="${[S.flip&&'flip',GC()&&'grad'].filter(Boolean).join(' ')}" style="${esc(vars().join(';'))}"`;
function theme(){try{const el=fr.contentDocument.documentElement;el.setAttribute('style',vars().join(';'));el.classList.toggle('flip',!!S.flip);el.classList.toggle('grad',GC());typeof guides=='function'?guides():(measure(),fit())}catch{}}
function draw(){if(!TP[T])return;const t=TP[T];LAST=R(parse(t.html),ctx()).replace('<html lang="pt">','<html lang="pt" '+attrs()+'>').replace(/<link[^>]*>/,()=>'<style>'+FCSS+t.css+'</style>');LAST=reorder(LAST);fr.srcdoc=LAST}
function measure(){try{const d=fr.contentDocument,r=d.getElementById('pgs')||d.querySelector('.resume');fr.style.height=Math.ceil(r?r.getBoundingClientRect().bottom+d.defaultView.scrollY+24:d.documentElement.scrollHeight)+'px'}catch{}}
function fit(){const w=$('#vp').clientWidth;if(!w)return;const k=Math.min(1,w/794);fr.style.transform='scale('+k+')';$('#stage').style.width=794*k+'px';$('#stage').style.height=fr.offsetHeight*k+'px'}
let RT=0;
fr.onload=()=>{try{const mt=fr.contentDocument.querySelector('meta[name=tpl]');if(mt&&TP[T]&&mt.content!==T&&RT++<2){draw();return}RT=0}catch{}typeof guides=='function'?guides():(measure(),fit());try{fr.contentDocument.fonts.ready.then(()=>{typeof guides=='function'?guides():(measure(),fit())})}catch{}};
const save=()=>{try{localStorage[LS]=JSON.stringify({D,T,S})}catch{}};
function up(){save();clearTimeout(tm);tm=setTimeout(draw,120)}
/* carregar modelos (templates/manifest.json + pasta de cada modelo) */
async function loadT(){try{MAN=await(await fetch('templates/manifest.json',{cache:'no-store'})).json();
/* um ficheiro de cada vez, sem cache, e confirmando que o HTML/CSS pertence mesmo a este modelo (marcas tpl:<id>) */
const g=async(u,id)=>{for(let n=0;n<3;n++){const r=await fetch(n?u+'?v='+Date.now()+n:u,{cache:'no-store'});if(!r.ok)continue;const x=await r.text(),m=/name="tpl" content="([^"]+)"|tpl:([\w-]+)/.exec(x);if(!m||(m[1]||m[2])==id)return x}throw 0};
for(const m of MAN)TP[m.id]={html:await g(`templates/${m.id}/index.html`,m.id),css:await g(`templates/${m.id}/style.css`,m.id)};return true}catch{$('#msg').hidden=false;return false}}
function start(){if(!TP[T])T=MAN[0].id;$('#tpl').innerHTML=MAN.map(m=>`<option value="${m.id}">${esc(m.name)}</option>`).join('');$('#tpl').value=T;build();draw();panel()}
function init(){$('#tpl').onchange=e=>{T=e.target.value;save();draw();panel()};
document.querySelectorAll('.tabs button').forEach(b=>b.onclick=()=>{document.body.dataset.v=b.dataset.v;if(b.dataset.v=='prev')draw();fit()});
$('#dirp').onchange=async e=>{const t={};MAN=[];for(const x of e.target.files){const p=x.webkitRelativePath.split('/'),n=p.at(-2),b=p.at(-1);
if(b=='index.html'||b=='style.css')(t[n]??={})[b=='index.html'?'html':'css']=await x.text();if(b=='manifest.json')MAN=JSON.parse(await x.text())}
TP=Object.fromEntries(Object.entries(t).filter(([,v])=>v.html&&v.css));if(!MAN.length)MAN=Object.keys(TP).map(id=>({id,name:id}));MAN=MAN.filter(m=>TP[m.id]);if(MAN.length){$('#msg').hidden=true;start()}};
addEventListener('resize',()=>{fit();typeof prevMark=='function'&&prevMark()});loadT().then(ok=>ok&&start())}
