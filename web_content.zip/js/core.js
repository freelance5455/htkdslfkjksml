'use strict';
/* ============ مجمع التسنيم الطبي — النواة ============ */
const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const pad = n => String(n).padStart(2, '0');
function nowTs() { return Date.now() + (S.clockOff || 0); }
function ymd(d) { d = d || new Date(nowTs()); return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
const today = () => ymd();
const yesterday = () => { const d = new Date(nowTs()); d.setDate(d.getDate() - 1); return ymd(d); };
const hm = ts => { const d = new Date(ts); return pad(d.getHours()) + ':' + pad(d.getMinutes()); };
const stamp = () => ({ ts: nowTs(), date: ymd() });
const num = n => (Math.round((+n || 0) * 100) / 100).toLocaleString('en-US');
const money = n => num(n) + ' ' + ((S.settings && S.settings.currency) || 'ج.س');
const GEN = { male: 'ذكر', female: 'أنثى', '': '—' };
const ROLE_AR = { admin: 'الإدارة', reception: 'الاستقبال', doctor: 'الطبيب', lab: 'المعمل', pharmacy: 'الصيدلية' };
const STORES = ['patients', 'queue', 'visits', 'labRequests', 'labTests', 'medicines', 'prescriptions', 'dispenses', 'activities'];
const KEYF = s => (s === 'patients' ? 'no' : 'id');
const initial = n => (String(n || '?').trim()[0] || '?');
const LS = {
  get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch (e) { } },
  del(k) { try { localStorage.removeItem(k); } catch (e) { } }
};

/* ============ الأيقونات (متجهية بنمط خطي موحّد) ============ */
const IC = {
  layout: '<rect x="3.5" y="3.5" width="7" height="8" rx="1.6"/><rect x="13.5" y="3.5" width="7" height="5" rx="1.6"/><rect x="13.5" y="11.5" width="7" height="9" rx="1.6"/><rect x="3.5" y="14.5" width="7" height="6" rx="1.6"/>',
  users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6"/><circle cx="17.5" cy="9" r="2.6"/><path d="M17 14.2c2.7.3 4.5 2.3 4.5 5.3"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-7 8-7s8 3 8 7"/>',
  userplus: '<circle cx="10" cy="8" r="3.8"/><path d="M3 20c0-3.7 3-6 7-6s7 2.3 7 6"/><path d="M19 8v6M16 11h6"/>',
  stetho: '<path d="M11 2v2M5 2v2"/><path d="M5 3H4a2 2 0 0 0-2 2v4a6 6 0 0 0 12 0V5a2 2 0 0 0-2-2h-1"/><path d="M8 15a6 6 0 0 0 12 0v-3"/><circle cx="20" cy="10" r="2"/>',
  flask: '<path d="M10 2v7.5a2 2 0 0 1-.2.9L4.7 20.5a1 1 0 0 0 .9 1.5h12.8a1 1 0 0 0 .9-1.5l-5.1-10.1a2 2 0 0 1-.2-.9V2"/><path d="M8.5 2h7M7 16h10"/>',
  pill: '<path d="m10.5 20.5 10-10a4.95 4.95 0 1 0-7-7l-10 10a4.95 4.95 0 1 0 7 7Z"/><path d="m8.5 8.5 7 7"/>',
  sliders: '<path d="M4 6h9M17 6h3M4 12h3M11 12h9M4 18h11M19 18h1"/><circle cx="15" cy="6" r="2"/><circle cx="9" cy="12" r="2"/><circle cx="17" cy="18" r="2"/>',
  shield: '<path d="M12 3 4.5 6v5.5c0 4.6 3.1 8 7.5 9.5 4.4-1.5 7.5-4.9 7.5-9.5V6L12 3Z"/><path d="m9 12 2.2 2.2L15 10"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  search: '<circle cx="11" cy="11" r="6.5"/><path d="m20 20-3.8-3.8"/>',
  printer: '<path d="M7 9V3.5h10V9"/><rect x="3.5" y="9" width="17" height="8" rx="2"/><path d="M7 14h10v6.5H7z"/>',
  trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 11v5M14 11v5"/>',
  edit: '<path d="M4 20h4L19.5 8.5a2.8 2.8 0 0 0-4-4L4 16v4Z"/><path d="m13.5 6.5 4 4"/>',
  check: '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
  x: '<path d="M6 6l12 12M18 6 6 18"/>',
  bell: '<path d="M6 16v-5a6 6 0 0 1 12 0v5l1.5 2h-15L6 16Z"/><path d="M10 21h4"/>',
  logout: '<path d="M9 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h3"/><path d="m16 8 4 4-4 4M20 12H9"/>',
  download: '<path d="M12 4v11M7.5 11 12 15.5 16.5 11M5 20h14"/>',
  upload: '<path d="M12 15V4M7.5 8 12 3.5 16.5 8M5 20h14"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  calendar: '<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M4 10h16M9 3v4M15 3v4"/>',
  wifi: '<path d="M2.5 9a14 14 0 0 1 19 0M5.5 12.5a9.5 9.5 0 0 1 13 0M8.8 16a5 5 0 0 1 6.4 0"/><circle cx="12" cy="19.4" r=".9" fill="currentColor"/>',
  key: '<circle cx="8" cy="15" r="4"/><path d="m11 12 9-9M16 7l3 3M14 9l2 2"/>',
  file: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8l-5-5Z"/><path d="M14 3v5h5M9 13h6M9 17h6"/>',
  pulse: '<path d="M3 12h4l2.5-6 4 12L16 12h5"/>',
  list: '<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 4V3h6v1M9 10h6M9 14h6M9 18h3"/>',
  menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
  chevl: '<path d="m15 5-7 7 7 7"/>', chevr: '<path d="m9 5 7 7-7 7"/>',
  db: '<ellipse cx="12" cy="6" rx="7.5" ry="3"/><path d="M4.5 6v6c0 1.7 3.4 3 7.5 3s7.5-1.3 7.5-3V6M4.5 12v6c0 1.7 3.4 3 7.5 3s7.5-1.3 7.5-3v-6"/>',
  plug: '<path d="M9 3v4M15 3v4M7 7h10v5a5 5 0 0 1-10 0V7ZM12 17v4"/>',
  box: '<path d="M12 3 4 7v10l8 4 8-4V7l-8-4Z"/><path d="m4 7 8 4 8-4M12 11v10"/>',
  bars: '<path d="M5 20V11M12 20V5M19 20v-6"/>',
  idcard: '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="11" r="2"/><path d="M6 16c.5-1.5 1.7-2.2 3-2.2s2.5.7 3 2.2M15 10h3M15 14h3"/>',
  alert: '<path d="M12 4 2.5 20h19L12 4Z"/><path d="M12 10v4M12 17.2v.1"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 7.8v.1"/>',
  refresh: '<path d="M20 11a8 8 0 0 0-14-4L4 9M4 5v4h4M4 13a8 8 0 0 0 14 4l2-2M20 19v-4h-4"/>',
  vol: '<path d="M4 9v6h4l5 4V5L8 9H4Z"/><path d="M16.5 8.5a5 5 0 0 1 0 7M19 6a8.5 8.5 0 0 1 0 12"/>',
  mute: '<path d="M4 9v6h4l5 4V5L8 9H4Z"/><path d="m16.5 9.5 5 5M21.5 9.5l-5 5"/>',
  link: '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
  lock: '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
  eye: '<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
  eyeoff: '<path d="M3 3l18 18M10.6 6.2A10 10 0 0 1 12 6c6.4 0 10 6 10 6a17 17 0 0 1-3.2 3.8M6.5 7.6A16.6 16.6 0 0 0 2 12s3.6 6 10 6c1.5 0 2.9-.3 4.1-.8M9.9 9.9a3 3 0 0 0 4.2 4.2"/>',
  copy: '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 0 1 2-2h8"/>',
  send: '<path d="M21 3 10 14M21 3l-7 18-4-7-7-4 18-7Z"/>',
  building: '<path d="M4 21V5a1 1 0 0 1 1-1h8a1 1 0 0 1 1 1v16M14 9h5a1 1 0 0 1 1 1v11M3 21h18M8 8h2M8 12h2M8 16h2"/>',
  history: '<path d="M3 12a9 9 0 1 0 3-6.7L3 8M3 3v5h5M12 8v4l3 2"/>',
  drop: '<path d="M12 3s6 6.2 6 10.5a6 6 0 0 1-12 0C6 9.2 12 3 12 3Z"/>'
};
function ic(n, cls) {
  return '<svg class="ic ' + (cls || '') + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (IC[n] || '') + '</svg>';
}

/* ============ الحالة العامة ============ */
const S = { me: null, token: null, settings: null, users: [], page: null, pno: null, online: false, devices: [], clockOff: 0, ptab: 'exam' };
let BASE = '';
const D = {}; STORES.forEach(s => D[s] = []);
const all = s => D[s];
const get = (s, k) => { const f = KEYF(s); return D[s].find(r => r[f] === k); };
function upsert(s, rec) { const f = KEYF(s), i = D[s].findIndex(r => r[f] === rec[f]); if (i >= 0) D[s][i] = rec; else D[s].push(rec); }
function removeRec(s, key) { const f = KEYF(s); D[s] = D[s].filter(r => r[f] !== key); }

/* ============ الاتصال بالخادم ============ */
async function api(path, body) {
  let r;
  try {
    r = await fetch(BASE + path, {
      method: body === undefined ? 'GET' : 'POST',
      headers: Object.assign({ 'Content-Type': 'application/json' }, S.token ? { Authorization: 'Bearer ' + S.token } : {}),
      body: body === undefined ? undefined : JSON.stringify(body)
    });
  } catch (e) { throw Object.assign(new Error('تعذر الاتصال بالخادم — تحقق من الواي فاي'), { net: true }); }
  let j = {}; try { j = await r.json(); } catch (e) { }
  if (r.status === 401 && S.token && path !== '/api/login') { sessionExpired(); throw new Error(j.error || 'انتهت الجلسة'); }
  if (!r.ok) throw Object.assign(new Error(j.error || 'حدث خطأ'), { status: r.status, data: j });
  return j;
}
async function safe(fn) { try { return await fn(); } catch (e) { toast(e.message, 'err'); return null; } }
async function put(s, rec) { const j = await api('/api/put', { store: s, rec }); upsert(s, j.rec); return j.rec; }
async function del(s, key) { await api('/api/del', { store: s, key }); removeRec(s, key); }
async function log(type, text, patientNo) { try { await put('activities', Object.assign({ type, text, patientNo: patientNo || null }, stamp())); } catch (e) { } }
async function ping() {
  try {
    const c = new AbortController(), t = setTimeout(() => c.abort(), 4000);
    const r = await fetch(BASE + '/api/ping', { signal: c.signal }); clearTimeout(t);
    const j = await r.json(); return !!(j && j.app === 'tasneem-clinic');
  } catch (e) { return false; }
}
async function loadSnapshot() {
  const j = await api('/api/snapshot');
  S.me = j.me; S.settings = j.settings; S.clockOff = j.serverTime - Date.now(); S.users = j.users || [];
  STORES.forEach(s => D[s] = j.stores[s] || []);
}

/* ============ المزامنة اللحظية ============ */
let es = null, wasOff = false, refTimer = null;
function connectEvents() {
  closeEvents();
  es = new EventSource(BASE + '/api/events?token=' + encodeURIComponent(S.token));
  es.onopen = () => setOnline(true);
  es.onmessage = e => { try { onEvent(JSON.parse(e.data)); } catch (x) { console.error(x); } };
  es.onerror = () => { wasOff = true; setOnline(false); if (es && es.readyState === 2) { closeEvents(); setTimeout(() => S.token && connectEvents(), 3000); } };
}
function closeEvents() { if (es) { es.onerror = null; es.close(); es = null; } }
function setOnline(v) { S.online = v; updateStatus(); const b = $('offb'); if (b) b.classList.toggle('hide', v); }
function updateStatus() {
  const el = $('status'); if (!el) return;
  el.className = 'status' + (S.online ? '' : ' off');
  el.innerHTML = '<i></i>' + (S.online ? 'متصل' + (S.devices.length > 1 ? ' · ' + S.devices.length + ' أجهزة' : '') : 'غير متصل');
}
async function onEvent(ev) {
  switch (ev.t) {
    case 'hello':
      if (wasOff) { wasOff = false; try { await loadSnapshot(); } catch (e) { return; } updateBadges(); refreshPage(true); }
      break;
    case 'put': { const prev = get(ev.s, ev.r[KEYF(ev.s)]); upsert(ev.s, ev.r); notifyEvent(ev, prev); scheduleRefresh(ev.s); break; }
    case 'del': removeRec(ev.s, ev.key); scheduleRefresh(ev.s); break;
    case 'reload': try { await loadSnapshot(); } catch (e) { return; } updateBadges(); applyBrand(); refreshPage(true); break;
    case 'presence': S.devices = ev.list || []; updateStatus(); scheduleRefresh('presence'); break;
    case 'settings': S.settings = ev.settings; applyBrand(); scheduleRefresh('settings'); break;
    case 'users': if (S.me && S.me.role === 'admin') { try { const j = await api('/api/snapshot'); S.users = j.users || []; } catch (e) { } scheduleRefresh('users'); } break;
  }
}
function scheduleRefresh(store) { clearTimeout(refTimer); refTimer = setTimeout(() => { updateBadges(); refreshPage(false, store); }, 140); }
function refreshPage(force, store) {
  const pg = PAGES[S.page]; if (!pg || !S.me) return;
  if (modalOpen() && !force) return;
  if (pg.live) { const y = window.scrollY; renderPage(true).then(() => window.scrollTo(0, y)); }
  else if (pg.onData) pg.onData(store);
}

/* ============ إشعارات الأقسام ============ */
function notifyEvent(ev, prev) {
  if (!S.me || ev.by === S.me.id) return;
  const r = ev.r, role = S.me.role, adm = role === 'admin';
  if (ev.s === 'queue' && !prev && (adm || role === 'doctor')) { toast('مريض جديد في الانتظار: ' + r.patientName + ' (دور ' + r.no + ')', 'info', 'bell'); beep(); }
  if (ev.s === 'labRequests') {
    if (!prev && (adm || role === 'lab')) { toast('طلب فحوصات جديد: ' + r.patientName, 'info', 'flask'); beep(); }
    if (prev && prev.status !== 'done' && r.status === 'done' && (adm || role === 'doctor')) { toast('نتيجة جاهزة: ' + r.patientName, 'ok', 'check'); beep(); }
  }
  if (ev.s === 'prescriptions' && !prev && r.status === 'pending' && (adm || role === 'pharmacy')) { toast('وصفة جديدة: ' + r.patientName, 'info', 'pill'); beep(); }
}
let AC = null;
function beep() {
  if (LS.get('tsn_mute') === '1') return;
  try {
    AC = AC || new (window.AudioContext || window.webkitAudioContext)(); const t = AC.currentTime;
    [[880, 0], [1175, .13]].forEach(([f, d]) => {
      const o = AC.createOscillator(), g = AC.createGain(); o.type = 'sine'; o.frequency.value = f;
      g.gain.setValueAtTime(.0001, t + d); g.gain.exponentialRampToValueAtTime(.14, t + d + .02); g.gain.exponentialRampToValueAtTime(.0001, t + d + .26);
      o.connect(g); g.connect(AC.destination); o.start(t + d); o.stop(t + d + .3);
    });
  } catch (e) { }
}
function toggleSound() { LS.set('tsn_mute', LS.get('tsn_mute') === '1' ? '0' : '1'); soundIcon(); if (LS.get('tsn_mute') !== '1') beep(); }
function soundIcon() { const b = $('sndbtn'); if (b) b.innerHTML = ic(LS.get('tsn_mute') === '1' ? 'mute' : 'vol', 'sm'); }

/* ============ عناصر الواجهة العامة ============ */
function toast(msg, type, icon) {
  const t = document.createElement('div'); t.className = 'toast ' + (type || '');
  t.innerHTML = ic(icon || (type === 'err' ? 'alert' : 'check')) + '<span>' + esc(msg) + '</span>';
  $('toasts').appendChild(t); setTimeout(() => t.remove(), type === 'err' ? 5200 : 3400);
}
const modalOpen = () => $('modal').style.display === 'block';
function openModal(h, wide) { $('mbox').className = wide ? 'wide' : ''; $('mbox').innerHTML = h; $('modal').style.display = 'block'; }
function closeModal() {
  $('modal').style.display = 'none'; $('mbox').innerHTML = '';
  if (window._askRes) { const r = window._askRes; window._askRes = null; r(false); }
}
const mhead = t => '<div class="mh"><h3>' + t + '</h3><button class="btn ghost icon sm" onclick="closeModal()" aria-label="إغلاق">' + ic('x') + '</button></div>';
function ask(msg, o) {
  o = o || {};
  return new Promise(res => {
    window._askRes = res;
    openModal(mhead(esc(o.title || 'تأكيد الإجراء')) + '<p style="margin:.2rem 0 1.3rem">' + esc(msg).replace(/\n/g, '<br>') + '</p><div class="btns"><button class="btn ' + (o.danger ? 'danger' : '') + '" onclick="askDone(true)">' + esc(o.ok || 'تأكيد') + '</button><button class="btn ghost" onclick="askDone(false)">إلغاء</button></div>');
  });
}
function askDone(v) { const r = window._askRes; window._askRes = null; closeModal(); if (r) r(v); }
document.addEventListener('keydown', e => { if (e.key === 'Escape' && modalOpen()) closeModal(); });

const stat = (icon, label, val, tone) => '<div class="stat"><div class="si ' + (tone || '') + '">' + ic(icon, 'lg') + '</div><div><div class="sv num">' + val + '</div><div class="sl">' + label + '</div></div></div>';
const empty = (icon, txt) => '<div class="empty">' + ic(icon) + '<div>' + txt + '</div></div>';
const badge = (t, tone) => '<span class="badge ' + (tone || '') + '">' + t + '</span>';
const pagehead = (t, actions) => '<div class="pagehead"><h2>' + t + '</h2>' + (actions ? '<div class="btns">' + actions + '</div>' : '') + '</div>';
function seg(items, cur, fn) { return '<div class="seg">' + items.map(([id, l, c]) => '<button class="' + (cur === id ? 'on' : '') + '" onclick="' + fn + '(\'' + id + '\')">' + l + (c ? '<span class="cnt">' + c + '</span>' : '') + '</button>').join('') + '</div>'; }

/* فلتر التاريخ المشترك */
const FL = { dash: { mode: 'today', date: '' }, sales: { mode: 'today', date: '' }, rq: { mode: 'today', date: '' } };
function filt(F) {
  if (F.mode === 'all') return () => true;
  const t = F.mode === 'today' ? today() : F.mode === 'yesterday' ? yesterday() : (F.date || today());
  return r => r.date === t;
}
function filterBar(k) {
  const F = FL[k], b = (m, l) => '<button class="' + (F.mode === m ? 'on' : '') + '" onclick="setF(\'' + k + '\',\'' + m + '\')">' + l + '</button>';
  return '<div class="btns" style="margin-bottom:1rem"><div class="seg">' + b('today', 'اليوم') + b('yesterday', 'أمس') + b('all', 'كل الأوقات') + '</div><input type="date" class="input" style="width:auto;height:44px" value="' + (F.mode === 'date' ? F.date : '') + '" onchange="setFD(\'' + k + '\',this.value)" aria-label="اختيار تاريخ"></div>';
}
function setF(k, m) { FL[k].mode = m; renderPage(true); }
function setFD(k, v) { if (v) { FL[k].mode = 'date'; FL[k].date = v; renderPage(true); } }
function periodLabel(F) { return F.mode === 'today' ? 'اليوم' : F.mode === 'yesterday' ? 'أمس' : F.mode === 'all' ? 'كل الأوقات' : F.date; }

/* ============ التنقل والهيكل ============ */
const PAGES = {};
const NAV = {
  admin: [
    { g: 'الإدارة', items: [['dash', 'لوحة التحكم', 'layout'], ['users', 'المستخدمون', 'users'], ['print', 'الطباعة والترويسة', 'printer'], ['system', 'النظام والشبكة', 'wifi']] },
    { g: 'الاستقبال', items: [['rc_queue', 'طابور اليوم', 'list'], ['rc_patients', 'المرضى', 'userplus']] },
    { g: 'الطبيب', items: [['dr_queue', 'قائمة الانتظار', 'stetho'], ['dr_patients', 'سجلات المرضى', 'file']] },
    { g: 'المعمل', items: [['lb_wait', 'العينات الواردة', 'flask'], ['lb_done', 'النتائج المكتملة', 'check'], ['lb_cat', 'كتالوج الفحوصات', 'list'], ['lb_dev', 'ربط الجهاز', 'plug']] },
    { g: 'الصيدلية', items: [['ph_pend', 'الوصفات', 'file'], ['ph_inv', 'المخزون', 'box'], ['ph_sales', 'المبيعات', 'bars']] }
  ],
  reception: [{ items: [['rc_queue', 'طابور اليوم', 'list'], ['rc_patients', 'المرضى والتسجيل', 'userplus']] }],
  doctor: [{ items: [['dr_queue', 'قائمة الانتظار', 'stetho'], ['dr_patients', 'سجلات المرضى', 'file']] }],
  lab: [{ items: [['lb_wait', 'العينات الواردة', 'flask'], ['lb_done', 'النتائج المكتملة', 'check'], ['lb_cat', 'كتالوج الفحوصات', 'list'], ['lb_dev', 'ربط الجهاز', 'plug']] }],
  pharmacy: [{ items: [['ph_pend', 'الوصفات', 'file'], ['ph_inv', 'المخزون', 'box'], ['ph_sales', 'المبيعات', 'bars']] }]
};
const HOME = { admin: 'dash', reception: 'rc_queue', doctor: 'dr_queue', lab: 'lb_wait', pharmacy: 'ph_pend' };
const logoSrc = () => (S.settings && S.settings.print && S.settings.print.logo) || 'img/logo.png';
function pageIds() { return NAV[S.me.role].flatMap(g => g.items.map(i => i[0])); }

function renderShell() {
  const nav = NAV[S.me.role].map(g => (g.g ? '<div class="gt">' + g.g + '</div>' : '') + g.items.map(([id, l, i]) =>
    '<button data-id="' + id + '" onclick="go(\'' + id + '\')">' + ic(i) + '<span>' + l + '</span><span class="nb hide" id="nb_' + id + '"></span></button>').join('')).join('');
  $('root').innerHTML =
    '<div class="shell"><aside class="side" id="side"><div class="brand"><div class="lg"><img id="brandLogo" alt=""></div><div><div class="bn" id="brandAr"></div><div class="be" id="brandEn"></div></div></div>' +
    '<nav class="nav">' + nav + '</nav>' +
    '<div class="me"><div class="av">' + esc(initial(S.me.name)) + '</div><div class="grow"><div class="mn">' + esc(S.me.name) + '</div><div class="mr">' + ROLE_AR[S.me.role] + '</div></div><button class="btn ghost icon sm" onclick="logout()" title="تسجيل الخروج" aria-label="تسجيل الخروج">' + ic('logout') + '</button></div></aside>' +
    '<div class="scrim" id="scrim" onclick="toggleMenu(false)"></div>' +
    '<div class="main"><div class="offline-banner hide" id="offb">انقطع الاتصال بالخادم — جارٍ إعادة المحاولة…</div>' +
    '<header class="topbar"><button class="btn ghost icon menu-btn" onclick="toggleMenu(true)" aria-label="القائمة">' + ic('menu') + '</button><h1 id="ptitle"></h1><span class="status" id="status"></span><button class="btn ghost icon sm" id="sndbtn" onclick="toggleSound()" aria-label="الصوت"></button><span class="clock num" id="clock"></span></header>' +
    '<main id="page"></main></div></div>';
  applyBrand(); updateStatus(); soundIcon(); tickClock();
}
function applyBrand() {
  if (!S.settings) return; const p = S.settings.print;
  document.title = p.nameAr || 'مجمع التسنيم الطبي';
  const a = $('brandAr'), e = $('brandEn'), l = $('brandLogo');
  if (a) a.textContent = p.nameAr; if (e) e.textContent = p.nameEn; if (l) l.src = logoSrc();
}
function tickClock() { const c = $('clock'); if (c) { const d = new Date(nowTs()); c.textContent = ymd(d) + '  ·  ' + pad(d.getHours()) + ':' + pad(d.getMinutes()); } }
setInterval(tickClock, 20000);
function toggleMenu(v) { $('side').classList.toggle('open', v); $('scrim').classList.toggle('on', v); }

function go(id, opts) {
  if (!S.me || !pageIds().includes(id)) return;
  S.page = id; toggleMenu(false);
  if (!(opts && opts.keep)) { S.pno = null; S.labReq = null; }
  renderPage().then(() => window.scrollTo(0, 0));
}
async function renderPage() {
  const pg = PAGES[S.page]; if (!pg) return;
  document.querySelectorAll('.nav button').forEach(b => b.classList.toggle('on', b.dataset.id === S.page));
  const t = $('ptitle'); if (t) t.textContent = typeof pg.title === 'function' ? pg.title() : pg.title;
  try { await pg.render(); } catch (e) { console.error(e); toast('خطأ: ' + e.message, 'err'); }
}
function updateBadges() {
  if (!S.me) return; const t = today();
  const wq = D.queue.filter(q => q.date === t && q.status === 'waiting').length;
  const ready = D.labRequests.filter(r => r.status === 'done' && !r.seen).length;
  const lw = D.labRequests.filter(r => r.status === 'waiting').length;
  const rx = D.prescriptions.filter(r => r.status === 'pending').length;
  const set = (id, n, red) => { const e = $('nb_' + id); if (!e) return; e.textContent = n; e.classList.toggle('hide', !n); e.classList.toggle('red', !!red); };
  set('rc_queue', wq); set('dr_queue', wq + ready); set('lb_wait', lw); set('ph_pend', rx);
}

/* ============ تسجيل الدخول والاتصال ============ */
const ARCS = '<svg class="arcs" viewBox="0 0 600 800" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><g fill="none" stroke="#FCBD2A" stroke-linecap="round"><path d="M-60 300Q300 20 660 300" stroke-width="26" opacity=".95"/><path d="M-20 360Q300 120 620 360" stroke-width="20" opacity=".7"/><path d="M30 420Q300 220 570 420" stroke-width="14" opacity=".5"/><path d="M90 480Q300 330 510 480" stroke-width="9" opacity=".32"/></g><path d="M-60 740Q300 520 660 740V820H-60Z" fill="#18203F"/><path d="M-60 780Q300 600 660 780V820H-60Z" fill="#222B52"/></svg>';
function showLogin(msg) {
  closeEvents(); S.me = null;
  const nm = (S.settings && S.settings.print) || { nameAr: 'مجمع التسنيم الطبي', nameEn: 'Al Tasneem Medical Clinics' };
  $('root').innerHTML =
    '<div class="login"><div class="fm"><div style="max-width:380px;width:100%;margin:0 auto">' +
    '<img class="lg" src="' + esc(logoSrc()) + '" alt="شعار المجمع">' +
    '<h1>' + esc(nm.nameAr) + '</h1><div class="sub">' + esc(nm.nameEn) + '</div>' +
    '<form onsubmit="doLogin(event)" autocomplete="on">' +
    '<div class="field"><label for="lu">اسم المستخدم</label><input id="lu" class="input" autocomplete="username" autocapitalize="none" spellcheck="false" required></div>' +
    '<div class="field"><label for="lp">كلمة المرور</label><div class="pw"><input id="lp" class="input" type="password" autocomplete="current-password" required><button type="button" onclick="togglePw()" aria-label="إظهار كلمة المرور" id="pwb">' + ic('eye') + '</button></div></div>' +
    '<div class="err" id="lerr" role="alert">' + esc(msg || '') + '</div>' +
    '<button class="btn block" style="height:48px;font-size:1rem" id="lbtn">تسجيل الدخول</button></form>' +
    '<div class="srv">' + ic('wifi', 'sm') + ' متصل بالخادم' + (BASE ? ' <span class="ltr num">' + esc(BASE.replace(/^https?:\/\//, '')) + '</span> · <a onclick="showConnect()">تغيير</a>' : '') + '</div>' +
    '</div></div><div class="vis">' + ARCS + '<div class="cap"><h2>رعاية <b>متكاملة</b><br>بإدارة أبسط وأدق</h2><p>جميع أقسام المجمع على شبكة واحدة — من الاستقبال إلى الصيدلية، لحظة بلحظة وبدون إنترنت.</p></div></div></div>';
  setTimeout(() => { const u = $('lu'); if (u) u.focus(); }, 50);
}
function togglePw() { const p = $('lp'), s = p.type === 'password'; p.type = s ? 'text' : 'password'; $('pwb').innerHTML = ic(s ? 'eyeoff' : 'eye'); }
async function doLogin(e) {
  e.preventDefault(); const b = $('lbtn'); b.disabled = true; $('lerr').textContent = '';
  try {
    const j = await api('/api/login', { username: $('lu').value, password: $('lp').value });
    S.token = j.token; LS.set('tsn_token', j.token); await loadSnapshot(); startApp();
  } catch (x) { S.token = null; $('lerr').textContent = x.message; b.disabled = false; $('lp').select(); }
}
async function logout() {
  try { await api('/api/logout', {}); } catch (e) { }
  S.token = null; LS.del('tsn_token'); closeEvents(); S.page = null; S.pno = null; showLogin();
}
function sessionExpired() {
  if (!S.token) return; S.token = null; LS.del('tsn_token'); closeEvents(); closeModal(); S.page = null; showLogin('انتهت الجلسة، سجّل الدخول من جديد');
}
function showConnect(msg) {
  closeEvents();
  const served = location.protocol === 'http:' || location.protocol === 'https:';
  $('root').innerHTML =
    '<div class="login"><div class="fm"><div style="max-width:400px;width:100%;margin:0 auto">' +
    '<img class="lg" src="img/logo.png" alt="">' +
    '<h1>الاتصال بخادم المجمع</h1><div class="sub" style="direction:rtl;font-weight:400">أدخل عنوان الجهاز الرئيسي الذي يعمل عليه الخادم</div>' +
    (msg ? '<div class="alertbox err">' + ic('alert') + '<div>' + esc(msg) + '</div></div>' : '') +
    '<form onsubmit="doConnect(event)"><div class="field"><label for="sa">عنوان الخادم</label><input id="sa" class="input ltr" style="direction:ltr;text-align:left" placeholder="192.168.1.10:3000" value="' + esc((BASE || LS.get('tsn_base') || '').replace(/^https?:\/\//, '')) + '" inputmode="url" autocapitalize="none" spellcheck="false" required></div>' +
    '<button class="btn block" style="height:48px" id="cbtn">اتصال</button></form>' +
    '<div class="alertbox info" style="margin-top:1.2rem">' + ic('info') + '<div>تأكد أن الجهاز متصل بنفس شبكة الواي فاي. العنوان يظهر في نافذة تشغيل الخادم وفي صفحة «النظام والشبكة» للمدير.</div></div>' +
    (served ? '<div class="srv"><a onclick="boot()">إعادة المحاولة</a></div>' : '') +
    '</div></div><div class="vis">' + ARCS + '<div class="cap"><h2>اتصال <b>محلي</b> آمن</h2><p>البيانات تبقى داخل شبكة المجمع ولا تخرج إلى الإنترنت.</p></div></div></div>';
}
async function doConnect(e) {
  e.preventDefault(); const b = $('cbtn'); b.disabled = true; b.textContent = 'جارٍ الاتصال…';
  let a = $('sa').value.trim().replace(/\/+$/, '');
  if (!/^https?:\/\//i.test(a)) a = 'http://' + a;
  if (!/:\d+$/.test(a.replace(/^https?:\/\//, '')) && !/^https:/i.test(a)) a += ':3000';
  const old = BASE; BASE = a;
  if (await ping()) { LS.set('tsn_base', a); boot(); }
  else { BASE = old; showConnect('تعذر الوصول إلى الخادم على ' + a.replace(/^https?:\/\//, '')); }
}

/* ============ الإقلاع ============ */
function startApp() {
  renderShell(); connectEvents(); updateBadges();
  go(HOME[S.me.role]);
}
async function boot() {
  if ('serviceWorker' in navigator && window.isSecureContext && location.protocol.startsWith('http')) navigator.serviceWorker.register('sw.js').catch(() => { });
  const served = location.protocol === 'http:' || location.protocol === 'https:', saved = LS.get('tsn_base');
  let ok = false;
  if (served) { BASE = ''; ok = await ping(); }
  if (!ok && saved) { BASE = saved; ok = await ping(); }
  if (!ok) { BASE = saved || ''; return showConnect(served || saved ? 'تعذر الوصول إلى الخادم. تأكد أنه يعمل وأنك على نفس الشبكة.' : ''); }
  const tok = LS.get('tsn_token');
  if (tok) { S.token = tok; try { await loadSnapshot(); return startApp(); } catch (e) { S.token = null; LS.del('tsn_token'); if (e.net) return showConnect(e.message); } }
  showLogin();
}
