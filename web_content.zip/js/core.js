// ===== CORE: scene, camera, renderer, lighting, terrain, physics world =====

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x8fc7e8);
scene.fog = new THREE.Fog(0x8fc7e8, 40, 220);

const camera = new THREE.PerspectiveCamera(62, window.innerWidth / window.innerHeight, 0.1, 500);

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.setClearColor(0x8fc7e8, 1);
document.getElementById('gameRoot').appendChild(renderer.domElement);

window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});

const ambient = new THREE.AmbientLight(0xffffff, 0.6);
scene.add(ambient);

const sun = new THREE.DirectionalLight(0xfff2d6, 1.15);
sun.position.set(60, 90, 30);
sun.castShadow = true;
sun.shadow.mapSize.set(1536, 1536);
sun.shadow.camera.left = -100;
sun.shadow.camera.right = 100;
sun.shadow.camera.top = 100;
sun.shadow.camera.bottom = -100;
sun.shadow.camera.far = 250;
scene.add(sun);
scene.add(sun.target);

const hemi = new THREE.HemisphereLight(0xbfe0ff, 0x3a5a34, 0.45);
scene.add(hemi);

// ---- Terrain: a rolling low-poly ground plane ----
const WORLD_SIZE = 300;

function heightAt(x, z) {
  return Math.sin(x * 0.035) * 2.6 + Math.cos(z * 0.04) * 2.6 + Math.sin((x + z) * 0.018) * 1.6;
}

const groundGeo = new THREE.PlaneGeometry(WORLD_SIZE, WORLD_SIZE, 70, 70);
groundGeo.rotateX(-Math.PI / 2);
const gPos = groundGeo.attributes.position;
for (let i = 0; i < gPos.count; i++) {
  const x = gPos.getX(i), z = gPos.getZ(i);
  gPos.setY(i, heightAt(x, z));
}
groundGeo.computeVertexNormals();
const groundMat = new THREE.MeshStandardMaterial({ color: 0x4c8f4d, flatShading: true });
const ground = new THREE.Mesh(groundGeo, groundMat);
ground.receiveShadow = true;
scene.add(ground);

// A wide, flat-shaded low-poly water disc ringing the play area for atmosphere.
const waterGeo = new THREE.CircleGeometry(WORLD_SIZE * 0.9, 24);
const waterMat = new THREE.MeshStandardMaterial({ color: 0x2f6fa3, flatShading: true, transparent: true, opacity: 0.85 });
const water = new THREE.Mesh(waterGeo, waterMat);
water.rotation.x = -Math.PI / 2;
water.position.y = -1.6;
scene.add(water);

// ---- Physics world ----
// The physics body handles horizontal collisions (running into rocks/trees).
// Vertical position instead directly follows the visual terrain height each
// frame -- far more reliable across devices than simulating full heightfield
// physics, while still giving real collision response and a real jump arc.
const world = new CANNON.World();
world.gravity.set(0, -20, 0);
world.broadphase = new CANNON.SAPBroadphase(world);
world.solver.iterations = 8;

const physMaterial = new CANNON.Material('default');
world.defaultContactMaterial.friction = 0.05;
world.defaultContactMaterial.restitution = 0.1;
