/* هسته‌ی رابط: رندر، وضعیت فرم‌ها، رویدادها (تفویض‌شده)، کارت‌های بازشونده، پیام کوتاه، پنجره‌ی گفتگو. */
(function () {
  'use strict';
  var App = (window.App = window.App || {});
  var u = App.u;
  var ui = (App.ui = { tab: 'today', forms: {}, sheet: false, vp: [], focusAct: '', modal: null, pendingAct: null });
  App.views = {};
  App.act = {};
  var TABS = [['today', '🏠', 'امروز'], ['ai', '💬', 'مشاور'], ['plan', '📋', 'برنامه'], ['subj', '📖', 'دروس'], ['exam', '📝', 'آزمون'], ['stat', '📊', 'آمار']];
  App.TABS = TABS;

  // ---- ابزار HTML ----
  App.h = u.esc;
  App.opts = function (list, cur) {
    return list.map(function (x) {
      var v = Array.isArray(x) ? x[0] : x, l = Array.isArray(x) ? x[1] : x;
      return '<option value="' + u.esc(v) + '"' + (String(v) === String(cur) ? ' selected' : '') + '>' + u.esc(l) + '</option>';
    }).join('');
  };
  // فرم کنترل‌شده: مقدارها در App.ui.forms نگه داشته می‌شوند
  App.form = function (name, defaults) {
    var f = ui.forms[name];
    if (!f) { f = ui.forms[name] = {}; }
    Object.keys(defaults || {}).forEach(function (k) { if (f[k] === undefined) f[k] = defaults[k]; });
    return f;
  };
  App.resetForm = function (name, defaults) { ui.forms[name] = Object.assign({}, defaults || {}); return ui.forms[name]; };
  // ورودی متنی/عددی؛ data-f="form.key" ؛ نوع با data-t
  App.input = function (form, key, o) {
    o = o || {};
    var f = App.form(form, {});
    var v = f[key] == null ? '' : f[key];
    var id = o.id || ('f-' + form + '-' + key);
    return '<input id="' + id + '" type="' + (o.type || 'text') + '" data-f="' + form + '.' + key + '" data-t="' + (o.t || 'str') + '"' +
      (o.inputmode ? ' inputmode="' + o.inputmode + '"' : '') + (o.ph ? ' placeholder="' + u.esc(o.ph) + '"' : '') +
      (o.min != null ? ' min="' + o.min + '"' : '') + (o.max != null ? ' max="' + o.max + '"' : '') + (o.maxlength ? ' maxlength="' + o.maxlength + '"' : '') +
      ' value="' + u.esc(v) + '"' + (o.dis ? ' disabled' : '') + (o.cls ? ' class="' + o.cls + '"' : '') + ' autocomplete="off">';
  };
  // انتخاب؛ list: [[value,label]] یا رشته
  App.select = function (form, key, list, o) {
    o = o || {};
    var f = App.form(form, {});
    var cur = f[key] == null ? '' : f[key];
    var id = o.id || ('f-' + form + '-' + key);
    return '<select id="' + id + '" data-f="' + form + '.' + key + '" data-t="' + (o.t || 'str') + '"' + (o.rr ? ' data-rr="1"' : '') + (o.dis ? ' disabled' : '') + (o.cls ? ' class="' + o.cls + '"' : '') + '>' +
      (o.empty != null ? '<option value="">' + u.esc(o.empty) + '</option>' : '') + App.opts(list, cur) + '</select>';
  };
  App.check = function (form, key, label, o) {
    o = o || {};
    var f = App.form(form, {});
    var id = o.id || ('c-' + form + '-' + key);
    return '<label class="check" for="' + id + '"><input id="' + id + '" type="checkbox" data-f="' + form + '.' + key + '" data-t="bool"' + (o.rr ? ' data-rr="1"' : '') + (f[key] ? ' checked' : '') + '><span>' + u.esc(label) + '</span></label>';
  };
  App.field = function (label, control, id) {
    return '<div class="field"><label' + (id ? ' for="' + id + '"' : '') + '>' + u.esc(label) + '</label>' + control + '</div>';
  };
  App.btn = function (label, act, data, cls) {
    var d = '';
    Object.keys(data || {}).forEach(function (k) { d += ' data-' + k + '="' + u.esc(data[k]) + '"'; });
    return '<button type="button" class="btn ' + (cls || '') + '" data-act="' + u.esc(act) + '"' + d + '>' + label + '</button>';
  };
  App.sm = function (label, act, data, cls) { return App.btn(label, act, data, 'sm ' + (cls || '')); };
  App.bar = function (p, cls) {
    p = u.clamp(p || 0, 0, 100);
    return '<div class="bar ' + (cls || '') + '" role="img" aria-label="' + u.fa(Math.round(p)) + ' درصد"><i style="width:' + p.toFixed(1) + '%"></i></div>';
  };
  App.empty = function (text) { return '<p class="mu empty">' + text + '</p>'; };

  // کارت؛ اگر title داشته باشد با <details> بازشونده (وضعیت باز/بسته در S.col ذخیره می‌شود)
  App.card = function (title, body, o) {
    o = o || {};
    var cls = 'card' + (o.cls ? ' ' + o.cls : '');
    if (!title) return '<section class="' + cls + '"' + (o.id ? ' id="' + o.id + '"' : '') + '>' + body + '</section>';
    var key = (o.key || (ui.tab + '|' + title));
    var open = App.S.col && key in App.S.col ? App.S.col[key] : (o.open !== false);
    return '<details class="' + cls + '" data-colkey="' + u.esc(key) + '"' + (open ? ' open' : '') + (o.id ? ' id="' + o.id + '"' : '') + '><summary><h2>' + (o.icon ? o.icon + ' ' : '') + u.esc(title) + '</h2>' + (o.sub ? '<span class="sub">' + o.sub + '</span>' : '') + '</summary><div class="cbody">' + body + '</div></details>';
  };

  // ---- رندر ----
  App.render = function () {
    var app = document.getElementById('app');
    if (!app) return;
    var ae = document.activeElement;
    var focusId = ae && ae.id && app.contains(ae) ? ae.id : '';
    var caret = null;
    if (focusId && ae.selectionStart != null) caret = [ae.selectionStart, ae.selectionEnd];
    var html = '';
    try {
      html = App.views[ui.tab] ? App.views[ui.tab]() : App.views.today();
    } catch (e) {
      html = '<div class="card"><p>خطا در نمایش این بخش. دوباره امتحان کن.</p></div>';
      App.logError(e);
    }
    app.innerHTML = html;
    document.body.setAttribute('data-tab', ui.tab);
    renderNav();
    renderSheet();
    if (App.afterRender) { try { App.afterRender(); } catch (e) { App.logError(e); } }
    if (focusId) {
      var el = document.getElementById(focusId);
      if (el && el.focus) { el.focus(); if (caret && el.setSelectionRange) { try { el.setSelectionRange(caret[0], caret[1]); } catch (e) { /* ignore */ } } }
    } else if (ui.focusAct) {
      var parts = ui.focusAct.split('|');
      var sel = '[data-act="' + parts[0] + '"]' + (parts[1] ? '[data-key="' + parts[1] + '"]' : '');
      var b = app.querySelector(sel);
      if (b && b.focus) b.focus();
      ui.focusAct = '';
    }
    tickClock();
    if (App.gamify) {
      var ups = App.gamify.check();
      if (ups.length) App.toast('🏅 ' + ups.join(' · '), { ms: 7000 });
    }
  };
  App.go = function (tab, opt) {
    ui.tab = tab;
    if (tab === 'ai') ui.chatScroll = true;
    if (opt && opt.keepSheet !== true) ui.sheet = false;
    window.scrollTo(0, 0);
    App.render();
  };
  App.logError = function (e) {
    try { console.warn('[app]', e && e.message ? e.message : e); } catch (x) { /* ignore */ }
  };
  function renderNav() {
    var nav = document.getElementById('nav');
    if (!nav) return;
    nav.innerHTML = TABS.map(function (t) {
      var on = ui.tab === t[0];
      return '<button type="button" data-act="go" data-tab="' + t[0] + '"' + (on ? ' aria-current="page" class="on"' : '') + '><span aria-hidden="true">' + t[1] + '</span><span class="nl">' + t[2] + '</span></button>';
    }).join('');
  }
  function tickClock() {
    var e = document.getElementById('date');
    if (e) {
      var n = new Date();
      e.textContent = u.jd(u.todayISO(), true, true) + ' · ساعت ' + u.hm(n.getHours() * 60 + n.getMinutes());
    }
  }
  App.tickClock = tickClock;

  // ---- رویدادها (تفویض) ----
  document.addEventListener('click', function (e) {
    var el = e.target && e.target.closest ? e.target.closest('[data-act]') : null;
    if (!el) return;
    var name = el.getAttribute('data-act');
    var fn = App.act[name];
    if (!fn) return;
    if (el.tagName === 'A' || el.tagName === 'BUTTON' || el.tagName === 'SUMMARY') e.preventDefault();
    ui.focusAct = name + (el.getAttribute('data-key') ? '|' + el.getAttribute('data-key') : '');
    try { fn(el, e); }
    catch (err) { App.logError(err); App.toast('این کار انجام نشد: ' + (err && err.message ? err.message : 'خطای ناشناخته'), { ms: 5000 }); }
  }, false);

  // ورودی‌های فرم: بدون رندر (تا فوکوس و متن حفظ شود)
  function setFromEl(el) {
    var path = el.getAttribute('data-f');
    if (!path) return false;
    var parts = path.split('.');
    var f = App.form(parts[0], {});
    var t = el.getAttribute('data-t') || 'str';
    var v;
    if (t === 'bool') v = !!el.checked;
    else if (t === 'int' || t === 'num') { v = App.u.num(el.value); if (!isFinite(v)) v = null; }
    else v = el.value;
    f[parts[1]] = v;
    return true;
  }
  document.addEventListener('input', function (e) {
    var el = e.target;
    if (el && el.getAttribute && el.getAttribute('data-f') && !el.hasAttribute('data-rr')) setFromEl(el);
  }, false);
  document.addEventListener('change', function (e) {
    var el = e.target;
    if (!el || !el.getAttribute || !el.getAttribute('data-f')) return;
    setFromEl(el);
    if (el.hasAttribute('data-rr')) { if (el.getAttribute('data-act-change')) App.act[el.getAttribute('data-act-change')](el, e); else App.render(); }
  }, false);
  // کارت‌های بازشونده: وضعیت را ذخیره کن
  document.addEventListener('toggle', function (e) {
    var el = e.target;
    if (!el || !el.getAttribute || !el.hasAttribute('data-colkey') || !App.S) return;
    App.S.col = App.S.col || {};
    App.S.col[el.getAttribute('data-colkey')] = !!el.open;
    App.save();
  }, true);
  // کلیدهای میانبر: Esc بستن پنجره‌ها
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      if (ui.modal) App.closeModal();
      else if (ui.sheet) { ui.sheet = false; renderSheet(); }
    }
  });

  // ---- پیام کوتاه ----
  App.toast = function (msg, o) {
    o = o || {};
    var box = document.getElementById('toasts');
    if (!box) return;
    var t = document.createElement('div');
    t.className = 'toast' + (o.kind === 'err' ? ' err' : '');
    t.setAttribute('role', o.kind === 'err' ? 'alert' : 'status');
    var txt = document.createElement('span');
    txt.textContent = msg;
    t.appendChild(txt);
    var close = document.createElement('button');
    close.type = 'button';
    close.className = 'toast-x';
    close.setAttribute('aria-label', 'بستن پیام');
    close.textContent = '✕';
    close.onclick = function () { t.remove(); };
    t.appendChild(close);
    if (o.action) {
      var a = document.createElement('button');
      a.type = 'button';
      a.className = 'toast-act';
      a.textContent = o.action.label;
      a.onclick = function () { t.remove(); o.action.fn(); };
      t.insertBefore(a, close);
    }
    box.appendChild(t);
    while (box.children.length > 3) box.removeChild(box.firstChild);
    setTimeout(function () { if (t.parentNode) t.remove(); }, o.ms || 4500);
  };
  App.alert = function (msg) { App.toast(msg, { kind: 'err', ms: 6000 }); };
  App.confirm = function (msg) { try { return window.confirm(msg); } catch (e) { return false; } };

  // ---- پنجره (مودال) ----
  App.openModal = function (title, html, o) {
    o = o || {};
    var root = document.getElementById('modal');
    if (!root) return;
    ui.modal = { title: title, o: o };
    root.innerHTML = '<div class="modal-back" data-act="close-modal-back"></div><div class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><div class="modal-head"><h2 id="modal-title">' + u.esc(title) + '</h2><button type="button" class="sm" data-act="close-modal" aria-label="بستن">✕</button></div><div class="modal-body">' + html + '</div></div>';
    root.hidden = false;
    var first = root.querySelector('input,select,textarea,button:not([data-act="close-modal"])') || root.querySelector('[data-act="close-modal"]');
    if (first) first.focus();
    if (o.onOpen) o.onOpen(root);
  };
  App.closeModal = function () {
    var root = document.getElementById('modal');
    if (root) { root.hidden = true; root.innerHTML = ''; }
    var was = ui.modal;
    ui.modal = null;
    if (was && was.o && was.o.onClose) was.o.onClose();
  };
  App.act['close-modal'] = function () { App.closeModal(); };
  App.act['close-modal-back'] = function () { App.closeModal(); };

  // ---- پنجره‌ی گفتگو (روی همه‌ی تب‌ها) ----
  function renderSheet() {
    var sh = document.getElementById('sheet');
    if (!sh) return;
    if (!ui.sheet || ui.tab === 'ai') { sh.hidden = true; sh.innerHTML = ''; return; }
    sh.hidden = false;
    sh.innerHTML = '<div class="sheet-inner" role="dialog" aria-modal="false" aria-labelledby="sheet-title"><div class="sheet-head"><h2 id="sheet-title">💬 مشاور من</h2><div class="row0"><button type="button" class="sm" data-act="go" data-tab="ai">باز کردن کامل</button><button type="button" class="sm" data-act="sheet-close" aria-label="بستن مشاور">✕</button></div></div>' + (App.views.chatPanel ? App.views.chatPanel({ compact: true }) : '') + '</div>';
  }
  App.renderSheet = renderSheet;
  App.act['sheet-close'] = function () { ui.sheet = false; renderSheet(); };
  App.act['go'] = function (el) {
    var tab = el.getAttribute('data-tab');
    if (tab) App.go(tab);
  };

  // اعلان یک‌باره‌ی نسخه‌ی ۲ (کلید API از برنامه حذف شد)
  App.upgradeNotice = function () {
    var n = App.S.notices;
    if (!n || n.upgraded !== 0 || !n.upgradedFrom) return '';
    var key = n.keyHad ? 'کلید API قبلی‌ات از داخل برنامه حذف شد و دیگر در دستگاه ذخیره نمی‌شود. ' : '';
    return '<div class="card notice" role="note"><b>نسخه‌ی جدید (۲)</b><p>' + key + 'هوش مصنوعی را در تب 💬 مشاور فعال کن: سرویس مورد نظرت (Claude، Gemini یا OpenAI-سازگار) را با کلیدش اضافه کن.</p><button type="button" class="sm" data-act="dismiss-notice">متوجه شدم</button></div>';
  };
  App.act['dismiss-notice'] = function () { App.S.notices.upgraded = 1; App.save(); App.render(); };
})();
