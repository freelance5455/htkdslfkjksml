/* مشاور تحصیلی من، ابزارهای پایه: عدد، تاریخ شمسی، متن. بدون وابستگی. */
(function () {
  'use strict';
  var App = (window.App = window.App || {});
  var u = (App.u = {});

  var FA = '۰۱۲۳۴۵۶۷۸۹';
  u.JM = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
  u.WD = ['یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه']; // شاخص = getDay()

  u.p2 = function (n) { return String(n).padStart(2, '0'); };
  // عدد انگلیسی به فارسی
  u.pd = function (s) { return String(s).replace(/\d/g, function (d) { return FA[+d]; }); };
  // نمایش عدد با جداکننده‌ی فارسی (با پشتیبانی جایگزین)
  u.fa = function (n) {
    var x = Number(n);
    if (!isFinite(x)) x = 0;
    try { return x.toLocaleString('fa-IR', { maximumFractionDigits: 1 }); }
    catch (e) { return u.pd(String(Math.round(x * 10) / 10)); }
  };
  // ارقام فارسی/عربی را به لاتین و جداکننده‌ها را استاندارد می‌کند
  u.ascii = function (v) {
    return String(v == null ? '' : v)
      .replace(/[۰-۹]/g, function (c) { return String(c.charCodeAt(0) - 0x6f0); })
      .replace(/[٠-٩]/g, function (c) { return String(c.charCodeAt(0) - 0x660); })
      .replace(/٫/g, '.').replace(/[٬‌\s]/g, '').replace(/،/g, ',');
  };
  // خواندن عدد از ورودی؛ NaN اگر معتبر نباشد
  u.num = function (v) {
    var s = u.ascii(v).replace(/,/g, '.');
    if (s === '') return NaN;
    return /^-?\d+(\.\d+)?$/.test(s) ? parseFloat(s) : NaN;
  };
  u.int = function (v, min, max, def) {
    var x = u.num(v);
    if (!isFinite(x)) return def;
    x = Math.round(x);
    if (min != null && x < min) x = min;
    if (max != null && x > max) x = max;
    return x;
  };
  u.clamp = function (x, a, b) { return Math.max(a, Math.min(b, x)); };
  u.sum = function (a, f) { var t = 0; for (var i = 0; i < a.length; i++) t += f ? f(a[i]) : a[i]; return t; };
  u.avg = function (a) { return a.length ? u.sum(a) / a.length : 0; };
  u.esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };
  u.uid = function () { return Date.now() * 1000 + Math.floor(Math.random() * 1000); };
  u.clip = function (s, n) { s = String(s == null ? '' : s); return s.length > n ? s.slice(0, n) : s; };

  // ---- زمان و تاریخ (میلادی، محلی دستگاه) ----
  u.iso = function (d) { return d.getFullYear() + '-' + u.p2(d.getMonth() + 1) + '-' + u.p2(d.getDate()); };
  u.todayISO = function () { return u.iso(new Date()); };
  u.isISO = function (s) {
    if (typeof s !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
    var d = new Date(s + 'T12:00:00');
    return !isNaN(d.getTime()) && u.iso(d) === s;
  };
  u.addDays = function (iso, n) { var d = new Date(iso + 'T12:00:00'); d.setDate(d.getDate() + n); return u.iso(d); };
  // b - a بر حسب روز
  u.dayDiff = function (a, b) { return Math.round((new Date(b + 'T12:00:00') - new Date(a + 'T12:00:00')) / 864e5); };
  u.minutesNow = function () { var n = new Date(); return n.getHours() * 60 + n.getMinutes(); };

  // تبدیل میلادی به شمسی و برعکس (الگوریتم استاندارد)
  u.g2j = function (gy, gm, gd) {
    var g = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
    var jy = gy > 1600 ? 979 : 0;
    gy -= gy > 1600 ? 1600 : 621;
    var gy2 = gm > 2 ? gy + 1 : gy;
    var days = 365 * gy + ~~((gy2 + 3) / 4) - ~~((gy2 + 99) / 100) + ~~((gy2 + 399) / 400) - 80 + gd + g[gm - 1];
    jy += 33 * ~~(days / 12053);
    days %= 12053;
    jy += 4 * ~~(days / 1461);
    days %= 1461;
    if (days > 365) { jy += ~~((days - 1) / 365); days = (days - 1) % 365; }
    var jm = days < 186 ? 1 + ~~(days / 31) : 7 + ~~((days - 186) / 30);
    var jd = 1 + (days < 186 ? days % 31 : (days - 186) % 30);
    return [jy, jm, jd];
  };
  u.j2g = function (jy, jm, jd) {
    jy += 1595;
    var days = -355668 + 365 * jy + ~~(jy / 33) * 8 + ~~((jy % 33 + 3) / 4) + jd + (jm < 7 ? (jm - 1) * 31 : (jm - 7) * 30 + 186);
    var gy = 400 * ~~(days / 146097);
    days %= 146097;
    if (days > 36524) { gy += 100 * ~~(--days / 36524); days %= 36524; if (days >= 365) days++; }
    gy += 4 * ~~(days / 1461);
    days %= 1461;
    if (days > 365) { gy += ~~((days - 1) / 365); days = (days - 1) % 365; }
    var gd = days + 1;
    var md = [0, 31, (gy % 4 === 0 && gy % 100 !== 0) || gy % 400 === 0 ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    var gm;
    for (gm = 0; gm < 13 && gd > md[gm]; gm++) gd -= md[gm];
    return [gy, gm, gd];
  };
  // [سال، ماه، روز] شمسی برای یک تاریخ ISO
  u.jparts = function (iso) {
    var d = new Date(iso + 'T12:00:00');
    return u.g2j(d.getFullYear(), d.getMonth() + 1, d.getDate());
  };
  // ISO شمسی-به-میلادی؛ اگر نامعتبر باشد null
  u.jToIso = function (jy, jm, jd) {
    if (!(jm >= 1 && jm <= 12) || !(jd >= 1 && jd <= 31)) return null;
    var g = u.j2g(jy, jm, jd);
    var s = g[0] + '-' + u.p2(g[1]) + '-' + u.p2(g[2]);
    return u.isISO(s) && u.jparts(s)[2] === jd ? s : null;
  };
  // نمایش کوتاه: «۱۷ مهر»، یا با سال
  u.jd = function (iso, withYear, withWeekday) {
    if (!u.isISO(iso)) return '—';
    var p = u.jparts(iso);
    var s = p[2] + ' ' + u.JM[p[1] - 1] + (withYear ? ' ' + p[0] : '');
    if (withWeekday) s = u.WD[new Date(iso + 'T12:00:00').getDay()] + '، ' + s;
    return u.pd(s);
  };
  // تاریخ کامل شمسی و میلادی برای هوش مصنوعی
  u.dateLine = function (iso) {
    var wd = u.WD[new Date(iso + 'T12:00:00').getDay()];
    return wd + ' ' + u.jd(iso, true) + ' (' + iso + ')';
  };
  u.tmin = function (x) {
    var p = String(x || '00:00').split(':');
    return (+p[0] || 0) * 60 + (+p[1] || 0);
  };
  u.hm = function (n) { return u.pd(u.p2(Math.floor(n / 60)) + ':' + u.p2(n % 60)); };
  u.validHM = function (s) {
    if (typeof s !== 'string' || !/^\d{1,2}:\d{2}$/.test(s)) return false;
    var p = s.split(':');
    return +p[0] >= 0 && +p[0] <= 23 && +p[1] >= 0 && +p[1] <= 59;
  };
  u.normHM = function (s) { var p = String(s).split(':'); return u.p2(+p[0]) + ':' + u.p2(+p[1] || 0); };
  u.hours = function (min) { return u.fa(+(min / 60).toFixed(1)) + ' ساعت'; };
  u.dur = function (min) { return min ? u.hours(min) : '۰'; };
  u.pct = function (x) { return u.fa(Math.round(x)) + '٪'; };
  u.copyText = function (text) {
    var ok = false;
    try {
      var ta = document.createElement('textarea');
      ta.value = text; ta.setAttribute('readonly', ''); ta.style.position = 'fixed'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.select();
      ok = document.execCommand('copy');
      ta.remove();
    } catch (e) { ok = false; }
    if (ok) return Promise.resolve(true);
    try { return navigator.clipboard.writeText(text).then(function () { return true; }, function () { return false; }); }
    catch (e) { return Promise.resolve(false); }
  };
})();
