/* diplomacy-ui.js — Phase 5 interface: Diplomacy modal (Nations / Inbox / Treaties / Wars), nation detail, peace talks. */
(function (G) {
  'use strict';
  const $ = id => document.getElementById(id);
  const me = () => G.state.player;
  const nm = id => G.COUNTRIES[id].name;
  const sg = n => (n >= 0 ? '+' : '−') + Math.abs(Math.round(n));
  let tab = 'nations', target = null, terms = null, peaceWith = null;

  function relBar(r) {
    const pct = Math.round((r + 100) / 2), col = r > 20 ? 'var(--green)' : r < -20 ? '#e07060' : '#c8b060';
    return '<div class="bar"><i style="width:' + pct + '%;background:' + col + '"></i></div>';
  }
  function flag(id) { return '<img class="mini" src="' + G.flagURL(id) + '">'; }
  function treatyIcons(a, b) {
    return G.state.treaties.filter(t => (t.a === a && t.b === b) || (t.a === b && t.b === a)).map(t => G.TREATY[t.type].icon).join('') + (G.atWar(a, b) ? '⚔' : '');
  }
  function openM(h) { $('modal-box').innerHTML = h; $('modal').classList.remove('hidden'); }

  G.showDiplomacy = function (which, tgt) {
    if (which) tab = which;
    if (tgt !== undefined) target = tgt;
    const st = G.state, id = me(), inbox = G.pendingOffers();
    if (tab === 'peace') return renderPeace();
    if (tab === 'nation' && target != null) return renderNation();
    if (tab === 'nation') tab = 'nations';
    const names = { nations: 'Nations', inbox: 'Inbox' + (inbox.length ? ' (' + inbox.length + ')' : ''), treaties: 'Treaties', wars: 'Wars' };
    let h = '<h3>🤝 Diplomacy — ' + nm(id) + '</h3><div class="tabs">' +
      Object.keys(names).map(t => '<button data-t="' + t + '" class="' + (tab === t ? 'on' : '') + '">' + names[t] + '</button>').join('') + '</div>';
    const inf = st.infamy[id] || 0;
    if (inf >= 10) h += '<div class="alert">⚠ Your reputation as an aggressor is ' + Math.round(inf) + ' — other nations trust you less. It fades with time.</div>';
    h += ({ nations: nationsTab, inbox: inboxTab, treaties: treatiesTab, wars: warsTab })[tab](id);
    h += '<div class="row"><button id="dp-close">Close</button></div>';
    openM(h);
    $('dp-close').onclick = G.closeModal;
    $('modal-box').querySelectorAll('.tabs button[data-t]').forEach(b => b.onclick = () => { tab = b.dataset.t; G.showDiplomacy(); });
    $('modal-box').querySelectorAll('[data-nation]').forEach(b => b.onclick = () => { tab = 'nation'; target = b.dataset.nation; G.showDiplomacy(); });
    $('modal-box').querySelectorAll('[data-peace]').forEach(b => b.onclick = () => G.showPeace(b.dataset.peace));
    $('modal-box').querySelectorAll('[data-acc]').forEach(b => b.onclick = () => { const r = G.acceptOffer(+b.dataset.acc); G.toast(r.msg || (r.ok ? 'Accepted' : 'Failed')); G.updateTopBar(); G.requestDraw(); G.showDiplomacy(); });
    $('modal-box').querySelectorAll('[data-dec]').forEach(b => b.onclick = () => { G.declineOffer(+b.dataset.dec); G.updateTopBar(); G.showDiplomacy(); });
    $('modal-box').querySelectorAll('[data-cancel]').forEach(b => b.onclick = () => cancelFlow(+b.dataset.cancel));
  };

  function nationsTab(id) {
    return '<div class="rows">' + Object.keys(G.COUNTRIES).filter(o => o !== id && !G.isDead(o)).map(o => {
      const r = G.relation(id, o);
      return '<div class="slot dip" data-nation="' + o + '"><div class="info"><b>' + flag(o) + ' ' + nm(o) + '</b> <small>' + treatyIcons(id, o) + '</small><br><small>Relations ' + sg(r) + ' · ' + G.COUNTRIES[o].gov + '</small>' + relBar(r) + '</div><span class="chev">›</span></div>';
    }).join('') + '</div>';
  }

  function offerText(o) {
    if (o.type === 'join') return '📯 <b>' + nm(o.from) + '</b> calls you to join its war against <b>' + nm(o.target) + '</b>.';
    if (o.type === 'peace') {
      const t = o.terms || {}, bits = [];
      if ((t.demand || []).length) bits.push('you cede ' + t.demand.map(p => G.provinces[p].name).join(', '));
      if ((t.concede || []).length) bits.push('they cede ' + t.concede.map(p => G.provinces[p].name).join(', '));
      if (t.indemnity) bits.push(t.indemnity > 0 ? 'you pay ' + t.indemnity + ' gold' : 'they pay ' + (-t.indemnity) + ' gold');
      return '🕊 <b>' + nm(o.from) + '</b> offers peace: ' + (bits.length ? bits.join('; ') : 'white peace (no changes)') + '.';
    }
    return G.TREATY[o.type].icon + ' <b>' + nm(o.from) + '</b> proposes a ' + G.TREATY[o.type].name + '.';
  }
  function inboxTab() {
    const list = G.pendingOffers();
    if (!list.length) return '<p class="dim">No pending offers. Other nations propose treaties from time to time.</p>';
    return list.map(o => '<div class="card"><p>' + offerText(o) + '</p><small class="dim">Expires in ' + Math.max(0, o.expires - G.state.day) + ' days</small>' +
      '<div class="chips"><button class="primary" data-acc="' + o.id + '">Accept</button><button data-dec="' + o.id + '">Decline</button></div></div>').join('');
  }

  function treatiesTab(id) {
    const list = G.treatiesOf(id);
    if (!list.length) return '<p class="dim">You have no treaties. Open <b>Nations</b> to propose one.</p>' + incomeNote(id);
    return incomeNote(id) + list.map(t => {
      const T = G.TREATY[t.type], other = t.a === id ? t.b : t.a;
      const dir = T.sym ? '' : (t.a === id ? ' (you grant)' : ' (they grant)');
      return '<div class="slot"><div class="info"><b>' + T.icon + ' ' + T.name + dir + '</b><br><small>' + flag(other) + ' ' + nm(other) + (t.end ? ' · ends in ' + Math.max(0, t.end - G.state.day) + ' days' : ' · no expiry') + '</small></div>' +
        '<button data-cancel="' + t.id + '">Cancel</button></div>';
    }).join('');
  }
  function incomeNote(id) {
    const n = G.tradePartners(id);
    return n ? '<div class="eqline">📦 ' + n + ' trade agreement' + (n > 1 ? 's' : '') + ': +' + n * G.TRADE_GOLD_BONUS + ' gold/day, +' + n * G.TRADE_CAP_BONUS + ' trade capacity/month</div>' : '';
  }
  function cancelFlow(tid) {
    const t = G.state.treaties.find(x => x.id === tid); if (!t) return;
    const costly = t.type === 'nap' || t.type === 'alliance';
    G.confirmBox('Cancel ' + G.TREATY[t.type].name + '?' + (costly ? ' This damages relations and your reputation.' : ''), 'Cancel treaty', () => {
      G.cancelTreaty(tid, me(), 'cancel'); G.toast('Treaty cancelled'); G.updateTopBar(); G.requestDraw(); G.showDiplomacy();
    });
  }

  function warsTab(id) {
    const ws = G.warsOf(id);
    let h = '';
    if (!ws.length) h += '<p class="dim">You are at peace.</p>';
    ws.forEach(o => {
      const s = G.warScore(id, o);
      h += '<div class="slot"><div class="info"><b>' + flag(o) + ' ' + nm(o) + '</b><br><small>War score ' + sg(s) + ' · weariness ' + G.exhaustion(id, o) + '</small>' + relBar(s) + '</div><button data-peace="' + o + '">Peace talks</button></div>';
    });
    const others = Object.keys(G.state.wars).map(k => G.state.wars[k]).filter(w => w.a !== id && w.b !== id);
    if (others.length) h += '<h3>Other wars</h3>' + others.map(w => '<div class="slot"><div class="info">' + flag(w.a) + ' ' + nm(w.a) + ' ⚔ ' + flag(w.b) + ' ' + nm(w.b) + '<br><small>since day ' + w.start + '</small></div></div>').join('');
    return h;
  }

  /* ---------- nation detail ---------- */
  function renderNation() {
    const st = G.state, id = me(), o = target;
    if (G.isDead(o)) { tab = 'nations'; return G.showDiplomacy(); }
    const r = G.relation(id, o), op = G.opinion(o, id), war = G.atWar(id, o);
    let h = '<h3>' + flag(o) + ' ' + nm(o) + '</h3><div class="sub">' + G.COUNTRIES[o].gov + ' · ' + st.countries[o].provCount + ' provinces</div>';
    const pers = G.aiInfo(o);
    h += '<div class="eqline">Relations ' + sg(r) + ' ' + treatyIcons(id, o) + '</div>' + relBar(r);
    if (pers) h += '<p class="dim" style="font-size:12px">Temperament: <b>' + pers.label + '</b>' + (G.intelLevel(id, o) >= 50 ? ' · aggression ' + Math.round(pers.aggression * 100) + '% · caution ' + Math.round(pers.caution * 100) + '%' + (pers.plan && !G.isDead(pers.plan.target) && G.atWar(o, pers.plan.target) ? ' · fighting ' + G.COUNTRIES[pers.plan.target].name : '') : ' (build intel for details)') + '</p>';
    h += '<p class="dim" style="font-size:12px">Their view of you: <b>' + sg(op.score) + '</b> (' + op.parts.map(p => p[0] + ' ' + sg(p[1])).join(', ') + ')</p>';
    if (war) {
      h += '<div class="alert">⚔ At war — war score ' + sg(G.warScore(id, o)) + '</div><div class="chips"><button class="primary" data-peace="' + o + '">🕊 Peace talks</button></div>';
    } else {
      h += '<div class="chips"><button id="dn-imp"' + (st.countries[id].treasury < G.IMPROVE_COST ? ' disabled' : '') + '>💬 Improve relations (💰 ' + G.IMPROVE_COST + ')</button>' +
        '<button data-gift="100">🎁 Gift 100</button><button data-gift="300">🎁 Gift 300</button></div>';
      h += '<h3>Proposals</h3>';
      G.TREATY_TYPES.forEach(type => {
        const T = G.TREATY[type], have = G.hasTreaty(type, id, o), ev = G.diplomacyEval(type, id, o);
        const hint = have ? 'In force' : ev.score == null ? ev.msg : (ev.ok ? '👍 likely (' + sg(ev.score) + ' / ' + ev.need + ')' : '👎 unlikely (' + sg(ev.score) + ' / ' + ev.need + ')');
        const label = type === 'access' ? 'Ask military access' : type === 'guarantee' ? 'Guarantee their independence' : T.name;
        h += '<div class="slot"><div class="info"><b>' + T.icon + ' ' + label + '</b><br><small>' + hint + '</small></div>' +
          (have ? '<button data-cancelp="' + type + '">Cancel</button>' : '<button data-prop="' + type + '"' + (ev.score == null ? ' disabled' : '') + '>Propose</button>') + '</div>';
      });
      const tr = G.hasTreaty('access', o, id);
      h += '<div class="chips"><button id="dn-grant">' + (G.hasTreaty('access', id, o) ? '✔ You grant them access (cancel)' : '🪖 Grant them military access') + '</button></div>';
    }
    h += '<div class="row"><button id="dn-back">‹ Back</button><button id="dn-close">Close</button></div>';
    openM(h);
    const box = $('modal-box'), done = () => { G.updateTopBar(); G.requestDraw(); G.showDiplomacy(); };
    $('dn-back').onclick = () => { tab = 'nations'; G.showDiplomacy(); };
    $('dn-close').onclick = G.closeModal;
    box.querySelectorAll('[data-peace]').forEach(b => b.onclick = () => G.showPeace(o));
    const imp = $('dn-imp'); if (imp) imp.onclick = () => { const rr = G.improveRelations(id, o); G.toast(rr.ok ? 'Relations improved' : rr.msg); done(); };
    box.querySelectorAll('[data-gift]').forEach(b => b.onclick = () => { const rr = G.sendGift(id, o, +b.dataset.gift); G.toast(rr.ok ? 'Gift sent' : rr.msg); done(); });
    box.querySelectorAll('[data-prop]').forEach(b => b.onclick = () => {
      const rr = G.propose(b.dataset.prop, id, o);
      G.toast(rr.ok ? G.TREATY[b.dataset.prop].name + ' signed with ' + nm(o) : rr.msg); done();
    });
    box.querySelectorAll('[data-cancelp]').forEach(b => b.onclick = () => { const t = G.hasTreaty(b.dataset.cancelp, id, o); if (t) cancelFlow(t.id); });
    const gr = $('dn-grant'); if (gr) gr.onclick = () => {
      const t = G.hasTreaty('access', id, o);
      if (t) G.cancelTreaty(t.id, id, 'cancel'); else if (!G.allied(id, o)) G.signTreaty('access', id, o); else G.toast('Allies already share access');
      done();
    };
  }

  /* ---------- peace talks ---------- */
  G.showPeace = function (o) {
    if (peaceWith !== o) { peaceWith = o; terms = { demand: [], concede: [], indemnity: 0 }; }
    tab = 'peace'; target = o; renderPeace();
  };
  function renderPeace() {
    const st = G.state, id = me(), o = target;
    if (!G.atWar(id, o)) { tab = 'nation'; peaceWith = null; return G.showDiplomacy(); }
    const theirs = G.provinces.filter(p => !p.sea && st.owners[p.id] === o), mine = G.provinces.filter(p => !p.sea && st.owners[p.id] === id);
    const ev = G.peaceEval(id, o, terms);
    let h = '<h3>🕊 Peace talks — ' + nm(o) + '</h3>' +
      '<div class="eqline">War score ' + sg(G.warScore(id, o)) + ' · their weariness ' + G.exhaustion(id, o) + '</div>';
    h += '<h3>Demand from them</h3><div class="chips">' + theirs.map(p => {
      const on = terms.demand.includes(p.id);
      return '<button data-d="' + p.id + '" class="' + (on ? 'primary' : '') + '">' + (p.capital ? '★ ' : '') + p.name + ' (' + G.provPeaceCost(p.id) + ')</button>';
    }).join('') + '</div>';
    h += '<h3>Concede to them</h3><div class="chips">' + (mine.length ? mine.map(p => {
      const on = terms.concede.includes(p.id);
      return '<button data-c="' + p.id + '" class="' + (on ? 'primary' : '') + '">' + (p.capital ? '★ ' : '') + p.name + '</button>';
    }).join('') : '<small class="dim">—</small>') + '</div>';
    h += '<h3>Gold</h3><div class="chips">' + [-300, -100, 0, 100, 300].map(v =>
      '<button data-i="' + v + '" class="' + (terms.indemnity === v ? 'primary' : '') + '">' + (v < 0 ? 'You pay ' + (-v) : v > 0 ? 'They pay ' + v : 'None') + '</button>').join('') + '</div>';
    h += '<div class="alert ' + (ev.ok ? 'ok' : '') + '">' + (ev.ok ? '👍 They would accept' : '👎 ' + (ev.msg || 'They would refuse')) +
      '<br><small>' + ev.parts.map(p => p[0] + ' ' + sg(p[1])).join(' · ') + ' = ' + sg(ev.total) + '</small></div>';
    h += '<div class="row"><button id="pc-back">‹ Back</button><button id="pc-go" class="primary"' + (ev.ok ? '' : ' disabled') + '>Sign peace</button></div>';
    openM(h);
    const box = $('modal-box'), again = () => renderPeace();
    box.querySelectorAll('[data-d]').forEach(b => b.onclick = () => { const p = +b.dataset.d, i = terms.demand.indexOf(p); if (i < 0) terms.demand.push(p); else terms.demand.splice(i, 1); again(); });
    box.querySelectorAll('[data-c]').forEach(b => b.onclick = () => { const p = +b.dataset.c, i = terms.concede.indexOf(p); if (i < 0) terms.concede.push(p); else terms.concede.splice(i, 1); again(); });
    box.querySelectorAll('[data-i]').forEach(b => b.onclick = () => { terms.indemnity = +b.dataset.i; again(); });
    $('pc-back').onclick = () => { peaceWith = null; tab = 'wars'; G.showDiplomacy(); };
    $('pc-go').onclick = () => {
      const r = G.makePeace(id, o, terms);
      G.toast(r.ok ? 'Peace signed with ' + nm(o) : r.msg);
      peaceWith = null; tab = 'wars'; G.updateTopBar(); G.requestDraw(); G.refreshPanel(); G.showDiplomacy();
    };
  }

  /* ---------- hooks ---------- */
  G.dipBadge = function () {
    const el = $('dip-badge'); if (!el || !G.state || !G.state.player) return;
    const n = G.pendingOffers().length;
    el.textContent = n || ''; el.style.display = n ? '' : 'none';
  };
  G.onOffer = function () { G.dipBadge(); };
  G.onTreatyChange = function () { G.dipBadge && G.dipBadge(); G.requestDraw && G.requestDraw(); };
  G.bindDiplomacyUI = function () { $('btn-dip').onclick = () => { tab = 'nations'; target = null; peaceWith = null; G.showDiplomacy(); }; };
})(window.EMP = window.EMP || {});
