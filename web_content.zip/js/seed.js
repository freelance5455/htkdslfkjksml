/**
 * seed.js
 * Dados fictícios EXCLUSIVOS para desenvolvimento/teste. Nunca rodam se
 * APP_CONFIG.ENV === 'prod'. Isso cumpre a exigência de nunca apresentar
 * dados fictícios como se fossem usuários reais.
 *
 * Cria:
 * - 1 administrador de teste (login: admin@anjodaguarda.dev / senha: admin123)
 * - categorias de serviço padrão
 * - nada de imóveis/providers fictícios — cada pessoa que testar cria os seus
 */
async function rodarSeedDesenvolvimento(){
  if(window.APP_CONFIG.ENV === 'prod') return;

  CategoriesService.seedPadrao();

  if(DB._tabelaVazia('users')){
    // Cria o admin de teste diretamente (sem passar por Auth.signUp para não
    // exigir um "tipo_usuario" fora dos dois perfis públicos de cadastro).
    const salt = 'devsalt';
    const enc = new TextEncoder().encode(salt + ':admin123');
    const buf = await crypto.subtle.digest('SHA-256', enc);
    const hash = Array.from(new Uint8Array(buf)).map(b=>b.toString(16).padStart(2,'0')).join('');

    DB.insert('users', Models.novoUsuario({
      nome: '[DEV] Administrador de Teste',
      email: 'admin@anjodaguarda.dev',
      telefone: '(13) 90000-0000',
      tipo_usuario: 'administrador',
      senha_hash: salt + '$' + hash,
    }));
  }
}
