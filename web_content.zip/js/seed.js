/* =============================================================
   LAMPION POS · js/seed.js
   Pengganti sql/schema.sqlite.sql + sql/seed.sqlite.sql
   -------------------------------------------------------------
   Data awal identik dengan seed SQLite: settings, permissions,
   roles, role_permissions, categories, menu_items,
   inventory_items, menu_inventory.
   Akun pertama TIDAK dibuat di sini (padanan: dulu dibuat oleh
   lpos-install.sh / panel Pengguna) — dibuat oleh js/boot.js
   saat instalasi pertama supaya tidak ada kredensial default.
   ============================================================= */
(function (global) {
  'use strict';

  var DB = global.LPDB;
  var db = DB.db;

  /* ---------- settings (padanan INSERT INTO settings) ---------- */
  var SETTINGS = [
    ['store_name', 'Lampion Resto'],
    ['store_address', 'Jl. Contoh No. 1, Kota'],
    ['store_phone', '+62 900 000 0000'],
    ['store_footer', 'Terima kasih! Selamat datang kembali.'],
    ['tax_rate', '10'],
    ['pos_item_style', 'icon'],
    ['kiosk_fullscreen', '1'],
    ['printer_mode', 'browser'],
    ['printer_width', '58'],
    ['printer_service', '0000ff00-0000-1000-8000-00805f9b34fb'],
    ['printer_char', '0000ff02-0000-1000-8000-00805f9b34fb'],
    ['printer_font_px', '24'],
    ['counter_date', '00000000'],
    ['counter_dine_in', '0'],
    ['counter_takeaway', '0'],
    ['counter_online', '0'],
    ['promo_images', '[]'],
    ['print_kitchen', '1']
  ];

  /* ---------- permissions ---------- */
  var PERMISSIONS = [
    ['dashboard.view', 'Lihat Ringkasan', 'Dashboard', 1],
    ['pos.order', 'Buat Pesanan (Kasir)', 'Kasir', 2],
    ['pos.print', 'Cetak Struk', 'Kasir', 3],
    ['menu.view', 'Lihat Menu', 'Menu', 4],
    ['menu.manage', 'Kelola Menu (CRUD)', 'Menu', 5],
    ['category.view', 'Lihat Kategori', 'Kategori', 6],
    ['category.manage', 'Kelola Kategori', 'Kategori', 7],
    ['inventory.view', 'Lihat Inventory', 'Inventory', 10],
    ['inventory.manage', 'Kelola Inventory & Stok', 'Inventory', 11],
    ['sales.view', 'Lihat Penjualan', 'Laporan', 12],
    ['users.manage', 'Kelola Pengguna', 'Pengguna', 13],
    ['roles.manage', 'Kelola Peran & Akses', 'Peran', 14],
    ['settings.manage', 'Kelola Pengaturan', 'Pengaturan', 15],
    ['activity.view', 'Lihat Activity Log', 'Activity Log', 16]
  ];

  /* ---------- roles ---------- */
  var ROLES = [
    { id: 1, name: 'Admin', is_system: 1 },
    { id: 2, name: 'Kasir', is_system: 0 },
    { id: 3, name: 'Owner', is_system: 0 },
    { id: 4, name: 'Staff Gudang', is_system: 0 }
  ];

  /* ---------- role_permissions (padanan SELECT ... WHERE p.pkey IN ...) ---------- */
  var ROLE_PERMS = {
    'Admin': null, // null = SEMUA permission (padanan '*' di role_permissions())
    'Kasir': ['dashboard.view', 'pos.order', 'pos.print', 'menu.view'],
    'Owner': ['dashboard.view', 'pos.order', 'pos.print', 'menu.view', 'menu.manage',
      'category.view', 'category.manage', 'inventory.view', 'sales.view',
      'settings.manage', 'activity.view'],
    'Staff Gudang': ['inventory.view', 'inventory.manage', 'menu.view']
  };

  /* ---------- categories ---------- */
  var CATEGORIES = [
    { id: 1, name: 'Makanan', sort_order: 1 },
    { id: 2, name: 'Minuman', sort_order: 2 },
    { id: 3, name: 'Snack', sort_order: 3 }
  ];

  /* ---------- menu_items ---------- */
  var MENU_ITEMS = [
    { id: 1, category_id: 1, name: 'Ayam Geprek', description: '', price_dine_in: 18000, price_takeaway: 20000, price_online: 22000, sort_order: 1 },
    { id: 2, category_id: 1, name: 'Ayam Goreng', description: '', price_dine_in: 15000, price_takeaway: 17000, price_online: 19000, sort_order: 2 },
    { id: 3, category_id: 1, name: 'Ayam Bakar', description: '', price_dine_in: 20000, price_takeaway: 22000, price_online: 24000, sort_order: 3 },
    { id: 4, category_id: 1, name: 'Nasi Goreng', description: '', price_dine_in: 8000, price_takeaway: 9000, price_online: 10000, sort_order: 4 },
    { id: 5, category_id: 2, name: 'Es Teh', description: '', price_dine_in: 5000, price_takeaway: 5000, price_online: 6000, sort_order: 1 },
    { id: 6, category_id: 2, name: 'Jus Oranye', description: '', price_dine_in: 9000, price_takeaway: 10000, price_online: 11000, sort_order: 2 },
    { id: 7, category_id: 3, name: 'Pommes (Fries)', description: '', price_dine_in: 7000, price_takeaway: 8000, price_online: 9000, sort_order: 1 }
  ];

  /* ---------- inventory_items ---------- */
  var INVENTORY_ITEMS = [
    { id: 1, name: 'Ayam Potong', unit: 'ekor', stock_qty: 20, min_stock: 5, note: 'Ayam yang sudah dipotong' },
    { id: 2, name: 'Minyak Goreng', unit: 'liter', stock_qty: 10, min_stock: 2, note: '' },
    { id: 3, name: 'Beras', unit: 'kg', stock_qty: 25, min_stock: 5, note: '' },
    { id: 4, name: 'Daun Oranye/Kaffir', unit: 'pak', stock_qty: 15, min_stock: 4, note: '' },
    { id: 5, name: 'Sos Siracha', unit: 'botol', stock_qty: 8, min_stock: 2, note: '' },
    { id: 6, name: 'Karton Es Teh', unit: 'botol', stock_qty: 24, min_stock: 6, note: '' }
  ];

  /* ---------- menu_inventory (pivot many-to-many) ---------- */

  /** INSERT OR IGNORE: hanya tambah bila belum ada */
  function addIfMissing(table, row, keyField) {
    return db.table(table).where(keyField).equals(row[keyField]).count().then(function (n) {
      if (n > 0) { return 0; }
      return db.table(table).add(row).then(function () { return 1; });
    });
  }

  /**
   * Isi database dengan data awal (padanan bootstrap_database + seed).
   * Semua langkah dijalankan BERURUTAN (bukan paralel) karena
   * role_permissions membutuhkan id permission & role yang sudah ada.
   * @returns {Promise<boolean>} true bila seed selesai dijalankan
   */
  function runSeed() {
    var now = DB.now();
    var permIdByKey = {};
    var roleIdByName = {};

    /* 1. permissions lebih dulu (dibutuhkan role_permissions).
       Memakai put() pada pkey unik supaya aman walau seed sebelumnya
       berhenti di tengah (data separuh jadi). */
    return chain(PERMISSIONS, function (p) {
      return db.permissions.where('pkey').equals(p[0]).first().then(function (row) {
        if (row) {
          permIdByKey[p[0]] = Number(row.id);
          /* lengkapi nama/grup bila baris lama tidak lengkap */
          return db.permissions.update(Number(row.id), {
            name: p[1], group_label: p[2], sort: p[3]
          });
        }
        return db.permissions.add({
          pkey: p[0], name: p[1], group_label: p[2], sort: p[3]
        }).then(function (id) { permIdByKey[p[0]] = Number(id); return 1; });
      });
    })

      /* 2. roles — cari berdasarkan nama, jangan paksa id tertentu
            (auto-increment bisa sudah maju, mis. setelah wipeTables) */
      .then(function () {
        return chain(ROLES, function (r) {
          return db.roles.where('name').equals(r.name).first().then(function (row) {
            if (row) { roleIdByName[r.name] = Number(row.id); return 0; }
            return db.roles.add({
              name: r.name, is_system: r.is_system, is_active: 1, created_at: now
            }).then(function (id) { roleIdByName[r.name] = Number(id); return 1; });
          });
        });
      })

      /* 3. role_permissions (hanya setelah permission & role pasti ada) */
      .then(function () {
        var pairs = [];
        Object.keys(ROLE_PERMS).forEach(function (roleName) {
          var rid = roleIdByName[roleName];
          if (!rid) { return; }
          var keys = ROLE_PERMS[roleName];
          if (keys === null) {
            keys = PERMISSIONS.map(function (p) { return p[0]; });
          }
          keys.forEach(function (k) {
            var pid = permIdByKey[k];
            if (pid) { pairs.push({ role_id: rid, permission_id: pid }); }
          });
        });
        return pairs.length ? db.role_permissions.bulkPut(pairs) : 0;
      })

      /* 4. settings */
      .then(function () {
        return chain(SETTINGS, function (s) {
          return addIfMissing('settings',
            { setting_key: s[0], setting_value: s[1] }, 'setting_key');
        });
      })

      /* 5. categories — jangan paksa id (auto-increment bisa sudah maju) */
      .then(function () {
        return chain(CATEGORIES, function (c) {
          return addIfMissing('categories', {
            name: c.name, sort_order: c.sort_order, is_active: 1
          }, 'name');
        });
      })

      /* 6. menu_items */
      .then(function () {
        return db.categories.toArray().then(function (cats) {
          var catIdByName = {};
          cats.forEach(function (c) { catIdByName[String(c.name)] = Number(c.id); });
          return chain(MENU_ITEMS, function (m) {
            var catRef = CATEGORIES.filter(function (c) {
              return c.id === m.category_id;
            })[0] || {};
            return addIfMissing('menu_items', {
              category_id: catIdByName[String(catRef.name)],
              name: m.name,
              description: m.description,
              price_dine_in: m.price_dine_in, price_takeaway: m.price_takeaway,
              price_online: m.price_online, image: null, is_active: 1,
              sort_order: m.sort_order, created_at: now, updated_at: now
            }, 'name');
          });
        });
      })

      /* 7. inventory_items — jangan paksa id */
      .then(function () {
        return chain(INVENTORY_ITEMS, function (i) {
          return addIfMissing('inventory_items', {
            name: i.name, unit: i.unit, stock_qty: i.stock_qty,
            min_stock: i.min_stock, note: i.note, is_active: 1, created_at: now
          }, 'name');
        });
      })

      /* 8. menu_inventory (pivot) — selesaikan id lewat NAMA,
            karena auto-increment tidak selalu sama dengan seed SQL */
      .then(function () {
        return Promise.all([
          db.menu_items.toArray(), db.inventory_items.toArray(),
          db.menu_inventory.toArray()
        ]).then(function (res) {
          var menuIdByName = {};
          res[0].forEach(function (m) { menuIdByName[String(m.name)] = Number(m.id); });
          var invIdByName = {};
          res[1].forEach(function (i) { invIdByName[String(i.name)] = Number(i.id); });

          var seen = {};
          res[2].forEach(function (e) {
            seen[e.menu_id + ':' + e.inventory_id] = 1;
          });

          var fresh = [];
          MENU_INVENTORY.forEach(function (p) {
            var menuName = (MENU_ITEMS[p.menu_id - 1] || {}).name;
            var invName = (INVENTORY_ITEMS[p.inventory_id - 1] || {}).name;
            var mid = menuIdByName[menuName];
            var iid = invIdByName[invName];
            if (!mid || !iid) { return; }
            if (seen[mid + ':' + iid]) { return; }
            fresh.push({ menu_id: mid, inventory_id: iid, qty_used: p.qty_used });
          });
          return fresh.length ? db.menu_inventory.bulkAdd(fresh) : 0;
        });
      })

      .then(function () { return true; });
  }

  /** Jalankan tugas berurutan (menghindari transaksi bersarang Dexie) */
  function chain(list, fn) {
    var p = Promise.resolve();
    list.forEach(function (item) {
      p = p.then(function () { return fn(item); });
    });
    return p;
  }

  global.LPSEED = {
    SETTINGS: SETTINGS,
    PERMISSIONS: PERMISSIONS,
    ROLES: ROLES,
    ROLE_PERMS: ROLE_PERMS,
    CATEGORIES: CATEGORIES,
    MENU_ITEMS: MENU_ITEMS,
    INVENTORY_ITEMS: INVENTORY_ITEMS,
    MENU_INVENTORY: MENU_INVENTORY,
    runSeed: runSeed
  };
})(window);

  var MENU_INVENTORY = [
    { menu_id: 1, inventory_id: 1, qty_used: 0.5 },
    { menu_id: 2, inventory_id: 1, qty_used: 0.5 },
    { menu_id: 3, inventory_id: 1, qty_used: 0.5 },
    { menu_id: 1, inventory_id: 5, qty_used: 0.2 },
    { menu_id: 2, inventory_id: 2, qty_used: 0.15 },
    { menu_id: 3, inventory_id: 4, qty_used: 1 },
    { menu_id: 4, inventory_id: 3, qty_used: 0.25 }
  ];
