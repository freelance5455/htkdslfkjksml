export class RealtimeArena {
  constructor({ onEvent = () => {} } = {}) {
    this.onEvent = onEvent;
    this.socket = null;
    this.playerId = null;
    this.roomCode = null;
    this.localStream = null;
    this.peers = new Map();
    this.remoteCandidates = new Map();
    this.voiceEnabled = false;
  }

  async connect(code) {
    if (!window.WebsimSocket?.joinRoom) throw new Error("Canlı oyun bağlantısı kullanılamıyor.");
    this.roomCode = code;
    const socket = await window.WebsimSocket.joinRoom();
    this.socket = socket;
    return new Promise((resolve, reject) => {
      let settled = false;
      const timeout = window.setTimeout(() => {
        if (!settled) {
          settled = true;
          reject(new Error("Oda bağlantısı zaman aşımına uğradı."));
        }
      }, 10000);
      socket.onmessage = async (event) => {
        let message;
        try { message = JSON.parse(event.data); } catch { return; }
        if (message.type === "welcome") {
          this.playerId = message.id;
          socket.send({ type: "enter", code });
          return;
        }
        if (message.type === "lobby" || message.type === "joined") {
          if (message.ok) {
            if (!settled) {
              settled = true;
              clearTimeout(timeout);
              resolve(message);
            }
            this.onEvent(message.type, message);
          } else if (!settled) {
            settled = true;
            clearTimeout(timeout);
            reject(new Error(message.error ?? "Odaya katılınamadı."));
            socket.close();
          }
          return;
        }
        await this._message(message);
      };
      socket.onclose = (event) => {
        if (!settled) {
          settled = true;
          clearTimeout(timeout);
          reject(new Error(event.reason || "Oda bağlantısı kapandı."));
        }
        this.onEvent("disconnect", { reason: event.reason || "Bağlantı kesildi." });
        this._closeVoice();
      };
      socket.onreconnect = () => this.onEvent("reconnect", {});
    });
  }

  send(message) {
    this.socket?.send(message);
  }

  chat(text) {
    this.send({ type: "chat", text });
  }

  async toggleVoice() {
    if (this.voiceEnabled) {
      this.send({ type: "voice-ready", enabled: false });
      this._closeVoice();
      return false;
    }
    this.localStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    this.voiceEnabled = true;
    this.send({ type: "voice-ready", enabled: true });
    for (const [peerId, peer] of this.peers) {
      const pc = peer.pc;
      if (pc.signalingState !== "closed" && pc.getSenders().length === 0) {
        for (const track of this.localStream.getTracks()) pc.addTrack(track, this.localStream);
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);
        this.send({ type: "voice-signal", to: peerId, signal: { kind: "offer", sdp: pc.localDescription } });
      }
    }
    return true;
  }

  async _message(message) {
    if (message.type === "voice-ready") {
      if (!message.enabled) {
        this._dropPeer(message.id);
        return;
      }
      if (this.voiceEnabled && this.playerId < message.id) await this._offerPeer(message.id);
      return;
    }
    if (message.type === "voice-signal") {
      await this._signal(message.from, message.signal);
      return;
    }
    this.onEvent(message.type, message);
  }

  async _offerPeer(peerId) {
    const peer = this._peer(peerId);
    if (this.localStream) {
      for (const track of this.localStream.getTracks()) peer.pc.addTrack(track, this.localStream);
    }
    const offer = await peer.pc.createOffer();
    await peer.pc.setLocalDescription(offer);
    this.send({ type: "voice-signal", to: peerId, signal: { kind: "offer", sdp: peer.pc.localDescription } });
  }

  async _signal(peerId, signal) {
    if (!signal || !peerId) return;
    const peer = this._peer(peerId);
    if (signal.kind === "offer") {
      if (this.localStream) for (const track of this.localStream.getTracks()) peer.pc.addTrack(track, this.localStream);
      await peer.pc.setRemoteDescription(signal.sdp);
      const candidates = this.remoteCandidates.get(peerId) ?? [];
      for (const candidate of candidates) await peer.pc.addIceCandidate(candidate).catch(() => {});
      this.remoteCandidates.delete(peerId);
      const answer = await peer.pc.createAnswer();
      await peer.pc.setLocalDescription(answer);
      this.send({ type: "voice-signal", to: peerId, signal: { kind: "answer", sdp: peer.pc.localDescription } });
    } else if (signal.kind === "answer" && peer.pc.signalingState === "have-local-offer") {
      await peer.pc.setRemoteDescription(signal.sdp);
      const candidates = this.remoteCandidates.get(peerId) ?? [];
      for (const candidate of candidates) await peer.pc.addIceCandidate(candidate).catch(() => {});
      this.remoteCandidates.delete(peerId);
    } else if (signal.kind === "candidate") {
      if (peer.pc.remoteDescription) await peer.pc.addIceCandidate(signal.candidate).catch(() => {});
      else {
        const candidates = this.remoteCandidates.get(peerId) ?? [];
        candidates.push(signal.candidate);
        this.remoteCandidates.set(peerId, candidates);
      }
    }
  }

  _peer(peerId) {
    if (this.peers.has(peerId)) return this.peers.get(peerId);
    const pc = new RTCPeerConnection({ iceServers: [{ urls: "stun:stun.l.google.com:19302" }] });
    const peer = { pc, audio: null };
    pc.onicecandidate = (event) => {
      if (event.candidate) this.send({ type: "voice-signal", to: peerId, signal: { kind: "candidate", candidate: event.candidate } });
    };
    pc.ontrack = (event) => {
      const audio = new Audio();
      audio.autoplay = true;
      audio.srcObject = event.streams[0];
      audio.play().catch(() => {});
      peer.audio = audio;
    };
    pc.onconnectionstatechange = () => {
      if (["failed", "closed"].includes(pc.connectionState)) this._dropPeer(peerId);
    };
    this.peers.set(peerId, peer);
    return peer;
  }

  _dropPeer(peerId) {
    const peer = this.peers.get(peerId);
    if (!peer) return;
    peer.audio?.remove();
    peer.pc.close();
    this.peers.delete(peerId);
    this.remoteCandidates.delete(peerId);
  }

  _closeVoice() {
    this.localStream?.getTracks().forEach((track) => track.stop());
    this.localStream = null;
    this.voiceEnabled = false;
    for (const id of this.peers.keys()) this._dropPeer(id);
  }

  close() {
    this._closeVoice();
    this.socket?.close();
    this.socket = null;
  }
}
