// ===== finisher.js: the karambit finisher cutscene (plays after the last Silah Oyunu kill) =====
// Staged inside the real arena: a rotated group is laid along a clear lane. All motion is scripted from one clock T.
const FIN_Y = 0, FIN_X0 = 17, FIN_Z0 = -.5;
function finKnife() {
  const g = new THREE.Group(), bm = new THREE.MeshStandardMaterial({ color: 0xeaf2f8, roughness: .12, metalness: .95, emissive: 0x335577, emissiveIntensity: .5 }), dk = new THREE.MeshStandardMaterial({ color: 0x15171a, roughness: .5, metalness: .6 });
  const grip = new THREE.Mesh(new THREE.BoxGeometry(.05, .05, .2), dk); grip.position.z = .06; g.add(grip);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(.04, .009, 8, 16), bm); ring.position.z = .18; ring.rotation.y = Math.PI / 2; g.add(ring);
  const R = .24, N = 8;
  for (let i = 0; i < N; i++) { const a = i * .26, w = lerp(.07, .01, i / N), m = new THREE.Mesh(new THREE.BoxGeometry(.012, w, .07), bm); m.position.set(0, -R * (1 - Math.cos(a)), -R * Math.sin(a) - .04); m.rotation.x = -a - .12; g.add(m); }
  return g;
}
function finGun() {
  const g = new THREE.Group(), m = EM.gun;
  const a = new THREE.Mesh(new THREE.BoxGeometry(.07, .1, .5), m); a.position.z = .05; g.add(a);
  const b = new THREE.Mesh(new THREE.BoxGeometry(.04, .04, .45), m); b.position.set(0, .02, .52); g.add(b);
  const c = new THREE.Mesh(new THREE.BoxGeometry(.06, .16, .08), m); c.position.set(0, -.1, .1); g.add(c);
  return g;
}
function finActor(stg, friendly, x, z, yaw) {
  const b = friendly ? friendlySoldier() : buildSoldier('soldier');
  b.g.children[b.g.children.length - 1].visible = false;               // the built-in rifle: we carry our own so it can be cut off
  const r = new THREE.Group(), h = new THREE.Group(); r.add(h); h.add(b.g);
  const a = { r, h, g: b.g, legs: b.legs, arms: b.arms, head: [b.g.children[2], b.g.children[3]], ph: Math.random() * 6, ph0: Math.random() * 6, x, z, yaw, y: 0, fall: 0, fallDir: 0, fallT0: 1e9, fallDur: .9, dead: false, speed: 0, gun: null, rc: 0, ox: 0, oz: 0, lean: 0, roll: 0, flip: 0, look: 0, nod: 0, rise: 0, kn: null };
  if (!friendly) { a.gun = finGun(); a.gun.position.set(.08, 1.2, .55); b.g.add(a.gun); }
  stg.add(r); return a;
}
function finPlace(a, T, dt) {
  if (a.kn) { const k = pe(T, a.kn.t0, a.kn.t0 + a.kn.dur); a.ox = a.kn.dx * a.kn.dist * k; a.oz = a.kn.dz * a.kn.dist * k; }
  a.r.position.set(a.x + a.ox, FIN_Y + a.y, a.z + a.oz); a.r.rotation.y = a.yaw;
  let fr = 0, k = 0; if (a.fallDir) { k = pe(T, a.fallT0, a.fallT0 + a.fallDur); fr = a.fallDir * 1.5 * k * (1 - .65 * a.rise); }
  a.rc = Math.max(0, a.rc - dt * 7);
  a.h.rotation.set(fr + a.lean + a.flip - a.rc * .07 + Math.sin(T * 1.7 + a.ph0) * .01, 0, a.roll); a.h.position.y = -.05 * k * (1 - a.rise);
  a.ph += dt * a.speed * 2.2; const sw = Math.sin(a.ph) * .85 * Math.min(1, a.speed / 3);
  if (!a.dead) { a.legs[0].rotation.x = sw; a.legs[1].rotation.x = -sw; } else { a.legs[0].rotation.x = -.5 * k; a.legs[1].rotation.x = -1.0 * k; }
  a.head[0].rotation.set(a.nod, a.look, 0); a.head[1].rotation.set(a.nod, a.look, 0);
}
function finAim(a, k, ang) { const x = lerp(-1.2, ang || -1.55, k) + a.rc * .12; a.arms[0].rotation.x = x; a.arms[1].rotation.x = x; }
const yawTo = (ax, az, bx, bz) => Math.atan2(bx - ax, bz - az);

function startFinisher(done) {
  beginCine(); $('skip').hidden = false; $('fade').style.transition = 'none'; $('fade').style.opacity = 1;
  for (const a of allies) a.g.visible = false;
  const px0 = P.pos.x, pz0 = P.pos.z, bul = [], fxs = [], STG = new THREE.Group();
  STG.position.set(FIN_X0, 0, FIN_Z0); STG.rotation.y = -Math.PI / 2; scene.add(STG); STG.updateMatrixWorld(true);
  // clear the arena's props out of the lane for the cutscene (the walls are rebuilt so it still reads as the same arena)
  const hid = [], walls = [];
  if (typeof PIT_PROP0 === 'number' && MAP.pit) {
    for (let i = PIT_PROP0; i < WORLD.length; i++) if (WORLD[i].visible) { WORLD[i].visible = false; hid.push(WORLD[i]); }
    for (const [x0, z0, x1, z1] of [[-40.9, -28.9, 40.9, -28], [-40.9, 28, 40.9, 28.9], [-40.9, -28, -40, 28], [40, -28, 40.9, 28]]) { const w = new THREE.Mesh(new THREE.BoxGeometry(x1 - x0, 6.5, z1 - z0), MATS.concrete); w.position.set((x0 + x1) / 2, 3.25, (z0 + z1) / 2); scene.add(w); walls.push(w); }
  }
  const gradeOld = canvas.style.filter;
  const wash = document.createElement('div'); wash.style.cssText = 'position:fixed;inset:0;z-index:37;pointer-events:none;background:#fff;opacity:0'; document.body.appendChild(wash);
  const vig = document.createElement('div'); vig.style.cssText = 'position:fixed;inset:0;z-index:36;pointer-events:none;background:radial-gradient(ellipse at center,rgba(0,0,0,0) 55%,rgba(0,0,0,.55) 100%)'; document.body.appendChild(vig);
  const V = (x, y, z) => new THREE.Vector3(x, y, z), W = (x, y, z) => STG.localToWorld(V(x, y, z));
  const fxBlood = (x, y, z) => { const w = W(x, y, z); bloodPuff(w.x, w.y, w.z); }, fxDust = (x, y, z, n, col, s, v) => { const w = W(x, y, z); dustPuff(w.x, w.y, w.z, n, col, s, v); }, fxSpark = (x, y, z, n, v) => { const w = W(x, y, z); sparks(w.x, w.y, w.z, n, v); }, fxMuz = (x, y, z, s) => { const w = W(x, y, z); muzzleFx(w.x, w.y, w.z, s); };
  // actors
  const H = finActor(STG, true, 0, 12, Math.PI), Aa = finActor(STG, false, 0, -4, 0), Bb = finActor(STG, false, -6, -9, 0), Cc = finActor(STG, false, 1, -15, 0), Dd = finActor(STG, false, 6, -12, 0), Ee = finActor(STG, false, -11, -13, 0);
  const enemies2 = [Aa, Bb, Cc, Dd, Ee];
  const knife = finKnife(); knife.rotation.x = -Math.PI / 2; knife.position.set(0, -.5, 0); H.arms[1].add(knife);
  const tip = finKnife(); tip.scale.setScalar(.8); tip.visible = false; STG.add(tip);
  const flyK = finKnife(); flyK.visible = false; STG.add(flyK);
  const F = finActor(STG, false, 7, -9, Math.PI); F.r.visible = false; const M = Cc;
  // sword trail ribbon (additive, fades to the tail)
  const TN = 16, tpos = new Float32Array(TN * 6), tcol = new Float32Array(TN * 6), tgeo = new THREE.BufferGeometry(), tidx = [];
  for (let i = 0; i < TN - 1; i++) { const a = i * 2; tidx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); }
  tgeo.setAttribute('position', new THREE.BufferAttribute(tpos, 3)); tgeo.setAttribute('color', new THREE.BufferAttribute(tcol, 3)); tgeo.setIndex(tidx);
  const trail = new THREE.Mesh(tgeo, new THREE.MeshBasicMaterial({ vertexColors: true, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide })); trail.frustumCulled = false; STG.add(trail);
  const tsamples = [], tipL = V(0, -.3, -.27), baseL = V(0, 0, -.05);
  // state
  const S = { T: 0, ts: 1, done: {}, snap: true, mode: '', cp: V(0, 0, 0), cl: V(0, 0, 0), fov: 0, vis: true, hit: 0, tFade: -1, sh: 0, stop: 0, punch: 0, bulletRef: null, flight: null, trailOn: false, dustT: 0, hitAt: 0 };
  const once = (k, cond, fn) => { if (!S.done[k] && cond) { S.done[k] = true; fn(); } };
  const muz = a => V(a.x + a.ox + Math.sin(a.yaw) * 1.05 + Math.cos(a.yaw) * .08, FIN_Y + 1.28, a.z + a.oz + Math.cos(a.yaw) * 1.05 - Math.sin(a.yaw) * .08);
  const chest = (a, dy) => V(a.x + a.ox, FIN_Y + (a.y || 0) + (dy || 1.25), a.z + a.oz);
  const shoot = (from, to, speed, col, big) => {
    const dir = to.clone().sub(from), d = dir.length(); dir.divideScalar(d || 1);
    const m = new THREE.Mesh(new THREE.BoxGeometry(big ? .07 : .035, big ? .07 : .035, big ? .5 : .6), new THREE.MeshBasicMaterial({ color: col })); m.position.copy(from); STG.add(m); m.lookAt(STG.localToWorld(from.clone().add(dir)));
    const tr = new THREE.Mesh(new THREE.BoxGeometry(.016, .016, big ? 3 : 2), new THREE.MeshBasicMaterial({ color: col, transparent: true, opacity: .45, blending: THREE.AdditiveBlending, depthWrite: false })); tr.position.z = big ? -1.6 : -1.2; m.add(tr);
    const b = { m, v: dir.multiplyScalar(speed), t: 0, life: 3 }; bul.push(b); return b;
  };
  const arcFx = (p, yaw, tilt, size, col) => {      // curved slash: a partial torus that expands and fades
    const m = new THREE.Mesh(new THREE.TorusGeometry(size, size * .035, 5, 26, Math.PI * 1.15), new THREE.MeshBasicMaterial({ color: col || 0xffffff, transparent: true, opacity: 1, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide }));
    m.position.copy(p); m.rotation.set(tilt, yaw, rand(-.3, .3), 'YXZ'); STG.add(m); fxs.push({ m, t: 0, life: .32, arc: true });
  };
  const ring = (p, col) => { const m = new THREE.Mesh(new THREE.TorusGeometry(.3, .02, 6, 24), new THREE.MeshBasicMaterial({ color: col || 0xffffff, transparent: true, opacity: .9, blending: THREE.AdditiveBlending, depthWrite: false })); m.position.copy(p); m.rotation.x = Math.PI / 2; STG.add(m); fxs.push({ m, t: 0, life: .45, ring: true }); };
  const whiteFlash = k => { S.wash = k; };
  const impact = (p, big) => { fxSpark(p.x, p.y, p.z, big ? 26 : 12, big ? 7 : 4); ring(p, 0xfff0d0); S.stop = big ? .11 : .07; S.sh = Math.max(S.sh, big ? .14 : .08); S.punch = big ? 7 : 4; whiteFlash(big ? .5 : .25); };
  const slash = (a, tilt) => { const p = V(a.x + a.ox + Math.sin(a.yaw) * .85, FIN_Y + 1.3 + (a.y || 0), a.z + a.oz + Math.cos(a.yaw) * .85); arcFx(p, a.yaw + Math.PI / 2, tilt, .95, 0xcfeaff); SND.whoosh(); S.trailOn = true; S.trailT = S.T + .5; };
  const die = (a, dir, T, dur, away) => { if (a.dead) return; a.dead = true; a.fallDir = dir; a.fallT0 = T + .12; a.fallDur = dur || .9; fxBlood(a.x + a.ox, FIN_Y + 1.3, a.z + a.oz); SND.kill(); if (away) a.kn = { dx: away.x, dz: away.z, dist: 1.1, t0: T, dur: .7 }; a.rc = 1.5; };
  const puff = (x, z, n) => fxDust(x, FIN_Y + 1, z, n || 14, [.9, .9, .95], 1.4, 4);
  const splitBullet = b => {
    if (!b || bul.indexOf(b) < 0) return; const p = b.m.position.clone(), dir = b.v.clone().normalize(), side = V(dir.z, 0, -dir.x).normalize(); bul.splice(bul.indexOf(b), 1); STG.remove(b.m);
    for (const sg of [-1, 1]) { const m = new THREE.Mesh(new THREE.BoxGeometry(.05, .05, .25), new THREE.MeshBasicMaterial({ color: 0xffb060 })); m.position.copy(p); m.lookAt(STG.localToWorld(p.clone().add(dir))); STG.add(m); bul.push({ m, v: dir.clone().multiplyScalar(6).add(side.clone().multiplyScalar(sg * 4)).add(V(0, sg * 1.2, 0)), t: 0, life: 1.5 }); }
    arcFx(p, H.yaw + Math.PI / 2, .5, .8, 0xffffff); fxSpark(p.x, p.y, p.z, 24, 6); SND.hit(true); S.sh = .1; S.punch = 5;
  };
  const camSet = (px, py, pz, lx, ly, lz, fov, sm, dt) => {
    const p = W(px, py, pz), l = W(lx, ly, lz);
    if (S.snap || !sm) { S.cp.copy(p); S.cl.copy(l); } else { const k = 1 - Math.exp(-dt * sm); S.cp.lerp(p, k); S.cl.lerp(l, k); }
    camera.position.copy(S.cp); const sh = S.sh + .004; camera.position.add(V(rand(-sh, sh), rand(-sh, sh), rand(-sh, sh))); camLookAt(S.cl.x, S.cl.y, S.cl.z);
    const f = fov - S.punch; if (Math.abs(S.fov - f) > .05) { S.fov = f; camera.fov = f; camera.updateProjectionMatrix(); }
  };
  const mode = m => { if (S.mode !== m) { S.mode = m; S.snap = true; } };
  const cleanup = () => {
    STG.traverse(o => { if (o.geometry && o.geometry.dispose && o !== trail) { } }); scene.remove(STG); for (const m of hid) m.visible = true; for (const w of walls) scene.remove(w); wash.remove(); vig.remove(); canvas.style.filter = gradeOld;
    VMS.forEach(m => m.visible = false); LH.visible = false; P.pos.x = px0; P.pos.z = pz0;
  };
  const finish = () => { cleanup(); C = null; try { done(); } catch (e) { reportErr(e); winGame(); } };
  const tsOf = T => T < 6.9 ? 1 : T < 7.5 ? .1 : T < 8.2 ? lerp(.1, 1, (T - 7.5) / .7) : T < 8.4 ? 1 : T < 9.7 ? .55 : T < 19.7 ? 1 : T < 21.7 ? .5 : T < 33.9 ? 1 : T < 34.9 ? .2 : 1;
  // choreography geometry
  const A = Aa, B = Bb, Hs = { x: .3, z: -3.25 };
  const Bdir = yawTo(B.x, B.z, Hs.x, Hs.z), Bf = { x: B.x + Math.sin(Bdir) * 1.15, z: B.z + Math.cos(Bdir) * 1.15 }, HB = { x: B.x - Math.sin(Bdir) * .95, z: B.z - Math.cos(Bdir) * .95 };
  const Cs = { x: 0, z: -20.5 }, Ds = { x: 10, z: -15 }, Es = { x: -10, z: -15 };           // M (the watching soldier) in the back, D on his left, E on his right
  const Hw = { x: 0, z: -9 }, Hm = { x: 0, z: -13.5 };
  const eu = (() => { const dx = Hm.x - Es.x, dz = Hm.z - Es.z, d = Math.hypot(dx, dz); return { x: dx / d, z: dz / d }; })(), hyE = Math.atan2(eu.x, eu.z);
  const HE = { x: Es.x - eu.x * .75 - .3 * Math.cos(hyE), z: Es.z - eu.z * .75 + .3 * Math.sin(hyE), yaw: hyE };            // behind E
  const du = (() => { const dx = Hm.x - Ds.x, dz = Hm.z - Ds.z, d = Math.hypot(dx, dz); return { x: dx / d, z: dz / d }; })();
  const HD = { x: Ds.x + du.x * 1.15, z: Ds.z + du.z * 1.15, yaw: Math.atan2(-du.x, -du.z) };                                // in front of D
  const L0 = Math.hypot(HD.x - Cs.x, HD.z - Cs.z), WU = { x: (Cs.x - HD.x) / L0, z: (Cs.z - HD.z) / L0 }, HEnd = { x: HD.x + WU.x * (L0 - 1.1), z: HD.z + WU.z * (L0 - 1.1) };
  const BLK = [26.2, 28.0, 29.8, 31.6];                                                                                         // the watching soldier blinks
  let hx = 0, hz = 12, hyaw = Math.PI, hy = 0, hspd = 0;
  // instant dodges: the hero blinks sideways the moment a bullet arrives and a black silhouette of his last pose stays behind
  const EV1 = [[8.72, 1.1], [8.92, -1.1], [9.12, 1.1], [9.32, 0]], EV2 = [[19.9, 1.25], [20.1, -1.25], [20.3, 1.25], [20.5, -1.25], [20.7, 1.25], [20.9, -1.25], [21.1, 1.25], [21.3, 0]];
  const base1 = Tq => { const k = prog(Tq, 8.4, 9.7), x = lerp(.3, Bf.x, k), z = lerp(Hs.z, Bf.z, k); return { x, z, yy: yawTo(x, z, B.x, B.z) }; };
  const base2 = Tq => { const k = prog(Tq, 19.7, 21.7), e = k * k * (3 - 2 * k), x = lerp(Hw.x, Hm.x, e), z = lerp(Hw.z, Hm.z, e); return { x, z, yy: yawTo(x, z, Cs.x, Cs.z) }; };
  const dLat = (ev, Tq) => { let v = 0; for (const e of ev) if (Tq >= e[0]) v = e[1]; return v; };
  const posAt = (bs, Tq, lat) => { const b = bs(Tq); return { x: b.x + Math.cos(b.yy) * lat, z: b.z - Math.sin(b.yy) * lat, yy: b.yy }; };
  const ghosts = [];
  const ghost = () => {
    H.r.updateMatrixWorld(true); const g = H.r.clone(true), mat = new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: .9, depthWrite: false });
    g.traverse(o => { if (o.isMesh) o.material = mat; }); STG.add(g); ghosts.push({ g, mat, t: 0 });
  };
  const cutGun = a => {
    const g = a.gun; if (!g) return; const wp = V(0, 0, 0); g.getWorldPosition(wp); a.g.remove(g); const lp = STG.worldToLocal(wp.clone()); g.position.copy(lp); g.rotation.set(0, a.yaw, 0); STG.add(g);
    const g2 = finGun(); g2.position.copy(lp); g2.rotation.set(0, a.yaw, 0); STG.add(g2); g.scale.z = .5; g2.scale.z = .5; g.position.x += Math.sin(a.yaw) * .15; g.position.z += Math.cos(a.yaw) * .15; g2.position.x -= Math.sin(a.yaw) * .2; g2.position.z -= Math.cos(a.yaw) * .2;
    (S.gunParts = S.gunParts || []).push({ m: g, v: V(1.2, 1.5, .3), w: V(3, 1, 2) }, { m: g2, v: V(-1.2, 1.8, -.3), w: V(-2, 2, -3) }); a.gun = null;
  };
  const dodgePhase = (key, ev, bs, shooters, T) => {
    for (let i = 0; i < ev.length; i++) {
      const te = ev[i][0], prev = i ? ev[i - 1][1] : 0, fl = .11;
      once(key + 'f' + i, T > te - fl, () => { const p = posAt(bs, te, prev); for (const s of shooters()) { const from = muz(s), to = V(p.x + rand(-.06, .06), FIN_Y + 1.2 + rand(-.2, .2), p.z + rand(-.06, .06)), d = from.distanceTo(to); shoot(from, to, d / fl, 0xffc070); fxMuz(from.x, from.y, from.z, .9); SND.shot('rifle', 0, 0); s.rc = 1; } });
      once(key + 'd' + i, T >= te, () => { ghost(); fxDust(H.x, FIN_Y + 1, H.z, 10, [.12, .12, .14], 1.1, 2.5); ring(V(H.x, FIN_Y + .1, H.z), 0x8899aa); SND.whiz(0, 0); S.sh = Math.max(S.sh, .05); S.dodgeAt = te; S.dodgeS = Math.sign(ev[i][1] - prev) || 1; });
    }
  };
  canvas.style.filter = 'contrast(1.08) saturate(1.12)';

  C = { kind: 'finisher', t: 0, end: 200 };
  C.update = dt0 => {
    try {
      C.t += dt0; if (C.t >= C.end || S.T > 60) { finish(); return; }
      S.ts = tsOf(S.T); if (S.stop > 0) S.stop -= dt0; const dt = dt0 * S.ts * (S.stop > 0 ? .04 : 1); const T = S.T += dt;
      P.pos.x = 0; P.pos.z = 0; skyMesh.position.copy(camera.position); S.sh = Math.max(0, S.sh - dt0 * .7); S.punch = Math.max(0, S.punch - dt0 * 14);
      S.wash = Math.max(0, (S.wash || 0) - dt0 * 3.2); wash.style.opacity = S.wash.toFixed(2);
      const slow = S.ts < .6 ? 1 : 0; S.slowK = lerp(S.slowK || 0, slow, Math.min(1, dt0 * 4)); canvas.style.filter = 'contrast(' + (1.08 + S.slowK * .14).toFixed(2) + ') saturate(' + (1.12 - S.slowK * .35).toFixed(2) + ') brightness(' + (1 + S.slowK * .04).toFixed(2) + ')';
      // ---------- hero ----------
      H.arms[0].rotation.x = -1.2; H.arms[0].rotation.z = .25; H.arms[1].rotation.z = -.25; let armR = -1.2; hspd = 0; hy = 0; H.lean = 0; H.roll = 0; H.flip = 0; H.look = 0; H.nod = 0; S.vis = true;
      if (T < 3.2) { const k = pe(T, 0, 3.2); hx = lerp(0, .3, k); hz = lerp(12, Hs.z, T / 3.2); hyaw = Math.PI; hspd = 5.4; armR = -1.1 + Math.sin(T * 9) * .3; H.arms[0].rotation.x = -1.1 - Math.sin(T * 9) * .3; hy = Math.abs(Math.sin(T * 9)) * .05; H.lean = .2; if (T > 2.4) armR = lerp(armR, -2.7, pe(T, 2.4, 3.1)); }
      else if (T < 4.8) { hx = .3; hz = Hs.z; hyaw = Math.PI; armR = T < 3.34 ? lerp(-2.7, -1.95, pe(T, 3.15, 3.34)) : T < 4.4 ? -1.95 : lerp(-1.95, -1.2, pe(T, 4.4, 4.8)); H.lean = T < 3.3 ? .1 : .25 * (1 - pe(T, 3.4, 4.2)); }
      else if (T < 8.4) { hx = .3; hz = Hs.z; hyaw = lerp(Math.PI, yawTo(.3, Hs.z, B.x, B.z), pe(T, 4.8, 5.8)); armR = -1.3; H.look = 0; }
      else if (T < 9.7) { const p = posAt(base1, T, dLat(EV1, T)); hx = p.x; hz = p.z; hyaw = p.yy; hspd = 6; hy = Math.abs(Math.sin(T * 9)) * .05; H.lean = .22; armR = -1.3; dodgePhase('p4', EV1, base1, () => [B], T); }
      else if (T < 11.0) { hx = Bf.x; hz = Bf.z; hyaw = yawTo(hx, hz, B.x, B.z); armR = T < 9.9 ? lerp(-1.3, -2.6, prog(T, 9.7, 9.9)) : T < 10.1 ? lerp(-2.6, -1.8, prog(T, 9.9, 10.1)) : T < 10.35 ? -2.6 : T < 10.55 ? lerp(-2.6, -1.9, prog(T, 10.35, 10.55)) : -1.9; H.lean = T > 10.3 && T < 10.7 ? .15 : 0; if (T > 10.9) S.vis = false; }
      else if (T < 12.5) { hx = HB.x; hz = HB.z; hyaw = yawTo(HB.x, HB.z, B.x, B.z); armR = T < 11.3 ? lerp(-2.0, -2.6, prog(T, 11.0, 11.25)) : T < 11.4 ? lerp(-2.6, -1.6, prog(T, 11.3, 11.4)) : T < 12.4 ? -1.6 : -1.3; H.lean = T > 11.3 ? .2 : 0; }
      else if (T < 13.9) { hx = HB.x; hz = HB.z; armR = -1.2; const k = pe(T, 12.5, 13.9); hyaw = lerp(yawTo(HB.x, HB.z, B.x, B.z), yawTo(HB.x, HB.z, Cs.x, Cs.z), k); }
      else if (T < 19.7) { const k = prog(T, 13.9, 19.7); hx = lerp(HB.x, Hw.x, k); hz = lerp(HB.z, Hw.z, k); hyaw = yawTo(hx, hz, Cs.x, Cs.z); hspd = 1.6; armR = -1.2 + Math.sin(T * 3) * .1; H.arms[0].rotation.x = -1.2 - Math.sin(T * 3) * .1; H.nod = .0; }
      else if (T < 21.7) { // run through the barrage with instant blink-dodges
        const p = posAt(base2, T, dLat(EV2, T)); hx = p.x; hz = p.z; hyaw = p.yy; hspd = 6; armR = -1.5; H.lean = .2; dodgePhase('p8', EV2, base2, () => [Cc, Dd, Ee], T);
      }
      else if (T < 22.0) { hx = Hm.x; hz = Hm.z; hyaw = angLerp(yawTo(Hm.x, Hm.z, Cs.x, Cs.z), HE.yaw, pe(T, 21.7, 22.0)); armR = -1.3; }
      else if (T < 22.1) { once('tele1', true, () => { ghost(); puff(Hm.x, Hm.z, 16); ring(V(Hm.x, FIN_Y + .1, Hm.z), 0xaaddff); SND.whoosh(); whiteFlash(.3); }); S.vis = false; hx = Hm.x; hz = Hm.z; hyaw = HE.yaw; }
      else if (T < 23.1) { // behind the right-hand soldier: arms crossed in mid-air, then the karambit comes down on his head
        once('tele1b', true, () => { puff(HE.x, HE.z, 14); ring(V(HE.x, FIN_Y + .1, HE.z), 0xaaddff); SND.whoosh(); });
        const air = T < 22.45; hx = HE.x; hz = HE.z; hyaw = HE.yaw;
        hy = air ? 1.4 + Math.sin((T - 22.1) * 8) * .08 : 1.4 * (1 - pe(T, 22.45, 22.58)); H.lean = air ? -.12 : .3 * (1 - pe(T, 22.7, 23.0));
        H.arms[0].rotation.x = air ? -2.5 : -1.3; H.arms[0].rotation.z = air ? 1.1 : .25; H.arms[1].rotation.z = air ? -1.1 : -.25;
        armR = air ? -2.5 : T < 23.0 ? lerp(-2.7, -1.95, pe(T, 22.45, 22.58)) : lerp(-1.95, -1.3, pe(T, 23.0, 23.1));
      }
      else if (T < 23.3) { once('tele2', true, () => { ghost(); puff(HE.x, HE.z, 16); ring(V(HE.x, FIN_Y + .1, HE.z), 0xaaddff); SND.whoosh(); whiteFlash(.3); }); S.vis = false; hx = HD.x; hz = HD.z; hyaw = HD.yaw; }
      else if (T < 24.6) { // in front of the left-hand soldier: cut his rifle in two, then one stab
        once('tele2b', true, () => { puff(HD.x, HD.z, 14); ring(V(HD.x, FIN_Y + .1, HD.z), 0xaaddff); SND.whoosh(); });
        const lunge = .45 * pe(T, 23.88, 23.98) * (1 - pe(T, 24.2, 24.5)); hx = HD.x + Math.sin(HD.yaw) * lunge; hz = HD.z + Math.cos(HD.yaw) * lunge; hyaw = HD.yaw;
        armR = T < 23.35 ? -2.3 : T < 23.58 ? lerp(-2.3, -1.4, pe(T, 23.35, 23.58)) : T < 23.85 ? lerp(-1.4, -2.0, pe(T, 23.58, 23.85)) : T < 23.98 ? lerp(-2.0, -1.55, pe(T, 23.85, 23.98)) : T < 24.35 ? -1.55 : lerp(-1.55, -1.3, pe(T, 24.35, 24.6));
        H.lean = T > 23.85 && T < 24.3 ? .3 : 0;
      }
      else if (T < 32.0) { // the very slow walk: he only gets closer for real whenever the soldier blinks
        let s = .22 * (T - 24.6); const J = [2.4, 2.4, 2.4]; for (let i = 0; i < 3; i++) if (T >= BLK[i] + .12) s += J[i]; if (T >= BLK[3] + .12) s = L0 - 1.1;
        hx = HD.x + WU.x * s; hz = HD.z + WU.z * s; hyaw = yawTo(hx, hz, Cs.x, Cs.z); hspd = T >= BLK[3] + .12 ? 0 : .7; armR = -1.3 + Math.sin(T * 1.4) * .05; H.arms[0].rotation.x = -1.2 - Math.sin(T * 1.4) * .08;
        if (T > 31.75) { const u = pe(T, 31.75, 32.0); armR = lerp(-.9, -2.6, u); H.arms[1].rotation.z = lerp(.75, -1.3, u); H.lean = .2 * u; once('mSlash', true, () => { S.trailOn = true; S.trailT = T + .4; SND.whoosh(); }); }
      }
      else if (T < 32.6) { hx = HEnd.x; hz = HEnd.z; hyaw = yawTo(hx, hz, Cs.x, Cs.z); armR = lerp(-2.6, -1.3, pe(T, 32.1, 32.6)); H.arms[1].rotation.z = lerp(-1.3, -.25, pe(T, 32.1, 32.6)); }
      else { // the next one: he turns, winds up and throws the karambit
        hx = HEnd.x; hz = HEnd.z; hyaw = angLerp(yawTo(hx, hz, Cs.x, Cs.z), yawTo(hx, hz, F.x, F.z), pe(T, 32.7, 33.3));
        armR = T < 33.6 ? -1.3 : T < 34.05 ? lerp(-1.3, -2.9, pe(T, 33.6, 34.05)) : T < 34.22 ? lerp(-2.9, -1.0, pe(T, 34.05, 34.22)) : -1.0; H.lean = T > 34.05 ? .25 : 0;
      }
      if (S.dodgeAt !== undefined && T - S.dodgeAt < .25 && T < 21.7) { const q = 1 - (T - S.dodgeAt) / .25; H.roll = S.dodgeS * .6 * q; H.lean = .35 * q; }
      H.x = hx; H.z = hz; H.yaw = hyaw; H.y = hy; H.speed = hspd; H.arms[1].rotation.x = armR; H.r.visible = S.vis;
      if (hspd > 3.5) { S.dustT -= dt; if (S.dustT <= 0) { S.dustT = .1; fxDust(hx, FIN_Y + .08, hz, 3, [.78, .78, .8], .8, 1.4); } }
      finPlace(H, T, dt); if (T > 12.4 && T < 12.9) H.legs[0].rotation.x = -1.3 * Math.sin(prog(T, 12.4, 12.9) * Math.PI);
      // ---------- enemies ----------
      for (const e of enemies2) { if (!e.dead) finAim(e, e === B && T > 10.0 ? 0 : 1); else { e.arms[0].rotation.x = -.4; e.arms[1].rotation.x = -.4; } }
      A.yaw = yawTo(A.x, A.z, hx, hz); A.speed = 0;
      once('aDie', T > 3.38, () => { impact(V(0, FIN_Y + 1.58, -3.6), true); arcFx(V(0, FIN_Y + 1.58, -3.5), Math.PI / 2, .4, .7, 0xffffff); die(A, -1, T, 1.0, { x: 0, z: -1 }); SND.hit(true); });
      for (const e of [Dd, Ee]) { if (!e.dead && T < (e === Ee ? 22.0 : 23.1)) e.yaw = yawTo(e.x, e.z, hx, hz); e.look = 0; e.nod = 0; }
      if (!M.dead && T < 21.7 && !(T >= 16.6 && T < 19.7)) M.yaw = yawTo(M.x, M.z, hx, hz); M.look = 0; M.nod = 0;
      // B
      B.lean = 0; B.speed = 0;
      if (T < 12.5) { B.yaw = yawTo(B.x, B.z, T < 11.0 ? hx : HB.x, T < 11.0 ? hz : HB.z); if (T > 10.9) B.yaw = Bdir; } else B.yaw = Bdir;
      if (T > 6.5 && T < 12.5 && !B.dead) finAim(B, pe(T, 6.2, 6.9), -1.58);
      if (T > 8.3 && T < 9.7) B.speed = -1.5 * 0;                                         // (B holds ground while firing)
      if (T > 9.3 && T < 9.9 && !B.dead) { B.lean = -.12 * Math.sin(prog(T, 9.3, 9.9) * Math.PI); }  // flinches as the hero closes in
      if (T > 10.35 && T < 11.0) B.lean = -.75 * Math.sin(prog(T, 10.35, 10.75) * Math.PI);          // limbo under the head cut
      once('bFire', T > 6.9, () => { const from = muz(B), to = chest(H); const d = from.distanceTo(to); S.bulletRef = shoot(from, to, d / .36, 0xffb060, true); fxMuz(from.x, from.y, from.z, 1.2); B.rc = 1.5; SND.shot('rifle', 0, 0); });
      once('split', T > 7.2, () => { splitBullet(S.bulletRef); S.splitT = T; });
      if (T > 6.95 && T < 7.3) { armR = lerp(-2.6, -1.3, prog(T, 7.0, 7.2)); H.arms[1].rotation.x = armR; if (T > 7.0 && T < 7.25) H.lean = .15; }
      once('gunCut', T > 9.95, () => {
        slash(H, -.3); impact(chest(B, 1.2), false); const g = B.gun; if (!g) return; const wp = V(0, 0, 0); g.getWorldPosition(wp); B.g.remove(g); const lp = STG.worldToLocal(wp.clone()); g.position.copy(lp); g.rotation.set(0, B.yaw, 0); STG.add(g);
        const g2 = finGun(); g2.position.copy(lp); g2.rotation.set(0, B.yaw, 0); STG.add(g2); g.scale.z = .5; g2.scale.z = .5; g.position.x += Math.sin(B.yaw) * .15; g.position.z += Math.cos(B.yaw) * .15; g2.position.x -= Math.sin(B.yaw) * .2; g2.position.z -= Math.cos(B.yaw) * .2;
        S.gunParts = [{ m: g, v: V(1.2, 1.5, .3), w: V(3, 1, 2) }, { m: g2, v: V(-1.2, 1.8, -.3), w: V(-2, 2, -3) }]; });
      if (S.gunParts) for (const p of S.gunParts) { p.v.y -= 9 * dt; p.m.position.addScaledVector(p.v, dt); p.m.rotation.x += p.w.x * dt; p.m.rotation.y += p.w.y * dt; p.m.rotation.z += p.w.z * dt; if (p.m.position.y < FIN_Y + .1) { p.m.position.y = FIN_Y + .1; p.v.set(0, 0, 0); p.w.set(0, 0, 0); } }
      once('gunNull', T > 10.0, () => { B.gun = null; });
      once('tele', T > 10.9, () => { puff(Bf.x, Bf.z, 18); puff(HB.x, HB.z, 18); ring(V(Bf.x, FIN_Y + .1, Bf.z), 0xaaddff); ring(V(HB.x, FIN_Y + .1, HB.z), 0xaaddff); SND.whoosh(); whiteFlash(.35); });
      once('stab', T > 11.38, () => { tip.visible = true; fxBlood(B.x, FIN_Y + 1.1, B.z); impact(chest(B, 1.05), true); B.rc = 1.5; });
      if (tip.visible) { const f = { x: Math.sin(Bdir), z: Math.cos(Bdir) }; const out = pe(T, 11.38, 11.6); tip.position.set(B.x + f.x * (.05 + .55 * out), FIN_Y + 1.05, B.z + f.z * (.05 + .55 * out)); tip.rotation.set(0, Bdir, 0); if (T > 12.4) tip.visible = false; if (T > 11.5 && T < 12.3 && Math.random() < .3) fxBlood(B.x + f.x * .3, FIN_Y + 1.05, B.z + f.z * .3); }
      once('kick', T > 12.55, () => { B.dead = true; B.fallDir = 1; B.fallT0 = T; B.fallDur = .8; B.kn = { dx: Math.sin(Bdir), dz: Math.cos(Bdir), dist: 2.4, t0: T, dur: .9 }; impact(chest(B, .9), false); fxDust(B.x, FIN_Y + .2, B.z, 8, [.8, .8, .8], 1, 2); });
      // C, D, E step back, glance at each other, then take a stand
      if (T > 13.0 && T < 14.4 && !Cc.dead) { const k = pe(T, 13.0, 14.4); Cc.x = lerp(1, Cs.x, k); Cc.z = lerp(-15, Cs.z, k); Dd.x = lerp(6, Ds.x, k); Dd.z = lerp(-12, Ds.z, k); Ee.x = lerp(-11, Es.x, k); Ee.z = lerp(-13, Es.z, k); for (const e of [Cc, Dd, Ee]) e.speed = -2.2; }
      else if (!Cc.dead) { if (T >= 14.4) { Cc.x = Cs.x; Cc.z = Cs.z; Dd.x = Ds.x; Dd.z = Ds.z; Ee.x = Es.x; Ee.z = Es.z; } for (const e of [Cc, Dd, Ee]) e.speed = 0; }
      if (T > 14.4 && T < 16.6) { const q = Math.sin(prog(T, 14.4, 16.6) * Math.PI * 2); Dd.look = q * .6; Ee.look = -q * .6; Dd.nod = Math.max(0, q) * .15; }
      let cLook = yawTo(Cc.x, Cc.z, hx, hz), cPitch = 0;
      if (T >= 16.6 && T < 19.7) { const hh = yawTo(Cc.x, Cc.z, hx, hz), l = yawTo(Cc.x, Cc.z, Dd.x, Dd.z), r = yawTo(Cc.x, Cc.z, Ee.x, Ee.z);
        if (T < 17.3) cLook = hh; else if (T < 17.9) cLook = angLerp(hh, l, pe(T, 17.3, 17.9)); else if (T < 18.3) { cLook = l; cPitch = Math.sin(prog(T, 17.9, 18.3) * Math.PI * 2) * .1; } else if (T < 18.9) cLook = angLerp(l, r, pe(T, 18.3, 18.9)); else if (T < 19.3) { cLook = r; cPitch = Math.sin(prog(T, 18.9, 19.3) * Math.PI * 2) * .1; } else cLook = angLerp(r, hh, pe(T, 19.3, 19.7));
        if (!Cc.dead) Cc.yaw = cLook; if (T > 17.2 && T < 19.7) { Dd.look = Math.sin(T * 2) * .3; Ee.look = Math.cos(T * 2) * .3; } }
      // barrage
      // the one who survives: raises his rifle at us, then eats a karambit
      // ----- the watching soldier (M): looks around, aims at us with a shaking rifle, blinks -----
      if (T >= 21.7 && !M.dead) { let ty = yawTo(M.x, M.z, hx, hz); if (T >= 22.15 && T < 23.15) ty = yawTo(M.x, M.z, Es.x, Es.z); else if (T >= 23.15 && T < 24.4) ty = yawTo(M.x, M.z, Ds.x, Ds.z); M.yaw = angLerp(M.yaw, ty, 1 - Math.exp(-dt0 * 7)); }
      if (T > 24.3 && !M.dead) { const j = .02 + .05 * prog(T, 24.6, 31.7); M.arms[0].rotation.x += Math.sin(T * 55) * j; M.arms[1].rotation.x += Math.sin(T * 55 + 1) * j; if (M.gun) { M.gun.rotation.x = Math.sin(T * 51) * j * .8; M.gun.rotation.y = Math.cos(T * 47) * j * .8; } }
      once('eDie', T > 22.58, () => { impact(V(Es.x, FIN_Y + 1.58, Es.z), true); arcFx(V(Es.x, FIN_Y + 1.58, Es.z), HE.yaw + Math.PI / 2, .4, .7, 0xffffff); die(Ee, 1, T, 1.0, { x: eu.x, z: eu.z }); S.trailOn = true; S.trailT = T + .3; });
      once('dGun', T > 23.58, () => { slash(H, -.3); impact(chest(Dd, 1.2), false); cutGun(Dd); });
      once('dStab', T > 23.98, () => { slash(H, .15); impact(chest(Dd, 1.1), true); die(Dd, -1, T, .9, { x: Math.sin(HD.yaw), z: Math.cos(HD.yaw) }); });
      once('mDie', T > 31.95, () => { impact(V(M.x, FIN_Y + 1.5, M.z), true); S.punch = 12; S.wash = .8; die(M, -1, T, .9, { x: WU.x, z: WU.z }); });
      // ----- the last soldier shows up, aims from the ground-level camera's view, shoots; the karambit cuts the bullet and reaches him -----
      once('fApp', T > 32.7, () => { F.r.visible = true; puff(F.x, F.z, 18); ring(V(F.x, FIN_Y + .1, F.z), 0xaaddff); SND.whoosh(); });
      F.yaw = yawTo(F.x, F.z, hx, hz); F.speed = 0; if (T > 33.0 && !F.dead) finAim(F, pe(T, 33.0, 33.7), -1.55);
      once('fFire', T > 34.0, () => { const from = muz(F), to = chest(H), d = from.distanceTo(to); S.fBullet = shoot(from, to, d / .5, 0xffb060, true); S.fD = d; fxMuz(from.x, from.y, from.z, 1.3); F.rc = 1.6; SND.shot('rifle', 0, 0); });
      once('throw', T > 34.22, () => { knife.visible = false; flyK.visible = true; const from = V(hx + Math.sin(hyaw) * .7, FIN_Y + 1.6, hz + Math.cos(hyaw) * .7), to = V(F.x + F.ox, FIN_Y + 1.5, F.z + F.oz); S.flight = { from, to, t0: T, dur: Math.max(.25, from.distanceTo(to) / ((S.fD || 12) / .4)) }; SND.whoosh(); S.trailOn = true; S.trailT = T + 1.2; });
      if (S.flight) { const f = S.flight, k = clamp((T - f.t0) / f.dur, 0, 1); flyK.position.lerpVectors(f.from, f.to, k); const dir = f.to.clone().sub(f.from).normalize(); flyK.lookAt(STG.localToWorld(flyK.position.clone().add(dir))); flyK.rotateZ(T * 38);
        if (S.fBullet && !S.done.splitF && bul.indexOf(S.fBullet) >= 0 && flyK.position.distanceTo(S.fBullet.m.position) < .8) { S.done.splitF = true; splitBullet(S.fBullet); S.stop = .12; }
        once('face', k >= 1, () => { flyK.visible = false; fxBlood(f.to.x, f.to.y, f.to.z); impact(f.to, true); S.hitAt = C.t; S.punch = 10; die(F, 1, T, 1.0, { x: Math.sin(F.yaw), z: Math.cos(F.yaw) }); if (S.fBullet && bul.indexOf(S.fBullet) >= 0) splitBullet(S.fBullet); }); }
      // ---------- draw ----------
      for (const e of enemies2.concat([F])) finPlace(e, T, dt);
      for (let i = bul.length - 1; i >= 0; i--) { const b = bul[i]; b.t += dt; b.m.position.addScaledVector(b.v, dt); if (b.t > b.life) { STG.remove(b.m); bul.splice(i, 1); } }
      for (let i = fxs.length - 1; i >= 0; i--) { const f = fxs[i]; f.t += dt0; const k = f.t / f.life; f.m.material.opacity = 1 - k; if (f.ring) f.m.scale.setScalar(1 + k * 5); else f.m.scale.set(1 + k * .5, 1 + k * .5, 1 + k * .5); if (k >= 1) { STG.remove(f.m); fxs.splice(i, 1); } }
      for (let i = ghosts.length - 1; i >= 0; i--) { const g = ghosts[i]; g.t += dt0; g.mat.opacity = .9 * (1 - clamp((g.t - .6) / 1.0, 0, 1)); if (g.t > 1.7) { STG.remove(g.g); g.mat.dispose(); ghosts.splice(i, 1); } }
      // sword trail: sample the blade tip + base each frame while a slash is live
      H.r.updateMatrixWorld(true);
      if (S.trailOn && T > S.trailT) S.trailOn = false;
      const live = S.trailOn && (knife.visible || flyK.visible);
      if (live) { const src = knife.visible ? knife : flyK, a = STG.worldToLocal(src.localToWorld(tipL.clone())), b = STG.worldToLocal(src.localToWorld(baseL.clone())); tsamples.unshift([a, b]); if (tsamples.length > TN) tsamples.pop(); } else if (tsamples.length) tsamples.pop();
      for (let i = 0; i < TN; i++) { const s = tsamples[Math.min(i, Math.max(0, tsamples.length - 1))] || [V(0, -99, 0), V(0, -99, 0)], f = tsamples.length ? 1 - i / TN : 0; tpos.set([s[0].x, s[0].y, s[0].z, s[1].x, s[1].y, s[1].z], i * 6); tcol.set([.55 * f, .85 * f, 1 * f, .15 * f, .3 * f, .5 * f], i * 6); }
      tgeo.attributes.position.needsUpdate = true; tgeo.attributes.color.needsUpdate = true; trail.visible = tsamples.length > 1;
      // ---------- camera ----------
      const ve = 1.62 + FIN_Y, br = Math.sin(C.t * .8) * .06;
      VMS.forEach(m => m.visible = false); LH.visible = false;
      if (T < 1.3) { mode('fps'); camSet(hx, ve + hy, hz, A.x, FIN_Y + 1.5, A.z, 75, 0, dt0); camera.position.y += Math.sin(T * 9) * .05; camera.rotation.z = Math.sin(T * 4.5) * .02; const vm = VMS[8], ud = vm.userData; vm.visible = true; vm.position.copy(ud.hip); vm.position.y += Math.sin(T * 9) * .025 - .02; vm.rotation.set(.05 + Math.sin(T * 9) * .06, .15, 0); ud.fing.forEach(f => f.rotation.z = 0); }
      else if (T < 4.8) { mode('side1'); const pushIn = T < 3.2 ? 0 : pe(T, 3.2, 4.8) * 2.5; camSet(hx + 8.5 - pushIn, FIN_Y + 1.5, hz - (T < 3.2 ? 1.2 : 2.2), hx, FIN_Y + 1.3, hz - (T < 3.2 ? 1.2 : 2.2), T < 3.2 ? 48 : 40, T < 3.4 ? 8 : 3, dt0); }
      else if (T < 6.9) { mode('two'); const push = pe(T, 4.8, 6.9) * 1.5; camSet(hx + 8 - push, FIN_Y + 1.8 - push * .1, (hz + B.z) / 2 + 2.5, (hx + B.x) / 2, FIN_Y + 1.35, (hz + B.z) / 2, 46 - push * 2, 2.5, dt0); }
      else if (T < 7.55 && S.bulletRef && bul.indexOf(S.bulletRef) >= 0) { mode('chase'); const b = S.bulletRef, d = b.v.clone().normalize(); camSet(b.m.position.x - d.x * 1.6 + d.z * .35, b.m.position.y + .22, b.m.position.z - d.z * 1.6 - d.x * .35, hx, FIN_Y + 1.25, hz, 52, 0, dt0); }
      else if (T < 8.4) { mode('side2'); camSet(hx + 6.5, FIN_Y + 1.5, hz - 1.6, hx - 1, FIN_Y + 1.25, hz - 3.2, 42, 5, dt0); }
      else if (T < 9.7) { mode('track'); camSet(hx + 7.5, FIN_Y + 1.5, hz, hx, FIN_Y + 1.2, hz, 48, 6, dt0); }
      else if (T < 11.1) { mode('cut'); camSet(Bf.x + 5.5, FIN_Y + 1.4, (Bf.z + B.z) / 2, (Bf.x + B.x) / 2, FIN_Y + 1.4, (Bf.z + B.z) / 2, 44, 3, dt0); }
      else if (T < 12.5) { mode('belly'); const f = { x: Math.sin(Bdir), z: Math.cos(Bdir) }, push = pe(T, 11.1, 12.4) * .8; camSet(B.x + f.x * (3.2 - push) + f.z * .6, FIN_Y + 1.15, B.z + f.z * (3.2 - push) - f.x * .6, B.x + f.x * .3, FIN_Y + 1.1, B.z + f.z * .3, 38, 4, dt0); }
      else if (T < 16.6) { mode('wide'); camSet(lerp(HB.x, hx, .5) + 11, FIN_Y + 2.2, hz - 1, lerp(B.x, Cs.x, .55), FIN_Y + 1.2, lerp(B.z, Cs.z, .55), 52, 2, dt0); }
      else if (T < 19.7) { mode('pov'); camSet(Cc.x, ve - .02, Cc.z, Cc.x + Math.sin(cLook) * 5, ve - .02 + Math.tan(cPitch) * 5 - .35, Cc.z + Math.cos(cLook) * 5, 70, 0, dt0); camera.rotation.z = Math.sin(T * 7) * .004; }
      else if (T < 21.7) { mode('far'); camSet(hx + 15, FIN_Y + 2.8, hz + 1, hx - .5, FIN_Y + 1.3, hz - 1, 46, 3.5, dt0); }
      else if (T < 32.6) { // seen through the watching soldier's eyes
        mode('povM'); const ex = M.x + M.ox, ez = M.z + M.oz, ey = ve - .02, dist = Math.max(.5, Math.hypot(hx - ex, hz - ez)), pit = Math.atan2(1.25 - ey, dist) * (T < 22.15 || T > 24.3 ? 1 : .35);
        camSet(ex, ey, ez, ex + Math.sin(M.yaw) * 5, ey + Math.tan(pit) * 5, ez + Math.cos(M.yaw) * 5, 70, 0, dt0);
        const tr = (T > 24.3 ? .004 + .009 * prog(T, 24.6, 31.7) : .002); camera.rotation.x += Math.sin(T * 53) * tr; camera.rotation.y += Math.sin(T * 47 + 1) * tr; camera.rotation.z = Math.sin(T * 3) * .004;
        const kn = pe(T, 31.95, 32.12) * (1 - pe(T, 32.12, 32.6)); camera.rotation.x += kn * .5; camera.rotation.z += kn * .25;
      }
      else { // low and behind the new soldier, looking over his shoulder at us
        mode('behindF'); const fx = F.x + F.ox, fz = F.z + F.oz, dx = hx - fx, dz = hz - fz, d = Math.hypot(dx, dz) || 1, ux = dx / d, uz = dz / d, push = pe(T, 32.7, 35.5) * .9;
        camSet(fx - ux * (2.7 - push) - uz * 1.0, FIN_Y + .3, fz - uz * (2.7 - push) + ux * 1.0, hx, FIN_Y + 1.1, hz, 42, 2, dt0);
      }
      S.snap = false;
      // ---------- fade ----------
      let lid = 0; if (T > 24.4 && T < 33.3) { for (const tb of BLK) { const u = T - tb; if (u > 0 && u < .34) lid = Math.max(lid, u < .1 ? u / .1 : u < .17 ? 1 : 1 - (u - .17) / .17); } if (T >= 32.1 && T < 32.6) lid = pe(T, 32.1, 32.5); else if (T >= 32.6) lid = 1 - pe(T, 32.7, 33.25); }
      if (lid !== S.lid) { S.lid = lid; lidsOverlay(lid, 0); }
      const fd = $('fade').style; fd.transition = 'none';
      if (T < 1.0) fd.opacity = 1 - pe(T, .1, 1.0);
      else if (S.done.face) { if (S.tFade < 0) S.tFade = C.t + 1.0; fd.opacity = clamp((C.t - S.tFade) / 3.6, 0, 1); if (C.t - S.tFade > 4.0) { finish(); return; } }
      else fd.opacity = 0;
    } catch (e) { console.log('FIN ERR', e && e.stack); reportErr(e); try { finish(); } catch (e2) { C = null; winGame(); } }
  };
}
