/**
 * BD BLOOD DONATION - Google AdMob & Native Ad Integration
 * Non-intrusive banner ad system supporting both Capacitor native AdMob and Web fallback
 */

// Official Google AdMob Test Ad Unit IDs
const ADMOB_CONFIG = {
  androidBannerId: 'ca-app-pub-3940256099942544/6300978111', // Official Google Test Banner ID
  iosBannerId: 'ca-app-pub-3940256099942544/2934735716',     // Official Google Test Banner ID
  isTesting: true
};

export function renderAdBanner(containerElement) {
  if (!containerElement) return;

  // Check if Capacitor AdMob native plugin is present
  if (window.Capacitor && window.Capacitor.isPluginAvailable('AdMob')) {
    try {
      const { AdMob, BannerAdSize, BannerAdPosition } = window.Capacitor.Plugins;
      AdMob.showBanner({
        adId: ADMOB_CONFIG.androidBannerId,
        adSize: BannerAdSize.BANNER,
        position: BannerAdPosition.BOTTOM_CENTER,
        margin: 60,
        isTesting: true
      }).catch(err => {
        console.log('[Native AdMob banner notice]:', err.message);
        renderWebAdPlaceholder(containerElement);
      });
      return;
    } catch (e) {
      console.warn('[AdMob native initialize notice]:', e.message);
    }
  }

  // Graceful Web / Non-intrusive Banner
  renderWebAdPlaceholder(containerElement);
}

function renderWebAdPlaceholder(containerElement) {
  containerElement.innerHTML = `
    <div class="admob-banner-container" aria-label="Sponsored advertisement banner">
      <div class="admob-badge">বিজ্ঞাপন • Ad</div>
      <div class="admob-content">
        <div class="admob-icon">💉</div>
        <div class="admob-text">
          <strong>রক্তদান মহৎ দান</strong>
          <span>আপনার রক্তের এক ফোঁটা বাঁচাতে পারে একটি মূল্যবান জীবন।</span>
        </div>
        <a href="#/donor-search" class="admob-action-btn">রক্তদাতা খুঁজুন</a>
      </div>
    </div>
  `;
}
