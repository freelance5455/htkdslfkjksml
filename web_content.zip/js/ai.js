/* ai.js — Phase 8: strategic and operational AI for every non-player nation.
   - Personalities (from government + a deterministic twist) and a global difficulty.
   - Strategy: choose wars it can win (coalition strength, hatred, borders, readiness).
   - Operations: pick an objective, gather at a staging province, then strike; defend and retake land.
   - Recruitment: standing armies, composition by need, front-line deployment.
   - Economy: tax policy, fortifying threatened borders, selling surplus, buying shortages.
   - Diplomacy: alliances against threats, appeasement, coalitions against runaway powers.
   Espionage and research AI live in intel.js and tech.js and are driven from here by the same clock. */
(function (G) {
  'use strict';

  const cname = id => G.COUNTRIES[id].name;
  G.DIFFICULTY = {
    easy:   { name: 'Easy',   grace: 240, aggr: 0.9,  income: 0.9,  think: 1.5 },
    normal: { name: 'Normal', grace: 150, aggr: 1.0,  income: 1.0,  think: 1.0 },
    hard:   { name: 'Hard',   grace: 90,  aggr: 1.3,  income: 1.15, think: 0.7 }
  };
  G.DIFF_ORDER = ['easy', 'normal', 'hard'];
  G.diff = function () { return G.DIFFICULTY[(G.state && G.state.difficulty) || 'normal'] || G.DIFFICULTY.normal; };
  G.aiIncomeMult = function (id) { return G.state && id !== G.state.player ? G.diff().income : 1; };

  const BASE_PERSONA = {
    'Fascist State': { aggression: 0.85, caution: 0.25 }, 'Military Junta': { aggression: 0.75, caution: 0.35 },
    'Empire': { aggression: 0.7, caution: 0.4 }, 'Constitutional Monarchy': { aggression: 0.45, caution: 0.55 },
    'Federation': { aggression: 0.4, caution: 0.6 }, 'Republic': { aggression: 0.35, caution: 0.65 },
    'Parliamentary Democracy': { aggression: 0.3, caution: 0.7 },
    'Communist State': { aggression: 0.6, caution: 0.45 }, 'Absolute Monarchy': { aggression: 0.4, caution: 0.55 }
  };
  function label(p) {
    return p.aggression >= 0.8 ? 'Warmonger' : p.aggression >= 0.62 ? 'Expansionist' : p.aggression >= 0.4 ? 'Balanced' : p.aggression >= 0.3 ? 'Defensive' : 'Peaceful';
  }

  G.initAI = function (st, fresh) {
    st.ai = st.ai || {};
    if (!st.difficulty) st.difficulty = 'normal';
    let s = 8088; const rnd = () => { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; return s / 4294967296; };
    for (const id in G.COUNTRIES) {
      const j1 = (rnd() - 0.5) * 0.2, j2 = (rnd() - 0.5) * 0.2;
      if (!st.ai[id]) {
        const b = BASE_PERSONA[G.COUNTRIES[id].gov] || { aggression: 0.5, caution: 0.5 };
        st.ai[id] = { aggression: Math.max(0.1, Math.min(1, b.aggression + j1)), caution: Math.max(0.1, Math.min(1, b.caution + j2)), stage: null, stageSince: 0, plan: null };
      }
      st.ai[id].label = label(st.ai[id]);
    }
  };
  G.aiInfo = function (id) { return G.state.ai && G.state.ai[id]; };

  /* ---------- helpers ---------- */
  const alive = () => Object.keys(G.state.countries).filter(id => !G.state.countries[id].dead);
  function menOf(id) { return G.state.armies.filter(a => a.owner === id).reduce((s, a) => s + G.armySummary(a).men, 0); }
  function power(id) { const c = G.state.countries[id]; return menOf(id) + 0.3 * c.manpower + 150 * (c.provCount || 0); }
  function coalition(id, extraAllies) {
    let p = power(id);
    G.alliesOf(id).forEach(a => { if (!G.isDead(a)) p += 0.6 * power(a); });
    return p;
  }
  function bordering(a, b) {
    const st = G.state;
    return G.provinces.some(p => !p.sea && st.owners[p.id] === a && p.adj.some(n => st.owners[n] === b));
  }
  function landShare(id) {
    const st = G.state, tot = G.provinces.filter(p => !p.sea).length;
    return (st.countries[id].provCount || 0) / tot;
  }
  const hostileAt = (prov, id) => G.armiesAt(prov).filter(x => x.owner !== id && G.atWar(x.owner, id));

  /* ---------- strategy: whom to attack ---------- */
  function ready(id) {
    const c = G.state.countries[id];
    return c.treasury > 250 && c.manpower > 4000 && !c.starving && !c.broke && menOf(id) > 2500;
  }
  function chooseWar(id) {
    const st = G.state, ai = st.ai[id], D = G.diff();
    if (st.day < D.grace) return;
    if (st.day < (ai.nextWar || 0)) return;
    const wars = G.warsOf(id), maxWars = ai.aggression > 0.8 ? 2 : 1;
    if (wars.length >= maxWars || !ready(id)) return;
    // never open a second front while losing the first
    for (const w of wars) if (G.warScore(id, w) < -10) return;
    const mine = coalition(id);
    let best = null, bestScore = 0;
    for (const t of alive()) {
      if (t === id || G.atWar(id, t) || G.allied(id, t) || G.hasTreaty('nap', id, t)) continue;
      if ((st.truce[G.dkey(id, t)] || 0) > st.day) continue;
      const overseas = !bordering(id, t);
      if (overseas && !(G.aiSeaReach && G.aiSeaReach(id, t))) continue;
      let theirs = coalition(t);
      G.treatiesOf(t).filter(x => x.type === 'guarantee' && x.b === t).forEach(x => { theirs += 0.5 * power(x.a); });
      const ratio = mine / Math.max(1, theirs);
      if (ratio < 1.25) continue;
      const hatred = Math.max(0, -G.relation(id, t)) / 100;
      let score = 1.1 * (ratio - 1.25) + 0.9 * hatred + 0.7 * ai.aggression - 0.45 * ai.caution - 0.008 * (st.infamy[id] || 0);
      if (G.warsOf(t).length) score += 0.25;                          // opportunism
      if (landShare(t) > 0.3) score += 0.4;                           // coalition against a runaway power
      if (t === st.player) score += 0.05;
      score -= 2.2 * Math.max(0, landShare(id) - 0.18);              // big nations tire of conquest
      if (overseas) score -= 0.3;
      score *= D.aggr;
      if (score > bestScore) { bestScore = score; best = t; }
    }
    if (best && bestScore > 0.75) {
      const r = G.declareWar(id, best);
      if (r.ok) { ai.plan = { target: best, since: st.day }; ai.nextWar = st.day + Math.round(150 - 50 * ai.aggression); }
    }
  }

  /* ---------- operations ---------- */
  function retreatWeak(id) {
    const st = G.state;
    for (const a of st.armies.filter(x => x.owner === id && !G.inBattle(x))) {
      const s = G.armySummary(a);
      if (!s.n) continue;
      const weak = s.strength < 0.5 || s.org < 0.6;
      if (weak && st.owners[a.prov] !== id && !G.allied(st.owners[a.prov], id)) {
        const to = G.retreatProvince(a); if (to != null) G.orderMove(a, to);
      }
    }
  }
  function objectives(id) {
    const st = G.state, P = G.provinces, out = [];
    const enemies = G.warsOf(id);
    if (!enemies.length) return out;
    const seen = {};
    const mineAt = p => st.owners[p] === id || G.allied(st.owners[p], id) || G.armiesAt(p).some(a => a.owner === id);
    P.forEach(p => {
      if (p.sea) return;
      const o = st.owners[p.id];
      if (!o || !enemies.includes(o) || seen[p.id]) return;
      if (!p.adj.some(mineAt)) return;
      seen[p.id] = true;
      const D = G.armiesAt(p.id).filter(x => x.owner === o);
      const defFire = D.length ? G.sideFire(D, true, p.id, G.armiesAt(p.id).filter(x => x.owner === id)) : 0.5;
      const value = 1 + p.pop / 80000 + (G.COUNTRIES[o].capitalId === p.id ? 3 : 0) + (st.occ[p.id] && st.occ[p.id].by === id ? 1.5 : 0);
      out.push({ prov: p.id, owner: o, defFire: defFire, value: value });
    });
    return out;
  }
  function operate(id) {
    const st = G.state, P = G.provinces, ai = st.ai[id];
    retreatWeak(id);
    const idle = st.armies.filter(a => a.owner === id && !a.path.length && !G.inBattle(a) && G.armySummary(a).strength >= 0.5 && G.armySummary(a).org >= 0.6);
    if (!idle.length) return;
    // 1. retake own land that enemies stand in
    const enemies = G.warsOf(id);
    for (const p of P) {
      if (p.sea || st.owners[p.id] !== id) continue;
      const E = hostileAt(p.id, id); if (!E.length) continue;
      const near = idle.filter(a => a.prov !== p.id).map(a => ({ a: a, path: G.findPath(a, p.id) })).filter(x => x.path).sort((x, y) => x.path.length - y.path.length);
      if (!near.length) continue;
      const mine = G.sideFire(near.slice(0, 3).map(x => x.a), false, p.id, E), theirs = G.sideFire(E, true, p.id, near.map(x => x.a));
      if (mine >= theirs * 0.9) near.slice(0, 3).forEach(x => { G.orderMove(x.a, p.id); });
    }
    const free = idle.filter(a => !a.path.length);
    if (!enemies.length || !free.length) return;
    // 2. choose an objective
    const objs = objectives(id);
    if (!objs.length) return;
    const myFire = G.sideFire(free, false, objs[0].prov, []);
    objs.forEach(o => { o.score = o.value / (1 + o.defFire / Math.max(0.5, myFire)); });
    objs.sort((x, y) => y.score - x.score);
    const O = objs[0];
    // 3. staging province next to the objective
    const cands = P[O.prov].adj.filter(n => !P[n].sea && (st.owners[n] === id || G.allied(st.owners[n], id) || G.armiesAt(n).some(a => a.owner === id)));
    if (!cands.length) return;
    const count = n => G.armiesAt(n).filter(a => a.owner === id).length;
    cands.sort((x, y) => count(y) - count(x));
    const S = cands[0];
    if (!ai.stage || ai.stage.obj !== O.prov) ai.stage = { obj: O.prov, at: S, since: st.day };
    const atS = free.filter(a => a.prov === S), elsewhere = free.filter(a => a.prov !== S);
    // 4. everyone not at S marches to S (or straight at O if it is empty and close)
    elsewhere.forEach(a => {
      if (O.defFire <= 0.5 && P[a.prov].adj.includes(O.prov)) { G.orderMove(a, O.prov); return; }
      const path = G.findPath(a, S); if (path && path.length <= 6) G.orderMove(a, S);
    });
    // 5. at S: attack when strong enough (or after waiting long enough)
    if (atS.length) {
      const enemyAt = G.armiesAt(O.prov).filter(x => x.owner === O.owner);
      const mine = G.sideFire(atS, false, O.prov, enemyAt), theirs = enemyAt.length ? G.sideFire(enemyAt, true, O.prov, atS) : 0;
      const waited = st.day - ai.stage.since;
      if (!enemyAt.length || mine >= theirs * (waited > 14 ? 1.0 : 1.3)) atS.forEach(a => { G.orderMove(a, O.prov); });
      else if (atS.length > 1) {                                      // consolidate while waiting
        const base = atS[0]; atS.slice(1).forEach(a => G.mergeArmies(base, a));
      }
    }
  }

  /* ---------- recruitment ---------- */
  const COMP = { infantry: 0.50, artillery: 0.15, cavalry: 0.08, tank: 0.12, engineers: 0.06, militia: 0.09 };
  function recruitAI(id) {
    const st = G.state, c = st.countries[id], ai = st.ai[id];
    if (st.queues[id].length >= 4) return;
    const wars = G.warsOf(id).length > 0;
    const M = menOf(id) + st.queues[id].reduce((s, it) => s + G.UNITS[it.type].men, 0);
    const want = (2500 + 800 * (c.provCount || 0)) * (0.8 + ai.aggression * 0.6) * (wars ? 1.8 : 1) * (G.diff().aggr > 1 ? 1.15 : 1);
    if (M >= want) return;
    if (c.treasury < 120 + (wars ? 0 : 150)) return;
    // composition by deficit
    const have = {}; let tot = 0;
    st.armies.filter(a => a.owner === id).forEach(a => a.units.forEach(u => { have[u.type] = (have[u.type] || 0) + 1; tot++; }));
    st.queues[id].forEach(it => { have[it.type] = (have[it.type] || 0) + 1; tot++; });
    const deficit = t => COMP[t] - (have[t] || 0) / Math.max(1, tot);
    const order = Object.keys(COMP).sort((x, y) => deficit(y) - deficit(x));
    // province: the front line if at war, otherwise a big province near the border
    const own = G.provinces.filter(p => !p.sea && st.owners[p.id] === id);
    const front = own.filter(p => p.adj.some(n => st.owners[n] && st.owners[n] !== id && (G.atWar(id, st.owners[n]) || !G.allied(id, st.owners[n]))));
    const pool = (wars && front.length ? front : own).slice().sort((x, y) => y.pop - x.pop);
    const spot = pool[(st.day / 6 | 0) % Math.max(1, Math.min(pool.length, 4))];
    for (const t of order) { if (G.recruit(id, t, spot.id).ok) return; }
    G.recruit(id, 'militia', spot.id);
  }

  function consolidate(id) {
    const st = G.state, seen = {};
    for (const a of st.armies.filter(x => x.owner === id && !x.path.length && !G.inBattle(x))) {
      const t = seen[a.prov];
      if (t && t.units.length + a.units.length <= G.ARMY_MAX_UNITS) G.mergeArmies(t, a); else seen[a.prov] = a;
    }
  }

  /* ---------- economy ---------- */
  function economyAI(id) {
    const st = G.state, c = st.countries[id], ai = st.ai[id];
    // taxes follow the budget
    if (c.treasury < 150 && st.tax[id] !== 'high') st.tax[id] = 'high';
    else if (c.treasury > 1500 && st.tax[id] !== 'low') st.tax[id] = 'low';
    else if (c.treasury > 400 && c.treasury < 1200 && st.tax[id] !== 'normal') st.tax[id] = 'normal';
    // production lines follow shortages of equipment
    const t = G.totals(id), a = st.alloc[id];
    if (t.mil) {
      const lowGuns = c.equip.guns < 150, lowRifles = c.equip.rifles < 3000, lowVeh = c.equip.vehicles < 120;
      const wRifles = lowRifles ? 0.6 : 0.4, wGuns = lowGuns ? 0.3 : 0.2, wVeh = lowVeh ? 0.3 : 0.2;
      const tot = wRifles + wGuns + wVeh;
      a.rifles = Math.round(t.mil * wRifles / tot); a.guns = Math.round(t.mil * wGuns / tot); a.vehicles = Math.max(0, t.mil - a.rifles - a.guns);
    }
    // surplus is sold, shortages are bought
    G.RESOURCES.forEach(r => { if (c.res[r] > 2500 && c.treasury < 800) G.trade(id, r, -150); });
    // fortify threatened border provinces
    if (c.treasury > 450 && st.fortQ.filter(f => f.owner === id).length < 2) {
      let best = null, bs = 0;
      G.provinces.forEach(p => {
        if (p.sea || st.owners[p.id] !== id || !G.canBuildFort(id, p.id).ok) return;
        let threat = 0;
        p.adj.forEach(n => { const o = st.owners[n]; if (o && o !== id) { if (G.atWar(id, o)) threat += 2 + hostileAt(n, id).length * 3; else if (G.relation(id, o) < -30) threat += 0.5; } });
        if (G.COUNTRIES[id].capitalId === p.id) threat *= 1.4;
        if (threat > bs) { bs = threat; best = p; }
      });
      if (best && bs >= 2.5 - ai.caution) G.buildFort(id, best.id);
    }
    // infrastructure and railways at the front, then ports
    if (st.construct.filter(x => x.owner === id).length < 3 && c.treasury > 350) {
      const wars = G.warsOf(id).length > 0;
      const cand = G.provinces.filter(p => !p.sea && st.owners[p.id] === id && p.adj.some(n => st.owners[n] !== id && st.owners[n]));
      cand.sort((x, y) => y.pop - x.pop);
      for (const p of cand.slice(0, 3)) {
        const types = wars ? ['rail', 'infra', 'port'] : ['infra', 'port', 'rail'];
        if (types.some(ty => G.startBuild(id, ty, p.id).ok)) break;
      }
    }
  }

  /* ---------- diplomacy ---------- */
  function diplomacyAI(id) {
    const st = G.state, ai = st.ai[id];
    const rivals = alive().filter(t => t !== id && !G.allied(id, t) && bordering(id, t) && power(t) > 1.2 * power(id));
    const threat = rivals.sort((x, y) => power(y) - power(x))[0];
    if (threat) {
      // seek allies against the threat
      const friends = alive().filter(d => d !== id && d !== threat && d !== st.player && !G.atWar(id, d) && G.relation(d, threat) < 15);
      for (const d of friends.sort((x, y) => G.relation(id, y) - G.relation(id, x))) {
        const e1 = G.diplomacyEval('alliance', id, d), e2 = G.diplomacyEval('alliance', d, id);
        if (e1.score != null && e2.score != null && e1.ok && e2.ok) { G.signTreaty('alliance', id, d); return; }
      }
      // cautious nations appease the threat with a pact
      if (ai.caution > 0.5 && !G.hasTreaty('nap', id, threat) && !G.atWar(id, threat)) {
        const e = G.diplomacyEval('nap', id, threat);
        if (e.score != null && e.ok && threat !== st.player) G.signTreaty('nap', id, threat);
      }
    }
  }

  /* ---------- clock ---------- */
  G.economyAI = economyAI;
  G.warAIDay = function () {
    const st = G.state; if (!st.ai) return;
    const D = G.diff(), think = Math.max(1, Math.round(4 * D.think));
    const ids = alive().filter(id => id !== st.player);
    ids.forEach((id, i) => {
      if (st.day % think === i % think && G.warsOf(id).length) operate(id);
      if (st.day % 6 === i % 6) recruitAI(id);
      if (st.day % 7 === i % 7) consolidate(id);
      if (st.day % Math.round(12 * D.think) === (i * 2) % Math.round(12 * D.think)) chooseWar(id);
      if (st.day % 10 === (i + 3) % 10) economyAI(id);
    });
    if (st.day % 30 === 18) ids.forEach(diplomacyAI);
    // runaway powers become hated by everyone (coalition pressure)
    if (st.day % 30 === 25) alive().forEach(big => {
      if (landShare(big) > 0.3) alive().forEach(x => { if (x !== big) G.addRelation(x, big, -3); });
    });
  };
})(window.EMP = window.EMP || {});
