'use strict';
function angDiff(a,b){let d=b-a;if(!isFinite(d))return 0;while(d>Math.PI)d-=TAU;while(d<-Math.PI)d+=TAU;return d}
function safeDir(b){
  if((b.fl|0)>0){const h=hsAt(b.x,b.y);if(h){const s=stairPos(h,b.fl-1),ux=s.x-b.x,uy=s.y-b.y,ul=Math.hypot(ux,uy)||1;return[ux/ul,uy/ul]}}
 const ux=z.tx-b.x,uy=z.ty-b.y,ul=Math.hypot(ux,uy)||1;return[ux/ul,uy/ul]}

function botAI(b,dt){
  b.t-=dt;b.sT-=dt;b.avoidT-=dt;b.wpT-=dt;b.gT-=dt;
  const w=curW(b),mate=b.team===player.team&&player.alive;
  if(b.t<=0){
    b.t=rnd(.2,.38);
    let best=null,bd=Infinity,bl=false;
    for(const p of players){
      if(!p.alive||p.team===b.team||(p.fl|0)!==(b.fl|0)||(p.camo>0&&Math.hypot(p.x-b.x,p.y-b.y)>110))continue;
      const d2=(p.x-b.x)**2+(p.y-b.y)**2;
      if(d2<bd&&d2<580*580){bd=d2;best=p}
    }
    if(best){bl=los(b.x,b.y,best.x,best.y,b.fl);if(!bl&&bd>260*260)best=null}
    if(best&&best!==b.tgt)b.react=rnd(.25,.7)*(1.4-b.skill);
    b.tgt=best;b.tgtLos=bl;
    if(b.wantMove&&Math.hypot(b.x-b.lx,b.y-b.ly)<7){b.avoidT=.8;b.avoidA=(Math.random()<.5?-1:1)*rnd(.9,2);b.wp=null}
    b.lx=b.x;b.ly=b.y;
    b.loot=null;let ld=400*400;
    for(const l of loot){
      if(l.np===b||(l.fl|0)!==(b.fl|0)||!needLoot(b,l))continue;
      const d2=(l.x-b.x)**2+(l.y-b.y)**2;if(d2<ld){ld=d2;b.loot=l}
    }
    // survival decisions
    if(!best&&!b.heal&&b.hp<65){
      if(b.inv.medkit>0&&b.hp<45)startHeal(b,'medkit');else if(b.inv.bandage>0&&b.hp<70)startHeal(b,'bandage');
    }
    if(best&&b.heal&&b.hp>30)b.heal=null;
    if(best&&b.hp<55&&b.inv.gloo>0&&b.glCd<=0&&time-b.lastHit<1.6&&bd<380*380)placeGloo(b);
    if(best&&bl&&b.inv.grenade>0&&b.gT<=0&&bd>140*140&&bd<290*290){b.ang=Math.atan2(best.y-b.y,best.x-b.x);throwN(b,'grenade');b.gT=rnd(7,14)}
    if(best&&b.hp<35&&b.inv.smoke>0&&b.gT<=0){b.ang=Math.atan2(best.y-b.y,best.x-b.x);throwN(b,'smoke');b.gT=rnd(8,14)}
    if(b.sl[1]&&curS(b).mag<=0&&b.res<=0&&b.sl[1-b.cur].mag>0)swapW(b);
  }
  const dz=Math.hypot(b.x-z.cx,b.y-z.cy);
  const useT=z.stage==='shrink'||(z.stage==='wait'&&z.t<20)||z.stage==='done';
  const unsafe=dz>z.r*.92||(useT&&Math.hypot(b.x-z.tx,b.y-z.ty)>z.tr*.8);
  let mx=0,my=0;b.wantMove=true;
  const tg=b.tgt&&b.tgt.alive?b.tgt:null;
  let aimA=b.ang;
  if(tg){
    const dx=tg.x-b.x,dy=tg.y-b.y,d=Math.hypot(dx,dy)||1;
    const lead=b.skill>.65?d/w.sp:0;
    aimA=Math.atan2(dy+tg.vy*lead,dx+tg.vx*lead);
    if(b.sT<=0){b.sT=rnd(.8,2);b.sdir=Math.random()<.5?-1:1}
    const pref=w.pref*(.8+b.skill*.3);
    if(unsafe){[mx,my]=safeDir(b)}
    else if(b.hp<30||(curS(b).mag<=0&&b.res<=0)){mx=-dx/d;my=-dy/d}
    else if(d>pref+50){mx=dx/d;my=dy/d}
    else if(d<pref-70){mx=-dx/d;my=-dy/d}
    else{mx=-dy/d*b.sdir;my=dx/d*b.sdir}
  }else if(unsafe){
    [mx,my]=safeDir(b);aimA=Math.atan2(my,mx);
  }else if(b.heal){
    b.wantMove=false;
  }else if(b.loot){
    const ux=b.loot.x-b.x,uy=b.loot.y-b.y,ul=Math.hypot(ux,uy)||1;mx=ux/ul;my=uy/ul;aimA=Math.atan2(uy,ux);
  }else if(mate&&b!==player&&Math.hypot(player.x-b.x,player.y-b.y)>140){
    const ux=player.x-b.x,uy=player.y-b.y,ul=Math.hypot(ux,uy)||1;mx=ux/ul;my=uy/ul;aimA=Math.atan2(uy,ux);
  }else if(mate){
    b.wantMove=false;
  }else{
    if(b.rest>0){b.rest-=dt;b.wantMove=false}
    else{
      if(!b.wp||b.wpT<=0||Math.hypot(b.wp[0]-b.x,b.wp[1]-b.y)<46){
        if(b.wp&&Math.random()<.35)b.rest=rnd(.5,1.8);
        let hs=null;
        for(let t=0;t<8;t++){const c=pick(houses);if(c&&Math.hypot(c.cx-z.cx,c.cy-z.cy)<z.r*.8){hs=c;break}}
        b.wp=hs?[hs.cx+rnd(-30,30),hs.cy+rnd(-30,30)]:[z.cx+rnd(-1,1)*z.r*.5,z.cy+rnd(-1,1)*z.r*.5];
        b.wpT=rnd(12,26);
        const fh=hsAt(b.x,b.y);
        if(fh&&fh.nf>1){
          const fl=b.fl|0,r=Math.random();let t=-1;
          if(fl>0&&r<.4)t=fl-1;else if(fl<fh.nf-1&&r<.7)t=fl;
          if(t>=0){const s=stairPos(fh,t);b.wp=[s.x,s.y]}
          else if(fl>0)b.wp=[fh.x+rnd(60,fh.w-60),fh.y+rnd(60,fh.h-60)];
        }
      }
      const ux=b.wp[0]-b.x,uy=b.wp[1]-b.y,ul=Math.hypot(ux,uy)||1;mx=ux/ul;my=uy/ul;aimA=Math.atan2(uy,ux);
    }
  }
  if(b.avoidT>0){const c=Math.cos(b.avoidA),s=Math.sin(b.avoidA),nx=mx*c-my*s,ny=mx*s+my*c;mx=nx;my=ny}
  const rate=5+b.skill*6,df=angDiff(b.ang,aimA),st=rate*dt;
  b.ang+=Math.abs(df)<st?df:Math.sign(df)*st;
  const sp=(138+b.skill*16)*(inWater(b)?.55:1)*(b.heal?.55:1)*(b.wantMove?1:0);
  moveE(b,mx*sp,my*sp,dt);
  b.mv=clamp(Math.hypot(b.vx,b.vy)/150,0,1);
  if(tg&&b.tgtLos){
    b.react-=dt;
    const d=Math.hypot(tg.x-b.x,tg.y-b.y);
    if(time>7&&b.react<=0&&Math.abs(angDiff(b.ang,aimA))<.1+(1-b.skill)*.12&&d<w.range*.92)shoot(b);
  }
}
