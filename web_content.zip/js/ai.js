/* يمكن هدف؟ — محرك روبو للتحليل والتوقع
   Everything here is computed in the browser from live match data. */
(function () {
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const AR = n => YH.TEAM_AR[n] || n;

  /* ---------- helpers on summary ---------- */
  function teamStats(sum) {
    const out = { home: {}, away: {} };
    const teams = (sum.boxscore && sum.boxscore.teams) || [];
    teams.forEach(t => {
      const side = t.homeAway || (t.team.id === homeId(sum) ? 'home' : 'away');
      (t.statistics || []).forEach(s => { const v = parseFloat(s.displayValue); out[side][s.name] = isNaN(v) ? 0 : v; });
    });
    ['home', 'away'].forEach(s => {
      const o = out[s];
      if (o.totalPasses) o.passPct = Math.round(100 * (o.accuratePasses || 0) / o.totalPasses);
      else if (o.passPct != null && o.passPct <= 1) o.passPct = Math.round(o.passPct * 100);
    });
    return out;
  }
  function comp(sum) { return sum.header && sum.header.competitions && sum.header.competitions[0]; }
  function side(sum, s) { const c = comp(sum); return c && c.competitors.find(x => x.homeAway === s); }
  function homeId(sum) { const h = side(sum, 'home'); return h && h.team.id; }
  function names(sum) {
    const h = side(sum, 'home'), a = side(sum, 'away');
    return { home: h ? h.team.displayName : 'الأرض', away: a ? a.team.displayName : 'الضيف', hs: h ? +h.score || 0 : 0, as: a ? +a.score || 0 : 0 };
  }
  function playTeamSide(sum, p) {
    const n = names(sum);
    const tn = p.team && (p.team.displayName || p.team.name);
    if (!tn) return null;
    if (tn === n.home) return 'home';
    if (tn === n.away) return 'away';
    const hid = homeId(sum);
    if (p.team.id) return p.team.id === hid ? 'home' : 'away';
    return null;
  }
  function plays(sum) {
    return (sum.commentary || []).map(c => c.play ? { ...c.play, seq: c.sequence, timeTxt: c.time && c.time.displayValue, raw: c.text } : null).filter(Boolean);
  }
  function minuteOf(p) {
    const t = (p.clock && p.clock.displayValue) || p.timeTxt || '';
    const m = t.match(/(\d+)(?:'\s*\+\s*(\d+))?/);
    if (!m) return p.clock && p.clock.value ? Math.round(p.clock.value / 60) : 0;
    return (+m[1]) + (m[2] ? +m[2] * 0.01 : 0);
  }

  /* ---------- expected goals from coordinates ---------- */
  function xgOf(p) {
    const type = (p.type && p.type.type) || '';
    if (/penalty/.test(type) || /penalty/i.test(p.text || '')) return /missed|saved/.test(type) && !/scored/.test(type) ? 0.76 : 0.76;
    if (p.fieldPositionX == null) return /goal|on-target/.test(type) ? 0.25 : 0.06;
    const x = p.fieldPositionX, y = p.fieldPositionY;
    const dx = (100 - x) * 1.05, dy = (y - 50) * 0.68;
    const dist = Math.sqrt(dx * dx + dy * dy);
    const a1 = Math.atan2(3.66 - dy, dx), a2 = Math.atan2(-3.66 - dy, dx);
    const angle = Math.abs(a1 - a2);
    let z = -0.75 - 0.11 * dist + 1.15 * angle;
    if (/header/.test(type) || /header/i.test(p.text || '')) z -= 0.55;
    return clamp(1 / (1 + Math.exp(-z)), 0.01, 0.92);
  }
  const SHOT_TYPES = /goal|shot|penalty/;
  function shots(sum) {
    return plays(sum).filter(p => p.type && SHOT_TYPES.test(p.type.type) && !/^(penalty---awarded|penalty-awarded)$/.test(p.type.type))
      .map(p => {
        const t = p.type.type;
        const isGoal = /^goal|scored/.test(t) || (p.scoringPlay === true);
        return { side: playTeamSide(sum, p), min: minuteOf(p), x: p.fieldPositionX, y: p.fieldPositionY, gx: p.fieldPosition2X, gy: p.goalPositionY ?? p.fieldPosition2Y,
          xg: xgOf(p), goal: isGoal, type: t, onTarget: isGoal || /on-target|saved/.test(t), who: p.participants && p.participants[0] && p.participants[0].athlete.displayName, text: p.text || p.raw };
      }).filter(s => s.side);
  }

  /* ---------- momentum ---------- */
  const MW = { 'goal': 6, 'goal---header': 6, 'goal---free-kick': 6, 'penalty---scored': 6, 'shot-on-target': 2.4, 'shot-hit-woodwork': 2.6,
    'shot-off-target': 1.1, 'shot-blocked': 0.9, 'corner-awarded': 0.8, 'offside': 0.3, 'penalty---saved': 2.5, 'penalty---missed': 2 };
  function momentum(sum, bucket = 5) {
    const ps = plays(sum);
    const maxMin = Math.max(90, ...ps.map(minuteOf).map(Math.floor));
    const n = Math.ceil(maxMin / bucket);
    const arr = Array.from({ length: n }, (_, i) => ({ t: i * bucket, home: 0, away: 0 }));
    ps.forEach(p => {
      const w = MW[p.type && p.type.type];
      const s = playTeamSide(sum, p);
      if (!w || !s) return;
      const i = clamp(Math.floor(minuteOf(p) / bucket), 0, n - 1);
      arr[i][s] += w;
    });
    // smooth
    return arr.map((b, i) => {
      const prev = arr[i - 1] || b, next = arr[i + 1] || b;
      return { t: b.t, home: (prev.home + 2 * b.home + next.home) / 4, away: (prev.away + 2 * b.away + next.away) / 4 };
    });
  }

  /* ---------- player ratings ---------- */
  function ratings(sum) {
    const n = names(sum);
    const out = [];
    (sum.rosters || []).forEach(r => {
      const s = r.homeAway;
      const won = s === 'home' ? n.hs > n.as : n.as > n.hs;
      const conceded = s === 'home' ? n.as : n.hs;
      (r.roster || []).forEach(p => {
        if (!p.starter && !p.subbedIn) return;
        const st = {}; (p.stats || []).forEach(x => st[x.name] = x.value || 0);
        const isGK = p.position && p.position.abbreviation === 'G';
        const isDef = p.position && /^(CD|CB|LB|RB|D|SW|LWB|RWB)/.test(p.position.abbreviation);
        let r0 = 6.3;
        r0 += (st.totalGoals || 0) * 1.05 + (st.goalAssists || 0) * 0.75 + (st.shotsOnTarget || 0) * 0.22 + (st.totalShots || 0) * 0.05;
        r0 += (st.foulsSuffered || 0) * 0.06 - (st.foulsCommitted || 0) * 0.06 - (st.yellowCards || 0) * 0.35 - (st.redCards || 0) * 1.6 - (st.ownGoals || 0) * 1.1;
        if (isGK) r0 += (st.saves || 0) * 0.32 - conceded * 0.28 + (conceded === 0 ? 0.6 : 0);
        if (isDef) r0 += conceded === 0 ? 0.45 : -conceded * 0.12;
        r0 += won ? 0.3 : 0;
        if (!p.starter) r0 = 6.0 + (r0 - 6.3) * 0.9;
        out.push({ side: s, name: p.athlete.displayName, short: p.athlete.shortName || p.athlete.displayName, jersey: p.jersey,
          pos: p.position && p.position.abbreviation, rating: clamp(Math.round(r0 * 10) / 10, 3.5, 10), st, starter: p.starter });
      });
    });
    return out.sort((a, b) => b.rating - a.rating);
  }

  /* ---------- style DNA ---------- */
  function styleDNA(ts) {
    const axes = [
      { k: 'poss', ar: 'الاستحواذ' }, { k: 'pass', ar: 'دقة التمرير' }, { k: 'direct', ar: 'اللعب المباشر' },
      { k: 'wide', ar: 'اللعب على الأطراف' }, { k: 'press', ar: 'الضغط والافتكاك' }, { k: 'threat', ar: 'الخطورة' }, { k: 'clinical', ar: 'الفعالية' },
    ];
    const f = s => {
      const passes = s.totalPasses || 1;
      return {
        poss: clamp((s.possessionPct || 50) / 75, 0, 1),
        pass: clamp(((s.passPct || 75) - 55) / 40, 0, 1),
        direct: clamp(((s.totalLongBalls || 0) / passes) / 0.16, 0, 1),
        wide: clamp((s.totalCrosses || 0) / 35, 0, 1),
        press: clamp(((s.totalTackles || 0) + (s.interceptions || 0)) / 45, 0, 1),
        threat: clamp((s.totalShots || 0) / 25, 0, 1),
        clinical: clamp((s.shotsOnTarget || 0) / Math.max(1, s.totalShots || 1) / 0.6, 0, 1),
      };
    };
    return { axes, home: f(ts.home), away: f(ts.away) };
  }
  function styleLabel(s, opp) {
    const p = s.possessionPct || 50, pp = s.passPct || 75, passes = s.totalPasses || 1;
    const longShare = (s.totalLongBalls || 0) / passes, cross = s.totalCrosses || 0, def = (s.totalTackles || 0) + (s.interceptions || 0);
    const tags = [];
    if (p >= 60 && pp >= 85) tags.push({ t: 'تيكي تاكا', d: 'استحواذ طويل وتمرير قصير دقيق لسحب الخصم وفتح المساحات' });
    else if (p >= 55) tags.push({ t: 'بناء منظم من الخلف', d: 'سيطرة على الكرة وبناء هادئ للهجمات' });
    if (p <= 44 && (s.shotsOnTarget || 0) >= (opp.shotsOnTarget || 0)) tags.push({ t: 'مرتدات قاتلة', d: 'تراجع منظّم ثم انطلاقات سريعة نحو المرمى' });
    else if (p <= 42) tags.push({ t: 'كتلة دفاعية منخفضة', d: 'إغلاق المساحات وانتظار أخطاء الخصم' });
    if (longShare >= 0.11) tags.push({ t: 'كرات طويلة مباشرة', d: 'تجاوز خط الوسط بسرعة نحو المهاجمين' });
    if (cross >= 24) tags.push({ t: 'هجوم من الأطراف', d: 'اعتماد واضح على العرضيات وانطلاقات الأظهرة' });
    if (def >= 38) tags.push({ t: 'ضغط عالٍ', d: 'افتكاك متكرر وقطع للكرات في مناطق متقدمة' });
    if ((s.foulsCommitted || 0) >= 16) tags.push({ t: 'لعب خشن', d: 'كثرة الأخطاء لكسر إيقاع الخصم' });
    if (!tags.length) tags.push({ t: 'أسلوب متوازن', d: 'مزيج بين البناء والهجوم المباشر دون هوية طاغية' });
    return tags.slice(0, 3);
  }

  /* ---------- full analysis ---------- */
  function analyze(sum) {
    const n = names(sum), ts = teamStats(sum), sh = shots(sum), mom = momentum(sum), rt = ratings(sum);
    const xg = { home: 0, away: 0 }; sh.forEach(s => xg[s.side] += s.xg);
    const dom = { home: 0, away: 0 }; mom.forEach(b => { dom.home += b.home; dom.away += b.away; });
    const domTot = dom.home + dom.away || 1;
    const domShare = { home: dom.home / domTot, away: dom.away / domTot };
    const H = AR(n.home), A = AR(n.away);
    const winner = n.hs > n.as ? 'home' : n.as > n.hs ? 'away' : null;
    const xgWinner = Math.abs(xg.home - xg.away) < 0.35 ? null : xg.home > xg.away ? 'home' : 'away';
    const nm = s => s === 'home' ? H : A;
    const story = [];
    const goals = sh.filter(s => s.goal).sort((a, b) => a.min - b.min);

    // verdict
    let verdict;
    if (!winner) verdict = xgWinner ? `تعادل ${n.hs}-${n.as} لكن ${nm(xgWinner)} كان الأقرب للفوز بفرص أخطر (xG ${xg[xgWinner].toFixed(2)} مقابل ${xg[xgWinner === 'home' ? 'away' : 'home'].toFixed(2)}).` : `تعادل عادل ${n.hs}-${n.as}؛ الفرص كانت متقاربة جداً بين الفريقين.`;
    else if (xgWinner === winner || !xgWinner) verdict = `فوز مستحق لـ${nm(winner)} — تفوّق في النتيجة ${Math.max(n.hs, n.as)}-${Math.min(n.hs, n.as)} وفي جودة الفرص (xG ${xg[winner].toFixed(2)}).`;
    else verdict = `${nm(winner)} فاز بالواقعية رغم أن ${nm(xgWinner)} صنع فرصاً أخطر (xG ${xg[xgWinner].toFixed(2)} مقابل ${xg[winner].toFixed(2)}) — فعالية أمام المرمى حسمت اللقاء.`;
    story.push({ k: 'verdict', title: 'حكم المباراة', text: verdict });

    // control
    const pH = ts.home.possessionPct, pA = ts.away.possessionPct;
    const ctrl = domShare.home > 0.57 ? 'home' : domShare.away > 0.57 ? 'away' : null;
    story.push({ k: 'control', title: 'من سيطر؟', text: ctrl
      ? `${nm(ctrl)} فرض إيقاعه بـ${Math.round(domShare[ctrl] * 100)}% من مؤشر الضغط الهجومي${pH ? `، واستحواذ ${ctrl === 'home' ? pH : pA}%` : ''}.`
      : `مباراة متكافئة: مؤشر الضغط الهجومي ${Math.round(domShare.home * 100)}% لـ${H} مقابل ${Math.round(domShare.away * 100)}% لـ${A}.` });

    // phases
    const third = Math.ceil(mom.length / 3);
    const phase = (a, b) => { let h = 0, w = 0; mom.slice(a, b).forEach(x => { h += x.home; w += x.away; }); return h > w * 1.3 ? 'home' : w > h * 1.3 ? 'away' : null; };
    const ph = [phase(0, third), phase(third, 2 * third), phase(2 * third, mom.length)];
    const phTxt = ['البداية', 'منتصف المباراة', 'الدقائق الأخيرة'].map((l, i) => ph[i] ? `${l}: أفضلية ${nm(ph[i])}` : `${l}: توازن`).join(' · ');
    story.push({ k: 'phases', title: 'مراحل اللقاء', text: phTxt });

    // turning points
    const tps = [];
    let sh0 = 0, sa0 = 0;
    goals.forEach(g => {
      g.side === 'home' ? sh0++ : sa0++;
      const lbl = sh0 === sa0 ? 'هدف التعادل' : (g.side === 'home' ? sh0 > sa0 : sa0 > sh0) ? (Math.abs(sh0 - sa0) === 1 ? 'هدف التقدم' : 'هدف يعزّز التقدم') : 'هدف تقليص الفارق';
      tps.push({ min: g.min, side: g.side, who: g.who, txt: `${Math.floor(g.min)}' — ${g.who || ''} (${nm(g.side)}): ${lbl} ${sh0}-${sa0}` });
    });
    plays(sum).filter(p => /red-card/.test(p.type && p.type.type)).forEach(p => {
      const s = playTeamSide(sum, p); tps.push({ min: minuteOf(p), side: s, txt: `${Math.floor(minuteOf(p))}' — بطاقة حمراء على ${(p.participants && p.participants[0] && p.participants[0].athlete.displayName) || 'لاعب'} (${nm(s)})`, red: true });
    });
    tps.sort((a, b) => a.min - b.min);

    // star
    const star = rt[0];
    if (star) story.push({ k: 'star', title: 'نجم المباراة', text: `${star.name} (${nm(star.side)}) بتقييم ${star.rating.toFixed(1)}${star.st.totalGoals ? ` — ${star.st.totalGoals} هدف` : ''}${star.st.goalAssists ? ` و${star.st.goalAssists} صناعة` : ''}${star.pos === 'G' && star.st.saves ? ` — ${star.st.saves} تصديات` : ''}.` });

    const styles = { home: styleLabel(ts.home, ts.away), away: styleLabel(ts.away, ts.home) };
    story.push({ k: 'style', title: 'كيف لعب كل فريق؟', text: `${H}: ${styles.home.map(s => s.t).join('، ')}. ${A}: ${styles.away.map(s => s.t).join('، ')}.` });

    // efficiency
    const eff = s => (s === 'home' ? n.hs : n.as) - xg[s];
    const effTxt = ['home', 'away'].map(s => {
      const e = eff(s);
      return `${nm(s)} ${e > 0.6 ? 'سجّل أكثر من المتوقع بفعالية عالية' : e < -0.6 ? 'أهدر فرصاً كان يجب أن تُترجم' : 'سجّل بما يوازي فرصه'} (${(s === 'home' ? n.hs : n.as)} هدف من xG ${xg[s].toFixed(2)})`;
    }).join(' · ');
    story.push({ k: 'eff', title: 'الفعالية أمام المرمى', text: effTxt });

    return { n, ts, sh, mom, rt, xg, domShare, story, tps, styles, dna: styleDNA(ts), H, A, goals };
  }

  /* ---------- prediction ---------- */
  function poisson(k, l) { let p = Math.exp(-l); for (let i = 1; i <= k; i++) p *= l / i; return p; }
  function grid(lh, la) {
    let H = 0, D = 0, A = 0, best = { p: 0 }; const cells = [];
    for (let i = 0; i <= 7; i++) for (let j = 0; j <= 7; j++) {
      const p = poisson(i, lh) * poisson(j, la); cells.push({ h: i, a: j, p });
      if (i > j) H += p; else if (i === j) D += p; else A += p;
    }
    const s = H + D + A;
    return { home: H / s, draw: D / s, away: A / s, cells: cells.sort((a, b) => b.p - a.p) };
  }
  function ml2p(ml) { if (ml == null || isNaN(ml)) return null; ml = +ml; return ml > 0 ? 100 / (ml + 100) : -ml / (-ml + 100); }
  function formPts(f) { return (f || '').split('').slice(-5).reduce((a, c) => a + (c === 'W' ? 3 : c === 'D' ? 1 : 0), 0); }

  /* inputs: { home, away (names), homeId, awayId, table (standings array|null), formH, formA, odds {home,draw,away}, poly, leadersH, leadersA } */
  function predict(inp) {
    const sources = [];
    const H = AR(inp.home), A = AR(inp.away);
    let lh = 1.45, la = 1.15; const reasons = [];
    // model from table
    if (inp.table && inp.table.length) {
      const th = inp.table.find(t => t.id === inp.homeId || t.name === inp.home);
      const ta = inp.table.find(t => t.id === inp.awayId || t.name === inp.away);
      const gpAll = inp.table.reduce((a, t) => a + t.gp, 0) || 1;
      const avg = inp.table.reduce((a, t) => a + t.gf, 0) / gpAll || 1.35;
      if (th && ta && th.gp > 1 && ta.gp > 1) {
        const atH = (th.gf / th.gp) / avg, dfH = (th.ga / th.gp) / avg, atA = (ta.gf / ta.gp) / avg, dfA = (ta.ga / ta.gp) / avg;
        lh = clamp(avg * atH * dfA * 1.12, 0.25, 4); la = clamp(avg * atA * dfH * 0.9, 0.2, 4);
        const g = grid(lh, la);
        sources.push({ k: 'model', ar: 'نموذج روبو (الترتيب والأهداف)', w: 0.25, ...g });
        reasons.push(`${H} في المركز ${th.rank} (${th.pts} نقطة، ${th.gf}/${th.ga} أهداف) و${A} في المركز ${ta.rank} (${ta.pts} نقطة، ${ta.gf}/${ta.ga}).`);
        if (atH > 1.25) reasons.push(`هجوم ${H} أقوى من معدل الدوري بنسبة ${Math.round((atH - 1) * 100)}%.`);
        if (atA > 1.25) reasons.push(`هجوم ${A} أقوى من معدل الدوري بنسبة ${Math.round((atA - 1) * 100)}%.`);
        if (dfH < 0.75) reasons.push(`دفاع ${H} من الأصلب: يستقبل ${(th.ga / th.gp).toFixed(1)} هدف في المباراة.`);
        if (dfA < 0.75) reasons.push(`دفاع ${A} من الأصلب: يستقبل ${(ta.ga / ta.gp).toFixed(1)} هدف في المباراة.`);
      }
    }
    if (!sources.length) sources.push({ k: 'model', ar: 'نموذج روبو (أفضلية الأرض)', w: 0.12, ...grid(lh, la) });
    // form
    if (inp.formH || inp.formA) {
      const fh = formPts(inp.formH), fa = formPts(inp.formA), diff = (fh - fa) / 15;
      const ph = clamp(0.4 + diff * 0.45, 0.08, 0.85), pa = clamp(0.32 - diff * 0.45, 0.06, 0.85), pd = clamp(1 - ph - pa, 0.1, 0.4);
      const s = ph + pa + pd;
      sources.push({ k: 'form', ar: 'الفورمة (آخر 5 مباريات)', w: 0.15, home: ph / s, draw: pd / s, away: pa / s, extra: `${inp.formH || '—'} مقابل ${inp.formA || '—'}` });
      reasons.push(`آخر 5 مباريات: ${H} جمع ${fh} نقطة و${A} جمع ${fa} نقطة.`);
      lh *= 1 + diff * 0.12; la *= 1 - diff * 0.12;
    }
    // odds
    if (inp.odds && inp.odds.home != null && inp.odds.away != null) {
      const ph = ml2p(inp.odds.home), pa = ml2p(inp.odds.away), pd = ml2p(inp.odds.draw) || 0.25; const s = ph + pa + pd;
      sources.push({ k: 'odds', ar: `المراهنات (${inp.odds.provider || 'شركات المراهنة'})`, w: 0.32, home: ph / s, draw: pd / s, away: pa / s, extra: inp.odds.ou ? `خط الأهداف ${inp.odds.ou}` : '' });
      if (inp.odds.ou) { const tot = lh + la, target = inp.odds.ou - 0.35; lh *= target / tot; la *= target / tot; }
    }
    if (inp.poly) {
      sources.push({ k: 'poly', ar: 'سوق التوقعات Polymarket', w: 0.3, home: inp.poly.home, draw: inp.poly.draw, away: inp.poly.away, url: inp.poly.url, extra: inp.poly.volume ? `حجم التداول ${Math.round(inp.poly.volume).toLocaleString('en')}$` : '' });
    }
    // players
    const topG = l => { const g = (l || []).find(x => x.name === 'goals' || x.name === 'goalsLeaders'); return g && g.leaders && g.leaders[0]; };
    const sH = topG(inp.leadersH), sA = topG(inp.leadersA);
    const players = [];
    if (sH) players.push({ side: 'home', name: sH.athlete.displayName, goals: sH.value });
    if (sA) players.push({ side: 'away', name: sA.athlete.displayName, goals: sA.value });
    if (sH && sA) {
      const d = clamp((sH.value - sA.value) / 20, -0.15, 0.15);
      lh *= 1 + d; la *= 1 - d;
      reasons.push(`الهدّاف: ${sH.athlete.displayName} (${sH.value}) لـ${H} و${sA.athlete.displayName} (${sA.value}) لـ${A}.`);
    }
    // blend
    const W = sources.reduce((a, s) => a + s.w, 0);
    const fin = { home: 0, draw: 0, away: 0 };
    sources.forEach(s => { fin.home += s.home * s.w / W; fin.draw += s.draw * s.w / W; fin.away += s.away * s.w / W; });
    const pick = fin.home >= fin.away && fin.home >= fin.draw ? 'home' : fin.away >= fin.draw ? 'away' : 'draw';
    const g = grid(lh, la);
    const consistent = g.cells.find(c => pick === 'home' ? c.h > c.a : pick === 'away' ? c.a > c.h : c.h === c.a) || g.cells[0];
    const top = Math.max(fin.home, fin.draw, fin.away);
    const spread = Math.max(...sources.map(s => s[pick])) - Math.min(...sources.map(s => s[pick]));
    const confidence = clamp(Math.round((top - 0.33) / 0.5 * 100 * (1 - spread)), 8, 96);
    const pOver = 1 - g.cells.filter(c => c.h + c.a <= 2).reduce((a, c) => a + c.p, 0);
    const pBtts = g.cells.filter(c => c.h > 0 && c.a > 0).reduce((a, c) => a + c.p, 0);
    return { sources, fin, pick, score: consistent, lh, la, confidence, reasons, players, pOver, pBtts, H, A, topScores: g.cells.slice(0, 5) };
  }

  /* in-play: remaining-time Poisson from pre-match rates and current score */
  function livePredict(lh, la, minute, hs, as, redH = 0, redA = 0) {
    const left = Math.max(0, (95 - (minute || 0)) / 95);
    const kh = left * lh * Math.pow(0.72, redH) * Math.pow(1.18, redA), ka = left * la * Math.pow(0.72, redA) * Math.pow(1.18, redH);
    let H = 0, D = 0, A = 0;
    for (let i = 0; i <= 6; i++) for (let j = 0; j <= 6; j++) { const p = poisson(i, kh) * poisson(j, ka); const fh = hs + i, fa = as + j; if (fh > fa) H += p; else if (fh === fa) D += p; else A += p; }
    const t = H + D + A; return { home: H / t, draw: D / t, away: A / t };
  }
  YH.ai = { livePredict, styleLabel, analyze, predict, teamStats, shots, momentum, ratings, ml2p, names, AR, plays, playTeamSide, minuteOf };
})();
