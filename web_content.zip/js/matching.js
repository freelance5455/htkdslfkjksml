/**
 * matching.js
 * Filtra e ordena solicitações PUBLISHED para um profissional específico.
 * Regras de primeira geração (sem machine learning): filtros elimina­tórios
 * (categoria, status, capacidade simultânea) + ordenação por distância e
 * reputação. Documentado para evoluir depois com dados estatísticos reais.
 */
const Matching = {
  /**
   * @param {Object} provider — linha da tabela providers (já aprovado)
   * @param {Array} solicitacoes — solicitações com status PUBLISHED
   * @param {{lat:number,lng:number}|null} posicaoAtual — localização real do profissional (ou null)
   * @param {number} maxServicosSimultaneos — quantos ACCEPTED simultâneos o profissional pode ter
   */
  oportunidadesPara(provider, solicitacoes, posicaoAtual, maxServicosSimultaneos = 3){
    // Filtro eliminatório 1: categoria compatível
    let candidatas = solicitacoes.filter(s => provider.categorias.includes(s.categoria));

    // Filtro eliminatório 2: capacidade — profissional não pode estar sobrecarregado
    const emAndamento = DB.list('service_requests', s =>
      s.accepted_provider_id === provider.id &&
      [STATUS_SOLICITACAO.ACCEPTED, STATUS_SOLICITACAO.IN_PROGRESS].includes(s.status)
    ).length;
    if(emAndamento >= maxServicosSimultaneos){
      return { oportunidades: [], bloqueadoPorCapacidade: true };
    }

    // Filtro eliminatório 3: já demonstrou interesse? não mostrar de novo como "nova"
    const jaInteressado = new Set(
      DB.list('interests', i => i.provider_id === provider.id).map(i => i.service_request_id)
    );

    // Calcula distância (se houver posição do profissional e do imóvel) e monta score
    const comDistancia = candidatas.map(s => {
      const imovel = DB.find('properties', s.property_id);
      const dist = (posicaoAtual && imovel && imovel.latitude != null && imovel.longitude != null)
        ? distanciaKm(posicaoAtual.lat, posicaoAtual.lng, imovel.latitude, imovel.longitude)
        : null;
      return Object.assign({}, s, {
        _imovel: imovel,
        _distanciaKm: dist,
        _jaInteressado: jaInteressado.has(s.id),
      });
    });

    // Ordena: mais próximos primeiro (quando há distância), depois mais urgentes, depois mais recentes
    const pesoUrgencia = { 'Urgente (poucas horas)': 0, 'Hoje': 1, 'Programado': 2 };
    comDistancia.sort((a,b) => {
      if(a._distanciaKm != null && b._distanciaKm != null && a._distanciaKm !== b._distanciaKm){
        return a._distanciaKm - b._distanciaKm;
      }
      const pu = (pesoUrgencia[a.urgencia] ?? 2) - (pesoUrgencia[b.urgencia] ?? 2);
      if(pu !== 0) return pu;
      return new Date(b.created_at) - new Date(a.created_at);
    });

    return { oportunidades: comDistancia, bloqueadoPorCapacidade: false };
  },
};
