/* تسجيل Service Worker + زر إخفاء الأرصدة */
if('serviceWorker' in navigator&&/^https?:$/.test(location.protocol)){window.addEventListener('load',function(){navigator.serviceWorker.register('sw.js').catch(function(e){console.warn('SW:',e)})})}
(function(){var KEY='ayman_cashflow_privacy_v1';
 function apply(on){document.body.classList.toggle('privacy',on);var b=document.getElementById('privacyBtn');if(b)b.textContent=on?'👁 إظهار الأرصدة':'🙈 إخفاء الأرصدة'}
 function toggle(){var on=!document.body.classList.contains('privacy');AStore.setItem(KEY,on?'1':'0');apply(on)}
 var btn=document.createElement('button');btn.id='privacyBtn';btn.type='button';btn.onclick=toggle;btn.textContent='🙈 إخفاء الأرصدة';
 var h=document.querySelector('header');if(h)h.appendChild(btn);
 AStore.ready.then(function(){apply(AStore.getItem(KEY)==='1')});
})();
