const $ = (id) => document.getElementById(id);

const urlInput = $("gameUrl");
const frame = $("gameFrame");
const viewer = $("viewer");
const statusText = $("status");
const emptyState = $("emptyState");
let currentUrl = "";
let currentMode = "incorporado";

function setStatus(message, action = message) {
  statusText.textContent = message;
  $("lastAction").textContent = action;
}

function validateUrl(raw) {
  let parsed;
  try { parsed = new URL(raw.trim()); }
  catch { throw new Error("Endereço inválido. Inclua https:// ou http://."); }
  if (!["https:", "http:"].includes(parsed.protocol)) {
    throw new Error("Por segurança, use um endereço HTTP ou HTTPS.");
  }
  return parsed.href;
}

function loadEmbedded(raw) {
  try {
    const url = validateUrl(raw);
    currentUrl = url;
    currentMode = "incorporado";
    frame.hidden = false;
    emptyState.hidden = true;
    $("modeLabel").textContent = "Modo incorporado";
    setStatus("Solicitando abertura dentro do visualizador…", "Iframe solicitado");
    frame.src = "about:blank";
    requestAnimationFrame(() => { frame.src = url; });
  } catch (error) {
    setStatus(error.message, "URL não aceita");
  }
}

$("loadEmbedded").addEventListener("click", () => loadEmbedded(urlInput.value));
urlInput.addEventListener("keydown", (event) => {
  if (event.key === "Enter") loadEmbedded(urlInput.value);
});

$("loadExample").addEventListener("click", () => {
  urlInput.value = "https://example.com";
  loadEmbedded(urlInput.value);
});

$("openDirect").addEventListener("click", () => {
  try {
    const url = validateUrl(urlInput.value);
    currentUrl = url;
    currentMode = "direto";
    $("modeLabel").textContent = "Modo direto";
    setStatus("Solicitando navegação direta no WebView…", "Navegação direta solicitada");
    // Em um wrapper Android com WebView, esta navegação pode abrir o site
    // como página principal do WebView, sem depender de iframe.
    window.location.href = url;
  } catch (error) {
    setStatus(error.message, "URL não aceita");
  }
});

$("fullscreen").addEventListener("click", async () => {
  try {
    if (!document.fullscreenElement) await viewer.requestFullscreen();
    else await document.exitFullscreen();
    setStatus("Solicitação de tela cheia concluída.", "Tela cheia");
  } catch (error) {
    setStatus("Tela cheia não está disponível neste ambiente.", "Tela cheia indisponível");
  }
});

$("scale").addEventListener("input", (event) => {
  const value = Number(event.target.value);
  $("scaleValue").textContent = value + "%";
  $("scaleLabel").textContent = "Escala: " + value + "%";
  frame.style.transform = `scale(${value / 100})`;
});

$("resetScale").addEventListener("click", () => {
  $("scale").value = 100;
  $("scale").dispatchEvent(new Event("input"));
  setStatus("Escala restaurada para 100%.", "Escala restaurada");
});

$("landscape").addEventListener("click", async () => {
  try {
    if (screen.orientation && screen.orientation.lock) {
      await screen.orientation.lock("landscape");
      setStatus("Solicitação de orientação paisagem concluída.", "Paisagem");
    } else {
      setStatus("Este ambiente não oferece bloqueio de orientação pela página.", "Paisagem não suportada");
    }
  } catch (error) {
    setStatus("O navegador ou aplicativo não permitiu mudar a orientação.", "Paisagem recusada");
  }
});

frame.addEventListener("load", () => {
  // O evento load não confirma que o conteúdo interno foi aceito.
  setStatus("A navegação do quadro terminou. Confira se o conteúdo apareceu.", "Iframe carregado");
});

frame.addEventListener("error", () => {
  setStatus("O navegador informou uma falha ao carregar o quadro.", "Erro no iframe");
});

function updateDiagnostics() {
  $("platform").textContent = /Android/i.test(navigator.userAgent) ? "Android / navegador WebView possível" : "Navegador web";
  $("screenSize").textContent = `${window.innerWidth} × ${window.innerHeight}`;
  $("displayMode").textContent = document.fullscreenElement ? "Tela cheia" : "Janela";
}
window.addEventListener("resize", updateDiagnostics);
document.addEventListener("fullscreenchange", updateDiagnostics);
updateDiagnostics();

console.log("Linix Adapt Teste 0.1 iniciado.");
