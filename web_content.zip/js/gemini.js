(function () {
  'use strict';
  const P = (window.Pith = window.Pith || {});
  const U = P.util;
  const G = (P.gemini = {});

  // Hardcoded on purpose (project requirement). Anyone who opens the APK can read it,
  // so restrict the key in Google AI Studio / Cloud Console and put a spend cap on it.
  const API_KEY = 'AQ.Ab8RN6Kz80tLBedByzviBo8tusKMf61zpfT9YxiuxxyPdWxrbQ';
  const BASE = 'https://generativelanguage.googleapis.com/v1beta';

  G.TEXT_MODELS = [
    { id: 'gemini-3.8-flash', label: 'Gemini 3.8 Flash', hint: 'Newest Flash. Fast and capable.' },
    { id: 'gemini-flash-latest', label: 'Flash, auto-updating', hint: 'Always the current Flash model.' },
    { id: 'gemini-3.5-flash-lite', label: 'Gemini 3.5 Flash-Lite', hint: 'Fastest and cheapest.' },
    { id: 'gemini-4-argon', label: 'Gemini 4 Argon', hint: 'Most capable. Slower.' },
  ];
  G.IMAGE_MODELS = [
    { id: 'gemini-nano-banana-2.1', label: 'Nano Banana 2.1', hint: 'Fast images and edits.' },
    { id: 'gemini-3-pro-image', label: 'Nano Banana Pro', hint: 'Highest quality. Slower.' },
  ];
  const TEXT_FALLBACK = ['gemini-3.8-flash', 'gemini-flash-latest', 'gemini-3.6-flash'];
  const IMAGE_FALLBACK = ['gemini-nano-banana-2.1', 'gemini-3.1-flash-image'];
  G.TITLE_MODEL = 'gemini-3.5-flash-lite';
  G.BASE_INSTRUCTIONS = 'You are Pith, a clear and thoughtful assistant. Answer directly, use Markdown when it helps readability, put code in fenced blocks with a language tag, and reply in the language the user writes in.';

  class AiError extends Error {
    constructor(message, opts) {
      super(message);
      const o = opts || {};
      this.offline = !!o.offline;
      this.modelUnavailable = !!o.modelUnavailable;
      this.aborted = !!o.aborted;
    }
  }
  G.AiError = AiError;

  const chain = (selected, fallback) => [selected].concat(fallback.filter((m) => m !== selected));
  const headers = () => ({ 'Content-Type': 'application/json', 'x-goog-api-key': API_KEY });

  function emptyReason(finish) {
    if (['SAFETY', 'PROHIBITED_CONTENT', 'BLOCKLIST', 'SPII'].includes(finish)) return 'Gemini declined to answer this one. Try rephrasing the request.';
    if (finish === 'MAX_TOKENS') return 'The reply was cut off before it started. Try a shorter request.';
    return 'Gemini sent an empty reply. Try again.';
  }

  function errorFor(status, bodyText) {
    let message = '';
    try { const j = JSON.parse(bodyText); message = (j.error && j.error.message) || ''; } catch (e) { /* not json */ }
    const lower = message.toLowerCase();
    if (status === 404 || (status === 400 && (lower.includes('not found') || lower.includes('is not supported')))) {
      return new AiError(message || 'That Gemini model is not available.', { modelUnavailable: true });
    }
    if (status === 401 || status === 403) return new AiError('Gemini rejected the API key or this project cannot use the model. ' + message);
    if (status === 429) return new AiError('Gemini quota or rate limit reached. Wait a moment and try again.');
    if (status >= 500) return new AiError('Gemini is having trouble right now. Try again in a moment.');
    return new AiError(message || 'Gemini could not process that request.');
  }

  function mapNet(e, signal, timedOut) {
    if (timedOut) return new AiError('Gemini took too long to respond. Try again.');
    if (e && e.name === 'AbortError') return new AiError('Cancelled.', { aborted: true });
    if (signal && signal.aborted) return new AiError('Cancelled.', { aborted: true });
    if (e instanceof TypeError || /network|fetch|load failed/i.test(String(e && e.message))) {
      return new AiError('Could not reach Gemini. Check your connection.', { offline: true });
    }
    return new AiError('Something went wrong talking to Gemini: ' + (e && e.message ? e.message : e));
  }

  function body(system, contents, generationConfig) {
    const b = { contents };
    if (system && system.trim()) b.systemInstruction = { parts: [{ text: system }] };
    if (generationConfig) b.generationConfig = generationConfig;
    return JSON.stringify(b);
  }

  function partsOf(candidate) {
    return (candidate && candidate.content && candidate.content.parts) || [];
  }

  // Runs a fetch with an idle watchdog and an outer abort signal.
  function guarded(outer, idleMs) {
    const ctrl = new AbortController();
    let timer = null, timedOut = false;
    const arm = (ms) => { clearTimeout(timer); timer = setTimeout(() => { timedOut = true; ctrl.abort(); }, ms || idleMs); };
    const onAbort = () => ctrl.abort();
    if (outer) { if (outer.aborted) ctrl.abort(); else outer.addEventListener('abort', onAbort); }
    return {
      signal: ctrl.signal, arm,
      get timedOut() { return timedOut; },
      done() { clearTimeout(timer); if (outer) outer.removeEventListener('abort', onAbort); },
    };
  }

  async function streamOnce(model, system, contents, outer, onText) {
    const g = guarded(outer, 90000);
    g.arm(60000);
    let full = '', finish = null;
    const handle = (payload) => {
      if (!payload) return;
      let json;
      try { json = JSON.parse(payload); } catch (e) { return; }
      if (json.promptFeedback && json.promptFeedback.blockReason) {
        throw new AiError(`Gemini blocked this request (${json.promptFeedback.blockReason}). Try rephrasing it.`);
      }
      const cand = json.candidates && json.candidates[0];
      if (!cand) return;
      if (cand.finishReason) finish = cand.finishReason;
      let added = '';
      for (const part of partsOf(cand)) if (typeof part.text === 'string' && !part.thought) added += part.text;
      if (added) { full += added; onText(full); }
    };
    try {
      let res;
      try {
        res = await fetch(`${BASE}/models/${model}:streamGenerateContent?alt=sse`, { method: 'POST', headers: headers(), body: body(system, contents), signal: g.signal });
      } catch (e) { throw mapNet(e, outer, g.timedOut); }
      if (!res.ok) throw errorFor(res.status, await res.text().catch(() => ''));
      g.arm();
      if (!res.body || !res.body.getReader) {
        (await res.text()).split('\n').forEach((l) => { if (l.startsWith('data:')) handle(l.slice(5).trim()); });
      } else {
        const reader = res.body.getReader();
        const dec = new TextDecoder();
        let buf = '';
        try {
          for (;;) {
            const { done, value } = await reader.read();
            if (done) break;
            g.arm();
            buf += dec.decode(value, { stream: true });
            let at;
            while ((at = buf.indexOf('\n')) >= 0) {
              const line = buf.slice(0, at).replace(/\r$/, '');
              buf = buf.slice(at + 1);
              if (line.startsWith('data:')) handle(line.slice(5).trim());
            }
          }
          buf += dec.decode();
          if (buf.startsWith('data:')) handle(buf.slice(5).trim());
        } catch (e) {
          if (e instanceof AiError) throw e;
          const mapped = mapNet(e, outer, g.timedOut);
          if (mapped.aborted) return { text: full, aborted: true };
          throw mapped;
        }
      }
      if (!full && !(outer && outer.aborted)) throw new AiError(emptyReason(finish));
      return { text: full, aborted: !!(outer && outer.aborted) };
    } finally { g.done(); }
  }

  G.stream = async function (opts) {
    let last;
    for (const model of chain(opts.model, TEXT_FALLBACK)) {
      try { return await streamOnce(model, opts.system, opts.contents, opts.signal, opts.onText); }
      catch (e) {
        if (e.modelUnavailable && !(opts.signal && opts.signal.aborted)) { last = e; continue; }
        throw e;
      }
    }
    throw last || new AiError('No Gemini model is available for this key.');
  };

  async function generate(model, system, contents, generationConfig, outer, idleMs) {
    const g = guarded(outer, idleMs);
    g.arm();
    try {
      let res;
      try {
        res = await fetch(`${BASE}/models/${model}:generateContent`, { method: 'POST', headers: headers(), body: body(system, contents, generationConfig), signal: g.signal });
      } catch (e) { throw mapNet(e, outer, g.timedOut); }
      const text = await res.text().catch(() => '');
      if (!res.ok) throw errorFor(res.status, text);
      let json;
      try { json = JSON.parse(text); } catch (e) { throw new AiError('Gemini returned an unexpected response.'); }
      if (json.promptFeedback && json.promptFeedback.blockReason) {
        throw new AiError(`Gemini blocked this request (${json.promptFeedback.blockReason}). Try rephrasing it.`);
      }
      const cand = json.candidates && json.candidates[0];
      let out = '';
      const images = [];
      for (const part of partsOf(cand)) {
        if (part.thought) continue;
        if (typeof part.text === 'string') out += part.text;
        const inline = part.inlineData || part.inline_data;
        if (inline && inline.data) images.push({ mime: inline.mimeType || inline.mime_type || 'image/png', data: inline.data });
      }
      if (!out && !images.length && cand && cand.finishReason) throw new AiError(emptyReason(cand.finishReason));
      return { text: out.trim(), images };
    } finally { g.done(); }
  }

  G.image = async function (opts) {
    let last;
    for (const model of chain(opts.model, IMAGE_FALLBACK)) {
      try {
        const r = await generate(model, null, opts.contents, { responseModalities: ['TEXT', 'IMAGE'] }, opts.signal, 150000);
        if (!r.images.length) throw new AiError(r.text || 'No image came back. Try describing the picture differently.');
        return r;
      } catch (e) {
        if (e.modelUnavailable && !(opts.signal && opts.signal.aborted)) { last = e; continue; }
        throw e;
      }
    }
    throw last || new AiError('No Gemini image model is available for this key.');
  };

  G.quickText = async function (prompt) {
    let last;
    for (const model of chain(G.TITLE_MODEL, TEXT_FALLBACK)) {
      try {
        const r = await generate(model, null, [{ role: 'user', parts: [{ text: prompt }] }], null, null, 25000);
        return r.text;
      } catch (e) { if (e.modelUnavailable) { last = e; continue; } throw e; }
    }
    throw last || new AiError('No Gemini model is available for this key.');
  };

  G.part = {
    text: (t) => ({ text: t }),
    inline: (mime, b64) => ({ inlineData: { mimeType: mime, data: b64 } }),
  };
})();
