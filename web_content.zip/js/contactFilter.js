/**
 * contactFilter.js
 * Detecta tentativas de compartilhar contato externo em mensagens do chat.
 * É aplicado NO SERVIÇO (ChatService.enviarMensagem), não só na tela — ou
 * seja, mesmo chamando a função diretamente (sem passar pela UI) a mensagem
 * bloqueada não é gravada. Isso cumpre "proteção no frontend E backend" na
 * medida do que existe aqui: como não há um servidor separado, o "backend"
 * real deste projeto é esta camada de serviço, que é o único caminho por
 * onde uma mensagem chega ao banco.
 */
const ContactFilter = {

  MENSAGEM_BLOQUEIO: 'Por segurança, contatos externos não podem ser compartilhados. Toda negociação deve permanecer dentro do Anjo da Guarda.',

  // Palavras-chave de redes/apps de mensagem e domínios comuns
  PALAVRAS_CHAVE: [
    'whatsapp', 'whats app', 'wpp', 'zap', 'zapzap', 'zap zap',
    'telegram', 'telegram.me', 't.me',
    'instagram', 'insta', '@instagram',
    'facebook', 'messenger',
    'gmail', 'hotmail', 'outlook', 'yahoo',
    '.com', '.com.br', '.net', '.org',
    'http://', 'https://', 'www.',
  ],

  // Números por extenso (heurística simples, cobre sequências comuns em PT-BR)
  NUMEROS_EXTENSO: ['zero','um','uma','dois','duas','tres','três','quatro','cinco','seis','sete','oito','nove'],

  analisar(texto){
    const motivos = [];
    const t = (texto || '').toLowerCase();

    // Telefone: 10-11 dígitos seguidos, com ou sem separadores (espaço, hífen, parênteses, ponto)
    const digitosLimpos = t.replace(/[^\d]/g, '');
    const janelasDigitos = digitosLimpos.match(/\d{10,11}/g);
    if(janelasDigitos && janelasDigitos.length){
      motivos.push('Número de telefone detectado');
    }
    // Padrões explícitos com separadores (reforço, cobre "11 99999-9999", "(11)99999-9999" etc.)
    if(/\(?\d{2}\)?[\s.-]?9?\d{4}[\s.-]?\d{4}/.test(t)){
      if(!motivos.includes('Número de telefone detectado')) motivos.push('Número de telefone detectado');
    }

    // E-mail
    if(/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/i.test(texto || '')){
      motivos.push('E-mail detectado');
    }

    // @usuario (redes sociais) — mas não confundir com e-mail já capturado acima
    if(/(?<!\S)@[a-z0-9_.]{3,}/i.test(texto || '') && !motivos.includes('E-mail detectado')){
      motivos.push('Usuário de rede social (@) detectado');
    }

    // URLs
    if(/https?:\/\/\S+|www\.\S+/i.test(t)){
      motivos.push('Link/URL detectado');
    }

    // Palavras-chave de apps/domínios
    const achadas = this.PALAVRAS_CHAVE.filter(p => t.includes(p));
    if(achadas.length){
      motivos.push('Menção a canal externo: ' + achadas.slice(0,3).join(', '));
    }

    // Números por extenso em sequência (heurística: 4+ ocorrências de palavras-número no texto)
    const palavras = t.split(/[\s,.-]+/);
    const qtdNumEscrito = palavras.filter(p => this.NUMEROS_EXTENSO.includes(p)).length;
    if(qtdNumEscrito >= 4){
      motivos.push('Possível número de telefone escrito por extenso');
    }

    return { bloqueado: motivos.length > 0, motivos };
  },
};
