                                        
                                                                           
                                                                               
                                                                      
                                                    

                                                             
                                                    
                                                                                              
                                                               
                                                                              
                                                                                                 
                                                                                   

                                                                    
                                                                 
                                               

                                                                          
                                    

                                                                           
                                                              

window.Cenario = {
    me: {
        name: 'Morajo',
        avatar: 'pfp/morajo.png',
        status: 'online',
        phone: "(56) 1.21.20.15-9.13.21.14.5",
        about: "Alguém realmente lê isso?"
    },

    contacts: {
        torajo: {
            name: "Torajo",
            avatar: 'pfp/torajo.png',
            status: 'online',
            phone: "(56) 15.20.9.13-9.19.20.1",
            about: "Apesar de tudo, ainda é você.",
            unread: 0,
            initialNode: 'torajo_idle',
            messages: []
        },
        linn: {
            name: "Linn",
            avatar: 'pfp/linn.png',
            status: 'online',
            phone: "(56) 19.9.12.5-14.3.9.15",
            about: "\"O verdadeiro encanto é a gentileza. Seja uma boa pessoa, só isso.\" - Reigen Mob",
            unread: 0,
            initialNode: 'linn_idle',
            messages: []
        },
        zulmi: {
            name: "Zulmi",
            avatar: 'pfp/zulmi.png',
            status: 'offline',
            phone: "(56) 6.15.6.15-3.1.18",
            about: "Eu não preciso de holofotes, porque eu tenho meu próprio brilho! ✨",
            unread: 0,
            initialNode: 'zulmi_idle',
            messages: []
        },
        margo: {
            name: "Margo",
            avatar: 'pfp/margo.png',
            status: 'online',
            phone: "(56) 3.1.18.9-19.13.1",
            about: "Eu sou a diva que você quer ser, xuxu💋",
            unread: 0,
            initialNode: 'margo_idle',
            messages: []
        },
        jay: {
            name: "Jay",
            avatar: 'pfp/jay.png',
            status: 'offline',
            phone: "(56) 18.5.16.15-18.20.5.18",
            about: "No trabalho. Ligue apenas em caso de emergência.",
            unread: 0,
            initialNode: 'jay_idle',
            messages: []
        },
        azedo: {
            name: "Azedo",
            avatar: 'pfp/azedo.png',
            status: 'online',
            phone: "(56) 5.19.20.18-5.12.1",
            about: "maior farmador de aura de verade 🗿🍷",
            unread: 0,
            initialNode: 'azedo_idle',
            messages: []
        },
        pessy: {
            name: "Pessy",
            avatar: 'pfp/pessy.png',
            status: 'offline',
            phone: "(56) 13.9.19.20-5.18.9.15",
            about: "221B Baker Street",
            unread: 0,
            initialNode: 'pessy_idle',
            messages: []
        },
        pai: {
            name: 'Pai',
            avatar: 'pfp/Arthur.png',
            status: 'offline',
            phone: "(56) 3.15.26.9-14.8.1",
            about: "Olá! Eu estou usando zap!",
            unread: 0,
            initialNode: 'pai_idle',
            messages: []
        },
        mae: {
            name: 'Mãe',
            avatar: 'pfp/Maya.png',
            status: 'offline',
            phone: "(56) 3.1.18.9-14.8.15",
            about: "Colecionando reticências e buscando um ponto final para essa história 😘🥰📚",
            unread: 0,
            initialNode: 'mae_idle',
            messages: []
        }
    },

    nodes: {
                                                                             
        mae_idle: { choices: [] },
        torajo_idle: { choices: [] },
        linn_idle: { choices: [] },
        zulmi_idle: { choices: [] },
        margo_idle: { choices: [] },
        jay_idle: { choices: [] },
        azedo_idle: { choices: [] },
        pessy_idle: { choices: [] },
        pai_idle: { choices: [] }

    },

    events: [
        { time: '03:15', type: 'call', contact: 'mae' }
    ],

                                               
                                                                        
                                                                             
                                                                          
                                                                         
                                           
    social: {
        me: 'morajo',

        accounts: {
            morajo: {
                name: 'Morajo',
                handle: 'Morajo_',
                avatar: 'pfp/morajo.png',
                bio: 'não me chama de nerd. 🍎',
                banner: ['#ff4545', '#5df7f3'],
                followers: 1204,
                following: 87,
                joined: 'entrou em junho de 2021'
            },
            torajo: {
                name: 'Torajo',
                handle: 'Torajo',
                avatar: 'pfp/torajo.png',
                bio: '🍏 criador do Mundo Torajo | meus queridos amigos...',
                banner: ['#39d353', '#0d1117'],
                followers: 3200000,
                following: 91,
                joined: 'entrou em maio de 2021',
                verified: true
            },
            margo: {
                name: 'Margo',
                handle: 'Margo_morango',
                avatar: 'pfp/margo.png',
                bio: '🎀 diretora de marketing (confia) | só falo por áudio',
                banner: ['#e15585', '#86ed98'],
                followers: 48200,
                following: 312,
                joined: 'entrou em fevereiro de 2026'
            },
            pessy: {
                name: 'Pessy',
                handle: 'PessyHolmes',
                avatar: 'pfp/pessy.png',
                bio: '🔍 detetive | caderno de teorias | na dúvida, vota no Morajo',
                banner: ['#f97e3c', '#000076'],
                followers: 76400,
                following: 128,
                joined: 'entrou em novembro de 2024'
            },
            jay: {
                name: 'Jay',
                handle: 'JayNews',
                avatar: 'pfp/jay.png',
                bio: '🎙️ jornalista em formação | organizo o caos | sem tempo livre',
                banner: ['#1c0e31', '#f3ecfc'],
                followers: 33800,
                following: 205,
                joined: 'entrou em maio de 2025'
            },
            linn: {
                name: 'Linn',
                handle: 'LinnMao',
                avatar: 'pfp/linn.png',
                bio: '🍋 animes, ukulele e dormir o dia inteiro | cadê o Linn?',
                banner: ['#fff1a9', '#ed1f13'],
                followers: 92100,
                following: 64,
                joined: 'entrou em abril de 2024'
            },
            azedo: {
                name: 'Azedo',
                handle: 'AzedoAmaNorguet',
                avatar: 'pfp/azedo.png',
                bio: '🍋‍🟩 EU SOU UMA ESTRELA!! sigma | nuggets | rock 🤘',
                banner: ['#131412', '#5f9b2d'],
                followers: 12900,
                following: 401,
                joined: 'entrou em julho de 2024'
            },
            zulmi: {
                name: 'Zulmi',
                handle: 'ZulmiStar',
                avatar: 'pfp/zulmi.png',
                bio: '⭐ fofoca mal contada é mais pecado que fofoca! | astronomia',
                banner: ['#5a68e1', '#ffff82'],
                followers: 88300,
                following: 173,
                joined: 'entrou em janeiro de 2024'
            },

        },

        posts: [
            {
                id: 'p-torajo-1', author: 'torajo', time: '8 dias',
                text: '',
                likes: 0, reposts: 0
            },
            {
                id: 'p-zulmi-1', author: 'zulmi', time: '8 dias',
                text: '',
                likes: 0, reposts: 0
            },
            {
                id: 'p-morajo-1', author: 'morajo', time: '8 dias',
                text: '',
                likes: 0, reposts: 0
            },
            {
                id: 'p-linn-1', author: 'linn', time: '8 dias',
                text: '',
                likes: 0, reposts: 0
            },
            {
                id: 'p-azedo-1', author: 'azedo', time: '8 dias',
                text: '',
                likes: 0, reposts: 0
            },
            {
                id: 'p-jay-1', author: 'jay', time: '8 dias',
                text: '',
                likes: 0, reposts: 0
            },
            {
                id: 'p-pessy-1', author: 'pessy', time: '8 dias',
                text: '',
                likes: 0, reposts: 0
            },
            {
                id: 'p-margo-1', author: 'margo', time: '8 dias',
                text: '',
                likes: 0, reposts: 0
            },
            {
                id: 'p-torajo-2', author: 'torajo', time: '8 dias',
                text: '',
                likes: 0, reposts: 0
            },
            {
                id: 'p-linn-2', author: 'linn', time: '8 dias',
                text: '',
                likes: 0, reposts: 0
            },
            {
                id: 'p-zulmi-2', author: 'zulmi', time: '8 dias',
                text: '',
                likes: 0, reposts: 0
            },
            {
                id: 'p-azedo-2', author: 'azedo', time: '8 dias',
                text: '',
                likes: 0, reposts: 0
            },
            {
                id: 'p-jay-2', author: 'jay', time: '8 dias',
                text: '',
                likes: 0, reposts: 0
            },
            {
                id: 'p-pessy-2', author: 'pessy', time: '8 dias',
                text: '',
                likes: 0, reposts: 0
            },
            {
                id: 'p-margo-2', author: 'margo', time: '8 dias',
                text: '',
                likes: 0, reposts: 0
            },
            {
                id: 'p-torajo-3', author: 'torajo', time: '8 dias',
                text: '',
                likes: 0, reposts: 0
            },
            {
                id: 'p-azedo-3', author: 'azedo', time: '8 dias',
                text: '',
                likes: 0, reposts: 0
            },
            {
                id: 'p-linn-3', author: 'linn', time: '8 dias',
                text: '',
                likes: 0, reposts: 0
            },
            {
                id: 'p-morajo-2', author: 'morajo', time: '8 dias',
                text: '',
                likes: 0, reposts: 0
            },
            {
                id: 'p-zulmi-3', author: 'zulmi', time: '8 dias',
                text: '',
                likes: 0, reposts: 0
            },

        ],

        notifications: []
    }
};

(function (S) {
    S.SCENARIO = window.Cenario;
})(window.Celular = window.Celular || {});
