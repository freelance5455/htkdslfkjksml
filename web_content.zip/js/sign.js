/* assinatura: desenhar, escrever ou importar → imagem PNG transparente, recortada ao traço */
/* estilos do separador "Escrever": [nome, fonte ({n} = tamanho), fator de tamanho, família instalável, ficheiro em fonts/]
   French Script MT e Kunstler Script são fontes do Windows/Office: usa a fonte instalada ou os ficheiros em fonts/ (ver fonts/README.txt) */
const SGST=[['Manuscrita','italic 400 {n}px "Segoe Script","Bradley Hand","Snell Roundhand","Brush Script MT",cursive',1],
['French Script MT','400 {n}px "CV French Script","French Script MT",cursive',1.3,'French Script MT','frscript.ttf'],
['Künstler Script','400 {n}px "CV Kunstler Script","Kunstler Script",cursive',1.3,'Kunstler Script','kunstler.ttf']];
(()=>{const st=document.createElement('style');st.textContent="@font-face{font-family:'CV French Script';src:local('French Script MT'),local('FrenchScriptMT'),url(fonts/frscript.ttf),url(fonts/FRSCRIPT.TTF)}@font-face{font-family:'CV Kunstler Script';src:local('Kunstler Script'),local('KunstlerScript'),url(fonts/kunstler.ttf),url(fonts/KUNSTLER.TTF)}";document.head.append(st)})();
/* confirma se a fonte do estilo está disponível (instalada ou em fonts/); o resultado fica guardado */
const SGOK={};
function sgFont(i){const e=SGST[i];if(!e[3])return Promise.resolve(true);if(i in SGOK)return Promise.resolve(SGOK[i]);
return Promise.race([document.fonts.load(e[1].replace('{n}',40),'Abc').then(r=>r.length>0),new Promise(r=>setTimeout(()=>r(false),4000))]).catch(()=>false).then(ok=>SGOK[i]=ok)}
const SGCOL=['#111111','#1d3fd8','#d61f1f'];
/* recorta a área com traço (alfa > 0) e limita a largura */
function sgCrop(cv){const w=cv.width,h=cv.height,d=cv.getContext('2d').getImageData(0,0,w,h).data;let x0=w,y0=h,x1=-1,y1=-1;
for(let y=0;y<h;y++)for(let x=0;x<w;x++)if(d[(y*w+x)*4+3]>8){if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y}
if(x1<0)return null;const p=6;x0=Math.max(0,x0-p);y0=Math.max(0,y0-p);x1=Math.min(w-1,x1+p);y1=Math.min(h-1,y1+p);
const cw=x1-x0+1,ch=y1-y0+1,k=Math.min(1,800/cw),o=document.createElement('canvas');o.width=Math.max(1,Math.round(cw*k));o.height=Math.max(1,Math.round(ch*k));
const c=o.getContext('2d');c.imageSmoothingQuality='high';c.drawImage(cv,x0,y0,cw,ch,0,0,o.width,o.height);return o.toDataURL('image/png')}
/* torna o fundo branco/claro transparente, mantendo a cor do traço */
function sgClean(cv){const c=cv.getContext('2d'),im=c.getImageData(0,0,cv.width,cv.height),d=im.data;
for(let i=0;i<d.length;i+=4){if(d[i+3]<8)continue;const m=Math.min(d[i],d[i+1],d[i+2]);if(m>=232)d[i+3]=0;else if(m>=170)d[i+3]=Math.round(d[i+3]*(232-m)/62)}c.putImageData(im,0,0)}
function signDlg(cur){return new Promise(done=>{
const o=document.createElement('div');o.id='sgd';
o.innerHTML=`<div class="box"><div class="sgh"><b>Assinatura</b><button type="button" class="sgx" aria-label="Fechar">✕</button></div>
<div class="sgt"><button type="button" data-t="draw" class="on">Desenhar</button><button type="button" data-t="type">Escrever</button><button type="button" data-t="up">Importar</button></div>
<div class="sgp" data-p="draw"><canvas width="1200" height="600"></canvas><div class="sgc">${SGCOL.map((c,i)=>`<button type="button" class="dot${i?'':' on'}" data-c="${c}" style="background:${c}" aria-label="Cor"></button>`).join('')}<button type="button" class="er un">↶ Desfazer</button><button type="button" class="er">⌫ Apagar</button></div></div>
<div class="sgp" data-p="type" hidden><input class="sgi" placeholder="Escreva o seu nome" autocomplete="off"><div class="sgst">${SGST.map((s,i)=>`<button type="button" data-s="${i}"${i?'':' class="on"'}>${s[0]}</button>`).join('')}</div><p class="sgn" hidden></p><canvas width="1200" height="400" class="pv"></canvas><div class="sgc">${SGCOL.map((c,i)=>`<button type="button" class="dot${i?'':' on'}" data-c="${c}" style="background:${c}" aria-label="Cor"></button>`).join('')}</div></div>
<div class="sgp" data-p="up" hidden><button type="button" class="sgf">Escolher imagem da assinatura…</button><input type="file" accept="image/*" hidden><canvas width="1200" height="400" class="pv"></canvas><label class="sgk"><input type="checkbox" checked> Remover fundo branco</label><small>Dica: assine em papel branco, com caneta escura, e fotografe com boa luz.</small></div>
<div class="acts"><button type="button" class="pri sgok">Concluir</button></div></div>`;
document.body.append(o);
const $$=s=>o.querySelector(s),pane=t=>$$(`[data-p="${t}"]`);let tab='draw',col=SGCOL[0],sty=0,up=null;
const dv=pane('draw').querySelector('canvas'),dc=dv.getContext('2d'),tv=pane('type').querySelector('canvas'),uv=pane('up').querySelector('canvas');let ink=false;
/* desenhar: o traço é guardado como pontos (x, y, espessura) e desenhado como curva suave (Catmull-Rom → Bézier)
   com "carimbos" redondos densos: sem cantos, espessura que varia com a velocidade (ou a pressão da caneta), como tinta.
   Como o desenho é vetorial, trocar a cor repinta a assinatura inteira. */
const pt=e=>{const r=dv.getBoundingClientRect();return[(e.clientX-r.left)*dv.width/r.width,(e.clientY-r.top)*dv.height/r.height]};
dv.style.touchAction='none';
const strokes=[],WMAX=9.5,WMIN=3.6;let cur=null,rawP=null,lastT=0;
/* traça o segmento i→i+1 de P (spline que passa pelos pontos); devolve o número de carimbos */
function segPath(c,P,i){const p0=P[Math.max(0,i-1)],p1=P[i],p2=P[i+1],p3=P[Math.min(P.length-1,i+2)],
c1x=p1.x+(p2.x-p0.x)/6,c1y=p1.y+(p2.y-p0.y)/6,c2x=p2.x-(p3.x-p1.x)/6,c2y=p2.y-(p3.y-p1.y)/6,n=Math.max(1,Math.ceil(Math.hypot(p2.x-p1.x,p2.y-p1.y)/1.2));
for(let k=0;k<=n;k++){const t=k/n,u=1-t,x=u*u*u*p1.x+3*u*u*t*c1x+3*u*t*t*c2x+t*t*t*p2.x,y=u*u*u*p1.y+3*u*u*t*c1y+3*u*t*t*c2y+t*t*t*p2.y,r=(p1.w+(p2.w-p1.w)*t)/2;c.moveTo(x+r,y);c.arc(x,y,r,0,6.2832)}}
function dot(c,p){c.moveTo(p.x+p.w/2,p.y);c.arc(p.x,p.y,p.w/2,0,6.2832)}
function paintStroke(P){dc.beginPath();if(P.length==1)dot(dc,P[0]);else for(let i=0;i<P.length-1;i++)segPath(dc,P,i);dc.fill()}
function redraw(){dc.clearRect(0,0,dv.width,dv.height);dc.fillStyle=col;for(const P of strokes)paintStroke(P)}
/* acrescenta um ponto bruto: filtra tremor, suaviza a posição e a espessura */
function addPt(x,y,t,pr){const q=cur[cur.length-1];if(!q){const w=pr?WMIN+(WMAX-WMIN)*pr:7;cur.push({x,y,w});rawP=[x,y];lastT=t;return false}
const d=Math.hypot(x-rawP[0],y-rawP[1]);if(d<1.5)return false;
const v=d/Math.max(1,t-lastT),tw=pr?WMIN+(WMAX-WMIN)*pr:Math.max(WMIN,Math.min(WMAX,WMAX-2.6*v));
rawP=[x,y];lastT=t;cur.push({x:q.x+(x-q.x)*.5,y:q.y+(y-q.y)*.5,w:q.w+(tw-q.w)*.3});return true}
function inc(){const P=cur,n=P.length;if(n==1){dc.beginPath();dot(dc,P[0]);dc.fill()}else if(n>=3){dc.beginPath();segPath(dc,P,n-3);dc.fill()}}
dv.onpointerdown=e=>{e.preventDefault();try{dv.setPointerCapture(e.pointerId)}catch{}cur=[];strokes.push(cur);dc.fillStyle=col;const p=pt(e);addPt(p[0],p[1],e.timeStamp,e.pointerType=='pen'&&e.pressure>0?e.pressure:0);inc();ink=true};
dv.onpointermove=e=>{if(!cur)return;e.preventDefault();dc.fillStyle=col;const ev=(e.getCoalescedEvents&&e.getCoalescedEvents())||[];
for(const q of ev.length?ev:[e]){const p=pt(q);if(addPt(p[0],p[1],q.timeStamp,q.pointerType=='pen'&&q.pressure>0?q.pressure:0))inc()}};
dv.onpointerup=dv.onpointercancel=e=>{if(!cur)return;if(rawP){const q=cur[cur.length-1];if(cur.length>1&&Math.hypot(rawP[0]-q.x,rawP[1]-q.y)>.5)cur.push({x:rawP[0],y:rawP[1],w:q.w})}cur=null;redraw()};
/* escrever */
const ti=$$('.sgi');ti.value=(cur&&cur.text)||(typeof D!='undefined'&&D.full_name)||'';
function typeDraw(){const c=tv.getContext('2d');c.clearRect(0,0,tv.width,tv.height);const t=ti.value.trim();if(!t)return;let n=Math.round(190*(SGST[sty][2]||1));c.textBaseline='middle';c.font=SGST[sty][1].replace('{n}',n);
const w=c.measureText(t).width;if(w>tv.width-60){n=Math.floor(n*(tv.width-60)/w);c.font=SGST[sty][1].replace('{n}',n)}c.fillStyle=col;c.textAlign='center';c.fillText(t,tv.width/2,tv.height/2)}
ti.oninput=typeDraw;
const note=pane('type').querySelector('.sgn');
function typeShow(){const i=sty;typeDraw();sgFont(i).then(ok=>{if(i!=sty)return;const e=SGST[i];note.hidden=ok;if(!ok)note.textContent='A fonte '+e[0]+' não está instalada neste dispositivo. Instale-a ou copie '+e[4]+' para a pasta fonts/.';typeDraw()})}
/* importar */
const fi=pane('up').querySelector('input[type=file]'),ck=pane('up').querySelector('.sgk input');
function upDraw(){const c=uv.getContext('2d');c.clearRect(0,0,uv.width,uv.height);if(!up)return;const k=Math.min(uv.width/up.width,uv.height/up.height,1),w=up.width*k,h=up.height*k;c.drawImage(up,(uv.width-w)/2,(uv.height-h)/2,w,h);if(ck.checked)sgClean(uv)}
pane('up').querySelector('.sgf').onclick=()=>fi.click();ck.onchange=upDraw;
fi.onchange=()=>{const f=fi.files[0];if(!f)return;const u=URL.createObjectURL(f),im=new Image();im.onload=()=>{up=im;upDraw();URL.revokeObjectURL(u)};im.onerror=()=>alert('Não foi possível abrir esta imagem.');im.src=u;fi.value=''};
const show=t=>{tab=t;o.querySelectorAll('.sgt button').forEach(b=>b.classList.toggle('on',b.dataset.t==t));['draw','type','up'].forEach(x=>pane(x).hidden=x!=t);if(t=='type')typeShow()};
const close=r=>{o.remove();done(r)};
o.onclick=e=>{const b=e.target.closest('button');if(e.target==o)return close(null);if(!b)return;
if(b.classList.contains('sgx'))return close(null);
if(b.dataset.t)return show(b.dataset.t);
if(b.dataset.c){col=b.dataset.c;b.closest('.sgc').querySelectorAll('.dot').forEach(x=>x.classList.toggle('on',x==b));o.querySelectorAll('.dot').forEach(x=>x.classList.toggle('on',x.dataset.c==col));if(tab=='type')typeDraw();else if(tab=='draw')redraw();return}
if(b.classList.contains('un')){strokes.pop();redraw();ink=strokes.length>0;return}
if(b.classList.contains('er')){strokes.length=0;redraw();ink=false;return}
if(b.dataset.s!==undefined){sty=+b.dataset.s;o.querySelectorAll('.sgst button').forEach(x=>x.classList.toggle('on',x==b));typeShow();return}
if(b.classList.contains('sgok')){const cv=tab=='draw'?dv:tab=='type'?tv:uv;if(tab=='type')typeDraw();const img=sgCrop(cv);if(!img){alert(tab=='draw'?'Desenhe a assinatura primeiro.':tab=='type'?'Escreva o seu nome primeiro.':'Escolha primeiro uma imagem.');return}
close({img,mode:tab,text:ti.value.trim()})}};
});}
