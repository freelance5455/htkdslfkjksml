/* راه‌اندازی: بارگذاری وضعیت، اعمال ظاهر، پشتیبان خودکار، زمان‌سنج، دکمه‌های شناور، خطاهای سراسری و ثبت سرویس‌ورکر. */
(function () {
  'use strict';
  var App = (window.App = window.App || {});
  var ui = App.ui;
  var errShown = false;

  // دکمه‌ی 💬: پنجره‌ی مشاور روی همه‌ی تب‌ها (در تب مشاور، فقط فوکوس روی کادر)
  App.act['fab-chat'] = function () {
    if (ui.tab === 'ai') {
      var i = document.getElementById('chat-in');
      if (i) i.focus();
      return;
    }
    ui.sheet = !ui.sheet;
    App.render();
    if (ui.sheet) {
      var box = document.getElementById('chat-in');
      if (box) box.focus();
    }
  };
  // دکمه‌ی 🎙: گفتن مستقیم برای مشاور (متن در کادر گفتگو ساخته می‌شود)
  App.act['fab-mic'] = function (el) {
    if (App.voice && App.voice.on) { App.voice.stop(); return; }
    if (ui.tab !== 'ai' && !ui.sheet) { ui.sheet = true; App.render(); }
    if (App.voice && App.voice.toggle) App.voice.toggle(el, 'chat-in', 'chatf.txt');
  };

  // خطاهای پیش‌بینی‌نشده: یک بار پیام فارسی، بدون از دست رفتن داده
  function onFail(err) {
    App.logError(err);
    if (errShown) return;
    errShown = true;
    if (App.toast) App.toast('یک خطای غیرمنتظره رخ داد. داده‌ها دست نخورده‌اند؛ اگر تکرار شد، صفحه را دوباره باز کن.', { kind: 'err', ms: 7000 });
    setTimeout(function () { errShown = false; }, 30000);
  }
  window.addEventListener('error', function (e) { onFail(e.error || e.message); });
  window.addEventListener('unhandledrejection', function (e) { onFail(e.reason); });

  function registerSW() {
    if (!('serviceWorker' in navigator)) return;
    if (!/^https?:$/.test(location.protocol)) return; // در فایل محلی یا WebView بدون http، لازم نیست
    try {
      navigator.serviceWorker.register('sw.js').catch(function () { /* آفلاین نشد؛ برنامه بدون آن کار می‌کند */ });
    } catch (e) { /* ignore */ }
  }

  function boot() {
    try { App.store.load(); }
    catch (e) { App.logError(e); }
    if (!App.S) App.S = App.store.defaults();
    App.applyPrefs();
    try { App.backup.maybeSnapshot(); } catch (e) { App.logError(e); }
    if (App.timer) App.timer.boot();
    ui.tab = 'today';
    App.render();
    if (App.remind) App.remind.boot();
    setInterval(function () { App.tickClock(); }, 30000);
    document.addEventListener('visibilitychange', function () {
      if (!document.hidden) { App.tickClock(); if (App.timer) App.timer.tick(); }
    });
    if (window.matchMedia) {
      var mq = window.matchMedia('(prefers-color-scheme: dark)');
      var onMq = function () { App.applyPrefs(); };
      if (mq.addEventListener) mq.addEventListener('change', onMq);
      else if (mq.addListener) mq.addListener(onMq);
    }
    registerSW();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
