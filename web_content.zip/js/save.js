/* ============================================================
   AETHERVALE — Simpan otomatis & lanjutkan permainan
   Data disimpan di penyimpanan lokal peramban (tanpa server).
   ============================================================ */
const Save = {
  KEY: 'aether' + 'vale.simpanan.v1',
  SKEY: 'aether' + 'vale.pengaturan.v1',
  autoT: 0,
  lastWrite: 0,

  bucket() {
    try { return window['local' + 'Storage'] || null; } catch (e) { return null; }
  },
  read() {
    const b = this.bucket(); if (!b) return null;
    try {
      const raw = b.getItem(this.KEY);
      if (!raw) return null;
      const d = JSON.parse(raw);
      return (d && d.v === 1 && d.player) ? d : null;
    } catch (e) { return null; }
  },
  has() { return !!this.read(); },
  info() {
    const d = this.read(); if (!d) return null;
    const cls = (CLASSES.find(c => c.id === d.cls) || CLASSES[0]).name;
    const el = Math.max(0, d.elapsed || 0);
    const time = String(Math.floor(el / 60)).padStart(2, '0') + ':' + String(Math.floor(el % 60)).padStart(2, '0');
    let when = 'baru saja';
    if (d.at) {
      const mins = Math.floor((Date.now() - d.at) / 60000);
      when = mins < 1 ? 'baru saja' : mins < 60 ? mins + ' menit lalu' : Math.floor(mins / 60) + ' jam lalu';
    }
    return { cls, level: d.player.level || 1, time, when, bosses: Object.keys(d.bosses || {}).length };
  },
  clear() {
    const b = this.bucket(); if (!b) return;
    try { b.removeItem(this.KEY); } catch (e) { }
  },

  /* ---------- tulis ---------- */
  collect() {
    const P = Game.player; if (!P) return null;
    const clean = it => it && {
      uid: it.uid, tid: it.tid, qty: it.qty, plus: it.plus,
      sockets: it.sockets ? it.sockets.slice() : undefined,
      enchant: it.enchant ? Object.assign({}, it.enchant) : null,
    };
    const eq = {};
    for (const k in P.equip) eq[k] = clean(P.equip[k]);
    return {
      v: 1, at: Date.now(), cls: (Game.cls || CLASSES[0]).id, elapsed: Game.elapsed || 0,
      player: {
        x: P.x, y: P.y, level: P.level, xp: P.xp, xpNext: P.xpNext, gold: P.gold,
        hp: P.hp, base: Object.assign({}, P.base), inv: P.inv.map(clean), equip: eq,
      },
      uid: UID,
      quest: { step: Game.quest.step, counter: Game.quest.counter, finished: Game.quest.finished, log: Game.quest.log.slice() },
      bosses: Object.assign({}, Game.bossDefeated || {}),
      skills: { unlocked: (Skills.unlocked || []).slice(), slots: (Skills.slots || []).slice() },
      market: { price: Object.assign({}, Market.price || {}) },
      gstats: Object.assign({}, Game.stats || {}),
      settings: Object.assign({}, Game.settings),
    };
  },
  write(force) {
    if (!Game.player || Game.state !== 'play' && !force) return false;
    if (Clash.active) return false;                       // jangan simpan di tengah arena clash
    const b = this.bucket(); if (!b) return false;
    const d = this.collect(); if (!d) return false;
    try { b.setItem(this.KEY, JSON.stringify(d)); this.lastWrite = Date.now(); return true; }
    catch (e) { return false; }
  },
  /* simpan + beri kabar kecil ke pemain */
  writeNotice() {
    if (this.write(true)) Game.toast('Kemajuan tersimpan otomatis.', '#9ef7ff');
  },

  /* ---------- muat ---------- */
  apply(d) {
    const P = Game.player;
    const S = d.player;
    P.x = S.x; P.y = S.y; P.level = S.level || 1; P.xp = S.xp || 0;
    P.xpNext = S.xpNext || 90; P.gold = S.gold || 0;
    if (S.base) P.base = Object.assign(P.base, S.base);
    // barang
    const rebuild = it => {
      if (!it || !ITEMS[it.tid]) return null;
      const t = ITEMS[it.tid];
      const out = { uid: it.uid, tid: it.tid };
      if (t.stack) out.qty = Math.max(1, it.qty || 1);
      else {
        out.plus = it.plus || 0;
        out.sockets = new Array(t.sockets || 0).fill(null);
        if (it.sockets) it.sockets.forEach((g, i) => { if (i < out.sockets.length && g && ITEMS[g]) out.sockets[i] = g; });
        out.enchant = (it.enchant && ENCHANTS.some(e => e.id === it.enchant.id))
          ? Object.assign({}, it.enchant) : null;
      }
      return out;
    };
    P.inv = (S.inv || []).map(rebuild).filter(Boolean);
    for (const k in P.equip) P.equip[k] = rebuild(S.equip ? S.equip[k] : null);
    UID = Math.max(d.uid || 1, ...P.inv.map(i => i.uid || 0), 1) + 1;
    // kisah
    Game.quest.step = Math.min(d.quest ? d.quest.step : 0, STORY.steps.length);
    Game.quest.counter = (d.quest && d.quest.counter) || 0;
    Game.quest.finished = !!(d.quest && d.quest.finished);
    Game.quest.log = (d.quest && d.quest.log) || [];
    Game.quest.refresh();
    Game.elapsed = d.elapsed || 0;
    Game.bossDefeated = Object.assign({}, d.bosses || {});
    if (d.skills) {
      Skills.unlocked = (d.skills.unlocked || []).filter(id => SKILLS[id]);
      const sl = d.skills.slots || [];
      Skills.slots = [0, 1, 2].map(i => (sl[i] && SKILLS[sl[i]] && Skills.unlocked.includes(sl[i])) ? sl[i] : null);
      if (!Skills.slots.some(Boolean)) Skills.slots = Skills.unlocked.slice(0, 3).concat([null, null, null]).slice(0, 3);
      Skills.cd = [0, 0, 0];
    }
    if (d.gstats) Object.assign(Game.stats, d.gstats);
    if (d.market && d.market.price) for (const k in d.market.price) if (Market.price[k] != null) Market.price[k] = d.market.price[k];
    Game.recalc();
    P.hp = Math.max(1, Math.min(S.hp || P.stats.hp, P.stats.hp));
    UI.syncHUD(); UI.syncQuest();
  },
  continueGame() {
    const d = this.read(); if (!d) return false;
    Game.start(d.cls);
    try { this.apply(d); } catch (e) { console.warn('gagal memuat simpanan', e); }
    Game.toast('Permainan dilanjutkan — selamat kembali, petualang.', '#9ef7ff');
    return true;
  },

  /* ---------- pemasangan ---------- */
  /* pengaturan grafis/suara disimpan terpisah supaya perubahan di layar utama pun ikut tersimpan */
  writeSettings() {
    const b = this.bucket(); if (!b) return;
    try { b.setItem(this.SKEY, JSON.stringify(Game.settings)); } catch (e) { }
  },
  loadSettings() {
    const b = this.bucket();
    let src = null;
    try { src = b && JSON.parse(b.getItem(this.SKEY) || 'null'); } catch (e) { src = null; }
    if (!src) { const d = this.read(); src = d && d.settings; }
    const d = { settings: src };
    if (!d.settings) return;
    for (const k in d.settings) if (k in Game.settings) Game.settings[k] = d.settings[k];
    if (Game.canvas && Game.applyResolution) Game.applyResolution();
    if (Audio2.ctx) { Audio2.musicOn = Game.settings.music !== false; Audio2.sfxOn = Game.settings.sfx !== false; }
    document.body.classList.toggle('touch-on', Game.settings.touchControls !== false);
  },
  hook() {
    setInterval(() => { if (Game.state === 'play' && !Clash.active) this.write(); }, 15000);
    const flush = () => { if (Game.player && Game.state !== 'home') this.write(true); };
    addEventListener('pagehide', flush);
    addEventListener('blur', flush);
    document.addEventListener('visibilitychange', () => { if (document.hidden) flush(); });
  },
};

/* ---- simpan pada momen penting ---- */
(function () {
  const adv = Game.quest.advance.bind(Game.quest);
  Game.quest.advance = function () { adv(); Save.write(); };

  if (Game.levelUp) {
    const lu = Game.levelUp.bind(Game);
    Game.levelUp = function () { lu(); Save.write(); };
  }
  const gp = Game.pause ? Game.pause.bind(Game) : null;
  if (gp) Game.pause = function () { gp(); Save.write(true); };

  /* tombol LANJUTKAN di layar utama */
  const ih = UI.initHome.bind(UI);
  UI.initHome = function () {
    ih();
    const acts = UI.home.querySelector('.home-actions');
    const start = document.getElementById('btnStart');
    if (acts && start && !document.getElementById('btnCont')) {
      const b = document.createElement('button');
      b.className = 'btn primary'; b.id = 'btnCont'; b.textContent = 'LANJUTKAN';
      acts.insertBefore(b, start);
      b.onclick = () => { Audio2.init(); Audio2.sfx('ui'); Save.continueGame(); };
    }
    UI.refreshContinue();
  };
  UI.refreshContinue = function () {
    const b = document.getElementById('btnCont');
    if (!b) return;
    const inf = Save.info();
    b.classList.toggle('hidden', !inf);
    const st = document.getElementById('btnStart');
    if (st) st.textContent = inf ? 'MAIN BARU' : 'MAIN';
    if (inf) b.textContent = 'LANJUTKAN · Lv ' + inf.level;
  };
  const sh = UI.showHome.bind(UI);
  UI.showHome = function () { sh(); UI.refreshContinue(); UI.syncAccount(); };

  Save.loadSettings();
  Save.hook();
})();
