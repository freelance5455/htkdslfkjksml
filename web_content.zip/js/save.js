/* ============================================================
   save.js — persistent progress (localStorage)
   ============================================================ */
'use strict';

const SAVE_KEY = 'badal3d_extreme_save_v2';

function _defaultSave() {
  return {
    version: 2,
    coins: 1500,
    owned: ['falcon', 'urban'],
    selected: 'falcon',
    paints: {},                       // carId -> paint index
    settings: {
      steering: 'wheel',              // wheel | buttons
      transmission: 'auto',           // auto | manual
      camera: 'chase',
      quality: 'high',                // low | medium | high
      master: 0.85,
      engine: 0.9,
      sfx: 0.85,
      mute: false,
      weather: 'clear',
      time: 19.2,                     // 0..24
      headlights: true,
      showFps: false,
    },
    best: {},                         // modeId -> number (higher better)
    bestTime: 0,                      // time-trial best seconds (0 = none)
    raceWins: 0,
    stats: {
      distance: 0, overtakes: 0, drift: 0, runs: 0,
      coinsEarned: 0, nearMiss: 0, nitro: 0, policeTime: 0,
    },
    missions: { date: '', list: [] },
    lastCar: 'falcon',
  };
}

class SaveSystem {
  constructor() {
    this.data = _defaultSave();
    this.load();
  }

  load() {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return;
      const parsed = JSON.parse(raw);
      if (!parsed || typeof parsed !== 'object') return;
      const def = _defaultSave();
      // shallow-merge with defaults, preserving nested settings/stats
      this.data = Object.assign({}, def, parsed);
      this.data.settings = Object.assign({}, def.settings, parsed.settings || {});
      this.data.stats = Object.assign({}, def.stats, parsed.stats || {});
      this.data.best = Object.assign({}, def.best, parsed.best || {});
      this.data.missions = Object.assign({}, def.missions, parsed.missions || {});
      if (!Array.isArray(this.data.owned)) this.data.owned = def.owned.slice();
      if (!this.data.owned.includes('falcon')) this.data.owned.push('falcon');
      if (!this.data.owned.includes('urban')) this.data.owned.push('urban');
      if (!CAR_BY_ID[this.data.selected]) this.data.selected = 'falcon';
    } catch (e) {
      console.warn('Save load failed, using defaults', e);
      this.data = _defaultSave();
    }
  }

  save() {
    try { localStorage.setItem(SAVE_KEY, JSON.stringify(this.data)); }
    catch (e) { /* private mode / quota */ }
  }

  reset() {
    this.data = _defaultSave();
    this.save();
  }

  /* ---------- coins ---------- */
  addCoins(n) {
    n = Math.round(n);
    if (!n) return;
    this.data.coins = Math.max(0, this.data.coins + n);
    if (n > 0) this.data.stats.coinsEarned += n;
    this.save();
  }

  spendCoins(n) {
    if (this.data.coins < n) return false;
    this.data.coins -= n;
    this.save();
    return true;
  }

  /* ---------- cars ---------- */
  isOwned(id) { return this.data.owned.includes(id); }
  unlockCar(id) {
    if (!this.isOwned(id)) {
      this.data.owned.push(id);
      this.save();
    }
  }
  selectCar(id) {
    if (!CAR_BY_ID[id]) return;
    this.data.selected = id;
    this.data.lastCar = id;
    this.save();
  }
  paintOf(id) {
    const p = this.data.paints[id];
    return Number.isInteger(p) && p >= 0 && p < PAINTS.length ? p : (CAR_BY_ID[id]?.paint || 0);
  }
  setPaint(id, index) {
    this.data.paints[id] = AD.clamp(index | 0, 0, PAINTS.length - 1);
    this.save();
  }

  /* ---------- scores ---------- */
  best(modeId) { return this.data.best[modeId] || 0; }
  setBest(modeId, value) {
    const prev = this.best(modeId);
    if (value > prev) {
      this.data.best[modeId] = value;
      this.save();
      return true;
    }
    return false;
  }
  setBestTime(sec) {
    if (!this.data.bestTime || sec < this.data.bestTime) {
      this.data.bestTime = sec;
      this.save();
      return true;
    }
    return false;
  }

  addStat(key, amount) {
    if (this.data.stats[key] === undefined) this.data.stats[key] = 0;
    this.data.stats[key] += amount;
  }

  /* ---------- settings ---------- */
  get settings() { return this.data.settings; }
  setSetting(key, value) {
    this.data.settings[key] = value;
    this.save();
  }
}
