/* save.js — save/load foundation (localStorage, 3 slots + autosave). Versioned JSON. */
(function (G) {
  'use strict';
  const PREFIX = 'empires_save_';
  G.SAVE_SLOTS = ['auto', '1', '2', '3'];

  function store() { try { return window.localStorage; } catch (e) { return null; } }

  function snapshot() {
    const st = G.state;
    return {
      version: st.version, savedAt: Date.now(),
      player: st.player, date: st.date, day: st.day, speedIdx: st.speedIdx,
      owners: st.owners, countries: st.countries, log: st.log,
      armies: st.armies, queues: st.queues, generals: st.generals, armyCount: st.armyCount, nextId: st.nextId,
      pb: st.pb, alloc: st.alloc, construct: st.construct, tax: st.tax, tradeUsed: st.tradeUsed, nextBid: st.nextBid,
      intel: st.intel, ops: st.ops, effects: st.effects, reveal: st.reveal, disc: st.disc, intelLog: st.intelLog, nextOp: st.nextOp, nextAgent: st.nextAgent,
      tech: st.tech, ai: st.ai, difficulty: st.difficulty,
      camp: st.camp, ev: st.ev,
      scenario: st.scenario, fleets: st.fleets, shipQ: st.shipQ, nextFid: st.nextFid, fleetCount: st.fleetCount,
      rel: st.rel, treaties: st.treaties, infamy: st.infamy, offers: st.offers, dipCd: st.dipCd, nextTid: st.nextTid,
      wars: st.wars, truce: st.truce, occ: st.occ, fortQ: st.fortQ, rs: st.rs, battleRec: st.battleRec,
      fort: G.provinces.map(p => p.fort),
      capitals: Object.keys(G.COUNTRIES).reduce((o, k) => { o[k] = G.COUNTRIES[k].capitalId; return o; }, {}),
      view: G.view ? { x: G.view.x, y: G.view.y, z: G.view.z } : null,
      selected: G.selected != null ? G.selected : null
    };
  }

  G.saveGame = function (slot) {
    const s = store();
    if (!s) return { ok: false, msg: 'Storage unavailable' };
    try {
      s.setItem(PREFIX + slot, JSON.stringify(snapshot()));
      return { ok: true };
    } catch (e) { return { ok: false, msg: String(e) }; }
  };

  G.slotInfo = function (slot) {
    const s = store(); if (!s) return null;
    try {
      const raw = s.getItem(PREFIX + slot);
      if (!raw) return null;
      const d = JSON.parse(raw);
      return { player: d.player, date: d.date, savedAt: d.savedAt };
    } catch (e) { return null; }
  };

  G.loadGame = function (slot) {
    const s = store();
    if (!s) return { ok: false, msg: 'Storage unavailable' };
    let d;
    try { d = JSON.parse(s.getItem(PREFIX + slot)); } catch (e) { return { ok: false, msg: 'Corrupt save' }; }
    if (!d || !d.owners || !d.countries) return { ok: false, msg: 'No save in this slot' };
    const prev = { st: G.state, prov: G.provinces, sc: G.scenarioId, zones: G.zones, zbi: G.zoneById, straits: G.straits, w: G.WORLD_W, h: G.WORLD_H };
    const st = G.newGame(d.player, d.scenario || 'empires');
    if (d.owners.length !== G.provinces.length) {
      G.useScenario(prev.sc); G.state = prev.st; G.provinces = prev.prov; G.zones = prev.zones; G.zoneById = prev.zbi; G.straits = prev.straits; G.WORLD_W = prev.w; G.WORLD_H = prev.h;
      return { ok: false, msg: 'Save is from an incompatible map' };
    }
    st.date = d.date; st.day = d.day; st.speedIdx = d.speedIdx || 1;
    st.owners = d.owners; st.log = d.log || [];
    for (const id in st.countries) if (d.countries[id]) Object.assign(st.countries[id], d.countries[id]);
    if (d.armies) { // Phase 2+ save; Phase 1 saves keep the default starting armies
      st.armies = d.armies; st.queues = d.queues || {}; st.generals = d.generals || st.generals;
      st.armyCount = d.armyCount || {}; st.nextId = d.nextId || st.nextId;
      G.initMilitary(st, false);
    }
    st.paused = true;
    // Phase 3 state (older saves simply start at peace)
    st.wars = d.wars || {}; st.truce = d.truce || {}; st.occ = d.occ || {}; st.fortQ = d.fortQ || {};
    st.fortQ = Array.isArray(d.fortQ) ? d.fortQ : []; st.battleRec = d.battleRec || {}; if (d.rs != null) st.rs = d.rs;
    if (d.fort) d.fort.forEach((f, i) => { G.provinces[i].fort = f || 0; });
    if (d.capitals) for (const k in d.capitals) {
      const c = G.COUNTRIES[k], old = G.provinces[c.capitalId];
      if (c.capitalId !== d.capitals[k]) { old.capital = false; c.capitalId = d.capitals[k]; const np = G.provinces[c.capitalId]; np.capital = true; c.capital = np.name; }
    }
    if (d.pb) { st.pb = d.pb; st.alloc = d.alloc || st.alloc; st.construct = d.construct || []; st.tax = d.tax || st.tax; st.tradeUsed = d.tradeUsed || st.tradeUsed; st.nextBid = d.nextBid || 1; }
    G.initEconomy(st, false);
    if (d.rel) { st.rel = d.rel; st.treaties = d.treaties || []; st.infamy = d.infamy || {}; st.offers = d.offers || []; st.dipCd = d.dipCd || {}; st.nextTid = d.nextTid || 1; }
    G.initDiplomacy(st, false);
    if (d.intel) { st.intel = d.intel; st.ops = d.ops || []; st.effects = d.effects || []; st.reveal = d.reveal || {}; st.disc = d.disc || {}; st.intelLog = d.intelLog || []; st.nextOp = d.nextOp || 1; st.nextAgent = d.nextAgent || 1; }
    G.initIntel(st, false);
    if (d.tech) st.tech = d.tech;
    G.initTech(st, false);
    if (d.ai) st.ai = d.ai;
    if (d.difficulty) st.difficulty = d.difficulty;
    G.initAI(st, false);
    if (d.fleets) { st.fleets = d.fleets; st.shipQ = d.shipQ || {}; st.nextFid = d.nextFid || st.nextFid; st.fleetCount = d.fleetCount || {}; } else { st.fleets = []; st.shipQ = {}; }
    G.initNaval(st, !d.fleets);
    if (d.camp) st.camp = d.camp; else st.camp = null;
    G.initCampaign(st, !d.camp, 'sandbox');
    if (d.ev) st.ev = d.ev;
    G.initEvents(st, !d.ev);
    G.recompute();
    G.selected = d.selected != null ? d.selected : null;
    if (d.view && G.view) { G.view.x = d.view.x; G.view.y = d.view.y; G.view.z = d.view.z; }
    return { ok: true };
  };

  G.deleteSave = function (slot) { const s = store(); if (s) try { s.removeItem(PREFIX + slot); } catch (e) {} };
})(window.EMP = window.EMP || {});
