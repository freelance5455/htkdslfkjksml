const Save={k:'cursed_forest_v1',
save(s){try{localStorage.setItem(this.k,JSON.stringify(s))}catch(e){}},
load(){try{return JSON.parse(localStorage.getItem(this.k))}catch(e){return null}},
has(){return !!this.load()},
clear(){try{localStorage.removeItem(this.k)}catch(e){}}};
