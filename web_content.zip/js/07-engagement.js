/* ================= FFM 26 Engagement system (hub, daily, tasks, wheel, pass, career+, cups ...) ================= */
(function () {
  const D = window.FFMStoreData, $ = (id) => document.getElementById(id);
  const fmt = (n) => Number(n).toLocaleString('en-US');
  const lang = () => (typeof state !== 'undefined' && state.lang) || 'ar';
  const LIDX = { ar: 0, en: 1, fr: 2, es: 3, pt: 4, de: 5, tr: 6 };
  const L = function () { const v = arguments[LIDX[lang()] == null ? 0 : LIDX[lang()]]; return v == null ? arguments[1] : v; };
  const HOUR = 3600000, DAY = 86400000;
  let tmax = 0; const now = () => { const t = Date.now(); const sv = (typeof state !== 'undefined' && state && state.eng) ? state.eng : null; const m = Math.max(tmax, (sv && sv.tmax) || 0); if (t < m) return m; tmax = t; if (sv) sv.tmax = t; return t; };
  const pad = (n) => String(n).padStart(2, '0');
  const dayKey = (t) => { const d = new Date(t == null ? now() : t); return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); };
  const dayNum = (t) => { t = t == null ? now() : t; return Math.floor((t - new Date(t).getTimezoneOffset() * 60000) / DAY); };
  const weekNum = () => Math.floor((dayNum() + 3) / 7);
  const monthKey = () => dayKey().slice(0, 7);
  const SEASON_EPOCH = Math.floor(Date.UTC(2026, 10, 1) / DAY);
  const seasonIdx = () => Math.max(0, Math.floor((dayNum() - SEASON_EPOCH) / 30));
  function srnd(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
  function seededPick(list, seed, n) { const r = srnd(seed), a = list.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a.slice(0, n); }
  const rnd = (n) => D.rndInt(n);
  const S = () => window.FFMStore.store();
  const CAREER_TIERS = 8;

  /* ---------- state ---------- */
  function eng() {
    if (!state.eng || typeof state.eng !== 'object') state.eng = {};
    const e = state.eng;
    e.daily = e.daily || { last: '', streak: 0 };
    e.month = e.month || { key: '', days: 0, last: '', claimed: [] };
    e.tasks = e.tasks || { day: -1, list: [], chest: false };
    e.weekly = e.weekly || { week: -1, list: [], chest: false };
    e.free = e.free || { n: 1, t: now() };
    e.wheel = e.wheel || { day: -1, used: 0, extra: 0 };
    e.pass = e.pass || { season: -1, xp: 0, free: [], prem: [], premium: false };
    e.album = e.album || { claimed: [] };
    e.stats = Object.assign({ matches: 0, wins: 0, draws: 0, losses: 0, goals: 0, conceded: 0, cs: 0, streak: 0, bestStreak: 0, packs: 0, spins: 0, upgrades: 0, merges: 0, cups: 0, challenges: 0, promotions: 0, legends: 0, loginStreak: 0, tasks: 0 }, e.stats || {});
    e.ach = e.ach || {};
    e.chal = e.chal || { day: -1, tries: 0, done: false };
    e.lb = e.lb || { week: -1, pts: 0, last: null };
    e.cups = e.cups || { local: { alive: false, round: 0, next: 0 }, cont: { alive: false, round: 0, next: 0 } };
    e.ss = e.ss || { w: 0, d: 0, l: 0, gf: 0, ga: 0, cs: 0, p: 0 };
    e.goals = e.goals || { no: 0, list: [], done: [] };
    e.set = Object.assign({ diff: 'normal', form: '4-3-3', press: 'normal' }, e.set || {});
    e.notif = e.notif || { sys: false, seen: {} };
    return e;
  }

  /* ---------- rewards ---------- */
  function rewStr(r) {
    const o = [];
    if (r.tok) o.push('🪙 ' + fmt(r.tok)); if (r.vch) o.push('🎟️ ' + r.vch); if (r.shards) o.push('🔩 ' + r.shards);
    if (r.free) o.push('🎁 ×' + r.free); if (r.xp) o.push('⭐ ' + r.xp + ' XP');
    if (r.card) o.push('🃏 ' + (r.card.tier >= 6 ? L('أسطورة', 'Legend', 'Légende', 'Leyenda', 'Lenda', 'Legende', 'Efsane') : L('بطاقة نادرة', 'Rare card', 'Carte rare', 'Carta rara', 'Carta rara', 'Seltene Karte', 'Nadir kart')));
    return o.join('  ');
  }
  function give(r) {
    const s = S(); let txt = [];
    if (r.tok) state.tokens += r.tok;
    if (r.vch) s.vouchers += r.vch;
    if (r.shards) s.shards = (s.shards || 0) + r.shards;
    if (r.free) { acc(); eng().free.n += r.free; }
    if (r.xp) addXp(r.xp);
    let card = null;
    if (r.card) { card = window.FFMStoreGrant(r.card); }
    updateTokenDisplay(); saveGame(); if (window.FFMSfx) FFMSfx.play(card ? 'card' : 'reward');
    return { text: rewStr(r) + (card ? '  → ' + card.name + ' (' + card.rating + ')' : ''), card };
  }
  function toast(msg, sub) {
    let t = $('eng-toast'); if (!t) { t = document.createElement('div'); t.id = 'eng-toast'; document.body.appendChild(t); }
    t.innerHTML = '<b>' + msg + '</b>' + (sub ? '<br><small>' + sub + '</small>' : ''); t.className = 'on';
    clearTimeout(t._h); t._h = setTimeout(() => { t.className = ''; }, 3600);
  }
  function claimToast(title, r) { const g = give(r); toast('✔ ' + title, g.text); refreshAll(); return g; }

  /* ---------- pass XP ---------- */
  function passSync() { const p = eng().pass, sn = seasonIdx(); if (p.season !== sn) { p.season = sn; p.xp = 0; p.free = []; p.prem = []; p.premium = false; } return p; }
  function addXp(n) { const p = passSync(); p.xp = Math.min(3000, p.xp + n); }
  const passLvl = () => Math.min(30, Math.floor(passSync().xp / 100));
  const passFree = (l) => ({ tok: 100 + l * 10, vch: l % 5 === 0 ? (l === 30 ? 3 : 1) : 0 });
  function passPrem(l) {
    if (l === 30) return { card: { tier: 8 }, vch: 5 };
    if (l === 20) return { card: { tier: 7 }, vch: 3 };
    if (l === 10) return { card: { tier: 4, autoTrait: true }, vch: 2 };
    if (l % 3 === 0) return { vch: 1, shards: 2 };
    return { tok: 200 + l * 15, shards: 1 };
  }

  /* ---------- free pack charges ---------- */
  function acc() {
    const f = eng().free, t = now();
    if (f.n >= 3) { f.t = t; return f; }
    while (f.n < 3 && t >= f.t + 8 * HOUR) { f.n++; f.t += 8 * HOUR; }
    if (f.n >= 3) f.t = t;
    return f;
  }

  /* ---------- daily login ---------- */
  const DAILY = [{ tok: 200 }, { tok: 300 }, { vch: 1 }, { tok: 500 }, { vch: 1, shards: 2 }, { tok: 800 }, { vch: 3, tok: 1500, free: 1 }];
  function dailyState() {
    const d = eng().daily, today = dayKey(), y = dayKey(now() - DAY);
    if (d.last && d.last !== today && d.last !== y) d.streak = 0;
    return { can: d.last !== today, idx: d.streak % 7, streak: d.streak };
  }
  function registerLogin() {
    const m = eng().month, mk = monthKey(), today = dayKey();
    if (m.key !== mk) { m.key = mk; m.days = 0; m.last = ''; m.claimed = []; }
    if (m.last !== today) { m.last = today; m.days++; }
  }
  const MONTH = (d) => {
    if (d === 30) return { card: { tier: 6 }, vch: 3, tok: 2000 };
    const r = { tok: 100 + d * 15 }; if (d % 5 === 0) r.vch = 1; if (d % 7 === 0) r.free = 1; if (d % 10 === 3) r.shards = 2; return r;
  };

  /* ---------- tasks ---------- */
  const DAILY_POOL = [
    { id: 'win1', ev: 'win', n: 1, r: { tok: 150 }, t: () => L('اربح مباراة', 'Win a match', 'Gagnez un match', 'Gana un partido', 'Ganhe um jogo', 'Gewinne ein Spiel', 'Bir maç kazan') },
    { id: 'play2', ev: 'match', n: 2, r: { tok: 120 }, t: () => L('العب مباراتين', 'Play 2 matches', 'Jouez 2 matchs', 'Juega 2 partidos', 'Jogue 2 jogos', 'Spiele 2 Spiele', '2 maç oyna') },
    { id: 'goals3', ev: 'goals', n: 3, r: { tok: 150 }, t: () => L('سجّل 3 أهداف', 'Score 3 goals', 'Marquez 3 buts', 'Marca 3 goles', 'Marque 3 golos', 'Erziele 3 Tore', '3 gol at') },
    { id: 'goals5', ev: 'goals', n: 5, r: { tok: 250 }, t: () => L('سجّل 5 أهداف', 'Score 5 goals', 'Marquez 5 buts', 'Marca 5 goles', 'Marque 5 golos', 'Erziele 5 Tore', '5 gol at') },
    { id: 'cs1', ev: 'cs', n: 1, r: { tok: 200 }, t: () => L('حافظ على شباكك نظيفة', 'Keep a clean sheet', 'Gardez votre cage inviolée', 'Mantén la portería a cero', 'Mantenha a baliza a zero', 'Spiele zu Null', 'Kalende gol yeme') },
    { id: 'pack1', ev: 'pack', n: 1, r: { tok: 100, shards: 1 }, t: () => L('افتح حزمة', 'Open a pack', 'Ouvrez un pack', 'Abre un sobre', 'Abra um pacote', 'Öffne ein Pack', 'Bir paket aç') },
    { id: 'cwin1', ev: 'careerWin', n: 1, r: { tok: 200 }, t: () => L('اربح مباراة في المسار المهني', 'Win a career match', 'Gagnez un match de carrière', 'Gana un partido de carrera', 'Ganhe um jogo de carreira', 'Gewinne ein Karrierespiel', 'Bir kariyer maçı kazan') },
    { id: 'spin1', ev: 'spin', n: 1, r: { tok: 100 }, t: () => L('أدر عجلة الحظ', 'Spin the wheel', 'Tournez la roue', 'Gira la ruleta', 'Gire a roleta', 'Drehe das Glücksrad', 'Çarkı çevir') },
    { id: 'free1', ev: 'free', n: 1, r: { tok: 100 }, t: () => L('افتح حزمة مجانية', 'Open a free pack', 'Ouvrez un pack gratuit', 'Abre un sobre gratis', 'Abra um pacote grátis', 'Öffne ein Gratis-Pack', 'Ücretsiz bir paket aç') },
    { id: 'upg1', ev: 'upgrade', n: 1, r: { tok: 150 }, t: () => L('طوّر لاعبًا', 'Upgrade a player', 'Améliorez un joueur', 'Mejora a un jugador', 'Melhore um jogador', 'Verbessere einen Spieler', 'Bir oyuncuyu geliştir') }
  ];
  const WEEKLY_POOL = [
    { id: 'w_win5', ev: 'win', n: 5, r: { tok: 600, vch: 1 }, t: () => L('اربح 5 مباريات', 'Win 5 matches', 'Gagnez 5 matchs', 'Gana 5 partidos', 'Ganhe 5 jogos', 'Gewinne 5 Spiele', '5 maç kazan') },
    { id: 'w_car7', ev: 'careerPlay', n: 7, r: { tok: 500, shards: 3 }, t: () => L('العب 7 مباريات مسار مهني', 'Play 7 career matches', 'Jouez 7 matchs de carrière', 'Juega 7 partidos de carrera', 'Jogue 7 jogos de carreira', 'Spiele 7 Karrierespiele', '7 kariyer maçı oyna') },
    { id: 'w_goal15', ev: 'goals', n: 15, r: { tok: 600, vch: 1 }, t: () => L('سجّل 15 هدفًا', 'Score 15 goals', 'Marquez 15 buts', 'Marca 15 goles', 'Marque 15 golos', 'Erziele 15 Tore', '15 gol at') },
    { id: 'w_pack5', ev: 'pack', n: 5, r: { vch: 2 }, t: () => L('افتح 5 حزم', 'Open 5 packs', 'Ouvrez 5 packs', 'Abre 5 sobres', 'Abra 5 pacotes', 'Öffne 5 Packs', '5 paket aç') },
    { id: 'w_cs3', ev: 'cs', n: 3, r: { tok: 700, shards: 2 }, t: () => L('3 شباك نظيفة', '3 clean sheets', '3 cages inviolées', '3 porterías a cero', '3 jogos sem sofrer golos', '3 Zu-Null-Spiele', '3 kalesini kapalı tut') },
    { id: 'w_cup', ev: 'cupRound', n: 3, r: { tok: 800, vch: 1 }, t: () => L('اجتز 3 جولات كأس', 'Win 3 cup rounds', 'Passez 3 tours de coupe', 'Gana 3 rondas de copa', 'Ganhe 3 rondas da taça', 'Gewinne 3 Pokalrunden', '3 kupa turu kazan') }
  ];
  function tasksSync() {
    const e = eng(), dn = dayNum();
    if (e.tasks.day !== dn) { e.tasks = { day: dn, chest: false, list: seededPick(DAILY_POOL, dn * 31 + 7, 3).map(x => ({ id: x.id, p: 0, c: false })) }; }
    const wk = weekNum();
    if (e.weekly.week !== wk) { e.weekly = { week: wk, chest: false, list: seededPick(WEEKLY_POOL, wk * 17 + 3, 3).map(x => ({ id: x.id, p: 0, c: false })) }; }
    return e;
  }
  const defOf = (id) => DAILY_POOL.concat(WEEKLY_POOL).find(x => x.id === id);

  /* ---------- events bus ---------- */
  function event(type, n) {
    n = n == null ? 1 : n; const e = tasksSync();
    [e.tasks.list, e.weekly.list].forEach(list => list.forEach(tk => { const d = defOf(tk.id); if (d && d.ev === type && !tk.c) tk.p = Math.min(d.n, tk.p + n); }));
    const st = e.stats;
    if (type === 'pack') st.packs += n; else if (type === 'spin') st.spins += n; else if (type === 'upgrade') st.upgrades += n; else if (type === 'merge') st.merges += n; else if (type === 'legend') st.legends += n;
    saveGame();
  }

  /* ---------- achievements ---------- */
  const ACH = [];
  [['matches', [1, 10, 50, 200], { ar: 'العب {n} مباراة', en: 'Play {n} matches', fr: 'Jouez {n} matchs', es: 'Juega {n} partidos', pt: 'Jogue {n} jogos', de: 'Spiele {n} Spiele', tr: '{n} maç oyna' }],
   ['wins', [1, 10, 50, 150], { ar: 'اربح {n} مباراة', en: 'Win {n} matches', fr: 'Gagnez {n} matchs', es: 'Gana {n} partidos', pt: 'Ganhe {n} jogos', de: 'Gewinne {n} Spiele', tr: '{n} maç kazan' }],
   ['goals', [10, 50, 200, 500], { ar: 'سجّل {n} هدفًا', en: 'Score {n} goals', fr: 'Marquez {n} buts', es: 'Marca {n} goles', pt: 'Marque {n} golos', de: 'Erziele {n} Tore', tr: '{n} gol at' }],
   ['cs', [5, 25, 60], { ar: '{n} شباك نظيفة', en: '{n} clean sheets', fr: '{n} cages inviolées', es: '{n} porterías a cero', pt: '{n} jogos sem sofrer golos', de: '{n} Zu-Null-Spiele', tr: '{n} kez kalesini kapalı tut' }],
   ['bestStreak', [3, 5, 10], { ar: 'سلسلة {n} انتصارات', en: '{n} wins in a row', fr: '{n} victoires d\'affilée', es: 'Racha de {n} victorias', pt: 'Sequência de {n} vitórias', de: '{n} Siege in Folge', tr: 'Üst üste {n} galibiyet' }],
   ['packs', [1, 10, 50, 150], { ar: 'افتح {n} حزمة', en: 'Open {n} packs', fr: 'Ouvrez {n} packs', es: 'Abre {n} sobres', pt: 'Abra {n} pacotes', de: 'Öffne {n} Packs', tr: '{n} paket aç' }],
   ['legends', [1, 5], { ar: 'احصل على {n} بطاقة أسطورية', en: 'Get {n} legend cards', fr: 'Obtenez {n} cartes légendes', es: 'Consigue {n} cartas de leyenda', pt: 'Obtenha {n} cartas lendárias', de: 'Erhalte {n} Legendenkarten', tr: '{n} efsane kart kazan' }],
   ['loginStreak', [7, 30], { ar: 'سجّل الدخول {n} يومًا متتاليًا', en: 'Log in {n} days in a row', fr: 'Connectez-vous {n} jours de suite', es: 'Accede {n} días seguidos', pt: 'Aceda {n} dias seguidos', de: 'Logge dich {n} Tage in Folge ein', tr: 'Üst üste {n} gün giriş yap' }],
   ['cups', [1, 5], { ar: 'افز بـ {n} كأس', en: 'Win {n} cups', fr: 'Gagnez {n} coupes', es: 'Gana {n} copas', pt: 'Ganhe {n} taças', de: 'Gewinne {n} Pokale', tr: '{n} kupa kazan' }],
   ['promotions', [1, 3], { ar: 'اصعد {n} درجات', en: 'Get promoted {n} times', fr: 'Montez {n} fois', es: 'Asciende {n} veces', pt: 'Suba de divisão {n} vezes', de: 'Steige {n}-mal auf', tr: '{n} kez lige yüksel' }],
   ['upgrades', [5, 20], { ar: 'طوّر لاعبين {n} مرات', en: 'Upgrade players {n} times', fr: 'Améliorez {n} fois', es: 'Mejora jugadores {n} veces', pt: 'Melhore jogadores {n} vezes', de: 'Verbessere Spieler {n}-mal', tr: 'Oyuncuları {n} kez geliştir' }],
   ['challenges', [3, 15], { ar: 'أكمل {n} تحديات يومية', en: 'Complete {n} daily challenges', fr: 'Réussissez {n} défis', es: 'Completa {n} desafíos diarios', pt: 'Complete {n} desafios diários', de: 'Schließe {n} tägliche Herausforderungen ab', tr: '{n} günlük meydan okuma tamamla' }]]
    .forEach(([stat, goals, names]) => goals.forEach((g, i) => ACH.push({ id: stat + g, stat, goal: g, i, name: names, r: { tok: 150 * (i + 1) * (i + 1), vch: i >= 2 ? i - 1 : 0, shards: i >= 1 ? i : 0 } })));
  const achName = (a) => (a.name[lang()] || a.name.en).replace('{n}', a.goal);
  function achGet(a) { return eng().stats[a.stat] || 0; }
  const SHIELD = ['🥉', '🥈', '🥇', '💎'];

  /* ---------- player XP & upgrades ---------- */
  function xpPlayers(win) {
    const pl = state.teams.team_1.players, ups = [];
    for (let i = 0; i < 11; i++) {
      const p = pl[i]; if (!p) continue;
      p.xp = (p.xp || 0) + 10 + (win ? 5 : 0);
      let lvl = 0; while (lvl < 9 && p.xp >= 15 * (lvl + 1) * (lvl + 2)) lvl++;
      if (lvl > (p.lvl || 0)) { p.lvl = lvl; const u = Math.floor(lvl / 3); const d = u - (p.xpUp || 0); if (d > 0 && p.rating < 94) { p.rating = Math.min(94, p.rating + d); p.xpUp = u; ups.push(p.name + ' ⬆'); } }
    }
    return ups;
  }
  const upgCost = (p) => { const n = (p.upg || 0) + 1; return { n, tok: Math.round(n * (200 + (p.rating - 60) * 15) / 10) * 10, sh: 2 * n }; };
  window.engUpgrade = function (i) {
    const p = state.teams.team_1.players[i], s = S(); if (!p) return;
    if ((p.upg || 0) >= 3 || p.rating >= 94) { modal(L('تنبيه', 'Notice', 'Info', 'Aviso', 'Aviso', 'Hinweis', 'Uyarı'), L('بلغ اللاعب الحد الأقصى للتطوير.', 'This player reached the upgrade cap.', 'Ce joueur a atteint le maximum.', 'Este jugador alcanzó el límite de mejora.', 'Este jogador atingiu o limite de melhoria.', 'Dieser Spieler hat das Upgrade-Limit erreicht.', 'Bu oyuncu geliştirme sınırına ulaştı.')); return; }
    const c = upgCost(p);
    if (state.tokens < c.tok || (s.shards || 0) < c.sh) { ffmShort(state.tokens < c.tok && (s.shards || 0) < c.sh ? 'res' : (state.tokens < c.tok ? 'tok' : 'shard'), L('موارد غير كافية', 'Not enough resources', 'Ressources insuffisantes', 'Recursos insuficientes', 'Recursos insuficientes', 'Nicht genug Ressourcen', 'Yetersiz kaynak'), L(`تحتاج 🪙 ${fmt(c.tok)} و 🔩 ${c.sh}.`, `You need 🪙 ${fmt(c.tok)} and 🔩 ${c.sh}.`, `Il faut 🪙 ${fmt(c.tok)} et 🔩 ${c.sh}.`, `Necesitas 🪙 ${fmt(c.tok)} y 🔩 ${c.sh}.`, `Precisa de 🪙 ${fmt(c.tok)} e 🔩 ${c.sh}.`, `Du brauchst 🪙 ${fmt(c.tok)} und 🔩 ${c.sh}.`, `🪙 ${fmt(c.tok)} ve 🔩 ${c.sh} gerekiyor.`)); return; }
    state.tokens -= c.tok; s.shards -= c.sh; p.upg = c.n; p.rating++; updateTokenDisplay(); saveGame(); event('upgrade', 1);
    toast('⬆️ ' + p.name + ' → ' + p.rating); go('upg');
  };

  /* ---------- modal reuse ---------- */
  function modal(title, body, ok) { $('st-modal-title').innerHTML = title; $('st-modal-body').innerHTML = body; $('st-modal-ok').textContent = ok || 'OK'; $('st-modal').style.display = 'flex'; }

  /* ---------- career: tiers ---------- */
  const TIERN = [
    ['دوري الهواة', 'Amateur League', 'Ligue amateur', 'Liga amateur', 'Liga amadora', 'Amateurliga', 'Amatör Lig'], ['الدوري الإقليمي', 'Regional League', 'Ligue régionale', 'Liga regional', 'Liga regional', 'Regionalliga', 'Bölgesel Lig'], ['الدرجة الثالثة', 'Third Division', 'Troisième division', 'Tercera división', 'Terceira divisão', 'Dritte Liga', 'Üçüncü Lig'], ['الدرجة الثانية', 'Second Division', 'Deuxième division', 'Segunda división', 'Segunda divisão', 'Zweite Liga', 'İkinci Lig'],
    ['الدرجة الأولى', 'First Division', 'Première division', 'Primera división', 'Primeira divisão', 'Erste Liga', 'Birinci Lig'], ['الدوري الممتاز', 'Premier League', 'Ligue Premier', 'Liga Premier', 'Liga Premier', 'Premier League', 'Premier Lig'], ['الدوري القاري', 'Continental League', 'Ligue continentale', 'Liga continental', 'Liga continental', 'Kontinentalliga', 'Kıta Ligi'], ['دوري النخبة العالمي', 'World Elite League', 'Ligue mondiale d\'élite', 'Liga mundial de élite', 'Liga mundial de elite', 'Weltelite-Liga', 'Dünya Elit Ligi']
  ];
  const tierName = (t) => { const r = TIERN[CAREER_TIERS - t] || ['?', '?', '?']; const q = r[LIDX[lang()]]; return q == null ? r[1] : q; };
  const tierMult = () => 1 + (CAREER_TIERS - state.currentTier) * 0.12;
  const DIFF = { easy: { b: -8, m: 0.7 }, normal: { b: 0, m: 1 }, hard: { b: 6, m: 1.3 }, legend: { b: 12, m: 1.7 } };
  const diffName = (k) => ({ easy: L('سهل', 'Easy', 'Facile', 'Fácil', 'Fácil', 'Leicht', 'Kolay'), normal: L('عادي', 'Normal', 'Normal', 'Normal', 'Normal', 'Normal', 'Normal'), hard: L('صعب', 'Hard', 'Difficile', 'Difícil', 'Difícil', 'Schwer', 'Zor'), legend: L('أسطوري', 'Legendary', 'Légendaire', 'Legendario', 'Lendário', 'Legendär', 'Efsanevi') })[k];
  function tierIds(t, withMe) {
    const off = (CAREER_TIERS - t) * 20; let ids;
    if (t === CAREER_TIERS) ids = Array.from({ length: 20 }, (_, i) => 'team_' + (i + 1)); else ids = ['team_1'].concat(Array.from({ length: 19 }, (_, i) => 'team_' + (off + i + 2)));
    ids = ids.filter(id => state.teams[id]); return withMe ? ids : ids.filter(id => id !== 'team_1');
  }
  function ensureCareer() {
    if (state.careerVer !== 2) { state.careerVer = 2; state.currentTier = Math.min(CAREER_TIERS, (Number(state.currentTier) || 4) + 4); }
    for (let i = 121; i <= 160; i++) {
      const id = 'team_' + i; if (state.teams[id]) continue;
      const players = [];
      for (let j = 1; j <= 22; j++) { let r = 60 + ((i * j + j) % 31); if (r > 91) r = 91; players.push({ number: j, name: (window.FFMStoreData ? FFMStoreData.careerName((i - 2) * 22 + (j - 1)) : fakeFirstNames[(i * j) % fakeFirstNames.length] + ' ' + fakeLastNames[(i + j) % fakeLastNames.length]), rating: r, contractMatches: 10, onBench: j > 11 }); }
      state.teams[id] = { id, name: 'team_' + i, players };
      if (state.careerStandings && state.careerStandings[id] == null) state.careerStandings[id] = 0;
    }
  }

  /* ---------- season goals ---------- */
  const GOAL_POOL = [
    { id: 'top8', t: () => L('أنهِ الموسم ضمن أول 8', 'Finish in the top 8', 'Terminez dans le top 8', 'Termina entre los 8 primeros', 'Termine no top 8', 'Beende die Saison in den Top 8', 'İlk 8\'de bitir'), ok: (ss, rk) => rk <= 8 },
    { id: 'top5', t: () => L('أنهِ الموسم ضمن أول 5', 'Finish in the top 5', 'Terminez dans le top 5', 'Termina entre los 5 primeros', 'Termine no top 5', 'Beende die Saison in den Top 5', 'İlk 5\'te bitir'), ok: (ss, rk) => rk <= 5 },
    { id: 'top3', t: () => L('أنهِ الموسم ضمن أول 3', 'Finish in the top 3', 'Terminez dans le top 3', 'Termina entre los 3 primeros', 'Termine no top 3', 'Beende die Saison in den Top 3', 'İlk 3\'te bitir'), ok: (ss, rk) => rk <= 3 },
    { id: 'wins8', t: () => L('اربح 8 مباريات في الموسم', 'Win 8 matches this season', 'Gagnez 8 matchs', 'Gana 8 partidos esta temporada', 'Ganhe 8 jogos esta época', 'Gewinne 8 Spiele in dieser Saison', 'Bu sezon 8 maç kazan'), ok: (ss) => ss.w >= 8, prog: (ss) => [ss.w, 8] },
    { id: 'wins12', t: () => L('اربح 12 مباراة في الموسم', 'Win 12 matches this season', 'Gagnez 12 matchs', 'Gana 12 partidos esta temporada', 'Ganhe 12 jogos esta época', 'Gewinne 12 Spiele in dieser Saison', 'Bu sezon 12 maç kazan'), ok: (ss) => ss.w >= 12, prog: (ss) => [ss.w, 12] },
    { id: 'gf25', t: () => L('سجّل 25 هدفًا في الموسم', 'Score 25 goals this season', 'Marquez 25 buts', 'Marca 25 goles esta temporada', 'Marque 25 golos esta época', 'Erziele 25 Tore in dieser Saison', 'Bu sezon 25 gol at'), ok: (ss) => ss.gf >= 25, prog: (ss) => [ss.gf, 25] },
    { id: 'gf35', t: () => L('سجّل 35 هدفًا في الموسم', 'Score 35 goals this season', 'Marquez 35 buts', 'Marca 35 goles esta temporada', 'Marque 35 golos esta época', 'Erziele 35 Tore in dieser Saison', 'Bu sezon 35 gol at'), ok: (ss) => ss.gf >= 35, prog: (ss) => [ss.gf, 35] },
    { id: 'cs6', t: () => L('6 شباك نظيفة في الموسم', '6 clean sheets this season', '6 cages inviolées', '6 porterías a cero esta temporada', '6 jogos sem sofrer golos esta época', '6 Zu-Null-Spiele in dieser Saison', 'Bu sezon 6 kez kalesini kapalı tut'), ok: (ss) => ss.cs >= 6, prog: (ss) => [ss.cs, 6] },
    { id: 'loss5', t: () => L('لا تخسر أكثر من 5 مباريات', 'Lose at most 5 matches', 'Perdez au plus 5 matchs', 'Pierde como máximo 5 partidos', 'Perca no máximo 5 jogos', 'Verliere höchstens 5 Spiele', 'En fazla 5 maç kaybet'), ok: (ss) => ss.l <= 5 }
  ];
  function goalsSync() { const g = eng().goals; if (!g.list.length) { g.list = seededPick(GOAL_POOL, g.no * 13 + 5, 3).map(x => x.id); g.done = []; } return g; }

  /* ---------- leaderboard (offline, simulated rivals) ---------- */
  function lbSync() {
    const l = eng().lb, wk = weekNum();
    if (l.week !== wk) { if (l.week >= 0) l.last = { week: l.week, pts: l.pts, claimed: false }; l.week = wk; l.pts = 0; }
    return l;
  }
  function lbRivals(wk, fraction) {
    const r = srnd(wk * 977 + 11), out = [];
    for (let i = 0; i < 29; i++) {
      const fin = Math.round(40 + r() * 260 * (0.4 + r())), name = fakeFirstNames[Math.floor(r() * fakeFirstNames.length)] + ' ' + fakeLastNames[Math.floor(r() * fakeLastNames.length)];
      out.push({ name, fin, pts: Math.round(fin * Math.pow(fraction, 0.8)) });
    }
    return out;
  }
  const weekFraction = () => Math.min(1, ((dayNum() + 3) % 7 + (now() % DAY) / DAY) / 7);
  function lbRank(pts, wk, fr) { const rv = lbRivals(wk, fr); return 1 + rv.filter(x => x.pts > pts).length; }
  const lbPrize = (rk) => rk === 1 ? { tok: 3000, vch: 5 } : rk <= 3 ? { tok: 1500, vch: 3 } : rk <= 10 ? { tok: 800, vch: 1 } : rk <= 20 ? { tok: 400 } : { tok: 150 };
  function lbAdd(n) { lbSync().pts += n; }

  /* ---------- cups ---------- */
  const CUPS = {
    local: { name: () => L('كأس الدوري', 'League Cup', 'Coupe de la Ligue', 'Copa de la Liga', 'Taça da Liga', 'Ligapokal', 'Lig Kupası'), icon: '🏆', rounds: 3, cool: 20 * HOUR, boost: 0, rn: () => [L('ربع النهائي', 'Quarter-final', 'Quart de finale', 'Cuartos de final', 'Quartos de final', 'Viertelfinale', 'Çeyrek final'), L('نصف النهائي', 'Semi-final', 'Demi-finale', 'Semifinal', 'Meia-final', 'Halbfinale', 'Yarı final'), L('النهائي', 'Final', 'Finale', 'Final', 'Final', 'Finale', 'Final')], rew: [{ tok: 200 }, { tok: 400, xp: 20 }, { tok: 800, vch: 1, xp: 40 }], trophy: { tok: 2000, vch: 2, shards: 3 } },
    cont: { name: () => L('البطولة القارية', 'Continental Cup', 'Coupe continentale', 'Copa Continental', 'Taça Continental', 'Kontinentalpokal', 'Kıta Kupası'), icon: '🌍', rounds: 4, cool: 48 * HOUR, boost: 4, rn: () => [L('دور الـ16', 'Round of 16', '8es de finale', 'Octavos de final', 'Oitavos de final', 'Achtelfinale', 'Son 16 turu'), L('ربع النهائي', 'Quarter-final', 'Quart de finale', 'Cuartos de final', 'Quartos de final', 'Viertelfinale', 'Çeyrek final'), L('نصف النهائي', 'Semi-final', 'Demi-finale', 'Semifinal', 'Meia-final', 'Halbfinale', 'Yarı final'), L('النهائي', 'Final', 'Finale', 'Final', 'Final', 'Finale', 'Final')], rew: [{ tok: 300 }, { tok: 600, xp: 20 }, { tok: 1000, vch: 1, xp: 40 }, { tok: 1500, vch: 2, xp: 60 }], trophy: { tok: 5000, vch: 4, shards: 10 } }
  };
  const contUnlocked = () => state.currentTier <= 5;
  window.engCupPlay = function (k) {
    const c = eng().cups[k], def = CUPS[k], t = now();
    if (k === 'cont' && !contUnlocked()) return;
    if (!c.alive) { if (t < c.next) return; c.alive = true; c.round = 0; saveGame(); }
    let ids = tierIds(k === 'cont' && state.currentTier > 1 ? state.currentTier - 1 : state.currentTier, false);
    if (!ids.length) ids = tierIds(state.currentTier, false);
    const opp = ids[rnd(ids.length)];
    matchContext.type = 'cup'; matchContext.cupKey = k; matchContext.myTeamId = 'team_1'; matchContext.oppTeamId = opp;
    setupTacticsScreen();
  };

  /* ---------- challenge ---------- */
  const CHAL = [
    { id: 'win', t: () => L('اربح المباراة', 'Win the match', 'Gagnez le match', 'Gana el partido', 'Ganhe o jogo', 'Gewinne das Spiel', 'Maçı kazan'), ok: (a, b) => a > b },
    { id: 'win2', t: () => L('اربح بفارق هدفين أو أكثر', 'Win by 2+ goals', 'Gagnez par 2 buts ou plus', 'Gana por 2 o más goles', 'Ganhe por 2 ou mais golos', 'Gewinne mit 2+ Toren Unterschied', '2+ farkla kazan'), ok: (a, b) => a - b >= 2 },
    { id: 'cs', t: () => L('اربح دون أن يدخل مرماك هدف', 'Win without conceding', 'Gagnez sans encaisser', 'Gana sin encajar', 'Ganhe sem sofrer golos', 'Gewinne ohne Gegentor', 'Gol yemeden kazan'), ok: (a, b) => a > b && b === 0 },
    { id: 'score3', t: () => L('سجّل 3 أهداف أو أكثر', 'Score 3+ goals', 'Marquez 3 buts ou plus', 'Marca 3 o más goles', 'Marque 3 ou mais golos', 'Erziele 3+ Tore', '3+ gol at'), ok: (a, b) => a >= 3 }
  ];
  const chalToday = () => CHAL[dayNum() % CHAL.length];
  function chalSync() { const c = eng().chal, dn = dayNum(); if (c.day !== dn) { c.day = dn; c.tries = 0; c.done = false; } return c; }
  window.engChalPlay = function () {
    const c = chalSync(); if (c.done || c.tries >= 3) return;
    const ids = tierIds(state.currentTier > 1 ? state.currentTier - 1 : 1, false), opp = ids[rnd(ids.length)];
    matchContext.type = 'challenge'; matchContext.myTeamId = 'team_1'; matchContext.oppTeamId = opp; setupTacticsScreen();
  };

  /* ---------- match hooks ---------- */
  const _sm = window.startMatchSimulation;
  window.startMatchSimulation = function (forced) {
    const ctx = Object.assign({}, matchContext), pre = { season: state.careerSeasonMatches || 0, tier: state.currentTier };
    _sm.apply(this, arguments);
    const pop = $('result-popup'); if (!pop || pop.style.display !== 'flex') return;
    const m = String($('popup-score').innerText).match(/(\d+)\D+(\d+)/); if (!m) return;
    try { onMatch(ctx, +m[1], +m[2], pre); } catch (err) { console.error(err); }
  };
  const _cp = window.closePopup;
  window.closePopup = function () { const ty = matchContext.type; _cp.apply(this, arguments); if (ty === 'cup') go('cup'); else if (ty === 'challenge') go('chal'); };
  const _st = window.setupTacticsScreen;
  window.setupTacticsScreen = function () { _st.apply(this, arguments); if (matchContext.type === 'cup' || matchContext.type === 'challenge') { const b = $('tactics-back-btn'); if (b) b.setAttribute('onclick', "FFMEng.go('hub')"); } };
  const _sl = window.startLiveMatch;
  window.startLiveMatch = function () {
    const e = eng(), cfg = window.FFMLiveCfg; cfg.formation = e.set.form; cfg.press = e.set.press;
    let b = DIFF[e.set.diff].b; if (matchContext.type === 'challenge') b += 6; if (matchContext.type === 'cup') b += CUPS[matchContext.cupKey].boost;
    cfg.oppBoost = b; return _sl.apply(this, arguments);
  };

  function popupAppend(txt) { const e = $('popup-teams-details'); if (e) e.innerText += ' • ' + txt; }
  function onMatch(ctx, my, opp, pre) {
    const e = eng(), st = e.stats, win = my > opp, draw = my === opp;
    st.matches++; st.goals += my; st.conceded += opp; if (win) { st.wins++; st.streak++; st.bestStreak = Math.max(st.bestStreak, st.streak); } else { st.streak = 0; if (draw) st.draws++; else st.losses++; }
    if (opp === 0) st.cs++;
    event('match', 1); if (win) event('win', 1); if (my) event('goals', my); if (opp === 0) event('cs', 1);
    addXp(20 + (win ? 15 : 0)); lbAdd((win ? 3 : draw ? 1 : 0) + my);
    const ups = xpPlayers(win); if (ups.length) toast('⭐ ' + L('ترقية مستوى', 'Level up', 'Niveau +', 'Subida de nivel', 'Subida de nível', 'Level-Up', 'Seviye atladın'), ups.slice(0, 3).join(' • '));
    if (ctx.type === 'career') {
      event('careerPlay', 1); if (win) event('careerWin', 1);
      const base = parseInt($('popup-tokens-earned').innerText) || 0, mult = tierMult() * DIFF[e.set.diff].m, extra = Math.round(base * (mult - 1));
      if (extra !== 0) { state.tokens = Math.max(0, state.tokens + extra); $('popup-tokens-earned').innerText = base + extra; updateTokenDisplay(); }
      const ss = e.ss; ss.p++; ss.gf += my; ss.ga += opp; if (win) ss.w++; else if (draw) ss.d++; else ss.l++; if (opp === 0) ss.cs++;
      if (pre.season === 18 && (state.careerSeasonMatches || 0) === 0) seasonEnd();
    } else if (ctx.type === 'cup') cupResult(my, opp);
    else if (ctx.type === 'challenge') chalResult(my, opp);
    saveGame(); checkAch();
  }
  function cupResult(my, opp) {
    const k = matchContext.cupKey, def = CUPS[k], c = eng().cups[k], rn = def.rn();
    let adv = my > opp, pens = '';
    if (my === opp) {
      const mp = state.teams.team_1.players.slice(0, 11).reduce((a, p) => a + p.rating, 0) / 11, op = state.teams[matchContext.oppTeamId].players.slice(0, 11).reduce((a, p) => a + p.rating, 0) / 11;
      adv = Math.random() < Math.max(0.25, Math.min(0.75, 0.5 + (mp - op) * 0.012)); pens = L(' (ركلات الترجيح)', ' (penalties)', ' (tirs au but)', ' (penaltis)', ' (penáltis)', ' (Elfmeterschießen)', ' (penaltılar)');
    }
    if (adv) {
      const r = def.rew[c.round]; const g = give(r); event('cupRound', 1); lbAdd(5); c.round++;
      let msg = rn[c.round - 1] + ' ✔' + pens + ' — ' + g.text;
      if (c.round >= def.rounds) { const g2 = give(def.trophy); c.alive = false; c.round = 0; c.next = now() + def.cool; eng().stats.cups++; msg += ' • 🏆 ' + L('بطل!', 'Champion!', 'Champion !', '¡Campeón!', 'Campeão!', 'Meister!', 'Şampiyon!') + ' ' + g2.text; }
      popupAppend(def.name() + ': ' + msg);
    } else { c.alive = false; c.round = 0; c.next = now() + def.cool; popupAppend(def.name() + ': ' + L('خرجت من البطولة', 'Eliminated', 'Éliminé', 'Eliminado', 'Eliminado', 'Ausgeschieden', 'Elendin') + pens); }
  }
  function chalResult(my, opp) {
    const c = chalSync(), ch = chalToday(); c.tries++;
    if (!c.done && ch.ok(my, opp)) { c.done = true; eng().stats.challenges++; lbAdd(5); const g = give({ tok: 800, vch: 2, shards: 2, xp: 60 }); popupAppend('🔥 ' + L('تم إنجاز التحدي', 'Challenge complete', 'Défi réussi', 'Desafío superado', 'Desafio concluído', 'Herausforderung geschafft', 'Meydan okuma tamamlandı') + ' ' + g.text); }
    else if (!c.done) popupAppend('🔥 ' + L('لم يكتمل التحدي', 'Challenge not met', 'Défi non réussi', 'Desafío no superado', 'Desafio não cumprido', 'Herausforderung nicht geschafft', 'Meydan okuma başarısız') + ' (' + c.tries + '/3)');
  }
  function seasonEnd() {
    const e = eng(), rank = state.lastCareerSeasonRank || 20, promoted = !!state.lastCareerSeasonPromoted, lines = [];
    let relegated = false;
    if (promoted) { e.stats.promotions++; lines.push('⬆️ ' + L('صعود إلى', 'Promoted to', 'Promu en', 'Ascendido a', 'Promovido a', 'Aufgestiegen in', 'Yükseldin:') + ' ' + tierName(state.currentTier)); }
    else if (rank >= 18 && state.currentTier < CAREER_TIERS) { state.currentTier++; relegated = true; tierIds(state.currentTier, true).forEach(id => { state.careerStandings[id] = 0; }); lines.push('⬇️ ' + L('هبوط إلى', 'Relegated to', 'Relégué en', 'Descendido a', 'Despromovido a', 'Abgestiegen in', 'Düştün:') + ' ' + tierName(state.currentTier)); }
    if (rank === 1) { const g = give({ tok: 1500, vch: 2 }); lines.push('🥇 ' + L('بطل الدوري', 'League champion', 'Champion', 'Campeón de liga', 'Campeão da liga', 'Ligameister', 'Lig şampiyonu') + ' ' + g.text); }
    const g = goalsSync(); g.list.forEach(id => { const d = GOAL_POOL.find(x => x.id === id); const ok = d.ok(e.ss, rank); lines.push((ok ? '✅ ' : '❌ ') + d.t()); if (ok) give({ tok: 500, vch: 1 }); });
    addXp(100);
    e.ss = { w: 0, d: 0, l: 0, gf: 0, ga: 0, cs: 0, p: 0 }; g.no++; g.list = []; goalsSync();
    updateTokenDisplay(); saveGame();
    setTimeout(() => modal('📅 ' + L('نهاية الموسم', 'Season complete', 'Fin de saison', 'Temporada completada', 'Época concluída', 'Saison abgeschlossen', 'Sezon tamamlandı') + ' — #' + rank, lines.join('<br>')), 1200);
  }
  function checkAch() {
    ACH.forEach(a => { const st = eng().ach; if (!st[a.id] && achGet(a) >= a.goal) { st[a.id] = 1; toast('🏆 ' + L('إنجاز جديد', 'Achievement', 'Succès', 'Logro', 'Conquista', 'Erfolg', 'Başarım'), achName(a)); } });
  }

  /* ---------- notifications ---------- */
  function notifs() {
    const e = eng(), out = [], d = dailyState(), tk = tasksSync(); acc(); chalSync(); lbSync(); passSync();
    if (d.can) out.push({ k: 'daily', i: '📅', t: L('مكافأة اليوم جاهزة', 'Daily reward ready', 'Récompense du jour prête', 'Recompensa diaria lista', 'Recompensa diária pronta', 'Tägliche Belohnung bereit', 'Günlük ödül hazır'), v: 'daily' });
    if (tk.tasks.list.some(x => x.p >= defOf(x.id).n && !x.c) || tk.weekly.list.some(x => x.p >= defOf(x.id).n && !x.c)) out.push({ k: 'task', i: '📋', t: L('مهام جاهزة للاستلام', 'Tasks ready to claim', 'Missions à récupérer', 'Tareas listas para reclamar', 'Tarefas prontas para receber', 'Aufgaben zum Abholen bereit', 'Görevler alınmaya hazır'), v: 'tasks' });
    if (e.free.n > 0) out.push({ k: 'free', i: '🎁', t: L('حزمة مجانية جاهزة (' + e.free.n + ')', 'Free pack ready (' + e.free.n + ')', 'Pack gratuit prêt (' + e.free.n + ')', 'Sobre gratis listo (' + e.free.n + ')', 'Pacote grátis pronto (' + e.free.n + ')', 'Gratis-Pack bereit (' + e.free.n + ')', 'Ücretsiz paket hazır (' + e.free.n + ')'), v: 'free' });
    if (e.wheel.day !== dayNum() || e.wheel.used < 1) out.push({ k: 'wheel', i: '🎡', t: L('دورة العجلة المجانية متاحة', 'Free wheel spin available', 'Tour de roue gratuit', 'Giro gratis de la ruleta disponible', 'Rotação grátis da roleta disponível', 'Gratis-Dreh am Glücksrad verfügbar', 'Ücretsiz çark çevirme hakkı var'), v: 'wheel' });
    const p = e.pass, lv = passLvl(); if (Array.from({ length: lv }, (_, i) => i + 1).some(l => !p.free.includes(l) || (p.premium && !p.prem.includes(l)))) out.push({ k: 'pass', i: '🏅', t: L('جوائز الموسم جاهزة', 'Season pass rewards ready', 'Récompenses du pass prêtes', 'Recompensas del pase de temporada listas', 'Recompensas do passe de época prontas', 'Season-Pass-Belohnungen bereit', 'Sezon bileti ödülleri hazır'), v: 'pass' });
    if (ACH.some(a => achGet(a) >= a.goal && !e.ach[a.id + 'c'])) out.push({ k: 'ach', i: '🏆', t: L('إنجازات جاهزة للاستلام', 'Achievements ready', 'Succès à récupérer', 'Logros listos', 'Conquistas prontas', 'Erfolge bereit', 'Başarımlar hazır'), v: 'ach' });
    if (!e.chal.done && e.chal.tries < 3) out.push({ k: 'chal', i: '🔥', t: L('تحدي اليوم متاح', 'Daily challenge available', 'Défi du jour disponible', 'Desafío diario disponible', 'Desafio diário disponível', 'Tägliche Herausforderung verfügbar', 'Günlük meydan okuma hazır'), v: 'chal' });
    if (e.lb.last && !e.lb.last.claimed) out.push({ k: 'lb', i: '📊', t: L('جائزة لوحة الترتيب الأسبوعية', 'Weekly leaderboard prize', 'Prix du classement hebdo', 'Premio de la clasificación semanal', 'Prémio do ranking semanal', 'Preis der Wochenrangliste', 'Haftalık sıralama ödülü'), v: 'lb' });
    if (state.teams && state.teams.team_1 && state.teams.team_1.players.slice(0, 11).some(q => q.contractMatches <= 2 && q.contractMatches >= 0)) out.push({ k: 'contract', i: '📄', t: L('عقود لاعبين أساسيين قاربت على الانتهاء', 'Starter contracts about to expire', 'Contrats de titulaires bientôt expirés', 'Contratos iniciales a punto de caducar', 'Contratos iniciais prestes a expirar', 'Startverträge laufen bald aus', 'Başlangıç sözleşmeleri bitmek üzere'), v: 'contracts' });
    const o = window.FFMStore.offers(); out.push({ k: 'offer', i: '⏱', t: L('عروض المتجر المحدودة نشطة', 'Limited store offers active', 'Offres boutique actives', 'Ofertas limitadas de la tienda activas', 'Ofertas limitadas da loja ativas', 'Zeitlich begrenzte Shop-Angebote aktiv', 'Sınırlı mağaza teklifleri aktif'), v: 'store' });
    if (e.cups.local.next <= now() || e.cups.local.alive) out.push({ k: 'cup', i: '🏆', t: L('الكأس متاحة', 'Cup available', 'Coupe disponible', 'Copa disponible', 'Taça disponível', 'Pokal verfügbar', 'Kupa mevcut'), v: 'cup' });
    return out;
  }
  const readyCount = () => notifs().filter(n => n.k !== 'offer' && n.k !== 'contract' && n.k !== 'cup').length;
  function updateBadges() {
    const n = readyCount();
    ['bell-btn', 'hub-open-btn'].forEach(id => { const b = $(id); if (!b) return; let s = b.querySelector('.eng-badge'); if (!s) { s = document.createElement('span'); s.className = 'eng-badge'; b.appendChild(s); } s.textContent = n; s.style.display = n ? 'inline-block' : 'none'; });
    const ks = notifs().map(x => x.k);
    document.querySelectorAll('#screen-main-menu [data-k]').forEach(b => {
      const c = b.dataset.k.split(',').filter(k => ks.includes(k)).length; let s = b.querySelector('.eng-badge');
      if (!s) { s = document.createElement('span'); s.className = 'eng-badge mm-bdg'; b.appendChild(s); } s.textContent = '!'; s.style.display = c ? 'inline-block' : 'none';
    });
  }
  function sysNotify() {
    if (!('Notification' in window) || Notification.permission !== 'granted' || !eng().notif.sys || !document.hidden) return;
    const seen = eng().notif.seen;
    notifs().filter(n => ['daily', 'free', 'task', 'chal'].includes(n.k)).forEach(n => { const key = n.k + dayKey() + (n.k === 'free' ? eng().free.n : ''); if (!seen[key]) { seen[key] = 1; try { new Notification('FFM 26', { body: n.t }); } catch (x) {} } });
  }

  /* ---------- views ---------- */
  let view = 'hub', wheelBusy = false;
  const pbar = (a, b) => `<div class="st-bar"><i style="width:${Math.min(100, a / b * 100)}%"></i></div>`;
  function head(title) {
    return `<div class="st-head"><div class="st-title">${title}</div><div class="st-chip">🎟️ <b class="st-vouch-n">0</b></div></div><div class="st-sub"><span>🪙 <b class="st-tok-n">0</b></span> &nbsp; <span>🔩 <b class="eng-sh-n">0</b></span></div>`;
  }
  const GROUP_OF = { daily: 'g_rew', tasks: 'g_rew', wheel: 'g_rew', free: 'g_rew', pass: 'g_sea', ach: 'g_sea', goals: 'g_sea', chal: 'g_cmp', lb: 'g_cmp', cup: 'g_cmp', album: 'g_col', upg: 'g_col' };
  const back = (to) => `<div class="back-bar"><button class="godot-btn" onclick="FFMEng.go('${to || GROUP_OF[view] || 'menu'}')">${L('رجوع', 'Back', 'Retour', 'Volver', 'Voltar', 'Zurück', 'Geri')}</button></div>`;
  const btn = (txt, on, cls, dis) => `<button class="godot-btn ${cls || ''}${dis ? ' st-dim' : ''}" ${dis ? 'disabled' : `onclick="${on}"`}>${txt}</button>`;
  function refreshAll() { document.querySelectorAll('.st-vouch-n').forEach(x => x.textContent = fmt(S().vouchers)); document.querySelectorAll('.st-tok-n').forEach(x => x.textContent = fmt(state.tokens)); document.querySelectorAll('.eng-sh-n').forEach(x => x.textContent = fmt(S().shards || 0)); updateBadges(); }
  function tile(icon, title, sub, v, badge) { return `<button class="godot-btn eng-tile" onclick="FFMEng.go('${v}')"><span class="eng-ti">${icon}</span><b>${title}</b><small>${sub}</small>${badge ? '<span class="eng-badge">!</span>' : ''}</button>`; }

  const V = {};
  V.hub = () => {
    const n = notifs(), has = (k) => n.some(x => x.k === k);
    return head('🎁 ' + L('مركز المكافآت', 'Rewards Hub', 'Centre de récompenses', 'Centro de recompensas', 'Centro de recompensas', 'Belohnungszentrum', 'Ödül Merkezi')) + `<div class="eng-grid">` +
      tile('📅', L('المكافآت اليومية', 'Daily rewards', 'Récompenses', 'Recompensas diarias', 'Recompensas diárias', 'Tägliche Belohnungen', 'Günlük ödüller'), L('7 أيام + تقويم الشهر', '7 days + monthly calendar', '7 jours + calendrier', '7 días + calendario mensual', '7 dias + calendário mensal', '7 Tage + Monatskalender', '7 gün + aylık takvim'), 'daily', has('daily')) +
      tile('📋', L('المهام', 'Tasks', 'Missions', 'Tareas', 'Tarefas', 'Aufgaben', 'Görevler'), L('يومية وأسبوعية', 'Daily & weekly', 'Quotidiennes et hebdo', 'Diarias y semanales', 'Diárias e semanais', 'Täglich & wöchentlich', 'Günlük ve haftalık'), 'tasks', has('task')) +
      tile('🎡', L('عجلة الحظ', 'Lucky wheel', 'Roue de la chance', 'Ruleta de la suerte', 'Roleta da sorte', 'Glücksrad', 'Şans çarkı'), L('دورة مجانية يوميًا', 'Free spin daily', 'Tour gratuit', 'Giro gratis al día', 'Rotação grátis por dia', 'Täglich ein Gratis-Dreh', 'Günde bir ücretsiz çevirme'), 'wheel', has('wheel')) +
      tile('🎁', L('حزمة مجانية', 'Free pack', 'Pack gratuit', 'Sobre gratis', 'Pacote grátis', 'Gratis-Pack', 'Ücretsiz paket'), L('كل 8 ساعات', 'Every 8 hours', 'Toutes les 8 h', 'Cada 8 horas', 'A cada 8 horas', 'Alle 8 Stunden', 'Her 8 saatte bir'), 'free', has('free')) +
      tile('🏅', L('موسم باس', 'Season Pass', 'Pass de saison', 'Pase de temporada', 'Passe de época', 'Season Pass', 'Sezon Bileti'), L('30 مستوى', '30 levels', '30 niveaux', '30 niveles', '30 níveis', '30 Level', '30 seviye'), 'pass', has('pass')) +
      tile('🏆', L('الإنجازات', 'Achievements', 'Succès', 'Logros', 'Conquistas', 'Erfolge', 'Başarımlar'), L('قاعة المجد', 'Hall of fame', 'Palmarès', 'Salón de la fama', 'Hall da fama', 'Ruhmeshalle', 'Şöhret salonu'), 'ach', has('ach')) +
      tile('📚', L('ألبوم الجمع', 'Collection album', 'Album', 'Álbum de colección', 'Álbum de coleção', 'Sammelalbum', 'Koleksiyon albümü'), L('أكمل المجموعات', 'Complete sets', 'Complétez les séries', 'Completa los conjuntos', 'Complete os conjuntos', 'Vervollständige Sets', 'Setleri tamamla'), 'album') +
      tile('⬆️', L('تطوير اللاعبين', 'Upgrade players', 'Améliorer', 'Mejorar jugadores', 'Melhorar jogadores', 'Spieler verbessern', 'Oyuncuları geliştir'), L('توكن + قطع', 'Tokens + shards', 'Jetons + pièces', 'Fichas + fragmentos', 'Fichas + fragmentos', 'Tokens + Splitter', 'Jeton + parça'), 'upg') +
      tile('🔥', L('تحدي اليوم', 'Daily challenge', 'Défi du jour', 'Desafío diario', 'Desafio diário', 'Tägliche Herausforderung', 'Günlük meydan okuma'), chalToday().t(), 'chal', has('chal')) +
      tile('📊', L('لوحة الترتيب', 'Leaderboard', 'Classement', 'Clasificación', 'Ranking', 'Rangliste', 'Sıralama'), L('أسبوعية', 'Weekly', 'Hebdo', 'Semanal', 'Semanal', 'Wöchentlich', 'Haftalık'), 'lb', has('lb')) +
      tile('🏆', L('الكأس والبطولات', 'Cups', 'Coupes', 'Copas', 'Taças', 'Pokale', 'Kupalar'), L('إقصائيات', 'Knockouts', 'Éliminatoires', 'Eliminatorias', 'Eliminatórias', 'K.-o.-Runden', 'Eleme maçları'), 'cup') +
      tile('🎯', L('أهداف الموسم', 'Season goals', 'Objectifs', 'Objetivos de temporada', 'Objetivos da época', 'Saisonziele', 'Sezon hedefleri'), L('مكافآت نهاية الموسم', 'End-of-season rewards', 'Récompenses', 'Recompensas de fin de temporada', 'Recompensas de fim de época', 'Belohnungen zum Saisonende', 'Sezon sonu ödülleri'), 'goals') +
      tile('⚙️', L('التكتيك والصعوبة', 'Tactics & difficulty', 'Tactique', 'Táctica y dificultad', 'Tática e dificuldade', 'Taktik & Schwierigkeit', 'Taktik ve zorluk'), L('خطة، ضغط، صعوبة', 'Formation, press, level', 'Schéma, pressing', 'Formación, presión, nivel', 'Formação, pressão, nível', 'Formation, Pressing, Stufe', 'Diziliş, pres, seviye'), 'tact') +
      tile('🔔', L('الإشعارات', 'Notifications', 'Notifications', 'Notificaciones', 'Notificações', 'Benachrichtigungen', 'Bildirimler'), L('ما ينتظرك', 'What awaits you', 'À récupérer', 'Lo que te espera', 'O que te espera', 'Was dich erwartet', 'Seni neler bekliyor'), 'bell') + `</div>` +
      `<div class="back-bar"><button class="godot-btn" onclick="showScreen('screen-main-menu')">${L('رجوع', 'Back', 'Retour', 'Volver', 'Voltar', 'Zurück', 'Geri')}</button></div>`;
  };

  const grpPage = (icon, title, tiles) => head(icon + ' ' + title) + `<div class="eng-grid">` + tiles + `</div>` + `<div class="back-bar"><button class="godot-btn" onclick="FFMEng.go('menu')">${L('رجوع', 'Back', 'Retour', 'Volver', 'Voltar', 'Zurück', 'Geri')}</button></div>`;
  const hasK = (k) => notifs().some(x => x.k === k);
  V.g_rew = () => grpPage('🎁', L('المكافآت', 'Rewards', 'Récompenses', 'Premios', 'Prémios', 'Belohnungen', 'Ödüller'),
    tile('📅', L('المكافآت اليومية', 'Daily rewards', 'Récompenses', 'Recompensas diarias', 'Recompensas diárias', 'Tägliche Belohnungen', 'Günlük ödüller'), L('7 أيام + تقويم الشهر', '7 days + monthly calendar', '7 jours + calendrier', '7 días + calendario mensual', '7 dias + calendário mensal', '7 Tage + Monatskalender', '7 gün + aylık takvim'), 'daily', hasK('daily')) +
    tile('📋', L('المهام', 'Tasks', 'Missions', 'Tareas', 'Tarefas', 'Aufgaben', 'Görevler'), L('يومية وأسبوعية', 'Daily & weekly', 'Quotidiennes et hebdo', 'Diarias y semanales', 'Diárias e semanais', 'Täglich & wöchentlich', 'Günlük ve haftalık'), 'tasks', hasK('task')) +
    tile('🎡', L('عجلة الحظ', 'Lucky wheel', 'Roue de la chance', 'Ruleta de la suerte', 'Roleta da sorte', 'Glücksrad', 'Şans çarkı'), L('دورة مجانية يوميًا', 'Free spin daily', 'Tour gratuit', 'Giro gratis al día', 'Rotação grátis por dia', 'Täglich ein Gratis-Dreh', 'Günde bir ücretsiz çevirme'), 'wheel', hasK('wheel')) +
    tile('🎁', L('حزمة مجانية', 'Free pack', 'Pack gratuit', 'Sobre gratis', 'Pacote grátis', 'Gratis-Pack', 'Ücretsiz paket'), L('كل 8 ساعات', 'Every 8 hours', 'Toutes les 8 h', 'Cada 8 horas', 'A cada 8 horas', 'Alle 8 Stunden', 'Her 8 saatte bir'), 'free', hasK('free')));
  V.g_sea = () => grpPage('🏅', L('الموسم والإنجازات', 'Season & Achievements', 'Saison et succès', 'Temporada y logros', 'Época e conquistas', 'Saison & Erfolge', 'Sezon ve başarımlar'),
    tile('🏅', L('موسم باس', 'Season Pass', 'Pass de saison', 'Pase de temporada', 'Passe de época', 'Season Pass', 'Sezon Bileti'), L('30 مستوى', '30 levels', '30 niveaux', '30 niveles', '30 níveis', '30 Level', '30 seviye'), 'pass', hasK('pass')) +
    tile('🏆', L('الإنجازات', 'Achievements', 'Succès', 'Logros', 'Conquistas', 'Erfolge', 'Başarımlar'), L('قاعة المجد', 'Hall of fame', 'Palmarès', 'Salón de la fama', 'Hall da fama', 'Ruhmeshalle', 'Şöhret salonu'), 'ach', hasK('ach')) +
    tile('🎯', L('أهداف الموسم', 'Season goals', 'Objectifs', 'Objetivos de temporada', 'Objetivos da época', 'Saisonziele', 'Sezon hedefleri'), L('مكافآت نهاية الموسم', 'End-of-season rewards', 'Récompenses', 'Recompensas de fin de temporada', 'Recompensas de fim de época', 'Belohnungen zum Saisonende', 'Sezon sonu ödülleri'), 'goals'));
  V.g_cmp = () => grpPage('🏆', L('المنافسات', 'Competitions', 'Compétitions', 'Competiciones', 'Competições', 'Wettbewerbe', 'Yarışmalar'),
    tile('🔥', L('تحدي اليوم', 'Daily challenge', 'Défi du jour', 'Desafío diario', 'Desafio diário', 'Tägliche Herausforderung', 'Günlük meydan okuma'), chalToday().t(), 'chal', hasK('chal')) +
    tile('🏆', L('الكأس والبطولات', 'Cups', 'Coupes', 'Copas', 'Taças', 'Pokale', 'Kupalar'), L('إقصائيات', 'Knockouts', 'Éliminatoires', 'Eliminatorias', 'Eliminatórias', 'K.-o.-Runden', 'Eleme maçları'), 'cup', hasK('cup')) +
    tile('📊', L('لوحة الترتيب', 'Leaderboard', 'Classement', 'Clasificación', 'Ranking', 'Rangliste', 'Sıralama'), L('أسبوعية', 'Weekly', 'Hebdo', 'Semanal', 'Semanal', 'Wöchentlich', 'Haftalık'), 'lb', hasK('lb')));
  V.g_col = () => grpPage('📚', L('المجموعة', 'Collection', 'Collection', 'Colección', 'Coleção', 'Sammlung', 'Koleksiyon'),
    tile('📚', L('ألبوم الجمع', 'Collection album', 'Album', 'Álbum de colección', 'Álbum de coleção', 'Sammelalbum', 'Koleksiyon albümü'), L('أكمل المجموعات', 'Complete sets', 'Complétez les séries', 'Completa los conjuntos', 'Complete os conjuntos', 'Vervollständige Sets', 'Setleri tamamla'), 'album') +
    tile('⬆️', L('تطوير اللاعبين', 'Upgrade players', 'Améliorer', 'Mejorar jugadores', 'Melhorar jogadores', 'Spieler verbessern', 'Oyuncuları geliştir'), L('توكن + قطع', 'Tokens + shards', 'Jetons + pièces', 'Fichas + fragmentos', 'Fichas + fragmentos', 'Tokens + Splitter', 'Jeton + parça'), 'upg'));

  V.daily = () => {
    const e = eng(), d = dailyState(), m = e.month; registerLogin();
    const cells = DAILY.map((r, i) => { const st = i < d.idx ? 'done' : (i === d.idx ? (d.can ? 'now' : 'done') : ''); return `<div class="eng-day ${st}"><b>${L('يوم', 'Day', 'Jour', 'Día', 'Dia', 'Tag', 'Gün')} ${i + 1}</b><small>${rewStr(r)}</small>${st === 'done' ? '<i>✔</i>' : ''}</div>`; }).join('');
    const days = Array.from({ length: 30 }, (_, i) => i + 1).map(dd => { const cl = m.claimed.includes(dd), can = dd <= m.days && !cl; return `<button class="eng-mday ${cl ? 'done' : can ? 'now' : ''}" ${can ? `onclick="engMonthClaim(${dd})"` : ''}><b>${dd}</b><small>${dd === 30 ? '👑' : (MONTH(dd).vch ? '🎟️' : '🪙')}</small></button>`; }).join('');
    return head('📅 ' + L('المكافآت اليومية', 'Daily rewards', 'Récompenses quotidiennes', 'Recompensas diarias', 'Recompensas diárias', 'Tägliche Belohnungen', 'Günlük ödüller')) +
      `<div class="st-intro">${L('تسلسل الدخول:', 'Login streak:', 'Série :', 'Racha de acceso:', 'Sequência de acessos:', 'Login-Serie:', 'Giriş serisi:')} <b>${d.streak}</b> — ${L('إن فاتك يوم يعود العدّاد إلى اليوم الأول.', 'Miss a day and the cycle restarts at day 1.', 'Un jour manqué relance le cycle.', 'Si te saltas un día, el ciclo vuelve al día 1.', 'Se faltar um dia, o ciclo volta ao dia 1.', 'Verpasst du einen Tag, startet der Zyklus wieder bei Tag 1.', 'Bir gün atlarsan döngü 1. günden yeniden başlar.')}</div><div class="eng-days">${cells}</div>` +
      btn(d.can ? '🎁 ' + L('استلم مكافأة اليوم', 'Claim today\'s reward', 'Récupérer', 'Reclamar la recompensa de hoy', 'Receber a recompensa de hoje', 'Heutige Belohnung abholen', 'Bugünün ödülünü al') + ' (' + rewStr(DAILY[d.idx]) + ')' : '✔ ' + L('تم استلام مكافأة اليوم — عد غدًا', 'Claimed — come back tomorrow', 'Déjà récupérée — revenez demain', 'Reclamada — vuelve mañana', 'Recebida — volte amanhã', 'Abgeholt — komm morgen wieder', 'Alındı — yarın tekrar gel'), 'engDailyClaim()', 'st-big', !d.can) +
      `<h3 style="margin:14px 0 6px">${L('تقويم الشهر', 'Monthly calendar', 'Calendrier du mois', 'Calendario mensual', 'Calendário mensal', 'Monatskalender', 'Aylık takvim')} (${m.days}/30 ${L('يوم دخول', 'login days', 'jours', 'días de acceso', 'dias de acesso', 'Login-Tage', 'giriş günü')})</h3><div class="eng-mgrid">${days}</div><div class="st-intro">${L('اليوم 30: بطاقة أسطورية + 3 قسائم + 2000 توكن.', 'Day 30: Legend card + 3 vouchers + 2000 tokens.', 'Jour 30 : carte légende + 3 bons + 2000 jetons.', 'Día 30: carta de leyenda + 3 vales + 2000 fichas.', 'Dia 30: carta lendária + 3 vales + 2000 fichas.', 'Tag 30: Legendenkarte + 3 Gutscheine + 2000 Tokens.', '30. gün: Efsane kart + 3 kupon + 2000 jeton.')}</div>` + back();
  };
  window.engDailyClaim = function () {
    const d = dailyState(), e = eng(); if (!d.can) return;
    e.daily.last = dayKey(); e.daily.streak++; e.stats.loginStreak = Math.max(e.stats.loginStreak, e.daily.streak);
    const g = claimToast(L('مكافأة اليوم', 'Daily reward', 'Récompense du jour', 'Recompensa diaria', 'Recompensa diária', 'Tägliche Belohnung', 'Günlük ödül'), Object.assign({ xp: 20 }, DAILY[d.idx])); checkAch(); go('daily');
  };
  window.engMonthClaim = function (dd) {
    const m = eng().month; if (dd > m.days || m.claimed.includes(dd)) return; m.claimed.push(dd);
    const g = claimToast(L('تقويم الشهر — يوم ', 'Monthly — day ', 'Mois — jour ', 'Mensual — día ', 'Mensal — dia ', 'Monatlich — Tag ', 'Aylık — gün ') + dd, MONTH(dd)); go('daily');
  };

  V.tasks = () => {
    const e = tasksSync();
    const row = (tk, wk) => { const d = defOf(tk.id), ok = tk.p >= d.n; return `<div class="st-row" style="--tc:${ok ? '#7fe9ff' : '#35d0ff'}"><div class="st-row-h"><b>${d.t()}</b><span class="st-pct">${tk.p}/${d.n}</span></div>${pbar(tk.p, d.n)}<div class="st-row-h"><small>${rewStr(d.r)}</small>${tk.c ? '✔' : btn(L('استلام', 'Claim', 'Récupérer', 'Reclamar', 'Receber', 'Abholen', 'Al'), `engTaskClaim(${wk},'${tk.id}')`, '', !ok)}</div></div>`; };
    const dAll = e.tasks.list.every(x => x.c), wAll = e.weekly.list.every(x => x.c);
    return head('📋 ' + L('المهام', 'Tasks', 'Missions', 'Tareas', 'Tarefas', 'Aufgaben', 'Görevler')) + `<h3>${L('مهام اليوم', 'Today', 'Aujourd\'hui', 'Hoy', 'Hoje', 'Heute', 'Bugün')}</h3>` + e.tasks.list.map(x => row(x, 0)).join('') +
      btn(e.tasks.chest ? '✔ ' + L('صندوق اليوم مُستلم', 'Chest claimed', 'Coffre récupéré', 'Cofre reclamado', 'Baú recebido', 'Truhe abgeholt', 'Sandık alındı') : '🎁 ' + L('صندوق إكمال المهام الثلاث', 'All-3 chest', 'Coffre des 3 missions', 'Cofre de los 3', 'Baú dos 3', 'Truhe für alle 3', '3\'lü sandık') + ' (🎟️1 🪙300)', 'engChest(0)', 'st-big', !dAll || e.tasks.chest) +
      `<h3 style="margin-top:14px">${L('مهام الأسبوع', 'This week', 'Cette semaine', 'Esta semana', 'Esta semana', 'Diese Woche', 'Bu hafta')}</h3>` + e.weekly.list.map(x => row(x, 1)).join('') +
      btn(e.weekly.chest ? '✔ ' + L('صندوق الأسبوع مُستلم', 'Chest claimed', 'Coffre récupéré', 'Cofre reclamado', 'Baú recebido', 'Truhe abgeholt', 'Sandık alındı') : '🎁 ' + L('صندوق الأسبوع', 'Weekly chest', 'Coffre hebdo', 'Cofre semanal', 'Baú semanal', 'Wochentruhe', 'Haftalık sandık') + ' (🎟️3 🔩3)', 'engChest(1)', 'st-big', !wAll || e.weekly.chest) + back();
  };
  window.engTaskClaim = function (wk, id) {
    const e = tasksSync(), list = wk ? e.weekly.list : e.tasks.list, tk = list.find(x => x.id === id), d = defOf(id); if (!tk || tk.c || tk.p < d.n) return;
    tk.c = true; e.stats.tasks++; claimToast(d.t(), Object.assign({ xp: wk ? 80 : 30 }, d.r)); go('tasks');
  };
  window.engChest = function (wk) {
    const e = tasksSync(), o = wk ? e.weekly : e.tasks; if (o.chest || !o.list.every(x => x.c)) return; o.chest = true;
    claimToast(L('الصندوق', 'Chest', 'Coffre', 'Cofre', 'Baú', 'Truhe', 'Sandık'), wk ? { vch: 3, shards: 3, xp: 100 } : { vch: 1, tok: 300, xp: 40 }); go('tasks');
  };

  /* ----- wheel ----- */
  const WHEEL = [
    { w: 26, r: { tok: 100 }, c: '#0c3bca' }, { w: 22, r: { tok: 250 }, c: '#1984cd' }, { w: 15, r: { vch: 1 }, c: '#12a8a0' }, { w: 12, r: { tok: 500 }, c: '#0f6ace' },
    { w: 10, r: { shards: 3 }, c: '#6a1b9a' }, { w: 7, r: { free: 1 }, c: '#0a7fa8' }, { w: 5, r: { vch: 2 }, c: '#c58bff' }, { w: 3, r: { card: { tier: 4 }, tok: 0 }, c: '#e0a8ff' }
  ];
  const wheelPrize = (i) => i === 7 ? L('بطاقة 87+', 'Card 87+', 'Carte 87+', 'Carta 87+', 'Carta 87+', 'Karte 87+', 'Kart 87+') : rewStr(WHEEL[i].r);
  V.wheel = () => {
    const e = eng(), wl = e.wheel, dn = dayNum(); if (wl.day !== dn) { wl.day = dn; wl.used = 0; wl.extra = 0; }
    const free = wl.used < 1, cost = 2000, can = free || (wl.extra < 3 && state.tokens >= cost);
    let acc0 = 0; const stops = WHEEL.map((x, i) => { const a = acc0, b = acc0 + 45; acc0 = b; return `${x.c} ${a}deg ${b}deg`; }).join(',');
    const labels = WHEEL.map((x, i) => `<i style="transform:rotate(${i * 45 + 22.5}deg) translateY(-92px) rotate(${-(i * 45 + 22.5)}deg)">${i + 1}</i>`).join('');
    return head('🎡 ' + L('عجلة الحظ', 'Lucky wheel', 'Roue de la chance', 'Ruleta de la suerte', 'Roleta da sorte', 'Glücksrad', 'Şans çarkı')) + `<div class="eng-wheel-wrap"><div class="eng-pointer">▼</div><div id="eng-wheel" style="background:conic-gradient(${stops})">${labels}</div></div>` +
      btn(free ? '🎡 ' + L('أدر مجانًا', 'Spin free', 'Tour gratuit', 'Girar gratis', 'Girar grátis', 'Gratis drehen', 'Ücretsiz çevir') : '🎡 ' + L('أدر بـ 2000 توكن', 'Spin for 2000 tokens', 'Tour : 2000 jetons', 'Girar por 2000 fichas', 'Girar por 2000 fichas', 'Für 2000 Tokens drehen', '2000 jetona çevir') + ` (${wl.extra}/5)`, 'engSpin()', 'st-big', !can) +
      `<div class="eng-legend">` + WHEEL.map((x, i) => `<div><b style="background:${x.c}">${i + 1}</b> ${wheelPrize(i)} <small>${x.w}%</small></div>`).join('') + `</div>` + back();
  };
  window.engSpin = function () {
    if (wheelBusy) return; const e = eng(), wl = e.wheel, free = wl.used < 1;
    if (!free && (wl.extra >= 3 || state.tokens < 2000)) return;
    wheelBusy = true;
    if (free) wl.used = 1; else { wl.extra++; state.tokens -= 2000; updateTokenDisplay(); }
    let x = rnd(100), idx = 0; for (let i = 0; i < WHEEL.length; i++) { if (x < WHEEL[i].w) { idx = i; break; } x -= WHEEL[i].w; }
    saveGame(); event('spin', 1);
    const el = $('eng-wheel'), target = 360 * 5 + (360 - (idx * 45 + 22.5)); el.style.transition = 'transform 4s cubic-bezier(.12,.7,.1,1)'; el.style.transform = `rotate(${target}deg)`; if (window.FFMSfx) FFMSfx.wheel(4);
    setTimeout(() => { wheelBusy = false; const r = Object.assign({}, WHEEL[idx].r); if (r.card) { r.card = { tier: 4 + rnd(2) }; r.tok = 0; } const g = give(r); modal('🎡 ' + L('فزت!', 'You won!', 'Gagné !', '¡Has ganado!', 'Ganhou!', 'Du hast gewonnen!', 'Kazandın!'), g.text); refreshAll(); go('wheel'); }, 4200);
  };

  /* ----- free pack ----- */
  V.free = () => {
    const f = acc(), left = f.n >= 3 ? 0 : Math.max(0, f.t + 8 * HOUR - now());
    const dots = [0, 1, 2].map(i => `<span class="eng-dot ${i < f.n ? 'on' : ''}">🎁</span>`).join('');
    return head('🎁 ' + L('حزمة مجانية', 'Free pack', 'Pack gratuit', 'Sobre gratis', 'Pacote grátis', 'Gratis-Pack', 'Ücretsiz paket')) + `<div class="st-intro">${L('تتجدد حزمة مجانية كل 8 ساعات وتتراكم حتى 3.', 'A free pack renews every 8 hours and stacks up to 3.', 'Un pack gratuit toutes les 8 h, cumulable jusqu\'à 3.', 'Un sobre gratis se renueva cada 8 horas y se acumulan hasta 3.', 'Um pacote grátis renova a cada 8 horas e acumula até 3.', 'Alle 8 Stunden gibt es ein Gratis-Pack; bis zu 3 sammeln sich an.', 'Ücretsiz paket her 8 saatte yenilenir ve en fazla 3 birikir.')}</div><div class="eng-dots">${dots}</div>` +
      (f.n < 3 ? `<div class="st-intro">⏱ ${L('التالية بعد', 'Next in', 'Prochain dans', 'Próximo en', 'Próximo em', 'Nächstes in', 'Sonraki')} <b id="eng-free-t" data-t="${f.t + 8 * HOUR}"></b></div>` : '') +
      btn('🎁 ' + L('افتح حزمة مجانية', 'Open a free pack', 'Ouvrir un pack gratuit', 'Abre un sobre gratis', 'Abra um pacote grátis', 'Öffne ein Gratis-Pack', 'Ücretsiz bir paket aç'), 'engFreeOpen()', 'st-big', f.n < 1) + back();
  };
  window.engFreeOpen = function () {
    const f = acc(); if (f.n < 1) return; const t = now();
    const was3 = f.n >= 3; f.n--; if (was3) f.t = t; saveGame();
    const list = D.PACKS.filter(p => p.theme !== 'leg' && p.price <= 2), p = list[rnd(list.length)];
    window.FFMStoreOpenFree(p.id);
  };

  /* ----- season pass ----- */
  V.pass = () => {
    const p = passSync(), lv = passLvl(), days = 30 - ((dayNum() - SEASON_EPOCH) % 30);
    const rows = Array.from({ length: 30 }, (_, i) => i + 1).map(l => {
      const fr = passFree(l), pr = passPrem(l), reach = lv >= l, fc = p.free.includes(l), pc = p.prem.includes(l);
      return `<div class="eng-prow ${reach ? 'reach' : ''}"><b class="eng-pl">${l}</b><div class="eng-pc">${fc ? '✔' : btn(rewStr(fr), `engPassClaim(${l},0)`, '', !reach)}</div><div class="eng-pc prem">${pc ? '✔' : btn(rewStr(pr), `engPassClaim(${l},1)`, 'prem', !reach || !p.premium)}</div></div>`;
    }).join('');
    return head('🏅 ' + L('موسم باس', 'Season Pass', 'Pass de saison', 'Pase de temporada', 'Passe de época', 'Season Pass', 'Sezon Bileti')) + `<div class="st-intro">${L('المستوى', 'Level', 'Niveau', 'Nivel', 'Nível', 'Level', 'Seviye')} <b>${lv}</b>/30 • XP ${p.xp % 100}/100 • ${L('ينتهي بعد', 'ends in', 'fin dans', 'termina en', 'termina em', 'endet in', 'bitiyor:')} ${days} ${L('يومًا', 'days', 'jours', 'días', 'dias', 'Tage', 'gün')}</div>${pbar(lv >= 30 ? 100 : p.xp % 100, 100)}` +
      btn(p.premium ? '✔ ' + L('المسار المميز مفعّل', 'Premium active', 'Premium actif', 'Premium activo', 'Premium ativo', 'Premium aktiv', 'Premium aktif') : '💎 ' + L('فعّل المسار المميز (25 قسيمة)', 'Unlock premium (25 vouchers)', 'Débloquer premium (25 bons)', 'Desbloquear premium (25 vales)', 'Desbloquear premium (25 vales)', 'Premium freischalten (25 Gutscheine)', 'Premium\'u aç (25 kupon)'), 'engPassBuy()', 'st-big', p.premium) +
      `<div class="eng-prow head"><b></b><div class="eng-pc">${L('مجاني', 'Free', 'Gratuit', 'Gratis', 'Grátis', 'Gratis', 'Ücretsiz')}</div><div class="eng-pc">${L('مميز', 'Premium', 'Premium', 'Premium', 'Premium', 'Premium', 'Premium')}</div></div>${rows}<div class="st-intro">${L('مصادر الخبرة: المباريات، المهام، تسجيل الدخول، التحدي، نهاية الموسم.', 'XP from matches, tasks, login, challenge and season end.', 'XP : matchs, missions, connexion, défi, fin de saison.', 'XP por partidos, tareas, acceso, desafío y fin de temporada.', 'XP por jogos, tarefas, acesso, desafio e fim de época.', 'XP durch Spiele, Aufgaben, Login, Herausforderung und Saisonende.', 'Maçlar, görevler, giriş, meydan okuma ve sezon sonundan XP.')}</div>` + back();
  };
  window.engPassBuy = function () { const p = passSync(), s = S(); if (p.premium) return; if (s.vouchers < 25) { ffmShort('vch', L('قسائم غير كافية', 'Not enough vouchers', 'Bons insuffisants', 'Vales insuficientes', 'Vales insuficientes', 'Nicht genug Gutscheine', 'Yetersiz kupon'), L('تحتاج 25 قسيمة.', 'You need 25 vouchers.', 'Il faut 25 bons.', 'Necesitas 25 vales.', 'Precisa de 25 vales.', 'Du brauchst 25 Gutscheine.', '25 kupon gerekiyor.')); return; } s.vouchers -= 25; p.premium = true; saveGame(); refreshAll(); go('pass'); };
  window.engPassClaim = function (l, pr) {
    const p = passSync(); if (passLvl() < l) return; const arr = pr ? p.prem : p.free; if (arr.includes(l) || (pr && !p.premium)) return; arr.push(l);
    claimToast(L('جائزة المستوى ', 'Level reward ', 'Récompense niveau ', 'Recompensa de nivel ', 'Recompensa de nível ', 'Level-Belohnung ', 'Seviye ödülü ') + l, pr ? passPrem(l) : passFree(l)); go('pass');
  };

  /* ----- achievements ----- */
  V.ach = () => {
    const e = eng();
    return head('🏆 ' + L('الإنجازات', 'Achievements', 'Succès', 'Logros', 'Conquistas', 'Erfolge', 'Başarımlar')) + `<div class="eng-ach">` + ACH.map(a => {
      const v = Math.min(achGet(a), a.goal), ok = v >= a.goal, cl = e.ach[a.id + 'c'];
      return `<div class="st-row" style="--tc:${ok ? '#ffd24a' : '#35d0ff'}"><div class="st-row-h"><b>${SHIELD[Math.min(3, a.i)]} ${achName(a)}</b><span class="st-pct">${v}/${a.goal}</span></div>${pbar(v, a.goal)}<div class="st-row-h"><small>${rewStr(a.r)}</small>${cl ? '✔' : btn(L('استلام', 'Claim', 'Récupérer', 'Reclamar', 'Receber', 'Abholen', 'Al'), `engAchClaim('${a.id}')`, '', !ok)}</div></div>`;
    }).join('') + `</div>` + back();
  };
  window.engAchClaim = function (id) { const a = ACH.find(x => x.id === id), e = eng(); if (!a || achGet(a) < a.goal || e.ach[id + 'c']) return; e.ach[id + 'c'] = 1; claimToast(achName(a), a.r); go('ach'); };

  /* ----- album ----- */
  function albumSets() {
    const inv = S().inventory, seen = new Set(), uniq = inv.filter(it => { const k = it.name + '|' + it.nat + '|' + it.rating; if (seen.has(k)) return false; seen.add(k); return true; });
    const sets = [];
    ['BR', 'AR', 'FR', 'ES', 'PT', 'EN', 'DE', 'IT', 'MA', 'DZ'].forEach(c => { const n = uniq.filter(x => x.nat === c).length; sets.push({ id: 'n' + c, label: '🌍 ' + (D.COUNTRY_AR[c] ? countryLbl(c) : c), tiers: [[5, { vch: 1 }], [12, { vch: 3, shards: 3 }]], n }); });
    ['GK', 'CB', 'LB', 'RB', 'CDM', 'CM', 'CAM', 'LW', 'RW', 'ST'].forEach(p => { const n = uniq.filter(x => x.pos === p).length; sets.push({ id: 'p' + p, label: '⚽ ' + p, tiers: [[4, { tok: 300 }], [10, { vch: 2 }]], n }); });
    sets.push({ id: 'legends', label: '👑 ' + L('الأساطير', 'Legends', 'Légendes', 'Leyendas', 'Lendas', 'Legenden', 'Efsaneler'), tiers: [[5, { vch: 5 }], [15, { vch: 15, shards: 10 }]], n: uniq.filter(x => x.tier >= 6).length });
    return sets;
  }
  function countryLbl(c) { return (window.FFMStore && FFMStore.countryName) ? FFMStore.countryName(c) : c; }
  V.album = () => {
    const e = eng();
    return head('📚 ' + L('ألبوم الجمع', 'Collection album', 'Album', 'Álbum de colección', 'Álbum de coleção', 'Sammelalbum', 'Koleksiyon albümü')) + `<div class="st-intro">${L('اجمع لاعبين مختلفين من المتجر لإكمال المجموعات (المكررون لا يُحتسبون).', 'Collect different players from the store to complete sets (duplicates do not count).', 'Collectez des joueurs différents (les doublons ne comptent pas).', 'Reúne jugadores distintos de la tienda para completar conjuntos (los duplicados no cuentan).', 'Reúna jogadores diferentes da loja para completar conjuntos (duplicados não contam).', 'Sammle verschiedene Spieler aus dem Shop, um Sets zu vervollständigen (Duplikate zählen nicht).', 'Setleri tamamlamak için mağazadan farklı oyuncular topla (kopyalar sayılmaz).')}</div>` +
      albumSets().map(s => `<div class="st-row"><div class="st-row-h"><b>${s.label}</b><span class="st-pct">${s.n}</span></div>${s.tiers.map(([need, r], k) => { const key = s.id + k, ok = s.n >= need, cl = e.album.claimed.includes(key); return `<div class="st-row-h"><small>${need} ${L('بطاقات', 'cards', 'cartes', 'cartas', 'cartas', 'Karten', 'kart')} → ${rewStr(r)}</small>${cl ? '✔' : btn(L('استلام', 'Claim', 'Récupérer', 'Reclamar', 'Receber', 'Abholen', 'Al'), `engAlbum('${key}')`, '', !ok)}</div>${pbar(Math.min(s.n, need), need)}`; }).join('')}</div>`).join('') + back();
  };
  window.engAlbum = function (key) {
    const e = eng(), id = key.slice(0, -1), k = +key.slice(-1), s = albumSets().find(x => x.id === id); if (!s || e.album.claimed.includes(key) || s.n < s.tiers[k][0]) return;
    e.album.claimed.push(key); claimToast(s.label, s.tiers[k][1]); go('album');
  };

  /* ----- upgrade ----- */
  V.upg = () => {
    const pl = state.teams.team_1.players;
    return head('⬆️ ' + L('تطوير اللاعبين', 'Upgrade players', 'Améliorer les joueurs', 'Mejorar jugadores', 'Melhorar jogadores', 'Spieler verbessern', 'Oyuncuları geliştir')) + `<div class="st-intro">${L('ارفع تقييم اللاعب حتى +3 مقابل توكن وقطع 🔩 (القطع من دمج المكررين والمكافآت).', 'Raise a player up to +3 for tokens and shards 🔩 (from merging duplicates and rewards).', 'Jusqu\'à +3 contre jetons et pièces 🔩.', 'Sube a un jugador hasta +3 con fichas y fragmentos 🔩 (de fusionar duplicados y recompensas).', 'Suba um jogador até +3 com fichas e fragmentos 🔩 (de fundir duplicados e recompensas).', 'Steigere einen Spieler bis +3 mit Tokens und Splittern 🔩 (aus Duplikat-Fusion und Belohnungen).', 'Bir oyuncuyu jeton ve parçalarla 🔩 (kopya birleştirme ve ödüllerden) +3\'e kadar yükselt.')}</div><div class="pl-strip" id="eng-upg-strip">` +
      pl.map((p, i) => { const c = upgCost(p), max = (p.upg || 0) >= 3 || p.rating >= 94; return `<div class="pl-cell">${window.ffmFullCard(p)}<div class="pl-info">${max ? 'MAX' : `🪙 ${fmt(c.tok)} • 🔩 ${c.sh}`}</div><div class="pl-btns">${btn('⬆️ +1', `engUpgrade(${i})`, '', max)}</div></div>`; }).join('') + `</div>` + back();
  };

  /* ----- challenge ----- */
  V.chal = () => {
    const c = chalSync(), ch = chalToday();
    return head('🔥 ' + L('تحدي اليوم', 'Daily challenge', 'Défi du jour', 'Desafío diario', 'Desafio diário', 'Tägliche Herausforderung', 'Günlük meydan okuma')) + `<div class="st-row" style="--tc:#ff9a3d"><div class="st-row-h"><b>${ch.t()}</b><span class="st-pct">${c.tries}/3</span></div><div class="st-intro">${L('خصم أقوى (+6 تقييم). 3 محاولات يوميًا.', 'Stronger opponent (+6 rating). 3 tries a day.', 'Adversaire plus fort (+6). 3 essais par jour.', 'Rival más fuerte (+6 de valoración). 3 intentos al día.', 'Adversário mais forte (+6 de classificação). 3 tentativas por dia.', 'Stärkerer Gegner (+6 Wertung). 3 Versuche pro Tag.', 'Daha güçlü rakip (+6 puan). Günde 3 deneme.')}</div><div class="st-intro">${L('الجائزة:', 'Reward:', 'Récompense :', 'Recompensa:', 'Recompensa:', 'Belohnung:', 'Ödül:')} ${rewStr({ tok: 800, vch: 2, shards: 2, xp: 60 })}</div></div>` +
      btn(c.done ? '✔ ' + L('تم إنجاز تحدي اليوم', 'Challenge completed', 'Défi accompli', 'Desafío completado', 'Desafio concluído', 'Herausforderung abgeschlossen', 'Meydan okuma tamamlandı') : '⚽ ' + L('ابدأ التحدي', 'Start challenge', 'Commencer', 'Empezar desafío', 'Iniciar desafio', 'Herausforderung starten', 'Meydan okumayı başlat'), 'engChalPlay()', 'st-big', c.done || c.tries >= 3) + back();
  };

  /* ----- leaderboard ----- */
  V.lb = () => {
    const l = lbSync(), wk = weekNum(), fr = weekFraction(), rv = lbRivals(wk, fr);
    const all = rv.map(x => ({ n: x.name, p: x.pts })).concat([{ n: L('أنت', 'You', 'Vous', 'Tú', 'Você', 'Du', 'Sen'), p: l.pts, me: true }]).sort((a, b) => b.p - a.p);
    const myRank = all.findIndex(x => x.me) + 1, days = 7 - ((dayNum() + 3) % 7);
    let html = head('📊 ' + L('لوحة الترتيب الأسبوعية', 'Weekly leaderboard', 'Classement hebdomadaire', 'Clasificación semanal', 'Ranking semanal', 'Wochenrangliste', 'Haftalık sıralama')) + `<div class="st-intro">${L('نقاط: فوز 3، تعادل 1، كل هدف 1، جولة كأس 5. (منافسون افتراضيون بدون اتصال)', 'Points: win 3, draw 1, goal 1, cup round 5. (offline simulated rivals)', 'Points : victoire 3, nul 1, but 1, tour de coupe 5. (rivaux simulés hors ligne)', 'Puntos: victoria 3, empate 1, gol 1, ronda de copa 5. (rivales simulados sin conexión)', 'Pontos: vitória 3, empate 1, golo 1, ronda de taça 5. (adversários simulados offline)', 'Punkte: Sieg 3, Unentschieden 1, Tor 1, Pokalrunde 5. (simulierte Offline-Gegner)', 'Puanlar: galibiyet 3, beraberlik 1, gol 1, kupa turu 5. (çevrimdışı simüle rakipler)')} • ${L('ينتهي بعد', 'ends in', 'fin dans', 'termina en', 'termina em', 'endet in', 'bitiyor:')} ${days} ${L('يوم', 'd', 'j', 'd', 'd', 'T', 'g')}</div>`;
    if (l.last && !l.last.claimed) { const rk = lbRank(l.last.pts, l.last.week, 1), pz = lbPrize(rk); html += `<div class="st-row" style="--tc:#ffd24a"><div class="st-row-h"><b>${L('جائزة الأسبوع الماضي', 'Last week prize', 'Prix de la semaine dernière', 'Premio de la semana pasada', 'Prémio da semana passada', 'Preis der letzten Woche', 'Geçen haftanın ödülü')} #${rk}</b></div>${btn('🎁 ' + rewStr(pz), 'engLbClaim()', 'st-big')}</div>`; }
    html += `<div class="eng-lb">` + all.slice(0, 10).map((x, i) => `<div class="eng-lbr ${x.me ? 'me' : ''}"><b>${i + 1}</b><span>${x.n}</span><span>${x.p}</span></div>`).join('') + (myRank > 10 ? `<div class="eng-lbr me"><b>${myRank}</b><span>${L('أنت', 'You', 'Vous', 'Tú', 'Você', 'Du', 'Sen')}</span><span>${l.pts}</span></div>` : '') + `</div><div class="st-intro">${L('جوائز نهاية الأسبوع:', 'End-of-week prizes:', 'Prix de fin de semaine :', 'Premios de fin de semana:', 'Prémios de fim de semana:', 'Preise zum Wochenende:', 'Hafta sonu ödülleri:')} #1 ${rewStr(lbPrize(1))} • ≤3 ${rewStr(lbPrize(3))} • ≤10 ${rewStr(lbPrize(10))}</div>` + back();
    return html;
  };
  window.engLbClaim = function () { const l = lbSync(); if (!l.last || l.last.claimed) return; l.last.claimed = true; const rk = lbRank(l.last.pts, l.last.week, 1); claimToast(L('جائزة الترتيب', 'Ranking prize', 'Prix classement', 'Premio de clasificación', 'Prémio de ranking', 'Ranglistenpreis', 'Sıralama ödülü') + ' #' + rk, lbPrize(rk)); go('lb'); };

  /* ----- cups ----- */
  function fmtTime(ms) { const m = Math.ceil(ms / 60000); return Math.floor(m / 60) + ':' + pad(m % 60); }
  V.cup = () => {
    const e = eng();
    return head('🏆 ' + L('الكأس والبطولات', 'Cups', 'Coupes', 'Copas', 'Taças', 'Pokale', 'Kupalar')) + ['local', 'cont'].map(k => {
      const d = CUPS[k], c = e.cups[k], locked = k === 'cont' && !contUnlocked(), wait = !c.alive && now() < c.next, rn = d.rn();
      return `<div class="st-row" style="--tc:${locked ? '#555' : '#ffd24a'}"><div class="st-row-h"><b>${d.icon} ${d.name()}</b><span class="st-pct">${c.alive ? rn[c.round] : ''}</span></div>${pbar(c.alive ? c.round : 0, d.rounds)}<small>${rn.map((x, i) => `${i + 1}) ${x} → ${rewStr(d.rew[i])}`).join('<br>')}<br>🏆 ${rewStr(d.trophy)}</small>` +
        `<div style="margin-top:6px">${locked ? '🔒 ' + L('تُفتح عند الدرجة 5 فما فوق', 'Unlocks at tier 5 or higher', 'Débloqué au niveau 5 ou plus', 'Se desbloquea en la división 5 o superior', 'Desbloqueia na divisão 5 ou superior', 'Wird ab Liga 5 oder höher freigeschaltet', '5. lig veya üstünde açılır') : btn(c.alive ? '⚽ ' + L('العب الجولة', 'Play round', 'Jouer le tour', 'Jugar ronda', 'Jogar ronda', 'Runde spielen', 'Turu oyna') + ' ' + (c.round + 1) : (wait ? '⏱ ' + fmtTime(c.next - now()) : '▶ ' + L('ابدأ البطولة', 'Start cup', 'Lancer', 'Empezar copa', 'Iniciar taça', 'Pokal starten', 'Kupayı başlat')), `engCupPlay('${k}')`, 'st-big', wait)}</div></div>`;
    }).join('') + back();
  };

  /* ----- season goals ----- */
  V.goals = () => {
    const e = eng(), g = goalsSync(), ss = e.ss;
    return head('🎯 ' + L('أهداف الموسم', 'Season goals', 'Objectifs de saison', 'Objetivos de temporada', 'Objetivos da época', 'Saisonziele', 'Sezon hedefleri')) + `<div class="st-intro">${L('مباريات الموسم:', 'Season matches:', 'Matchs :', 'Partidos de la temporada:', 'Jogos da época:', 'Saisonspiele:', 'Sezon maçları:')} ${state.careerSeasonMatches || 0}/19 • ${L('الدرجة', 'Tier', 'Niveau', 'División', 'Divisão', 'Liga', 'Lig')}: ${tierName(state.currentTier)} (${state.currentTier})<br>${L('ف', 'W', 'V', 'G', 'V', 'S', 'G')} ${ss.w} ${L('ت', 'D', 'N', 'E', 'E', 'U', 'B')} ${ss.d} ${L('خ', 'L', 'D', 'P', 'D', 'N', 'M')} ${ss.l} • ${L('أهداف', 'Goals', 'Buts', 'Goles', 'Golos', 'Tore', 'Goller')} ${ss.gf}-${ss.ga} • CS ${ss.cs}</div>` +
      g.list.map(id => { const d = GOAL_POOL.find(x => x.id === id), pr = d.prog ? d.prog(ss) : null; return `<div class="st-row"><div class="st-row-h"><b>🎯 ${d.t()}</b><span class="st-pct">${pr ? pr[0] + '/' + pr[1] : ''}</span></div>${pr ? pbar(pr[0], pr[1]) : ''}<small>${L('تُقيَّم نهاية الموسم → ', 'Evaluated at season end → ', 'Évalué en fin de saison → ', 'Se evalúa al final de la temporada → ', 'Avaliado no fim da época → ', 'Wird am Saisonende ausgewertet → ', 'Sezon sonunda değerlendirilir → ')}${rewStr({ tok: 500, vch: 1 })}</small></div>`; }).join('') +
      `<div class="st-intro">${L('الصعود: أول 3 • الهبوط: آخر 3 (المراكز 18-20) • البطل يحصل على مكافأة إضافية.', 'Promotion: top 3 • Relegation: bottom 3 (18th-20th) • The champion gets a bonus.', 'Promotion : top 3 • Relégation : 3 derniers • bonus pour le champion.', 'Ascenso: los 3 primeros • Descenso: los 3 últimos (18.º-20.º) • El campeón recibe un bonus.', 'Subida: top 3 • Descida: últimos 3 (18.º-20.º) • O campeão recebe um bónus.', 'Aufstieg: Top 3 • Abstieg: letzte 3 (18.–20.) • Der Meister erhält einen Bonus.', 'Yükselme: ilk 3 • Düşme: son 3 (18.-20.) • Şampiyon bonus kazanır.')}</div>` + back();
  };

  /* ----- tactics & difficulty ----- */
  V.tact = () => {
    const s = eng().set, forms = ['4-3-3', '4-4-2', '3-5-2', '4-2-3-1', '5-3-2'];
    return head('⚙️ ' + L('التكتيك والصعوبة', 'Tactics & difficulty', 'Tactique et difficulté', 'Táctica y dificultad', 'Tática e dificuldade', 'Taktik & Schwierigkeit', 'Taktik ve zorluk')) +
      `<h3>${L('مستوى الصعوبة', 'Difficulty', 'Difficulté', 'Dificultad', 'Dificuldade', 'Schwierigkeit', 'Zorluk')}</h3><div class="eng-opts">` + Object.keys(DIFF).map(k => `<button class="godot-btn ${s.diff === k ? 'sel' : ''}" onclick="engSet('diff','${k}')">${diffName(k)}<br><small>×${DIFF[k].m} ${L('مكافآت', 'rewards', 'gains', 'recompensas', 'recompensas', 'Belohnungen', 'ödüller')}</small></button>`).join('') + `</div>` +
      `<h3>${L('الخطة', 'Formation', 'Schéma', 'Formación', 'Formação', 'Formation', 'Diziliş')}</h3><div class="eng-opts">` + forms.map(k => `<button class="godot-btn ${s.form === k ? 'sel' : ''}" onclick="engSet('form','${k}')">${k}</button>`).join('') + `</div>` +
      `<h3>${L('أسلوب الضغط', 'Pressing', 'Pressing', 'Presión', 'Pressão', 'Pressing', 'Pres')}</h3><div class="eng-opts">` + [['low', L('منخفض', 'Low', 'Bas', 'Baja', 'Baixa', 'Niedrig', 'Düşük')], ['normal', L('متوازن', 'Balanced', 'Équilibré', 'Equilibrada', 'Equilibrada', 'Ausgewogen', 'Dengeli')], ['high', L('عالٍ', 'High', 'Haut', 'Alta', 'Alta', 'Hoch', 'Yüksek')]].map(([k, n]) => `<button class="godot-btn ${s.press === k ? 'sel' : ''}" onclick="engSet('press','${k}')">${n}</button>`).join('') + `</div>` +
      `<div class="st-intro">${L('تؤثر الخطة والضغط على مواقع لاعبيك في المباراة الحية، وتؤثر الصعوبة على قوة الخصم ومكافآت المسار المهني.', 'Formation and pressing change your players\' positions in the live match; difficulty changes the opponent and career rewards.', 'Le schéma et le pressing modifient vos positions en match ; la difficulté change l\'adversaire et les gains.', 'La formación y la presión cambian la posición de tus jugadores en el partido en directo; la dificultad cambia al rival y las recompensas de carrera.', 'A formação e a pressão mudam a posição dos seus jogadores no jogo ao vivo; a dificuldade muda o adversário e as recompensas de carreira.', 'Formation und Pressing ändern die Positionen deiner Spieler im Live-Spiel; die Schwierigkeit ändert den Gegner und die Karrierebelohnungen.', 'Diziliş ve pres, canlı maçta oyuncularının konumunu değiştirir; zorluk rakibi ve kariyer ödüllerini değiştirir.')}</div>` + back();
  };
  window.engSet = function (k, v) { eng().set[k] = v; saveGame(); go('tact'); };

  /* ----- bell ----- */
  V.bell = () => {
    const n = notifs(), e = eng();
    return head('🔔 ' + L('الإشعارات', 'Notifications', 'Notifications', 'Notificaciones', 'Notificações', 'Benachrichtigungen', 'Bildirimler')) + (n.length ? n.map(x => `<button class="godot-btn st-sec" onclick="FFMEng.open('${x.v}')"><span class="st-sec-ic">${x.i}</span><span class="st-sec-tx"><b>${x.t}</b></span></button>`).join('') : `<div class="st-intro">${L('لا شيء الآن.', 'Nothing right now.', 'Rien pour le moment.', 'Nada por ahora.', 'Nada por agora.', 'Im Moment nichts.', 'Şu an bir şey yok.')}</div>`) +
      ('Notification' in window ? btn(e.notif.sys ? '🔕 ' + L('إيقاف إشعارات النظام', 'Disable system notifications', 'Désactiver', 'Desactivar notificaciones del sistema', 'Desativar notificações do sistema', 'Systembenachrichtigungen deaktivieren', 'Sistem bildirimlerini kapat') : '🔔 ' + L('تفعيل إشعارات النظام', 'Enable system notifications', 'Activer', 'Activar notificaciones del sistema', 'Ativar notificações do sistema', 'Systembenachrichtigungen aktivieren', 'Sistem bildirimlerini aç'), 'engSysNotif()', '') : '') + back();
  };
  window.engSysNotif = function () {
    const e = eng();
    if (e.notif.sys) { e.notif.sys = false; saveGame(); go('bell'); return; }
    if (!('Notification' in window)) return;
    Notification.requestPermission().then(p => { e.notif.sys = p === 'granted'; saveGame(); go('bell'); });
  };

  /* ---------- navigation ---------- */
  function go(v) {
    if (v === 'menu') { view = 'menu'; showScreen('screen-main-menu'); updateBadges(); window.scrollTo(0, 0); return; }
    view = v; registerLogin();
    if (!V[v]) v = view = 'hub';
    const body = $('eng-body'); body.innerHTML = V[v]();
    showScreen('screen-eng'); refreshAll(); window.scrollTo(0, 0);
  }
  function open(v) {
    if (v === 'store') return openStore();
    if (v === 'contracts') return openPlayerContracts();
    go(v);
  }
  setInterval(() => {
    const t = document.getElementById('eng-free-t'); if (t) t.textContent = fmtTime(Math.max(0, +t.dataset.t - now()));
    if (view === 'free' && $('screen-eng').classList.contains('active')) { const f = eng().free, before = f.n; acc(); if (f.n !== before) go('free'); }
  }, 1000);
  setInterval(() => { updateBadges(); sysNotify(); }, 30000);

  function renderMenu() {
    const set = (id, h) => { const e = $(id); if (e) { const bd = e.querySelector('.eng-badge'); e.innerHTML = h; if (bd) e.appendChild(bd); } };
    { const cd = document.querySelector('#screen-main-menu [data-key="career_desc"]'); if (cd) cd.textContent = L('ابدأ من الدرجة 8 وتسلّق إلى القمة', 'Start in Tier 8 and climb to the top', 'Partez du niveau 8 et visez le sommet', 'Empieza en la División 8 y llega a lo más alto', 'Comece na Divisão 8 e chegue ao topo', 'Starte in Liga 8 und steige bis an die Spitze auf', '8. Ligde başla ve zirveye ulaş'); }
    set('mm-sub', L('كرة القدم • مدير الفريق', 'FOOTBALL MANAGER', 'MANAGER DE FOOT', 'MÁNAGER DE FÚTBOL', 'MANAGER DE FUTEBOL', 'FUSSBALL-MANAGER', 'FUTBOL MENAJERİ'));
    set('mm-hint1', '◂ ' + L('اسحب لرؤية الأحداث', 'swipe for events', 'glisser : événements', 'desliza para ver eventos', 'deslize para ver eventos', 'wischen für Events', 'etkinlikler için kaydır') + ' ◂');
    set('mm-hint2', '▸ ' + L('اسحب للرجوع للمسار المهني', 'swipe back to career', 'glisser : carrière', 'desliza para volver a la carrera', 'deslize para voltar à carreira', 'wischen zurück zur Karriere', 'kariyere dönmek için kaydır') + ' ▸');
    set('mm-ev-chal', '🔥 ' + L('تحدي اليوم', 'Daily challenge', 'Défi du jour', 'Desafío diario', 'Desafio diário', 'Tägliche Herausforderung', 'Günlük meydan okuma'));
    set('mm-ev-offer', '⏱ ' + L('عروض المتجر المحدودة', 'Limited store offers', 'Offres limitées', 'Ofertas limitadas de la tienda', 'Ofertas limitadas da loja', 'Zeitlich begrenzte Shop-Angebote', 'Sınırlı mağaza teklifleri'));
    [['mm-n-rew', '🎁', 'المكافآت', 'Rewards', 'Récomp.', 'Premios', 'Prêmios', 'Prämien', 'Ödüller'], ['mm-n-sea', '🏅', 'الموسم', 'Season', 'Saison', 'Temporada', 'Época', 'Saison', 'Sezon'], ['mm-n-cmp', '🏆', 'منافسات', 'Compete', 'Compét.', 'Competir', 'Competir', 'Wettkampf', 'Yarış'], ['mm-n-col', '📚', 'المجموعة', 'Collection', 'Collec.', 'Colección', 'Coleção', 'Sammlung', 'Koleksiyon'], ['mm-n-tac', '⚙️', 'التكتيك', 'Tactics', 'Tactique', 'Táctica', 'Tática', 'Taktik', 'Taktik']]
      .forEach(a => set(a[0], `<span class="mm-ni">${a[1]}</span><small>${L(a[2], a[3], a[4], a[5], a[6], a[7], a[8])}</small>`));
  }
  (function menuDrag() {
    const car = $('mm-car'); if (!car) return;
    const dots = document.querySelectorAll('#mm-dots i');
    const upd = () => { const i = Math.round(Math.abs(car.scrollLeft) / Math.max(1, car.clientWidth)); dots.forEach((d, k) => d.classList.toggle('on', k === i)); };
    car.addEventListener('scroll', upd, { passive: true });
    let down = false, sx = 0, sl = 0, moved = false;
    car.addEventListener('pointerdown', (e) => { if (e.pointerType !== 'mouse') return; down = true; moved = false; sx = e.clientX; sl = car.scrollLeft; car.style.scrollSnapType = 'none'; });
    window.addEventListener('pointermove', (e) => { if (!down) return; const dx = e.clientX - sx; if (Math.abs(dx) > 5) moved = true; car.scrollLeft = sl - dx; });
    window.addEventListener('pointerup', () => { if (!down) return; down = false; const w = car.clientWidth, i = Math.round(Math.abs(car.scrollLeft) / w); const sg = car.scrollLeft < 0 ? -1 : 1; car.style.scrollSnapType = ''; car.scrollTo({ left: sg * i * w, behavior: 'smooth' }); });
    car.addEventListener('click', (e) => { if (moved) { e.stopPropagation(); e.preventDefault(); moved = false; } }, true);
  })();

  function init() {
    renderMenu();
    try { if (window.FFMStore && FFMStore.store) FFMStore.store(); } catch (e) {}
    ensureCareer();
    try { if (state.dbVer !== 4 && window.FFMStoreData && FFMStoreData.buildTeam) { for (let i = 2; i <= 160; i++) { const id = 'team_' + i; const ps = FFMStoreData.buildTeam(i); if (state.teams[id]) state.teams[id].players = ps; else state.teams[id] = { id, name: id, players: ps }; } state.dbVer = 4; } } catch (e) { console.error(e); }
    registerLogin(); passSync(); tasksSync(); acc(); chalSync(); lbSync(); goalsSync(); checkAch(); dailyState();
    const e = eng(); if (!e.started) { e.started = now(); }
    saveGame(); updateBadges();
    setTimeout(() => { const n = readyCount(); if (n > 0 && !document.querySelector('.st-modal[style*="flex"]')) toast('🎁 ' + L('لديك ' + n + ' مكافآت جاهزة', n + ' rewards are ready', n + ' récompenses prêtes', n + ' recompensas listas', n + ' recompensas prontas', n + ' Belohnungen bereit', n + ' ödül hazır'), L('افتح مركز المكافآت', 'Open the Rewards Hub', 'Ouvrez le centre de récompenses', 'Abre el centro de recompensas', 'Abra o centro de recompensas', 'Öffne das Belohnungszentrum', 'Ödül Merkezi\'ni aç')); }, 2500);
  }

  /* ---------- hooks into the existing game ---------- */
  const _ecm = window.enterCareerMode;
  window.enterCareerMode = function () {
    _ecm.apply(this, arguments);
    const d = $('career-tier-display'); if (d) d.innerText = state.currentTier + ' — ' + tierName(state.currentTier) + ' (' + L('من', 'of', 'sur', 'de', 'de', 'von', '/') + ' ' + CAREER_TIERS + ')';
  };
  const _al = window.applyLanguage;
  window.applyLanguage = function (l) { _al(l); renderMenu(); updateBadges(); const h = $('hub-open-btn'); if (h) { h.firstChild.textContent = '🎁 ' + L('مركز المكافآت', 'Rewards Hub', 'Centre de récompenses', 'Centro de recompensas', 'Centro de recompensas', 'Belohnungszentrum', 'Ödül Merkezi') + ' '; } if ($('screen-eng') && $('screen-eng').classList.contains('active')) go(view); };

  const cont = $('game-container');
  const sc = document.createElement('div'); sc.id = 'screen-eng'; sc.className = 'screen store-screen'; sc.innerHTML = '<div id="eng-body"></div>'; cont.appendChild(sc);
  window.FFMEng = {
    go, open, init, event, give, now, eng, notifs, ACH, DAILY, MONTH, passPrem, passFree, tierName, tierIds, CAREER_TIERS, seasonEnd, onMatch, CUPS, GOAL_POOL, WHEEL, readyCount, dailyState, lbRank, lbRivals, tasksSync, DAILY_POOL, WEEKLY_POOL, upgCost, xpPlayers, albumSets
  };
})();
