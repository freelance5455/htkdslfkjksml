/* economy.js — Phase 4: factories, equipment production, resources, budget, construction, tax, trade, shortages. */
(function (G) {
  'use strict';

  /* ---------- data ---------- */
  G.TAX = {
    low:    { name: 'Low',    income: 0.8,  consumer: 0.10, desc: 'Income ×0.8 · more factory output' },
    normal: { name: 'Normal', income: 1.0,  consumer: 0.15, desc: 'Income ×1.0' },
    high:   { name: 'High',   income: 1.25, consumer: 0.25, desc: 'Income ×1.25 · less factory output' }
  };
  G.RES_NAMES = { steel: 'Steel', coal: 'Coal', oil: 'Oil', rubber: 'Rubber', food: 'Food' };
  G.RES_ICONS = { steel: '⚙️', coal: '⛏️', oil: '🛢️', rubber: '🛞', food: '🌾' };
  G.PRICE = { steel: 4, coal: 2.5, oil: 6, rubber: 8, food: 1.6 };
  G.RECIPES = {
    rifles:   { name: 'Rifles',         out: 40,  need: { steel: 1.0, coal: 0.5 } },
    guns:     { name: 'Artillery guns', out: 2,   need: { steel: 2.0, coal: 1.0 } },
    vehicles: { name: 'Vehicles',       out: 1.5, need: { steel: 2.0, oil: 1.0, rubber: 1.0 } }
  };
  G.LINES = ['rifles', 'guns', 'vehicles'];
  G.BUILD = {
    civ:   { name: 'Civilian Factory', icon: '🏭', slot: true },
    mil:   { name: 'Military Factory', icon: '🔧', slot: true },
    dock:  { name: 'Shipyard',         icon: '⚓', slot: true, coastal: true },
    infra: { name: 'Infrastructure',   icon: '🛣', max: 5 },
    rail:  { name: 'Railway',          icon: '🚆', max: 3 },
    port:  { name: 'Port',             icon: '🏗', max: 3, coastal: true },
    farm:  { name: 'Farm Estates',     icon: '🌾', max: 3 }
  };
  const UPKEEP = { civ: 0.3, mil: 0.5, dock: 0.3 };       // gold/day per building
  const ARMY_UPKEEP = 0.01;                              // gold/day per recruitment gold of each unit
  const POINTS_PER_CIV = 3, MAX_POINTS_PER_PROJECT = 20, QUEUE_MAX = 12;

  G.pb = function (id) { return G.state.pb[id]; };

  /* ---------- init ---------- */
  G.initEconomy = function (st, fresh) {
    const rand = G.rng(4242);
    if (!st.pb) {
      st.pb = G.provinces.map(p => {
        if (p.sea) return null;
        const big = p.pop > 80000, mid = p.pop > 45000;
        const b = {
          civ: p.capital ? 3 : (big ? 2 : (mid ? 1 : 0)) + (rand() < 0.2 ? 1 : 0),
          mil: p.capital ? 2 : (p.pop > 90000 ? 1 : 0) + (rand() < 0.15 ? 1 : 0),
          dock: p.coastal && p.pop > 70000 ? 1 : 0,
          port: p.coastal ? 1 : 0,
          rail: p.capital ? 2 : (p.pop > 70000 ? 1 : 0),
          farm: 0,
          infra: p.infra
        };
        return b;
      });
    }
    st.pb.forEach(b => { if (b && b.farm == null) b.farm = 0; });
    if (fresh) for (const id in G.COUNTRIES) {          // every nation with a coast starts with at least one shipyard
      const ports = G.provinces.filter(p => !p.sea && st.owners[p.id] === id && p.seaZones && p.seaZones.length);
      if (ports.length && !ports.some(p => st.pb[p.id].dock)) { ports.sort((a, b) => (b.capital ? 1e6 : 0) + b.pop - ((a.capital ? 1e6 : 0) + a.pop)); st.pb[ports[0].id].dock = 1; st.pb[ports[0].id].port = Math.max(1, st.pb[ports[0].id].port); }
    }
    st.alloc = st.alloc || {}; st.construct = st.construct || []; st.tax = st.tax || {}; st.tradeUsed = st.tradeUsed || {};
    st.nextBid = st.nextBid || 1;
    for (const id in st.countries) {
      const c = st.countries[id];
      G.RESOURCES.forEach(r => { if (typeof c.res[r] !== 'number') c.res[r] = r === 'rubber' ? 25 : 0; });
      if (!c.dRes) c.dRes = {}; G.RESOURCES.forEach(r => { if (typeof c.dRes[r] !== 'number') c.dRes[r] = 0; });
      if (!st.tax[id]) st.tax[id] = 'normal';
      if (st.tradeUsed[id] == null) st.tradeUsed[id] = 0;
      if (!st.alloc[id]) st.alloc[id] = { rifles: 0, guns: 0, vehicles: 0 };
    }
    G.provinces.forEach((p, i) => { if (st.pb[i]) p.infra = st.pb[i].infra; });
    if (fresh) for (const id in st.countries) G.autoAlloc(id);
    G.recompute();
  };

  /* ---------- totals ---------- */
  G.totals = function (id) {
    const st = G.state, t = { civ: 0, mil: 0, dock: 0, port: 0, rail: 0, pop: 0, provs: 0 };
    G.provinces.forEach((p, i) => {
      if (p.sea || st.owners[i] !== id) return;
      const b = st.pb[i]; t.civ += b.civ; t.mil += b.mil; t.dock += b.dock; t.port += b.port; t.rail += b.rail; t.pop += p.pop; t.provs++;
    });
    return t;
  };
  G.slotsOf = function (prov) {
    const p = G.provinces[prov];
    return Math.min(8, 3 + Math.floor(p.pop / 60000) + (p.capital ? 2 : 0));
  };
  G.slotsUsed = function (prov) {
    const b = G.state.pb[prov];
    const q = G.state.construct.filter(x => x.prov === prov && G.BUILD[x.type].slot).length;
    return b.civ + b.mil + b.dock + q;
  };
  G.consumerShare = function (id) { return G.TAX[G.state.tax[id]].consumer; };
  G.civEfficiency = function (id) { return G.totals(id).civ * (1 - G.consumerShare(id)); };
  G.constructionPoints = function (id) { return G.civEfficiency(id) * POINTS_PER_CIV * G.techMult(id, 'construction'); };

  /* ---------- production lines ---------- */
  G.allocTotal = function (id) { const a = G.state.alloc[id]; return a.rifles + a.guns + a.vehicles; };
  G.autoAlloc = function (id) {
    const n = G.totals(id).mil, a = G.state.alloc[id];
    a.rifles = Math.round(n * 0.5); a.guns = Math.round(n * 0.25); a.vehicles = Math.max(0, n - a.rifles - a.guns);
  };
  G.setAlloc = function (id, line, delta) {
    const a = G.state.alloc[id], mil = G.totals(id).mil;
    const v = a[line] + delta;
    if (v < 0) return false;
    if (delta > 0 && G.allocTotal(id) + delta > mil) return false;
    a[line] = v; return true;
  };
  function clampAlloc(id) {
    const a = G.state.alloc[id], mil = G.totals(id).mil;
    let over = G.allocTotal(id) - mil;
    for (const l of ['vehicles', 'guns', 'rifles']) { while (over > 0 && a[l] > 0) { a[l]--; over--; } }
  }

  /* ---------- construction ---------- */
  G.buildCost = function (type, prov) {
    const b = G.state.pb[prov];
    switch (type) {
      case 'civ': return { points: 600, gold: 120 };
      case 'mil': return { points: 700, gold: 160 };
      case 'dock': return { points: 800, gold: 180 };
      case 'infra': return { points: 350 * b.infra, gold: 70 * b.infra };
      case 'rail': return { points: 300 * (b.rail + 1), gold: 90 * (b.rail + 1) };
      case 'farm': return { points: 220 * (b.farm + 1), gold: 80 * (b.farm + 1) };
      case 'port': return { points: 450 * (b.port + 1), gold: 130 * (b.port + 1) };
    }
  };
  G.canBuild = function (owner, type, prov) {
    const st = G.state, def = G.BUILD[type], p = G.provinces[prov];
    if (!def) return { ok: false, msg: 'Unknown building' };
    if (p.sea || st.owners[prov] !== owner) return { ok: false, msg: 'Not your province' };
    if (st.construct.filter(x => x.owner === owner).length >= QUEUE_MAX) return { ok: false, msg: 'Construction queue is full' };
    if (def.coastal && !p.coastal) return { ok: false, msg: 'Needs a coastal province' };
    const b = st.pb[prov];
    if (def.slot) { if (G.slotsUsed(prov) >= G.slotsOf(prov)) return { ok: false, msg: 'No free building slots' }; }
    else {
      const lvl = type === 'infra' ? b.infra : b[type];
      if (lvl >= def.max) return { ok: false, msg: 'Already at maximum level' };
      if (st.construct.some(x => x.prov === prov && x.type === type)) return { ok: false, msg: 'Already under construction' };
    }
    if (G.battleAt(prov)) return { ok: false, msg: 'Battle in progress' };
    const cost = G.buildCost(type, prov);
    if (st.countries[owner].treasury < cost.gold) return { ok: false, msg: 'Not enough gold' };
    return { ok: true, cost: cost };
  };
  G.startBuild = function (owner, type, prov) {
    const chk = G.canBuild(owner, type, prov); if (!chk.ok) return chk;
    const st = G.state;
    st.countries[owner].treasury -= chk.cost.gold;
    st.construct.push({ id: st.nextBid++, owner: owner, prov: prov, type: type, left: chk.cost.points, total: chk.cost.points, gold: chk.cost.gold });
    return { ok: true };
  };
  G.cancelBuild = function (owner, bid) {
    const st = G.state, i = st.construct.findIndex(x => x.id === bid && x.owner === owner);
    if (i < 0) return false;
    st.countries[owner].treasury += st.construct[i].gold; st.construct.splice(i, 1); return true;
  };
  function completeBuild(it) {
    const st = G.state, b = st.pb[it.prov], p = G.provinces[it.prov];
    if (it.type === 'infra') { b.infra++; p.infra = b.infra; } else b[it.type]++;
    if (it.owner === st.player) { G.logMsg(G.BUILD[it.type].name + ' completed at ' + p.name); G.onBuilt && G.onBuilt(it); }
  }
  G.refundBuildsIn = function (prov) {
    const st = G.state;
    st.construct = st.construct.filter(x => { if (x.prov !== prov) return true; st.countries[x.owner].treasury += x.gold; return false; });
  };

  /* ---------- market ---------- */
  G.marketFactor = function () { return 1 + 0.12 * Math.sin(G.state.day / 45); };
  G.buyPrice = function (r) { return Math.round(G.PRICE[r] * 1.3 * G.marketFactor() * 100) / 100; };
  G.sellPrice = function (r) { return Math.round(G.PRICE[r] * 0.7 * G.marketFactor() * 100) / 100; };
  G.tradeCap = function (id) { const t = G.totals(id); return Math.round((200 + 60 * t.port + 40 * t.dock + (G.tradePartners ? G.TRADE_CAP_BONUS * G.tradePartners(id) : 0)) * G.techMult(id, 'trade') * (1 - 0.85 * (G.blockadeShare ? G.blockadeShare(id) : 0))); };
  G.tradeLeft = function (id) { return Math.max(0, G.tradeCap(id) - G.state.tradeUsed[id]); };
  G.trade = function (id, r, qty) {
    const st = G.state, c = st.countries[id], n = Math.abs(qty);
    if (!n) return { ok: false, msg: 'Nothing to trade' };
    if (n > G.tradeLeft(id)) return { ok: false, msg: 'Monthly trade capacity used up (build ports and shipyards)' };
    if (qty > 0) {
      const cost = G.buyPrice(r) * n;
      if (c.treasury < cost) return { ok: false, msg: 'Not enough gold' };
      c.treasury -= cost; c.res[r] += n;
    } else {
      if (c.res[r] < n) return { ok: false, msg: 'Not enough ' + G.RES_NAMES[r].toLowerCase() };
      c.res[r] -= n; c.treasury += G.sellPrice(r) * n;
    }
    st.tradeUsed[id] += n;
    return { ok: true };
  };

  /* ---------- budget ---------- */
  function budget(id, t, armyUpkeep) {
    const st = G.state, c = st.countries[id];
    c.taxBase = 0;
    G.provinces.forEach((p, i) => { if (!p.sea && st.owners[i] === id) c.taxBase += p.income * 0.5 * (1 - 0.45 * (G.blockadeLevel ? G.blockadeLevel(i) * (1 - Math.min(0.8, G.techEff(id, 'convoy'))) : 0)); });
    c.income = c.taxBase * G.TAX[st.tax[id]].income * G.techMult(id, 'tax');
    c.expArmy = armyUpkeep;
    c.expInd = t.civ * UPKEEP.civ + t.mil * UPKEEP.mil + t.dock * UPKEEP.dock;
    c.expTrade = G.tradePartners ? G.TRADE_GOLD_BONUS * G.tradePartners(id) : 0;
    c.dIncome = c.income + c.expTrade - c.expArmy - c.expInd;
  }
  // Recompute budgets without advancing time (after conquest, loading, policy changes).
  G.refreshBudget = function () {
    const st = G.state; if (!st.pb || !st.tax) return;
    const upkeep = {};
    for (const a of st.armies) for (const u of a.units) upkeep[a.owner] = (upkeep[a.owner] || 0) + G.UNITS[u.type].gold * ARMY_UPKEEP;
    G.navalCensus && G.navalCensus({}, upkeep);
    for (const id in st.countries) if (!st.countries[id].dead) budget(id, G.totals(id), upkeep[id] || 0);
  };

  /* ---------- daily tick ---------- */
  G.economyDay = function () {
    const st = G.state;
    // army census (men and upkeep) per country
    const men = {}, upkeep = {};
    for (const a of st.armies) {
      for (const u of a.units) { men[a.owner] = (men[a.owner] || 0) + u.men; upkeep[a.owner] = (upkeep[a.owner] || 0) + G.UNITS[u.type].gold * ARMY_UPKEEP; }
    }
    G.navalCensus && G.navalCensus(men, upkeep);
    for (const id in st.countries) {
      const c = st.countries[id]; if (c.dead) continue;
      const t = G.totals(id);
      c.tot = t;
      c.broke = false;
      if (c.treasury < 0) { c.treasury = 0; c.broke = true; }
      clampAlloc(id);

      // construction: civilian factories feed projects in queue order
      let pool = G.constructionPoints(id);
      c.constrUsed = 0;
      for (const it of st.construct.filter(x => x.owner === id)) {
        if (pool <= 0) break;
        const spend = Math.min(pool, MAX_POINTS_PER_PROJECT, it.left);
        it.left -= spend; pool -= spend; c.constrUsed += spend;
        if (it.left <= 0.001) { completeBuild(it); st.construct.splice(st.construct.indexOf(it), 1); }
      }

      // equipment production: shortages of any input scale the whole line down
      c.lineEff = {}; c.consume = {}; c.produce = {};
      G.LINES.forEach(l => {
        const n = st.alloc[id][l], rc = G.RECIPES[l];
        if (!n) { c.lineEff[l] = 1; return; }
        let eff = 1;
        for (const r in rc.need) { const want = n * rc.need[r]; if (want > 0) eff = Math.min(eff, c.res[r] / want); }
        eff = Math.max(0, Math.min(1, eff));
        c.lineEff[l] = eff;
        for (const r in rc.need) { const used = n * rc.need[r] * eff; c.res[r] -= used; c.consume[r] = (c.consume[r] || 0) + used; }
        const made = n * rc.out * eff * G.techMult(id, 'industry'); c.equip[l] += made; c.produce[l] = made;
      });

      // population and army eat
      const food = t.pop / 80000 + (men[id] || 0) / 8000;
      c.consume.food = (c.consume.food || 0) + Math.min(food, c.res.food + c.dRes.food);
      c.foodNeed = food;
      c.res.food -= food;
      c.starving = false;
      if (c.res.food < 0) { c.res.food = 0; c.starving = true; }

      budget(id, t, upkeep[id] || 0);
    }
    // shortage effects on morale
    for (const a of st.armies) {
      const c = st.countries[a.owner];
      if (c.starving || c.broke) a.units.forEach(u => { u.morale = Math.max(0, u.morale - 0.3); });
    }
    // basic autopilot for non-player nations
    for (const id in st.countries) {
      if (id === st.player || st.countries[id].dead) continue;
      if (st.day % 10 === 0 && !G.economyAI) G.autoAlloc(id);
      if (st.day % 15 === 3) aiEconomy(id);
    }
  };

  function aiEconomy(id) {
    const st = G.state, c = st.countries[id], t = G.totals(id);
    if ((c.starving || c.res.food < 40) && c.treasury > 80) G.trade(id, 'food', 60);
    if (c.res.steel < 25 && c.treasury > 120) G.trade(id, 'steel', 30);
    if (c.res.rubber < 10 && c.treasury > 150) G.trade(id, 'rubber', 20);
    if (c.res.oil < 10 && c.treasury > 150) G.trade(id, 'oil', 20);
    if (st.construct.filter(x => x.owner === id).length >= 2 || c.treasury < 300) return;
    if (c.dRes.food - c.foodNeed < 0.5 && c.treasury > 200) {          // food deficit: build farms first
      let fp = null;
      G.provinces.forEach(p => {
        if (p.sea || st.owners[p.id] !== id || st.pb[p.id].farm >= 3 || st.construct.some(x => x.prov === p.id && x.type === 'farm')) return;
        if (!fp || p.res.food + 2 * st.pb[p.id].farm > fp.res.food + 2 * st.pb[fp.id].farm) fp = p;
      });
      if (fp && G.startBuild(id, 'farm', fp.id).ok) return;
    }
    const type = t.civ <= t.mil * 2 ? 'civ' : 'mil';
    let best = null;
    G.provinces.forEach(p => {
      if (p.sea || st.owners[p.id] !== id) return;
      if (G.slotsOf(p.id) - G.slotsUsed(p.id) <= 0) return;
      if (!best || p.pop > best.pop) best = p;
    });
    if (best) G.startBuild(id, type, best.id);
  }

  G.economyMonth = function () {
    const st = G.state;
    for (const id in st.countries) {
      st.tradeUsed[id] = 0;
      st.countries[id].equip.horses += (st.countries[id].provCount || 0) * 6;   // horses breed on farmland
    }
  };
})(window.EMP = window.EMP || {});
