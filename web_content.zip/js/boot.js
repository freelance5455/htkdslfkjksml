/* =============================================================
   LAMPION POS · js/boot.js
   Pengganti bootstrap_database() + lpos-install.sh
   -------------------------------------------------------------
   1. Buka IndexedDB (Dexie)
   2. Bila tabel belum dibangun -> jalankan seed data awal
   3. Bila belum ada user sama sekali -> tampilkan form pembuatan
      akun Admin pertama (padanan create_user_account()).
      TIDAK ada kredensial default yang sama di semua instalasi.
   ============================================================= */
(function (global) {
  'use strict';

  var DB = global.LPDB;
  var db = DB.db;
  var PHP = global.LPHP;

  /**
   * Pastikan database siap dipakai.
   * @param {boolean} force true = hapus semua tabel lalu rebuild
   * @returns {Promise<{built:boolean, users:number}>}
   */
  function bootstrap(force) {
    return db.open().then(function () {
      if (force) {
        return DB.wipeTables()
          .then(function () { return global.LPSEED.runSeed(); })
          .then(function () { return DB.userCount(); })
          .then(function (n) { return { built: true, users: n }; });
      }
      return DB.isBuilt().then(function (built) {
        if (built) {
          return DB.userCount().then(function (n) {
            return { built: false, users: n };
          });
        }
        return global.LPSEED.runSeed()
          .then(function () { return DB.userCount(); })
          .then(function (n) { return { built: true, users: n }; });
      });
    });
  }

  /**
   * Buat akun pengguna (padanan create_user_account()).
   * @returns {Promise<{created:boolean, id:number}>}
   */
  function createUser(opts) {
    var username = String(opts.username || '').trim();
    var password = String(opts.password || '');
    var name = String(opts.name || '').trim();
    var roleName = String(opts.role_name || 'Admin');
    var replace = !!opts.replace;

    if (username === '' || password === '') {
      return Promise.reject(new Error('Username dan password wajib diisi.'));
    }
    if (password.length < 4) {
      return Promise.reject(new Error('Password minimal 4 karakter.'));
    }

    return db.roles.where('name').equals(roleName).first().then(function (role) {
      if (!role) {
        throw new Error('Role tidak ditemukan: ' + roleName);
      }
      var roleId = Number(role.id);

      return db.users.where('username').equals(username).first().then(function (existing) {
        return global.LPAUTH.makeStoredHash(password).then(function (hash) {
          if (existing) {
            if (!replace) {
              throw new Error('Username sudah dipakai: ' + username);
            }
            return db.users.update(Number(existing.id), {
              password: hash, name: name, role_id: roleId, is_active: 1
            }).then(function () { return Number(existing.id); });
          }
          return db.users.add({
            username: username,
            password: hash,
            name: name,
            role_id: roleId,
            is_active: 1,
            created_at: DB.now()
          });
        });
      });
    }).then(function (id) {
      return PHP.logActivity('user_create', username, { role: roleName })
        .then(function () { return { created: true, id: id }; });
    });
  }


  /* =============================================================
     Gerbang halaman: wajib login + permission
     ============================================================= */

  /**
   * Lindungi halaman HTML (padanan require_permission()).
   * Kalau tidak berhak -> redirect ke landing page yang sesuai.
   * @param {string|null} perm permission yang dibutuhkan
   */
  function guardPage(perm) {
    return global.LPAUTH.authContext().then(function (c) {
      if (!c.user) {
        global.location.replace('login.html');
        return null;
      }
      /* padanan session_touch() */
      if (!global.LPAUTH.sessionTouch()) {
        global.location.replace('login.html');
        return null;
      }
      if (perm && !global.LPAUTH.can(perm)) {
        global.location.replace(global.LPAUTH.landingPage());
        return null;
      }
      return c;
    });
  }

  /** Isi elemen topbar/sidebar dengan data user + permission */
  function paintUserChrome(ctx) {
    var u = ctx.user;
    document.querySelectorAll('[data-user-name]').forEach(function (el) {
      el.textContent = u.name;
    });
    document.querySelectorAll('[data-user-role]').forEach(function (el) {
      el.textContent = u.role_name;
    });
    document.querySelectorAll('[data-user-initial]').forEach(function (el) {
      el.textContent = String(u.name || '?').trim().charAt(0).toUpperCase();
    });
    /* sembunyikan menu sidebar yang tidak berhak (padanan can() di sidebar.php) */
    document.querySelectorAll('[data-perm]').forEach(function (el) {
      var perms = String(el.getAttribute('data-perm')).split(',');
      var allowed = perms.some(function (p) { return global.LPAUTH.can(p.trim()); });
      if (!allowed) { el.style.display = 'none'; }
    });
  }

  /** Render flash message (padanan flash_dump() di footer.php) */
  function paintFlash() {
    PHP.flashDump().forEach(function (f) {
      if (global.LP && typeof LP.toast === 'function') {
        LP.toast(f.msg, f.type === 'warn' ? 'warn' : 'ok');
      }
    });
  }

  /**
   * Urutan inisialisasi standar untuk halaman terproteksi.
   * @param {string|null} perm permission halaman
   * @param {function(Object):void} onReady dipanggil setelah lolos gerbang
   */
  function start(perm, onReady) {
    return bootstrap(false).then(function (res) {
      /* belum ada akun -> arahkan ke pemasangan akun pertama */
      if (res.users === 0) {
        global.location.replace('install.html');
        return null;
      }
      return guardPage(perm).then(function (ctx) {
        if (!ctx) { return null; }
        paintUserChrome(ctx);
        paintFlash();
        if (typeof onReady === 'function') { onReady(ctx); }
        return ctx;
      });
    }).catch(function (e) {
      if (global.LP && typeof LP.toast === 'function') {
        LP.toast('Gagal membuka database: ' + e.message, 'err', 6000);
      }
      console.error(e);
      return null;
    });
  }

  global.LPBOOT = {
    bootstrap: bootstrap,
    createUser: createUser,
    guardPage: guardPage,
    paintUserChrome: paintUserChrome,
    paintFlash: paintFlash,
    start: start
  };
})(window);
