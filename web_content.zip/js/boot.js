'use strict';
/* ---------- landscape: fullscreen + lock, warna portrait me rotate ---------- */
const ROOT=document.documentElement;
function fit(){
  const w=innerWidth,h=innerHeight;
  ROOT.style.setProperty('--W',w+'px');ROOT.style.setProperty('--H',h+'px');
  ROOT.classList.toggle('rot',isTouch&&h>w);
}
const _resize=window.resize;
window.resize=function(){fit();_resize()};
addEventListener('orientationchange',()=>setTimeout(()=>window.resize(),250));
async function goLandscape(){
  try{
    if(!document.fullscreenElement&&ROOT.requestFullscreen)await ROOT.requestFullscreen({navigationUI:'hide'});
    if(screen.orientation&&screen.orientation.lock)await screen.orientation.lock('landscape');
  }catch(e){}
  window.resize();
}
// pichhli baar start par crash hua tha? to graphics low kar do
try{const st=localStorage.getItem('lr_stage');if(st){localStorage.removeItem('lr_stage');set.gfx='low';save();
  const d=document.getElementById('err');d.hidden=false;d.textContent='पिछली बार गेम स्टार्ट के समय क्रैश हुआ ('+st+') — ग्राफ़िक्स अपने-आप "लो" कर दिए';setTimeout(()=>{d.hidden=true},9000)}}catch(e){}

/* ---------- Free Fire style loading screen ---------- */
const TIPS=['ज़ोन के अंदर रहो — बाहर हर सेकंड हेल्थ कम होती है','ऊपर की मंज़िल से पूरा घर साफ़ दिखता है — सीढ़ी (तीर वाला पैड) पर चलो','मेडकिट से पूरी हेल्थ वापस आती है, बैंडेज धीरे-धीरे','ग्लू वॉल से दुश्मन की गोली रोको','ग्रेनेड फेंककर दुश्मन को घर से बाहर निकालो','ऊँची मंज़िल पर बैठा स्नाइपर सबसे ख़तरनाक होता है'];
const Loader={
  el:document.getElementById('loading'),p:0,tgt:0,raf:0,last:0,
  show(sub){
    const L=this,g=id=>document.getElementById(id);
    L.p=0;L.tgt=8;L.el.hidden=false;L.el.classList.remove('out');
    g('ldSub').textContent=sub||'सर्वाइवल बैटल रॉयल';
    g('ldTip').textContent='टिप: '+TIPS[Math.floor(Math.random()*TIPS.length)];
    g('ldMsg').textContent='लोड हो रहा है…';
    L.last=performance.now();cancelAnimationFrame(L.raf);L.tick(L.last);
  },
  set(t,m){this.tgt=t;if(m)document.getElementById('ldMsg').textContent=m},
  tick(now){
    const L=Loader,dt=Math.min(.05,(now-L.last)/1000);L.last=now;
    L.p+=(L.tgt-L.p)*Math.min(1,dt*3)+(L.tgt<100?dt*1.5:0);
    if(L.p>L.tgt)L.p=L.tgt;if(L.tgt>=100&&L.p>99.4)L.p=100;
    document.getElementById('ldFill').style.width=L.p+'%';
    document.getElementById('ldPct').textContent=Math.floor(L.p)+'%';
    if(!L.el.hidden)L.raf=requestAnimationFrame(L.tick);
  },
  hide(){
    const L=this;
    const go=()=>{if(L.p<99.5){setTimeout(go,60);return}L.el.classList.add('out');setTimeout(()=>{L.el.hidden=true;L.el.classList.remove('out')},480)};
    L.tgt=100;go();
  }
};
// game khulne se pehle: boot loading
Loader.show('सर्वाइवल बैटल रॉयल');Loader.set(40,'फ़ॉन्ट और आवाज़ें तैयार हो रही हैं…');
window.resize();
Promise.race([document.fonts?document.fonts.ready:Promise.resolve(),new Promise(r=>setTimeout(r,2500))]).then(()=>{
  Loader.set(80,'दुनिया तैयार हो रही है…');
  setTimeout(()=>{Loader.set(100,'तैयार!');setTimeout(()=>Loader.hide(),300)},1300);
});
