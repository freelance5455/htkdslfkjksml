"use strict";


/* =========================================================
   NEXORA BOOT
========================================================= */

const NexoraBoot = {

    started: false,


    async start() {

        if (this.started) return;

        this.started = true;


        const steps = [

            ["Kernel", "Initializing core system..."],
            ["System Modules", "Loading Nexora System..."],
            ["File System", "Mounting virtual file system..."],
            ["Window Manager", "Starting window manager..."],
            ["Applications", "Loading applications..."],
            ["Desktop", "Starting desktop..."]

        ];


        for (let i = 0; i < steps.length; i++) {

            const [status, detail] = steps[i];


            this.update(
                status,
                detail,
                ((i + 1) / steps.length) * 100
            );


            await this.delay(250);


            if (status === "System Modules") {

                await Nexora.System.init();

            }

        }


        this.update(
            "Nexora OS Ready",
            "Starting desktop...",
            100
        );


        await this.delay(400);


        this.startDesktop();

    },


    update(status, detail, progress) {

        const statusElement =
            document.getElementById("status");


        const detailsElement =
            document.getElementById("details");


        const progressElement =
            document.getElementById("progress");


        if (statusElement) {

            statusElement.textContent =
                status;

        }


        if (detailsElement) {

            detailsElement.textContent =
                detail;

        }


        if (progressElement) {

            progressElement.style.width =
                progress + "%";

        }

    },


    startDesktop() {

        const boot =
            document.getElementById("bootScreen");


        const desktop =
            document.getElementById("desktop");


        if (desktop) {

            desktop.style.display =
                "block";

        }


        if (boot) {

            boot.style.opacity =
                "0";


            setTimeout(() => {

                boot.style.display =
                    "none";

            }, 800);

        }


        Desktop.start();

    },


    delay(ms) {

        return new Promise(
            resolve =>
                setTimeout(resolve, ms)
        );

    }

};


/* =========================================================
   NEXORA DESKTOP
========================================================= */

window.Desktop = {

    selectedShortcut: null,

    movingShortcut: null,

    shortcutMoveMode: false,

    longPressTimer: null,

    clockInterval: null,

    started: false,


    /* =====================================================
       GRID
    ===================================================== */

    GRID_WIDTH: 112,

    GRID_HEIGHT: 112,

    GRID_PADDING: 12,


    /* =====================================================
       START
    ===================================================== */

    start() {

        if (this.started) return;

        this.started = true;


        this.updateClock();


        this.clockInterval =
            setInterval(
                () => this.updateClock(),
                1000
            );


        this.setupStartButton();

        this.setupStartMenu();

        this.setupDesktopIcons();

        this.setupContextMenu();

        this.setupGlobalContext();

        this.populateApps();

        this.restoreShortcuts();


        setTimeout(
            () => this.openApp("welcome"),
            350
        );

    },


    /* =====================================================
       CLOCK
    ===================================================== */

    updateClock() {

        const clock =
            document.getElementById("clock");


        if (!clock) return;


        const now =
            new Date();


        clock.textContent =
            now.toLocaleTimeString(
                [],
                {
                    hour: "2-digit",
                    minute: "2-digit"
                }
            );

    },


    /* =====================================================
       START MENU
    ===================================================== */

    setupStartButton() {

        const button =
            document.getElementById(
                "startButton"
            );


        if (!button) return;


        button.addEventListener(
            "click",
            event => {

                event.stopPropagation();

                this.toggleStartMenu();

            }
        );

    },


    toggleStartMenu() {

        const menu =
            document.getElementById(
                "startMenu"
            );


        if (!menu) return;


        menu.classList.toggle(
            "open"
        );

    },


    closeStartMenu() {

        const menu =
            document.getElementById(
                "startMenu"
            );


        if (menu) {

            menu.classList.remove(
                "open"
            );

        }

    },


    setupStartMenu() {

        const search =
            document.getElementById(
                "startSearch"
            );


        if (search) {

            search.addEventListener(
                "input",
                () => {

                    const query =
                        search.value
                            .toLowerCase()
                            .trim();


                    document
                        .querySelectorAll(
                            ".start-app"
                        )
                        .forEach(button => {

                            const text =
                                button.textContent
                                    .toLowerCase();


                            button.style.display =
                                text.includes(query)
                                    ? "flex"
                                    : "none";

                        });

                }
            );

        }


        document.addEventListener(
            "keydown",
            event => {

                if (event.key === "Escape") {

                    this.closeStartMenu();

                    this.closeContextMenu();

                    this.clearShortcutSelection();

                    this.stopMoving();

                }

            }
        );

    },


    /* =====================================================
       DESKTOP SHORTCUTS
    ===================================================== */

    setupDesktopIcons() {

        document
            .querySelectorAll(
                ".desktop-icon"
            )
            .forEach(icon => {

                this.setupShortcut(
                    icon
                );

            });

    },


    setupShortcut(icon) {

        if (
            icon.dataset.nexoraReady ===
            "true"
        ) {

            return;

        }


        icon.dataset.nexoraReady =
            "true";


        let pointerDown =
            false;


        let dragging =
            false;


        let pointerId =
            null;


        let offsetX =
            0;


        let offsetY =
            0;


        let startX =
            0;


        let startY =
            0;


        /* =================================================
           POINTER DOWN
        ================================================= */

        icon.addEventListener(
            "pointerdown",
            event => {

                if (
                    event.pointerType === "mouse" &&
                    event.button !== 0
                ) {

                    return;

                }


                pointerDown =
                    true;


                dragging =
                    false;


                pointerId =
                    event.pointerId;


                startX =
                    event.clientX;


                startY =
                    event.clientY;


                const rect =
                    icon.getBoundingClientRect();


                offsetX =
                    event.clientX -
                    rect.left;


                offsetY =
                    event.clientY -
                    rect.top;


                this.selectShortcut(
                    icon
                );


                /* =========================================
                   MOBILE LONG PRESS
                ========================================= */

                if (
                    event.pointerType ===
                    "touch"
                ) {

                    clearTimeout(
                        this.longPressTimer
                    );


                    this.longPressTimer =
                        setTimeout(() => {

                            if (
                                !pointerDown
                            ) {

                                return;

                            }


                            this.shortcutMoveMode =
                                true;


                            this.movingShortcut =
                                icon;


                            icon.classList.add(
                                "moving"
                            );


                            try {

                                icon.setPointerCapture(
                                    pointerId
                                );

                            } catch {}

                        }, 450);

                }


                try {

                    icon.setPointerCapture(
                        pointerId
                    );

                } catch {}


                event.preventDefault();

            }
        );


        /* =================================================
           POINTER MOVE
        ================================================= */

        icon.addEventListener(
            "pointermove",
            event => {

                if (
                    !pointerDown
                ) {

                    return;

                }


                if (
                    event.pointerId !==
                    pointerId
                ) {

                    return;

                }


                const movedX =
                    event.clientX -
                    startX;


                const movedY =
                    event.clientY -
                    startY;


                const distance =
                    Math.sqrt(
                        movedX * movedX +
                        movedY * movedY
                    );


                /*
                 * Começa o movimento quando
                 * o usuário realmente arrasta.
                 */

                if (
                    distance > 6 &&
                    !dragging
                ) {

                    clearTimeout(
                        this.longPressTimer
                    );


                    dragging =
                        true;


                    this.shortcutMoveMode =
                        true;


                    this.movingShortcut =
                        icon;


                    icon.classList.add(
                        "moving"
                    );

                }


                if (
                    !dragging &&
                    !this.shortcutMoveMode
                ) {

                    return;

                }


                const desktop =
                    document.getElementById(
                        "desktop"
                    );


                if (!desktop) return;


                const desktopRect =
                    desktop.getBoundingClientRect();


                const iconRect =
                    icon.getBoundingClientRect();


                let x =
                    event.clientX -
                    desktopRect.left -
                    offsetX;


                let y =
                    event.clientY -
                    desktopRect.top -
                    offsetY;


                const maxX =
                    Math.max(
                        0,
                        desktopRect.width -
                        iconRect.width -
                        10
                    );


                const maxY =
                    Math.max(
                        0,
                        desktopRect.height -
                        iconRect.height -
                        90
                    );


                x =
                    Math.max(
                        0,
                        Math.min(
                            x,
                            maxX
                        )
                    );


                y =
                    Math.max(
                        0,
                        Math.min(
                            y,
                            maxY
                        )
                    );


                icon.style.position =
                    "absolute";


                icon.style.left =
                    x + "px";


                icon.style.top =
                    y + "px";

            }
        );


        /* =================================================
           POINTER UP
        ================================================= */

        icon.addEventListener(
            "pointerup",
            event => {

                clearTimeout(
                    this.longPressTimer
                );


                if (
                    event.pointerId !==
                    pointerId
                ) {

                    return;

                }


                pointerDown =
                    false;


                /*
                 * Se estava arrastando,
                 * encaixa no Grid.
                 */

                if (
                    dragging ||
                    this.movingShortcut ===
                    icon
                ) {

                    this.snapShortcut(
                        icon
                    );


                    this.saveShortcutPosition(
                        icon
                    );


                    this.stopMoving(
                        icon
                    );

                }


                /*
                 * Duplo clique no mouse
                 */

                else if (
                    event.pointerType ===
                    "mouse" &&
                    event.detail === 2
                ) {

                    this.openApp(
                        icon.dataset.app
                    );

                }


                /*
                 * Final do toque
                 */

                else if (
                    event.pointerType ===
                    "touch"
                ) {

                    this.stopMoving(
                        icon
                    );

                }


                try {

                    icon.releasePointerCapture(
                        pointerId
                    );

                } catch {}


                pointerId =
                    null;

            }
        );


        /* =================================================
           POINTER CANCEL
        ================================================= */

        icon.addEventListener(
            "pointercancel",
            () => {

                clearTimeout(
                    this.longPressTimer
                );


                pointerDown =
                    false;


                dragging =
                    false;


                if (
                    this.movingShortcut ===
                    icon
                ) {

                    this.snapShortcut(
                        icon
                    );


                    this.saveShortcutPosition(
                        icon
                    );

                }


                this.stopMoving(
                    icon
                );

            }
        );


        /* =================================================
           RIGHT CLICK
        ================================================= */

        icon.addEventListener(
            "contextmenu",
            event => {

                event.preventDefault();

                event.stopPropagation();


                this.selectShortcut(
                    icon
                );


                this.openContextMenu(
                    event.clientX,
                    event.clientY,
                    icon
                );

            }
        );

    },


    /* =====================================================
       SELECT SHORTCUT
    ===================================================== */

    selectShortcut(icon) {

        document
            .querySelectorAll(
                ".desktop-icon"
            )
            .forEach(item => {

                item.classList.remove(
                    "selected"
                );

            });


        icon.classList.add(
            "selected"
        );


        this.selectedShortcut =
            icon;

    },


    clearShortcutSelection() {

        document
            .querySelectorAll(
                ".desktop-icon"
            )
            .forEach(item => {

                item.classList.remove(
                    "selected"
                );

            });


        this.selectedShortcut =
            null;

    },


    /* =====================================================
       STOP MOVING
    ===================================================== */

    stopMoving(icon = null) {

        if (
            icon &&
            this.movingShortcut &&
            this.movingShortcut !==
            icon
        ) {

            return;

        }


        document
            .querySelectorAll(
                ".desktop-icon.moving"
            )
            .forEach(item => {

                item.classList.remove(
                    "moving"
                );

            });


        this.shortcutMoveMode =
            false;


        this.movingShortcut =
            null;

    },


    /* =====================================================
       SNAP TO GRID
    ===================================================== */

    snapShortcut(icon) {

        const desktop =
            document.getElementById(
                "desktop"
            );


        if (!desktop) return;


        const desktopRect =
            desktop.getBoundingClientRect();


        const iconRect =
            icon.getBoundingClientRect();


        const currentLeft =
            parseFloat(
                icon.style.left
            ) || 0;


        const currentTop =
            parseFloat(
                icon.style.top
            ) || 0;


        const padding =
            this.GRID_PADDING;


        const gridW =
            this.GRID_WIDTH;


        const gridH =
            this.GRID_HEIGHT;


        /*
         * Descobre a célula desejada.
         */

        let col =
            Math.round(
                (
                    currentLeft -
                    padding
                ) /
                gridW
            );


        let row =
            Math.round(
                (
                    currentTop -
                    padding
                ) /
                gridH
            );


        col =
            Math.max(
                0,
                col
            );


        row =
            Math.max(
                0,
                row
            );


        /*
         * Limites.
         */

        const maxCol =
            Math.max(
                0,
                Math.floor(
                    (
                        desktopRect.width -
                        iconRect.width -
                        padding
                    ) /
                    gridW
                )
            );


        const maxRow =
            Math.max(
                0,
                Math.floor(
                    (
                        desktopRect.height -
                        iconRect.height -
                        90 -
                        padding
                    ) /
                    gridH
                )
            );


        col =
            Math.min(
                col,
                maxCol
            );


        row =
            Math.min(
                row,
                maxRow
            );


        /*
         * Se estiver ocupada,
         * procura outra célula.
         */

        const free =
            this.findNearestFreeCell(
                col,
                row,
                icon
            );


        col =
            free.col;


        row =
            free.row;


        /*
         * Posição final.
         */

        const x =
            padding +
            col * gridW;


        const y =
            padding +
            row * gridH;


        icon.style.position =
            "absolute";


        icon.style.left =
            x + "px";


        icon.style.top =
            y + "px";

    },


    /* =====================================================
       FIND NEAREST FREE CELL
    ===================================================== */

    findNearestFreeCell(
        targetCol,
        targetRow,
        ignoredIcon = null
    ) {

        const occupied =
            new Set();


        /*
         * Descobre as células ocupadas.
         */

        document
            .querySelectorAll(
                ".desktop-icon"
            )
            .forEach(icon => {

                if (
                    icon ===
                    ignoredIcon
                ) {

                    return;

                }


                const left =
                    parseFloat(
                        icon.style.left
                    );


                const top =
                    parseFloat(
                        icon.style.top
                    );


                if (
                    Number.isNaN(left) ||
                    Number.isNaN(top)
                ) {

                    return;

                }


                const col =
                    Math.round(
                        (
                            left -
                            this.GRID_PADDING
                        ) /
                        this.GRID_WIDTH
                    );


                const row =
                    Math.round(
                        (
                            top -
                            this.GRID_PADDING
                        ) /
                        this.GRID_HEIGHT
                    );


                occupied.add(
                    `${col}:${row}`
                );

            });


        /*
         * Primeiro tenta a célula
         * exata.
         */

        const targetKey =
            `${targetCol}:${targetRow}`;


        if (
            !occupied.has(
                targetKey
            )
        ) {

            return {

                col:
                    targetCol,

                row:
                    targetRow

            };

        }


        /*
         * Busca a célula livre mais próxima.
         */

        const desktop =
            document.getElementById(
                "desktop"
            );


        if (!desktop) {

            return {

                col:
                    targetCol,

                row:
                    targetRow

            };

        }


        const desktopRect =
            desktop.getBoundingClientRect();


        const testIcon =
            ignoredIcon ||
            document.querySelector(
                ".desktop-icon"
            );


        const iconWidth =
            testIcon
                ? testIcon.offsetWidth
                : 92;


        const iconHeight =
            testIcon
                ? testIcon.offsetHeight
                : 104;


        const maxCol =
            Math.max(
                0,
                Math.floor(
                    (
                        desktopRect.width -
                        iconWidth -
                        this.GRID_PADDING
                    ) /
                    this.GRID_WIDTH
                )
            );


        const maxRow =
            Math.max(
                0,
                Math.floor(
                    (
                        desktopRect.height -
                        iconHeight -
                        90 -
                        this.GRID_PADDING
                    ) /
                    this.GRID_HEIGHT
                )
            );


        const maxDistance =
            Math.max(
                maxCol,
                maxRow
            );


        /*
         * Expande a procura em volta
         * da célula desejada.
         */

        for (
            let distance = 1;
            distance <= maxDistance;
            distance++
        ) {

            for (
                let row =
                    targetRow -
                    distance;

                row <=
                    targetRow +
                    distance;

                row++
            ) {

                for (
                    let col =
                        targetCol -
                        distance;

                    col <=
                        targetCol +
                        distance;

                    col++
                ) {

                    if (
                        col < 0 ||
                        row < 0 ||
                        col > maxCol ||
                        row > maxRow
                    ) {

                        continue;

                    }


                    /*
                     * Só verifica a borda
                     * do quadrado atual.
                     */

                    if (
                        Math.abs(
                            col -
                            targetCol
                        ) !== distance &&
                        Math.abs(
                            row -
                            targetRow
                        ) !== distance
                    ) {

                        continue;

                    }


                    const key =
                        `${col}:${row}`;


                    if (
                        !occupied.has(
                            key
                        )
                    ) {

                        return {

                            col,
                            row

                        };

                    }

                }

            }

        }


        /*
         * Fallback:
         * procura qualquer célula.
         */

        for (
            let row = 0;
            row <= maxRow;
            row++
        ) {

            for (
                let col = 0;
                col <= maxCol;
                col++
            ) {

                const key =
                    `${col}:${row}`;


                if (
                    !occupied.has(
                        key
                    )
                ) {

                    return {

                        col,
                        row

                    };

                }

            }

        }


        /*
         * Desktop completamente cheio.
         */

        return {

            col:
                targetCol,

            row:
                targetRow

        };

    },


    /* =====================================================
       FIND FREE GRID POSITION
    ===================================================== */

    findFreeGridPosition() {

        const desktop =
            document.getElementById(
                "desktop"
            );


        if (!desktop) {

            return {

                x:
                    this.GRID_PADDING,

                y:
                    this.GRID_PADDING

            };

        }


        const rect =
            desktop.getBoundingClientRect();


        const icon =
            document.querySelector(
                ".desktop-icon"
            );


        const iconWidth =
            icon
                ? icon.offsetWidth
                : 92;


        const iconHeight =
            icon
                ? icon.offsetHeight
                : 104;


        const columns =
            Math.max(
                1,
                Math.floor(
                    (
                        rect.width -
                        iconWidth -
                        this.GRID_PADDING
                    ) /
                    this.GRID_WIDTH
                ) + 1
            );


        const rows =
            Math.max(
                1,
                Math.floor(
                    (
                        rect.height -
                        iconHeight -
                        90 -
                        this.GRID_PADDING
                    ) /
                    this.GRID_HEIGHT
                ) + 1
            );


        const occupied =
            new Set();


        document
            .querySelectorAll(
                ".desktop-icon"
            )
            .forEach(icon => {

                const left =
                    parseFloat(
                        icon.style.left
                    );


                const top =
                    parseFloat(
                        icon.style.top
                    );


                if (
                    Number.isNaN(left) ||
                    Number.isNaN(top)
                ) {

                    return;

                }


                const col =
                    Math.round(
                        (
                            left -
                            this.GRID_PADDING
                        ) /
                        this.GRID_WIDTH
                    );


                const row =
                    Math.round(
                        (
                            top -
                            this.GRID_PADDING
                        ) /
                        this.GRID_HEIGHT
                    );


                occupied.add(
                    `${col}:${row}`
                );

            });


        for (
            let row = 0;
            row < rows;
            row++
        ) {

            for (
                let col = 0;
                col < columns;
                col++
            ) {

                const key =
                    `${col}:${row}`;


                if (
                    !occupied.has(
                        key
                    )
                ) {

                    return {

                        x:
                            this.GRID_PADDING +
                            col *
                            this.GRID_WIDTH,

                        y:
                            this.GRID_PADDING +
                            row *
                            this.GRID_HEIGHT

                    };

                }

            }

        }


        return {

            x:
                this.GRID_PADDING,

            y:
                this.GRID_PADDING +
                rows *
                this.GRID_HEIGHT

        };

    },


    /* =====================================================
       RESTORE SHORTCUTS
    ===================================================== */

    restoreShortcuts() {

        const icons =
            document.querySelectorAll(
                ".desktop-icon"
            );


        icons.forEach(icon => {

            const removed =
                localStorage.getItem(
                    "nexora-shortcut-removed-" +
                    icon.dataset.app
                );


            if (
                removed === "true"
            ) {

                icon.remove();

                return;

            }


            const restored =
                this.loadShortcutPosition(
                    icon
                );


            if (!restored) {

                const position =
                    this.findFreeGridPosition();


                icon.style.position =
                    "absolute";


                icon.style.left =
                    position.x + "px";


                icon.style.top =
                    position.y + "px";


                this.saveShortcutPosition(
                    icon
                );

            }

        });

    },


    /* =====================================================
       LOAD SHORTCUT POSITION
    ===================================================== */

    loadShortcutPosition(icon) {

        const raw =
            localStorage.getItem(
                "nexora-shortcut-" +
                icon.dataset.app
            );


        if (!raw) {

            return false;

        }


        try {

            const data =
                JSON.parse(
                    raw
                );


            if (
                typeof data.left !==
                "string" ||

                typeof data.top !==
                "string"
            ) {

                return false;

            }


            icon.style.position =
                "absolute";


            icon.style.left =
                data.left;


            icon.style.top =
                data.top;


            return true;

        } catch {

            return false;

        }

    },


    /* =====================================================
       SAVE SHORTCUT POSITION
    ===================================================== */

    saveShortcutPosition(icon) {

        if (
            !icon.dataset.app
        ) {

            return;

        }


        const data = {

            left:
                icon.style.left,

            top:
                icon.style.top

        };


        localStorage.setItem(
            "nexora-shortcut-" +
            icon.dataset.app,

            JSON.stringify(
                data
            )
        );

    },


    /* =====================================================
       CONTEXT MENU
    ===================================================== */

    setupContextMenu() {

        let menu =
            document.getElementById(
                "nexoraContextMenu"
            );


        if (menu) {

            return;

        }


        menu =
            document.createElement(
                "div"
            );


        menu.id =
            "nexoraContextMenu";


        document.body.appendChild(
            menu
        );

    },


    setupGlobalContext() {

        const desktop =
            document.getElementById(
                "desktop"
            );


        if (!desktop) {

            return;

        }


        /*
         * Remove browser menu.
         */

        document.addEventListener(
            "contextmenu",
            event => {

                event.preventDefault();

            }
        );


        /*
         * Desktop right click.
         */

        desktop.addEventListener(
            "contextmenu",
            event => {

                if (
                    event.target.closest(
                        ".nexora-window"
                    )
                ) {

                    return;

                }


                if (
                    event.target.closest(
                        "#taskbar"
                    )
                ) {

                    return;

                }


                if (
                    event.target.closest(
                        "#startMenu"
                    )
                ) {

                    return;

                }


                const shortcut =
                    event.target.closest(
                        ".desktop-icon"
                    );


                if (shortcut) {

                    return;

                }


                this.clearShortcutSelection();


                this.openContextMenu(
                    event.clientX,
                    event.clientY,
                    null
                );

            }
        );


        /*
         * Click outside menus.
         */

        document.addEventListener(
            "pointerdown",
            event => {

                const menu =
                    document.getElementById(
                        "nexoraContextMenu"
                    );


                if (
                    menu &&
                    !menu.contains(
                        event.target
                    )
                ) {

                    this.closeContextMenu();

                }


                const startMenu =
                    document.getElementById(
                        "startMenu"
                    );


                const startButton =
                    document.getElementById(
                        "startButton"
                    );


                if (
                    startMenu &&
                    startMenu.classList.contains(
                        "open"
                    ) &&

                    !startMenu.contains(
                        event.target
                    ) &&

                    !startButton?.contains(
                        event.target
                    )
                ) {

                    this.closeStartMenu();

                }

            }
        );

    },


    /* =====================================================
       OPEN CONTEXT MENU
    ===================================================== */

    openContextMenu(
        x,
        y,
        shortcut
    ) {

        const menu =
            document.getElementById(
                "nexoraContextMenu"
            );


        if (!menu) {

            return;

        }


        menu.innerHTML =
            "";


        if (shortcut) {

            this.addContextItem(
                menu,
                "◈",
                "Open",
                () => {

                    this.closeContextMenu();

                    this.openApp(
                        shortcut.dataset.app
                    );

                }
            );


            this.addContextItem(
                menu,
                "✋",
                "Move Shortcut",
                () => {

                    this.closeContextMenu();


                    this.shortcutMoveMode =
                        true;


                    this.movingShortcut =
                        shortcut;


                    shortcut.classList.add(
                        "moving"
                    );

                }
            );


            this.addContextSeparator(
                menu
            );


            this.addContextItem(
                menu,
                "⌫",
                "Remove Shortcut",
                () => {

                    const appId =
                        shortcut.dataset.app;


                    localStorage.setItem(
                        "nexora-shortcut-removed-" +
                        appId,
                        "true"
                    );


                    localStorage.removeItem(
                        "nexora-shortcut-" +
                        appId
                    );


                    shortcut.remove();


                    this.clearShortcutSelection();

                    this.closeContextMenu();

                },
                true
            );

        } else {

            this.addContextItem(
                menu,
                "＋",
                "Add Shortcut",
                () => {

                    this.closeContextMenu();

                    this.openShortcutPicker();

                }
            );


            this.addContextItem(
                menu,
                "↻",
                "Refresh",
                () => {

                    this.closeContextMenu();

                    location.reload();

                }
            );


            this.addContextSeparator(
                menu
            );


            this.addContextItem(
                menu,
                "▦",
                "Display Settings",
                () => {

                    this.closeContextMenu();

                    this.openApp(
                        "settings"
                    );

                }
            );


            this.addContextItem(
                menu,
                "⚙",
                "Desktop Settings",
                () => {

                    this.closeContextMenu();

                    this.openApp(
                        "settings"
                    );

                }
            );

        }


        menu.classList.add(
            "open"
        );


        /*
         * Mede depois de abrir.
         */

        const width =
            menu.offsetWidth;


        const height =
            menu.offsetHeight;


        x =
            Math.min(
                x,
                window.innerWidth -
                width -
                8
            );


        y =
            Math.min(
                y,
                window.innerHeight -
                height -
                8
            );


        menu.style.left =
            Math.max(
                8,
                x
            ) + "px";


        menu.style.top =
            Math.max(
                8,
                y
            ) + "px";

    },


    /* =====================================================
       CONTEXT ITEM
    ===================================================== */

    addContextItem(
        menu,
        icon,
        label,
        callback,
        danger = false
    ) {

        const button =
            document.createElement(
                "button"
            );


        button.type =
            "button";


        button.className =
            "context-item";


        if (danger) {

            button.classList.add(
                "danger"
            );

        }


        button.style.appearance =
            "none";


        button.style.webkitAppearance =
            "none";


        button.innerHTML = `

            <span class="context-item-icon">
                ${icon}
            </span>

            <span>
                ${label}
            </span>

        `;


        button.addEventListener(
            "click",
            callback
        );


        menu.appendChild(
            button
        );

    },


    addContextSeparator(menu) {

        const separator =
            document.createElement(
                "div"
            );


        separator.className =
            "context-separator";


        menu.appendChild(
            separator
        );

    },


    closeContextMenu() {

        const menu =
            document.getElementById(
                "nexoraContextMenu"
            );


        if (menu) {

            menu.classList.remove(
                "open"
            );

        }

    },


    /* =====================================================
       SHORTCUT PICKER
    ===================================================== */

    openShortcutPicker() {

        const apps =
            Nexora.System.getApps();


        const content =
            document.createElement(
                "div"
            );


        content.style.cssText = `

            width:100%;

            height:100%;

            padding:24px;

            box-sizing:border-box;

            color:white;

            overflow:auto;

        `;


        content.innerHTML = `

            <div style="
                display:flex;
                align-items:center;
                gap:12px;
            ">

                <div style="
                    width:42px;
                    height:42px;
                    display:flex;
                    align-items:center;
                    justify-content:center;
                    border-radius:13px;
                    background:
                        rgba(255,255,255,.08);
                    border:
                        1px solid
                        rgba(255,255,255,.08);
                    font-size:19px;
                ">
                    ＋
                </div>

                <div>

                    <h2 style="
                        margin:0;
                        font-size:20px;
                        font-weight:600;
                    ">
                        Add Shortcut
                    </h2>

                    <p style="
                        margin:4px 0 0;
                        font-size:12px;
                        opacity:.45;
                    ">
                        Choose an application
                    </p>

                </div>

            </div>


            <div
                id="shortcutApps"
                style="
                    display:grid;
                    grid-template-columns:
                        repeat(
                            auto-fill,
                            minmax(150px,1fr)
                        );
                    gap:10px;
                    margin-top:22px;
                "
            ></div>

        `;


        const grid =
            content.querySelector(
                "#shortcutApps"
            );


        apps.forEach(
            app => {

                const existing =
                    document.querySelector(
                        `.desktop-icon[data-app="${app.id}"]`
                    );


                const button =
                    document.createElement(
                        "button"
                    );


                button.type =
                    "button";


                button.style.cssText = `

                    min-height:86px;

                    padding:14px;

                    display:flex;

                    flex-direction:column;

                    align-items:flex-start;

                    justify-content:center;

                    gap:6px;

                    border:
                        1px solid
                        rgba(255,255,255,.08);

                    border-radius:14px;

                    background:
                        rgba(255,255,255,.045);

                    color:white;

                    font-family:inherit;

                    cursor:pointer;

                    text-align:left;

                    appearance:none;

                    -webkit-appearance:none;

                    outline:none;

                    transition:
                        background .15s ease,
                        transform .12s ease,
                        border-color .15s ease;

                `;


                if (existing) {

                    button.style.opacity =
                        ".35";

                    button.style.cursor =
                        "default";

                }


                button.innerHTML = `

                    <div style="
                        width:32px;
                        height:32px;
                        display:flex;
                        align-items:center;
                        justify-content:center;
                        border-radius:10px;
                        background:
                            rgba(255,255,255,.07);
                        border:
                            1px solid
                            rgba(255,255,255,.07);
                        font-size:16px;
                    ">
                        ${app.icon}
                    </div>

                    <strong style="
                        font-size:12px;
                        font-weight:500;
                    ">
                        ${app.name}
                    </strong>

                    ${
                        existing
                            ? `
                                <span style="
                                    font-size:9px;
                                    opacity:.45;
                                ">
                                    Already on desktop
                                </span>
                            `
                            : ""
                    }

                `;


                if (!existing) {

                    button.addEventListener(
                        "mouseenter",
                        () => {

                            button.style.background =
                                "rgba(255,255,255,.09)";


                            button.style.borderColor =
                                "rgba(255,255,255,.12)";

                        }
                    );


                    button.addEventListener(
                        "mouseleave",
                        () => {

                            button.style.background =
                                "rgba(255,255,255,.045)";


                            button.style.borderColor =
                                "rgba(255,255,255,.08)";

                        }
                    );


                    button.addEventListener(
                        "click",
                        () => {

                            this.createShortcut(
                                app
                            );

                        }
                    );

                }


                grid.appendChild(
                    button
                );

            }
        );


        WindowManager.create({

            appId:
                "shortcut-picker-" +
                Date.now(),

            title:
                "Add Shortcut",

            icon:
                "＋",

            width:
                560,

            height:
                450,

            content

        });

    },


    /* =====================================================
       CREATE SHORTCUT
    ===================================================== */

    createShortcut(app) {

        const existing =
            document.querySelector(
                `.desktop-icon[data-app="${app.id}"]`
            );


        if (existing) {

            this.selectShortcut(
                existing
            );

            return;

        }


        /*
         * Remove the deleted state.
         */

        localStorage.removeItem(
            "nexora-shortcut-removed-" +
            app.id
        );


        const icon =
            document.createElement(
                "button"
            );


        icon.type =
            "button";


        icon.className =
            "desktop-icon";


        icon.dataset.app =
            app.id;


        icon.innerHTML = `

            <span class="desktop-icon-symbol">
                ${app.icon}
            </span>

            <span class="desktop-icon-label">
                ${app.name}
            </span>

        `;


        const area =
            document.getElementById(
                "desktopArea"
            );


        if (!area) return;


        area.appendChild(
            icon
        );


        const position =
            this.findFreeGridPosition();


        icon.style.position =
            "absolute";


        icon.style.left =
            position.x + "px";


        icon.style.top =
            position.y + "px";


        this.setupShortcut(
            icon
        );


        this.saveShortcutPosition(
            icon
        );


        this.selectShortcut(
            icon
        );

    },


    /* =====================================================
       START MENU APPS
    ===================================================== */

    populateApps() {

        const list =
            document.getElementById(
                "startAppList"
            );


        if (!list) return;


        list.innerHTML =
            "";


        for (
            const app
            of Nexora.System.getApps()
        ) {

            const button =
                document.createElement(
                    "button"
                );


            button.type =
                "button";


            button.className =
                "start-app";


            button.dataset.app =
                app.id;


            button.innerHTML = `

                <span class="start-app-icon">
                    ${app.icon}
                </span>

                <span class="start-app-info">

                    <span class="start-app-name">
                        ${app.name}
                    </span>

                    <span class="start-app-description">
                        ${app.description}
                    </span>

                </span>

            `;


            button.addEventListener(
                "click",
                () => {

                    this.openApp(
                        app.id
                    );


                    this.closeStartMenu();

                }
            );


            list.appendChild(
                button
            );

        }

    },


    /* =====================================================
       OPEN APP
    ===================================================== */

    openApp(id) {

        this.closeContextMenu();

        this.closeStartMenu();


        return Nexora.System.launch(
            id
        );

    }

};


/* =========================================================
   DOM READY
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        NexoraBoot.start();

    }
);


console.log(
    "Nexora Boot loaded."
);