/* Setup screen, boot(), loadProfile, loadApp */
  function requireReady(){ if(!ready){ renderSetup(); return false; } return true; }
  function renderSetup(){ $('#app').innerHTML=`<main id="main-content" class="setup" tabindex="-1"><div class="setup-card"><div class="brand-mark">${icon('disc',22)}</div><p class="eyebrow blue">SUPABASE REQUIRED</p><h1>Connect Imposed Entertainment</h1><p>This deployment requires a live Supabase project. Add your Supabase Project URL and anon public key to <code>config.js</code>, then redeploy.</p><div class="setup-code"><b>config.js</b><pre>window.IMPOSED_CONFIG = {
  SUPABASE_URL: "https://YOUR-PROJECT.supabase.co",
  SUPABASE_ANON_KEY: "YOUR-ANON-PUBLIC-KEY"
};</pre></div><ol><li>Use the existing Supabase project and its applied migrations; do not run an old schema file over a live database.</li><li>Confirm the Project URL and publishable/anon key in <code>config.js</code>.</li><li>Deploy this folder to Netlify.</li><li>Have the existing label administrator invite artists and label members from Roster &amp; invites.</li></ol><p class="setup-note">The portal contains no seeded catalogue data. Everything shown after sign-in comes from your Supabase project.</p></div></main>`; }

  async function boot(){
    if(!requireReady()) return;
    document.addEventListener('keydown',e=>{ if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='k'){ e.preventDefault(); if(session&&profile) openPal(); } else if(e.key==='Escape') closePal(); });
    { const qs=new URLSearchParams(location.search+'&'+location.hash.replace(/^#/,'')); const ed=qs.get('error_description'); if(ed){ toast(/database error|invite/i.test(ed)?'That Google account is not invited yet. Ask the label to invite the same email address.':ed,'error'); history.replaceState(null,'',location.pathname); } }
    const {data,error}=await sb.auth.getSession(); if(error){toast(error.message,'error'); return;} session=data.session;
    sb.auth.onAuthStateChange((_e,s)=>{ if(s&&profile&&profile.id===s.user.id&&_e!=='USER_UPDATED'){ session=s; return; } session=s; if(s) loadApp(); else { profile=null; releases=[]; users=[]; renderAuth(); } });
    if(!session) await readInviteFromUrl();
    if(session) await loadApp(); else renderAuth();
  }
  async function loadProfile(){
    const {data,error}=await sb.from('profiles').select('*').eq('id',session.user.id).maybeSingle();
    if(error) throw error;
    if(!data){ const {data:p,error:e}=await sb.from('profiles').insert({id:session.user.id,email:session.user.email,display_name:session.user.user_metadata?.full_name||session.user.email?.split('@')[0]||'Artist'}).select().single(); if(e) throw e; profile=p; }
    else profile=data;
    profile.role=String(profile.role||'artist').trim().toLowerCase();
    if(window.IE_I18N){
      if(profile.preferred_language && window.IE_I18N.languages[profile.preferred_language]) window.IE_I18N.setLanguage(profile.preferred_language,{notify:false});
      else {
        const language=window.IE_I18N.language||'en';
        const {error:languageError}=await sb.from('profiles').update({preferred_language:language}).eq('id',session.user.id);
        if(!languageError) profile.preferred_language=language; else console.warn('Could not sync language preference to profile',languageError);
      }
    }
  }

  window.addEventListener('ie-language-change',async e=>{
    const language=e.detail&&e.detail.language;
    if(!session||!profile||!window.IE_I18N||!window.IE_I18N.languages[language])return;
    try{const {error}=await sb.from('profiles').update({preferred_language:language}).eq('id',session.user.id);if(error)throw error;profile.preferred_language=language;}
    catch(err){console.warn('Language saved on this device; profile sync failed',err);}
  });
  async function loadApp(){
    if(!session){renderAuth();return;} try { await loadProfile(); await Promise.all([loadReleases(), loadBands(), loadNotes(), loadMisc(), ...(isAdmin()?[loadUsers(), loadInvites()]:[])]);
    if(!window.__poll) window.__poll=setInterval(async()=>{ if(!session||!profile||document.hidden) return; const u=inbox.filter(n=>!n.read).length, p=myBandInvites.length; await loadNotes(); try{const m=await sb.rpc('my_band_invites'); myBandInvites=m.data||[];}catch(_){} if(view!=='builder'&&!typing()&&(inbox.filter(n=>!n.read).length!==u||myBandInvites.length!==p)) render(); },60000);
    if(window.__rtUid!==session.user.id){ try{ if(window.__rt) sb.removeChannel(window.__rt); window.__rtUid=session.user.id; window.__rt=sb.channel('notes-'+session.user.id).on('postgres_changes',{event:'INSERT',schema:'public',table:'notifications',filter:'user_id=eq.'+session.user.id},async p=>{ await loadNotes(); try{const m=await sb.rpc('my_band_invites'); myBandInvites=m.data||[];}catch(_){} await loadMisc(); if(p.new&&p.new.release_id) await loadReleases(); if(p.new&&p.new.title) toast(p.new.title+(p.new.body?': '+p.new.body:''),'success'); if(view!=='builder'&&!typing()) render(); }).subscribe(); }catch(e){ console.warn('Realtime unavailable',e); } }
    if(!window.__routed){window.__routed=true;restoreRoute();}
    render(); } catch(e){ console.error(e); toast(e.message||'Could not load portal','error'); render(); } }
