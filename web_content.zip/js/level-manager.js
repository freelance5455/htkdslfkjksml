/**
 * Snake Escape — Level Manager & Integrity Validator
 * Validates level specifications, organizes worlds, and delegates hints to pathfinder.
 */
(function() {
  'use strict';

  class LevelManager {
    constructor() {
      this.levels = window.SnakeEscape && window.SnakeEscape.LEVELS ? window.SnakeEscape.LEVELS : [];
      this.validateAllLevels();
    }

    getLevel(id) {
      if (id === 999) {
        // Daily Challenge
        const today = new Date().toISOString().split('T')[0];
        return window.SnakeEscape.getDailyLevel(today);
      }

      const lvl = this.levels.find(l => l.id === Number(id));
      if (!lvl) {
        console.error(`[LevelManager] Level ID ${id} not found!`);
        return this.levels[0] || null;
      }
      return JSON.parse(JSON.stringify(lvl));
    }

    getLevelsByWorld(worldNum) {
      return this.levels.filter(l => l.world === Number(worldNum));
    }

    getTotalLevels() {
      return this.levels.length;
    }

    /**
     * Comprehensive validation for each level according to Rule 31
     */
    validateLevel(level) {
      const errors = [];
      const { id, grid, snakes, walls, portals, gates, keys } = level;

      if (!grid || grid.cols < 6 || grid.rows < 6) {
        errors.push(`Invalid grid size: cols ${grid?.cols}, rows ${grid?.rows}`);
      }

      if (!snakes || snakes.length === 0) {
        errors.push('No snakes defined in level');
      }

      // Check snake segments inside bounds
      snakes.forEach(s => {
        if (!s.exit) errors.push(`Snake ${s.id} has no exit!`);
        if (s.exit && (s.exit.x < 0 || s.exit.x >= grid.cols || s.exit.y < 0 || s.exit.y >= grid.rows)) {
          errors.push(`Snake ${s.id} exit out of bounds: (${s.exit.x}, ${s.exit.y})`);
        }
        s.segments.forEach((seg, i) => {
          if (seg.x < 0 || seg.x >= grid.cols || seg.y < 0 || seg.y >= grid.rows) {
            errors.push(`Snake ${s.id} segment ${i} out of bounds: (${seg.x}, ${seg.y})`);
          }
        });
      });

      // Check walls inside bounds
      if (walls) {
        walls.forEach(w => {
          if (w.x < 0 || w.x >= grid.cols || w.y < 0 || w.y >= grid.rows) {
            errors.push(`Wall out of bounds: (${w.x}, ${w.y})`);
          }
        });
      }

      // Check portal pairs
      if (portals && portals.length > 0) {
        if (portals.length % 2 !== 0) {
          errors.push(`Unmatched portal count: ${portals.length}`);
        }
        portals.forEach(p => {
          const partner = portals.find(o => o.id !== p.id && (o.pairId === p.pairId || o.color === p.color));
          if (!partner) {
            errors.push(`Portal ${p.id} has no matching partner pair!`);
          }
        });
      }

      if (errors.length > 0) {
        console.error(`Invalid level: ${id}`, errors);
        return false;
      }
      return true;
    }

    validateAllLevels() {
      let validCount = 0;
      this.levels.forEach(lvl => {
        if (this.validateLevel(lvl)) validCount++;
      });
      console.log(`[LevelManager] Validated ${validCount}/${this.levels.length} levels successfully.`);
    }

    /**
     * Solves and generates an intelligent hint
     */
    getHint(state) {
      if (window.SnakeEscape && window.SnakeEscape.pathfinding) {
        return window.SnakeEscape.pathfinding.findHint(state);
      }
      return null;
    }
  }

  window.SnakeEscape = window.SnakeEscape || {};
  window.SnakeEscape.levelManager = new LevelManager();
})();
