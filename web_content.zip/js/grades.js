document.addEventListener("DOMContentLoaded", () => {
  const key = "msl_grades";
  let grades = JSON.parse(localStorage.getItem(key) || "[]");
  const list = document.getElementById("gradeList");
  const render = () => {
    let points=0, coef=0;
    grades.forEach(g=>{points += g.note*g.coef; coef += g.coef});
    const avg = coef ? points/coef : 0;
    document.getElementById("average").textContent = avg.toFixed(2).replace(".",",");
    document.getElementById("totalPoints").textContent = `${points.toFixed(2).replace(".",",")} point${points>1?"s":""}`;
    list.innerHTML = grades.length ? grades.map((g,i)=>`
      <div class="grade-item"><span>📘</span><b>${escapeHtml(g.subject)}</b><small>${g.note}/20 • coef ${g.coef}</small><button class="icon-btn delete-grade" data-i="${i}">×</button></div>
    `).join("") : "";
  };
  const escapeHtml = s => String(s).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
  render();
  document.getElementById("addGradeBtn").onclick = () => {
    const subject=document.getElementById("gradeSubject").value.trim();
    const note=Number(document.getElementById("gradeValue").value);
    const coef=Number(document.getElementById("gradeCoef").value);
    if(!subject || !Number.isFinite(note) || note<0 || note>20 || !Number.isFinite(coef) || coef<=0){showToast("Vérifie les informations");return;}
    grades.push({subject,note,coef}); localStorage.setItem(key,JSON.stringify(grades));
    document.getElementById("gradeSubject").value=""; document.getElementById("gradeValue").value="";
    render(); showToast("Note ajoutée");
  };
  list.onclick=e=>{const b=e.target.closest(".delete-grade");if(!b)return;grades.splice(+b.dataset.i,1);localStorage.setItem(key,JSON.stringify(grades));render()};
});
