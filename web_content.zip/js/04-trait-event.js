/* ===== FFM 26 • "Special Traits" event (red theme, 15 days, 5 matches, one player with a shooting trait) ===== */
const TRAIT_EVENT_DURATION_MS = 15 * 24 * 60 * 60 * 1000;
const TRAIT_BOOST_PERCENT = 39;
const TRAIT_REWARD = { id: 'ffm-trait-roy-blaze', name: 'Roy Blaze', rating: 91, trait: 'clinical', traitName: 'Clinical Finisher' };

Object.assign(dict.ar, {
  trait_event_title: '🔺 سمات خاصة', trait_kicker: 'FFM 26 • حدث خاص',
  trait_event_subtitle: '5 مباريات • 15 يومًا • لاعب بسمة التسديد',
  trait_match_finish: '🔺 اكتملت مباراة حدث السمات!', trait_stage_reward: 'تم احتساب المباراة في الحدث.',
  trait_progress: 'التقدم: {done}/5 مباريات مكتملة',
  trait_all_complete: 'أكملت المباريات الخمس! افتح المسيرة المهنية واضغط زر الهدية لاستلام Roy Blaze (OVR 91) بسمة Clinical Finisher.',
  trait_expired_message: 'انتهى حدث السمات الخاصة نهائيًا. لا يمكن بدء مباريات جديدة.',
  trait_gift_waiting: '🔺 هدية حدث السمات — أكمل المباريات الخمس لفتحها', trait_gift_ready: '🔺 استلام لاعب حدث السمات',
  trait_gift_claimed: '✅ تم استلام لاعب حدث السمات', trait_gift_ended: '⛔ انتهى حدث السمات',
  trait_player_details: 'السمة: Clinical Finisher — زيادة 39% في قوة ودقة التسديد', trait_reward_title: '🔺 جائزة حدث السمات الخاصة',
  trait_timer_active: '⏱️ الحدث جارٍ', trait_timer_expired: '⛔ انتهى الحدث', trait_trait_label: 'سمة التسديد'
});
Object.assign(dict.en, {
  trait_event_title: '🔺 Special Traits', trait_kicker: 'FFM 26 • SPECIAL EVENT',
  trait_event_subtitle: '5 matches • 15 days • One player with a shooting trait',
  trait_match_finish: '🔺 Special Traits match complete!', trait_stage_reward: 'This match counted toward the event.',
  trait_progress: 'Progress: {done}/5 matches complete',
  trait_all_complete: 'All 5 matches complete! Open Career Mode and press the gift button to claim Roy Blaze (OVR 91) with the Clinical Finisher trait.',
  trait_expired_message: 'The Special Traits event has ended permanently. No new matches can be started.',
  trait_gift_waiting: '🔺 Traits Event Gift — complete all 5 matches to unlock', trait_gift_ready: '🔺 Claim the Traits Event player',
  trait_gift_claimed: '✅ Traits Event player claimed', trait_gift_ended: '⛔ Traits Event ended',
  trait_player_details: 'Trait: Clinical Finisher — +39% shot power & accuracy', trait_reward_title: '🔺 Special Traits Reward',
  trait_timer_active: '⏱️ Event is live', trait_timer_expired: '⛔ Event ended', trait_trait_label: 'Shooting trait'
});
Object.assign(dict.fr, {
  trait_event_title: '🔺 Traits spéciaux', trait_kicker: 'FFM 26 • ÉVÉNEMENT SPÉCIAL',
  trait_event_subtitle: '5 matchs • 15 jours • Un joueur avec un trait de tir',
  trait_match_finish: '🔺 Match des traits terminé !', trait_stage_reward: 'Ce match compte pour l’événement.',
  trait_progress: 'Progression : {done}/5 matchs terminés',
  trait_all_complete: 'Les 5 matchs sont terminés ! Ouvrez le mode carrière et appuyez sur le cadeau pour recevoir Roy Blaze (OVR 91) avec le trait Clinical Finisher.',
  trait_expired_message: 'L’événement Traits spéciaux est terminé définitivement.',
  trait_gift_waiting: '🔺 Cadeau Traits — terminez les 5 matchs pour le débloquer', trait_gift_ready: '🔺 Récupérer le joueur Traits',
  trait_gift_claimed: '✅ Joueur Traits récupéré', trait_gift_ended: '⛔ Événement Traits terminé',
  trait_player_details: 'Trait : Clinical Finisher — +39 % puissance et précision de tir', trait_reward_title: '🔺 Récompense Traits spéciaux',
  trait_timer_active: '⏱️ Événement en cours', trait_timer_expired: '⛔ Événement terminé', trait_trait_label: 'Trait de tir'
});

function ensureTraitEventState() {
  if (!state.ffmTraitEvent || typeof state.ffmTraitEvent !== 'object') state.ffmTraitEvent = {};
  const ev = state.ffmTraitEvent;
  // The 15-day clock starts the first time this save sees the event, and is stored in the save.
  if (!Number.isFinite(ev.startAt)) { ev.startAt = Date.now(); window.__traitEventStartedNow = true; }
  if (!Array.isArray(ev.completedStages)) ev.completedStages = [];
  ev.completedStages = [...new Set(ev.completedStages.map(Number).filter(n => n >= 1 && n <= 5))];
  for (const k of ['rewardPending', 'rewardClaimed', 'playerRewardAdded', 'permanentlyExpired']) if (typeof ev[k] !== 'boolean') ev[k] = false;
  if (typeof ev.currentStage !== 'number') ev.currentStage = 0;
  ev.expired = traitEventStatus() === 'expired';
  if (ev.completedStages.length === 5 && !ev.rewardClaimed && !ev.playerRewardAdded) ev.rewardPending = true;
  return ev;
}
function traitEventStatus() {
  const ev = state.ffmTraitEvent;
  if (ev && ev.permanentlyExpired === true) return 'expired';
  if (!ev || !Number.isFinite(ev.startAt)) return 'active';
  return Date.now() >= ev.startAt + TRAIT_EVENT_DURATION_MS ? 'expired' : 'active';
}
function traitEventRemainingMs() {
  const ev = state.ffmTraitEvent; if (!ev || !Number.isFinite(ev.startAt)) return TRAIT_EVENT_DURATION_MS;
  return Math.max(0, ev.startAt + TRAIT_EVENT_DURATION_MS - Date.now());
}
function updateTraitEventTimerUI() {
  const ev = ensureTraitEventState(), st = traitEventStatus();
  if (st === 'expired' && !ev.permanentlyExpired) { ev.permanentlyExpired = true; ev.expired = true; saveGame(); }
  const clock = document.getElementById('trait-countdown'), wrap = document.getElementById('trait-countdown-wrap'), status = document.getElementById('trait-timer-status');
  if (clock) clock.textContent = formatKickoffCountdown(traitEventRemainingMs());
  if (wrap) wrap.classList.toggle('expired', st === 'expired');
  if (status) status.textContent = tx(st === 'expired' ? 'trait_timer_expired' : 'trait_timer_active');
  if (window.ffmTraitPrevStatus !== st) { window.ffmTraitPrevStatus = st; renderTraitLadder(); renderTraitGiftButton(); }
}
function openTraitEvent() { showScreen('screen-trait-event'); renderTraitLadder(); updateTraitEventTimerUI(); }
function traitCardHTML(kind) {
  const label = tx('player_card_label');
  if (kind === 'track') {
    const unlocked = state.ffmTraitEvent.rewardPending || state.ffmTraitEvent.rewardClaimed || state.ffmTraitEvent.playerRewardAdded;
    return `<i class="trait-tri"></i><div class="event-track-card-label">${label}</div><div class="event-track-card-rating"><span>🔺</span><strong>${TRAIT_REWARD.rating}</strong><span>OVR</span></div><div class="event-track-card-name">${TRAIT_REWARD.name}</div><div class="event-track-card-meta">${tx('trait_player_details')}</div><div class="event-track-card-status">${tx(unlocked ? 'event_card_unlocked' : 'event_card_locked')}</div>`;
  }
  return `<i class="trait-tri big"></i><div style="font-size:12px;letter-spacing:1.5px;font-weight:900;color:#ffd8d8;">${label}</div><div style="display:flex;justify-content:space-between;align-items:flex-start;margin-top:12px;"><span style="font-size:38px;">🔺</span><span class="event-player-ovr">${TRAIT_REWARD.rating}<small style="display:block;font-size:10px;text-align:center;">OVR</small></span></div><div class="event-player-name">${TRAIT_REWARD.name}</div><div class="event-player-meta">${tx('trait_player_details')}</div>`;
}
function renderTraitLadder() {
  const ev = ensureTraitEventState(), ladder = document.getElementById('trait-ladder'); if (!ladder) return;
  ladder.innerHTML = '';
  const playable = traitEventStatus() === 'active';
  for (let n = 1; n <= 5; n++) {
    const done = ev.completedStages.includes(n), node = document.createElement('button');
    node.type = 'button'; node.className = 'event-node' + (done ? ' completed' : ''); node.disabled = !playable || done;
    node.title = done ? tx('event_stage_done') : tx('event_stage_label', { n });
    node.innerHTML = `<span class="node-number">${done ? '✓' : n}</span><span class="node-mini">${done ? tx('event_stage_done') : tx('event_stage_label', { n })}</span>`;
    node.onclick = () => playTraitStage(n);
    ladder.appendChild(node);
  }
  const card = document.createElement('div'); card.className = 'event-track-player-card'; card.innerHTML = traitCardHTML('track'); ladder.appendChild(card);
  const msg = document.getElementById('trait-progress-message');
  if (msg) msg.textContent = traitEventStatus() === 'expired' ? tx('trait_expired_message') : (ev.completedStages.length === 5 ? tx('trait_all_complete') : tx('trait_progress', { done: ev.completedStages.length }));
}
function playTraitStage(stage) {
  const ev = ensureTraitEventState();
  if (traitEventStatus() === 'expired') { alert(tx('trait_expired_message')); return; }
  if (ev.completedStages.includes(stage)) { alert(tx('event_already_done')); return; }
  ev.currentStage = stage;
  matchContext.type = 'trait'; matchContext.eventStage = stage; matchContext.myTeamId = 'team_1'; matchContext.oppTeamId = `team_${stage + 6}`;
  setupTacticsScreen();
}
// Called from startMatchSimulation when a 'trait' match ends. Returns false if the event is no longer playable.
function traitEventCompleteStage() {
  const ev = ensureTraitEventState();
  if (traitEventStatus() !== 'active') { alert(tx('trait_expired_message')); openTraitEvent(); return false; }
  const stage = Number(matchContext.eventStage || ev.currentStage || 0);
  if (stage >= 1 && stage <= 5 && !ev.completedStages.includes(stage)) ev.completedStages.push(stage);
  if (ev.completedStages.length === 5 && !ev.rewardClaimed && !ev.playerRewardAdded) ev.rewardPending = true;
  ev.currentStage = 0; saveGame(); renderTraitLadder(); renderTraitGiftButton();
  return true;
}
function renderTraitGiftButton() {
  const ev = ensureTraitEventState(), b = document.getElementById('career-trait-gift-button'); if (!b) return;
  const ended = traitEventStatus() === 'expired' && !ev.rewardPending && !ev.rewardClaimed && !ev.playerRewardAdded;
  b.classList.toggle('ready', ev.rewardPending && !ev.rewardClaimed); b.classList.toggle('claimed', ev.rewardClaimed);
  b.textContent = ev.rewardClaimed ? tx('trait_gift_claimed') : (ev.rewardPending ? tx('trait_gift_ready') : (ended ? tx('trait_gift_ended') : tx('trait_gift_waiting')));
  b.disabled = ended;
}
function claimTraitEventReward() {
  const ev = ensureTraitEventState();
  if (ev.rewardClaimed || ev.playerRewardAdded) { alert(tx('gift_already_claimed')); renderTraitGiftButton(); return; }
  if (!ev.rewardPending || ev.completedStages.length < 5) { alert(tx('gift_not_ready')); return; }
  const team = state.teams && state.teams.team_1;
  if (!team || !Array.isArray(team.players)) { alert(tx('gift_not_ready')); return; }
  if (!team.players.find(p => p && p.eventPlayerId === TRAIT_REWARD.id)) {
    if (!ffmCanAdd()) return;
    ffmAddPlayer({ name: TRAIT_REWARD.name, rating: TRAIT_REWARD.rating, contractMatches: 15, eventPlayer: true, eventPlayerId: TRAIT_REWARD.id, contractRenewable: false, trait: TRAIT_REWARD.trait });
  }
  ev.rewardPending = false; ev.rewardClaimed = true; ev.playerRewardAdded = true;
  saveGame(); renderTraitGiftButton(); openTraitRewardPopup();
}
function openTraitRewardPopup() {
  const c = document.getElementById('trait-player-card-popup');
  if (c) c.innerHTML = `<div class="event-player-card trait-card">${traitCardHTML('popup')}</div>`;
  document.getElementById('trait-reward-popup').style.display = 'flex';
}
function closeTraitRewardPopup() { document.getElementById('trait-reward-popup').style.display = 'none'; enterCareerMode(); }
