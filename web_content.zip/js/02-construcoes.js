/* Construcoes, arvores e locais especiais */
/* ---------- construcoes e arvores ---------- */
const buildings=[],trees=[];
/* ---------- fachadas procedurais (janelas acesas à noite) e geometria fundida ---------- */
const ANI=Math.min(4,renderer.capabilities.getMaxAnisotropy()),litMats=[];let litK=0;
const hexS=c=>'#'+new THREE.Color(c).getHexString();
const shade=(c,f)=>{const o=new THREE.Color(c);o.r=Math.min(1,o.r*f);o.g=Math.min(1,o.g*f);o.b=Math.min(1,o.b*f);return '#'+o.getHexString()};
const cvs=(W,H)=>{const c=document.createElement('canvas');c.width=W;c.height=H;return[c,c.getContext('2d')]};
const cTex=c=>{const t=new THREE.CanvasTexture(c);t.anisotropy=ANI;return t};
const litMat=(map,lit)=>{const m=new THREE.MeshLambertMaterial({map,color:0xffffff,emissive:0xffffff,emissiveMap:lit,emissiveIntensity:litK});litMats.push(m);return m};
const rnd=(a,b)=>a+Math.random()*(b-a),pick=a=>a[(Math.random()*a.length)|0];
const noise=(x,W,Hh,n,a)=>{for(let i=0;i<n;i++){x.fillStyle='rgba('+(Math.random()<.5?'0,0,0':'255,255,255')+','+(Math.random()*a).toFixed(3)+')';x.fillRect(Math.random()*W,Math.random()*Hh,1+Math.random()*2,1+Math.random()*2)}};
/* acumula varias caixas, cilindros e prismas num unico mesh (poucos draw calls por construcao) */
const _m4=new THREE.Matrix4(),_m5=new THREE.Matrix4(),_q=new THREE.Quaternion(),_eu=new THREE.Euler(),_p3=new THREE.Vector3(),_s3=new THREE.Vector3(),_v=new THREE.Vector3(),_n3=new THREE.Matrix3(),_gc=new Map();
const ni=g=>{let o=_gc.get(g);if(!o){o=g.index?g.toNonIndexed():g;_gc.set(g,o)}return o};
const boxU=new THREE.BoxGeometry(1,1,1),sphU=new THREE.SphereGeometry(1,7,5);
class Acc{
  constructor(rot=0){this.P=[];this.N=[];this.U=[];this.rot=rot}
  add(geo,sx,sy,sz,x,y,z,rx=0,ry=0,rz=0){
    const g=ni(geo),P=g.attributes.position,N=g.attributes.normal,U=g.attributes.uv;
    _eu.set(rx,ry,rz);_q.setFromEuler(_eu);_m4.compose(_p3.set(x,y,z),_q,_s3.set(sx,sy,sz));
    if(this.rot){_m5.makeRotationY(this.rot);_m4.premultiply(_m5)}
    _n3.getNormalMatrix(_m4);
    for(let i=0;i<P.count;i++){
      _v.fromBufferAttribute(P,i).applyMatrix4(_m4);this.P.push(_v.x,_v.y,_v.z);
      _v.fromBufferAttribute(N,i).applyMatrix3(_n3).normalize();this.N.push(_v.x,_v.y,_v.z);
      this.U.push(U?U.getX(i):0,U?U.getY(i):0);
    }
    return this;
  }
  box(w,h,d,x,y,z,rx,ry,rz){return this.add(boxU,w,h,d,x,y,z,rx,ry,rz)}
  mesh(mat){
    if(!this.P.length)return null;
    const g=new THREE.BufferGeometry();
    g.setAttribute('position',new THREE.Float32BufferAttribute(this.P,3));g.setAttribute('normal',new THREE.Float32BufferAttribute(this.N,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(this.U,2));
    return new THREE.Mesh(g,mat);
  }
}
const put=(g,...ms)=>{for(const m of ms)if(m)g.add(m)};
function facade(color,cols,rows,o){
  const W=cols<=2?64:128,Hh=rows<=2?64:rows<=4?128:rows<=8?256:512,[c,x]=cvs(W,Hh),[c2,y]=cvs(W,Hh),cw=W/cols,ch=Hh/rows,st=o.style||'win';
  x.fillStyle=hexS(color);x.fillRect(0,0,W,Hh);y.fillStyle='#000';y.fillRect(0,0,W,Hh);
  noise(x,W,Hh,W*Hh/50,.07);
  const glass=(gx,gy,gw,gh)=>{const g=x.createLinearGradient(gx,gy,gx+gw,gy+gh);g.addColorStop(0,'#40596e');g.addColorStop(.5,'#6f93ad');g.addColorStop(1,'#2b3c4b');return g};
  const bandH=Math.max(2,ch*.09);
  for(let r=0;r<rows;r++){
    const cy=r*ch,gr=o.ground&&r===rows-1;
    x.fillStyle=shade(color,.74);x.fillRect(0,cy+ch-bandH,W,bandH);x.fillStyle=shade(color,1.15);x.fillRect(0,cy+ch-bandH-1,W,1);
    for(let k=0;k<cols;k++){
      const cx=k*cw;
      if(gr){
        x.fillStyle='#2a2d30';x.fillRect(cx+cw*.08,cy+ch*.22,cw*.84,ch*.62);
        x.fillStyle=glass(cx,cy,cw,ch);x.fillRect(cx+cw*.12,cy+ch*.28,cw*.76,ch*.54);
        if(Math.random()<.7){y.fillStyle='#ffd9a0';y.fillRect(cx+cw*.14,cy+ch*.3,cw*.72,ch*.5)}
        if(o.ground==='door'&&k===((cols-1)>>1)){x.fillStyle='#f1ede2';x.fillRect(cx+cw*.26,cy+ch*.26,cw*.48,ch*.6);x.fillStyle='#3a2a20';x.fillRect(cx+cw*.3,cy+ch*.3,cw*.4,ch*.56);x.fillStyle='#4d6a82';x.fillRect(cx+cw*.34,cy+ch*.34,cw*.32,ch*.2);x.fillStyle='#caa24a';x.fillRect(cx+cw*.6,cy+ch*.6,Math.max(1,cw*.04),Math.max(1,ch*.05))}
        for(let q=0;q<6;q++){x.fillStyle=q%2?'#f2efe6':o.awn;x.fillRect(cx+cw*.04+q*cw*.92/6,cy+ch*.08,cw*.92/6+.5,ch*.13)}
        continue;
      }
      if(st==='glass'){
        x.fillStyle=glass(cx,cy+ch*.1,cw,ch*.72);x.fillRect(cx,cy+ch*.1,cw,ch*.72);
        if(Math.random()<.35){x.fillStyle='rgba(255,222,150,.9)';x.fillRect(cx+1,cy+ch*.12,cw-2,ch*.68);y.fillStyle='#ffc766';y.fillRect(cx+1,cy+ch*.12,cw-2,ch*.68)}
        x.fillStyle=shade(color,.55);x.fillRect(cx,cy+ch*.1,2,ch*.72);
        continue;
      }
      const wx=cx+cw*.2,wy=cy+ch*.18,ww=cw*.6,wh=ch*.58,lit=Math.random()<.32;
      const arch=e=>{x.beginPath();x.moveTo(wx-e,wy+wh+e);x.lineTo(wx-e,wy+ww/2);x.arc(wx+ww/2,wy+ww/2,ww/2+e,Math.PI,0);x.lineTo(wx+ww+e,wy+wh+e);x.closePath()};
      x.fillStyle=shade(color,1.3);
      if(o.arch){arch(2);x.fill();arch(0);x.fillStyle=lit?'#ffd98a':glass(wx,wy,ww,wh);x.fill()}
      else{x.fillRect(wx-2,wy-2,ww+4,wh+4);x.fillStyle=lit?'#ffd98a':glass(wx,wy,ww,wh);x.fillRect(wx,wy,ww,wh)}
      if(lit){y.fillStyle='#ffc766';y.fillRect(wx,wy+(o.arch?ww/2:0),ww,wh-(o.arch?ww/2:0))}
      else if(Math.random()<.35){x.fillStyle=pick(['#d8d2c0','#b9564a','#8fa6b8']);x.fillRect(wx,wy+(o.arch?ww/2:0),ww*(.3+Math.random()*.3),wh-(o.arch?ww/2:0))}
      x.fillStyle=shade(color,1.4);x.fillRect(wx+ww/2-1,wy+(o.arch?ww/2:0),2,wh-(o.arch?ww/2:0));x.fillRect(wx,wy+wh*.5,ww,1.5);
      x.fillStyle=shade(color,.55);x.fillRect(wx-3,wy+wh+2,ww+6,3);
      if(o.balc&&r%2===1&&r<rows-1){x.fillStyle=shade(color,.66);x.fillRect(cx+cw*.06,cy+ch*.82,cw*.88,ch*.06);x.fillStyle='rgba(25,25,25,.55)';for(let q=0;q<8;q++)x.fillRect(cx+cw*.09+q*cw*.105,cy+ch*.66,1.2,ch*.16)}
    }
  }
  const pw=Math.max(2,W*.05);x.fillStyle=shade(color,1.2);x.fillRect(0,0,pw,Hh);x.fillRect(W-pw,0,pw,Hh);x.fillStyle=shade(color,.7);x.fillRect(pw,0,1,Hh);x.fillRect(W-pw-1,0,1,Hh);
  return litMat(cTex(c),cTex(c2));
}
/* casas: texturas de frente e lados, com porta, janelas e venezianas */
const HC=[0xe6d9b8,0xd9b99b,0xc7d2c0,0xe3c5b0,0xbfc9d6],hCache={};
function houseTex(ci,kind,v,up){
  const key=ci+kind+v+(up?'u':'');if(hCache[key])return hCache[key];
  const color=HC[ci],W=128,Hh=64,[c,x]=cvs(W,Hh),[c2,y]=cvs(W,Hh);
  x.fillStyle=hexS(color);x.fillRect(0,0,W,Hh);y.fillStyle='#000';y.fillRect(0,0,W,Hh);
  if(v%2===0)for(let i=0;i<Hh;i+=4){x.fillStyle='rgba(0,0,0,.07)';x.fillRect(0,i,W,1);x.fillStyle='rgba(255,255,255,.06)';x.fillRect(0,i+1,W,1)}
  else noise(x,W,Hh,W*Hh/18,.08);
  if(!up){x.fillStyle='#8d887e';x.fillRect(0,Hh-6,W,6);x.fillStyle='#aaa598';x.fillRect(0,Hh-6,W,1)}
  x.fillStyle='rgba(0,0,0,.2)';x.fillRect(0,0,W,3);
  const shut=pick(['#3f6b4a','#3d5a80','#7a2e2a','#2f2f2f']);
  const win=(wx,wy,ww,wh)=>{
    x.fillStyle=shut;x.fillRect(wx-ww*.34,wy,ww*.3,wh);x.fillRect(wx+ww*1.04,wy,ww*.3,wh);
    x.fillStyle='rgba(0,0,0,.25)';for(let q=3;q<wh;q+=3){x.fillRect(wx-ww*.34,wy+q,ww*.3,1);x.fillRect(wx+ww*1.04,wy+q,ww*.3,1)}
    x.fillStyle='#f1ede2';x.fillRect(wx-2,wy-2,ww+4,wh+4);
    const lit=Math.random()<.4;
    x.fillStyle=lit?'#ffd98a':'#4d6a82';x.fillRect(wx,wy,ww,wh);
    if(lit){y.fillStyle='#ffc766';y.fillRect(wx,wy,ww,wh)}
    else{const g=x.createLinearGradient(wx,wy,wx+ww,wy+wh);g.addColorStop(0,'rgba(255,255,255,.4)');g.addColorStop(.55,'rgba(255,255,255,0)');x.fillStyle=g;x.fillRect(wx,wy,ww,wh)}
    x.fillStyle='#f1ede2';x.fillRect(wx+ww/2-1,wy,2,wh);x.fillRect(wx,wy+wh/2-1,ww,2);
    x.fillStyle='#7d786c';x.fillRect(wx-4,wy+wh+2,ww+8,3);
    x.fillStyle='#b98a5a';x.fillRect(wx-1,wy+wh+5,ww+2,3);x.fillStyle='#4a8a3a';for(let q=0;q<ww;q+=4)x.fillRect(wx+q,wy+wh+3,3,3);
  };
  const door=dx=>{const dw=16,dh=38,dy=(up?Hh-1:Hh-6)-dh;x.fillStyle='#f1ede2';x.fillRect(dx-2,dy-2,dw+4,dh+2);x.fillStyle=pick(['#5a3a24','#7a2e2a','#2f4a3a','#3d4a66']);x.fillRect(dx,dy,dw,dh);x.fillStyle='rgba(0,0,0,.22)';x.fillRect(dx+2,dy+16,dw-4,9);x.fillRect(dx+2,dy+28,dw-4,8);x.fillStyle='#4d6a82';x.fillRect(dx+3,dy+3,dw-6,10);x.fillStyle='#d9b24a';x.fillRect(dx+dw-4,dy+dh*.55,2,3);y.fillStyle='#ffc766';if(Math.random()<.5)y.fillRect(dx+3,dy+3,dw-6,10)};
  if(kind==='f'){
    if(v===0){win(14,16,20,22);door(56);win(94,16,20,22)}
    else if(v===1){door(16);win(52,16,24,22);win(92,16,20,22)}
    else if(v===2){win(14,16,22,22);win(50,16,22,22);door(92)}
    else{win(14,16,20,22);door(56);win(94,16,20,22)}
  }else{
    if(v===0){win(22,16,22,22);win(84,16,22,22)}else win(52,16,24,22);
  }
  const r={map:cTex(c),lit:cTex(c2),dx:kind==='f'?(v===1?-.3:v===2?.25:0):0};hCache[key]=r;return r;
}
function roofTex(color){
  const[c,x]=cvs(64,64);x.fillStyle=hexS(color);x.fillRect(0,0,64,64);
  for(let r=0;r<8;r++){x.fillStyle='rgba(0,0,0,.2)';x.fillRect(0,r*8+6,64,2);x.fillStyle='rgba(255,255,255,.09)';x.fillRect(0,r*8,64,1);for(let k=0;k<8;k++){x.fillStyle='rgba(0,0,0,.12)';x.fillRect(k*8+(r%2)*4,r*8,1,6)}}
  noise(x,64,64,200,.06);
  const t=cTex(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(3,3);return new THREE.MeshLambertMaterial({map:t});
}
const roofMats=[0x8c3b2a,0x4a4f58,0x6a4a38,0x7b5a4a].map(roofTex);
const gableG=(()=>{const sh=new THREE.Shape();sh.moveTo(-.5,0);sh.lineTo(.5,0);sh.lineTo(0,1);sh.closePath();const g=new THREE.ExtrudeGeometry(sh,{depth:1,bevelEnabled:false});g.translate(0,0,-.5);return g})();
const cylG=new THREE.CylinderGeometry(1,1,1,14),coneG=new THREE.ConeGeometry(1,1,14),spireG=new THREE.CylinderGeometry(0,1,1,4).rotateY(Math.PI/4);
const roofRed=new THREE.MeshLambertMaterial({color:0x8c3b2a}),roofSlate=new THREE.MeshLambertMaterial({color:0x4a4f58}),roofTin=new THREE.MeshLambertMaterial({color:0x8a9096}),
  darkM=new THREE.MeshLambertMaterial({color:0x2b2d28}),steelM=new THREE.MeshLambertMaterial({color:0x9aa0a4}),brickM=new THREE.MeshLambertMaterial({color:0x7a4a3a}),lampM=new THREE.MeshBasicMaterial({color:0xff4030}),
  trimM=new THREE.MeshLambertMaterial({color:0xe6e1d4}),bushM=new THREE.MeshLambertMaterial({color:0x3f7a3a}),
  PC=[0xc9b99a,0xb5aaa0,0xd2c3a3,0xb98f6f,0xa88a78,0x9aa6a8];
/* telhado de duas aguas com beiral: duas lajes inclinadas, cumeeira, oitoes e janela de sotao */
function gableRoof(R,T,D,span,ln,rh,y0){
  const a=Math.atan2(rh,span/2),Ls=Math.hypot(span/2,rh)+.5,th=.17,ca=Math.cos(a),sa=Math.sin(a);
  for(const s of[1,-1]){
    const cx=s*(ca*(Ls/2-.08)+sa*th/2),cy=rh-sa*(Ls/2-.08)+ca*th/2;
    R.box(Ls,th,ln+.9,cx,y0+cy,0,0,0,-s*a);
  }
  R.box(.4,.24,ln+.95,0,y0+rh+.1,0);
  for(const s of[1,-1]){D.box(.8,.95,.1,0,y0+rh*.36,s*(ln/2+.03));T.box(1,1.15,.08,0,y0+rh*.36,s*(ln/2+.02))}
}
const BT={
  predio(){
    const cols=2+((Math.random()*3)|0),colsD=2+((Math.random()*3)|0),rows=2+((Math.random()*4)|0)+(Math.random()<.25?1:0),w=cols*3.1,d=colsD*3.1,h=rows*3.2,color=pick(PC),balc=Math.random()<.45,awn=pick(['#a33a2a','#2f6b4a','#2f4f80','#b8892a']),
      fz=facade(color,cols,rows,{ground:'door',awn,balc}),fb=facade(color,cols,rows,{ground:'glass',awn,balc}),fx=facade(color,colsD,rows,{ground:'glass',awn,balc}),
      top=new THREE.MeshLambertMaterial({color:0x4a4640}),trim=new THREE.MeshLambertMaterial({color:new THREE.Color(color).lerp(new THREE.Color(0xffffff),.5)}),g=new THREE.Group();
    const body=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),[fx,fx,top,top,fz,fb]);body.position.y=h/2;g.add(body);
    const T=new Acc(),D=new Acc(),S=new Acc(),y0=h+1.12,hx=w/2-1.5,hz=d/2-1.5;
    T.box(w+.5,.55,d+.5,0,h-.05,0);T.box(w+.2,1,d+.2,0,h+.55,0);D.box(w-.5,.1,d-.5,0,h+1.07,0);T.box(2.4,.18,1,0,.09,d/2+.5);
    const bxp=rnd(-hx,hx)*.5,bzp=rnd(-hz,hz)*.5;T.box(2.2,1.8,2.2,bxp,y0+.9,bzp);D.box(.8,1.2,.06,bxp,y0+.6,bzp+1.13);T.box(2.5,.14,2.5,bxp,y0+1.85,bzp);
    for(let i=0,n=2+((Math.random()*2)|0);i<n;i++){const x=rnd(-hx,hx),z=rnd(-hz,hz);if(Math.abs(x-bxp)<2.2&&Math.abs(z-bzp)<2.2)continue;S.box(1.3,.9,1.1,x,y0+.45,z);D.box(.9,.05,.7,x,y0+.93,z)}
    if(Math.random()<.45){const x=rnd(-hx,hx)*.8,z=rnd(-hz,hz)*.8;if(Math.abs(x-bxp)>2.2||Math.abs(z-bzp)>2.2){S.add(cylG,.9,1.3,.9,x,y0+1.95,z);S.add(coneG,.95,.5,.95,x,y0+2.85,z);for(const sx of[-1,1])for(const sz of[-1,1])S.box(.1,1.3,.1,x+sx*.6,y0+.65,z+sz*.6)}}
    if(Math.random()<.5){const x=rnd(-hx,hx),z=rnd(-hz,hz);S.box(.08,3.4,.08,x,y0+1.7,z);S.box(1.3,.06,.06,x,y0+3,z);S.box(.9,.06,.06,x,y0+2.5,z)}
    S.box(.14,h,.14,w/2+.1,h/2,d/2+.1);S.box(.14,h,.14,-w/2-.1,h/2,d/2+.1);
    put(g,T.mesh(trim),D.mesh(darkM),S.mesh(steelM));
    return{g,w,d,h:h+1.1,hp:70,mats:[fz,fb,fx,trim],color};
  },
  casa(){
    /* tres tipos: 0 terrea, 1 com area (varanda larga + garagem coberta), 2 sobrado de dois andares com sacada */
    const ty=Math.random(),kd=ty<.3?0:ty<.62?1:2,
      w=rnd(5,8)+(kd===2?.4:0),d=rnd(5,7.5),h1=rnd(3,3.5),h2=kd===2?rnd(2.9,3.2):0,h=h1+h2,rh=rnd(2,3),ci=(Math.random()*HC.length)|0,color=HC[ci],fv=(Math.random()*3)|0,sv=(Math.random()*2)|0,
      F=houseTex(ci,'f',fv),S1=houseTex(ci,'s',sv),S2=houseTex(ci,'s',1-sv),mF=litMat(F.map,F.lit),mS=litMat(S1.map,S1.lit),mB=litMat(S2.map,S2.lit),mT=new THREE.MeshLambertMaterial({color}),
      g=new THREE.Group(),al=Math.random()<.5,rm=pick(roofMats),mats=[mF,mS,mB,mT];
    const body=new THREE.Mesh(new THREE.BoxGeometry(w,h1,d),[mS,mS,mT,mT,mF,mB]);body.position.y=h1/2;g.add(body);
    if(kd===2){
      const U=houseTex(ci,'f',3,1),US1=houseTex(ci,'s',sv,1),US2=houseTex(ci,'s',1-sv,1),uF=litMat(U.map,U.lit),uS=litMat(US1.map,US1.lit),uB=litMat(US2.map,US2.lit);
      const up=new THREE.Mesh(new THREE.BoxGeometry(w,h2,d),[uS,uS,mT,mT,uF,uB]);up.position.y=h1+h2/2;g.add(up);mats.push(uF,uS,uB);
    }
    const rot=al?Math.PI/2:0,span=al?d:w,ln=al?w:d,R=new Acc(rot),Tr=new Acc(rot),Dr=new Acc(rot);
    gableRoof(R,Tr,Dr,span,ln,rh,h);
    const prism=new THREE.Mesh(gableG,mT);prism.scale.set(span-.04,rh-.04,ln);prism.position.y=h;prism.rotation.y=rot;g.add(prism);
    const Br=new Acc(rot),T=new Acc(),P=new Acc(),Gd=new Acc(),px=kd===2?(F.dx||0)*w:F.dx*w;
    {const cxm=span*.2*(Math.random()<.5?1:-1),yr=h+rh*(1-Math.abs(cxm)/(span/2)),zl=rnd(-.2,.2)*ln,yt=yr+1.3;
     Br.box(.8,yt-(yr-.6),.8,cxm,(yt+yr-.6)/2,zl);Tr.box(1.05,.16,1.05,cxm,yt+.08,zl)}
    T.box(2.3,.2,.9,px,.1,d/2+.45);T.box(1.1,.05,2.6,px,.03,d/2+2.2);
    let fz=3.4,bz=.7;
    if(kd===1){
      /* varanda larga na frente: laje, cobertura e pilares */
      T.box(w+.4,.12,2.3,0,.06,d/2+1.15);P.box(w+.6,.14,2.6,0,2.9,d/2+1.2,-.07,0,0);
      const np=Math.max(2,Math.round(w/1.9));for(let i=0;i<=np;i++){const x=-w/2+.15+(w-.3)*i/np;T.box(.18,2.85,.18,x,1.43,d/2+2.3)}
      /* area lateral coberta (garagem): telhado sobre pilares, piso de concreto */
      const sx=Math.random()<.5?-1:1,cw=3.4,cd=d*.85,cx=sx*(w/2+cw/2+.05);
      P.box(cw+.3,.14,cd+.3,cx,2.75,0,0,0,sx*.05);T.box(cw,.06,cd,cx,.03,0);
      for(const qz of[-1,1])T.box(.16,2.7,.16,sx*(w/2+cw-.1),1.35,qz*(cd/2-.1));
      fz=3.9;bz=2.7;
    }else{
      T.box(.2,2.6,.2,px-1.1,1.4,d/2+1.7);T.box(.2,2.6,.2,px+1.1,1.4,d/2+1.7);P.box(2.8,.14,1.8,px,2.8,d/2+.95,-.1,0,0);
    }
    if(kd===2){
      /* sacada no andar de cima: laje, guarda-corpo com balaustres e mao-francesa */
      const by=h1,bw=3.2,bd=1.15;
      T.box(bw,.16,bd,0,by+.08,d/2+bd/2);T.box(w+.12,.2,d+.12,0,by,0);
      T.box(bw,.07,.07,0,by+1,d/2+bd);T.box(.07,.07,bd,-bw/2,by+1,d/2+bd/2);T.box(.07,.07,bd,bw/2,by+1,d/2+bd/2);
      for(let i=0;i<=8;i++)T.box(.05,.82,.05,-bw/2+bw*i/8,by+.57,d/2+bd);
      for(const sx of[-1,1])T.box(.12,.32,.9,sx*1.3,by-.17,d/2+.5);
    }
    if(Math.random()<.55){for(let x=-w/2-1;x<=w/2+1;x+=.55){if(Math.abs(x-px)<.8)continue;T.box(.1,.85,.06,x,.43,d/2+fz)}T.box(w+2,.07,.05,0,.3,d/2+fz);T.box(w+2,.07,.05,0,.7,d/2+fz)}
    for(const sx of[-1,1])if(Math.random()<.7)Gd.add(sphU,rnd(.55,.85),rnd(.45,.65),rnd(.55,.85),sx*(w/2-.2),.4,d/2+bz);
    if(Math.random()<.4)Gd.add(sphU,.9,.8,.9,rnd(-1,1)*w*.3,.55,-d/2-.9);
    put(g,R.mesh(rm),P.mesh(rm),Tr.mesh(trimM),T.mesh(trimM),Dr.mesh(darkM),Br.mesh(brickM),Gd.mesh(bushM));
    return{g,w,d,h:h+rh,hp:kd===2?54:38,mats,color};
  },
  torre(){
    const cols=3,colsD=2+((Math.random()*2)|0),rA=5+((Math.random()*3)|0),rB=3+((Math.random()*2)|0),CH=3.4,w=cols*3,d=colsD*3,wU=(cols-1)*3,dU=(colsD-1)*3,hA=rA*CH,hB=rB*CH,
      color=pick([0x8fa3b5,0x9aa7a0,0xb3b8be,0xa5a095]),color2=pick([0x5f7a92,0x4f6f80,0x6a7f8c]),awn=pick(['#a33a2a','#2f6b4a','#2f4f80','#b8892a']),
      fzA=facade(color,cols,rA,{ground:'door',awn}),fbA=facade(color,cols,rA,{ground:'glass',awn}),fxA=facade(color,colsD,rA,{ground:'glass',awn}),
      fzB=facade(color2,cols-1,rB,{style:'glass'}),fxB=facade(color2,Math.max(1,colsD-1),rB,{style:'glass'}),
      top=new THREE.MeshLambertMaterial({color:0x4a4640}),trim=new THREE.MeshLambertMaterial({color:new THREE.Color(color).lerp(new THREE.Color(0xffffff),.4)}),g=new THREE.Group();
    const A=new THREE.Mesh(new THREE.BoxGeometry(w,hA,d),[fxA,fxA,top,top,fzA,fbA]),B=new THREE.Mesh(new THREE.BoxGeometry(wU,hB,dU),[fxB,fxB,top,top,fzB,fzB]);
    A.position.y=hA/2;B.position.y=hA+hB/2;g.add(A,B);
    const T=new Acc(),S=new Acc(),D=new Acc(),yt=hA+hB;
    T.box(w+.5,.6,d+.5,0,hA,0);T.box(wU+.4,.6,dU+.4,0,yt,0);T.box(wU*.55,2.2,dU*.55+.6,0,yt+1.3,0);T.box(2.8,.2,1,0,.1,d/2+.5);T.box(w*.6,.25,1.5,0,3.4,d/2+.75);
    for(const sx of[-1,1])T.box(.2,3.3,.2,sx*w*.3,1.65,d/2+1.4);
    D.box(w+.2,.3,d+.2,0,hA+.55,0);D.box(wU-.4,.1,dU-.4,0,yt+.35,0);
    S.add(cylG,.12,9,.12,0,yt+2.4+4.5,0);S.box(1.4,.07,.07,0,yt+2.4+6,0);S.box(1.1,.07,.07,0,yt+2.4+7.5,0);
    S.box(1.6,.9,1.2,w*.25,hA+.9,d*.25);S.box(1.6,.9,1.2,-w*.25,hA+.9,-d*.25);
    put(g,T.mesh(trim),D.mesh(darkM),S.mesh(steelM),bx(.5,.5,.5,lampM,0,yt+2.4+9,0));
    return{g,w,d,h:yt+2.5,hp:150,mats:[fzA,fbA,fxA,fzB,fxB,trim],color};
  },
  galpao(){
    const w=rnd(16,22),d=rnd(8,11),h=rnd(5,6.5),color=pick([0x9ca3a8,0xb0a58f,0x8f9a8b,0xa8a29a]),g=new THREE.Group();
    const mk=kind=>{
      const W=kind==='l'?256:128,Hh=64,[c,x]=cvs(W,Hh);x.fillStyle=hexS(color);x.fillRect(0,0,W,Hh);
      for(let i=0;i<W;i+=3){x.fillStyle='rgba(0,0,0,.13)';x.fillRect(i,0,1,Hh);x.fillStyle='rgba(255,255,255,.08)';x.fillRect(i+1,0,1,Hh)}
      noise(x,W,Hh,W*Hh/40,.06);x.fillStyle=shade(color,.62);x.fillRect(0,Hh-7,W,7);
      if(kind==='l'){
        for(let k=0;k<6;k++){const wx=10+k*42;if(wx>72&&wx<172)continue;x.fillStyle='#e9e6dc';x.fillRect(wx-1,9,27,15);x.fillStyle='#4a6075';x.fillRect(wx,10,25,13);x.fillStyle='rgba(255,255,255,.3)';x.fillRect(wx,10,25,3);x.fillStyle='#e9e6dc';x.fillRect(wx+12,10,1.5,13)}
        x.fillStyle='#e9e6dc';x.fillRect(86,14,84,50);x.fillStyle='#3b4045';x.fillRect(88,16,80,46);for(let q=0;q<9;q++){x.fillStyle='rgba(255,255,255,.12)';x.fillRect(88,18+q*5,80,1)}
        for(let q=0;q<10;q++){x.fillStyle=q%2?'#d9b72c':'#25272a';x.fillRect(88+q*8,56,8,6)}
        x.fillStyle='#ffd34a';x.fillRect(124,10,8,3);
      }else{
        x.fillStyle='#e9e6dc';x.fillRect(46,26,32,38);x.fillStyle='#3b4045';x.fillRect(48,28,28,36);for(let q=0;q<7;q++){x.fillStyle='rgba(255,255,255,.12)';x.fillRect(48,30+q*5,28,1)}
        x.fillStyle='#e9e6dc';x.fillRect(14,10,22,13);x.fillRect(90,10,22,13);x.fillStyle='#4a6075';x.fillRect(15,11,20,11);x.fillRect(91,11,20,11);
      }
      const t=cTex(c);return new THREE.MeshLambertMaterial({map:t});
    };
    const mL=mk('l'),mE=mk('e'),top=new THREE.MeshLambertMaterial({color:0x6e6a62});
    const body=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),[mE,mE,top,top,mL,mL]);body.position.y=h/2;g.add(body);
    const r=new THREE.Mesh(gableG,roofTin);r.scale.set(d+.8,2.4,w+.8);r.rotation.y=Math.PI/2;r.position.y=h;g.add(r);
    const S=new Acc(),D=new Acc();
    for(const x of[-w/3,0,w/3])S.box(1.4,.5,1.1,x,h+2.4+.12,0);
    S.box(.2,h,.2,w/2+.12,h/2,d/2+.12);S.box(.2,h,.2,-w/2-.12,h/2,-d/2-.12);
    D.box(w+.5,.3,.2,0,h+.1,d/2+.05);D.box(w+.5,.3,.2,0,h+.1,-d/2-.05);
    put(g,S.mesh(steelM),D.mesh(darkM));
    return{g,w,d,h:h+2.4,hp:110,mats:[mL,mE,top],color};
  },
  silo(){
    const r=rnd(2.2,3.2),h=rnd(12,18),two=Math.random()<.5,color=pick([0xc3c6c2,0xb7b9b4,0xd0cfc6]),m=new THREE.MeshLambertMaterial({color}),g=new THREE.Group(),S=new Acc(),C=new Acc();
    const one=(x,hh)=>{
      const c=new THREE.Mesh(cylG,m);c.scale.set(r,hh,r);c.position.set(x,hh/2,0);g.add(c);
      S.add(coneG,r*1.06,r*.8,r*1.06,x,hh+r*.4,0);S.box(.22,hh,.12,x+r+.04,hh/2,0);
      for(let k=1;k<5;k++)C.add(cylG,r*1.025,.14,r*1.025,x,hh*k/5,0);
      C.add(cylG,r*1.12,.7,r*1.12,x,.35,0);S.add(cylG,.35,.5,.35,x,hh+r*.8+.2,0);
      for(let k=1;k<hh;k+=1.1)S.box(.6,.05,.05,x+r+.04,k,0);
    };
    if(two){one(-r*1.1,h);one(r*1.1,h*.82);S.box(r*2.2,.18,.5,0,h*.78,0);S.add(cylG,.18,h*.78,.18,0,h*.39,r*.9)}else one(0,h);
    put(g,S.mesh(steelM),C.mesh(trimM));
    return{g,w:two?r*4.4:r*2.2,d:r*2.2,h:h+r*.8,hp:85,mats:[m],color,stilt:false};
  },
  agua(){
    const h=rnd(11,14),r=2.5,m=new THREE.MeshLambertMaterial({map:(()=>{
      const[c,x]=cvs(128,64);x.fillStyle=pick(['#cfd3d6','#b9c6cf','#d8d2c0']);x.fillRect(0,0,128,64);
      for(let i=0;i<128;i+=16){x.fillStyle='rgba(0,0,0,.12)';x.fillRect(i,0,1,64)}for(let j=0;j<64;j+=16){x.fillStyle='rgba(0,0,0,.14)';x.fillRect(0,j,128,1)}
      x.fillStyle='#2f6f9c';x.fillRect(0,22,128,20);x.fillStyle='#f1f6f9';x.beginPath();x.moveTo(64,24);x.bezierCurveTo(56,34,56,40,64,40);x.bezierCurveTo(72,40,72,34,64,24);x.fill();
      x.fillStyle='rgba(120,70,30,.22)';for(let i=0;i<12;i++)x.fillRect(Math.random()*128,Math.random()*64,1+Math.random()*2,6+Math.random()*16);
      return cTex(c);
    })()}),g=new THREE.Group(),S=new Acc(),a=2.05;
    const tk=new THREE.Mesh(cylG,m);tk.scale.set(r,3.4,r);tk.position.y=h+1.9;g.add(tk);
    S.add(cylG,r*.75,.6,r*.75,0,h+.1,0);S.add(coneG,r*1.08,1.7,r*1.08,0,h+4.6,0);S.add(cylG,.12,.9,.12,0,h+5.8,0);S.add(cylG,r*1.18,.14,r*1.18,0,h-.15,0);
    for(const sx of[-1,1])for(const sz of[-1,1])S.box(.34,h,.34,sx*a,h/2,sz*a);
    for(let k=1;k<=3;k++){
      const y0=h*(k-1)/3,y1=h*k/3,L=Math.hypot(2*a,y1-y0),ang=Math.atan2(y1-y0,2*a),ym=(y0+y1)/2;
      for(const sz of[-1,1]){S.box(2*a,.16,.16,0,y1,sz*a);S.box(L,.1,.1,0,ym,sz*a,0,0,ang);S.box(L,.1,.1,0,ym,sz*a,0,0,-ang)}
      for(const sx of[-1,1]){S.box(.16,.16,2*a,sx*a,y1,0);S.box(.1,.1,L,sx*a,ym,0,ang,0,0);S.box(.1,.1,L,sx*a,ym,0,-ang,0,0)}
    }
    S.add(cylG,.18,h-.4,.18,0,(h-.4)/2,0);
    S.box(.07,h+.4,.07,-.3,(h+.4)/2,a+.3);S.box(.07,h+.4,.07,.3,(h+.4)/2,a+.3);
    for(let k=.6;k<h;k+=.55)S.box(.6,.05,.05,0,k,a+.3);
    const lamp=new THREE.Mesh(sphU,lampM);lamp.scale.setScalar(.25);lamp.position.y=h+6.4;g.add(lamp);
    put(g,S.mesh(steelM));
    return{g,w:6,d:6,h:h+6.4,hp:45,mats:[m],color:0xb9bdc0,stilt:true};
  },
  igreja(){
    const w=6.5,d=11,h=5.5,tw=3.2,th=13,color=0xe3d9c3,fN=facade(color,4,1,{arch:true}),fF=facade(color,2,1,{arch:true}),fT=facade(color,1,3,{arch:true}),top=new THREE.MeshLambertMaterial({color:0x4a4640}),g=new THREE.Group(),tz=-d/2+tw/2-.2;
    const nave=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),[fN,fN,top,top,fF,fF]);nave.position.y=h/2;
    const tower=new THREE.Mesh(new THREE.BoxGeometry(tw,th,tw),[fT,fT,top,top,fT,fT]);tower.position.set(0,th/2,tz);
    const r=new THREE.Mesh(gableG,roofSlate),sp=new THREE.Mesh(spireG,roofSlate),T=new Acc(),D=new Acc(),S=new Acc();
    r.scale.set(w+.8,3.4,d+.8);r.position.y=h;sp.scale.set(tw*.78,5.5,tw*.78);sp.position.set(0,th+2.75,tz);
    for(let k=0;k<4;k++)for(const sx of[-1,1])T.box(.5,3.6,.6,sx*(w/2+.2),1.8,-d/2+1.8+k*(d-3.6)/3);
    T.box(2.3,3.1,.12,0,1.55,d/2+.03);T.box(3.2,.3,1.3,0,.15,d/2+.6);T.box(2.6,.3,.8,0,.45,d/2+.3);T.box(tw+.4,.5,tw+.4,0,th,tz);
    D.box(1.6,2.6,.12,0,1.3,d/2+.07);D.add(cylG,.6,.1,.6,0,4.35,d/2+.04,Math.PI/2,0,0);D.box(.9,2,.1,0,th*.85,tz+tw/2+.03);D.box(.9,2,.1,0,th*.85,tz-tw/2-.03);D.box(.1,2,.9,tw/2+.03,th*.85,tz);D.box(.1,2,.9,-tw/2-.03,th*.85,tz);
    S.box(.15,1.6,.15,0,th+6.3,tz);S.box(.9,.15,.15,0,th+6.6,tz);
    g.add(nave,tower,r,sp);put(g,T.mesh(trimM),D.mesh(darkM),S.mesh(steelM));
    return{g,w,d,h:th,hp:110,mats:[fN,fF,fT],color};
  }
};
/* ---------- construcoes dos locais especiais: container, guindaste, bunker, radar, tenda, muro, torre de controle ---------- */
const lm=c=>new THREE.MeshLambertMaterial({color:c}),ctCols=[0xb5432f,0x2f5f8f,0x3f7f4a,0xc99a2e,0x7a7f84,0x8a4f2a],ribM=lm(0x2b2d30),concD=lm(0x6e6e69);
BT.container=function(){
  const rot=Math.random()<.5,n=1+((Math.random()*3)|0),m=lm(pick(ctCols)),g=new THREE.Group(),inn=new THREE.Group(),R=new Acc();
  for(let k=0;k<n;k++){const y=1.3+k*2.6,b=new THREE.Mesh(boxU,m);b.scale.set(2.5,2.5,12);b.position.set(0,y,0);inn.add(b);for(let q=-5.5;q<=5.5;q+=.9)R.box(2.62,2.3,.12,0,y,q)}
  put(inn,R.mesh(ribM));inn.rotation.y=rot?Math.PI/2:0;g.add(inn);
  return{g,w:rot?12:2.6,d:rot?2.6:12,h:2.6*n,hp:55+n*15,mats:[m],color:m.color.getHex(),stilt:false};
};
BT.guindaste=function(){
  const g=new THREE.Group(),S=new Acc(),H=22,L=30,a=3.4,m=lm(pick([0xc96a1f,0xd8b02a,0xb23a2c]));
  for(const sx of[-1,1])for(const sz of[-1,1])S.box(.7,H,.7,sx*a,H/2,sz*a);
  S.box(2*a+.7,.7,.7,0,H,a);S.box(2*a+.7,.7,.7,0,H,-a);S.box(.7,.7,2*a,a,H,0);S.box(.7,.7,2*a,-a,H,0);
  S.box(.6,.9,L,a,H+.7,L/2-a);S.box(.6,.9,L,-a,H+.7,L/2-a);S.box(2*a,.9,.6,0,H+.7,L-a);
  for(const sz of[-1,1])S.box(.25,Math.hypot(2*a,H),.25,0,H/2,sz*a,0,0,Math.atan2(2*a,H));
  S.box(3.2,2.2,3.6,0,H+2,-a-.5);
  g.add(S.mesh(m));g.rotation.y=((Math.random()*4)|0)*Math.PI/2;
  return{g,w:2*a+.7,d:2*a+.7,h:H+3,hp:70,mats:[m],color:0xc96a1f,stilt:true};
};
BT.bunker=function(){
  const g=new THREE.Group(),C=new Acc(),D=new Acc(),w=9,d=6,h=3,m=lm(0x8c8b84);
  C.box(w,h,d,0,h/2,0);C.box(w+.6,.4,d+.6,0,h+.2,0);
  D.box(w*.55,.7,.3,0,2.1,d/2+.02);D.box(w*.55,.7,.3,0,2.1,-d/2-.02);
  put(g,C.mesh(m),D.mesh(ribM));
  return{g,w,d,h:h+.4,hp:240,mats:[m],color:0x8c8b84,stilt:false};
};
BT.radar=function(){
  const g=new THREE.Group(),S=new Acc(),m=lm(0xb9bec2);
  S.box(3.6,2,3.6,0,1,0);S.box(.5,10,.5,0,7,0);
  for(const sx of[-1,1])for(const sz of[-1,1])S.box(.2,10,.2,sx*1.2,5,sz*1.2);
  S.add(cylG,3.4,.25,3.4,0,11,0,.55,0,0);S.box(.2,2.2,.2,0,12.4,0);
  g.add(S.mesh(m));
  return{g,w:4,d:4,h:13,hp:55,mats:[m],color:0xb9bec2,stilt:true};
};
BT.tenda=function(){
  const g=new THREE.Group(),w=7,d=4.4,h=3,m=lm(0x6b7248),r=new THREE.Mesh(gableG,m);
  r.scale.set(d,h,w);r.rotation.y=Math.PI/2;r.position.y=.1;g.add(r);
  return{g,w,d,h:h+.1,hp:30,mats:[m],color:0x6b7248,stilt:false};
};
BT.muro=function(o){
  const rot=!!(o&&o.rot),w=12,d=1.2,h=2.8,m=lm(0x9a9a94),g=new THREE.Group(),b=new THREE.Mesh(boxU,m),cap=new THREE.Mesh(boxU,concD);
  b.scale.set(w,h,d);b.position.y=h/2;cap.scale.set(w+.1,.3,d+.35);cap.position.y=h+.15;g.add(b,cap);
  if(rot)g.rotation.y=Math.PI/2;
  return{g,w:rot?d:w,d:rot?w:d,h:h+.3,hp:60,mats:[m],color:0x9a9a94,stilt:false};
};
BT.torreCtrl=function(){
  const g=new THREE.Group(),S=new Acc(),G2=new Acc(),m=lm(0xd6d3c8),gl=lm(0x35566e);
  S.box(3.2,12,3.2,0,6,0);S.box(7.4,.5,7.4,0,15.2,0);S.box(.2,3,.2,0,17.2,0);
  G2.box(6.4,3,6.4,0,13.5,0);
  g.add(S.mesh(m),G2.mesh(gl));
  return{g,w:6.4,d:6.4,h:17.6,hp:90,mats:[m],color:0xd6d3c8,stilt:false};
};
function pickType(zone){
  const W=zone?{galpao:3,silo:2,agua:1,predio:2,torre:1,casa:1}:{casa:5,predio:3,torre:1,igreja:1,agua:1,galpao:1};
  let t=0;for(const k in W)t+=W[k];let r=Math.random()*t;for(const k in W){r-=W[k];if(r<=0)return k}return'casa';
}
function tryBuilding(x,z,type,opt){
  if(Math.hypot(x,z)<14||Math.hypot(x,z)>HALF-20)return false;
  if(getH(x,z)<-1||roadAt(x,z)>.08)return false;
  const o=BT[type](opt),w=o.w,d=o.d;const rej=()=>{for(const m of o.mats){const i=litMats.indexOf(m);if(i>=0)litMats.splice(i,1);m.dispose&&m.dispose()}return false};let lo=1e9,hi=-1e9;
  for(const sx of[-1,0,1])for(const sz of[-1,0,1]){const h=getH(x+sx*w/2,z+sz*d/2);lo=Math.min(lo,h);hi=Math.max(hi,h)}
  if(hi-lo>3||lo<-1)return rej();
  for(const sx of[-1,0,1])for(const sz of[-1,0,1])if(roadAt(x+sx*(w/2+1.5),z+sz*(d/2+1.5))>.08)return rej();
  if(opt&&opt.tight){const gp=opt.gap===undefined?1:opt.gap;for(const q of buildings)if(Math.abs(q.x-x)<(q.w+w)/2+gp&&Math.abs(q.z-z)<(q.d+d)/2+gp)return rej()}
  else{const r=Math.max(w,d)/2+2.5;
  for(const q of buildings)if(Math.hypot(q.x-x,q.z-z)<r+Math.max(q.w,q.d)/2+2.5)return rej()}
  o.g.position.set(x,lo-1,z);o.g.traverse(m=>{if(m.isMesh)m.castShadow=m.receiveShadow=true});scene.add(o.g);
  buildings.push({m:o.g,x,z,w,d,h:o.h,y:lo-1,hp:o.hp,hp0:o.hp,base:o.hp*.55,base0:o.hp*.55,stilt:!!o.stilt,color:o.color,mats:o.mats,type});return true;
}
function scorch(b,f){for(const m of b.mats)m.color.multiplyScalar(f)}
/* ---------- arvores altas: geometria fundida com cor por vertice (1 draw call por arvore) ---------- */
const treeMat=new THREE.MeshLambertMaterial({vertexColors:true}),blobG=new THREE.IcosahedronGeometry(1,1),trunkT=new THREE.CylinderGeometry(.6,1,1,7),coneT=new THREE.ConeGeometry(1,1,9);
function buildTree(parts){
  const P=[],N=[],C=[],c0=new THREE.Color(),c1=new THREE.Color(),cc=new THREE.Color();
  for(const o of parts){
    const g=ni(o.g),pos=g.attributes.position,nor=g.attributes.normal;
    _eu.set(o.rx||0,o.ry||0,o.rz||0);_q.setFromEuler(_eu);_m4.compose(_p3.set(o.x,o.y,o.z),_q,_s3.set(o.sx,o.sy,o.sz));_n3.getNormalMatrix(_m4);
    c0.set(o.c0);c1.set(o.c1);const tone=1+(Math.random()-.5)*(o.j||0);
    for(let i=0;i<pos.count;i++){
      _v.fromBufferAttribute(pos,i).applyMatrix4(_m4);P.push(_v.x,_v.y,_v.z);
      _v.fromBufferAttribute(nor,i).applyMatrix3(_n3).normalize();N.push(_v.x,_v.y,_v.z);
      const t=o.flat?.5:clamp(.5+.55*_v.y,0,1);
      cc.copy(c0).lerp(c1,t).multiplyScalar(tone);C.push(cc.r,cc.g,cc.b);
    }
  }
  const geo=new THREE.BufferGeometry();
  geo.setAttribute('position',new THREE.Float32BufferAttribute(P,3));geo.setAttribute('normal',new THREE.Float32BufferAttribute(N,3));geo.setAttribute('color',new THREE.Float32BufferAttribute(C,3));
  geo.computeBoundingBox();geo.userData.H=geo.boundingBox.max.y;return geo;
}
const TRK=[0x3a2718,0x6e4c32];
const GREENS=[[0x1c5428,0x62a644],[0x27652f,0x78b84c],[0x22593a,0x5aa65e],[0x356a22,0x8cbc3e]],FLOWER=[[0xb88a10,0xf7da3c],[0xb4467a,0xf4a8cc]];
/* frondosa: tronco alto com galhos e copa de varias esferas */
function oakGeo(pal){
  const Ht=rnd(4.6,5.8),pr=[{g:trunkT,sx:.5,sy:Ht,sz:.5,x:0,y:Ht/2,z:0,c0:TRK[0],c1:TRK[1],flat:1,j:.2}];
  for(let i=0;i<2;i++){const a=Math.random()*6.28;pr.push({g:trunkT,sx:.17,sy:2.6,sz:.17,x:Math.cos(a)*.7,y:Ht*.85,z:Math.sin(a)*.7,rz:Math.cos(a)*-.8,rx:Math.sin(a)*.8,c0:TRK[0],c1:TRK[1],flat:1})}
  const cy=Ht+2.9,R=rnd(3.4,4);
  pr.push({g:blobG,sx:R,sy:R*.86,sz:R,x:0,y:cy,z:0,c0:pal[0],c1:pal[1],j:.14});
  const n=5+((Math.random()*3)|0);
  for(let i=0;i<n;i++){const a=i/n*6.28+Math.random()*.7,r=rnd(2.1,3),q=rnd(2.1,2.9);pr.push({g:blobG,sx:q,sy:q*.82,sz:q,x:Math.cos(a)*r,y:cy+rnd(-1.3,1.2),z:Math.sin(a)*r,c0:pal[0],c1:pal[1],j:.2})}
  pr.push({g:blobG,sx:2.5,sy:2.1,sz:2.5,x:rnd(-.6,.6),y:cy+R*.8,z:rnd(-.6,.6),c0:pal[0],c1:pal[1],j:.14});
  return buildTree(pr);
}
/* copa oval e alta (cipreste) */
function ovalGeo(pal){
  const Ht=rnd(2.6,3.4),pr=[{g:trunkT,sx:.42,sy:Ht+1.6,sz:.42,x:0,y:(Ht+1.6)/2,z:0,c0:TRK[0],c1:TRK[1],flat:1,j:.2}],lean=rnd(-.25,.25);
  const L=[[Ht+2.6,2.3,3.2],[Ht+5.2,2.55,3.6],[Ht+8,2.4,3.5],[Ht+10.4,1.8,2.9],[Ht+12.3,1,2]];
  L.forEach((o,i)=>pr.push({g:blobG,sx:o[1],sy:o[2],sz:o[1],x:lean*i+rnd(-.2,.2),y:o[0],z:rnd(-.2,.2),c0:pal[0],c1:pal[1],j:.16}));
  return buildTree(pr);
}
/* pinheiro: cones empilhados */
function pineGeo(){
  const pr=[{g:trunkT,sx:.3,sy:8,sz:.3,x:0,y:4,z:0,c0:TRK[0],c1:TRK[1],flat:1}],n=5+((Math.random()*2)|0),pal=pick([[0x16402a,0x3c8450],[0x1d4a30,0x4a9060]]);
  for(let i=0;i<n;i++){const k=i/(n-1),r=3.3-k*2.3,hh=3.4-k*.8;pr.push({g:coneT,sx:r,sy:hh,sz:r,x:rnd(-.1,.1),y:3.3+i*(8.2/n)+hh/2,z:rnd(-.1,.1),c0:pal[0],c1:pal[1],j:.14})}
  return buildTree(pr);
}
const treeGeos=[];
for(const pal of GREENS){treeGeos.push({g:oakGeo(pal),w:5},{g:oakGeo(pal),w:5},{g:ovalGeo(pal),w:3})}
for(const pal of FLOWER)treeGeos.push({g:oakGeo(pal),w:.9});
treeGeos.push({g:pineGeo(),w:5},{g:pineGeo(),w:5},{g:pineGeo(),w:4});
const treeW=treeGeos.reduce((a,o)=>a+o.w,0);
function addTree(x,z){
  let r=Math.random()*treeW,geo=treeGeos[0].g;for(const o of treeGeos){r-=o.w;if(r<=0){geo=o.g;break}}
  const m=new THREE.Mesh(geo,treeMat),sc=.95+Math.random()*.6;
  m.position.set(x,getH(x,z),z);m.scale.set(sc*rnd(.92,1.08),sc,sc*rnd(.92,1.08));m.rotation.y=Math.random()*6;
  m.scale.z=m.scale.x;scene.add(m);trees.push({g:m,x,z,H:geo.userData.H*sc});
}
function killTree(t){scene.remove(t.g);trees.splice(trees.indexOf(t),1);const px=t.cx===undefined?t.x:t.cx,pz=t.cz===undefined?t.z:t.cz;for(let i=0;i<4;i++)puff(new THREE.Vector3(px,getH(px,pz)+(t.st===2?1:(t.H||9)*.5),pz),i?0x5a3d28:0x3d7a3a,1.6,4,.9,2)}
/* ---------- mobiliario urbano: postes de rua e bancos de praca ---------- */
const props=[],poleM=new THREE.MeshLambertMaterial({color:0x34383c}),bulbM=new THREE.MeshLambertMaterial({color:0xd9d4c0,emissive:0xffd890,emissiveIntensity:litK}),junkM=new THREE.MeshLambertMaterial({color:0x3a3d40}),
  woodMs=[0x8a5a34,0x6f4a2c,0x9a6a3c].map(c=>new THREE.MeshLambertMaterial({color:c}));
litMats.push(bulbM); /* a lampada acende a noite junto com as janelas */
const lampGeo=(()=>{
  const A=new Acc(),B=new Acc();
  A.box(.55,.4,.55,0,.2,0);A.box(.36,.3,.36,0,.55,0);A.add(cylG,.1,5.6,.1,0,3.1,0);A.add(cylG,.07,1.5,.07,.62,5.85,0,0,0,Math.PI/2);A.box(.8,.12,.4,1.3,5.86,0);A.box(.7,.05,.32,1.3,5.95,0);
  B.box(.55,.07,.28,1.3,5.77,0);
  return[A.mesh(poleM).geometry,B.mesh(bulbM).geometry];
})();
const benchGeo=(()=>{
  const W=new Acc(),I=new Acc();
  for(const z of[-.16,-.03,.1,.23])W.box(1.9,.045,.11,0,.46,z);
  for(const o of[[.66,-.3],[.78,-.32],[.9,-.34]])W.box(1.9,.1,.035,0,o[0],o[1],-.14);
  for(const sx of[-.92,.92]){I.box(.06,.46,.06,sx,.23,.24);I.box(.06,.95,.06,sx,.48,-.3);I.box(.06,.05,.62,sx,.45,-.03);I.box(.07,.05,.5,sx,.7,-.02);I.box(.06,.5,.06,sx,.25,-.28)}
  I.box(1.9,.04,.04,0,.2,.24);
  return[W.mesh(woodMs[0]).geometry,I.mesh(poleM).geometry];
})();
function addLamp(x,z,dx,dz){
  const g=new THREE.Group(),a=new THREE.Mesh(lampGeo[0],poleM),b=new THREE.Mesh(lampGeo[1],bulbM);a.castShadow=true;g.add(a,b);
  g.position.set(x,getH(x,z),z);g.rotation.y=Math.atan2(-dz,dx);scene.add(g);props.push({g,x,z,k:'lamp'});
}
function addBench(x,z,dx,dz){
  const g=new THREE.Group(),a=new THREE.Mesh(benchGeo[0],pick(woodMs)),b=new THREE.Mesh(benchGeo[1],poleM);a.castShadow=b.castShadow=true;g.add(a,b);
  g.position.set(x,getH(x,z),z);g.rotation.y=Math.atan2(dx,dz);scene.add(g);props.push({g,x,z,k:'bench'});
}
function killProp(q){
  scene.remove(q.g);const i=props.indexOf(q);if(i>=0)props.splice(i,1);
  puff(new THREE.Vector3(q.x,getH(q.x,q.z)+1.5,q.z),0x8a8478,1.3,3,.8,1.5);
  for(let k=0;k<3;k++){const m=new THREE.Mesh(dg,junkM),s=.25+Math.random()*.3;m.scale.set(s,s*(q.k==='lamp'?3:1),s);m.position.set(q.x,getH(q.x,q.z)+1+Math.random()*3,q.z);scene.add(m);debris.push({m,s,t:8,v:new THREE.Vector3((Math.random()-.5)*8,3+Math.random()*5,(Math.random()-.5)*8)})}
}
function propSpot(x,z,r){
  if(Math.hypot(x,z)<14||Math.hypot(x,z)>HALF-20)return false;
  if(getH(x,z)<.4||Math.abs(getH(x+1.5,z)-getH(x-1.5,z))>1.2||Math.abs(getH(x,z+1.5)-getH(x,z-1.5))>1.2)return false;
  if(roadAt(x,z)>.06)return false;
  for(const b of buildings)if(Math.abs(x-b.x)<b.w/2+r&&Math.abs(z-b.z)<b.d/2+r)return false;
  for(const q of props)if(Math.hypot(q.x-x,q.z-z)<r)return false;
  return true;
}
const clusters=[];
const MS=SIZE/500;
for(let n=0;n<22;n++){
  for(let k=0;k<200;k++){
    const a=Math.random()*6.28,r=(n?60+Math.random()*170:70+Math.random()*40)*MS,cx=Math.cos(a)*r,cz=Math.sin(a)*r;
    if(getH(cx,cz)<=0)continue;clusters.push({x:cx,z:cz,zone:n%2});break;
  }
}
/* ---------- locais especiais: base militar, porto e aeroporto (terreno aplainado antes das estradas) ---------- */
function flat(cx,cz,hx,hz,h,fall){
  const i0=Math.max(0,Math.floor((cx-hx-fall+HALF)/CELL)),i1=Math.min(N,Math.ceil((cx+hx+fall+HALF)/CELL)),j0=Math.max(0,Math.floor((cz-hz-fall+HALF)/CELL)),j1=Math.min(N,Math.ceil((cz+hz+fall+HALF)/CELL));
  for(let j=j0;j<=j1;j++)for(let i=i0;i<=i1;i++){
    const x=i*CELL-HALF,z=j*CELL-HALF,d=Math.hypot(Math.max(0,Math.abs(x-cx)-hx),Math.max(0,Math.abs(z-cz)-hz));
    if(d>=fall)continue;const t=1-d/fall,sv=t*t*(3-2*t),k=j*(N+1)+i;H[k]=H[k]*(1-sv)+h*sv;
  }
}
const specials=[],pierJobs=[];
function areaStat(cx,cz,hx,hz){let lo=1e9,hi=-1e9;for(let a=-1;a<=1;a+=.5)for(let b=-1;b<=1;b+=.5){const h=getH(cx+a*hx,cz+b*hz);lo=Math.min(lo,h);hi=Math.max(hi,h)}return[lo,hi]}
function findSpot(hx,hz,rmin,rmax,maxRange,clear){
  for(let k=0;k<1800;k++){
    const a=Math.random()*6.28,r=(rmin+Math.random()*(rmax-rmin))*HALF,x=Math.cos(a)*r,z=Math.sin(a)*r,[lo,hi]=areaStat(x,z,hx,hz);
    if(lo<1.2||hi-lo>maxRange)continue;
    if(specials.some(q=>Math.hypot(q.x-x,q.z-z)<280)||clusters.some(c=>Math.hypot(c.x-x,c.z-z)<clear))continue;
    return{x,z,h:clamp((lo+hi)/2,3,8)};
  }
  return null;
}
function findPort(){
  for(let k=0;k<500;k++){
    const a=Math.random()*6.28,ox=Math.cos(a),oz=Math.sin(a);let sr=null;
    for(let r=HALF*.97;r>HALF*.25;r-=4)if(getH(ox*r,oz*r)>1.5){sr=r;break}
    if(sr===null)continue;
    const px=ox*(sr-26),pz=oz*(sr-26),[lo,hi]=areaStat(px,pz,20,20);
    if(hi-lo>10||getH(ox*(sr-60),oz*(sr-60))<1.5||getH(ox*(sr+60),oz*(sr+60))>WATER)continue;
    if(specials.some(q=>Math.hypot(q.x-px,q.z-pz)<280)||clusters.some(c=>Math.hypot(c.x-px,c.z-pz)<100))continue;
    return{x:px,z:pz,ox,oz};
  }
  return null;
}
for(let n=0;n<2;n++){const q=findSpot(44,44,.25,.7,9,130);if(q){flat(q.x,q.z,44,44,q.h,24);specials.push({type:'base',x:q.x,z:q.z,h:q.h});clusters.push({x:q.x,z:q.z,zone:2})}}
{const q=findSpot(95,28,.1,.65,20,150);if(q){flat(q.x,q.z,95,28,q.h,28);specials.push({type:'aero',x:q.x,z:q.z,h:q.h});clusters.push({x:q.x,z:q.z,zone:2})}}
for(let n=0;n<2;n++){const q=findPort();if(q){flat(q.x,q.z,18,18,2.4,22);specials.push({type:'port',x:q.x,z:q.z,h:2.4,ox:q.ox,oz:q.oz});clusters.push({x:q.x,z:q.z,zone:2})}}
/* estradas ligando as cidades e o ponto de partida */
clusters.sort((p,q)=>Math.atan2(p.z,p.x)-Math.atan2(q.z,q.x));
for(let i=0;i<clusters.length;i++){const p=clusters[i],q=clusters[(i+1)%clusters.length];if(p!==q&&Math.hypot(p.x-q.x,p.z-q.z)<300*MS)makeRoad(p,q)}
for(const c of clusters.slice().sort((p,q)=>Math.hypot(p.x,p.z)-Math.hypot(q.x,q.z)).slice(0,3))makeRoad({x:0,z:0},c);
/* garante algumas pontes: acha travessias de agua funda e liga por estrada reta */
function nearestCluster(x,z){let b=null,bd=1e9;for(const c of clusters){const d=Math.hypot(c.x-x,c.z-z);if(d<bd){bd=d;b=c}}return b}
{let made=0;
 for(let k=0;k<3000&&made<5;k++){
  const a=Math.random()*6.28,r=Math.random()*HALF*.75,x=Math.cos(a)*r,z=Math.sin(a)*r;
  if(getH(x,z)<2)continue;
  const dir=Math.random()*6.28,dx=Math.cos(dir),dz=Math.sin(dir);
  let wet=0,deep=false,s0=0,s1=0,ok=false;
  for(let q=0;q<=240;q+=3){
    const h=getH(x+dx*q,z+dz*q);
    if(h<WATER+1.3){if(!wet)s0=q;wet++;if(h<WATER-.4)deep=true}
    else if(wet){if(deep&&wet>=5&&wet<=30){ok=true;s1=q}break}
  }
  if(!ok)continue;
  const A={x:x+dx*(s0-60),z:z+dz*(s0-60)},B={x:x+dx*(s1+60),z:z+dz*(s1+60)};
  if(getH(A.x,A.z)<1.5||getH(B.x,B.z)<1.5||Math.hypot(A.x,A.z)>HALF-60||Math.hypot(B.x,B.z)>HALF-60)continue;
  makeRoad(A,B,0);
  const cA=nearestCluster(A.x,A.z),cB=nearestCluster(B.x,B.z);
  if(cA)makeRoad(cA,A);if(cB&&cB!==cA)makeRoad(cB,B);
  made++;
 }
}
/* cidades (zona 0) e area industrial (zona 1) */
for(const c of clusters){if(c.zone===2)continue;let cnt=0;for(let q=0;q<80&&cnt<9;q++){if(tryBuilding(c.x+(Math.random()-.5)*60,c.z+(Math.random()-.5)*60,pickType(c.zone)))cnt++}}
/* casas e galpoes na beira das estradas */
for(const pts of roads){let acc=0;for(let i=1;i<pts.length;i++){acc+=1.5;if(acc<50)continue;acc=0;
  const p=pts[i],q=pts[i-1],tx=p.x-q.x,tz=p.z-q.z,tl=Math.hypot(tx,tz)||1,side=Math.random()<.5?-1:1,off=side*(9+Math.random()*4);
  if(Math.random()<.5)tryBuilding(p.x-tz/tl*off,p.z+tx/tl*off,Math.random()<.88?'casa':'galpao')}}
/* conteudo dos locais especiais */
function paintRunway(cx,cz,hl,hw){
  const i0=Math.max(0,Math.floor((cx-hl-6+HALF)/CELL)),i1=Math.min(N,Math.ceil((cx+hl+6+HALF)/CELL)),j0=Math.max(0,Math.floor((cz-hw-6+HALF)/CELL)),j1=Math.min(N,Math.ceil((cz+hw+6+HALF)/CELL));
  for(let j=j0;j<=j1;j++)for(let i=i0;i<=i1;i++){const e=Math.max(Math.abs(i*CELL-HALF-cx)-hl,Math.abs(j*CELL-HALF-cz)-hw),k=j*(N+1)+i;if(e<3)Rd[k]=Math.max(Rd[k],clamp(1-e/3,0,1))}
}
function buildSpecials(){
  const whiteM=new THREE.MeshBasicMaterial({color:0xece8d8});
  for(const sp of specials){
    const cx=sp.x,cz=sp.z;
    if(sp.type==='base'){
      const S=42;
      for(let side=0;side<4;side++)for(let u=-36;u<=36;u+=12){
        if(side===0&&u===0)continue;
        tryBuilding(side<2?cx+u:cx+(side===2?S:-S),side<2?cz+(side===0?S:-S):cz+u,'muro',{rot:side>1,tight:true,gap:.3});
      }
      for(const[sx,sz]of[[-1,-1],[1,-1],[1,1],[-1,1]])tryBuilding(cx+sx*32,cz+sz*32,'bunker',{tight:true,gap:1});
      tryBuilding(cx+4,cz-6,'radar',{tight:true});
      for(let q=0;q<5;q++)tryBuilding(cx-22+q*11,cz+12+(q%2)*8,'tenda',{tight:true,gap:1.5});
      tryBuilding(cx-17,cz-24,'galpao',{tight:true});tryBuilding(cx+17,cz-24,'galpao',{tight:true});
    }else if(sp.type==='port'){
      const ox=sp.ox,oz=sp.oz,px=-oz,pz=ox;let cnt=0;
      for(let q=0;q<140&&cnt<24;q++){const u=rnd(-17,17),v=rnd(-17,6);if(tryBuilding(cx+px*u+ox*v,cz+pz*u+oz*v,'container',{tight:true,gap:1.1}))cnt++}
      for(const u of[-9,9])tryBuilding(cx+px*u+ox*14,cz+pz*u+oz*14,'guindaste',{tight:true});
      for(const u of[-14,14])tryBuilding(cx+px*u-ox*22,cz+pz*u-oz*22,'galpao',{tight:true});
      pierJobs.push({x0:cx+ox*8,z0:cz+oz*8,x1:cx+ox*100,z1:cz+oz*100,h:sp.h});
    }else if(sp.type==='aero'){
      paintRunway(cx,cz,85,8);
      const B=new Acc();
      for(let q=-70;q<=70;q+=20)B.box(9,.05,.7,cx+q,sp.h+.08,cz);
      for(const e of[-1,1])for(let u=-6;u<=6;u+=2)B.box(5,.05,.7,cx+e*79,sp.h+.08,cz+u);
      const dm=B.mesh(whiteM);if(dm)scene.add(dm);
      for(let q=0;q<4;q++)tryBuilding(cx-52+q*35,cz-25,'galpao',{tight:true});
      tryBuilding(cx+20,cz+23,'torreCtrl',{tight:true});
      for(let q=0;q<3;q++)tryBuilding(cx-50+q*14,cz+23,'tenda',{tight:true,gap:1.5});
    }
  }
}
buildSpecials();
/* fazendas isoladas */
for(let k=0;k<60;k++)tryBuilding((Math.random()-.5)*430*MS,(Math.random()-.5)*430*MS,pick(['casa','casa','casa','silo','galpao','agua']));
refresh(0,N,0,N);
/* postes ao longo das ruas, com banco de praca em alguns trechos */
{let tot=0;for(const pts of roads)tot+=pts.length*1.5;
 const gap=Math.max(32,tot/150);
 for(const pts of roads){let acc=gap*Math.random(),side=Math.random()<.5?1:-1;
  for(let i=1;i<pts.length;i++){
   acc+=1.5;if(acc<gap)continue;acc=0;side=-side;
   const p=pts[i],q=pts[i-1],tx=p.x-q.x,tz=p.z-q.z,tl=Math.hypot(tx,tz)||1,nx=-tz/tl,nz=tx/tl,x=p.x+nx*side*5.6,z=p.z+nz*side*5.6;
   if(!propSpot(x,z,1.8))continue;
   addLamp(x,z,-nx*side,-nz*side);
   if(Math.random()<.22){const r=pts[Math.min(pts.length-1,i+3)],bx=r.x+nx*side*6.3,bz=r.z+nz*side*6.3;if(propSpot(bx,bz,2.2))addBench(bx,bz,-nx*side,-nz*side)}
  }}
 /* pracinha em cada cidade: poste no meio e tres bancos em volta */
 for(const c of clusters){if(c.zone)continue;
  for(let k=0;k<20;k++){
   const cx=c.x+(Math.random()-.5)*46,cz=c.z+(Math.random()-.5)*46;if(!propSpot(cx,cz,5))continue;
   addLamp(cx,cz,1,0);const a0=Math.random()*6.28;
   for(let i=0;i<3;i++){const a=a0+i*2.094,bx=cx+Math.cos(a)*3.4,bz=cz+Math.sin(a)*3.4;if(propSpot(bx,bz,1.6))addBench(bx,bz,-Math.cos(a),-Math.sin(a))}
   break;
  }}
}
for(let k=0;k<4500&&trees.length<700;k++){
  const x=(Math.random()-.5)*440*MS,z=(Math.random()-.5)*440*MS;
  const bm=biomeAt(x,z);if(Math.random()<bm.d*.92||Math.random()<bm.s*.55)continue;
  if(getH(x,z)>-1&&Math.hypot(x,z)>14&&roadAt(x,z)<.06&&buildings.every(b=>Math.hypot(b.x-x,b.z-z)>Math.max(b.w,b.d)/2+5)&&props.every(q=>Math.hypot(q.x-x,q.z-z)>3.4))addTree(x,z);
}

