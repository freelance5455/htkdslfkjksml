/* =============================================================
   LAMPION POS · js/escpos.js
   Jembatan cetak ke aplikasi Android open-escpos-print-service
   -------------------------------------------------------------
   Repo : https://github.com/farminos/open-escpos-print-service
   App  : com.farminos.print  (activity .PrintActivity)

   KONTRAK INTENT (dari README + AndroidManifest.xml app tsb):
     scheme    : print-intent
     S.content : Base64URL( gzip( JSON array of HTML strings ) )
     bentuk    : intent://#Intent;scheme=print-intent;S.content=...;end

   PrintActivity.kt membaca extra itu, gunzip, JSONArray, lalu
   merender tiap string HTML jadi bitmap dan MENCETAK LANGSUNG ke
   printer default — tanpa layar pemilihan printer (seamless).

   Catatan: tidak ada dependensi baru. gzip memakai CompressionStream
   bawaan browser/WebView, base64 memakai btoa (dipotong per blok).
   Format payload sudah diverifikasi lewat tools/selftest-escpos.ps1.
   ============================================================= */
(function (global) {
  'use strict';

  var SCHEME = 'print-intent';

  /* ---------- helper ---------- */
  function esc(s) { return global.LPHP.esc(s); }
  function money(n) { return global.LPHP.money(n); }

  /** true bila berjalan di Android/WebView yang bisa membuka intent:// */
  function available() {
    var ua = String((global.navigator && global.navigator.userAgent) || '');
    return /Android/i.test(ua) && typeof global.btoa === 'function';
  }

  /** true bila CompressionStream('gzip') tersedia (WebView >= 80) */
  function gzipSupported() {
    return !!(global.CompressionStream && global.Response && global.Blob);
  }

  /* =============================================================
     ENCODER: gzip + base64url
     ============================================================= */

  /** String -> bytes -> gzip. Mengembalikan Uint8Array. */
  function gzipText(str) {
    var input = new global.TextEncoder().encode(str);
    if (!gzipSupported()) {
      return Promise.reject(new Error(
        'Perangkat ini tidak mendukung kompresi gzip (WebView terlalu lama).'));
    }
    var cs = new global.CompressionStream('gzip');
    var stream = new global.Blob([input]).stream().pipeThrough(cs);
    return new global.Response(stream).arrayBuffer().then(function (buf) {
      return new Uint8Array(buf);
    });
  }

  /**
   * Uint8Array -> base64 STANDAR (dengan padding '=').
   *
   * PENTING: PrintActivity.kt memakai android.util.Base64.decode() yang
   * memakai alfabet standar '+/'. Base64 varian url-safe ('-_') DITOLAK
   * oleh decoder tersebut, jadi padding '=' justru WAJIB dipertahankan.
   * Dipotong per blok supaya payload besar tidak melampaui batas
   * argumen String.fromCharCode.
   */
  function toBase64(bytes) {
    var CHUNK = 0x8000;
    var parts = [];
    for (var i = 0; i < bytes.length; i += CHUNK) {
      parts.push(String.fromCharCode.apply(null, bytes.subarray(i, i + CHUNK)));
    }
    return global.btoa(parts.join(''));
  }

  /**
   * Susun URL intent dari daftar dokumen HTML.
   * @param {string[]} htmlPages
   * @returns {Promise<string>} intent://#Intent;scheme=print-intent;...;end
   */
  function intentUrl(htmlPages) {
    var pages = Array.isArray(htmlPages) ? htmlPages : [String(htmlPages)];
    return gzipText(JSON.stringify(pages)).then(function (bytes) {
      return 'intent://#Intent;scheme=' + SCHEME +
        ';S.content=' + toBase64(bytes) + ';end';
    });
  }

  /**
   * Kirim intent ke aplikasi printer.
   * WebView Android menyerahkan navigasi `intent://` ke app yang cocok.
   *
   * JANGAN menambahkan query/cache-buster setelah ';end'. Parser intent
   * Android memecah string berdasarkan ';' dan berhenti pada token 'end';
   * menambahkan '?t=...' membuat token 'end' tidak lagi cocok sehingga
   * timestamp ikut terbaca sebagai bagian S.content -> decoder gagal
   * ('cannot decode url' / 'invalid distances set').
   * @returns {Promise<{ok:boolean, handoff:boolean}>}
   */
  function sendIntent(url) {
    return new Promise(function (resolve) {
      var handedOff = false;
      var done = false;

      function markHandoff() { handedOff = true; }

      /* bila app printer mengambil alih, halaman jadi tidak terlihat */
      global.document.addEventListener('visibilitychange', markHandoff, { once: true });
      global.addEventListener('pagehide', markHandoff, { once: true });
      global.addEventListener('blur', markHandoff, { once: true });

      try {
        /* URL dipakai apa adanya supaya diakhiri ';end' */
        global.location.href = url;
      } catch (e) {
        done = true;
        resolve({ ok: false, handoff: false, error: e });
        return;
      }

      global.setTimeout(function () {
        if (done) { return; }
        done = true;
        resolve({ ok: handedOff, handoff: handedOff });
      }, 1200);
    });
  }

  /* =============================================================
     HTML STRUK
     ============================================================= */

  /** Kolom teks: 58mm = 32 kolom, 80mm = 48 kolom (sama dgn receiptText) */
  function cols(width) { return (String(width) === '80') ? 48 : 32; }

  /* -------------------------------------------------------------
     SKALA FONT — kenapa px tetap, bukan vw
     -------------------------------------------------------------
     App printer merender HTML ini lewat com.izettle:html2bitmap:
         renderWidthPx = (width_cm - marginL - marginR) / 2.54 * dpi
     Untuk 58mm @203dpi margin 0 -> ~464px.

     vw TIDAK bisa dipakai: 1vw = 1% lebar viewport WebView internal
     html2bitmap, dan lebar itu tidak dapat dipastikan sama dengan
     renderWidthPx. Akibatnya font berbasis vw tampak sangat kecil.
     Ukuran px tetap = rasio tetap antara jumlah kolom dan lebar kertas,
     karena bitmap hasil render diskalakan ke lebar fisik kertas.
     ------------------------------------------------------------- */

  /** Lebar render default (px) = 58mm @203dpi tanpa margin */
  var RENDER_W_PX = 464;

  /** Rasio lebar karakter monospace terhadap font-size.
      0.6 umum, tapi font fallback WebView bisa berbeda -> sebab itu
      nilai final bisa dikalibrasi lewat Pengaturan (printer_font_px). */
  var MONO_ADVANCE = 0.60;

  /** Ukuran font default (px) agar `c` kolom pas selebar kertas */
  function defaultFontPx(width) {
    return Math.round(RENDER_W_PX / cols(width) / MONO_ADVANCE);
  }

  /**
   * Ukuran font efektif: pakai pengaturan bila ada, jika tidak default.
   * @param {string} width '58' | '80'
   * @param {Object} store settings toko
   */
  function fontPx(width, store) {
    var v = store ? Number(store.printer_font_px) : 0;
    if (v > 0) { return v; }
    return defaultFontPx(width);
  }

  /**
   * CSS inti: margin nol + font monospace ukuran tetap.
   * Reset @page diambil dari rekomendasi README app printer.
   *
   * @param {string} width '58' | '80'
   * @param {Object} [store] settings toko (untuk printer_font_px)
   */
  function baseCss(width, store) {
    var px = fontPx(width, store);
    return '' +
      '@page{margin:0mm 0mm 0mm 0mm}' +
      'html,body{margin:0;padding:0}' +
      '@media all{body{width:100%;margin:0}}' +
      'body{font-family:monospace;' +
      'font-size:' + px + 'px;' +
      'line-height:1.3;color:#000;background:#fff;' +
      '-webkit-print-color-adjust:exact;print-color-adjust:exact}' +
      /* tanpa width:Nch — pembungkusan diserahkan white-space:pre saja
         agar kesalahan metrik font tidak memotong/melipat kolom kanan */
      'pre{margin:0;font-family:inherit;font-size:inherit;' +
      'white-space:pre;overflow:visible}';
  }

  /** Bangun baris teks struk (isi <pre>) — padanan receiptText() di pos.js */
  function receiptLines(o, store, width, opts) {
    var COLS = cols(width);
    var L = [];
    opts = opts || {};
    function line(ch) {
      var s = ''; while (s.length < COLS) { s += (ch || '-'); } L.push(s);
    }
    /* potong teks panjang menjadi beberapa baris selebar kertas */
    function wrap(text) {
      text = String(text);
      var out = [];
      if (text === '') { out.push(''); return out; }
      while (text.length > COLS) { out.push(text.slice(0, COLS)); text = text.slice(COLS); }
      out.push(text);
      return out;
    }
    /* teks tengah; bila lebih panjang dari kertas -> dipotong per baris */
    function center(t) {
      wrap(t).forEach(function (seg) {
        var pad = Math.floor((COLS - seg.length) / 2);
        L.push(new Array(pad + 1).join(' ') + seg);
      });
    }
    /* baris dua kolom: label kiri, nilai kanan.
       Bila tidak muat, label dipecah ke baris berikutnya dan nilai
       tetap rata kanan pada baris terakhir -> tidak melebihi kertas. */
    function lr(left, right) {
      left = String(left); right = String(right);

      /* nilai sendiri sudah lebih lebar dari kertas -> baris terpisah */
      if (right.length >= COLS) {
        wrap(left).forEach(function (seg) { L.push(seg); });
        L.push(right);
        return;
      }

      var room = COLS - right.length - 1;   /* sisakan minimal 1 spasi */
      var segs = wrap(left);
      for (var i = 0; i + 1 < segs.length; i++) { L.push(segs[i]); }

      var last = segs[segs.length - 1];
      if (last.length > room) {
        /* potong label agar nilai tetap bisa rata kanan */
        L.push(last.slice(0, Math.max(0, room)));
        last = last.slice(Math.max(0, room));
        while (last.length > COLS) { L.push(last.slice(0, COLS)); last = last.slice(COLS); }
        if (last !== '') { L.push(last); }
      }
      var space = COLS - last.length - right.length;
      if (space < 1) { L.push(last + ' ' + right); return; }
      L.push(last + new Array(space + 1).join(' ') + right);
    }
    /* potong nama item panjang agar perataan struk tidak rusak */
    function wrapItem(name) {
      name = String(name);
      var out = [];
      while (name.length > COLS) { out.push(name.slice(0, COLS)); name = name.slice(COLS); }
      out.push(name);
      return out;
    }

    /* Banner REPRINT di paling atas (untuk cetak ulang dari laporan) */
    if (opts.reprint) {
      line('=');
      center('** REPRINT **');
      line('=');
    }

    center(String(store.store_name || 'Lampion Resto'));
    if (store.store_address) { center(String(store.store_address)); }
    if (store.store_phone) { center(String(store.store_phone)); }
    line('=');
    lr('No', String(o.order_number));
    lr('Tipe', String(o.order_type_label || o.order_type || ''));
    if (o.customer_name) { lr('Pelanggan', String(o.customer_name)); }
    lr('Kasir', String(o.cashier_name || ''));
    lr('Waktu', String(o.created_label || ''));
    line('-');

    (o.items || []).forEach(function (it) {
      wrapItem(it.item_name).forEach(function (t) { L.push(t); });
      lr('  ' + it.qty + ' x ' + money(it.price), money(it.subtotal));
    });

    line('-');
    lr('Subtotal', money(o.subtotal));
    if (Number(o.discount) > 0) { lr('Diskon', '-' + money(o.discount)); }
    /* Pajak 0 -> baris pajak dihilangkan dari struk */
    if (Number(o.tax) > 0) { lr('Pajak', money(o.tax)); }
    lr('TOTAL', money(o.total));
    line('-');
    lr('Bayar (' + String(o.payment_label || '') + ')',
      money(o.received === null ? o.total : o.received));
    lr('Kembali', money(o.change_due));
    line('=');
    center(String(store.store_footer || 'Terima kasih!'));
    /* 2 baris kosong di akhir struk supaya teks tidak menempel ke
       tepi guntingan / akhir kertas saat dipotong printer */
    L.push('');
    L.push('');
    /* baris ke-3: penanda akhir struk (memudahkan melihat batas kertas) */
    L.push('~');
    return L;
  }

  /**
   * HTML struk pelanggan.
   * @param {Object} o order (bentuk response api/orders.php)
   * @param {Object} store settings toko
   * @param {string} width '58' | '80'
   * @returns {string} dokumen HTML lengkap
   */
  function receiptHtml(o, store, width, opts) {
    /* Akhir struk: 2 baris kosong, lalu baris "~" sebagai penanda.
       Parser HTML membuang satu newline tepat sebelum </pre>, jadi
       baris kosong TIDAK boleh diandalkan lewat '\n' saja (dibuktikan
       lewat uji). Baris kosong dikirim sebagai <br> eksplisit. */
    var lines = receiptLines(o, store, width, opts);

    /* pisahkan blok akhir: [teks isi] + [kosong]* + ["~"] */
    var tail = [];
    while (lines.length > 0 &&
           (lines[lines.length - 1] === '' || lines[lines.length - 1] === '~')) {
      tail.unshift(lines.pop());
    }

    var body = lines.map(esc).join('\n');
    tail.forEach(function (t) {
      /* newline sebelum setiap baris tail, lalu baris itu sendiri;
         baris kosong jadi <br> agar tidak dibuang parser */
      body += '\n' + (t === '' ? '<br>' : esc(t));
    });
    return '<html><head><meta charset="utf-8"><style>' + baseCss(width, store) +
      '</style></head><body><pre>' + body + '</pre></body></html>';
  }

  /**
   * HTML tiket dapur (tanpa harga) — dipakai bila print_kitchen aktif.
   * @returns {string} dokumen HTML lengkap
   */
  function kitchenHtml(o, store, width) {
    var COLS = cols(width);
    var L = [];
    function line(ch) {
      var s = ''; while (s.length < COLS) { s += (ch || '-'); } L.push(s);
    }
    function wrap(text) {
      text = String(text);
      var out = [];
      if (text === '') { out.push(''); return out; }
      while (text.length > COLS) { out.push(text.slice(0, COLS)); text = text.slice(COLS); }
      out.push(text);
      return out;
    }
    function center(t) {
      wrap(t).forEach(function (seg) {
        var pad = Math.floor((COLS - seg.length) / 2);
        L.push(new Array(pad + 1).join(' ') + seg);
      });
    }

    center('*** TIKET DAPUR ***');
    center(String(store.store_name || 'Lampion Resto'));
    line('=');
    L.push('No    : ' + String(o.order_number));
    L.push('Tipe  : ' + String(o.order_type_label || o.order_type || ''));
    if (o.customer_name) { L.push('Nama  : ' + String(o.customer_name)); }
    L.push('Waktu : ' + String(o.created_label || ''));
    line('-');
    (o.items || []).forEach(function (it) {
      L.push(String(it.qty) + ' x ' + String(it.item_name));
    });
    line('=');

    var body = L.map(esc).join('\n');
    return '<html><head><meta charset="utf-8"><style>' + baseCss(width, store) +
      '</style></head><body><pre>' + body + '</pre></body></html>';
  }

  /* =============================================================
     API PUBLIK
     ============================================================= */

  /** Baris "penggaris" 32/48 kolom untuk kalibrasi ukuran font */
  function ruler(cols) {
    var s = '';
    for (var i = 1; i <= cols; i++) { s += String(i % 10); }
    return s;
  }

  /**
   * Halaman kalibrasi: cetak beberapa ukuran font sekaligus, masing-masing
   * dengan penggaris penuh sejumlah kolom. Pilih baris yang tepi kanannya
   * paling pas menyentuh tepi kertas -> itulah nilai printer_font_px.
   *
   * @param {Object} store settings toko
   * @param {string} width '58' | '80'
   * @returns {string} dokumen HTML
   */
  function calibrateHtml(store, width) {
    var c = cols(width);
    var cur = fontPx(width, store);
    var bar = new Array(c + 1).join('=');
    var sizes = [14, 18, 22, Math.round(RENDER_W_PX / c / 0.55), cur, 26, 30];
    var seen = {};

    var parts = [];
    parts.push('<div class="cal">');
    parts.push('<pre class="hd">' +
      esc('KALIBRASI UKURAN FONT') + '\n' +
      esc(bar) + '\n' +
      esc('Kertas ' + width + 'mm / ' + c + ' kolom') + '\n' +
      esc('Baris di bawah harus tepat ') + '\n' +
      esc('selebar kertas (tidak terpotong).') + '\n' +
      esc('Pilih angka yg paling pas, isi di') + '\n' +
      esc('Pengaturan > Ukuran font struk.') + '\n' +
      esc(bar) + '</pre>');

    sizes.forEach(function (px) {
      if (seen[px]) { return; }
      seen[px] = 1;
      /* setiap blok punya font-size sendiri, dibungkus div ber-font-size
         terpisah supaya tidak saling memengaruhi */
      parts.push('<div class="blk" style="font-size:' + px + 'px">' +
        '<pre>' + esc(px + 'px |' + ruler(c) + '|') + '</pre>' +
        '</div>');
    });

    parts.push('<pre class="ft">' + esc(bar) + '\n' +
      esc('Nilai sekarang: ' + cur + 'px') + '</pre>');
    parts.push('</div>');

    return '<html><head><meta charset="utf-8"><style>' +
      baseCss(width, store) +
      '.blk pre{white-space:pre}' +
      '.hd,.ft{font-size:inherit}' +
      '</style></head><body>' + parts.join('') + '</body></html>';
  }

  /** Struk uji 1 halaman biasa (tombol "Uji Cetak" di Pengaturan) */
  function testHtml(store, width) {
    var COLS = cols(width);
    var t = 'UJI CETAK PRINTER';
    var pad = Math.floor((COLS - t.length) / 2);
    var bar = new Array(COLS + 1).join('=');
    var L = [
      new Array(pad + 1).join(' ') + t,
      bar,
      'Nama toko : ' + String(store.store_name || '-'),
      'Lebar     : ' + String(width) + ' mm (' + COLS + ' kolom)',
      'Font      : ' + fontPx(width, store) + ' px',
      'Mode      : intent ' + SCHEME,
      'Waktu     : ' + new Date().toLocaleString('id-ID'),
      bar,
      'Bila baris ini tercetak,',
      'pengaturan printer sudah benar.'
    ];
    return '<html><head><meta charset="utf-8"><style>' + baseCss(width, store) +
      '</style></head><body><pre>' + L.map(esc).join('\n') +
      '</pre></body></html>';
  }

  /**
   * Cetak struk pelanggan lewat intent.
   * @returns {Promise<{ok:boolean, handoff:boolean}>}
   */
  function printReceipt(o, store, opts) {
    return intentUrl(receiptHtml(o, store, store.printer_width || '58', opts))
      .then(sendIntent);
  }

  /** Cetak tiket dapur lewat intent */
  function printKitchen(o, store) {
    return intentUrl(kitchenHtml(o, store, store.printer_width || '58'))
      .then(sendIntent);
  }

  /** Cetak halaman uji lewat intent */
  function printTest(store) {
    return intentUrl(testHtml(store, store.printer_width || '58'))
      .then(sendIntent);
  }

  /** Cetak halaman kalibrasi ukuran font lewat intent */
  function printCalibrate(store) {
    return intentUrl(calibrateHtml(store, store.printer_width || '58'))
      .then(sendIntent);
  }

  global.LPESCPOS = {
    SCHEME: SCHEME,
    available: available,
    gzipSupported: gzipSupported,
    intentUrl: intentUrl,
    sendIntent: sendIntent,
    cols: cols,
    defaultFontPx: defaultFontPx,
    fontPx: fontPx,
    receiptHtml: receiptHtml,
    kitchenHtml: kitchenHtml,
    testHtml: testHtml,
    calibrateHtml: calibrateHtml,
    printReceipt: printReceipt,
    printKitchen: printKitchen,
    printTest: printTest,
    printCalibrate: printCalibrate
  };
})(window);