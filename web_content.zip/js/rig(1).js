import { PARAMS, PARAM_MAP, setCustomParams, getCustomParams } from './params.js';
import { cloneWarp, drawWarped, warpPoints, evalWarp, normalizeWarp } from './warp.js';
import { normalizeAnim } from './anim.js';
import { meshPositions, drawMeshLayer, drawMeshOverlay, hitVertex, normalizeMesh } from './mesh.js';

export const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

/** Curva multiponto [{p,o}] (p crescente): interpolação linear, constante fora da faixa. */
export function evalCurve(keys, v) {
  if (v <= keys[0].p) return keys[0].o;
  const n = keys.length;
  if (v >= keys[n - 1].p) return keys[n - 1].o;
  let i = 1; while (keys[i].p < v) i++;
  const a = keys[i - 1], b = keys[i], t = (v - a.p) / ((b.p - a.p) || 1);
  return a.o + (b.o - a.o) * t;
}

export function loadImage(src) {
  return new Promise((res, rej) => {
    const img = new Image();
    img.onload = () => res(img);
    img.onerror = () => rej(new Error('Falha ao carregar imagem'));
    img.src = src;
  });
}

let uid = 1;

export const BLENDS = [['source-over', 'Normal'], ['multiply', 'Multiplicar'], ['screen', 'Tela'], ['overlay', 'Sobrepor'],
  ['lighter', 'Somar (brilho)'], ['soft-light', 'Luz suave'], ['darken', 'Escurecer'], ['lighten', 'Clarear']];
export const OSC_PROPS = [['rot', 'Rotação (°)'], ['x', 'Mover X'], ['y', 'Mover Y'], ['sx', 'Escala X'], ['sy', 'Escala Y']];
const jclone = o => JSON.parse(JSON.stringify(o));
const cloneBinding = b => jclone(b);
/** Cópia profunda de uma camada (sem imagens). */
export function cloneLayer(l) {
  return { ...l, bindings: l.bindings.map(cloneBinding), osc: (l.osc || []).map(o => ({ ...o })),
    warp: l.warp ? cloneWarp(l.warp) : null, mesh: l.mesh ? jclone(l.mesh) : null };
}

/**
 * Rig 2D: camadas de imagem em hierarquia. Cada camada tem uma pose de repouso
 * (x, y = canto sup. esq.; px, py = pivô em coordenadas da tela) e uma lista de
 * bindings parâmetro → propriedade que deformam a camada (e as filhas).
 */
export class Rig {
  constructor() { this.reset(); }

  reset() {
    this.name = 'Novo modelo';
    this.w = 800; this.h = 1100;
    this.layers = [];
    this.animations = [];
    this.physics = [];       // molas: { id, name, input, output, freq, damp, gain }
    this.expressions = [];   // { id, name, values:{param:valor}, fade }
    this.exprW = {};         // runtime: peso atual/alvo de cada expressão
    this._phys = new Map();
    this.time = 0;
    this.images = new Map();
    setCustomParams([]);
    this.values = {};
    for (const p of PARAMS) this.values[p.id] = p.def;
    this._alpha = new Map();
    this._meshPos = new Map();
  }

  /** Depois de mudar a lista de parâmetros: cria valores que faltam e remove os órfãos. */
  syncValues() {
    for (const p of PARAMS) if (!(p.id in this.values)) this.values[p.id] = p.def;
    for (const k of Object.keys(this.values)) if (!PARAM_MAP[k]) delete this.values[k];
  }

  /** Física (molas) + expressões, depois dos valores base. Chamar uma vez por quadro. */
  tick(dt) {
    this.time += dt;
    const V = this.values;
    const steps = Math.max(1, Math.ceil(dt * 120)), h = dt / steps;
    for (const ph of this.physics) {
      const inp = PARAM_MAP[ph.input], out = PARAM_MAP[ph.output];
      if (!inp || !out) continue;
      const n = (V[ph.input] - inp.def) / (((inp.max - inp.min) / 2) || 1);
      let st = this._phys.get(ph.id);
      if (!st) { st = { p: n, v: 0 }; this._phys.set(ph.id, st); }
      const w = 2 * Math.PI * clamp(ph.freq ?? 2, 0.2, 12), k = w * w, c = 2 * clamp(ph.damp ?? 0.35, 0.02, 2) * w;
      for (let i = 0; i < steps; i++) { st.v += (k * (n - st.p) - c * st.v) * h; st.p += st.v * h; }
      V[ph.output] = clamp((st.p - n) * (ph.gain ?? 2), out.min, out.max);
    }
    for (const ex of this.expressions) {
      const e = this.exprW[ex.id]; if (!e) continue;
      const rate = dt / Math.max(0.02, ex.fade ?? 0.15);
      e.w += clamp(e.target - e.w, -rate, rate);
      if (e.w <= 0.001) continue;
      for (const [pid, val] of Object.entries(ex.values)) if (PARAM_MAP[pid]) V[pid] += (val - V[pid]) * e.w;
    }
  }
  toggleExpression(id, on) {
    const e = this.exprW[id] ||= { w: 0, target: 0 };
    e.target = on ?? (e.target ? 0 : 1);
    return e.target;
  }

  newId() { return 'L' + Date.now().toString(36) + (uid++); }
  byId(id) { return this.layers.find(l => l.id === id) || null; }
  children(id) { return this.layers.filter(l => l.parent === id); }

  descendants(id) {
    const out = [];
    const walk = pid => { for (const c of this.children(pid)) { out.push(c); walk(c.id); } };
    walk(id);
    return out;
  }

  depth(l) {
    let d = 0, cur = l, guard = 0;
    while (cur && cur.parent && guard++ < 50) { cur = this.byId(cur.parent); d++; }
    return d;
  }

  async addLayer({ name, src, x, y, parent = null, bindings = [], pivot, id, warp = null, mesh = null, osc = [], opacity = 1, blend = 'source-over' }) {
    const img = await loadImage(src);
    id = id || this.newId();
    this.images.set(id, img);
    const w = img.naturalWidth, h = img.naturalHeight;
    x = x ?? Math.round((this.w - w) / 2);
    y = y ?? Math.round((this.h - h) / 2);
    const layer = {
      id, name: name || id, src, x, y, w, h,
      px: pivot ? pivot[0] : x + w / 2,
      py: pivot ? pivot[1] : y + h / 2,
      parent, visible: true, bindings: bindings.map(b => ({ ...b })),
      warp: warp ? cloneWarp(warp) : null,
      mesh: mesh ? normalizeMesh(jclone(mesh)) : null,
      osc: (Array.isArray(osc) ? osc : []).filter(o => o && OSC_PROPS.some(q => q[0] === o.prop)).map(o => ({ prop: o.prop, amp: +o.amp || 0, freq: +o.freq || 0.5, phase: +o.phase || 0 })),
      opacity: clamp(+opacity || 0, 0, 1) || (opacity === 0 ? 0 : 1),
      blend: BLENDS.some(b => b[0] === blend) ? blend : 'source-over',
    };
    this.layers.push(layer);
    return layer;
  }

  duplicateLayer(id) {
    const l = this.byId(id), img = this.images.get(id);
    if (!l || !img) return null;
    const c = cloneLayer(l); c.id = this.newId(); c.name = l.name + ' cópia';
    this.images.set(c.id, img);
    this.layers.splice(this.layers.indexOf(l) + 1, 0, c);
    return c;
  }

  removeLayer(id) {
    const l = this.byId(id);
    if (!l) return;
    for (const c of this.children(id)) c.parent = l.parent;
    this.layers = this.layers.filter(x => x.id !== id);   // a imagem fica em cache p/ o undo
  }

  moveZ(id, dir) {
    const i = this.layers.findIndex(l => l.id === id);
    const j = i + dir;
    if (i < 0 || j < 0 || j >= this.layers.length) return;
    [this.layers[i], this.layers[j]] = [this.layers[j], this.layers[i]];
  }

  setParent(id, parentId) {
    if (parentId === id) return;
    // impede ciclos
    if (parentId && this.descendants(id).some(d => d.id === parentId)) return;
    const l = this.byId(id);
    if (l) l.parent = parentId || null;
  }

  // ---- deformação ---------------------------------------------------------
  _deform(l) {
    let rot = 0, x = 0, y = 0, sx = 1, sy = 1, op = l.opacity ?? 1;
    for (const b of l.bindings) {
      const p = PARAM_MAP[b.param];
      if (!p) continue;
      let v;
      if (b.keys && b.keys.length >= 2) v = evalCurve(b.keys, this.values[b.param]);
      else {
        const lo = b.pmin ?? p.min, hi = b.pmax ?? p.max;
        const t = hi === lo ? 0 : clamp((this.values[b.param] - lo) / (hi - lo), 0, 1);
        v = b.from + (b.to - b.from) * t;
      }
      switch (b.prop) {
        case 'rot': rot += v; break;
        case 'x': x += v; break;
        case 'y': y += v; break;
        case 'sx': sx *= v; break;
        case 'sy': sy *= v; break;
        case 'op': op *= v; break;
      }
    }
    if (l.osc?.length) for (const o of l.osc) {
      const v = o.amp * Math.sin(2 * Math.PI * (o.freq * this.time + o.phase));
      switch (o.prop) { case 'rot': rot += v; break; case 'x': x += v; break; case 'y': y += v; break; case 'sx': sx *= 1 + v; break; case 'sy': sy *= 1 + v; break; }
    }
    const m = new DOMMatrix().translate(x, y).translate(l.px, l.py)
      .rotate(rot).scale(sx, sy).translate(-l.px, -l.py);
    return { m, op: clamp(op, 0, 1) };
  }

  /** Calcula matriz de mundo e opacidade acumulada de cada camada. */
  computeWorld() {
    const world = new Map();
    const visit = (l, depth) => {
      if (world.has(l.id)) return world.get(l.id);
      const d = this._deform(l);
      let W = d.m, op = d.op;
      const parent = l.parent && depth < 50 ? this.byId(l.parent) : null;
      if (parent) {
        const pw = visit(parent, depth + 1);
        W = pw.m.multiply(d.m);
        op *= pw.op;
      }
      const r = { m: W, op };
      world.set(l.id, r);
      return r;
    };
    for (const l of this.layers) visit(l, 0);
    return world;
  }

  /** Deformadores (warp) ancestrais de uma camada, do mais próximo ao mais distante. */
  _warpAncestors(l) {
    const out = [];
    let cur = l.parent ? this.byId(l.parent) : null, guard = 0;
    while (cur && guard++ < 50) {
      if (cur.warp) {
        normalizeWarp(cur.warp);
        let ev = this._evCache?.get(cur.id);
        if (!ev) { ev = evalWarp(cur, this.values); this._evCache?.set(cur.id, ev); }
        out.push({ layer: cur, ev });
      }
      cur = cur.parent ? this.byId(cur.parent) : null;
    }
    return out;
  }

  /** view: DOMMatrix da tela do rig → pixels do canvas. */
  render(ctx, view, { selected = null, overlay = false } = {}) {
    this._evCache = new Map();
    const world = this.computeWorld();
    this._lastWorld = world;
    this._lastView = view;
    for (const l of this.layers) {
      if (!l.visible) continue;
      const w = world.get(l.id);
      const img = this.images.get(l.id);
      if (!img || w.op <= 0.001) continue;
      ctx.setTransform(view.multiply(w.m));
      ctx.globalAlpha = w.op;
      ctx.globalCompositeOperation = l.blend || 'source-over';
      const ancs = this._warpAncestors(l);          // filhos herdam a deformação do warp-pai
      if (l.mesh && l.mesh.tris.length) {
        const pos = meshPositions(l, l.mesh, this.values, ancs);
        this._meshPos.set(l.id, pos);
        drawMeshLayer(ctx, img, l, l.mesh, pos, view.multiply(w.m));
      } else if (l.warp || ancs.length) drawWarped(ctx, img, l, l.warp, this.values, 1, ancs, !!(this.wireLayer && this.wireLayer === l.id));
      else ctx.drawImage(img, l.x, l.y);
    }
    ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
    if (overlay && selected) this._drawOverlay(ctx, view, world, selected);
  }

  _drawOverlay(ctx, view, world, id) {
    const l = this.byId(id), w = world.get(id);
    if (!l || !w) return;
    const M = view.multiply(w.m);
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    const pts = [[l.x, l.y], [l.x + l.w, l.y], [l.x + l.w, l.y + l.h], [l.x, l.y + l.h]]
      .map(([x, y]) => M.transformPoint({ x, y }));
    ctx.strokeStyle = '#4de2c5'; ctx.lineWidth = 2; ctx.setLineDash([6, 4]);
    ctx.beginPath(); pts.forEach((p, i) => i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y));
    ctx.closePath(); ctx.stroke(); ctx.setLineDash([]);
    const c = M.transformPoint({ x: l.px, y: l.py });
    ctx.strokeStyle = '#ff5d8f'; ctx.fillStyle = '#ff5d8f'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(c.x, c.y, 8, 0, 7); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(c.x - 13, c.y); ctx.lineTo(c.x + 13, c.y);
    ctx.moveTo(c.x, c.y - 13); ctx.lineTo(c.x, c.y + 13); ctx.stroke();
  }

  // ---- seleção por toque --------------------------------------------------
  _alphaAt(l, lx, ly) {
    let c = this._alpha.get(l.id);
    if (!c) {
      c = document.createElement('canvas'); c.width = l.w; c.height = l.h;
      const cx = c.getContext('2d', { willReadFrequently: true });
      cx.drawImage(this.images.get(l.id), 0, 0);
      this._alpha.set(l.id, c);
    }
    return c.getContext('2d', { willReadFrequently: true })
      .getImageData(clamp(lx | 0, 0, l.w - 1), clamp(ly | 0, 0, l.h - 1), 1, 1).data[3];
  }

  /** Converte ponto da tela do rig p/ espaço de repouso da camada. */
  toRest(id, x, y) {
    const w = (this._lastWorld || this.computeWorld()).get(id);
    const p = w.m.inverse().transformPoint({ x, y });
    return { x: p.x, y: p.y };
  }

  pick(x, y) {
    const world = this._lastWorld || this.computeWorld();
    for (let i = this.layers.length - 1; i >= 0; i--) {
      const l = this.layers[i];
      if (!l.visible) continue;
      const p = world.get(l.id).m.inverse().transformPoint({ x, y });
      const lx = p.x - l.x, ly = p.y - l.y;
      if (lx < 0 || ly < 0 || lx >= l.w || ly >= l.h) continue;
      if (this._alphaAt(l, lx, ly) > 20) return l.id;
    }
    return null;
  }

  // ---- warp: hit-test e overlay --------------------------------------------
  /** Índice do ponto de controle mais próximo de (x,y) [espaço do rig], ou -1. */
  warpHit(id, x, y, maxDist) {
    const l = this.byId(id), w = this._lastWorld?.get(id);
    if (!l?.warp || !w) return -1;
    let best = -1, bd = maxDist;
    warpPoints(l, l.warp, this.values).forEach((p, i) => {
      const q = w.m.transformPoint({ x: p.x, y: p.y });
      const d = Math.hypot(q.x - x, q.y - y);
      if (d < bd) { bd = d; best = i; }
    });
    return best;
  }

  // ---- malha livre: hit-test e overlay -----------------------------------------
  meshAncestors(l) { return this._warpAncestors(l); }
  meshHit(id, x, y, maxDist) {
    const l = this.byId(id), w = this._lastWorld?.get(id), pos = this._meshPos.get(id);
    if (!l?.mesh || !w || !pos) return -1;
    return hitVertex(pos, w.m, x, y, maxDist);
  }
  drawMeshOverlay(ctx, view, id, opts) {
    const l = this.byId(id), w = this._lastWorld?.get(id), pos = this._meshPos.get(id);
    if (!l?.mesh || !w || !pos) return;
    drawMeshOverlay(ctx, view.multiply(w.m), l.mesh, pos, opts);
  }

  drawWarpOverlay(ctx, view, id, { radius = 0, active = -1 } = {}) {
    const l = this.byId(id), w = this._lastWorld?.get(id);
    if (!l?.warp || !w) return;
    const M = view.multiply(w.m), wp = l.warp, W = wp.cols + 1;
    const pts = warpPoints(l, wp, this.values).map(p => M.transformPoint({ x: p.x, y: p.y }));
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.lineWidth = 1.2; ctx.strokeStyle = '#4de2c5cc';
    ctx.beginPath();
    for (let b = 0; b <= wp.rows; b++) for (let a = 0; a <= wp.cols; a++) {
      const p = pts[b * W + a];
      if (a < wp.cols) { const q = pts[b * W + a + 1]; ctx.moveTo(p.x, p.y); ctx.lineTo(q.x, q.y); }
      if (b < wp.rows) { const q = pts[(b + 1) * W + a]; ctx.moveTo(p.x, p.y); ctx.lineTo(q.x, q.y); }
    }
    ctx.stroke();
    const ga = active >= 0 ? active % W : -1, gb = active >= 0 ? (active / W) | 0 : -1;
    pts.forEach((p, i) => {
      const a = i % W, b = (i / W) | 0;
      let r = 5, fill = '#14111f';
      if (active >= 0 && radius > 0) {
        const wt = Math.exp(-((Math.hypot(a - ga, b - gb) / radius) ** 2));
        if (wt > 0.05) { r = 5 + 4 * wt; fill = `rgba(255,93,143,${0.25 + 0.6 * wt})`; }
      }
      if (i === active) fill = '#ff5d8f';
      ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, 7); ctx.fillStyle = fill; ctx.fill();
      ctx.strokeStyle = '#4de2c5'; ctx.stroke();
    });
  }

  // ---- histórico (undo/redo) ----------------------------------------------
  snapshot() {
    return {
      name: this.name, w: this.w, h: this.h,
      animations: jclone(this.animations), physics: jclone(this.physics), expressions: jclone(this.expressions),
      customParams: getCustomParams(),
      layers: this.layers.map(cloneLayer),
    };
  }

  restore(snap) {
    this.name = snap.name; this.w = snap.w; this.h = snap.h;
    this.animations = jclone(snap.animations || []);
    this.physics = jclone(snap.physics || []); this.expressions = jclone(snap.expressions || []);
    setCustomParams(snap.customParams || []); this.syncValues();
    this.layers = snap.layers.map(cloneLayer);
  }

  // ---- (de)serialização ---------------------------------------------------
  toJSON() {
    return {
      format: 'vtuber-rigger', version: 1, name: this.name, w: this.w, h: this.h,
      animations: this.animations, customParams: getCustomParams(), physics: this.physics, expressions: this.expressions,
      layers: this.layers.map(l => ({
        id: l.id, name: l.name, src: l.src, x: l.x, y: l.y, px: l.px, py: l.py,
        parent: l.parent, visible: l.visible, bindings: l.bindings, osc: l.osc, opacity: l.opacity, blend: l.blend,
        warp: l.warp ? cloneWarp(l.warp) : null, mesh: l.mesh || null,
      })),
    };
  }

  async fromJSON(data) {
    if (!data || data.format !== 'vtuber-rigger') throw new Error('Arquivo de modelo inválido');
    this.reset();
    this.name = data.name || 'Modelo'; this.w = data.w; this.h = data.h;
    setCustomParams(data.customParams || []); this.syncValues();
    this.physics = (Array.isArray(data.physics) ? data.physics : []).filter(p => p && p.id && p.input && p.output);
    this.expressions = (Array.isArray(data.expressions) ? data.expressions : []).filter(e => e && e.id && e.values && typeof e.values === 'object');
    this.animations = (Array.isArray(data.animations) ? data.animations : []).map(normalizeAnim).filter(Boolean);
    for (const l of data.layers) {
      const layer = await this.addLayer({ ...l, pivot: [l.px, l.py] });
      layer.visible = l.visible !== false;
    }
  }
}
