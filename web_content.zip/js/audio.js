/* =========================================================================
   Aethervale — Mesin audio prosedural (musik berlapis + tempur berlapis)
   Tidak ada berkas audio: semua dibangkitkan Web Audio saat berjalan.
   ========================================================================= */
const Audio2 = {
  ctx: null, master: null, musicGain: null, sfxGain: null, revGain: null, revIn: null,
  on: true, musicOn: true, sfxOn: true,
  step: 0, nextTime: 0, intensity: 0, curKey: 'meadow', keyFade: 1, lfo: null,

  /* palet musik per bioma */
  palettes: {
    meadow: { root: 220.00, scale: [0, 2, 4, 7, 9], prog: [0, 5, 3, 4], pad: 'triangle', lead: 'triangle', bpm: 88,  air: 0.5 },
    forest: { root: 196.00, scale: [0, 3, 5, 7, 10], prog: [0, 3, 5, 4], pad: 'sawtooth', lead: 'square',  bpm: 92,  air: 0.55 },
    swamp:  { root: 164.81, scale: [0, 2, 3, 7, 8],  prog: [0, 2, 5, 3], pad: 'sawtooth', lead: 'triangle', bpm: 74, air: 0.7 },
    ash:    { root: 146.83, scale: [0, 1, 4, 6, 7],  prog: [0, 4, 1, 6], pad: 'sawtooth', lead: 'square',  bpm: 104, air: 0.4 },
    snow:   { root: 246.94, scale: [0, 2, 5, 7, 9],  prog: [0, 5, 2, 4], pad: 'triangle', lead: 'sine',    bpm: 70,  air: 0.85 },
    rift:   { root: 130.81, scale: [0, 1, 5, 6, 10], prog: [0, 6, 3, 5], pad: 'sawtooth', lead: 'sine',    bpm: 82,  air: 0.9 },
  },

  init() {
    if (this.ctx) return;
    try { this.ctx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { this.on = false; return; }
    const c = this.ctx;
    this.master = c.createGain(); this.master.gain.value = 0.85;
    const comp = c.createDynamicsCompressor();
    comp.threshold.value = -16; comp.knee.value = 24; comp.ratio.value = 3.4; comp.attack.value = 0.004; comp.release.value = 0.22;
    this.master.connect(comp).connect(c.destination);

    // reverb prosedural
    this.revIn = c.createGain(); this.revIn.gain.value = 1;
    const conv = c.createConvolver(); conv.buffer = this._impulse(2.6, 0.55);
    this.revGain = c.createGain(); this.revGain.gain.value = 0.5;
    const revLP = c.createBiquadFilter(); revLP.type = 'lowpass'; revLP.frequency.value = 3600;
    this.revIn.connect(conv).connect(revLP).connect(this.revGain).connect(this.master);

    this.musicGain = c.createGain(); this.musicGain.gain.value = 0.2; this.musicGain.connect(this.master);
    this.musicSend = c.createGain(); this.musicSend.gain.value = 0.35; this.musicGain.connect(this.musicSend); this.musicSend.connect(this.revIn);
    this.sfxGain = c.createGain(); this.sfxGain.gain.value = 0.42; this.sfxGain.connect(this.master);
    this.sfxSend = c.createGain(); this.sfxSend.gain.value = 0.16; this.sfxGain.connect(this.sfxSend); this.sfxSend.connect(this.revIn);

    // delay ringan untuk arpeggio
    this.delay = c.createDelay(0.6); this.delay.delayTime.value = 0.26;
    this.delayFb = c.createGain(); this.delayFb.gain.value = 0.28;
    this.delayMix = c.createGain(); this.delayMix.gain.value = 0.3;
    this.delay.connect(this.delayFb).connect(this.delay);
    this.delay.connect(this.delayMix).connect(this.musicGain);

    this.nextTime = c.currentTime + 0.1;
    this.noiseBuf = this._noiseBuffer(1.4);
  },

  _impulse(dur, decay) {
    const c = this.ctx, len = Math.floor(c.sampleRate * dur);
    const buf = c.createBuffer(2, len, c.sampleRate);
    for (let ch = 0; ch < 2; ch++) {
      const d = buf.getChannelData(ch);
      for (let i = 0; i < len; i++) {
        const t = i / len;
        d[i] = (Math.random() * 2 - 1) * Math.pow(1 - t, 2.2) * decay * (1 - t * 0.2);
      }
    }
    return buf;
  },
  _noiseBuffer(dur) {
    const c = this.ctx, len = Math.floor(c.sampleRate * dur);
    const buf = c.createBuffer(1, len, c.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    return buf;
  },

  /* ---------- blok dasar ---------- */
  osc(when, dur, freq, type, vol, dest, opts) {
    if (!this.ctx || !this.on) return null;
    opts = opts || {};
    const c = this.ctx, o = c.createOscillator(), g = c.createGain();
    o.type = type || 'square';
    o.frequency.setValueAtTime(Math.max(20, freq), when);
    if (opts.to) o.frequency.exponentialRampToValueAtTime(Math.max(20, opts.to), when + (opts.slide || dur));
    if (opts.detune) o.detune.value = opts.detune;
    const atk = opts.atk === undefined ? 0.008 : opts.atk;
    g.gain.setValueAtTime(0.0001, when);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), when + atk);
    g.gain.exponentialRampToValueAtTime(0.0001, when + dur);
    let node = g;
    if (opts.filter) {
      const f = c.createBiquadFilter(); f.type = opts.filter; f.frequency.setValueAtTime(opts.fFreq || 1200, when);
      if (opts.fTo) f.frequency.exponentialRampToValueAtTime(Math.max(60, opts.fTo), when + dur);
      if (opts.q) f.Q.value = opts.q;
      g.connect(f); node = f;
    }
    o.connect(g); node.connect(dest || this.sfxGain);
    o.start(when); o.stop(when + dur + 0.05);
    return o;
  },
  nz(when, dur, vol, dest, opts) {
    if (!this.ctx || !this.on) return;
    opts = opts || {};
    const c = this.ctx, s = c.createBufferSource();
    s.buffer = this.noiseBuf || (this.noiseBuf = this._noiseBuffer(1.4));
    s.playbackRate.value = opts.rate || 1;
    const f = c.createBiquadFilter();
    f.type = opts.type || 'lowpass';
    f.frequency.setValueAtTime(opts.f0 || 1800, when);
    if (opts.f1) f.frequency.exponentialRampToValueAtTime(Math.max(60, opts.f1), when + dur);
    f.Q.value = opts.q || 1;
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, when);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), when + (opts.atk || 0.005));
    g.gain.exponentialRampToValueAtTime(0.0001, when + dur);
    s.connect(f).connect(g).connect(dest || this.sfxGain);
    s.start(when); s.stop(when + dur + 0.05);
  },
  // kompatibilitas dengan kode lama
  note(freq, dur, type, gainNode, vol) { if (this.ctx) this.osc(this.ctx.currentTime, dur, freq, type, vol || 0.25, gainNode || this.sfxGain); },
  noise(dur, vol, f) { if (this.ctx) this.nz(this.ctx.currentTime, dur, vol || 0.2, this.sfxGain, { f0: f || 1400, f1: (f || 1400) * 0.4 }); },

  /* ---------- suara senjata: tebasan & hantaman berlapis ---------- */
  /* ---------- efek suara klasik (versi awal) ---------- */
  swing() { this.noise(0.07, 0.10, 3000); },
  impact(spec, crit) {
    if (crit) { this.noise(0.12, 0.30, 2600); this.note(320, 0.12, 'sawtooth', null, 0.20); }
    else { this.noise(0.09, 0.22, 1800); this.note(180, 0.08, 'square', null, 0.16); }
  },
  skillCast(color, big) {
    if (!this.ctx || !this.on || !this.sfxOn) return;
    [523, 784, 1046].forEach((f, i) => setTimeout(() => this.note(f, 0.16, 'square', null, big ? 0.18 : 0.13), i * 60));
  },
  sfx(kind) {
    if (!this.ctx || !this.on || !this.sfxOn) return;
    switch (kind) {
      case 'hit': this.noise(0.09, 0.22, 1800); this.note(180, 0.08, 'square', null, 0.16); break;
      case 'crit': this.noise(0.12, 0.3, 2600); this.note(320, 0.12, 'sawtooth', null, 0.2); break;
      case 'swing': this.noise(0.07, 0.1, 3000); break;
      case 'hurt': this.note(140, 0.18, 'sawtooth', null, 0.22); break;
      case 'coin': this.note(880, 0.06, 'square', null, 0.14); setTimeout(() => this.note(1320, 0.07, 'square', null, 0.12), 55); break;
      case 'level': [523, 659, 784, 1046].forEach((f, i) => setTimeout(() => this.note(f, 0.18, 'triangle', null, 0.2), i * 90)); break;
      case 'ui': this.note(660, 0.045, 'square', null, 0.10); break;
      case 'ok': [659, 988].forEach((f, i) => setTimeout(() => this.note(f, 0.14, 'triangle', null, 0.18), i * 80)); break;
      case 'fail': [330, 233].forEach((f, i) => setTimeout(() => this.note(f, 0.2, 'sawtooth', null, 0.18), i * 110)); break;
      case 'break': this.noise(0.5, 0.34, 700); [220, 160, 110].forEach((f, i) => setTimeout(() => this.note(f, 0.3, 'sawtooth', null, 0.2), i * 110)); break;
      case 'quest': [523, 659, 784, 1046, 1318].forEach((f, i) => setTimeout(() => this.note(f, 0.2, 'square', null, 0.16), i * 100)); break;
      case 'boss': [110, 104, 98].forEach((f, i) => setTimeout(() => this.note(f, 0.5, 'sawtooth', null, 0.22), i * 160)); break;
      case 'death': [330, 262, 196, 147].forEach((f, i) => setTimeout(() => this.note(f, 0.4, 'triangle', null, 0.2), i * 200)); break;
      case 'unlock': [659, 880, 1175].forEach((f, i) => setTimeout(() => this.note(f, 0.18, 'triangle', null, 0.18), i * 80)); break;
      case 'clash': [196, 262, 330].forEach((f, i) => setTimeout(() => this.note(f, 0.28, 'square', null, 0.18), i * 130)); break;
    }
  },

  /* ---------- musik berlapis ---------- */
  setIntensity(v) { this.intensity = v; },
  updateMusic(regionKey, inCombat) {
    if (!this.ctx || !this.on || !this.musicOn) return;
    const P = this.palettes[regionKey] || this.palettes.meadow;
    const inten = this.intensity || (inCombat ? 1 : 0);
    const bpm = P.bpm * (inten >= 2 ? 1.34 : inten === 1 ? 1.16 : 1);
    const spb = 60 / bpm / 4;                    // langkah 1/16
    const t = this.ctx.currentTime;
    while (this.nextTime < t + 0.3) {
      this._schedule(P, inten, this.nextTime, spb);
      this.nextTime += spb;
      this.step++;
    }
  },
  _schedule(P, inten, when, spb) {
    const s = this.step % 16;
    const bar = Math.floor(this.step / 16);
    const chord = P.prog[bar % P.prog.length];
    const sc = P.scale;
    const deg = d => P.root * Math.pow(2, (sc[((d % sc.length) + sc.length) % sc.length] + 12 * Math.floor(d / sc.length)) / 12);
    const M = this.musicGain;

    // --- pad akor (sustain 1 bar, dua osilator detune) ---
    if (s === 0) {
      const dur = spb * 16 * 1.02;
      [0, 2, 4].forEach((iv, k) => {
        this.osc(when, dur, deg(chord + iv) / 2, P.pad, 0.045 + (inten >= 2 ? 0.02 : 0), M,
          { atk: dur * 0.25, detune: k * 7 - 7, filter: 'lowpass', fFreq: 700 + inten * 500, fTo: 420 + inten * 300 });
      });
      // udara / atmosfer
      this.nz(when, dur, 0.012 * (P.air || 0.5), this.musicGain, { type: 'bandpass', f0: 1800, f1: 900, q: 0.8 });
    }
    // --- bass ---
    if (s % 4 === 0) {
      const bf = deg(chord) / 4;
      this.osc(when, spb * 3.4, bf, 'triangle', 0.16, M, { atk: 0.01, filter: 'lowpass', fFreq: 420 });
      this.osc(when, spb * 2.2, bf / 2, 'sine', 0.12, M);
    }
    // --- arpeggio bergema (lewat delay) ---
    if (inten >= 1 || s % 2 === 0) {
      const ad = [0, 2, 4, 2, 5, 4, 2, 0][s % 8] + chord;
      this.osc(when, spb * 1.3, deg(ad), 'square', inten >= 1 ? 0.055 : 0.04, this.delay, { atk: 0.004, filter: 'lowpass', fFreq: 2600 });
    }
    // --- melodi (motif 4 bar) ---
    const motif = [0, 4, 2, 7, 4, 2, 0, -1, 2, 4, 5, 4, 2, 0, -1, 0];
    if (s % 2 === 0 && (bar % 2 === 1 || inten >= 1)) {
      const md = motif[(s + bar * 3) % motif.length] + chord;
      this.osc(when, spb * 2.1, deg(md) * 2, P.lead, inten >= 2 ? 0.075 : 0.05, M, { atk: 0.012, filter: 'lowpass', fFreq: 3400 });
    }
    // --- perkusi ---
    if (inten >= 1) {
      if (s === 0 || s === 6 || s === 10) {                       // kick
        this.osc(when, 0.16, 140, 'sine', 0.3, M, { to: 44, atk: 0.002 });
      }
      if (s === 4 || s === 12) {                                  // snare
        this.nz(when, 0.14, 0.16, M, { type: 'bandpass', f0: 1900, f1: 900, q: 0.9 });
      }
      if (s % 2 === 1) this.nz(when, 0.045, 0.05, M, { type: 'highpass', f0: 6200 });   // hat
      if (inten >= 2 && s % 8 === 7) this.osc(when, 0.3, 70, 'sine', 0.26, M, { to: 32 }); // tom bos
    } else if (s === 0 || s === 8) {
      this.nz(when, 0.09, 0.05, M, { type: 'bandpass', f0: 1200, q: 0.7 });
    }
  },
};
