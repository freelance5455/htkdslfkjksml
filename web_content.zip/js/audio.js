// ===== Áudio procedural (Web Audio) =====
const AudioSys = {
  ctx: null, master: null, muted: false, ocean: null, oceanGain: null, nightGain: null,
  init() {
    if (this.ctx) { this.ctx.resume(); return; }
    try {
      const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
      this.ctx = new AC();
      this.master = this.ctx.createGain(); this.master.gain.value = 0.5; this.master.connect(this.ctx.destination);
      // ondas do mar: ruído marrom filtrado com LFO
      const len = this.ctx.sampleRate * 4, buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate), d = buf.getChannelData(0);
      let last = 0; for (let i = 0; i < len; i++) { const w = Math.random() * 2 - 1; last = (last + 0.02 * w) / 1.02; d[i] = last * 3.2; }
      const src = this.ctx.createBufferSource(); src.buffer = buf; src.loop = true;
      const lp = this.ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 600;
      this.oceanGain = this.ctx.createGain(); this.oceanGain.gain.value = 0.25;
      const lfo = this.ctx.createOscillator(), lfoG = this.ctx.createGain(); lfo.frequency.value = 0.12; lfoG.gain.value = 0.12; lfo.connect(lfoG).connect(this.oceanGain.gain); lfo.start();
      src.connect(lp).connect(this.oceanGain).connect(this.master); src.start();
      // grilos à noite
      this.nightGain = this.ctx.createGain(); this.nightGain.gain.value = 0;
      const cr = this.ctx.createOscillator(); cr.frequency.value = 4200; cr.type = 'sine';
      const am = this.ctx.createOscillator(), amG = this.ctx.createGain(); am.frequency.value = 22; amG.gain.value = 0.5; am.connect(amG);
      const crG = this.ctx.createGain(); crG.gain.value = 0.5; amG.connect(crG.gain);
      cr.connect(crG).connect(this.nightGain).connect(this.master); cr.start(); am.start();
    } catch (e) { this.ctx = null; }
  },
  setAmbient(coast, night) {
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    this.oceanGain.gain.setTargetAtTime(0.06 + 0.3 * coast, now, 0.5);
    this.nightGain.gain.setTargetAtTime(night ? 0.012 : 0, now, 1.5);
  },
  toggle() { this.muted = !this.muted; if (this.master) this.master.gain.value = this.muted ? 0 : 0.5; return this.muted; },
  tone(f, dur, type, vol, slide) {
    if (!this.ctx || this.muted) return;
    const o = this.ctx.createOscillator(), g = this.ctx.createGain(), t = this.ctx.currentTime;
    o.type = type || 'sine'; o.frequency.setValueAtTime(f, t); if (slide) o.frequency.exponentialRampToValueAtTime(slide, t + dur);
    g.gain.setValueAtTime(vol || 0.2, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g).connect(this.master); o.start(t); o.stop(t + dur + 0.02);
  },
  noise(dur, freq, vol) {
    if (!this.ctx || this.muted) return;
    const len = Math.floor(this.ctx.sampleRate * dur), buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate), d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
    const s = this.ctx.createBufferSource(); s.buffer = buf;
    const f = this.ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = freq; f.Q.value = 1.2;
    const g = this.ctx.createGain(); g.gain.value = vol || 0.4;
    s.connect(f).connect(g).connect(this.master); s.start();
  },
  sfx(name) {
    switch (name) {
      case 'chop': this.noise(0.12, 300, 0.6); this.tone(110, 0.1, 'triangle', 0.15); break;
      case 'stone': this.noise(0.06, 2400, 0.4); this.tone(900, 0.05, 'square', 0.05); break;
      case 'soft': this.noise(0.1, 1200, 0.25); break;
      case 'pickup': this.tone(520, 0.08, 'sine', 0.15, 880); break;
      case 'craft': this.tone(440, 0.1, 'triangle', 0.15); setTimeout(() => this.tone(660, 0.16, 'triangle', 0.15), 90); break;
      case 'eat': this.noise(0.15, 700, 0.3); break;
      case 'drink': this.tone(300, 0.12, 'sine', 0.15, 500); setTimeout(() => this.tone(340, 0.1, 'sine', 0.12, 560), 140); break;
      case 'hurt': this.tone(240, 0.22, 'sawtooth', 0.15, 90); break;
      case 'swing': this.noise(0.08, 900, 0.2); break;
      case 'page': this.noise(0.18, 3000, 0.15); this.tone(780, 0.25, 'sine', 0.08, 1040); break;
      case 'error': this.tone(180, 0.12, 'square', 0.06); break;
      case 'win': [523, 659, 784, 1046].forEach((f, i) => setTimeout(() => this.tone(f, 0.4, 'triangle', 0.15), i * 160)); break;
    }
  },
};
