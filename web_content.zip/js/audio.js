/* ============================================================
   audio.js — fully synthesized WebAudio soundscape
   engine · wind · tyres · skid · rain · nitro · horn · siren
   ============================================================ */
'use strict';

class EngineAudio {
  constructor() {
    this.ctx = null;
    this.ready = false;
    this.running = false;
    this.enabled = true;
    this.vol = { master: 0.85, engine: 0.9, sfx: 0.85 };
    this.nodes = null;
    this.cyl = 6;
    this.redline = 7200;
    this.idle = 900;
    this._sirenOn = false;
    this._nitro = false;
  }

  init() {
    if (this.ctx) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) { this.enabled = false; return; }
    try { this.ctx = new AC(); } catch (e) { this.enabled = false; return; }

    const ctx = this.ctx;

    // ---- buses ----
    const master = ctx.createGain(); master.gain.value = 0; master.connect(ctx.destination);
    const engineBus = ctx.createGain(); engineBus.gain.value = this.vol.engine; engineBus.connect(master);
    const sfxBus = ctx.createGain(); sfxBus.gain.value = this.vol.sfx; sfxBus.connect(master);

    // ---- engine core ----
    const engineGain = ctx.createGain(); engineGain.gain.value = 0.5;
    const engineFilter = ctx.createBiquadFilter();
    engineFilter.type = 'lowpass'; engineFilter.frequency.value = 900; engineFilter.Q.value = 1.3;
    const shaper = ctx.createWaveShaper();
    shaper.curve = this._makeDistortion(22); shaper.oversample = '2x';

    const oscs = [], oscGains = [];
    const harmonics = [0.5, 1, 1.5, 2, 3];
    const levels = [0.8, 1.0, 0.42, 0.3, 0.16];
    for (let i = 0; i < harmonics.length; i++) {
      const o = ctx.createOscillator();
      o.type = i % 2 === 0 ? 'sawtooth' : 'square';
      const g = ctx.createGain(); g.gain.value = levels[i] * 0.14;
      o.connect(g); g.connect(shaper);
      oscs.push(o); oscGains.push(g);
    }
    shaper.connect(engineFilter); engineFilter.connect(engineGain); engineGain.connect(engineBus);

    const noiseBuf = this._makeNoiseBuffer(ctx, 2.5);

    // exhaust rumble
    const rumble = ctx.createBufferSource(); rumble.buffer = noiseBuf; rumble.loop = true;
    const rumbleFilter = ctx.createBiquadFilter(); rumbleFilter.type = 'bandpass';
    rumbleFilter.frequency.value = 140; rumbleFilter.Q.value = 0.8;
    const rumbleGain = ctx.createGain(); rumbleGain.gain.value = 0;
    rumble.connect(rumbleFilter); rumbleFilter.connect(rumbleGain); rumbleGain.connect(engineBus);

    // wind
    const wind = ctx.createBufferSource(); wind.buffer = noiseBuf; wind.loop = true;
    const windFilter = ctx.createBiquadFilter(); windFilter.type = 'highpass'; windFilter.frequency.value = 650;
    const windGain = ctx.createGain(); windGain.gain.value = 0;
    wind.connect(windFilter); windFilter.connect(windGain); windGain.connect(engineBus);

    // tyres / road hum
    const tireFilter = ctx.createBiquadFilter(); tireFilter.type = 'lowpass'; tireFilter.frequency.value = 260;
    const tireGain = ctx.createGain(); tireGain.gain.value = 0;
    wind.connect(tireFilter); tireFilter.connect(tireGain); tireGain.connect(engineBus);

    // skid
    const skid = ctx.createBufferSource(); skid.buffer = noiseBuf; skid.loop = true;
    const skidFilter = ctx.createBiquadFilter(); skidFilter.type = 'bandpass';
    skidFilter.frequency.value = 1100; skidFilter.Q.value = 2.2;
    const skidGain = ctx.createGain(); skidGain.gain.value = 0;
    skid.connect(skidFilter); skidFilter.connect(skidGain); skidGain.connect(sfxBus);

    // rain
    const rain = ctx.createBufferSource(); rain.buffer = noiseBuf; rain.loop = true;
    const rainFilter = ctx.createBiquadFilter(); rainFilter.type = 'lowpass'; rainFilter.frequency.value = 2200;
    const rainGain = ctx.createGain(); rainGain.gain.value = 0;
    rain.connect(rainFilter); rainFilter.connect(rainGain); rainGain.connect(sfxBus);

    // nitro whoosh
    const nitro = ctx.createBufferSource(); nitro.buffer = noiseBuf; nitro.loop = true;
    const nitroFilter = ctx.createBiquadFilter(); nitroFilter.type = 'highpass'; nitroFilter.frequency.value = 900;
    const nitroGain = ctx.createGain(); nitroGain.gain.value = 0;
    nitro.connect(nitroFilter); nitroFilter.connect(nitroGain); nitroGain.connect(sfxBus);

    // siren
    const siren = ctx.createOscillator(); siren.type = 'square'; siren.frequency.value = 760;
    const sirenGain = ctx.createGain(); sirenGain.gain.value = 0;
    const sirenFilter = ctx.createBiquadFilter(); sirenFilter.type = 'lowpass'; sirenFilter.frequency.value = 1800;
    siren.connect(sirenFilter); sirenFilter.connect(sirenGain); sirenGain.connect(sfxBus);

    for (const o of oscs) o.start();
    rumble.start(); wind.start(); skid.start(); rain.start(); nitro.start(); siren.start();

    this.nodes = {
      master, engineBus, sfxBus, engineGain, engineFilter, rumbleGain,
      windGain, tireGain, skidGain, rainGain, nitroGain, sirenGain, siren,
      oscs, oscGains, noiseBuf,
    };
    this.ready = true;
    this._applyVolumes();
  }

  _makeNoiseBuffer(ctx, seconds) {
    const len = Math.max(1, Math.floor(ctx.sampleRate * seconds));
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = buf.getChannelData(0);
    let last = 0;
    for (let i = 0; i < len; i++) {
      const w = Math.random() * 2 - 1;
      last = (last + 0.02 * w) / 1.02;
      d[i] = last * 3.2;
    }
    return buf;
  }

  _makeDistortion(amount) {
    const n = 1024, curve = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      const x = (i * 2) / n - 1;
      curve[i] = Math.tanh(x * (1 + amount * 0.15));
    }
    return curve;
  }

  _applyVolumes() {
    if (!this.ready) return;
    const n = this.nodes, t = this.ctx.currentTime;
    const on = this.enabled && !this.vol.mute;
    n.master.gain.setTargetAtTime(on ? this.vol.master * 0.55 : 0, t, 0.06);
    n.engineBus.gain.setTargetAtTime(this.vol.engine, t, 0.06);
    n.sfxBus.gain.setTargetAtTime(this.vol.sfx, t, 0.06);
  }

  setVolumes(v) {
    Object.assign(this.vol, v);
    this.enabled = !this.vol.mute;
    this._applyVolumes();
  }

  setCar(spec) {
    if (!spec) return;
    this.cyl = spec.cyl || 6;
    this.redline = 6800 + spec.top * 2;
    this.idle = spec.cyl === 0 ? 0 : 850;
  }

  resume() { if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume().catch(() => {}); }
  suspend() { if (this.ctx && this.ctx.state === 'running') this.ctx.suspend().catch(() => {}); }

  start() {
    this.init(); this.resume();
    if (!this.ready) return;
    this.running = true;
    this._applyVolumes();
    this.nodes.master.gain.setTargetAtTime(this.enabled && !this.vol.mute ? this.vol.master * 0.55 : 0, this.ctx.currentTime, 0.25);
  }

  stop() {
    if (!this.ready) return;
    this.running = false;
    this.nodes.master.gain.setTargetAtTime(0, this.ctx.currentTime, 0.15);
    this.nodes.sirenGain.gain.setTargetAtTime(0, this.ctx.currentTime, 0.1);
  }

  /* ---------------- one-shots ---------------- */
  _blip(freqA, freqB, dur, type, amp, bus) {
    if (!this.ready || !this.enabled) return;
    const ctx = this.ctx, t = ctx.currentTime;
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.type = type || 'square';
    o.frequency.setValueAtTime(freqA, t);
    o.frequency.exponentialRampToValueAtTime(Math.max(20, freqB), t + dur);
    g.gain.setValueAtTime(amp, t);
    g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
    o.connect(g); g.connect(bus || this.nodes.sfxBus);
    o.start(t); o.stop(t + dur + 0.02);
  }

  shiftBlip(up) { this._blip(up ? 260 : 180, up ? 100 : 70, 0.1, 'square', 0.18); }
  ui() { this._blip(620, 900, 0.06, 'sine', 0.1); }
  coin() { this._blip(880, 1500, 0.11, 'sine', 0.14); }
  mission() {
    if (!this.ready || !this.enabled) return;
    const notes = [523, 659, 784, 1046];
    notes.forEach((f, i) => setTimeout(() => this._blip(f, f, 0.18, 'triangle', 0.12), i * 90));
  }

  horn() {
    if (!this.ready || !this.enabled) return;
    const ctx = this.ctx, t = ctx.currentTime;
    const g = ctx.createGain(); g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.22, t + 0.02);
    g.gain.setValueAtTime(0.22, t + 0.3);
    g.gain.exponentialRampToValueAtTime(0.0008, t + 0.42);
    g.connect(this.nodes.sfxBus);
    for (const f of [392, 494]) {
      const o = ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.value = f;
      o.connect(g); o.start(t); o.stop(t + 0.45);
    }
  }

  crash(intensity) {
    if (!this.ready || !this.enabled) return;
    const ctx = this.ctx, t = ctx.currentTime;
    const src = ctx.createBufferSource(); src.buffer = this.nodes.noiseBuf;
    const f = ctx.createBiquadFilter(); f.type = 'lowpass';
    f.frequency.setValueAtTime(1600, t);
    f.frequency.exponentialRampToValueAtTime(110, t + 0.35);
    const g = ctx.createGain();
    const amp = Math.min(0.7, 0.22 + intensity * 0.55);
    g.gain.setValueAtTime(amp, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.42);
    src.connect(f); f.connect(g); g.connect(this.nodes.sfxBus);
    src.start(t); src.stop(t + 0.45);
    this._blip(90, 40, 0.25, 'sine', amp * 0.6);
  }

  nitroBurst() {
    if (!this.ready || !this.enabled) return;
    const ctx = this.ctx, t = ctx.currentTime;
    const src = ctx.createBufferSource(); src.buffer = this.nodes.noiseBuf;
    const f = ctx.createBiquadFilter(); f.type = 'bandpass';
    f.frequency.setValueAtTime(400, t);
    f.frequency.exponentialRampToValueAtTime(2400, t + 0.3);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.22, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.4);
    src.connect(f); f.connect(g); g.connect(this.nodes.sfxBus);
    src.start(t); src.stop(t + 0.42);
  }

  /* ---------------- per-frame ---------------- */
  update(dt, st) {
    if (!this.ready || !this.running) return;
    const n = this.nodes, t = this.ctx.currentTime;
    const { rpm, throttle, speedKmh, gear, drift, nitro, rain, siren, gearCount } = st;

    const limit = this.redline;
    const rpmFrac = AD.clamp(rpm / limit, 0, 1.05);
    const electric = this.cyl === 0;

    if (electric) {
      const base = 120 + rpmFrac * 900;
      n.oscs[0].frequency.setTargetAtTime(base, t, 0.04);
      n.oscs[1].frequency.setTargetAtTime(base * 2.01, t, 0.04);
      n.oscs[2].frequency.setTargetAtTime(base * 3.02, t, 0.04);
      n.oscs[3].frequency.setTargetAtTime(base * 0.5, t, 0.04);
      n.oscs[4].frequency.setTargetAtTime(base * 4.01, t, 0.04);
    } else {
      const base = Math.max(26, (rpm / 60) * Math.max(1.4, this.cyl / 4));
      const harmonics = [0.5, 1, 1.5, 2, 3];
      for (let i = 0; i < n.oscs.length; i++) {
        n.oscs[i].frequency.setTargetAtTime(base * harmonics[i], t, 0.025);
      }
    }

    const load = 0.25 + throttle * 0.75;
    const gearBoost = gearCount > 1 ? 1 : 0.85;
    n.engineGain.gain.setTargetAtTime((0.28 + 0.5 * load) * (rpmFrac * 0.55 + 0.45) * gearBoost, t, 0.05);
    n.engineFilter.frequency.setTargetAtTime(500 + rpmFrac * 2800 + throttle * 1000, t, 0.06);
    n.rumbleGain.gain.setTargetAtTime((electric ? 0.02 : 0.06) + load * 0.2 * rpmFrac, t, 0.06);

    const v = AD.clamp(speedKmh / 300, 0, 1);
    n.windGain.gain.setTargetAtTime(v * v * 0.42, t, 0.1);
    n.tireGain.gain.setTargetAtTime(v * 0.14, t, 0.1);

    n.skidGain.gain.setTargetAtTime(AD.clamp(drift, 0, 1) * 0.3, t, 0.06);
    n.rainGain.gain.setTargetAtTime(AD.clamp(rain, 0, 1) * 0.16, t, 0.2);
    n.nitroGain.gain.setTargetAtTime(nitro ? 0.13 : 0, t, 0.06);

    // siren warble
    if (siren && this.enabled) {
      const wobble = Math.sin(performance.now() / 190) > 0 ? 880 : 620;
      n.siren.frequency.setTargetAtTime(wobble, t, 0.05);
      n.sirenGain.gain.setTargetAtTime(0.055, t, 0.08);
    } else {
      n.sirenGain.gain.setTargetAtTime(0, t, 0.1);
    }
  }
}
