'use strict';
/* ===== Audio: synthesized music, engine, siren, gunshots, impacts, rain. No sound files are needed. ===== */
const AUD = { ctx: null, master: null, music: null, sfx: null, noise: null, engine: null, siren: null, rain: null, timer: null, next: 0, step: 0, ready: false, muted: false };
// progression Am, F, C, G: [bass note, chord tones] as MIDI numbers
const CHORDS = [[45, [57, 60, 64]], [41, [53, 57, 60]], [48, [60, 64, 67]], [43, [55, 59, 62]]];
const midiHz = m => 440 * Math.pow(2, (m - 69) / 12);

function audioInit() {
  if (AUD.ready) { if (AUD.ctx.state === 'suspended') AUD.ctx.resume(); return; }
  try {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return;
    const c = new Ctx(); AUD.ctx = c;
    AUD.master = c.createGain(); AUD.master.gain.value = AUD.muted ? 0 : .9; AUD.master.connect(c.destination);
    AUD.music = c.createGain(); AUD.music.gain.value = .3; AUD.music.connect(AUD.master);
    AUD.sfx = c.createGain(); AUD.sfx.gain.value = .8; AUD.sfx.connect(AUD.master);
    const nb = c.createBuffer(1, c.sampleRate * 2, c.sampleRate), d = nb.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    AUD.noise = nb;
    // engine: saw + square through a lowpass, pitch follows speed
    const o1 = c.createOscillator(), o2 = c.createOscillator(), lp = c.createBiquadFilter(), eg = c.createGain();
    o1.type = 'sawtooth'; o2.type = 'square'; o1.frequency.value = 42; o2.frequency.value = 21;
    lp.type = 'lowpass'; lp.frequency.value = 500; lp.Q.value = 3;
    eg.gain.value = 0; o1.connect(lp); o2.connect(lp); lp.connect(eg); eg.connect(AUD.sfx); o1.start(); o2.start();
    AUD.engine = { o1, o2, lp, g: eg };
    // police siren
    const so = c.createOscillator(), sg = c.createGain();
    so.type = 'triangle'; so.frequency.value = 700; sg.gain.value = 0; so.connect(sg); sg.connect(AUD.sfx); so.start();
    AUD.siren = { o: so, g: sg, hi: false, t: 0 };
    // rain / wind bed
    const rs = c.createBufferSource(); rs.buffer = nb; rs.loop = true;
    const rf = c.createBiquadFilter(); rf.type = 'highpass'; rf.frequency.value = 2400;
    const rg = c.createGain(); rg.gain.value = 0;
    rs.connect(rf); rf.connect(rg); rg.connect(AUD.sfx); rs.start();
    AUD.rain = rg;
    AUD.next = c.currentTime + .1; AUD.step = 0;
    AUD.timer = setInterval(musicSchedule, 25);
    AUD.ready = true;
  } catch (e) { AUD.ready = false; }
}

function audioSetMuted(m) {
  AUD.muted = m;
  if (AUD.master) AUD.master.gain.setTargetAtTime(m ? 0 : .9, AUD.ctx.currentTime, .05);
}

/* ---------- music: a looping 112 BPM groove ---------- */
function envelope(g, t, a, peak, dur) {
  g.gain.setValueAtTime(.0001, t);
  g.gain.exponentialRampToValueAtTime(peak, t + a);
  g.gain.exponentialRampToValueAtTime(.0001, t + dur);
}
function musicSchedule() {
  if (!AUD.ready) return;
  const c = AUD.ctx, stepDur = 60 / 112 / 4;
  while (AUD.next < c.currentTime + .12) { playStep(AUD.step, AUD.next); AUD.next += stepDur; AUD.step++; }
}
function playStep(s, t) {
  const bar = Math.floor(s / 16) % 4, sp = s % 16, ch = CHORDS[bar];
  if (sp % 4 === 0) kick(t);
  if (sp % 4 === 2) hat(t);
  if (sp % 2 === 0) bassNote(ch[0] + (sp % 8 === 4 ? 12 : 0), t);
  arpNote(ch[1][sp % 3] + 12, t);
}
function kick(t) {
  const c = AUD.ctx, o = c.createOscillator(), g = c.createGain();
  o.frequency.setValueAtTime(130, t); o.frequency.exponentialRampToValueAtTime(40, t + .14);
  envelope(g, t, .005, .9, .25); o.connect(g); g.connect(AUD.music); o.start(t); o.stop(t + .26);
}
function hat(t) {
  const c = AUD.ctx, s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
  s.buffer = AUD.noise; f.type = 'highpass'; f.frequency.value = 7500;
  envelope(g, t, .002, .25, .05); s.connect(f); f.connect(g); g.connect(AUD.music); s.start(t, Math.random()); s.stop(t + .06);
}
function bassNote(m, t) {
  const c = AUD.ctx, o = c.createOscillator(), f = c.createBiquadFilter(), g = c.createGain();
  o.type = 'sawtooth'; o.frequency.value = midiHz(m);
  f.type = 'lowpass'; f.frequency.value = 420;
  envelope(g, t, .01, .35, .2); o.connect(f); f.connect(g); g.connect(AUD.music); o.start(t); o.stop(t + .22);
}
function arpNote(m, t) {
  const c = AUD.ctx, o = c.createOscillator(), g = c.createGain();
  o.type = 'triangle'; o.frequency.value = midiHz(m);
  envelope(g, t, .005, .14, .14); o.connect(g); g.connect(AUD.music); o.start(t); o.stop(t + .15);
}

/* ---------- engine, siren, rain ---------- */
function audioEngine(on, speed, thr) {
  if (!AUD.ready) return;
  const e = AUD.engine, t = AUD.ctx.currentTime, f = 42 + speed * 2.4 + thr * 16;
  e.o1.frequency.setTargetAtTime(f, t, .06);
  e.o2.frequency.setTargetAtTime(f * .5, t, .06);
  e.lp.frequency.setTargetAtTime(420 + speed * 12 + thr * 260, t, .08);
  e.g.gain.setTargetAtTime(on ? .045 + thr * .05 + Math.min(.03, speed * .0012) : 0, t, .12);
}
function audioSiren(on, dt) {
  if (!AUD.ready) return;
  const s = AUD.siren, t = AUD.ctx.currentTime;
  s.g.gain.setTargetAtTime(on ? .03 : 0, t, .15);
  if (on) {
    s.t += dt;
    if (s.t > .55) { s.t = 0; s.hi = !s.hi; s.o.frequency.setTargetAtTime(s.hi ? 960 : 700, t, .03); }
  }
}
function audioRain(level) { if (AUD.ready) AUD.rain.gain.setTargetAtTime(level * .1, AUD.ctx.currentTime, .3); }

/* ---------- one-shot effects ---------- */
function noiseHit(type, freq, q, vol, dur) {
  if (!AUD.ready) return;
  const c = AUD.ctx, t = c.currentTime, s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
  s.buffer = AUD.noise; f.type = type; f.frequency.value = freq; f.Q.value = q;
  envelope(g, t, .002, vol, dur);
  s.connect(f); f.connect(g); g.connect(AUD.sfx); s.start(t, Math.random()); s.stop(t + dur + .05);
}
function audioShot() { noiseHit('bandpass', 1800, .7, .7, .16); noiseHit('lowpass', 500, 1, .5, .08); }
function audioBoom() { noiseHit('lowpass', 500, 1, 1, .9); }
function audioHit() {
  if (!AUD.ready) return;
  const c = AUD.ctx, t = c.currentTime, o = c.createOscillator(), g = c.createGain();
  o.frequency.setValueAtTime(220, t); o.frequency.exponentialRampToValueAtTime(90, t + .15);
  envelope(g, t, .003, .4, .18); o.connect(g); g.connect(AUD.sfx); o.start(t); o.stop(t + .2);
}
