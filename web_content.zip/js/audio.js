/* جنة القرآن v6 — القرّاء الإضافيون والمشغّل المتقدم */
'use strict';
/* REC: [المعرّف، الاسم، مسار مجلد mp3quran أو null، مجلد everyayah أو null، قائمة السور المتاحة أو null] */
const EA=[
['ea.basit_m','عبد الباسط عبد الصمد (مجوّد)','Abdul_Basit_Mujawwad_128kbps'],
['ea.basfar','عبد الله بصفر','Abdullah_Basfar_192kbps'],
['ea.budair','صلاح البدير','Salah_Al_Budair_128kbps'],
['ea.qatami','ناصر القطامي','Nasser_Alqatami_128kbps'],
['ea.qahtani','خالد القحطاني','Khaalid_Abdullaah_al-Qahtaanee_192kbps'],
['ea.rifai','هاني الرفاعي','Hani_Rifai_192kbps'],
['ea.ghamdi','سعد الغامدي','Ghamadi_40kbps'],
['ea.qasim','محسن القاسم','Muhsin_Al_Qasim_192kbps'],
['ea.tablawi','محمد الطبلاوي','Mohammad_al_Tablaway_128kbps'],
['ea.husary_m','محمود خليل الحصري (مجوّد)','Husary_Mujawwad_128kbps'],
['ea.husary_t','محمود خليل الحصري (معلّم)','Husary_Muallim_128kbps'],
['ea.minsh_m','محمد صديق المنشاوي (مجوّد)','Minshawy_Mujawwad_192kbps'],
['ea.akhdar','إبراهيم الأخضر','Ibrahim_Akhdar_32kbps'],
['ea.bukhatir','صلاح بو خاطر','Salaah_AbdulRahman_Bukhatir_128kbps'],
['ea.juhany','عبد الله عوّاد الجهني','Abdullaah_3awwaad_Al-Juhaynee_128kbps'],
['ea.mustafa','مصطفى إسماعيل','Mustafa_Ismail_48kbps'],
['ea.jaber','علي جابر','Ali_Jaber_64kbps'],
['ea.fares','فارس عبّاد','Fares_Abbad_64kbps'],
['ea.ayman','أيمن سويد','Ayman_Sowaid_64kbps'],
['ea.matroud','عبد الله المطرود','Abdullah_Matroud_128kbps'],
['ea.neana','أحمد نعينع','Ahmed_Neana_128kbps'],
['ea.alaqimy','أكرم العلاقمي','Akram_AlAlaqimy_128kbps'],
['ea.sahl','سهل ياسين','Sahl_Yassin_128kbps'],
['ea.salamah','ياسر سلامة','Yaser_Salamah_128kbps'],
['ea.tunaiji','خليفة الطنيجي','Khalefa_Al_Tunaiji_64kbps'],
['ea.suesy','علي الحجّاج السويسي','Ali_Hajjaj_AlSuesy_128kbps'],
['ea.mansoori','كريم منصوري','Karim_Mansoori_40kbps'],
['ea.nabil','نبيل الرفاعي','Nabil_Rifa3i_48kbps']];
EA.forEach(e=>REC.push([e[0],e[1],null,e[2],null]));
const CDN_IDS=new Set(REC.slice(0,13).map(r=>r[0]).filter(x=>x.startsWith('ar.')));
/* قرّاء mp3quran (تُجلب قائمتهم الكاملة من الإنترنت وتُخزَّن أسبوعًا) */
function mergeMq(list){const have=new Set(REC.map(r=>(r[2]||'').toLowerCase()));let n=0;
  list.forEach(x=>{if(have.has(x[2].toLowerCase()))return;have.add(x[2].toLowerCase());REC.push(x);n++});
  const id=ls.get('recid');if(id){const i=REC.findIndex(r=>r[0]==id);if(i>=0)S.rec=i}return n}
async function loadMq(){try{let c=ls.get('mq:rec');
  if(!c||Date.now()-c.t>6048e5){const r=await fetch('https://mp3quran.net/api/v3/reciters?language=ar');const j=await r.json();const out=[];
    (j.reciters||[]).forEach(rc=>(rc.moshaf||[]).forEach(m=>{const tot=+m.surah_total||0;if(!m.server||tot<20)return;
      const srv=m.server.replace(/^https?:\/\//,'').replace(/\/+$/,'');const lst=tot>=114?null:String(m.surah_list||'').split(',').map(Number).filter(Boolean);
      const rw=/حفص/.test(m.name||'')?'':' — '+String(m.name||'').replace(/^المصحف\s*/,'').replace(/^.*?-\s*/,'').slice(0,28);
      out.push(['mq.'+m.id,rc.name+rw,srv,null,lst])}));
    c={t:Date.now(),l:out};if(out.length)ls.set('mq:rec',c)}
  if(c&&c.l)mergeMq(c.l)}catch(e){const c=ls.get('mq:rec');if(c&&c.l)mergeMq(c.l)}}
{const c=ls.get('mq:rec');if(c&&c.l)mergeMq(c.l)}
{const id=ls.get('recid');if(id){const i=REC.findIndex(r=>r[0]==id);if(i>=0)S.rec=i}}
loadMq();
/* اختيار القارئ مع بحث */
function recPicker(cb){openSheet(`<h3>🎙 اختر القارئ</h3><input class="in" id="rpq" placeholder="ابحث عن قارئ… (${AR(REC.length)} قارئًا)"><div id="rpl"></div>`);
  const draw=()=>{const q=norm($('#rpq').value);$('#rpl').innerHTML=REC.map((r,i)=>[r,i]).filter(x=>!q||norm(x[0][1]).includes(q)).slice(0,80).map(x=>`<div class="sr" onclick="pickRec(${x[1]})"><div class="f1"><div class="t">${esc(x[0][1])}</div><div class="sub" style="text-align:right">${x[0][2]?'سور كاملة':'آيات'}${x[0][4]?' · '+AR(x[0][4].length)+' سورة':''}</div></div>${x[1]==S.rec?'✅':''}</div>`).join('')||'<p class="mt">لا نتائج</p>'};
  $('#rpq').oninput=draw;draw();window._rpcb=cb}
function pickRec(i){S.rec=i;ls.set('rec',i);closeSheet();toast('🎙 '+REC[i][1]);if(window._rpcb)window._rpcb(i);document.querySelectorAll('select').forEach(s=>{if(s.id=='rr')s.value=i})}
/* ---------- المشغّل ---------- */
const SPD=[0.75,1,1.25,1.5,2];S.spd=ls.get('spd',1);au.defaultPlaybackRate=S.spd;
S.rm=ls.get('rmode',0);S.an=ls.get('autonext',true);let WARNED=0,SKIPSAVE=0;
$('#player').innerHTML=`<button id="pv" onclick="pPrev()">⏮</button><button id="pp" onclick="tp()">⏸</button><button id="pn_" onclick="pNext()">⏭</button><span id="pt"></span><button id="psp" class="sp" onclick="cycSpd()"></button><button id="prm" onclick="cycRm()"></button><button onclick="recPicker()">🎙</button><button onclick="sleepT()">⏲</button><button onclick="stopP()">✕</button><div class="pr2"><small id="pc">0:00</small><input id="ps" type="range" min="0" max="1000" value="0"><small id="pd">0:00</small></div>`;
const fmt=t=>isFinite(t)?Math.floor(t/60)+':'+z2(Math.floor(t%60)):'0:00';
function uiP(){$('#psp').textContent=AR(S.spd)+'×';$('#prm').textContent=['➡️','🔂','🔁'][S.rm];$('#prm').title=['بدون تكرار','تكرار السورة/المقطع','تكرار القائمة']}
function cycSpd(){S.spd=SPD[(SPD.indexOf(S.spd)+1)%SPD.length];ls.set('spd',S.spd);au.defaultPlaybackRate=au.playbackRate=S.spd;uiP()}
function cycRm(){S.rm=(S.rm+1)%3;ls.set('rmode',S.rm);uiP();toast(['بدون تكرار','تكرار السورة الحالية','تكرار قائمة التشغيل'][S.rm])}
uiP();
au.addEventListener('loadedmetadata',()=>{au.playbackRate=S.spd;if(S._seek){au.currentTime=Math.min(S._seek,au.duration||S._seek);S._seek=0}});
au.addEventListener('timeupdate',()=>{const sl=$('#ps');if(!sl||S._drag)return;if(au.duration>0)sl.value=au.currentTime/au.duration*1000;$('#pc').textContent=fmt(au.currentTime);$('#pd').textContent=fmt(au.duration);
  if(cur&&Date.now()-SKIPSAVE>4000){SKIPSAVE=Date.now();saveRes()}});
$('#ps').oninput=()=>{S._drag=1;$('#pc').textContent=fmt($('#ps').value/1000*au.duration)};
$('#ps').onchange=()=>{if(au.duration>0)au.currentTime=$('#ps').value/1000*au.duration;S._drag=0};
function saveRes(){if(!cur)return;const r=REC[S.rec];ls.set('ares',{m:cur.m,s:cur.s,a:cur.a||0,n:cur.n||0,t:cur.m=='f'?au.currentTime:0,rid:r[0],full:!!cur.full,ts:Date.now()})}
function resumeListen(){const o=ls.get('ares');if(!o)return toast('لا يوجد استماع سابق');const i=REC.findIndex(r=>r[0]==o.rid);if(i>=0){S.rec=i;ls.set('rec',i)}
  if(o.m=='f'){S._seek=o.t;playFull(o.s)}else{playAyah(o.s,o.a,o.n,1,o.full)}}
/* رابط الصوت */
function ayahUrl(r,s,a,g){if(r[3])return`https://everyayah.com/data/${r[3]}/${pad(s)}${pad(a)}.mp3`;
  if(r[0]=='ev.yasser')return`https://everyayah.com/data/Yasser_Ad-Dussary_128kbps/${pad(s)}${pad(a)}.mp3`;
  if(CDN_IDS.has(r[0]))return`https://cdn.islamic.network/quran/audio/128/${r[0]}/${g}.mp3`;
  if(!WARNED){WARNED=1;toast('تلاوة الآيات المنفردة متاحة لقرّاء محددين، استُخدم العفاسي')}return`https://cdn.islamic.network/quran/audio/128/ar.alafasy/${g}.mp3`}
const hasFull=r=>!!r[2];
/* تشغيل سورة كاملة */
function playFull(s,pl){const r=REC[S.rec];
  if(r[4]&&!r[4].includes(s))return toast('هذه السورة غير متوفرة بصوت '+r[1]+'، اختر قارئًا آخر');
  if(!hasFull(r)){playAyah(s,1,0,1,true);return}
  cur={m:'f',s,pl:!!pl,full:true};document.querySelectorAll('.ay.on').forEach(e=>e.classList.remove('on'));showP('🎧 '+nm(s)+' · '+r[1]);
  const u=`https://${r[2]}/${pad(s)}.mp3`;logPos('listen',{s});
  try{caches.match(u).then(m=>m?m.blob():null).then(b=>run(b?URL.createObjectURL(b):u)).catch(()=>run(u))}catch(e){run(u)}}
async function playAyah(s,a,end,rep,full){try{const d=await api('/surah/'+s+'/quran-uthmani'),r=REC[S.rec],g=d.ayahs[a-1].number;
  const pl=cur&&cur.pl&&cur.full,cont=cur&&cur.m=='a'&&cur.s==s&&a==cur.a+1;cur={m:'a',s,a,a0:cont?cur.a0:a,n:end||d.numberOfAyahs,r:rep||1,k:1,full:!!full||(!end),pl:pl&&!!full};
  document.querySelectorAll('.ay.on').forEach(e=>e.classList.remove('on'));const e=$('#a'+a);if(e&&S.cur==s)e.classList.add('on');
  showP('🎧 '+nm(s)+' · آية '+AR(a)+' · '+r[1]);logPos('listen',{s,a});run(ayahUrl(r,s,a,g))}catch(e){toast('تعذّر تشغيل الآية')}}
function logPos(k,v){const p=ls.get('pos',{});p[k]=v;p[k+'_t']=Date.now();ls.set('pos',p)}
/* نهاية المقطع */
function endItem(){const P=ls.get('pl',{items:[],i:-1});
  if(S.rm==1&&cur){if(cur.m=='f')return playFull(cur.s,cur.pl);return playAyah(cur.s,cur.a0,cur.full?0:cur.n,cur.r,cur.full)}
  if(cur&&cur.pl&&P.items.length){let i=P.i+1;if(i>=P.items.length){if(S.rm==2)i=0;else{$('#pp').textContent='▶';return}}P.i=i;ls.set('pl',P);return playFull(P.items[i],true)}
  if(cur&&cur.full&&S.an&&cur.s<114)return playFull(cur.s+1);
  $('#pp').textContent='▶'}
au.onended=()=>{if(cur){logAdd('done',0);if(cur.m=='a'){if(cur.k<cur.r){cur.k++;au.currentTime=0;au.play();return}if(cur.a<cur.n){cur.k=1;playAyah(cur.s,cur.a+1,cur.n,cur.r,cur.full);return}}endItem();return}$('#pp').textContent='▶'};
function pNext(){if(!cur)return;const P=ls.get('pl',{items:[],i:-1});
  if(cur.pl&&P.items.length){P.i=(P.i+1)%P.items.length;ls.set('pl',P);return playFull(P.items[P.i],true)}
  if(cur.m=='a'&&!cur.full)return cur.a<cur.n?playAyah(cur.s,cur.a+1,cur.n,cur.r):toast('آخر آية في المقطع');
  if(cur.m=='a'&&cur.a<S.cnt[cur.s-1])return playAyah(cur.s,cur.a+1,0,1,true);
  if(cur.s<114)playFull(cur.s+1)}
function pPrev(){if(!cur)return;const P=ls.get('pl',{items:[],i:-1});if(au.currentTime>4&&cur.m=='f'){au.currentTime=0;return}
  if(cur.pl&&P.items.length){P.i=(P.i-1+P.items.length)%P.items.length;ls.set('pl',P);return playFull(P.items[P.i],true)}
  if(cur.m=='a')return cur.a>1?playAyah(cur.s,cur.a-1,cur.full?0:cur.n,cur.r,cur.full):toast('أول آية');
  if(cur.s>1)playFull(cur.s-1)}
try{const ms=navigator.mediaSession;ms.setActionHandler('nexttrack',pNext);ms.setActionHandler('previoustrack',pPrev);ms.setActionHandler('seekto',e=>{au.currentTime=e.seekTime})}catch(e){}
/* ---------- قائمة التشغيل ---------- */
const PLP=[['الجزء ٣٠ (النبأ → الناس)',()=>rng(78,114)],['المعوذات والإخلاص',()=>[112,113,114]],['الكهف · يس · الملك',()=>[18,36,67]],['الأكثر قراءةً',()=>[1,2,18,36,55,56,67,112,113,114]],['القرآن كاملًا',()=>rng(1,114)]];
const rng=(a,b)=>Array.from({length:b-a+1},(_,i)=>a+i);
function plAdd(s){const P=ls.get('pl',{items:[],i:-1});P.items.push(s);ls.set('pl',P);toast('أُضيفت «'+nm(s)+'» إلى قائمة التشغيل')}
async function playlist(){await names();enter('more');const P=ls.get('pl',{items:[],i:-1});
  v.innerHTML=head('🎶 قائمة التشغيل')+`<div class="sub">${AR(P.items.length)} سورة · القارئ: ${esc(REC[S.rec][1])}</div>
  <div class="row"><button class="b" onclick="plPlay(0)" ${P.items.length?'':'disabled'}>▶ تشغيل القائمة</button><button class="o" onclick="cycRm()">${['➡️ بدون تكرار','🔂 تكرار','🔁 تكرار القائمة'][S.rm]}</button><button class="o" onclick="recPicker(playlist)">🎙 القارئ</button></div>
  <label class="lb"><input type="checkbox" ${S.an?'checked':''} onchange="S.an=this.checked;ls.set('autonext',S.an)"> الانتقال التلقائي للسورة التالية عند انتهاء السورة</label>
  <div id="pli">${P.items.map((s,i)=>`<div class="sr"><div class="f1" onclick="plPlay(${i})"><div class="t">${i==P.i?'▶ ':''}${AR(i+1)}. ${esc(nm(s))}</div></div><button class="o" onclick="plMv(${i},-1)">▲</button><button class="o" onclick="plMv(${i},1)">▼</button><button class="o" onclick="plRm(${i})">✕</button></div>`).join('')||'<p class="mt">القائمة فارغة، أضف سورًا من الأسفل</p>'}</div>
  <h3>إضافة سريعة</h3><div>${PLP.map((p,i)=>`<span class="chip" onclick="plPre(${i})">${p[0]}</span>`).join('')}</div>
  <label class="lb">إضافة سورة</label><div class="row"><select id="pls">${surahOpts(1)}</select><button class="b" onclick="plAdd(+$('#pls').value);playlist()">＋ أضف</button></div>
  <button class="o w" onclick="ls.set('pl',{items:[],i:-1});playlist()">🗑 تفريغ القائمة</button>`}
function plPre(i){const P=ls.get('pl',{items:[],i:-1});P.items=P.items.concat(PLP[i][1]());ls.set('pl',P);playlist()}
function plPlay(i){const P=ls.get('pl',{items:[],i:-1});if(!P.items.length)return;P.i=i;ls.set('pl',P);playFull(P.items[i],true)}
function plMv(i,d){const P=ls.get('pl',{items:[],i:-1}),j=i+d;if(j<0||j>=P.items.length)return;[P.items[i],P.items[j]]=[P.items[j],P.items[i]];ls.set('pl',P);playlist()}
function plRm(i){const P=ls.get('pl',{items:[],i:-1});P.items.splice(i,1);P.i=-1;ls.set('pl',P);playlist()}
/* تكرار آية أو مجموعة آيات */
async function repeatUI(s,a){await names();const n=S.cnt[s-1];openSheet(`<h3>🔁 تكرار آيات</h3><div class="sub">${esc(nm(s))}</div><div class="row"><div><label class="lb">من</label><input id="rpa" class="in" type="number" min="1" max="${n}" value="${a}"></div><div><label class="lb">إلى</label><input id="rpb" class="in" type="number" min="1" max="${n}" value="${a}"></div><div><label class="lb">مرّات</label><select id="rpn" class="w">${[2,3,5,7,10,20,33,100].map(x=>`<option>${x}</option>`).join('')}</select></div></div><button class="b w" onclick="goRep(${s})">▶ ابدأ التكرار</button>`)}
function goRep(s){const n=S.cnt[s-1],a=+$('#rpa').value,b=Math.min(n,+$('#rpb').value),k=+$('#rpn').value;if(!(a>=1&&b>=a))return toast('تأكد من أرقام الآيات');closeSheet();playAyah(s,a,b,k)}
