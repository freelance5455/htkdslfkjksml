// Simple Web Audio API sound manager (no external files needed)
const AudioManager = {
  ctx: null,
  volume: 0.7,
  enabled: true,

  init() {
    try {
      this.ctx = new (window.AudioContext || window.webkitAudioContext)();
    } catch (e) {
      console.warn('Audio not supported');
      this.enabled = false;
    }
  },

  setVolume(v) {
    this.volume = Utils.clamp(v, 0, 1);
  },

  playTone(freq, duration, type = 'square', vol = 0.3) {
    if (!this.enabled || !this.ctx) return;
    if (this.ctx.state === 'suspended') this.ctx.resume();

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = type;
    osc.frequency.value = freq;
    gain.gain.value = vol * this.volume;
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + duration);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start();
    osc.stop(this.ctx.currentTime + duration);
  },

  shoot(weaponType) {
    if (weaponType === 'sniper') {
      this.playTone(180, 0.25, 'sawtooth', 0.4);
      setTimeout(() => this.playTone(80, 0.15, 'square', 0.2), 40);
    } else if (weaponType === 'shotgun') {
      this.playTone(120, 0.18, 'sawtooth', 0.45);
      this.playTone(90, 0.12, 'square', 0.3);
    } else if (weaponType === 'smg') {
      this.playTone(320, 0.06, 'square', 0.25);
    } else {
      this.playTone(220, 0.1, 'square', 0.3);
    }
  },

  reload() {
    this.playTone(400, 0.08, 'triangle', 0.2);
    setTimeout(() => this.playTone(300, 0.1, 'triangle', 0.15), 120);
  },

  hit() {
    this.playTone(150, 0.08, 'sawtooth', 0.25);
  },

  damage() {
    this.playTone(90, 0.2, 'sawtooth', 0.35);
  },

  pickup() {
    this.playTone(600, 0.08, 'sine', 0.2);
    setTimeout(() => this.playTone(800, 0.1, 'sine', 0.15), 80);
  },

  zoneWarning() {
    this.playTone(200, 0.3, 'triangle', 0.15);
  },

  win() {
    [400, 500, 600, 800].forEach((f, i) => {
      setTimeout(() => this.playTone(f, 0.2, 'sine', 0.25), i * 150);
    });
  },

  lose() {
    this.playTone(150, 0.4, 'sawtooth', 0.3);
    setTimeout(() => this.playTone(100, 0.5, 'sawtooth', 0.25), 200);
  }
};
