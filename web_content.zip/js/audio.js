"use strict";

const Sound = (() => {
  let ctx = null;

  function getContext() {
    if (!ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return null;
      try {
        ctx = new AudioCtx();
      } catch (error) {
        return null;
      }
    }
    if (ctx.state === "suspended") ctx.resume();
    return ctx;
  }

  function enabled() {
    const prefs = Prefs.get();
    return prefs.sound && prefs.volume > 0;
  }

  function tone(options) {
    const c = getContext();
    if (!c) return;
    const { freq, to, type = "sine", start = 0, dur = 0.2, gain = 0.3 } = options;
    const t0 = c.currentTime + start;
    const volume = Math.max(0.0002, (gain * Prefs.get().volume) / 100);

    const osc = c.createOscillator();
    const amp = c.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t0);
    if (to) osc.frequency.exponentialRampToValueAtTime(to, t0 + dur);

    amp.gain.setValueAtTime(0.0001, t0);
    amp.gain.exponentialRampToValueAtTime(volume, t0 + 0.02);
    amp.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);

    osc.connect(amp);
    amp.connect(c.destination);
    osc.start(t0);
    osc.stop(t0 + dur + 0.05);
  }

  const SOUNDS = {
    tap() {
      tone({ freq: 520, to: 380, dur: 0.08, type: "triangle", gain: 0.25 });
    },
    reveal() {
      tone({ freq: 220, to: 880, dur: 0.45, type: "triangle", gain: 0.3 });
      tone({ freq: 660, start: 0.3, dur: 0.5, gain: 0.2 });
      tone({ freq: 990, start: 0.35, dur: 0.5, gain: 0.15 });
    },
    night() {
      tone({ freq: 110, to: 82, dur: 1.4, gain: 0.4 });
      tone({ freq: 165, to: 123, dur: 1.4, gain: 0.25 });
      tone({ freq: 55, dur: 1.6, gain: 0.3 });
    },
    day() {
      [392, 494, 587, 784].forEach((freq, i) => {
        tone({ freq, start: i * 0.12, dur: 0.35, type: "triangle", gain: 0.28 });
      });
    },
    vote() {
      tone({ freq: 160, to: 90, dur: 0.12, type: "square", gain: 0.22 });
      tone({ freq: 140, to: 80, start: 0.1, dur: 0.12, type: "square", gain: 0.2 });
    },
    win() {
      [523, 659, 784, 1047, 784, 1047].forEach((freq, i) => {
        tone({ freq, start: i * 0.15, dur: 0.3, gain: 0.3 });
      });
    },
  };

  function play(name) {
    if (!enabled()) return;
    const fn = SOUNDS[name];
    if (!fn) return;
    try {
      fn();
    } catch (error) {
      /* الصوت اختياري ولا يجب أن يوقف اللعبة */
    }
  }

  const SCREEN_SOUNDS = {
    "reveal-handover": "tap",
    "reveal-transition": "tap",
    "night-intro": "night",
    "night-handover": "tap",
    "night-transition": "tap",
    "night-dawn": "day",
    "day-vote-handover": "tap",
    "day-vote-transition": "vote",
    win: "win",
  };

  function onScreen(name) {
    const sound = SCREEN_SOUNDS[name];
    if (sound) play(sound);
  }

  function init() {
    UI.onScreen(onScreen);
    const card = document.getElementById("flip-card");
    if (card) {
      card.addEventListener("click", () => {
        if (!card.classList.contains("flipped")) play("reveal");
      });
    }
  }

  return { init, play };
})();