const Aud=(()=>{
let c,mg,wind,dg,pan,pg,L,NB,mbOn=0;
const sp=(p,x,y,z)=>{if(p.positionX){p.positionX.value=x;p.positionY.value=y;p.positionZ.value=z}else p.setPosition(x,y,z)};
const o=(type,f,t,d,v,dest,f2)=>{const x=c.createOscillator(),g=c.createGain();x.type=type;x.frequency.setValueAtTime(f,t);if(f2)x.frequency.exponentialRampToValueAtTime(f2,t+d);g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.0001,t+d);x.connect(g);g.connect(dest||mg);x.start(t);x.stop(t+d+.05)};
const thump=()=>{const t=c.currentTime;o('sine',70,t,.2,1,0,38);o('sine',60,t+.17,.18,.7,0,35)};
const violin=(d,v)=>{const t=c.currentTime;[740,1109,1480].forEach(f=>o('sawtooth',f,t,d,v,0,f*1.04))};
const init=()=>{if(c)return;
 c=(window.Howler&&Howler.ctx)||new(window.AudioContext||window.webkitAudioContext)();if(c.state!='running')c.resume();
 mg=c.createGain();mg.gain.value=.8;mg.connect(c.destination);L=c.listener;
 NB=c.createBuffer(1,c.sampleRate*2,c.sampleRate);const d=NB.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;
 const s=c.createBufferSource();s.buffer=NB;s.loop=true;const f=c.createBiquadFilter();f.type='bandpass';f.frequency.value=450;f.Q.value=.6;
 wind=c.createGain();wind.gain.value=.14;const lf=c.createOscillator(),lg=c.createGain();lf.frequency.value=.12;lg.gain.value=.08;lf.connect(lg);lg.connect(wind.gain);s.connect(f);f.connect(wind);wind.connect(mg);s.start();lf.start();
 dg=c.createGain();dg.gain.value=.05;const lp=c.createBiquadFilter();lp.type='lowpass';lp.frequency.value=220;
 [55,55.8].forEach(fr=>{const x=c.createOscillator();x.type='sawtooth';x.frequency.value=fr;x.connect(lp);x.start()});lp.connect(dg);dg.connect(mg);
 pan=c.createPanner();pan.panningModel='HRTF';pan.refDistance=2;pg=c.createGain();pg.gain.value=0;
 const go=c.createOscillator(),gf=c.createBiquadFilter(),vb=c.createOscillator(),vg=c.createGain();go.type='sawtooth';go.frequency.value=98;gf.type='lowpass';gf.frequency.value=500;vb.frequency.value=5;vg.gain.value=8;
 vb.connect(vg);vg.connect(go.frequency);go.connect(gf);gf.connect(pg);pg.connect(pan);pan.connect(mg);go.start();vb.start();
 const seq=[440,523,659,622,659,523,440,415];let n=0;
 setInterval(()=>{if(!mbOn||Math.random()<.2)return;const t=c.currentTime,f=seq[n++%8]*(Math.random()<.1?.5:1);o('sine',f,t,1.2,.07,0,f*.995);o('triangle',f*2,t,.6,.03)},520);
};
return{init,
 heart(cb,done){let t=0,g=1100;for(let i=0;i<8;i++){setTimeout(()=>{thump();cb((i+1)/8);if(i==7)setTimeout(done,700)},t);t+=g;g*=.86}},
 music(on){mbOn=on;wind.gain.setTargetAtTime(on?.05:.14,c.currentTime,.5)},
 threat(v){dg.gain.setTargetAtTime(.05+v*.2,c.currentTime,.3)},
 violin(){violin(.9,.1)},
 scream(d=1.4){const t=c.currentTime,s=c.createBufferSource();s.buffer=NB;const f=c.createBiquadFilter();f.type='bandpass';f.Q.value=3;f.frequency.setValueAtTime(900,t);f.frequency.exponentialRampToValueAtTime(3200,t+d);
  const g=c.createGain();g.gain.setValueAtTime(.9,t);g.gain.exponentialRampToValueAtTime(.001,t+d);s.connect(f);f.connect(g);g.connect(mg);s.start(t);s.stop(t+d);
  o('sawtooth',600,t,d,.3,0,1900);o('square',650,t,d,.15,0,2100)},
 scare(){violin(1.5,.2);this.scream(1.4)},
 beat:thump,
 step(){const t=c.currentTime,s=c.createBufferSource();s.buffer=NB;const f=c.createBiquadFilter();f.type='lowpass';f.frequency.value=600;const g=c.createGain();g.gain.setValueAtTime(.3,t);g.gain.exponentialRampToValueAtTime(.001,t+.14);s.connect(f);f.connect(g);g.connect(mg);s.start(t,Math.random(),.16)},
 pick(){o('sine',880,c.currentTime,.15,.2,0,1320)},
 ghost(p,on){sp(pan,p.x,p.y,p.z);pg.gain.setTargetAtTime(on?.35:0,c.currentTime,.2)},
 listen(p,yaw){const fx=-Math.sin(yaw),fz=-Math.cos(yaw);if(L.positionX){L.positionX.value=p.x;L.positionY.value=p.y;L.positionZ.value=p.z;L.forwardX.value=fx;L.forwardY.value=0;L.forwardZ.value=fz;L.upX.value=0;L.upY.value=1;L.upZ.value=0}else{L.setPosition(p.x,p.y,p.z);L.setOrientation(fx,0,fz,0,1,0)}},
 mute(m){mg.gain.value=m?0:.8}};
})();
