/* Account pages: Discover (search), public profile page, profile editor, audio player */
let discoverQ = '', discoverRes = null, pageId = null, pageData = null, pageDisc = [], coverUrls = {}, editState = null, pfPlayer = null, pfNow = null, pfTimer;
const MEDIA_URL = p => p ? sb.storage.from('profile-media').getPublicUrl(p).data.publicUrl : '';
const safeUrl = u => { try { const x = new URL(/^https?:\/\//i.test(u) ? u : 'https://' + u); return /^https?:$/.test(x.protocol) ? x.href : ''; } catch (e) { return ''; } };
const accentOf = a => /^#[0-9a-f]{6}$/i.test(a || '') ? a : '#d7bd72';
const PRESETS = ['#d7bd72', '#8caed8', '#539df5', '#7c83ff', '#b79af0', '#ff6fae', '#f3727f', '#ffa42b', '#eadb62', '#e8eeeb'];
function avatarHtml(p, size) {
  const u = MEDIA_URL(p.avatar_path);
  return `<span class="pf-avatar" style="width:${size}px;height:${size}px;font-size:${Math.round(size / 3)}px;background:${accentOf(p.accent)}">${u ? `<img loading="lazy" decoding="async" src="${esc(u)}" alt="">` : esc(String(p.display_name || '?').trim().slice(0, 2).toUpperCase())}</span>`;
}

/* ---------- Discover ---------- */
function discover() {
  return `<section class="page fade"><div class="page-heading"><p class="eyebrow">DISCOVER</p><h1>Find artists</h1><p class="sub">Search by name to see profiles, releases, music and links.</p></div><input id="disc-q" class="pf-search" placeholder="Search by name…" value="${esc(discoverQ)}" autocomplete="off"><div id="disc-results">${discoverList()}</div></section>`;
}
function discoverList() {
  if (discoverRes === null) return '<p class="muted">Loading…</p>';
  if (!discoverRes.length) return '<p class="muted">No accounts found.</p>';
  return `<div class="pf-grid">${discoverRes.map(p => `<button class="pf-card" data-pf="open-profile" data-id="${esc(p.id)}">${avatarHtml(p, 54)}<div><strong>${esc(p.display_name || 'Unnamed')}</strong><span>${esc(p.tagline || p.location || (p.role === 'label_admin' ? 'Label' : 'Artist'))}</span></div></button>`).join('')}</div>`;
}
async function runSearch(q) {
  discoverQ = q;
  const { data, error } = await sb.rpc('search_profiles', { p_q: q });
  if (q !== discoverQ) return;
  if (error) toast(error.message, 'error');
  discoverRes = error ? [] : (data || []);
  const el = $('#disc-results'); if (el) { el.innerHTML = discoverList(); bindProfiles(); }
}
function openDiscover() { view = 'discover'; mobile = false; discoverRes = null; render(); runSearch(discoverQ); }

/* ---------- Profile page ---------- */
async function openProfile(id) {
  pageId = id; pageData = null; pageDisc = []; coverUrls = {}; view = 'profile'; mobile = false; render(); window.scrollTo(0, 0);
  const [a, b] = await Promise.all([sb.rpc('get_profile', { p_id: id }), sb.rpc('profile_discography', { p_id: id })]);
  if (pageId !== id) return;
  const row = Array.isArray(a.data) ? a.data[0] : a.data;
  pageData = row || false; pageDisc = Array.isArray(b.data) ? b.data : [];
  const paths = pageDisc.map(r => r.artwork_path).filter(Boolean);
  if (paths.length) { const s = await sb.storage.from('artwork').createSignedUrls(paths, 3600); (s.data || []).forEach(x => { if (x.signedUrl) coverUrls[x.path] = x.signedUrl; }); }
  if (view === 'profile' && pageId === id) render();
}
function profilePage() {
  const back = `<button class="back-link" data-pf="discover">${icon('back', 16)} Discover</button>`;
  if (pageData === null) return `<section class="page fade">${back}<p class="muted">Loading…</p></section>`;
  if (pageData === false) return `<section class="page fade">${back}<p class="muted">This profile is not available.</p></section>`;
  const p = pageData, ac = accentOf(p.accent), banner = MEDIA_URL(p.banner_path), mine = p.id === session.user.id;
  const links = (Array.isArray(p.links) ? p.links : []).map(l => ({ label: String(l.label || '').trim(), href: safeUrl(String(l.url || '')) })).filter(l => l.href);
  return `<section class="page fade pf-page" style="--ac:${ac}">${back}
    <div class="pf-banner" style="${banner ? `background-image:url('${esc(banner)}')` : ''}"></div>
    <div class="pf-head">${avatarHtml(p, 96)}<div class="pf-id"><h1>${esc(p.display_name || 'Unnamed')}</h1>${p.tagline ? `<p class="pf-tag">${esc(p.tagline)}</p>` : ''}<p class="muted">${esc([p.role === 'label_admin' ? 'Label' : 'Artist', p.location].filter(Boolean).join(' · '))}</p></div>${mine ? `<button class="secondary" data-pf="edit-profile">Edit profile</button>` : ''}</div>
    ${p.bio ? `<div class="card pf-bio"><h3>About</h3><p>${esc(p.bio).replace(/\n/g, '<br>')}</p></div>` : ''}
    ${(links.length || p.contact_email) ? `<div class="card"><h3>Links & contact</h3><div class="pf-links">${links.map(l => `<a class="pf-link" href="${esc(l.href)}" target="_blank" rel="noopener noreferrer nofollow">${esc(l.label || l.href.replace(/^https?:\/\/(www\.)?/, '').slice(0, 40))} ↗</a>`).join('')}${p.contact_email ? `<a class="pf-link" href="mailto:${esc(p.contact_email)}">✉ ${esc(p.contact_email)}</a>` : ''}</div></div>` : ''}
    <div class="section-head"><div><p class="eyebrow">MUSIC</p><h2>Discography</h2></div></div>
    ${pageDisc.length ? `<div class="pf-discog">${pageDisc.map(r => `<article class="card pf-release"><div class="pf-cover">${coverUrls[r.artwork_path] ? `<img src="${esc(coverUrls[r.artwork_path])}" alt="${esc(r.title)} cover" loading="lazy">` : icon('disc', 34)}</div><div class="pf-rel-body"><h3>${esc(r.title)}</h3><p class="muted">${esc(r.release_type)}${r.release_date ? ' · ' + esc(String(r.release_date).slice(0, 4)) : ''}</p><div class="pf-tracks">${(r.tracks || []).map(t => `<div class="pf-track"><button class="pf-play" data-pf="play" data-path="${esc(t.audio_path || '')}" ${t.audio_path ? '' : 'disabled'} aria-label="Play ${esc(t.title)}">▶</button><span>${t.n}. ${esc(t.title)}${t.version ? ` <small>${esc(t.version)}</small>` : ''}</span></div>`).join('')}</div></div></article>`).join('')}</div>` : '<p class="muted">No released music yet.</p>'}
  </section>`;
}
async function playTrack(path) {
  if (!path) return;
  if (pfPlayer && pfNow === path) { pfPlayer.paused ? pfPlayer.play() : pfPlayer.pause(); return; }
  const { data, error } = await sb.storage.from('audio').createSignedUrl(path, 3600);
  if (error) return toast('Could not load audio: ' + error.message, 'error');
  if (pfPlayer) pfPlayer.pause();
  pfPlayer = new Audio(data.signedUrl); pfNow = path;
  pfPlayer.onplay = pfPlayer.onpause = pfPlayer.onended = syncPlayIcons;
  pfPlayer.play().catch(e => toast(e.message, 'error'));
}
function syncPlayIcons() { document.querySelectorAll('[data-pf="play"]').forEach(b => { b.textContent = (b.dataset.path === pfNow && pfPlayer && !pfPlayer.paused && !pfPlayer.ended) ? '❚❚' : '▶'; }); }

/* ---------- Editor ---------- */
function openEditor() {
  const p = profile, links = Array.isArray(p.links) && p.links.length ? p.links.map(l => ({ label: l.label || '', url: l.url || '' })) : [p.instagram ? { label: 'Instagram', url: p.instagram.startsWith('@') ? 'https://instagram.com/' + p.instagram.slice(1) : p.instagram } : null, p.website ? { label: 'Website', url: p.website } : null].filter(Boolean);
  editState = { tagline: p.tagline || '', bio: p.bio || '', location: p.location || '', accent: accentOf(p.accent), show_email: p.show_email !== false, links, avatarFile: null, bannerFile: null, avatarPath: p.avatar_path || '', bannerPath: p.banner_path || '' };
  view = 'editprofile'; mobile = false; render(); window.scrollTo(0, 0);
}
function editProfile() {
  const s = editState; if (!s) return discover();
  return `<section class="page fade"><button class="back-link" data-pf="my-page">${icon('back', 16)} Cancel</button><div class="page-heading"><p class="eyebrow">YOUR PAGE</p><h1>Edit profile</h1><p class="sub">This is what other accounts see when they find you. Your name is set by the label.</p></div>
  <div class="card pf-form"><h3>Look</h3>
    <div class="pf-media"><div>${avatarHtml({ display_name: profile.display_name, accent: s.accent, avatar_path: s.avatarPath }, 72)}<label class="secondary pf-file">Choose photo<input type="file" accept="image/*" data-pf-file="avatar" hidden></label><small>${s.avatarFile ? esc(s.avatarFile.name) : ''}</small></div><div><label class="secondary pf-file">Choose banner<input type="file" accept="image/*" data-pf-file="banner" hidden></label><small>${s.bannerFile ? esc(s.bannerFile.name) : (s.bannerPath ? 'Banner set' : 'Wide image works best')}</small></div></div>
    <div class="field"><span>Accent colour</span>
      <div class="pf-preview" style="--ac:${esc(s.accent)}"><div class="pf-prev-banner"></div><div class="pf-prev-row"><i class="pf-prev-avatar"></i><div><b>${esc(profile.display_name || 'Your name')}</b><small>${esc(s.tagline || 'Your tagline')}</small></div><button type="button" class="pf-prev-play" tabindex="-1" aria-hidden="true">&#9654;</button></div></div>
      <div class="pf-swatches">${PRESETS.map(c => `<button type="button" class="pf-sw ${c.toLowerCase() === s.accent.toLowerCase() ? 'on' : ''}" style="--c:${c}" data-pf="swatch" data-c="${c}" aria-label="Colour ${c}"></button>`).join('')}</div>
      <div class="pf-hex"><span class="pf-hex-dot" style="background:${esc(s.accent)}"></span><input id="pf-hex" value="${esc(s.accent)}" maxlength="7" spellcheck="false" autocomplete="off" aria-label="Hex colour"></div></div></div>
  <div class="card pf-form"><h3>About you</h3>
    <label class="field"><span>Tagline</span><input data-pf-in="tagline" maxlength="80" value="${esc(s.tagline)}" placeholder="Metalcore from Leeds"></label>
    <label class="field"><span>Bio</span><textarea data-pf-in="bio" rows="5" maxlength="600" placeholder="Tell people who you are">${esc(s.bio)}</textarea></label>
    <label class="field"><span>Location</span><input data-pf-in="location" maxlength="60" value="${esc(s.location)}" placeholder="City, Country"></label>
    <label class="pf-check"><input type="checkbox" id="pf-email" ${s.show_email ? 'checked' : ''}> Show my email on my page so people can contact me</label></div>
  <div class="card pf-form"><h3>Links</h3><p class="muted">Add up to 8. Spotify, Instagram, YouTube, your site, anything.</p>
    ${s.links.map((l, i) => `<div class="pf-linkrow"><input data-pf-link="${i}" data-k="label" placeholder="Label" maxlength="30" value="${esc(l.label)}"><input data-pf-link="${i}" data-k="url" placeholder="https://" maxlength="200" value="${esc(l.url)}"><button class="icon-btn danger-ghost" data-pf="del-link" data-i="${i}" aria-label="Remove link">✕</button></div>`).join('')}
    ${s.links.length < 8 ? `<button class="secondary" data-pf="add-link">+ Add link</button>` : ''}</div>
  <div class="builder-buttons"><button class="secondary" data-pf="my-page">Cancel</button><button class="primary" data-pf="save-profile">Save profile</button></div></section>`;
}
async function saveEditor() {
  if (busy) return; busy = true;
  try {
    const s = editState, uid = session.user.id, up = async (f, kind) => {
      if (!f) return null; if (!/^image\//.test(f.type)) throw new Error('Pictures must be image files.'); if (f.size > 2 * 1024 * 1024) throw new Error('Pictures must be under 2 MB.');
      const path = `${uid}/${kind}-${Date.now()}.${(f.name.split('.').pop() || 'jpg').toLowerCase()}`;
      const r = await sb.storage.from('profile-media').upload(path, f, { upsert: true, contentType: f.type }); if (r.error) throw new Error(`Could not upload ${kind}: ${r.error.message}`); return path;
    };
    const a = await up(s.avatarFile, 'avatar'), b = await up(s.bannerFile, 'banner');
    const links = s.links.map(l => ({ label: l.label.trim(), url: safeUrl(l.url.trim()) })).filter(l => l.url);
    const v = { tagline: s.tagline.trim() || null, bio: s.bio.trim() || null, location: s.location.trim() || null, accent: s.accent, show_email: !!s.show_email, links, avatar_path: a || s.avatarPath || null, banner_path: b || s.bannerPath || null };
    const { error } = await sb.from('profiles').update(v).eq('id', uid); if (error) throw new Error('Could not save profile: ' + error.message);
    if (a && s.avatarPath && s.avatarPath !== a) sb.storage.from('profile-media').remove([s.avatarPath]); if (b && s.bannerPath && s.bannerPath !== b) sb.storage.from('profile-media').remove([s.bannerPath]); Object.assign(profile, v); toast('Profile saved', 'success'); busy = false; editState = null; await openProfile(uid);
  } catch (e) { console.error(e); toast(e.message || 'Could not save profile', 'error'); } finally { busy = false; }
}

/* ---------- Wiring (called from bind() after every render) ---------- */
function bindProfiles() {
  document.querySelectorAll('[data-pf]').forEach(el => el.onclick = async () => {
    const a = el.dataset.pf;
    try {
      if (a === 'discover') openDiscover();
      else if (a === 'open-profile') await openProfile(el.dataset.id);
      else if (a === 'my-page') await openProfile(session.user.id);
      else if (a === 'edit-profile') openEditor();
      else if (a === 'save-profile') await saveEditor();
      else if (a === 'add-link') { editState.links.push({ label: '', url: '' }); render(); }
      else if (a === 'del-link') { editState.links.splice(Number(el.dataset.i), 1); render(); }
      else if (a === 'swatch') { setAccent(el.dataset.c); }
      else if (a === 'play') await playTrack(el.dataset.path);
    } catch (e) { toast(e.message, 'error'); }
  });
  const q = $('#disc-q'); if (q) { q.oninput = () => { clearTimeout(pfTimer); pfTimer = setTimeout(() => runSearch(q.value.trim()), 250); }; if (document.activeElement === document.body) q.focus(); }
  if (editState && view === 'editprofile') {
    document.querySelectorAll('[data-pf-in]').forEach(i => i.oninput = () => { editState[i.dataset.pfIn] = i.value; });
    document.querySelectorAll('[data-pf-link]').forEach(i => i.oninput = () => { editState.links[Number(i.dataset.pfLink)][i.dataset.k] = i.value; });
    const hx = $('#pf-hex'); if (hx) hx.oninput = () => { let v = hx.value.trim(); if (v && v[0] !== '#') v = '#' + v; if (/^#[0-9a-f]{6}$/i.test(v)) setAccent(v, true); };
    const em = $('#pf-email'); if (em) em.onchange = () => { editState.show_email = em.checked; };
    document.querySelectorAll('[data-pf-file]').forEach(i => i.onchange = () => { const f = i.files && i.files[0]; if (!f) return; if (i.dataset.pfFile === 'avatar') editState.avatarFile = f; else editState.bannerFile = f; render(); });
  }
  syncPlayIcons();
}

function setAccent(c, fromHex) {
  editState.accent = c;
  const pv = document.querySelector('.pf-preview'); if (pv) pv.style.setProperty('--ac', c);
  const dot = document.querySelector('.pf-hex-dot'); if (dot) dot.style.background = c;
  const hx = $('#pf-hex'); if (hx && !fromHex) hx.value = c;
  document.querySelectorAll('.pf-sw').forEach(b => b.classList.toggle('on', b.dataset.c.toLowerCase() === c.toLowerCase()));
}
