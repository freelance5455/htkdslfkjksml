class Ghost{
constructor(S){
 const c=document.createElement('canvas');c.width=128;c.height=256;const g=c.getContext('2d');
 g.fillStyle='#050505';g.beginPath();g.ellipse(64,42,31,36,0,0,7);g.fill();g.fillRect(33,42,62,214);
 g.fillStyle='#e6e6dc';g.beginPath();g.moveTo(44,78);g.lineTo(84,78);g.lineTo(106,254);g.lineTo(22,254);g.fill();
 g.fillStyle='#d4d4c8';g.beginPath();g.ellipse(64,52,17,23,0,0,7);g.fill();
 g.fillStyle='#050505';g.fillRect(34,60,12,196);g.fillRect(82,60,12,196);g.fillRect(48,36,32,12);
 g.fillRect(55,48,7,10);g.fillRect(67,48,7,10);g.beginPath();g.ellipse(64,68,5,7,0,0,7);g.fill();
 g.fillStyle='#8B0000';g.fillRect(50,100,8,70);g.beginPath();g.ellipse(70,150,18,34,0,0,7);g.fill();g.fillRect(60,70,3,14);g.fillRect(86,200,10,50);
 this.m=new THREE.Mesh(new THREE.PlaneGeometry(1.8,3.6),new THREE.MeshBasicMaterial({map:new THREE.CanvasTexture(c),transparent:true,alphaTest:.1,side:2}));
 S.add(this.m);this.pos=this.m.position;this.reset();
}
get on(){return this.st=='chase'}
reset(){this.st='idle';this.tm=18;this.sc=0;this.m.visible=false;this.m.scale.set(1,1,1);this.m.material.opacity=1;this.m.material.fog=true;this.m.material.needsUpdate=true}
update(dt,P,cam,sym){
 const m=this.m;
 if(this.st=='idle'){this.tm-=dt;if(this.tm<=0){const a=Math.random()*6.28;m.position.set(P.x+Math.cos(a)*24,1.8,P.z+Math.sin(a)*24);m.visible=true;this.st='chase';this.onSpawn&&this.onSpawn()}return 0}
 if(this.st=='chase'){
  const dx=P.x-m.position.x,dz=P.z-m.position.z,d=Math.hypot(dx,dz),cd=new THREE.Vector3();cam.getWorldDirection(cd);const lk=-(cd.x*dx+cd.z*dz)/d>.85,v=(2.4+sym*.5)*dt*(lk?.45:1);m.material.opacity=lk?.7:1;m.visible=!(d<14&&Math.random()<.06);if(d<10&&Math.random()<.05)m.position.x+=(Math.random()-.5)*1.4;
  m.position.x+=dx/d*v;m.position.z+=dz/d*v;m.position.y=1.8+Math.sin(performance.now()/300)*.12;m.rotation.y=Math.atan2(dx,dz);
  if(d<1.7){this.st='scare';this.sc=0;m.visible=true;m.material.opacity=1;m.material.fog=false;m.material.needsUpdate=true;Aud.scare()}
  else if(d>45){this.st='idle';this.tm=10;m.visible=false}
  return Math.max(0,1-d/20);
 }
 if(this.st=='scare'){
  this.sc+=dt;const dir=new THREE.Vector3();cam.getWorldDirection(dir);
  m.position.set(cam.position.x+dir.x*.9,.5,cam.position.z+dir.z*.9);m.rotation.y=Math.atan2(-dir.x,-dir.z);m.scale.setScalar(1+Math.random()*.25);
  if(this.sc>1.6){this.st='done';this.onCatch&&this.onCatch()}
 }
 return 1;
}}
