/* يمكن هدف؟ — data layer with multi-server failover */
(function () {
  const SERVERS = [
    { id: 's1', name: 'S1', role: 'الرئيسي', host: 'https://site.web.api.espn.com', status: 'idle', latency: null, fails: 0 },
    { id: 's2', name: 'S2', role: 'الاحتياطي', host: 'https://site.api.espn.com', status: 'idle', latency: null, fails: 0 },
    { id: 's3', name: 'S3', role: 'الطوارئ', host: 'https://site.web.api.espn.com', bust: true, status: 'idle', latency: null, fails: 0 },
  ];
  let active = 0;
  const cache = new Map();
  const listeners = new Set();

  function emit() { listeners.forEach(fn => { try { fn(state()); } catch (e) {} }); }
  function state() { return { servers: SERVERS.map(s => ({ ...s })), active, activeServer: SERVERS[active] }; }

  async function fetchJSON(url, ms = 9000) {
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), ms);
    try {
      const r = await fetch(url, { signal: ctl.signal, cache: 'no-store' });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return await r.json();
    } finally { clearTimeout(t); }
  }

  /* Try active server first, rotate on failure. ttl in ms for in-memory cache */
  async function espn(path, { ttl = 0 } = {}) {
    const key = path;
    const hit = cache.get(key);
    if (hit && Date.now() - hit.t < ttl) return hit.v;
    let lastErr;
    for (let i = 0; i < SERVERS.length; i++) {
      const idx = (active + i) % SERVERS.length;
      const s = SERVERS[idx];
      const sep = path.includes('?') ? '&' : '?';
      const url = s.host + path + (s.bust ? `${sep}_=${Date.now()}` : '');
      const t0 = performance.now();
      try {
        s.status = 'busy'; emit();
        const v = await fetchJSON(url);
        s.latency = Math.round(performance.now() - t0);
        s.status = 'ok'; s.fails = 0;
        if (idx !== active) active = idx;
        emit();
        cache.set(key, { t: Date.now(), v });
        return v;
      } catch (e) {
        lastErr = e; s.status = 'down'; s.fails++; emit();
      }
    }
    if (hit) return hit.v; // stale fallback
    throw lastErr || new Error('all servers failed');
  }

  function setActive(i) { active = i; emit(); }

  const ymd = d => `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;

  async function scoreboard(league, date) {
    const d = await espn(`/apis/site/v2/sports/soccer/${league}/scoreboard?dates=${ymd(date)}`, { ttl: 10000 });
    return (d.events || []).map(e => normalizeEvent(e, league, d.leagues && d.leagues[0]));
  }

  async function allScoreboards(date, leagues) {
    const res = await Promise.allSettled(leagues.map(l => scoreboard(l, date)));
    const out = [];
    res.forEach(r => { if (r.status === 'fulfilled') out.push(...r.value); });
    return out;
  }

  async function summary(league, id) {
    return espn(`/apis/site/v2/sports/soccer/${league}/summary?event=${id}`, { ttl: 8000 });
  }

  async function standings(league) {
    const d = await espn(`/apis/v2/sports/soccer/${league}/standings`, { ttl: 300000 });
    const child = (d.children && d.children[0]) || d;
    const entries = (child.standings && child.standings.entries) || [];
    return entries.map(en => {
      const st = {};
      (en.stats || []).forEach(s => { st[s.name || s.type] = s.value; st[(s.name || s.type) + '_d'] = s.displayValue; });
      return {
        id: en.team.id, name: en.team.displayName, abbr: en.team.abbreviation,
        logo: en.team.logos && en.team.logos[0] && en.team.logos[0].href,
        gp: st.gamesPlayed || 0, w: st.wins || 0, d: st.ties || 0, l: st.losses || 0,
        gf: st.pointsFor || 0, ga: st.pointsAgainst || 0, gd: st.pointDifferential || 0,
        pts: st.points || 0, rank: st.rank || 0, note: en.note && en.note.description, noteColor: en.note && en.note.color,
      };
    }).sort((a, b) => (a.rank || 99) - (b.rank || 99));
  }

  /* Polymarket public gamma API */
  async function polymarket(home, away, dateISO) {
    const norm = s => (s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .replace(/\b(fc|cf|afc|sc|ac|as|club|de|the|cd|ss|calcio|hotspur|wanderers|albion|&|hove)\b/g, ' ').replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
    const key = s => norm(s).split(' ').filter(w => w.length > 2);
    const hk = key(home), ak = key(away);
    const q = encodeURIComponent((hk[0] || home) + ' ' + (ak[0] || away));
    const ck = 'pm:' + q;
    const hit = cache.get(ck);
    if (hit && Date.now() - hit.t < 120000) return hit.v;
    let v = null;
    try {
      const d = await fetchJSON(`https://gamma-api.polymarket.com/public-search?q=${q}&limit_per_type=8&events_status=active`, 7000);
      const target = dateISO ? new Date(dateISO).getTime() : 0;
      const cands = (d.events || []).filter(e => {
        const t = norm(e.title);
        return hk.some(w => t.includes(w)) && ak.some(w => t.includes(w)) && !/more markets|women|wfc/i.test(e.title);
      }).filter(e => !target || Math.abs(new Date(e.endDate).getTime() - target) < 3 * 864e5);
      const ev = cands[0];
      if (ev) {
        const ms = ev.markets || [];
        let ph = null, pd = null, pa = null;
        ms.forEach(m => {
          const lab = norm(m.groupItemTitle || m.question);
          let p = null; try { p = parseFloat(JSON.parse(m.outcomePrices)[0]); } catch (e) {}
          if (p == null) return;
          if (/draw/.test(lab)) pd = p;
          else if (hk.some(w => lab.includes(w))) ph = p;
          else if (ak.some(w => lab.includes(w))) pa = p;
        });
        if (ph != null && pa != null) {
          pd = pd == null ? Math.max(0, 1 - ph - pa) : pd;
          const s = ph + pd + pa;
          v = { home: ph / s, draw: pd / s, away: pa / s, title: ev.title, url: `https://polymarket.com/event/${ev.slug}`, volume: ev.volume };
        }
      }
    } catch (e) { v = null; }
    cache.set(ck, { t: Date.now(), v });
    return v;
  }


  /* ---------- team history: last completed match (for expected XI + style) ---------- */
  async function lastMatch(teamId, beforeISO) {
    const ck = 'lm:' + teamId + ':' + (beforeISO || '');
    const hit = cache.get(ck); if (hit) return hit.v;
    let v = null;
    try {
      const d = await espn(`/apis/site/v2/sports/soccer/all/teams/${teamId}/schedule`, { ttl: 600000 });
      const lim = beforeISO ? new Date(beforeISO).getTime() - 3600e3 : Date.now();
      const ev = (d.events || []).filter(e => e.competitions && e.competitions[0].status.type.state === 'post' && new Date(e.date).getTime() < lim)
        .sort((a, b) => new Date(b.date) - new Date(a.date));
      for (const e of ev.slice(0, 2)) {
        const lg = (e.league && e.league.slug) || 'all';
        try {
          const s = await espn(`/apis/site/v2/sports/soccer/${lg}/summary?event=${e.id}`, { ttl: 600000 });
          const r = (s.rosters || []).find(x => x.team && x.team.id === String(teamId));
          if (r && (r.roster || []).some(p => p.starter)) {
            const c = s.header.competitions[0];
            const me = c.competitors.find(x => x.team.id === String(teamId)), op = c.competitors.find(x => x.team.id !== String(teamId));
            v = { id: e.id, league: lg, date: e.date, sum: s, roster: r, side: r.homeAway, formation: r.formation,
              gf: +me.score || 0, ga: +op.score || 0, opp: op.team.displayName, home: me.homeAway === 'home' };
            break;
          }
        } catch (err) {}
      }
    } catch (e) {}
    cache.set(ck, { t: Date.now(), v });
    return v;
  }

  /* ---------- Wikidata: player photos, Arabic names, head coach ---------- */
  const WD = 'https://www.wikidata.org/w/api.php', WQ = 'https://query.wikidata.org/sparql';
  async function sparql(q, ms = 9000) {
    const d = await fetchJSON(`${WQ}?format=json&query=${encodeURIComponent(q)}`, ms);
    return d.results.bindings;
  }
  const normName = s => (s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/ø/g, 'o').replace(/ß/g, 'ss').replace(/[^a-z ]/g, ' ').replace(/\s+/g, ' ').trim();
  const imgUrl = (u, w = 200) => u ? u.replace(/^http:/, 'https:') + `?width=${w}` : null;
  async function teamQid(name, national) {
    const q = national ? `${name} national football team` : name;
    const d = await fetchJSON(`${WD}?action=wbsearchentities&search=${encodeURIComponent(q)}&language=en&format=json&type=item&limit=7&origin=*`, 7000);
    const list = d.search || [];
    const good = x => {
      const ds = (x.description || '').toLowerCase();
      if (/women|female|under-|u-\d|youth|reserve|academy|futsal|beach|season|basketball|handball|rugby|cricket|hockey/.test(ds)) return false;
      return national ? /national/.test(ds) && /football|soccer/.test(ds) : /football|soccer/.test(ds) && /club|team/.test(ds);
    };
    const hit = list.find(good);
    return hit ? hit.id : null;
  }
  async function people(team, national) {
    const ck = 'wd:' + team.id;
    const c0 = cache.get(ck); if (c0) return c0.v;
    const p = (async () => {
      const out = { qid: null, players: [], byName: new Map(), byEspn: new Map(), byLast: new Map(), coach: null };
      try {
        const qid = await teamQid(team.name, national);
        if (!qid) return out;
        out.qid = qid;
        const [pl, co] = await Promise.allSettled([
          sparql(`SELECT ?p ?en ?ar ?img ?espn WHERE { ?p p:P54 ?st. ?st ps:P54 wd:${qid}. FILTER NOT EXISTS{?st pq:P582 ?e} ?p wdt:P31 wd:Q5. OPTIONAL{?p wdt:P18 ?img} OPTIONAL{?p wdt:P3681 ?espn} OPTIONAL{?p rdfs:label ?en FILTER(lang(?en)="en")} OPTIONAL{?p rdfs:label ?ar FILTER(lang(?ar)="ar")} } LIMIT 900`),
          sparql(`SELECT ?c ?en ?ar ?img ?start WHERE { wd:${qid} p:P286 ?st. ?st ps:P286 ?c. FILTER NOT EXISTS{?st pq:P582 ?e} OPTIONAL{?st pq:P580 ?start} OPTIONAL{?c wdt:P18 ?img} OPTIONAL{?c rdfs:label ?en FILTER(lang(?en)="en")} OPTIONAL{?c rdfs:label ?ar FILTER(lang(?ar)="ar")} } ORDER BY DESC(?start) LIMIT 3`),
        ]);
        if (pl.status === 'fulfilled') pl.value.forEach(b => {
          const rec = { en: b.en && b.en.value, ar: b.ar && b.ar.value, img: imgUrl(b.img && b.img.value), espn: b.espn && b.espn.value };
          if (!rec.en) return;
          out.players.push(rec);
          const k = normName(rec.en); if (!out.byName.has(k) || rec.img) out.byName.set(k, rec);
          if (rec.espn) out.byEspn.set(rec.espn, rec);
          const last = k.split(' ').slice(-1)[0]; (out.byLast.get(last) || out.byLast.set(last, []).get(last)).push(rec);
        });
        if (co.status === 'fulfilled' && co.value.length) {
          const b = co.value[0];
          const en = b.en && b.en.value;
          out.coach = { en, ar: (b.ar && b.ar.value) || (YH.COACHES[en] || {}).ar || en, img: imgUrl(b.img && b.img.value, 260), since: b.start && b.start.value };
        }
      } catch (e) {}
      return out;
    })();
    cache.set(ck, { t: Date.now(), v: p });
    return p;
  }
  /* find the Wikidata record for an ESPN athlete */
  function personFor(pp, ath) {
    if (!pp || !ath) return null;
    if (ath.id && pp.byEspn.has(String(ath.id))) return pp.byEspn.get(String(ath.id));
    const k = normName(ath.displayName || ath.fullName);
    if (pp.byName.has(k)) return pp.byName.get(k);
    const parts = k.split(' '); const last = parts.slice(-1)[0];
    const c = pp.byLast.get(last) || [];
    if (c.length === 1) return c[0];
    const fi = parts[0] && parts[0][0];
    return c.find(x => normName(x.en)[0] === fi) || null;
  }

  /* ---------- Arabic goal videos (YouTube, via public Piped mirrors) ---------- */
  const PIPED = ['https://api.piped.private.coffee', 'https://pipedapi.kavin.rocks', 'https://pipedapi.adminforge.de', 'https://pipedapi.r4fo.com'];
  let pipedIdx = 0;
  async function videoSearch(q) {
    const ck = 'yt:' + q; const hit = cache.get(ck);
    if (hit && Date.now() - hit.t < 60000) return hit.v;
    let items = null;
    for (let i = 0; i < PIPED.length && !items; i++) {
      const base = PIPED[(pipedIdx + i) % PIPED.length];
      try {
        const d = await fetchJSON(`${base}/search?q=${encodeURIComponent(q)}&filter=videos`, 8000);
        if (d && Array.isArray(d.items)) { items = d.items; pipedIdx = (pipedIdx + i) % PIPED.length; }
      } catch (e) {}
    }
    const v = (items || []).filter(x => x.type === 'stream' && x.url).map(x => ({
      id: (x.url.split('v=')[1] || '').split('&')[0], title: x.title || '', channel: x.uploaderName || '', verified: !!x.uploaderVerified,
      duration: x.duration || 0, uploaded: x.uploaded || 0, thumb: `https://i.ytimg.com/vi/${(x.url.split('v=')[1] || '').split('&')[0]}/mqdefault.jpg`,
    })).filter(x => x.id);
    cache.set(ck, { t: Date.now(), v });
    return v;
  }
  const hasAr = s => /[\u0600-\u06FF]/.test(s || '');
  /* rank Arabic-commentary clips for a match / goal */
  async function arabicClips({ teamsAr, teamsEn, date, scorer, kind }) {
    const base = kind === 'goal' ? `هدف ${scorer || ''} ${teamsAr[0]} ${teamsAr[1]}` : `ملخص اهداف ${teamsAr[0]} و${teamsAr[1]}`;
    const qs = [base + ' تعليق عربي', base];
    const t0 = date ? new Date(date).getTime() - 3 * 3600e3 : 0;
    const seen = new Map();
    for (const q of qs) {
      const r = await videoSearch(q).catch(() => []);
      r.forEach(x => seen.set(x.id, x));
      if (seen.size >= 8) break;
    }
    const toks = [...teamsAr, ...(scorer ? [scorer] : [])].flatMap(n => (n || '').split(/\s+/)).filter(w => w.length > 2);
    const out = [...seen.values()].filter(x => hasAr(x.title) && x.duration > 15 && x.duration < (kind === 'goal' ? 420 : 1500) && (!t0 || !x.uploaded || x.uploaded > t0))
      .map(x => {
        let sc = 0; toks.forEach(w => { if (x.title.includes(w)) sc += 2; });
        if (/هدف|اهداف|أهداف|ملخص/.test(x.title)) sc += 3;
        if (/تعليق|معلق/.test(x.title)) sc += 2;
        if (x.verified) sc += 2;
        if (/live|بث مباشر|مباشر الآن|ردة فعل|توقعات|تحليل/i.test(x.title)) sc -= 6;
        return { ...x, score: sc };
      }).filter(x => x.score >= 4).sort((a, b) => b.score - a.score);
    return out.slice(0, 6);
  }

  function normalizeEvent(e, league, lg) {
    const c = e.competitions[0];
    const home = c.competitors.find(x => x.homeAway === 'home') || c.competitors[0];
    const away = c.competitors.find(x => x.homeAway === 'away') || c.competitors[1];
    const team = t => ({
      id: t.team.id, name: t.team.displayName, short: t.team.shortDisplayName || t.team.displayName,
      abbr: t.team.abbreviation, logo: t.team.logo, color: t.team.color, alt: t.team.alternateColor,
      score: t.score != null ? +t.score : null, form: t.form || '', winner: t.winner,
      leaders: t.leaders || [], shootout: t.shootoutScore,
    });
    const st = c.status || e.status;
    const odds = c.odds && c.odds[0];
    return {
      id: e.id, league, leagueName: lg ? lg.name : league, leagueLogo: lg && lg.logos && lg.logos[0] && lg.logos[0].href,
      date: e.date, state: st.type.state, completed: st.type.completed, detail: st.type.shortDetail || st.type.detail,
      clock: st.displayClock, period: st.period, statusName: st.type.name,
      venue: c.venue && c.venue.fullName, city: c.venue && c.venue.address && c.venue.address.city,
      home: team(home), away: team(away), details: c.details || [],
      odds: odds ? {
        home: odds.homeTeamOdds && odds.homeTeamOdds.moneyLine, away: odds.awayTeamOdds && odds.awayTeamOdds.moneyLine,
        draw: odds.drawOdds && odds.drawOdds.moneyLine, ou: odds.overUnder, provider: odds.provider && odds.provider.name,
      } : null,
      broadcasts: (c.broadcasts || []).flatMap(b => b.names || []),
      tier: (YH.LEAGUE_BY_ID[league] || {}).tier || 3,
    };
  }

  YH.api = { lastMatch, people, personFor, videoSearch, arabicClips, normName, espn, scoreboard, allScoreboards, summary, standings, polymarket, onServer: fn => listeners.add(fn), state, setActive, ymd, SERVERS };
})();
