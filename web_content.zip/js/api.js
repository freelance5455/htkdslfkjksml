/* NOVA ULTIMATE AI — connexions aux vraies API. Aucune clé n'est incluse. */
const NovaAPI = (() => {
  const S = () => JSON.parse(localStorage.getItem('nova_settings') || sessionStorage.getItem('nova_settings') || '{}');
  const BRAIN = {
    openai:{url:'https://api.openai.com/v1',model:'gpt-4o-mini'},
    gemini:{url:'https://generativelanguage.googleapis.com/v1beta/openai',model:'gemini-2.0-flash'},
    openrouter:{url:'https://openrouter.ai/api/v1',model:'openai/gpt-4o-mini'},
    groq:{url:'https://api.groq.com/openai/v1',model:'llama-3.3-70b-versatile'},
    custom:{url:'',model:''}
  };
  const need = (k, label) => { if (!k) throw new Error(`Ajoutez votre clé « ${label} » dans ⚙ Paramètres.`); };
  async function fail(r){ let t=''; try{const j=await r.json(); t=j.error?.message||j.detail||j.message||JSON.stringify(j);}catch{t=r.statusText} throw new Error(`Erreur ${r.status} : ${t}`); }

  /* ---- Cerveau IA (streaming, format OpenAI) ---- */
  async function chat(messages, onToken){
    const s=S(); need(s.brainKey,'Cerveau IA');
    const p=BRAIN[s.brainProvider||'openai'];
    const base=(s.brainProvider==='custom'?s.brainUrl:p.url).replace(/\/$/,'');
    const r=await fetch(base+'/chat/completions',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+s.brainKey},
      body:JSON.stringify({model:s.brainModel||p.model,messages,stream:true})});
    if(!r.ok) await fail(r);
    const rd=r.body.getReader(), dec=new TextDecoder(); let buf='', full='';
    while(true){const {done,value}=await rd.read(); if(done)break; buf+=dec.decode(value,{stream:true});
      const lines=buf.split('\n'); buf=lines.pop();
      for(const l of lines){const d=l.trim(); if(!d.startsWith('data:'))continue; const x=d.slice(5).trim(); if(x==='[DONE]')continue;
        try{const t=JSON.parse(x).choices?.[0]?.delta?.content; if(t){full+=t; onToken&&onToken(full);}}catch{}}}
    return full;
  }
  async function complete(prompt, system){ return chat([{role:'system',content:system||'Tu es NOVA, assistant créatif.'},{role:'user',content:prompt}]); }

  /* ---- Images ---- */
  const SIZES={'1:1':'1024x1024','9:16':'1024x1536','16:9':'1536x1024'};
  async function image(prompt, ratio='1:1'){
    const s=S(); need(s.imageKey,'Génération d\'images'); const pv=s.imageProvider||'openai';
    if(pv==='openai'){
      const model=s.imageModel||'gpt-image-1';
      const size=model==='dall-e-3'?({'1:1':'1024x1024','9:16':'1024x1792','16:9':'1792x1024'})[ratio]:SIZES[ratio];
      const body={model,prompt,size,n:1}; if(model==='dall-e-3') body.response_format='b64_json';
      const r=await fetch('https://api.openai.com/v1/images/generations',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+s.imageKey},body:JSON.stringify(body)});
      if(!r.ok) await fail(r); const j=await r.json(); const d=j.data[0];
      return d.b64_json?'data:image/png;base64,'+d.b64_json:d.url;
    }
    if(pv==='stability'){
      const f=new FormData(); f.append('prompt',prompt); f.append('aspect_ratio',ratio); f.append('output_format','png');
      const r=await fetch('https://api.stability.ai/v2beta/stable-image/generate/'+(s.imageModel||'core'),{method:'POST',headers:{'Authorization':'Bearer '+s.imageKey,'Accept':'image/*'},body:f});
      if(!r.ok) await fail(r); return URL.createObjectURL(await r.blob());
    }
    if(pv==='fal'){
      const sz={'1:1':'square_hd','9:16':'portrait_16_9','16:9':'landscape_16_9'}[ratio];
      const j=await falRun(s.imageKey, s.imageModel||'fal-ai/flux/schnell',{prompt,image_size:sz});
      return j.images?.[0]?.url;
    }
  }

  /* ---- fal.ai file d'attente ---- */
  async function falRun(key, model, input, onStatus){
    const h={'Authorization':'Key '+key,'Content-Type':'application/json'};
    const r=await fetch('https://queue.fal.run/'+model,{method:'POST',headers:h,body:JSON.stringify(input)});
    if(!r.ok) await fail(r); const q=await r.json();
    for(let i=0;i<180;i++){ await new Promise(z=>setTimeout(z,i<5?2000:4000));
      const st=await (await fetch(q.status_url,{headers:h})).json(); onStatus&&onStatus(st.status);
      if(st.status==='COMPLETED'){const res=await fetch(q.response_url,{headers:h}); if(!res.ok) await fail(res); return res.json();}
      if(st.status==='FAILED'||st.error) throw new Error('Génération échouée'); }
    throw new Error('Délai dépassé');
  }

  /* ---- Vidéos ---- */
  async function video(prompt, ratio='16:9', onStatus){
    const s=S(); need(s.videoKey,'Génération de vidéos');
    if((s.videoProvider||'fal')==='fal'){
      const j=await falRun(s.videoKey, s.videoModel||'fal-ai/ltx-video',{prompt,aspect_ratio:ratio},onStatus);
      return j.video?.url||j.videos?.[0]?.url;
    }
    if(!s.videoUrl) throw new Error('Indiquez l\'URL de votre endpoint vidéo.');
    const r=await fetch(s.videoUrl,{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+s.videoKey},body:JSON.stringify({model:s.videoModel,prompt,aspect_ratio:ratio})});
    if(!r.ok) await fail(r); const j=await r.json(); return j.video_url||j.url||j.output?.[0]||j.data?.[0]?.url;
  }

  async function test(kind){
    const s=S();
    if(kind==='brain'){ await chat([{role:'user',content:'Réponds juste OK'}]); return 'Cerveau IA connecté ✓'; }
    if(kind==='image'){ need(s.imageKey,'images');
      const pv=s.imageProvider||'openai';
      if(pv==='openai'){const r=await fetch('https://api.openai.com/v1/models',{headers:{Authorization:'Bearer '+s.imageKey}}); if(!r.ok) await fail(r);}
      if(pv==='stability'){const r=await fetch('https://api.stability.ai/v1/user/balance',{headers:{Authorization:'Bearer '+s.imageKey}}); if(!r.ok) await fail(r);}
      return 'Clé images enregistrée ✓'; }
    if(kind==='video'){ need(s.videoKey,'vidéos'); return 'Clé vidéos enregistrée ✓ (vérifiée à la 1ère génération)'; }
  }
  return {chat,complete,image,video,test};
})();
