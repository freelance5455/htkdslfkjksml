/* يمكن هدف؟ — data layer with multi-server failover ("خوادم بلاد الرافدين") */
(function () {
  const SERVERS = [
    { id: 'babel', name: 'بابل', host: 'https://site.web.api.espn.com', status: 'idle', latency: null, fails: 0 },
    { id: 'ashur', name: 'آشور', host: 'https://site.api.espn.com', status: 'idle', latency: null, fails: 0 },
    { id: 'nineveh', name: 'نينوى', host: 'https://site.web.api.espn.com', bust: true, status: 'idle', latency: null, fails: 0 },
  ];
  let active = 0;
  const cache = new Map();
  const listeners = new Set();

  function emit() { listeners.forEach(fn => { try { fn(state()); } catch (e) {} }); }
  function state() { return { servers: SERVERS.map(s => ({ ...s })), active, activeServer: SERVERS[active] }; }

  async function fetchJSON(url, ms = 9000) {
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), ms);
    try {
      const r = await fetch(url, { signal: ctl.signal, cache: 'no-store' });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return await r.json();
    } finally { clearTimeout(t); }
  }

  /* Try active server first, rotate on failure. ttl in ms for in-memory cache */
  async function espn(path, { ttl = 0 } = {}) {
    const key = path;
    const hit = cache.get(key);
    if (hit && Date.now() - hit.t < ttl) return hit.v;
    let lastErr;
    for (let i = 0; i < SERVERS.length; i++) {
      const idx = (active + i) % SERVERS.length;
      const s = SERVERS[idx];
      const sep = path.includes('?') ? '&' : '?';
      const url = s.host + path + (s.bust ? `${sep}_=${Date.now()}` : '');
      const t0 = performance.now();
      try {
        s.status = 'busy'; emit();
        const v = await fetchJSON(url);
        s.latency = Math.round(performance.now() - t0);
        s.status = 'ok'; s.fails = 0;
        if (idx !== active) active = idx;
        emit();
        cache.set(key, { t: Date.now(), v });
        return v;
      } catch (e) {
        lastErr = e; s.status = 'down'; s.fails++; emit();
      }
    }
    if (hit) return hit.v; // stale fallback
    throw lastErr || new Error('all servers failed');
  }

  function setActive(i) { active = i; emit(); }

  const ymd = d => `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;

  async function scoreboard(league, date) {
    const d = await espn(`/apis/site/v2/sports/soccer/${league}/scoreboard?dates=${ymd(date)}`, { ttl: 10000 });
    return (d.events || []).map(e => normalizeEvent(e, league, d.leagues && d.leagues[0]));
  }

  async function allScoreboards(date, leagues) {
    const res = await Promise.allSettled(leagues.map(l => scoreboard(l, date)));
    const out = [];
    res.forEach(r => { if (r.status === 'fulfilled') out.push(...r.value); });
    return out;
  }

  async function summary(league, id) {
    return espn(`/apis/site/v2/sports/soccer/${league}/summary?event=${id}`, { ttl: 8000 });
  }

  async function standings(league) {
    const d = await espn(`/apis/v2/sports/soccer/${league}/standings`, { ttl: 300000 });
    const child = (d.children && d.children[0]) || d;
    const entries = (child.standings && child.standings.entries) || [];
    return entries.map(en => {
      const st = {};
      (en.stats || []).forEach(s => { st[s.name || s.type] = s.value; st[(s.name || s.type) + '_d'] = s.displayValue; });
      return {
        id: en.team.id, name: en.team.displayName, abbr: en.team.abbreviation,
        logo: en.team.logos && en.team.logos[0] && en.team.logos[0].href,
        gp: st.gamesPlayed || 0, w: st.wins || 0, d: st.ties || 0, l: st.losses || 0,
        gf: st.pointsFor || 0, ga: st.pointsAgainst || 0, gd: st.pointDifferential || 0,
        pts: st.points || 0, rank: st.rank || 0, note: en.note && en.note.description, noteColor: en.note && en.note.color,
      };
    }).sort((a, b) => (a.rank || 99) - (b.rank || 99));
  }

  /* Polymarket public gamma API */
  async function polymarket(home, away, dateISO) {
    const norm = s => (s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .replace(/\b(fc|cf|afc|sc|ac|as|club|de|the|cd|ss|calcio|hotspur|wanderers|albion|&|hove)\b/g, ' ').replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
    const key = s => norm(s).split(' ').filter(w => w.length > 2);
    const hk = key(home), ak = key(away);
    const q = encodeURIComponent((hk[0] || home) + ' ' + (ak[0] || away));
    const ck = 'pm:' + q;
    const hit = cache.get(ck);
    if (hit && Date.now() - hit.t < 120000) return hit.v;
    let v = null;
    try {
      const d = await fetchJSON(`https://gamma-api.polymarket.com/public-search?q=${q}&limit_per_type=8&events_status=active`, 7000);
      const target = dateISO ? new Date(dateISO).getTime() : 0;
      const cands = (d.events || []).filter(e => {
        const t = norm(e.title);
        return hk.some(w => t.includes(w)) && ak.some(w => t.includes(w)) && !/more markets|women|wfc/i.test(e.title);
      }).filter(e => !target || Math.abs(new Date(e.endDate).getTime() - target) < 3 * 864e5);
      const ev = cands[0];
      if (ev) {
        const ms = ev.markets || [];
        let ph = null, pd = null, pa = null;
        ms.forEach(m => {
          const lab = norm(m.groupItemTitle || m.question);
          let p = null; try { p = parseFloat(JSON.parse(m.outcomePrices)[0]); } catch (e) {}
          if (p == null) return;
          if (/draw/.test(lab)) pd = p;
          else if (hk.some(w => lab.includes(w))) ph = p;
          else if (ak.some(w => lab.includes(w))) pa = p;
        });
        if (ph != null && pa != null) {
          pd = pd == null ? Math.max(0, 1 - ph - pa) : pd;
          const s = ph + pd + pa;
          v = { home: ph / s, draw: pd / s, away: pa / s, title: ev.title, url: `https://polymarket.com/event/${ev.slug}`, volume: ev.volume };
        }
      }
    } catch (e) { v = null; }
    cache.set(ck, { t: Date.now(), v });
    return v;
  }

  function normalizeEvent(e, league, lg) {
    const c = e.competitions[0];
    const home = c.competitors.find(x => x.homeAway === 'home') || c.competitors[0];
    const away = c.competitors.find(x => x.homeAway === 'away') || c.competitors[1];
    const team = t => ({
      id: t.team.id, name: t.team.displayName, short: t.team.shortDisplayName || t.team.displayName,
      abbr: t.team.abbreviation, logo: t.team.logo, color: t.team.color, alt: t.team.alternateColor,
      score: t.score != null ? +t.score : null, form: t.form || '', winner: t.winner,
      leaders: t.leaders || [], shootout: t.shootoutScore,
    });
    const st = c.status || e.status;
    const odds = c.odds && c.odds[0];
    return {
      id: e.id, league, leagueName: lg ? lg.name : league, leagueLogo: lg && lg.logos && lg.logos[0] && lg.logos[0].href,
      date: e.date, state: st.type.state, completed: st.type.completed, detail: st.type.shortDetail || st.type.detail,
      clock: st.displayClock, period: st.period, statusName: st.type.name,
      venue: c.venue && c.venue.fullName, city: c.venue && c.venue.address && c.venue.address.city,
      home: team(home), away: team(away), details: c.details || [],
      odds: odds ? {
        home: odds.homeTeamOdds && odds.homeTeamOdds.moneyLine, away: odds.awayTeamOdds && odds.awayTeamOdds.moneyLine,
        draw: odds.drawOdds && odds.drawOdds.moneyLine, ou: odds.overUnder, provider: odds.provider && odds.provider.name,
      } : null,
      broadcasts: (c.broadcasts || []).flatMap(b => b.names || []),
      tier: (YH.LEAGUE_BY_ID[league] || {}).tier || 3,
    };
  }

  YH.api = { espn, scoreboard, allScoreboards, summary, standings, polymarket, onServer: fn => listeners.add(fn), state, setActive, ymd, SERVERS };
})();
