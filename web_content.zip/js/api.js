/* UrbaAlerte — adaptateur API « local-first »
   Si URBA_CONFIG.API_BASE est vide : tout reste sur l'appareil (démo).
   Sinon : les routes ci-dessous sont appelées (à aligner avec l'API REST du mémoire) ; en cas d'échec réseau, l'app retombe sur le stockage local et re-synchronise plus tard. */
(function(w){
'use strict';
const C=w.URBA_CONFIG;
const A=w.API={
  get enabled(){return !!C.API_BASE},
  token:null,
  async call(method,path,body){
    const r=await fetch(C.API_BASE.replace(/\/$/,'')+path,{method,headers:Object.assign({'Content-Type':'application/json'},A.token?{Authorization:'Bearer '+A.token}:{}),body:body?JSON.stringify(body):undefined});
    if(!r.ok){const e=new Error('HTTP '+r.status);e.status=r.status;throw e}
    return r.status===204?null:r.json();
  },
  register:(name,phone,password)=>A.call('POST','/api/auth/register',{nom_complet:name,telephone:phone,mot_de_passe:password}),
  login:(phone,password)=>A.call('POST','/api/auth/login',{telephone:phone,mot_de_passe:password}),
  listIncidents:since=>A.call('GET','/api/incidents'+(since?'?since='+since:'')),
  createIncident:r=>A.call('POST','/api/incidents',{type:r.type,description:r.desc,latitude:r.lat,longitude:r.lng,reference:r.ref,created_at:r.created}),
  /* l'envoi des médias (multipart) est à brancher sur POST /api/incidents/:id/medias */
  uploadMedia:async(id,blob)=>{const f=new FormData();f.append('file',blob);const r=await fetch(C.API_BASE.replace(/\/$/,'')+'/api/incidents/'+id+'/medias',{method:'POST',headers:A.token?{Authorization:'Bearer '+A.token}:{},body:f});if(!r.ok)throw new Error('HTTP '+r.status)}
};
})(window);
