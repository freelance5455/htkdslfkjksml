export class ApiError extends Error {
  constructor(message, status = 0, code = "unknown") {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.code = code;
  }
}

async function call(path, options = {}) {
  let response;
  try {
    response = await fetch(path, {
      ...options,
      headers: { ...(options.body ? { "content-type": "application/json" } : {}), ...options.headers },
    });
  } catch {
    throw new ApiError("Sunucuya ulaşılamıyor.", 0, "offline");
  }
  let body;
  try {
    body = await response.json();
  } catch {
    throw new ApiError("Veri tabanı henüz hazır değil. Projeyi ilk kez yayımladıktan sonra tekrar dene.", response.status, "unavailable");
  }
  if (!response.ok) {
    const code = response.status === 503 || body.code === "DATABASE_UNAVAILABLE" ? "unavailable" : body.code ?? "request";
    throw new ApiError(body.error ?? "İstek tamamlanamadı.", response.status, code);
  }
  return body;
}

export const api = {
  status: () => call("/api/status"),
  profile: () => call("/api/profile"),
  saveProfile: (profile) => call("/api/profile", { method: "POST", body: JSON.stringify(profile) }),
  getProgress: () => call("/api/progress"),
  saveProgress: (progress) => call("/api/progress", { method: "POST", body: JSON.stringify(progress) }),
  friends: () => call("/api/friends"),
  addFriend: (username) => call("/api/friends", { method: "POST", body: JSON.stringify({ username }) }),
  acceptFriend: (friendId) => call("/api/friends/accept", { method: "POST", body: JSON.stringify({ friendId }) }),
  createRoom: (mode) => call("/api/rooms", { method: "POST", body: JSON.stringify({ mode }) }),
  joinRoom: (code) => call("/api/rooms/join", { method: "POST", body: JSON.stringify({ code }) }),
  invite: (username, code) => call("/api/invites", { method: "POST", body: JSON.stringify({ username, code }) }),
  inbox: () => call("/api/invites"),
};

export function reportError(message) {
  window.dispatchEvent(new CustomEvent("arena:error", { detail: message }));
}
