/* naval-ai.js — Phase 9: AI navy. Builds ships, repairs, merges and stations fleets, hunts weaker enemy fleets,
   blockades enemy ports and mounts escorted amphibious invasions against enemies it cannot reach by land.
   (Like the rest of the AI it ignores fog of war.) */
(function (G) {
  'use strict';

  const alive = () => Object.keys(G.state.countries).filter(id => !G.state.countries[id].dead);
  const mine = id => G.state.fleets.filter(f => f.owner === id);
  const isWar = f => f.ships.some(s => G.SHIPS[s.type].atk > 0);
  const isTrans = f => f.ships.length > 0 && f.ships.every(s => G.SHIPS[s.type].cargo > 0);
  function enemyFireAt(zone, id) {
    const m = G._zf && G._zf[zone]; let s = 0;
    if (m) for (const o in m) if (G.atWar(o, id)) s += m[o];
    return s;
  }
  function navyValue(id) {
    let v = 0; mine(id).forEach(f => f.ships.forEach(s => { v += G.SHIPS[s.type].gold; }));
    (G.state.shipQ[id] || []).forEach(it => { v += G.SHIPS[it.type].gold; });
    return v;
  }
  const hasCoast = id => G.provinces.some(p => !p.sea && G.state.owners[p.id] === id && p.seaZones && p.seaZones.length);
  // holdings the land army cannot reach on foot (islands, colonies) make a navy matter more
  function overseasHoldings(id) {
    const st = G.state, cap = G.COUNTRIES[id].capitalId, seen = { [cap]: true }, q = [cap];
    while (q.length) { const c = q.pop(); for (const n of G.provinces[c].adj) if (!seen[n] && st.owners[n] === id) { seen[n] = true; q.push(n); } }
    return G.provinces.some(p => !p.sea && st.owners[p.id] === id && !seen[p.id]);
  }

  /* ---------- shipbuilding ---------- */
  function shipbuildAI(id) {
    const st = G.state, c = st.countries[id], ai = st.ai[id]; if (!ai || !hasCoast(id)) return;
    if (st.shipQ[id].length >= 2) return;
    const pow = G.COUNTRIES[id].pow || 3, atWar = G.warsOf(id).length > 0;
    const want = pow * 330 * (atWar ? 1.5 : 1) * (0.6 + ai.aggression * 0.7) * (overseasHoldings(id) ? 1.5 : 1);
    if (navyValue(id) >= want) return;
    const yards = G.provinces.filter(p => !p.sea && st.owners[p.id] === id && p.seaZones && p.seaZones.length && st.pb[p.id].dock && st.pb[p.id].port && G.blockadeLevel(p.id) < 0.5 &&
      st.shipQ[id].filter(q => q.prov === p.id).length < st.pb[p.id].dock);
    if (!yards.length) return;
    yards.sort((a, b) => b.pop - a.pop);
    const have = {}, tot = { n: 0 };
    mine(id).forEach(f => f.ships.forEach(s => { have[s.type] = (have[s.type] || 0) + 1; tot.n++; }));
    st.shipQ[id].forEach(it => { have[it.type] = (have[it.type] || 0) + 1; tot.n++; });
    const tr = overseasHoldings(id) || atWar ? 0.25 : 0.12;
    const mix = { destroyer: 0.34, submarine: 0.14, cruiser: pow >= 2 ? 0.16 : 0.05, battleship: pow >= 4 ? 0.1 : 0, transport: tr };
    const order = Object.keys(mix).filter(t => mix[t] > 0).sort((x, y) => (mix[y] - (have[y] || 0) / Math.max(1, tot.n)) - (mix[x] - (have[x] || 0) / Math.max(1, tot.n)));
    if (c.treasury < 220) return;
    for (const t of order) for (const y of yards.slice(0, 2)) if (G.buildShip(id, t, y.id).ok) return;
  }

  /* ---------- fleets ---------- */
  function mergeAt(id) {
    const st = G.state, byNode = {};
    for (const f of mine(id)) {
      if (f.path.length || f.cargo.length || G.fleetInBattle(f)) continue;
      const k = String(f.loc) + (isTrans(f) ? 't' : 'w');
      const t = byNode[k];
      if (t && t.ships.length + f.ships.length <= G.FLEET_MAX_SHIPS) { t.ships = t.ships.concat(f.ships); st.fleets.splice(st.fleets.indexOf(f), 1); }
      else if (!t) byNode[k] = f;
    }
  }
  function homePort(id) {
    const st = G.state, cap = G.provinces[G.COUNTRIES[id].capitalId];
    if (cap && st.owners[cap.id] === id && cap.seaZones && cap.seaZones.length && G.blockadeLevel(cap.id) < 0.6) return cap.id;
    const ps = G.provinces.filter(p => !p.sea && st.owners[p.id] === id && p.seaZones && p.seaZones.length).sort((a, b) => b.pop - a.pop);
    return ps.length ? ps[0].id : null;
  }
  function targetZones(id) {
    const st = G.state, out = {};
    for (const e of G.warsOf(id)) for (const p of G.provinces) {
      if (p.sea || st.owners[p.id] !== e || !p.seaZones) continue;
      for (const z of p.seaZones) out[z] = (out[z] || 0) + 1 + p.income / 6 + (p.capital ? 3 : 0);
    }
    return out;
  }
  function fleetAI(id) {
    const st = G.state, ai = st.ai[id];
    mergeAt(id);
    const tz = targetZones(id), atWar = G.warsOf(id).length > 0;
    for (const f of mine(id).slice()) {
      if (!st.fleets.includes(f) || f.path.length || G.fleetInBattle(f)) continue;
      const sm = G.fleetSummary(f);
      if (f.cargo.length) { if (typeof f.loc === 'number') G.unloadAll(f); continue; }
      if (isTrans(f)) {
        if (isZone(f.loc)) G.returnHome(f);
        continue;
      }
      if (!isWar(f)) continue;
      const docked = typeof f.loc === 'number';
      if (sm.hp < 0.8) { if (!docked) G.returnHome(f); continue; }            // repair first
      if (docked && sm.hp < 0.97 && !atWar) continue;
      if (!atWar) {
        const hp = homePort(id);
        if (!docked && hp != null) { if (st.day % 12 === 0) G.orderSail(f, hp); }
        continue;
      }
      // choose a zone to blockade or contest
      const start = docked ? f.loc : f.loc;
      let best = null, bs = 0;
      const myFire = sm.fire;
      for (const z in tz) {
        if (z === f.loc) { const ef = enemyFireAt(z, id); if (myFire >= 1.1 * ef) { best = null; bs = 1e9; break; } continue; }
        const path = G.navalPath(f, start, n => n === z); if (!path) continue;
        const eta = path.reduce((a, n, i) => a + G.navalLegDays(f, i ? path[i - 1] : start, n), 0);
        if (eta > 30) continue;
        const ef = enemyFireAt(z, id), here = G.zoneFireOf(z, id, true);
        if (myFire + here < 1.25 * ef) continue;
        const score = tz[z] / (1 + eta / 8) + (ef > 0 ? 1.2 : 0);
        if (score > bs) { bs = score; best = z; }
      }
      if (best && bs < 1e9) G.orderSail(f, best);
      else if (bs < 1e9 && !docked && sm.fire < 8) G.returnHome(f);
    }
  }
  const isZone = n => typeof n === 'string';

  /* ---------- sea reach (used by the war planner in ai.js) ---------- */
  G.aiSeaReach = function (id, t) {
    const st = G.state;
    const tf = mine(id).filter(f => isTrans(f) && typeof f.loc === 'number' && f.ships.length);
    if (tf.reduce((n, f) => n + f.ships.length, 0) < 2) return false;
    const myPow = G.navalPower(id), theirPow = G.navalPower(t);
    if (myPow < 14 || myPow < 1.3 * theirPow + 3) return false;
    const tgt = G.provinces.filter(p => !p.sea && st.owners[p.id] === t && p.seaZones && p.seaZones.length);
    if (!tgt.length) return false;
    const zones = {}; tgt.forEach(p => p.seaZones.forEach(z => { zones[z] = true; }));
    const f = tf[0];
    const path = G.navalPath(f, f.loc, n => zones[n]);
    if (!path) return false;
    const eta = path.reduce((a, n, i) => a + G.navalLegDays(f, i ? path[i - 1] : f.loc, n), 0);
    return eta <= 20;
  };

  /* ---------- amphibious operations ---------- */
  function amphibAI(id) {
    const st = G.state, ai = st.ai[id];
    const enemies = G.warsOf(id).filter(e => !G.provinces.some(p => !p.sea && st.owners[p.id] === id && p.adj.some(n => st.owners[n] === e)));
    if (!enemies.length) return;
    const tfs = mine(id).filter(f => isTrans(f) && typeof f.loc === 'number' && !f.path.length && !f.cargo.length);
    if (!tfs.length) return;
    tfs.sort((a, b) => G.fleetSummary(b).free - G.fleetSummary(a).free);
    const tf = tfs[0], port = tf.loc, cap = G.fleetSummary(tf).free;
    if (cap < 3) return;
    // gather an army at the staging port
    const here = st.armies.filter(a => a.owner === id && a.prov === port && !a.path.length && !G.inBattle(a) && G.armySummary(a).strength >= 0.6);
    let units = here.reduce((n, a) => n + a.units.length, 0);
    if (units < 3) {
      const spare = st.armies.filter(a => a.owner === id && a.prov !== port && !a.path.length && !G.inBattle(a) && st.owners[a.prov] === id && G.armySummary(a).strength >= 0.7 &&
        !G.provinces[a.prov].adj.some(n => st.owners[n] && st.owners[n] !== id && G.atWar(id, st.owners[n])));
      spare.sort((a, b) => { const pa = G.findPath(a, port), pb = G.findPath(b, port); return (pa ? pa.length : 99) - (pb ? pb.length : 99); });
      spare.slice(0, 2).forEach(a => { const p = G.findPath(a, port); if (p && p.length <= 8) G.orderMove(a, port); });
      return;
    }
    // merge and choose the load
    const base = here[0]; here.slice(1).forEach(a => { if (base.units.length + a.units.length <= Math.min(G.ARMY_MAX_UNITS, cap)) G.mergeArmies(base, a); });
    const army = here.filter(a => st.armies.includes(a)).sort((a, b) => b.units.length - a.units.length)[0];
    if (!army || army.units.length < 3 || army.units.length > cap) return;
    // pick a target
    const myFire = G.sideFire([army], false, army.prov, []);
    let best = null, bs = -1e9;
    for (const p of G.provinces) {
      if (p.sea || !enemies.includes(st.owners[p.id]) || !p.seaZones || !p.seaZones.length) continue;
      const path = G.navalPath(tf, port, n => isZone(n) && p.seaZones.includes(n)); if (!path) continue;
      const eta = path.reduce((a, n, i) => a + G.navalLegDays(tf, i ? path[i - 1] : port, n), 0); if (eta > 22) continue;
      const D = G.armiesAt(p.id).filter(x => x.owner === st.owners[p.id]);
      const defFire = D.length ? G.sideFire(D, true, p.id, [army]) : 0.5;
      const val = 1 + p.pop / 80000 + (p.capital ? 3 : 0);
      const score = val / (1 + defFire / Math.max(1, myFire)) - eta * 0.04;
      if (score > bs) { bs = score; best = { p: p, path: path }; }
    }
    if (!best) return;
    // escort: the landing zone must not be held by a stronger enemy
    const lz = best.path[best.path.length - 1] || best.p.seaZones[0];
    const ef = enemyFireAt(lz, id), mf = G.zoneFireOf(lz, id, true);
    if (ef > 0 && mf < 1.3 * ef) {
      const wf = mine(id).filter(f => isWar(f) && !f.path.length && !f.cargo.length && !G.fleetInBattle(f) && G.fleetSummary(f).hp > 0.8).sort((a, b) => G.fleetSummary(b).fire - G.fleetSummary(a).fire)[0];
      if (wf && G.fleetSummary(wf).fire >= 1.3 * ef) G.orderSail(wf, lz);
      return;
    }
    const r = G.orderAmphibious(army, best.p.id);
    if (r.ok && (id === st.player || G.atWar(st.player, st.owners[best.p.id]))) G.logMsg(G.COUNTRIES[id].name + ' launched an amphibious invasion of ' + best.p.name);
  }

  G.navalAIDay = function () {
    const st = G.state; if (!st.ai) return;
    const ids = alive().filter(id => id !== st.player);
    ids.forEach((id, i) => {
      if (st.day % 8 === i % 8) shipbuildAI(id);
      if (st.day % 3 === i % 3) fleetAI(id);
      if (st.day % 5 === (i + 2) % 5) amphibAI(id);
    });
  };
})(window.EMP = window.EMP || {});
