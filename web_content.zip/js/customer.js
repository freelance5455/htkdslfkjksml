const cfg=window.DARRELL_CONFIG;
const menu=[
 ["🍔","Darrell Burger","Beef, cheese, lettuce & house sauce",8.50],
 ["🍗","Grilled Chicken","Herbs, fries & garden salad",10.00],
 ["🍝","Creamy Pasta","Cream sauce, herbs & parmesan",9.50],
 ["🥗","Garden Bowl","Fresh vegetables & house dressing",7.00],
 ["🍰","Dessert of the Day","Ask our team",5.00],
 ["🥤","Fresh Juice","Seasonal fruit",3.00]
];
document.getElementById("menuGrid").innerHTML=menu.map(x=>`<article class="food"><div class="foodpic">${x[0]}</div><div><h3>${x[1]}</h3><p>${x[2]}</p><b>$${x[3].toFixed(2)}</b></div></article>`).join("");
const form=document.getElementById("bookingForm"), msg=document.getElementById("bookingMsg");
form.addEventListener("submit",async e=>{
 e.preventDefault(); msg.textContent="Sending booking…";
 if(cfg.SUPABASE_URL.includes("PASTE_")) { msg.textContent="Demo mode: connect Supabase in js/config.js first."; return; }
 try{
  const row={customer_name:name.value.trim(),phone:phone.value.trim(),date:date.value,time:time.value,guests:Number(guests.value),special_request:request.value.trim(),status:"pending"};
  const r=await fetch(cfg.SUPABASE_URL+"/rest/v1/bookings",{method:"POST",headers:{"apikey":cfg.SUPABASE_ANON_KEY,"Authorization":"Bearer "+cfg.SUPABASE_ANON_KEY,"Content-Type":"application/json","Prefer":"return=representation"},body:JSON.stringify(row)});
  if(!r.ok) throw new Error(await r.text());
  const saved=(await r.json())[0]; msg.textContent="Booking received. Reference: "+saved.id.slice(0,8).toUpperCase(); form.reset();
 }catch(err){console.error(err);msg.textContent="Could not send booking. Check your Supabase setup."}
});