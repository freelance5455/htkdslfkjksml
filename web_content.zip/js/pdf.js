function printInvoice(inv){
  if(!inv)return;
  const seller=inv.seller||{},c=calcInvoice(inv),rows=inv.rows||[],pages=[];
  for(let i=0;i<rows.length;i+=12)pages.push(rows.slice(i,i+12));
  if(!pages.length)pages.push([]);
  const w=window.open("","_blank");
  if(!w){alert("مرورگر اجازه بازکردن پنجره چاپ را نداد. اجازه بازشدن پنجره‌های بازشو را فعال کنید.");return}
  const safe=s=>esc(s==null||s===""?"—":String(s));
  const cell=(label,value)=>`<div class="print-head-box"><span>${label}</span><b>${safe(value)}</b></div>`;
  const pageHtml=pages.map((part,idx)=>{
    const filled=part.map((r,j)=>`<tr><td>${fmt(idx*12+j+1)}</td><td>${safe(r.description)}</td><td>${fmt(r.quantity)}</td><td>${fmt(r.weight)}</td><td>${fmt(r.unitPrice)}</td><td>${fmt(num(r.weight)*num(r.unitPrice))}</td></tr>`);
    for(let j=part.length;j<12;j++)filled.push(`<tr><td>${fmt(idx*12+j+1)}</td><td>&nbsp;</td><td></td><td></td><td></td><td></td></tr>`);
    const final=idx===pages.length-1;
    return `<section class="invoice-print print-page">
      <header class="print-header">
        <div class="print-head-side">${cell("کد اقتصادی:",seller.economic||"—")}${cell("تلفن:",seller.phone||"—")}</div>
        <div class="print-head-center"><div class="ornament">✳</div><div class="seller-title">${safe(seller.name)}</div><h1>فاکتور فروش</h1><div class="subtitle">سند فروش</div></div>
        <div class="print-head-side">${cell("شماره:",fmt(inv.number))}${cell("تاریخ:",inv.date||"—")}</div>
      </header>
      <div class="print-parties">
        <div class="party-line"><span class="party-label">نام فروشنده:</span><span class="party-value">${safe(seller.name)}</span><span class="party-extra">تلفن: ${safe(seller.phone)}</span></div>
        <div class="party-line"><span class="party-label">نام خریدار:</span><span class="party-value">${safe(inv.buyer?.name)}</span><span class="party-extra">تلفن: ${safe(inv.buyer?.phone)}</span></div>
        <div class="party-line double"><span class="party-label">نشانی خریدار:</span><span class="party-value">${safe(inv.buyer?.address)}</span></div>
      </div>
      <div class="print-customer-code">کد شناسایی مشتری: ${safe(inv.buyer?.code)} <span style="float:left">نشانی فروشنده: ${safe(seller.address)}</span></div>
      <table class="print-table"><thead><tr><th>ردیف</th><th>شرح کالا / خدمات</th><th>تعداد</th><th>وزن</th><th>قیمت واحد (ریال)</th><th>قیمت کل (ریال)</th></tr></thead><tbody>${filled.join("")}</tbody></table>
      ${final?`<div class="print-lower"><table class="print-summary"><tbody><tr><td>جمع کالاها</td><td>${fmt(c.subtotal)} ریال</td></tr><tr><td>حساب از قبل</td><td>${fmt(c.previous)} ریال</td></tr><tr><td>تخفیف</td><td>${fmt(c.discount)} ریال</td></tr><tr><td>مالیات (${fmt(inv.taxRate||0)}٪)</td><td>${fmt(c.tax)} ریال</td></tr><tr class="total-row"><td>جمع کل فاکتور</td><td>${fmt(c.total)} ریال</td></tr></tbody></table><div class="print-notes"><strong>توضیحات:</strong><div class="notes-content">${safe(inv.notes)}</div></div></div>
      <div class="signatures"><div class="signature">مهر و امضای فروشنده</div><div class="signature">امضای خریدار</div></div>`:`<div style="margin-top:2mm;font-size:7pt;text-align:left">ادامه فاکتور — صفحه ${fmt(idx+1)} از ${fmt(pages.length)}</div>`}
      <footer class="print-footer"><span>فاکتور فروش</span><span>با تشکر از خرید شما</span></footer>
    </section>`;
  }).join("");
  w.document.open();
  w.document.write(`<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>فاکتور فروش ${fmt(inv.number)}</title><link rel="stylesheet" href="${new URL("./css/print.css",location.href).href}"><style>body{font-family:VazirLocal,Tahoma,sans-serif}</style></head><body>${pageHtml}<script>window.addEventListener('load',()=>setTimeout(()=>window.print(),500));<\/script></body></html>`);
  w.document.close();
}
async function previewCurrent(){
  const inv=invoiceFormData();
  if(!inv.buyer.name.trim()){alert("ابتدا نام خریدار را وارد کنید.");return}
  if(!inv.rows.length){alert("حداقل یک ردیف کالا اضافه کنید.");return}
  inv.seller=editingInvoiceId?(editingSellerSnapshot||window.sellerSnapshot||{}):(window.sellerSnapshot||{});
  printInvoice(inv);
}
