/* Página A4 real: a pré-visualização é feita de folhas A4 fixas (como no Word). O conteúdo flui pelas folhas e as quebras de página
   já aparecem durante a edição. O PDF imprime exactamente estas folhas pelo navegador (vectorial, texto pesquisável), sem converter em imagem. */
const BUILD='v20',MM=96/25.4,PW=210*MM,PH=297*MM,pm=()=>({t:Math.max(10,S.mt??18)*MM,b:Math.max(10,S.mb??18)*MM,x:0}),PAPER=d=>{const v=getComputedStyle(d.documentElement).getPropertyValue('--paper').trim();return/^(#[0-9a-f]{3,8}|rgb.*|[a-z]+)$/i.test(v)&&v?v:'#fff'};
/* ---- medição: linhas de texto e blocos (para nunca cortar uma linha ao meio nem separar um título do seu conteúdo) ---- */
const DECO=x=>{const c=getComputedStyle(x),t=c.backgroundColor;return(t!=='rgba(0, 0, 0, 0)'&&t!=='transparent')||c.backgroundImage!=='none'||['Top','Right','Bottom','Left'].some(k=>parseFloat(c['border'+k+'Width'])>0&&c['border'+k+'Style']!=='none')};
function measureDoc(d,el){const R0=el.getBoundingClientRect(),top=R0.top,lf=R0.left,L=[],A=[],r=d.createRange(),tw=d.createTreeWalker(el,4);let n;
while(n=tw.nextNode()){if(!n.nodeValue.trim())continue;r.selectNodeContents(n);for(const q of r.getClientRects())if(q.height>1)L.push([q.top-top,q.bottom-top,q.left-lf,q.right-lf])}
el.querySelectorAll('.entry,.ref,li,dl,.photo,.card,.sig-in').forEach(x=>{const q=x.getBoundingClientRect();A.push([q.top-top,q.bottom-top,0,x.matches('.photo')?900:x.matches('.entry,.ref,.card,.sig-in')?100:x.matches('li')&&DECO(x)?160:50,q.left-lf,q.right-lf])});
/* títulos: o título e o primeiro bloco do conteúdo ficam sempre na mesma página */
el.querySelectorAll('h2,h3').forEach(x=>{const q=x.getBoundingClientRect();let nx=x.matches('h2')?x.nextElementSibling:null;if(nx&&nx.matches('ul,ol,.refs')&&nx.firstElementChild)nx=nx.firstElementChild;const nq=nx&&nx.getBoundingClientRect();
const ke=nq?(nq.height<=220?nq.bottom:nq.top+80)-top:q.bottom-top+40;A.push([q.top-top,q.bottom-top,1,ke,q.left-lf,q.right-lf])});
return{L,A,total:Math.ceil(el.getBoundingClientRect().height),end:Math.max(0,...L.map(x=>x[1]),...A.filter(x=>!x[2]).map(x=>x[1]))}}
/* posições de corte de cada folha. Regras rígidas: nunca corta uma linha, nunca corta um título, nunca deixa um título sozinho no fim da folha.
   Entre as posições possíveis escolhe a que deixa a folha mais cheia, descontando uma penalização por partir um item. */
function cuts(M){const{t,b}=pm(),{L,A,total,end}=M,c=[0];let y=0;
const pick=(top,bot,strict)=>{let best=null,bs=-1e9;const span=bot-top;
for(let q=Math.floor(bot);q>top+span*.3;q--){let bad=false,pen=0;
for(const[a,z]of L)if(a<q-.5&&z>q+.5){bad=true;break}
if(!bad)for(const[a,z,k,w]of A)if(k){if(q>a-3&&q<z+3){bad=true;break}if(q>a-3&&q<w){if(strict){bad=true;break}pen+=200}}
if(bad)continue;
for(const[a,z,k,w]of A)if(!k&&a>top+30&&a<q-.5&&z>q+.5&&z-a<span*.6)pen+=w;
const sc=q-pen;if(sc>bs){bs=sc;best=q}}
return best};
while(c.length<400){const hc=PH-b-(y?t:0);if(end<=y+hc){c.push(Math.max(total,y+1));break}
const e=pick(y,y+hc,true)??pick(y,y+hc,false)??(y+hc);c.push(e);y=Math.floor(e);}return c}
/* ---- folhas ---- */
const PGCSS='@media screen{html,body{background:#cfd5e1!important}.pg{border-radius:10px}#pgs{padding:14px 0 6px}.pg{margin:0 auto 18px!important;box-shadow:0 6px 24px #1b2a5a38}}'
+'#pgs{margin:0;padding:0}.pg{position:relative;width:210mm;height:297mm;overflow:hidden;break-after:page;page-break-after:always;break-inside:avoid}.pg:last-child{break-after:auto;page-break-after:auto}.pgc,.pgb{position:absolute;overflow:hidden}.pgb{pointer-events:none}'
+'@media print/*pg*/{html,body{background:#fff!important;margin:0!important;padding:0!important}#pgs{padding:0!important}.pg{margin:0!important;box-shadow:none!important}}'
+'@page{size:A4;margin:0}@page :first{margin:0}';
const clone=(src,W,y0)=>{const c=src.cloneNode(true);c.style.cssText+=`;margin:0!important;box-shadow:none!important;width:${W}px!important;max-width:none!important;`+(y0==null?'':`position:absolute!important;left:0;top:${-y0}px;`);return c};
/* estilo das datas por secção (S.es = {experience:'time',...}); escolhido ao seleccionar a secção no preview */
const ESV=()=>{const e=S.es;return typeof e=='string'?{experience:e,education:e,extra:e}:(e||{})};
const ESEC=['experience','education','extra','custom'],ESN={classic:'Clássico',date:'Data à esquerda',time:'Linha do tempo',card:'Cartões',bar:'Destaque'};
function applyES(root){const m=ESV();root.querySelectorAll('[data-sec]').forEach(x=>{const v=m[x.dataset.sec];if(v&&v!='classic')x.dataset.es=v;else delete x.dataset.es})}
/* estilo da pontuação por secção (S.ls = {skills:'bar',languages:'ring',custom:'tags'}); escolhido ao seleccionar a secção no preview.
   Cada item com nível tem data-lv (20..100) e data-lb (texto do nível) nos modelos; "classic" = desenho original do modelo. */
const LSEC=['skills','languages','custom'],LSN={classic:'Padrão do modelo',dots:'Cinco pontos',bar:'Barra de progresso',list:'Lista',slider:'Slider',ring:'Anel',tags:'Etiquetas'};
const LSCSS='[data-ls]{--ls-a:var(--accent,var(--primary,#444));--ls-t:color-mix(in srgb,var(--ls-a) 22%,var(--paper,#fff))}'
+'[data-ls] li[data-lv]{break-inside:avoid}.ls-lb{opacity:.65;font-size:.92em;white-space:nowrap}'
+'[data-ls=dots] li[data-lv]{display:flex;flex-wrap:nowrap;justify-content:space-between;align-items:center;gap:8px}'
+'.ls-d{display:inline-flex;flex:none;gap:4px}.ls-d i{width:8px;height:8px;border-radius:50%;background:var(--ls-t)}.ls-d i.on{background:var(--ls-a)}'
+'[data-ls=bar] li[data-lv],[data-ls=slider] li[data-lv]{display:grid;grid-template-columns:1fr auto;align-items:baseline;gap:4px 8px}'
+'.ls-bar{grid-column:1/-1;height:6px;border-radius:3px;background:var(--ls-t);overflow:hidden}.ls-bar i{display:block;height:100%;border-radius:3px;background:var(--grad,var(--ls-a))}'
+'.ls-sl{grid-column:1/-1;position:relative;height:12px}.ls-sl::before{content:"";position:absolute;left:0;right:0;top:50%;height:2px;margin-top:-1px;border-radius:1px;background:var(--ls-t)}'
+'.ls-sl i{position:absolute;left:0;top:50%;height:2px;margin-top:-1px;border-radius:1px;background:var(--grad,var(--ls-a))}'
+'.ls-sl b{position:absolute;top:0;width:12px;height:12px;box-sizing:border-box;border-radius:50%;background:var(--ls-a);border:2px solid var(--paper,#fff);box-shadow:0 0 0 1px var(--ls-a)}'
+'[data-ls=list] li[data-lv]{display:flex;flex-wrap:nowrap;justify-content:flex-start;align-items:baseline;gap:6px}.ls-b{flex:none;width:5px;height:5px;border-radius:50%;background:var(--ls-a);transform:translateY(-.12em)}[data-ls=list] .ls-lb::before{content:"— "}'
+'[data-ls=ring] li[data-lv]{display:flex;flex-wrap:nowrap;justify-content:space-between;align-items:center;gap:8px}'
+'.ls-rg{flex:none;width:20px;height:20px}.ls-rg circle{fill:none;stroke-width:3.4}.ls-rg .t{stroke:var(--ls-t)}.ls-rg .f{stroke:var(--ls-a);stroke-linecap:round}'
+'[data-ls=tags] .langs{display:flex!important;flex-wrap:wrap;grid-template-columns:none!important;gap:5px 6px!important}'
+'[data-ls=tags] li[data-lv]{display:inline-flex;flex-wrap:nowrap;justify-content:flex-start;padding:2px 10px;border-radius:99px;background:var(--ls-t)}';
const LSV=()=>S.ls||{};
function lsHtml(v,nm,lv,lb){const n='<span class="lang-name">'+esc(nm)+'</span>',L=lb?'<span class="ls-lb">'+esc(lb)+'</span>':'';
if(v=='dots'){const k=Math.round(lv/20);return n+'<span class="ls-d">'+'<i class="on"></i>'.repeat(k)+'<i></i>'.repeat(5-k)+'</span>'}
if(v=='bar')return n+L+'<span class="ls-bar"><i style="width:'+lv+'%"></i></span>';
if(v=='slider')return n+L+'<span class="ls-sl"><i style="width:'+lv+'%"></i><b style="left:calc('+lv+'% - '+(lv*.12).toFixed(1)+'px)"></b></span>';
if(v=='list')return'<span class="ls-b"></span>'+n+L;
if(v=='ring'){const C=2*Math.PI*9;return n+'<svg class="ls-rg" viewBox="0 0 24 24" aria-hidden="true"><circle class="t" cx="12" cy="12" r="9"/><circle class="f" cx="12" cy="12" r="9" stroke-dasharray="'+(C*lv/100).toFixed(2)+' '+C.toFixed(2)+'" transform="rotate(-90 12 12)"/></svg>'}
return n}
function applyLS(root){const m=LSV();root.querySelectorAll('[data-sec]').forEach(x=>{const k=x.dataset.sec;if(!LSEC.includes(k))return;const v=m[k]&&m[k]!='classic'&&LSN[m[k]]?m[k]:'',its=x.querySelectorAll('li[data-lv]');if(!its.length)return;
if(v)x.dataset.ls=v;else delete x.dataset.ls;
its.forEach(li=>{if(li.__o==null)li.__o=li.innerHTML;if(!v){li.innerHTML=li.__o;return}const nm=(li.querySelector('.lang-name')||{}).textContent||'',lv=Math.max(0,Math.min(100,+li.dataset.lv||0));li.innerHTML=lsHtml(v,nm,lv,li.dataset.lb||'')})})}
function paginate(){try{const d=fr.contentDocument,b=d&&d.body;if(!b)return;
if(!d.__src){const r=d.querySelector('.resume');if(!r)return;d.__src=r.cloneNode(true)}applyES(d.__src);applyLS(d.__src);
if(!d.getElementById('ls-css')){const q=d.createElement('style');q.id='ls-css';q.textContent=LSCSS;d.head.append(q)}
if(!d.getElementById('pg-css')){const s=d.createElement('style');s.id='pg-css';s.textContent=PGCSS;d.head.append(s)}
const o=pm(),W=PW-2*o.x,src=d.__src,wrap=d.createElement('div');wrap.style.cssText=`position:absolute;left:0;top:0;width:${W}px;visibility:hidden`;
const m=clone(src,W);wrap.append(m);b.replaceChildren(wrap);
const M=measureDoc(d,m),c=cuts(M),tot=M.total,mr=m.getBoundingClientRect(),paper=PAPER(d);
/* colunas de fundo a toda a altura (barra lateral…), para preencher as margens de topo/rodapé sem copiar conteúdo */
const cols=[];[m,...m.querySelectorAll('*')].forEach(x=>{const q=x.getBoundingClientRect();if(q.width<4)return;const bot=q.bottom-mr.top;if(!(q.height>=tot*.92||(bot>=tot-2&&q.height>=tot*.3)))return;const cs=getComputedStyle(x),bc=cs.backgroundColor,bi=cs.backgroundImage,has=bc!=='rgba(0, 0, 0, 0)'&&bc!=='transparent';
if(has||bi!=='none')cols.push({l:q.left-mr.left,w:q.width,t:q.top-mr.top,h:q.height,ext:bot>=tot-2,bc:has?bc:'transparent',bi})});
const pgs=d.createElement('div');pgs.id='pgs';
for(let k=0;k<c.length-1;k++){const y0=c[k],dy=k?o.t:0,hh=Math.min(c[k+1]-y0,PH-dy),pg=d.createElement('div');pg.className='pg';pg.style.background=paper;
const strip=(top,h,ya)=>{if(h<.5)return;for(const q of cols){const a=Math.max(ya,q.t),z=Math.min(ya+h,q.ext?1e9:q.t+q.h);if(z<=a)continue;const s=d.createElement('div');s.className='pgb';s.style.cssText=`left:${o.x+q.l}px;width:${q.w}px;top:${top+(a-ya)}px;height:${Math.min(z,ya+h)-a}px;background-color:${q.bc};background-image:${q.bi};background-size:${q.w}px ${q.h}px;background-position:0 ${-(a-q.t)}px;background-repeat:repeat-y`;pg.append(s)}};
if(k&&dy>.5)strip(0,dy,y0-dy);strip(dy+hh,PH-dy-hh,y0+hh);
const win=d.createElement('div');win.className='pgc';win.style.cssText=`left:${o.x}px;top:${dy}px;width:${W}px;height:${hh}px`;win.append(clone(src,W,y0));pg.append(win);pgs.append(pg)}
b.replaceChildren(pgs);
/* se o tipo de letra / imagens mudarem a altura depois da medição, refaz as folhas (evita conteúdo tapado ou cortes errados) */
const c0=pgs.querySelector('.pgc>*');if(c0&&Math.abs(c0.getBoundingClientRect().height-tot)>1.5&&(d.__rp=(d.__rp||0)+1)<4)setTimeout(guides,30);else if(c0)d.__rp=0;
if(!d.__fh){d.__fh=1;d.fonts&&d.fonts.ready.then(()=>guides());d.defaultView.addEventListener('load',()=>guides())}
const n=c.length-1,p=$('#pgc');if(p)p.textContent=n+(n>1?' páginas':' página')+' A4'}catch(e){console.error(e)}}
/* ---- impressão: imprime as folhas tal como estão no ecrã ---- */
function printHtml(){const c=fr.contentDocument.documentElement.cloneNode(true);c.querySelectorAll('#cv-sel-css').forEach(x=>x.remove());c.querySelectorAll('.cv-sel,.cv-h').forEach(x=>x.classList.remove('cv-sel','cv-h'));
return('<!doctype html>'+c.outerHTML).replace(/@media print(?!\/\*pg)/g,'@media not all').replace('</body>','<script>addEventListener("load",()=>setTimeout(()=>print(),500))<\/script></body>')}
function printDoc(){const u=URL.createObjectURL(new Blob([printHtml()],{type:'text/html'}));if(!open(u,'_blank'))location.href=u}
/* ---- projecto: guardar / abrir o CV (dados + modelo + estilo) num ficheiro ---- */
const projName=()=>((D.full_name||'cv').trim().replace(/[^\p{L}\p{N}]+/gu,'_')||'cv')+'.cvb.json';
const projBlob=()=>new Blob([JSON.stringify({app:'cv-builder',version:1,saved:new Date().toISOString(),template:T,style:S,data:D})],{type:'application/json'});
function projSave(){BASE=JSON.stringify(D);const u=URL.createObjectURL(projBlob()),a=document.createElement('a');a.href=u;a.download=projName();document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),4000)}
async function projShare(){try{await navigator.share({files:[new File([projBlob()],projName(),{type:'application/json'})],title:projName()})}catch(e){if(e&&e.name!='AbortError')projSave()}}
function projLoad(txt){let o;try{o=JSON.parse(txt)}catch{alert('Este ficheiro não é um projecto válido.');return}
const d=o&&o.data&&typeof o.data=='object'?o.data:(o&&typeof o=='object'&&('full_name' in o||'experience' in o)?o:null);if(!d){alert('Este ficheiro não é um projecto do CV Builder.');return}
BASE=null;D=fix({...E(),...JSON.parse(JSON.stringify(d))});S=(o.style&&typeof o.style=='object')?o.style:{};if(o.template&&TP[o.template])T=o.template;OPEN={};$('#tpl').value=T;build();save();draw();panel();BASE=JSON.stringify(D)}
$('#pj').onchange=async e=>{const x=e.target.files[0];e.target.value='';if(!x)return;const t=await x.text();guardLoad(()=>projLoad(t))};
const PMENU=$('#menu'),canShare=!!(navigator.canShare&&navigator.canShare({files:[new File([''],'a.json',{type:'application/json'})]}));PMENU.querySelector('[data-m=share]').hidden=!canShare;
$('#dl').onclick=e=>{e.stopPropagation();PMENU.hidden=!PMENU.hidden};
document.addEventListener('click',e=>{if(!e.target.closest('#menu'))PMENU.hidden=true});
PMENU.onclick=e=>{const b=e.target.closest('button');if(!b)return;PMENU.hidden=true;const m=b.dataset.m;if(m=='print')printDoc();else if(m=='save')projSave();else if(m=='open')$('#pj').click();else if(m=='share')projShare()};

/* ---- secções seleccionáveis na pré-visualização (só no ecrã; nunca entram no PDF) ---- */
let SEL=null;
const SELCSS='@media screen{[data-sec],header,.personal{cursor:pointer;-webkit-tap-highlight-color:transparent}'
+'@media (hover:hover){.cv-h{outline:2px dashed #2563eb88!important;outline-offset:3px}}'
+'.cv-sel{outline:2px solid #2563eb!important;outline-offset:3px;border-radius:2px}}@media print{.cv-h,.cv-sel{outline:none!important}}';
const secEls=(d,k)=>{if(k!='personal')return[...d.querySelectorAll(`[data-sec="${k}"]`)];const h=[...d.querySelectorAll('header')];return h.length?h:[...d.querySelectorAll('.personal')].map(x=>x.closest('section')).filter(Boolean)};
const secKey=(d,t)=>{if(!t||!t.closest)return null;const s=t.closest('[data-sec]');if(s)return s.dataset.sec;return t.closest('header')||(t.closest('.personal')&&t.closest('.personal').closest('section'))?'personal':null};
function selBar(){const b=$('#selbar'),d=fr.contentDocument;if(!b)return;
const els=d&&SEL?secEls(d,SEL):[];if(!els.length){b.hidden=true;return}
const k=parseFloat(fr.style.transform.slice(6))||1,w=$('#stage').clientWidth;let best=null,ba=-1;
for(const el of els){const r=el.getBoundingClientRect(),w0=el.closest('.pgc'),cr=w0?w0.getBoundingClientRect():r,l=Math.max(r.left,cr.left),t=Math.max(r.top,cr.top),rr=Math.min(r.right,cr.right),bb=Math.min(r.bottom,cr.bottom),a=Math.max(0,rr-l)*Math.max(0,bb-t);if(a>ba){ba=a;best={l,t,w:rr-l,el}}}
if(!best){b.hidden=true;return}
b.hidden=false;
const el=best.el,sib=SEL=='personal'?[]:[...el.parentElement.children].filter(x=>x.dataset.sec),i=sib.indexOf(el);
b.querySelector('[data-m="-1"]').disabled=!(i>0&&sib[i-1].dataset.sec!=SEL);b.querySelector('[data-m="1"]').disabled=!(i>=0&&i<sib.length-1&&sib[i+1].dataset.sec!=SEL);
b.querySelector('[data-m]').parentElement.style.display=SEL=='personal'?'none':'';
const eb=b.querySelector('[data-a="es"]');eb.hidden=!ESEC.includes(SEL)||(SEL=='custom'&&!D.custom_sections.some(x=>x.kind=='experience'));const lb=b.querySelector('[data-a="ls"]');lb.hidden=!LSEC.includes(SEL)||(SEL=='custom'&&!D.custom_sections.some(x=>x.kind=='skills'));if(eb.hidden&&lb.hidden)$('#esm').hidden=true;
const sdc=SIDE(),pb=b.querySelector('[data-a="pl"]');pb.hidden=!(sdc&&sdc.can.includes(SEL));if(!pb.hidden){const inSide=!!el.closest(sdc.box);pb.textContent=inSide?'⇆ Principal':'⇆ Lateral';pb.title=inSide?'Mover para a coluna principal':'Mover para a barra lateral'}
const bw=b.offsetWidth,bh=b.offsetHeight;let top=best.t*k-bh-6;if(top<2)top=Math.max(2,best.t*k+4);
b.style.top=top+'px';b.style.left=Math.max(2,Math.min(w-bw-2,best.l*k+(best.w*k-bw)/2))+'px'}
function selSet(k){SEL=k;$('#esm').hidden=true;prevMark()}
function prevMark(){try{const d=fr.contentDocument;if(!d)return;
if(!d.getElementById('cv-sel-css')){const s=d.createElement('style');s.id='cv-sel-css';s.textContent=SELCSS;d.head.append(s)}
if(!d.cvBound){d.cvBound=1;let last=[];const clr=()=>{last.forEach(x=>x.classList.remove('cv-h'));last=[]};
d.addEventListener('click',e=>{const k=secKey(d,e.target);e.preventDefault();selSet(k)});
d.addEventListener('mouseover',e=>{const k=secKey(d,e.target);clr();if(k){last=secEls(d,k);last.forEach(x=>x.classList.add('cv-h'))}});
d.addEventListener('mouseleave',clr)}
d.querySelectorAll('.cv-sel').forEach(x=>x.classList.remove('cv-sel'));
const els=SEL?secEls(d,SEL):[];els.forEach(x=>x.classList.add('cv-sel'));if(!els.length)SEL=null;selBar()}catch{}}
/* chamado pelo núcleo depois de cada desenho / mudança de estilo: refaz as folhas e a selecção */
function guides(){paginate();measure();fit();prevMark();typeof toolVis=='function'&&toolVis()}
/* menu flutuante por baixo da barra da secção: kind 'es' (datas) ou 'ls' (pontuação) */
function esMenu(b,kind,title,names,cur){const m=$('#esm'),same=!m.hidden&&m.dataset.k==kind;m.dataset.k=kind;
m.innerHTML='<b>'+title+'</b>'+Object.entries(names).map(([v,n])=>`<button type="button" data-${kind}="${v}"${v==cur?' class="on"':''}>${n}</button>`).join('');m.hidden=same;if(same)return;
const r=b.getBoundingClientRect(),s=$('#stage').getBoundingClientRect();m.style.top=(r.bottom-s.top+4)+'px';m.style.left=Math.max(2,Math.min(s.width-m.offsetWidth-2,r.left-s.left))+'px'}
$('#selbar').onclick=e=>{const b=e.target.closest('button');if(!b||!SEL)return;
if(b.dataset.a=='x'){selSet(null);return}
if(b.dataset.a=='es'){esMenu(b,'es','Estilo das datas',ESN,ESV()[SEL]||'classic');return}
if(b.dataset.a=='ls'){const df=T=='professional'?'bar':T=='classic'?'':'dots',nm={classic:(df?LSN[df]:'Texto')+' (padrão)'};for(const[k,v]of Object.entries(LSN))if(k!='classic'&&k!=df)nm[k]=v;esMenu(b,'ls','Estilo da pontuação',nm,LSV()[SEL]||'classic');return}
if(b.dataset.a=='pl'){const sdc=SIDE(),el=secEls(fr.contentDocument,SEL)[0];if(!sdc||!el)return;const P=(D.place??={})[T]??={};P[SEL]=el.closest(sdc.box)?'main':'side';up();return}
if(b.dataset.a=='ed'){const k=SEL;SO={};SO[k]=true;build();const s=f.querySelector(`.sec[data-sec="${k}"]`);document.body.dataset.v='edit';
if(s){s.scrollIntoView({behavior:'smooth',block:'start'});s.classList.add('flash');setTimeout(()=>s.classList.remove('flash'),1400)}return}
if(b.dataset.m){const d=fr.contentDocument,el=secEls(d,SEL)[0],sib=[...el.parentElement.children].filter(x=>x.dataset.sec),i=sib.indexOf(el),n=sib[i+ +b.dataset.m];
if(!n||n.dataset.sec==SEL)return;const o=ORD(),a=o.indexOf(SEL),c=o.indexOf(n.dataset.sec);if(a<0||c<0)return;[o[a],o[c]]=[o[c],o[a]];D.order=o;build();up()}};

$('#esm').onclick=e=>{const b=e.target.closest('button[data-es],button[data-ls]');if(!b||!SEL)return;
if(b.dataset.ls!==undefined){const m={...LSV()};if(b.dataset.ls=='classic')delete m[SEL];else m[SEL]=b.dataset.ls;if(Object.keys(m).length)S.ls=m;else delete S.ls;$('#esm').hidden=true;save();theme();return}
const m={...ESV()};m[SEL]=b.dataset.es;S.es=m;$('#esm').hidden=true;save();theme()};

/* ---- aviso antes de substituir dados por um exemplo / projecto ---- */
let BASE=null;
const hasData=()=>!!(D.photo||['full_name','job_title','email','phone','address','location','website','linkedin','birth_date','gender','nationality','professional_summary','projects','additional_information'].some(k=>(D[k]||'').toString().trim())||['experience','education','languages','skills','certificates','hobbies','extra','references','custom_sections','pfields'].some(k=>(D[k]||[]).length));
const dirty=()=>hasData()&&JSON.stringify(D)!==BASE;
function askDlg(msg,btns){return new Promise(ok=>{const o=document.createElement('div');o.id='dlg';o.innerHTML='<div class="box"><p></p><div class="acts"></div></div>';o.querySelector('p').textContent=msg;
btns.forEach(([t,v,c])=>{const b=document.createElement('button');b.type='button';b.textContent=t;if(c)b.className=c;b.onclick=()=>{o.remove();ok(v)};o.querySelector('.acts').append(b)});document.body.append(o)})}
async function guardLoad(next){if(dirty()){const r=await askDlg('Tem alterações que ainda não guardou. Quer guardar o projecto actual antes de continuar?',[['Guardar e continuar','save','pri'],['Continuar sem guardar','go'],['Cancelar','x']]);if(r=='x')return;if(r=='save')projSave()}next()}
const sample0=sample;sample=async function(){await sample0();BASE=JSON.stringify(D)};
