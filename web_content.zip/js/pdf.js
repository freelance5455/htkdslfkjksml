(function () {
  'use strict';
  const P = (window.Pith = window.Pith || {});
  const U = P.util;
  const X = (P.exporter = {});

  X.transcript = function (chat, userName) {
    const lines = [`# ${chat.title}`, '', `Exported from Pith on ${U.stamp(Date.now())}`];
    if (chat.system) lines.push('', `Instructions for this chat: ${chat.system}`);
    chat.messages.forEach((m) => {
      lines.push('', `## ${m.role === 'user' ? userName : 'Gemini'}, ${U.stamp(m.ts)}`, '');
      (m.attachments || []).forEach((a) => lines.push(`[Attachment: ${a.name}]`));
      if (m.text) lines.push(m.text);
    });
    return lines.join('\n') + '\n';
  };

  X.text = (chat, userName) => new Blob([X.transcript(chat, userName)], { type: 'text/markdown' });

  // ---------------------------------------------------------------- PDF
  // Pages are drawn on canvases (so every script and emoji the device can render works)
  // and embedded as JPEG images in a minimal hand-built PDF.
  const W = 1190, H = 1684, MARGIN = 84;
  const SANS = '"Helvetica Neue", Arial, "Segoe UI", Roboto, "Noto Sans", sans-serif';
  const MONO = 'ui-monospace, Menlo, Consolas, "DejaVu Sans Mono", "Roboto Mono", monospace';

  X.pdf = async function (chat, userName) {
    const pages = [];
    let canvas, ctx, y;
    const newPage = () => {
      canvas = document.createElement('canvas');
      canvas.width = W; canvas.height = H;
      ctx = canvas.getContext('2d');
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, W, H);
      y = MARGIN;
      pages.push(canvas);
    };
    const room = (hgt) => { if (y + hgt > H - MARGIN) newPage(); };
    const font = (size, weight, mono) => { ctx.font = `${weight || 400} ${size}px ${mono ? MONO : SANS}`; };

    function wrap(text, maxW) {
      const out = [];
      text.split('\n').forEach((para) => {
        if (!para) { out.push(''); return; }
        let line = '';
        para.split(/(\s+)/).forEach((tok) => {
          const test = line + tok;
          if (ctx.measureText(test).width <= maxW || !line.trim()) { line = test; }
          else { out.push(line.trimEnd()); line = tok.trimStart(); }
          while (ctx.measureText(line).width > maxW && line.length > 1) {
            let cut = line.length - 1;
            while (cut > 1 && ctx.measureText(line.slice(0, cut)).width > maxW) cut--;
            out.push(line.slice(0, cut));
            line = line.slice(cut);
          }
        });
        out.push(line.trimEnd());
      });
      return out;
    }

    function drawText(text, o) {
      font(o.size, o.weight, false);
      const lh = Math.round(o.size * 1.5);
      wrap(text, W - 2 * MARGIN - (o.indent || 0)).forEach((line) => {
        room(lh);
        ctx.fillStyle = o.color || '#111';
        ctx.fillText(line, MARGIN + (o.indent || 0), y + o.size);
        y += lh;
      });
      y += o.after || 0;
    }

    function drawCode(lines) {
      const size = 20, lh = 28;
      font(size, 400, true);
      lines.forEach((raw) => {
        const parts = raw === '' ? [''] : wrap(raw, W - 2 * MARGIN - 32);
        parts.forEach((line) => {
          room(lh);
          font(size, 400, true);
          ctx.fillStyle = '#eef0ee';
          ctx.fillRect(MARGIN, y, W - 2 * MARGIN, lh);
          ctx.fillStyle = '#1b1f1b';
          ctx.fillText(line, MARGIN + 16, y + 21);
          y += lh;
        });
      });
      y += 12;
    }

    function drawMarkdown(src) {
      let inCode = false;
      let code = [];
      src.split('\n').forEach((line) => {
        if (/^\s*(```|~~~)/.test(line)) {
          if (inCode) { drawCode(code); code = []; }
          inCode = !inCode;
          return;
        }
        if (inCode) { code.push(line); return; }
        const hd = line.match(/^(#{1,6})\s+(.*)$/);
        if (hd) { drawText(plain(hd[2]), { size: 34 - hd[1].length * 3, weight: 700, after: 6 }); return; }
        if (!line.trim()) { y += 12; return; }
        const bullet = line.match(/^(\s*)[-*+]\s+(.*)$/);
        if (bullet) { drawText('•  ' + plain(bullet[2]), { size: 23, indent: 20 + bullet[1].length * 10 }); return; }
        drawText(plain(line), { size: 23 });
      });
      if (inCode) drawCode(code);
    }
    const plain = (s) => s.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '$1 ($2)').replace(/\*\*|__|`/g, '');

    newPage();
    drawText(chat.title, { size: 44, weight: 700, after: 4 });
    drawText('Exported from Pith on ' + U.stamp(Date.now()), { size: 20, color: '#777', after: 28 });

    for (const m of chat.messages) {
      drawText(`${m.role === 'user' ? userName : 'Gemini'}   ${U.stamp(m.ts)}`, { size: 20, weight: 700, color: '#666', after: 6 });
      for (const a of m.attachments || []) {
        let drawn = false;
        if (a.kind === 'image') {
          try {
            const blob = await P.media.blob(a.id);
            const img = blob && (await U.decodeImage(blob));
            if (img) {
              const scale = Math.min(1, 420 / img.naturalHeight, (W - 2 * MARGIN) / img.naturalWidth);
              const iw = img.naturalWidth * scale, ih = img.naturalHeight * scale;
              room(ih + 14);
              ctx.drawImage(img, MARGIN, y, iw, ih);
              y += ih + 14;
              drawn = true;
            }
          } catch (e) { /* fall back to a label */ }
        }
        if (!drawn) drawText(`[Attachment: ${a.name}]`, { size: 20, color: '#777', after: 4 });
      }
      if (m.text) drawMarkdown(m.text);
      y += 26;
    }

    const jpegs = [];
    for (const c of pages) {
      const blob = await new Promise((res) => c.toBlob(res, 'image/jpeg', 0.84));
      jpegs.push(new Uint8Array(await new Response(blob).arrayBuffer()));
    }
    return buildPdf(jpegs);
  };

  function buildPdf(jpegs) {
    const wPt = 595.28, hPt = 841.89;
    const enc = new TextEncoder();
    const parts = [];
    const offsets = [];
    let len = 0;
    const push = (x) => { const b = typeof x === 'string' ? enc.encode(x) : x; parts.push(b); len += b.length; };
    const obj = (n, body) => { offsets[n] = len; push(`${n} 0 obj\n${body}\nendobj\n`); };

    push('%PDF-1.4\n');
    obj(1, '<< /Type /Catalog /Pages 2 0 R >>');
    obj(2, `<< /Type /Pages /Count ${jpegs.length} /Kids [${jpegs.map((_, i) => `${3 + i * 3} 0 R`).join(' ')}] >>`);
    jpegs.forEach((jpg, i) => {
      const page = 3 + i * 3, content = page + 1, image = page + 2;
      obj(page, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${wPt} ${hPt}] /Resources << /XObject << /Im0 ${image} 0 R >> >> /Contents ${content} 0 R >>`);
      const draw = `q ${wPt} 0 0 ${hPt} 0 0 cm /Im0 Do Q`;
      obj(content, `<< /Length ${draw.length} >>\nstream\n${draw}\nendstream`);
      offsets[image] = len;
      push(`${image} 0 obj\n<< /Type /XObject /Subtype /Image /Width ${W} /Height ${H} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpg.length} >>\nstream\n`);
      push(jpg);
      push('\nendstream\nendobj\n');
    });
    const total = 3 + jpegs.length * 3;
    const xref = len;
    push(`xref\n0 ${total}\n0000000000 65535 f \n`);
    for (let k = 1; k < total; k++) push(String(offsets[k]).padStart(10, '0') + ' 00000 n \n');
    push(`trailer\n<< /Size ${total} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`);
    return new Blob(parts, { type: 'application/pdf' });
  }
})();
