// Mundo SHENLONG · ensamblado del motor: junta los módulos portados del archivo EDEN-Visor-3D (alturas, texturas, terreno,
// agua, flora, dragones, vida) y los conecta con la escena de RigWorld. No dibuja cielo propio (usa el de RigWorld) ni tiene
// personaje propio (usa el del usuario). Recibe THREE por parámetro, como el resto del proyecto.
//
// Uso:  const w = new ShenlongWorld({ THREE, scene, camera, renderer, zoo, flags });
//       await w.prepare(tier, onProgress);  → texturas, trabajos en segundo plano, terreno y módulos
//       await w.prestream(x, y, z, { onProgress });  → espera a que carguen las teselas de alrededor
//       w.update(camPos, dt, { state, lut, fogK, underwater });  cada fotograma
import { EDEN_DW_TEX } from './tex.js';
import { EDEN_DW_ATMOS } from './atmos.js';
import { EDEN_DW_TERRAIN } from './terrain.js';
import { EDEN_DW_FLORA } from './flora.js';
import { EDEN_DW_DRAGONS } from './dragons.js';
import { EDEN_DW_LIFE } from './life.js';

// Geometría del mundo y velocidades del archivo original (m/s). El 0 es «andar», con 3 y 10 de multiplicador al viajar.
export const SHEN = Object.freeze({
  SPAWN: [0, -500], // pradera central
  HEADING: Math.PI, // mirando al norte (−Z, hacia la Cumbre Celestial); en RigWorld el frente es (sen h, cos h)
  EDGE: 20800, // el borde del mundo es un muro suave
  CAM_NEAR: 0.45,
  CAM_FAR: 46000,
  SPEED_MUL: [1, 3, 10],
  FLY: [48, 170, 560],
});

export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export class ShenlongWorld {
  // flags: { flora, life, dragons } (true por defecto). zoo: createZoo(...) o null (sin dragones).
  constructor({ THREE, scene, camera, renderer, zoo = null, log = () => {}, flags = {} }) {
    this.THREE = THREE;
    this.scene = scene;
    this.camera = camera;
    this.renderer = renderer;
    this.zoo = zoo;
    this.log = log;
    this.flags = { flora: true, life: true, dragons: true, ...flags };
    this.pos = new THREE.Vector3(SHEN.SPAWN[0], 0, SHEN.SPAWN[1]); // posición del jugador (la actualiza el controlador)
    this.W = { ctx: { scene, camera, renderer }, position: this.pos }; // lo mínimo que esperan los módulos del juego original
    this.disposed = false;
    this.ready = false;
    this.mods = [];
    this.eng = null;
    this.DW = null;
    this.saved = null;
  }

  // El objeto DW es el «bus» del motor: cada módulo le añade sus funciones (texturas, terreno, etc.).
  #build() {
    const THREE = this.THREE;
    const DW = {};
    EDEN_DW_TEX(THREE, DW);
    EDEN_DW_ATMOS(THREE, DW);
    EDEN_DW_TERRAIN(THREE, DW);
    DW.THREE = THREE;
    DW.mods = [];
    const env = { log: this.log, zoo: this.zoo, EDEN: { dragonFlora: { enabled: !!this.flags.flora }, dragonLife: { enabled: !!this.flags.life } } };
    this.env = env;
    try {
      if (this.zoo && this.flags.dragons) EDEN_DW_DRAGONS(THREE, env).DWD_REGISTER(DW);
      EDEN_DW_FLORA(THREE, env).DWF_REGISTER(DW);
      EDEN_DW_LIFE(THREE, env).DWL_REGISTER(DW);
    } catch (e) {
      this.log('warn', 'shenlong', e); // si un módulo extra falla, el terreno sigue
    }
    return DW;
  }

  // tier 0..3 = bajo, medio, alto, ultra (DW.QUALITY). onProgress(p 0..1, texto).
  async prepare(tier = 0, onProgress = () => {}) {
    const DW = (this.DW = this.#build());
    const ti = Math.max(0, Math.min(DW.QUALITY.length - 1, tier | 0));
    const q = DW.QUALITY[ti];
    onProgress(0.05, 'Generando la roca y el suelo…');
    await DW.makeTextures(q);
    DW.texSize = q.texSize;
    if (this.disposed) return;
    onProgress(0.34, 'Levantando montañas…');
    const jobs = new DW.Jobs(q.workers);
    const terrain = new DW.Terrain(this.scene, q, jobs);
    this.eng = { DW, q, ti, jobs, terrain, scene: this.scene, H: DW.H, cam: new this.THREE.Vector3(), t0: performance.now(), renderer: this.renderer };
    this.mods = [];
    for (const m of DW.mods || []) {
      try {
        const inst = m.create ? m.create(this.eng, this.W) : m;
        if (inst) this.mods.push(inst);
      } catch (e) { this.log('warn', 'shenlong', e); }
    }
    onProgress(0.42, 'Despertando a los dragones…');
    this.ready = true;
  }

  get H() { return this.eng?.H; }
  get terrain() { return this.eng?.terrain; }

  // Altura del suelo exacta (la de la tesela dibujada). Sin motor listo, la altura analítica.
  groundAt(x, z) { return this.eng ? this.eng.terrain.groundAt(x, z) : 0; }
  // Agua en (x, z): { level, kind } con kind 0 agua, 1 hielo, 2 lava. Donde no hay lago, el nivel es el del mar (el agua solo se
  // «ve» donde el suelo queda por debajo del nivel).
  waterInfo(x, z) {
    const H = this.eng.H;
    const wi = H.waterAt(x, z);
    return wi >= 0 ? { level: H.WATER[wi].level, kind: H.WATER[wi].kind } : { level: H.SEA, kind: 0 };
  }
  // Superficie pisable: el hielo del lago glaciar se pisa; el agua y la lava no cuentan como suelo.
  groundTop(x, z) {
    const g = this.eng.terrain.groundAt(x, z);
    const w = this.waterInfo(x, z);
    return w.kind === 1 && g < w.level ? w.level : g;
  }

  // El mundo original usa un cielo y niebla muy lejanos: la cámara necesita un plano lejano enorme y la sombra del Sol se apaga.
  enter() {
    this.saved = { near: this.camera.near, far: this.camera.far };
    this.camera.near = SHEN.CAM_NEAR;
    this.camera.far = SHEN.CAM_FAR;
    this.camera.updateProjectionMatrix();
    for (const m of this.mods) { try { m.enter && m.enter(this.W); } catch (e) { this.log('warn', 'shenlong', e); } }
  }

  // Espera a que carguen las teselas de alrededor del punto (x, y, z) y planta la vegetación cercana. onProgress(p, texto).
  async prestream(x, y, z, { maxMs = 15000, p0 = 0.45, p1 = 0.97, text = 'Construyendo el terreno…', onProgress = null, atmos = null } = {}) {
    const e = this.eng, T = e.terrain, DW = e.DW;
    const t0 = performance.now();
    const cam = new this.THREE.Vector3(x, y + 5, z);
    let first = -1;
    T.pumpMs = e.jobs.mode === 'sync' ? 28 : 5;
    T.fast = true;
    for (let i = 0; i < 2000 && !this.disposed; i++) {
      if (atmos) atmos(0.016);
      T.update(cam, 0.016);
      let miss = 0;
      for (const w of T.wanted || []) if (w.l >= 6 || w.dist < 600) miss++;
      if (first < 0 && i > 1) first = Math.max(1, miss);
      if (onProgress && i % 3 === 0) onProgress(p0 + (p1 - p0) * Math.max(0, Math.min(1, first > 0 ? 1 - miss / first : 0)), text);
      if (i > 3 && miss === 0 && T.applyQ.length === 0) break;
      if (performance.now() - t0 > maxMs) break;
      await sleep(e.jobs.mode === 'worker' ? 28 : 2);
    }
    T.fast = false;
    T.pumpMs = 5;
    try {
      const fl = this.mods.find((m) => m.warm);
      if (fl) {
        onProgress?.(0.985, 'Plantando bosques y praderas…');
        await fl.warm(cam, this.W, 9000);
      }
    } catch (er) { this.log('warn', 'shenlong', er); }
  }

  // Un fotograma: luz y niebla (desde la atmósfera de RigWorld), teselas del terreno y módulos (flora, dragones, vida).
  update(camPos, dt, { state, lut = null, fogK = 1, underwater = false } = {}) {
    const e = this.eng;
    if (!e || this.disposed) return;
    e.cam.copy(camPos);
    if (state) this.DW.updateAtmos(state, dt, underwater, lut, fogK);
    e.terrain.update(camPos, dt);
    for (let i = 0; i < this.mods.length; i++) {
      const m = this.mods[i];
      try { m.update && m.update(camPos, dt, this.W); } catch (er) {
        this.log('warn', 'shenlong', er);
        if ((m._fail = (m._fail || 0) + 1) > 4) { try { m.dispose && m.dispose(); } catch { /* nada */ } this.mods.splice(i, 1); i--; }
      }
    }
  }

  // ¿Quedan teselas cercanas por cargar? (para el viaje rápido)
  settled(missDist = 500) {
    const e = this.eng;
    let miss = 0;
    for (const w of e.terrain.wanted || []) if (w.l >= 6 || w.dist < missDist) miss++;
    return miss === 0 && e.terrain.applyQ.length === 0 && e.jobs.busy() === 0;
  }

  // Información de zona para el letrero: { name, sub }. dragonName(id) → nombre del dragón.
  zoneInfo(x, y, z, underwater = false) {
    const H = this.eng?.H;
    if (!H) return { name: '', sub: '' };
    const hb = H.domHab(x, z);
    const names = ['Llanuras del Origen'].concat(H.HABS.slice(1).map((h) => h.name));
    let sub = `${Math.round(y).toLocaleString('es')} m`;
    let nearest = null, nd = 1e9;
    for (let i = 1; i < H.HABS.length; i++) {
      const l = H.HABS[i].lair;
      const d = Math.hypot(x - l.x, z - l.z);
      if (d < nd) { nd = d; nearest = H.HABS[i]; }
    }
    if (nearest && nd < 3200) {
      const dn = this.zoo?.SP?.[nearest.dragon]?.name || 'dragón';
      sub += ` · ${dn} a ${nd < 1000 ? `${Math.round(nd)} m` : `${(nd / 1000).toFixed(1)} km`}`;
    }
    if (underwater) sub += ' · bajo el agua';
    return { name: names[hb] || '', sub };
  }

  // Lugares del viaje rápido: [{ title, sub, acts: [{ label, x, z, yaw }] }]
  travelPoints() {
    const H = this.eng.H;
    const yawTo = (a, b) => Math.atan2(b.x - a.x, b.z - a.z); // rumbo de a hacia b (frente = (sen h, cos h))
    const out = [{ title: 'Llanuras del Origen', sub: 'Pradera central · punto de inicio', acts: [{ label: 'Ir', x: SHEN.SPAWN[0], z: SHEN.SPAWN[1], yaw: SHEN.HEADING }] }];
    for (let i = 1; i < H.HABS.length; i++) {
      const hb = H.HABS[i];
      const dn = this.zoo?.SP?.[hb.dragon]?.name || '';
      const ap = hb.go || hb.appr || hb.view;
      out.push({ title: hb.name, sub: dn ? `🐉 ${dn}` : '', acts: [
        { label: 'Mirador', x: hb.view.x, z: hb.view.z, yaw: yawTo(hb.view, hb.lair) },
        { label: 'Dragón', x: ap.x, z: ap.z, yaw: yawTo(ap, hb.lair) },
      ] });
    }
    return out;
  }


  // ── Dragones llamados ──────────────────────────────────────────────────────────────────────────────────────────────────────
  get #dr() { return this.mods.find((m) => m && typeof m.callTo === 'function') || null; }
  get hasDragons() { return !!this.#dr; }
  // [{ id, name, habitat, loaded, state: 'guarida'|'viniendo'|'aqui'|'volviendo', dist }]
  dragonList() {
    const d = this.#dr;
    return d ? d.list().map((x) => ({ ...x, name: this.zoo?.SP?.[x.id]?.name || x.id })) : [];
  }
  callDragon(id, P) {
    const d = this.#dr;
    return d ? d.callTo(id, P) : { ok: false, msg: 'Los dragones están apagados (Ajustes del mundo → Dragones, al volver a entrar).' };
  }
  sendDragonsHome(id = null) { return this.#dr ? this.#dr.sendHome(id) : 0; }
  // fn(tipo: 'start'|'arrive'|'home', { id, pos }) — para el sonido y los avisos.
  onDragonEvent(fn) {
    const d = this.#dr;
    if (d) d.onEvent = fn ? (type, it) => fn(type, { id: it.id, name: this.zoo?.SP?.[it.id]?.name || it.id, sp: this.zoo?.SP?.[it.id], pos: it.pos }) : null;
  }

  // Interruptores en caliente (los módulos de flora y vida consultan estos indicadores en cada fotograma).
  setFlag(name, on) {
    const E = this.env?.EDEN;
    if (!E) return;
    if (name === 'flora') E.dragonFlora.enabled = !!on;
    else if (name === 'life') E.dragonLife.enabled = !!on;
  }

  // Carga inicial por el bucle normal: terreno rápido y avance {p 0..1, done}. Se llama cada fotograma hasta que done sea true.
  beginLoad() {
    const T = this.eng.terrain;
    T.pumpMs = this.eng.jobs.mode === 'sync' ? 28 : 5;
    T.fast = true;
    this._first = -1;
    this._loadFrames = 0;
  }
  loadStep(missDist = 600) {
    const T = this.eng.terrain;
    let miss = 0;
    for (const w of T.wanted || []) if (w.l >= 6 || w.dist < missDist) miss++;
    this._loadFrames++;
    if (this._first < 0 && this._loadFrames > 2) this._first = Math.max(1, miss);
    const p = this._first > 0 ? 1 - miss / this._first : 0;
    return { p: Math.max(0, Math.min(1, p)), done: this._loadFrames > 4 && miss === 0 && T.applyQ.length === 0 };
  }
  endLoad() {
    const T = this.eng.terrain;
    T.fast = false;
    T.pumpMs = 5;
  }

  // Siembra la vegetación alrededor de un punto (tras un salto largo).
  async warm(x, y, z, ms = 6000) {
    try {
      const fl = this.mods.find((m) => m.warm);
      if (fl) await fl.warm(new this.THREE.Vector3(x, y, z), this.W, ms);
    } catch (er) { this.log('warn', 'shenlong', er); }
  }

  dispose() {
    if (this.disposed) return;
    this.disposed = true;
    const e = this.eng;
    for (const m of this.mods) { try { m.dispose && m.dispose(); } catch { /* nada */ } }
    this.mods = [];
    if (e) {
      try { e.terrain.dispose(); } catch (er) { this.log('warn', 'shenlong', er); }
      try { e.jobs.dispose(); } catch { /* nada */ }
    }
    try { if (this.DW?.T) for (const k in this.DW.T) this.DW.T[k]?.dispose?.(); } catch { /* nada */ }
    if (this.saved) {
      this.camera.near = this.saved.near;
      this.camera.far = this.saved.far;
      this.camera.updateProjectionMatrix();
    }
    this.eng = null;
  }
}
