// Mundo SHENLONG · vida ambiental: bandadas de aves, motas de luz/polvo y cascadas. Portado del archivo EDEN-Visor-3D.
// env = { log, EDEN: { dragonLife: { enabled } } (opcional) }
export function EDEN_DW_LIFE(THREE, env = {}) {
  const eLog = env.log || (() => {});
  const EDEN = env.EDEN;
function DWL_REGISTER(DW) {
  DW.mods.push({ name: 'life', create(eng, W) {
    try { if (typeof EDEN !== 'undefined' && EDEN.dragonLife && !EDEN.dragonLife.enabled) return null; } catch (_) {}
    const l = new DWLife(eng, W); return l.dead ? null : l;
  } });
}
function dwlRng(seed) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

// ave de ~240 triángulos: cuerpo en huso con cabeza y pico, cola en abanico y alas de plumas con dedos (el recorte
// de plumas se hace en el sombreador). aW = (fracción de envergadura, lado); aK = (tipo: 0 cuerpo 1 ala 2 cola 3 cabeza 4 pico, coordenada de cuerda)
function dwlBirdGeo() {
  const P = [], A = [], K = [], I = [];
  const add = (x, y, z, u, sd, tone, v) => { P.push(x, y, z); A.push(u, sd); K.push(tone, v); return P.length / 3 - 1; };
  // cuerpo
  const bx = [0.56, 0.50, 0.44, 0.38, 0.30, 0.20, 0.08, -0.05, -0.18, -0.30, -0.42];
  const rh = [0.0, 0.016, 0.040, 0.052, 0.050, 0.078, 0.105, 0.108, 0.085, 0.055, 0.030];
  const rw = [0.0, 0.012, 0.032, 0.046, 0.046, 0.075, 0.100, 0.098, 0.074, 0.046, 0.026];
  const SEG = 6, ring = [];
  for (let i = 0; i < bx.length; i++) {
    const r = []; const tone = i < 2 ? 4 : i < 5 ? 3 : 0;
    for (let k = 0; k < SEG; k++) { const a = k / SEG * 6.2832; r.push(add(bx[i], rh[i] * Math.sin(a) - 0.008, rw[i] * Math.cos(a), 0, 0, tone, 0)); } ring.push(r);
  }
  for (let i = 0; i < bx.length - 1; i++) for (let k = 0; k < SEG; k++) { const a = ring[i][k], b = ring[i][(k + 1) % SEG], c = ring[i + 1][k], d = ring[i + 1][(k + 1) % SEG]; I.push(a, b, d, a, d, c); }
  // cola: abanico con borde festoneado
  for (const sd of [-1, 1]) {
    const rows = [], NV = 3, NU = 3;
    for (let j = 0; j <= NV; j++) { const v = j / NV, row = []; for (let i = 0; i <= NU; i++) { const u = i / NU, hw = 0.04 + 0.19 * v; row.push(add(-0.38 - 0.5 * v, 0.0, sd * u * hw, u, sd, 2, v)); } rows.push(row); }
    for (let j = 0; j < NV; j++) for (let i = 0; i < NU; i++) { const a = rows[j][i], b = rows[j][i + 1], c = rows[j + 1][i], d = rows[j + 1][i + 1]; I.push(a, b, d, a, d, c); }
  }
  // alas
  const NU = 10, NV = 4;
  for (const sd of [-1, 1]) {
    const rows = [];
    for (let i = 0; i <= NU; i++) {
      const u = i / NU, le = 0.14 - 0.10 * u - 0.30 * Math.pow(u, 2.2), c = 0.42 - 0.10 * u - 0.22 * u * u * u, z = sd * (0.07 + 1.18 * u);
      const y = 0.035 * Math.sin(u * 3.1416) + 0.30 * Math.pow(Math.max(0, u - 0.62) / 0.38, 2.2);
      const row = []; for (let j = 0; j <= NV; j++) { const v = j / NV; row.push(add(le - v * c, y - 0.05 * v * (1 - u) + 0.02 * Math.sin(v * 3.1416), z, u, sd, 1, v)); } rows.push(row);
    }
    for (let i = 0; i < NU; i++) for (let j = 0; j < NV; j++) { const a = rows[i][j], b = rows[i][j + 1], c = rows[i + 1][j], d = rows[i + 1][j + 1]; if (sd > 0) I.push(a, c, d, a, d, b); else I.push(a, d, c, a, b, d); }
  }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(P, 3)); g.setAttribute('aW', new THREE.Float32BufferAttribute(A, 2)); g.setAttribute('aK', new THREE.Float32BufferAttribute(K, 2)); g.setIndex(I); g.computeVertexNormals(); return g;
}

class DWLife {
  constructor(eng, W) {
    this.eng = eng; this.W = W; this.DW = eng.DW; this.H = eng.H; this.T = eng.terrain; this.dead = false; this.t = 0; this.parts = [];
    this.group = new THREE.Group(); this.group.name = 'dw-life'; eng.scene.add(this.group);
    this.hw = new Float32Array(8); this.folP = new THREE.Vector3(); this.folInit = false;
    for (const f of [this.mkBirds, this.mkMotes, this.mkFalls]) { if (!f) continue; try { const s = f.call(this); if (s) this.parts.push(s); } catch (e) { eLog('warn', 'dragonWorld', e); } }
    if (!this.parts.length) this.dead = true;
  }
  enter() { this.folInit = false; }
  update(cam, dt, W) {
    if (this.dead) return; this.t += dt; const H = this.H;
    try { H.habWeights(cam.x, cam.z); for (let i = 0; i < 8; i++) this.hw[i] = H.HW[i] || 0; } catch (_) {}
    const camera = (W && W.ctx && W.ctx.camera) || (this.W && this.W.ctx && this.W.ctx.camera);
    for (const s of this.parts) { if (s.dead) continue; try { s.update(cam, dt, camera); } catch (e) { s.err = (s.err || 0) + 1; if (s.err > 3) { s.dead = true; try { s.dispose && s.dispose(); } catch (_) {} eLog('warn', 'dragonWorld', e); } } }
  }
  groundY(x, z) { const H = this.H; let y = H.heightAt(x, z, 16); for (const w of H.WATER) { if (Math.hypot(x - w.x, z - w.z) < w.r && w.level > y) y = w.level; } return y; }
  dispose() { this.dead = true; for (const s of this.parts) { try { s.dispose && s.dispose(); } catch (_) {} } try { this.eng.scene.remove(this.group); } catch (_) {} this.parts = []; }

  // ---------------- aves ----------------
  mkBirds() {
    const DW = this.DW, H = this.H, rnd = dwlRng(90210), hb = (k) => H.HABS.find(h => h && h.key === k), gY = (x, z) => this.groundY(x, z);
    const F = [];
    // giantes: envergadura ≈ 2.4·tam. Parámetros: centro, radio de órbita, altura sobre el suelo, n, tam, color, velocidad (m/s), aleteo (Hz), amplitud, vaivén
    const G = (x, z, r, dy, n, s, col, v, fl, amp, bob, sp) => F.push({ x, z, r, dy, n, s: s >= 3 ? s * 1.4 : s, col, v, fl: fl || 0.7, amp: amp === undefined ? 0.1 : amp, bob: bob === undefined ? 30 : bob, sp: sp || 0.18 });
    const dark = [0.06, 0.05, 0.045], white = [0.8, 0.82, 0.84], brown = [0.13, 0.09, 0.06], ash = [0.03, 0.03, 0.035];
    let h = hb('celestial'); G(h.lair.x, h.lair.z, 1100, 420, 3, 6.5, dark, 24, 0.55, 0.08, 50); G(h.view.x, h.view.z, 380, 110, 14, 1.2, white, 14, 5, 0.55, 14, 0.5);
    h = hb('glaciar'); G(h.lair.x, h.lair.z, 700, 300, 2, 5, white, 22, 0.6, 0.1, 40); G(h.view.x, h.view.z, 520, 160, 16, 1.25, [0.9, 0.92, 0.95], 15, 4.2, 0.5, 16, 0.5);
    h = hb('canon'); G(h.lair.x - 120, h.lair.z, 900, 260, 4, 5.5, brown, 21, 0.5, 0.07, 45); G(h.view.x, h.view.z, 260, 70, 12, 0.7, [0.05, 0.05, 0.07], 17, 8, 0.6, 10, 0.6);
    h = hb('jade'); G(h.view.x - 400, h.view.z, 600, 70, 18, 1.4, [0.95, 0.95, 0.93], 13, 3.2, 0.4, 14, 0.45); G(h.view.x + 200, h.view.z + 300, 280, 40, 12, 0.7, [0.1, 0.55, 0.2], 16, 8, 0.6, 8, 0.5);
    G(h.lair.x, h.lair.z, 800, 300, 2, 5, [0.1, 0.1, 0.12], 20, 0.5, 0.08, 40);
    h = hb('cascadas'); G(9100, 4300, 2500, 420, 2, 6, brown, 22, 0.55, 0.08, 45); G(h.view.x + 500, h.view.z + 200, 420, 60, 30, 0.55, [0.12, 0.12, 0.14], 18, 9, 0.6, 12, 0.55);
    G(9100, 4300, 1400, 45, 10, 1.4, white, 13, 3.2, 0.4, 10, 0.4);
    h = hb('mesas'); G(h.lair.x, h.lair.z, 900, 280, 3, 5.5, brown, 22, 0.55, 0.08, 45); G(h.view.x, h.view.z, 300, 90, 10, 0.9, [0.04, 0.04, 0.05], 15, 5, 0.55, 12, 0.5);
    h = hb('caldera'); G(h.lair.x, h.lair.z, 750, 320, 3, 5.5, ash, 20, 0.6, 0.1, 40); G(h.view.x, h.view.z, 300, 120, 14, 0.8, ash, 15, 6, 0.6, 12, 0.5);
    G(0, -500, 260, 55, 12, 0.9, [0.88, 0.88, 0.86], 12, 3.6, 0.5, 8, 0.5); G(0, -500, 700, 170, 2, 3.4, brown, 18, 0.6, 0.08, 25);
    let N = 0; for (const f of F) N += f.n; const NF = 10; N += NF;
    const iA = new Float32Array(N * 3), iB = new Float32Array(N * 4), iC = new Float32Array(N * 4), iCol = new Float32Array(N * 3); let k = 0;
    for (const f of F) {
      const cy = gY(f.x, f.z) + f.dy, sgn = rnd() < 0.5 ? -1 : 1;
      for (let i = 0; i < f.n; i++, k++) {
        const r = f.r * (1 + (rnd() - 0.5) * 2 * f.sp), om = sgn * f.v / f.r * (0.9 + rnd() * 0.2);
        iA.set([f.x, cy + (rnd() - 0.5) * f.dy * 0.3, f.z], k * 3); iB.set([r, rnd() * 6.2832, om, f.s * (0.85 + rnd() * 0.3)], k * 4);
        iC.set([f.fl * (0.85 + rnd() * 0.3), f.amp, f.bob * (0.5 + rnd()), 0], k * 4); const j = 0.85 + rnd() * 0.3; iCol.set([f.col[0] * j, f.col[1] * j, f.col[2] * j], k * 3);
      }
    }
    for (let i = 0; i < NF; i++, k++) { // pájaros pequeños que acompañan al jugador
      iA.set([(rnd() - 0.5) * 40, 6 + rnd() * 14, (rnd() - 0.5) * 40], k * 3); iB.set([5 + rnd() * 10, rnd() * 6.2832, (rnd() < 0.5 ? -1 : 1) * (0.5 + rnd() * 0.5), 0.3 + rnd() * 0.1], k * 4);
      iC.set([9 + rnd() * 3, 0.7, 1.5, 1], k * 4); const c = rnd() < 0.5 ? [0.12, 0.09, 0.07] : [0.1, 0.16, 0.28]; iCol.set(c, k * 3);
    }
    const base = dwlBirdGeo(), g = new THREE.InstancedBufferGeometry(); g.index = base.index; for (const a in base.attributes) g.setAttribute(a, base.attributes[a]);
    g.setAttribute('iA', new THREE.InstancedBufferAttribute(iA, 3)); g.setAttribute('iB', new THREE.InstancedBufferAttribute(iB, 4)); g.setAttribute('iC', new THREE.InstancedBufferAttribute(iC, 4)); g.setAttribute('iCol', new THREE.InstancedBufferAttribute(iCol, 3)); g.instanceCount = N;
    const uFol = { value: new THREE.Vector3() }, uFolK = { value: 0 };
    const VS = /* glsl */`
attribute vec3 iA; attribute vec4 iB, iC; attribute vec3 iCol; attribute vec2 aW, aK;
uniform float uTime; uniform vec3 uFol; uniform float uFolK;
varying vec3 vN, vW, vCol; varying vec4 vK;
void main(){
  float a = iB.y + iB.z * uTime; float dirS = iB.z < 0.0 ? -1.0 : 1.0; float s = iB.w;
  bool fol = iC.w > 0.5; vec3 c = fol ? uFol + iA : iA; if (fol) s *= uFolK;
  float rr = iB.x * (1.0 + 0.05 * sin(uTime * 0.13 + iB.y * 3.0));
  float bob = iC.z * sin(uTime * 0.21 + iB.y * 5.0) * (fol ? 0.3 : 1.0);
  vec3 pos = c + vec3(cos(a) * rr, bob, sin(a) * rr);
  vec3 fwd = vec3(-sin(a), 0.0, cos(a)) * dirS, inw = vec3(-cos(a), 0.0, -sin(a));
  float bk = 0.38; vec3 up1 = normalize(vec3(0.0, 1.0, 0.0) * cos(bk) + inw * sin(bk));
  vec3 rt = normalize(cross(fwd, up1)), up2 = cross(rt, fwd);
  vec3 p = position; float ph = uTime * iC.x * 6.2832 + iB.y * 7.0, u = aW.x;
  float fl = sin(ph - 1.1 * u) * iC.y * (0.15 + 0.85 * pow(u, 1.2)) * 1.6;
  p.y += abs(p.z) * (0.04 + fl); p.z *= 1.0 - 0.14 * abs(sin(ph)) * iC.y * u;
  p.y += aK.x < 0.5 ? sin(ph) * 0.012 : 0.0;
  vec3 w = pos + (fwd * p.x + up2 * p.y + rt * p.z) * s; vW = w;
  vN = normalize(fwd * normal.x + up2 * normal.y + rt * normal.z); vCol = iCol; vK = vec4(aK, u, aW.y);
  gl_Position = projectionMatrix * viewMatrix * vec4(w, 1.0);
}`;
    const FS = /* glsl */`
varying vec3 vN, vW, vCol; varying vec4 vK;
${DW.GLSL_ATM}
void main(){
  float tone = vK.x, v = vK.y, u = vK.z;
  if (tone > 0.5 && tone < 1.5) { // alas: dedos de las primarias y punta redondeada
    float slot = smoothstep(0.60, 0.68, u) * pow(0.5 + 0.5 * cos(6.2832 * (u - 0.6) * 13.0), 1.4);
    if (v > 1.0 - 0.55 * slot) discard;
    if (u > 0.9 && v > 1.0 - (u - 0.9) * 8.0) discard;
  } else if (tone > 1.5 && tone < 2.5) { // cola festoneada
    if (v > 0.86 + 0.14 * (0.5 + 0.5 * cos(6.2832 * u * 3.0))) discard;
  }
  vec3 N = normalize(vN); bool top = gl_FrontFacing; if (!top) N = -N;
  vec3 c0 = vCol;
  if (tone > 0.5 && tone < 1.5) { c0 *= mix(0.78, 1.05, smoothstep(0.0, 0.35, v)) * (1.0 - 0.38 * smoothstep(0.78, 1.0, u)); c0 *= 0.92 + 0.08 * sin(u * 90.0); if (!top) c0 = mix(c0, vec3(dot(c0, vec3(0.33))) * 1.5 + 0.04, 0.35); }
  else if (tone > 3.5) c0 = vec3(0.75, 0.58, 0.18);
  else if (tone > 2.5) c0 *= 1.15;
  else if (tone < 0.5) c0 *= 1.0 + 0.35 * clamp(-vN.y, 0.0, 1.0);
  float d = dot(N, uSunDir), lit = max(d, 0.0) + 0.35 * max(-d, 0.0);
  vec3 col = c0 * (uSunCol * lit + mix(uGndAmb, uSkyAmb, 0.5 + 0.5 * N.y) * 1.25 + uMoonCol * 1.5);
  col = aerial(col, vW);
  gl_FragColor = vec4(col, 1.0);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}`;
    const mat = new THREE.ShaderMaterial({ uniforms: Object.assign({}, DW.U, { uFol, uFolK }), vertexShader: VS, fragmentShader: FS, side: THREE.DoubleSide, fog: false });
    const mesh = new THREE.Mesh(g, mat); mesh.frustumCulled = false; this.group.add(mesh); const self = this, fwd = new THREE.Vector3();
    return {
      update(cam, dt, camera) {
        const gy = self.groundY(cam.x, cam.z); let fx = 0, fz = -1; if (camera) { camera.getWorldDirection(fwd); const l = Math.hypot(fwd.x, fwd.z) || 1; fx = fwd.x / l; fz = fwd.z / l; }
        const tx = cam.x + fx * 35, tz = cam.z + fz * 35, ty = Math.max(gy, cam.y - 8) + 6;
        if (!self.folInit) { self.folP.set(tx, ty, tz); self.folInit = true; } else { const k = Math.min(1, dt * 0.35); self.folP.x += (tx - self.folP.x) * k; self.folP.y += (ty - self.folP.y) * k; self.folP.z += (tz - self.folP.z) * k; }
        uFol.value.copy(self.folP); const w = self.hw, nightK = 1 - (self.DW.U.uNight.value || 0);
        const target = Math.min(1, w[0] + w[4] + w[5] + w[1] * 0.7) * nightK; uFolK.value += (target - uFolK.value) * Math.min(1, dt * 0.8);
      },
      dispose() { try { self.group.remove(mesh); g.dispose(); mat.dispose(); base.dispose(); } catch (_) {} }
    };
  }

  // ---------------- partículas de ambiente (caja alrededor de la cámara) ----------------
  mkMotes() {
    const DW = this.DW, N = [1200, 2000, 3200, 4000][this.eng.ti === undefined ? 2 : this.eng.ti], rnd = dwlRng(777), r4 = new Float32Array(N * 4), pos = new Float32Array(N * 3);
    for (let i = 0; i < N; i++) { r4[i * 4] = rnd(); r4[i * 4 + 1] = rnd(); r4[i * 4 + 2] = rnd(); r4[i * 4 + 3] = rnd(); }
    const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('aR', new THREE.BufferAttribute(r4, 4));
    const uCam = { value: new THREE.Vector3() }, uPx = { value: 800 }, uHW = { value: Array.from({ length: 8 }, () => 0) };
    const VS = /* glsl */`
attribute vec4 aR; uniform float uTime, uNight, uPx; uniform vec3 uCam; uniform float uHW[8]; uniform vec2 uWind;
varying vec4 vC;
void main(){
  // reparto de las partículas entre tipos según el hábitat donde está la cámara (todas se aprovechan)
  float wS = clamp(uHW[2] + uHW[1] * 0.5, 0.0, 1.0), wA = uHW[7] * 0.6, wE = uHW[7] * (0.2 + 0.6 * clamp(uNight + 0.15, 0.0, 1.0));
  float wP = (uHW[0] * 0.4 + uHW[4] * 0.3 + uHW[5] * 0.25 + uHW[1] * 0.12) * (1.0 - uNight);
  float wF = (uHW[0] * 0.5 + uHW[4] + uHW[5] * 0.8) * uNight, wD = (uHW[3] + uHW[6]) * (1.0 - uNight * 0.7);
  float c1 = wS, c2 = c1 + wA, c3 = c2 + wE, c4 = c3 + wP, c5 = c4 + wF, tot = c5 + wD;
  float r = aR.x * max(tot, 1.0);
  float t = r < c1 ? 0.0 : r < c2 ? 1.0 : r < c3 ? 2.0 : r < c4 ? 3.0 : r < c5 ? 4.0 : r < tot ? 5.0 : 6.0;
  float r2 = fract(aR.x * 1237.31);
  vec3 box = t < 0.5 ? vec3(46.0, 26.0, 46.0) : t < 2.5 ? vec3(80.0, 40.0, 80.0) : t < 3.5 ? vec3(110.0, 30.0, 110.0) : t < 4.5 ? vec3(60.0, 14.0, 60.0) : vec3(90.0, 30.0, 90.0);
  vec3 vel; float sz; vec3 col; float al; vec2 wd = uWind;
  if (t < 0.5) { vel = vec3(wd.x * 1.6, -1.35, wd.y * 1.6); sz = 0.11; col = vec3(1.0); al = 0.95; }
  else if (t < 1.5) { vel = vec3(wd.x * 1.2, -0.55, wd.y * 1.2); sz = 0.13; col = vec3(0.33, 0.31, 0.28); al = 0.78; }
  else if (t < 2.5) { vel = vec3(wd.x * 0.6, 1.1, wd.y * 0.6); sz = 0.09; col = vec3(3.0, 0.9, 0.2) * (0.5 + 0.5 * sin(uTime * (3.0 + r2 * 5.0) + r2 * 40.0)); al = 0.0; }
  else if (t < 3.5) { vel = vec3(wd.x * 0.25, 0.04, wd.y * 0.25); sz = 0.06; col = vec3(1.0, 0.85, 0.4); al = 0.55; }
  else if (t < 4.5) { vel = vec3(0.1, 0.03, -0.1); sz = 0.085; float bl = smoothstep(0.55, 1.0, 0.5 + 0.5 * sin(uTime * (1.5 + r2 * 2.0) + r2 * 60.0)); col = vec3(0.65, 1.0, 0.25) * bl * 2.6; al = 0.0; }
  else { vel = vec3(wd.x * 3.2, 0.0, wd.y * 3.2); sz = 0.24; col = vec3(0.82, 0.66, 0.46); al = 0.40; }
  vec3 P = aR.yzw * box + vel * uTime;
  P.x += sin(uTime * 0.6 + r2 * 40.0) * 0.8 * (t < 2.5 ? 1.0 : 0.6); P.z += cos(uTime * 0.5 + r2 * 33.0) * 0.8 * (t < 2.5 ? 1.0 : 0.6);
  vec3 q = mod(P - uCam + box * 0.5, box) - box * 0.5; vec3 wp = uCam + q;
  float edge = 1.0 - smoothstep(0.32, 0.5, max(max(abs(q.x) / box.x, abs(q.y) / box.y), abs(q.z) / box.z));
  vec4 mv = viewMatrix * vec4(wp, 1.0); float dd = -mv.z;
  bool vis = t < 5.5 && tot > 0.01;
  float pxs = clamp(sz * uPx / max(dd, 0.5), 1.4, 26.0);
  gl_PointSize = vis ? pxs : 0.0; gl_Position = vis ? projectionMatrix * mv : vec4(2.0, 2.0, 2.0, 1.0);
  vC = vec4(col, al * edge * smoothstep(0.3, 2.0, dd));
}`;
    const FS = /* glsl */`
varying vec4 vC; uniform vec3 uSkyAmb, uSunCol, uMoonCol; uniform vec3 uSunDir;
void main(){
  vec2 c = gl_PointCoord * 2.0 - 1.0; float d = dot(c, c); if (d > 1.0) discard; float f = 1.0 - d;
  float lightF = clamp(length(uSkyAmb) * 1.4 + uSunCol.r * 0.08 * max(uSunDir.y, 0.0), 0.08, 1.4);
  bool glow = vC.a < 0.0001 && max(vC.r, max(vC.g, vC.b)) > 0.0;
  vec3 col = glow ? vC.rgb : vC.rgb * lightF;
  float a = glow ? 0.0 : vC.a * f;
  gl_FragColor = vec4(glow ? col * f * f : col, a);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
  gl_FragColor.rgb *= (glow ? 1.0 : a); // se premultiplica DESPUÉS de codificar el color (si no, las partículas tenues salen blanquecinas)
}`;
    const mat = new THREE.ShaderMaterial({ uniforms: Object.assign({}, DW.U, { uCam, uPx, uHW }), vertexShader: VS, fragmentShader: FS, transparent: true, depthWrite: false, blending: THREE.CustomBlending, blendEquation: THREE.AddEquation, blendSrc: THREE.OneFactor, blendDst: THREE.OneMinusSrcAlphaFactor, fog: false });
    const pts = new THREE.Points(g, mat); pts.frustumCulled = false; pts.renderOrder = 5; this.group.add(pts); const self = this;
    return {
      update(cam, dt, camera) {
        uCam.value.copy(cam); const rd = self.eng.renderer || (self.W && self.W.ctx && self.W.ctx.renderer);
        let hpx = 700; try { if (rd) { const s = rd.getSize(new THREE.Vector2()); hpx = s.y * (rd.getPixelRatio ? rd.getPixelRatio() : 1); } } catch (_) {} const fov = camera ? camera.fov : 60; uPx.value = 0.5 * hpx / Math.tan(fov * Math.PI / 360);
        for (let i = 0; i < 8; i++) uHW.value[i] = self.hw[i];
      },
      dispose() { try { self.group.remove(pts); g.dispose(); mat.dispose(); } catch (_) {} }
    };
  }
}

// ================================================================
// MUNDO DE DRAGONES — cascadas: 4 cintas de agua en las gargantas del
// Lago de las Cascadas (espuma que corre por la pendiente), bruma que
// asciende y salpicadura donde caen al lago. Se construye en diferido.
// ================================================================
DWLife.prototype.mkFalls = function () {
  const DW = this.DW, H = this.H, hb = H.HABS[5], L = H.WATER[1].level, self = this, rnd = dwlRng(4242);
  const wq = (x, z) => 160 * H.fbm(x / 800 + 2.2, z / 800 + 9.1, 3) + 430 * H.fbm(x / 1500 + 7.7, z / 1500 - 3.3, 3);
  const gy = (x, z) => H.heightAt(x, z, 16);
  const NA = 7;
  const state = { built: false, meshes: [], geos: [], mats: [] };

  // trayectoria de la garganta k: línea de menor altura, suavizada, desde el nacimiento hasta la orilla
  function path(k) {
    const a = (-2.35 + k * 1.52) + 0.04 * k, ca = Math.cos(a), sa = Math.sin(a), nx = -sa, nz = ca, P = []; let lo = 0, first = true;
    for (let r = 3700; r > 1900; r -= 22) {
      const bx = hb.x + ca * r, bz = hb.z + sa * r, d = r + wq(bx, bz); if (d > 3300) continue;
      let by = 1e9, bo = 0; for (let o = -60; o <= 60; o += 10) { const y = gy(bx + nx * o, bz + nz * o); if (y < by - 0.01) { by = y; bo = o; } }
      lo = first ? bo : lo * 0.75 + bo * 0.25; first = false;
      const x = bx + nx * lo, z = bz + nz * lo, y = gy(x, z); P.push({ x, z, y });
      if (y <= L + 1.5) break;
    }
    for (let i = 1; i < P.length - 1; i++) P[i].ys = (P[i - 1].y + 2 * P[i].y + P[i + 1].y) / 4; P[0].ys = P[0].y; if (P.length) P[P.length - 1].ys = P[P.length - 1].y;
    return P;
  }

  function build() {
    const pos = [], uv = [], kk = [], nor = [], idx = [], mist = [], splash = []; let base = 0;
    for (let k = 0; k < 4; k++) {
      const P = path(k), n = P.length; if (n < 8) continue;
      const s = new Float32Array(n); for (let i = 1; i < n; i++) s[i] = s[i - 1] + Math.hypot(P[i].x - P[i - 1].x, P[i].z - P[i - 1].z, P[i].ys - P[i - 1].ys);
      const len = s[n - 1], sl = new Float32Array(n);
      for (let i = 0; i < n; i++) { const j = Math.min(n - 1, i + 1), i0 = Math.max(0, i - 1), ds = Math.hypot(P[j].x - P[i0].x, P[j].z - P[i0].z) || 1; sl[i] = Math.max(0, (P[i0].ys - P[j].ys) / ds); }
      for (let i = 0; i < n; i++) {
        const j = Math.min(n - 1, i + 1), i0 = Math.max(0, i - 1);
        let tx = P[j].x - P[i0].x, tz = P[j].z - P[i0].z, ty = P[j].ys - P[i0].ys; const tl = Math.hypot(tx, ty, tz) || 1; tx /= tl; ty /= tl; tz /= tl;
        let lx = -tz, lz = tx; const ll = Math.hypot(lx, lz) || 1; lx /= ll; lz /= ll;
        let nx = ty * lz, ny = tz * lx - tx * lz, nz = -ty * lx; if (ny < 0) { nx = -nx; ny = -ny; nz = -nz; } const nl = Math.hypot(nx, ny, nz) || 1; nx /= nl; ny /= nl; nz /= nl;
        const tt = s[i] / len, w = 24 + 46 * Math.pow(tt, 0.8) + 6 * Math.sin(i * 0.9 + k * 2.1);
        for (let a = 0; a < NA; a++) {
          const u = a / (NA - 1) * 2 - 1, x = P[i].x + lx * u * w * 0.5, z = P[i].z + lz * u * w * 0.5;
          let y = gy(x, z) + 0.8; y = Math.min(P[i].ys + 5, Math.max(P[i].ys - 0.5, y));
          pos.push(x, y, z); uv.push(u, s[i]); kk.push(sl[i], tt); nor.push(nx, ny, nz);
        }
      }
      for (let i = 0; i < n - 1; i++) for (let a = 0; a < NA - 1; a++) { const p0 = base + i * NA + a, p1 = p0 + 1, p2 = p0 + NA, p3 = p2 + 1; idx.push(p0, p1, p3, p0, p3, p2); }
      base += n * NA;
      // salpicadura y bruma en la desembocadura (con un poco de adelanto hacia el lago)
      const E = P[n - 1], E0 = P[Math.max(0, n - 4)]; let dx = E.x - E0.x, dz = E.z - E0.z; const dl = Math.hypot(dx, dz) || 1; dx /= dl; dz /= dl;
      const cx = E.x + dx * 55, cz = E.z + dz * 55; splash.push(cx, L + 1.3, cz, 150 + rnd() * 25);
      for (let m = 0; m < 34; m++) { const a = rnd() * 6.2832, rr = Math.sqrt(rnd()) * 80; mist.push(cx + Math.cos(a) * rr, L + 4 + rnd() * 10, cz + Math.sin(a) * rr, 70 + rnd() * 110, rnd(), 90 + rnd() * 170, 0.035 + rnd() * 0.05); }
      // bruma en los saltos más fuertes
      const ord = Array.from({ length: n - 6 }, (_, i) => i + 3).sort((a, b) => sl[b] - sl[a]), used = [];
      for (const i of ord) { if (used.length >= 6) break; if (used.some(u => Math.abs(s[u] - s[i]) < 90) || sl[i] < 0.35) continue; used.push(i); for (let m = 0; m < 3; m++) { mist.push(P[i].x + (rnd() - 0.5) * 24, P[i].ys + 4 + rnd() * 8, P[i].z + (rnd() - 0.5) * 24, 24 + rnd() * 40, rnd(), 28 + rnd() * 60, 0.06 + rnd() * 0.07); } }
    }
    if (!idx.length) return false;
    // cintas
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('aUV', new THREE.Float32BufferAttribute(uv, 2)); g.setAttribute('aK', new THREE.Float32BufferAttribute(kk, 2)); g.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3)); g.setIndex(idx);
    const VS = /* glsl */`
attribute vec2 aUV, aK; varying vec2 vUV, vK; varying vec3 vW, vN;
void main(){ vUV = aUV; vK = aK; vN = normal; vec4 wp = modelMatrix * vec4(position, 1.0); float dist = length(wp.xyz - cameraPosition); wp.y += 0.5 + dist * 0.0032; vW = wp.xyz; gl_Position = projectionMatrix * viewMatrix * wp; }`;
    const FS = /* glsl */`
varying vec2 vUV, vK; varying vec3 vW, vN; uniform sampler2D tNoise;
${DW.GLSL_ATM}
void main(){
  float u = vUV.x, v = vUV.y, sl = clamp(vK.x, 0.0, 1.4), tt = vK.y;
  float spd = 5.0 + 20.0 * clamp(sl, 0.0, 1.0), fv = v - uTime * spd;
  vec2 q = vec2(u * 0.55, fv * 0.0085);
  float n1 = texture2D(tNoise, q).g, n2 = texture2D(tNoise, q * vec2(2.7, 2.3) + vec2(0.37, 0.11)).r, n3 = texture2D(tNoise, vec2(u * 1.7 + 0.2, fv * 0.026)).g;
  float ledge = smoothstep(0.55, 0.9, texture2D(tNoise, vec2(0.13, v * 0.0042 + 0.3)).r);
  float foam = clamp(0.2 + sl * 0.95 + ledge * 0.5 + (n1 * 0.55 + n2 * 0.45 - 0.5) * 0.95 + (n3 - 0.5) * 0.5, 0.0, 1.0);
  float edge = 1.0 - smoothstep(0.5, 1.0, abs(u) + (n2 - 0.5) * 0.3);
  vec3 water = mix(vec3(0.04, 0.17, 0.2), vec3(0.2, 0.42, 0.45), n1);
  vec3 alb = mix(water, vec3(0.93, 0.96, 1.0), smoothstep(0.25, 0.8, foam));
  vec3 N = normalize(vN);
  vec3 lit = uSkyAmb * 1.25 + uSunCol * (0.30 + 0.45 * max(dot(N, uSunDir), 0.0)) + uMoonCol * 1.5;
  vec3 col = aerial(alb * lit, vW);
  float a = edge * smoothstep(0.0, 0.1, tt) * clamp(0.35 + foam * 0.9, 0.0, 0.97);
  gl_FragColor = vec4(col, a);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}`;
    const mat = new THREE.ShaderMaterial({ uniforms: Object.assign({}, DW.U), vertexShader: VS, fragmentShader: FS, transparent: true, depthWrite: false, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2, fog: false });
    const rib = new THREE.Mesh(g, mat); rib.frustumCulled = false; rib.renderOrder = 3; self.group.add(rib); state.meshes.push(rib); state.geos.push(g); state.mats.push(mat);
    // salpicadura (discos de espuma sobre el lago) y bruma (carteles que ascienden y se disipan)
    const quad = (nI, arr, sz, VSs, FSs, ord) => {
      const q = new THREE.PlaneGeometry(1, 1), ig = new THREE.InstancedBufferGeometry(); ig.index = q.index; ig.setAttribute('position', q.attributes.position);
      ig.setAttribute('iP', new THREE.InstancedBufferAttribute(new Float32Array(arr.P), 3)); ig.setAttribute('iS', new THREE.InstancedBufferAttribute(new Float32Array(arr.S), sz)); ig.instanceCount = nI;
      const m = new THREE.ShaderMaterial({ uniforms: Object.assign({}, DW.U), vertexShader: VSs, fragmentShader: FSs, transparent: true, depthWrite: false, side: THREE.DoubleSide, fog: false });
      const me = new THREE.Mesh(ig, m); me.frustumCulled = false; me.renderOrder = ord; self.group.add(me); state.meshes.push(me); state.geos.push(ig, q); state.mats.push(m);
    };
    const nS = splash.length / 4, SP = [], SS = []; for (let i = 0; i < nS; i++) { SP.push(splash[i * 4], splash[i * 4 + 1], splash[i * 4 + 2]); SS.push(splash[i * 4 + 3]); }
    quad(nS, { P: SP, S: SS }, 1, /* glsl */`
attribute vec3 iP; attribute float iS; varying vec2 vQ; varying vec3 vW;
void main(){ vQ = position.xy * 2.0; vec3 wp = vec3(iP.x + position.x * iS * 2.0, iP.y, iP.z + position.y * iS * 2.0); vW = wp; gl_Position = projectionMatrix * viewMatrix * vec4(wp, 1.0); }`,
    /* glsl */`
varying vec2 vQ; varying vec3 vW; uniform sampler2D tNoise;
${DW.GLSL_ATM}
void main(){
  float r = length(vQ); if (r > 1.0) discard;
  float n1 = texture2D(tNoise, vQ * 1.6 + vec2(0.0, uTime * 0.012)).g, n2 = texture2D(tNoise, vQ * 3.7 - vec2(uTime * 0.02, 0.0) + 0.5).r;
  float foam = clamp((1.0 - smoothstep(0.0, 0.55, r)) * 1.4 + n1 * 0.75 + n2 * 0.45 - 0.55 - r * 0.7, 0.0, 1.0);
  float a = (1.0 - smoothstep(0.5, 1.0, r)) * (0.2 + 0.8 * foam);
  vec3 lit = uSkyAmb * 1.25 + uSunCol * 0.45 + uMoonCol * 1.5;
  gl_FragColor = vec4(aerial(vec3(0.93, 0.96, 1.0) * lit, vW), a * 0.92);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}`, 2);
    const nM = mist.length / 7, MP = [], MS = []; for (let i = 0; i < nM; i++) { MP.push(mist[i * 7], mist[i * 7 + 1], mist[i * 7 + 2]); MS.push(mist[i * 7 + 3], mist[i * 7 + 4], mist[i * 7 + 5], mist[i * 7 + 6]); }
    quad(nM, { P: MP, S: MS }, 4, /* glsl */`
attribute vec3 iP; attribute vec4 iS; varying vec2 vQ; varying float vA, vSeed; varying vec3 vW; uniform vec2 uWind; uniform float uTime;
void main(){
  float ph = fract(uTime * iS.w + iS.y);
  vec3 c = iP + vec3(uWind.x, 0.0, uWind.y) * (22.0 + 60.0 * ph) + vec3(0.0, iS.z * ph, 0.0);
  float size = iS.x * (0.55 + 1.05 * ph);
  vec3 rt = vec3(viewMatrix[0][0], viewMatrix[1][0], viewMatrix[2][0]), up = vec3(viewMatrix[0][1], viewMatrix[1][1], viewMatrix[2][1]);
  vec3 wp = c + (rt * position.x + up * position.y) * size;
  vQ = position.xy * 2.0; vSeed = iS.y; vW = wp; vA = sin(3.14159 * ph) * (1.0 - 0.45 * ph) * smoothstep(15.0, 140.0, length(c - cameraPosition));
  gl_Position = projectionMatrix * viewMatrix * vec4(wp, 1.0);
}`,
    /* glsl */`
varying vec2 vQ; varying float vA, vSeed; varying vec3 vW; uniform sampler2D tNoise;
${DW.GLSL_ATM}
void main(){
  float r2 = dot(vQ, vQ); if (r2 > 1.0) discard;
  float n = texture2D(tNoise, vQ * 0.45 + vec2(vSeed * 3.7, vSeed * 1.9)).r, n2 = texture2D(tNoise, vQ * 1.1 + vec2(vSeed * 7.1, uTime * 0.02)).g;
  float a = pow(1.0 - r2, 1.6) * (0.35 + 0.9 * n) * (0.6 + 0.8 * n2);
  vec3 lit = uSkyAmb * 1.5 + uSunCol * 0.38 + uMoonCol * 1.2;
  gl_FragColor = vec4(aerial(vec3(0.92, 0.95, 1.0) * lit, vW), clamp(a * vA * 0.5, 0.0, 0.62));
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}`, 4);
    return true;
  }

  return {
    update(cam) {
      const d = Math.hypot(cam.x - hb.x, cam.z - hb.z);
      if (!state.built) { if (d > 14000) return; state.built = true; if (!build()) { this.dead = true; return; } }
      const v = d < 17000; for (const m of state.meshes) m.visible = v;
    },
    dispose() { for (const m of state.meshes) { try { self.group.remove(m); } catch (_) {} } for (const g of state.geos) { try { g.dispose(); } catch (_) {} } for (const m of state.mats) { try { m.dispose(); } catch (_) {} } state.meshes = []; }
  };
};


  return { DWL_REGISTER };
}
