// Mundo SHENLONG · control del personaje y la cámara. Misma entrada que el mundo EDEN (stick, mirada, saltar, saludar, correr),
// pero con las reglas de este mundo gigante: caminar (con multiplicador de viaje ×1/×3/×10), nadar en lagos y mar, pisar el hielo,
// no entrar en la lava y volar (48/170/560 m/s). Usa el personaje del usuario y su animador (los pies siguen el ciclo al caminar).
// Sin Three.js ni DOM: se puede probar en Node con un «mundo» falso que tenga groundTop(x,z) y waterInfo(x,z).
import { stickToWorld, targetSpeed, wrapAngle, EYE_HEIGHT } from '../world/physics.js';
import { CAMERA } from '../world/controller.js';
import { createTerrainFit } from '../rig/terrainFit.js';
import { SHEN } from './engine.js';

const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
const smooth = (a, b, x) => {
  const t = clamp((x - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
};

export const FLY_MAX_ALT = 9000; // techo de vuelo (m)
const GRAVITY = 22;
const JUMP_V = 6.4;
const STEP_DOWN = 6; // si el suelo baja menos que esto (ladera, teselas más finas al cargar) se sigue pegado; más es un precipicio y se cae

export class ShenlongController {
  // avatar: { animator, speeds(), applyPose(pose), scale, rig }.  world: { groundTop(x,z), groundAt(x,z), waterInfo(x,z) }.
  constructor({ avatar, world, spawn = SHEN.SPAWN, heading = SHEN.HEADING } = {}) {
    this.avatar = avatar;
    this.world = world;
    this.footIK = true;
    this.fit = null;
    try {
      if (avatar?.rig?.joints) this.fit = createTerrainFit(avatar.rig);
    } catch (err) {
      console.warn('[shenlong] sin adaptación al terreno', err);
    }
    this.x = spawn[0];
    this.z = spawn[1];
    this.heading = heading;
    this.y = world.groundTop(this.x, this.z);
    this.vy = 0;
    this.mode = 'walk'; // walk | swim | fly
    this.fly = false;
    this.speedLvl = 0; // índice en SHEN.SPEED_MUL / SHEN.FLY
    this.tilt = 0; // inclinación del cuerpo al volar (rad)
    this.grounded = true;
    this.steep = 0;
    this.blocked = false;
    this.speedNow = 0;
    this.camYaw = heading;
    this.camPitch = CAMERA.defaultPitch;
    this.camDist = CAMERA.defaultDist;
    this.focusY = this.y + CAMERA.focusHeight;
    this.cam = { x: 0, y: 0, z: 0, dist: 0 };
    this.focus = [0, 0, 0];
    this.look = [0, 0, 0];
    this.underwater = false;
    this.moving = false;
    this.#placeCamera(0);
  }

  // Ciclo ×1 → ×3 → ×10 → ×1. Devuelve el nuevo índice.
  cycleSpeed() {
    this.speedLvl = (this.speedLvl + 1) % SHEN.SPEED_MUL.length;
    return this.speedLvl;
  }
  setFly(on) {
    on = !!on;
    if (on === this.fly) return this.fly;
    this.fly = on;
    this.vy = 0;
    if (on) this.y += 3; // un pequeño impulso al despegar
    return on;
  }

  #ground = { x: 0, z: 0, k: 1, c: 1, s: 0, base: 0 };
  #sample = (lx, lz) => {
    const g = this.#ground;
    return (this.world.groundAt(g.x + g.k * (lx * g.c + lz * g.s), g.z + g.k * (-lx * g.s + lz * g.c)) - g.base) / g.k;
  };

  step(dt, inp) {
    dt = clamp(dt, 0, 0.05);
    const W = this.world;
    const an = this.avatar.animator;
    const sp = this.avatar.speeds();
    const k = this.avatar.scale || 1;

    // Cámara (igual que en EDEN: dedo a la derecha → mira a la derecha; dedo arriba → mira arriba).
    this.camYaw = wrapAngle(this.camYaw - inp.lookX * CAMERA.lookK);
    this.camPitch = clamp(this.camPitch + inp.lookY * CAMERA.lookK, CAMERA.minPitch, CAMERA.maxPitch);
    this.camDist = clamp(this.camDist * (inp.zoom || 1), CAMERA.minDist, CAMERA.maxDist);

    const [dx, dz, mag] = stickToWorld(inp.stick.x, inp.stick.y, this.camYaw);
    const turn = (rate) => {
      if (mag > 0.1) this.heading = wrapAngle(this.heading + wrapAngle(Math.atan2(dx, dz) - this.heading) * (1 - Math.exp(-rate * dt)));
    };
    let moved = 0;
    this.blocked = false;

    if (this.fly) {
      // ── Vuelo: se avanza hacia donde se mira (el pitch de la cámara sube y baja) ──
      this.mode = 'fly';
      const v = SHEN.FLY[this.speedLvl] * (mag > 0.1 ? mag : 0);
      turn(5);
      const pitchEff = clamp(this.camPitch - CAMERA.defaultPitch, -0.95, 0.95);
      const vy = mag > 0.1 ? -Math.sin(pitchEff) * v * 0.9 : 0;
      const hx = mag > 0.1 ? dx / mag : 0, hz = mag > 0.1 ? dz / mag : 0;
      const hv = v * Math.cos(pitchEff);
      this.x += hx * hv * dt;
      this.z += hz * hv * dt;
      this.y += vy * dt;
      if (inp.jump) this.y += 6; // el botón de salto da un empujón hacia arriba
      moved = Math.hypot(hx * hv, vy) * dt;
      an.setSpeed(0);
      const r = an.update(dt);
      this.avatar.applyPose(r.pose);
      this.moving = mag > 0.1;
      this.tilt += ((mag > 0.1 ? 0.35 + 0.45 * Math.min(1, v / 300) : 0) - this.tilt) * (1 - Math.exp(-4 * dt));
      this.vy = vy;
      this.grounded = false;
    } else {
      // ── A pie / nadando ──
      this.tilt += (0 - this.tilt) * (1 - Math.exp(-8 * dt));
      const g0 = W.groundTop(this.x, this.z);
      const wi = W.waterInfo(this.x, this.z);
      const depth = wi.kind === 0 ? wi.level - g0 : 0;
      const swimming = wi.kind === 0 && depth > 0.9 * k;
      this.mode = swimming ? 'swim' : 'walk';
      let want = targetSpeed(mag, sp, inp.sprint && !swimming);
      if (mag > 0.1) {
        const frac = clamp(this.speedNow / Math.max(sp.run, 0.1), 0, 1);
        const desired = Math.atan2(dx, dz);
        const diff = Math.abs(wrapAngle(desired - this.heading));
        turn(11 - 5 * frac);
        want *= 1 - 0.85 * smooth(0.7, 2.0, diff);
      }
      // Pendiente (a partir de la altura del suelo a ±1,5 m).
      const gx = (W.groundTop(this.x + 1.5, this.z) - W.groundTop(this.x - 1.5, this.z)) / 3;
      const gz = (W.groundTop(this.x, this.z + 1.5) - W.groundTop(this.x, this.z - 1.5)) / 3;
      this.steep = 1 - 1 / Math.sqrt(1 + gx * gx + gz * gz);
      want *= 1 - 0.45 * smooth(0.08, 0.34, this.steep);
      if (swimming) want = Math.min(want, sp.walk * 0.8);
      else if (wi.kind === 0 && depth > 0.15) want *= 1 - 0.4 * smooth(0.15, 0.9, depth);

      an.setSpeed(sp.walk > 0 ? want / k : 0);
      if (inp.jump && this.grounded && !swimming) {
        this.vy = JUMP_V;
        this.grounded = false;
        an.jump();
      }
      if (inp.wave) an.wave();
      const r = an.update(dt);
      let pose = r.pose;
      if (this.fit && this.footIK && !swimming) {
        const g = this.#ground;
        g.x = this.x; g.z = this.z; g.k = k; g.c = Math.cos(this.heading); g.s = Math.sin(this.heading); g.base = W.groundAt(this.x, this.z);
        pose = this.fit.apply(pose, this.#sample, { dt, strength: r.state === 'jump' ? 0.3 : 1 });
      }
      this.avatar.applyPose(pose);
      this.moving = r.moving;

      // Avance: el del ciclo de la animación × multiplicador de viaje; la lava es un muro.
      const dist = r.groundSpeed * k * dt * (swimming ? 1 : SHEN.SPEED_MUL[this.speedLvl]);
      if (dist > 0) {
        const nx = this.x + Math.sin(this.heading) * dist, nz = this.z + Math.cos(this.heading) * dist;
        const wn = W.waterInfo(nx, nz);
        if (wn.kind === 2 && W.groundAt(nx, nz) < wn.level + 0.2) this.blocked = true;
        else {
          this.x = nx;
          this.z = nz;
          moved = dist;
        }
      }
      // Altura: se sigue el suelo (o la superficie del agua al nadar); en el aire cae por gravedad.
      const g = W.groundTop(this.x, this.z);
      const wn = W.waterInfo(this.x, this.z);
      const wd = wn.kind === 0 ? wn.level - g : 0;
      if (wn.kind === 0 && wd > 0.9 * k) {
        const target = wn.level - 1.0 * k; // flota con el pecho fuera
        this.y += (target - this.y) * (1 - Math.exp(-10 * dt));
        this.vy = 0;
        this.grounded = true;
      } else if (this.vy > 0 || (this.y > g + 0.06 && (!this.grounded || this.y - g > STEP_DOWN))) {
        this.vy -= GRAVITY * dt;
        this.y += this.vy * dt;
        if (this.y <= g && this.vy <= 0) {
          this.y = g;
          this.vy = 0;
          this.grounded = true;
        } else this.grounded = false;
      } else {
        // Pegado al suelo: sigue el relieve con suavidad (y de golpe si el salto es grande, como al viajar en ×10).
        this.y = Math.abs(g - this.y) > 1.5 ? g : this.y + (g - this.y) * (1 - Math.exp(-22 * dt));
        this.vy = 0;
        this.grounded = true;
      }
    }

    // Límites: muro suave en el borde del mundo, techo de vuelo y no atravesar el suelo.
    const rr = Math.hypot(this.x, this.z);
    if (rr > SHEN.EDGE) {
      this.x *= SHEN.EDGE / rr;
      this.z *= SHEN.EDGE / rr;
    }
    if (this.fly) {
      this.y = clamp(this.y, W.groundTop(this.x, this.z) + 1.8, FLY_MAX_ALT);
    }
    this.speedNow = dt > 0 ? moved / dt : 0;
    this.#placeCamera(dt);
    const wc = W.waterInfo(this.cam.x, this.cam.z);
    this.underwater = wc.kind === 0 && this.cam.y < wc.level && W.groundAt(this.cam.x, this.cam.z) < wc.level;
    return this.state;
  }

  // Órbita de la cámara: se acerca donde el terreno se interpone.
  #orbit(target, yaw, pitch, dist, out) {
    const W = this.world;
    const cp = Math.cos(pitch), sp = Math.sin(pitch);
    const dirX = -Math.sin(yaw) * cp, dirY = sp, dirZ = -Math.cos(yaw) * cp;
    let d = dist;
    const N = 10;
    for (let i = 1; i <= N; i++) {
      const t = (dist * i) / N;
      const x = target[0] + dirX * t, y = target[1] + dirY * t, z = target[2] + dirZ * t;
      if (y < W.groundTop(x, z) + 0.45) {
        d = Math.max(0.6, t - dist / N);
        break;
      }
    }
    out.x = target[0] + dirX * d;
    out.y = target[1] + dirY * d;
    out.z = target[2] + dirZ * d;
    const g = W.groundTop(out.x, out.z) + 0.4;
    if (out.y < g) out.y = g;
    out.dist = d;
    return out;
  }

  #placeCamera(dt) {
    const k = dt > 0 ? 1 - Math.exp(-9 * dt) : 1;
    this.focusY += (this.y + CAMERA.focusHeight - this.focusY) * k;
    this.focus = [this.x, this.focusY, this.z];
    this.#orbit(this.focus, this.camYaw, Math.max(this.camPitch, CAMERA.orbitMinPitch), this.camDist, this.cam);
    this.look = this.focus;
    const up = -this.camPitch;
    if (up > 0) {
      const c = this.cam;
      const hd = Math.max(1e-3, Math.hypot(this.focus[0] - c.x, this.focus[2] - c.z));
      if (up > Math.atan2(this.focus[1] - c.y, hd)) this.look = [this.focus[0], c.y + hd * Math.tan(up), this.focus[2]];
    }
  }

  // Coloca al personaje en otro punto (viaje rápido, volver al inicio). Termina a pie.
  teleport(x, z, heading = this.heading) {
    this.x = x;
    this.z = z;
    this.heading = heading;
    this.fly = false;
    this.mode = 'walk';
    this.y = this.world.groundTop(x, z);
    this.vy = 0;
    this.tilt = 0;
    this.camYaw = heading;
    this.focusY = this.y + CAMERA.focusHeight;
    this.speedNow = 0;
    this.avatar.animator.reset?.();
    this.fit?.reset();
    this.#placeCamera(0);
  }

  get state() {
    return {
      x: this.x, y: this.y, z: this.z, heading: this.heading, tilt: this.tilt,
      mode: this.mode, fly: this.fly, speedLvl: this.speedLvl, steepness: this.steep, blocked: this.blocked, underwater: this.underwater,
      speed: this.speedNow, camera: this.cam, look: this.look, focus: this.focus, yaw: this.camYaw, pitch: this.camPitch, dist: this.camDist,
      eye: [this.x, this.y + EYE_HEIGHT, this.z],
    };
  }
}
