// Mundo SHENLONG · campo de alturas (puro: sin THREE ni DOM). Se ejecuta en el hilo principal y en Web Workers
// (se serializa con Function.toString), por eso NO puede usar variables externas. Portado tal cual del archivo EDEN-Visor-3D.
export function EDEN_DW_HEIGHT() {
  'use strict';
  const SEA = -5;
  const clamp = (x, a, b) => x < a ? a : x > b ? b : x;
  const mix = (a, b, t) => a + (b - a) * t;
  const sstep = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };

  // ---------- ruido de gradiente con derivadas analíticas ----------
  const perm = new Uint8Array(512), gxT = new Float32Array(256), gzT = new Float32Array(256);
  (function () {
    let s = 20261105; const rnd = () => (s = (Math.imul(s, 1664525) + 1013904223) >>> 0) / 4294967296;
    const p = new Uint8Array(256); for (let i = 0; i < 256; i++) p[i] = i;
    for (let i = 255; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); const t = p[i]; p[i] = p[j]; p[j] = t; }
    for (let i = 0; i < 512; i++) perm[i] = p[i & 255];
    for (let i = 0; i < 256; i++) { const a = rnd() * 6.283185307; gxT[i] = Math.cos(a); gzT[i] = Math.sin(a); }
  })();
  let NV = 0, NDX = 0, NDZ = 0;
  function noiseD(x, z) {
    const ix = Math.floor(x), iz = Math.floor(z), fx = x - ix, fz = z - iz, X = ix & 255, Z = iz & 255;
    const i00 = perm[X + perm[Z]], i10 = perm[X + 1 + perm[Z]], i01 = perm[X + perm[Z + 1]], i11 = perm[X + 1 + perm[Z + 1]];
    const g00x = gxT[i00], g00z = gzT[i00], g10x = gxT[i10], g10z = gzT[i10], g01x = gxT[i01], g01z = gzT[i01], g11x = gxT[i11], g11z = gzT[i11];
    const a = g00x * fx + g00z * fz, b = g10x * (fx - 1) + g10z * fz, c = g01x * fx + g01z * (fz - 1), d = g11x * (fx - 1) + g11z * (fz - 1);
    const ux = fx * fx * fx * (fx * (fx * 6 - 15) + 10), uz = fz * fz * fz * (fz * (fz * 6 - 15) + 10);
    const dux = 30 * fx * fx * (fx - 1) * (fx - 1), duz = 30 * fz * fz * (fz - 1) * (fz - 1);
    const k1 = b - a, k2 = c - a, k4 = a - b - c + d;
    NV = a + ux * k1 + uz * k2 + ux * uz * k4;
    NDX = g00x + ux * (g10x - g00x) + uz * (g01x - g00x) + ux * uz * (g00x - g10x - g01x + g11x) + dux * (k1 + uz * k4);
    NDZ = g00z + ux * (g10z - g00z) + uz * (g01z - g00z) + ux * uz * (g00z - g10z - g01z + g11z) + duz * (k2 + ux * k4);
  }
  function hash2(ix, iz, s) { let h = Math.imul(ix | 0, 374761393) ^ Math.imul(iz | 0, 668265263) ^ Math.imul((s | 0) + 1013, 2147483629); h = Math.imul(h ^ (h >>> 13), 1274126177); h ^= h >>> 16; return (h >>> 0) / 4294967296; }
  // octavas permitidas según longitud de onda mínima representable
  function oc(lambda0, maxOct, mwl) { const n = Math.floor(Math.log2(lambda0 / mwl)) + 1; return n < 1 ? 1 : n > maxOct ? maxOct : n; }
  function fbm(x, z, oct) { let a = 0, b = 1, s = 0; for (let i = 0; i < oct; i++) { noiseD(x, z); a += b * NV; s += b; b *= 0.5; const t = 0.8 * x - 0.6 * z; z = (0.6 * x + 0.8 * z) * 2; x = t * 2; } return a / s; }
  function efbm(x, z, oct) { let a = 0, b = 0.5, dx = 0, dz = 0; for (let i = 0; i < oct; i++) { noiseD(x, z); dx += NDX; dz += NDZ; a += b * NV / (1 + dx * dx + dz * dz); b *= 0.5; const t = 0.8 * x - 0.6 * z; z = (0.6 * x + 0.8 * z) * 2; x = t * 2; } return a * 1.6; }
  function ridged(x, z, oct) { let sum = 0, amp = 0.5, w = 1, tot = 0; for (let i = 0; i < oct; i++) { noiseD(x, z); let n = 1 - Math.abs(NV * 1.7); n = clamp(n, 0, 1); n *= n; n *= w; w = clamp(n * 2, 0, 1); sum += n * amp; tot += amp; amp *= 0.5; const t = 0.8 * x - 0.6 * z; z = (0.6 * x + 0.8 * z) * 2; x = t * 2; } return sum / tot; }
  function terrace(h, step, sharp) { const t = h / step, f = Math.floor(t), r = t - f; return (f + sstep(1 - sharp, 1, r)) * step; }

  // ---------- definición del mundo ----------
  // dir = eje del valle (Gris), rot = giro general
  const HABS = [
    null,
    { key: 'celestial', name: 'Cumbre Celestial', dragon: 'dragonEo', x: 0, z: -9400, R: 6400, Rc: 2600, lair: { x: 40, z: -7850, r: 380 }, view: { x: 60, z: -5600 } },
    { key: 'glaciar', name: 'Glaciar de la Bruma', dragon: 'dragonEg', x: -8100, z: -4900, R: 5600, Rc: 2300, dirx: 0.83, dirz: 0.56, lair: { x: -7430, z: -4170, r: 230 }, view: { x: -5400, z: -2800 } },
    { key: 'canon', name: 'Cañón del Ocaso', dragon: 'dragonEn', x: 8300, z: -4700, R: 5600, Rc: 2400, lair: { x: 8300, z: -4700, r: 380 }, view: { x: 5900, z: -3000 } },
    { key: 'jade', name: 'Bahía de Jade', dragon: 'dragonE', x: -9400, z: 3500, R: 5600, Rc: 3300, lair: { x: -9150, z: 3350, r: 260 }, view: { x: -6400, z: 2300 } },
    { key: 'cascadas', name: 'Lago de las Cascadas', dragon: 'dragonEa', x: 9100, z: 4300, R: 5400, Rc: 2900, lair: { x: 8800, z: 4500, r: 330 }, view: { x: 6300, z: 3300 } },
    { key: 'mesas', name: 'Mesas de Bronce', dragon: 'dragonEb', x: 3300, z: 9500, R: 5200, Rc: 2300, lair: { x: 3300, z: 9500, r: 320 }, view: { x: 2400, z: 6800 } },
    { key: 'caldera', name: 'Caldera de Ceniza', dragon: 'dragonW', x: -3900, z: 9300, R: 6400, Rc: 2000, lair: { x: -4350, z: 9420, r: 330 }, view: { x: -3200, z: 6300 } }
  ];
  // plataformas de las guaridas (alturas objetivo)
  const LEO = { x: HABS[1].lair.x, z: HABS[1].lair.z, h: 2460 };
  const WATER = [
    { key: 'jade', x: -9400, z: 3500, r: 3700, level: 128, kind: 0 },     // 0 agua
    { key: 'cascadas', x: 9100, z: 4300, r: 3000, level: 380, kind: 0 },
    { key: 'hielo', x: -6850, z: -3700, r: 1250, level: 765, kind: 1 },    // 1 hielo
    { key: 'lava', x: -3650, z: 9250, r: 520, level: 1182, kind: 2 }      // 2 lava
  ];
  // máscaras con forma propia: el hielo y la lava solo existen donde la cubeta está tallada (no hay borde circular)
  function iceLakeMask(x, z) { return 1 - sstep(520, 700, Math.hypot(x - WATER[2].x, z - WATER[2].z) * 0.8 * (1 + 0.34 * fbm(x / 330 + 4.1, z / 330 - 2.7, 3) + 0.12 * fbm(x / 95, z / 95, 2))); }
  function lavaLakeMask(x, z) { return 1 - sstep(220, 360, Math.hypot(x - WATER[3].x, z - WATER[3].z) * (1 + 0.30 * fbm(x / 120 + 9.3, z / 120 - 4.4, 3) + 0.1 * fbm(x / 40, z / 40, 2))); }
  WATER[2].mask = iceLakeMask; WATER[3].mask = lavaLakeMask;
  const ENV = [
    // snow, grass, tree, dens(0..1), vegBias
    [2350, 1900, 1650, 0.95, 1.0],
    [2900, 2750, 2350, 0.30, 0.9],
    [1250, 1350, 1100, 0.55, 0.6],
    [9999, 1500, 1500, 0.75, 0.85],
    [9999, 950, 950, 1.0, 1.0],
    [9999, 1000, 1000, 1.0, 1.0],
    [9999, 800, 650, 0.10, 0.25],
    [9999, 800, 800, 0.06, 0.12]
  ];

  // eje frontal de cada guarida (hacia donde mira el dragón) y forma irregular de la meseta
  for (let i = 1; i < 8; i++) { const Hb = HABS[i], t = Hb.appr || Hb.view; const fx = t.x - Hb.lair.x, fz = t.z - Hb.lair.z, l = Math.hypot(fx, fz) || 1; Hb.fx = fx / l; Hb.fz = fz / l; Hb.go = { x: Hb.lair.x + Hb.fx * Hb.lair.r * 0.62, z: Hb.lair.z + Hb.fz * Hb.lair.r * 0.62 }; }
  const LAIRP = [null, [3.1, 1.28, 0.96, 0.26], [5.7, 1.25, 0.95, 0.30], [8.3, 1.30, 0.95, 0.24], [2.2, 1.18, 0.95, 0.38], [4.4, 1.15, 1.00, 0.34, 1], [6.6, 1.55, 1.20, 0.30], [9.1, 1.30, 1.00, 0.30]];
  // distancia normalizada e irregular al centro de la guarida: 1 = borde de la meseta (nunca un círculo perfecto)
  function lairN(x, z, i) {
    const Hb = HABS[i], P = LAIRP[i], dx = x - Hb.lair.x, dz = z - Hb.lair.z;
    const u = (dx * Hb.fx + dz * Hb.fz) / P[1], v = (-dx * Hb.fz + dz * Hb.fx) / P[2];
    const d = Math.hypot(u, v) + 1e-3, ca = u / d, sa = v / d, lob = P[3], sd = P[0];
    const rag = P[4] || 0; // 1 = contorno extra irregular (costa de la isla de Cascadas: sin lóbulos regulares tipo "galleta")
    const env = rag ? Math.max(0.2, Math.min(1.8, 1 + 3.2 * fbm(ca * 0.8 + sd * 1.7, sa * 0.8 + 4.1, 2))) : 1;
    let lobes, wob;
    if (rag) { // pocas bahías y penínsulas grandes + rugosidad fina, sin repetición
      lobes = lob * 1.6 * fbm(ca * 1.15 + sd, sa * 1.15 - sd * 0.7, 2) + 0.28 * lob * env * fbm(ca * 3.3 - sd, sa * 3.3 + 2.3, 2);
      wob = 0.12 * fbm(x / 120 + sd, z / 120 - sd, 3) + 0.025 * fbm(x / 24 - sd, z / 24 + sd, 2);
    } else {
      lobes = lob * 1.3 * fbm(ca * 1.6 + sd, sa * 1.6 - sd * 0.7, 3) + 0.5 * lob * fbm(ca * 3.9 - sd, sa * 3.9 + 2.3, 2);
      wob = 0.07 * fbm(x / 65 + sd, z / 65 - sd, 3);
    }
    return d / (Hb.lair.r * (1 + lobes + wob));
  }
  // para la flora: distancia normalizada a la guarida más cercana (9 = lejos)
  function lairAt(x, z) {
    let m = 9;
    for (let i = 1; i < 8; i++) { const Hb = HABS[i]; const dx = x - Hb.lair.x, dz = z - Hb.lair.z; const rr = Hb.lair.r * 2.4; if (dx * dx + dz * dz > rr * rr) continue; const n = lairN(x, z, i); if (n < m) m = n; }
    return m;
  }

  const HW = new Float64Array(8);
  function habWeights(x, z) {
    const wq = 0.22 * fbm(x / 3100 + 2.7, z / 3100 - 6.1, 3);
    let sum = 0;
    for (let i = 1; i < 8; i++) {
      const H = HABS[i]; const d = Math.hypot(x - H.x, z - H.z) * (1 + wq);
      const w = 1 - sstep(H.Rc, H.R, d); HW[i] = w; sum += w;
    }
    if (sum > 1) { for (let i = 1; i < 8; i++) HW[i] /= sum; HW[0] = 0; } else HW[0] = 1 - sum;
    return sum;
  }

  // ---------- terreno base (valles y sierras templadas) ----------
  function baseH(x, z, mwl) {
    const w1 = fbm(x / 5200 + 4.1, z / 5200 + 9.3, 2), w2 = fbm(x / 5200 - 12.7, z / 5200 + 3.3, 2);
    const px = x + 1100 * w1, pz = z + 1100 * w2;
    const up = 0.5 + 0.5 * fbm(px / 15000 + 2.2, pz / 15000 - 5.4, 3);
    const r1 = ridged(px / 8200 + 1.7, pz / 8200 + 8.1, oc(8200, 3, mwl));
    const r2 = ridged(px / 3000 - 4.3, pz / 3000 + 2.2, oc(3000, 5, mwl));
    const er = efbm(px / 1700, pz / 1700, oc(1700, 12, mwl));
    const mount = r1 * (0.35 + 0.65 * up);
    let h = 160 + 380 * up + 1050 * mount + 520 * r2 * (0.15 + 0.85 * mount) + 580 * er * (0.35 + 0.9 * mount);
    // valle central (mirador de entrada)
    const hd = Math.hypot(x, z + 500);
    const hm = 1 - sstep(1300, 3300, hd);
    if (hm > 0) h = mix(h, 335 + 30 * er + 20 * fbm(x / 500, z / 500, 2), hm * 0.9);
    return h;
  }

  // ---------- habitats ----------
  function hEo(x, z, b, mwl) {
    const H = HABS[1];
    const wx = 650 * fbm(x / 2600 + 1.3, z / 2600 + 7.7, 2), wz = 650 * fbm(x / 2600 - 5.1, z / 2600 + 2.9, 2);
    const rr = Math.hypot(x - H.x + wx, z - H.z + wz) / 5800;
    const mass = Math.pow(Math.max(0, 1 - rr), 1.2);
    const cr = ridged(x / 2300 + 9.1, z / 2300 - 3.3, oc(2300, 9, mwl));
    let h = 560 + mass * (1450 + 1250 * cr) + 0.25 * b;
    h += 38 * efbm(x / 260, z / 260, oc(260, 6, mwl)) * mass;
    const ln = lairN(x, z, 1);
    const lm = 1 - sstep(0.80, 1.34, ln);
    if (lm > 0) {
      // meseta de roca pulida por el hielo: hondonadas, bloques y repisas en el borde
      const und = 7 * fbm(x / 140 + 3, z / 140 - 1, oc(140, 3, mwl)) + 2.6 * efbm(x / 38, z / 38, oc(38, 3, mwl)) + 1.8 * ridged(x / 22 + 4, z / 22 + 9, oc(22, 2, mwl));
      h = mix(h, LEO.h + und, lm) + 16 * (4 * lm * (1 - lm)) * ridged(x / 70 - 2, z / 70 + 5, oc(70, 3, mwl));
    }
    // muro de roca detrás de la guarida (al norte)
    const wall = Math.exp(-Math.pow((z - (LEO.z - 520)) / 330, 2) - Math.pow((x - LEO.x) / 760, 2));
    h += 720 * wall * (0.65 + 0.35 * cr);
    return h;
  }
  function hEg(x, z, b, mwl) {
    const H = HABS[2]; const dx = x - H.x, dz = z - H.z;
    const au = dx * H.dirx + dz * H.dirz, vx = -dx * H.dirz + dz * H.dirx;
    const av = Math.abs(vx + 140 * fbm(x / 900 + 1.1, z / 900 - 2.2, 2));
    const fl = 776 + 0.17 * Math.max(0, -au);
    const wallT = sstep(360, 1450, av);
    let h = fl + 1180 * Math.pow(wallT, 1.35);
    const pk = ridged(x / 1500 + 3.3, z / 1500 + 8.8, oc(1500, 8, mwl));
    h += pk * 950 * sstep(900, 2100, av);
    h += 760 * sstep(-3000, -4100, au);
    h += 42 * efbm(x / 170, z / 170, oc(170, 5, mwl)) * (wallT + 0.15);
    // morrena frontal (cordón irregular)
    const mo = Math.exp(-Math.pow((au - 820) / 150, 2)) * (1 - sstep(300, 650, av)) * (1 + 0.5 * fbm(x / 140, z / 140, 3));
    h += 52 * mo;
    // lengua glaciar convexa
    const aun = au + 240 * fbm(x / 450 + 3.3, z / 450 - 1.1, 3), avn = av + 55 * fbm(x / 210 - 1.7, z / 210 + 4.2, 3);
    const gl = (1 - sstep(260, 470, avn)) * sstep(840, 760, aun) * sstep(-3500, -3100, aun);
    h += 34 * gl * (1 - Math.pow(av / 470, 2) * 0.0);
    // cubeta del lago congelado
    const lk = iceLakeMask(x, z);
    if (lk > 0) h = mix(h, 738 + 7 * fbm(x / 140, z / 140, 3), lk);
    // terraza de la guarida
    const ln = lairN(x, z, 2);
    const lm = 1 - sstep(0.75, 1.36, ln);
    if (lm > 0) h = mix(h, 772 + 2.5 * fbm(x / 60, z / 60, 2) + 5 * efbm(x / 26, z / 26, oc(26, 3, mwl)), lm) + 9 * (4 * lm * (1 - lm)) * ridged(x / 40 + 7, z / 40 - 2, oc(40, 3, mwl));
    return h;
  }
  function hEn(x, z, b, mwl) {
    const H = HABS[3];
    const plat = 1060 + 38 * efbm(x / 900, z / 900, oc(900, 8, mwl));
    // red de cañones
    const wq = 380 * fbm(x / 1700 + 5.5, z / 1700 - 1.5, 2);
    const d = Math.abs(fbm((x + wq) / 2300 + 7.7, (z - wq) / 2300 - 2.2, 3));
    const cm = 1 - sstep(0.03, 0.105, d);
    const floorH = 560 + 30 * fbm(x / 500, z / 500, 3);
    let h = mix(plat, floorH, Math.pow(cm, 0.85));
    const wallm = cm * (1 - cm) * 4;
    if (wallm > 0.02) { const ht = terrace(h, 38, 0.4); h = mix(h, ht, wallm * 0.9); }
    h += 7 * efbm(x / 70, z / 70, oc(70, 4, mwl)) * (0.3 + wallm);
    // bahía de cañón rodeando la guarida
    const bay = Math.abs(Math.hypot(x - (H.x + 120), z - (H.z + 880)) - 640);
    const bm = (1 - sstep(60, 210, bay)) * sstep(1.15, 1.62, lairN(x, z, 3));
    h = mix(h, Math.min(h, 640 + 20 * fbm(x / 300, z / 300, 2)), bm * 0.95);
    const ln = lairN(x, z, 3);
    const lm = 1 - sstep(0.80, 1.22, ln);
    if (lm > 0) {
      const hh = mix(h, 1055 + 3.5 * fbm(x / 90, z / 90, 2) + 1.6 * efbm(x / 30, z / 30, oc(30, 3, mwl)), lm);
      h = mix(hh, terrace(hh, 34, 0.5), 4 * lm * (1 - lm) * 0.9);   // farallón escalonado por estratos
    }
    return h;
  }
  function hJade(x, z, b, mwl) {
    const H = HABS[4]; const d = Math.hypot(x - H.x, z - H.z) * (1 + 0.15 * fbm(x / 2300 + 6.2, z / 2300 - 1.3, 3) + 0.05 * fbm(x / 700, z / 700, 2));
    const L = WATER[0].level;
    // torres kársticas (Worley)
    const cs = 400; const ci = Math.floor(x / cs), cj = Math.floor(z / cs);
    let tw = 0, tprof = 0;
    for (let j = -1; j <= 1; j++) for (let i = -1; i <= 1; i++) {
      const cx = ci + i, cz = cj + j; const hx = hash2(cx, cz, 11), hz = hash2(cx, cz, 12), hr = hash2(cx, cz, 13), hh = hash2(cx, cz, 14);
      if (hh < 0.12) continue;
      const px = (cx + 0.12 + 0.76 * hx) * cs, pz = (cz + 0.12 + 0.76 * hz) * cs; const rad = 62 + 120 * hr * hr + 30 * hr;
      const tAng = 3.1416 * hash2(cx, cz, 15), asp = 0.68 + 0.64 * hash2(cx, cz, 16), tca = Math.cos(tAng), tsa = Math.sin(tAng), ux = x - px, uz = z - pz;
      const dd = Math.hypot((ux * tca + uz * tsa) / asp, (-ux * tsa + uz * tca) * asp);
      const wob = 1 + 0.30 * fbm(x / 140 + cx * 3.1, z / 140 + cz * 1.7, 3);
      const t = 1 - dd / (rad * wob); if (t <= 0) continue;
      const tall = 120 + 260 * hh * hh + 70 * hr;
      const prof = Math.pow(sstep(0.0, 0.42, t), 0.7) * (0.82 + 0.18 * t);
      const v = tall * prof; if (v > tw) { tw = v; tprof = t; }
    }
    tw += 9 * efbm(x / 55 + 3, z / 55 + 4, oc(55, 4, mwl)) * sstep(8, 60, tw);   // estrías de erosión
    // suelo sumergido poco profundo con bancos de arena e islas
    const isl = fbm(x / 900 + 3.3, z / 900 - 4.4, 3);
    const floor = L - 9 + 5 * fbm(x / 160, z / 160, 3) + 20 * sstep(0.12, 0.34, isl);
    let h = floor + tw;
    // orilla: la bahía se cierra con colinas selváticas
    const rim = L - 4 + 190 * sstep(2700, 3500, d) + 80 * sstep(3200, 4600, d) * (0.5 + 0.5 * fbm(x / 800, z / 800, 3));
    const inside = 1 - sstep(2900, 3550, d);
    h = mix(Math.max(b * 0.5 + 60, rim), h, inside);
    // torre-plataforma de la guarida
    const ln = lairN(x, z, 4);
    const tm = 1 - sstep(0.84, 1.10, ln);
    if (tm > 0) {
      const ang = Math.atan2(z - H.lair.z, x - H.lair.x), groove = 0.5 + 0.5 * Math.sin(ang * 23 + 5 * fbm(x / 110, z / 110, 2));
      const top = L + 218 + 5 * fbm(x / 80, z / 80, 2) + 2.5 * efbm(x / 30, z / 30, oc(30, 3, mwl));
      h = mix(h, top, Math.pow(tm, 0.62)) + 14 * (4 * tm * (1 - tm)) * groove;
    }
    return h;
  }
  function hAgua(x, z, b, mwl) {
    const H = HABS[5]; const L = WATER[1].level;
    const wq = 160 * fbm(x / 800 + 2.2, z / 800 + 9.1, 3) + 430 * fbm(x / 1500 + 7.7, z / 1500 - 3.3, 3);
    const d = Math.hypot(x - H.x, z - H.z) + wq;
    const bowl = 1 - sstep(1500, 2350, d);
    let h = L - 92 * Math.pow(bowl, 1.5) * (0.85 + 0.3 * fbm(x / 500, z / 500, 2));
    const wall = sstep(2150, 2750, d);
    h = Math.max(h, mix(L - 25, L + 560 + 300 * ridged(x / 900 + 1.1, z / 900 - 0.5, oc(900, 6, mwl)), wall));
    h += 22 * efbm(x / 130, z / 130, oc(130, 5, mwl)) * sstep(2000, 2500, d);
    // gargantas de cascadas
    const ang = Math.atan2(z - H.z, x - H.x);
    for (let k = 0; k < 4; k++) {
      const a = (-2.35 + k * 1.52) + 0.04 * k; let da = ang - a; da = Math.atan2(Math.sin(da), Math.cos(da));
      const lat = Math.abs(da) * d;             // distancia lateral en metros
      const notch = (1 - sstep(40, 150, lat)) * sstep(2000, 2300, d) * (1 - sstep(3300, 3900, d));
      if (notch > 0) { const chan = L + 40 + 480 * sstep(2280, 3000, d); h = mix(h, Math.min(h, chan), notch); }
    }
    // isla/terraza de la guarida
    const ln = lairN(x, z, 5);
    const lm = 1 - sstep(0.72, 1.28, ln);
    if (lm > 0) h = mix(h, L + 3.2 + 9 * (1 - sstep(0.0, 0.9, ln)) + 1.6 * fbm(x / 70, z / 70, 2) + 1.0 * efbm(x / 25, z / 25, oc(25, 3, mwl)), lm);
    // islotes y farallones alrededor de la isla
    if (ln < 2.9) for (let k = 0; k < 5; k++) {
      const a = k * 1.37 + 0.4, rr = H.lair.r * (1.5 + 0.22 * (k & 1)) * (1 + 0.1 * k);
      const ix = H.lair.x + Math.cos(a) * rr, iz = H.lair.z + Math.sin(a) * rr, dd = Math.hypot(x - ix, z - iz) / ((30 + 9 * k) * (1 + 0.5 * fbm(x / 45 + k * 5, z / 45 - k, 3)));
      if (dd < 1.8) h = Math.max(h, L - 6 + (6 + 5 * ((k * 7) % 5)) * Math.exp(-dd * dd * 1.3) * (0.7 + 0.5 * ridged(x / 16 + k, z / 16, 3)) + 3 * fbm(x / 20 + k, z / 20, 2) * Math.exp(-dd * dd));
    }
    // fuera de la cuenca: base elevada
    h = mix(Math.max(h, b * 0.6 + 280), h, 1 - sstep(2900, 4300, d));
    return h;
  }
  function hMesas(x, z, b, mwl) {
    const H = HABS[6];
    const wq = 260 * fbm(x / 1400 + 4.4, z / 1400 - 8.8, 2);
    const m = fbm((x + wq) / 1500 + 4.4, (z - wq) / 1500 - 8.8, 3);
    let t = terrace(330 + (m + 0.55) * 700, 74, 0.2);
    t += 11 * efbm(x / 150, z / 150, oc(150, 6, mwl));
    const floorH = 420 + 28 * fbm(x / 800, z / 800, 3);
    let h = Math.max(floorH, t);
    // talud en la base de los farallones
    h = mix(h, floorH + (h - floorH) * 0.92, 0.3);
    // mesa de la guarida (cima plana)
    const ln = lairN(x, z, 6) + 0.06 * fbm(x / 110, z / 110, 3);
    const mm = 1 - sstep(0.90, 1.05, ln);
    if (mm > 0) {
      const hh = mix(h, 905 + 3 * fbm(x / 100, z / 100, 2) + 1.5 * efbm(x / 30, z / 30, oc(30, 3, mwl)), mm);
      h = mix(hh, terrace(hh, 40, 0.7), 4 * mm * (1 - mm) * 0.8);
    }
    const skirt = (1 - sstep(1.05, 1.75, ln)) * sstep(0.90, 1.05, ln);
    h += 50 * skirt * (0.4 + fbm(x / 200, z / 200, 2));
    return h;
  }
  function hCaldera(x, z, b, mwl) {
    const H = HABS[7];
    const wq = 380 * fbm(x / 1700 + 1.9, z / 1700 + 5.9, 3) + 90 * fbm(x / 420, z / 420, 2);
    const r = Math.hypot(x - H.x, z - H.z) + wq;
    let h = 480 + 1180 * Math.pow(Math.max(0, 1 - r / 7400), 1.9) + 0.35 * b;
    h += 90 * efbm(x / 500, z / 500, oc(500, 9, mwl)) * (0.3 + 0.7 * sstep(900, 4500, r)) + 30 * ridged(x / 330, z / 330, oc(330, 5, mwl));
    // flujos de lava solidificados (surcos radiales)
    const ang = Math.atan2(z - H.z, x - H.x);
    h -= 26 * (0.5 + 0.5 * Math.sin(ang * 23 + 4 * fbm(x / 800, z / 800, 2))) * sstep(1500, 2600, r) * (1 - sstep(4800, 6600, r));
    // caldera
    const ci = 1 - sstep(820, 1180, r);
    const rimH = 1480 + 70 * fbm(x / 400, z / 400, 3);
    const floorH2 = 1192 + 4 * fbm(x / 110, z / 110, 3);
    if (ci > 0) h = mix(h, Math.min(h, floorH2), ci);
    const rm = Math.exp(-Math.pow((r - 1180) / 170, 2));
    h = Math.max(h, mix(h, rimH, rm * 0.9));
    // lago de lava
    const lk = lavaLakeMask(x, z);
    if (lk > 0) h = mix(h, 1166 + 3 * fbm(x / 70, z / 70, 2), lk);
    // plataforma de la guarida
    const ln = lairN(x, z, 7);
    const lm = 1 - sstep(0.70, 1.25, ln);
    if (lm > 0) h = mix(h, 1194 + 2 * fbm(x / 70, z / 70, 2) + 3.2 * ridged(x / 38 + 1, z / 38 - 3, oc(38, 3, mwl)) + 1.5 * efbm(x / 18, z / 18, oc(18, 3, mwl)), lm);
    return h;
  }
  const HF = [null, hEo, hEg, hEn, hJade, hAgua, hMesas, hCaldera];

  function heightAt(x, z, mwl) {
    mwl = mwl || 4;
    let H = baseH(x, z, mwl);
    habWeights(x, z);
    let acc = 0;
    for (let i = 1; i < 8; i++) { const w = HW[i]; if (w > 0.002) acc += w * (HF[i](x, z, H, mwl) - H); }
    H += acc;
    // borde del mundo → océano
    const r = Math.hypot(x, z) + 2400 * fbm(x / 7500 + 8.8, z / 7500 - 3.1, 3);
    const e = sstep(15500, 21500, r);
    if (e > 0) H = mix(H, -95 + 22 * fbm(x / 900, z / 900, 3), e);
    return H;
  }
  // índice del cuerpo de agua que contiene el punto (o -1)
  function waterAt(x, z) {
    for (let i = 0; i < WATER.length; i++) { const w = WATER[i]; const dx = x - w.x, dz = z - w.z; if (dx * dx + dz * dz < w.r * w.r) { if (w.mask && w.mask(x, z) < 0.012) continue; return i; } }
    return -1;
  }
  function waterLevelAt(x, z) { const i = waterAt(x, z); return i < 0 ? SEA : WATER[i].level; }
  function domHab(x, z) { habWeights(x, z); let b = 0, bw = HW[0]; for (let i = 1; i < 8; i++) if (HW[i] > bw) { bw = HW[i]; b = i; } return b; }

  // ---------- campos de entorno ----------
  function envInto(out, x, z, h, ny, lap, s) {
    const slope = 1 - ny;
    let snowL = 0, grassL = 0, treeL = 0, dens = 0, vb = 0;
    for (let i = 0; i < 8; i++) { const w = HW[i]; if (w < 0.003) continue; const e = ENV[i]; snowL += w * e[0]; grassL += w * e[1]; treeL += w * e[2]; dens += w * e[3]; vb += w * e[4]; }
    const n1 = fbm(x / 85 + 7.1, z / 85 + 3.3, 3), n2 = fbm(x / 760 + 1.7, z / 760 - 4.2, 3);
    const wb = waterAt(x, z); const wl = wb < 0 ? SEA : WATER[wb].level;
    const dh = h - wl;
    const wet = 1 - sstep(-1, 6, dh);
    const moist = clamp(0.55 + 0.65 * n2 + 0.5 * wet, 0, 1);
    const veg = (1 - sstep(grassL - 450, grassL + 120, h + 90 * n1)) * (1 - sstep(0.26, 0.58, slope + 0.07 * n1)) * (0.3 + 0.7 * moist) * vb;
    const snow = sstep(snowL - 220, snowL + 80, h + 100 * n1) * (1 - sstep(0.42, 0.8, slope - 0.12 * n1));
    let can = veg * dens * (1 - sstep(treeL - 300, treeL + 60, h)) * (1 - sstep(0.18, 0.4, slope)) * (1 - wet) * clamp(0.5 + 1.2 * n2, 0, 1) * sstep(0.95, 1.5, lairAt(x, z));
    // Llanuras del Origen: praderas abiertas con bosquetes (y un claro amplio alrededor del punto de inicio)
    { const g0 = HW[0]; if (g0 > 0.003) { const sp = Math.hypot(x, z + 500) * (1 + 0.8 * n1) + 300 * fbm(x / 520 + 2.2, z / 520 - 8.1, 2), grove = sstep(-0.06, 0.12, fbm(x / 640 + 11.3, z / 640 - 5.7, 3)) * sstep(160, 430, sp); can *= 1 - g0 * (1 - grove); } }
    const ao = 1 - clamp(lap / (s * 0.9), -0.2, 0.62);
    out[0] = clamp(veg, 0, 1); out[1] = clamp(snow, 0, 1); out[2] = clamp(wet, 0, 1); out[3] = clamp(ao, 0, 1); out[4] = clamp(can, 0, 1);
  }
  // máscara de hielo glaciar (para el sombreador)
  function iceAt(x, z) {
    const H = HABS[2]; const dx = x - H.x, dz = z - H.z; const au = dx * H.dirx + dz * H.dirz, vx = -dx * H.dirz + dz * H.dirx;
    const av = Math.abs(vx + 140 * fbm(x / 900 + 1.1, z / 900 - 2.2, 2));
    const aun = au + 240 * fbm(x / 450 + 3.3, z / 450 - 1.1, 3), avn = av + 55 * fbm(x / 210 - 1.7, z / 210 + 4.2, 3);
    return (1 - sstep(300, 470, avn)) * sstep(840, 740, aun) * sstep(-3600, -3100, aun);
  }

  // ---------- teselas ----------
  function tile(x0, z0, size, N, lvl) {
    const s = size / N, mwl = 2 * s, M = N + 3, N1 = N + 1;
    const hs = new Float32Array(M * M);
    for (let j = 0; j < M; j++) for (let i = 0; i < M; i++) hs[j * M + i] = heightAt(x0 + (i - 1) * s, z0 + (j - 1) * s, mwl);
    const V = N1 * N1, S = 4 * N1, T = V + S;
    const pos = new Float32Array(T * 3), nrm = new Int8Array(T * 4), w0 = new Uint8Array(T * 4), w1 = new Uint8Array(T * 4), env = new Uint8Array(T * 4), env2 = new Uint8Array(T * 4), hg = new Float32Array(V);
    const skirt = Math.max(3, size * 0.008), eo = [0, 0, 0, 0, 0];
    let minH = 1e9, maxH = -1e9;
    for (let j = 0; j < N1; j++) for (let i = 0; i < N1; i++) {
      const k = j * N1 + i, c = (j + 1) * M + (i + 1), h = hs[c];
      const hl = hs[c - 1], hr = hs[c + 1], hd = hs[c - M], hu = hs[c + M];
      let nx = hl - hr, ny = 2 * s, nz = hd - hu; const nl = Math.hypot(nx, ny, nz); nx /= nl; ny /= nl; nz /= nl;
      const wx = x0 + i * s, wz = z0 + j * s;
      pos[k * 3] = i * s; pos[k * 3 + 1] = h; pos[k * 3 + 2] = j * s; hg[k] = h;
      if (h < minH) minH = h; if (h > maxH) maxH = h;
      nrm[k * 4] = Math.round(nx * 127); nrm[k * 4 + 1] = Math.round(ny * 127); nrm[k * 4 + 2] = Math.round(nz * 127);
      habWeights(wx, wz);
      // pesos de hábitat a bytes (suma 255)
      let tot = 0, bi = 0, bw = -1; const q = [0, 0, 0, 0, 0, 0, 0, 0];
      for (let b = 0; b < 8; b++) { q[b] = Math.round(HW[b] * 255); tot += q[b]; if (HW[b] > bw) { bw = HW[b]; bi = b; } }
      q[bi] += 255 - tot; if (q[bi] < 0) q[bi] = 0;
      w0[k * 4] = q[0]; w0[k * 4 + 1] = q[1]; w0[k * 4 + 2] = q[2]; w0[k * 4 + 3] = q[3]; w1[k * 4] = q[4]; w1[k * 4 + 1] = q[5]; w1[k * 4 + 2] = q[6]; w1[k * 4 + 3] = q[7];
      const lap = (hl + hr + hd + hu - 4 * h);
      envInto(eo, wx, wz, h, ny, lap, s);
      env[k * 4] = Math.round(eo[0] * 255); env[k * 4 + 1] = Math.round(eo[1] * 255); env[k * 4 + 2] = Math.round(eo[2] * 255); env[k * 4 + 3] = Math.round(eo[3] * 255);
      const ice = HW[2] > 0.02 ? iceAt(wx, wz) : 0;
      env2[k * 4] = Math.round(eo[4] * 255); env2[k * 4 + 1] = Math.round(ice * 255);
    }
    // faldones (skirts): copian el borde bajándolo
    const copy = (d, sIdx) => { for (let t = 0; t < 3; t++) pos[d * 3 + t] = pos[sIdx * 3 + t]; pos[d * 3 + 1] -= skirt; for (let t = 0; t < 4; t++) { nrm[d * 4 + t] = nrm[sIdx * 4 + t]; w0[d * 4 + t] = w0[sIdx * 4 + t]; w1[d * 4 + t] = w1[sIdx * 4 + t]; env[d * 4 + t] = env[sIdx * 4 + t]; env2[d * 4 + t] = env2[sIdx * 4 + t]; } };
    for (let t = 0; t < N1; t++) { copy(V + t, t); copy(V + N1 + t, N * N1 + t); copy(V + 2 * N1 + t, t * N1); copy(V + 3 * N1 + t, t * N1 + N); }
    return { lvl, x0, z0, size, N, pos, nrm, w0, w1, env, env2, hg, minH, maxH: maxH };
  }

  return { SEA, HABS, WATER, ENV, lairAt, lairN, heightAt, habWeights, HW, waterAt, waterLevelAt, domHab, iceAt, tile, hash2, fbm, efbm, ridged, sstep, mix, clamp, oc, noiseD, nv: () => NV, ndx: () => NDX, ndz: () => NDZ };
}
