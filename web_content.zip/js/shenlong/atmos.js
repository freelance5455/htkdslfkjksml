// Mundo SHENLONG · luz y niebla (conectadas a la atmósfera de RigWorld), perspectiva aérea, sombras de criaturas gigantes y agua/hielo/lava.
// Portado del archivo EDEN-Visor-3D: se quitó su cielo y su mar de nubes (ahora el cielo es el de RigWorld) y su ciclo día/noche propio.
export function EDEN_DW_ATMOS(THREE, DW) {
  'use strict';
  const V3 = THREE.Vector3, C3 = THREE.Color;
  const U = DW.U = {
    uTime: { value: 0 },
    uSunDir: { value: new V3(0, 1, 0) }, uSunCol: { value: new C3(3, 3, 3) },
    uMoonDir: { value: new V3(0, -1, 0) }, uMoonCol: { value: new C3(0, 0, 0) },
    uZenith: { value: new C3(0.11, 0.29, 0.7) }, uHorizon: { value: new C3(0.52, 0.69, 0.88) }, uGlow: { value: new C3(0.7, 0.55, 0.4) },
    uSkyAmb: { value: new C3(0.3, 0.4, 0.55) }, uGndAmb: { value: new C3(0.1, 0.09, 0.07) },
    uFog: { value: new THREE.Vector4(1 / 17000, 1 / 4200, 0, 0) },
    uMist: { value: new THREE.Vector4(0, 300, 1 / 260, 0) },
    uUnder: { value: 0 }, uUnderCol: { value: new C3(0.02, 0.2, 0.24) },
    uCaps: { value: Array.from({ length: 12 }, () => new THREE.Vector4()) }, uNCaps: { value: 0 },
    uCover: { value: 0.5 }, uWind: { value: new THREE.Vector2(1, 0.35) }, uNight: { value: 0 },
    tDetail: { value: null }, tNoise: { value: null }, tCloud: { value: null }, tWater: { value: null }, tSoil: { value: null }
  };

  // ---------- GLSL común ----------
  DW.GLSL_ATM = /* glsl */`
uniform vec3 uSunDir, uSunCol, uMoonDir, uMoonCol, uZenith, uHorizon, uGlow, uSkyAmb, uGndAmb, uUnderCol;
uniform vec4 uFog, uMist; uniform float uUnder, uTime;
vec3 skyBase(vec3 d){
  float y = d.y; float h = clamp(y, 0.0, 1.0);
  vec3 c = mix(uHorizon, uZenith, pow(h, 0.42));
  float mu = max(dot(d, uSunDir), 0.0);
  c += uGlow * (pow(mu, 5.0) * 0.20 + pow(mu, 36.0) * 0.55 + pow(mu, 300.0) * 1.2);
  float mm = max(dot(d, uMoonDir), 0.0);
  c += uMoonCol * (pow(mm, 18.0) * 0.25 + pow(mm, 220.0) * 0.5);
  if (y < 0.0) c = mix(c, uHorizon * 0.6, clamp(-y * 6.0, 0.0, 1.0));
  return c;
}
vec3 aerial(vec3 col, vec3 wp){
  vec3 v = wp - cameraPosition; float dist = length(v); vec3 d = v / max(dist, 0.001);
  float hc = cameraPosition.y, hp = wp.y, dy = hp - hc;
  float k = uFog.y; float tau = uFog.x * dist;
  if (k > 0.0) { float e = k * dy; tau *= (abs(e) < 1e-3) ? exp(-k * hc) : (exp(-k * hc) - exp(-k * hp)) / e; }
  if (uMist.x > 0.0) { float km = uMist.z; float em = km * dy; float b0 = exp(-km * (hc - uMist.y)); float f = (abs(em) < 1e-3) ? b0 : (b0 - exp(-km * (hp - uMist.y))) / em; tau += uMist.x * dist * f; }
  tau += uUnder * dist * 0.055;
  float f = 1.0 - exp(-tau);
  vec3 dd = normalize(vec3(d.x, max(d.y, 0.03), d.z));
  vec3 fc = skyBase(dd); fc = mix(uHorizon * 0.9 + 0.1 * fc, fc, 0.55);
  fc = mix(fc, uUnderCol, uUnder);
  return mix(col, fc, clamp(f, 0.0, 1.0));
}
float hash21(vec2 p){ p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
float hash31(vec3 p){ p = fract(p * vec3(443.897, 441.423, 437.195)); p += dot(p, p.yzx + 19.19); return fract((p.x + p.y) * p.z); }
`;


  // ---------- perspectiva aérea para materiales estándar de three (criaturas, props) ----------
  DW.UNI_NAMES = ['uSunDir', 'uSunCol', 'uMoonDir', 'uMoonCol', 'uZenith', 'uHorizon', 'uGlow', 'uSkyAmb', 'uGndAmb', 'uUnderCol', 'uFog', 'uMist', 'uUnder', 'uTime'];
  DW.aerialize = function (mat) {
    const prev = mat.onBeforeCompile, prevKey = mat.customProgramCacheKey ? mat.customProgramCacheKey() : '';
    const m = mat.clone();
    // los materiales "Basic/Points/Line" no declaran vViewPosition: se añade aquí (si no, el shader no compila y la malla desaparece)
    const noVP = !!(mat.isMeshBasicMaterial || mat.isPointsMaterial || mat.isLineBasicMaterial);
    // brillos aditivos (llamas, destellos): no se mezclan con la bruma; solo se clonan
    if (mat.blending === THREE.AdditiveBlending) { if (prev && prev !== Material_noop) { m.onBeforeCompile = prev; m.customProgramCacheKey = () => prevKey; } return m; }
    m.onBeforeCompile = function (shader, renderer) {
      if (prev && prev !== Material_noop) prev.call(this, shader, renderer);
      for (const k of DW.UNI_NAMES) shader.uniforms[k] = DW.U[k];
      if (noVP) {
        shader.vertexShader = shader.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vViewPosition;').replace('#include <project_vertex>', '#include <project_vertex>\nvViewPosition = -mvPosition.xyz;');
        shader.fragmentShader = shader.fragmentShader.replace('#include <common>', '#include <common>\nvarying vec3 vViewPosition;');
      }
      shader.fragmentShader = shader.fragmentShader.replace('#include <common>', '#include <common>\n' + DW.GLSL_ATM)
        .replace('#include <tonemapping_fragment>', 'gl_FragColor.rgb = aerial(gl_FragColor.rgb, cameraPosition + transpose(mat3(viewMatrix)) * (-vViewPosition));\n#include <tonemapping_fragment>');
    };
    m.customProgramCacheKey = () => prevKey + '|dwa';
    m.userData = Object.assign({}, m.userData, { dwAerial: true }); return m;
  };
  const Material_noop = THREE.Material.prototype.onBeforeCompile;

  // sombras proyectadas por criaturas gigantes (cápsulas A.xyz-B.xyz, radio A.w, intensidad B.w)
  DW.GLSL_CAPS = /* glsl */`
uniform vec4 uCaps[12]; uniform int uNCaps;
float dragonShadow(vec3 p, vec3 L){
  float vis = 1.0;
  for (int i = 0; i < 6; i++) {
    if (i >= uNCaps) break;
    vec4 A = uCaps[i * 2], B = uCaps[i * 2 + 1];
    vec3 ba = B.xyz - A.xyz; float r = A.w; vec3 w0 = p - A.xyz;
    float b = dot(L, ba), c = dot(ba, ba), d = dot(L, w0), e = dot(ba, w0);
    float s = clamp((e - b * d) / max(c - b * b, 1e-3), 0.0, 1.0);
    float tr = s * b - d; if (tr < 0.0) continue;
    vec3 q = w0 + tr * L - s * ba; float dist = length(q);
    float pen = r * 0.16 + tr * 0.03 + 5.0;
    float sh = 1.0 - smoothstep(r - pen, r + pen, dist);
    vis *= 1.0 - 0.8 * sh * B.w;
  }
  return vis;
}`;

  // ---------- agua / hielo / lava ----------
  const waterVS = /* glsl */`
attribute float aDepth; varying vec3 vW; varying float vDepth; uniform float uTime; uniform float uWave;
void main(){
  vec4 w = modelMatrix * vec4(position, 1.0);
  float sh = smoothstep(0.2, 4.0, aDepth);
  float dc = length(w.xz - cameraPosition.xz);
  float nearF = 1.0 - smoothstep(300.0, 1600.0, dc);
  w.y += (sin(w.x * 0.19 + uTime * 1.25) * 0.55 + sin(w.z * 0.14 - uTime * 1.05) * 0.45 + sin((w.x + w.z) * 0.33 + uTime * 1.9) * 0.25) * uWave * sh * nearF;
  vW = w.xyz; vDepth = aDepth; gl_Position = projectionMatrix * viewMatrix * w;
}`;
  const waterFS = /* glsl */`
varying vec3 vW; varying float vDepth; uniform sampler2D tWater, tNoise; uniform vec3 uShallow, uDeep, uFoam; uniform float uAbsorb, uKind, uRough;
${DW.GLSL_ATM}
void main(){
  vec3 toC = cameraPosition - vW; float dist = length(toC); vec3 V = toC / dist;
  vec2 uv = vW.xz; float fd = 1.0 - smoothstep(40.0, 900.0, dist);
  vec2 f1 = texture2D(tWater, uv * 0.045 + vec2(uTime * 0.010, uTime * 0.006)).xy * 2.0 - 1.0;
  vec2 f2 = texture2D(tWater, uv * 0.17 - vec2(uTime * 0.021, uTime * 0.014)).xy * 2.0 - 1.0;
  vec2 f3 = texture2D(tWater, uv * 0.77 + vec2(uTime * 0.05, -uTime * 0.04)).xy * 2.0 - 1.0;
  vec2 f4 = texture2D(tWater, uv * 2.9 + vec2(-uTime * 0.09, uTime * 0.07)).xy * 2.0 - 1.0;
  vec2 nn = f1 * 0.38 + f2 * 0.30 + f3 * 0.22 * fd + f4 * 0.14 * fd * fd;
  nn *= uRough;
  vec3 N = normalize(vec3(nn.x, 1.0, nn.y));
  float d = max(vDepth, 0.0);
  vec3 col; float alpha;
  if (uKind < 0.5) {
    float ab = 1.0 - exp(-d * uAbsorb);
    float lightF = 0.35 + 0.65 * clamp(uSunDir.y * 1.2 + 0.2, 0.0, 1.0);
    vec3 body = mix(uShallow, uDeep, ab) * (uSkyAmb * 0.9 + uSunCol * 0.18 * max(uSunDir.y, 0.0)) * (1.2 + lightF);
    vec3 R = reflect(-V, N); R.y = abs(R.y);
    vec3 refl = skyBase(normalize(vec3(R.x, max(R.y, 0.03), R.z)));
    float ndv = max(dot(N, V), 0.0); float fres = 0.02 + 0.98 * pow(1.0 - ndv, 5.0);
    col = mix(body, refl, clamp(fres * 1.0, 0.0, 1.0));
    float sp = pow(max(dot(R, uSunDir), 0.0), 900.0) * 14.0 + pow(max(dot(R, uSunDir), 0.0), 60.0) * 0.5;
    col += uSunCol * sp * smoothstep(-0.02, 0.1, uSunDir.y) * (0.4 + 0.6 * fd);
    float mp = pow(max(dot(R, uMoonDir), 0.0), 700.0) * 4.0; col += uMoonCol * mp * 20.0;
    // espuma de orilla
    float nz = texture2D(tNoise, uv * 0.06 + vec2(uTime * 0.02, 0.0)).r * 0.6 + texture2D(tNoise, uv * 0.19 - vec2(0.0, uTime * 0.03)).g * 0.4;
    float shore = 1.0 - smoothstep(0.0, 1.5, d + (nz - 0.5) * 0.9 + 0.35 * sin(uTime * 1.2 + nz * 6.0));
    float foam = shore * smoothstep(0.38, 0.72, nz) * fd;
    col = mix(col, uFoam * (0.5 + uSkyAmb * 0.8 + uSunCol * 0.2 * max(uSunDir.y, 0.0)), foam * 0.85);
    alpha = smoothstep(0.0, 0.55, d) * mix(0.42, 0.97, ab);
    alpha = max(alpha, fres * smoothstep(0.0, 0.25, d));
    alpha = max(alpha, foam * 0.9);
  } else if (uKind < 1.5) {
    // hielo: superficie lechosa con grietas
    float c1 = texture2D(tNoise, uv * 0.02).b, c2 = texture2D(tNoise, uv * 0.07 + 0.3).b; float crack = 1.0 - smoothstep(0.0, 0.1, min(c1, c2));
    float nz = texture2D(tNoise, uv * 0.013).r;
    vec3 base = mix(vec3(0.46, 0.66, 0.80), vec3(0.80, 0.90, 0.96), nz) * (uSkyAmb * 1.4 + uSunCol * 0.2 * max(uSunDir.y, 0.0));
    base = mix(base, vec3(0.12, 0.28, 0.4) * (uSkyAmb + 0.1), crack * 0.55);
    vec3 R = reflect(-V, normalize(vec3(nn * 0.25, 1.0).xzy)); R.y = abs(R.y);
    float fres = 0.04 + 0.5 * pow(1.0 - max(V.y, 0.0), 4.0);
    col = mix(base, skyBase(normalize(vec3(R.x, max(R.y, 0.03), R.z))), fres) + uSunCol * pow(max(dot(R, uSunDir), 0.0), 120.0) * 0.4;
    alpha = 0.98 * smoothstep(0.0, 0.3, d);
  } else {
    // lava: costra oscura y vetas incandescentes
    vec2 q = uv * 0.012; float t = uTime * 0.03;
    float a = texture2D(tNoise, q + vec2(t, 0.0)).r, b = texture2D(tNoise, q * 2.3 - vec2(0.0, t * 1.3)).g;
    float cr = texture2D(tNoise, q * 1.7 + 0.2 + vec2(t * 0.4, 0.0)).b;
    float heat = clamp(0.55 * (1.0 - cr * 1.7) + 0.5 * (a - 0.4) + 0.25 * (b - 0.4), 0.0, 1.0);
    heat = smoothstep(0.18, 0.75, heat);
    vec3 crust = vec3(0.025, 0.015, 0.012);
    vec3 hot = mix(vec3(1.6, 0.30, 0.04), vec3(3.2, 1.5, 0.35), smoothstep(0.55, 1.0, heat));
    col = mix(crust, hot, heat);
    col += vec3(0.5, 0.12, 0.02) * (0.5 + 0.5 * sin(uTime * 0.7 + a * 8.0)) * heat * 0.4;
    alpha = 1.0;
  }
  col = aerial(col, vW);
  gl_FragColor = vec4(col, alpha);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}`;
  DW.makeWaterMaterial = function (kind, o) {
    o = o || {};
    const u = Object.assign({}, U, {
      uShallow: { value: new C3(o.shallow || 0x2f7f86) }, uDeep: { value: new C3(o.deep || 0x0a3550) }, uFoam: { value: new C3(0xf2f6f8) },
      uAbsorb: { value: o.absorb || 0.09 }, uKind: { value: kind || 0 }, uRough: { value: o.rough || 1.0 }, uWave: { value: o.wave === undefined ? 0.5 : o.wave }
    });
    return new THREE.ShaderMaterial({ uniforms: u, vertexShader: waterVS, fragmentShader: waterFS, transparent: true, depthWrite: kind === 2, side: THREE.DoubleSide, fog: false });
  };
  // ---------- luz y niebla desde la atmósfera de RigWorld ----------
  // Aquí NO hay cielo propio: lo dibuja el mismo cielo que usa el mundo EDEN (js/world/atmosphere.js). Este módulo solo copia
  // su luz (Sol, Luna, ambiente) y los colores del horizonte a los uniformes de los sombreadores del terreno, el agua y la
  // vegetación, para que todo se vea con la misma luz. Las unidades son las de los materiales estándar: radiancia = albedo × E / π.
  const INV_PI = 1 / Math.PI;
  const CLAMP01 = (v) => (v < 0 ? 0 : v > 1 ? 1 : v);
  // state = atmosphereState(...) · fogK = multiplicador de niebla del clima (1 despejado) · lut = SkyLut (para el cénit).
  DW.updateAtmos = function (state, dt, underwater, lut, fogK) {
    const e = state.sun[1];
    U.uSunDir.value.fromArray(state.sun); U.uMoonDir.value.fromArray(state.moon);
    U.uSunCol.value.setRGB(state.sunColor[0] * INV_PI, state.sunColor[1] * INV_PI, state.sunColor[2] * INV_PI);
    U.uSkyAmb.value.setRGB(state.skyAmbient[0] * INV_PI, state.skyAmbient[1] * INV_PI, state.skyAmbient[2] * INV_PI);
    U.uGndAmb.value.setRGB(state.groundAmbient[0] * INV_PI, state.groundAmbient[1] * INV_PI, state.groundAmbient[2] * INV_PI);
    // El terreno multiplica la Luna por 2: se compensa para que tenga la misma fuerza que en EDEN.
    U.uMoonCol.value.setRGB(state.moonColor[0] * INV_PI * 0.5, state.moonColor[1] * INV_PI * 0.5, state.moonColor[2] * INV_PI * 0.5);
    // Colores de la niebla lejana: horizonte = el del cielo dibujado; cénit = lectura de la misma tabla.
    U.uHorizon.value.setRGB(state.fogColor[0], state.fogColor[1], state.fogColor[2]);
    const z = lut ? lut.sample([0, 1, 0], zen) : null;
    if (z) U.uZenith.value.setRGB(z[0], z[1], z[2]); else U.uZenith.value.setRGB(state.fogColor[0] * 0.45, state.fogColor[1] * 0.6, state.fogColor[2] * 0.95);
    U.uGlow.value.setRGB(Math.max(0, state.fogSunColor[0] - state.fogColor[0]) * 0.6, Math.max(0, state.fogSunColor[1] - state.fogColor[1]) * 0.6, Math.max(0, state.fogSunColor[2] - state.fogColor[2]) * 0.6);
    U.uNight.value = CLAMP01((-e - 0.04) * 7);
    // Bruma de valle: más densa al amanecer y al anochecer (igual que en el archivo original).
    const m = 0.0004 + 0.0010 * CLAMP01((0.28 - e) / 0.28) * (e > -0.3 ? 1 : 0.5);
    U.uMist.value.x = DW.mistScale * m * (fogK || 1); U.uMist.value.y = 330; U.uMist.value.z = 1 / 300;
    U.uFog.value.x = DW.fogScale * (fogK || 1) / 17000;
    U.uUnder.value = underwater ? 1 : 0;
    U.uTime.value += dt;
    return { e, nightF: CLAMP01((-e - 0.02) * 6) };
  };
  const zen = [0, 0, 0];
  DW.mistScale = 1; DW.fogScale = 1;
}
