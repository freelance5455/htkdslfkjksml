// Mundo SHENLONG · flora: árboles, arbustos, hierba, flores, helechos y rocas (atlas de hojas procedural, instancias por celdas,
// niveles de detalle y viento). Portado del archivo EDEN-Visor-3D.
// env = { log(nivel, sistema, error), EDEN: { dragonFlora: { enabled } } (opcional) }
export function EDEN_DW_FLORA(THREE, env = {}) {
  const eLog = env.log || (() => {});
  const EDEN = env.EDEN;
function dwfRng(seed) { let s = (seed >>> 0) || 1; return () => { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; return s / 4294967296; }; }
function dwfHash(a, b, c) { let h = Math.imul(a | 0, 374761393) ^ Math.imul(b | 0, 668265263) ^ Math.imul((c | 0) + 977, 2147483629); h = Math.imul(h ^ (h >>> 13), 1274126177); h ^= h >>> 16; return (h >>> 0) / 4294967296; }
const dwfLerp = (a, b, t) => a + (b - a) * t;

// ---------- atlas 1024×512: 4×2 celdas de 256 ----------
// fila 0: hoja ancha, conífera, palma, hoja fina · fila 1: helecho, hierba, flores, corteza
function dwfAtlas() {
  const W = 1024, Hh = 512, cs = 256;
  const cv = document.createElement('canvas'); cv.width = W; cv.height = Hh; const g = cv.getContext('2d', { willReadFrequently: true });
  const rnd = dwfRng(90210);
  const clip = (v) => Math.max(0, Math.min(255, v | 0));
  const leafCol = (l, k) => 'rgb(' + clip((70 + 30 * (k || 0)) * l * 1.35) + ',' + clip((122 + 14 * (k || 0)) * l * 1.3) + ',' + clip((38 + 14 * (k || 0)) * l * 1.2) + ')';
  const gray = (l) => 'rgb(' + clip(l * 255) + ',' + clip(l * 255) + ',' + clip(l * 255) + ')';
  const cell = (c, r, fn) => { g.save(); g.translate(c * cs, r * cs); g.beginPath(); g.rect(0, 0, cs, cs); g.clip(); fn(); g.restore(); };
  g.lineCap = 'round'; g.lineJoin = 'round';
  // 0: racimo de hojas anchas
  cell(0, 0, () => {
    const L = [];
    for (let i = 0; i < 96; i++) { const a = rnd() * 6.283, rr = Math.sqrt(rnd()) * 96, x = 128 + Math.cos(a) * rr, y = 134 + Math.sin(a) * rr * 0.88 - 6; L.push({ x, y, rot: a + 1.57 + (rnd() - 0.5) * 1.5, len: 34 + rnd() * 22, wid: 10 + rnd() * 7, l: 0.5 + 0.55 * rnd() + (140 - y) / 420 }); }
    L.sort((p, q) => p.l - q.l);
    for (const f of L) {
      g.save(); g.translate(f.x, f.y); g.rotate(f.rot);
      const gr = g.createLinearGradient(0, -f.len / 2, 0, f.len / 2); gr.addColorStop(0, leafCol(f.l * 1.15)); gr.addColorStop(1, leafCol(f.l * 0.75));
      g.fillStyle = gr; g.beginPath(); g.moveTo(0, -f.len / 2); g.quadraticCurveTo(f.wid, -f.len * 0.1, 0, f.len / 2); g.quadraticCurveTo(-f.wid, -f.len * 0.1, 0, -f.len / 2); g.fill();
      g.strokeStyle = leafCol(f.l * 0.55, 0); g.globalAlpha = 0.5; g.lineWidth = 1; g.stroke();
      g.strokeStyle = leafCol(f.l * 1.35); g.globalAlpha = 0.55; g.beginPath(); g.moveTo(0, -f.len * 0.42); g.lineTo(0, f.len * 0.42); g.stroke(); g.globalAlpha = 1;
      g.restore();
    }
    g.globalCompositeOperation = 'source-atop'; const gg = g.createLinearGradient(0, 36, 0, 232); gg.addColorStop(0, 'rgba(0,10,0,0)'); gg.addColorStop(1, 'rgba(0,10,0,0.5)'); g.fillStyle = gg; g.fillRect(0, 0, cs, cs); g.globalCompositeOperation = 'source-over';
  });
  // 1: rama de conífera (agujas a ambos lados de una ramilla)
  cell(1, 0, () => {
    g.strokeStyle = 'rgb(70,50,36)'; g.lineWidth = 4; g.beginPath(); g.moveTo(128, 254); g.lineTo(128, 8); g.stroke();
    const N = 46;
    for (let i = 0; i < N; i++) {
      const t = i / N, y = 246 - t * 232;
      const half = 112 * (0.2 + 0.8 * Math.sin(Math.min(1, t * 1.2 + 0.08) * 1.5708)) * (1 - 0.74 * Math.pow(t, 2.2));
      for (let side = -1; side <= 1; side += 2) for (let k = 0; k < 7; k++) {
        const th = (32 + 48 * rnd()) * Math.PI / 180, len = half * (0.35 + 0.65 * rnd()); const l = 0.36 + 0.42 * rnd() + 0.22 * (len / 120);
        g.strokeStyle = leafCol(l, 0.1); g.lineWidth = 2.4; g.beginPath(); g.moveTo(128, y); g.lineTo(128 + side * Math.sin(th) * len, y - Math.cos(th) * len); g.stroke();
      }
    }
  });
  // 2: fronda de palma (nervio central y folíolos caídos)
  cell(2, 0, () => {
    g.strokeStyle = 'rgb(120,150,70)'; g.lineWidth = 4; g.beginPath(); g.moveTo(128, 254); g.lineTo(128, 10); g.stroke();
    for (let i = 0; i < 74; i++) {
      const t = i / 74, y = 248 - t * 226, len = 108 * Math.pow(Math.sin(Math.PI * (0.05 + 0.95 * t)), 0.75) * (1 - 0.4 * t), ph = (62 - 22 * t) * Math.PI / 180;
      for (let side = -1; side <= 1; side += 2) {
        const ex = 128 + side * Math.sin(ph) * len, ey = y - Math.cos(ph) * len, cx = 128 + side * Math.sin(ph) * len * 0.55, cy = y - Math.cos(ph) * len * 0.45 + len * 0.16;
        const l = 0.5 + 0.4 * rnd() + 0.2 * t; g.strokeStyle = leafCol(l, 0.3); g.lineWidth = 3.2 - 1.4 * t;
        g.beginPath(); g.moveTo(128, y); g.quadraticCurveTo(cx, cy, ex, ey + len * 0.1); g.stroke();
      }
    }
  });
  // 3: hoja fina compuesta (acacia, bambú, sauce)
  cell(3, 0, () => {
    g.strokeStyle = 'rgb(96,80,50)'; g.lineWidth = 3; g.beginPath(); g.moveTo(128, 254); g.quadraticCurveTo(122, 130, 130, 8); g.stroke();
    for (let i = 0; i < 14; i++) {
      const t = i / 14, y = 244 - t * 224, side = i % 2 ? 1 : -1, len = 96 * (1 - 0.45 * t), ang = 56 * Math.PI / 180;
      const ex = 128 + side * Math.sin(ang) * len, ey = y - Math.cos(ang) * len; g.strokeStyle = 'rgb(100,100,56)'; g.lineWidth = 1.6; g.beginPath(); g.moveTo(128, y); g.lineTo(ex, ey); g.stroke();
      for (let k = 1; k < 14; k++) {
        const u = k / 14, px = dwfLerp(128, ex, u), py = dwfLerp(y, ey, u), ll = 15 * (1 - 0.5 * u), l = 0.55 + 0.5 * rnd();
        for (let s2 = -1; s2 <= 1; s2 += 2) { g.save(); g.translate(px, py); g.rotate(Math.atan2(ey - y, ex - 128) + s2 * 1.1); g.fillStyle = leafCol(l, 0.5); g.beginPath(); g.ellipse(ll * 0.5, 0, ll * 0.5, 2.6, 0, 0, 6.283); g.fill(); g.restore(); }
      }
    }
  });
  // 4: helecho (raquis curvo y pinas)
  cell(0, 1, () => {
    const P = (t) => [128 + 40 * Math.sin(t * 2.2) * t, 252 - t * 236], tg = (t) => { const a = P(Math.max(0, t - 0.02)), b = P(Math.min(1, t + 0.02)); const dx = b[0] - a[0], dy = b[1] - a[1], l = Math.hypot(dx, dy); return [dx / l, dy / l]; };
    g.strokeStyle = 'rgb(70,100,40)'; g.lineWidth = 3; g.beginPath(); for (let i = 0; i <= 30; i++) { const p = P(i / 30); i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1]); } g.stroke();
    for (let i = 2; i < 46; i++) {
      const t = i / 46, p = P(t), d = tg(t), len = 82 * Math.pow(Math.sin(Math.PI * (0.08 + 0.92 * t)), 0.8) * (1 - 0.5 * t);
      for (let side = -1; side <= 1; side += 2) {
        const nx = -d[1] * side, ny = d[0] * side, fx = nx * 0.8 + d[0] * 0.62, fy = ny * 0.8 + d[1] * 0.62; const l = 0.42 + 0.38 * rnd() + 0.16 * t;
        g.save(); g.translate(p[0], p[1]); g.rotate(Math.atan2(fy, fx)); g.fillStyle = leafCol(l, 0.1); g.beginPath(); g.moveTo(0, 0); g.quadraticCurveTo(len * 0.5, -6.5, len, 0); g.quadraticCurveTo(len * 0.5, 6.5, 0, 0); g.fill(); g.restore();
      }
    }
  });
  // 5: mata de hierba (solo luminancia; el color lo da la paleta del hábitat)
  cell(1, 1, () => {
    // hojas finas que se abren en abanico y cuelgan en la punta; alturas muy variadas (si no, la mata parece un rectángulo).
    // Las tarjetas de hierba son ~1.6-2.2 veces más anchas que altas: se comprime en x para que las hojas no salgan "gordas".
    g.save(); g.translate(128, 0); g.scale(0.625, 1); g.translate(-128, 0);
    const B = [];
    for (let i = 0; i < 58; i++) {
      const c = rnd() - 0.5;
      B.push({ x: 128 + c * 70 + (rnd() - 0.5) * 14, lean: c * 150 + (rnd() - 0.5) * 66, h: 46 + Math.pow(rnd(), 0.85) * (205 - 70 * Math.abs(c) * 2), w: 3.6 + rnd() * 4.6, l: 0.46 + 0.5 * rnd(), dr: rnd() });
    }
    B.sort((a, b) => a.l - b.l);
    for (const b of B) {
      const x0 = b.x, y0 = 254, px = b.x + b.lean * 0.1, py = 254 - b.h * 0.66, x2 = b.x + b.lean, y2 = 254 - b.h * (0.94 - 0.26 * b.dr);
      const gr = g.createLinearGradient(0, y0, 0, y2); gr.addColorStop(0, gray(b.l * 0.5)); gr.addColorStop(0.5, gray(b.l)); gr.addColorStop(1, gray(Math.min(1, b.l * 1.25)));
      g.fillStyle = gr;
      const Lp = [], Rp = [], S = 16;
      for (let k = 0; k <= S; k++) {
        const t = k / S, u = 1 - t;
        const cx = u * u * x0 + 2 * u * t * px + t * t * x2, cy = u * u * y0 + 2 * u * t * py + t * t * y2;
        let tx = 2 * u * (px - x0) + 2 * t * (x2 - px), ty = 2 * u * (py - y0) + 2 * t * (y2 - py); const tl = Math.hypot(tx, ty) || 1; tx /= tl; ty /= tl;
        const hw = 0.5 * b.w * Math.pow(1 - t, 0.75) * (0.55 + 0.45 * Math.min(1, t * 6));
        Lp.push([cx - ty * hw, cy + tx * hw]); Rp.push([cx + ty * hw, cy - tx * hw]);
      }
      g.beginPath(); g.moveTo(Lp[0][0], Lp[0][1]); for (let k = 1; k <= S; k++) g.lineTo(Lp[k][0], Lp[k][1]); for (let k = S; k >= 0; k--) g.lineTo(Rp[k][0], Rp[k][1]); g.closePath(); g.fill();
    }
    g.restore();
  });
  // 6: flores silvestres
  cell(2, 1, () => {
    const cols = [[246, 246, 238], [250, 214, 70], [186, 108, 204], [236, 84, 84], [108, 148, 236], [255, 154, 56]];
    for (let i = 0; i < 9; i++) {
      const x = 40 + rnd() * 176, h = 90 + rnd() * 130, lean = (rnd() - 0.5) * 50, c = cols[(rnd() * cols.length) | 0];
      g.strokeStyle = 'rgb(70,112,44)'; g.lineWidth = 2.6; g.beginPath(); g.moveTo(x, 254); g.quadraticCurveTo(x + lean * 0.2, 254 - h * 0.6, x + lean, 254 - h); g.stroke();
      g.fillStyle = 'rgb(66,110,42)'; g.beginPath(); g.ellipse(x + 8, 254 - h * 0.35, 12, 4, -0.6, 0, 6.283); g.fill();
      const hx = x + lean, hy = 254 - h, R = 9 + rnd() * 6;
      for (let p = 0; p < 7; p++) { const a = p / 7 * 6.283; g.fillStyle = 'rgb(' + c[0] + ',' + c[1] + ',' + c[2] + ')'; g.beginPath(); g.ellipse(hx + Math.cos(a) * R * 0.75, hy + Math.sin(a) * R * 0.75, R * 0.62, R * 0.36, a, 0, 6.283); g.fill(); }
      g.fillStyle = 'rgb(220,170,40)'; g.beginPath(); g.arc(hx, hy, R * 0.34, 0, 6.283); g.fill();
    }
  });
  // 7: corteza (gris, estrías verticales, sin costuras en horizontal)
  cell(3, 1, () => {
    g.fillStyle = gray(0.55); g.fillRect(0, 0, cs, cs);
    for (let i = 0; i < 260; i++) {
      const x = rnd() * cs, w = 1.5 + rnd() * 5, y0 = rnd() * cs - 30, len = 40 + rnd() * 190, l = 0.28 + 0.55 * rnd(); g.strokeStyle = gray(l); g.globalAlpha = 0.5; g.lineWidth = w;
      for (const ox of [-cs, 0, cs]) { g.beginPath(); g.moveTo(x + ox, y0); g.bezierCurveTo(x + ox + (rnd() - 0.5) * 8, y0 + len * 0.3, x + ox + (rnd() - 0.5) * 8, y0 + len * 0.7, x + ox + (rnd() - 0.5) * 6, y0 + len); g.stroke(); }
    }
    g.globalAlpha = 1;
  });
  // sangrado de color en los bordes transparentes (evita halos oscuros en los mipmaps)
  const img = g.getImageData(0, 0, W, Hh), d = img.data;
  for (let cy = 0; cy < 2; cy++) for (let cx = 0; cx < 4; cx++) {
    let r = 0, gg = 0, b = 0, n = 0;
    for (let y = 0; y < cs; y += 2) for (let x = 0; x < cs; x += 2) { const o = ((cy * cs + y) * W + cx * cs + x) * 4; if (d[o + 3] > 200) { r += d[o]; gg += d[o + 1]; b += d[o + 2]; n++; } }
    if (!n) continue; r = (r / n) | 0; gg = (gg / n) | 0; b = (b / n) | 0;
    for (let y = 0; y < cs; y++) for (let x = 0; x < cs; x++) { const o = ((cy * cs + y) * W + cx * cs + x) * 4; if (d[o + 3] < 24) { d[o] = r; d[o + 1] = gg; d[o + 2] = b; } }
  }
  const tex = new THREE.DataTexture(new Uint8Array(d.buffer), W, Hh, THREE.RGBAFormat, THREE.UnsignedByteType);
  tex.colorSpace = THREE.SRGBColorSpace; tex.wrapS = tex.wrapT = THREE.ClampToEdgeWrapping; tex.magFilter = THREE.LinearFilter; tex.minFilter = THREE.LinearMipmapLinearFilter; tex.generateMipmaps = true; tex.anisotropy = 4; tex.flipY = false; tex.needsUpdate = true;
  // celdas en UV (v crece hacia abajo del lienzo): vt = punta (arriba), vb = base (abajo)
  const C = (c, r) => ({ u0: c * 0.25 + 0.006, u1: (c + 1) * 0.25 - 0.006, vt: r * 0.5 + 0.01, vb: (r + 1) * 0.5 - 0.01 });
  return { tex, broad: C(0, 0), conifer: C(1, 0), palm: C(2, 0), fine: C(3, 0), fern: C(0, 1), grass: C(1, 1), flower: C(2, 1), bark: C(3, 1) };
}

// ---------- constructor de geometría ----------
class DWFGB {
  constructor() { this.p = []; this.n = []; this.uv = []; this.m = []; this.ix = []; }
  vc() { return this.p.length / 3; }
  v(x, y, z, nx, ny, nz, u, vv, sw, ao, mat, fl) { this.p.push(x, y, z); this.n.push(nx, ny, nz); this.uv.push(u, vv); this.m.push(sw, ao, mat, fl); return this.p.length / 3 - 1; }
  // tubo cónico a lo largo de una polilínea (corteza); o.rib/o.ribs dan costillas (cactus)
  tube(pts, rad, sides, c, sw, ao0, ao1, o) {
    o = o || {}; const n = pts.length, base = this.vc(); let pn = null;
    for (let k = 0; k < n; k++) {
      const a = pts[Math.max(0, k - 1)], b = pts[Math.min(n - 1, k + 1)]; let tx = b[0] - a[0], ty = b[1] - a[1], tz = b[2] - a[2]; const tl = Math.hypot(tx, ty, tz) || 1; tx /= tl; ty /= tl; tz /= tl;
      let nx, ny, nz; if (!pn) { if (Math.abs(ty) < 0.9) { nx = -tz; ny = 0; nz = tx; } else { nx = 1; ny = 0; nz = 0; } } else { nx = pn[0]; ny = pn[1]; nz = pn[2]; }
      const d = nx * tx + ny * ty + nz * tz; nx -= tx * d; ny -= ty * d; nz -= tz * d; const nl = Math.hypot(nx, ny, nz) || 1; nx /= nl; ny /= nl; nz /= nl; pn = [nx, ny, nz];
      const bx = ty * nz - tz * ny, by = tz * nx - tx * nz, bz = tx * ny - ty * nx, t = k / (n - 1), ao = ao0 + (ao1 - ao0) * t;
      for (let s = 0; s <= sides; s++) {
        const an = (s / sides) * 6.283185, ca = Math.cos(an), sa = Math.sin(an), dx = nx * ca + bx * sa, dy = ny * ca + by * sa, dz = nz * ca + bz * sa;
        const rr = rad[k] * (o.rib ? 1 + o.rib * Math.cos(an * o.ribs) : 1);
        this.v(pts[k][0] + dx * rr, pts[k][1] + dy * rr, pts[k][2] + dz * rr, dx, dy, dz, c.u0 + (c.u1 - c.u0) * (s / sides), c.vb + (c.vt - c.vb) * t, sw, ao, 0, 0);
      }
    }
    const S = sides + 1;
    for (let k = 0; k < n - 1; k++) for (let s = 0; s < sides; s++) { const a = base + k * S + s, b = a + 1, c2 = a + S, d2 = c2 + 1; this.ix.push(a, c2, b, b, c2, d2); }
  }
  // cuadrilátero con ejes explícitos: u = eje largo (punta), r = eje ancho; o.base ancla en la base
  quad(px, py, pz, ux, uy, uz, rx, ry, rz, w, h, c, o) {
    const hw = w / 2, y0 = o.base ? 0 : -h / 2, y1 = o.base ? h : h / 2;
    let nx, ny, nz; if (o.nrm) { nx = o.nrm[0]; ny = o.nrm[1]; nz = o.nrm[2]; } else { nx = uy * rz - uz * ry; ny = uz * rx - ux * rz; nz = ux * ry - uy * rx; }
    const nl = Math.hypot(nx, ny, nz) || 1; nx /= nl; ny /= nl; nz /= nl;
    const ao = o.ao === undefined ? 1 : o.ao, mat = o.mat === undefined ? 1 : o.mat, fl = o.fl === undefined ? 1 : o.fl, sw = o.sw === undefined ? 1 : o.sw;
    const a = this.v(px - rx * hw + ux * y0, py - ry * hw + uy * y0, pz - rz * hw + uz * y0, nx, ny, nz, c.u0, c.vb, sw, ao, mat, fl);
    const b = this.v(px + rx * hw + ux * y0, py + ry * hw + uy * y0, pz + rz * hw + uz * y0, nx, ny, nz, c.u1, c.vb, sw, ao, mat, fl);
    const d = this.v(px + rx * hw + ux * y1, py + ry * hw + uy * y1, pz + rz * hw + uz * y1, nx, ny, nz, c.u1, c.vt, sw, ao, mat, fl);
    const e = this.v(px - rx * hw + ux * y1, py - ry * hw + uy * y1, pz - rz * hw + uz * y1, nx, ny, nz, c.u0, c.vt, sw, ao, mat, fl);
    this.ix.push(a, b, d, a, d, e);
  }
  // tarjeta orientada hacia n (normal exterior); o.lean mezcla la normal de luz con "arriba"
  card(cx, cy, cz, nx, ny, nz, w, h, c, o) {
    let l = Math.hypot(nx, ny, nz) || 1; nx /= l; ny /= l; nz /= l;
    let rx, ry, rz; if (Math.abs(ny) > 0.97) { rx = 1; ry = 0; rz = 0; } else { rx = nz; ry = 0; rz = -nx; const rl = Math.hypot(rx, rz) || 1; rx /= rl; rz /= rl; }
    let ux = ny * rz - nz * ry, uy = nz * rx - nx * rz, uz = nx * ry - ny * rx;
    const cr = Math.cos(o.roll || 0), sr = Math.sin(o.roll || 0);
    const r2x = rx * cr + ux * sr, r2y = ry * cr + uy * sr, r2z = rz * cr + uz * sr, u2x = -rx * sr + ux * cr, u2y = -ry * sr + uy * cr, u2z = -rz * sr + uz * cr;
    const k = o.lean === undefined ? 0.3 : o.lean; let lx = nx * (1 - k), ly = ny * (1 - k) + k, lz = nz * (1 - k); const ll = Math.hypot(lx, ly, lz) || 1;
    this.quad(cx, cy, cz, u2x, u2y, u2z, r2x, r2y, r2z, w, h, c, Object.assign({}, o, { nrm: [lx / ll, ly / ll, lz / ll] }));
  }
  build() {
    // el balanceo crece con la altura relativa (suelo fijo, puntas libres)
    let maxY = 1e-3; for (let i = 1; i < this.p.length; i += 3) if (this.p[i] > maxY) maxY = this.p[i];
    const m = new Float32Array(this.m); for (let i = 0; i < m.length; i += 4) { const y = this.p[(i / 4) * 3 + 1]; const t = Math.max(0, Math.min(1, y / maxY)); m[i] = m[i] * Math.pow(t, 1.7); }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(this.p), 3)); g.setAttribute('normal', new THREE.BufferAttribute(new Float32Array(this.n), 3));
    g.setAttribute('uv', new THREE.BufferAttribute(new Float32Array(this.uv), 2)); g.setAttribute('aMisc', new THREE.BufferAttribute(m, 4));
    g.setIndex(new THREE.BufferAttribute(this.vc() > 65000 ? new Uint32Array(this.ix) : new Uint16Array(this.ix), 1));
    g.computeBoundingSphere(); return g;
  }
}

// ---------- árboles de hoja ancha (roble, selva, álamo, sauce, acacia, pino torcido) ----------
function dwfBroad(seed, o, lod, A) {
  const r = dwfRng(seed), g = new DWFGB(), bark = A.bark, lf = A[o.leaf || 'broad'];
  const sides = lod ? 4 : 7, th = o.th, r0 = o.r0, ln = o.lean === undefined ? 0.08 : o.lean;
  const lx = (r() - 0.5) * ln, lz = (r() - 0.5) * ln, ns = lod ? 2 : 6, pts = [], rad = [];
  for (let k = 0; k <= ns; k++) { const t = k / ns; pts.push([lx * t * t * 1.5 + Math.sin(t * 5 + seed) * 0.006 * th, th * t, lz * t * t * 1.5]); rad.push(r0 * (1 - 0.5 * t) * (1 + (o.flare === undefined ? 0.6 : o.flare) * Math.pow(1 - t, 6))); }
  g.tube(pts, rad, sides, bark, 0.15, 0.55, 1.0);
  const top = pts[ns], cc = [top[0], th + o.ch * 0.5, top[2]], anchors = [], nl = (o.nl || 4) + (r() < 0.5 ? 1 : 0);
  const eMin = o.elMin === undefined ? 0.35 : o.elMin, eMax = o.elMax === undefined ? 0.95 : o.elMax, curl = o.curl === undefined ? 0.08 : o.curl, droop = o.droop || 0;
  for (let i = 0; i < nl; i++) {
    const a = (i / nl + r() * 0.22) * 6.2832, el = eMin + r() * (eMax - eMin), ce = Math.cos(el), dx = Math.cos(a) * ce, dy = Math.sin(el), dz = Math.sin(a) * ce, len = o.limb * (0.75 + r() * 0.5);
    const st = lod ? 2 : 4, p = [], q = [];
    for (let k = 0; k <= st; k++) { const t = k / st; p.push([top[0] + dx * len * t, top[1] + dy * len * t + curl * t * t * len - droop * t * t * len, top[2] + dz * len * t]); q.push(r0 * 0.55 * (1 - 0.7 * t)); }
    g.tube(p, q, lod ? 3 : 5, bark, 0.3, 0.6, 1.0); anchors.push({ p: p[st], s: 1 });
    if (!lod) {
      const nt = 2 + ((r() * 2) | 0);
      for (let j = 0; j < nt; j++) {
        const bi = Math.max(2, Math.round(st * (0.5 + 0.4 * r()))), bp = p[Math.min(st, bi)], a2 = a + (r() - 0.5) * 2.4, el2 = el + (r() - 0.35) * 0.8, ce2 = Math.cos(el2), tl = len * (0.35 + 0.3 * r());
        const e1 = [bp[0] + Math.cos(a2) * ce2 * tl * 0.5, bp[1] + Math.sin(el2) * tl * 0.5 + 0.015 - droop * tl * 0.2, bp[2] + Math.sin(a2) * ce2 * tl * 0.5];
        const e2 = [bp[0] + Math.cos(a2) * ce2 * tl, bp[1] + Math.sin(el2) * tl + 0.03 - droop * tl * 0.6, bp[2] + Math.sin(a2) * ce2 * tl];
        g.tube([bp, e1, e2], [r0 * 0.2, r0 * 0.14, r0 * 0.08], 4, bark, 0.5, 0.7, 1.0); anchors.push({ p: e2, s: 0.85 });
      }
    }
  }
  const R = [o.cr, o.ch * 0.5 * (o.flat ? 0.55 : 1), o.cr];
  const addCard = (px, py, pz, size) => {
    const nx = px - cc[0], ny = (py - cc[1]) / (o.flat ? 0.6 : 1), nz = pz - cc[2]; const rr = Math.min(1, Math.hypot(nx / R[0], (py - cc[1]) / R[1], nz / R[2]));
    g.card(px, py, pz, nx + (r() - 0.5) * 0.6, ny + (r() - 0.5) * 0.6 + (o.flat ? 0.5 : 0), nz + (r() - 0.5) * 0.6, size, size * (o.cardAsp || 1), lf, { ao: 0.45 + 0.55 * rr, mat: 1, fl: 1, sw: 1, lean: 0.3, roll: (r() - 0.5) * 0.9 });
  };
  const ncard = lod ? 2 : (o.nc || 5), ls = o.ls;
  for (const A2 of anchors) for (let k = 0; k < ncard; k++) addCard(A2.p[0] + (r() - 0.5) * ls * 0.9, A2.p[1] + (r() - 0.5) * ls * 0.7, A2.p[2] + (r() - 0.5) * ls * 0.9, ls * A2.s * (lod ? 1.6 : 1) * (0.85 + 0.3 * r()));
  const nf = lod ? (o.nfL || 8) : (o.nf || 30);
  for (let k = 0; k < nf; k++) {
    const a = r() * 6.2832, e = Math.asin(r() * 2 - 1), rho = 0.55 + 0.45 * r(), ce = Math.cos(e);
    addCard(cc[0] + Math.cos(a) * ce * R[0] * rho, cc[1] + Math.sin(e) * R[1] * rho, cc[2] + Math.sin(a) * ce * R[2] * rho, ls * (lod ? 1.9 : 1.15) * (0.85 + 0.3 * r()));
  }
  return g.build();
}

// ---------- coníferas (abeto, enebro) ----------
function dwfConifer(seed, o, lod, A) {
  const r = dwfRng(seed), g = new DWFGB(), bark = A.bark, lf = A.conifer, sides = lod ? 4 : 6, lean = (r() - 0.5) * (o.lean || 0.04);
  const ns = lod ? 3 : 7, pts = [], rad = [];
  for (let k = 0; k <= ns; k++) { const t = k / ns; pts.push([lean * t * t, t * 0.97, 0]); rad.push(o.r0 * (1 - 0.88 * t) * (1 + 0.8 * Math.pow(1 - t, 8))); }
  g.tube(pts, rad, sides, bark, 0.1, 0.7, 1.0);
  const nW = lod ? (o.nwL || 6) : (o.nw || 13), base = o.base === undefined ? 0.12 : o.base;
  for (let w = 0; w < nW; w++) {
    const t = (w + 0.5) / nW, h = base + (0.985 - base) * t, bl = Math.max(o.bl * Math.pow(1 - t, o.taper || 0.85) + 0.055, 0.06);
    const nb = lod ? (o.nbL || 5) : Math.round((o.nb || 7) * (0.55 + 0.45 * (1 - t)));
    for (let b = 0; b < nb; b++) {
      const a = ((b + (w % 2) * 0.5) / nb + (r() - 0.5) * 0.12) * 6.2832, dr = (o.droop || 0.28) + (r() - 0.5) * 0.12, dx = Math.cos(a), dz = Math.sin(a);
      const al = Math.hypot(dx, dr, dz), ux = dx / al, uy = -dr / al, uz = dz / al, rx = -dz, rz = dx, px = lean * h * h;
      const opt = { base: true, ao: 0.62 + 0.38 * t, mat: 1, fl: 0.6, sw: 1, nrm: [dx * 0.55, 0.72, dz * 0.55] };
      g.quad(px, h, 0, ux, uy, uz, rx, 0, rz, bl * (o.wid || 0.85), bl * al, lf, opt);
      if (!lod) { // segunda tarjeta girada alrededor del eje: rama más tupida
        const c1 = Math.cos(0.95), s1 = Math.sin(0.95); const cx2 = uy * rz, cy2 = uz * rx - ux * rz, cz2 = -uy * rx; // up × right
        g.quad(px, h, 0, ux, uy, uz, rx * c1 + cx2 * s1, cy2 * s1, rz * c1 + cz2 * s1, bl * (o.wid || 0.85) * 0.9, bl * al, lf, opt);
      }
    }
  }
  // punta
  g.quad(lean, 0.93, 0, 0, 1, 0, 1, 0, 0, 0.15, 0.15, lf, { base: true, ao: 1, mat: 1, fl: 0.5, sw: 1, nrm: [0, 1, 0] });
  g.quad(lean, 0.93, 0, 0, 1, 0, 0, 0, 1, 0.15, 0.15, lf, { base: true, ao: 1, mat: 1, fl: 0.5, sw: 1, nrm: [0, 1, 0] });
  return g.build();
}

// ---------- palmeras ----------
function dwfPalm(seed, o, lod, A) {
  const r = dwfRng(seed), g = new DWFGB(), bark = A.bark, fr = A.palm, th = o.th || 0.78;
  const lean = (0.10 + r() * 0.16) * (r() < 0.5 ? -1 : 1), la = r() * 6.28, lx = Math.cos(la) * lean, lz = Math.sin(la) * lean, ns = lod ? 3 : 9, pts = [], rad = [];
  for (let k = 0; k <= ns; k++) { const t = k / ns; pts.push([lx * t * t, th * t, lz * t * t]); rad.push(o.r0 * (1 - 0.35 * t) * (1 + 0.9 * Math.pow(1 - t, 7))); }
  g.tube(pts, rad, lod ? 4 : 7, bark, 0.15, 0.7, 1.0);
  const top = pts[ns], nf = lod ? 8 : 14, segs = lod ? 2 : 3;
  for (let i = 0; i < nf; i++) {
    const a = i * 2.39996 + r() * 0.3, e0 = 1.0 - 0.55 * ((i % 3) / 2) + (r() - 0.5) * 0.2, flen = (o.fl || 0.5) * (0.85 + 0.3 * r()); let px = top[0], py = top[1], pz = top[2];
    const hx = Math.cos(a), hz = Math.sin(a);
    for (let k = 0; k < segs; k++) {
      const e = e0 - k * (0.62 / segs) * 1.5, ce = Math.cos(e), se = Math.sin(e), L = flen / segs; const ux = hx * ce, uy = se, uz = hz * ce;
      const c = { u0: fr.u0, u1: fr.u1, vb: dwfLerp(fr.vb, fr.vt, k / segs), vt: dwfLerp(fr.vb, fr.vt, (k + 1) / segs) };
      g.quad(px, py, pz, ux, uy, uz, -hz, 0, hx, o.fw || 0.2, L * 1.04, c, { base: true, ao: 0.6 + 0.4 * (k / segs), mat: 1, fl: 1, sw: 1, nrm: [hx * 0.35, 0.9, hz * 0.35] });
      px += ux * L; py += uy * L; pz += uz * L;
    }
  }
  return g.build();
}

// ---------- arbustos / helechos / matorral ----------
function dwfShrub(seed, o, lod, A) {
  const r = dwfRng(seed), g = new DWFGB(), lf = A[o.leaf || 'broad'];
  if (o.fern) {
    const n = lod ? 6 : 10;
    for (let i = 0; i < n; i++) {
      const a = (i / n + r() * 0.08) * 6.2832, hx = Math.cos(a), hz = Math.sin(a), segs = lod ? 1 : 2; let px = 0, py = 0.02, pz = 0;
      for (let k = 0; k < segs; k++) {
        const e = 0.95 - k * 0.55 + (r() - 0.5) * 0.2, ce = Math.cos(e), se = Math.sin(e), L = (0.82 + 0.3 * r()) / segs, ux = hx * ce, uy = se, uz = hz * ce;
        const c = { u0: lf.u0, u1: lf.u1, vb: dwfLerp(lf.vb, lf.vt, k / segs), vt: dwfLerp(lf.vb, lf.vt, (k + 1) / segs) };
        g.quad(px, py, pz, ux, uy, uz, -hz, 0, hx, 0.5 * L * segs, L * 1.05, c, { base: true, ao: 0.55 + 0.45 * (k / segs), mat: 1, fl: 1, sw: 1, nrm: [hx * 0.35, 0.9, hz * 0.35] });
        px += ux * L; py += uy * L; pz += uz * L;
      }
    }
    return g.build();
  }
  const n = lod ? (o.nL || 7) : (o.n || 16), R = o.R || 0.5, Hh = o.H || 0.8;
  for (let i = 0; i < n; i++) {
    const a = r() * 6.2832, e = Math.pow(r(), 0.7) * 1.35, ce = Math.cos(e), rr = R * (0.55 + 0.45 * r());
    const px = Math.cos(a) * ce * rr, py = 0.06 + Math.sin(e) * Hh, pz = Math.sin(a) * ce * rr, s = (o.s || 0.5) * (0.8 + 0.4 * r()) * (lod ? 1.45 : 1);
    g.card(px, py, pz, Math.cos(a) * ce, Math.sin(e) + 0.3, Math.sin(a) * ce, s, s, lf, { ao: 0.5 + 0.5 * Math.sin(e + 0.2), mat: 1, fl: 1, sw: 1, lean: 0.4, roll: (r() - 0.5) * 1.0 });
  }
  return g.build();
}

// ---------- cactus gigante (saguaro) ----------
function dwfCactus(seed, o, lod, A) {
  const r = dwfRng(seed), g = new DWFGB(), bark = A.bark, R = o.r0, rings = lod ? 7 : 15, sides = lod ? 8 : 14;
  const col = (x0, z0, y0, y1, rr, ribAmp) => {
    const pts = [], rad = [];
    for (let k = 0; k <= rings; k++) { const t = k / rings; pts.push([x0, y0 + (y1 - y0) * t, z0]); rad.push(rr * (k >= rings - 1 ? 0.22 : k === rings - 2 ? 0.66 : k === rings - 3 ? 0.92 : 1)); }
    g.tube(pts, rad, sides, bark, 0.1, 0.85, 1.0, { rib: ribAmp, ribs: 9 });
  };
  col(0, 0, 0, 1.0, R, 0.1);
  const na = lod ? 1 + ((r() * 2) | 0) : 2 + ((r() * 2) | 0);
  for (let i = 0; i < na; i++) {
    const a = r() * 6.2832 + i * 2.4, y0 = 0.3 + 0.28 * r(), dist = 0.2 + 0.1 * r(), rise = 0.26 + 0.24 * r(), hx = Math.cos(a), hz = Math.sin(a), pts = [], rad = [], st = lod ? 4 : 7;
    for (let k = 0; k <= st; k++) { const t = k / st; const reach = Math.min(1, t * 2.2); pts.push([hx * dist * Math.sin(reach * 1.5708), y0 + rise * Math.pow(t, 2.2), hz * dist * Math.sin(reach * 1.5708)]); rad.push(R * 0.72 * (k >= st - 1 ? 0.3 : 1)); }
    g.tube(pts, rad, lod ? 6 : 10, bark, 0.12, 0.85, 1.0, { rib: 0.1, ribs: 7 });
  }
  return g.build();
}

// ---------- bambú ----------
function dwfBamboo(seed, o, lod, A) {
  const r = dwfRng(seed), g = new DWFGB(), bark = A.bark, lf = A.fine, n = lod ? 5 : 9;
  for (let i = 0; i < n; i++) {
    const a = r() * 6.28, d = 0.12 * r(), x0 = Math.cos(a) * d, z0 = Math.sin(a) * d, h = 0.72 + 0.28 * r(), la = r() * 6.28, bend = 0.1 + 0.16 * r(), st = lod ? 3 : 8, pts = [], rad = [];
    for (let k = 0; k <= st; k++) { const t = k / st; pts.push([x0 + Math.cos(la) * bend * t * t, h * t, z0 + Math.sin(la) * bend * t * t]); rad.push(o.r0 * (1 - 0.45 * t) * (1 + (k % 2 && !lod ? 0.22 : 0))); }
    g.tube(pts, rad, lod ? 4 : 5, bark, 0.4, 0.8, 1.0);
    const nl = lod ? 4 : 12;
    for (let k = 0; k < nl; k++) {
      const t = 0.5 + 0.5 * (k / nl), kk = Math.min(st, Math.round(t * st)), p = pts[kk], aa = r() * 6.28, s = 0.2 * (lod ? 1.5 : 1);
      g.card(p[0] + Math.cos(aa) * 0.04, p[1], p[2] + Math.sin(aa) * 0.04, Math.cos(aa), 0.2, Math.sin(aa), s, s * 1.2, lf, { ao: 0.7 + 0.3 * t, mat: 1, fl: 1, sw: 1, lean: 0.4, roll: (r() - 0.5) });
    }
  }
  return g.build();
}

// ---------- árbol muerto / quemado ----------
function dwfDead(seed, o, lod, A) {
  const r = dwfRng(seed), g = new DWFGB(), bark = A.bark, sides = lod ? 4 : 6;
  const branch = (p0, dir, len, rad0, depth) => {
    const st = lod ? 2 : 4, pts = [], rads = []; let [x, y, z] = p0; const [dx, dy, dz] = dir;
    for (let k = 0; k <= st; k++) { const t = k / st; pts.push([x + dx * len * t + (r() - 0.5) * 0.012 * len, y + dy * len * t, z + dz * len * t + (r() - 0.5) * 0.012 * len]); rads.push(rad0 * (1 - 0.7 * t)); }
    g.tube(pts, rads, depth ? 4 : sides, bark, 0.4, 0.7, 1.0);
    if (depth >= (lod ? 1 : 3)) return;
    const nb = depth === 0 ? 4 + ((r() * 3) | 0) : 2;
    for (let i = 0; i < nb; i++) {
      const t = depth === 0 ? 0.4 + 0.55 * r() : 0.5 + 0.45 * r(), k = Math.min(st, Math.round(t * st)), a = r() * 6.28, el = depth === 0 ? 0.35 + 0.6 * r() : 0.2 + 0.7 * r();
      const ce = Math.cos(el); branch(pts[k], [Math.cos(a) * ce, Math.sin(el), Math.sin(a) * ce], len * (0.55 - 0.1 * depth) * (0.8 + 0.4 * r()), rad0 * (0.5 - 0.08 * depth), depth + 1);
    }
  };
  branch([0, 0, 0], [(r() - 0.5) * 0.12, 1, (r() - 0.5) * 0.12], 0.62 + 0.15 * r(), o.r0, 0);
  return g.build();
}

// ---------- cobertura: hierba, flores, helechos bajos, juncos ----------
function dwfCover(seed, o, lod, A) {
  const r = dwfRng(seed), g = new DWFGB(), lf = A[o.cell || 'grass'], n = o.n || 3;
  for (let c = 0; c < (o.clumps || 1); c++) {
    const ox = (o.clumps > 1 ? (r() - 0.5) * 0.7 : 0), oz = (o.clumps > 1 ? (r() - 0.5) * 0.7 : 0);
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI + r() * 0.35, nx = Math.cos(a + Math.PI / 2), nz = Math.sin(a + Math.PI / 2), ux = 0, uy = 1, uz = 0, rx = Math.cos(a), rz = Math.sin(a), w = (o.w || 1.1) * (0.85 + 0.3 * r());
      g.quad(ox, 0, oz, ux, uy, uz, rx, 0, rz, w, 1, lf, { base: true, ao: 0.65, mat: 3, fl: 1, sw: 1, nrm: [nx * 0.25, 1, nz * 0.25] });
    }
  }
  return g.build();
}

// ---------- rocas: poliedros de aristas redondeadas (blando-mínimo de planos) + ruido ----------
function dwfIco(sub) {
  const t = (1 + Math.sqrt(5)) / 2; const V = [[-1, t, 0], [1, t, 0], [-1, -t, 0], [1, -t, 0], [0, -1, t], [0, 1, t], [0, -1, -t], [0, 1, -t], [t, 0, -1], [t, 0, 1], [-t, 0, -1], [-t, 0, 1]].map(v => { const l = Math.hypot(v[0], v[1], v[2]); return [v[0] / l, v[1] / l, v[2] / l]; });
  let F = [[0, 11, 5], [0, 5, 1], [0, 1, 7], [0, 7, 10], [0, 10, 11], [1, 5, 9], [5, 11, 4], [11, 10, 2], [10, 7, 6], [7, 1, 8], [3, 9, 4], [3, 4, 2], [3, 2, 6], [3, 6, 8], [3, 8, 9], [4, 9, 5], [2, 4, 11], [6, 2, 10], [8, 6, 7], [9, 8, 1]];
  for (let s = 0; s < sub; s++) {
    const cache = new Map(), mid = (a, b) => { const k = a < b ? a * 100000 + b : b * 100000 + a; let m = cache.get(k); if (m === undefined) { const p = [(V[a][0] + V[b][0]) / 2, (V[a][1] + V[b][1]) / 2, (V[a][2] + V[b][2]) / 2], l = Math.hypot(p[0], p[1], p[2]); V.push([p[0] / l, p[1] / l, p[2] / l]); m = V.length - 1; cache.set(k, m); } return m; };
    const NF = []; for (const f of F) { const a = mid(f[0], f[1]), b = mid(f[1], f[2]), c = mid(f[2], f[0]); NF.push([f[0], a, c], [f[1], b, a], [f[2], c, b], [a, b, c]); } F = NF;
  }
  return { V, F };
}
function dwfN3(x, y, z, s) { // ruido de valor suave 3D
  const ix = Math.floor(x), iy = Math.floor(y), iz = Math.floor(z), fx = x - ix, fy = y - iy, fz = z - iz, ux = fx * fx * (3 - 2 * fx), uy = fy * fy * (3 - 2 * fy), uz = fz * fz * (3 - 2 * fz);
  const h = (a, b, c) => dwfHash(ix + a, iy + b + 31 * s, iz + c);
  const x00 = dwfLerp(h(0, 0, 0), h(1, 0, 0), ux), x10 = dwfLerp(h(0, 1, 0), h(1, 1, 0), ux), x01 = dwfLerp(h(0, 0, 1), h(1, 0, 1), ux), x11 = dwfLerp(h(0, 1, 1), h(1, 1, 1), ux);
  return dwfLerp(dwfLerp(x00, x10, uy), dwfLerp(x01, x11, uy), uz) * 2 - 1;
}
function dwfRock(seed, lod, o) {
  o = o || {}; const r = dwfRng(seed), np = 9 + ((r() * 5) | 0), pl = [];
  for (let i = 0; i < np; i++) { let x = r() * 2 - 1, y = r() * 2 - 1, z = r() * 2 - 1; const l = Math.hypot(x, y, z) || 1; pl.push([x / l, y / l, z / l, (o.round || 0.8) + 0.35 * r()]); }
  pl.push([0, -1, 0, 0.42 + 0.1 * r()]);
  const sx = 1 + 0.45 * r(), sy = (o.flat || 0.62) + 0.35 * r(), sz = 1 + 0.45 * r(), P = 7;
  const ico = dwfIco(lod ? 2 : 3), pos = new Float32Array(ico.V.length * 3), nrm = new Float32Array(ico.V.length * 3);
  for (let i = 0; i < ico.V.length; i++) {
    const d = ico.V[i]; let sum = 0;
    for (const p of pl) { const dd = d[0] * p[0] + d[1] * p[1] + d[2] * p[2]; if (dd > 0) sum += Math.pow(dd / p[3], P); }
    let rad = Math.pow(sum, -1 / P); if (!isFinite(rad) || rad > 2) rad = 1;
    rad *= 1 + 0.10 * dwfN3(d[0] * 2.3 + seed, d[1] * 2.3, d[2] * 2.3, 1) + 0.05 * dwfN3(d[0] * 5.9, d[1] * 5.9 + seed, d[2] * 5.9, 2) + (lod ? 0 : 0.025 * dwfN3(d[0] * 13, d[1] * 13, d[2] * 13 + seed, 3));
    pos[i * 3] = d[0] * rad * sx; pos[i * 3 + 1] = d[1] * rad * sy; pos[i * 3 + 2] = d[2] * rad * sz;
  }
  for (const f of ico.F) {
    const a = f[0] * 3, b = f[1] * 3, c = f[2] * 3; const ux = pos[b] - pos[a], uy = pos[b + 1] - pos[a + 1], uz = pos[b + 2] - pos[a + 2], vx = pos[c] - pos[a], vy = pos[c + 1] - pos[a + 1], vz = pos[c + 2] - pos[a + 2];
    const nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx; for (const k of [a, b, c]) { nrm[k] += nx; nrm[k + 1] += ny; nrm[k + 2] += nz; }
  }
  for (let i = 0; i < nrm.length; i += 3) { const l = Math.hypot(nrm[i], nrm[i + 1], nrm[i + 2]) || 1; nrm[i] /= l; nrm[i + 1] /= l; nrm[i + 2] /= l; }
  const idx = []; for (const f of ico.F) idx.push(f[0], f[1], f[2]);
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('normal', new THREE.BufferAttribute(nrm, 3));
  g.setIndex(new THREE.BufferAttribute(new Uint16Array(idx), 1)); g.computeBoundingSphere(); return g;
}

// ================================================================
// MUNDO DE DRAGONES — flora: tabla de especies y sombreadores
// hab = afinidad por hábitat [base, celestial, glaciar, cañón, jade, cascadas, mesas, caldera]
// dens = densidad máxima de candidatos (por m²) · sc = fracción dispersa fuera del bosque
// H = altura final en metros · hGeo = altura de la geometría unitaria
// ================================================================
const DWF_SP = [
  // ---- árboles ----
  { id: 'oak', kind: 'tree', b: 'broad', nv: 3, hGeo: 1.08, H: [12, 20], wK: 1, o: { th: 0.30, r0: 0.030, ch: 0.78, cr: 0.60, limb: 0.46, ls: 0.15, nl: 4, nc: 5, nf: 46, nfL: 12, lean: 0.05 },
    hab: [0.9, 0.12, 0, 0.1, 0.1, 0.5, 0, 0], dens: 1 / 70, sc: 0.07, zMax: 1500, slope: 0.42, colA: [0.8, 0.56, 0.7], colB: [1.0, 0.64, 0.58], bark: [0.17, 0.13, 0.10], amp: 0.032, flut: 0.012 },
  { id: 'poplar', kind: 'tree', b: 'broad', nv: 2, hGeo: 1.18, H: [15, 25], wK: 1, o: { th: 0.28, r0: 0.022, ch: 0.9, cr: 0.27, limb: 0.2, ls: 0.115, nl: 5, nc: 5, nf: 40, nfL: 10, elMin: 0.7, elMax: 1.3, lean: 0.03 },
    hab: [0.45, 0, 0, 0.5, 0.05, 0.25, 0, 0], dens: 1 / 90, sc: 0.04, wet: 0.5, zMax: 1500, slope: 0.35, colA: [0.98, 0.72, 0.6], colB: [1.3, 0.85, 0.5], bark: [0.30, 0.27, 0.22], amp: 0.045, flut: 0.016 },
  { id: 'jungle', kind: 'tree', b: 'broad', nv: 3, hGeo: 1.05, H: [20, 36], wK: 1, o: { th: 0.50, r0: 0.026, ch: 0.55, cr: 0.50, limb: 0.34, ls: 0.13, nl: 5, nc: 5, nf: 52, nfL: 14, flat: 1, flare: 1.6, lean: 0.06 },
    hab: [0, 0, 0, 0, 1.0, 0.6, 0, 0], dens: 1 / 60, sc: 0.12, zMax: 1000, slope: 0.4, colA: [0.62, 0.62, 0.6], colB: [0.85, 0.72, 0.6], bark: [0.15, 0.12, 0.09], amp: 0.026, flut: 0.011 },
  { id: 'acacia', kind: 'tree', b: 'broad', nv: 2, hGeo: 0.78, H: [5, 9], wK: 1, o: { th: 0.50, r0: 0.022, ch: 0.28, cr: 0.80, limb: 0.55, ls: 0.14, nl: 4, nc: 6, nf: 34, nfL: 10, flat: 1, leaf: 'fine', elMin: 0.2, elMax: 0.5, lean: 0.25 },
    hab: [0.04, 0, 0, 0.25, 0, 0, 0.7, 0], dens: 1 / 260, sc: 0.35, bare: 0.5, zMax: 1200, slope: 0.3, colA: [0.95, 0.66, 0.5], colB: [1.2, 0.78, 0.45], bark: [0.14, 0.11, 0.085], amp: 0.03, flut: 0.012 },
  { id: 'willow', kind: 'tree', b: 'broad', nv: 2, hGeo: 1.0, H: [8, 14], wK: 1, o: { th: 0.30, r0: 0.032, ch: 0.7, cr: 0.55, limb: 0.5, ls: 0.12, nl: 5, nc: 6, nf: 44, nfL: 12, leaf: 'fine', droop: 0.55, elMin: 0.5, elMax: 1.0, curl: 0.25, lean: 0.1 },
    hab: [0.3, 0, 0, 0.25, 0.3, 0.5, 0.05, 0], dens: 1 / 110, sc: 0.0, wet: 1.0, zMax: 900, slope: 0.25, colA: [0.9, 0.7, 0.6], colB: [1.05, 0.76, 0.5], bark: [0.16, 0.13, 0.1], amp: 0.05, flut: 0.02 },
  // ---- coníferas ----
  { id: 'spruce', kind: 'tree', b: 'conifer', nv: 3, hGeo: 1.0, H: [18, 34], wK: 1, o: { r0: 0.013, bl: 0.15, nw: 16, nb: 9, droop: 0.30, taper: 0.9, base: 0.07, wid: 1.05, nwL: 7, nbL: 6, lean: 0.03 },
    hab: [0.3, 1.0, 0.8, 0.08, 0, 0.5, 0, 0], dens: 1 / 42, sc: 0.06, zMax: 2800, slope: 0.5, colA: [0.46, 0.36, 1.9], colB: [0.6, 0.46, 2.1], bark: [0.12, 0.09, 0.07], amp: 0.020, flut: 0.007 },
  { id: 'pine', kind: 'tree', b: 'conifer', nv: 3, hGeo: 1.0, H: [14, 26], wK: 1, o: { r0: 0.012, bl: 0.15, nw: 9, nb: 6, droop: 0.2, taper: 0.5, base: 0.42, wid: 0.9, nwL: 5, nbL: 4, lean: 0.12 },
    hab: [0.25, 0.3, 0.18, 0.5, 0, 0.12, 0.08, 0], dens: 1 / 85, sc: 0.07, zMax: 2400, slope: 0.5, colA: [0.62, 0.5, 1.4], colB: [0.78, 0.6, 1.5], bark: [0.20, 0.12, 0.08], amp: 0.026, flut: 0.009 },
  { id: 'juniper', kind: 'tree', b: 'broad', nv: 3, hGeo: 1.0, H: [3.5, 7.5], wK: 1, o: { leaf: 'conifer', th: 0.22, r0: 0.05, ch: 0.78, cr: 0.5, limb: 0.36, ls: 0.26, nl: 4, nc: 4, nf: 30, nfL: 10, lean: 0.14, flat: 0, elMin: 0.5, elMax: 1.1 },
    hab: [0.12, 0.08, 0.04, 0.8, 0, 0, 0.5, 0.02], dens: 1 / 160, sc: 0.5, bare: 0.45, zMax: 2200, slope: 0.5, colA: [0.5, 0.44, 1.6], colB: [0.62, 0.5, 1.7], bark: [0.18, 0.12, 0.09], amp: 0.02, flut: 0.008 },
  { id: 'palm', kind: 'tree', b: 'palm', nv: 2, hGeo: 1.1, H: [8, 15], wK: 1, o: { th: 0.78, r0: 0.02, fl: 0.5, fw: 0.2 },
    hab: [0, 0, 0, 0, 0.5, 0.3, 0.03, 0], dens: 1 / 150, sc: 0.12, wet: 0.35, zMax: 400, slope: 0.3, colA: [0.85, 0.66, 0.6], colB: [1.05, 0.78, 0.5], bark: [0.28, 0.22, 0.15], amp: 0.06, flut: 0.02 },
  { id: 'bamboo', kind: 'tree', b: 'bamboo', nv: 2, hGeo: 1.0, H: [7, 12], wK: 1, o: { r0: 0.011 },
    hab: [0, 0, 0, 0, 0.75, 0.5, 0, 0], dens: 1 / 120, sc: 0.05, zMax: 800, slope: 0.35, colA: [0.7, 0.68, 0.6], colB: [0.95, 0.8, 0.5], bark: [0.30, 0.34, 0.15], amp: 0.07, flut: 0.02 },
  { id: 'dead', kind: 'tree', b: 'dead', nv: 3, hGeo: 1.0, H: [4, 11], wK: 1, o: { r0: 0.03 },
    hab: [0.02, 0.05, 0.25, 0.1, 0, 0, 0.12, 0.7], dens: 1 / 190, sc: 0.8, bare: 0.22, zMax: 2900, slope: 0.55, colA: [1, 1, 1], colB: [1, 1, 1], bark: [0.13, 0.115, 0.105], amp: 0.004, flut: 0 },
  { id: 'cactus', kind: 'tree', b: 'cactus', nv: 2, hGeo: 1.0, H: [3.5, 8], wK: 1, o: { r0: 0.075 },
    hab: [0, 0, 0, 0.3, 0, 0, 0.6, 0], dens: 1 / 520, sc: 1.0, bare: 0.6, zMax: 1400, slope: 0.28, colA: [1, 1, 1], colB: [1, 1, 1], bark: [0.10, 0.20, 0.08], amp: 0.0, flut: 0 },
  // ---- arbustos y sotobosque ----
  { id: 'bush', kind: 'shrub', b: 'shrub', nv: 2, hGeo: 0.9, H: [1.0, 2.4], wK: 1, o: { leaf: 'broad', n: 16, nL: 7, R: 0.5, H: 0.8, s: 0.5 },
    hab: [0.7, 0.3, 0.1, 0.3, 0.8, 0.7, 0.05, 0], dens: 1 / 26, sc: 0.12, zMax: 1900, slope: 0.5, colA: [0.88, 0.66, 0.6], colB: [1.05, 0.76, 0.5], bark: [0.15, 0.11, 0.08], amp: 0.05, flut: 0.03 },
  { id: 'sage', kind: 'shrub', b: 'shrub', nv: 2, hGeo: 0.56, H: [0.5, 1.2], wK: 1, o: { leaf: 'broad', n: 22, nL: 8, R: 0.55, H: 0.5, s: 0.3 },
    hab: [0.12, 0, 0, 0.9, 0, 0, 0.8, 0.05], dens: 1 / 9, sc: 0.35, bare: 0.7, zMax: 1900, slope: 0.5, colA: [0.62, 0.6, 0.62], colB: [0.8, 0.72, 0.66], bark: [0.15, 0.12, 0.09], amp: 0.04, flut: 0.02 },
  { id: 'heath', kind: 'shrub', b: 'shrub', nv: 2, hGeo: 0.45, H: [0.35, 0.8], wK: 1, o: { leaf: 'broad', n: 16, nL: 6, R: 0.5, H: 0.35, s: 0.26 },
    hab: [0.2, 0.65, 0.75, 0.08, 0, 0.1, 0, 0.1], dens: 1 / 7, sc: 0.5, bare: 0.3, zMax: 2900, slope: 0.6, colA: [0.62, 0.62, 0.4], colB: [0.78, 0.68, 0.42], bark: [0.15, 0.11, 0.08], amp: 0.03, flut: 0.02 },
  { id: 'fern', kind: 'shrub', b: 'shrub', nv: 2, hGeo: 0.75, H: [0.7, 1.4], wK: 1, o: { fern: true, leaf: 'fern' },
    hab: [0.12, 0, 0, 0, 1.0, 1.0, 0, 0], dens: 1 / 5, sc: 0.25, zMax: 1200, slope: 0.5, colA: [0.7, 0.68, 0.6], colB: [0.92, 0.8, 0.55], bark: [0.15, 0.11, 0.08], amp: 0.07, flut: 0.03, shade: 1 },
  // ---- cobertura baja ----
  { id: 'grass', kind: 'cover', b: 'cover', nv: 2, hGeo: 1, H: [0.22, 0.42], wK: 1, o: { cell: 'grass', n: 3, w: 2.2, clumps: 2 }, pal: 1,
    hab: [1, 0.75, 0.3, 0.3, 1, 1, 0.22, 0.05], dens: 1 / 0.7, sc: 1, amp: 0.20, flut: 0.0 },
  { id: 'tallgrass', kind: 'cover', b: 'cover', nv: 2, hGeo: 1, H: [0.7, 1.15], wK: 1, o: { cell: 'grass', n: 3, w: 1.5, clumps: 2 }, pal: 1, tall: 1,
    hab: [0.7, 0.2, 0, 0.15, 0.6, 0.8, 0.06, 0], dens: 1 / 4.5, sc: 1, amp: 0.22, flut: 0.0 },
  { id: 'drygrass', kind: 'cover', b: 'cover', nv: 2, hGeo: 1, H: [0.28, 0.5], wK: 1, o: { cell: 'grass', n: 3, w: 2.0, clumps: 2 }, pal: 1, dry: 1,
    hab: [0, 0, 0.1, 0.8, 0, 0, 0.7, 0.12], dens: 1 / 2.2, sc: 1, bare: 0.5, amp: 0.2, flut: 0.0 },
  { id: 'flowers', kind: 'cover', b: 'cover', nv: 2, hGeo: 1, H: [0.35, 0.65], wK: 1, o: { cell: 'flower', n: 3, w: 0.9, clumps: 1 }, pal: 2, patch: 1,
    hab: [0.85, 0.7, 0.08, 0.12, 0.35, 0.55, 0.06, 0], dens: 1 / 3.5, sc: 1, amp: 0.2, flut: 0.0 },
  { id: 'reeds', kind: 'cover', b: 'cover', nv: 2, hGeo: 1, H: [1.2, 2.0], wK: 1, o: { cell: 'grass', n: 3, w: 1.2, clumps: 2 }, pal: 1, reed: 1,
    hab: [0.8, 0.2, 0.3, 0.4, 0.9, 1, 0.3, 0], dens: 1 / 1.6, sc: 0, amp: 0.12, flut: 0.0 }
];
const DWF_ROCKS = [
  { id: 'rockL', kind: 'rock', nv: 4, H: [1.3, 5.5], dens: 1 / 520, R: 1.0, hab: [0.4, 1, 0.9, 1, 0.45, 0.6, 1, 1] },
  { id: 'rockS', kind: 'rock', nv: 4, H: [0.22, 0.95], dens: 1 / 15, R: 0.5, hab: [0.45, 1, 0.9, 1, 0.5, 0.65, 1, 1], small: 1 }
];

// ---------- sombreadores ----------
function dwfShaders(DW) {
  const VS = /* glsl */`
attribute vec3 iPos; attribute vec4 iA, iB; attribute vec4 aMisc;
uniform float uTime; uniform vec2 uWind; uniform vec4 uPar; uniform int uPal;
uniform vec3 uGrassA[8], uGrassB[8];
varying vec3 vW, vN; varying vec4 vM, vI; varying vec2 vUv; varying vec3 vPal;
void main(){
  float sc = iA.y, cy = cos(iA.x), sy = sin(iA.x);
  float dcam = distance(iPos.xz, cameraPosition.xz);
  if (uPar.w > 0.0) sc *= 1.0 - smoothstep(uPar.w * 0.72, uPar.w, dcam);
  vec3 lp = position; lp.xz *= uPar.z; lp *= sc;
  vec3 rp = vec3(cy * lp.x + sy * lp.z, lp.y, -sy * lp.x + cy * lp.z);
  vec3 w = iPos + rp;
  vec2 wd = normalize(uWind + vec2(1e-4));
  float ph = dot(iPos.xz, wd) * 0.05 + uTime * 1.3 + iA.z * 6.2832;
  float gust = sin(ph) + 0.55 * sin(ph * 2.31 + 1.7) + 0.45 * sin(uTime * 0.41 + dot(iPos.xz, vec2(0.013, -0.019))) + 0.35;
  float sw = aMisc.x;
  w.xz += wd * gust * uPar.x * sw * sc;
  w.y -= max(gust, 0.0) * uPar.x * sw * sc * 0.18;
  float fl = uPar.y * sw * sc * step(0.5, aMisc.z);
  w += vec3(sin(ph * 6.1 + position.x * 23.0), sin(ph * 5.3 + position.y * 19.0) * 0.5, cos(ph * 6.7 + position.z * 21.0)) * fl;
  vW = w;
  vN = vec3(cy * normal.x + sy * normal.z, normal.y, -sy * normal.x + cy * normal.z);
  vM = aMisc; vI = iB; vUv = uv;
  vec3 pc = vec3(1.0);
  if (uPal == 1) { int i1 = int(iB.x + 0.5), i2 = int(iB.y + 0.5); vec3 gA = mix(uGrassA[i1], uGrassA[i2], iB.z), gB = mix(uGrassB[i1], uGrassB[i2], iB.z); pc = mix(gA, gB, clamp(iA.w * 0.55, 0.0, 1.0)); }
  vPal = pc;
  gl_Position = projectionMatrix * viewMatrix * vec4(w, 1.0);
}`;
  const FS = /* glsl */`
uniform sampler2D tAtlas; uniform vec4 uFade; uniform vec3 uBark, uColA, uColB; uniform int uPal; uniform vec4 uTone;
varying vec3 vW, vN; varying vec4 vM, vI; varying vec2 vUv; varying vec3 vPal;
${DW.GLSL_ATM}
${DW.GLSL_CAPS}
float ign(vec2 p){ return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715)))); }
void main(){
  vec3 toC = cameraPosition - vW; float dist = length(toC); vec3 V = toC / dist;
  float vis = (1.0 - smoothstep(uFade.z, uFade.w, dist)) * smoothstep(uFade.x, uFade.y, dist);
  if (vis < 0.999 && vis < ign(gl_FragCoord.xy)) discard;
  vec4 tx = texture2D(tAtlas, vUv);
  float leaf = step(0.5, vM.z);
  float cut = (0.44 - clamp(dist * 0.0007, 0.0, 0.2)) * (1.0 - 0.5 * uTone.z); if (leaf > 0.5 && tx.a < cut) discard;
  vec3 base;
  if (leaf < 0.5) { float lum = mix(1.0, tx.r / 0.26, 0.55); base = uBark * lum * vec3(0.78, 0.74, 0.66); }
  else if (uPal == 1) { base = vPal * (0.5 + tx.r * 2.2); }
  else { base = tx.rgb * mix(uColA, uColB, 0.5 + 0.5 * sin(dot(vW.xz, vec2(0.071, 0.053)))); }
  if (leaf > 0.5) { float lum = dot(base, vec3(0.3, 0.59, 0.11)); base = mix(vec3(lum), base, 0.78) * 0.9; }
  vec3 N = normalize(vN); if (!gl_FrontFacing) N = -N;
  float sn = vI.w * smoothstep(0.05, 0.8, N.y) * (leaf > 0.5 ? 0.9 : 0.55);
  base = mix(base, vec3(0.8, 0.84, 0.9), sn);
  vec3 L = uSunDir;
  float ndl = dot(N, L);
  float lit = leaf > 0.5 ? clamp(ndl * 0.55 + 0.45, 0.0, 1.0) : max(ndl, 0.0);
  float ao = mix(0.3, 1.0, smoothstep(0.1, 0.85, vM.y));
  float self = mix(0.42, 1.0, smoothstep(0.3, 0.8, vM.y));
  float sunVis = dragonShadow(vW, L) * self;
  vec3 amb = mix(uGndAmb, uSkyAmb, 0.5 + 0.5 * N.y) * ao;
  vec3 moon = uMoonCol * max(dot(N, uMoonDir), 0.0) * 2.0;
  float back = leaf > 0.5 ? max(-ndl, 0.0) * (0.35 + 0.65 * pow(max(dot(-V, L), 0.0), 2.0)) : 0.0;
  vec3 col = base * (uSunCol * lit * sunVis + amb + moon) + base * vec3(0.95, 1.0, 0.45) * uSunCol * back * 0.55 * sunVis * uTone.x;
  col *= uTone.y;
  col = aerial(col, vW);
  gl_FragColor = vec4(col, 1.0);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}`;
  const RVS = /* glsl */`
attribute vec3 iPos; attribute vec4 iA, iB;
uniform vec3 uRockA[8], uRockB[8], uRockC[8]; uniform vec4 uP3[8];
varying vec3 vW, vN, vLp, vRA, vRB, vRC; varying vec4 vI, vP3; varying float vTint, vYn;
void main(){
  float cy = cos(iA.x), sy = sin(iA.x); vec3 lp = position * iA.y;
  vec3 rp = vec3(cy * lp.x + sy * lp.z, lp.y, -sy * lp.x + cy * lp.z);
  vec3 w = iPos + rp; vW = w;
  vN = vec3(cy * normal.x + sy * normal.z, normal.y, -sy * normal.x + cy * normal.z);
  vLp = lp + vec3(iA.z * 13.7, iA.z * 7.3, iA.z * 3.1); vI = iB; vTint = iA.w; vYn = position.y;
  int i1 = int(iB.x + 0.5), i2 = int(iB.y + 0.5);
  vRA = mix(uRockA[i1], uRockA[i2], iB.z); vRB = mix(uRockB[i1], uRockB[i2], iB.z); vRC = mix(uRockC[i1], uRockC[i2], iB.z); vP3 = mix(uP3[i1], uP3[i2], iB.z);
  gl_Position = projectionMatrix * viewMatrix * vec4(w, 1.0);
}`;
  const RFS = /* glsl */`
uniform sampler2D tDetail; uniform vec4 uFade;
varying vec3 vW, vN, vLp, vRA, vRB, vRC; varying vec4 vI, vP3; varying float vTint, vYn;
${DW.GLSL_ATM}
${DW.GLSL_CAPS}
float ign(vec2 p){ return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715)))); }
void main(){
  vec3 toC = cameraPosition - vW; float dist = length(toC); vec3 V = toC / dist;
  float vis = (1.0 - smoothstep(uFade.z, uFade.w, dist)) * smoothstep(uFade.x, uFade.y, dist);
  if (vis < 0.999 && vis < ign(gl_FragCoord.xy)) discard;
  vec3 N0 = normalize(vN);
  vec3 wg = pow(abs(N0), vec3(4.0)); wg /= (wg.x + wg.y + wg.z);
  vec3 q = vLp;
  vec4 fx = texture2D(tDetail, q.zy * 0.34), fy = texture2D(tDetail, q.xz * 0.34), fz = texture2D(tDetail, q.xy * 0.34);
  vec4 cx = texture2D(tDetail, q.zy * 0.085), cy = texture2D(tDetail, q.xz * 0.085), cz = texture2D(tDetail, q.xy * 0.085);
  float fad = 1.0 - smoothstep(30.0, 160.0, dist);
  vec2 gx = (fx.xy * 2.0 - 1.0) * fad + (cx.xy * 2.0 - 1.0) * 0.8, gy = (fy.xy * 2.0 - 1.0) * fad + (cy.xy * 2.0 - 1.0) * 0.8, gz = (fz.xy * 2.0 - 1.0) * fad + (cz.xy * 2.0 - 1.0) * 0.8;
  vec3 dn = vec3(0.0, gx.y, gx.x) * wg.x + vec3(gy.x, 0.0, gy.y) * wg.y + vec3(gz.x, gz.y, 0.0) * wg.z;
  vec3 N = normalize(N0 + dn * 0.75);
  float hF = fx.b * wg.x + fy.b * wg.y + fz.b * wg.z, hC = cx.b * wg.x + cy.b * wg.y + cz.b * wg.z;
  float cav = (fx.a * wg.x + fy.a * wg.y + fz.a * wg.z) * 0.5 + (cx.a * wg.x + cy.a * wg.y + cz.a * wg.z) * 0.5;
  float mott = clamp(0.5 + (hC - 0.5) * 0.9 + (hF - 0.5) * 0.4 + (vTint - 0.5) * 0.6, 0.0, 1.0);
  vec3 rock = mix(vRA, vRB, mott) * (0.62 + 0.7 * mix(hC, hF, fad)) * mix(1.0, cav, 0.4);
  float up = smoothstep(0.35, 0.9, N0.y);
  float lich = smoothstep(0.45, 0.8, hC * 0.6 + cy.b * 0.5 + (vTint - 0.5) * 0.4) * vP3.x * up;
  rock = mix(rock, vRC * (0.7 + 0.6 * cx.b), lich * 0.75);
  float sn = smoothstep(0.35, 0.65, vI.w + (hF - 0.5) * 0.3) * smoothstep(0.4, 0.82, N0.y);
  rock = mix(rock, vec3(0.88, 0.91, 0.95), sn * 0.95);
  vec3 L = uSunDir; float nlR = dot(N, L); float nl = max(nlR, 0.0);
  float sunVis = smoothstep(-0.03, 0.2, dot(N0, L)) * dragonShadow(vW, L);
  float ao = mix(0.45, 1.0, smoothstep(-0.55, 0.05, vYn)) * mix(0.8, 1.0, cav);
  vec3 amb = mix(uGndAmb, uSkyAmb, 0.5 + 0.5 * N.y) * ao;
  vec3 moon = uMoonCol * max(dot(N, uMoonDir), 0.0) * 2.0;
  vec3 col = rock * (uSunCol * nl * sunVis + amb + moon);
  vec3 Hh = normalize(L + V); col += uSunCol * pow(max(dot(N, Hh), 0.0), 40.0) * (0.02 + 0.3 * sn) * sunVis;
  col = aerial(col, vW);
  gl_FragColor = vec4(col, 1.0);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}`;
  return { VS, FS, RVS, RFS };
}

// ================================================================
// MUNDO DE DRAGONES — flora: gestor (celdas, instancias, LOD, viento)
//  · celdas grandes (128 m): árboles y bloques → L0 detallado / L1 simple
//  · celdas pequeñas (16 m): arbustos, hierba, flores, helechos, piedras
// ================================================================
const DWF_BIG = 128, DWF_SMALL = 16;
const dwfSS = (a, b, x) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
function DWF_REGISTER(DW) {
  DW.mods.push({ name: 'flora', create(eng, W) {
    try { if (typeof EDEN !== 'undefined' && EDEN.dragonFlora && !EDEN.dragonFlora.enabled) return null; } catch (_) {}
    const f = new DWFlora(eng, W); return f.dead ? null : f;
  } });
}

class DWFlora {
  constructor(eng, W) {
    this.eng = eng; this.W = W; this.DW = eng.DW; this.H = eng.H; this.T = eng.terrain; this.dead = false; this.fast = false; this.t = 0;
    const ti = eng.ti === undefined ? 2 : eng.ti; this.ti = ti; this.qf = eng.q.flora; this.dm = [0.45, 0.7, 1, 1.2][ti];
    this.R0 = [70, 100, 140, 180][ti]; this.R1 = [300, 420, 580, 760][ti]; this.RG = [42, 65, 90, 115][ti];
    this.group = new THREE.Group(); this.group.name = 'dw-flora'; eng.scene.add(this.group);
    this.cellsB = new Map(); this.cellsS = new Map(); this.queue = []; this.geoQ = []; this.geoSet = new Set(); this.geos = new Map(); this.mats = new Map(); this.batches = new Map(); this.act = [];
    this.so = { w: new Float32Array(8) }; this.last = { x: 1e9, z: 1e9, fx: 0, fy: 0, fz: 0, fov: 0 }; this.dirty = true; this.tAsm = -9; this.tNeed = -9; this.kb = ''; this.tl = -1; this.nowNeed = 0;
    this.fr = new THREE.Frustum(); this.pm = new THREE.Matrix4(); this.mi = new THREE.Matrix4(); this.pc = new THREE.PerspectiveCamera(); this.sph = new THREE.Sphere(); this.dir = new THREE.Vector3();
    try { this.A = dwfAtlas(); this.S = dwfShaders(this.DW); } catch (e) { eLog('warn', 'dragonWorld', e); this.dead = true; return; }
    this.SP = DWF_SP.concat(DWF_ROCKS); this.nSP = this.SP.length;
    const RK = { juniper: 0.6, acacia: 0.8, dead: 0.7, cactus: 0.6, palm: 0.85, bamboo: 0.85, willow: 0.85, rockL: 0.85 };
    const RS = { grass: 1, tallgrass: 0.9, drygrass: 1, flowers: 0.8, reeds: 1.1, bush: 1.5, sage: 0.9, heath: 0.8, fern: 0.8, rockS: 1.3 };
    this.rMax = []; this.bigIdx = []; this.smallIdx = [];
    this.SP.forEach((s, i) => {
      const big = s.kind === 'tree' || s.id === 'rockL'; s.big = big; s.i = i;
      if (big) { this.rMax[i] = this.R1 * (RK[s.id] || 1); this.bigIdx.push(i); } else { this.rMax[i] = this.RG * (RS[s.id] || 1); this.smallIdx.push(i); }
    });
    this.tOnTile = eng.terrain.onTile; const self = this;
    eng.terrain.onTile = function (t) { if (self.tOnTile) { try { self.tOnTile(t); } catch (_) {} } self.nowNeed = 1; };
  }
  enter() { this.dirty = true; }
  // genera de antemano todas las celdas y geometrías cercanas (sin dibujar) para que no aparezcan de golpe
  async warm(cam, W, maxMs) {
    if (this.dead) return; const t0 = performance.now(), camera = W && W.ctx && W.ctx.camera; this.need(cam); this.kb = ''; let t1 = performance.now();
    const slice = () => new Promise(r => setTimeout(r, 0));
    while (this.queue.length && performance.now() - t0 < maxMs) { this.gen(this.queue.shift()); if (performance.now() - t1 > 14) { await slice(); t1 = performance.now(); } }
    if (camera) {
      this.noCull = true; try { this.assemble(cam, camera); } catch (e) { eLog('warn', 'dragonWorld', e); } this.noCull = false;
      while (this.geoQ.length && performance.now() - t0 < maxMs) { this.doGeo(this.geoQ.shift()); if (performance.now() - t1 > 14) { await slice(); t1 = performance.now(); } }
    }
    this.dirty = true; this.last.x = 1e9; this.tNeed = -9;
  }
  pending() {
    if (this.dead) return false; if (this.geoQ.length || this.dirty) return true;
    const lim = this.R0 * 1.4 + 130; for (const q of this.queue) if (q.d < lim) return true; return false;
  }
  // ---------- geometría y materiales (perezosos) ----------
  geoReady(i, v, lod) { return this.geos.has(i + ':' + v + ':' + lod); }
  buildGeo(i, v, lod) {
    const s = this.SP[i], seed = 4001 + i * 977 + v * 131;
    if (s.kind === 'rock') return dwfRock(seed, lod, { flat: s.small ? 0.7 : 0.62, round: 0.8 });
    const f = { broad: dwfBroad, conifer: dwfConifer, palm: dwfPalm, shrub: dwfShrub, cactus: dwfCactus, bamboo: dwfBamboo, dead: dwfDead, cover: dwfCover }[s.b];
    return f(seed, s.o, lod, this.A);
  }
  doGeo(j) { const key = j.i + ':' + j.v + ':' + j.lod; this.geoSet.delete(key); if (this.geos.has(key)) return; try { this.geos.set(key, this.buildGeo(j.i, j.v, j.lod)); } catch (e) { eLog('warn', 'dragonWorld', e); this.geos.set(key, null); } }
  mat(i, lod) {
    const key = i + ':' + lod; let m = this.mats.get(key); if (m) return m;
    const s = this.SP[i], DW = this.DW, TU = DW.terrUniforms || {}, rock = s.kind === 'rock', R0 = this.R0, band = R0 * 0.2, rM = this.rMax[i];
    const fade = s.big ? (lod === 0 ? [-1, 0, R0 - band, R0 + band] : [R0 - band, R0 + band, rM - band * 2.5, rM + 12]) : [-1, 0, 1e9, 2e9];
    const col = (a) => new THREE.Color().setRGB(a[0], a[1], a[2]);
    let u;
    if (rock) u = Object.assign({}, DW.U, { uFade: { value: new THREE.Vector4(...fade) }, uRockA: TU.uRockA, uRockB: TU.uRockB, uRockC: TU.uRockC, uP3: TU.uP3 });
    else u = Object.assign({}, DW.U, { tAtlas: { value: this.A.tex }, uFade: { value: new THREE.Vector4(...fade) }, uBark: { value: col(s.bark || [0.15, 0.12, 0.09]) }, uColA: { value: col(s.colA || [1, 1, 1]) }, uColB: { value: col(s.colB || [1, 1, 1]) },
      uPar: { value: new THREE.Vector4(s.amp || 0, s.flut || 0, s.wK || 1, s.big ? 0 : this.rMax[i]) }, uPal: { value: s.pal || 0 }, uTone: { value: new THREE.Vector4(s.kind === 'cover' ? 0.5 : 1, 1, s.kind === 'cover' ? 1 : 0, 0) }, uGrassA: TU.uGrassA, uGrassB: TU.uGrassB });
    m = new THREE.ShaderMaterial({ uniforms: u, vertexShader: rock ? this.S.RVS : this.S.VS, fragmentShader: rock ? this.S.RFS : this.S.FS, side: THREE.DoubleSide, fog: false });
    this.mats.set(key, m); return m;
  }
  batch(i, v, lod) {
    const key = i + ':' + v + ':' + lod; let b = this.batches.get(key); if (b) return b;
    const gk = i + ':' + v + ':' + lod; const base = this.geos.get(gk); if (!base) return null;
    b = { key, i, v, lod, cap: 0, n: 0, mesh: null, geo: null, base }; this.batches.set(key, b); this.grow(b, 96); return b;
  }
  grow(b, need) {
    const cap = Math.max(need, 64), g = new THREE.InstancedBufferGeometry(); const base = b.base;
    g.index = base.index; for (const k in base.attributes) g.setAttribute(k, base.attributes[k]);
    b.aPos = new THREE.InstancedBufferAttribute(new Float32Array(cap * 3), 3); b.aA = new THREE.InstancedBufferAttribute(new Float32Array(cap * 4), 4); b.aB = new THREE.InstancedBufferAttribute(new Float32Array(cap * 4), 4);
    b.aPos.setUsage(THREE.DynamicDrawUsage); b.aA.setUsage(THREE.DynamicDrawUsage); b.aB.setUsage(THREE.DynamicDrawUsage);
    g.setAttribute('iPos', b.aPos); g.setAttribute('iA', b.aA); g.setAttribute('iB', b.aB); g.instanceCount = 0;
    if (!b.mesh) { b.mesh = new THREE.Mesh(g, this.mat(b.i, b.lod)); b.mesh.frustumCulled = false; b.mesh.matrixAutoUpdate = false; b.mesh.visible = false; b.mesh.renderOrder = 1; this.group.add(b.mesh); }
    else { const old = b.mesh.geometry; b.mesh.geometry = g; try { old.dispose(); } catch (_) {} }
    b.geo = g; b.cap = cap;
  }
  // ---------- celdas necesarias ----------
  need(cam) {
    const T = this.T, R1 = this.R1, RS = this.RG * 1.5 + 16, B = DWF_BIG, Sm = DWF_SMALL, q = []; this.tl = T.loaded;
    const scan = (map, size, R, kind) => {
      const c0x = Math.floor(cam.x / size), c0z = Math.floor(cam.z / size), n = Math.ceil(R / size) + 1;
      for (let dz = -n; dz <= n; dz++) for (let dx = -n; dx <= n; dx++) {
        const cx = c0x + dx, cz = c0z + dz, xc = (cx + 0.5) * size, zc = (cz + 0.5) * size, d = Math.hypot(xc - cam.x, zc - cam.z); if (d > R + size * 0.7) continue;
        const key = cx + ',' + cz, c = map.get(key);
        if (!c) { q.push({ k: kind, cx, cz, d }); continue; }
        if (c.lvl > 0 && d < R1 && T.levelAt(xc, zc) < c.lvl) q.push({ k: kind, cx, cz, d, re: 1 });
      }
      // olvidar lo lejano
      for (const [key, c] of map) { if (Math.hypot(c.xc - cam.x, c.zc - cam.z) > R + size * 2.4) { map.delete(key); this.dirty = true; } }
    };
    scan(this.cellsB, B, R1 + 90, 'b'); scan(this.cellsS, Sm, RS, 's');
    q.sort((a, b) => a.d - b.d); this.queue = q;
  }
  gen(q) {
    const map = q.k === 'b' ? this.cellsB : this.cellsS; let c = null;
    try { c = q.k === 'b' ? this.genBig(q.cx, q.cz) : this.genSmall(q.cx, q.cz); } catch (e) { eLog('warn', 'dragonWorld', e); c = { xc: (q.cx + 0.5) * (q.k === 'b' ? DWF_BIG : DWF_SMALL), zc: (q.cz + 0.5) * (q.k === 'b' ? DWF_BIG : DWF_SMALL), yc: 0, rad: 1, lvl: 0, groups: [], ready: true }; }
    if (c) { map.set(q.cx + ',' + q.cz, c); this.dirty = true; }
  }
  // ---------- bucle ----------
  update(cam, dt, W) {
    if (this.dead) return; this.t += dt; const T = this.T; const camera = (W && W.ctx && W.ctx.camera) || (this.W && this.W.ctx && this.W.ctx.camera); if (!camera) return;
    const fast = this.fast || T.fast, bud = fast ? 30 : 3.2, t0 = performance.now(), nowS = t0 / 1000;
    const kb = Math.floor(cam.x / DWF_BIG) + ',' + Math.floor(cam.z / DWF_BIG) + '|' + Math.floor(cam.x / DWF_SMALL) + ',' + Math.floor(cam.z / DWF_SMALL);
    if ((kb !== this.kb || this.tl !== T.loaded || this.nowNeed) && (fast || nowS - this.tNeed > 0.3)) { this.kb = kb; this.tNeed = nowS; this.nowNeed = 0; this.need(cam); }
    while (this.queue.length && performance.now() - t0 < bud) this.gen(this.queue.shift());
    while (this.geoQ.length && performance.now() - t0 < bud) { this.doGeo(this.geoQ.shift()); this.dirty = true; }
    camera.updateMatrixWorld(); camera.getWorldDirection(this.dir); const L = this.last;
    const moved = Math.hypot(cam.x - L.x, cam.z - L.z) > 7, rot = this.dir.x * L.fx + this.dir.y * L.fy + this.dir.z * L.fz < 0.9975, fovc = Math.abs(camera.fov - L.fov) > 0.5;
    if ((this.dirty || moved || rot || fovc) && (fast || nowS - this.tAsm > 0.11)) { this.tAsm = nowS; this.dirty = false; L.x = cam.x; L.z = cam.z; L.fx = this.dir.x; L.fy = this.dir.y; L.fz = this.dir.z; L.fov = camera.fov; this.assemble(cam, camera); }
  }
  // ---------- ensamblado de instancias visibles ----------
  assemble(cam, camera) {
    const px = cam.x, pz = cam.z, R0 = this.R0, band = R0 * 0.2, SPN = this.nSP, rM = this.rMax, SP = this.SP;
    this.mi.copy(camera.matrixWorld).invert(); this.pc.fov = Math.min(150, camera.fov * 1.35 + 8); this.pc.aspect = camera.aspect || 1.6; this.pc.near = 0.5; this.pc.far = 6000; this.pc.updateProjectionMatrix();
    this.pm.multiplyMatrices(this.pc.projectionMatrix, this.mi); this.fr.setFromProjectionMatrix(this.pm);
    const act = this.act; act.length = 0; const sph = this.sph, fr = this.fr;
    const gather = (map, lim) => { for (const c of map.values()) { const d = Math.hypot(c.xc - px, c.zc - pz); if (d > lim + c.rad) continue; if (!this.noCull && d > 70 + c.rad) { sph.center.set(c.xc, c.yc, c.zc); sph.radius = c.rad; if (!fr.intersectsSphere(sph)) continue; } act.push(c); } };
    gather(this.cellsB, this.R1 + 20); gather(this.cellsS, this.RG * 1.5 + 12);
    const NID = SPN * 8; if (!this._cnt || this._cnt.length !== NID) { this._cnt = new Int32Array(NID); this._cur = new Int32Array(NID); this._bat = new Array(NID).fill(null); }
    const CNT = this._cnt, CUR = this._cur, BAT = this._bat; CNT.fill(0); CUR.fill(0);
    const run = (write) => {
      for (let ci = 0; ci < act.length; ci++) {
        const groups = act[ci].groups;
        for (let gi = 0; gi < groups.length; gi++) {
          const g = groups[gi], i = g.i, s = SP[i], d = g.d, n = g.n, big = s.big, rmax = rM[i], lodMode = big && !s.small, thin0 = big ? R0 * 1.5 : rmax * 0.3;
          for (let k = 0, o = 0; k < n; k++, o += 12) {
            const x = d[o], z = d[o + 2], dx = x - px, dz = z - pz, dd = Math.sqrt(dx * dx + dz * dz);
            if (dd >= rmax + 12) continue;
            const rank = d[o + 11]; if (dd > thin0 && rank > 1 - 0.55 * dwfSS(thin0, rmax, dd)) continue;
            const mode = lodMode ? (dd < R0 + band ? (dd > R0 - band ? 3 : 1) : 2) : 1, base = (i * 4 + (d[o + 5] | 0)) * 2;
            for (let lod = 0; lod < 2; lod++) {
              if (!(mode & (1 << lod))) continue; const id = base + lod;
              if (!write) { CNT[id]++; continue; }
              const b = BAT[id]; if (!b) continue; const w = CUR[id]++; if (w >= b.cap) continue;
              const pa = b.aPos.array, aa = b.aA.array, ab = b.aB.array, a3 = w * 3, a4 = w * 4;
              pa[a3] = x; pa[a3 + 1] = d[o + 1]; pa[a3 + 2] = z;
              aa[a4] = d[o + 3]; aa[a4 + 1] = d[o + 4]; aa[a4 + 2] = rank; aa[a4 + 3] = d[o + 6];
              ab[a4] = d[o + 8]; ab[a4 + 1] = d[o + 9]; ab[a4 + 2] = d[o + 10]; ab[a4 + 3] = d[o + 7];
            }
          }
        }
      }
    };
    run(false);
    let miss = false;
    for (let id = 0; id < NID; id++) {
      const cnt = CNT[id]; if (!cnt) continue; const lod = id & 1, v = (id >> 1) & 3, i = id >> 3; let b = BAT[id];
      if (!b) { if (!this.geoReady(i, v, lod)) { const gk = i + ':' + v + ':' + lod; if (!this.geoSet.has(gk)) { this.geoSet.add(gk); this.geoQ.push({ i, v, lod }); } miss = true; continue; } b = this.batch(i, v, lod); BAT[id] = b; if (!b) continue; }
      if (cnt > b.cap) this.grow(b, Math.ceil(cnt * 1.3) + 32);
    }
    run(true);
    for (let id = 0; id < NID; id++) {
      const b = BAT[id]; if (!b) continue; const n = Math.min(CNT[id], b.cap); if (n === 0 && b.n === 0) continue;
      b.n = n; b.geo.instanceCount = n; b.mesh.visible = n > 0;
      if (n > 0) for (const a of [b.aPos, b.aA, b.aB]) { if (a.clearUpdateRanges) a.clearUpdateRanges(); if (a.addUpdateRange) a.addUpdateRange(0, n * a.itemSize); a.needsUpdate = true; }
    }
    if (miss) this.dirty = true;
  }
  dispose() {
    this.dead = true; try { this.eng.terrain.onTile = this.tOnTile; } catch (_) {}
    try { this.eng.scene.remove(this.group); } catch (_) {}
    try { for (const b of this.batches.values()) { b.mesh.geometry.dispose(); } for (const g of this.geos.values()) { if (g) g.dispose(); } for (const m of this.mats.values()) m.dispose(); if (this.A && this.A.tex) this.A.tex.dispose(); } catch (_) {}
    this.batches.clear(); this.geos.clear(); this.mats.clear(); this.cellsB.clear(); this.cellsS.clear(); this.queue = []; this.geoQ = []; this.geoSet.clear();
  }
}

// ================================================================
// MUNDO DE DRAGONES — flora: colocación (idoneidad por hábitat,
// pendiente, humedad, altitud) a partir de la malla del terreno
// registro por instancia (12 floats):
//  x, y, z, giro, escala, variante, tinte, nieve, hab1, hab2, mezcla, rango
// ================================================================
function dwfVN(x, z, sd) { // ruido de valor 2D suave (0..1)
  const ix = Math.floor(x), iz = Math.floor(z), fx = x - ix, fz = z - iz, u = fx * fx * (3 - 2 * fx), v = fz * fz * (3 - 2 * fz);
  const a = dwfHash(ix, iz, sd), b = dwfHash(ix + 1, iz, sd), c = dwfHash(ix, iz + 1, sd), d = dwfHash(ix + 1, iz + 1, sd);
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}
function dwfHabPair(w, out) { // los dos hábitats dominantes y la mezcla hacia el segundo
  let i1 = 0, w1 = -1, i2 = 0, w2 = -1;
  for (let j = 0; j < 8; j++) { const v = w[j]; if (v > w1) { w2 = w1; i2 = i1; w1 = v; i1 = j; } else if (v > w2) { w2 = v; i2 = j; } }
  out[0] = i1; out[1] = i2; out[2] = (w1 + w2 > 1e-4) ? Math.min(0.5, Math.max(0, w2) / (w1 + w2)) : 0;
}

DWFlora.prototype.treeP = function (s, o, a, x, z) {
  const slope = 1 - o.ny, wk = s.wet || 0;
  const wetF = dwfSS(0.03, 0.3, o.wet) * (1 - dwfSS(0.8, 0.97, o.wet)), dry = 1 - dwfSS(0.55, 0.85, o.wet);
  const pf = o.can * a * (1 - wk * 0.5) * dry, ps = (s.sc || 0) * o.veg * a * (1 - wk) * dry, pw = wk > 0 ? a * o.veg * wetF * wk : 0, pb = (s.bare || 0) * a * dry;
  let p = Math.max(pf, ps, pw, pb); if (p <= 0) return 0;
  p *= 0.4 + 1.2 * dwfSS(0.3, 0.7, dwfVN(x * 0.014 + s.i * 3.1, z * 0.014 - s.i * 1.7, 53)); // rodales y claros (agrupación natural)
  p *= (1 - dwfSS(s.slope - 0.12, s.slope, slope)) * (1 - dwfSS(s.zMax - 250, s.zMax, o.h)) * (1 - dwfSS(0.55, 0.9, o.snow) * 0.9) * (1 - o.ice);
  if (p > 0.004 && this.H.lairAt(x, z) < 1.2) return 0;
  return p;
};
DWFlora.prototype.rockP = function (s, o, a, x, z) {
  const slope = 1 - o.ny; if (slope > 0.72) return 0;
  let p = a * (s.small ? 0.1 : 0.16) + a * (s.small ? 0.5 : 0.84) * dwfSS(0.08, 0.38, slope);
  p *= (1 - dwfSS(0.5, 0.92, o.snow) * 0.85) * (1 - o.ice) * (1 - dwfSS(0.75, 0.97, o.wet) * 0.8);
  if (!s.small && p > 0.004 && this.H.lairAt(x, z) < 1.2) return 0;
  return p;
};
DWFlora.prototype.coverP = function (s, o, a, x, z) {
  const slope = 1 - o.ny, wet = o.wet, snowF = 1 - dwfSS(0.25, 0.7, o.snow), iceF = 1 - o.ice, slF = 1 - dwfSS(0.3, 0.52, slope);
  if (s.reed) return a * dwfSS(0.18, 0.45, wet) * (1 - dwfSS(0.93, 0.995, wet)) * (0.35 + 0.9 * dwfVN(x * 0.05, z * 0.05, 31)) * snowF * iceF * slF;
  const dry = 1 - dwfSS(0.72, 0.95, wet); let p;
  if (s.kind === 'shrub') {
    p = a * Math.max(o.can * 1.15, s.sc * o.veg, s.bare || 0) * dry * slF * snowF * iceF;
    if (s.shade) p *= 0.4 + 0.6 * dwfSS(0.02, 0.4, o.can + 0.5 * o.veg);
    p *= 0.6 + 0.8 * dwfVN(x * 0.045 + 3.3, z * 0.045 - 1.7, 37 + s.i);
  } else {
    let pv = dwfSS(0.12, 0.45, o.veg); if (s.bare) pv = Math.max(pv, s.bare);
    p = a * pv * dry * slF * snowF * iceF * (1 - 0.5 * o.can);
    const nz = dwfVN(x * 0.06 + s.i * 7.1, z * 0.06 - s.i * 3.7, 41);
    if (s.patch) p *= dwfSS(0.5, 0.72, nz); else if (s.tall) p *= dwfSS(0.35, 0.7, nz); else p *= 0.55 + 0.8 * nz;
  }
  return p;
};

// recorre una rejilla con jitter de una especie dentro de la celda y llena buf con los registros aceptados
DWFlora.prototype.scatter = function (s, cx, cz, S, buf, o, hp, acc) {
  const i = s.i, n = Math.max(1, Math.round(S * Math.sqrt(s.dens * this.dm))), step = S / n, x0 = cx * S, z0 = cz * S, T = this.T, k = i * 13, rock = s.kind === 'rock', cover = s.kind === 'cover', hb = s.hab;
  for (let jz = 0; jz < n; jz++) for (let ix = 0; ix < n; ix++) {
    const gx = cx * n + ix, gz = cz * n + jz;
    const x = x0 + (ix + 0.1 + 0.8 * dwfHash(gx, gz, k + 1)) * step, z = z0 + (jz + 0.1 + 0.8 * dwfHash(gx, gz, k + 2)) * step;
    if (!T.sample(x, z, o)) continue;
    let a = 0; for (let j = 0; j < 8; j++) a += o.w[j] * hb[j]; if (a < 0.02) continue;
    const p = rock ? this.rockP(s, o, a, x, z) : (s.kind === 'tree' ? this.treeP(s, o, a, x, z) : this.coverP(s, o, a, x, z));
    if (p < 0.004 || dwfHash(gx, gz, k + 3) > p) continue;
    const r4 = dwfHash(gx, gz, k + 4), r5 = dwfHash(gx, gz, k + 5);
    let sc, y;
    if (rock) { sc = s.H[0] + (s.H[1] - s.H[0]) * Math.pow(r4, 2.2); y = o.h - 0.2 * sc; }
    else { const hh = s.H[0] + (s.H[1] - s.H[0]) * Math.pow(r4, 0.85) * (0.88 + 0.24 * r5); sc = hh / s.hGeo; y = o.h - (cover ? 0.03 : 0.02 * hh); }
    dwfHabPair(o.w, hp);
    buf.push(x, y, z, dwfHash(gx, gz, k + 6) * 6.2832, sc, Math.min(s.nv - 1, Math.floor(dwfHash(gx, gz, k + 7) * s.nv)), dwfHash(gx, gz, k + 8), o.snow, hp[0], hp[1], hp[2], dwfHash(gx, gz, k + 9));
    const top = y + sc * (s.hGeo || 1.4); if (y < acc.ymin) acc.ymin = y; if (top > acc.ymax) acc.ymax = top;
  }
};

DWFlora.prototype.genBig = function (cx, cz) {
  const T = this.T, S = DWF_BIG, x0 = cx * S, z0 = cz * S, o = this.so, SP = this.SP, hp = this._hp || (this._hp = [0, 0, 0]);
  const aff = this._aff || (this._aff = new Float32Array(this.nSP)); aff.fill(0); let lvl = 0;
  const PT = [[0.5, 0.5], [0.06, 0.06], [0.94, 0.06], [0.06, 0.94], [0.94, 0.94]];
  for (const p of PT) {
    if (!T.sample(x0 + p[0] * S, z0 + p[1] * S, o)) return null; if (o.lvl > lvl) lvl = o.lvl;
    for (const i of this.bigIdx) { const hb = SP[i].hab; let a = 0; for (let j = 0; j < 8; j++) a += o.w[j] * hb[j]; if (a > aff[i]) aff[i] = a; }
  }
  const groups = [], acc = { ymin: 1e9, ymax: -1e9 };
  for (const i of this.bigIdx) {
    if (aff[i] < 0.02) continue; const buf = []; this.scatter(SP[i], cx, cz, S, buf, o, hp, acc);
    if (buf.length) groups.push({ i, n: buf.length / 12, d: new Float32Array(buf) });
  }
  if (acc.ymin > acc.ymax) { acc.ymin = 0; acc.ymax = 0; }
  return { xc: x0 + S / 2, zc: z0 + S / 2, yc: (acc.ymin + acc.ymax) / 2, rad: Math.hypot(S * 0.7072, (acc.ymax - acc.ymin) / 2) + 14, lvl, groups, ready: true };
};
DWFlora.prototype.genSmall = function (cx, cz) {
  const T = this.T, S = DWF_SMALL, x0 = cx * S, z0 = cz * S, o = this.so, SP = this.SP, hp = this._hp || (this._hp = [0, 0, 0]);
  if (!T.sample(x0 + S / 2, z0 + S / 2, o)) return null; const lvl = o.lvl, w0 = this._w0 || (this._w0 = new Float32Array(8)); for (let j = 0; j < 8; j++) w0[j] = o.w[j];
  const groups = [], acc = { ymin: 1e9, ymax: -1e9 };
  for (const i of this.smallIdx) {
    const s = SP[i]; let a = 0; for (let j = 0; j < 8; j++) a += w0[j] * s.hab[j]; if (a < 0.02) continue;
    const buf = []; this.scatter(s, cx, cz, S, buf, o, hp, acc);
    if (buf.length) groups.push({ i, n: buf.length / 12, d: new Float32Array(buf) });
  }
  if (acc.ymin > acc.ymax) { acc.ymin = 0; acc.ymax = 0; }
  return { xc: x0 + S / 2, zc: z0 + S / 2, yc: (acc.ymin + acc.ymax) / 2, rad: Math.hypot(S * 0.7072, (acc.ymax - acc.ymin) / 2) + 4, lvl, groups, ready: true };
};


  return { DWF_REGISTER };
}
