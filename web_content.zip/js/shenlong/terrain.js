// Mundo SHENLONG · terreno por teselas (quadtree con niveles de detalle), material y trabajos en segundo plano (Web Workers
// con respaldo en el hilo principal). Portado del archivo EDEN-Visor-3D.
import { EDEN_DW_HEIGHT } from './height.js';

export function EDEN_DW_TERRAIN(THREE, DW) {
  'use strict';
  const V3 = THREE.Vector3, C3 = THREE.Color;
  const H = DW.H = EDEN_DW_HEIGHT();

  // ---------- calidad ----------
  DW.QUALITY = [
    { name: 'bajo', N: 32, K: 1.0, detail: 0, texSize: 128, workers: 1, levels: 10, cache: 150, flora: 0.35, layers: 1 },
    { name: 'medio', N: 40, K: 1.15, detail: 1, texSize: 256, workers: 2, levels: 10, cache: 240, flora: 0.65, layers: 1 },
    { name: 'alto', N: 48, K: 1.3, detail: 2, texSize: 256, workers: 3, levels: 10, cache: 320, flora: 1.0, layers: 2 },
    { name: 'ultra', N: 48, K: 1.7, detail: 2, texSize: 256, workers: 3, levels: 10, cache: 420, flora: 1.35, layers: 3 }
  ];

  // ---------- paletas por hábitat (0 base,1 celestial,2 glaciar,3 cañón,4 jade,5 cascadas,6 mesas,7 caldera) ----------
  // rA/rB roca (sombra/luz), rC acento (liquen, estrato claro, musgo), soil, gA/gB hierba, sp nieve, cA/cB copas de bosque
  // p1 = [1/espesor de estratos (m), contraste estratos, bandas finas, vetas de escorrentía]
  // p2 = [vegetación, humedad oscurece, lava, -]   p3 = [liquen/musgo, gravilla, copas, sequedad]
  const PAL = [
    { sa: 0x9a8a66, rA: 0x5d5953, rB: 0x8a8478, rC: 0x9a9588, soil: 0x5b4a38, gA: 0x466e2a, gB: 0x73913f, sp: 0xf1f4f8, cA: 0x2c4521, cB: 0x56753a, p1: [1 / 90, 0.15, 0.2, 0.6], p2: [1.0, 0.7, 0, 0], p3: [0.3, 0.6, 1.0, 0.06] },
    { sa: 0x8c8576, rA: 0x6c6864, rB: 0xa7a198, rC: 0xb4ab6a, soil: 0x6b5d4b, gA: 0x5f7538, gB: 0x9a9858, sp: 0xf6f4ee, cA: 0x1d3626, cB: 0x3a5a3a, p1: [1 / 140, 0.0, 0.0, 0.9], p2: [1.0, 0.6, 0, 0], p3: [0.9, 0.9, 1.0, 0.3] },
    { sa: 0x7d848a, rA: 0x474f58, rB: 0x7a8691, rC: 0xb4c3cf, soil: 0x585b5e, gA: 0x58664c, gB: 0x7b8468, sp: 0xe9f0f8, cA: 0x253a30, cB: 0x46604f, p1: [1 / 60, 0.25, 0.2, 0.8], p2: [0.6, 0.6, 0, 0], p3: [0.3, 1.0, 0.7, 0.4] },
    { sa: 0xc99a6b, rA: 0x5b2b22, rB: 0xb5603a, rC: 0xd9b88c, soil: 0x8f5434, gA: 0x877c3c, gB: 0xb09a4e, sp: 0xd4b04a, cA: 0x5a5a26, cB: 0xa49a3a, p1: [1 / 150, 1.0, 0.8, 0.7], p2: [1.0, 0.5, 0, 0], p3: [0.0, 0.8, 0.5, 0.6] },
    { sa: 0xd2c39a, rA: 0x6a7165, rB: 0xb2b2a0, rC: 0x5f8a45, soil: 0x6e5f42, gA: 0x2b5f2e, gB: 0x4b7f3a, sp: 0xd8d6c0, cA: 0x174422, cB: 0x38823a, p1: [1 / 70, 0.1, 0.2, 1.0], p2: [1.2, 0.8, 0, 0], p3: [1.0, 0.5, 1.0, 0.0] },
    { sa: 0xb3a784, rA: 0x474d42, rB: 0x7a7f6f, rC: 0x4f7a3a, soil: 0x46392a, gA: 0x2d5a2a, gB: 0x486e33, sp: 0xcbbf9a, cA: 0x1a4222, cB: 0x3a7a32, p1: [1 / 100, 0.2, 0.2, 0.8], p2: [1.2, 0.9, 0, 0], p3: [1.0, 0.6, 1.0, 0.05] },
    { sa: 0xd6b27c, rA: 0x78462a, rB: 0xcf9658, rC: 0xe8d3a6, soil: 0xb98a58, gA: 0x9a8f4a, gB: 0xb8a465, sp: 0xe0c08a, cA: 0x66713a, cB: 0x9c9a4c, p1: [1 / 120, 0.9, 0.7, 0.6], p2: [0.5, 0.3, 0, 0], p3: [0.0, 0.7, 0.3, 0.75] },
    { sa: 0x2a2624, rA: 0x1e1c1b, rB: 0x4c4540, rC: 0x7a3a22, soil: 0x2e2a27, gA: 0x4a4a30, gB: 0x5a5a3a, sp: 0x77726b, cA: 0x2a2a22, cB: 0x4a4a38, p1: [1 / 45, 0.35, 0.3, 0.2], p2: [0.2, 0.2, 1, 0], p3: [0.0, 1.0, 0.15, 0.9] }
  ];
  DW.PAL = PAL;

  // ---------- material ----------
  const terrVS = /* glsl */`
attribute vec4 aNrm, aW0, aW1, aEnv, aEnv2;
varying vec3 vW, vN; varying vec4 vW0, vW1, vEnv, vEnv2;
void main(){
  vec4 w = modelMatrix * vec4(position, 1.0);
  vW = w.xyz; vN = aNrm.xyz; vW0 = aW0; vW1 = aW1; vEnv = aEnv; vEnv2 = aEnv2;
  gl_Position = projectionMatrix * viewMatrix * w;
}`;
  const terrFS = /* glsl */`
varying vec3 vW, vN; varying vec4 vW0, vW1, vEnv, vEnv2;
uniform sampler2D tDetail, tNoise, tSoil; uniform vec3 uOrigin;
uniform vec3 uSand[8], uRockA[8], uRockB[8], uRockC[8], uSoil[8], uGrassA[8], uGrassB[8], uSpec[8], uCanA[8], uCanB[8]; uniform vec4 uP1[8], uP2[8], uP3[8];
uniform vec4 uLava;
${DW.GLSL_ATM}
${DW.GLSL_CAPS}
vec3 unpackN(vec2 xy){ vec2 v = xy * 2.0 - 1.0; return vec3(v, sqrt(max(1.0 - dot(v, v), 0.0))); }
vec3 triNormal(vec4 tx, vec4 ty, vec4 tz, vec3 n, vec3 w, float s){
  vec3 nx = unpackN(tx.xy); vec3 ny = unpackN(ty.xy); vec3 nz = unpackN(tz.xy);
  nx.xy *= s; ny.xy *= s; nz.xy *= s;
  nx = vec3(nx.xy + n.zy, abs(nx.z) * n.x); ny = vec3(ny.xy + n.xz, abs(ny.z) * n.y); nz = vec3(nz.xy + n.xy, abs(nz.z) * n.z);
  return normalize(nx.zyx * w.x + ny.xzy * w.y + nz.xyz * w.z);
}
void main(){
  vec3 N = normalize(vN);
  vec3 toC = cameraPosition - vW; float dist = length(toC); vec3 V = toC / dist;
  float ws[8]; ws[0] = vW0.x; ws[1] = vW0.y; ws[2] = vW0.z; ws[3] = vW0.w; ws[4] = vW1.x; ws[5] = vW1.y; ws[6] = vW1.z; ws[7] = vW1.w;
  vec3 sandB = vec3(0.0), rockA = vec3(0.0), rockB = vec3(0.0), rockC = vec3(0.0), soilC = vec3(0.0), grA = vec3(0.0), grB = vec3(0.0), spC = vec3(0.0), canA = vec3(0.0), canB = vec3(0.0); vec4 p1 = vec4(0.0), p2 = vec4(0.0), p3 = vec4(0.0);
  for (int i = 0; i < 8; i++) { float w = ws[i]; if (w < 0.012) continue; sandB += w * uSand[i]; rockA += w * uRockA[i]; rockB += w * uRockB[i]; rockC += w * uRockC[i]; soilC += w * uSoil[i]; grA += w * uGrassA[i]; grB += w * uGrassB[i]; spC += w * uSpec[i]; canA += w * uCanA[i]; canB += w * uCanB[i]; p1 += w * uP1[i]; p2 += w * uP2[i]; p3 += w * uP3[i]; }
  vec2 xz = vW.xz; vec3 q = vW - uOrigin;
  float m1 = texture2D(tNoise, xz * 0.000075).r, m2 = texture2D(tNoise, xz * 0.00055).g, m3 = texture2D(tNoise, xz * 0.0042).r, m4 = texture2D(tNoise, xz * 0.025).g;
  float m5 = texture2D(tNoise, xz * 0.095 + 0.31).r, m6 = texture2D(tNoise, xz * 0.31 + 0.7).g;
  float hf = texture2D(tNoise, q.xz * 0.3125).a;
  float fadeF = 1.0 - smoothstep(25.0, 170.0, dist), fadeC = 1.0 - smoothstep(200.0, 1600.0, dist);
  float slope = 1.0 - N.y;
  // ---- suelo / hierba: relieve plano en XZ ----
  vec4 s1 = texture2D(tSoil, q.xz * 0.625), s2 = texture2D(tSoil, q.xz * 0.1563);
  vec2 gs = (unpackN(s1.xy).xy * fadeF * 0.9 + unpackN(s2.xy).xy * (0.35 + 0.5 * fadeC));
  float hs = mix(s2.b, s1.b * 0.6 + s2.b * 0.4, fadeF);
  // ---- roca: triplanar ----
  vec3 Nr = N; float hr = 0.5, cav = 1.0;
  #if DETAIL > 0
    vec3 wgt = pow(abs(N), vec3(5.0)); wgt /= (wgt.x + wgt.y + wgt.z);
    vec4 fx = texture2D(tDetail, q.zy * 0.3125), fy = texture2D(tDetail, q.xz * 0.3125), fz = texture2D(tDetail, q.xy * 0.3125);
    vec3 nF = triNormal(fx, fy, fz, N, wgt, 1.0);
    float hF = fx.b * wgt.x + fy.b * wgt.y + fz.b * wgt.z; float cF = fx.a * wgt.x + fy.a * wgt.y + fz.a * wgt.z;
    #if DETAIL > 1
      vec4 cx = texture2D(tDetail, q.zy * 0.0781), cy = texture2D(tDetail, q.xz * 0.0781), cz = texture2D(tDetail, q.xy * 0.0781);
      vec3 nC = triNormal(cx, cy, cz, N, wgt, 1.2);
      float hC = cx.b * wgt.x + cy.b * wgt.y + cz.b * wgt.z; float cC = cx.a * wgt.x + cy.a * wgt.y + cz.a * wgt.z;
      Nr = normalize(mix(N, nC, fadeC * 0.9)); Nr = normalize(mix(Nr, nF, fadeF * 0.9)); hr = mix(hC, hF, fadeF); cav = mix(1.0, mix(cC, cF, fadeF), 0.9 * fadeC);
    #else
      Nr = normalize(mix(N, nF, fadeF * 0.9)); hr = mix(0.5, hF, fadeF); cav = mix(1.0, cF, fadeF * 0.8);
    #endif
  #else
    vec4 cy = texture2D(tDetail, q.xz * 0.0781); vec2 gg = unpackN(cy.xy).xy; Nr = normalize(N + vec3(gg.x, 0.0, gg.y) * 0.6 * fadeC); hr = cy.b; cav = cy.a;
  #endif
  vec3 Ns = normalize(vec3(N.x + gs.x, N.y, N.z + gs.y));
  // ================= ROCA =================
  // mota de color a varias escalas (nunca franjas regulares)
  float mott = clamp(0.45 + (m3 - 0.5) * 0.85 + (m4 - 0.5) * 0.55 + (m5 - 0.5) * 0.35 + (hr - 0.5) * 0.45 + (m2 - 0.5) * 0.5, 0.0, 1.0);
  vec3 rock = mix(rockA, rockB, mott);
  // estratos de espesor variable (solo rocas sedimentarias: p1.y > 0), ondulados por ruido
  float sy = (vW.y + (m3 - 0.5) * 26.0 + (m2 - 0.5) * 140.0 + sin(vW.x * 0.0041 + vW.z * 0.0029) * 20.0) * p1.x;
  float sa = texture2D(tNoise, vec2(0.21, sy)).g, sb = texture2D(tNoise, vec2(0.67, sy * 3.7)).g;
  float band = smoothstep(0.42, 0.58, sa), thin = smoothstep(0.46, 0.54, sb);
  rock = mix(rock, rockC, band * p1.y * 0.6);
  rock *= 1.0 - p1.z * 0.30 * thin;
  rock *= mix(1.0, 0.7 + 0.6 * sa, p1.y * 0.3);
  rock *= 0.74 + 0.52 * hr; rock *= mix(1.0, cav, 0.4);
  // vetas oscuras de escorrentía, verticales
  float stn = texture2D(tNoise, vec2((vW.x * 0.7 + vW.z) * 0.0042, vW.y * 0.0009)).g * 0.65 + texture2D(tNoise, vec2((vW.x * 0.7 + vW.z) * 0.0135 + 0.3, vW.y * 0.0028)).g * 0.35;
  float streak = smoothstep(0.50, 0.78, stn) * smoothstep(0.28, 0.62, slope) * p1.w;
  rock *= 1.0 - 0.45 * streak;
  // líquenes y musgo en superficies poco inclinadas
  float lich = smoothstep(0.56, 0.80, m4 * 0.5 + hr * 0.4 + m6 * 0.25 + (m3 - 0.5) * 0.4) * p3.x * (1.0 - smoothstep(0.32, 0.68, slope)) * fadeC;
  rock = mix(rock, rockC * (0.75 + 0.5 * m6), lich * 0.75);
  // ================= SUELO Y HIERBA =================
  vec3 soil = soilC * (0.66 + 0.55 * m3 + 0.30 * (hs - 0.5) + 0.25 * (m5 - 0.5));
  float dry = clamp(p3.w + (m1 - 0.5) * 0.7 + (m2 - 0.5) * 0.5, 0.0, 1.0);
  float gmix = smoothstep(0.3, 0.7, m2 + 0.5 * (m1 - 0.5) + 0.25 * (m3 - 0.5));
  vec3 grass = mix(grA, grB, clamp(gmix * 0.75 + dry * 0.5, 0.0, 1.0));
  float patchK = smoothstep(0.35, 0.7, texture2D(tNoise, xz * 0.0105).r);
  grass *= (0.55 + 0.75 * m4) * (0.78 + 0.5 * hs) * mix(0.88, 1.12, patchK) * (0.9 + 0.2 * (hf - 0.5)) * (0.86 + 0.28 * m5) * (0.92 + 0.16 * m6);
  float veg = vEnv.x * p2.x;
  float gAmt = smoothstep(0.2, 0.55, veg + (hs - 0.5) * 0.45 + (m3 - 0.5) * 0.22 + (m5 - 0.5) * 0.18);
  vec3 ground = mix(soil, grass, gAmt);
  float wRock = smoothstep(0.22, 0.46, slope + (hr - 0.5) * 0.12 + (m4 - 0.5) * 0.06 + (m5 - 0.5) * 0.05);
  // gravilla y derrubios al pie de los riscos
  float scr = smoothstep(0.14, 0.26, slope) * (1.0 - smoothstep(0.40, 0.56, slope)) * p3.y;
  float grain = mix(0.5, texture2D(tNoise, q.xz * 0.7).a, fadeF);
  vec3 scree = mix(rockB * 1.05, soilC * 1.25, 0.35) * (0.66 + 0.7 * grain) * (0.85 + 0.3 * m4);
  ground = mix(ground, scree, scr * (1.0 - gAmt * 0.45));
  vec3 alb = mix(ground, rock, wRock);
  // ---- orilla: arena y guijarros mojados ----
  float beach = smoothstep(0.5, 0.95, vEnv.z) * (1.0 - smoothstep(0.12, 0.34, slope));
  vec3 sand = sandB * (0.82 + 0.3 * m4) * (0.9 + 0.2 * hs) * (0.9 + 0.2 * grain);
  alb = mix(alb, sand, beach);
  // ---- nieve ----
  float sn = smoothstep(0.38, 0.62, vEnv.y + (hr - 0.5) * 0.4 + (hs - 0.5) * 0.25 + (m3 - 0.5) * 0.25 + (m5 - 0.5) * 0.2 - slope * 0.35);
  vec3 snowC = spC * (0.93 + 0.1 * hf);
  float ice = vEnv2.y;
  float crev = 1.0 - smoothstep(0.0, 0.085, texture2D(tNoise, xz * 0.011).b);
  vec3 iceC = mix(vec3(0.55, 0.74, 0.88), vec3(0.86, 0.93, 0.97), m3) * (1.0 - 0.45 * crev);
  // ---- copas de bosque (a lo lejos son árboles pintados; de cerca la flora real las tapa) ----
  float cn = vEnv2.x * p3.z; vec3 Nd0 = vec3(0.0); float cw = 0.0; float shadeK = 0.0;
  if (cn > 0.02) {
    float cb = texture2D(tNoise, xz * 0.0076).b, cb2 = texture2D(tNoise, xz * 0.0214 + 0.37).b;
    float crown = smoothstep(0.04, 0.55, cb) * 0.62 + smoothstep(0.04, 0.6, cb2) * 0.38;
    float leafT = clamp(texture2D(tNoise, xz * 0.011).r + (m5 - 0.5) * 0.5, 0.0, 1.0);
    vec3 canopy = mix(canA, canB, leafT) * (0.40 + 0.85 * crown) * (0.92 + 0.16 * m6);
    cw = smoothstep(0.14, 0.5, cn + (m3 - 0.5) * 0.3 + (m5 - 0.5) * 0.15) * (1.0 - sn * 0.6);
    shadeK = cw * (0.3 + 0.7 * crown);
    float far = smoothstep(60.0, 420.0, dist);
    // cerca: suelo de bosque oscuro con hojarasca; lejos: copas
    vec3 litter = mix(soil, canA * 0.9, 0.5) * 0.46;
    alb = mix(alb, mix(litter, canopy, far), cw * (0.55 + 0.45 * far));
  }
  alb = mix(alb, snowC, sn); alb = mix(alb, iceC, ice);
  alb *= 1.0 - 0.3 * vEnv.z * (1.0 - sn) * p2.y;
  // normal final: suelo plano vs roca
  float rockMix = max(wRock, max(sn * 0.5, beach * 0.0));
  vec3 Nd = normalize(mix(Ns, Nr, clamp(wRock * 1.2, 0.0, 1.0)));
  Nd = normalize(mix(Nd, N, ice * 0.8));
  Nd = normalize(mix(Nd, N, cw * smoothstep(40.0, 400.0, dist) * 0.7));
  // ---- lava ----
  float lavaK = ws[7] * p2.z; vec3 emis = vec3(0.0);
  if (lavaK > 0.02) {
    vec2 wxz = xz + (vec2(m5, m6) - 0.5) * 22.0 + (vec2(m3, m4) - 0.5) * 60.0;
    float cr = texture2D(tNoise, wxz * 0.0105).b, cr2 = texture2D(tNoise, wxz * 0.031 + 0.4).b;
    float line = 1.0 - smoothstep(0.0, 0.045 + 0.05 * m5, min(cr, cr2 * 1.1 + 0.08 * m6));
    line *= 0.55 + 0.9 * texture2D(tNoise, wxz * 0.0007).g;
    float dl = length(xz - uLava.xy); float nearL = 1.0 - smoothstep(uLava.z * 0.9, uLava.z * 3.2, dl);
    float heat = line * (nearL * 1.1 + 0.10) * lavaK * smoothstep(0.0, 0.25, 1.0 - sn);
    heat *= 0.78 + 0.22 * sin(uTime * 0.9 + m3 * 18.0);
    emis = mix(vec3(1.4, 0.26, 0.04), vec3(2.6, 1.0, 0.2), line * nearL) * heat;
    alb *= 1.0 - 0.45 * nearL * lavaK;
  }
  // ---- iluminación ----
  vec3 L = uSunDir;
  float nlR = dot(Nd, L);
  float nl = max(nlR, 0.0);
  float soft = max(nlR * 0.78 + 0.22, 0.0);
  nl = mix(nl, soft, gAmt * (1.0 - wRock) * 0.55 + cw * 0.5);
  float sunVis = smoothstep(-0.03, 0.2, dot(N, L));
  sunVis *= dragonShadow(vW, L);
  sunVis *= 1.0 - 0.7 * shadeK * (1.0 - smoothstep(0.0, 900.0, dist));
  vec3 sunC = uSunCol * nl * sunVis;
  float ao = (1.0 - 0.28 * shadeK) * vEnv.w * mix(1.0, cav, 0.65) * mix(0.8 + 0.3 * hs, 1.0, wRock) * mix(1.0, 0.72 + 0.4 * m6, cw * 0.6);
  vec3 amb = mix(uGndAmb, uSkyAmb, 0.5 + 0.5 * Nd.y) * ao;
  vec3 moon = uMoonCol * max(dot(Nd, uMoonDir), 0.0) * 2.0;
  vec3 col = alb * (sunC + amb + moon);
  float gloss = mix(16.0, 90.0, clamp(sn + ice + vEnv.z * 0.5, 0.0, 1.0));
  vec3 Hh = normalize(L + V); float spec = pow(max(dot(Nd, Hh), 0.0), gloss) * (0.03 + 0.5 * (sn + ice) + 0.2 * vEnv.z * (1.0 - sn)) * sunVis;
  col += uSunCol * spec;
  col += snowC * sn * 0.06 * uSkyAmb;
  col += emis;
  col = aerial(col, vW);
  gl_FragColor = vec4(col, 1.0);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}`;

  DW.makeTerrainMaterial = function (q) {
    const mk = (k) => PAL.map(p => new C3(p[k]));
    const u = Object.assign({}, DW.U, {
      uOrigin: { value: new V3() },
      uSand: { value: mk('sa') }, uRockA: { value: mk('rA') }, uRockB: { value: mk('rB') }, uRockC: { value: mk('rC') }, uSoil: { value: mk('soil') }, uGrassA: { value: mk('gA') }, uGrassB: { value: mk('gB') }, uSpec: { value: mk('sp') },
      uCanA: { value: mk('cA') }, uCanB: { value: mk('cB') },
      uP1: { value: PAL.map(p => new THREE.Vector4(...p.p1)) }, uP2: { value: PAL.map(p => new THREE.Vector4(...p.p2)) }, uP3: { value: PAL.map(p => new THREE.Vector4(...p.p3)) },
      uLava: { value: new THREE.Vector4(H.WATER[3].x, H.WATER[3].z, H.WATER[3].r, 1) },
      uCaps: DW.U.uCaps, uNCaps: DW.U.uNCaps
    });
    DW.terrUniforms = u;
    const m = new THREE.ShaderMaterial({ uniforms: u, vertexShader: terrVS, fragmentShader: terrFS, side: THREE.DoubleSide, fog: false, defines: { DETAIL: q.detail } });
    m.extensions = { derivatives: true };
    return m;
  };

  // ---------- trabajos (workers) ----------
  function Jobs(nWorkers) {
    this.workers = []; this.idle = []; this.queue = []; this.pending = new Map(); this.nextId = 1; this.mode = 'sync'; this.frame = 0;
    if (nWorkers > 0 && typeof Worker !== 'undefined' && typeof Blob !== 'undefined') {
      try {
        const parts = (DW.workerParts || []).map(f => f.toString());
        const code = '(()=>{const H=(' + EDEN_DW_HEIGHT.toString() + ')();const J={};' + parts.map(p => '(' + p + ')(H,J);').join('') +
          'J.tile=(m)=>{const r=H.tile(m.x0,m.z0,m.size,m.N,m.lvl);return {r,tr:[r.pos.buffer,r.nrm.buffer,r.w0.buffer,r.w1.buffer,r.env.buffer,r.env2.buffer,r.hg.buffer]};};' +
          'onmessage=(e)=>{const m=e.data;try{const o=J[m.type](m.p);postMessage({id:m.id,r:o.r},o.tr||[]);}catch(err){postMessage({id:m.id,err:String(err&&err.stack||err)});}};postMessage({ready:1});})();';
        const url = URL.createObjectURL(new Blob([code], { type: 'text/javascript' })); this.url = url;
        for (let i = 0; i < nWorkers; i++) {
          const w = new Worker(url); w.__busy = false; w.onmessage = (e) => this._done(w, e.data); w.onerror = (e) => { this._fail(w, e); }; this.workers.push(w);
        }
        this.mode = 'worker';
      } catch (e) { this.workers = []; this.mode = 'sync'; }
    }
    this.idle = this.workers.slice();
  }
  Jobs.prototype._done = function (w, m) {
    if (m.ready) return;
    const j = this.pending.get(m.id); this.pending.delete(m.id); w.__busy = false; this.idle.push(w);
    if (j) { if (m.err) j.rej(new Error(m.err)); else j.res(m.r); }
    this.pump();
  };
  Jobs.prototype._fail = function (w, e) {
    // si un worker muere, se pasa a modo síncrono
    this.mode = 'sync'; for (const x of this.workers) { try { x.terminate(); } catch (_) {} } this.workers = []; this.idle = [];
    const lost = Array.from(this.pending.values()); this.pending.clear(); for (const j of lost) this.queue.push(j);
  };
  Jobs.prototype.run = function (type, p, pri, key, stale) {
    let job; const pr = new Promise((res, rej) => { job = { type, p, pri, key, res, rej, stale, stamp: this.frame }; this.queue.push(job); }); pr.job = job; return pr;
  };
  Jobs.prototype.pump = function (budgetMs) {
    this.queue.sort((a, b) => a.pri - b.pri);
    if (this.mode === 'worker') {
      while (this.idle.length && this.queue.length) {
        const j = this.queue.shift(); if (j.stale && j.stale()) { j.res(null); continue; }
        const w = this.idle.pop(); const id = this.nextId++; this.pending.set(id, j); w.__busy = true; w.postMessage({ id, type: j.type, p: j.p });
      }
    } else {
      const t0 = performance.now(); let n = 0;
      while (this.queue.length && (n === 0 || performance.now() - t0 < (budgetMs || 6))) {
        const j = this.queue.shift(); if (j.stale && j.stale()) { j.res(null); continue; }
        try { const J = DW.syncJobs; j.res(J[j.type](j.p)); } catch (e) { j.rej(e); } n++;
      }
    }
  };
  Jobs.prototype.busy = function () { return this.queue.length + this.pending.size; };
  Jobs.prototype.dispose = function () { for (const w of this.workers) { try { w.terminate(); } catch (_) {} } this.workers = []; this.idle = []; try { if (this.url) URL.revokeObjectURL(this.url); } catch (_) {} };
  DW.Jobs = Jobs;
  DW.syncJobs = { tile: (m) => H.tile(m.x0, m.z0, m.size, m.N, m.lvl) };

  // ---------- terreno ----------
  class DWTerrain {
    constructor(scene, q, jobs) {
      this.scene = scene; this.q = q; this.jobs = jobs; this.N = q.N; this.K = q.K; this.size0 = q.N * 2; this.maxLvl = q.levels - 1;
      this.tiles = new Map(); this.wantFrame = new Map(); this.reqJobs = new Map(); this.shown = []; this.frame = 0;
      this.group = new THREE.Group(); this.group.name = 'dw-terrain'; scene.add(this.group);
      this.material = DW.makeTerrainMaterial(q);
      this.waterMats = DW.waterMats || (DW.waterMats = {
        sea: DW.makeWaterMaterial(0, { shallow: 0x3f9a9a, deep: 0x082c48, absorb: 0.07, wave: 0.7, rough: 1.0 }),
        jade: DW.makeWaterMaterial(0, { shallow: 0x3aa88c, deep: 0x0c5a50, absorb: 0.16, wave: 0.12, rough: 0.55 }),
        lago: DW.makeWaterMaterial(0, { shallow: 0x2f8aa0, deep: 0x0a3d5a, absorb: 0.075, wave: 0.2, rough: 0.7 }),
        hielo: DW.makeWaterMaterial(1, {}), lava: DW.makeWaterMaterial(2, {})
      });
      this.bodyMat = [this.waterMats.jade, this.waterMats.lago, this.waterMats.hielo, this.waterMats.lava];
      this.index = this._makeIndex(); this.windex = this._makeWaterIndex();
      this.loaded = 0; this.inFlight = new Set(); this.applyQ = []; this.lastCam = new V3(1e9, 0, 0); this.disposed = false;
    }
    _makeIndex() {
      const N = this.N, N1 = N + 1, V = N1 * N1; const idx = [];
      for (let j = 0; j < N; j++) for (let i = 0; i < N; i++) { const a = j * N1 + i, b = a + 1, c = a + N1, d = c + 1; idx.push(a, c, d, a, d, b); }
      // faldones: lado z=0 (V..), z=N, x=0, x=N
      const strip = (base, border, flip) => { for (let t = 0; t < N; t++) { const b0 = border[t], b1 = border[t + 1], s0 = base + t, s1 = base + t + 1; if (flip) idx.push(b0, b1, s0, b1, s1, s0); else idx.push(b0, s0, b1, b1, s0, s1); } };
      const bz0 = [], bz1 = [], bx0 = [], bx1 = []; for (let t = 0; t <= N; t++) { bz0.push(t); bz1.push(N * N1 + t); bx0.push(t * N1); bx1.push(t * N1 + N); }
      strip(V, bz0, false); strip(V + N1, bz1, true); strip(V + 2 * N1, bx0, true); strip(V + 3 * N1, bx1, false);
      return new THREE.BufferAttribute(new Uint16Array(idx), 1);
    }
    _makeWaterIndex() { return null; }
    key(l, i, j) { return l + ':' + i + ':' + j; }
    // altura del terreno donde el jugador pisa (interpola la malla más fina disponible)
    groundAt(x, z) {
      const N = this.N, N1 = N + 1;
      for (let l = 0; l <= this.maxLvl; l++) {
        const size = this.size0 * (1 << l), ix = Math.floor(x / size), iz = Math.floor(z / size); const t = this.tiles.get(this.key(l, ix, iz));
        if (t && t.ready) {
          const s = size / N; const fx = (x - ix * size) / s, fz = (z - iz * size) / s; let i = Math.floor(fx), j = Math.floor(fz); if (i >= N) i = N - 1; if (j >= N) j = N - 1; const u = fx - i, v = fz - j; const hg = t.hg;
          const a = hg[j * N1 + i], b = hg[j * N1 + i + 1], c = hg[(j + 1) * N1 + i], d = hg[(j + 1) * N1 + i + 1];
          return v >= u ? a + (d - c) * u + (c - a) * v : a + (b - a) * u + (d - b) * v;
        }
      }
      return H.heightAt(x, z, 4);
    }
    // nivel (0 = más fino) de la malla lista que cubre el punto, o -1
    levelAt(x, z) {
      for (let l = 0; l <= this.maxLvl; l++) { const size = this.size0 * (1 << l); const t = this.tiles.get(this.key(l, Math.floor(x / size), Math.floor(z / size))); if (t && t.ready) return l; }
      return -1;
    }
    // altura y atributos de entorno en un punto (a partir de la malla ya construida); o=salida reutilizable
    sample(x, z, o) {
      const N = this.N, N1 = N + 1;
      for (let l = 0; l <= this.maxLvl; l++) {
        const size = this.size0 * (1 << l), ix = Math.floor(x / size), iz = Math.floor(z / size); const t = this.tiles.get(this.key(l, ix, iz));
        if (t && t.ready && t.env) {
          const s = size / N; const fx = (x - ix * size) / s, fz = (z - iz * size) / s; let i = Math.floor(fx), j = Math.floor(fz); if (i >= N) i = N - 1; if (j >= N) j = N - 1; const u = fx - i, v = fz - j; const hg = t.hg;
          const k = j * N1 + i, a = hg[k], b = hg[k + 1], c = hg[k + N1], d = hg[k + N1 + 1];
          o.h = v >= u ? a + (d - c) * u + (c - a) * v : a + (b - a) * u + (d - b) * v;
          const kk = (k + (u > 0.5 ? 1 : 0) + (v > 0.5 ? N1 : 0)) * 4, e = t.env, e2 = t.env2, nr = t.nrm, w0 = t.w0, w1 = t.w1;
          o.veg = e[kk] / 255; o.snow = e[kk + 1] / 255; o.wet = e[kk + 2] / 255; o.can = e2[kk] / 255; o.ice = e2[kk + 1] / 255; o.ny = nr[kk + 1] / 127;
          const W = o.w || (o.w = new Float32Array(8)); W[0] = w0[kk] / 255; W[1] = w0[kk + 1] / 255; W[2] = w0[kk + 2] / 255; W[3] = w0[kk + 3] / 255; W[4] = w1[kk] / 255; W[5] = w1[kk + 1] / 255; W[6] = w1[kk + 2] / 255; W[7] = w1[kk + 3] / 255;
          o.lvl = l; return true;
        }
      }
      return false;
    }
    update(cam, dt) {
      if (this.disposed) return; this.frame++; this.jobs.frame = this.frame;
      this.material.uniforms.uOrigin.value.set(Math.floor(cam.x / 102.4) * 102.4, 0, Math.floor(cam.z / 102.4) * 102.4);
      this.cam = cam; this.shown.length = 0; this.wanted = [];
      for (let iz = -1; iz <= 0; iz++) for (let ix = -1; ix <= 0; ix++) this.walk(this.maxLvl, ix, iz, cam);
      // peticiones
      this.wanted.sort((a, b) => a.pri - b.pri);
      let budget = 0;
      for (const w of this.wanted) { this.wantFrame.set(w.key, this.frame); const j = this.reqJobs.get(w.key); if (j) { j.pri = w.pri; continue; } if (this.tiles.has(w.key)) continue; if (this.inFlight.size >= 48) continue; this._request(w); }
      this.jobs.pump(5);
      // aplicar resultados
      const ta = performance.now(); let ap = 0; while (this.applyQ.length && (ap < 1 || performance.now() - ta < (this.fast ? 14 : 4))) { this._apply(this.applyQ.shift()); ap++; }
      // visibilidad
      for (const t of this.shown) t.shownFrame = this.frame;
      for (const t of this.tiles.values()) { const vis = t.shownFrame === this.frame; if (t.mesh) t.mesh.visible = vis; if (t.water) for (const m of t.water) m.visible = vis; }
      if (this.tiles.size > this.q.cache && (this.frame % 30 === 0)) this._evict();
    }
    rangeOf(l, ix, iz) {
      // altura estimada para tesela aún sin construir: la del ancestro más cercano construido
      for (let k = l + 1; k <= this.maxLvl; k++) { const sh = k - l; const t = this.tiles.get(this.key(k, ix >> sh, iz >> sh)); if (t && t.ready) return t; }
      return null;
    }
    walk(l, ix, iz, cam) {
      const size = this.size0 * (1 << l), x0 = ix * size, z0 = iz * size, key = this.key(l, ix, iz);
      const t = this.tiles.get(key);
      let mn = -120, mx = 3600; if (t && t.ready) { mn = t.minH; mx = t.maxH; } else { const a = this.rangeOf(l, ix, iz); if (a) { mn = a.minH; mx = a.maxH; } }
      const dx = Math.max(x0 - cam.x, 0, cam.x - (x0 + size)), dz = Math.max(z0 - cam.z, 0, cam.z - (z0 + size)), dy = Math.max(mn - cam.y, 0, cam.y - mx);
      const dist = Math.sqrt(dx * dx + dz * dz + dy * dy);
      if (t) t.lastUse = this.frame;
      const kk = this.K * (l >= 8 ? 0.6 : l >= 6 ? 0.78 : 1);
      if (l > 0 && dist < kk * size) {
        const mark = this.shown.length; let ready = true;
        for (let c = 0; c < 4; c++) { if (!this.walk(l - 1, ix * 2 + (c & 1), iz * 2 + (c >> 1), cam)) ready = false; }
        if (ready) return true;
        if (t && t.ready) { this.shown.length = mark; this.shown.push(t); return true; }
        this.wanted.push({ key, l, ix, iz, dist, pri: (this.maxLvl - l) * 1e6 + dist - 5e5 });
        return false;
      }
      if (t && t.ready) { this.shown.push(t); return true; }
      this.wanted.push({ key, l, ix, iz, dist, pri: (this.maxLvl - l) * 1e6 + dist });
      return false;
    }
    _request(w) {
      const size = this.size0 * (1 << w.l); this.inFlight.add(w.key);
      const frame = this.frame; const self = this;
      const stale = () => self.disposed || (self.frame - (self.wantFrame.get(w.key) || 0) > 10);
      const job = this.jobs.run('tile', { x0: w.ix * size, z0: w.iz * size, size, N: this.N, lvl: w.l }, w.pri, w.key, stale);
      this.reqJobs.set(w.key, job.job);
      job.then(r => { self.reqJobs.delete(w.key); if (r && !self.disposed) self.applyQ.push({ w, r }); else self.inFlight.delete(w.key); }).catch(e => { self.inFlight.delete(w.key); self.reqJobs.delete(w.key); console.warn('tile', e); });
    }
    _apply(o) {
      const { w, r } = o; const key = w.key; this.inFlight.delete(key); if (this.tiles.has(key)) return;
      const g = new THREE.BufferGeometry(); const N = this.N;
      g.setAttribute('position', new THREE.BufferAttribute(r.pos, 3));
      g.setAttribute('aNrm', new THREE.BufferAttribute(r.nrm, 4, true)); g.setAttribute('aW0', new THREE.BufferAttribute(r.w0, 4, true)); g.setAttribute('aW1', new THREE.BufferAttribute(r.w1, 4, true));
      g.setAttribute('aEnv', new THREE.BufferAttribute(r.env, 4, true)); g.setAttribute('aEnv2', new THREE.BufferAttribute(r.env2, 4, true));
      g.setIndex(this.index);
      const size = r.size, sk = Math.max(3, size * 0.008); const hr = (r.maxH - r.minH) / 2 + sk;
      g.boundingSphere = new THREE.Sphere(new V3(size / 2, (r.maxH + r.minH) / 2, size / 2), Math.sqrt(size * size / 2 + hr * hr) + 1);
      const mesh = new THREE.Mesh(g, this.material); mesh.position.set(r.x0, 0, r.z0); mesh.matrixAutoUpdate = false; mesh.updateMatrix(); mesh.frustumCulled = true; mesh.visible = false;
      this.group.add(mesh);
      const t = { key, l: w.l, ix: w.ix, iz: w.iz, ready: true, mesh, hg: r.hg, nrm: r.nrm, w0: r.w0, w1: r.w1, env: r.env, env2: r.env2, minH: r.minH, maxH: r.maxH, lastUse: this.frame, shownFrame: -1, water: [] };
      this._makeWater(t, r);
      this.tiles.set(key, t); this.loaded++; if (this.onTile) { try { this.onTile(t); } catch (_) {} }
    }
    _makeWater(t, r) {
      const N = this.N, N1 = N + 1, s = r.size / N; const hg = r.hg;
      const bodies = []; // {level, mat, mask}
      if (r.minH < H.SEA + 0.5) bodies.push({ level: H.SEA, mat: this.waterMats.sea, idx: -1 });
      for (let b = 0; b < H.WATER.length; b++) {
        const w = H.WATER[b]; const cx = Math.max(r.x0, Math.min(w.x, r.x0 + r.size)), cz = Math.max(r.z0, Math.min(w.z, r.z0 + r.size));
        if ((cx - w.x) * (cx - w.x) + (cz - w.z) * (cz - w.z) > w.r * w.r) continue; if (r.minH > w.level + 0.5) continue; bodies.push({ level: w.level, mat: this.bodyMat[b], idx: b });
      }
      for (const bd of bodies) {
        const depth = new Float32Array(N1 * N1); let any = false;
        for (let j = 0; j < N1; j++) for (let i = 0; i < N1; i++) {
          const k = j * N1 + i; const wx = r.x0 + i * s, wz = r.z0 + j * s; let inb = true;
          inb = bd.idx >= 0 ? H.waterAt(wx, wz) === bd.idx : H.waterAt(wx, wz) < 0;
          let d = inb ? bd.level - hg[k] : -1; if (d > 0) any = true; depth[k] = Math.min(d, 90);
        }
        if (!any) continue;
        const pos = new Float32Array(N1 * N1 * 3); for (let j = 0; j < N1; j++) for (let i = 0; i < N1; i++) { const k = (j * N1 + i) * 3; pos[k] = i * s; pos[k + 1] = bd.level; pos[k + 2] = j * s; }
        const idx = []; for (let j = 0; j < N; j++) for (let i = 0; i < N; i++) { const a = j * N1 + i, b = a + 1, c = a + N1, d = c + 1; if (depth[a] > -0.5 || depth[b] > -0.5 || depth[c] > -0.5 || depth[d] > -0.5) idx.push(a, c, d, a, d, b); }
        if (!idx.length) continue;
        const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('aDepth', new THREE.BufferAttribute(depth, 1)); g.setIndex(new THREE.BufferAttribute(new Uint16Array(idx), 1));
        g.boundingSphere = new THREE.Sphere(new V3(r.size / 2, bd.level, r.size / 2), r.size * 0.72 + 5);
        const m = new THREE.Mesh(g, bd.mat); m.position.set(r.x0, 0, r.z0); m.matrixAutoUpdate = false; m.updateMatrix(); m.renderOrder = bd.idx >= 0 && H.WATER[bd.idx].kind === 2 ? 2 : 3; m.visible = false; this.group.add(m); t.water.push(m);
      }
    }
    _evict() {
      const arr = Array.from(this.tiles.values()).filter(t => this.frame - t.lastUse > 120).sort((a, b) => a.lastUse - b.lastUse);
      let n = this.tiles.size - Math.floor(this.q.cache * 0.85);
      for (const t of arr) { if (n-- <= 0) break; this._drop(t); }
    }
    _drop(t) { this.group.remove(t.mesh); t.mesh.geometry.dispose(); for (const m of t.water) { this.group.remove(m); m.geometry.dispose(); } this.tiles.delete(t.key); }
    // listo cuando no faltan teselas cerca
    readiness(cam) {
      let need = 0, have = 0;
      for (const w of (this.wanted || [])) { if (w.l >= 5 || w.dist < 2500) need++; }
      return { missing: need, tiles: this.tiles.size, queued: this.jobs.busy() };
    }
    setQuality(q) { this.K = q.K; }
    dispose() {
      this.disposed = true; for (const t of Array.from(this.tiles.values())) this._drop(t); this.scene.remove(this.group); this.material.dispose();
    }
  }
  DW.Terrain = DWTerrain;
}
