// Mundo SHENLONG · los siete dragones a escala gigante, cada uno en su hábitat. Reutilizan el zoológico (zoo.makeInst + animador
// procedural). Portado del archivo EDEN-Visor-3D. env = { zoo (createZoo), log }
export function EDEN_DW_DRAGONS(THREE, env = {}) {
  const eLog = env.log || (() => {});
  const Zoo = env.zoo;
const DWD_CFG = {
  dragonEo: { len: 640, st: 'coil', shape: 'lie', lieP: { nb: 1.3, amp: 1.15, phase: 0.4, uL: 0.84, rise: 1.4, endE: -0.2 }, yawOff: 0 },
  dragonEa: { len: 420, st: 'coil', shape: 'lie', lieP: { nb: 0.85, amp: 1.35, phase: 1.0, uL: 0.8, rise: 1.25, endE: -0.3 }, yawOff: 0 },
  dragonEn: { len: 330, st: 'coil', shape: 'lie', lieP: { nb: 1.55, amp: 0.95, phase: 2.0, uL: 0.82, rise: 1.2, endE: -0.3 }, yawOff: 0 },
  dragonEb: { len: 270, st: 'coil', yawOff: 0 },
  dragonE: { len: 210, st: 'coil', shape: 'lie', lieP: { nb: 1.8, amp: 0.9, phase: 0.8, uL: 0.82, rise: 1.3, endE: -0.25 }, yawOff: 0 },
  dragonEg: { len: 180, st: 'coil', shape: 'lie', lieP: { nb: 1.1, amp: 1.4, phase: 0.2, uL: 0.8, rise: 1.2, endE: -0.3 }, yawOff: 0 },
  dragonW: { len: 300, st: 'rest', yawOff: 0 }
};
function DWD_REGISTER(DW) { DW.mods.push({ name: 'dragons', create(eng, W) { return new DWDragons(eng, W); } }); }

class DWDragons {
  constructor(eng, W) {
    this.eng = eng; this.W = W; this.H = eng.H; this.onEvent = null; this.dead = false; this.t = 0; this.capT = 0; this.items = [];
    this.group = new THREE.Group(); this.group.name = 'dw-dragons'; eng.scene.add(this.group);
    this.fr = new THREE.Frustum(); this.pm = new THREE.Matrix4(); this.sph = new THREE.Sphere(); this.tmp = new THREE.Vector3(); this.tmp2 = new THREE.Vector3();
    const H = eng.H;
    for (let i = 1; i < H.HABS.length; i++) {
      const hb = H.HABS[i], cfg = DWD_CFG[hb.dragon]; if (!cfg) continue;
      const lx = hb.lair.x, lz = hb.lair.z; const y = hb.lair.y !== undefined ? hb.lair.y : H.heightAt(lx, lz);
      const vx = (hb.appr || hb.view).x - lx, vz = (hb.appr || hb.view).z - lz;
      this.items.push({ id: hb.dragon, hab: hb, cfg, inst: null, c: null, lod: -1, loading: false, scale: 1, pos: new THREE.Vector3(lx, y, lz), yaw: Math.atan2(vx, vz) + (cfg.yawOff || 0), vis: false, acc: 0, dist: 1e9, mats: [], err: 0, home: { pos: new THREE.Vector3(lx, y, lz), yaw: Math.atan2(vx, vz) + (cfg.yawOff || 0) }, call: null });
    }
  }
  enter(W) {
    this.kick();
  }
  async kick() {
    if (this.kicking) return; this.kicking = true;
    try {
      const wantLod = () => (this.eng.ti >= 2 ? 0 : 1);
      // 1) primero todos en baja resolución (el más cercano antes), 2) luego alta resolución cuando el jugador se acerca
      while (!this.dead) {
        const P = this.W.position; for (const it of this.items) it.dist = Math.hypot(P.x - it.pos.x, P.z - it.pos.z);
        let job = null;
        const todo = this.items.filter(it => !it.inst && !it.loading && it.err < 2).sort((a, b) => a.dist - b.dist)[0];
        if (todo) job = { it: todo, lod: 1 };
        else if (wantLod() === 0) { const up = this.items.filter(it => it.inst && it.lod === 1 && !it.loading && it.err < 2 && it.dist < 2600).sort((a, b) => a.dist - b.dist)[0]; if (up) job = { it: up, lod: 0 }; }
        if (job) await this.load(job.it, job.lod); else await new Promise(r => setTimeout(r, 900));
      }
    } finally { this.kicking = false; }
  }
  async load(it, lod) {
    it.loading = true;
    try {
      const inst = await Zoo.makeInst(it.id, lod); if (this.dead) return;
      const tpl = Zoo.tpl[it.id + ':' + lod] || Zoo.tpl[it.id + ':0'] || Zoo.tpl[it.id + ':1']; let base = 1;
      try { const bb = tpl.geo.boundingBox || (tpl.geo.computeBoundingBox(), tpl.geo.boundingBox); base = Math.max(bb.max.z - bb.min.z, bb.max.x - bb.min.x, 1e-3); } catch (_) { base = (Zoo.SP[it.id].cfg && Zoo.SP[it.id].cfg.L) || 30; }
      const mats = []; inst.group.traverse(o => { if (o.isMesh && o.material) { if (Array.isArray(o.material)) o.material = o.material.map(m => { const q = this.eng.DW.aerialize(m); mats.push(q); return q; }); else { const q = this.eng.DW.aerialize(o.material); mats.push(q); o.material = q; } o.castShadow = false; o.receiveShadow = false; o.frustumCulled = false; } });
      const c = Zoo.AN.make(inst, { kind: Zoo.SP[it.id].kind }); Zoo.AN.setState(c, it.cfg.st); if (it.cfg.shape) { c.shape = it.cfg.shape; c.lieP = it.cfg.lieP; }
      it.scale = it.cfg.len / base; inst.group.scale.setScalar(it.scale); inst.group.position.copy(it.pos); inst.group.rotation.y = it.yaw;
      const old = it.inst; if (old) { this.group.remove(old.group); it.mats.forEach(m => { try { m.dispose(); } catch (_) {} }); }
      it.mats = mats; it.inst = inst; it.c = c; it.lod = lod; it.vis = true; this.group.add(inst.group);
      if (it.call) { inst.group.rotation.order = 'YXZ'; it.mv = null; this.setMove(it, it.call.phase === 'hover' ? 'hover' : it.call.phase === 'roar' ? 'roar' : 'fly'); } // cambió de resolución en pleno vuelo
      for (let k = 0; k < 70; k++) { try { Zoo.AN.update(c, 0.1, 0); } catch (e) { throw e; } } // asentar la pose de reposo
      inst.group.updateMatrixWorld(true);
    } catch (e) { it.err++; eLog('warn', 'dragonWorld', e); console.warn('[dragon]', it.id, e); }
    finally { it.loading = false; }
  }
  update(cam, dt, W) {
    this.t += dt; this.pm.multiplyMatrices(W.ctx.camera.projectionMatrix, W.ctx.camera.matrixWorldInverse); this.fr.setFromProjectionMatrix(this.pm);
    let nearest = null, nd = 1e9;
    for (const it of this.items) {
      if (!it.inst) continue;
      if (it.call) this.stepCall(it, dt);
      const d = cam.distanceTo(it.pos); it.dist = d;
      this.sph.center.set(it.pos.x, it.pos.y + it.cfg.len * 0.12, it.pos.z); this.sph.radius = it.cfg.len * (it.cfg.st === 'rest' ? 0.7 : 0.5) + 40;
      const vis = d < 42000 && this.fr.intersectsSphere(this.sph); if (vis !== it.vis) { it.vis = vis; it.inst.group.visible = vis; }
      if (!vis) continue;
      it.acc += dt; const iv = d < 2500 ? 0.05 : d < 9000 ? 0.15 : 0.5;
      if (it.acc >= iv) { try { Zoo.AN.update(it.c, it.acc, 0); } catch (e) { it.err = 9; eLog('warn', 'dragonWorld', e); } it.acc = 0; }
      if (d < nd) { nd = d; nearest = it; }
    }
    this.capT -= dt; if (this.capT <= 0) { this.capT = 0.4; this.caps(nearest, nd); }
  }
  // ── Llamado ─────────────────────────────────────────────────────────────────────────────────────────────────────────────────
  // El jugador llama a un dragón desde donde está: sale de su guarida, cruza el cielo y se queda sobrevolando cerca de ese lugar,
  // mirando al jugador. «Que vuelva» lo lleva de regreso a su guarida y recupera su postura de reposo.
  list() {
    return this.items.map((it) => ({ id: it.id, habitat: it.hab.name, loaded: !!it.inst, state: it.call ? (it.call.home ? 'volviendo' : it.call.phase === 'hover' ? 'aqui' : 'viniendo') : 'guarida', dist: Math.hypot(this.W.position.x - it.pos.x, this.W.position.z - it.pos.z) }));
  }
  groundNear(x, z) { try { return Math.max(this.eng.terrain.groundAt(x, z), this.H.heightAt(x, z) - 40); } catch (_) { return this.H.heightAt(x, z); } }
  // El mejor punto de parada: en la línea entre el jugador y el dragón, a una distancia proporcional a su tamaño.
  standoff(it, P) {
    const D = it.cfg.len * 0.5 + 140;
    const from = it.call ? it.pos : it.home.pos;
    let dx = from.x - P.x, dz = from.z - P.z; const l = Math.hypot(dx, dz) || 1; dx /= l; dz /= l;
    const x = P.x + dx * D, z = P.z + dz * D;
    return new THREE.Vector3(x, Math.max(this.groundNear(x, z), P.y - 30) + it.cfg.len * 0.12 + 80, z);
  }
  callTo(id, P) {
    const it = this.items.find((i) => i.id === id);
    const name = (Zoo.SP[id] && Zoo.SP[id].name) || 'El dragón';
    if (!it) return { ok: false, msg: 'Ese dragón no existe.' };
    if (!it.inst) return { ok: false, msg: `${name} aún está despertando; prueba en unos segundos.` };
    if (it.call && !it.call.home && it.call.phase === 'hover') {
      const d = Math.hypot(P.x - it.pos.x, P.z - it.pos.z);
      if (d < it.cfg.len * 0.5 + 400) return { ok: true, msg: `${name} ya está aquí.` };
    }
    const target = this.standoff(it, P);
    this.startFlight(it, target, { x: P.x, z: P.z }, false);
    const eta = Math.round(it.call.dur);
    this.emit('start', it);
    return { ok: true, msg: eta > 4 ? `Llamaste a ${name}. Llegará en unos ${eta} s.` : `Llamaste a ${name}.`, eta };
  }
  sendHome(id) {
    let n = 0;
    for (const it of this.items) {
      if (!it.call || (id && it.id !== id)) continue;
      this.startFlight(it, it.home.pos.clone().setY(it.home.pos.y + it.cfg.len * 0.3 + 60), null, true);
      n++;
    }
    return n;
  }
  startFlight(it, to, look, home) {
    const from = it.pos.clone();
    const dist = Math.hypot(to.x - from.x, to.z - from.z);
    const dur = Math.max(6, Math.min(60, dist / 140)); // unos 140 m/s; nunca más de un minuto de espera
    if (!it.call) it.inst.group.rotation.order = 'YXZ';
    it.call = { phase: 'fly', from, to, look, home, t: 0, dur, dist, bump: Math.min(420, dist * 0.06), prevY: from.y };
    this.setMove(it, 'fly');
  }
  setMove(it, st) { if (it.mv === st) return; it.mv = st; try { Zoo.AN.setState(it.c, st); } catch (_) {} }
  emit(type, it) { try { this.onEvent && this.onEvent(type, it); } catch (_) {} }
  stepCall(it, dt) {
    const k = it.call, g = it.inst.group, P = this.W.position;
    k.t += dt;
    if (k.phase === 'fly') {
      const u = Math.min(1, k.t / k.dur), e = u * u * (3 - 2 * u); // sale y llega con suavidad
      const x = k.from.x + (k.to.x - k.from.x) * e, z = k.from.z + (k.to.z - k.from.z) * e;
      let y = k.from.y + (k.to.y - k.from.y) * e + Math.sin(Math.PI * e) * k.bump; // sube a crucero y baja al llegar
      y = Math.max(y, this.groundNear(x, z) + it.cfg.len * 0.1 + 50); // sin atravesar montañas
      const dx = x - it.pos.x, dz = z - it.pos.z, dy = y - it.pos.y, hs = Math.hypot(dx, dz);
      it.pos.set(x, y, z);
      if (hs > 0.05) { const want = Math.atan2(dx, dz); let d = want - it.yaw; d = Math.atan2(Math.sin(d), Math.cos(d)); it.yaw += d * Math.min(1, dt * 1.6); }
      const pitch = Math.max(-0.45, Math.min(0.45, -Math.atan2(dy, Math.max(hs, 0.001)) * 0.6));
      g.rotation.x += (pitch - g.rotation.x) * Math.min(1, dt * 2);
      this.setMove(it, u > 0.8 && !k.home ? 'glide' : 'fly');
      if (u >= 1) {
        if (k.home) { this.settleHome(it); return; }
        k.phase = 'roar'; k.t = 0; this.setMove(it, 'roar'); this.emit('arrive', it);
      }
    } else if (k.phase === 'roar' || k.phase === 'hover') {
      // Sobrevuela el lugar: mira al jugador y se mece un poco.
      const want = Math.atan2(P.x - it.pos.x, P.z - it.pos.z); let d = want - it.yaw; d = Math.atan2(Math.sin(d), Math.cos(d)); it.yaw += d * Math.min(1, dt * 0.9);
      it.pos.y = k.to.y + Math.sin(k.t * 0.55) * 7;
      g.rotation.x += (0 - g.rotation.x) * Math.min(1, dt * 2);
      if (k.phase === 'roar' && k.t > 3.2) { k.phase = 'hover'; this.setMove(it, 'hover'); }
    }
    g.position.copy(it.pos); g.rotation.y = it.yaw;
  }
  settleHome(it) {
    const h = it.home, g = it.inst.group;
    it.call = null; it.mv = null; it.pos.copy(h.pos); it.yaw = h.yaw;
    g.rotation.set(0, h.yaw, 0); g.rotation.order = 'XYZ'; g.position.copy(h.pos);
    try {
      Zoo.AN.setState(it.c, it.cfg.st); if (it.cfg.shape) { it.c.shape = it.cfg.shape; it.c.lieP = it.cfg.lieP; }
      for (let i = 0; i < 70; i++) Zoo.AN.update(it.c, 0.1, 0); // vuelve a asentar la pose de reposo
    } catch (e) { eLog('warn', 'dragonWorld', e); }
    this.emit('home', it);
  }
  // sombras en el terreno: cápsulas del dragón más cercano (espiral, cuello+cabeza, cola)
  caps(it, d) {
    const U = this.eng.DW.U; if (!it || d > 5000) { U.uNCaps.value = 0; return; }
    const inst = it.inst, ro = inst.rig && inst.rig.roles || {}, bn = inst.byName, A = U.uCaps.value; const v = this.tmp, s = it.scale;
    const wp = (n) => { const b = bn[n]; if (!b) return null; return b.getWorldPosition(new THREE.Vector3()); };
    const spine = (ro.spine || []).map(wp).filter(Boolean), neck = (ro.neck || []).map(wp).filter(Boolean), tail = ((ro.tails || [])).map(wp).filter(Boolean), head = ro.head ? wp(ro.head) : null;
    let n = 0; const put = (a, b, r, k) => { A[n * 2].set(a.x, a.y, a.z, r); A[n * 2 + 1].set(b.x, b.y, b.z, k); n++; };
    if (spine.length > 2) {
      let cx = 0, cz = 0, ymax = -1e9, ymin = 1e9; spine.forEach(p => { cx += p.x; cz += p.z; ymax = Math.max(ymax, p.y); ymin = Math.min(ymin, p.y); }); cx /= spine.length; cz /= spine.length;
      let rm = 0; spine.forEach(p => { rm = Math.max(rm, Math.hypot(p.x - cx, p.z - cz)); });
      const R0 = (Zoo.SP[it.id].cfg ? Zoo.SP[it.id].cfg.thick * Zoo.SP[it.id].cfg.L : 1) * s;
      if (it.cfg.st === 'coil') put(new THREE.Vector3(cx, ymin - R0, cz), new THREE.Vector3(cx, ymax, cz), rm + R0 * 1.2, 1);
      else { for (let i = 0; i + 1 < spine.length && n < 3; i += Math.max(1, Math.floor(spine.length / 3))) { const a = spine[i], b = spine[Math.min(spine.length - 1, i + Math.max(1, Math.floor(spine.length / 3)))]; put(a, b, R0 * 1.6, 1); } }
    }
    if (neck.length > 1 && head) { put(neck[0], head, (Zoo.SP[it.id].cfg ? Zoo.SP[it.id].cfg.thick * Zoo.SP[it.id].cfg.L : 1) * s * 1.0, 0.9); }
    if (tail.length > 3) { const a = tail[0], b = tail[Math.floor(tail.length * 0.6)]; put(a, b, (Zoo.SP[it.id].cfg ? Zoo.SP[it.id].cfg.thick * Zoo.SP[it.id].cfg.L : 1) * s * 0.7, 0.9); }
    U.uNCaps.value = Math.min(n, 6);
  }
  dispose() {
    this.dead = true; try { this.eng.scene.remove(this.group); } catch (_) {}
    this.items.forEach(it => { it.mats.forEach(m => { try { m.dispose(); } catch (_) {} }); it.mats = []; it.inst = null; });
    try { this.eng.DW.U.uNCaps.value = 0; } catch (_) {}
  }
}


  return { DWD_REGISTER, DWD_CFG };
}
