// Mundo SHENLONG · texturas procedurales de roca, suelo, nubes, ruido y agua (portado del archivo EDEN-Visor-3D).
export function EDEN_DW_TEX(THREE, DW) {
  'use strict';
  const clamp = (x, a, b) => x < a ? a : x > b ? b : x;
  // hash de lattice periódico
  function hv(ix, iy, per, seed) { ix = ((ix % per) + per) % per; iy = ((iy % per) + per) % per; let h = Math.imul(ix, 374761393) ^ Math.imul(iy, 668265263) ^ Math.imul(seed + 7, 2147483629); h = Math.imul(h ^ (h >>> 13), 1274126177); h ^= h >>> 16; return (h >>> 0) / 4294967296; }
  function pval(x, y, per, seed) {
    const ix = Math.floor(x), iy = Math.floor(y), fx = x - ix, fy = y - iy;
    const u = fx * fx * (3 - 2 * fx), v = fy * fy * (3 - 2 * fy);
    const a = hv(ix, iy, per, seed), b = hv(ix + 1, iy, per, seed), c = hv(ix, iy + 1, per, seed), d = hv(ix + 1, iy + 1, per, seed);
    return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
  }
  function pfbm(u, v, base, oct, seed) { let a = 0, amp = 0.5, f = base, s = 0; for (let i = 0; i < oct; i++) { a += amp * pval(u * f, v * f, f, seed + i * 17); s += amp; f *= 2; amp *= 0.5; } return a / s; }
  // Worley periódico → [F1, F2]
  const _w = [0, 0];
  function pworley(u, v, per, seed) {
    const x = u * per, y = v * per, ix = Math.floor(x), iy = Math.floor(y); let f1 = 9, f2 = 9;
    for (let j = -1; j <= 1; j++) for (let i = -1; i <= 1; i++) {
      const cx = ix + i, cy = iy + j; const px = cx + hv(cx, cy, per, seed), py = cy + hv(cx, cy, per, seed + 91);
      const d = Math.hypot(px - x, py - y); if (d < f1) { f2 = f1; f1 = d; } else if (d < f2) f2 = d;
    }
    _w[0] = f1; _w[1] = f2; return _w;
  }
  async function slice() { await new Promise(r => setTimeout(r, 0)); }

  function mkTex(data, size, opts) {
    const t = new THREE.DataTexture(data, size, size, THREE.RGBAFormat, THREE.UnsignedByteType);
    t.wrapS = t.wrapT = THREE.RepeatWrapping; t.magFilter = THREE.LinearFilter; t.minFilter = THREE.LinearMipmapLinearFilter; t.generateMipmaps = true;
    t.colorSpace = THREE.NoColorSpace; t.anisotropy = (opts && opts.aniso) || 4; t.needsUpdate = true; return t;
  }

  // altura de roca: placas agrietadas + fbm
  async function genDetail(S) {
    const H = new Float32Array(S * S);
    for (let y = 0; y < S; y++) {
      for (let x = 0; x < S; x++) {
        const u = x / S, v = y / S;
        const w1 = pworley(u + 0.03 * pfbm(u, v, 4, 2, 5), v + 0.03 * pfbm(u, v, 4, 2, 6), 7, 3); const plates = clamp(w1[1] - w1[0], 0, 1);   // 0 en grietas
        const crack = Math.min(1, plates * 3.2);
        const w2 = pworley(u, v, 19, 8); const peb = clamp(w2[0] * 1.1, 0, 1);
        const f = pfbm(u, v, 6, 5, 21), g = pfbm(u, v, 24, 3, 41);
        H[y * S + x] = 0.38 * crack + 0.22 * (1 - peb) + 0.28 * f + 0.12 * g;
      }
      if ((y & 31) === 31) await slice();
    }
    const d = new Uint8ClampedArray(S * S * 4); const str = 3.2;
    const at = (x, y) => H[(((y % S) + S) % S) * S + (((x % S) + S) % S)];
    for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
      const dx = (at(x - 1, y) - at(x + 1, y)) * str, dy = (at(x, y - 1) - at(x, y + 1)) * str; const l = Math.hypot(dx, dy, 1);
      const avg = (at(x - 2, y) + at(x + 2, y) + at(x, y - 2) + at(x, y + 2) + at(x - 1, y - 1) + at(x + 1, y + 1) + at(x - 1, y + 1) + at(x + 1, y - 1)) / 8; const cav = clamp(0.55 + (at(x, y) - avg) * 5, 0, 1);
      const i = (y * S + x) * 4; d[i] = (dx / l * 0.5 + 0.5) * 255; d[i + 1] = (dy / l * 0.5 + 0.5) * 255; d[i + 2] = clamp(H[y * S + x], 0, 1) * 255; d[i + 3] = cav * 255;
    }
    return mkTex(d, S, { aniso: 8 });
  }
  async function genNoise(S) {
    const d = new Uint8ClampedArray(S * S * 4);
    for (let y = 0; y < S; y++) {
      for (let x = 0; x < S; x++) {
        const u = x / S, v = y / S, i = (y * S + x) * 4;
        const r = pfbm(u, v, 3, 5, 100), g = pfbm(u, v, 9, 4, 200);
        const w = pworley(u, v, 11, 300); const cr = clamp((w[1] - w[0]) * 2.4, 0, 1);
        const a = hv(x, y, S, 400) * 0.6 + pval(u * 64, v * 64, 64, 410) * 0.4;
        d[i] = clamp((r - 0.5) * 2.1 + 0.5, 0, 1) * 255; d[i + 1] = clamp((g - 0.5) * 2.1 + 0.5, 0, 1) * 255; d[i + 2] = cr * 255; d[i + 3] = a * 255;
      }
      if ((y & 31) === 31) await slice();
    }
    return mkTex(d, S, { aniso: 4 });
  }
  async function genCloud(S) {
    const d = new Uint8ClampedArray(S * S * 4);
    for (let y = 0; y < S; y++) {
      for (let x = 0; x < S; x++) {
        const u = x / S, v = y / S, i = (y * S + x) * 4;
        const wu = u + 0.06 * pfbm(u, v, 3, 3, 500), wv = v + 0.06 * pfbm(u, v, 3, 3, 510);
        const r = pfbm(wu, wv, 4, 6, 520); const w = pworley(u, v, 8, 530); const bil = 1 - clamp(w[0] * 1.15, 0, 1);
        const g = clamp(0.55 * r + 0.45 * bil * (0.6 + 0.4 * pfbm(u, v, 12, 3, 540)), 0, 1);
        d[i] = clamp((r - 0.5) * 2.3 + 0.5, 0, 1) * 255; d[i + 1] = clamp((g - 0.35) * 1.9 + 0.35, 0, 1) * 255; d[i + 2] = pfbm(u, v, 16, 4, 550) * 255; d[i + 3] = 255;
      }
      if ((y & 31) === 31) await slice();
    }
    return mkTex(d, S, { aniso: 2 });
  }
  async function genWater(S) {
    const H = new Float32Array(S * S);
    for (let y = 0; y < S; y++) { for (let x = 0; x < S; x++) { const u = x / S, v = y / S; const a = pfbm(u, v, 3, 3, 600), b = pfbm(u + 0.2 * a, v + 0.2 * a, 8, 4, 610); const rid = 1 - Math.abs(pfbm(u, v, 6, 3, 620) - 0.5) * 2; H[y * S + x] = 0.45 * a + 0.35 * b + 0.2 * rid * rid; } if ((y & 31) === 31) await slice(); }
    const d = new Uint8ClampedArray(S * S * 4); const at = (x, y) => H[(((y % S) + S) % S) * S + (((x % S) + S) % S)];
    for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) { const dx = (at(x - 1, y) - at(x + 1, y)) * 9, dy = (at(x, y - 1) - at(x, y + 1)) * 9; const l = Math.hypot(dx, dy, 1); const i = (y * S + x) * 4; d[i] = (dx / l * 0.5 + 0.5) * 255; d[i + 1] = (dy / l * 0.5 + 0.5) * 255; d[i + 2] = H[y * S + x] * 255; d[i + 3] = 255; }
    return mkTex(d, S, { aniso: 8 });
  }
  async function genSoil(S) {
    const H = new Float32Array(S * S);
    for (let y = 0; y < S; y++) { for (let x = 0; x < S; x++) { const u = x / S, v = y / S;
      const a = pfbm(u, v, 5, 4, 700), b = pfbm(u, v, 18, 3, 710), c = pval(u * 64, v * 64, 64, 720), d = pval(u * 128, v * 128, 128, 730), e = pval(u * 40, v * 160, 40, 740);
      const w = pworley(u, v, 23, 750);
      H[y * S + x] = 0.30 * a + 0.22 * b + 0.14 * c + 0.10 * d + 0.12 * e + 0.12 * clamp(w[0] * 1.2, 0, 1); } if ((y & 31) === 31) await slice(); }
    const d = new Uint8ClampedArray(S * S * 4); const at = (x, y) => H[(((y % S) + S) % S) * S + (((x % S) + S) % S)];
    for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) { const dx = (at(x - 1, y) - at(x + 1, y)) * 5.0, dy = (at(x, y - 1) - at(x, y + 1)) * 5.0; const l = Math.hypot(dx, dy, 1); const i = (y * S + x) * 4;
      const avg = (at(x - 2, y) + at(x + 2, y) + at(x, y - 2) + at(x, y + 2)) / 4; d[i] = (dx / l * 0.5 + 0.5) * 255; d[i + 1] = (dy / l * 0.5 + 0.5) * 255; d[i + 2] = clamp((H[y * S + x] - 0.2) * 1.6, 0, 1) * 255; d[i + 3] = clamp(0.55 + (H[y * S + x] - avg) * 6, 0, 1) * 255; }
    return mkTex(d, S, { aniso: 8 });
  }
  DW.tex = { hv, pval, pfbm, pworley, genDetail, genNoise, genCloud, genWater, mkTex, slice };
  DW.makeTextures = async function (q) {
    const S = (q && q.texSize) || 256; const T = {};
    T.detail = await genDetail(S); T.noise = await genNoise(S); T.cloud = await genCloud(Math.min(256, S)); T.water = await genWater(Math.min(256, S)); T.soil = await genSoil(S);
    DW.T = T; if (DW.U) { DW.U.tDetail.value = T.detail; DW.U.tNoise.value = T.noise; DW.U.tCloud.value = T.cloud; DW.U.tWater.value = T.water; DW.U.tSoil.value = T.soil; } return T;
  };
}
