/* مشاور: بلوک سرویس‌ها در بالای صفحه‌ی مشاور؛ فهرست پروفایل‌ها (نام، نوع، کلید، فعال‌سازی، ویرایش، حذف) و یک فرم برای ویرایش یا افزودن (نوع، نام، نشانی، کلید، مدل، تست). کلیدها فقط از راه App.keys ذخیره می‌شوند. */
(function () {
  'use strict';
  var App = (window.App = window.App || {});
  var u = App.u;
  var store = App.store;
  var ai = App.ai;
  var keys = App.keys;
  var P = App.providers;
  var TYPE_LABEL = { claude: 'Claude (Anthropic)', gemini: 'Gemini (Google)', openai: 'OpenAI یا سازگار با OpenAI' };
  var TYPE_SHORT = { claude: 'Claude', gemini: 'Gemini', openai: 'OpenAI یا سازگار' };
  var DEFAULT_NAMES = ['Claude', 'Gemini', 'OpenAI', 'OpenRouter', 'DeepSeek', 'سرویس سفارشی', 'سرویس سازگار', ''];
  var GEMINI_LIST = ['gemini-2.5-flash', 'gemini-2.5-pro', 'gemini-2.0-flash'];
  var HINT = 'کلید را از سایت همین سرویس بگیر و اینجا بچسبان (مثلاً console.anthropic.com برای Claude).';
  // وضعیت صفحه فقط در حافظه است؛ کلید تایپ‌شده هرگز در S نمی‌رود
  var aiUi = { open: null, sel: null, loaded: '', models: null, msg: '', kind: '', test: '', testBad: false };

  function pf() { return App.form('pf', {}); }
  function say(text, kind) { aiUi.msg = text || ''; aiUi.kind = kind || ''; }
  function activeId() { var a = ai.active(); return a ? String(a.id) : ''; }
  function selProfile() { return aiUi.sel && aiUi.sel.mode !== 'new' ? ai.profileById(aiUi.sel.id) : null; }
  function presetBase(k) { var x = P.presets.filter(function (p) { return p.key === k; })[0]; return x ? x.base : ''; }
  // مدل خالی یا یکی از مدل‌های پیش‌فرض برنامه: وقتی سرویس عوض می‌شود پاک می‌شود؛ مدلی که خودت نوشته‌ای دست نمی‌خورد
  function autoModel(m) {
    return !m || P.presets.some(function (x) { return x.model === m; }) || (App.MODELS || []).indexOf(m) >= 0 || GEMINI_LIST.indexOf(m) >= 0;
  }
  function defaultName(type, base) {
    if (type === 'claude') return 'Claude';
    if (type === 'gemini') return 'Gemini';
    var k = P.presetOf(base);
    var x = P.presets.filter(function (p) { return p.key === k; })[0];
    return x && x.name ? x.name : 'سرویس سفارشی';
  }
  // مقدارهای فرم از پروفایل انتخاب‌شده، یا از حالت «افزودن»
  function loadValues() {
    var p = selProfile();
    if (!p) {
      var t = aiUi.presetType || 'claude', nb = t === 'openai' ? presetBase('openai') : '';
      return { type: t, preset: t === 'openai' ? 'openai' : '', name: defaultName(t, nb), base: nb, model: '', key: '' };
    }
    return {
      type: p.type, preset: p.type === 'openai' ? P.presetOf(p.base) : '', name: p.name, base: p.base || '',
      model: p.model || '', key: ''
    };
  }
  // انتخاب فعلی و فرم را هماهنگ می‌کند؛ با تغییر انتخاب، فرم از پروفایل تازه پر می‌شود
  function syncForm() {
    if (!aiUi.sel || (aiUi.sel.mode !== 'new' && !ai.profileById(aiUi.sel.id))) aiUi.sel = { mode: 'edit', id: activeId() };
    var k = aiUi.sel.mode === 'new' ? 'new' : String(aiUi.sel.id);
    if (aiUi.loaded !== k) {
      aiUi.loaded = k; aiUi.models = null; aiUi.test = ''; aiUi.testBad = false;
      App.resetForm('pf', loadValues());
    }
    return pf();
  }
  // خطای فرم پیش از ذخیره؛ '' یعنی آماده
  function formError(f) {
    if (f.type === 'openai' && !String(f.base || '').trim()) return 'آدرس سرویس را وارد کن (مثلاً https://api.openai.com/v1).';
    if (String(f.base || '').trim() && !store.cleanUrl(f.base)) return 'آدرس باید با https شروع شود و فاصله نداشته باشد.';
    return '';
  }
  // ذخیره‌ی پروفایل از فرم: به‌روزرسانی یا افزودن؛ پروفایل یا null
  function saveFromForm(f) {
    var o = { name: String(f.name || '').trim() || defaultName(f.type, f.base), base: store.cleanUrl(f.base) || '', model: String(f.model || '').trim() };
    var sel = selProfile();
    if (sel) return ai.updateProfile(sel.id, o);
    var p = ai.addProfile(f.type, o);
    if (p) aiUi.sel = { mode: 'edit', id: p.id };
    return p;
  }

  // ---- فهرست مدل‌ها ----
  // فهرست از سرویس؛ اگر مدل فرم خالی بود، اولین مدل انتخاب و برای پروفایل ذخیره می‌شود
  function fetchModels(p, saved) {
    say('در حال گرفتن فهرست مدل‌ها…');
    App.render();
    return ai.listModels(p).then(function (r) {
      var pre = saved ? '✅ کلید ذخیره شد. ' : '';
      if (!r.ok) say((saved ? 'کلید ذخیره شد، اما فهرست گرفته نشد: ' : '') + r.error, 'bad');
      else if (!r.models.length) { aiUi.models = null; say(pre + 'فهرستی برنگشت؛ مدل را دستی نگه دار یا دوباره امتحان کن.'); }
      else {
        aiUi.models = r.models;
        // مدل را خودت انتخاب یا می‌نویسی؛ برنامه چیزی را به‌جای تو انتخاب نمی‌کند
        say(pre + u.fa(r.models.length) + ' مدل پیدا شد؛ یکی را انتخاب کن.', 'ok');
      }
      App.render();
    });
  }
  // کادر متنی: نام مدل را می‌شود نوشت؛ فهرست گرفته‌شده فقط پیشنهاد است
  function modelField(f) {
    var cur = f.model || '';
    var base = aiUi.models || (f.type === 'claude' ? (App.MODELS || []) : f.type === 'gemini' ? GEMINI_LIST : []);
    var opts = base.map(function (m) { return '<option value="' + u.esc(m) + '">' + u.esc(m) + '</option>'; }).join('');
    return '<div class="field"><label for="set-model">مدل <span class="mu">(از فهرست انتخاب کن یا نام دقیقش را خودت بنویس)</span></label>' +
      '<input id="set-model" type="text" dir="ltr" list="set-model-list" autocomplete="off" spellcheck="false" data-f="pf.model" placeholder="نام دقیق مدل" value="' + u.esc(cur) + '">' +
      '<datalist id="set-model-list">' + opts + '</datalist></div>';
  }

  // ---- فرم ----
  function msgLine(id, text, kind) { return '<p class="mu ai-msg ' + (kind || '') + '" id="' + id + '" role="status">' + u.esc(text || '') + '</p>'; }
  function formHtml(f) {
    var sel = selProfile(), isNew = !sel;
    var saved = !!sel && keys.has(sel.id);
    var openai = f.type === 'openai';
    var typeOpts = [['claude', TYPE_LABEL.claude], ['gemini', TYPE_LABEL.gemini], ['openai', TYPE_LABEL.openai]];
    var h = '<h3 class="pf-title">' + (isNew ? '＋ سرویس تازه' : 'ویرایش: ' + u.esc(sel.name)) + '</h3>';
    h += '<div class="field"><label for="pf-type">نوع سرویس</label><select id="pf-type" data-f="pf.type" data-rr="1" data-act-change="pf-type-change"' + (isNew ? '' : ' disabled') + '>' + App.opts(typeOpts, f.type) + '</select></div>';
    if (openai) {
      h += '<div class="field"><label for="pf-preset">سرویس آماده</label><select id="pf-preset" data-f="pf.preset" data-rr="1" data-act-change="pf-preset-change">' +
        App.opts(P.presets.map(function (x) { return [x.key, x.name]; }), f.preset) + '</select></div>';
    }
    h += '<div class="field"><label for="pf-name">نام</label><input id="pf-name" type="text" maxlength="30" autocomplete="off" data-f="pf.name" value="' + u.esc(f.name || '') + '"></div>';
    h += '<div class="field"><label for="pf-base">' + (openai ? 'آدرس سرویس (الزامی)' : 'آدرس سفارشی (اختیاری)') + '</label><input id="pf-base" type="text" dir="ltr" inputmode="url" autocomplete="off" spellcheck="false" data-f="pf.base" placeholder="https://..." value="' + u.esc(f.base || '') + '"></div>';
    h += '<div class="field"><label for="set-key">کلید API</label><input id="set-key" type="password" dir="ltr" autocomplete="off" spellcheck="false" data-f="pf.key" placeholder="' + (saved ? 'کلید ذخیره شده؛ برای عوض کردن، تازه بچسبان' : 'کلید را اینجا بچسبان') + '" value="' + u.esc(f.key || '') + '"></div>';
    h += saved ? '<p class="mu">کلید ذخیره شده: <span dir="ltr">••••' + u.esc(keys.get(sel.id).slice(-4)) + '</span></p>' : '<p class="mu">' + HINT + '</p>';
    h += '<div class="row0 wrap ai-btns">' + App.btn('ذخیره‌ی کلید', 'set-key-save', null, 'accent') + App.btn('دریافت لیست مدل‌ها', 'ai-fetch-models', null, 'muted') +
      (saved ? App.btn('پاک‌کردن کلید', 'set-key-clear', null, 'danger') : '') + '</div>';
    h += modelField(f);
    h += '<div class="row0 wrap ai-btns">' + App.btn('🔌 تست اتصال', 'set-test', null, 'accent2') + '</div>';
    h += msgLine('set-test-out', aiUi.test, aiUi.testBad ? 'bad' : 'ok');
    h += '<div class="row0 wrap ai-btns">' + App.btn(isNew ? 'افزودن سرویس' : 'ذخیره', 'pf-save', null, 'accent') +
      (isNew ? App.btn('انصراف', 'pf-cancel', null, 'muted') : '') + '</div>';
    h += msgLine('set-status', aiUi.msg, aiUi.kind);
    return h;
  }

  // ---- فهرست و خلاصه ----
  function rowHtml(p) {
    var on = String(p.id) === activeId();
    var has = keys.has(p.id);
    var only = ai.profiles().length <= 1;
    return '<li class="pf-row' + (on ? ' on' : '') + '"><div class="pf-info"><b>' + u.esc(p.name) + '</b>' +
      '<span class="mu">' + u.esc(TYPE_SHORT[p.type] || p.type) + ' · ' + (has ? 'کلید دارد' : 'کلید ندارد') + '</span></div>' +
      '<div class="pf-btns">' + (on ? '<span class="pill">فعال ✓</span>' : App.sm('فعال کن', 'pf-act', { key: p.id }, '')) +
      App.sm('ویرایش', 'pf-edit', { key: p.id }, '') +
      '<button type="button" class="sm danger" data-act="pf-del" data-key="' + u.esc(p.id) + '"' + (only ? ' disabled title="آخرین سرویس را نمی‌شود پاک کرد"' : '') + '>حذف</button></div></li>';
  }
  function headHtml(c) {
    return '<span class="ai-dot' + (c.key ? '' : ' bad') + '" aria-hidden="true"></span><span class="ai-sum-text">🤖 مشاور: <b>' + u.esc(c.name) + '</b> · <span class="ai-model" dir="ltr">' + u.esc(c.model || '—') + '</span>' +
      (aiUi.testBad ? ' · خطا ⚠️' : '') + '</span>';
  }
  // بلوک بالای صفحه: بسته وقتی کلید فعال ذخیره است، باز وقتی نیست
  function profileBlock() {
    var f = syncForm();
    var c = ai.config();
    // اگر گفتگو شروع شده، تنظیمات بسته می‌ماند تا پیام‌ها دیده شوند؛ کاربر با یک لمس بازش می‌کند
    var chatStarted = (App.S.chat || []).length > 0;
    var open = aiUi.open != null ? aiUi.open : (!c.key && !chatStarted);
    return '<details class="card ai-setup" id="ai-setup"' + (open ? ' open' : '') + '><summary>' + headHtml(c) + '</summary><div class="cbody">' +
      '<ul class="pf-list" aria-label="سرویس‌های مشاور">' + ai.profiles().map(rowHtml).join('') + '</ul>' +
      '<div class="pf-add">' + App.sm('＋ Claude', 'pf-new-type', { key: 'claude' }, '') + App.sm('＋ Gemini', 'pf-new-type', { key: 'gemini' }, '') + App.sm('＋ OpenAI یا سازگار', 'pf-new-type', { key: 'openai' }, '') + '</div>' +
      '<div class="pf-panel">' + formHtml(f) + '</div></div></details>';
  }
  App.views.ai = function () {
    return App.upgradeNotice() + profileBlock() + '<section class="card" id="chat-page">' + App.views.chatPanel({}) + '</section>';
  };

  // ---- کنش‌های فهرست ----
  App.act['pf-new'] = function () {
    aiUi.presetType = null; aiUi.open = true; aiUi.sel = { mode: 'new' }; aiUi.loaded = ''; say(''); App.render();
    var el = document.getElementById('pf-name');
    if (el) el.focus();
  };
  // هر دکمه‌ی افزودن فرم را از نو با نوع خودش پر می‌کند، حتی اگر فرم تازه از قبل باز باشد
  // دکمه‌ی مدل زیر گفتگو: تنظیمات مشاور را باز می‌کند تا مدل یا سرویس عوض شود
  App.act['ai-open-setup'] = function () {
    aiUi.open = true; App.render();
    var el = document.getElementById('ai-setup');
    if (el && el.scrollIntoView) el.scrollIntoView({ block: 'start' });
  };
  App.act['pf-new-type'] = function (el) {
    aiUi.presetType = el.getAttribute('data-key') || 'claude'; aiUi.open = true;
    aiUi.sel = { mode: 'new' }; aiUi.loaded = ''; say(''); App.render();
  };
  App.act['pf-edit'] = function (el) {
    var p = ai.profileById(el.getAttribute('data-key'));
    if (!p) return;
    aiUi.sel = { mode: 'edit', id: p.id }; say(''); App.render();
  };
  App.act['pf-cancel'] = function () { aiUi.sel = { mode: 'edit', id: activeId() }; say(''); App.render(); };
  App.act['pf-act'] = function (el) {
    if (!ai.activate(el.getAttribute('data-key'))) return;
    aiUi.testBad = false;
    say('✅ سرویس فعال شد.', 'ok'); App.render();
  };
  App.act['pf-del'] = function (el) {
    var id = el.getAttribute('data-key'), p = ai.profileById(id);
    if (!p) return;
    if (!App.confirm('سرویس «' + p.name + '» و کلیدش از این دستگاه پاک شود؟')) return;
    if (!ai.removeProfile(id)) { say('آخرین سرویس را نمی‌شود پاک کرد.', 'bad'); App.render(); return; }
    if (aiUi.sel && String(aiUi.sel.id) === String(id)) aiUi.sel = null;
    aiUi.testBad = false;
    say('سرویس و کلیدش پاک شد.'); App.render();
  };
  App.act['pf-save'] = function () {
    var f = pf(), err = formError(f);
    if (err) { say(err, 'bad'); App.render(); return; }
    var p = saveFromForm(f);
    if (!p) { say('سرویس ذخیره نشد. شاید حد مجاز سرویس‌ها پر است.', 'bad'); App.render(); return; }
    aiUi.open = true;
    say(keys.has(p.id) ? '✅ سرویس ذخیره شد.' : 'سرویس ذخیره شد. حالا کلیدش را بچسبان و «ذخیره‌ی کلید» را بزن.', keys.has(p.id) ? 'ok' : '');
    App.render();
  };

  // ---- کنش‌های کلید، مدل و تست ----
  App.act['set-key-save'] = function () {
    var f = pf(), typed = String(f.key || '').trim(), err = formError(f);
    if (!typed) err = err || 'کلید را وارد کن.';
    else if (f.type === 'claude' && !/^sk-ant-/.test(typed)) err = 'کلید Anthropic باید با sk-ant- شروع شود.';
    if (err) { say(err, 'bad'); App.render(); return; }
    var p = saveFromForm(f);
    if (!p || !keys.set(p.id, typed) || keys.get(p.id) !== typed) { say('ذخیره‌ی کلید در این مرورگر ممکن نیست.', 'bad'); App.render(); return; }
    f.key = '';
    aiUi.open = true; aiUi.testBad = false; aiUi.test = '';
    fetchModels({ type: p.type, base: p.base, key: typed }, true);
  };
  App.act['ai-fetch-models'] = function () {
    var f = pf(), sp = selProfile();
    var key = String(f.key || '').trim() || (sp ? keys.get(sp.id) : '');
    var err = formError(f) || (key ? '' : 'اول کلید را وارد کن.');
    if (err) { say(err, 'bad'); App.render(); return; }
    fetchModels({ type: f.type, base: store.cleanUrl(f.base) || '', key: key }, false);
  };
  App.act['set-key-clear'] = function () {
    var sp = selProfile();
    if (!sp) return;
    if (!App.confirm('کلید «' + sp.name + '» از این دستگاه پاک شود؟')) return;
    keys.set(sp.id, '');
    pf().key = '';
    aiUi.open = null; aiUi.testBad = false; aiUi.test = '';
    say('کلید از این دستگاه پاک شد.'); App.render();
  };
  App.act['set-test'] = function () {
    var f = pf(), sp = selProfile();
    var key = String(f.key || '').trim() || (sp ? keys.get(sp.id) : '');
    var err = formError(f) || (key ? '' : 'کلید ذخیره نشده است؛ اول کلید را بچسبان و ذخیره کن.') || (f.model ? '' : 'اول مدل را انتخاب کن (با «دریافت لیست مدل‌ها»).');
    if (err) { aiUi.test = err; aiUi.testBad = true; App.render(); return; }
    aiUi.test = 'در حال تست…'; aiUi.testBad = false; App.render();
    ai.test({ name: f.name || 'سرویس', type: f.type, base: store.cleanUrl(f.base) || '', key: key, model: f.model }).then(function (r) {
      aiUi.test = r.ok ? '✅ وصل شد: ' + r.text : '⚠️ ' + r.error;
      aiUi.testBad = !r.ok;
      App.render();
    });
  };
  // نوع یا پیش‌تنظیم عوض شد: نشانی، مدل و نام پیش‌فرض همان سرویس می‌آیند
  App.act['pf-type-change'] = function () {
    var f = pf(), t = f.type;
    if (t === 'openai') { f.preset = 'openai'; f.base = presetBase('openai'); }
    else if (P.presetOf(f.base) !== 'custom' || !f.base) f.base = '';
    if (autoModel(f.model)) f.model = '';
    if (DEFAULT_NAMES.indexOf(f.name) >= 0) f.name = defaultName(t, f.base);
    aiUi.models = null;
    App.render();
  };
  App.act['pf-preset-change'] = function () {
    var f = pf();
    if (f.preset !== 'custom') f.base = presetBase(f.preset);
    else if (P.presetOf(f.base) !== 'custom') f.base = '';
    if (autoModel(f.model)) f.model = '';
    if (DEFAULT_NAMES.indexOf(f.name) >= 0) f.name = defaultName('openai', f.base);
    aiUi.models = null;
    App.render();
  };
  // انتخاب مدل همان لحظه برای پروفایل ذخیره‌شده ثبت می‌شود؛ برای پروفایل تازه با «افزودن سرویس»
  document.addEventListener('change', function (e) {
    var el = e.target;
    if (!el || el.id !== 'set-model') return;
    var m = String(el.value || '').trim(), sp = selProfile();
    if (!m) say('اول یک مدل را انتخاب کن.', 'bad');
    else if (!ai.isModelId(m)) say('این نام مدل درست نیست.', 'bad');
    else if (sp) { ai.setModel(sp.id, m); say('✔ مدل «' + m + '» ذخیره شد.', 'ok'); }
    else say('مدل «' + m + '» انتخاب شد؛ با «افزودن سرویس» ذخیره می‌شود.', 'ok');
    App.render();
  }, false);
  // بازبودن بلوک را نگه می‌داریم تا رندر آن را نبندد
  document.addEventListener('toggle', function (e) {
    if (e.target && e.target.id === 'ai-setup') aiUi.open = e.target.open;
  }, true);
})();
