import { PARAMS, PARAM_MAP, PROPS, isValidParamId, MOUTH_PACK, setCustomParams, getCustomParams } from './params.js';
import { Rig, clamp, loadImage, BLENDS, OSC_PROPS, evalCurve } from './rig.js';
import { generateMesh, addVertex, removeVertex, retriangulate, dragMesh, ensureMeshKey, deleteMeshKey, resetMeshTarget } from './mesh.js';
import { buildDemo } from './demo.js';
import { Tracker, DEFAULT_SETTINGS } from './tracker.js';
import { createWarp, normalizeWarp, dragNode, ensureForm, ensureKey, deleteKey, resetTarget } from './warp.js';
import { EASES, newAnimation, normalizeAnim, evalTrack, sampleAnim, setKey, removeKey, moveKey, closeLoop, applyRecording } from './anim.js';

// ───────────────────────── utilidades ─────────────────────────
const $ = s => document.querySelector(s);
const h = (tag, attrs = {}, ...kids) => {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'class') e.className = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (v === true) e.setAttribute(k, '');
    else if (v !== false && v != null) e.setAttribute(k, v);
  }
  for (const c of kids.flat()) if (c != null && c !== false) e.append(c.nodeType ? c : document.createTextNode(c));
  return e;
};
const fmt = v => (Math.abs(v) >= 100 ? v.toFixed(0) : v.toFixed(2));
let toastTimer;
function toast(msg, ms = 3200) {
  const t = $('#toast'); t.textContent = msg; t.hidden = false;
  clearTimeout(toastTimer); toastTimer = setTimeout(() => (t.hidden = true), ms);
}

// persistência (IndexedDB) – guarda o projeto automaticamente
const idb = {
  _db: null,
  open() {
    return this._db || (this._db = new Promise((res, rej) => {
      const r = indexedDB.open('vtuber-rigger', 1);
      r.onupgradeneeded = () => r.result.createObjectStore('kv');
      r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
    }));
  },
  async get(k) { try { const db = await this.open(); return await new Promise(res => { const q = db.transaction('kv').objectStore('kv').get(k); q.onsuccess = () => res(q.result); q.onerror = () => res(null); }); } catch { return null; } },
  async set(k, v) { try { const db = await this.open(); db.transaction('kv', 'readwrite').objectStore('kv').put(v, k); } catch { /* ignora */ } },
};

// ───────────────────────── estado ─────────────────────────
const rig = new Rig();
const settings = { ...DEFAULT_SETTINGS };
try { Object.assign(settings, JSON.parse(localStorage.getItem('vr-settings') || '{}')); } catch { /* ok */ }
const saveSettings = () => { try { localStorage.setItem('vr-settings', JSON.stringify(settings)); } catch { /* ok */ } };

const state = {
  tab: 'layers', selected: null, tool: 'move', bg: 0,
  manual: Object.fromEntries(PARAMS.map(p => [p.id, p.def])),
  auto: { blink: true, breath: true, hair: true },
  sim: false,
  warp: { target: 'rest', radius: 1.2, sym: false, wire: false, node: -1, cols: 4, rows: 4, mode: 'grid',
    mesh: { tool: 'move', radius: 60, density: 12, node: -1, show: true } },
  anim: { cur: null, time: 0, playing: false, speed: 1, autoKey: false, sel: null, rec: null, zoom: 0,
    addParam: 'AngleX', once: false, exporting: null, draw: null, ui: null },
};
const BGS = [
  { name: 'Escuro', css: '#0d0b16' }, { name: 'Verde', css: '#00b140' },
  { name: 'Branco', css: '#ffffff' }, { name: 'Xadrez', css: 'checker' }, { name: 'Transparente', css: null },
];

const cv = $('#cv'), ctx = cv.getContext('2d');
const video = $('#cam');
const tracker = new Tracker(video, settings);
tracker.onStatus = s => { state.trackStatus = s; if (state.tab === 'track') renderTab(); };

// ── histórico (desfazer/refazer) ──
const hist = { undo: [], redo: [], last: null, lastStr: '' };
const snapStr = s => JSON.stringify(s, (k, v) => (k === 'src' ? undefined : v));
function resetHistory() { hist.undo = []; hist.redo = []; hist.last = rig.snapshot(); hist.lastStr = snapStr(hist.last); }
function commit() {
  const s = rig.snapshot(), str = snapStr(s);
  if (str === hist.lastStr) return;
  hist.undo.push(hist.last); if (hist.undo.length > 100) hist.undo.shift();
  hist.redo = []; hist.last = s; hist.lastStr = str;
}
function applyHistory(from, to) {
  if (!from.length) return toast(from === hist.undo ? 'Nada para desfazer' : 'Nada para refazer', 900);
  to.push(hist.last); hist.last = from.pop(); hist.lastStr = snapStr(hist.last);
  rig.restore(hist.last);
  if (state.selected && !rig.byId(state.selected)) state.selected = null;
  state.warp.node = -1; state.warp.mesh.node = -1; state.anim.sel = null; syncManual();
  clearTimeout(dirtyTimer); dirtyTimer = setTimeout(() => idb.set('project', JSON.stringify(rig.toJSON())), 700);
  renderTab();
}
const undo = () => applyHistory(hist.undo, hist.redo);
const redo = () => applyHistory(hist.redo, hist.undo);

let dirtyTimer;
function markDirty() {
  commit();
  clearTimeout(dirtyTimer);
  dirtyTimer = setTimeout(() => idb.set('project', JSON.stringify(rig.toJSON())), 700);
}

function syncManual() {
  for (const p of PARAMS) if (!(p.id in state.manual)) state.manual[p.id] = p.def;
  for (const k of Object.keys(state.manual)) if (!PARAM_MAP[k]) delete state.manual[k];
  rig.syncValues();
}
function setParams(list) { setCustomParams(list); syncManual(); }
/** Remove todas as referências a um parâmetro apagado. */
function purgeParam(id) {
  for (const l of rig.layers) {
    l.bindings = l.bindings.filter(b => b.param !== id);
    if (l.warp) l.warp.forms = l.warp.forms.filter(f => f.param !== id);
    if (l.mesh) l.mesh.forms = l.mesh.forms.filter(f => f.param !== id);
  }
  for (const a of rig.animations) delete a.tracks[id];
  rig.physics = rig.physics.filter(p => p.input !== id && p.output !== id);
  for (const e of rig.expressions) delete e.values[id];
  if (state.warp.target === id) state.warp.target = 'rest';
  if (state.anim.addParam === id) state.anim.addParam = 'AngleX';
}

// ───────────────────────── canvas / render ─────────────────────────
let view = new DOMMatrix(), dpr = 1;
function resize() {
  dpr = Math.min(window.devicePixelRatio || 1, 2);
  const r = cv.getBoundingClientRect();
  cv.width = Math.max(1, Math.round(r.width * dpr)); cv.height = Math.max(1, Math.round(r.height * dpr));
  const pad = 12 * dpr;
  const s = Math.min((cv.width - pad * 2) / rig.w, (cv.height - pad * 2) / rig.h);
  view = new DOMMatrix().translate((cv.width - rig.w * s) / 2, (cv.height - rig.h * s) / 2).scale(s);
}
new ResizeObserver(resize).observe(cv);

function drawBackground() {
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  const bg = BGS[state.bg];
  ctx.clearRect(0, 0, cv.width, cv.height);
  if (bg.css === 'checker') {
    const s = 16 * dpr;
    for (let y = 0; y < cv.height; y += s) for (let x = 0; x < cv.width; x += s) {
      ctx.fillStyle = ((x / s + y / s) & 1) ? '#2a2540' : '#1d1930'; ctx.fillRect(x, y, s, s);
    }
  } else if (bg.css) { ctx.fillStyle = bg.css; ctx.fillRect(0, 0, cv.width, cv.height); }
  // moldura do rig (só em edição)
  if (!document.body.classList.contains('stage-only')) {
    ctx.strokeStyle = '#ffffff22'; ctx.lineWidth = 1;
    const a = view.transformPoint({ x: 0, y: 0 }), b = view.transformPoint({ x: rig.w, y: rig.h });
    ctx.strokeRect(a.x, a.y, b.x - a.x, b.y - a.y);
  }
}

// ───────────────────────── simulação de rastreio (teste sem câmera) ─────────────────────────
function simOut(t) {
  const s = t / 1000;
  const blink = (Math.sin(s * 1.3) > 0.985 || Math.sin(s * 0.7 + 2) > 0.992) ? 0 : 1;
  const ax = Math.sin(s * 0.9) * 22;
  return {
    AngleX: ax, AngleY: Math.sin(s * 0.7) * 12, AngleZ: Math.sin(s * 0.6 + 1) * 14,
    EyeLOpen: blink, EyeROpen: blink,
    EyeBallX: Math.sin(s * 1.3), EyeBallY: Math.sin(s * 0.9) * 0.6,
    BrowLY: Math.sin(s * 0.8) * 0.8, BrowRY: Math.sin(s * 0.8) * 0.8,
    MouthOpen: clamp(Math.sin(s * 5) * 0.5 + 0.35, 0, 1) * (Math.sin(s * 0.5) > 0 ? 1 : 0.1),
    MouthForm: Math.sin(s * 0.4), Cheek: clamp(Math.sin(s * 0.4), 0, 1), BodyX: ax / 3,
  };
}

// ───────────────────────── animação: reprodução, auto-chave, gravação, exportação ─────────────────────────
function curAnim() {
  const A = state.anim;
  let an = rig.animations.find(a => a.id === A.cur);
  if (!an && rig.animations.length) { an = rig.animations[0]; A.cur = an.id; }
  return an || null;
}
function resetAnimState() {
  Object.assign(state.anim, { cur: rig.animations[0]?.id ?? null, time: 0, playing: false, sel: null, rec: null, once: false });
}
let lazyT;
function markDirtyLazy() { clearTimeout(lazyT); lazyT = setTimeout(markDirty, 400); }
function setTime(t, pause = true) {
  const A = state.anim, an = curAnim();
  if (!an) return;
  A.time = clamp(t, 0, an.duration);
  if (pause) A.playing = false;
}

/** Chamado quando o usuário mexe num parâmetro (slider/joystick): com Auto-chave, grava a chave no tempo atual. */
function onParamEdited(id, v, prev) {
  const A = state.anim, an = curAnim();
  if (!A.autoKey || !an || A.playing) return;
  if (!an.tracks[id] && A.time > 0.0005) setKey(an, id, 0, prev ?? PARAM_MAP[id].def);   // âncora no início
  setKey(an, id, A.time, v);
  markDirtyLazy();
}

function stepAnimation(V, tracked, dt, now) {
  const A = state.anim, an = curAnim(), set = new Set();
  if (A.rec) recordSample(tracked, now);
  if (!an) return set;
  if (A.playing) {
    A.time += dt * A.speed;
    if (A.time >= an.duration) {
      if (A.once) { A.time = an.duration; A.playing = false; finishExport(); }
      else if (an.loop) A.time %= an.duration;
      else { A.time = an.duration; A.playing = false; }
    }
  }
  if (A.playing || state.tab === 'anim') {
    for (const [k, v] of Object.entries(sampleAnim(an, A.time))) {
      if (tracked && k in tracked) continue;          // o rastreio ao vivo tem prioridade
      V[k] = v; set.add(k);
    }
  }
  return set;
}

function syncAnimUI() {
  const A = state.anim, an = curAnim();
  if (state.tab !== 'anim' || !an) return;
  A.draw?.();
  if (A.ui) {
    A.ui.playBtn.textContent = A.playing ? '⏸' : '▶';
    A.ui.timeEl.textContent = `${A.time.toFixed(2)} / ${an.duration.toFixed(2)} s`;
    if (document.activeElement !== A.ui.scrub) A.ui.scrub.value = A.time;
  }
}

function recordSample(tracked, now) {
  const R = state.anim.rec;
  if (!tracked) return;
  if (R.t0 == null) R.t0 = now;
  const t = (now - R.t0) / 1000;
  if (t - R.lastT < 1 / 30 && R.lastT > 0) return;
  R.lastT = t; R.len = t;
  for (const p of PARAMS) if (p.id in tracked) (R.data[p.id] ||= []).push({ t, v: tracked[p.id] });
}
function startRecording() {
  if (!curAnim()) return;
  if (!(tracker.active || state.sim)) return toast('Ligue o rastreio (ou a simulação) para gravar.', 3500);
  state.anim.playing = false;
  state.anim.rec = { t0: null, lastT: 0, len: 0, data: {} };
  renderTab();
}
function stopRecording() {
  const A = state.anim, R = A.rec, an = curAnim();
  A.rec = null;
  if (R && an && R.len > 0.3) {
    const n = applyRecording(an, R.data, R.len);
    A.time = 0; A.sel = null; markDirty();
    toast(`Gravação convertida em ${n} chaves (${an.duration.toFixed(1)} s).`);
  } else toast('Gravação muito curta.');
  renderTab();
}

function exportVideo() {
  const A = state.anim, an = curAnim();
  if (!an) return;
  const mime = typeof MediaRecorder !== 'undefined' && cv.captureStream &&
    ['video/webm;codecs=vp9', 'video/webm;codecs=vp8', 'video/webm'].find(m => MediaRecorder.isTypeSupported(m));
  if (!mime) return toast('Este navegador não suporta exportar vídeo.', 5000);
  const chunks = [], rec = new MediaRecorder(cv.captureStream(an.fps), { mimeType: mime, videoBitsPerSecond: 8e6 });
  rec.ondataavailable = e => { if (e.data.size) chunks.push(e.data); };
  rec.onstop = () => {
    const blob = new Blob(chunks, { type: 'video/webm' });
    const a = h('a', { href: URL.createObjectURL(blob), download: (an.name || 'animacao').replace(/\W+/g, '_') + '.webm' });
    document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000);
    A.exporting = null; window.__vr && (window.__vr.lastExport = blob.size);
    toast(`Vídeo exportado (${Math.round(blob.size / 1024)} KB, WebM). Fundo “Transparente” sai preto no WebM.`, 5000);
    renderTab();
  };
  A.exporting = rec; A.once = true; A.time = 0; A.playing = true;
  rec.start(); toast('Gravando o vídeo…', 1500); renderTab();
}
function finishExport() {
  const A = state.anim, r = A.exporting;
  A.once = false;
  if (r && r.state !== 'inactive') setTimeout(() => r.stop(), 200);
}

// ───────────────────────── loop principal ─────────────────────────
let last = performance.now(), hair = { a: 0, v: 0 }, prevAx = 0, blinkT = 0, nextBlink = 2500;
const hud = $('#hud');
function frame(now) {
  const dt = Math.min(0.05, (now - last) / 1000); last = now;
  const tracked = tracker.active ? tracker.out : (state.sim ? simOut(now) : null);

  const V = rig.values;
  syncManual();
  for (const p of PARAMS) V[p.id] = tracked && p.id in tracked ? tracked[p.id] : state.manual[p.id];

  const animSet = stepAnimation(V, tracked, dt, now);
  const editingForms = state.tab === 'warp';           // ao esculpir keyforms, não deixa o automático mexer nos valores
  if (state.auto.breath && !editingForms && !animSet.has('Breath')) V.Breath = (Math.sin(now / 1000 * 1.7) + 1) / 2;
  if (state.auto.blink && !tracked && !animSet.has('EyeLOpen') && !animSet.has('EyeROpen')) {          // piscar automático
    nextBlink -= dt * 1000;
    if (nextBlink <= 0) { blinkT = 0.16; nextBlink = 2000 + Math.random() * 3500; }
    if (blinkT > 0) { blinkT -= dt; const k = Math.abs(blinkT / 0.16 - 0.5) * 2; V.EyeLOpen *= k; V.EyeROpen *= k; }
  }
  if (state.auto.hair && !editingForms && !animSet.has('HairSway')) {                        // mola simples para o cabelo
    const vel = (V.AngleX - prevAx) / Math.max(dt, 1e-3) / 30;
    hair.v += (-70 * hair.a - 7 * hair.v - 16 * vel + (-V.AngleZ / 30) * 8 * 0) * dt;
    hair.a = clamp(hair.a + hair.v * dt, -1, 1);
    V.HairSway = hair.a;
  }
  prevAx = V.AngleX;
  rig.tick(dt);                                           // física (molas) + expressões

  drawBackground();
  const editUI = !document.body.classList.contains('stage-only');
  rig.wireLayer = editUI && state.tab === 'warp' && state.warp.wire ? state.selected : null;
  rig.render(ctx, view, { selected: state.selected, overlay: editUI && ['layers', 'rig'].includes(state.tab) });
  if (editUI && state.tab === 'warp' && state.selected) {
    const l = rig.byId(state.selected);
    if (l?.mesh && state.warp.mode === 'mesh') { if (state.warp.mesh.show) rig.drawMeshOverlay(ctx, view, l.id, { active: state.warp.mesh.node, radius: state.warp.mesh.tool === 'move' ? state.warp.mesh.radius : 0, topology: state.warp.target === 'topo' }); }
    else if (l?.warp && state.warp.mode !== 'mesh') rig.drawWarpOverlay(ctx, view, l.id, { radius: state.warp.radius, active: state.warp.node });
  }

  syncAnimUI();
  hud.textContent = state.anim.rec ? `● Gravando ${state.anim.rec.len.toFixed(1)} s` : state.anim.exporting ? '● Exportando vídeo…' : tracker.running
    ? (tracker.active ? `Rastreando · ${tracker.fps.toFixed(0)} fps` : 'Câmera ligada — rosto não detectado')
    : (state.sim ? 'Simulação de rastreio' : 'Toque numa camada para editar');
  requestAnimationFrame(frame);
}

// ───────────────────────── edição direta no canvas ─────────────────────────
let drag = null;
const toRig = e => {
  const r = cv.getBoundingClientRect();
  const p = view.inverse().transformPoint({ x: (e.clientX - r.left) * dpr, y: (e.clientY - r.top) * dpr });
  return { x: p.x, y: p.y };
};
function warpTarget() {
  const W = state.warp;
  if (W.target === 'rest') return { kind: 'rest' };
  if (W.target === 'topo' && W.mode === 'mesh') return { kind: 'topo' };
  const p = PARAM_MAP[W.target];
  if (!p) { W.target = 'rest'; return { kind: 'rest' }; }
  return { kind: 'param', param: p.id, value: rig.values[p.id], def: p.def, range: p.max - p.min };
}
cv.addEventListener('pointerdown', e => {
  if (!['layers', 'rig', 'warp'].includes(state.tab) || document.body.classList.contains('stage-only')) return;
  const p = toRig(e);
  if (state.tab === 'warp') {                       // arrastar pontos da grade de deformação
    const l = state.selected && rig.byId(state.selected);
    if (state.warp.mode === 'mesh' && l?.mesh) {
      const M = state.warp.mesh, k = rig.meshHit(l.id, p.x, p.y, (28 * dpr) / view.a);
      if (M.tool === 'del') { if (k >= 0 && removeVertex(l, rig.images.get(l.id), l.mesh, k)) { M.node = -1; markDirty(); } return; }
      if (M.tool === 'add') { const q = rig.toRest(l.id, p.x, p.y); M.node = addVertex(l, rig.images.get(l.id), l.mesh, q.x, q.y); markDirty(); return; }
      if (k >= 0) { M.node = k; cv.setPointerCapture(e.pointerId); drag = { mesh: true, id: l.id, k }; return; }
    } else if (l?.warp && state.warp.mode !== 'mesh') {
      const k = rig.warpHit(l.id, p.x, p.y, (28 * dpr) / view.a);
      if (k >= 0) { state.warp.node = k; cv.setPointerCapture(e.pointerId); drag = { warp: true, id: l.id, k }; return; }
    }
    const hit = rig.pick(p.x, p.y);
    if (hit !== state.selected) { state.selected = hit; state.warp.node = -1; state.warp.mesh.node = -1; if (hit) state.warp.mode = rig.byId(hit).mesh ? 'mesh' : 'grid'; renderTab(); }
    return;
  }
  let id = state.selected;
  if (state.tool === 'move' || !id) {
    const hit = rig.pick(p.x, p.y);
    if (hit) id = hit; else if (state.tool === 'move') { id = null; }
    if (id !== state.selected) { state.selected = id; renderTab(); }
  }
  const l = id && rig.byId(id);
  if (!l) return;
  cv.setPointerCapture(e.pointerId);
  const inv = rig._lastWorld.get(id).m.inverse();
  drag = {
    id, inv, start: inv.transformPoint(p),
    snap: [l, ...rig.descendants(id)].map(d => ({ d, x: d.x, y: d.y, px: d.px, py: d.py })),
  };
});
cv.addEventListener('pointermove', e => {
  if (!drag) return;
  if (drag.mesh) {
    const l = rig.byId(drag.id), q0 = toRig(e), q = rig.toRest(l.id, q0.x, q0.y), T = warpTarget();
    const eps = T.kind === 'param' ? 1e-3 * (T.range || 1) : 0;
    dragMesh(l, l.mesh, rig.values, rig.meshAncestors(l), T, drag.k, [q.x, q.y], state.warp.mesh.radius,
      (m, t) => ensureMeshKey(m, t.param, t.value, t.def, eps));
    return;
  }
  if (drag.warp) {
    const l = rig.byId(drag.id), q = rig.toRest(l.id, toRig(e).x, toRig(e).y);
    dragNode(l, rig.values, warpTarget(), drag.k, [q.x, q.y], { radius: state.warp.radius, sym: state.warp.sym });
    return;
  }
  const c = drag.inv.transformPoint(toRig(e));
  const dx = c.x - drag.start.x, dy = c.y - drag.start.y;
  if (state.tool === 'pivot') {
    const s = drag.snap[0]; s.d.px = Math.round(s.px + dx); s.d.py = Math.round(s.py + dy);
  } else {
    for (const s of drag.snap) { s.d.x = Math.round(s.x + dx); s.d.y = Math.round(s.y + dy); s.d.px = Math.round(s.px + dx); s.d.py = Math.round(s.py + dy); }
  }
});
const endDrag = () => {
  if (!drag) return;
  const w = drag.warp || drag.mesh;
  if (drag.mesh && state.warp.target === 'topo') { const l = rig.byId(drag.id); if (l?.mesh) retriangulate(l, rig.images.get(l.id), l.mesh); }
  drag = null; markDirty();
  if (state.tab === 'rig' || (w && state.warp.target !== 'rest')) renderTab();
};
cv.addEventListener('pointerup', endDrag); cv.addEventListener('pointercancel', endDrag);

// ───────────────────────── componentes de UI ─────────────────────────
const paramRefs = new Map(), padRefs = [];
function slider(label, min, max, step, value, onInput, opts = {}) {
  const val = h('span', { class: 'val' }, fmt(value));
  const inp = h('input', { type: 'range', min, max, step, value });
  inp.addEventListener('input', () => { const v = parseFloat(inp.value); val.textContent = fmt(v); onInput(v); });
  if (opts.ref) paramRefs.set(opts.ref, { inp, val });
  const lab = h('label', opts.onLabel ? { class: 'lnk' + (opts.hl ? ' on' : ''), onclick: opts.onLabel, title: 'Editar o keyform deste parâmetro' } : {}, label);
  return h('div', { class: 'row' }, lab, inp, val);
}
function check(label, value, onChange) {
  const i = h('input', { type: 'checkbox', checked: !!value });
  i.addEventListener('change', () => onChange(i.checked));
  return h('label', { class: 'row', style: 'cursor:pointer' }, i, ' ', label);
}
function select(options, value, onChange, cls = '') {
  const s = h('select', { class: cls }, options.map(([v, t]) => h('option', { value: v, selected: v === value }, t)));
  s.addEventListener('change', () => onChange(s.value));
  return s;
}
function num(value, onChange, step = 1) {
  const i = h('input', { type: 'number', value, step });
  i.addEventListener('change', () => onChange(parseFloat(i.value)));
  return i;
}

// ───────────────────────── abas ─────────────────────────
function renderTab() {
  paramRefs.clear(); padRefs.length = 0; state.anim.draw = null; state.anim.ui = null;
  const body = $('#tabBody'), keep = body.scrollTop;
  body.replaceChildren(...({ layers: tabLayers, rig: tabRig, warp: tabWarp, anim: tabAnim, extras: tabExtras, track: tabTrack, params: tabParams }[state.tab])());
  body.scrollTop = keep;
  document.querySelectorAll('#tabs button').forEach(b => b.classList.toggle('on', b.dataset.tab === state.tab));
  $('#tools').style.display = ['layers', 'rig', 'warp'].includes(state.tab) ? '' : 'none';
  document.querySelectorAll('[data-tool]').forEach(b => (b.style.display = state.tab === 'warp' ? 'none' : ''));
}

function tabLayers() {
  const sel = state.selected && rig.byId(state.selected);
  const list = [...rig.layers].reverse().map(l => {
    const img = rig.images.get(l.id);
    return h('div', { class: 'layer' + (l.id === state.selected ? ' sel' : ''), style: `margin-left:${rig.depth(l) * 14}px` },
      h('img', { src: img?.src || '', alt: '' }),
      h('div', { class: 'nm', onclick: () => { state.selected = l.id; renderTab(); } }, l.name),
      h('button', { class: 'ib', title: 'Visível', onclick: () => { l.visible = !l.visible; markDirty(); renderTab(); } }, l.visible ? '👁' : '—'));
  });
  return [
    h('div', { class: 'row' },
      h('button', { class: 'primary', onclick: () => $('#fileImg').click() }, '+ Importar PNGs'),
      h('button', { onclick: newProject }, 'Novo vazio'),
      h('button', { disabled: !sel, onclick: () => { rig.moveZ(sel.id, 1); markDirty(); renderTab(); } }, '▲'),
      h('button', { disabled: !sel, onclick: () => { rig.moveZ(sel.id, -1); markDirty(); renderTab(); } }, '▼'),
      h('button', { class: 'danger', disabled: !sel, onclick: () => { rig.removeLayer(sel.id); state.selected = null; markDirty(); renderTab(); } }, 'Excluir')),
    h('p', { class: 'hint' }, rig.layers.length
      ? `${rig.name} · ${rig.w}×${rig.h}px · ${rig.layers.length} camadas. Toque no modelo ou na lista para selecionar; arraste para mover.`
      : 'Nenhuma camada. Importe PNGs (um por parte do corpo: cabelo, rosto, olhos, boca…) ou carregue o modelo Demo.'),
    ...list,
  ];
}

const PRESETS = {
  blink: ['Piscar olho E', [{ param: 'EyeLOpen', prop: 'sy', from: 0.06, to: 1 }]],
  blinkR: ['Piscar olho D', [{ param: 'EyeROpen', prop: 'sy', from: 0.06, to: 1 }]],
  tilt: ['Inclinar com AngleZ', [{ param: 'AngleZ', prop: 'rot', from: -12, to: 12 }]],
  turn: ['Mover com AngleX', [{ param: 'AngleX', prop: 'x', from: -20, to: 20 }]],
  nod: ['Mover com AngleY', [{ param: 'AngleY', prop: 'y', from: -12, to: 12 }]],
  mouth: ['Abrir boca (escala Y)', [{ param: 'MouthOpen', prop: 'sy', from: 0.05, to: 1 }]],
  eyeball: ['Olhar (X e Y)', [{ param: 'EyeBallX', prop: 'x', from: -10, to: 10 }, { param: 'EyeBallY', prop: 'y', from: -7, to: 7 }]],
  breath: ['Respirar', [{ param: 'Breath', prop: 'sy', from: 1, to: 1.012 }]],
  hair: ['Balançar (cabelo)', [{ param: 'HairSway', prop: 'rot', from: -7, to: 7 }]],
};

/** Curva multiponto de um binding (substitui "valor mín./máx."). */
function curveUI(b) {
  const p = PARAM_MAP[b.param], on = !!b.keys;
  const toggle = h('label', { class: 'full row', style: 'margin:0;cursor:pointer' },
    (() => { const i = h('input', { type: 'checkbox', checked: on });
      i.addEventListener('change', () => {
        if (i.checked && p) b.keys = [{ p: b.pmin ?? p.min, o: b.from }, { p: b.pmax ?? p.max, o: b.to }];
        else delete b.keys;
        markDirty(); renderTab(); });
      return i; })(), ' Curva multiponto (vários pontos)');
  if (!on) return [toggle];
  const rows = b.keys.map((k, i) => h('div', { class: 'full row', style: 'margin:0' },
    h('label', {}, 'param'), num(+k.p.toFixed(3), v => { k.p = v; b.keys.sort((x, y) => x.p - y.p); markDirty(); renderTab(); }, 0.05),
    h('label', {}, 'valor'), num(+k.o.toFixed(3), v => { k.o = v; markDirty(); }, 0.1),
    h('button', { class: 'danger', disabled: b.keys.length <= 2, onclick: () => { b.keys.splice(i, 1); markDirty(); renderTab(); } }, '×')));
  return [toggle, ...rows, h('button', { class: 'full', onclick: () => {
    const x = rig.values[b.param]; b.keys.push({ p: x, o: evalCurve(b.keys, x) }); b.keys.sort((a, c) => a.p - c.p); markDirty(); renderTab(); } }, '+ Ponto no valor atual')];
}

function tabRig() {
  const l = state.selected && rig.byId(state.selected);
  if (!l) return [h('p', { class: 'hint' }, 'Selecione uma camada (na lista ou tocando no modelo) para editar o rig dela.')];
  const used = [...new Set(l.bindings.map(b => b.param))];
  const parents = [['', '— nenhum (raiz) —'], ...rig.layers.filter(x => x.id !== l.id && !rig.descendants(l.id).some(d => d.id === x.id)).map(x => [x.id, x.name])];
  const apply = fn => v => { fn(v); markDirty(); };

  const bindCards = l.bindings.map((b, i) => h('div', { class: 'card bind' },
    h('div', { class: 'full row', style: 'margin:0' },
      select(PARAMS.map(p => [p.id, p.name]), b.param, v => { b.param = v; markDirty(); renderTab(); }),
      select(PROPS.map(p => [p.id, p.name]), b.prop, v => { b.prop = v; markDirty(); renderTab(); })),
    h('label', { class: 'hint' }, 'Valor no mín. do parâmetro', num(b.from, apply(v => (b.from = v)), 0.1)),
    h('label', { class: 'hint' }, 'Valor no máx. do parâmetro', num(b.to, apply(v => (b.to = v)), 0.1)),
    h('label', { class: 'hint' }, 'Faixa mín. (opcional)', num(b.pmin ?? '', apply(v => { if (isNaN(v)) delete b.pmin; else b.pmin = v; }), 0.05)),
    h('label', { class: 'hint' }, 'Faixa máx. (opcional)', num(b.pmax ?? '', apply(v => { if (isNaN(v)) delete b.pmax; else b.pmax = v; }), 0.05)),
    ...curveUI(b),
    h('button', { class: 'danger full', onclick: () => { l.bindings.splice(i, 1); markDirty(); renderTab(); } }, 'Remover binding')));

  return [
    h('h3', {}, 'Camada'),
    h('div', { class: 'row' }, h('label', {}, 'Nome'),
      (() => { const i = h('input', { type: 'text', value: l.name, style: 'flex:1' }); i.addEventListener('change', () => { l.name = i.value; markDirty(); }); return i; })()),
    h('div', { class: 'row' }, h('label', {}, 'Pai'), select(parents, l.parent || '', v => { rig.setParent(l.id, v); markDirty(); renderTab(); })),
    h('div', { class: 'row' }, h('label', {}, 'Pivô X/Y'),
      num(Math.round(l.px), v => { l.px = v; markDirty(); }), num(Math.round(l.py), v => { l.py = v; markDirty(); }),
      h('button', { onclick: () => { l.px = l.x + l.w / 2; l.py = l.y + l.h / 2; markDirty(); renderTab(); } }, 'Centro')),
    h('p', { class: 'hint' }, 'Dica: use a ferramenta “Pivô” e arraste no palco para posicionar o ponto de rotação.'),

    h('h3', {}, 'Aparência'),
    slider('Opacidade', 0, 1, 0.01, l.opacity ?? 1, v => { l.opacity = v; markDirtyLazy(); }),
    h('div', { class: 'row' }, h('label', {}, 'Mistura'), select(BLENDS, l.blend || 'source-over', v => { l.blend = v; markDirty(); }),
      h('button', { onclick: () => { const c = rig.duplicateLayer(l.id); if (c) { state.selected = c.id; markDirty(); renderTab(); } } }, 'Duplicar camada')),

    h('h3', {}, 'Movimento automático (oscilador)'),
    ...(l.osc || []).map((o, i) => h('div', { class: 'card bind' },
      h('div', { class: 'full row', style: 'margin:0' }, select(OSC_PROPS, o.prop, v => { o.prop = v; markDirty(); }),
        h('button', { class: 'danger', onclick: () => { l.osc.splice(i, 1); markDirty(); renderTab(); } }, '×')),
      h('label', { class: 'hint' }, 'Amplitude', num(o.amp, apply(v => (o.amp = v || 0)), 0.1)),
      h('label', { class: 'hint' }, 'Frequência (Hz)', num(o.freq, apply(v => (o.freq = v || 0)), 0.1)),
      h('label', { class: 'hint full' }, 'Fase (0–1)', num(o.phase, apply(v => (o.phase = v || 0)), 0.05)))),
    h('div', { class: 'row' }, h('button', { onclick: () => { (l.osc ||= []).push({ prop: 'rot', amp: 3, freq: 0.5, phase: 0 }); markDirty(); renderTab(); } }, '+ Oscilador'),
      h('span', { class: 'hint' }, 'Balanço contínuo (cabelo, brinco, orelha…) somado ao rig.')),

    h('h3', {}, 'Bindings (parâmetro → movimento)'),
    ...bindCards,
    h('div', { class: 'row' },
      h('button', { class: 'primary', onclick: () => { l.bindings.push({ param: 'AngleX', prop: 'x', from: -10, to: 10 }); markDirty(); renderTab(); } }, '+ Binding'),
      select([['', 'Adicionar preset…'], ...Object.entries(PRESETS).map(([k, v]) => [k, v[0]])], '', v => {
        if (v) { l.bindings.push(...PRESETS[v][1].map(b => ({ ...b }))); markDirty(); renderTab(); }
      })),

    ...(used.length ? [h('h3', {}, 'Teste rápido'), ...used.map(id => paramSlider(PARAM_MAP[id]))] : []),
  ];
}

function tabGrid() {
  const l = state.selected && rig.byId(state.selected);
  const W = state.warp;
  if (!l) return [h('p', { class: 'hint' }, 'Selecione uma camada (tocando no modelo ou na aba Camadas) para criar um deformador de grade nela.')];

  if (!l.warp) {
    const nc = num(W.cols, v => (W.cols = clamp(v | 0, 1, 16)), 1), nr = num(W.rows, v => (W.rows = clamp(v | 0, 1, 16)), 1);
    return [
      h('h3', {}, 'Warp Deformer — ' + l.name),
      h('p', { class: 'hint' }, 'Cria uma grade de pontos de controle sobre a textura. Ao arrastar os pontos, a imagem é distorcida por interpolação (Catmull-Rom). A deformação pode ser estática ou ligada a parâmetros por keyforms — e as camadas filhas herdam o movimento.'),
      h('div', { class: 'row' }, h('label', {}, 'Colunas'), nc, h('label', {}, 'Linhas'), nr),
      h('div', { class: 'row' }, h('button', { class: 'primary', onclick: () => { l.warp = createWarp(W.cols, W.rows); W.node = -1; W.target = 'rest'; markDirty(); renderTab(); } }, 'Criar deformador')),
    ];
  }
  normalizeWarp(l.warp);
  const w = l.warp, isRest = W.target === 'rest', p = isRest ? null : PARAM_MAP[W.target];
  const form = p && w.forms.find(f => f.param === p.id);
  const eps = p ? 1e-3 * (p.max - p.min) : 0;
  const keyRows = form ? form.keys.map(k => h('div', { class: 'row' },
    h('button', { class: Math.abs(k.v - rig.values[p.id]) <= eps ? 'on' : '', onclick: () => { state.manual[p.id] = k.v; renderTab(); } }, 'Chave ' + fmt(k.v)),
    h('button', { class: 'danger', onclick: () => { deleteKey(form, k); if (!form.keys.length) w.forms = w.forms.filter(f => f !== form); markDirty(); renderTab(); } }, '×'))) : [];

  return [
    h('h3', {}, `Warp Deformer — ${l.name} (${w.cols}×${w.rows})`),
    h('div', { class: 'row' }, h('label', {}, 'Editar'),
      select([['rest', 'Forma base (repouso)'], ...PARAMS.map(q => [q.id, 'Keyform: ' + q.name])], W.target, v => { W.target = v; renderTab(); })),
    ...(p ? [
      paramSlider(p),
      h('p', { class: 'hint' }, 'Mova o slider até o valor desejado e arraste os pontos: uma chave é criada nesse valor (e interpolada entre as chaves). Mantenha uma chave no valor padrão para o “neutro”.'),
      h('div', { class: 'row' }, h('button', { class: 'primary', onclick: () => { ensureKey(ensureForm(w, p.id, p.def), rig.values[p.id], eps); markDirty(); renderTab(); } }, '+ Chave no valor atual')),
      ...keyRows,
    ] : [h('p', { class: 'hint' }, 'Arraste os pontos amarelos no palco para esculpir a forma base (vale para todos os valores de parâmetro).')]),

    h('h3', {}, 'Pincel'),
    slider('Raio (células)', 0, 4, 0.1, W.radius, v => { W.radius = v; }),
    check('Simetria horizontal', W.sym, v => { W.sym = v; }),
    check('Mostrar malha de render', W.wire, v => { W.wire = v; }),

    h('h3', {}, 'Interpolação e malha'),
    h('div', { class: 'row' }, h('label', {}, 'Superfície'),
      select([['cr', 'Bicúbica (Catmull-Rom)'], ['bilinear', 'Bilinear']], w.interp, v => { w.interp = v; markDirty(); })),
    slider('Subdivisões', 1, 12, 1, w.sub, v => { w.sub = v; }),

    h('div', { class: 'row' },
      h('button', { onclick: () => { resetTarget(l, isRest ? { kind: 'rest' } : { kind: 'param', param: p.id, value: rig.values[p.id] }, eps); markDirty(); } }, 'Zerar alvo atual'),
      h('button', { class: 'danger', onclick: () => { l.warp = null; W.node = -1; markDirty(); renderTab(); } }, 'Remover deformador')),

    ...poseUI({ exclude: p?.id, onLabel: id => { W.target = id; renderTab(); } }),
  ];
}

function tabWarp() {
  const l = state.selected && rig.byId(state.selected), W = state.warp;
  if (!l) return tabGrid();
  if (W.mode === 'mesh' && W.target === 'topo' && !l.mesh) W.target = 'rest';
  if (W.mode !== 'mesh' && W.target === 'topo') W.target = 'rest';
  const modeRow = h('div', { class: 'row' }, h('label', {}, 'Tipo'),
    h('button', { class: W.mode !== 'mesh' ? 'on' : '', onclick: () => { W.mode = 'grid'; if (W.target === 'topo') W.target = 'rest'; renderTab(); } }, 'Grade (retangular)'),
    h('button', { class: W.mode === 'mesh' ? 'on' : '', onclick: () => { W.mode = 'mesh'; renderTab(); } }, 'Malha livre (segue a imagem)'));
  return [modeRow, ...(W.mode === 'mesh' ? tabMesh(l) : tabGrid())];
}

function tabMesh(l) {
  const W = state.warp, M = W.mesh, img = rig.images.get(l.id);
  if (!l.mesh) return [
    h('h3', {}, 'Malha livre — ' + l.name),
    h('p', { class: 'hint' }, 'Gera uma malha de triângulos que segue o contorno exato da imagem (só cobre os pixels visíveis, sem área vazia). Depois você move, adiciona e remove vértices e liga a deformação a parâmetros (keyforms).'),
    slider('Densidade', 4, 40, 1, M.density, v => { M.density = v; }),
    h('div', { class: 'row' }, h('button', { class: 'primary', onclick: () => { l.mesh = generateMesh(l, img, { density: M.density }); W.target = 'rest'; M.node = -1; markDirty(); renderTab(); } }, 'Gerar malha pelo contorno')),
    ...(l.warp ? [h('p', { class: 'hint' }, 'Esta camada tem um warp em grade: ao criar a malha, a malha passa a valer (o warp fica guardado e volta se você remover a malha).')] : []),
  ];
  const m = l.mesh, isTopo = W.target === 'topo', isRest = W.target === 'rest';
  const p = isTopo || isRest ? null : PARAM_MAP[W.target];
  const form = p && m.forms.find(f => f.param === p.id), eps = p ? 1e-3 * (p.max - p.min) : 0;
  const keyRows = form ? form.keys.map(k => h('div', { class: 'row' },
    h('button', { class: Math.abs(k.v - rig.values[p.id]) <= eps ? 'on' : '', onclick: () => { state.manual[p.id] = k.v; renderTab(); } }, 'Chave ' + fmt(k.v)),
    h('button', { class: 'danger', onclick: () => { deleteMeshKey(m, p.id, k); markDirty(); renderTab(); } }, '×'))) : [];
  const tbtn = (id, t) => h('button', { class: M.tool === id ? 'on' : '', onclick: () => { M.tool = id; renderTab(); } }, t);
  return [
    h('h3', {}, `Malha livre — ${l.name} (${m.verts.length / 2} vértices, ${m.tris.length / 3} triângulos)`),
    h('div', { class: 'row' }, h('label', {}, 'Ferramenta'), tbtn('move', 'Mover'), tbtn('add', '+ Vértice'), tbtn('del', '− Vértice')),
    h('p', { class: 'hint' }, M.tool === 'move' ? 'Arraste os pontos no palco (o círculo rosa é o raio de influência).' : M.tool === 'add' ? 'Toque no palco para adicionar um vértice (a malha é refeita dentro da forma da imagem).' : 'Toque num vértice para apagá-lo.'),
    h('div', { class: 'row' }, h('label', {}, 'Editar'),
      select([['topo', 'Estrutura (posição dos vértices)'], ['rest', 'Forma base (repouso)'], ...PARAMS.map(q => [q.id, 'Keyform: ' + q.name])], W.target, v => { W.target = v; renderTab(); })),
    ...(p ? [
      paramSlider(p),
      h('p', { class: 'hint' }, 'Mova o slider até o valor desejado e arraste os vértices: uma chave é criada nesse valor. Chaves são interpoladas entre si.'),
      h('div', { class: 'row' }, h('button', { class: 'primary', onclick: () => { ensureMeshKey(m, p.id, rig.values[p.id], p.def, eps); markDirty(); renderTab(); } }, '+ Chave no valor atual')),
      ...keyRows,
    ] : [h('p', { class: 'hint' }, isTopo ? 'Estrutura: mova os vértices amarelos para ajustar onde a malha toca a imagem (a textura acompanha os vértices).' : 'Forma base: deformação fixa, vale para todos os valores de parâmetro.')]),
    slider('Raio do pincel (px)', 0, 250, 1, M.radius, v => { M.radius = v; }),
    check('Mostrar malha', M.show, v => { M.show = v; }),
    h('div', { class: 'row' },
      h('button', { disabled: isTopo, onclick: () => { resetMeshTarget(m, isRest ? { kind: 'rest' } : { kind: 'param', param: p.id, value: rig.values[p.id] }, eps); markDirty(); } }, 'Zerar alvo atual'),
      h('button', { onclick: () => { retriangulate(l, img, m); markDirty(); renderTab(); } }, 'Refazer triângulos')),
    slider('Densidade ao regerar', 4, 40, 1, M.density, v => { M.density = v; }),
    h('div', { class: 'row' },
      h('button', { onclick: () => { l.mesh = generateMesh(l, img, { density: M.density }); W.target = 'rest'; M.node = -1; markDirty(); renderTab(); } }, 'Regerar (apaga deformações)'),
      h('button', { class: 'danger', onclick: () => { l.mesh = null; M.node = -1; W.mode = 'grid'; W.target = 'rest'; markDirty(); renderTab(); } }, 'Remover malha')),
    ...poseUI({ exclude: p?.id, onLabel: id => { W.target = id; renderTab(); } }),
  ];
}

function paramSlider(p, opts = {}) {
  return slider(p.name, p.min, p.max, (p.max - p.min) / 200, state.manual[p.id],
    v => { const prev = state.manual[p.id]; state.manual[p.id] = v; onParamEdited(p.id, v, prev); }, { ref: p.id, ...opts });
}

/** Joystick 2D que controla dois parâmetros de uma vez (ex.: cabeça X/Y). */
function pad(label, idX, idY) {
  const X = PARAM_MAP[idX], Y = PARAM_MAP[idY], dot = h('i'), el = h('div', { class: 'pad' }, dot);
  const place = () => {
    dot.style.left = ((rig.values[idX] - X.min) / (X.max - X.min)) * 100 + '%';
    dot.style.top = (1 - (rig.values[idY] - Y.min) / (Y.max - Y.min)) * 100 + '%';
  };
  const set = e => {
    const r = el.getBoundingClientRect(), nx = clamp((e.clientX - r.left) / r.width, 0, 1), ny = clamp(1 - (e.clientY - r.top) / r.height, 0, 1);
    const px = state.manual[idX], py = state.manual[idY];
    state.manual[idX] = X.min + nx * (X.max - X.min); state.manual[idY] = Y.min + ny * (Y.max - Y.min);
    onParamEdited(idX, state.manual[idX], px); onParamEdited(idY, state.manual[idY], py);
    place();
  };
  let down = false;
  el.addEventListener('pointerdown', e => { down = true; el.setPointerCapture(e.pointerId); set(e); });
  el.addEventListener('pointermove', e => { if (down) set(e); });
  el.addEventListener('pointerup', () => (down = false)); el.addEventListener('pointercancel', () => (down = false));
  el.addEventListener('dblclick', () => { state.manual[idX] = X.def; state.manual[idY] = Y.def; place(); });
  padRefs.push(place); place();
  return h('div', { class: 'padbox' }, el, h('div', { class: 'hint' }, label));
}

/** Painel para posar o modelo: joysticks + todos os parâmetros (usado nas abas Warp e Animação). */
function poseUI({ exclude = null, onLabel = null } = {}) {
  return [
    h('h3', {}, 'Posar o modelo'),
    h('div', { class: 'pads' }, pad('Cabeça X/Y (2 toques = zerar)', 'AngleX', 'AngleY'), pad('Olhar', 'EyeBallX', 'EyeBallY')),
    h('details', { open: true },
      h('summary', {}, 'Todos os parâmetros' + (onLabel ? ' — toque no nome para editar o keyform dele' : '')),
      ...PARAMS.filter(q => q.id !== exclude).map(q => paramSlider(q, onLabel ? { onLabel: () => onLabel(q.id), hl: q.id === state.warp.target } : {}))),
  ];
}

// ───────────────────────── aba Animação ─────────────────────────
const TL_ROW = 28, TL_HEAD = 24;

function tabAnim() {
  const A = state.anim, an = curAnim();
  const addAnim = () => {
    const a = newAnimation('Animação ' + (rig.animations.length + 1));
    rig.animations.push(a); A.cur = a.id; A.time = 0; A.sel = null; A.playing = false; markDirty(); renderTab();
  };
  if (!an) return [
    h('p', { class: 'hint' }, 'Crie uma animação do zero: posicione o modelo pelos parâmetros, grave chaves (◆) em tempos diferentes e dê play. Também dá para gravar o seu rosto pelo rastreio e converter em chaves.'),
    h('div', { class: 'row' }, h('button', { class: 'primary', onclick: addAnim }, 'Criar animação')),
  ];

  const tracks = Object.keys(an.tracks).filter(q => PARAM_MAP[q]);
  const snap = t => Math.round(t * an.fps) / an.fps;

  // transporte
  const playBtn = h('button', { class: 'primary', onclick: () => {
    if (A.playing) A.playing = false; else { if (A.time >= an.duration - 1e-3) A.time = 0; A.playing = true; }
  } }, A.playing ? '⏸' : '▶');
  const timeEl = h('span', { class: 'pill' }, '');
  const scrub = h('input', { type: 'range', min: 0, max: an.duration, step: 1 / an.fps, value: A.time, style: 'flex:1;min-width:120px;accent-color:var(--accent)' });
  scrub.addEventListener('input', () => setTime(parseFloat(scrub.value)));
  A.ui = { playBtn, timeEl, scrub };

  // timeline
  const availW = Math.max(220, $('#tabBody').clientWidth - 24 - 92);
  const pps = A.zoom > 0 ? A.zoom : availW / an.duration;
  const W = Math.max(availW, Math.ceil(an.duration * pps)), H = TL_HEAD + Math.max(1, tracks.length) * TL_ROW;
  const dprT = Math.min(2, window.devicePixelRatio || 1);
  const cvs = h('canvas', { style: `width:${W}px;height:${H}px;display:block;touch-action:none` });
  cvs.width = W * dprT; cvs.height = H * dprT;
  const g = cvs.getContext('2d');
  const yOf = (r, v, def) => TL_HEAD + r * TL_ROW + TL_ROW - 5 - ((v - def.min) / (def.max - def.min)) * (TL_ROW - 10);

  A.draw = () => {
    g.setTransform(dprT, 0, 0, dprT, 0, 0); g.clearRect(0, 0, W, H);
    g.fillStyle = '#262040'; g.fillRect(0, 0, W, TL_HEAD);
    const step = pps >= 120 ? 0.25 : pps >= 60 ? 0.5 : pps >= 30 ? 1 : 2;
    g.font = '11px system-ui'; g.textBaseline = 'middle';
    for (let t = 0; t <= an.duration + 1e-6; t += step) {
      const x = t * pps;
      g.strokeStyle = '#352e57'; g.beginPath(); g.moveTo(x, TL_HEAD - 6); g.lineTo(x, H); g.stroke();
      g.fillStyle = '#9b93c4'; g.fillText(t.toFixed(step < 1 ? 2 : 0) + 's', x + 3, 11);
    }
    if (!tracks.length) { g.fillStyle = '#9b93c4'; g.fillText('Sem trilhas — use ◆ Chave ou a Auto-chave', 10, TL_HEAD + TL_ROW / 2); }
    tracks.forEach((pid, r) => {
      const def = PARAM_MAP[pid], keys = an.tracks[pid], y0 = TL_HEAD + r * TL_ROW;
      if (r % 2) { g.fillStyle = '#ffffff08'; g.fillRect(0, y0, W, TL_ROW); }
      g.strokeStyle = '#4de2c566'; g.lineWidth = 1.5; g.beginPath();
      for (let x = 0; x <= W; x += 3) { const y = yOf(r, evalTrack(keys, x / pps, def), def); x ? g.lineTo(x, y) : g.moveTo(x, y); }
      g.stroke();
      for (const k of keys) {
        const x = k.t * pps, y = yOf(r, k.v, def), sel = A.sel && A.sel.key === k;
        g.beginPath(); g.moveTo(x, y - 6); g.lineTo(x + 6, y); g.lineTo(x, y + 6); g.lineTo(x - 6, y); g.closePath();
        g.fillStyle = sel ? '#ff5d8f' : '#ffc857'; g.fill(); g.strokeStyle = '#14111f'; g.lineWidth = 1.5; g.stroke();
      }
    });
    const px = A.time * pps;
    g.strokeStyle = '#ff5d8f'; g.lineWidth = 2; g.beginPath(); g.moveTo(px, 0); g.lineTo(px, H); g.stroke();
    g.fillStyle = '#ff5d8f'; g.beginPath(); g.moveTo(px - 6, 0); g.lineTo(px + 6, 0); g.lineTo(px, 9); g.fill();
  };

  const keyPanel = h('div', { class: 'card' });
  const renderKeyPanel = () => {
    const s = A.sel;
    if (!s || !an.tracks[s.param]?.includes(s.key)) {
      keyPanel.replaceChildren(h('p', { class: 'hint', style: 'margin:0' }, 'Toque numa chave (◆) para editar tempo, valor e curva. Arraste-a para mover no tempo. Toque no vazio para mover o cursor.'));
      return;
    }
    const pd = PARAM_MAP[s.param];
    keyPanel.replaceChildren(
      h('div', { class: 'row', style: 'margin-top:0' }, h('b', {}, s.param), h('label', {}, 'tempo (s)'),
        num(+s.key.t.toFixed(3), v => { moveKey(an, s.param, s.key, snap(v)); markDirty(); renderKeyPanel(); }, 1 / an.fps),
        h('label', {}, 'valor'), num(+s.key.v.toFixed(3), v => { s.key.v = clamp(v, pd.min, pd.max); markDirty(); }, (pd.max - pd.min) / 100)),
      h('div', { class: 'row' }, h('label', {}, 'Curva →'),
        select(EASES, s.key.e || 'spline', v => { s.key.e = v; markDirty(); }),
        h('button', { class: 'danger', onclick: () => { removeKey(an, s.param, s.key); A.sel = null; markDirty(); renderTab(); } }, 'Excluir chave')));
  };
  renderKeyPanel();

  let dragKey = null, scrubbing = false;
  const xy = e => { const r = cvs.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; };
  cvs.addEventListener('pointerdown', e => {
    const [x, y] = xy(e), row = Math.floor((y - TL_HEAD) / TL_ROW);
    let hit = null;
    if (row >= 0 && row < tracks.length) for (const k of an.tracks[tracks[row]]) if (Math.abs(k.t * pps - x) <= 12) { hit = { param: tracks[row], key: k }; break; }
    cvs.setPointerCapture(e.pointerId);
    if (hit) { A.sel = hit; dragKey = hit; setTime(hit.key.t); }
    else { A.sel = null; scrubbing = true; setTime(x / pps); }
    renderKeyPanel();
  });
  cvs.addEventListener('pointermove', e => {
    const [x] = xy(e);
    if (dragKey) { moveKey(an, dragKey.param, dragKey.key, snap(clamp(x / pps, 0, an.duration))); setTime(dragKey.key.t); }
    else if (scrubbing) setTime(x / pps);
  });
  const up = () => { if (dragKey) { markDirty(); renderKeyPanel(); } dragKey = null; scrubbing = false; };
  cvs.addEventListener('pointerup', up); cvs.addEventListener('pointercancel', up);

  const labels = h('div', { class: 'tl-labels' }, h('div', { style: `height:${TL_HEAD}px` }),
    ...(tracks.length ? tracks.map(pid => h('div', { class: 'tl-label', style: `height:${TL_ROW}px` },
      h('span', { title: PARAM_MAP[pid].name, onclick: () => { A.addParam = pid; renderTab(); } }, pid),
      h('button', { class: 'x', title: 'Remover trilha', onclick: () => { delete an.tracks[pid]; A.sel = null; markDirty(); renderTab(); } }, '×')))
      : [h('div', { style: `height:${TL_ROW}px` })]));

  const keyAll = () => { for (const pid of tracks) setKey(an, pid, A.time, rig.values[pid]); markDirty(); renderTab(); };
  const keyOne = () => { setKey(an, A.addParam, A.time, rig.values[A.addParam]); markDirty(); renderTab(); };
  const canRec = tracker.active || state.sim;

  return [
    h('div', { class: 'row' },
      select(rig.animations.map(a => [a.id, a.name]), an.id, v => { A.cur = v; A.time = 0; A.sel = null; A.playing = false; renderTab(); }),
      h('button', { onclick: addAnim }, '+ Nova'),
      h('button', { onclick: () => { const c = normalizeAnim(JSON.parse(JSON.stringify(an))); c.id = newAnimation().id; c.name = an.name + ' cópia'; rig.animations.push(c); A.cur = c.id; markDirty(); renderTab(); } }, 'Duplicar'),
      h('button', { class: 'danger', onclick: () => { rig.animations = rig.animations.filter(a => a !== an); A.cur = null; A.sel = null; A.playing = false; markDirty(); renderTab(); } }, 'Excluir')),
    h('div', { class: 'row' }, h('label', {}, 'Nome'),
      (() => { const i = h('input', { type: 'text', value: an.name, style: 'flex:1' }); i.addEventListener('change', () => { an.name = i.value; markDirty(); renderTab(); }); return i; })(),
      h('label', {}, 'Duração s'), num(an.duration, v => { an.duration = clamp(v || 4, 0.2, 600); for (const ks of Object.values(an.tracks)) for (const k of ks) k.t = Math.min(k.t, an.duration); A.time = Math.min(A.time, an.duration); markDirty(); renderTab(); }, 0.5),
      h('label', {}, 'FPS'), num(an.fps, v => { an.fps = clamp(Math.round(v) || 30, 5, 120); markDirty(); renderTab(); }, 1)),
    h('div', { class: 'row' },
      check('Repetir (loop)', an.loop, v => { an.loop = v; markDirty(); }),
      h('label', {}, 'Velocidade'), select([['0.25', '0.25×'], ['0.5', '0.5×'], ['1', '1×'], ['2', '2×']], String(A.speed), v => { A.speed = parseFloat(v); })),

    h('div', { class: 'row' },
      h('button', { onclick: () => { setTime(0); } }, '⏮'), playBtn,
      h('button', { onclick: () => { A.playing = false; setTime(0); } }, '⏹'), timeEl, scrub),

    h('div', { class: 'row' },
      check('Auto-chave (grava ao mexer nos parâmetros)', A.autoKey, v => { A.autoKey = v; })),
    h('div', { class: 'row' },
      h('button', { class: 'primary', onclick: keyAll, disabled: !tracks.length }, '◆ Chave em todas as trilhas'),
      select(PARAMS.map(q => [q.id, q.name]), A.addParam, v => { A.addParam = v; }),
      h('button', { onclick: keyOne }, '◆ Chave aqui'),
      h('button', { onclick: () => { closeLoop(an); markDirty(); renderTab(); }, disabled: !tracks.length, title: 'Copia o 1º valor de cada trilha para o fim' }, 'Fechar loop')),

    h('div', { class: 'tl' }, labels, h('div', { class: 'tl-scroll' }, cvs)),
    keyPanel,
    h('div', { class: 'row' },
      h('label', {}, 'Zoom'),
      (() => { const i = h('input', { type: 'range', min: 20, max: 400, step: 1, value: Math.round(pps), style: 'flex:1;accent-color:var(--accent)' }); i.addEventListener('change', () => { A.zoom = parseFloat(i.value); renderTab(); }); return i; })(),
      h('button', { onclick: () => { A.zoom = 0; renderTab(); } }, 'Ajustar')),

    h('h3', {}, 'Gravar e exportar'),
    h('div', { class: 'row' },
      A.rec ? h('button', { class: 'danger', onclick: stopRecording }, '■ Parar gravação')
        : h('button', { onclick: startRecording, disabled: !canRec, title: 'Grava o rastreio facial (ou a simulação) e converte em chaves' }, '● Gravar do rastreio'),
      h('button', { onclick: exportVideo, disabled: !!A.exporting }, A.exporting ? 'Exportando…' : 'Exportar vídeo (WebM)')),
    check('Simular rastreio (para testar a gravação sem câmera)', state.sim, v => { state.sim = v; renderTab(); }),
    h('p', { class: 'hint' }, canRec ? 'A gravação substitui as trilhas dos parâmetros rastreados e ajusta a duração.' : 'Para gravar: Rastreio → iniciar câmera (ou marcar “Simular rastreio”).'),

    ...poseUI(),
  ];
}

function tabParams() {
  return [
    h('div', { class: 'row' },
      h('button', { onclick: () => { for (const p of PARAMS) state.manual[p.id] = p.def; renderTab(); } }, 'Resetar'),
      check('Respiração automática', state.auto.breath, v => (state.auto.breath = v)),
      check('Piscar automático', state.auto.blink, v => (state.auto.blink = v)),
      check('Balanço do cabelo (mola)', state.auto.hair, v => (state.auto.hair = v))),
    h('p', { class: 'hint' }, 'Os sliders mostram o valor atual. Com o rastreio ligado eles seguem o seu rosto.'),
    ...PARAMS.filter(q => !q.custom).map(paramSlider),
    ...customParamsUI(),
  ];
}

function customParamsUI() {
  const nid = h('input', { type: 'text', placeholder: 'ID (ex.: MouthWide)', style: 'flex:1;min-width:120px' });
  const nname = h('input', { type: 'text', placeholder: 'Nome (ex.: Boca larga)', style: 'flex:1;min-width:120px' });
  const add = () => {
    const id = nid.value.trim();
    if (!isValidParamId(id)) return toast('ID inválido: use letras/números/_ , começando por letra, e que não seja de um parâmetro padrão.', 4500);
    if (PARAM_MAP[id]) return toast('Já existe um parâmetro com esse ID.', 3000);
    setParams([...getCustomParams(), { id, name: nname.value.trim() || id, min: 0, max: 1, def: 0 }]);
    markDirty(); renderTab();
  };
  const cards = PARAMS.filter(q => q.custom).map(q => h('div', { class: 'card' },
    paramSlider(q),
    h('div', { class: 'row', style: 'margin:0' },
      h('label', {}, q.id),
      (() => { const i = h('input', { type: 'text', value: q.name, style: 'flex:1;min-width:90px' }); i.addEventListener('change', () => { q.name = i.value || q.id; markDirty(); renderTab(); }); return i; })(),
      h('button', { class: 'danger', onclick: () => { purgeParam(q.id); setParams(getCustomParams().filter(c => c.id !== q.id)); markDirty(); renderTab(); } }, 'Apagar')),
    h('div', { class: 'row', style: 'margin:0' },
      h('label', {}, 'mín'), num(q.min, v => { if (v < q.max) { q.min = v; q.def = clamp(q.def, q.min, q.max); markDirty(); renderTab(); } }, 0.1),
      h('label', {}, 'máx'), num(q.max, v => { if (v > q.min) { q.max = v; q.def = clamp(q.def, q.min, q.max); markDirty(); renderTab(); } }, 0.1),
      h('label', {}, 'padrão'), num(q.def, v => { q.def = clamp(v, q.min, q.max); markDirty(); renderTab(); }, 0.1))));
  const missing = MOUTH_PACK.filter(m => !PARAM_MAP[m.id]);
  return [
    h('h3', {}, 'Parâmetros personalizados'),
    h('p', { class: 'hint' }, 'Crie parâmetros novos para qualquer coisa (boca em “U”, língua, cabelo extra…). Eles aparecem em Bindings, Warp/Malha (keyforms), Animação e Extras, e são salvos no projeto.'),
    h('div', { class: 'row' }, nid, nname, h('button', { class: 'primary', onclick: add }, '+ Criar')),
    h('div', { class: 'row' },
      h('button', { disabled: !missing.length, onclick: () => { setParams([...getCustomParams(), ...MOUTH_PACK.filter(m => !PARAM_MAP[m.id])]); markDirty(); renderTab(); toast('Pacote de boca adicionado: U, O, I, língua, boca lateral, bochecha. O rastreio facial já alimenta esses parâmetros.', 5000); } },
        missing.length ? 'Adicionar pacote de boca (U/O/I/língua/lateral/bochecha)' : 'Pacote de boca já adicionado')),
    ...cards,
  ];
}

// ───────────────────────── aba Extras: expressões e física ─────────────────────────
const uid = () => Math.random().toString(36).slice(2, 8);
function tabExtras() {
  const sel = (arr, cur, fn) => select(arr, cur, fn);
  const exprs = rig.expressions.map((ex, i) => h('div', { class: 'card' },
    h('div', { class: 'row', style: 'margin:0' },
      h('button', { class: (rig.exprW[ex.id]?.target ? 'on' : ''), title: 'Ligar/desligar', onclick: () => { for (const o of rig.expressions) if (o !== ex) rig.toggleExpression(o.id, 0); rig.toggleExpression(ex.id); renderTab(); } }, i < 9 ? `[${i + 1}] ${ex.name}` : ex.name),
      (() => { const t = h('input', { type: 'text', value: ex.name, style: 'flex:1;min-width:80px' }); t.addEventListener('change', () => { ex.name = t.value || 'Expressão'; markDirty(); renderTab(); }); return t; })(),
      h('button', { class: 'danger', onclick: () => { rig.expressions.splice(i, 1); markDirty(); renderTab(); } }, '×')),
    h('div', { class: 'row' }, h('label', {}, 'Transição s'), num(ex.fade ?? 0.15, v => { ex.fade = clamp(v || 0.15, 0.02, 3); markDirty(); }, 0.05),
      h('button', { onclick: () => { ex.values = captureValues(); markDirty(); renderTab(); } }, 'Recapturar pose atual')),
    h('div', { class: 'hint' }, Object.keys(ex.values).length ? Object.entries(ex.values).map(([k, v]) => `${k}=${(+v).toFixed(2)}`).join(' · ') : 'Vazia (nenhum parâmetro diferente do padrão).')));
  const phys = rig.physics.map((ph, i) => h('div', { class: 'card bind' },
    h('div', { class: 'full row', style: 'margin:0' }, h('b', {}, ph.name),
      h('button', { class: 'danger', onclick: () => { rig.physics.splice(i, 1); markDirty(); renderTab(); } }, '×')),
    h('label', { class: 'hint' }, 'Entrada', sel(PARAMS.map(q => [q.id, q.name]), ph.input, v => { ph.input = v; markDirty(); })),
    h('label', { class: 'hint' }, 'Saída', sel(PARAMS.map(q => [q.id, q.name]), ph.output, v => { ph.output = v; markDirty(); })),
    h('label', { class: 'hint' }, 'Rigidez (Hz)', num(ph.freq, v => { ph.freq = clamp(v || 2, 0.2, 12); markDirty(); }, 0.2)),
    h('label', { class: 'hint' }, 'Amortecimento', num(ph.damp, v => { ph.damp = clamp(v || 0.35, 0.02, 2); markDirty(); }, 0.05)),
    h('label', { class: 'hint full' }, 'Ganho (negativo inverte)', num(ph.gain, v => { ph.gain = v || 0; markDirty(); }, 0.25))));
  return [
    h('h3', {}, 'Expressões (atalhos 1–9)'),
    h('p', { class: 'hint' }, 'Posicione o modelo (sliders/rastreio), toque em “Capturar expressão” e use as teclas 1–9 (ou o botão) para ligar/desligar com transição suave. Vale sobre o rastreio.'),
    h('div', { class: 'row' }, h('button', { class: 'primary', onclick: () => {
      rig.expressions.push({ id: 'E' + uid(), name: 'Expressão ' + (rig.expressions.length + 1), values: captureValues(), fade: 0.15 }); markDirty(); renderTab(); } }, '+ Capturar expressão')),
    ...exprs,
    h('h3', {}, 'Física (molas)'),
    h('p', { class: 'hint' }, 'Uma mola segue um parâmetro de entrada e escreve um parâmetro de saída com atraso/oscilação (cabelo, acessórios). Use a saída em Bindings ou keyforms.'),
    h('div', { class: 'row' }, h('button', { class: 'primary', onclick: () => {
      const n = rig.physics.length + 1, id = 'Phys' + n;
      if (!PARAM_MAP[id]) setParams([...getCustomParams(), { id, name: 'Física ' + n, min: -1, max: 1, def: 0 }]);
      rig.physics.push({ id: 'P' + uid(), name: 'Mola ' + n, input: 'AngleX', output: id, freq: 2.5, damp: 0.3, gain: 2 }); markDirty(); renderTab(); } }, '+ Mola (cabeça → balanço)')),
    ...phys,
  ];
}
function captureValues() {
  const out = {};
  for (const q of PARAMS) { const v = state.manual[q.id] ?? q.def; if (Math.abs(v - q.def) > 1e-3 * (q.max - q.min)) out[q.id] = +v.toFixed(4); }
  return out;
}

function tabTrack() {
  const st = state.trackStatus || 'Parado';
  const s = settings, upd = (k, v) => { s[k] = v; saveSettings(); };
  return [
    h('div', { class: 'row' },
      h('button', { class: tracker.running ? 'danger' : 'primary', onclick: toggleTracking }, tracker.running ? 'Parar rastreio' : 'Iniciar rastreio facial'),
      h('button', { disabled: !tracker.running, onclick: () => { tracker.calibrate(); toast('Neutro calibrado: olhe para a tela e fique relaxado.'); } }, 'Calibrar neutro'),
      h('span', { class: 'pill ' + (tracker.running ? 'ok' : state.trackErr ? 'err' : '') }, state.trackErr || st)),
    h('p', { class: 'hint' }, 'Usa a câmera frontal e o MediaPipe Face Landmarker (52 blendshapes + pose 3D da cabeça), tudo no aparelho — nenhum vídeo é enviado. Precisa de HTTPS e internet na 1ª vez para baixar o modelo (depois fica em cache).'),
    check('Modo espelho (o modelo acompanha como um espelho)', s.mirror, v => upd('mirror', v)),
    check('Simular rastreio (teste sem câmera)', state.sim, v => { state.sim = v; }),

    h('h3', {}, 'Suavização e ganho'),
    slider('Suavizar', 0, 1, 0.01, s.smooth, v => upd('smooth', v)),
    slider('Cabeça', 0.3, 2.5, 0.05, s.headGain, v => upd('headGain', v)),
    slider('Olhos', 0.5, 2.5, 0.05, s.eyeGain, v => upd('eyeGain', v)),
    slider('Boca', 0.5, 2.5, 0.05, s.mouthGain, v => upd('mouthGain', v)),
    slider('Sobrancelhas', 0.3, 2.5, 0.05, s.browGain, v => upd('browGain', v)),
    slider('Piscar: início', 0, 0.9, 0.01, s.blinkLo, v => upd('blinkLo', v)),
    slider('Piscar: fechado', 0.1, 1, 0.01, s.blinkHi, v => upd('blinkHi', v)),

    h('h3', {}, 'Inverter eixos da cabeça'),
    h('p', { class: 'hint' }, 'Vire a cabeça para a direita: se o modelo virar para o lado errado, marque a opção correspondente.'),
    h('div', { class: 'row' },
      check('Virar (X)', s.invX, v => upd('invX', v)),
      check('Cima/baixo (Y)', s.invY, v => upd('invY', v)),
      check('Inclinar (Z)', s.invZ, v => upd('invZ', v))),
  ];
}

async function toggleTracking() {
  state.trackErr = '';
  if (tracker.running) { tracker.stop(); $('#camPrev').hidden = true; renderTab(); return; }
  try {
    $('#camPrev').hidden = false;
    await tracker.start();
  } catch (e) {
    console.error(e);
    $('#camPrev').hidden = true;
    state.trackErr = e.name === 'NotAllowedError' ? 'Permissão da câmera negada' : (e.message || 'Erro ao iniciar');
    toast('Rastreio: ' + state.trackErr, 6000);
  }
  renderTab();
}

// atualiza sliders (ao vivo) sem recriar a aba
setInterval(() => {
  for (const [id, r] of paramRefs) {
    if (document.activeElement === r.inp || !PARAM_MAP[id]) continue;
    r.inp.value = rig.values[id]; r.val.textContent = fmt(rig.values[id]);
  }
  padRefs.forEach(f => f());
}, 100);

// ───────────────────────── arquivos ─────────────────────────
const readDataURL = f => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(f); });

async function importImages(files) {
  const MAX = 2048;
  for (const f of files) {
    let src = await readDataURL(f);
    let img = await loadImage(src);
    if (Math.max(img.naturalWidth, img.naturalHeight) > MAX) {    // reduz para economizar memória
      const k = MAX / Math.max(img.naturalWidth, img.naturalHeight);
      const c = document.createElement('canvas'); c.width = Math.round(img.naturalWidth * k); c.height = Math.round(img.naturalHeight * k);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      src = c.toDataURL('image/png'); img = await loadImage(src);
    }
    if (!rig.layers.length) { rig.w = img.naturalWidth; rig.h = img.naturalHeight; resize(); }
    const same = img.naturalWidth === rig.w && img.naturalHeight === rig.h;
    const l = await rig.addLayer({ name: f.name.replace(/\.[^.]+$/, ''), src, ...(same ? { x: 0, y: 0 } : {}) });
    state.selected = l.id;
  }
  markDirty(); renderTab();
  toast(`${files.length} camada(s) importada(s). Defina pais e bindings na aba Rig.`);
}

function newProject() {
  rig.reset(); state.selected = null; resize(); resetAnimState(); resetHistory(); markDirty(); renderTab();
}
async function loadDemo() {
  await buildDemo(rig); state.selected = null; resize(); resetAnimState(); resetHistory(); markDirty(); renderTab();
  toast('Demo carregada. Vá em Rastreio para mover com o rosto (ou use a simulação).');
}
function saveProject() {
  const blob = new Blob([JSON.stringify(rig.toJSON())], { type: 'application/json' });
  const a = h('a', { href: URL.createObjectURL(blob), download: (rig.name || 'modelo').replace(/\W+/g, '_') + '.vrig.json' });
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
}

$('#btnImport').onclick = () => $('#fileImg').click();
$('#fileImg').onchange = e => { importImages([...e.target.files]); e.target.value = ''; };
$('#btnOpen').onclick = () => $('#fileProj').click();
$('#fileProj').onchange = async e => {
  const f = e.target.files[0]; e.target.value = '';
  if (!f) return;
  try { await rig.fromJSON(JSON.parse(await f.text())); state.selected = null; resize(); resetAnimState(); resetHistory(); markDirty(); renderTab(); toast('Projeto aberto'); }
  catch (err) { toast('Erro ao abrir: ' + err.message, 5000); }
};
$('#btnSave').onclick = saveProject;
$('#btnUndo').onclick = undo;
$('#btnRedo').onclick = redo;
window.addEventListener('keydown', e => {
  if (e.target.matches('input[type=text],input[type=number],select,textarea')) return;
  const mod = e.ctrlKey || e.metaKey;
  if (mod && e.key.toLowerCase() === 'z') { e.preventDefault(); e.shiftKey ? redo() : undo(); }
  else if (mod && e.key.toLowerCase() === 'y') { e.preventDefault(); redo(); }
  else if (!mod && !e.altKey && /^[1-9]$/.test(e.key) && rig.expressions[+e.key - 1]) {
    const ex = rig.expressions[+e.key - 1], on = !rig.exprW[ex.id]?.target;
    for (const o of rig.expressions) rig.toggleExpression(o.id, 0);
    rig.toggleExpression(ex.id, on ? 1 : 0); toast((on ? 'Expressão: ' : 'Expressão desligada: ') + ex.name, 900);
    if (state.tab === 'extras') renderTab();
  }
  else if (e.key === ' ' && state.tab === 'anim' && e.target.tagName !== 'BUTTON' && curAnim()) {
    e.preventDefault();
    const A = state.anim, an = curAnim();
    if (A.playing) A.playing = false; else { if (A.time >= an.duration - 1e-3) A.time = 0; A.playing = true; }
  }
});
$('#btnDemo').onclick = loadDemo;
$('#btnStage').onclick = () => { document.body.classList.add('stage-only'); $('#btnExitStage').hidden = false; setTimeout(resize, 50); };
$('#btnExitStage').onclick = () => { document.body.classList.remove('stage-only'); $('#btnExitStage').hidden = true; setTimeout(resize, 50); };
$('#btnBg').onclick = () => { state.bg = (state.bg + 1) % BGS.length; toast('Fundo: ' + BGS[state.bg].name, 1200); };
document.querySelectorAll('#tabs button').forEach(b => b.onclick = () => { state.tab = b.dataset.tab; renderTab(); });
document.querySelectorAll('[data-tool]').forEach(b => b.onclick = () => {
  state.tool = b.dataset.tool;
  document.querySelectorAll('[data-tool]').forEach(x => x.classList.toggle('on', x === b));
});
window.addEventListener('resize', () => setTimeout(resize, 50));

// ───────────────────────── init ─────────────────────────
(async function init() {
  resize();
  const saved = await idb.get('project');
  let ok = false;
  if (saved) { try { await rig.fromJSON(JSON.parse(saved)); ok = rig.layers.length > 0; } catch { /* cai no demo */ } }
  if (!ok) await buildDemo(rig);
  resize(); resetAnimState(); resetHistory(); renderTab();
  requestAnimationFrame(frame);
  if ('serviceWorker' in navigator && location.protocol !== 'file:') navigator.serviceWorker.register('sw.js').catch(() => {});
})();

// expõe para depuração/testes
window.__vr = { rig, state, tracker, settings, simOut, undo, redo, hist, curAnim, setTime };
