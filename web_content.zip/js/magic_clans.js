// ===== MAGIC CLANS: elemental camps whose mages fight rivals, the =====
// ===== military factions, AND the player -- not just the player.  =====
// Elements match the 4 playable heroes in characters.js.

const MAGIC_CLANS = [
  { id: 'fire_clan', name: 'Fire Clan', element: 'fire', color: 0xe0602a, x: 130, z: 90 },
  { id: 'storm_clan', name: 'Storm Clan', element: 'storm', color: 0x3fc7dd, x: -140, z: 40 },
  { id: 'nature_clan', name: 'Nature Clan', element: 'nature', color: 0x4a9d4a, x: 40, z: 150 },
  { id: 'shadow_clan', name: 'Shadow Clan', element: 'shadow', color: 0x8a5ac9, x: -60, z: -150 },
];

const MAGIC_TRACER_MATS = {
  fire: new THREE.LineBasicMaterial({ color: 0xff7a33, transparent: true }),
  storm: new THREE.LineBasicMaterial({ color: 0x6fe0ff, transparent: true }),
  nature: new THREE.LineBasicMaterial({ color: 0x7de07d, transparent: true }),
  shadow: new THREE.LineBasicMaterial({ color: 0xb98bf0, transparent: true }),
};

function buildTotem(color) {
  const group = new THREE.Group();
  const stoneMat = new THREE.MeshStandardMaterial({ color: 0x4a463f, flatShading: true });
  const crystalMat = new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.75, flatShading: true });

  const base = new THREE.Mesh(new THREE.CylinderGeometry(1.6, 2, 1.2, 6), stoneMat);
  base.position.y = 0.6;
  base.castShadow = true;
  base.receiveShadow = true;
  group.add(base);

  const crystal = new THREE.Mesh(new THREE.OctahedronGeometry(1.3, 0), crystalMat);
  crystal.position.y = 3;
  crystal.castShadow = true;
  group.add(crystal);

  group.userData = { crystal };
  return group;
}

function buildMage(color) {
  const group = buildCharacter(color);
  group.userData.gun.visible = false;

  const orbMat = new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.9, flatShading: true });
  const orb = new THREE.Mesh(new THREE.SphereGeometry(0.18, 8, 6), orbMat);
  orb.position.set(0.5, 1.5, 0.3);
  group.add(orb);
  group.userData.orb = orb;

  const robe = new THREE.Mesh(new THREE.ConeGeometry(0.5, 0.7, 7), group.userData.bodyMat);
  robe.position.y = 0.55;
  group.add(robe);

  return group;
}

function spawnMagicClan(clan) {
  const totem = buildTotem(clan.color);
  const bx = clan.x, bz = clan.z;
  totem.position.set(bx, heightAt(bx, bz), bz);
  scene.add(totem);

  const colliderBody = new CANNON.Body({ mass: 0, shape: new CANNON.Cylinder(1.8, 1.8, 4.2, 6) });
  colliderBody.position.set(bx, heightAt(bx, bz) + 2.1, bz);
  world.addBody(colliderBody);

  const base = {
    mesh: totem, x: bx, z: bz, color: clan.color, name: clan.name,
    faction: clan.id, kind: 'magic', element: clan.element, hp: 120, maxHp: 120, destroyed: false, spawnTimer: 3,
  };
  bases.push(base);

  spawnEnemyUnit(base, 'mage');
  spawnEnemyUnit(base, 'mage');
  spawnEnemyUnit(base, 'mage');
}
MAGIC_CLANS.forEach(spawnMagicClan);

let totemPhase = 0;
function updateTotems(dt) {
  totemPhase += dt;
  bases.forEach(b => {
    if (b.kind === 'magic' && !b.destroyed && b.mesh.userData.crystal) {
      b.mesh.userData.crystal.rotation.y += dt * 0.6;
      b.mesh.userData.crystal.position.y = 3 + Math.sin(totemPhase + b.x) * 0.2;
    }
  });
}
