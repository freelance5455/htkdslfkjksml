(function () {
  "use strict";

  const frame = document.getElementById("preview-frame");
  const logEl = document.getElementById("console-log");
  const countEl = document.getElementById("console-count");
  const sizeSel = document.getElementById("preview-size");
  const filterSel = document.getElementById("console-filter");

  let msgCount = 0;

  function clearConsole() {
    logEl.innerHTML = "";
    msgCount = 0;
    countEl.textContent = "0";
  }

  function log(type, text) {
    msgCount++;
    countEl.textContent = String(msgCount);
    const line = document.createElement("div");
    line.className = "console-line " + type;
    line.dataset.type = type;
    line.textContent = "[" + type + "] " + text;
    if (filterSel.value !== "all" && filterSel.value !== type) line.classList.add("hidden");
    logEl.appendChild(line);
    logEl.scrollTop = logEl.scrollHeight;
  }

  function buildDocument() {
    const files = window.Files.all();
    const htmlFile = files.find((f) => f.lang === "html") || files[0];
    if (!htmlFile) {
      return "<!DOCTYPE html><html><body style='font-family:sans-serif;padding:24px;color:#64748b;text-align:center'><h3>لا يوجد ملف HTML للمعاينة</h3><p>أنشئ ملف .html أولاً</p></body></html>";
    }

    let html = htmlFile.content || "";
    const cssFiles = files.filter((f) => f.lang === "css");
    const jsFiles = files.filter((f) => f.lang === "js");

    let injected = "";
    cssFiles.forEach((f) => {
      injected += "<style data-file='" + f.name + "'>\n" + f.content + "\n</style>\n";
    });
    jsFiles.forEach((f) => {
      injected += "<script data-file='" + f.name + "'>\n" + f.content + "\n<\/script>\n";
    });

    const bridge = "<script>(function(){" +
      "function s(t,a){try{parent.postMessage({__mcs:1,type:t,args:Array.prototype.slice.call(a).map(function(x){try{return typeof x==='object'?JSON.stringify(x):String(x)}catch(e){return String(x)}})},'*')}catch(e){}}" +
      "var _l=console.log,_w=console.warn,_e=console.error;" +
      "console.log=function(){s('log',arguments);_l.apply(console,arguments)};" +
      "console.warn=function(){s('warn',arguments);_w.apply(console,arguments)};" +
      "console.error=function(){s('error',arguments);_e.apply(console,arguments)};" +
      "window.onerror=function(m,src,ln,col){s('error',[m+' (line '+ln+')']);return false};" +
      "window.addEventListener('error',function(e){if(e.target&&(e.target.tagName==='IMG'||e.target.tagName==='SCRIPT'||e.target.tagName==='LINK')){s('error',['Failed to load: '+(e.target.src||e.target.href)])}},true);" +
      "})();<\/script>";

    if (/<head[^>]*>/i.test(html)) {
      html = html.replace(/<head([^>]*)>/i, "<head$1>" + bridge + injected);
    } else {
      html = bridge + injected + html;
    }
    return html;
  }

  function run() {
    clearConsole();
    log("log", "تشغيل المعاينة...");
    frame.srcdoc = buildDocument();
  }

  window.addEventListener("message", (e) => {
    const d = e.data;
    if (!d || !d.__mcs) return;
    log(d.type, (d.args || []).join(" "));
  });

  document.getElementById("preview-reload").addEventListener("click", run);
  document.getElementById("console-clear").addEventListener("click", clearConsole);
  document.getElementById("preview-full").addEventListener("click", () => {
    if (document.fullscreenElement) document.exitFullscreen();
    else document.documentElement.requestFullscreen().catch(() => {});
  });
  sizeSel.addEventListener("change", () => {
    frame.style.width = sizeSel.value;
    frame.style.maxWidth = "100%";
  });
  filterSel.addEventListener("change", () => {
    const v = filterSel.value;
    logEl.querySelectorAll(".console-line").forEach((el) => {
      el.classList.toggle("hidden", v !== "all" && el.dataset.type !== v);
    });
  });

  window.Preview = { run, log, clearConsole };
})();