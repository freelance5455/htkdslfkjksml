/* OPERATION: DISCIPLINE — backup JSON completo: exportação e importação validada. Sem DOM. */
(function(){'use strict';
var OD=globalThis.OD,U=OD.U,Sc=OD.Schema,E=U.E,isO=U.isO;
/* Envelope: {app,v,sum,p,exported}. p = estado serializado (perfil/configurações, missões, categorias, extrato de XP, dias, conquistas).
   Histórico de progressão e desafios são derivados do extrato e das missões, portanto fazem parte do backup. */
function exportJson(S){var p=JSON.stringify(S);return JSON.stringify({app:'od',v:3,sum:U.hash2(p),p:p,exported:new Date().toISOString()})}
function parse(text){if(typeof text!=='string')E('Conteúdo inválido');if(text.length>U.MAXB)E('Arquivo grande demais (máx. 2 MB)');
 text=text.replace(/^﻿/,'');var o;try{o=JSON.parse(text)}catch(e){E('Não é um JSON válido')}
 if(!isO(o)||o.app!=='od')E('Não é um backup do Operation: Discipline');if(o.v!==1&&o.v!==2&&o.v!==3)E('Versão de backup não suportada: '+String(o.v).slice(0,20));
 if(typeof o.p!=='string'||o.p.length>U.MAXB)E('Checksum inválido: arquivo corrompido ou alterado');
 var okSum=o.v===3?U.hash2(o.p)===o.sum:U.hash(o.p)===o.sum;if(!okSum)E('Checksum inválido: arquivo corrompido ou alterado');
 var n;try{n=JSON.parse(o.p)}catch(e){E('Dados internos ilegíveis')}
 if(o.v===1||!(isO(n)&&n.v>=2))Sc.migrate(n);return Sc.validate(n)}
OD.Backup={exportJson:exportJson,parse:parse};
})();
