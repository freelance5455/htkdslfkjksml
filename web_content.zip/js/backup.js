async function exportBackup(){const data={version:1,createdAt:new Date().toISOString()};for(const s of DB.stores)data[s]=await DB.all(s);const blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json"}),url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download="factorino-backup-"+new Date().toISOString().slice(0,10)+".json";a.click();URL.revokeObjectURL(url);toast("فایل پشتیبان آماده شد")}
async function importBackup(file){try{const data=JSON.parse(await file.text());if(!data||!Array.isArray(data.invoices)||!Array.isArray(data.customers)||!Array.isArray(data.products))throw Error("ساختار فایل معتبر نیست");if(!confirm("تمام اطلاعات فعلی با اطلاعات فایل پشتیبان جایگزین شود؟"))return;for(const s of DB.stores)if(!Array.isArray(data[s]))data[s]=[];
const maxNo=data.invoices.reduce((m,x)=>Math.max(m,Number(x.number)||0),0);
const savedNext=Number(data.meta.find(x=>x.id==="sequence")?.next)||1;
const sequence=data.meta.findIndex(x=>x.id==="sequence");
if(sequence>=0)data.meta[sequence].next=Math.max(savedNext,maxNo+1);else data.meta.push({id:"sequence",next:maxNo+1,lastUsed:maxNo});
await DB.replaceAll(data);await refreshAll();toast("اطلاعات با موفقیت بازیابی شد")}catch(e){alert("بازیابی انجام نشد: "+e.message)}}
