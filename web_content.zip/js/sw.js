// ==========================================
//  SERVICE WORKER - PWA TUki
//  Toimii sekä iOS että Android
// ==========================================

const CACHE_NAME = 'hsl-lippu-v1.0.0';

// Tiedostot jotka ladataan välimuistiin asennuksen yhteydessä
const urlsToCache = [
  '/',
  '/index.html',
  '/ticket.html',
  '/js/manifest.json',
  '/css/index.css',
  '/css/ticket.css',
  '/images/favicon-64.png',
  '/images/icon-180.png',
  '/images/icon-192.png',
  '/images/icon-512.png',
  '/images/qr.png',
  '/images/single.png',
  '/images/calendar.svg',
  '/images/child.svg',
  '/images/info.svg',
  '/images/newspinner.svg',
  '/images/caret.svg',
  '/images/single.svg'
];

// ==========================================
//  ASENNUS - Lataa välimuistiin
// ==========================================
self.addEventListener('install', (event) => {
  console.log('📦 Service Worker asennetaan...');
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('✅ Avattu välimuisti:', CACHE_NAME);
      return cache.addAll(urlsToCache).catch((err) => {
        console.warn('⚠️ Joidenkin tiedostojen välimuistiin tallennus epäonnistui:', err);
      });
    })
  );
  self.skipWaiting();
});

// ==========================================
//  AKTIVOINTI - Poista vanhat välimuistit
// ==========================================
self.addEventListener('activate', (event) => {
  console.log('🔄 Service Worker aktivoituu...');
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            console.log('🗑️ Poistetaan vanha välimuisti:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
  self.clients.claim();
});

// ==========================================
//  FETCH - Palvele välimuistista (offline-tuki)
// ==========================================
self.addEventListener('fetch', (event) => {
  // Ohita ei-GET -pyynnöt
  if (event.request.method !== 'GET') return;

  // Ohita selaimen sisäiset pyynnöt
  const url = new URL(event.request.url);
  if (url.protocol !== 'http:' && url.protocol !== 'https:') return;

  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      // Jos löytyy välimuistista, palauta se
      if (cachedResponse) {
        return cachedResponse;
      }

      // Muuten hae verkosta
      return fetch(event.request).then((response) => {
        // Jos vastaus on kelvollinen, tallenna välimuistiin
        if (!response || response.status !== 200 || response.type !== 'basic') {
          return response;
        }

        // Kloonaa vastaus (koska se voidaan lukea vain kerran)
        const responseToCache = response.clone();

        caches.open(CACHE_NAME).then((cache) => {
          cache.put(event.request, responseToCache);
        });

        return response;
      }).catch(() => {
        // Jos verkko ei toimi ja sivu on HTML, palauta index.html
        if (event.request.headers.get('accept')?.includes('text/html')) {
          return caches.match('/index.html');
        }
      });
    })
  );
});

// ==========================================
//  VIESTIT - Tuki päivityksille
// ==========================================
self.addEventListener('message', (event) => {
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
  }
});

console.log('✅ Service Worker käynnissä');