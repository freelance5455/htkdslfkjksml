
const V4_MOTIVATIONS=[
"Chaque exercice résolu transforme une difficulté en compétence.",
"Comprendre aujourd’hui rend demain plus simple.",
"Une petite session sérieuse vaut mieux qu’une grande session repoussée.",
"Travaille le point que tu ne comprends pas encore. C’est là que tu progresses.",
"La régularité construit les résultats, une session après l’autre."
];
let focusInterval=null,focusSeconds=1500,focusMinutes=25,focusRunning=false,focusStart=0;

function v4Sessions(){try{return JSON.parse(localStorage.getItem("msl_sessions")||"[]")}catch{return[]}}
function v4Grades(){try{return JSON.parse(localStorage.getItem("msl_grades")||"[]")}catch{return[]}}
function v4Subjects(){
 try{
  const custom=JSON.parse(localStorage.getItem("msl_custom_subjects")||"[]");
  return [...(window.MSL_DEFAULT_SUBJECTS||[]),...custom];
 }catch{return window.MSL_DEFAULT_SUBJECTS||[]}
}
function v4Docs(){
 return new Promise(resolve=>{
  try{
   const r=indexedDB.open("MyStudyLifeDB",2);
   r.onsuccess=()=>{const db=r.result,t=db.transaction("documents","readonly"),q=t.objectStore("documents").getAll();q.onsuccess=()=>resolve(q.result||[]);q.onerror=()=>resolve([])}
   r.onerror=()=>resolve([]);
  }catch{resolve([])}
 })
}
function v4Avg(){
 const gs=v4Grades();let p=0,c=0;
 gs.forEach(g=>{const n=Number(g.note??g.grade??g.value),k=Number(g.coeff??g.coefficient??1);if(Number.isFinite(n)&&k>0){p+=n*k;c+=k}});
 return c?p/c:null;
}
function v4Day(d){return new Date(d||0).toISOString().slice(0,10)}
function v4Today(){return new Date().toISOString().slice(0,10)}
function v4Minutes(ss){return ss.reduce((a,s)=>a+(Number(s.minutes??s.duration)||0),0)}
function v4TodayMinutes(ss){const t=v4Today();return ss.reduce((a,s)=>a+(v4Day(s.date||s.createdAt||s.created)===t?(Number(s.minutes??s.duration)||0):0),0)}
function v4Streak(ss){const set=new Set(ss.map(s=>v4Day(s.date||s.createdAt||s.created)));let n=0,d=new Date();while(set.has(v4Day(d))){n++;d.setDate(d.getDate()-1)}return n}
function esc(s){return String(s||"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}

async function v4Refresh(){
 const ss=v4Sessions(),docs=await v4Docs(),today=v4TodayMinutes(ss),avg=v4Avg();
 const e=id=>document.getElementById(id);
 if(e("v4Date"))e("v4Date").textContent=new Intl.DateTimeFormat("fr-FR",{weekday:"long",day:"numeric",month:"long",year:"numeric"}).format(new Date());
 if(e("studyStreak"))e("studyStreak").textContent=v4Streak(ss);
 if(e("statSubjects"))e("statSubjects").textContent=v4Subjects().length;
 if(e("statDocuments"))e("statDocuments").textContent=docs.length;
 if(e("statStudyMinutes"))e("statStudyMinutes").textContent=v4Minutes(ss);
 if(e("statAverage"))e("statAverage").textContent=avg==null?"--":avg.toFixed(2);
 if(e("todayProgressLabel"))e("todayProgressLabel").textContent=today+" min / 60 min";
 if(e("todayProgressBar"))e("todayProgressBar").style.width=Math.min(100,today/60*100)+"%";
 docs.sort((a,b)=>(b.created||0)-(a.created||0));
 const box=e("recentDocuments");
 if(box)box.innerHTML=docs.slice(0,4).map(d=>`<button class="recent-doc" data-open-doc="${Number(d.id)}"><span class="recent-icon">${d.type?.includes("pdf")?"📕":"🖼️"}</span><span class="recent-text"><strong>${esc(d.name||"Document")}</strong><small>${esc(d.subject||"Autres")}</small></span><span>›</span></button>`).join("")||'<div class="v4-empty">Aucun document récent.</div>';
}
function clock(){const m=Math.floor(focusSeconds/60).toString().padStart(2,"0"),s=(focusSeconds%60).toString().padStart(2,"0");return m+":"+s}
function setFocus(n){
 focusMinutes=Number(n)||25;focusSeconds=focusMinutes*60;focusRunning=false;clearInterval(focusInterval);
 const c=document.getElementById("focusClock"),s=document.getElementById("focusStatus"),b=document.getElementById("startFocusTimer");
 if(c)c.textContent=clock();if(s)s.textContent="Prêt à commencer.";if(b)b.textContent="Démarrer";
}
function openFocus(){document.getElementById("focusTimerModal")?.classList.remove("hidden");setFocus(focusMinutes)}
function saveFocus(min){
 const s=v4Sessions();s.push({date:new Date().toISOString(),minutes:min,source:"focus_timer"});localStorage.setItem("msl_sessions",JSON.stringify(s));v4Refresh()
}
function startFocus(){
 if(focusRunning){clearInterval(focusInterval);focusRunning=false;document.getElementById("startFocusTimer").textContent="Démarrer";return}
 focusRunning=true;focusStart=Date.now();document.getElementById("startFocusTimer").textContent="Pause";document.getElementById("focusStatus").textContent="Concentration en cours…";
 focusInterval=setInterval(()=>{
  focusSeconds--;document.getElementById("focusClock").textContent=clock();
  if(focusSeconds<=0){clearInterval(focusInterval);focusRunning=false;saveFocus(focusMinutes);document.getElementById("focusStatus").textContent="Session terminée.";document.getElementById("startFocusTimer").textContent="Démarrer"}
 },1000)
}
document.addEventListener("DOMContentLoaded",()=>{
 document.getElementById("newMotivationBtn")?.addEventListener("click",()=>{const a=V4_MOTIVATIONS.filter(x=>x!==document.getElementById("dailyMotivation")?.textContent);document.getElementById("dailyMotivation").textContent=a[Math.floor(Math.random()*a.length)]||V4_MOTIVATIONS[0]});
 document.getElementById("openFocusQuick")?.addEventListener("click",openFocus);
 document.getElementById("closeFocusTimer")?.addEventListener("click",()=>{clearInterval(focusInterval);focusRunning=false;document.getElementById("focusTimerModal").classList.add("hidden")});
 document.getElementById("resetFocusTimer")?.addEventListener("click",()=>setFocus(focusMinutes));
 document.getElementById("startFocusTimer")?.addEventListener("click",startFocus);
 document.querySelectorAll(".timer-preset").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll(".timer-preset").forEach(x=>x.classList.remove("active"));b.classList.add("active");setFocus(b.dataset.minutes)}));
 document.getElementById("recentDocuments")?.addEventListener("click",async e=>{const b=e.target.closest("[data-open-doc]");if(b&&window.MSLDocumentsV3?.openDocument)await window.MSLDocumentsV3.openDocument(Number(b.dataset.openDoc))});
 setTimeout(v4Refresh,300);
});
window.MSLV4={refresh:v4Refresh,openFocus};
