// ===== lobby.js: difficulty, mode, lobby music, local accounts, coins, cosmetics store =====
const DIFFS = [
  { n: 'KOLAY', hp: .7, dmg: .55, cnt: .75, rew: .6, d: 'Rahat bir giriş. Düşmanlar zayıf, az ve isabetsiz. Ödül ×0.6' },
  { n: 'ORTA', hp: 1, dmg: 1, cnt: 1, rew: 1, d: 'Dengeli savaş. Ödül ×1' },
  { n: 'ZOR', hp: 1.35, dmg: 1.3, cnt: 1.15, rew: 1.5, d: 'Düşman daha dayanıklı ve sert vuruyor. Ödül ×1.5' },
  { n: 'İMKANSIZ', hp: 1.8, dmg: 1.7, cnt: 1.3, rew: 2.1, d: 'Hata affetmez. Ödül ×2.1' },
  { n: 'KABUS', hp: 2.5, dmg: 2.3, cnt: 1.5, rew: 3, d: 'Kalabalık ve ölümcül. Ödül ×3' },
  { n: 'CEHENNEM', hp: 3.4, dmg: 3.2, cnt: 1.8, rew: 4.5, d: 'Tek hata ölüm. Yalnızca delilere. Ödül ×4.5' }
];
let DIFF = DIFFS[1];
const LOBBY = { mode: 'camp', diff: 1, map: 0, squad: 0, load: { p: 3, m: [10, 7] } };
try { const o = JSON.parse(localStorage.getItem('celikCephe.lobby') || '{}'); if (['endless', 'gungame', 'tdm'].includes(o.mode)) LOBBY.mode = o.mode; if (o.map >= 0 && o.map < 6) LOBBY.map = o.map | 0; if (o.squad >= 0 && o.squad <= 3) LOBBY.squad = o.squad | 0; if (o.diff >= 0 && o.diff < 6) LOBBY.diff = o.diff | 0; } catch (e) { }
DIFF = DIFFS[LOBBY.diff];
try { const o = JSON.parse(localStorage.getItem('celikCephe.lobby') || '{}').load; if (o && o.m && o.m.length === 2 && o.p >= 0 && o.p < 5 && o.m.every(v => v >= 5 && v <= 18)) LOBBY.load = { p: o.p | 0, m: [o.m[0] | 0, o.m[1] | 0] }; } catch (e) { }
function saveLobby() { try { localStorage.setItem('celikCephe.lobby', JSON.stringify(LOBBY)); } catch (e) { } }
const MODE_INFO = {
  camp: ['KAMPANYA', '30 dalga, 6 cephe. Her 5 dalgada tahliye ile yeni haritaya geçersin.'],
  endless: ['SONSUZ', 'Dalgalar hiç bitmez. Her tahliyede harita değişir, düşman güçlenir.'],
  tdm: ['TAKIM ÖLÜM', 'ARENA · Yapay zeka askerlerinle karşı takımın 4 kişisini yen. Sahaya çıkmadan 1 tabanca + 2 ana silah seç. İlk 30 öldürmeyi yapan takım kazanır.'],
  gungame: ['SİLAH OYUNU', 'ARENA · Tabancayla başla, her 2 öldürmede silahın değişir: 5 tabanca, 5 SMG, 5 tüfek, 2 keskin, 2 pompalı. Son silah karambit.'],
  online: ['ONLİNE', 'Arkadaşlarınla takım kur, çevrimiçi karşılaş.']
};
let lobbyView = 'camp';
function loadUI() {
  const box = $('loadBox'); box.hidden = lobbyView !== 'tdm'; if (box.hidden) return; const ld = LOBBY.load;
  let h = '<div class="lbH">SİLAHLARIN · 1 TABANCA + 2 ANA SİLAH</div><div class="lgrp">TABANCA</div><div class="chips">';
  for (let i = 0; i < 5; i++) h += '<button data-p="' + i + '" class="' + (ld.p === i ? 'on' : '') + '">' + GG[i].n + '</button>';
  h += '</div><div class="lgrp">ANA SİLAH <small>(aynı türden iki tane olmaz)</small></div><div class="chips">';
  for (let i = 5; i <= 18; i++) { const k = ld.m.indexOf(i); h += '<button data-m="' + i + '" class="' + (k >= 0 ? 'on' : '') + '">' + (k >= 0 ? (k + 1) + '· ' : '') + GG[i].n + '</button>'; }
  box.innerHTML = h + '</div>';
  box.querySelectorAll('[data-p]').forEach(b => b.onclick = () => { ld.p = +b.dataset.p; saveLobby(); loadUI(); });
  box.querySelectorAll('[data-m]').forEach(b => b.onclick = () => {
    const i = +b.dataset.m; if (ld.m.includes(i)) return;
    const same = ld.m.findIndex(v => GG[v].a === GG[i].a); if (same >= 0) ld.m[same] = i; else { ld.m.push(i); ld.m.shift(); }
    saveLobby(); loadUI();
  });
}
function lobbyUI() {
  loadUI();
  const m = lobbyView, arenaM = m === 'tdm' || m === 'gungame', un = PROFILE ? (PROFILE.data.maxMap || 0) : 0;
  for (const b of $('modeSeg').children) b.classList.toggle('on', b.dataset.m === m);
  for (const b of $('diffSeg').children) b.classList.toggle('on', +b.dataset.d === LOBBY.diff);
  $('diffInfo').textContent = DIFF.d; $('modeDesc').textContent = MODE_INFO[m][1]; $('modeName').textContent = MODE_INFO[m][0];
  $('onlineBox').hidden = m !== 'online'; $('btnPlay').disabled = m === 'online'; $('btnPlay').textContent = m === 'online' ? 'YAKINDA' : 'SAHAYA ÇIK';
  const ml = $('mapList'); ml.innerHTML = '';
  const card = (name, sub, on, locked, fn) => { const d = document.createElement('div'); d.className = 'mc' + (on ? ' on' : '') + (locked ? ' lock' : ''); d.innerHTML = '<b>' + name + '</b><small>' + (locked ? 'KİLİTLİ · önce bu cepheye ulaş' : sub) + '</small>'; if (!locked) d.onclick = fn; ml.appendChild(d); };
  if (arenaM) card('ARENA', 'Kapalı stadyum · takım savaşı', true, false, () => { });
  else if (m !== 'online') MAPS.forEach((mp, i) => card(mp.name, mp.sub, i === LOBBY.map, i > un, () => { LOBBY.map = i; saveLobby(); lobbyUI(); }));
  for (const sq of $('sqList').querySelectorAll('.ai')) sq.classList.toggle('on', +sq.dataset.s <= LOBBY.squad), sq.querySelector('small').textContent = +sq.dataset.s <= LOBBY.squad ? 'SAFTA · ÇIKAR' : 'EKLE';
  $('pName2').textContent = PROFILE ? (PROFILE.guest ? 'MİSAFİR' : PROFILE.name.toUpperCase()) : 'SEN';
}
for (const b of $('modeSeg').children) b.onclick = () => {
  const m = b.dataset.m; lobbyView = m;
  if (m !== 'online') { LOBBY.mode = m; if ((m === 'tdm') && LOBBY.squad === 0) LOBBY.squad = 3; saveLobby(); }
  lobbyUI();
};
for (const b of $('diffSeg').children) b.onclick = () => { LOBBY.diff = +b.dataset.d; DIFF = DIFFS[LOBBY.diff]; saveLobby(); lobbyUI(); };
for (const sq of $('sqList').querySelectorAll('.ai')) sq.onclick = () => { const k = +sq.dataset.s; LOBBY.squad = LOBBY.squad >= k ? k - 1 : k; saveLobby(); lobbyUI(); };
$('sqFriend').onclick = () => { $('onlineBox').hidden = false; lobbyView = 'online'; lobbyUI(); };
$('btnManual').onclick = () => { $('manual').hidden = !$('manual').hidden; };
lobbyView = LOBBY.mode;
// ---------- 3D stage: your soldier and your AI squad in the lobby ----------
let MF = null;
function menuStage(tt, dt) {
  if (!MF) {
    MF = { g: new THREE.Group(), s: [] };
    for (let i = 0; i < 4; i++) { const f = friendlySoldier(); if (i === 0) f.g.traverse(o => { if (o.isMesh && o.material && o.material.color && !o.material.isMeshBasicMaterial) { o.material = o.material.clone(); o.material.color.offsetHSL(-.55, .1, .12); } }); MF.g.add(f.g); MF.s.push(f); }
    scene.add(MF.g);
  }
  MF.g.visible = true; const C = MAP.pit ? [-36, 0] : [0, 2], n = LOBBY.squad, a = Math.sin(tt * .22) * .55, R = 4.6 + n * .9;
  const off = [[0, 0], [-1.7, .5], [1.7, .5], [0, -1.4]];
  const cx = C[0] + Math.sin(a) * R, cz = C[1] + Math.cos(a) * R;
  camera.position.set(cx, 1.5 + Math.sin(tt * .5) * .05, cz); camera.fov = 52; camera.updateProjectionMatrix();
  for (let i = 0; i < 4; i++) {
    const f = MF.s[i], on = i === 0 || i <= n; f.g.visible = on; if (!on) continue; const x = C[0] + off[i][0], z = C[1] + off[i][1];
    f.g.position.set(x, Math.sin(tt * 1.6 + i) * .01, z); f.g.rotation.y = Math.atan2(cx - x, cz - z) + (i === 0 ? .25 : i === 1 ? .5 : -.4); animSol(f, 0, 0, false); f.g.position.y = Math.sin(tt * 1.6 + i) * .01;
  }
  camera.lookAt(C[0] + (n > 0 ? 0 : -.6), 1.15, C[1]);
}
// ---------- profile / local accounts ----------
const COS = { paint: null, xh: null, trc: null, skin: null, skins: {} };
let PROFILE = null;
const K_ACC = 'celikCephe.acc', K_GUEST = 'celikCephe.guest', K_SESS = 'celikCephe.sess';
const newData = () => ({ coins: 0, own: {}, eq: { paint: '', xh: '', trc: '' }, best: 0, games: 0 });
function lsGet(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } }
function lsSet(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } }
function saveProfile() {
  if (!PROFILE) return;
  if (PROFILE.guest) lsSet(K_GUEST, PROFILE.data);
  else { const a = lsGet(K_ACC, { users: {} }); if (a.users[PROFILE.name]) { a.users[PROFILE.name].data = PROFILE.data; lsSet(K_ACC, a); } }
}
async function hashPw(pw, salt) {
  try {
    const enc = new TextEncoder(), k = await crypto.subtle.importKey('raw', enc.encode(pw), 'PBKDF2', false, ['deriveBits']);
    const b = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt: enc.encode(salt), iterations: 60000, hash: 'SHA-256' }, k, 256);
    return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join('');
  } catch (e) { let h = 2166136261; const s = salt + '|' + pw; for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619); return 'f' + (h >>> 0).toString(16); }
}
// skins used to be one global item; give old purchases to every weapon once
function migrateSkins(d) {
  if (d.skinMig) return; d.skinMig = 1;
  for (const s of SKIN_DEFS) if (d.own[s.id]) for (const w of WEAPONS) d.own[s.id + '@' + w.id] = true;
  if (d.eq.skin) { for (const w of WEAPONS) d.eq['skin@' + w.id] = d.eq.skin; d.eq.skin = ''; }
}
function applyCosmetics() {
  const e = PROFILE ? PROFILE.data.eq : {}, it = id => COS_ITEMS.find(x => x.id === id);
  COS.paint = null; COS.xh = null; COS.trc = null; COS.skin = null; COS.skins = {};
  if (PROFILE) migrateSkins(PROFILE.data);
  for (const k of ['paint', 'xh', 'trc']) { const x = it(e[k]); if (x) COS[k] = x.col; }
  for (const w of WEAPONS) { const sid = (e['skin@' + w.id] || '').split('@')[0]; if (sid && SKIN_DEFS.some(s => s.id === sid)) COS.skins[w.id] = sid; }
  document.documentElement.style.setProperty('--xh', COS.xh !== null ? '#' + COS.xh.toString(16).padStart(6, '0') : '');
}
function setProfile(p) {
  PROFILE = p; applyCosmetics(); profUI();
  if (!p.guest) { try { localStorage.setItem(K_SESS, p.name); } catch (e) { } } else { try { localStorage.setItem(K_SESS, ':guest'); } catch (e) { } }
}
function profUI() {
  if (!PROFILE) return;
  $('pName').textContent = PROFILE.guest ? 'MİSAFİR' : PROFILE.name.toUpperCase(); $('pCoins').textContent = PROFILE.data.coins + ' ◈'; $('stCoins').textContent = PROFILE.data.coins + ' ◈ KREDİ';
  $('btnLogout').textContent = PROFILE.guest ? 'GİRİŞ / KAYIT' : 'ÇIKIŞ YAP'; try { lobbyUI(); } catch (e) { }
}
let auTab = 'login';
function authTab(t) {
  auTab = t; for (const b of $('auTabs').children) b.classList.toggle('on', b.dataset.t === t);
  $('auL1').style.display = $('auL2').style.display = t === 'guest' ? 'none' : ''; $('auL3').style.display = t === 'reg' ? '' : 'none';
  $('auGo').textContent = t === 'login' ? 'GİRİŞ YAP' : t === 'reg' ? 'KAYIT OL' : 'MİSAFİR OLARAK DEVAM'; $('auMsg').textContent = '';
}
for (const b of $('auTabs').children) b.onclick = () => authTab(b.dataset.t);
function showAuth() { $('auth').hidden = false; authTab('login'); }
$('auGo').onclick = async () => {
  initAudio(); const msg = t => { $('auMsg').textContent = t; };
  if (auTab === 'guest') { setProfile({ guest: true, name: 'misafir', data: Object.assign(newData(), lsGet(K_GUEST, {})) }); $('auth').hidden = true; afterLogin(); return; }
  const u = $('auUser').value.trim(), pw = $('auPass').value; if (!/^[A-Za-z0-9_ÇĞİÖŞÜçğıöşü]{3,16}$/.test(u)) return msg('Kullanıcı adı 3-16 karakter: harf, rakam, _');
  if (pw.length < 6) return msg('Şifre en az 6 karakter olmalı');
  const a = lsGet(K_ACC, { users: {} }), key = u.toLowerCase();
  if (auTab === 'reg') {
    if ($('auPass2').value !== pw) return msg('Şifreler uyuşmuyor'); if (a.users[key]) return msg('Bu kullanıcı adı alınmış');
    const salt = Math.random().toString(36).slice(2) + Date.now().toString(36); const hash = await hashPw(pw, salt);
    const data = newData(); const g = lsGet(K_GUEST, null); if (g && g.coins) { data.coins = g.coins; data.own = g.own || {}; data.eq = g.eq || data.eq; }
    a.users[key] = { name: u, salt, hash, data }; lsSet(K_ACC, a); setProfile({ guest: false, name: key, data }); $('auth').hidden = true; afterLogin();
  } else {
    const r = a.users[key]; if (!r) return msg('Böyle bir hesap yok (bu cihazda)'); const hash = await hashPw(pw, r.salt); if (hash !== r.hash) return msg('Şifre yanlış');
    setProfile({ guest: false, name: key, data: Object.assign(newData(), r.data) }); $('auth').hidden = true; afterLogin();
  }
};
function afterLogin() { $('auPass').value = $('auPass2').value = ''; profUI(); if (G.state === 'menu') musicStart(); }
$('btnLogout').onclick = () => { try { localStorage.removeItem(K_SESS); } catch (e) { } saveProfile(); PROFILE = null; showAuth(); };
// ---------- earnings ----------
function payout(win) {
  if (!PROFILE || G.paid || !(G.score > 0)) return 0; G.paid = true;
  const wv = G.arena ? Math.round((G.tdmA || 0) * .9 + (G.ggLv || 0)) : G.wave; const earn = Math.round((G.score / 140 + wv * 22 + G.kills * .8 + (win ? 1500 : 0)) * DIFF.rew * (LOBBY.mode === 'endless' ? 1.1 : 1) + (G.mode === 'gungame' ? (G.ggLv || 0) * 60 : 0));
  PROFILE.data.coins += earn; if (!G.arena) PROFILE.data.maxMap = Math.max(PROFILE.data.maxMap || 0, Math.min(5, MAPI)); PROFILE.data.games = (PROFILE.data.games || 0) + 1; PROFILE.data.best = Math.max(PROFILE.data.best || 0, G.score); saveProfile(); profUI();
  $('oEarn').textContent = '+' + earn + ' ◈ kredi kazandın (' + DIFF.n + ')'; return earn;
}
// ---------- cosmetics store ----------
const COS_ITEMS = [
  { id: 'p_red', cat: 'paint', n: 'Kızıl Boya', col: 0xd23a2a, cost: 400 }, { id: 'p_blue', cat: 'paint', n: 'Mavi Çelik', col: 0x3a7ad2, cost: 400 }, { id: 'p_green', cat: 'paint', n: 'Zümrüt', col: 0x2ec27a, cost: 600 },
  { id: 'p_gold', cat: 'paint', n: 'Altın Kaplama', col: 0xf2c230, cost: 1600 }, { id: 'p_purple', cat: 'paint', n: 'Mor Gece', col: 0x9a4ae0, cost: 900 }, { id: 'p_white', cat: 'paint', n: 'Kar Kamuflajı', col: 0xf4f4f4, cost: 700 },
  { id: 'x_green', cat: 'xh', n: 'Yeşil Nişangâh', col: 0x4cff6a, cost: 150 }, { id: 'x_red', cat: 'xh', n: 'Kırmızı Nişangâh', col: 0xff4a3a, cost: 150 }, { id: 'x_cyan', cat: 'xh', n: 'Camgöbeği Nişangâh', col: 0x3af0ff, cost: 200 }, { id: 'x_pink', cat: 'xh', n: 'Pembe Nişangâh', col: 0xff6ad8, cost: 250 },
  { id: 't_red', cat: 'trc', n: 'Kızıl İz Mermisi', col: 0xff4030, cost: 350 }, { id: 't_green', cat: 'trc', n: 'Yeşil İz Mermisi', col: 0x40ff60, cost: 350 }, { id: 't_blue', cat: 'trc', n: 'Mavi İz Mermisi', col: 0x50a0ff, cost: 450 }, { id: 't_purple', cat: 'trc', n: 'Mor İz Mermisi', col: 0xc060ff, cost: 600 },
  { id: 'f_cash', cat: 'perk', n: 'Başlangıç Parası', d: 'Her oyuna +$300 ile başla', cost: 800 }, { id: 'f_gren', cat: 'perk', n: 'Bomba Çantası', d: 'Her oyuna +2 el bombası', cost: 700 },
  { id: 'f_hp', cat: 'perk', n: 'Takviye Zırh Plakası', d: 'Maksimum can +15', cost: 1500 }, { id: 'f_ammo', cat: 'perk', n: 'Yedek Cephane', d: 'Tüfekte +60 yedek mermi', cost: 900 }, { id: 'f_air', cat: 'perk', n: 'Hava Desteği Kartı', d: 'Her oyuna 1 hava saldırısı', cost: 2400 }
];
const SKIN_W = [['rifle', 'TÜFEK'], ['smg', 'SMG'], ['shotgun', 'POMPALI'], ['sniper', 'KESKİN'], ['pistol', 'TABANCA'], ['knife', 'KARAMBİT'], ['rpg', 'RPG'], ['minigun', 'MİNİGUN'], ['plasma', 'PLAZMA']];
let stW = 'knife';
function skinItems(wid) { return SKIN_DEFS.map(s => ({ id: s.id + '@' + wid, cat: 'skin@' + wid, n: s.n, tier: s.tier, col: SKIN_TIERS[s.tier].col, grad: SKIN_TIERS[s.tier].grad, d: SKIN_TIERS[s.tier].n + ' · ' + s.d, cost: s.cost })); }
const COS_CATS = [['skin', 'SİLAH KOSTÜMÜ'], ['paint', 'SİLAH BOYASI'], ['xh', 'NİŞANGÂH'], ['trc', 'İZ MERMİSİ'], ['perk', 'EKİPMAN']];
let stCat = 'skin';
function hex(c) { return '#' + c.toString(16).padStart(6, '0'); }
function storeUI() {
  const t = $('stTabs'); t.innerHTML = ''; for (const [k, n] of COS_CATS) { const b = document.createElement('button'); b.textContent = n; b.className = k === stCat ? 'on' : ''; b.onclick = () => { stCat = k; storeUI(); }; t.appendChild(b); }
  const g = $('stGrid'); g.innerHTML = ''; const d = PROFILE.data; $('stCoins').textContent = d.coins + ' ◈ KREDİ';
  if (stCat === 'skin') {
    const wr = document.createElement('div'); wr.style.cssText = 'grid-column:1/-1;display:flex;flex-wrap:wrap;gap:6px';
    for (const [k, n] of SKIN_W) { const b = document.createElement('button'); b.textContent = n; b.className = 'btn s' + (k === stW ? '' : ' alt'); b.onclick = () => { stW = k; storeUI(); }; wr.appendChild(b); }
    g.appendChild(wr);
  }
  for (const it of (stCat === 'skin' ? skinItems(stW) : COS_ITEMS.filter(x => x.cat === stCat))) {
    const own = !!d.own[it.id], eq = d.eq[it.cat] === it.id, div = document.createElement('div'); div.className = 'sti' + (eq ? ' eq' : '');
    div.innerHTML = '<b>' + (it.col !== undefined ? '<i style="background:' + (it.grad || hex(it.col)) + '"></i>' : '') + it.n + '</b><small>' + (it.d || (eq ? 'Kuşanıldı' : own ? 'Sahipsin' : '')) + '</small>';
    const bt = document.createElement('button');
    if (it.cat === 'perk') bt.textContent = own ? 'SAHİPSİN' : it.cost + ' ◈ AL'; else bt.textContent = eq ? 'ÇIKAR' : own ? 'KUŞAN' : it.cost + ' ◈ AL';
    bt.onclick = () => {
      if (!own) { if (d.coins < it.cost) { bt.textContent = 'YETERSİZ KREDİ'; return; } d.coins -= it.cost; d.own[it.id] = true; if (it.cat !== 'perk') d.eq[it.cat] = it.id; }
      else if (it.cat !== 'perk') d.eq[it.cat] = eq ? '' : it.id; else return;
      saveProfile(); applyCosmetics(); profUI(); storeUI();
    };
    div.appendChild(bt); g.appendChild(div);
  }
}
$('btnStore').onclick = () => { if (!PROFILE) return; $('store').hidden = false; storeUI(); };
$('stClose').onclick = () => { $('store').hidden = true; };
function applyPerks() {
  if (!PROFILE) return; const o = PROFILE.data.own;
  if (o.f_cash) P.money += 300; if (o.f_gren) P.gren = Math.min(8, P.gren + 2); if (o.f_hp) { P.maxHp += 15; P.hp = P.maxHp; } if (o.f_ammo) P.ws[0].reserve += 60; if (o.f_air) P.air += 1;
}
$('btnQualityLobby').onclick = () => setGfx((gfx + 1) % 4);

// ---------- lobby music (procedural, no files) ----------
const MUS = { on: true, playing: false, out: null, bus: null, timer: null, next: 0, step: 0 };
try { MUS.on = localStorage.getItem('celikCephe.mus') !== '0'; } catch (e) { }
const mtof = m => 440 * Math.pow(2, (m - 69) / 12), SP16 = 60 / 78 / 4;
const PROG = [[45, 48, 52], [41, 45, 48], [48, 52, 55], [43, 47, 50]];
function mo(type, f, t0, dur, vol, lpf, att) {
  const o = ac.createOscillator(); o.type = type; o.frequency.value = f; const g = ac.createGain(), fl = ac.createBiquadFilter(); fl.type = 'lowpass'; fl.frequency.value = lpf || 1200;
  const a = att || .01; g.gain.setValueAtTime(0, t0); g.gain.linearRampToValueAtTime(vol, t0 + a); g.gain.setTargetAtTime(0, t0 + Math.max(a, dur * .6), Math.max(.05, dur * .25));
  o.connect(fl); fl.connect(g); g.connect(MUS.bus); o.start(t0); o.stop(t0 + dur + 1.2); return o;
}
function mn(t0, dur, vol, type, f0, f1) {
  const s = ac.createBufferSource(); s.buffer = noiseBuf; const fl = ac.createBiquadFilter(); fl.type = type; fl.frequency.value = f0; if (f1) fl.frequency.exponentialRampToValueAtTime(f1, t0 + dur); const g = ac.createGain(); g.gain.setValueAtTime(vol, t0); g.gain.exponentialRampToValueAtTime(.001, t0 + dur);
  s.connect(fl); fl.connect(g); g.connect(MUS.bus); s.start(t0, Math.random()); s.stop(t0 + dur + .05);
}
function taiko(t0, vol) { const o = ac.createOscillator(); o.frequency.setValueAtTime(110, t0); o.frequency.exponentialRampToValueAtTime(38, t0 + .35); const g = ac.createGain(); g.gain.setValueAtTime(vol, t0); g.gain.exponentialRampToValueAtTime(.001, t0 + .6); o.connect(g); g.connect(MUS.bus); o.start(t0); o.stop(t0 + .65); mn(t0, .08, vol * .35, 'lowpass', 900); }
function schedStep(st, t) {
  const bar = Math.floor(st / 16), s = st % 16, ch = PROG[bar % 4], bl = SP16 * 16;
  if (s === 0) { for (const n of ch) { for (const dt of [-7, 0, 7]) mo('sawtooth', mtof(n + 12) * Math.pow(2, dt / 1200), t, bl * 1.05, .045, 700 + (bar % 4) * 90, 1.1); } mo('sine', mtof(ch[0] - 12), t, bl, .3, 200, .05); }
  if (s === 0 || s === 6 || s === 10) mo('sawtooth', mtof(ch[0] - 12), t, SP16 * 3, .16, 300, .01);
  if (s === 0 || s === 8) taiko(t, s === 0 ? .85 : .6); if (s === 14 && bar % 2 === 1) taiko(t, .4);
  if (s === 4 || s === 12) mn(t, .16, .22, 'bandpass', 1900); if (bar % 4 === 3 && s >= 12) mn(t, .09, .1 + (s - 12) * .06, 'bandpass', 2300);
  if (s % 4 === 2) mn(t, .035, .045, 'highpass', 7000);
  { const idx = [0, 3, 6, 8, 11, 14].indexOf(s); if (idx >= 0) mo('triangle', mtof(ch[[0, 1, 2, 1, 2, 1][idx]] + 24), t, .5, .075, 2400, .005); }
  if (bar % 4 === 2 && s === 0) { mo('sawtooth', mtof(ch[2] + 12), t, bl * .5, .06, 1000, .25); mo('sawtooth', mtof(ch[1] + 12), t + bl * .5, bl * .5, .06, 1000, .25); }
}
function musicTick() {
  if (!MUS.playing || !ac) return; if (ac.state === 'suspended') ac.resume().catch(() => { });
  try { while (MUS.next < ac.currentTime + .5) { schedStep(MUS.step, MUS.next); MUS.next += SP16; MUS.step++; } } catch (e) { }
}
function musicStart() {
  if (!MUS.on || MUS.playing || G.state !== 'menu') return; initAudio(); if (!ac || !noiseBuf) return;
  MUS.out = ac.createGain(); MUS.out.gain.value = 0; MUS.out.connect(master); MUS.out.gain.setTargetAtTime(.6, ac.currentTime, 1.4);
  const dl = ac.createDelay(1), fb = ac.createGain(), lp = ac.createBiquadFilter(); dl.delayTime.value = .46; fb.gain.value = .4; lp.type = 'lowpass'; lp.frequency.value = 1700;
  MUS.bus = ac.createGain(); MUS.bus.connect(MUS.out); MUS.bus.connect(dl); dl.connect(lp); lp.connect(fb); fb.connect(dl); lp.connect(MUS.out);
  MUS.playing = true; MUS.next = ac.currentTime + .15; MUS.step = 0; MUS.timer = setInterval(musicTick, 100); musicTick();
}
function musicStop() {
  if (!MUS.playing) return; MUS.playing = false; clearInterval(MUS.timer); const o = MUS.out; try { o.gain.setTargetAtTime(0, ac.currentTime, .35); } catch (e) { } setTimeout(() => { try { o.disconnect(); } catch (e) { } }, 2500);
}
function musicBtn() { $('btnMusic').textContent = MUS.on ? '♪ MÜZİK: AÇIK' : '♪ MÜZİK: KAPALI'; }
$('btnMusic').onclick = () => { MUS.on = !MUS.on; try { localStorage.setItem('celikCephe.mus', MUS.on ? '1' : '0'); } catch (e) { } musicBtn(); if (MUS.on) musicStart(); else musicStop(); };
musicBtn();
const firstGesture = () => { initAudio(); if (G.state === 'menu' && PROFILE && $('auth').hidden) musicStart(); };
document.addEventListener('pointerdown', firstGesture); document.addEventListener('keydown', firstGesture);

(function bootAuth() {
  let s = null; try { s = localStorage.getItem(K_SESS); } catch (e) { }
  if (s === ':guest') setProfile({ guest: true, name: 'misafir', data: Object.assign(newData(), lsGet(K_GUEST, {})) });
  else if (s) { const a = lsGet(K_ACC, { users: {} }), r = a.users[s]; if (r) setProfile({ guest: false, name: s, data: Object.assign(newData(), r.data) }); else showAuth(); }
  else showAuth();
})();
lobbyUI();
