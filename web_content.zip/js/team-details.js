// =====================================================
// NetEarn Pro - Team Member Details
// Referral Based L1 → L5
// =====================================================

import { auth, db } from "./firebase.js";

import {
    onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";

import {
    collection,
    query,
    where,
    getDocs,
    doc,
    getDoc
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";


// =====================================================
// DOM
// =====================================================

const loadingState =
    document.getElementById("loadingState");

const errorState =
    document.getElementById("errorState");

const memberContent =
    document.getElementById("memberContent");

const errorTitle =
    document.getElementById("errorTitle");

const errorMessage =
    document.getElementById("errorMessage");


// =====================================================
// URL
// =====================================================

const params =
    new URLSearchParams(window.location.search);

const memberId =
    params.get("id");


// =====================================================
// STATE
// =====================================================

let currentUser = null;
let memberData = null;


// =====================================================
// FORMAT DATE
// =====================================================

function formatDate(timestamp) {

    if (!timestamp) {
        return "N/A";
    }

    try {

        let date;

        if (
            typeof timestamp.toDate === "function"
        ) {
            date = timestamp.toDate();
        } else {
            date = new Date(timestamp);
        }

        if (isNaN(date.getTime())) {
            return "N/A";
        }

        return date.toLocaleDateString(
            "en-GB",
            {
                day: "2-digit",
                month: "short",
                year: "numeric"
            }
        );

    } catch {

        return "N/A";

    }

}


// =====================================================
// SHOW ERROR
// =====================================================

function showError(
    title = "Member Not Found",
    message = "We could not load this member."
) {

    if (loadingState) {
        loadingState.style.display = "none";
    }

    if (memberContent) {
        memberContent.style.display = "none";
    }

    if (errorState) {
        errorState.style.display = "block";
    }

    if (errorTitle) {
        errorTitle.textContent = title;
    }

    if (errorMessage) {
        errorMessage.textContent = message;
    }

}


// =====================================================
// LOAD USER
// =====================================================

async function getUser(uid) {

    const userRef =
        doc(db, "users", uid);

    const snap =
        await getDoc(userRef);

    if (!snap.exists()) {
        return null;
    }

    return {
        uid: snap.id,
        ...snap.data()
    };

}


// =====================================================
// GET DIRECT REFERRALS
// =====================================================

async function getDirectReferrals(uid) {

    try {

        const referralsRef =
            collection(db, "referrals");

        const q =
            query(
                referralsRef,
                where(
                    "referrerUid",
                    "==",
                    uid
                )
            );

        const snapshot =
            await getDocs(q);

        const result = [];

        snapshot.forEach(docSnap => {

            const data =
                docSnap.data();

            if (
                data.status &&
                data.status !== "active"
            ) {
                return;
            }

            if (!data.referredUserUid) {
                return;
            }

            result.push(
                data.referredUserUid
            );

        });

        return result;

    } catch (error) {

        console.error(
            "Referral Error:",
            error
        );

        return [];

    }

}


// =====================================================
// CALCULATE L1 → L5
// =====================================================

async function calculateTeamLevels(uid) {

    const allMembers =
        new Set();

    const levelCounts = {
        1: 0,
        2: 0,
        3: 0,
        4: 0,
        5: 0
    };

    let parents = [uid];

    for (
        let level = 1;
        level <= 5;
        level++
    ) {

        // ⚡ All parents on the same level can be queried independently.
        const referralResults =
            await Promise.all(
                parents.map(parentUid =>
                    getDirectReferrals(parentUid)
                )
            );

        const nextParents = [];

        for (const referrals of referralResults) {

            for (const childUid of referrals) {

                if (
                    childUid === uid ||
                    allMembers.has(childUid)
                ) {
                    continue;
                }

                allMembers.add(childUid);

                levelCounts[level]++;

                nextParents.push(
                    childUid
                );

            }

        }

        parents = nextParents;

        if (
            parents.length === 0
        ) {
            break;
        }

    }

    return {
        total: allMembers.size,
        levels: levelCounts,
        memberUids: Array.from(allMembers)
    };

}


// =====================================================
// UPDATE PROFILE
// =====================================================

function updateProfile(member) {

    const verified =
        member.verified === true ||
        member.verified === "true";


    const username =
        document.getElementById("username");

    const userid =
        document.getElementById("userid");

    const joinDate =
        document.getElementById("joinDate");

    const level =
        document.getElementById("level");

    const sponsor =
        document.getElementById("sponsor");

    const mobile =
        document.getElementById("mobile");

    const accountStatus =
        document.getElementById("accountStatus");

    const levelBadge =
        document.getElementById("levelBadge");

    const statusBadge =
        document.getElementById("statusBadge");

    const photo =
        document.getElementById("memberPhoto");


    // Username

    if (username) {
        username.textContent =
            member.username ||
            "Unknown";
    }


    // User ID

    if (userid) {
        userid.textContent =
            "ID : " +
            (
                member.userId ||
                member.uid ||
                "N/A"
            );
    }


    // Join date

    if (joinDate) {

        joinDate.textContent =
            formatDate(
                member.createdAt ||
                member.joinDate
            );

    }


    // Level

    const memberLevel =
        Number(
            member.level || 1
        );

    if (level) {
        level.textContent =
            "Level " +
            memberLevel;
    }

    if (levelBadge) {
        levelBadge.textContent =
            "⭐ Level " +
            memberLevel;
    }


    // Sponsor

    if (sponsor) {

        sponsor.textContent =
            member.sponsor ||
            member.referredBy ||
            "NetEarn Pro";

    }


    // Mobile

    if (mobile) {

        mobile.textContent =
            member.phone ||
            member.mobile ||
            "N/A";

    }


    // Account status

    if (accountStatus) {

        accountStatus.textContent =
            member.status ||
            (
                member.blocked
                ? "Blocked"
                : "Active"
            );

    }


    // Photo

    if (
        photo &&
        member.photoURL
    ) {

        photo.src =
            member.photoURL;

    }


    // Verification

    if (statusBadge) {

        if (verified) {

            statusBadge.textContent =
                "✅ Verified";

            statusBadge.classList.remove(
                "pending"
            );

            statusBadge.classList.add(
                "verified"
            );

        } else {

            statusBadge.textContent =
                "⏳ Pending";

            statusBadge.classList.remove(
                "verified"
            );

            statusBadge.classList.add(
                "pending"
            );

        }

    }

}


// =====================================================
// UPDATE STATISTICS
// =====================================================

async function updateStatistics(member, preloadedTeam = null) {

    // Team hierarchy only needs the member UID, which is already
    // available from the URL. Reuse a parallel preloaded result when
    // available instead of waiting for the member document first.
    const team =
        preloadedTeam ||
        await calculateTeamLevels(
            member.uid
        );


    const totalTeam =
        document.getElementById(
            "totalTeam"
        );

    const verifiedTeam =
        document.getElementById(
            "verifiedTeam"
        );

    const pendingTeam =
        document.getElementById(
            "pendingTeam"
        );

    const reward =
        document.getElementById(
            "reward"
        );


    if (totalTeam) {
        totalTeam.textContent =
            team.total;
    }


    // For this page we only show
    // actual team counts.
    // Verification totals are calculated
    // from the members inside L1 → L5.

    let verified = 0;

    let pending = 0;

    // ⚡ calculateTeamLevels already discovered every team member.
    // Reuse those UIDs instead of running the same referral queries again.
    // User documents are independent, so fetch them in parallel.
    const childUsers =
        await Promise.all(
            (team.memberUids || []).map(
                childUid => getUser(childUid)
            )
        );

    for (const child of childUsers) {

        if (!child) {
            continue;
        }

        const isVerified =
            child.verified === true ||
            child.verified === "true";

        if (isVerified) {
            verified++;
        } else {
            pending++;
        }

    }

    if (verifiedTeam) {
        verifiedTeam.textContent =
            verified;
    }


    if (pendingTeam) {
        pendingTeam.textContent =
            pending;
    }


    // Reward
    // Only the existing referral commission
    // is shown. No new team commission is created.

    const commission =
        Number(
            member.referralCommission ||
            member.reward ||
            0
        );


    if (reward) {

        reward.textContent =
            "৳" +
            commission.toLocaleString(
                "en-BD"
            );

    }


    // Level cards

    const levelIds = {
        1: "level1",
        2: "level2",
        3: "level3",
        4: "level4",
        5: "level5"
    };


    for (
        let level = 1;
        level <= 5;
        level++
    ) {

        const element =
            document.getElementById(
                levelIds[level]
            );

        if (!element) {
            continue;
        }

        const count =
            team.levels[level] || 0;

        element.textContent =
            count +
            (
                count === 1
                ? " Member"
                : " Members"
            );

    }

}


// =====================================================
// LOAD MEMBER
// =====================================================

async function loadMember() {

    if (!memberId) {

        showError(
            "Invalid Member",
            "No member ID was provided."
        );

        return;

    }


    try {

        // The member document and its team statistics are independent
        // reads. Start both together to remove the sequential wait.
        const [member, team] =
            await Promise.all([
                getUser(memberId),
                calculateTeamLevels(memberId)
            ]);


        if (!member) {

            showError(
                "Member Not Found",
                "This team member does not exist."
            );

            return;

        }


        memberData =
            member;


        updateProfile(
            member
        );


        await updateStatistics(
            member,
            team
        );


        // Show content

        if (loadingState) {
            loadingState.style.display =
                "none";
        }

        if (errorState) {
            errorState.style.display =
                "none";
        }

        if (memberContent) {
            memberContent.style.display =
                "block";
        }


    } catch (error) {

        console.error(
            "Team Details Error:",
            error
        );


        showError(
            "Loading Failed",
            "Something went wrong while loading this member."
        );

    }

}


// =====================================================
// AUTH
// =====================================================

onAuthStateChanged(
    auth,
    async user => {

        if (!user) {

            window.location.href =
                "index.html";

            return;

        }


        currentUser =
            user;


        await loadMember();

    }
);