/**
 * Utilitários puros do aplicativo Contagem Regressiva
 * Funções genéricas de formatação, cores, sanitização e manipulação de datas sem estado global.
 * Compatível com ambientes de navegador, WebView Android (file:// e http://) e empacotamento nativo.
 */
(function(root){
  var U = {};

  // Formatação com zero à esquerda
  U.pad = function(n){
    return n < 10 ? "0" + n : String(n);
  };

  // Gerador de identificador único
  U.uid = function(){
    return "c" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  };

  // Conversão de data de item para Date
  U.tgt = function(it){
    return new Date(it.date + "T" + it.time);
  };

  // Formatação de data em string YYYY-MM-DD segura e pura
  U.dstr = function(ts){
    var d = new Date(ts || Date.now());
    return d.getFullYear() + "-" + U.pad(d.getMonth() + 1) + "-" + U.pad(d.getDate());
  };

  // Sanitização de texto HTML contra injeção
  U.esc = function(t){
    return String(t).replace(/[&<>"']/g, function(c){
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  };

  // Validação de string base64 de imagem
  U.okImg = function(u){
    return typeof u === "string" && u.length < 900000 && /^data:image\/(png|jpe?g|webp|gif);base64,[A-Za-z0-9+\/=]+$/.test(u);
  };

  // Validação de cor hexadecimal de 6 dígitos (#RRGGBB)
  U.hexOk = function(c){
    return typeof c === "string" && /^#[0-9a-fA-F]{6}$/.test(c);
  };

  // Conversão hex para rgba
  U.rgba = function(h, a){
    var n = parseInt(h.slice(1), 16);
    return "rgba(" + (n >> 16) + "," + (n >> 8 & 255) + "," + (n & 255) + "," + a + ")";
  };

  // Interpolação/mistura linear de duas cores hexadecimais
  U.mixHex = function(a, b, t){
    var x = parseInt(a.slice(1), 16), y = parseInt(b.slice(1), 16);
    var r = Math.round((x >> 16) * (1 - t) + (y >> 16) * t);
    var g = Math.round((x >> 8 & 255) * (1 - t) + (y >> 8 & 255) * t);
    var bl = Math.round((x & 255) * (1 - t) + (y & 255) * t);
    return "#" + ((1 << 24) + (r << 16) + (g << 8) + bl).toString(16).slice(1);
  };

  // Hash matemático de string (usado para PIN de segurança)
  U.hash = function(s){
    var h = 5381;
    s = "cd" + s;
    for (var i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) >>> 0;
    return "h" + h.toString(36);
  };

  // Sanitização de identificador de classe css
  U.cls = function(x){
    return /^[a-z]+$/.test(x) ? x : "none";
  };

  // Criação de elemento DOM auxiliar
  U.mk = function(t, c, x){
    var e = document.createElement(t);
    if (c) e.className = c;
    if (x !== undefined) e.textContent = x;
    return e;
  };

  // Conversão de Blob para Data URL (Base64)
  U.b2d = function(b){
    return new Promise(function(res){
      var fr = new FileReader();
      fr.onload = function(){ res(fr.result); };
      fr.onerror = function(){ res(""); };
      fr.readAsDataURL(b);
    });
  };

  // Conversão de Data URL para Blob
  U.d2b = function(u){
    var m = /^data:([^;]+);base64,(.*)$/.exec(u);
    if (!m) return null;
    try {
      var s = atob(m[2]), a = new Uint8Array(s.length);
      for (var i = 0; i < s.length; i++) a[i] = s.charCodeAt(i);
      return new Blob([a], { type: m[1] });
    } catch(e) {
      return null;
    }
  };

  // Normalização de URL
  U.normUrl = function(u){
    u = String(u || "").trim();
    if (/^https?:\/\/[^\s]+$/i.test(u)) return u;
    if (/^[\w-]+(\.[\w-]+)+(\/\S*)?$/.test(u)) return "https://" + u;
    return "";
  };

  // Extração de hostname limpo de uma URL
  U.hostOf = function(u){
    try {
      return new URL(u).hostname.replace(/^www\./, "");
    } catch(e) {
      return u;
    }
  };

  root.AppUtils = U;
})(typeof window !== "undefined" ? window : this);
