/* ===================================================================
 * VFL.Utils
 * توابع کمکی عمومی — بدون وابستگی به UI یا داده خاص
 * =================================================================== */
(function (VFL) {
  "use strict";

  VFL.Utils = {
    clone: function (obj) {
      return JSON.parse(JSON.stringify(obj));
    },

    uid: function (prefix) {
      return (prefix || "id") + "_" + Math.random().toString(36).slice(2, 10);
    },

    faDigits: function (input) {
      var fa = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];
      return String(input).replace(/[0-9]/g, function (d) { return fa[d]; });
    },

    // یک ردیف خالی جدول برای یک تیم می‌سازد
    emptyStandingRow: function (teamId) {
      return {
        teamId: teamId,
        played: 0, win: 0, draw: 0, loss: 0,
        goalsFor: 0, goalsAgainst: 0,
        get goalDiff() { return this.goalsFor - this.goalsAgainst; },
        get points() { return this.win * 3 + this.draw; }
      };
    },

    // مرتب‌سازی جدول: امتیاز > تفاضل گل > گل زده
    sortStandings: function (rows) {
      return rows.slice().sort(function (a, b) {
        if (b.points !== a.points) return b.points - a.points;
        if (b.goalDiff !== a.goalDiff) return b.goalDiff - a.goalDiff;
        if (b.goalsFor !== a.goalsFor) return b.goalsFor - a.goalsFor;
        return 0;
      });
    },

    weekLabel: function (week) {
      return "هفته " + VFL.Utils.faDigits(week);
    },

    // خط توضیح بازیکن (پست · سن · کشور) — فیلدهای نامشخص را با «نامشخص» جایگزین می‌کند
    // به‌جای حدس زدن (برای بازیکنانی که فقط شماره پیراهن + Overall داده شده‌اند)
    playerSubLabel: function (p) {
      var pos = p.position || "نامشخص";
      var age = (p.age !== null && p.age !== undefined) ? VFL.Utils.faDigits(p.age) + " سال" : "سن نامشخص";
      var country = p.country || "کشور نامشخص";
      return pos + " · " + age + " · " + country;
    },

    // برچسب شماره پیراهن برای نمایش کنار نام بازیکن (اگر مشخص نشده باشد چیزی نشان نمی‌دهد)
    shirtLabel: function (p) {
      return (p.shirtNumber !== null && p.shirtNumber !== undefined) ? "#" + VFL.Utils.faDigits(p.shirtNumber) : "";
    }
  };
})(window.VFL || (window.VFL = {}));
