/* Studio – celoobrazovkový editor nepřátel a věží (zapíná se příkazem „studio“ v terminálu, pak je v menu).
   Vlevo seznam, uprostřed malé hřiště se zoomem (živý náhled, osy, mřížka, dosah, skutečná velikost),
   vpravo záložky: Vzhled (strom vrstev), Vlastnosti (čísla a mechaniky), Vlny (kdy se nepřítel objeví).
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  var S = BD.studio, SP = BD.render.sprite, TAU = Math.PI * 2, CELL = 26;

  /* jedno číselné pole: posuvník + číslo */
  var Num = {
    props: { modelValue: Number, label: String, min: Number, max: Number, step: { type: Number, default: 0.01 }, slider: { type: Boolean, default: true } },
    emits: ['update:modelValue'],
    template: '<label class="sn"><span>{{ label }}</span><input v-if="slider" type="range" :min="min" :max="max" :step="step" :value="modelValue" @input="set($event.target.value)"><input class="in n" type="number" :min="min" :max="max" :step="step" :value="modelValue" @change="set($event.target.value)"></label>',
    methods: { set: function (v) { v = Number(v); if (!isFinite(v)) return; this.$emit('update:modelValue', Math.min(this.max, Math.max(this.min, v))); } },
  };
  /* tlačítko barvy: vzorek + kód, po kliknutí vyskočí vlastní ColorPicker (js/ui/colorpicker.js) */
  var CBtn = {
    props: { modelValue: String, alpha: { type: Boolean, default: true } },
    emits: ['update:modelValue'],
    template: '<button type="button" class="cbtn" :class="{on: on}" @click="toggle" title="Vybrat barvu"><i><b :style="{\'--c\': modelValue}"></b></i><code>{{ txt }}</code></button>',
    data: function () { return { on: false }; },
    computed: { txt: function () { var p = BD.ui.colorPicker.parse(this.modelValue); return p ? BD.ui.colorPicker.format(p.r, p.g, p.b, p.a, this.alpha).toUpperCase() : String(this.modelValue || ''); } },
    methods: {
      toggle: function () {
        var me = this; if (this.on) { BD.ui.colorPicker.close(); return; }
        this.on = true;
        BD.ui.colorPicker.open(this.$el, this.modelValue, { alpha: this.alpha, onChange: function (v) { me.$emit('update:modelValue', v); }, onClose: function () { me.on = false; } });
      },
    },
    beforeUnmount: function () { if (this.on) BD.ui.colorPicker.close(); },
  };
  var Col = {
    components: { 'stu-cbtn': CBtn },
    props: { modelValue: String, label: String, alpha: { type: Boolean, default: true } },
    emits: ['update:modelValue'],
    template: '<div class="sn"><span>{{ label }}</span><stu-cbtn :model-value="modelValue" :alpha="alpha" @update:model-value="$emit(\'update:modelValue\', $event)"></stu-cbtn></div>',
  };

  /* schránka tvarů Studia: v paměti + v localStorage (přežije přepnutí položky i obnovení stránky) */
  var CLIP_KEY = 'bd.studio.clip.v1', clipMem = null;
  function readClip() {
    if (clipMem) return clipMem;
    try { var o = JSON.parse(localStorage.getItem(CLIP_KEY) || 'null'); if (o && o.type === 'studio-shapes' && Array.isArray(o.nodes) && o.nodes.length) return (clipMem = o); } catch (e) { /* bez úložiště */ }
    return null;
  }
  function writeClip(o) { clipMem = o; try { localStorage.setItem(CLIP_KEY, JSON.stringify(o)); } catch (e) { /* bez úložiště */ } }
  function heightOf(n) { var m = 0; (n.children || []).forEach(function (c) { m = Math.max(m, heightOf(c)); }); return 1 + m; }

  BD.ui.components.StudioView = {
    components: { 'stu-num': Num, 'stu-col': Col, 'stu-cbtn': CBtn },
    emits: ['back', 'test'],
    template: `
<div class="stv">
  <div class="stv-head">
    <button class="btn" @click="$emit('back')" data-act="stu-back"><ic n="back"></ic> Menu</button>
    <h2>Studio</h2><span class="pill">dev · {{ ver }}</span>
    <div class="stv-tabs"><template v-for="(t, i) in tabs" :key="t.id"><i class="tsep" v-if="i && tabs[i - 1].g !== t.g" data-role="tab-sep"></i><button :class="{on: S.ui.tab === t.id}" @click="setTab(t.id)" :data-tab="t.id">{{ t.label }}</button></template></div>
    <div class="sp"></div>
    <button class="btn sm" :class="{on: ioOpen}" @click="ioOpen = !ioOpen" data-act="stu-io"><ic n="copy"></ic> Export / Import</button>
    <button class="btn primary sm" v-if="cur && S.ui.tab !== 'templates' && S.ui.tab !== 'ammo'" @click="test" data-act="stu-test"><ic n="play"></ic> Zkusit ve hře</button>
  </div>

  <div class="stv-io" v-if="ioOpen">
    <textarea class="in" v-model="ioText" rows="5" spellcheck="false" placeholder="Sem vlož export ze Studia… nebo stiskni Zobrazit export" data-role="stu-text"></textarea>
    <div class="stv-iob">
      <label class="chk" v-if="cur"><input type="checkbox" v-model="ioOne" data-role="io-one"> jen vybraná položka ({{ cur.name }})</label>
      <button class="btn sm" @click="showExport" data-act="stu-show">Zobrazit export</button>
      <button class="btn sm" @click="copyExport" data-act="stu-copy"><ic n="copy"></ic> Kopírovat</button>
      <button class="btn sm" @click="downloadExport" data-act="stu-download"><ic n="download"></ic> Stáhnout</button>
      <button class="btn sm primary" :disabled="!ioText.trim()" @click="doImport" data-act="stu-import"><ic n="upload"></ic> Načíst</button>
      <span :class="ioErr ? 'err' : 'okk'" v-if="ioMsg" data-role="stu-msg">{{ ioMsg }}</span>
    </div>
  </div>

  <div class="stv-body">
    <div class="stu-list">
      <template v-if="S.ui.tab === 'towers'">
        <div class="stu-cat" data-cat="start">
          <button class="stu-cath" @click="tfold.start = !tfold.start" data-cat-h="start"><span class="fa">{{ tfold.start ? '▸' : '▾' }}</span><b>Basic Tower</b></button>
          <template v-if="!tfold.start">
            <p class="stu-cathint">Základna: věž, která se staví rovnou. Je jedna jediná.</p>
            <div class="stu-trow" v-if="S.KINDS.towers.base"><i class="fold"></i>
              <button class="stu-item inl" :class="{on: S.ui.sel === 'base'}" @click="S.ui.sel = 'base'" data-id="base"><i class="dot" :style="{background: S.value('towers', 'base', 'color')}"></i><span class="nm">{{ S.value('towers', 'base', 'name') || 'base' }}</span><em v-if="S.touched('towers', 'base')" class="chg">upraveno</em></button></div>
          </template>
        </div>
        <div class="stu-cat" data-cat="kinds">
          <button class="stu-cath" @click="tfold.kinds = !tfold.kinds" data-cat-h="kinds"><span class="fa">{{ tfold.kinds ? '▸' : '▾' }}</span><b>Upgrades</b><small>{{ treeRows.length || '' }}</small></button>
          <template v-if="!tfold.kinds">
            <p class="stu-cathint">Věž a pod ní (odsazeně) její další vylepšení. Přetáhni věž na jinou = bude její vylepšení; nad / pod řádek = změna pořadí.</p>
            <div class="stu-trow" v-for="r in treeRows" :key="r.id" :style="{paddingLeft: 4 + r.depth * 16 + 'px'}" :data-row="r.id"
              :class="[{on: S.ui.sel === r.id, dragging: dragT && dragT.id === r.id}, dragT && dragT.over === r.id ? 'dz-' + dragT.zone : '']"
              draggable="true" @dragstart="tDragStart($event, r.id)" @dragover.prevent="tDragOver($event, r.id)" @drop.prevent="tDrop($event, r.id)" @dragend="dragT = null">
              <button class="fold" v-if="r.kids" @click.stop="tfold[r.id] = !tfold[r.id]" :data-tfold="r.id" :title="tfold[r.id] ? 'Rozbalit' : 'Sbalit'">{{ tfold[r.id] ? '▸' : '▾' }}</button><i class="fold" v-else></i>
              <button class="stu-item inl" :class="{on: S.ui.sel === r.id}" @click="S.ui.sel = r.id" :data-id="r.id">
                <i class="dot" :style="{background: S.value('towers', r.id, 'color')}"></i>
                <span class="nm">{{ S.value('towers', r.id, 'name') || r.id }}</span>
                <b class="wn" v-if="weakerList(r.id).length" :title="'Slabší než rodič: ' + weakerList(r.id).join(', ')" data-role="weak">⚠</b>
                <em v-if="!S.isBuiltin('towers', r.id)">nový</em><em v-else-if="S.touched('towers', r.id)" class="chg">upraveno</em>
              </button>
            </div>
            <button class="btn sm stu-restore" v-if="deletedTowers.length" @click="restoreAll" data-act="stu-restore">Obnovit smazané věže ({{ deletedTowers.length }})</button>
          </template>
        </div>
        <div class="stu-cat" data-cat="combo">
          <button class="stu-cath" @click="tfold.combo = !tfold.combo" data-cat-h="combo"><span class="fa">{{ tfold.combo ? '▸' : '▾' }}</span><b>Combinations</b></button>
          <p class="stu-cathint" v-if="!tfold.combo">Později: spojené věže (např. 4 věže 2×2 → jedna lepší s novým vzhledem) a výjimečné tvary (H, T, I…) s unikátními zbraněmi. Strom tu bude fungovat stejně.</p>
        </div>
      </template>
      <template v-else>
      <button class="stu-item" v-for="id in ids" :key="id" :class="{on: S.ui.sel === id}" @click="S.ui.sel = id" :data-id="id">
        <i class="dot" :style="{background: S.value(S.ui.tab, id, 'color')}"></i>
        <span class="nm">{{ S.value(S.ui.tab, id, 'name') || id }}</span>
        <em v-if="!S.isBuiltin(S.ui.tab, id)">nový</em><em v-else-if="S.touched(S.ui.tab, id)" class="chg">upraveno</em>
      </button>
      </template>
      <div class="stu-new">
        <input class="in" v-model="newId" maxlength="20" placeholder="Název nové položky" spellcheck="true" @keydown.enter="create" data-role="stu-newid">
        <button class="btn sm primary" @click="create" data-act="stu-create"><ic n="plus"></ic> {{ S.ui.tab === 'enemies' ? 'Nový nepřítel' : S.ui.tab === 'templates' ? 'Nová šablona' : S.ui.tab === 'ammo' ? 'Nové střelivo' : 'Nové vylepšení' }}</button>
        <div class="hint" v-if="S.ui.tab === 'templates'">Šablona je vzhled, který pak vložíš do věže nebo nepřítele tvarem „Šablona“. Změníš ji na jednom místě a změní se všude, kde je vložená. Šablonu jde vložit i do jiné šablony (ne do sebe sama).</div>
        <div class="hint" v-if="S.ui.tab === 'ammo'">Střelivo = jak střela vypadá a letí: výstřel u věže, let a dopad. Přiřadíš ho věži ve Vlastnostech věže (pole Střelivo). „Výchozí střela“ platí pro věže bez vlastního střeliva a nejde smazat.</div>
        <div class="hint" v-if="S.ui.tab === 'towers' && cur">Vznikne jako vylepšení věže „{{ cur.name }}“ (jde pak přetáhnout jinam).</div>
        <div class="err" v-if="newErr">{{ newErr }}</div>
      </div>
    </div>

    <div class="stv-mid">
      <div class="pv-bar" v-if="cur">
        <button class="btn sm" @click="zoomBy(1 / 1.4)" title="Oddálit">−</button>
        <span class="pill zl" data-role="zoom">×{{ zoomLabel }}</span>
        <button class="btn sm" @click="zoomBy(1.4)" title="Přiblížit">+</button>
        <button class="btn sm" @click="fitView" title="Vycentrovat a přiblížit">Vycentrovat</button>
        <i class="sepv"></i>
        <button class="btn sm" :class="{on: view.axes}" @click="view.axes = !view.axes" data-act="v-axes">Osy</button>
        <button class="btn sm" :class="{on: view.grid}" @click="view.grid = !view.grid" data-act="v-grid">Mřížka</button>
        <button class="btn sm" :class="{on: view.guides}" @click="view.guides = !view.guides" data-act="v-guides" title="Rámečky o velikosti N×N buněk herního pole">Míry</button>
        <span class="bxs" v-if="view.guides"><button class="btn sm" v-for="n in sizeChoices" :key="n" :class="{on: boxes.indexOf(n) >= 0}" @click="toggleBox(n)" :data-box="n" :title="'Rámeček ' + n + '×' + n + ' buněk'">{{ n }}×{{ n }}</button>
          <input class="in sm" type="number" min="1" max="60" v-model.number="customBox" @change="addCustomBox" placeholder="N" data-role="box-custom" title="Vlastní velikost N×N (1–60) + Enter">
          <button class="btn sm" :class="{on: phaseNow() === 'corner'}" @click="view.phase = phaseNow() === 'corner' ? 'center' : 'corner'" data-act="v-phase" title="Kde leží střed postavy vůči mřížce">střed: {{ phaseNow() === 'corner' ? 'roh buněk' : 'střed buňky' }}</button></span>
        <button class="btn sm" :class="{on: view.target}" @click="view.target = !view.target" data-act="v-target" title="Smyšlený cíl, který obíhá kolem objektu a ukazuje, kam míří předek">Cíl</button>
        <label class="aimin" v-if="view.target && !view.anim" title="Směr cíle, když stojí animace">směr cíle <input class="in sm" type="number" min="-180" max="180" v-model.number="view.aimDeg" data-role="aim-deg">°</label>
        <button class="btn sm" :class="{on: view.range}" @click="view.range = !view.range" data-act="v-range">Dosah</button>
        <button class="btn sm" :class="{on: view.anim}" @click="view.anim = !view.anim" data-act="v-anim">Animace</button>
        <button class="btn sm" :class="{on: view.real}" @click="view.real = !view.real" data-act="v-real">Skutečná velikost</button>
        <button class="btn sm" :class="{on: view.light}" @click="view.light = !view.light" data-act="v-bg">Světlé pozadí</button>
        <div class="sp"></div><small class="hint" data-role="pos">{{ posText }}</small>
      </div>
      <div class="pv-wrap" ref="wrap"><canvas ref="cv" class="pv-cv" data-role="pv"
        @pointerdown="pDown" @pointermove="pMove" @pointerup="pUp" @pointercancel="pUp" @wheel.prevent="pWheel" @contextmenu.prevent></canvas></div>
      <div class="am-prev" v-if="S.ui.tab === 'ammo' && cur" data-role="am-prev">
        <canvas ref="acv" class="am-cv" data-role="am-cv"></canvas>
        <div class="am-ctl">
          <button class="btn sm" @click="ap.play = !ap.play" data-act="am-play">{{ ap.play ? '❚❚ Pauza' : '▶ Přehrát' }}</button>
          <input type="range" ref="ascrub" min="0" :max="apTotal" step="0.01" value="0" @input="apScrub($event.target.value)" data-role="am-scrub">
          <span class="am-seg" data-role="am-seg"><b class="m">výstřel {{ fix(cur.muzzle && cur.muzzle.dur) }} s</b><b class="f">let {{ fix(apFlight) }} s</b><b class="i">dopad {{ fix(cur.impact && cur.impact.dur) }} s</b></span>
        </div>
      </div>
    </div>

    <div class="stv-side" v-if="cur">
      <label class="stv-name"><span>Název</span><input class="in" :value="cur.name" maxlength="24" @input="S.set(S.ui.tab, S.ui.sel, 'name', $event.target.value)" data-role="stu-name" placeholder="Název"></label>
      <div class="stv-ptabs">
        <button :class="{on: panel === 'look'}" @click="panel = 'look'" data-panel="look">Vzhled</button>
        <button :class="{on: panel === 'props'}" @click="panel = 'props'" data-panel="props" v-if="S.ui.tab !== 'templates'">Vlastnosti</button>
        <button :class="{on: panel === 'waves'}" @click="panel = 'waves'" v-if="S.ui.tab === 'enemies'" data-panel="waves">Vlny</button>
      </div>
      <div class="stv-pane">

        <!-- ======= VZHLED ======= -->
        <template v-if="panel === 'look'">
          <div class="am-ph" v-if="S.ui.tab === 'ammo'" data-role="am-ph"><button v-for="p in phases" :key="p.id" :class="{on: ph === p.id}" @click="ph = p.id" :data-ph="p.id">{{ p.label }}</button></div>
          <div v-if="!sp" class="stv-nolook">
            <p class="hint" v-if="S.ui.tab === 'ammo'">Fáze „{{ phaseLabel }}“ nemá vlastní tvar{{ ph === 'shot' ? ' – střela se kreslí jako původní kulička' : ' – nic se nekreslí' }}. Nakresli ji z vrstev; +x (doprava) je směr střelby.</p>
            <p class="hint" v-else>{{ cur.name }} se zatím kreslí původním způsobem hry. Vlastní vzhled se skládá z vrstev: tvarů s přechodem, okrajem, stínem a animací.</p>
            <button class="btn primary" @click="makeLook(true)" data-act="look-from"><ic n="plus"></ic> Začít ze současného vzhledu</button>
            <button class="btn" @click="makeLook(false)" data-act="look-empty">Začít prázdný</button>
            <div class="stv-copy" v-if="copySources.length"><span>nebo převzít vzhled z</span>
              <select class="btn sm" v-model="copySrc" data-role="copy-src"><option value="">— vyber —</option><option v-for="o in copySources" :key="o.v" :value="o.v">{{ o.label }}</option></select>
              <button class="btn sm primary" :disabled="!copySrc" @click="copyLookFrom" data-act="look-copy">Zkopírovat</button></div>
          </div>
          <template v-else>
            <div class="stv-copy" v-if="copySources.length"><span>Převzít vzhled z</span>
              <select class="btn sm" v-model="copySrc" data-role="copy-src"><option value="">— jiná položka —</option><option v-for="o in copySources" :key="o.v" :value="o.v">{{ o.label }}</option></select>
              <button class="btn sm" :disabled="!copySrc" @click="copyLookFrom" data-act="look-copy" title="Nahradí právě upravovaný vzhled kopií vybraného (jde vrátit tlačítkem Zpět)">Nahradit kopií</button></div>
            <div class="ly-add"><button class="btn sm shp" v-for="t in addList" :key="t" @click="addNode(t)" :data-add="t" :disabled="nodeFull || (t === 'ref' && refFull)" :aria-label="names[t]" :title="t === 'ref' ? 'Šablona - vložit šablonu (vytvoříš ji v záložce Šablony)' : names[t]" v-html="shapeIcon(t)"></button></div>
            <div class="ly-cnt" :class="{warn: nodeCount >= nodeLimit * 0.85, full: nodeFull}" data-role="node-count" :title="'Nejvíc ' + nodeLimit + ' vrstev na jeden vzhled (skupiny i šablony se počítají jako jedna vrstva)'">
              <i><b :style="{width: Math.min(100, nodeCount / nodeLimit * 100) + '%'}"></b></i><span>{{ nodeCount }} / {{ nodeLimit }} vrstev</span><small v-if="nodeFull">plno</small><small v-else-if="nodeCount >= nodeLimit * 0.85">už jich moc nezbývá</small>
              <small class="lm" v-if="limMsg" data-role="lim-msg">{{ limMsg }}</small></div>
            <div class="ly-tools">
              <button class="btn sm" :disabled="!selNode" @click="moveZ(1)" title="Výš (blíž k divákovi)" data-act="ly-up">↑</button>
              <button class="btn sm" :disabled="!selNode" @click="moveZ(-1)" title="Níž" data-act="ly-down">↓</button>
              <button class="btn sm" :disabled="!selNode" @click="wrapGroup" title="Seskupit vybrané vrstvy do nové skupiny" data-act="ly-wrap">Seskupit<span v-if="selCount > 1"> ({{ selCount }})</span></button>
              <button class="btn sm" :disabled="!selNode" @click="dupNode" data-act="ly-dup">Kopie</button>
              <button class="btn sm" :disabled="!selNode" @click="clipCopy" data-act="clip-copy" title="Zkopíruje vybrané tvary do schránky Studia (Ctrl+C) - vložíš je i do jiné věže nebo nepřítele">Kopírovat</button>
              <button class="btn sm" :disabled="!clipHas" @click="clipPaste" data-act="clip-paste" title="Vloží tvary ze schránky Studia (Ctrl+V)">Vložit</button>
              <button class="btn sm" :disabled="!undo.length" @click="doUndo" data-act="ly-undo" title="Zpět (Ctrl+Z)">Zpět</button>
              <button class="btn sm danger" :disabled="!selNode" @click="delNode" data-act="ly-del"><ic n="trash"></ic></button>
            </div>
            <div class="ly-list" data-role="layers">
              <div class="ly-hint" v-if="rows.length">nahoře = vepředu · Ctrl+klik = přidat/odebrat, Shift+klik = rozsah · tažením přesuneš / vložíš do skupiny
                <span class="fbt"><button class="btn sm" @click="setAllFold(true)" data-act="fold-all">Sbalit vše</button><button class="btn sm" @click="setAllFold(false)" data-act="unfold-all">Rozbalit vše</button><button class="btn sm" @click="selectAll" data-act="sel-all">Vybrat vše</button></span></div>
              <div class="ly" v-for="r in rows" :key="r.n.id" :class="[{on: selMap[r.n.id], main: selId === r.n.id, isgrp: r.n.type === 'group', off: r.n.visible === false, dragging: dnd && dnd.ids.indexOf(r.n.id) >= 0}, dnd && dnd.over === r.n.id ? 'dz-' + dnd.zone : '']" :style="{paddingLeft: 6 + r.depth * 14 + 'px'}" @click="clickRow($event, r)" :data-node="r.n.id"
                draggable="true" @dragstart="dragStart($event, r.n)" @dragover.prevent="dragOver($event, r.n)" @drop.prevent="dropOn($event, r.n)" @dragend="dnd = null">
                <button class="eye" @click.stop="r.n.visible = r.n.visible === false; touch()" :title="r.n.visible === false ? 'Zobrazit' : 'Skrýt'">{{ r.n.visible === false ? '○' : '●' }}</button>
                <button class="fold" v-if="r.n.type === 'group' && r.n.children.length" @click.stop="fold[r.n.id] = !fold[r.n.id]" :title="fold[r.n.id] ? 'Rozbalit skupinu' : 'Sbalit skupinu'" :data-fold="r.n.id">{{ fold[r.n.id] ? '▸' : '▾' }}</button><i class="fold" v-else></i>
                <span class="ty">{{ glyph[r.n.type] }}</span><span class="nm">{{ r.n.name }}</span><small class="cnt" v-if="r.n.type === 'group' && r.n.children.length && fold[r.n.id]">({{ r.n.children.length }})</small><em v-if="r.n.anim && r.n.anim.t !== 'none'">{{ animName[r.n.anim.t] }}</em>
              </div>
            </div>
            <div class="ly-bulk" v-if="selCount > 1" data-role="bulk">
              <h4>Hromadná úprava ({{ selCount }} vybraných)</h4>
              <div class="row"><stu-num label="Posun x" v-model="bulk.dx" :min="-4" :max="4"></stu-num><stu-num label="Posun y" v-model="bulk.dy" :min="-4" :max="4"></stu-num><button class="btn sm" @click="bulkMove" data-act="bulk-move">Posunout</button></div>
              <div class="row"><stu-num label="Otočit °" v-model="bulk.rot" :min="-180" :max="180" :step="1"></stu-num><button class="btn sm" @click="bulkRotate" data-act="bulk-rot">Otočit</button>
                <label class="chk"><input type="checkbox" v-model="bulk.pivot" data-role="bulk-pivot"> kolem společného středu</label></div>
              <div class="row"><stu-num label="Velikost %" v-model="bulk.scale" :min="10" :max="400" :step="5"></stu-num><button class="btn sm" @click="bulkScale" data-act="bulk-scale">Změnit velikost</button></div>
              <stu-col label="Výplň (všem)" :model-value="bulk.fill" :alpha="false" @update:model-value="bulk.fill = $event; bulkFill()" data-role="bulk-fill"></stu-col>
              <stu-col label="Okraj (všem)" :model-value="bulk.stroke" :alpha="false" @update:model-value="bulk.stroke = $event; bulkStroke(true)" data-role="bulk-stroke"></stu-col>
              <div class="row"><stu-num label="Tloušťka okraje" v-model="bulk.sw" :min="0" :max="0.4"></stu-num><button class="btn sm" @click="bulkStroke(false)" data-act="bulk-sw">Použít</button></div>
              <div class="row"><stu-num label="Průhlednost" v-model="bulk.alpha" :min="0" :max="1"></stu-num><button class="btn sm" @click="bulkAlpha" data-act="bulk-alpha">Použít</button></div>
            </div>
            <div class="ly-tools2" v-if="selNode">
              <p class="hint" v-if="selCount > 1">Vybráno {{ selCount }} vrstev. Smazání, seskupení, přesun, kopie, zrcadlení i opakování platí pro všechny; vlastnosti níže upravují jen „{{ selNode.name }}“.</p>
              <h4>Zrcadlení</h4>
              <label class="sn"><span>Osa</span><select class="btn" v-model.number="tm.ang" data-role="tm-ang"><option :value="90">svislá (zrcadlí vlevo/vpravo)</option><option :value="0">vodorovná (nahoře/dole)</option><option :value="45">úhlopříčka ╲ 45°</option><option :value="-45">úhlopříčka ╱ −45°</option></select></label>
              <stu-num label="Úhel osy °" v-model="tm.ang" :min="-180" :max="180" :step="1"></stu-num>
              <stu-num label="Střed x" v-model="tm.cx" :min="-4" :max="4"></stu-num>
              <stu-num label="Střed y" v-model="tm.cy" :min="-4" :max="4"></stu-num>
              <div class="row"><button class="btn sm" @click="mirrorCopy(false)" data-act="mir-copy" title="Přidá zrcadlový obraz vybraného tvaru">Zrcadlová kopie</button>
                <button class="btn sm" @click="mirrorCopy(true)" data-act="mir-self" title="Zrcadlí samotný tvar">Převrátit tvar</button></div>
              <h4>Opakovat kolem středu</h4>
              <stu-num label="Počet kusů" v-model="tr.n" :min="2" :max="24" :step="1"></stu-num>
              <stu-num label="Rozsah °" v-model="tr.sweep" :min="10" :max="360" :step="5"></stu-num>
              <stu-num label="Střed x" v-model="tr.cx" :min="-4" :max="4"></stu-num>
              <stu-num label="Střed y" v-model="tr.cy" :min="-4" :max="4"></stu-num>
              <div class="row"><button class="btn sm" @click="repeatRadial" data-act="rep-radial">Vytvořit kopie</button>
                <label class="chk"><input type="checkbox" v-model="view.toolGuides"> ukázat osu a střed</label></div>
            </div>
            <div class="ly-props" v-if="selNode" @input="touch" @change="touch" :key="selNode.id">
              <h3>{{ selNode.name }}</h3>
              <label class="sn"><span>Název</span><input class="in" v-model="selNode.name" maxlength="24"></label>
              <label class="sn"><span>Rodič</span><select class="btn" :value="parentId" @change="reparent($event.target.value)"><option value="">— nejvyšší úroveň —</option><option v-for="g in groupsFor" :key="g.id" :value="g.id">{{ g.name }}</option></select></label>
              <h4>Poloha a velikost</h4>
              <stu-num label="x" v-model="selNode.x" :min="-4" :max="4"></stu-num>
              <stu-num label="y" v-model="selNode.y" :min="-4" :max="4"></stu-num>
              <stu-num label="Otočení °" v-model="selNode.rot" :min="-180" :max="180" :step="1"></stu-num>
              <template v-if="selNode.type === 'ref'">
                <label class="sn"><span>Šablona</span><select class="btn" v-model="selNode.ref" @change="refPicked" data-role="ref-pick"><option value="">— vyber šablonu —</option><option v-for="id in tplIds" :key="id" :value="id">{{ S.value('templates', id, 'name') }}</option></select></label>
                <p class="hint err" v-if="selNode.ref && !tplIds.includes(selNode.ref)" data-role="ref-missing">Tahle šablona už neexistuje, nic se nekreslí.</p>
                <p class="hint" v-else-if="!tplIds.length">Zatím nemáš žádnou šablonu - vytvoř ji v záložce Šablony.</p>
                <stu-num label="Měřítko (1 = původní velikost)" v-model="selNode.w" :min="0.02" :max="5"></stu-num>
              </template>
              <template v-else-if="selNode.type !== 'group'">
                <stu-num :label="sizeLabel" v-model="selNode.w" :min="0.02" :max="5"></stu-num>
                <stu-num label="Výška" v-if="selNode.type === 'ellipse' || selNode.type === 'rect'" v-model="selNode.h" :min="0.02" :max="5"></stu-num>
                <stu-num label="Zaoblení" v-if="selNode.type === 'rect'" v-model="selNode.cr" :min="0" :max="1"></stu-num>
                <stu-num label="Tloušťka" v-if="selNode.type === 'ring'" v-model="selNode.thick" :min="0.01" :max="2"></stu-num>
                <stu-num label="Počet stran" v-if="selNode.type === 'poly' || selNode.type === 'star'" v-model="selNode.n" :min="3" :max="16" :step="1"></stu-num>
                <stu-num label="Vnitřní poloměr" v-if="selNode.type === 'star'" v-model="selNode.inner" :min="0.1" :max="0.95"></stu-num>
              </template>
              <stu-num label="Průhlednost" v-model="selNode.alpha" :min="0" :max="1"></stu-num>

              <template v-if="selNode.type !== 'group' && selNode.type !== 'ref'">
                <h4>Výplň</h4>
                <label class="sn"><span>Druh</span><select class="btn" v-model="selNode.fill.t"><option value="none">žádná</option><option value="solid">jednobarevná</option><option value="linear">lineární přechod</option><option value="radial">kruhový přechod</option></select></label>
                <template v-if="selNode.fill.t !== 'none'">
                  <div class="stop" v-for="(s, i) in selNode.fill.stops" :key="i" v-show="selNode.fill.t !== 'solid' || i === 0">
                    <stu-col :label="selNode.fill.t === 'solid' ? 'Barva' : 'Barva ' + (i + 1)" :model-value="s[1]" @update:model-value="s[1] = $event; touch()"></stu-col>
                    <label class="sn" v-if="selNode.fill.t !== 'solid'"><span>Poloha</span><input type="range" min="0" max="1" step="0.01" v-model.number="s[0]"><button class="rst" v-if="selNode.fill.stops.length > 2" @click.prevent="selNode.fill.stops.splice(i, 1); touch()" title="Odebrat barvu">×</button></label>
                  </div>
                  <button class="btn sm" v-if="selNode.fill.t !== 'solid' && selNode.fill.stops.length < 5" @click="selNode.fill.stops.push([1, '#ffffff']); touch()">+ barva</button>
                  <stu-num label="Úhel °" v-if="selNode.fill.t === 'linear'" v-model="selNode.fill.angle" :min="-180" :max="180" :step="1"></stu-num>
                  <template v-if="selNode.fill.t === 'radial'">
                    <stu-num label="Střed x" v-model="selNode.fill.fx" :min="-1" :max="1"></stu-num>
                    <stu-num label="Střed y" v-model="selNode.fill.fy" :min="-1" :max="1"></stu-num>
                  </template>
                </template>
                <h4>Okraj</h4>
                <stu-col label="Barva" v-model="selNode.stroke.c" :alpha="false"></stu-col>
                <stu-num label="Tloušťka" v-model="selNode.stroke.w" :min="0" :max="0.4"></stu-num>
                <stu-num label="Průhlednost" v-model="selNode.stroke.a" :min="0" :max="1"></stu-num>
                <h4>Stín / záře</h4>
                <stu-col label="Barva" v-model="selNode.shadow.c"></stu-col>
                <stu-num label="Rozmazání" v-model="selNode.shadow.b" :min="0" :max="2"></stu-num>
                <stu-num label="Posun x" v-model="selNode.shadow.x" :min="-1" :max="1"></stu-num>
                <stu-num label="Posun y" v-model="selNode.shadow.y" :min="-1" :max="1"></stu-num>
              </template>
              <h4>Animace (platí i pro všechny podřízené vrstvy)</h4>
              <label class="sn"><span>Druh</span><select class="btn" v-model="selNode.anim.t"><option value="none">stojí</option><option value="aim">otáčí se za cílem</option><option value="spin">točí se pořád</option><option value="pulse">pulzuje</option><option value="bob">houpe se nahoru a dolů</option></select></label>
              <stu-num label="Rychlost" v-if="selNode.anim.t === 'spin' || selNode.anim.t === 'pulse' || selNode.anim.t === 'bob'" v-model="selNode.anim.speed" :min="-10" :max="10"></stu-num>
              <stu-num label="Rozsah" v-if="selNode.anim.t === 'pulse' || selNode.anim.t === 'bob'" v-model="selNode.anim.amp" :min="0" :max="0.6"></stu-num>
              <p class="hint" v-if="selNode.anim.t === 'aim'">Skupina se otáčí tak, aby její osa +x mířila na cíl (u věže). U nepřítele stojí.</p>
            </div>
            <button class="btn danger sm" v-if="S.ui.tab !== 'templates'" @click="dropLook" data-act="look-drop">Zahodit vlastní vzhled</button>
          </template>
        </template>

        <!-- ======= VLASTNOSTI / VLNY ======= -->
        <template v-else>
          <div class="stu-warn" v-if="weakList.length" data-role="weak-box">⚠ Tahle věž je slabší než její rodič: {{ weakList.join(', ') }}. Jen upozornění, nic se neomezuje.</div>
          <div class="stu-grp" v-for="g in groups" :key="g.g">
            <h3>{{ g.g }}</h3>
            <div class="stu-f" v-for="f in g.fields" :key="f.k" :class="{chg: S.isChanged(S.ui.tab, S.ui.sel, f.k)}">
              <label :for="'sf-' + f.k">{{ f.label }}</label>
              <div class="ctl">
                <template v-if="f.type === 'num'">
                  <input type="range" :min="f.min" :max="f.max" :step="f.step" :value="num(f)" @input="put(f, $event.target.value)" v-if="!f.empty">
                  <input class="in n" type="number" :id="'sf-' + f.k" :min="f.min" :max="f.max" :step="f.step" :value="num(f)" @change="put(f, $event.target.value)" :placeholder="f.empty ? '—' : ''" :data-f="f.k">
                </template>
                <template v-else-if="f.type === 'bool'"><input type="checkbox" :id="'sf-' + f.k" :checked="!!val(f)" @change="put(f, $event.target.checked)" :data-f="f.k"></template>
                <template v-else-if="f.type === 'color'"><stu-cbtn :model-value="val(f)" :alpha="false" @update:model-value="put(f, $event)" :data-f="f.k"></stu-cbtn></template>
                <template v-else-if="f.type === 'select'">
                  <select class="btn" :id="'sf-' + f.k" :value="val(f) || f.options[0][0]" @change="put(f, $event.target.value)" :data-f="f.k"><option v-for="o in f.options" :key="o[0]" :value="o[0]">{{ o[1] }}</option></select>
                </template>
                <template v-else-if="f.type === 'tower'">
                  <select class="btn" :id="'sf-' + f.k" :value="val(f) || 'base'" @change="put(f, $event.target.value)" :data-f="f.k" :disabled="S.ui.sel === 'base'"><option v-for="id in towerIds" :key="id" :value="id">{{ S.value('towers', id, 'name') }}</option></select>
                </template>
                <template v-else-if="f.type === 'ammo'">
                  <select class="btn" :id="'sf-' + f.k" :value="val(f) || ''" @change="put(f, $event.target.value)" :data-f="f.k"><option value="">— výchozí střela —</option><option v-for="id in ammoIds" :key="id" :value="id" v-if="id !== 'default'">{{ S.value('ammo', id, 'name') }} ({{ id }})</option></select>
                </template>
                <template v-else-if="f.type === 'enemy'">
                  <select class="btn" :id="'sf-' + f.k" :value="val(f) || ''" @change="put(f, $event.target.value)" :data-f="f.k"><option value="">— žádný —</option><option v-for="id in enemyIds" :key="id" :value="id">{{ S.value('enemies', id, 'name') }} ({{ id }})</option></select>
                </template>
                <template v-else><input class="in" type="text" :id="'sf-' + f.k" :value="val(f)" :maxlength="f.max" @change="put(f, $event.target.value)" :data-f="f.k"></template>
                <button class="rst" v-if="S.isChanged(S.ui.tab, S.ui.sel, f.k)" @click="S.resetField(S.ui.tab, S.ui.sel, f.k)" title="Vrátit výchozí hodnotu">↺</button>
              </div>
              <div class="hp" v-if="f.help">{{ f.help }}</div>
            </div>
          </div>
        </template>
      </div>
      <div class="stv-foot">
        <div class="stu-facts">{{ facts }}</div>
        <div class="stv-fb">
          <button class="btn sm" v-if="builtin" :disabled="!touched" @click="resetItem" data-act="stu-reset"><ic n="refresh"></ic> Vrátit výchozí</button>
          <button class="btn sm danger" v-if="!builtin || (S.ui.tab === 'towers' && S.ui.sel !== 'base')" @click="remove" data-act="stu-remove"><ic n="trash"></ic> Smazat</button>
        </div>
      </div>
    </div>
    <div class="stv-side empty" v-else>Vyber položku vlevo.</div>
  </div>
</div>`,
    data: function () {
      return { S: S, ver: BD.VERSION, panel: 'look', ioOpen: false, ioText: '', ioMsg: '', ioErr: false, newId: '', newErr: '',
        view: { target: true, aimDeg: 30, toolGuides: true, phase: null, zoom: 5, px: 0, py: 0, axes: true, grid: true, guides: true, range: false, anim: true, real: true, light: false },
        fold: {}, sel: [], anchor: '', dnd: null, tm: { ang: 90, cx: 0, cy: 0 }, tr: { n: 6, sweep: 360, cx: 0, cy: 0 }, tfold: {}, dragT: null, copySrc: '', clipRev: 0, bulk: { dx: 0, dy: 0, rot: 15, scale: 120, pivot: true, fill: '#ff8800', stroke: '#ffffff', sw: 0.06, alpha: 1 },  ioOne: true, sizeChoices: [1, 2, 3, 4, 8, 20], customBox: null, boxSel: { enemies: [1], towers: [2], templates: [2], ammo: [1] }, sp: null, selId: '', undo: [], ph: 'shot', ap: { play: true }, apT: 0, apLast: 0, posText: '', names: SP.NAMES, addTypes: ['circle', 'ring', 'ellipse', 'rect', 'poly', 'star', 'group'], limMsg: '',
        glyph: { ref: '◈', group: '▣', circle: '●', ring: '◯', ellipse: '⬭', rect: '▬', poly: '⬡', star: '★' }, animName: { aim: '↻ míří', spin: '⟳ točí', pulse: '◉ pulzuje', bob: '↕ houpe' } };
    },
    computed: {
      tabs: function () { return [{ id: 'enemies', label: 'Nepřátelé', g: 1 }, { id: 'towers', label: 'Věže', g: 2 }, { id: 'ammo', label: 'Střelivo', g: 3 }, { id: 'templates', label: 'Šablony', g: 4 }]; },       // g = skupina; mezi skupinami je svislá čárka
      treeRows: function () {                                     // plochý seznam stromu pod základnou (sbalené větve se přeskočí)
        S.rev; var out = [], me = this;
        (function walk(pid, depth, guard) {
          S.childrenOf(pid).forEach(function (id) {
            var kids = guard < 12 ? S.childrenOf(id).length : 0; out.push({ id: id, depth: depth, kids: kids });
            if (kids && !me.tfold[id]) walk(id, depth + 1, guard + 1);
          });
        })('base', 0, 0);
        return out;
      },
      deletedTowers: function () { return S.deleted('towers'); },
      towerIds: function () { S.rev; return S.ids('towers').filter(function (i) { return i !== S.ui.sel && !S.isUnder(i, S.ui.sel); }); },
      weakList: function () { return S.ui.tab === 'towers' && S.ui.sel ? this.weakerList(S.ui.sel) : []; },
      ids: function () { S.rev; return S.ids(S.ui.tab); },
      enemyIds: function () { S.rev; return S.ids('enemies').filter(function (i) { return i !== S.ui.sel; }); },
      cur: function () { S.rev; return S.ui.sel && S.KINDS[S.ui.tab][S.ui.sel] ? S.KINDS[S.ui.tab][S.ui.sel] : null; },
      builtin: function () { return S.isBuiltin(S.ui.tab, S.ui.sel); },
      touched: function () { return S.touched(S.ui.tab, S.ui.sel); },
      boxes: function () { return this.boxSel[S.ui.tab] || []; },
      phases: function () { return [{ id: 'muzzle', label: 'Výstřel' }, { id: 'shot', label: 'Let' }, { id: 'impact', label: 'Dopad' }]; },
      phaseLabel: function () { var me = this; return this.phases.filter(function (p) { return p.id === me.ph; })[0].label; },
      spPath: function () { return S.ui.tab === 'ammo' ? this.ph + '.sprite' : 'sprite'; },
      ammoIds: function () { S.rev; return S.ids('ammo'); },
      apFlight: function () { S.rev; var c = this.cur; return c && S.ui.tab === 'ammo' ? 4.5 / (10 * (c.speedMul || 1)) : 0.45; },
      apTotal: function () { var c = this.cur; return c && c.impact ? Math.round((this.apFlight + (c.impact.dur || 0.3)) * 100) / 100 : 1; },
      zoomLabel: function () { return Math.round(this.view.zoom * 10) / 10; },
      groups: function () {
        var c = this.cur, role = S.ui.tab === 'towers' && c ? c.role : null, wave = this.panel === 'waves';
        return S.schema[S.ui.tab].filter(function (g) { return !!g.wave === wave; }).map(function (g) {
          return { g: g.g, fields: g.fields.filter(function (f) { return (f.k !== 'parent' || S.ui.sel !== 'base') && (!f.role || !role || f.role.split(',').indexOf(role) >= 0) && (!f.when || (c && c.waveMode === f.when)); }) };
        }).filter(function (g) { return g.fields.length; });
      },
      addList: function () { return this.addTypes.concat(['ref']); },
      nodeCount: function () { return this.sp ? SP.count(this.sp) : 0; },
      nodeLimit: function () { return SP.LIMIT.nodes; },
      nodeFull: function () { return this.nodeCount >= SP.LIMIT.nodes; },
      refFull: function () { return !!this.sp && SP.refCount(this.sp) >= SP.LIMIT.refs; },
      tplIds: function () { S.rev; var me = S.ui.tab === 'templates' ? S.ui.sel : null; return S.ids('templates').filter(function (i) { return !me || !S.tplReaches(i, me); }); },       // v šabloně nejde vložit ji samu ani šablonu, která ji obsahuje
      noRef: function () { return false; },
      clipHas: function () { this.clipRev; return !!readClip(); },
      copySources: function () {                                   // všechny položky, které už mají vlastní vzhled
        S.rev; var out = [];
        ['towers', 'enemies', 'templates'].forEach(function (k) {
          S.ids(k).forEach(function (id) {
            if (!S.value(k, id, 'sprite') || (k === S.ui.tab && id === S.ui.sel)) return;
            out.push({ v: k + ':' + id + ':base', label: (k === 'towers' ? 'Věž · ' : k === 'enemies' ? 'Nepřítel · ' : 'Šablona · ') + S.value(k, id, 'name') });
          });
        });
        return out;
      },
      selNode: function () { return this.sp && this.selId ? (SP.find(this.sp, this.selId) || {}).node || null : null; },
      parentId: function () { var f = this.sp && this.selId ? SP.find(this.sp, this.selId) : null; return f && f.parent ? f.parent.id : ''; },
      groupsFor: function () {
        var out = [], me = this.selNode; if (!this.sp || !me) return out;
        var banned = {}; SP.walk([me], function (n) { banned[n.id] = 1; });
        SP.walk(this.sp.nodes, function (n) { if (n.type === 'group' && !banned[n.id]) out.push({ id: n.id, name: n.name }); });
        return out;
      },
      selMap: function () { var m = {}; this.sel.forEach(function (i) { m[i] = 1; }); if (this.selId) m[this.selId] = 1; return m; },
      selCount: function () { return this.selIds(false).length; },
      rows: function () {
        var out = []; if (!this.sp) return out; var fold = this.fold;
        (function rec(list, depth) { for (var i = list.length - 1; i >= 0; i--) { out.push({ n: list[i], depth: depth }); if (list[i].children && list[i].children.length && !fold[list[i].id]) rec(list[i].children, depth + 1); } })(this.sp.nodes, 0);
        return out;
      },
      sizeLabel: function () { return this.selNode && (this.selNode.type === 'ellipse' || this.selNode.type === 'rect') ? 'Šířka' : 'Průměr'; },
      facts: function () {
        S.rev; var c = this.cur; if (!c) return '';
        if (S.ui.tab === 'ammo') {
          var n = Object.keys(S.KINDS.towers).filter(function (i) { var a = S.KINDS.towers[i].ammo; return S.ui.sel === 'default' ? !a || !S.KINDS.ammo[a] || a === 'default' : a === S.ui.sel; }).length;
          return 'Poškození ×' + c.dmgMul + ' · rychlost ×' + c.speedMul + ' · používá ' + n + ' ' + (n === 1 ? 'věž' : n >= 2 && n <= 4 ? 'věže' : 'věží');
        }
        if (S.ui.tab === 'templates') { var u = S.templateUsage(S.ui.sel); return 'Šablona · ' + (c.sprite ? SP.count(c.sprite) : 0) + ' vrstev · vložená v ' + u + ' ' + (u === 1 ? 'vzhledu' : u >= 2 && u <= 4 ? 'vzhledech' : 'vzhledech'); }
        if (S.ui.tab === 'enemies') {
          var dps = (c.atkDmg > 0 && c.atkRange > 0) ? ' · útok ' + Math.round(c.atkDmg / (c.atkCd || 1)) + '/s' : '';
          return 'Zdraví ' + c.hp + ' · rychlost ' + c.speed + ' · odměna ' + c.reward + (c.splitCount ? ' · rozpad ×' + c.splitCount : '') + dps;
        }
        var t = { type: S.ui.sel, level: 1, tier: 0, size: BD.SUB }, st = BD.systems.towers.stats(t);
        return 'Poškození ' + Math.round(st.dmg * 10) / 10 + ' · dosah ' + Math.round(st.range / BD.SUB * 10) / 10 + ' · prodleva ' + Math.round(st.cd * 100) / 100 + ' s · životy ' + st.hp;
      },
    },
    watch: {
      'S.ui.sel': function () { this.loadSp(); },
      ph: function () { this.loadSp(); },
      'S.ui.tab': function () { this.pick(); },
      selId: function (v) { if (!v) this.sel = []; else if (this.sel.indexOf(v) < 0) this.sel = [v]; },
    },
    mounted: function () {
      this.pick(); this.loadSp(); this.t0 = performance.now(); this.rec = {};
      var self = this; this.ro = new ResizeObserver(function () { self.resize(); }); this.ro.observe(this.$refs.wrap); this.resize();
      this.onKey = function (ev) {
        if ((ev.ctrlKey || ev.metaKey) && ev.code === 'KeyZ' && !(ev.target && /INPUT|TEXTAREA/.test(ev.target.tagName) && ev.target.type !== 'range')) { ev.preventDefault(); self.doUndo(); }
        else if ((ev.ctrlKey || ev.metaKey) && (ev.code === 'KeyC' || ev.code === 'KeyV') && self.panel === 'look' && self.sp !== undefined && !/INPUT|TEXTAREA|SELECT/.test((ev.target && ev.target.tagName) || '')) { ev.preventDefault(); if (ev.code === 'KeyC') self.clipCopy(); else self.clipPaste(); }
        else if (ev.code === 'Delete' && self.panel === 'look' && self.selNode && !/INPUT|TEXTAREA|SELECT/.test((ev.target && ev.target.tagName) || '')) self.delNode();
      };
      window.addEventListener('keydown', this.onKey);
      BD.debugStudio = this; this.tick();
    },
    beforeUnmount: function () { cancelAnimationFrame(this.raf); if (this.ro) this.ro.disconnect(); window.removeEventListener('keydown', this.onKey); if (BD.debugStudio === this) BD.debugStudio = null; },
    methods: {
      pick: function () { var ids = S.ids(S.ui.tab); if (!S.ui.sel || !S.KINDS[S.ui.tab][S.ui.sel]) S.ui.sel = ids[0] || ''; this.newErr = ''; this.loadSp(); },
      setTab: function (t) { S.ui.tab = t; S.ui.sel = ''; this.panel = 'look'; this.pick(); },
      val: function (f) { return S.value(S.ui.tab, S.ui.sel, f.k); },
      num: function (f) { var v = this.val(f); return v === undefined ? (f.empty ? '' : f.min) : v; },
      put: function (f, v) { S.set(S.ui.tab, S.ui.sel, f.k, v); },
      create: function () {
        var par = S.ui.tab === 'towers' && S.ui.sel && S.KINDS.towers[S.ui.sel] ? S.ui.sel : 'base';
        var err = S.create(S.ui.tab, this.newId);
        if (!err && S.ui.tab === 'towers') { S.moveTower(S.lastId, par, S.childrenOf(par).length + 1); this.tfold[par] = false; }
        this.newErr = err; if (!err) { S.ui.sel = S.lastId; this.newId = ''; this.loadSp(); }
      },
      remove: async function () {
        var ok = await BD.ui.confirm('Smazat „' + (this.cur && this.cur.name) + '“ ze Studia?' + (S.ui.tab === 'towers' && S.childrenOf(S.ui.sel).length ? ' Její vylepšení se přesunou o patro výš.' : '') + (S.isBuiltin(S.ui.tab, S.ui.sel) ? ' Vestavěnou věž jde obnovit tlačítkem pod seznamem.' : '') + (S.ui.tab === 'templates' && S.templateUsage(S.ui.sel) ? ' Je vložená v ' + S.templateUsage(S.ui.sel) + ' vzhledech - tam se přestane kreslit.' : ''), { ok: 'Smazat' });
        if (ok) { S.remove(S.ui.tab, S.ui.sel); S.ui.sel = ''; this.pick(); }
      },
      resetItem: function () { S.resetItem(S.ui.tab, S.ui.sel); this.loadSp(); },
      test: function () { this.$emit('test', { kind: S.ui.tab, id: S.ui.sel }); },

      say: function (t, bad) { this.ioMsg = t; this.ioErr = !!bad; },
      expText: function () { return this.ioOne && this.cur && S.ui.sel ? S.exportText(S.ui.tab, S.ui.sel) : S.exportText(); },
      showExport: function () { this.ioText = this.expText(); this.say('Export je ve vstupním poli.'); },
      copyExport: async function () { var txt = this.expText(); this.ioText = txt; this.say(await BD.ui.levelIO.copy(txt) ? 'Zkopírováno do schránky.' : 'Kopírování se nepovedlo.', false); },
      downloadExport: function () { BD.ui.levelIO.download(this.expText(), 'bubbledefence-studio.json'); this.say('Soubor bubbledefence-studio.json je stažený.'); },
      doImport: function () { var r = S.importText(this.ioText); if (r.ok) { this.say('Načteno položek: ' + r.count + '.'); this.pick(); } else this.say(r.error, true); },

      /* ---------- vzhled: úpravy stromu vrstev ---------- */
      /* ---------- strom věží v levém sloupci ---------- */
      /* v čem je věž slabší než její rodič (jen upozornění, nic neblokuje; porovnává se jen věž stejného druhu) */
      weakerList: function (id) {
        S.rev; var d = S.KINDS.towers[id], p = d && S.KINDS.towers[d.parent], out = [];
        if (!d || !p || d.parent === 'base' || p.role !== d.role || !d.base || !p.base) return out;
        if (d.role === 'boost') { if ((d.base.boost || 0) < (p.base.boost || 0)) out.push('zesílení'); return out; }
        if ((d.base.dmg || 0) < (p.base.dmg || 0)) out.push('poškození'); if ((d.base.range || 0) < (p.base.range || 0)) out.push('dosah'); if ((d.base.cd || 0) > (p.base.cd || 0)) out.push('prodleva (pomalejší)');
        return out;
      },
      tDragStart: function (ev, id) { this.dragT = { id: id, over: '', zone: '' }; try { ev.dataTransfer.setData('text/plain', id); ev.dataTransfer.effectAllowed = 'move'; } catch (e) { /* bez dataTransfer */ } },
      tDragOver: function (ev, id) {
        var d = this.dragT; if (!d) return; var r = ev.currentTarget.getBoundingClientRect(), y = (ev.clientY - r.top) / r.height;
        d.over = id; d.zone = y < 0.28 ? 'above' : y > 0.72 ? 'below' : 'into';
      },
      tDrop: function (ev, id) {
        var d = this.dragT; this.dragT = null; if (!d || !d.id || d.id === id) return;
        var zone = d.zone || 'into';
        if (zone === 'into') { var last = S.childrenOf(id).filter(function (c) { return c !== d.id; }); if (S.moveTower(d.id, id)) { this.tfold[id] = false; this.renumber(id, last.concat([d.id])); } return; }
        var tgt = S.KINDS.towers[id]; if (!tgt) return; var par = tgt.parent || 'base';
        if (!S.moveTower(d.id, par)) return;
        var sib = S.childrenOf(par).filter(function (c) { return c !== d.id; }), at = sib.indexOf(id) + (zone === 'below' ? 1 : 0); sib.splice(at, 0, d.id);
        this.renumber(par, sib);
      },
      renumber: function (par, ids) { ids.forEach(function (id, i) { if ((S.KINDS.towers[id].order || 0) !== i + 1) S.set('towers', id, 'order', i + 1); }); },
      restoreAll: function () { S.deleted('towers').forEach(function (id) { S.restore('towers', id); }); },
      /* ---------- převzetí vzhledu z jiné položky ---------- */
      copyLookFrom: function () {
        var q = String(this.copySrc || '').split(':'); if (q.length < 3) return;
        var sp = q[2] === 'base' ? S.value(q[0], q[1], 'sprite') : ((S.value(q[0], q[1], 'looks') || [])[+q[2]] || {}).sprite; sp = sp && SP.sanitize(SP.clone(sp), { noRef: this.noRef }); if (!sp) return;
        if (this.sp) this.pushUndo(); this.sp = sp; this.sel = []; this.selId = sp.nodes[0].id; this.copySrc = ''; this.commit();
      },
      /* ---------- schránka tvarů (mezi věžemi i nepřáteli) ---------- */
      clipCopy: function () {
        var ids = this.selIds(true), me = this; if (!ids.length) return;
        var nodes = ids.map(function (id) { var f = SP.find(me.sp, id); return f ? SP.clone(f.node) : null; }).filter(Boolean); if (!nodes.length) return;
        var o = { game: 'BubbleDefence', type: 'studio-shapes', v: 1, nodes: nodes }; writeClip(o); this.clipRev++;
        try { if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(JSON.stringify(o)).catch(function () {}); } catch (e) { /* bez systémové schránky */ }
        this.say('Zkopírováno tvarů: ' + nodes.length + '. Vlož je (Vložit / Ctrl+V) kdekoli, i v jiné položce.', false);
      },
      clipPaste: async function () {
        var o = null;
        try { if (navigator.clipboard && navigator.clipboard.readText) { var t = await navigator.clipboard.readText(); var j = JSON.parse(t); if (j && j.type === 'studio-shapes' && Array.isArray(j.nodes)) o = j; } } catch (e) { /* použije se vnitřní schránka */ }
        if (!o) o = readClip(); if (!o) return;
        var clean = SP.sanitize({ v: 1, nodes: SP.clone(o.nodes) }, { noRef: this.noRef }); if (!clean) return;
        if (!this.sp) { this.sp = { v: 1, nodes: [] }; }
        var f = this.selId ? SP.find(this.sp, this.selId) : null, list, at, depth = 0;
        if (f && f.node.type === 'group') { list = f.node.children; at = list.length; SP.walk(this.sp.nodes, function (n, p, l, i, d) { if (n === f.node) depth = d + 1; }); this.fold[f.node.id] = false; }
        else if (f) { list = f.list; at = f.index + 1; SP.walk(this.sp.nodes, function (n, p, l, i, d) { if (n === f.node) depth = d; }); }
        else { list = this.sp.nodes; at = list.length; }
        var add = clean.nodes.filter(function (n) { return depth + heightOf(n) <= SP.LIMIT.depth; }), room = SP.LIMIT.nodes - SP.count(this.sp), put = [];
        add.forEach(function (n) { var c = SP.reid(n), k = SP.count({ nodes: [c] }); if (k <= room) { room -= k; put.push(c); } });
        if (!put.length) { this.say('Tvary se sem nevejdou (limit vrstev nebo hloubky).', true); return; }
        if (put.length < clean.nodes.length) this.flash('Vložena jen část tvarů - vzhled by přesáhl ' + SP.LIMIT.nodes + ' vrstev' + '.');
        if (!put.length) return;
        this.pushUndo(); Array.prototype.splice.apply(list, [at, 0].concat(put)); this.setSelection(put.map(function (n) { return n.id; })); this.commit();
        this.say('Vloženo tvarů: ' + put.length + '.', false);
      },
      /* ---------- hromadná úprava vybraných vrstev ---------- */
      bulkTop: function () { var me = this; return this.selIds(true).map(function (i) { var f = SP.find(me.sp, i); return f && f.node; }).filter(Boolean); },
      bulkLeaves: function () { var out = []; this.bulkTop().forEach(function (n) { SP.walk([n], function (m) { if (m.type !== 'group') out.push(m); }); }); return out; },
      bulkCenter: function (nodes) { var x = 0, y = 0; nodes.forEach(function (n) { x += n.x || 0; y += n.y || 0; }); return { x: x / nodes.length, y: y / nodes.length }; },
      bulkMove: function () { var ns = this.bulkTop(), b = this.bulk; if (!ns.length) return; this.pushUndo(); ns.forEach(function (n) { n.x = (n.x || 0) + (+b.dx || 0); n.y = (n.y || 0) + (+b.dy || 0); }); this.commit(); },
      bulkRotate: function () {
        var ns = this.bulkTop(), b = this.bulk, a = (+b.rot || 0) * Math.PI / 180; if (!ns.length) return; this.pushUndo();
        var c = b.pivot ? this.bulkCenter(ns) : null;
        ns.forEach(function (n) {
          n.rot = Math.round((((n.rot || 0) + (+b.rot || 0) + 540) % 360 - 180) * 100) / 100;
          if (c) { var dx = (n.x || 0) - c.x, dy = (n.y || 0) - c.y; n.x = Math.round((c.x + dx * Math.cos(a) - dy * Math.sin(a)) * 1e4) / 1e4; n.y = Math.round((c.y + dx * Math.sin(a) + dy * Math.cos(a)) * 1e4) / 1e4; }
        });
        this.commit();
      },
      bulkScale: function () {
        var ns = this.bulkTop(), b = this.bulk, k = Math.max(0.1, Math.min(4, (+b.scale || 100) / 100)); if (!ns.length) return; this.pushUndo();
        var c = this.bulkCenter(ns);
        function inner(n) {
          if (n.type !== 'group') { n.w = Math.max(0.02, Math.min(5, n.w * k)); if (n.h != null) n.h = Math.max(0.02, Math.min(5, n.h * k)); if (n.thick) n.thick = Math.max(0.01, Math.min(2, n.thick * k)); if (n.stroke) n.stroke.w = Math.min(0.4, n.stroke.w * k); if (n.shadow) { n.shadow.b = Math.min(2, n.shadow.b * k); n.shadow.x = Math.max(-1, Math.min(1, n.shadow.x * k)); n.shadow.y = Math.max(-1, Math.min(1, n.shadow.y * k)); } }
          (n.children || []).forEach(function (m) { m.x = Math.max(-4, Math.min(4, (m.x || 0) * k)); m.y = Math.max(-4, Math.min(4, (m.y || 0) * k)); inner(m); });
        }
        ns.forEach(function (n) { n.x = Math.max(-4, Math.min(4, c.x + ((n.x || 0) - c.x) * k)); n.y = Math.max(-4, Math.min(4, c.y + ((n.y || 0) - c.y) * k)); inner(n); });
        this.commit();
      },
      bulkFill: function () { var c = this.bulk.fill; this.touch1(); this.bulkLeaves().forEach(function (n) { n.fill = Object.assign(n.fill || {}, { t: 'solid', stops: [[0, c], [1, c]] }); }); this.commit(); },
      bulkStroke: function (color) {
        var b = this.bulk; this.touch1(); this.bulkLeaves().forEach(function (n) { n.stroke = n.stroke || { c: '#ffffff', w: 0, a: 1 }; if (color) { n.stroke.c = b.stroke; if (!(n.stroke.w > 0)) n.stroke.w = 0.06; } else n.stroke.w = Math.max(0, Math.min(0.4, +b.sw || 0)); });
        this.commit();
      },
      bulkAlpha: function () { var a = Math.max(0, Math.min(1, +this.bulk.alpha)); this.pushUndo(); this.bulkTop().forEach(function (n) { n.alpha = a; }); this.commit(); },
      touch1: function () { var now = performance.now(); if (!this.lastTouch || now - this.lastTouch > 700) this.pushUndo(); this.lastTouch = now; },

      loadSp: function () {
        var c = this.cur, src = c && S.get(c, this.spPath); this.sp = src ? SP.clone(src) : null; this.undo = []; this.sel = [];
        var first = null; if (this.sp) SP.walk(this.sp.nodes, function (n) { first = n.id; }); this.selId = first || '';
      },
      commit: function () { if (this.sp) S.set(S.ui.tab, S.ui.sel, this.spPath, SP.clone(this.sp)); },
      pushUndo: function () { if (this.sp) { this.undo.push(JSON.stringify(this.sp)); if (this.undo.length > 60) this.undo.shift(); } },
      touch: function () {
        var now = performance.now(); if (!this.lastTouch || now - this.lastTouch > 700) this.pushUndo();       // úpravy jedné hodnoty v rychlém sledu = jeden krok zpět
        this.lastTouch = now; this.commit();
      },
      doUndo: function () {
        if (this.panel !== 'look' || !this.undo.length) return;
        this.sp = JSON.parse(this.undo.pop()); this.lastTouch = 0;
        var me = this; this.sel = this.sel.filter(function (i) { return SP.find(me.sp, i); }); if (!SP.find(this.sp, this.selId)) this.selId = this.sel[this.sel.length - 1] || ''; this.commit();
      },
      makeLook: function (fromCurrent) {
        var c = this.cur, sp = fromCurrent ? (S.ui.tab === 'ammo' ? this.ammoLook() : S.ui.tab === 'enemies' ? SP.enemyTemplate(c) : SP.towerTemplate(c)) : { v: 1, nodes: [SP.node('circle', { name: 'Tělo', w: 1.6 })] };
        this.sp = sp; this.undo = []; this.selId = sp.nodes[0].id; this.commit();
      },
      fix: function (v) { return (Math.round((+v || 0) * 100) / 100).toString().replace('.', ','); },
      /* výchozí tvar fáze střeliva (barva podle střeliva): výstřel = hvězda záblesku, let = kulička, dopad = prstenec + jádro */
      ammoLook: function () {
        var col = this.cur.color || '#7fe3cf', fl = function (c) { return { t: 'solid', stops: [[0, c], [1, c]] }; }, nd = SP.node, ph = this.ph, list;
        if (ph === 'muzzle') list = [nd('star', { name: 'Záblesk', w: 2, n: 4, inner: 0.35, fill: fl(col), stroke: { c: '#ffffff', w: 0, a: 1 } }), nd('circle', { name: 'Jádro', w: 0.7, fill: fl('#ffffff'), stroke: { c: '#ffffff', w: 0, a: 1 } })];
        else if (ph === 'shot') list = [nd('circle', { name: 'Střela', w: 2, fill: { t: 'radial', stops: [[0, '#ffffff'], [1, col]], angle: 90, fx: -0.3, fy: -0.3 }, stroke: { c: '#ffffff', w: 0.12, a: 0.8 } })];
        else list = [nd('ring', { name: 'Vlna', w: 2, thick: 0.2, fill: fl(col) }), nd('circle', { name: 'Jádro', w: 1, fill: fl(col), alpha: 0.6, stroke: { c: '#ffffff', w: 0, a: 1 } })];
        return { v: 1, nodes: list };
      },
      dropLook: async function () {
        var ok = await BD.ui.confirm('Zahodit vlastní vzhled a vrátit původní kreslení hry?', { ok: 'Zahodit' });
        if (!ok) return; S.resetField(S.ui.tab, S.ui.sel, this.spPath); if (!S.isBuiltin(S.ui.tab, S.ui.sel)) S.set(S.ui.tab, S.ui.sel, this.spPath, undefined); this.loadSp();
      },
      /* kam vložit novou vrstvu: do vybrané skupiny, jinak hned nad vybranou, jinak nahoru */
      addNode: function (type) {
        if (SP.count(this.sp) >= SP.LIMIT.nodes) { this.flash('Vzhled už má největší počet vrstev (' + SP.LIMIT.nodes + ').'); return; }
        if (type === 'ref' && (this.noRef || SP.refCount(this.sp) >= SP.LIMIT.refs)) return;
        this.pushUndo(); var n = SP.node(type), f = this.selId ? SP.find(this.sp, this.selId) : null;
        if (f && f.node.type === 'group') { f.node.children.push(n); this.fold[f.node.id] = false; } else if (f) f.list.splice(f.index + 1, 0, n); else this.sp.nodes.push(n);
        if (type === 'ref') { n.ref = this.tplIds[0] || ''; n.name = n.ref ? String(S.value('templates', n.ref, 'name')).slice(0, 24) : 'Šablona'; }
        this.selId = n.id; this.commit();
      },
      shapeIcon: function (t) {
        var d = {
          circle: '<circle cx="12" cy="12" r="8.5"/>',
          ring: '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.2"/>',
          ellipse: '<ellipse cx="12" cy="12" rx="9.5" ry="5.8"/>',
          rect: '<rect x="3" y="6.5" width="18" height="11" rx="2.5"/>',
          poly: '<path d="M12 3 20 7.5v9L12 21 4 16.5v-9z"/>',
          star: '<path d="m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z"/>',
          group: '<rect x="3.5" y="3.5" width="17" height="17" rx="2" stroke-dasharray="3 2.6"/><rect x="7.5" y="7.5" width="5" height="5" rx="1"/><circle cx="15.5" cy="15.5" r="2.6"/>',
          ref: '<path d="M12 3 21 12 12 21 3 12z"/><path d="M12 8 16 12 12 16 8 12z"/>' }[t] || '';
        return '<svg viewBox="0 0 24 24" aria-hidden="true">' + d + '</svg>';
      },
      refPicked: function () { var n = this.selNode; if (n && n.type === 'ref') { var nm = n.ref ? S.value('templates', n.ref, 'name') : ''; if (nm && (n.name === 'Šablona' || this.tplIds.some(function (i) { return S.value('templates', i, 'name') === n.name; }))) n.name = String(nm).slice(0, 24); } this.touch(); },
      flash: function (m) { var me = this; this.limMsg = m; clearTimeout(this.limT); this.limT = setTimeout(function () { me.limMsg = ''; }, 4000); },

      /* ---------- výběr více vrstev ---------- */
      /* id vybraných vrstev v pořadí odzadu dopředu; top = bez těch, jejichž rodič je také vybraný */
      selIds: function (top) {
        if (!this.sp) return []; var set = {}; (this.sel.length ? this.sel : (this.selId ? [this.selId] : [])).forEach(function (i) { set[i] = 1; }); var out = [];
        (function w(list, anc) { list.forEach(function (n) { var hit = !!set[n.id]; if (hit && !(top && anc)) out.push(n.id); w(n.children || [], anc || hit); }); })(this.sp.nodes, false);
        return out;
      },
      setSelection: function (ids, primary) { this.sel = ids.slice(); this.selId = primary || ids[ids.length - 1] || ''; this.anchor = this.selId; },
      selectAll: function () { var ids = this.rows.map(function (r) { return r.n.id; }); this.setSelection(ids, this.selId || ids[0]); },
      setAllFold: function (v) { var f = this.fold, any = false; SP.walk(this.sp.nodes, function (n) { if (n.type === 'group' && n.children.length) { f[n.id] = v; any = true; } }); },
      reveal: function (id) {                                       // rozbalí skupiny nad vrstvou
        var f = SP.find(this.sp, id), self = this; while (f && f.parent) { self.fold[f.parent.id] = false; f = SP.find(self.sp, f.parent.id); }
      },
      clickRow: function (ev, r) {
        var id = r.n.id;
        if (ev.shiftKey && this.anchor && this.rows.some(function (x) { return x.n.id === this.anchor; }, this)) {
          var ids = this.rows.map(function (x) { return x.n.id; }), a = ids.indexOf(this.anchor), b = ids.indexOf(id);
          this.sel = ids.slice(Math.min(a, b), Math.max(a, b) + 1); this.selId = id;
        } else if (ev.ctrlKey || ev.metaKey) {
          var i = this.sel.indexOf(id);
          if (i >= 0) { this.sel.splice(i, 1); if (this.selId === id) this.selId = this.sel[this.sel.length - 1] || ''; }
          else { this.sel.push(id); this.selId = id; }
          this.anchor = id;
        } else this.setSelection([id], id);
      },
      /* ---------- drag & drop v seznamu ---------- */
      dragStart: function (ev, n) {
        if (!this.selMap[n.id]) this.setSelection([n.id], n.id);
        this.dnd = { id: n.id, ids: this.selIds(true), over: '', zone: '' };
        try { ev.dataTransfer.setData('text/plain', n.id); ev.dataTransfer.effectAllowed = 'move'; } catch (e) {}
      },
      dragOver: function (ev, n) {
        if (!this.dnd) return; var r = ev.currentTarget.getBoundingClientRect(), y = (ev.clientY - r.top) / r.height, isG = n.type === 'group';
        var zone = isG ? (y < 0.3 ? 'above' : y > 0.7 ? 'below' : 'into') : (y < 0.5 ? 'above' : 'below');
        this.dnd.over = n.id; this.dnd.zone = zone;
      },
      dropOn: function (ev, n) { var d = this.dnd; this.dnd = null; if (d && d.ids && d.ids.length) this.moveNodes(d.ids, n.id, d.zone || 'above'); },
      moveNode: function (id, tid, zone) { this.moveNodes([id], tid, zone); },
      /* přesune uzly (z-pořadí odzadu dopředu): 'above' = vizuálně nad cílem (vepředu), 'below' = pod, 'into' = dovnitř skupiny (nahoru) */
      moveNodes: function (ids, tid, zone) {
        var self = this, tg = SP.find(this.sp, tid); if (!tg || !ids.length || ids.indexOf(tid) >= 0) return;
        var bad = false, hmax = 0;
        ids.forEach(function (id) {
          var f = SP.find(self.sp, id); if (!f) { bad = true; return; } SP.walk([f.node], function (n) { if (n.id === tid) bad = true; });
          hmax = Math.max(hmax, (function hh(n) { var m = 0; (n.children || []).forEach(function (c) { m = Math.max(m, hh(c)); }); return 1 + m; })(f.node));
        });
        if (bad) return;                                                                                   // do vlastního potomka ne
        var td = 0; SP.walk(this.sp.nodes, function (n, p, l, i, depth) { if (n.id === tid) td = depth; });
        if ((zone === 'into' ? td + 1 : td) + hmax - 1 > SP.LIMIT.depth) return;
        this.pushUndo(); var order = ids.slice(); if (zone === 'above') order.reverse();
        order.forEach(function (id) {
          var f = SP.find(self.sp, id); f.list.splice(f.index, 1); var t = SP.find(self.sp, tid);
          if (zone === 'into') { t.node.children.push(f.node); self.fold[tid] = false; } else t.list.splice(t.index + (zone === 'above' ? 1 : 0), 0, f.node);
        });
        this.setSelection(ids, ids[ids.length - 1]); this.commit();
      },
      /* ---------- zrcadlení / opakování (pro všechny vybrané; skupina se zrcadlí i se vším uvnitř) ---------- */
      mirrorCopy: function (self) {
        var ids = this.selIds(true); if (!ids.length) return; this.pushUndo(); var out = [], me = this;
        ids.forEach(function (id) {
          var f = SP.find(me.sp, id); if (!f) return; var m = SP.mirrored(f.node, me.tm.cx, me.tm.cy, me.tm.ang);
          if (self) { m.id = f.node.id; m.name = f.node.name; f.list.splice(f.index, 1, m); out.push(m.id); }
          else { if (SP.count(me.sp) + SP.count({ nodes: [m] }) > SP.LIMIT.nodes) return; m.name = (f.node.name + ' ⇋').slice(0, 24); f.list.splice(f.index + 1, 0, m); out.push(m.id); }
        });
        if (out.length) this.setSelection(out); this.commit();
      },
      repeatRadial: function () {
        var ids = this.selIds(true); if (!ids.length) return; var tr = this.tr, n = Math.max(2, Math.min(24, Math.round(tr.n))), me = this, all = ids.slice(); this.pushUndo();
        ids.forEach(function (id) {
          var f = SP.find(me.sp, id); if (!f) return; var cp = SP.radial(f.node, tr.cx, tr.cy, n, tr.sweep), per = SP.count({ nodes: [f.node] });
          var room = Math.floor((SP.LIMIT.nodes - SP.count(me.sp)) / per); if (room < cp.length) cp = cp.slice(0, Math.max(0, room));
          if (!cp.length) return; Array.prototype.splice.apply(f.list, [f.index + 1, 0].concat(cp)); cp.forEach(function (c) { all.push(c.id); });
        });
        this.setSelection(all, ids[ids.length - 1]); this.commit();
      },
      delNode: function () {
        var ids = this.selIds(true); if (!ids.length) return; this.pushUndo(); var me = this;
        ids.forEach(function (id) { var f = SP.find(me.sp, id); if (f) f.list.splice(f.index, 1); });
        this.sel = []; this.selId = ''; this.commit();
      },
      dupNode: function () {
        var ids = this.selIds(true); if (!ids.length) return; this.pushUndo(); var me = this, out = [];
        ids.forEach(function (id) {
          var f = SP.find(me.sp, id); if (!f) return; var c = SP.reid(SP.clone(f.node)); if (SP.count(me.sp) + SP.count({ nodes: [c] }) > SP.LIMIT.nodes) return;
          c.name = (c.name + ' 2').slice(0, 24); f.list.splice(f.index + 1, 0, c); out.push(c.id);
        });
        if (out.length) this.setSelection(out); this.commit();
      },
      moveZ: function (d) {
        var ids = this.selIds(true), me = this, set = {}; if (!ids.length) return; ids.forEach(function (i) { set[i] = 1; }); this.pushUndo();
        (d > 0 ? ids.slice().reverse() : ids).forEach(function (id) {
          var f = SP.find(me.sp, id); if (!f) return; var j = f.index + d; if (j < 0 || j >= f.list.length || set[f.list[j].id]) return;
          var t = f.list[f.index]; f.list[f.index] = f.list[j]; f.list[j] = t;
        });
        this.commit();
      },
      wrapGroup: function () {
        var ids = this.selIds(true), me = this; if (!ids.length || SP.count(this.sp) >= SP.LIMIT.nodes) return;
        var finds = ids.map(function (i) { return SP.find(me.sp, i); }), last = finds[finds.length - 1], hmax = 0;
        finds.forEach(function (f) { hmax = Math.max(hmax, (function hh(n) { var m = 0; (n.children || []).forEach(function (c) { m = Math.max(m, hh(c)); }); return 1 + m; })(f.node)); });
        var gd = 0; SP.walk(this.sp.nodes, function (n, p, l, i, depth) { if (n.id === last.node.id) gd = depth; });
        if (gd + hmax > SP.LIMIT.depth) return;
        this.pushUndo(); var g = SP.node('group', { name: 'Skupina' }); last.list.splice(last.index, 1, g);
        ids.forEach(function (id) { if (id === last.node.id) g.children.push(last.node); else { var f = SP.find(me.sp, id); f.list.splice(f.index, 1); g.children.push(f.node); } });
        this.fold[g.id] = false; this.setSelection([g.id]); this.commit();
      },
      reparent: function (pid) {
        var f = SP.find(this.sp, this.selId); if (!f) return; this.pushUndo();
        f.list.splice(f.index, 1);
        if (!pid) this.sp.nodes.push(f.node); else { var g = SP.find(this.sp, pid); (g ? g.node.children : this.sp.nodes).push(f.node); }
        this.commit();
      },

      /* ---------- hřiště ---------- */
      resize: function () {
        var w = this.$refs.wrap, cv = this.$refs.cv; if (!w || !cv) return;
        var d = window.devicePixelRatio || 1; this.dpr = d; this.W = w.clientWidth; this.H = w.clientHeight;
        cv.width = Math.max(1, Math.round(this.W * d)); cv.height = Math.max(1, Math.round(this.H * d)); cv.style.width = this.W + 'px'; cv.style.height = this.H + 'px';
      },
      cs: function () { return CELL * this.view.zoom; },
      aimNow: function (t) { return this.view.anim ? t * 0.8 : (this.view.aimDeg || 0) * Math.PI / 180; },
      phaseNow: function () { return this.view.phase || (S.ui.tab === 'enemies' ? 'center' : 'corner'); },
      toggleBox: function (n) { var a = this.boxSel[S.ui.tab], i = a.indexOf(n); if (i >= 0) a.splice(i, 1); else a.push(n); },
      addCustomBox: function () { var n = Math.round(+this.customBox); if (n >= 1 && n <= 60) { var a = this.boxSel[S.ui.tab]; if (a.indexOf(n) < 0) a.push(n); if (this.sizeChoices.indexOf(n) < 0) this.sizeChoices.push(n); } this.customBox = null; },
      zoomBy: function (k) { this.view.zoom = Math.min(60, Math.max(0.5, this.view.zoom * k)); },
      fitView: function () { this.view.px = 0; this.view.py = 0; this.view.zoom = S.ui.tab === 'enemies' ? Math.max(1, Math.min(14, 2.2 / (((this.cur && this.cur.r) || 0.3) * 2) * 1)) : 5; this.view.zoom = Math.round(this.view.zoom * 10) / 10; },
      pWheel: function (ev) {
        var r = this.$refs.cv.getBoundingClientRect(), mx = ev.clientX - r.left - this.W / 2 - this.view.px, my = ev.clientY - r.top - this.H / 2 - this.view.py, k = Math.exp(-ev.deltaY * 0.0016);
        var z0 = this.view.zoom, z1 = Math.min(60, Math.max(0.5, z0 * k)), q = z1 / z0;
        this.view.zoom = z1; this.view.px -= mx * (q - 1); this.view.py -= my * (q - 1);
      },
      localPt: function (ev) { var r = this.$refs.cv.getBoundingClientRect(); return { x: ev.clientX - r.left, y: ev.clientY - r.top }; },
      unitPx: function () { if (S.ui.tab === 'ammo') return ((this.cur && this.cur[this.ph] && this.cur[this.ph].size) || 1) / 2 * this.cs(); return S.ui.tab === 'enemies' ? ((this.cur && this.cur.r) || 0.3) * this.cs() : this.cs(); },
      spriteState: function (t) { return { t: t, aim: this.aimNow(t), alpha: this.cur && this.cur.ghost ? 0.6 : 1 }; },
      pDown: function (ev) {
        var p = this.localPt(ev), cv = this.$refs.cv; cv.setPointerCapture(ev.pointerId);
        this.drag = { x: p.x, y: p.y, x0: p.x, y0: p.y, mode: 'pan', moved: false };
        if (ev.button === 0 && this.panel === 'look' && this.sp) {
          var ctx = cv.getContext('2d'), d = this.dpr, ox = (this.W / 2 + this.view.px) * d, oy = (this.H / 2 + this.view.py) * d, self = this, st = this.spriteState(this.animT || 0), u = this.unitPx() * d;
          var pickAt = function (only) { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); var r = SP.draw(ctx, self.sp, ox, oy, u, st, { pick: { x: p.x * d, y: p.y * d }, only: only || null }); ctx.restore(); return r; };
          var ctrl = ev.ctrlKey || ev.metaKey, alt = ev.altKey;
          /* nejdřív: je pod myší už vybraný tvar? pak se jím hýbe (i když je nad ním jiný); Alt = vybrat to, co je nahoře */
          var hit = false; if (!ctrl && !alt) this.selIds(true).forEach(function (id) { if (!hit && pickAt(id)) hit = true; });
          if (hit) this.drag.mode = 'node';
          else {
            var id = pickAt(null);
            if (id) {
              this.reveal(id);
              if (ctrl) { var i = this.sel.indexOf(id); if (i >= 0) { this.sel.splice(i, 1); if (this.selId === id) this.selId = this.sel[this.sel.length - 1] || ''; } else { this.sel.push(id); this.selId = id; } }
              else { this.setSelection([id], id); this.drag.mode = 'node'; }
            }
          }
        }
      },
      pMove: function (ev) {
        var p = this.localPt(ev), d = this.drag, cs = this.cs();
        var wx = (p.x - this.W / 2 - this.view.px) / cs, wy = (p.y - this.H / 2 - this.view.py) / cs;
        this.posText = 'x ' + (Math.round(wx * 100) / 100) + ' · y ' + (Math.round(wy * 100) / 100) + ' buněk';
        if (!d) return;
        var dx = p.x - d.x, dy = p.y - d.y;
        if (d.mode === 'pan') { this.view.px += dx; this.view.py += dy; }
        else if (d.mode === 'node') {
          var me = this;
          if (!d.items) {
            d.items = this.selIds(true).map(function (id) { var f = SP.find(me.sp, id), m = me.rec && me.rec[id]; return f && m ? { n: f.node, inv: m.inverse(), nx: f.node.x, ny: f.node.y } : null; }).filter(Boolean);
            if (!d.items.length) return; this.pushUndo();
          }
          var tx = p.x - d.x0, ty = p.y - d.y0;
          if (ev.shiftKey && (tx || ty)) { var an = Math.round(Math.atan2(ty, tx) / (Math.PI / 4)) * Math.PI / 4, pr = tx * Math.cos(an) + ty * Math.sin(an); tx = pr * Math.cos(an); ty = pr * Math.sin(an); }   // Shift = po osách 45°
          var dpr = this.dpr;
          d.items.forEach(function (it) {
            var a = it.inv.transformPoint(new DOMPoint(d.x0 * dpr, d.y0 * dpr)), b = it.inv.transformPoint(new DOMPoint((d.x0 + tx) * dpr, (d.y0 + ty) * dpr));
            it.n.x = Math.round((it.nx + (b.x - a.x)) * 100) / 100; it.n.y = Math.round((it.ny + (b.y - a.y)) * 100) / 100;
          });
          this.commit();
        }
        d.x = p.x; d.y = p.y;
      },
      pUp: function () { this.drag = null; },

      tick: function () { this.raf = requestAnimationFrame(this.tick); this.paint(); if (S.ui.tab === 'ammo') this.paintAmmo(); },
      apScrub: function (v) { this.apT = +v; this.ap.play = false; },
      /* náhled střeliva: věž vlevo, cíl vpravo; výstřel i let začínají spolu v čase 0, dopad přijde po doletu */
      paintAmmo: function () {
        var cv = this.$refs.acv, c = this.cur, R = BD.render.ammo; if (!cv || !c || !c.muzzle) return;
        var d = Math.min(2, window.devicePixelRatio || 1), W = cv.clientWidth, H = cv.clientHeight; if (!W || !H) return;
        if (cv.width !== Math.round(W * d) || cv.height !== Math.round(H * d)) { cv.width = Math.round(W * d); cv.height = Math.round(H * d); }
        var now = performance.now(), dt = this.apLast ? Math.min(0.1, (now - this.apLast) / 1000) : 0; this.apLast = now;
        var tf = this.apFlight, total = this.apTotal, DIST = 4.5;
        if (this.ap.play) { this.apT += dt; if (this.apT > total + 0.5) this.apT = 0; }
        var t = Math.min(this.apT, total), sl = this.$refs.ascrub; if (sl && this.ap.play) sl.value = t;
        var ctx = cv.getContext('2d'), cell = Math.min(H / 3.4, W / (DIST + 3)), x0 = (W - DIST * cell) / 2, y0 = H / 2, clk = now / 1000;
        ctx.setTransform(d, 0, 0, d, 0, 0); ctx.fillStyle = '#172420'; ctx.fillRect(0, 0, W, H);
        ctx.strokeStyle = 'rgba(255,255,255,.06)'; ctx.lineWidth = 1;
        for (var gx = x0 - Math.floor(x0 / cell) * cell; gx < W; gx += cell) { ctx.beginPath(); ctx.moveTo(gx, 0); ctx.lineTo(gx, H); ctx.stroke(); }
        ctx.fillStyle = '#2b3d37'; ctx.strokeStyle = '#7fe3cf'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x0, y0, cell * 0.8, 0, TAU); ctx.fill(); ctx.stroke();       // věž
        ctx.fillStyle = '#7fe3cf'; ctx.fillRect(x0, y0 - cell * 0.12, cell * 0.8, cell * 0.24);
        var hit = t >= tf, ty = y0, tx = x0 + DIST * cell;
        ctx.save(); ctx.translate(tx, ty); var wob = hit ? Math.max(0, 1 - (t - tf) / 0.3) : 0; ctx.rotate(wob * 0.3);
        ctx.beginPath(); ctx.arc(0, 0, cell * 0.38, 0, TAU); ctx.fillStyle = '#e077c0'; ctx.fill(); ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 2; ctx.stroke(); ctx.restore();           // cíl
        ctx.save(); ctx.translate(x0, y0);
        var m = c.muzzle, im = c.impact, sh = c.shot;
        if (t < (m.dur || 0.2)) R.phase(ctx, m, (m.dist || 0) * cell, 0, cell, t / (m.dur || 0.2), 0, clk);
        if (t < tf) {
          var pr = t / tf, mk = function (tt) { var q = Math.max(0, Math.min(1, tt / tf)); return { x: q * DIST, y: 0, ang: 0, lift: c.flight === 'arc' ? Math.sin(Math.PI * q) * 0.3 * DIST : 0 }; };
          var o = mk(t); o.age = t; o.trail = []; var tn = Math.ceil((sh.trail || 0) * 10);
          for (var i = tn; i >= 1; i--) { var tp = mk(t - i * 0.03); if (t - i * 0.03 >= 0) o.trail.push({ x: tp.x, y: 0, a: 0, l: tp.lift }); }
          if (!R.shot(ctx, o, c, cell, clk)) { ctx.beginPath(); ctx.arc(o.x * cell, -o.lift * cell, (sh.size || 0.3) / 2 * cell, 0, TAU); ctx.fillStyle = c.color; ctx.fill(); }
        } else if (t < tf + (im.dur || 0.3)) R.phase(ctx, im, DIST * cell, 0, cell, (t - tf) / (im.dur || 0.3), 0, clk);
        ctx.restore();
      },
      /* nakreslí jednu entitu (nepřítel / věž) se středem v (cx,cy) při velikosti buňky cs; vlastní vzhled se bere z pracovní kopie */
      /* věž tak, jak ji nakreslí hra (s čtverečky úrovně); vzhled podle úrovně / větve zvoleného stupně */
      towerReal: function (ctx, cx, cy, cs, t) {
        var size = BD.SUB, tw = { type: S.ui.sel, boost: 1, x: cx / cs - size / 2, y: cy / cs - size / 2, size: size, level: 1, tier: 0, angle: this.aimNow(t), cool: 0 };
        tw.s = BD.systems.towers.stats(tw); tw.hp = tw.s.hp; BD.render.draw.tower(ctx, tw, cs);
      },
      entity: function (ctx, cx, cy, cs, t, opts) {
        var c = this.cur, D = BD.render.draw, tab = S.ui.tab;
        if (tab === 'ammo') { var pp = c[this.ph]; if (this.sp && pp) SP.draw(ctx, this.sp, cx, cy, (pp.size || 1) / 2 * cs, this.spriteState(t), opts); else if (pp && this.ph === 'shot') { ctx.beginPath(); ctx.arc(cx, cy, (pp.size || 0.3) / 2 * cs, 0, TAU); ctx.fillStyle = c.color; ctx.fill(); } return; }
        if (this.sp) { SP.draw(ctx, this.sp, cx, cy, tab === 'enemies' ? c.r * cs : cs, this.spriteState(t), opts); return; }
        if (tab === 'enemies') { D.enemy(ctx, { type: S.ui.sel, id: 1, x: cx / cs, y: cy / cs, slow: 0, hp: 1, maxhp: 1 }, cs); return; }
        var size = BD.SUB, tw = { type: S.ui.sel, branch: null, boost: 1, x: cx / cs - size / 2, y: cy / cs - size / 2, size: size, level: 1, tier: 0, angle: this.aimNow(t), cool: 0 };
        tw.s = BD.systems.towers.stats(tw); tw.hp = tw.s.hp; D.tower(ctx, tw, cs);
      },
      paint: function () {
        var cv = this.$refs.cv, c = this.cur; if (!cv || !this.W) return;
        var ctx = cv.getContext('2d'), d = this.dpr, W = this.W, H = this.H, cs = this.cs(), v = this.view, light = v.light;
        var t = (performance.now() - this.t0) / 1000; this.animT = t;
        ctx.setTransform(d, 0, 0, d, 0, 0); ctx.fillStyle = light ? '#e8e4d8' : '#172420'; ctx.fillRect(0, 0, W, H);
        if (!c) return;
        var ox = W / 2 + v.px, oy = H / 2 + v.py, line = light ? 'rgba(0,0,0,' : 'rgba(255,255,255,', ph = this.phaseNow() === 'corner' ? 0 : 0.5, i;
        if (v.grid && cs >= 4) {
          /* podlaha stejná jako ve hře: šachovnice buněk, jemné čáry buněk, výraznější čáry po 2 buňkách (hranice věží) */
          var kx0 = Math.floor((0 - ox) / cs - ph), kx1 = Math.ceil((W - ox) / cs - ph), ky0 = Math.floor((0 - oy) / cs - ph), ky1 = Math.ceil((H - oy) / cs - ph), kx, ky;
          if (!light) for (ky = ky0; ky <= ky1; ky++) for (kx = kx0; kx <= kx1; kx++) { ctx.fillStyle = (kx + ky) & 1 ? '#1b2a25' : '#172420'; ctx.fillRect(ox + (kx + ph) * cs, oy + (ky + ph) * cs, cs + 1, cs + 1); }
          ctx.lineWidth = 1;
          for (kx = kx0; kx <= kx1 + 1; kx++) { i = Math.round(ox + (kx + ph) * cs) + .5; ctx.strokeStyle = line + (kx % 2 ? '.05' : '.12') + ')'; ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, H); ctx.stroke(); }
          for (ky = ky0; ky <= ky1 + 1; ky++) { i = Math.round(oy + (ky + ph) * cs) + .5; ctx.strokeStyle = line + (ky % 2 ? '.05' : '.12') + ')'; ctx.beginPath(); ctx.moveTo(0, i); ctx.lineTo(W, i); ctx.stroke(); }
        }
        if (v.axes) {
          ctx.lineWidth = 1.2; ctx.strokeStyle = 'rgba(229,107,97,.8)'; ctx.beginPath(); ctx.moveTo(0, oy); ctx.lineTo(W, oy); ctx.stroke();
          ctx.strokeStyle = 'rgba(64,184,154,.8)'; ctx.beginPath(); ctx.moveTo(ox, 0); ctx.lineTo(ox, H); ctx.stroke();
          ctx.fillStyle = light ? '#444' : '#aab'; ctx.font = '10px ui-monospace, monospace'; ctx.textAlign = 'center';
          var step = cs >= 40 ? 1 : cs >= 16 ? 2 : 5, k;
          for (k = -Math.floor(ox / cs / step) * step; ox + k * cs < W; k += step) { if (k && ox + k * cs > 0) { ctx.beginPath(); ctx.moveTo(ox + k * cs, oy - 3); ctx.lineTo(ox + k * cs, oy + 3); ctx.stroke(); ctx.fillText(k, ox + k * cs, oy + 14); } }
          ctx.textAlign = 'left';
          for (k = -Math.floor(oy / cs / step) * step; oy + k * cs < H; k += step) { if (k && oy + k * cs > 0) { ctx.beginPath(); ctx.moveTo(ox - 3, oy + k * cs); ctx.lineTo(ox + 3, oy + k * cs); ctx.stroke(); ctx.fillText(k, ox + 7, oy + k * cs + 3); } }
        }
        if (v.guides) {
          ctx.lineWidth = 1.5; ctx.font = '600 11px Sora, sans-serif'; ctx.textAlign = 'left';
          var cols = ['rgba(240,191,76,.95)', 'rgba(110,200,255,.95)', 'rgba(255,140,170,.95)', 'rgba(150,230,140,.95)'];
          this.boxes.slice().sort(function (p, q) { return q - p; }).forEach(function (n, j) {
            var col = cols[j % cols.length], hs = n * cs / 2; ctx.setLineDash([6, 4]); ctx.strokeStyle = col; ctx.strokeRect(ox - hs, oy - hs, n * cs, n * cs); ctx.setLineDash([]);
            var tx = Math.min(Math.max(ox - hs + 4, 2), W - 60), ty = Math.min(Math.max(oy - hs - 4, 12), H - 4); ctx.fillStyle = col; ctx.fillText(n + '×' + n + ' buněk', tx, ty);
          });
          if (S.ui.tab === 'enemies') { ctx.strokeStyle = 'rgba(255,255,255,.35)'; ctx.setLineDash([2, 3]); ctx.beginPath(); ctx.arc(ox, oy, c.r * cs, 0, TAU); ctx.stroke(); ctx.setLineDash([]); }
        }
        if (this.panel === 'look' && this.selNode && v.toolGuides && this.sp) {          // osa zrcadlení a střed opakování
          var up = this.unitPx(), mx = ox + this.tm.cx * up, my = oy + this.tm.cy * up, ta = this.tm.ang * Math.PI / 180, L = Math.max(W, H) * 2;
          ctx.save(); ctx.lineWidth = 1.2; ctx.setLineDash([8, 4]); ctx.strokeStyle = 'rgba(200,140,255,.9)'; ctx.beginPath(); ctx.moveTo(mx - Math.cos(ta) * L, my - Math.sin(ta) * L); ctx.lineTo(mx + Math.cos(ta) * L, my + Math.sin(ta) * L); ctx.stroke();
          ctx.setLineDash([]); ctx.beginPath(); ctx.arc(mx, my, 4, 0, TAU); ctx.fillStyle = 'rgba(200,140,255,.95)'; ctx.fill();
          var rx = ox + this.tr.cx * up, ry = oy + this.tr.cy * up; ctx.strokeStyle = 'rgba(110,220,200,.95)'; ctx.beginPath(); ctx.moveTo(rx - 7, ry); ctx.lineTo(rx + 7, ry); ctx.moveTo(rx, ry - 7); ctx.lineTo(rx, ry + 7); ctx.stroke();
          ctx.restore();
        }
        if (v.range && (S.ui.tab === 'enemies' || S.ui.tab === 'towers')) {
          var R = S.ui.tab === 'enemies' ? ((c.atkDmg > 0 ? c.atkRange : 0) * BD.SUB * cs) : BD.systems.towers.stats({ type: S.ui.sel, branch: null, level: 1, tier: 0, size: BD.SUB }).range * cs;
          if (R > 0) { ctx.beginPath(); ctx.arc(ox, oy, R, 0, TAU); ctx.fillStyle = 'rgba(240,191,76,.07)'; ctx.fill(); ctx.strokeStyle = 'rgba(240,191,76,.5)'; ctx.stroke(); }
        }
        if (v.target) {                                                         // smyšlený cíl: obíhá kolem objektu, předek směřuje k němu
          var aim = this.aimNow(t), R = (S.ui.tab === 'enemies' ? Math.max(c.r * 2.4, 1.2) : 2.6) * cs, tx2 = ox + Math.cos(aim) * R, ty2 = oy + Math.sin(aim) * R;
          ctx.save(); ctx.lineWidth = 1; ctx.setLineDash([3, 5]); ctx.strokeStyle = 'rgba(255,255,255,.22)'; ctx.beginPath(); ctx.arc(ox, oy, R, 0, TAU); ctx.stroke();
          ctx.setLineDash([]); ctx.strokeStyle = 'rgba(255,107,97,.85)'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(ox + Math.cos(aim) * 0.6 * cs, oy + Math.sin(aim) * 0.6 * cs); ctx.lineTo(tx2, ty2); ctx.stroke();
          ctx.beginPath(); ctx.arc(tx2, ty2, 9, 0, TAU); ctx.moveTo(tx2 - 14, ty2); ctx.lineTo(tx2 + 14, ty2); ctx.moveTo(tx2, ty2 - 14); ctx.lineTo(tx2, ty2 + 14); ctx.stroke();
          ctx.fillStyle = 'rgba(255,107,97,.95)'; ctx.font = '600 11px Sora, sans-serif'; ctx.textAlign = 'left'; ctx.fillText('cíl', tx2 + 12, ty2 - 10);
          var hx = ox + Math.cos(aim) * 0.9 * cs, hy = oy + Math.sin(aim) * 0.9 * cs; ctx.fillStyle = 'rgba(255,107,97,.95)'; ctx.save(); ctx.translate(hx, hy); ctx.rotate(aim); ctx.beginPath(); ctx.moveTo(10, 0); ctx.lineTo(-4, -6); ctx.lineTo(-4, 6); ctx.closePath(); ctx.fill(); ctx.restore();
          ctx.fillStyle = 'rgba(150,230,140,.95)'; ctx.font = '600 10px Sora, sans-serif'; ctx.textAlign = 'right'; ctx.fillText('předek = směr k cíli (0° = doprava →)', W - 14, 18);
          ctx.restore();
        }
        /* entita (s nahráváním matic vrstev pro tažení myší) */
        ctx.save(); ctx.setTransform(d, 0, 0, d, 0, 0);
        this.rec = {}; this.entity(ctx, ox, oy, cs, t, { sel: this.panel === 'look' ? this.selId : '', sels: this.panel === 'look' ? this.selMap : null, rec: this.rec });
        ctx.restore();
        if (v.real) {                                                         // rámeček se skutečnou velikostí (buňka = 26 px, jako ve hře)
          var bw = 120, bx = 12, by = H - bw - 12;
          ctx.setTransform(d, 0, 0, d, 0, 0); ctx.fillStyle = '#172420'; ctx.fillRect(bx, by, bw, bw); for (var qy = 0; qy * CELL < bw; qy++) for (var qx = 0; qx * CELL < bw; qx++) if ((qx + qy) & 1) { ctx.fillStyle = '#1b2a25'; ctx.fillRect(bx + qx * CELL, by + qy * CELL, Math.min(CELL, bw - qx * CELL), Math.min(CELL, bw - qy * CELL)); } ctx.strokeStyle = 'rgba(255,255,255,.25)'; ctx.strokeRect(bx + .5, by + .5, bw, bw);
          ctx.save(); ctx.beginPath(); ctx.rect(bx, by, bw, bw); ctx.clip(); if (S.ui.tab === 'towers') this.towerReal(ctx, bx + bw / 2, by + bw / 2 + 4, CELL, t); else this.entity(ctx, bx + bw / 2, by + bw / 2 + 4, CELL, t, null); ctx.restore();
          ctx.fillStyle = '#8e95a3'; ctx.font = '10px Sora, sans-serif'; ctx.textAlign = 'left'; ctx.fillText('ve hře (×1)', bx + 6, by + 12);
        }
      },
    },
  };
})(window.BD);
