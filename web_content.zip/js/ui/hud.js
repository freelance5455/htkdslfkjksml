'use strict';
/* ================= HUD ================= */
function buildHot(){
 const hot=$('hot');hot.innerHTML='';
 for(let i=0;i<9;i++){
  const b=document.createElement('button');b.className='slot';b.dataset.i=i;
  b.innerHTML='<svg viewBox="0 0 24 24"></svg><u></u>';
  b.addEventListener('pointerdown',ev=>{ev.stopPropagation();});
  b.addEventListener('click',()=>{slotIdx=i;refreshHud();const id=HOT[i];toast(id?ITEMS[id].n+(owns(id)?'':' (غير مصنوع)'):'خانة فارغة، ضع فيها عنصراً من الحقيبة');});
  hot.appendChild(b);
 }
}
let lastHp=-1,lastFd=-1,lastO2=-1;
function refreshHud(){
 if(!P)return;
 const hs=$('hot').children,list=hotList();
 for(let i=0;i<hs.length;i++){
  const id=list[i],b=hs[i];b.classList.toggle('on',i===slotIdx);b.classList.toggle('lock',!!id&&!owns(id));
  b.querySelector('svg').innerHTML=id?ICONS[id]:'';
  let t='';if(id&&!creative){const it=ITEMS[id];if(it.type==='ranged')t=INV[it.ammo]||0;else if(it.type==='build')t=Object.keys(it.cost).map(k=>it.cost[k]).join('/');else if(it.type==='block')t=INV[id]||0;}
  b.querySelector('u').textContent=t;b.setAttribute('aria-label',id?ITEMS[id].n:'خانة فارغة');
 }
 const inv=$('inv');if(creative){inv.innerHTML='<span><i>وضع الإبداع</i></span>';}
 else inv.innerHTML=Object.keys(INV).filter(k=>INV[k]>0).map(k=>'<span><i>'+NAMES[k]+'</i><b>'+INV[k]+'</b></span>').join('');
 $('coinV').textContent=S.coins;$('gemV').textContent=S.gems|0;
 if(!document.body.classList.contains('swim'))$('bEat').style.display=creative?'none':'grid';
 refreshHeld();
 if($('bag').classList.contains('on'))renderBag();
}
function hudBars(){
 const h=Math.max(0,Math.round(P.hp)),f=Math.max(0,Math.round(P.food)),o=Math.max(0,Math.round(P.air));
 if(h!==lastHp){lastHp=h;$('hpB').firstElementChild.style.width=h+'%';$('hpT').textContent='الصحة '+h;}
 if(f!==lastFd){lastFd=f;$('fdB').firstElementChild.style.width=f+'%';$('fdT').textContent='الجوع '+f;}
 const show=(P.swim||o<100)&&!creative;$('o2B').style.display=show?'block':'none';
 if(o!==lastO2){lastO2=o;$('o2B').firstElementChild.style.width=o+'%';$('o2T').textContent='الهواء '+o;}
}

