/* OPERATION: DISCIPLINE — infraestrutura de interface: estado da tela, transações, modais, toasts, navegação, delegação de eventos.
   Sem handlers inline (compatível com CSP) e sem funções globais: tudo vive em OD.UI. */
(function(){'use strict';
var OD=globalThis.OD,U=OD.U,G=OD.G,Core=OD.Core,UI=OD.UI={};
var esc=U.esc,K='od-v1',PK='od-prev';
var td=function(){return U.iso(new Date())};
var st=null;try{st=window.localStorage}catch(e){}
var L0=Core.loadState(st,K);
var App=UI.App={S:L0.S,C:Core.mk(L0.S),blocked:L0.blocked,warn:L0.warn,sw:'',tab:'home',cur:td(),hm:td().slice(0,7),hs:null,fl:7,cf:U.add(td(),-6),ct:td(),q:{text:'',s:'',cat:'',pr:'',df:'',all:false,sort:''},notes:L0.notes||[],migrated:L0.migrated};
UI.K=K;UI.PK=PK;UI.st=st;UI.td=td;UI.esc=esc;
UI.L={ST:{P:'Pendente',A:'Em andamento',C:'Concluída',F:'Falhou',X:'Cancelada',R:'Reagendada'},DL:{S:'Simples',M:'Moderada',H:'Difícil',C:'Crítica'},PL:{L:'Baixa',M:'Média',H:'Alta'},
 RL:{PERFECT:'Dia perfeito',PARTIAL:'Parcial',REST:'Descanso',EXCUSED:'Exceção justificada',UNPLANNED:'Sem planejamento',PLANNED:'Planejado'},
 EV:{criada:'Criada',editada:'Editada',iniciada:'Iniciada',concluida:'Concluída',cancelada:'Cancelada',reagendada:'Reagendada',falhou:'Falhou',reaberta:'Reaberta'},
 SORT:{time:'Horário',priority:'Prioridade',xp:'XP',title:'Título'}};
var $=function(s,r){return(r||document).querySelector(s)};UI.$=$;
UI.A={};UI.CH={};UI.views={};

/* ---------- feedback ---------- */
function toast(m,ok){var h=$('#toasts');if(!h){h=document.createElement('div');h.id='toasts';h.setAttribute('role','status');h.setAttribute('aria-live','polite');document.body.appendChild(h)}
 var e=document.createElement('div');e.className='ts'+(ok?' ok':'');e.textContent=m;h.appendChild(e);setTimeout(function(){e.remove()},ok?3000:5500)}
UI.toast=toast;

/* ---------- transações ---------- */
/* Tudo passa por Core.transact: só vira estado visível depois de gravado e conferido. msg: texto de sucesso (opcional). */
UI.run=function(f,msg,quiet){
 if(App.blocked){if(!quiet)toast('Alterações bloqueadas: armazenamento indisponível ou integridade não confirmada. Nada foi alterado.');return false}
 var lv0=G.lvl(App.C.total());
 try{var r=Core.transact(st,K,App.S,f,td(),{force:!!App.migrated});App.migrated=false;App.S=r.S;App.C=r.C;App.sw='';UI.draw();
  if(msg&&r.changed!==false)toast(msg,true);var lv1=G.lvl(App.C.total());if(lv1>lv0)toast('Nível '+lv1+' · '+G.rank(lv1),true);return true}
 catch(e){if(e.stale){App.blocked=true;App.sw='⚠ Dados alterados em outra janela. Reinicie o aplicativo; nada foi alterado.';UI.draw();toast(e.message);return false}
  if(e.storage){App.sw='⚠ NÃO SALVO: '+e.message+' A última alteração foi descartada.';UI.draw()}
  if(!quiet||e.storage)toast(e.message);return false}};

/* ---------- modais ---------- */
var modals=[],skip=0,armed=false;
/* Botão Voltar do Android: uma única entrada de histórico "armada" enquanto houver modal aberto ou aba diferente de Início. A reconciliação é assíncrona e coalescida (sem corridas). */
function sync(){setTimeout(function(){var need=modals.length>0||App.tab!=='home';if(need&&!armed){try{history.pushState({app:1},'')}catch(e){}armed=true}else if(!need&&armed){armed=false;skip++;try{history.back()}catch(e){skip--}}},0)}
UI.modal=function(title,body,btns,opt){opt=opt||{};var o=document.createElement('div');o.className='ov';
 o.innerHTML='<div class="md" role="dialog" aria-modal="true" aria-labelledby="mt"><h2 id="mt">'+esc(title)+'</h2><div class="mb">'+body+'</div><div class="row mf"></div></div>';
 o._ret=document.activeElement;document.body.appendChild(o);modals.push(o);bg(true);sync();
 var r=$('.mf',o);(btns||[]).forEach(function(b){var el=document.createElement('button');el.type='button';el.textContent=b[0];if(b[2])el.className=b[2];
  el.addEventListener('click',function(){if(b[1]&&b[1](o)===false)return;UI.close(o)});r.appendChild(el)});
 o.addEventListener('mousedown',function(e){if(e.target===o&&!opt.sticky)UI.close(o)});
 var f=$('input:not([type=hidden]),textarea,select',o)||$('button',o);if(f&&!opt.nofocus)try{f.focus({preventScroll:true})}catch(e){}return o};
/* Fundo inerte enquanto houver modal; foco volta ao elemento que abriu o modal. */
function bg(on){['v','nav'].forEach(function(id){var e=document.getElementById(id);if(!e)return;if(on)e.setAttribute('inert','');else e.removeAttribute('inert')})}
function back(o){var r=o&&o._ret;if(r&&document.contains(r)&&!modals.length)try{r.focus({preventScroll:true})}catch(e){}}
UI.close=function(o){var i=modals.indexOf(o);if(i<0)return;modals.splice(i,1);o.remove();if(!modals.length)bg(false);back(o);sync()};
UI.closeAll=function(){modals.forEach(function(o){o.remove()});modals=[];bg(false);sync()};
document.addEventListener('keydown',function(e){if(!modals.length)return;var o=modals[modals.length-1];
 if(e.key==='Escape'){UI.close(o);return}
 if(e.key==='Tab'){var f=[].slice.call(o.querySelectorAll('button,input,select,textarea,[href]')).filter(function(x){return!x.disabled&&x.type!=='hidden'});if(!f.length)return;
  var a=document.activeElement,fi=f[0],la=f[f.length-1];if(e.shiftKey&&(a===fi||!o.contains(a))){e.preventDefault();la.focus()}else if(!e.shiftKey&&(a===la||!o.contains(a))){e.preventDefault();fi.focus()}}});
UI.confirm=function(msg,fn,label,cls){UI.modal('Confirmar','<p>'+msg+'</p>',[['Cancelar'],[label||'Confirmar',function(){fn()},cls||'p']])};

/* ---------- formulários ---------- */
UI.field=function(l,ctl){return'<label class="fl"><span>'+esc(l)+'</span>'+ctl+'</label>'};
UI.inp=function(n,l,t,v,x){return UI.field(l,'<input name="'+n+'" type="'+t+'" value="'+esc(v==null?'':v)+'" '+(x||'')+'>')};
UI.sel=function(n,l,opts,v,x){return UI.field(l,'<select name="'+n+'" '+(x||'')+'>'+opts.map(function(o){return'<option value="'+esc(o[0])+'"'+(String(o[0])===String(v)?' selected':'')+'>'+esc(o[1])+'</option>'}).join('')+'</select>')};
UI.F=function(o,k){return o.querySelector('[name='+k+']')};
UI.pg=function(c,t){return'<div class="bar" role="progressbar" aria-valuemin="0" aria-valuemax="'+t+'" aria-valuenow="'+Math.min(c,t)+'"><i style="width:'+(t?Math.min(100,c/t*100):0)+'%"></i></div>'};
UI.sd=function(v,d){return U.validDate(v)?v:d};
UI.ic=function(p){return'<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+p+'</svg>'};

/* ---------- navegação ---------- */
var TABS=[['home','Início','<path d="M3 11l9-8 9 8M5 10v10h14V10"/>'],['missions','Missões','<path d="M9 6h11M9 12h11M9 18h11M4 6l1 1 2-2M4 12l1 1 2-2M4 18l1 1 2-2"/>'],['stats','Stats','<path d="M5 20V10M12 20V4M19 20v-7"/>'],['hist','Histórico','<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>'],['profile','Perfil','<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>']];
UI.go=function(t){UI.closeAll();if(t!==App.tab){App.tab=t;sync();UI.draw()}window.scrollTo(0,0)};
window.addEventListener('popstate',function(){if(skip>0){skip--;return}
 armed=false;if(modals.length){var m=modals.pop();m.remove();if(!modals.length)bg(false);back(m)}else if(App.tab!=='home'){App.tab='home';UI.draw()}sync()});

/* ---------- desenho ---------- */
UI.draw=function(){var y=window.scrollY,v=UI.views[App.tab],h;
 try{h=v()}catch(e){h='<div class="c">Erro ao desenhar a tela: '+esc(e.message)+'</div>'}
 $('#v').innerHTML=h;var w=$('#warn');w.textContent=App.sw||App.warn||'';
 $('#nav').innerHTML=TABS.map(function(t){return'<button type="button" data-a="tab" data-t="'+t[0]+'" class="'+(t[0]===App.tab?'on':'')+'"'+(t[0]===App.tab?' aria-current="page"':'')+'>'+UI.ic(t[2])+'<span>'+t[1]+'</span></button>'}).join('');
 window.scrollTo(0,y)};
UI.A.tab=function(el){UI.go(el.dataset.t)};

/* ---------- delegação de eventos ---------- */
document.addEventListener('click',function(e){var el=e.target.closest('[data-a]');if(!el||el.disabled)return;var f=UI.A[el.dataset.a];if(f)f(el,e)});
['change','input'].forEach(function(ev){document.addEventListener(ev,function(e){var el=e.target.closest('[data-c]');if(!el)return;var h=UI.CH[el.dataset.c];if(h&&(h.ev||'change')===ev)h.fn(el,e)})});
/* teclado virtual: mantém o campo focado visível */
document.addEventListener('focusin',function(e){if(/INPUT|TEXTAREA|SELECT/.test(e.target.tagName))setTimeout(function(){try{e.target.scrollIntoView({block:'center'})}catch(_){}},350)});
UI.reload=function(S){App.S=S;App.C=Core.mk(S);App.sw='';UI.draw()};
})();
