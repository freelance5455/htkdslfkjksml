/* Ikony – jedna komponenta <ic n="jmeno"></ic>
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  var ICONS = {
    heart: 'M12 20s-7-4.4-9.2-9A5.2 5.2 0 0 1 12 6.6 5.2 5.2 0 0 1 21.2 11C19 15.6 12 20 12 20z',
    coin: 'M12 4a8 8 0 1 0 0 16 8 8 0 0 0 0-16zM12 9v6M9.5 10.5h3.8M9.5 13.5h3.8',
    play: 'M7 4.5l12 7.5-12 7.5z',
    pause: 'M8 5v14M16 5v14',
    fast: 'M4 5l7 7-7 7M13 5l7 7-7 7',
    trash: 'M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13',
    up: 'M12 19V5M5 12l7-7 7 7',
    merge: 'M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z',
    plus: 'M12 5v14M5 12h14',
    refresh: 'M4 12a8 8 0 1 1 2.5 5.8M4 19v-5h5',
    copy: 'M9 9h10v11H9zM5 15V4h10',
    save: 'M5 4h12l2 2v14H5zM8 4v5h7V4M8 20v-6h8v6',
    rock: 'M4 17l3-9 5-3 6 4 2 8z',
    erase: 'M5 16l8-9 6 5-6 7H8zM8 19h11',
    spawn: 'M12 4v13M6 12l6 6 6-6',
    exit: 'M5 21V4M5 5h12l-2 4 2 4H5',
    menu: 'M4 7h16M4 12h16M4 17h16',
    back: 'M15 5l-7 7 7 7',
    check: 'M5 12.5l4.5 4.5L19 7.5',
    close: 'M6 6l12 12M18 6L6 18',
    download: 'M12 4v11M7 11l5 5 5-5M5 20h14',
    upload: 'M12 16V5M7 9l5-5 5 5M5 20h14',
    gear: 'M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6zM19.4 13a7.5 7.5 0 0 0 0-2l2-1.5-2-3.4-2.3 1a7.6 7.6 0 0 0-1.7-1L15 3.5h-4l-.4 2.6a7.6 7.6 0 0 0-1.7 1l-2.3-1-2 3.4 2 1.5a7.5 7.5 0 0 0 0 2l-2 1.5 2 3.4 2.3-1c.5.4 1.100.7 1.700 1l.4 2.600h4l.4-2.600c.6-.3 1.200-.6 1.700-1l2.300 1 2-3.400z',
    book: 'M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2zM4 19a2 2 0 0 1 2-2h13',
    bookopen: 'M12 7C10.5 5.3 8 4.6 3.5 4.6V18c4.5 0 7 .6 8.5 2.4 1.5-1.8 4-2.4 8.5-2.4V4.6C16 4.6 13.5 5.3 12 7zM12 7v13.4',
    bubble: 'M12 4a8 8 0 1 0 0 16 8 8 0 0 0 0-16zM8.5 9.5a4 4 0 0 1 3-2',
    tower: 'M12 6a6 6 0 1 0 0 12 6 6 0 0 0 0-12zM12 10a2 2 0 1 0 0 4 2 2 0 0 0 0-4zM4 4h3M17 4h3M4 20h3M17 20h3',
    star: 'M12 4l2.4 5 5.4.7-4 3.7 1 5.4-4.8-2.7-4.8 2.7 1-5.4-4-3.7 5.4-.7z',
    inf: 'M7 8a4 4 0 1 0 0 8c4 0 6-8 10-8a4 4 0 1 1 0 8c-4 0-6-8-10-8z',
    pencil: 'M4 20l1-5L16 4l4 4L9 19zM14 6l4 4',
    flag: 'M5 21V4M5 5h12l-2 4 2 4H5',
    lock: 'M6 11h12v9H6zM8.5 11V8a3.5 3.5 0 0 1 7 0v3',
    zoomin: 'M10.5 4a6.5 6.5 0 1 0 0 13 6.5 6.5 0 0 0 0-13zM15.5 15.5L20 20M10.5 7.5v6M7.5 10.5h6',
    zoomout: 'M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5',
  };
  BD.ui.ICONS = ICONS;
  BD.ui.components.Ic = {
    props: ['n'],
    template: '<svg class="ic" viewBox="0 0 24 24"><path :d="d"></path></svg>',
    computed: { d: function () { return ICONS[this.n] || ''; } },
  };
})(window.BD);
