import { drawLessonVisual } from "./imageBuilder.js";
import {
  composePlantCell, composeHeart, drawParametricRecipe,
  drawBirdInFlight, drawCatalogDiagram
} from "../engines/parametricEngine.js";
// Port of ui/render.py — every question "diagram" and lab "chart" is drawn live on a
// <canvas>, never a static image file, so questions can be regenerated infinitely.
export const PALETTE = ["#3157D5", "#159A68", "#D64545", "#F5A623", "#8B5CF6", "#06B6D4", "#EC4899"];

function setupCanvas(canvas, w, h, bg = "#ffffff") {
  const dpr = window.devicePixelRatio || 1;
  canvas.width = Math.round(w * dpr);
  canvas.height = Math.round(h * dpr);
  canvas.style.width = w + "px";
  canvas.style.height = h + "px";
  const ctx = canvas.getContext("2d");
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, w, h);
  ctx.lineCap = "round";
  return ctx;
}
function ln(ctx, x1, y1, x2, y2) { ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); }
function dot(ctx, cx, cy, r, color) { ctx.fillStyle = color; ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.fill(); }
function circ(ctx, cx, cy, r) { ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.stroke(); }
function txt(ctx, s, x, y, color = "#222", align = "left") { ctx.fillStyle = color; ctx.textAlign = align; ctx.textBaseline = "alphabetic"; ctx.fillText(s, x, y); }
function ctxt(ctx, s, x, y, color = "#222") { ctx.fillStyle = color; ctx.textAlign = "center"; ctx.textBaseline = "middle"; ctx.fillText(s, x, y); }
function leader(ctx, x1, y1, x2, y2, label, align = "left") {
  ctx.strokeStyle = "#555"; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
  ctx.fillStyle = "#111"; ctx.font = "11px sans-serif";
  ctx.textAlign = align; ctx.textBaseline = "middle";
  ctx.fillText(label, align === "right" ? x2 - 4 : x2 + 4, y2);
}

function drawGrid(ctx, w, h, span = 34) {
  const step = Math.min(w, h) / span;
  const cx = w / 2, cy = h / 2;
  ctx.strokeStyle = "#e0e0e0"; ctx.lineWidth = 1;
  for (let x = cx; x < w; x += step) ln(ctx, x, 0, x, h);
  for (let x = cx; x > 0; x -= step) ln(ctx, x, 0, x, h);
  for (let y = cy; y < h; y += step) ln(ctx, 0, y, w, y);
  for (let y = cy; y > 0; y -= step) ln(ctx, 0, y, w, y);
  ctx.strokeStyle = "#333"; ctx.lineWidth = 2;
  ln(ctx, 0, cy, w, cy);
  ln(ctx, cx, 0, cx, h);
}

// ================= QUESTION / GEOMETRY DIAGRAMS =================
export function drawDiagram(canvas, diagram, w = 320, h = 240) {
  if (diagram && (diagram.type === "bar_chart" || diagram.type === "solid3d" || diagram.type === "fraction" || diagram.type === "place_value" || diagram.type === "banner")) {
    drawLessonVisual(canvas, diagram, w, h);
    return;
  }

  const ctx = setupCanvas(canvas, w, h);
  if (!diagram) return;
  const d = diagram, kind = d.type;
  ctx.strokeStyle = "#3157D5"; ctx.lineWidth = 3;
  ctx.font = "bold 14px sans-serif";
  // Parametric / Naderi-style constructive diagrams
  if (drawCatalogDiagram(ctx, w, h, kind) !== null) {
    return;
  }

  if (kind === "right_triangle") {
    const margin = 40, base = Math.min(w, h) - 2 * margin, x0 = margin, y0 = h - margin;
    ln(ctx, x0, y0, x0 + base, y0);
    ln(ctx, x0, y0, x0, y0 - base * 0.75);
    ln(ctx, x0 + base, y0, x0, y0 - base * 0.75);
    ctx.strokeRect(x0, y0 - 14, 14, 14);
    const { a, b, c, find } = d;
    if ("a" in d) txt(ctx, `${find !== "a" ? a : "?"} cm`, x0 + base / 2 - 10, y0 + 22);
    if ("b" in d) txt(ctx, `${find !== "b" ? b : "?"} cm`, x0 - 34, y0 - base * 0.35);
    if ("c" in d) txt(ctx, `${find !== "c" ? c : "?"} cm`, x0 + base / 2 - 10, y0 - base * 0.45);
  } else if (kind === "triangle_bh") {
    const margin = 40, base = Math.min(w, h) - 2 * margin, x0 = margin, y0 = h - margin;
    const apex = { x: x0 + base * 0.4, y: y0 - base * 0.7 };
    ln(ctx, x0, y0, x0 + base, y0);
    ln(ctx, x0, y0, apex.x, apex.y);
    ln(ctx, x0 + base, y0, apex.x, apex.y);
    ctx.save(); ctx.strokeStyle = "#999"; ctx.setLineDash([4, 4]); ctx.lineWidth = 1;
    ln(ctx, apex.x, apex.y, apex.x, y0);
    ctx.restore();
    ctx.strokeStyle = "#3157D5";
    txt(ctx, `base = ${d.b ?? "?"} cm`, x0 + base / 2 - 20, y0 + 22);
    txt(ctx, `h = ${d.h ?? "?"} cm`, apex.x + 6, (apex.y + y0) / 2);
  } else if (kind === "rectangle") {
    const margin = 40, rw = Math.min(w - 2 * margin, 220), rh = Math.min(h - 2 * margin, 140);
    const x0 = (w - rw) / 2, y0 = (h - rh) / 2;
    ctx.strokeRect(x0, y0, rw, rh);
    txt(ctx, `l = ${d.l ?? "?"} cm`, x0 + rw / 2 - 20, y0 - 10);
    txt(ctx, `w = ${d.w ?? "?"}`, x0 - 34, y0 + rh / 2);
  } else if (kind === "circle") {
    const rPx = Math.min(w, h) / 2 - 40, cx = w / 2, cy = h / 2;
    circ(ctx, cx, cy, rPx);
    ln(ctx, cx, cy, cx + rPx, cy);
    txt(ctx, `r = ${d.r ?? "?"} cm`, cx + rPx / 2 - 10, cy - 6);

  } else if (kind === "polygon") {
    const n = Math.max(3, d.sides || 5);
    const cx = w / 2, cy = h / 2, r = Math.min(w, h) / 2 - 36;
    ctx.beginPath();
    for (let i = 0; i < n; i++) {
      const ang = -Math.PI / 2 + (i * 2 * Math.PI) / n;
      const x = cx + r * Math.cos(ang), y = cy + r * Math.sin(ang);
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.closePath(); ctx.strokeStyle = "#3157D5"; ctx.lineWidth = 3; ctx.stroke();
    txt(ctx, n + " sides", cx - 24, h - 18);
  } else if (kind === "straight_line_angles") {
    const y = h / 2;
    ln(ctx, 30, y, w - 30, y);
    const vx = w * 0.55;
    ln(ctx, vx, y, vx - 60, y - 70);
    txt(ctx, `${d.known ?? "?"}°`, vx - 55, y - 40);
    txt(ctx, "x", vx + 10, y - 20);
  } else if (kind === "angles_at_point") {
    const cx = w / 2, cy = h / 2, r = Math.min(w, h) / 2 - 30;
    [0, 100, 220].forEach((ang) => { const rad = (ang * Math.PI) / 180; ln(ctx, cx, cy, cx + r * Math.cos(rad), cy - r * Math.sin(rad)); });
    txt(ctx, `${d.a ?? "?"}°`, cx + 20, cy - 30);
    txt(ctx, `${d.b ?? "?"}°`, cx - 60, cy - 30);
    txt(ctx, "y", cx - 20, cy + 45);
  } else if (kind === "vertical_angles") {
    const cx = w / 2, cy = h / 2, r = Math.min(w, h) / 2 - 30;
    ln(ctx, cx - r, cy - r * 0.4, cx + r, cy + r * 0.4);
    ln(ctx, cx - r, cy + r * 0.4, cx + r, cy - r * 0.4);
    txt(ctx, `${d.known ?? "?"}°`, cx + 12, cy - 30);
    txt(ctx, "?", cx - 40, cy + 40);
  } else if (kind === "translation" || kind === "reflect_x" || kind === "reflect_y") {
    drawGrid(ctx, w, h);
    const scale = Math.min(w, h) / 34, cx = w / 2, cy = h / 2;
    const x = d.x ?? 0, y = d.y ?? 0;
    const p1 = { x: cx + x * scale, y: cy - y * scale };
    ctx.strokeStyle = "#3157D5";
    dot(ctx, p1.x, p1.y, 6, "#3157D5");
    txt(ctx, `(${x},${y})`, p1.x + 8, p1.y - 8);
    let p2;
    if (kind === "translation") { const a = d.a ?? 0, b = d.b ?? 0; p2 = { x: cx + (x + a) * scale, y: cy - (y + b) * scale }; }
    else if (kind === "reflect_x") p2 = { x: cx + x * scale, y: cy + y * scale };
    else p2 = { x: cx - x * scale, y: cy - y * scale };
    dot(ctx, p2.x, p2.y, 6, "#D64545");
    ctx.save(); ctx.strokeStyle = "#999"; ctx.setLineDash([4, 4]); ctx.lineWidth = 1;
    ln(ctx, p1.x, p1.y, p2.x, p2.y);
    ctx.restore();
  } else if (kind === "coordinate_plane") {
    // Points A, B, C on cartesian plane (analytical geometry)
    drawGrid(ctx, w, h, d.span || 20);
    const scale = Math.min(w, h) / (d.span || 20);
    const cx = w / 2, cy = h / 2;
    const pts = d.points || [];
    pts.forEach((p, i) => {
      const px = cx + (p.x || 0) * scale;
      const py = cy - (p.y || 0) * scale;
      dot(ctx, px, py, 5, PALETTE[i % PALETTE.length]);
      txt(ctx, `${p.label || ""}(${p.x};${p.y})`, px + 8, py - 8, "#222");
    });
    if (d.connect && pts.length >= 2) {
      ctx.strokeStyle = "#3157D5"; ctx.lineWidth = 2;
      for (let i = 0; i < pts.length - 1; i++) {
        ln(ctx, cx + pts[i].x * scale, cy - pts[i].y * scale,
          cx + pts[i + 1].x * scale, cy - pts[i + 1].y * scale);
      }
      if (d.closed && pts.length >= 3) {
        ln(ctx, cx + pts[pts.length - 1].x * scale, cy - pts[pts.length - 1].y * scale,
          cx + pts[0].x * scale, cy - pts[0].y * scale);
      }
    }
  } else if (kind === "hyperbola") {
    // f(x) = a/(x+p) + q with asymptotes
    drawGrid(ctx, w, h, 16);
    const scale = Math.min(w, h) / 16;
    const cx = w / 2, cy = h / 2;
    const a = d.a ?? 2, p = d.p ?? 0, q = d.q ?? 0;
    // asymptotes
    ctx.save();
    ctx.strokeStyle = "#D64545"; ctx.lineWidth = 1.5; ctx.setLineDash([6, 4]);
    ln(ctx, cx + p * scale, 0, cx + p * scale, h); // x = -p in maths → x+p=0
    ln(ctx, 0, cy - q * scale, w, cy - q * scale);
    ctx.restore();
    ctx.strokeStyle = "#3157D5"; ctx.lineWidth = 2.5;
    ctx.beginPath();
    let started = false;
    for (let px = 0; px < w; px += 2) {
      const x = (px - cx) / scale;
      if (Math.abs(x + p) < 0.15) { started = false; continue; }
      const y = a / (x + p) + q;
      const py = cy - y * scale;
      if (py < -20 || py > h + 20) { started = false; continue; }
      if (!started) { ctx.moveTo(px, py); started = true; }
      else ctx.lineTo(px, py);
    }
    ctx.stroke();
    txt(ctx, `x = ${-p}`, cx + p * scale + 6, 16, "#D64545");
    txt(ctx, `y = ${q}`, 8, cy - q * scale - 6, "#D64545");
    if (d.intercept) {
      const ix = d.intercept.x, iy = d.intercept.y;
      dot(ctx, cx + ix * scale, cy - iy * scale, 5, "#159A68");
      txt(ctx, `(${ix};${iy})`, cx + ix * scale + 6, cy - iy * scale - 6, "#159A68");
    }
  } else if (kind === "exponential") {
    // f(x) = a·b^x + q
    drawGrid(ctx, w, h, 16);
    const scale = Math.min(w, h) / 16;
    const cx = w / 2, cy = h / 2;
    const a = d.a ?? 1, b = d.b ?? 2, q = d.q ?? 0;
    ctx.save();
    ctx.strokeStyle = "#D64545"; ctx.lineWidth = 1.5; ctx.setLineDash([6, 4]);
    ln(ctx, 0, cy - q * scale, w, cy - q * scale);
    ctx.restore();
    ctx.strokeStyle = "#3157D5"; ctx.lineWidth = 2.5;
    ctx.beginPath();
    let started = false;
    for (let px = 0; px < w; px += 2) {
      const x = (px - cx) / scale;
      const y = a * Math.pow(b, x) + q;
      if (!Number.isFinite(y) || Math.abs(y) > 40) { started = false; continue; }
      const py = cy - y * scale;
      if (py < -10 || py > h + 10) { started = false; continue; }
      if (!started) { ctx.moveTo(px, py); started = true; }
      else ctx.lineTo(px, py);
    }
    ctx.stroke();
    // y-intercept
    const y0 = a + q;
    dot(ctx, cx, cy - y0 * scale, 5, "#159A68");
    txt(ctx, `(0;${y0})`, cx + 8, cy - y0 * scale - 6, "#159A68");
    txt(ctx, `y = ${q}`, 8, cy - q * scale - 6, "#D64545");
  } else if (kind === "parabola") {
    drawGrid(ctx, w, h, 16);
    const scale = Math.min(w, h) / 16;
    const cx = w / 2, cy = h / 2;
    const a = d.a ?? 1, b = d.b ?? 0, c = d.c ?? 0;
    ctx.strokeStyle = "#3157D5"; ctx.lineWidth = 2.5;
    ctx.beginPath();
    let started = false;
    for (let px = 0; px < w; px += 2) {
      const x = (px - cx) / scale;
      const y = a * x * x + b * x + c;
      const py = cy - y * scale;
      if (py < -20 || py > h + 20) { started = false; continue; }
      if (!started) { ctx.moveTo(px, py); started = true; }
      else ctx.lineTo(px, py);
    }
    ctx.stroke();
    const xv = -b / (2 * a);
    const yv = a * xv * xv + b * xv + c;
    if (Number.isFinite(xv) && Number.isFinite(yv)) {
      dot(ctx, cx + xv * scale, cy - yv * scale, 5, "#159A68");
      txt(ctx, `(${Math.round(xv * 10) / 10};${Math.round(yv * 10) / 10})`, cx + xv * scale + 6, cy - yv * scale - 6, "#159A68");
    }
  } else if (kind === "box_whisker") {

    const vals = (d.values || [10, 25, 40, 55, 70]).slice().sort((a, b) => a - b);
    const min = vals[0], max = vals[vals.length - 1];
    const q1 = d.q1 ?? vals[Math.floor(vals.length * 0.25)];
    const med = d.median ?? vals[Math.floor(vals.length * 0.5)];
    const q3 = d.q3 ?? vals[Math.floor(vals.length * 0.75)];
    const pad = 40;
    const mapX = (v) => pad + ((v - min) / Math.max(1, max - min)) * (w - 2 * pad);
    const midY = h / 2;
    ctx.strokeStyle = "#3157D5"; ctx.lineWidth = 2;
    ln(ctx, mapX(min), midY, mapX(q1), midY);
    ln(ctx, mapX(q3), midY, mapX(max), midY);
    ctx.strokeRect(mapX(q1), midY - 30, mapX(q3) - mapX(q1), 60);
    ln(ctx, mapX(med), midY - 30, mapX(med), midY + 30);
    dot(ctx, mapX(min), midY, 4, "#3157D5");
    dot(ctx, mapX(max), midY, 4, "#3157D5");
    txt(ctx, String(min), mapX(min) - 8, midY + 48);
    txt(ctx, String(q1), mapX(q1) - 8, midY - 38);
    txt(ctx, String(med), mapX(med) - 8, midY + 48);
    txt(ctx, String(q3), mapX(q3) - 8, midY - 38);
    txt(ctx, String(max), mapX(max) - 8, midY + 48);
  } else if (kind === "tree_diagram") {
    // Simple two-stage tree
    const cx = 40, cy = h / 2;
    const stages = d.stages || [
      { labels: ["A", "A'"], probs: ["0,4", "0,6"] },
      { labels: ["B", "B'"], probs: ["0,3", "0,7"] }
    ];
    ctx.strokeStyle = "#3157D5"; ctx.lineWidth = 2;
    const x1 = w * 0.35, x2 = w * 0.75;
    ln(ctx, cx, cy, x1, cy - 40);
    ln(ctx, cx, cy, x1, cy + 40);
    ln(ctx, x1, cy - 40, x2, cy - 70);
    ln(ctx, x1, cy - 40, x2, cy - 10);
    ln(ctx, x1, cy + 40, x2, cy + 10);
    ln(ctx, x1, cy + 40, x2, cy + 70);
    const s0 = stages[0], s1 = stages[1];
    txt(ctx, `${s0.labels[0]} (${s0.probs[0]})`, x1 - 10, cy - 50);
    txt(ctx, `${s0.labels[1]} (${s0.probs[1]})`, x1 - 10, cy + 55);
    txt(ctx, `${s1.labels[0]} (${s1.probs[0]})`, x2 + 4, cy - 70);
    txt(ctx, `${s1.labels[1]} (${s1.probs[1]})`, x2 + 4, cy - 10);
    txt(ctx, `${s1.labels[0]} (${s1.probs[0]})`, x2 + 4, cy + 10);
    txt(ctx, `${s1.labels[1]} (${s1.probs[1]})`, x2 + 4, cy + 70);
  } else if (kind === "circle_geometry") {
    const cx = w / 2, cy = h / 2 + 10, r = Math.min(w, h) / 2 - 36;
    circ(ctx, cx, cy, r);
    // centre O
    dot(ctx, cx, cy, 3, "#333");
    txt(ctx, "O", cx - 12, cy - 8);
    // points on circumference
    const pts = d.points || [
      { label: "A", ang: 200 }, { label: "B", ang: 320 }, { label: "C", ang: 40 }
    ];
    const coords = pts.map((p) => {
      const rad = (p.ang * Math.PI) / 180;
      return { label: p.label, x: cx + r * Math.cos(rad), y: cy - r * Math.sin(rad) };
    });
    coords.forEach((p) => {
      dot(ctx, p.x, p.y, 4, "#3157D5");
      txt(ctx, p.label, p.x + 6, p.y - 6);
    });
    if (d.chords) {
      ctx.strokeStyle = "#3157D5"; ctx.lineWidth = 2;
      d.chords.forEach(([i, j]) => {
        if (coords[i] && coords[j]) ln(ctx, coords[i].x, coords[i].y, coords[j].x, coords[j].y);
      });
    }
    if (d.angleLabel) {
      txt(ctx, d.angleLabel, cx - 20, cy + r * 0.3, "#D64545");
    }
  } else if (kind === "vectors_2d") {
    const cx = 50, cy = h - 40;
    const vx = (d.vx || 8) * 8, vy = (d.vy || 6) * 8;
    ctx.strokeStyle = "#888"; ln(ctx, 30, cy, w - 20, cy); ln(ctx, cx, 20, cx, h - 20);
    ctx.strokeStyle = "#3157D5"; ctx.lineWidth = 3;
    ln(ctx, cx, cy, cx + vx, cy);
    ln(ctx, cx, cy, cx, cy - vy);
    ctx.strokeStyle = "#D64545";
    ln(ctx, cx, cy, cx + vx, cy - vy);
    txt(ctx, "R", cx + vx / 2 + 8, cy - vy / 2 - 6, "#D64545");
    txt(ctx, "x", cx + vx + 6, cy + 14);
    txt(ctx, "y", cx - 18, cy - vy - 4);
  } else if (kind === "second_diff_tree") {
    // Number pattern: terms → first differences → second differences
    const terms = d.terms || [4, 9, 16, 25];
    const n = terms.length;
    const gap = Math.min(70, (w - 40) / Math.max(1, n - 1));
    const y0 = 36, y1 = h / 2, y2 = h - 36;
    const x0 = 30;
    // terms
    terms.forEach((v, i) => {
      const x = x0 + i * gap;
      txt(ctx, String(v), x - 6, y0, "#222");
      if (i < n - 1) {
        const fd = terms[i + 1] - terms[i];
        const mx = x + gap / 2;
        ln(ctx, x + 10, y0 + 6, mx, y1 - 10);
        ln(ctx, x + gap - 10, y0 + 6, mx, y1 - 10);
        txt(ctx, String(fd), mx - 8, y1, "#3157D5");
      }
    });
    // second diffs
    for (let i = 0; i < n - 2; i++) {
      const fd1 = terms[i + 1] - terms[i];
      const fd2 = terms[i + 2] - terms[i + 1];
      const sd = fd2 - fd1;
      const mx = x0 + (i + 1) * gap;
      ln(ctx, x0 + i * gap + gap / 2, y1 + 8, mx, y2 - 10);
      ln(ctx, x0 + (i + 1) * gap + gap / 2, y1 + 8, mx, y2 - 10);
      txt(ctx, String(sd), mx - 8, y2, "#D64545");
    }
    txt(ctx, "terms", 4, y0 - 14, "#666");
    txt(ctx, "1st Δ", 4, y1 - 4, "#3157D5");
    txt(ctx, "2nd Δ", 4, y2 - 4, "#D64545");
  } else if (kind === "free_body") {

    const cx = w / 2, cy = h / 2;
    ctx.fillStyle = "#ddd"; ctx.strokeStyle = "#3157D5";
    ctx.fillRect(cx - 24, cy - 24, 48, 48); ctx.strokeRect(cx - 24, cy - 24, 48, 48);
    txt(ctx, (d.mass ? d.mass + " kg" : "m"), cx - 16, cy + 4);
    const map = { right: [60, 0], left: [-60, 0], up: [0, -60], down: [0, 60] };
    (d.forces || []).forEach((f) => {
      const off = map[f.dir] || [60, 0];
      ctx.strokeStyle = "#D64545"; ctx.lineWidth = 2.5;
      ln(ctx, cx, cy, cx + off[0], cy + off[1]);
      txt(ctx, f.label || "F", cx + off[0] + 4, cy + off[1] - 4, "#D64545");
    });
  } else if (kind === "coulomb") {
    const y = h / 2;
    dot(ctx, 70, y, 10, "#3157D5");
    dot(ctx, w - 70, y, 10, "#D64545");
    txt(ctx, `Q₁=${d.q1 ?? "?"}`, 40, y - 22);
    txt(ctx, `Q₂=${d.q2 ?? "?"}`, w - 110, y - 22);
    ln(ctx, 90, y, w - 90, y);
    txt(ctx, `r = ${d.r ?? "?"} cm`, w / 2 - 30, y + 22);
  } else if (kind === "circuit_simple" || kind === "circuit_series") {
    const y = h / 2;
    ctx.strokeRect(40, y - 18, 28, 36);
    txt(ctx, `${d.V ?? "V"}V`, 36, y - 26);
    ln(ctx, 68, y, w - 80, y);
    ctx.strokeRect(w / 2 - 30, y - 12, 60, 24);
    txt(ctx, `${d.R ?? d.R1 ?? "R"}Ω`, w / 2 - 18, y + 36);
    if (kind === "circuit_series") txt(ctx, `${d.R2 ?? ""}Ω`, w / 2 + 40, y - 20);
  } else if (kind === "cell_simple") {
    const cx = w / 2, cy = h / 2;
    ctx.strokeStyle = "#3157D5"; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.ellipse(cx, cy, 70, 50, 0, 0, Math.PI * 2); ctx.stroke();
    ctx.fillStyle = "#7b9bff";
    ctx.beginPath(); ctx.arc(cx - 15, cy - 5, 14, 0, Math.PI * 2); ctx.fill();
    txt(ctx, "nucleus", cx - 35, cy - 28, "#333");
  } else if (kind === "map_scale") {
    ln(ctx, 40, h / 2, w - 40, h / 2);
    ln(ctx, 40, h / 2 - 8, 40, h / 2 + 8);
    ln(ctx, w - 40, h / 2 - 8, w - 40, h / 2 + 8);
    txt(ctx, "0", 36, h / 2 + 24);
    txt(ctx, "1 km", w - 55, h / 2 + 24);
  } else if (kind === "wave") {
    ctx.beginPath();
    for (let x = 20; x < w - 20; x++) {
      const y = h / 2 + 40 * Math.sin((x - 20) / 18);
      if (x === 20) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.strokeStyle = "#3157D5"; ctx.lineWidth = 2; ctx.stroke();
    txt(ctx, `λ`, w / 2, 22);
  } else if (kind === "energy_profile") {
    ctx.beginPath();
    ctx.moveTo(30, h - 50);
    ctx.quadraticCurveTo(w * 0.35, 30, w * 0.5, 50);
    const endY = d.exo ? h - 80 : h - 30;
    ctx.quadraticCurveTo(w * 0.65, 40, w - 30, endY);
    ctx.strokeStyle = "#3157D5"; ctx.lineWidth = 2.5; ctx.stroke();
    txt(ctx, "reactants", 24, h - 20);
    txt(ctx, "products", w - 90, endY + 16);
    txt(ctx, "Eₐ", w * 0.35, 22);
  } else if (kind === "gravitation") {
    const y = h / 2;
    ctx.fillStyle = "#3157D5";
    ctx.beginPath(); ctx.arc(80, y, 22, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(w - 80, y, 28, 0, Math.PI * 2); ctx.fill();
    txt(ctx, `m₁`, 68, y + 4, "#fff");
    txt(ctx, `m₂`, w - 92, y + 4, "#fff");
    ctx.strokeStyle = "#D64545"; ctx.lineWidth = 2;
    ln(ctx, 110, y, w - 115, y);
    txt(ctx, "F", w / 2 - 6, y - 12, "#D64545");
  } else if (kind === "electric_field") {
    const cx = w / 2, cy = h / 2;
    const pos = (d.sign || "+") === "+";
    ctx.fillStyle = pos ? "#D64545" : "#3157D5";
    ctx.beginPath(); ctx.arc(cx, cy, 14, 0, Math.PI * 2); ctx.fill();
    txt(ctx, d.sign || "+", cx - 5, cy + 4, "#fff");
    ctx.strokeStyle = "#888";
    for (let a = 0; a < 8; a++) {
      const ang = (a / 8) * Math.PI * 2;
      const x1 = cx + Math.cos(ang) * 22, y1 = cy + Math.sin(ang) * 22;
      const x2 = cx + Math.cos(ang) * 70, y2 = cy + Math.sin(ang) * 70;
      ln(ctx, x1, y1, x2, y2);
    }
  } else if (kind === "bond_energy") {
    ctx.beginPath();
    ctx.moveTo(30, 30);
    ctx.quadraticCurveTo(w * 0.25, h - 30, w * 0.45, h - 50);
    ctx.quadraticCurveTo(w * 0.7, h - 40, w - 20, 40);
    ctx.strokeStyle = "#3157D5"; ctx.lineWidth = 2.5; ctx.stroke();
    txt(ctx, "E", 12, 24);
    txt(ctx, "r", w - 24, h - 12);
    txt(ctx, "bond length", w * 0.35, h - 12, "#666");
  } else if (kind === "imf_bars") {
    const items = [["London", 40], ["Dipole", 70], ["H-bond", 110]];
    items.forEach((it, i) => {
      const y = 40 + i * 45;
      ctx.fillStyle = "#3157D5";
      ctx.fillRect(100, y, it[1], 22);
      txt(ctx, it[0], 20, y + 16);
    });
  } else if (kind === "mole_triangle") {
    ctx.strokeStyle = "#3157D5"; ctx.lineWidth = 2;
    ln(ctx, w / 2, 30, 40, h - 30);
    ln(ctx, w / 2, 30, w - 40, h - 30);
    ln(ctx, 40, h - 30, w - 40, h - 30);
    txt(ctx, "m", w / 2 - 6, 24);
    txt(ctx, "n", 50, h - 36);
    txt(ctx, "M", w - 60, h - 36);
  } else if (kind === "proton_transfer") {
    txt(ctx, "HA  +  B   ⇌   A⁻  +  HB⁺", 40, h / 2);
    txt(ctx, "acid      base        conjugate", 40, h / 2 + 28, "#666");
  } else if (kind === "redox_arrow") {
    txt(ctx, "Reductant  →  loses e⁻  →  oxidised", 30, h / 2 - 16);
    txt(ctx, "Oxidant    →  gains e⁻  →  reduced", 30, h / 2 + 16);
  } else if (kind === "solenoid") {

    for (let i = 0; i < 6; i++) {
      ctx.beginPath();
      ctx.ellipse(70 + i * 28, h / 2, 14, 36, 0, 0, Math.PI * 2);
      ctx.stroke();
    }
    txt(ctx, "solenoid", w / 2 - 30, h - 18);
  } else if (kind === "lewis_pair") {
    txt(ctx, "A : B", w / 2 - 28, h / 2);
    txt(ctx, "shared pair", w / 2 - 40, h / 2 + 24);
  } else if (kind === "number_line") {
    const y = h / 2;
    ln(ctx, 20, y, w - 20, y);
    const lo = d.min ?? -5, hi = d.max ?? 5;
    const map = (v) => 20 + ((v - lo) / ((hi - lo) || 1)) * (w - 40);
    for (let v = lo; v <= hi; v++) {
      ln(ctx, map(v), y - 6, map(v), y + 6);
      txt(ctx, String(v), map(v) - 4, y + 22);
    }
    if (d.interval) {
      const [a, b] = d.interval;
      ctx.strokeStyle = "#3157D5"; ctx.lineWidth = 4;
      ln(ctx, map(a), y, map(b), y);
      if (d.openLeft) circ(ctx, map(a), y, 5);
      if (d.openRight) circ(ctx, map(b), y, 5);
    }
    if (d.point != null) {
      dot(ctx, map(d.point), y, 6, "#D64545");
      txt(ctx, String(d.point), map(d.point) - 4, y - 14, "#D64545");
    }
  } else if (kind === "solar_system") {
    // CAPS-style schematic: Sun + orbits + planets with leader labels
    const cx = w * 0.42, cy = h * 0.52;
    const maxR = Math.min(w, h) * 0.38;
    const bodies = d.bodies || [
      { name: "Sun", r: 0, color: "#F5A623", radiusPx: 18 },
      { name: "Mercury", r: 0.22, color: "#9CA3AF", radiusPx: 3 },
      { name: "Venus", r: 0.34, color: "#D4A574", radiusPx: 5 },
      { name: "Earth", r: 0.46, color: "#2563EB", radiusPx: 5 },
      { name: "Mars", r: 0.58, color: "#DC2626", radiusPx: 4 },
      { name: "Jupiter", r: 0.78, color: "#C4A35A", radiusPx: 9 },
      { name: "Saturn", r: 0.92, color: "#E8D48B", radiusPx: 8 }
    ];
    ctx.strokeStyle = "#CBD5E1"; ctx.lineWidth = 1;
    bodies.forEach((b) => { if (b.r > 0) circ(ctx, cx, cy, b.r * maxR); });
    bodies.forEach((b, i) => {
      if (b.r === 0) {
        const g = ctx.createRadialGradient(cx - 4, cy - 4, 2, cx, cy, b.radiusPx);
        g.addColorStop(0, "#FDE68A"); g.addColorStop(1, b.color);
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.arc(cx, cy, b.radiusPx, 0, Math.PI * 2); ctx.fill();
        leader(ctx, cx + b.radiusPx, cy, w - 12, 28, "Sun", "right");
      } else {
        const ang = -0.4 + i * 0.55;
        const px = cx + Math.cos(ang) * b.r * maxR;
        const py = cy + Math.sin(ang) * b.r * maxR;
        ctx.fillStyle = b.color;
        ctx.beginPath(); ctx.arc(px, py, b.radiusPx, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = "#334155"; ctx.lineWidth = 0.8; ctx.stroke();
        if (b.name === "Earth" || b.name === "Mars" || b.name === "Jupiter") {
          leader(ctx, px + b.radiusPx, py, w - 12, 40 + i * 16, b.name, "right");
        }
      }
    });
    ctx.font = "bold 12px sans-serif";
    ctxt(ctx, "Solar system (schematic — not to scale)", w / 2, 14, "#334155");
  } else if (kind === "plant_structure") {
    // Textbook plant: roots, stem, leaves, flower with leader labels
    const cx = w * 0.45;
    // soil line
    ctx.strokeStyle = "#A16207"; ctx.lineWidth = 1.5;
    ln(ctx, 20, h * 0.68, w - 20, h * 0.68);
    ctx.fillStyle = "#FEF3C7";
    ctx.fillRect(20, h * 0.68, w - 40, h * 0.28);
    // roots (branching)
    ctx.strokeStyle = "#92400E"; ctx.lineWidth = 2.5;
    ln(ctx, cx, h * 0.68, cx, h * 0.88);
    ln(ctx, cx, h * 0.75, cx - 28, h * 0.9);
    ln(ctx, cx, h * 0.78, cx + 26, h * 0.92);
    ln(ctx, cx, h * 0.82, cx - 12, h * 0.94);
    // stem
    ctx.strokeStyle = "#166534"; ctx.lineWidth = 7;
    ln(ctx, cx, h * 0.68, cx, h * 0.28);
    // leaves (pointed ovals)
    ctx.fillStyle = "#22C55E"; ctx.strokeStyle = "#15803D"; ctx.lineWidth = 1.2;
    [[-1, 0.42, -0.6], [1, 0.38, 0.55], [-1, 0.52, -0.4]].forEach(([side, fy, rot]) => {
      ctx.beginPath();
      ctx.ellipse(cx + side * 32, h * fy, 26, 11, rot, 0, Math.PI * 2);
      ctx.fill(); ctx.stroke();
    });
    // flower
    const fy = h * 0.2;
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2;
      ctx.fillStyle = "#F472B6";
      ctx.beginPath(); ctx.ellipse(cx + Math.cos(a) * 14, fy + Math.sin(a) * 14, 8, 5, a, 0, Math.PI * 2); ctx.fill();
    }
    ctx.fillStyle = "#FBBF24";
    ctx.beginPath(); ctx.arc(cx, fy, 7, 0, Math.PI * 2); ctx.fill();
    // leaders
    leader(ctx, cx - 8, h * 0.86, 14, h * 0.86, "roots", "left");
    leader(ctx, cx + 5, h * 0.48, w - 14, h * 0.48, "stem", "right");
    leader(ctx, cx + 40, h * 0.38, w - 14, h * 0.32, "leaf", "right");
    leader(ctx, cx + 16, fy, w - 14, fy - 6, "flower", "right");
    ctx.font = "bold 12px sans-serif";
    ctxt(ctx, "Plant structure", w / 2, 14, "#334155");
  } else if (kind === "organ_heart") {
    // Schematic heart with chambers — school diagram style
    const cx = w * 0.42, cy = h * 0.5;
    ctx.fillStyle = "#FECACA";
    ctx.beginPath();
    ctx.moveTo(cx, cy + 58);
    ctx.bezierCurveTo(cx - 70, cy + 20, cx - 75, cy - 45, cx - 20, cy - 35);
    ctx.bezierCurveTo(cx - 5, cy - 55, cx + 5, cy - 55, cx + 20, cy - 35);
    ctx.bezierCurveTo(cx + 75, cy - 45, cx + 70, cy + 20, cx, cy + 58);
    ctx.closePath(); ctx.fill();
    ctx.strokeStyle = "#B91C1C"; ctx.lineWidth = 2.5; ctx.stroke();
    // septum + valves suggestion
    ctx.strokeStyle = "#991B1B"; ctx.lineWidth = 1.5;
    ln(ctx, cx, cy - 28, cx, cy + 48);
    ln(ctx, cx - 38, cy + 2, cx + 38, cy + 2);
    ctx.font = "10px sans-serif";
    ctxt(ctx, "RA", cx - 22, cy - 10, "#7F1D1D");
    ctxt(ctx, "LA", cx + 22, cy - 10, "#7F1D1D");
    ctxt(ctx, "RV", cx - 22, cy + 22, "#7F1D1D");
    ctxt(ctx, "LV", cx + 22, cy + 22, "#7F1D1D");
    // aorta stub
    ctx.strokeStyle = "#B91C1C"; ctx.lineWidth = 4;
    ln(ctx, cx + 18, cy - 40, cx + 18, cy - 58);
    leader(ctx, cx + 18, cy - 55, w - 12, 36, "aorta", "right");
    leader(ctx, cx - 40, cy - 5, 12, 50, "right atrium", "left");
    leader(ctx, cx + 40, cy + 20, w - 12, h - 40, "left ventricle", "right");
    ctx.font = "bold 12px sans-serif";
    ctxt(ctx, "Heart (schematic)", w / 2, 14, "#334155");
  } else if (kind === "organ_digestive") {
    // Vertical gut tube with organs — CAPS schematic
    const x = w * 0.38;
    ctx.strokeStyle = "#E11D48"; ctx.lineWidth = 10; ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(x, 36);
    ctx.lineTo(x, 70);
    ctx.quadraticCurveTo(x + 20, 95, x, 120);
    ctx.quadraticCurveTo(x - 25, 150, x + 5, 175);
    ctx.quadraticCurveTo(x + 30, 200, x, h - 28);
    ctx.stroke();
    // stomach bulge
    ctx.fillStyle = "#FCA5A5"; ctx.strokeStyle = "#B91C1C"; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.ellipse(x + 8, 105, 32, 22, 0.3, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    // liver suggestion
    ctx.fillStyle = "#F87171";
    ctx.beginPath(); ctx.ellipse(x - 28, 88, 18, 14, -0.3, 0, Math.PI * 2); ctx.fill();
    leader(ctx, x, 40, w - 12, 40, "mouth / oesophagus", "right");
    leader(ctx, x + 30, 105, w - 12, 100, "stomach", "right");
    leader(ctx, x - 40, 88, 12, 88, "liver", "left");
    leader(ctx, x + 15, 175, w - 12, 170, "small intestine", "right");
    leader(ctx, x, h - 30, w - 12, h - 28, "large intestine", "right");
    ctx.font = "bold 12px sans-serif";
    ctxt(ctx, "Digestive system", w / 2, 14, "#334155");
  } else if (kind === "cell_plant") {
    // Textbook plant cell: wall, membrane, large vacuole, nucleus, chloroplasts, labels
    const x0 = 56, y0 = 36, rw = w - 100, rh = h - 70;
    // cell wall (thick)
    ctx.fillStyle = "#DCFCE7";
    ctx.strokeStyle = "#166534"; ctx.lineWidth = 5;
    ctx.beginPath();
    const r = 12;
    ctx.moveTo(x0 + r, y0);
    ctx.lineTo(x0 + rw - r, y0); ctx.quadraticCurveTo(x0 + rw, y0, x0 + rw, y0 + r);
    ctx.lineTo(x0 + rw, y0 + rh - r); ctx.quadraticCurveTo(x0 + rw, y0 + rh, x0 + rw - r, y0 + rh);
    ctx.lineTo(x0 + r, y0 + rh); ctx.quadraticCurveTo(x0, y0 + rh, x0, y0 + rh - r);
    ctx.lineTo(x0, y0 + r); ctx.quadraticCurveTo(x0, y0, x0 + r, y0);
    ctx.closePath(); ctx.fill(); ctx.stroke();
    // membrane
    ctx.strokeStyle = "#2563EB"; ctx.lineWidth = 1.8;
    ctx.strokeRect(x0 + 7, y0 + 7, rw - 14, rh - 14);
    // large central vacuole
    ctx.fillStyle = "rgba(147, 197, 253, 0.45)";
    ctx.strokeStyle = "#3B82F6"; ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.ellipse(x0 + rw * 0.42, y0 + rh * 0.55, rw * 0.28, rh * 0.28, 0, 0, Math.PI * 2);
    ctx.fill(); ctx.stroke();
    // nucleus
    ctx.fillStyle = "#A5B4FC"; ctx.strokeStyle = "#4338CA"; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.arc(x0 + rw * 0.72, y0 + rh * 0.32, 16, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    ctx.fillStyle = "#6366F1";
    ctx.beginPath(); ctx.arc(x0 + rw * 0.72, y0 + rh * 0.32, 5, 0, Math.PI * 2); ctx.fill();
    // chloroplasts
    [[0.22, 0.25], [0.18, 0.72], [0.75, 0.7], [0.55, 0.2]].forEach(([fx, fy]) => {
      ctx.fillStyle = "#4ADE80"; ctx.strokeStyle = "#15803D"; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.ellipse(x0 + rw * fx, y0 + rh * fy, 14, 8, fx, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    });
    // cytoplasm hint
    ctx.fillStyle = "rgba(254, 243, 199, 0.35)";
    // labels with leaders
    leader(ctx, x0, y0 + 20, 8, 28, "cell wall", "left");
    leader(ctx, x0 + 10, y0 + 40, 8, 48, "membrane", "left");
    leader(ctx, x0 + rw * 0.42, y0 + rh * 0.55, w - 10, h * 0.55, "vacuole", "right");
    leader(ctx, x0 + rw * 0.72 + 14, y0 + rh * 0.32, w - 10, 36, "nucleus", "right");
    leader(ctx, x0 + rw * 0.22 + 12, y0 + rh * 0.25, w - 10, 58, "chloroplast", "right");
    ctx.font = "bold 12px sans-serif";
    ctxt(ctx, "Plant cell", w / 2, 14, "#334155");
  } else if (kind === "cell_animal") {
    const cx = w * 0.4, cy = h * 0.5;
    ctx.fillStyle = "#FEF3C7";
    ctx.strokeStyle = "#2563EB"; ctx.lineWidth = 2.5;
    ctx.beginPath(); ctx.ellipse(cx, cy, 85, 62, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    // nucleus
    ctx.fillStyle = "#A5B4FC"; ctx.strokeStyle = "#4338CA"; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.arc(cx - 15, cy - 8, 20, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    ctx.fillStyle = "#6366F1";
    ctx.beginPath(); ctx.arc(cx - 15, cy - 8, 6, 0, Math.PI * 2); ctx.fill();
    // mitochondria
    [[30, 15], [-35, 28], [25, -30]].forEach(([dx, dy]) => {
      ctx.fillStyle = "#FCA5A5"; ctx.strokeStyle = "#B91C1C"; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.ellipse(cx + dx, cy + dy, 12, 6, 0.4, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    });
    leader(ctx, cx + 85, cy, w - 10, cy, "cell membrane", "right");
    leader(ctx, cx - 15 + 18, cy - 8, w - 10, 40, "nucleus", "right");
    leader(ctx, cx + 30 + 10, cy + 15, w - 10, h - 36, "mitochondrion", "right");
    ctx.font = "bold 12px sans-serif";
    ctxt(ctx, "Animal cell", w / 2, 14, "#334155");
  } else if (kind === "food_web") {
    const nodes = d.nodes || [
      { id: "sun", label: "Sun", level: 0 },
      { id: "grass", label: "Grass", level: 1 },
      { id: "insect", label: "Insect", level: 2 },
      { id: "bird", label: "Bird", level: 3 },
      { id: "hawk", label: "Hawk", level: 4 }
    ];
    const levels = {};
    nodes.forEach((n) => { levels[n.level] = levels[n.level] || []; levels[n.level].push(n); });
    const pos = {};
    Object.keys(levels).forEach((lv) => {
      const arr = levels[lv];
      arr.forEach((n, i) => {
        pos[n.id] = { x: ((i + 1) / (arr.length + 1)) * w, y: 36 + Number(lv) * ((h - 60) / 4), label: n.label };
      });
    });
    ctx.strokeStyle = "#64748B"; ctx.lineWidth = 1.5;
    (d.edges || [["sun","grass"],["grass","insect"],["insect","bird"],["bird","hawk"]]).forEach(([a, b]) => {
      if (pos[a] && pos[b]) {
        ln(ctx, pos[a].x, pos[a].y + 12, pos[b].x, pos[b].y - 12);
        // arrow head
        const ang = Math.atan2(pos[b].y - pos[a].y, pos[b].x - pos[a].x);
        const ax = pos[b].x, ay = pos[b].y - 12;
        ctx.beginPath();
        ctx.moveTo(ax, ay);
        ctx.lineTo(ax - 6 * Math.cos(ang - 0.4), ay - 6 * Math.sin(ang - 0.4));
        ctx.lineTo(ax - 6 * Math.cos(ang + 0.4), ay - 6 * Math.sin(ang + 0.4));
        ctx.closePath(); ctx.fillStyle = "#64748B"; ctx.fill();
      }
    });
    Object.values(pos).forEach((pt) => {
      ctx.fillStyle = "#DBEAFE"; ctx.strokeStyle = "#1D4ED8"; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(pt.x, pt.y, 18, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
      ctx.font = "10px sans-serif"; ctxt(ctx, pt.label, pt.x, pt.y, "#1E3A8A");
    });
    ctx.font = "bold 12px sans-serif";
    ctxt(ctx, "Food chain / web", w / 2, 14, "#334155");
  } else if (kind === "journal_table" || kind === "trial_balance" || kind === "bank_recon" || kind === "income_statement") {
    const title = d.title || String(kind).replaceAll("_", " ");
    const cols = d.cols || (kind === "journal_table"
      ? ["Date", "Details", "Fol", "Debit", "Credit"]
      : kind === "trial_balance" ? ["Account", "Debit", "Credit"] : ["Details", "Amount"]);
    const rows = d.rows || [];
    ctx.font = "bold 13px sans-serif";
    ctxt(ctx, title, w / 2, 16, "#0F172A");
    const top = 30;
    const colW = (w - 16) / Math.max(1, cols.length);
    ctx.fillStyle = "#E0E7FF";
    ctx.fillRect(8, top, w - 16, 24);
    ctx.strokeStyle = "#94A3B8"; ctx.lineWidth = 1;
    ctx.strokeRect(8, top, w - 16, 24 + Math.max(1, rows.length) * 22);
    ctx.font = "bold 11px sans-serif";
    cols.forEach((c, i) => txt(ctx, c, 14 + i * colW, top + 16, "#1E293B"));
    ctx.font = "11px sans-serif";
    rows.forEach((r, ri) => {
      const y = top + 24 + ri * 22 + 15;
      const cells = Array.isArray(r) ? r : [r];
      if (ri % 2 === 1) {
        ctx.fillStyle = "#F8FAFC";
        ctx.fillRect(8, top + 24 + ri * 22, w - 16, 22);
      }
      cells.forEach((cell, i) => txt(ctx, String(cell), 14 + i * colW, y, "#0F172A"));
      ctx.strokeStyle = "#E2E8F0";
      ln(ctx, 8, top + 24 + (ri + 1) * 22, w - 8, top + 24 + (ri + 1) * 22);
    });
  } else if (kind === "t_account") {
    const name = d.account || "Account";
    ctx.font = "bold 14px sans-serif";
    ctxt(ctx, name, w / 2, 18, "#0F172A");
    const mid = w / 2, top = 30, bot = h - 10;
    ctx.strokeStyle = "#0F172A"; ctx.lineWidth = 2;
    ln(ctx, mid, top, mid, bot);
    ln(ctx, 12, top + 20, w - 12, top + 20);
    ctx.font = "bold 12px sans-serif";
    txt(ctx, "Debit", 20, top + 15, "#1D4ED8");
    txt(ctx, "Credit", mid + 10, top + 15, "#B91C1C");
    ctx.font = "11px sans-serif";
    (d.debit || []).forEach((row, i) => {
      const [lab, amt] = row;
      txt(ctx, lab, 16, top + 40 + i * 20, "#334155");
      txt(ctx, amt, mid - 10, top + 40 + i * 20, "#0F172A", "right");
    });
    (d.credit || []).forEach((row, i) => {
      const [lab, amt] = row;
      txt(ctx, lab, mid + 10, top + 40 + i * 20, "#334155");
      txt(ctx, amt, w - 14, top + 40 + i * 20, "#0F172A", "right");
    });
  } else if (kind === "accounting_equation") {
    const a = d.assets ?? 12000, l = d.liabilities ?? 4000, e = d.equity ?? (a - l);
    const total = a || 1;
    const y = h / 2, left = 24, width = w - 48;
    ctx.font = "bold 13px sans-serif";
    ctxt(ctx, "Accounting equation", w / 2, 22, "#0F172A");
    ctx.fillStyle = "#3B82F6";
    ctx.fillRect(left, y - 28, width, 56);
    const ew = (e / total) * width, lw = (l / total) * width;
    ctx.fillStyle = "#10B981"; ctx.fillRect(left, y - 28, ew, 56);
    ctx.fillStyle = "#EF4444"; ctx.fillRect(left + ew, y - 28, lw, 56);
    ctx.font = "bold 12px sans-serif";
    ctxt(ctx, "Assets  R" + a, left + width / 2, y - 42, "#1D4ED8");
    ctxt(ctx, "Equity R" + e, left + Math.max(ew / 2, 30), y + 4, "#fff");
    ctxt(ctx, "Liabilities R" + l, left + ew + Math.max(lw / 2, 30), y + 4, "#fff");
    ctx.font = "12px sans-serif";
    ctxt(ctx, "Assets = Owner's equity + Liabilities", w / 2, h - 18, "#334155");
  } else if (kind === "lever") {
    const y = h * 0.52;
    const f = Math.max(0.15, Math.min(0.85, d.fulcrum ?? 0.4));
    const fx = 36 + f * (w - 72);
    ctx.strokeStyle = "#334155"; ctx.lineWidth = 5;
    ln(ctx, 36, y, w - 36, y);
    ctx.fillStyle = "#64748B";
    ctx.beginPath();
    ctx.moveTo(fx, y); ctx.lineTo(fx - 16, y + 40); ctx.lineTo(fx + 16, y + 40);
    ctx.closePath(); ctx.fill();
    // load & effort blocks
    ctx.fillStyle = "#FCA5A5"; ctx.fillRect(44, y - 36, 28, 28);
    ctx.fillStyle = "#93C5FD"; ctx.fillRect(w - 72, y - 36, 28, 28);
    leader(ctx, 58, y - 36, 58, y - 52, d.load || "Load", "left");
    leader(ctx, w - 58, y - 36, w - 58, y - 52, d.effort || "Effort", "right");
    leader(ctx, fx, y + 40, fx, y + 56, "fulcrum", "left");
    ctx.font = "bold 12px sans-serif";
    ctxt(ctx, "Lever", w / 2, 16, "#334155");
  } else if (kind === "states_of_matter" || kind === "water_cycle" || kind === "food_chain" || kind === "simple_circuit") {
    // Delegate legacy science kinds already implemented below
    drawScienceDiagram(canvas, kind, w, h);
    return;
  }

}

// ================= CHARTS (Data Lab / Probability Lab) =================
export function drawChart(canvas, values, labels, mode = "bar", w = 320, h = 260) {
  const ctx = setupCanvas(canvas, w, h);
  if (!values || !values.length) { txt(ctx, "No data yet", w / 2 - 30, h / 2, "#888"); return; }
  labels = labels || values.map((_, i) => String(i + 1));
  if (mode === "bar") drawBar(ctx, values, labels, w, h);
  else if (mode === "pie") drawPie(ctx, values, labels, w, h);
  else if (mode === "line") drawLine(ctx, values, labels, w, h);
  else if (mode === "box") drawBox(ctx, values, w, h);
  else if (mode === "histogram") drawHistogram(ctx, values, w, h);
}

function drawBar(ctx, values, labels, w, h) {
  const margin = 36, top = 20, chartH = h - margin - top;
  const vmax = Math.max(...values) || 1, n = values.length, bw = (w - 2 * margin) / n;
  ctx.font = "10px sans-serif";
  values.forEach((v, i) => {
    const barH = (v / vmax) * chartH, x = margin + i * bw + bw * 0.15, y = h - margin - barH;
    ctx.fillStyle = PALETTE[i % PALETTE.length];
    ctx.fillRect(x, y, bw * 0.7, barH);
    txt(ctx, String(labels[i]), x + bw * 0.35, h - margin + 16, "#333", "center");
    txt(ctx, String(v), x + bw * 0.35, y - 6, "#333", "center");
  });
  ctx.strokeStyle = "#333"; ctx.lineWidth = 2;
  ln(ctx, margin, h - margin, w - margin, h - margin);
}

function drawPie(ctx, values, labels, w, h) {
  const size = Math.min(w, h) - 70, cx = w / 2, cy = h / 2 - 5, r = size / 2;
  const total = values.reduce((a, b) => a + b, 0) || 1;
  ctx.font = "bold 11px sans-serif";
  let start = -Math.PI / 2;
  values.forEach((v, i) => {
    const span = (2 * Math.PI * v) / total;
    ctx.fillStyle = PALETTE[i % PALETTE.length];
    ctx.beginPath(); ctx.moveTo(cx, cy); ctx.arc(cx, cy, r, start, start + span); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = "#fff"; ctx.lineWidth = 2; ctx.stroke();
    const mid = start + span / 2;
    const lx = cx + (r + 20) * Math.cos(mid), ly = cy + (r + 20) * Math.sin(mid);
    const pct = Math.round((100 * v) / total);
    ctxt(ctx, `${labels[i]} (${pct}%)`, lx, ly, "#333");
    start += span;
  });
}

function drawLine(ctx, values, labels, w, h) {
  const margin = 36, top = 20, chartH = h - margin - top;
  const vmax = Math.max(...values) || 1, vmin = Math.min(...values), n = values.length;
  const stepX = (w - 2 * margin) / Math.max(1, n - 1);
  const pts = values.map((v, i) => ({ x: margin + i * stepX, y: h - margin - ((v - vmin) / (vmax - vmin + 1e-9)) * chartH }));
  ctx.strokeStyle = "#333"; ctx.lineWidth = 2;
  ln(ctx, margin, h - margin, w - margin, h - margin);
  ctx.strokeStyle = PALETTE[0]; ctx.lineWidth = 3;
  ctx.beginPath(); pts.forEach((p, i) => (i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y))); ctx.stroke();
  ctx.font = "9px sans-serif";
  pts.forEach((p, i) => {
    dot(ctx, p.x, p.y, 4, PALETTE[0]);
    txt(ctx, String(values[i]), p.x - 8, p.y - 10, "#333");
    txt(ctx, String(labels[i]), p.x - 8, h - margin + 14, "#333");
  });
}

function drawBox(ctx, values, w, h) {
  const sv = [...values].sort((a, b) => a - b), n = sv.length;
  const lo = sv[0], hi = sv[n - 1];
  const q1 = sv[Math.floor(n / 4)];
  const med = n % 2 ? sv[(n - 1) / 2] : (sv[n / 2 - 1] + sv[n / 2]) / 2;
  const q3 = sv[Math.floor((3 * n) / 4)];
  const margin = 40, span = (hi - lo) || 1;
  const X = (val) => margin + ((val - lo) / span) * (w - 2 * margin);
  const midY = h / 2;
  ctx.strokeStyle = "#333"; ctx.lineWidth = 2;
  ln(ctx, X(lo), midY, X(q1), midY);
  ln(ctx, X(q3), midY, X(hi), midY);
  ctx.fillStyle = "#a9bdf3"; ctx.fillRect(X(q1), midY - 30, X(q3) - X(q1), 60);
  ctx.strokeRect(X(q1), midY - 30, X(q3) - X(q1), 60);
  ctx.strokeStyle = PALETTE[2]; ctx.lineWidth = 3;
  ln(ctx, X(med), midY - 30, X(med), midY + 30);
  ctx.strokeStyle = "#333"; ctx.lineWidth = 2; ctx.font = "10px sans-serif";
  [[lo, "min"], [q1, "Q1"], [med, "median"], [q3, "Q3"], [hi, "max"]].forEach(([val, label]) => {
    ln(ctx, X(val), midY - 36, X(val), midY + 36);
    txt(ctx, `${label} ${Math.round(val * 100) / 100}`, X(val) - 16, midY + 52, "#333");
  });
}

function drawHistogram(ctx, values, w, h) {
  const lo = Math.min(...values), hi = Math.max(...values), span = (hi - lo) || 1;
  const nBins = Math.min(8, Math.max(4, Math.floor(values.length / 2)));
  const binW = span / nBins;
  const bins = new Array(nBins).fill(0);
  values.forEach((v) => { const idx = binW ? Math.min(nBins - 1, Math.floor((v - lo) / binW)) : 0; bins[idx]++; });
  const labels = Array.from({ length: nBins }, (_, i) => `${Math.round(lo + i * binW)}-${Math.round(lo + (i + 1) * binW)}`);
  drawBar(ctx, bins, labels, w, h);
}

// ================= NATURAL SCIENCES DIAGRAMS =================
export function drawScienceDiagram(canvas, kind, w = 320, h = 240) {
  const ctx = setupCanvas(canvas, w, h);
  ctx.font = "bold 12px sans-serif";

  if (kind === "states_of_matter") {
    const labels = ["Solid", "Liquid", "Gas"];
    labels.forEach((label, i) => {
      const cx = w / 6 + (i * w) / 3;
      const box = { left: cx - w / 8, top: 20, w: w / 4, h: h - 60 };
      ctx.strokeStyle = "#333"; ctx.lineWidth = 1; ctx.strokeRect(box.left, box.top, box.w, box.h);
      ctx.fillStyle = "#3157D5";
      if (label === "Solid") {
        for (let row = 0; row < 4; row++) for (let col = 0; col < 3; col++) {
          const px = box.left + 10 + (col * (box.w - 20)) / 2, py = box.top + 15 + (row * (box.h - 30)) / 3;
          dot(ctx, px, py, 5, "#3157D5");
        }
      } else if (label === "Liquid") {
        for (let i2 = 0; i2 < 12; i2++) {
          const px = box.left + 8 + Math.random() * (box.w - 16), py = box.top + box.h * 0.4 + Math.random() * (box.h * 0.55);
          dot(ctx, px, py, 5, "#3157D5");
        }
      } else {
        for (let i2 = 0; i2 < 10; i2++) {
          const px = box.left + 8 + Math.random() * (box.w - 16), py = box.top + 8 + Math.random() * (box.h - 16);
          dot(ctx, px, py, 4, "#3157D5");
        }
      }
      txt(ctx, label, box.left + box.w / 2, box.top + box.h + 20, "#333", "center");
    });
  } else if (kind === "water_cycle") {
    dot(ctx, w * 0.8, h * 0.18, 20, "#F5A623");
    ctx.fillStyle = "#89CFF0"; ctx.fillRect(0, h * 0.75, w, h * 0.25);
    ctx.fillStyle = "#e0e0e0";
    ctx.beginPath(); ctx.ellipse(w * 0.35, h * 0.22, 30, 18, 0, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(w * 0.48, h * 0.2, 24, 16, 0, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = "#333"; ctx.lineWidth = 2;
    ln(ctx, w * 0.25, h * 0.75, w * 0.32, h * 0.3);
    ln(ctx, w * 0.45, h * 0.32, w * 0.4, h * 0.7);
    ctx.font = "9px sans-serif";
    txt(ctx, "Evaporation", w * 0.05, h * 0.55, "#333");
    txt(ctx, "Precipitation", w * 0.5, h * 0.55, "#333");
    txt(ctx, "Condensation", w * 0.25, h * 0.12, "#333");
  } else if (kind === "food_chain") {
    const items = ["Sun", "Grass", "Grasshopper", "Frog", "Snake"];
    const seg = w / items.length;
    ctx.font = "bold 9px sans-serif";
    items.forEach((item, i) => {
      const cx = seg * i + seg / 2, cy = h / 2;
      dot(ctx, cx, cy, 28, PALETTE[i % PALETTE.length]);
      ctxt(ctx, item, cx, cy, "#fff");
      if (i < items.length - 1) { ctx.strokeStyle = "#333"; ctx.lineWidth = 2; ln(ctx, cx + 28, cy, cx + seg - 28, cy); }
    });
  } else if (kind === "simple_circuit") {
    ctx.strokeStyle = "#333"; ctx.lineWidth = 3;
    const rect = { left: 40, top: 40, w: w - 80, h: h - 100 };
    ctx.strokeRect(rect.left, rect.top, rect.w, rect.h);
    ln(ctx, rect.left, rect.top + rect.h / 2 - 10, rect.left, rect.top + rect.h / 2 + 10);
    ctx.font = "10px sans-serif";
    txt(ctx, "Battery", rect.left - 30, rect.top + rect.h / 2 + 30, "#333");
    ctx.fillStyle = "#F5A623";
    dot(ctx, rect.left + rect.w, rect.top + rect.h / 2, 14, "#F5A623");
    txt(ctx, "Bulb", rect.left + rect.w - 15, rect.top + rect.h / 2 + 32, "#333");
  }
}

// ================= PAPER -> PNG EXPORT (in place of ui/pillow_paper.py) =================
function wrapText(ctx, text, maxWidth) {
  const words = String(text).split(/\s+/);
  const lines = [];
  let line = "";
  words.forEach((word) => {
    const test = line ? line + " " + word : word;
    if (ctx.measureText(test).width > maxWidth && line) { lines.push(line); line = word; }
    else line = test;
  });
  if (line) lines.push(line);
  return lines;
}

export function exportPaperImage(paper, showMemo = true) {
  const W = 800, PAD = 36, LINE = 22, DIAG_W = 260, DIAG_H = 170;
  const measure = document.createElement("canvas").getContext("2d");
  measure.font = "15px sans-serif";

  let estHeight = 210;
  const layout = paper.questions.map((q) => {
    measure.font = "15px sans-serif";
    const qLines = wrapText(measure, q.question, W - 2 * PAD);
    let h = 34 + qLines.length * LINE + 14;
    if (q.diagram) h += DIAG_H + 12;
    let memoLines = [];
    if (showMemo) {
      measure.font = "13px sans-serif";
      memoLines = [
        ...wrapText(measure, `Answer: ${q.answer}`, W - 2 * PAD),
        ...wrapText(measure, `Working: ${q.explanation}`, W - 2 * PAD),
        ...wrapText(measure, `Technique: ${q.hint}`, W - 2 * PAD)
      ];
      h += memoLines.length * 18 + 10;
    }
    estHeight += h + 18;
    return { q, qLines, memoLines, h };
  });

  const canvas = document.createElement("canvas");
  const ctx = setupCanvas(canvas, W, estHeight, "#ffffff");
  let y = PAD;

  ctx.fillStyle = "#111"; ctx.textAlign = "left";
  ctx.font = "bold 22px sans-serif";
  ctx.fillText(`${paper.grade_label || "Grade 8"} Mathematics — ${paper.type}`, PAD, y + 22); y += 34;
  ctx.font = "13px sans-serif"; ctx.fillStyle = "#555";
  ctx.fillText(`Term ${paper.term} • ${paper.difficulty} • ${paper.marks} marks • ${paper.time_minutes || 45} min`, PAD, y + 16); y += 18;
  ctx.fillText(`Student: ${paper.student_code || ""} • Created: ${(paper.created_at || "").slice(0, 16).replace("T", " ")}`, PAD, y + 16); y += 30;
  ctx.strokeStyle = "#ccc"; ctx.beginPath(); ctx.moveTo(PAD, y); ctx.lineTo(W - PAD, y); ctx.stroke(); y += 22;

  layout.forEach(({ q, qLines, memoLines }) => {
    ctx.font = "bold 15px sans-serif"; ctx.fillStyle = "#111";
    ctx.fillText(`Q${q.number}. (${q.marks} marks) — ${q.topic_name}`, PAD, y + 15); y += 26;
    ctx.font = "15px sans-serif";
    qLines.forEach((l) => { ctx.fillText(l, PAD, y + 15); y += LINE; });
    y += 6;
    if (q.diagram) {
      const dc = document.createElement("canvas");
      drawDiagram(dc, q.diagram, DIAG_W, DIAG_H);
      ctx.drawImage(dc, PAD, y, DIAG_W, DIAG_H);
      y += DIAG_H + 12;
    }
    if (showMemo) {
      ctx.font = "13px sans-serif"; ctx.fillStyle = "#1a6b3c";
      memoLines.forEach((l) => { ctx.fillText(l, PAD, y + 13); y += 18; });
      ctx.fillStyle = "#111";
      y += 8;
    }
    ctx.strokeStyle = "#eee"; ctx.beginPath(); ctx.moveTo(PAD, y); ctx.lineTo(W - PAD, y); ctx.stroke();
    y += 18;
  });

  canvas.toBlob(async (blob) => {
    if (!blob) return;
    const filename = `${paper.paper_id || "learnly_paper"}.png`;
    // Prefer Web Share API (saves to Photos / Files on mobile) when available.
    try {
      if (navigator.canShare && navigator.canShare({ files: [new File([blob], filename, { type: "image/png" })] })) {
        const file = new File([blob], filename, { type: "image/png" });
        await navigator.share({
          files: [file],
          title: `${paper.grade_label || "Grade"} Mathematics Paper`,
          text: `${paper.type || "Question paper"} — ${paper.marks || ""} marks`
        });
        return;
      }
    } catch (err) {
      // User cancelled share or share failed — fall through to download.
      if (err && err.name === "AbortError") return;
    }
    // Fallback: download link (works on desktop and many mobile browsers).
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.setAttribute("target", "_blank");
    a.rel = "noopener";
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 6000);
  }, "image/png");
}
