/* OPERATION: DISCIPLINE — telas Estatísticas e Histórico. */
(function(){'use strict';
var OD=globalThis.OD,UI=OD.UI,U=OD.U,G=OD.G,St=OD.Stats,App=UI.App,esc=UI.esc,L=UI.L,A=UI.A,CH=UI.CH,td=UI.td,fd=UI.fd,ft=UI.ft;
var pc=function(r){return r[1]?Math.round(r[0]/r[1]*100):0};
var rowsOf=function(o,lab,last){var k=Object.keys(o).sort();if(last)k=k.slice(-last);return k.map(function(x){var r=o[x];return'<div class="rw"><span>'+esc(lab(x))+'</span><span class="mu">'+r[0]+'/'+r[1]+' · '+pc(r)+'%</span></div>'+UI.pg(r[0],r[1])}).join('')};

/* ---------- Estatísticas ---------- */
UI.views.stats=function(){var S=App.S,C=App.C,t=td(),fl=App.fl,from=fl===-1?App.cf:fl?U.add(t,1-fl):'2000-01-01',to=fl===-1?App.ct:t,lo=from<to?from:to,hi=from<to?to:from,s=St.stats(S,lo,hi),sk=C.streak(t),
 cn=function(k){return+k===0?'Sem categoria':(S.c.find(function(c){return c.id===+k})||{name:'(removida)'}).name},prog=G.progression(S).slice(-8).reverse();
 return'<h1>Estatísticas</h1>'+UI.sel('sper','Período',[[1,'Hoje'],[7,'7 dias'],[30,'30 dias'],[90,'90 dias'],[180,'180 dias'],[365,'365 dias'],[0,'Todo o período'],[-1,'Intervalo personalizado']],fl,'data-c="sper"')
 +(fl===-1?'<div class="grid2">'+UI.inp('cf','De','date',App.cf,'data-c="sfrom"')+UI.inp('ct','Até','date',App.ct,'data-c="sto"')+'</div>':'')
 +'<div class="tiles" style="margin-top:12px"><div class="t"><b>'+s.xp.toLocaleString('pt-BR')+'</b>XP no período</div><div class="t"><b>'+C.total().toLocaleString('pt-BR')+'</b>XP total</div><div class="t"><b>'+s.perfect+'</b>Dias perfeitos</div></div>'
 +(s.total?'<div class="c"><div class="h">TAXA DE CONCLUSÃO</div><div class="big">'+Math.round(s.rate*100)+'%</div>'+UI.pg(s.done,s.total)+'<div class="tiles"><div class="t"><b>'+s.done+'</b>Concluídas</div><div class="t"><b>'+s.failed+'</b>Falhas</div><div class="t"><b>'+s.pending+'</b>Abertas</div></div><div class="mu">'+s.days+' dia(s) com missões · média '+s.avg.toFixed(1)+' concluídas/dia · '+s.rest+' dia(s) de descanso (não contam). Falhas = “Falhou” + canceladas sem justificativa.</div></div>'
  +'<div class="c"><div class="h">MELHOR E PIOR DIA</div>Melhor: '+fd(s.best[0])+' ('+pc(s.best[1])+'%)<br>Pior: '+fd(s.worst[0])+' ('+pc(s.worst[1])+'%)</div>'
  +'<div class="c"><div class="h">POR DIFICULDADE</div>'+rowsOf(s.byDf,function(k){return L.DL[k]})+'</div><div class="c"><div class="h">POR CATEGORIA</div>'+rowsOf(s.byCat,cn)+'</div>'
  +'<div class="c"><div class="h">DESEMPENHO SEMANAL (semana iniciada em…)</div>'+rowsOf(s.weekly,fd,12)+'</div><div class="c"><div class="h">DESEMPENHO MENSAL</div>'+rowsOf(s.monthly,function(k){return k.slice(5)+'/'+k.slice(0,4)},12)+'</div>'
  :'<div class="empty"><b>Sem missões no período</b><span class="mu">Dias sem planejamento e dias de descanso não contam como zero.</span></div>')
 +'<div class="tiles"><div class="t"><b>'+sk[0]+' d</b>Sequência atual</div><div class="t"><b>'+sk[1]+' d</b>Melhor sequência</div><div class="t"><b>'+G.lvl(C.total())+'</b>Nível</div></div>'
 +'<div class="c"><div class="h">EVOLUÇÃO DE NÍVEL (mais recentes)</div>'+(prog.length?prog.map(function(p){return'<div class="rw"><span>Nível '+p.level+' · '+esc(p.rank)+'</span><span class="mu">'+ft(p.t)+'</span></div>'}).join(''):'<span class="mu">Nenhuma evolução ainda.</span>')+'</div>'};
CH.sper={fn:function(el){App.fl=+el.value;UI.draw()}};CH.sfrom={fn:function(el){App.cf=UI.sd(el.value,App.cf);UI.draw()}};CH.sto={fn:function(el){App.ct=UI.sd(el.value,App.ct);UI.draw()}};

/* ---------- Histórico ---------- */
UI.views.hist=function(){var S=App.S,C=App.C,hm=App.hm,y=+hm.slice(0,4),mo=+hm.slice(5),n=new Date(y,mo,0).getDate(),lead=(new Date(y,mo-1,1).getDay()+6)%7,pd={},g='';C.pendingDays(td()).forEach(function(x){pd[x.d]=1});
 ['Seg','Ter','Qua','Qui','Sex','Sáb','Dom'].forEach(function(w){g+='<span class="wd">'+w+'</span>'});for(var i=0;i<lead;i++)g+='<span></span>';
 for(i=1;i<=n;i++){var d=hm+'-'+String(i).padStart(2,'0'),ds=C.dayState(d);g+='<button type="button" class="cd d'+ds+(pd[d]?' pend':'')+(d===App.hs?' sel':'')+(d===td()?' today':'')+'" data-a="hday" data-d="'+d+'" aria-label="'+fd(d)+': '+esc(L.RL[ds])+(pd[d]?', aguardando revisão':'')+'">'+i+'</button>'}
 var hs=App.hs,det='';
 if(hs){var dt=C.on(hs),xs=St.xpOnDay(S,hs),ac=G.ACH.filter(function(a){return S.ua[a[0]]&&U.iso(new Date(S.ua[a[0]]))===hs}),ds2=C.dayState(hs),sum=St.stats(S,hs,hs);
  det='<div class="c"><div class="row"><b class="grow">'+fd(hs)+'</b><span class="pill d'+ds2+'">'+esc(L.RL[ds2])+'</span></div>'+(pd[hs]?'<div class="mu">Aguardando revisão (não encerrado).</div>':'')
  +(sum.total?'<div class="mu">'+sum.done+'/'+sum.total+' concluídas · '+sum.failed+' falha(s) · XP do dia: '+sum.xp+'</div>':'')+'<div class="h sec">MISSÕES</div>'
  +(dt.map(function(m){return'<div class="rw"><button type="button" class="lnk" data-a="detail" data-id="'+m.id+'">'+(m.main?'★ ':'')+(m.time?esc(m.time)+' ':'')+esc(m.title)+'</button><span class="pill st'+m.s+'">'+L.ST[m.s]+'</span></div>'+(m.reason?'<div class="mu">'+esc(m.reason)+'</div>':'')}).join('')||'<span class="mu">Nenhuma missão neste dia.</span>')
  +'<div class="h sec">XP DESTE DIA</div>'+(xs.map(function(x){return'<div class="rw"><span>'+esc(x.d)+'</span><span class="'+(x.a<0?'neg':'lm')+'">'+(x.a>0?'+':'')+x.a+'</span></div>'}).join('')||'<span class="mu">—</span>')
  +(ac.length?'<div class="h sec">CONQUISTAS</div>'+ac.map(function(a){return esc(a[1])}).join(', '):'')
  +'<div class="row" style="margin-top:10px"><button type="button" class="sm" data-a="goto" data-d="'+hs+'">Abrir em Missões</button></div></div>'}
 else det='<div class="empty"><b>Selecione um dia</b><span class="mu">Toque em um dia do calendário para ver missões, XP e resultado.</span></div>';
 return'<h1>Histórico</h1><div class="row dn"><button type="button" aria-label="Mês anterior" data-a="hmprev">‹</button><b class="grow center">'+String(mo).padStart(2,'0')+'/'+y+'</b><button type="button" aria-label="Próximo mês" data-a="hmnext">›</button><button type="button" class="sm" data-a="hmtoday">Hoje</button></div>'
 +'<div class="cal">'+g+'</div><div class="legend"><i class="dPERFECT"></i>Perfeito <i class="dPARTIAL"></i>Parcial <i class="dREST"></i>Descanso <i class="dEXCUSED"></i>Exceção <i class="dPLANNED"></i>Planejado <i class="pend"></i>Revisar</div>'+det};
A.hday=function(el){App.hs=el.dataset.d;UI.draw()};
A.hmprev=function(){App.hm=U.iso(new Date(+App.hm.slice(0,4),+App.hm.slice(5)-2,1)).slice(0,7);UI.draw()};
A.hmnext=function(){App.hm=U.iso(new Date(+App.hm.slice(0,4),+App.hm.slice(5),1)).slice(0,7);UI.draw()};
A.hmtoday=function(){App.hm=td().slice(0,7);App.hs=td();UI.draw()};
})();
