/* EditorView – editor levelů.
   Nástroje (zkratky): Skála S, Zeď Z, Guma G, Vstup V, Cíl C, Věž T. Pravé tlačítko myši maže. Štětec 1/2/3 = 1×1, 2×2, 4×4. Ctrl+Z = zpět.
   Mapa má 4–32 věží na šířku i výšku; kreslí se po buňkách (1 věž = 2×2 buňky).
   Skála: jedním tahem vznikne jeden souvislý kámen, jednotlivá klepnutí dělají samostatné kamínky.
   Zeď: přesné čtverce se společnou hranicí. Vstup/Cíl na okraji: jedním tahem se nakreslí brána o libovolné délce;
   brány se nesmí dotýkat (mezi nimi aspoň 1 buňka). Cíl nakreslený do pole je pulzující perlová koule.
   Pravidla levelu: životy, zlato, počet vln (10–999 nebo nekonečno), síla bublin, povolené věže, předpostavené věže.
   Události: back, play (level)
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  var Lv = BD.systems.levels, G = BD.systems.grid, F = BD.render.field, D = BD.render.draw, TW = BD.systems.towers;
  var SIDE_NAME = { L: 'vlevo', R: 'vpravo', T: 'nahoře', B: 'dole' };
  var UNDO_FIELDS = ['w', 'h', 'spawns', 'exit', 'rocks', 'walls', 'towers', 'lives', 'gold', 'waves', 'gap', 'hp', 'allowed'];

  BD.ui.components.EditorView = {
    props: { levelId: String },
    emits: ['back', 'play'],
    template: `
<div class="edv">
  <div class="smap-head">
    <button class="btn" @click="$emit('back')"><ic n="back"></ic> Menu</button>
    <input class="in ed-name" v-if="level" v-model="level.name" maxlength="40" @input="touch" aria-label="Název levelu">
    <div class="sp"></div>
    <button class="btn" :disabled="!undo.length" @click="doUndo" title="Zpět (Ctrl+Z)"><ic n="refresh"></ic><span class="lbl"> Zpět</span></button>
    <button class="btn" @click="doCopy" title="Zkopírovat level jako text (pošli mi ho)" data-act="ed-copy"><ic n="copy"></ic><span class="lbl"> Kopírovat</span></button>
    <button class="btn" @click="doDownload" title="Stáhnout level jako soubor" data-act="ed-download"><ic n="download"></ic><span class="lbl"> Export</span></button>
    <button class="btn" @click="clearAll"><ic n="trash"></ic><span class="lbl"> Vyčistit</span></button>
    <button class="btn primary" :disabled="!check.ok" @click="$emit('play', level)"><ic n="play"></ic><span class="lbl"> Vyzkoušet</span></button>
  </div>
  <div class="ed-main" v-if="level">
    <div class="ed-tools">
      <div class="ed-tabs">
        <button :class="{on: panel === 'draw'}" @click="panel = 'draw'">Kreslení</button>
        <button :class="{on: panel === 'rules'}" @click="panel = 'rules'">Pravidla</button>
      </div>

      <template v-if="panel === 'draw'">
        <div class="ed-toollist">
          <button class="trow" v-for="t in tools" :key="t.id" :class="{on: tool === t.id}" @click="tool = t.id" :title="t.hint" :data-tool="t.id">
            <i class="sw" :class="'sw-' + t.id"></i><span class="nm">{{ t.name }}</span><kbd>{{ t.key.toUpperCase() }}</kbd>
          </button>
        </div>
        <div class="hint keys"><kbd>pravé tlačítko</kbd> maže · <kbd>1</kbd> <kbd>2</kbd> <kbd>3</kbd> velikost štětce · <kbd>Ctrl</kbd>+<kbd>Z</kbd> zpět</div>

        <div class="ed-grp" v-if="isPaint || tool === 'erase'">
          <div class="h">Štětec</div>
          <div class="seg"><button v-for="(n, i) in [1, 2, 4]" :key="n" :class="{on: brush === n}" @click="brush = n">{{ n }}×{{ n }}<kbd>{{ i + 1 }}</kbd></button></div>
          <div class="hint" v-if="tool === 'rock'">Tah = jedna souvislá skála, klepnutí = samostatný kamínek.</div>
          <div class="hint" v-else-if="tool === 'wall'">Zdi se spojují do jednoho tvaru s ohraničením.</div>
          <div class="hint" v-else>Gumou smažeš skály, zdi, předpostavené věže i celou bránu vstupu.</div>
        </div>
        <div class="ed-grp" v-else-if="tool === 'spawn'">
          <div class="h">Vstup</div>
          <div class="hint">Táhni po okraji mapy: jedním tahem nakreslíš bránu libovolné délky. Další vstup musí být o aspoň jednu buňku dál. Max {{ max }} vstupů.</div>
        </div>
        <div class="ed-grp" v-else-if="tool === 'exit'">
          <div class="h">Cíl</div>
          <div class="hint"><b>Na okraji</b> vznikne brána, <b>uvnitř pole</b> pulzující perlová koule (velikost podle štětce). Cíl je jen jeden – nové kreslení ho přesune. Od vstupu musí být aspoň jednu buňku stranou.</div>
          <div class="seg" v-if="exitInside"><button v-for="(n, i) in [1, 2, 4]" :key="n" :class="{on: brush === n}" @click="brush = n">{{ n }}×{{ n }}<kbd>{{ i + 1 }}</kbd></button></div>
        </div>
        <div class="ed-grp" v-else-if="tool === 'tower'">
          <div class="h">Předpostavená věž</div>
          <div class="chips"><button v-for="t in towerTypes" :key="t.key" :class="{on: towerType === t.key}" @click="towerType = t.key"><i :style="{background: t.color}"></i>{{ t.name }}</button></div>
          <div class="hint">Klepnutím postavíš věž, která bude ve hře od začátku. Nesmí zavřít cestu.</div>
        </div>

        <div class="ed-grp">
          <div class="h">Rozměr mapy (věží)</div>
          <div class="ed-size"><span>Šířka</span><button class="btn sm" @click="resize(level.w - 1, level.h)">−</button><b>{{ level.w }}</b><button class="btn sm" @click="resize(level.w + 1, level.h)">+</button></div>
          <div class="ed-size"><span>Výška</span><button class="btn sm" @click="resize(level.w, level.h - 1)">−</button><b>{{ level.h }}</b><button class="btn sm" @click="resize(level.w, level.h + 1)">+</button></div>
        </div>

        <div class="ed-grp">
          <div class="h">Brány</div>
          <div class="kv" v-for="(g, i) in level.spawns" :key="i"><span>Vstup {{ i + 1 }} · {{ side(g) }}</span>
            <b><button class="btn sm danger" @click="removeSpawn(i)" :disabled="level.spawns.length < 2" aria-label="Smazat vstup">✕</button></b></div>
          <div class="kv"><span>Cíl · {{ side(level.exit) }}</span><b></b></div>
        </div>
      </template>

      <template v-else>
        <div class="ed-grp">
          <div class="h">Životy</div>
          <input class="in num" type="number" min="1" max="999" :value="rules.lives" @change="setRule('lives', $event)" data-rule="lives">
          <div class="h">Zlato na začátku</div>
          <input class="in num" type="number" min="0" max="99999" step="10" :value="rules.gold" @change="setRule('gold', $event)" data-rule="gold">
        </div>
        <div class="ed-grp">
          <div class="h">Počet vln</div>
          <label class="tog"><span>Nekonečno ∞</span><input type="checkbox" :checked="rules.endless" @change="setEndless($event.target.checked)" data-rule="endless"><i></i></label>
          <input class="in num" type="number" :min="minWaves" :max="maxWaves" :value="rules.waves" @change="setRule('waves', $event)" data-rule="waves" v-if="!rules.endless">
          <div class="hint" v-if="!rules.endless">Minimum {{ minWaves }} vln. Po poslední vlně je level splněn.</div>
          <div class="hint" v-else>Vlny jedou bez konce, dokud hráč neprohraje.</div>
        </div>
        <div class="ed-grp">
          <div class="h">Odstup vln · {{ rules.gap }} s</div>
          <input class="in num" type="number" :min="gapMin" :max="gapMax" :value="rules.gap" @change="setRule('gap', $event)" data-rule="gap">
          <div class="hint">Za jak dlouho po sobě vyrazí další vlna z pásu.</div>
        </div>
        <div class="ed-grp">
          <div class="h">Síla bublin · {{ Math.round(rules.hp * 100) }} %</div>
          <input type="range" min="25" max="400" step="5" :value="Math.round(rules.hp * 100)" @input="setHp($event.target.value)" data-rule="hp">
          <div class="hint">Násobek zdraví všech bublin.</div>
        </div>
        <div class="ed-grp">
          <div class="h">Povolené věže</div>
          <label class="chk" v-for="c in categories" :key="c.id"><input type="checkbox" :checked="rules.allowed.indexOf(c.id) >= 0" @change="toggleAllowed(c.id, $event)" :data-allow="c.id"><i :style="{background: c.color}"></i>{{ c.name }}</label>
          <div class="hint">Základna je vždy k dispozici. Aspoň jedna kategorie musí zůstat.</div>
        </div>
        <div class="ed-grp">
          <div class="h">Předpostavené věže: {{ (level.towers || []).length }}</div>
          <div class="hint">Nástroj <b>Věž</b> (T) je postaví na mapu. Ve hře se dají vylepšit i prodat.</div>
          <button class="btn sm" :disabled="!(level.towers || []).length" @click="clearTowers">Odstranit všechny</button>
        </div>
      </template>

      <div class="ed-grp">
        <div class="msg err" v-if="!check.ok">{{ check.error }}</div>
        <div class="msg okk" v-else>Level je v pořádku. Nejkratší cesta: {{ shortest }} polí.</div>
        <div class="hint">Uloženo: {{ when }} · skály {{ level.rocks.length }} · zdi {{ level.walls.length }}</div>
      </div>
      <div class="msg err" v-if="msg">{{ msg }}</div>
      <div class="msg okk" v-else-if="note" data-role="ed-note">{{ note }}</div>
    </div>
    <div class="ed-stage" ref="stage"><canvas ref="cv" class="ed-cv" @contextmenu.prevent></canvas></div>
  </div>
  <div class="empty" v-else>Level nebyl nalezen.</div>
</div>`,
    data: function () {
      var L = BD.store.profile.editor.levels.filter(function (l) { return l.id === this.levelId; }, this)[0] || null;
      var cats = TW.categories().map(function (d) { return { id: d.id, name: d.name, color: d.color }; });
      var types = ['base'].concat(cats.map(function (c) { return c.id; })).map(function (k) { return { key: k, name: BD.data.towers[k].name, color: BD.data.towers[k].color }; });
      return {
        level: L, tool: 'wall', brush: 1, undo: [], msg: '', note: '', max: Lv.MAX_SPAWNS, rev: 0, panel: 'draw', hoverInside: false,
        minWaves: Lv.MIN_WAVES, maxWaves: Lv.MAX_WAVES, categories: cats, towerTypes: types, towerType: 'base',
        tools: [
          { id: 'rock', key: 's', name: 'Skála', hint: 'Kulatý kámen; tah = jedna souvislá skála' },
          { id: 'wall', key: 'z', name: 'Zeď', hint: 'Přesný čtverec bez tvaru, jako okraj mapy' },
          { id: 'erase', key: 'g', name: 'Guma', hint: 'Smaže skály, zdi, věže a brány vstupu' },
          { id: 'spawn', key: 'v', name: 'Vstup', hint: 'Brána, kudy přicházejí bubliny (až 8)' },
          { id: 'exit', key: 'c', name: 'Cíl', hint: 'Brána na okraji, nebo koule uvnitř pole' },
          { id: 'tower', key: 't', name: 'Věž', hint: 'Předpostavená věž' },
        ],
      };
    },
    computed: {
      isPaint: function () { return this.tool === 'rock' || this.tool === 'wall'; },
      exitInside: function () { return this.tool === 'exit' && this.hoverInside; },
      check: function () { this.rev; return this.level ? Lv.validate(Vue.toRaw(this.level)) : { ok: false, error: '' }; },
      shortest: function () { return this.check.ok ? Math.round(Math.min.apply(null, this.check.lens) / BD.SUB * 10) / 10 : 0; },
      when: function () { return this.level ? BD.util.date(this.level.updated) : ''; },
      gapMin: function () { return Lv.LIMITS.gap[0]; },
      gapMax: function () { return Lv.LIMITS.gap[1]; },
      rules: function () {
        var L = this.level, all = this.categories.map(function (c) { return c.id; });
        return { lives: L.lives !== undefined ? L.lives : BD.systems.GAME.LIVES_START, gold: L.gold !== undefined ? L.gold : BD.systems.GAME.GOLD_START,
          waves: L.waves > 0 ? L.waves : (this.lastWaves || 20), endless: !(L.waves > 0), gap: L.gap || BD.systems.GAME.WAVE_GAP, hp: L.hp || 1, allowed: L.allowed || all };
      },
    },
    methods: {
      side: function (g) {
        if (G.isOrb(g)) return 'koule uvnitř · ' + this.cells(g.orb.length);
        return SIDE_NAME[g.side] + ' · ' + this.cells(g.len);
      },
      cells: function (n) { return n + (n === 1 ? ' buňka' : n < 5 ? ' buňky' : ' buněk'); },
      touch: function () { if (this.level) this.level.updated = Date.now(); },
      raw: function () { return Vue.toRaw(this.level); },
      dims: function () { return { W: this.level.w * BD.SUB, H: this.level.h * BD.SUB }; },
      bump: function () { this.ver = (this.ver || 0) + 1; },

      /* ---- historie (zpět) ---- */
      doCopy: async function () {
        var ok = await BD.ui.levelIO.copy(BD.store.exportLevels([this.raw()]));
        this.note = ok ? 'Level je zkopírovaný do schránky.' : 'Kopírování se nepovedlo, zkus Export.';
      },
      doDownload: function () {
        try { BD.ui.levelIO.download(BD.store.exportLevels([this.raw()]), BD.ui.levelIO.fileName(this.level.name)); this.note = 'Soubor ' + BD.ui.levelIO.fileName(this.level.name) + ' je stažený.'; }
        catch (e) { this.note = 'Export se nepovedl, zkus Kopírovat.'; }
      },
      snap: function () {
        var r = this.raw(), o = {};
        UNDO_FIELDS.forEach(function (f) { if (r[f] !== undefined) o[f] = r[f]; });
        this.undo.push(JSON.stringify(o));
        if (this.undo.length > 60) this.undo.shift();
      },
      doUndo: function () {
        if (!this.undo.length) return;
        var o = JSON.parse(this.undo.pop()), L = this.level;
        UNDO_FIELDS.forEach(function (f) { if (o[f] === undefined) delete L[f]; else L[f] = o[f]; });
        this.changed(true);
      },
      changed: function (refit) { this.msg = ''; this.note = ''; this.touch(); this.rev++; this.buildMasks(); this.bump(); if (refit) this.$nextTick(this.fit); else this.draw(); },

      /* ---- masky buněk (rychlé kreslení štětcem) ---- */
      buildMasks: function () {
        var d = this.dims(), r = this.raw(), i, n = d.W * d.H, maxg = 0;
        this.rm = new Uint8Array(n); this.wm = new Uint8Array(n); this.gm = new Int32Array(n); this.om = new Uint8Array(n);
        for (i = 0; i < r.rocks.length; i++) { var k = r.rocks[i][1] * d.W + r.rocks[i][0], g = r.rocks[i][2] | 0; this.rm[k] = 1; this.gm[k] = g; if (g > maxg) maxg = g; }
        for (i = 0; i < r.walls.length; i++) this.wm[r.walls[i][1] * d.W + r.walls[i][0]] = 1;
        if (G.isOrb(r.exit)) for (i = 0; i < r.exit.orb.length; i++) this.om[r.exit.orb[i][1] * d.W + r.exit.orb[i][0]] = 1;
        this.gid = Math.max(this.gid || 0, maxg);
      },
      flushMasks: function () {
        var d = this.dims(), rocks = [], walls = [], x, y;
        for (y = 0; y < d.H; y++) for (x = 0; x < d.W; x++) {
          var k = y * d.W + x;
          if (this.rm[k]) rocks.push(this.gm[k] > 0 ? [x, y, this.gm[k]] : [x, y]); else if (this.wm[k]) walls.push([x, y]);
        }
        this.level.rocks = rocks; this.level.walls = walls; this.bump();
      },
      /* odstraní předpostavené věže, které by se překrývaly s buňkou (x,y) */
      dropTowersAt: function (x, y, n) {
        var r = this.raw(); if (!r.towers || !r.towers.length) return false;
        var S = BD.SUB, keep = r.towers.filter(function (t) { return !(t.x < x + n && t.x + S > x && t.y < y + n && t.y + S > y); });
        if (keep.length === r.towers.length) return false;
        this.level.towers = keep; return true;
      },
      paintCell: function (cx, cy) {
        var d = this.dims(), n = this.brush, st = this.stroke, tool = st.tool, x, y, any = false;
        for (y = cy; y < cy + n; y++) for (x = cx; x < cx + n; x++) {
          if (x < 0 || y < 0 || x >= d.W || y >= d.H) continue;
          var k = y * d.W + x, r = this.rm[k], w = this.wm[k], gg = this.gm[k];
          if (this.om[k]) continue;                                               // koule cíle zůstane; přesuň ji nástrojem Cíl
          if (tool === 'rock') { this.rm[k] = 1; this.wm[k] = 0; this.gm[k] = st.gid; } else if (tool === 'wall') { this.wm[k] = 1; this.rm[k] = 0; this.gm[k] = 0; } else { this.rm[k] = 0; this.wm[k] = 0; this.gm[k] = 0; }
          if (r !== this.rm[k] || w !== this.wm[k] || gg !== this.gm[k]) any = true;
          if (this.dropTowersAt(x, y, 1)) any = true;
        }
        return any;
      },
      /* štětec je vystředěný na ukazatel */
      brushOrigin: function (q) { var o = Math.floor(this.brush / 2); return [Math.floor(q.x) - o, Math.floor(q.y) - o]; },

      /* ---- brány: kreslí se po buňkách ---- */
      sideOf: function (q) {
        var d = this.dims(), dist = [q.x, d.W - q.x, q.y, d.H - q.y], best = 0, i;
        for (i = 1; i < 4; i++) if (dist[i] < dist[best]) best = i;
        return ['L', 'R', 'T', 'B'][best];
      },
      alongOf: function (side, q) { var d = this.dims(), n = G.sideLen(side, d.W, d.H), a = side === 'L' || side === 'R' ? q.y : q.x; return BD.util.clamp(Math.floor(a), 0, n - 1); },
      gateCellAt: function (side, a) { var d = this.dims(); return side === 'L' ? [-1, a] : side === 'R' ? [d.W, a] : side === 'T' ? [a, -1] : [a, d.H]; },
      /* buňky všech bran (kromě ignorovaných) → index brány; 'e' = cíl */
      ownerMap: function (skipExit) {
        var d = this.dims(), r = this.raw(), map = {};
        r.spawns.forEach(function (g, i) { G.gateCells(g, d.W, d.H).forEach(function (c) { map[c[0] + ',' + c[1]] = i; }); });
        if (!skipExit) G.exitCellsOf(r.exit, d.W, d.H).forEach(function (c) { map[c[0] + ',' + c[1]] = 'e'; });
        return map;
      },
      /* buňka se nedotýká žádné jiné brány (ani úhlopříčně ne – stačí 4-sousedství) */
      cellFree: function (x, y, map) {
        if (map[x + ',' + y] !== undefined) return false;
        for (var i = 0; i < 4; i++) if (map[(x + G.DIRS[i][0]) + ',' + (y + G.DIRS[i][1])] !== undefined) return false;
        return true;
      },
      removeSpawn: function (i) {
        if (this.level.spawns.length < 2) { this.msg = 'Level potřebuje aspoň jeden vstup.'; return; }
        this.snap(); this.level.spawns.splice(i, 1); this.changed(false);
      },
      spawnAt: function (q) {
        var d = this.dims(), x = Math.floor(q.x), y = Math.floor(q.y), sp = this.raw().spawns;
        for (var i = 0; i < sp.length; i++) {
          var cs = G.gateCells(sp[i], d.W, d.H);
          for (var j = 0; j < cs.length; j++) if (cs[j][0] === x && cs[j][1] === y) return i;
        }
        return -1;
      },
      inRing: function (q) { var d = this.dims(); return q.x < 0 || q.y < 0 || q.x >= d.W || q.y >= d.H; },
      inField: function (x, y) { var d = this.dims(); return x >= 0 && y >= 0 && x < d.W && y < d.H; },

      startGate: function (ev, q, tool) {
        var L = this.raw(), d = this.dims();
        if (tool === 'spawn' && L.spawns.length >= this.max) { this.msg = 'Maximum je ' + this.max + ' vstupů.'; return; }
        var side = this.sideOf(q), a = this.alongOf(side, q), map = this.ownerMap(tool === 'exit'), c = this.gateCellAt(side, a);
        if (!this.cellFree(c[0], c[1], map)) { this.msg = 'Brány se nesmí dotýkat – nech mezi nimi aspoň jednu buňku mezery.'; return; }
        this.snap();
        this.stroke = { kind: 'gate', tool: tool, side: side, start: a, lo: a, hi: a, map: map, n: G.sideLen(side, d.W, d.H) };
        try { this.$refs.cv.setPointerCapture(ev.pointerId); } catch (e) { /* ignore */ }
        this.draw();
      },
      moveGate: function (q) {
        var st = this.stroke, a2 = this.alongOf(st.side, q), a, c;
        st.lo = st.hi = st.start;
        if (a2 > st.start) { for (a = st.start + 1; a <= a2; a++) { c = this.gateCellAt(st.side, a); if (!this.cellFree(c[0], c[1], st.map)) break; st.hi = a; } }
        else if (a2 < st.start) { for (a = st.start - 1; a >= a2; a--) { c = this.gateCellAt(st.side, a); if (!this.cellFree(c[0], c[1], st.map)) break; st.lo = a; } }
      },
      commitGate: function (st) {
        var g = { side: st.side, pos: st.lo, len: st.hi - st.lo + 1 };
        if (st.tool === 'spawn') this.level.spawns.push(g); else this.level.exit = g;
        this.changed(false);
      },

      /* ---- cíl uvnitř pole: koule ---- */
      startOrb: function (ev, q) {
        var map = this.ownerMap(true);
        this.snap();
        this.stroke = { kind: 'orb', cells: {}, count: 0, last: null, map: map, bad: false };
        try { this.$refs.cv.setPointerCapture(ev.pointerId); } catch (e) { /* ignore */ }
        this.moveOrb(q);
      },
      moveOrb: function (q) {
        var st = this.stroke, o = this.brushOrigin(q), l = st.last || o, steps = Math.max(Math.abs(o[0] - l[0]), Math.abs(o[1] - l[1]), 1), n = this.brush;
        for (var s = 1; s <= steps; s++) {
          var cx = Math.round(l[0] + (o[0] - l[0]) * s / steps), cy = Math.round(l[1] + (o[1] - l[1]) * s / steps);
          for (var y = cy; y < cy + n; y++) for (var x = cx; x < cx + n; x++) {
            if (!this.inField(x, y) || st.cells[x + ',' + y]) continue;
            if (!this.cellFree(x, y, st.map)) { st.bad = true; continue; }
            if (st.count >= Lv.MAX_ORB) continue;
            st.cells[x + ',' + y] = [x, y]; st.count++;
          }
        }
        st.last = o;
      },
      commitOrb: function (st) {
        var cells = Object.keys(st.cells).map(function (k) { return st.cells[k]; }), d = this.dims(), self = this;
        cells.sort(function (a, b) { return a[1] - b[1] || a[0] - b[0]; });
        this.level.exit = { orb: cells };
        this.buildMasks();
        var under = {}; cells.forEach(function (c) { under[c[0] + ',' + c[1]] = 1; });
        this.level.rocks = this.raw().rocks.filter(function (r) { return !under[r[0] + ',' + r[1]]; });
        this.level.walls = this.raw().walls.filter(function (r) { return !under[r[0] + ',' + r[1]]; });
        cells.forEach(function (c) { self.dropTowersAt(c[0], c[1], 1); });
        this.changed(false);
      },

      /* ---- předpostavené věže ---- */
      towerIndexAt: function (x, y) {
        var t = this.raw().towers || [], S = BD.SUB;
        for (var i = t.length - 1; i >= 0; i--) if (x >= t[i].x && x < t[i].x + S && y >= t[i].y && y < t[i].y + S) return i;
        return -1;
      },
      towerPos: function (q) { var d = this.dims(), S = BD.SUB; return [BD.util.clamp(Math.round(q.x - S / 2), 0, d.W - S), BD.util.clamp(Math.round(q.y - S / 2), 0, d.H - S)]; },
      towerFits: function (p) {
        var d = this.dims(), S = BD.SUB, x, y;
        for (y = 0; y < S; y++) for (x = 0; x < S; x++) {
          var k = (p[1] + y) * d.W + p[0] + x;
          if (this.rm[k] || this.wm[k] || this.om[k] || this.towerIndexAt(p[0] + x, p[1] + y) >= 0) return false;
        }
        return true;
      },
      placeTower: function (q) {
        var p = this.towerPos(q), L = this.raw();
        if (!this.towerFits(p)) { this.msg = 'Tady už něco je.'; return; }
        if ((L.towers || []).length >= 300) { this.msg = 'Víc než 300 věží nejde.'; return; }
        var cand = Object.assign({}, L, { towers: (L.towers || []).concat([{ type: this.towerType, x: p[0], y: p[1] }]) });
        if (this.check.ok && !Lv.validate(cand).ok) { this.msg = 'Věž by zavřela cestu bublinám.'; return; }
        this.snap(); this.level.towers = cand.towers; this.changed(false);
      },
      clearTowers: function () { this.snap(); this.level.towers = []; this.changed(false); },

      /* ---- pravidla levelu ---- */
      setRule: function (f, ev) {
        var lim = Lv.LIMITS[f], v = Math.round(Number(ev.target.value));
        if (!isFinite(v)) v = f === 'lives' ? BD.systems.GAME.LIVES_START : f === 'gold' ? BD.systems.GAME.GOLD_START : 20;
        v = BD.util.clamp(v, f === 'waves' ? Lv.MIN_WAVES : lim[0], lim[1]);
        ev.target.value = v;
        if (this.level[f] === v) return;
        this.snap(); this.level[f] = v; if (f === 'waves') this.lastWaves = v; this.changed(false);
      },
      setEndless: function (on) {
        this.snap();
        if (on) { this.lastWaves = this.level.waves > 0 ? this.level.waves : this.lastWaves; this.level.waves = 0; } else this.level.waves = this.lastWaves || 20;
        this.changed(false);
      },
      setHp: function (pct) {
        var v = BD.util.clamp(Math.round(Number(pct)), 25, 400) / 100;
        if (!this.hpSnapped) { this.snap(); this.hpSnapped = true; clearTimeout(this.hpT); }
        clearTimeout(this.hpT); var self = this; this.hpT = setTimeout(function () { self.hpSnapped = false; }, 600);
        if (v === 1) delete this.level.hp; else this.level.hp = v;
        this.changed(false);
      },
      toggleAllowed: function (id, ev) {
        var cur = this.rules.allowed.slice(), i = cur.indexOf(id);
        if (i >= 0) { if (cur.length < 2) { this.msg = 'Aspoň jedna kategorie věží musí zůstat.'; if (ev) ev.target.checked = true; return; } cur.splice(i, 1); } else cur.push(id);
        var all = this.categories.map(function (c) { return c.id; });
        this.snap();
        if (all.every(function (a) { return cur.indexOf(a) >= 0; })) delete this.level.allowed; else this.level.allowed = all.filter(function (a) { return cur.indexOf(a) >= 0; });
        this.changed(false);
      },

      /* ---- velikost mapy a čištění ---- */
      resize: function (w, h) {
        w = BD.util.clamp(w, Lv.MIN_SIZE, Lv.MAX_SIZE); h = BD.util.clamp(h, Lv.MIN_SIZE, Lv.MAX_SIZE);
        var L = this.level; if (w === L.w && h === L.h) return;
        this.snap();
        var W = w * BD.SUB, H = h * BD.SUB, S = BD.SUB;
        function fix(g) { var n = G.sideLen(g.side, W, H), len = Math.min(g.len, n); return { side: g.side, len: len, pos: BD.util.clamp(g.pos, 0, n - len) }; }
        var sp = L.spawns.map(fix), r = this.raw(), ex;
        if (G.isOrb(r.exit)) {
          var keep = r.exit.orb.filter(function (c) { return c[0] < W && c[1] < H; });
          ex = keep.length ? { orb: keep } : fix({ side: 'R', pos: 0, len: Math.min(4, H) });
        } else ex = fix(r.exit);
        L.rocks = r.rocks.filter(function (c) { return c[0] < W && c[1] < H; });
        L.walls = r.walls.filter(function (c) { return c[0] < W && c[1] < H; });
        if (r.towers) L.towers = r.towers.filter(function (t) { return t.x + S <= W && t.y + S <= H; });
        L.w = w; L.h = h; L.spawns = sp; L.exit = ex;
        this.changed(true);
      },
      async clearAll() {
        var ok = await BD.ui.confirm('Smazat všechny skály, zdi a předpostavené věže? (Brány a cíl zůstanou.)', { ok: 'Smazat' });
        if (!ok) return;
        this.snap(); this.level.rocks = []; this.level.walls = []; this.level.towers = []; this.changed(false);
      },

      /* ---- plátno ---- */
      fit: function () {
        var st = this.$refs.stage, cv = this.$refs.cv; if (!st || !cv || !this.level) return;
        var d = this.dims(), pad = 16;
        this.cell = Math.max(3, Math.floor(Math.min((st.clientWidth - pad) / (d.W + 2), (st.clientHeight - pad) / (d.H + 2))));
        this.dpr = window.devicePixelRatio || 1;
        var w = this.cell * (d.W + 2), h = this.cell * (d.H + 2);
        cv.width = Math.round(w * this.dpr); cv.height = Math.round(h * this.dpr); cv.style.width = w + 'px'; cv.style.height = h + 'px';
        this.draw();
      },
      pointer: function (ev) {
        var r = this.$refs.cv.getBoundingClientRect();
        return { x: (ev.clientX - r.left) / this.cell - 1, y: (ev.clientY - r.top) / this.cell - 1 };
      },
      fillCells: function (ctx, list, c, fill, stroke) {
        ctx.fillStyle = fill; list.forEach(function (p) { ctx.fillRect(p[0] * c, p[1] * c, c, c); });
        if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = 1.5; list.forEach(function (p) { ctx.strokeRect(p[0] * c + .75, p[1] * c + .75, c - 1.5, c - 1.5); }); }
      },
      draw: function () {
        var cv = this.$refs.cv; if (!cv || !this.level || !this.cell) return;
        var ctx = cv.getContext('2d'), c = this.cell, r = this.raw(), d = this.dims(), self = this;
        var w = c * (d.W + 2), h = c * (d.H + 2);
        ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
        ctx.clearRect(0, 0, w, h);
        var lay = F.layer(this.lyr, (this.ver || 0) + '|' + c + '|' + this.dpr, w, h, this.dpr, function (cx) { F.base(cx, r, c, { grid: true, gates: true }); });
        ctx.drawImage(lay, 0, 0, w, h);
        ctx.save(); ctx.translate(c, c);
        F.orbs(ctx, r, c);
        if (G.isOrb(r.exit)) {                                              // žlutý přerušovaný kroužek: tady je cíl (jen v editoru)
          G.orbBlobs(r.exit.orb).forEach(function (b) { ctx.save(); ctx.setLineDash([c * 0.4, c * 0.3]); ctx.strokeStyle = 'rgba(240,191,76,.8)'; ctx.lineWidth = 1.5;
            ctx.beginPath(); ctx.arc(b.cx * c, b.cy * c, b.r * c * 1.45, 0, Math.PI * 2); ctx.stroke(); ctx.restore(); });
        }
        (r.towers || []).forEach(function (t) {
          D.tower(ctx, { type: t.type, x: t.x, y: t.y, size: BD.SUB, level: t.type === 'base' ? 0 : 1, tier: 0, branch: null, angle: 0, boost: 1 }, c);
        });
        var st = this.stroke, q = this.hover, tool = this.tool, n = this.brush, o, g, cs;
        if (st && st.kind === 'gate') {
          cs = []; for (var a = st.lo; a <= st.hi; a++) cs.push(this.gateCellAt(st.side, a));
          this.fillCells(ctx, cs, c, st.tool === 'exit' ? 'rgba(240,191,76,.7)' : 'rgba(229,107,97,.7)', '#fff');
        } else if (st && st.kind === 'orb') {
          this.fillCells(ctx, Object.keys(st.cells).map(function (k) { return st.cells[k]; }), c, 'rgba(240,191,76,.55)', null);
        } else if (q && !st) {
          if (this.isPaint || tool === 'erase') {
            o = this.brushOrigin(q);
            ctx.fillStyle = tool === 'erase' ? 'rgba(229,107,97,.35)' : tool === 'rock' ? 'rgba(74,83,104,.7)' : 'rgba(52,68,79,.8)';
            ctx.fillRect(o[0] * c, o[1] * c, n * c, n * c); ctx.strokeStyle = 'rgba(240,191,76,.9)'; ctx.lineWidth = 1.5; ctx.strokeRect(o[0] * c, o[1] * c, n * c, n * c);
          } else if (tool === 'spawn' || (tool === 'exit' && this.inRing(q))) {
            var side = this.sideOf(q), aa = this.alongOf(side, q), cc = this.gateCellAt(side, aa), map = this.ownerMap(tool === 'exit');
            var ok = this.cellFree(cc[0], cc[1], map) && !(tool === 'spawn' && r.spawns.length >= this.max);
            this.fillCells(ctx, [cc], c, ok ? (tool === 'exit' ? 'rgba(240,191,76,.7)' : 'rgba(229,107,97,.7)') : 'rgba(255,255,255,.25)', ok ? '#fff' : 'rgba(229,107,97,.9)');
          } else if (tool === 'exit') {
            o = this.brushOrigin(q); g = this.ownerMap(true); cs = [];
            for (var yy = o[1]; yy < o[1] + n; yy++) for (var xx = o[0]; xx < o[0] + n; xx++) if (this.inField(xx, yy) && this.cellFree(xx, yy, g)) cs.push([xx, yy]);
            this.fillCells(ctx, cs, c, 'rgba(240,191,76,.45)', 'rgba(240,191,76,.9)');
          } else if (tool === 'tower') {
            var p = this.towerPos(q), fits = this.towerFits(p);
            ctx.globalAlpha = 0.65; D.tower(ctx, { type: this.towerType, x: p[0], y: p[1], size: BD.SUB, level: this.towerType === 'base' ? 0 : 1, tier: 0, branch: null, angle: 0, boost: 1 }, c); ctx.globalAlpha = 1;
            ctx.strokeStyle = fits ? 'rgba(240,191,76,.9)' : 'rgba(229,107,97,.95)'; ctx.lineWidth = 2; ctx.strokeRect(p[0] * c, p[1] * c, BD.SUB * c, BD.SUB * c);
          }
        }
        ctx.restore();
      },

      /* ---- ukazatel ---- */
      onDown: function (ev) {
        if (!this.level || ev.button === 1) return;
        var q = this.pointer(ev), tool = ev.button === 2 ? 'erase' : this.tool, i;
        this.msg = '';
        if (tool === 'spawn') { this.startGate(ev, q, 'spawn'); return; }
        if (tool === 'exit') { if (this.inRing(q)) this.startGate(ev, q, 'exit'); else this.startOrb(ev, q); return; }
        if (tool === 'tower') { if (this.inField(Math.floor(q.x), Math.floor(q.y))) this.placeTower(q); return; }
        if (tool === 'erase') {
          i = this.spawnAt(q);
          if (i >= 0) { this.removeSpawn(i); return; }
          var cx = Math.floor(q.x), cy = Math.floor(q.y);
          i = this.towerIndexAt(cx, cy);
          if (i >= 0) { this.snap(); this.level.towers.splice(i, 1); this.changed(false); return; }
          if (this.inField(cx, cy) && this.om[cy * this.dims().W + cx]) { this.msg = 'Cíl nejde smazat – přesuň ho nástrojem Cíl.'; return; }
        }
        this.snap();
        this.stroke = { kind: 'paint', tool: tool, last: null, dirty: false, gid: tool === 'rock' ? ++this.gid : 0 };
        try { this.$refs.cv.setPointerCapture(ev.pointerId); } catch (e) { /* ignore */ }
        this.onMove(ev);
      },
      onMove: function (ev) {
        var q = this.pointer(ev), st = this.stroke; this.hover = q;
        var inside = !this.inRing(q); if (inside !== this.hoverInside) this.hoverInside = inside;
        if (st && st.kind === 'paint') {
          var o = this.brushOrigin(q), l = st.last || o, steps = Math.max(Math.abs(o[0] - l[0]), Math.abs(o[1] - l[1]), 1);
          for (var s = 1; s <= steps; s++) if (this.paintCell(Math.round(l[0] + (o[0] - l[0]) * s / steps), Math.round(l[1] + (o[1] - l[1]) * s / steps))) st.dirty = true;
          st.last = o;
          if (st.dirty) { this.flushMasks(); this.touch(); }
        } else if (st && st.kind === 'gate') this.moveGate(q);
        else if (st && st.kind === 'orb') this.moveOrb(q);
        this.draw();
      },
      onUp: function () {
        var st = this.stroke; if (!st) return;
        this.stroke = null;
        if (st.kind === 'paint') {
          if (st.dirty) { this.flushMasks(); this.rev++; this.touch(); } else this.undo.pop();
        } else if (st.kind === 'gate') this.commitGate(st);
        else if (st.kind === 'orb') {
          if (st.count) this.commitOrb(st);
          else { this.undo.pop(); this.msg = st.bad ? 'Cíl se nesmí dotýkat brány vstupu – nech mezi nimi aspoň jednu buňku.' : ''; }
        }
        this.draw();
      },
      onCancel: function () {
        if (!this.stroke) return;
        this.stroke = null; this.doUndo();                       // vrátí stav před začátkem tahu
      },
      onLeave: function () { if (!this.stroke) { this.hover = null; this.draw(); } },

      /* ---- klávesové zkratky ---- */
      onKey: function (ev) {
        var tg = ev.target && ev.target.tagName; if (tg === 'INPUT' || tg === 'TEXTAREA' || tg === 'SELECT') return;
        if (!this.level) return;
        var k = String(ev.key || '').toLowerCase();
        if ((ev.ctrlKey || ev.metaKey) && k === 'z') { ev.preventDefault(); this.doUndo(); return; }
        if (ev.ctrlKey || ev.metaKey || ev.altKey) return;
        if (k === 'escape') { this.onCancel(); return; }
        var code = ev.code || '', m = /^(?:Digit|Numpad)([123])$/.exec(code);
        if (m) { this.brush = [1, 2, 4][+m[1] - 1]; return; }
        for (var i = 0; i < this.tools.length; i++) if (this.tools[i].key === k) { this.tool = this.tools[i].id; this.panel = 'draw'; return; }
      },
      tick: function () {
        this.raf = requestAnimationFrame(this.tick);
        if (this.level && G.isOrb(this.raw().exit) && !document.hidden) this.draw();
      },
    },
    watch: { tool: function () { this.msg = ''; this.draw(); }, brush: function () { this.draw(); }, panel: function () { this.$nextTick(this.fit); } },
    mounted: function () {
      this.cell = 0; this.hover = null; this.stroke = null; this.lyr = {}; this.ver = 0; this.gid = 0; this.lastWaves = 0;
      if (!this.level) return;
      if (this.level.waves > 0) this.lastWaves = this.level.waves;
      this.buildMasks();
      var self = this;
      this.ro = new ResizeObserver(function () { self.fit(); }); this.ro.observe(this.$refs.stage);
      var cv = this.$refs.cv;
      cv.addEventListener('pointerdown', this.onDown); cv.addEventListener('pointermove', this.onMove);
      cv.addEventListener('pointerup', this.onUp); cv.addEventListener('pointercancel', this.onCancel); cv.addEventListener('pointerleave', this.onLeave);
      window.addEventListener('keydown', this.onKey);
      this.fit();
      this.raf = requestAnimationFrame(this.tick);
      BD.debugEditor = this;
    },
    beforeUnmount: function () {
      if (this.ro) this.ro.disconnect();
      window.removeEventListener('keydown', this.onKey); cancelAnimationFrame(this.raf); clearTimeout(this.hpT);
    },
  };
})(window.BD);
