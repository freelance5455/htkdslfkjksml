// Port of ui/widgets.py (Card, TopicTile, BottomNav, MasteryBar) as DOM builders,
// plus a modal/toast system standing in for QMessageBox / QInputDialog.

export function el(tag, props = {}, children = []) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === "class") node.className = v;
    else if (k === "html" || k === "innerHTML") node.innerHTML = v;
    else if (k === "text") node.textContent = v;
    else if (k.startsWith("on") && typeof v === "function") node.addEventListener(k.slice(2).toLowerCase(), v);
    else if (v !== null && v !== undefined) node.setAttribute(k, v);
  }
  (Array.isArray(children) ? children : [children]).forEach((c) => {
    if (c === null || c === undefined || c === false) return;
    node.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
  });
  return node;
}

export function heading(text, role = "heading") { return el("div", { class: `role-${role} wrap` }, text); }

// ---------------- Card ----------------
// actions: [{label, onClick, secondary}]
export function card(title, body = "", actions = []) {
  const kids = [el("div", { class: "role-heading wrap" }, title)];
  if (body) kids.push(el("div", { class: "role-subtitle wrap" }, body));
  if (actions && actions.length) {
    kids.push(el("div", { class: "card-actions" }, actions.map((a) =>
      el("button", { class: a.secondary ? "btn-secondary" : "btn", onClick: a.onClick }, a.label)
    )));
  }
  return el("div", { class: "card" }, kids);
}

// ---------------- Topic tile (Learn / Choose Topic) ----------------
export function topicTile(icon, name, subtitle, onOpen, onPractice = null) {
  const actions = [el("button", { class: "btn", onClick: onOpen }, "OPEN NOTES")];
  if (onPractice) actions.push(el("button", { class: "btn-secondary", onClick: onPractice }, "PRACTICE THIS"));
  return el("div", { class: "tile" }, [
    el("div", { class: "role-heading wrap" }, `${icon}  ${name}`),
    subtitle ? el("div", { class: "role-subtitle wrap" }, subtitle) : null,
    el("div", { class: "btn-row" }, actions)
  ]);
}

// ---------------- Bottom navigation ----------------
export function bottomNav(app, activeKey = "") {
  const isPS = app.student?.subject === "physical_sciences" && (app.student?.grade ?? 0) >= 10;
  const sid = app.student?.subject || "maths";
  const isAlt = sid !== "maths";
  const buttons = isPS
    ? [
        ["home", "🏠", "Home", () => app.showHome()],
        ["learn", "🔬", "Topics", () => app.showScience()],
        ["practice", "✏️", "Practice", () => app.showPractice("choose")],
        ["papers", "📝", "Papers", () => app.showPapers()],
        ["profile", "👤", "You", () => app.showProfile()]
      ]
    : isAlt
    ? [
        ["home", "🏠", "Home", () => app.showHome()],
        ["learn", "📚", "Topics", () => app.showLearn()],
        ["practice", "✏️", "Practice", () => app.showSubjectHub()],
        ["papers", "📝", "Quiz", () => app.showSubjectHub()],
        ["profile", "👤", "You", () => app.showProfile()]
      ]
    : [
        ["home", "🏠", "Home", () => app.showHome()],
        ["learn", "📚", "Learn", () => app.showLearn()],
        ["practice", "✏️", "Practice", () => app.showPractice()],
        ["papers", "📝", "Papers", () => app.showPapers()],
        ["profile", "👤", "You", () => app.showProfile()]
      ];
  return el("div", { class: "bottomnav" }, buttons.map(([key, icon, label, cb]) =>
    el("button", { class: key === activeKey ? "active" : "", onClick: cb }, [
      el("span", {}, icon),
      el("span", { class: "nav-label" }, label)
    ])
  ));
}

// ---------------- Progress / mastery ----------------
export function progressBar(value, max, label = null) {
  const pct = max > 0 ? Math.max(0, Math.min(100, (value / max) * 100)) : 0;
  return el("div", { class: "progress" }, [
    el("i", { style: `width:${pct}%` }),
    el("span", { class: "progress-label" }, label ?? `${value} / ${max}`)
  ]);
}
export function masteryBar(label, value) {
  return el("div", { class: "mastery-row" }, [
    el("div", { class: "m-label" }, label),
    progressBar(Math.round(value * 100), 100, `${Math.round(value * 100)}%`)
  ]);
}

// ================= MODAL / TOAST SYSTEM =================
const root = () => document.getElementById("modal-root");

function openSheet(children) {
  const backdrop = el("div", { class: "modal-backdrop", onClick: (e) => { if (e.target === backdrop) close(); } });
  const sheet = el("div", { class: "modal-sheet" }, children);
  backdrop.appendChild(sheet);
  root().appendChild(backdrop);
  function close() { backdrop.remove(); }
  return { backdrop, sheet, close };
}

export function showAlert(title, message) {
  return new Promise((resolve) => {
    const { close } = openSheet([
      el("div", { class: "modal-title" }, title),
      el("div", { class: "modal-msg" }, message),
      el("button", { class: "btn", onClick: () => { close(); resolve(); } }, "OK")
    ]);
  });
}

export function showConfirm(title, message, okLabel = "CONFIRM", cancelLabel = "CANCEL") {
  return new Promise((resolve) => {
    const { close } = openSheet([
      el("div", { class: "modal-title" }, title),
      el("div", { class: "modal-msg" }, message),
      el("div", { class: "btn-row" }, [
        el("button", { class: "btn-secondary", onClick: () => { close(); resolve(false); } }, cancelLabel),
        el("button", { class: "btn", onClick: () => { close(); resolve(true); } }, okLabel)
      ])
    ]);
  });
}

export function showPrompt(title, message, placeholder = "", isPassword = false) {
  return new Promise((resolve) => {
    const input = el("input", { type: isPassword ? "password" : "text", placeholder });
    input.addEventListener("keydown", (e) => { if (e.key === "Enter") submit(); });
    function submit() { const v = input.value; close(); resolve(v); }
    const { close } = openSheet([
      el("div", { class: "modal-title" }, title),
      message ? el("div", { class: "modal-msg" }, message) : null,
      input,
      el("div", { class: "btn-row" }, [
        el("button", { class: "btn-secondary", onClick: () => { close(); resolve(null); } }, "CANCEL"),
        el("button", { class: "btn", onClick: submit }, "OK")
      ])
    ]);
    setTimeout(() => input.focus(), 50);
  });
}

let toastTimer = null;
export function showToast(message, ms = 2600) {
  let t = document.querySelector(".toast");
  if (t) t.remove();
  t = el("div", { class: "toast" }, message);
  document.body.appendChild(t);
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.remove(), ms);
}


/** Turn ⟦FRAC:n/d⟧ markers into stacked fraction HTML. */
export function formatQuestionHTML(text) {
  const s = String(text ?? "");
  const escaped = s
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  return escaped
    .replace(/⟦FRAC:([^/]+)\/([^⟧]+)⟧/g,
      (_, n, d) => `<span class="frac"><span class="frac-num">${n}</span><span class="frac-den">${d}</span></span>`)
    .replace(/\n/g, "<br>");
}

/** Simple maths keypad. Returns a div; buttons write into target input. */
export function mathKeyboard(inputEl) {
  const keys = ["7","8","9","÷","4","5","6","×","1","2","3","−","0",".","=","+","⌫"];
  const wrap = el("div", { class: "math-kbd", style: "display:grid;grid-template-columns:repeat(4,1fr);gap:0.35rem;margin-top:0.5rem;" });
  keys.forEach((k) => {
    wrap.appendChild(el("button", {
      class: "btn-secondary btn-sm",
      type: "button",
      onClick: (e) => {
        e.preventDefault();
        if (!inputEl) return;
        if (k === "⌫") inputEl.value = inputEl.value.slice(0, -1);
        else if (k === "=") inputEl.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
        else inputEl.value += k === "−" ? "-" : k;
        inputEl.focus();
      }
    }, k));
  });
  return wrap;
}
