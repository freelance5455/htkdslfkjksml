/* StoryMap – mapa levelů ve story módu.
   - splněný level svítí, hratelný pulzuje, další krok je vidět zašedle (zbytek je skrytý)
   - najetí myší na bublinu ukáže popup s tvarem levelu (na dotyku první klepnutí, druhé spustí)
   - přiblížení s posunem a minimapkou se nabídne jen u velkého stromu (odkryto ≥ BIG_NODES uzlů, nebo je mapa na malé obrazovce moc drobná)
   Události: play (uzel), back, skip (přeskočit tutoriál)
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  var story = BD.data.story;
  var BIG_NODES = 10;        // od tohoto počtu odkrytých uzlů se strom považuje za velký
  var MIN_GAP = 150;         // nejmenší odstup uzlů v souřadnicích mapy; na obrazovce má být aspoň 60 px

  BD.ui.components.StoryMap = {
    emits: ['play', 'back', 'skip'],
    template:
      '<div class="smap">' +
        '<div class="smap-head">' +
          '<button class="btn" @click="$emit(\'back\')"><ic n="back"></ic> Menu</button>' +
          '<h2 class="smap-title">Výběr levelu</h2>' +
          '<span class="pill">Splněno {{ doneCount }} / {{ total }}</span>' +
          '<button class="btn rel" data-act="bestiary" @click="openBook" title="Bestiář (B)"><ic n="bookopen"></ic><i class="badge" v-if="unread"></i></button>' +
          '<div class="sp"></div>' +
          '<button class="btn" v-if="!tutDone" @click="$emit(\'skip\')"><ic n="fast"></ic> Přeskočit tutoriál</button>' +
        '</div>' +

        '<div class="smap-body" ref="body" :class="{pan: big && zoom > 1.01, dragging: dragging}" @pointermove="onMove" @pointerdown="onDown" @pointerup="onUp" @pointercancel="onUp" @wheel.prevent="onWheel" @click="tip = null">' +
          '<svg class="smap-svg" ref="svg" :viewBox="viewBox" preserveAspectRatio="xMidYMid meet">' +
            '<g class="lines">' +
              '<path v-for="l in lines" :key="l.key" :d="l.d" :class="l.cls"></path>' +
            '</g>' +
            '<g v-for="n in shown" :key="n.id" class="node" :class="n.st" :transform="\'translate(\' + n.x + \',\' + n.y + \')\'"' +
               ' @pointerenter="enter(n, $event)" @pointerleave="leave" @click.stop="click(n, $event)">' +
              '<circle class="halo" r="27"></circle>' +
              '<circle class="dot" r="17"></circle>' +
              '<path v-if="n.st === \'done\'" class="chk" d="M-7 0.5 L-2 5.5 L7.5 -5"></path>' +
              '<text v-else-if="n.st === \'locked\'" class="q" y="5" text-anchor="middle">?</text>' +
              '<text v-else class="num" y="5" text-anchor="middle">{{ n.tutorial ? \'T\' : n.idx }}</text>' +
              '<text class="lbl" y="44" text-anchor="middle">{{ n.st === \'locked\' ? \'\' : n.title }}</text>' +
            '</g>' +
          '</svg>' +

          '<div class="zoomui" v-if="big" @pointerdown.stop @click.stop>' +
            '<svg v-if="zoom > 1.01" class="mini" ref="mini" viewBox="0 0 1000 540" @pointerdown="miniDown" @pointermove="miniMove" @pointerup="miniUp" @pointercancel="miniUp">' +
              '<rect x="0" y="0" width="1000" height="540" class="mbg"></rect>' +
              '<path v-for="l in lines" :key="l.key" :d="l.d" :class="l.cls" class="ml"></path>' +
              '<circle v-for="n in shown" :key="n.id" :cx="n.x" :cy="n.y" r="12" :class="\'md \' + n.st"></circle>' +
              '<rect class="mv" :x="vb.x" :y="vb.y" :width="vb.w" :height="vb.h"></rect>' +
            '</svg>' +
            '<div class="zbtns">' +
              '<button class="btn sm" data-act="zin" @click="zoomBy(1.4)" title="Přiblížit"><ic n="plus"></ic></button>' +
              '<button class="btn sm" data-act="zout" @click="zoomBy(1 / 1.4)" :disabled="zoom <= 1.01" title="Oddálit"><span class="minus"></span></button>' +
              '<button class="btn sm" data-act="zfull" v-if="zoom > 1.01" @click="fullMap"><ic n="zoomout"></ic> Celá mapa</button>' +
            '</div>' +
          '</div>' +

          '<div class="tip" v-if="tip" :style="tipStyle">' +
            '<template v-if="tip.node.st === \'locked\'">' +
              '<div class="tip-title"><ic n="lock"></ic> Zamčeno</div>' +
              '<div class="hint">Nejdřív dokonči předchozí level.</div>' +
            '</template>' +
            '<template v-else>' +
              '<div class="tip-shape"><bd-level-preview :level="tip.node.level"></bd-level-preview></div>' +
              '<div class="tip-title">{{ tip.node.title }}</div>' +
              '<div class="tip-meta">{{ tip.node.level.waves }} vln · {{ tip.node.level.w }}×{{ tip.node.level.h }} · {{ tip.node.level.spawns.length }} {{ tip.node.level.spawns.length === 1 ? \'vstup\' : \'vstupy\' }}</div>' +
              '<div class="tip-state" :class="tip.node.st">{{ tip.node.st === \'done\' ? \'Splněno, můžeš hrát znovu\' : (ptr === \'touch\' ? \'Klepni znovu pro start\' : \'Klikni pro start\') }}</div>' +
            '</template>' +
          '</div>' +
        '</div>' +
      '</div>',

    data: function () { return { p: BD.store.profile, tip: null, mx: 0, my: 0, ptr: 'mouse', total: story.total, bw: 1000, bh: 540, zoom: 1, cx: 500, cy: 270, dragging: false }; },

    computed: {
      unread: function () { return BD.bestiary.unreadCount() > 0; },
      big: function () {
        var sc = Math.min(this.bw / 1000, this.bh / 540);
        return this.shown.length >= BIG_NODES || sc * MIN_GAP < 60;
      },
      vb: function () { var w = 1000 / this.zoom, h = 540 / this.zoom; return { x: this.cx - w / 2, y: this.cy - h / 2, w: w, h: h }; },
      viewBox: function () { var v = this.vb; return v.x + ' ' + v.y + ' ' + v.w + ' ' + v.h; },
      done: function () { return story.doneMap(this.p.story.completed); },
      doneCount: function () { return this.p.story.completed.filter(function (id) { return !!story.byId[id]; }).length; },
      tutDone: function () { return !!this.done.t1; },
      shown: function () {
        var d = this.done, out = [], n = 0;
        story.nodes.forEach(function (node) {
          if (!node.tutorial) n++;
          var st = story.state(node, d);
          if (st === 'hidden') return;
          out.push({ id: node.id, title: node.title, x: node.x, y: node.y, level: node.level, tutorial: !!node.tutorial, st: st, idx: node.tutorial ? 0 : n, node: node });
        });
        return out;
      },
      lines: function () {
        var d = this.done, vis = {}, out = [];
        this.shown.forEach(function (s) { vis[s.id] = s; });
        story.nodes.forEach(function (n) {
          if (!vis[n.id]) return;
          n.requires.forEach(function (r) {
            var a = story.byId[r]; if (!vis[r]) return;
            var mx = (a.x + n.x) / 2;
            out.push({ key: r + '>' + n.id, d: 'M' + a.x + ',' + a.y + ' H' + mx + ' V' + n.y + ' H' + n.x, cls: d[r] ? 'on' : '' });
          });
        });
        return out;
      },
      tipStyle: function () {
        var body = this.$refs.body, w = body ? body.clientWidth : 800, h = body ? body.clientHeight : 500;
        var x = this.mx + 18, y = this.my + 18, tw = 210, th = 250;
        if (x + tw > w - 8) x = this.mx - tw - 18;
        if (y + th > h - 8) y = h - th - 8;
        return { left: Math.max(8, x) + 'px', top: Math.max(8, y) + 'px' };
      },
    },

    created: function () { this.pts = {}; this.moved = false; this.pinch = 0; },
    mounted: function () {
      var self = this, body = this.$refs.body;
      function measure() { if (body && body.clientWidth) { self.bw = body.clientWidth; self.bh = body.clientHeight; } }
      measure();
      if (window.ResizeObserver) { this.ro = new ResizeObserver(measure); this.ro.observe(body); }
    },
    beforeUnmount: function () { if (this.ro) this.ro.disconnect(); },
    watch: { big: function (b) { if (!b) this.fullMap(); } },

    methods: {
      openBook: function () { BD.bestiary.open(); },
      /* ---- přiblížení a posun mapy ---- */
      clampView: function () {
        var hw = 500 / this.zoom, hh = 270 / this.zoom;
        this.cx = Math.max(hw, Math.min(1000 - hw, this.cx)); this.cy = Math.max(hh, Math.min(540 - hh, this.cy));
      },
      geom: function () {
        var svg = this.$refs.svg, r = svg.getBoundingClientRect(), vb = this.vb, s = Math.min(r.width / vb.w, r.height / vb.h);
        return { r: r, s: s, vb: vb, ox: (r.width - vb.w * s) / 2, oy: (r.height - vb.h * s) / 2 };
      },
      toSvg: function (x, y) { var g = this.geom(); return { x: g.vb.x + (x - g.r.left - g.ox) / g.s, y: g.vb.y + (y - g.r.top - g.oy) / g.s }; },
      /* změní zoom tak, aby bod pod kurzorem (clientX/Y) zůstal na místě */
      zoomAt: function (z, clientX, clientY) {
        if (!this.big) return;
        z = Math.max(1, Math.min(5, z));
        var p = this.toSvg(clientX, clientY), v = this.vb, fx = (p.x - v.x) / v.w, fy = (p.y - v.y) / v.h;
        this.zoom = z; var w = 1000 / z, h = 540 / z;
        this.cx = p.x - fx * w + w / 2; this.cy = p.y - fy * h + h / 2; this.clampView();
      },
      zoomBy: function (k) { var r = this.$refs.svg.getBoundingClientRect(); this.zoomAt(this.zoom * k, r.left + r.width / 2, r.top + r.height / 2); },
      fullMap: function () { this.zoom = 1; this.cx = 500; this.cy = 270; },
      onWheel: function (ev) { if (!this.big) return; this.tip = null; this.zoomAt(this.zoom * (ev.deltaY < 0 ? 1.2 : 1 / 1.2), ev.clientX, ev.clientY); },
      onDown: function (ev) {
        this.ptr = ev.pointerType; this.pts[ev.pointerId] = { x: ev.clientX, y: ev.clientY }; this.moved = false;
        var ids = Object.keys(this.pts); if (this.big && ids.length === 2) this.pinch = this.pdist();
      },
      onUp: function (ev) { delete this.pts[ev.pointerId]; this.dragging = false; this.pinch = 0; },
      pdist: function () { var a = Object.keys(this.pts).map(function (k) { return this.pts[k]; }, this); return Math.hypot(a[0].x - a[1].x, a[0].y - a[1].y); },
      dragMove: function (ev) {
        var p = this.pts[ev.pointerId]; if (!p) return;
        var ids = Object.keys(this.pts);
        if (this.big && ids.length === 2) {                             // dva prsty: štípnutí
          this.pts[ev.pointerId] = { x: ev.clientX, y: ev.clientY };
          var d = this.pdist(), a = ids.map(function (k) { return this.pts[k]; }, this);
          if (this.pinch > 0) this.zoomAt(this.zoom * d / this.pinch, (a[0].x + a[1].x) / 2, (a[0].y + a[1].y) / 2);
          this.pinch = d; this.moved = true; this.tip = null; return;
        }
        var dx = ev.clientX - p.x, dy = ev.clientY - p.y;
        if (!this.dragging && Math.hypot(ev.clientX - (p.sx || p.x), ev.clientY - (p.sy || p.y)) < 6) return;
        if (!p.sx) { p.sx = p.x; p.sy = p.y; }
        if (this.zoom > 1.01) { var g = this.geom(); this.cx -= dx / g.s; this.cy -= dy / g.s; this.clampView(); this.dragging = true; this.moved = true; this.tip = null; }
        p.x = ev.clientX; p.y = ev.clientY;
      },
      /* minimapka: klik/tažení přesune pohled */
      miniAt: function (ev) {
        var r = this.$refs.mini.getBoundingClientRect(), s = Math.min(r.width / 1000, r.height / 540);
        this.cx = (ev.clientX - r.left - (r.width - 1000 * s) / 2) / s; this.cy = (ev.clientY - r.top - (r.height - 540 * s) / 2) / s; this.clampView();
      },
      miniDown: function (ev) { this.miniDrag = true; ev.target.setPointerCapture && ev.target.setPointerCapture(ev.pointerId); this.miniAt(ev); },
      miniMove: function (ev) { if (this.miniDrag) this.miniAt(ev); },
      miniUp: function () { this.miniDrag = false; },

      track: function (ev) {
        var r = this.$refs.body.getBoundingClientRect();
        this.mx = ev.clientX - r.left; this.my = ev.clientY - r.top;
      },
      onMove: function (ev) { this.dragMove(ev); if (this.tip && ev.pointerType === 'mouse' && !this.dragging) this.track(ev); },
      enter: function (n, ev) { if (ev.pointerType !== 'mouse') return; this.track(ev); this.tip = { node: n }; },
      leave: function (ev) { if (ev.pointerType === 'mouse') this.tip = null; },
      click: function (n, ev) {
        if (this.moved) { this.moved = false; return; }                  // táhnutí mapy není klik na level
        if (n.st === 'locked') return;
        if (this.ptr !== 'mouse') {                 // dotyk: první klepnutí ukáže popup, druhé spustí level
          if (!this.tip || this.tip.node.id !== n.id) { this.track(ev); this.tip = { node: n }; return; }
        }
        this.tip = null;
        this.$emit('play', n.node);
      },
    },
  };
})(window.BD);
