'use strict';
/* ================= drag-scroll for panels (works with the rotated stage) ================= */
function dragScroll(el){
 let id=null,sy=0,st=0,moved=false;
 el.addEventListener('pointerdown',e=>{if(e.pointerType==='mouse')return;id=e.pointerId;sy=pt(e).y;st=el.scrollTop;moved=false;});
 el.addEventListener('pointermove',e=>{if(e.pointerId!==id)return;const dy=pt(e).y-sy;if(!moved&&Math.abs(dy)>8){moved=true;try{el.setPointerCapture(id);}catch(x){}}if(moved)el.scrollTop=st-dy;});
 const end=e=>{if(e.pointerId===id)id=null;};
 el.addEventListener('pointerup',end);el.addEventListener('pointercancel',end);
 el.addEventListener('click',e=>{if(moved){e.stopPropagation();e.preventDefault();moved=false;}},true);
}
for(const id of['menuCard','craftCard','bagCard','tradeCard','planetCard'])dragScroll($(id));

