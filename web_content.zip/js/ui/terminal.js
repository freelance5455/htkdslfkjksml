/* Terminal – příkazový řádek (zasouvá se shora), živý log a oznámení.
   Zobrazuje se jen po odemčení (slovo „terminal“); otevírá se klávesou ` / ~ (ev.code = Backquote).
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  var dev = BD.dev;

  BD.ui.components.Terminal = {
    template:
      '<div class="dev">' +
        '<div class="dev-note" v-if="dev.notice">{{ dev.notice }}</div>' +
        '<div class="livelog" v-if="dev.liveLog && dev.unlocked" ref="ll">' +
          '<div class="ll-h">LiveLog</div>' +
          '<div class="ll-l" v-for="(l, i) in dev.log.slice(-14)" :key="i"><span>{{ l.t }}</span> {{ l.text }}</div>' +
        '</div>' +
        '<div class="term" v-if="dev.unlocked" :class="{open: dev.open}" @pointerdown.stop @click="focus">' +
          '<div class="term-out" ref="out"><div v-for="(l, i) in lines" :key="i" class="tl" :class="l.cls">{{ l.text }}</div></div>' +
          '<div class="term-in"><span class="pr">&gt;</span><input ref="inp" v-model="cmd" spellcheck="false" autocomplete="off" autocapitalize="off" @keydown="onInputKey" placeholder="help"></div>' +
        '</div>' +
      '</div>',
    data: function () { return { dev: dev, cmd: '', lines: [{ text: 'BubbleDefence ' + BD.VERSION + ' – terminál. Napiš help.', cls: 'dim' }], hist: [], hi: -1 }; },
    created: function () {
      var self = this;
      this.onKey = function (ev) {
        if (ev.code !== 'Backquote' || !dev.unlocked || ev.ctrlKey || ev.metaKey || ev.altKey) return;
        var tg = ev.target && ev.target.tagName;
        if ((tg === 'INPUT' || tg === 'TEXTAREA' || tg === 'SELECT') && ev.target !== self.$refs.inp) return;     // v cizím políčku se ` píše normálně
        ev.preventDefault(); dev.toggle();
      };
      window.addEventListener('keydown', this.onKey);
      this.beat = setInterval(function () { if (dev.liveLog && dev.game && !dev.game.gameOver) dev.write('· ' + dev.snapshot()); }, 5000);
    },
    beforeUnmount: function () { window.removeEventListener('keydown', this.onKey); clearInterval(this.beat); },
    watch: {
      'dev.open': function (o) { var self = this; if (o) this.$nextTick(function () { if (self.$refs.inp) self.$refs.inp.focus(); }); else if (document.activeElement && document.activeElement.blur) document.activeElement.blur(); },
    },
    methods: {
      focus: function () { if (this.$refs.inp) this.$refs.inp.focus(); },
      print: function (text, cls) {
        if (text === '\f') { this.lines = []; return; }
        this.lines.push({ text: text, cls: cls || '' }); if (this.lines.length > 300) this.lines.splice(0, this.lines.length - 300);
        var self = this; this.$nextTick(function () { var o = self.$refs.out; if (o) o.scrollTop = o.scrollHeight; });
      },
      onInputKey: function (ev) {
        ev.stopPropagation();                                           // klávesy z terminálu nesmí spouštět zkratky ve hře
        var k = ev.key;
        if (ev.code === 'Backquote' || k === 'Escape') { ev.preventDefault(); dev.open = false; this.cmd = this.cmd.replace(/[`~]/g, ''); return; }
        if (k === 'Enter') {
          var line = this.cmd.trim(); this.cmd = ''; this.hi = -1; if (!line) return;
          this.print('> ' + line, 'cmd'); if (this.hist[this.hist.length - 1] !== line) this.hist.push(line);
          dev.run(line, this.print.bind(this)); return;
        }
        if (k === 'ArrowUp') { ev.preventDefault(); if (!this.hist.length) return; this.hi = this.hi < 0 ? this.hist.length - 1 : Math.max(0, this.hi - 1); this.cmd = this.hist[this.hi]; return; }
        if (k === 'ArrowDown') { ev.preventDefault(); if (this.hi < 0) return; this.hi++; if (this.hi >= this.hist.length) { this.hi = -1; this.cmd = ''; } else this.cmd = this.hist[this.hi]; return; }
        if (k === 'Tab') {
          ev.preventDefault(); var p = this.cmd.trim().toLowerCase(); if (!p || /\s/.test(p)) return;
          var m = dev.names().filter(function (n) { return n.indexOf(p) === 0; });
          if (m.length === 1) this.cmd = m[0] + ' '; else if (m.length > 1) this.print(m.join('  '), 'dim');
        }
      },
    },
  };
})(window.BD);
