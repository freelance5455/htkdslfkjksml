/* Bestiář – kniha s třemi záložkami (Nepřátelé, Věže, Karty a bonusy).
   Vlevo seznam s hledáním a značkou „nové“, vpravo detail: neznámé = rozmazaná silueta, viděno = ostrá silueta a jméno, poznáno = plný popis.
   Otevírá se klávesou B, ikonou otevřené knihy ve hře, na mapě levelů a v menu. Zavírá se Esc, křížkem nebo klikem mimo knihu.
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  var SHOW_UNKNOWN = true;      // neodkryté záznamy ukázat v seznamu jako „???“ (false = vůbec neukazovat)

  /* karta: zaoblený štítek v barvě karty a symbol (atomový hřib / meteor) */
  function cardArt(ctx, id, n) {
    var D = BD.render.draw, col = BD.data.cards.list[id].color, w = n * 0.78, h = n * 0.92, x = (n - w) / 2, y = (n - h) / 2, i;
    var g = ctx.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, D.hexA(col, 0.95)); g.addColorStop(1, D.hexA(col, 0.55));
    D.rr(ctx, x, y, w, h, n * 0.1); ctx.fillStyle = g; ctx.fill(); ctx.lineWidth = Math.max(1.5, n * 0.03); ctx.strokeStyle = 'rgba(255,255,255,.85)'; ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,.92)'; ctx.strokeStyle = 'rgba(255,255,255,.92)';
    var cx = n / 2, cy = n / 2;
    if (id === 'atomic') {                                         // hřib: čepice z kruhů, noha, kouř u země
      ctx.beginPath(); ctx.arc(cx, cy - n * 0.12, n * 0.17, 0, 6.3); ctx.arc(cx - n * 0.15, cy - n * 0.04, n * 0.12, 0, 6.3); ctx.arc(cx + n * 0.15, cy - n * 0.04, n * 0.12, 0, 6.3); ctx.fill();
      ctx.fillRect(cx - n * 0.05, cy - n * 0.02, n * 0.1, n * 0.24);
      ctx.beginPath(); ctx.ellipse(cx, cy + n * 0.25, n * 0.24, n * 0.06, 0, 0, 6.3); ctx.fill();
    } else {                                                       // meteor: hlava a ohon šikmo
      ctx.beginPath(); ctx.arc(cx + n * 0.1, cy + n * 0.08, n * 0.13, 0, 6.3); ctx.fill();
      ctx.lineCap = 'round'; for (i = 0; i < 3; i++) { ctx.lineWidth = n * (0.07 - i * 0.015); ctx.beginPath(); ctx.moveTo(cx + n * 0.1 - n * 0.06 * i, cy + n * 0.08 - n * 0.05 * i); ctx.lineTo(cx - n * (0.2 + i * 0.03), cy - n * (0.22 + i * 0.03)); ctx.stroke(); }
    }
  }

  /* silueta: skutečná kresba bubliny / věže z hry; styl podle stavu (CSS filtr) */
  BD.ui.components.Silhouette = {
    props: { kind: String, id: String, st: Number, size: { type: Number, default: 48 } },
    template: '<canvas class="sil" :class="\'s\' + st" :style="{width: size + \'px\', height: size + \'px\'}"></canvas>',
    mounted: function () { this.paint(); },
    watch: { kind: 'paint', id: 'paint', size: 'paint' },
    methods: {
      paint: function () {
        var cv = this.$el, dpr = Math.min(2, window.devicePixelRatio || 1), n = this.size, D = BD.render.draw;
        cv.width = Math.round(n * dpr); cv.height = Math.round(n * dpr);
        var ctx = cv.getContext('2d'); ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, n, n);
        if (this.kind === 'enemies' && BD.systems.enemies.TYPES[this.id]) {
          var c = n * 0.4 / 0.46;                                   // šéf (r 0,46) zaplní plátno, drobní nepřátelé jsou vidět menší
          D.enemy(ctx, { type: this.id, x: n / 2 / c, y: n / 2 / c, hp: 1, maxhp: 1, slow: 0 }, c);
        } else if (this.kind === 'cards' && BD.data.cards.list[this.id]) {
          cardArt(ctx, this.id, n);
        } else if (this.kind === 'towers' && BD.data.towers[this.id]) {
          var cc = n * 0.4, S = 2 * cc, o = (n - S) / 2 / cc;
          D.tower(ctx, { type: this.id, x: o, y: o, size: 2, level: this.id === 'base' ? 0 : 1, tier: 0, branch: null, boost: 1, angle: -0.7 }, cc);
        }
      },
    },
  };

  BD.ui.components.Bestiary = {
    template:
      '<div class="bs-wrap" v-if="ui.open" @click.self="close">' +
        '<div class="bs-book">' +
          '<button class="bs-x" @click="close" title="Zavřít (Esc)"><ic n="close"></ic></button>' +
          '<div class="bs-tabs">' +
            '<button v-for="t in tabs" :key="t.id" class="bs-tab" :class="[t.cls, {on: ui.tab === t.id}]" @click="setTab(t.id)" :data-tab="t.id">' +
              '<span class="lb">{{ t.label }}</span><ic :n="t.icon"></ic><i class="nw" v-if="news[t.id]"></i>' +
            '</button>' +
          '</div>' +
          '<div class="bs-pages" :class="{turning: turning}">' +
            '<div class="bs-page l">' +
              '<div class="bs-h">{{ tabInfo.label }} <small>{{ found }} / {{ total }}</small></div>' +
              '<input class="in bs-search" v-model="q" placeholder="Hledat…" spellcheck="false">' +
              '<div class="bs-list">' +
                '<button v-for="e in list" :key="e.id" class="bs-row" :class="{on: cur && cur.id === e.id, unk: e.st === 0}" @click="pick(e.id)" :data-id="e.id">' +
                  '<bd-sil :kind="ui.tab" :id="e.id" :st="e.st" :size="36"></bd-sil>' +
                  '<span class="nm">{{ e.st ? e.name : \'???\' }}</span>' +
                  '<span class="rd" v-if="e.unread" title="Nové, ještě nepřečtené">nové</span><ic v-else-if="e.st === 2" n="check" class="ok"></ic>' +
                '</button>' +
                '<div class="bs-empty" v-if="!list.length">{{ ui.tab === \'cards\' ? \'Zatím tu nic není.\' : \'Nic nenalezeno.\' }}</div>' +
              '</div>' +
            '</div>' +
            '<div class="bs-spine"></div>' +
            '<div class="bs-page r">' +
              '<div class="bs-det" v-if="cur">' +
                '<div class="bs-art"><bd-sil :kind="ui.tab" :id="cur.id" :st="cur.st" :size="150"></bd-sil></div>' +
                '<h3 class="bs-name">{{ cur.st ? cur.name : \'???\' }}</h3>' +
                '<template v-if="cur.st === 0"><p class="dim">Zatím neznámé. {{ ui.tab === \'enemies\' ? \'Potkáš to v některém z dalších levelů.\' : \'Zatím jsi to neviděl.\' }}</p></template>' +
                '<template v-else-if="cur.st === 1">' +
                  '<p>{{ cur.blurb }}</p>' +
                  '<p class="dim">{{ ui.tab === \'enemies\' ? \'Dokonči level, ve kterém se objeví, a dozvíš se víc.\' : (cur.hint || \'Postav ji a dozvíš se víc.\') }}</p>' +
                '</template>' +
                '<template v-else>' +
                  '<p>{{ cur.desc }}</p>' +
                  '<div class="bs-stats"><div v-for="s in stats" :key="s[0]"><span>{{ s[0] }}</span><b>{{ s[1] }}</b></div></div>' +
                  '<div class="bs-sec pro"><h4>Výhody</h4><ul><li v-for="x in cur.pros">{{ x }}</li></ul></div>' +
                  '<div class="bs-sec con"><h4>Nevýhody</h4><ul><li v-for="x in cur.cons">{{ x }}</li></ul></div>' +
                  '<div class="bs-sec ctr"><h4>{{ ui.tab === \'enemies\' ? \'Čím ho zničit\' : \'Tip\' }}</h4><p>{{ cur.counter }}</p></div>' +
                  '<div class="bs-sec mrg" v-if="ui.tab === \'towers\' && cur.id !== \'base\'"><h4>Sloučení</h4>' +
                    '<p><span :class="{got: merged >= 1}">XL (2×2) {{ merged >= 1 ? \'✓\' : \'?\' }}</span> · <span :class="{got: merged >= 2}">XXL (4×4) {{ merged >= 2 ? \'✓\' : \'?\' }}</span></p></div>' +
                '</template>' +
              '</div>' +
              '<div class="bs-det empty" v-else><p class="dim">{{ ui.tab === \'cards\' ? \'Karty a bonusy tu přibudou, až je hra bude mít.\' : \'Vyber záznam vlevo.\' }}</p></div>' +
            '</div>' +
            '<div class="bs-leaf" v-if="flipping"></div>' +
          '</div>' +
        '</div>' +
      '</div>' +
      '<div class="bs-toast" v-if="ui.toast && !ui.open">{{ ui.toast }}</div>',

    data: function () { return { ui: BD.bestiary.ui, q: '', flipping: false, turning: false, sel: {} }; },
    computed: {
      tabs: function () { var any = BD.bestiary.anyCard(); return BD.data.bestiary.tabs.filter(function (t) { return t.id !== 'cards' || any; }); },     // záložka Karty se ukáže až po první kartě
      tabInfo: function () { var t = this.ui.tab; return BD.data.bestiary.tabs.filter(function (x) { return x.id === t; })[0]; },
      all: function () {
        var kind = this.ui.tab, B = BD.bestiary, self = this;
        return (BD.data.bestiary[kind] || []).map(function (e) {
          var st = B.state(kind, e.id), o = Object.assign({}, e);
          o.st = st; o.unread = B.unread(kind, e.id); o.name = self.nameOf(kind, e.id); return o;
        });
      },
      list: function () {
        var q = this.q.trim().toLowerCase();
        return this.all.filter(function (e) { if (!e.st) return !q && SHOW_UNKNOWN; return !q || e.name.toLowerCase().indexOf(q) >= 0; });
      },
      found: function () { return this.all.filter(function (e) { return e.st > 0; }).length; },
      total: function () { return this.all.length; },
      cur: function () {
        var id = this.sel[this.ui.tab], l = this.list, f = null;
        l.forEach(function (e) { if (e.id === id) f = e; });
        return f || l[0] || null;
      },
      news: function () { var B = BD.bestiary, o = {}; this.tabs.forEach(function (t) { o[t.id] = B.unreadCount(t.id) > 0; }); return o; },
      merged: function () { return this.cur ? BD.bestiary.mergedTier(this.cur.id) : 0; },
      stats: function () {
        var c = this.cur, o = []; if (!c) return o;
        var f = BD.util.fmt;
        if (this.ui.tab === 'enemies') {
          var B = BD.systems.enemies.TYPES[c.id];
          o.push(['Zdraví', f(B.hp)], ['Rychlost', f(B.speed) + ' věže/s'], ['Odměna', f(B.reward) + ' zlata'], ['Bere životů', String(B.life)]);
          if (B.ghost) o.push(['Zasáhnou ji', 'jen Základní a Proti duchům']);
        } else if (this.ui.tab === 'cards') {
          o.push(['Získáš', 'za šéfa nebo bezchybnou vlnu'], ['Použití', 'kliknutím ve spodní liště']);
        } else if (this.ui.tab === 'towers') {
          var D = BD.data.towers[c.id], role = { shot: 'střela', burst: 'rázová vlna', boost: 'zesilovač' }[D.role] || D.role;
          o.push(['Cena', f(D.cost) + ' zlata'], ['Typ', role]);
          if (D.role === 'boost') o.push(['Zesílení', '×' + f(D.base.boost)]);
          else o.push(['Poškození', f(D.base.dmg)], ['Dosah', f(D.base.range)], ['Rychlost', f(1 / D.base.cd) + '/s']);
        }
        return o;
      },
    },
    created: function () {
      var self = this;
      this.onKey = function (ev) {
        if (ev.ctrlKey || ev.metaKey || ev.altKey) return;
        var tg = ev.target && ev.target.tagName, typing = tg === 'INPUT' || tg === 'TEXTAREA' || tg === 'SELECT';
        if (ev.key === 'Escape' && self.ui.open) { ev.preventDefault(); ev.stopPropagation(); if (typing && self.q) { self.q = ''; return; } BD.bestiary.close(); return; }
        if (typing || (BD.dev && BD.dev.open) || ev.repeat) return;
        if (ev.code === 'KeyB') { ev.preventDefault(); BD.bestiary.toggle(); }
      };
      window.addEventListener('keydown', this.onKey, true);
    },
    beforeUnmount: function () { window.removeEventListener('keydown', this.onKey, true); },
    watch: {
      cur: { handler: function (c) { if (c && this.ui.open) BD.bestiary.read(this.ui.tab, c.id); }, immediate: true },
      'ui.open': function (o) { if (o) { this.q = ''; if (this.cur) BD.bestiary.read(this.ui.tab, this.cur.id); } },
    },
    methods: {
      nameOf: function (kind, id) {
        if (kind === 'enemies') return BD.systems.enemies.TYPES[id].name;
        if (kind === 'towers') return BD.data.towers[id].name;
        if (kind === 'cards') return BD.data.cards.list[id].name;
        return id;
      },
      close: function () { BD.bestiary.close(); },
      pick: function (id) { this.sel[this.ui.tab] = id; BD.bestiary.read(this.ui.tab, id); },
      setTab: function (t) {
        if (t === this.ui.tab || this.flipping) return;
        var self = this; this.flipping = true; this.turning = true;                       // obsah stránek začne mizet hned se začátkem listování
        setTimeout(function () { self.ui.tab = t; self.q = ''; }, 330);                 // výměna obsahu, když je stránka „na hraně“ a obsah je schovaný
        setTimeout(function () { self.turning = false; }, 540);                         // nový obsah se vyfade dřív, než list dosedne
        setTimeout(function () { self.flipping = false; }, 760);
      },
    },
  };
})(window.BD);
