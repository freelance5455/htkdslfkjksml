/* OPERATION: DISCIPLINE — telas Início e Missões (criar, editar, detalhes, concluir, cancelar, reagendar, filtrar, buscar, ordenar, encerrar). */
(function(){'use strict';
var OD=globalThis.OD,UI=OD.UI,U=OD.U,G=OD.G,St=OD.Stats,App=UI.App,esc=UI.esc,L=UI.L,A=UI.A,CH=UI.CH,td=UI.td,run=UI.run;
var fd=UI.fd=function(d){return d&&d.length===10?d.slice(8)+'/'+d.slice(5,7)+'/'+d.slice(0,4):String(d||'')};
var ft=UI.ft=function(t){if(!t)return'data desconhecida';var d=new Date(t),p=function(n){return String(n).padStart(2,'0')};return fd(U.iso(d))+' '+p(d.getHours())+':'+p(d.getMinutes())};
var catName=UI.catName=function(id){var c=App.S.c.find(function(x){return x.id===id});return c?c.name:''};
var catOpts=function(){return[['','Nenhuma']].concat(App.S.c.map(function(c){return[c.id,c.name]}))};

/* ---------- Início ---------- */
UI.views.home=function(){var S=App.S,C=App.C,d=td(),ms=C.on(d),c=C.cnt(ms),dn=c.filter(function(m){return m.s==='C'}).length,x=C.total(),Lv=G.lvl(x),nx=G.need(Lv),st=C.streak(d),mn=ms.find(function(m){return m.main&&m.s!=='X'&&m.s!=='R'}),pd=C.pendingDays(d),ds=C.dayState(d),open=ms.filter(OD.Rules.open).length,ch=C.challenges(d);
 var name=S.cfg.name?', '+esc(S.cfg.name):'';
 return'<h1>Hoje · '+fd(d)+'</h1><p class="mu sub">Olá'+name+'. Estado do dia: <b>'+esc(L.RL[ds])+'</b></p>'
 +(pd.length?'<div class="c alert"><b>'+pd.length+' dia(s) anterior(es) aguardando revisão</b><div class="mu">Nenhum foi encerrado automaticamente.</div><button type="button" class="sm" data-a="review">Revisar</button></div>':'')
 +'<div class="c"><div class="row"><span class="pill lm">'+esc(G.rank(Lv))+'</span><span class="pill">Nível '+Lv+'</span></div><div class="big">'+x.toLocaleString('pt-BR')+' XP</div>'
 +(Lv<100?UI.pg(x-G.thr(Lv),nx)+'<div class="mu">'+(x-G.thr(Lv))+'/'+nx+' XP neste nível · faltam '+(nx-(x-G.thr(Lv)))+' XP para o nível '+(Lv+1)+'</div>':'<div class="mu">Nível máximo alcançado</div>')+'</div>'
 +'<div class="c"><div class="h">PROGRESSO DO DIA</div>'+(App.S.r[d]?'<p>Dia de descanso: missões não são contadas.</p>':UI.pg(dn,c.length)+'<div class="tiles"><div class="t"><b>'+dn+'</b>Concluídas</div><div class="t"><b>'+open+'</b>Abertas</div><div class="t"><b>'+c.length+'</b>Total</div></div>')+(S.d[d]?'<p class="mu">Dia encerrado: '+esc(L.RL[S.d[d]])+'</p>':'')+'</div>'
 +'<div class="c"><div class="h">MISSÃO PRINCIPAL</div>'+(mn?'<b>★ '+esc(mn.title)+'</b> <span class="pill">'+L.ST[mn.s]+'</span>':'<span class="mu">Nenhuma definida para hoje.</span>')+'</div>'
 +'<div class="tiles"><div class="t"><b>'+st[0]+' d</b>Sequência</div><div class="t"><b>'+st[1]+' d</b>Melhor</div><div class="t"><b>'+Object.keys(S.ua).length+'/'+G.ACH.length+'</b>Conquistas</div></div>'
 +'<div class="h sec">DESAFIOS DA SEMANA (+100 XP cada)</div>'+ch.map(function(k){return'<div class="c"><div class="row"><span class="pill">'+esc(k.cat)+'</span><b class="grow">'+esc(k.title)+'</b>'+(k.paid?'<span class="pill lm">+100 XP ✓</span>':'')+'</div>'+UI.pg(Math.min(k.value,k.target),k.target)+'<div class="mu">'+esc(k.desc)+' · '+Math.min(k.value,k.target)+'/'+k.target+'</div></div>'}).join('')
 +'<button type="button" class="p wide" data-a="new" data-d="'+d+'">+ Nova missão para hoje</button>'};

/* ---------- Missões ---------- */
function pills(m){return'<div class="row pills"><span class="pill st'+m.s+'">'+L.ST[m.s]+'</span><span class="pill">'+L.DL[m.df]+'</span><span class="pill">Prio. '+L.PL[m.pr].toLowerCase()+'</span>'+(m.cat&&catName(m.cat)?'<span class="pill">'+esc(catName(m.cat))+'</span>':'')+(m.due?'<span class="pill">prazo '+fd(m.due)+'</span>':'')+'</div>'}
function card(m,showDate){var cl=!!App.S.d[m.date],op=OD.Rules.open(m);
 return'<article class="c mc"><div class="row"><button type="button" class="lnk grow" data-a="detail" data-id="'+m.id+'">'+(m.main?'★ ':'')+(showDate?'<span class="mu">'+fd(m.date)+' · </span>':'')+(m.time?esc(m.time)+' · ':'')+esc(m.title)+'</button><span class="xp">'+m.xp+' XP</span></div>'+pills(m)+(m.reason?'<div class="mu">'+esc(m.reason)+'</div>':'')
 +(op&&!cl?'<div class="row acts"><button type="button" class="p sm" data-a="complete" data-id="'+m.id+'">Concluir</button>'+(m.s==='P'?'<button type="button" class="sm" data-a="start" data-id="'+m.id+'">Iniciar</button>':'')+'<button type="button" class="sm" data-a="edit" data-id="'+m.id+'">Editar</button><button type="button" class="sm" data-a="main" data-id="'+m.id+'">'+(m.main?'Tirar principal':'Principal')+'</button><button type="button" class="sm" data-a="resch" data-id="'+m.id+'">Reagendar</button><button type="button" class="d sm" data-a="cancel" data-id="'+m.id+'">Cancelar</button></div>':'')+'</article>'}
var LIM=100;
function listHtml(){var q=App.q,l=St.query(App.S,{date:App.cur,all:q.all,text:q.text,s:q.s,cat:q.cat,df:q.df,pr:q.pr,sort:q.sort||undefined}),n=l.length;
 return(q.all||q.text||q.s||q.cat!==''||q.df||q.pr?'<div class="mu" role="status">'+n+' resultado(s)'+(q.all?' em todas as datas':' neste dia')+(n>LIM?' · mostrando '+LIM:'')+'</div>':'')
  +(l.slice(0,LIM).map(function(m){return card(m,q.all)}).join('')||'<div class="empty"><b>Nenhuma missão '+(q.all||q.text||q.s||q.cat||q.df||q.pr?'encontrada':'neste dia')+'</b><span class="mu">'+(q.all||q.text||q.s||q.cat||q.df||q.pr?'Ajuste a busca ou limpe os filtros.':'Planeje suas missões manualmente: toque em “Nova missão”.')+'</span></div>')}
UI.views.missions=function(){var S=App.S,C=App.C,cur=App.cur,cl=S.d[cur],ds=C.dayState(cur),q=App.q,ms=C.on(cur),pend=ms.filter(OD.Rules.open).length,fa=!!(q.s||q.cat!==''||q.df||q.pr||q.all||q.sort);
 return'<h1>Missões</h1><div class="row dn"><button type="button" aria-label="Dia anterior" data-a="dprev">‹</button><input type="date" aria-label="Data" value="'+cur+'" data-c="cdate"><button type="button" aria-label="Próximo dia" data-a="dnext">›</button>'+(cur!==td()?'<button type="button" class="sm" data-a="dtoday">Hoje</button>':'')+'</div>'
 +'<div class="c"><div class="row"><span class="pill d'+ds+'">'+esc(L.RL[ds])+'</span>'+(cl?'<span class="mu grow">Dia encerrado</span><button type="button" class="sm" data-a="reopen" data-d="'+cur+'">Reabrir</button>':'')+'</div>'
 +(cl?'':'<div class="row" style="margin-top:8px"><button type="button" class="p" data-a="new" data-d="'+cur+'">+ Nova missão</button><button type="button" data-a="rest" data-d="'+cur+'" data-v="'+(S.r[cur]?0:1)+'">'+(S.r[cur]?'Remover descanso':'Marcar descanso')+'</button>'+((ms.length||S.r[cur])&&cur<=td()?'<button type="button" data-a="closeday" data-d="'+cur+'">Encerrar dia</button>':'')+'</div>'
  +(S.r[cur]?'<div class="mu">Dia de descanso: não há missões a cumprir e ele não conta como falha.</div>':pend&&cur<td()?'<div class="mu">'+pend+' aberta(s) neste dia passado — nada foi encerrado automaticamente.</div>':''))+'</div>'
 +'<div class="c flt"><label class="fl"><span>Buscar</span><input type="search" name="q" data-c="qtext" value="'+esc(q.text)+'" placeholder="Título, descrição ou justificativa" maxlength="120" autocomplete="off"></label>'
 +'<details'+(fa||App.fo?' open':'')+'><summary>Filtros e ordenação</summary><div class="grid2">'
 +UI.sel('fs','Status',[['','Todos'],['open','Abertas'],['P','Pendente'],['A','Em andamento'],['C','Concluída'],['F','Falhou'],['X','Cancelada'],['R','Reagendada']],q.s,'data-c="fs"')
 +UI.sel('fc','Categoria',[['','Todas'],[0,'Sem categoria']].concat(S.c.map(function(c){return[c.id,c.name]})),q.cat,'data-c="fc"')
 +UI.sel('fdf','Dificuldade',[['','Todas']].concat(Object.keys(L.DL).map(function(k){return[k,L.DL[k]]})),q.df,'data-c="fdf"')
 +UI.sel('fp','Prioridade',[['','Todas'],['H','Alta'],['M','Média'],['L','Baixa']],q.pr,'data-c="fp"')
 +UI.sel('fo','Ordenar por',Object.keys(L.SORT).map(function(k){return[k,L.SORT[k]]}),q.sort||S.cfg.sort,'data-c="fo"')+'</div>'
 +'<label class="chk"><input type="checkbox" name="fall" data-c="fall"'+(q.all?' checked':'')+'> Buscar em todas as datas</label><button type="button" class="sm" data-a="fclear">Limpar filtros</button></details></div>'
 +'<div id="mlist">'+listHtml()+'</div>'};
function relist(){var e=document.getElementById('mlist');if(e)e.innerHTML=listHtml()}
CH.qtext={ev:'input',fn:function(el){App.q.text=el.value;relist()}};
CH.fs={fn:function(el){App.q.s=el.value;App.fo=1;UI.draw()}};CH.fc={fn:function(el){App.q.cat=el.value;App.fo=1;UI.draw()}};CH.fdf={fn:function(el){App.q.df=el.value;App.fo=1;UI.draw()}};CH.fp={fn:function(el){App.q.pr=el.value;App.fo=1;UI.draw()}};CH.fo={fn:function(el){App.q.sort=el.value;App.fo=1;UI.draw()}};CH.fall={fn:function(el){App.q.all=el.checked;App.fo=1;UI.draw()}};
CH.cdate={fn:function(el){App.cur=UI.sd(el.value,App.cur);UI.draw()}};
A.fclear=function(){App.q={text:'',s:'',cat:'',pr:'',df:'',all:false,sort:''};UI.draw()};
A.dprev=function(){App.cur=U.add(App.cur,-1);UI.draw()};A.dnext=function(){App.cur=U.add(App.cur,1);UI.draw()};A.dtoday=function(){App.cur=td();UI.draw()};

/* ---------- ações ---------- */
var mid=function(el){return+el.dataset.id};
A.complete=function(el){var id=mid(el),m=App.C.get(id);run(function(c){c.complete(id)},'Missão concluída · +'+m.xp+' XP')};
A.start=function(el){var id=mid(el);run(function(c){c.start(id)},'Missão em andamento')};
A.main=function(el){var id=mid(el);run(function(c){c.toggleMain(id)})};
A.rest=function(el){var d=el.dataset.d,v=el.dataset.v==='1';run(function(c){c.setRest(d,v)},v?'Dia marcado como descanso':'Descanso removido')};
A.reopen=function(el){var d=el.dataset.d;UI.confirm('Reabrir o dia '+fd(d)+'? O bônus de dia perfeito (e o desafio de disciplina, se dependerem dele) serão estornados e as missões “Falhou” criadas pelo encerramento voltam a pendentes.',function(){run(function(c){c.reopen(d)},'Dia reaberto')})};
A.closeday=function(el){closeD(el.dataset.d)};
A.new=function(el){mDlg(0,el.dataset.d)};A.edit=function(el){mDlg(mid(el))};
A.cancel=function(el){var id=mid(el);UI.modal('Cancelar missão','<p class="mu">Com justificativa a missão sai do cálculo do dia; sem justificativa ela conta como falha nas estatísticas. Cancelar nunca concede XP.</p>'+UI.inp('r','Justificativa (opcional)','text','','maxlength="200"'),[['Voltar'],['Cancelar missão',function(o){return run(function(c){c.cancel(id,UI.F(o,'r').value)},'Missão cancelada')?undefined:false},'d']])};
A.resch=function(el){var id=mid(el),m=App.C.get(id),t=td(),def=U.add(m.date,1)<t?t:U.add(m.date,1);
 UI.modal('Reagendar','<p class="mu">Cria uma nova missão ligada à original (a original fica “Reagendada” e não gera XP). Prazo: '+(m.due?fd(m.due):'sem prazo')+'. Se já houver outra principal na nova data, a nova missão não será principal.</p>'+UI.inp('t','Nova data','date',def,'min="'+t+'"')+UI.inp('tm','Horário (opcional)','time',m.time),
 [['Voltar'],['Reagendar',function(o){var r;return run(function(c){r=c.resch(id,UI.F(o,'t').value,UI.F(o,'tm').value)},'Missão reagendada')?(r.mainKept||!m.main?undefined:UI.toast('Reagendada sem status de principal (já existe outra na data).',1)):false},'p']])};
function mDlg(id,date){var m=id?App.C.get(id):{date:date||App.cur,time:'',title:'',desc:'',df:'M',pr:'M',cat:null,main:false,due:''};
 UI.modal(id?'Editar missão':'Nova missão',UI.inp('title','Título','text',m.title,'maxlength="120" required autocomplete="off"')+UI.field('Descrição (opcional)','<textarea name="desc" maxlength="500" rows="3" class="sm">'+esc(m.desc)+'</textarea>')
  +'<div class="grid2">'+UI.inp('date','Data','date',m.date)+UI.inp('time','Horário (opcional)','time',m.time)+UI.inp('due','Prazo (opcional)','date',m.due)
  +UI.sel('df','Dificuldade',Object.keys(L.DL).map(function(k){return[k,L.DL[k]+' ('+G.B[k]+' XP)']}),m.df)+UI.sel('pr','Prioridade',[['H','Alta'],['M','Média'],['L','Baixa']],m.pr)+UI.sel('cat','Categoria',catOpts(),m.cat||'')+'</div>'
  +'<label class="chk"><input name="main" type="checkbox"'+(m.main?' checked':'')+'> Missão principal (+30 XP; uma por dia)</label>',
  [['Cancelar'],['Salvar',function(o){var v={title:UI.F(o,'title').value,desc:UI.F(o,'desc').value,date:UI.F(o,'date').value,time:UI.F(o,'time').value,due:UI.F(o,'due').value,df:UI.F(o,'df').value,pr:UI.F(o,'pr').value,cat:+UI.F(o,'cat').value||null,main:UI.F(o,'main').checked};
   return run(function(c){id?c.editM(id,v):c.addM(v)},id?'Missão atualizada':'Missão criada')?undefined:false},'p']])}
function closeD(d){var p=App.C.on(d).filter(OD.Rules.open).length;UI.confirm(p?p+' missão(ões) aberta(s) em '+fd(d)+' serão marcadas como FALHOU. Você pode reabrir o dia depois. Prefira concluir, reagendar ou cancelar antes. Continuar?':'Encerrar o dia '+fd(d)+'? Bônus e resultado são definidos agora; o dia pode ser reaberto.',function(){run(function(c){c.close(d,td(),{fail:p>0})},'Dia encerrado')},'Encerrar')}
A.review=function(){var pd=App.C.pendingDays(td());UI.modal('Revisão de dias anteriores','<p class="mu">Nada é encerrado automaticamente. Abra o dia para concluir, reagendar ou cancelar — ou encerre de forma explícita (pendentes viram “Falhou”; o dia pode ser reaberto).</p>'
 +(pd.length?pd.slice(-60).reverse().map(function(x){return'<div class="c"><b>'+fd(x.d)+'</b> <span class="mu">'+(x.rest?'descanso':x.pend+' aberta(s) · '+x.n+' missão(ões)')+'</span><div class="row" style="margin-top:6px"><button type="button" class="sm" data-a="rv" data-d="'+x.d+'">Abrir</button><button type="button" class="sm" data-a="rvclose" data-d="'+x.d+'">Encerrar</button></div></div>'}).join(''):'<p>Nenhum dia pendente.</p>'),[['Fechar']])};
A.rv=function(el){UI.closeAll();App.cur=el.dataset.d;UI.go('missions')};
A.rvclose=function(el){var d=el.dataset.d;UI.closeAll();closeD(d)};
A.detail=function(el){detail(mid(el))};
function detail(id){var m=App.C.get(id),S=App.S,rows=[['Data',fd(m.date)],['Horário',m.time||'—'],['Prazo',m.due?fd(m.due):'—'],['Categoria',m.cat?catName(m.cat):'—'],['Dificuldade',L.DL[m.df]],['Prioridade',L.PL[m.pr]],['Principal',m.main?'Sim (+30 XP)':'Não'],['XP',m.xp+(m.s==='C'?' (concedido)':m.s==='X'||m.s==='R'||m.s==='F'?' (não concedido)':' (ao concluir)')],['Criada em',ft(m.created)]],
 led=S.l.filter(function(x){return x.r==='MC:'+m.id}),orig=m.from!=null?S.m.find(function(x){return x.id===m.from}):null,dest=m.to!=null?S.m.find(function(x){return x.id===m.to}):null;
 var op=OD.Rules.open(m)&&!S.d[m.date];
 UI.modal(m.title,pills(m)+(m.desc?'<p class="desc">'+esc(m.desc)+'</p>':'')+(m.reason?'<p class="mu">'+esc(m.reason)+'</p>':'')+'<dl class="kv">'+rows.map(function(r){return'<dt>'+r[0]+'</dt><dd>'+esc(r[1])+'</dd>'}).join('')+'</dl>'
  +(orig?'<p><button type="button" class="sm" data-a="goto" data-d="'+orig.date+'">Ver missão original ('+fd(orig.date)+')</button></p>':'')+(dest?'<p><button type="button" class="sm" data-a="goto" data-d="'+dest.date+'">Ver missão reagendada ('+fd(dest.date)+')</button></p>':'')
  +(led.length?'<div class="h">XP LANÇADO</div>'+led.map(function(x){return'<div class="mu">+'+x.a+' XP · '+esc(x.d)+' · '+ft(x.t)+'</div>'}).join(''):'')
  +'<div class="h" style="margin-top:10px">HISTÓRICO DE ALTERAÇÕES</div><ol class="log">'+m.log.slice().reverse().map(function(l){return'<li><b>'+esc(L.EV[l.e]||l.e)+'</b> <span class="mu">'+ft(l.t)+'</span><div class="mu">'+esc(l.d)+'</div></li>'}).join('')+(m.log.length?'':'<li class="mu">Sem registros (missão anterior à versão 3).</li>')+'</ol>',
  [['Fechar']].concat(op?[['Editar',function(){setTimeout(function(){mDlg(id)},0)},'p']]:[]))}
A.goto=function(el){UI.closeAll();App.cur=el.dataset.d;UI.go('missions')};
UI.mDlg=mDlg;UI.closeD=closeD;
})();
