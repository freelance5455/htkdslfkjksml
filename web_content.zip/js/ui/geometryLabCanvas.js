// Geometry lab canvas — tap points on a grid to build shapes; measurements update live.
// Fixed: reliable sizing after DOM mount (ResizeObserver + explicit defaults) so the
// lab never renders as a blank white box on first open.
const STEP = 24;
export const MODES = ["Point", "Line Segment", "Triangle", "Square", "Rectangle", "Parallelogram", "Pentagon", "Hexagon", "Octagon", "Circle", "Angle", "Coordinate Plane"];
const LIMITS = { Point: 1, "Line Segment": 2, Triangle: 3, Square: 2, Rectangle: 2, Parallelogram: 3, Pentagon: 5, Hexagon: 6, Octagon: 8, Circle: 2, Angle: 3, "Coordinate Plane": 999 };

function dist(a, b) { return Math.hypot(a.x - b.x, a.y - b.y); }

export class GeometryLabCanvas {
  constructor(canvas) {
    this.canvas = canvas;
    this.mode = "Triangle";
    this.points = [];
    this.showMeasurements = true;
    this.w = 320;
    this.h = 340;
    this._ro = null;

    // Visible empty state so a failed layout never looks like a "blank screen"
    canvas.style.display = "block";
    canvas.style.maxWidth = "100%";
    canvas.style.border = "1px solid #ddd";
    canvas.style.borderRadius = "8px";
    canvas.style.background = "#fff";
    canvas.style.touchAction = "none";

    canvas.addEventListener("pointerdown", (e) => this._onTap(e));
    this._resize();
    this.redraw();
  }

  /** Call after the canvas is in the document so parent width is real. */
  mount() {
    this._resize();
    this.redraw();
    if (typeof ResizeObserver !== "undefined" && this.canvas.parentElement) {
      this._ro = new ResizeObserver(() => {
        this._resize();
        this.redraw();
      });
      this._ro.observe(this.canvas.parentElement);
    } else {
      this._onWinResize = () => { this._resize(); this.redraw(); };
      window.addEventListener("resize", this._onWinResize);
    }
  }

  unmount() {
    if (this._ro) { this._ro.disconnect(); this._ro = null; }
    if (this._onWinResize) window.removeEventListener("resize", this._onWinResize);
  }

  _resize() {
    let w = 320;
    const parent = this.canvas.parentElement;
    if (parent) {
      const cw = parent.clientWidth;
      if (cw && cw > 40) w = cw;
    }
    this.w = Math.max(260, Math.min(w, 520));
    this.h = 340;
  }

  clear() { this.points = []; this.redraw(); }

  _onTap(e) {
    e.preventDefault();
    const rect = this.canvas.getBoundingClientRect();
    const scaleX = this.w / (rect.width || this.w);
    const scaleY = this.h / (rect.height || this.h);
    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;
    this.points.push({ x, y });
    const limit = LIMITS[this.mode] ?? 3;
    if (this.points.length > limit) this.points.shift();
    this.redraw();
  }

  redraw() {
    const dpr = window.devicePixelRatio || 1;
    const w = this.w || 320;
    const h = this.h || 340;
    this.canvas.width = Math.round(w * dpr);
    this.canvas.height = Math.round(h * dpr);
    this.canvas.style.width = w + "px";
    this.canvas.style.height = h + "px";
    const ctx = this.canvas.getContext("2d");
    if (!ctx) return;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    // Background
    ctx.fillStyle = "#fafafa";
    ctx.fillRect(0, 0, w, h);

    // Grid
    ctx.strokeStyle = "#e6e6e6";
    ctx.lineWidth = 1;
    for (let gx = 0; gx <= w; gx += STEP) {
      ctx.beginPath(); ctx.moveTo(gx, 0); ctx.lineTo(gx, h); ctx.stroke();
    }
    for (let gy = 0; gy <= h; gy += STEP) {
      ctx.beginPath(); ctx.moveTo(0, gy); ctx.lineTo(w, gy); ctx.stroke();
    }

    // Hint when empty (except coordinate plane which still shows axes)
    if (!this.points.length && this.mode !== "Coordinate Plane") {
      ctx.fillStyle = "#888";
      ctx.font = "14px sans-serif";
      ctx.textAlign = "center";
      ctx.fillText("Tap on the grid to place points", w / 2, h / 2);
      ctx.textAlign = "left";
    }

    ctx.strokeStyle = "#3157D5";
    ctx.lineWidth = 3;
    ctx.font = "bold 12px sans-serif";
    ctx.fillStyle = "#3157D5";
    const pts = this.points;

    if (this.mode === "Point" && pts.length >= 1) {
      const p = pts[pts.length - 1];
      ctx.beginPath(); ctx.arc(p.x, p.y, 5, 0, Math.PI * 2); ctx.fill();
    } else if (this.mode === "Line Segment" && pts.length >= 2) {
      const [a, b] = pts.slice(-2);
      ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
      pts.slice(-2).forEach((p) => { ctx.beginPath(); ctx.arc(p.x, p.y, 4, 0, Math.PI * 2); ctx.fill(); });
      if (this.showMeasurements) ctx.fillText(`${(dist(a, b) / STEP).toFixed(1)} u`, (a.x + b.x) / 2, (a.y + b.y) / 2);
    } else if (this.mode === "Triangle" && pts.length >= 3) {
      const [a, b, c] = pts.slice(-3);
      ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.lineTo(c.x, c.y); ctx.closePath(); ctx.stroke();
      [a, b, c].forEach((p) => { ctx.beginPath(); ctx.arc(p.x, p.y, 4, 0, Math.PI * 2); ctx.fill(); });
      if (this.showMeasurements) {
        [[a, b], [b, c], [c, a]].forEach(([s1, s2]) =>
          ctx.fillText(`${(dist(s1, s2) / STEP).toFixed(1)}u`, (s1.x + s2.x) / 2, (s1.y + s2.y) / 2));
      }
    } else if (this.mode === "Rectangle" && pts.length >= 2) {
      const [a, b] = pts.slice(-2);
      const x = Math.min(a.x, b.x), y = Math.min(a.y, b.y);
      const rw = Math.abs(a.x - b.x), rh = Math.abs(a.y - b.y);
      ctx.strokeRect(x, y, rw, rh);
      if (this.showMeasurements) {
        ctx.fillText(`w=${(rw / STEP).toFixed(1)}u`, x + rw / 2, y - 6);
        ctx.fillText(`h=${(rh / STEP).toFixed(1)}u`, x + 4, y + rh / 2);
      }
    } else if (this.mode === "Circle" && pts.length >= 2) {
      const [a, b] = pts.slice(-2);
      const r = dist(a, b);
      ctx.beginPath(); ctx.arc(a.x, a.y, r, 0, Math.PI * 2); ctx.stroke();
      ctx.beginPath(); ctx.arc(a.x, a.y, 4, 0, Math.PI * 2); ctx.fill();
      if (this.showMeasurements) ctx.fillText(`r=${(r / STEP).toFixed(1)}u`, a.x + 6, a.y - 6);
    } else if (this.mode === "Angle" && pts.length >= 3) {
      const [vertex, p1, p2] = pts.slice(-3);
      ctx.beginPath(); ctx.moveTo(vertex.x, vertex.y); ctx.lineTo(p1.x, p1.y); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(vertex.x, vertex.y); ctx.lineTo(p2.x, p2.y); ctx.stroke();
      [vertex, p1, p2].forEach((p) => { ctx.beginPath(); ctx.arc(p.x, p.y, 4, 0, Math.PI * 2); ctx.fill(); });
      const v1 = Math.atan2(p1.y - vertex.y, p1.x - vertex.x);
      const v2 = Math.atan2(p2.y - vertex.y, p2.x - vertex.x);
      let deg = Math.abs((v2 - v1) * 180 / Math.PI);
      if (deg > 180) deg = 360 - deg;
      ctx.fillText(`${deg.toFixed(0)}°`, vertex.x + 10, vertex.y + 10);
    
    } else if (["Pentagon", "Hexagon", "Octagon", "Square", "Parallelogram"].includes(this.mode) && pts.length >= 1) {
      // Draw points; if enough points, connect as polygon
      const need = LIMITS[this.mode] || 5;
      if (pts.length >= need) {
        const use = pts.slice(-need);
        ctx.beginPath();
        ctx.moveTo(use[0].x, use[0].y);
        for (let i = 1; i < use.length; i++) ctx.lineTo(use[i].x, use[i].y);
        ctx.closePath(); ctx.stroke();
        if (this.showMeasurements) {
          ctx.fillText(this.mode + " · " + need + " sides", 12, 20);
        }
      }
} else if (this.mode === "Coordinate Plane") {
      const cx = w / 2, cy = h / 2;
      ctx.strokeStyle = "#333"; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(0, cy); ctx.lineTo(w, cy); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(cx, 0); ctx.lineTo(cx, h); ctx.stroke();
      ctx.fillStyle = "#666"; ctx.font = "11px sans-serif";
      ctx.fillText("x", w - 14, cy - 8);
      ctx.fillText("y", cx + 8, 14);
      ctx.fillStyle = "#3157D5"; ctx.font = "bold 12px sans-serif";
      pts.forEach((p) => {
        ctx.beginPath(); ctx.arc(p.x, p.y, 4, 0, Math.PI * 2); ctx.fill();
        const gx = Math.round((p.x - cx) / STEP), gy = Math.round((cy - p.y) / STEP);
        ctx.fillText(`(${gx},${gy})`, p.x + 6, p.y - 6);
      });
      if (!pts.length) {
        ctx.fillStyle = "#888"; ctx.font = "14px sans-serif"; ctx.textAlign = "center";
        ctx.fillText("Tap to plot points on the plane", w / 2, h / 2 + 24);
        ctx.textAlign = "left";
      }
    }

    // Always draw placed points for partial shapes
    if (pts.length && this.mode !== "Coordinate Plane" && this.mode !== "Point") {
      ctx.fillStyle = "#3157D5";
      pts.forEach((p) => { ctx.beginPath(); ctx.arc(p.x, p.y, 4, 0, Math.PI * 2); ctx.fill(); });
    }
  }
}
