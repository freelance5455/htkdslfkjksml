// Canvas "image builder" — colourful lesson strips, big numbers, 3D solids (perspective).
// No external images; everything is drawn so it works offline.

function setup(canvas, w, h) {
  const dpr = window.devicePixelRatio || 1;
  canvas.width = Math.round(w * dpr);
  canvas.height = Math.round(h * dpr);
  canvas.style.width = w + "px";
  canvas.style.height = h + "px";
  const ctx = canvas.getContext("2d");
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  return ctx;
}

const COLORS = {
  bg: "#FFF5FB",
  pink: "#F472B6",
  purple: "#A78BFA",
  blue: "#60A5FA",
  green: "#34D399",
  yellow: "#FBBF24",
  orange: "#FB923C",
  text: "#1F2937",
  muted: "#6B7280",
  white: "#FFFFFF",
  card: "#FFFFFF"
};

/** Big colourful number / equation strip for lessons. */
export function drawLessonBanner(canvas, { title = "", steps = [], bigText = "", w = 340, h = 220 } = {}) {
  const ctx = setup(canvas, w, h);
  // candy gradient bg
  const g = ctx.createLinearGradient(0, 0, w, h);
  g.addColorStop(0, "#FCE7F3");
  g.addColorStop(1, "#EDE9FE");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);

  // decorative dots
  [COLORS.pink, COLORS.purple, COLORS.blue, COLORS.green].forEach((c, i) => {
    ctx.fillStyle = c;
    ctx.globalAlpha = 0.35;
    ctx.beginPath();
    ctx.arc(30 + i * 80, 24, 10, 0, Math.PI * 2);
    ctx.fill();
  });
  ctx.globalAlpha = 1;

  if (title) {
    ctx.fillStyle = COLORS.text;
    ctx.font = "bold 16px system-ui,sans-serif";
    ctx.fillText(title, 16, 40);
  }

  if (bigText) {
    ctx.fillStyle = COLORS.purple;
    ctx.font = "bold 42px system-ui,sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(bigText, w / 2, title ? 100 : 80);
    ctx.textAlign = "left";
  }

  let y = bigText ? 130 : 60;
  steps.forEach((s, i) => {
    const boxY = y + i * 28;
    ctx.fillStyle = COLORS.white;
    roundRect(ctx, 16, boxY, w - 32, 24, 8);
    ctx.fill();
    ctx.fillStyle = [COLORS.pink, COLORS.blue, COLORS.green, COLORS.orange][i % 4];
    ctx.beginPath();
    ctx.arc(30, boxY + 12, 8, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = COLORS.white;
    ctx.font = "bold 11px system-ui";
    ctx.textAlign = "center";
    ctx.fillText(String(i + 1), 30, boxY + 16);
    ctx.textAlign = "left";
    ctx.fillStyle = COLORS.text;
    ctx.font = "13px system-ui";
    ctx.fillText(String(s).slice(0, 42), 46, boxY + 16);
  });
}

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

/** Fraction bar visual */
export function drawFractionBar(canvas, num, den, w = 320, h = 120) {
  const ctx = setup(canvas, w, h);
  ctx.fillStyle = COLORS.bg;
  ctx.fillRect(0, 0, w, h);
  const pad = 20, barH = 40, barW = w - pad * 2;
  const y = 40;
  const slice = barW / den;
  for (let i = 0; i < den; i++) {
    ctx.fillStyle = i < num ? COLORS.pink : COLORS.white;
    ctx.strokeStyle = COLORS.purple;
    ctx.lineWidth = 2;
    ctx.fillRect(pad + i * slice, y, slice - 2, barH);
    ctx.strokeRect(pad + i * slice, y, slice - 2, barH);
  }
  ctx.fillStyle = COLORS.text;
  ctx.font = "bold 20px system-ui";
  ctx.textAlign = "center";
  ctx.fillText(`${num} / ${den}`, w / 2, y + barH + 28);
  ctx.textAlign = "left";
}

/** Place-value blocks style banner */
export function drawPlaceValue(canvas, number, w = 340, h = 140) {
  const ctx = setup(canvas, w, h);
  ctx.fillStyle = "#EEF2FF";
  ctx.fillRect(0, 0, w, h);
  const s = String(number);
  const labels = ["U", "T", "H", "Th", "TTh", "HTh"];
  const cols = ["#F472B6", "#A78BFA", "#60A5FA", "#34D399", "#FBBF24", "#FB923C"];
  const boxW = Math.min(52, (w - 24) / s.length - 6);
  const startX = (w - s.length * (boxW + 6)) / 2;
  for (let i = 0; i < s.length; i++) {
    const place = s.length - 1 - i;
    const x = startX + i * (boxW + 6);
    ctx.fillStyle = cols[place % cols.length];
    roundRect(ctx, x, 30, boxW, 56, 10);
    ctx.fill();
    ctx.fillStyle = "#fff";
    ctx.font = "bold 24px system-ui";
    ctx.textAlign = "center";
    ctx.fillText(s[i], x + boxW / 2, 66);
    ctx.font = "11px system-ui";
    ctx.fillText(labels[place] || "", x + boxW / 2, 100);
  }
  ctx.textAlign = "left";
}

/** Simple 3D solids with 2D perspective (isometric-ish). */
export function drawSolid3D(canvas, kind = "cube", w = 280, h = 220) {
  const ctx = setup(canvas, w, h);
  ctx.fillStyle = "#F8FAFC";
  ctx.fillRect(0, 0, w, h);
  const cx = w / 2, cy = h / 2 + 10;

  ctx.lineWidth = 2;
  ctx.strokeStyle = "#4F46E5";

  if (kind === "cube" || kind === "rectangular prism") {
    const dx = kind === "cube" ? 48 : 68, dy = 48, dz = 32;
    // top (back) face
    ctx.fillStyle = "#C4B5FD";
    pathPrism(ctx, cx, cy, dx, dy, dz, "back");
    ctx.fill(); ctx.stroke();
    // right face
    ctx.fillStyle = "#8B5CF6";
    pathPrism(ctx, cx, cy, dx, dy, dz, "side");
    ctx.fill(); ctx.stroke();
    // front face
    ctx.fillStyle = "#DDD6FE";
    pathPrism(ctx, cx, cy, dx, dy, dz, "front");
    ctx.fill(); ctx.stroke();
    // face labels (visible faces)
    ctx.fillStyle = "#4C1D95";
    ctx.font = "bold 11px system-ui";
    ctx.textAlign = "center";
    ctx.fillText("front", cx, cy + 6);
    ctx.fillText("side", cx + dx + dz / 2, cy);
    ctx.fillText("top", cx + 6, cy - dy - 8);
    ctx.textAlign = "left";
  } else if (kind === "cylinder") {
    const rx = 50, ry = 18, top = cy - 40, bot = cy + 40;
    ctx.fillStyle = "#60A5FA";
    ctx.beginPath();
    ctx.moveTo(cx - rx, top);
    ctx.lineTo(cx - rx, bot);
    ctx.ellipse(cx, bot, rx, ry, 0, Math.PI, 0, true);
    ctx.lineTo(cx + rx, top);
    ctx.ellipse(cx, top, rx, ry, 0, 0, Math.PI, true);
    ctx.fill(); ctx.stroke();
    ctx.fillStyle = "#BFDBFE";
    ctx.beginPath();
    ctx.ellipse(cx, top, rx, ry, 0, 0, Math.PI * 2);
    ctx.fill(); ctx.stroke();
    ctx.beginPath();
    ctx.ellipse(cx, bot, rx, ry, 0, 0, Math.PI * 2);
    ctx.stroke();
  } else if (kind === "cone") {
    const rx = 55, ry = 18, top = cy - 70;
    ctx.fillStyle = "#FDE68A";
    ctx.beginPath();
    ctx.moveTo(cx, top);
    ctx.lineTo(cx + rx, cy + 20);
    ctx.ellipse(cx, cy + 20, rx, ry, 0, 0, Math.PI, true);
    ctx.closePath();
    ctx.fill(); ctx.stroke();
    ctx.fillStyle = "#FCD34D";
    ctx.beginPath();
    ctx.ellipse(cx, cy + 20, rx, ry, 0, 0, Math.PI * 2);
    ctx.fill(); ctx.stroke();
  } else if (kind === "pyramid") {
    const dx = 60, dy = 40, top = cy - 70;
    ctx.fillStyle = "#6EE7B7";
    ctx.beginPath();
    ctx.moveTo(cx, top);
    ctx.lineTo(cx + dx, cy + 20);
    ctx.lineTo(cx - dx + 20, cy + 30);
    ctx.closePath();
    ctx.fill(); ctx.stroke();
    ctx.fillStyle = "#34D399";
    ctx.beginPath();
    ctx.moveTo(cx, top);
    ctx.lineTo(cx - dx, cy + 10);
    ctx.lineTo(cx - dx + 20, cy + 30);
    ctx.closePath();
    ctx.fill(); ctx.stroke();
  } else if (kind === "sphere") {
    const r = 60;
    const grd = ctx.createRadialGradient(cx - 15, cy - 15, 10, cx, cy, r);
    grd.addColorStop(0, "#FBCFE8");
    grd.addColorStop(1, "#EC4899");
    ctx.fillStyle = grd;
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.fill(); ctx.stroke();
  } else {
    // triangular prism
    ctx.fillStyle = "#FDA4AF";
    ctx.beginPath();
    ctx.moveTo(cx - 40, cy + 30);
    ctx.lineTo(cx, cy - 50);
    ctx.lineTo(cx + 40, cy + 30);
    ctx.closePath();
    ctx.fill(); ctx.stroke();
    ctx.fillStyle = "#FB7185";
    ctx.beginPath();
    ctx.moveTo(cx, cy - 50);
    ctx.lineTo(cx + 55, cy - 35);
    ctx.lineTo(cx + 40, cy + 30);
    ctx.closePath();
    ctx.fill(); ctx.stroke();
  }

  ctx.fillStyle = COLORS.text;
  ctx.font = "bold 14px system-ui";
  ctx.textAlign = "center";
  ctx.fillText(kind, cx, h - 16);
  ctx.textAlign = "left";

}

function pathPrism(ctx, cx, cy, dx, dy, dz, face) {
  const ox = dz, oy = -dz * 0.6;
  if (face === "front") {
    ctx.beginPath();
    ctx.rect(cx - dx, cy - dy, dx * 2, dy * 2);
  } else if (face === "side") {
    ctx.beginPath();
    ctx.moveTo(cx + dx, cy - dy);
    ctx.lineTo(cx + dx + ox, cy - dy + oy);
    ctx.lineTo(cx + dx + ox, cy + dy + oy);
    ctx.lineTo(cx + dx, cy + dy);
    ctx.closePath();
  } else {
    ctx.beginPath();
    ctx.moveTo(cx - dx, cy - dy);
    ctx.lineTo(cx - dx + ox, cy - dy + oy);
    ctx.lineTo(cx + dx + ox, cy - dy + oy);
    ctx.lineTo(cx + dx, cy - dy);
    ctx.closePath();
  }
}


/** Single die face for probability / step-by-step practice. */
export function drawDice(canvas, value = 3, faces = 6, w = 200, h = 160) {
  const ctx = setup(canvas, w, h);
  const g = ctx.createLinearGradient(0, 0, w, h);
  g.addColorStop(0, "#EEF2FF");
  g.addColorStop(1, "#FCE7F3");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);
  const size = Math.min(w, h) * 0.55;
  const x = (w - size) / 2;
  const y = (h - size) / 2 - 4;
  ctx.fillStyle = "#FFFFFF";
  roundRect(ctx, x, y, size, size, 14);
  ctx.fill();
  ctx.strokeStyle = "#7C3AED";
  ctx.lineWidth = 3;
  roundRect(ctx, x, y, size, size, 14);
  ctx.stroke();
  const v = Math.max(1, Math.min(faces, value | 0));
  const positions = {
    1: [[0.5, 0.5]],
    2: [[0.28, 0.28], [0.72, 0.72]],
    3: [[0.28, 0.28], [0.5, 0.5], [0.72, 0.72]],
    4: [[0.28, 0.28], [0.72, 0.28], [0.28, 0.72], [0.72, 0.72]],
    5: [[0.28, 0.28], [0.72, 0.28], [0.5, 0.5], [0.28, 0.72], [0.72, 0.72]],
    6: [[0.28, 0.28], [0.72, 0.28], [0.28, 0.5], [0.72, 0.5], [0.28, 0.72], [0.72, 0.72]]
  };
  const dots = positions[v] || positions[1];
  const r = size * 0.08;
  ctx.fillStyle = "#1F2937";
  dots.forEach(([px, py]) => {
    ctx.beginPath();
    ctx.arc(x + px * size, y + py * size, r, 0, Math.PI * 2);
    ctx.fill();
  });
  ctx.fillStyle = "#6B7280";
  ctx.font = "12px system-ui";
  ctx.textAlign = "center";
  ctx.fillText(String(v), w / 2, h - 12);
  ctx.textAlign = "left";
}

/** Generic lesson visual router */
export function drawLessonVisual(canvas, visual = {}, w = 340, h = 200) {
  const type = visual.type || "banner";
  if (type === "fraction") return drawFractionBar(canvas, visual.num || 1, visual.den || 4, w, Math.min(h, 130));
  if (type === "place_value") return drawPlaceValue(canvas, visual.number || 345, w, Math.min(h, 140));
  if (type === "solid3d") return drawSolid3D(canvas, visual.kind || "cube", w, h);
  if (type === "dice") return drawDice(canvas, visual.value || 3, visual.faces || 6, w, Math.min(h, 160));
  if (type === "number_line") {
    return drawNumberLine(canvas, { value: visual.value, roundTo: visual.roundTo || 10, w, h: Math.min(h, 140) });
  }
  if (type === "bar_chart") {
    const ctx = setup(canvas, w, h);
    ctx.fillStyle = "#F0FDF4";
    ctx.fillRect(0, 0, w, h);
    const vals = visual.values || [3, 5, 2, 4];
    const labels = visual.labels || vals.map((_, i) => String(i + 1));
    const max = Math.max(...vals, 1);
    const bw = (w - 40) / vals.length;
    vals.forEach((v, i) => {
      const bh = (v / max) * (h - 50);
      ctx.fillStyle = ["#F472B6", "#A78BFA", "#60A5FA", "#34D399", "#FBBF24"][i % 5];
      ctx.fillRect(20 + i * bw + 4, h - 30 - bh, bw - 8, bh);
      ctx.fillStyle = "#374151";
      ctx.font = "11px system-ui";
      ctx.textAlign = "center";
      ctx.fillText(labels[i], 20 + i * bw + bw / 2, h - 12);
    });
    ctx.textAlign = "left";
    return;
  }
  let steps = visual.steps || [];
  if (typeof visual.stepIndex === "number" && steps.length) {
    const i = Math.max(0, Math.min(steps.length - 1, visual.stepIndex));
    steps = [steps[i]];
  }
  return drawLessonBanner(canvas, {
    title: visual.title || "",
    steps,
    bigText: visual.bigText || "",
    w, h
  });
}


/** Number line for rounding / placing numbers (child-friendly). */
export function drawNumberLine(canvas, { value = 73, roundTo = 10, w = 340, h = 130 } = {}) {
  const ctx = setup(canvas, w, h);
  const g = ctx.createLinearGradient(0, 0, w, h);
  g.addColorStop(0, "#FDF2F8");
  g.addColorStop(1, "#EDE9FE");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);

  const low = Math.floor(value / roundTo) * roundTo;
  const high = low + roundTo;
  const mid = (low + high) / 2;
  const pad = 28;
  const y = 70;
  const x0 = pad, x1 = w - pad;

  ctx.strokeStyle = "#7C3AED";
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(x0, y);
  ctx.lineTo(x1, y);
  ctx.stroke();
  // arrow heads
  ctx.beginPath();
  ctx.moveTo(x1 - 8, y - 6);
  ctx.lineTo(x1, y);
  ctx.lineTo(x1 - 8, y + 6);
  ctx.stroke();

  function xAt(n) {
    return x0 + ((n - low) / (high - low)) * (x1 - x0);
  }

  // ticks
  [low, mid, high].forEach((n) => {
    const x = xAt(n);
    ctx.beginPath();
    ctx.moveTo(x, y - 10);
    ctx.lineTo(x, y + 10);
    ctx.stroke();
    ctx.fillStyle = "#4C1D95";
    ctx.font = "bold 13px system-ui";
    ctx.textAlign = "center";
    ctx.fillText(String(n), x, y + 28);
  });

  // value marker
  const xv = xAt(Math.min(high, Math.max(low, value)));
  ctx.fillStyle = "#EC4899";
  ctx.beginPath();
  ctx.moveTo(xv, y - 18);
  ctx.lineTo(xv - 8, y - 32);
  ctx.lineTo(xv + 8, y - 32);
  ctx.closePath();
  ctx.fill();
  ctx.font = "bold 16px system-ui";
  ctx.fillText(String(value), xv, y - 40);

  // rounded answer bubble
  const rounded = value - low >= roundTo / 2 ? high : low;
  ctx.fillStyle = "#FFFFFF";
  roundRect(ctx, w / 2 - 70, 8, 140, 26, 10);
  ctx.fill();
  ctx.fillStyle = "#BE185D";
  ctx.font = "bold 13px system-ui";
  ctx.textAlign = "center";
  ctx.fillText(`→ nearest ${roundTo}: ${rounded}`, w / 2, 26);
  ctx.textAlign = "left";
}
