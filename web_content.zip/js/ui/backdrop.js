/* Backdrop – animované pozadí úvodu a menu: bubliny ze všech stran putují do středu.
   Je to jen animace (žádné věže, nic se nehraje); CSS ji lehce rozmaže.
   Při běhu hry se zastaví, ať nežere výkon.
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  var D = BD.render.draw, ET = BD.systems.enemies.TYPES;
  var TYPE_KEYS = ['bub', 'bub', 'bub', 'fast', 'fast', 'swarm', 'swarm', 'tank', 'boss'];
  var CELL = 56, MAX = 46;

  BD.ui.components.Backdrop = {
    props: { running: { type: Boolean, default: true }, animate: { type: Boolean, default: true } },
    template: '<canvas class="bd-backdrop"></canvas>',

    mounted: function () {
      var self = this;
      this.list = []; this.pops = []; this.raf = 0; this.last = 0; this.spawnT = 0; this.t = 0;
      this.onResize = function () { self.resize(); };
      window.addEventListener('resize', this.onResize);
      this.resize();
      this.seed();
      this.sync();
    },
    beforeUnmount: function () {
      cancelAnimationFrame(this.raf);
      window.removeEventListener('resize', this.onResize);
    },
    watch: {
      running: function () { this.sync(); },
      animate: function () { this.sync(); },
    },
    methods: {
      sync: function () {
        cancelAnimationFrame(this.raf); this.raf = 0;
        if (this.running && this.animate) { this.last = 0; this.raf = requestAnimationFrame(this.frame); }
        else this.drawStatic();
      },
      resize: function () {
        var cv = this.$el, k = 0.75;                // menší rozlišení = míň práce, pozadí je stejně rozmazané
        this.W = window.innerWidth; this.H = window.innerHeight; this.k = k;
        cv.width = Math.round(this.W * k); cv.height = Math.round(this.H * k);
        this.ctx = cv.getContext('2d');
        if (!this.raf) this.drawStatic();
      },
      spawn: function (progress) {
        var W = this.W, H = this.H, side = Math.floor(Math.random() * 4), x, y, m = 60;
        if (side === 0) { x = Math.random() * W; y = -m; }
        else if (side === 1) { x = W + m; y = Math.random() * H; }
        else if (side === 2) { x = Math.random() * W; y = H + m; }
        else { x = -m; y = Math.random() * H; }
        var type = TYPE_KEYS[Math.floor(Math.random() * TYPE_KEYS.length)], B = ET[type];
        var tx = W / 2 + (Math.random() - 0.5) * 70, ty = H / 2 + (Math.random() - 0.5) * 70;
        var e = { type: type, x: x, y: y, tx: tx, ty: ty, sp: B.speed * (46 + Math.random() * 26), ph: Math.random() * 6.28, a: 1, dying: false };
        if (progress) { e.x += (tx - x) * progress; e.y += (ty - y) * progress; }
        this.list.push(e);
      },
      seed: function () { for (var i = 0; i < 22; i++) this.spawn(Math.random() * 0.85); },

      frame: function (ts) {
        this.raf = requestAnimationFrame(this.frame);
        var dt = Math.min(0.05, (ts - this.last) / 1000 || 0); this.last = ts; this.t += dt;
        this.spawnT -= dt;
        if (this.spawnT <= 0 && this.list.length < MAX) { this.spawn(0); this.spawnT = 0.18 + Math.random() * 0.35; }
        var i, e;
        for (i = this.list.length - 1; i >= 0; i--) {
          e = this.list[i];
          var dx = e.tx - e.x, dy = e.ty - e.y, d = Math.hypot(dx, dy);
          if (!e.dying) {
            if (d < 36) { e.dying = true; this.pops.push({ x: e.x, y: e.y, t: 0, type: e.type }); }
            else {
              var ux = dx / d, uy = dy / d, w = Math.sin(this.t * 2.4 + e.ph) * 0.55;
              e.x += (ux - uy * w) * e.sp * dt; e.y += (uy + ux * w) * e.sp * dt;
            }
          } else { e.a -= dt * 4; if (e.a <= 0) this.list.splice(i, 1); }
        }
        for (i = this.pops.length - 1; i >= 0; i--) { this.pops[i].t += dt; if (this.pops[i].t > 0.5) this.pops.splice(i, 1); }
        this.draw();
      },

      bg: function (ctx) {
        var W = this.W, H = this.H;
        var g = ctx.createRadialGradient(W / 2, H / 2, 20, W / 2, H / 2, Math.max(W, H) * 0.7);
        g.addColorStop(0, '#1d2a27'); g.addColorStop(1, '#0f1216');
        ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
      },
      draw: function () {
        var ctx = this.ctx; if (!ctx) return;
        ctx.setTransform(this.k, 0, 0, this.k, 0, 0);
        this.bg(ctx);
        // slabá záře uprostřed – tam bubliny míří
        var pulse = 0.5 + 0.5 * Math.sin(this.t * 1.6);
        var g = ctx.createRadialGradient(this.W / 2, this.H / 2, 4, this.W / 2, this.H / 2, 150);
        g.addColorStop(0, 'rgba(240,191,76,' + (0.16 + 0.08 * pulse) + ')'); g.addColorStop(1, 'rgba(240,191,76,0)');
        ctx.fillStyle = g; ctx.fillRect(this.W / 2 - 160, this.H / 2 - 160, 320, 320);
        for (var i = 0; i < this.list.length; i++) {
          var e = this.list[i];
          ctx.globalAlpha = Math.max(0, e.a) * 0.9;
          D.enemy(ctx, { type: e.type, x: e.x / CELL, y: e.y / CELL, slow: 0, hp: 1, maxhp: 1 }, CELL);
        }
        ctx.globalAlpha = 1;
        for (var j = 0; j < this.pops.length; j++) {
          var p = this.pops[j], q = p.t / 0.5;
          ctx.beginPath(); ctx.arc(p.x, p.y, 10 + 34 * q, 0, D.TAU);
          ctx.strokeStyle = D.hexA(ET[p.type].color, 0.7 * (1 - q)); ctx.lineWidth = 2.5; ctx.stroke();
        }
      },
      drawStatic: function () {
        var ctx = this.ctx; if (!ctx) return;
        ctx.setTransform(this.k, 0, 0, this.k, 0, 0);
        this.bg(ctx);
        for (var i = 0; i < this.list.length; i++) {
          var e = this.list[i];
          ctx.globalAlpha = 0.5;
          D.enemy(ctx, { type: e.type, x: e.x / CELL, y: e.y / CELL, slow: 0, hp: 1, maxhp: 1 }, CELL);
        }
        ctx.globalAlpha = 1;
      },
    },
  };
})(window.BD);
