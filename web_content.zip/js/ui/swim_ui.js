'use strict';
/* ================= swimming UI ================= */
function setSwimUI(on){document.body.classList.toggle('swim',!!on);}
function splash(p){particles(p.x,-.3,p.z,0xbfe8ff,14);sfx('splash');}

