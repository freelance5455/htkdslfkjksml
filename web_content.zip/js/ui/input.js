'use strict';
/* ================= input ================= */
const keys={};let joy={id:null,ox:0,oy:0,dx:0,dy:0},look={id:null,x:0,y:0},jump=false,down=false;
const typing=()=>document.activeElement&&document.activeElement.tagName==='INPUT';
addEventListener('keydown',e=>{
 if(typing())return;keys[e.code]=true;
 if(e.code==='Space'){jump=true;e.preventDefault();}
 if(e.code==='KeyF')eat();if(e.code==='KeyC')toggleCraft();if(e.code==='KeyE'||e.code==='KeyI'||e.code==='KeyB')toggleBag();
 if(e.code==='Enter'&&Net.ok)openChat();
 if(e.code.startsWith('Digit')){const n=+e.code.slice(5)-1;if(n>=0&&n<hotList().length){slotIdx=n;refreshHud();}}
 if(e.code==='KeyG'&&creative)toggleFly();
});
addEventListener('keyup',e=>{keys[e.code]=false;if(e.code==='Space')jump=false;});
const jz=$('joyZone'),lz=$('lookZone'),jb=$('joyBase'),jk=$('joyKnob');
jz.addEventListener('pointerdown',e=>{if(joy.id!==null)return;joy.id=e.pointerId;const q=pt(e);joy.ox=q.x;joy.oy=q.y;joy.dx=joy.dy=0;jb.style.display='block';jb.style.left=q.x+'px';jb.style.top=q.y+'px';jk.style.transform='translate(0,0)';try{jz.setPointerCapture(e.pointerId);}catch(x){}});
jz.addEventListener('pointermove',e=>{if(e.pointerId!==joy.id)return;const q=pt(e);let vx=q.x-joy.ox,vy=q.y-joy.oy;const l=Math.hypot(vx,vy),R=50;if(l>R){vx*=R/l;vy*=R/l;}joy.dx=vx/R;joy.dy=vy/R;jk.style.transform='translate('+vx+'px,'+vy+'px)';});
const joyEnd=e=>{if(e.pointerId!==joy.id)return;joy.id=null;joy.dx=joy.dy=0;jb.style.display='none';};
jz.addEventListener('pointerup',joyEnd);jz.addEventListener('pointercancel',joyEnd);
lz.addEventListener('pointerdown',e=>{
 if(e.pointerType==='mouse'){if(document.pointerLockElement!==lz){try{lz.requestPointerLock();}catch(x){}}if(e.button===0)useItem();return;}
 if(look.id!==null)return;look.id=e.pointerId;{const q=pt(e);look.x=q.x;look.y=q.y;}try{lz.setPointerCapture(e.pointerId);}catch(x){}
});
lz.addEventListener('pointermove',e=>{
 if(e.pointerType==='mouse'){if(document.pointerLockElement===lz){{const fl=WT.flipCam?-1:1;camYaw-=fl*e.movementX*.0035;camPitch=clamp(camPitch+fl*e.movementY*.0035,-.5,1.2);}}return;}
 if(e.pointerId!==look.id)return;const q=pt(e);{const fl=WT.flipCam?-1:1;camYaw-=fl*(q.x-look.x)*.0055;camPitch=clamp(camPitch+fl*(q.y-look.y)*.0045,-.5,1.2);}look.x=q.x;look.y=q.y;
});
const lookEnd=e=>{if(e.pointerId===look.id)look.id=null;};
lz.addEventListener('pointerup',lookEnd);lz.addEventListener('pointercancel',lookEnd);
lz.addEventListener('contextmenu',e=>e.preventDefault());
function hold(el,on,off){el.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();on();try{el.setPointerCapture(e.pointerId);}catch(x){}});const f=()=>off&&off();el.addEventListener('pointerup',f);el.addEventListener('pointercancel',f);}
let atkHeld=false;
hold($('bAtk'),()=>{atkHeld=true;useItem();},()=>{atkHeld=false;});
hold($('bJump'),()=>{jump=true;},()=>{jump=false;});
hold($('bDown'),()=>{down=true;},()=>{down=false;});
hold($('bUp'),()=>{jump=true;},()=>{jump=false;});
hold($('bDive'),()=>{down=true;},()=>{down=false;});
$('bEat').addEventListener('click',eat);
$('bCraft').addEventListener('click',toggleCraft);
$('bFly').addEventListener('click',toggleFly);
$('bTime').addEventListener('click',()=>{tod=(Math.sin(tod*6.283)>0)?.75:.25;toast('تغيّر الوقت');});
function toggleFly(){if(!creative||!P)return;P.fly=!P.fly;P.vy=0;toast(P.fly?'الطيران مفعّل':'الطيران متوقف');}
function toggleCraft(){if(!playing)return;const c=$('craft');if(c.classList.contains('on'))c.classList.remove('on');else{renderCraft();c.classList.add('on');}}
$('craftX').addEventListener('click',()=>$('craft').classList.remove('on'));
$('craftX').addEventListener('click',()=>{});
$('bFull').addEventListener('click',()=>{try{if(document.fullscreenElement)document.exitFullscreen();else document.documentElement.requestFullscreen();}catch(e){}});
$('bMenu').addEventListener('click',()=>showMenu(true));
$('respawn').addEventListener('click',()=>{const p=P;P=newPlayer();P.fly=false;setSwimUI(false);for(const k in INV)INV[k]=Math.floor(INV[k]/2);$('dead').classList.remove('on');refreshHud();});

