/* ===================================================================
 * VFL.UI.Header
 * =================================================================== */
(function (VFL) {
  "use strict";

  VFL.UI = VFL.UI || {};

  VFL.UI.Header = {
    render: function () {
      var el = document.getElementById("app-header");
      if (!el) return;
      var state = VFL.State.get();

      var seasonChip = "";
      if (state) {
        seasonChip =
          '<div class="header-season-chip">فصل ' + VFL.Utils.faDigits(state.season.current) +
          " · " + VFL.Utils.weekLabel(state.season.week) + "</div>";
      }

      el.innerHTML =
        '<div class="brand">' +
        '<span class="brand-mark"></span>' +
        '<span class="brand-name">شبیه‌ساز لیگ فوتبال مجازی</span>' +
        '<span class="brand-version">نسخه ' + VFL.Utils.faDigits(VFL.Config.version) + "</span>" +
        "</div>" +
        seasonChip;
    }
  };
})(window.VFL || (window.VFL = {}));
