/* ===================================================================
 * VFL.UI.BottomNav
 * نوار پایین ثابت: خانه | مسابقات | جدول | تیم‌ها | نقل‌وانتقالات | بیشتر
 * =================================================================== */
(function (VFL) {
  "use strict";

  VFL.UI = VFL.UI || {};

  var ICONS = {
    home: '<svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10v9a1 1 0 0 0 1 1H9a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h2.5a1 1 0 0 0 1-1v-9"/></svg>',
    competitions: '<svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M8 21h8M12 17v4M7 4h10v4a5 5 0 0 1-10 0V4Z"/><path d="M7 6H4a3 3 0 0 0 3 5M17 6h3a3 3 0 0 1-3 5"/></svg>',
    standings: '<svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 19V10M12 19V5M20 19v-6"/></svg>',
    teams: '<svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="8" cy="8" r="3"/><circle cx="17" cy="9" r="2.5"/><path d="M2.5 20c0-3 2.5-5.5 5.5-5.5S13.5 17 13.5 20"/><path d="M14.5 14.8c2.3.2 4 2.3 4 5.2"/></svg>',
    transfers: '<svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M7 4 3 8l4 4"/><path d="M3 8h14"/><path d="M17 20l4-4-4-4"/><path d="M21 16H7"/></svg>',
    more: '<svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="5" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="19" cy="12" r="1.6"/></svg>'
  };

  var ITEMS = [
    { route: "home", label: "خانه", icon: "home" },
    { route: "competitions", label: "مسابقات", icon: "competitions" },
    { route: "standings", label: "جدول", icon: "standings" },
    { route: "teams", label: "تیم‌ها", icon: "teams" },
    { route: "transfers", label: "نقل‌وانتقالات", icon: "transfers" },
    { route: "more", label: "بیشتر", icon: "more" }
  ];

  VFL.UI.BottomNav = {
    render: function (activeRoute) {
      var el = document.getElementById("bottom-nav");
      if (!el) return;
      el.innerHTML = ITEMS.map(function (item) {
        var active = item.route === activeRoute ? " active" : "";
        return (
          '<button class="nav-item' + active + '" data-route="' + item.route + '">' +
          ICONS[item.icon] +
          "<span>" + item.label + "</span>" +
          "</button>"
        );
      }).join("");

      Array.prototype.forEach.call(el.querySelectorAll(".nav-item"), function (btn) {
        btn.addEventListener("click", function () {
          window.location.hash = "#/" + btn.getAttribute("data-route");
        });
      });
    }
  };
})(window.VFL || (window.VFL = {}));
