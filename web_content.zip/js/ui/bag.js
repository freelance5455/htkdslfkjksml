'use strict';
/* ================= bag ================= */
const DESC={
 fist:'القبضة: ضرر بسيط، لا تفارقك.',sword:'سيف: ضرر عالٍ على الزومبي والحيوانات.',axe:'فأس: يقطع الأشجار والصخور أسرع.',
 bow:'قوس: يطلق السهام، يحتاج سهاماً.',gun:'مسدس: سريع الطلقات، يحتاج رصاصاً.',
 wall:'جدار خشبي لبناء بيتك.',floor:'أرضية خشبية.',fire:'نار مخيم: تبعد الزومبي وتشفيك قربها.',
 sp_deer:'إضافة غزال أمامك.',sp_pig:'إضافة خنزير أمامك.',sp_zombie:'إضافة زومبي أمامك.',
 wood:'خشب: للبناء والصناعة.',stone:'حجر: للصناعة والنار.',iron:'حديد: للمسدس والرصاص.',
 meat:'لحم: يملأ الجوع ويعالجك.',berry:'توت: يملأ جزءاً من الجوع.',arrow:'سهام للقوس.',bullet:'رصاص للمسدس.'
};
let bagSel=null;
const iconOf=id=>ICONS[id]||RES_ICONS[id]||'';
const nameOf=id=>(ITEMS[id]&&ITEMS[id].n)||NAMES[id]||id;
function bagEntries(){
 const arr=[];
 for(const id of['fist','sword','axe','pickaxe','bow','gun','fire'])if(owns(id))arr.push(id);
 if(creative){for(const id of BLOCK_IDS)arr.push(id);for(const id of['sp_deer','sp_pig','sp_zombie'])arr.push(id);}
 for(const k of Object.keys(INV))if((creative&&!ITEMS[k])||(!creative&&INV[k]>0&&!arr.includes(k)))arr.push(k);
 return arr;
}
function bagCount(id){
 if(ITEMS[id]){const it=ITEMS[id];if(it.type==='block')return creative?'∞':(INV[id]||0);return it.type==='ranged'?(creative?'∞':(INV[it.ammo]||0)):'';}
 return creative?'∞':INV[id];
}
function mkSlot(id,sel){
 const b=document.createElement('button');b.className='bslot'+(sel?' sel':'');
 b.innerHTML='<svg viewBox="0 0 24 24" style="color:'+(RES_COL[id]||'#fff')+'">'+(id?iconOf(id):'')+'</svg><u>'+(id?bagCount(id):'')+'</u>';
 if(id)b.setAttribute('aria-label',nameOf(id));else b.disabled=true;
 return b;
}
function equip(id){
 if(!ITEMS[id]||!owns(id))return;
 const j=HOT.indexOf(id);if(j>=0&&j!==slotIdx)HOT[j]=HOT[slotIdx]||null;
 HOT[slotIdx]=id;toast(nameOf(id)+' في الخانة '+(slotIdx+1));refreshHud();
}
function renderBag(){
 const g=$('bgrid');g.innerHTML='';
 const list=bagEntries();
 for(let i=0;i<27;i++){
  const id=list[i]||null;const b=mkSlot(id,id&&id===bagSel);
  if(id)b.addEventListener('click',()=>{bagSel=id;renderBag();});
  g.appendChild(b);
 }
 const h=$('bhot');h.innerHTML='';
 for(let i=0;i<9;i++){
  const id=HOT[i]||null;const b=mkSlot(id,i===slotIdx);b.disabled=false;
  b.addEventListener('click',()=>{slotIdx=i;refreshHud();});
  h.appendChild(b);
 }
 const inf=$('binfo');inf.innerHTML='';
 if(!bagSel||(!creative&&!list.includes(bagSel)))bagSel=null;
 const t=document.createElement('h3');const p=document.createElement('p');
 if(bagSel){
  t.textContent=nameOf(bagSel)+(bagCount(bagSel)!==''?'  ×'+bagCount(bagSel):'');p.textContent=DESC[bagSel]||'';
  inf.append(t,p);
  if(ITEMS[bagSel]&&ITEMS[bagSel].type!=='res'){const b=document.createElement('button');b.className='pri';b.textContent='ضعه في الخانة '+(slotIdx+1);b.addEventListener('click',()=>equip(bagSel));inf.appendChild(b);}
  if((bagSel==='meat'||bagSel==='berry')&&!creative){const b=document.createElement('button');b.className='pri';b.textContent='كل';b.addEventListener('click',()=>eatItem(bagSel));inf.appendChild(b);}
 }else{t.textContent='الحقيبة';p.textContent='اختر عنصراً لترى تفاصيله. اختر خانة من الشريط السفلي ثم اضغط «ضعه في الخانة» لتغيير ما تحمله.';inf.append(t,p);}
 const c=document.createElement('button');c.textContent='إفراغ الخانة '+(slotIdx+1);c.addEventListener('click',()=>{HOT[slotIdx]=null;refreshHud();});inf.appendChild(c);
}
function toggleBag(){
 if(!playing)return;const b=$('bag');
 if(b.classList.contains('on')){b.classList.remove('on');return;}
 $('craft').classList.remove('on');renderBag();b.classList.add('on');
}
$('bBag').addEventListener('click',toggleBag);
$('bagX').addEventListener('click',()=>$('bag').classList.remove('on'));
$('bagCraft').addEventListener('click',()=>{$('bag').classList.remove('on');toggleCraft();});

