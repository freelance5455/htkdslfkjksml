'use strict';
/* ================= boot ================= */
initWorld('عالمي','survival');
showMenu(true);
if(S.name)Pres.start();
requestAnimationFrame(frame);
setLang(LANG);
window.__game={S,Net,Pres,heightAt,getP:()=>P,cloud,Cave,world,chunks,ents,spawnEnt,enterCave,exitCave,get WTK(){return WTK;},get INV(){return INV;},get TOOLS(){return TOOLS;},hurt,giveBonus,sendOrder,tr,setLang,get LANG(){return LANG;},scanProps,launch,boxBlockedX:(x,z)=>boxBlocked(x,z,.4),hAtX:hAt,kbHide,BIGW,BIG_KEYS,ravD,kbShow,kbInsert,BLK,setBlock,delBlock,placeBlock,BT,aimBlock,topBlockUnder,GIFT_PATH,giftState,claimGift,nearBlockInteract,toggleDoorBlock,flushBlocks,get aim(){return aim;},get tod(){return tod;},set tod(v){tod=v;}};
