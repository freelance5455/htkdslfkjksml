/* Nastavení – panel v pravé části menu. Mění se rovnou profil (a ukládá se samo).
   Zvuky zatím nejsou, hlasitosti se jen ukládají pro další krok.
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';

  BD.ui.components.Settings = {
    template:
      '<div class="settings">' +
        '<h2 class="ph">Nastavení</h2>' +

        '<div class="grp">' +
          '<div class="h">Zvuk <span class="tag">zvuky přibudou později</span></div>' +
          '<label class="rng"><span>Celková hlasitost</span><input type="range" min="0" max="100" v-model.number="s.master"><b>{{ s.master }}</b></label>' +
          '<label class="rng"><span>Hudba</span><input type="range" min="0" max="100" v-model.number="s.music"><b>{{ s.music }}</b></label>' +
          '<label class="rng"><span>Efekty</span><input type="range" min="0" max="100" v-model.number="s.sfx"><b>{{ s.sfx }}</b></label>' +
        '</div>' +

        '<div class="grp">' +
          '<div class="h">Hra</div>' +
          '<div class="row2"><span>Výchozí rychlost</span>' +
            '<div class="seg"><button v-for="n in 3" :key="n" :class="{on: s.gameSpeed === n}" @click="s.gameSpeed = n">{{ n }}×</button></div></div>' +
          '<div class="row2"><span>Třesení obrazovky</span>' +
            '<div class="seg"><button v-for="o in shakes" :key="o.v" :class="{on: s.shake === o.v}" @click="s.shake = o.v">{{ o.t }}</button></div></div>' +
          '<label class="tog"><span>Zobrazit dosah věží</span><input type="checkbox" v-model="s.showRange"><i></i></label>' +
          '<label class="tog"><span>Zobrazit trasu bublin</span><input type="checkbox" v-model="s.showPath"><i></i></label>' +
          '<label class="tog"><span>Zobrazit délku cesty nad věží</span><input type="checkbox" v-model="s.showPathLen"><i></i></label>' +
          '<label class="tog"><span>Zobrazit mřížku</span><input type="checkbox" v-model="s.showGrid"><i></i></label>' +
          '<label class="tog"><span>Nápovědy v tutoriálu</span><input type="checkbox" v-model="s.hints"><i></i></label>' +
        '</div>' +

        '<div class="grp">' +
          '<div class="h">Vzhled</div>' +
          '<label class="tog"><span>Animace pozadí menu</span><input type="checkbox" v-model="s.menuAnimation"><i></i></label>' +
          '<div class="row2"><span>Jazyk</span><select class="btn" disabled><option>Čeština</option></select></div>' +
        '</div>' +

        '<div class="grp">' +
          '<div class="h">Data</div>' +
          '<div class="hint">Postup se ukládá jen v tomto prohlížeči. Export ti dá soubor, který můžeš zálohovat nebo přenést na jiné zařízení.</div>' +
          '<div class="row">' +
            '<button class="btn" @click="doExport"><ic n="download"></ic> Export do JSON</button>' +
            '<button class="btn" @click="copy"><ic n="copy"></ic> Kopírovat</button>' +
            '<button class="btn" @click="$refs.file.click()"><ic n="upload"></ic> Import z JSON</button>' +
            '<input ref="file" type="file" accept=".json,.txt,application/json,text/plain" hidden @change="onFile">' +
          '</div>' +
          '<div class="msg" :class="msgCls" v-if="msg">{{ msg }}</div>' +
          '<div class="row"><button class="btn danger" @click="wipe"><ic n="trash"></ic> Smazat všechna data</button></div>' +
        '</div>' +
      '</div>',

    data: function () {
      return { s: BD.store.profile.settings, msg: '', msgCls: '',
        shakes: [{ v: 0, t: 'Vypnuto' }, { v: 1, t: 'Jemné' }, { v: 2, t: 'Silné' }] };
    },
    methods: {
      say: function (t, bad) { this.msg = t; this.msgCls = bad ? 'err' : 'okk'; },
      doExport: function () {
        try {
          var blob = new Blob([BD.store.exportJSON()], { type: 'application/json' });
          var a = document.createElement('a');
          a.href = URL.createObjectURL(blob); a.download = 'bubbledefence-postup.json';
          document.body.appendChild(a); a.click(); document.body.removeChild(a);
          setTimeout(function () { URL.revokeObjectURL(a.href); }, 2000);
          this.say('Soubor bubbledefence-postup.json je stažený.');
        } catch (e) { this.say('Export se nepovedl, zkus „Kopírovat“.', true); }
      },
      copy: async function () {
        var txt = BD.store.exportJSON();
        try { await navigator.clipboard.writeText(txt); this.say('Postup je zkopírovaný do schránky.'); }
        catch (e) {
          var ta = document.createElement('textarea'); ta.value = txt; document.body.appendChild(ta); ta.select();
          try { document.execCommand('copy'); this.say('Postup je zkopírovaný do schránky.'); } catch (e2) { this.say('Kopírování se nepovedlo.', true); }
          document.body.removeChild(ta);
        }
      },
      onFile: async function (ev) {
        var self = this, f = ev.target.files && ev.target.files[0];
        ev.target.value = '';
        if (!f) return;
        if (f.size > 5 * 1024 * 1024) { self.say('Soubor je příliš velký.', true); return; }
        var ok = await BD.ui.confirm('Import přepíše současný postup, uložené hry, levely i nastavení. Pokračovat?', { ok: 'Přepsat' });
        if (!ok) return;
        var r = new FileReader();
        r.onload = function () {
          var res = BD.store.importJSON(String(r.result));
          if (res.ok) { self.s = BD.store.profile.settings; self.say('Postup byl načten.'); } else self.say(res.error, true);
        };
        r.readAsText(f);
      },
      wipe: async function () {
        var ok = await BD.ui.confirm('Opravdu smazat všechna uložená data (postup, hry, levely, nastavení)? Nejde to vrátit.', { ok: 'Smazat vše' });
        if (!ok) return;
        BD.store.newProfile(); this.s = BD.store.profile.settings; this.say('Všechna data byla smazána.');
      },
    },
  };
})(window.BD);
