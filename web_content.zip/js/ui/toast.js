// Avisos breves. El contenedor #toasts es una región aria-live.
import { h } from './dom.js';

// Contenedor de avisos. A pantalla completa (el mundo) solo se ve lo que está dentro del elemento a pantalla completa, así que ahí
// se mueve el contenedor; al salir vuelve a #app. Si se perdió junto con el mundo (se quitó con los avisos dentro), se recrea.
function toastHost() {
  const app = document.getElementById('app') || document.body;
  let host = document.getElementById('toasts');
  if (!host) {
    host = h('div', { id: 'toasts', 'aria-live': 'polite' });
    app.append(host);
  }
  const root = document.fullscreenElement || app;
  if (host.parentElement !== root) root.append(host);
  return host;
}
if (typeof document !== 'undefined') {
  document.addEventListener('fullscreenchange', () => {
    const host = document.getElementById('toasts');
    const app = document.getElementById('app');
    if (host && app && !document.fullscreenElement && host.parentElement !== app) app.append(host);
  });
}

export function toast(message, { kind = 'info', ms = 4200 } = {}) {
  const host = toastHost();
  if (!host) return;
  const el = h('div', { class: `toast toast--${kind}`, role: kind === 'error' ? 'alert' : 'status' }, message);
  host.append(el);
  requestAnimationFrame(() => el.classList.add('is-in'));
  const remove = () => {
    el.classList.remove('is-in');
    setTimeout(() => el.remove(), 260);
  };
  const timer = setTimeout(remove, ms);
  el.addEventListener('click', () => {
    clearTimeout(timer);
    remove();
  });
  while (host.children.length > 3) host.firstChild.remove();
}
