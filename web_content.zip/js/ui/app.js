/* App – kořen: řídí „okno“ nad pozadím a přechody mezi obrazovkami.
   Okno má 3 velikosti: intro (malé) → menu (velké) → full (celá plocha).
   Při každém přechodu: obsah zmizí (fade) → okno se zvětší/zmenší → objeví se nový obsah.
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  var sleep = BD.util.sleep;

  BD.ui.App = {
    template: `
<div class="app" :class="win">
  <bd-backdrop :running="win !== 'full'" :animate="settings.menuAnimation"></bd-backdrop>
  <div class="shade"></div>

  <div class="win" :class="win">
    <div class="content" :class="{hidden: !visible}">
      <bd-intro v-if="screen === 'intro'" @start="goMenu"></bd-intro>
      <bd-main-menu v-else-if="screen === 'menu'" @launch="launch" @back="goIntro"></bd-main-menu>
      <bd-story-map v-else-if="screen === 'story-map'" @play="playNode" @back="goMenu" @skip="skipTutorial"></bd-story-map>
      <bd-game-view v-else-if="screen === 'game'" :key="gameKey" :session="session" @exit="onGameExit" @skip="skipTutorial"></bd-game-view>
      <bd-editor-view v-else-if="screen === 'editor'" :level-id="editorId" @back="goMenu" @play="playEditor"></bd-editor-view>
      <bd-studio-view v-else-if="screen === 'studio'" @back="goMenu" @test="studioTest"></bd-studio-view>
    </div>
  </div>

  <bd-bestiary></bd-bestiary>
  <bd-terminal></bd-terminal>

  <div class="dlg" v-if="dlg.open" @click.self="answer(false)">
    <div class="dlg-box">
      <div class="dlg-text">{{ dlg.text }}</div>
      <div class="dlg-btns">
        <button class="btn" @click="answer(false)">{{ dlg.cancel }}</button>
        <button class="btn primary" @click="answer(true)">{{ dlg.ok }}</button>
      </div>
    </div>
  </div>
</div>`,

    data: function () {
      return { win: 'intro', screen: 'intro', visible: true, busy: false, session: null, gameKey: 0, editorId: '',
        dlg: { open: false, text: '', ok: 'Ano', cancel: 'Zrušit', resolve: null } };
    },
    computed: { settings: function () { return BD.store.profile.settings; } },

    created: function () {
      var self = this;
      /* BD.ui.confirm(text, {ok, cancel}) → Promise<boolean>, použijí ho ostatní komponenty */
      BD.ui.confirm = function (text, o) {
        o = o || {};
        return new Promise(function (resolve) {
          self.dlg.text = text; self.dlg.ok = o.ok || 'Ano'; self.dlg.cancel = o.cancel || 'Zrušit';
          self.dlg.resolve = resolve; self.dlg.open = true;
        });
      };
    },

    methods: {
      answer: function (val) { var r = this.dlg.resolve; this.dlg.open = false; this.dlg.resolve = null; if (r) r(val); },

      /* fade out → změna velikosti okna → fade in nového obsahu */
      go: async function (win, screen, before) {
        if (this.busy) return;
        this.busy = true;
        this.visible = false; await sleep(240);
        if (before) before();
        if (win !== this.win) { this.win = win; await sleep(580); }
        this.screen = screen;
        await this.$nextTick();
        this.visible = true;
        this.busy = false;
      },

      goMenu: function () { this.go('menu', 'menu'); },
      goIntro: function () { this.go('intro', 'intro'); },

      launch: function (p) {
        var self = this;
        if (p.to === 'story-map') this.go('full', 'story-map');
        else if (p.to === 'game') this.go('full', 'game', function () { self.session = p.session; self.gameKey++; });
        else if (p.to === 'editor') this.go('full', 'editor', function () { self.editorId = p.levelId; });
        else if (p.to === 'studio') this.go('full', 'studio');
      },

      playNode: function (node) {
        var self = this, sv = BD.store.profile.story.save;
        var snap = sv && sv.nodeId === node.id ? sv.snapshot : null;
        this.go('full', 'game', function () {
          self.session = { mode: node.tutorial ? 'tutorial' : 'story', nodeId: node.id, title: node.title, level: node.level, snapshot: snap, rewards: !node.noCards && !node.tutorial };
          self.gameKey++;
        });
      },
      playEditor: function (level) {
        var self = this;
        this.go('full', 'game', function () {
          self.session = { mode: 'free', title: level.name, level: BD.util.clone(level), snapshot: null, editorId: level.id };
          self.gameKey++;
        });
      },
      /* zkouška položky ze Studia: prázdné pole, hodně zlata a životů; nepřítel se opakuje v každé vlně */
      studioTest: function (p) {
        var self = this, lv = BD.util.clone(BD.data.presets[0]); lv.gold = 5000; lv.lives = 999; lv.waves = 0; lv.towers = []; lv.name = 'Studio zkouška';
        this.go('full', 'game', function () {
          self.session = { mode: 'free', title: 'Studio: ' + p.id, level: lv, snapshot: null, editorId: '__studio', rewards: false, studioTest: p.kind === 'enemies' ? p.id : null, studioTower: p.kind === 'towers' ? p.id : null };
          self.gameKey++;
        });
      },
      skipTutorial: function () { BD.store.completeNode('t1'); this.go('full', 'story-map'); },

      onGameExit: function (dest, extra) {
        var self = this, eid = this.session && this.session.editorId;
        if (eid === '__studio') { this.go('full', 'studio'); return; }
        if (dest === 'next' && BD.data.story.byId[extra]) this.playNode(BD.data.story.byId[extra]);
        else if (dest === 'next') this.go('full', 'story-map');
        else if (dest === 'editor' && eid) this.go('full', 'editor', function () { self.editorId = eid; });
        else if (dest === 'map') this.go('full', 'story-map'); else this.go('menu', 'menu');
      },
    },
  };
})(window.BD);
