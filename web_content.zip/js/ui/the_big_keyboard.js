'use strict';
/* ================= THE BIG (gated limited mode), quick-join, in-game keyboard ================= */
const BIG_SHA='f3dafcd93aa3b6e6af443c40593abdf0a09275085267dfefeff6f544128bcdcf',BIG_FNV='1qo8u4d';
async function checkBig(code){
 const n=String(code||'').trim().toLowerCase().replace(/\s+/g,'');if(!n)return false;const s='ard|big|'+n;
 try{if(window.crypto&&crypto.subtle){const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s));return Array.from(new Uint8Array(b)).map(x=>x.toString(16).padStart(2,'0')).join('')===BIG_SHA;}}catch(e){}
 return fnv(s)===BIG_FNV;
}
const BIG_KEYS=Object.keys(BIGW);
function bigPanelRender(){
 const ok=!!(S.big);$('bigGate').style.display=ok?'none':'block';$('bigPanel').style.display=ok?'block':'none';
 const box=$('bigList');box.innerHTML='';
 BIG_KEYS.forEach((k,i)=>{const b=document.createElement('button');b.className='mode alt'+(1+i%3);b.innerHTML='<b>'+(i+1)+'. '+BIGW[k].n+'</b><small>جاذبية '+Math.round((BIGW[k].grav||1)*100)+'%</small>';b.addEventListener('click',()=>{Net.close();launch({room:'big-'+k+'-'+S.name,mode:wantMode,wt:k,online:false});});box.appendChild(b);});
}
$('toBig').addEventListener('click',()=>{view('vBig');bigPanelRender();});
$('bigGo').addEventListener('click',async()=>{
 const ok=await checkBig($('bigCode').value);
 if(ok){S.big=1;save();$('bigCode').value='';toast('مرحباً بك في THE BIG');beep(700,.2,'triangle',.06);bigPanelRender();}
 else{say('الرمز غير صحيح');beep(150,.2,'sawtooth',.05);}
});
function travelTo(k){
 const keepI=Object.assign({},INV),keepT=Object.assign({},TOOLS);
 $('planets').classList.remove('on');Net.close();
 launch({room:'big-'+k+'-'+S.name,mode:world.mode,wt:k,online:false});
 if(!creative){Object.assign(INV,keepI);Object.assign(TOOLS,keepT);}
 refreshHud();toast('وصلت إلى: '+BIGW[k].n);
}
const ERAS=[['العصر القديم',.27],['العصر الحاضر',.5],['عصر المستقبل',.8]];
function openPlanets(){
 const el=$('eraList');el.innerHTML='';
 ERAS.forEach(e=>{const b=document.createElement('button');b.className='mode alt2';b.innerHTML='<b>'+e[0]+'</b>';b.addEventListener('click',()=>{tod=e[1];toast('عبرت البوابة الزمنية: '+e[0]);beep(500,.3,'sine',.06);});el.appendChild(b);});
 const pl=$('planetList');pl.innerHTML='';
 BIG_KEYS.forEach((k,i)=>{const b=document.createElement('button');b.className='mode alt'+(1+i%3);b.innerHTML='<b>'+BIGW[k].n+'</b>'+(k===WTK?'<small>أنت هنا</small>':'');b.addEventListener('click',()=>travelTo(k));pl.appendChild(b);});
 $('planets').classList.add('on');
}
$('bPortal').addEventListener('click',openPlanets);$('planetX').addEventListener('click',()=>$('planets').classList.remove('on'));
/* ---- quick join "any room" ---- */
async function anyRoom(){
 if(busy)return;busy=true;say('جارٍ البحث عن غرفة بها لاعبين…');
 try{
  for(let i=1;i<=3;i++){try{const m=await joinRoom('public-'+i,'0000');pushRecent('public-'+i,'0000','j');launch({room:m.seed,mode:m.mode,wt:m.wt||'forest',online:true,joined:m});say('');busy=false;return;}catch(e){}}
  say('لا توجد غرفة نشطة، سننشئ غرفة عامة جديدة…');
  for(let i=1;i<=3;i++){try{await hostRoom('public-'+i,'0000','survival',wantWT||'forest');launch({room:'public-'+i,mode:'survival',wt:wantWT||'forest',online:true});say('');toast('أنت أول لاعب في الغرفة العامة، سينضم إليك الآخرون');busy=false;return;}catch(e){}}
  say(NONET);
 }catch(e){say(NONET);}
 busy=false;
}
$('anyRoom').addEventListener('click',anyRoom);
/* ---- in-game keyboard (native keyboard never opens) ---- */
const KB={ar:[['ض','ص','ث','ق','ف','غ','ع','ه','خ','ح','ج'],['ش','س','ي','ب','ل','ا','ت','ن','م','ك','ط'],['ئ','ء','ؤ','ر','ى','ة','و','ز','ظ','د','ذ']],en:[['q','w','e','r','t','y','u','i','o','p'],['a','s','d','f','g','h','j','k','l'],['z','x','c','v','b','n','m']],num:[['1','2','3','4','5','6','7','8','9','0'],['-','_','.',',','!','?','@','#'],['(',')',':',';','/','+','=','*']]};
let kbL='ar',kbT=null,kbUp=false;const kbEl=document.createElement('div');kbEl.id='igk';$('trade').parentNode.appendChild(kbEl);
function kbInsert(s){const i=kbT;if(!i)return;const a=i.selectionStart==null?i.value.length:i.selectionStart,b=i.selectionEnd==null?a:i.selectionEnd;const max=+i.maxLength>0?+i.maxLength:999;if(s.length&&i.value.length-(b-a)+s.length>max)return;i.value=i.value.slice(0,a)+s+i.value.slice(b);try{i.setSelectionRange(a+s.length,a+s.length);}catch(e){}i.dispatchEvent(new Event('input',{bubbles:true}));}
function kbBack(){const i=kbT;if(!i)return;const a=i.selectionStart==null?i.value.length:i.selectionStart,b=i.selectionEnd==null?a:i.selectionEnd;if(a===b&&a>0){i.value=i.value.slice(0,a-1)+i.value.slice(b);try{i.setSelectionRange(a-1,a-1);}catch(e){}}else{i.value=i.value.slice(0,a)+i.value.slice(b);try{i.setSelectionRange(a,a);}catch(e){}}i.dispatchEvent(new Event('input',{bubbles:true}));}
function kbRender(){
 kbEl.innerHTML='';
 const mk=(txt,cls,fn)=>{const b=document.createElement('button');b.type='button';b.textContent=txt;if(cls)b.className=cls;b.addEventListener('pointerdown',e=>{e.preventDefault();});b.addEventListener('click',e=>{e.preventDefault();fn();if(kbT)kbT.focus({preventScroll:true});});return b;};
 for(const row of KB[kbL]){const r=document.createElement('div');r.className='kr';for(const k of row)r.appendChild(mk(kbUp&&kbL==='en'?k.toUpperCase():k,'',()=>kbInsert(kbUp&&kbL==='en'?k.toUpperCase():k)));kbEl.appendChild(r);}
 const r=document.createElement('div');r.className='kr';
 r.appendChild(mk(kbL==='ar'?'EN':kbL==='en'?'123':'ع','w',()=>{kbL=kbL==='ar'?'en':kbL==='en'?'num':'ar';kbRender();}));
 if(kbL==='en')r.appendChild(mk('⇧','w',()=>{kbUp=!kbUp;kbRender();}));
 r.appendChild(mk('مسافة','sp',()=>kbInsert(' ')));
 r.appendChild(mk('⌫','w',kbBack));
 r.appendChild(mk('إدخال','w ok',()=>{if(!kbT)return;const i=kbT;i.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',code:'Enter',bubbles:true}));if(i.style.display!=='none'&&document.activeElement===i&&!i.dataset.keep){}}));
 r.appendChild(mk('إخفاء','w',()=>kbHide()));
 kbEl.appendChild(r);
}
function kbShow(i){kbT=i;kbRender();kbEl.classList.add('on');document.body.classList.add('igk');}
function kbHide(){kbEl.classList.remove('on');document.body.classList.remove('igk');if(kbT)kbT.blur();kbT=null;}
function kbPrep(i){if(i.dataset.igk)return;i.dataset.igk=1;i.setAttribute('inputmode','none');i.setAttribute('autocomplete','off');i.addEventListener('focus',()=>{kbShow(i);setTimeout(()=>{try{i.scrollIntoView({block:'center',behavior:'smooth'});}catch(e){}},60);});}
function kbScan(){for(const i of document.querySelectorAll('input[type=text],input:not([type]),input[type=tel],input[type=search],input[type=number]'))kbPrep(i);}
kbScan();new MutationObserver(kbScan).observe(document.body,{childList:true,subtree:true});
document.addEventListener('pointerdown',e=>{if(kbEl.classList.contains('on')&&!kbEl.contains(e.target)&&e.target.tagName!=='INPUT'&&e.target.tagName!=='LABEL')kbHide();},true);



