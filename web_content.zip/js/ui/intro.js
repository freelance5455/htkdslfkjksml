/* Intro – malé popup okno nad animovaným pozadím: název hry a výběr, jak začít.
   Události: start (pokračovat/nový profil úspěšně, jde se do menu)
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';

  BD.ui.components.Intro = {
    emits: ['start'],
    template:
      '<div class="intro">' +
        '<svg class="intro-logo" width="76" height="76" viewBox="0 0 32 32">' +
          '<circle cx="12" cy="13" r="8" fill="#e077c0"></circle><circle cx="21" cy="19" r="7" fill="#4a8fdc"></circle>' +
          '<circle cx="12" cy="24" r="4.5" fill="#e3a23a"></circle><ellipse cx="9.5" cy="10" rx="2.5" ry="1.5" fill="#fff" opacity=".5"></ellipse>' +
        '</svg>' +
        '<h1 class="intro-title">BubbleDefence</h1>' +
        '<div class="intro-sub">Stav labyrint z věží. Spoj je. Zastav bubliny.</div>' +
        '<div class="intro-actions">' +
          '<button v-if="saved" class="btn primary big" @click="cont"><ic n="play"></ic> Pokračovat v postupu</button>' +
          '<button class="btn big" :class="{primary: !saved}" @click="newLocal"><ic n="plus"></ic> Nová lokální hra</button>' +
          '<button class="btn big" @click="$refs.file.click()"><ic n="upload"></ic> Načíst postup z JSON</button>' +
          '<input ref="file" type="file" accept=".json,.txt,application/json,text/plain" hidden @change="onFile">' +
        '</div>' +
        '<div class="intro-msg err" v-if="msg">{{ msg }}</div>' +
        '<div class="intro-foot">v{{ version }} · funguje offline · postup se ukládá jen v tomto prohlížeči</div>' +
      '</div>',
    data: function () { return { msg: '', saved: BD.store.hasSaved(), version: BD.VERSION }; },
    methods: {
      cont: function () { this.$emit('start'); },
      newLocal: async function () {
        if (this.saved) {
          var ok = await BD.ui.confirm('Nová lokální hra smaže celý uložený postup v tomto prohlížeči (story, free hru i uložené levely). Pokračovat?', { ok: 'Smazat a začít znovu' });
          if (!ok) return;
        }
        BD.store.newProfile();
        this.$emit('start');
      },
      onFile: function (ev) {
        var self = this, f = ev.target.files && ev.target.files[0];
        ev.target.value = '';
        if (!f) return;
        if (f.size > 5 * 1024 * 1024) { self.msg = 'Soubor je příliš velký.'; return; }
        var r = new FileReader();
        r.onload = function () {
          var res = BD.store.importJSON(String(r.result));
          if (res.ok) { self.msg = ''; self.$emit('start'); } else self.msg = res.error;
        };
        r.onerror = function () { self.msg = 'Soubor se nepodařilo načíst.'; };
        r.readAsText(f);
      },
    },
  };
})(window.BD);
