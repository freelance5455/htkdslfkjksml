/* UI: overlay, modal accessible (fokus + Escape), toast, HUD, panel pengaturan, dialog sandi & konfirmasi. Tanpa alert/confirm/prompt. */
(function (g) {
  'use strict';
  const SU = g.SU, $ = SU.util.$, doc = g.document;
  const h = function (tag, props, kids) {
    const e = doc.createElement(tag);
    Object.keys(props || {}).forEach(function (k) {
      if (k === 'text') e.textContent = props[k]; else if (k === 'class') e.className = props[k];
      else if (k.indexOf('on') === 0) e.addEventListener(k.slice(2), props[k]); else e.setAttribute(k, props[k]);
    });
    (kids || []).forEach(function (c) { if (c) e.appendChild(typeof c === 'string' ? doc.createTextNode(c) : c); });
    return e;
  };
  const UI = (SU.ui = { h: h });

  UI.overlay = {
    show: function (o) {
      $('overlayTitle').textContent = o.title; $('overlayMessage').textContent = o.msg || '';
      const box = $('overlayActions'); box.textContent = '';
      (o.buttons || []).forEach(function (b, i) {
        const el = h('button', { type: 'button', class: 'btn ' + (b.cls || ''), text: b.label, onclick: b.onClick });
        box.appendChild(el); if (i === 0) g.setTimeout(function () { el.focus(); }, 0);
      });
      $('gameOverlay').style.display = 'flex';
    },
    hide: function () { $('gameOverlay').style.display = 'none'; }
  };

  let modalState = null;
  UI.modal = {
    open: function (title, body, onClose) {
      UI.modal.close(true);
      const root = $('modalRoot'), prev = doc.activeElement;
      const card = h('div', { class: 'modal', role: 'dialog', 'aria-modal': 'true', 'aria-label': title }, [h('h3', { text: title }), body]);
      root.textContent = ''; root.appendChild(card); root.hidden = false;
      const key = function (e) {
        if (e.key === 'Escape') { e.preventDefault(); if (onClose) onClose(); return; }
        if (e.key !== 'Tab') return;
        const f = card.querySelectorAll('button,input,select,a[href]'); if (!f.length) return;
        const a = f[0], z = f[f.length - 1];
        if (e.shiftKey && doc.activeElement === a) { e.preventDefault(); z.focus(); } else if (!e.shiftKey && doc.activeElement === z) { e.preventDefault(); a.focus(); }
      };
      doc.addEventListener('keydown', key, true);
      modalState = { prev: prev, key: key };
      const first = card.querySelector('button,input,select'); if (first) first.focus();
    },
    close: function (silent) {
      const root = $('modalRoot'); root.hidden = true; root.textContent = '';
      if (modalState) { doc.removeEventListener('keydown', modalState.key, true); const p = modalState.prev; modalState = null; if (!silent && p && p.focus) p.focus(); }
    }
  };

  let toastT = 0;
  UI.toast = function (msg) {
    const t = $('toast'); t.textContent = msg; t.classList.add('show');
    g.clearTimeout(toastT); toastT = g.setTimeout(function () { t.classList.remove('show'); }, 2600);
  };

  let lastKey = '';
  UI.hud = function (v) {
    const key = JSON.stringify(v); if (key === lastKey) return; lastKey = key;
    $('scoreValue').textContent = v.score; $('livesValue').textContent = v.lives; $('highScoreValue').textContent = v.high;
    const ind = $('gameIndicators'); ind.textContent = '';
    v.badges.forEach(function (b) { ind.appendChild(h('span', { class: 'badge ' + b.cls, text: b.text })); });
    const ch = $('powerupsContainer'); ch.textContent = '';
    v.chips.forEach(function (c) { ch.appendChild(h('span', { class: 'chip', style: 'border-color:' + c.color, text: c.tag + ' ' + c.name + ' ' + c.left + ' dtk' })); });
    const d = $('dashButton'); d.textContent = v.dashLabel; d.disabled = !v.dashEnabled;
  };
  UI.hudReset = function () { lastKey = ''; };

  UI.confirm = function (o) {
    const ok = h('button', { type: 'button', class: 'btn danger', text: o.confirmLabel, disabled: 'disabled' });
    const cancel = h('button', { type: 'button', class: 'btn primary', text: 'Batal', onclick: o.onCancel });
    let left = o.delay || 0, timer = 0;
    const label = function () { ok.textContent = left > 0 ? o.confirmLabel + ' (' + left + ')' : o.confirmLabel; };
    label();
    const arm = function () { ok.removeAttribute('disabled'); label(); };
    if (left > 0) timer = g.setInterval(function () { left--; label(); if (left <= 0) { g.clearInterval(timer); arm(); } }, 1000); else arm();
    ok.addEventListener('click', function () { g.clearInterval(timer); o.onConfirm(); });
    cancel.addEventListener('click', function () { g.clearInterval(timer); });
    UI.modal.open(o.title, h('div', {}, [h('p', { class: 'note', text: o.text }), h('div', { class: 'actions' }, [ok, cancel])]), function () { g.clearInterval(timer); o.onCancel(); });
  };

  UI.password = function (o) {
    const inp = h('input', { type: 'password', id: 'pwInput', autocomplete: 'off', 'aria-label': 'Kata sandi tema Special' });
    const err = h('p', { class: 'error', role: 'alert' });
    const submit = function () { if (o.check(inp.value)) o.onOk(); else { err.textContent = 'Kata sandi salah. Tema Special tidak dibuka.'; inp.select(); } };
    inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); submit(); } });
    UI.modal.open('Buka tema Special', h('div', {}, [
      h('p', { class: 'note', text: 'Tema Special adalah easter egg lokal. Kata sandi disimpan di dalam kode game sehingga bukan fitur keamanan.' }),
      inp, err, h('div', { class: 'actions' }, [h('button', { type: 'button', class: 'btn primary', text: 'Buka', onclick: submit }), h('button', { type: 'button', class: 'btn', text: 'Batal', onclick: o.onCancel })])
    ]), o.onCancel);
  };

  /* api: {settings, unlocks, change(patch), theme(id)->bool, exportBackup(), importFile(file), reset(scope), close()} */
  UI.settings = function (api) {
    const S = api.settings, row = function (label, el, id) { return h('div', { class: 'row' }, [h('label', { for: id, text: label }), el]); };
    const sel = function (id, opts, val, fn) { const s = h('select', { id: id }); opts.forEach(function (o) { const e = h('option', { value: o[0], text: o[1] }); if (o[0] === val) e.selected = true; s.appendChild(e); }); s.addEventListener('change', function () { fn(s.value, s); }); return s; };
    const chk = function (id, val, fn) { const c = h('input', { type: 'checkbox', id: id }); c.checked = !!val; c.addEventListener('change', function () { fn(c.checked); }); return c; };
    const rng = function (id, val, fn) { const r = h('input', { type: 'range', id: id, min: '1', max: '100', value: String(val) }); r.addEventListener('input', function () { fn(parseInt(r.value, 10)); }); return r; };
    const themes = [['classic', 'Klasik'], ['dark', 'Gelap'], ['forest', 'Hutan'], ['neon', 'Neon'], ['light', 'Terang'], ['special', api.unlocks.special ? 'Special' : 'Special (terkunci)']];
    const file = h('input', { type: 'file', accept: 'application/json,.json', class: 'hidden', 'aria-label': 'Pilih berkas backup' });
    file.addEventListener('change', function () { if (file.files && file.files[0]) api.importFile(file.files[0]); file.value = ''; });
    const body = h('div', { class: 'settings' }, [
      row('Musik latar', chk('sBg', S.bgSound, function (v) { api.change({ bgSound: v }); }), 'sBg'),
      row('Volume musik', rng('sBgVol', S.bgVolume, function (v) { api.change({ bgVolume: v }); }), 'sBgVol'),
      row('Efek suara', chk('sFx', S.fxSound, function (v) { api.change({ fxSound: v }); }), 'sFx'),
      row('Volume efek', rng('sFxVol', S.fxVolume, function (v) { api.change({ fxVolume: v }); }), 'sFxVol'),
      row('Tema', sel('sTheme', themes, S.theme, function (v, el) { if (!api.theme(v)) el.value = S.theme; }), 'sTheme'),
      row('Kontrol', sel('sCtl', [['swipe', 'Swipe'], ['dpad', 'D-pad']], S.control, function (v) { api.change({ control: v }); }), 'sCtl'),
      row('Tampilkan FPS', chk('sFps', S.showFps, function (v) { api.change({ showFps: v }); }), 'sFps'),
      row('Kurangi gerakan & efek', chk('sRm', S.reducedMotion, function (v) { api.change({ reducedMotion: v }); }), 'sRm'),
      h('h4', { text: 'Backup data' }),
      h('div', { class: 'actions' }, [h('button', { type: 'button', class: 'btn', text: 'Ekspor backup', onclick: api.exportBackup }), h('button', { type: 'button', class: 'btn', text: 'Impor backup', onclick: function () { file.click(); } })]), file,
      h('h4', { text: 'Reset (hanya data game ini)' }),
      h('div', { class: 'actions col' }, [
        h('button', { type: 'button', class: 'btn danger', text: 'Reset pengaturan', onclick: function () { api.reset('settings'); } }),
        h('button', { type: 'button', class: 'btn danger', text: 'Hapus simpanan game', onclick: function () { api.reset('save'); } }),
        h('button', { type: 'button', class: 'btn danger', text: 'Reset progres (skor tertinggi, unlock, simpanan)', onclick: function () { api.reset('progress'); } }),
        h('button', { type: 'button', class: 'btn danger', text: 'Reset semua data game', onclick: function () { api.reset('all'); } })]),
      h('button', { type: 'button', class: 'btn primary wide', text: 'Tutup', onclick: api.close })
    ]);
    UI.modal.open('Pengaturan', body, api.close);
  };
})(typeof window !== 'undefined' ? window : globalThis);
