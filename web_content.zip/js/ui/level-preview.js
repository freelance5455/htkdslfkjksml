/* LevelPreview – malý SVG náhled tvaru levelu (okraj s bránami, skály, zdi, případně věže).
   Používá ho mapa levelů, menu „Pokračovat“, seznam map i editor.  1 buňka = 5 jednotek SVG.
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  var TT = BD.systems.towers.TYPES, G = BD.systems.grid, U = 5;

  BD.ui.components.LevelPreview = {
    props: { level: Object, towers: { type: Array, default: function () { return []; } }, grid: { type: Boolean, default: true } },
    template:
      '<svg class="lp" :viewBox="\'0 0 \' + (g.W + 2) * u + \' \' + (g.H + 2) * u" preserveAspectRatio="xMidYMid meet">' +
        '<rect :width="(g.W + 2) * u" :height="(g.H + 2) * u" rx="3" fill="#2a3a44"></rect>' +
        '<rect :x="u" :y="u" :width="g.W * u" :height="g.H * u" fill="#182420"></rect>' +
        '<g v-if="grid" stroke="rgba(255,255,255,.07)" stroke-width=".4">' +
          '<line v-for="x in g.w - 1" :key="\'x\' + x" :x1="x * u * 2 + u" :y1="u" :x2="x * u * 2 + u" :y2="(g.H + 1) * u"></line>' +
          '<line v-for="y in g.h - 1" :key="\'y\' + y" :x1="u" :y1="y * u * 2 + u" :x2="(g.W + 1) * u" :y2="y * u * 2 + u"></line>' +
        '</g>' +
        '<g v-for="(q, i) in gates" :key="\'g\' + i">' +
          '<rect :x="q.x" :y="q.y" :width="q.w" :height="q.h" fill="#182420"></rect>' +
          '<rect :x="q.x" :y="q.y" :width="q.w" :height="q.h" :fill="q.exit ? \'rgba(240,191,76,.3)\' : \'rgba(229,107,97,.3)\'"></rect>' +
          '<path :d="q.arrow" :fill="q.exit ? \'#f0bf4c\' : \'#e56b61\'"></path>' +
        '</g>' +
        '<path v-if="wallD" :d="wallD" fill="#3a4e5b"></path>' +
        '<path v-if="rockD" :d="rockD" :transform="\'translate(\' + u + \' \' + u + \')\'" fill="#4a5368"></path>' +
        '<g v-for="(b, i) in orbs" :key="\'o\' + i">' +
          '<circle :cx="b.cx" :cy="b.cy" :r="b.r * 1.7" fill="rgba(150,200,255,.28)"></circle>' +
          '<circle :cx="b.cx" :cy="b.cy" :r="b.r" fill="#d4e8ff" stroke="#f0bf4c" stroke-width=".7"></circle>' +
          '<circle :cx="b.cx - b.r * .3" :cy="b.cy - b.r * .35" :r="b.r * .3" fill="#ffffff" opacity=".85"></circle>' +
        '</g>' +
        '<rect v-for="(t, i) in towers" :key="\'t\' + i" :x="t.x * u + u + .4" :y="t.y * u + u + .4" :width="(2 << t.tier) * u - .8" :height="(2 << t.tier) * u - .8" rx="2" :fill="color(t.type)" opacity=".9"></rect>' +
      '</svg>',
    data: function () { return { u: U }; },
    computed: {
      g: function () { return { w: this.level.w, h: this.level.h, W: this.level.w * BD.SUB, H: this.level.h * BD.SUB }; },
      wallD: function () {
        var u = this.u, d = [];
        (this.level.walls || []).forEach(function (r) { d.push('M' + (r[0] * u + u) + ' ' + (r[1] * u + u) + 'h' + u + 'v' + u + 'h' + (-u) + 'Z'); });
        return d.join('');
      },
      rockD: function () { var F = BD.render.field; return F.rockPath(F.rockRects(this.level.rocks || [], 0.07, 0.36), this.u); },
      orbs: function () {
        var u = this.u, ex = this.level.exit; if (!G.isOrb(ex)) return [];
        return G.orbBlobs(ex.orb).map(function (b) { return { cx: (b.cx + 1) * u, cy: (b.cy + 1) * u, r: b.r * u }; });
      },
      gates: function () {
        var W = this.g.W, H = this.g.H, out = [], all = this.level.spawns.map(function (s) { return [s, false]; });
        if (!G.isOrb(this.level.exit)) all.push([this.level.exit, true]);
        all.forEach(function (a) {
          var q = a[0], isExit = a[1], len = q.len * U, p = (q.pos + 1) * U, dir = G.SIDES[q.side], horiz = q.side === 'L' || q.side === 'R';
          var x = q.side === 'L' ? 0 : q.side === 'R' ? (W + 1) * U : p, y = q.side === 'T' ? 0 : q.side === 'B' ? (H + 1) * U : p;
          var w = horiz ? U : len, h = horiz ? len : U;
          var cx = x + w / 2, cy = y + h / 2, sx = isExit ? -dir[0] : dir[0], sy = isExit ? -dir[1] : dir[1], r = U * 0.38;
          var px = -sy, py = sx;                                                   // kolmice ke směru šipky
          var d = 'M' + (cx + sx * r) + ' ' + (cy + sy * r) + 'L' + (cx - sx * r * .6 + px * r * .7) + ' ' + (cy - sy * r * .6 + py * r * .7) +
                  'L' + (cx - sx * r * .6 - px * r * .7) + ' ' + (cy - sy * r * .6 - py * r * .7) + 'Z';
          out.push({ x: x, y: y, w: w, h: h, exit: isExit, arrow: d });
        });
        return out;
      },
    },
    methods: { color: function (type) { return TT[type] ? TT[type].color : '#888'; } },
  };
})(window.BD);
