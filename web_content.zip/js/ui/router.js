/* ===================================================================
 * VFL.UI.Router
 * روتر ساده مبتنی بر hash. صفحات مسابقات UI را از قوانین مسابقات جدا نگه می‌دارد —
 * این فایل فقط مسیریابی می‌کند، هیچ منطق مسابقه‌ای در آن نیست.
 * =================================================================== */
(function (VFL) {
  "use strict";

  VFL.UI = VFL.UI || {};

  var routes = {
    "home": { page: "home", nav: "home" },
    "team-select": { page: "teamSelect", nav: "home" },
    "dashboard": { page: "dashboard", nav: "home" },
    "competitions": { page: "competitions", nav: "competitions" },
    "fixtures": { page: "fixtures", nav: "competitions" },
    "standings": { page: "standings", nav: "standings" },
    "teams": { page: "teams", nav: "teams" },
    "squad": { page: "squad", nav: "teams" },
    "transfers": { page: "transfers", nav: "transfers" },
    "more": { page: "more", nav: "more" },
    "calendar": { page: "calendar", nav: "more" },
    "cup": { page: "cup", nav: "more" },
    "super-cup": { page: "superCup", nav: "more" },
    "champions-league": { page: "championsLeague", nav: "more" },
    "stats": { page: "stats", nav: "competitions" },
    "honours": { page: "honours", nav: "more" },
    "season-archive": { page: "seasonArchive", nav: "more" },
    "records": { page: "records", nav: "more" },
    "season": { page: "season", nav: "more" },
    "settings": { page: "settings", nav: "more" }
  };

  function parseHash() {
    var hash = window.location.hash.replace(/^#\/?/, "");
    if (!hash) return { name: "home", params: {} };

    var parts = hash.split("/");
    if (parts[0] === "match" && parts[1]) return { name: "match", params: { id: parts[1] } };
    if (parts[0] === "team" && parts[1]) return { name: "team", params: { id: parts[1] } };
    if (parts[0] === "lineup" && parts[1]) return { name: "lineup", params: { id: parts[1] } };
    if (routes[parts[0]]) return { name: parts[0], params: {} };
    return { name: "home", params: {} };
  }

  VFL.UI.Router = {
    render: function () {
      var parsed = parseHash();
      var pageName = parsed.name === "match" ? "match" : parsed.name === "team" ? "teamProfile" : parsed.name === "lineup" ? "lineup" : (routes[parsed.name] || { page: "home" }).page;
      var navName = parsed.name === "match" ? "competitions" : parsed.name === "team" ? "teams" : parsed.name === "lineup" ? "teams" : (routes[parsed.name] || { nav: "home" }).nav;
      var pageModule = VFL.UI.Pages[pageName];
      var container = document.getElementById("app-main");

      if (!pageModule) {
        container.innerHTML = '<div class="empty-state"><strong>صفحه پیدا نشد</strong></div>';
        return;
      }

      pageModule.render(container, parsed.params);
      VFL.UI.Header.render();
      VFL.UI.BottomNav.render(navName);
      window.scrollTo(0, 0);
    },

    start: function () {
      window.addEventListener("hashchange", VFL.UI.Router.render);
      VFL.UI.Router.render();
    }
  };
})(window.VFL || (window.VFL = {}));
