/* OPERATION: DISCIPLINE — inicialização. NÃO encerra dias: apenas aplica conquistas/desafios (post), migra/persiste se necessário e avisa. */
(function(){'use strict';
var OD=globalThis.OD,UI=OD.UI,App=UI.App;
window.addEventListener('error',function(e){UI.toast('Erro inesperado: '+(e.message||e))});
window.addEventListener('unhandledrejection',function(e){UI.toast('Erro inesperado: '+((e.reason&&e.reason.message)||e.reason))});
function boot(){UI.run(function(){},null,true);UI.draw()}
if(App.notes&&App.notes.length)setTimeout(function(){UI.toast('Dados antigos ajustados: '+App.notes.slice(0,3).join(' ')+(App.notes.length>3?' (+'+(App.notes.length-3)+')':''),1)},300);
boot();
var day=UI.td();
document.addEventListener('visibilitychange',function(){if(document.hidden)return;if(UI.td()!==day){day=UI.td();App.cur=day}boot()});
})();
