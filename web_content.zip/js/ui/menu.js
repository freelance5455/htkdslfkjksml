'use strict';
/* ================= menu logic ================= */
const msgEl=$('msg');const say=t=>{msgEl.textContent=t||'';};
let wantMode='survival',wantWT='forest',frT=null,tab='c',shTab='chars',shSel=null;
function view(id){
 for(const v of document.querySelectorAll('.view'))v.classList.toggle('on',v.id===id);say('');
 clearInterval(frT);frT=null;pv.on=(id==='vShop');
 $('langBtn').style.display=id==='vTitle'?'none':'';
 if(id==='vHome'){$('hello').textContent=S.name+(achClaimed()?'  ★'+achClaimed():'');renderEvtBox();$('resume').style.display=world.started?'block':'none';$('leave').style.display=Net.ok?'block':'none';$('homeCoins').textContent=S.coins;renderHome();updateFriendsUI();}
 if(id==='vLogin')$('uname').value='';
 if(id==='vOn'){renderRecent();$('onWarn').style.display=IN_PREVIEW?'block':'none';}
 if(id==='vShop'){initPreview();renderShop();}
 if(id==='vWheel'){$('whMsg').textContent='';renderWheel();}
 if(id==='vHub'){renderHub();}
 if(id==='vWorld'){renderWorld();}
 if(id==='vChests'){renderChests();}
 if(id==='vRecharge'){renderPacks();$('rechCoins').textContent=S.coins;$('orderMsg').textContent='';$('orderCopy').style.display='none';}
 if(id==='vFriends'){updateFriendsUI();Pres.refresh();frT=setInterval(()=>Pres.refresh(),10000);}
 $('menuCard').scrollTop=0;
}

