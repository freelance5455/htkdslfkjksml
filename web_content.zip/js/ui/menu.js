'use strict';
/* ================= menu logic ================= */
const msgEl=$('msg');const say=t=>{msgEl.textContent=t||'';};
let wantMode='survival',wantWT='forest',frT=null,tab='c',shTab='chars',shSel=null;
function view(id){
 for(const v of document.querySelectorAll('.view'))v.classList.toggle('on',v.id===id);say('');
 clearInterval(frT);frT=null;pv.on=(id==='vShop');
 $('langBtn').style.display=id==='vTitle'?'none':'';
 if(id==='vHome'){$('hello').textContent=S.name;$('resume').style.display=world.started?'block':'none';$('leave').style.display=Net.ok?'block':'none';$('homeCoins').textContent=S.coins;renderHome();updateFriendsUI();}
 if(id==='vLogin')$('uname').value=S.name||'';
 if(id==='vOn'){renderRecent();$('onWarn').style.display=IN_PREVIEW?'block':'none';}
 if(id==='vShop'){initPreview();renderShop();}
 if(id==='vRecharge'){renderPacks();$('rechCoins').textContent=S.coins;$('orderMsg').textContent='';$('orderCopy').style.display='none';}
 if(id==='vFriends'){updateFriendsUI();Pres.refresh();frT=setInterval(()=>Pres.refresh(),10000);}
 $('menuCard').scrollTop=0;
}
function renderHome(){
 const g=giftState();$('chest').textContent=g.can?('افتح صندوق اليوم (اليوم '+((g.n%28)+1)+' من 28)'):'تم استلام صندوق اليوم. عد غداً';
 $('chest').style.opacity=g.can?1:.6;renderQuests();$('tokBox').textContent=S.token||'';
}
/* ---- 3D preview ---- */
const pv={on:false,r:null,s:null,c:null,ch:null,t:0,id:null};
function initPreview(){
 if(pv.r)return;
 try{
  pv.r=new T.WebGLRenderer({canvas:$('pvCanvas'),antialias:true,alpha:true});pv.r.setSize(360,360,false);
  pv.s=new T.Scene();pv.c=new T.PerspectiveCamera(35,1,.1,50);pv.c.position.set(0,1.5,6.2);pv.c.lookAt(0,1.3,0);
  pv.s.add(new T.HemisphereLight(0xffffff,0x556677,.95));const d=new T.DirectionalLight(0xffffff,.8);d.position.set(3,5,4);pv.s.add(d);
 }catch(e){pv.r=null;}
}
function setPreview(skinId,armor){
 if(!pv.r)return;if(pv.ch)pv.s.remove(pv.ch.g);
 pv.ch=makeChar(skinById(skinId));decorChar(pv.ch,skinId,armor||'');pv.s.add(pv.ch.g);
}
function renderPreview(dt){if(!pv.r||!pv.on||!pv.ch)return;pv.t+=dt;pv.ch.g.rotation.y=pv.t*.9;animAura(pv.ch,pv.t);pv.r.render(pv.s,pv.c);}
/* ---- shop ---- */
const hex=n=>'#'+('000000'+n.toString(16)).slice(-6);
function shopItems(){
 if(shTab==='chars')return SKINS.filter(k=>!k.secret||S.owned.includes(k.id)).map(k=>({id:k.id,n:k.n,p:k.p,own:S.owned.includes(k.id),on:S.skin===k.id,ab:k.ab,cols:[k.body,k.pants,k.hatC||k.skin]}));
 if(shTab==='weap')return Object.keys(WEAPS).map(id=>({id,n:WEAPS[id].n,p:WEAPS[id].p,own:(S.stock||[]).includes(id),on:false,ab:WEAPS[id].ranged?'سهام تنفجر وتؤذي من حولها':'ضرر '+WEAPS[id].dmg+(WEAPS[id].burn?' + حرق':''),cols:[WEAPS[id].col||0xaa7733]}));
 return Object.keys(ARMORS).map(id=>({id,n:ARMORS[id].n,p:ARMORS[id].p,own:(S.armors||[]).includes(id),on:S.armor===id,ab:'يقلل الضرر '+Math.round(ARMORS[id].red*100)+'%',cols:[ARMORS[id].c]}));
}
function renderShop(){
 const box=$('skins');box.innerHTML='';const items=shopItems();
 if(!shSel||!items.some(i=>i.id===shSel))shSel=(items.find(i=>i.on)||items[0]).id;
 for(const it of items){
  const b=document.createElement('button');b.className='skin'+(shSel===it.id?' sel':'');
  b.innerHTML='<div class="sw">'+it.cols.map(c=>'<i style="background:'+hex(c)+'"></i>').join('')+'</div><b>'+it.n+'</b><span>'+(it.on?'مختارة':it.own?'ملكك':'شراء '+it.p)+'</span>';
  b.addEventListener('click',()=>{shSel=it.id;renderShop();});box.appendChild(b);
 }
 const cur=items.find(i=>i.id===shSel);
 $('menuCoins').textContent='العملات: '+S.coins;
 $('pvName').textContent=cur.n;$('pvAb').textContent=cur.ab||'';
 const a=shTab==='armor'?shSel:S.armor||'',sk=shTab==='chars'?shSel:S.skin;
 if(pv.id!==sk+'|'+a){pv.id=sk+'|'+a;setPreview(sk,a);}
 $('shopAct').textContent=cur.on?(shTab==='armor'?'إزالة الدرع':'مختارة'):cur.own?(shTab==='weap'?'مملوك':'اختيار'):'شراء '+cur.p;
 $('secretRow').style.display=shTab==='chars'?'flex':'none';
 for(const x of document.querySelectorAll('.shTab'))x.classList.toggle('on',x.dataset.sh===shTab);
}
$('shopAct').addEventListener('click',()=>{
 const cur=shopItems().find(i=>i.id===shSel);if(!cur)return;
 if(!cur.own){
  if(S.coins<cur.p){say('تحتاج '+(cur.p-S.coins)+' عملة إضافية. اجمعها بالقتال والمهام أو اشحن رصيدك.');return;}
  S.coins-=cur.p;beep(660,.15,'triangle');cloud.event('buy',cur.id);
  if(shTab==='chars'){S.owned.push(cur.id);S.skin=cur.id;}
  else if(shTab==='weap'){S.stock=(S.stock||[]).concat(cur.id);}
  else{S.armors=(S.armors||[]).concat(cur.id);S.armor=cur.id;}
 }else if(shTab==='chars')S.skin=cur.id;
 else if(shTab==='armor')S.armor=cur.on?'':cur.id;
 save();cloud.push();pv.id=null;renderShop();setPlayerSkin();
});
for(const b of document.querySelectorAll('.shTab'))b.addEventListener('click',()=>{shTab=b.dataset.sh;shSel=null;pv.id=null;renderShop();});
$('secretGo').addEventListener('click',async()=>{
 const ok=await checkSecret($('secret').value);
 if(ok){if(!S.owned.includes('phoenix'))S.owned.push('phoenix');S.skin='phoenix';save();cloud.push();cloud.event('secret','phoenix');shTab='chars';shSel='phoenix';pv.id=null;renderShop();setPlayerSkin();say('تم فتح الشخصية السرية: العنقاء!');beep(900,.3,'triangle',.07);}
 else{say('الرمز غير صحيح');cloud.event('secret_fail','');}
 $('secret').value='';
});
$('chest').addEventListener('click',()=>{
 const r=claimGift();if(!r){say('استلمت صندوق اليوم. عد غداً!');return;}
 say('صندوق اليوم: +'+r.n+' عملة (سلسلة '+r.streak+' يوم)'+r.extra);renderHome();$('homeCoins').textContent=S.coins;
});
function renderRecent(){
 const box=$('recent');box.innerHTML='';
 if(!S.recent.length){box.style.display='none';return;}
 box.style.display='flex';
 for(const r of S.recent){
  const b=document.createElement('button');b.className='chip';b.textContent=r.name+' · '+r.code;
  b.addEventListener('click',()=>{$('rname').value=r.name;$('rcode').value=r.code;setTab(r.kind||'j');});
  box.appendChild(b);
 }
}
function pushRecent(name,code,kind){
 S.recent=S.recent.filter(r=>!(r.name===name&&r.code===code));S.recent.unshift({name,code,kind});S.recent=S.recent.slice(0,5);save();
}
function showMenu(on,vw){
 $('menu').style.display=on?'flex':'none';
 playing=!on&&world.started;
 $('hud').classList.toggle('on',!on);
 if(on){$('craft').classList.remove('on');$('bag').classList.remove('on');$('trade').classList.remove('on');try{snapshot();save();}catch(e){}}
 for(const id of['bAtk','bJump','bEat','bCraft','bRun'])$(id).style.display=on?'none':'grid';
 if(on){$('bTalk').style.display='none';$('bUse').style.display='none';for(const id of['bFly','bDown','bTime'])$(id).style.display='none';setSwimUI(false);view(vw||(S.name?'vHome':(world.started?'vLogin':'vTitle')));}
 else{$('bEat').style.display=creative?'none':'grid';for(const id of['bFly','bDown','bTime'])$(id).style.display=creative?'grid':'none';setSwimUI(!!(P&&P.swim));}
}
function launch(o){
 world.room=o.room;world.wt=o.wt||'forest';world.mode=o.mode;
 initWorld(o.room,o.mode,o.wt||'forest');
 if(o.joined){for(const b of o.joined.builds||[])addPiece(b);setOthers(o.joined.players||[]);tod=o.joined.tod||tod;day=o.joined.day||day;}
 else if(!o.online)restoreSnapshot();
 grantStock();buildHot();
 document.body.classList.toggle('big',!!WT.big);world.started=true;ensureQuests();cloud.status('online');cloud.event('start',(o.online?'online ':'offline ')+world.wt+' '+o.mode);
 $('bChat').style.display=o.online?'grid':'none';$('chat').classList.toggle('on',!!o.online);
 $('onlineV').textContent=o.online?(Net.others.size+1)+' لاعب':'أنت';
 const rt=$('roomTag');if(o.online){rt.textContent='الغرفة: '+Net.room+'  |  الرمز: '+Net.code;rt.style.display='block';}else rt.style.display='none';
 showMenu(false);
 try{if(document.documentElement.requestFullscreen&&!document.fullscreenElement)document.documentElement.requestFullscreen().then(()=>{try{screen.orientation.lock('landscape').catch(()=>{});}catch(e){}}).catch(()=>{});}catch(e){}
 toast(creative?'وضع الإبداع: اضغط "طيران" لتحلّق':'احمِ نفسك قبل حلول الليل!');
}
let busy=false;
async function enterRoom(kind,name,code,mode,wt){
 if(busy)return;busy=true;say(kind==='c'?'جارٍ إنشاء الغرفة…':'جارٍ البحث عن الغرفة…');
 try{
  if(kind==='c'){await hostRoom(name,code,mode||'survival',wt||'forest');pushRecent(name,code,'c');launch({room:name,mode:mode||'survival',wt:wt||'forest',online:true});}
  else{const m=await joinRoom(name,code);pushRecent(name,code,'j');launch({room:m.seed,mode:m.mode,wt:m.wt||'forest',online:true,joined:m});}
  say('');
 }catch(e){const t=e&&e.message||NONET;say(t);toast(t);}
 busy=false;
}
function setTab(k){
 tab=k;for(const x of document.querySelectorAll('.tabBtn'))x.classList.toggle('on',x.dataset.tab===k);
 $('createOpts').style.display=k==='c'?'flex':'none';$('goOn').textContent=k==='c'?'أنشئ الغرفة':'ادخل الغرفة';
 $('onNote').textContent=k==='c'?'شارك اسم الغرفة والرمز مع أصدقائك ليدخلوا معك. صاحب الغرفة يجب أن يبقى داخل اللعبة.':'اكتب اسم الغرفة والرمز اللذين أعطاك إياهما صاحب الغرفة.';
 say('');
}
function afterLogin(){Pres.start();cloud.listen();cloud.status('online');if(S.tamper){cloud.event('coin_tamper','checksum mismatch');S.tamper=false;}view('vHome');}
$('goLogin').addEventListener('click',()=>{const n=$('uname').value.trim().slice(0,14);if(!n){say('اكتب اسمك أولاً');return;}loadAcc(n);S.consent=$('consent').checked;save();afterLogin();});
$('uname').addEventListener('keydown',e=>{if(e.key==='Enter')$('goLogin').click();});
$('goRestore').addEventListener('click',async()=>{say('جارٍ البحث…');const r=await restoreByToken($('rtok').value);if(r.ok){afterLogin();toast('تم استرجاع حسابك');}else say(r.err);});
$('copyTok').addEventListener('click',()=>{try{navigator.clipboard.writeText(S.token).then(()=>toast('تم نسخ الرمز'),()=>toast(S.token));}catch(e){toast(S.token);}});
$('logout').addEventListener('click',()=>{cloud.status('offline');cloud.unlisten();Pres.stop();Net.close();S.name='';DB.last='';saveDB();world.started=false;initWorld('عالمي','survival','forest');view('vLogin');});
$('startBtn').addEventListener('click',()=>{beep(600,.1,'triangle');view(S.name?'vHome':'vLogin');});
$('toOff').addEventListener('click',()=>{view('vOff');$('world').value=$('world').value||'عالمي';});
$('toOn').addEventListener('click',()=>{view('vOn');if(!$('rcode').value)$('rcode').value=String(Math.floor(1000+Math.random()*9000));});
$('toFr').addEventListener('click',()=>view('vFriends'));
$('toShop').addEventListener('click',()=>view('vShop'));
$('toRecharge').addEventListener('click',()=>view('vRecharge'));
$('oSend').addEventListener('click',sendOrder);
$('resume').addEventListener('click',()=>showMenu(false));
$('leave').addEventListener('click',()=>{Net.close();world.started=false;initWorld('عالمي','survival','forest');$('roomTag').style.display='none';view('vHome');toast('غادرت الغرفة');});
for(const b of document.querySelectorAll('.back'))b.addEventListener('click',()=>view('vHome'));
for(const b of document.querySelectorAll('.modeBtn'))b.addEventListener('click',()=>{wantMode=b.dataset.m;for(const x of document.querySelectorAll('.modeBtn'))x.classList.toggle('on',x.dataset.m===wantMode);});
for(const b of document.querySelectorAll('.wtBtn'))b.addEventListener('click',()=>{wantWT=b.dataset.w;for(const x of document.querySelectorAll('.wtBtn'))x.classList.toggle('on',x.dataset.w===wantWT);});
for(const b of document.querySelectorAll('.tabBtn'))b.addEventListener('click',()=>setTab(b.dataset.tab));
$('goOff').addEventListener('click',()=>{Net.close();launch({room:($('world').value.trim()||'عالمي'),mode:wantMode,wt:wantWT,online:false});});
$('goOn').addEventListener('click',()=>{
 const name=$('rname').value.trim(),code=$('rcode').value.trim();
 if(!name){say('اكتب اسم الغرفة');return;}
 if(code.length<3){say('الرمز يجب أن يكون 3 خانات على الأقل');return;}
 enterRoom(tab,name,code,wantMode,wantWT);
});
$('bFriends').addEventListener('click',()=>showMenu(true,'vFriends'));

