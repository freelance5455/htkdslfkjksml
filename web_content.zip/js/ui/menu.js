/* MainMenu – menu vlevo (Story, Free, Editor, Nastavení), vpravo náhled podle toho,
   nad čím je myš / co je vybrané. Kliknutí na položku spustí hru (okno se roztáhne),
   kromě Nastavení, které zůstane v okně.
   Události: launch ({to:'story-map'} | {to:'game', session} | {to:'editor', levelId}), back
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  var story = BD.data.story, presets = BD.data.presets;

  BD.ui.components.MainMenu = {
    emits: ['launch', 'back'],
    template:
      '<div class="menu" @pointerdown="ptr = $event.pointerType">' +
        '<nav class="mnav">' +
          '<div class="mbrand">' +
            '<svg width="30" height="30" viewBox="0 0 32 32"><circle cx="12" cy="13" r="8" fill="#e077c0"></circle><circle cx="21" cy="19" r="7" fill="#4a8fdc"></circle><circle cx="12" cy="24" r="4.5" fill="#e3a23a"></circle></svg>' +
            '<span>BubbleDefence</span>' +
          '</div>' +
          '<div class="mlist">' +
            '<template v-for="s in shownSections" :key="s.id">' +
              '<button class="mi" :class="{on: sec === s.id}" @click="openSec(s)">' +
                '<ic :n="s.icon"></ic><span>{{ s.label }}</span><i class="badge" v-if="s.popup && unread"></i><ic v-if="s.subs" n="back" class="chev"></ic>' +
              '</button>' +
              '<div class="msub" v-if="s.subs && sec === s.id">' +
                '<button v-for="b in s.subs" :key="b.id" class="ms" :class="{on: sub === b.id, off: isOff(s.id, b.id)}"' +
                  ' @pointerenter="hoverSub($event, s.id, b.id)" @click="clickSub(s.id, b.id)">{{ b.label }}</button>' +
              '</div>' +
            '</template>' +
          '</div>' +
          '<button class="mi back" @click="$emit(\'back\')"><ic n="back"></ic><span>Zpět na úvod</span></button>' +
        '</nav>' +

        '<section class="mright">' +

          /* ---- STORY: pokračovat ---- */
          '<div class="pv" v-if="sec === \'story\' && sub === \'continue\'">' +
            '<h2 class="ph">Story mód · Pokračovat</h2>' +
            '<template v-if="storyCont">' +
              '<div class="pv-body">' +
                '<div class="pv-shape" v-if="storyCont.level"><bd-level-preview :level="storyCont.level" :towers="storyCont.towers"></bd-level-preview></div>' +
                '<div class="pv-info">' +
                  '<template v-if="storyCont.kind === \'save\'">' +
                    '<div class="pv-title">{{ storyCont.node.title }}</div>' +
                    '<div class="kv"><span>Vlna</span><b>{{ storyCont.wave }} / {{ storyCont.level.waves }}</b></div>' +
                    '<div class="kv"><span>Životy</span><b>{{ storyCont.lives }}</b></div>' +
                    '<div class="kv"><span>Zlato</span><b>{{ storyCont.gold }}</b></div>' +
                    '<div class="kv"><span>Uloženo</span><b>{{ storyCont.when }}</b></div>' +
                  '</template>' +
                  '<template v-else>' +
                    '<div class="pv-title">Mapa levelů</div>' +
                    '<div class="kv"><span>Splněno</span><b>{{ storyCont.done }} / {{ total }}</b></div>' +
                    '<div class="kv" v-if="storyCont.node"><span>Další level</span><b>{{ storyCont.node.title }}</b></div>' +
                  '</template>' +
                  '<button class="btn primary big" @click="storyContinue"><ic n="play"></ic> {{ storyCont.kind === \'save\' ? \'Pokračovat v levelu\' : \'Otevřít mapu\' }}</button>' +
                '</div>' +
              '</div>' +
            '</template>' +
            '<div class="empty" v-else>Zatím tu není nic rozehraného. Začni novou hrou.</div>' +
          '</div>' +

          /* ---- STORY: nová hra ---- */
          '<div class="pv" v-else-if="sec === \'story\' && sub === \'new\'">' +
            '<h2 class="ph">Story mód · Nová hra</h2>' +
            '<div class="pv-body">' +
              '<div class="pv-shape"><bd-level-preview :level="firstLevel"></bd-level-preview></div>' +
              '<div class="pv-info">' +
                '<div class="pv-title">Od začátku</div>' +
                '<p class="hint">Začneš tutoriálem (jde přeskočit) a pak procházíš mapu levelů. Další levely se odemykají postupně.</p>' +
                '<p class="hint warn" v-if="hasStoryProgress">Pozor: smaže se dosavadní postup ve story módu.</p>' +
                '<button class="btn primary big" @click="storyNew"><ic n="play"></ic> Začít novou hru</button>' +
              '</div>' +
            '</div>' +
          '</div>' +

          /* ---- FREE: pokračovat ---- */
          '<div class="pv" v-else-if="sec === \'free\' && sub === \'continue\'">' +
            '<h2 class="ph">Free mód · Pokračovat</h2>' +
            '<template v-if="freeCont">' +
              '<div class="pv-body">' +
                '<div class="pv-shape"><bd-level-preview :level="freeCont.level" :towers="freeCont.towers"></bd-level-preview></div>' +
                '<div class="pv-info">' +
                  '<div class="pv-title">{{ freeCont.title }}</div>' +
                  '<div class="kv"><span>Vlna</span><b>{{ freeCont.wave }}</b></div>' +
                  '<div class="kv"><span>Životy</span><b>{{ freeCont.lives }}</b></div>' +
                  '<div class="kv"><span>Zlato</span><b>{{ freeCont.gold }}</b></div>' +
                  '<div class="kv"><span>Nejlepší vlna</span><b>{{ best }}</b></div>' +
                  '<div class="kv"><span>Uloženo</span><b>{{ freeCont.when }}</b></div>' +
                  '<button class="btn primary big" @click="freeContinue"><ic n="play"></ic> Pokračovat</button>' +
                '</div>' +
              '</div>' +
            '</template>' +
            '<div class="empty" v-else>Zatím tu není žádná rozehraná free hra.</div>' +
          '</div>' +

          /* ---- FREE: nová hra – výběr mapy ---- */
          '<div class="pv" v-else-if="sec === \'free\' && sub === \'new\'">' +
            '<h2 class="ph">Free mód · Nová hra</h2>' +
            '<p class="hint">Nekonečné vlny na vybrané mapě. Vyber mapu:</p>' +
            '<div class="cards">' +
              '<button class="lcard" v-for="m in freeMaps" :key="m.key" @click="freeNew(m)">' +
                '<div class="lcard-shape"><bd-level-preview :level="m.level" :grid="false"></bd-level-preview></div>' +
                '<div class="lcard-name">{{ m.level.name }}</div>' +
                '<div class="lcard-sub">{{ m.sub }}</div>' +
              '</button>' +
            '</div>' +
          '</div>' +

          /* ---- EDITOR ---- */
          '<div class="pv" v-else-if="sec === \'editor\'">' +
            '<h2 class="ph">Editor levelů</h2>' +
            '<p class="hint">Vyber uložený level a pokračuj, kde jsi skončil, nebo vytvoř nový.</p>' +
            '<div class="io-row">' +
              '<button class="btn" data-act="lv-import-file" @click="$refs.lvFile.click()"><ic n="upload"></ic> Načíst ze souboru</button>' +
              '<button class="btn" data-act="lv-import-text" :class="{on: pasteOpen}" @click="pasteOpen = !pasteOpen"><ic n="copy"></ic> Vložit text</button>' +
              '<button class="btn" data-act="lv-export-all" :disabled="!editorLevels.length" @click="exportAll"><ic n="download"></ic> Exportovat vše</button>' +
              '<input ref="lvFile" type="file" accept=".json,application/json" hidden @change="importFile">' +
            '</div>' +
            '<div class="io-paste" v-if="pasteOpen">' +
              '<textarea class="in" v-model="pasteText" rows="4" placeholder="Sem vlož text levelu…" data-role="lv-paste"></textarea>' +
              '<button class="btn primary" data-act="lv-paste-ok" :disabled="!pasteText.trim()" @click="importText(pasteText)">Načíst</button>' +
            '</div>' +
            '<div class="msg" :class="ioErr ? \'err\' : \'okk\'" v-if="ioMsg" data-role="io-msg">{{ ioMsg }}</div>' +
            '<div class="cards">' +
              '<button class="lcard add" @click="editorNew"><div class="lcard-plus"><ic n="plus"></ic></div><div class="lcard-name">Nový level</div></button>' +
              '<div class="lcard" v-for="l in editorLevels" :key="l.id" @click="editorOpen(l.id)" tabindex="0">' +
                '<div class="lcard-shape"><bd-level-preview :level="l" :grid="false"></bd-level-preview></div>' +
                '<div class="lcard-name">{{ l.name }}</div>' +
                '<div class="lcard-sub">{{ l.w }}×{{ l.h }} · {{ when(l.updated) }}</div>' +
                '<button class="lcard-del" title="Smazat" @click.stop="editorDelete(l)"><ic n="trash"></ic></button>' +
              '</div>' +
            '</div>' +
          '</div>' +

          /* ---- NASTAVENÍ ---- */
          '<bd-settings v-else-if="sec === \'settings\'"></bd-settings>' +

        '</section>' +
      '</div>',

    data: function () {
      return {
        sec: 'story', pasteOpen: false, pasteText: '', ioMsg: '', ioErr: false, sub: 'new', ptr: 'mouse', p: BD.store.profile,
        total: story.total, firstLevel: story.nodes[0].level,
        sections: [
          { id: 'story', label: 'Story mód', icon: 'book', subs: [{ id: 'continue', label: 'Pokračovat' }, { id: 'new', label: 'Nová hra' }] },
          { id: 'free', label: 'Free mód', icon: 'inf', subs: [{ id: 'continue', label: 'Pokračovat' }, { id: 'new', label: 'Nová hra' }] },
          { id: 'editor', label: 'Editor', icon: 'pencil' },
          { id: 'bestiary', label: 'Bestiář', icon: 'bookopen', popup: true },
          { id: 'studio', label: 'Studio', icon: 'tower', studio: true },
          { id: 'settings', label: 'Nastavení', icon: 'gear' },
        ],
      };
    },
    created: function () { this.sub = this.storyCont ? 'continue' : 'new'; },

    computed: {
      shownSections: function () { var on = BD.dev.studio; return this.sections.filter(function (s) { return !s.studio || on; }); },
      unread: function () { return BD.bestiary.unreadCount() > 0; },
      hasStoryProgress: function () { return this.p.story.completed.length > 0 || !!this.p.story.save; },
      best: function () { return this.p.free.best; },
      editorLevels: function () { return this.p.editor.levels; },

      storyCont: function () {
        var sv = this.p.story.save, n = sv && story.byId[sv.nodeId];
        if (sv && n) {
          var sn = sv.snapshot;
          return { kind: 'save', node: n, level: n.level, towers: sn.towers, wave: sn.wave | 0, lives: sn.lives, gold: sn.gold, when: BD.util.date(sv.savedAt) };
        }
        if (this.p.story.completed.length) {
          var nx = story.nextNode(this.p.story.completed);
          return { kind: 'map', node: nx, level: nx ? nx.level : null, towers: [], done: this.p.story.completed.length };
        }
        return null;
      },
      freeCont: function () {
        var sv = this.p.free.save;
        if (!sv) return null;
        var sn = sv.snapshot;
        return { title: sv.title, level: sv.level, towers: sn.towers, wave: sn.wave | 0, lives: sn.lives, gold: sn.gold, when: BD.util.date(sv.savedAt) };
      },
      freeMaps: function () {
        var out = presets.map(function (p) { return { key: p.id, level: p, sub: p.w + '×' + p.h + ' · ' + p.spawns.length + (p.spawns.length === 1 ? ' vstup' : ' vstupy') }; });
        this.p.editor.levels.forEach(function (l) { out.push({ key: l.id, level: l, sub: 'Můj level · ' + l.w + '×' + l.h + (BD.systems.levels.validate(l).ok ? '' : ' · nehratelný') }); });
        return out;
      },
    },

    methods: {
      when: function (t) { return BD.util.date(t); },
      isOff: function (sec, sub) {
        if (sub !== 'continue') return false;
        return sec === 'story' ? !this.storyCont : !this.freeCont;
      },
      openSec: function (s) {
        if (s.id === 'studio') { this.$emit('launch', { to: 'studio' }); return; }
        if (s.popup) { BD.bestiary.open(); return; }
        this.sec = s.id;
        if (s.subs && !s.subs.some(function (b) { return b.id === this.sub; }, this)) this.sub = s.subs[0].id;
        if (s.subs) this.sub = this.isOff(s.id, 'continue') ? 'new' : 'continue';
      },
      hoverSub: function (ev, sec, sub) { if (ev.pointerType === 'mouse' && sec === this.sec) this.sub = sub; },
      clickSub: function (sec, sub) {
        var firstTap = this.ptr !== 'mouse' && this.sub !== sub;   // na dotyku první klepnutí jen ukáže náhled
        this.sub = sub;
        if (firstTap || this.isOff(sec, sub)) return;
        if (sec === 'story') { if (sub === 'continue') this.storyContinue(); else this.storyNew(); }
        else if (sec === 'free' && sub === 'continue') this.freeContinue();
        /* free / nová hra: mapu vybereš vpravo */
      },

      storyContinue: function () {
        var sv = this.p.story.save, n = sv && story.byId[sv.nodeId];
        if (sv && n) this.$emit('launch', { to: 'game', session: { mode: n.tutorial ? 'tutorial' : 'story', nodeId: n.id, title: n.title, level: n.level, snapshot: sv.snapshot } });
        else this.$emit('launch', { to: 'story-map' });
      },
      storyNew: async function () {
        if (this.hasStoryProgress) {
          var ok = await BD.ui.confirm('Nová story hra smaže dosavadní postup ve story módu. Pokračovat?', { ok: 'Začít znovu' });
          if (!ok) return;
        }
        BD.store.resetStory();
        this.$emit('launch', { to: 'story-map' });
      },
      freeContinue: function () {
        var sv = this.p.free.save; if (!sv) return;
        this.$emit('launch', { to: 'game', session: { mode: 'free', title: sv.title, level: sv.level, snapshot: sv.snapshot } });
      },
      freeNew: async function (m) {
        var chk = BD.systems.levels.validate(m.level);
        if (!chk.ok) {                       /* rozdělaný level z editoru, který zatím nejde hrát */
          var open = await BD.ui.confirm('Level „' + m.level.name + '“ zatím nejde hrát: ' + chk.error + ' Otevřít ho v editoru a opravit?', { ok: 'Otevřít editor' });
          if (open && m.level.id) this.$emit('launch', { to: 'editor', levelId: m.level.id });
          return;
        }
        if (this.p.free.save) {
          var ok = await BD.ui.confirm('Nová free hra přepíše uloženou rozehranou hru. Pokračovat?', { ok: 'Přepsat' });
          if (!ok) return;
          this.p.free.save = null;
        }
        this.$emit('launch', { to: 'game', session: { mode: 'free', title: m.level.name, level: BD.util.clone(m.level), snapshot: null } });
      },

      ioSay: function (t, bad) { this.ioMsg = t; this.ioErr = !!bad; },
      importText: function (text) {
        var r = BD.store.importLevels(text);
        if (r.ok) { this.ioSay(r.count === 1 ? 'Level byl přidán do editoru.' : 'Načteno levelů: ' + r.count + '.'); this.pasteText = ''; this.pasteOpen = false; }
        else this.ioSay(r.error, true);
      },
      importFile: function (ev) {
        var self = this, f = ev.target.files && ev.target.files[0]; ev.target.value = '';
        if (!f) return;
        if (f.size > 2 * 1024 * 1024) { self.ioSay('Soubor je příliš velký.', true); return; }
        var r = new FileReader(); r.onload = function () { self.importText(String(r.result)); }; r.readAsText(f);
      },
      exportAll: function () {
        try { BD.ui.levelIO.download(BD.store.exportLevels(BD.store.profile.editor.levels), 'bubbledefence-levely.json'); this.ioSay('Soubor bubbledefence-levely.json je stažený.'); }
        catch (e) { this.ioSay('Export se nepovedl.', true); }
      },
      editorNew: function () { var L = BD.store.addEditorLevel(); this.$emit('launch', { to: 'editor', levelId: L.id }); },
      editorOpen: function (id) { this.$emit('launch', { to: 'editor', levelId: id }); },
      editorDelete: async function (l) {
        var ok = await BD.ui.confirm('Smazat level „' + l.name + '“?', { ok: 'Smazat' });
        if (ok) BD.store.removeEditorLevel(l.id);
      },
    },
  };
})(window.BD);
