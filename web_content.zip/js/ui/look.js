// Apariencia del modelo (visor B «piel y texturas»): textura propia, rugosidad, metalicidad y opacidad.
// Se guarda con el modelo (ajustes de IndexedDB) y se aplica igual en el visor y en el personaje del mundo.
// THREE llega por parámetro (no se importa de forma estática).

export const lookKey = (id) => `look:${id}`;
export const lookTexKey = (id) => `look-tex:${id}`;
export const BG_KEY = 'viewer-bg';

export const MAX_TEX_BYTES = 8 * 1024 * 1024;
export const MAX_BG_BYTES = 10 * 1024 * 1024;

export const DEFAULT_LOOK = Object.freeze({
  hasTex: false, // hay una textura guardada para este modelo
  force: false, // true: la textura pisa también la que ya traía el modelo
  rough: null, // null = la del modelo
  metal: null,
  alpha: 1,
  key: 1, // luz principal del visor B (1 = como el visor A)
  amb: 1, // luz ambiental
  exp: 1, // exposición (1 = sin mapeo de tonos)
});

const num = (v, lo, hi, d) => (typeof v === 'number' && Number.isFinite(v) ? Math.min(hi, Math.max(lo, v)) : d);

export function cleanLook(raw) {
  const r = raw && typeof raw === 'object' ? raw : {};
  return {
    hasTex: !!r.hasTex,
    force: !!r.force,
    rough: r.rough == null ? null : num(r.rough, 0, 1, null),
    metal: r.metal == null ? null : num(r.metal, 0, 1, null),
    alpha: num(r.alpha, 0.1, 1, 1),
    key: num(r.key, 0, 3, 1),
    amb: num(r.amb, 0, 3, 1),
    exp: num(r.exp, 0.2, 2.5, 1),
  };
}

// ¿Cambia algo del aspecto del modelo? (las luces y la exposición solo afectan al visor B, no al mundo)
export function changesMaterials(look) {
  return !!(look.hasTex || look.rough != null || look.metal != null || look.alpha < 1);
}

// Imagen (Blob) → textura de Three.js reducida a maxSize. equirect: como fondo panorámico.
export async function loadImageTexture(THREE, blob, { maxSize = 2048, equirect = false } = {}) {
  const bmp = await createImageBitmap(blob);
  const w = bmp.width, h = bmp.height;
  const k = Math.min(1, maxSize / Math.max(w, h));
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(w * k));
  canvas.height = Math.max(1, Math.round(h * k));
  canvas.getContext('2d').drawImage(bmp, 0, 0, canvas.width, canvas.height);
  bmp.close?.();
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  if (equirect) tex.mapping = THREE.EquirectangularReflectionMapping;
  return tex;
}

const materialsOf = (root) => {
  const out = new Set();
  root.traverse((o) => {
    if (!o.isMesh || !o.material) return;
    for (const m of Array.isArray(o.material) ? o.material : [o.material]) if (m) out.add(m);
  });
  return out;
};

// Aplica la apariencia sobre todos los materiales del grupo. Guarda el estado original de cada material la primera vez, así
// se puede volver atrás sin recrear el modelo. tex puede ser null.
export function applyLook(THREE, root, look, tex = null) {
  for (const m of materialsOf(root)) {
    const base = (m.userData.look0 ||= {
      map: m.map || null,
      color: m.color ? m.color.clone() : null,
      roughness: m.roughness,
      metalness: m.metalness,
      transparent: m.transparent,
      opacity: m.opacity,
    });
    const useTex = !!tex && (look.force || !base.map);
    const before = (m.map ? 1 : 0) + (m.transparent ? 2 : 0);
    m.map = useTex ? tex : base.map;
    if (m.color && base.color) {
      if (useTex) m.color.set(0xffffff); // el color base no debe teñir la textura nueva
      else m.color.copy(base.color);
    }
    if (m.roughness !== undefined) m.roughness = look.rough ?? base.roughness;
    if (m.metalness !== undefined) m.metalness = look.metal ?? base.metalness;
    m.transparent = base.transparent || look.alpha < 1;
    m.opacity = base.opacity * look.alpha;
    // Recompilar el sombreador solo si aparece o desaparece la textura o la transparencia (no al mover un deslizador).
    if (before !== (m.map ? 1 : 0) + (m.transparent ? 2 : 0)) m.needsUpdate = true;
  }
}

export async function readLook(store, id) {
  const look = cleanLook(await store.getSetting(lookKey(id), null).catch(() => null));
  const blob = look.hasTex ? await store.getSetting(lookTexKey(id), null).catch(() => null) : null;
  if (look.hasTex && !blob) look.hasTex = false; // la textura ya no está
  return { look, blob };
}

export async function saveLook(store, id, look, texBlob) {
  const clean = cleanLook({ ...look, hasTex: !!texBlob });
  await store.setSetting(lookKey(id), clean);
  if (texBlob) await store.setSetting(lookTexKey(id), texBlob);
  else await store.setSetting(lookTexKey(id), null);
  return clean;
}

// Para el mundo: lee lo guardado y lo aplica al personaje. Devuelve { dispose } (libera la textura) o null si no hay nada.
export async function applySavedLook(THREE, store, id, root, { maxSize = 2048 } = {}) {
  const { look, blob } = await readLook(store, id);
  if (!changesMaterials(look)) return null;
  const tex = blob ? await loadImageTexture(THREE, blob, { maxSize }).catch(() => null) : null;
  applyLook(THREE, root, look, tex);
  return { look, dispose: () => tex?.dispose() };
}
