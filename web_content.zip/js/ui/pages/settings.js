/* ===================================================================
 * VFL.UI.Pages.settings
 * =================================================================== */
(function (VFL) {
  "use strict";

  VFL.UI = VFL.UI || {};
  VFL.UI.Pages = VFL.UI.Pages || {};

  VFL.UI.Pages.settings = {
    render: function (container) {
      var state = VFL.State.get();

      container.innerHTML =
        "<h1>تنظیمات</h1>" +
        '<div class="section-title">مسابقات فعال</div>' +
        '<div class="row-list">' +
        toggleRow("league", "لیگ داخلی", true, true) +
        toggleRow("cup", "جام حذفی", state.competitions.cup.enabled !== false) +
        toggleRow("superCup", "سوپر جام", state.competitions.superCup.enabled !== false) +
        toggleRow("championsLeague", "لیگ قهرمانان اروپا", state.competitions.championsLeague.status !== "disabled") +
        "</div>" +
        '<div class="section-title">درباره</div>' +
        '<div class="row-list">' +
        '<div class="row"><div class="row-main"><span class="row-title">نسخه</span></div><span class="row-value">' + VFL.Utils.faDigits(VFL.Config.version) + "</span></div>" +
        '<div class="row"><div class="row-main"><span class="row-title">مرحله فعلی</span></div><span class="row-value">' + VFL.Config.stage + "</span></div>" +
        "</div>" +
        '<div class="section-title">بازی ذخیره‌شده</div>' +
        '<button class="btn ghost" id="reset-save">حذف بازی ذخیره‌شده و شروع مجدد</button>';

      Array.prototype.forEach.call(container.querySelectorAll(".toggle"), function (toggle) {
        toggle.addEventListener("click", function () {
          var key = toggle.getAttribute("data-key");
          if (key === "league") return;
          VFL.State.toggleCompetition(key);
          VFL.UI.Pages.settings.render(container);
        });
      });

      container.querySelector("#reset-save").addEventListener("click", function () {
        VFL.Storage.clear();
        window.location.hash = "#/home";
        window.location.reload();
      });
    }
  };

  function toggleRow(key, label, isOn, locked) {
    return (
      '<div class="row"><div class="row-main"><span class="row-title">' + label + "</span></div>" +
      '<button class="toggle' + (isOn ? " on" : "") + (locked ? "" : "") + '" data-key="' + key + '"' +
      (locked ? " disabled" : "") + "></button></div>"
    );
  }
})(window.VFL || (window.VFL = {}));
