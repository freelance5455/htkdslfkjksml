/* ===================================================================
 * VFL.UI.Pages.standings
 * =================================================================== */
(function (VFL) {
  "use strict";

  VFL.UI = VFL.UI || {};
  VFL.UI.Pages = VFL.UI.Pages || {};

  var selectedLeagueId = null;

  VFL.UI.Pages.standings = {
    render: function (container) {
      var state = VFL.State.get();
      var fullLeagues = VFL.Data.Leagues.filter(function (l) { return l.full; });

      if (!selectedLeagueId) {
        var ownTeam = state && state.selectedTeamId ? VFL.Data.getTeamById(state.selectedTeamId) : null;
        selectedLeagueId = (ownTeam && ownTeam.league) || fullLeagues[0].id;
      }

      container.innerHTML =
        "<h1>جدول‌ها</h1>" +
        '<div class="chip-row" id="league-chips"></div>' +
        '<div class="standings-table-wrap" id="table-wrap"></div>';

      var chipsEl = container.querySelector("#league-chips");
      chipsEl.innerHTML = fullLeagues.map(function (l) {
        var active = l.id === selectedLeagueId ? " active" : "";
        return '<div class="chip' + active + '" data-league="' + l.id + '">' + l.displayName + "</div>";
      }).join("");

      Array.prototype.forEach.call(chipsEl.querySelectorAll(".chip"), function (chip) {
        chip.addEventListener("click", function () {
          selectedLeagueId = chip.getAttribute("data-league");
          VFL.UI.Pages.standings.render(container);
        });
      });

      var rows = VFL.Utils.sortStandings(state.standings[selectedLeagueId] || []);
      var ownTeamId = state.selectedTeamId;

      var tableHtml =
        "<table class='standings'><thead><tr>" +
        "<th>#</th><th>تیم</th><th>ب</th><th>ب.برد</th><th>م</th><th>ش</th>" +
        "<th>گ.ز</th><th>گ.خ</th><th>ت.گ</th><th>امت</th>" +
        "</tr></thead><tbody>";

      rows.forEach(function (row, idx) {
        var team = VFL.Data.getTeamById(row.teamId);
        var isOwn = row.teamId === ownTeamId;
        tableHtml +=
          "<tr" + (isOwn ? ' class="own-team"' : "") + ">" +
          "<td>" + VFL.Utils.faDigits(idx + 1) + "</td>" +
          '<td class="team-name">' + team.name + "</td>" +
          "<td>" + VFL.Utils.faDigits(row.played) + "</td>" +
          "<td>" + VFL.Utils.faDigits(row.win) + "</td>" +
          "<td>" + VFL.Utils.faDigits(row.draw) + "</td>" +
          "<td>" + VFL.Utils.faDigits(row.loss) + "</td>" +
          "<td>" + VFL.Utils.faDigits(row.goalsFor) + "</td>" +
          "<td>" + VFL.Utils.faDigits(row.goalsAgainst) + "</td>" +
          "<td>" + VFL.Utils.faDigits(row.goalDiff) + "</td>" +
          '<td class="points">' + VFL.Utils.faDigits(row.points) + "</td>" +
          "</tr>";
      });

      tableHtml += "</tbody></table>";
      container.querySelector("#table-wrap").innerHTML = tableHtml;
    }
  };
})(window.VFL || (window.VFL = {}));
