/* ===================================================================
 * VFL.UI.Pages.cup
 * =================================================================== */
(function (VFL) {
  "use strict";

  VFL.UI = VFL.UI || {};
  VFL.UI.Pages = VFL.UI.Pages || {};

  VFL.UI.Pages.cup = {
    render: function (container) {
      var state = VFL.State.get();

      if (!state.cup) {
        container.innerHTML = "<h1>جام حذفی</h1>" +
          '<div class="empty-state"><strong>هنوز آماده نیست</strong>جام حذفی به دیتابیس بازیکن یک لیگ نیاز دارد.</div>';
        return;
      }

      var league = VFL.Data.getLeagueById(state.cup.leagueId);
      var bracket = state.cup.bracket;

      var html = "<h1>جام حذفی</h1><p>" + league.displayName + "</p>";

      if (bracket.championTeamId) {
        var champ = VFL.Data.getTeamById(bracket.championTeamId);
        html += '<div class="hero-strip" style="text-align:center;"><div class="hero-team-name">🏆 ' + champ.name + "</div><div class=\"hero-team-meta\">قهرمان جام حذفی</div></div>";
      }

      bracket.rounds.forEach(function (round, idx) {
        html += '<div class="section-title">' + round.label + "</div><div class=\"row-list\">";
        round.matches.forEach(function (m) {
          var home = VFL.Data.getTeamById(m.home);
          var away = VFL.Data.getTeamById(m.away);
          var resultText = m.played
            ? VFL.Utils.faDigits(m.result.homeGoals) + " - " + VFL.Utils.faDigits(m.result.awayGoals) + (m.penalties ? " (پن)" : "")
            : "برنامه‌ریزی‌شده";
          html += '<div class="row' + (m.played ? " clickable" : "") + '"' + (m.played ? ' data-report="cup-' + m.id + '"' : "") + '>' +
            '<div class="row-main"><span class="row-title">' + home.name + " — " + away.name + "</span></div>" +
            '<span class="row-value">' + resultText + "</span></div>";
        });
        if (round.byes && round.byes.length > 0 && idx === 0) {
          round.byes.forEach(function (teamId) {
            var t = VFL.Data.getTeamById(teamId);
            html += '<div class="row"><div class="row-main"><span class="row-title">' + t.name + "</span></div><span class=\"badge muted\">صعود مستقیم</span></div>";
          });
        }
        html += "</div>";
      });

      var currentRound = bracket.rounds[bracket.rounds.length - 1];
      var roundDone = currentRound.matches.every(function (m) { return m.played; });

      if (!bracket.championTeamId) {
        html += '<button class="btn" id="sim-round" style="margin-top:16px;">' +
          (roundDone ? "رفتن به دور بعد" : "شبیه‌سازی این دور") + "</button>";
      }

      container.innerHTML = html;

      var simBtn = container.querySelector("#sim-round");
      if (simBtn) {
        simBtn.addEventListener("click", function () {
          VFL.State.simulateCupRound();
          VFL.UI.Pages.cup.render(container);
        });
      }

      Array.prototype.forEach.call(container.querySelectorAll("[data-report]"), function (row) {
        row.addEventListener("click", function () {
          window.location.hash = "#/match/" + row.getAttribute("data-report");
        });
      });
    }
  };
})(window.VFL || (window.VFL = {}));
