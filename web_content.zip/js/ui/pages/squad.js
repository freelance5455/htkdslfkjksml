/* ===================================================================
 * VFL.UI.Pages.squad
 * مدیریت بازیکنان: مشاهده ترکیب، ویرایش، حذف، ساخت بازیکن جدید، انتقال آزاد
 * =================================================================== */
(function (VFL) {
  "use strict";

  VFL.UI = VFL.UI || {};
  VFL.UI.Pages = VFL.UI.Pages || {};

  var viewTeamId = null;
  var expanded = null; // { playerId, mode: 'edit' | 'transfer' } | { mode: 'create' }

  var POSITIONS = ["GK", "CB", "LB", "RB", "DM", "CM", "AM", "LM", "RM", "LW", "RW", "SS", "CF"];
  var GROUPS = [
    { label: "دروازه‌بان‌ها", positions: ["GK"] },
    { label: "مدافعان", positions: ["CB", "LB", "RB"] },
    { label: "هافبک‌ها", positions: ["DM", "CM", "AM", "LM", "RM"] },
    { label: "مهاجمان", positions: ["LW", "RW", "SS", "CF"] },
    { label: "سایر / پست نامشخص", positions: [null, undefined] }
  ];

  function posOptions(selected) {
    return POSITIONS.map(function (p) {
      return '<option value="' + p + '"' + (p === selected ? " selected" : "") + '>' + p + "</option>";
    }).join("");
  }

  VFL.UI.Pages.squad = {
    render: function (container) {
      var state = VFL.State.get();
      if (!viewTeamId) viewTeamId = state.selectedTeamId || "epl-arsenal";

      var fullLeagues = VFL.Data.Leagues.filter(function (l) { return l.full; });
      var currentTeam = VFL.Data.getTeamById(viewTeamId);
      var currentLeagueId = currentTeam.league || fullLeagues[0].id;

      var html = "<h1>بازیکنان</h1>";

      // --- انتخاب لیگ و تیم ---
      html += '<div class="chip-row" id="league-chips">' + fullLeagues.map(function (l) {
        var active = l.id === currentLeagueId ? " active" : "";
        return '<div class="chip' + active + '" data-league="' + l.id + '">' + l.displayName + "</div>";
      }).join("") + "</div>";

      var teamsInLeague = VFL.Data.getTeamsByLeague(currentLeagueId).slice().sort(function (a, b) { return b.overall - a.overall; });
      html += '<select id="team-select" class="btn ghost" style="margin-bottom:16px;">' + teamsInLeague.map(function (tm) {
        return '<option value="' + tm.id + '"' + (tm.id === viewTeamId ? " selected" : "") + '>' + tm.name + "</option>";
      }).join("") + "</select>";

      var squad = VFL.State.getSquad(viewTeamId);

      if (squad.length === 0) {
        html += '<div class="empty-state"><strong>این تیم هنوز دیتابیس بازیکن ندارد</strong>می‌توانی بازیکن جدید برای این تیم بسازی.</div>';
      } else {
        GROUPS.forEach(function (group) {
          var players = squad.filter(function (p) { return group.positions.indexOf(p.position) !== -1; })
            .sort(function (a, b) { return b.overall - a.overall; });
          if (players.length === 0) return;
          html += '<div class="section-title">' + group.label + " (" + VFL.Utils.faDigits(players.length) + ")</div>";
          html += '<div class="row-list">';
          players.forEach(function (p) { html += renderPlayerRow(p); });
          html += "</div>";
        });
      }

      html += '<button class="btn" id="add-player" style="margin-top:20px;">+ افزودن بازیکن جدید</button>';

      if (expanded && expanded.mode === "create") {
        html += renderCreateForm(viewTeamId);
      }

      container.innerHTML = html;
      bindEvents(container);
    }
  };

  function renderPlayerRow(p) {
    var shirt = VFL.Utils.shirtLabel(p);
    var rows = '<div class="row clickable" data-player="' + p.id + '" data-action="toggle-edit">' +
      '<div class="row-main">' +
      '<span class="badge">' + VFL.Utils.faDigits(p.overall) + "</span>" +
      '<div><span class="row-title">' + (shirt ? shirt + " " : "") + p.name + "</span><br>" +
      '<span class="row-sub">' + VFL.Utils.playerSubLabel(p) + "</span></div>" +
      "</div>" +
      (p.status.injured ? '<span class="badge muted">مصدوم</span>' : '<span class="row-value">›</span>') +
      "</div>";

    if (expanded && expanded.playerId === p.id && expanded.mode === "edit") {
      rows += renderEditForm(p);
    }
    if (expanded && expanded.playerId === p.id && expanded.mode === "transfer") {
      rows += renderTransferForm(p);
    }
    return rows;
  }

  function renderEditForm(p) {
    return (
      '<div class="row-list" style="border-top:none; margin-bottom:12px;">' +
      '<div class="row" style="flex-direction:column; align-items:stretch; gap:8px;">' +
      '<input type="text" id="edit-name" value="' + p.name.replace(/"/g, "&quot;") + '" placeholder="نام" style="background:var(--pitch-raised);border:1px solid var(--line);color:var(--chalk);border-radius:var(--radius-sm);padding:8px;">' +
      '<div style="display:flex; gap:8px;">' +
      '<input type="number" id="edit-age" value="' + (p.age !== null && p.age !== undefined ? p.age : "") + '" placeholder="سن" style="flex:1;background:var(--pitch-raised);border:1px solid var(--line);color:var(--chalk);border-radius:var(--radius-sm);padding:8px;">' +
      '<select id="edit-position" style="flex:1;background:var(--pitch-raised);border:1px solid var(--line);color:var(--chalk);border-radius:var(--radius-sm);padding:8px;">' + posOptions(p.position) + "</select>" +
      "</div>" +
      '<input type="text" id="edit-country" value="' + (p.country || "").replace(/"/g, "&quot;") + '" placeholder="کشور" style="background:var(--pitch-raised);border:1px solid var(--line);color:var(--chalk);border-radius:var(--radius-sm);padding:8px;">' +
      '<input type="number" id="edit-overall" value="' + p.overall + '" min="1" max="99" placeholder="Overall" style="background:var(--pitch-raised);border:1px solid var(--line);color:var(--chalk);border-radius:var(--radius-sm);padding:8px;">' +
      '<div style="display:flex; gap:8px;">' +
      '<button class="btn small" data-action="save-edit" data-player="' + p.id + '">ذخیره</button>' +
      '<button class="btn small ghost" data-action="open-transfer" data-player="' + p.id + '">انتقال</button>' +
      '<button class="btn small ghost" data-action="delete-player" data-player="' + p.id + '" style="color:var(--loss);border-color:var(--loss);">حذف</button>' +
      "</div>" +
      "</div></div>"
    );
  }

  function renderTransferForm(p) {
    var fullLeagues = VFL.Data.Leagues; // انتقال به هر تیمی، حتی گروه‌های ناقص، آزاد است
    var currentTeam = VFL.Data.getTeamById(p.teamId);
    return (
      '<div class="row-list" style="border-top:none; margin-bottom:12px;">' +
      '<div class="row" style="flex-direction:column; align-items:stretch; gap:8px;">' +
      '<p style="margin:0;">انتقال ' + p.name + " از " + currentTeam.name + "</p>" +
      '<select id="transfer-team" style="background:var(--pitch-raised);border:1px solid var(--line);color:var(--chalk);border-radius:var(--radius-sm);padding:8px;">' +
      VFL.Data.Teams.filter(function (t) { return t.id !== p.teamId; })
        .slice().sort(function (a, b) { return a.name.localeCompare(b.name); })
        .map(function (t) { return '<option value="' + t.id + '">' + t.name + " (" + t.country + ")</option>"; }).join("") +
      "</select>" +
      '<div style="display:flex; gap:8px;">' +
      '<button class="btn small" data-action="confirm-transfer" data-player="' + p.id + '">تأیید انتقال</button>' +
      '<button class="btn small ghost" data-action="cancel">انصراف</button>' +
      "</div></div></div>"
    );
  }

  function renderCreateForm(teamId) {
    var team = VFL.Data.getTeamById(teamId);
    return (
      '<div class="row-list" style="border-top:none; margin-top:12px;">' +
      '<div class="row" style="flex-direction:column; align-items:stretch; gap:8px;">' +
      '<p style="margin:0;">بازیکن جدید برای ' + team.name + "</p>" +
      '<input type="text" id="create-name" placeholder="نام بازیکن" style="background:var(--pitch-raised);border:1px solid var(--line);color:var(--chalk);border-radius:var(--radius-sm);padding:8px;">' +
      '<div style="display:flex; gap:8px;">' +
      '<input type="number" id="create-age" placeholder="سن" style="flex:1;background:var(--pitch-raised);border:1px solid var(--line);color:var(--chalk);border-radius:var(--radius-sm);padding:8px;">' +
      '<select id="create-position" style="flex:1;background:var(--pitch-raised);border:1px solid var(--line);color:var(--chalk);border-radius:var(--radius-sm);padding:8px;">' + posOptions("CM") + "</select>" +
      "</div>" +
      '<input type="text" id="create-country" placeholder="کشور" style="background:var(--pitch-raised);border:1px solid var(--line);color:var(--chalk);border-radius:var(--radius-sm);padding:8px;">' +
      '<input type="number" id="create-overall" min="1" max="99" placeholder="Overall (۱ تا ۹۹)" style="background:var(--pitch-raised);border:1px solid var(--line);color:var(--chalk);border-radius:var(--radius-sm);padding:8px;">' +
      '<div style="display:flex; gap:8px;">' +
      '<button class="btn small" data-action="confirm-create">ساخت بازیکن</button>' +
      '<button class="btn small ghost" data-action="cancel">انصراف</button>' +
      "</div></div></div>"
    );
  }

  function bindEvents(container) {
    container.querySelectorAll("[data-league]").forEach(function (chip) {
      chip.addEventListener("click", function () {
        var leagueId = chip.getAttribute("data-league");
        var firstTeam = VFL.Data.getTeamsByLeague(leagueId)[0];
        viewTeamId = firstTeam.id;
        expanded = null;
        VFL.UI.Pages.squad.render(container);
      });
    });

    var teamSelect = container.querySelector("#team-select");
    if (teamSelect) {
      teamSelect.addEventListener("change", function () {
        viewTeamId = teamSelect.value;
        expanded = null;
        VFL.UI.Pages.squad.render(container);
      });
    }

    container.querySelectorAll('[data-action="toggle-edit"]').forEach(function (row) {
      row.addEventListener("click", function () {
        var pid = row.getAttribute("data-player");
        if (expanded && expanded.playerId === pid) { expanded = null; }
        else { expanded = { playerId: pid, mode: "edit" }; }
        VFL.UI.Pages.squad.render(container);
      });
    });

    var addBtn = container.querySelector("#add-player");
    if (addBtn) {
      addBtn.addEventListener("click", function () {
        expanded = { mode: "create" };
        VFL.UI.Pages.squad.render(container);
      });
    }

    bindAction(container, "save-edit", function (btn) {
      var pid = btn.getAttribute("data-player");
      VFL.State.editPlayer(pid, {
        name: container.querySelector("#edit-name").value,
        age: parseInt(container.querySelector("#edit-age").value, 10),
        position: container.querySelector("#edit-position").value,
        country: container.querySelector("#edit-country").value,
        overall: parseInt(container.querySelector("#edit-overall").value, 10)
      });
      expanded = null;
      VFL.UI.Pages.squad.render(container);
    });

    bindAction(container, "open-transfer", function (btn) {
      expanded = { playerId: btn.getAttribute("data-player"), mode: "transfer" };
      VFL.UI.Pages.squad.render(container);
    });

    bindAction(container, "confirm-transfer", function (btn) {
      var pid = btn.getAttribute("data-player");
      var toTeamId = container.querySelector("#transfer-team").value;
      VFL.State.transferPlayer(pid, toTeamId);
      expanded = null;
      VFL.UI.Pages.squad.render(container);
    });

    bindAction(container, "delete-player", function (btn) {
      var pid = btn.getAttribute("data-player");
      VFL.State.deletePlayer(pid);
      expanded = null;
      VFL.UI.Pages.squad.render(container);
    });

    bindAction(container, "confirm-create", function () {
      var name = container.querySelector("#create-name").value.trim();
      var age = parseInt(container.querySelector("#create-age").value, 10);
      var overall = parseInt(container.querySelector("#create-overall").value, 10);
      if (!name || !age || !overall) return;
      VFL.State.createPlayer({
        name: name, age: age,
        position: container.querySelector("#create-position").value,
        country: container.querySelector("#create-country").value || "نامشخص",
        overall: Math.max(1, Math.min(99, overall)),
        teamId: viewTeamId
      });
      expanded = null;
      VFL.UI.Pages.squad.render(container);
    });

    bindAction(container, "cancel", function () {
      expanded = null;
      VFL.UI.Pages.squad.render(container);
    });
  }

  function bindAction(container, action, handler) {
    container.querySelectorAll('[data-action="' + action + '"]').forEach(function (el) {
      el.addEventListener("click", function (e) {
        e.stopPropagation();
        handler(el);
      });
    });
  }
})(window.VFL || (window.VFL = {}));
