/* ===================================================================
 * VFL.UI.Pages.championsLeague
 * =================================================================== */
(function (VFL) {
  "use strict";

  VFL.UI = VFL.UI || {};
  VFL.UI.Pages = VFL.UI.Pages || {};

  var PHASE_LABEL = {
    league: "مرحله لیگ", playoff: "پلی‌آف", r16: "یک‌شانزدهم نهایی",
    qf: "یک‌چهارم نهایی", sf: "نیمه‌نهایی", final: "فینال", done: "پایان‌یافته"
  };

  VFL.UI.Pages.championsLeague = {
    render: function (container) {
      var state = VFL.State.get();
      var cl = state.championsLeague;

      if (!cl) {
        container.innerHTML = "<h1>لیگ قهرمانان اروپا</h1>" + '<div class="empty-state"><strong>هنوز آماده نیست</strong></div>';
        return;
      }

      var html = "<h1>لیگ قهرمانان اروپا</h1><p>فرمت جدید UEFA — ۳۲ تیم بر اساس سهمیه کشوری · مرحله: " + PHASE_LABEL[cl.phase] + "</p>";

      if (cl.championTeamId) {
        var champ = VFL.Data.getTeamById(cl.championTeamId);
        html += '<div class="hero-strip" style="text-align:center;"><div class="hero-team-name">🏆 ' + champ.name + "</div><div class=\"hero-team-meta\">قهرمان لیگ قهرمانان اروپا</div></div>";
      }

      if (cl.phase === "league" || (!cl.championTeamId && cl.leagueRanking)) {
        html += '<div class="section-title">جدول مرحله لیگ (۳۲ تیم)</div>';
        var ranked = VFL.Utils.sortStandings(cl.leagueStandings);
        html += '<div class="standings-table-wrap"><table class="standings"><thead><tr><th>#</th><th>تیم</th><th>ب</th><th>ب.برد</th><th>م</th><th>ش</th><th>ت.گ</th><th>امت</th></tr></thead><tbody>';
        ranked.forEach(function (row, idx) {
          var team = VFL.Data.getTeamById(row.teamId);
          var zone = idx < 8 ? "champions" : idx < 24 ? null : "relegation";
          html += "<tr><td>" + VFL.Utils.faDigits(idx + 1) + (zone ? '<span class="zone-marker ' + zone + '"></span>' : "") + "</td>" +
            '<td class="team-name">' + team.name + "</td><td>" + VFL.Utils.faDigits(row.played) + "</td><td>" + VFL.Utils.faDigits(row.win) +
            "</td><td>" + VFL.Utils.faDigits(row.draw) + "</td><td>" + VFL.Utils.faDigits(row.loss) + "</td><td>" + VFL.Utils.faDigits(row.goalDiff) +
            '</td><td class="points">' + VFL.Utils.faDigits(row.points) + "</td></tr>";
        });
        html += "</tbody></table></div>";
        html += '<p style="margin-top:8px;">🟡 ۱ تا ۸: صعود مستقیم به یک‌شانزدهم — ۹ تا ۲۴: پلی‌آف — 🔴 ۲۵ تا ۳۲: حذف</p>';
      }

      var roundTies = { playoff: cl.playoffTies, r16: cl.r16Ties, qf: cl.qfTies, sf: cl.sfTies };
      if (roundTies[cl.phase]) {
        html += '<div class="section-title">' + PHASE_LABEL[cl.phase] + " (رفت و برگشت)</div><div class=\"row-list\">";
        roundTies[cl.phase].forEach(function (tie) {
          html += renderTie(tie);
        });
        html += "</div>";
      }

      if (cl.phase === "final" && cl.finalMatch) {
        html += '<div class="section-title">فینال (تک‌بازی)</div><div class="row-list">' +
          renderSingleMatch(cl.finalMatch) + "</div>";
      }

      if (cl.phase !== "done") {
        html += '<button class="btn" id="cl-step" style="margin-top:16px;">ادامه لیگ قهرمانان</button>';
      }

      container.innerHTML = html;

      var stepBtn = container.querySelector("#cl-step");
      if (stepBtn) {
        stepBtn.addEventListener("click", function () {
          VFL.State.simulateCLStep();
          VFL.UI.Pages.championsLeague.render(container);
        });
      }

      container.querySelectorAll("[data-report]").forEach(function (row) {
        row.addEventListener("click", function () { window.location.hash = "#/match/" + row.getAttribute("data-report"); });
      });
    }
  };

  function renderTie(tie) {
    var teamA = VFL.Data.getTeamById(tie.leg1.home), teamB = VFL.Data.getTeamById(tie.leg1.away);
    var leg1Text = tie.leg1.played ? VFL.Utils.faDigits(tie.leg1.result.homeGoals) + "-" + VFL.Utils.faDigits(tie.leg1.result.awayGoals) : "—";
    var leg2Text = tie.leg2.played ? VFL.Utils.faDigits(tie.leg2.result.homeGoals) + "-" + VFL.Utils.faDigits(tie.leg2.result.awayGoals) : "—";
    var winnerText = tie.aggregateWinner ? " (صعود: " + VFL.Data.getTeamById(tie.aggregateWinner).name + (tie.penalties ? " با پنالتی" : "") + ")" : "";
    return '<div class="row"><div class="row-main"><span class="row-title">' + teamA.name + " — " + teamB.name + "</span><br>" +
      '<span class="row-sub">لگ اول: ' + leg1Text + " · لگ دوم: " + leg2Text + winnerText + "</span></div></div>";
  }

  function renderSingleMatch(m) {
    var home = VFL.Data.getTeamById(m.home), away = VFL.Data.getTeamById(m.away);
    var text = m.played ? VFL.Utils.faDigits(m.result.homeGoals) + "-" + VFL.Utils.faDigits(m.result.awayGoals) + (m.penalties ? " (پنالتی)" : "") : "برنامه‌ریزی‌شده";
    return '<div class="row' + (m.played ? " clickable" : "") + '"' + (m.played ? ' data-report="cl-final"' : "") + '><div class="row-main"><span class="row-title">' +
      home.name + " — " + away.name + "</span></div><span class=\"row-value\">" + text + "</span></div>";
  }
})(window.VFL || (window.VFL = {}));
