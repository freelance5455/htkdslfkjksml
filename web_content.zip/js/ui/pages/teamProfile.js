/* ===================================================================
 * VFL.UI.Pages.teamProfile
 * صفحه کامل تیم: اطلاعات، فرم/انرژی، بازیکنان (قابل ویرایش/انتقال)،
 * تاریخچه نقل‌وانتقالات تیم، نتایج، آمار.
 * =================================================================== */
(function (VFL) {
  "use strict";

  VFL.UI = VFL.UI || {};
  VFL.UI.Pages = VFL.UI.Pages || {};

  var expandedPlayerId = null;
  var expandedMode = null; // 'edit' | 'transfer'
  var showCreateForm = false;

  var POSITIONS = ["GK", "CB", "LB", "RB", "DM", "CM", "AM", "LM", "RM", "LW", "RW", "SS", "CF"];
  function posOptions(selected) {
    return POSITIONS.map(function (p) {
      return '<option value="' + p + '"' + (p === selected ? " selected" : "") + '>' + p + "</option>";
    }).join("");
  }
  function inputStyle() {
    return "background:var(--pitch-raised);border:1px solid var(--line);color:var(--chalk);border-radius:var(--radius-sm);padding:8px;";
  }

  VFL.UI.Pages.teamProfile = {
    render: function (container, params) {
      var teamId = params && params.id;
      var team = teamId ? VFL.Data.getTeamById(teamId) : null;
      if (!team) { container.innerHTML = '<div class="empty-state"><strong>تیم پیدا نشد</strong></div>'; return; }

      var state = VFL.State.get();
      var league = VFL.Data.getLeagueById(team.league);
      var form = state.form[teamId] || [];
      var row = team.league && state.standings[team.league] ? state.standings[team.league].find(function (r) { return r.teamId === teamId; }) : null;
      var position = null;
      if (row && team.league) {
        var ranked = VFL.Utils.sortStandings(state.standings[team.league]);
        position = ranked.findIndex(function (r) { return r.teamId === teamId; }) + 1;
      }
      var fatigue = Math.min(25, (row ? row.played : 0) * 0.7);
      var energy = Math.round(100 - fatigue);

      var squad = VFL.State.getSquad(teamId);
      var results = state.fixtures[team.league] ? state.fixtures[team.league].filter(function (fx) {
        return fx.played && (fx.home === teamId || fx.away === teamId);
      }).slice(-5).reverse() : [];
      var history = VFL.State.getTransferHistory(teamId).slice(0, 8);

      var html = "<h1>" + team.name + "</h1>";

      var formHtml = form.map(function (r) { return '<div class="form-pip ' + r.toLowerCase() + '">' + r + "</div>"; }).join("") +
        Array(Math.max(0, 5 - form.length)).fill('<div class="form-pip empty">—</div>').join("");

      html += '<div class="hero-strip">' +
        '<div class="hero-team-meta">' + team.country + (league ? " · " + league.displayName : "") + "</div>" +
        '<div class="hero-stat-strip">' +
        '<div class="hero-stat"><div class="hero-stat-value">' + VFL.Utils.faDigits(team.overall) + '</div><div class="hero-stat-label">Overall</div></div>' +
        '<div class="hero-stat"><div class="hero-stat-value">' + (position || "—") + '</div><div class="hero-stat-label">جایگاه</div></div>' +
        '<div class="hero-stat"><div class="hero-stat-value">' + VFL.Utils.faDigits(row ? row.points : 0) + '</div><div class="hero-stat-label">امتیاز</div></div>' +
        '<div class="hero-stat"><div class="hero-stat-value">' + VFL.Utils.faDigits(energy) + '٪</div><div class="hero-stat-label">انرژی</div></div>' +
        "</div>" +
        '<div class="form-strip">' + formHtml + "</div>" +
        "</div>";

      if (teamId !== state.selectedTeamId) {
        html += '<button class="btn" id="select-this-team" style="margin-bottom:12px;">کنترل این تیم</button>';
      }

      html += '<div class="section-title">بازیکنان (' + VFL.Utils.faDigits(squad.length) + ")</div>";
      if (squad.length > 0) {
        var lineupInfo = VFL.State.getLineup(teamId);
        html += '<div class="row-list" style="margin-bottom:10px;"><div class="row clickable" data-goto-lineup="' + teamId + '">' +
          '<div class="row-main"><span class="row-title">⚙️ چیدن ترکیب اصلی و نیمکت</span>' +
          '<span class="row-sub">' + (lineupInfo ? VFL.Utils.faDigits(lineupInfo.starters.length) + " بازیکن دستی چیده شده" : "الان خودکار (۱۱ برتر بر اساس Overall)") + "</span></div>" +
          '<span class="row-value">›</span></div></div>';
      }
      if (squad.length === 0) {
        html += '<div class="empty-state">این تیم هنوز دیتابیس بازیکن ندارد.</div>';
      } else {
        var sorted = squad.slice().sort(function (a, b) { return b.overall - a.overall; });
        html += '<div class="row-list">' + sorted.map(renderPlayerRow).join("") + "</div>";
      }
      html += '<button class="btn ghost small" id="add-player" style="margin-top:10px;">+ افزودن بازیکن</button>';
      if (showCreateForm) html += renderCreateForm(teamId);

      html += '<div class="section-title">تاریخچه نقل‌وانتقالات</div>';
      if (history.length === 0) {
        html += '<div class="empty-state">نقل‌وانتقالی برای این تیم ثبت نشده.</div>';
      } else {
        html += '<div class="row-list">' + history.map(function (h) {
          var dir = h.toTeamId === teamId ? "ورود از " + VFL.Data.getTeamById(h.fromTeamId).name : "خروج به " + VFL.Data.getTeamById(h.toTeamId).name;
          return '<div class="row"><div class="row-main"><span class="row-title">' + h.playerName + "</span><br><span class=\"row-sub\">" + dir + "</span></div></div>";
        }).join("") + "</div>";
      }

      html += '<div class="section-title">نتایج اخیر</div>';
      if (results.length === 0) {
        html += '<div class="empty-state">هنوز بازی‌ای انجام نشده.</div>';
      } else {
        html += '<div class="row-list">' + results.map(function (fx) {
          var opp = VFL.Data.getTeamById(fx.home === teamId ? fx.away : fx.home);
          return '<div class="row clickable" data-report="' + fx.id + '"><div class="row-main"><span class="row-title">' +
            VFL.Utils.weekLabel(VFL.State.getDisplayWeek(team.league, fx.week)) + " · " + opp.name + "</span></div><span class=\"row-value\">" +
            VFL.Utils.faDigits(fx.result.homeGoals) + " - " + VFL.Utils.faDigits(fx.result.awayGoals) + "</span></div>";
        }).join("") + "</div>";
      }

      var statLines = computeTeamStats(teamId, (state.fixtures[team.league] || []).filter(function (fx) {
        return fx.played && (fx.home === teamId || fx.away === teamId);
      }));
      html += '<div class="section-title">آمار فصل</div>';
      html += '<div class="row-list">' +
        statRow("بازی‌ها", VFL.Utils.faDigits(statLines.matches)) +
        statRow("گل زده", VFL.Utils.faDigits(statLines.goalsFor)) +
        statRow("گل خورده", VFL.Utils.faDigits(statLines.goalsAgainst)) +
        statRow("میانگین تصرف توپ", statLines.avgPossession + (statLines.avgPossession !== "—" ? "٪" : "")) +
        statRow("میانگین شوت", statLines.avgShots) +
        "</div>";

      container.innerHTML = html;
      bindEvents(container, teamId);
    }
  };

  function statRow(label, value) {
    return '<div class="row"><div class="row-main"><span class="row-title">' + label + "</span></div><span class=\"row-value\">" + value + "</span></div>";
  }

  function computeTeamStats(teamId, list) {
    var matches = list.length, goalsFor = 0, goalsAgainst = 0, possSum = 0, shotsSum = 0, statCount = 0;
    list.forEach(function (fx) {
      var isHome = fx.home === teamId;
      goalsFor += isHome ? fx.result.homeGoals : fx.result.awayGoals;
      goalsAgainst += isHome ? fx.result.awayGoals : fx.result.homeGoals;
      var report = VFL.State.getMatchReport(fx.id);
      if (report) {
        var side = isHome ? report.teamStats.home : report.teamStats.away;
        possSum += side.possession; shotsSum += side.shots; statCount++;
      }
    });
    return {
      matches: matches, goalsFor: goalsFor, goalsAgainst: goalsAgainst,
      avgPossession: statCount ? Math.round(possSum / statCount) : "—",
      avgShots: statCount ? Math.round(shotsSum / statCount) : "—"
    };
  }

  function renderPlayerRow(p) {
    var shirt = VFL.Utils.shirtLabel(p);
    var row = '<div class="row clickable" data-player="' + p.id + '" data-action="toggle-edit">' +
      '<div class="row-main"><span class="badge">' + VFL.Utils.faDigits(p.overall) + "</span>" +
      '<div><span class="row-title">' + (shirt ? shirt + " " : "") + p.name + "</span><br><span class=\"row-sub\">" +
      VFL.Utils.playerSubLabel(p) + "</span></div></div>" +
      (p.status.injured ? '<span class="badge muted">مصدوم</span>' : '<span class="row-value">›</span>') + "</div>";

    if (expandedPlayerId === p.id && expandedMode === "edit") row += renderEditForm(p);
    if (expandedPlayerId === p.id && expandedMode === "transfer") row += renderTransferForm(p);
    return row;
  }

  function renderEditForm(p) {
    var s = inputStyle();
    return '<div class="row-list" style="border-top:none; margin-bottom:12px;"><div class="row" style="flex-direction:column; align-items:stretch; gap:8px;">' +
      '<input type="text" id="edit-name" value="' + p.name.replace(/"/g, "&quot;") + '" style="' + s + '">' +
      '<div style="display:flex; gap:8px;">' +
      '<input type="number" id="edit-age" value="' + (p.age !== null && p.age !== undefined ? p.age : "") + '" style="flex:1;' + s + '">' +
      '<select id="edit-position" style="flex:1;' + s + '">' + posOptions(p.position) + "</select></div>" +
      '<input type="text" id="edit-country" value="' + (p.country || "").replace(/"/g, "&quot;") + '" style="' + s + '">' +
      '<input type="number" id="edit-overall" value="' + p.overall + '" min="1" max="99" style="' + s + '">' +
      '<div style="display:flex; gap:8px;">' +
      '<button class="btn small" data-action="save-edit" data-player="' + p.id + '">ذخیره</button>' +
      '<button class="btn small ghost" data-action="open-transfer" data-player="' + p.id + '">انتقال</button>' +
      '<button class="btn small ghost" data-action="delete-player" data-player="' + p.id + '" style="color:var(--loss);border-color:var(--loss);">حذف</button>' +
      "</div></div></div>";
  }

  function renderTransferForm(p) {
    var s = inputStyle();
    var currentTeam = VFL.Data.getTeamById(p.teamId);
    return '<div class="row-list" style="border-top:none; margin-bottom:12px;"><div class="row" style="flex-direction:column; align-items:stretch; gap:8px;">' +
      '<p style="margin:0;">انتقال ' + p.name + " از " + currentTeam.name + "</p>" +
      '<select id="transfer-team" style="' + s + '">' +
      VFL.Data.Teams.filter(function (t) { return t.id !== p.teamId; }).slice().sort(function (a, b) { return a.name.localeCompare(b.name); })
        .map(function (t) { return '<option value="' + t.id + '">' + t.name + " (" + t.country + ")</option>"; }).join("") +
      "</select><div style=\"display:flex; gap:8px;\">" +
      '<button class="btn small" data-action="confirm-transfer" data-player="' + p.id + '">تأیید انتقال</button>' +
      '<button class="btn small ghost" data-action="cancel">انصراف</button></div></div></div>';
  }

  function renderCreateForm(teamId) {
    var s = inputStyle();
    return '<div class="row-list" style="border-top:none; margin-top:12px;"><div class="row" style="flex-direction:column; align-items:stretch; gap:8px;">' +
      '<input type="text" id="create-name" placeholder="نام بازیکن" style="' + s + '">' +
      '<div style="display:flex; gap:8px;">' +
      '<input type="number" id="create-age" placeholder="سن" style="flex:1;' + s + '">' +
      '<select id="create-position" style="flex:1;' + s + '">' + posOptions("CM") + "</select></div>" +
      '<input type="text" id="create-country" placeholder="کشور" style="' + s + '">' +
      '<input type="number" id="create-overall" placeholder="Overall" min="1" max="99" style="' + s + '">' +
      '<div style="display:flex; gap:8px;">' +
      '<button class="btn small" data-action="confirm-create">ساخت</button>' +
      '<button class="btn small ghost" data-action="cancel">انصراف</button></div></div></div>';
  }

  function bindEvents(container, teamId) {
    var selectBtn = container.querySelector("#select-this-team");
    if (selectBtn) {
      selectBtn.addEventListener("click", function () {
        VFL.State.selectTeam(teamId);
        VFL.UI.Pages.teamProfile.render(container, { id: teamId });
      });
    }

    container.querySelectorAll('[data-action="toggle-edit"]').forEach(function (row) {
      row.addEventListener("click", function () {
        var pid = row.getAttribute("data-player");
        if (expandedPlayerId === pid) { expandedPlayerId = null; expandedMode = null; }
        else { expandedPlayerId = pid; expandedMode = "edit"; }
        VFL.UI.Pages.teamProfile.render(container, { id: teamId });
      });
    });

    var addBtn = container.querySelector("#add-player");
    if (addBtn) addBtn.addEventListener("click", function () {
      showCreateForm = true;
      VFL.UI.Pages.teamProfile.render(container, { id: teamId });
    });

    bindAction(container, "save-edit", function (btn) {
      VFL.State.editPlayer(btn.getAttribute("data-player"), {
        name: container.querySelector("#edit-name").value,
        age: parseInt(container.querySelector("#edit-age").value, 10),
        position: container.querySelector("#edit-position").value,
        country: container.querySelector("#edit-country").value,
        overall: parseInt(container.querySelector("#edit-overall").value, 10)
      });
      expandedPlayerId = null; expandedMode = null;
      VFL.UI.Pages.teamProfile.render(container, { id: teamId });
    });

    bindAction(container, "open-transfer", function (btn) {
      expandedPlayerId = btn.getAttribute("data-player"); expandedMode = "transfer";
      VFL.UI.Pages.teamProfile.render(container, { id: teamId });
    });

    bindAction(container, "confirm-transfer", function (btn) {
      var toTeamId = container.querySelector("#transfer-team").value;
      VFL.State.transferPlayer(btn.getAttribute("data-player"), toTeamId);
      expandedPlayerId = null; expandedMode = null;
      VFL.UI.Pages.teamProfile.render(container, { id: teamId });
    });

    bindAction(container, "delete-player", function (btn) {
      VFL.State.deletePlayer(btn.getAttribute("data-player"));
      expandedPlayerId = null; expandedMode = null;
      VFL.UI.Pages.teamProfile.render(container, { id: teamId });
    });

    bindAction(container, "confirm-create", function () {
      var name = container.querySelector("#create-name").value.trim();
      var age = parseInt(container.querySelector("#create-age").value, 10);
      var overall = parseInt(container.querySelector("#create-overall").value, 10);
      if (!name || !age || !overall) return;
      VFL.State.createPlayer({
        name: name, age: age,
        position: container.querySelector("#create-position").value,
        country: container.querySelector("#create-country").value || "نامشخص",
        overall: Math.max(1, Math.min(99, overall)),
        teamId: teamId
      });
      showCreateForm = false;
      VFL.UI.Pages.teamProfile.render(container, { id: teamId });
    });

    bindAction(container, "cancel", function () {
      expandedPlayerId = null; expandedMode = null; showCreateForm = false;
      VFL.UI.Pages.teamProfile.render(container, { id: teamId });
    });

    container.querySelectorAll("[data-report]").forEach(function (row) {
      row.addEventListener("click", function () {
        window.location.hash = "#/match/" + row.getAttribute("data-report");
      });
    });

    container.querySelectorAll("[data-goto-lineup]").forEach(function (row) {
      row.addEventListener("click", function () {
        window.location.hash = "#/lineup/" + row.getAttribute("data-goto-lineup");
      });
    });
  }

  function bindAction(container, action, handler) {
    container.querySelectorAll('[data-action="' + action + '"]').forEach(function (el) {
      el.addEventListener("click", function (e) { e.stopPropagation(); handler(el); });
    });
  }
})(window.VFL || (window.VFL = {}));
