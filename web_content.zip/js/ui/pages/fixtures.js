/* ===================================================================
 * VFL.UI.Pages.fixtures
 * برنامه مسابقات — نمایش تمام بازی‌های فصل برای لیگ تیم انتخاب‌شده
 * =================================================================== */
(function (VFL) {
  "use strict";

  VFL.UI = VFL.UI || {};
  VFL.UI.Pages = VFL.UI.Pages || {};

  VFL.UI.Pages.fixtures = {
    render: function (container) {
      var state = VFL.State.get();

      if (!state || !state.selectedTeamId) {
        container.innerHTML =
          "<h1>برنامه مسابقات</h1>" +
          '<div class="empty-state"><strong>ابتدا یک تیم انتخاب کن</strong>برنامه مسابقات بر اساس لیگ تیم تو نمایش داده می‌شود.</div>';
        return;
      }

      var team = VFL.Data.getTeamById(state.selectedTeamId);
      var league = VFL.Data.getLeagueById(team.league);
      var fixtures = state.fixtures[team.league] || [];

      var byWeek = {};
      fixtures.forEach(function (fx) {
        byWeek[fx.week] = byWeek[fx.week] || [];
        byWeek[fx.week].push(fx);
      });

      var weeks = Object.keys(byWeek).map(Number).sort(function (a, b) { return a - b; });
      var currentWeekHasUnplayed = (byWeek[state.season.week] || []).some(function (fx) { return !fx.played; });

      var html = "<h1>برنامه مسابقات</h1>" +
        "<p>" + league.displayName + " · فصل " + VFL.Utils.faDigits(state.season.current) + " · " + VFL.Utils.weekLabel(state.season.week) + "</p>";

      if (currentWeekHasUnplayed) {
        html += '<button class="btn" id="sim-week" style="margin-bottom:16px;">شبیه‌سازی هفته جاری همه لیگ‌ها</button>';
      }

      weeks.forEach(function (week) {
        html += '<div class="section-title">' + VFL.Utils.weekLabel(week) + "</div>";
        html += '<div class="row-list">';
        byWeek[week].forEach(function (fx) {
          var home = VFL.Data.getTeamById(fx.home);
          var away = VFL.Data.getTeamById(fx.away);
          var isOwn = fx.home === team.id || fx.away === team.id;
          html +=
            '<div class="row clickable' + (isOwn ? "" : "") + '" data-fixture="' + fx.id + '">' +
            '<div class="row-main"><span class="row-title">' +
            (isOwn ? "⭐ " : "") + home.name + " — " + away.name +
            "</span></div>" +
            '<span class="row-value">' + (fx.played ? (VFL.Utils.faDigits(fx.result.homeGoals) + " - " + VFL.Utils.faDigits(fx.result.awayGoals)) : "برنامه‌ریزی‌شده") + "</span>" +
            "</div>";
        });
        html += "</div>";
      });

      container.innerHTML = html;

      Array.prototype.forEach.call(container.querySelectorAll("[data-fixture]"), function (row) {
        row.addEventListener("click", function () {
          window.location.hash = "#/match/" + row.getAttribute("data-fixture");
        });
      });

      var simWeekBtn = container.querySelector("#sim-week");
      if (simWeekBtn) {
        simWeekBtn.addEventListener("click", function () {
          VFL.State.simulateGlobalWeek();
          VFL.UI.Pages.fixtures.render(container);
        });
      }
    }
  };
})(window.VFL || (window.VFL = {}));
