/* ===================================================================
 * VFL.UI.Pages.seasonArchive
 * تاریخچه فصل‌ها — جدول نهایی و جوایز هر فصلی که واقعاً تمام و بسته شده.
 * =================================================================== */
(function (VFL) {
  "use strict";

  VFL.UI = VFL.UI || {};
  VFL.UI.Pages = VFL.UI.Pages || {};

  VFL.UI.Pages.seasonArchive = {
    render: function (container) {
      var history = VFL.State.getSeasonHistory();
      var awards = VFL.State.getSeasonAwardsHistory();

      var html = "<h1>تاریخچه فصل‌ها</h1>";

      if (history.length === 0) {
        html += '<div class="empty-state"><strong>هنوز فصلی تمام نشده</strong>وقتی یک لیگ فصلش را تمام کند و از صفحه «پایان فصل» بسته شود، اینجا ثبت می‌شود.</div>';
        container.innerHTML = html;
        return;
      }

      // جدید به قدیم
      var sorted = history.slice().sort(function (a, b) {
        if (b.year !== a.year) return b.year - a.year;
        return a.leagueId.localeCompare(b.leagueId);
      });

      sorted.forEach(function (h) {
        var league = VFL.Data.getLeagueById(h.leagueId);
        var award = awards.find(function (a) { return a.leagueId === h.leagueId && a.year === h.year; });

        html += '<div class="section-title">' + league.displayName + " — سال " + VFL.Utils.faDigits(h.year) + "</div>";

        html += '<div class="standings-table-wrap"><table class="standings"><thead><tr>' +
          "<th>#</th><th>تیم</th><th>ب</th><th>ب.برد</th><th>م</th><th>ش</th><th>ت.گ</th><th>امت</th>" +
          "</tr></thead><tbody>";
        h.standings.forEach(function (row, idx) {
          var team = VFL.Data.getTeamById(row.teamId);
          html += "<tr" + (idx === 0 ? ' class="own-team"' : "") + "><td>" + VFL.Utils.faDigits(idx + 1) + "</td>" +
            '<td class="team-name">' + team.name + "</td><td>" + VFL.Utils.faDigits(row.played) + "</td><td>" + VFL.Utils.faDigits(row.win) +
            "</td><td>" + VFL.Utils.faDigits(row.draw) + "</td><td>" + VFL.Utils.faDigits(row.loss) + "</td><td>" + VFL.Utils.faDigits(row.goalDiff) +
            '</td><td class="points">' + VFL.Utils.faDigits(row.points) + "</td></tr>";
        });
        html += "</tbody></table></div>";

        if (award) {
          html += '<div class="row-list">';
          if (award.topScorer) html += awardLine("⚽ آقای گل", award.topScorer.playerId, VFL.Utils.faDigits(award.topScorer.value) + " گل");
          if (award.topAssist) html += awardLine("🎯 برترین پاس‌گل‌دهنده", award.topAssist.playerId, VFL.Utils.faDigits(award.topAssist.value));
          if (award.bestPlayer) html += awardLine("⭐ بهترین بازیکن", award.bestPlayer.playerId, "");
          html += "</div>";
        }
      });

      container.innerHTML = html;
    }
  };

  function awardLine(label, playerId, extra) {
    var p = VFL.State.getPlayer(playerId);
    var name = p ? p.name : "—";
    return '<div class="row"><div class="row-main"><span class="row-title">' + label + "</span></div><span class=\"row-value\">" + name + (extra ? " · " + extra : "") + "</span></div>";
  }
})(window.VFL || (window.VFL = {}));
