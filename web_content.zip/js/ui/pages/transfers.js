/* ===================================================================
 * VFL.UI.Pages.transfers
 * بازار نقل‌وانتقالات — جست‌وجو، مرور تیم مبدأ/مقصد، انتقال، تاریخچه.
 * منطق انتقال از VFL.State.transferPlayer (بدون تغییر) استفاده می‌کند.
 * =================================================================== */
(function (VFL) {
  "use strict";

  VFL.UI = VFL.UI || {};
  VFL.UI.Pages = VFL.UI.Pages || {};

  var query = "";
  var browseTeamId = null;
  var activePlayerId = null;
  var destTeamId = null;

  function inputStyle() {
    return "background:var(--pitch-raised);border:1px solid var(--line);color:var(--chalk);border-radius:var(--radius-sm);padding:9px;width:100%;";
  }

  VFL.UI.Pages.transfers = {
    render: function (container) {
      var state = VFL.State.get();
      if (!browseTeamId) browseTeamId = state.selectedTeamId || VFL.Data.Teams[0].id;

      var html = "<h1>نقل‌وانتقالات</h1>";

      // --- جست‌وجو ---
      html += '<input type="text" id="search-box" placeholder="جست‌وجوی بازیکن..." value="' + query.replace(/"/g, "&quot;") + '" style="' + inputStyle() + ' margin-bottom:12px;">';

      var searchResults = [];
      if (query.trim().length > 0) {
        var q = query.trim().toLowerCase();
        searchResults = state.players.filter(function (p) { return p.name.toLowerCase().indexOf(q) !== -1; }).slice(0, 20);
      }

      if (query.trim().length > 0) {
        html += '<div class="section-title">نتایج جست‌وجو (' + VFL.Utils.faDigits(searchResults.length) + ")</div>";
        if (searchResults.length === 0) {
          html += '<div class="empty-state">بازیکنی پیدا نشد.</div>';
        } else {
          html += '<div class="row-list">' + searchResults.map(renderPlayerRow).join("") + "</div>";
        }
      }

      // --- بازیکن انتخاب‌شده برای انتقال ---
      if (activePlayerId) {
        var player = VFL.State.getPlayer(activePlayerId);
        if (player) {
          var fromTeam = VFL.Data.getTeamById(player.teamId);
          html += '<div class="section-title">انتقال بازیکن</div>';
          html += '<div class="hero-strip">' +
            '<div class="hero-team-name">' + player.name + "</div>" +
            '<div class="hero-team-meta">تیم مبدأ: ' + fromTeam.name + " · Overall " + VFL.Utils.faDigits(player.overall) + "</div>" +
            '<div style="margin-top:14px;">' +
            '<select id="dest-team" style="' + inputStyle() + '">' +
            VFL.Data.Teams.filter(function (t) { return t.id !== player.teamId; }).slice().sort(function (a, b) { return a.name.localeCompare(b.name); })
              .map(function (t) { return '<option value="' + t.id + '"' + (t.id === destTeamId ? " selected" : "") + '>' + t.name + " (" + t.country + ")</option>"; }).join("") +
            "</select></div>" +
            '<div style="display:flex; gap:8px; margin-top:12px;">' +
            '<button class="btn small" id="confirm-transfer">تأیید انتقال به تیم مقصد</button>' +
            '<button class="btn small ghost" id="cancel-transfer">انصراف</button>' +
            "</div></div>";
        }
      }

      // --- مرور تیم مبدأ ---
      html += '<div class="section-title">مرور بازیکنان یک تیم</div>';
      var teamsSorted = VFL.Data.Teams.slice().sort(function (a, b) { return a.name.localeCompare(b.name); });
      html += '<select id="browse-team" style="' + inputStyle() + ' margin-bottom:12px;">' +
        teamsSorted.map(function (t) { return '<option value="' + t.id + '"' + (t.id === browseTeamId ? " selected" : "") + '>' + t.name + " (" + t.country + ")</option>"; }).join("") +
        "</select>";

      var browseSquad = VFL.State.getSquad(browseTeamId).slice().sort(function (a, b) { return b.overall - a.overall; });
      if (browseSquad.length === 0) {
        html += '<div class="empty-state">این تیم دیتابیس بازیکن ندارد.</div>';
      } else {
        html += '<div class="row-list">' + browseSquad.map(renderPlayerRow).join("") + "</div>";
      }

      // --- تاریخچه نقل‌وانتقالات ---
      var history = VFL.State.getTransferHistory().slice(0, 15);
      html += '<div class="section-title">تاریخچه نقل‌وانتقالات</div>';
      if (history.length === 0) {
        html += '<div class="empty-state">هنوز انتقالی ثبت نشده.</div>';
      } else {
        html += '<div class="row-list">' + history.map(function (h) {
          var from = VFL.Data.getTeamById(h.fromTeamId), to = VFL.Data.getTeamById(h.toTeamId);
          return '<div class="row"><div class="row-main"><span class="row-title">' + h.playerName + "</span><br>" +
            '<span class="row-sub">' + from.name + " ← " + to.name + "</span></div>" +
            '<span class="row-value">' + VFL.Utils.weekLabel(h.week) + "</span></div>";
        }).join("") + "</div>";
      }

      container.innerHTML = html;
      bindEvents(container);
    }
  };

  function renderPlayerRow(p) {
    var team = VFL.Data.getTeamById(p.teamId);
    var shirt = VFL.Utils.shirtLabel(p);
    var active = p.id === activePlayerId ? " style=\"border-color:var(--amber);\"" : "";
    return '<div class="row clickable" data-select-player="' + p.id + '"' + active + '>' +
      '<div class="row-main"><span class="badge">' + VFL.Utils.faDigits(p.overall) + "</span>" +
      '<div><span class="row-title">' + (shirt ? shirt + " " : "") + p.name + "</span><br><span class=\"row-sub\">" + team.name + (p.position ? " · " + p.position : "") + "</span></div></div>" +
      '<span class="row-value">انتقال</span></div>';
  }

  function bindEvents(container) {
    var searchBox = container.querySelector("#search-box");
    searchBox.addEventListener("input", function () {
      query = searchBox.value;
      VFL.UI.Pages.transfers.render(container);
    });
    // حفظ فوکوس روی جست‌وجو پس از رندر مجدد
    if (document.activeElement !== searchBox && query) {
      searchBox.focus();
      searchBox.setSelectionRange(searchBox.value.length, searchBox.value.length);
    }

    var browseSelect = container.querySelector("#browse-team");
    browseSelect.addEventListener("change", function () {
      browseTeamId = browseSelect.value;
      VFL.UI.Pages.transfers.render(container);
    });

    container.querySelectorAll("[data-select-player]").forEach(function (row) {
      row.addEventListener("click", function () {
        activePlayerId = row.getAttribute("data-select-player");
        destTeamId = null;
        VFL.UI.Pages.transfers.render(container);
      });
    });

    var confirmBtn = container.querySelector("#confirm-transfer");
    if (confirmBtn) {
      confirmBtn.addEventListener("click", function () {
        var toTeamId = container.querySelector("#dest-team").value;
        VFL.State.transferPlayer(activePlayerId, toTeamId);
        activePlayerId = null; destTeamId = null;
        VFL.UI.Pages.transfers.render(container);
      });
    }
    var cancelBtn = container.querySelector("#cancel-transfer");
    if (cancelBtn) {
      cancelBtn.addEventListener("click", function () {
        activePlayerId = null; destTeamId = null;
        VFL.UI.Pages.transfers.render(container);
      });
    }
  }
})(window.VFL || (window.VFL = {}));
