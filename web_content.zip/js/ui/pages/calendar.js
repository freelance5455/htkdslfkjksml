/* ===================================================================
 * VFL.UI.Pages.calendar
 * تقویم فصل — هفته جاری برای همه لیگ‌ها با هم، به‌علاوه امکان مرور
 * کامل برنامه یک لیگ خاص. تاریخ واقعی هنوز پیاده نشده (بر اساس هفته).
 * =================================================================== */
(function (VFL) {
  "use strict";

  VFL.UI = VFL.UI || {};
  VFL.UI.Pages = VFL.UI.Pages || {};

  var drillDownLeagueId = null;

  VFL.UI.Pages.calendar = {
    render: function (container) {
      var state = VFL.State.get();
      var fullLeagues = VFL.Data.Leagues.filter(function (l) { return l.full; });
      var currentWeek = state.season.week;

      var html = "<h1>تقویم فصل</h1>" +
        "<p>سال " + VFL.Utils.faDigits(state.season.current) + " · " + VFL.Utils.weekLabel(currentWeek) + " (همه لیگ‌ها با هم پیش می‌روند)</p>";

      html += '<div class="section-title">بازی‌های ' + VFL.Utils.weekLabel(currentWeek) + " در همه لیگ‌ها</div>";

      var anyThisWeek = false;
      fullLeagues.forEach(function (league) {
        var fixtures = (state.fixtures[league.id] || []).filter(function (fx) { return fx.week === currentWeek; });
        if (fixtures.length === 0) return; // این لیگ فصلش زودتر تمام شده
        anyThisWeek = true;
        html += '<h3 style="margin-top:14px;">' + league.displayName + "</h3>";
        html += '<div class="row-list">' + fixtures.map(function (fx) {
          var home = VFL.Data.getTeamById(fx.home), away = VFL.Data.getTeamById(fx.away);
          return '<div class="row"><div class="row-main"><span class="row-title">' + home.name + " — " + away.name + "</span></div>" +
            '<span class="row-value">' + (fx.played ? (VFL.Utils.faDigits(fx.result.homeGoals) + "-" + VFL.Utils.faDigits(fx.result.awayGoals)) : "—") + "</span></div>";
        }).join("") + "</div>";
      });
      if (!anyThisWeek) {
        html += '<div class="empty-state">هیچ لیگ فعالی برای این هفته بازی ندارد — همه فصل خود را تمام کرده‌اند.</div>';
      }

      html += '<div class="section-title">سایر مسابقات این فصل</div><div class="row-list">';
      if (state.cup) {
        var cupRound = state.cup.bracket.rounds[state.cup.bracket.rounds.length - 1];
        html += '<div class="row clickable" data-goto="cup"><div class="row-main"><span class="row-title">جام حذفی</span>' +
          '<span class="row-sub">' + cupRound.label + (state.cup.bracket.championTeamId ? " · قهرمان مشخص شد" : "") + "</span></div><span class=\"row-value\">›</span></div>";
      }
      html += '<div class="row clickable" data-goto="super-cup"><div class="row-main"><span class="row-title">سوپر جام</span>' +
        '<span class="row-sub">' + (state.superCup.played ? "بازی شده" : "برنامه‌ریزی‌نشده") + "</span></div><span class=\"row-value\">›</span></div>";
      if (state.championsLeague) {
        html += '<div class="row clickable" data-goto="champions-league"><div class="row-main"><span class="row-title">لیگ قهرمانان اروپا</span>' +
          '<span class="row-sub">مرحله: ' + phaseLabel(state.championsLeague.phase) + "</span></div><span class=\"row-value\">›</span></div>";
      }
      html += "</div>";

      // --- مرور کامل برنامه یک لیگ خاص ---
      html += '<div class="section-title">مرور کامل برنامه یک لیگ</div>';
      html += '<div class="chip-row" id="league-chips">' + fullLeagues.map(function (l) {
        var active = l.id === drillDownLeagueId ? " active" : "";
        return '<div class="chip' + active + '" data-league="' + l.id + '">' + l.displayName + "</div>";
      }).join("") + "</div>";

      if (drillDownLeagueId) {
        var fixtures = state.fixtures[drillDownLeagueId] || [];
        var byWeek = {};
        fixtures.forEach(function (fx) { (byWeek[fx.week] = byWeek[fx.week] || []).push(fx); });
        var weeks = Object.keys(byWeek).map(Number).sort(function (a, b) { return a - b; });
        weeks.forEach(function (week) {
          html += '<div class="section-title">' + VFL.Utils.weekLabel(VFL.State.getDisplayWeek(drillDownLeagueId, week)) + (week === currentWeek ? " · هفته جاری" : "") + "</div>";
          html += '<div class="row-list">' + byWeek[week].map(function (fx) {
            var home = VFL.Data.getTeamById(fx.home), away = VFL.Data.getTeamById(fx.away);
            return '<div class="row"><div class="row-main"><span class="row-title">' + home.name + " — " + away.name + "</span></div>" +
              '<span class="row-value">' + (fx.played ? (VFL.Utils.faDigits(fx.result.homeGoals) + "-" + VFL.Utils.faDigits(fx.result.awayGoals)) : "—") + "</span></div>";
          }).join("") + "</div>";
        });
      }

      container.innerHTML = html;
      container.querySelectorAll("[data-goto]").forEach(function (row) {
        row.addEventListener("click", function () { window.location.hash = "#/" + row.getAttribute("data-goto"); });
      });
      container.querySelectorAll("[data-league]").forEach(function (chip) {
        chip.addEventListener("click", function () {
          drillDownLeagueId = drillDownLeagueId === chip.getAttribute("data-league") ? null : chip.getAttribute("data-league");
          VFL.UI.Pages.calendar.render(container);
        });
      });
    }
  };

  function phaseLabel(phase) {
    var labels = { league: "مرحله لیگ", playoff: "پلی‌آف", r16: "یک‌شانزدهم نهایی", qf: "یک‌چهارم نهایی", sf: "نیمه‌نهایی", final: "فینال", done: "پایان‌یافته" };
    return labels[phase] || phase;
  }
})(window.VFL || (window.VFL = {}));
