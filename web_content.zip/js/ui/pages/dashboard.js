/* ===================================================================
 * VFL.UI.Pages.dashboard
 * =================================================================== */
(function (VFL) {
  "use strict";

  VFL.UI = VFL.UI || {};
  VFL.UI.Pages = VFL.UI.Pages || {};

  VFL.UI.Pages.dashboard = {
    render: function (container) {
      var state = VFL.State.get();

      if (!state || !state.selectedTeamId) {
        container.innerHTML =
          "<h1>داشبورد تیم</h1>" +
          '<div class="empty-state"><strong>هنوز تیمی انتخاب نشده</strong>برای دیدن داشبورد، ابتدا یک تیم انتخاب کن.</div>' +
          '<br><button class="btn" id="go-select">انتخاب تیم</button>';
        container.querySelector("#go-select").addEventListener("click", function () {
          window.location.hash = "#/team-select";
        });
        return;
      }

      var team = VFL.Data.getTeamById(state.selectedTeamId);
      var league = VFL.Data.getLeagueById(team.league);
      var leagueTable = VFL.Utils.sortStandings(state.standings[team.league] || []);
      var position = leagueTable.findIndex(function (row) { return row.teamId === team.id; }) + 1;
      var ownRow = state.standings[team.league].find(function (r) { return r.teamId === team.id; });

      var remaining = VFL.State.getRemainingFixturesForTeam(team.id).sort(function (a, b) { return a.week - b.week; });
      var nextFixture = remaining[0];
      var results = VFL.State.getResultsForTeam(team.id);

      var nextFixtureHtml = "بدون بازی برنامه‌ریزی‌شده";
      if (nextFixture) {
        var opponentId = nextFixture.home === team.id ? nextFixture.away : nextFixture.home;
        var opponent = VFL.Data.getTeamById(opponentId);
        var venue = nextFixture.home === team.id ? "خانگی" : "خارج از خانه";
        nextFixtureHtml =
          VFL.Utils.weekLabel(VFL.State.getDisplayWeek(team.league, nextFixture.week)) + " · " + opponent.name + " (" + venue + ")";
      }

      var form = state.form[team.id] || [];
      var formHtml = form.map(function (r) { return '<div class="form-pip ' + r.toLowerCase() + '">' + r + "</div>"; }).join("") +
        Array(Math.max(0, 5 - form.length)).fill('<div class="form-pip empty">—</div>').join("");

      results.reverse();

      container.innerHTML =
        "<h1>داشبورد تیم</h1>" +
        '<div class="hero-strip">' +
        '<div class="hero-team-name">' + team.name + "</div>" +
        '<div class="hero-team-meta">' + team.country + (league ? " · " + league.displayName : "") + "</div>" +
        '<div class="hero-stat-strip">' +
        '<div class="hero-stat"><div class="hero-stat-value">' + VFL.Utils.faDigits(team.overall) + '</div><div class="hero-stat-label">Overall</div></div>' +
        '<div class="hero-stat"><div class="hero-stat-value">' + (position || "—") + '</div><div class="hero-stat-label">جایگاه جدول</div></div>' +
        '<div class="hero-stat"><div class="hero-stat-value">' + VFL.Utils.faDigits(ownRow ? ownRow.points : 0) + '</div><div class="hero-stat-label">امتیاز</div></div>' +
        "</div>" +
        '<div class="form-strip">' + formHtml + "</div>" +
        "</div>" +

        '<div class="section-title">بازی بعدی</div>' +
        '<div class="row-list"><div class="row' + (nextFixture ? " clickable" : "") + '"' + (nextFixture ? ' id="next-fixture-row"' : "") + '><div class="row-main"><span class="row-title">' + nextFixtureHtml + "</span></div>" +
        (nextFixture ? '<span class="row-value">›</span>' : "") + "</div></div>" +

        '<div class="section-title">آخرین نتایج</div>' +
        (results.length
          ? '<div class="row-list">' + results.map(function (fx) {
              var opp = VFL.Data.getTeamById(fx.home === team.id ? fx.away : fx.home);
              var score = fx.result ? (fx.result.homeGoals + " - " + fx.result.awayGoals) : "—";
              return (
                '<div class="row"><div class="row-main"><span class="row-title">' +
                VFL.Utils.weekLabel(VFL.State.getDisplayWeek(team.league, fx.week)) + " · " + opp.name +
                "</span></div><span class=\"row-value\">" + score + "</span></div>"
              );
            }).join("") + "</div>"
          : '<div class="empty-state">هنوز بازی‌ای انجام نشده. موتور شبیه‌سازی مسابقه در مرحله بعد اضافه می‌شود.</div>');

      var btnRow = document.createElement("div");
      btnRow.style.marginTop = "20px";
      btnRow.style.display = "flex";
      btnRow.style.gap = "8px";
      btnRow.innerHTML =
        '<button class="btn small" id="view-squad">بازیکنان تیم</button>' +
        '<button class="btn small ghost" id="change-team">تغییر تیم</button>';
      container.appendChild(btnRow);
      container.querySelector("#change-team").addEventListener("click", function () {
        window.location.hash = "#/team-select";
      });
      container.querySelector("#view-squad").addEventListener("click", function () {
        window.location.hash = "#/squad";
      });
      var nextRow = container.querySelector("#next-fixture-row");
      if (nextRow && nextFixture) {
        nextRow.addEventListener("click", function () {
          window.location.hash = "#/match/" + nextFixture.id;
        });
      }
    }
  };
})(window.VFL || (window.VFL = {}));
