/* ===================================================================
 * VFL.UI.Pages.season
 * وضعیت هر لیگ به‌طور جداگانه؛ هر لیگی که فصلش تمام شده را می‌توان
 * مستقل بست (و اگر بخشی از صعود/سقوط باشد، منتظر طرف مقابلش می‌ماند).
 * سال تقویم بازی جدا و با اختیار خود کاربر جلو می‌رود.
 * =================================================================== */
(function (VFL) {
  "use strict";

  VFL.UI = VFL.UI || {};
  VFL.UI.Pages = VFL.UI.Pages || {};

  VFL.UI.Pages.season = {
    render: function (container) {
      var state = VFL.State.get();
      var pt = VFL.State.getPendingTransition();

      var html = "<h1>پایان فصل</h1><p>سال تقویم فعلی: " + VFL.Utils.faDigits(state.season.current) + "</p>";

      if (pt) {
        html += renderTransitionSection(pt);
        container.innerHTML = html;
        bindTransitionEvents(container);
        return;
      }

      var statuses = VFL.State.getLeagueSeasonStatus();
      html += '<div class="section-title">وضعیت لیگ‌ها</div><div class="row-list">';
      statuses.forEach(function (st) {
        var label = st.finished ? "فصل تمام شده" : VFL.Utils.faDigits(st.playedMatches) + " از " + VFL.Utils.faDigits(st.totalMatches) + " بازی";
        html += '<div class="row"><div class="row-main"><span class="row-title">' + st.displayName + "</span><br><span class=\"row-sub\">" + label + "</span></div>" +
          (st.finished ? '<button class="btn small" data-end-league="' + st.leagueId + '">پایان فصل این لیگ</button>' : "") +
          "</div>";
      });
      html += "</div>";

      html += '<div class="section-title">تقویم کلی</div>' +
        '<p>وقتی همه یا اکثر لیگ‌ها فصلشان تمام شد، می‌توانی سال تقویم را برای برچسب فصل جدید جلو ببری.</p>' +
        '<button class="btn ghost" id="advance-year">جلو بردن سال تقویم به ' + VFL.Utils.faDigits(state.season.current + 1) + "</button>";

      container.innerHTML = html;

      container.querySelectorAll("[data-end-league]").forEach(function (btn) {
        btn.addEventListener("click", function () {
          var result = VFL.State.endLeagueSeason(btn.getAttribute("data-end-league"));
          if (result.type === "waiting_for_partner") {
            alert("این لیگ آرشیو شد، اما چون بخشی از صعود/سقوط است، تا پایان فصل لیگ مرتبط صبر می‌کند.");
            VFL.UI.Pages.season.render(container);
          } else if (result.type === "league_restarted") {
            window.location.hash = "#/honours";
          } else {
            VFL.UI.Pages.season.render(container);
          }
        });
      });

      container.querySelector("#advance-year").addEventListener("click", function () {
        VFL.State.advanceCalendarYear();
        VFL.UI.Pages.season.render(container);
      });
    }
  };

  function renderTransitionSection(pt) {
    var html = "<p>در حال تعیین صعود و سقوط بین دو لیگ هستیم.</p>";

    if (pt.phase === "playoff") {
      pt.transitions.forEach(function (t) {
        if (!t.playoff) return;
        html += renderPlayoffTie("نیمه‌نهایی اول", t.playoff.semiA);
        html += renderPlayoffTie("نیمه‌نهایی دوم", t.playoff.semiB);
        if (t.playoff.final) html += renderFinal(t.playoff.final);
      });
      html += '<button class="btn" id="playoff-step" style="margin-top:16px;">ادامه پلی‌آف</button>';
      return html;
    }

    // phase === 'ready'
    html += "<p>نتیجه صعود و سقوط مشخص شد:</p>";
    pt.transitions.forEach(function (t) {
      html += '<div class="section-title">' + (t.link.label || VFL.Data.getLeagueById(t.link.upperLeagueId).displayName) + "</div>";
      html += '<div class="row-list">';
      t.autoPromotedFromLower.forEach(function (id) { html += teamRow(id, "صعود مستقیم"); });
      if (t.playoffWinner) html += teamRow(t.playoffWinner, "صعود از پلی‌آف");
      t.relegatedFromUpper.forEach(function (id) { html += teamRow(id, "سقوط"); });
      html += "</div>";
    });
    html += '<button class="btn" id="start-new-leagues" style="margin-top:16px;">اعمال و بازسازی این دو لیگ</button>';
    return html;
  }

  function bindTransitionEvents(container) {
    var stepBtn = container.querySelector("#playoff-step");
    if (stepBtn) stepBtn.addEventListener("click", function () {
      VFL.State.simulatePromotionPlayoffStep();
      VFL.UI.Pages.season.render(container);
    });
    var startBtn = container.querySelector("#start-new-leagues");
    if (startBtn) startBtn.addEventListener("click", function () {
      VFL.State.finalizeNewSeasonTransition();
      window.location.hash = "#/honours";
    });
  }

  function teamRow(teamId, label) {
    var t = VFL.Data.getTeamById(teamId);
    return '<div class="row"><div class="row-main"><span class="row-title">' + t.name + "</span></div><span class=\"row-value\">" + label + "</span></div>";
  }

  function renderPlayoffTie(label, tie) {
    var teamA = VFL.Data.getTeamById(tie.leg1.home), teamB = VFL.Data.getTeamById(tie.leg1.away);
    var leg1 = tie.leg1.played ? VFL.Utils.faDigits(tie.leg1.result.homeGoals) + "-" + VFL.Utils.faDigits(tie.leg1.result.awayGoals) : "—";
    var leg2 = tie.leg2.played ? VFL.Utils.faDigits(tie.leg2.result.homeGoals) + "-" + VFL.Utils.faDigits(tie.leg2.result.awayGoals) : "—";
    var winner = tie.aggregateWinner ? " (برنده: " + VFL.Data.getTeamById(tie.aggregateWinner).name + ")" : "";
    return '<div class="section-title">' + label + '</div><div class="row-list"><div class="row"><div class="row-main"><span class="row-title">' +
      teamA.name + " — " + teamB.name + "</span><br><span class=\"row-sub\">لگ اول: " + leg1 + " · لگ دوم: " + leg2 + winner + "</span></div></div></div>";
  }

  function renderFinal(final) {
    var home = VFL.Data.getTeamById(final.home), away = VFL.Data.getTeamById(final.away);
    var text = final.played ? VFL.Utils.faDigits(final.result.homeGoals) + "-" + VFL.Utils.faDigits(final.result.awayGoals) : "برنامه‌ریزی‌شده";
    return '<div class="section-title">فینال پلی‌آف</div><div class="row-list"><div class="row"><div class="row-main"><span class="row-title">' +
      home.name + " — " + away.name + "</span></div><span class=\"row-value\">" + text + "</span></div></div>";
  }
})(window.VFL || (window.VFL = {}));
