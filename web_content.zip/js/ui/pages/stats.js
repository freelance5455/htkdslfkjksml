/* ===================================================================
 * VFL.UI.Pages.stats
 * آمار بازیکنان — همیشه مخصوص لیگ فعال (همان لیگی که در صفحه مسابقات
 * انتخاب شده)، نه یک لیست سراسری ثابت. تغییر لیگ اینجا، لیگ فعال را
 * برای بقیه بازی هم عوض می‌کند.
 * =================================================================== */
(function (VFL) {
  "use strict";

  VFL.UI = VFL.UI || {};
  VFL.UI.Pages = VFL.UI.Pages || {};

  VFL.UI.Pages.stats = {
    render: function (container) {
      var state = VFL.State.get();
      var fullLeagues = VFL.Data.Leagues.filter(function (l) { return l.full; });
      var activeLeagueId = VFL.State.getActiveLeague();
      var league = VFL.Data.getLeagueById(activeLeagueId);

      var leagueTeamIds = VFL.Data.getTeamsByLeague(activeLeagueId).map(function (t) { return t.id; });
      var players = state.players.filter(function (p) {
        return leagueTeamIds.indexOf(p.teamId) !== -1 && p.seasonStats.matches > 0;
      });

      var html = "<h1>آمار بازیکنان</h1>";
      html += '<div class="chip-row" id="league-chips">' + fullLeagues.map(function (l) {
        var active = l.id === activeLeagueId ? " active" : "";
        return '<div class="chip' + active + '" data-league="' + l.id + '">' + l.displayName + "</div>";
      }).join("") + "</div>";
      html += "<p>" + league.displayName + "</p>";

      if (players.length === 0) {
        html += '<div class="empty-state"><strong>هنوز بازی‌ای در ' + league.displayName + ' انجام نشده</strong>بعد از شبیه‌سازی چند مسابقه، آمار اینجا نمایش داده می‌شود.</div>';
        container.innerHTML = html;
        bindChips(container);
        return;
      }

      var topScorers = players.filter(function (p) { return p.seasonStats.goals > 0; })
        .sort(function (a, b) { return b.seasonStats.goals - a.seasonStats.goals; }).slice(0, 10);
      var topAssists = players.filter(function (p) { return p.seasonStats.assists > 0; })
        .sort(function (a, b) { return b.seasonStats.assists - a.seasonStats.assists; }).slice(0, 10);
      var topRated = players.slice().sort(function (a, b) { return (b.seasonStats.avgRating || 0) - (a.seasonStats.avgRating || 0); }).slice(0, 10);
      var topKeepers = players.filter(function (p) { return p.position === "GK"; })
        .sort(function (a, b) { return (b.seasonStats.avgRating || 0) - (a.seasonStats.avgRating || 0); }).slice(0, 5);

      html += leaderboard("⚽ بهترین گلزنان", topScorers, function (p) { return VFL.Utils.faDigits(p.seasonStats.goals) + " گل"; });
      html += leaderboard("🎯 بهترین پاس‌گل‌دهنده‌ها", topAssists, function (p) { return VFL.Utils.faDigits(p.seasonStats.assists) + " پاس‌گل"; });
      html += leaderboard("⭐ برترین‌های امتیاز مسابقه", topRated, function (p) { return VFL.Utils.faDigits(p.seasonStats.avgRating) + " امتیاز"; });
      html += leaderboard("🧤 برترین دروازه‌بان‌ها", topKeepers, function (p) { return p.seasonStats.avgRating ? VFL.Utils.faDigits(p.seasonStats.avgRating) + " امتیاز" : "—"; });

      container.innerHTML = html;
      bindChips(container);
    }
  };

  function bindChips(container) {
    container.querySelectorAll("[data-league]").forEach(function (chip) {
      chip.addEventListener("click", function () {
        VFL.State.setActiveLeague(chip.getAttribute("data-league"));
        VFL.UI.Pages.stats.render(container);
      });
    });
  }

  function leaderboard(title, list, valueFn) {
    if (list.length === 0) return "";
    var html = '<div class="section-title">' + title + "</div><div class=\"row-list\">";
    list.forEach(function (p, idx) {
      var team = VFL.Data.getTeamById(p.teamId);
      html += '<div class="row"><div class="row-main"><span class="badge muted">' + VFL.Utils.faDigits(idx + 1) + "</span>" +
        '<div><span class="row-title">' + p.name + "</span><br><span class=\"row-sub\">" + team.name + "</span></div></div>" +
        '<span class="row-value">' + valueFn(p) + "</span></div>";
    });
    return html + "</div>";
  }
})(window.VFL || (window.VFL = {}));
