/* ===================================================================
 * VFL.UI.Pages.lineup
 * انتخاب ترکیب اصلی (حداکثر ۱۱ نفر) و نیمکت. اگر چیزی انتخاب نشود،
 * موتور مسابقه طبق قبل خودش ۱۱ بازیکن برتر بر اساس Overall را انتخاب می‌کند.
 * =================================================================== */
(function (VFL) {
  "use strict";

  VFL.UI = VFL.UI || {};
  VFL.UI.Pages = VFL.UI.Pages || {};

  var selectedStarters = null; // فقط وقتی صفحه باز است در حافظه نگه داشته می‌شود؛ با ذخیره در state ثابت می‌ماند
  var loadedForTeamId = null;

  VFL.UI.Pages.lineup = {
    render: function (container, params) {
      var teamId = params && params.id;
      var team = teamId ? VFL.Data.getTeamById(teamId) : null;
      if (!team) { container.innerHTML = '<div class="empty-state"><strong>تیم پیدا نشد</strong></div>'; return; }

      var squad = VFL.State.getSquad(teamId);
      if (squad.length === 0) {
        container.innerHTML = "<h1>ترکیب " + team.name + "</h1>" +
          '<div class="empty-state">این تیم دیتابیس بازیکن ندارد؛ ترکیب فقط برای تیم‌های دارای بازیکن قابل چیدن است.</div>';
        return;
      }

      if (selectedStarters === null || loadedForTeamId !== teamId) {
        var existing = VFL.State.getLineup(teamId);
        selectedStarters = existing ? existing.starters.slice() : [];
        loadedForTeamId = teamId;
      }

      var html = "<h1>ترکیب " + team.name + "</h1>" +
        "<p>حداکثر ۱۱ بازیکن را به‌عنوان ترکیب اصلی انتخاب کن. بقیه به‌طور خودکار نیمکت حساب می‌شوند. " +
        "اگر چیزی انتخاب نکنی، موتور طبق قبل ۱۱ بازیکن برتر بر اساس Overall را خودش انتخاب می‌کند.</p>";

      html += '<div class="row-list"><div class="row"><div class="row-main"><span class="row-title">انتخاب‌شده</span></div>' +
        '<span class="row-value">' + VFL.Utils.faDigits(selectedStarters.length) + " / ۱۱</span></div></div>";

      var sorted = squad.slice().sort(function (a, b) { return b.overall - a.overall; });
      html += '<div class="section-title">بازیکنان</div><div class="row-list">';
      sorted.forEach(function (p) {
        var isStarter = selectedStarters.indexOf(p.id) !== -1;
        var shirt = VFL.Utils.shirtLabel(p);
        html += '<div class="row clickable" data-player="' + p.id + '"' + (isStarter ? ' style="border-color:var(--amber);"' : "") + '>' +
          '<div class="row-main"><span class="badge' + (isStarter ? "" : " muted") + '">' + VFL.Utils.faDigits(p.overall) + "</span>" +
          '<div><span class="row-title">' + (shirt ? shirt + " " : "") + p.name + "</span><br><span class=\"row-sub\">" + VFL.Utils.playerSubLabel(p) + "</span></div></div>" +
          '<span class="row-value">' + (isStarter ? "در ترکیب اصلی ✓" : "نیمکت") + "</span></div>";
      });
      html += "</div>";

      html += '<div style="display:flex; gap:8px; margin-top:16px;">' +
        '<button class="btn" id="save-lineup">ذخیره ترکیب</button>' +
        '<button class="btn ghost" id="reset-lineup">بازگشت به انتخاب خودکار</button>' +
        "</div>";

      container.innerHTML = html;

      container.querySelectorAll("[data-player]").forEach(function (row) {
        row.addEventListener("click", function () {
          var pid = row.getAttribute("data-player");
          var idx = selectedStarters.indexOf(pid);
          if (idx !== -1) {
            selectedStarters.splice(idx, 1);
          } else if (selectedStarters.length < 11) {
            selectedStarters.push(pid);
          }
          VFL.UI.Pages.lineup.render(container, { id: teamId });
        });
      });

      container.querySelector("#save-lineup").addEventListener("click", function () {
        VFL.State.setLineup(teamId, selectedStarters);
        window.location.hash = "#/team/" + teamId;
      });

      container.querySelector("#reset-lineup").addEventListener("click", function () {
        VFL.State.clearLineup(teamId);
        selectedStarters = null;
        VFL.UI.Pages.lineup.render(container, { id: teamId });
      });
    }
  };
})(window.VFL || (window.VFL = {}));
