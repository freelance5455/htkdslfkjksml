/* ===================================================================
 * VFL.UI.Pages.honours
 * افتخارات — جوایز واقعی پایان هر فصل (بر اساس آمار واقعی، نه تصادفی)
 * به‌علاوه قهرمانان فعلی جام حذفی / سوپر جام / لیگ قهرمانان اروپا.
 * =================================================================== */
(function (VFL) {
  "use strict";

  VFL.UI = VFL.UI || {};
  VFL.UI.Pages = VFL.UI.Pages || {};

  VFL.UI.Pages.honours = {
    render: function (container) {
      var state = VFL.State.get();
      var html = "<h1>افتخارات</h1>";

      html += '<div class="section-title">قهرمانان فعلی</div><div class="row-list">';
      if (state.cup && state.cup.bracket.championTeamId) {
        html += trophyRow("جام حذفی", VFL.Data.getTeamById(state.cup.bracket.championTeamId).name);
      }
      if (state.superCup.played) {
        var scWinner = state.superCup.result.homeGoals >= state.superCup.result.awayGoals ? state.superCup.homeTeamId : state.superCup.awayTeamId;
        html += trophyRow("سوپر جام", VFL.Data.getTeamById(scWinner).name);
      }
      if (state.championsLeague && state.championsLeague.championTeamId) {
        html += trophyRow("لیگ قهرمانان اروپا", VFL.Data.getTeamById(state.championsLeague.championTeamId).name);
      }
      if ((!state.cup || !state.cup.bracket.championTeamId) && !state.superCup.played && (!state.championsLeague || !state.championsLeague.championTeamId)) {
        html += '<div class="empty-state">هنوز هیچ‌کدام از این مسابقات قهرمان ندارند.</div>';
      }
      html += "</div>";

      var history = VFL.State.getSeasonAwardsHistory().slice().reverse();
      html += '<div class="section-title">جوایز پایان فصل لیگ‌ها</div>';
      if (history.length === 0) {
        html += '<div class="empty-state"><strong>هنوز فصلی تمام نشده</strong>وقتی یک لیگ فصلش را تمام کرد و از صفحه «پایان فصل» بسته شد، جوایز واقعی همان فصل اینجا ثبت می‌شود.</div>';
      } else {
        history.forEach(function (a) {
          html += renderAward(a);
        });
      }

      html += '<div class="empty-state" style="margin-top:20px;">لیگ اروپا (Europa League) و لیگ کنفرانس (Conference League) هنوز ساخته نشده‌اند.</div>';

      container.innerHTML = html;
    }
  };

  function trophyRow(label, winner) {
    return '<div class="row"><div class="row-main"><span class="row-title">🏆 ' + label + "</span></div><span class=\"row-value\">" + winner + "</span></div>";
  }

  function playerName(playerId) {
    var p = VFL.State.getPlayer(playerId);
    return p ? p.name : "—";
  }

  function renderAward(a) {
    var league = VFL.Data.getLeagueById(a.leagueId);
    var html = '<div class="hero-strip">' +
      '<div class="hero-team-name">' + league.displayName + " — سال " + VFL.Utils.faDigits(a.year) + "</div>";
    if (a.championTeamId) {
      html += '<div class="hero-team-meta">🏆 قهرمان: ' + VFL.Data.getTeamById(a.championTeamId).name + "</div>";
    }
    html += '<div class="row-list" style="margin-top:12px; border-top:none;">';
    if (a.topScorer) html += awardRow("⚽ آقای گل", playerName(a.topScorer.playerId), VFL.Utils.faDigits(a.topScorer.value) + " گل");
    if (a.topAssist) html += awardRow("🎯 برترین پاس‌گل‌دهنده", playerName(a.topAssist.playerId), VFL.Utils.faDigits(a.topAssist.value) + " پاس‌گل");
    if (a.bestPlayer) html += awardRow("⭐ بهترین بازیکن فصل", playerName(a.bestPlayer.playerId), "");
    if (a.bestGoalkeeper) html += awardRow("🧤 بهترین دروازه‌بان", playerName(a.bestGoalkeeper.playerId), "");
    if (a.bestYoungPlayer) html += awardRow("🌟 بهترین بازیکن جوان", playerName(a.bestYoungPlayer.playerId), "");
    if (a.bestAttackTeamId) html += awardRow("بهترین خط حمله", VFL.Data.getTeamById(a.bestAttackTeamId).name, "");
    if (a.bestDefenseTeamId) html += awardRow("بهترین خط دفاع", VFL.Data.getTeamById(a.bestDefenseTeamId).name, "");
    if (a.mostWinsTeamId) html += awardRow("بیشترین برد", VFL.Data.getTeamById(a.mostWinsTeamId).name, "");
    html += "</div>";
    html += '<div class="hero-stat-strip">' +
      '<div class="hero-stat"><div class="hero-stat-value">' + VFL.Utils.faDigits(a.totalMatches) + '</div><div class="hero-stat-label">بازی فصل</div></div>' +
      '<div class="hero-stat"><div class="hero-stat-value">' + VFL.Utils.faDigits(a.totalGoals) + '</div><div class="hero-stat-label">کل گل‌ها</div></div>' +
      '<div class="hero-stat"><div class="hero-stat-value">' + a.avgGoalsPerMatch + '</div><div class="hero-stat-label">میانگین گل هر بازی</div></div>' +
      "</div>";
    html += "</div>";
    return html;
  }

  function awardRow(label, name, extra) {
    return '<div class="row"><div class="row-main"><span class="row-title">' + label + "</span></div><span class=\"row-value\">" + name + (extra ? " · " + extra : "") + "</span></div>";
  }
})(window.VFL || (window.VFL = {}));
