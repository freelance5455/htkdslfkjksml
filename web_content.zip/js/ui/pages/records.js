/* ===================================================================
 * VFL.UI.Pages.records
 * رکوردهای تاریخی — همه از داده‌های واقعی فصل‌های بسته‌شده استخراج می‌شوند،
 * هیچ‌کدام ساختگی/تصادفی نیست. اگر هنوز فصلی تمام نشده، خالی نمایش داده می‌شود.
 * =================================================================== */
(function (VFL) {
  "use strict";

  VFL.UI = VFL.UI || {};
  VFL.UI.Pages = VFL.UI.Pages || {};

  VFL.UI.Pages.records = {
    render: function (container) {
      var history = VFL.State.getSeasonHistory();
      var awards = VFL.State.getSeasonAwardsHistory();

      var html = "<h1>رکوردهای تاریخی</h1>";

      if (history.length === 0 && awards.length === 0) {
        html += '<div class="empty-state"><strong>هنوز فصلی تمام نشده</strong>وقتی چند فصل بسته شد، رکوردهای واقعی اینجا نمایش داده می‌شود.</div>';
        container.innerHTML = html;
        return;
      }

      var titleCounts = {};
      awards.forEach(function (a) {
        if (!a.championTeamId) return;
        titleCounts[a.championTeamId] = (titleCounts[a.championTeamId] || 0) + 1;
      });
      var titleList = Object.keys(titleCounts).map(function (teamId) {
        return { teamId: teamId, count: titleCounts[teamId] };
      }).sort(function (a, b) { return b.count - a.count; }).slice(0, 8);

      html += '<div class="section-title">🏆 بیشترین قهرمانی‌های لیگ</div>';
      if (titleList.length === 0) {
        html += '<div class="empty-state">هنوز قهرمانی ثبت نشده.</div>';
      } else {
        html += '<div class="row-list">' + titleList.map(function (t) {
          var team = VFL.Data.getTeamById(t.teamId);
          return '<div class="row"><div class="row-main"><span class="row-title">' + team.name + "</span></div><span class=\"row-value\">" +
            VFL.Utils.faDigits(t.count) + " قهرمانی</span></div>";
        }).join("") + "</div>";
      }

      var bestScorerSeason = topByValue(awards, "topScorer");
      var bestAssistSeason = topByValue(awards, "topAssist");

      html += '<div class="section-title">📈 بهترین رکورد یک فصل (بازیکنان)</div><div class="row-list">';
      if (bestScorerSeason) {
        html += recordRow("بیشترین گل در یک فصل", bestScorerSeason.entry.topScorer.playerId,
          VFL.Utils.faDigits(bestScorerSeason.entry.topScorer.value) + " گل", bestScorerSeason.entry);
      }
      if (bestAssistSeason) {
        html += recordRow("بیشترین پاس‌گل در یک فصل", bestAssistSeason.entry.topAssist.playerId,
          VFL.Utils.faDigits(bestAssistSeason.entry.topAssist.value) + " پاس‌گل", bestAssistSeason.entry);
      }
      if (!bestScorerSeason && !bestAssistSeason) html += '<div class="empty-state">هنوز داده‌ای ثبت نشده.</div>';
      html += "</div>";

      var bestAttack = null, bestDefense = null, mostPoints = null;
      history.forEach(function (h) {
        h.standings.forEach(function (row) {
          if (!bestAttack || row.goalsFor > bestAttack.row.goalsFor) bestAttack = { row: row, year: h.year, leagueId: h.leagueId };
          if (!bestDefense || row.goalsAgainst < bestDefense.row.goalsAgainst) bestDefense = { row: row, year: h.year, leagueId: h.leagueId };
          if (!mostPoints || row.points > mostPoints.row.points) mostPoints = { row: row, year: h.year, leagueId: h.leagueId };
        });
      });

      html += '<div class="section-title">🛡️ بهترین رکورد یک فصل (تیم‌ها)</div><div class="row-list">';
      if (mostPoints) html += teamRecordRow("بیشترین امتیاز در یک فصل", mostPoints, VFL.Utils.faDigits(mostPoints.row.points) + " امتیاز");
      if (bestAttack) html += teamRecordRow("بهترین خط حمله یک فصل", bestAttack, VFL.Utils.faDigits(bestAttack.row.goalsFor) + " گل زده");
      if (bestDefense) html += teamRecordRow("بهترین خط دفاع یک فصل", bestDefense, VFL.Utils.faDigits(bestDefense.row.goalsAgainst) + " گل خورده");
      if (!mostPoints && !bestAttack && !bestDefense) html += '<div class="empty-state">هنوز داده‌ای ثبت نشده.</div>';
      html += "</div>";

      html += '<div class="empty-state" style="margin-top:16px;">جام حذفی و لیگ قهرمانان هنوز چرخه چندفصلی ندارند (هربار فقط یک قهرمان دارند)، پس فعلاً در این رکوردها حساب نشده‌اند.</div>';

      container.innerHTML = html;
    }
  };

  function topByValue(awards, field) {
    var best = null;
    awards.forEach(function (a) {
      if (!a[field]) return;
      if (!best || a[field].value > best.entry[field].value) best = { entry: a };
    });
    return best;
  }

  function recordRow(label, playerId, valueText, awardEntry) {
    var p = VFL.State.getPlayer(playerId);
    var league = VFL.Data.getLeagueById(awardEntry.leagueId);
    return '<div class="row"><div class="row-main"><span class="row-title">' + label + "</span><br><span class=\"row-sub\">" +
      (p ? p.name : "—") + " · " + league.displayName + " " + VFL.Utils.faDigits(awardEntry.year) + "</span></div>" +
      '<span class="row-value">' + valueText + "</span></div>";
  }

  function teamRecordRow(label, rec, valueText) {
    var team = VFL.Data.getTeamById(rec.row.teamId);
    var league = VFL.Data.getLeagueById(rec.leagueId);
    return '<div class="row"><div class="row-main"><span class="row-title">' + label + "</span><br><span class=\"row-sub\">" +
      team.name + " · " + league.displayName + " " + VFL.Utils.faDigits(rec.year) + "</span></div>" +
      '<span class="row-value">' + valueText + "</span></div>";
  }
})(window.VFL || (window.VFL = {}));
