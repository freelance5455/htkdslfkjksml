/* ===================================================================
 * VFL.UI.Pages.match
 * صفحه مسابقه: پیش از بازی → دکمه شبیه‌سازی. بعد از بازی → گزارش کامل.
 * =================================================================== */
(function (VFL) {
  "use strict";

  VFL.UI = VFL.UI || {};
  VFL.UI.Pages = VFL.UI.Pages || {};

  var EVENT_ICON = {
    kickoff: "🏁", goal: "⚽", yellow_card: "🟨", red_card: "🟥",
    injury: "🩹", substitution: "🔄", half_time: "⏸️", full_time: "🏁"
  };

  VFL.UI.Pages.match = {
    render: function (container, params) {
      var state = VFL.State.get();
      var id = params && params.id;
      if (!id) { container.innerHTML = '<div class="empty-state"><strong>مسابقه‌ای مشخص نشده</strong></div>'; return; }

      var report = VFL.State.getMatchReport(id);
      if (report) {
        renderReport(container, report);
        return;
      }

      // هنوز بازی نشده — باید یک فیکسچر لیگ باشد
      var found = null, leagueId = null;
      Object.keys(state.fixtures).some(function (lid) {
        var fx = state.fixtures[lid].find(function (f) { return f.id === id; });
        if (fx) { found = fx; leagueId = lid; return true; }
        return false;
      });

      if (!found) {
        container.innerHTML = '<div class="empty-state"><strong>مسابقه پیدا نشد</strong></div>';
        return;
      }

      renderPreMatch(container, found, leagueId, id);
    }
  };

  function renderPreMatch(container, fixture, leagueId, fixtureId) {
    var home = VFL.Data.getTeamById(fixture.home);
    var away = VFL.Data.getTeamById(fixture.away);
    var league = VFL.Data.getLeagueById(leagueId);

    container.innerHTML =
      "<h1>مسابقه</h1>" +
      "<p>" + league.displayName + " · " + VFL.Utils.weekLabel(fixture.week) + "</p>" +
      '<div class="hero-strip"><div class="match-scoreline">' +
      '<div class="match-team"><div class="match-team-name">' + home.name + '</div><div class="match-team-overall">Overall ' + VFL.Utils.faDigits(home.overall) + "</div></div>" +
      '<div class="match-vs">در برابر</div>' +
      '<div class="match-team"><div class="match-team-name">' + away.name + '</div><div class="match-team-overall">Overall ' + VFL.Utils.faDigits(away.overall) + "</div></div>" +
      "</div></div>" +
      '<button class="btn" id="simulate-btn">شبیه‌سازی این مسابقه</button>';

    container.querySelector("#simulate-btn").addEventListener("click", function () {
      VFL.State.simulateFixture(fixtureId);
      VFL.State.save();
      VFL.UI.Pages.match.render(container, { id: fixtureId });
    });
  }

  function renderReport(container, report) {
    var home = VFL.Data.getTeamById(report.homeTeamId);
    var away = VFL.Data.getTeamById(report.awayTeamId);
    var hs = report.teamStats.home, as = report.teamStats.away;

    var html = "<h1>گزارش مسابقه</h1>";

    html += '<div class="hero-strip"><div class="match-scoreline">' +
      '<div class="match-team"><div class="match-team-name">' + home.name + "</div></div>" +
      '<div class="match-vs" style="font-size:22px; font-weight:700; color:var(--amber);">' +
      VFL.Utils.faDigits(report.homeGoals) + " - " + VFL.Utils.faDigits(report.awayGoals) + "</div>" +
      '<div class="match-team"><div class="match-team-name">' + away.name + "</div></div>" +
      "</div></div>";

    if (report.motm) {
      var motmPlayer = VFL.State.getPlayer(report.motm);
      if (motmPlayer) {
        html += '<div class="row-list"><div class="row"><div class="row-main"><span class="row-title">برترین بازیکن مسابقه</span></div>' +
          '<span class="row-value">' + motmPlayer.name + " (" + VFL.Utils.faDigits(report.motmRating) + ")</span></div></div>";
      }
    }

    html += '<div class="section-title">آمار تیمی</div>';
    html += buildStatsTable(home.name, away.name, hs, as);

    html += '<div class="section-title">جدول زمانی مسابقه</div>';
    html += '<div class="row-list">' + report.timeline.map(function (ev) {
      var icon = EVENT_ICON[ev.type] || "•";
      return '<div class="row"><div class="row-main"><span class="badge muted">' + VFL.Utils.faDigits(ev.minute) + "'</span>" +
        '<span class="row-title">' + icon + " " + ev.text + "</span></div></div>";
    }).join("") + "</div>";

    container.innerHTML = html;
  }

  function statRow(label, homeVal, awayVal) {
    return (
      '<div class="row"><span class="row-value" style="min-width:40px; text-align:center;">' + homeVal + "</span>" +
      '<div class="row-main" style="justify-content:center; flex:1;"><span class="row-sub">' + label + "</span></div>" +
      '<span class="row-value" style="min-width:40px; text-align:center;">' + awayVal + "</span></div>"
    );
  }

  function buildStatsTable(homeName, awayName, hs, as) {
    var f = VFL.Utils.faDigits;
    return (
      '<div class="row-list">' +
      '<div class="row"><span class="row-title" style="flex:1; text-align:center;">' + homeName + '</span><span class="row-title" style="flex:1; text-align:center;">' + awayName + "</span></div>" +
      statRow("تصرف توپ", f(hs.possession) + "%", f(as.possession) + "%") +
      statRow("شوت", f(hs.shots), f(as.shots)) +
      statRow("شوت در چارچوب", f(hs.shotsOnTarget), f(as.shotsOnTarget)) +
      statRow("موقعیت خطرناک", f(hs.bigChances), f(as.bigChances)) +
      statRow("پاس", f(hs.passes), f(as.passes)) +
      statRow("دقت پاس", f(hs.passAccuracy) + "%", f(as.passAccuracy) + "%") +
      statRow("کرنر", f(hs.corners), f(as.corners)) +
      statRow("خطا", f(hs.fouls), f(as.fouls)) +
      statRow("آفساید", f(hs.offsides), f(as.offsides)) +
      statRow("کارت زرد", f(hs.yellowCards), f(as.yellowCards)) +
      statRow("کارت قرمز", f(hs.redCards), f(as.redCards)) +
      statRow("xG", hs.xG, as.xG) +
      statRow("سیو دروازه‌بان", f(hs.saves), f(as.saves)) +
      "</div>"
    );
  }
})(window.VFL || (window.VFL = {}));
