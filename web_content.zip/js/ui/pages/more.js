/* ===================================================================
 * VFL.UI.Pages.more
 * =================================================================== */
(function (VFL) {
  "use strict";

  VFL.UI = VFL.UI || {};
  VFL.UI.Pages = VFL.UI.Pages || {};

  var ITEMS = [
    { route: "calendar", icon: "📅", label: "تقویم فصل" },
    { route: "cup", icon: "🏆", label: "جام حذفی" },
    { route: "super-cup", icon: "🥇", label: "سوپر جام" },
    { route: "champions-league", icon: "🌍", label: "لیگ قهرمانان اروپا" },
    { route: "honours", icon: "🏆", label: "افتخارات" },
    { route: "season-archive", icon: "📜", label: "تاریخچه فصل‌ها" },
    { route: "records", icon: "📈", label: "رکوردهای تاریخی" },
    { route: "season", icon: "🔁", label: "پایان فصل" },
    { route: "settings", icon: "⚙️", label: "تنظیمات لیگ" }
  ];

  VFL.UI.Pages.more = {
    render: function (container) {
      container.innerHTML = "<h1>بیشتر</h1>" +
        '<div class="row-list">' + ITEMS.map(function (item) {
          return '<div class="row clickable" data-goto="' + item.route + '">' +
            '<div class="row-main"><span style="font-size:18px;">' + item.icon + "</span>" +
            '<span class="row-title">' + item.label + "</span></div>" +
            '<span class="row-value">›</span></div>';
        }).join("") + "</div>";

      container.querySelectorAll("[data-goto]").forEach(function (row) {
        row.addEventListener("click", function () {
          window.location.hash = "#/" + row.getAttribute("data-goto");
        });
      });
    }
  };
})(window.VFL || (window.VFL = {}));
