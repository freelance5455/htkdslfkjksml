/* ===================================================================
 * VFL.UI.Pages.competitions
 * مسابقات هفته‌ها: انتخاب لیگ (مستقل از تیم تحت کنترل)، هفته جاری مشخص،
 * نتایج قبلی، بازی‌های آینده، انتخاب مسابقه، شروع شبیه‌سازی.
 * =================================================================== */
(function (VFL) {
  "use strict";

  VFL.UI = VFL.UI || {};
  VFL.UI.Pages = VFL.UI.Pages || {};

  VFL.UI.Pages.competitions = {
    render: function (container) {
      var state = VFL.State.get();
      var fullLeagues = VFL.Data.Leagues.filter(function (l) { return l.full; });
      var activeLeagueId = VFL.State.getActiveLeague();
      var league = VFL.Data.getLeagueById(activeLeagueId);
      var myTeam = state.selectedTeamId ? VFL.Data.getTeamById(state.selectedTeamId) : null;

      var fixtures = state.fixtures[activeLeagueId] || [];
      var byWeek = {};
      fixtures.forEach(function (fx) { (byWeek[fx.week] = byWeek[fx.week] || []).push(fx); });
      var weeks = Object.keys(byWeek).map(Number).sort(function (a, b) { return a - b; });
      var currentWeekHasUnplayed = (byWeek[state.season.week] || []).some(function (fx) { return !fx.played; });

      var html = "<h1>مسابقات</h1>";

      html += '<div class="chip-row" id="league-chips">' + fullLeagues.map(function (l) {
        var active = l.id === activeLeagueId ? " active" : "";
        return '<div class="chip' + active + '" data-league="' + l.id + '">' + l.displayName + "</div>";
      }).join("") + "</div>";

      html += "<p>" + league.displayName + " · فصل " + VFL.Utils.faDigits(state.season.current) + "</p>";
      html += '<div class="row-list" style="margin-bottom:12px;"><div class="row clickable" data-goto="stats"><div class="row-main"><span class="row-title">📊 آمار بازیکنان همین لیگ</span></div><span class="row-value">›</span></div></div>';

      if (currentWeekHasUnplayed) {
        html += '<button class="btn" id="sim-week" style="margin-bottom:16px;">شبیه‌سازی هفته جاری همه لیگ‌ها (' + VFL.Utils.weekLabel(state.season.week) + ")</button>";
      }

      var orderedWeeks = [state.season.week].concat(weeks.filter(function (w) { return w !== state.season.week; }));

      orderedWeeks.forEach(function (week) {
        if (!byWeek[week]) return;
        var isCurrent = week === state.season.week;
        html += '<div class="section-title">' + VFL.Utils.weekLabel(VFL.State.getDisplayWeek(activeLeagueId, week)) + (isCurrent ? " · هفته جاری" : "") + "</div>";
        html += '<div class="row-list">' + byWeek[week].map(function (fx) {
          var home = VFL.Data.getTeamById(fx.home), away = VFL.Data.getTeamById(fx.away);
          var isOwn = myTeam && (fx.home === myTeam.id || fx.away === myTeam.id);
          return '<div class="row clickable" data-fixture="' + fx.id + '"><div class="row-main"><span class="row-title">' +
            (isOwn ? "⭐ " : "") + home.name + " — " + away.name + "</span></div>" +
            '<span class="row-value">' + (fx.played ? (VFL.Utils.faDigits(fx.result.homeGoals) + " - " + VFL.Utils.faDigits(fx.result.awayGoals)) : "شبیه‌سازی ›") + "</span></div>";
        }).join("") + "</div>";
      });

      container.innerHTML = html;

      container.querySelectorAll("[data-league]").forEach(function (chip) {
        chip.addEventListener("click", function () {
          VFL.State.setActiveLeague(chip.getAttribute("data-league"));
          VFL.UI.Pages.competitions.render(container);
        });
      });

      container.querySelectorAll("[data-goto]").forEach(function (row) {
        row.addEventListener("click", function () { window.location.hash = "#/" + row.getAttribute("data-goto"); });
      });

      container.querySelectorAll("[data-fixture]").forEach(function (row) {
        row.addEventListener("click", function () { window.location.hash = "#/match/" + row.getAttribute("data-fixture"); });
      });

      var simWeekBtn = container.querySelector("#sim-week");
      if (simWeekBtn) {
        simWeekBtn.addEventListener("click", function () {
          VFL.State.simulateGlobalWeek();
          VFL.UI.Pages.competitions.render(container);
        });
      }
    }
  };
})(window.VFL || (window.VFL = {}));
