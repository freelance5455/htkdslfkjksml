/* ===================================================================
 * VFL.UI.Pages.home
 * خلاصه وضعیت لیگ: هفته جاری، تعداد تیم‌ها، صدرنشین، آخرین نتایج،
 * بازی‌های هفته بعد، وضعیت مسابقات، و بازی بعدی تیم کاربر (اگر دارد).
 * =================================================================== */
(function (VFL) {
  "use strict";

  VFL.UI = VFL.UI || {};
  VFL.UI.Pages = VFL.UI.Pages || {};

  VFL.UI.Pages.home = {
    render: function (container) {
      var hasSave = VFL.State.hasSavedGame();
      var state = VFL.State.get();

      if (!hasSave || !state) {
        renderWelcome(container, hasSave);
        return;
      }

      var leagueId = VFL.State.getActiveLeague();
      var league = VFL.Data.getLeagueById(leagueId);
      var teams = VFL.Data.getTeamsByLeague(leagueId);
      var standings = VFL.Utils.sortStandings(state.standings[leagueId] || []);
      var leader = standings.length && standings[0].played > 0 ? VFL.Data.getTeamById(standings[0].teamId) : null;

      var fixtures = state.fixtures[leagueId] || [];
      var recentResults = fixtures.filter(function (fx) { return fx.played; }).slice(-4).reverse();
      var nextWeekFixtures = fixtures.filter(function (fx) { return fx.week === state.season.week && !fx.played; }).slice(0, 4);

      var html = "<h1>خانه</h1>";

      html += '<div class="hero-strip">' +
        '<div class="hero-team-name">' + league.displayName + "</div>" +
        '<div class="hero-team-meta">فصل ' + VFL.Utils.faDigits(state.season.current) + " · " + VFL.Utils.weekLabel(state.season.week) + "</div>" +
        '<div class="hero-stat-strip">' +
        '<div class="hero-stat"><div class="hero-stat-value">' + VFL.Utils.faDigits(teams.length) + '</div><div class="hero-stat-label">تیم</div></div>' +
        '<div class="hero-stat"><div class="hero-stat-value" style="font-size:14px;">' + (leader ? leader.name : "—") + '</div><div class="hero-stat-label">صدرنشین</div></div>' +
        "</div></div>";

      if (state.selectedTeamId) {
        var myTeam = VFL.Data.getTeamById(state.selectedTeamId);
        var myNext = VFL.State.getRemainingFixturesForTeam(state.selectedTeamId).sort(function (a, b) { return a.week - b.week; })[0];
        html += '<div class="section-title">تیم من: ' + myTeam.name + "</div>";
        html += '<div class="row-list"><div class="row clickable" data-goto="team/' + myTeam.id + '"><div class="row-main"><span class="row-title">' +
          (myNext ? (VFL.Utils.weekLabel(VFL.State.getDisplayWeek(myTeam.league, myNext.week)) + " · " + VFL.Data.getTeamById(myNext.home === myTeam.id ? myNext.away : myNext.home).name) : "بازی برنامه‌ریزی‌شده‌ای نیست") +
          "</span></div><span class=\"row-value\">مشاهده تیم ›</span></div></div>";
      }

      html += '<div class="section-title">آخرین نتایج</div>';
      if (recentResults.length === 0) {
        html += '<div class="empty-state">هنوز بازی‌ای انجام نشده.</div>';
      } else {
        html += '<div class="row-list">' + recentResults.map(function (fx) {
          var home = VFL.Data.getTeamById(fx.home), away = VFL.Data.getTeamById(fx.away);
          return '<div class="row clickable" data-goto="match/' + fx.id + '"><div class="row-main"><span class="row-title">' + home.name + " " +
            VFL.Utils.faDigits(fx.result.homeGoals) + " - " + VFL.Utils.faDigits(fx.result.awayGoals) + " " + away.name + "</span></div></div>";
        }).join("") + "</div>";
      }

      html += '<div class="section-title">بازی‌های هفته بعد</div>';
      if (nextWeekFixtures.length === 0) {
        html += '<div class="empty-state">همه بازی‌های این هفته انجام شده.</div>';
      } else {
        html += '<div class="row-list">' + nextWeekFixtures.map(function (fx) {
          var home = VFL.Data.getTeamById(fx.home), away = VFL.Data.getTeamById(fx.away);
          return '<div class="row clickable" data-goto="match/' + fx.id + '"><div class="row-main"><span class="row-title">' + home.name + " — " + away.name + "</span></div></div>";
        }).join("") + "</div>";
      }

      html += '<div class="section-title">وضعیت مسابقات</div><div class="row-list">' +
        statusRow("جام حذفی", state.cup ? state.cup.bracket.rounds[state.cup.bracket.rounds.length - 1].label : "—") +
        statusRow("سوپر جام", state.superCup.played ? "بازی شده" : "برنامه‌ریزی‌نشده") +
        statusRow("لیگ قهرمانان اروپا", state.championsLeague ? phaseLabel(state.championsLeague.phase) : "—") +
        "</div>";

      container.innerHTML = html;
      container.querySelectorAll("[data-goto]").forEach(function (row) {
        row.addEventListener("click", function () { window.location.hash = "#/" + row.getAttribute("data-goto"); });
      });
    }
  };

  function statusRow(label, value) {
    return '<div class="row"><div class="row-main"><span class="row-title">' + label + "</span></div><span class=\"row-value\">" + value + "</span></div>";
  }

  function phaseLabel(phase) {
    var labels = { league: "مرحله لیگ", playoff: "پلی‌آف", r16: "یک‌شانزدهم نهایی", qf: "یک‌چهارم نهایی", sf: "نیمه‌نهایی", final: "فینال", done: "پایان‌یافته" };
    return labels[phase] || phase;
  }

  function renderWelcome(container, hasSave) {
    container.innerHTML =
      "<h1>خانه</h1>" +
      "<p>یک دنیای فوتبال جدید بساز، یا ادامه بده.</p>" +
      '<div class="tile-grid">' +
      '<button class="tile primary" data-action="start">' +
      '<span class="tile-label">شروع بازی</span>' +
      '<span class="tile-sub">انتخاب لیگ و تیم جدید</span></button>' +
      '<button class="tile' + (hasSave ? "" : " disabled") + '" data-action="continue">' +
      '<span class="tile-label">ادامه بازی</span>' +
      '<span class="tile-sub">' + (hasSave ? "بازگشت به آخرین وضعیت ذخیره‌شده" : "هنوز بازی ذخیره‌شده‌ای نیست") + "</span></button>" +
      "</div>";

    container.querySelector('[data-action="start"]').addEventListener("click", function () {
      window.location.hash = "#/team-select";
    });
    container.querySelector('[data-action="continue"]').addEventListener("click", function () {
      if (hasSave) window.location.hash = "#/home";
    });
  }
})(window.VFL || (window.VFL = {}));
