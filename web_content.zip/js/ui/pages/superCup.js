/* ===================================================================
 * VFL.UI.Pages.superCup
 * =================================================================== */
(function (VFL) {
  "use strict";

  VFL.UI = VFL.UI || {};
  VFL.UI.Pages = VFL.UI.Pages || {};

  VFL.UI.Pages.superCup = {
    render: function (container) {
      var state = VFL.State.get();
      var sc = state.superCup;
      var eplTeams = VFL.Data.getTeamsByLeague("epl").slice().sort(function (a, b) { return a.name.localeCompare(b.name); });

      var html = "<h1>سوپر جام</h1><p>دو تیم را برای یک مسابقه تک‌بازی انتخاب کن.</p>";

      if (sc.played) {
        var report = VFL.State.getMatchReport(sc.matchId);
        var home = VFL.Data.getTeamById(sc.homeTeamId);
        var away = VFL.Data.getTeamById(sc.awayTeamId);
        html += '<div class="hero-strip" style="text-align:center;">' +
          '<div class="hero-team-name">' + home.name + " " + VFL.Utils.faDigits(report.homeGoals) + " - " +
          VFL.Utils.faDigits(report.awayGoals) + " " + away.name + "</div>" +
          '<div class="hero-team-meta">نتیجه سوپر جام</div></div>' +
          '<button class="btn" id="view-report">مشاهده گزارش کامل</button>' +
          '<button class="btn ghost" id="reset-sc" style="margin-top:10px;">مسابقه جدید</button>';
      } else {
        html += '<div class="row-list"><div class="row" style="flex-direction:column; align-items:stretch; gap:8px;">' +
          '<label class="row-sub">تیم میزبان</label>' +
          '<select id="sc-home" style="background:var(--pitch-raised);border:1px solid var(--line);color:var(--chalk);border-radius:var(--radius-sm);padding:8px;">' +
          eplTeams.map(function (t) { return '<option value="' + t.id + '"' + (t.id === sc.homeTeamId ? " selected" : "") + '>' + t.name + "</option>"; }).join("") +
          "</select>" +
          '<label class="row-sub">تیم میهمان</label>' +
          '<select id="sc-away" style="background:var(--pitch-raised);border:1px solid var(--line);color:var(--chalk);border-radius:var(--radius-sm);padding:8px;">' +
          eplTeams.map(function (t) { return '<option value="' + t.id + '"' + (t.id === sc.awayTeamId ? " selected" : "") + '>' + t.name + "</option>"; }).join("") +
          "</select>" +
          "</div></div>" +
          '<button class="btn" id="sim-sc" style="margin-top:16px;">شبیه‌سازی سوپر جام</button>';
      }

      container.innerHTML = html;

      var simBtn = container.querySelector("#sim-sc");
      if (simBtn) {
        simBtn.addEventListener("click", function () {
          var homeId = container.querySelector("#sc-home").value;
          var awayId = container.querySelector("#sc-away").value;
          if (homeId === awayId) { alert("دو تیم باید متفاوت باشند."); return; }
          VFL.State.setSuperCupTeams(homeId, awayId);
          VFL.State.simulateSuperCup();
          VFL.UI.Pages.superCup.render(container);
        });
      }

      var viewBtn = container.querySelector("#view-report");
      if (viewBtn) {
        viewBtn.addEventListener("click", function () {
          window.location.hash = "#/match/" + sc.matchId;
        });
      }

      var resetBtn = container.querySelector("#reset-sc");
      if (resetBtn) {
        resetBtn.addEventListener("click", function () {
          VFL.State.get().superCup = { homeTeamId: null, awayTeamId: null, played: false, matchId: null };
          VFL.State.save();
          VFL.UI.Pages.superCup.render(container);
        });
      }
    }
  };
})(window.VFL || (window.VFL = {}));
