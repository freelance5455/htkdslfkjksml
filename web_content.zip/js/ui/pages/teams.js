/* ===================================================================
 * VFL.UI.Pages.teams
 * فهرست تیم‌های یک لیگ — با تپ روی هرکدام وارد پروفایل تیم می‌شوی.
 * =================================================================== */
(function (VFL) {
  "use strict";

  VFL.UI = VFL.UI || {};
  VFL.UI.Pages = VFL.UI.Pages || {};

  var selectedLeagueId = null;

  VFL.UI.Pages.teams = {
    render: function (container) {
      var state = VFL.State.get();
      var allLeagues = VFL.Data.Leagues; // شامل لیگ‌های کامل و گروه‌های Other/World (پرتغال، هلند، ترکیه، بلژیک، بین‌المللی)

      if (!selectedLeagueId) {
        var ownTeam = state && state.selectedTeamId ? VFL.Data.getTeamById(state.selectedTeamId) : null;
        selectedLeagueId = (ownTeam && (ownTeam.league || ownTeam.leagueGroup)) || allLeagues[0].id;
      }

      var html = "<h1>تیم‌ها</h1>";
      html += '<div class="row-list" style="margin-bottom:12px;"><div class="row clickable" data-goto="stats"><div class="row-main"><span class="row-title">📊 آمار بازیکنان همین لیگ</span></div><span class="row-value">›</span></div></div>';
      html += '<div class="chip-row" id="league-chips">' + allLeagues.map(function (l) {
        var active = l.id === selectedLeagueId ? " active" : "";
        return '<div class="chip' + active + '" data-league="' + l.id + '">' + l.displayName + "</div>";
      }).join("") + "</div>";

      var selectedLeague = VFL.Data.getLeagueById(selectedLeagueId);
      var teams = (selectedLeague.full ? VFL.Data.getTeamsByLeague(selectedLeagueId) : VFL.Data.getTeamsByLeagueGroup(selectedLeagueId))
        .slice().sort(function (a, b) { return b.overall - a.overall; });
      html += '<div class="row-list">' + teams.map(function (t) {
        var isOwn = state && state.selectedTeamId === t.id;
        var squadSize = VFL.State.getSquad(t.id).length;
        return '<div class="row clickable" data-team="' + t.id + '">' +
          '<div class="row-main"><span class="badge">' + VFL.Utils.faDigits(t.overall) + "</span>" +
          '<div><span class="row-title">' + (isOwn ? "⭐ " : "") + t.name + "</span><br>" +
          '<span class="row-sub">' + (squadSize ? VFL.Utils.faDigits(squadSize) + " بازیکن" : "بدون دیتابیس بازیکن") + "</span></div></div>" +
          '<span class="row-value">›</span></div>';
      }).join("") + "</div>";

      container.innerHTML = html;

      container.querySelectorAll("[data-league]").forEach(function (chip) {
        chip.addEventListener("click", function () {
          selectedLeagueId = chip.getAttribute("data-league");
          VFL.UI.Pages.teams.render(container);
        });
      });
      container.querySelectorAll("[data-team]").forEach(function (row) {
        row.addEventListener("click", function () {
          window.location.hash = "#/team/" + row.getAttribute("data-team");
        });
      });
      container.querySelectorAll("[data-goto]").forEach(function (row) {
        row.addEventListener("click", function () { window.location.hash = "#/" + row.getAttribute("data-goto"); });
      });
    }
  };
})(window.VFL || (window.VFL = {}));
