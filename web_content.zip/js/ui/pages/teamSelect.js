/* ===================================================================
 * VFL.UI.Pages.teamSelect
 * دو حالت شروع: کنترل یک تیم، یا شبیه‌سازی کامل بدون کنترل تیم.
 * =================================================================== */
(function (VFL) {
  "use strict";

  VFL.UI = VFL.UI || {};
  VFL.UI.Pages = VFL.UI.Pages || {};

  var selectedLeagueId = null;
  var mode = null; // 'control' | 'simulate'

  VFL.UI.Pages.teamSelect = {
    render: function (container) {
      if (!mode) {
        renderModeChoice(container);
        return;
      }
      if (mode === "simulate") {
        renderSimulateMode(container);
        return;
      }
      renderControlMode(container);
    }
  };

  function renderModeChoice(container) {
    container.innerHTML =
      "<h1>شروع بازی</h1>" +
      "<p>می‌خواهی یک تیم را کنترل کنی، یا کل دنیای فوتبال را بدون کنترل هیچ تیمی شبیه‌سازی کنی؟</p>" +
      '<div class="tile-grid">' +
      '<button class="tile primary" data-mode="control">' +
      '<span class="tile-label">کنترل تیم</span>' +
      '<span class="tile-sub">یک تیم انتخاب کن و آن را مدیریت کن</span></button>' +
      '<button class="tile" data-mode="simulate">' +
      '<span class="tile-label">شبیه‌سازی کامل</span>' +
      '<span class="tile-sub">بدون کنترل تیم — فقط ناظر باش</span></button>' +
      "</div>";

    container.querySelector('[data-mode="control"]').addEventListener("click", function () {
      mode = "control";
      VFL.UI.Pages.teamSelect.render(container);
    });
    container.querySelector('[data-mode="simulate"]').addEventListener("click", function () {
      mode = "simulate";
      VFL.UI.Pages.teamSelect.render(container);
    });
  }

  var simulateLeagueChoice = "epl";

  function renderSimulateMode(container) {
    var fullLeagues = VFL.Data.Leagues.filter(function (l) { return l.full; });
    container.innerHTML =
      "<h1>شبیه‌سازی کامل</h1>" +
      "<p>در این حالت هیچ تیمی را کنترل نمی‌کنی. همه لیگ‌ها با هم پیش می‌روند؛ فقط انتخاب کن اول کدام لیگ را دنبال کنی — هر وقت خواستی از صفحه مسابقات لیگ دیگری را انتخاب می‌کنی.</p>" +
      '<div class="chip-row" id="league-chips">' + fullLeagues.map(function (l) {
        var active = l.id === simulateLeagueChoice ? " active" : "";
        return '<div class="chip' + active + '" data-league="' + l.id + '">' + l.displayName + "</div>";
      }).join("") + "</div>" +
      '<button class="btn" id="start-simulate" style="margin-top:12px;">شروع دنیای جدید</button>' +
      '<button class="btn ghost" id="back-mode" style="margin-top:10px;">بازگشت</button>';

    container.querySelectorAll("[data-league]").forEach(function (chip) {
      chip.addEventListener("click", function () {
        simulateLeagueChoice = chip.getAttribute("data-league");
        renderSimulateMode(container);
      });
    });

    container.querySelector("#start-simulate").addEventListener("click", function () {
      VFL.State.newGame();
      VFL.State.setActiveLeague(simulateLeagueChoice);
      window.location.hash = "#/competitions";
    });
    container.querySelector("#back-mode").addEventListener("click", function () {
      mode = null;
      VFL.UI.Pages.teamSelect.render(container);
    });
  }

  function renderControlMode(container) {
    var allLeagues = VFL.Data.Leagues; // شامل لیگ‌های کامل و گروه‌های Other/World
    if (!selectedLeagueId) selectedLeagueId = allLeagues[0].id;

    container.innerHTML =
      "<h1>انتخاب تیم</h1>" +
      "<p>ابتدا یک لیگ یا دسته را انتخاب کن، سپس تیم موردنظرت را انتخاب کن.</p>" +
      '<div class="chip-row" id="league-chips"></div>' +
      '<div class="row-list" id="team-list"></div>' +
      '<button class="btn ghost small" id="back-mode" style="margin-top:14px;">بازگشت</button>';

    var chipsEl = container.querySelector("#league-chips");
    chipsEl.innerHTML = allLeagues.map(function (l) {
      var active = l.id === selectedLeagueId ? " active" : "";
      return '<div class="chip' + active + '" data-league="' + l.id + '">' + l.displayName + "</div>";
    }).join("");

    Array.prototype.forEach.call(chipsEl.querySelectorAll(".chip"), function (chip) {
      chip.addEventListener("click", function () {
        selectedLeagueId = chip.getAttribute("data-league");
        VFL.UI.Pages.teamSelect.render(container);
      });
    });

    var selectedLeague = VFL.Data.getLeagueById(selectedLeagueId);
    var listEl = container.querySelector("#team-list");
    var teams = (selectedLeague.full ? VFL.Data.getTeamsByLeague(selectedLeagueId) : VFL.Data.getTeamsByLeagueGroup(selectedLeagueId))
      .slice().sort(function (a, b) { return b.overall - a.overall; });

    listEl.innerHTML = teams.map(function (team) {
      return (
        '<div class="row clickable" data-team="' + team.id + '">' +
        '<div class="row-main"><span class="badge">' + VFL.Utils.faDigits(team.overall) + "</span>" +
        '<span class="row-title">' + team.name + "</span></div>" +
        '<span class="row-value">انتخاب ›</span></div>'
      );
    }).join("");

    Array.prototype.forEach.call(listEl.querySelectorAll(".row"), function (row) {
      row.addEventListener("click", function () {
        var teamId = row.getAttribute("data-team");
        if (!VFL.State.hasSavedGame()) VFL.State.newGame();
        VFL.State.selectTeam(teamId);
        window.location.hash = "#/home";
      });
    });

    container.querySelector("#back-mode").addEventListener("click", function () {
      mode = null;
      VFL.UI.Pages.teamSelect.render(container);
    });
  }
})(window.VFL || (window.VFL = {}));
