/* GameView – herní obrazovka (canvas + panely). Hraje jednu session:
   session = { mode: 'story' | 'tutorial' | 'free', nodeId?, title, level, snapshot? }
   Postup se ukládá po každé dokončené vlně a při odchodu (mezi vlnami).
   Události: exit ('map' | 'menu'), skip (přeskočit tutoriál)
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';

  BD.ui.components.GameView = {
    props: { session: Object },
    emits: ['exit', 'skip'],
    template: `
<div class="gv">
  <div class="bar">
    <button class="btn" @click="menuOpen = true"><ic n="menu"></ic><span class="lbl"> Menu</span></button>
    <span class="pill gtitle">{{ session.title }}</span>
    <span class="stat heart"><ic n="heart"></ic> {{ v.god ? '∞' : v.lives }}</span>
    <span class="stat coin"><ic n="coin"></ic> {{ v.god ? '∞' : v.gold }}</span>
    <span class="stat"><small>Vlna</small> {{ v.wave }}<template v-if="v.maxWaves"> / {{ v.maxWaves }}</template></span>
    <button class="btn primary" @click="callBelt(1)" :disabled="!canCall"><ic n="play"></ic> {{ v.running ? 'Další vlna' : 'Start' }}</button>
    <button class="btn" :class="{on: v.speed > 1}" @click="cycleSpeed" title="Rychlost"><ic n="fast"></ic> {{ v.speed }}×</button>
    <button class="btn rel" @click="openBestiary" title="Bestiář (B)"><ic n="bookopen"></ic><i class="badge" v-if="bsUnread"></i></button>
    <button class="btn" :class="{on: v.paused}" @click="v.paused = !v.paused" title="Pauza"><ic n="pause"></ic></button>
    <button class="btn" v-if="session.editorId" @click="leave('editor')" title="Zpět do editoru"><ic n="pencil"></ic><span class="lbl"> {{ session.editorId === '__studio' ? 'Studio' : 'Editor' }}</span></button>
  </div>

  <div class="tut" v-if="tutorial && tutStep">
    <div class="tut-n">Tutoriál {{ tStep + 1 }}/{{ steps.length }}</div>
    <div class="tut-t" v-if="S.hints" v-html="tutStep.text"></div>
    <div class="tut-t" v-else>Nápovědy jsou vypnuté v nastavení.</div>
    <div class="tut-b">
      <button class="btn sm primary" v-if="tutStep.manual" @click="tStep++">Rozumím</button>
      <button class="btn sm" @click="$emit('skip')">Přeskočit tutoriál</button>
    </div>
  </div>

  <div class="main">
    <div class="col l">
      <div class="first">
        <div class="h">Věže</div>
        <div class="shop">
          <button class="tw" v-for="(t, i) in towerList" :key="t.key" :class="{on: shop === t.key, off: v.gold < t.cost}" @click="pickShop(t.key)">
            <div class="sw" :style="{background: t.color}">{{ i + 1 }}</div>
            <div style="flex:1">
              <div class="nm">{{ t.name }} <span>{{ t.cost }}</span></div>
              <div class="ds">{{ t.desc }}</div>
              <div class="ts"><span>Poškození <b>{{ t.st[0] }}</b></span><span>Rychlost <b>{{ t.st[1] }}</b></span><span>Dosah <b>{{ t.st[2] }}</b></span></div>
            </div>
          </button>
        </div>
      </div>
      <div class="lab" v-if="lab" data-role="lab">
        <div class="h">Zkušebna</div>
        <label class="lf"><span>Věž (kterákoli ze stromu)</span>
          <select class="btn" v-model="L.tower" @change="labTower($event.target.value)" data-role="lab-tower"><option value="">— vyber a klepni do pole —</option><option v-for="o in labTowers" :key="o.id" :value="o.id">{{ o.label }}</option></select></label>
        <label class="lf"><span>Nepřítel</span>
          <select class="btn" v-model="L.enemy" @change="labEnemy($event.target.value)" data-role="lab-enemy"><option v-for="o in labEnemies" :key="o.id" :value="o.id">{{ o.name }}</option></select></label>
        <div class="lrow"><button class="btn sm" @click="labSpawn(1)" data-act="lab-spawn1">Vypustit 1</button><button class="btn sm" @click="labSpawn(10)" data-act="lab-spawn10">Vypustit 10</button></div>
        <label class="chk"><input type="checkbox" v-model="L.god" data-role="lab-god"> nekonečné zlato a životy</label>
        <div class="lrow"><button class="btn sm" @click="labClear" data-act="lab-clear">Vyčistit pole</button></div>
        <div class="hint">Věž se staví rovnou, bez cesty přes vylepšení. Vlny se opakují s vybraným nepřítelem.</div>
      </div>
      <div class="selbox">
        <template v-if="sel">
          <div class="h">Vybraná věž</div>
          <div class="card">
            <div class="t"><span class="sw" :style="{background: sel.color}"></span>{{ sel.name }}</div>
            <div class="kv" v-if="sel.tier"><span>Velikost</span><b>{{ sel.size }}×{{ sel.size }}</b></div>
            <div class="kv" v-if="sel.role === 'boost'"><span>Zesílení dotyk. věží</span><b>×{{ sel.boostMul }}</b></div>
            <div class="hint" v-else-if="sel.role === 'none'" style="margin:0">{{ sel.desc }}</div>
            <template v-else>
              <div class="kv"><span>Poškození</span><b>{{ sel.dmg }}</b></div>
              <div class="kv"><span>Dosah</span><b>{{ sel.range }}</b></div>
              <div class="kv"><span>{{ sel.role === 'burst' ? 'Výbuchy' : 'Střelba' }}</span><b>{{ sel.rate }} / s</b></div>
              <div class="kv" v-if="sel.boosted"><span>Zesíleno</span><b>×{{ sel.boosted }}</b></div>
            </template>
            <div class="kv" v-if="sel.splash"><span>Plošný zásah</span><b>{{ sel.splash }}</b></div>
            <div class="kv" v-if="sel.slow"><span>Zpomalení</span><b>{{ sel.slow }} %</b></div>
          </div>
          <template v-if="sel.choices">
            <div class="hint" style="margin:0">Vyber {{ sel.chooseWhat }} – volba je nevratná:</div>
            <button class="btn choice" v-for="b in sel.choices" :key="b.id" :title="b.desc" @click="doUpgrade(b.id)" :disabled="!b.can || !sel.active"><span class="cn"><ic n="up"></ic> {{ b.name }} <b>{{ b.cost }}</b></span><span class="cd">{{ b.desc }}</span></button>
          </template>
          <div class="hint" v-else style="margin:0">Další vylepšení tahle věž nemá.</div>
          <button class="btn primary" v-if="sel.canMerge" @click="doMerge"><ic n="merge"></ic> Sloučit<span class="lbl"> 4 → {{ sel.mergeName }}</span></button>
          <button class="btn danger" @click="doSell"><ic n="trash"></ic> Prodat · +{{ sel.sell }}</button>
        </template>
        <template v-else>
          <template v-if="show.pathLen">
            <div class="h">Cesta bublin</div>
            <div class="card">
              <div class="kv" v-for="(p, i) in v.path" :key="i"><span>Vstup {{ i + 1 }}</span><b>{{ p }} polí</b></div>
              <div class="hint">Delší cesta = víc času pod palbou.</div>
            </div>
          </template>
          <div class="hint">Klepni na věž a uvidíš její vylepšení. Vlny jedou po pásu vedle hrací plochy: po startu přijíždějí samy. Klepnutím na vlnu ji přivoláš dřív – i se všemi před ní.</div>
          <div class="hint keys"><kbd>T</kbd> základna · <kbd>S</kbd> prodat · <kbd>M</kbd> sloučit · <kbd>P</kbd> pauza · <kbd>mezerník</kbd> další vlna<template v-if="dockOn"> · <kbd>C</kbd> karty</template></div>
          <div class="hint" v-if="v.maxWaves && v.wave >= v.maxWaves">Tohle byla poslední vlna levelu.</div>
        </template>
      </div>
    </div>

    <div class="play" ref="playEl">
    <div class="stage" ref="stageEl" :class="shakeCls" @wheel="onWheel">
      <canvas ref="canvasEl" style="touch-action: manipulation"
        @pointerdown="onDown" @pointermove="onMove" @pointerup="onUp" @pointerleave="onLeave" @pointercancel="onLeave" @contextmenu.prevent></canvas>
      <div class="toast" :class="{err: toast.err}" v-if="toast">{{ toast.text }}</div>
      <div class="zoomui" v-if="big">
        <template v-if="zoomed">
          <canvas class="mini" ref="miniEl" :style="miniStyle" @pointerdown="miniDown" @pointermove="miniMove" @pointerup="miniUp" @pointercancel="miniUp"></canvas>
          <button class="btn sm" data-act="zoom-out" @click="setZoom(false)"><ic n="zoomout"></ic> Celá mapa</button>
        </template>
        <button class="btn sm" v-else data-act="zoom-in" @click="setZoom(true)"><ic n="zoomin"></ic> Přiblížit</button>
      </div>

      <div class="over" v-if="result === 'won'">
        <h2>Level splněn</h2>
        <div>{{ session.title }} · {{ v.wave }} vln přežito</div>
        <button class="btn primary big" v-if="session.editorId" @click="leave('editor')"><ic n="pencil"></ic> Zpět do editoru</button>
        <button class="btn primary big" v-if="nextNode" data-act="next-level" @click="leave('next', nextNode.id)"><ic n="play"></ic> Další level · {{ nextNode.title }}</button>
        <button class="btn big" :class="{primary: !session.editorId && !nextNode}" @click="leave(backTo)"><ic n="check"></ic> {{ backTo === 'map' ? 'Zpět na mapu' : backLabel }}</button>
        <button class="btn" @click="restart"><ic n="refresh"></ic> Zahrát znovu</button>
      </div>
      <div class="over" v-if="result === 'lost'">
        <h2>Konec hry</h2>
        <div>Došel jsi do vlny <b>{{ v.wave }}</b><template v-if="session.mode === 'free'"> · nejlepší: <b>{{ best }}</b></template></div>
        <button class="btn primary big" @click="restart"><ic n="refresh"></ic> Zkusit znovu</button>
        <button class="btn" v-if="session.editorId" @click="leave('editor')"><ic n="pencil"></ic> Zpět do editoru</button>
        <button class="btn" @click="leave(backTo)"><ic n="back"></ic> {{ backLabel }}</button>
      </div>
    </div>

    <div class="belt" ref="beltEl" :class="{idle: !v.running}">
      <div class="belt-h">Vlny</div>
      <div class="belt-track">
        <div class="belt-slot"></div>
        <transition-group name="bl">
          <button v-for="b in v.belt" :key="b.wave" class="blk" :class="{boss: b.boss, go: b.launching}" :style="blockStyle(b)" :title="b.title" @click="callBelt(b.k)">
            <span class="bw">{{ b.wave }}</span>
            <span class="bi">
              <span class="bt" v-if="b.boss">BOSS</span>
              <span class="bk"><span class="ln" v-for="t in b.kinds" :key="t.type"><i :style="{background: t.color}"></i>{{ t.count }}× {{ t.name }}</span><span class="ln more" v-if="b.more">+{{ b.more }}</span></span>
              <span class="bf"><span class="bm">{{ b.hpTxt }} HP</span><span class="bc"><i v-for="t in b.types" :key="t.type" :style="{flex: t.hp, background: t.color}"></i></span></span>
            </span>
          </button>
        </transition-group>
      </div>
      <div class="belt-f">{{ v.running ? 'klepnutím vlnu přivoláš' : 'klepnutím spustíš' }}</div>
    </div>

    <!-- spodní lišta s kartami (odměny): ukáže se až když hráč první kartu získá; široká mezi sloupci, zasouvá se dolů, karty se posouvají vodorovně -->
    <div class="dock" v-if="dockOn" :class="{open: dock.open}">
      <button class="dock-tab" data-act="dock-toggle" @click="dock.open = !dock.open" :title="(dock.open ? 'Schovat karty' : 'Zobrazit karty') + ' (C)'"><ic n="up"></ic><i class="badge" v-if="cardsView.length && !dock.open"></i></button>
      <div class="dock-body" data-slot="dock" @wheel="dockWheel">
        <button v-for="(c, i) in cardsView" :key="i + c.id" class="cardi" :class="{fresh: i === freshIdx}" :style="{'--c': c.color}" :disabled="!canUseCard" @click="useCard(i)" :title="c.short" :data-card="c.id">
          <bd-sil kind="cards" :id="c.id" :st="2" :size="62"></bd-sil>
          <span class="cn">{{ c.name }}</span>
        </button>
        <div class="dock-empty" v-if="!cardsView.length">Zatím žádné karty.</div>
      </div>
    </div>
    </div>

  </div>

  <div class="over pause" v-if="menuOpen">
    <div class="pbox">
      <h2>Pauza</h2>
      <button class="btn primary big" @click="menuOpen = false"><ic n="play"></ic> Pokračovat</button>
      <button class="btn big" @click="settingsOpen = true"><ic n="gear"></ic> Nastavení</button>
      <button class="btn big" @click="restart"><ic n="refresh"></ic> Restart levelu</button>
      <button class="btn big" v-if="session.editorId" @click="leave('editor')"><ic n="pencil"></ic> Zpět do editoru</button>
      <button class="btn big" v-if="backTo === 'map'" @click="leave('map')"><ic n="flag"></ic> Mapa levelů</button>
      <button class="btn big" @click="leave('menu')"><ic n="menu"></ic> Hlavní menu</button>
      <div class="hint" v-if="session.mode !== 'tutorial'">Postup se ukládá po každé dokončené vlně a při odchodu mezi vlnami.</div>
    </div>
  </div>

  <div class="over pause" v-if="menuOpen && settingsOpen">
    <div class="pbox wide">
      <div class="sbody"><bd-settings></bd-settings></div>
      <button class="btn primary big" data-act="close-settings" @click="settingsOpen = false"><ic n="check"></ic> Hotovo</button>
    </div>
  </div>
</div>`,

    setup: function (props, ctx) {
      var R = Vue, ref = R.ref, reactive = R.reactive, computed = R.computed, onMounted = R.onMounted,
          onBeforeUnmount = R.onBeforeUnmount, markRaw = R.markRaw, nextTick = R.nextTick;
      var sys = BD.systems, TT = sys.towers.TYPES, ET = sys.enemies.TYPES;
      var store = BD.store, P = store.profile, S = P.settings;
      var session = props.session;
      var tutorial = session.mode === 'tutorial';
      var steps = BD.data.tutorial;

      var game = markRaw(new sys.Game(session.level));
      BD.systems.waves.ctx.levelNo = session.mode === 'story' ? (BD.store.profile.story.completed.length + 1) : 0;      // pro pravidla vln „od kolikátého levelu“
      BD.systems.waves.testEnemy = session.studioTest || null;                        // zkouška nepřítele ze Studia: každá vlna = tento nepřítel
      game.rewards = session.rewards !== false && !tutorial;                       // smí padat karty? (tutoriál a první levely story ne)
      if (session.snapshot) game.restore(session.snapshot);
      else if (session.mode === 'story' && game.rewards) game.cards = (P.story.cards || []).filter(function (c) { return !!BD.data.cards.list[c]; });     // karty z předchozích levelů
      var cardsStart = game.cards.slice();                                           // s tímhle se level (znovu) začíná
      var lastSnap = session.snapshot || game.serialize();
      var startPath = game.pathLen(0);

      function shopStats(d) {
        var b = d.base || {}, f = BD.util.fmt;
        if (d.role === 'none' || !b.dmg) return ['–', '–', '–'];
        return [f(b.dmg), f(1 / (b.cd || 1)) + '/s', f((b.range || 0) * BD.SUB)];
      }
      var towerList = Object.keys(TT).map(function (k) { return Object.assign({ key: k, st: shopStats(TT[k]) }, TT[k]); }).filter(function (t) { return !t.parent; }).sort(function (a, b) { return a.order - b.order; });
      var stageEl = ref(null), canvasEl = ref(null), playEl = ref(null), beltEl = ref(null), miniEl = ref(null);
      var zoomed = ref(true), big = ref(false), miniDrag = false;
      var dock = reactive({ enabled: false, open: false });          // enabled = vynucené zapnutí (ladění); jinak se lišta ukáže, když hráč získá první kartu
      var freshIdx = ref(-1), freshT = 0;
      var v = reactive({ gold: 0, lives: 0, wave: 0, running: false, god: false, cards: [], maxWaves: 0, gameOver: false, speed: S.gameSpeed, paused: false, caps: false, path: [], belt: [] });
      var shop = ref(null), selId = ref(0), sel = ref(null);
      /* zkušebna (zkouška ze Studia): libovolná věž ze stromu rovnou, libovolný nepřítel, nekonečné zlato; nic se neukládá do postupu */
      var lab = session.editorId === '__studio';
      var L = reactive({ tower: session.studioTower || '', enemy: session.studioTest || Object.keys(BD.systems.enemies.TYPES)[0] || '', god: true });
      var labTowers = [], labEnemies = Object.keys(BD.systems.enemies.TYPES).map(function (k) { return { id: k, name: BD.systems.enemies.TYPES[k].name || k }; }), labTimers = [];
      if (lab) (function walkT(id, depth, path) { sys.towers.children(id).forEach(function (d) { var p = path ? path + ' › ' + d.name : d.name; labTowers.push({ id: d.id, label: new Array(depth + 1).join('   ') + (depth ? '↳ ' : '') + d.name + (depth ? '   (' + path + ')' : '') }); walkT(d.id, depth + 1, p); }); })('base', 0, '');
      if (lab) labTowers.unshift({ id: 'base', label: TT.base ? TT.base.name : 'base' });
      /* zobrazení se bere z globálního nastavení (mění se v popupu Nastavení) */
      var show = { get range() { return S.showRange; }, get path() { return S.showPath; }, get pathLen() { return S.showPathLen; }, get grid() { return S.showGrid; } };
      var toast = ref(null), toastT = 0;
      var nextNode = ref(null);
      var result = ref(null), menuOpen = ref(false), settingsOpen = ref(false), shakeCls = ref('');
      var tStep = ref(0);
      var best = computed(function () { return P.free.best; });
      var backTo = session.mode === 'free' ? 'menu' : 'map';
      var backLabel = backTo === 'map' ? 'Mapa levelů' : 'Hlavní menu';
      var tutStep = computed(function () { return tutorial ? steps[tStep.value] || null : null; });
      var canCall = computed(function () { return !v.gameOver && !result.value && !(v.maxWaves && v.wave >= v.maxWaves); });
      var CD = BD.data.cards.list;
      var cardsView = computed(function () { return v.cards.map(function (id) { return CD[id]; }).filter(Boolean); });
      var dockOn = computed(function () { return dock.enabled || (game.rewards && (v.cards.length > 0 || BD.bestiary.anyCard())); });
      var canUseCard = computed(function () { return !v.gameOver && !result.value && !menuOpen.value && !BD.bestiary.ui.open; });
      function persistCards() { if (session.mode === 'story' && game.rewards) P.story.cards = game.cards.slice(); }
      function useCard(i) { if (!canUseCard.value) return; if (game.useCard(i)) { sync(); } }
      function dockWheel(ev) { var el = ev.currentTarget; if (el.scrollWidth <= el.clientWidth) return; ev.preventDefault(); el.scrollLeft += (ev.deltaY || ev.deltaX); }
      var runTypes = {}, seenTw = {};                       // co se v tomhle levelu objevilo (pro bestiář)
      var bsUnread = computed(function () { return BD.bestiary.unreadCount() > 0; });
      function openBestiary() { BD.bestiary.open(); }
      if (!lab) BD.bestiary.see('towers', 'base');
      var BELT_SHOWN = 10;                                 // kolik bloků se vejde na pás: počítač 10 (malé karty), mobil 5 (šestý/jedenáctý se zasouvá zespodu)

      var renderer = null, hover = null, downPt = null, raf = 0, last = 0, acc = 0, syncT = 0, ro = null, ptrType = 'mouse';

      function say(text, err) {
        toast.value = { text: text, err: !!err };
        clearTimeout(toastT); toastT = setTimeout(function () { toast.value = null; }, 1600);
      }

      /* ---------- ukládání postupu ---------- */
      function persist() {
        if (tutorial || result.value || session.editorId) return;
        if (session.mode === 'story') P.story.save = { nodeId: session.nodeId, snapshot: lastSnap, savedAt: Date.now() };
        else if (session.mode === 'free') P.free.save = { level: BD.util.clone(session.level), title: session.title, snapshot: lastSnap, savedAt: Date.now() };
      }
      function snapshotNow() { if (!result.value && !game.gameOver) lastSnap = game.serialize(); }          // ukládá se hotové vlny popořadě + věže, zlato a životy

      game.on('waveCleared', function (n) {
        lastSnap = game.serialize();
        if (session.mode === 'free' && !session.editorId && n > P.free.best) P.free.best = n;
        persist();
      });
      game.on('card', function (id) {
        BD.bestiary.see('cards', id); persistCards(); dock.open = true;
        sync(); freshIdx.value = game.cards.length - 1; clearTimeout(freshT); freshT = setTimeout(function () { freshIdx.value = -1; }, 2200);
        say('Získal jsi kartu: ' + CD[id].name);
      });
      game.on('cardUsed', function (id) { BD.bestiary.know('cards', id); persistCards(); });
      game.on('spawn', function (type) { if (!lab && !runTypes[type]) { runTypes[type] = 1; BD.bestiary.see('enemies', type); } });
      game.on('won', function () {
        result.value = 'won';
        Object.keys(runTypes).forEach(function (k) { BD.bestiary.know('enemies', k); });          // dokončený level: nepřátelé v něm se „poznají“
        if (session.nodeId) { store.completeNode(session.nodeId); nextNode.value = BD.data.story.pickNext(session.nodeId, P.story.completed); }
        if (session.mode === 'free' && !session.editorId) P.free.save = null;
      });
      game.on('lost', function (n) {
        result.value = 'lost';
        if (session.mode === 'story' && game.rewards) P.story.cards = cardsStart.slice();              // prohraný level: karty se vrací, jak byly na začátku
        if (session.mode === 'story') P.story.save = null;
        if (session.mode === 'free' && !session.editorId) { P.free.save = null; if (n - 1 > P.free.best) P.free.best = n - 1; }
      });
      game.on('lifeLost', function () {
        if (!S.shake) return;
        shakeCls.value = '';
        requestAnimationFrame(function () {
          shakeCls.value = 'sh' + S.shake;
          setTimeout(function () { shakeCls.value = ''; }, 500);
        });
      });

      /* ---------- stav pro panely ---------- */
      function sync() {
        v.gold = game.gold; v.lives = game.lives; v.wave = game.wave; v.running = game.running; v.god = BD.dev.god || (lab && L.god);
        if (v.cards.join('|') !== game.cards.join('|')) v.cards = game.cards.slice();
        v.maxWaves = game.maxWaves; v.gameOver = game.gameOver;
        if (!lab) game.towers.forEach(function (t) { if (!seenTw[t.type + t.tier]) { seenTw[t.type + t.tier] = 1; BD.bestiary.know('towers', t.type); if (t.tier > 0) BD.bestiary.merged(t.type, t.tier); } });
        if (show.pathLen) v.path = game.level.spawns.map(function (s, i) { return Math.round(game.pathLen(i) / game.sub * 10) / 10; });
        var nowT = performance.now(), dtv = Math.min(0.25, (nowT - visT) / 1000); visT = nowT;
        var seen = {};
        v.belt = game.belt(BELT_SHOWN + 1).map(function (b) {
          b.pos = smoothPos(b, dtv); seen[b.wave] = 1;
          b.hpTxt = b.hp >= 1000 ? (b.hp / 1000).toFixed(1).replace('.', ',') + 'k' : String(b.hp);
          var mk = BELT_SHOWN > 5 ? 2 : 3; b.kinds = b.types.slice(0, mk); b.more = Math.max(0, b.types.length - mk);
          b.title = b.types.map(function (t) { return t.count + '× ' + t.name; }).join(', ');
          return b;
        });
        for (var kk in vis) if (!seen[kk]) delete vis[kk];
        if (tutorial) {
          var guard = 0;
          while (guard++ < 8 && steps[tStep.value] && !steps[tStep.value].manual &&
                 steps[tStep.value].done({ game: game, shop: shop.value, sel: selId.value, startPath: startPath })) tStep.value++;
        }
      }
      function refreshSel() {
        var t = selId.value ? game.byId(selId.value) : null;
        if (!t) { if (selId.value) selId.value = 0; sel.value = null; return; }
        var kids = sys.towers.children(t.type).filter(function (d) { return !game.allowed || game.allowed.indexOf(sys.towers.rootKind(d.id)) >= 0; });
        if (!lab) kids.forEach(function (d) { BD.bestiary.see('towers', d.id); });
        var s = t.s, m = game.findMerge(t), up = kids.length ? Math.min.apply(null, kids.map(function (d) { return d.cost; })) : null, f = BD.util.fmt, D = TT[t.type];
        var can = up !== null && game.gold >= up && !game.gameOver && !result.value;
        sel.value = {
          name: sys.towers.name(t), color: D.color, level: t.level, tier: t.tier, size: t.size, role: D.role,
          boostMul: s.boost ? f(s.boost) : '', boosted: t.boost > 1 ? f(t.boost) : '', desc: D.desc,
          choices: kids.length ? kids.map(function (d) { return { id: d.id, name: d.name, desc: d.desc, cost: d.cost, can: game.gold >= d.cost }; }) : null,
          chooseWhat: 'vylepšení',
          dmg: f(s.dmg * (t.boost || 1)), range: f(s.range), rate: f(1 / s.cd), splash: s.splash ? f(s.splash) : '', slow: s.slow ? Math.round(s.slow * 100) : 0,
          upCost: up, active: !game.gameOver && !result.value, canUp: up !== null && game.gold >= up && !game.gameOver && !result.value, maxed: up === null,
          canMerge: !!m, mergeName: t.tier < sys.towers.MAX_TIER ? sys.towers.tierName(t.type, t.tier + 1) : '', sell: game.sellValue(t),
        };
      }

      /* ---------- akce ---------- */
      function labTower(id) { if (typeof id === 'string') L.tower = id; if (!L.tower) { shop.value = null; return; } shop.value = L.tower; selId.value = 0; sel.value = null; }
      function labEnemy(id) { if (typeof id === 'string') L.enemy = id; BD.systems.waves.testEnemy = L.enemy || null; }
      function labSpawn(n) {
        if (!L.enemy || !BD.systems.enemies.TYPES[L.enemy]) return;
        for (var i = 0; i < n; i++) labTimers.push(setTimeout(function () { if (!game.gameOver) { sys.enemies.spawn(game, L.enemy, Math.max(1, game.wave)); } }, i * 350));
      }
      function labClear() { labTimers.forEach(clearTimeout); labTimers.length = 0; game.towers.slice().forEach(function (t) { game.removeTower(t); }); game.enemies = []; game.recompute(); sys.towers.updateBoosts(game); selId.value = 0; sel.value = null; sync(); }
      if (lab && L.tower) nextTick(labTower);
      function pickShop(k) { shop.value = shop.value === k ? null : k; selId.value = 0; sel.value = null; }
      /* přivolá k vln z pásu (1 = nejbližší); první klepnutí zároveň spustí pás */
      function callBelt(k) { if (k === 0 || !canCall.value) return; if (game.callWaves(k)) { snapshotNow(); sync(); } else if (!game.running) { game.run(); sync(); } }
      /* plynulý pohyb bloku: pomalý plynulý posun se bere přesně, velké skoky (přivolání vln) se dojíždějí rychlostí ~70 %/s */
      var vis = {}, visT = performance.now();
      function smoothPos(b, dt) {
        var target = Math.max(0, b.slot) * 100 / BELT_SHOWN, cur = vis[b.wave];
        if (cur === undefined) cur = target;
        else {
          var d = target - cur, step = 70 * Math.max(dt, 0.016);
          if (Math.abs(d) <= 1.5) cur = target; else cur += Math.sign(d) * Math.min(Math.abs(d), step);
        }
        vis[b.wave] = cur; return Math.round(cur * 100) / 100;
      }
      function blockStyle(b) {
        return { '--p': b.pos + '%', zIndex: 50 - Math.min(49, b.wave % 1000), '--c': b.main, '--cb': BD.render.draw.hexA(b.main, 0.22) };
      }
      function cycleSpeed() { v.speed = v.speed % 3 + 1; }
      function doUpgrade(to) { var t = game.byId(selId.value); if (t && typeof to === 'string' && game.upgrade(t, to)) { sync(); refreshSel(); } }
      function doMerge() {
        var t = game.byId(selId.value); if (!t) return;
        var n = game.merge(t);
        if (n) { selId.value = n.id; say(sys.towers.name(n) + '!'); sync(); refreshSel(); }
      }
      function doSell() { var t = game.byId(selId.value); if (!t) return; game.sell(t); selId.value = 0; sync(); refreshSel(); }
      function select(t) { selId.value = t ? t.id : 0; if (t) shop.value = null; refreshSel(); }

      function restart() {
        game.setLevel(session.level);
        game.cards = cardsStart.slice(); persistCards();
        lastSnap = game.serialize(); startPath = game.pathLen(0);
        result.value = null; menuOpen.value = false; shop.value = null; selId.value = 0; sel.value = null;
        v.paused = false; acc = 0; tStep.value = 0; vis = {}; nextNode.value = null;
        if (session.mode === 'story') P.story.save = null;
        sync(); nextTick(fit);
      }
      function leave(dest, extra) {
        if (dest === 'editor') { ctx.emit('exit', dest); return; }          // zkušební hra z editoru se neukládá
        snapshotNow(); persist();
        ctx.emit('exit', dest, extra);
      }

      /* ---------- plátno ---------- */
      /* na počítači je pás vln pravý sloupec (stejně široký jako levý) a pole je vycentrované v zbytku; na mobilu je pás pod polem.
         Když je mapa moc velká (buňky by byly malé), zapne se přiblížení s posunem, minimapkou a tlačítkem „Celá mapa“. */
      var BELT_W = 288;                                    // pás vln je pravý sloupec stejně široký jako levý
      function fit() {
        if (!renderer) return;
        var pl = playEl.value, st = stageEl.value, bl = beltEl.value, wide = !window.matchMedia('(max-width:900px)').matches;
        if (!pl || !st) return;
        var shown = wide ? 10 : 5; if (shown !== BELT_SHOWN) { BELT_SHOWN = shown; vis = {}; }
        renderer.setZoom(zoomed.value);
        if (!wide) { st.style.width = ''; if (bl) { bl.style.height = ''; bl.style.width = ''; } renderer.fit(st, game); big.value = renderer.big; return; }
        st.style.width = '';
        if (bl) { bl.style.height = ''; bl.style.width = BELT_W + 'px'; }
        if (!renderer.fit(st, game, pl.clientWidth - BELT_W, pl.clientHeight)) return;
        big.value = renderer.big;
      }
      function setZoom(on) { zoomed.value = !!on; fit(); }
      var miniStyle = computed(function () {
        var ew = game.w + 2, eh = game.h + 2, k = Math.min(170 / ew, 130 / eh);
        return { width: Math.round(ew * k) + 'px', height: Math.round(eh * k) + 'px' };
      });
      function miniAt(ev) {
        var r = miniEl.value.getBoundingClientRect();
        renderer.centerOn((ev.clientX - r.left) / r.width * (game.w + 2) - 1, (ev.clientY - r.top) / r.height * (game.h + 2) - 1);
      }
      function miniDown(ev) { miniDrag = true; ev.target.setPointerCapture && ev.target.setPointerCapture(ev.pointerId); miniAt(ev); }
      function miniMove(ev) { if (miniDrag) miniAt(ev); }
      function miniUp() { miniDrag = false; }
      function onWheel(ev) {
        if (!renderer || !renderer.zoomed) return;
        ev.preventDefault();
        renderer.panBy(ev.deltaX + (ev.shiftKey ? ev.deltaY : 0), ev.shiftKey ? 0 : ev.deltaY);
      }
      function tap(h) {                      /* h = { cell: buňka pod ukazatelem, pos: levý horní roh věže vystředěné na ukazatel } */
        var t = game.towerAt(h.cell[0], h.cell[1]);
        if (t) { select(t); return; }
        if (shop.value) {
          var ck = game.canPlace(shop.value, h.pos[0], h.pos[1]);
          if (!ck.ok) { say(ck.reason, true); return; }
          game.place(shop.value, h.pos[0], h.pos[1]); sync(); refreshSel(); return;
        }
        select(null);
      }
      var lastPt = null, panning = false;
      function onDown(ev) { ptrType = ev.pointerType; downPt = { x: ev.clientX, y: ev.clientY }; lastPt = downPt; panning = false; hover = renderer.cellOf(ev, game); }
      function onMove(ev) {
        if (downPt && renderer.zoomed) {                   // táhnutím se posouvá přiblížená mapa (krátké klepnutí dál staví / vybírá)
          if (!panning && Math.hypot(ev.clientX - downPt.x, ev.clientY - downPt.y) > 10) panning = true;
          if (panning) { renderer.panBy(lastPt.x - ev.clientX, lastPt.y - ev.clientY); hover = null; }
          lastPt = { x: ev.clientX, y: ev.clientY };
          if (panning) return;
        }
        hover = renderer.cellOf(ev, game);
      }
      function onUp(ev) {
        var c = renderer.cellOf(ev, game);
        if (c && downPt && Math.hypot(ev.clientX - downPt.x, ev.clientY - downPt.y) < 10 && !menuOpen.value && !result.value) tap(c);
        downPt = null;
        if (ev.pointerType === 'touch') hover = null;
      }
      function onLeave() { hover = null; }

      function frame(ts) {
        raf = requestAnimationFrame(frame);
        var dt = Math.min(0.1, (ts - last) / 1000 || 0); last = ts;
        if (!v.paused && !menuOpen.value && !result.value && !BD.bestiary.ui.open) {
          acc += dt * v.speed;
          var n = 0; while (acc >= 1 / 60 && n++ < 24) { if (BD.dev.god || (lab && L.god)) { game.lives = Math.max(game.lives, 999); game.gold = Math.max(game.gold, 999999); } game.step(1 / 60); acc -= 1 / 60; }
          if (acc > 1) acc = 0;
        }
        renderer.draw(game, { selId: selId.value, hover: hover, shop: shop.value, show: show });
        if (renderer.zoomed && miniEl.value) renderer.drawMini(miniEl.value, game);
        syncT += dt;
        if (syncT > 0.1) { syncT = 0; sync(); refreshSel(); }
      }

      /* ---------- klávesové zkratky ----------
         Písmena a číslice se berou podle fyzické klávesy (ev.code), takže fungují i na české klávesnici bez Shiftu a s jiným rozložením.
         Každá zkratka může mít podmínku na Caps Lock (caps: true / false; bez ní platí vždy) a na Shift – připraveno na pozdější využití. */
      var keymap = [
        { key: 't',      run: function () { pickShop('base'); } },                                   // věž Základna
        { key: 's',      run: function () { doSell(); } },                                          // prodat věž
        { key: 'delete', run: function () { doSell(); } },
        { key: 'm',      run: function () { doMerge(); } },
        { key: 'p',      run: function () { v.paused = !v.paused; } },
        { key: 'c',      run: function () { if (dockOn.value) dock.open = !dock.open; } },
        { key: ' ',      run: function (ev) { ev.preventDefault(); callBelt(1); } },
        { key: '1',      run: function () { pickShop(Object.keys(TT)[0]); } },
        { key: '2',      run: function () { pickShop(Object.keys(TT)[1]); } },
        { key: '3',      run: function () { pickShop(Object.keys(TT)[2]); } },
      ];
      function keyInfo(ev) {
        var m = /^(?:Key([A-Z])|Digit([0-9])|Numpad([0-9]))$/.exec(ev.code || ''), k = m ? (m[1] || m[2] || m[3]).toLowerCase() : String(ev.key || '').toLowerCase();
        if (k === 'spacebar') k = ' ';
        return { key: k, caps: !!(ev.getModifierState && ev.getModifierState('CapsLock')), shift: !!ev.shiftKey };
      }
      function onKey(ev) {
        var tg = ev.target && ev.target.tagName; if (tg === 'INPUT' || tg === 'TEXTAREA' || tg === 'SELECT') return;
        if (ev.ctrlKey || ev.metaKey || ev.altKey) return;                    // Ctrl+S apod. nechává prohlížeči
        if (ev.bdSeq || BD.dev.open || BD.bestiary.ui.open) return;                                  // rozepsaný kód (např. „terminal“) nebo otevřený terminál: zkratky mlčí
        var ki = keyInfo(ev), k = ki.key; v.caps = ki.caps;
        if (k === 'escape') { if (shop.value || selId.value) { shop.value = null; select(null); } else menuOpen.value = !menuOpen.value; return; }
        if (menuOpen.value || result.value) return;
        for (var i = 0; i < keymap.length; i++) {
          var b = keymap[i];
          if (b.key !== k || (b.caps !== undefined && b.caps !== ki.caps) || (b.shift !== undefined && b.shift !== ki.shift)) continue;
          b.run(ev, ki); return;
        }
        if (renderer && renderer.zoomed && k.indexOf('arrow') === 0) { ev.preventDefault(); var pd = 90; renderer.panBy(k === 'arrowleft' ? -pd : k === 'arrowright' ? pd : 0, k === 'arrowup' ? -pd : k === 'arrowdown' ? pd : 0); }
      }
      function onKeyUp(ev) { if (ev.getModifierState) v.caps = !!ev.getModifierState('CapsLock'); }
      function onHide() { if (session.editorId) return; snapshotNow(); persist(); }

      onMounted(function () {
        renderer = new BD.render.Renderer(canvasEl.value);
        fit(); sync();
        ro = new ResizeObserver(fit); ro.observe(playEl.value);
        window.addEventListener('keydown', onKey); window.addEventListener('keyup', onKeyUp);
        window.addEventListener('pagehide', onHide);
        BD.dev.attach(game);
        raf = requestAnimationFrame(frame);
      });
      onBeforeUnmount(function () {
        labTimers.forEach(clearTimeout);
        BD.dev.detach(game); BD.systems.waves.testEnemy = null;
        cancelAnimationFrame(raf); if (ro) ro.disconnect();
        window.removeEventListener('keydown', onKey); window.removeEventListener('keyup', onKeyUp); window.removeEventListener('pagehide', onHide);
        clearTimeout(toastT);
      });

      /* pro testy a ladění */
      BD.debug = { dock: dock, cardsView: cardsView, get renderer() { return renderer; }, game: game, session: session, v: v, selId: selId, shop: shop, tStep: tStep, tap: tap, result: result };

      return { lab: lab, L: L, labTowers: labTowers, labEnemies: labEnemies, labTower: labTower, labEnemy: labEnemy, labSpawn: labSpawn, labClear: labClear, S: S, studio: BD.studio, v: v, towerList: towerList, shop: shop, sel: sel, show: show, toast: toast, result: result, menuOpen: menuOpen,
        shakeCls: shakeCls, nextNode: nextNode, stageEl: stageEl, canvasEl: canvasEl, miniEl: miniEl, dock: dock, zoomed: zoomed, big: big, miniStyle: miniStyle, setZoom: setZoom, onWheel: onWheel, miniDown: miniDown, miniMove: miniMove, miniUp: miniUp, playEl: playEl, beltEl: beltEl, tutorial: tutorial, steps: steps, tStep: tStep, tutStep: tutStep,
        dockOn: dockOn, cardsView: cardsView, freshIdx: freshIdx, canUseCard: canUseCard, useCard: useCard, dockWheel: dockWheel, bsUnread: bsUnread, openBestiary: openBestiary, canCall: canCall, callBelt: callBelt, settingsOpen: settingsOpen, blockStyle: blockStyle, best: best, backTo: backTo, backLabel: backLabel,
        pickShop: pickShop, cycleSpeed: cycleSpeed, doUpgrade: doUpgrade, doMerge: doMerge, doSell: doSell,
        restart: restart, leave: leave, onDown: onDown, onMove: onMove, onUp: onUp, onLeave: onLeave };
    },
  };
})(window.BD);
