/* ColorPicker – vlastní výběr barvy (místo systémového <input type="color">).
   Okno vyskočí nad místem, kde se barva volí (když nad ním není místo, pod ním). Skládá se ze 4 řádků:
     1) přepínač HEX / RGB / HSL / HSB
     2) vizuální výběr – pokaždé jiný: HEX = čtverec odstín-sytost-jas + pruh odstínu + pruh průhlednosti (s pipetou),
        RGB = plocha R×G + svislý pruh B, HSL = plocha odstín×sytost + svislý pruh světlosti, HSB = kruh odstínu s čtvercem uvnitř
     3) posuvníky a políčka pro ruční zápis (podle zvoleného typu)
     4) posledních 8 a 8 nejčastěji používaných barev (pamatuje se v tomto prohlížeči)
   Použití: BD.ui.colorPicker.open(prvekKamZakotvit, '#rrggbb[aa]', { alpha: true, onChange: function (css) {…}, onClose: function () {…} })
   Výstup je '#rrggbb' (bez průhlednosti) nebo '#rrggbbaa'.
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  var cp = BD.ui.colorPicker = {};
  var KEY = 'bd.colors.v1';

  /* ---------- barevná matematika ---------- */
  function clamp(v, a, b) { v = +v; return isFinite(v) ? Math.min(b, Math.max(a, v)) : a; }
  function hsv2rgb(h, s, v) {
    h = ((h % 360) + 360) % 360; var c = v * s, x = c * (1 - Math.abs((h / 60) % 2 - 1)), m = v - c, r = 0, g = 0, b = 0;
    if (h < 60) { r = c; g = x; } else if (h < 120) { r = x; g = c; } else if (h < 180) { g = c; b = x; } else if (h < 240) { g = x; b = c; } else if (h < 300) { r = x; b = c; } else { r = c; b = x; }
    return [(r + m) * 255, (g + m) * 255, (b + m) * 255];
  }
  function rgb2hsv(r, g, b) {
    r /= 255; g /= 255; b /= 255; var mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn, h = 0;
    if (d) { if (mx === r) h = ((g - b) / d) % 6; else if (mx === g) h = (b - r) / d + 2; else h = (r - g) / d + 4; h *= 60; if (h < 0) h += 360; }
    return { h: h, s: mx ? d / mx : 0, v: mx, gray: !d };
  }
  function hex2(n) { return ('0' + Math.round(clamp(n, 0, 255)).toString(16)).slice(-2); }
  /* '#rgb' '#rgba' '#rrggbb' '#rrggbbaa' rgb(a)(…) → {r,g,b,a} nebo null */
  function parse(str) {
    var c = String(str == null ? '' : str).trim(), m;
    if ((m = c.match(/^#?([0-9a-f]{3,4})$/i))) { var t = m[1].split('').map(function (x) { return x + x; }); return { r: parseInt(t[0], 16), g: parseInt(t[1], 16), b: parseInt(t[2], 16), a: t[3] ? Math.round(parseInt(t[3], 16) / 255 * 100) / 100 : 1 }; }
    if ((m = c.match(/^#?([0-9a-f]{6})([0-9a-f]{2})?$/i))) return { r: parseInt(m[1].slice(0, 2), 16), g: parseInt(m[1].slice(2, 4), 16), b: parseInt(m[1].slice(4), 16), a: m[2] ? Math.round(parseInt(m[2], 16) / 255 * 100) / 100 : 1 };
    if ((m = c.match(/^rgba?\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*(?:,\s*([\d.]+)\s*)?\)$/i))) return { r: clamp(m[1], 0, 255), g: clamp(m[2], 0, 255), b: clamp(m[3], 0, 255), a: m[4] === undefined ? 1 : clamp(m[4], 0, 1) };
    return null;
  }
  function css(r, g, b, a, withAlpha) { return '#' + hex2(r) + hex2(g) + hex2(b) + (withAlpha !== false && a < 0.995 ? hex2(a * 255) : ''); }
  cp.parse = parse; cp.format = css; cp.hsv2rgb = hsv2rgb; cp.rgb2hsv = rgb2hsv;

  /* ---------- paměť posledních a nejpoužívanějších barev ---------- */
  function load() { try { var o = JSON.parse(localStorage.getItem(KEY) || '{}'); return { recent: Array.isArray(o.recent) ? o.recent.slice(0, 8) : [], use: o.use && typeof o.use === 'object' ? o.use : {} }; } catch (e) { return { recent: [], use: {} }; } }
  function save(m) { try { localStorage.setItem(KEY, JSON.stringify(m)); } catch (e) {} }
  cp.remember = function (color) {
    var p = parse(color); if (!p) return; var k = css(p.r, p.g, p.b, p.a), m = load();
    m.recent = [k].concat(m.recent.filter(function (x) { return x !== k; })).slice(0, 8);
    m.use[k] = (m.use[k] || 0) + 1;
    var keys = Object.keys(m.use).sort(function (a, b) { return m.use[b] - m.use[a]; }); keys.slice(64).forEach(function (x) { delete m.use[x]; });      // paměť se neroztéká
    save(m); return m;
  };
  cp.memory = function () { var m = load(); return { recent: m.recent, often: Object.keys(m.use).sort(function (a, b) { return m.use[b] - m.use[a] || (m.recent.indexOf(a) < 0 ? 99 : m.recent.indexOf(a)) - (m.recent.indexOf(b) < 0 ? 99 : m.recent.indexOf(b)); }).slice(0, 8) }; };

  /* ---------- pomocné: tažení myší/dotykem ---------- */
  function track(ev, el, fn) {
    var r = el.getBoundingClientRect();
    function at(e) { fn(clamp((e.clientX - r.left) / r.width, 0, 1), clamp((e.clientY - r.top) / r.height, 0, 1), e); }
    el.setPointerCapture(ev.pointerId); ev.preventDefault(); at(ev);
    function mv(e) { at(e); } function up() { el.removeEventListener('pointermove', mv); el.removeEventListener('pointerup', up); el.removeEventListener('pointercancel', up); }
    el.addEventListener('pointermove', mv); el.addEventListener('pointerup', up); el.addEventListener('pointercancel', up);
  }

  var MODES = [['hex', 'HEX'], ['rgb', 'RGB'], ['hsl', 'HSL'], ['hsb', 'HSB']];
  var CH = {                                  // kanály pro řádek 3: [klíč, popisek, max, jednotka]
    rgb: [['r', 'R', 255], ['g', 'G', 255], ['b', 'B', 255]],
    hsl: [['h', 'H', 360], ['sl', 'S', 100], ['l', 'L', 100]],
    hsb: [['h', 'H', 360], ['sv', 'S', 100], ['v', 'B', 100]],
  };

  var Picker = {
    template: `
<div class="cpk" v-if="open" ref="root" :style="pos" @pointerdown.stop @keydown.esc.stop="close()" data-role="cpk">
  <div class="cpk-tabs" data-row="1"><button v-for="m in modes" :key="m[0]" :class="{on: mode === m[0]}" @click="mode = m[0]" :data-mode="m[0]">{{ m[1] }}</button></div>

  <div class="cpk-pick" data-row="2" :data-kind="mode">
    <template v-if="mode === 'hex'">
      <div class="cpk-sq" ref="sq" @pointerdown="dragSq" :style="{background: hueBg}"><i class="th" :style="{left: sv.s * 100 + '%', top: (1 - sv.v) * 100 + '%'}"></i></div>
      <div class="cpk-bars"><button class="cpk-eye" v-if="eye" @click="pipette" title="Pipeta (vzít barvu odkudkoliv z obrazovky)">⌖</button>
        <div class="cpk-bs"><div class="cpk-bar hue" ref="hb" @pointerdown="dragHue"><i class="th" :style="{left: h / 360 * 100 + '%'}"></i></div>
          <div class="cpk-bar alpha" v-if="alpha" ref="ab" @pointerdown="dragAlpha"><u :style="{background: alphaBg}"></u><i class="th" :style="{left: a * 100 + '%'}"></i></div></div></div>
    </template>
    <template v-else-if="mode === 'rgb'">
      <div class="cpk-plane"><canvas ref="plane" width="64" height="64" @pointerdown="dragPlane"></canvas><i class="th" :style="{left: rgb[0] / 255 * 100 + '%', top: (1 - rgb[1] / 255) * 100 + '%'}"></i><small class="ax x">R →</small><small class="ax y">G ↑</small></div>
      <div class="cpk-vbar" ref="vb" @pointerdown="dragV" :style="{background: vBg}"><i class="th" :style="{top: (1 - rgb[2] / 255) * 100 + '%'}"></i><small class="ax">B</small></div>
      <div class="cpk-bar alpha wide" v-if="alpha" ref="ab" @pointerdown="dragAlpha"><u :style="{background: alphaBg}"></u><i class="th" :style="{left: a * 100 + '%'}"></i></div>
    </template>
    <template v-else-if="mode === 'hsl'">
      <div class="cpk-plane"><canvas ref="plane" width="72" height="48" @pointerdown="dragPlane"></canvas><i class="th" :style="{left: h / 360 * 100 + '%', top: (1 - sl) * 100 + '%'}"></i><small class="ax x">H →</small><small class="ax y">S ↑</small></div>
      <div class="cpk-vbar" ref="vb" @pointerdown="dragV" :style="{background: vBg}"><i class="th" :style="{top: (1 - l) * 100 + '%'}"></i><small class="ax">L</small></div>
      <div class="cpk-bar alpha wide" v-if="alpha" ref="ab" @pointerdown="dragAlpha"><u :style="{background: alphaBg}"></u><i class="th" :style="{left: a * 100 + '%'}"></i></div>
    </template>
    <template v-else>
      <div class="cpk-ring" ref="ring" @pointerdown="dragRing" :style="{width: D + 'px', height: D + 'px'}">
        <div class="cpk-ringbg"></div>
        <i class="th" :style="ringThumb"></i>
        <div class="cpk-in" :style="{width: inner + 'px', height: inner + 'px', background: hueBg}"><i class="th" :style="{left: sv.s * 100 + '%', top: (1 - sv.v) * 100 + '%'}"></i></div>
      </div>
      <div class="cpk-bar alpha wide" v-if="alpha" ref="ab" @pointerdown="dragAlpha"><u :style="{background: alphaBg}"></u><i class="th" :style="{left: a * 100 + '%'}"></i></div>
    </template>
  </div>

  <div class="cpk-vals" data-row="3">
    <template v-if="mode === 'hex'">
      <label class="cr"><span>HEX</span><input class="in hexin" :value="hexText" @change="setHex($event.target.value)" @keydown.enter="setHex($event.target.value)" spellcheck="false" maxlength="9" data-role="cpk-hex"></label>
    </template>
    <template v-else>
      <label class="cr" v-for="c in chans" :key="c[0]"><span>{{ c[1] }}</span>
        <input type="range" min="0" :max="c[2]" step="1" :value="chv(c)" :style="{'--trk': trk(c)}" @input="setCh(c, $event.target.value)" :data-ch="c[0]">
        <input class="in n" type="number" min="0" :max="c[2]" step="1" :value="chv(c)" @change="setCh(c, $event.target.value)" :data-num="c[0]"></label>
    </template>
    <label class="cr" v-if="alpha"><span>A</span><input type="range" min="0" max="100" step="1" :value="Math.round(a * 100)" :style="{'--trk': alphaBg}" @input="setA($event.target.value)" data-ch="a"><input class="in n" type="number" min="0" max="100" step="1" :value="Math.round(a * 100)" @change="setA($event.target.value)" data-num="a"></label>
  </div>

  <div class="cpk-mem" data-row="4">
    <div class="ml"><small>Poslední</small><div class="sw"><button v-for="(c, i) in mem.recent8" :key="'r' + i" :class="{empty: !c}" :style="c ? {'--c': c} : null" @click="use(c)" :disabled="!c" :title="c || ''" :data-recent="i"><i></i></button></div></div>
    <div class="ml"><small>Často</small><div class="sw"><button v-for="(c, i) in mem.often8" :key="'o' + i" :class="{empty: !c}" :style="c ? {'--c': c} : null" @click="use(c)" :disabled="!c" :title="c || ''" :data-often="i"><i></i></button></div></div>
  </div>
</div>`,
    data: function () { return { open: false, mode: 'hex', h: 0, sv: { s: 0, v: 1 }, sl: 0, l: 1, a: 1, alpha: true, anchor: null, pos: { left: '0px', top: '0px', visibility: 'hidden' }, mem: { recent8: [], often8: [] }, start: '', D: 196, eye: typeof window.EyeDropper === 'function' }; },
    computed: {
      modes: function () { return MODES; },
      chans: function () { return CH[this.mode] || []; },
      rgb: function () { return hsv2rgb(this.h, this.sv.s, this.sv.v); },
      inner: function () { return Math.round(this.D * 0.5); },
      hueBg: function () { var c = hsv2rgb(this.h, 1, 1); return 'linear-gradient(to top,#000,rgba(0,0,0,0)),linear-gradient(to right,#fff,rgb(' + c.map(Math.round).join(',') + '))'; },
      alphaBg: function () { var c = this.rgb.map(Math.round).join(','); return 'linear-gradient(to right, rgba(' + c + ',0), rgb(' + c + '))'; },
      vBg: function () {
        if (this.mode === 'rgb') { var r = Math.round(this.rgb[0]), g = Math.round(this.rgb[1]); return 'linear-gradient(to top, rgb(' + r + ',' + g + ',0), rgb(' + r + ',' + g + ',255))'; }
        var s = Math.round(this.sl * 100); return 'linear-gradient(to top, hsl(' + Math.round(this.h) + ',' + s + '%,0%), hsl(' + Math.round(this.h) + ',' + s + '%,50%), hsl(' + Math.round(this.h) + ',' + s + '%,100%))';
      },
      hexText: function () { var c = this.rgb; return css(c[0], c[1], c[2], this.alpha ? this.a : 1).toUpperCase(); },
      ringThumb: function () { var R = this.D / 2, rr = R * 0.82, ang = this.h * Math.PI / 180; return { left: (R + Math.sin(ang) * rr) + 'px', top: (R - Math.cos(ang) * rr) + 'px' }; },
      value: function () { var c = this.rgb; return css(c[0], c[1], c[2], this.alpha ? this.a : 1); },
    },
    watch: {
      mode: function () { this.$nextTick(this.paintPlane); },
      rgb: function () { if (this.mode === 'rgb') this.paintPlane(); },
      l: function () { if (this.mode === 'hsl') this.paintPlane(); },
    },
    methods: {
      /* ----- stav ⇄ barva ----- */
      load: function (str) {
        var p = parse(str) || { r: 136, g: 136, b: 136, a: 1 }, q = rgb2hsv(p.r, p.g, p.b);
        this.h = q.gray ? this.h : q.h; this.sv = { s: q.s, v: q.v }; this.a = p.a; this.syncHsl(); 
      },
      syncHsl: function () {                                      // HSL odvozené z HSV (při černé/bílé se zachová poslední sytost)
        var s = this.sv.s, v = this.sv.v, l = v * (1 - s / 2); this.l = l;
        if (l > 0.0005 && l < 0.9995) this.sl = (v - l) / Math.min(l, 1 - l);
      },
      fromHsl: function (h, s, l) {
        var v = l + s * Math.min(l, 1 - l); this.h = h; this.sl = s; this.l = l;
        this.sv = { s: v > 0.0005 ? 2 * (1 - l / v) : this.sv.s, v: v };
      },
      emit: function () { if (this.cb) this.cb(this.value); },
      setHsv: function (h, s, v) { this.h = h; this.sv = { s: s, v: v }; this.syncHsl(); this.emit(); },
      setRgb: function (r, g, b) { var q = rgb2hsv(r, g, b); this.h = q.gray ? this.h : q.h; this.sv = { s: q.s, v: q.v }; this.syncHsl(); this.emit(); },
      /* ----- tažení ----- */
      dragSq: function (ev) { var me = this; track(ev, this.$refs.sq, function (x, y) { me.setHsv(me.h, x, 1 - y); }); },
      dragHue: function (ev) { var me = this; track(ev, this.$refs.hb, function (x) { if (me.mode === 'hsl') me.fromHsl(x * 360, me.sl, me.l); else me.setHsv(Math.min(359.9, x * 360), me.sv.s, me.sv.v); if (me.mode === 'hsl') me.emit(); }); },
      dragAlpha: function (ev) { var me = this; track(ev, this.$refs.ab, function (x) { me.a = Math.round(x * 100) / 100; me.emit(); }); },
      dragV: function (ev) {
        var me = this; track(ev, this.$refs.vb, function (x, y) {
          if (me.mode === 'rgb') { var c = me.rgb; me.setRgb(c[0], c[1], (1 - y) * 255); } else { me.fromHsl(me.h, me.sl, 1 - y); me.emit(); }
        });
      },
      dragPlane: function (ev) {
        var me = this; track(ev, ev.currentTarget, function (x, y) {
          if (me.mode === 'rgb') { var c = me.rgb; me.setRgb(x * 255, (1 - y) * 255, c[2]); } else { me.fromHsl(Math.min(359.9, x * 360), 1 - y, me.l); me.emit(); }
        });
      },
      dragRing: function (ev) {
        var me = this, el = this.$refs.ring, r = el.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2, d0 = Math.hypot(ev.clientX - cx, ev.clientY - cy), hue = d0 > this.inner * 0.72;
        if (hue) { el.setPointerCapture(ev.pointerId); ev.preventDefault(); var upd = function (e) { var h = Math.atan2(e.clientX - cx, -(e.clientY - cy)) * 180 / Math.PI; if (h < 0) h += 360; me.setHsv(Math.min(359.9, h), me.sv.s, me.sv.v); };
          upd(ev); var mv = function (e) { upd(e); }, up = function () { el.removeEventListener('pointermove', mv); el.removeEventListener('pointerup', up); el.removeEventListener('pointercancel', up); };
          el.addEventListener('pointermove', mv); el.addEventListener('pointerup', up); el.addEventListener('pointercancel', up); return; }
        var sq = el.querySelector('.cpk-in'); track(ev, sq, function (x, y) { me.setHsv(me.h, x, 1 - y); });
      },
      /* ----- řádek 3 ----- */
      chv: function (c) {
        var k = c[0]; if (k === 'r') return Math.round(this.rgb[0]); if (k === 'g') return Math.round(this.rgb[1]); if (k === 'b') return Math.round(this.rgb[2]);
        if (k === 'h') return Math.round(this.h) % 360; if (k === 'sl') return Math.round(this.sl * 100); if (k === 'l') return Math.round(this.l * 100); if (k === 'sv') return Math.round(this.sv.s * 100); if (k === 'v') return Math.round(this.sv.v * 100); return 0;
      },
      setCh: function (c, val) {
        var k = c[0], v = clamp(val, 0, c[2]), r = this.rgb;
        if (k === 'r') this.setRgb(v, r[1], r[2]); else if (k === 'g') this.setRgb(r[0], v, r[2]); else if (k === 'b') this.setRgb(r[0], r[1], v);
        else if (k === 'h') { if (this.mode === 'hsl') { this.fromHsl(v, this.sl, this.l); this.emit(); } else this.setHsv(v, this.sv.s, this.sv.v); }
        else if (k === 'sl') { this.fromHsl(this.h, v / 100, this.l); this.emit(); } else if (k === 'l') { this.fromHsl(this.h, this.sl, v / 100); this.emit(); }
        else if (k === 'sv') this.setHsv(this.h, v / 100, this.sv.v); else if (k === 'v') this.setHsv(this.h, this.sv.s, v / 100);
      },
      setA: function (v) { this.a = clamp(v, 0, 100) / 100; this.emit(); },
      setHex: function (t) { var p = parse(t); if (!p) { this.$forceUpdate(); return; } var q = rgb2hsv(p.r, p.g, p.b); this.h = q.gray ? this.h : q.h; this.sv = { s: q.s, v: q.v }; if (this.alpha && /^#?([0-9a-f]{4}|[0-9a-f]{8})$/i.test(t.trim())) this.a = p.a; this.syncHsl(); this.emit(); },
      /* posuvník kanálu je vybarvený podle toho, co by se změnilo */
      trk: function (c) {
        var k = c[0], r = this.rgb.map(Math.round), h = Math.round(this.h);
        if (k === 'r') return 'linear-gradient(to right, rgb(0,' + r[1] + ',' + r[2] + '), rgb(255,' + r[1] + ',' + r[2] + '))';
        if (k === 'g') return 'linear-gradient(to right, rgb(' + r[0] + ',0,' + r[2] + '), rgb(' + r[0] + ',255,' + r[2] + '))';
        if (k === 'b') return 'linear-gradient(to right, rgb(' + r[0] + ',' + r[1] + ',0), rgb(' + r[0] + ',' + r[1] + ',255))';
        if (k === 'h') return 'linear-gradient(to right,#f00,#ff0,#0f0,#0ff,#00f,#f0f,#f00)';
        if (k === 'sl') return 'linear-gradient(to right, hsl(' + h + ',0%,' + Math.round(this.l * 100) + '%), hsl(' + h + ',100%,' + Math.round(this.l * 100) + '%))';
        if (k === 'l') return 'linear-gradient(to right,#000, hsl(' + h + ',' + Math.round(this.sl * 100) + '%,50%),#fff)';
        if (k === 'sv') { var a = hsv2rgb(this.h, 0, this.sv.v).map(Math.round), b = hsv2rgb(this.h, 1, this.sv.v).map(Math.round); return 'linear-gradient(to right, rgb(' + a + '), rgb(' + b + '))'; }
        var d = hsv2rgb(this.h, this.sv.s, 1).map(Math.round); return 'linear-gradient(to right,#000, rgb(' + d + '))';
      },
      /* plocha R×G (při B) nebo odstín×sytost (při L) – kreslí se do malého plátna, které se roztáhne */
      paintPlane: function () {
        var cv = this.$refs.plane; if (!cv) return; var ctx = cv.getContext('2d'), w = cv.width, h = cv.height, im = ctx.createImageData(w, h), d = im.data, x, y, i, c;
        for (y = 0; y < h; y++) for (x = 0; x < w; x++) {
          i = (y * w + x) * 4;
          if (this.mode === 'rgb') c = [x / (w - 1) * 255, (1 - y / (h - 1)) * 255, this.rgb[2]];
          else { var hh = x / (w - 1) * 360, s = 1 - y / (h - 1), l = this.l, v = l + s * Math.min(l, 1 - l); c = hsv2rgb(hh, v > 0 ? 2 * (1 - l / v) : 0, v); }
          d[i] = c[0]; d[i + 1] = c[1]; d[i + 2] = c[2]; d[i + 3] = 255;
        }
        ctx.putImageData(im, 0, 0);
      },
      pipette: function () { var me = this; try { new window.EyeDropper().open().then(function (r) { me.setHex(r.sRGBHex); }).catch(function () {}); } catch (e) {} },
      use: function (c) { if (!c) return; this.load(c); this.emit(); this.touched = true; this.$nextTick(this.paintPlane); },
      refreshMem: function () {
        var m = cp.memory(), pad = function (a) { a = a.slice(0, 8); while (a.length < 8) a.push(''); return a; };
        this.mem = { recent8: pad(m.recent), often8: pad(m.often) };
      },
      /* ----- okno ----- */
      place: function () {
        var root = this.$refs.root, a = this.anchor; if (!root || !a || !a.getBoundingClientRect) return;
        var r = a.getBoundingClientRect(), w = root.offsetWidth, h = root.offsetHeight, vw = window.innerWidth, vh = window.innerHeight;
        var top = r.top - h - 8; if (top < 8) { top = r.bottom + 8; if (top + h > vh - 8) top = Math.max(8, vh - h - 8); }
        var left = Math.min(Math.max(8, r.left + r.width / 2 - w / 2), vw - w - 8);
        this.pos = { left: left + 'px', top: top + 'px', visibility: 'visible' };
      },
      show: function (anchor, color, o) {
        o = o || {}; if (this.open) this.close(true);
        this.cb = o.onChange || null; this.onClose = o.onClose || null; this.alpha = o.alpha !== false; this.anchor = anchor; this.start = '';
        this.load(color); this.start = this.value; this.touched = false; this.refreshMem(); this.pos = { left: '0px', top: '0px', visibility: 'hidden' }; this.open = true;
        var me = this; this.$nextTick(function () { me.paintPlane(); me.place(); var r = me.$refs.root; if (r) r.focus && r.focus(); });
        this.offDown = function (e) { if (me.$refs.root && !me.$refs.root.contains(e.target) && !(me.anchor && me.anchor.contains && me.anchor.contains(e.target))) me.close(); };
        this.offKey = function (e) { if (e.key === 'Escape') me.close(); };
        this.offScroll = function () { me.place(); };
        setTimeout(function () { document.addEventListener('pointerdown', me.offDown, true); }, 0);
        document.addEventListener('keydown', this.offKey, true); window.addEventListener('resize', this.offScroll); document.addEventListener('scroll', this.offScroll, true);
      },
      close: function (silent) {
        if (!this.open) return; this.open = false;
        document.removeEventListener('pointerdown', this.offDown, true); document.removeEventListener('keydown', this.offKey, true); window.removeEventListener('resize', this.offScroll); document.removeEventListener('scroll', this.offScroll, true);
        if (this.value !== this.start || this.touched) cp.remember(this.value);               // do historie se zapíše při zavření, když se barva změnila
        var f = this.onClose; this.onClose = null; this.cb = null; if (f && !silent) f(); else if (f) f();
      },
    },
  };

  var host = null, inst = null;
  function ensure() {
    if (inst) return inst; host = document.createElement('div'); host.id = 'cpk-host'; document.body.appendChild(host);
    var app = Vue.createApp(Picker); inst = app.mount(host); return inst;
  }
  cp.open = function (anchor, color, o) { ensure().show(anchor, color, o); };
  cp.close = function () { if (inst) inst.close(); };
  cp.isOpen = function () { return !!(inst && inst.open); };
  cp.vm = function () { return inst; };
})(window.BD);
