/* Pomocné funkce pro export levelů: stažení souboru a kopírování do schránky. */
(function (BD) {
  'use strict';
  BD.ui = BD.ui || {};
  BD.ui.levelIO = {
    download: function (text, name) {
      var blob = new Blob([text], { type: 'application/json' });
      var a = document.createElement('a');
      a.href = URL.createObjectURL(blob); a.download = name;
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
      setTimeout(function () { URL.revokeObjectURL(a.href); }, 2000);
    },
    copy: async function (text) {
      try { await navigator.clipboard.writeText(text); return true; } catch (e) {}
      var ta = document.createElement('textarea'); ta.value = text; document.body.appendChild(ta); ta.select();
      var ok = false; try { ok = document.execCommand('copy'); } catch (e2) {}
      document.body.removeChild(ta); return ok;
    },
    fileName: function (name) { return 'level-' + (String(name || 'level').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'level') + '.json'; },
  };
})(window.BD);
