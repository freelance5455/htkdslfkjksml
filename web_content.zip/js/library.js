/* جنة القرآن v6 — المكتبة الشخصية والتدبر */
'use strict';
const BMC={g:['#2e9e5b','أخضر'],r:['#d64545','أحمر'],b:['#3b82d6','أزرق'],y:['#e0b020','أصفر'],p:['#9b59d0','بنفسجي']};
const lib=()=>ls.get('lib',{it:{},fo:[]});
function libSet(fn){const L=lib();fn(L);Object.keys(L.it).forEach(k=>{const x=L.it[k];if(!x.bm&&!x.fo&&!x.nt&&!x.rv&&!x.td)delete L.it[k]});ls.set('lib',L);return L}
const itm=(L,k)=>(L.it[k]=L.it[k]||{ts:Date.now()});
/* إضافة صف أزرار إلى نافذة الآية */
const _sheet=sheet;
sheet=async function(s,a){await _sheet(s,a);const sh=document.querySelector('#sheet .sh');if(!sh||$('#lbx'))return;const k=s+':'+a,x=lib().it[k]||{};
  const d=document.createElement('div');d.id='lbx';d.className='row';
  d.innerHTML=`<button class="o" onclick="bmUI(${s},${a})">${x.bm?'🔖 علامة':'🔖 علّم'}</button><button class="o" onclick="noteUI(${s},${a})">📝 ${x.nt?'ملاحظتي':'ملاحظة'}</button><button class="o" onclick="foUI(${s},${a})">📂 مجلد</button><button class="o" onclick="rvAdd(${s},${a})">${x.rv?'✔ في المراجعة':'🔁 للمراجعة'}</button><button class="o" onclick="repeatUI(${s},${a})">🔂 تكرار</button><button class="o" onclick="closeSheet();understand(${s},${a})">🔍 فهم</button><button class="o" onclick="closeSheet();tadabbur(${s},${a})">📖 تدبّر</button><button class="o" onclick="closeSheet();studio(${s},${a})">🎨 استوديو</button>`;
  sh.insertBefore(d,$('#tf'))};
/* علامات */
function bmUI(s,a){const k=s+':'+a,x=lib().it[k]||{};openSheet(`<h3>🔖 علامة مرجعية</h3><div class="sub">${esc(nm(s))} · ${AR(a)}</div><div class="row">${Object.keys(BMC).map(c=>`<button class="o" style="border-color:${BMC[c][0]};${x.bm==c?'background:'+BMC[c][0]+'44':''}" onclick="bmSet(${s},${a},'${c}')">● ${BMC[c][1]}</button>`).join('')}</div>${x.bm?`<button class="o w" onclick="bmSet(${s},${a},'')">إزالة العلامة</button>`:''}`)}
function bmSet(s,a,c){libSet(L=>{const x=itm(L,s+':'+a);x.bm=c||undefined});closeSheet();toast(c?'🔖 تمت العلامة':'أُزيلت العلامة');decorate()}
/* مجلدات */
function foUI(s,a){const L=lib(),x=L.it[s+':'+a]||{};openSheet(`<h3>📂 إضافة إلى مجلد</h3><div class="sub">${esc(nm(s))} · ${AR(a)}</div>${L.fo.map(f=>`<button class="${x.fo==f.id?'b':'o'} w" onclick="foSet(${s},${a},'${f.id}')">📁 ${esc(f.n)}</button>`).join('')}<input id="fon" class="in" placeholder="مجلد جديد…"><button class="b w" onclick="foNew(${s},${a})">＋ إنشاء مجلد وإضافة</button>${x.fo?`<button class="o w" onclick="foSet(${s},${a},'')">إخراجها من المجلد</button>`:''}`)}
function foSet(s,a,id){libSet(L=>{itm(L,s+':'+a).fo=id||undefined});closeSheet();toast('تم ✅')}
function foNew(s,a){const n=($('#fon').value||'').trim();if(!n)return toast('اكتب اسم المجلد');const id='f'+Date.now().toString(36);libSet(L=>{L.fo.push({id,n});itm(L,s+':'+a).fo=id});closeSheet();toast('تم ✅')}
/* ملاحظات */
async function noteUI(s,a){await names();const k=s+':'+a,x=lib().it[k]||{};enter('more');const t=await ayahT(s,a);
  v.innerHTML=head('📝 ملاحظتي')+`<div class="card"><b>${esc(nm(s))} · ${AR(a)}</b><div class="qt sm">${esc(t)}</div></div><textarea id="nt" class="in" rows="6" placeholder="اكتب خاطرتك أو فائدتك من الآية…">${esc(x.nt||'')}</textarea><button class="b w" onclick="noteSave(${s},${a})">💾 حفظ</button>${x.nt?`<button class="o w" onclick="noteDel(${s},${a})">🗑 حذف الملاحظة</button>`:''}<button class="o w" onclick="openS(${s},${a})">📖 العودة للآية</button>`}
function noteSave(s,a){const t=$('#nt').value.trim();libSet(L=>{itm(L,s+':'+a).nt=t||undefined});toast('تم الحفظ ✅');logAdd('nt');if(window.checkBadges)checkBadges()}
function noteDel(s,a){libSet(L=>{itm(L,s+':'+a).nt=undefined});library('notes')}
/* المراجعة */
function rvAdd(s,a){const k=s+':'+a;libSet(L=>{const x=itm(L,k);x.rv=x.rv?undefined:{d:td(),lv:0,nx:addDays(td(),1)}});closeSheet();toast('تم ✅')}
function rvDone(k,ok){libSet(L=>{const x=L.it[k];if(!x||!x.rv)return;x.rv.lv=ok?Math.min(5,x.rv.lv+1):Math.max(0,x.rv.lv-1);x.rv.nx=addDays(td(),ok?RI[x.rv.lv]:1)});library('rv')}
/* صفحة مكتبتي */
async function library(tab,fid){await names();enter('more');tab=tab||'bm';const L=lib(),its=Object.entries(L.it),T=[['bm','🔖 العلامات'],['fo','📂 المجلدات'],['notes','📝 ملاحظاتي'],['td','📖 تدبّري'],['rv','🔁 المراجعة'],['fav','❤️ المفضلة']];
  let h=head('📚 مكتبتي')+`<div class="seg">${T.map(t=>`<button class="${t[0]==tab?'on':''}" onclick="library('${t[0]}')">${t[1]}</button>`).join('')}</div>`;
  const row=async(k,extra)=>{const[s,a]=KP(k);let t='';try{t=await ayahT(s,a)}catch(e){}const x=L.it[k]||{};return `<div class="card"><div onclick="openS(${s},${a})"><b>${x.bm?`<span style="color:${BMC[x.bm][0]}">●</span> `:''}${esc(nm(s))} · ${AR(a)}</b><div class="qt sm">${esc(snip(t,150))}</div></div>${extra||''}</div>`};
  v.innerHTML=h+LD;
  if(tab=='bm'){const f=S._bmf||'';const list=its.filter(([k,x])=>x.bm&&(!f||x.bm==f));h+=`<div>${Object.keys(BMC).map(c=>`<span class="chip ${f==c?'on':''}" onclick="S._bmf=S._bmf=='${c}'?'':'${c}';library('bm')"><span style="color:${BMC[c][0]}">●</span> ${BMC[c][1]}</span>`).join('')}</div>`;
    h+=(await Promise.all(list.sort((a,b)=>b[1].ts-a[1].ts).map(([k])=>row(k)))).join('')||'<p class="mt">لا علامات بعد. اضغط على آية ثم «🔖 علّم»</p>'}
  else if(tab=='fo'){if(fid){const f=L.fo.find(x=>x.id==fid);h+=`<h3>📁 ${esc(f?f.n:'')}</h3><button class="o" onclick="library('fo')">→ المجلدات</button>`+(await Promise.all(its.filter(([k,x])=>x.fo==fid).map(([k])=>row(k,`<button class="o" onclick="foSet(${KP(k)[0]},${KP(k)[1]},'');library('fo','${fid}')">إخراج</button>`)))).join('')||'<p class="mt">المجلد فارغ</p>';
      h+=`<button class="o w" onclick="foRen('${fid}')">✏️ تسمية المجلد</button><button class="o w" onclick="foDel('${fid}')">🗑 حذف المجلد (تبقى الآيات)</button>`}
    else{h+=L.fo.map(f=>`<button class="card" onclick="library('fo','${f.id}')">📁 <b>${esc(f.n)}</b> · ${AR(its.filter(([k,x])=>x.fo==f.id).length)} آية</button>`).join('')||'<p class="mt">لا مجلدات بعد. أنشئ مجلدًا من نافذة أي آية.</p>';h+=`<input id="fon" class="in" placeholder="اسم مجلد جديد"><button class="b w" onclick="foMk()">＋ إنشاء مجلد</button>`}}
  else if(tab=='notes'){h+=(await Promise.all(its.filter(([k,x])=>x.nt).sort((a,b)=>b[1].ts-a[1].ts).map(([k,x])=>row(k,`<div class="tx"><b>ملاحظتي</b>${esc(x.nt)}</div><button class="o" onclick="noteUI(${KP(k)[0]},${KP(k)[1]})">✏️ تعديل</button>`)))).join('')||'<p class="mt">لا ملاحظات بعد.</p>'}
  else if(tab=='td'){h+=`<button class="b w" onclick="tadabbur()">＋ تدبّر جديد</button>`+(await Promise.all(its.filter(([k,x])=>x.td).sort((a,b)=>(b[1].td.ts||0)-(a[1].td.ts||0)).map(([k,x])=>row(k,`<div class="tx"><b>ما وقفتُ عنده</b>${esc(x.td.a||'—')}<b>ما سأعمل به</b>${esc(x.td.b||'—')}<b>دعائي</b>${esc(x.td.c||'—')}</div><button class="o" onclick="tadabbur(${KP(k)[0]},${KP(k)[1]})">✏️ تعديل</button>`)))).join('')}
  else if(tab=='rv'){const due=its.filter(([k,x])=>x.rv&&x.rv.nx<=td()).length;h+=`<div class="sub">${AR(its.filter(([k,x])=>x.rv).length)} آية · المستحقة اليوم: ${AR(due)}</div>`+(await Promise.all(its.filter(([k,x])=>x.rv).sort((a,b)=>a[1].rv.nx.localeCompare(b[1].rv.nx)).map(([k,x])=>row(k,`<div class="sub">${x.rv.nx<=td()?'⏰ موعد المراجعة: اليوم':'القادمة: '+x.rv.nx} · مستوى ${AR(x.rv.lv)}</div><div class="row"><button class="b" onclick="rvDone('${k}',1)">✔ راجعتها</button><button class="o" onclick="rvDone('${k}',0)">✖ تعثّرت</button><button class="o" onclick="rvAdd(${KP(k)[0]},${KP(k)[1]});library('rv')">إزالة</button></div>`)))).join('')||'<p class="mt">أضف آيات من نافذة الآية عبر «🔁 للمراجعة»</p>'}
  else{h+=(await Promise.all(S.favs.map(k=>row(k,`<div class="sub">${L.it[k]&&L.it[k].fo?'📁 '+esc((L.fo.find(f=>f.id==L.it[k].fo)||{}).n||''):''}</div><button class="o" onclick="foUI(${KP(k)[0]},${KP(k)[1]})">📂 مجلد</button>`)))).join('')||'<p class="mt">لا مفضلة بعد.</p>'}
  v.innerHTML=h}
function foMk(){const n=($('#fon').value||'').trim();if(!n)return toast('اكتب اسم المجلد');libSet(L=>L.fo.push({id:'f'+Date.now().toString(36),n}));library('fo')}
function foRen(id){const n=prompt('اسم المجلد');if(!n)return;libSet(L=>{const f=L.fo.find(x=>x.id==id);if(f)f.n=n.trim()});library('fo',id)}
function foDel(id){if(!confirm('حذف المجلد؟ تبقى الآيات في مكتبتك.'))return;libSet(L=>{L.fo=L.fo.filter(f=>f.id!=id);Object.values(L.it).forEach(x=>{if(x.fo==id)x.fo=undefined})});library('fo')}
/* تلوين الآيات في القراءة */
function decorate(){if(!$('.qt')||!S.cur)return;const L=lib();document.querySelectorAll('.ay[id^=a]').forEach(e=>{const a=e.id.slice(1),x=L.it[S.cur+':'+a];if(x&&x.bm)e.dataset.bm=x.bm;else delete e.dataset.bm;const m=e.querySelector('.nt');if(x&&(x.nt||x.td)){if(!m)e.insertAdjacentHTML('beforeend','<i class="n nt">📝</i>')}else if(m)m.remove()})}
const _openS=openS;
openS=async function(s,a){await _openS(s,a);try{decorate();addReaderBar()}catch(e){}};
function addReaderBar(){if($('#rbar')||!$('.qt'))return;const b=document.createElement('div');b.id='rbar';b.className='row';b.innerHTML=`<button class="o" onclick="khushoo(1)">🌙 خشوع</button><button class="o" onclick="plAdd(S.cur)">🎶 للقائمة</button><button class="o" onclick="recPicker()">🎙 قارئ</button><button class="o" onclick="surahInfo(S.cur)">🗂 عن السورة</button><button class="o" onclick="understand(S.cur,1)">🔍 فهم</button>`;const r=v.querySelector('.row');if(r)r.after(b)}
/* وضع التدبّر */
async function tadabbur(s,a){await names();enter('more');const lp=ls.get('last',[1,1]);s=s||lp[0];a=a||lp[1];const n=S.cnt[s-1];a=Math.max(1,Math.min(n,a));const k=s+':'+a,x=(lib().it[k]||{}).td||{};
  v.innerHTML=head('📖 وضع التدبّر')+LD;const t=await ayahT(s,a);let tf='';try{tf=(await api('/ayah/'+gidx(s,a)+'/ar.muyassar')).text}catch(e){}
  v.innerHTML=head('📖 وضع التدبّر')+`<div class="row"><select id="ts" onchange="tadabbur(+this.value,1)">${surahOpts(s)}</select><button class="o" onclick="tadabbur(${s},${a-1})">▶</button><b style="align-self:center">${AR(a)}/${AR(n)}</b><button class="o" onclick="tadabbur(${s},${a+1})">◀</button></div>
  <div class="card"><div class="qt">${esc(t)} <i class="n">﴿${AR(a)}﴾</i></div></div>
  <div class="row"><button class="o" onclick="playAyah(${s},${a},${a})">🎧 استمع</button></div>
  <details class="card"><summary>📚 التفسير الميسر</summary><p style="line-height:1.9">${esc(tf||'غير متاح الآن')}</p></details>
  <label class="lb">1) ما الذي أوقفني عند هذه الآية؟</label><textarea id="td1" class="in" rows="3">${esc(x.a||'')}</textarea>
  <label class="lb">2) ما الذي سأعمل به أو أغيّره؟</label><textarea id="td2" class="in" rows="3">${esc(x.b||'')}</textarea>
  <label class="lb">3) دعائي المستلهم من الآية</label><textarea id="td3" class="in" rows="2">${esc(x.c||'')}</textarea>
  <button class="b w" onclick="tdSave(${s},${a})">💾 حفظ التدبّر</button><div class="sub">المساعد يطرح أسئلة للتأمل فقط؛ لا يولّد تفسيرًا.</div>`}
function tdSave(s,a){const o={a:$('#td1').value.trim(),b:$('#td2').value.trim(),c:$('#td3').value.trim(),ts:Date.now()};libSet(L=>{itm(L,s+':'+a).td=(o.a||o.b||o.c)?o:undefined});toast('تم حفظ تدبّرك ✅');if(o.a||o.b||o.c){logAdd('nt');if(window.checkBadges)checkBadges()}}
