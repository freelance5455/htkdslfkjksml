export const firebaseConfig = {
  apiKey: "AIzaSyBKTnrYb67r-FkWHtzLxVIujEgMo2iz06A",
  authDomain: "al-insaf-460a5.firebaseapp.com",
  projectId: "al-insaf-460a5",
  storageBucket: "al-insaf-460a5.firebasestorage.app",
  messagingSenderId: "417118259448",
  appId: "1:417118259448:web:cfa3a6f12bdfb3ef20930d",
  measurementId: "G-Y29K18NTY6"
};
