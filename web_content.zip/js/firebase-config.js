/**
 * BD BLOOD DONATION - Real Production Firebase Configuration
 * Project ID: bd-blood-dontion
 * Sender ID: 279297430175
 * Modular Firebase SDK v11 integration
 */

import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getAuth, 
  setPersistence, 
  browserLocalPersistence,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  signOut,
  onAuthStateChanged,
  updateProfile
} from 'firebase/auth';
import { 
  getFirestore, 
  collection, 
  doc, 
  getDoc, 
  setDoc, 
  addDoc, 
  updateDoc, 
  deleteDoc,
  query, 
  where, 
  orderBy, 
  limit, 
  getDocs, 
  onSnapshot, 
  serverTimestamp, 
  increment,
  arrayUnion,
  arrayRemove
} from 'firebase/firestore';
import { 
  getStorage, 
  ref as storageRef, 
  uploadBytes, 
  getDownloadURL 
} from 'firebase/storage';

// Real credentials from user's provided google-services.json & GoogleService-Info.plist
export const firebaseConfig = {
  apiKey: "AIzaSyCYgoYKpT414F02f5lpQemwpOOLNzD_1pw",
  authDomain: "bd-blood-dontion.firebaseapp.com",
  projectId: "bd-blood-dontion",
  storageBucket: "bd-blood-dontion.firebasestorage.app",
  messagingSenderId: "279297430175",
  appId: "1:279297430175:web:bd-blood-donation-web"
};

// Initialize Firebase App singleton safely
let app;
try {
  app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
} catch (err) {
  console.warn('[Firebase] Initializing fallback config:', err);
  app = initializeApp(firebaseConfig, 'BD_BLOOD_APP');
}

export const auth = getAuth(app);
export const db = getFirestore(app);
let storageInstance = null;
try {
  storageInstance = getStorage(app);
} catch (e) {
  console.warn('[Firebase Storage] Storage initialization notice:', e);
}
export const storage = storageInstance;

// Configure persistent login using Firebase Auth persistence
try {
  setPersistence(auth, browserLocalPersistence).catch((err) => {
    console.warn('[Firebase Auth] Persistence set notice:', err.message);
  });
} catch (err) {
  console.warn('[Firebase Auth] Persistence error:', err);
}

export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

export {
  app,
  // Auth methods
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  sendPasswordResetEmail,
  signOut,
  onAuthStateChanged,
  updateProfile,
  // Firestore methods
  collection,
  doc,
  getDoc,
  setDoc,
  addDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  getDocs,
  onSnapshot,
  serverTimestamp,
  increment,
  arrayUnion,
  arrayRemove,
  // Storage methods
  storageRef,
  uploadBytes,
  getDownloadURL
};
