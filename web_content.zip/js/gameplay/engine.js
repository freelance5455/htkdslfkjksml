/* Engine gameplay murni (tanpa DOM). Waktu = detik game (s.t), hanya maju saat tick() dipanggil,
   sehingga semua timer otomatis sadar-pause. Event dikumpulkan di s.events untuk UI/audio/statistik. */
(function (g) {
  'use strict';
  const SU = g.SU, C = SU.config, U = SU.util;

  const FOODS = [
    { id: 'tomat', p: 1, w: 0.25, mv: 0, rare: 0 }, { id: 'wortel', p: 1, w: 0.20, mv: 0, rare: 0 },
    { id: 'apel', p: 2, w: 0.15, mv: 1, rare: 0 }, { id: 'jeruk', p: 2, w: 0.10, mv: 0, rare: 0 },
    { id: 'ceri', p: 3, w: 0.08, mv: 0, rare: 1 }, { id: 'stroberi', p: 3, w: 0.05, mv: 1, rare: 1 },
    { id: 'kebab', p: 4, w: 0.03, mv: 0, rare: 1 }, { id: 'kari', p: 4, w: 0.02, mv: 1, rare: 1 },
    { id: 'berlian', p: 5, w: 0.005, mv: 0, rare: 1 }, { id: 'cabai', p: 5, w: 0.005, mv: 1, rare: 1 }
  ];
  const FOOD_COLOR = { 1: '#e74c3c', 2: '#e67e22', 3: '#e84393', 4: '#8e44ad', 5: '#00b8d4' };
  const POWERS = {
    speed: { dur: 5, color: '#f39c12', tag: 'S', name: 'Speed' },
    shield: { dur: 8, color: '#3498db', tag: 'P', name: 'Perisai' },
    slow: { dur: 6, color: '#9b59b6', tag: 'L', name: 'Slow' },
    double: { dur: 10, color: '#2ecc71', tag: '2x', name: '2× Skor' },
    ghost: { dur: 5, color: '#99ccff', tag: 'G', name: 'Hantu' },
    magnet: { dur: 8, color: '#f368e0', tag: 'M', name: 'Magnet' }
  };
  const PROB = { box: 0.015, slow: 0.005, ice: 0.005, portal: 0.003, coin: 0.005, meteor: 0.002, power: 0.05 };
  const DIRS = [{ x: 1, y: 0 }, { x: -1, y: 0 }, { x: 0, y: 1 }, { x: 0, y: -1 }];

  const same = function (a, b) { return !!a && !!b && a.x === b.x && a.y === b.y; };
  const ev = function (s, type, d) { const e = d || {}; e.type = type; if (s.events.length < 200) s.events.push(e); };
  const on = function (s, k) { return s.active[k] > s.t; };
  const inZone = function (z, c) { return !!z && c.x >= z.x && c.x < z.x + z.size && c.y >= z.y && c.y < z.y + z.size; };

  function create(opts) {
    opts = opts || {};
    const s = {
      rng: opts.rng || Math.random, grid: C.GRID0, snake: [], dir: { x: 1, y: 0 }, queue: [],
      score: 0, lives: 3, extraUsed: false, t: 0, acc: 0, food: null, powerUps: [], active: {},
      box: null, slowZone: null, ice: [], portal: null, coin: null, meteor: null, bombs: [], shadow: null,
      combo: 0, maxCombo: 0, comboUntil: 0, fury: 0, furyAt: 0, mirror: false, mirrorT: C.MIRROR_EVERY,
      dash: 0, dashCd: 0, slideUntil: 0, lastGrid: 0, stats: { food: 0, powerups: 0 }, events: []
    };
    respawn(s);
    return s;
  }

  function occupied(s) {
    const o = new Set(), add = function (c) { if (c) o.add(c.x + ',' + c.y); };
    s.snake.forEach(add); add(s.food); s.powerUps.forEach(add); add(s.box); add(s.coin); add(s.meteor);
    add(s.shadow); s.ice.forEach(add); s.bombs.forEach(add);
    if (s.portal) { add(s.portal.entry); add(s.portal.exit); }
    if (s.slowZone) for (let dy = 0; dy < s.slowZone.size; dy++) for (let dx = 0; dx < s.slowZone.size; dx++) add({ x: s.slowZone.x + dx, y: s.slowZone.y + dy });
    return o;
  }
  function freeCells(s) {
    const o = occupied(s), f = [];
    for (let y = 0; y < s.grid; y++) for (let x = 0; x < s.grid; x++) if (!o.has(x + ',' + y)) f.push({ x: x, y: y });
    return f;
  }
  function emptyCell(s) {
    const f = freeCells(s);
    return f.length ? f[Math.floor(s.rng() * f.length)] : null;
  }

  function spawnFood(s) {
    let tot = 0; FOODS.forEach(function (f) { tot += f.w; });
    let r = s.rng() * tot, pick = FOODS[0];
    for (let i = 0; i < FOODS.length; i++) { r -= FOODS[i].w; if (r <= 0) { pick = FOODS[i]; break; } }
    const c = emptyCell(s);
    if (!c) { s.food = null; ev(s, 'boardFull'); return null; }
    s.food = { x: c.x, y: c.y, id: pick.id, points: pick.p, moving: !!pick.mv, rare: !!pick.rare, color: FOOD_COLOR[pick.p], mt: 0 };
    return s.food;
  }

  function respawn(s) {
    s.snake = [{ x: Math.floor(s.grid / 2), y: Math.floor(s.grid / 2) }];
    s.dir = { x: 1, y: 0 }; s.queue = []; s.combo = 0; s.acc = 0;
    s.powerUps = []; s.box = null; s.slowZone = null; s.ice = []; s.portal = null; s.coin = null;
    s.meteor = null; s.bombs = []; s.shadow = null; s.food = null; s.slideUntil = 0;
    spawnFood(s);
  }

  function speed(s) {
    let v = Math.min(C.SPEED_MAX, C.SPEED0 + Math.floor(s.score / C.SPEED_EVERY));
    const sp = on(s, 'speed'), sl = on(s, 'slow');
    if (sp && !sl) v = Math.min(C.SPEED_MAX, v + 3); else if (sl && !sp) v = Math.max(C.SPEED_MIN, v - 3); /* keduanya aktif = saling meniadakan */
    if (inZone(s.slowZone, s.snake[0])) v = Math.max(C.SPEED_MIN, v * 0.5);
    if (s.dash > 0) v = C.SPEED_MAX + 5;
    return v;
  }
  const sliding = function (s) { return s.slideUntil > s.t; };

  function setDir(s, x, y) {
    if (sliding(s)) return false;
    if (s.mirror) { x = (-x) | 0; y = (-y) | 0; }
    const last = s.queue.length ? s.queue[s.queue.length - 1] : s.dir;
    if ((x !== 0 && last.x !== 0) || (y !== 0 && last.y !== 0) || s.queue.length >= 2) return false;
    s.queue.push({ x: x, y: y });
    return true;
  }
  function startDash(s) {
    if (s.dash > 0 || s.dashCd > 0) return false;
    s.dash = C.DASH_DUR; ev(s, 'dash'); return true;
  }

  function activate(s, type) {
    const p = POWERS[type]; if (!p) return;
    s.active[type] = s.t + p.dur; s.stats.powerups++;
    ev(s, 'powerup', { power: type });
  }
  function eatFood(s) {
    const f = s.food, mult = (on(s, 'double') || s.fury > 0) ? 2 : 1; /* fury & 2× tidak menumpuk */
    let pts = f.points * mult;
    s.combo++; s.comboUntil = s.t + C.COMBO_WINDOW; s.maxCombo = Math.max(s.maxCombo, s.combo);
    if (s.combo >= C.COMBO_THRESHOLD && s.combo % C.COMBO_THRESHOLD === 0) { pts += C.COMBO_BONUS; ev(s, 'combo', { combo: s.combo, bonus: C.COMBO_BONUS }); }
    s.score += pts; s.stats.food++;
    ev(s, 'eat', { x: f.x, y: f.y, points: pts, rare: f.rare });
    if (s.score >= s.furyAt + C.FURY_SCORE) { s.furyAt = s.score; if (s.fury <= 0) ev(s, 'fury'); s.fury = C.FURY_DUR; }
    if (s.score >= s.lastGrid + C.GRID_EVERY && s.grid < C.GRID_MAX) { s.grid++; s.lastGrid = s.score; ev(s, 'grow'); }
    spawnFood(s);
  }

  function hit(s, cause) {
    ev(s, 'hit', { cause: cause });
    if (on(s, 'shield')) { delete s.active.shield; s.active.ghost = s.t + 1; respawn(s); ev(s, 'shieldBreak'); return 'shield'; }
    s.lives--;
    if (s.lives <= 0) { s.lives = 0; return 'dead'; }
    respawn(s); return 'life';
  }

  function move(s) {
    if (s.queue.length) s.dir = s.queue.shift();
    const o = s.snake[0];
    const head = { x: (o.x + s.dir.x + s.grid) % s.grid, y: (o.y + s.dir.y + s.grid) % s.grid };
    const ate = same(head, s.food);
    s.snake.unshift(head); if (!ate) s.snake.pop();
    if (s.portal) {
      const p = s.portal;
      if (same(head, p.entry)) { head.x = p.exit.x; head.y = p.exit.y; s.portal = null; ev(s, 'portal'); }
      else if (same(head, p.exit)) { head.x = p.entry.x; head.y = p.entry.y; s.portal = null; ev(s, 'portal'); }
    }
    if (ate) eatFood(s);
    if (same(head, s.box)) { const ks = Object.keys(POWERS); activate(s, ks[Math.floor(s.rng() * ks.length)]); s.box = null; ev(s, 'box'); }
    if (same(head, s.coin)) { s.score += 10 * (on(s, 'double') ? 2 : 1); ev(s, 'coin', { x: s.coin.x, y: s.coin.y }); s.coin = null; }
    for (let i = 0; i < s.powerUps.length; i++) if (same(head, s.powerUps[i])) { activate(s, s.powerUps[i].type); s.powerUps.splice(i, 1); break; }
    if (s.ice.some(function (c) { return same(c, head); })) { s.slideUntil = s.t + C.SLIDE_DUR; ev(s, 'ice'); }
    return collide(s);
  }
  function collide(s) {
    const h = s.snake[0];
    if (!on(s, 'ghost')) for (let i = 1; i < s.snake.length; i++) if (same(h, s.snake[i])) return hit(s, 'self');
    for (let i = 0; i < s.bombs.length; i++) if (same(h, s.bombs[i])) { s.bombs.splice(i, 1); return hit(s, 'bomb'); }
    if (same(h, s.meteor)) { ev(s, 'explode', { x: s.meteor.x, y: s.meteor.y }); s.meteor = null; return hit(s, 'meteor'); }
    if (same(h, s.shadow)) return hit(s, 'shadow');
    return null;
  }

  function magnet(s) {
    const f = s.food, h = s.snake[0]; if (!f || !on(s, 'magnet')) return;
    const dx = h.x - f.x, dy = h.y - f.y;
    if (Math.abs(dx) + Math.abs(dy) > 5 || Math.abs(dx) + Math.abs(dy) === 0) return;
    const n = Math.abs(dx) >= Math.abs(dy) ? { x: f.x + Math.sign(dx), y: f.y } : { x: f.x, y: f.y + Math.sign(dy) };
    if (s.snake.some(function (c, i) { return i > 0 && same(c, n); })) return;
    f.x = n.x; f.y = n.y;
    if (same(f, h)) { eatFood(s); }
  }
  function moveShadow(s) {
    const sh = s.shadow; if (!sh) return;
    if (s.rng() < 0.1) sh.dir = DIRS[Math.floor(s.rng() * 4)];
    sh.x = (sh.x + sh.dir.x + s.grid) % s.grid; sh.y = (sh.y + sh.dir.y + s.grid) % s.grid;
  }
  function spawnMisc(s) {
    const r = s.rng;
    if (!s.box && r() < PROB.box) { const c = emptyCell(s); if (c) s.box = { x: c.x, y: c.y, life: 5 }; }
    if (!s.slowZone && r() < PROB.slow) {
      const size = 2 + Math.floor(r() * 2), occ = occupied(s), cands = [];
      for (let y = 0; y + size <= s.grid; y++) for (let x = 0; x + size <= s.grid; x++) {
        let ok = true;
        for (let dy = 0; dy < size && ok; dy++) for (let dx = 0; dx < size; dx++) if (occ.has((x + dx) + ',' + (y + dy))) { ok = false; break; }
        if (ok) cands.push({ x: x, y: y });
      }
      if (cands.length) { const c = cands[Math.floor(r() * cands.length)]; s.slowZone = { x: c.x, y: c.y, size: size, life: C.SLOW_ZONE_DUR }; }
    }
    if (s.ice.length < 5 && r() < PROB.ice) { const c = emptyCell(s); if (c) s.ice.push(c); }
    if (!s.portal && r() < PROB.portal) {
      const f = freeCells(s);
      if (f.length >= 2) { const i = Math.floor(r() * f.length); const a = f.splice(i, 1)[0]; const b = f[Math.floor(r() * f.length)]; s.portal = { entry: a, exit: b }; }
    }
    if (!s.coin && r() < PROB.coin) { const c = emptyCell(s); if (c) s.coin = { x: c.x, y: c.y, life: 5 }; }
    if (!s.meteor && r() < PROB.meteor) { const c = emptyCell(s); if (c) s.meteor = { x: c.x, y: c.y, life: 5 }; }
    if (s.powerUps.length < 2 && r() < PROB.power) {
      const c = emptyCell(s), ks = Object.keys(POWERS);
      if (c) s.powerUps.push({ x: c.x, y: c.y, type: ks[Math.floor(r() * ks.length)], life: 10 });
    }
    if (!s.shadow && s.score >= C.SHADOW_SCORE) { const c = emptyCell(s); if (c) s.shadow = { x: c.x, y: c.y, dir: DIRS[Math.floor(r() * 2)] }; }
  }

  function step(s) {
    const r = move(s); if (r === 'life' || r === 'dead') return r;
    moveShadow(s);
    if (same(s.snake[0], s.shadow)) { const h = hit(s, 'shadow'); if (h === 'life' || h === 'dead') return h; }
    magnet(s); spawnMisc(s);
    return r;
  }

  function timers(s, dt) {
    s.t += dt;
    if (s.fury > 0) { s.fury -= dt; if (s.fury <= 0) { s.fury = 0; ev(s, 'furyEnd'); } }
    s.mirrorT -= dt; if (s.mirrorT <= 0) { s.mirror = !s.mirror; s.mirrorT = C.MIRROR_EVERY; ev(s, 'mirror', { on: s.mirror }); }
    if (s.dash > 0) { s.dash -= dt; if (s.dash <= 0) { s.dash = 0; s.dashCd = C.DASH_CD; } }
    else if (s.dashCd > 0) s.dashCd = Math.max(0, s.dashCd - dt);
    if (s.combo > 0 && s.t > s.comboUntil) s.combo = 0;
    if (s.food && s.food.moving) {
      s.food.mt += dt;
      if (s.food.mt >= 1) {
        s.food.mt = 0; const d = DIRS[Math.floor(s.rng() * 4)];
        const n = { x: (s.food.x + d.x + s.grid) % s.grid, y: (s.food.y + d.y + s.grid) % s.grid };
        if (!s.snake.some(function (c) { return same(c, n); })) { s.food.x = n.x; s.food.y = n.y; }
      }
    }
    ['box', 'coin', 'meteor'].forEach(function (k) {
      if (s[k]) { s[k].life -= dt; if (s[k].life <= 0) { if (k === 'meteor') ev(s, 'explode', { x: s.meteor.x, y: s.meteor.y }); s[k] = null; } }
    });
    if (s.slowZone) { s.slowZone.life -= dt; if (s.slowZone.life <= 0) s.slowZone = null; }
    s.powerUps = s.powerUps.filter(function (p) { p.life -= dt; return p.life > 0; });
    Object.keys(s.active).forEach(function (k) { if (s.active[k] <= s.t) { delete s.active[k]; ev(s, 'expire', { power: k }); } });
  }

  /* Satu pemanggilan = satu frame. Mengembalikan 'life' | 'dead' | null. */
  function tick(s, dt) {
    dt = Math.max(0, Math.min(dt, C.MAX_DT));
    timers(s, dt);
    s.acc += dt;
    let steps = 0, res = null;
    while (steps < C.MAX_STEPS) {
      const iv = 1 / speed(s);
      if (s.acc < iv) break;
      s.acc -= iv; steps++;
      const r = step(s);
      if (r === 'life' || r === 'dead') { res = r; s.acc = 0; break; }
    }
    if (s.acc > 1 / speed(s)) s.acc = 0; /* buang sisa catch-up berlebih */
    return res;
  }

  function grantExtraLife(s) {
    s.extraUsed = true; s.lives = 1; s.score = 0; s.lastGrid = 0; s.furyAt = 0;
    s.active = {}; s.fury = 0; s.mirror = false; s.mirrorT = C.MIRROR_EVERY; s.dash = 0; s.dashCd = 0; s.combo = 0;
    respawn(s);
  }

  /* ---- Save: snapshot, validasi, migrasi data lama ---- */
  function snapshot(s) {
    const o = {};
    Object.keys(s).forEach(function (k) { if (k !== 'rng' && k !== 'events') o[k] = s[k]; });
    return JSON.parse(JSON.stringify(o));
  }
  const okCell = function (c, g2) { return !!c && Number.isInteger(c.x) && Number.isInteger(c.y) && c.x >= 0 && c.y >= 0 && c.x < g2 && c.y < g2; };
  function validate(d) {
    const e = [];
    if (!d || typeof d !== 'object') return { ok: false, errors: ['data bukan objek'] };
    if (!Number.isInteger(d.grid) || d.grid < 10 || d.grid > C.GRID_MAX) e.push('grid');
    const g2 = d.grid;
    if (!Array.isArray(d.snake) || !d.snake.length || d.snake.length > g2 * g2 || !d.snake.every(function (c) { return okCell(c, g2); })) e.push('snake');
    if (!d.dir || Math.abs(d.dir.x) + Math.abs(d.dir.y) !== 1) e.push('dir');
    if (!Number.isInteger(d.score) || d.score < 0 || d.score > 1e7) e.push('score');
    if (!Number.isInteger(d.lives) || d.lives < 1 || d.lives > 3) e.push('lives');
    if (!U.isNum(d.t, 0, 1e9)) e.push('t');
    if (d.food !== null && !okCell(d.food, g2)) e.push('food');
    if (!d.active || typeof d.active !== 'object') e.push('active');
    else Object.keys(d.active).forEach(function (k) { if (!POWERS[k] || !U.isNum(d.active[k], 0, 1e9)) e.push('active.' + k); });
    return { ok: e.length === 0, errors: e };
  }
  function restore(data, rng) {
    const v = validate(data); if (!v.ok) return v;
    const s = create({ rng: rng });
    Object.keys(data).forEach(function (k) { if (k !== 'rng' && k !== 'events') s[k] = data[k]; });
    const g2 = s.grid, cellOrNull = function (c) { return okCell(c, g2) ? c : null; };
    s.box = cellOrNull(s.box); s.coin = cellOrNull(s.coin); s.meteor = cellOrNull(s.meteor);
    s.shadow = okCell(s.shadow, g2) && s.shadow.dir ? s.shadow : null;
    s.ice = (s.ice || []).filter(function (c) { return okCell(c, g2); });
    s.bombs = (s.bombs || []).filter(function (c) { return okCell(c, g2); });
    s.powerUps = (s.powerUps || []).filter(function (c) { return okCell(c, g2) && POWERS[c.type]; });
    s.portal = s.portal && okCell(s.portal.entry, g2) && okCell(s.portal.exit, g2) ? s.portal : null;
    s.slowZone = s.slowZone && okCell(s.slowZone, g2) && s.slowZone.size >= 2 ? s.slowZone : null;
    s.queue = []; s.events = []; s.acc = 0; s.rng = rng || Math.random;
    s.stats = s.stats || { food: 0, powerups: 0 };
    return { ok: true, session: s, errors: [] };
  }
  /* Format lama (snakeSaveGame, v2): power-up memakai Date.now() sehingga tidak bisa dipulihkan -> dibuang. */
  function fromLegacy(old, rng) {
    if (!old || typeof old !== 'object') return { ok: false, errors: ['data lama bukan objek'] };
    const cell = function (c) { return c && typeof c.x === 'number' ? { x: c.x, y: c.y } : null; };
    const pts = old.food && old.food.points;
    const d = {
      grid: old.gridSize || C.GRID0, snake: old.snake, dir: old.direction, score: old.score, lives: old.lives, t: 0,
      food: old.food ? { x: old.food.x, y: old.food.y, id: 'lama', points: pts || 1, moving: !!old.food.isMoving, rare: false, color: FOOD_COLOR[pts] || FOOD_COLOR[1], mt: 0 } : null,
      active: {}, powerUps: (old.powerUps || []).map(function (p) { return { x: p.x, y: p.y, type: p.type, life: Math.max(1, p.life || 5) }; }),
      box: cell(old.randomBox) && Object.assign(cell(old.randomBox), { life: 5 }), coin: cell(old.coin) && Object.assign(cell(old.coin), { life: 5 }),
      meteor: cell(old.meteor) && Object.assign(cell(old.meteor), { life: 5 }), ice: (old.icePatches || []).map(cell).filter(Boolean),
      portal: old.portal && old.portal.entry ? { entry: cell(old.portal.entry), exit: cell(old.portal.exit) } : null,
      slowZone: old.slowZone ? { x: old.slowZone.x, y: old.slowZone.y, size: old.slowZone.size, life: C.SLOW_ZONE_DUR } : null,
      shadow: old.shadowSnake ? { x: old.shadowSnake.x, y: old.shadowSnake.y, dir: old.shadowSnake.dir || { x: 1, y: 0 } } : null,
      combo: 0, maxCombo: old.maxCombo || 0, extraUsed: !!old.extraLifeUsed, lastGrid: old.lastGridIncreaseScore || 0,
      mirror: !!old.isMirrorMode, mirrorT: old.mirrorModeTimer > 0 ? old.mirrorModeTimer : C.MIRROR_EVERY
    };
    return restore(d, rng);
  }

  SU.engine = {
    FOODS: FOODS, POWERS: POWERS, create: create, tick: tick, step: step, setDir: setDir, startDash: startDash,
    speed: speed, sliding: sliding, emptyCell: emptyCell, spawnFood: spawnFood, respawn: respawn, activate: activate,
    grantExtraLife: grantExtraLife, snapshot: snapshot, validate: validate, restore: restore, fromLegacy: fromLegacy,
    isActive: on
  };
})(typeof window !== 'undefined' ? window : globalThis);
