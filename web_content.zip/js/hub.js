
'use strict';
(function(){
 const buttons=[...document.querySelectorAll('[data-hub]')];
 function show(name){
  for(const b of buttons){
   const active=b.dataset.hub===name;
   b.setAttribute('aria-selected',String(active));
   const panel=document.getElementById('hub-'+b.dataset.hub);
   if(panel)panel.hidden=!active;
  }
 }
 buttons.forEach(b=>b.addEventListener('click',()=>show(b.dataset.hub)));
 show('shop');
})();
