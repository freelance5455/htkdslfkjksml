// =====================================================
// NetEarn Pro Referral System V4
// Users Based Referral System
// Dashboard + Team Compatible
// =====================================================

import { auth, db } from "./firebase.js";
import {
    doc,
    getDoc,
    collection,
    query,
    where,
    getDocs,
    onSnapshot,
    increment,
    runTransaction,
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";


// =====================================================
// ELEMENTS
// =====================================================

const referralInput =
    document.getElementById("referralInput");

const useReferralBtn =
    document.getElementById("useReferralBtn");

const copyBtn =
    document.getElementById("copyBtn");

const shareBtn =
    document.getElementById("shareBtn");

const userIdElement =
    document.getElementById("userId");

const referralCodeElement =
    document.getElementById("referralCode");

const totalReferralElement =
    document.getElementById("totalReferral");

const refIncomeElement =
    document.getElementById("refIncome");


// =====================================================
// LOAD CURRENT USER REFERRAL DATA
// =====================================================

async function loadReferralData() {

    const user = auth.currentUser;

    if (!user) {
        return;
    }

    try {

        const userRef =
            doc(
                db,
                "users",
                user.uid
            );

        const snap =
            await getDoc(userRef);

        if (!snap.exists()) {
            return;
        }

        const data =
            snap.data();

        // -----------------------------
        // User ID
        // -----------------------------

        if (userIdElement) {

            userIdElement.textContent =
                data.userId ||
                "NE00000";

        }

        // -----------------------------
        // Referral Code
        // -----------------------------

        if (referralCodeElement) {

            referralCodeElement.textContent =
                data.referralCode ||
                "NET00000";

        }

        // -----------------------------
        // Total Referral — live Firestore count
        // -----------------------------
        // Count actual members whose referrerCode is this user's
        // referralCode. This keeps the displayed total accurate even
        // when the cached totalReferrals field is stale/missing.
        if (totalReferralElement) {
            // Render the stored count immediately so the page never waits
            // for the first live snapshot before showing a value.
            const initialReferralCount = Number(
                data.totalReferrals ?? data.referralCount ?? 0
            );
            totalReferralElement.textContent = String(
                Number.isFinite(initialReferralCount) ? initialReferralCount : 0
            );

            const myReferralCode = String(data.referralCode || "").trim();

            if (myReferralCode) {
                const referralsQuery = query(
                    collection(db, "users"),
                    where("referrerCode", "==", myReferralCode)
                );

                onSnapshot(
                    referralsQuery,
                    (referralsSnap) => {
                        totalReferralElement.textContent =
                            String(referralsSnap.size);
                    },
                    (error) => {
                        console.warn(
                            "Live referral count listener failed:",
                            error
                        );
                        totalReferralElement.textContent =
                            String(Number(data.totalReferrals || 0));
                    }
                );
            } else {
                totalReferralElement.textContent =
                    String(Number(data.totalReferrals || 0));
            }
        }

        // -----------------------------
        // Referral Income
        // -----------------------------

        if (refIncomeElement) {

            refIncomeElement.textContent =
                "৳" +
                Number(
                    data.referralCommission ||
                    0
                );

        }

    }

    catch (error) {

        console.error(
            "Referral Data Load Error:",
            error
        );

    }

}


// =====================================================
// USE REFERRAL CODE
// =====================================================

if (useReferralBtn) {

    useReferralBtn.addEventListener(
        "click",
        async () => {

            const code =
                referralInput?.value
                    .trim()
                    .toUpperCase();

            if (!code) {

                alert(
                    "Please enter referral code"
                );

                return;

            }


            const user =
                auth.currentUser;

            if (!user) {

                alert(
                    "Please login first"
                );

                return;

            }


            try {

                // =================================================
                // CURRENT USER
                // =================================================

                const myRef =
                    doc(
                        db,
                        "users",
                        user.uid
                    );

                // The current-user check and referrer lookup are
                // independent until the atomic transaction, so start
                // both Firebase reads together.
                const referralsQuery =
                    query(
                        collection(
                            db,
                            "users"
                        ),
                        where(
                            "referralCode",
                            "==",
                            code
                        )
                    );

                const [mySnap, snap] =
                    await Promise.all([
                        getDoc(myRef),
                        getDocs(referralsQuery)
                    ]);

                if (!mySnap.exists()) {

                    alert(
                        "User data not found"
                    );

                    return;

                }

                const myData =
                    mySnap.data();


                // =================================================
                // ALREADY REFERRED
                // =================================================

                if (
                    myData.referrerCode ||
                    myData.referredBy
                ) {

                    alert(
                        "❌ Referral Code already used."
                    );

                    return;

                }


                // =================================================
                // FIND REFERRER
                // =================================================

                if (snap.empty) {

                    alert(
                        "❌ Invalid Referral Code"
                    );

                    return;

                }


                const refUser =
                    snap.docs[0];

                const refUid =
                    refUser.id;

                const refData =
                    refUser.data();


                // =================================================
                // SELF REFERRAL
                // =================================================

                if (
                    refUid ===
                    user.uid
                ) {

                    alert(
                        "❌ নিজের Referral Code ব্যবহার করা যাবে না"
                    );

                    return;

                }


                // =================================================
                // SAVE RELATIONSHIP + COUNT ATOMICALLY
                //
                // This prevents two simultaneous submissions from
                // attaching the same member twice. No money is paid here.
                // The authoritative reward is issued once at Premium approval.
                // =================================================

                await runTransaction(db, async transaction => {
                    const latestUserSnap = await transaction.get(myRef);
                    const latestReferrerRef = doc(db, "users", refUid);
                    const latestReferrerSnap = await transaction.get(latestReferrerRef);

                    if (!latestUserSnap.exists()) {
                        throw new Error("User data not found");
                    }

                    if (!latestReferrerSnap.exists()) {
                        throw new Error("Referral owner not found");
                    }

                    const latestData = latestUserSnap.data() || {};
                    if (latestData.referrerCode || latestData.referredBy) {
                        throw new Error("Referral Code already used.");
                    }

                    transaction.update(myRef, {
                        referrerCode: code,
                        referredBy: code,
                        referrerUid: refUid
                    });

                    transaction.update(latestReferrerRef, {
                        totalReferrals: increment(1)
                    });
                });

                // =================================================
                // SUCCESS
                // =================================================

                await alert(
                    "✅ Referral Successful!\n\n" +
                    "Referral relationship saved successfully.\n\n" +
                    "💰 Referral Bonus will be added after the referred member's Premium approval."
                );


                location.reload();

            }

            catch (error) {

                console.error(
                    "Referral Error:",
                    error
                );

                alert(
                    "❌ " +
                    (
                        error.message ||
                        "Referral failed"
                    )
                );

            }

        }
    );

}


// =====================================================
// COPY REFERRAL CODE
// =====================================================

if (copyBtn) {

    copyBtn.addEventListener(
        "click",
        async () => {

            const code =
                referralCodeElement?.textContent
                    ?.trim();

            if (!code) {

                alert(
                    "Referral Code পাওয়া যায়নি।"
                );

                return;

            }

            try {

                await navigator.clipboard.writeText(
                    code
                );

                alert(
                    "✅ Referral Code Copied"
                );

            }

            catch (error) {

                console.error(
                    "Copy Error:",
                    error
                );

                alert(
                    "❌ Copy Failed"
                );

            }

        }
    );

}


// =====================================================
// SHARE / INVITE
// =====================================================

if (shareBtn) {

    shareBtn.addEventListener(
        "click",
        async () => {

            const code =
                referralCodeElement?.textContent
                    ?.trim();

            if (!code) {

                alert(
                    "Referral Code পাওয়া যায়নি।"
                );

                return;

            }


            const text =
`Join NetEarn Pro 🚀

আমার Referral Code:
${code}

NetEarn Pro-তে join করে আমার referral code ব্যবহার করুন।`;


            try {

                if (
                    navigator.share
                ) {

                    await navigator.share({

                        title:
                            "Join NetEarn Pro",

                        text:
                            text

                    });

                }

                else if (
                    navigator.clipboard
                ) {

                    await navigator.clipboard.writeText(
                        text
                    );

                    alert(
                        "✅ Invite message copied"
                    );

                }

                else {

                    alert(
                        text
                    );

                }

            }

            catch (error) {

                if (
                    error?.name ===
                    "AbortError"
                ) {

                    return;

                }

                console.error(
                    "Share Error:",
                    error
                );

            }

        }
    );

}


// =====================================================
// AUTH → LOAD DATA
// =====================================================

auth.onAuthStateChanged(
    async user => {

        if (!user) {
            return;
        }

        await loadReferralData();

    }
);


// =====================================================
// READY
// =====================================================

console.log(
    "✅ NetEarn Pro Referral System V4 Loaded"
);