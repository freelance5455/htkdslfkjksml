"use strict";

const WinUI = (() => {
  const ICONS = { town: "🏛️", mafia: "🔪", lone_killer: "🗡️", clown: "🤡", none: "🕯️" };

  const $ = (id) => document.getElementById(id);

  function show() {
    const result = Game.getResult();
    if (!result) {
      UI.toast("لا توجد نتيجة بعد");
      return;
    }
    document.body.classList.remove("is-night");
    $("win-icon").textContent = ICONS[result.winner] || "🏆";
    $("win-title").textContent = result.title;
    $("win-text").textContent = result.text;

    const roster = $("win-roster");
    roster.innerHTML = "";
    result.roster.forEach((p) => {
      const role = Roles.get(p.roleId);
      const row = document.createElement("div");
      row.className = "roster-row";
      if (p.winner) row.classList.add("win");
      if (!p.alive) row.classList.add("dead");

      const name = document.createElement("span");
      name.className = "roster-name";
      name.textContent = (p.winner ? "🏆 " : "") + p.name;

      const roleBox = document.createElement("span");
      roleBox.textContent = `${role.icon} ${role.name}`;

      const status = document.createElement("small");
      status.textContent = p.alive ? "حي" : "ميت";

      row.append(name, roleBox, status);
      roster.appendChild(row);
    });
    UI.showScreen("win");
  }

  function onReplay() {
    const res = Game.replay();
    if (!res.ok) {
      UI.toast(res.error || "تعذرت إعادة اللعب");
      return;
    }
    Reveal.start();
  }

  function init() {
    $("btn-win-replay").addEventListener("click", onReplay);
  }

  return { init, show };
})();