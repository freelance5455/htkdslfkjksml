/*
 * NetEarn Pro — Universal Instant User Cache
 * Cache-first sessionStorage + silent Firestore refresh.
 * This file is intentionally dependency-light and safe on every page.
 */
import { auth, db } from "./firebase.js";
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";
import { doc, getDoc } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";

(() => {
  "use strict";

  if (window.__NetEarnInstantUserCache) return;
  window.__NetEarnInstantUserCache = true;

  const USER_CACHE_KEY = "netearnUserSessionCache";
  const PROFILE_CACHE_KEY = "netearnProfileCache";
  const CACHE_VERSION = 2;
  const REFRESH_AFTER_MS = 15 * 1000;
  let refreshInFlight = false;

  const FIELD_MAP = {
    menuUserName: ["username", "name"],
    userName: ["username", "name"],
    userNameText: ["username", "name"],
    nameText: ["name", "username"],
    fullName: ["name", "username"],
    settingsUserName: ["username", "name"],
    menuUserId: ["userId"],
    userId: ["userId"],
    userid: ["userId"],
    settingsUserId: ["userId"],
    dashboardBalance: ["creditBalance", "mainBalance", "balance"],
    creditBalance: ["creditBalance"],
    mainBalance: ["mainBalance", "balance"],
    availableBalance: ["mainBalance", "balance", "creditBalance"],
    totalIncome: ["totalIncome", "income", "totalTaskIncome"],
    todayIncome: ["todayIncome"],
    yesterdayIncome: ["yesterdayIncome"],
    weeklyIncome: ["weeklyIncome"],
    monthlyIncome: ["monthlyIncome"],
    refIncome: ["referralIncome", "refIncome"],
    totalReward: ["rewardBalance", "totalReward"],
    totalReferral: ["totalReferrals", "referralCount"],
    dashboardReferralTotal: ["totalReferrals", "referralCount"],
    dashboardReferrals: ["totalReferrals", "referralCount"],
    dashboardReferralIncome: ["referralIncome", "refIncome"],
    dashboardReferralCode: ["referralCode", "myReferralCode"],
    referralCode: ["referralCode", "myReferralCode"]
  };

  function read(key) {
    try {
      const raw = sessionStorage.getItem(key);
      return raw ? JSON.parse(raw) : null;
    } catch (_) {
      return null;
    }
  }

  function write(key, value) {
    try {
      sessionStorage.setItem(key, JSON.stringify(value));
    } catch (_) {}
  }

  function getCached(uid) {
    const a = read(USER_CACHE_KEY);
    if (a?.uid === uid && a?.data) return a;

    const b = read(PROFILE_CACHE_KEY);
    if (b?.uid === uid && b?.data) {
      return {
        uid,
        data: b.data,
        savedAt: Number(b.cachedAt || 0),
        version: CACHE_VERSION
      };
    }
    return null;
  }

  function money(value) {
    const n = Number(value);
    if (!Number.isFinite(n)) return "0";
    return n.toLocaleString("en-BD", {
      minimumFractionDigits: 0,
      maximumFractionDigits: 2
    });
  }

  function paint(el, value, id) {
    if (value === undefined || value === null) return;

    if (/balance|income|reward|refincome/i.test(id)) {
      el.textContent = `৳${money(value)}`;
    } else if (/totalreferral|dashboardreferrals/i.test(id)) {
      el.textContent = String(Number(value) || 0);
    } else {
      el.textContent = String(value);
    }
  }

  function render(data) {
    if (!data || typeof data !== "object") return;

    for (const [id, candidates] of Object.entries(FIELD_MAP)) {
      const el = document.getElementById(id);
      if (!el) continue;

      let value;
      for (const key of candidates) {
        if (data[key] !== undefined && data[key] !== null) {
          value = data[key];
          break;
        }
      }
      paint(el, value, id);
    }

    document.querySelectorAll("[data-ne-cache]").forEach(el => {
      const key = el.getAttribute("data-ne-cache");
      if (key && data[key] !== undefined && data[key] !== null) {
        paint(el, data[key], key);
      }
    });

    const image = document.getElementById("profileImage") ||
      document.getElementById("settingsProfileImage");
    const photo = data.photoURL || data.photo;
    if (image && photo) image.src = photo;

    window.dispatchEvent(new CustomEvent("netearn:user-cache-ready", {
      detail: { data }
    }));
  }

  function save(uid, data) {
    const snapshot = {
      uid,
      data,
      savedAt: Date.now(),
      version: CACHE_VERSION
    };
    write(USER_CACHE_KEY, snapshot);
    write(PROFILE_CACHE_KEY, {
      uid,
      data,
      photo: data.photoURL || data.photo || null,
      cachedAt: snapshot.savedAt,
      version: CACHE_VERSION
    });
  }

  async function refresh(uid) {
    if (!uid || refreshInFlight) return;
    refreshInFlight = true;

    try {
      const snap = await getDoc(doc(db, "users", uid));
      if (!snap.exists()) return;

      const data = snap.data();
      save(uid, data);
      render(data);

      window.dispatchEvent(new CustomEvent("netearn:user-data-refreshed", {
        detail: { uid, data }
      }));
    } catch (error) {
      console.warn("NetEarn background user refresh skipped:", error);
    } finally {
      refreshInFlight = false;
    }
  }

  function start(user) {
    if (!user) return;

    const cached = getCached(user.uid);

    // Paint from memory/sessionStorage immediately.
    if (cached?.data) render(cached.data);

    // Never block navigation for Firebase.
    const age = Date.now() - Number(cached?.savedAt || 0);
    if (!cached || age > REFRESH_AFTER_MS) {
      void refresh(user.uid);
    }
  }

  // Auth may already be restored from Firebase Auth persistence.
  if (auth.currentUser) start(auth.currentUser);

  onAuthStateChanged(auth, start);
})();
