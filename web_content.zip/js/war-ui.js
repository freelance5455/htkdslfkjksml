/* war-ui.js — Phase 3 interface: war/ceasefire buttons, fortification & occupation info, battle notifications, game over. */
(function (G) {
  'use strict';
  const $ = id => document.getElementById(id);

  /* ---------- country tab: relations and war actions ---------- */
  G.countryWarHtml = function (oid) {
    const st = G.state, me = st.player;
    const wars = G.warsOf(oid).map(x => G.COUNTRIES[x].name);
    let h = '<div class="chips"><span style="font-size:12px;color:var(--dim);align-self:center">' +
      (wars.length ? '⚔ At war with: <b style="color:#ff9a8a">' + wars.join(', ') + '</b>' : '☮ At peace') + '</span></div>';
    if (st.countries[oid].dead) return h + '<div class="chips"><span class="tag">ELIMINATED</span></div>';
    if (oid !== me) {
      if (G.atWar(me, oid)) h += '<div class="chips"><button id="w-peace">🕊 Peace talks</button><button id="w-dip">🤝 Diplomacy</button></div>';
      else {
        const t = (st.truce[oid < me ? oid + '|' + me : me + '|' + oid] || 0) - st.day;
        h += '<div class="chips"><button id="w-dip">🤝 Diplomacy</button><button id="w-war" class="danger"' + (t > 0 ? ' disabled' : '') + '>⚔ Declare war on ' + G.COUNTRIES[oid].name + (t > 0 ? ' (truce ' + t + 'd)' : '') + '</button></div>';
      }
    }
    return h;
  };
  G.bindCountryWar = function (oid) {
    const me = G.state.player;
    const w = $('w-war');
    if (w) w.onclick = () => G.confirmBox('Declare war on ' + G.COUNTRIES[oid].name + '?', '⚔ Declare war', () => {
      const r = G.declareWar(me, oid);
      G.toast(r.ok ? 'War declared on ' + G.COUNTRIES[oid].name : r.msg);
      G.refreshPanel(); G.updateTopBar(); G.requestDraw();
    });
    const p = $('w-peace');
    if (p) p.onclick = () => G.showPeace(oid);
    const d = $('w-dip');
    if (d) d.onclick = () => G.showDiplomacy('nation', oid);
  };

  /* ---------- province panel: fortification, occupation, battle ---------- */
  G.provinceWarHtml = function (prov) {
    const st = G.state, p = G.provinces[prov], o = st.owners[prov];
    let h = '';
    const b = G.battleAt(prov);
    if (b) h += '<div class="alert">⚔ Battle in progress — ' + b.att.map(a => a.name).join(', ') + ' attacking</div>';
    const occ = st.occ && st.occ[prov];
    if (occ) h += '<div class="alert">🚩 Occupied by ' + G.COUNTRIES[occ.by].name + ': ' + occ.days + ' / ' + G.occupationNeed(prov) + ' days</div>';
    const fq = (st.fortQ || []).find(f => f.prov === prov);
    if (fq) h += '<div class="alert ok">🏗 Fortification under construction — ' + fq.left + ' days left</div>';
    if (o !== st.player && !st.countries[o].dead) {
      if (G.atWar(st.player, o)) h += '<div class="alert">⚔ At war with ' + G.COUNTRIES[o].name + '</div>';
      else h += '<div class="chips"><button id="pv-war" class="danger">⚔ Declare war on ' + G.COUNTRIES[o].name + '</button></div>';
    }
    if (o === st.player) {
      const c = G.canBuildFort(o, prov);
      h += '<div class="chips"><button id="pv-fort"' + (c.ok ? '' : ' disabled') + '>🏰 ' + (c.ok ? 'Build fort lvl ' + (p.fort + 1) + ' (💰 ' + G.fortCost(prov) + ', ' + G.fortDays(prov) + 'd)' : c.msg) + '</button></div>';
    }
    return h;
  };
  G.bindProvinceWar = function (prov) {
    const wb = $('pv-war');
    if (wb) wb.onclick = () => {
      const oid = G.state.owners[prov];
      G.confirmBox('Declare war on ' + G.COUNTRIES[oid].name + '?', '⚔ Declare war', () => {
        const r = G.declareWar(G.state.player, oid);
        G.toast(r.ok ? 'War declared on ' + G.COUNTRIES[oid].name : r.msg);
        G.refreshPanel(); G.updateTopBar(); G.requestDraw();
      });
    };
    const b = $('pv-fort');
    if (b) b.onclick = () => {
      const r = G.buildFort(G.state.player, prov);
      G.toast(r.ok ? 'Fortification started (' + r.days + ' days)' : r.msg);
      G.updateTopBar(); G.refreshPanel();
    };
  };

  /* ---------- notifications ---------- */
  G.onBattleEnd = function (prov, winner, loser, rep) {
    const me = G.state.player, won = winner === me;
    G.toast((won ? '✅ Victory at ' : '❌ Defeat at ') + G.provinces[prov].name);
    G.refreshPanel(); G.requestDraw();
  };
  G.onCapture = function (prov, by, old, wasCap) {
    const me = G.state.player;
    if (by === me) G.toast('🚩 ' + G.provinces[prov].name + ' conquered' + (wasCap ? ' — enemy capital captured!' : ''));
    else if (old === me) { G.toast('⚠ ' + G.provinces[prov].name + ' has been lost' + (wasCap ? ' — your CAPITAL has fallen!' : '')); if (wasCap) { G.setPaused(true); } }
    G.updateTopBar(); G.refreshPanel(); G.requestDraw();
  };
  G.onWarChange = function (a, b, start) {
    const me = G.state.player;
    if ((a === me || b === me) && !start) G.toast('Ceasefire — armies withdraw to their own borders');
    if (start && b === me) { G.toast('⚔ ' + G.COUNTRIES[a].name + ' declared war on you!'); G.setPaused(true); }
    else if (start && a !== me && G.allied(a, me)) G.toast('⚔ Your ally ' + G.COUNTRIES[a].name + ' is at war with ' + G.COUNTRIES[b].name);
    G.updateTopBar(); G.requestDraw();
  };
  G.onPlayerDefeated = function (by) {
    G.setPaused(true);
    const box = $('modal-box');
    box.innerHTML = '<h1>DEFEAT</h1><div class="tagline">' + G.COUNTRIES[G.state.player].name + ' has been eliminated by ' + G.COUNTRIES[by].name + '.</div>' +
      '<div class="row"><button class="primary" id="df-menu">Back to nation select</button></div>';
    $('modal').classList.remove('hidden');
    $('df-menu').onclick = () => { G.state.player = null; G.showStart(); };
  };

  /* ---------- top bar war badge ---------- */
  G.warBadge = function () {
    const n = G.warsOf(G.state.player).length;
    const el = $('tb-war'); if (!el) return;
    el.textContent = n ? '⚔ ' + n : ''; el.style.display = n ? '' : 'none';
    G.dipBadge && G.dipBadge();
  };
})(window.EMP = window.EMP || {});
