// Adaptación de la pose al terreno: pies pegados al suelo en cuestas y escalones, pelvis que baja lo justo y cuerpo que se
// inclina un poco hacia la cuesta. Se aplica DESPUÉS del animador, sobre la pose ya calculada, y no cambia la marcha en llano.
//
//  · terreno: función sample(x, z) → altura del suelo en (x, z) relativa a la del personaje, en las mismas unidades del
//    esqueleto, con x hacia la izquierda del personaje y z hacia delante (marco del rig).
//  · piernas: IK analítico de dos huesos (el mismo de la marcha). El pie va a donde estaba más la altura del suelo bajo él; la
//    rodilla conserva el lado hacia el que ya se doblaba. Solo se aplica la diferencia respecto a la pose original.
//  · pelvis: baja lo que haga falta para que el pie que pisa más abajo siga alcanzando el suelo (nunca sube).
//  · pie: se inclina con la normal del terreno solo mientras está apoyado.
//  · inclinación: hacia delante cuesta arriba (más) y algo hacia atrás cuesta abajo (menos); todo el torso y los brazos giran
//    como un bloque alrededor de la cadera.
import { v3, qMul, qRotX, qFromUnitVectors, qSlerp, clamp, smoothstep, Q_IDENTITY } from './mathq.js';
import { IDX, poseJoints, clonePose } from './skeleton.js';
import { solveTwoBone } from './gait.js';

const SIDES = ['Left', 'Right'];

export function createTerrainFit(rig) {
  const J = rig.joints;
  const legs = SIDES.map((n) => {
    const up = IDX[`${n}UpperLeg`], low = IDX[`${n}LowerLeg`], foot = IDX[`${n}Foot`];
    return { up, low, foot, L1: v3.dist(J[up], J[low]), L2: v3.dist(J[low], J[foot]), restY: J[foot][1] };
  });
  const legBones = new Set(legs.flatMap((l) => [l.up, l.low, l.foot]));
  const upper = [];
  for (let i = 0; i < rig.names.length; i++) if (!legBones.has(i)) upper.push(i);
  const legLen = legs[0].L1 + legs[0].L2;
  const probe = 0.12 * legLen; // separación (unidades del esqueleto) para medir pendientes
  const maxDelta = 0.4 * legLen; // diferencias de altura mayores que esto no se intentan seguir
  const S = { lean: 0, pelvis: 0, k: -1 }; // k < 0: todavía sin fuerza inicial (la primera llamada la fija sin fundido)

  const reset = () => {
    S.lean = 0;
    S.pelvis = 0;
    S.k = -1;
  };

  // pose → pose nueva. opts: { dt, strength (0..1), maxLean (rad) }
  function apply(pose, sample, { dt = 1 / 60, strength = 1, maxLean = 0.3 } = {}) {
    const a = 1 - Math.exp(-Math.max(dt, 0) * 8);
    S.k = S.k < 0 ? clamp(strength, 0, 1) : S.k + (clamp(strength, 0, 1) - S.k) * a;
    const k = S.k;
    if (k < 1e-3 && Math.abs(S.lean) < 1e-4 && Math.abs(S.pelvis) < 1e-5) return pose;
    const out = clonePose(pose);

    // Inclinación del cuerpo según la pendiente en la dirección de marcha.
    const slope = (sample(0, probe * 2) - sample(0, -probe * 2)) / (probe * 4);
    const ang = Math.atan(slope);
    const leanGoal = k * clamp(ang >= 0 ? ang * 0.55 : ang * 0.3, -maxLean * 0.5, maxLean);
    S.lean += (leanGoal - S.lean) * (1 - Math.exp(-Math.max(dt, 0) * 6));
    if (Math.abs(S.lean) > 1e-4) {
      const q = qRotX(S.lean);
      for (const i of upper) out.world[i] = qMul(q, out.world[i]);
    }

    // Altura del suelo bajo cada tobillo y descenso de la pelvis.
    const P = poseJoints(rig, out);
    const g = legs.map((l) => clamp(sample(P[l.foot][0], P[l.foot][2]), -maxDelta, maxDelta) * k);
    const goal = Math.min(0, g[0], g[1]) * 0.9;
    S.pelvis += (goal - S.pelvis) * (1 - Math.exp(-Math.max(dt, 0) * 14));
    const s = S.pelvis;
    out.root[1] += s;

    legs.forEach((l, i) => {
      const H = v3.add(P[l.up], [0, s, 0]);
      const K = P[l.low], A = P[l.foot];
      const target = [A[0], A[1] + g[i], A[2]];
      // Lado hacia el que se dobla la rodilla (perpendicular al eje cadera → tobillo); si la pierna está recta, hacia delante.
      const axis = v3.norm(v3.sub(A, P[l.up]));
      const kneeOff = v3.sub(K, P[l.up]);
      const side = v3.sub(kneeOff, v3.mul(axis, v3.dot(kneeOff, axis)));
      const pole = v3.add(side, [0, 0, 0.03 * legLen]);
      // Se resuelve dos veces (pose original y pose corregida) y se aplica solo la diferencia: así, sin corrección, la pierna
      // queda exactamente como la dejó el animador y la transición es continua.
      const ik0 = solveTwoBone(P[l.up], A, l.L1, l.L2, pole);
      const ik = solveTwoBone(H, target, l.L1, l.L2, pole);
      const up0 = v3.norm(v3.sub(ik0.knee, P[l.up])), up1 = v3.norm(v3.sub(ik.knee, H));
      const lo0 = v3.norm(v3.sub(ik0.ankle, ik0.knee)), lo1 = v3.norm(v3.sub(ik.ankle, ik.knee));
      out.world[l.up] = qMul(qFromUnitVectors(up0, up1), out.world[l.up]);
      out.world[l.low] = qMul(qFromUnitVectors(lo0, lo1), out.world[l.low]);

      // Pie: se apoya sobre la ladera mientras está cerca del suelo.
      const ax = A[0], az = A[2];
      const h0 = sample(ax, az);
      const gx = (sample(ax + probe, az) - h0) / probe;
      const gz = (sample(ax, az + probe) - h0) / probe;
      const contact = 1 - smoothstep(0.03 * legLen, 0.22 * legLen, A[1] - l.restY);
      const tilt = qSlerp(Q_IDENTITY, qFromUnitVectors([0, 1, 0], v3.norm([-gx, 1, -gz])), clamp(contact * k, 0, 1));
      out.world[l.foot] = qMul(tilt, out.world[l.foot]);
    });
    return out;
  }

  return { apply, reset, get state() { return { ...S }; } };
}
