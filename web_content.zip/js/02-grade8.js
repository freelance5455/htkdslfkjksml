/* تولیدشده از data/grade8.json با tests/gen-grade8.js. دستی ویرایش نکن. */
(function () {
  'use strict';
  var App = (window.App = window.App || {});
  App.DATA = App.DATA || {};
  App.DATA.grade8 = {
 "grade": 8,
 "year": "1404-1405",
 "year_verified": true,
 "generated_at": "2026-10-09",
 "note": "فهرست دروس از منبع ثانویه است؛ تعداد فصل‌ها و عنوان فصل‌ها تأیید نشده‌اند مگر اینکه chapters_verified باشد.",
 "subjects": [
  {
   "name": "آموزش قرآن",
   "chapter_count": null,
   "chapters": [],
   "chapters_verified": false,
   "konkur_relevant": false
  },
  {
   "name": "پیام های آسمان",
   "chapter_count": null,
   "chapters": [],
   "chapters_verified": false,
   "konkur_relevant": true
  },
  {
   "name": "فارسی",
   "chapter_count": null,
   "chapters": [],
   "chapters_verified": false,
   "konkur_relevant": true
  },
  {
   "name": "نگارش",
   "chapter_count": null,
   "chapters": [],
   "chapters_verified": false,
   "konkur_relevant": false
  },
  {
   "name": "ریاضی",
   "chapter_count": null,
   "chapters": [],
   "chapters_verified": false,
   "konkur_relevant": true
  },
  {
   "name": "علوم تجربی",
   "chapter_count": 13,
   "chapters": [],
   "chapters_verified": false,
   "konkur_relevant": false
  },
  {
   "name": "مطالعات اجتماعی",
   "chapter_count": null,
   "chapters": [],
   "chapters_verified": false,
   "konkur_relevant": false
  },
  {
   "name": "فرهنگ و هنر",
   "chapter_count": null,
   "chapters": [],
   "chapters_verified": false,
   "konkur_relevant": false
  },
  {
   "name": "عربی",
   "chapter_count": null,
   "chapters": [],
   "chapters_verified": false,
   "konkur_relevant": true
  },
  {
   "name": "انگلیسی",
   "chapter_count": null,
   "chapters": [],
   "chapters_verified": false,
   "konkur_relevant": true
  },
  {
   "name": "تفکر و سبک زندگی",
   "chapter_count": null,
   "chapters": [],
   "chapters_verified": false,
   "konkur_relevant": false
  },
  {
   "name": "کار و فناوری",
   "chapter_count": null,
   "chapters": [],
   "chapters_verified": false,
   "konkur_relevant": false
  }
 ]
};
})();
