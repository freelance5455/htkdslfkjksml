/* tech.js — Phase 7: research, technologies and military doctrines.
   Research points come from civilian factories; each country researches in a few parallel slots.
   Technology effects feed combat, economy, movement, intelligence and construction. */
(function (G) {
  'use strict';

  const cname = id => G.COUNTRIES[id].name;

  /* ---------- technology tree ---------- */
  // fx keys: atk_all def_all atk_inf def_inf atk_arm def_arm atk_art siege speed supply reinforce
  //          industry resources mining construction tax manpower research trade spy counter netgrowth fort rail
  G.BRANCHES = {
    infantry: { name: 'Infantry', icon: '🪖' }, armor: { name: 'Armor', icon: '🛡' }, artillery: { name: 'Artillery', icon: '💥' },
    industry: { name: 'Industry', icon: '🏭' }, logistics: { name: 'Logistics & State', icon: '🚂' },
    defense: { name: 'Fortification', icon: '🏰' }, intel: { name: 'Intelligence', icon: '🕵' }, doctrine: { name: 'Doctrine', icon: '📘' }, navy: { name: 'Naval', icon: '⚓' }
  };
  const T = [];
  const add = (id, branch, name, cost, req, fx, desc) => T.push({ id: id, branch: branch, name: name, cost: cost, req: req || [], fx: fx, desc: desc });
  add('inf1', 'infantry', 'Infantry Tactics I', 80, [], { atk_inf: 0.08 }, 'Infantry & militia attack +8%');
  add('inf2', 'infantry', 'Infantry Tactics II', 130, ['inf1'], { def_inf: 0.10 }, 'Infantry & militia defense +10%');
  add('inf3', 'infantry', 'Combined Arms', 200, ['inf2'], { atk_all: 0.05, def_all: 0.05 }, 'All land units attack and defense +5%');
  add('inf4', 'infantry', 'Elite Infantry', 280, ['inf3'], { atk_inf: 0.10, def_inf: 0.10 }, 'Infantry attack and defense +10%');
  add('arm1', 'armor', 'Motorization', 90, [], { atk_arm: 0.10, speed: 0.05 }, 'Tanks & cavalry attack +10%, army speed +5%');
  add('arm2', 'armor', 'Armored Doctrine', 150, ['arm1'], { atk_arm: 0.15 }, 'Tanks & cavalry attack +15%');
  add('arm3', 'armor', 'Combined Armor', 230, ['arm2'], { def_arm: 0.15, speed: 0.10 }, 'Tanks & cavalry defense +15%, speed +10%');
  add('art1', 'artillery', 'Field Artillery', 90, [], { atk_art: 0.12 }, 'Artillery attack +12%');
  add('art2', 'artillery', 'Heavy Guns', 150, ['art1'], { atk_art: 0.12, siege: 0.25 }, 'Artillery attack +12%; your attackers ignore 25% of fortification bonus');
  add('art3', 'artillery', 'Rocket Artillery', 240, ['art2'], { atk_art: 0.15 }, 'Artillery attack +15%');
  add('ind1', 'industry', 'Industrial Efficiency', 90, [], { industry: 0.10 }, 'Equipment output +10%');
  add('ind2', 'industry', 'Assembly Lines', 150, ['ind1'], { industry: 0.10 }, 'Equipment output +10%');
  add('ind3', 'industry', 'Resource Extraction', 120, [], { resources: 0.10 }, 'All resource production +10%');
  add('ind4', 'industry', 'Advanced Mining', 180, ['ind3'], { mining: 0.15 }, 'Steel and coal production +15%');
  add('agr1', 'industry', 'Agricultural Methods', 80, [], { food: 0.15 }, 'Food production +15%');
  add('agr2', 'industry', 'Mechanized Farming', 140, ['agr1'], { food: 0.20 }, 'Food production +20%');
  add('con1', 'industry', 'Construction Techniques', 80, [], { construction: 0.15 }, 'Construction speed +15%');
  add('con2', 'industry', 'Prefabrication', 140, ['con1'], { construction: 0.15 }, 'Construction speed +15%');
  add('log1', 'logistics', 'Supply Trains', 80, [], { supply: 0.25 }, 'Out-of-supply penalty reduced by 25%');
  add('log2', 'logistics', 'Field Hospitals', 120, ['log1'], { reinforce: 0.5 }, 'Reinforcement rate +50%');
  add('log3', 'logistics', 'Railway Networks', 110, [], { speed: 0.10 }, 'Army speed +10%');
  add('adm1', 'logistics', 'Bureaucracy', 100, [], { tax: 0.08 }, 'Tax income +8%');
  add('adm2', 'logistics', 'Mass Mobilization', 160, ['adm1'], { manpower: 0.15 }, 'Manpower growth +15%');
  add('adm3', 'logistics', 'Research Bureau', 140, ['adm1'], { research: 0.25 }, 'Research speed +25%');
  add('trd1', 'logistics', 'Trade Networks', 100, [], { trade: 0.25 }, 'Monthly trade capacity +25%');
  add('fort1', 'defense', 'Fortifications II', 100, [], { fort: 2 }, 'Allows fortification level 2');
  add('fort2', 'defense', 'Fortifications III', 180, ['fort1'], { fort: 3 }, 'Allows fortification level 3');
  add('spy1', 'intel', 'Signals Intelligence', 100, [], { spy: 0.05, netgrowth: 0.20 }, 'Spy success +5%, networks grow 20% faster');
  add('spy2', 'intel', 'Cryptography', 160, ['spy1'], { spy: 0.05, counter: 1 }, 'Spy success +5%, counter-intelligence +1');
  add('doc1', 'doctrine', 'Doctrinal Studies I', 110, [], { doctrine: 1 }, 'Doctrine level +1');
  add('doc2', 'doctrine', 'Doctrinal Studies II', 180, ['doc1'], { doctrine: 1 }, 'Doctrine level +1');
  add('doc3', 'doctrine', 'Doctrinal Studies III', 260, ['doc2'], { doctrine: 1 }, 'Doctrine level +1');
  add('nav1', 'navy', 'Naval Gunnery', 100, [], { naval_atk: 0.10 }, 'Warship attack +10%');
  add('nav2', 'navy', 'Armoured Hulls', 160, ['nav1'], { naval_def: 0.15 }, 'Ship durability +15%');
  add('nav3', 'navy', 'Sonar and Depth Charges', 140, [], { asw: 0.30, naval_def: 0.05 }, 'Anti-submarine strength +30%, durability +5%');
  add('nav4', 'navy', 'Fleet Logistics', 120, [], { naval_speed: 0.15 }, 'Fleet speed +15%');
  add('nav5', 'navy', 'Convoy Doctrine', 150, ['nav4'], { convoy: 0.35 }, 'Blockade damage to your economy reduced by 35%');
  add('nav6', 'navy', 'Fire Control', 230, ['nav2'], { naval_atk: 0.15 }, 'Warship attack +15%');
  G.TECHS = T; G.TECH = {}; T.forEach(t => { G.TECH[t.id] = t; });

  G.DOCTRINES = {
    mass:      { name: 'Mass Assault', icon: '👥', desc: 'Infantry attack and manpower. +8% infantry attack and +4% manpower, growing with Doctrine level.', base: { atk_inf: 0.08, manpower: 0.04 }, per: { atk_inf: 0.03, manpower: 0.01 } },
    mobile:    { name: 'Mobile Warfare', icon: '🏇', desc: 'Armor and speed. +8% tank & cavalry attack and +5% speed, growing with level.', base: { atk_arm: 0.08, speed: 0.05 }, per: { atk_arm: 0.03, speed: 0.02 } },
    firepower: { name: 'Superior Firepower', icon: '💥', desc: 'Artillery and sieges. +10% artillery attack and +8% fortification ignored, growing with level.', base: { atk_art: 0.10, siege: 0.08 }, per: { atk_art: 0.04, siege: 0.05 } },
    fortress:  { name: 'Fortress Defense', icon: '🏰', desc: 'Defense. +8% defense for all land units, growing with level.', base: { def_all: 0.08 }, per: { def_all: 0.03 } }
  };
  G.DOCTRINE_SWITCH_COST = 300;

  // Starting knowledge: a little variety between nations.
  const START = { E: ['inf1', 'ind1', 'adm1'], D: ['ind1', 'con1', 'spy1'], B: ['inf1', 'art1'], G: ['arm1', 'inf1'], A: ['inf1', 'log1'], C: ['ind3', 'log3'], F: ['adm1', 'trd1'] };
  const AI_DOCTRINE = { 'Military Junta': 'mass', 'Fascist State': 'mobile', 'Empire': 'firepower', 'Communist State': 'mass', 'Absolute Monarchy': 'fortress', 'Republic': 'fortress', 'Parliamentary Democracy': 'fortress', 'Constitutional Monarchy': 'firepower', 'Federation': 'mass' };
  const AI_PRIORITY = {
    war: ['inf1', 'art1', 'agr1', 'arm1', 'ind1', 'nav1', 'inf2', 'log1', 'fort1', 'nav3', 'doc1', 'art2', 'arm2', 'inf3', 'ind2', 'doc2', 'log2', 'inf4', 'arm3', 'art3', 'doc3', 'fort2'],
    eco: ['agr1', 'ind1', 'ind3', 'con1', 'adm1', 'trd1', 'nav4', 'nav5', 'adm3', 'ind2', 'ind4', 'con2', 'adm2', 'agr2', 'inf1', 'log1', 'spy1', 'art1', 'inf2', 'fort1', 'log3', 'doc1', 'spy2']
  };

  /* ---------- state ---------- */
  G.initTech = function (st, fresh) {
    st.tech = st.tech || {};
    for (const id in G.COUNTRIES) {
      if (!st.tech[id]) {
        const done = {}; (START[id] || []).forEach(t => { done[t] = true; });
        st.tech[id] = { done: done, prog: {}, active: [], doctrine: id === st.player ? null : (AI_DOCTRINE[G.COUNTRIES[id].gov] || 'mass'), docChanged: -999 };
      }
      const t = st.tech[id]; t.prog = t.prog || {}; t.active = t.active || []; t.done = t.done || {};
      if (t.docChanged == null) t.docChanged = -999;
    }
    cache = {};
  };

  /* ---------- effects ---------- */
  let cache = {};
  G.invalidateTech = function () { cache = {}; };
  G.doctrineLevel = function (id) { const t = G.state.tech[id]; let l = 0; for (const k in t.done) if (G.TECH[k] && G.TECH[k].fx.doctrine) l += G.TECH[k].fx.doctrine; return l; };
  function build(id) {
    const st = G.state, t = st.tech[id], out = {};
    for (const k in t.done) { const T = G.TECH[k]; if (!T) continue; for (const f in T.fx) { if (f === 'fort' || f === 'doctrine') continue; out[f] = (out[f] || 0) + T.fx[f]; } }
    out.fortLevel = 1; for (const k in t.done) if (G.TECH[k] && G.TECH[k].fx.fort) out.fortLevel = Math.max(out.fortLevel, G.TECH[k].fx.fort);
    if (t.doctrine && G.DOCTRINES[t.doctrine]) {
      const D = G.DOCTRINES[t.doctrine], L = G.doctrineLevel(id);
      for (const f in D.base) out[f] = (out[f] || 0) + D.base[f] + D.per[f] * L;
    }
    return out;
  }
  G.techEff = function (id, key) {
    if (!G.state.tech || !G.state.tech[id]) return 0;
    const sig = id + ':' + Object.keys(G.state.tech[id].done).length + ':' + G.state.tech[id].doctrine;
    if (!cache[id] || cache[id].sig !== sig) { cache[id] = { sig: sig, v: build(id) }; }
    return cache[id].v[key] || 0;
  };
  G.techMult = function (id, key) { return 1 + G.techEff(id, key); };
  const CLS = { infantry: 'inf', militia: 'inf', engineers: 'inf', cavalry: 'arm', tank: 'arm', artillery: 'art' };
  // attack/defense multiplier for one unit type
  G.unitTech = function (id, type, defending) {
    const c = CLS[type] || 'inf', k = defending ? 'def' : 'atk';
    return (1 + G.techEff(id, k + '_all')) * (1 + G.techEff(id, k + '_' + c));
  };
  G.fortLevelAllowed = function (id) { return G.techEff(id, 'fortLevel') || 1; };
  G.hasTech = function (id, t) { return !!G.state.tech[id].done[t]; };

  /* ---------- research ---------- */
  G.researchSlots = function (id) { return 2 + (G.totals(id).civ >= 20 ? 1 : 0); };
  G.researchRate = function (id) {
    const st = G.state; if (!st.tech) return 0;
    const t = G.totals(id), c = st.countries[id];
    let r = 0.8 + 0.12 * t.civ + 0.015 * (c.provCount || 0);
    r *= G.techMult(id, 'research');
    return r;
  };
  G.techCost = function (tid) { return G.TECH[tid].cost; };
  G.techAvailable = function (id, tid) {
    const st = G.state, T = G.TECH[tid], r = st.tech[id];
    if (r.done[tid]) return { ok: false, msg: 'Researched' };
    if (r.active.includes(tid)) return { ok: false, msg: 'In progress' };
    const miss = T.req.filter(q => !r.done[q]); if (miss.length) return { ok: false, msg: 'Needs ' + miss.map(q => G.TECH[q].name).join(', ') };
    if (r.active.length >= G.researchSlots(id)) return { ok: false, msg: 'All research slots busy' };
    return { ok: true };
  };
  G.startResearch = function (id, tid) {
    const chk = G.techAvailable(id, tid); if (!chk.ok) return chk;
    G.state.tech[id].active.push(tid); return { ok: true };
  };
  G.cancelResearch = function (id, tid) {
    const r = G.state.tech[id]; r.active = r.active.filter(x => x !== tid); return { ok: true };   // progress is kept
  };
  // days left at current rate, taking allies' knowledge into account
  G.techBoost = function (id, tid) { return G.alliesOf(id).some(a => G.state.tech[a] && G.state.tech[a].done[tid]) ? 1.25 : 1; };
  G.techEta = function (id, tid) {
    const r = G.state.tech[id], n = Math.max(1, r.active.length || 1);
    const per = G.researchRate(id) / n * G.techBoost(id, tid);
    return Math.ceil((G.TECH[tid].cost - (r.prog[tid] || 0)) / Math.max(0.01, per));
  };
  G.setDoctrine = function (id, d) {
    const st = G.state, r = st.tech[id], c = st.countries[id];
    if (!G.DOCTRINES[d] || r.doctrine === d) return { ok: false, msg: 'Already your doctrine' };
    const free = !r.doctrine, cost = free ? 0 : G.DOCTRINE_SWITCH_COST;
    if (!free && st.day - r.docChanged < 60) return { ok: false, msg: 'Doctrine changed recently — wait ' + (60 - (st.day - r.docChanged)) + ' days' };
    if (c.treasury < cost) return { ok: false, msg: 'Not enough gold (' + cost + ')' };
    c.treasury -= cost; r.doctrine = d; r.docChanged = st.day; return { ok: true };
  };

  function complete(id, tid) {
    const st = G.state, r = st.tech[id];
    r.done[tid] = true; delete r.prog[tid]; r.active = r.active.filter(x => x !== tid);
    cache = {};
    G.recompute && G.recompute();
    G.logMsg && id === st.player && G.logMsg('🔬 Research complete: ' + G.TECH[tid].name);
    if (id === st.player) { G.toast && G.toast('🔬 Research complete: ' + G.TECH[tid].name); G.onTechDone && G.onTechDone(tid); }
  }

  function aiResearch(id) {
    const st = G.state, r = st.tech[id], war = G.warsOf(id).length > 0;
    let list = (war || G.COUNTRIES[id].gov.match(/Junta|Fascist|Empire/) ? AI_PRIORITY.war : AI_PRIORITY.eco).slice();
    if (!war) list = list.concat(AI_PRIORITY.war);
    while (r.active.length < G.researchSlots(id)) {
      const pick = list.find(t => G.techAvailable(id, t).ok);
      if (!pick) break;
      G.startResearch(id, pick);
    }
  }

  G.techDay = function () {
    const st = G.state; if (!st.tech) return;
    for (const id in st.countries) {
      const c = st.countries[id]; if (c.dead) continue;
      const r = st.tech[id];
      if (id !== st.player && st.day % 5 === 1) aiResearch(id);
      if (!r.active.length) continue;
      const per = G.researchRate(id) / r.active.length;
      for (const tid of r.active.slice()) {
        r.prog[tid] = (r.prog[tid] || 0) + per * G.techBoost(id, tid);
        if (r.prog[tid] >= G.TECH[tid].cost) complete(id, tid);
      }
    }
  };

  // Used by the "Steal technology" operation (intel.js): returns the stolen tech name or null.
  G.stealTech = function (thief, victim) {
    const st = G.state, rv = st.tech[victim], rt = st.tech[thief];
    const cand = Object.keys(rv.done).filter(t => !rt.done[t] && G.TECH[t].req.every(q => rt.done[q]));
    if (!cand.length) return null;
    const tid = cand[Math.floor(G.rand() * cand.length)], T = G.TECH[tid];
    rt.prog[tid] = Math.min(T.cost - 1, (rt.prog[tid] || 0) + 0.6 * T.cost);
    if (rt.active.length < G.researchSlots(thief) && !rt.active.includes(tid)) rt.active.push(tid);
    return T.name;
  };
})(window.EMP = window.EMP || {});
