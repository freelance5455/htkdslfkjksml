// ===== cine.js: transport vehicles, extraction / arrival / victory cutscenes, loading screen =====
const LZ = { x: 14, z: 0 };
const VSPEC = {
  plane: { L: 16, W: 3.2, hf: .9, rampLen: 3.4, fuse: 0x6b7078, accent: 0x2a2d31, eng: 'jet', cabL: 7, air: true, tL: 8.4 },
  heli: { L: 11, W: 2.6, hf: .9, rampLen: 3.2, fuse: 0x7a6a48, accent: 0x2a2820, eng: 'rotor', cabL: 5.5, air: true, tL: 9.2 },
  gunship: { L: 12, W: 2.6, hf: .9, rampLen: 3.2, fuse: 0x1b1e24, accent: 0x0c0d10, eng: 'rotor', cabL: 5.8, air: true, tL: 9.2 },
  truck: { L: 9.5, W: 2.6, hf: 1.25, rampLen: 3.6, fuse: 0x56603f, accent: 0x1c1e17, eng: 'diesel', cabL: 6, air: false, tL: 8.2 },
  hover: { L: 10, W: 3.2, hf: .9, rampLen: 3.2, fuse: 0x4a5a50, accent: 0x1b211d, eng: 'rotor', cabL: 5.2, air: false, tL: 8.2 }
};
const _vm = (c, m, r) => new THREE.MeshStandardMaterial({ color: c, metalness: m === undefined ? .4 : m, roughness: r === undefined ? .6 : r });
function cb(g, w, h, d, mat, x, y, z, rx, ry, rz) { const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat); m.position.set(x, y, z); if (rx || ry || rz) m.rotation.set(rx || 0, ry || 0, rz || 0); m.castShadow = true; g.add(m); return m; }
function cc(g, rt, rb, h, mat, x, y, z, rx, ry, rz, seg) { const m = new THREE.Mesh(new THREE.CylinderGeometry(rt, rb, h, seg || 12), mat); m.position.set(x, y, z); m.rotation.set(rx || 0, ry || 0, rz || 0); m.castShadow = true; g.add(m); return m; }
function glowSprite(g, x, y, z, s, col) { const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: TEX_SOFT, color: col, blending: THREE.AdditiveBlending, transparent: true, depthWrite: false, fog: false })); sp.scale.setScalar(s); sp.position.set(x, y, z); g.add(sp); return sp; }
function propeller(parent, x, y, z, r, nb, rx, ry) {
  const w = new THREE.Group(); w.position.set(x, y, z); w.rotation.set(rx || 0, ry || 0, 0); parent.add(w); const sp = new THREE.Group(); w.add(sp);
  for (let i = 0; i < nb; i++) { const b = cb(sp, r * 2, .04, .28, _vm(0x181818, .2, .6), 0, 0, 0, 0, 0, i / nb * Math.PI); b.castShadow = false; }
  const d = new THREE.Mesh(new THREE.CircleGeometry(r, 20), new THREE.MeshBasicMaterial({ color: 0x9a9a9a, transparent: true, opacity: .1, side: THREE.DoubleSide, depthWrite: false })); w.add(d); return sp;
}
function buildVehicle(kind) {
  const S = VSPEC[kind], W = S.W, L = S.L, hf = S.hf, cl = S.cabL, H = 2.3, zc = -L / 2 + cl / 2;
  const root = new THREE.Group(), body = new THREE.Group(); root.add(body);
  const hull = _vm(S.fuse, .5, .55), dark = _vm(S.accent, .5, .7), glass = new THREE.MeshStandardMaterial({ color: 0x1a2a3a, metalness: .8, roughness: .1, emissive: 0x0a1420 }), lamp = new THREE.MeshBasicMaterial({ color: 0xe8f0ff }), light = _vm(0x8a8d92, .6, .5);
  cb(body, W, .12, cl, dark, 0, hf - .06, zc);
  for (const sx of [-1, 1]) { cb(body, .12, H, cl, hull, sx * W / 2, hf + H / 2, zc); cb(body, .5, .12, cl - 1.2, dark, sx * (W / 2 - .35), hf + .5, zc); cb(body, .1, .55, cl - 1.2, dark, sx * (W / 2 - .12), hf + .85, zc); cb(body, .1, .05, cl - 1, lamp, sx * (W / 2 - .45), hf + H - .04, zc); }
  cb(body, W, .12, cl, hull, 0, hf + H + .06, zc); cb(body, W, H, .12, dark, 0, hf + H / 2, -L / 2 + cl); cb(body, W, .18, .2, dark, 0, hf + H, -L / 2); cb(body, .9, .5, .5, dark, 0, hf + .25, -L / 2 + cl - 1.0);
  const cab = new THREE.PointLight(0xdfeaff, 1.5, 10); cab.position.set(0, hf + H - .3, zc); body.add(cab);
  const ramp = new THREE.Group(); ramp.position.set(0, hf, -L / 2); body.add(ramp); const pl = new THREE.Group(); ramp.add(pl);
  cb(pl, W - .3, .12, S.rampLen, dark, 0, 0, -S.rampLen / 2); for (let i = 1; i < 7; i++) cb(pl, W - .3, .03, .07, light, 0, .07, -i * S.rampLen / 7);
  const V = { g: root, body, ramp, pl, S, cab, L, W, hf, H, cl, rotors: [], fans: [], wheels: [], nac: [], glows: [], rampK: 0, rampRun: Math.sqrt(S.rampLen * S.rampLen - hf * hf) };
  V.setRamp = k => { k = clamp(k, 0, 1); V.rampK = k; const e = k * k * (3 - 2 * k); ramp.rotation.x = lerp(Math.PI / 2, -Math.asin(hf / S.rampLen), e); pl.scale.z = lerp(H + .1, S.rampLen, e) / S.rampLen; };
  V.setRamp(0);
  V.setTilt = a => V.nac.forEach(n => { n.rotation.x = -a * Math.PI / 2; });
  const noseZ = -L / 2 + cl, fl = L - cl;
  const nav = (x, y, z, c) => { cb(body, .14, .14, .14, new THREE.MeshBasicMaterial({ color: c }), x, y, z); glowSprite(body, x, y, z, 1.2, c); };
  if (kind === 'plane') {
    cb(body, W, H + .2, fl - 2, hull, 0, hf + H / 2, noseZ + (fl - 2) / 2); cb(body, W - .6, 1.4, 2.4, hull, 0, hf + 1.2, L / 2 - 1.2, .3, 0, 0); cb(body, W - .5, .9, 1.7, glass, 0, hf + H - .25, L / 2 - 2.6, -.25, 0, 0);
    cb(body, 15, .28, 3.4, hull, 0, hf + H - .2, -.6); cb(body, .3, 3.0, 2.4, hull, 0, hf + H + 1.4, -L / 2 + 1.6, .15, 0, 0); cb(body, 5.5, .2, 1.5, hull, 0, hf + H + 2.7, -L / 2 + 1.9);
    for (const sx of [-1, 1]) {
      const n = new THREE.Group(); n.position.set(sx * 7.3, hf + H, -.6); body.add(n); cc(n, .85, .85, 3, dark, 0, 0, 0, Math.PI / 2, 0, 0);
      V.fans.push(propeller(n, 0, 0, 1.6, 1.7, 3, 0, 0)); V.glows.push(glowSprite(n, 0, 0, -1.9, 3.4, 0xffa860)); V.nac.push(n); nav(sx * 7.5, hf + H, -2.2, sx < 0 ? 0xff3a2a : 0x2aff5a);
      for (const z of [-4, 4]) cc(body, .14, .14, hf, dark, sx * 1.4, hf / 2, z);
    }
    cb(body, W + .04, .5, fl - 2, dark, 0, hf + .1, noseZ + (fl - 2) / 2);
  } else if (kind === 'heli' || kind === 'gunship') {
    cb(body, W, H + .1, fl, hull, 0, hf + H / 2, noseZ + fl / 2); cb(body, W - .4, 1.0, 1.5, glass, 0, hf + 1.7, L / 2 - .5, -.3, 0, 0);
    cb(body, .7, .8, 7, hull, 0, hf + H + .2, -L / 2 - 3.0); cb(body, .12, 1.8, 1.1, hull, 0, hf + H + 1.1, -L / 2 - 6.2);
    V.rotors.push(propeller(body, .45, hf + H + 1.2, -L / 2 - 6.2, .95, 2, 0, Math.PI / 2)); cc(body, .12, .12, .9, dark, 0, hf + H + .45, -.5); V.rotors.push(propeller(body, 0, hf + H + .9, -.5, 6.4, 4, Math.PI / 2, 0));
    for (const sx of [-1, 1]) { cc(body, .07, .07, L - 1, dark, sx * 1.3, .14, 0, Math.PI / 2); cb(body, .08, hf - .1, .08, dark, sx * 1.25, hf / 2, -2); cb(body, .08, hf - .1, .08, dark, sx * 1.25, hf / 2, 2); cc(body, .5, .5, 2.2, dark, sx * .6, hf + H + .5, -1, Math.PI / 2); }
    if (kind === 'gunship') {
      cb(body, 6, .15, 1.2, hull, 0, hf + 1.4, .6); for (const sx of [-1, 1]) cb(body, .5, .5, 1.8, dark, sx * 2.6, hf + 1.15, .6);
      const geo = new THREE.ConeGeometry(2.6, 14, 18, 1, true); geo.translate(0, -7, 0); const cone = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ color: 0xcfe4ff, transparent: true, opacity: .1, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false }));
      cone.position.set(0, hf - .2, L / 2 - 1); cone.rotation.x = -.5; body.add(cone); nav(1.3, hf + 1.0, L / 2 - .6, 0xff2a2a);
    } else nav(1.3, hf + 1.0, L / 2 - .6, 0x2aff5a);
  } else if (kind === 'truck') {
    cb(body, W - .3, .5, L - 1, dark, 0, hf - .38, 0); cb(body, W, 2.1, 2.0, hull, 0, hf + 1.05, 2.4); cb(body, W - .3, 1.1, 1.5, hull, 0, hf + .55, 4.0); cb(body, W - .4, .9, .08, glass, 0, hf + 1.55, 3.43, -.25, 0, 0);
    cb(body, W + .1, .35, .3, dark, 0, hf - .15, 4.8);
    for (const sx of [-1, 1]) { cb(body, .25, .2, .1, lamp, sx * .8, hf + .6, 4.76); V.glows.push(glowSprite(body, sx * .8, hf + .6, 4.9, 2.6, 0xfff0c0)); }
    for (const z of [-2.8, -.9, 3.4]) for (const sx of [-1, 1]) { const w = new THREE.Group(); w.position.set(sx * (W / 2 + .1), .62, z); body.add(w); cc(w, .62, .62, .5, _vm(0x111111, 0, .9), 0, 0, 0, 0, 0, Math.PI / 2, 16); cb(w, .52, .2, .2, light, 0, 0, 0); V.wheels.push(w); }
    cc(body, .08, .08, 1.2, dark, W / 2 + .05, hf + 1.7, 1.5);
  } else {
    cb(body, W + .6, .7, L - .6, hull, 0, .45, 0); cb(body, W + 1.0, .3, L, dark, 0, .16, 0); cb(body, W, H, fl - .2, hull, 0, hf + H / 2, noseZ + (fl - .2) / 2); cb(body, W - .4, 1.0, .1, glass, 0, hf + 1.5, L / 2 - .3, -.35, 0, 0);
    for (const sx of [-1, 1]) {
      const tor = new THREE.Mesh(new THREE.TorusGeometry(1.15, .1, 8, 24), dark); tor.position.set(sx * (W / 2 + 1.3), hf + 1.6, -L / 2 + 1.4); body.add(tor);
      V.rotors.push(propeller(body, sx * (W / 2 + 1.3), hf + 1.6, -L / 2 + 1.4, 1.1, 5, 0, 0)); cb(body, 1.2, .12, .12, dark, sx * (W / 2 + .6), hf + 1.6, -L / 2 + 1.4); V.glows.push(glowSprite(body, sx * (W / 2 + 1.3), hf + 1.6, -L / 2 + .6, 2.6, 0x80ffa0)); nav(sx * (W / 2 + .4), hf + .4, L / 2 - .4, sx < 0 ? 0xff3a2a : 0x2aff5a);
    }
  }
  V.tick = (dt, rpm, wheel) => { for (const r of V.rotors) r.rotation.z += rpm * dt; for (const f of V.fans) f.rotation.z += rpm * dt * 1.3; for (const w of V.wheels) w.rotation.x += (wheel || 0) * dt; };
  return V;
}

// ---- friendly soldiers ----
function friendlySoldier() {
  const b = buildSoldier('soldier'), g = b.g, mats = {};
  g.traverse(o => {
    if (!o.isMesh) return; const m = o.material; let c = null;
    if (m === EM.uni) c = 0x37577a; else if (m === EM.uni2) c = 0x2b405a; else if (m === EM.vest) c = 0x1f2b3a; else if (m === EM.helmet) c = 0x24384e; else if (m === EM.band) { o.material = new THREE.MeshBasicMaterial({ color: 0x2aa6ff }); return; }
    if (c !== null) { if (!mats[c]) mats[c] = sm(c); o.material = mats[c]; }
  });
  return { g, legs: b.legs, arms: b.arms, ph: Math.random() * 6 };
}
function animSol(s, dt, speed, sit) { s.ph += dt * Math.max(speed, .01) * 1.9; const sw = Math.sin(s.ph) * .75 * Math.min(1, speed / 3); if (sit) { s.legs[0].rotation.x = -1.4; s.legs[1].rotation.x = -1.4; } else { s.legs[0].rotation.x = sw; s.legs[1].rotation.x = -sw; } s.g.position.y += Math.abs(Math.cos(s.ph)) * .04 * Math.min(1, speed / 3); }

// ---- cutscene toolkit ----
let C = null; const _cw = new THREE.Vector3();
const pickV = a => a[Math.floor(Math.random() * a.length)];
const ALT = { plane: ['plane', 'plane', 'heli', 'gunship'], heli: ['heli', 'gunship'], gunship: ['gunship', 'heli'], truck: ['truck', 'hover'], hover: ['hover', 'truck'] };
function altVehicle(vk) { return pickV(ALT[vk] || [vk]); }
const ease = x => x * x * (3 - 2 * x), prog = (t, a, b) => clamp((t - a) / (b - a), 0, 1), pe = (t, a, b) => ease(prog(t, a, b));
const yawOf = (dx, dz) => Math.atan2(-dx, -dz);
function spline(KF, t) {
  const n = KF.length; if (t <= KF[0][0]) return KF[0].slice(1); if (t >= KF[n - 1][0]) return KF[n - 1].slice(1);
  let i = 0; while (KF[i + 1][0] < t) i++; const a = KF[i], b = KF[i + 1], u = (t - a[0]) / (b[0] - a[0]), p0 = KF[Math.max(0, i - 1)], p3 = KF[Math.min(n - 1, i + 2)];
  return [1, 2, 3].map(k => .5 * ((2 * a[k]) + (-p0[k] + b[k]) * u + (2 * p0[k] - 5 * a[k] + 4 * b[k] - p3[k]) * u * u + (-p0[k] + 3 * a[k] - 3 * b[k] + p3[k]) * u * u * u));
}
function angLerp(a, b, k) { return a + angDiff(a, b) * k; }
function capText(t, dur) { const c = $('cap'); c.textContent = t; c.classList.add('on'); clearTimeout(capText.h); capText.h = setTimeout(() => c.classList.remove('on'), (dur || 2.4) * 1000); }
function startEngine(kind) { return (typeof makeEngine === 'function') ? makeEngine(kind) : { vol() { }, pitch() { }, stop() { } }; }
function cineSound(kind) {
  if (!ac || muted) return; const o = sout(undefined, undefined, 1);
  if (kind === 'ramp') { snoise(o, 1.5, 'lowpass', 1100, 200, .8, .7); stone(o, 70, 40, 1.5, .4, 'sawtooth'); stone(o, 90, 30, .3, 1.1, 'sine', 1.5); }
  else if (kind === 'thud') { stone(o, 85, 25, .4, 1.3); snoise(o, .3, 'lowpass', 1500, 150, .7, .8); }
  else if (kind === 'grab') { snoise(o, .15, 'bandpass', 1200, 600, 1, .6); stone(o, 160, 70, .14, .7); }
}
function beginCine() {
  G.state = 'cine'; clearStrikes(); clearEnemies(); clearLoot(); removeMerchant(); clearAirdrop(); hideLZ(); fires.length = 0; P.trigger = false; P.adsHeld = false; for (const k in K) K[k] = false; touchIn.mx = touchIn.my = 0;
  if (P.inTank) exitTank(); document.body.classList.add('cine'); $('hud').hidden = true; $('pause').hidden = $('shop').hidden = $('inv').hidden = true; hint(''); reloadBar(-1); $('skip').hidden = false; $('tankfp').style.opacity = 0;
  if (document.pointerLockElement) document.exitPointerLock(); canvas.style.filter = '';
}
function cineVisualsOff() {
  document.body.classList.remove('cine'); $('skip').hidden = true; $('lidT').style.height = $('lidB').style.height = '0'; $('dustov').style.opacity = 0; $('cap').classList.remove('on'); GH.visible = false; LH.visible = false;
  camera.fov = 75; camera.updateProjectionMatrix(); vmCam.fov = 58; vmCam.updateProjectionMatrix(); canvas.style.filter = '';
}
function endCine() { cineVisualsOff(); $('hud').hidden = false; $('fade').style.transition = 'opacity .6s'; $('fade').style.opacity = 0; C = null; G.state = 'playing'; hudAmmo(); hudHealth(); lockMouse(); }
function disposeCine(o) { if (o.PF) scene.remove(o.PF.g); if (o.CH) scene.remove(o.CH); if (o.eng2) o.eng2.stop(); if (o.V) { scene.remove(o.V.g); } if (o.A) scene.remove(o.A.g); if (o.B) scene.remove(o.B.g); if (o.eng) o.eng.stop(); }
// first-person hands that the soldiers put on you
const GH = new THREE.Group(); GH.visible = false; vmScene.add(GH);
const ghHand = [0, 1].map(i => { const w = new THREE.Group(); GH.add(w); const gl = vmMesh(w, BX(.09, .08, .13), vmM.glove, 0, 0, 0), ar = new THREE.Mesh(new THREE.CylinderGeometry(.05, .06, 1, 8), _vm(0x37577a, 0, 1)); w.add(ar); return { gl, ar }; });
function placeGrab(k, jolt) {
  GH.visible = k > .01; if (!GH.visible) return;
  for (let i = 0; i < 2; i++) {
    const sx = i ? 1 : -1, h = ghHand[i], gx = sx * (.5 - .0 + (1 - k) * .55), gy = -.3 + (1 - k) * -.15 + jolt * .02 * sx, gz = -.34; h.gl.position.set(gx, gy, gz); h.gl.rotation.set(-.5, sx * .4, sx * -.3);
    const ex = sx * 1.2, ey = -.85, ez = .25, dx = gx - ex, dy = gy - ey, dz = gz - ez, len = Math.hypot(dx, dy, dz); h.ar.position.set((gx + ex) / 2, (gy + ey) / 2, (gz + ez) / 2); h.ar.scale.set(1, len, 1); h.ar.quaternion.setFromUnitVectors(_yv, _ld2.set(dx / len, dy / len, dz / len));
  }
}
function lidsOverlay(lid, dust) { const h = (lid * 50).toFixed(1) + '%'; $('lidT').style.height = h; $('lidB').style.height = h; $('dustov').style.opacity = dust.toFixed(2); }
function dustBlast(x, z, k, dt, toward) {
  const n = Math.floor(k * 220 * dt + Math.random()); if (n <= 0) return;
  for (let i = 0; i < n; i++) { const a = rand(0, 6.283), r = rand(1, 9); smoke.emit(x + Math.cos(a) * r, .3, z + Math.sin(a) * r, Math.cos(a) * rand(5, 11), rand(.2, 1.6), Math.sin(a) * rand(5, 11), rand(1.6, 3), 1.6, 5.5, C_DUST, C_DUST, .5, 0, 0, 1.2); }
  if (toward && k > .25 && Math.random() < k) smoke.emit(LZ.x + rand(-5, 3), rand(.2, 3), rand(-5, 5), -rand(6, 11), rand(-.2, .6), rand(-1.5, 1.5), rand(1.4, 2.4), 2, 4.5, C_DUST, C_DUST, .5, 0, 0, .6);
}
// eye height over the ramp / floor
function profileY(S, rampEnd, hingeX, x) { return x <= rampEnd ? 0 : x >= hingeX ? S.hf : S.hf * (x - rampEnd) / (hingeX - rampEnd); }

// ---- pickup: vehicle comes in, soldiers drag you aboard, takeoff ----
function startPickup(vk, mode) {
  beginCine(); const S = VSPEC[vk], V = buildVehicle(vk), air = S.air, tL = S.tL, hf = S.hf;
  const rampEnd = LZ.x + 2.0, hingeX = rampEnd + V.rampRun, Vx = hingeX + S.L / 2, seatX = hingeX + S.cabL - .8, tag = vk === 'plane' ? 0 : 1;
  scene.add(V.g); V.g.position.set(1000, -50, 0); const A = friendlySoldier(), B = friendlySoldier(); A.g.visible = B.g.visible = false; scene.add(A.g); scene.add(B.g);
  const eng = startEngine(S.eng); P.pos.set(LZ.x, 0, 0);
  const side = Math.random() < .5 ? -1 : 1, zo = side * rand(14, 40), bank = side * rand(.15, .4); let KF, yawF;
  if (vk === 'plane') { KF = [[0, LZ.x - 180, 60, 0], [3.3, LZ.x + 2, 46, 0], [5.0, Vx - 20, 32, .12], [6.6, Vx - 4, 10, .16], [8.4, Vx, 0, 0]]; yawF = () => Math.PI / 2; }
  else if (air) { KF = [[0, Vx + 160, 48, -.08], [3.6, Vx + 36, 28, -.1], [5.2, Vx + 2, 15, .05], [7.0, Vx, 13, 0], [S.tL, Vx, 0, 0]]; yawF = t => lerp(-Math.PI / 2, Math.PI / 2, pe(t, 5.0, 7.0)); }
  else { KF = [[0, 98, 0, 0], [4.6, Vx + 26, 0, -.05], [5.4, Vx + 14, 0, 0], [6.8, Vx + 9, 0, 0], [S.tL, Vx, 0, 0]]; yawF = t => lerp(-Math.PI / 2, Math.PI / 2, pe(t, 5.4, 6.8)); }
  const tSol = tL + 1.6, tRun = rand(2.0, 3.3), tGrab = tSol + tRun + .9, tD0 = tGrab + .6, tD1 = tD0 + rand(2.8, 4.2), tS = tD1, tT = tS + 2.4, tExt = tT + 1.6;
  const end = mode === 'win' ? tExt + 9.5 : tT + 3.8; let cyaw = -Math.PI / 2, cpitch = 0, seated = false;
  const gs0 = air ? tL - 3.6 : 5.0, gs1 = tL + 1.9;
  C = { kind: 'pickup', t: 0, V, A, B, eng, end };
  C.update = dt => {
    const t = C.t += dt;
    if (t >= end) { C.t = end; const o = C; C = null; disposeCine(o); if (mode === 'win') cineCredits(); else { cineVisualsOff(); runLoading(Math.floor(G.wave / 5) % MAPS.length, vk); } return; }
    if (t > .8 && t < .86) capText(mode === 'win' ? 'SON TAHLİYE · EVE DÖNÜYORSUN' : pickV(['TAHLİYE ARACI GELİYOR', '"SİNYALİ GÖRDÜK, YAKLAŞIYORUZ"', 'HATTIN ARKASINA ÇEKİLİYORSUN', '"LZ TEMİZ, İNİYORUZ"']), 2.6);
    // vehicle
    let vx, vy, vpitch = 0, vroll = 0, vyaw = Math.PI / 2;
    if (t < tL) { const p = spline(KF, t); vx = p[0]; vy = p[1]; vpitch = p[2]; vyaw = yawF(t); if (!air && vk === 'truck') vroll = .08 * Math.sin(prog(t, 5.4, 6.8) * Math.PI); }
    else { vx = Vx; vy = 0; }
    let tk = 0; if (t > tT) { tk = t - tT; if (air) { vy = .5 * 3.2 * tk * tk; vx = Vx + .5 * 1.4 * tk * tk * tk * .2 * (tk > 1.5 ? 1 : 0); vpitch = -.1 * prog(tk, 1, 3); } else { vx = Vx + .5 * 2.6 * tk * tk; vpitch = .03; } }
    const hov = vk === 'hover' ? .3 + Math.sin(t * 3) * .05 : 0;
    const vz = t < tL ? zo * (1 - pe(t, 0, tL - 1.2)) : (t > tT ? side * .6 * tk * tk : 0); if (t < tL) vyaw += -side * .22 * (1 - pe(t, 0, tL - 1.2)); if (air && t > tT) vroll += bank * prog(tk, .4, 3);
    V.g.position.set(vx, vy + hov, vz); V.g.rotation.y = vyaw; V.body.rotation.x = -vpitch; V.body.rotation.z = vroll;
    const rpm = (air ? 38 : 24) * (t < 1 ? .5 + t * .5 : 1); V.tick(dt, rpm, (air ? 0 : (t < tL ? -24 : t > tT ? 24 : 0)));
    if (vk === 'plane') V.setTilt(t < tL ? pe(t, 3.6, 5.6) : t > tT + 2 ? 1 - pe(t, tT + 2, tT + 4) : 1);
    V.setRamp(t < tL - .4 ? 0 : t < tS + 1.0 ? pe(t, tL - .4, tL + 1.8) : 1 - pe(t, tS + 1.0, tS + 3.0));
    V.cab.intensity = 1.5 * (1 - .6 * pe(t, tS + 2.2, tS + 3.2));
    for (const g of V.glows) g.material.opacity = air ? (t < tL ? 1 : .5) : .8;
    // dust: the downwash
    const dK = air ? (t < tL ? clamp(1 - vy / 24, 0, 1) * clamp(1 - Math.abs(vx - Vx) / 30, 0, 1) : (t > tT && tk < 3 ? clamp(1 - vy / 22, 0, 1) : 0) * 1) : (t > 5.2 && t < tL + .6 ? 1 : 0);
    dustBlast(vx, 0, dK, dt, true);
    // eyes, hand, weapon
    const g = pe(t, gs0, gs0 + .9) * (1 - pe(t, gs1 - .9, gs1)), lid = .08 + .42 * (air ? pe(t, tL - 1.8, tL - .7) * (1 - pe(t, tL + .4, tL + 1.4)) : pe(t, 5.8, 6.4) * (1 - pe(t, 7.8, 8.8))) * (g > .5 ? 1 : 0);
    lidsOverlay(g > .05 ? lid : 0, g * .75);
    // camera
    let cx, cy, cz, sh = .01 + dK * .06 + (t > tT ? Math.min(.05, tk * .02) : 0);
    const ox = LZ.x;
    if (t < tD0) {
      cx = ox; cy = EYE; cz = 0; let tgx, tgy, tgz;
      if (vk === 'plane' && t < 1.6) { tgx = ox + 40; tgy = EYE; tgz = 0; } else if (t < tL + 1.0) { tgx = vx; tgy = vy + 2; tgz = V.g.position.z; } else { tgx = rampEnd + 2; tgy = 1.2; tgz = 0; }
      const dx = tgx - cx, dz = tgz - cz, dyy = tgy - cy; const wy = yawOf(dx, dz), wp = clamp(Math.atan2(dyy, Math.hypot(dx, dz)), -.6, 1.35);
      const f = 1 - Math.exp(-dt * (vk === 'plane' && t > 1.6 && t < 4 ? 5 : 3)); cyaw = angLerp(cyaw, Math.hypot(dx, dz) < .01 ? cyaw : wy, f); cpitch = lerp(cpitch, wp, f);
      cpitch -= .0; const bow = .38 * g; cy -= .12 * g;
      camera.position.set(cx + rand(-sh, sh), cy + rand(-sh, sh), cz + rand(-sh, sh)); camera.rotation.set(cpitch - bow, cyaw, Math.sin(t * 2.1) * .01 + g * .05);
    } else if (t < tS) {
      const s = ease(prog(t, tD0, tD1)); cx = lerp(ox, seatX, s); const gy = profileY(S, rampEnd, hingeX, cx); cy = gy + (cx > hingeX ? EYE - .38 : EYE) - (cx > hingeX ? 0 : 0);
      const bob = Math.sin(s * 70) * .045 * Math.sin(s * Math.PI);
      camera.position.set(cx, cy + bob, Math.sin(s * 35) * .05); camera.rotation.set(Math.sin(s * 40) * .02, -Math.PI / 2 + Math.sin(s * 25) * .05, Math.sin(s * 35) * .04); cyaw = -Math.PI / 2; cpitch = 0;
    } else {
      V.g.updateMatrixWorld(true); _cw.set(0, hf + 1.3, -S.L / 2 + S.cabL - .8); V.g.localToWorld(_cw); const turn = pe(t, tS + .3, tS + 1.7), yaw = lerp(-Math.PI / 2, Math.PI / 2, turn) + (V.g.rotation.y - Math.PI / 2);
      camera.position.set(_cw.x + rand(-sh, sh), _cw.y + rand(-sh, sh), _cw.z + rand(-sh, sh)); camera.rotation.set(rand(-sh, sh) * .6, yaw, Math.sin(t * 6) * sh); cx = _cw.x;
    }
    // soldiers
    const ph = prog(t, tSol, tSol + tRun);
    if (t < tD0) {
      for (const [s, sg] of [[A, -1], [B, 1]]) {
        if (t < tSol) { s.g.visible = false; continue; } s.g.visible = true;
        const u = ph, x0 = hingeX + 1.6, x1 = ox + 1.0 + (sg < 0 ? 0 : .15), x = lerp(x0, x1, u), zz = sg * lerp(.7, 1.15, prog(x, rampEnd, ox + 1)) , dx = x1 - x0;
        s.g.position.set(x, profileY(S, rampEnd, hingeX, x), zz); s.g.rotation.y = u < 1 ? Math.atan2(-1, 0) : yawOf(0, 0) * 0 + Math.atan2(-1, 0) * 0 + (-Math.PI / 2) ; if (u >= 1) s.g.rotation.y = Math.atan2(0, sg > 0 ? -1 : 1) ; animSol(s, dt, u < 1 ? 6 : 0, false);
        if (u >= 1) s.g.rotation.y = sg < 0 ? 0 : Math.PI;
      }
    } else if (t < tS) {
      for (const [s, sg] of [[A, -1], [B, 1]]) { s.g.visible = true; const x = camera.position.x + .1, gy = profileY(S, rampEnd, hingeX, camera.position.x); s.g.position.set(x, gy, sg * 1.0); s.g.rotation.y = Math.PI / 2; animSol(s, dt, 6, false); }
    } else {
      if (!seated) { seated = true; for (const [s, sg] of [[A, -1], [B, 1]]) { V.g.add(s.g); s.g.position.set(sg * (S.W / 2 - .55), hf - .2, -S.L / 2 + 2.2); s.g.rotation.y = -sg * Math.PI / 2; animSol(s, dt, 0, true); s.g.position.y = hf - .2; } }
      for (const s of [A, B]) animSol(s, 0, 0, true), s.g.position.y = hf - .2;
    }
    // grab hands
    const gk = t < tGrab ? 0 : t < tS ? pe(t, tGrab, tGrab + .35) : 1 - pe(t, tS, tS + .6); const jolt = Math.sin(clamp(t - tGrab, 0, 1) * 18) * Math.exp(-(t - tGrab) * 5) * (t >= tGrab ? 1 : 0);
    placeGrab(gk, jolt); if (t >= tGrab && t < tGrab + .05) { cineSound('grab'); capText(pickV(['"ÇABUK, ÇIKIYORUZ!"', '"SENİ BULDUK, YÜRÜ!"', '"GÖREV TAMAM, KALKIYORUZ!"', '"TUT BENİ, GİDİYORUZ!"']), 2.2); }
    if (t >= tL && t < tL + .06) cineSound('thud'); if (t >= tL - .4 && t < tL - .34) cineSound('ramp'); if (t >= tS + 1.0 && t < tS + 1.06) cineSound('ramp'); if (t >= tD0 - .1 && t < tD0) camera.rotation.z += .08;
    // weapon and left hand
    const vmV = t < tS; const vm = VMS[P.cur], ud = vm.userData; VMS.forEach((m, i) => m.visible = vmV && i === P.cur); LH.visible = vmV;
    if (vmV) {
      vm.position.copy(ud.hip); vm.rotation.set(0, 0, 0); resetParts(ud); const low = Math.max(g, t >= tD0 ? .8 : 0); vm.position.y -= low * .5; vm.rotation.x += low * .55; vm.position.x += low * .1 + (t >= tGrab ? .05 : 0);
      vm.position.y += Math.sin(t * 1.4) * .0015; HAND.copy(ud.lh); placeLeftHand(vm, g);
    }
    // engine sound
    const dist = Math.hypot(camera.position.x - vx, camera.position.y - vy); const inside = t > tS - .6;
    eng.vol(inside ? .5 : clamp(1.15 - dist / 170, .08, 1)); eng.pitch((air ? 1 : .9) + (t < tL ? .25 * (1 - prog(t, 5, tL)) : 0) + (t > tT ? .3 * Math.min(1, tk / 2) : 0));
    // exterior shot for the victory cut
    if (mode === 'win' && t > tExt) {
      const e = t - tExt, fx = Vx + .5 * 1.4 * Math.pow(tk, 3) * .2, fy = vy, camx = Vx - 38 + e * 7, camy = 3.5 + e * .6;
      V.g.updateMatrixWorld(true); camera.position.set(camx, camy, 24); const tx = V.g.position.x, ty = V.g.position.y + 2, tz = 0, dx = tx - camx, dz = tz - 24;
      camera.rotation.set(Math.atan2(ty - camy, Math.hypot(dx, dz)), yawOf(dx, dz), 0); camera.fov = lerp(75, 42, prog(e, 0, 7)); camera.updateProjectionMatrix(); vm.visible = false; LH.visible = false;
      if (air) { V.g.position.x += e * e * 3; V.g.position.y += e * e * 1.2; V.g.rotation.z = .05 * Math.sin(e); } else V.g.position.x += e * e * 3;
      if (e > .05 && e < .1) V.setRamp(0);
      eng.vol(clamp(1.2 - e / 9, .1, 1)); lidsOverlay(0, 0);
      $('fade').style.transition = 'none'; $('fade').style.opacity = pe(t, end - 1.6, end);
    } else if (mode !== 'win' || t <= tExt) { const f = pe(t, tT + 2.4, tT + 3.6); if (mode !== 'win') { $('fade').style.transition = 'none'; $('fade').style.opacity = f; } else { $('fade').style.opacity = 0; } }
    if (t < 1.2 && mode !== 'win') { $('fade').style.transition = 'none'; $('fade').style.opacity = 1 - pe(t, .2, 1.2); }
    if (t < 1.2 && mode === 'win') { $('fade').style.transition = 'none'; $('fade').style.opacity = 1 - pe(t, .2, 1.2); }
    skyMesh.position.copy(camera.position);
  };
}

// ---- arrival: you wake inside the vehicle, the ramp opens, the soldiers push you out ----
function startArrive(vk, first) {
  beginCine(); const S = VSPEC[vk], V = buildVehicle(vk), air = S.air, hf = S.hf;
  const rampEnd = LZ.x + 2.0, hingeX = rampEnd + V.rampRun, Vx = hingeX + S.L / 2, seatX = hingeX + S.cabL - .8;
  scene.add(V.g); V.g.position.set(Vx, 0, 0); V.g.rotation.y = Math.PI / 2; V.setRamp(0); if (vk === 'plane') V.setTilt(1);
  const A = friendlySoldier(), B = friendlySoldier(); for (const [s, sg] of [[A, -1], [B, 1]]) { V.g.add(s.g); s.g.position.set(sg * (S.W / 2 - .55), hf - .2, -S.L / 2 + 2.2); s.g.rotation.y = -sg * Math.PI / 2; animSol(s, 0, 0, true); s.g.position.y = hf - .2; scene.visible = true; }
  const eng = startEngine(S.eng); P.pos.set(LZ.x, 0, 0);
  const tJ = 3.4, tO = 4.2, tStand = tO + 1.4, tGrab = tO + 3.0, tD0 = tGrab + .5, tD1 = tD0 + 3.2, tBack = tD1 + .4, tClose = tD1 + 3.4, tT = tD1 + 5.4, end = tT + 6.5;
  let stood = false, back = false, ret = false; const side2 = Math.random() < .5 ? -1 : 1, bank2 = side2 * rand(.12, .38), hopK = rand(.6, 1.5), wake0 = rand(-.7, -.3);
  C = { kind: 'arrive', t: 0, V, A, B, eng, end };
  $('fade').style.transition = 'none'; $('fade').style.opacity = 1;
  C.update = dt => {
    const t = C.t += dt;
    if (t >= end) { const o = C; disposeCine(o); C = null; arriveDone(); return; }
    const tk = Math.max(0, t - tT);
    V.g.position.set(Vx + (air ? (tk > 2.2 ? .5 * 2.2 * Math.pow(tk - 2.2, 2) : 0) : .5 * 2.4 * tk * tk), air ? .5 * 3.0 * tk * tk : 0, side2 * .55 * tk * tk); V.body.rotation.x = air && tk > 1 ? -.08 * prog(tk, 1, 3) : 0; V.body.rotation.z = air ? bank2 * prog(tk, .5, 3) : 0;
    V.tick(dt, (air ? 30 : 20) * (t < tJ ? 1 : .6 + .4 * (1 - prog(t, tJ, tJ + 3))) * (tk > 0 ? 1.4 : 1), air ? 0 : (tk > 0 ? 24 : 0));
    V.setRamp(t < tO ? 0 : t < tClose ? pe(t, tO, tO + 1.8) : 1 - pe(t, tClose, tClose + 1.8));
    const shake = (t < tJ ? .018 : .006) + (t >= tJ && t < tJ + .5 ? (1 - (t - tJ) * 2) * .08 : 0) + (tk > 0 ? .012 : 0);
    if (t >= tJ && t < tJ + .05) cineSound('thud'); if (t >= tO && t < tO + .05) { cineSound('ramp'); $('fade').style.transition = 'none'; $('fade').style.opacity = .85; } if (t >= tClose && t < tClose + .05) cineSound('ramp');
    if (t >= tO + .05 && t < tO + 2.6) { $('fade').style.transition = 'opacity 1.6s ease-out'; $('fade').style.opacity = 0; }
    if (t < 1.4) { $('fade').style.transition = 'none'; $('fade').style.opacity = 1 - pe(t, .1, 1.4); }
    if (t > .5 && t < .56) capText(MAP.name + ' · ' + MAP.sub, 3.2);
    // camera
    let cx, cy, cz = 0, yaw, pitch = 0, roll = 0, inside = true;
    const standY = S.hf + 1.3;
    if (t < tD0) {
      V.g.updateMatrixWorld(true); _cw.set(0, hf + 1.3, -S.L / 2 + S.cabL - .8); V.g.localToWorld(_cw); cx = _cw.x; cy = _cw.y; cz = _cw.z; yaw = Math.PI / 2;
      const wake = pe(t, 0, 1.6); pitch = (1 - wake) * wake0 + Math.sin(t * .7) * .02; roll = (1 - wake) * .15;
      if (t > tStand) { const sk = pe(t, tStand, tStand + .8); cy += sk * (EYE - 1.3); }
    } else if (t < tD1) {
      const s = ease(prog(t, tD0, tD1)); cx = lerp(seatX, LZ.x, s); const gy = profileY(S, rampEnd, hingeX, cx); cy = gy + (cx > hingeX ? EYE - .0 : EYE); cy += Math.sin(s * 70) * .045 * Math.sin(s * Math.PI); yaw = Math.PI / 2 + Math.sin(s * 25) * .05; roll = Math.sin(s * 35) * .04; pitch = Math.sin(s * 40) * .02 - .05 * (1 - s) * Math.sin(s * Math.PI);
      if (s > .85) pitch += -.14 * hopK * Math.sin((s - .85) / .15 * Math.PI); // the landing hop
      if (s > .85) cy -= .08 * Math.sin((s - .85) / .15 * Math.PI); inside = cx < hingeX;
    } else {
      cx = LZ.x; cy = EYE; const look = pe(t, tBack + .2, tBack + 1.8) * (1 - pe(t, tT + 3.2, tT + 5.2));
      yaw = lerp(Math.PI / 2, -Math.PI / 2 + (air ? 0 : 0), look); pitch = (air && tk > 1.2 ? .42 * pe(tk, 1.2, 3.5) * look : 0) - .0; inside = false;
      const gk2 = air ? pe(t, tClose + .2, tClose + 1.2) * (1 - pe(t, tT + 4.2, tT + 5.6)) : 0; pitch -= .28 * gk2; cy -= .1 * gk2; roll = .05 * gk2;
      lidsOverlay(.4 * gk2 * (tk > 0.6 ? 1 : 0), gk2 * .7); C.g = gk2;
      dustBlast(V.g.position.x, 0, air ? (tk > 0 && tk < 4 ? clamp(1 - V.g.position.y / 22, 0, 1) : (t > tClose && t < tT ? .35 : 0)) : (tk > 0 && tk < 3 ? .8 : 0), dt, true);
    }
    if (t < tD1) lidsOverlay(0, 0);
    camera.position.set(cx + rand(-shake, shake), cy + rand(-shake, shake), cz + rand(-shake, shake)); camera.rotation.set(pitch, yaw, roll);
    // soldiers: stand up, flank the player, then climb back in
    if (t >= tStand && !stood) { stood = true; for (const s of [A, B]) { scene.attach(s.g); } capText(pickV(['"HADİ HADİ, İNİN İNİN!"', '"HAREKET! HAREKET!"', '"YENİ CEPHE, AYAĞA KALK ASKER!"', '"UYAN ŞAMPİYON, VARDIK!"']), 2.4); }
    for (const [s, sg] of [[A, -1], [B, 1]]) {
      if (t < tStand) { animSol(s, 0, 0, true); s.g.position.y = hf - .2; continue; }
      if (t < tD0) { const u = pe(t, tStand, tD0 - .2); const x = lerp(s.g.position.x, seatX - 1.3, u * .12 + .02), z = lerp(s.g.position.z, sg * .85, .05); s.g.position.set(x, hf, z); s.g.rotation.y = -Math.PI / 2 * 0 + (sg < 0 ? 0 : Math.PI); animSol(s, dt, 0, false); }
      else if (t < tD1) { const px = camera.position.x; s.g.position.set(px + .1, profileY(S, rampEnd, hingeX, px), sg * 1.0); s.g.rotation.y = -Math.PI / 2; animSol(s, dt, 6, false); }
      else if (t < tBack + 3.0 || !ret) {
        const u = prog(t, tBack, tBack + 3.0); const x = lerp(LZ.x + 1.0, seatX - .8, ease(u)); s.g.visible = true;
        s.g.position.set(x, profileY(S, rampEnd, hingeX, x), sg * lerp(1.1, .75, prog(x, rampEnd, LZ.x + 1))); s.g.rotation.y = Math.PI / 2; animSol(s, dt, u < 1 ? 6 : 0, false);
        if (u >= 1 && !s.in) { s.in = true; V.g.attach(s.g); }
      }
      if (s.in) { s.g.position.set(sg * (S.W / 2 - .55), hf - .2, -S.L / 2 + 2.2); s.g.rotation.y = -sg * Math.PI / 2; animSol(s, 0, 0, true); s.g.position.y = hf - .2; }
    }
    // grab hands: they shove you out
    const gk = t < tGrab ? 0 : t < tD1 ? pe(t, tGrab, tGrab + .35) : 1 - pe(t, tD1, tD1 + .5); const jolt = Math.sin(clamp(t - tGrab, 0, 1) * 18) * Math.exp(-(t - tGrab) * 5) * (t >= tGrab ? 1 : 0);
    placeGrab(gk, jolt); if (t >= tGrab && t < tGrab + .05) cineSound('grab');
    // weapon shows up when you are on the ground
    const vmV = t > tD1 - .6 && !(t > tD1 && C.g > .3); const vm = VMS[P.cur], ud = vm.userData; VMS.forEach((m, i) => m.visible = vmV && i === P.cur); LH.visible = vmV;
    if (vmV) { const k = pe(t, tD1 - .6, tD1 + .4); vm.position.copy(ud.hip); vm.rotation.set(0, 0, 0); resetParts(ud); vm.position.y -= (1 - k) * .6 + (C.g || 0) * .5; vm.rotation.x += (1 - k) * .8 + (C.g || 0) * .55; HAND.copy(ud.lh); placeLeftHand(vm, C.g || 0); }
    eng.vol(inside ? .5 : clamp(1.1 - Math.abs(camera.position.x - V.g.position.x) / 150 - V.g.position.y / 160, .05, 1)); eng.pitch((air ? 1 : .9) + (tk > 0 ? .35 * Math.min(1, tk / 2) : 0) - (t > tJ && t < tJ + 3 ? .2 * prog(t, tJ, tJ + 3) : 0));
    skyMesh.position.copy(camera.position);
  };
}
function arriveDone() {
  P.pos.set(LZ.x, 0, 0); P.yaw = Math.PI / 2; P.pitch = 0; P.vx = P.vz = 0; P.swT = .45; P.nextWeap = P.cur; for (const m of VMS) m.visible = false;
  endCine(); G.breakT = 2.5; message(MAP.name, MAP.sub); if (!G.arena) spawnSquad(LOBBY.squad);
}

// ---- paratrooper arrival: the transport flies over, the soldiers throw you out, you pull the chute ----
document.addEventListener('keydown', e => { if (C && C.kind === 'drop' && (e.code === 'Space' || e.code === 'KeyE' || e.code === 'Enter')) C.pull = true; });
document.addEventListener('pointerdown', e => { if (C && C.kind === 'drop' && !(e.target && e.target.id === 'skip')) C.pull = true; });
function buildChute() {
  const g = new THREE.Group(), m1 = new THREE.MeshStandardMaterial({ color: 0xe8e2d0, roughness: .9, side: THREE.DoubleSide }), m2 = new THREE.MeshStandardMaterial({ color: 0xc8501e, roughness: .9, side: THREE.DoubleSide });
  const dome = new THREE.Mesh(new THREE.SphereGeometry(4.2, 20, 8, 0, Math.PI * 2, 0, Math.PI * .42), m1); dome.scale.y = .62; dome.position.y = 6.2; g.add(dome);
  const stripe = new THREE.Mesh(new THREE.SphereGeometry(4.22, 20, 8, 0, Math.PI * .5, 0, Math.PI * .42), m2); stripe.scale.y = .62; stripe.position.y = 6.2; g.add(stripe);
  const stripe2 = new THREE.Mesh(new THREE.SphereGeometry(4.22, 20, 8, Math.PI, Math.PI * .5, 0, Math.PI * .42), m2); stripe2.scale.y = .62; stripe2.position.y = 6.2; g.add(stripe2);
  const pts = []; for (let i = 0; i < 12; i++) { const a = i / 12 * Math.PI * 2; pts.push(new THREE.Vector3(Math.cos(a) * 3.9, 6.2 + 4.2 * .62 * Math.cos(Math.PI * .42) - 0.05, Math.sin(a) * 3.9), new THREE.Vector3(Math.sin(a * 2) * .06, 1.7, Math.cos(a * 2) * .06)); }
  const lg = new THREE.BufferGeometry().setFromPoints(pts); g.add(new THREE.LineSegments(lg, new THREE.LineBasicMaterial({ color: 0xdddddd })));
  return g;
}
function startDrop(vk) {
  if (!VSPEC[vk] || !VSPEC[vk].air) vk = 'plane';
  beginCine(); const S = VSPEC[vk], V = buildVehicle(vk), hf = S.hf, L = S.L; scene.add(V.g); V.setRamp(0); if (vk === 'plane') V.setTilt(0);
  const A = friendlySoldier(), B = friendlySoldier(), PF = friendlySoldier(); PF.g.traverse(o => { if (o.isMesh && o.material && o.material.color && !o.material.isMeshBasicMaterial) { o.material = o.material.clone(); o.material.color.offsetHSL(-.55, .1, .12); } });
  for (const s of [A, B, PF]) { V.g.add(s.g); }
  const CH = buildChute(); CH.visible = false; scene.add(CH);
  const eng = startEngine(S.eng === 'rotor' ? 'jet' : S.eng), eng2 = startEngine('jet');
  const Y = 138, Vp = vk === 'plane' ? 72 : 52, tRamp = 2.9, tWalk = 4.6, tR = 7.0, tFall = 3.0;
  const rr = V.rampRun, zr = -L / 2;
  const xr = LZ.x - 98, pxR = xr + L / 2 + rr * .55 + .4, px0 = pxR - Vp * tR;
  const side = Math.random() < .5 ? 1 : -1;
  let phase = 0, fx = 0, fy = 0, fz = 0, fvx = 0, fvy = 0, fvz = 0, tFreeStart = 0, cOpen = 0, cx0 = 0, cy0 = 0, cz0 = 0, landT = 0, pdone = false, released = false, camP = new THREE.Vector3(), camL = new THREE.Vector3(), cinit = false, tum = rand(2, 4), tumz = rand(-3, 3);
  const end = 40; C = { kind: 'drop', t: 0, V, A, B, PF, CH, eng, eng2, end, pull: false };
  $('fade').style.transition = 'none'; $('fade').style.opacity = 1;
  const planeX = t => t < tR ? px0 + Vp * t : pxR + Vp * (t - tR) + 9 * Math.pow(t - tR, 2), planeY = t => t < tR ? Y : Y + 3.2 * Math.pow(t - tR, 2) * .5;
  C.update = dt => {
    const t = C.t += dt; if (t >= end) { const o = C; disposeCine(o); C = null; arriveDone(); return; }
    // aircraft
    const px = planeX(t), py = planeY(t); V.g.position.set(px, py, 0); V.g.rotation.y = Math.PI / 2; V.body.rotation.x = t > tR + .5 ? -.12 * prog(t, tR + .5, tR + 3) : 0; V.body.rotation.z = Math.sin(t * 1.3) * .015;
    V.tick(dt, 40, 0); V.setRamp(t < tRamp ? 0 : t < tR + 1.6 ? pe(t, tRamp, tRamp + 1.8) : 1 - pe(t, tR + 1.6, tR + 3.4));
    // soldiers + player on the ramp (vehicle local space)
    const wk = prog(t, tWalk, tR - .15), zloc = lerp(zr + 2.6, zr - rr * .55, ease(wk)), yloc = (z => z > zr ? hf : hf * (1 - clamp((zr - z) / rr, 0, 1)))(zloc);
    if (!released) {
      PF.g.position.set(0, yloc, zloc); PF.g.rotation.set(0, Math.PI, 0); animSol(PF, dt, wk > 0 && wk < 1 ? 3 : 0, false);
      const lean = t > tR - .5 && t < tR ? .5 : 0, thr = prog(t, tR - .45, tR);
      for (const [s, sg] of [[A, -1], [B, 1]]) { s.g.position.set(sg * (.95 - .3 * thr), yloc, zloc + .1); s.g.rotation.set(0, Math.PI, sg * lean * .3); animSol(s, dt, wk > 0 && wk < 1 ? 3 : 0, t < tWalk - .8 ? false : false); if (t < tWalk - .8) { s.g.position.set(sg * (S.W / 2 - .55), hf - .2, zr + 2.6); s.g.rotation.set(0, -sg * Math.PI / 2, 0); animSol(s, 0, 0, true); s.g.position.y = hf - .2; } }
      if (t < tWalk - .8) { PF.g.position.set(0, hf, zr + 2.6); PF.g.rotation.set(0, Math.PI, 0); }
      if (t >= tWalk && t < tWalk + .06) cineSound('grab');
    } else if (t > tR + .4) { for (const [s, sg] of [[A, -1], [B, 1]]) { const u = ease(prog(t, tR + .4, tR + 2.4)), z2 = lerp(zr - rr * .55, zr + 2.6, u); s.g.position.set(sg * lerp(.7, S.W / 2 - .55, u), z2 > zr ? hf - .1 * u : yloc, z2); s.g.rotation.set(0, u < 1 ? 0 : -sg * Math.PI / 2, 0); animSol(s, dt, u < 1 ? 3 : 0, u >= 1); } }
    // release
    if (!released && t >= tR) {
      released = true; V.g.updateMatrixWorld(true); const w = new THREE.Vector3(); PF.g.getWorldPosition(w); scene.attach(PF.g); PF.g.position.copy(w); fx = w.x; fy = w.y; fz = w.z; fvx = Vp * .85; fvy = -3; fvz = 0; tFreeStart = t; cineSound('grab'); capText(pickV(['"İYİ ŞANSLAR ASKER!"', '"CEPHEDE GÖRÜŞÜRÜZ!"', '"ÇEK İPİ, ÇEK İPİ!"']), 2.2); setTimeout(() => { if (C && C.kind === 'drop' && !C.CHopen) capText('PARAŞÜTÜ AÇ!  (SPACE / DOKUN)', 2.6); }, 1100);
    }
    // free fall -> chute -> glide to LZ
    let spd = 0, onChute = false;
    if (released && !cOpen) {
      const ft = t - tFreeStart; fvy = Math.max(-52, fvy - 9.8 * dt * 1.15); fvx = lerp(fvx, 0, 1 - Math.exp(-dt * 1.1)); fx += fvx * dt; fy += fvy * dt; fz += 0; spd = -fvy;
      PF.g.position.set(fx, fy, fz); PF.g.rotation.set(Math.sin(ft * 3.1) * .7 + (ft < .9 ? ft * tum : 0), Math.PI / 2 + Math.sin(ft * 2) * .5, Math.sin(ft * 4) * .5 + tumz * Math.min(ft, .6));
      if ((C.pull && ft > .9) || ft > tFall) { cOpen = t; cx0 = fx; cy0 = fy; cz0 = fz; C.CHopen = true; CH.visible = true; cineSound('thud'); cineSound('ramp'); capText('"PARAŞÜT AÇILDI!"', 1.8); }
    } else if (cOpen) {
      onChute = true; const ct = t - cOpen, y1 = Math.max(6, cy0 - 22.05), Dd = Math.max(2.5, y1 / 6.5), u = prog(ct, .9, .9 + Dd), k = ease(prog(ct, 0, .9 + Dd));
      fx = lerp(cx0, LZ.x, k); fz = lerp(cz0, 0, k); fy = ct < .9 ? cy0 - (40 * ct - 31 * ct * ct / 1.8) : y1 * (1 - u); spd = ct < .9 ? lerp(40, 9, pe(ct, 0, .9)) : 6.5;
      PF.g.position.set(fx, fy, fz); const sw = Math.sin(ct * 1.6) * .1 * (1 - pe(ct, .9 + Dd * .8, .9 + Dd)); PF.g.rotation.set(sw * .6, Math.PI / 2, sw);
      const op = pe(ct, 0, .8); CH.position.set(fx, fy, fz); CH.scale.set(.2 + .8 * op, .1 + .9 * op, .2 + .8 * op); CH.rotation.set(sw * .9, ct * .12, sw * .6);
      if (u >= 1 && !pdone) { pdone = true; landT = t; fy = 0; }
    }
    const dropFade = 0;
    // soldiers waving as plane leaves is implicit; engine sounds
    const pcam = onChute || (released && cOpen) ? new THREE.Vector3(fx, fy, fz) : new THREE.Vector3(px, py, 0);
    // ---- camera ----
    let shake = .012;
    const tCut = 2.4;
    if (t < tCut) {
      const a = camera.position; camera.position.set(LZ.x - 30, 1.7, 9); camLookAt(px, py + 2, 0); camera.fov = lerp(75, 42, pe(t, 0, tCut)); camera.updateProjectionMatrix();
      const near = clamp(1 - Math.abs(px - camera.position.x) / 420, 0, 1); shake = .004 + near * .05;
    } else if (!released || t < tR + .15) {
      camera.fov = 62; camera.updateProjectionMatrix(); const ck = pe(t, tCut, tCut + 1.2), wob = Math.sin(t * 1.3) * 1.5;
      camP.set(px - 5 + wob, py + 2.2 + Math.sin(t * .9), 25 * side); camL.set(px + zr + 1.2 + L / 2 * 0 - 2, py + .6, 0); camera.position.copy(camP); camLookAt(camL.x, camL.y, camL.z); shake = .014;
    } else if (!cOpen || t - cOpen < 1.8) {
      const ct = cOpen ? t - cOpen : 0; camera.fov = lerp(62, 70, pe(t, tR, tR + 1)); camera.updateProjectionMatrix();
      const target = new THREE.Vector3(fx - 4, fy + 2.5, 15 * side); if (!cinit) { camera.position.copy(camP); cinit = true; } camera.position.lerp(target, 1 - Math.exp(-dt * 3.2)); camLookAt(fx + 1, fy + (cOpen ? 3 : 0), 0); shake = .01 + (cOpen && ct < .7 ? (1 - ct / .7) * .12 : 0) + (cOpen ? 0 : .02 + spd / 52 * .03);
    } else {
      const ct = t - cOpen, fp = pe(ct, 1.8, 3.6), dropK = clamp(fy / 30, 0, 1);
      const tp = new THREE.Vector3(fx - 3.5, fy + 1.2, 11 * side * (1 - fp)); const eye = new THREE.Vector3(fx, fy + 1.55, fz); camera.position.lerp(tp, 1 - Math.exp(-dt * 3)); camera.position.lerp(eye, fp * .25 + (fp >= 1 ? 1 : 0));
      const fwd = new THREE.Vector3(fx - 8 + (fp) * 0, fy + 1.55 - 6 * fp - 1 * (1 - fp), 0); camLookAt(lerp(fx + 1, LZ.x - 26, fp), lerp(fy, 3, fp), lerp(0, 0, fp)); shake = .006 + (ct > 6 ? .01 : 0); PF.g.visible = fp < .85;
      if (fp >= .5) { camera.rotation.z += Math.sin(ct * 1.6) * .03 * (1 - fp * .3); }
      // landing flare
      if (pdone) { const lt = t - landT; const dip = Math.sin(clamp(lt / .5, 0, 1) * Math.PI) * .45; camera.position.y -= dip; camera.rotation.x -= Math.sin(clamp(lt / .5, 0, 1) * Math.PI) * .14; if (lt < .06) { cineSound('thud'); dustBlast(LZ.x, 0, 1.2, dt * 6, false); } dustBlast(LZ.x, 0, clamp(1 - lt, 0, 1) * .5, dt, false); const cl = pe(lt, .2, 1.6); CH.position.set(LZ.x + cl * 3, 0, 0); CH.scale.set(1 + cl, Math.max(.02, 1 - cl), 1 + cl); if (lt > 1.9) CH.visible = false; }
      // weapon comes up after the landing
      const vmV = pdone && t - landT > .3; const vm = VMS[P.cur], ud = vm.userData; VMS.forEach((m, i) => m.visible = vmV && i === P.cur); LH.visible = vmV;
      if (vmV) { const k = pe(t, landT + .3, landT + 1.4); vm.position.copy(ud.hip); vm.rotation.set(0, 0, 0); resetParts(ud); vm.position.y -= (1 - k) * .6; vm.rotation.x += (1 - k) * .8; HAND.copy(ud.lh); placeLeftHand(vm, 0); }
    }
    camera.position.x += rand(-shake, shake); camera.position.y += rand(-shake, shake); camera.position.z += rand(-shake, shake);
    // fades
    if (t < 1.1) { $('fade').style.transition = 'none'; $('fade').style.opacity = 1 - pe(t, .1, 1.1); }
    if (t > tCut - .15 && t < tCut + .45) { $('fade').style.transition = 'none'; $('fade').style.opacity = .85 * Math.sin(prog(t, tCut - .15, tCut + .45) * Math.PI); }
    if (pdone && t - landT > 1.6) { lidsOverlay(0, 0); C.t = Math.max(C.t, end - .01); }
    // audio
    const dist = camera.position.distanceTo(V.g.position); eng.vol(clamp(1.35 - dist / 330, .05, 1) * (t < tCut ? 1.1 : 1)); eng.pitch(1 + .3 * clamp(1 - (px - camera.position.x) / 300, 0, 1) - (t < tCut ? 0 : .12));
    eng2.vol(released ? clamp(spd / 55, 0, 1) * (cOpen ? .25 : .55) : 0); eng2.pitch(.35 + spd / 90);
    skyMesh.position.copy(camera.position);
    if (t > .6 && t < .66) capText(pickV(['\"SİNYAL ALINDI. İNDİRME NOKTASI HAZIR\"', 'GİRİŞ UÇUŞU · ' + MAP.name, '\"HAVAYOLUYLA GELİYORUZ\"']), 2.4);
    if (pdone && t - landT > .6 && t - landT < .66) capText(MAP.name + ' · ' + MAP.sub, 3);
  };
}
const _lk = new THREE.Vector3();
function camLookAt(x, y, z) { const p = camera.position, dx = x - p.x, dy = y - p.y, dz = z - p.z, h = Math.hypot(dx, dz); camera.rotation.set(Math.atan2(dy, h), h < .001 ? camera.rotation.y : yawOf(dx, dz), 0); }
// ---- loading screen: the map is built behind it ----
const TIPS = ['Tüccardan varyant satın al: her yeni harita bir üst varyantın kilidini açar.', 'İkram kutuları her 2 dalgada bir düşer. İçinde özel silahlar çıkabilir.', 'Koşarken C: kayarak hem hızlan hem siperden çık.', 'Birleştirilen ek parçalar daha güçlüdür. Envanterdeki birleştirme alanına bak.', 'Tankı onarıp kullanabilirsin. Shift ile tek dokunuşla 1. şahıs.', 'Keskin nişancılar seni kırmızı lazerle işaretler: siper al.'];
function runLoading(mapIdx, vk) {
  const ld = $('loading'), fill = $('ldFill'); ld.hidden = false; $('ldTitle').textContent = 'YÜKLENİYOR...'; $('ldMap').textContent = MAPS[mapIdx].name + ' · ' + MAPS[mapIdx].sub; $('ldTip').textContent = TIPS[randi(0, TIPS.length - 1)]; fill.style.width = '6%';
  $('fade').style.transition = 'none'; $('fade').style.opacity = 1;
  setTimeout(() => { fill.style.width = '38%'; }, 500);
  setTimeout(() => { fill.style.width = '70%'; }, 1300);
  setTimeout(() => {
    try { removeMerchant(); clearLoot(); clearEnemies(); clearTanks(); fires.length = 0; P.inTank = false; loadMap(mapIdx); } catch (e) { reportErr(e); }
    fill.style.width = '100%'; $('ldTitle').textContent = 'HAZIR';
    setTimeout(() => { ld.hidden = true; startDrop(pickV(['plane', 'plane', 'heli', 'gunship'])); }, 1300);
  }, 2300);
}
// ---- extraction point ----
let lz = null;
function showLZ() {
  hideLZ(); const g = new THREE.Group(), m = new THREE.MeshBasicMaterial({ color: 0x66ccff, transparent: true, opacity: .3, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide });
  const beam = new THREE.Mesh(new THREE.CylinderGeometry(.9, .9, 60, 12, 1, true), m); beam.position.y = 30; g.add(beam); const ring = new THREE.Mesh(new THREE.RingGeometry(4.6, 5.2, 40), new THREE.MeshBasicMaterial({ color: 0x66ccff, transparent: true, opacity: .6, side: THREE.DoubleSide, depthWrite: false })); ring.rotation.x = -Math.PI / 2; ring.position.y = .08; g.add(ring);
  g.position.set(LZ.x, 0, 0); scene.add(g); lz = { g, x: LZ.x, z: LZ.z };
}
function hideLZ() { if (lz) { scene.remove(lz.g); lz = null; } }
// ---- victory credits after the final extraction ----
function cineCredits() {
  cineVisualsOff(); G.state = 'cine'; $('fade').style.transition = 'none'; $('fade').style.opacity = 1; const cr = $('credits'); cr.hidden = false; document.querySelector('.cr2').textContent = G.mode === 'gungame' ? '20 SİLAH · 1 KARAMBİT' : '30 DALGA · 6 CEPHE'; cr.firstElementChild.style.animation = 'none'; void cr.offsetWidth; cr.firstElementChild.style.animation = '';
  $('crStats').textContent = 'Skor ' + G.score + '  ·  Öldürme ' + G.kills + '  ·  Kafadan ' + G.heads; document.body.classList.add('cine'); $('skip').hidden = false;
  C = { kind: 'credits', t: 0, end: 22, eng: null }; C.update = dt => { C.t += dt; if (C.t >= C.end) { C = null; cr.hidden = true; $('fade').style.opacity = 0; document.body.classList.remove('cine'); $('skip').hidden = true; winGame(); } };
}
function skipCine() { if (C) C.t = C.end - .01; }
