// NetEarn Pro Dashboard Referral UI
// Presentation/interaction layer only. Existing referral business logic remains in js/referral.js.
const modal = document.getElementById('dashboardReferralModal');
const codeEl = document.getElementById('dashboardReferralCode');
const userIdEl = document.getElementById('dashboardReferralUserId');
const totalEl = document.getElementById('dashboardReferralTotal');
const incomeEl = document.getElementById('dashboardReferralIncome');
const copyBtn = document.getElementById('dashboardReferralCopy');
const shareBtn = document.getElementById('dashboardReferralShare');

function setReferralData(data = {}) {
  if (userIdEl) userIdEl.textContent = data.userId || 'NE00000';
  if (codeEl) codeEl.textContent = data.referralCode || 'NET00000';
  if (totalEl) totalEl.textContent = String(Number(data.totalReferrals ?? data.referralCount ?? 0) || 0);
  if (incomeEl) incomeEl.textContent = `৳${Number(data.referralCommission ?? 0) || 0}`;
}

function openReferral() {
  if (!modal) return;
  modal.classList.add('show');
  modal.setAttribute('aria-hidden', 'false');
  document.body.classList.add('referral-modal-open');
}

function closeReferral() {
  if (!modal) return;
  modal.classList.remove('show');
  modal.setAttribute('aria-hidden', 'true');
  document.body.classList.remove('referral-modal-open');
}

window.addEventListener('netearn:user-data-ready', event => {
  setReferralData(event.detail?.data || {});
});

window.openDashboardReferral = openReferral;

document.querySelectorAll('[data-referral-close]').forEach(el => {
  el.addEventListener('click', closeReferral);
});

document.addEventListener('keydown', event => {
  if (event.key === 'Escape') closeReferral();
});

if (copyBtn) {
  copyBtn.addEventListener('click', async () => {
    const code = codeEl?.textContent?.trim();
    if (!code || code === 'NET00000') {
      alert('Referral Code পাওয়া যায়নি।');
      return;
    }
    try {
      await navigator.clipboard.writeText(code);
      alert('✅ Referral Code Copied');
    } catch (error) {
      console.error('Referral copy error:', error);
      alert('❌ Copy Failed');
    }
  });
}

if (shareBtn) {
  shareBtn.addEventListener('click', async () => {
    const code = codeEl?.textContent?.trim();
    if (!code || code === 'NET00000') {
      alert('Referral Code পাওয়া যায়নি।');
      return;
    }
    const text = `Join NetEarn Pro 🚀\n\nআমার Referral Code:\n${code}\n\nNetEarn Pro-তে join করে আমার referral code ব্যবহার করুন।`;
    try {
      if (navigator.share) {
        await navigator.share({ title: 'Join NetEarn Pro', text });
      } else if (navigator.clipboard) {
        await navigator.clipboard.writeText(text);
        alert('✅ Invite message copied');
      } else {
        alert(text);
      }
    } catch (error) {
      if (error?.name !== 'AbortError') console.error('Referral share error:', error);
    }
  });
}
