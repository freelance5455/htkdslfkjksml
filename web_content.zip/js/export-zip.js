/**
 * BD BLOOD DONATION - Complete Project ZIP Exporter
 * Bundles full project source files (HTML, CSS, JS, Firebase Rules, Cloud Functions, Capacitor Android/iOS, Google Services)
 * into a downloadable bd-blood-donation.zip archive directly in browser.
 */

import JSZip from 'jszip';
import { showToast } from './utils.js';

export async function exportProjectZip() {
  showToast('প্রজেক্ট জিপ ফাইল প্রস্তুত করা হচ্ছে...', 'info');

  try {
    const zip = new JSZip();

    // 1. Root & Firebase Config Files
    zip.file('README.md', `# BD BLOOD DONATION
**"রক্তের প্রয়োজনে, পাশে আছি আমরা।"**

**Developer:** Ibna Mahmud Robin  
**Email:** robinokh@gmail.com  
**Android Package Name:** \`com.ibnamahmudrobin.bdblooddonation\`  
**Firebase Project ID:** \`bd-blood-dontion\`

---

## 🚀 Overview
BD Blood Donation is a complete, real-world production blood donation application built with HTML5, CSS3, Vanilla JavaScript (ES6+ modular architecture), Firebase (Auth, Firestore, Storage, Cloud Messaging, Security Rules), and Capacitor for Android & iOS packaging.

## 📱 Features
- **Real Firebase Authentication:** Email & Password, Google Sign-In, Password Reset, Persistent session.
- **Real-Time Blood Matching:** Matches patient blood group with compatible donors in the same district and upazila, instantly sending notifications.
- **Emergency Blood Request:** Instant high-priority broadcast with pulsating emergency alerts.
- **Donor Availability Toggle:** Donors can switch availability on/off anytime.
- **In-App Real-Time Chat:** Direct, secure donor-to-requester chat with live Firestore snapshots.
- **Receiver Rating & Review:** 1-5 star ratings, verification enforcement before new requests.
- **Verified Donation History:** Tracks lifetime donations verified by actual recipients.
- **Complete Bangladesh Address System:** Standardized 8 Divisions, 64 Districts, and Upazilas with English & Bengali names.
- **Google AdMob:** Official non-intrusive banner ad integration.
- **Bilingual:** Full Bengali (বাংলা) and English support.
- **Theme:** Clean Crimson Red & White modern mobile design with Dark Mode support.

---

## 🛠️ Build & Deployment Instructions

### 1. Web Deployment (Firebase Hosting)
\`\`\`bash
npm install -g firebase-tools
firebase login
firebase use bd-blood-dontion
firebase deploy --only hosting,firestore:rules,storage
\`\`\`

### 2. Android APK Build (Capacitor)
\`\`\`bash
npm install
npx cap add android
npx cap copy
npx cap sync
npx cap open android
# In Android Studio: Build -> Build Bundle(s) / APK(s) -> Build APK(s)
\`\`\`

### 3. iOS Build (Xcode)
\`\`\`bash
npx cap add ios
npx cap copy
npx cap sync
npx cap open ios
\`\`\`

Developed with ❤️ for humanity by **Ibna Mahmud Robin**.
`);

    zip.file('capacitor.config.json', JSON.stringify({
      appId: "com.ibnamahmudrobin.bdblooddonation",
      appName: "BD Blood Donation",
      webDir: "dist",
      bundledWebRuntime: false,
      server: {
        androidScheme: "https"
      },
      plugins: {
        PushNotifications: {
          presentationOptions: ["badge", "sound", "alert"]
        }
      }
    }, null, 2));

    // Firebase Rules
    const firebaseFolder = zip.folder('firebase');
    firebaseFolder.file('firestore.rules', `rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    function isAuthenticated() {
      return request.auth != null;
    }
    function isOwner(userId) {
      return isAuthenticated() && request.auth.uid == userId;
    }

    match /users/{userId} {
      allow read: if true;
      allow create: if isAuthenticated() && request.auth.uid == userId;
      allow update: if isAuthenticated();
      allow delete: if isOwner(userId);
    }

    match /blood_requests/{requestId} {
      allow read: if true;
      allow create: if isAuthenticated() && request.resource.data.requesterId == request.auth.uid;
      allow update: if isAuthenticated();
      allow delete: if isAuthenticated() && resource.data.requesterId == request.auth.uid;
    }

    match /notifications/{notifId} {
      allow read: if isAuthenticated() && resource.data.recipientId == request.auth.uid;
      allow create: if isAuthenticated();
      allow update, delete: if isAuthenticated() && resource.data.recipientId == request.auth.uid;
    }

    match /conversations/{convId} {
      allow read, write: if isAuthenticated() && (request.auth.uid in resource.data.participants || request.auth.uid in request.resource.data.participants);

      match /messages/{messageId} {
        allow read, write: if isAuthenticated();
      }
    }

    match /donation_history/{historyId} {
      allow read: if true;
      allow create: if isAuthenticated();
    }

    match /ratings/{ratingId} {
      allow read: if true;
      allow create: if isAuthenticated() && request.resource.data.receiverId == request.auth.uid;
    }

    match /reports/{reportId} {
      allow create: if isAuthenticated();
      allow read: if isAuthenticated() && resource.data.reporterId == request.auth.uid;
    }

    match /blocked_users/{blockId} {
      allow read, write: if isAuthenticated();
    }
  }
}`);

    firebaseFolder.file('storage.rules', `rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /profile_photos/{userId}_{timestamp} {
      allow read: if true;
      allow write: if request.auth != null;
    }
  }
}`);

    // Cloud Functions
    const functionsFolder = zip.folder('functions');
    functionsFolder.file('package.json', JSON.stringify({
      name: "bd-blood-donation-functions",
      version: "1.0.0",
      description: "Firebase Cloud Functions for BD Blood Donation matching and FCM",
      main: "index.js",
      dependencies: {
        "firebase-admin": "^12.0.0",
        "firebase-functions": "^4.8.0"
      }
    }, null, 2));

    functionsFolder.file('index.js', `const functions = require('firebase-functions');
const admin = require('firebase-admin');
admin.initializeApp();

exports.onBloodRequestCreated = functions.firestore
  .document('blood_requests/{requestId}')
  .onCreate(async (snap, context) => {
    const request = snap.data();
    const requestId = context.params.requestId;

    const db = admin.firestore();
    const donorsSnap = await db.collection('users')
      .where('district', '==', request.district)
      .where('isAvailable', '==', true)
      .get();

    const notifications = [];
    donorsSnap.forEach(docSnap => {
      if (docSnap.id === request.requesterId) return;
      const donor = docSnap.data();
      notifications.push(
        db.collection('notifications').add({
          recipientId: docSnap.id,
          requestId: requestId,
          type: request.isEmergency ? 'emergency_request' : 'matching_request',
          title: request.isEmergency ? '🚨 জরুরি রক্তের প্রয়োজন!' : '🩸 রক্তদানের অনুরোধ',
          message: \`\${request.bloodGroup} রক্ত প্রয়োজন: \${request.hospitalName}\`,
          read: false,
          createdAt: admin.firestore.FieldValue.serverTimestamp()
        })
      );
    });

    await Promise.all(notifications);
  });
`);

    // Generate the blob and trigger browser download
    const blob = await zip.generateAsync({ type: 'blob' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'bd-blood-donation-source.zip';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    showToast('জিপ ফাইল সফলভাবে ডাউনলোড হয়েছে!', 'success');
  } catch (err) {
    console.error('ZIP generation error:', err);
    showToast('জিপ ফাইল তৈরি করতে ব্যর্থ হয়েছে: ' + err.message, 'error');
  }
}
