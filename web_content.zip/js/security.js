/**
 * Panchal Business Manager - Security, PIN Lock, Role Access & Audit Trail
 */
(function (global) {
  "use strict";

  const I18N = {
    en: {
      securityTitle: "Security, PIN Lock & Role Access",
      securityDesc: "Local PIN lock provides basic device privacy against casual access (stored locally in IndexedDB, not enterprise encryption).",
      pinStatusSet: "Admin PIN is ACTIVE",
      pinStatusNotSet: "No PIN set",
      setPinBtn: "Set / Change PIN",
      removePinBtn: "Remove PIN",
      lockNowBtn: "Lock App Now",
      roleLabel: "Active Access Role",
      roleAdmin: "Owner / Admin (Full Access)",
      roleAccountant: "Accountant (No Delete/Settings)",
      roleStaff: "Site Staff (Billing/Projects/Attendance)",
      auditTitle: "Recent Audit Logs",
      auditEmpty: "No audit records yet.",
      enterNewPin: "Enter 4-digit PIN *",
      confirmPin: "Confirm 4-digit PIN *",
      errPinFormat: "PIN must be exactly 4 digits.",
      errPinMismatch: "PINs do not match.",
      toastPinSaved: "Admin PIN saved.",
      toastPinRemoved: "Admin PIN removed.",
      unlockTitle: "Panchal ERP Locked",
      unlockDesc: "Enter your 4-digit Admin PIN to unlock.",
      unlockBtn: "Unlock",
      errWrongPin: "Incorrect PIN. Try again.",
      toastRestricted: "Action restricted for current role. Switch to Admin in Settings."
    },
    hi: {
      securityTitle: "सुरक्षा, PIN लॉक और स्टाफ़ रोल",
      securityDesc: "लोकल PIN आपके फ़ोन पर बेसिक प्राइवेसी के लिए है (यह सिर्फ़ लोकल IndexedDB में सेव होता है, एंटरप्राइज़ एन्क्रिप्शन नहीं है)।",
      pinStatusSet: "एडमिन PIN चालू है",
      pinStatusNotSet: "कोई PIN सेट नहीं है",
      setPinBtn: "PIN सेट / बदलें",
      removePinBtn: "PIN हटाएँ",
      lockNowBtn: "ऐप लॉक करें",
      roleLabel: "सक्रिय यूज़र रोल (Access Role)",
      roleAdmin: "मालिक / एडमिन (पूरा अधिकार)",
      roleAccountant: "अकाउंटेंट (डिलीट/सेटिंग्स बंद)",
      roleStaff: "साइट स्टाफ़ (बिलिंग/प्रोजेक्ट/हाज़िरी)",
      auditTitle: "ताज़ा ऑडिट लॉग (Audit Trail)",
      auditEmpty: "अभी तक कोई ऑडिट लॉग नहीं है।",
      enterNewPin: "4-अंकों का नया PIN डालें *",
      confirmPin: "PIN दोबारा डालें *",
      errPinFormat: "PIN ठीक 4 अंकों का होना चाहिए।",
      errPinMismatch: "दोनों PIN एक जैसे नहीं हैं।",
      toastPinSaved: "PIN सेव हो गया।",
      toastPinRemoved: "PIN हटा दिया गया।",
      unlockTitle: "Panchal ERP लॉक है",
      unlockDesc: "ऐप खोलने के लिए अपना 4-अंकों का PIN डालें।",
      unlockBtn: "अनलॉक करें",
      errWrongPin: "गलत PIN, कृपया फिर कोशिश करें।",
      toastRestricted: "इस रोल को यह अनुमति नहीं है। Settings में Admin चुनें।"
    }
  };

  const state = {
    pin: "",
    role: localStorage.getItem("pbm_active_role") || "ADMIN",
    isLocked: false
  };

  function tr(key) {
    const lang = global.PBM_APP ? global.PBM_APP.getLang() : "en";
    return (I18N[lang] && I18N[lang][key]) || I18N.en[key] || key;
  }

  function loadSecurityState() {
    return global.PBM_DB.getOne("meta", "adminPin").then(function (rec) {
      state.pin = rec && rec.value ? String(rec.value) : "";
      if (state.pin && !sessionStorage.getItem("pbm_unlocked")) {
        state.isLocked = true;
      }
      renderLockOverlay();
    });
  }

  function renderLockOverlay() {
    let overlay = document.getElementById("pbmLockOverlay");
    if (!state.isLocked || !state.pin) {
      if (overlay) overlay.classList.add("hidden");
      return;
    }

    if (!overlay) {
      overlay = document.createElement("div");
      overlay.id = "pbmLockOverlay";
      overlay.className = "lock-overlay";
      document.body.appendChild(overlay);
    }

    overlay.classList.remove("hidden");
    overlay.innerHTML = `
      <div class="lock-card">
        <div class="brand-monogram" style="margin:0 auto 12px;">PB</div>
        <h2 class="card-title">${tr("unlockTitle")}</h2>
        <p class="card-subtitle">${tr("unlockDesc")}</p>
        <div id="unlockErr" class="form-error hidden" style="margin-top:10px;"></div>
        <form id="unlockForm" class="form-grid" style="margin-top:14px;">
          <input id="unlockPinInput" class="form-input" type="password" inputmode="numeric" maxlength="4" placeholder="••••" style="text-align:center;font-size:1.3rem;letter-spacing:0.4em;" required />
          <button class="primary-btn" type="submit">${tr("unlockBtn")}</button>
        </form>
      </div>
    `;

    document.getElementById("unlockForm").addEventListener("submit", function (event) {
      event.preventDefault();
      const entered = document.getElementById("unlockPinInput").value.trim();
      if (entered === state.pin) {
        state.isLocked = false;
        sessionStorage.setItem("pbm_unlocked", "1");
        renderLockOverlay();
      } else {
        const err = document.getElementById("unlockErr");
        err.textContent = tr("errWrongPin");
        err.classList.remove("hidden");
      }
    });
  }

  function openPinModal() {
    const app = global.PBM_APP;
    const html = `
      <form id="pinSetupForm" class="form-grid" novalidate>
        <div id="pinFormErr" class="form-error hidden"></div>
        <div class="form-group">
          <label class="form-label" for="newPinInput">${tr("enterNewPin")}</label>
          <input id="newPinInput" class="form-input" type="password" inputmode="numeric" maxlength="4" required />
        </div>
        <div class="form-group">
          <label class="form-label" for="confirmPinInput">${tr("confirmPin")}</label>
          <input id="confirmPinInput" class="form-input" type="password" inputmode="numeric" maxlength="4" required />
        </div>
        <div class="modal-actions">
          <button id="pinCancelBtn" class="secondary-btn" type="button">${app.t("cancelBtn")}</button>
          <button class="primary-btn" type="submit">${app.t("saveBtn")}</button>
        </div>
      </form>
    `;
    app.openModal(tr("setPinBtn"), html);
    document.getElementById("pinCancelBtn").addEventListener("click", app.closeModal);

    document.getElementById("pinSetupForm").addEventListener("submit", function (event) {
      event.preventDefault();
      const err = document.getElementById("pinFormErr");
      const p1 = document.getElementById("newPinInput").value.trim();
      const p2 = document.getElementById("confirmPinInput").value.trim();

      if (!/^[0-9]{4}$/.test(p1)) {
        err.textContent = tr("errPinFormat");
        err.classList.remove("hidden");
        return;
      }
      if (p1 !== p2) {
        err.textContent = tr("errPinMismatch");
        err.classList.remove("hidden");
        return;
      }

      global.PBM_DB.put("meta", { key: "adminPin", value: p1, updatedAt: new Date().toISOString() }).then(function () {
        state.pin = p1;
        sessionStorage.setItem("pbm_unlocked", "1");
        app.closeModal();
        app.showToast(tr("toastPinSaved"), false);
        app.renderCurrentRoute();
      });
    });
  }

  function canAccess(permission) {
    if (state.role === "ADMIN") return true;
    if (state.role === "ACCOUNTANT" && (permission === "accounting" || permission === "billing" || permission === "parties")) {
      return true;
    }
    if (state.role === "STAFF" && (permission === "billing" || permission === "projects" || permission === "attendance")) {
      return true;
    }
    return false;
  }

  function renderSettingsSecurityCard(containerEl) {
    const app = global.PBM_APP;
    const businessId = app.getActiveBusinessId();

    return global.PBM_DB.getByBusiness("auditLogs", businessId).then(function (logs) {
      const recentLogs = logs
        .sort(function (a, b) {
          return (b.createdAt || "").localeCompare(a.createdAt || "");
        })
        .slice(0, 20);

      const logsHtml =
        recentLogs.length === 0
          ? `<div class="list-item-meta">${tr("auditEmpty")}</div>`
          : recentLogs
              .map(function (l) {
                return `
                  <div class="ledger-row">
                    <div class="ledger-row-main">
                      <div class="ledger-row-title">${app.escapeHtml(l.action)} · ${app.escapeHtml(l.entity)}</div>
                      <div class="list-item-meta">${app.escapeHtml(l.details)}</div>
                    </div>
                    <div class="list-item-meta">${app.escapeHtml((l.createdAt || "").slice(0, 16).replace("T", " "))}</div>
                  </div>
                `;
              })
              .join("");

      containerEl.innerHTML = `
        <div class="card">
          <h2 class="card-title">${tr("securityTitle")}</h2>
          <p class="card-subtitle">${tr("securityDesc")}</p>
          <div class="list-item-meta" style="margin-top:8px;">
            <strong>${state.pin ? tr("pinStatusSet") : tr("pinStatusNotSet")}</strong>
          </div>
          <div class="btn-row" style="margin-top:10px;">
            <button id="secSetPinBtn" class="primary-btn" type="button">${tr("setPinBtn")}</button>
            ${state.pin ? `<button id="secLockNowBtn" class="secondary-btn" type="button">${tr("lockNowBtn")}</button>` : ""}
            ${state.pin ? `<button id="secRemPinBtn" class="danger-btn" type="button">${tr("removePinBtn")}</button>` : ""}
          </div>
          <div class="form-group" style="margin-top:14px;">
            <label class="form-label" for="secRoleSelect">${tr("roleLabel")}</label>
            <select id="secRoleSelect" class="form-select">
              <option value="ADMIN" ${state.role === "ADMIN" ? "selected" : ""}>${tr("roleAdmin")}</option>
              <option value="ACCOUNTANT" ${state.role === "ACCOUNTANT" ? "selected" : ""}>${tr("roleAccountant")}</option>
              <option value="STAFF" ${state.role === "STAFF" ? "selected" : ""}>${tr("roleStaff")}</option>
            </select>
          </div>
        </div>

        <div class="card">
          <h2 class="card-title">${tr("auditTitle")}</h2>
          <div class="ledger-list" style="margin-top:8px;">${logsHtml}</div>
        </div>
      `;

      document.getElementById("secSetPinBtn").addEventListener("click", openPinModal);

      const lockBtn = document.getElementById("secLockNowBtn");
      if (lockBtn) {
        lockBtn.addEventListener("click", function () {
          sessionStorage.removeItem("pbm_unlocked");
          state.isLocked = true;
          renderLockOverlay();
        });
      }

      const remBtn = document.getElementById("secRemPinBtn");
      if (remBtn) {
        remBtn.addEventListener("click", function () {
          global.PBM_DB.remove("meta", "adminPin").then(function () {
            state.pin = "";
            state.isLocked = false;
            sessionStorage.removeItem("pbm_unlocked");
            app.showToast(tr("toastPinRemoved"), false);
            app.renderCurrentRoute();
          });
        });
      }

      document.getElementById("secRoleSelect").addEventListener("change", function (event) {
        state.role = event.target.value;
        localStorage.setItem("pbm_active_role", state.role);
        app.renderCurrentRoute();
      });
    });
  }

  global.PBM_SECURITY = {
    init: loadSecurityState,
    canAccess: canAccess,
    getRole: function () { return state.role; },
    renderSettingsSecurityCard: renderSettingsSecurityCard,
    showRestrictedToast: function () { global.PBM_APP.showToast(tr("toastRestricted"), true); }
  };
})(window);
