const WEAPONS = {
  pistol: {
    id: 'pistol',
    name: 'Pistola',
    damage: 22,
    fireRate: 0.35,
    magSize: 12,
    reloadTime: 1.4,
    range: 45,
    spread: 0.035,
    recoil: 0.02,
    type: 'pistol',
    auto: false
  },
  assault: {
    id: 'assault',
    name: 'Fuzil de Assalto',
    damage: 18,
    fireRate: 0.12,
    magSize: 30,
    reloadTime: 2.1,
    range: 70,
    spread: 0.028,
    recoil: 0.018,
    type: 'assault',
    auto: true
  },
  smg: {
    id: 'smg',
    name: 'SMG',
    damage: 14,
    fireRate: 0.08,
    magSize: 35,
    reloadTime: 1.8,
    range: 40,
    spread: 0.045,
    recoil: 0.015,
    type: 'smg',
    auto: true
  },
  shotgun: {
    id: 'shotgun',
    name: 'Escopeta',
    damage: 12, // per pellet
    pellets: 6,
    fireRate: 0.9,
    magSize: 6,
    reloadTime: 2.6,
    range: 22,
    spread: 0.12,
    recoil: 0.05,
    type: 'shotgun',
    auto: false
  },
  sniper: {
    id: 'sniper',
    name: 'Sniper',
    damage: 85,
    fireRate: 1.4,
    magSize: 5,
    reloadTime: 2.8,
    range: 150,
    spread: 0.008,
    recoil: 0.06,
    type: 'sniper',
    auto: false
  },
  grenade: {
    id: 'grenade',
    name: 'Granada',
    damage: 90,
    fireRate: 1.5,
    magSize: 1,
    reloadTime: 1.0,
    range: 35,
    type: 'grenade',
    auto: false
  }
};

function createWeaponInstance(baseId) {
  const base = WEAPONS[baseId] || WEAPONS.pistol;
  return {
    ...base,
    ammo: base.magSize,
    reserve: base.magSize * 3,
    lastShot: 0,
    reloading: false,
    reloadEnd: 0
  };
}
