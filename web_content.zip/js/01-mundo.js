/* Terreno e cena */

/* online: mundo gerado a partir do codigo da sala (mesmo codigo = mesma ilha) e fabricas de veiculo marcadas para replicar o modelo */
const NET={on:0,host:0,guest:0,code:'',conns:[],remotes:{},px:{},up:null,me:'',snapT:0,seq:0,f:0},RNG0=Math.random;
{const m=/sala=([A-Z0-9]{4,6})/.exec(location.hash);NET.code=m?m[1]:Array.from({length:5},()=>'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'[(RNG0()*32)|0]).join('');
 const WSEED=(/mundo=([A-Z0-9]{3,8})/.exec(location.hash)||[0,'ILHA1'])[1];let a=2166136261;for(const c of WSEED){a^=c.charCodeAt(0);a=Math.imul(a,16777619)}a>>>=0;
 Math.random=()=>{a=(a+0x6D2B79F5)|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296};
 for(const n of Object.getOwnPropertyNames(window))if(/^make[A-Z]/.test(n)&&typeof window[n]==='function'){const f=window[n];window[n]=function(c,fc){const t=f.apply(this,arguments);if(t&&t.g&&t.hp!==undefined){t.mkn=n;t.cc=c;t.fc=fc}return t}}}
const N=520,SIZE=1700,CELL=SIZE/N,HALF=SIZE/2,G=22,SPEED=85,WATER=-5;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const angDiff=(a,b)=>((a-b+Math.PI)%(Math.PI*2)+Math.PI*2)%(Math.PI*2)-Math.PI;
const dirOf=(y,p)=>new THREE.Vector3(Math.sin(y)*Math.cos(p),Math.sin(p),Math.cos(y)*Math.cos(p));
const v1=new THREE.Vector3();

/* ---------- terreno ---------- */
const H=new Float32Array((N+1)*(N+1)),S=new Float32Array((N+1)*(N+1)),Rd=new Float32Array((N+1)*(N+1)),Zc=new Float32Array((N+1)*(N+1));
const sm=(a,b,v)=>{const t=clamp((v-a)/(b-a),0,1);return t*t*(3-2*t)};
/* regioes: neve ao norte (com montanhas) e deserto a leste */
function biomeAt(x,z){const sn=sm(-HALF*.22,-HALF*.4,z+34*Math.sin(x*.012)),de=sm(HALF*.08,HALF*.3,x+34*Math.sin(z*.013));return{s:sn,d:de*(1-sn)}}
function baseH(x,z){const r=Math.hypot(x,z)/HALF,b=biomeAt(x,z);return 9*Math.sin(x*.011)*Math.cos(z*.013)+5*Math.sin(x*.027+z*.021)+2*Math.sin(z*.06)*Math.cos(x*.05)+3-24*Math.pow(r,6)+11*b.s*(.45+.55*Math.sin(x*.034+1.3)*Math.sin(z*.029))+3.2*b.d*(.6*Math.sin(x*.045+z*.03)+.4*Math.sin(x*.021-z*.037))}
const pos=new Float32Array((N+1)**2*3),col=new Float32Array((N+1)**2*3),idx=[];
for(let j=0;j<=N;j++)for(let i=0;i<=N;i++){const k=j*(N+1)+i;pos[k*3]=i*CELL-HALF;pos[k*3+2]=j*CELL-HALF;H[k]=baseH(pos[k*3],pos[k*3+2])}
for(let j=0;j<N;j++)for(let i=0;i<N;i++){const a=j*(N+1)+i,b=a+N+1,c=a+1,d=b+1;idx.push(a,b,c,c,b,d)}
const geo=new THREE.BufferGeometry();geo.setIndex(idx);
geo.setAttribute('position',new THREE.BufferAttribute(pos,3));geo.setAttribute('color',new THREE.BufferAttribute(col,3));
const cSand=new THREE.Color(0xcbb98a),cG1=new THREE.Color(0x5e8a3a),cG2=new THREE.Color(0x7d9c48),cRock=new THREE.Color(0x857b6d),cBurn=new THREE.Color(0x201c18),cRoad=new THREE.Color(0x4b4d50),cSnow=new THREE.Color(0xeef3f6),cDes=new THREE.Color(0xd9b574),cConc=new THREE.Color(0xa9a9a2),tc=new THREE.Color();
let bmS=null,bmD=null;
function refresh(i0,i1,j0,j1){
  for(let j=j0;j<=j1;j++)for(let i=i0;i<=i1;i++){
    const k=j*(N+1)+i,h=H[k],n=Math.abs((Math.sin(i*12.9898+j*78.233)*43758.5453)%1);
    pos[k*3+1]=h;tc.copy(cG1).lerp(cG2,n*.8);
    if(h<-1)tc.lerp(cSand,clamp((-1-h)/1.5,0,1));
    if(h>10)tc.lerp(cRock,clamp((h-10)/4,0,1));
    if(h>-1){if(!bmS){bmS=new Float32Array((N+1)*(N+1));bmD=new Float32Array((N+1)*(N+1));for(let jj=0;jj<=N;jj++)for(let ii=0;ii<=N;ii++){const q=biomeAt(ii*CELL-HALF,jj*CELL-HALF);bmS[jj*(N+1)+ii]=q.s;bmD[jj*(N+1)+ii]=q.d}}const bs=bmS[k],bd=bmD[k];if(bs>0)tc.lerp(cSnow,bs*.92);if(bd>0)tc.lerp(cDes,bd*.9)}
    if(Rd[k]>0)tc.lerp(cRoad,Math.min(1,Rd[k]));if(Zc[k]>0)tc.lerp(cConc,Math.min(1,Zc[k]));tc.lerp(cBurn,S[k]);col[k*3]=tc.r;col[k*3+1]=tc.g;col[k*3+2]=tc.b;
  }
  if(i0<=0&&i1>=N&&j0<=0&&j1>=N){geo.computeVertexNormals();tDirty.a=0;tDirty.b=N;tDirty.full=true}
  else{ /* so recalcula as normais e envia a faixa alterada (antes era o terreno inteiro a cada explosao) */
    const a0=Math.max(0,i0-1),a1=Math.min(N,i1+1),b0=Math.max(0,j0-1),b1=Math.min(N,j1+1),na=geo.attributes.normal.array;
    for(let j=b0;j<=b1;j++)for(let i=a0;i<=a1;i++){
      const k=j*(N+1)+i,l=i>0?k-1:k,r=i<N?k+1:k,u=j>0?k-N-1:k,d=j<N?k+N+1:k,
        gx=(H[r]-H[l])/(((r-l)||1)*CELL),gz=(H[d]-H[u])/((((d-u)/(N+1))||1)*CELL),il=1/Math.hypot(gx,1,gz);
      na[k*3]=-gx*il;na[k*3+1]=il;na[k*3+2]=-gz*il;
    }
    tDirty.a=Math.min(tDirty.a,b0);tDirty.b=Math.max(tDirty.b,b1);
  }
  tDirty.on=true;
}
const tDirty={a:1e9,b:-1,on:false,full:false};
function flushTerrain(){
  if(!tDirty.on)return;
  const R=N+1,at=[geo.attributes.position,geo.attributes.color,geo.attributes.normal];
  for(const a of at){a.needsUpdate=true;a.updateRange=tDirty.full?{offset:0,count:-1}:{offset:tDirty.a*R*3,count:(tDirty.b-tDirty.a+1)*R*3}}
  tDirty.a=1e9;tDirty.b=-1;tDirty.on=false;tDirty.full=false;
}
function getH(x,z){
  let gx=clamp((x+HALF)/CELL,0,N-.001),gz=clamp((z+HALF)/CELL,0,N-.001);
  const i=gx|0,j=gz|0,fx=gx-i,fz=gz-j,k=j*(N+1)+i;
  return (H[k]*(1-fx)+H[k+1]*fx)*(1-fz)+(H[k+N+1]*(1-fx)+H[k+N+2]*fx)*fz;
}
function roadAt(x,z){
  const gx=clamp((x+HALF)/CELL,0,N-.001),gz=clamp((z+HALF)/CELL,0,N-.001),i=gx|0,j=gz|0,fx=gx-i,fz=gz-j,k=j*(N+1)+i;
  return (Rd[k]*(1-fx)+Rd[k+1]*fx)*(1-fz)+(Rd[k+N+1]*(1-fx)+Rd[k+N+2]*fx)*fz;
}
const roads=[];
function makeRoad(a,b,bw){
  const dx=b.x-a.x,dz=b.z-a.z,L=Math.hypot(dx,dz);if(L<20)return;
  const nx=-dz/L,nz=dx/L,bow=bw!==undefined?bw:(Math.random()-.5)*L*.3,steps=Math.ceil(L/1.5),pts=[];
  for(let q=0;q<=steps;q++){const u=q/steps,o=Math.sin(u*Math.PI)*bow;pts.push({x:a.x+dx*u+nx*o,z:a.z+dz*u+nz*o})}
  roads.push(pts);
  for(const p of pts){
    if(getH(p.x,p.z)<-2.2||Math.hypot(p.x,p.z)>HALF-8)continue;
    const i0=Math.max(0,Math.floor((p.x-5+HALF)/CELL)),i1=Math.min(N,Math.ceil((p.x+5+HALF)/CELL)),j0=Math.max(0,Math.floor((p.z-5+HALF)/CELL)),j1=Math.min(N,Math.ceil((p.z+5+HALF)/CELL));
    for(let j=j0;j<=j1;j++)for(let i=i0;i<=i1;i++){
      const d=Math.hypot(i*CELL-HALF-p.x,j*CELL-HALF-p.z),w=clamp(1-(d-2.2)/2.6,0,1),k=j*(N+1)+i;if(w>Rd[k])Rd[k]=w;
    }
  }
}
function crater(x,z,R,depth){
  hideTracks(x,z,R);
  const i0=Math.max(0,Math.floor((x-R+HALF)/CELL)),i1=Math.min(N,Math.ceil((x+R+HALF)/CELL)),j0=Math.max(0,Math.floor((z-R+HALF)/CELL)),j1=Math.min(N,Math.ceil((z+R+HALF)/CELL));
  for(let j=j0;j<=j1;j++)for(let i=i0;i<=i1;i++){
    const q=Math.hypot(i*CELL-HALF-x,j*CELL-HALF-z)/R;
    if(q<1){const f=(1-q*q),k=j*(N+1)+i;H[k]=Math.max(-9,H[k]-depth*f*f);S[k]=Math.min(1,S[k]+f);Rd[k]=Math.max(0,Rd[k]-f*2.2);Zc[k]=Math.max(0,Zc[k]-f*2.2)}
  }
  refresh(i0,i1,j0,j1);
}

/* ---------- cena ---------- */
const renderer=new THREE.WebGLRenderer({antialias:true});
renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.setSize(innerWidth,innerHeight);renderer.shadowMap.enabled=true;
document.body.appendChild(renderer.domElement);
const scene=new THREE.Scene();scene.background=new THREE.Color(0xa9cde6);scene.fog=new THREE.Fog(0xa9cde6,120,430);
const cam=new THREE.PerspectiveCamera(60,innerWidth/innerHeight,.5,470);
scene.add(new THREE.HemisphereLight(0xdbeaff,0x5a5a3c,.8));
const sun=new THREE.DirectionalLight(0xfff0cf,.95);sun.castShadow=true;sun.shadow.mapSize.set(2048,2048);sun.shadow.bias=-.0006;
const sc=sun.shadow.camera;sc.left=sc.bottom=-70;sc.right=sc.top=70;sc.near=10;sc.far=320;scene.add(sun,sun.target);
refresh(0,N,0,N);
/* terreno em blocos: a camera so desenha os blocos que estao na tela e dentro da nevoa */
const terrain=new THREE.Group();scene.add(terrain);
{const tm=new THREE.MeshLambertMaterial({vertexColors:true}),CS=65;
 for(let cj=0;cj<N;cj+=CS)for(let ci=0;ci<N;ci+=CS){
  const ix=[];for(let j=cj;j<Math.min(N,cj+CS);j++)for(let i=ci;i<Math.min(N,ci+CS);i++){const o=(j*N+i)*6;for(let q=0;q<6;q++)ix.push(idx[o+q])}
  const g=new THREE.BufferGeometry();g.setIndex(ix);g.setAttribute('position',geo.attributes.position);g.setAttribute('color',geo.attributes.color);g.setAttribute('normal',geo.attributes.normal);
  const w=Math.min(CS,N-ci)*CELL,d=Math.min(CS,N-cj)*CELL;g.boundingSphere=new THREE.Sphere(new THREE.Vector3(ci*CELL-HALF+w/2,4,cj*CELL-HALF+d/2),Math.hypot(w/2,d/2,32)+2);
  const m=new THREE.Mesh(g,tm);m.receiveShadow=true;terrain.add(m);
 }}
const water=new THREE.Mesh(new THREE.PlaneGeometry(2600,2600).rotateX(-Math.PI/2),new THREE.MeshPhongMaterial({color:0x2a6f97,transparent:true,opacity:.78,shininess:80}));
water.position.y=WATER;scene.add(water);

