// =======================================
// NetEarn Pro
// Form Fill Work System
// Clean V5
// Firebase Auth + Task Validation
// Admin Controlled Fields
// Timer + Submit + Task Chance
// =======================================

import { auth, db } from "./firebase.js";
import { getBusinessSettings, getConfiguredTaskReward } from "./business-settings.js";

import {
    onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";

import {
    doc,
    getDoc,
    addDoc,
    collection,
    serverTimestamp,
    increment,
    updateDoc
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";


// =======================================
// ELEMENTS
// =======================================

const timerBox =
    document.getElementById("timer");

const fullNameInput =
    document.getElementById("fullName");

const emailInput =
    document.getElementById("userEmail");

const userIdInput =
    document.getElementById("userId");

const referralInput =
    document.getElementById("referralCode");

const adminFormFields =
    document.getElementById("adminFormFields");

const additionalInfo =
    document.getElementById("additionalInfo");

const submitBtn =
    document.getElementById("submitFormBtn");

const taskTitle =
    document.querySelector(".active-card h2");

const taskDescription =
    document.querySelector(".instruction-box p");


// =======================================
// URL TASK ID
// =======================================

const taskId =
    new URLSearchParams(
        window.location.search
    ).get("taskId");


// =======================================
// APP STATE
// =======================================

let currentUser = null;

let currentTask = null;

let remainingSeconds = 10 * 60;

let timerInterval = null;

let taskSubmitting = false;

let taskExpired = false;


// =======================================
// DEFAULT TASK CONFIG
// =======================================

const DEFAULT_TIME =
    30 * 60;

const DEFAULT_REWARD =
    50;


// =======================================
// AUTH
// =======================================

onAuthStateChanged(
    auth,
    async (user) => {

        if (!user) {

            window.location.href =
                "index.html";

            return;

        }


        currentUser =
            user;


        disableForm();


        try {

            // ===================================
            // TASK ID CHECK
            // ===================================

            if (!taskId) {

                throw new Error(
                    "TASK_ID_MISSING"
                );

            }


            // ===================================
            // LOAD USER
            // ===================================

            const userRef =
                doc(
                    db,
                    "users",
                    user.uid
                );


            const userSnap =
                await getDoc(
                    userRef
                );


            if (!userSnap.exists()) {

                throw new Error(
                    "USER_NOT_FOUND"
                );

            }


            const userData =
                userSnap.data();


            // ===================================
            // ACCOUNT VERIFICATION
            // ===================================

            const verified =
                userData.verified === true ||
                userData.verified === "true";


            if (!verified) {

                throw new Error(
                    "NOT_VERIFIED"
                );

            }


            // ===================================
            // TASK CHANCE
            // ===================================

            const chance =
                Number(
                    userData.taskChance || 0
                );


            if (chance < 1) {

                throw new Error(
                    "NO_CHANCE"
                );

            }


            // ===================================
            // SELECTED TASK CHECK
            // ===================================

            const selectedTask =
                userData.selectedTask ||
                null;


            if (
                selectedTask &&
                selectedTask !== "formfill"
            ) {

                throw new Error(
                    "OTHER_TASK"
                );

            }


            // ===================================
            // LOAD TASK
            // ===================================

            await loadCurrentTask();


            if (!currentTask) {

                throw new Error(
                    "TASK_NOT_FOUND"
                );

            }


            // ===================================
            // START
            // ===================================

            loadAccountData(
                userData
            );


            loadAdminFormFields(
                currentTask
            );


            applyTaskInfo();


            startTask();

        }

        catch (error) {

            console.error(
                "❌ Form Fill Work Error:",
                error
            );


            handleLoadError(
                error
            );

        }

    }
);


// =======================================
// LOAD CURRENT TASK
// =======================================

async function loadCurrentTask() {

    const taskRef =
        doc(
            db,
            "tasks",
            taskId
        );


    const settingsPromise =
        getBusinessSettings({ force: true });

    const taskSnap =
        await getDoc(
            taskRef
        );


    if (!taskSnap.exists()) {

        return null;

    }


    const task =
        taskSnap.data();


    // ===================================
    // VALIDATE TASK
    // ===================================

    if (
        task.category !== "Form Fill" ||
        task.status !== "Active"
    ) {

        throw new Error(
            "INVALID_TASK"
        );

    }


    currentTask = {

        id:
            taskSnap.id,

        ...task

    };

    const businessSettings = await settingsPromise;
    currentTask.reward = getConfiguredTaskReward(currentTask, businessSettings);


    console.log(
        "✅ Form Fill Task Loaded:",
        currentTask
    );


    return currentTask;

}


// =======================================
// LOAD ACCOUNT DATA
// =======================================

function loadAccountData(
    data
) {

    if (fullNameInput) {

        fullNameInput.value =
            data.username ||
            data.name ||
            data.fullName ||
            "";

    }


    if (emailInput) {

        emailInput.value =
            data.email ||
            currentUser?.email ||
            "";

    }


    if (userIdInput) {

        userIdInput.value =
            data.userId ||
            currentUser?.uid ||
            "";

    }


    if (referralInput) {

        referralInput.value =
            data.referralCode ||
            data.referral ||
            "";

    }

}


// =======================================
// LOAD ADMIN CONTROLLED FIELDS
// =======================================

function loadAdminFormFields(
    task
) {

    if (!adminFormFields) {

        return;

    }


    adminFormFields.innerHTML =
        "";


    const fields =
        Array.isArray(
            task.formFields
        )
            ? task.formFields
            : [];


    if (!fields.length) {

        return;

    }


    fields.forEach(
        (field, index) => {

            const group =
                document.createElement(
                    "div"
                );


            group.className =
                "form-group";


            const label =
                document.createElement(
                    "label"
                );


            const labelText =
                String(
                    field.label ||
                    `Required Information ${index + 1}`
                ).trim();


            label.textContent =
                labelText;


            const input =
                document.createElement(
                    "input"
                );


            input.type =
                field.type || "text";


            input.id =
                `adminFormField_${index}`;


            input.className =
                "admin-form-field-input";


            input.dataset.fieldIndex =
                String(index);


            input.dataset.fieldLabel =
                labelText;


            input.placeholder =
                `Enter ${labelText}`;


            if (
                field.required !== false
            ) {

                input.required =
                    true;

            }


            group.appendChild(
                label
            );


            group.appendChild(
                input
            );


            adminFormFields.appendChild(
                group
            );

        }
    );

}


// =======================================
// APPLY TASK INFORMATION
// =======================================

function applyTaskInfo() {

    if (!currentTask) {

        return;

    }


    // ===================================
    // TITLE
    // ===================================

    if (taskTitle) {

        taskTitle.textContent =
            currentTask.title ||
            currentTask.name ||
            "NetEarn Pro Form Fill Task";

    }


    // ===================================
    // DESCRIPTION
    // ===================================

    if (taskDescription) {

        taskDescription.textContent =
            currentTask.description ||
            "Complete the assigned form correctly and submit your work for admin review.";

    }


    // ===================================
    // REWARD
    // ===================================

    const rewardElement =
        document.getElementById(
            "taskReward"
        );


    if (rewardElement) {

        rewardElement.textContent =
            Number.isFinite(Number(currentTask?.reward))
                ? "৳" + Number(currentTask.reward)
                : "—";

    }


    // ===================================
    // TIME
    // ===================================

    const timeElement =
        document.querySelector(
            ".time-card strong"
        );


    const timeLimit =
        Number(
            currentTask.timeLimit ||
            currentTask.time ||
            30
        );


    if (timeElement) {

        timeElement.textContent =
            timeLimit +
            " Min";

    }

}

// =======================================
// START TASK
// =======================================

function startTask() {

    taskExpired =
        false;

    taskSubmitting =
        false;


    const minutes =
        Number(
            currentTask?.timeLimit ||
            currentTask?.time ||
            10
        );


    remainingSeconds =
        Math.max(
            1,
            minutes * 60
        );


    enableForm();


    updateTimer();


    startTimer();

}


// =======================================
// ENABLE FORM
// =======================================

function enableForm() {

    if (additionalInfo) {

        additionalInfo.disabled =
            false;

    }


    if (adminFormFields) {

        const inputs =
            adminFormFields.querySelectorAll(
                "input, select, textarea"
            );


        inputs.forEach(
            (input) => {

                input.disabled =
                    false;

            }
        );

    }


    if (submitBtn) {

        submitBtn.disabled =
            false;

        submitBtn.textContent =
            "🚀 Submit Form";

    }

}


// =======================================
// DISABLE FORM
// =======================================

function disableForm() {

    if (additionalInfo) {

        additionalInfo.disabled =
            true;

    }


    if (adminFormFields) {

        const inputs =
            adminFormFields.querySelectorAll(
                "input, select, textarea"
            );


        inputs.forEach(
            (input) => {

                input.disabled =
                    true;

            }
        );

    }


    if (submitBtn) {

        submitBtn.disabled =
            true;

    }


    stopTimer();

}


// =======================================
// TIMER
// =======================================

function startTimer() {

    stopTimer();


    timerInterval =
        setInterval(
            () => {

                updateTimer();

            },
            1000
        );

}


// =======================================
// STOP TIMER
// =======================================

function stopTimer() {

    if (timerInterval) {

        clearInterval(
            timerInterval
        );

        timerInterval =
            null;

    }

}


// =======================================
// UPDATE TIMER
// =======================================

function updateTimer() {

    if (!timerBox) {

        return;

    }


    const minutes =
        Math.floor(
            remainingSeconds / 60
        );


    const seconds =
        remainingSeconds % 60;


    timerBox.textContent =
        String(minutes)
            .padStart(2, "0") +
        ":" +
        String(seconds)
            .padStart(2, "0");


    if (
        remainingSeconds <= 0
    ) {

        finishTimer();

        return;

    }


    remainingSeconds--;

}


// =======================================
// TIMER FINISHED
// =======================================

function finishTimer() {

    stopTimer();


    taskExpired =
        true;


    disableForm();


    if (timerBox) {

        timerBox.textContent =
            "00:00";

    }


    alert(
        "⏳ Task Time Finished!\n\nআপনার Form Fill Task-এর সময় শেষ হয়ে গেছে।"
    );

}


// =======================================
// COLLECT ADMIN FORM DATA
// =======================================

function collectAdminFormData() {

    const formData = {};


    if (!adminFormFields) {

        return formData;

    }


    const inputs =
        adminFormFields.querySelectorAll(
            ".admin-form-field-input"
        );


    inputs.forEach(
        (input) => {

            const label =
                input.dataset.fieldLabel ||
                input.name ||
                input.id;


            formData[label] =
                input.value.trim();

        }
    );


    return formData;

}


// =======================================
// VALIDATE ADMIN FIELDS
// =======================================

async function validateAdminFields() {

    if (!adminFormFields) {

        return true;

    }


    const inputs =
        adminFormFields.querySelectorAll(
            ".admin-form-field-input"
        );


    for (
        const input of inputs
    ) {

        if (
            input.required &&
            !input.value.trim()
        ) {

            const label =
                input.dataset.fieldLabel ||
                "Required Information";


            await NetEarnDialog.alert(
                `📝 ${label} পূরণ করুন।`
            );


            input.focus();


            return false;

        }

    }


    return true;

}


// =======================================
// SUBMIT BUTTON
// =======================================

submitBtn?.addEventListener(
    "click",
    submitTask
);


// =======================================
// SUBMIT TASK
// =======================================

async function submitTask() {

    if (taskSubmitting) {

        return;

    }


    if (taskExpired) {

        await NetEarnDialog.alert(
            "⏳ Task-এর সময় শেষ হয়ে গেছে।"
        );

        return;

    }


    if (!currentUser) {

        await NetEarnDialog.alert(
            "⚠️ User authentication পাওয়া যায়নি।"
        );

        return;

    }


    // ===================================
    // REQUIRED ADMIN FIELDS
    // ===================================

    if (
        !(await validateAdminFields())
    ) {

        return;

    }


    // ===================================
    // ADDITIONAL INFORMATION
    // ===================================

    const extraInfo =
        additionalInfo?.value.trim() ||
        "";


    if (!extraInfo) {

        await NetEarnDialog.alert(
            "📝 Additional Information পূরণ করুন।"
        );


        additionalInfo?.focus();


        return;

    }


    // ===================================
    // CONFIRM
    // ===================================

    const confirmed =
        await NetEarnDialog.confirm(
            "আপনি কি Form Fill Task Submit করতে চান?\n\nSubmit করার পর আর পরিবর্তন করা যাবে না।"
        );


    if (!confirmed) {

        return;

    }


    taskSubmitting =
        true;


    if (submitBtn) {

        submitBtn.disabled =
            true;

        submitBtn.textContent =
            "⏳ Submitting...";

    }


    try {

        // ===================================
        // FRESH USER DATA
        // ===================================

        const userRef =
            doc(
                db,
                "users",
                currentUser.uid
            );


        // The current user read and the business-settings read are
        // independent. Start both together; the reward is calculated
        // only after the fresh user validation completes.
        const businessSettingsPromise =
            getBusinessSettings({ force: true });

        const [freshSnap, businessSettings] =
            await Promise.all([
                getDoc(userRef),
                businessSettingsPromise
            ]);


        if (!freshSnap.exists()) {

            throw new Error(
                "USER_NOT_FOUND"
            );

        }


        const freshUser =
            freshSnap.data();


        // ===================================
        // VERIFY
        // ===================================

        const verified =
            freshUser.verified === true ||
            freshUser.verified === "true";


        if (!verified) {

            throw new Error(
                "NOT_VERIFIED"
            );

        }


        // ===================================
        // CHANCE
        // ===================================

        const freshChance =
            Number(
                freshUser.taskChance || 0
            );


        if (freshChance < 1) {

            throw new Error(
                "NO_CHANCE"
            );

        }


        // ===================================
        // SELECTED TASK
        // ===================================

        const selectedTask =
            freshUser.selectedTask ||
            null;


        if (
            selectedTask &&
            selectedTask !== "formfill"
        ) {

            throw new Error(
                "OTHER_TASK"
            );

        }


        // ===================================
        // FINAL ACCOUNT DATA
        // ===================================

        const finalName =
            freshUser.username ||
            freshUser.name ||
            freshUser.fullName ||
            currentUser.displayName ||
            "";


        const finalEmail =
            freshUser.email ||
            currentUser.email ||
            "";


        const finalUserId =
            freshUser.userId ||
            currentUser.uid;


        const finalReferralCode =
            freshUser.referralCode ||
            freshUser.referral ||
            "";


        // ===================================
        // ADMIN DATA
        // ===================================

        const adminData =
            collectAdminFormData();


        // ===================================
        // REWARD
        // ===================================

        const reward =
            getConfiguredTaskReward(currentTask, businessSettings);


// ===================================
        // CREATE SUBMISSION
        // ===================================

        await addDoc(

            collection(
                db,
                "taskSubmissions"
            ),

            {

                userUid:
                    currentUser.uid,

                userId:
                    finalUserId,

                username:
                    finalName,

                email:
                    finalEmail,

                referralCode:
                    finalReferralCode,

                taskId:
                    currentTask.id,

                taskType:
                    "form_fill",

                taskName:
                    currentTask.title ||
                    currentTask.name ||
                    "Form Fill Task",

                reward:
                    reward,

                formData: {

                    fullName:
                        finalName,

                    email:
                        finalEmail,

                    userId:
                        finalUserId,

                    referralCode:
                        finalReferralCode,

                    additionalInfo:
                        extraInfo,

                    adminFields:
                        adminData

                },

                status:
                    "pending",

                submittedAt:
                    serverTimestamp()

            }

        );


        // ===================================
        // REMOVE ONE CHANCE
        // ===================================

        await updateDoc(

            userRef,

            {

                taskChance:
                    increment(-1),

                selectedTask:
                    null

            }

        );


        // ===================================
        // SUCCESS STATE
        // ===================================

        stopTimer();


        taskExpired =
            true;


        if (additionalInfo) {

            additionalInfo.disabled =
                true;

        }


        if (adminFormFields) {

            const inputs =
                adminFormFields.querySelectorAll(
                    "input, select, textarea"
                );


            inputs.forEach(
                (input) => {

                    input.disabled =
                        true;

                }
            );

        }


        if (submitBtn) {

            submitBtn.disabled =
                true;

            submitBtn.textContent =
                "✅ Task Submitted";

        }


        // ===================================
        // SUCCESS MESSAGE
        // ===================================

        await NetEarnDialog.alert(

            "🎉 Form Fill Task Successfully Submitted!\n\n" +

            "Reward: ৳" +
            reward +

            "\n\n" +

            "Status: Pending Admin Approval"

        );


        // ===================================
        // DASHBOARD
        // ===================================

        window.location.href =
            "dashboard.html";

    }

    catch (error) {

        console.error(
            "❌ Form Fill Submit Error:",
            error
        );


        taskSubmitting =
            false;


        if (submitBtn) {

            submitBtn.disabled =
                false;

            submitBtn.textContent =
                "🚀 Submit Form";

        }


        // ===================================
        // ERROR HANDLING
        // ===================================

        if (
            error.message ===
            "USER_NOT_FOUND"
        ) {

            await NetEarnDialog.alert(
                "⚠️ User data পাওয়া যায়নি।"
            );


            window.location.href =
                "dashboard.html";


            return;

        }


        if (
            error.message ===
            "NOT_VERIFIED"
        ) {

            await NetEarnDialog.alert(
                "🔒 আপনার Account Verify করা হয়নি।"
            );


            window.location.href =
                "dashboard.html";


            return;

        }


        if (
            error.message ===
            "NO_CHANCE"
        ) {

            await NetEarnDialog.alert(
                "👥 আপনার Task Chance শেষ হয়ে গেছে।"
            );


            window.location.href =
                "dashboard.html";


            return;

        }


        if (
            error.message ===
            "OTHER_TASK"
        ) {

            await NetEarnDialog.alert(
                "🔒 আপনার অন্য একটি Task selected আছে।"
            );


            window.location.href =
                "dashboard.html";


            return;

        }


        if (
            error.message ===
            "TASK_ID_MISSING"
        ) {

            await NetEarnDialog.alert(
                "⚠️ Task ID পাওয়া যায়নি।"
            );


            window.location.href =
                "formfill.html";


            return;

        }


        if (
            error.message ===
            "TASK_NOT_FOUND" ||
            error.message ===
            "INVALID_TASK"
        ) {

            await NetEarnDialog.alert(
                "⚠️ এই Form Fill Task আর Active নেই।"
            );


            window.location.href =
                "formfill.html";


            return;

        }


        await NetEarnDialog.alert(
            "❌ Form Fill Task Submit করা যায়নি।\n\nদয়া করে আবার চেষ্টা করুন।"
        );

    }

}


// =======================================
// LOAD ERROR
// =======================================

async function handleLoadError(
    error
) {

    disableForm();


    switch (
        error.message
    ) {

        case "TASK_ID_MISSING":

            await NetEarnDialog.alert(
                "⚠️ Task ID পাওয়া যায়নি।"
            );

            window.location.href =
                "formfill.html";

            break;


        case "USER_NOT_FOUND":

            await NetEarnDialog.alert(
                "⚠️ User data পাওয়া যায়নি।"
            );

            window.location.href =
                "dashboard.html";

            break;


        case "NOT_VERIFIED":

            await NetEarnDialog.alert(
                "🔒 আপনার Account এখনো Verify করা হয়নি।"
            );

            window.location.href =
                "dashboard.html";

            break;


        case "NO_CHANCE":

            await NetEarnDialog.alert(
                "👥 আপনার কোনো Task Chance নেই।"
            );

            window.location.href =
                "dashboard.html";

            break;


        case "OTHER_TASK":

            await NetEarnDialog.alert(
                "🔒 আপনার অন্য একটি Task selected আছে।"
            );

            window.location.href =
                "dashboard.html";

            break;


        case "TASK_NOT_FOUND":
        case "INVALID_TASK":

            await NetEarnDialog.alert(
                "⚠️ এই Form Fill Task আর Active নেই।"
            );

            window.location.href =
                "formfill.html";

            break;


        default:

            await NetEarnDialog.alert(
                "⚠️ Form Fill Task Load করা যায়নি।"
            );

            break;

    }

}


// =======================================
// ERROR DISPLAY
// =======================================

async function showError(
    message
) {

    stopTimer();


    if (timerBox) {

        timerBox.textContent =
            "LOCKED";

        timerBox.style.fontSize =
            "18px";

        timerBox.style.color =
            "#fecaca";

    }


    return await NetEarnDialog.alert(
        message
    );

}


// =======================================
// PAGE CLEANUP
// =======================================

window.addEventListener(
    "beforeunload",
    () => {

        stopTimer();

    }
);


console.log(
    "✅ NetEarn Pro Form Fill Work Clean V5 Loaded"
);