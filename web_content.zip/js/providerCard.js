/**
 * providerCard.js
 * Componente reutilizável: gera o HTML do "Cartão/Carteira Digital do
 * Profissional". Usado em home-profissional.html (meu cartão) e em
 * solicitacao-detalhe.html (anfitrião vê o cartão do profissional aceito).
 *
 * NUNCA inclui RG/CPF/documentos/ocorrências detalhadas — só o resumo público
 * (ProvidersService.resumoPublico). Se não houver histórico, mostra
 * "Novo profissional" em vez de inventar uma nota.
 */
function renderCartaoProfissional(providerId, { mostrarAcoes = false, tamanho = 'normal', cpf = null } = {}){
  const r = ProvidersService.resumoPublico(providerId);
  if(!r) return '<p class="text-[12.5px] text-muted">Profissional não encontrado.</p>';

  const grande = tamanho === 'grande';
  // Selo oficial por categoria (arte fornecida: faxineira / marido de aluguel).
  // Categorias sem arte própria (ex.: só Roupa de cama/Enxoval) mantêm o
  // avatar simples — nunca inventar um selo não fornecido.
  const categorias = r.categorias || [];
  let badgeClasse = null, badgeLogo = null;
  if(categorias.includes(CATEGORIAS_SERVICO.LIMPEZA)){
    badgeClasse = 'faxineira'; badgeLogo = 'assets/logo-cartao-faxineira.png';
  } else if(categorias.includes(CATEGORIAS_SERVICO.REPAROS)){
    badgeClasse = 'marido-aluguel'; badgeLogo = 'assets/logo-cartao-marido-aluguel.png';
  }

  const fotoUrl = r.selfie || null;
  const tamanhoAvatarPx = grande ? 84 : 56;
  let fotoHtml;
  if(badgeLogo){
    fotoHtml = `
      <div class="prof-badge ${badgeClasse}">
        <img class="prof-badge-logo" src="${badgeLogo}" alt="Anjo da Guarda">
        ${fotoUrl ? `<img class="prof-badge-foto" src="${fotoUrl}">` : `<div class="prof-badge-foto avatar-circle" style="display:flex;align-items:center;justify-content:center;font-size:12px">${iniciais(r.nome)}</div>`}
      </div>`;
  } else {
    fotoHtml = fotoUrl
      ? `<img src="${fotoUrl}" style="width:${tamanhoAvatarPx}px;height:${tamanhoAvatarPx}px;border-radius:50%;object-fit:cover;flex-shrink:0">`
      : `<div class="avatar-circle" style="width:${tamanhoAvatarPx}px;height:${tamanhoAvatarPx}px;font-size:18px">${iniciais(r.nome)}</div>`;
  }

  const classificacaoHtml = r.temHistorico
    ? `<p class="text-[13px] font-bold" style="color:var(--dourado-escuro)">★ ${r.reputacao.toFixed(1)} <span class="text-muted font-normal">(${r.qtdAvaliacoes} avaliações)</span></p>
       <p class="text-[11.5px] text-muted">${r.servicosConcluidos} serviço${r.servicosConcluidos===1?'':'s'} concluído${r.servicosConcluidos===1?'':'s'}</p>`
    : `<p class="text-[12.5px] font-semibold" style="color:var(--azul-escuro)">Novo profissional</p>`;

  return `
    <div class="prof-card${grande ? ' grande' : ''}">
      <div class="flex items-center gap-3 mb-3">
        ${fotoHtml}
        <div class="flex-1 min-w-0">
          <p class="font-bold text-[14.5px] truncate prof-card-nome">${r.nome}</p>
          <p class="text-[11.5px] text-muted truncate">${r.categorias.join(', ') || 'Categoria não definida'}</p>
        </div>
        ${r.aprovado ? '<span class="badge-status verificado"><i data-lucide="badge-check" class="icon-inline"></i> Aprovado</span>' : '<span class="badge-status pendente">Pendente</span>'}
      </div>
      ${cpf ? `<p class="text-[11px] text-muted mb-2">CPF: <span class="font-semibold" style="color:var(--tinta)">${cpf}</span></p>` : ''}
      <div class="mb-3">${classificacaoHtml}</div>
      <div class="flex items-center justify-between text-[11px] text-muted pt-2" style="border-top:1px solid var(--linha)">
        <span>${r.tempoNaPlataforma}</span>
        <span>ID #${String(r.id).padStart(5,'0')}</span>
      </div>
      <div class="qr-placeholder mt-3">
        <i data-lucide="qr-code" style="width:16px;height:16px"></i> QR Code (em breve)
      </div>
    </div>
  `;
}
