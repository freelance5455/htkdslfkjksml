window.WorkspaceGameCards=(()=>{
  function layer(name,key){return `<span class="game-card-layer game-card-layer-${name}"${key?` data-asset-key="${key}"`:''} aria-hidden="true"></span>`}
  function markup(game,index,selected,escape){
    const stats=game.previewStats||{mods:'—',saves:'—',hours:'—'},def=WorkspaceGameCardRegistry.get(game.key),assets=def?.assets||{},background=assets.background||`card.${game.key}`;
    return `<button class="game-card art-slot${selected?' selected':''}" data-game-key="${escape(game.key)}" data-game-card-component="${escape(game.key)}" data-art-slot="${escape(game.key)}-card" data-game-card-background="${escape(background)}">${layer('overlay',assets.overlay)}${layer('hover',assets.hover)}${layer('selected',assets.selected)}<span class="game-card-inner-icon"${assets.icon?` data-asset-key="${assets.icon}"`:''} aria-hidden="true"><i>${escape(def?.fallbackIcon||game.short||String(index+1))}</i></span><span class="game-number">${String(index+1).padStart(2,'0')}</span><span class="game-card-copy"><small>${escape(game.region)}</small><b>${escape(game.title)}</b><em>Enter game →</em></span><span class="game-card-stats"><span><small>MODS</small><b>${escape(stats.mods)}</b></span><span><small>SAVE FILES</small><b>${escape(stats.saves)}</b></span><span><small>TIME PLAYED</small><b>${escape(stats.hours)}${stats.hours==='—'?'':'h'}</b></span></span></button>`
  }
  return{markup,definition:key=>WorkspaceGameCardRegistry.get(key)};
})();
