window.WorkspaceGameCardRegistry=(()=>{
  const definitions=new Map();
  function register(definition){if(!definition?.key)throw new Error('Game card definition requires a key');definitions.set(definition.key,Object.freeze({...definition,assets:Object.freeze({...definition.assets})}));return definition}
  function get(key){return definitions.get(String(key||''))||null}
  function all(){return [...definitions.values()]}
  return{register,get,all};
})();
