import { jsx as _jsx } from "react/jsx-runtime";
import { ICONS } from '../lib/icons.js';
export default function Icon({ name, size = 22, className = '' }) {
    return (_jsx("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "1.8", strokeLinecap: "round", strokeLinejoin: "round", className: className, "aria-hidden": "true", dangerouslySetInnerHTML: { __html: ICONS[name] || '' } }));
}
import { SERVICE_ICON } from '../lib/icons.js';
export function ServiceIcon({ slug, emoji, size = 24 }) {
    const name = SERVICE_ICON[slug];
    return name ? _jsx(Icon, { name: name, size: size }) : _jsx("span", { children: emoji || '🛠️' });
}
