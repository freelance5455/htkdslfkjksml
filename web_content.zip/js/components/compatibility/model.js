window.WorkspaceCompatibilityModel=(()=>{
  let d=null;
  function configure(deps){d=deps;return api}
  function fnvMods(){return d.active().filter(mod=>['Fallout: New Vegas','Fallout New Vegas','New Vegas'].includes(mod.game))}
  function modNexusIdentity(mod,k=d.knowledgeFor(mod)||{}){const research=k.research||{};const direct=String(research.nexus_mod_id||'').trim();if(direct)return direct;const match=String(mod?.source_url||'').match(/\/mods\/(\d+)/i);return match?match[1]:''}
  function exactRelatedMod(rel){const mods=fnvMods();const nexus=String(rel?.related_nexus_mod_id||'').trim();if(nexus){const hit=mods.find(mod=>modNexusIdentity(mod)===nexus);if(hit)return hit}const name=String(rel?.related_mod_name||'').trim().toLowerCase();return name?mods.find(mod=>String(mod.name||'').trim().toLowerCase()===name)||null:null}
  function relationPointsTo(rel,target){if(!target)return false;const nexus=String(rel?.related_nexus_mod_id||'').trim(),targetNexus=modNexusIdentity(target);if(nexus&&targetNexus&&nexus===targetNexus)return true;return String(rel?.related_mod_name||'').trim().toLowerCase()===String(target.name||'').trim().toLowerCase()}
  function pairRelations(a,b){if(!a||!b||a.id===b.id)return[];const ak=d.knowledgeFor(a)||{},bk=d.knowledgeFor(b)||{};return[...(ak.relationships||[]).filter(r=>relationPointsTo(r,b)).map(r=>({...r,direction:'outgoing'})),...(bk.relationships||[]).filter(r=>relationPointsTo(r,a)).map(r=>({...r,direction:'incoming'}))]}
  function relationClass(relations){const text=relations.map(r=>`${r.relationship_type||''} ${r.status||''}`).join(' ').toLowerCase();if(/incompat|conflict|replacement|not[_ -]?companion/.test(text))return'bad';if(/potential[_ -]?overlap|warning|needs[_ -]?verification|verify/.test(text))return'warn';if(relations.some(r=>String(r.relationship_type||'').toLowerCase()==='compatible'||/^compatible/.test(String(r.status||'').toLowerCase())))return'good';return'recorded'}
  function relationLabel(kind){return kind==='bad'?'CONFLICT / REPLACEMENT':kind==='warn'?'VERIFY / OVERLAP':kind==='good'?'COMPATIBLE':'RECORDED'}
  function relationSymbol(kind){return kind==='bad'?'!':kind==='warn'?'?':kind==='good'?'✓':'·'}
  function exactPairsFor(mod){return fnvMods().filter(other=>other.id!==mod.id).map(other=>({mod:other,relations:pairRelations(mod,other)})).filter(x=>x.relations.length).map(x=>({...x,kind:relationClass(x.relations)}))}
  function defaultMod(){const mods=fnvMods();return mods.slice().sort((a,b)=>(exactPairsFor(b).length-exactPairsFor(a).length)||((d.knowledgeFor(b)?.relationships?.length||0)-(d.knowledgeFor(a)?.relationships?.length||0))||String(a.name).localeCompare(String(b.name)))[0]||null}
  function uniquePairs(){const mods=fnvMods(),rows=[];for(let i=0;i<mods.length;i++)for(let j=i+1;j<mods.length;j++){const relations=pairRelations(mods[i],mods[j]);if(relations.length)rows.push({a:mods[i],b:mods[j],relations,kind:relationClass(relations)})}return rows}
  return api={configure,fnvMods,modNexusIdentity,exactRelatedMod,relationPointsTo,pairRelations,relationClass,relationLabel,relationSymbol,exactPairsFor,defaultMod,uniquePairs,knowledgeFor:mod=>d.knowledgeFor(mod)};
})();
