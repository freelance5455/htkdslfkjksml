window.WorkspaceCompatibilityHub=(()=>{
  let d=null,bound=false,selectedId=null;const $=id=>document.getElementById(id);
  function configure(deps){d=deps;d.model.configure({active:d.active,knowledgeFor:d.knowledgeFor});d.center.configure({model:d.model,library:d.library,recommendation:d.recommendation,fusion:d.fusion,localVerification:d.localVerification,ui:d.ui,api:d.api,installedState:d.installedState,toast:d.toast});d.advanced.configure({model:d.model,ui:d.ui,installedState:d.installedState});return api}
  function renderCenter(){selectedId=d.center.render(selectedId);return selectedId}
  function select(id){selectedId=Number(id);renderCenter()}
  function showCenter(){d.router.show('compatibility','Compatibility',{page:'compatibility'});document.body.dataset.worldTheme=d.currentWorldTheme();Promise.resolve(d.installedState?.ensure?.(d.api)).finally(()=>renderCenter())}
  function showAdvanced(){d.router.show('advanced','Advanced compatibility',{page:'advanced'});document.body.dataset.worldTheme=d.currentWorldTheme();Promise.resolve(d.installedState?.ensure?.(d.api)).finally(()=>d.advanced.render())}
  function bind(){if(bound)return;bound=true;d.library.bind(select,renderCenter);$('compatBack')?.addEventListener('click',d.showGameHub);$('openAdvanced')?.addEventListener('click',showAdvanced);$('advancedBack')?.addEventListener('click',showCenter)}
  function setSelectedId(id){selectedId=Number(id)||null}
  function getSelectedId(){return Number(selectedId)||0}
  return api={configure,bind,showCenter,showAdvanced,renderCenter,select,setSelectedId,getSelectedId,model:()=>d?.model};
})();
