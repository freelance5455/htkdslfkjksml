window.WorkspaceQuestsList=(()=>{
  let d=null,bound=false;
  const $=id=>document.getElementById(id);
  function configure(deps){d=deps;return api}
  function render(items,total,selectedId=''){
    $('questTotal').textContent=`${items.length} of ${total} quests`;
    if(total===0){$('questList').innerHTML='<div class="quest-no-results">Quest data is unavailable. Install the Fallout: New Vegas Game Pack to populate this page.</div>';return}
    $('questList').innerHTML=items.map(q=>`<button class="quest-row${q.stable_id===selectedId?' selected':''}" data-quest-id="${d.ui.escape(q.stable_id)}"><b>${d.ui.escape(q.quest_name)}</b><span>${d.ui.escape(q.content)}</span><span>${d.ui.escape(q.quest_type)}</span><code>${d.ui.escape(q.form_id||'—')}</code></button>`).join('')||'<div class="quest-no-results">No quests match those filters.</div>'
  }
  function bind(onSelect){if(bound)return;bound=true;$('questList')?.addEventListener('click',event=>{const row=event.target.closest('[data-quest-id]');if(row)onSelect(row.dataset.questId)})}
  return api={configure,render,bind};
})();
