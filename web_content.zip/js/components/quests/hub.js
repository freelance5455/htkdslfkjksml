window.WorkspaceQuestsHub=(()=>{
  let d=null,selectedQuestId='',bound=false;
  function configure(deps){d=deps;d.filters.configure({data:d.data,ui:d.ui});d.list.configure({ui:d.ui});d.detail.configure({ui:d.ui});return api}
  function render(){const all=d.data.all(),filtered=d.filters.apply(all);d.list.render(filtered,all.length,selectedQuestId);const selected=selectedQuestId?d.data.get(selectedQuestId):null;if(selected)d.detail.render(selected)}
  function clearSelection(){selectedQuestId='';d.detail.render(null);render()}
  function select(id){selectedQuestId=id||'';render();d.detail.render(d.data.get(selectedQuestId))}
  function bind(){if(bound)return;bound=true;d.filters.bind(clearSelection);d.list.bind(select)}
  async function show(){if(d.currentGameKey()!=='fallout-new-vegas')return;await d.data.load();d.filters.populate();d.router.show('gameQuests','Quests',{page:'gameQuests'});document.body.dataset.worldTheme=d.currentWorldTheme();render()}
  function selectedId(){return selectedQuestId}
  return api={configure,bind,show,render,select,clearSelection,selectedId};
})();
