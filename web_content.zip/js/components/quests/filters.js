window.WorkspaceQuestsFilters=(()=>{
  let d=null,bound=false;
  const $=id=>document.getElementById(id);
  function configure(deps){d=deps;return api}
  function populate(){const {contents,types}=d.data.options();$('questContentFilter').innerHTML='<option value="">All content</option>'+contents.map(v=>`<option>${d.ui.escape(v)}</option>`).join('');$('questTypeFilter').innerHTML='<option value="">All quest types</option>'+types.map(v=>`<option>${d.ui.escape(v)}</option>`).join('')}
  function values(){return{term:String($('questSearch')?.value||'').trim().toLowerCase(),content:$('questContentFilter')?.value||'',type:$('questTypeFilter')?.value||''}}
  function apply(items){const {term,content,type}=values();return items.filter(q=>(!content||q.content===content)&&(!type||q.quest_type===type)&&(!term||[q.quest_name,q.locations,q.given_by,q.form_id,q.editor_id].some(v=>String(v||'').toLowerCase().includes(term))))}
  function bind(onChange){if(bound)return;bound=true;for(const id of ['questSearch','questContentFilter','questTypeFilter']){const el=$(id);if(el)el.addEventListener(id==='questSearch'?'input':'change',onChange)}}
  return api={configure,populate,values,apply,bind};
})();
