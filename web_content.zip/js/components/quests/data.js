window.WorkspaceQuestsData=(()=>{
  const RUNTIME_URL='/api/game-pack/fallout-new-vegas/quests';
  let quests=[],loaded=false,pending=null,loadedSource='',lastStatus='unknown';
  function normalizeRows(value){let rows=value;for(let i=0;i<4;i++){if(typeof rows==='string'){try{rows=JSON.parse(rows);continue}catch{return[]}}if(Array.isArray(rows)&&rows.length===1&&Array.isArray(rows[0])){rows=rows[0];continue}break}if(!Array.isArray(rows))return[];return rows.flat(4).filter(row=>row&&typeof row==='object'&&!Array.isArray(row))}
  async function load(fetchImpl=fetch){
    if(pending)return pending;
    pending=fetchImpl(RUNTIME_URL,{cache:'no-store'}).then(r=>{if(!r.ok)throw new Error(`Quest Game Pack request failed (${r.status})`);return r.json()}).then(payload=>{
      quests=normalizeRows(payload?.quests??payload);
      lastStatus=String(payload?.status||'available');loaded=true;loadedSource=RUNTIME_URL;return quests;
    }).catch(()=>{quests=[];lastStatus='game_pack_unavailable';loaded=true;loadedSource=RUNTIME_URL;return quests}).finally(()=>{pending=null});
    return pending;
  }
  function all(){return quests}
  function get(stableId){return quests.find(q=>q.stable_id===stableId)||null}
  function options(){return{contents:[...new Set(quests.map(q=>q.content).filter(Boolean))],types:[...new Set(quests.map(q=>q.quest_type).filter(Boolean))]}}
  function source(){return loadedSource||RUNTIME_URL}
  function status(){return lastStatus}
  function resetForTest(){quests=[];loaded=false;pending=null;loadedSource='';lastStatus='unknown'}
  return{load,all,get,options,source,status,resetForTest};
})();
