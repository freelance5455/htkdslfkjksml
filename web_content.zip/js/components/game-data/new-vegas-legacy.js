// v0.20.18: transitional embedded New Vegas provider retired.
// Physical Game Pack availability is registered from the local runtime instead.
window.WorkspaceNewVegasLegacyDataDisabled=true;
