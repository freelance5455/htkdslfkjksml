window.WorkspaceGameSectionShell=(()=>{
  let d=null;
  const $=id=>document.getElementById(id);
  function configure(deps){d=deps;return api}
  function setText(page,slot,value){const node=page?.querySelector(`[data-game-section-component="${slot}"]`);if(node)node.textContent=value||''}
  function show(owner){
    if(!d||!owner)return;
    const page=$(`${owner.screen}Page`);if(!page)return;
    page.dataset.gameSectionKey=owner.key;
    page.dataset.gameSectionOwner=owner.owner;
    setText(page,'icon',owner.icon);
    setText(page,'eyebrow',owner.eyebrow);
    setText(page,'title',owner.title);
    setText(page,'description',owner.description);
    d.router.show(owner.screen,owner.title,{page:owner.screen,game:d.gameKey(),gameFilter:''});
    document.body.dataset.worldTheme=d.worldTheme();
    document.body.dataset.gameKey=d.gameKey();
  }
  const api={configure,show};return api;
})();
