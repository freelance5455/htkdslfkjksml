window.WorkspaceToolsSection={
  key:'tools',owner:'tools',screen:'gameTools',icon:'⌘',eyebrow:'FALLOUT: NEW VEGAS',title:'Tools',
  description:'Game-specific utilities and deliberately connected external tools will live here.'
};
