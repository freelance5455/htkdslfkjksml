window.WorkspaceSettingsSection={
  key:'settings',owner:'settings',screen:'gameSettings',icon:'⚙',eyebrow:'FALLOUT: NEW VEGAS',title:'Settings',
  description:'New Vegas workspace preferences and presentation settings will live here.'
};
