window.WorkspaceGameSections=(()=>{
  let shell=null;
  const registry={};
  function configure({shellOwner,deps,owners}){shell=shellOwner.configure(deps);for(const owner of owners||[])registry[owner.key]=owner;return api}
  function show(key){const owner=registry[key];if(!owner)return false;shell.show(owner);try{const result=owner.onShow?.();if(result&&typeof result.catch==='function')result.catch(error=>console.error(error))}catch(error){console.error(error)}return true}
  function get(key){return registry[key]||null}
  const api={configure,show,get};return api;
})();
