window.WorkspaceKnowledgeSection={
  key:'knowledge',owner:'knowledge',screen:'gameKnowledge',icon:'□',eyebrow:'FALLOUT: NEW VEGAS',title:'Knowledge Database',
  description:'Canonical game knowledge and category records live here. The UI remains available even when no shared game-data provider is installed.',
  onShow(){return window.WorkspaceKnowledgeHub?.render()}
};
