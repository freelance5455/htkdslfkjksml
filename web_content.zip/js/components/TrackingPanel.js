import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase.js';
import { useAuth } from '../lib/AuthContext.js';
import { ago } from '../lib/util.js';
import LiveMap from './LiveMap.js';
import ShareLocation from './ShareLocation.js';
import Icon from './Icon.js';
export default function TrackingPanel({ deal }) {
    const { profile, can } = useAuth();
    const [rows, setRows] = useState([]);
    const [, tick] = useState(0);
    const isSeller = profile?.id === deal.seller_id;
    const isBuyer = profile?.id === deal.buyer_id;
    const admin = !isSeller && !isBuyer && can('view_contacts');
    useEffect(() => {
        let alive = true;
        const load = async () => {
            const { data } = await supabase.from('live_locations').select('user_id,lat,lng,accuracy,updated_at').eq('deal_id', deal.id);
            if (alive) {
                setRows(data || []);
                tick((n) => n + 1);
            }
        };
        load();
        const t = setInterval(load, 5000);
        return () => { alive = false; clearInterval(t); };
    }, [deal.id]);
    if (!isSeller && !isBuyer && !admin)
        return null;
    const sellerRow = rows.find((r) => r.user_id === deal.seller_id);
    const buyerRow = rows.find((r) => r.user_id === deal.buyer_id);
    const stale = (r) => Date.now() - new Date(r.updated_at).getTime() > 120000;
    const markers = [];
    if (sellerRow)
        markers.push({ id: 's', lat: sellerRow.lat, lng: sellerRow.lng, color: '#F5A524', stale: stale(sellerRow), label: isSeller ? 'Aap' : `Seller: ${deal.seller?.full_name || ''}` });
    if (buyerRow)
        markers.push({ id: 'b', lat: buyerRow.lat, lng: buyerRow.lng, color: '#0A3D52', stale: stale(buyerRow), label: isBuyer ? 'Aap' : `Buyer: ${deal.buyer?.full_name || ''}` });
    return (_jsxs("div", { className: "card", style: { marginTop: '.7rem' }, children: [_jsxs("div", { className: "row", style: { marginBottom: '.6rem' }, children: [_jsx("div", { className: "ic-box sm", children: _jsx(Icon, { name: "pin", size: 18 }) }), _jsx("b", { children: "Live tracking" }), sellerRow && !stale(sellerRow) && _jsx("span", { className: "chip green", children: "Live" })] }), markers.length > 0 ? _jsx(LiveMap, { markers: markers }) : (_jsxs("div", { className: "notice", children: [_jsx(Icon, { name: "info", size: 18 }), _jsx("div", { children: isBuyer ? 'Seller ne abhi location share nahi ki. Share karte hi wo yahan map par nazar aayega.' : isSeller ? 'Neeche se location share shuru karein.' : 'Abhi kisi ne is deal mein location share nahi ki.' })] })), sellerRow && !isSeller && _jsxs("p", { className: "small muted", style: { margin: '.5rem 0 0' }, children: ["Seller ki location: ", ago(sellerRow.updated_at), stale(sellerRow) ? ' (purani, seller offline ho sakta hai)' : ''] }), buyerRow && admin && _jsxs("p", { className: "small muted", style: { margin: '.2rem 0 0' }, children: ["Buyer ki location: ", ago(buyerRow.updated_at)] }), (isSeller || isBuyer) && (_jsxs(_Fragment, { children: [_jsx("div", { className: "divider-line" }), _jsx(ShareLocation, { dealId: deal.id, who: isSeller ? 'seller' : 'buyer' })] }))] }));
}
