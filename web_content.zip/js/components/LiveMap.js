import { jsx as _jsx } from "react/jsx-runtime";
import { useEffect, useRef } from 'react';
// Sirf Pakistan
export const PK_BOUNDS = [[23.3, 60.6], [37.3, 77.9]];
// Pakistan ki (thori kushada) hadd - isi ke bahar sab kuch chhupa diya jata hai
export const PK_POLY = [
    [24.7, 61.1], [26.2, 61.4], [27.4, 62.1], [28.4, 61.4], [29.2, 61.2], [29.9, 60.8], [30.5, 61.0], [31.3, 62.0], [31.3, 64.0],
    [31.4, 66.0], [31.7, 67.8], [32.3, 69.0], [33.2, 69.3], [33.9, 69.7], [34.0, 70.85], [34.6, 71.1], [35.2, 71.0], [36.0, 71.0], [37.0, 72.0],
    [37.35, 74.0], [37.35, 74.9], [37.0, 75.6], [36.4, 76.8], [35.8, 77.95], [35.3, 77.0], [34.7, 76.0], [34.8, 75.2], [34.0, 74.7],
    [33.2, 74.7], [32.8, 75.0], [32.3, 75.1], [31.6, 74.75], [30.9, 74.75], [30.0, 74.2], [29.0, 73.5], [28.3, 72.0], [27.6, 71.0],
    [26.6, 70.8], [25.3, 71.0], [24.3, 71.2], [23.45, 68.7], [23.4, 67.5], [23.4, 61.1],
];
export function insidePK(lat, lng) {
    let inside = false;
    for (let i = 0, j = PK_POLY.length - 1; i < PK_POLY.length; j = i++) {
        const [yi, xi] = PK_POLY[i], [yj, xj] = PK_POLY[j];
        if (yi > lat !== yj > lat && lng < ((xj - xi) * (lat - yi)) / (yj - yi) + xi)
            inside = !inside;
    }
    return inside;
}
const esc = (s) => s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export default function LiveMap(props) {
    const { markers, height = 320, circle = null } = props;
    const el = useRef(null);
    const map = useRef(null);
    const layer = useRef({});
    const circleLayer = useRef(null);
    const sig = useRef('');
    const cbMarker = useRef(props.onMarkerClick);
    const cbMap = useRef(props.onMapClick);
    cbMarker.current = props.onMarkerClick;
    cbMap.current = props.onMapClick;
    useEffect(() => {
        const L = window.L;
        if (!L || !el.current)
            return;
        const m = L.map(el.current, {
            zoomControl: true, minZoom: 5, maxBounds: PK_BOUNDS, maxBoundsViscosity: 1, worldCopyJump: false,
        });
        m.fitBounds(PK_BOUNDS);
        L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19, bounds: PK_BOUNDS, attribution: '&copy; OpenStreetMap',
        }).addTo(m);
        // Pakistan ke bahar ka hissa dhak do
        L.polygon([[[-85, -180], [-85, 180], [85, 180], [85, -180]], PK_POLY], { stroke: false, fillColor: '#E9EDF1', fillOpacity: 1, interactive: false }).addTo(m);
        L.polygon(PK_POLY, { color: '#0E5673', weight: 1.5, opacity: 0.55, fill: false, interactive: false }).addTo(m);
        m.on('click', (e) => { if (insidePK(e.latlng.lat, e.latlng.lng))
            cbMap.current?.(e.latlng.lat, e.latlng.lng); });
        map.current = m;
        setTimeout(() => {
            m.invalidateSize();
            const z = m.getBoundsZoom(PK_BOUNDS, true);
            m.setMinZoom(z);
            if (m.getZoom() < z)
                m.setZoom(z);
        }, 250);
        return () => { m.remove(); map.current = null; layer.current = {}; circleLayer.current = null; sig.current = ''; };
    }, []);
    useEffect(() => {
        const L = window.L;
        const m = map.current;
        if (!L || !m)
            return;
        const seen = new Set();
        markers.forEach((mk) => {
            seen.add(mk.id);
            const icon = L.divIcon({
                className: 'pin-wrap', iconSize: [0, 0],
                html: `<div class="pin-label${mk.clickable ? ' clk' : ''}"><b>${esc(mk.label)}</b>${mk.sub ? `<small>${esc(mk.sub)}</small>` : ''}</div><div class="pin${mk.stale ? ' stale' : ''}" style="--pc:${mk.color || '#0A3D52'}"><span></span></div>`,
            });
            const cur = layer.current[mk.id];
            if (cur) {
                cur.setLatLng([mk.lat, mk.lng]);
                cur.setIcon(icon);
            }
            else {
                const x = L.marker([mk.lat, mk.lng], { icon, riseOnHover: true }).addTo(m);
                x.on('click', () => cbMarker.current?.(mk.id));
                layer.current[mk.id] = x;
            }
            if (mk.clickable)
                layer.current[mk.id].setZIndexOffset(500);
        });
        Object.keys(layer.current).forEach((id) => { if (!seen.has(id)) {
            layer.current[id].remove();
            delete layer.current[id];
        } });
        // radius circle
        if (circleLayer.current) {
            circleLayer.current.remove();
            circleLayer.current = null;
        }
        if (circle) {
            circleLayer.current = L.circle([circle.lat, circle.lng], {
                radius: circle.km * 1000, color: '#0E5673', weight: 2, fillColor: '#0E5673', fillOpacity: 0.07, interactive: false,
            }).addTo(m);
            const csig = `c${circle.lat.toFixed(4)},${circle.lng.toFixed(4)},${circle.km}`;
            if (csig !== sig.current) {
                sig.current = csig;
                m.fitBounds(circleLayer.current.getBounds(), { padding: [20, 20] });
            }
            return;
        }
        if (!markers.length)
            return;
        const ids = markers.map((k) => k.id).sort().join('|');
        const pts = markers.map((k) => [k.lat, k.lng]);
        const bounds = L.latLngBounds(pts);
        if (ids !== sig.current) {
            sig.current = ids;
            if (markers.length === 1)
                m.setView(pts[0], 16);
            else
                m.fitBounds(bounds, { padding: [50, 50], maxZoom: 16 });
        }
        else if (!m.getBounds().contains(bounds)) {
            if (markers.length === 1)
                m.panTo(pts[0]);
            else
                m.fitBounds(bounds, { padding: [50, 50], maxZoom: 16 });
        }
    }, [JSON.stringify(markers), circle?.lat, circle?.lng, circle?.km]); // eslint-disable-line react-hooks/exhaustive-deps
    if (!window.L)
        return _jsx("div", { className: "notice error", children: "Map load nahi hui. Internet check karein aur page refresh karein." });
    return _jsx("div", { ref: el, className: "map-box", style: { height } });
}
