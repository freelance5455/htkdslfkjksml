import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from 'react';
import { passwordChecks } from '../lib/util.js';
const Eye = () => (_jsxs("svg", { width: "22", height: "22", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [_jsx("path", { d: "M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12Z" }), _jsx("circle", { cx: "12", cy: "12", r: "3" })] }));
const EyeOff = () => (_jsxs("svg", { width: "22", height: "22", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [_jsx("path", { d: "M17.9 17.9A10.9 10.9 0 0 1 12 19C5 19 1 12 1 12a18.5 18.5 0 0 1 5.1-5.9M9.9 4.2A10.7 10.7 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.2 3.2M14.1 14.1a3 3 0 1 1-4.2-4.2" }), _jsx("path", { d: "m1 1 22 22" })] }));
export default function PasswordInput(props) {
    const [show, setShow] = useState(false);
    return (_jsxs("div", { className: "pw", children: [_jsx("input", { className: "input", type: show ? 'text' : 'password', value: props.value, onChange: (e) => props.onChange(e.target.value), placeholder: props.placeholder || 'Password', autoComplete: props.autoComplete || 'current-password' }), _jsx("button", { type: "button", className: "pw-eye", onClick: () => setShow((s) => !s), "aria-label": show ? 'Password chhupayein' : 'Password dekhein', children: show ? _jsx(EyeOff, {}) : _jsx(Eye, {}) })] }));
}
export function PasswordRules({ value }) {
    return (_jsx("ul", { className: "rules", children: passwordChecks(value).map((c) => (_jsxs("li", { className: c.ok ? 'ok' : '', children: [c.ok ? '✓' : '○', " ", c.label] }, c.label))) }));
}
