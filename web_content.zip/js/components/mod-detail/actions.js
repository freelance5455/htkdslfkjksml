window.WorkspaceModDetailActions={
  render(ctx){const link=ctx.$('detailNexusLink');if(ctx.mod.source_url){link.href=ctx.mod.source_url;link.classList.remove('disabled');link.removeAttribute('aria-disabled')}else{link.removeAttribute('href');link.classList.add('disabled');link.setAttribute('aria-disabled','true')}}
};
