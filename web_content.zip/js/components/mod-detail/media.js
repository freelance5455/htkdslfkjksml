window.WorkspaceModDetailMedia={
  render(ctx){const note=ctx.$('detailMediaNote');if(note)note.textContent='No researched media imported'}
};
