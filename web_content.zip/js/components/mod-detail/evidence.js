window.WorkspaceModDetailEvidence={
  render(ctx){
    const {mod,api,ui,currentPage,getSelectedId,installedState,pluginOwnership,fileOverlaps,pluginRecords,questEvidence,relationshipEvidence}=ctx;
    installedState.applyDetail(mod);pluginOwnership.applyDetail(mod,ui.escape);
    fileOverlaps.loadMod(api,mod,ui.escape);pluginRecords.loadMod(api,mod,ui.escape);questEvidence.loadMod(api,mod,ui.escape);relationshipEvidence.loadMod(api,mod,ui.escape);
    installedState.ensure(api).then(()=>{if(currentPage()==='modDetail'&&getSelectedId()===Number(mod.id)){installedState.applyDetail(mod);pluginOwnership.applyDetail(mod,ui.escape)}})
  }
};
