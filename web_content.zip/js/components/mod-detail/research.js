window.WorkspaceModDetailResearch={
  textValue(value){if(value===undefined||value===null||value==='')return'';if(typeof value==='string'||typeof value==='number'||typeof value==='boolean')return String(value);if(Array.isArray(value))return value.map(v=>this.textValue(v)).filter(Boolean).join('; ');return Object.entries(value).map(([k,v])=>`${k.replaceAll('_',' ')}: ${this.textValue(v)}`).join('; ')},
  render(ctx){
    const {$,ui,mod,research}=ctx;
    $('detailSummary').textContent=research.summary||mod.notes||'No research summary available.';
    const features=research.features,entries=Array.isArray(features)?features.slice(0,4).map((v,i)=>[`Feature ${i+1}`,this.textValue(v)]):features&&typeof features==='object'?Object.entries(features).slice(0,4).map(([key,value])=>[key.replaceAll('_',' '),this.textValue(value)]):[];
    $('detailResearchCards').innerHTML=entries.length?entries.map(([title,body],i)=>`<article><i>${['◉','⌖','▣','◈'][i]||'◇'}</i><b>${ui.escape(title.replace(/\b\w/g,c=>c.toUpperCase()))}</b><p>${ui.escape(body)}</p></article>`).join(''):'<article><b>Not analyzed</b><p>No structured feature data is available.</p></article>';
  }
};
