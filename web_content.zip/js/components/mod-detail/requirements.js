window.WorkspaceModDetailRequirements={
  render(ctx){const {$,ui,requirements}=ctx;$('detailRequirements').innerHTML=requirements.length?requirements.slice(0,10).map(r=>`<p>• ${ui.escape(r.requirement_name||'Requirement')} ${r.requirement_type?`<small>(${ui.escape(r.requirement_type.replaceAll('_',' '))})</small>`:''}</p>`).join(''):'<p>Not analyzed</p>'}
};
