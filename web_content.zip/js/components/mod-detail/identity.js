window.WorkspaceModDetailIdentity={
  render(ctx){
    const {$,ui,mod,research,plugins,sources,questLinks,tags}=ctx;
    const author=mod.author||'Unavailable';
    $('detailTitle').innerHTML=`${ui.escape(mod.name)} <span>☆</span>`;
    $('detailAuthor').textContent=author;$('detailSideAuthor').textContent=author;
    const tagHtml=tags.length?tags.map(tag=>`<span>${ui.escape(tag)}</span>`).join(''):'<span>Unavailable</span>';
    $('detailTags').innerHTML=tagHtml;$('detailSideTags').innerHTML=tagHtml;
    $('detailCategory').textContent=research.category||'Unavailable';
    $('detailPluginType').textContent=plugins[0]?.plugin_type||'Not analyzed';
    $('detailVerification').textContent=research.verification_status||'Unavailable';
    $('detailConfidence').textContent=research.confidence||'Unavailable';
    $('detailSourceCount').textContent=sources.length?`${sources.length} recorded`:'Unavailable';
    $('detailQuestLinks').textContent=questLinks.length?`${questLinks.length} verified`:'None verified';
  }
};
