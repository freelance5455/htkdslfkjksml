window.WorkspaceModDetailHistory={
  render(ctx){
    const {$,ui,mod,research,versions,bugs,changes,nexus}=ctx;
    $('detailVersion').textContent=mod.version||versions[0]?.version||'Unavailable';
    $('detailInstalledVersion').textContent=mod.installed_version||'Not connected';
    $('detailNexusId').textContent=nexus||'Unavailable';
    $('detailLastUpdated').textContent=research.last_updated||'Unavailable';
    $('detailResearchCoverage').textContent=ctx.k.research?`${(research.raw_sections||[]).length} sections`:'Unavailable';
    $('detailStatus').textContent=mod.status||'Unavailable';
    $('detailQuickInfo').innerHTML=`<dt>Created</dt><dd>${ui.escape(research.original_upload||'Unavailable')}</dd><dt>Last Updated</dt><dd>${ui.escape(research.last_updated||'Unavailable')}</dd><dt>Virus Scan</dt><dd>${ui.escape(research.virus_scan||'Unavailable')}</dd><dt>Research Sections</dt><dd>${(research.raw_sections||[]).length||'Unavailable'}</dd><dt>Bug Records</dt><dd>${bugs.length||'None captured'}</dd><dt>Changelog Entries</dt><dd>${changes.length||'None captured'}</dd>`;
  }
};
