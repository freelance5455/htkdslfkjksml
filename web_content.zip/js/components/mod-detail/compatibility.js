window.WorkspaceModDetailCompatibility={
  render(ctx){
    const {$,ui,relations}=ctx,types=relations.reduce((acc,r)=>(acc[r.relationship_type||'recorded']=(acc[r.relationship_type||'recorded']||0)+1,acc),{});
    $('detailRelationshipSummary').innerHTML=relations.length?Object.entries(types).slice(0,6).map(([type,count])=>`<dt>${ui.escape(type.replaceAll('_',' '))}</dt><dd>${count}</dd>`).join(''):'<dt>Source-recorded relationships</dt><dd>Not analyzed</dd>';
    const conflicts=relations.filter(r=>/incompat|conflict/i.test(`${r.relationship_type} ${r.status}`)).length,replacements=relations.filter(r=>/replacement|upgrade/i.test(`${r.relationship_type} ${r.status}`)).length;
    $('detailConflictStatus').textContent=conflicts?`${conflicts} source record${conflicts===1?'':'s'}`:'Not analyzed';
    $('detailUpgradeStatus').textContent=replacements?`${replacements} recorded`:'None recorded';
  }
};
