window.WorkspaceModDetailHub=(()=>{
  let d=null;
  const $=id=>document.getElementById(id);
  function configure(deps){d=deps;return api}
  function nexusIdentity(mod,research){const direct=String(research?.nexus_mod_id||'').trim();if(direct)return direct;const match=String(mod?.source_url||'').match(/\/mods\/(\d+)/i);return match?match[1]:''}
  function context(mod){
    const k=d.knowledgeFor(mod)||{},research=k.research||{},versions=k.versions||[],requirements=k.requirements||[],relations=k.relationships||[],plugins=k.plugins||[],bugs=k.bugs||[],sources=k.sources||[],questLinks=k.quest_links||[],changes=k.changelog||[];
    const tags=[...(Array.isArray(research.tags)?research.tags:[]),...String(mod.tags||'').split(',')].map(v=>String(v).trim()).filter(Boolean).filter((v,i,a)=>a.indexOf(v)===i);
    return{$,ui:d.ui,mod,k,research,versions,requirements,relations,plugins,bugs,sources,questLinks,changes,tags,nexus:nexusIdentity(mod,research),api:d.api,currentPage:d.currentPage,getSelectedId:d.getSelectedId,installedState:d.installedState,pluginOwnership:d.pluginOwnership,fileOverlaps:d.fileOverlaps,pluginRecords:d.pluginRecords,questEvidence:d.questEvidence,relationshipEvidence:d.relationshipEvidence}
  }
  function show(mod){
    if(!mod)return;d.setSelectedId(Number(mod.id));d.remember(mod.id);const ctx=context(mod);
    WorkspaceModDetailIdentity.render(ctx);WorkspaceModDetailHistory.render(ctx);WorkspaceModDetailMedia.render(ctx);WorkspaceModDetailResearch.render(ctx);WorkspaceModDetailRequirements.render(ctx);WorkspaceModDetailCompatibility.render(ctx);WorkspaceModDetailActions.render(ctx);
    d.router.show('modDetail',mod.name,{page:'modDetail'});WorkspaceModDetailEvidence.render(ctx);d.assets.apply()
  }
  const api={configure,show,context};return api
})();
