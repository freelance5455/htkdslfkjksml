window.WorkspaceHomeBrand={
  render(){const node=document.querySelector('[data-home-component="brand"]');if(node)node.dataset.componentReady='true'}
};
