window.WorkspaceHomeHub={
  render({config,state,records,games,recentIds,escape}){const world=config.worlds[state.route.world]||config.worlds.fallout;WorkspaceHomeBrand.render();WorkspaceHomeWorldPicker.render(config,escape);WorkspaceHomeWorldCards.render(config,state,escape);WorkspaceHomeStatus.render(records,games);WorkspaceHomeRecent.render({records,games,recentIds,escape});WorkspaceHomeBackground.apply(world)},
  bind(){WorkspaceHomeWorldPicker.bind()}
};
