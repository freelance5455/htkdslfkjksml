window.WorkspaceHomeStatus={
  _style(){
    if(document.getElementById('workspaceHomeBottomBarStyle'))return;
    const style=document.createElement('style');
    style.id='workspaceHomeBottomBarStyle';
    style.textContent=`
      #homePage .home-status-bar{
        display:grid!important;
        grid-template-columns:1fr 1fr 1fr 1fr minmax(210px,260px)!important;
        align-items:stretch!important;
        gap:0!important;
        min-height:92px!important;
        margin-top:12px!important;
        padding:0 18px!important;
        box-sizing:border-box!important;
        border:1px solid rgba(255,255,255,.12)!important;
        border-radius:12px!important;
        background:rgba(5,10,13,.92)!important;
        box-shadow:0 12px 34px rgba(0,0,0,.52)!important;
        backdrop-filter:blur(10px)!important;
        overflow:hidden!important;
      }

      #homePage .workspace-bottom-cell{
        min-width:0;
        display:flex;
        align-items:center;
        gap:13px;
        padding:16px 22px;
        box-sizing:border-box;
        border-right:1px solid rgba(255,255,255,.11);
      }
      #homePage .workspace-bottom-cell:first-child{padding-left:6px}
      #homePage .workspace-bottom-cell:last-of-type{border-right:0}

      #homePage .workspace-bottom-status-dot{
        flex:0 0 auto;
        width:12px;
        height:12px;
        border-radius:50%;
        background:#62cf43;
        box-shadow:0 0 0 7px rgba(70,170,45,.18),0 0 14px rgba(89,220,65,.58);
      }
      #homePage .workspace-bottom-status-dot[data-state="error"]{
        background:#d04a3d;
        box-shadow:0 0 0 7px rgba(180,55,45,.16),0 0 14px rgba(220,70,55,.45);
      }

      #homePage .workspace-bottom-copy{
        min-width:0;
        display:flex;
        flex-direction:column;
        justify-content:center;
        gap:7px;
      }
      #homePage .workspace-bottom-copy b{
        color:#f0ece8;
        font:500 17px/1 "Arial Narrow","Segoe UI",sans-serif;
        letter-spacing:.035em;
        white-space:nowrap;
      }
      #homePage .workspace-bottom-copy small{
        color:#aaa9a5;
        font:400 15px/1.15 "Arial Narrow","Segoe UI",sans-serif;
        white-space:nowrap;
        overflow:hidden;
        text-overflow:ellipsis;
      }

      #homePage .workspace-bottom-dashboard{
        align-self:center;
        justify-self:stretch;
        height:54px;
        margin:0 14px 0 28px;
        padding:0 26px;
        border:1px solid #d89b00;
        border-radius:9px;
        background:rgba(18,17,12,.72);
        color:#f3aa00;
        display:flex;
        align-items:center;
        justify-content:center;
        gap:18px;
        font:600 16px/1 "Arial Narrow","Segoe UI",sans-serif;
        letter-spacing:.035em;
        cursor:pointer;
      }
      #homePage .workspace-bottom-dashboard:hover{
        background:rgba(55,42,8,.72);
        box-shadow:0 0 18px rgba(211,147,0,.12);
      }
      #homePage .workspace-bottom-dashboard:disabled{
        opacity:.58;
        cursor:not-allowed;
        background:rgba(18,17,12,.52);
        box-shadow:none;
      }
      #homePage .workspace-bottom-dashboard:disabled:hover{
        background:rgba(18,17,12,.52);
        box-shadow:none;
      }
      #homePage .workspace-bottom-dashboard-icon{
        font-size:25px;
        line-height:1;
        transform:translateY(-1px);
      }

      @media(max-width:1100px){
        #homePage .home-status-bar{
          grid-template-columns:1fr 1fr!important;
          min-height:auto!important;
          padding:10px!important;
        }
        #homePage .workspace-bottom-cell{
          border-right:0;
          border-bottom:1px solid rgba(255,255,255,.08);
          padding:14px 12px;
        }
        #homePage .workspace-bottom-dashboard{
          grid-column:1/-1;
          margin:10px 0 2px;
        }
      }
    `;
    document.head.appendChild(style);
  },

  async _health(){
    try{
      const response=await fetch('/api/health',{cache:'no-store'});
      if(!response.ok)throw new Error('health request failed');
      const health=await response.json();
      return health&&health.ok?{ok:true,text:'All systems operational'}:{ok:false,text:'Runtime needs attention'};
    }catch{
      return {ok:false,text:'Runtime unavailable'};
    }
  },

  render(records,games){
    const active=records||[];
    const installed=active.filter(mod=>mod.status==='Installed');
    const installedGameCount=new Set(installed.map(mod=>String(mod.game||'').trim()).filter(Boolean)).size;
    const gameCount=(games||[]).length;
    const count=active.length;
    const testing=active.filter(mod=>mod.status==='Testing').length;
    const set=(id,value)=>{const node=document.getElementById(id);if(node)node.textContent=value};

    set('statMods',count);
    set('statGames',gameCount);
    set('statInstalled',installed.length);
    set('statTesting',testing);
    set('homeLibraryCount',`${count} mod${count===1?'':'s'} in your collection`);
    set('homeStatusLibrary',`${count} mod${count===1?'':'s'} across ${gameCount} game${gameCount===1?'':'s'}`);

    this._style();

    const footer=document.querySelector('#homePage .home-status-bar');
    if(!footer)return;

    const version=window.WorkspaceVersion?.current?.()||{};
    const dbSchema=version.database_schema??'—';

    /* Backup history does not currently have a Workspace runtime authority.
       If a later subsystem stores a timestamp in localStorage, this UI will
       pick it up without pretending one exists today. */
    const backupRaw=localStorage.getItem('workspace-last-backup')||'';
    let backupText='Not configured';
    if(backupRaw){
      const parsed=new Date(backupRaw);
      backupText=Number.isNaN(parsed.getTime())?backupRaw:parsed.toLocaleString();
    }

    footer.innerHTML=`
      <div class="workspace-bottom-cell">
        <span class="workspace-bottom-status-dot" id="workspaceBottomStatusDot"></span>
        <div class="workspace-bottom-copy">
          <b>SYSTEM STATUS</b>
          <small id="workspaceBottomSystemText">Checking runtime…</small>
        </div>
      </div>

      <div class="workspace-bottom-cell">
        <div class="workspace-bottom-copy">
          <b>DATABASE</b>
          <small>SQLite &nbsp;•&nbsp; Schema ${dbSchema}</small>
        </div>
      </div>

      <div class="workspace-bottom-cell">
        <div class="workspace-bottom-copy">
          <b>MODS INSTALLED</b>
          <small>${installed.length.toLocaleString()} across ${installedGameCount} game${installedGameCount===1?'':'s'}</small>
        </div>
      </div>

      <div class="workspace-bottom-cell">
        <div class="workspace-bottom-copy">
          <b>LAST BACKUP</b>
          <small>${backupText}</small>
        </div>
      </div>

      <button class="workspace-bottom-dashboard" type="button" disabled aria-disabled="true"
        title="Dashboard shortcut temporarily disabled during the Home UI redesign">
        <span class="workspace-bottom-dashboard-icon" aria-hidden="true">↗</span>
        <span>VIEW DASHBOARD</span>
      </button>
    `;

    this._health().then(result=>{
      const dot=document.getElementById('workspaceBottomStatusDot');
      const text=document.getElementById('workspaceBottomSystemText');
      if(dot)dot.dataset.state=result.ok?'ok':'error';
      if(text)text.textContent=result.text;
    });
  }
};
