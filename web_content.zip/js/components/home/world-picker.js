window.WorkspaceHomeWorldPicker={
  _style(){
    if(document.getElementById('workspaceAllWorldsStyle'))return;
    const style=document.createElement('style');
    style.id='workspaceAllWorldsStyle';
    style.textContent=`
      #homePage #allWorldsPanel.world-picker{
        position:fixed!important;
        z-index:5000!important;
        inset:0!important;
        width:auto!important;
        height:auto!important;
        max-height:none!important;
        padding:70px 70px 54px!important;
        box-sizing:border-box!important;
        overflow:auto!important;
        border:0!important;
        border-radius:0!important;
        background:
          linear-gradient(180deg,rgba(3,7,10,.88),rgba(3,7,10,.96)),
          var(--backdrop-image)!important;
        background-position:center!important;
        background-size:cover!important;
        box-shadow:none!important;
        backdrop-filter:blur(8px)!important;
      }
      #homePage #allWorldsPanel.hidden{display:none!important}
      #homePage .workspace-all-worlds-shell{
        width:min(1680px,calc(100vw - 100px));
        margin:0 auto;
      }
      #homePage .workspace-all-worlds-head{
        display:flex;
        align-items:flex-start;
        justify-content:space-between;
        gap:24px;
        margin-bottom:34px;
      }
      #homePage .workspace-all-worlds-head p{
        margin:0 0 7px;
        color:#f0ad16;
        font:600 13px/1 "Arial Narrow","Segoe UI",sans-serif;
        letter-spacing:.18em;
      }
      #homePage .workspace-all-worlds-head h2{
        margin:0;
        color:#f2f2ef;
        font:600 clamp(34px,4vw,58px)/1 "Arial Narrow","Segoe UI",sans-serif;
        letter-spacing:.03em;
      }
      #homePage .workspace-all-worlds-head small{
        display:block;
        margin-top:12px;
        color:#a8aaa8;
        font:400 16px/1.4 "Segoe UI",sans-serif;
      }
      #homePage .workspace-all-worlds-close{
        width:44px;
        height:44px;
        border:1px solid rgba(255,255,255,.16);
        border-radius:8px;
        background:rgba(5,9,12,.72);
        color:#eee;
        font-size:28px;
        cursor:pointer;
      }
      #homePage .workspace-all-worlds-grid{
        display:grid;
        grid-template-columns:repeat(4,minmax(190px,1fr));
        gap:24px;
        align-items:stretch;
      }
      #homePage .workspace-all-world-card{
        position:relative;
        min-height:330px;
        overflow:hidden;
        border:1px solid rgba(255,255,255,.14);
        border-radius:10px;
        background:rgba(12,16,20,.78);
        color:#ededeb;
        box-shadow:0 16px 34px rgba(0,0,0,.34);
      }
      #homePage .workspace-all-world-card .home-world-art-placeholder{
        position:absolute;
        inset:0;
        opacity:.94;
      }
      #homePage .workspace-all-world-card .workspace-all-world-copy{
        position:absolute;
        z-index:2;
        left:0;
        right:0;
        bottom:0;
        padding:22px 18px 18px;
        background:linear-gradient(180deg,transparent,rgba(4,6,8,.96) 48%);
      }
      #homePage .workspace-all-world-card b{
        display:block;
        font:600 22px/1.05 "Arial Narrow","Segoe UI",sans-serif;
      }
      #homePage .workspace-all-world-card small{
        display:block;
        margin-top:8px;
        color:#aaa;
        font:400 13px/1.35 "Segoe UI",sans-serif;
      }
      #homePage .workspace-all-world-card em{
        display:inline-block;
        margin-top:12px;
        padding:5px 8px;
        border-radius:4px;
        background:rgba(240,170,10,.13);
        color:#f0ad16;
        font:700 10px/1 "Segoe UI",sans-serif;
        font-style:normal;
        letter-spacing:.08em;
      }
      #homePage .workspace-all-world-card.disabled{
        filter:saturate(.55);
        opacity:.70;
      }

      /* Reuse the same approved Home card art in the All Worlds browser. */
      #homePage .workspace-all-world-card[data-franchise="fallout"] .home-world-art-placeholder{
        background-image:linear-gradient(180deg,rgba(5,6,7,.00),rgba(5,6,7,.08) 58%,rgba(5,6,7,.90)),url('assets/cards/home-fallout-card.jpg');
        background-size:cover;background-position:center top;
      }
      #homePage .workspace-all-world-card[data-franchise="elder-scrolls"] .home-world-art-placeholder{
        background-image:linear-gradient(180deg,rgba(5,6,7,.00),rgba(5,6,7,.08) 58%,rgba(5,6,7,.90)),url('assets/cards/home-elder-scrolls-card.jpg');
        background-size:cover;background-position:center top;
      }
      #homePage .workspace-all-world-card[data-franchise="cyberpunk"] .home-world-art-placeholder{
        background-image:linear-gradient(180deg,rgba(5,6,7,.00),rgba(5,6,7,.08) 58%,rgba(5,6,7,.90)),url('assets/cards/home-cyberpunk-card.jpg');
        background-size:cover;background-position:center top;
      }
      #homePage .workspace-all-world-card[data-franchise="starfield"] .home-world-art-placeholder{
        background-image:linear-gradient(180deg,rgba(5,6,7,.00),rgba(5,6,7,.08) 58%,rgba(5,6,7,.90)),url('assets/cards/home-starfield-card.jpg');
        background-size:cover;background-position:center top;
      }

      @media(max-width:1100px){
        #homePage #allWorldsPanel.world-picker{padding:60px 28px 36px!important}
        #homePage .workspace-all-worlds-grid{grid-template-columns:repeat(2,minmax(180px,1fr))}
      }
      @media(max-width:620px){
        #homePage .workspace-all-worlds-shell{width:100%}
        #homePage .workspace-all-worlds-grid{grid-template-columns:1fr}
      }
    `;
    document.head.appendChild(style);
  },

  markup(world,escape){
    const enabled=!!world.enabled;
    return `<article class="workspace-all-world-card${enabled?'':' disabled'}" data-franchise="${escape(world.key)}">
      <span class="home-world-art-placeholder" aria-hidden="true"></span>
      <div class="workspace-all-world-copy">
        <b>${escape(world.title)}</b>
        <small>${escape(world.subtitle||'Franchise world')}</small>
        <em>${enabled?'AVAILABLE':'PLANNED'}</em>
      </div>
    </article>`;
  },

  render(config,escape){
    const panel=document.getElementById('allWorldsPanel');
    if(!panel)return;

    this._style();
    const worlds=(config.homeWorldCards||[]).filter(item=>!item.allWorlds);
    panel.innerHTML=`
      <div class="workspace-all-worlds-shell">
        <header class="workspace-all-worlds-head">
          <div>
            <p>MODDING WORKSPACE</p>
            <h2>ALL WORLDS</h2>
            <small>Every franchise world currently registered in this Workspace.</small>
          </div>
          <button class="workspace-all-worlds-close" type="button" data-all-worlds-close aria-label="Close All Worlds">×</button>
        </header>
        <section class="workspace-all-worlds-grid">
          ${worlds.map(item=>this.markup(item,escape)).join('')}
        </section>
      </div>
    `;
  },

  position(){},

  open(){
    const panel=document.getElementById('allWorldsPanel');
    if(!panel)return;
    panel.classList.remove('hidden');
    document.body.style.overflow='hidden';
  },

  toggle(){
    const panel=document.getElementById('allWorldsPanel');
    if(!panel)return;
    panel.classList.contains('hidden')?this.open():this.close();
  },

  close(){
    const panel=document.getElementById('allWorldsPanel');
    if(!panel)return;
    panel.classList.add('hidden');
    document.body.style.overflow='';
  },

  bind(){
    const button=document.getElementById('allWorldsToggle');
    if(button&&!button.dataset.homePickerBound){
      button.dataset.homePickerBound='true';
      button.title='Open All Worlds';
      button.addEventListener('click',event=>{
        event.preventDefault();
        event.stopPropagation();
        this.open();
      });
    }

    const panel=document.getElementById('allWorldsPanel');
    if(panel&&!panel.dataset.allWorldsBound){
      panel.dataset.allWorldsBound='true';
      panel.addEventListener('click',event=>{
        if(event.target.closest('[data-all-worlds-close]'))this.close();
      });
    }

    if(!document.documentElement.dataset.allWorldsEscapeBound){
      document.documentElement.dataset.allWorldsEscapeBound='true';
      document.addEventListener('keydown',event=>{
        if(event.key==='Escape')this.close();
      });
    }
  }
};
