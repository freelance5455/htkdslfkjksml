window.WorkspaceHomeWorldCards={
  markup(item,selectedWorld,escape){
    const attrs=item.enabled?`data-world="${escape(item.key)}"`:'disabled';
    const classes=['home-franchise-card'];
    if(item.key===selectedWorld)classes.push('selected-world');
    if(!item.enabled)classes.push('disabled');
    return `<button class="${classes.join(' ')}" data-franchise="${escape(item.key)}" ${attrs}><span class="home-world-art-placeholder"></span><span class="home-world-card-copy"><b>${escape(item.title)}</b><small>${escape(item.subtitle||'')}</small>${item.status?`<em>${escape(item.status)}</em>`:''}</span></button>`
  },
  recentMarkup(item,escape){
    if(!item)return '';
    const attrs=item.enabled?`data-world="${escape(item.key)}"`:'disabled';
    return `<button class="home-franchise-card home-recent-world-card current${item.enabled?'':' disabled'}" data-franchise="${escape(item.key)}" ${attrs}><span class="home-world-art-placeholder"></span><span class="home-recent-label">MOST RECENT</span><span class="home-world-card-copy"><b>${escape(item.title)}</b><small>Resume world</small></span></button>`
  },
  render(config,state,escape){
    const host=document.getElementById('homeWorldCards');
    if(!host)return;
    const worlds=config.homeWorldCards.filter(item=>!item.allWorlds);
    const recent=worlds.find(item=>item.key===state.route.world)||worlds.find(item=>item.enabled)||worlds[0];
    const remainingWorlds=recent?worlds.filter(item=>item.key!==recent.key):worlds;
    host.innerHTML=this.recentMarkup(recent,escape)+remainingWorlds.map(item=>this.markup(item,state.route.world,escape)).join('')
  }
};
