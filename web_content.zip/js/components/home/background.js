window.WorkspaceHomeBackground={
  _style(page){
    let style=document.getElementById('workspaceHomeHeaderStyle');
    if(!style){
      style=document.createElement('style');
      style.id='workspaceHomeHeaderStyle';
      document.head.appendChild(style);
    }

    style.textContent=`
      #homePage{
        --home-sidebar-width:198px;
        --home-sidebar-center-shift:99px;
      }
      #homePage.home-sidebar-collapsed{
        --home-sidebar-width:68px;
        --home-sidebar-center-shift:34px;
      }

      /* Reserve real layout space for the sidebar instead of laying it over
         the cards/status area. The background still covers the full page. */
      #homePage.art-slot{
        padding-left:calc(var(--home-sidebar-width) + 24px)!important;
        transition:padding-left .18s ease;
      }

      /* Top concept bar, now real UI over the Home background. */
      #homePage #workspaceHomeTopUi{
        position:absolute;
        z-index:3000;
        left:0;
        right:0;
        top:0;
        height:54px;
        display:flex;
        align-items:center;
        justify-content:space-between;
        padding:0 18px;
        box-sizing:border-box;
        background:transparent;
        pointer-events:none;
      }
      #homePage #workspaceHomeTopUi .workspace-topbar-left{
        display:flex;
        align-items:center;
        height:54px;
        pointer-events:auto;
      }
      #homePage #workspaceHomeTopUi .workspace-topbar-brand{
        display:block;
        width:300px;
        height:54px;
        object-fit:contain;
        object-position:left center;
        user-select:none;
        pointer-events:none;
      }
      #homePage #workspaceHomeTopUi .workspace-topbar-version{
        margin-left:10px;
        color:#d9d9d7;
        font:400 16px/1 "Segoe UI",sans-serif;
        letter-spacing:.03em;
        text-shadow:0 1px 5px rgba(0,0,0,.75);
        white-space:nowrap;
      }
      #homePage #workspaceHomeTopUi .workspace-topbar-controls{
        display:flex;
        align-items:center;
        gap:18px;
        height:54px;
        pointer-events:auto;
      }
      #homePage #workspaceHomeTopUi .workspace-topbar-control{
        width:28px;
        height:28px;
        padding:0;
        border:0;
        background:transparent;
        color:#e4e4e2;
        font:300 22px/1 "Segoe UI",sans-serif;
        cursor:default;
        opacity:.9;
      }
      #homePage #workspaceHomeTopUi .workspace-topbar-control:hover{opacity:1;color:#fff}
      #homePage #workspaceHomeTopUi .workspace-topbar-control[data-action="fullscreen"]{cursor:pointer}

      /* New Home-only left sidebar based on the supplied reference. */
      #homePage #workspaceHomeSidebar{
        position:absolute;
        z-index:2500;
        left:0;
        top:54px;
        bottom:0;
        width:var(--home-sidebar-width);
        box-sizing:border-box;
        display:flex;
        flex-direction:column;
        padding:20px 7px 14px;
        border-right:1px solid rgba(255,255,255,.14);
        background:linear-gradient(180deg,rgba(4,10,14,.96),rgba(4,10,14,.92));
        box-shadow:12px 0 28px rgba(0,0,0,.20);
        backdrop-filter:blur(9px);
        transition:width .18s ease;
      }
      #homePage .workspace-home-side-nav{
        display:flex;
        flex-direction:column;
        gap:8px;
      }
      #homePage .workspace-home-side-button,
      #homePage .workspace-home-side-collapse{
        appearance:none;
        width:100%;
        min-height:54px;
        display:flex;
        align-items:center;
        gap:16px;
        padding:0 16px;
        box-sizing:border-box;
        border:1px solid transparent;
        border-radius:8px;
        background:transparent;
        color:#e7e7e4;
        font:500 17px/1 "Arial Narrow","Segoe UI",sans-serif;
        letter-spacing:.025em;
        text-align:left;
        cursor:pointer;
        white-space:nowrap;
        overflow:hidden;
      }
      #homePage .workspace-home-side-button:hover,
      #homePage .workspace-home-side-collapse:hover{
        background:rgba(255,255,255,.035);
        border-color:rgba(255,255,255,.08);
      }
      #homePage .workspace-home-side-button.active{
        border-color:#b78209;
        background:linear-gradient(180deg,rgba(68,53,17,.22),rgba(29,27,19,.32));
        color:#ffba18;
      }
      #homePage .workspace-home-side-icon{
        flex:0 0 28px;
        width:28px;
        display:grid;
        place-items:center;
        color:#c9cbc9;
        font:400 26px/1 "Segoe UI Symbol","Segoe UI",sans-serif;
      }
      #homePage .workspace-home-side-button.active .workspace-home-side-icon{color:#ffb51a}
      #homePage .workspace-home-side-label{min-width:0;overflow:hidden;text-overflow:ellipsis}
      #homePage .workspace-home-side-bottom{
        margin-top:auto;
        padding-top:12px;
        border-top:1px solid rgba(255,255,255,.07);
      }
      #homePage .workspace-home-side-collapse{
        min-height:48px;
        color:#c8c8c5;
      }
      #homePage .workspace-home-side-collapse .workspace-home-side-icon{
        width:26px;
        height:26px;
        border-radius:5px;
        background:rgba(255,255,255,.035);
        color:#f2ad11;
        font-size:25px;
      }
      #homePage.home-sidebar-collapsed #workspaceHomeSidebar{
        padding-left:6px;
        padding-right:6px;
      }
      #homePage.home-sidebar-collapsed .workspace-home-side-button,
      #homePage.home-sidebar-collapsed .workspace-home-side-collapse{
        justify-content:center;
        padding:0;
        gap:0;
      }
      #homePage.home-sidebar-collapsed .workspace-home-side-label{display:none}

      /* All Home content now lives inside the same sidebar-safe content box. */
      #homePage .home-welcome,
      #homePage .home-worlds,
      #homePage .home-status-bar{
        box-sizing:border-box;
      }
      #homePage .home-world-card-row{
        width:100%!important;
        max-width:none!important;
      }

      /* Center the logo inside the actual usable content area. */
      #homePage .home-brand-lockup{
        position:absolute!important;
        z-index:5!important;
        left:50%!important;
        top:33vh!important;
        margin:0!important;
        transform:translate(-50%,-50%)!important;
      }
      #homePage .home-main-logo{
        display:block!important;
        width:min(768px,58vw)!important;
        max-width:768px!important;
        height:auto!important;
      }

      @media(max-width:900px){
        #homePage{--home-sidebar-width:68px;--home-sidebar-center-shift:34px}
        #homePage.art-slot{padding-left:88px!important}
        #homePage #workspaceHomeSidebar{width:68px;padding-left:6px;padding-right:6px}
        #homePage .workspace-home-side-button,
        #homePage .workspace-home-side-collapse{justify-content:center;padding:0;gap:0}
        #homePage .workspace-home-side-label{display:none}
        #homePage #workspaceHomeTopUi .workspace-topbar-brand{width:240px;height:auto}
        #homePage #workspaceHomeTopUi .workspace-topbar-version{font-size:13px;margin-left:4px}
        #homePage .home-brand-lockup{top:28vh!important}
        #homePage .home-main-logo{width:min(768px,78vw)!important}
      }
    `;
  },

  _sidebar(page){
    let sidebar=document.getElementById('workspaceHomeSidebar');
    if(!sidebar){
      sidebar=document.createElement('aside');
      sidebar.id='workspaceHomeSidebar';
      sidebar.setAttribute('aria-label','Home navigation');
      sidebar.innerHTML=`
        <nav class="workspace-home-side-nav">
          <button class="workspace-home-side-button active" type="button" data-home-side="home">
            <span class="workspace-home-side-icon">⌂</span><span class="workspace-home-side-label">HOME</span>
          </button>
          <button class="workspace-home-side-button" type="button" data-home-side="games">
            <span class="workspace-home-side-icon">◈</span><span class="workspace-home-side-label">GAMES</span>
          </button>
          <button class="workspace-home-side-button" type="button" data-page="library">
            <span class="workspace-home-side-icon">◇</span><span class="workspace-home-side-label">MOD LIBRARY</span>
          </button>
          <button class="workspace-home-side-button" type="button" data-home-side="search">
            <span class="workspace-home-side-icon">⌕</span><span class="workspace-home-side-label">SEARCH</span>
          </button>
          <button class="workspace-home-side-button" type="button" data-page="notes">
            <span class="workspace-home-side-icon">▤</span><span class="workspace-home-side-label">NOTES</span>
          </button>
          <button class="workspace-home-side-button" type="button" data-page="archive">
            <span class="workspace-home-side-icon">▣</span><span class="workspace-home-side-label">ARCHIVE</span>
          </button>
          <button class="workspace-home-side-button" type="button" data-home-side="settings">
            <span class="workspace-home-side-icon">⚙</span><span class="workspace-home-side-label">SETTINGS</span>
          </button>
        </nav>
        <div class="workspace-home-side-bottom">
          <button class="workspace-home-side-collapse" type="button" data-home-side="collapse">
            <span class="workspace-home-side-icon">‹</span><span class="workspace-home-side-label">COLLAPSE</span>
          </button>
        </div>
      `;
      page.prepend(sidebar);

      sidebar.addEventListener('click',event=>{
        const button=event.target.closest('[data-home-side]');
        if(!button)return;
        const action=button.dataset.homeSide;

        if(action==='games'){
          window.WorkspaceHomeWorldPicker?.open?.();
          return;
        }

        if(action==='collapse'){
          page.classList.toggle('home-sidebar-collapsed');
          localStorage.setItem('workspace-home-sidebar-collapsed',page.classList.contains('home-sidebar-collapsed')?'1':'0');
          const icon=button.querySelector('.workspace-home-side-icon');
          if(icon)icon.textContent=page.classList.contains('home-sidebar-collapsed')?'›':'‹';
          return;
        }

        /* Search and Settings are visual placeholders for now, per current UI pass. */
        if(action==='search'||action==='settings'){
          button.animate([{background:'rgba(255,181,26,.12)'},{background:'transparent'}],{duration:260});
        }
      });
    }

    const collapsed=localStorage.getItem('workspace-home-sidebar-collapsed')==='1';
    page.classList.toggle('home-sidebar-collapsed',collapsed);
    const collapseIcon=sidebar.querySelector('[data-home-side="collapse"] .workspace-home-side-icon');
    if(collapseIcon)collapseIcon.textContent=collapsed?'›':'‹';
  },

  apply(world){
    const page=document.getElementById('homePage');
    if(!page||!world)return;

    const slot=`${world.key}-home`;
    page.dataset.artSlot=slot;
    page.dataset.worldTheme=world.theme;
    document.body.dataset.worldTheme=world.theme;

    const url=window.WorkspaceAssets?.slots?.[slot]||'';
    if(url)page.style.setProperty('--backdrop-image',`url("${url}")`);
    else page.style.removeProperty('--backdrop-image');

    page.style.marginTop='0';
    page.style.height='100vh';
    page.style.minHeight='100vh';

    this._style(page);
    this._sidebar(page);

    let topBar=document.getElementById('workspaceHomeTopUi');
    if(topBar&&topBar.tagName==='IMG'){
      topBar.remove();
      topBar=null;
    }

    if(!topBar){
      topBar=document.createElement('div');
      topBar.id='workspaceHomeTopUi';
      topBar.setAttribute('aria-label','Modding Workspace header');

      const left=document.createElement('div');
      left.className='workspace-topbar-left';

      const brand=document.createElement('img');
      brand.className='workspace-topbar-brand';
      brand.src='/assets/branding/workspace-topbar-brand-transparent.png';
      brand.alt='Modding Workspace';

      const version=document.createElement('span');
      version.className='workspace-topbar-version';
      version.id='workspaceHomeLiveVersion';
      version.textContent=window.WorkspaceVersion?.current?.().display_version||'';

      left.append(brand,version);

      const controls=document.createElement('div');
      controls.className='workspace-topbar-controls';
      controls.setAttribute('aria-label','Window-style controls');

      const minimize=document.createElement('button');
      minimize.className='workspace-topbar-control';
      minimize.dataset.action='minimize';
      minimize.type='button';
      minimize.textContent='−';
      minimize.title='Window minimize is controlled by the browser in localhost mode';

      const fullscreen=document.createElement('button');
      fullscreen.className='workspace-topbar-control';
      fullscreen.dataset.action='fullscreen';
      fullscreen.type='button';
      fullscreen.textContent='□';
      fullscreen.title='Toggle fullscreen';
      fullscreen.addEventListener('click',async()=>{
        try{
          if(document.fullscreenElement)await document.exitFullscreen();
          else await document.documentElement.requestFullscreen();
        }catch{}
      });

      const close=document.createElement('button');
      close.className='workspace-topbar-control';
      close.dataset.action='close';
      close.type='button';
      close.textContent='×';
      close.title='Window close is controlled by the browser in localhost mode';

      controls.append(minimize,fullscreen,close);
      topBar.append(left,controls);
      page.prepend(topBar);
    }

    const updateVersion=value=>{
      const node=document.getElementById('workspaceHomeLiveVersion');
      if(node)node.textContent=value?.display_version||`v${value?.version||''}`;
    };
    updateVersion(window.WorkspaceVersion?.current?.());
    window.WorkspaceVersion?.load?.().then(updateVersion).catch(()=>{});
  }
};
