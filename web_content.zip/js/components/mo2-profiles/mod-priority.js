window.WorkspaceMo2ModPriority=(()=>{
  let d=null;const $=id=>document.getElementById(id);
  function configure(deps){d=deps;return api}
  function render(model){const mods=model?.mods||[],host=$('mo2ModList');if(!host)return;host.innerHTML=mods.length?mods.map(m=>`<div class="mo2-mod-row${Number(m.is_separator)?' separator':''}" ${m.matched_mod_id?`data-open="${Number(m.matched_mod_id)}"`:''}><span>${Number(m.priority)+1}</span><b>${d.ui.escape(m.mod_name||'')}</b><span class="${Number(m.enabled)?'enabled':'disabled'}">${Number(m.is_separator)?'Separator':(Number(m.enabled)?'Enabled':'Disabled')}</span><span>${d.ui.escape(m.version||'—')}</span><span class="${m.matched_mod_id?'matched':''}">${m.matched_mod_id?`Matched · ${d.ui.escape(m.match_method||'')}`:'No match'}</span></div>`).join(''):'<p>No MO2 mods found in this profile.</p>'}
  return api={configure,render};
})();
