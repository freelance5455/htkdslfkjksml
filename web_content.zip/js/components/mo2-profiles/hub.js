window.WorkspaceMo2ProfilesHub=(()=>{
  let d=null,bound=false;
  function configure(deps){d=deps;d.state.configure({installedState:d.installedState,pluginOwnership:d.pluginOwnership});d.profileState.configure({ui:d.ui});d.modPriority.configure({ui:d.ui});d.pluginLoadOrder.configure({ui:d.ui,pluginOwnership:d.pluginOwnership});d.loadOrderInterpretation?.configure({api:d.api,state:d.state,modNameFor:d.modNameFor});d.evidence.configure({api:d.api,state:d.state,fileOverlaps:d.fileOverlaps,pluginRecords:d.pluginRecords,questEvidence:d.questEvidence,relationshipEvidence:d.relationshipEvidence,loadOrderInterpretation:d.loadOrderInterpretation});d.scans.configure({api:d.api,toast:d.toast,profileState:d.profileState,fileOverlaps:d.fileOverlaps,pluginRecords:d.pluginRecords,evidence:d.evidence,applyPayload});return api}
  function applyPayload(payload){const model=d.state.build(payload);d.profileState.render(model);d.modPriority.render(model);d.pluginLoadOrder.render(model);return model}
  async function loadState(){try{return applyPayload(await d.api('/api/mo2/status'))}catch(error){d.profileState.setUnavailable('MO2 evidence is unavailable on this runtime. Windows performs live scans; Linux can display saved Windows snapshots when the snapshot bridge is running.',true);return null}}
  async function show(){d.showSection('gameProfiles','MO2 Profile State');await loadState();await d.evidence.loadAll()}
  function bind(){if(bound)return;bound=true;d.scans.bind()}
  return api={configure,applyPayload,loadState,show,bind};
})();
