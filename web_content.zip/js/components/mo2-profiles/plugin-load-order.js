window.WorkspaceMo2PluginLoadOrder=(()=>{
  let d=null;const $=id=>document.getElementById(id);
  function configure(deps){d=deps;return api}
  function render(model){const plugins=model?.plugins||[],host=$('mo2PluginList');if(!host)return;host.innerHTML=plugins.length?plugins.map(p=>d.pluginOwnership.profileMarkup(p,d.ui.escape)).join(''):'<p>No plugin load order was captured.</p>'}
  return api={configure,render};
})();
