window.WorkspaceMo2ProfileState=(()=>{
  let d=null;const $=id=>document.getElementById(id);
  function configure(deps){d=deps;return api}
  function setUnavailable(message,bad=false){const host=$('mo2Status');if(!host)return;host.className=`mo2-status${bad?' bad':''}`;host.textContent=message}
  function render(model){const payload=model?.payload||{},latest=model?.latest,savedOnly=Boolean(model?.savedOnly),rootInput=$('mo2Root'),buttons=[$('mo2Scan'),$('mo2OverlapScan'),$('mo2RecordScan')],readOnlyBadge=$('mo2ReadOnly');
    if(rootInput){rootInput.readOnly=savedOnly;rootInput.title=savedOnly?'Saved Windows MO2 path. Refresh this snapshot on Windows.':'';if(payload?.configured_root||payload?.detected_root)rootInput.value=payload.configured_root||payload.detected_root}
    for(const button of buttons)if(button){button.disabled=savedOnly;button.title=savedOnly?'Saved Windows evidence is view-only on Linux. Run scans on Windows, then copy the updated Workspace.':''}
    if(readOnlyBadge)readOnlyBadge.textContent=savedOnly?'SAVED WINDOWS SNAPSHOT':'READ ONLY';
    if(!latest){setUnavailable(payload?.platform==='windows'?'MO2 was not detected yet. Enter its root folder or use Detect & Refresh.':'Windows MO2 state has not been captured yet.');return}
    const {run,realMods,enabled,plugins,matches,ownership}=model;const host=$('mo2Status');host.className='mo2-status good';host.textContent=savedOnly?`Saved Windows MO2 snapshot captured ${run.synced_at||''}. Viewing it read-only on Linux; refresh/scans stay on Windows. ${ownership.ownership_rows?`${ownership.unique_plugins} plugin${ownership.unique_plugins===1?'':'s'} linked to saved MO2 providers.`:''}`:`Read-only snapshot captured ${run.synced_at||''}. ${ownership.ownership_rows?`${ownership.unique_plugins} plugin${ownership.unique_plugins===1?'':'s'} linked to MO2 mod-folder providers.`:'Refresh once to capture plugin providers.'}`;
    $('mo2Profile').textContent=run.profile_name||'Unknown';$('mo2ModCount').textContent=realMods.length;$('mo2EnabledCount').textContent=enabled.length;$('mo2PluginCount').textContent=plugins.length;$('mo2MatchCount').textContent=matches.length
  }
  return api={configure,render,setUnavailable};
})();
