window.WorkspaceMo2ProfilesState=(()=>{
  let d=null,current=null;
  function configure(deps){d=deps;return api}
  function normalizeRows(value){let rows=value;for(let i=0;i<4;i++){if(typeof rows==='string'){try{rows=JSON.parse(rows);continue}catch{return[]}}if(Array.isArray(rows)&&rows.length===1&&(Array.isArray(rows[0])||typeof rows[0]==='string')){rows=rows[0];continue}break}if(!Array.isArray(rows))rows=rows&&typeof rows==='object'?[rows]:[];return rows.flat(4).filter(row=>row&&typeof row==='object'&&!Array.isArray(row))}
  function build(payload){d.installedState.ingest(payload);const latest=payload?.latest||null,savedOnly=Boolean(payload?.saved_snapshot||payload?.platform==='linux-saved-snapshot'),run=latest?.run||{},mods=latest?normalizeRows(latest.mods):[],plugins=latest?normalizeRows(latest.plugins):[],realMods=mods.filter(m=>!Number(m.is_separator)),enabled=realMods.filter(m=>Number(m.enabled)),matches=realMods.filter(m=>m.matched_mod_id),ownership=d.pluginOwnership.counts();current={payload,latest,savedOnly,run,mods,plugins,realMods,enabled,matches,ownership};return current}
  return api={configure,build,current:()=>current,normalizeRows};
})();
