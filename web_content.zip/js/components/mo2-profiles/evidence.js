window.WorkspaceMo2ProfilesEvidence=(()=>{
  let d=null;
  function configure(deps){d=deps;return api}
  async function loadAll(){const [overlap,records,quest,relationship]=await Promise.all([d.fileOverlaps.loadStatus(d.api),d.pluginRecords.loadStatus(d.api),d.questEvidence.loadProfile(d.api),d.relationshipEvidence.loadProfile(d.api)]);d.loadOrderInterpretation?.update({model:d.state?.current?.()||null,overlap,records,relationship});return[overlap,records,quest,relationship]}
  function clearAll(){d.fileOverlaps.clearProfile();d.pluginRecords.clearProfile();d.questEvidence.clearProfile();d.relationshipEvidence.clearProfile();d.loadOrderInterpretation?.clear()}
  async function refreshQuest(){const result=await d.questEvidence.loadProfile(d.api);await refreshInterpretation();return result}
  async function refreshInterpretation(){const [overlap,records,relationship]=await Promise.all([d.fileOverlaps.loadStatus(d.api),d.pluginRecords.loadStatus(d.api),d.relationshipEvidence.loadProfile(d.api)]);d.loadOrderInterpretation?.update({model:d.state?.current?.()||null,overlap,records,relationship});return{overlap,records,relationship}}
  return api={configure,loadAll,clearAll,refreshQuest,refreshInterpretation};
})();
