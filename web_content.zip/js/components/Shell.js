import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { NavLink, Link, Outlet } from 'react-router-dom';
import { useAuth } from '../lib/AuthContext.js';
import { Avatar, Logo } from './Bits.js';
import Icon from './Icon.js';
export default function Shell() {
    const { profile, contact } = useAuth();
    const seller = profile?.role === 'seller';
    return (_jsxs("div", { className: "shell", children: [_jsxs("header", { className: "topbar", children: [_jsxs(Link, { to: "/", className: "brand", children: [_jsx(Logo, { size: 32 }), " Udaan"] }), _jsxs("div", { className: "top-right", children: [contact?.city && _jsxs("span", { className: "loc", children: [_jsx(Icon, { name: "pin", size: 14 }), contact.city] }), _jsx(Link, { to: "/profile", "aria-label": "Profile", children: _jsx(Avatar, { name: profile?.full_name }) })] })] }), _jsx("main", { className: "content", children: _jsx(Outlet, {}) }), _jsxs("nav", { className: "nav", "aria-label": "Main", children: [seller
                        ? _jsxs(NavLink, { to: "/seller", children: [_jsx(Icon, { name: "briefcase" }), "Services"] })
                        : _jsxs(NavLink, { to: "/home", children: [_jsx(Icon, { name: "home" }), "Home"] }), _jsxs(NavLink, { to: "/deals", children: [_jsx(Icon, { name: "chat" }), "Deals"] }), profile?.is_admin && _jsxs(NavLink, { to: "/admin", children: [_jsx(Icon, { name: "shieldCheck" }), "Admin"] }), _jsxs(NavLink, { to: "/profile", children: [_jsx(Icon, { name: "user" }), "Profile"] })] })] }));
}
