window.WorkspaceResearchIntakeHub=(()=>{
  let d=null,bound=false;
  const state=window.WorkspaceResearchIntakeState,queue=window.WorkspaceResearchIntakeQueue,safety=window.WorkspaceResearchIntakeSafety,transport=window.WorkspaceResearchIntakeTransport,worker=window.WorkspaceResearchIntakeWorker;
  function configure(deps){d=deps;worker.configure({state,queue,safety,transport,ui:deps.ui,toast:deps.toast,normalizer:WorkspaceResearchWorker});queue.configure({state,ui:deps.ui,toast:deps.toast,fnvMods:deps.fnvMods,modNexusIdentity:deps.modNexusIdentity,onChange:()=>worker.render()});safety.configure({state,ui:deps.ui,toast:deps.toast});transport.configure({queue,safety,ui:deps.ui,toast:deps.toast});return api}
  function bind(){if(bound)return;bound=true;queue.bind();safety.bind();transport.bind();worker.bind()}
  function render(){queue.render();safety.renderGovernor();safety.renderLog();worker.render()}
  function show(){d.showSection('gameResearch','Research Intake');render();transport.refreshStatus()}
  const api={configure,bind,render,show,state,queue,safety,transport,worker};return api
})();
