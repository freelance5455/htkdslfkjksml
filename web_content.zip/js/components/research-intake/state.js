window.WorkspaceResearchIntakeState=(()=>{
  const KEYS=Object.freeze({
    queue:'fnvResearchQueueV1',governor:'fnvResearchGovernorV1',cache:'fnvResearchApiCacheV2',sourceCache:'fnvResearchSourceCacheV1',safetyLog:'fnvResearchSafetyLogV1',jobLocks:'fnvResearchJobLocksV1',circuit:'fnvResearchCircuitV1',normalized:'fnvNormalizedResearchV6',worker:'fnvResearchWorkerStateV1'
  });
  const GOVERNOR_DEFAULTS=Object.freeze({paused:true,max_per_run:50,max_per_day:1000,min_delay_ms:1500,day:'',requests_today:0,last_request_at:0});
  const CACHE_MAX=12,SOURCE_CACHE_MAX=12;
  function readJson(key,fallback){try{const value=JSON.parse(localStorage.getItem(key)||'');return value??fallback}catch{return fallback}}
  function writeJson(key,value){localStorage.setItem(key,JSON.stringify(value));return value}
  function queueLoad(){const value=readJson(KEYS.queue,[]);return Array.isArray(value)?value:[]}
  function queueSave(value){return writeJson(KEYS.queue,Array.isArray(value)?value:[])}
  function governorLoad(){const raw=readJson(KEYS.governor,{}),today=new Date().toISOString().slice(0,10),g={...GOVERNOR_DEFAULTS,...(raw&&typeof raw==='object'&&!Array.isArray(raw)?raw:{})};if(g.day!==today){g.day=today;g.requests_today=0}return g}
  function governorSave(value){return writeJson(KEYS.governor,value)}
  function cacheLoad(){const value=readJson(KEYS.cache,{});return value&&typeof value==='object'&&!Array.isArray(value)?value:{}}
  function cacheSave(value){return writeJson(KEYS.cache,value&&typeof value==='object'&&!Array.isArray(value)?value:{})}
  function sourceCacheLoad(){const value=readJson(KEYS.sourceCache,{});return value&&typeof value==='object'&&!Array.isArray(value)?value:{}}
  function sourceCacheSave(value){return writeJson(KEYS.sourceCache,value&&typeof value==='object'&&!Array.isArray(value)?value:{})}
  function safetyLogLoad(){const value=readJson(KEYS.safetyLog,[]);return Array.isArray(value)?value:[]}
  function safetyLogSave(value){return writeJson(KEYS.safetyLog,Array.isArray(value)?value:[])}
  function jobLocksLoad(){const value=readJson(KEYS.jobLocks,{});return value&&typeof value==='object'&&!Array.isArray(value)?value:{}}
  function jobLocksSave(value){return writeJson(KEYS.jobLocks,value&&typeof value==='object'&&!Array.isArray(value)?value:{})}
  function circuitLoad(){const raw=readJson(KEYS.circuit,{});return{open:false,consecutive_failures:0,last_signature:'',same_error_count:0,last_error_at:0,...(raw&&typeof raw==='object'&&!Array.isArray(raw)?raw:{})}}
  function circuitSave(value){return writeJson(KEYS.circuit,value)}
  function normalizedLoad(){const value=readJson(KEYS.normalized,{});return value&&typeof value==='object'&&!Array.isArray(value)?value:{}}
  function normalizedSave(value){return writeJson(KEYS.normalized,value&&typeof value==='object'&&!Array.isArray(value)?value:{})}
  function workerLoad(){const raw=readJson(KEYS.worker,{});return{last_run_at:'',last_run_processed:0,last_run_manual:0,last_run_normalized:0,...(raw&&typeof raw==='object'&&!Array.isArray(raw)?raw:{})}}
  function workerSave(value){return writeJson(KEYS.worker,value)}
  function remove(keyName){const key=KEYS[keyName]||keyName;localStorage.removeItem(key)}
  function downloadJson(name,payload){const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000)}
  return{KEYS,GOVERNOR_DEFAULTS,CACHE_MAX,SOURCE_CACHE_MAX,queueLoad,queueSave,governorLoad,governorSave,cacheLoad,cacheSave,sourceCacheLoad,sourceCacheSave,safetyLogLoad,safetyLogSave,jobLocksLoad,jobLocksSave,circuitLoad,circuitSave,normalizedLoad,normalizedSave,workerLoad,workerSave,remove,downloadJson};
})();
