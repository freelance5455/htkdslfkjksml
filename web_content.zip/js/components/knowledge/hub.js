window.WorkspaceKnowledgeHub=(()=>{
  let d=null,bound=false,renderToken=0,activeCategory=null,activeOffset=0;
  const $=id=>document.getElementById(id);
  const PAGE_SIZE=100;
  function configure(deps){d=deps;return api}
  function statusLabel(provider){
    if(!provider)return'NO GAME DATA';
    if(provider.kind==='legacy_embedded')return'LEGACY DATA SOURCE';
    if(provider.kind==='game_pack')return'GAME PACK';
    return String(provider.state||'DATA SOURCE').replaceAll('_',' ').toUpperCase();
  }
  async function resolveCount(category){
    try{const value=await category.count();return Number.isFinite(Number(value))?Number(value):null}catch{return null}
  }
  function categoryCard(category,count){
    const safe=d.escape;
    const countText=count===null?'Available':`${count.toLocaleString()} record${count===1?'':'s'}`;
    return`<button type="button" class="knowledge-category-card" data-knowledge-category="${safe(category.key)}"><span>${safe(category.eyebrow)}</span><strong>${safe(category.title)}</strong><p>${safe(category.description)}</p><small>${safe(countText)}</small><i>Open ›</i></button>`;
  }
  function providerForCurrent(){return d?.registry?.get?.(d.gameKey())||null}
  function categoryForKey(key){return providerForCurrent()?.categories?.find(item=>item.key===key)||null}
  function scalarPreview(value){
    if(value===null||value===undefined)return'';
    if(typeof value==='string'||typeof value==='number'||typeof value==='boolean')return String(value);
    try{return JSON.stringify(value)}catch{return String(value)}
  }
  function recordTitle(record,index){
    if(!record||typeof record!=='object')return`Record ${index+1}`;
    for(const key of ['name','title','display_name','full_name','editor_id','form_id','id']){
      const value=record[key];if(value!==undefined&&value!==null&&String(value).trim())return String(value)
    }
    return`Record ${index+1}`;
  }
  function recordCard(record,index){
    const safe=d.escape,obj=record&&typeof record==='object'?record:{value:record};
    const rows=Object.entries(obj).slice(0,12).map(([key,value])=>{
      let text=scalarPreview(value);if(text.length>420)text=`${text.slice(0,417)}…`;
      return`<div class="knowledge-record-field"><b>${safe(key.replaceAll('_',' '))}</b><span>${safe(text||'—')}</span></div>`;
    }).join('');
    const more=Object.keys(obj).length>12?`<small class="knowledge-record-more">${Object.keys(obj).length-12} additional field${Object.keys(obj).length-12===1?'':'s'} retained in the Game Pack record.</small>`:'';
    return`<article class="knowledge-record-card"><h3>${safe(recordTitle(obj,index))}</h3>${rows}${more}</article>`;
  }
  async function render(){
    activeCategory=null;activeOffset=0;
    if(!d)return;const token=++renderToken,gameKey=d.gameKey(),provider=d.registry.get(gameKey);
    const state=$('knowledgeDataSourceState'),title=$('knowledgeDataSourceTitle'),note=$('knowledgeDataSourceNote'),meta=$('knowledgeDataSourceMeta'),host=$('knowledgeCategories');
    if(!host)return;
    if(state)state.textContent=statusLabel(provider);
    if(title)title.textContent=provider?.label||'No shared game data installed';
    if(note)note.textContent=provider?.note||'The full Workspace interface is available. Shared game records will populate here when a data provider is installed.';
    if(meta)meta.textContent=provider?`${provider.id} • ${provider.version}`:'UI READY • DATA EMPTY';
    const categories=provider?.categories||[];
    if(!categories.length){host.className='knowledge-category-grid';host.innerHTML='<div class="knowledge-empty"><b>NO KNOWLEDGE CATEGORIES AVAILABLE</b><p>The page itself is working. There is simply no shared game-data provider supplying category records yet.</p></div>';return}
    host.className='knowledge-category-grid';host.innerHTML='<div class="knowledge-loading">Loading category summaries…</div>';
    const counts=await Promise.all(categories.map(resolveCount));
    if(token!==renderToken||gameKey!==d.gameKey())return;
    host.innerHTML=categories.map((category,index)=>categoryCard(category,counts[index])).join('');
  }
  async function openCategory(key,offset=0){
    if(!d)return;
    if(key==='quests'&&typeof d.openSpecialCategory==='function'){d.openSpecialCategory(key);return}
    const category=categoryForKey(key),host=$('knowledgeCategories');if(!category||!host)return;
    const token=++renderToken;activeCategory=key;activeOffset=Math.max(0,Number(offset)||0);
    host.className='knowledge-domain-view';
    host.innerHTML=`<div class="knowledge-domain-toolbar"><button type="button" data-knowledge-back>‹ Categories</button><div><span>${d.escape(category.eyebrow)}</span><h2>${d.escape(category.title)}</h2></div></div><div class="knowledge-loading">Loading ${d.escape(category.title)} records…</div>`;
    try{
      const joiner=category.dataUrl.includes('?')?'&':'?';
      const payload=await d.api(`${category.dataUrl}${joiner}offset=${activeOffset}&limit=${PAGE_SIZE}`);
      if(token!==renderToken||activeCategory!==key)return;
      const records=Array.isArray(payload?.records)?payload.records:[];
      const total=Number.isFinite(Number(payload?.total_count))?Number(payload.total_count):(Number.isFinite(Number(payload?.record_count))?Number(payload.record_count):records.length);
      const shownStart=total?activeOffset+1:0,shownEnd=Math.min(activeOffset+records.length,total||activeOffset+records.length);
      const prev=Math.max(0,activeOffset-PAGE_SIZE),next=activeOffset+PAGE_SIZE;
      const pager=`<div class="knowledge-domain-pager"><small>${shownStart.toLocaleString()}–${shownEnd.toLocaleString()} of ${total.toLocaleString()}</small><div>${activeOffset>0?`<button type="button" data-knowledge-page="${prev}">‹ Previous</button>`:''}${next<total?`<button type="button" data-knowledge-page="${next}">Next ›</button>`:''}</div></div>`;
      const body=records.length?records.map((record,index)=>recordCard(record,activeOffset+index)).join(''):'<div class="knowledge-empty"><b>NO RECORDS</b><p>This domain is installed but currently contains no records.</p></div>';
      host.innerHTML=`<div class="knowledge-domain-toolbar"><button type="button" data-knowledge-back>‹ Categories</button><div><span>${d.escape(category.eyebrow)}</span><h2>${d.escape(category.title)}</h2></div></div>${pager}<div class="knowledge-record-list">${body}</div>${pager}`;
    }catch(error){
      if(token!==renderToken)return;
      host.innerHTML=`<div class="knowledge-domain-toolbar"><button type="button" data-knowledge-back>‹ Categories</button><div><span>${d.escape(category.eyebrow)}</span><h2>${d.escape(category.title)}</h2></div></div><div class="knowledge-empty"><b>DOMAIN COULD NOT LOAD</b><p>${d.escape(error?.message||String(error))}</p></div>`;
    }
  }
  function bind(){
    if(bound)return;bound=true;
    document.addEventListener('click',event=>{
      if(!d)return;
      const back=event.target.closest('[data-knowledge-back]');if(back){render();return}
      const page=event.target.closest('[data-knowledge-page]');if(page&&activeCategory){openCategory(activeCategory,Number(page.dataset.knowledgePage)||0);return}
      const target=event.target.closest('[data-knowledge-category]');if(!target)return;
      const key=target.dataset.knowledgeCategory;if(key)openCategory(key);
    });
  }
  const api={configure,bind,render,openCategory};return api;
})();
