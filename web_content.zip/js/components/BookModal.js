import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from 'react';
import { supabase } from '../lib/supabase.js';
import { money } from '../lib/util.js';
import { Notice } from './Bits.js';
import Icon from './Icon.js';
export default function BookModal({ target, onClose, onDone }) {
    const [note, setNote] = useState('');
    const [busy, setBusy] = useState(false);
    const [err, setErr] = useState('');
    async function confirm() {
        setBusy(true);
        setErr('');
        const { data, error } = await supabase.rpc('book_listing', { p_listing: target.id, p_note: note });
        setBusy(false);
        if (error)
            return setErr(error.message);
        onDone(data);
    }
    return (_jsx("div", { className: "modal-bg", onClick: () => !busy && onClose(), children: _jsxs("div", { className: "modal", onClick: (e) => e.stopPropagation(), children: [_jsx("div", { className: "ic-box", style: { width: 56, height: 56, borderRadius: 18, marginBottom: '.7rem' }, children: _jsx(Icon, { name: "check", size: 28 }) }), _jsx("h2", { children: "Booking pakki karein" }), _jsxs("div", { className: "card", style: { boxShadow: 'none', background: 'var(--bg)' }, children: [_jsx("div", { className: "small muted", children: target.seller_name }), _jsx("b", { children: target.title }), _jsxs("div", { className: "price", style: { marginTop: '.3rem' }, children: [money(target.price), " ", _jsx("span", { className: "small muted", style: { fontWeight: 600 }, children: target.price_unit })] })] }), _jsxs(Notice, { kind: "info", children: ["Aap seller ki likhi hui ", _jsx("b", { children: "isi price" }), " par book kar rahe hain. Admin approve karega, phir admin aap dono se rabta karega."] }), _jsxs("label", { className: "field", children: [_jsx("span", { children: "Admin ke liye note (zaroori nahi)" }), _jsx("textarea", { className: "input", value: note, onChange: (e) => setNote(e.target.value), maxLength: 300, placeholder: "Jaise: kal subah chahiye, 2 mazdoor chahiye..." })] }), err && _jsx(Notice, { kind: "error", children: err }), _jsxs("div", { className: "row", style: { marginTop: '1rem' }, children: [_jsx("button", { className: "btn ghost xl grow", onClick: onClose, disabled: busy, children: "Wapas" }), _jsx("button", { className: "btn primary xl grow", onClick: confirm, disabled: busy, children: busy ? '...' : 'Book karein' })] })] }) }));
}
