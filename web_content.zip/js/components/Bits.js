import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useAuth } from '../lib/AuthContext.js';
import { STATUS_LABEL } from '../lib/util.js';
import Icon from './Icon.js';
export const Logo = ({ size = 34 }) => (_jsx("img", { src: "./logo-mark-192.png", width: size, height: size, alt: "Udaan", style: { borderRadius: Math.round(size * 0.24), display: 'block', flex: 'none', objectFit: 'cover' } }));
export const Skel = ({ h = 16, w = '100%', r = 12, style }) => (_jsx("div", { className: "skel", style: { height: h, width: w, borderRadius: r, ...style } }));
export const ListSkeleton = ({ n = 3, h = 110 }) => (_jsx("div", { className: "list", children: Array.from({ length: n }).map((_, i) => _jsx(Skel, { h: h, r: 16 }, i)) }));
export const Splash = ({ text = 'Udaan khul raha hai...' }) => (_jsxs("div", { className: "splash", children: [_jsx(Logo, { size: 60 }), _jsx("p", { className: "muted small", children: text })] }));
const NOTICE_ICON = { info: 'info', error: 'alert', ok: 'check', warn: 'alert' };
export const Notice = ({ kind = 'info', children }) => (_jsxs("div", { className: `notice ${kind}`, children: [_jsx(Icon, { name: NOTICE_ICON[kind], size: 18 }), _jsx("div", { children: children })] }));
export const StatusChip = ({ status }) => (_jsx("span", { className: `chip st-${status}`, children: STATUS_LABEL[status] || status }));
export const Avatar = ({ name, size = 'md', gold = false }) => (_jsx("span", { className: `avatar ${size === 'lg' ? 'lg' : ''} ${gold ? 'gold' : ''}`, children: (name || '?').trim().charAt(0).toUpperCase() || '?' }));
export const Empty = ({ icon = 'grid', title, text }) => (_jsxs("div", { className: "empty", children: [_jsx("div", { className: "ic-box", children: _jsx(Icon, { name: icon, size: 28 }) }), _jsx("h3", { children: title }), text && _jsx("p", { children: text })] }));
export function Blocked() {
    const { signOut } = useAuth();
    return (_jsxs("div", { className: "splash", children: [_jsx("div", { className: "ic-box", style: { ['--c']: '#F04438', width: 64, height: 64 }, children: _jsx(Icon, { name: "alert", size: 30 }) }), _jsx("h2", { children: "Account block hai" }), _jsx("p", { className: "muted", children: "Admin ne aap ka account block kar diya hai. Madad ke liye admin se rabta karein." }), _jsx("button", { className: "btn", onClick: signOut, children: "Logout" })] }));
}
export function ConfigMissing() {
    return (_jsxs("div", { className: "splash", children: [_jsx(Logo, { size: 60 }), _jsx("h2", { children: "Supabase set nahi hai" }), _jsxs("p", { className: "muted", children: ["Website ki ", _jsx("b", { children: "config.js" }), " file kholein aur ", _jsx("b", { children: "SUPABASE_URL" }), " aur ", _jsx("b", { children: "SUPABASE_ANON_KEY" }), " apni Supabase values se bharein, phir page refresh karein."] })] }));
}
