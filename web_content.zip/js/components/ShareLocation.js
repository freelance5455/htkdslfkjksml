import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useCallback, useEffect, useRef, useState } from 'react';
import { supabase } from '../lib/supabase.js';
import { geoErrorText } from '../lib/util.js';
import { Notice } from './Bits.js';
import Icon from './Icon.js';
export default function ShareLocation({ dealId, who }) {
    const [on, setOn] = useState(false);
    const [err, setErr] = useState('');
    const [last, setLast] = useState(null);
    const watch = useRef(null);
    const lastSent = useRef(0);
    const clear = useCallback(() => {
        if (watch.current !== null) {
            navigator.geolocation.clearWatch(watch.current);
            watch.current = null;
        }
    }, []);
    useEffect(() => clear, [clear]);
    async function stop() {
        clear();
        setOn(false);
        await supabase.rpc('stop_location', { p_deal: dealId });
    }
    function start() {
        if (!navigator.geolocation)
            return setErr('Aap ka browser location support nahi karta.');
        setErr('');
        watch.current = navigator.geolocation.watchPosition(async (pos) => {
            const now = Date.now();
            if (now - lastSent.current < 4000)
                return;
            lastSent.current = now;
            const { error } = await supabase.rpc('update_location', {
                p_deal: dealId, p_lat: pos.coords.latitude, p_lng: pos.coords.longitude,
                p_acc: pos.coords.accuracy, p_heading: pos.coords.heading ?? null, p_speed: pos.coords.speed ?? null,
            });
            if (error) {
                setErr(error.message);
                clear();
                setOn(false);
            }
            else
                setLast(new Date());
        }, (e) => {
            setErr(geoErrorText(e.code));
            clear();
            setOn(false);
        }, { enableHighAccuracy: true, maximumAge: 3000, timeout: 20000 });
        setOn(true);
    }
    return (_jsxs("div", { className: "stack", children: [_jsxs("div", { className: "row between", children: [_jsxs("div", { className: "grow", children: [_jsx("b", { children: on ? 'Aap ki live location chal rahi hai' : 'Live location share karein' }), _jsxs("div", { className: "small muted", children: [who === 'seller' ? 'Buyer aur admin aap ko map par dekh sakenge.' : 'Aap ki location sirf admin ko dikhegi, seller ko nahi.', last && ` Aakhri update: ${last.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}`] })] }), on
                        ? _jsx("button", { className: "btn danger sm", onClick: stop, children: "Band karein" })
                        : _jsxs("button", { className: "btn ok sm", onClick: start, children: [_jsx(Icon, { name: "pin", size: 16 }), "Shuru karein"] })] }), on && _jsx("div", { className: "small muted", children: "Is page ko khula rakhein, warna location update rukk jati hai." }), err && _jsx(Notice, { kind: "error", children: err })] }));
}
