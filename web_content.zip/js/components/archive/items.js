window.WorkspaceArchiveItems={
  tagMarkup(mod,escape){return String(mod.tags||'').split(',').map(v=>v.trim()).filter(Boolean).slice(0,3).map(tag=>`<span class="tag">${escape(tag)}</span>`).join('')},
  reason(mod,escape){return escape(mod.archive_reason||'No reason recorded')},
  card(mod,{escape}){return`<article class="card archive-card" data-record-id="${Number(mod.id)}"><div class="card-top"><span class="status ${escape(mod.status)}">${escape(mod.status)}</span><span class="meta">${escape(mod.version||'No version')}</span></div><h3>${escape(mod.name)}</h3><div class="game">${escape(mod.game||'No game set')}</div><div class="tags">${this.tagMarkup(mod,escape)}</div><div class="archive-card-reason"><span>ARCHIVE REASON</span><b>${this.reason(mod,escape)}</b></div></article>`},
  row(mod,{escape}){return`<tr data-record-id="${Number(mod.id)}"><td><b>${escape(mod.name)}</b></td><td>${escape(mod.game)}</td><td><span class="status ${escape(mod.status)}">${escape(mod.status)}</span></td><td>${escape(mod.version)}</td><td>${this.tagMarkup(mod,escape)}</td><td class="archive-reason-cell" title="${this.reason(mod,escape)}">${this.reason(mod,escape)}</td></tr>`},
  render({list,view,escape}){
    const cards=document.getElementById('cards'),wrap=document.getElementById('tableWrap'),tbody=document.querySelector('#table tbody');
    if(cards){cards.classList.toggle('hidden',view!=='grid'||!list.length);cards.innerHTML=list.map(mod=>this.card(mod,{escape})).join('')}
    if(wrap)wrap.classList.toggle('hidden',view==='grid'||!list.length);
    if(tbody)tbody.innerHTML=list.map(mod=>this.row(mod,{escape})).join('')
  }
};
