window.WorkspaceArchiveHub=(()=>{
  let d=null;
  function configure(deps){d=deps;d.stateOwner.configure({archived:d.archived,state:d.state,filters:d.filters,fields:d.fields,knowledgeFor:d.knowledgeFor});d.presentation.configure({});return api}
  function render(){
    if(!d)return[];const list=d.stateOwner.visible();d.presentation.render(list);d.filters.syncView(d.state.view);d.items.render({list,view:d.state.view,escape:d.ui.escape.bind(d.ui)});return list
  }
  return api={configure,render};
})();
