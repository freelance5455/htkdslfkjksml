window.WorkspaceArchivePresentation=(()=>{
  let d=null;const $=id=>document.getElementById(id);
  function configure(deps){d=deps;return api}
  function setHidden(id,value){const node=$(id);if(node)node.classList.toggle('hidden',Boolean(value))}
  function render(list){
    const page=$('libraryPage');if(page)page.dataset.collectionMode='archive';
    if($('libraryTitle'))$('libraryTitle').textContent='Archive';
    if($('libraryIcon'))$('libraryIcon').textContent='▣';
    if($('collectionTab'))$('collectionTab').textContent='Archived mods';
    setHidden('add',true);setHidden('nexusImport',true);setHidden('emptyAdd',true);setHidden('libraryMo2Summary',true);setHidden('newRow',true);
    if($('libraryStateHeader'))$('libraryStateHeader').innerHTML='<span class="property-icon">□</span>Archive reason';
    if($('emptyTitle'))$('emptyTitle').textContent='Archive is empty';
    if($('emptyCopy'))$('emptyCopy').textContent='Rejected and retired mods will be kept here.';
    if($('count'))$('count').textContent=`${list.length} mod${list.length===1?'':'s'} safely preserved`;
    if($('empty'))$('empty').classList.toggle('hidden',list.length>0);
  }
  return api={configure,render};
})();
