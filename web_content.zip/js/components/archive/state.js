window.WorkspaceArchiveState=(()=>{
  let d=null;
  function configure(deps){d=deps;return api}
  function visible(){
    const search=document.getElementById('search'),filter=document.getElementById('filter');
    return d.filters.filter({records:d.archived(),query:search?.value||'',status:filter?.value||'',gameFilter:d.state.route.gameFilter,fields:d.fields,knowledgeFor:d.knowledgeFor})
  }
  return api={configure,visible};
})();
