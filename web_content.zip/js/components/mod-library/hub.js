window.WorkspaceModLibraryHub=(()=>{
  let d=null,bound=false;
  const $=id=>document.getElementById(id);
  function configure(deps){d=deps;d.editor.configure(deps.editorDeps);d.importer.configure(deps.importDeps);return api}
  function visible(){return d.filters.filter({records:d.active(),query:$('search')?.value||'',status:$('filter')?.value||'',gameFilter:d.state.route.gameFilter,fields:d.fields,knowledgeFor:d.knowledgeFor})}
  function render(){
    if(!d)return[];const list=visible(),gameFilter=d.state.route.gameFilter,page=$('libraryPage'),gameScoped=d.state.route.screen==='gameMods';if(page)page.dataset.collectionMode='library';
    if($('libraryGameContextName'))$('libraryGameContextName').textContent=gameFilter||'Fallout: New Vegas';
    $('libraryTitle').textContent=gameScoped?'Mod Library':(gameFilter||'Mod library');$('libraryIcon').textContent='▦';$('collectionTab').textContent='All mods';$('add').classList.remove('hidden');$('nexusImport').classList.remove('hidden');$('emptyAdd').classList.remove('hidden');$('newRow')?.classList.remove('hidden');$('emptyTitle').textContent='No mods here yet';$('emptyCopy').textContent='Add a mod to start building this collection.';
    $('libraryMo2Summary').classList.remove('hidden');$('libraryMo2Summary').textContent=d.installedState.summary();if($('libraryStateHeader'))$('libraryStateHeader').innerHTML='<span class="property-icon">⚙</span>MO2';
    const scope=gameFilter?` for ${gameFilter}`:' in your local library';$('count').textContent=`${list.length} mod${list.length===1?'':'s'}${scope}`;$('empty').classList.toggle('hidden',list.length>0);
    d.filters.syncView(d.state.view);d.items.render({list,view:d.state.view,isArchive:false,escape:d.ui.escape.bind(d.ui),installedState:d.installedState});return list
  }
  function bind(){
    if(bound)return;bound=true;d.filters.bind({state:d.state,onRender:d.renderCurrent});d.editor.bind();d.importer.bind();
    if($('add'))$('add').onclick=()=>d.editor.open();if($('quickAdd'))$('quickAdd').onclick=()=>d.editor.open()
  }
  function openEditor(id){return d.editor.open(id)}
  const api={configure,render,bind,openEditor,visible};return api
})();
