window.WorkspaceModLibraryEditor=(()=>{
  let d=null,bound=false;
  const $=id=>document.getElementById(id);
  function configure(deps){d=deps;return api}
  function find(id){return d.active().find(item=>item.id===id)||d.archived().find(item=>item.id===id)||{}}
  function open(id){
    const mod=find(id),isArchived=Boolean(mod.archived_at),form=$('form');if(!form)return;
    form.reset();$('id').value=mod.id||'';d.fields.forEach(key=>$(key).value=mod[key]||(key==='status'?'Interested':''));
    $('formTitle').textContent=id?(isArchived?'Archived mod':'Edit mod'):'New mod';$('archive').classList.toggle('hidden',!id||isArchived);$('restore').classList.toggle('hidden',!isArchived);$('permanentDelete').classList.toggle('hidden',!isArchived);$('archiveReasonWrap').classList.toggle('hidden',!isArchived);
    if(id&&!isArchived)d.remember(id);d.dialogs.open('editor')
  }
  async function save(event){
    event.preventDefault();const id=$('id').value,body={};d.fields.forEach(key=>body[key]=$(key).value.trim());
    const saved=await d.api(id?`/api/mods/${id}`:'/api/mods',{method:id?'PUT':'POST',body:JSON.stringify(body)});d.dialogs.close('editor');await d.load();if(!saved.archived_at)d.remember(saved.id);d.toast(id?'Mod updated':'Mod added')
  }
  async function archive(){
    const mod=d.active().find(item=>String(item.id)===$('id').value);if(!mod)return;
    const reason=prompt(`Why are you archiving “${mod.name}”?\n\nOptional: describe incompatibility, poor quality, outdated version, or another reason.`)||'';
    await d.api(`/api/mods/${mod.id}/archive`,{method:'POST',body:JSON.stringify({reason})});d.settings.set('recent-mods',d.recentIds().filter(id=>id!==mod.id));d.dialogs.close('editor');await d.load();d.toast('Mod archived — record preserved')
  }
  async function restore(){const id=Number($('id').value);await d.api(`/api/mods/${id}/restore`,{method:'POST',body:'{}'});d.dialogs.close('editor');await d.load();d.showPage('library');d.toast('Mod restored')}
  async function permanentlyDelete(){
    const mod=d.archived().find(item=>String(item.id)===$('id').value);if(!mod)return;
    if(!confirm(`Permanently delete “${mod.name}” from the catalog?\n\nThis cannot be undone. It still will not touch any game or mod files.`))return;
    await d.api(`/api/mods/${mod.id}`,{method:'DELETE'});d.dialogs.close('editor');await d.load();d.toast('Archived record permanently deleted')
  }
  function bind(){if(bound)return;bound=true;const form=$('form');if(form)form.onsubmit=save;if($('archive'))$('archive').onclick=archive;if($('restore'))$('restore').onclick=restore;if($('permanentDelete'))$('permanentDelete').onclick=permanentlyDelete}
  const api={configure,open,bind};return api
})();
