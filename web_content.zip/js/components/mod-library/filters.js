window.WorkspaceModLibraryFilters={
  filter({records,query,status,gameFilter,fields,knowledgeFor}){
    const q=String(query||'').trim().toLowerCase();
    return (records||[]).filter(mod=>{
      const k=knowledgeFor?knowledgeFor(mod):null;
      const rich=k?JSON.stringify({research:k.research,requirements:k.requirements,relationships:k.relationships,sources:k.sources}).toLowerCase():'';
      return(!gameFilter||mod.game===gameFilter)&&(!status||mod.status===status)&&(!q||(fields||[]).some(key=>String(mod[key]||'').toLowerCase().includes(q))||rich.includes(q))
    })
  },
  bind({state,onRender}){
    const search=document.getElementById('search'),filter=document.getElementById('filter'),grid=document.getElementById('gridBtn'),table=document.getElementById('tableBtn');
    if(search)search.oninput=onRender;if(filter)filter.onchange=onRender;
    if(grid)grid.onclick=()=>{state.view='grid';this.syncView(state.view);onRender()};
    if(table)table.onclick=()=>{state.view='table';this.syncView(state.view);onRender()};
    this.syncView(state.view)
  },
  syncView(view){
    const grid=document.getElementById('gridBtn'),table=document.getElementById('tableBtn');
    if(grid)grid.classList.toggle('chosen',view==='grid');if(table)table.classList.toggle('chosen',view!=='grid')
  }
};
