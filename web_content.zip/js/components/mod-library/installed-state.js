window.WorkspaceModLibraryInstalledState=(()=>{
  let loaded=false,latest=null,loading=null;
  const byModId=new Map();

  function normalizeRows(value){
    let rows=value;
    for(let i=0;i<4;i++){
      if(typeof rows==='string'){
        try{rows=JSON.parse(rows);continue}catch{return[]}
      }
      if(Array.isArray(rows)&&rows.length===1&&(Array.isArray(rows[0])||typeof rows[0]==='string')){rows=rows[0];continue}
      break
    }
    if(!Array.isArray(rows))rows=rows&&typeof rows==='object'?[rows]:[];
    return rows.flat(4).filter(row=>row&&typeof row==='object'&&!Array.isArray(row))
  }

  function ingest(payload){
    latest=payload?.latest||null;
    if(window.WorkspacePluginOwnership)window.WorkspacePluginOwnership.ingest(payload);
    byModId.clear();
    if(latest){
      for(const row of normalizeRows(latest.mods)){
        if(Number(row.is_separator))continue;
        const id=Number(row.matched_mod_id);
        if(Number.isInteger(id)&&id!==0)byModId.set(id,row)
      }
    }
    loaded=true;
    return payload
  }

  async function refresh(api){
    if(loading)return loading;
    loading=api('/api/mo2/status').then(ingest).catch(()=>{loaded=true;latest=null;byModId.clear();if(window.WorkspacePluginOwnership)window.WorkspacePluginOwnership.ingest({latest:null});return null}).finally(()=>{loading=null});
    return loading
  }

  async function ensure(api){if(loaded)return latest;return refresh(api)}
  function isFnv(mod){return ['Fallout: New Vegas','Fallout New Vegas','New Vegas'].includes(String(mod?.game||''))}
  function priority(row){const n=Number(row?.priority);return Number.isFinite(n)?n+1:null}
  function matchLabel(row){if(!row)return'—';if(row.match_method==='nexus_mod_id')return'Nexus ID';if(row.match_method==='exact_name')return'Exact name';return row.match_method||'Exact match'}
  function info(mod){
    if(!isFnv(mod))return{kind:'na',label:'—',short:'—',priority:null,row:null};
    if(!loaded)return{kind:'loading',label:'Loading MO2…',short:'Loading…',priority:null,row:null};
    if(!latest)return{kind:'offline',label:'MO2 not connected',short:'Not connected',priority:null,row:null};
    const row=byModId.get(Number(mod?.id))||null;
    if(!row)return{kind:'missing',label:'Not installed in MO2',short:'Not installed',priority:null,row:null};
    const enabled=Number(row.enabled)===1,p=priority(row);
    return{kind:enabled?'enabled':'disabled',label:`Installed · ${enabled?'Enabled':'Disabled'}`,short:`${enabled?'Enabled':'Disabled'}${p?` · #${p}`:''}`,priority:p,row,version:String(row.version||'').trim(),match:matchLabel(row)}
  }
  function className(kind){return`mo2-state mo2-${kind}`}
  function cardMarkup(mod,escape){const x=info(mod);if(x.kind==='na')return'';return`<div class="mo2-card-state ${className(x.kind)}"><span>MO2</span><b>${escape(x.short)}</b></div>`}
  function tableMarkup(mod,escape){const x=info(mod);if(x.kind==='na')return'<span class="mo2-state mo2-na">—</span>';return`<span class="${className(x.kind)}">${escape(x.short)}</span>`}
  function summary(){if(!loaded)return'MO2: loading snapshot…';if(!latest)return'MO2: not connected';const run=latest.run||{},profile=run.profile_name||'Unknown';return`MO2: ${profile} · ${byModId.size} library match${byModId.size===1?'':'es'}`}
  function applyDetail(mod){
    const x=info(mod),state=document.getElementById('detailMo2State'),prio=document.getElementById('detailMo2Priority'),match=document.getElementById('detailMo2Match'),installedVersion=document.getElementById('detailInstalledVersion');
    if(!state)return;
    state.className=`detail-mo2-value ${className(x.kind)}`;state.textContent=x.label;
    if(prio)prio.textContent=x.priority?`#${x.priority}`:'—';if(match)match.textContent=x.row?x.match:'—';if(installedVersion&&x.row&&x.version)installedVersion.textContent=x.version
  }
  return{ingest,refresh,ensure,info,cardMarkup,tableMarkup,summary,applyDetail,isLoaded:()=>loaded,latest:()=>latest}
})();
// Compatibility alias for older callers while the page migrates to component ownership.
window.WorkspaceMo2LibraryOverlay=window.WorkspaceModLibraryInstalledState;
