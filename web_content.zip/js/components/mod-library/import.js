window.WorkspaceModLibraryImport=(()=>{
  let d=null,bound=false;
  const $=id=>document.getElementById(id);
  function configure(deps){d=deps;return api}
  async function importFile(file){
    const text=await file.text(),incoming=WorkspaceNexusImport.parse(text);if(!incoming.length)throw new Error('No Nexus mod records were found in that JSON file.');
    const existing=new Set([...d.active(),...d.archived()].map(WorkspaceNexusImport.key));let added=0,skipped=0,failed=0;
    for(const mod of incoming){const key=WorkspaceNexusImport.key(mod);if(existing.has(key)){skipped++;continue}try{await d.api('/api/mods',{method:'POST',body:JSON.stringify(mod)});existing.add(key);added++}catch{failed++}}
    await d.load();d.showPage('library',d.gameFilter());d.toast(`Nexus import: ${added} added, ${skipped} skipped${failed?`, ${failed} failed`:''}`);return{added,skipped,failed}
  }
  function bind(){
    if(bound)return;bound=true;const button=$('nexusImport'),input=$('nexusJsonFile');if(button)button.onclick=()=>input?.click();if(input)input.onchange=async event=>{const file=event.target.files?.[0];event.target.value='';if(!file)return;try{await importFile(file)}catch(error){alert(`Nexus JSON import failed: ${error.message}`)}}
  }
  const api={configure,importFile,bind};return api
})();
