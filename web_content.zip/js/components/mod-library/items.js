window.WorkspaceModLibraryItems={
  tagMarkup(mod,escape){return String(mod?.tags||'').split(',').filter(Boolean).slice(0,3).map(tag=>`<span class="tag">${escape(tag.trim())}</span>`).join('')},
  card(mod,{escape,isArchive,installedState}){
    return`<article class="card" data-open="${mod.id}"><div class="card-top"><span class="status ${escape(mod.status)}">${escape(mod.status)}</span><span class="meta">${escape(mod.version||'No version')}</span></div><h3>${escape(mod.name)}</h3><div class="game">${escape(mod.game||'No game set')}</div><div class="tags">${this.tagMarkup(mod,escape)}</div>${isArchive?'':installedState.cardMarkup(mod,escape)}</article>`
  },
  row(mod,{escape,isArchive,installedState}){
    return`<tr data-open="${mod.id}"><td><b>${escape(mod.name)}</b></td><td>${escape(mod.game)}</td><td><span class="status ${escape(mod.status)}">${escape(mod.status)}</span></td><td>${escape(mod.version)}</td><td>${this.tagMarkup(mod,escape)}</td><td>${isArchive?'—':installedState.tableMarkup(mod,escape)}</td></tr>`
  },
  render({list,view,isArchive,escape,installedState}){
    const cards=document.getElementById('cards'),wrap=document.getElementById('tableWrap'),tbody=document.querySelector('#table tbody');
    if(cards){cards.classList.toggle('hidden',view!=='grid'||!list.length);cards.innerHTML=list.map(mod=>this.card(mod,{escape,isArchive,installedState})).join('')}
    if(wrap)wrap.classList.toggle('hidden',view==='grid'||!list.length);
    if(tbody)tbody.innerHTML=list.map(mod=>this.row(mod,{escape,isArchive,installedState})).join('')
  }
};
