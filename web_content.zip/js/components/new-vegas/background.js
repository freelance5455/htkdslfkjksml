window.WorkspaceNewVegasBackground={
  apply({world,game}){
    const page=document.getElementById('gamePage');
    if(!page)return;
    page.dataset.artSlot='fallout-new-vegas-hub';
    page.dataset.worldTheme=world.theme;
    page.dataset.gameKey=game.key;
  }
};
