window.WorkspaceNewVegasFooter={
  reset(){const node=document.getElementById('gameFooterProfile');if(node)node.textContent='—'},
  renderProfile(profile){const node=document.getElementById('gameFooterProfile');if(node)node.textContent=profile||'—'}
};
