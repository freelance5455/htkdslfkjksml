window.WorkspaceNewVegasStatus={
  reset(){
    const set=(id,value)=>{const node=document.getElementById(id);if(node)node.textContent=value};
    set('gameOverviewProfile','—');set('gameOverviewMods','—');set('gameOverviewPlugins','—');set('gameOverviewLoadOrder','—');set('gameOverviewNvse','—');set('gameOverviewSync','—');set('gameMo2TopStatus','⚙ MO2: Not connected');set('gameSystemsTopStatus','◇ Workspace Ready');set('gameLocalTopStatus','▱ Local Workspace');set('gameMo2ConnectionStatus','MO2 Not Connected');set('gameCompatibilityStatus','Compatibility: Not analyzed')
  },
  render(payload,normalizeRows){
    this.reset();const latest=payload?.latest;if(!latest)return null;const set=(id,value)=>{const node=document.getElementById(id);if(node)node.textContent=value},run=latest.run||{},mods=normalizeRows(latest.mods),plugins=normalizeRows(latest.plugins),realMods=mods.filter(m=>!Number(m.is_separator)),enabledPlugins=plugins.filter(p=>Number(p.enabled)),profile=run.profile_name||'Unknown',nvse=plugins.some(p=>/nvse/i.test(String(p.plugin_name||'')))?'Detected':'—';
    set('gameOverviewProfile',profile);set('gameOverviewMods',realMods.length);set('gameOverviewPlugins',enabledPlugins.length);set('gameOverviewLoadOrder',plugins.length);set('gameOverviewNvse',nvse);set('gameOverviewSync',run.synced_at?String(run.synced_at).replace('T',' ').slice(0,16):'—');set('gameMo2TopStatus','⚙ MO2: New Vegas');set('gameSystemsTopStatus','◇ MO2 Snapshot Loaded');set('gameInstalledStatus',`${realMods.length} Mod${realMods.length===1?'':'s'} Installed`);set('gameMo2ConnectionStatus','MO2 Connected');
    return{profile,modCount:realMods.length,pluginCount:enabledPlugins.length,loadOrderCount:plugins.length,nvse}
  },
  async load(api,normalizeRows){try{return this.render(await api('/api/mo2/status'),normalizeRows)}catch{this.reset();return null}}
};
