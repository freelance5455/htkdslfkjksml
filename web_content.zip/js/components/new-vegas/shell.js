window.WorkspaceNewVegasShell={
  prepare({world,game}){
    const page=document.getElementById('gamePage'),back=document.getElementById('gameWorldBack');
    if(page){page.dataset.gameKey=game.key;page.dataset.nvPage='dashboard'}
    if(back){back.dataset.world=world.key;back.textContent='‹';back.title=`Back to ${world.title} world`}
  }
};
