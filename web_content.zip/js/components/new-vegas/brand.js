window.WorkspaceNewVegasBrand={
  render({game}){
    const title=document.getElementById('gameTitle'),region=document.getElementById('gameRegion'),tagline=document.getElementById('gameTagline');
    if(title)title.innerHTML='<span>Fallout</span><strong>NEW VEGAS</strong>';
    if(region)region.textContent=game.region;
    if(tagline)tagline.innerHTML=`<b>Welcome back, Courier.</b><br>The Mojave's waiting.<br>Your setup is in your hands.`;
  }
};
