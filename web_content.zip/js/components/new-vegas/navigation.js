window.WorkspaceNewVegasNavigation={
  items:[['overview','Dashboard'],['mods','Mod Library'],['knowledge','Knowledge Database'],['research','Research Intake'],['compatibility','Compatibility'],['archive','Archive'],['profiles','Profiles'],['tools','Tools'],['settings','Settings']],
  render(ui){const host=document.getElementById('gameNav');if(host)host.innerHTML=ui.gameNavigation(this.items)+'<button type="button" data-field-guide="true">Field Guide</button>'}
};

