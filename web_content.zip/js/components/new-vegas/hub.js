window.WorkspaceNewVegasHub={
  show({world,game,records,ui,router,assets,api,normalizeRows}){
    const gameMods=records.filter(mod=>game.dbNames.includes(mod.game)),installed=gameMods.filter(mod=>mod.status==='Installed').length;
    WorkspaceNewVegasShell.prepare({world,game});
    WorkspaceNewVegasBackground.apply({world,game});
    WorkspaceNewVegasBrand.render({game});
    WorkspaceNewVegasNavigation.render(ui);
    WorkspaceNewVegasRecentMods.render(game,records,ui.escape.bind(ui));
    WorkspaceNewVegasFooter.reset();
    WorkspaceNewVegasStatus.reset();
    const installedNode=document.getElementById('gameInstalledStatus');if(installedNode)installedNode.textContent=`${installed} Mod${installed===1?'':'s'} Installed`;
    router.show('game',game.title,{page:'game',game:game.key,gameFilter:''});document.body.dataset.worldTheme=world.theme;document.body.dataset.gameKey=game.key;assets.apply();
    WorkspaceNewVegasStatus.load(api,normalizeRows).then(summary=>WorkspaceNewVegasFooter.renderProfile(summary?.profile||'—'))
  }
};
