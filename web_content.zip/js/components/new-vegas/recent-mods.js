window.WorkspaceNewVegasRecentMods={
  render(game,records,escape){
    const host=document.getElementById('gameRecentMods');if(!host)return;
    const mods=records.filter(mod=>game.dbNames.includes(mod.game)).slice().sort((a,b)=>String(b.updated_at||'').localeCompare(String(a.updated_at||''))).slice(0,8);
    host.innerHTML=mods.length?mods.map(mod=>`<button class="recent-mod-row" data-open="${mod.id}"><span><i>▧</i><b>${escape(mod.name)}</b></span><small>${escape((mod.updated_at||'—').slice(0,10))}</small><em>${escape(mod.status||'—')}</em></button>`).join(''):'<button class="recent-mod-row preview-row" disabled><span><i>▧</i><b>No shared Game Pack mods available</b></span><small>—</small><em>Unavailable</em></button>'
  }
};
