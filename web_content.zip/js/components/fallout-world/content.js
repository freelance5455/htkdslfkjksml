window.WorkspaceFalloutWorldContent={
  render(world){
    if(!world)return;
    const description=document.getElementById('worldDescription'),count=document.getElementById('worldGameCount');
    if(description)description.textContent=world.description||'';
    if(count)count.textContent=`${world.games.length} available worlds`;
  }
};
