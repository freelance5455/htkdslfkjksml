window.WorkspaceFalloutWorldHub={
  render({world,selectedKey,assets}){
    if(!world)return;
    WorkspaceFalloutWorldBackground.render(world);
    WorkspaceFalloutWorldBrand.render(world);
    WorkspaceFalloutWorldContent.render(world);
    WorkspaceFalloutWorldNavigation.render(world);
    WorkspaceFalloutWorldHours.render(world);
    const row=document.getElementById('gameCardRow');
    if(row)row.innerHTML=world.games.map((game,index)=>WorkspaceGameCards.markup(game,index,game.key===selectedKey,WorkspaceUI.escape.bind(WorkspaceUI))).join('');
  },
  show({world,selectedKey,router,assets}){
    this.render({world,selectedKey,assets});
    router.show('world',world.title,{page:'world',world:world.key,gameFilter:''});
    document.body.dataset.worldTheme=world.theme;
    if(assets&&typeof assets.apply==='function')assets.apply();
  }
};
