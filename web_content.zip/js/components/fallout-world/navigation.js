window.WorkspaceFalloutWorldNavigation={
  render(){
    const back=document.getElementById('worldBack');
    if(!back)return;
    back.textContent='← Return to world selection';
    back.title='Return to world selection';
  }
};
