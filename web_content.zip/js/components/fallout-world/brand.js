window.WorkspaceFalloutWorldBrand={
  render(world){
    if(!world)return;
    const hero=document.getElementById('worldHero'),mark=document.getElementById('worldMark'),motto=document.getElementById('worldMotto'),title=document.getElementById('worldTitle'),logo=document.getElementById('worldTitleLogo');
    if(hero)hero.dataset.worldTheme=world.theme;
    if(mark)mark.textContent=world.glyph||'';
    if(motto)motto.textContent=world.motto||'';
    if(title)title.textContent=world.title||'';
    if(logo&&title){const fallout=world.key==='fallout';logo.classList.toggle('hidden',!fallout);title.classList.toggle('hidden',fallout)}
  }
};
