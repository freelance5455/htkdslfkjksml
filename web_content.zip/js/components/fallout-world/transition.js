window.WorkspaceFalloutWorldTransition=(()=>{
  let busy=false;
  const overlay=()=>document.getElementById('worldEntryTransition');
  function backdropUrl(world,assets){return assets?.slots?.[`${world.key}-franchise`]||assets?.slots?.[`${world.key}-home`]||''}
  function clear(){
    const layer=overlay();
    if(layer){layer.className='world-entry-transition';layer.removeAttribute('data-world');layer.style.removeProperty('--entry-backdrop')}
    document.querySelectorAll('.world-entry-card-clone').forEach(node=>node.remove());
    busy=false;
  }
  function enter({world,sourceCard,assets,onEnter}){
    if(busy||!world)return false;
    const layer=overlay(),reduced=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if(!layer||!sourceCard||reduced){if(typeof onEnter==='function')onEnter();return true}
    busy=true;
    const url=backdropUrl(world,assets);if(url)layer.style.setProperty('--entry-backdrop',`url("${url}")`);
    layer.dataset.world=world.key;
    layer.className=`world-entry-transition active ${world.key==='fallout'?'fallout-entry':'generic-entry'}`;
    const rect=sourceCard.getBoundingClientRect(),clone=sourceCard.cloneNode(true);
    clone.className='world-entry-card-clone';clone.style.left=`${rect.left}px`;clone.style.top=`${rect.top}px`;clone.style.width=`${rect.width}px`;clone.style.height=`${rect.height}px`;
    clone.removeAttribute('data-world');clone.removeAttribute('disabled');document.body.appendChild(clone);
    requestAnimationFrame(()=>requestAnimationFrame(()=>clone.classList.add('launch')));
    window.setTimeout(()=>layer.classList.add('vault-phase'),280);
    window.setTimeout(()=>{if(typeof onEnter==='function')onEnter();layer.classList.add('world-visible')},1380);
    window.setTimeout(clear,1740);
    return true;
  }
  return{enter,clear,isBusy:()=>busy,backdropUrl};
})();
