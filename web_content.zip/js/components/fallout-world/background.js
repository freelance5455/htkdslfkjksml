window.WorkspaceFalloutWorldBackground={
  render(world){
    const page=document.getElementById('worldPage');
    if(!page||!world)return;
    page.dataset.artSlot=`${world.key}-franchise`;
    page.dataset.worldTheme=world.theme;
    document.body.dataset.worldTheme=world.theme;
  }
};
