window.WorkspaceFalloutWorldHours={
  total(world){return (world?.games||[]).reduce((sum,game)=>sum+(Number(game.previewStats?.hours)||0),0)},
  render(world){const node=document.getElementById('worldHoursTotal');if(!node)return;const total=this.total(world);node.textContent=total?`${total.toLocaleString()}h`:'—'}
};
