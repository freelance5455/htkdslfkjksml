/* ===================================================================
 * VFL.Competitions.EuropeanCup
 * پیاده‌سازی فرمت جدید لیگ قهرمانان اروپا (از فصل ۲۰۲۴/۲۵ به بعد):
 *   ۳۲ تیم (بر اساس سهمیه‌های کشوری موجود) → مرحله لیگ (۸ بازی هرکدام،
 *   حریفان متفاوت) → ۸ تیم برتر مستقیم به یک‌شانزدهم، ۹ تا ۲۴ پلی‌آف
 *   رفت‌وبرگشت برای ۸ جای باقی‌مانده، ۲۵ تا ۳۲ حذف → یک‌شانزدهم،
 *   یک‌چهارم، نیمه‌نهایی (همه رفت‌وبرگشت) → فینال تک‌بازی.
 *
 * چون تعداد تیم‌ها به تیم‌های واقعی موجود در دیتابیس محدود است (بدون
 * اختراع تیم جدید)، مجموع سهمیه‌های فعلی ۳۲ تیم است، نه ۳۶ تیم واقعی
 * UEFA — ساختار مرحله لیگ/پلی‌آف/حذفی همان فرمت جدید است، فقط اندازه
 * استخر تیم‌ها با دیتابیس فعلی تطبیق داده شده.
 *
 * این ماژول کاملاً مستقل از UI است.
 * =================================================================== */
(function (VFL) {
  "use strict";

  VFL.Competitions = VFL.Competitions || {};

  function shuffle(arr) {
    var a = arr.slice();
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var tmp = a[i]; a[i] = a[j]; a[j] = tmp;
    }
    return a;
  }

  // تیم‌های لیگ قهرمانان را بر اساس سهمیه هر کشور (از VFL.Config) انتخاب می‌کند —
  // در هر کشور، تیم‌ها بر اساس Overall مرتب و تیم‌های برتر انتخاب می‌شوند.
  VFL.Competitions.selectChampionsLeagueTeams = function () {
    var quotas = VFL.Config.championsLeague.quotas;
    var selected = [];
    Object.keys(quotas).forEach(function (country) {
      var quota = quotas[country];
      var teams = VFL.Data.Teams.filter(function (t) { return t.country === country; })
        .slice().sort(function (a, b) { return b.overall - a.overall; })
        .slice(0, quota);
      teams.forEach(function (t) { selected.push(t.id); });
    });
    return selected;
  };

  // مرحله لیگ: هر تیم ۸ بازی با ۸ حریف متفاوت (گراف دایره‌ای — بدون تکرار حریف)
  VFL.Competitions.buildLeaguePhase = function (teamIds) {
    var n = teamIds.length;
    var matchesPerTeam = Math.min(8, n - 1);
    var maxDistance = Math.floor(matchesPerTeam / 2);
    var matches = [];
    for (var i = 0; i < n; i++) {
      for (var d = 1; d <= maxDistance; d++) {
        var j = (i + d) % n;
        var homeIsI = Math.random() < 0.5;
        matches.push({
          id: VFL.Utils.uid("cl"),
          home: homeIsI ? teamIds[i] : teamIds[j],
          away: homeIsI ? teamIds[j] : teamIds[i],
          played: false,
          result: null
        });
      }
    }
    return matches;
  };

  // جفت‌سازی بر اساس سیدینگ: بهترین در برابر ضعیف‌ترین، بازنده به‌ترتیب رتبه
  // تیم بهتر (رتبه بالاتر) لِگ برگشت را در خانه بازی می‌کند
  VFL.Competitions.pairBySeeding = function (rankedTeamIds) {
    var n = rankedTeamIds.length;
    var ties = [];
    for (var i = 0; i < n / 2; i++) {
      var better = rankedTeamIds[i];
      var worse = rankedTeamIds[n - 1 - i];
      ties.push(VFL.Competitions.createTwoLegTie(worse, better)); // بهتر در لگ دوم میزبان است
    }
    return ties;
  };

  VFL.Competitions.createTwoLegTie = function (leg1HomeTeamId, leg2HomeTeamId) {
    return {
      id: VFL.Utils.uid("tie"),
      leg1: { home: leg1HomeTeamId, away: leg2HomeTeamId, played: false, result: null },
      leg2: { home: leg2HomeTeamId, away: leg1HomeTeamId, played: false, result: null },
      aggregateWinner: null,
      penalties: false
    };
  };

  VFL.Competitions.resolveTie = function (tie) {
    if (!tie.leg1.played || !tie.leg2.played) return tie;
    var teamA = tie.leg1.home, teamB = tie.leg1.away;
    var aggA = tie.leg1.result.homeGoals + tie.leg2.result.awayGoals;
    var aggB = tie.leg1.result.awayGoals + tie.leg2.result.homeGoals;
    if (aggA > aggB) tie.aggregateWinner = teamA;
    else if (aggB > aggA) tie.aggregateWinner = teamB;
    else { tie.aggregateWinner = Math.random() < 0.5 ? teamA : teamB; tie.penalties = true; }
    return tie;
  };
})(window.VFL || (window.VFL = {}));
