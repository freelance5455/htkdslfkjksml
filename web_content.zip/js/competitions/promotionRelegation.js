/* ===================================================================
 * VFL.Competitions.PromotionRelegation
 * موتور عمومی صعود و سقوط بین دو لیگ (بالا/پایین)، بر اساس یک کانفیگ:
 *   { upperLeagueId, lowerLeagueId, autoPromote, relegate, playoffFrom, playoffTo }
 * برای انگلیس طبق درخواست کاربر: autoPromote=2, relegate=3, playoff از رتبه ۳ تا ۶.
 * این فایل مستقل از UI و مستقل از یک کشور خاص است — با کانفیگ متفاوت
 * برای هر کشور دیگری هم قابل استفاده است.
 * =================================================================== */
(function (VFL) {
  "use strict";

  VFL.Competitions = VFL.Competitions || {};

  /**
   * بر اساس جدول نهایی دو لیگ، تیم‌های صعودکننده/سقوط‌کننده/پلی‌آفی را مشخص می‌کند.
   * ورودی‌ها باید از قبل با VFL.Utils.sortStandings مرتب شده باشند.
   */
  VFL.Competitions.computePromotionRelegation = function (link, upperStandingsSorted, lowerStandingsSorted) {
    var relegatedFromUpper = upperStandingsSorted.slice(-link.relegate).map(function (r) { return r.teamId; });
    var autoPromotedFromLower = lowerStandingsSorted.slice(0, link.autoPromote).map(function (r) { return r.teamId; });
    var playoffTeams = lowerStandingsSorted.slice(link.playoffFrom - 1, link.playoffTo).map(function (r) { return r.teamId; });
    return {
      relegatedFromUpper: relegatedFromUpper,
      autoPromotedFromLower: autoPromotedFromLower,
      playoffTeams: playoffTeams // به ترتیب رتبه: [rank3, rank4, rank5, rank6]
    };
  };

  /**
   * پلی‌آف صعود را می‌سازد: ۳ در برابر ۶، ۴ در برابر ۵ (رفت و برگشت،
   * تیم با رتبه بهتر لگ دوم را در خانه بازی می‌کند)، سپس یک فینال تک‌بازی.
   */
  VFL.Competitions.buildPromotionPlayoff = function (playoffTeamsRanked) {
    var rank3 = playoffTeamsRanked[0], rank4 = playoffTeamsRanked[1],
        rank5 = playoffTeamsRanked[2], rank6 = playoffTeamsRanked[3];
    return {
      semiA: VFL.Competitions.createTwoLegTie(rank6, rank3), // رتبه بهتر (۳) لگ دوم را میزبان است
      semiB: VFL.Competitions.createTwoLegTie(rank5, rank4),
      final: null // پس از مشخص شدن دو برنده نیمه‌نهایی ساخته می‌شود
    };
  };
})(window.VFL || (window.VFL = {}));
