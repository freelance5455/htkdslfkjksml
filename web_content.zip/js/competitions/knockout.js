/* ===================================================================
 * VFL.Competitions.Knockout
 * ساخت و پیشبرد جدول حذفی — مستقل از UI و مستقل از موتور شبیه‌سازی.
 * =================================================================== */
(function (VFL) {
  "use strict";

  VFL.Competitions = VFL.Competitions || {};

  function shuffle(arr) {
    var a = arr.slice();
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var tmp = a[i]; a[i] = a[j]; a[j] = tmp;
    }
    return a;
  }

  function nextPowerOfTwo(n) {
    var p = 1;
    while (p < n) p *= 2;
    return p;
  }

  function roundLabel(matchCount, byesRound) {
    if (byesRound) return "دور اول";
    if (matchCount === 1) return "فینال";
    if (matchCount === 2) return "نیمه‌نهایی";
    if (matchCount === 4) return "یک‌چهارم نهایی";
    if (matchCount === 8) return "یک‌هشتم نهایی";
    if (matchCount === 16) return "یک‌شانزدهم نهایی";
    return "دور حذفی";
  }

  /**
   * جدول حذفی اولیه را می‌سازد. اگر تعداد تیم‌ها توان دو نباشد،
   * تعدادی از تیم‌ها به‌صورت تصادفی مستقیم به دور بعد صعود می‌کنند (bye).
   */
  VFL.Competitions.createBracket = function (teamIds) {
    var shuffled = shuffle(teamIds);
    var n = shuffled.length;
    var pow2 = nextPowerOfTwo(n);
    var byeCount = pow2 - n;
    var byeTeams = shuffled.slice(0, byeCount);
    var playIn = shuffled.slice(byeCount);

    var matches = [];
    for (var i = 0; i < playIn.length; i += 2) {
      matches.push({
        id: VFL.Utils.uid("km"),
        home: playIn[i],
        away: playIn[i + 1],
        played: false,
        result: null,
        winner: null
      });
    }

    return {
      rounds: [{
        id: "round-1",
        label: roundLabel(matches.length, byeCount > 0),
        matches: matches,
        byes: byeTeams
      }],
      championTeamId: matches.length === 0 && byeTeams.length === 1 ? byeTeams[0] : null
    };
  };

  /**
   * پس از اینکه همه بازی‌های دور فعلی نتیجه گرفتند، دور بعد را می‌سازد.
   * اگر فقط یک تیم باقی مانده باشد، قهرمان را مشخص می‌کند.
   */
  VFL.Competitions.advanceBracket = function (bracket) {
    var current = bracket.rounds[bracket.rounds.length - 1];
    var allPlayed = current.matches.every(function (m) { return m.played; });
    if (!allPlayed) return bracket;

    var winners = current.matches.map(function (m) { return m.winner; });
    var nextParticipants = winners.concat(current.byes || []);

    if (nextParticipants.length <= 1) {
      bracket.championTeamId = nextParticipants[0] || bracket.championTeamId;
      return bracket;
    }

    var shuffled = shuffle(nextParticipants);
    var matches = [];
    for (var i = 0; i < shuffled.length; i += 2) {
      matches.push({
        id: VFL.Utils.uid("km"),
        home: shuffled[i],
        away: shuffled[i + 1],
        played: false,
        result: null,
        winner: null
      });
    }

    bracket.rounds.push({
      id: "round-" + (bracket.rounds.length + 1),
      label: roundLabel(matches.length, false),
      matches: matches,
      byes: []
    });

    return bracket;
  };
})(window.VFL || (window.VFL = {}));
