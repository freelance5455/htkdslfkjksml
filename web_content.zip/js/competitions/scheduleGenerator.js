/* ===================================================================
 * VFL.Competitions.Schedule
 * تولید برنامه مسابقات لیگ (رفت و برگشت) با الگوریتم دایره‌ای.
 * فقط ساختار مسابقات ساخته می‌شود — هیچ نتیجه‌ای شبیه‌سازی نمی‌شود.
 * =================================================================== */
(function (VFL) {
  "use strict";

  VFL.Competitions = VFL.Competitions || {};

  /**
   * برنامه رفت و برگشت یک لیگ را می‌سازد.
   * @param {Array} teamIds آرایه شناسه تیم‌ها
   * @returns {Array} آرایه‌ای از هفته‌ها؛ هر هفته آرایه‌ای از مسابقات {home, away}
   */
  VFL.Competitions.generateRoundRobin = function (teamIds) {
    var ids = teamIds.slice();
    var hasBye = ids.length % 2 !== 0;
    if (hasBye) ids.push(null); // تیم استراحت در صورت فرد بودن

    var n = ids.length;
    var totalRounds = n - 1;
    var half = n / 2;
    var rounds = [];
    var arr = ids.slice();

    for (var r = 0; r < totalRounds; r++) {
      var round = [];
      for (var i = 0; i < half; i++) {
        var home = arr[i];
        var away = arr[n - 1 - i];
        if (home !== null && away !== null) {
          // یک هفته در میان جای میزبان/میهمان عوض می‌شود تا توزیع متعادل‌تر باشد
          round.push(r % 2 === 0 ? { home: home, away: away } : { home: away, away: home });
        }
      }
      rounds.push(round);
      // چرخش: عنصر اول ثابت، بقیه می‌چرخند
      var fixed = arr[0];
      var rest = arr.slice(1);
      rest.unshift(rest.pop());
      arr = [fixed].concat(rest);
    }

    // نیم‌فصل برگشت: میزبان و میهمان جابه‌جا می‌شوند
    var secondLeg = rounds.map(function (round) {
      return round.map(function (m) { return { home: m.away, away: m.home }; });
    });

    return rounds.concat(secondLeg);
  };

  /**
   * برنامه یک لیگ را به فیکسچرهای دارای شناسه، هفته و وضعیت تبدیل می‌کند.
   */
  VFL.Competitions.buildLeagueFixtures = function (leagueId, teamIds) {
    var weeks = VFL.Competitions.generateRoundRobin(teamIds);
    var fixtures = [];
    weeks.forEach(function (weekMatches, weekIndex) {
      weekMatches.forEach(function (m) {
        fixtures.push({
          id: VFL.Utils.uid("fx"),
          competition: "league",
          leagueId: leagueId,
          week: weekIndex + 1,
          home: m.home,
          away: m.away,
          played: false,
          result: null // { homeGoals, awayGoals } — در مرحله بعد پر می‌شود
        });
      });
    });
    return fixtures;
  };

  /**
   * ساختار placeholder برای مسابقاتی که هنوز موتور اجرایی ندارند
   * (جام حذفی، سوپر جام، لیگ قهرمانان اروپا).
   */
  VFL.Competitions.buildPlaceholderCompetition = function (id, label) {
    return {
      id: id,
      label: label,
      status: "not_implemented",
      note: "ساختار این مسابقه آماده است اما موتور اجرای آن در مرحله بعد ساخته می‌شود."
    };
  };
})(window.VFL || (window.VFL = {}));
