window.pageInit=async function(u){
  let items=await dbAll('stock');
  const c=document.querySelector('#content');
  const canManage=isSupervisor(u);
  const canDelete=isSupervisor(u);
  function current(x){return Math.max(0,Number(x.initial||0)+Number(x.entries||0)-Number(x.exits||0))}
  function st(x){const n=current(x);return n<=0?['bad','Épuisé']:n<=Number(x.alert||0)?['warn','Faible']:['ok','OK']}
  c.innerHTML=`<div class="toolbar"><div><div class="muted">Consommables, achats, consommations et ajustements</div><h2 style="margin:4px 0">Stock</h2></div>${canManage?'<button class="primary" id="add">+ Nouveau consommable</button>':''}</div><div class="card section"><div class="table-wrap"><table class="table"><thead><tr><th>Consommable</th><th>Initial</th><th>Entrées</th><th>Sorties</th><th>Actuel</th><th>Seuil</th><th>Statut</th><th>Actions</th></tr></thead><tbody id="rows"></tbody></table></div></div>`;
  async function draw(){
    items=await dbAll('stock');
    rows.innerHTML=items.filter(x=>x.active!==false).map(x=>{const [cl,txt]=st(x);return `<tr><td><b>${WS.esc(x.name)}</b></td><td>${x.initial||0}</td><td>${x.entries||0}</td><td>${x.exits||0}</td><td><b>${current(x)}</b> ${WS.esc(x.unit||'unités')}</td><td>${x.alert||0}</td><td><span class="badge ${cl}">${txt}</span></td><td>${canManage?`<button class="secondary" data-add="${x.id}">+ Ajouter</button> <button class="secondary" data-reset="${x.id}">↺ Ajuster</button> <button class="secondary" data-edit="${x.id}">Modifier</button>`:''} ${canDelete?`<button class="danger" data-delete="${x.id}">Supprimer</button>`:''}</td></tr>`}).join('')||'<tr><td colspan="8" class="empty">Aucun consommable.</td></tr>';
    c.querySelectorAll('[data-add]').forEach(b=>b.onclick=()=>addQuantity(b.dataset.add));
    c.querySelectorAll('[data-reset]').forEach(b=>b.onclick=()=>adjustQuantity(b.dataset.reset));
    c.querySelectorAll('[data-edit]').forEach(b=>b.onclick=()=>edit(b.dataset.edit));
    c.querySelectorAll('[data-delete]').forEach(b=>b.onclick=()=>deleteStock(b.dataset.delete));
  }
  async function addQuantity(id){
    const x=items.find(z=>z.id===id); if(!x)return;
    const q=Number(prompt(`Quantité achetée / ajoutée pour « ${x.name} »`, '1'));
    if(!Number.isFinite(q)||q<=0)return WS.toast('Quantité invalide.');
    const note=prompt('Motif / fournisseur (facultatif)','Achat consommables')||'Achat consommables';
    await dbPut('stockMovements',{id:WS.uid('SM'),stockId:x.id,quantity:q,agent:u.name,agentId:u.id,createdAt:Date.now(),active:true,type:'purchase',note});
    await recalcDerived(); await dbPut('audit',{id:WS.uid('AUD'),action:'stock_entry',userId:u.id,createdAt:Date.now(),meta:{stockId:x.id,quantity:q,note}});
    await draw(); WS.toast(`+${q} ${x.unit||'unités'} ajouté(s) au stock.`);
  }
  async function adjustQuantity(id){
    const x=items.find(z=>z.id===id); if(!x)return;
    const now=current(x); const target=Number(prompt(`Stock actuel : ${now}. Nouvelle quantité réelle pour « ${x.name} »`,String(now)));
    if(!Number.isFinite(target)||target<0)return WS.toast('Quantité invalide.');
    const delta=target-now; if(delta===0)return WS.toast('Aucun changement.');
    const note=prompt('Motif obligatoire de l’ajustement','Inventaire / remise à niveau');
    if(!note?.trim())return WS.toast('Le motif est obligatoire.');
    await dbPut('stockMovements',{id:WS.uid('SM'),stockId:x.id,quantity:delta,agent:u.name,agentId:u.id,createdAt:Date.now(),active:true,type:'adjustment',note:note.trim()});
    await recalcDerived(); await dbPut('audit',{id:WS.uid('AUD'),action:'stock_adjusted',userId:u.id,createdAt:Date.now(),meta:{stockId:x.id,from:now,to:target,note:note.trim()}});
    await draw(); WS.toast(`Stock ajusté à ${target} ${x.unit||'unités'}.`);
  }
  async function add(){
    const name=prompt('Nom du consommable'); if(!name?.trim())return;
    const unit=prompt('Unité','unités')||'unités'; const initial=Number(prompt('Stock initial','0')); const alert=Number(prompt('Seuil d’alerte','5'));
    if(!Number.isFinite(initial)||!Number.isFinite(alert)||initial<0||alert<0)return WS.toast('Valeurs invalides.');
    const id=WS.uid('STK'); await dbPut('stock',{id,name:name.trim(),unit,initial,entries:0,exits:0,alert,active:true,createdAt:Date.now(),updatedAt:Date.now()});
    await dbPut('audit',{id:WS.uid('AUD'),action:'stock_created',userId:u.id,createdAt:Date.now(),meta:{target:id}}); await draw(); WS.toast('Consommable ajouté.');
  }
  async function edit(id){const x=items.find(z=>z.id===id);if(!x)return;const name=prompt('Nom',x.name);if(name===null)return;const alert=Number(prompt('Seuil',String(x.alert||0)));if(!Number.isFinite(alert)||alert<0)return WS.toast('Seuil invalide.');x.name=name.trim();x.unit=prompt('Unité',x.unit||'unités')||x.unit||'unités';x.alert=alert;x.updatedAt=Date.now();await dbPut('stock',x);await dbPut('audit',{id:WS.uid('AUD'),action:'stock_updated',userId:u.id,createdAt:Date.now(),meta:{target:id}});await draw()}
  async function deleteStock(id){const x=items.find(z=>z.id===id);if(!x)return;if(!confirm(`Supprimer définitivement « ${x.name} » du catalogue ? Les mouvements historiques seront conservés.`))return;x.active=false;x.deleted=true;x.updatedAt=Date.now();await dbPut('stock',x);await dbPut('audit',{id:WS.uid('AUD'),action:'stock_deleted',userId:u.id,createdAt:Date.now(),meta:{target:id}});await draw();WS.toast('Consommable supprimé.');}
  document.getElementById('add')?.addEventListener('click',add); await draw();
}