// ===== gungame.js: SİLAH OYUNU — 20 weapons, every kill moves you up, final kill with the karambit wins =====
const GG_NEED = 2;
const GG = (() => {
  const L = [], add = (a, n, w, col) => { if (w.reserve === undefined && a !== 8) w.reserve = Math.min(240, (w.mag || 30) * 7); L.push({ a, n, w, col }); };
  // 5 pistols (archetype 7)
  add(7, 'GLOCK 17', { mag: 17, dmg: 22, rate: .12, spread: .013, reload: 1.4, auto: false }, 0x6a7078);
  add(7, 'M1911', { mag: 8, dmg: 34, rate: .2, spread: .01, reload: 1.5, kick: .016 }, 0x8a8f96);
  add(7, 'FIVE-SEVEN', { mag: 20, dmg: 27, rate: .1, spread: .012, reload: 1.5 }, 0x3a78d8);
  add(7, 'DESERT EAGLE', { mag: 7, dmg: 62, rate: .34, spread: .009, reload: 1.9, kick: .03, bloom: .012 }, 0xd8a838);
  add(7, 'REVOLVER .357', { mag: 6, dmg: 78, rate: .45, spread: .008, reload: 2.4, kick: .036, bloom: .014 }, 0xc8502e);
  // 5 SMGs (archetype 3)
  add(3, 'MAC-10', { mag: 32, dmg: 14, rate: .045, spread: .038, kick: .006, reload: 1.5 }, 0xd8a838);
  add(3, 'UZI', { mag: 32, dmg: 16, rate: .055, spread: .03, reload: 1.6 }, 0x9a9fa6);
  add(3, 'MP5', { mag: 30, dmg: 19, rate: .068, spread: .02, reload: 1.7 }, 0x39b86a);
  add(3, 'VECTOR', { mag: 33, dmg: 18, rate: .048, spread: .026, reload: 1.6 }, 0x9a5be0);
  add(3, 'P90', { mag: 50, dmg: 17, rate: .06, spread: .022, reload: 2.0 }, 0xf08a22);
  // 5 assault rifles (archetype 0)
  add(0, 'AK-47', { mag: 30, dmg: 32, rate: .1, spread: .02, kick: .01, reload: 2.2 }, 0xc8502e);
  add(0, 'M4A1', { mag: 30, dmg: 27, rate: .082, spread: .015, reload: 2.0 }, 0x3a78d8);
  add(0, 'FAMAS', { mag: 25, dmg: 24, rate: .07, spread: .019, reload: 2.0 }, 0x39b86a);
  add(0, 'AUG A3', { mag: 42, dmg: 29, rate: .09, spread: .013, reload: 2.3 }, 0x9a5be0);
  add(0, 'SCAR-H', { mag: 20, dmg: 40, rate: .12, spread: .014, kick: .011, reload: 2.2 }, 0xd8a838);
  // 2 snipers (archetype 4)
  add(4, 'SSG 08', { mag: 5, dmg: 170, rate: .9, reload: 2.6 }, 0x39b86a);
  add(4, 'BARRETT M82', { mag: 5, dmg: 280, rate: 1.25, reload: 3.2, kick: .045 }, 0xe8402c);
  // 2 shotguns (archetype 1)
  add(1, 'SPAS-12', { mag: 8, dmg: 14, pellets: 9, rate: .72, reload: 2.7 }, 0xf08a22);
  add(1, 'AA-12 OTOMATİK', { mag: 20, dmg: 10, pellets: 8, rate: .17, auto: true, spread: .06, reload: 3.1, kick: .03 }, 0xe8402c);
  // the karambit (archetype 8)
  add(8, 'KARAMBİT', { dmg: 300, rate: .34, mag: 1, reserve: 0 }, 0xe8402c);
  return L;
})();
function ggOn() { return G.mode === 'gungame'; }
function ggOf(i) { return P.ggSet && P.ggSet[i] || null; }
function ggLabel() { return 'SİLAH ' + String(G.ggLv + 1).padStart(2, '0') + ' / ' + GG.length + (G.ggLv < GG.length - 1 ? ' · ' + G.ggK + '/' + GG_NEED : ' · SON'); }
function ggApply(first) {
  const L = GG[G.ggLv]; P.gg = L; P.ggArch = L.a; P.ggSet = { [L.a]: L }; P.owned = P.owned.map((_, i) => i === L.a); invalidateWS();
  const ws = WS(L.a); P.ws[L.a] = { ammo: ws.mag, reserve: L.w.reserve !== undefined ? L.w.reserve : 0 };
  P.reload = 0; P.nextWeap = L.a; P.swT = .45; P.semiReady = true; P.kt = 9; P.kFlipT = -1; hudAmmo(); setT(H.wave, ggLabel());
}
function ggStart() { G.botCarry = []; G.ggLv = 0; G.ggK = 0; G.ggWon = false; P.owned = P.owned.map(() => false); ggApply(true); P.gren = 3; P.molo = 1; P.money = 0; hudAmmo(); }
function ggKill(e) {
  if (!ggOn() || G.ggWon || P.dead) return;
  if (G.ggLv >= GG.length - 1) {
    if (G.mode === 'tdm') return;
    G.ggWon = true; G.waveActive = false; message('KARAMBİT!', 'TÜM SİLAHLAR TAMAMLANDI'); SND.pickup();
    setTimeout(() => { if (G.state !== 'playing') return; if (SET.cine) startFinisher(() => cineCredits()); else winGame(); }, 900); return;
  }
  G.ggK++;
  if (G.ggK >= GG_NEED) {
    G.ggLv++; G.ggK = 0; P.hp = Math.min(P.maxHp, P.hp + 15); hudHealth(); SND.pickup(); ggApply(false);
    message('SİLAH ' + (G.ggLv + 1) + ' / ' + GG.length, GG[G.ggLv].n); feedLine('YENİ SİLAH: ' + GG[G.ggLv].n, 'head');
  } else setT(H.wave, ggLabel());
}

// ---- takım ölüm: choose 1 pistol + 2 main weapons in the lobby, all three kept for the whole match ----
function tdmLoadout() {
  const ld = LOBBY.load, picks = [GG[ld.m[0]], GG[ld.m[1]], GG[ld.p]], set = {};
  for (const L of picks) set[L.a] = L; set[8] = GG[GG.length - 1];
  P.ggSet = set; P.gg = null; P.ggArch = -1; P.owned = P.owned.map((_, i) => !!set[i]); invalidateWS();
  for (const a in set) { const L = set[a], ws = WS(+a); P.ws[a] = { ammo: ws.mag, reserve: +a === 8 ? 0 : Math.min(400, (L.w.mag || 30) * 12) }; }
  P.slots = [picks[0].a, picks[1].a, picks[2].a, 8]; P.cur = P.nextWeap = P.slots[0]; P.swT = 0; P.reload = 0; P.gren = 3; P.molo = 1; P.semiReady = true; P.kt = 9; P.kFlipT = -1; hudAmmo();
}
