/* military.js — Phase 2: unit types, equipment, recruitment queues, armies, generals, movement. */
(function (G) {
  'use strict';

  G.ARMY_MAX_UNITS = 9;
  G.QUEUE_MAX = 8;
  G.EQUIP = ['rifles', 'horses', 'guns', 'vehicles'];
  G.EQUIP_NAMES = { rifles: 'Rifles', horses: 'Horses', guns: 'Artillery guns', vehicles: 'Vehicles' };

  // speed = world units per day; men = full-strength headcount.
  G.UNITS = {
    infantry:  { name: 'Infantry Division',  icon: 'INF', men: 1000, gold: 45,  equip: { rifles: 1000 },                 train: 18, speed: 25, atk: 5,  def: 7, org: 50, desc: 'Backbone of every army.' },
    militia:   { name: 'Militia Garrison',   icon: 'MIL', men: 800,  gold: 20,  equip: { rifles: 400 },                  train: 8,  speed: 22, atk: 2,  def: 5, org: 35, desc: 'Cheap, fast to raise, weak attackers.' },
    cavalry:   { name: 'Cavalry Brigade',    icon: 'CAV', men: 600,  gold: 60,  equip: { rifles: 300, horses: 600 },     train: 22, speed: 45, atk: 7,  def: 4, org: 45, desc: 'Fast raiders and scouts.' },
    artillery: { name: 'Artillery Battery',  icon: 'ART', men: 300,  gold: 90,  equip: { guns: 24, horses: 100 },        train: 30, speed: 18, atk: 10, def: 3, org: 30, desc: 'Heavy firepower, slow, fragile.' },
    engineers: { name: 'Engineer Battalion', icon: 'ENG', men: 400,  gold: 70,  equip: { rifles: 300, vehicles: 10 },    train: 25, speed: 22, atk: 2,  def: 5, org: 40, desc: 'Fortifications and river crossings (used from Phase 3).' },
    tank:      { name: 'Light Tank Company', icon: 'TNK', men: 250,  gold: 160, equip: { vehicles: 40, guns: 20 },       train: 40, speed: 38, atk: 12, def: 6, org: 35, desc: 'Fast armoured striking force.' }
  };

  const GEN_FIRST = ['Aldric', 'Bruno', 'Casimir', 'Dorian', 'Edmund', 'Felix', 'Gregor', 'Hadrian', 'Ivor', 'Julian', 'Konrad', 'Leopold', 'Marek', 'Nikolai', 'Oswin', 'Pavel', 'Rurik', 'Stefan', 'Tobias', 'Viktor'];
  const GEN_LAST = ['Hartmann', 'Volkov', 'Marchetti', 'Ashford', 'Kovacs', 'Drummond', 'Falk', 'Orlov', 'Reinhardt', 'Valente', 'Brandt', 'Novak', 'Sterling', 'Dragan', 'Lindqvist'];
  const GEN_TRAIT = ['Organizer', 'Aggressive', 'Defender', 'Logistician', 'Cavalry Master', 'Gunner'];
  function ord(n) { const s = ['th', 'st', 'nd', 'rd'], v = n % 100; return n + (s[(v - 20) % 10] || s[v] || s[0]); }

  /* ---------- init ---------- */
  G.initMilitary = function (st, fresh) {
    st.nextId = st.nextId || 1;
    st.armies = st.armies || [];
    st.queues = st.queues || {};
    st.generals = st.generals || {};
    st.armyCount = st.armyCount || {};
    const rand = G.rng(777);
    for (const id in G.COUNTRIES) {
      const c = st.countries[id];
      if (!c.equip) {
        const m = G.COUNTRIES[id].manpower;
        c.equip = { rifles: Math.round(m * 0.45), horses: Math.round(m * 0.05), guns: Math.round(m * 0.012), vehicles: Math.round(m * 0.008) };
      }
      st.queues[id] = st.queues[id] || [];
      if (!st.generals[id]) {
        st.generals[id] = [];
        for (let i = 0; i < 5; i++) {
          st.generals[id].push({
            id: st.nextId++,
            name: GEN_FIRST[Math.floor(rand() * GEN_FIRST.length)] + ' ' + GEN_LAST[Math.floor(rand() * GEN_LAST.length)],
            skill: 1 + Math.floor(rand() * 4) + (rand() < 0.2 ? 1 : 0),
            trait: GEN_TRAIT[Math.floor(rand() * GEN_TRAIT.length)], army: null
          });
        }
      }
    }
    if (fresh) {
      // Starting garrisons: every nation begins with armies around its capital.
      for (const id in G.COUNTRIES) {
        const cap = G.COUNTRIES[id].capitalId;
        const own = G.provinces[cap].adj.filter(n => st.owners[n] === id);
        const spots = [cap, own[0], own[1]].filter(x => x != null);
        spots.forEach((prov, i) => {
          const a = G.createArmy(id, prov);
          const comp = i === 0 ? ['infantry', 'infantry', 'artillery', 'cavalry'] : i === 1 ? ['infantry', 'infantry', 'engineers'] : ['militia', 'militia', 'infantry'];
          comp.forEach(t => a.units.push(G.makeUnit(t)));
        });
      }
    }
  };

  G.makeUnit = function (type) {
    const d = G.UNITS[type];
    return { type: type, men: d.men, org: d.org, morale: 80 };
  };

  G.unitStats = function (u) {
    const d = G.UNITS[u.type];
    return { strength: u.men / d.men, orgPct: u.org / d.org };
  };

  /* ---------- generals ---------- */
  // Every trait has a real effect. Skill (1-5 stars) gives +5% attack, defense and firepower per star to the whole army.
  G.GEN_TRAITS = {
    'Organizer':      { icon: '🗂', desc: 'Army recovers organization 50% faster' },
    'Aggressive':     { icon: '🗡', desc: '+10% firepower when attacking' },
    'Defender':       { icon: '🛡', desc: '+10% firepower when defending' },
    'Logistician':    { icon: '📦', desc: 'Supply +0.1 (less penalty far from home)' },
    'Cavalry Master': { icon: '🐎', desc: 'Army marches 20% faster' },
    'Gunner':         { icon: '💥', desc: '+15% firepower from artillery batteries' }
  };
  G.hasTrait = function (a, t) { const g = G.generalOf(a); return !!g && g.trait === t; };

  G.freeGenerals = function (owner) { return G.state.generals[owner].filter(g => !g.army); };
  G.generalOf = function (a) { return a.general ? G.state.generals[a.owner].find(g => g.id === a.general) || null : null; };
  G.assignGeneral = function (a, gid) {
    const list = G.state.generals[a.owner];
    const old = G.generalOf(a); if (old) old.army = null;
    a.general = null;
    if (gid != null) {
      const g = list.find(x => x.id === gid);
      if (!g || g.army) return false;
      g.army = a.id; a.general = g.id;
    }
    return true;
  };
  // Cycle through: none -> each available general -> none.
  G.cycleGeneral = function (a) {
    const cur = G.generalOf(a);
    const ids = G.freeGenerals(a.owner).map(g => g.id);
    if (cur) ids.push(cur.id);
    ids.sort((x, y) => x - y);
    const opts = [null].concat(ids);
    const i = opts.indexOf(cur ? cur.id : null);
    const next = opts[(i + 1) % opts.length];
    if (cur) { cur.army = null; a.general = null; }
    return G.assignGeneral(a, next);
  };

  /* ---------- armies ---------- */
  G.createArmy = function (owner, prov) {
    const st = G.state;
    st.armyCount[owner] = (st.armyCount[owner] || 0) + 1;
    const a = { id: st.nextId++, owner: owner, name: ord(st.armyCount[owner]) + ' Army', prov: prov, units: [], general: null, path: [], progress: 0, legDays: 1 };
    st.armies.push(a);
    const free = G.freeGenerals(owner).sort((x, y) => y.skill - x.skill)[0];
    if (free) G.assignGeneral(a, free.id);
    return a;
  };
  G.armyById = function (id) { return G.state.armies.find(a => a.id === id) || null; };
  G.armiesAt = function (prov) { return G.state.armies.filter(a => a.prov === prov); };
  G.removeArmy = function (a) {
    const old = G.generalOf(a); if (old) old.army = null;
    const i = G.state.armies.indexOf(a); if (i >= 0) G.state.armies.splice(i, 1);
  };

  G.armySummary = function (a) {
    let men = 0, maxMen = 0, org = 0, maxOrg = 0, morale = 0, atk = 0, def = 0, speed = Infinity;
    a.units.forEach(u => {
      const d = G.UNITS[u.type], s = u.men / d.men;
      men += u.men; maxMen += d.men; org += u.org; maxOrg += d.org; morale += u.morale;
      atk += d.atk * s; def += d.def * s; speed = Math.min(speed, d.speed);
    });
    const n = a.units.length;
    const g = G.generalOf(a);
    return {
      n: n, men: men, maxMen: maxMen, strength: maxMen ? men / maxMen : 0,
      org: maxOrg ? org / maxOrg : 0, morale: n ? morale / n : 0,
      atk: atk * (g ? 1 + g.skill * 0.05 : 1), def: def * (g ? 1 + g.skill * 0.05 : 1),
      speed: n ? speed * (g && g.trait === 'Cavalry Master' ? 1.2 : 1) : 0, general: g
    };
  };

  G.mergeArmies = function (target, source) {
    if (target === source || target.prov !== source.prov || target.owner !== source.owner) return false;
    if (target.units.length + source.units.length > G.ARMY_MAX_UNITS) return false;
    if (target.path.length || source.path.length) return false;
    target.units = target.units.concat(source.units);
    G.removeArmy(source);
    return true;
  };

  G.detachUnit = function (a, idx) {
    if (a.units.length < 2 || a.path.length) return null;
    const u = a.units.splice(idx, 1)[0];
    const n = G.createArmy(a.owner, a.prov);
    n.units.push(u);
    return n;
  };

  G.disbandArmy = function (a) {
    const c = G.state.countries[a.owner];
    a.units.forEach(u => { c.manpower += u.men; });
    G.removeArmy(a);
  };

  /* ---------- movement ---------- */
  G.legDays = function (a, from, to) {
    const sm = G.armySummary(a), pf = G.provinces[from], pt = G.provinces[to];
    const dist = Math.hypot(pf.cx - pt.cx, pf.cy - pt.cy);
    const T = G.TERRAIN[pt.terrain].move;
    const infra = (pf.infra + pt.infra) / 2;
    const rail = (G.state.pb[from].rail + G.state.pb[to].rail) / 2;
    return Math.max(1, dist / Math.max(1, sm.speed * G.techMult(a.owner, 'speed')) * T / (1 + 0.1 * infra + 0.12 * rail));
  };

  // Dijkstra over provinces the army's owner controls (cross-border movement arrives with war in Phase 3).
  G.findPath = function (a, dest) {
    const st = G.state, P = G.provinces;
    if (dest === a.prov) return [];
    if (!G.canEnter(a, dest)) return null;
    const dist = {}, prev = {}, open = [a.prov]; dist[a.prov] = 0;
    const done = {};
    while (open.length) {
      open.sort((x, y) => dist[x] - dist[y]);
      const cur = open.shift();
      if (done[cur]) continue; done[cur] = true;
      if (cur === dest) break;
      for (const n of P[cur].adj) {
        if (!G.canEnter(a, n)) continue;
        const nd = dist[cur] + G.legDays(a, cur, n);
        if (dist[n] === undefined || nd < dist[n]) { dist[n] = nd; prev[n] = cur; open.push(n); }
      }
    }
    if (dist[dest] === undefined) return null;
    const path = []; let c = dest;
    while (c !== a.prov) { path.unshift(c); c = prev[c]; }
    return path;
  };

  G.orderMove = function (a, dest) {
    if (!a.units.length) return { ok: false, msg: 'Army has no units' };
    if (G.inBattle(a)) return { ok: false, msg: 'Army is engaged in battle' };
    if (!G.canEnter(a, dest)) return { ok: false, msg: 'Cannot enter foreign territory without declaring war' };
    const mid = a.path.length > 0 && a.progress > 0;
    const base = mid ? a.path[0] : a.prov;
    if (dest === base && !mid) return { ok: false, msg: 'Already there' };
    const saved = a.prov; a.prov = base;
    const path = dest === base ? [] : G.findPath(a, dest);
    a.prov = saved;
    if (path === null) return { ok: false, msg: 'No route to that province' };
    if (mid) path.unshift(base);
    a.path = path; a.goal = dest;
    if (!mid) { a.legDays = G.legDays(a, a.prov, path[0]); a.progress = 0; }
    return { ok: true, eta: G.etaDays(a) };
  };
  G.stopArmy = function (a) {
    a.goal = null;
    if (a.path.length) { a.path = a.progress > 0 ? [a.path[0]] : []; if (!a.path.length) a.progress = 0; }
  };
  G.etaDays = function (a) {
    if (!a.path.length) return 0;
    let d = a.legDays * (1 - a.progress), from = a.path[0];
    for (let i = 1; i < a.path.length; i++) { d += G.legDays(a, from, a.path[i]); from = a.path[i]; }
    return Math.ceil(d);
  };
  // Map position (world coords) for drawing.
  G.armyPos = function (a) {
    const p = G.provinces[a.prov];
    if (!a.path.length) return { x: p.cx, y: p.cy, moving: false };
    const q = G.provinces[a.path[0]], t = a.progress;
    return { x: p.cx + (q.cx - p.cx) * t, y: p.cy + (q.cy - p.cy) * t, moving: true };
  };

  /* ---------- recruitment ---------- */
  G.canRecruit = function (owner, type, prov) {
    const st = G.state, c = st.countries[owner], d = G.UNITS[type];
    if (!d) return { ok: false, msg: 'Unknown unit' };
    if (prov == null || st.owners[prov] !== owner || G.provinces[prov].sea) return { ok: false, msg: 'Choose one of your provinces' };
    if (st.queues[owner].length >= G.QUEUE_MAX) return { ok: false, msg: 'Recruitment queue is full' };
    if (c.treasury < d.gold) return { ok: false, msg: 'Not enough gold' };
    if (c.manpower < d.men) return { ok: false, msg: 'Not enough manpower' };
    for (const k in d.equip) if ((c.equip[k] || 0) < d.equip[k]) return { ok: false, msg: 'Not enough ' + G.EQUIP_NAMES[k].toLowerCase() };
    return { ok: true };
  };
  G.recruit = function (owner, type, prov) {
    const chk = G.canRecruit(owner, type, prov);
    if (!chk.ok) return chk;
    const st = G.state, c = st.countries[owner], d = G.UNITS[type];
    c.treasury -= d.gold; c.manpower -= d.men;
    for (const k in d.equip) c.equip[k] -= d.equip[k];
    const item = { id: st.nextId++, type: type, prov: prov, left: d.train, total: d.train };
    st.queues[owner].push(item);
    return { ok: true, item: item };
  };
  G.cancelRecruit = function (owner, itemId) {
    const st = G.state, q = st.queues[owner], i = q.findIndex(x => x.id === itemId);
    if (i < 0) return false;
    const it = q[i], d = G.UNITS[it.type], c = st.countries[owner];
    c.treasury += d.gold; c.manpower += d.men;
    for (const k in d.equip) c.equip[k] += d.equip[k];
    q.splice(i, 1); return true;
  };

  // Training completes -> unit deploys in its province; joins a stationary friendly army there if there is room.
  function deploy(owner, item) {
    const st = G.state;
    const here = G.armiesAt(item.prov).filter(a => a.owner === owner && !a.path.length && a.units.length < G.ARMY_MAX_UNITS);
    let a = here[0];
    if (!a) a = G.createArmy(owner, item.prov);
    a.units.push(G.makeUnit(item.type));
    if (owner === st.player) {
      G.logMsg(G.UNITS[item.type].name + ' ready at ' + G.provinces[item.prov].name + ' (' + a.name + ')');
      G.onDeploy && G.onDeploy(a, item);
    }
  }

  /* ---------- daily / monthly ---------- */
  G.militaryDay = function () {
    const st = G.state;
    for (const id in st.queues) {
      const q = st.queues[id];
      for (let i = 0; i < q.length;) {
        q[i].left--;
        if (q[i].left <= 0) { const it = q.splice(i, 1)[0]; if (st.owners[it.prov] === id) deploy(id, it); else { /* province lost: refund */ const d = G.UNITS[it.type], c = st.countries[id]; c.treasury += d.gold; c.manpower += d.men; for (const k in d.equip) c.equip[k] += d.equip[k]; } }
        else i++;
      }
    }
    for (const a of st.armies.slice()) {
      const moving = a.path.length > 0;
      if (moving) {
        a.progress += 1 / a.legDays;
        if (a.progress >= 1) {
          a.prov = a.path.shift(); a.progress = 0;
          if (st.owners[a.prov] !== a.owner) a.path = [];   // stop in hostile ground; goal is kept for the campaign
          if (a.path.length) a.legDays = G.legDays(a, a.prov, a.path[0]);
          else { if (a.goal === a.prov) a.goal = null; G.onArrive && G.onArrive(a); }
        }
      }
      const own = st.owners[a.prov] === a.owner;
      a.units.forEach(u => {
        const d = G.UNITS[u.type];
        if (moving) { u.org = Math.max(d.org * 0.4, u.org - 0.6); }
        else { u.org = Math.min(d.org, u.org + (own ? 1.5 : 0.5) * (G.hasTrait(a, 'Organizer') ? 1.5 : 1)); u.morale = Math.min(100, u.morale + (own ? 1 : 0.3)); }
      });
    }
  };

})(window.EMP = window.EMP || {});
