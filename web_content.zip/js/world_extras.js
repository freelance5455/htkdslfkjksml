// ===== WORLD EXTRAS: birds and a volcano landmark =====

function buildBird() {
  const mat = new THREE.MeshBasicMaterial({ color: 0x2a2a2a, side: THREE.DoubleSide });
  const wingGeo = new THREE.BufferGeometry();
  wingGeo.setAttribute('position', new THREE.BufferAttribute(new Float32Array([0, 0, 0, 0.5, 0.1, -0.3, 0.9, 0, 0]), 3));
  wingGeo.computeVertexNormals();
  const group = new THREE.Group();
  const wingL = new THREE.Mesh(wingGeo, mat);
  const wingR = new THREE.Mesh(wingGeo.clone(), mat);
  wingR.scale.x = -1;
  group.add(wingL, wingR);
  group.userData = { wingL, wingR, flapPhase: Math.random() * Math.PI * 2 };
  return group;
}

let birds = [];
function spawnBirds() {
  for (let i = 0; i < 12; i++) {
    const b = buildBird();
    const cx = (Math.random() - 0.5) * WORLD_SIZE * 0.7;
    const cz = (Math.random() - 0.5) * WORLD_SIZE * 0.7;
    b.position.set(cx, 18 + Math.random() * 8, cz);
    scene.add(b);
    birds.push({
      mesh: b, angle: Math.random() * Math.PI * 2, radius: 15 + Math.random() * 20,
      cx, cz, speed: 0.3 + Math.random() * 0.3, chirpTimer: Math.random() * 8,
    });
  }
}
spawnBirds();

function updateAngryBird(b, dt) {
  b.cx += (player.position.x - b.cx) * 0.5 * dt;
  b.cz += (player.position.z - b.cz) * 0.5 * dt;
  b.angle += dt * b.speed * 2.2;
  b.diveTimer = (b.diveTimer || 0) + dt;
  const altitude = 13 + Math.sin(b.diveTimer * 1.3) * 10;
  b.mesh.position.x = b.cx + Math.cos(b.angle) * b.radius * 0.5;
  b.mesh.position.z = b.cz + Math.sin(b.angle) * b.radius * 0.5;
  b.mesh.position.y = heightAt(b.mesh.position.x, b.mesh.position.z) + altitude;
  b.mesh.rotation.y = b.angle + Math.PI / 2;

  const dist = Math.hypot(b.mesh.position.x - player.position.x, b.mesh.position.z - player.position.z);
  if (altitude < 6 && dist < 4 && !inVehicle) {
    b.hitCd = (b.hitCd || 0) - dt;
    if (b.hitCd <= 0) {
      playerHp = Math.max(0, playerHp - 5);
      b.hitCd = 1.5;
      playHit();
    }
  }
}

function updateBirds(dt) {
  birds.forEach(b => {
    if (b.angry) updateAngryBird(b, dt);
    else {
      b.angle += dt * b.speed;
      b.mesh.position.x = b.cx + Math.cos(b.angle) * b.radius;
      b.mesh.position.z = b.cz + Math.sin(b.angle) * b.radius;
      b.mesh.rotation.y = b.angle + Math.PI / 2;
    }

    b.mesh.userData.flapPhase += dt * (b.angry ? 16 : 10);
    const flap = Math.sin(b.mesh.userData.flapPhase) * 0.6;
    b.mesh.userData.wingL.rotation.z = flap;
    b.mesh.userData.wingR.rotation.z = -flap;

    if (b.angry) {
      b.screechTimer = (b.screechTimer || 0) - dt;
      if (b.screechTimer <= 0) { playScreech(); b.screechTimer = 2 + Math.random() * 2; }
    } else {
      b.chirpTimer -= dt;
      if (b.chirpTimer <= 0) { playChirp(); b.chirpTimer = 6 + Math.random() * 10; }
    }
  });
}

// ---- Nests: steal an egg and its guardian bird turns angry and dive-bombs you ----
const NESTS = [
  { x: 90, z: -20 },
  { x: -30, z: 100 },
  { x: -100, z: -40 },
];
let nests = [];

function buildNest() {
  const group = new THREE.Group();
  const nestMat = new THREE.MeshStandardMaterial({ color: 0x6b4a2f, flatShading: true });
  const eggMat = new THREE.MeshStandardMaterial({ color: 0xe8dcc0, flatShading: true });

  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.9, 0.28, 6, 10), nestMat);
  ring.rotation.x = Math.PI / 2;
  ring.position.y = 0.3;
  ring.castShadow = true;
  group.add(ring);

  const eggs = [];
  for (let i = 0; i < 3; i++) {
    const egg = new THREE.Mesh(new THREE.SphereGeometry(0.25, 7, 6), eggMat);
    egg.scale.set(1, 1.3, 1);
    const a = (i / 3) * Math.PI * 2;
    egg.position.set(Math.cos(a) * 0.35, 0.4, Math.sin(a) * 0.35);
    egg.castShadow = true;
    group.add(egg);
    eggs.push(egg);
  }
  group.userData = { eggs };
  return group;
}

function spawnNests() {
  NESTS.forEach((n, i) => {
    const mesh = buildNest();
    mesh.position.set(n.x, heightAt(n.x, n.z), n.z);
    scene.add(mesh);
    nests.push({ mesh, x: n.x, z: n.z, stolen: false, guardianIndex: i % birds.length });
  });
}
spawnNests();

function updateNests() {
  nests.forEach(nest => {
    if (nest.stolen) return;
    const dist = Math.hypot(player.position.x - nest.x, player.position.z - nest.z);
    if (dist < 2.5) {
      nest.stolen = true;
      nest.mesh.userData.eggs.forEach(e => { e.visible = false; });
      playEggSteal();
      const guardian = birds[nest.guardianIndex];
      if (guardian && !guardian.angry) {
        guardian.angry = true;
        guardian.mesh.scale.setScalar(1.6);
        guardian.mesh.userData.wingL.material.color.setHex(0xaa2222);
        guardian.speed *= 1.8;
        showToast('You stole an egg! Something is angry now...', 2800);
      }
    }
  });
}

// ---- Volcano ----
const VOLCANO_POS = { x: -70, z: 70 };

function buildVolcano() {
  const group = new THREE.Group();
  const rockMat = new THREE.MeshStandardMaterial({ color: 0x4a3a35, flatShading: true });
  const lavaMat = new THREE.MeshStandardMaterial({ color: 0xff5522, emissive: 0xff3300, emissiveIntensity: 0.9, flatShading: true });

  const mountain = new THREE.Mesh(new THREE.CylinderGeometry(6, 22, 26, 10), rockMat);
  mountain.position.y = 13;
  mountain.castShadow = true;
  mountain.receiveShadow = true;
  group.add(mountain);

  const crater = new THREE.Mesh(new THREE.CylinderGeometry(5, 5.5, 1.5, 10), lavaMat);
  crater.position.y = 26.2;
  group.add(crater);

  return group;
}

const volcano = buildVolcano();
volcano.position.set(VOLCANO_POS.x, heightAt(VOLCANO_POS.x, VOLCANO_POS.z), VOLCANO_POS.z);
scene.add(volcano);

const volcanoBody = new CANNON.Body({ mass: 0, shape: new CANNON.Cylinder(6, 22, 26, 10) });
volcanoBody.position.set(VOLCANO_POS.x, heightAt(VOLCANO_POS.x, VOLCANO_POS.z) + 13, VOLCANO_POS.z);
world.addBody(volcanoBody);

let volcanoRumbleGain = null;
function startVolcanoRumble() {
  if (!audioCtx || volcanoRumbleGain) return;
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  osc.type = 'sawtooth';
  osc.frequency.value = 45;
  gain.gain.value = 0;
  osc.connect(gain);
  gain.connect(audioCtx.destination);
  osc.start();
  volcanoRumbleGain = gain;
}

function updateVolcanoRumble() {
  if (!volcanoRumbleGain) return;
  if (!soundOn) { volcanoRumbleGain.gain.value = 0; return; }
  const d = Math.hypot(player.position.x - VOLCANO_POS.x, player.position.z - VOLCANO_POS.z);
  volcanoRumbleGain.gain.value = Math.max(0, 1 - d / 80) * 0.06;
}
