/**
 * geo.js
 * Estrutura geográfica hierárquica: Estado → Cidade → Bairros.
 * Os bairros NÃO estão hardcoded na interface — a interface (imovel-form.js)
 * lê estes dados e monta os <select> dinamicamente. Para adicionar uma nova
 * cidade/bairro no futuro, basta editar este arquivo (ou, quando houver
 * backend, popular a tabela SERVICE_CATEGORIES-like "GEO" via API).
 *
 * Cidade piloto: Praia Grande - SP (bairros preenchidos).
 * Demais cidades já estruturadas, prontas para receber bairros depois.
 */
const GEO_BRASIL = {
  estados: [
    {
      sigla: 'SP',
      nome: 'São Paulo',
      cidades: [
        {
          nome: 'Praia Grande',
          bairros: [
            'Boqueirão','Guilhermina','Tupi','Real','Solemar','Ocian',
            'Caiçara','Aviação','Mirim','Vila Mirim','Canto do Forte',
            'Flórida Mirim','Melvi','Sítio do Campo','Vila Sônia',
            'Jardim Real','Antártica','Balneário Flórida','Esmeralda',
            'Glória','Maracanã','Nova Mirim','Ribeirópolis','Samambaia',
            'Tude Bastos','Vila Caiçara','Vila Guilhermina',
          ],
        },
        { nome: 'Santos', bairros: [] },
        { nome: 'São Vicente', bairros: [] },
        { nome: 'Guarujá', bairros: [] },
        { nome: 'Mongaguá', bairros: [] },
        { nome: 'Itanhaém', bairros: [] },
      ],
    },
  ],

  listarEstados(){
    return this.estados.map(e => ({ sigla: e.sigla, nome: e.nome }));
  },
  listarCidades(siglaEstado){
    const estado = this.estados.find(e => e.sigla === siglaEstado);
    return estado ? estado.cidades.map(c => c.nome) : [];
  },
  listarBairros(siglaEstado, nomeCidade){
    const estado = this.estados.find(e => e.sigla === siglaEstado);
    if(!estado) return [];
    const cidade = estado.cidades.find(c => c.nome === nomeCidade);
    return cidade ? cidade.bairros : [];
  },
};
