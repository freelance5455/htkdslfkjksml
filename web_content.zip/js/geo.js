/* UrbaAlerte — géolocalisation automatique */
(function(w){
'use strict';
const G=w.GEO={last:null,watchId:null,listeners:[],status:'idle',err:null};
G.onChange=f=>{G.listeners.push(f)};
function emit(){G.listeners.forEach(f=>{try{f(G)}catch(e){}})}
G.set=(lat,lng,acc,src)=>{G.last={lat,lng,acc:acc||null,t:Date.now(),src:src||'gps'};G.status='ok';G.err=null;try{localStorage.setItem('ua_lastpos',JSON.stringify(G.last))}catch(e){}emit()};
G.restore=()=>{try{const p=JSON.parse(localStorage.getItem('ua_lastpos')||'null');if(p&&!G.last){G.last=Object.assign(p,{src:'cache'});}}catch(e){}};
G.once=(opts)=>new Promise((res,rej)=>{if(!navigator.geolocation){G.status='unsupported';G.err='Géolocalisation non disponible sur cet appareil';emit();return rej(new Error(G.err))}
 G.status='loading';emit();
 navigator.geolocation.getCurrentPosition(p=>{G.set(p.coords.latitude,p.coords.longitude,p.coords.accuracy,'gps');res(G.last)},e=>{G.status=e.code===1?'denied':'error';G.err=e.code===1?'Autorisation de localisation refusée':e.code===3?'Délai dépassé — signal GPS faible':'Position indisponible';emit();rej(new Error(G.err))},Object.assign({enableHighAccuracy:true,timeout:12000,maximumAge:20000},opts||{}))});
G.watch=()=>{if(!navigator.geolocation||G.watchId!=null)return;G.watchId=navigator.geolocation.watchPosition(p=>{G.set(p.coords.latitude,p.coords.longitude,p.coords.accuracy,'gps')},e=>{if(e.code===1){G.status='denied';G.err='Autorisation de localisation refusée';emit()}},{enableHighAccuracy:true,maximumAge:15000,timeout:20000})};
G.stop=()=>{if(G.watchId!=null){navigator.geolocation.clearWatch(G.watchId);G.watchId=null}};
/* Centre approximatif de la commune de Mont-Ngafula (valeur indicative utilisée uniquement pour centrer la carte) */
G.DEFAULT={lat:-4.4500,lng:15.2800};
})(window);
