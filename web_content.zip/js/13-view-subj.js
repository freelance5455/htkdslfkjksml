/* تب دروس: خطاهای پرتکرار، تکنیک‌ها، قوانین نظام جدید، نقاط ضعف، و فهرست فصل‌های هر پایه (از جمله پایه‌ی هشتم). */
(function () {
  'use strict';
  var App = (window.App = window.App || {});
  var u = App.u;
  var D = App.D;
  var st = App.study;
  var S = function () { return App.S; };

  App.views.subj = function () {
    var grade = +App.form('subjg', { g: S().mg || 12 }).g || 12;
    App.form('subjg', {}).g = grade;
    return App.upgradeNotice() + errCard() + techCard() + rulesCard() + weakCard() + gradeTabs(grade) + gradeCards(grade);
  };

  // ---- بیشترین ایرادها ----
  function errCard() {
    var R = st.errRank();
    if (!R.length) return App.card('❗ بیشترین ایرادها', '<p class="mu">هنوز تستی با «تعداد درست» ثبت نکردی. در ثبت سریع، فیلد «از آنها درست» را پر کن تا ایرادهات دیده شود.</p>', { open: true });
    return App.card('❗ بیشترین ایرادها', R.map(function (o, i) {
      return '<div class="li"><span>' + u.fa(i + 1) + ') ' + u.esc(o.s) + ' — ' + u.esc(st.chName(o.g, o.s, o.c)) + '<br><span class="mu">' + u.fa(o.wrong) + ' غلط از ' + u.fa(o.t) + ' تست · دقت ' + u.fa(o.p) + '٪</span></span>' +
        App.sm('🎯 ضعف', 'ch-weak', { g: o.g, s: o.s, c: o.c }) + '</div>';
    }).join(''), { open: true });
  }
  App.act['ch-weak'] = function (el) {
    var g = +el.getAttribute('data-g'), s = el.getAttribute('data-s'), c = +el.getAttribute('data-c');
    var key = s + '|' + c;
    if (S().wk.some(function (x) { return !x.ok && x.s === s && x.t.indexOf(st.chName(g, s, c)) === 0; })) { App.toast('این فصل قبلاً در ضعف‌ها هست'); return; }
    var p = st.autoWeak(1, 2).find(function (o) { return o.g == g && o.s === s && o.c === c; });
    st.addWeak({ s: s, t: st.chName(g, s, c) + (p ? ' (دقت ' + p.p + '٪)' : ''), v: p && p.p < 40 ? 3 : 2, m: 20 });
    App.save(); App.render(); App.toast('به نقاط ضعف اضافه شد');
  };

  // ---- تکنیک‌ها ----
  function techCard() {
    var A = D.allSubjects();
    var f = App.form('tech', { sub: 'ریاضی' });
    if (A.indexOf(f.sub) < 0) f.sub = A[0] || 'ریاضی';
    var T = (D.TECH[f.sub] || []).concat(D.TECH0);
    return App.card('🧠 تکنیک‌های یادگیری هر درس', App.select('tech', 'sub', A.map(function (x) { return [x, x]; }), { rr: true }) +
      '<ol class="tech">' + T.map(function (x) { return '<li>' + u.esc(x) + '</li>'; }).join('') + '</ol>' +
      App.btn('🤖 مشاور برای وضعیت من شخصی‌سازی کند', 'ai-ask', { q: 'tech', tab: 'subj', sub: '' }, 'mt'), { open: false });
  }
  // ---- قوانین نظام جدید ----
  function rulesCard() {
    var k = D.KONKUR.riazi;
    var f = App.form('rules', { mg: S().mg || 12, text: S().rules || D.RULES0 });
    return App.card('🇮🇷 نظام جدید آموزشی و کنکور من', '<p class="mu">مشاور برنامه‌ریزی‌اش را براساس این متن می‌چیند. اگر چیزی عوض شد یا اشتباه بود، خودت ویرایشش کن.</p>' +
      App.field('پایه‌ی فعلی من', App.select('rules', 'mg', App.gradeOpts())) +
      '<div class="konkur-box"><b>' + u.esc(k.title) + '</b> — ' + u.pd(k.total) + ' سؤال در ' + u.pd(k.minutes) + ' دقیقه<ul>' +
      k.parts.map(function (p) { return '<li>' + u.esc(p.s) + ': ' + u.pd(p.n) + ' سؤال (' + u.pd(p.min) + ' دقیقه، دفترچه ' + u.pd(p.booklet) + ')</li>'; }).join('') +
      '</ul><div class="mu">' + u.esc(k.basis) + '</div><details><summary>نکته‌های نامطمئن</summary><ul>' + k.uncertain.map(function (x) { return '<li>' + u.esc(x) + '</li>'; }).join('') + '</ul></details></div>' +
      App.field('متن قوانین نظام جدید', '<textarea id="rules-t" class="ta tall" data-f="rules.text" aria-label="قوانین">' + u.esc(f.text) + '</textarea>') +
      '<div class="grid2"><button type="button" class="btn" data-act="rules-save">ذخیره</button><button type="button" class="btn muted" data-act="rules-reset">بازگردانی پیش‌فرض</button></div>', { open: false });
  }
  App.act['rules-save'] = function () {
    var f = App.form('rules', {});
    S().mg = +f.mg || 12;
    S().rules = String(f.text || '').slice(0, 6000) === D.RULES0 ? '' : String(f.text || '').slice(0, 6000);
    App.save(); App.render(); App.toast('ذخیره شد ✅');
  };
  App.act['rules-reset'] = function () { S().rules = ''; App.form('rules', {}).text = D.RULES0; App.save(); App.render(); };

  // ---- نقاط ضعف ----
  function weakCard() {
    var W = S().wk.slice().sort(function (a, b) { return (a.ok - b.ok) || b.v - a.v || a.m - b.m; });
    var f = App.form('wk', { s: '', t: '', v: 2 });
    if (D.allSubjects().indexOf(f.s) < 0) f.s = D.allSubjects()[0] || '';
    var auto = autoSuggest();
    return App.card('🎯 نقاط ضعف من', (auto ? auto : '') + (W.length ? W.map(function (x) {
      return '<div class="weak' + (x.ok ? ' done' : '') + '"><div class="row0 space"><b>' + (x.ok ? '✅ ' : '') + u.esc(x.s) + ' — ' + u.esc(x.t) + '</b><span class="mu">شدت: ' + ['', 'کم', 'متوسط', 'زیاد'][x.v] + '</span></div>' +
        App.bar(x.m) + '<div class="row0 wrap"><span class="mu">تسلط ' + u.pct(x.m) + '</span>' +
        (x.ok ? '' : App.sm('📈 بهتر شد', 'wk-bump', { key: x.id, v: 20 }) + App.sm('📉 هنوز ضعیفم', 'wk-bump', { key: x.id, v: -10 }) + App.sm('✅ رفع شد', 'wk-bump', { key: x.id, v: 100 })) +
        App.sm('🗑', 'wk-del', { key: x.id }) + '</div></div>';
    }).join('') : '<p class="mu">هنوز نقطه ضعفی ثبت نکردی. از مشاور بخواه پیدات کند یا خودت اضافه کن.</p>') +
      '<details class="inner" open><summary>➕ افزودن نقطه ضعف</summary><div class="grid2">' + App.field('درس', App.select('wk', 's', D.allSubjects().map(function (x) { return [x, x]; }))) +
      App.field('شدت', App.select('wk', 'v', [['3', 'زیاد'], ['2', 'متوسط'], ['1', 'کم']])) + '</div>' +
      App.field('مبحث یا مشکل (مثلاً: قوانین نیوتن)', App.input('wk', 't', { ph: 'مبحث', maxlength: 120 })) + App.btn('افزودن نقطه ضعف', 'wk-add', {}, 'mt') + '</details>' +
      App.sm('🤖 مشاور نقطه‌ضعف‌هایم را پیدا کند', 'ai-ask', { q: 'weakfind', tab: 'subj' }, 'mt'), { open: true });
  }
  function autoSuggest() {
    var A = st.autoWeak().filter(function (o) {
      return !S().wk.some(function (x) { return x.s === o.s && !x.ok && x.t.indexOf(st.chName(o.g, o.s, o.c)) >= 0; });
    }).slice(0, 3);
    if (!A.length) return '';
    return '<div class="notice-inline"><b>📉 پیشنهاد خودکار از روی دقت تست‌ها</b>' + A.map(function (o) {
      return '<div class="li"><span>' + u.esc(o.s) + ' — ' + u.esc(st.chName(o.g, o.s, o.c)) + '<br><span class="mu">دقت ' + u.fa(o.p) + '٪ از ' + u.fa(o.a) + ' تست</span></span>' + App.sm('افزودن به ضعف‌ها', 'ch-weak', { g: o.g, s: o.s, c: o.c }) + '</div>';
    }).join('') + '</div>';
  }
  App.act['wk-add'] = function () {
    var f = App.form('wk', {});
    var o = st.addWeak({ s: f.s, t: f.t, v: +f.v || 2, m: 10 });
    if (!o) { App.alert('مبحث یا مشکل را بنویس'); return; }
    f.t = ''; App.save(); App.render();
  };
  App.act['wk-bump'] = function (el) {
    st.bumpWeak(el.getAttribute('data-key'), +el.getAttribute('data-v'));
    App.save(); App.render();
  };
  App.act['wk-del'] = function (el) { st.delById(S().wk, el.getAttribute('data-key')); App.save(); App.render(); };

  // ---- پایه‌ها و فصل‌ها ----
  function gradeTabs(grade) {
    return '<div class="tabs" role="tablist" aria-label="پایه">' + D.GRADES.slice().reverse().map(function (g) {
      var on = grade === g;
      return '<button type="button" role="tab" aria-selected="' + on + '" class="' + (on ? 'on' : '') + '" data-act="subj-grade" data-g="' + g + '">' + D.GN[g] + '</button>';
    }).join('') + '</div>';
  }
  App.act['subj-grade'] = function (el) { App.form('subjg', {}).g = +el.getAttribute('data-g'); App.render(); };

  function gradeCards(grade) {
    var list = D.subjects(grade);
    var note = '';
    if (grade === 8) {
      note = '<div class="notice-inline"><b>پایه‌ی هشتم</b><p class="mu">فهرست دروس از یک منبع ثانویه (سال ۱۴۰۴–۱۴۰۵) است و تعداد فصل‌ها تأیید نشده. تعداد فصل هر درس را خودت با دکمه‌ی + و − تنظیم کن و نام فصل‌ها را هم خودت بنویس. اگر سال تحصیلی‌ات فرق دارد، فهرست را با کتاب خودت تطبیق بده.</p></div>';
    }
    if (!list.length) return note + App.card(null, '<p class="mu">برای این پایه هنوز درسی ثبت نشده.</p>');
    return note + list.map(function (sub) { return subjectCard(grade, sub); }).join('');
  }

  function subjectCard(grade, sub) {
    var s = sub.name, n = st.chCount(grade, s);
    var logs = S().logs.filter(function (l) { return l.g == grade && l.s === s; });
    var sm = u.sum(logs.filter(st.isStudy), function (l) { return l.m; });
    var cm = u.sum(logs.filter(function (l) { return !st.isStudy(l); }), function (l) { return l.m; });
    var tests = u.sum(logs, function (l) { return l.t; });
    var rows = [];
    var mx = 60;
    var CS = [];
    for (var i = 1; i <= n; i++) CS.push(st.chStat(grade, s, i));
    CS.forEach(function (x) { mx = Math.max(mx, x.sm); });
    for (var c = 1; c <= n; c++) {
      var x = CS[c - 1];
      var acc = x.ans ? ' · دقت ' + u.pct(x.ok / x.ans * 100) : '';
      rows.push('<div class="li chap"><div class="row0 space"><span>' + u.pd(c) + '. ' + u.esc(st.chName(grade, s, c)) + '</span><span class="row0">' +
        App.sm('✏️', 'ch-rename', { g: grade, s: s, i: c }) + App.sm('🎯', 'ch-weak', { g: grade, s: s, c: c }) + '</span></div>' +
        (x.sm || x.cm || x.t ? '<div class="mu">📖 ' + u.dur(x.sm) + ' · 🏫 ' + u.dur(x.cm) + ' · 📝 ' + u.fa(x.t) + ' تست' + acc + '</div>' + App.bar(x.sm / mx * 100) : '<div class="mu">بدون ثبت</div>') + '</div>');
    }
    var unknown = n === 0 ? '<p class="mu">تعداد فصل‌های این درس هنوز مشخص نیست. با دکمه‌ی + تعداد را بگذار.</p>' : '';
    var meta = sub.verified === false && grade === 8 ? ' <span class="pill">تأیید نشده</span>' : '';
    var konk = sub.konkur ? ' <span class="pill">مرتبط با کنکور</span>' : '';
    var body = '<div class="mu">📖 ' + u.dur(sm) + ' · 🏫 ' + u.dur(cm) + ' · 📝 ' + u.fa(tests) + ' تست</div>' + unknown + rows.join('') +
      '<div class="q-row chap-count"><span class="mu">تعداد فصل‌ها:</span>' + App.sm('−', 'ch-count', { g: grade, s: s, n: n - 1 }) + '<b>' + u.fa(n) + '</b>' + App.sm('+', 'ch-count', { g: grade, s: s, n: n + 1 }) + '</div>';
    return App.card(s, body, { key: 'subj|' + grade + '|' + s, open: false, sub: meta + konk });
  }
  App.act['ch-count'] = function (el) {
    var g = +el.getAttribute('data-g'), s = el.getAttribute('data-s') || '', n = +el.getAttribute('data-n');
    var subject = el.closest('details') ? el.closest('details').querySelector('summary h2') : null;
    if (!s && subject) s = subject.textContent.replace(/\s*(تأیید نشده|مرتبط با کنکور)\s*/g, '').trim();
    st.setChCount(g, s, u.clamp(n, 0, D.MAX_CH));
    App.save(); App.render();
  };
  App.act['ch-rename'] = function (el) {
    var g = +el.getAttribute('data-g'), s = el.getAttribute('data-s'), i = +el.getAttribute('data-i');
    App.resetForm('rename', { g: g, s: s, i: i, v: (S().cn || {})[st.chKey(g, s) + '|' + i] || '' });
    var html = '<div class="field"><label for="rn-in">نام فصل (مثلاً: حرکت‌شناسی). خالی = نام پیش‌فرض</label><input id="rn-in" type="text" maxlength="30" data-f="rename.v" value="' + u.esc(App.form('rename', {}).v) + '"></div><div class="grid2"><button type="button" class="btn" data-act="rename-save">تأیید</button><button type="button" class="btn muted" data-act="close-modal">انصراف</button></div>';
    App.openModal('تغییر نام فصل', html);
  };
  App.act['rename-save'] = function () {
    var f = App.form('rename', {});
    st.renameCh(f.g, f.s, f.i, f.v);
    App.closeModal(); App.save(); App.render();
  };
})();
