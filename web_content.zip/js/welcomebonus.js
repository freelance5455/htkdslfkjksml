// =======================================
// NetEarn Pro
// Welcome Bonus System
// FINAL CLEAN VERSION
//
// FLOW:
// Registration
//      ↓
// 🔒 Locked
//      ↓
// Admin verifies account
//      ↓
// verified = true
//      ↓
// 🎁 Bonus Ready
//      ↓
// Claim
//      ↓
// ⏳ Pending Approval
//      ↓
// Admin Approves
//      ↓
// ✅ Bonus Claimed
// =======================================


import { auth, db } from "./firebase.js";

import {
    onAuthStateChanged,
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";

import {
    doc,
    getDoc,
    collection,
    addDoc,
    getDocs,
    query,
    where,
    serverTimestamp,
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";


// =======================================
// CONFIG
// =======================================

let bonusAmount = 5;

const LOGIN_PAGE =
    "index.html";


// =======================================
// APP STATE
// =======================================

let currentUser = null;

let currentUserData = null;

let accountVerified = false;

let bonusRequestStatus = null;

let loading = true;


// =======================================
// ELEMENTS
// =======================================

const claimBonusBtn =
    document.getElementById(
        "claimBonusBtn"
    );

const bonusStatusBadge =
    document.getElementById(
        "bonusStatusBadge"
    );

const accountVerificationStatus =
    document.getElementById(
        "accountVerificationStatus"
    );

const welcomeBonusStatus =
    document.getElementById(
        "welcomeBonusStatus"
    );


// =======================================
// HELPER
// =======================================

async function loadWelcomeBonusAmount() {

    try {
        const settingsSnap = await getDoc(doc(db, "settings", "main"));
        const settings = settingsSnap.exists() ? settingsSnap.data() : {};
        const amount = Number(settings?.welcomeBonus);

        if (Number.isFinite(amount) && amount >= 0) {
            bonusAmount = amount;
        }

        const amountElement = document.getElementById("welcomeBonusAmount");
        if (amountElement) {
            amountElement.textContent = `৳${bonusAmount}`;
        }

    } catch (error) {
        console.warn("⚠️ Welcome Bonus amount could not be loaded:", error);
    }

}

function isVerified(data) {

    return (
        data?.verified === true ||
        data?.verified === "true"
    );

}


// =======================================
// SET STATUS CLASS
// =======================================

function setStatusClass(
    element,
    className
) {

    if (!element)
        return;

    element.className =
        "status-value";

    if (className) {

        element.classList.add(
            className
        );

    }

}


// =======================================
// LOADING UI
// =======================================

function showLoadingUI() {

    loading = true;
    accountVerified = false;


    // -----------------------------------
    // CLAIM BUTTON
    // -----------------------------------

    if (claimBonusBtn) {

        claimBonusBtn.disabled = true;

        claimBonusBtn.innerText =
            "⏳ Checking...";

    }


    // -----------------------------------
    // READY BADGE
    // -----------------------------------

    if (bonusStatusBadge) {

        bonusStatusBadge.innerText =
            "⏳ Checking...";

    }


    // -----------------------------------
    // ACCOUNT VERIFICATION STATUS
    // -----------------------------------

    if (accountVerificationStatus) {

        accountVerificationStatus.innerText =
            "⏳ Checking...";

        setStatusClass(
            accountVerificationStatus,
            "checking"
        );

    }


    // -----------------------------------
    // BONUS STATUS
    // -----------------------------------

    if (welcomeBonusStatus) {

        welcomeBonusStatus.innerText =
            "⏳ Checking...";

        setStatusClass(
            welcomeBonusStatus,
            "checking"
        );

    }

}


// =======================================
// LOCK BONUS UI
// =======================================

function lockBonusUI() {

    loading = false;
    accountVerified = false;
    bonusRequestStatus = null;


    // -----------------------------------
    // CLAIM BUTTON
    // -----------------------------------

    if (claimBonusBtn) {

        claimBonusBtn.disabled = true;

        claimBonusBtn.innerText =
            "🔒 Verify Account to Unlock";

    }


    // -----------------------------------
    // READY BADGE
    // -----------------------------------

    if (bonusStatusBadge) {

        bonusStatusBadge.innerText =
            "🔒 Bonus Locked";

        setStatusClass(
            bonusStatusBadge,
            ""
        );

    }


    // -----------------------------------
    // ACCOUNT VERIFICATION
    // -----------------------------------

    if (accountVerificationStatus) {

        accountVerificationStatus.innerText =
            "🔒 Not Verified";

        setStatusClass(
            accountVerificationStatus,
            ""
        );

    }


    // -----------------------------------
    // BONUS STATUS
    // -----------------------------------

    if (welcomeBonusStatus) {

        welcomeBonusStatus.innerText =
            "🔒 Locked";

        setStatusClass(
            welcomeBonusStatus,
            ""
        );

    }


    console.log(
        "🔒 Welcome Bonus Locked"
    );

}


// =======================================
// UNLOCK BONUS UI
// =======================================

function unlockBonusUI() {

    loading = false;
    accountVerified = true;


    // -----------------------------------
    // CLAIM BUTTON
    // -----------------------------------

    if (claimBonusBtn) {

        claimBonusBtn.disabled = false;

        claimBonusBtn.innerText =
            "🎁 Claim Welcome Bonus";

    }


    // -----------------------------------
    // READY BADGE
    // -----------------------------------

    if (bonusStatusBadge) {

        bonusStatusBadge.innerText =
            "🟢 Bonus Ready";

        setStatusClass(
            bonusStatusBadge,
            "ready"
        );

    }


    // -----------------------------------
    // ACCOUNT VERIFICATION
    // -----------------------------------

    if (accountVerificationStatus) {

        accountVerificationStatus.innerText =
            "✅ Verified";

        setStatusClass(
            accountVerificationStatus,
            "verified"
        );

    }


    // -----------------------------------
    // BONUS STATUS
    // -----------------------------------

    if (welcomeBonusStatus) {

        welcomeBonusStatus.innerText =
            "🎁 Ready";

        setStatusClass(
            welcomeBonusStatus,
            "ready"
        );

    }


    console.log(
        "🎁 Welcome Bonus Ready"
    );

}


// =======================================
// PENDING UI
// =======================================

function showPendingUI() {

    loading = false;
    accountVerified = true;
    bonusRequestStatus = "pending";


    // -----------------------------------
    // CLAIM BUTTON
    // -----------------------------------

    if (claimBonusBtn) {

        claimBonusBtn.disabled = true;

        claimBonusBtn.innerText =
            "⏳ Pending Approval";

    }


    // -----------------------------------
    // READY BADGE
    // -----------------------------------

    if (bonusStatusBadge) {

        bonusStatusBadge.innerText =
            "🟡 Pending Approval";

        setStatusClass(
            bonusStatusBadge,
            ""
        );

    }


    // -----------------------------------
    // ACCOUNT VERIFICATION
    // -----------------------------------

    if (accountVerificationStatus) {

        accountVerificationStatus.innerText =
            "✅ Verified";

        setStatusClass(
            accountVerificationStatus,
            "verified"
        );

    }


    // -----------------------------------
    // BONUS STATUS
    // -----------------------------------

    if (welcomeBonusStatus) {

        welcomeBonusStatus.innerText =
            "⏳ Pending";

        setStatusClass(
            welcomeBonusStatus,
            ""
        );

    }


    console.log(
        "⏳ Welcome Bonus Pending"
    );

}


// =======================================
// CLAIMED UI
// =======================================

function showClaimedUI() {

    loading = false;
    accountVerified = true;
    bonusRequestStatus = "approved";


    // -----------------------------------
    // CLAIM BUTTON
    // -----------------------------------

    if (claimBonusBtn) {

        claimBonusBtn.disabled = true;

        claimBonusBtn.innerText =
            "✅ Bonus Already Claimed";

    }


// -----------------------------------
// READY BADGE
// -----------------------------------

if (bonusStatusBadge) {

    bonusStatusBadge.innerText =
        "🟢 Bonus Claimed";

    // শুধু এই Badge-এর লেখার রং সাদা
    setStatusClass(
        bonusStatusBadge,
        ""
    );

    bonusStatusBadge.style.color =
        "#ffffff";

}

    // -----------------------------------
    // ACCOUNT VERIFICATION
    // -----------------------------------

    if (accountVerificationStatus) {

        accountVerificationStatus.innerText =
            "✅ Verified";

        setStatusClass(
            accountVerificationStatus,
            "verified"
        );

    }


    // -----------------------------------
    // BONUS STATUS
    // -----------------------------------

   if (welcomeBonusStatus) {

    welcomeBonusStatus.innerText =
        "✅ Claimed";

    setStatusClass(
        welcomeBonusStatus,
        "welcome-bonus-claimed"
    );

}

    console.log(
        "✅ Welcome Bonus Already Claimed"
    );

}


// =======================================
// CHECK EXISTING BONUS REQUEST
// =======================================

async function checkBonusRequest(uid) {

    try {

        const requestQuery =
            query(

                collection(
                    db,
                    "welcomeBonusRequests"
                ),

                where(
                    "uid",
                    "==",
                    uid
                )

            );


        const snapshot =
            await getDocs(
                requestQuery
            );


        // -----------------------------------
        // NO REQUEST
        // -----------------------------------

        if (snapshot.empty) {

            bonusRequestStatus =
                null;

            return null;

        }


        let pendingFound =
            false;

        let approvedFound =
            false;


        snapshot.forEach(
            (docSnap) => {

                const data =
                    docSnap.data();


                const status =
                    String(
                        data.status || ""
                    )
                    .trim()
                    .toLowerCase();


                if (
                    status ===
                    "approved"
                ) {

                    approvedFound = true;

                }


                else if (
                    status ===
                    "pending"
                ) {

                    pendingFound = true;

                }

            }
        );


        // -----------------------------------
        // APPROVED HAS HIGHEST PRIORITY
        // -----------------------------------

        if (approvedFound) {

            bonusRequestStatus =
                "approved";

            return "approved";

        }


        // -----------------------------------
        // PENDING
        // -----------------------------------

        if (pendingFound) {

            bonusRequestStatus =
                "pending";

            return "pending";

        }


        // -----------------------------------
        // NO ACTIVE REQUEST
        // -----------------------------------

        bonusRequestStatus =
            null;

        return null;

    }

    catch (error) {

        console.error(
            "❌ Bonus Request Check Error:",
            error
        );

        bonusRequestStatus =
            null;

        return null;

    }

}


// =======================================
// APPLY FINAL BONUS STATE
// =======================================

async function applyBonusState(
    userData
) {

    currentUserData =
        userData;


    // ===================================
    // CHECK VERIFICATION
    // ===================================

    const verified =
        isVerified(
            userData
        );


    console.log(
        "🔐 Final Verification:",
        verified
    );


    // ===================================
    // NOT VERIFIED
    // ===================================

    if (!verified) {

        console.log(
            "🔒 Account is NOT verified"
        );


        // IMPORTANT:
        // No request check.
        // No unlock.
        // Directly LOCK.

        lockBonusUI();

        return;

    }


    // ===================================
    // VERIFIED
    // ===================================

    console.log(
        "✅ Account is verified"
    );


    accountVerified = true;


    // ===================================
    // CHECK BONUS REQUEST FIRST
    // ===================================
    // IMPORTANT:
    // আগে request check হবে।
    // তারপর মাত্র একটি final UI state
    // apply হবে।

    if (!currentUser) {

        unlockBonusUI();

        return;

    }


    const requestStatus =
        await checkBonusRequest(
            currentUser.uid
        );


    // ===================================
    // APPROVED
    // ===================================

    if (
        requestStatus ===
        "approved"
    ) {

        showClaimedUI();

        return;

    }


    // ===================================
    // PENDING
    // ===================================

    if (
        requestStatus ===
        "pending"
    ) {

        showPendingUI();

        return;

    }


    // ===================================
    // VERIFIED + NO REQUEST
    // ===================================

    unlockBonusUI();

}


// =======================================
// LOAD USER DATA
// OPTIMIZED
// =======================================

async function loadUserData() {

    if (!currentUser) {
        return;
    }

    try {

        // =================================
        // LOAD USER DOCUMENT
        // =================================

        const userRef =
            doc(
                db,
                "users",
                currentUser.uid
            );


        const userSnap =
            await getDoc(
                userRef
            );


        // =================================
        // USER NOT FOUND
        // =================================

        if (!userSnap.exists()) {

            console.error(
                "❌ User document not found."
            );

            lockBonusUI();

            return;

        }


        // =================================
        // USER DATA
        // =================================

        const userData =
            userSnap.data();


        currentUserData =
            userData;


        // =================================
        // QUICK VERIFICATION CHECK
        // =================================

        const verified =
            isVerified(
                userData
            );


        console.log(
            "👤 Welcome Bonus User:",
            currentUser.uid
        );


        console.log(
            "🔐 Verified:",
            verified
        );


        console.log(
            "📊 Verification Status:",
            userData.verificationStatus
        );


        // =================================
        // NOT VERIFIED
        // =================================

        if (!verified) {

            accountVerified =
                false;

            lockBonusUI();

            console.log(
                "🔒 Account is not verified."
            );

            return;

        }


        // =================================
        // VERIFIED
        // =================================

        accountVerified =
            true;


        // =================================
        // APPLY FINAL STATE
        // =================================

        await applyBonusState(
            userData
        );

    }

    catch (error) {

        console.error(
            "❌ Welcome Bonus Load Error:",
            error
        );


        // Error হলে Checking-এ আটকে থাকবে না

        lockBonusUI();

    }

}

// =======================================
// AUTH STATE
// =======================================

loadWelcomeBonusAmount();


onAuthStateChanged(

    auth,

    async (user) => {

        // =================================
        // NOT LOGGED IN
        // =================================

        if (!user) {

            currentUser =
                null;

            currentUserData =
                null;

            accountVerified =
                false;


            window.location.replace(
                LOGIN_PAGE
            );


            return;

        }


        // =================================
        // CURRENT USER
        // =================================

        currentUser =
            user;


// =================================
// INITIAL LOAD
// =================================

// IMPORTANT:
// এখানে showLoadingUI() চালানো হবে না।
// HTML-এর default Locked state আগে থেকেই থাকবে.
// Firestore থেকে verified status আসার পর
// applyBonusState() final UI সেট করবে.

await loadUserData();

        console.log(
            "✅ Welcome Bonus initialized"
        );

    }

);


// =======================================
// CLAIM WELCOME BONUS
// =======================================

claimBonusBtn?.addEventListener(

    "click",

    async () => {

        // =================================
        // LOGIN CHECK
        // =================================

        if (!currentUser) {

            await alert(
                "⚠️ Please login first."
            );

            return;

        }


        // =================================
        // VERIFIED CHECK
        // =================================

        if (!accountVerified) {

            await alert(
                "🔒 Welcome Bonus Claim করতে আগে Account Verify করুন।"
            );

            return;

        }


        // =================================
        // PREVENT DOUBLE CLICK
        // =================================

        claimBonusBtn.disabled =
            true;

        claimBonusBtn.innerText =
            "⏳ Checking...";


        try {

            // =================================
            // FRESH USER CHECK
            // =================================

            const userRef =
                doc(
                    db,
                    "users",
                    currentUser.uid
                );


            // User verification and existing bonus-request check are
            // independent reads, so start them together to reduce
            // submit-time network wait.
            const requestQuery =
                query(

                    collection(
                        db,
                        "welcomeBonusRequests"
                    ),

                    where(
                        "uid",
                        "==",
                        currentUser.uid
                    )

                );


            const [freshUserSnap, snapshot] =
                await Promise.all([
                    getDoc(userRef),
                    getDocs(requestQuery)
                ]);


            if (
                !freshUserSnap.exists()
            ) {

                throw new Error(
                    "USER_NOT_FOUND"
                );

            }


            const freshUser =
                freshUserSnap.data();


            currentUserData =
                freshUser;


            // =================================
            // FRESH VERIFICATION
            //
            // ONLY verified MATTERS
            // =================================

            const verified =
                isVerified(
                    freshUser
                );


            if (!verified) {

                lockBonusUI();


                await alert(
                    "🔒 আপনার Account এখনো Verify করা হয়নি।"
                );


                return;

            }


            accountVerified =
                true;


            // =================================
            // FIND EXISTING REQUEST
            // =================================

            let approvedRequest =
                null;

            let pendingRequest =
                null;


            snapshot.forEach(
                (docSnap) => {

                    const data =
                        docSnap.data();


                    const status =
                        String(
                            data.status || ""
                        )
                        .trim()
                        .toLowerCase();


                    if (
                        status ===
                        "approved"
                    ) {

                        approvedRequest =
                            docSnap;

                    }


                    else if (
                        status ===
                        "pending"
                    ) {

                        pendingRequest =
                            docSnap;

                    }

                }
            );


            // =================================
            // ALREADY APPROVED
            // =================================

            if (approvedRequest) {

                showClaimedUI();


                await alert(
                    "🎁 আপনি ইতিমধ্যে Welcome Bonus পেয়েছেন।"
                );


                return;

            }


            // =================================
            // ALREADY PENDING
            // =================================

            if (pendingRequest) {

                showPendingUI();


                await alert(
                    "⏳ আপনার Welcome Bonus request ইতিমধ্যে Pending আছে।"
                );


                return;

            }


            // =================================
            // CREATE REQUEST
            // =================================

            const requestData = {

                uid:
                    currentUser.uid,

                // IMPORTANT:
                // Use NetEarn custom User ID
                // instead of Firebase UID

                userId:
                    freshUser.userId ||
                    "NE00000",

                username:
                    freshUser.username ||
                    freshUser.name ||
                    currentUser.displayName ||
                    "User",

                email:
                    freshUser.email ||
                    currentUser.email ||
                    "",

                amount:
                    bonusAmount,

                rewardType:
                    "welcome_bonus",

                rewardName:
                    "Welcome Bonus",

                status:
                    "pending",

                approvedAmount:
                    0,

                createdAt:
                    serverTimestamp()

            };


            await addDoc(

                collection(
                    db,
                    "welcomeBonusRequests"
                ),

                requestData

            );


            // =================================
            // UPDATE UI
            // =================================

            showPendingUI();


            await alert(

                "🎉 Welcome Bonus request সফলভাবে পাঠানো হয়েছে!\n\n" +

                "Reward: ৳" +
                bonusAmount +
                "\n\n" +

                "Admin approval-এর পর আপনার Wallet-এ Bonus যোগ হবে।"

            );


        }

        catch (error) {

            console.error(
                "❌ Welcome Bonus Claim Error:",
                error
            );

// =================================
            // ERROR
            // =================================

            if (
                error.message ===
                "USER_NOT_FOUND"
            ) {

                await alert(
                    "⚠️ User data পাওয়া যায়নি।"
                );


                lockBonusUI();


                return;

            }


            // =================================
            // RESTORE CURRENT STATE
            // =================================

            if (accountVerified) {

                claimBonusBtn.disabled =
                    false;

                claimBonusBtn.innerText =
                    "🎁 Claim Welcome Bonus";

            }

            else {

                lockBonusUI();

            }


            await alert(
                "❌ Request পাঠানো যায়নি। আবার চেষ্টা করুন।"
            );

        }

    }

);


// =======================================
// PAGE VISIBILITY REFRESH
//
// User may verify account from another
// page/tab and return here.
// =======================================

document.addEventListener(
    "visibilitychange",
    async () => {

        if (
            document.visibilityState !==
            "visible"
        ) {

            return;

        }


        if (!currentUser) {

            return;

        }


        console.log(
            "🔄 Page visible — refreshing verification..."
        );


        await loadUserData();

    }
);


// =======================================
// PAGE FOCUS REFRESH
// =======================================

window.addEventListener(
    "focus",
    async () => {

        if (!currentUser) {

            return;

        }


        await loadUserData();

    }
);


// =======================================
// READY
// =======================================

console.log(
    "✅ NetEarn Pro Welcome Bonus FINAL Loaded"
);

console.log(
    "🔐 Unlock Rule: verified === true"
);

console.log(
    "🎁 Welcome Bonus Amount loaded dynamically"
);