"use strict";

const Panel = (() => {
  const PHASE_LABELS = {
    reveal: "كشف الأدوار",
    night: "الليل",
    dawn: "الفجر",
    day: "النهار",
    over: "انتهت اللعبة",
  };

  let confirmKey = null;
  let confirmTimer = null;
  let activeBtn = null;
  let activeText = "";

  const $ = (id) => document.getElementById(id);

  function fillChips(box, items) {
    box.innerHTML = "";
    if (items.length === 0) {
      const none = document.createElement("span");
      none.className = "alive-chip";
      none.textContent = "—";
      box.appendChild(none);
      return;
    }
    items.forEach((text) => {
      const chip = document.createElement("span");
      chip.className = "alive-chip";
      chip.textContent = text;
      box.appendChild(chip);
    });
  }

  function render() {
    const info = Game.getPanelInfo();
    if (!info) {
      $("panel-round").textContent = "لا توجد لعبة نشطة";
      fillChips($("panel-alive"), []);
      fillChips($("panel-dead"), []);
      $("panel-log").innerHTML = "";
      return;
    }
    $("panel-round").textContent = `الجولة ${info.round} — ${PHASE_LABELS[info.phase] || info.phase}`;
    fillChips($("panel-alive"), info.alive);
    fillChips(
      $("panel-dead"),
      info.dead.map((d) => {
        if (!d.roleId) return d.name;
        const role = Roles.get(d.roleId);
        return `${d.name} (${role.icon} ${role.name})`;
      })
    );
    const log = $("panel-log");
    log.innerHTML = "";
    if (info.log.length === 0) {
      const empty = document.createElement("div");
      empty.textContent = "لا أحداث بعد";
      log.appendChild(empty);
    }
    info.log.forEach((entry) => {
      const line = document.createElement("div");
      line.textContent = `• ${entry.text}`;
      log.appendChild(line);
    });
  }

  function resetConfirm() {
    clearTimeout(confirmTimer);
    if (activeBtn) activeBtn.textContent = activeText;
    confirmKey = null;
    activeBtn = null;
  }

  // زر بضغطتين للتأكيد
  function twoTap(key, btn, idleText, confirmText, action) {
    if (confirmKey === key) {
      resetConfirm();
      action();
      return;
    }
    resetConfirm();
    confirmKey = key;
    activeBtn = btn;
    activeText = idleText;
    btn.textContent = confirmText;
    confirmTimer = setTimeout(resetConfirm, 3000);
  }

  function open() {
    render();
    $("panel-overlay").hidden = false;
  }

  function close() {
    resetConfirm();
    $("panel-overlay").hidden = true;
  }

  function onPause() {
    close();
    DayUI.pauseTimer();
    $("pause-overlay").hidden = false;
  }

  function onResume() {
    $("pause-overlay").hidden = true;
    DayUI.resumeTimer();
  }

  function onEnd() {
    Game.forceEnd();
    close();
    DayUI.stopTimer();
    WinUI.show();
  }

  function onHome() {
    Game.abandonMatch();
    close();
    DayUI.stopTimer();
    document.body.classList.remove("is-night");
    UI.showScreen("home");
  }

  function init() {
    $("btn-panel").addEventListener("click", open);
    $("btn-panel-close").addEventListener("click", close);
    $("btn-panel-pause").addEventListener("click", onPause);
    $("btn-pause-resume").addEventListener("click", onResume);

    const endBtn = $("btn-panel-end");
    endBtn.addEventListener("click", () =>
      twoTap("end", endBtn, "🏁 إنهاء اللعبة", "⚠️ اضغط مرة أخرى للتأكيد", onEnd)
    );

    const homeBtn = $("btn-panel-home");
    homeBtn.addEventListener("click", () =>
      twoTap("home", homeBtn, "🏠 العودة إلى القائمة", "⚠️ سيُحفظ التقدم — اضغط للتأكيد", onHome)
    );
  }

  return { init };
})();