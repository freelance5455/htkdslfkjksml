/* naval-ui.js — Phase 9 interface: Navy screen (Fleets / Build / Queue / Overview), fleet panel, sea-zone panel,
   port information in province panels, sailing orders and amphibious "Sail" button for armies. */
(function (G) {
  'use strict';
  const $ = id => document.getElementById(id);
  const fmt = n => Math.round(n).toLocaleString('en-US');
  const pct = x => Math.round(x * 100) + '%';
  const me = () => G.state.player;
  const bar = (f, cls) => '<div class="bar ' + (cls || '') + '"><i style="width:' + Math.max(0, Math.min(100, f * 100)).toFixed(0) + '%"></i></div>';
  const cell = (l, v) => '<div class="cell"><span>' + l + '</span>' + v + '</div>';
  let tab = 'fleets', buildProv = null;

  function shipLine(f) {
    const c = {}; f.ships.forEach(s => { c[s.type] = (c[s.type] || 0) + 1; });
    return G.SHIP_ORDER.filter(t => c[t]).map(t => c[t] + ' ' + G.SHIPS[t].icon).join(' · ') || 'no ships';
  }
  function myPorts(needYard) {
    const st = G.state, pid = me();
    return G.provinces.filter(p => !p.sea && st.owners[p.id] === pid && p.seaZones && p.seaZones.length && (!needYard || (st.pb[p.id].dock && st.pb[p.id].port)));
  }

  /* =============== Navy modal =============== */
  G.showNavy = function (which, prov) {
    if (which) tab = which;
    if (prov != null) buildProv = prov;
    const st = G.state, pid = me(), c = st.countries[pid];
    const names = { fleets: 'Fleets (' + st.fleets.filter(f => f.owner === pid).length + ')', build: 'Build', queue: 'Queue (' + st.shipQ[pid].length + ')', overview: 'Overview' };
    let h = '<h3>⚓ Navy — ' + G.COUNTRIES[pid].name + '</h3>' +
      '<div class="eqline">💰 ' + fmt(c.treasury) + ' · ⚙️ ' + fmt(c.res.steel) + ' · 🛢️ ' + fmt(c.res.oil) + ' · ships ' + G.navalShips(pid) + ' · naval power ' + Math.round(G.navalPower(pid)) +
      (G.blockadeShare(pid) > 0.02 ? ' · <span style="color:#ff9a8a">blockaded ' + pct(G.blockadeShare(pid)) + '</span>' : '') + '</div>' +
      '<div class="tabs">' + Object.keys(names).map(t => '<button data-t="' + t + '" class="' + (tab === t ? 'on' : '') + '">' + names[t] + '</button>').join('') + '</div>';
    h += ({ fleets: fleetsTab, build: buildTab, queue: queueTab, overview: overviewTab })[tab](pid);
    h += '<div class="row"><button id="nv-close">Close</button></div>';
    $('modal-box').innerHTML = h; $('modal').classList.remove('hidden');
    const box = $('modal-box');
    $('nv-close').onclick = G.closeModal;
    box.querySelectorAll('.tabs button[data-t]').forEach(b => b.onclick = () => { tab = b.dataset.t; G.showNavy(); });
    const sel = $('nv-prov'); if (sel) sel.onchange = () => { buildProv = +sel.value; G.showNavy(); };
    box.querySelectorAll('button[data-b]').forEach(b => b.onclick = () => {
      const r = G.buildShip(pid, b.dataset.b, buildProv);
      G.toast(r.ok ? G.SHIPS[b.dataset.b].name + ' ordered (' + G.SHIPS[b.dataset.b].days + ' days)' : r.msg); G.updateTopBar(); G.showNavy();
    });
    box.querySelectorAll('button[data-c]').forEach(b => b.onclick = () => { G.cancelShip(pid, +b.dataset.c); G.toast('Cancelled — resources refunded'); G.updateTopBar(); G.showNavy(); });
    box.querySelectorAll('button[data-f]').forEach(b => b.onclick = () => {
      const f = G.fleetById(+b.dataset.f); if (!f) return;
      G.closeModal(); G.selFleet = f.id; G.selected = null; G.selZone = null; G.selArmy = null;
      const pos = G.nodePos(f.loc); G.focusPoint(pos.x, pos.y); G.showFleetPanel(); G.requestDraw();
    });
  };

  function fleetsTab(pid) {
    const list = G.state.fleets.filter(f => f.owner === pid);
    if (!list.length) return '<p class="dim">You have no fleets. Build ships in the Build tab (needs a Port and a Shipyard).</p>';
    return list.map(f => {
      const sm = G.fleetSummary(f);
      return '<div class="slot"><div class="info"><b>' + f.name + '</b> <small>' + shipLine(f) + ' · hull ' + pct(sm.hp) + '</small><br><small>' + G.fleetLocName(f) +
        (f.path.length ? ' → ' + G.nodeName(f.path[f.path.length - 1]) + ' (ETA ' + G.fleetEta(f) + 'd)' : '') + (f.cargo.length ? ' · carrying ' + sm.cargoUnits + ' units' : '') + (G.fleetInBattle(f) ? ' · ⚔ in battle' : '') + '</small></div><button data-f="' + f.id + '">Select</button></div>';
    }).join('');
  }
  function buildTab(pid) {
    const ports = myPorts(false);
    if (!ports.length) return '<p class="dim">Your nation has no coastline, so it cannot build a navy.</p>';
    const yards = myPorts(true);
    if (!yards.length) return '<div class="alert">No port with a Shipyard. Open 🏭 Industry → select a coastal province → build a ⚓ Shipyard (and a Port).</div>';
    if (buildProv == null || !yards.some(p => p.id === buildProv)) buildProv = (G.selected != null && yards.some(p => p.id === G.selected)) ? G.selected : yards[0].id;
    const st = G.state;
    let h = '<div style="margin:6px 0">Build in: <select id="nv-prov">' + yards.map(p => '<option value="' + p.id + '"' + (p.id === buildProv ? ' selected' : '') + '>' + p.name + ' (yards ' + st.pb[p.id].dock + ', port ' + st.pb[p.id].port + ')' + (G.blockadeLevel(p.id) > 0.05 ? ' — blockaded' : '') + '</option>').join('') + '</select></div>';
    h += '<div class="ucards">' + G.SHIP_ORDER.map(k => {
      const d = G.SHIPS[k], chk = G.canBuildShip(pid, k, buildProv);
      return '<div class="ucard"><div class="uh"><span class="utag">' + d.icon + '</span><b>' + d.name + '</b></div><small>' + d.desc + '</small>' +
        '<div class="ucost">💰 ' + d.gold + ' · ⚙️ ' + d.steel + ' · 🛢️ ' + d.oil + ' · ⏱ ' + d.days + 'd</div>' +
        '<div class="ustats">ATK ' + d.atk + ' · DEF ' + d.def + ' · SPD ' + d.speed + (d.cargo ? ' · carries ' + d.cargo : '') + '</div>' +
        '<button class="' + (chk.ok ? 'primary' : '') + '" data-b="' + k + '"' + (chk.ok ? '' : ' disabled') + '>' + (chk.ok ? 'Build' : chk.msg) + '</button></div>';
    }).join('') + '</div><p class="dim" style="font-size:12px">Each Shipyard builds one ship at a time in its province; extra Ports speed it up. Ships cost 1% of their price per day in upkeep.</p>';
    return h;
  }
  function queueTab(pid) {
    const q = G.state.shipQ[pid];
    if (!q.length) return '<p class="dim">No ships under construction.</p>';
    return q.map(it => {
      const d = G.SHIPS[it.type];
      return '<div class="slot"><span class="utag">' + d.icon + '</span><div class="info"><b>' + d.name + '</b> <small>at ' + G.provinces[it.prov].name + ' · ' + Math.ceil(it.left) + ' days left' + (G.blockadeLevel(it.prov) > 0.6 ? ' · BLOCKADED' : '') + '</small>' +
        bar(1 - it.left / it.total, 'b') + '</div><button class="danger" data-c="' + it.id + '">Cancel</button></div>';
    }).join('');
  }
  function overviewTab(pid) {
    const st = G.state;
    const rows = Object.keys(st.countries).filter(id => !st.countries[id].dead && G.navalShips(id) > 0).map(id => ({ id: id, p: G.navalPower(id), n: G.navalShips(id) })).sort((a, b) => b.p - a.p).slice(0, 12);
    let h = '<div class="rtable"><div class="rh" style="grid-template-columns:2fr 1fr 1fr"><span>Nation</span><span>Ships</span><span>Power</span></div>' +
      rows.map(r => '<div class="rw" style="grid-template-columns:2fr 1fr 1fr"><span>' + (r.id === pid ? '★ ' : '') + G.COUNTRIES[r.id].name + '</span><span>' + (r.id === pid ? r.n : G.intelVal(r.id, r.n)) + '</span><span>' + (r.id === pid ? Math.round(r.p) : G.intelVal(r.id, r.p)) + '</span></div>').join('') + '</div>';
    const bl = G.provinces.filter(p => !p.sea && G.blockadeLevel(p.id) > 0.05).sort((a, b) => G.blockadeLevel(b.id) - G.blockadeLevel(a.id)).slice(0, 14);
    h += '<h3>Blockades</h3>' + (bl.length ? bl.map(p => {
      const o = st.owners[p.id], mineB = o === pid;
      return '<div class="slot"><img class="mini" src="' + G.flagURL(o) + '"><div class="info"><b>' + p.name + '</b> <small>' + G.COUNTRIES[o].name + ' · ' + pct(G.blockadeLevel(p.id)) + ' blockaded' + (mineB ? ' — income and trade suffer' : '') + '</small></div></div>';
    }).join('') : '<p class="dim">No port is blockaded. Park warships in the sea zone next to an enemy port to cut its income and trade.</p>');
    return h;
  }

  /* =============== fleet panel =============== */
  G.showFleetPanel = function () { $('panel').classList.remove('hidden'); G.renderFleetPanel(); };
  G.renderFleetPanel = function () {
    const f = G.fleetById(G.selFleet);
    if (!f) { $('panel').classList.add('hidden'); G.selFleet = null; G.fleetMoveMode = false; return; }
    const st = G.state, mine = f.owner === me(), sm = G.fleetSummary(f);
    let status = 'Idle';
    if (G.fleetInBattle(f)) status = '⚔ IN BATTLE';
    else if (f.path.length) status = 'Sailing to ' + G.nodeName(f.path[f.path.length - 1]) + ' — ETA ' + G.fleetEta(f) + 'd' + (f.mission && f.mission.type === 'land' ? ' (landing)' : '');
    else if (typeof f.loc === 'number') status = 'Docked' + (sm.hp < 1 ? ' — repairing' : '');
    let h = '<div class="ph"><img src="' + G.flagURL(f.owner) + '"><div><h2>' + f.name + '</h2><div class="sub">' + G.COUNTRIES[f.owner].name + ' · ' + G.fleetLocName(f) + (mine ? ' (you)' : '') + '</div></div><button class="x" id="p-close">✕</button></div>';
    h += '<div class="grid">' + cell('Ships', sm.n + ' · ' + shipLine(f)) + cell('Hull', pct(sm.hp) + bar(sm.hp, 'g')) + cell('Firepower', sm.fire.toFixed(1)) + cell('Speed', Math.round(sm.speed * G.navalSpeedMult()) + ' u/day') +
      cell('Transport', sm.cap ? sm.cargoUnits + ' / ' + sm.cap + ' units' : '—') + cell('Status', status) + '</div>';
    h += '<div class="units">' + f.ships.map((s, i) => {
      const d = G.SHIPS[s.type];
      return '<div class="urow"><span class="utag">' + d.icon + '</span><div class="uinfo"><b>' + d.name + '</b><div class="ubars">' + bar(s.hp, 'g') + '</div><small>hull ' + pct(s.hp) + '</small></div>' +
        (mine && f.ships.length > 1 && !f.path.length ? '<button class="mini" data-d="' + i + '">Detach</button>' : '') + '</div>';
    }).join('') + '</div>';
    if (f.cargo.length) h += '<div class="eqline" style="margin-top:6px">On board: ' + f.cargo.map(a => a.name + ' (' + a.units.length + ')').join(', ') + '</div>';
    if (mine) {
      const here = st.fleets.filter(o => o !== f && o.owner === f.owner && o.loc === f.loc && !o.path.length && !f.path.length && !o.cargo.length && !f.cargo.length);
      const docked = typeof f.loc === 'number';
      const loadable = docked && sm.free > 0 ? st.armies.filter(a => a.owner === f.owner && a.prov === f.loc && !a.path.length && !G.inBattle(a) && a.units.length <= sm.free) : [];
      h += '<div class="chips">' +
        '<button class="primary" id="f-sail">' + (G.fleetMoveMode ? 'Cancel' : '➜ Sail') + '</button>' +
        (f.path.length ? '<button id="f-stop">⏹ Stop</button>' : '') +
        (here.length ? '<button id="f-merge">⛓ Merge (' + here.length + ')</button>' : '') +
        (loadable.length ? '<button id="f-load">⬇ Load armies (' + loadable.length + ')</button>' : '') +
        (docked && f.cargo.length && G.canDock(f.owner, f.loc) ? '<button id="f-unload">⬆ Unload</button>' : '') +
        '<button id="f-home">⚓ Nearest port</button>' +
        (docked && G.canDock(f.owner, f.loc) ? '<button id="f-disb" class="danger">Disband</button>' : '') + '</div>';
      if (f.cargo.length && typeof f.loc === 'string') {
        const coast = G.zoneById[f.loc].ports.filter(p => G.landingCheck(f.owner, p).ok);
        h += '<div class="chips"><span style="font-size:12px;color:var(--dim);align-self:center">Land at:</span>' + (coast.length ? coast.map(p => '<span class="chip" data-land="' + p + '">' + (G.landingCheck(f.owner, p).invade ? '⚔ ' : '') + G.provinces[p].name + '</span>').join('') : '<span class="dim">no valid coast here</span>') + '</div>';
      }
    }
    $('panel-body').innerHTML = h;
    $('p-close').onclick = () => { G.selFleet = null; G.fleetMoveMode = false; G.requestDraw(); $('panel').classList.add('hidden'); };
    if (!mine) return;
    const on = (id, fn) => { const b = $(id); if (b) b.onclick = fn; };
    on('f-sail', () => { G.fleetMoveMode = !G.fleetMoveMode; G.requestDraw(); G.renderFleetPanel(); if (G.fleetMoveMode) G.toast('Tap a sea zone or one of your ports'); });
    on('f-stop', () => { G.stopFleet(f); G.toast('Fleet halted'); G.renderFleetPanel(); G.requestDraw(); });
    on('f-merge', () => { let n = 0; here.forEach(o => { if (f.ships.length + o.ships.length <= G.FLEET_MAX_SHIPS) { f.ships = f.ships.concat(o.ships); G.removeFleet(o); n++; } }); G.toast(n ? 'Merged ' + n + ' fleets' : 'Fleet would exceed ' + G.FLEET_MAX_SHIPS + ' ships'); G.renderFleetPanel(); G.requestDraw(); });
    on('f-load', () => { let n = 0; st.armies.filter(a => a.owner === f.owner && a.prov === f.loc && !a.path.length).forEach(a => { if (G.loadArmy(f, a).ok) n++; }); G.toast(n ? n + ' army aboard' : 'Nothing fits'); G.renderFleetPanel(); G.requestDraw(); });
    on('f-unload', () => { const r = G.unloadAll(f); G.toast(r.ok ? 'Armies unloaded' : r.msg); G.renderFleetPanel(); G.requestDraw(); });
    on('f-home', () => { const ok = G.returnHome(f); G.toast(ok ? 'Heading for the nearest port' : 'No port in reach'); G.renderFleetPanel(); G.requestDraw(); });
    on('f-disb', () => G.confirmBox('Disband ' + f.name + '? Ships are scrapped (no refund).', 'Disband', () => { G.removeFleet(f); G.selFleet = null; $('panel').classList.add('hidden'); G.requestDraw(); }));
    document.querySelectorAll('#panel-body button[data-d]').forEach(b => b.onclick = () => {
      const s = f.ships.splice(+b.dataset.d, 1)[0], n = G.createFleet(f.owner, f.loc, [s]);
      G.selFleet = n.id; G.toast('Detached into ' + n.name); G.renderFleetPanel(); G.requestDraw();
    });
    document.querySelectorAll('#panel-body .chip[data-land]').forEach(ch => ch.onclick = () => {
      const r = G.landFleet(f, +ch.dataset.land); G.toast(r.ok ? 'Landing at ' + G.provinces[+ch.dataset.land].name : r.msg); G.renderFleetPanel(); G.requestDraw();
    });
  };
  G.onFleetSelect = function () { G.fleetMoveMode = false; G.showFleetPanel(); };
  G.onFleetTarget = function (pid) {
    const f = G.fleetById(G.selFleet); G.fleetMoveMode = false;
    if (f && pid != null) {
      const p = G.provinces[pid];
      const dest = p.sea ? p.zone : pid;
      const r = G.orderSail(f, dest);
      G.toast(r.ok ? 'Sailing to ' + G.nodeName(dest) + ' — ETA ' + r.eta + ' days' + (G.state.paused ? ' (press ▶)' : '') : r.msg);
    }
    G.renderFleetPanel(); G.requestDraw();
  };
  G.focusPoint = function (x, y) {
    const v = G.view, cv = $('map'); v.z = Math.max(v.z, 1.2 / ((G.AVGCELL || 100) / 100));
    v.x = x - cv.clientWidth / v.z / 2; v.y = y - cv.clientHeight / v.z / 2; G.requestDraw();
    G.ensureVisible && G.fitClamp && G.fitClamp();
  };

  /* =============== sea-zone panel =============== */
  G.onZoneSelect = function (zid) { $('panel').classList.remove('hidden'); G.renderZonePanel(); };
  G.renderZonePanel = function () {
    const z = G.zoneById[G.selZone]; if (!z) { $('panel').classList.add('hidden'); return; }
    const st = G.state;
    const here = G.stationary(z.id).filter(f => G.canSeeFleet(f));
    const dom = G.zoneDominant(z.id);
    let h = '<div class="ph"><div style="font-size:30px">🌊</div><div><h2>' + z.name + '</h2><div class="sub">Sea zone · ' + z.cells.length + ' cells · ' + z.ports.length + ' ports</div></div><button class="x" id="p-close">✕</button></div>';
    h += '<div class="grid">' + cell('Naval control', dom ? G.COUNTRIES[dom].name : 'Contested / none') + cell('Fleets seen', here.length) + cell('Adjacent zones', z.adj.length) + '</div>';
    if (here.length) h += '<div class="chips"><span style="font-size:12px;color:var(--dim);align-self:center">Fleets here:</span>' + here.map(f => '<span class="chip" data-fleet="' + f.id + '">' + G.COUNTRIES[f.owner].adj + ' ' + f.name + ' (' + f.ships.length + ')</span>').join('') + '</div>';
    h += '<div class="chips"><span style="font-size:12px;color:var(--dim);align-self:center">Ports:</span>' + z.ports.slice(0, 24).map(p => '<span class="chip" data-p="' + p + '">' + G.provinces[p].name + (G.blockadeLevel(p) > 0.05 ? ' ⛔' : '') + '</span>').join('') + '</div>';
    h += '<div class="chips"><span style="font-size:12px;color:var(--dim);align-self:center">Neighbouring seas:</span>' + z.adj.map(n => '<span class="chip" data-z="' + n + '">' + G.zoneById[n].name + '</span>').join('') + '</div>';
    $('panel-body').innerHTML = h;
    $('p-close').onclick = () => { G.selZone = null; G.requestDraw(); $('panel').classList.add('hidden'); };
    document.querySelectorAll('#panel-body .chip[data-fleet]').forEach(ch => ch.onclick = () => { G.selFleet = +ch.dataset.fleet; G.selZone = null; G.showFleetPanel(); G.requestDraw(); });
    document.querySelectorAll('#panel-body .chip[data-p]').forEach(ch => ch.onclick = () => { G.selZone = null; G.selected = +ch.dataset.p; G.focusProvince(G.selected); G.onSelect(G.selected); G.requestDraw(); });
    document.querySelectorAll('#panel-body .chip[data-z]').forEach(ch => ch.onclick = () => { G.selZone = ch.dataset.z; const q = G.nodePos(G.selZone); G.focusPoint(q.x, q.y); G.renderZonePanel(); G.requestDraw(); });
  };

  /* =============== province panel: port block =============== */
  G.provincePortHtml = function (id) {
    const st = G.state, p = G.provinces[id];
    if (!p.seaZones || !p.seaZones.length) return '';
    const o = st.owners[id], pb = st.pb[id], bl = G.blockadeLevel(id);
    const docked = G.fleetsDockedAt(id).filter(f => G.canSeeFleet(f));
    let h = '<div class="eqline">⚓ Port · level ' + (pb ? pb.port : 0) + ' · shipyards ' + (pb ? pb.dock : 0) + (bl > 0.05 ? ' · <span style="color:#ff9a8a">BLOCKADED ' + pct(bl) + '</span>' : '') + ' · seas: ' + p.seaZones.map(z => G.zoneById[z].name).join(', ') + '</div>';
    if (docked.length) h += '<div class="chips"><span style="font-size:12px;color:var(--dim);align-self:center">Fleets in port:</span>' + docked.map(f => '<span class="chip" data-fleet="' + f.id + '">' + G.COUNTRIES[f.owner].adj + ' ' + f.name + ' (' + f.ships.length + ')</span>').join('') + '</div>';
    if (o === st.player && pb && pb.dock && pb.port) h += '<div class="chips"><button id="pv-ships" class="primary">⚓ Build ships here</button></div>';
    return h;
  };
  G.bindProvincePort = function (id) {
    const b = $('pv-ships'); if (b) b.onclick = () => G.showNavy('build', id);
    document.querySelectorAll('#panel-body .chip[data-fleet]').forEach(ch => ch.onclick = () => { G.selFleet = +ch.dataset.fleet; G.selected = null; G.showFleetPanel(); G.requestDraw(); });
  };

  /* =============== armies: sail =============== */
  G.armySailHtml = function (a) {
    const P = G.provinces[a.prov];
    if (!P.seaZones || !P.seaZones.length || !G.canDock(a.owner, a.prov)) return '';
    return '<button id="a-sail">⛴ Sail</button>';
  };
  G.bindArmySail = function (a, rerender) {
    const b = $('a-sail'); if (!b) return;
    b.onclick = () => {
      G.sailMode = !G.sailMode; G.moveMode = G.sailMode; G.requestDraw(); rerender();
      if (G.sailMode) G.toast('Tap a coastal destination (needs a docked transport fleet here)');
    };
  };

  /* ---------- notifications ---------- */
  G.onNavalBattleEnd = function (zone, winner, loser, rep) {
    G.toast(rep); if (!G.state.paused) { G.setPaused(true); G.updateTopBar(); }
  };
  G.onFleetArrive = function (f) { if (!f.path.length) G.toast(f.name + ' arrived at ' + G.fleetLocName(f)); };
  G.onShipBuilt = function (f, it) { G.toast(G.SHIPS[it.type].name + ' commissioned at ' + G.provinces[it.prov].name); };
  G.onLanding = function (f, prov, invade) { if (f.owner === me()) G.toast((invade ? 'Amphibious assault at ' : 'Landed at ') + G.provinces[prov].name); };

  G.bindNavalUI = function () { $('btn-navy').onclick = () => { tab = 'fleets'; G.showNavy(); }; };
})(window.EMP = window.EMP || {});
