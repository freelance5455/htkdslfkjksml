// LABORATORIO · galería 3D donde cada personaje guardado vive en una cápsula de cristal azul claro.
// Se abre desde el hub como una superposición. Arrastra a los lados para pasar de una cápsula a otra; al soltar, la cámara se
// acerca a la más cercana, carga el personaje en 3D (los demás se ven con su miniatura) y se puede elegir como personaje activo.
// Solo hay un personaje en 3D a la vez, así que funciona con muchos modelos pesados sin llenar la memoria.
import { h, icon } from '../ui/dom.js';
import { toast } from '../ui/toast.js';
import { loadThree } from '../core/threeLoader.js';
import { loadPreviewFor } from '../import/importer.js';
import { buildPreviewGroup } from '../import/previewScene.js';
import { fmtCount } from '../core/format.js';

export const LAB = Object.freeze({ GAP: 3.4, MAX: 60, HEIGHT: 1.9, FLOOR: 0.3, FAR_Z: 7.6, NEAR_Z: 5.6, SETTLE_S: 0.45 });

// Índice de la cápsula más cercana a la posición x de la cámara (acotado a [0, n−1]).
export const nearestCapsule = (x, n) => Math.max(0, Math.min(Math.max(0, n - 1), Math.round(x / LAB.GAP)));
// Posición x de la cámara tras soltar el dedo: la inercia empuja un poco y se ajusta a una cápsula.
export const snapTarget = (x, vel, n) => nearestCapsule(x + vel * 0.18, n) * LAB.GAP;
// Factor de escala para que un personaje de tamaño (x, y, z) quepa en la cápsula (alto 1,9 m, ancho 1,5 m).
export function fitScale(size) {
  const hs = LAB.HEIGHT / Math.max(size.y, 1e-6);
  const ws = 1.5 / Math.max(size.x, size.z, 1e-6);
  return Math.min(hs, ws);
}

export function openLab({ store, layers, profile, models, activeId = null, onActiveChange = null, onDetail = null, root = document.getElementById('app'), onClose = null }) {
  const list = models.slice(0, LAB.MAX);
  const n = list.length;
  let active = activeId;
  let closed = false;
  let THREE = null;
  let focus = Math.max(0, list.findIndex((m) => m.id === activeId));
  let dismissMain = null;

  // ── Interfaz ─────────────────────────────────────────────────────────────────────────────────
  const canvas = h('canvas', { class: 'lab__canvas', role: 'img', 'aria-label': 'Laboratorio de cápsulas con tus personajes' });
  const backBtn = h('button', { class: 'zoo__back', type: 'button', onclick: () => dismissMain?.() }, '‹ Regresar');
  const sub = h('small', null, n ? `${n} ${n === 1 ? 'personaje' : 'personajes'}${models.length > n ? ` (los ${n} más recientes)` : ''}` : 'Sin personajes');
  const head = h('header', { class: 'lab__head' }, backBtn, h('div', { class: 'zoo__title' }, 'Laboratorio', sub));
  const nameEl = h('strong', { class: 'lab__name' });
  const metaEl = h('span', { class: 'lab__meta mono' });
  const statusEl = h('span', { class: 'lab__status' });
  const prevBtn = h('button', { class: 'icon-btn lab__nav', type: 'button', 'aria-label': 'Cápsula anterior', onclick: () => go(-1) }, icon('back'));
  const nextBtn = h('button', { class: 'icon-btn lab__nav lab__nav--next', type: 'button', 'aria-label': 'Cápsula siguiente', onclick: () => go(1) }, icon('back'));
  const useBtn = h('button', { class: 'btn btn--primary', type: 'button', onclick: () => choose() });
  const detailBtn = h('button', { class: 'btn btn--ghost', type: 'button', onclick: () => list[focus] && onDetail?.(list[focus].id) }, 'Detalle');
  if (!onDetail) detailBtn.hidden = true;
  const hud = h('div', { class: 'lab__hud', hidden: !n }, h('div', { class: 'lab__info' }, nameEl, metaEl, statusEl), h('div', { class: 'lab__acts' }, useBtn, detailBtn));
  const empty = h('p', { class: 'lab__empty', hidden: n > 0 }, 'El laboratorio está vacío. Importa un personaje en el hub y aparecerá aquí en su cápsula.');
  const el = h('section', { class: 'lab', 'aria-label': 'Laboratorio de cápsulas' }, canvas, head, prevBtn, nextBtn, hud, empty);
  prevBtn.hidden = nextBtn.hidden = n < 2;
  root.append(el);
  requestAnimationFrame(() => el.classList.add('is-open'));

  function paintHud() {
    const m = list[focus];
    if (!m) return;
    nameEl.textContent = m.name;
    metaEl.textContent = [`${fmtCount(m.stats?.triangles || 0)} tri`, m.rig ? 'con esqueleto' : 'sin esqueleto'].join(' · ');
    const isActive = m.id === active;
    useBtn.replaceChildren(isActive ? icon('check', 18) : icon('person', 18), isActive ? 'Personaje activo' : 'Usar este personaje');
    useBtn.disabled = isActive;
    prevBtn.disabled = focus === 0;
    nextBtn.disabled = focus === n - 1;
  }

  async function choose() {
    const m = list[focus];
    if (!m || m.id === active) return;
    active = m.id;
    paintHud();
    paintActive();
    try {
      await onActiveChange?.(m.id);
      toast(`«${m.name}» es ahora el personaje activo.`, { kind: 'ok' });
    } catch (err) {
      console.warn('[lab] no se pudo elegir', err);
    }
  }

  // ── Escena (se crea cuando Three.js está cargado) ──────────────────────────────────────────────
  let renderer = null, scene = null, camera = null;
  const caps = []; // { x, group, ring, plate: { tex, ctx, canvas }, thumb: Sprite|null, thumbState }
  let holder = null, built = null, loadedIndex = -1, loadToken = 0;
  let camX = focus * LAB.GAP, targetX = camX, vel = 0, zoom = 0, settledFor = 0, dragging = false;
  let raf = 0, last = 0, ro = null;
  const disposables = [];
  const track = (o) => (disposables.push(o), o);
  const ringMats = {};
  let bubbles = null;

  const tex = (canvas2d, { repeat = null, srgb = true } = {}) => {
    const t = track(new THREE.CanvasTexture(canvas2d));
    if (srgb) t.colorSpace = THREE.SRGBColorSpace;
    if (repeat) {
      t.wrapS = t.wrapT = THREE.RepeatWrapping;
      t.repeat.set(repeat[0], repeat[1]);
    }
    t.anisotropy = 4;
    return t;
  };
  const paint2d = (w, ht, fn) => {
    const c = document.createElement('canvas');
    c.width = w;
    c.height = ht;
    fn(c.getContext('2d'), w, ht);
    return c;
  };

  function buildScene() {
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x061219);
    scene.fog = new THREE.Fog(0x061219, 9, 30);
    camera = new THREE.PerspectiveCamera(48, 1, 0.1, 80);
    renderer = new THREE.WebGLRenderer({ canvas, antialias: profile?.tier !== 'low', powerPreference: 'high-performance' });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, profile?.tier === 'low' ? 1.25 : 1.75));

    scene.add(track(new THREE.HemisphereLight(0xcdeeff, 0x0b1822, 1.05)));
    const key = new THREE.DirectionalLight(0xffffff, 1.5);
    key.position.set(2, 5, 6);
    scene.add(key);
    const rim = new THREE.DirectionalLight(0x6fd0ff, 0.9);
    rim.position.set(-3, 3, -5);
    scene.add(rim);

    const W = LAB.GAP * Math.max(n, 3) + 60;
    const cx = ((n - 1) * LAB.GAP) / 2;
    // Suelo de baldosas
    const floorTex = tex(paint2d(256, 256, (g, w, ht) => {
      g.fillStyle = '#243746'; g.fillRect(0, 0, w, ht);
      g.fillStyle = '#2c4252'; g.fillRect(6, 6, w - 12, ht - 12);
      g.strokeStyle = 'rgba(160,220,255,.16)'; g.lineWidth = 2; g.strokeRect(3, 3, w - 6, ht - 6);
    }), { repeat: [W / 2, 8] });
    const floor = new THREE.Mesh(track(new THREE.PlaneGeometry(W, 16)), track(new THREE.MeshStandardMaterial({ map: floorTex, roughness: 0.5, metalness: 0.25 })));
    floor.rotation.x = -Math.PI / 2;
    floor.position.set(cx, 0, 2.5);
    scene.add(floor);
    // Pared del fondo con paneles (una junta entre cápsulas) y franja de luz
    const wallTex = tex(paint2d(256, 256, (g, w, ht) => {
      const gr = g.createLinearGradient(0, 0, 0, ht); gr.addColorStop(0, '#16303f'); gr.addColorStop(1, '#0d1f2b');
      g.fillStyle = gr; g.fillRect(0, 0, w, ht);
      g.strokeStyle = 'rgba(140,215,255,.28)'; g.lineWidth = 3; g.strokeRect(0, 0, w, ht);
      g.fillStyle = 'rgba(140,215,255,.07)'; g.fillRect(16, 16, w - 32, ht - 32);
    }), { repeat: [W / LAB.GAP, 1] });
    wallTex.offset.set(0.5 - (cx / LAB.GAP) % 1, 0);
    const wall = new THREE.Mesh(track(new THREE.PlaneGeometry(W, 6)), track(new THREE.MeshStandardMaterial({ map: wallTex, roughness: 0.8, metalness: 0.1 })));
    wall.position.set(cx, 3, -3.4);
    scene.add(wall);
    const stripMat = track(new THREE.MeshBasicMaterial({ color: 0xa9ecff }));
    const strip = new THREE.Mesh(track(new THREE.BoxGeometry(W, 0.07, 0.07)), stripMat);
    strip.position.set(cx, 4.1, -3.3);
    scene.add(strip);
    const ceiling = new THREE.Mesh(track(new THREE.PlaneGeometry(W, 16)), track(new THREE.MeshStandardMaterial({ color: 0x0b1822, roughness: 0.9 })));
    ceiling.rotation.x = Math.PI / 2;
    ceiling.position.set(cx, 5.2, 2.5);
    scene.add(ceiling);

    // Piezas compartidas por todas las cápsulas
    const baseGeo = track(new THREE.CylinderGeometry(1.02, 1.12, 0.3, 40));
    const baseMat = track(new THREE.MeshStandardMaterial({ color: 0x1a2a37, metalness: 0.85, roughness: 0.32 }));
    const ringGeo = track(new THREE.TorusGeometry(0.9, 0.04, 8, 48));
    ringMats.idle = track(new THREE.MeshBasicMaterial({ color: 0x7fe3ff }));
    ringMats.active = track(new THREE.MeshBasicMaterial({ color: 0x8dffb8 }));
    const glassMat = track(new THREE.MeshStandardMaterial({ color: 0xa8e6ff, emissive: 0x2a6f9a, emissiveIntensity: 0.4, roughness: 0.05, metalness: 0, transparent: true, opacity: 0.2, side: THREE.DoubleSide, depthWrite: false }));
    const tubeGeo = track(new THREE.CylinderGeometry(0.94, 0.94, 2.35, 40, 1, true));
    const domeGeo = track(new THREE.SphereGeometry(0.94, 40, 14, 0, Math.PI * 2, 0, Math.PI / 2));
    const beamMat = track(new THREE.MeshBasicMaterial({ color: 0x66ccff, transparent: true, opacity: 0.07, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide }));
    const beamGeo = track(new THREE.CylinderGeometry(0.55, 0.92, 3, 28, 1, true));
    const capGeo = track(new THREE.TorusGeometry(0.94, 0.05, 8, 48));
    const plateGeo = track(new THREE.PlaneGeometry(1.8, 0.45));

    list.forEach((m, i) => {
      const g = new THREE.Group();
      g.position.set(i * LAB.GAP, 0, 0);
      const base = new THREE.Mesh(baseGeo, baseMat); base.position.y = 0.15; g.add(base);
      const ring = new THREE.Mesh(ringGeo, m.id === active ? ringMats.active : ringMats.idle); ring.rotation.x = Math.PI / 2; ring.position.y = 0.31; g.add(ring);
      const tube = new THREE.Mesh(tubeGeo, glassMat); tube.position.y = 0.3 + 1.175; tube.userData.index = i; g.add(tube);
      const dome = new THREE.Mesh(domeGeo, glassMat); dome.position.y = 0.3 + 2.35; dome.userData.index = i; g.add(dome);
      const cap = new THREE.Mesh(capGeo, baseMat); cap.rotation.x = Math.PI / 2; cap.position.y = 0.3 + 2.35; g.add(cap);
      const beam = new THREE.Mesh(beamGeo, beamMat); beam.position.y = 0.3 + 1.5; g.add(beam);
      // Placa con el nombre
      const pc = document.createElement('canvas'); pc.width = 512; pc.height = 128;
      const ptex = tex(pc);
      const plate = new THREE.Mesh(plateGeo, track(new THREE.MeshBasicMaterial({ map: ptex, transparent: true, depthWrite: false })));
      plate.position.set(0, 0.16, 1.14); plate.rotation.x = -0.18; g.add(plate);
      scene.add(g);
      caps.push({ x: i * LAB.GAP, group: g, ring, plate: { tex: ptex, canvas: pc }, thumb: null, thumbState: 0 });
      drawPlate(i);
    });

    // Burbujas que suben en la cápsula enfocada
    const N = 26, pos = new Float32Array(N * 3), seed = new Float32Array(N);
    for (let i = 0; i < N; i++) { seed[i] = Math.random(); pos[i * 3] = (Math.random() - 0.5) * 1.4; pos[i * 3 + 1] = 0.4 + Math.random() * 2.2; pos[i * 3 + 2] = (Math.random() - 0.5) * 1.4; }
    const bg = track(new THREE.BufferGeometry());
    bg.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    bubbles = new THREE.Points(bg, track(new THREE.PointsMaterial({ color: 0xcdf3ff, size: 0.05, transparent: true, opacity: 0.55, depthWrite: false })));
    bubbles.userData.seed = seed;
    bubbles.frustumCulled = false;
    scene.add(bubbles);
  }

  function drawPlate(i) {
    const c = caps[i], m = list[i];
    if (!c) return;
    const g = c.plate.canvas.getContext('2d');
    g.clearRect(0, 0, 512, 128);
    g.fillStyle = 'rgba(6,18,26,.82)';
    g.beginPath(); g.roundRect(4, 8, 504, 112, 22); g.fill();
    g.strokeStyle = m.id === active ? 'rgba(141,255,184,.9)' : 'rgba(127,227,255,.6)'; g.lineWidth = 3; g.stroke();
    g.fillStyle = '#eaf6ff'; g.font = '600 40px system-ui, sans-serif'; g.textBaseline = 'middle';
    let name = m.name;
    while (name.length > 3 && g.measureText(name).width > (m.id === active ? 330 : 470)) name = name.slice(0, -2);
    if (name !== m.name) name = `${name.trimEnd()}…`;
    g.fillText(name, 22, 64);
    if (m.id === active) {
      g.fillStyle = '#8dffb8'; g.beginPath(); g.roundRect(368, 34, 126, 60, 14); g.fill();
      g.fillStyle = '#06241a'; g.font = '700 30px system-ui, sans-serif'; g.textAlign = 'center'; g.fillText('ACTIVO', 431, 66); g.textAlign = 'left';
    }
    c.plate.tex.needsUpdate = true;
  }
  function paintActive() {
    list.forEach((m, i) => { if (caps[i]) { caps[i].ring.material = m.id === active ? ringMats.active : ringMats.idle; drawPlate(i); } });
  }

  // Miniatura circular dentro de la cápsula (hasta que el personaje se carga en 3D). Se crea al acercarse.
  async function ensureThumb(i) {
    const c = caps[i], m = list[i];
    if (!c || c.thumbState) return;
    c.thumbState = 1;
    try {
      const cv = paint2d(256, 256, () => {});
      const g = cv.getContext('2d');
      g.fillStyle = 'rgba(8,24,34,.55)'; g.beginPath(); g.arc(128, 128, 120, 0, Math.PI * 2); g.fill();
      if (m.thumb?.data) {
        const bmp = await createImageBitmap(new Blob([m.thumb.data], { type: m.thumb.type }));
        if (closed) return;
        g.save(); g.beginPath(); g.arc(128, 128, 114, 0, Math.PI * 2); g.clip();
        const s = Math.max(256 / bmp.width, 256 / bmp.height);
        g.drawImage(bmp, 128 - (bmp.width * s) / 2, 128 - (bmp.height * s) / 2, bmp.width * s, bmp.height * s);
        g.restore();
        bmp.close?.();
      }
      g.strokeStyle = 'rgba(160,230,255,.9)'; g.lineWidth = 6; g.beginPath(); g.arc(128, 128, 118, 0, Math.PI * 2); g.stroke();
      const sp = new THREE.Sprite(track(new THREE.SpriteMaterial({ map: tex(cv), transparent: true, depthWrite: false })));
      sp.scale.set(1.5, 1.5, 1);
      sp.position.y = 1.5;
      c.group.add(sp);
      c.thumb = sp;
      c.thumbState = 2;
      sp.visible = loadedIndex !== i;
    } catch (err) {
      console.warn('[lab] miniatura', err);
      c.thumbState = 3;
    }
  }

  // ── Personaje en 3D (solo el de la cápsula enfocada) ────────────────────────────────────────────
  function unloadModel() {
    loadToken++;
    if (holder) {
      scene.remove(holder);
      holder = null;
    }
    try { built?.dispose(); } catch { /* nada */ }
    built = null;
    if (caps[loadedIndex]?.thumb) caps[loadedIndex].thumb.visible = true;
    loadedIndex = -1;
  }

  async function showModel(i) {
    const m = list[i];
    if (!m || loadedIndex === i) return;
    unloadModel();
    const token = loadToken;
    statusEl.textContent = 'Cargando personaje…';
    try {
      const { preview } = await loadPreviewFor(store, m);
      if (closed || token !== loadToken) return;
      const b = await buildPreviewGroup(THREE, preview, { texMax: profile?.tier === 'low' ? 512 : 1024 });
      if (closed || token !== loadToken) {
        b.dispose();
        return;
      }
      const s = fitScale(b.size);
      b.group.scale.setScalar(s);
      b.group.position.set(-b.center.x * s, -b.box.min.y * s, -b.center.z * s);
      const hold = new THREE.Group();
      hold.add(b.group);
      hold.position.set(caps[i].x, LAB.FLOOR, 0);
      scene.add(hold);
      holder = hold;
      built = b;
      loadedIndex = i;
      if (caps[i].thumb) caps[i].thumb.visible = false;
      statusEl.textContent = 'Arrastra para pasar a otra cápsula';
    } catch (err) {
      if (token !== loadToken) return;
      console.warn('[lab] no se pudo cargar', m.name, err);
      statusEl.textContent = 'No se pudo mostrar en 3D; se ve la miniatura';
    }
  }

  // ── Movimiento ───────────────────────────────────────────────────────────────────────────────
  function go(d) {
    const i = Math.max(0, Math.min(n - 1, nearestCapsule(targetX, n) + d));
    targetX = i * LAB.GAP;
    vel = 0;
    settledFor = 0;
  }

  const ray = { rc: null, v: null };
  let down = null;
  function onDown(e) {
    if (!n || e.button > 0) return;
    canvas.setPointerCapture?.(e.pointerId);
    down = { x: e.clientX, t: performance.now(), moved: 0, id: e.pointerId, lx: e.clientX, lt: performance.now() };
    dragging = true;
    vel = 0;
  }
  function onMove(e) {
    if (!down || e.pointerId !== down.id) return;
    const dx = e.clientX - down.lx;
    down.moved += Math.abs(dx);
    const dist = camera.position.z; // ancho visible en el plano de las cápsulas
    const perPx = (2 * Math.tan((camera.fov * Math.PI) / 360) * dist * camera.aspect) / Math.max(1, canvas.clientWidth);
    const dt = Math.max(1, performance.now() - down.lt) / 1000;
    const dxw = -dx * perPx;
    targetX = Math.max(-LAB.GAP * 0.3, Math.min((n - 1) * LAB.GAP + LAB.GAP * 0.3, targetX + dxw));
    vel = vel * 0.6 + (dxw / dt) * 0.4;
    down.lx = e.clientX;
    down.lt = performance.now();
    settledFor = 0;
  }
  function onUp(e) {
    if (!down || e.pointerId !== down.id) return;
    const wasTap = down.moved < 10 && performance.now() - down.t < 450;
    down = null;
    dragging = false;
    if (wasTap) {
      const rect = canvas.getBoundingClientRect();
      ray.rc ||= new THREE.Raycaster();
      ray.v ||= new THREE.Vector2();
      ray.v.set(((e.clientX - rect.left) / rect.width) * 2 - 1, -(((e.clientY - rect.top) / rect.height) * 2 - 1));
      ray.rc.setFromCamera(ray.v, camera);
      const hit = ray.rc.intersectObjects(caps.flatMap((c) => c.group.children.filter((o) => o.userData.index !== undefined)), false)[0];
      if (hit) targetX = hit.object.userData.index * LAB.GAP;
      else if (zoom > 0.5) settledFor = 0; // tocar fuera: nada
      vel = 0;
    } else {
      targetX = snapTarget(targetX, vel, n);
      vel = 0;
    }
    settledFor = 0;
  }
  const onKey = (ev) => {
    if (closed || !dismissMain?.isTop?.()) return;
    if (ev.key === 'ArrowLeft') go(-1);
    else if (ev.key === 'ArrowRight') go(1);
  };

  function resize() {
    if (!renderer) return;
    const w = Math.max(1, canvas.clientWidth), ht = Math.max(1, canvas.clientHeight);
    renderer.setSize(w, ht, false);
    camera.aspect = w / ht;
    camera.updateProjectionMatrix();
  }

  function frame(ts) {
    raf = requestAnimationFrame(frame);
    if (closed || document.hidden) { last = ts; return; }
    const dt = Math.min(0.1, (ts - last) / 1000 || 0.016);
    last = ts;
    // Cámara: sigue al objetivo (el dedo la mueve directamente) y se acerca cuando se queda quieta.
    if (!dragging) camX += (targetX - camX) * (1 - Math.exp(-dt * 7));
    else camX += (targetX - camX) * (1 - Math.exp(-dt * 30));
    const moving = dragging || Math.abs(targetX - camX) > 0.03;
    settledFor = moving ? 0 : settledFor + dt;
    const near = settledFor > LAB.SETTLE_S && n > 0;
    zoom += ((near ? 1 : 0) - zoom) * (1 - Math.exp(-dt * 3.2));
    const idx = nearestCapsule(camX, n);
    if (idx !== focus) {
      focus = idx;
      paintHud();
    }
    if (near && n) {
      ensureThumb(idx);
      if (loadedIndex !== idx && !loadingFor.has(idx)) {
        loadingFor.add(idx);
        showModel(idx).finally(() => loadingFor.delete(idx));
      }
    } else if (moving) {
      // Al desplazarse se cargan las miniaturas de las cápsulas que se ven.
      for (let k = Math.max(0, idx - 2); k <= Math.min(n - 1, idx + 2); k++) ensureThumb(k);
    }
    const z = LAB.FAR_Z + (LAB.NEAR_Z - LAB.FAR_Z) * zoom;
    camera.position.set(camX, 2.0 + (1.6 - 2.0) * zoom, z);
    camera.lookAt(camX, 1.1 + (0.95 - 1.1) * zoom, 0);
    if (holder) {
      holder.rotation.y += dt * 0.55;
      holder.visible = loadedIndex === focus || Math.abs(caps[loadedIndex]?.x - camX) < LAB.GAP * 1.4;
    }
    if (bubbles && n) {
      const p = bubbles.geometry.attributes.position, sd = bubbles.userData.seed;
      bubbles.position.set(caps[focus].x, 0, 0);
      for (let i = 0; i < sd.length; i++) {
        let y = p.getY(i) + dt * (0.18 + sd[i] * 0.35);
        if (y > 2.6) y = 0.4;
        p.setY(i, y);
      }
      p.needsUpdate = true;
    }
    renderer.render(scene, camera);
  }
  const loadingFor = new Set();

  // ── Cierre ───────────────────────────────────────────────────────────────────────────────────
  function finish() {
    if (closed) return;
    closed = true;
    cancelAnimationFrame(raf);
    document.removeEventListener('keydown', onKey);
    ro?.disconnect();
    unloadModel();
    for (const d of disposables) { try { d.dispose(); } catch { /* nada */ } }
    try { renderer?.dispose(); renderer?.forceContextLoss(); } catch { /* nada */ }
    el.classList.remove('is-open');
    setTimeout(() => el.remove(), 320);
    onClose?.();
  }
  dismissMain = layers.pushOverlay(() => finish());
  document.addEventListener('keydown', onKey);

  // ── Arranque ─────────────────────────────────────────────────────────────────────────────────
  if (n) paintHud();
  (async () => {
    try {
      THREE = await loadThree();
      if (closed) return;
      buildScene();
      resize();
      ro = new ResizeObserver(resize);
      ro.observe(canvas);
      canvas.addEventListener('pointerdown', onDown);
      canvas.addEventListener('pointermove', onMove);
      canvas.addEventListener('pointerup', onUp);
      canvas.addEventListener('pointercancel', onUp);
      canvas.addEventListener('webglcontextlost', (e) => { e.preventDefault(); statusEl.textContent = 'Se perdió el contexto gráfico; vuelve a abrir el laboratorio.'; });
      if (n) for (let k = Math.max(0, focus - 2); k <= Math.min(n - 1, focus + 2); k++) ensureThumb(k);
      last = performance.now();
      raf = requestAnimationFrame(frame);
      el.dataset.ready = '1';
    } catch (err) {
      console.warn('[lab] no se pudo iniciar', err);
      empty.hidden = false;
      empty.textContent = 'No se pudo iniciar el laboratorio 3D en este dispositivo.';
    }
  })();

  // Para pruebas y para quien llame desde fuera.
  const api = {
    el,
    close: () => dismissMain?.(),
    debug: () => ({ focus, loadedIndex, camX, targetX, zoom, active, n, settledFor, dragging, vel, closed }),
  };
  el.__lab = api;
  return api;
}
