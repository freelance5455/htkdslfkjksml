// Visor B · piel y texturas. Panel que se muestra bajo el visor del detalle cuando se elige «B» en los botones A | B.
// Importar textura y fondo, rugosidad, metalicidad, opacidad, luces y exposición. Todo se guarda con el modelo y la textura y
// los materiales también se ven en el personaje del mundo (world/avatar.js llama a applySavedLook).
import { h, icon } from '../ui/dom.js';
import { toast } from '../ui/toast.js';
import {
  DEFAULT_LOOK, MAX_TEX_BYTES, MAX_BG_BYTES, BG_KEY,
  applyLook, cleanLook, loadImageTexture, readLook, saveLook,
} from '../ui/look.js';

const SLIDERS = [
  { key: 'key', label: 'Luz principal', min: 0, max: 3, step: 0.05, kind: 'view' },
  { key: 'amb', label: 'Luz ambiental', min: 0, max: 3, step: 0.05, kind: 'view' },
  { key: 'exp', label: 'Exposición', min: 0.2, max: 2.5, step: 0.05, kind: 'view' },
  { key: 'alpha', label: 'Opacidad', min: 0.1, max: 1, step: 0.01, kind: 'mat' },
  { key: 'rough', label: 'Rugosidad', min: 0, max: 1, step: 0.01, kind: 'mat', orig: true },
  { key: 'metal', label: 'Metalicidad', min: 0, max: 1, step: 0.01, kind: 'mat', orig: true },
];

export function createSkinPanel({ store, model, getViewer, profile }) {
  let look = { ...DEFAULT_LOOK };
  let texBlob = null;
  let tex = null;
  let bgBlob = null;
  let bgTex = null;
  let active = false;
  let loaded = false;
  let disposed = false;
  let saveTimer = 0;
  const maxTex = profile?.tier === 'low' ? 1024 : 2048;

  const readouts = {};
  const ranges = {};

  const fileTex = h('input', { type: 'file', accept: 'image/*', hidden: true, onchange: (e) => pick(e, 'tex') });
  const fileBg = h('input', { type: 'file', accept: 'image/*', hidden: true, onchange: (e) => pick(e, 'bg') });
  const btnTex = h('button', { class: 'chip-btn', type: 'button', onclick: () => fileTex.click() }, icon('upload', 18), 'Importar textura');
  const btnTexOff = h('button', { class: 'chip-btn', type: 'button', onclick: () => removeTex() }, icon('trash', 18), 'Quitar textura');
  const btnBg = h('button', { class: 'chip-btn', type: 'button', onclick: () => fileBg.click() }, icon('upload', 18), 'Importar fondo');
  const btnBgOff = h('button', { class: 'chip-btn', type: 'button', onclick: () => removeBg() }, icon('trash', 18), 'Quitar fondo');
  btnTexOff.disabled = btnBgOff.disabled = true; // hasta que se lea lo guardado no hay nada que quitar
  const force = h('input', { type: 'checkbox', onchange: () => {
    look.force = force.checked;
    push();
    persist();
  } });
  const status = h('p', { class: 'hint skin__status' });

  const rows = SLIDERS.map((sl) => {
    const out = h('output', { class: 'skin__val' });
    const input = h('input', {
      type: 'range', min: sl.min, max: sl.max, step: sl.step, value: sl.orig ? 0.5 : DEFAULT_LOOK[sl.key], 'aria-label': sl.label,
      oninput: () => {
        look[sl.key] = Number(input.value);
        readout(sl);
        push(sl.kind);
        persist();
      },
    });
    readouts[sl.key] = out;
    ranges[sl.key] = input;
    return h('label', { class: 'skin__row' }, h('span', { class: 'skin__lab' }, sl.label), input, out);
  });

  const resetBtn = h('button', { class: 'chip-btn', type: 'button', onclick: () => reset() }, icon('refresh', 18), 'Restablecer ajustes');

  const el = h(
    'section',
    { class: 'skin', hidden: true, 'aria-label': 'Visor B: piel y texturas' },
    h('p', { class: 'hint' }, 'Visor B · piel y texturas. Lo que elijas se guarda con este modelo y el personaje lo muestra también en el mundo.'),
    h('div', { class: 'viewer-tools' }, btnTex, btnTexOff, btnBg, btnBgOff, fileTex, fileBg),
    h('label', { class: 'skin__check' }, force, h('span', null, 'La textura reemplaza también la que ya trae el modelo')),
    status,
    h('div', { class: 'skin__rows' }, rows),
    h('div', { class: 'viewer-tools' }, resetBtn),
  );

  function readout(sl) {
    const v = look[sl.key];
    readouts[sl.key].textContent = sl.orig && v == null ? 'original' : Number(v).toFixed(2);
  }

  function paint() {
    force.checked = !!look.force;
    for (const sl of SLIDERS) {
      const v = look[sl.key];
      ranges[sl.key].value = sl.orig && v == null ? 0.5 : v;
      readout(sl);
    }
    btnTexOff.disabled = !texBlob;
    btnBgOff.disabled = !bgBlob;
    const parts = [];
    parts.push(texBlob ? 'Textura propia aplicada.' : 'Sin textura importada: se ve el modelo tal como es.');
    if (bgBlob) parts.push('Fondo puesto.');
    status.textContent = parts.join(' ');
  }

  // Lo que se ve en el visor según el modo (A: modelo tal cual; B: con la apariencia).
  function push(kind = 'all') {
    const v = getViewer();
    if (!v?.built || !v.THREE) return;
    const L = active ? look : DEFAULT_LOOK;
    if (kind === 'all' || kind === 'mat') applyLook(v.THREE, v.built.group, L, active ? tex : null);
    if (kind === 'all' || kind === 'view') {
      v.setLightScale(L.key, L.amb);
      v.setExposure(L.exp);
    }
    if (kind === 'all') v.setBackground(active ? bgTex : null);
    v.requestRender();
  }

  function persist() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(async () => {
      try {
        look = cleanLookKeepNull(look, !!texBlob);
        await saveLook(store, model.id, look, texBlob);
      } catch (err) {
        console.warn('[visor B] no se pudo guardar', err);
        toast('No se pudo guardar la apariencia en este dispositivo.', { kind: 'error' });
      }
    }, 450);
  }
  // cleanLook también valida; aquí solo se mantiene hasTex coherente con el Blob.
  function cleanLookKeepNull(l, hasTex) {
    return { ...cleanLook({ ...l, hasTex }) };
  }

  async function ensureLoaded() {
    if (loaded) return;
    loaded = true;
    const v = getViewer();
    try {
      const r = await readLook(store, model.id);
      look = r.look;
      texBlob = r.blob;
      bgBlob = await store.getSetting(BG_KEY, null).catch(() => null);
      if (v?.THREE) {
        if (texBlob) tex = await loadImageTexture(v.THREE, texBlob, { maxSize: maxTex }).catch(() => null);
        if (bgBlob) bgTex = await loadImageTexture(v.THREE, bgBlob, { maxSize: 2048, equirect: true }).catch(() => null);
      }
    } catch (err) {
      console.warn('[visor B] no se pudo leer lo guardado', err);
    }
    if (disposed) {
      tex?.dispose();
      bgTex?.dispose();
      return;
    }
    paint();
  }

  const hasUv = (v) => {
    let ok = false;
    v.built.group.traverse((o) => {
      if (o.isMesh && o.geometry?.attributes?.uv) ok = true;
    });
    return ok;
  };

  async function pick(e, what) {
    const f = e.target.files?.[0];
    e.target.value = '';
    if (!f) return;
    const v = getViewer();
    if (!v?.built || !v.THREE) return;
    if (!/^image\//.test(f.type)) {
      toast('Elige un archivo de imagen (PNG, JPG o WebP).', { kind: 'error' });
      return;
    }
    const limit = what === 'tex' ? MAX_TEX_BYTES : MAX_BG_BYTES;
    if (f.size > limit) {
      toast(`La imagen pesa más de ${Math.round(limit / 1048576)} MB.`, { kind: 'error' });
      return;
    }
    if (what === 'tex' && !hasUv(v)) {
      toast('Este modelo no tiene coordenadas UV: una textura no se puede colocar sobre él.', { kind: 'error' });
      return;
    }
    try {
      if (what === 'tex') {
        const t = await loadImageTexture(v.THREE, f, { maxSize: maxTex });
        if (disposed) return t.dispose();
        tex?.dispose();
        tex = t;
        texBlob = f;
        look.hasTex = true;
        push();
        persist();
        toast('Textura aplicada. Se guarda con este modelo.', { kind: 'ok' });
      } else {
        const t = await loadImageTexture(v.THREE, f, { maxSize: 2048, equirect: true });
        if (disposed) return t.dispose();
        bgTex?.dispose();
        bgTex = t;
        bgBlob = f;
        await store.setSetting(BG_KEY, f);
        push();
        toast('Fondo puesto (es el mismo para todos los modelos).', { kind: 'ok' });
      }
      paint();
    } catch (err) {
      console.error('[visor B]', err);
      toast('No se pudo leer esa imagen.', { kind: 'error' });
    }
  }

  function removeTex() {
    tex?.dispose();
    tex = null;
    texBlob = null;
    look.hasTex = false;
    push();
    persist();
    paint();
  }

  async function removeBg() {
    bgTex?.dispose();
    bgTex = null;
    bgBlob = null;
    await store.setSetting(BG_KEY, null).catch(() => {});
    push();
    paint();
  }

  function reset() {
    look = { ...DEFAULT_LOOK, hasTex: !!texBlob };
    push();
    persist();
    paint();
  }

  return {
    el,
    // Pasa al visor B.
    async enter() {
      active = true;
      el.hidden = false;
      await ensureLoaded();
      if (active) push();
    },
    // Vuelve al visor A: el modelo tal cual, sin tocar lo guardado.
    leave() {
      active = false;
      el.hidden = true;
      push();
    },
    // El visor reconstruyó el modelo (p. ej. vista completa): se reaplica lo elegido.
    onBuilt() {
      if (active && loaded) push();
    },
    get active() {
      return active;
    },
    dispose() {
      disposed = true;
      clearTimeout(saveTimer);
      tex?.dispose();
      bgTex?.dispose();
    },
  };
}
