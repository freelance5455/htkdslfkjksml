// Capa 4 · Mundo abierto: pantalla completa con el personaje del usuario caminando por un terreno infinito con cielo, Sol,
// nubes, sombras, agua y vegetación. Esta capa solo une las piezas (js/world/*): lee la entrada, mueve al personaje, pide
// los trozos de terreno, actualiza la atmósfera y dibuja; además pinta la interfaz (joystick, botones, ajustes).
//
// Se abre como una superposición (botón Atrás del móvil = salir). Si Three.js, WebGL o los sombreadores propios fallan,
// se avisa y el mundo pasa al modo sencillo o se cierra con un mensaje claro: nunca queda una pantalla en blanco.
import { h, icon, clear } from '../ui/dom.js';
import { toast } from '../ui/toast.js';
import { loadThree } from '../core/threeLoader.js';
import { WorldRenderer } from '../world/render.js';
import { ChunkManager } from '../world/chunks.js';
import { createChunkSource } from '../world/chunkSource.js';
import { WorldInput } from '../world/input.js';
import { WorldController } from '../world/controller.js';
import { prepareAvatar } from '../world/avatar.js';
import { QUALITY, QUALITY_ORDER, qualityForTier } from '../world/quality.js';
import { WEATHER, formatHours } from '../world/atmosphere.js';
import { SPAWN, SEA, heightAt } from '../world/terrain.js';
import { openSheet } from '../ui/sheet.js';
import { bus } from '../core/bus.js';
import { pro, resolveQuality, texMax, levelB } from '../core/pro.js';
import { openProSettings } from './proSettings.js';
import { openNetSheet } from './netSheet.js';
import { getNet } from '../net/index.js';
import { Remotes } from '../net/remotes.js';
import { audio } from '../audio/engine.js';
import { createAmbient } from '../audio/ambient.js';
import { biomeAt } from '../world/biome.js';
import { estimateVram } from '../core/diag.js';

export const WORLD_KEY = 'world';
const SPAWN_HEADING = 0.79;
const TIME_SPEEDS = { pause: { label: 'Pausa', rate: 0 }, slow: { label: 'Lento', rate: 1 / 90 }, fast: { label: 'Rápido', rate: 1 / 10 } }; // horas del juego por segundo real
const TIME_PRESETS = [
  ['Amanecer', 6.4],
  ['Mañana', 9.5],
  ['Mediodía', 12.3],
  ['Atardecer', 18.35],
  ['Noche', 22.5],
];
const READY_TIMEOUT_S = 9; // si los trozos de alrededor tardan más, se entra igualmente
const SAVE_EVERY_S = 6;

export const DEFAULT_WORLD_SETTINGS = Object.freeze({ hours: 9.5, weather: 'clear', quality: 'auto', timeSpeed: 'slow', tech: false, invertY: false, creatures: true, creatureSound: true, pos: null, posShen: null, shen: { flora: true, life: true, dragons: true } });

// Ajustes guardados → ajustes válidos (se ignora lo que no tenga sentido).
export function sanitizeWorldSettings(raw) {
  const out = { ...DEFAULT_WORLD_SETTINGS };
  if (!raw || typeof raw !== 'object') return out;
  if (Number.isFinite(raw.hours)) out.hours = ((raw.hours % 24) + 24) % 24;
  if (typeof raw.weather === 'string' && WEATHER[raw.weather]) out.weather = raw.weather;
  if (raw.quality === 'auto' || QUALITY[raw.quality]) out.quality = raw.quality;
  if (TIME_SPEEDS[raw.timeSpeed]) out.timeSpeed = raw.timeSpeed;
  if (typeof raw.tech === 'boolean') out.tech = raw.tech;
  if (typeof raw.invertY === 'boolean') out.invertY = raw.invertY;
  if (typeof raw.creatures === 'boolean') out.creatures = raw.creatures;
  if (typeof raw.creatureSound === 'boolean') out.creatureSound = raw.creatureSound;
  const okPos = (a) => Array.isArray(a) && a.length === 3 && a.every((v) => Number.isFinite(v) && Math.abs(v) < 1e6);
  if (okPos(raw.pos)) out.pos = raw.pos.slice(0, 3);
  if (okPos(raw.posShen)) out.posShen = raw.posShen.slice(0, 3);
  out.shen = { ...DEFAULT_WORLD_SETTINGS.shen };
  if (raw.shen && typeof raw.shen === 'object') for (const k of Object.keys(out.shen)) if (typeof raw.shen[k] === 'boolean') out.shen[k] = raw.shen[k];
  return out;
}

// Gobernador de fotogramas: mide los FPS y, si el móvil no llega, baja primero la resolución y luego la calidad.
// Funciones puras para poder probarlo sin pantalla. state = { low, high, cooldown }.
export function governorStep(state, fps, dt, { scale, qualityIndex, canLowerQuality = true }) {
  const out = { scale, qualityIndex, changed: false };
  state.cooldown = Math.max(0, state.cooldown - dt);
  if (fps < 24) {
    state.low += dt;
    state.high = 0;
  } else if (fps > 54) {
    state.high += dt;
    state.low = 0;
  } else {
    state.low = Math.max(0, state.low - dt);
    state.high = Math.max(0, state.high - dt);
  }
  if (state.cooldown > 0) return out;
  if (state.low > 2.5) {
    if (scale > 0.62) out.scale = Math.max(0.6, +(scale - 0.15).toFixed(2));
    else if (canLowerQuality && qualityIndex > 0) {
      out.qualityIndex = qualityIndex - 1;
      out.scale = 1;
    } else return out;
    out.changed = true;
  } else if (state.high > 12 && scale < 1) {
    out.scale = Math.min(1, +(scale + 0.1).toFixed(2));
    out.changed = true;
  }
  if (out.changed) {
    state.low = state.high = 0;
    state.cooldown = 4;
  }
  return out;
}

// store, model, layers, profile: los del hub. onModel(m): se avisa si se guardó un esqueleto nuevo. Devuelve { close }.
export function openWorld({ store, model, layers, profile, onModel = null, onClose = null, root = document.getElementById('app'), worldId = 'eden' }) {
  const isShen = worldId === 'shenlong'; // EDEN = el mundo propio de RigWorld · SHENLONG = el mundo de los dragones
  let shen = null; // ShenlongWorld (solo en SHENLONG)
  let shenMod = null, shenCtlMod = null; // módulos de SHENLONG, cargados al entrar
  let shenPhase = 'tiles'; // tiles → flora → listo
  let shenZoneT = 0;
  let closed = false;
  let cfg = { ...DEFAULT_WORLD_SETTINGS };
  let ctl = new AbortController();
  let runId = 0;
  let THREE = null;
  let net = null; // sesión multijugador (única en toda la aplicación; sobrevive al salir del mundo)
  let unsubNet = null;
  let remotes = null;
  let netDirty = false;
  const netWorld = isShen ? 'shen' : 'eden'; // nombre del mundo en los mensajes de red
  let wr = null; // WorldRenderer
  let chunks = null;
  let source = null;
  let input = null;
  let avatar = null;
  let controller = null;
  let creatures = null; // criaturas vivas (se cargan al empezar a jugar)
  let zooRef = null;
  let creaturesState = 'idle'; // idle | loading | ready | failed
  let creaturesPromise = null;
  let raf = 0;
  let lastT = 0;
  let playing = false; // ¿ya se puede jugar?
  let hours = cfg.hours;
  let loadingTime = 0;
  let camYawIdle = SPAWN_HEADING + Math.PI;
  let saveTimer = 0;
  let hudTimer = 0;
  let hintTimer = 0;
  let frameErrors = 0;
  let autosave = 0;
  let awaitingTerrain = false;
  let idle = { x: 0, z: 0, heading: SPAWN_HEADING };
  let unwatch = null;
  let ro = null;
  let fpsEma = 60;
  let fpsAccum = { t: 0, n: 0 };
  const gov = { low: 0, high: 0, cooldown: 6 };
  let scale = 1;
  let qualityIdx = 1;
  let curRes = null; // resultado de resolveQuality (calidad vigente + efectos)
  let thermalDrop = 0; // niveles que ha bajado el gobernador térmico (tipo B)
  let batteryDrop = 0; // niveles que baja el ahorro de batería (tipo B)
  let unsubPro = null;
  const ambient = createAmbient();
  audio.start(); // viene de un toque («Entrar al mundo»); si el navegador no lo deja, se reintenta con el siguiente toque
  const frameMs = []; // últimos ~240 fotogramas (ms) para el informe de diagnóstico
  let battery = null;
  let simpleNotified = false;
  let glareKey = '';
  let dismissPanel = null;
  let overlayDismiss = null;
  // Límite de fotogramas: el del ajuste «FPS objetivo» o, si es automático, el del dispositivo.
  const frameCapMs = () => {
    const c = pro.get('fpsTarget');
    return c !== 'auto' ? 1000 / Number(c) - 2 : profile?.maxFps === 30 ? 29 : 0;
  };
  let lastRenderT = 0;

  // ── Interfaz ─────────────────────────────────────────────────────────────────────────────────
  const canvas = h('canvas', { class: 'world__canvas', role: 'img', 'aria-label': 'Vista del mundo en tercera persona' });
  const stage = h('div', { class: 'world__stage' }, canvas);
  const glare = h('div', { class: 'world__glare', 'aria-hidden': 'true' });

  const knob = h('i', { class: 'world__knob' });
  const joy = h('div', { class: 'world__joy', 'aria-hidden': 'true', hidden: true }, knob);

  const noTouch = { 'data-no-touch': '' };
  const backBtn = h('button', { ...noTouch, class: 'world__pill world__back', type: 'button', 'aria-label': 'Regresar', onclick: () => close() }, icon('back', 20), 'Regresar');
  const clockText = h('span', { class: 'mono' }, '--:--');
  const weatherText = h('span', null, '');
  const clockBtn = h('button', { ...noTouch, class: 'world__pill', type: 'button', 'aria-label': 'Hora y clima', onclick: () => togglePanel() }, icon('sun', 18), clockText, weatherText);
  const gearBtn = h('button', { ...noTouch, class: 'world__btn world__btn--round', type: 'button', 'aria-label': 'Ajustes del mundo', onclick: () => togglePanel() }, icon('sliders'));
  const tech = h('p', { class: 'world__tech mono', hidden: true, 'aria-hidden': 'true' });

  const jumpBtn = h('button', { ...noTouch, class: 'world__btn world__btn--big', type: 'button', 'aria-label': 'Saltar' }, icon('up', 30));
  jumpBtn.addEventListener('pointerdown', (e) => {
    e.preventDefault();
    input?.pressJump();
  });
  jumpBtn.addEventListener('click', (e) => e.detail === 0 && input?.pressJump()); // con teclado
  const waveBtn = h('button', { ...noTouch, class: 'world__btn world__btn--round', type: 'button', 'aria-label': 'Saludar' }, icon('hand', 24));
  waveBtn.addEventListener('pointerdown', (e) => {
    e.preventDefault();
    input?.pressWave();
  });
  waveBtn.addEventListener('click', (e) => e.detail === 0 && input?.pressWave());
  const runBtn = h('button', { ...noTouch, class: 'world__btn world__btn--round', type: 'button', 'aria-pressed': 'false', 'aria-label': 'Correr rápido' }, icon('bolt', 24));
  runBtn.addEventListener('click', () => {
    const on = runBtn.getAttribute('aria-pressed') !== 'true';
    runBtn.setAttribute('aria-pressed', String(on));
    input?.setSprint(on);
  });
  const actions = h('div', { class: 'world__actions' }, waveBtn, runBtn, jumpBtn);

  // SHENLONG: volar, velocidad de viaje (×1 / ×3 / ×10), viaje rápido y letrero de la zona.
  const SPEED_LABELS = ['×1', '×3', '×10'];
  const flyBtn = h('button', { ...noTouch, class: 'world__btn world__btn--round', type: 'button', 'aria-pressed': 'false', 'aria-label': 'Volar', onclick: () => toggleFly() }, icon('wing', 24));
  const speedBtn = h('button', { ...noTouch, class: 'world__btn world__btn--round world__btn--txt', type: 'button', 'aria-label': 'Velocidad de viaje', onclick: () => cycleSpeed() }, SPEED_LABELS[0]);
  const travelBtn = h('button', { ...noTouch, class: 'world__btn world__btn--round', type: 'button', 'aria-label': 'Viaje rápido', onclick: () => openTravelSheet() }, icon('pin', 24));
  const shenSide = isShen ? h('div', { class: 'world__side' }, travelBtn, speedBtn, flyBtn) : null;
  const zoneName = h('b', null, '');
  const zoneSub = h('span', null, '');
  const zoneEl = isShen ? h('div', { class: 'world__zone', 'aria-live': 'polite' }, zoneName, zoneSub) : null;

  const hint = h('p', { class: 'world__hint', role: 'status' }, isShen
    ? 'Pulgar izquierdo: andar · derecho: mirar · el ala vuela hacia donde miras · ×3/×10 acelera · el pin viaja a los dragones'
    : 'Mantén el pulgar izquierdo para andar · arrastra con el derecho para mirar · pellizca para acercar');

  // Panel de ajustes
  const timeLabel = h('span', { class: 'mono' }, '09:30');
  const timeInput = h('input', { class: 'range', type: 'range', min: '0', max: '24', step: '0.05', value: String(cfg.hours), 'aria-label': 'Hora del día', oninput: () => setHours(Number(timeInput.value), true) });
  const groups = [];
  const chipGroup = (label, options, get, set) => {
    const row = h('div', { class: 'viewer-tools', role: 'group', 'aria-label': label });
    const btns = options.map(([key, text]) => {
      const b = h('button', { class: 'chip-btn', type: 'button', 'aria-pressed': 'false', onclick: () => set(key) }, text);
      row.append(b);
      return [key, b];
    });
    const paint = () => btns.forEach(([k, b]) => b.setAttribute('aria-pressed', String(get() === k)));
    groups.push(paint);
    paint();
    return row;
  };
  const presetRow = h('div', { class: 'viewer-tools', role: 'group', 'aria-label': 'Momentos del día' });
  for (const [label, hr] of TIME_PRESETS) presetRow.append(h('button', { class: 'chip-btn', type: 'button', onclick: () => setHours(hr, true) }, label));
  const speedRow = chipGroup('Velocidad del tiempo', Object.entries(TIME_SPEEDS).map(([k, v]) => [k, v.label]), () => cfg.timeSpeed, (k) => {
    cfg.timeSpeed = k;
    repaintGroups();
    scheduleSave();
  });
  const weatherRow = chipGroup('Clima', Object.entries(WEATHER).map(([k, v]) => [k, v.label]), () => cfg.weather, (k) => {
    cfg.weather = k;
    repaintGroups();
    paintClock();
    scheduleSave();
  });
  const qualityRow = chipGroup('Calidad gráfica', [['auto', 'Auto'], ...QUALITY_ORDER.map((k) => [k, QUALITY[k].label])], () => cfg.quality, (k) => {
    cfg.quality = k;
    applyQuality(true);
    repaintGroups();
    scheduleSave();
  });
  // Tipo de calidad (A: RigWorld · B: EDEN, niveles 1-20). Cada uno muestra su propio control; todo lo demás está en «Ajustes avanzados».
  const modeBtns = [['a', 'A · RigWorld'], ['b', 'B · EDEN 1-20']].map(([id, text]) => {
    const b = h('button', { class: 'seg__btn', type: 'button', onclick: () => pro.update({ mode: id }) }, text);
    b.dataset.mode = id;
    return b;
  });
  const modeRow = h('div', { class: 'seg seg--inline', role: 'group', 'aria-label': 'Tipo de calidad' }, modeBtns);
  const levelOut = h('output', { class: 'skin__val' });
  const levelInput = h('input', { type: 'range', min: 1, max: 20, step: 1, id: 'world-level', 'aria-label': 'Nivel de calidad' });
  levelInput.addEventListener('input', () => (levelOut.textContent = `${levelInput.value} · ${levelB(Number(levelInput.value)).name}`));
  levelInput.addEventListener('change', () => pro.update({ level: Number(levelInput.value) }));
  const levelRow = h('label', { class: 'skin__row' }, h('span', { class: 'skin__lab' }, 'Nivel'), levelInput, levelOut);
  const qualityA = h('div', { class: 'world__sub' }, qualityRow, h('p', { class: 'hint' }, 'Auto baja la resolución y los detalles si el móvil no llega a 30 fotogramas por segundo.'));
  const qualityB = h('div', { class: 'world__sub' }, levelRow, h('p', { class: 'hint' }, 'Del 11 en adelante cada nivel suma efectos. Si el móvil se calienta o la batería baja, el nivel baja solo.'));
  const advBtn = h('button', { class: 'btn btn--ghost', type: 'button', onclick: () => openProSettings({ layers, profile, getReport: report, getWorldCfg: () => ({ ...cfg, hours }) }) }, icon('sliders', 18), 'Ajustes avanzados…');
  function paintQualityMode() {
    const b = pro.get('mode') === 'b';
    qualityA.hidden = b;
    qualityB.hidden = !b;
    for (const x of modeBtns) x.setAttribute('aria-pressed', String(x.dataset.mode === pro.get('mode')));
    levelInput.value = pro.get('level');
    levelOut.textContent = `${pro.get('level')} · ${levelB(pro.get('level')).name}`;
  }
  paintQualityMode();
  const techSwitch = h('input', { class: 'switch', type: 'checkbox', id: 'world-tech', checked: cfg.tech, onchange: () => {
    cfg.tech = techSwitch.checked;
    paintTech(true);
    scheduleSave();
  } });
  const invertSwitch = h('input', { class: 'switch', type: 'checkbox', id: 'world-invert', checked: cfg.invertY, onchange: () => {
    cfg.invertY = invertSwitch.checked;
    scheduleSave();
  } });
  const creaturesSwitch = h('input', { class: 'switch', type: 'checkbox', id: 'world-creatures', checked: cfg.creatures, onchange: () => {
    cfg.creatures = creaturesSwitch.checked;
    if (cfg.creatures && creaturesState === 'idle') ensureCreatures();
    scheduleSave();
  } });
  const soundSwitch = h('input', { class: 'switch', type: 'checkbox', id: 'world-creature-sound', checked: cfg.creatureSound, onchange: () => {
    cfg.creatureSound = soundSwitch.checked;
    if (creatures) creatures.sound = cfg.creatureSound;
    scheduleSave();
  } });
  const summonBtn = h('button', { class: 'btn btn--ghost', type: 'button', onclick: () => openSummonSheet() }, icon('paw', 18), 'Invocar criatura…');
  const dismissBtn = h('button', { class: 'btn btn--ghost', type: 'button', onclick: () => creatures?.clear() }, icon('close', 18), 'Despedir a las criaturas');
  const netBtn = h('button', { class: 'btn btn--ghost', type: 'button', onclick: () => openNet() }, icon('wifi', 18), 'Multijugador por Wi‑Fi…');
  const netCount = h('b');
  const netPill = h('button', { ...noTouch, class: 'world__pill', type: 'button', hidden: true, 'aria-label': 'Jugadores conectados', onclick: () => openNet() }, icon('wifi', 18), netCount);
  const restartBtn = h('button', { class: 'btn btn--ghost', type: 'button', onclick: () => respawn() }, icon('refresh', 18), 'Volver al punto de inicio');
  const label = (text) => h('p', { class: 'studio__label' }, text);
  const shenSwitch = (id, key, text, live) => {
    const sw = h('input', { class: 'switch', type: 'checkbox', id, checked: cfg.shen[key], onchange: () => {
      cfg.shen[key] = sw.checked;
      if (live) shen?.setFlag(key, sw.checked);
      scheduleSave();
    } });
    return h('label', { class: 'world__switch-row', for: id }, h('span', null, text), sw);
  };
  const edenBlock = h('div', { class: 'world__sub' },
    label('Criaturas'),
    h('label', { class: 'world__switch-row', for: 'world-creatures' }, h('span', null, 'Criaturas en el mundo'), creaturesSwitch),
    h('label', { class: 'world__switch-row', for: 'world-creature-sound' }, h('span', null, 'Sonidos de criaturas'), soundSwitch),
    h('div', { class: 'world__btnrow' }, summonBtn, dismissBtn),
    h('p', { class: 'hint' }, 'Los dragones viven en SHENLONG. Aquí solo aparecen si los invocas.'),
  );
  const callBtn = h('button', { class: 'btn btn--ghost', type: 'button', onclick: () => openCallSheet() }, icon('paw', 18), 'Llamar a un dragón…');
  const sendHomeBtn = h('button', { class: 'btn btn--ghost', type: 'button', onclick: () => {
    const n = shen?.sendDragonsHome() || 0;
    toast(n ? 'Los dragones vuelven a su guarida.' : 'No hay dragones llamados.');
  } }, icon('close', 18), 'Que vuelvan a su guarida');
  const shenBlock = h('div', { class: 'world__sub' },
    label('SHENLONG'),
    shenSwitch('shen-flora', 'flora', 'Bosques, hierba y rocas', true),
    shenSwitch('shen-life', 'life', 'Aves, cascadas y motas de luz', true),
    shenSwitch('shen-dragons', 'dragons', 'Dragones (al volver a entrar)', false),
    h('div', { class: 'world__btnrow' }, callBtn, sendHomeBtn),
    h('p', { class: 'hint' }, 'Llamas a un dragón y viene volando hasta donde estás. Si el móvil va justo, apaga la vegetación o la vida; los dragones tardan en construirse la primera vez.'),
  );
  const colTime = h(
    'div',
    { class: 'world__col' },
    h('div', { class: 'studio__speed' }, h('label', { class: 'studio__label', for: 'world-time' }, 'Hora del día'), timeLabel),
    timeInput,
    presetRow,
    label('Paso del tiempo'),
    speedRow,
  );
  const colLook = h(
    'div',
    { class: 'world__col' },
    label('Clima'),
    weatherRow,
    label('Calidad gráfica'),
    modeRow,
    qualityA,
    qualityB,
    advBtn,
    h('label', { class: 'world__switch-row', for: 'world-invert' }, h('span', null, 'Invertir mirada arriba/abajo'), invertSwitch),
    h('label', { class: 'world__switch-row', for: 'world-tech' }, h('span', null, 'Mostrar datos técnicos'), techSwitch),
    isShen ? shenBlock : edenBlock,
    h('div', { class: 'world__sub' }, label('Multijugador'), netBtn, h('p', { class: 'hint' }, 'Juega con amigos en la misma red Wi‑Fi, sin internet ni cuentas.')),
    restartBtn,
  );
  const panel = h(
    'div',
    { ...noTouch, class: 'world__panel', role: 'dialog', 'aria-label': 'Ajustes del mundo', hidden: true },
    h('div', { class: 'world__panel-head' }, h('h2', null, 'Mundo'), h('button', { class: 'icon-btn', type: 'button', 'aria-label': 'Cerrar ajustes', onclick: () => togglePanel(false) }, icon('close'))),
    h('div', { class: 'world__cols' }, colTime, colLook),
  );
  timeInput.id = 'world-time';

  // Pantalla de carga
  const loadText = h('p', { class: 'viewer-status__text' }, 'Preparando el mundo…');
  const loadBar = h('div', { class: 'progress progress--thin' }, h('i'));
  const loadSpinner = h('span', { class: 'spinner', 'aria-hidden': 'true' });
  const retryBtn = h('button', { class: 'btn btn--primary', type: 'button', hidden: true, onclick: () => restart() }, 'Reintentar');
  const exitBtn = h('button', { class: 'btn btn--ghost', type: 'button', onclick: () => close() }, 'Salir');
  // data-no-touch: WorldInput captura el puntero de cualquier toque fuera de estos elementos, y con el puntero capturado el «clic» no llegaría a los botones.
  const loading = h('div', { ...noTouch, class: 'world__load', role: 'status' }, h('div', { class: 'world__load-card' }, loadSpinner, loadText, loadBar, h('div', { class: 'world__load-actions' }, retryBtn, exitBtn)));

  function setLoading(text, p, { error = false } = {}) {
    loading.hidden = false;
    loading.classList.toggle('is-error', error);
    loadSpinner.hidden = error;
    loadBar.hidden = error || p == null;
    retryBtn.hidden = !error;
    loadText.textContent = text;
    if (p != null) loadBar.firstChild.style.transform = `scaleX(${Math.min(1, Math.max(0, p))})`;
  }

  const hud = h(
    'div',
    { class: 'world__hud' },
    h('div', { class: 'world__top' }, backBtn, clockBtn, netPill, gearBtn),
    zoneEl,
    tech,
    joy,
    shenSide,
    actions,
    hint,
    panel,
  );
  const el = h('section', { class: 'world', 'aria-label': 'Mundo abierto' }, stage, glare, hud, loading);
  root.append(el);
  requestAnimationFrame(() => el.classList.add('is-open'));
  // Pantalla completa si el navegador lo permite (hace falta el gesto del toque que abrió el mundo). «Regresar» sale.
  try {
    el.requestFullscreen?.({ navigationUI: 'hide' })?.catch?.(() => {});
  } catch {
    /* sin pantalla completa */
  }
  setLoading('Preparando el mundo…', 0);

  // ── Ajustes y estado ─────────────────────────────────────────────────────────────────────────
  const repaintGroups = () => groups.forEach((p) => p());

  function paintClock() {
    clockText.textContent = formatHours(hours);
    weatherText.textContent = ` · ${WEATHER[cfg.weather].label}`;
    timeLabel.textContent = formatHours(hours);
  }
  function setHours(v, fromUser = false) {
    hours = ((v % 24) + 24) % 24;
    if (fromUser) timeInput.value = String(hours);
    paintClock();
    if (fromUser) scheduleSave();
  }

  function paintTech(force = false) {
    tech.hidden = !cfg.tech;
    if (!cfg.tech || !wr) return;
    if (!force && hudTimer < 0.5) return;
    const i = wr.info;
    const q = currentQuality();
    tech.textContent = `${Math.round(fpsEma)} fps · ${i.calls} llamadas · ${Math.round(i.triangles / 1000)} k tri · ${isShen ? `${shen?.terrain?.tiles?.size ?? 0} teselas` : `${chunks?.summary.loaded ?? 0} trozos`} · ${q.label}${cfg.quality === 'auto' ? ' (auto)' : ''} · res ${Math.round(scale * 100)} %${wr.simple ? ' · modo sencillo' : ''}`;
  }

  // Calidad vigente = tipo A (Baja/Media/Alta de RigWorld) o tipo B (nivel 1-20 de EDEN) + los ajustes sueltos de «Ajustes avanzados».
  const baseQuality = () => QUALITY[QUALITY_ORDER[qualityIdx]];
  function resolveNow() {
    curRes = resolveQuality(pro.all(), { baseQ: baseQuality(), tier: profile?.tier, thermal: thermalDrop, battery: batteryDrop });
    return curRes;
  }
  function currentQuality() {
    return (curRes || resolveNow()).q;
  }
  // La escala del gobernador de fotogramas se multiplica por la del nivel (tipo B).
  const applyScale = () => wr?.setScale(scale * (curRes?.scale ?? 1));
  function applyQuality(fromUser = false) {
    if (cfg.quality === 'auto') {
      if (fromUser) qualityIdx = QUALITY_ORDER.indexOf(qualityForTier(profile?.tier).id);
    } else qualityIdx = QUALITY_ORDER.indexOf(cfg.quality);
    scale = 1;
    gov.low = gov.high = 0;
    gov.cooldown = 6;
    applyResolved();
  }
  function applyResolved() {
    resolveNow();
    wr?.setQuality(curRes.q);
    wr?.applyPro(curRes);
    applyScale();
    chunks?.setQuality(curRes.q);
    paintTech(true);
  }
  // Cambió algún ajuste avanzado (o el estado de batería / temperatura).
  function onProChanged() {
    if (closed) return;
    paintQualityMode();
    applyResolved();
  }

  // Escalón de calidad de SHENLONG (0-3): el del nivel (tipo B), el de «Texturas del mundo» o el de la calidad del tipo A. Se aplica al entrar.
  function shenTier() {
    const tw = pro.get('texWorld');
    if (tw !== 'auto') return { low: 0, medium: 1, high: 2, max: 3 }[tw];
    return (curRes || resolveNow()).shenTier ?? Math.min(2, qualityIdx);
  }
  // Ahorro de batería (tipo B): con menos del 20 % y sin cargar baja dos niveles.
  function onBattery() {
    if (!battery) return;
    const d = battery.level < 0.2 && !battery.charging ? 2 : 0;
    if (d !== batteryDrop) {
      batteryDrop = d;
      if (pro.get('mode') === 'b' && pro.get('battery')) applyResolved();
    }
  }
  function watchBattery() {
    if (!navigator.getBattery) return;
    navigator.getBattery().then((b) => {
      if (closed || battery) return;
      battery = b;
      b.addEventListener('levelchange', onBattery);
      b.addEventListener('chargingchange', onBattery);
      onBattery();
    }).catch(() => {});
  }

  function togglePanel(force) {
    const open = force ?? panel.hidden;
    if (open === !panel.hidden) return;
    panel.hidden = !open;
    if (open) {
      hint.hidden = true;
      repaintGroups();
      dismissPanel = layers.pushOverlay(() => {
        dismissPanel = null;
        panel.hidden = true;
      });
    } else if (dismissPanel) {
      const d = dismissPanel;
      dismissPanel = null;
      d();
    }
  }

  // Guarda los ajustes y la posición (con un pequeño retraso para no escribir en cada gesto).
  function scheduleSave() {
    saveTimer = Math.max(saveTimer, 0.01);
  }
  async function saveNow() {
    saveTimer = 0;
    try {
      const st = controller?.state;
      const out = { ...cfg, hours };
      if (st) out[isShen ? 'posShen' : 'pos'] = [st.x, st.z, st.heading];
      await store.setSetting(WORLD_KEY, out);
    } catch (err) {
      console.warn('[mundo] no se pudieron guardar los ajustes', err);
    }
  }

  // ── SHENLONG: vuelo, velocidad de viaje y viaje rápido ───────────────────────────────────────
  let travelText = '';
  function paintShenButtons(st) {
    flyBtn.setAttribute('aria-pressed', String(!!st.fly));
    speedBtn.textContent = SPEED_LABELS[st.speedLvl] || '×1';
    jumpBtn.setAttribute('aria-label', st.fly ? 'Subir' : 'Saltar');
  }
  function toggleFly() {
    if (!controller || !playing) return;
    const on = controller.setFly(!controller.fly);
    paintShenButtons(controller.state);
    toast(on ? 'Vuelo activado: avanza hacia donde miras.' : 'Vuelo desactivado.');
  }
  function cycleSpeed() {
    if (!controller) return;
    const l = controller.cycleSpeed();
    paintShenButtons(controller.state);
    toast(controller.fly ? `Vuelo ${shenMod.SHEN.FLY[l]} m/s` : `Velocidad ${SPEED_LABELS[l]}`);
  }
  // Teletransporta y espera a que carguen las teselas de alrededor (pantalla de carga corta).
  function travelTo(x, z, yaw, text = 'Viajando…') {
    if (!controller || !shen?.ready) return;
    controller.teleport(x, z, yaw);
    travelText = text;
    playing = false;
    awaitingTerrain = true;
    loadingTime = 0;
    shenPhase = 'tiles';
    shen.beginLoad();
    setLoading(text, 0.66);
    el.classList.remove('is-playing');
    scheduleSave();
  }
  function openTravelSheet() {
    if (!shen?.ready || !controller) return;
    togglePanel(false);
    const body = h('div', { class: 'summon' });
    let sheet = null;
    for (const t of shen.travelPoints()) {
      body.append(h('div', { class: 'travel' },
        h('div', { class: 'travel__t' }, h('b', null, t.title), t.sub ? h('span', null, t.sub) : null),
        h('div', { class: 'viewer-tools' }, t.acts.map((a) => h('button', { class: 'chip-btn', type: 'button', onclick: () => {
          sheet?.close();
          travelTo(a.x, a.z, a.yaw, `Viajando a ${t.title}…`);
        } }, a.label)))));
    }
    sheet = openSheet({ title: 'Viaje rápido', body, layers, tall: true });
  }

  // SHENLONG: en vez de «invocar», se LLAMA al dragón y él viene volando hasta donde está el jugador.
  async function openCallSheet() {
    if (!shen?.ready || !controller) return;
    if (!shen.hasDragons) return toast('Los dragones están apagados: actívalos en Ajustes del mundo y vuelve a entrar.', { kind: 'error' });
    const STATE = { guarida: 'En su guarida', viniendo: 'Viene hacia ti', aqui: 'Aquí contigo', volviendo: 'Vuelve a su guarida' };
    const body = h('div', { class: 'summon' });
    let sheet = null;
    const km = (m) => (m < 1000 ? `${Math.round(m)} m` : `${(m / 1000).toFixed(1)} km`);
    body.append(h('p', { class: 'hint' }, 'Elige a quién llamar. Viene volando desde su guarida hasta donde estás ahora.'));
    for (const d of shen.dragonList()) {
      body.append(h('div', { class: 'travel' },
        h('div', { class: 'travel__t' }, h('b', null, d.name), h('span', null, `${d.habitat} · ${STATE[d.state] || ''} · a ${km(d.dist)}`)),
        h('div', { class: 'viewer-tools' }, h('button', { class: 'chip-btn', type: 'button', disabled: !d.loaded, onclick: async () => {
          sheet?.close();
          togglePanel(false);
          if (cfg.creatureSound) (await import('../zoo/sound.js')).zooAudioStart();
          const st = controller?.state;
          const r = shen.callDragon(d.id, { x: st?.x ?? idle.x, y: st?.y ?? 0, z: st?.z ?? idle.z });
          toast(r.msg, { kind: r.ok ? 'ok' : 'error' });
        } }, d.loaded ? 'Llamar' : 'Despertando…'))));
    }
    sheet = openSheet({ title: 'Llamar a un dragón', body, layers, tall: true });
  }
  // Sonido y avisos de los dragones llamados (el rugido llega con ellos).
  async function wireDragonEvents() {
    if (!shen?.hasDragons) return;
    const { ZooSound } = await import('../zoo/sound.js');
    shen.onDragonEvent((type, d) => {
      if (closed) return;
      const P = controller?.state;
      const dist = P ? Math.hypot(d.pos.x - P.x, d.pos.z - P.z) : 0;
      const pitch = Math.max(0.35, 0.7 - Math.log10(Math.max(dist, 100)) * 0.05);
      if (type === 'arrive') {
        toast(`${d.name} ha llegado.`);
        if (cfg.creatureSound && d.sp?.sound) ZooSound.play(d.sp.sound, 0.7, 0, pitch);
      } else if (type === 'start') {
        if (cfg.creatureSound && d.sp?.sound) setTimeout(() => ZooSound.play(d.sp.sound, 0.3, 0, pitch), 600); // responde desde lejos
      } else if (type === 'home') toast(`${d.name} descansa de nuevo en su guarida.`);
    });
  }

  function respawn() {
    if (!controller) return;
    if (isShen) travelTo(shenMod.SHEN.SPAWN[0], shenMod.SHEN.SPAWN[1], shenMod.SHEN.HEADING, 'Volviendo al inicio…');
    else controller.teleport(SPAWN[0], SPAWN[1], SPAWN_HEADING);
    togglePanel(false);
    toast('De vuelta en el punto de inicio.');
    scheduleSave();
  }

  // ── Arranque ─────────────────────────────────────────────────────────────────────────────────
  async function start() {
    const run = ++runId;
    const stale = () => closed || run !== runId;
    try {
      cfg = sanitizeWorldSettings(await store.getSetting(WORLD_KEY, null).catch(() => null));
      hours = cfg.hours;
      timeInput.value = String(hours);
      techSwitch.checked = cfg.tech;
      invertSwitch.checked = cfg.invertY;
      repaintGroups();
      paintClock();
      if (!profile?.webgl?.ok) {
        setLoading('Este dispositivo no ofrece WebGL 2, así que no se puede mostrar el mundo en 3D.', null, { error: true });
        retryBtn.hidden = true;
        return;
      }
      setLoading('Cargando el motor 3D…', 0.02);
      THREE = await loadThree();
      if (stale()) return;
      if (isShen) [shenMod, shenCtlMod] = await Promise.all([import('../shenlong/engine.js'), import('../shenlong/controller.js')]); // solo se descargan al entrar en SHENLONG
      if (stale()) return;

      qualityIdx = cfg.quality === 'auto' ? QUALITY_ORDER.indexOf(qualityForTier(profile?.tier).id) : QUALITY_ORDER.indexOf(cfg.quality);
      setLoading('Creando el mundo…', 0.04);
      wr = new WorldRenderer(THREE, canvas, {
        quality: currentQuality(),
        onShaderError: onShaderError,
        onContextLost: () => !closed && setLoading('Se perdió el contexto gráfico (el sistema liberó la memoria de vídeo). Vuelve a intentarlo.', null, { error: true }),
      });
      wr.resize();
      wr.applyPro(resolveNow());
      applyScale();
      unsubPro?.();
      unsubPro = bus.on('pro:changed', onProChanged);
      watchBattery();
      if (isShen) wr.setWorldProfile({ far: shenMod.SHEN.CAM_FAR, shadows: false });
      wr.setTime(hours);
      wr.setWeather(cfg.weather);
      wr.update(0, { hours, weatherKey: cfg.weather, playerPos: [0, 0, 0], camera: null });
      watchResize();

      if (!isShen) {
        source = createChunkSource({});
        chunks = new ChunkManager({ source, quality: currentQuality(), build: (res, c) => wr.buildChunk(res, c) });
      }

      const sp0 = isShen ? cfg.posShen : cfg.pos;
      const spawn = sp0 ? [sp0[0], sp0[1]] : isShen ? shenMod.SHEN.SPAWN : SPAWN;
      const heading = sp0 ? sp0[2] : isShen ? shenMod.SHEN.HEADING : SPAWN_HEADING;
      idle = { x: spawn[0], z: spawn[1], heading };
      camYawIdle = heading + Math.PI * 0.8;
      input = new WorldInput(el, { onStick: paintStick });
      lastT = performance.now();
      const liveNet = getNet();
      if (liveNet?.active) attachNet(liveNet); // ya había una partida abierta: sigue al cambiar de mundo
      raf = requestAnimationFrame(frame);

      if (isShen) {
        // El terreno gigante: texturas, hilos de trabajo y módulos (flora, vida, dragones). Los dragones usan el zoológico.
        let zoo = null;
        if (cfg.shen.dragons) {
          try {
            const { createZoo } = await import('../zoo/zoo.js');
            zooRef = createZoo(THREE, { log: (lvl, sys, e) => console.warn(`[${sys}]`, e) });
            zooRef.setBuildBudget(4);
            zoo = zooRef;
          } catch (err) {
            console.warn('[shenlong] sin dragones', err);
          }
        }
        if (stale()) return;
        shen = new shenMod.ShenlongWorld({ THREE, scene: wr.scene, camera: wr.camera, renderer: wr.renderer, zoo, log: (lvl, sys, e) => console.warn(`[${sys}]`, e), flags: cfg.shen });
        await shen.prepare(shenTier(), (p, t) => !stale() && setLoading(t, 0.05 + p * 0.2));
        if (stale()) return;
        shen.enter();
        shen.pos.set(spawn[0], 0, spawn[1]);
        wireDragonEvents();
      }

      // El personaje se prepara mientras los primeros trozos de terreno se generan.
      avatar = await prepareAvatar({
        store,
        model,
        profile,
        texLimit: texMax(pro.get('texChar'), profile?.tier),
        signal: ctl.signal,
        onModel,
        onStatus: (text, p) => !stale() && setLoading(text, isShen ? 0.25 + p * 0.4 : 0.05 + p * 0.85),
      });
      if (stale()) {
        avatar.dispose();
        avatar = null;
        return;
      }
      wr.setAvatar(avatar.group);
      if (isShen) {
        controller = new shenCtlMod.ShenlongController({ avatar, world: shen, spawn, heading });
        wr.avatarRoot.rotation.order = 'YXZ'; // rumbo y luego inclinación (al volar el cuerpo se inclina hacia delante)
        shen.beginLoad();
        shenPhase = 'tiles';
      } else controller = new WorldController({ avatar, spawn, heading });
      setLoading('Construyendo el terreno…', isShen ? 0.66 : 0.92);
      loadingTime = 0;
      awaitingTerrain = true;
    } catch (err) {
      if (stale() || err?.name === 'AbortError') return;
      console.error('[mundo]', err);
      setLoading(err?.message || 'No se pudo abrir el mundo.', null, { error: true });
    }
  }
  // Carga el zoológico y el gestor de criaturas la primera vez que hacen falta (no retrasa la entrada al mundo).
  function ensureCreatures() {
    if (creaturesPromise) return creaturesPromise;
    creaturesState = 'loading';
    const myRun = runId;
    creaturesPromise = (async () => {
      try {
        const [{ createZoo }, { createCreatureManager }, { zooAudioStart }, { biomeAt: biomeFn }] = await Promise.all([
          import('../zoo/zoo.js'), import('../zoo/creatures.js'), import('../zoo/sound.js'), import('../world/biome.js'),
        ]);
        if (closed || myRun !== runId || !wr) return null;
        zooRef = createZoo(THREE, { log: (lvl, sys, e) => console.warn(`[${sys}]`, e) });
        zooRef.setBuildBudget(4); // en el mundo, construir criaturas en trozos pequeños para no cortar los fotogramas
        creatures = createCreatureManager({
          THREE, zoo: zooRef, scene: wr.scene,
          terrain: { heightAt, biomeAt: biomeFn, sea: SEA },
          adapt: (g) => wr.adaptCreature(g),
          onSeen: (sp) => toast(`Avistado: ${sp.name}`),
        });
        creatures.sound = cfg.creatureSound;
        el.addEventListener('pointerdown', () => { if (cfg.creatureSound) zooAudioStart(); }, { once: true, capture: true }); // el audio solo arranca tras un toque
        creaturesState = 'ready';
        return creatures;
      } catch (err) {
        console.warn('[mundo] criaturas no disponibles', err);
        creaturesState = 'failed';
        return null;
      }
    })();
    return creaturesPromise;
  }

  async function openSummonSheet() {
    const mgr = await ensureCreatures();
    if (!mgr || !zooRef) return toast('Las criaturas no están disponibles en este dispositivo.', { kind: 'error' });
    const CAT = { animales: 'Animales', fantasticos: 'Fantásticos', leyendas: 'Leyendas y dragones', monstruos: 'Monstruos' };
    const body = h('div', { class: 'summon' });
    let sheet = null;
    for (const cat of Object.keys(CAT)) {
      const list = zooRef.list().filter((sp) => sp.cat === cat); // todas, también los dragones (solo aparecen así en EDEN)
      if (!list.length) continue;
      body.append(h('p', { class: 'studio__label' }, CAT[cat]), h('div', { class: 'viewer-tools' }, list.map((sp) => h('button', {
        class: 'chip-btn', type: 'button',
        onclick: async () => {
          sheet?.close();
          togglePanel(false);
          if (!cfg.creatures) { cfg.creatures = true; creaturesSwitch.checked = true; scheduleSave(); }
          toast(`Invocando: ${sp.name}…`);
          if (cfg.creatureSound) (await import('../zoo/sound.js')).zooAudioStart();
          const r = await mgr.summon(sp.id, { x: controller?.state.x ?? idle.x, z: controller?.state.z ?? idle.z }, wr.camera);
          toast(r.msg, { kind: r.ok ? 'ok' : 'error' });
        },
      }, sp.name))));
    }
    sheet = openSheet({ title: 'Invocar criatura', body, layers, tall: true });
  }

  // ── Multijugador ────────────────────────────────────────────────────────────────────────────
  function paintNetPill() {
    netPill.hidden = !net?.active;
    netCount.textContent = net?.active ? String(net.count) : '';
  }
  function attachNet(n) {
    if (net === n && unsubNet) return;
    unsubNet?.();
    net = n;
    n.setWorld(netWorld);
    unsubNet = n.on(() => {
      netDirty = true;
      paintNetPill();
    });
    netDirty = true;
    paintNetPill();
  }
  function openNet() {
    // Sin cerrar antes el panel: cerrarlo deshace una entrada del historial que cerraría justo la hoja nueva (como «Ajustes avanzados»).
    openNetSheet({ layers, name: model?.name, onSession: attachNet });
  }
  // Cada fotograma: envía la posición propia y mueve a los demás jugadores.
  function netFrame(dt, st) {
    if (net?.active && THREE) {
      if (!remotes) remotes = new Remotes({ THREE, scene: wr.scene, adapt: (g) => wr.adaptCreature(g) });
      if (netDirty) {
        remotes.sync(net.list());
        netDirty = false;
      }
      if (st && playing) net.sendState({ x: st.x, y: st.y, z: st.z, h: st.heading, s: st.speed || 0, f: isShen && st.mode === 'fly' });
      remotes.update(dt, net.list(), netWorld);
    } else if (remotes) {
      remotes.dispose();
      remotes = null;
    }
  }

  function onShaderError(err) {
    console.warn('[mundo] sombreador:', err?.message || err);
    if (simpleNotified || closed) return;
    simpleNotified = true;
    // Los sombreadores propios no compilan en este dispositivo: se sigue con materiales estándar.
    queueMicrotask(() => {
      try {
        wr?.enterSimpleMode();
      } catch (e) {
        console.error('[mundo] no se pudo pasar al modo sencillo', e);
      }
      toast('Este dispositivo no admite los efectos avanzados del cielo y el suelo. Se usa el modo sencillo (sin hierba animada).', { kind: 'error', ms: 7000 });
    });
  }

  function paintStick(s) {
    if (!s.active) {
      joy.hidden = true;
      return;
    }
    joy.hidden = false;
    joy.style.transform = `translate(${s.ox}px, ${s.oy}px)`; // coordenadas relativas a la capa (WorldInput ya resta su rectángulo)
    knob.style.transform = `translate(${s.kx - s.ox}px, ${s.ky - s.oy}px)`;
    hint.hidden = true; // al usar el joystick ya no hace falta la ayuda
  }

  function watchResize() {
    const fn = () => wr?.resize();
    if (typeof ResizeObserver !== 'undefined') {
      ro = new ResizeObserver(fn);
      ro.observe(stage);
    }
    window.addEventListener('resize', fn);
    window.addEventListener('orientationchange', fn);
    unwatch = () => {
      ro?.disconnect();
      window.removeEventListener('resize', fn);
      window.removeEventListener('orientationchange', fn);
    };
  }

  // ── Bucle ────────────────────────────────────────────────────────────────────────────────────
  function frame(now) {
    if (closed) return;
    raf = requestAnimationFrame(frame);
    if (document.hidden) {
      lastT = now;
      return;
    }
    const rawDt = (now - lastT) / 1000;
    const minFrameMs = frameCapMs();
    if (minFrameMs && now - lastRenderT < minFrameMs) return;
    lastRenderT = now;
    lastT = now;
    const dt = Math.min(0.1, Math.max(0, rawDt));
    try {
      step(dt, rawDt);
      frameErrors = 0;
    } catch (err) {
      // Un error en un fotograma no debe congelar el mundo ni dejar el bucle muerto: se cuenta y, si se repite, se avisa.
      console.error('[mundo] error en el fotograma', err);
      if (++frameErrors > 8 && !closed) {
        setLoading('Ocurrió un error al dibujar el mundo. Vuelve a intentarlo.', null, { error: true });
        cancelAnimationFrame(raf);
      }
    }
  }

  function step(dt, rawDt) {
    if (!wr) return;
    // FPS suavizados (se ignoran los fotogramas enormes de cuando la pestaña estuvo en segundo plano).
    if (rawDt > 0 && rawDt < 0.5) {
      if (frameMs.length >= 240) frameMs.shift();
      frameMs.push(rawDt * 1000);
      fpsAccum.t += rawDt;
      fpsAccum.n++;
      if (fpsAccum.t >= 0.5) {
        const fps = fpsAccum.n / fpsAccum.t;
        fpsEma = fpsEma * 0.6 + fps * 0.4;
        fpsAccum = { t: 0, n: 0 };
        if (playing && pro.get('mode') === 'b') {
          // Tipo B: el gobernador térmico baja el nivel (hasta 5) si los fotogramas se alargan; el índice «0-3» solo hace de contador.
          if (pro.get('thermal')) {
            const idx = 5 - thermalDrop;
            const r = governorStep(gov, fpsEma, 0.5, { scale, qualityIndex: idx });
            if (r.changed) {
              scale = r.scale;
              if (r.qualityIndex < idx) thermalDrop = Math.min(5, thermalDrop + 1);
              applyResolved();
            }
          }
        } else if (playing && cfg.quality === 'auto') {
          const r = governorStep(gov, fpsEma, 0.5, { scale, qualityIndex: qualityIdx });
          if (r.changed) {
            const qChanged = r.qualityIndex !== qualityIdx;
            scale = r.scale;
            qualityIdx = r.qualityIndex;
            if (qChanged) {
              resolveNow();
              wr.setQuality(curRes.q);
              wr.applyPro(curRes);
              chunks?.setQuality(curRes.q);
            }
            applyScale();
          }
        }
      }
    }

    if (!playing) loadingTime += dt;
    let st = null;
    if (controller && playing) {
      const inp = input.consume();
      if (cfg.invertY) inp.lookY = -inp.lookY; // por defecto: dedo arriba = mirar arriba
      controller.footIK = wr.q?.footIK !== 0;
      st = isShen ? controller.step(dt, inp) : controller.step(dt, inp, (cx, cz) => chunks.colliders(cx, cz));
    } else {
      input.consume(); // mientras se carga se descarta la entrada
      if (controller) st = controller.state;
    }

    // Paso del tiempo.
    const dayMin = pro.get('dayMinutes');
    const rate = TIME_SPEEDS[cfg.timeSpeed].rate && dayMin !== 'auto' ? 24 / (Number(dayMin) * 60) : TIME_SPEEDS[cfg.timeSpeed].rate;
    if (rate && playing) hours = (hours + dt * rate) % 24;

    const px = st ? st.x : idle.x, pz = st ? st.z : idle.z;
    chunks?.update(px, pz, dt);
    netFrame(dt, st);
    if (!isShen && playing && cfg.creatures && creaturesState === 'idle' && fpsEma > 22) ensureCreatures();
    if (creatures) {
      // Con pocos FPS no aparecen más criaturas; el tope por calidad baja solo si el gobernador baja la calidad.
      creatures.cap = fpsEma < 26 ? 0 : currentQuality().creatures;
      creatures.enabled = cfg.creatures;
      creatures.lowDetail = qualityIdx === 0;
      creatures.update(dt, { x: px, z: pz }, { night: hours < 5.5 || hours >= 20 });
    }

    // Cámara: la del controlador, o una órbita lenta alrededor del punto de inicio mientras se carga.
    let cam, look, py;
    if (st) {
      cam = st.camera;
      look = st.look;
      py = st.y;
      wr.avatarRoot.position.set(st.x, st.y, st.z);
      wr.avatarRoot.rotation.y = st.heading;
      wr.avatarRoot.rotation.x = st.tilt || 0;
    } else {
      camYawIdle += dt * 0.08;
      py = isShen ? (shen?.ready ? shen.groundAt(px, pz) : 0) : heightAt(px, pz);
      look = [px, py + 1.4, pz];
      cam = { x: px - Math.sin(camYawIdle) * 6, y: py + 2.6, z: pz - Math.cos(camYawIdle) * 6 };
    }
    wr.camera.position.set(cam.x, cam.y, cam.z);
    wr.camera.lookAt(look[0], look[1], look[2]);
    const atm = wr.update(dt, { hours, weatherKey: cfg.weather, playerPos: [px, py, pz], camera: cam });
    if (isShen && shen?.ready) {
      shen.pos.set(px, py, pz);
      shen.update(wr.camera.position, dt, { state: atm, lut: wr.lut, fogK: wr.weather.fog, underwater: !!st?.underwater });
    }
    wr.render();
    paintGlare(wr.computeGlare());
    if (playing && st) {
      // Ambiente sonoro (viento, pasos, pájaros, chapoteo): solo suena si el audio ya arrancó con un toque.
      ambient.frame({
        active: true,
        y: st.y,
        grounded: isShen ? st.mode === 'walk' : true,
        wet: isShen ? st.mode === 'swim' || !!st.underwater : (st.wade || 0) > 0.6 || st.y < SEA - 0.3,
        speed: st.speed || 0,
        biome: isShen ? null : () => biomeAt(st.x, st.z),
        hours,
      });
    }

    // ¿Listo para jugar? Cuando hay terreno alrededor (o ha pasado demasiado tiempo) se quita la pantalla de carga.
    if (awaitingTerrain) {
      let ready = false;
      if (isShen) {
        if (shen?.ready && controller) {
          if (shenPhase === 'tiles') {
            const r = shen.loadStep(600);
            setLoading(travelText || 'Construyendo el terreno…', 0.66 + 0.28 * r.p);
            if (r.done || loadingTime > READY_TIMEOUT_S * 2.2) {
              shenPhase = 'flora';
              shen.endLoad();
              setLoading('Plantando bosques y praderas…', 0.95);
              shen.warm(px, py, pz, 5000).finally(() => { shenPhase = 'ready'; });
            }
          } else if (shenPhase === 'ready') ready = true;
        }
      } else ready = chunks.isReady(px, pz, 1) || loadingTime > READY_TIMEOUT_S;
      if (ready) {
        awaitingTerrain = false;
        if (pro.get('warmup')) {
          try {
            wr.renderer.compile(wr.scene, wr.camera); // sombreadores precompilados: sin tirones al ver cosas nuevas
          } catch {
            /* el siguiente fotograma los compila igualmente */
          }
        }
        playing = true;
        audio.inWorld = true;
        loading.hidden = true;
        hint.hidden = false;
        hintTimer = 7;
        el.classList.add('is-playing');
        travelText = '';
      }
    }

    hudTimer += dt;
    if (hudTimer >= 0.5) {
      paintClock();
      paintTech(true);
      hudTimer = 0;
      if (isShen && shen?.ready && st && playing) {
        const z = shen.zoneInfo(st.x, st.y, st.z, st.underwater);
        zoneName.textContent = z.name;
        zoneSub.textContent = z.sub;
        paintShenButtons(st);
      }
    }
    if (!hint.hidden && playing) {
      hintTimer -= dt;
      if (hintTimer <= 0) hint.hidden = true;
    }
    if (playing) {
      if (saveTimer > 0) {
        saveTimer += dt;
        if (saveTimer > 1.2) saveNow();
      } else {
        autosave += dt;
        if (autosave > SAVE_EVERY_S) {
          autosave = 0;
          saveNow();
        }
      }
    }
  }
  // Resplandor del Sol (CSS): una capa de degradado radial sobre la imagen, con el color de la luz que llega.
  function paintGlare(g) {
    const key = g.visible ? `${g.x.toFixed(3)}|${g.y.toFixed(3)}|${g.alpha.toFixed(2)}` : 'off';
    if (key === glareKey) return;
    glareKey = key;
    if (!g.visible) {
      glare.style.opacity = '0';
      return;
    }
    const t = g.warm || [1, 1, 1];
    const m = Math.max(t[0], t[1], t[2], 1e-4);
    const c = [t[0] / m, t[1] / m, t[2] / m].map((v) => Math.round(255 * (0.55 + 0.45 * Math.pow(v, 0.6))));
    glare.style.setProperty('--gx', `${(g.x * 100).toFixed(2)}%`);
    glare.style.setProperty('--gy', `${(g.y * 100).toFixed(2)}%`);
    glare.style.setProperty('--gc', `${c[0]}, ${c[1]}, ${c[2]}`);
    glare.style.opacity = g.alpha.toFixed(3);
  }

  // ── Cierre y reintento ───────────────────────────────────────────────────────────────────────
  function release() {
    unsubNet?.();
    unsubNet = null;
    net?.setWorld('');
    net = null;
    remotes?.dispose();
    remotes = null;
    audio.inWorld = false;
    ambient.dispose();
    unsubPro?.();
    unsubPro = null;
    battery?.removeEventListener?.('levelchange', onBattery);
    battery?.removeEventListener?.('chargingchange', onBattery);
    battery = null;
    cancelAnimationFrame(raf);
    ctl.abort();
    unwatch?.();
    unwatch = null;
    input?.dispose();
    creatures?.dispose();
    zooRef?.disposeAll?.();
    creatures = zooRef = creaturesPromise = null;
    shen?.dispose();
    shen = null;
    chunks?.dispose();
    source?.dispose?.();
    try {
      wr?.setAvatar(null);
      avatar?.dispose();
    } catch (err) {
      console.warn('[mundo] al liberar el personaje', err);
    }
    wr?.dispose();
    wr = chunks = source = input = avatar = controller = null;
  }

  // Con los ajustes abiertos, «salir» y Atrás cierran primero el panel; después, el mundo.
  function close() {
    if (closed) return;
    if (!panel.hidden) return togglePanel(false);
    overlayDismiss?.();
  }

  function finish() {
    if (closed) return;
    if (controller) saveNow();
    closed = true;
    document.removeEventListener('keydown', onKey);
    document.removeEventListener('visibilitychange', onVis);
    if (window.rigworld?.world === debug) delete window.rigworld.world;
    release();
    try {
      if (document.fullscreenElement === el) document.exitFullscreen?.()?.catch?.(() => {});
    } catch {
      /* nada */
    }
    el.classList.remove('is-open');
    setTimeout(() => el.remove(), 320);
    onClose?.();
  }

  // «Reintentar»: se libera todo y se vuelve a empezar con el mismo modelo.
  function restart() {
    if (closed) return;
    release();
    ctl = new AbortController();
    playing = false;
    awaitingTerrain = false;
    frameErrors = 0;
    simpleNotified = false;
    el.classList.remove('is-playing');
    start();
  }

  const onKey = (e) => {
    if (e.key !== 'Escape') return;
    if (!panel.hidden) togglePanel(false); // el panel es la superposición de más arriba
    else if (overlayDismiss?.isTop?.()) close();
  };
  const onVis = () => {
    lastT = performance.now();
  };
  document.addEventListener('keydown', onKey);
  document.addEventListener('visibilitychange', onVis);

  // Para depurar desde la consola del móvil (chrome://inspect) y para las pruebas: window.rigworld.world.
  // Datos para el informe de diagnóstico (core/diag.js): fotogramas, calidad vigente, memoria y estado del mundo.
  function report() {
    const ft = [...frameMs].sort((a, b) => a - b);
    const at = (p) => (ft.length ? Math.round(ft[Math.min(ft.length - 1, Math.floor(ft.length * p))]) : 0);
    const post = curRes?.post;
    const fx = post?.active ? ['aa=' + post.aa, post.bloom && 'bloom', post.ssao && 'ssao', post.rays && 'rayos', post.sharpen && 'nitidez', post.grain && 'grano', post.ca && 'aberración', post.grade && 'gradación'].filter(Boolean).join(' · ') : 'ninguno (dibujo directo)';
    const st = controller?.state;
    return {
      worldId,
      gl: wr?.renderer?.getContext?.() || null,
      fps: Math.round(fpsEma),
      p50: at(0.5),
      p95: at(0.95),
      max: at(0.999),
      quality: currentQuality(),
      scale: +(wr?.scale ?? 1).toFixed(2),
      level: curRes?.level || 0,
      capped: !!curRes?.capped,
      thermalDrop,
      batteryDrop,
      info: wr?.info || { calls: 0, triangles: 0, programs: 0 },
      vram: wr ? estimateVram(wr.scene) : { texMB: 0, geoMB: 0, textures: 0, geometries: 0 },
      post: fx,
      failedPatches: wr?.failedPatches || 0,
      pos: st ? [st.x, st.y, st.z] : [0, 0, 0],
      hours: formatHours(hours),
      extra: isShen ? `teselas ${shen?.terrain?.tiles?.size ?? 0} · fase ${shenPhase}` : '',
    };
  }

  const debug = { report, shen: () => shen, worldId, travelTo: (x, z, yaw) => travelTo(x, z, yaw), creatures: () => creatures, net: () => net, remotes: () => remotes, state: () => controller?.state ?? null, playing: () => playing, renderer: () => wr, chunks: () => chunks, controller: () => controller, settings: () => ({ ...cfg, hours }) };
  if (window.rigworld) window.rigworld.world = debug;

  overlayDismiss = layers.pushOverlay(() => finish());
  start();
  return { close, el };
}
