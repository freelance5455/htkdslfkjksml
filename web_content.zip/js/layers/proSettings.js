// Ajustes avanzados unificados: una hoja con pestañas (Calidad · Imagen · Texturas · Mundo · Rendimiento · Diagnóstico).
// Se abre desde los ajustes del hub y desde el engranaje del mundo. Todo se guarda al momento (core/pro.js) y el mundo lo aplica
// al instante cuando está abierto. Los valores «auto» dejan decidir al nivel de calidad elegido.
import { h, icon } from '../ui/dom.js';
import { openSheet, confirmDialog } from '../ui/sheet.js';
import { toast } from '../ui/toast.js';
import { pro, LEVELS_B, levelB, tierCap, PRO_DEFAULTS } from '../core/pro.js';
import { buildReport, copyText, downloadText } from '../core/diag.js';
import { audio } from '../audio/engine.js';
import { myMusic, MY_MAX_TRACKS } from '../audio/music.js';
import { fmtBytes } from '../core/format.js';

const TIER_TXT = { low: 'básica', mid: 'media', high: 'alta' };
const AUTO = ['auto', 'Auto'];

// Descripción corta de un nivel del tipo B.
function levelText(L) {
  const fx = [L.aa === 'taa' ? 'TAA' : L.aa === 'fxaa' ? 'FXAA' : 'MSAA', L.bloom && 'bloom', L.ssao && 'SSAO', L.rays && 'rayos de luz', L.grade && 'gradación', L.sharpen && 'nitidez'].filter(Boolean).join(' · ');
  return `Resolución ${Math.round(L.scale * 100)} % · píxeles ×${L.pr} · sombras ${L.shadow ? L.shadow : 'no'} · vegetación ${L.segments} · ${fx}`;
}

// Combinaciones rápidas: cada una es un conjunto de ajustes. «Fluido» = los de fábrica (el que funciona bien en el móvil).
const PRESETS = [
  ['fluid', 'Fluido (de fábrica)', { mode: 'a', level: 7 }],
  ['balanced', 'Equilibrado', { mode: 'b', level: 10 }],
  ['pretty', 'Bonito', { mode: 'b', level: 15 }],
  ['max', 'Máximo', { mode: 'b', level: 20 }],
];
const LOOKS = [
  ['none', 'Sin efectos', { bloom: 'auto', ssao: 'auto', rays: 'auto', sharpen: 'auto', grain: false, ca: false, grade: 'auto', contrast: 1, sat: 1, vignette: 0, temp: 0, lift: 0, gamma: 1, gain: 1 }],
  ['cine', 'Cinematográfico', { bloom: 'on', bloomStrength: 0.5, grade: 'on', contrast: 1.1, sat: 1.08, vignette: 0.3, temp: 0.12, grain: true, grainAmt: 0.12 }],
  ['sharp', 'Nítido', { aa: 'fxaa', sharpen: 'on', sharpenAmt: 0.5, contrast: 1.05 }],
  ['vivid', 'Vivo', { grade: 'on', sat: 1.25, contrast: 1.1, bloom: 'on', bloomStrength: 0.35 }],
];

export function openProSettings({ layers, profile = null, getReport = () => null, getWorldCfg = () => null, tab = 'quality' }) {
  const painters = [];
  let offMy = null; // suscripción a la lista de música propia (solo mientras se ve la pestaña Audio)
  const paintAll = () => painters.forEach((f) => f());

  // ── Controles ────────────────────────────────────────────────────────────────────────────────────────────────
  const row = (label, hint, ...ctl) =>
    h('div', { class: 'prow' }, h('div', { class: 'prow__head' }, h('span', { class: 'prow__lab' }, label), hint ? h('span', { class: 'prow__hint' }, hint) : null), ...ctl);

  const chips = (key, options, label, hint) => {
    const btns = options.map(([v, t]) => {
      const b = h('button', { class: 'chip-btn', type: 'button', onclick: () => { pro.update({ [key]: key === 'chunkRadius' && v !== 'auto' ? Number(v) : v }); paintAll(); } }, t);
      b.dataset.v = String(v);
      return b;
    });
    painters.push(() => {
      for (const b of btns) b.setAttribute('aria-pressed', String(String(pro.get(key)) === b.dataset.v));
    });
    return row(label, hint, h('div', { class: 'pro__chips' }, btns));
  };

  const range = (key, label, min, max, step, fmt = (v) => v.toFixed(2), hint) => {
    const out = h('output', { class: 'skin__val' });
    const input = h('input', { type: 'range', min, max, step, 'aria-label': label });
    input.addEventListener('input', () => (out.textContent = fmt(Number(input.value))));
    input.addEventListener('change', () => { pro.update({ [key]: Number(input.value) }); paintAll(); });
    painters.push(() => {
      const v = pro.get(key);
      input.value = v;
      out.textContent = fmt(Number(v));
    });
    return h('label', { class: 'skin__row pro__range' }, h('span', { class: 'skin__lab' }, label), input, out, hint ? h('span', { class: 'prow__hint pro__rangehint' }, hint) : null);
  };

  const toggle = (key, label, hint) => {
    const input = h('input', { type: 'checkbox', onchange: () => { pro.update({ [key]: input.checked }); paintAll(); } });
    painters.push(() => (input.checked = !!pro.get(key)));
    return h('label', { class: 'skin__check' }, input, h('span', null, label, hint ? h('small', { class: 'prow__hint' }, ` ${hint}`) : null));
  };

  const note = (text) => h('p', { class: 'hint' }, text);
  const group = (title, ...items) => h('section', { class: 'pro__group' }, h('h3', { class: 'pro__h' }, title), ...items);

  // ── Pestañas ─────────────────────────────────────────────────────────────────────────────────────────────────
  const live = h('p', { class: 'hint pro__live' });
  const levelInfo = h('p', { class: 'hint pro__level' });
  const paintLive = () => {
    const rep = getReport();
    const lvl = pro.get('level');
    levelInfo.textContent = `Nivel ${lvl} · ${levelB(lvl).name}: ${levelText(levelB(lvl))}`;
    levelInfo.hidden = pro.get('mode') !== 'b';
    if (!rep) {
      live.textContent = 'Los cambios se aplican al entrar al mundo; con el mundo abierto se ven al instante.';
      return;
    }
    const bits = [`${rep.worldId.toUpperCase()}`, `${rep.fps} fps`, rep.quality.label];
    if (rep.level) bits.push(`nivel efectivo ${rep.level}${rep.capped ? ' (reducido)' : ''}`);
    if (rep.thermalDrop) bits.push(`térmica −${rep.thermalDrop}`);
    if (rep.batteryDrop) bits.push(`batería −${rep.batteryDrop}`);
    live.textContent = `Ahora: ${bits.join(' · ')}`;
  };
  painters.push(paintLive);

  const typeCard = (id, title, text) => {
    const b = h('button', { class: 'worldpick__card pro__type', type: 'button', onclick: () => { pro.update({ mode: id }); paintAll(); } },
      h('span', { class: 'worldpick__txt' }, h('b', null, title), h('span', null, text)));
    painters.push(() => b.setAttribute('aria-pressed', String(pro.get('mode') === id)));
    return b;
  };

  const tabs = {
    quality: () => [
      group('Tipo de calidad',
        note('Hay dos tipos y puedes cambiar entre ellos cuando quieras; cada uno guarda su forma de decidir.'),
        h('div', { class: 'pro__types' },
          typeCard('a', 'A · RigWorld', 'Baja, Media, Alta y Auto (con gobernador de fotogramas). Es el de fábrica y el más fluido. La calidad concreta se elige en el panel del mundo.'),
          typeCard('b', 'B · EDEN', 'Niveles del 1 al 20: del 11 en adelante cada nivel suma efectos (bloom, SSAO, rayos de luz, TAA…). Se adapta por temperatura y batería.')),
        live),
      group('Nivel del tipo B',
        range('level', 'Nivel', 1, 20, 1, (v) => `${v} · ${levelB(v).name}`),
        levelInfo,
        chips('tierForce', [AUTO, ['low', 'Básica (hasta 10)'], ['mid', 'Media (hasta 16)'], ['high', 'Alta (hasta 20)']], 'Gama máxima',
          `Tu dispositivo se detectó como ${TIER_TXT[profile?.tier] || '—'}: tope ${tierCap(profile?.tier || 'mid')}.`)),
      group('Combinaciones rápidas',
        h('div', { class: 'pro__chips' }, PRESETS.map(([id, t, patch]) => h('button', { class: 'chip-btn', type: 'button', onclick: () => { pro.update(patch); paintAll(); toast(`Calidad: ${t}.`, { kind: 'ok' }); } }, t))),
        note('«Fluido» es la calidad de fábrica (tipo A). Los demás usan el tipo B.')),
    ],
    image: () => [
      group('Aspecto rápido',
        h('div', { class: 'pro__chips' }, LOOKS.map(([id, t, patch]) => h('button', { class: 'chip-btn', type: 'button', onclick: () => { pro.update(patch); paintAll(); } }, t)))),
      group('Imagen',
        chips('aa', [AUTO, ['off', 'Sin'], ['msaa', 'MSAA'], ['fxaa', 'FXAA'], ['taa', 'TAA']], 'Suavizado de bordes', 'MSAA, FXAA y TAA usan la tubería de imagen.'),
        chips('toneMapping', [['ACESFilmic', 'ACES'], ['AgX', 'AgX'], ['Neutral', 'Neutro'], ['Reinhard', 'Reinhard'], ['Linear', 'Lineal']], 'Mapeo de tonos'),
        chips('pixelRatio', [AUTO, ['0.75', '×0,75'], ['1', '×1'], ['1.25', '×1,25'], ['1.5', '×1,5'], ['2', '×2']], 'Resolución (píxeles)'),
        chips('shadows', [AUTO, ['off', 'Sin'], ['low', 'Baja'], ['medium', 'Media'], ['high', 'Alta']], 'Sombras'),
        chips('leaves', [AUTO, ['on', 'Sí'], ['off', 'No']], 'Follaje realista', 'Racimos de hojas sueltas en los árboles y arbustos cercanos y contorno desflecado. Cuesta más en el móvil. Auto: niveles 13+ del tipo B.'),
        chips('shadowMap', [AUTO, ['512', '512'], ['1024', '1024'], ['2048', '2048'], ['4096', '4096']], 'Tamaño de la sombra')),
      group('Efectos',
        chips('bloom', [AUTO, ['on', 'Sí'], ['off', 'No']], 'Bloom (resplandor)'),
        range('bloomStrength', 'Intensidad del bloom', 0, 1.5, 0.05),
        chips('ssao', [AUTO, ['on', 'Sí'], ['off', 'No']], 'Oclusión ambiental (SSAO)'),
        range('ssaoRadius', 'Radio de SSAO', 1, 16, 1, (v) => `${v} m`),
        chips('rays', [AUTO, ['on', 'Sí'], ['off', 'No']], 'Rayos de luz'),
        range('raysAmt', 'Intensidad de los rayos', 0, 1.5, 0.05),
        chips('sharpen', [AUTO, ['on', 'Sí'], ['off', 'No']], 'Nitidez'),
        range('sharpenAmt', 'Cantidad de nitidez', 0, 1.5, 0.05),
        toggle('grain', 'Grano de película'),
        range('grainAmt', 'Cantidad de grano', 0, 1, 0.05),
        toggle('ca', 'Aberración cromática'),
        range('caAmt', 'Cantidad de aberración', 0, 2, 0.05)),
      group('Gradación de color',
        chips('grade', [AUTO, ['on', 'Sí'], ['off', 'No']], 'Gradación'),
        range('lift', 'Sombras (lift)', -0.1, 0.1, 0.005, (v) => v.toFixed(3)),
        range('gamma', 'Gamma', 0.6, 1.6, 0.01),
        range('gain', 'Luces (gain)', 0.6, 1.6, 0.01),
        range('temp', 'Temperatura (frío ↔ cálido)', -1, 1, 0.05),
        range('contrast', 'Contraste', 0.5, 2, 0.01),
        range('sat', 'Saturación', 0, 2, 0.01),
        range('vignette', 'Viñeta', 0, 1, 0.05),
        note('Los efectos de imagen consumen GPU: en el móvil, actívalos de uno en uno y mira los fps. Si el dispositivo no admite buffers de media precisión, se desactivan solos.')),
    ],
    textures: () => [
      group('Resolución de texturas',
        chips('texChar', [AUTO, ['low', '512'], ['medium', '1024'], ['high', '2048'], ['max', '4096']], 'Personaje', 'Tamaño máximo de su textura (al entrar al mundo).'),
        chips('texWorld', [AUTO, ['low', 'Baja'], ['medium', 'Media'], ['high', 'Alta'], ['max', 'Máxima']], 'Mundo SHENLONG', 'Cambia el escalón del terreno; se aplica al volver a entrar.'),
        chips('aniso', [AUTO, ['1', '1×'], ['2', '2×'], ['4', '4×'], ['8', '8×'], ['16', '16×']], 'Filtrado anisotrópico', 'Texturas más nítidas vistas de lado.')),
      group('Texturas propias',
        note('La textura y los materiales del personaje se eligen en el visor B del detalle de cada modelo (botones A | B) y se ven también en el mundo.')),
    ],
    world: () => [
      group('Tiempo',
        chips('dayMinutes', [AUTO, ['5', '5 min'], ['15', '15 min'], ['60', '1 h'], ['360', '6 h'], ['1440', '24 h']], 'Duración del día', 'Auto usa «Paso del tiempo» del panel del mundo.')),
      group('EDEN',
        chips('vegetation', [AUTO, ['none', 'Sin'], ['low', 'Poca'], ['medium', 'Media'], ['high', 'Mucha']], 'Vegetación'),
        chips('chunkRadius', [AUTO, ['3', '3'], ['5', '5'], ['7', '7'], ['9', '9']], 'Distancia de visión', 'Trozos de 64 m alrededor del personaje.')),
      group('SHENLONG', note('Las criaturas, la flora y los dragones se activan desde el panel del mundo. El escalón de calidad de SHENLONG sale del nivel (tipo B) o de «Texturas».')),
    ],
    audio: () => {
      const list = h('div', { class: 'pro__tracks' });
      const paintTracks = () => {
        list.replaceChildren(
          ...(myMusic.tracks.length
            ? myMusic.tracks.map((t, i) =>
                h('div', { class: 'pro__track' },
                  h('span', { class: 'pro__trackname' }, `${i === myMusic.current && myMusic.playing ? '▶ ' : ''}${t.name}`, h('small', { class: 'prow__hint' }, ` ${fmtBytes(t.size)}`)),
                  h('button', { class: 'chip-btn', type: 'button', 'aria-label': `Reproducir ${t.name}`, onclick: () => { audio.start(); myMusic.play(i); } }, 'Reproducir'),
                  h('button', { class: 'chip-btn', type: 'button', 'aria-label': `Quitar ${t.name}`, onclick: () => myMusic.remove(t.id) }, icon('trash', 18))))
            : [h('p', { class: 'hint' }, 'Todavía no hay canciones. Se guardan solo en este dispositivo.')]),
        );
      };
      offMy?.();
      offMy = myMusic.onChange(paintTracks);
      paintTracks();
      const fileInput = h('input', { type: 'file', accept: 'audio/*,.mp3,.m4a,.aac,.ogg,.opus,.wav,.flac', multiple: true, hidden: true });
      fileInput.addEventListener('change', async () => {
        for (const f of fileInput.files) {
          try {
            await myMusic.add(f);
            toast(`Añadida: ${f.name}`, { kind: 'ok' });
          } catch (err) {
            toast(err.message || 'No se pudo añadir esa canción.', { kind: 'error' });
          }
        }
        fileInput.value = '';
      });
      return [
        group('Volumen',
          range('master', 'General', 0, 1, 0.05, (v) => `${Math.round(v * 100)} %`),
          toggle('musicOn', 'Música'),
          range('music', 'Volumen de la música', 0, 1, 0.05, (v) => `${Math.round(v * 100)} %`),
          toggle('sfxOn', 'Efectos (ambiente, pasos y criaturas)'),
          range('sfx', 'Volumen de los efectos', 0, 1, 0.05, (v) => `${Math.round(v * 100)} %`),
          note('El navegador solo deja sonar después de tocar la pantalla. Con la app en segundo plano el audio se pausa (Rendimiento).')),
        group('Ambiente del mundo',
          toggle('ambient', 'Sonido ambiente'),
          toggle('windOn', 'Viento', 'más fuerte en lo alto'),
          toggle('stepsOn', 'Pasos', 'según el suelo'),
          toggle('birdsOn', 'Pájaros', 'de día, en bosques y praderas'),
          toggle('splashOn', 'Chapoteo al entrar al agua')),
        group('Música china',
          note('Música generativa en escala pentatónica; nunca se repite igual.'),
          toggle('chinese', 'Activar música china'),
          range('chineseVol', 'Volumen', 0, 1, 0.05, (v) => `${Math.round(v * 100)} %`),
          toggle('guzheng', 'Guzheng'),
          toggle('pipa', 'Pipa'),
          toggle('harp', 'Arpa')),
        group('Mi música',
          note(`Añade tus canciones (hasta ${MY_MAX_TRACKS}, 40 MB cada una). Mientras suena una, la música china se calla.`),
          h('div', { class: 'viewer-tools' },
            h('button', { class: 'chip-btn', type: 'button', onclick: () => fileInput.click() }, icon('upload', 18), 'Añadir canciones'),
            h('button', { class: 'chip-btn', type: 'button', onclick: () => myMusic.next() }, 'Siguiente'),
            h('button', { class: 'chip-btn', type: 'button', onclick: () => myMusic.stop() }, 'Parar')),
          fileInput,
          list),
      ];
    },
    perf: () => [
      group('Rendimiento',
        chips('fpsTarget', [AUTO, ['30', '30'], ['45', '45'], ['60', '60']], 'Fotogramas por segundo', 'Con 30 el móvil se calienta menos y gasta menos batería.'),
        toggle('thermal', 'Gobernador térmico (tipo B)', 'baja el nivel si los fotogramas se alargan.'),
        toggle('battery', 'Ahorro de batería (tipo B)', 'baja 2 niveles con menos del 20 % y sin cargar.'),
        toggle('warmup', 'Precompilar sombreadores al entrar', 'evita tirones al ver cosas nuevas.')),
      group('Restablecer',
        h('button', { class: 'chip-btn', type: 'button', onclick: async () => {
          if (await confirmDialog({ title: 'Restablecer ajustes avanzados', message: 'Vuelven los valores de fábrica (calidad tipo A, sin efectos). No se toca nada más.', confirmLabel: 'Restablecer', layers })) {
            pro.reset();
            paintAll();
            toast('Ajustes avanzados restablecidos.', { kind: 'ok' });
          }
        } }, icon('refresh', 18), 'Restablecer todo')),
    ],
    diag: () => {
      const pre = h('pre', { class: 'diag' }, 'Pulsa «Generar informe».');
      let text = '';
      const make = () => {
        text = buildReport({ profile, world: getReport(), worldCfg: getWorldCfg() });
        pre.textContent = text;
      };
      return [
        group('Informe de diagnóstico',
          note('Reúne el dispositivo, la GPU, los ajustes, los fotogramas, la memoria y los últimos avisos y errores. No incluye nombres de archivos ni el contenido de tus modelos. Con el mundo abierto trae más datos.'),
          h('div', { class: 'viewer-tools' },
            h('button', { class: 'chip-btn', type: 'button', onclick: make }, icon('refresh', 18), 'Generar informe'),
            h('button', { class: 'chip-btn', type: 'button', onclick: async () => { if (!text) make(); toast((await copyText(text)) ? 'Informe copiado.' : 'No se pudo copiar: usa «Descargar».', { kind: 'ok' }); } }, 'Copiar'),
            h('button', { class: 'chip-btn', type: 'button', onclick: () => { if (!text) make(); downloadText(text); } }, 'Descargar .txt'),
            navigator.share ? h('button', { class: 'chip-btn', type: 'button', onclick: () => { if (!text) make(); navigator.share({ title: 'Informe de RigWorld 3D', text }).catch(() => {}); } }, 'Compartir') : null),
          pre),
      ];
    },
  };
  const TABS = [['quality', 'Calidad'], ['image', 'Imagen'], ['textures', 'Texturas'], ['world', 'Mundo'], ['audio', 'Audio'], ['perf', 'Rendimiento'], ['diag', 'Diagnóstico']];

  const panelEl = h('div', { class: 'pro__panel', role: 'tabpanel' });
  const tabBtns = TABS.map(([id, t]) => {
    const b = h('button', { class: 'protab', type: 'button', role: 'tab', onclick: () => show(id) }, t);
    b.dataset.tab = id;
    return b;
  });
  function show(id) {
    offMy?.();
    offMy = null;
    painters.length = 0;
    painters.push(paintLive);
    panelEl.replaceChildren(...tabs[id]().flat());
    for (const b of tabBtns) b.setAttribute('aria-selected', String(b.dataset.tab === id));
    paintAll();
    panelEl.scrollTop = 0;
  }
  const body = h('div', { class: 'pro' }, h('div', { class: 'protabs', role: 'tablist' }, tabBtns), panelEl);
  show(tab);

  return openSheet({ title: 'Ajustes avanzados', body, layers, tall: true, onClose: () => offMy?.() });
}
