// Selector de mundo: al pulsar «Mundo» o «Entrar al mundo» se elige a cuál ir. Devuelve 'eden', 'shenlong' o null (si se cierra).
import { h, icon } from '../ui/dom.js';
import { openSheet } from '../ui/sheet.js';

export const WORLDS = Object.freeze([
  {
    id: 'eden',
    name: 'EDEN',
    tag: 'Mundo realista',
    text: 'El mundo de RigWorld: terreno infinito con cielo, Sol, nubes, sombras, agua, bosques y criaturas del zoológico místico.',
  },
  {
    id: 'shenlong',
    name: 'SHENLONG',
    tag: 'Mundo de los dragones',
    text: 'Montañas colosales, lagos de hielo, agua y lava, y siete dragones a escala gigante. Aquí se puede volar y viajar rápido.',
  },
]);

const LAST_KEY = 'rigworld.lastWorld';
const readLast = () => {
  try {
    return localStorage.getItem(LAST_KEY);
  } catch {
    return null;
  }
};
const writeLast = (id) => {
  try {
    localStorage.setItem(LAST_KEY, id);
  } catch {
    /* sin almacenamiento */
  }
};

export function pickWorld({ layers }) {
  return new Promise((resolve) => {
    let chosen = null;
    const last = readLast();
    const body = h('div', { class: 'worldpick' }, WORLDS.map((w) => h('button', {
      class: `worldpick__card worldpick__card--${w.id}${w.id === last ? ' is-last' : ''}`,
      type: 'button',
      onclick: () => {
        chosen = w.id;
        writeLast(w.id);
        sheet.close();
      },
    },
    h('span', { class: 'worldpick__ico', 'aria-hidden': 'true' }, icon(w.id === 'eden' ? 'globe' : 'wing', 26)),
    h('span', { class: 'worldpick__txt' }, h('b', null, w.name), h('i', null, w.tag), h('span', null, w.text)),
    )));
    const sheet = openSheet({ title: '¿A qué mundo quieres ir?', body, layers, onClose: () => resolve(chosen) });
  });
}
