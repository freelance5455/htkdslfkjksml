// Pantalla «Criaturas»: galería del zoológico místico (35 criaturas generadas por código) con filtros, ficha y visor 3D.
// Se abre desde el hub como una superposición; Atrás (o «Regresar») cierra primero la ficha y después la galería.
import { h, icon, clear } from '../ui/dom.js';
import { toast } from '../ui/toast.js';
import { loadThree } from '../core/threeLoader.js';
import { ZOO_RANKS, ZOO_CATS, ZOO_SOCIAL, ZOO_STATES } from '../zoo/meta.js';

const bar = (v, color) => h('div', { class: 'zoo__bar2' }, h('i', { style: { width: `${v * 10}%`, background: color } }));
const sizeWord = (s) => (s >= 3 ? 'colosal' : s >= 1.5 ? 'grande' : s >= 0.9 ? 'mediano' : 'pequeño');

export function openZoo({ layers, root = document.getElementById('app'), onClose = null }) {
  let closed = false;
  let zoo = null, THREE = null, mods = null;
  let thumbs = null;
  let cat = 'todos', rank = 'todos';
  let detail = null; // { viewer, dismiss }
  let dismissMain = null;
  let thumbRun = 0;
  const queue = [];
  let queueBusy = false;
  let observer = null;

  // ── Interfaz ─────────────────────────────────────────────────────────────────────────────────
  const backBtn = h('button', { class: 'zoo__back', type: 'button', onclick: () => dismissMain?.() }, '‹ Regresar');
  const sub = h('small', null, 'Preparando criaturas…');
  const head = h('header', { class: 'zoo__head' }, backBtn, h('div', { class: 'zoo__title' }, 'Criaturas', sub));
  const catBar = h('div', { class: 'zoo__chips', role: 'tablist', 'aria-label': 'Categorías' });
  const rankBar = h('div', { class: 'zoo__chips', 'aria-label': 'Rangos' });
  const grid = h('div', { class: 'zoo__grid' });
  const note = h('p', { class: 'zoo__note' }, 'Las criaturas se crean por código cuando aparecen en pantalla; la primera vez cada una tarda unos segundos.');
  const detailEl = h('div', { class: 'zoo__detail', hidden: true });
  const el = h('section', { class: 'zoo', 'aria-label': 'Criaturas' }, head, catBar, rankBar, grid, note, detailEl);
  root.append(el);
  requestAnimationFrame(() => el.classList.add('is-open'));

  // ── Filtros y rejilla ────────────────────────────────────────────────────────────────────────
  function renderBars() {
    const cats = [['todos', '🌍 Todos'], ...Object.keys(ZOO_CATS).map((k) => [k, `${ZOO_CATS[k].i} ${ZOO_CATS[k].n}`])];
    const ranks = [['todos', 'Todos los rangos'], ...Object.keys(ZOO_RANKS).map((k) => [k, ZOO_RANKS[k].n])];
    clear(catBar);
    clear(rankBar);
    cats.forEach(([k, n]) => catBar.append(h('button', { class: `zoo__chip${cat === k ? ' is-on' : ''}`, type: 'button', onclick: () => { cat = k; renderBars(); renderGrid(); } }, n)));
    ranks.forEach(([k, n]) => rankBar.append(h('button', { class: `zoo__chip${rank === k ? ' is-on' : ''}`, type: 'button', style: k !== 'todos' ? { borderColor: ZOO_RANKS[k].c } : null, onclick: () => { rank = k; renderBars(); renderGrid(); } }, n)));
  }

  function renderGrid() {
    thumbRun++;
    queue.length = 0;
    observer?.disconnect();
    const all = zoo.list();
    const list = all.filter((sp) => (cat === 'todos' || sp.cat === cat) && (rank === 'todos' || sp.rank === rank));
    sub.textContent = `${list.length} de ${all.length} criaturas`;
    clear(grid);
    list.forEach((sp) => {
      const R = ZOO_RANKS[sp.rank];
      const th = h('div', { class: 'zoo__th', dataset: { id: sp.id } }, h('span', { class: 'zoo__em' }, ZOO_CATS[sp.cat].i), h('span', { class: 'zoo__tag' }, R.n.toUpperCase()));
      if (zoo.thumbs[sp.id]) paintThumb(th, sp.id);
      grid.append(
        h('button', { class: 'zoo__card', type: 'button', style: `--rc:${R.c}`, 'aria-label': sp.name, onclick: () => showDetail(sp.id) }, th, h('div', { class: 'zoo__nm' }, sp.name), h('div', { class: 'zoo__st' }, h('div', null, `Inteligencia ${sp.int}`), bar(sp.int, R.c), h('div', null, `Poder ${sp.pow}`), bar(sp.pow, R.c))),
      );
    });
    if (!list.length) grid.append(h('p', { class: 'zoo__empty' }, 'No hay criaturas con ese filtro.'));
    // Miniaturas: solo de las tarjetas que se ven (cada criatura se construye en el hilo principal).
    observer = new IntersectionObserver((entries) => {
      for (const e of entries) {
        if (!e.isIntersecting) continue;
        observer.unobserve(e.target);
        const id = e.target.dataset.id;
        if (!zoo.thumbs[id]) queue.push({ id, th: e.target, run: thumbRun });
      }
      pumpThumbs();
    }, { root: grid, rootMargin: '120px' });
    grid.querySelectorAll('.zoo__th').forEach((t) => { if (!zoo.thumbs[t.dataset.id]) observer.observe(t); });
  }

  function paintThumb(th, id) {
    th.style.backgroundImage = `url(${zoo.thumbs[id]})`;
    th.querySelector('.zoo__em')?.remove();
  }

  async function pumpThumbs() {
    if (queueBusy || detail) return;
    queueBusy = true;
    try {
      while (queue.length && !closed && !detail) {
        const j = queue.shift();
        if (j.run !== thumbRun || !j.th.isConnected) continue;
        try {
          await thumbs.make(j.id);
          if (j.th.isConnected) paintThumb(j.th, j.id);
        } catch (err) {
          console.warn('[zoo] miniatura', j.id, err);
        }
        await new Promise((r) => setTimeout(r, 30)); // deja respirar a la interfaz entre criaturas
      }
    } finally { queueBusy = false; }
  }

  // ── Ficha de una criatura ────────────────────────────────────────────────────────────────────
  async function showDetail(id) {
    if (detail) return;
    const sp = zoo.SP[id];
    const R = ZOO_RANKS[sp.rank];
    const canvas = h('canvas', { class: 'zoo__canvas', role: 'img', 'aria-label': `Vista 3D: ${sp.name}` });
    const status = h('div', { class: 'zoo__status' }, 'Construyendo criatura…');
    let stateNow = 'idle';
    let skelMode = 0;
    const stBtns = {};
    const stRow = h('div', { class: 'zoo__btns' });
    const setState = (s) => {
      stateNow = s;
      detail?.viewer.setState(s);
      for (const k in stBtns) stBtns[k].classList.toggle('is-on', k === s);
    };
    mods.statesFor(sp).forEach((s) => {
      stBtns[s] = h('button', { class: s === 'idle' ? 'is-on' : '', type: 'button', onclick: () => setState(s) }, ZOO_STATES[s] || s);
      stRow.append(stBtns[s]);
    });
    const skBtn = h('button', { type: 'button', onclick: () => {
      skelMode = (skelMode + 1) % 3;
      detail?.viewer.setSkel(skelMode);
      skBtn.textContent = ['🦴 Esqueleto: apagado', '🦴 Cuerpo + huesos', '🦴 Solo huesos'][skelMode];
    } }, '🦴 Esqueleto: apagado');
    const voiceBtn = sp.sound
      ? h('button', { type: 'button', onclick: () => {
        if (!mods.zooAudioStart()) return toast('Este navegador no permite reproducir sonidos.', { kind: 'info' });
        const size = sp.size || 1;
        mods.ZooSound.play(sp.sound, 0.7, 0, Math.min(1.6, Math.max(0.55, 1.25 - Math.log10(size + 1) * 0.5)));
      } }, '🔊 Voz')
      : null;
    const kv = (t) => h('div', { class: 'zoo__kv' }, t);
    const row = (label, v, color) => h('div', { class: 'zoo__row' }, h('b', null, label), bar(v, color), h('span', null, v));
    const side = h('div', { class: 'zoo__side', style: `--rc:${R.c}` },
      h('h2', null, sp.name),
      h('span', { class: 'zoo__rk' }, `${R.n.toUpperCase()} · ${ZOO_CATS[sp.cat].n}`),
      h('p', null, sp.desc || ''),
      row('Inteligencia', sp.int, '#6ec1ff'), row('Poder', sp.pow, '#ff7a59'), row('Velocidad', sp.spd, '#7be08a'),
      kv(`📍 Hábitat: ${sp.hab}`), kv(`🍃 Dieta: ${sp.diet}`), kv(`🧭 Carácter: ${ZOO_SOCIAL[sp.social] || '—'}`), kv(`📏 Tamaño aprox.: ${sizeWord(sp.size || 1)}`),
      h('div', { class: 'zoo__sec' }, 'Movimientos'), stRow,
      h('div', { class: 'zoo__btns zoo__btns--gap' }, skBtn, voiceBtn),
    );
    const back = h('button', { class: 'zoo__back zoo__back--over', type: 'button', onclick: () => detail?.dismiss() }, '‹ Regresar');
    const view = h('div', { class: 'zoo__view' }, canvas, back, status);
    clear(detailEl);
    detailEl.append(h('div', { class: 'zoo__main' }, view, side));
    detailEl.hidden = false;
    detail = { viewer: null, dismiss: null };
    detail.dismiss = layers.pushOverlay(() => closeDetail());
    try {
      const viewer = mods.createCreatureViewer({ THREE, zoo, canvas, id, state: stateNow, onError: (e) => console.warn('[zoo] visor', e) });
      detail.viewer = viewer;
      const ok = await viewer.ready;
      if (ok) {
        status.textContent = 'Arrastra para girar · pellizca para acercar';
        setTimeout(() => { status.style.opacity = '0'; }, 3500);
      }
    } catch (err) {
      console.warn('[zoo] no se pudo mostrar', id, err);
      status.textContent = `No se pudo mostrar la criatura: ${err?.message || err}`;
    }
  }

  function closeDetail() {
    if (!detail) return;
    try { detail.viewer?.dispose(); } catch {}
    detail = null;
    detailEl.hidden = true;
    clear(detailEl);
    pumpThumbs();
  }

  // ── Cierre ───────────────────────────────────────────────────────────────────────────────────
  function finish() {
    if (closed) return;
    closed = true;
    closeDetail();
    observer?.disconnect();
    queue.length = 0;
    try { thumbs?.dispose(); } catch {}
    el.classList.remove('is-open');
    setTimeout(() => el.remove(), 320);
    onClose?.();
  }
  dismissMain = layers.pushOverlay(() => finish());

  // ── Arranque: Three.js y el zoológico se cargan solo al abrir esta pantalla ────────────────────
  (async () => {
    try {
      THREE = await loadThree();
      mods = {
        ...(await import('../zoo/zoo.js')),
        ...(await import('../zoo/viewer.js')),
        ...(await import('../zoo/sound.js')),
      };
      if (closed) return;
      zoo = mods.createZoo(THREE, { log: (lvl, sys, e) => console.warn(`[${sys}]`, e) });
      thumbs = mods.createThumbMaker({ THREE, zoo });
      renderBars();
      renderGrid();
    } catch (err) {
      console.error('[zoo] no se pudo abrir', err);
      toast('No se pudieron cargar las criaturas.', { kind: 'error' });
      dismissMain?.();
    }
  })();

  const debug = { zoo: () => zoo, count: () => grid.querySelectorAll('.zoo__card').length };
  if (window.rigworld) window.rigworld.zoo = debug;
  return { close: () => dismissMain?.(), el };
}
