// Panel «Multijugador por Wi‑Fi»: crear una partida e invitar (código o QR), unirse a una partida y ver quién está conectado.
// Todo el intercambio de códigos es manual y local: no hay servidor. Ver js/net/ para el funcionamiento.
import { h, icon, clear } from '../ui/dom.js';
import { toast } from '../ui/toast.js';
import { openSheet } from '../ui/sheet.js';
import { ensureNet, netSupported } from '../net/index.js';
import { MAX_PLAYERS } from '../net/session.js';
import { drawQr } from '../net/qr.js';
import { canScan, scanQr } from '../net/scan.js';

const WORLD_NAME = { eden: 'EDEN', shen: 'SHENLONG', '': 'en el menú' };
const msg = (e) => e?.message || String(e);

// onSession(net): el mundo se engancha a la sesión (jugadores remotos, mundo actual).
export function openNetSheet({ layers, name, onSession }) {
  if (!netSupported()) {
    toast('Este navegador no permite conexiones directas entre teléfonos.', { kind: 'error' });
    return null;
  }
  const net = ensureNet(name);
  onSession?.(net);
  const body = h('div', { class: 'net' });
  let view = 'home'; // home | host | join
  let flow = null; // invitación o unión en curso
  let status = { text: '', kind: '' };
  let scan = null;
  let sheet = null;
  let nameInput = null;

  const setStatus = (text, kind = '') => {
    status = { text, kind };
    const el = body.querySelector('.net__status');
    if (el) {
      el.textContent = text;
      el.dataset.kind = kind;
    }
  };
  const statusEl = () => h('p', { class: 'net__status', role: 'status', 'data-kind': status.kind }, status.text);
  const stopScan = () => {
    scan?.stop();
    scan = null;
  };
  const back = () => {
    stopScan();
    flow?.cancel?.();
    flow = null;
    view = 'home';
    setStatus('');
    render();
  };

  const copy = async (area) => {
    try {
      await navigator.clipboard.writeText(area.value);
    } catch {
      area.select();
      document.execCommand?.('copy');
    }
    toast('Código copiado.');
  };

  // Caja con el código: QR + texto + copiar.
  const codeBox = (code, caption) => {
    const area = h('textarea', { class: 'net__code mono', readonly: true, rows: 4, 'aria-label': caption, onfocus: () => area.select() }, code);
    const qr = h('canvas', { class: 'net__qr', role: 'img', 'aria-label': 'Código QR de emparejamiento' });
    let hasQr = true;
    try {
      drawQr(qr, code, 300);
    } catch {
      hasQr = false;
    }
    return h('div', { class: 'net__box' },
      h('p', { class: 'studio__label' }, caption),
      hasQr ? qr : null,
      area,
      h('button', { class: 'btn btn--ghost btn--small', type: 'button', onclick: () => copy(area) }, icon('copy', 16), 'Copiar código'),
    );
  };

  // Entrada de código: texto pegado o cámara.
  const codeInput = (label, onSubmit, submitText) => {
    const area = h('textarea', { class: 'net__code mono', rows: 4, placeholder: 'RW1.…', spellcheck: 'false', autocapitalize: 'off', autocomplete: 'off', 'aria-label': label });
    const video = h('video', { class: 'net__video', muted: true, playsinline: true, hidden: true });
    const scanBtn = canScan()
      ? h('button', { class: 'btn btn--ghost btn--small', type: 'button', onclick: async () => {
          if (scan) return stopScan(), (video.hidden = true);
          video.hidden = false;
          scan = scanQr(video);
          setStatus('Apunta la cámara al QR del otro teléfono…');
          try {
            const text = await scan.done;
            if (text) {
              area.value = text;
              setStatus('QR leído.', 'ok');
              onSubmit(text);
            }
          } catch (e) {
            setStatus(e?.name === 'NotAllowedError' ? 'No hay permiso para la cámara. Pega el código como texto.' : 'No se pudo usar la cámara. Pega el código como texto.', 'error');
          } finally {
            stopScan();
            video.hidden = true;
          }
        } }, icon('camera', 16), 'Escanear QR')
      : null;
    return h('div', { class: 'net__box' },
      h('p', { class: 'studio__label' }, label),
      video,
      area,
      h('div', { class: 'world__btnrow' }, scanBtn, h('button', { class: 'btn btn--primary btn--small', type: 'button', onclick: () => onSubmit(area.value) }, submitText)),
    );
  };

  const startHost = async () => {
    view = 'host';
    setStatus('Preparando la invitación…');
    render();
    try {
      flow = await net.invite();
      const f = flow;
      f.opened.then((p) => {
        if (flow !== f) return;
        flow = null;
        view = 'home';
        setStatus('');
        toast(`${p.name} se unió a la partida.`, { kind: 'ok' });
        render();
      }, (e) => {
        if (flow !== f) return;
        setStatus(msg(e), 'error');
      });
      setStatus('');
      render();
    } catch (e) {
      view = 'home';
      setStatus(msg(e), 'error');
      render();
    }
  };

  const submitAnswer = async (text) => {
    if (!flow?.finish) return;
    try {
      setStatus('Conectando…');
      stopScan();
      await flow.finish(text);
    } catch (e) {
      setStatus(msg(e), 'error');
    }
  };

  const submitJoin = async (text) => {
    if (flow) return;
    try {
      setStatus('Leyendo el código…');
      const f = await net.join(text);
      flow = f;
      setStatus('Enséñale este código al anfitrión y espera a que lo introduzca.');
      render();
      f.opened.then(() => {
        if (flow !== f) return;
        flow = null;
        view = 'home';
        setStatus('');
        toast('Conectado a la partida.', { kind: 'ok' });
        render();
      }, (e) => {
        if (flow !== f) return;
        flow = null;
        setStatus(msg(e), 'error');
        view = 'join';
        render();
      });
    } catch (e) {
      setStatus(msg(e), 'error');
    }
  };

  const playersList = () => {
    const rows = [{ ...net.me(), me: true }, ...net.list()];
    return h('ul', { class: 'net__players' }, rows.map((p) => h('li', null,
      h('i', { class: 'net__dot', style: `background:hsl(${p.hue} 70% 55%)` }),
      h('span', { class: 'net__pname' }, p.name, p.me ? ' (tú)' : ''),
      h('span', { class: 'net__pw' }, WORLD_NAME[p.w] || ''),
    )));
  };

  function render() {
    clear(body);
    if (view === 'host') {
      body.append(
        h('p', { class: 'hint' }, 'Los dos teléfonos deben estar en la misma red Wi‑Fi (vale el punto de acceso de uno de ellos). Paso 1: que el otro lea tu código. Paso 2: introduce su respuesta aquí.'),
        flow?.code ? codeBox(flow.code, '1 · Tu código de invitación') : h('p', { class: 'hint' }, 'Preparando…'),
        flow?.code ? codeInput('2 · Respuesta del otro teléfono', submitAnswer, 'Conectar') : null,
        statusEl(),
        h('button', { class: 'btn btn--ghost', type: 'button', onclick: back }, 'Cancelar'),
      );
    } else if (view === 'join') {
      body.append(
        h('p', { class: 'hint' }, 'Pide al anfitrión que abra «Crear partida» y lee su código (o pégalo). Tu respuesta aparecerá aquí para que él la introduzca.'),
        flow?.code ? codeBox(flow.code, 'Tu código de respuesta (para el anfitrión)') : codeInput('Código del anfitrión', submitJoin, 'Unirme'),
        statusEl(),
        h('button', { class: 'btn btn--ghost', type: 'button', onclick: back }, 'Cancelar'),
      );
    } else if (net.active) {
      const canInvite = net.mode === 'host' && net.count < MAX_PLAYERS;
      body.append(
        h('p', { class: 'studio__label' }, `Jugadores (${net.count}/${MAX_PLAYERS})`),
        playersList(),
        h('p', { class: 'hint' }, net.mode === 'host' ? 'Eres el anfitrión. Si sales, la partida se cierra para todos.' : 'Solo se ve a los demás cuando están en el mismo mundo que tú. Los jugadores aparecen como figuras sencillas con su nombre.'),
        statusEl(),
        h('div', { class: 'world__btnrow' },
          canInvite ? h('button', { class: 'btn btn--primary', type: 'button', onclick: startHost }, icon('plus', 18), 'Invitar a otra persona') : null,
          h('button', { class: 'btn btn--ghost', type: 'button', onclick: () => { net.leave(); setStatus(''); render(); toast('Saliste de la partida.'); } }, icon('close', 18), 'Salir de la partida'),
        ),
      );
    } else {
      nameInput = h('input', { class: 'field__input', type: 'text', maxlength: 16, value: net.name, 'aria-label': 'Tu nombre en la partida', autocomplete: 'off' });
      const applyName = () => {
        const v = nameInput.value.trim().slice(0, 16);
        if (v) net.name = v;
      };
      body.append(
        h('p', { class: 'hint' }, `Juega con hasta ${MAX_PLAYERS - 1} amigos que estén en la misma red Wi‑Fi. No necesita internet ni cuentas: os intercambiáis un código corto (o un QR) una sola vez.`),
        h('label', { class: 'field__label', for: 'net-name' }, 'Tu nombre'),
        Object.assign(nameInput, { id: 'net-name' }),
        statusEl(),
        h('div', { class: 'world__btnrow' },
          h('button', { class: 'btn btn--primary', type: 'button', onclick: () => { applyName(); startHost(); } }, icon('wifi', 18), 'Crear partida e invitar'),
          h('button', { class: 'btn btn--ghost', type: 'button', onclick: () => { applyName(); view = 'join'; setStatus(''); render(); } }, 'Unirme a una partida'),
        ),
      );
    }
  }

  const off = net.on((kind, reason) => {
    if (kind === 'end' && reason) {
      flow = null;
      view = 'home';
      setStatus(reason, 'error');
    }
    if (view === 'home' || kind === 'end') render();
  });
  render();
  sheet = openSheet({ title: 'Multijugador por Wi‑Fi', body, layers, tall: true, onClose: () => {
    off();
    stopScan();
    if (flow) {
      flow.cancel?.();
      flow = null;
    }
  } });
  return sheet;
}
