/* simulation.js — game state, calendar, daily/monthly economy-lite tick, time controls. */
(function (G) {
  'use strict';

  const DIM = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  G.MONTHS = MONTHS;
  G.SPEEDS = [1, 2, 4, 8, 16];            // speed levels -> days per second
  G.VERSION = '10.0.0';

  function daysIn(m, y) { return m === 1 && (y % 4 === 0) ? 29 : DIM[m]; }

  G.newGame = function (playerId, scenarioId, opts) {
    G.useScenario(scenarioId || G.scenarioId || 'empires');
    const provinces = G.buildWorld();
    G.scenario.count = provinces.length;
    const countries = {};
    for (const id in G.COUNTRIES) {
      const c = G.COUNTRIES[id];
      countries[id] = {
        treasury: c.treasury, manpower: c.manpower,
        res: Object.assign({}, c.res),
        dIncome: 0, dManpower: 0, dRes: { steel: 0, coal: 0, oil: 0, food: 0 }
      };
    }
    const st = {
      version: G.VERSION, player: playerId || null,
      date: { y: G.scenario.startYear || 1936, m: 0, d: 1 }, day: 0, scenario: G.scenarioId,
      paused: true, speedIdx: 1, acc: 0,
      owners: provinces.map(p => p.owner),       // mutable ownership (conquest-ready)
      countries: countries, log: []
    };
    G.provinces = provinces;
    G.state = st;
    G.recompute();
    G.initMilitary(st, true);
    G.initWar(st);
    G.initEconomy(st, true);
    G.initDiplomacy(st, true);
    G.initIntel(st, true);
    G.initTech(st, true);
    G.initAI(st, true);
    G.initNaval(st, true);
    G.initCampaign && G.initCampaign(st, true, opts && opts.mode);
    G.initEvents && G.initEvents(st, true);
    return st;
  };

  // Rebuild derived per-country daily rates from current ownership.
  G.recompute = function () {
    const st = G.state;
    for (const id in st.countries) {
      const c = st.countries[id];
      c.dIncome = 0; c.dManpower = 0; c.provCount = 0;
      c.dRes = {}; G.RESOURCES.forEach(r => { c.dRes[r] = 0; });
    }
    G.provinces.forEach((p, i) => {
      const o = st.owners[i];
      if (!o || p.sea) return;
      const c = st.countries[o];
      c.provCount++;
      c.dIncome += p.income * 0.5;
      c.dManpower += p.manpower / 30;
      const farm = (st.pb && st.pb[i]) ? (st.pb[i].farm || 0) : 0;
      for (const r of G.RESOURCES) c.dRes[r] += ((p.res[r] || 0) + (r === 'food' ? 2 * farm : 0)) * (r === 'food' ? 0.7 : 0.4); // per day
    });
    for (const id in st.countries) {
      const c = st.countries[id];
      c.dManpower *= G.techMult(id, 'manpower');
      c.dRes.food *= G.techMult(id, 'food');
      for (const r of G.RESOURCES) if (r !== 'food') c.dRes[r] *= G.techMult(id, 'resources') * ((r === 'steel' || r === 'coal') ? G.techMult(id, 'mining') : 1);
    }
    G.refreshBudget && G.refreshBudget();
  };

  G.dateString = function (d) {
    d = d || G.state.date;
    return d.d + ' ' + MONTHS[d.m] + ' ' + d.y;
  };

  G.logMsg = function (t) {
    const st = G.state;
    st.log.unshift(G.dateString() + ' — ' + t);
    if (st.log.length > 40) st.log.length = 40;
  };

  // Advance exactly one game day.
  G.tickDay = function () {
    const st = G.state;
    G.economyDay();
    for (const id in st.countries) {
      const c = st.countries[id];
      if (c.dead) continue;
      c.treasury += c.dIncome > 0 ? c.dIncome * G.effectMult(id, 'income') * G.aiIncomeMult(id) : c.dIncome;
      c.manpower += c.dManpower * (c.starving ? 0.5 : 1) * G.effectMult(id, 'manpower');
      for (const r of G.RESOURCES) c.res[r] += c.dRes[r];
    }
    G.militaryDay();
    G.navalDay && G.navalDay();
    G.warDay();
    st.day++;
    const dt = st.date;
    dt.d++;
    if (dt.d > daysIn(dt.m, dt.y)) {
      dt.d = 1; dt.m++;
      if (dt.m > 11) { dt.m = 0; dt.y++; }
      G.onMonth && G.onMonth();
    }
  };

  // Monthly: trade capacity resets, horses breed.
  G.onMonth = function () {
    G.economyMonth();
    G.diplomacyMonth && G.diplomacyMonth();
    G.eventsMonth && G.eventsMonth();
    G.campaignMonth && G.campaignMonth();
  };

  // Real-time driver: dt in seconds.
  G.update = function (dt) {
    const st = G.state;
    if (!st || st.paused) return 0;
    st.acc += dt * G.SPEEDS[st.speedIdx];
    let n = 0;
    while (st.acc >= 1 && n < 40) { st.acc -= 1; G.tickDay(); n++; }
    return n;
  };

  G.setPaused = function (v) { G.state.paused = !!v; };
  G.setSpeed = function (i) { G.state.speedIdx = Math.max(0, Math.min(G.SPEEDS.length - 1, i)); };
})(window.EMP = window.EMP || {});
