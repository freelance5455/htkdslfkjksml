/* Input: swipe (satu gesture = satu belok), D-pad (pointer + keyboard-activation), keyboard. Gamepad: Fase 2. */
(function (g) {
  'use strict';
  const SU = g.SU, C = SU.config, $ = SU.util.$;
  const DIR = { up: [0, -1], down: [0, 1], left: [-1, 0], right: [1, 0] };
  SU.input = {
    init: function (h) {
      const cv = $('gameCanvas');
      let start = null, fired = false;
      cv.addEventListener('pointerdown', function (e) { if (h.control() !== 'swipe') return; start = { x: e.clientX, y: e.clientY, id: e.pointerId }; fired = false; });
      cv.addEventListener('pointermove', function (e) {
        if (!start || fired || e.pointerId !== start.id || h.control() !== 'swipe') return;
        const dx = e.clientX - start.x, dy = e.clientY - start.y;
        if (Math.abs(dx) < C.SWIPE_MIN && Math.abs(dy) < C.SWIPE_MIN) return;
        fired = true; /* satu gesture -> satu perubahan arah */
        if (Math.abs(dx) > Math.abs(dy)) h.dir(dx > 0 ? 1 : -1, 0); else h.dir(0, dy > 0 ? 1 : -1);
      });
      const end = function () { start = null; };
      cv.addEventListener('pointerup', end); cv.addEventListener('pointercancel', end);
      Object.keys(DIR).forEach(function (k) {
        const b = $(k), d = DIR[k];
        b.addEventListener('pointerdown', function (e) { e.preventDefault(); h.dir(d[0], d[1]); });
        b.addEventListener('click', function (e) { if (e.detail === 0) h.dir(d[0], d[1]); }); /* aktivasi keyboard/pembaca layar */
      });
      $('dashButton').addEventListener('click', function () { h.dash(); });
      g.document.addEventListener('keydown', function (e) {
        const t = e.target && e.target.tagName;
        if (t === 'INPUT' || t === 'SELECT' || t === 'TEXTAREA' || e.ctrlKey || e.metaKey || e.altKey) return;
        const k = e.key;
        const map = { ArrowUp: 'up', w: 'up', W: 'up', ArrowDown: 'down', s: 'down', S: 'down', ArrowLeft: 'left', a: 'left', A: 'left', ArrowRight: 'right', d: 'right', D: 'right' };
        if (map[k]) { if (h.active()) { e.preventDefault(); h.dir(DIR[map[k]][0], DIR[map[k]][1]); } }
        else if (k === ' ' && h.active()) { e.preventDefault(); h.dash(); }
        else if ((k === 'p' || k === 'P' || k === 'Escape') && h.canPause()) { e.preventDefault(); h.pause(); }
      });
    }
  };
})(typeof window !== 'undefined' ? window : globalThis);
