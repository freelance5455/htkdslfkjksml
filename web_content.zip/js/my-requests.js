/**
 * BD BLOOD DONATION - My Blood Requests Management View
 * Tabs: Pending, Accepted / Donor Found, Completed, Cancelled
 * Includes confirm donation completed, cancel request, and rating modal.
 */

import { 
  db, 
  collection, 
  query, 
  where, 
  orderBy, 
  getDocs, 
  doc, 
  getDoc 
} from './firebase-config.js';
import { getCurrentUser } from './auth.js';
import { completeBloodRequest, cancelBloodRequest } from './blood-request.js';
import { submitDonorRating } from './rating.js';
import { getDistrictName } from './location.js';
import { 
  toBengaliDigits, 
  escapeHtml, 
  formatDate, 
  formatTimeAgo, 
  showToast, 
  showModal, 
  getLanguage 
} from './utils.js';

export async function renderMyRequestsPage(container, params = {}) {
  const user = getCurrentUser();
  const isBn = getLanguage() === 'bn';

  if (!user) {
    container.innerHTML = `
      <div class="page-container animate-slide-in">
        <div class="empty-state card">
          <div class="empty-state-icon">🔒</div>
          <div class="empty-state-title">${isBn ? 'লগইন প্রয়োজন' : 'Login Required'}</div>
          <div class="empty-state-desc">${isBn ? 'আপনার রক্তদানের আবেদনসমূহ দেখতে অনুগ্রহ করে লগইন করুন।' : 'Please login to track your blood requests.'}</div>
          <a href="#/login" class="btn btn-primary btn-sm" style="margin-top: 10px;">${isBn ? 'লগইন করুন' : 'Login'}</a>
        </div>
      </div>
    `;
    return;
  }

  container.innerHTML = `
    <div class="page-container animate-slide-in">
      <div class="page-header-title">
        <span>📋 ${isBn ? 'আমার রক্তের আবেদনসমূহ' : 'My Blood Requests'}</span>
        <a href="#/blood-request" class="btn btn-primary btn-sm">+ ${isBn ? 'নতুন আবেদন' : 'New Request'}</a>
      </div>

      <!-- Filter Tabs -->
      <div class="tab-nav">
        <button class="tab-btn active" data-status="all">${isBn ? 'সকল' : 'All'}</button>
        <button class="tab-btn" data-status="Pending">${isBn ? 'অপেক্ষমান (Pending)' : 'Pending'}</button>
        <button class="tab-btn" data-status="Accepted">${isBn ? 'রক্তদাতা প্রাপ্ত (Accepted)' : 'Accepted'}</button>
        <button class="tab-btn" data-status="Completed">${isBn ? 'সম্পন্ন (Completed)' : 'Completed'}</button>
        <button class="tab-btn" data-status="Cancelled">${isBn ? 'বাতিল (Cancelled)' : 'Cancelled'}</button>
      </div>

      <!-- Requests Listing -->
      <div id="my-requests-list">
        <div class="spinner"></div>
      </div>
    </div>
  `;

  let currentTab = 'all';
  let cachedRequests = [];

  const tabBtns = container.querySelectorAll('.tab-btn');
  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      tabBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentTab = btn.dataset.status;
      renderFilteredList();
    });
  });

  await fetchUserRequests();

  async function fetchUserRequests() {
    const listContainer = document.getElementById('my-requests-list');
    if (!listContainer) return;

    try {
      const q = query(
        collection(db, 'blood_requests'),
        where('requesterId', '==', user.uid),
        orderBy('createdAt', 'desc')
      );
      const snap = await getDocs(q);

      cachedRequests = [];
      snap.forEach(d => {
        cachedRequests.push({ id: d.id, ...d.data() });
      });

      renderFilteredList();
    } catch (err) {
      console.warn('[Fetch Requests Error]', err.message);
      // Fallback query if composite index is waiting
      try {
        const snap = await getDocs(query(collection(db, 'blood_requests'), where('requesterId', '==', user.uid)));
        cachedRequests = [];
        snap.forEach(d => cachedRequests.push({ id: d.id, ...d.data() }));
        cachedRequests.sort((a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0));
        renderFilteredList();
      } catch (e) {
        listContainer.innerHTML = `<div class="empty-state card"><p>${isBn ? 'তথ্য লোড করতে সমস্যা হয়েছে।' : 'Error loading requests.'}</p></div>`;
      }
    }
  }

  function renderFilteredList() {
    const listContainer = document.getElementById('my-requests-list');
    if (!listContainer) return;

    const filtered = currentTab === 'all' 
      ? cachedRequests 
      : cachedRequests.filter(r => r.status === currentTab);

    if (filtered.length === 0) {
      listContainer.innerHTML = `
        <div class="empty-state card">
          <div class="empty-state-icon">📄</div>
          <div class="empty-state-title">${isBn ? 'কোনো আবেদন পাওয়া যায়নি' : 'No Requests Found'}</div>
          <div class="empty-state-desc">
            ${currentTab === 'all' 
              ? (isBn ? 'আপনি এখনো কোনো রক্তের আবেদন করেননি।' : 'You have not created any blood requests yet.') 
              : (isBn ? `এই ক্যাটাগরিতে (${currentTab}) কোনো আবেদন নেই।` : `No requests in ${currentTab} status.`)}
          </div>
        </div>
      `;
      return;
    }

    let html = '';
    filtered.forEach(req => {
      const distName = getDistrictName(req.division, req.district, isBn ? 'bn' : 'en');
      let statusBadge = '<span class="badge badge-warning">অপেক্ষমান</span>';
      if (req.status === 'Accepted') statusBadge = '<span class="badge badge-success">রক্তদাতা প্রস্তুত</span>';
      if (req.status === 'Completed') statusBadge = '<span class="badge badge-primary" style="background:#E0F2FE; color:#0369A1;">সম্পন্ন</span>';
      if (req.status === 'Cancelled') statusBadge = '<span class="badge badge-secondary">বাতিল</span>';

      html += `
        <div class="request-card ${req.isEmergency ? 'is-emergency' : ''}" id="req-card-${req.id}">
          <div class="request-card-header">
            <div class="request-patient-info">
              <h3>${escapeHtml(req.patientName)}</h3>
              <div style="font-size: 11px; color: var(--text-muted); margin-top: 2px;">
                ${escapeHtml(req.hospitalName)} • ${distName}
              </div>
            </div>
            <div style="display: flex; flex-direction: column; align-items: flex-end; gap: 4px;">
              <span class="badge badge-blood">${req.bloodGroup}</span>
              ${statusBadge}
            </div>
          </div>

          <div class="request-details-grid">
            <div class="request-detail-item">
              <span>🩸</span>
              <span>${toBengaliDigits(req.bagsCount)} ${isBn ? 'ব্যাগ' : 'Bags'}</span>
            </div>
            <div class="request-detail-item">
              <span>📅</span>
              <span>${escapeHtml(req.requiredDate)} (${escapeHtml(req.requiredTime || '')})</span>
            </div>
            <div class="request-detail-item">
              <span>📞</span>
              <span>${escapeHtml(req.contactPhone)}</span>
            </div>
            <div class="request-detail-item">
              <span>🕒</span>
              <span>${formatTimeAgo(req.createdAt)}</span>
            </div>
          </div>

          ${req.acceptedDonorName ? `
            <div style="padding: 10px; background: #ECFDF5; border: 1px solid #A7F3D0; border-radius: var(--radius-md); margin-bottom: 12px; font-size: 12px;">
              <div style="font-weight: 700; color: #065F46; margin-bottom: 2px;">
                🎉 রক্তদাতা: ${escapeHtml(req.acceptedDonorName)}
              </div>
              <div style="display: flex; align-items: center; justify-content: space-between; margin-top: 6px;">
                ${req.acceptedDonorPhone ? `
                  <a href="tel:${escapeHtml(req.acceptedDonorPhone)}" class="btn btn-secondary btn-sm" style="background:#fff;">
                    📞 ${escapeHtml(req.acceptedDonorPhone)}
                  </a>
                ` : ''}
                <a href="#/chat?userId=${req.acceptedDonorId}" class="btn btn-outline btn-sm">
                  💬 চ্যাট করুন
                </a>
              </div>
            </div>
          ` : ''}

          <!-- Action buttons depending on state -->
          <div class="request-actions-row">
            ${req.status === 'Pending' ? `
              <button class="btn btn-secondary btn-sm btn-cancel-req" data-id="${req.id}">
                ✕ ${isBn ? 'আবেদন বাতিল' : 'Cancel'}
              </button>
              <a href="#/donor-search?group=${encodeURIComponent(req.bloodGroup)}" class="btn btn-primary btn-sm">
                🔍 ${isBn ? 'রক্তদাতা খুঁজুন' : 'Find Donors'}
              </a>
            ` : ''}

            ${req.status === 'Accepted' ? `
              <button class="btn btn-primary btn-sm btn-complete-req" data-id="${req.id}" style="background:#059669; border-color:#059669;">
                ✓ ${isBn ? 'রক্তদান সম্পন্ন নিশ্চিত করুন' : 'Confirm Donated'}
              </button>
            ` : ''}

            ${req.status === 'Completed' ? `
              ${!req.isRated && req.acceptedDonorId ? `
                <button class="btn btn-danger btn-sm btn-rate-donor" data-id="${req.id}" data-donor-id="${req.acceptedDonorId}">
                  ⭐ ${isBn ? 'রক্তদাতাকে রেটিং দিন' : 'Rate Donor'}
                </button>
              ` : `
                <span class="badge badge-success">✓ ${isBn ? 'রিভিউ ও রেটিং সম্পন্ন' : 'Rated'}</span>
              `}
            ` : ''}

            ${req.status === 'Cancelled' ? `
              <span style="font-size: 11px; color: var(--text-light);">${isBn ? 'বাতিলকৃত' : 'Cancelled'}</span>
            ` : ''}
          </div>
        </div>
      `;
    });

    listContainer.innerHTML = html;

    // Attach event listeners
    listContainer.querySelectorAll('.btn-cancel-req').forEach(btn => {
      btn.addEventListener('click', () => {
        showModal({
          title: isBn ? 'আবেদন বাতিল করবেন?' : 'Cancel Request?',
          body: isBn ? 'আপনি কি নিশ্চিতভাবে এই রক্তের আবেদনটি বাতিল করতে চান?' : 'Are you sure you want to cancel this request?',
          confirmText: isBn ? 'হ্যাঁ, বাতিল করুন' : 'Yes, Cancel',
          cancelText: isBn ? 'না' : 'No',
          isDanger: true,
          onConfirm: async () => {
            await cancelBloodRequest(btn.dataset.id);
            await fetchUserRequests();
          }
        });
      });
    });

    listContainer.querySelectorAll('.btn-complete-req').forEach(btn => {
      btn.addEventListener('click', () => {
        showModal({
          title: isBn ? 'রক্তদান সম্পন্ন নিশ্চিতকরণ' : 'Confirm Blood Donation',
          body: isBn ? 'রোগী কি রক্তদান গ্রহণ করেছেন? এটি রক্তদাতার প্রোফাইলে সফল রক্তদান হিসেবে যুক্ত হবে।' : 'Has the patient received the blood? This will update the donor donation count.',
          confirmText: isBn ? 'হ্যাঁ, সম্পন্ন হয়েছে' : 'Yes, Completed',
          cancelText: isBn ? 'না' : 'No',
          onConfirm: async () => {
            await completeBloodRequest(btn.dataset.id);
            await fetchUserRequests();
          }
        });
      });
    });

    listContainer.querySelectorAll('.btn-rate-donor').forEach(btn => {
      btn.addEventListener('click', () => {
        openRatingDialog(btn.dataset.id, btn.dataset.donorId);
      });
    });
  }

  function openRatingDialog(requestId, donorId) {
    const dialogBody = `
      <div style="display: flex; flex-direction: column; gap: 14px;">
        <p style="font-size: 13px; color: var(--text-muted);">
          ${isBn ? 'রক্তদাতার সহযোগিতা এবং সময়ানুবর্তিতা কেমন ছিল? ১ থেকে ৫ তারকা দিয়ে মূল্যায়ন করুন:' : 'How was the donor punctuality and support?'}
        </p>

        <div style="display: flex; justify-content: center; gap: 10px; font-size: 32px; cursor: pointer;" id="star-rating-box">
          <span data-star="1">⭐</span>
          <span data-star="2">⭐</span>
          <span data-star="3">⭐</span>
          <span data-star="4">⭐</span>
          <span data-star="5">⭐</span>
        </div>
        <input type="hidden" id="selected-star-val" value="5" />

        <div class="form-group">
          <label class="form-label">${isBn ? 'রিভিউর ধরন' : 'Review Category'}</label>
          <select id="review-type-select" class="form-select">
            <option value="good">${isBn ? 'চমৎকার ও মানবিক ব্যবহার (Positive)' : 'Positive'}</option>
            <option value="average">${isBn ? 'সন্তোষজনক (Satisfactory)' : 'Neutral'}</option>
            <option value="bad">${isBn ? 'সমস্যা বা অভিযোগ (Issues)' : 'Issues'}</option>
          </select>
        </div>

        <div class="form-group">
          <label class="form-label">${isBn ? 'আপনার মন্তব্য (ঐচ্ছিক)' : 'Written Comment'}</label>
          <textarea id="review-feedback-text" class="form-control" rows="3" placeholder="${isBn ? 'রক্তদাতা সম্পর্কে আপনার মূল্যবান অভিজ্ঞতা লিখুন...' : 'Share feedback about the donor...'}"></textarea>
        </div>
      </div>
    `;

    showModal({
      title: isBn ? '⭐ রক্তদাতাকে রেটিং ও রিভিউ দিন' : '⭐ Rate the Donor',
      body: dialogBody,
      confirmText: isBn ? 'রিভিউ জমা দিন' : 'Submit Review',
      cancelText: isBn ? 'বাতিল' : 'Cancel',
      onConfirm: async () => {
        const starVal = Number(document.getElementById('selected-star-val').value) || 5;
        const reviewType = document.getElementById('review-type-select').value;
        const feedback = document.getElementById('review-feedback-text').value;

        await submitDonorRating({
          requestId,
          donorId,
          rating: starVal,
          reviewType,
          feedbackText: feedback
        });

        await fetchUserRequests();
      }
    });

    // Star selection click events
    setTimeout(() => {
      const starBox = document.getElementById('star-rating-box');
      if (starBox) {
        const stars = starBox.querySelectorAll('span');
        stars.forEach(s => {
          s.addEventListener('click', () => {
            const val = Number(s.dataset.star);
            document.getElementById('selected-star-val').value = val;
            stars.forEach((other, idx) => {
              other.style.opacity = idx < val ? '1' : '0.25';
            });
          });
        });
      }
    }, 100);
  }
}
