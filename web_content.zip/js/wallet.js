import { getDateValue } from "./shared-utils.js";
// ===============================================
// NetEarn Pro Wallet System
// STEP 2 — UNIVERSAL INCOME CALCULATOR
// ===============================================

import { auth, db } from "./firebase.js";

import {
    onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";

import {
    doc,
    onSnapshot,
    collection,
    query,
    where,
    getDocs
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";


// =================================================
// HELPERS
// =================================================

function money(value) {

    const number = Number(value || 0);

    return "৳" + number.toLocaleString("en-BD");

}


function setValue(id, value) {

    const el =
        document.getElementById(id);

    if (el) {

        el.innerText =
            money(value);

    }

}
// =====================================================
// ⚡ FAST WALLET CACHE
// NetEarn Pro
// Instant Wallet UI + Background Firebase Sync
// =====================================================

const WALLET_CACHE_KEY =
    "netearnWalletCache";

const USER_SESSION_CACHE_KEY =
    "netearnUserSessionCache";


// =====================================================
// SAVE WALLET CACHE
// =====================================================

function saveWalletCache(data) {

    try {

        localStorage.setItem(

            WALLET_CACHE_KEY,

            JSON.stringify({

                ...data,

                cachedAt:
                    Date.now()

            })

        );

        // Keep the same wallet snapshot in sessionStorage so navigation
        // can paint the wallet immediately without waiting for Firebase.
        try {
            const sessionUser = JSON.parse(
                sessionStorage.getItem(USER_SESSION_CACHE_KEY) || "null"
            );
            if (sessionUser && sessionUser.data) {
                sessionStorage.setItem(
                    USER_SESSION_CACHE_KEY,
                    JSON.stringify({
                        ...sessionUser,
                        data: {
                            ...sessionUser.data,
                            balance: data.balance ?? sessionUser.data.balance,
                            mainBalance: data.balance ?? sessionUser.data.mainBalance,
                            creditBalance: data.creditBalance ?? sessionUser.data.creditBalance,
                            todayIncome: data.todayIncome ?? sessionUser.data.todayIncome,
                            yesterdayIncome: data.yesterdayIncome ?? sessionUser.data.yesterdayIncome,
                            weeklyIncome: data.weeklyIncome ?? sessionUser.data.weeklyIncome,
                            monthlyIncome: data.monthlyIncome ?? sessionUser.data.monthlyIncome,
                            totalIncome: data.totalIncome ?? sessionUser.data.totalIncome
                        },
                        savedAt: Date.now()
                    })
                );
            }
        } catch (_) {}

        console.log(
            "⚡ Wallet cache saved"
        );

    }

    catch (error) {

        console.warn(
            "⚠️ Wallet cache save failed:",
            error
        );

    }

}


// =====================================================
// LOAD WALLET CACHE
// =====================================================

function loadWalletCache(uid) {

    // 1) Shared session user cache: fastest source across page navigation.
    try {
        const rawUser = sessionStorage.getItem(USER_SESSION_CACHE_KEY);
        const sessionUser = rawUser ? JSON.parse(rawUser) : null;
        if (sessionUser?.uid === uid && sessionUser?.data) {
            const data = sessionUser.data;
            if (data.balance !== undefined) setValue("mainBalance", data.balance);
            else if (data.mainBalance !== undefined) setValue("mainBalance", data.mainBalance);
            if (data.creditBalance !== undefined) setValue("creditBalance", data.creditBalance);
            if (data.todayIncome !== undefined) setValue("todayIncome", data.todayIncome);
            if (data.yesterdayIncome !== undefined) setValue("yesterdayIncome", data.yesterdayIncome);
            if (data.weeklyIncome !== undefined) setValue("weeklyIncome", data.weeklyIncome);
            if (data.monthlyIncome !== undefined) setValue("monthlyIncome", data.monthlyIncome);
            if (data.totalIncome !== undefined) setValue("totalIncome", data.totalIncome);
        }
    } catch (_) {}

    try {

        const cached =
            localStorage.getItem(
                WALLET_CACHE_KEY
            );


        if (!cached) {

            return false;

        }


        const data =
            JSON.parse(cached);


        // ---------------------------------------------
        // SECURITY
        // Cache must belong to CURRENT user
        // ---------------------------------------------

        if (
            data.uid &&
            data.uid !== uid
        ) {

            return false;

        }


        // ---------------------------------------------
        // MAIN BALANCE
        // ---------------------------------------------

        if (
            data.balance !== undefined
        ) {

            setValue(
                "mainBalance",
                data.balance
            );

        }


        // ---------------------------------------------
        // CREDIT BALANCE
        // ---------------------------------------------

        if (
            data.creditBalance !== undefined
        ) {

            setValue(
                "creditBalance",
                data.creditBalance
            );

        }


        // ---------------------------------------------
        // TODAY
        // ---------------------------------------------

        if (
            data.todayIncome !== undefined
        ) {

            setValue(
                "todayIncome",
                data.todayIncome
            );

        }


        // ---------------------------------------------
        // YESTERDAY
        // ---------------------------------------------

        if (
            data.yesterdayIncome !== undefined
        ) {

            setValue(
                "yesterdayIncome",
                data.yesterdayIncome
            );

        }


        // ---------------------------------------------
        // LAST 7 DAYS
        // ---------------------------------------------

        if (
            data.weeklyIncome !== undefined
        ) {

            setValue(
                "weeklyIncome",
                data.weeklyIncome
            );

        }


        // ---------------------------------------------
        // LAST 30 DAYS
        // ---------------------------------------------

        if (
            data.monthlyIncome !== undefined
        ) {

            setValue(
                "monthlyIncome",
                data.monthlyIncome
            );

        }


        // ---------------------------------------------
        // TOTAL INCOME
        // ---------------------------------------------

        if (
            data.totalIncome !== undefined
        ) {

            setValue(
                "totalIncome",
                data.totalIncome
            );

        }


        console.log(
            "⚡ Wallet cache loaded instantly"
        );


        return true;

    }

    catch (error) {

        console.warn(
            "⚠️ Wallet cache load failed:",
            error
        );

        return false;

    }

}

// =================================================
// DATE HELPERS
// =================================================

function startOfDay(date) {

    const d =
        new Date(date);

    d.setHours(
        0,
        0,
        0,
        0
    );

    return d;

}


function startOfYesterday(date) {

    const d =
        startOfDay(date);

    d.setDate(
        d.getDate() - 1
    );

    return d;

}


function startOf7Days(date) {

    const d =
        startOfDay(date);

    d.setDate(
        d.getDate() - 6
    );

    return d;

}


function startOf30Days(date) {

    const d =
        startOfDay(date);

    d.setDate(
        d.getDate() - 29
    );

    return d;

}


// =================================================
// UNIVERSAL INCOME CHECK
// =================================================
//
// Existing Task Reward:
// type = "task_reward"
// reward = 5
// status = "approved"
//
// Future Income:
// type = "referral"
// type = "bonus"
// type = "daily_bonus"
// type = "target_bonus"
// etc.
//
// All approved credit income can be counted.
//

function isValidIncome(data) {

    if (!data) {

        return false;

    }


    // ---------------------------------------------
    // STATUS
    // ---------------------------------------------

    const status =
        String(
            data.status || ""
        )
        .trim()
        .toLowerCase();


    const validStatus = [

        "approved",
        "completed",
        "complete",
        "success",
        "successful"

    ];


    if (
        !validStatus.includes(
            status
        )
    ) {

        return false;

    }


    // ---------------------------------------------
    // TYPE
    // ---------------------------------------------

    const type =
        String(
            data.type || ""
        )
        .trim()
        .toLowerCase();


    // ---------------------------------------------
    // DEBIT TYPES NEVER COUNT AS INCOME
    // ---------------------------------------------

    const debitTypes = [

        "debit",
        "withdraw",
        "withdrawal",
        "purchase",
        "payment",
        "subscription",
        "expense"

    ];


    if (
        debitTypes.includes(
            type
        )
    ) {

        return false;

    }


    // ---------------------------------------------
    // AMOUNT
    // ---------------------------------------------

    const amount =
        Number(
            data.amount ??
            data.reward ??
            0
        );


    if (
        !Number.isFinite(amount) ||
        amount <= 0
    ) {

        return false;

    }


    return true;

}


// =================================================
// GET INCOME AMOUNT
// =================================================

function getIncomeAmount(data) {

    const amount =
        Number(
            data.amount ??
            data.reward ??
            0
        );


    if (
        !Number.isFinite(amount) ||
        amount <= 0
    ) {

        return 0;

    }


    return amount;

}


// =====================================================
// STEP 7
// UNIVERSAL INCOME SYSTEM
// DOUBLE INCOME PROTECTION
// =====================================================

// =================================================
// SHARED TRANSACTION READ
// =================================================
// Share only the in-flight Firebase read between the Wallet
// income calculation and transaction list. The promise is
// cleared after completion, so normal refresh behavior remains.
let transactionSnapshotPromise = null;
let transactionSnapshotUid = null;

function getTransactionSnapshot(uid) {

    if (
        transactionSnapshotPromise &&
        transactionSnapshotUid === uid
    ) {
        return transactionSnapshotPromise;
    }

    const transactionQuery =
        query(
            collection(
                db,
                "transactions"
            ),
            where(
                "uid",
                "==",
                uid
            )
        );

    transactionSnapshotUid = uid;

    transactionSnapshotPromise =
        getDocs(transactionQuery);

    transactionSnapshotPromise
        .finally(() => {
            transactionSnapshotPromise = null;
            transactionSnapshotUid = null;
        })
        .catch(() => {});

    return transactionSnapshotPromise;
}


async function loadIncome(uid) {

    const now =
        new Date();


    // =================================================
    // DATE RANGE
    // =================================================

    const todayStart =
        startOfDay(now);


    const yesterdayStart =
        startOfYesterday(now);


    const sevenDaysStart =
        startOf7Days(now);


    const thirtyDaysStart =
        startOf30Days(now);


    // =================================================
    // INCOME TOTALS
    // =================================================

    let todayIncome = 0;

    let yesterdayIncome = 0;

    let weeklyIncome = 0;

    let monthlyIncome = 0;

    let totalIncome = 0;


    // =================================================
    // DUPLICATE PROTECTION
    // =================================================

    const countedRewardIds =
        new Set();

    const countedTransactionIds =
        new Set();


    try {


        // =================================================
        // 1️⃣ REWARD HISTORY
        // =================================================
        //
        // Task Reward-এর MAIN source.
        //
        // Example:
        //
        // rewardHistory
        // type   = task_reward
        // reward = 2
        // status = approved
        //
        // এই টাকা এখানে একবারই গণনা হবে।
        // =================================================


        const rewardQuery =
            query(

                collection(
                    db,
                    "rewardHistory"
                ),

                where(
                    "userUid",
                    "==",
                    uid
                )

            );


        // ⚡ Reward history and transactions are independent
        // reads, so start both at the same time. The transaction
        // read is shared with the transaction list when both are
        // requested together.
        const transactionSnapshotPromise =
            getTransactionSnapshot(uid);

        const [
            rewardSnapshot,
            transactionSnapshot
        ] = await Promise.all([

            getDocs(rewardQuery),
            transactionSnapshotPromise

        ]);


        rewardSnapshot.forEach(
            rewardDoc => {

                const data =
                    rewardDoc.data();


                // -----------------------------------------
                // DUPLICATE DOCUMENT PROTECTION
                // -----------------------------------------

                if (
                    countedRewardIds.has(
                        rewardDoc.id
                    )
                ) {

                    return;

                }


                // -----------------------------------------
                // STATUS
                // -----------------------------------------

                const status =
                    String(
                        data.status || ""
                    )
                    .trim()
                    .toLowerCase();


                const validRewardStatus = [

                    "approved",
                    "completed",
                    "complete",
                    "success",
                    "successful"

                ];


                if (
                    !validRewardStatus.includes(
                        status
                    )
                ) {

                    return;

                }


                // -----------------------------------------
                // TYPE
                // -----------------------------------------

                const type =
                    String(
                        data.type || ""
                    )
                    .trim()
                    .toLowerCase();


                // -----------------------------------------
                // ONLY INCOME
                // -----------------------------------------

                if (
                    [
                        "debit",
                        "withdraw",
                        "withdrawal",
                        "purchase",
                        "payment",
                        "subscription",
                        "expense"
                    ]
                    .includes(type)
                ) {

                    return;

                }


                // -----------------------------------------
                // AMOUNT
                // -----------------------------------------

                const amount =
                    Number(
                        data.reward ??
                        data.amount ??
                        0
                    );


                if (
                    !Number.isFinite(
                        amount
                    ) ||
                    amount <= 0
                ) {

                    return;

                }


                // -----------------------------------------
                // DATE
                // -----------------------------------------

                const date =
                    getDateValue(
                        data.createdAt
                    );


                if (!date) {

                    return;

                }


                // -----------------------------------------
                // MARK AS COUNTED
                // -----------------------------------------

                countedRewardIds.add(
                    rewardDoc.id
                );


                // -----------------------------------------
                // TOTAL
                // -----------------------------------------

                totalIncome +=
                    amount;


                // -----------------------------------------
                // TODAY
                // -----------------------------------------

                if (
                    date >=
                    todayStart
                ) {

                    todayIncome +=
                        amount;

                }


                // -----------------------------------------
                // YESTERDAY
                // -----------------------------------------

                else if (

                    date >=
                    yesterdayStart &&

                    date <
                    todayStart

                ) {

                    yesterdayIncome +=
                        amount;

                }


                // -----------------------------------------
                // LAST 7 DAYS
                // -----------------------------------------

                if (
                    date >=
                    sevenDaysStart
                ) {

                    weeklyIncome +=
                        amount;

                }


                // -----------------------------------------
                // LAST 30 DAYS
                // -----------------------------------------

                if (
                    date >=
                    thirtyDaysStart
                ) {

                    monthlyIncome +=
                        amount;

                }

            }
        );


        // =================================================
        // 2️⃣ TRANSACTIONS
        // =================================================
        //
        // Referral / Bonus / অন্যান্য income এখান থেকে
        // গণনা হবে।
        //
        // কিন্তু:
        //
        // "Task Reward"
        //
        // transaction থেকে আবার গণনা করা হবে না।
        //
        // কারণ Task Reward ইতিমধ্যে rewardHistory-তে আছে।
        // =================================================


        transactionSnapshot.forEach(
            transactionDoc => {

                const data =
                    transactionDoc.data();


                // -----------------------------------------
                // DUPLICATE TRANSACTION PROTECTION
                // -----------------------------------------

                if (
                    countedTransactionIds.has(
                        transactionDoc.id
                    )
                ) {

                    return;

                }


                // -----------------------------------------
                // TYPE
                // -----------------------------------------

                const type =
                    String(
                        data.type || ""
                    )
                    .trim()
                    .toLowerCase();


                // -----------------------------------------
                // ONLY CREDIT
                // -----------------------------------------

                if (
                    type !== "credit"
                ) {

                    return;

                }


                // -----------------------------------------
                // STATUS
                // -----------------------------------------

                const status =
                    String(
                        data.status || ""
                    )
                    .trim()
                    .toLowerCase();


                const validTransactionStatus = [

                    "approved",
                    "completed",
                    "complete",
                    "success",
                    "successful"

                ];


                if (
                    !validTransactionStatus.includes(
                        status
                    )
                ) {

                    return;

                }


                // -----------------------------------------
                // REASON / TITLE
                // -----------------------------------------

                const reason =
                    String(
                        data.reason ||
                        data.title ||
                        ""
                    )
                    .trim()
                    .toLowerCase();


                const title =
                    String(
                        data.title || ""
                    )
                    .trim()
                    .toLowerCase();


                // =================================================
                // 🚫 TASK REWARD DOUBLE COUNT PROTECTION
                // =================================================
                //
                // Example:
                //
                // reason = "Task Reward - LF"
                //
                // এটি rewardHistory-তে ইতিমধ্যে গণনা হয়েছে।
                //
                // তাই transactions থেকে SKIP.
                // =================================================


                const isTaskReward =

                    reason.includes(
                        "task reward"
                    )

                    ||

                    title.includes(
                        "task reward"
                    )

                    ||

                    type ===
                    "task_reward";


                if (
                    isTaskReward
                ) {

                    return;

                }


                // -----------------------------------------
                // AMOUNT
                // -----------------------------------------

                const amount =
                    Number(
                        data.amount ??
                        data.reward ??
                        0
                    );


                if (
                    !Number.isFinite(
                        amount
                    ) ||
                    amount <= 0
                ) {

                    return;

                }


                // -----------------------------------------
                // DATE
                // -----------------------------------------

                const date =
                    getDateValue(
                        data.createdAt
                    );


                if (!date) {

                    return;

                }


                // -----------------------------------------
                // MARK AS COUNTED
                // -----------------------------------------

                countedTransactionIds.add(
                    transactionDoc.id
                );


                // -----------------------------------------
                // TOTAL
                // -----------------------------------------

                totalIncome +=
                    amount;


                // -----------------------------------------
                // TODAY
                // -----------------------------------------

                if (
                    date >=
                    todayStart
                ) {

                    todayIncome +=
                        amount;

                }


                // -----------------------------------------
                // YESTERDAY
                // -----------------------------------------

                else if (

                    date >=
                    yesterdayStart &&

                    date <
                    todayStart

                ) {

                    yesterdayIncome +=
                        amount;

                }


                // -----------------------------------------
                // LAST 7 DAYS
                // -----------------------------------------

                if (
                    date >=
                    sevenDaysStart
                ) {

                    weeklyIncome +=
                        amount;

                }


                // -----------------------------------------
                // LAST 30 DAYS
                // -----------------------------------------

                if (
                    date >=
                    thirtyDaysStart
                ) {

                    monthlyIncome +=
                        amount;

                }

            }
        );


        // =================================================
        // 3️⃣ UPDATE WALLET UI
        // =================================================


        setValue(
            "todayIncome",
            todayIncome
        );


        setValue(
            "yesterdayIncome",
            yesterdayIncome
        );


        setValue(
            "weeklyIncome",
            weeklyIncome
        );


        setValue(
            "monthlyIncome",
            monthlyIncome
        );


        setValue(
            "totalIncome",
            totalIncome
        );


        // =================================================
        // 4️⃣ DEBUG
        // =================================================


        console.log(
            "💰 STEP 7 — Universal Income Loaded",
            {

                today:
                    todayIncome,

                yesterday:
                    yesterdayIncome,

                last7Days:
                    weeklyIncome,

                last30Days:
                    monthlyIncome,

                total:
                    totalIncome,

                rewardHistoryEntries:
                    countedRewardIds.size,

                transactionEntries:
                    countedTransactionIds.size

            }
        );


    }

    catch (error) {

        console.error(
            "❌ STEP 7 Income Calculation Error:",
            error
        );


        // =================================================
        // SAFE FALLBACK
        // =================================================

        setValue(
            "todayIncome",
            0
        );


        setValue(
            "yesterdayIncome",
            0
        );


        setValue(
            "weeklyIncome",
            0
        );


        setValue(
            "monthlyIncome",
            0
        );


        setValue(
            "totalIncome",
            0
        );
        
        // =================================================
// ⚡ SAVE LATEST INCOME TO CACHE
// =================================================

saveWalletCache({

    uid: uid,

    todayIncome:
        todayIncome,

    yesterdayIncome:
        yesterdayIncome,

    weeklyIncome:
        weeklyIncome,

    monthlyIncome:
        monthlyIncome,

    totalIncome:
        totalIncome

});

    }

}


// =================================================
// LOAD TRANSACTIONS
// =================================================

async function loadTransactions(uid) {

    const box =
        document.getElementById(
            "transactionList"
        );


    if (!box) {

        return;

    }


    try {

        // Reuse the in-flight transactions read if the Wallet
        // income loader is fetching the same data at the same time.
        const snapshot =
            await getTransactionSnapshot(uid);


        if (
            snapshot.empty
        ) {

            box.innerHTML = `
                <p class="empty">
                    No Transaction Found
                </p>
            `;

            return;

        }


        const transactions = [];


        snapshot.forEach(
            item => {

                const data =
                    item.data();


                transactions.push({

                    id:
                        item.id,

                    amount:
                        Number(
                            data.amount || 0
                        ),

                    type:
                        String(
                            data.type ||
                            "credit"
                        )
                        .toLowerCase(),

                    reason:
                        data.reason ||
                        "Transaction",

                    status:
                        data.status ||
                        "Completed",

                    createdAt:
                        getDateValue(
                            data.createdAt
                        )

                });

            }
        );


        // Newest first
        transactions.sort(
            (a, b) => {

                const aTime =
                    a.createdAt?.getTime() ||
                    0;

                const bTime =
                    b.createdAt?.getTime() ||
                    0;

                return bTime - aTime;

            }
        );


        box.innerHTML = "";


        transactions.forEach(
            transaction => {

                const isCredit =
                    transaction.type ===
                    "credit";


                const sign =
                    isCredit
                        ? "+"
                        : "-";


                const colorClass =
                    isCredit
                        ? "credit"
                        : "debit";


                const dateText =
                    transaction.createdAt
                        ? transaction.createdAt
                            .toLocaleDateString(
                                "en-GB"
                            )
                        : "";


                box.innerHTML += `

                    <div class="transaction-item">

                        <div>

                            <b>
                                ${escapeHTML(
                                    transaction.reason
                                )}
                            </b>

                            <br>

                            <small>

                                ${escapeHTML(
                                    transaction.status
                                )}

                                ${
                                    dateText
                                    ? " • " +
                                      escapeHTML(
                                          dateText
                                      )
                                    : ""
                                }

                            </small>

                        </div>


                        <div
                            class="${colorClass}"
                        >

                            ${sign}
                            ${money(
                                transaction.amount
                            )}

                        </div>

                    </div>

                `;

            }
        );

    }

    catch (error) {

        console.error(
            "❌ Transaction Error:",
            error
        );


        box.innerHTML = `
            <p class="empty">
                Transaction Load Failed
            </p>
        `;

    }

}


// =================================================
// ESCAPE HTML
// =================================================

function escapeHTML(value) {

    return String(
        value ?? ""
    )
    .replace(
        /&/g,
        "&amp;"
    )
    .replace(
        /</g,
        "&lt;"
    )
    .replace(
        />/g,
        "&gt;"
    )
    .replace(
        /"/g,
        "&quot;"
    )
    .replace(
        /'/g,
        "&#039;"
    );

}


// =================================================
// AUTH
// =================================================

onAuthStateChanged(
    auth,
    async user => {

        if (!user) {

            window.location.href =
                "index.html";

            return;

        }


        const uid =
            user.uid;


        // =========================================
        // USER DOCUMENT
        // =========================================

        const userRef =
            doc(
                db,
                "users",
                uid
            );


        // =========================================
        // ⚡ FAST WALLET CACHE
        // =========================================

        loadWalletCache(
            uid
        );


        // =========================================
        // LIVE BALANCE
        // =========================================

        onSnapshot(

            userRef,

            snapshot => {

                if (
                    !snapshot.exists()
                ) {

                    console.log(
                        "❌ User Data Not Found"
                    );

                    return;

                }


                const data =
                    snapshot.data();


                // ---------------------------------
                // MAIN BALANCE
                // ---------------------------------

                setValue(
                    "mainBalance",
                    data.balance
                );


                // ---------------------------------
                // CREDIT BALANCE
                // ---------------------------------

                setValue(
                    "creditBalance",
                    data.creditBalance
                );


                // =================================
                // ⚡ SAVE LIVE BALANCE TO CACHE
                // =================================

                try {

                    const oldCache =
                        JSON.parse(
                            localStorage.getItem(
                                WALLET_CACHE_KEY
                            ) || "{}"
                        );


                    saveWalletCache({

                        ...oldCache,

                        uid:
                            uid,

                        balance:
                            Number(
                                data.balance || 0
                            ),

                        creditBalance:
                            Number(
                                data.creditBalance || 0
                            )

                    });

                }

                catch (error) {

                    console.warn(
                        "⚠️ Balance cache update failed:",
                        error
                    );

                }


                // ---------------------------------
                // DATE
                // ---------------------------------

                const dateBox =
                    document.getElementById(
                        "walletDate"
                    );


                if (dateBox) {

                    dateBox.innerText =
                        new Date()
                            .toLocaleString(
                                "en-GB"
                            );

                }


                // ---------------------------------
                // ⚡ INCOME — BACKGROUND SYNC
                // ---------------------------------

                loadIncome(
                    uid
                ).catch(error => {

                    console.error(
                        "❌ Background Income Sync Error:",
                        error
                    );

                });


                // ---------------------------------
                // ⚡ TRANSACTIONS — BACKGROUND
                // ---------------------------------

                loadTransactions(
                    uid
                ).catch(error => {

                    console.error(
                        "❌ Background Transaction Sync Error:",
                        error
                    );

                });

            },

            error => {

                console.error(
                    "❌ Wallet Snapshot Error:",
                    error
                );

            }

        );

    }

);


// =================================================
// ADD BALANCE
// =================================================

const addBalanceBtn =
    document.getElementById(
        "addBalanceBtn"
    );


if (addBalanceBtn) {

    addBalanceBtn.onclick =
        () => {

            showToast(
                "💳 Add Balance System Coming Soon"
            );

        };

}

// =================================================
// TOAST
// =================================================

function showToast(message) {

    const box =
        document.createElement(
            "div"
        );


    box.innerText =
        message;


    box.style.position =
        "fixed";

    box.style.bottom =
        "100px";

    box.style.left =
        "50%";

    box.style.transform =
        "translateX(-50%)";

    box.style.background =
        "#1565ff";

    box.style.color =
        "#fff";

    box.style.padding =
        "12px 22px";

    box.style.borderRadius =
        "30px";

    box.style.zIndex =
        "9999";

    box.style.fontWeight =
        "600";


    document.body.appendChild(
        box
    );


    setTimeout(
        () => {

            box.remove();

        },
        2500
    );

}