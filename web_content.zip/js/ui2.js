/* =========================================================================
   Aethervale — Lapisan antarmuka tambahan
   Panel skill, panel tempa bos, tombol Boss Clash, pengaturan shader,
   HUD 3 slot skill + bilah HP bos + penghitung gelombang clash.
   Dimuat paling akhir: menambal UI, HUD, dan Game.onKey.
   ========================================================================= */

/* ---------------- HUD: 3 slot skill, bilah bos, clash ---------------- */
(function patchHUD() {
  const orig = HUD.draw.bind(HUD);
  HUD.draw = function (ctx, cam) {
    orig(ctx, cam);
    const P = Game.player; if (!P) return;
    const narrow = G.VW < 430;
    const pitch = narrow ? 32 : 38, wSlot = narrow ? 28 : 34;
    const cdy = 50;
    const keys = ['Q', 'R', 'C'];
    for (let i = 0; i < 3; i++) {
      const x = 6 + i * pitch, id = Skills.slots[i], sk = id ? SKILLS[id] : null;
      const cd = Skills.cd[i], max = sk ? sk.cd : 1;
      this.panel(ctx, x, cdy, wSlot, 24, 0.85);
      this.text(ctx, keys[i], x + wSlot / 2, cdy + 10, cd > 0 ? '#6b6480' : (sk ? sk.color : '#5b5470'), 7, 'center');
      this.text(ctx, sk ? sk.name.slice(0, narrow ? 5 : 6).toUpperCase() : '—', x + wSlot / 2, cdy + 20, cd > 0 ? '#5b5470' : '#b9b0d4', 3.6, 'center');
      if (cd > 0) {
        ctx.fillStyle = 'rgba(8,6,14,0.74)';
        ctx.fillRect(x + 1, cdy + 1, wSlot - 2, Math.round(22 * Math.min(1, cd / max)));
        this.text(ctx, cd.toFixed(1), x + wSlot / 2, cdy + 15, '#ffd24d', 4, 'center');
      }
    }
    const px = 6 + 3 * pitch;
    this.panel(ctx, px, cdy, wSlot, 24, 0.85);
    this.text(ctx, 'F', px + wSlot / 2, cdy + 10, P.potionCd > 0 ? '#6b6480' : '#6fe08a', 7, 'center');
    this.text(ctx, 'RAMUAN', px + wSlot / 2, cdy + 20, '#b9b0d4', 3.6, 'center');
    if (P.potionCd > 0) { ctx.fillStyle = 'rgba(8,6,14,0.74)'; ctx.fillRect(px + 1, cdy + 1, wSlot - 2, Math.round(22 * (P.potionCd / 1.2))); }

    // buff aktif
    let by = cdy + 28;
    const buffs = [];
    if (Skills.buffs.shield > 0) buffs.push(['PERISAI ' + Skills.buffs.shield.toFixed(0) + 's', '#9ec7ff']);
    if (Skills.buffs.haste > 0) buffs.push(['CEPAT ' + Skills.buffs.haste.toFixed(0) + 's', '#8fe8c0']);
    if (Skills.timeslow > 0) buffs.push(['WAKTU LAMBAT', '#7dd3fc']);
    buffs.forEach((b, i) => this.text(ctx, b[0], 8, by + 8 + i * 8, b[1], 5));

    // bilah HP bos
    const boss = Game.enemies.find(e => !e.dead && e.def_boss && (e.aggro || e.clash));
    if (boss) {
      const bw = Math.min(220, Math.round(G.VW * 0.6)), bx = Math.round(G.VW / 2 - bw / 2), byy = G.VH - 58;
      const def = ENEMIES[boss.type];
      const nm = (def.short || def.name).toUpperCase();
      this.panel(ctx, bx - 3, byy - 12, bw + 6, 22, 0.8);
      this.text(ctx, nm.slice(0, Math.floor(bw / 5.4)), bx + bw / 2, byy - 3, '#ff9a6b', 5, 'center');
      this.bar(ctx, bx, byy + 1, bw, 5, boss.hp / boss.maxhp, '#ff6b3d');
      this.text(ctx, Math.max(0, Math.round(boss.hp)) + '/' + boss.maxhp + ' · T' + (def.tier || '?'), bx + bw / 2, byy + 9, '#ffe9d0', 4, 'center');
    }
    // penghitung clash
    if (Clash.active) {
      const t = 'BOSS CLASH · GELOMBANG ' + Math.min(16, Clash.wave + 1) + '/16';
      this.panel(ctx, G.VW / 2 - 74, 44, 148, 14, 0.85);
      this.text(ctx, t, G.VW / 2, 54, '#ffd24d', 5, 'center');
      // ganti panel bioma dengan label arena
      const narrow2 = G.VW < 430, bw2 = narrow2 ? 112 : 126;
      this.panel(ctx, G.VW - 6 - bw2, 6, bw2, 34, 0.95);
      this.text(ctx, 'ARENA CLASH', G.VW - 6 - bw2 / 2, 17, '#ffb36b', narrow2 ? 5 : 6, 'center');
      this.text(ctx, 'RUANG TERTUTUP', G.VW - 6 - bw2 / 2, 26, '#8f89a8', 4, 'center');
      this.text(ctx, 'SISA BOS ' + (16 - Clash.wave) + ' · TANPA JALAN KELUAR', G.VW - 6 - bw2 / 2, 35, '#b9b0d4', 4, 'center');
    } else if (Lairs.site && !Game.paused) {
      // penunjuk arah sarang bos (disembunyikan saat jeda agar layar jeda bersih)
      const s = Lairs.site, dx = s.x - P.x, dy = s.y - P.y, d = Math.hypot(dx, dy);
      if (d > 120) {
        const a = Math.atan2(dy, dx);
        const cx = G.VW / 2 + Math.cos(a) * 86, cy = G.VH / 2 + Math.sin(a) * 66;
        ctx.save(); ctx.translate(cx, cy); ctx.rotate(a);
        ctx.fillStyle = 'rgba(255,122,69,0.95)';
        ctx.beginPath(); ctx.moveTo(6, 0); ctx.lineTo(-4, -4); ctx.lineTo(-4, 4); ctx.closePath(); ctx.fill();
        ctx.restore();
        this.text(ctx, 'SARANG ' + Math.round(d / 16) + 'm', cx, cy + 14, '#ff9a6b', 4, 'center');
      }
    }
  };
})();

/* ---------------- Panel: Skill ---------------- */
UI.view_skills = function () {
  const rows = Skills.unlocked.map(id => {
    const s = SKILLS[id];
    const slot = Skills.slots.indexOf(id);
    return `<div class="skill-row">
      <div class="sk-dot" style="background:${s.color}"></div>
      <div class="sk-main">
        <b>${s.name}</b>
        <small>${s.desc} · jeda ${s.cd}s${s.boss ? ' · dari bos' : ' · dasar kelas'}</small>
      </div>
      <div class="sk-btns">
        ${[0, 1, 2].map(i => `<button class="btn small${slot === i ? ' active' : ''}" data-eq="${id}" data-slot="${i}">${['Q', 'R', 'C'][i]}</button>`).join('')}
      </div>
    </div>`;
  }).join('');
  const locked = Object.keys(SKILLS).filter(k => !Skills.unlocked.includes(k));
  return `<div class="doc">
    <p class="hint">Tiga skill aktif terpasang di tombol <b>Q</b>, <b>R</b>, dan <b>C</b> (atau tombol S1/S2/S3 di layar sentuh).
    Skill baru terbuka dengan mengalahkan bos tertentu di sarangnya.</p>
    <h3>Skill dimiliki (${Skills.unlocked.length}/${Object.keys(SKILLS).length})</h3>
    <div class="skill-list">${rows}</div>
    <h3>Belum terbuka (${locked.length})</h3>
    <div class="skill-list locked">${locked.map(id => {
      const s = SKILLS[id];
      return `<div class="skill-row dim"><div class="sk-dot" style="background:${s.color}"></div>
        <div class="sk-main"><b>${s.name}</b><small>${s.desc} · hadiah bos bioma</small></div></div>`;
    }).join('')}</div>
  </div>`;
};
UI.wire_skills = function () {
  this.modal.querySelectorAll('[data-eq]').forEach(b => b.onclick = () => {
    Skills.equip(parseInt(b.dataset.slot, 10), b.dataset.eq);
    Audio2.sfx('ok'); this.render();
  });
};

/* ---------------- Panel: Tempa peralatan bos ---------------- */
UI.view_craft = function () {
  const P = Game.player;
  const have = tid => Inv.count ? Inv.count(tid) : (P.inv.filter(i => i.tid === tid).reduce((a, i) => a + (i.qty || 1), 0));
  const rows = CRAFT_RECIPES.map((r, idx) => {
    const it = ITEMS[r.out];
    const ok = r.cost.every(([tid, n]) => have(tid) >= n) && P.gold >= r.gold;
    return `<tr class="${ok ? '' : 'dim'}">
      <td>${this.icon(it, 22)} <b style="color:${RARITY[it.rarity].color}">${it.name}</b><br><small>${it.desc || ''}</small></td>
      <td>${r.cost.map(([tid, n]) => `${ITEMS[tid].name} <b>${have(tid)}/${n}</b>`).join('<br>')}<br>${fmt(r.gold)} G</td>
      <td><button class="btn small${ok ? ' primary' : ''}" data-craft="${idx}" ${ok ? '' : 'disabled'}>TEMPA</button></td>
    </tr>`;
  }).join('');
  return `<div class="doc">
    <p class="hint">Bawa <b>Inti Bos</b> dari bos bioma untuk menempa 16 pedang dan 16 zirah bos.
    Pedang rahasia <b>Flowers Flame</b> tidak bisa ditempa — hanya dari menuntaskan Boss Clash.</p>
    <table class="tbl"><thead><tr><th>Hasil</th><th>Bahan</th><th></th></tr></thead><tbody>${rows}</tbody></table>
  </div>`;
};
UI.wire_craft = function () {
  this.modal.querySelectorAll('[data-craft]').forEach(b => b.onclick = () => {
    const r = CRAFT_RECIPES[parseInt(b.dataset.craft, 10)];
    const P = Game.player;
    const have = tid => P.inv.filter(i => i.tid === tid).reduce((a, i) => a + (i.qty || 1), 0);
    if (!r.cost.every(([tid, n]) => have(tid) >= n) || P.gold < r.gold) { this.msg('Bahan atau gold belum cukup.', false); Audio2.sfx('fail'); return; }
    r.cost.forEach(([tid, n]) => Inv.remove(tid, n));
    P.gold -= r.gold;
    Inv.add(r.out);
    Audio2.sfx('unlock');
    this.msg('Berhasil menempa ' + ITEMS[r.out].name + '!', true);
    Game.toast('Tempaan selesai: ' + ITEMS[r.out].name, '#ffd24d');
    this.render();
  });
};

/* ---------------- Panel: Boss Clash ---------------- */
UI.view_clash = function () {
  const rows = CLASH_LADDER.map((bid, i) => {
    const d = ENEMIES[bid];
    const done = Clash.active ? i < Clash.wave : false;
    return `<tr class="${done ? 'good' : ''}"><td>${i + 1}</td><td>${d.name}</td><td>T${d.tier}</td><td>${fmt(d.hp)} HP</td><td>${done ? 'TUMBANG' : Clash.active && i === Clash.wave ? 'SEDANG DILAWAN' : '—'}</td></tr>`;
  }).join('');
  return `<div class="doc">
    <p class="hint">Arena tertutup berbentuk lingkaran — kau tidak bisa keluar. Enam belas bos datang berurutan
    dari yang terlemah sampai terkuat, HP-mu pulih 35% tiap bos tumbang. Menuntaskan semuanya memberi
    pedang rahasia <b>Flowers Flame</b>.</p>
    <div class="row-btns">
      ${Clash.active
      ? '<button class="btn" id="clashQuit">KELUAR ARENA</button>'
      : '<button class="btn primary" id="clashGo">MASUK ARENA</button>'}
    </div>
    <table class="tbl"><thead><tr><th>#</th><th>Bos</th><th>Tier</th><th>HP</th><th>Status</th></tr></thead><tbody>${rows}</tbody></table>
  </div>`;
};
UI.wire_clash = function () {
  const go = document.getElementById('clashGo');
  if (go) go.onclick = () => { this.closePanel(); Clash.start(); };
  const q = document.getElementById('clashQuit');
  if (q) q.onclick = () => { this.closePanel(); Clash.exit(false); };
};

/* ---------------- Panel: Bestiari bos ---------------- */
UI.view_bestiary = function () {
  const rows = BOSS_LIST.map(b => `<tr class="${Game.bossDefeated[b.biome] ? 'good' : ''}">
    <td>${b.name}</td><td>${BIOMES[b.biome].name}</td><td>T${b.tier}</td>
    <td>${fmt(b.hp)} HP · ATK ${b.atk}</td>
    <td>${b.reward.weapon ? ITEMS[b.reward.weapon].name : b.reward.armor ? ITEMS[b.reward.armor].name : b.reward.skill ? 'Skill: ' + SKILLS[b.reward.skill].name : fmt(b.reward.gold) + ' G'}</td>
    <td>${Game.bossDefeated[b.biome] ? 'TUMBANG' : '—'}</td></tr>`).join('');
  return `<div class="doc">
    <p class="hint">Setiap dari 64 bioma punya satu bos dengan sarang sendiri. Masuk ke bioma, ikuti penunjuk
    <b>SARANG</b> di tepi layar, dan bos akan terbangun saat kau mendekat. Tiap bioma juga punya 15 mob khas
    dan minimal satu dusun berpenduduk.</p>
    <table class="tbl"><thead><tr><th>Bos</th><th>Bioma</th><th>Tier</th><th>Status</th><th>Hadiah</th><th>Progres</th></tr></thead><tbody>${rows}</tbody></table>
  </div>`;
};

/* ---------------- judul panel baru ---------------- */
(function patchRender() {
  const orig = UI.render.bind(UI);
  const titles = {
    skills: 'Kemampuan — 3 Skill Aktif', craft: 'Tempa Peralatan Bos',
    clash: 'Mode Boss Clash — 16 Bos', bestiary: 'Bestiari Bos & Bioma',
  };
  UI.render = function () {
    orig();
    const t = titles[Game.activePanel];
    if (t) { const el = document.getElementById('sheetTitle'); if (el) el.textContent = t; }
  };
})();

/* ---------------- Pengaturan: shader + DLSS 5 ---------------- */
(function patchSettings() {
  const orig = UI.view_settings.bind(UI);
  UI.view_settings = function () {
    const S = Game.settings;
    const html = orig();
    const seg = (name, opts, cur) => opts.map(([v, l]) => `<button class="btn small seg${String(v) === String(cur) ? ' active' : ''}" data-set="${name}" data-val="${v}">${l}</button>`).join('');
    const row = `<div class="set-row"><div><b>Shader Ultra Realistis</b><small>Pasca-proses penuh: bloom, gradasi warna sinematik, aberasi kromatik, sinar tipis, dan grain film.
      Padukan dengan mode <b>DLSS 5</b> di baris atas agar tetap lancar. Ini efek shader di dalam game, bukan DLSS resmi NVIDIA.</small></div>
      <div class="set-ctrl">${seg('shader', [['off', 'Mati'], ['on', 'Realistis'], ['ultra', 'Ultra + DLSS 5']], S.shader || 'off')}</div></div>`;
    return html.replace('<p class="hint" id="setInfo">', row + '<p class="hint" id="setInfo">');
  };
  const origWire = UI.wire_settings.bind(UI);
  UI.wire_settings = function () {
    origWire();
    this.modal.querySelectorAll('[data-set="shader"]').forEach(b => b.onclick = () => {
      Game.settings.shader = b.dataset.val;
      if (b.dataset.val === 'ultra') { Game.settings.dlss = 'dlss5'; Game.applyResolution(); }
      Audio2.sfx('ui'); this.render();
    });
  };
})();

/* ---------------- Home: tombol Boss Clash & bestiari ---------------- */
(function patchHome() {
  const orig = UI.initHome.bind(UI);
  UI.initHome = function () {
    orig();
    const acts = this.home.querySelector('.home-actions');
    if (!acts) return;
    const b1 = document.createElement('button');
    b1.className = 'btn'; b1.id = 'btnClash'; b1.textContent = 'BOSS CLASH';
    b1.onclick = () => {
      Audio2.init(); Audio2.sfx('ok');
      const card = this.home.querySelector('.class-card.active');
      Game.start(card ? card.dataset.cls : CLASSES[0].id);
      setTimeout(() => Clash.start(), 400);
    };
    const b2 = document.createElement('button');
    b2.className = 'btn'; b2.id = 'btnBestiary'; b2.textContent = 'BESTIARI';
    b2.onclick = () => { Audio2.init(); this.openPanel('bestiary'); };
    acts.appendChild(b1); acts.appendChild(b2);
  };
})();

/* ---------------- Tombol sentuh: S1/S2/S3 + menu ---------------- */
(function patchTouch() {
  const orig = UI.initTouchPad.bind(UI);
  UI.initTouchPad = function () {
    orig();
    const pad = document.querySelector('.touchpad');
    if (!pad) return;
    // tombol Q lama diganti tiga slot skill
    const oldQ = pad.querySelector('[data-code="KeyQ"]');
    if (oldQ) oldQ.remove();
    const extra = [['S1', 0], ['S2', 1], ['S3', 2]];
    const frag = document.createDocumentFragment();
    extra.forEach(([label, slot]) => {
      const b = document.createElement('button');
      b.className = 'tbtn skill'; b.textContent = label;
      const fire = e => { e.preventDefault(); Audio2.init(); Game.skill(slot); };
      b.addEventListener('touchstart', fire, { passive: false });
      b.addEventListener('click', fire);
      frag.appendChild(b);
    });
    // sisipkan setelah tombol SERANG
    const atk = pad.querySelector('.tbtn.big');
    if (atk && atk.nextSibling) pad.insertBefore(frag, atk.nextSibling); else pad.appendChild(frag);
    [['SKILL', 'skills'], ['TEMPA', 'craft'], ['CLASH', 'clash']].forEach(([label, panel]) => {
      const b = document.createElement('button');
      b.className = 'tbtn'; b.textContent = label;
      const fire = e => { e.preventDefault(); Audio2.init(); UI.openPanel(panel); };
      b.addEventListener('touchstart', fire, { passive: false });
      b.addEventListener('click', fire);
      pad.appendChild(b);
    });
  };
})();

/* ---------------- Tombol papan ketik baru ---------------- */
(function patchKeys() {
  const orig = Game.onKey.bind(Game);
  Game.onKey = function (code) {
    if (this.state === 'play' && !this.activePanel && !this.dialog) {
      if (code === 'KeyK') { UI.openPanel('skills'); return; }
      if (code === 'KeyB') { UI.openPanel('clash'); return; }
      if (code === 'KeyT') { UI.openPanel('craft'); return; }
      if (code === 'KeyN') { UI.openPanel('bestiary'); return; }
    }
    orig(code);
  };
})();

/* ---------------- Kompatibilitas kisah dengan 960 mob bioma ---------------- */
(function patchQuestKills() {
  const orig = Game.quest.onKill.bind(Game.quest);
  Game.quest.onKill = function (type) {
    const s = this.cur();
    if (s && s.type === 'kill' && !s.boss && !s.target.includes(type) && String(type).indexOf('m_') === 0) {
      this.counter++; this.check(); UI.syncQuest(); return;
    }
    orig(type);
  };
})();
