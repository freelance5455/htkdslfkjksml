/* Entrada, camera, pontes, laco principal e toque */
/* ---------- entrada ---------- */
const keys={};let firing=false,running=false,locked=false,started=false,kills=0,wave=1;
addEventListener('keydown',e=>{keys[e.code]=true;if(e.code==='Space')e.preventDefault()});
addEventListener('keyup',e=>keys[e.code]=false);
addEventListener('mousedown',e=>{if(!running)return;if(e.button===2)zoomOn=true;else firing=true});addEventListener('mouseup',e=>{if(e.button===2)zoomOn=false;else firing=false});addEventListener('contextmenu',e=>e.preventDefault());
addEventListener('mousemove',e=>{if(!locked||!running)return;const k=(1-(player.ku?.7:.55)*zf)*aimSlow;player.yaw-=e.movementX*.0024*k;player.pitch=clamp(player.pitch-e.movementY*.002*k,player.air?-.9:-.15,.75)});
document.addEventListener('pointerlockchange',()=>{
  const was=locked;locked=document.pointerLockElement===renderer.domElement;
  if(was&&!locked&&!player.dead&&started)pauseOpen();
});
const pauseEl=document.getElementById('pause'),pbtn=document.getElementById('pbtn');
function pauseOpen(){
  if(!started||player.dead||!pauseEl.classList.contains('hide'))return;
  if(!document.getElementById('over').classList.contains('hide')||!document.getElementById('start').classList.contains('hide'))return;
  document.getElementById('pmsg').textContent=NET.on?'A partida online continua rodando enquanto você está aqui.':'Jogo pausado.';
  pauseEl.classList.remove('hide');if(!NET.on)running=false;firing=false;zoomOn=false;
  try{if(document.exitPointerLock)document.exitPointerLock()}catch(e){}
}
function pauseClose(){pauseEl.classList.add('hide');running=true;try{const r=renderer.domElement.requestPointerLock();if(r&&r.catch)r.catch(()=>{})}catch(e){}}
function pauseExit(){
  pauseEl.classList.add('hide');
  if(NET.on){location.href=location.href.split('#')[0];location.reload();return}
  running=false;firing=false;document.querySelector('.pick').classList.remove('hide');document.getElementById('start').classList.remove('hide');document.getElementById('go').textContent='Jogar';needRestart=true;refreshProg();
}
for(const[el,fn]of[[pbtn,pauseOpen],[document.getElementById('pcont'),pauseClose],[document.getElementById('psair'),pauseExit]]){el.addEventListener('touchstart',e=>{e.stopPropagation();e.preventDefault();fn()},{passive:false});el.addEventListener('mousedown',e=>e.stopPropagation());el.addEventListener('click',fn)}
addEventListener('keydown',e=>{if(e.code==='KeyP'){if(pauseEl.classList.contains('hide'))pauseOpen();else pauseClose()}else if(e.code==='Escape')pauseOpen()});
const fsB=document.getElementById('fs'),de=document.documentElement,canFS=!!(de.requestFullscreen||de.webkitRequestFullscreen);
const isFS=()=>document.fullscreenElement||document.webkitFullscreenElement;
function toggleFS(){try{
  if(isFS())(document.exitFullscreen||document.webkitExitFullscreen).call(document);
  else{const r=(de.requestFullscreen||de.webkitRequestFullscreen).call(de);if(r&&r.then)r.then(()=>{try{screen.orientation.lock('landscape').catch(()=>{})}catch(e){}}).catch(()=>{})}
}catch(e){}}
if(!canFS)fsB.classList.add('hide');
fsB.onclick=toggleFS;
const fsLabel=()=>{fsB.textContent=isFS()?'Sair da tela cheia':'Tela cheia'};
document.addEventListener('fullscreenchange',fsLabel);document.addEventListener('webkitfullscreenchange',fsLabel);
document.getElementById('go').onclick=()=>{
  if(NET.guest&&!(NET.up&&NET.up.open)){netMsg('Aguarde a conexão com a sala…');return}
  if(canFS&&!isFS())toggleFS();
  document.getElementById('start').classList.add('hide');running=true;inGarage=false;scene.remove(GAR.g);GAR.L.forEach(l=>scene.remove(l));
  if(needRestart){needRestart=false;restartGame()}else if(!started){started=true;document.querySelector('.pick').classList.add('hide');if(!NET.guest){spawnWave();for(let i=0;i<3;i++)spawnAlly()}spawnCrates();mhpOf(player);if(NET.guest)netSend({t:'hi',nick:curNick(),cust:custStr(),veh:curV});toast('Onda 1: os três times já estão espalhados pela ilha')}
  try{const r=renderer.domElement.requestPointerLock();if(r&&r.catch)r.catch(()=>{})}catch(e){}
  sfx(0,.05);
};
addEventListener('resize',()=>{renderer.setSize(innerWidth,innerHeight);cam.aspect=innerWidth/innerHeight;cam.updateProjectionMatrix()});
function toast(s){const t=document.getElementById('toast');t.textContent=s;t.style.opacity=1;clearTimeout(toast.k);toast.k=setTimeout(()=>t.style.opacity=0,2600)}
let needRestart=false;
/* reinicia a partida sem recarregar a pagina: limpa times, tiros e caixas, recria o jogador e a onda 1 */
function restartGame(){
  if(NET.on&&started)return netRespawn();
  for(const t of tanks)scene.remove(t.g);tanks.length=0;
  for(const s of shells){scene.remove(s.m);if(s.wire)scene.remove(s.wire)}shells.length=0;
  for(const c of crates)scene.remove(c.g);crates.length=0;crateQ.length=0;
  try{player=VEH[curV]()}catch(e){showErr('modelo '+curV,e);player=makeTank(0x5b6b3a)}
  player.isPlayer=true;player.x=0;player.z=0;player.hd=player.yaw=0;if(player.corv)toSea(player);place(player);camUpdate();
  ST={};UP.a=UP.r=0;OBJ={ty:-1};kills=0;wave=1;ammoT=0;hurt=0;shake=0;firing=false;zoomOn=false;aimLock=null;
  document.getElementById('kl').textContent=0;document.getElementById('wv').textContent=1;
  document.getElementById('over').classList.add('hide');document.querySelector('.pick').classList.add('hide');
  spawnWave();for(let i=0;i<3;i++)spawnAlly();spawnCrates();mhpOf(player);
  running=true;try{const r=renderer.domElement.requestPointerLock();if(r&&r.catch)r.catch(()=>{})}catch(e){}
  toast('Nova partida: Onda 1');
}
document.getElementById('again').onclick=restartGame;
document.getElementById('swap').onclick=()=>{document.getElementById('over').classList.add('hide');document.querySelector('.pick').classList.remove('hide');document.getElementById('start').classList.remove('hide');document.getElementById('go').textContent='Jogar';needRestart=true;refreshProg()};
addEventListener('keydown',e=>{if((e.code==='Enter'||e.code==='KeyR')&&!document.getElementById('over').classList.contains('hide'))restartGame()});
function gameOver(){
  save.best=Math.max(save.best,kills);save.wave=Math.max(save.wave,wave);save.games++;persist();
  document.getElementById('res').textContent='Você derrubou '+kills+' blindados e chegou à onda '+wave+'. Patente: '+rankOf(save.kills)+' · '+save.kills+' abates no total.';
  setTimeout(()=>{if(!NET.on)running=false;if(document.exitPointerLock)document.exitPointerLock();document.getElementById('over').classList.remove('hide')},1800);
}

/* ---------- mira, camera, minimapa ---------- */
const mark=new THREE.Mesh(new THREE.RingGeometry(1.2,1.8,24).rotateX(-Math.PI/2),new THREE.MeshBasicMaterial({color:0xff5b3a,depthTest:false,transparent:true,opacity:.9}));
mark.renderOrder=9;scene.add(mark);
const trajP=new Float32Array(62*3),trajG=new THREE.BufferGeometry(),pv=new THREE.Vector3(),impact=new THREE.Vector3();
trajG.setAttribute('position',new THREE.BufferAttribute(trajP,3));
const traj=new THREE.Line(trajG,new THREE.LineBasicMaterial({color:0xff7a4a,transparent:true,opacity:.45,depthTest:false}));traj.frustumCulled=false;traj.renderOrder=8;scene.add(traj);
let aimLock=null,aimTof=0,zf=0,zoomOn=false,aimSlow=1,lastP=0,aimS=null,aimTxt=-1;
function predict(){
  const d=dirOf(player.yaw,player.pitch);player.bp.getWorldPosition(v1);v1.addScaledVector(d,player.mz||4.3);d.multiplyScalar(SPEED);
  let n=0,tof=0;trajP[0]=v1.x;trajP[1]=v1.y;trajP[2]=v1.z;
  if(player.stry){d.normalize();for(let i=0;i<500;i++){v1.addScaledVector(d,8);tof+=8/TOWV;if(i%9===8&&n<59){n++;trajP[n*3]=v1.x;trajP[n*3+1]=v1.y;trajP[n*3+2]=v1.z}if(v1.y<Math.max(getH(v1.x,v1.z),WATER)||Math.hypot(v1.x-player.x,v1.z-player.z)>TOWR)break}}else for(let i=0;i<300;i++){const ox=v1.x,oy=v1.y,oz=v1.z;d.y-=G/30;v1.addScaledVector(d,1/30);tof+=1/30;if(i%5===4&&n<59){n++;trajP[n*3]=v1.x;trajP[n*3+1]=v1.y;trajP[n*3+2]=v1.z}if(v1.y<getH(v1.x,v1.z)){const a0=oy-getH(ox,oz),a1=v1.y-getH(v1.x,v1.z),f=a0/((a0-a1)||1);if(f>0&&f<1){v1.set(ox+(v1.x-ox)*f,oy+(v1.y-oy)*f,oz+(v1.z-oz)*f);tof-=(1-f)/30}break}}
  n++;trajP[n*3]=v1.x;trajP[n*3+1]=v1.y;trajP[n*3+2]=v1.z;trajG.setDrawRange(0,n+1);trajG.attributes.position.needsUpdate=true;traj.visible=true;
  mark.position.set(v1.x,v1.y+.3,v1.z);mark.visible=false;impact.copy(v1);aimTof=tof;
  const now=performance.now()/1000,dp=now-(lastP||now);lastP=now;
  for(const t of tanks){if(dp>0&&dp<.5){const k=Math.min(1,dp*6);t.vx=(t.vx||0)+((t.x-(t.px===undefined?t.x:t.px))/dp-(t.vx||0))*k;t.vz=(t.vz||0)+((t.z-(t.pz===undefined?t.z:t.pz))/dp-(t.vz||0))*k}t.px=t.x;t.pz=t.z}
  let best=null,bd=16;
  for(const t of tanks){if(t.dead||t===player||!hostile(player,t))continue;const dd=Math.hypot(t.x-v1.x,t.z-v1.z);if(dd<bd){bd=dd;best=t}}
  aimLock=best;aimSlow=best?.6:1;
}
const retEl=document.getElementById('ret'),leadEl=document.getElementById('lead'),rdEl=document.getElementById('rdist');
function toScr(x,y,z){pv.set(x,y,z).project(cam);return pv.z<1&&Math.abs(pv.x)<1.2&&Math.abs(pv.y)<1.2?[(pv.x*.5+.5)*innerWidth,(-pv.y*.5+.5)*innerHeight]:null}
/* mira: reticulo se move ate onde o tiro cai, trava no inimigo, mostra distancia, ponto de antecipacao e zoom */
let aimTxt_l=null;const crossEl=document.getElementById('cross');
function drawAim(dt){
  if(player.dead){retEl.style.display=leadEl.style.display='none';crossEl.style.display='';return}
  zf+=((zoomOn||keys.ShiftLeft||keys.ShiftRight?1:0)-zf)*Math.min(1,dt*9);
  cam.fov=(innerWidth<innerHeight?72:60)-(player.ku?40:30)*zf;cam.updateProjectionMatrix();cam.updateMatrixWorld();
  const sp=toScr(impact.x,impact.y+.3,impact.z);
  if(sp){if(!aimS||Math.hypot(sp[0]-aimS[0],sp[1]-aimS[1])>260)aimS=[sp[0],sp[1]];else{const k=1-Math.exp(-dt*26);aimS[0]+=(sp[0]-aimS[0])*k;aimS[1]+=(sp[1]-aimS[1])*k}
    retEl.style.display='block';retEl.style.transform='translate('+aimS[0].toFixed(1)+'px,'+aimS[1].toFixed(1)+'px)';retEl.classList.toggle('lock',!!aimLock);crossEl.style.display='none';
    const dm=Math.round(Math.hypot(impact.x-player.x,impact.z-player.z)/2)*2;if(dm!==aimTxt||aimLock!==aimTxt_l){aimTxt=dm;aimTxt_l=aimLock;rdEl.textContent=dm+' m'+(aimLock?' · alvo':'')}}
  else{retEl.style.display='none';crossEl.style.display='';aimS=null}
  let ls=null;
  if(aimLock&&Math.hypot(aimLock.vx||0,aimLock.vz||0)>1.2){
    const lx=aimLock.x+aimLock.vx*aimTof,lz=aimLock.z+aimLock.vz*aimTof;ls=toScr(lx,getH(lx,lz)+2,lz);
    if(document.body.classList.contains('t')){const want=Math.atan2(lx-player.x,lz-player.z);player.yaw+=clamp(angDiff(want,player.yaw),-.5*dt,.5*dt)}
  }
  if(ls){leadEl.style.display='block';leadEl.style.transform='translate('+ls[0].toFixed(1)+'px,'+ls[1].toFixed(1)+'px) rotate(45deg)'}else leadEl.style.display='none';
}
function camUpdate(){
  const AR=player.air;let fx=player.x,fy=player.y+(player.corv?6:3.2),fz=player.z;
  if(AR){ /* câmera do helicóptero: acompanha com suavização e olha para baixo sem travar */
    const n=performance.now(),dq=Math.min(.05,(n-(camUpdate.t||n))/1000),k=1-Math.exp(-dq*9),k2=1-Math.exp(-dq*5);camUpdate.t=n;
    if(camUpdate.o!==player||Math.hypot(camUpdate.fx-fx,camUpdate.fz-fz)>40){camUpdate.fx=fx;camUpdate.fy=fy;camUpdate.fz=fz}
    camUpdate.o=player;camUpdate.fx+=(fx-camUpdate.fx)*k;camUpdate.fz+=(fz-camUpdate.fz)*k;camUpdate.fy+=(fy-camUpdate.fy)*k2;fx=camUpdate.fx;fy=camUpdate.fy;fz=camUpdate.fz;
  }
  const d=dirOf(player.yaw,AR?clamp(player.pitch,-.5,.45):clamp(player.pitch,-.2,.5)),a=dirOf(player.yaw,player.pitch);
  const CD=(AR?24+(player.cdx||0):player.corv?36:17)*(innerWidth<innerHeight?1.2:1)-8*zf;let cx=fx-d.x*CD,cy=fy-d.y*CD+(AR?4.5:3),cz=fz-d.z*CD;cy=Math.max(cy,getH(cx,cz)+2.2);
  cam.position.set(cx+(Math.random()-.5)*shake,cy+(Math.random()-.5)*shake,cz+(Math.random()-.5)*shake);
  cam.lookAt(fx+a.x*40,fy+a.y*40,fz+a.z*40);
  sun.position.set(player.x+sunV.x,player.y+sunV.y,player.z+sunV.z);sun.target.position.set(player.x,player.y,player.z);
}
/* ---------- pontes: onde uma estrada atravessa agua funda (cada trecho de ~18 m pode ser destruido) ---------- */
const bridges=[],brMat=new THREE.MeshLambertMaterial({color:0x8b8d8f}),brRail=new THREE.MeshLambertMaterial({color:0x6b6e70}),brLn=new THREE.MeshBasicMaterial({color:0xe8e2c8}),brBox=new THREE.BoxGeometry(1,1,1),brCyl=new THREE.CylinderGeometry(.5,.6,1,8),SECP=6,brDebM=new THREE.MeshLambertMaterial({color:0x8b8d8f});
function makeBridge(seg,yFix){
  const n=seg.length,yA=getH(seg[0].x,seg[0].z)+.12,yB=getH(seg[n-1].x,seg[n-1].z)+.12,P=[],secs=[],segSec=[];
  let x0=1e9,x1=-1e9,z0=1e9,z1=-1e9;
  seg.forEach((q,k)=>{const u=k/(n-1);P.push({x:q.x,z:q.z,y:yFix!==undefined?yFix:yA+(yB-yA)*u+Math.sin(Math.PI*u)*1.1});x0=Math.min(x0,q.x);x1=Math.max(x1,q.x);z0=Math.min(z0,q.z);z1=Math.max(z1,q.z)});
  const add=(sec,geo,mat,x,y,z,sx,sy,sz,yaw,pit)=>{const m=new THREE.Mesh(geo,mat);m.rotation.order='YXZ';m.position.set(x,y,z);m.scale.set(sx,sy,sz);m.rotation.y=yaw;m.rotation.x=pit;m.castShadow=true;m.receiveShadow=true;scene.add(m);sec.m.push(m)};
  for(let k=0;k<n-1;k+=2){
    const si=Math.floor(k/2/SECP);
    if(!secs[si])secs[si]={hp:150,hp0:150,alive:true,m:[],cx:0,cy:0,cz:0,n:0,k0:si*2*SECP,k1:(si+1)*2*SECP};
    const sec=secs[si],a=P[k],c=P[Math.min(k+2,n-1)],dx=c.x-a.x,dz=c.z-a.z,dy=c.y-a.y,L=Math.hypot(dx,dz);if(L<.5)continue;
    const yaw=Math.atan2(dx,dz),pit=-Math.atan2(dy,L),mx=(a.x+c.x)/2,mz=(a.z+c.z)/2,my=(a.y+c.y)/2,rx=Math.cos(yaw),rz=-Math.sin(yaw);
    sec.cx+=mx;sec.cy+=my;sec.cz+=mz;sec.n++;
    add(sec,brBox,brMat,mx,my-.25,mz,7.2,.5,L+.2,yaw,pit);
    add(sec,brBox,brLn,mx,my+.03,mz,.22,.04,L*.55,yaw,pit);
    for(const sd of[-1,1])add(sec,brBox,brRail,mx+rx*3.4*sd,my+.5,mz+rz*3.4*sd,.28,.95,L+.1,yaw,pit);
    if((k/2)%3===1)for(const sd of[-1,1]){const px=mx+rx*2.4*sd,pz=mz+rz*2.4*sd,top=my-.5,bot=getH(px,pz)-.6;if(top>bot)add(sec,brCyl,brRail,px,(top+bot)/2,pz,1.1,top-bot,1.1,0,0)}
  }
  for(const sc of secs)if(sc){sc.cx/=sc.n||1;sc.cy/=sc.n||1;sc.cz/=sc.n||1}
  for(let k=0;k<n-1;k++)segSec[k]=secs[Math.floor(k/2/SECP)];
  bridges.push({pts:P,x0:x0-5,x1:x1+5,z0:z0-5,z1:z1+5,secs,segSec});
}
for(const pts of roads){
  let i=0;
  while(i<pts.length){
    if(getH(pts[i].x,pts[i].z)<WATER+1.3){
      let j=i,deep=false;while(j<pts.length&&getH(pts[j].x,pts[j].z)<WATER+1.3){if(getH(pts[j].x,pts[j].z)<WATER-.4)deep=true;j++}
      if(deep&&i>0&&j<pts.length&&j-i>=4&&j-i<=110)makeBridge(pts.slice(i-1,j+1));
      i=j;
    }else i++;
  }
}
/* piers dos portos: tabuleiro reto e plano que avanca sobre o mar */
for(const j of pierJobs){const L=Math.hypot(j.x1-j.x0,j.z1-j.z0),n=Math.ceil(L/1.5),seg=[];for(let q=0;q<=n;q++)seg.push({x:j.x0+(j.x1-j.x0)*q/n,z:j.z0+(j.z1-j.z0)*q/n});makeBridge(seg,j.h+.05)}
/* altura do chao para veiculos: considera o tabuleiro das pontes que ainda estao de pe */
function getHV(x,z){
  let h=getH(x,z);
  for(const b of bridges){
    if(x<b.x0||x>b.x1||z<b.z0||z>b.z1)continue;
    const P=b.pts;
    for(let k=0;k<P.length-1;k++){
      const sec=b.segSec[k];if(!sec||!sec.alive)continue;
      const a=P[k],c=P[k+1],dx=c.x-a.x,dz=c.z-a.z,l2=dx*dx+dz*dz||1,ru=((x-a.x)*dx+(z-a.z)*dz)/l2;
      if(ru<0&&k>0&&b.segSec[k-1]&&!b.segSec[k-1].alive)continue;
      if(ru>1&&k<P.length-2&&b.segSec[k+1]&&!b.segSec[k+1].alive)continue;
      const u=ru<0?0:ru>1?1:ru,px=a.x+dx*u-x,pz=a.z+dz*u-z;
      if(px*px+pz*pz<12.6){const y=a.y+(c.y-a.y)*u;if(y>h)h=y;break}
    }
  }
  return h;
}
/* tiro que bate no tabuleiro: devolve o trecho atingido */
function bridgeHit(x,y,z){
  for(const b of bridges){
    if(x<b.x0||x>b.x1||z<b.z0||z>b.z1)continue;
    const P=b.pts;
    for(let k=0;k<P.length-1;k++){
      const sec=b.segSec[k];if(!sec||!sec.alive)continue;
      const a=P[k],c=P[k+1],dx=c.x-a.x,dz=c.z-a.z,l2=dx*dx+dz*dz||1;let u=((x-a.x)*dx+(z-a.z)*dz)/l2;u=u<0?0:u>1?1:u;
      const px=a.x+dx*u-x,pz=a.z+dz*u-z;
      if(px*px+pz*pz<13){const yy=a.y+(c.y-a.y)*u;if(y<yy+.8&&y>yy-1.8)return sec}
    }
  }
  return null;
}
function breakSec(b,sec,owner){
  sec.alive=false;for(const m of sec.m)scene.remove(m);
  for(let i=0;i<16;i++){const m=new THREE.Mesh(dg,brDebM),sc=.5+Math.random()*1.3;m.scale.set(sc*1.5,sc*.5,sc);m.castShadow=true;m.position.set(sec.cx+(Math.random()-.5)*14,sec.cy+Math.random()*1.5,sec.cz+(Math.random()-.5)*14);m.rotation.set(Math.random()*3,Math.random()*3,0);scene.add(m);debris.push({m,s:sc,t:10,v:new THREE.Vector3((Math.random()-.5)*10,3+Math.random()*7,(Math.random()-.5)*10)})}
  for(let i=0;i<12;i++){v3.set(sec.cx+(Math.random()-.5)*14,sec.cy,sec.cz+(Math.random()-.5)*14);puff(v3,i%3?0xb9b0a0:0x4a4a48,3,8,2.4,3)}
  for(let i=0;i<8;i++){v3.set(sec.cx+(Math.random()-.5)*14,WATER+.2,sec.cz+(Math.random()-.5)*14);puff(v3,i%2?0xe6f3fa:0xb7d8ea,2.4,6,1,6)}
  v3.set(sec.cx,sec.cy,sec.cz);shake=Math.max(shake,2.2*near(v3));sfx(near(v3),.9);
  for(const t of tanks){
    if(t.dead||t.air)continue;let on=false;
    for(let k=sec.k0;k<=sec.k1&&k<b.pts.length;k++){const q=b.pts[k];if(Math.hypot(q.x-t.x,q.z-t.z)<5){on=true;break}}
    if(on&&t.y>sec.cy-2.5){splash(v3.set(t.x,WATER,t.z));t.v*=.2;damage(t,55,owner);if(t.isPlayer)toast('A ponte desabou!')}
  }
  while(debris.length>260){const o=debris.shift();scene.remove(o.m)}
  if(owner&&owner.isPlayer)toast('Ponte destruída!');
}
function bridgeBlast(p,R,k,owner){
  for(const b of bridges){
    if(p.x<b.x0-R||p.x>b.x1+R||p.z<b.z0-R||p.z>b.z1+R)continue;
    for(const sec of b.secs){
      if(!sec||!sec.alive)continue;
      const d=Math.hypot(p.x-sec.cx,(p.y-sec.cy)*.7,p.z-sec.cz),reach=R+10;
      if(d<reach){sec.hp-=130*k*(1-d/reach);if(sec.hp<=0)breakSec(b,sec,owner);else if(Math.random()<.6){v3.set(sec.cx+(Math.random()-.5)*10,sec.cy+.5,sec.cz+(Math.random()-.5)*10);puff(v3,0x4a4a48,2,3,1.6,2)}}
    }
  }
}
/* cobertura: linha de visada bloqueada por morros ou predios */
function los(ax,ay,az,bx,by,bz){
  for(let i=1;i<14;i++){const u=i/14,x=ax+(bx-ax)*u,y=ay+(by-ay)*u,z=az+(bz-az)*u;if(getH(x,z)>y)return false;
    for(const b of buildings)if(b.hp>0&&Math.abs(x-b.x)<b.w/2&&Math.abs(z-b.z)<b.d/2&&y<b.y+b.h)return false}
  return true;
}
function pickCover(t,o){
  const ey=o.y+2.2;t.cvx=undefined;
  for(const r of[10,18,26]){
    for(let k=0;k<10;k++){
      const a=k/10*6.283+Math.random()*.3,x=t.x+Math.cos(a)*r,z=t.z+Math.sin(a)*r,h=getH(x,z);
      if(h<1.5||Math.hypot(x,z)>HALF-25||Math.abs(getH(x+3,z)-getH(x-3,z))>2.5||Math.hypot(x-o.x,z-o.z)>175)continue;
      if(!los(o.x,ey,o.z,x,h+2.2,z)){t.cvx=x;t.cvz=z;return}
    }
  }
}

const MM=440,mini=document.getElementById('mini'),mc=mini.getContext('2d'),bg=document.createElement('canvas');bg.width=bg.height=MM;mini.width=mini.height=MM;
/* mapa: relevo sombreado, agua com profundidade, praias, florestas e estradas (desenhados uma vez) */
{const c=bg.getContext('2d'),im=c.createImageData(MM,MM),L=(a,b,u)=>a+(b-a)*u;
  for(let py=0;py<MM;py++)for(let px=0;px<MM;px++){
    const x=px/MM*SIZE-HALF,z=py/MM*SIZE-HALF,h=getH(x,z),o=(py*MM+px)*4;let r,g,b;
    if(h<WATER){const d=clamp((WATER-h)/22,0,1);r=L(86,24,d);g=L(172,92,d);b=L(208,142,d)}
    else if(h<1.3){r=224;g=210;b=152}
    else{const sh=1+clamp((getH(x-4,z-4)-getH(x+4,z+4))*.07,-.3,.3);r=(88+h*2.2)*sh;g=(134+h*1.6)*sh;b=(64+h*.9)*sh;const bm=biomeAt(x,z);if(bm.s>0){r=L(r,235,bm.s*.85);g=L(g,240,bm.s*.85);b=L(b,246,bm.s*.85)}if(bm.d>0){r=L(r,214,bm.d*.8);g=L(g,176,bm.d*.8);b=L(b,110,bm.d*.8)}}
    im.data[o]=r;im.data[o+1]=g;im.data[o+2]=b;im.data[o+3]=255}
  c.putImageData(im,0,0);const f=MM/SIZE;
  c.fillStyle='rgba(25,80,35,.75)';for(const q of trees)c.fillRect((q.x+HALF)*f-.7,(q.z+HALF)*f-.7,1.5,1.5);
  c.lineWidth=1.8;c.lineJoin='round';c.strokeStyle='#cdbd92';
  for(const pts of roads){c.beginPath();let on=false;for(let i=0;i<pts.length;i+=3){const q=pts[i];if(getH(q.x,q.z)<-1.5){on=false;continue}const X=(q.x+HALF)*f,Y=(q.z+HALF)*f;if(on)c.lineTo(X,Y);else{c.moveTo(X,Y);on=true}}c.stroke()}
  c.fillStyle='#6b6e72';for(const sp of specials)if(sp.type==='aero')c.fillRect((sp.x-85+HALF)*f,(sp.z-8+HALF)*f,170*f,16*f);
  c.font='700 15px sans-serif';c.textAlign='center';c.textBaseline='middle';c.lineWidth=3;c.strokeStyle='rgba(0,0,0,.75)';
  for(const sp of specials){const gl=sp.type==='base'?'★':sp.type==='port'?'⚓':'✈',X=(sp.x+HALF)*f,Y=(sp.z+HALF)*f;c.strokeText(gl,X,Y);c.fillStyle='#fff';c.fillText(gl,X,Y)}}
function drawMini(){
  mc.drawImage(bg,0,0);const f=MM/SIZE,k=MM/Math.max(60,mini.clientWidth),X=x=>(x+HALF)*f;
  mc.lineCap='butt';mc.lineJoin='round';
  for(const br of bridges)for(const sc of br.secs){
    if(!sc)continue;
    if(!sc.alive){mc.fillStyle='#ff4a3a';mc.fillRect(X(sc.cx)-2.2*k,X(sc.cz)-2.2*k,4.4*k,4.4*k);continue}
    mc.strokeStyle='#8a6a45';mc.lineWidth=2.6*k;mc.beginPath();const e=Math.min(sc.k1+1,br.pts.length-1);
    for(let i=sc.k0;i<=e;i+=2){const q=br.pts[i];if(i===sc.k0)mc.moveTo(X(q.x),X(q.z));else mc.lineTo(X(q.x),X(q.z))}
    mc.stroke();
  }
  mc.fillStyle='#7d838a';for(const b of buildings)if(b.hp>0){const w=Math.max(2*k,b.w*f),d=Math.max(2*k,b.d*f);mc.fillRect(X(b.x)-w/2,X(b.z)-d/2,w,d)}
  for(const c of crates){mc.fillStyle=c.kind==='rep'?'#5cff7a':'#ffd040';mc.strokeStyle='#000';mc.lineWidth=1*k;mc.fillRect(X(c.x)-3*k,X(c.z)-3*k,6*k,6*k);mc.strokeRect(X(c.x)-3*k,X(c.z)-3*k,6*k,6*k)}
  mc.lineWidth=1.5*k;mc.setLineDash([5*k,4*k]);
  for(const tm of[1,2,3,4,5]){const z=zones[tm];if(!z)continue;mc.strokeStyle=tm===5?'rgba(255,122,200,.95)':tm===4?'rgba(176,108,255,.95)':tm===2?'rgba(74,163,255,.9)':tm===3?'rgba(63,210,90,.95)':'rgba(214,69,47,.9)';mc.beginPath();mc.arc(X(z.x),X(z.z),62*f,0,7);mc.stroke()}
  mc.setLineDash([]);
  for(const t of tanks){if(t.dead||t.isPlayer)continue;mc.fillStyle=t.idle?'#9fb0bd':t.ally?'#f3ecd8':t.team===5?'#ff7ac8':t.team===4?'#b06cff':t.team===2?'#4aa3ff':t.team===3?'#3fd25a':'#d6452f';mc.beginPath();mc.arc(X(t.x),X(t.z),3.2*k,0,7);mc.fill();mc.strokeStyle=t.team===3?'#ffd400':'rgba(0,0,0,.65)';mc.lineWidth=1*k;mc.stroke()}
  if(!player.dead){
    const px=X(player.x),pz=X(player.z),a=Math.atan2(Math.cos(player.yaw),Math.sin(player.yaw));
    mc.fillStyle='rgba(255,200,60,.25)';mc.beginPath();mc.moveTo(px,pz);mc.arc(px,pz,150*f,a-.5,a+.5);mc.closePath();mc.fill();
    mc.fillStyle='#ffb000';mc.strokeStyle='#1b1d12';mc.lineWidth=1.2*k;mc.beginPath();
    mc.moveTo(px+Math.cos(a)*7*k,pz+Math.sin(a)*7*k);mc.lineTo(px+Math.cos(a+2.5)*5.5*k,pz+Math.sin(a+2.5)*5.5*k);mc.lineTo(px+Math.cos(a-2.5)*5.5*k,pz+Math.sin(a-2.5)*5.5*k);mc.closePath();mc.fill();mc.stroke();
  }
  mc.fillStyle='#fff';mc.font='700 '+(11*k)+'px sans-serif';mc.textAlign='center';mc.shadowColor='#000';mc.shadowBlur=3*k;mc.fillText('N',MM/2,13*k);mc.shadowBlur=0;
}
const toggleMap=()=>mini.classList.toggle('big');
mini.addEventListener('touchstart',e=>{e.stopPropagation();e.preventDefault();toggleMap()},{passive:false});
mini.addEventListener('mousedown',e=>e.stopPropagation());mini.addEventListener('click',toggleMap);
addEventListener('keydown',e=>{if(e.code==='KeyM')toggleMap()});

/* ---------- laco principal ---------- */
const hpEl=document.querySelector('#hp i'),rlEl=document.querySelector('#rl i'),hurtEl=document.getElementById('hurt');let frame=0;const towR=document.getElementById('towR'),towN=document.getElementById('towN');let towOn=false,towS='';
function update(dt){
  netTick(dt);extras(dt);
  if(!player.dead){
    drive(player,dt,(keys.KeyW?1:0)-(keys.KeyS?1:0)||(Math.abs(stick.y)>.15?-stick.y:0),(keys.KeyA?1:0)-(keys.KeyD?1:0)||(Math.abs(stick.x)>.15?-stick.x:0));
    player.yaw+=((keys.ArrowLeft||keys.KeyQ?1:0)-(keys.ArrowRight||keys.KeyE?1:0))*1.3*dt;
    player.pitch=clamp(player.pitch+((keys.ArrowUp?1:0)-(keys.ArrowDown?1:0))*.7*dt,player.air?-.9:-.15,.75);
    player.cd-=dt;if((firing||keys.Space)&&player.cd<=0){player.cd=(player.abv?7:player.astros?6:player.rld||1.8)*(ammoT>0?.5:1)*(player.cperk?1-player.cperk.rld:1);fire(player);if(NET.guest)netSend({t:'fi'})}
    if(player.h225){padPoll(dt);player.c2=(player.c2||0)-dt;if(player.c2<=0&&keys.KeyG){player.c2=3.2;player.sv=4;player.sT=0}}
    if(player.ch47){padPoll(dt);player.c2=(player.c2||0)-dt;if(player.c2<=0&&keys.KeyG&&chDrop(player))player.c2=.5}
    if(player.ap){padPoll(dt);player.c2=(player.c2||0)-dt;if(player.c2<=0){if(keys.KeyG){player.c2=3.2;player.sv=4;player.sT=0}else if(keys.KeyH&&apHell(player))player.c2=5}}
  }
  let alive=0;if(!NET.guest)shipCapture();
  for(const t of tanks){if(t.tx!==undefined)netSmooth(t,dt);if(t.ai&&!t.dead){ai(t,dt);if(!t.ally)alive++}if(t.cp&&!t.dead)cpTick(t,dt);if(!t.dead||!t.placed){place(t);t.placed=t.dead;if(t.cp&&!t.dead)cpPost(t)}if(!t.dead&&!t.air&&!t.corv)stamp(t,dt);if(!t.aerr)try{animTank(t,dt)}catch(e){t.aerr=1;showErr('anim '+vname(t),e)}}
  for(let i=shells.length-1;i>=0;i--){
    const s=shells[i],p=s.m.position,ox=p.x,oy=p.y,oz=p.z;
    if(s.hm){const q=s.hm;if(q.dead)s.hm=null;else{const dx=q.x-p.x,dy=q.y+1.5-p.y,dz=q.z-p.z,L=Math.hypot(dx,dy,dz)||1,sp=Math.hypot(s.v.x,s.v.y,s.v.z)||1,kk=Math.min(1,dt*3.2);s.v.x+=(dx/L*sp-s.v.x)*kk;s.v.y+=(dy/L*sp-s.v.y)*kk+G*dt;s.v.z+=(dz/L*sp-s.v.z)*kk}}
    if(s.tow)towGuide(s,dt);
    s.v.y-=G*dt;p.addScaledVector(s.v,dt);s.age+=dt;if(s.tow)towFx(s);
    if(s.spin){s.m.rotation.x+=s.spin*dt;s.m.rotation.z+=s.spin*.7*dt;s.tt=(s.tt||0)-dt;if(s.tt<=0){s.tt=.06;puff(p,0xd8d4c8,.5,.5,.5,.2)}}
    if(s.rk||s.tr){s.m.lookAt(p.x+s.v.x,p.y+s.v.y,p.z+s.v.z);s.tt-=dt;if(s.tt<=0){s.tt=s.tr?.025:.05;if(s.tr)puff(p,0xffa040,.4,.3,.22,0);else puff(p,0xe8e4dc,.55,.6,.7,.2)}}
    let hit=p.y<getH(p.x,p.z);
    if(!hit){ /* varredura: o tiro nao atravessa mais construcoes finas, mesmo com FPS baixo */
      const SL=Math.hypot(p.x-ox,p.y-oy,p.z-oz),SN=Math.max(1,Math.ceil(SL/1.1));
      sweep:for(let k=1;k<=SN;k++){const u=k/SN,qx=ox+(p.x-ox)*u,qy=oy+(p.y-oy)*u,qz=oz+(p.z-oz)*u;
        for(const b of buildings)if(Math.abs(qx-b.x)<b.w/2&&Math.abs(qz-b.z)<b.d/2&&qy<b.y+b.h&&qy>b.y-2){p.set(qx,qy,qz);hit=true;break sweep}
        if(bridgeHit(qx,qy,qz)){p.set(qx,qy,qz);hit=true;break sweep}}
    }
    if(!hit)for(const q of trees)if(Math.hypot(p.x-(q.cx===undefined?q.x:q.cx),p.z-(q.cz===undefined?q.z:q.cz))<(q.st===2?2.2:1.3)&&p.y<getH(q.x,q.z)+(q.st===2?1.5:(q.H||8)*.9)){hit=true;break}
    if(!hit)for(const t of tanks)if(hostile(t,s.owner)&&!t.dead&&Math.hypot(p.x-t.x,p.z-t.z)<((t.air||t.corv)?(t.hr||4.5):2.8)&&Math.abs(p.y-t.y-((t.air||t.corv)?(t.hc||2.2):1.2))<((t.air||t.corv)?(t.hh||2.6):2.2)){hit=true;break}
    let wh=false;if(!hit&&p.y<WATER){hit=true;wh=true}
    if(hit||p.y<-30||s.age>(s.life||12)){scene.remove(s.m);if(s.wire){scene.remove(s.wire);s.wire.geometry.dispose()}shells.splice(i,1);if(wh)splash(p);else if(p.y>-30){if(s.line)lineCharge(p.clone(),s);else boom(p.clone(),s.owner,s.k||1)}}
  }
  for(const q of trees){
    if(q.st===1){q.w+=dt*5;q.a+=q.w*dt;
      if(q.a>=1.35){q.a=1.35;q.st=2;q.t=1.2;const sc=q.g.scale.x;q.cx=q.x+Math.sin(q.g.rotation.y)*4.2*sc;q.cz=q.z+Math.cos(q.g.rotation.y)*4.2*sc;
        puff(v1.set(q.cx,getH(q.cx,q.cz)+.5,q.cz),0x8a7a5a,1.6,3,.8,1);shake=Math.max(shake,.4*near(q))}
      q.g.rotation.x=q.a;q.g.position.y=getH(q.x,q.z)+Math.sin(q.a)*.4}
    else if(q.st===2&&q.t>0)q.t-=dt;
  }
  for(let i=parts.length-1;i>=0;i--){
    const o=parts[i];o.life-=dt;o.m.position.addScaledVector(o.v,dt);o.v.multiplyScalar(.96);
    o.m.scale.setScalar(o.size*(1+(1-o.life/o.max)*1.5));o.m.material.opacity=Math.max(0,o.life/o.max*.9);
    if(o.life<=0){scene.remove(o.m);if(pPool.length<500)pPool.push(o.m);else o.m.material.dispose();parts.splice(i,1)}
  }
  for(let i=debris.length-1;i>=0;i--){
    const o=debris[i],p=o.m.position;o.v.y-=G*dt;p.addScaledVector(o.v,dt);o.t-=dt;
    const gh=getH(p.x,p.z)+o.s*.3;
    if(p.y<gh){p.y=gh;if(Math.abs(o.v.y)>3)o.v.y*=-.3;else o.v.set(0,0,0);o.v.x*=.7;o.v.z*=.7}
    if(o.v.lengthSq()>1){o.m.rotation.x+=dt*3;o.m.rotation.z+=dt*2}
    if(o.t<=0){scene.remove(o.m);debris.splice(i,1)}
  }
  if(started&&alive===0&&(!player.dead||NET.host)&&!NET.guest){waveEnd();wave++;document.getElementById('wv').textContent=wave;spawnWave();for(let n=tanks.filter(q=>q.ally&&!q.dead).length;n<3;n++)spawnAlly();toast('Onda '+wave+': '+5*(1+Math.ceil(wave/2))+' veículos, vermelhos, azuis, verde e amarelo, roxos e rosas em combate')}
  shake*=Math.pow(.02,dt);hurt=Math.max(0,hurt-dt*1.5);hurtEl.style.opacity=hurt;
  hpEl.style.width=Math.max(0,player.hp/mhpOf(player)*100)+'%';rlEl.style.width=clamp((1-Math.max(0,player.cd)/(player.abv?7:player.astros?6:player.rld||1.8))*100,0,100)+'%';
  {const on=!!player.stry;if(on!==towOn){towOn=on;towR.style.display=on?'flex':'none'}if(on){const q=player.tow+' / 12 · prontos '+player.rdy.filter(Boolean).length;if(q!==towS){towS=q;towN.textContent=q}}}
  cpHud(dt);CPFX.upd(dt);
  if(!player.dead)predict();else{mark.visible=false;traj.visible=false}
  if(frame++%4===0)drawMini();
}
/* ---------- toque ---------- */
if(matchMedia('(pointer:coarse)').matches||'ontouchstart' in window)document.body.classList.add('t');
const joy=document.getElementById('joy'),knob=document.getElementById('knob'),fireB=document.getElementById('fire'),stick={x:0,y:0};
let jid=null,aid=null,fid=null,jc=[0,0],al=[0,0];
function moveJoy(t){const rc=joy.getBoundingClientRect(),sc=rc.width/(joy.offsetWidth||130),R=.385*rc.width,dx=clamp(t.clientX-jc[0],-R,R),dy=clamp(t.clientY-jc[1],-R,R);stick.x=dx/R;stick.y=dy/R;knob.style.transform='translate('+dx/sc+'px,'+dy/sc+'px)'}
addEventListener('touchstart',e=>{
  if(!running)return;
  for(const t of e.changedTouches){
    if(t.target.className==='abtn')continue;
    if(t.target===fireB){firing=true;fid=t.identifier;continue}
    const r=joy.getBoundingClientRect();
    if(jid===null&&(player.air?(t.clientX<innerWidth*.45&&t.clientY>innerHeight*.28):(t.clientX<r.right+40&&t.clientX<innerWidth*.45&&t.clientY>r.top-40))){jid=t.identifier;if(player.air){const w=r.width,h=r.height;joy.style.left=clamp(t.clientX-w/2,6,Math.max(6,innerWidth*.45-w))+'px';joy.style.bottom=clamp(innerHeight-t.clientY-h/2,6,Math.max(6,innerHeight-h-6))+'px';const r2=joy.getBoundingClientRect();jc=[r2.left+r2.width/2,r2.top+r2.height/2]}else jc=[r.left+r.width/2,r.top+r.height/2];moveJoy(t)}
    else if(aid===null){aid=t.identifier;al=[t.clientX,t.clientY]}
  }
  e.preventDefault();
},{passive:false});
addEventListener('touchmove',e=>{
  if(!running)return;
  for(const t of e.changedTouches){
    if(t.identifier===jid)moveJoy(t);
    else if(t.identifier===aid){const k=aimSlow*(player.air?clamp(430/Math.min(innerWidth,innerHeight),.5,1.2):1);player.yaw-=(t.clientX-al[0])*.006*k;player.pitch=clamp(player.pitch-(t.clientY-al[1])*.004*k,player.air?-.9:-.15,.75);al=[t.clientX,t.clientY]}
  }
  e.preventDefault();
},{passive:false});
function tend(e){for(const t of e.changedTouches){
  if(t.identifier===jid){jid=null;stick.x=stick.y=0;knob.style.transform='';joy.style.left='';joy.style.bottom=''}
  if(t.identifier===aid)aid=null;
  if(t.identifier===fid){fid=null;firing=false}
}}
addEventListener('touchend',tend);addEventListener('touchcancel',tend);
place(player);camUpdate();
const menuCard=document.querySelector('#start .card'),vnEl=document.getElementById('vname');
