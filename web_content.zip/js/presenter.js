/* يمكن هدف؟ — cartoon presenters: each kind of analysis has its own character */
(function () {
  const ANALYSTS = [
    { id: 1, name: 'كابتن رعد', role: 'مقدّم الاستوديو', tone: '#8b5cf6' },
    { id: 2, name: 'الكوتش هادي', role: 'خبير الخطط والتشكيلات', tone: '#ef4444' },
    { id: 3, name: 'المحللة ليان', role: 'محللة الأرقام', tone: '#14b8a6' },
    { id: 4, name: 'الحارس صخر', role: 'خبير الدفاع والضغط', tone: '#f97316' },
    { id: 5, name: 'الجناح برق', role: 'خبير الأطراف والهجمات المرتدة', tone: '#22c55e' },
    { id: 6, name: 'البروفيسور نوّار', role: 'عقل التوقعات', tone: '#a16207' },
    { id: 7, name: 'الهدّاف شهاب', role: 'خبير الأهداف', tone: '#a855f7' },
  ].map(a => ({ ...a, img: `assets/toon${a.id}.webp`, head: `assets/toon${a.id}-head.webp` }));

  /* which character explains which scene */
  const RULES = [
    [7, /^إعادة الهدف|نجم|مناطق التسديد|الهدف/],
    [6, /^كيف|توقعي|مفتاح المواجهة|نقاط التحوّل/],
    [3, /xG|الأهداف المتوقعة|من سيطر|أرقام المباراة|الشوط/],
    [4, /الضغط|الدفاع|الطرد|الكرات الثابتة|البطاقات/],
    [5, /الأطراف|الكرات الطويلة|التحولات|المرتدة/],
    [2, /تشكيلة|شلون يلعب|المواجهة التكتيكية|البناء|الخلاصة|التبديلات/],
  ];
  const forScene = t => { for (const [id, re] of RULES) if (re.test(t || '')) return id; return 1; };
  const byId = id => ANALYSTS.find(a => a.id === id) || ANALYSTS[0];

  function create(host) {
    host.innerHTML = `<div class="pr"><i class="pr-glow" aria-hidden="true"></i><img class="pr-img" alt="" draggable="false"></div>`;
    const img = host.querySelector('.pr-img'), root = host.querySelector('.pr');
    let A = ANALYSTS[0];
    // preload every character once so switching is instant
    ANALYSTS.forEach(a => { const i = new Image(); i.src = a.img; });
    function set(id) {
      const N = byId(id); const changed = N !== A || !img.src; A = N;
      root.dataset.a = A.id; root.style.setProperty('--tone', A.tone);
      if (changed) { root.classList.remove('swap'); void root.offsetWidth; img.src = A.img; img.alt = A.name; root.classList.add('swap'); }
      return A;
    }
    function talk(on) { root.classList.toggle('talking', on); }
    function gesture() { root.classList.remove('gest'); void root.offsetWidth; root.classList.add('gest'); }
    function destroy() {}
    set(1);
    return { set, talk, gesture, destroy, get analyst() { return A; } };
  }
  YH.presenter = { create, ANALYSTS, forScene, byId };
})();
