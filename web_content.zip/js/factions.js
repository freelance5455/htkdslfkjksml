// ===== FACTIONS: barracks, soldiers, tanks, helicopters, enemy fire =====

const FACTIONS = [
  { id: 'crimson', name: 'Crimson Battalion', color: 0xb8483a, x: -60, z: -60 },
  { id: 'iron', name: 'Iron Vanguard', color: 0x4a6a8a, x: 60, z: -60 },
];

let bases = [];
let enemyUnits = [];
let enemyBullets = [];
const enemyTracerMat = new THREE.LineBasicMaterial({ color: 0xff5544, transparent: true });

function buildBarracks(color) {
  const group = new THREE.Group();
  const wallMat = new THREE.MeshStandardMaterial({ color: 0x5a5a4a, flatShading: true });
  const roofMat = new THREE.MeshStandardMaterial({ color, flatShading: true });
  const flagMat = new THREE.MeshStandardMaterial({ color, flatShading: true, side: THREE.DoubleSide });

  const main = new THREE.Mesh(new THREE.BoxGeometry(6, 3, 5), wallMat);
  main.position.y = 1.5;
  main.castShadow = true;
  main.receiveShadow = true;
  group.add(main);

  const roof = new THREE.Mesh(new THREE.BoxGeometry(6.4, 0.4, 5.4), roofMat);
  roof.position.y = 3.2;
  roof.castShadow = true;
  group.add(roof);

  const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 4, 5), wallMat);
  pole.position.set(2.6, 5, 0);
  group.add(pole);

  const flag = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 0.7), flagMat);
  flag.position.set(3.2, 6.3, 0);
  group.add(flag);

  group.userData = { flag, roof, roofMat, main, wallMat };
  return group;
}

function buildTank(color) {
  const group = new THREE.Group();
  const bodyMat = new THREE.MeshStandardMaterial({ color, flatShading: true });
  const darkMat = new THREE.MeshStandardMaterial({ color: 0x1c1c1c, flatShading: true });

  const hull = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.8, 3.6), bodyMat);
  hull.position.y = 0.7;
  hull.castShadow = true;
  group.add(hull);

  const turret = new THREE.Mesh(new THREE.CylinderGeometry(0.9, 1, 0.6, 8), bodyMat);
  turret.position.set(0, 1.3, -0.2);
  turret.castShadow = true;
  group.add(turret);

  const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 2.2, 6), darkMat);
  barrel.rotation.x = Math.PI / 2;
  barrel.position.set(0, 1.3, 1.3);
  barrel.castShadow = true;
  group.add(barrel);

  const trackGeo = new THREE.BoxGeometry(0.5, 0.6, 3.8);
  const trackL = new THREE.Mesh(trackGeo, darkMat);
  trackL.position.set(-1.1, 0.3, 0);
  trackL.castShadow = true;
  const trackR = trackL.clone();
  trackR.position.x = 1.1;
  group.add(trackL, trackR);

  group.userData = { turret };
  return group;
}

function buildHeli(color) {
  const group = new THREE.Group();
  const bodyMat = new THREE.MeshStandardMaterial({ color, flatShading: true });
  const darkMat = new THREE.MeshStandardMaterial({ color: 0x1c1c1c, flatShading: true });

  const body = new THREE.Mesh(new THREE.SphereGeometry(0.9, 8, 6), bodyMat);
  body.scale.set(1, 0.9, 1.8);
  body.castShadow = true;
  group.add(body);

  const tail = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.28, 2.2, 6), bodyMat);
  tail.rotation.x = Math.PI / 2;
  tail.position.set(0, 0.1, -1.8);
  tail.castShadow = true;
  group.add(tail);

  const rotor = new THREE.Mesh(new THREE.BoxGeometry(4.2, 0.06, 0.22), darkMat);
  rotor.position.y = 0.85;
  group.add(rotor);

  const tailRotor = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.5, 0.12), darkMat);
  tailRotor.position.set(0.25, 0.2, -2.85);
  group.add(tailRotor);

  group.userData = { rotor, tailRotor };
  return group;
}

function spawnEnemyUnit(base, type) {
  let mesh, hp, speed, range, dmg, fireDelay, hoverHeight;
  if (type === 'soldier') {
    mesh = buildCharacter(base.color);
    hp = 30; speed = 3; range = 25; dmg = 4; fireDelay = 1.2; hoverHeight = 0;
  } else if (type === 'tank') {
    mesh = buildTank(base.color);
    hp = 80; speed = 2.5; range = 30; dmg = 10; fireDelay = 2.5; hoverHeight = 0;
  } else if (type === 'mage') {
    mesh = buildMage(base.color);
    hp = 22; speed = 3.2; range = 30; dmg = 6; fireDelay = 1.3; hoverHeight = 0;
  } else {
    mesh = buildHeli(base.color);
    hp = 50; speed = 4; range = 35; dmg = 8; fireDelay = 1.8; hoverHeight = 9;
  }
  const x = base.x + (Math.random() - 0.5) * 8;
  const z = base.z + (Math.random() - 0.5) * 8;
  mesh.position.set(x, heightAt(x, z) + hoverHeight, z);
  scene.add(mesh);
  enemyUnits.push({
    mesh, type, base, faction: base.faction, magic: base.kind === 'magic', element: base.element,
    hp, maxHp: hp, speed, range, dmg, fireDelay, hoverHeight,
    alive: true, state: 'patrol', homeX: x, homeZ: z,
    fireCd: Math.random() * fireDelay, wanderAngle: Math.random() * Math.PI * 2, wanderTimer: 0,
    hitFlash: 0,
  });
}

function spawnFaction(faction) {
  const barracks = buildBarracks(faction.color);
  const bx = faction.x, bz = faction.z;
  barracks.position.set(bx, heightAt(bx, bz), bz);
  scene.add(barracks);

  const colliderBody = new CANNON.Body({ mass: 0, shape: new CANNON.Box(new CANNON.Vec3(3, 2, 2.5)) });
  colliderBody.position.set(bx, heightAt(bx, bz) + 1.5, bz);
  world.addBody(colliderBody);

  const base = { mesh: barracks, x: bx, z: bz, color: faction.color, name: faction.name, faction: faction.id, kind: 'military', hp: 150, maxHp: 150, destroyed: false, spawnTimer: 3 };
  bases.push(base);

  spawnEnemyUnit(base, 'soldier');
  spawnEnemyUnit(base, 'soldier');
  spawnEnemyUnit(base, 'tank');
}
FACTIONS.forEach(spawnFaction);

function fireEnemyAt(u, dx, dz, dist, targetUnit) {
  const origin = u.mesh.position.clone();
  origin.y += u.type === 'heli' ? 0.5 : 1.3;
  const d = dist || 1;
  const dirN = new THREE.Vector3(dx / d, 0, dz / d);
  const end = origin.clone().add(dirN.clone().multiplyScalar(dist));
  const mat = (u.magic && typeof MAGIC_TRACER_MATS !== 'undefined' && MAGIC_TRACER_MATS[u.element]) ? MAGIC_TRACER_MATS[u.element] : enemyTracerMat;
  const geo = new THREE.BufferGeometry().setFromPoints([origin, end]);
  const line = new THREE.Line(geo, mat.clone());
  line.userData.life = 8;
  scene.add(line);
  enemyBullets.push(line);

  if (targetUnit) {
    const hitChance = Math.max(0.15, 1 - dist / u.range);
    if (Math.random() < hitChance) registerUnitDamage(targetUnit, u.dmg);
  } else if (!inVehicle) {
    const hitChance = Math.max(0.12, 1 - dist / u.range);
    if (Math.random() < hitChance) playerHp = Math.max(0, playerHp - u.dmg);
  }
}

function registerUnitDamage(unit, dmg) {
  unit.hp -= dmg;
  unit.hitFlash = 0.3;
  if (unit.hp <= 0) {
    unit.alive = false;
    unit.mesh.visible = false;
  }
}

// Finds the nearest hostile target for a unit: the player, or any living
// unit belonging to a different faction. This is what lets clans and
// factions fight each other and not just the player.
function findHostileTarget(u) {
  let bestDist = u.range + 15;
  let best = null;
  const pd = Math.hypot(player.position.x - u.mesh.position.x, player.position.z - u.mesh.position.z);
  if (pd < bestDist) { best = 'player'; bestDist = pd; }
  for (let i = 0; i < enemyUnits.length; i++) {
    const other = enemyUnits[i];
    if (other === u || !other.alive || other.faction === u.faction) continue;
    const d = Math.hypot(other.mesh.position.x - u.mesh.position.x, other.mesh.position.z - u.mesh.position.z);
    if (d < bestDist) { best = other; bestDist = d; }
  }
  return best ? { target: best, dist: bestDist } : null;
}

function updateEnemyUnit(u, dt) {
  if (!u.alive) return;

  const found = findHostileTarget(u);
  let dx = 0, dz = 0, dist = 0, targetUnit = null;
  if (found) {
    u.state = 'engage';
    if (found.target === 'player') {
      dx = player.position.x - u.mesh.position.x;
      dz = player.position.z - u.mesh.position.z;
    } else {
      targetUnit = found.target;
      dx = targetUnit.mesh.position.x - u.mesh.position.x;
      dz = targetUnit.mesh.position.z - u.mesh.position.z;
    }
    dist = found.dist || 0.001;
  } else {
    u.state = 'patrol';
  }

  if (u.state === 'engage') {
    u.mesh.rotation.y = Math.atan2(dx, dz);
    if (dist > u.range * 0.5) {
      const nx = u.mesh.position.x + (dx / dist) * u.speed * dt;
      const nz = u.mesh.position.z + (dz / dist) * u.speed * dt;
      u.mesh.position.x = nx;
      u.mesh.position.z = nz;
      u.mesh.position.y = heightAt(nx, nz) + u.hoverHeight;
    }
    u.fireCd -= dt;
    if (dist < u.range && u.fireCd <= 0) {
      fireEnemyAt(u, dx, dz, dist, targetUnit);
      u.fireCd = u.fireDelay;
    }
  } else {
    u.wanderTimer -= dt;
    if (u.wanderTimer <= 0) {
      u.wanderAngle = Math.random() * Math.PI * 2;
      u.wanderTimer = 2 + Math.random() * 3;
    }
    const nx = u.mesh.position.x + Math.sin(u.wanderAngle) * u.speed * 0.3 * dt;
    const nz = u.mesh.position.z + Math.cos(u.wanderAngle) * u.speed * 0.3 * dt;
    if (Math.hypot(nx - u.homeX, nz - u.homeZ) < 14) {
      u.mesh.position.x = nx;
      u.mesh.position.z = nz;
      u.mesh.position.y = heightAt(nx, nz) + u.hoverHeight;
      u.mesh.rotation.y = u.wanderAngle;
    }
  }

  if (u.type === 'heli') {
    u.mesh.userData.rotor.rotation.y += dt * 25;
    u.mesh.userData.tailRotor.rotation.x += dt * 30;
  } else if (u.type === 'soldier' || u.type === 'mage') {
    u.mesh.userData.walkPhase = (u.mesh.userData.walkPhase || 0) + dt * (u.state === 'engage' ? 8 : 4);
    const swing = Math.sin(u.mesh.userData.walkPhase) * 0.5;
    u.mesh.userData.legL.rotation.x = swing;
    u.mesh.userData.legR.rotation.x = -swing;
    if (u.mesh.userData.orb) {
      u.mesh.userData.orbPhase = (u.mesh.userData.orbPhase || 0) + dt * 3;
      u.mesh.userData.orb.position.y = 1.5 + Math.sin(u.mesh.userData.orbPhase) * 0.15;
      u.mesh.userData.orb.scale.setScalar(1 + Math.sin(u.mesh.userData.orbPhase * 2) * 0.15);
    }
  }

  if (u.hitFlash > 0) {
    u.hitFlash -= dt;
    u.mesh.scale.setScalar(1 + Math.sin(u.hitFlash * 20) * 0.1);
  } else {
    u.mesh.scale.setScalar(1);
  }
}

function registerEnemyHit(u) {
  u.hp -= playerDamage;
  u.hitFlash = 0.3;
  playHit();
  if (u.hp <= 0) {
    u.alive = false;
    u.mesh.visible = false;
  }
}

function registerBaseHit(base) {
  if (base.destroyed) return;
  base.hp -= playerDamage;
  if (base.hp <= 0) destroyBase(base);
}

function destroyBase(base) {
  base.destroyed = true;
  if (base.kind === 'military') {
    const d = base.mesh.userData;
    d.wallMat.color.setHex(0x2c2a26);
    d.roofMat.color.setHex(0x1c1a18);
    d.roof.rotation.z = 0.35;
    d.roof.position.y -= 0.6;
    d.flag.visible = false;
  } else {
    const crystal = base.mesh.userData.crystal;
    crystal.material.color.setHex(0x3a3a3a);
    crystal.material.emissiveIntensity = 0;
    crystal.rotation.x = 0.6;
    crystal.position.y -= 1.4;
  }
  if (typeof showToast === 'function') showToast(base.name + ' has fallen!', 3000);
}

function updateBase(base, dt) {
  if (base.destroyed) return;
  base.spawnTimer -= dt;
  if (base.spawnTimer <= 0) {
    const aliveCount = enemyUnits.filter(u => u.base === base && u.alive).length;
    if (aliveCount < 6) {
      let type;
      if (base.kind === 'magic') {
        type = 'mage';
      } else {
        const r = Math.random();
        type = r < 0.15 ? 'heli' : r < 0.4 ? 'tank' : 'soldier';
      }
      spawnEnemyUnit(base, type);
    }
    base.spawnTimer = 12 + Math.random() * 8;
  }
}

function updateFactions(dt) {
  enemyUnits.forEach(u => updateEnemyUnit(u, dt));
  bases.forEach(b => updateBase(b, dt));

  for (let i = enemyBullets.length - 1; i >= 0; i--) {
    const l = enemyBullets[i];
    l.userData.life--;
    l.material.opacity = Math.max(l.userData.life / 8, 0);
    if (l.userData.life <= 0) { scene.remove(l); enemyBullets.splice(i, 1); }
  }
}
