/* =============================================================
   LAMPION POS · js/api/settings.js
   Pengganti api/settings.php — GET semua / POST save
   ============================================================= */
(function (global) {
  'use strict';

  var DB = global.LPDB;
  var CORE = global.LPCORE;

  /* daftar setting yang boleh dibaca/disimpan (padanan $keys/$allowed) */
  var KEYS = ['store_name', 'store_address', 'store_phone', 'store_footer', 'tax_rate',
    'pos_item_style', 'printer_width', 'kiosk_fullscreen', 'print_kitchen',
    'printer_mode', 'printer_service', 'printer_char', 'printer_font_px'];

  function handle(req) {
    if (req.method === 'GET') {
      return CORE.guard(['settings.manage']).then(function (g) {
        if (g.error) { return g.error; }
        return DB.getSettings(KEYS).then(function (settings) {
          return CORE.ok({ settings: settings });
        });
      });
    }

    return CORE.guard(['settings.manage']).then(function (g) {
      if (g.error) { return g.error; }
      var body = req.body || {};
      var saved = [];
      var jobs = [];

      Object.keys(body).forEach(function (k) {
        if (KEYS.indexOf(k) !== -1) {
          jobs.push(DB.setSetting(k, String(body[k])));
          saved.push(k);
        }
      });

      return Promise.all(jobs).then(function () {
        return global.LPHP.logActivity('settings_save', null, { keys: saved });
      }).then(function () {
        return CORE.ok({ saved: saved });
      });
    });
  }

  global.LPAPI = global.LPAPI || {};
  global.LPAPI.settings = handle;
  global.LPAPI._settingsKeys = KEYS;
})(window);
