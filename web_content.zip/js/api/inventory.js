/* =============================================================
   LAMPION POS · js/api/inventory.js
   Pengganti api/inventory.php — list / save / delete / move
   ============================================================= */
(function (global) {
  'use strict';

  var DB = global.LPDB;
  var db = DB.db;
  var PHP = global.LPHP;
  var CORE = global.LPCORE;

  function handle(req) {
    /* ---------- GET ---------- */
    if (req.method === 'GET') {
      return CORE.guard(['inventory.view']).then(function (g) {
        if (g.error) { return g.error; }
        return Promise.all([
          db.inventory_items.toArray(),
          db.menu_inventory.toArray(),
          db.menu_items.toArray()
        ]).then(function (res) {
          var items = res[0], pivots = res[1], menus = res[2];
          var nameById = {};
          menus.forEach(function (m) { nameById[Number(m.id)] = String(m.name); });

          var usedBy = {};
          var menuNames = {};
          pivots.forEach(function (p) {
            var iid = Number(p.inventory_id);
            usedBy[iid] = (usedBy[iid] || 0) + 1;
            var mn = nameById[Number(p.menu_id)];
            if (mn) {
              if (!menuNames[iid]) { menuNames[iid] = []; }
              if (menuNames[iid].indexOf(mn) === -1) { menuNames[iid].push(mn); }
            }
          });

          var rows = items.sort(function (a, b) {
            return String(a.name).localeCompare(String(b.name));
          }).map(function (i) {
            var iid = Number(i.id);
            return {
              id: iid,
              name: String(i.name),
              unit: String(i.unit || 'pcs'),
              stock_qty: Number(i.stock_qty) || 0,
              min_stock: Number(i.min_stock) || 0,
              note: i.note || '',
              is_active: Number(i.is_active),
              created_at: i.created_at || '',
              used_menus: usedBy[iid] || 0,
              /* padanan GROUP_CONCAT(m.name, ', ') */
              menus_used: (menuNames[iid] || []).join(', ')
            };
          });
          return CORE.ok({ inventory: rows });
        });
      });
    }

    /* ---------- POST ---------- */
    return CORE.guard(['inventory.manage']).then(function (g) {
      if (g.error) { return g.error; }
      var body = req.body || {};
      var action = String(body.action || 'save');

      if (action === 'save') {
        var id = Number(body.id || 0);
        var name = String(body.name || '').trim();
        var unit = String(body.unit || 'pcs').trim() || 'pcs';
        var stock = Number(body.stock_qty || 0);
        var min = Number(body.min_stock || 0);
        var note = String(body.note || '');
        var isActive = body.is_active === undefined ? 1 : (body.is_active ? 1 : 0);

        if (name === '') { return CORE.fail('Nama inventory wajib.'); }

        var op = (id > 0)
          ? db.inventory_items.update(id, {
            name: name, unit: unit, stock_qty: stock, min_stock: min,
            note: note, is_active: isActive
          })
          : db.inventory_items.add({
            name: name, unit: unit, stock_qty: stock, min_stock: min,
            note: note, is_active: isActive, created_at: DB.now()
          });

        return op.then(function () {
          return PHP.logActivity('inventory_save', name, { id: id });
        }).then(function () { return CORE.ok({}); });
      }

      if (action === 'delete') {
        var did = Number(body.id || 0);
        return db.menu_inventory.where('inventory_id').equals(did).count().then(function (n) {
          if (n > 0) {
            return CORE.fail('Inventory ini masih dipakai di menu — hapus relasinya dahulu.');
          }
          return db.inventory_items.delete(did).then(function () {
            return PHP.logActivity('inventory_delete', 'Inventory #' + did);
          }).then(function () { return CORE.ok({}); });
        });
      }

      if (action === 'move') { return doMove(body); }

      return CORE.fail('Action tidak dikenal.');
    });
  }

  /* ---------- move: stok masuk/keluar + catat pergerakan ---------- */
  function doMove(body) {
    var id = Number(body.id || 0);
    var type = (['in', 'out'].indexOf(String(body.type)) !== -1) ? String(body.type) : 'in';
    var qty = Math.abs(Number(body.qty || 0));
    var note = String(body.note || '');

    if (id <= 0 || !(qty > 0)) {
      return CORE.fail('Jumlah (qty > 0) wajib.');
    }

    return db.inventory_items.get(id).then(function (row) {
      if (!row) { return CORE.fail('Inventory tidak dikenal.'); }
      var cur = Number(row.stock_qty) || 0;
      var newStock = type === 'in' ? cur + qty : cur - qty;
      if (newStock < 0) {
        return CORE.fail('Stok tidak cukup (kini: ' + cur + ' ' + String(row.unit || '') + ').');
      }
      return db.transaction('rw', db.inventory_items, db.inventory_movements, function () {
        return db.inventory_items.update(id, { stock_qty: newStock }).then(function () {
          return db.inventory_movements.add({
            inventory_id: id,
            type: type,
            qty: qty,
            note: note,
            ref_type: null,
            ref_id: null,
            created_by: Number(global.LPAUTH.currentUser().id),
            created_at: DB.now()
          });
        });
      }).then(function () {
        return PHP.logActivity('inventory_move', 'Inventory #' + id,
          { type: type, qty: qty, note: note });
      }).then(function () {
        return CORE.ok({ stock_qty: newStock });
      });
    });
  }

  global.LPAPI = global.LPAPI || {};
  global.LPAPI.inventory = handle;
})(window);
