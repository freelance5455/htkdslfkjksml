/* =============================================================
   LAMPION POS · js/api/auth.js
   Pengganti api/auth.php
   -------------------------------------------------------------
   POST { action:'login',  username, password } -> token sesi
   POST { action:'logout' }
   GET  ?action=me                              -> user + perms
   ============================================================= */
(function (global) {
  'use strict';

  var DB = global.LPDB;
  var db = DB.db;
  var CORE = global.LPCORE;

  function handle(req) {
    var action = String((req.body && req.body.action) || req.query.action || '');

    if (req.method === 'GET' && action === 'me') {
      return CORE.guard([]).then(function (g) {
        if (g.error) { return g.error; }
        var u = g.ctx.user;
        return CORE.ok({
          user: {
            id: u.id, username: u.username, name: u.name,
            role_id: u.role_id, role_name: u.role_name, role_key: u.role_key
          },
          perms: g.ctx.perms
        });
      });
    }

    if (action === 'login') {
      var username = String((req.body && req.body.username) || '').trim();
      var password = String((req.body && req.body.password) || '');
      if (username === '' || password === '') {
        return Promise.resolve(CORE.fail('Username dan password wajib diisi.'));
      }
      return global.LPAUTH.doLogin(username, password).then(function (res) {
        if (!res.ok) { return CORE.fail(res.msg, 401); }
        return db.users.where('username').equals(username).first().then(function (u) {
          var sessId = '';
          try {
            sessId = JSON.parse(localStorage.getItem(DB.CFG.SESSION_KEY) || '{}').sid || '';
          } catch (e) { sessId = ''; }
          return CORE.ok({
            token: sessId,
            role_key: res.role_key,
            user: {
              id: u.id, username: u.username, name: u.name,
              role_id: u.role_id, role_name: u.role_name, role_key: res.role_key
            },
            perms: global.LPAUTH.currentPermissions()
          });
        });
      });
    }

    if (action === 'logout') {
      return global.LPAUTH.doLogout().then(function () {
        return CORE.ok({});
      });
    }

    return Promise.resolve(CORE.fail('Action tidak dikenal.'));
  }

  global.LPAPI = global.LPAPI || {};
  global.LPAPI.auth = handle;
})(window);
