/* =============================================================
   LAMPION POS · js/api/menus.js
   Pengganti api/menus.php
   -------------------------------------------------------------
   GET  [&all=1]          -> kategori + item menu (dengan usage_cnt)
   POST action=save       -> simpan menu + pivot inventory
   POST action=delete     -> hapus menu (ditolak bila pernah dipesan)
   ============================================================= */
(function (global) {
  'use strict';

  var db = global.LPDB.db;
  var PHP = global.LPHP;
  var CORE = global.LPCORE;

  /** Hitung jumlah pivot inventory per menu */
  function usageCounts() {
    return db.menu_inventory.toArray().then(function (pivots) {
      var count = {};
      pivots.forEach(function (p) {
        var mid = Number(p.menu_id);
        count[mid] = (count[mid] || 0) + 1;
      });
      return count;
    });
  }

  function toNumber(v) { return Number(v) || 0; }

  function handle(req) {
    /* ---------- GET: daftar menu ---------- */
    if (req.method === 'GET') {
      return CORE.guard(['menu.view']).then(function (g) {
        if (g.error) { return g.error; }
        var showAll = String(req.query.all || '') === '1';

        return Promise.all([
          db.categories.toArray(),
          db.menu_items.toArray(),
          usageCounts()
        ]).then(function (res) {
          var catsRaw = res[0], itemsRaw = res[1], usage = res[2];

          var activeMenusPerCat = {};
          itemsRaw.forEach(function (m) {
            if (Number(m.is_active) === 1) {
              var cid = Number(m.category_id);
              activeMenusPerCat[cid] = (activeMenusPerCat[cid] || 0) + 1;
            }
          });

          /* kategori aktif saja, urut sort_order lalu nama */
          var cats = catsRaw
            .filter(function (c) { return Number(c.is_active) === 1; })
            .sort(function (a, b) {
              var so = toNumber(a.sort_order) - toNumber(b.sort_order);
              if (so !== 0) { return so; }
              return String(a.name).localeCompare(String(b.name));
            })
            .map(function (c) {
              var cid = Number(c.id);
              return {
                id: cid,
                name: String(c.name),
                sort_order: toNumber(c.sort_order),
                item_count: activeMenusPerCat[cid] || 0
              };
            });

          var items = itemsRaw.filter(function (m) {
            return showAll || Number(m.is_active) === 1;
          });

          items.sort(function (a, b) {
            if (showAll) {
              /* ORDER BY is_active DESC, sort_order, name */
              var av = Number(a.is_active), bv = Number(b.is_active);
              if (av !== bv) { return bv - av; }
            }
            var so = toNumber(a.sort_order) - toNumber(b.sort_order);
            if (so !== 0) { return so; }
            return String(a.name).localeCompare(String(b.name));
          });

          items = items.map(function (m) {
            var mid = Number(m.id);
            return {
              id: mid,
              category_id: Number(m.category_id),
              name: String(m.name),
              description: m.description || '',
              price_dine_in: toNumber(m.price_dine_in),
              price_takeaway: toNumber(m.price_takeaway),
              price_online: toNumber(m.price_online),
              image: m.image || null,
              is_active: Number(m.is_active),
              sort_order: toNumber(m.sort_order),
              created_at: m.created_at || '',
              updated_at: m.updated_at || '',
              usage_cnt: usage[mid] || 0
            };
          });

          return CORE.ok({ categories: cats, items: items });
        });
      });
    }

    /* ---------- POST: save / delete ---------- */
    return CORE.guard(['menu.manage']).then(function (g) {
      if (g.error) { return g.error; }
      var body = req.body || {};
      var action = String(body.action || 'save');

      if (action === 'save') { return doSave(body); }
      if (action === 'delete') { return doDelete(body); }
      return CORE.fail('Action tidak dikenal.');
    });
  }

  function doSave(body) {
    var id = Number(body.id || 0);
    var categoryId = Number(body.category_id || 0);
    var name = String(body.name || '').trim();
    var description = String(body.description || '');
    var priceD = PHP.parseMoney(body.price_dine_in);
    var priceT = PHP.parseMoney(body.price_takeaway);
    var priceO = PHP.parseMoney(body.price_online);
    var isActive = body.is_active === undefined ? 1 : (body.is_active ? 1 : 0);
    var sortOrder = Number(body.sort_order || 0);
    var inventory = body.inventory || [];

    if (name === '' || categoryId <= 0) {
      return Promise.resolve(CORE.fail('Nama dan kategori wajib.'));
    }

    return db.categories.get(categoryId).then(function (cat) {
      if (!cat) { return CORE.fail('Kategori tidak valid.'); }
      var now = global.LPDB.now();
      var op = (id > 0)
        ? db.menu_items.update(id, {
          category_id: categoryId, name: name, description: description,
          price_dine_in: priceD, price_takeaway: priceT, price_online: priceO,
          is_active: isActive, sort_order: sortOrder, updated_at: now
        })
        : db.menu_items.add({
          category_id: categoryId, name: name, description: description,
          price_dine_in: priceD, price_takeaway: priceT, price_online: priceO,
          image: null, is_active: isActive, sort_order: sortOrder,
          created_at: now, updated_at: now
        });

      return op.then(function (newId) {
        var menuId = id > 0 ? id : Number(newId);

        /* pivot menu_inventory (many-to-many) — ganti seluruh relasi */
        return db.menu_inventory.where('menu_id').equals(menuId).delete().then(function () {
          var rows = [];
          inventory.forEach(function (row) {
            var iid = Number(row.inventory_id || 0);
            var q = Number(row.qty_used || 1);
            if (iid > 0 && q > 0) {
              rows.push({ menu_id: menuId, inventory_id: iid, qty_used: q });
            }
          });
          var pivotJob = rows.length ? db.menu_inventory.bulkAdd(rows) : Promise.resolve(0);
          return pivotJob.then(function () {
            return PHP.logActivity('menu_save', name, { id: menuId });
          }).then(function () {
            return CORE.ok({ id: menuId });
          });
        });
      });
    }).catch(function (e) {
      return CORE.fail('Error save menu: ' + e.message, 500);
    });
  }

  function doDelete(body) {
    var id = Number(body.id || 0);
    return db.order_items.where('menu_id').equals(id).count().then(function (n) {
      if (n > 0) {
        return CORE.fail('Menu sudah pernah dipesan — tidak bisa dihapus. Pilih is_active=0 supaya disembunyikan.');
      }
      return db.transaction('rw', db.menu_items, db.menu_inventory, function () {
        return db.menu_inventory.where('menu_id').equals(id).delete()
          .then(function () { return db.menu_items.delete(id); });
      }).then(function () {
        return PHP.logActivity('menu_delete', 'Menu #' + id);
      }).then(function () {
        return CORE.ok({});
      });
    });
  }

  global.LPAPI = global.LPAPI || {};
  global.LPAPI.menus = handle;
})(window);

