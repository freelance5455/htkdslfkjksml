/* =============================================================
   LAMPION POS · js/api/sales.js
   Pengganti api/sales.php — laporan penjualan rentang tanggal
   -------------------------------------------------------------
   GET ?from=YYYY-MM-DD&to=YYYY-MM-DD
   Agregasi SQL (SUM/COUNT/GROUP BY) dipindahkan ke JavaScript.
   ============================================================= */
(function (global) {
  'use strict';

  var DB = global.LPDB;
  var db = DB.db;
  var CORE = global.LPCORE;

  function handle(req) {
    return CORE.guard(['sales.view']).then(function (g) {
      if (g.error) { return g.error; }

      var from = String(req.query.from || DB.today());
      var to = String(req.query.to || DB.today());
      /* padanan: if ($from > $to) swap */
      if (from > to) { var t = from; from = to; to = t; }

      return Promise.all([
        db.orders.toArray(),
        db.order_items.toArray(),
        db.users.toArray()
      ]).then(function (res) {
        var orders = res[0], orderItems = res[1], users = res[2];
        var userById = {};
        users.forEach(function (u) { userById[Number(u.id)] = String(u.name); });

        /* ---------- ringkasan (hanya status paid) ---------- */
        var paidInRange = orders.filter(function (o) {
          if (String(o.status) !== 'paid') { return false; }
          var d = DB.dateOf(o.created_at);
          return d >= from && d <= to;
        });

        var paidIds = {};
        paidInRange.forEach(function (o) { paidIds[Number(o.id)] = 1; });

        var salesTotal = 0;
        var itemQty = 0;
        paidInRange.forEach(function (o) { salesTotal += Number(o.total) || 0; });
        orderItems.forEach(function (it) {
          if (paidIds[Number(it.order_id)]) { itemQty += Number(it.qty) || 0; }
        });

        var summary = {
          sales: DB.round2(salesTotal),
          tx: paidInRange.length,
          items: DB.round2(itemQty)
        };

        /* ---------- grup per hari (GROUP BY DATE(created_at)) ---------- */
        var dayMap = {};
        paidInRange.forEach(function (o) {
          var d = DB.dateOf(o.created_at);
          if (!dayMap[d]) { dayMap[d] = { d: d, tx: 0, total: 0 }; }
          dayMap[d].tx += 1;
          dayMap[d].total += Number(o.total) || 0;
        });
        var perDay = Object.keys(dayMap).sort().map(function (k) {
          return { d: dayMap[k].d, tx: dayMap[k].tx, total: DB.round2(dayMap[k].total) };
        });

        /* ---------- grup per metode bayar ---------- */
        var pmMap = {};
        paidInRange.forEach(function (o) {
          var pm = String(o.payment_method);
          if (!pmMap[pm]) { pmMap[pm] = { payment_method: pm, cnt: 0, total: 0 }; }
          pmMap[pm].cnt += 1;
          pmMap[pm].total += Number(o.total) || 0;
        });
        var payments = Object.keys(pmMap).map(function (k) {
          return {
            payment_method: k,
            cnt: pmMap[k].cnt,
            total: DB.round2(pmMap[k].total),
            label: DB.PAYMENT_LABEL[k] || k
          };
        });

        /* ---------- detail transaksi (SEMUA status, urut id DESC) ---------- */
        var detail = orders.filter(function (o) {
          var d = DB.dateOf(o.created_at);
          return d >= from && d <= to;
        }).sort(function (a, b) { return Number(b.id) - Number(a.id); });

        var itemsByOrder = {};
        orderItems.forEach(function (it) {
          var oid = Number(it.order_id);
          if (!itemsByOrder[oid]) { itemsByOrder[oid] = []; }
          itemsByOrder[oid].push({
            item_name: String(it.item_name),
            qty: Number(it.qty) || 0,
            price: Number(it.price) || 0,
            subtotal: Number(it.subtotal) || 0
          });
        });

        var list = detail.map(function (o) {
          var oid = Number(o.id);
          return {
            id: oid,
            order_number: String(o.order_number),
            order_type: String(o.order_type),
            customer_name: o.customer_name || '',
            subtotal: Number(o.subtotal) || 0,
            discount: Number(o.discount) || 0,
            tax: Number(o.tax) || 0,
            total: Number(o.total) || 0,
            payment_method: String(o.payment_method),
            status: String(o.status),
            created_at: String(o.created_at || ''),
            cashier: userById[Number(o.cashier_id)] || '',
            items: itemsByOrder[oid] || []
          };
        });

        return CORE.ok({
          from: from, to: to,
          summary: summary,
          per_day: perDay,
          payments: payments,
          orders: list
        });
      });
    });
  }

  global.LPAPI = global.LPAPI || {};
  global.LPAPI.sales = handle;
})(window);
