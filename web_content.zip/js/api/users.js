/* =============================================================
   LAMPION POS · js/api/users.js
   Pengganti users.php + roles.php + activity.php versi PHP
   (dulu memakai POST form). Kini disajikan lewat router lokal.
   -------------------------------------------------------------
   action=list_users | save_user | delete_user
   action=list_roles | save_role | delete_role
   action=list_activity
   ============================================================= */
(function (global) {
  'use strict';

  var DB = global.LPDB;
  var db = DB.db;
  var PHP = global.LPHP;
  var CORE = global.LPCORE;

  function handle(req) {
    var action = String((req.body && req.body.action) || req.query.action || 'list_users');

    /* permission bergantung pada action */
    var perm = 'users.manage';
    if (action === 'list_activity') { perm = 'activity.view'; }
    if (action === 'list_roles' || action === 'save_role' || action === 'delete_role') {
      perm = 'roles.manage';
    }

    return CORE.guard([perm]).then(function (g) {
      if (g.error) { return g.error; }

      if (action === 'list_users') { return listUsers(); }
      if (action === 'save_user') { return saveUser(req.body || {}); }
      if (action === 'delete_user') { return deleteUser(req.body || {}); }
      if (action === 'list_roles') { return listRoles(); }
      if (action === 'save_role') { return saveRole(req.body || {}); }
      if (action === 'delete_role') { return deleteRole(req.body || {}); }
      if (action === 'list_activity') { return listActivity(req.query); }
      return CORE.fail('Action tidak dikenal.');
    });
  }

  /* ---------- users ---------- */
  function listUsers() {
    return Promise.all([db.users.toArray(), db.roles.toArray()]).then(function (res) {
      var roleById = {};
      res[1].forEach(function (r) { roleById[Number(r.id)] = String(r.name); });
      var rows = res[0].sort(function (a, b) { return Number(a.id) - Number(b.id); })
        .map(function (u) {
          return {
            id: Number(u.id),
            username: String(u.username),
            name: String(u.name),
            role_id: Number(u.role_id),
            role_name: roleById[Number(u.role_id)] || '-',
            is_active: Number(u.is_active),
            created_at: String(u.created_at || '')
          };
        });
      return CORE.ok({ users: rows });
    });
  }

  function saveUser(body) {
    var id = Number(body.id || 0);
    var username = String(body.username || '').trim();
    var name = String(body.name || '').trim();
    var password = String(body.password || '');
    var roleId = Number(body.role_id || 0);
    var isActive = body.is_active === undefined ? 1 : (body.is_active ? 1 : 0);

    if (username === '') { return Promise.resolve(CORE.fail('Username wajib diisi.')); }
    if (name === '') { return Promise.resolve(CORE.fail('Nama wajib diisi.')); }
    if (!(roleId > 0)) { return Promise.resolve(CORE.fail('Pilih role terlebih dahulu.')); }

    return db.users.where('username').equals(username).first().then(function (dup) {
      if (dup && Number(dup.id) !== id) {
        throw new Error('Username sudah dipakai: ' + username);
      }
      if (id > 0) {
        var upd = { username: username, name: name, role_id: roleId, is_active: isActive };
        var pre = (password !== '')
          ? global.LPAUTH.makeStoredHash(password)
          : Promise.resolve(null);
        return pre.then(function (hash) {
          if (hash !== null) { upd.password = hash; }
          return db.users.update(id, upd);
        });
      }
      if (password === '') { throw new Error('Password wajib diisi untuk user baru.'); }
      if (password.length < 4) { throw new Error('Password minimal 4 karakter.'); }
      return global.LPAUTH.makeStoredHash(password).then(function (hash) {
        return db.users.add({
          username: username, password: hash, name: name, role_id: roleId,
          is_active: isActive, created_at: DB.now()
        });
      });
    }).then(function () {
      return PHP.logActivity('user_save', username, { id: id, role_id: roleId });
    }).then(function () {
      return CORE.ok({});
    }).catch(function (e) {
      return CORE.fail(e.message, 400);
    });
  }

  function deleteUser(body) {
    var id = Number(body.id || 0);
    var me = global.LPAUTH.currentUser();
    if (me && Number(me.id) === id) {
      return Promise.resolve(CORE.fail('Tidak bisa menghapus akun yang sedang aktif digunakan.'));
    }
    return db.users.count().then(function (n) {
      if (n <= 1) { return CORE.fail('Minimal harus ada satu akun pengguna.'); }
      return db.users.get(id).then(function (u) {
        return db.users.delete(id).then(function () {
          return PHP.logActivity('user_delete', u ? String(u.username) : ('User #' + id));
        }).then(function () {
          return CORE.ok({});
        });
      });
    });
  }


  /* ---------- roles ---------- */
  function listRoles() {
    return Promise.all([
      db.roles.toArray(), db.permissions.toArray(),
      db.role_permissions.toArray(), db.users.toArray()
    ]).then(function (res) {
      var roles = res[0], perms = res[1], rps = res[2], users = res[3];

      var permById = {};
      perms.forEach(function (p) { permById[Number(p.id)] = String(p.pkey); });

      var permByRole = {};
      rps.forEach(function (rp) {
        var rid = Number(rp.role_id);
        if (!permByRole[rid]) { permByRole[rid] = []; }
        var pk = permById[Number(rp.permission_id)];
        if (pk) { permByRole[rid].push(pk); }
      });

      var userCount = {};
      users.forEach(function (u) {
        var rid = Number(u.role_id);
        userCount[rid] = (userCount[rid] || 0) + 1;
      });

      var out = roles.sort(function (a, b) { return Number(a.id) - Number(b.id); })
        .map(function (r) {
          var rid = Number(r.id);
          var isAdmin = String(r.name).toLowerCase() === 'admin';
          return {
            id: rid,
            name: String(r.name),
            is_system: Number(r.is_system),
            is_active: Number(r.is_active),
            user_count: userCount[rid] || 0,
            /* admin selalu punya semua permission (padanan ['*']) */
            perms: isAdmin ? ['*'] : (permByRole[rid] || [])
          };
        });

      var permList = perms.sort(function (a, b) {
        return (Number(a.sort) || 0) - (Number(b.sort) || 0);
      }).map(function (p) {
        return {
          pkey: String(p.pkey),
          name: String(p.name),
          group_label: String(p.group_label || 'Lainnya'),
          sort: Number(p.sort) || 0
        };
      });

      return CORE.ok({ roles: out, permissions: permList });
    });
  }

  function saveRole(body) {
    var id = Number(body.id || 0);
    var name = String(body.name || '').trim();
    var perms = body.perms || [];
    if (name === '') { return Promise.resolve(CORE.fail('Nama role wajib diisi.')); }

    return db.roles.get(id).then(function (role) {
      if (role && Number(role.is_system) === 1 && String(role.name) !== name) {
        return CORE.fail('Role sistem tidak dapat diganti namanya.');
      }
      var op = (id > 0)
        ? db.roles.update(id, { name: name, is_active: 1 })
        : db.roles.add({ name: name, is_system: 0, is_active: 1, created_at: DB.now() });

      return op.then(function (newId) {
        var rid = id > 0 ? id : Number(newId);
        var isAdmin = (name.toLowerCase() === 'admin');

        return db.role_permissions.where('role_id').equals(rid).delete().then(function () {
          if (isAdmin) { return 0; }
          return db.permissions.toArray().then(function (all) {
            var rows = [];
            all.forEach(function (p) {
              if (perms.indexOf(String(p.pkey)) !== -1) {
                rows.push({ role_id: rid, permission_id: Number(p.id) });
              }
            });
            return rows.length ? db.role_permissions.bulkPut(rows) : 0;
          });
        }).then(function () {
          return PHP.logActivity('role_save', name, { id: rid, perms: perms.length });
        }).then(function () {
          return CORE.ok({ id: rid });
        });
      });
    }).catch(function (e) {
      return CORE.fail(e.message, 400);
    });
  }

  function deleteRole(body) {
    var id = Number(body.id || 0);
    return db.roles.get(id).then(function (role) {
      if (!role) { return CORE.fail('Role tidak ditemukan.'); }
      if (Number(role.is_system) === 1) {
        return CORE.fail('Role sistem tidak dapat dihapus.');
      }
      return db.users.where('role_id').equals(id).count().then(function (n) {
        if (n > 0) { return CORE.fail('Role masih dipakai ' + n + ' pengguna.'); }
        return db.transaction('rw', db.roles, db.role_permissions, function () {
          return db.role_permissions.where('role_id').equals(id).delete()
            .then(function () { return db.roles.delete(id); });
        }).then(function () {
          return PHP.logActivity('role_delete', String(role.name));
        }).then(function () {
          return CORE.ok({});
        });
      });
    });
  }

  /* ---------- activity log ---------- */
  function listActivity(query) {
    var limit = Math.min(1000, Number(query.limit || 300));
    /* Nama parameter filter HARUS berbeda dari 'action'.
       Sebelumnya halaman mengirim ?action=list_activity&action=<filter>,
       sehingga parseQuery() menimpa 'action' dengan nilai filter
       (yang terakhir menang) -> handler tidak pernah menemukan
       list_activity dan Activity Log tidak pernah tampil. */
    var filter = String(query.filter || '');

    return db.activity_log.toArray().then(function (rows) {
      rows.sort(function (a, b) { return Number(b.id) - Number(a.id); });

      var actions = {};
      rows.forEach(function (r) { actions[String(r.action)] = 1; });

      if (filter !== '') {
        rows = rows.filter(function (r) { return String(r.action) === filter; });
      }
      var picked = rows.slice(0, limit);

      return db.users.toArray().then(function (users) {
        var nameById = {};
        users.forEach(function (u) { nameById[Number(u.id)] = String(u.name); });

        return CORE.ok({
          actions: Object.keys(actions).sort(),
          total: rows.length,
          rows: picked.map(function (r) {
            return {
              id: Number(r.id),
              user_name: (r.user_id === null || r.user_id === undefined)
                ? '-'
                : (nameById[Number(r.user_id)] || 'Dihapus'),
              action: String(r.action),
              target: r.target || '',
              detail: r.detail || '',
              created_at: String(r.created_at || '')
            };
          })
        });
      });
    });
  }

  global.LPAPI = global.LPAPI || {};
  global.LPAPI.users = handle;
})(window);
