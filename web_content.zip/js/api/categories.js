/* =============================================================
   LAMPION POS · js/api/categories.js
   Pengganti api/categories.php  —  list / save / delete
   ============================================================= */
(function (global) {
  'use strict';

  var db = global.LPDB.db;
  var PHP = global.LPHP;
  var CORE = global.LPCORE;

  function handle(req) {
    /* ---------- GET: daftar kategori + jumlah menu ---------- */
    if (req.method === 'GET') {
      return CORE.guard(['category.view']).then(function (g) {
        if (g.error) { return g.error; }
        return db.categories.toArray().then(function (cats) {
          return db.menu_items.toArray().then(function (items) {
            var count = {};
            items.forEach(function (m) {
              var cid = Number(m.category_id);
              count[cid] = (count[cid] || 0) + 1;
            });
            cats.sort(function (a, b) {
              var so = (Number(a.sort_order) || 0) - (Number(b.sort_order) || 0);
              if (so !== 0) { return so; }
              return String(a.name).localeCompare(String(b.name));
            });
            return cats.map(function (c) {
              var cid = Number(c.id);
              return {
                id: cid,
                name: String(c.name),
                sort_order: Number(c.sort_order) || 0,
                is_active: Number(c.is_active),
                item_count: count[cid] || 0
              };
            });
          });
        }).then(function (rows) {
          return CORE.ok({ categories: rows });
        });
      });
    }

    /* ---------- POST: save / delete ---------- */
    return CORE.guard(['category.manage']).then(function (g) {
      if (g.error) { return g.error; }
      var body = req.body || {};
      var action = String(body.action || 'save');

      if (action === 'save') {
        var id = Number(body.id || 0);
        var name = String(body.name || '').trim();
        var sortOrder = Number(body.sort_order || 0);
        var isActive = body.is_active === undefined
          ? 1 : (body.is_active ? 1 : 0);

        if (name === '') { return CORE.fail('Nama kategori wajib.'); }

        return db.categories.where('name').equals(name).first().then(function (dup) {
          if (dup && Number(dup.id) !== id) {
            return CORE.fail('Nama kategori sudah dipakai.');
          }
          var op = (id > 0)
            ? db.categories.update(id, { name: name, sort_order: sortOrder, is_active: isActive })
            : db.categories.add({ name: name, sort_order: sortOrder, is_active: isActive });
          return op.then(function () {
            return PHP.logActivity('category_save', name, { id: id });
          }).then(function () {
            return CORE.ok({});
          });
        });
      }

      if (action === 'delete') {
        var did = Number(body.id || 0);
        return db.menu_items.where('category_id').equals(did).count().then(function (n) {
          if (n > 0) {
            return CORE.fail('Kategori masih punya menu — hapus/pindah menu tersebut dahulu.');
          }
          return db.categories.delete(did).then(function () {
            return PHP.logActivity('category_delete', 'Kategori #' + did);
          }).then(function () {
            return CORE.ok({});
          });
        });
      }

      return CORE.fail('Action tidak dikenal.');
    });
  }

  global.LPAPI = global.LPAPI || {};
  global.LPAPI.categories = handle;
})(window);
