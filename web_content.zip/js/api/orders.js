/* =============================================================
   LAMPION POS · js/api/orders.js
   Pengganti api/orders.php
   -------------------------------------------------------------
   GET                      -> list order ditahan (hold)
   POST action=create       -> bayar langsung / finalisasi hold
   POST action=hold         -> simpan order ditahan (tanpa potong stok)
   POST action=update_hold  -> ganti isi hold
   POST action=cancel       -> batalkan hold
   ============================================================= */
(function (global) {
  'use strict';

  var DB = global.LPDB;
  var db = DB.db;
  var PHP = global.LPHP;
  var CORE = global.LPCORE;

  /* ---------- _compute_lines(): ambil harga sesuai tipe pesanan ---------- */
  function computeLines(orderType, itemsRaw) {
    if (['dine_in', 'takeaway', 'online'].indexOf(orderType) === -1) {
      return Promise.resolve({ error: 'order_type tidak valid.' });
    }
    if (!itemsRaw || itemsRaw.length === 0) {
      return Promise.resolve({ error: 'Pesanan kosong.' });
    }

    var ids = itemsRaw.map(function (it) { return Number(it.menu_id) || 0; });

    return db.menu_items.where('id').anyOf(ids).toArray()
      .then(function (menuRows) {
        var catIds = menuRows.map(function (r) { return Number(r.category_id); });
        return db.categories.where('id').anyOf(catIds).toArray().then(function (cats) {
          var catName = {};
          cats.forEach(function (c) { catName[Number(c.id)] = String(c.name); });

          /* hanya menu aktif yang boleh dijual (padanan is_active === 1) */
          var priceMap = {};
          menuRows.forEach(function (r) {
            if (Number(r.is_active) === 1) {
              priceMap[Number(r.id)] = {
                name: String(r.name),
                price: Number(r['price_' + orderType]) || 0,
                category_name: catName[Number(r.category_id)] || ''
              };
            }
          });

          var lines = [];
          var subtotal = 0;
          for (var i = 0; i < itemsRaw.length; i++) {
            var mid = Number(itemsRaw[i].menu_id) || 0;
            var qty = Math.max(1, Number(itemsRaw[i].qty) || 1);
            var meta = priceMap[mid];
            if (!meta) {
              return { error: 'Menu #' + mid + ' tidak aktif/dikenal.' };
            }
            var lineSub = meta.price * qty;
            subtotal += lineSub;
            lines.push({
              menu_id: mid,
              item_name: meta.name,
              price: meta.price,
              qty: qty,
              subtotal: lineSub,
              category_name: meta.category_name
            });
          }
          return { lines: lines, subtotal: subtotal };
        });
      });
  }

  /* ---------- _insert_order() ---------- */
  function insertOrder(o) {
    return PHP.generateOrderNumber(o.order_type).then(function (orderNumber) {
      var change = (o.received !== null && o.received > o.total) ? o.received - o.total : 0;
      return db.orders.add({
        order_number: orderNumber,
        order_type: o.order_type,
        customer_name: o.customer_name !== '' ? o.customer_name : null,
        subtotal: o.subtotal,
        discount: o.discount,
        tax: o.tax,
        total: o.total,
        payment_method: o.payment_method,
        received: o.received,
        change_due: change,
        status: o.status,
        cancel_reason: null,
        cashier_id: o.uid,
        created_at: DB.now()
      }).then(function (id) {
        return { id: id, order_number: orderNumber };
      });
    });
  }

  /* ---------- _replace_items() ---------- */
  function replaceItems(orderId, lines) {
    return db.order_items.where('order_id').equals(orderId).delete().then(function () {
      var rows = lines.map(function (ln) {
        return {
          order_id: orderId,
          menu_id: Number(ln.menu_id),
          item_name: String(ln.item_name),
          price: Number(ln.price),
          qty: Number(ln.qty),
          subtotal: Number(ln.subtotal)
        };
      });
      return rows.length ? db.order_items.bulkAdd(rows) : 0;
    });
  }

  /* ---------- _deduct_stock(): potong stok via pivot menu_inventory ---------- */
  function deductStock(lines, orderId, orderNumber, uid) {
    var menuIds = lines.map(function (ln) { return Number(ln.menu_id); });
    return db.menu_inventory.where('menu_id').anyOf(menuIds).toArray()
      .then(function (pivots) {
        if (pivots.length === 0) { return 0; }

        /* akumulasi pemakaian per inventory: qty_used * qty */
        var usage = {};
        pivots.forEach(function (p) {
          var line = null;
          for (var i = 0; i < lines.length; i++) {
            if (Number(lines[i].menu_id) === Number(p.menu_id)) { line = lines[i]; break; }
          }
          if (!line) { return; }
          var iid = Number(p.inventory_id);
          usage[iid] = (usage[iid] || 0) + (Number(p.qty_used) || 0) * Number(line.qty);
        });

        var ids = Object.keys(usage).map(Number);
        if (ids.length === 0) { return 0; }
        return applyUsage(usage, orderId, orderNumber, uid);
      });
  }

  function applyUsage(usage, orderId, orderNumber, uid) {
    var ids = Object.keys(usage).map(Number);
    var now = DB.now();
    return db.transaction('rw', db.inventory_items, db.inventory_movements, function () {
      var jobs = [];
      ids.forEach(function (iid) {
        var q = usage[iid];
        if (!(q > 0)) { return; }
        jobs.push(
          db.inventory_items.get(iid).then(function (item) {
            if (!item) { return 0; }
            return db.inventory_items.update(iid, {
              stock_qty: (Number(item.stock_qty) || 0) - q
            });
          })
        );
        jobs.push(db.inventory_movements.add({
          inventory_id: iid,
          type: 'out',
          qty: q,
          note: 'Pemakaian pesanan ' + orderNumber,
          ref_type: 'order',
          ref_id: orderId,
          created_by: uid,
          created_at: now
        }));
      });
      return Promise.all(jobs);
    });
  }

  /* ---------- pengambil baris ---------- */
  function orderRow(orderId) {
    return db.orders.get(Number(orderId)).then(function (r) { return r || null; });
  }

  function assertHold(orderId) {
    return orderRow(orderId).then(function (o) {
      if (!o || String(o.status) !== 'hold') {
        return { error: 'Order #' + orderId + ' tidak hold / sudah diproses.' };
      }
      return { order: o };
    });
  }

  function orderLinesById(orderId) {
    return db.order_items.where('order_id').equals(Number(orderId)).toArray()
      .then(function (rows) {
        var menuIds = rows.map(function (r) { return Number(r.menu_id); });
        if (menuIds.length === 0) { return []; }
        return db.menu_items.where('id').anyOf(menuIds).toArray().then(function (menus) {
          var catIds = menus.map(function (m) { return Number(m.category_id); });
          return db.categories.where('id').anyOf(catIds).toArray().then(function (cats) {
            var catName = {};
            cats.forEach(function (c) { catName[Number(c.id)] = String(c.name); });
            var menuCat = {};
            menus.forEach(function (m) { menuCat[Number(m.id)] = catName[Number(m.category_id)] || ''; });
            return rows.map(function (r) {
              return {
                menu_id: Number(r.menu_id),
                item_name: String(r.item_name),
                qty: Number(r.qty),
                price: Number(r.price),
                subtotal: Number(r.subtotal),
                category_name: menuCat[Number(r.menu_id)] || ''
              };
            });
          });
        });
      });
  }

  /* ---------- _fetch_holds() ---------- */
  function fetchHolds() {
    return db.orders.where('status').equals('hold').toArray().then(function (rows) {
      rows.sort(function (a, b) { return Number(b.id) - Number(a.id); });
      var out = [];
      var chain = Promise.resolve();
      rows.forEach(function (o) {
        chain = chain.then(function () {
          return orderLinesById(o.id).then(function (lines) {
            out.push({
              id: Number(o.id),
              order_number: String(o.order_number),
              order_type: String(o.order_type),
              type_label: DB.ORDER_TYPE_LABEL[o.order_type] || o.order_type,
              customer_name: o.customer_name || '',
              total: Number(o.total) || 0,
              created_at: String(o.created_at || ''),
              created_label: DB.dmyHi(o.created_at),
              items: lines
            });
          });
        });
      });
      return chain.then(function () { return out; });
    });
  }

  /* ---------- _order_payload() ---------- */
  function orderPayload(orderId, lines) {
    return orderRow(orderId).then(function (o) {
      if (!o) { return null; }
      var user = global.LPAUTH.currentUser();
      return {
        id: Number(o.id),
        order_number: String(o.order_number),
        order_type: String(o.order_type),
        order_type_label: DB.ORDER_TYPE_LABEL[o.order_type] || o.order_type,
        customer_name: o.customer_name || '',
        subtotal: Number(o.subtotal) || 0,
        discount: Number(o.discount) || 0,
        tax: Number(o.tax) || 0,
        total: Number(o.total) || 0,
        payment_method: String(o.payment_method),
        payment_label: DB.PAYMENT_LABEL[o.payment_method] || o.payment_method,
        received: (o.received === null || o.received === undefined) ? null : Number(o.received),
        change_due: Number(o.change_due) || 0,
        cashier_name: user ? String(user.name) : '',
        created_label: DB.dmyHi(o.created_at),
        status: String(o.status || ''),
        items: lines
      };
    });
  }


  /* =============================================================
     Handler utama — padanan blok action di api/orders.php
     ============================================================= */
  function handle(req) {
    return CORE.guard(['pos.order']).then(function (g) {
      if (g.error) { return g.error; }

      /* ---------- GET: detail order atau list hold ---------- */
      if (req.method === 'GET') {
        var id = Number(req.query.id || 0);
        if (id > 0) {
          return orderRow(id).then(function (o) {
            if (!o) { return CORE.fail('Order tidak ditemukan.', 404); }
            return orderLinesById(id).then(function (lines) {
              return orderPayload(id, lines);
            }).then(function (payload) {
              return CORE.ok({ order: payload });
            });
          });
        }
        return fetchHolds().then(function (holds) {
          return CORE.ok({ holds: holds });
        });
      }

      return DB.getSetting('tax_rate', 0).then(function (tr) {
        var taxRate = Number(tr) || 0;
        var uid = Number(global.LPAUTH.currentUser().id);
        var body = req.body || {};
        var action = String(body.action || 'create');

        if (action === 'hold') { return doHold(body, taxRate, uid); }
        if (action === 'update_hold') { return doUpdateHold(body, taxRate); }
        if (action === 'cancel') { return doCancel(body); }
        if (action === 'create') { return doCreate(body, taxRate, uid); }
        return CORE.fail('Action tidak dikenal.');
      });
    });
  }

  /* ---------- ACTION: hold ---------- */
  function doHold(body, taxRate, uid) {
    var orderType = String(body.order_type || '');
    var customerName = String(body.customer_name || '').trim();
    var discount = Math.max(0, PHP.parseMoney(body.discount));

    return computeLines(orderType, body.items || []).then(function (linesR) {
      if (linesR.error) { return CORE.fail(linesR.error); }
      var tot = PHP.computeTotals(linesR.subtotal, discount, taxRate);

      return insertOrder({
        order_type: orderType, customer_name: customerName, subtotal: linesR.subtotal,
        discount: tot.discount, tax: tot.tax, total: tot.total,
        payment_method: 'cash', received: null, status: 'hold', uid: uid
      }).then(function (res) {
        return replaceItems(res.id, linesR.lines).then(function () {
          return PHP.logActivity('order_hold', res.order_number, { items: linesR.lines.length });
        }).then(function () {
          return orderPayload(res.id, linesR.lines);
        }).then(function (payload) {
          return CORE.ok({ order: payload });
        });
      });
    }).catch(function (e) {
      return CORE.fail('Error simpan hold: ' + e.message, 500);
    });
  }

  /* ---------- ACTION: update_hold ---------- */
  function doUpdateHold(body, taxRate) {
    var orderId = Number(body.order_id || 0);
    return assertHold(orderId).then(function (h) {
      if (h.error) { return CORE.fail(h.error); }

      var orderType = String(body.order_type || '');
      var customerName = String(body.customer_name || '').trim();
      var discount = Math.max(0, PHP.parseMoney(body.discount));

      return computeLines(orderType, body.items || []).then(function (linesR) {
        if (linesR.error) { return CORE.fail(linesR.error); }
        var tot = PHP.computeTotals(linesR.subtotal, discount, taxRate);

        return db.orders.update(orderId, {
          order_type: orderType,
          customer_name: customerName !== '' ? customerName : null,
          subtotal: linesR.subtotal, discount: tot.discount,
          tax: tot.tax, total: tot.total
        }).then(function () {
          return replaceItems(orderId, linesR.lines);
        }).then(function () {
          return PHP.logActivity('order_hold_update', h.order.order_number,
            { items: linesR.lines.length });
        }).then(function () {
          return orderPayload(orderId, linesR.lines);
        }).then(function (payload) {
          return CORE.ok({ order: payload });
        });
      });
    }).catch(function (e) {
      return CORE.fail('Error update hold: ' + e.message, 500);
    });
  }

  /* ---------- ACTION: cancel ---------- */
  function doCancel(body) {
    var orderId = Number(body.order_id || 0);
    return assertHold(orderId).then(function (h) {
      if (h.error) { return CORE.fail(h.error); }
      return db.transaction('rw', db.orders, db.order_items, function () {
        return db.order_items.where('order_id').equals(orderId).delete()
          .then(function () { return db.orders.delete(orderId); });
      }).then(function () {
        return PHP.logActivity('order_cancel', h.order.order_number);
      }).then(function () {
        return CORE.ok({});
      });
    }).catch(function (e) {
      return CORE.fail('Error cancel hold: ' + e.message, 500);
    });
  }

  /* ---------- ACTION: create (bayar / finalisasi hold) ---------- */
  function doCreate(body, taxRate, uid) {
    var orderId = Number(body.order_id || 0);

    var pre = orderId > 0
      ? assertHold(orderId).then(function (h) { return h.error ? h.error : null; })
      : Promise.resolve(null);

    return pre.then(function (bad) {
      if (bad) { return bad; }

      var orderType = String(body.order_type || '');
      var customerName = String(body.customer_name || '').trim();
      var discount = Math.max(0, PHP.parseMoney(body.discount));
      var payMethod = String(body.payment_method || '');
      if (['cash', 'qris', 'debit', 'online'].indexOf(payMethod) === -1) {
        return CORE.fail('payment_method tidak valid.');
      }
      var received = null;
      if (payMethod === 'cash' && body.received !== undefined && body.received !== null
        && String(body.received) !== '') {
        received = PHP.parseMoney(body.received);
      }

      return computeLines(orderType, body.items || []).then(function (linesR) {
        if (linesR.error) { return CORE.fail(linesR.error); }
        var tot = PHP.computeTotals(linesR.subtotal, discount, taxRate);
        var change = (received !== null && received > tot.total) ? received - tot.total : 0;

        var flow;
        if (orderId === 0) {
          flow = insertOrder({
            order_type: orderType, customer_name: customerName, subtotal: linesR.subtotal,
            discount: tot.discount, tax: tot.tax, total: tot.total,
            payment_method: payMethod, received: received, status: 'paid', uid: uid
          }).then(function (res) { return { id: res.id, number: res.order_number }; });
        } else {
          flow = db.orders.update(orderId, {
            order_type: orderType,
            customer_name: customerName !== '' ? customerName : null,
            subtotal: linesR.subtotal, discount: tot.discount, tax: tot.tax,
            total: tot.total, payment_method: payMethod, received: received,
            change_due: change, status: 'paid'
          }).then(function () { return db.orders.get(orderId); })
            .then(function (o) { return { id: orderId, number: String(o.order_number) }; });
        }

        return flow.then(function (res) {
          return replaceItems(res.id, linesR.lines)
            .then(function () { return deductStock(linesR.lines, res.id, res.number, uid); })
            .then(function () {
              return PHP.logActivity('order_pay', res.number,
                { total: tot.total, payment: payMethod });
            })
            .then(function () { return orderPayload(res.id, linesR.lines); })
            .then(function (payload) {
              return DB.getSettings(['store_name', 'store_address', 'store_phone',
                'store_footer', 'tax_rate']).then(function (st) {
                  return CORE.ok({
                    order: payload,
                    store: {
                      store_name: st.store_name || 'Lampion Resto',
                      store_address: st.store_address || '',
                      store_phone: st.store_phone || '',
                      store_footer: st.store_footer || 'Terima kasih!',
                      tax_rate: Number(st.tax_rate) || 0
                    }
                  });
                });
            });
        });
      });
    }).catch(function (e) {
      return CORE.fail('Error simpan order: ' + e.message, 500);
    });
  }

  global.LPAPI = global.LPAPI || {};
  global.LPAPI.orders = handle;
  global.LPAPI._orders = {
    computeLines: computeLines,
    deductStock: deductStock,
    fetchHolds: fetchHolds,
    orderPayload: orderPayload,
    orderRow: orderRow,
    orderLinesById: orderLinesById
  };
})(window);

