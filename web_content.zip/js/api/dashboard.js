/* =============================================================
   LAMPION POS · js/api/dashboard.js
   Pengganti api/dashboard.php — statistik JSON (refresh real-time)
   ============================================================= */
(function (global) {
  'use strict';

  var DB = global.LPDB;
  var db = DB.db;
  var CORE = global.LPCORE;

  function handle(req) {
    return CORE.guard(['dashboard.view']).then(function (g) {
      if (g.error) { return g.error; }

      var today = DB.today();
      var weekCut = DB.shiftDays(-7);

      return Promise.all([
        db.orders.toArray(),
        db.order_items.toArray(),
        db.users.toArray()
      ]).then(function (res) {
        var orders = res[0], orderItems = res[1], users = res[2];
        var userById = {};
        users.forEach(function (u) { userById[Number(u.id)] = String(u.name); });

        var paid = orders.filter(function (o) { return String(o.status) === 'paid'; });
        var paidIds = {};
        paid.forEach(function (o) { paidIds[Number(o.id)] = 1; });

        /* --- hari ini --- */
        var todayPaid = paid.filter(function (o) { return DB.dateOf(o.created_at) === today; });
        var todaySales = 0;
        todayPaid.forEach(function (o) { todaySales += Number(o.total) || 0; });
        var todayTx = todayPaid.length;
        var todayAvg = todayTx > 0 ? (todaySales / todayTx) : 0;

        var todayItems = 0;
        orderItems.forEach(function (it) {
          if (paidIds[Number(it.order_id)]) {
            var owner = orders.filter(function (o) { return Number(o.id) === Number(it.order_id); })[0];
            if (owner && DB.dateOf(owner.created_at) === today) {
              todayItems += Number(it.qty) || 0;
            }
          }
        });

        /* --- 7 hari terakhir --- */
        var days = [];
        for (var i = 6; i >= 0; i--) {
          var d = DB.shiftDays(-i);
          var sum = 0;
          paid.forEach(function (o) {
            if (DB.dateOf(o.created_at) === d) { sum += Number(o.total) || 0; }
          });
          days.push({ label: DB.dayShortLabel(d), full: d, total: DB.round2(sum) });
        }

        /* --- top menu (7 hari) --- */
        var topMap = {};
        orderItems.forEach(function (it) {
          var owner = null;
          for (var k = 0; k < orders.length; k++) {
            if (Number(orders[k].id) === Number(it.order_id)) { owner = orders[k]; break; }
          }
          if (!owner || String(owner.status) !== 'paid') { return; }
          var od = DB.dateOf(owner.created_at);
          if (!(od >= weekCut)) { return; }
          var name = String(it.item_name);
          if (!topMap[name]) { topMap[name] = { item_name: name, qty: 0, total: 0 }; }
          topMap[name].qty += Number(it.qty) || 0;
          topMap[name].total += Number(it.subtotal) || 0;
        });
        var top = Object.keys(topMap).map(function (k) {
          return {
            item_name: topMap[k].item_name,
            qty: DB.round2(topMap[k].qty),
            total: DB.round2(topMap[k].total)
          };
        }).sort(function (a, b) { return b.qty - a.qty; }).slice(0, 5);

        /* --- metode bayar hari ini --- */
        var pmMap = {};
        todayPaid.forEach(function (o) {
          var pm = String(o.payment_method);
          if (!pmMap[pm]) { pmMap[pm] = { payment_method: pm, cnt: 0, total: 0 }; }
          pmMap[pm].cnt += 1;
          pmMap[pm].total += Number(o.total) || 0;
        });
        var payments = Object.keys(pmMap).map(function (k) {
          return {
            payment_method: k,
            cnt: pmMap[k].cnt,
            total: DB.round2(pmMap[k].total),
            label: DB.PAYMENT_LABEL[k] || k
          };
        });

        /* --- transaksi terbaru (LIMIT 8) --- */
        var recent = paid.slice().sort(function (a, b) {
          return Number(b.id) - Number(a.id);
        }).slice(0, 8).map(function (o) {
          return {
            id: Number(o.id),
            order_number: String(o.order_number),
            total: Number(o.total) || 0,
            payment_method: String(o.payment_method),
            order_type: String(o.order_type),
            created_at: String(o.created_at || ''),
            cashier: userById[Number(o.cashier_id)] || ''
          };
        });

        return CORE.ok({
          today: {
            sales: DB.round2(todaySales),
            tx: todayTx,
            avg_tx: DB.round2(todayAvg),
            items: DB.round2(todayItems)
          },
          days: days,
          top_menus: top,
          payments: payments,
          recent: recent
        });
      });
    });
  }

  global.LPAPI = global.LPAPI || {};
  global.LPAPI.dashboard = handle;
})(window);
