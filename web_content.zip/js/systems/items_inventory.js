'use strict';
/* ================= items / inventory ================= */
const ICONS={
 fist:'<rect x="6" y="9" width="12" height="9" rx="3"/><path d="M9 9V6M12 9V5M15 9V6"/>',
 sword:'<path d="M5 19L18 6M15 4h5v5M7 14l3 3M4 21l2-2"/>',
 axe:'<path d="M6 20L15 6M13 5c4-2 7 0 7 3l-5 2z"/>',
 bow:'<path d="M6 4c11 3 11 13 0 16M6 4v16M6 12h14M17 9l3 3-3 3"/>',
 gun:'<path d="M3 9h15v4H10l-1 6H6l1-6H3zM18 9h3"/>',
 wall:'<rect x="3" y="5" width="18" height="14"/><path d="M3 10h18M3 15h18M9 5v5M15 10v5M9 15v4"/>',
 floor:'<path d="M3 14l9-5 9 5-9 5zM7.5 11.5l9 5M16.5 11.5l-9 5"/>',
 fire:'<path d="M12 3c1 4 5 5 5 10a5 5 0 0 1-10 0c0-3 2-4 2-6 1 1 2 2 3-4z"/>',
 sp_deer:'<circle cx="12" cy="14" r="5"/><path d="M8 10L6 4M16 10l2-6M6 4L4 6M18 4l2 2"/>',
 sp_pig:'<circle cx="12" cy="12" r="7"/><ellipse cx="12" cy="14" rx="3" ry="2"/><path d="M6 7l2 2M18 7l-2 2"/>',
 sp_zombie:'<rect x="5" y="5" width="14" height="14" rx="5"/><path d="M8 10l2 2M10 10l-2 2M14 10l2 2M16 10l-2 2M9 16h6"/>'
};
const ITEMS={
 fist:{n:'قبضة',type:'melee',dmg:1,pow:1},
 pickaxe:{n:'معول',type:'melee',dmg:2,pow:2.2,pick:1},
 sword:{n:'سيف',type:'melee',dmg:4,pow:1.5},
 axe:{n:'فأس',type:'melee',dmg:2.5,pow:3,axe:1},
 bow:{n:'قوس',type:'ranged',ammo:'arrow'},
 gun:{n:'مسدس',type:'ranged',ammo:'bullet'},
 wall:{n:'جدار',type:'build',cost:{wood:3}},
 floor:{n:'أرضية',type:'build',cost:{wood:2}},
 fire:{n:'نار مخيم',type:'build',cost:{wood:3,stone:2}},
 sp_deer:{n:'غزال',type:'spawn',kind:'deer'},
 sp_pig:{n:'خنزير',type:'spawn',kind:'pig'},
 sp_zombie:{n:'زومبي',type:'spawn',kind:'zombie'}
};
const HOT_S=['fist','sword','axe','bow','gun','planks','cobble','table',null];
const HOT_C=['fist','sword','bow','gun','planks','cobble','glass','table','door'];
let HOT=HOT_S.slice();
const RES_ICONS={
 wood:'<rect x="4" y="8" width="16" height="9" rx="3"/><path d="M8 11h8"/>',
 stone:'<path d="M5 17l2-7 5-3 6 4 1 6z"/>',
 iron:'<path d="M4 16l4-8h8l4 8z"/><path d="M8 8l4 8 4-8"/>',
 meat:'<path d="M6 14c0-5 6-8 10-6s3 7-2 9-8 1-8-3zM17 7l3-3"/>',
 berry:'<circle cx="9" cy="14" r="4"/><circle cx="15" cy="14" r="4"/><path d="M12 6c1 2 2 3 4 3"/>',
 arrow:'<path d="M4 20L19 5M15 4h5v5M4 20l2-5M4 20l5-2"/>',
 bullet:'<rect x="9" y="6" width="6" height="12" rx="3"/><path d="M9 18h6"/>'
};
const RES_COL={coal:'#555',gold:'#ffd54a',diamond:'#4de8e0',leather:'#a0643a',bone:'#eee',feather:'#cfe7ff',fish:'#7fc8ff',planks:'#d9b077',log:'#8a5a2b',cobble:'#aab',dirt:'#8a5a33',sand:'#eadb9a',glass:'#bfe9ff',brick:'#c0524a',wool:'#f4f4f0',lamp:'#ffe27a',table:'#b57a3a',door:'#9a6a35',slab:'#c06050',wood:'#d9a066',stone:'#c3cad6',iron:'#ffa24a',meat:'#ff8fa3',berry:'#ff5a78',arrow:'#efe0b0',bullet:'#ffd54a'};
const NAMES={coal:'فحم',gold:'ذهب',diamond:'ألماس',leather:'جلد',bone:'عظام',feather:'ريش',fish:'سمك',planks:'ألواح خشب',log:'جذع',cobble:'حجارة مرصوصة',dirt:'تراب',sand:'رمل',glass:'زجاج',brick:'طوب',wool:'صوف',lamp:'مصباح',table:'طاولة صناعة',door:'باب',slab:'بلاطة سقف',wood:'خشب',stone:'حجر',iron:'حديد',meat:'لحم',berry:'توت',arrow:'سهام',bullet:'رصاص'};
const RECIPES=[
 {id:'sword',n:'سيف',cost:{wood:5,stone:4},tool:'sword'},
 {id:'axe',n:'فأس',cost:{wood:4,stone:3},tool:'axe'},
 {id:'bow',n:'قوس',cost:{wood:6},tool:'bow'},
 {id:'arrow',n:'سهام ×8',cost:{wood:2,stone:1},give:{arrow:8}},
 {id:'gun',n:'مسدس',cost:{stone:10,iron:5},tool:'gun'},
 {id:'bullet',n:'رصاص ×10',cost:{iron:2},give:{bullet:10},t:1},
 {id:'pickaxe',n:'معول',cost:{planks:3,stone:3},tool:'pickaxe'},
 {id:'r_planks',n:'ألواح خشب ×4',cost:{wood:1},give:{planks:4}},
 {id:'r_table',n:'طاولة صناعة',cost:{planks:4},give:{table:1}},
 {id:'r_cobble',n:'حجارة مرصوصة ×2',cost:{stone:2},give:{cobble:2}},
 {id:'r_glass',n:'زجاج ×2',cost:{sand:2,coal:1},give:{glass:2}},
 {id:'r_brick',n:'طوب ×2',cost:{stone:2,dirt:2},give:{brick:2}},
 {id:'r_door',n:'باب',cost:{planks:6},give:{door:1},t:1},
 {id:'r_slab',n:'بلاطات سقف ×4',cost:{cobble:2},give:{slab:4}},
 {id:'r_lamp',n:'مصباح',cost:{glass:1,coal:1,iron:1},give:{lamp:1},t:1},
 {id:'r_log',n:'جذع ×1',cost:{wood:3},give:{log:1}}
];
let INV,TOOLS,slotIdx=0,creative=false;
function resetInv(){INV={wood:0,stone:0,iron:0,meat:0,berry:0,arrow:0,bullet:0,coal:0,gold:0,diamond:0,leather:0,bone:0,feather:0,fish:0,planks:0,log:0,cobble:0,dirt:0,sand:0,glass:0,brick:0,wool:0,lamp:0,table:0,door:0,slab:0};TOOLS={fist:1};}
resetInv();
const has=(k,n)=>creative||INV[k]>=n;
const take=(k,n)=>{if(!creative)INV[k]-=n;};
const hotList=()=>HOT;
const curId=()=>hotList()[slotIdx]||'fist';
const owns=id=>!!id&&(creative||!!TOOLS[id]||ITEMS[id].type==='build'||ITEMS[id].type==='block');

