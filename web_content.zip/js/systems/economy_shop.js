'use strict';
/* ================= economy: perks, weapons, armor, daily chest, quests, trade ================= */
const PERK={ /*v6 extra perks merged below*/knight:{red:.1},ninja:{spd:.12},wizard:{regen:1},pirate:{coin:.2},alien:{jump:.2},robot:{hungry:.4},king:{coin:.15},farmer:{food:.3},astronaut:{jump:.45},vampire:{vamp:.2},samurai:{dmg:.25},cyber:{spd:.18,dmg:.15},phoenix:{spd:1,dmg:1,fire:1}};
const PERK2={knight:{nofall:.5},ninja:{stealth:.4},pirate:{air:.5},alien:{nofall:.6},robot:{red:.05},king:{trade:.2},farmer:{loot:.35},astronaut:{nofall:1,air:.4},vampire:{stealth:.2},samurai:{crit:.15},cyber:{loot:.25}};
for(const k in PERK2)Object.assign(PERK[k],PERK2[k]);
const pk=k=>{const p=PERK[S.skin];return (p&&p[k])||0;};
const ARMORS={leather:{n:'درع جلدي',p:500,red:.15,c:0x8a5a2b},iron:{n:'درع حديدي',p:1600,red:.32,c:0xc9ced6},diamond:{n:'درع ألماس',p:4200,red:.52,c:0x4de8e0}};
const WEAPS={
 sw_stone:{n:'سيف حجري',p:300,dmg:5,pow:1.7,col:0x9aa0a8},
 sw_iron:{n:'سيف حديدي',p:900,dmg:7,pow:2,col:0xe6eaf0},
 sw_dia:{n:'سيف ألماس',p:2600,dmg:10,pow:2.4,col:0x4de8e0},
 sw_fire:{n:'سيف ناري',p:5200,dmg:14,pow:2.8,col:0xff6a1a,burn:1},
 bow_exp:{n:'قوس متفجر',p:3800,ranged:1}
};
for(const k in WEAPS){const w=WEAPS[k];ITEMS[k]=w.ranged?{n:w.n,type:'ranged',ammo:'arrow',explosive:1}:{n:w.n,type:'melee',dmg:w.dmg,pow:w.pow,burn:w.burn};ICONS[k]=ICONS[w.ranged?'bow':'sword'];}
const armorRed=()=>{const a=S.armor&&ARMORS[S.armor];return Math.min(.8,(a?a.red:0)+pk('red'));};
const dmgMul=()=>1+pk('dmg');
function addCoins(n){n=Math.round(n*(1+pk('coin')));S.coins+=n;save();if(playing)sfx('coin');return n;}
function addArmor(ch,tier){
 const old=ch.g.getObjectByName('armor');if(old)ch.g.remove(old);
 const a=ARMORS[tier];if(!a)return;
 const g=new T.Group();g.name='armor';const m=new T.MeshLambertMaterial({color:a.c,flatShading:true});
 const chest=new T.Mesh(GM.sph,m);chest.scale.set(.56,.62,.42);chest.position.y=1.42;g.add(chest);
 const helm=new T.Mesh(GM.sph,m);helm.scale.set(.46,.36,.46);helm.position.y=2.1;g.add(helm);
 for(const sx of[-1,1]){const b=new T.Mesh(GM.sph,m);b.scale.set(.2,.12,.26);b.position.set(.2*sx,.08,.05);g.add(b);const sh=new T.Mesh(GM.sph,m);sh.scale.set(.2,.14,.2);sh.position.set(.55*sx,1.7,0);g.add(sh);}
 g.traverse(o=>{if(o.isMesh)o.castShadow=true;});ch.g.add(g);
}
function fireAura(ch){
 if(ch.g.getObjectByName('aura'))return;
 const g=new T.Group();g.name='aura';
 for(let i=0;i<7;i++){const f=new T.Mesh(GM.cone,new T.MeshBasicMaterial({color:i%2?0xffc23a:0xff6a1a,transparent:true,opacity:.75}));f.userData.a=i/7*6.283;f.scale.set(.18,.7,.18);g.add(f);}
 const l=new T.PointLight(0xff8a2a,1.3,9);l.position.y=1.4;g.add(l);ch.aura=g;ch.g.add(g);
}
function animAura(ch,t){if(!ch.aura)return;ch.aura.children.forEach((f,i)=>{if(!f.isMesh)return;const a=f.userData.a+t*1.8;f.position.set(Math.cos(a)*.75,.5+((t*1.2+i*.37)%1.6),Math.sin(a)*.75);f.scale.y=.5+((t*3+i)%1)*.5;f.material.opacity=.8-((t*1.2+i*.37)%1.6)*.4;});}
function decorChar(ch,skinId,armor){addArmor(ch,armor);if(skinId==='phoenix')fireAura(ch);}
/* held weapon colours */
const _held=heldMesh;
heldMesh=function(id){
 if(WEAPS[id]&&!WEAPS[id].ranged){const g=new T.Group();const M=c=>new T.MeshLambertMaterial({color:c,flatShading:true,emissive:id==='sw_fire'?0x661a00:0});
  const b=new T.Mesh(GM.cyl,M(WEAPS[id].col));b.scale.set(.07,1.05,.025);b.position.y=-.55;g.add(b);const gd=new T.Mesh(GM.cyl,M(0xc9a23a));gd.scale.set(.22,.05,.07);gd.position.y=-.05;g.add(gd);return g;}
 return _held(id==='bow_exp'?'bow':id);
};
function explode(p){
 particles(p.x,p.y,p.z,0xff8a1a,18);particles(p.x,p.y,p.z,0xffe27a,10);sfx('boom');
 for(const e of ents.slice()){if(Math.hypot(e.x-p.x,e.z-p.z)<3.6&&Math.abs(e.y-p.y)<3)dmgEnt(e,9*dmgMul(),0,0);}
 if(Math.hypot(P.x-p.x,P.z-p.z)<2)hurt(8);
}
/* purchased items go to the player's tools */
function grantStock(){
 for(const id of (S.stock||[]))TOOLS[id]=1;
 if(S.name){const best=['sw_fire','sw_dia','sw_iron','sw_stone'].find(id=>TOOLS[id]);if(best&&!creative)HOT[8]=best;if(TOOLS.bow_exp&&!creative)HOT[3]='bow_exp';}
}
/* ---- daily chest ---- */
const dayKey=(d=new Date())=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
const dayDiff=(a,b)=>Math.round((new Date(b+'T00:00:00')-new Date(a+'T00:00:00'))/864e5);
/* 28-day reward path: one claim per calendar day per DEVICE (survives re-login, new accounts, reloads) */
const GIFT_PATH=[
 {c:10},{c:12},{c:15,i:{wood:10}},{c:15},{c:20,i:{arrow:12}},{c:20},{c:35,i:{iron:3}},
 {c:20},{c:22,i:{planks:12}},{c:25},{c:25,i:{coal:6}},{c:30},{c:30,i:{bullet:10}},{c:60,i:{gold:2}},
 {c:30},{c:32,i:{glass:8}},{c:35},{c:35,i:{iron:5}},{c:40},{c:40,i:{brick:8}},{c:70,i:{diamond:1}},
 {c:40},{c:45,i:{wool:6}},{c:45},{c:50,i:{gold:3}},{c:55},{c:60,i:{lamp:2}},{c:150,i:{diamond:3}}
];
function devGet(){let v='';try{v=localStorage.getItem('ard_gift_dev')||'';}catch(e){}if(!v){const m=document.cookie.match(/(?:^|; )ard_gd=([^;]*)/);if(m)v=decodeURIComponent(m[1]);}return v;}
function devSet(v){try{localStorage.setItem('ard_gift_dev',v);}catch(e){}try{document.cookie='ard_gd='+encodeURIComponent(v)+';max-age=31536000;path=/;SameSite=Lax';}catch(e){}}
function giftState(){
 const g=S.gift||{last:'',n:0};const t=dayKey();const dv=devGet();
 const dvLast=dv.split('|')[0]||'';
 if(g.last===t||dvLast===t)return {can:false,n:g.n|0,streak:g.n|0};
 return {can:true,n:g.n|0,streak:g.n|0};
}
function claimGift(){
 const st=giftState();if(!st.can)return null;
 const n=st.n,idx=n%GIFT_PATH.length,r=GIFT_PATH[idx];
 const coins=r.c;S.coins+=coins;
 let extra='';if(r.i){for(const k in r.i){giveInv(k,r.i[k]);extra+=' + '+r.i[k]+' '+(NAMES[k]||k);}}
 S.gift={last:dayKey(),n:n+1,streak:n+1};weekPoint(1);devSet(dayKey()+'|'+(n+1));save();cloud.push();beep(740,.2,'triangle',.06);
 return {n:coins,streak:n+1,cyc:idx+1,extra};
}
/* ---- daily quests ---- */
const QPOOL=[{id:'zombie',n:'اقتل {n} زومبي',need:[3,6],r:10},{id:'hunt',n:'اصطد {n} حيوانات',need:[3,5],r:8},{id:'crystal',n:'اجمع {n} بلورات من الكهوف',need:[2,4],r:10},{id:'trade',n:'تاجر مع القرويين {n} مرات',need:[1,3],r:6},{id:'play',n:'العب {n} دقائق',need:[5,12],r:7},{id:'wood',n:'اجمع {n} خشب',need:[10,20],r:5}];
function ensureQuests(){
 const t=dayKey();if(S.quests&&S.quests.day===t)return;
 const rng=mulberry(hashStr(t+S.name));const pool=QPOOL.slice();const list=[];
 while(list.length<3&&pool.length){const q=pool.splice(Math.floor(rng()*pool.length),1)[0];const need=q.need[0]+Math.floor(rng()*(q.need[1]-q.need[0]+1));list.push({id:q.id,need,prog:0,done:0,r:Math.max(2,Math.min(10,Math.round(q.r*need/q.need[1]))),tpl:q.n});}
 S.quests={day:t,list};save();
}
function mkQuest(excl){
 const pool=QPOOL.filter(q=>!excl.includes(q.id));const q=(pool.length?pool:QPOOL)[Math.floor(Math.random()*(pool.length||QPOOL.length))];
 const need=q.need[0]+Math.floor(Math.random()*(q.need[1]-q.need[0]+1));
 return {id:q.id,need,prog:0,done:0,r:Math.max(2,Math.min(10,Math.round(q.r*need/q.need[1]))),tpl:q.n};
}
function replaceQuest(q){
 if(!S.quests)return;const i=S.quests.list.indexOf(q);if(i<0)return;
 S.quests.list[i]=mkQuest(S.quests.list.map(x=>x.id));save();renderQuests();
}
function questEv(id,n){
 if(!S.name||creative)return;ensureQuests();
 for(const q of S.quests.list){if(q.id!==id||q.done)continue;q.prog=Math.min(q.need,q.prog+n);if(q.prog>=q.need){q.done=1;const c=Math.min(10,q.r);S.coins+=c;save();toast('مهمة مكتملة! +'+c+' عملة');beep(880,.2,'triangle',.06);cloud.event('quest',q.id);weekPoint(1);setTimeout(()=>replaceQuest(q),1800);}}
 save();
}
const qText=q=>tr(q.tpl).replace('{n}',q.need);
const WEEK_TIERS=[{p:2,c:5},{p:4,c:8,i:{planks:10}},{p:6,c:10},{p:9,c:12,i:{iron:4}},{p:12,c:15,i:{coal:8}},{p:16,c:20,i:{gold:2}},{p:20,c:40,i:{diamond:1}}];
function weekKey(d=new Date()){const x=new Date(Date.UTC(d.getFullYear(),d.getMonth(),d.getDate()));const dn=x.getUTCDay()||7;x.setUTCDate(x.getUTCDate()+4-dn);const y=x.getUTCFullYear();return y+'-W'+Math.ceil(((x-Date.UTC(y,0,1))/864e5+1)/7);}
function ensureWeek(){const k=weekKey();if(!S.week||S.week.k!==k){S.week={k,pts:0,cl:[]};save();}return S.week;}
function weekPoint(n){if(!S.name||creative)return;const w=ensureWeek();w.pts+=n;save();}
function claimWeek(i){const w=ensureWeek(),r=WEEK_TIERS[i];if(!r||w.pts<r.p||w.cl.includes(i))return;w.cl.push(i);S.coins+=r.c;if(r.i)for(const k in r.i)giveInv(k,r.i[k]);save();cloud.push();sfx('coin');toast('جائزة المسار الأسبوعي! +'+r.c+' عملة');refreshHud();renderWeekly();const m=$('homeCoins');if(m)m.textContent=S.coins;}
function renderWeekly(){
 const box=$('weekly');if(!box)return;const w=ensureWeek();box.innerHTML='';$('weekInfo').textContent=tr('النقاط')+': '+w.pts;
 WEEK_TIERS.forEach((r,i)=>{const b=document.createElement('button');const done=w.cl.includes(i),ok=w.pts>=r.p;b.className='mode '+(done?'alt3':ok?'alt1':'alt2');b.disabled=done||!ok;
  let extra='';if(r.i)for(const k in r.i)extra+=' +'+r.i[k]+' '+(NAMES[k]||k);
  b.innerHTML='<b>'+r.p+' '+tr('نقطة')+'</b><small>+'+r.c+' '+tr('عملة')+extra+(done?' ✓':'')+'</small>';b.addEventListener('click',()=>claimWeek(i));box.appendChild(b);});
}
function renderQuests(){
 const box=$('quests');if(!box)return;ensureQuests();box.innerHTML='';
 for(const q of S.quests.list){const d=document.createElement('div');d.className='q'+(q.done?' done':'');d.innerHTML='<span>'+qText(q)+'</span><b>'+q.prog+'/'+q.need+' · +'+q.r+'</b>';box.appendChild(d);}
 renderWeekly();
 renderWeekly();
}
/* ---- villager trade ---- */
const OFFERS=[
 {s:{wood:8},c:4},{s:{stone:6},c:4},{s:{iron:3},c:9},{s:{coal:6},c:5},{s:{gold:2},c:12},{s:{diamond:1},c:20},
 {s:{meat:4},c:3},{s:{leather:3},c:5},{s:{wool:4},c:4},{s:{feather:6},c:3},{s:{fish:3},c:3},{s:{bone:5},c:3},{s:{sand:10},c:3},
 {b:{arrow:8},c:6},{b:{bullet:10},c:20},{b:{iron:2},c:14},{b:{planks:8},c:5},{b:{glass:4},c:5},{b:{brick:4},c:8},{b:{wool:3},c:6},{b:{coal:4},c:6},{b:{meat:2},c:6},{b:{lamp:2},c:12},{b:{diamond:1},c:60}
];
function renderTrade(){
 const box=$('tradeList');box.innerHTML='';$('tradeCoins').textContent=S.coins;
 for(const o of OFFERS){
  const sell=!!o.s,it=o.s||o.b;const k=Object.keys(it)[0];
  const b=document.createElement('button');b.className='offer';
  b.innerHTML='<span>'+(sell?'بيع ':'شراء ')+it[k]+' '+NAMES[k]+'</span><b>'+(sell?'+':'-')+o.c+'</b>';
  b.addEventListener('click',()=>{
   if(sell){if(!has(k,it[k])){toast('ينقصك '+NAMES[k]);return;}take(k,it[k]);addCoins(Math.round(o.c*(1+pk('trade'))));}
   else{const pr=Math.max(1,Math.round(o.c*(1-pk('trade'))));if(S.coins<pr){toast('عملات غير كافية');return;}S.coins-=pr;giveInv(k,it[k]);save();}
   questEv('trade',1);beep(520,.1,'triangle');renderTrade();refreshHud();
  });
  box.appendChild(b);
 }
}
function openTrade(){if(!nearVillager||creative&&false)return;renderTrade();$('trade').classList.add('on');}
$('bTalk').addEventListener('click',openTrade);
$('tradeX').addEventListener('click',()=>$('trade').classList.remove('on'));
hold($('bRun'),()=>{runHeld=true;},()=>{runHeld=false;});

