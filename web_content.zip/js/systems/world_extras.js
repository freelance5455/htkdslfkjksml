'use strict';
/* ================= world_ext: pets farm legends gifts bosses music quality ================= */
Object.assign(ANIMALS,{
 dog:{c:0x9a7448,w:.26,l:.52,h:.32,lg:.3,hp:20,meat:0,coin:0,sp:3.6,ears:1},
 cub:{c:0x6b4a30,w:.34,l:.55,h:.4,lg:.28,hp:30,meat:0,coin:0,sp:3.4,ears:1}
});
const BOOST=()=>{try{const b=JSON.parse(localStorage.getItem('ard_boost')||'null');if(b&&b.until>Date.now())return b;}catch(e){}return null;};
const boostX=()=>{const b=BOOST();return b&&b.coinX>1?b.coinX:1;};
const isVip=()=>{const m=S.meta;return !!(m&&m.vip>Date.now());};
const vipK=()=>isVip()?.25:0;
function gotBoost(d){
 if(!d||typeof d.id!=='string'||d.id.length>30)return;if(+d.coinX<=1&&+d.xpX<=1){try{localStorage.removeItem('ard_boost');}catch(e){}renderBoost();return;}const until=+d.until;if(!(until>Date.now())||until>Date.now()+13*36e5)return;
 const b={id:d.id,coinX:Math.max(1,Math.min(5,+d.coinX||1)),xpX:Math.max(1,Math.min(5,+d.xpX||1)),until,label:String(d.label||'').slice(0,40)};
 let old=null;try{old=JSON.parse(localStorage.getItem('ard_boost')||'null');}catch(e){}
 if(old&&old.id===b.id)return;try{localStorage.setItem('ard_boost',JSON.stringify(b));}catch(e){}renderBoost();toast('🔥 عرض من المالك: '+(b.label||'مضاعفة المكافآت'));
}



/* ---------- more: lucky chest, bank, titles, records, fps ---------- */
const CHEST_MS=4*36e5;
const TITLES=[{id:'t0',n:'مبتدئ',ok:()=>true},{id:'t1',n:'صيّاد زومبي',ok:()=>((S.meta.cnt||{}).zombie|0)>=50},{id:'t2',n:'قاهر الزعماء',ok:()=>((S.meta.cnt||{}).boss|0)>=3},{id:'t3',n:'مزارع محترف',ok:()=>((S.meta.cnt||{}).farm|0)>=40},{id:'t4',n:'ملياردير',ok:()=>S.coins>=50000},{id:'t5',n:'جامع الشخصيات',ok:()=>S.owned.length>=8},{id:'t6',n:'ملك الكومبو',ok:()=>((W().rec||{}).combo|0)>=15},{id:'t7',n:'VIP',ok:()=>isVip()}];
const myTitle=()=>{const m=W();const t=TITLES.find(x=>x.id===m.title);return t&&t.ok()?t:TITLES[0];};
let fpsOn=false,fpsN=0,fpsT=0,fpsV=0;
function fpsTick(){if(!fpsOn)return;fpsN++;const n=performance.now();if(n-fpsT>=1000){fpsV=fpsN;fpsN=0;fpsT=n;let el=$('fpsBox');if(!el){el=document.createElement('div');el.id='fpsBox';el.style.cssText='position:fixed;top:4px;left:50%;transform:translateX(-50%);z-index:60;background:rgba(0,0,0,.55);color:#9f9;font:12px monospace;padding:2px 8px;border-radius:8px;pointer-events:none';document.body.appendChild(el);}el.textContent=fpsV+' FPS';}requestAnimationFrame(fpsTick);}
function moreHtml(){const m=W(),now=Date.now();const bk=m.bank||(m.bank={b:0,t:0});const next=(+m.chest||0)+CHEST_MS,left=next-now,rec=m.rec||{};
 const dayI=Math.min(7,Math.floor((now-bk.t)/864e5)),intr=bk.b>0?Math.floor(bk.b*.02*dayI):0;
 let h='<div class="hd"><span>صندوق الحظ</span></div><div class="frow"><b>صندوق مجاني كل 4 ساعات</b><small>'+(left>0?'متاح بعد '+fmtT(left/1000):'جاهز! عملات وأحياناً جواهر')+'</small><button class="'+(left<=0?'ok':'')+'" data-mx="chest" '+(left>0?'disabled':'')+'>افتح</button></div>';
 h+='<div class="hd"><span>البنك</span></div><div class="note">أودع عملاتك فتنمو 2% يومياً (حتى 7 أيام، الحد 20,000).</div><div class="frow"><b>رصيدك المودَع: '+fmt0(bk.b)+'</b><small>الفائدة الحالية: +'+fmt0(intr)+'</small></div><div class="frow" style="flex-wrap:wrap"><div class="row2" style="width:100%"><button data-mx="dep" data-v="500">إيداع 500</button><button data-mx="dep" data-v="2000">إيداع 2000</button><button data-mx="wd" data-v="all">سحب الكل</button></div></div>';
 h+='<div class="hd"><span>كود هدية</span></div><div class="frow" style="flex-wrap:wrap"><input id="codeIn" maxlength="20" placeholder="أدخل الكود" style="flex:1;min-width:120px;padding:8px;border-radius:8px;border:1px solid #555;background:#111;color:#fff;text-transform:uppercase" dir="ltr"><button data-mx="code">تفعيل</button></div>';
 h+='<div class="hd"><span>لقبي: '+myTitle().n+'</span></div><div class="frow" style="flex-wrap:wrap"><div class="row2" style="width:100%">'+TITLES.map(t=>'<button data-mx="title" data-v="'+t.id+'" '+(t.ok()?'':'disabled')+(myTitle().id===t.id?' class="ok"':'')+'>'+t.n+(t.ok()?'':' 🔒')+'</button>').join('')+'</div></div>';
 h+='<div class="hd"><span>أرقامي القياسية</span></div><div class="frow"><b>أعلى كومبو</b><small></small><span class="coinTag">×'+(rec.combo|0)+'</span></div><div class="frow"><b>عدّاد الإطارات (FPS)</b><small>لقياس الأداء</small><button data-mx="fps">'+(fpsOn?'إيقاف':'تشغيل')+'</button></div>';
 return h;}
const fmt0=n=>Math.floor(n||0).toLocaleString('en');
function moreAct(k,v){const m=W(),now=Date.now();
 if(k==='chest'){if(now<(+m.chest||0)+CHEST_MS)return;const r=Math.random();let c=50+Math.floor(Math.random()*300),g=0;if(r<.12){g=1+(Math.random()<.3?1:0);}else if(r>.9)c*=2;m.chest=now;addCoins(c);if(g)S.gems=(S.gems|0)+g;save();cloud.push();sfx('coin');say('صندوق الحظ: +'+c+' عملة'+(g?' و'+g+' جوهرة 💎':''));refreshHud();}
 else if(k==='dep'){const bk=m.bank||(m.bank={b:0,t:0});const n=+v;if(S.coins<n){say('لا تملك '+n+' عملة');return;}if(bk.b+n>20000){say('الحد الأقصى 20,000');return;}if(bk.b>0){const di=Math.min(7,Math.floor((now-bk.t)/864e5));bk.b+=Math.floor(bk.b*.02*di);}S.coins-=n;bk.b+=n;bk.t=now;save();cloud.push();sfx('coin');refreshHud();}
 else if(k==='wd'){const bk=m.bank;if(!bk||bk.b<=0){say('لا يوجد رصيد');return;}const di=Math.min(7,Math.floor((now-bk.t)/864e5));const tot=bk.b+Math.floor(bk.b*.02*di);S.coins+=tot;bk.b=0;bk.t=0;save();cloud.push();sfx('coin');say('سُحب '+fmt0(tot)+' عملة');refreshHud();}
 else if(k==='title'){m.title=v;save();}
 else if(k==='code'){redeem(($('codeIn')||{}).value);return;}
 else if(k==='fps'){fpsOn=!fpsOn;if(fpsOn){fpsT=performance.now();fpsN=0;requestAnimationFrame(fpsTick);}else{const e=$('fpsBox');e&&e.remove();}}
 renderWorld();}


/* ---------- owner live control ---------- */
const CTL={god:0,frz:0,fx:0,fz:0,q:[],seen:[]};
try{CTL.seen=JSON.parse(localStorage.getItem('ard_cmds')||'[]')||[];}catch(e){}
const CTL_SPAWN=['zombie','skeleton','bear','trex','tricera','ptero','boss'];
const CTL_RES=()=>Object.keys(INV);
const ctlName=k=>NAMES[k]||(ITEMS[k]&&ITEMS[k].n)||k;
function gotCmd(d){if(!d||typeof d.id!=='string'||d.id.length>30||typeof d.a!=='string')return;
 if(CTL.seen.includes(d.id))return;const srv=+d._srv||0;if(!srv||Date.now()-srv>180000||srv-Date.now()>600000)return;
 CTL.seen.push(d.id);CTL.seen=CTL.seen.slice(-40);try{localStorage.setItem('ard_cmds',JSON.stringify(CTL.seen));}catch(e){}
 CTL.q.push({a:d.a,v:String(d.v||'').slice(0,20),n:Math.max(1,Math.min(999,Math.floor(+d.n||1))),exp:srv+180000});}
function ctlTick(){
 if(CTL.frz>Date.now()&&P){P.x=CTL.fx;P.z=CTL.fz;}
 if(!CTL.q.length||!playing||!P)return;
 const c=CTL.q.shift();if(Date.now()>c.exp)return;
 try{ctlApply(c);}catch(e){}
 refreshHud();}
function ctlApply(c){const a=c.a,v=c.v,n=c.n;let t='';
 if(a==='give'){if(v in INV){giveInv(v,n);t='أعطاك '+n+' '+ctlName(v);}else if(ITEMS[v]&&v!=='fist'&&(ITEMS[v].type==='melee'||ITEMS[v].type==='ranged')){TOOLS[v]=1;t='أعطاك '+ctlName(v);}else return;}
 else if(a==='take'){if(v in INV){INV[v]=Math.max(0,INV[v]-n);t='سحب منك '+n+' '+ctlName(v);}else if(TOOLS[v]&&v!=='fist'){delete TOOLS[v];t='سحب منك '+ctlName(v);}else return;}
 else if(a==='clear'){resetInv();t='أفرغ حقيبتك';}
 else if(a==='heal'){P.hp=100;P.food=100;P.air=100;t='شفاك بالكامل';}
 else if(a==='hurt'){hurt(Math.min(90,n),false);t='أصابك بضرر '+Math.min(90,n);}
 else if(a==='kill'){if(creative)return;P.hp=1;hurt(5,false);t='أنهى حياتك';}
 else if(a==='spawn'){if(!CTL_SPAWN.includes(v))return;const k=Math.min(5,n);if(v==='boss'){try{spawnBoss();}catch(e){}t='استدعى زعيماً!';}else{for(let i=0;i<k;i++)trySpawn(v,6,12);t='أظهر لك '+k+' من الأعداء';}}
 else if(a==='purge'){let k=0;for(const e of ents.slice()){if(e.pet||e.kind==='villager')continue;if(e.kind==='zombie'||e.kind==='skeleton'||e.hostile||e.boss||e.kind==='bear'){removeEnt(e);k++;}}t='أزال '+k+' عدواً';}
 else if(a==='tod'){tod=v==='night'?.75:.25;t=v==='night'?'جعلها ليلاً':'جعلها نهاراً';}
 else if(a==='tp'){P.x=spawn.x;P.z=spawn.z;P.y=heightAt(spawn.x,spawn.z)+1;P.vy=0;t='نقلك إلى نقطة البداية';}
 else if(a==='freeze'){CTL.frz=Date.now()+Math.min(30,n)*1000;CTL.fx=P.x;CTL.fz=P.z;t='جمّدك '+Math.min(30,n)+' ثانية';}
 else if(a==='god'){CTL.god=Date.now()+Math.min(120,n)*1000;t='جعلك لا تُقهر '+Math.min(120,n)+' ثانية';}
 else if(a==='fly'){P.fly=v!=='off';t=P.fly?'فعّل الطيران لك':'أوقف الطيران';}
 else if(a==='food'){P.food=100;t='أشبعك';}
 else if(a==='kick'){toast('🛠️ المالك أنهى جلستك');try{save();}catch(e){}setTimeout(()=>location.reload(),1200);return;}
 else return;
 toast('🛠️ المالك '+t);}
/* ---------- owner promo codes ---------- */
const hcode=t=>{t=String(t||'').trim().toUpperCase();let h=2166136261;for(let i=0;i<t.length;i++){h^=t.charCodeAt(i);h=Math.imul(h,16777619)>>>0;}return h.toString(36)+t.length;};
const CODES=()=>{try{return (JSON.parse(localStorage.getItem('ard_codes')||'[]')||[]).filter(c=>c&&c.until>Date.now());}catch(e){return [];}};
function gotCode(d){if(!d||typeof d.id!=='string'||d.id.length>30||typeof d.h!=='string'||d.h.length>16)return;let l=[];try{l=JSON.parse(localStorage.getItem('ard_codes')||'[]')||[];}catch(e){}
 l=l.filter(c=>c&&c.h!==d.h&&c.until>Date.now());
 if(+d.revoke!==1){const until=+d.until;if(!(until>Date.now())||until>Date.now()+31*864e5)return;l.push({id:d.id,h:d.h,coins:Math.max(0,Math.min(5000,Math.floor(+d.coins||0))),gems:Math.max(0,Math.min(50,Math.floor(+d.gems||0))),until});}
 try{localStorage.setItem('ard_codes',JSON.stringify(l.slice(-30)));}catch(e){}}
function redeem(txt){const m=W();const h=hcode(txt);if(!String(txt||'').trim()){say('اكتب الكود');return;}
 const c=CODES().find(x=>x.h===h);if(!c){say('كود غير صالح أو منتهٍ');sfx('hit');return;}
 m.codes=m.codes||[];if(m.codes.includes(c.id)){say('استخدمت هذا الكود من قبل');return;}
 m.codes.push(c.id);S.coins+=c.coins;S.gems=(S.gems|0)+c.gems;save();cloud.push();try{cloud.event('code',c.id);}catch(e){}sfx('coin');say('🎁 تم! +'+c.coins+' عملة'+(c.gems?' +'+c.gems+' جوهرة':''));refreshHud();renderWorld();}
/* ---------- kill combo + haptics ---------- */
let cmbN=0,cmbT=0;
function comboKill(){const n=Date.now();cmbN=(n-cmbT<6000)?cmbN+1:1;cmbT=n;try{const r=(W().rec=W().rec||{});if(cmbN>(r.combo|0))r.combo=cmbN;}catch(e){}
 if(cmbN>=3&&(cmbN===3||cmbN%5===0)){const b=Math.min(200,cmbN*8);if(!creative){S.coins+=b;save();}toast('🔥 كومبو ×'+cmbN+' · +'+b+' عملة');try{sfx('coin');}catch(e){}try{navigator.vibrate&&navigator.vibrate(40);}catch(e){}}}
/* ---------- owner: flash sale + notice ---------- */
const SALE=()=>{try{const b=JSON.parse(localStorage.getItem('ard_sale')||'null');return b&&b.until>Date.now()&&b.pct>0?b:null;}catch(e){return null;}};
const saleK=()=>{const b=SALE();return b?1-Math.min(70,Math.max(5,b.pct))/100:1;};
function gotSale(d){if(!d||typeof d.id!=='string'||d.id.length>30)return;if(+d.pct===0){try{localStorage.removeItem('ard_sale');}catch(e){}renderNotice();try{if($('skins'))renderShop();}catch(e){}return;}const pct=Math.max(0,Math.min(70,Math.floor(+d.pct||0))),until=+d.until;if(!(until>Date.now())||until>Date.now()+13*36e5)return;
 let old=null;try{old=JSON.parse(localStorage.getItem('ard_sale')||'null');}catch(e){}if(old&&old.id===d.id)return;
 try{localStorage.setItem('ard_sale',JSON.stringify({id:d.id,pct,until}));}catch(e){}if(pct>0)toast('🏷️ تخفيض '+pct+'% في المتجر!');renderNotice();try{if(typeof renderShop==='function'&&$('skins'))renderShop();}catch(e){}}
function gotNotice(d){if(!d||typeof d.id!=='string'||d.id.length>30)return;const until=+d.until;if(!(until>Date.now())||until>Date.now()+13*36e5)return;
 let old=null;try{old=JSON.parse(localStorage.getItem('ard_notice')||'null');}catch(e){}if(old&&old.id===d.id)return;
 try{localStorage.setItem('ard_notice',JSON.stringify({id:d.id,msg:String(d.msg||'').slice(0,100),until,warn:d.warn?1:0}));}catch(e){}renderNotice();}
function renderNotice(){const el=$('noticeBox');if(!el)return;let h='';const s=SALE();if(s)h+='<div class="warn" style="background:rgba(60,200,120,.16);border-color:#31d98a"><b>🏷️ تخفيض '+s.pct+'% على المتجر</b> · ينتهي بعد '+Math.max(1,Math.round((s.until-Date.now())/6e4))+' د</div>';
 let n=null;try{n=JSON.parse(localStorage.getItem('ard_notice')||'null');}catch(e){}if(n&&n.until>Date.now())h+='<div class="warn" style="'+(n.warn?'background:rgba(255,80,80,.16);border-color:#ff5a6a':'')+'"><b>📢 '+esc2(n.msg)+'</b></div>';
 el.innerHTML=h;}
setInterval(()=>{try{renderNotice();}catch(e){}},30000);setTimeout(()=>{try{renderNotice();}catch(e){}},1600);
function renderBoost(){const el=$('boostBox');if(!el)return;const b=BOOST();if(!b){el.innerHTML='';return;}
 const left=Math.max(1,Math.round((b.until-Date.now())/6e4)),hh=Math.floor(left/60),mm=left%60;
 el.innerHTML='<div class="warn" style="background:rgba(255,120,40,.16);border-color:#ff8a3a"><b>🔥 '+esc2(b.label||'عرض خاص')+'</b> — '+(b.coinX>1?'عملات ×'+b.coinX+' ':'')+(b.xpX>1?'خبرة ×'+b.xpX:'')+' · ينتهي بعد '+(hh?hh+'س ':'')+mm+'د</div>';}
setInterval(()=>{try{renderBoost();}catch(e){}},20000);setTimeout(()=>{try{renderBoost();}catch(e){}},1500);
function W(){const m=M();if(!m.pets)m.pets={own:[],act:''};if(!m.farm)m.farm={n:3,pl:[]};if(!m.leg)m.leg=[];if(!m.shards)m.shards=0;if(!m.bossK)m.bossK=0;if(!m.gd)m.gd={d:'',n:0,gv:0};return m;}
XPT.farm=2;XPT.pet=5;
ACH.push({id:'fm20',n:'مزارع نشيط',k:'farm',need:20,c:100,g:1},{id:'pt1',n:'صاحب رفيق',k:'petsN',need:1,c:80,g:0},{id:'lg1',n:'صاحب سلاح أسطوري',k:'legN',need:1,c:300,g:3});
/* ---------- pets ---------- */
const PETS={
 rabbit:{n:'الأرنب الذهبي',p:400,g:0,coin:.03,bite:0,d:'+3% عملات'},
 dog:{n:'كلب الحراسة',p:900,g:0,coin:.05,bite:3,d:'+5% عملات ويعضّ الأعداء'},
 fox:{n:'الثعلب الماكر',p:0,g:15,coin:.10,bite:2,d:'+10% عملات'},
 cub:{n:'شبل الدب',p:0,g:35,coin:.06,bite:7,d:'+6% عملات وعضّة قوية'}
};
const petLv=id=>{const m=S.meta;return (m&&m.pets&&m.pets.lv&&m.pets.lv[id]&&m.pets.lv[id].l)||1;};
const petCoin=()=>{const m=S.meta;const a=m&&m.pets&&m.pets.act;return a&&PETS[a]?PETS[a].coin*(1+.15*(petLv(a)-1)):0;};
function petXp(n){const m=W(),a=m.pets.act;if(!a||!PETS[a])return;if(!m.pets.lv)m.pets.lv={};const o=m.pets.lv[a]||(m.pets.lv[a]={l:1,x:0});if(o.l>=10)return;o.x+=n;
 while(o.l<10&&o.x>=o.l*20){o.x-=o.l*20;o.l++;toast('رفيقك '+PETS[a].n+' ارتقى إلى المستوى '+o.l+'!');sfx('coin');}}
function buyPet(id){const m=W(),p=PETS[id];if(!p||m.pets.own.includes(id))return;
 if(p.g){if((S.gems|0)<p.g){say('تحتاج '+(p.g-(S.gems|0))+' جوهرة');return;}S.gems-=p.g;}else{if(S.coins<p.p){say('تحتاج '+(p.p-S.coins)+' عملة');return;}S.coins-=p.p;}
 m.pets.own.push(id);m.pets.act=id;addXP(10);save();cloud.push();cloud.event('pet',id);sfx('coin');say('رفيق جديد: '+p.n);refreshHud();renderWorld();}
function setPet(id){const m=W();m.pets.act=m.pets.act===id?'':id;save();renderWorld();}
function petUpdate(e,dt){
 const d=Math.hypot(P.x-e.x,P.z-e.z);
 if(d>28){e.x=P.x+1.5;e.z=P.z+1.5;}
 let mv=0;if(d>3.2){const a=Math.atan2(P.x-e.x,P.z-e.z);e.yaw=a;const sp=Math.min(6.5,e.sp*1.4+d*.25);e.x+=Math.sin(a)*sp*dt;e.z+=Math.cos(a)*sp*dt;mv=1;}
 e.y=Cave.on?Cave.y:Math.max(hAt(e.x,e.z),-.45);
 e.ph+=dt*(mv?10:0);if(e.legs)e.legs.forEach((l,i)=>{l.rotation.x=Math.sin(e.ph+(i%3?Math.PI:0))*.6*mv;});
 e.g.position.set(e.x,e.y+(mv?Math.abs(Math.sin(e.ph))*.06:0),e.z);e.g.rotation.y=e.yaw;
 const pd=PETS[e.petId];e.bt=(e.bt||0)-dt;
 if(pd&&pd.bite&&e.bt<=0){const bt=pd.bite*(1+.2*(petLv(e.petId)-1));const h=ents.find(h=>!h.pet&&(h.hostile||h.kind==='zombie')&&Math.hypot(h.x-e.x,h.z-e.z)<4.5);if(h){e.bt=1.4;dmgEnt(h,bt,0,0);}}
}
function ensurePet(){
 const a=S.meta&&S.meta.pets&&S.meta.pets.act;const cur=ents.find(e=>e.pet);
 if(cur&&cur.petId!==a){removeEnt(cur);ents.splice(ents.indexOf(cur),1);}
 if(a&&PETS[a]&&!ents.some(e=>e.pet)&&P&&!P.dead){const e=spawnEnt(a,P.x+1.5,P.z+1.5);e.pet=1;e.petId=a;e.hostile=0;e.bt=0;}
}
/* ---------- bosses ---------- */
function bossCount(){if(creative||!S.name)return;petXp(1);const m=W();m.bossK++;if(m.bossK>=14&&!ents.some(e=>e.boss)&&!Cave.on)spawnBoss();}
function spawnBoss(){
 const a=Math.random()*6.283,x=P.x+Math.cos(a)*22,z=P.z+Math.sin(a)*22;
 const e=spawnEnt(WT.mobs&&WT.mobs[0]==='alien'?'alien':'zombie',x,z);
 e.boss=1;e.hostile=1;e.variant='boss';e.bossN='زعيم '+(WT.n||'العالم');e.hp=e.max=150+25*Math.min(day||1,6);e.sp=Math.max(e.sp,2.6);e.dm=2.4;e.cm=25;e.r=1.5;e.tox=0;
 if(e.ch){e.ch.g.scale.setScalar(2.1);}for(const mm of e.mats)mm.color.lerp(new T.Color(0xaa1a1a),.7);
 toast('⚠ ظهر '+e.bossN+'!');sfx('roar');camShake=.6;
}
function bossDown(e){
 const m=W();petXp(8);m.shards+=3;m.bossK=0;addGems(3,1);addCoins(150);metaEv('boss',1);cloud.event('boss',e.bossN||'boss');
 toast('هزمت '+(e.bossN||'الزعيم')+'! +3 جوهرة +3 شظايا +150 عملة');sfx('coin');save();cloud.push();refreshHud();
}
function bossBar(){
 const b=$('bossB');if(!b)return;const e=ents.find(e=>e.boss);
 if(!e||!playing){b.style.display='none';return;}b.style.display='block';$('bossN').textContent=e.bossN||'زعيم';b.querySelector('i').style.width=Math.max(0,e.hp/e.max*100)+'%';
}
/* ---------- legendary weapons ---------- */
const LEG={
 sw_thunder:{n:'سيف الرعد',dmg:20,pow:2.9,col:0xffe14a,em:0x665500,g:90,sh:9,d:'ضرر 20'},
 sw_dragon:{n:'سيف التنين',dmg:26,pow:3.1,col:0xff3d1a,em:0x881a00,g:160,sh:15,burn:1,d:'ضرر 26 + حرق'},
 sw_void:{n:'سيف العدم',dmg:34,pow:3.4,col:0xa04dff,em:0x440088,g:260,sh:24,d:'ضرر 34'}
};
for(const k in LEG){const w=LEG[k];WEAPS[k]={n:w.n,p:0,dmg:w.dmg,pow:w.pow,col:w.col,em:w.em,burn:w.burn,leg:1};ITEMS[k]={n:w.n,type:'melee',dmg:w.dmg,pow:w.pow,burn:w.burn};ICONS[k]=ICONS.sword;}
function buyLeg(id,how){const m=W(),w=LEG[id];if(!w||(S.stock||[]).includes(id))return;
 if(how==='sh'){if(m.shards<w.sh){say('تحتاج '+(w.sh-m.shards)+' شظية زعيم');return;}m.shards-=w.sh;}
 else{if((S.gems|0)<w.g){say('تحتاج '+(w.g-(S.gems|0))+' جوهرة');return;}S.gems-=w.g;}
 S.stock=(S.stock||[]).concat(id);TOOLS[id]=1;m.leg.push(id);addXP(30);save();cloud.push();cloud.event('legend',id);sfx('coin');say('حصلت على '+w.n+'!');refreshHud();renderWorld();}
/* ---------- farm ---------- */
const CROPS={
 wheat:{n:'قمح',t:180,seed:10,y:25},
 carrot:{n:'جزر',t:420,seed:25,y:70},
 pumpkin:{n:'يقطين',t:900,seed:60,y:170},
 melon:{n:'بطيخ',t:1800,seed:120,y:380,gc:.3}
};
const fmtT=s=>{s=Math.max(0,Math.ceil(s));return Math.floor(s/60)+':'+('0'+(s%60)).slice(-2);};
function plant(i,c){const f=W().farm,cr=CROPS[c];if(!cr||f.pl[i]||i>=f.n)return;if(S.coins<cr.seed){say('تحتاج '+(cr.seed-S.coins)+' عملة للبذور');return;}S.coins-=cr.seed;f.pl[i]={c,t:Date.now()};save();sfx('pop');refreshHud();renderWorld();}
function harvest(i){const f=W().farm,p=f.pl[i];if(!p)return;const cr=CROPS[p.c];if(Date.now()-p.t<cr.t*(f.sp?700:1000))return;f.pl[i]=null;
 const c=Math.round(cr.y*(1+petCoin()));S.coins+=c;let tx='+'+c+' عملة';if(cr.gc&&Math.random()<cr.gc){addGems(1);tx+=' و جوهرة';}
 petXp(1);metaEv('farm',1);save();cloud.push();sfx('coin');say('حصاد '+cr.n+': '+tx);refreshHud();renderWorld();}
function buyPlot(){const f=W().farm;if(f.n>=8)return;const c=300*f.n;if(S.coins<c){say('تحتاج '+(c-S.coins)+' عملة');return;}S.coins-=c;f.n++;save();sfx('coin');refreshHud();renderWorld();}
/* ---------- friend gifts (inside an online room) ---------- */
function sendGift(name,c){
 const g=W().gd,d=dayKey();if(g.d!==d){g.d=d;g.n=0;}
 if(!Net.ok){say('الهدايا تعمل داخل غرفة أونلاين مع أصدقائك');return;}
 if(g.n+c>300){say('الحد اليومي للهدايا 300 عملة');return;}
 if(S.coins<c){say('رصيدك غير كافٍ');return;}
 S.coins-=c;g.n+=c;save();Net.send({t:'gift',to:name,c});metaEv('gift',1);cloud.event('giftsend',name+' '+c);sfx('coin');say('أرسلت '+c+' عملة إلى '+name);refreshHud();renderWorld();}
function gotGift(m){const c=Math.max(0,Math.min(200,m.c|0));if(!c||m.to!==S.name)return;S.coins+=c;save();cloud.push();sfx('coin');toast('هدية من '+m.from+': +'+c+' عملة');refreshHud();}
/* ---------- music + graphics quality ---------- */
const MUS={on:true,t:0,n:0};try{MUS.on=localStorage.getItem('ard_mus')!=='0';}catch(e){}
const GFX=['عالية','متوسطة','منخفضة'];let gfxI=1;try{const v=localStorage.getItem('ard_gfx');gfxI=v===null?1:+v;if(!(gfxI>=0&&gfxI<3))gfxI=1;}catch(e){}
function applyGfx(){
 const q=gfxI;try{renderer.setPixelRatio(q===0?Math.min(window.devicePixelRatio||1,2.2):q===1?Math.min(window.devicePixelRatio||1,1.75):1);
  sun.castShadow=q<2;const s=q===0?2048:1024;if(sun.shadow.mapSize.x!==s){sun.shadow.mapSize.set(s,s);if(sun.shadow.map){sun.shadow.map.dispose();sun.shadow.map=null;}}
  renderer.setSize(parseInt(rootEl.style.width)||innerWidth,parseInt(rootEl.style.height)||innerHeight,false);}catch(e){}
}
function musicTick(dt){
 if(!MUS.on||!playing||P&&P.dead)return;MUS.t-=dt;if(MUS.t>0)return;MUS.t=1.6+Math.random()*1.2;
 const ac=acx();if(!ac||ac.state==='suspended'){try{ac&&ac.resume();}catch(e){}return;}
 const sc=WTK==='nether'?[0,1,5,7,8,12]:WTK==='mars'?[0,3,5,7,10,12]:[0,2,4,7,9,12];const base=WTK==='nether'?110:196;
 const root=sc[MUS.n++%3===0?0:Math.floor(Math.random()*sc.length)];
 const t0=ac.currentTime;for(const [st,vol,dur,ty] of [[root,.022,3.4,'sine'],[root+12,.012,2.2,'triangle'],...(Math.random()<.5?[[sc[Math.floor(Math.random()*sc.length)]+12,.01,1.8,'sine']]:[])]){
  const o=ac.createOscillator(),g=ac.createGain();o.type=ty;o.frequency.value=base*Math.pow(2,st/12);g.gain.setValueAtTime(.0001,t0);g.gain.linearRampToValueAtTime(vol,t0+.5);g.gain.exponentialRampToValueAtTime(.0001,t0+dur);o.connect(g);g.connect(ac.destination);o.start(t0);o.stop(t0+dur+.1);}
}
function worldTick(dt){
 if(!S.name||!P)return;
 try{ctlTick();}catch(e){}
 petT-=dt;if(petT<=0){petT=2;if(playing)ensurePet();}
 if(playing)W().play=(W().play||0)+dt;
 bossBar();musicTick(dt);
}
let petT=2;
/* ---------- the "world" screen ---------- */
let worldTab='pets',worldTi=0;
function renderWorld(){
 const body=$('worldBody');if(!body)return;const m=W();for(const x of document.querySelectorAll('.wT'))x.classList.toggle('on',x.dataset.w===worldTab);
 let h='<div class="coinTag" style="margin-bottom:6px">'+S.coins+' عملة · '+(S.gems|0)+' جوهرة · '+m.shards+' شظية</div>';
 if(worldTab==='pets'){
  h+='<div class="hd"><span>الرفاق</span></div><div class="note">الرفيق يتبعك في اللعب ويعطيك نسبة عملات إضافية، وبعضهم يهاجم الأعداء.</div>';
  for(const id in PETS){const p=PETS[id],own=m.pets.own.includes(id),on=m.pets.act===id;
   h+='<div class="frow"><b>'+p.n+(own?' · Lv'+petLv(id):'')+'</b><small>'+p.d+(own?(m.pets.lv&&m.pets.lv[id]?' · خبرة '+m.pets.lv[id].x+'/'+petLv(id)*20:''):' · '+(p.g?p.g+' جوهرة':p.p+' عملة'))+'</small><button class="'+(own&&!on?'ok':'')+'" data-pet="'+id+'" data-own="'+(own?1:0)+'">'+(on?'نشِط ✓':own?'فعّل':'شراء')+'</button></div>';}
 }else if(worldTab==='farm'){
  const f=m.farm;h+='<div class="hd"><span>مزرعتي</span><span class="coinTag">'+f.n+'/8 قطع</span></div><div class="note">ازرع، انتظر (حتى لو أغلقت اللعبة)، ثم احصد العملات.</div>';
  for(let i=0;i<f.n;i++){const p=f.pl[i];
   if(!p){h+='<div class="frow" style="flex-wrap:wrap"><b>قطعة '+(i+1)+' (فارغة)</b><div class="row2" style="width:100%">'+Object.keys(CROPS).map(c=>'<button data-pl="'+i+'" data-c="'+c+'">'+CROPS[c].n+' · '+CROPS[c].seed+'</button>').join('')+'</div></div>';}
   else{const cr=CROPS[p.c],left=cr.t*(f.sp?.7:1)-(Date.now()-p.t)/1000;h+='<div class="frow"><b>'+cr.n+'</b><small>'+(left>0?'ينمو… '+fmtT(left):'جاهز! +'+cr.y+' عملة')+'</small><button class="'+(left<=0?'ok':'')+'" data-hv="'+i+'" '+(left>0?'disabled':'')+'>'+(left>0?'⏳':'احصد')+'</button></div>';}}
  h+='<div class="frow"><b>مرشّة ذكية</b><small>'+(f.sp?'مفعّلة: نمو أسرع 30%':'نمو أسرع 30% — 15 جوهرة')+'</small><button '+(f.sp?'disabled':'data-sp="1"')+'>'+(f.sp?'✓':'شراء')+'</button></div>';
  if(f.n<8)h+='<div class="frow"><b>قطعة جديدة</b><small>'+300*f.n+' عملة</small><button data-plot="1">شراء</button></div>';
 }else if(worldTab==='leg'){
  h+='<div class="hd"><span>الأسلحة الأسطورية</span></div><div class="note">تُشترى بالجواهر أو بشظايا الزعماء. الزعيم يظهر بعد كل 14 عدواً تقتلهم.</div>';
  for(const id in LEG){const w=LEG[id],own=(S.stock||[]).includes(id);
   h+='<div class="frow" style="flex-wrap:wrap"><b>'+w.n+'</b><small>'+w.d+'</small>'+(own?'<button disabled>تملكه ✓</button>':'<div class="row2" style="width:100%"><button data-lg="'+id+'" data-how="g">'+w.g+' جوهرة</button><button data-lg="'+id+'" data-how="sh">'+w.sh+' شظية</button></div>')+'</div>';}
 }else if(worldTab==='more'){h+=moreHtml();
 }else{
  if(worldTab==='stats'){const c=m.cnt||{},pl=m.play|0,st=m.streak||{};
   const rows=[['وقت اللعب',Math.floor(pl/3600)+' س '+Math.floor(pl%3600/60)+' د'],['زومبي قتلتهم',c.zombie|0],['زعماء هزمتهم',c.boss|0],['حصاد المزرعة',c.farm|0],['الإنجازات',(m.ach||[]).length+'/'+ACH.length],['الرفاق',m.pets.own.length+'/'+Object.keys(PETS).length],['الأسلحة الأسطورية',m.leg.length+'/'+Object.keys(LEG).length],['أفضل سلسلة أيام',st.best|0],['شظايا الزعماء',m.shards],['مستوى الموسم',sLvl()],['VIP',isVip()?'فعّال ('+Math.ceil((m.vip-Date.now())/864e5)+' يوم)':'غير مفعّل']];
   h+='<div class="hd"><span>إحصائياتي</span></div>'+rows.map(r=>'<div class="frow"><b>'+r[0]+'</b><small></small><span class="coinTag">'+r[1]+'</span></div>').join('');}else{
  h+='<div class="hd"><span>هدايا الأصدقاء</span></div>';
  if(!Net.ok)h+='<div class="note">ادخل غرفة أونلاين مع أصدقائك ثم افتح هذه الصفحة لإرسال العملات (حد 300 يومياً).</div>';
  else{   const ns=[...Net.others.values()].map(o=>o.name).filter(Boolean);
   h+=ns.length?ns.map(n=>'<div class="frow"><b>'+esc2(n)+'</b><small>هدية عملات</small><button data-gf="'+esc2(n)+'" data-c="20">20</button><button data-gf="'+esc2(n)+'" data-c="50">50</button></div>').join(''):'<div class="note">لا يوجد لاعبون آخرون الآن.</div>';}}
 }
 body.innerHTML=h;
 for(const b of body.querySelectorAll('[data-pet]'))b.onclick=()=>b.dataset.own==='1'?setPet(b.dataset.pet):buyPet(b.dataset.pet);
 for(const b of body.querySelectorAll('[data-pl]'))b.onclick=()=>plant(+b.dataset.pl,b.dataset.c);
 for(const b of body.querySelectorAll('[data-hv]'))b.onclick=()=>harvest(+b.dataset.hv);
 for(const b of body.querySelectorAll('[data-plot]'))b.onclick=buyPlot;
 for(const b of body.querySelectorAll('[data-sp]'))b.onclick=()=>{if((S.gems|0)<15){say('تحتاج 15 جوهرة');return;}S.gems-=15;W().farm.sp=1;save();cloud.push();sfx('coin');refreshHud();renderWorld();};
 for(const b of body.querySelectorAll('[data-lg]'))b.onclick=()=>buyLeg(b.dataset.lg,b.dataset.how);
 for(const b of body.querySelectorAll('[data-mx]'))b.onclick=()=>moreAct(b.dataset.mx,b.dataset.v);
 for(const b of body.querySelectorAll('[data-gf]'))b.onclick=()=>sendGift(b.dataset.gf,+b.dataset.c);
}
$('toWorld').addEventListener('click',()=>{worldTab='pets';view('vWorld');});
for(const b of document.querySelectorAll('.wT'))b.addEventListener('click',()=>{worldTab=b.dataset.w;renderWorld();});
setInterval(()=>{if($('vWorld').classList.contains('on')&&worldTab==='farm')renderWorld();},5000);
function syncOpts(){$('musicT').textContent='الموسيقى: '+(MUS.on?'تعمل':'متوقفة');$('gfxT').textContent='الرسوميات: '+GFX[gfxI];}
$('musicT').addEventListener('click',()=>{MUS.on=!MUS.on;try{localStorage.setItem('ard_mus',MUS.on?'1':'0');}catch(e){}syncOpts();});
$('gfxT').addEventListener('click',()=>{gfxI=(gfxI+1)%3;try{localStorage.setItem('ard_gfx',gfxI);}catch(e){}applyGfx();syncOpts();});
syncOpts();applyGfx();

