/* Věže – strom: základna → vylepšení → další vylepšení (pole parent); statistiky, vylepšení, střelba
   Data věží jsou v js/data/towers/*.js (BD.data.towers). Role: 'shot' (střela), 'burst' (rázová vlna), 'boost' (zesilovač).
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  var TYPES = BD.data.towers;
  var MAX_LEVEL = 1;   // věž už nemá úrovně: růst = vylepšení na jinou věž (dítě ve stromu); 'level' zůstává jen pro základnu (0) a ostatní (1)
  var MAX_TIER = 2;    // tier 0 = 1×1, tier 1 = 2×2, tier 2 = 4×4 (sloučení – zatím vypnuté, patří do kapitoly Kombinace)
  var MERGE = false;
  var TIER_TAG = ['', ' XL', ' XXL'];

  /* strom věží: parent = věž, ze které se tahle vylepšuje (základna má parent '') */
  function children(id) {
    return Object.keys(TYPES).map(function (k) { return TYPES[k]; }).filter(function (d) { return d.parent === id && d.id !== id; })
      .sort(function (a, b) { return (a.order || 0) - (b.order || 0); });
  }
  /* „kořen“ větve = potomek základny, pod kterým věž leží (kvůli povoleným kategoriím v levelu) */
  function rootKind(id) {
    var seen = {}, d = TYPES[id];
    while (d && d.parent && d.parent !== 'base' && !seen[d.id]) { seen[d.id] = 1; d = TYPES[d.parent]; }
    return d ? d.id : id;
  }
  function stats(t) {
    var D = TYPES[t.type], b = D.base, k = t.tier;
    var hpS = Math.round((D.hp || 100) * Math.pow(3, k));            // životy věže (útočí na ně nepřátelé s atkDmg)
    if (D.role === 'none') return { dmg: 0, cd: 1, range: 0, splash: 0, slow: 0, speed: 10, boost: 0, hp: hpS };
    var s = { dmg: 0, cd: b.cd || 1, range: 0, splash: 0, slow: 0, speed: b.speed || 10, boost: 0, hp: hpS };
    if (D.role === 'boost') { s.boost = 1 + (b.boost - 1) * (1 + 0.5 * k); return s; }
    s.dmg = b.dmg * Math.pow(14, k);
    s.cd = b.cd * Math.pow(0.85, k);
    var SUB = BD.SUB;
    s.range = (b.range * (1 + 0.3 * k) + (t.size / SUB - 1) * 0.5) * SUB;   // v buňkách
    s.speed *= SUB;
    s.splash = (b.splash || 0) * SUB; s.slow = Math.min(0.9, (b.slow || 0));      // splash v „věžích“, slow 0–0.9
    return s;
  }
  /* vzhled věže (Studio): vlastní sprite věže, jinak null (kreslí se původní bubliny) */
  function look(t) { var D = TYPES[t.type]; return (D && D.sprite) || null; }
  /* kategorie = vylepšení Základny (první patro stromu); používá je editor levelů pro „povolené věže“ */
  function categories() { return children('base'); }
  /* cena vylepšení na věž choice (musí být dítě aktuální věže); bez volby = nejlevnější dítě; žádné dítě = null */
  function upgradeCost(t, choice) {
    var ch = children(t.type); if (!ch.length) return null;
    if (choice) { var d = TYPES[choice]; return d && d.parent === t.type ? d.cost : null; }
    return Math.min.apply(null, ch.map(function (d) { return d.cost; }));
  }
  function tierName(type, tier) { return TYPES[type].name + TIER_TAG[tier || 0]; }
  function name(t) { return tierName(t.type, t.tier); }

  /* smí věž tohoto typu zasáhnout nepřítele? (duchové: jen věže s hitsGhost; „proti duchům“ střílí jen na duchy) */
  function canHit(D, e) {
    var ghost = !!BD.systems.enemies.TYPES[e.type].ghost;
    return ghost ? !!D.hitsGhost : !D.onlyGhost;
  }

  /* zesilovače: každá věž dostane ×(1 + součet bonusů dotýkajících se zesilovačů) */
  function updateBoosts(game) {
    var i, t;
    for (i = 0; i < game.towers.length; i++) game.towers[i].boost = 1;
    for (i = 0; i < game.towers.length; i++) {
      var b = game.towers[i];
      if (TYPES[b.type].role !== 'boost') continue;
      var bonus = b.s.boost - 1, seen = {};
      for (var k = 0; k < b.size; k++) {
        var nb = [[b.x - 1, b.y + k], [b.x + b.size, b.y + k], [b.x + k, b.y - 1], [b.x + k, b.y + b.size]];
        for (var n = 0; n < 4; n++) {
          t = game.inb(nb[n][0], nb[n][1]) ? game.towerAt(nb[n][0], nb[n][1]) : null;
          if (t && t !== b && !seen[t.id] && TYPES[t.type].role !== 'boost') { seen[t.id] = 1; t.boost += bonus; }
        }
      }
    }
  }

  function update(game, dt) {
    for (var i = 0; i < game.towers.length; i++) {
      var t = game.towers[i], D = TYPES[t.type];
      if (D.role === 'boost' || D.role === 'none') continue;
      t.cool -= dt;
      if (t.cool > 0) continue;
      var s = t.s, dmg = s.dmg * (t.boost || 1);
      var cx = t.x + t.size / 2, cy = t.y + t.size / 2;
      var r2 = s.range * s.range;
      var best = null, bv = 1e9, j, e, any = false;
      for (j = 0; j < game.enemies.length; j++) {
        e = game.enemies[j];
        if (!e.alive || !canHit(D, e)) continue;
        var ex = e.x - cx, ey = e.y - cy;
        if (ex * ex + ey * ey > r2) continue;
        any = true;
        var v = (BD.systems.enemies.TYPES[e.type].ghost ? game.distG : game.dist)[game.idx(e.tx, e.ty)] + Math.hypot(e.tx + 0.5 - e.x, e.ty + 0.5 - e.y);
        if (D.target === 'strong') v = -e.hp; else if (D.target === 'weak') v = e.hp; else if (D.target === 'close') v = Math.sqrt(ex * ex + ey * ey);   // výchozí „first“ = nejblíž cíli
        if (v < bv) { bv = v; best = e; }
      }
      if (!any) { t.cool = 0; continue; }
      t.cool = s.cd;
      if (D.role === 'burst') {                       /* rázová vlna: zasáhne všechny v dosahu */
        game.fx.push({ kind: 'ring', x: cx, y: cy, t: 0, life: 0.35, r: s.range, color: D.color });
        for (j = 0; j < game.enemies.length; j++) {
          e = game.enemies[j];
          if (!e.alive || !canHit(D, e)) continue;
          if (Math.hypot(e.x - cx, e.y - cy) > s.range) continue;
          e.hp -= BD.systems.enemies.hurt(e, dmg);
          if (e.hp <= 0) game.kill(e);
        }
        continue;
      }
      t.angle = Math.atan2(best.y - cy, best.x - cx);
      var A = BD.data.ammo, aid = A && A[D.ammo] ? D.ammo : 'default', am = A && A[aid];       // střelivo věže (bez něj výchozí střela)
      var mul = am ? am.dmgMul : 1, smul = am ? am.speedMul : 1;
      game.shots.push({ x: cx, y: cy, target: best, lx: best.x, ly: best.y, dmg: dmg * (mul || 1), splash: s.splash,
        slow: s.slow, speed: s.speed * (smul || 1), color: D.color, big: t.tier, am: aid, flight: am ? am.flight : 'homing', ang: t.angle, age: 0,
        d0: Math.hypot(best.x - cx, best.y - cy), trail: [] });
      if (am && am.muzzle && am.muzzle.sprite) {                                                // výstřel u hlavně
        var md = am.muzzle.dist || 0;
        game.fx.push({ kind: 'ammo', ph: 'muzzle', am: aid, x: cx + Math.cos(t.angle) * md, y: cy + Math.sin(t.angle) * md, aim: t.angle, t: 0, life: Math.max(0.05, am.muzzle.dur || 0.2) });
      }
    }
  }

  BD.systems.towers = { look: look, TYPES: TYPES, MAX_LEVEL: MAX_LEVEL, MAX_TIER: MAX_TIER, MERGE: MERGE, stats: stats, upgradeCost: upgradeCost, categories: categories,
    children: children, rootKind: rootKind, name: name, tierName: tierName, canHit: canHit,
    updateBoosts: updateBoosts, update: update };
})(window.BD);
