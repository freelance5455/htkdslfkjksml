'use strict';
/* ================= building pieces ================= */
let pieceId=1;
function makePieceMesh(type,ry){
 const g=new T.Group(),M=c=>new T.MeshLambertMaterial({color:c,flatShading:true});
 if(type==='wall'){for(let i=0;i<4;i++){const b=new T.Mesh(new T.BoxGeometry(2.4,.62,.3),M(i%2?0x9a6b3c:0x8a5c31));b.position.y=.35+i*.66;g.add(b);}}
 else if(type==='floor'){for(let i=0;i<4;i++){const b=new T.Mesh(new T.BoxGeometry(.46,.2,2),M(i%2?0xa87445:0x966636));b.position.set(-.75+i*.5,0,0);g.add(b);}}
 else{
  for(let i=0;i<6;i++){const a=i/6*6.283;const s=new T.Mesh(GM.ico,M(0x7d8189));s.scale.set(.26,.2,.26);s.position.set(Math.cos(a)*.6,.1,Math.sin(a)*.6);g.add(s);}
  const l1=new T.Mesh(GM.cyl,M(0x6b4423));l1.scale.set(.08,.8,.08);l1.rotation.z=1.2;l1.position.y=.15;g.add(l1);
  const l2=l1.clone();l2.rotation.y=1.6;g.add(l2);
  const f=new T.Mesh(GM.cone,new T.MeshBasicMaterial({color:0xffa02e,transparent:true,opacity:.92}));f.scale.set(.32,.85,.32);f.position.y=.55;f.name='flame';g.add(f);
  const f2=new T.Mesh(GM.cone,new T.MeshBasicMaterial({color:0xfff09a}));f2.scale.set(.16,.5,.16);f2.position.y=.45;f2.name='flame2';g.add(f2);
 }
 return g;
}
function addPiece(d,silent){if(d.b){setBlock(d.x,d.y,d.z,d.k,d.o,!!d.open,!!d.top);return;}
 const m=makePieceMesh(d.type,d.ry);m.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true;}});m.position.set(d.x,d.y,d.z);m.rotation.y=d.ry||0;scene.add(m);
 const q={id:d.id,type:d.type,x:d.x,y:d.y,z:d.z,ry:d.ry||0,mesh:m};
 if(d.type==='wall'){const h=Math.abs(Math.sin(q.ry))>.7;q.hx=h?.2:1.2;q.hz=h?1.2:.2;}
 built.push(q);return q;
}
function removePiece(id){if(typeof id==='string'&&id[0]==='b'){const q=id.slice(1).split(',').map(Number);delBlock(q[0],q[1],q[2]);return;}const i=built.findIndex(b=>b.id===id);if(i>=0){scene.remove(built[i].mesh);built.splice(i,1);}}

