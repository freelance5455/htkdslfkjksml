/* Vlny nepřátel – definice vln a vypouštění z fronty
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';

  function def(n) {
    var q = [];
    if (W.testEnemy && BD.systems.enemies.TYPES[W.testEnemy]) { for (var k = 0; k < 6 + n; k++) q.push({ type: W.testEnemy, gap: 0.8 }); return q; }       // zkouška ze Studia
    function add(type, count, gap) { if (!inWaves(type)) return; for (var i = 0; i < count; i++) q.push({ type: type, gap: gap }); }
    var base = 5 + Math.floor(n * 1.3);
    if (n % 10 === 0) { add('boss', 1, 1.5); add('bub', Math.floor(base / 2), 0.5); }
    else if (n % 5 === 0) { add('tank', 2 + Math.floor(n / 5), 1.0); add('bub', Math.floor(base / 2), 0.5); }
    else if (n % 4 === 0) { add('swarm', base * 2, 0.22); }
    else if (n % 3 === 0) { add('fast', Math.floor(base * 0.8), 0.4); add('bub', 3, 0.6); }
    else add('bub', base, 0.6);
    if (n >= 4 && n % 3 === 1) add('ghost', 2 + Math.floor(n / 4), 0.8);   // duchy: zasáhne je jen Základní a Proti duchům
    /* nepřátelé s vlastními pravidly ze Studia (waveMode 'rules'): od vlny, do vlny, každá N-tá, počet roste, od kolikátého levelu */
    var ET = BD.systems.enemies.TYPES;
    Object.keys(ET).forEach(function (id) {
      var B = ET[id]; if (B.waveMode !== 'rules') return;
      var from = B.waveFrom || 1; if (n < from || (B.waveTo && n > B.waveTo) || (n - from) % (B.waveEvery || 1)) return;
      if (B.levelFrom && W.ctx.levelNo && W.ctx.levelNo < B.levelFrom) return;
      var cnt = Math.max(1, Math.round((B.waveCount || 3) + (B.wavePer || 0) * (n - from)));
      for (var i = 0; i < cnt; i++) q.push({ type: id, gap: B.waveGap || 0.6 });
    });
    return q;
  }
  /* je nepřítel zařazený do pevného předpisu vln? (vestavění ano, pokud ho Studio nevyřadilo nebo nepřepsalo vlastními pravidly) */
  function inWaves(type) { var B = BD.systems.enemies.TYPES[type]; return !!B && (!B.waveMode || B.waveMode === 'builtin'); }

  /* souhrn vlny pro pás vln: počet, součet zdraví, složení a barva podle převládajících bublin; boss = vlna s šéfem */
  function info(n, hpMul) {
    var ET = BD.systems.enemies.TYPES, by = {}, order = [], total = 0, hp = 0, items = def(n);
    items.forEach(function (q) {
      var B = ET[q.type], h = B.hp * BD.systems.enemies.hpScale(n) * (hpMul || 1);
      if (!by[q.type]) { by[q.type] = { type: q.type, name: B.name, color: B.color, count: 0, hp: 0 }; order.push(q.type); }
      by[q.type].count++; by[q.type].hp += h; total++; hp += h;
    });
    var types = order.map(function (k) { return by[k]; }).sort(function (a, b) { return b.hp - a.hp; });
    var boss = !!by.boss;
    return { wave: n, count: total, hp: Math.round(hp), types: types, boss: boss, main: boss ? by.boss.color : (types[0] ? types[0].color : '#6b7280') };
  }

  /* vypustí další vlnu: vlna dostane vlastní proud, takže se víc vln může překrývat */
  function start(game, delay) { return game.launchWave(delay || 0); }

  function update(game, dt) {
    var ss = game.streams;
    if (!ss.length) return;
    for (var i = 0; i < ss.length; i++) {
      var s = ss[i];
      s.t -= dt;
      while (s.queue.length && s.t <= 0) {
        s.started = true;
        var q = s.queue.shift();
        BD.systems.enemies.spawn(game, q.type, s.wave);
        s.t += q.gap;
      }
    }
    game.streams = ss.filter(function (s) { return s.queue.length; });
  }

  var W = BD.systems.waves = { testEnemy: null, ctx: { levelNo: 0 }, def: def, info: info, start: start, update: update };
})(window.BD);
