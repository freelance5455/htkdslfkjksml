'use strict';
/* ================= gems / wheel / chests / weekly track ================= */
const addGems=(n,why)=>{n=Math.floor(n);if(n<=0)return;S.gems=(S.gems|0)+n;save();try{refreshHud();}catch(e){}if(why)toast('+'+n+' جوهرة');};
const DAYN=['الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت','الأحد'];
const WK7=[40,60,80,100,120,160],WK7_GEMS=6;
const dow=()=>(new Date().getDay()+6)%7;
function wk7State(){
 const k=weekKey();if(!S.wk7||S.wk7.k!==k){S.wk7={k,cl:[]};save();}
 let dv=[];try{const r=localStorage.getItem('ard_wk7')||'';const a=r.split('|');if(a[0]===k)dv=(a[1]||'').split(',').filter(x=>x!=='').map(Number);}catch(e){}
 return S.wk7.cl.concat(dv.filter(x=>!S.wk7.cl.includes(x)));
}
function claimWk7(){
 const i=dow(),cl=wk7State();if(cl.includes(i)){say('استلمت جائزة اليوم. عد غداً!');return;}
 if(i<6){S.coins+=WK7[i];say('+'+WK7[i]+' عملة');}else{addGems(WK7_GEMS);say('+'+WK7_GEMS+' جواهر!');}
 S.wk7.cl.push(i);try{localStorage.setItem('ard_wk7',S.wk7.k+'|'+S.wk7.cl.join(','));}catch(e){}
 save();cloud.push();sfx('coin');cloud.event('daily',i<6?'c'+WK7[i]:'g'+WK7_GEMS);metaEv('daily',1);refreshHud();renderHome();$('homeCoins').textContent=S.coins;
}
function renderWk7(){
 const box=$('wk7');if(!box)return;box.innerHTML='';const cl=wk7State(),t=dow();$('wk7Info').textContent=cl.length+'/7';
 for(let i=0;i<7;i++){const b=document.createElement('button');const done=cl.includes(i),today=i===t,gem=i===6;
  b.className='pack'+(today&&!done?' on':'');b.style.cssText='padding:7px 2px;font-size:11px;'+(done?'opacity:.55;':(i<t?'opacity:.4;':''));
  b.innerHTML='<span>'+DAYN[i]+'</span><b style="font-size:15px;color:'+(gem?'#7fe9ff':'var(--gold)')+'">'+(gem?WK7_GEMS+'ج':WK7[i])+'</b><span>'+(done?'✓':today?'اليوم':'')+'</span>';
  b.addEventListener('click',()=>{if(today)claimWk7();else say(i<t?'فاتك هذا اليوم':'لم يحن موعده بعد');});box.appendChild(b);}
}
/* wheel: price doubles each spin, resets daily */
const WHEEL=[{m:.2},{m:.5},{m:.2},{t:'items'},{m:1},{m:.5},{t:'gem'},{m:.3},{m:1.8},{m:.2},{m:.5},{m:3}];
const wheelW=()=>{const d=dayKey();if(!S.wheel||S.wheel.d!==d){S.wheel={d,n:0};}return S.wheel;};
const wheelPrice=()=>50*Math.pow(2,Math.min(wheelW().n,12));
let wheelRot=0,spinning=false;
function renderWheel(){
 const el=$('wheel');if(!el)return;const pr=wheelPrice();
 if(!el.dataset.built){
  const cols=['#2f7dff','#6b3fd0'];let g=[];WHEEL.forEach((w,i)=>g.push(cols[i%2]+' '+i*30+'deg '+(i+1)*30+'deg'));
  g[6]='#18b7d9 180deg 210deg';el.style.background='conic-gradient('+g.join(',')+')';el.dataset.built=1;
 }
 el.innerHTML='';WHEEL.forEach((w,i)=>{const d=document.createElement('div');d.style.cssText='position:absolute;inset:0;display:flex;justify-content:center;transform:rotate('+(i*30+15)+'deg)';
  const sp=document.createElement('span');sp.style.cssText='margin-top:7%;font-size:11px;font-weight:800;color:#fff;text-shadow:0 1px 2px #000';sp.textContent=w.t==='gem'?'جوهرة':w.t==='items'?'موارد':String(Math.round(pr*w.m));d.appendChild(sp);el.appendChild(d);});
 $('whCoins').textContent='العملات: '+S.coins;$('whNote').textContent='سعر اللفة الآن '+pr+' عملة، ويتضاعف مع كل لفة (يعود غداً إلى 50).';
 $('spinBtn').textContent='لفّ بـ '+pr;$('spinBtn').disabled=spinning||wheelW().n>=12;
}
function spinWheel(){
 if(spinning)return;const w=wheelW(),pr=wheelPrice();if(w.n>=12){$('whMsg').textContent='انتهت لفّات اليوم. عد غداً!';return;}
 if(S.coins<pr){$('whMsg').textContent='تحتاج '+(pr-S.coins)+' عملة إضافية.';return;}
 S.coins-=pr;w.n++;const i=Math.floor(Math.random()*WHEEL.length),sl=WHEEL[i];let txt;
 if(sl.t==='gem'){addGems(1);txt='جوهرة واحدة!';}
 else if(sl.t==='items'){const pool=[['iron',3],['coal',6],['wood',15],['planks',12],['gold',1],['brick',8]],it=pool[Math.floor(Math.random()*pool.length)];giveInv(it[0],it[1]);txt='+'+it[1]+' '+(NAMES[it[0]]||it[0]);}
 else{const c=Math.round(pr*sl.m);S.coins+=c;txt='+'+c+' عملة';}
 save();cloud.push();cloud.event('spin',pr+':'+txt);metaEv('spin',1);
 spinning=true;$('spinBtn').disabled=true;sfx('coin');
 const target=((360-(i*30+15))-(wheelRot%360)+360)%360;wheelRot+=360*5+target;$('wheel').style.transform='rotate('+wheelRot+'deg)';
 $('whMsg').textContent='…';
 setTimeout(()=>{spinning=false;$('whMsg').textContent='ربحت: '+txt;beep(880,.25,'triangle',.07);try{refreshHud();}catch(e){}renderWheel();renderHome();},3500);
}
const CHESTS=[{id:'bronze',n:'صندوق برونزي',g:5,c:[150,400],it:2,gc:0,gr:[0,0]},{id:'silver',n:'صندوق فضي',g:15,c:[500,1200],it:3,gc:.15,gr:[1,1]},{id:'gold',n:'صندوق ذهبي',g:40,c:[1500,3500],it:4,gc:.3,gr:[2,5]}];
function renderChests(){
 const box=$('chestList');if(!box)return;box.innerHTML='';$('gemTag').textContent='الجواهر: '+(S.gems|0);
 for(const c of CHESTS){const b=document.createElement('button');b.className='offer';b.innerHTML='<span><b>'+c.n+'</b><br><small>'+c.c[0]+'–'+c.c[1]+' عملة + موارد'+(c.gc?' + فرصة جواهر':'')+'</small></span><b>'+c.g+' جوهرة</b>';
  b.addEventListener('click',()=>openChest(c));box.appendChild(b);}
}
function openChest(c){
 if((S.gems|0)<c.g){$('chMsg').textContent='تحتاج '+(c.g-(S.gems|0))+' جوهرة إضافية.';return;}
 S.gems-=c.g;const coins=c.c[0]+Math.floor(Math.random()*(c.c[1]-c.c[0]+1));S.coins+=coins;
 const pool=['wood','iron','coal','planks','brick','glass','wool','gold','arrow'];let txt=coins+' عملة';
 for(let k=0;k<c.it;k++){const id=pool[Math.floor(Math.random()*pool.length)],n=(id==='gold'?1:2)+Math.floor(Math.random()*4);giveInv(id,n);txt+=' + '+n+' '+(NAMES[id]||id);}
 if(c.id==='gold'){giveInv('diamond',2);txt+=' + 2 '+(NAMES.diamond||'ألماس');}
 let gm=0;if(Math.random()<c.gc){gm=c.gr[0]+Math.floor(Math.random()*(c.gr[1]-c.gr[0]+1));S.gems+=gm;txt+=' + '+gm+' جوهرة';}
 save();cloud.push();cloud.event('gchest',c.id);sfx('coin');
 $('bonusTxt').textContent=c.n+':\n'+txt;$('bonus').classList.add('on');beep(880,.3,'triangle',.07);try{refreshHud();}catch(e){}renderChests();$('chMsg').textContent='';
}

