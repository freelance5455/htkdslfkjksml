'use strict';
/* ================= actions ================= */
let toastT=0;function toast(t){const e=$('toast');e.textContent=t;e.classList.add('on');clearTimeout(toastT);toastT=setTimeout(()=>e.classList.remove('on'),1700);}
function fwd(){return [Math.sin(camYaw),Math.cos(camYaw)];}
function giveInv(k,n){INV[k]=(INV[k]||0)+n;}
function dmgEnt(e,d,dx,dz){
 e.hp-=d;e.flash=.18;e.x+=dx*.6;e.z+=dz*.6;e.flee=3;(e.kind==='zombie'||e.hostile)?sfx('groan'):sfx('pop');
 particles(e.x,e.y+1,e.z,e.kind==='zombie'?0x66cc44:0xcc3344,6);
 if(e.hp<=0){
  if(e.kind==='trex')cloud.event('boss','trex');
  if(e.kind==='zombie'||e.hostile){const c=Math.max(1,Math.round((1+Math.floor(Math.random()*3))*(e.cm||1)));let cc=c;if(!creative){cc=addCoins(c);if(e.kind==='zombie')questEv('zombie',1);if(Math.random()<.3)giveInv('bone',1);if(e.meat)giveInv('meat',e.meat);}toast(creative?'تم القضاء على زومبي':'+'+cc+' عملة');if(!creative&&Math.random()<.35)giveInv('iron',1);if(!creative&&Math.random()<.3)giveInv('arrow',3);}
  else if(e.kind==='villager'){toast('يا للأسف...');}
  else{const m=e.meat;if(!creative){if(e.type==='cow'||e.type==='deer')giveInv('leather',1);if(e.type==='sheep')giveInv('wool',2);if(e.type==='bear')giveInv('leather',2);if(e.drop)giveInv(e.drop,1);giveInv('meat',m);addCoins(e.coin);questEv('hunt',1);}toast(creative?'تم':'+'+m+' لحم  +'+e.coin);}
  particles(e.x,e.y+1,e.z,0xffe27a,10);removeEnt(e);refreshHud();
 }
}
function meleeHit(it,id){
 const [fx,fz]=fwd();let best=null,bd=3.2;
 for(const e of ents){const dx=e.x-P.x,dz=e.z-P.z,d=Math.hypot(dx,dz);if(d<bd&&(dx*fx+dz*fz)/Math.max(d,.01)>.3){bd=d;best=e;}}
 if(best){dmgEnt(best,it.dmg*dmgMul(),fx,fz);if(it.burn)best.burn=3.5;return;}
 if(hitBlockUnderAim(it))return;
 let bp=null,pd=3.6,pch=null;
 nearProps(P.x,P.z,(p,ch)=>{const dx=p.x-P.x,dz=p.z-P.z,d=Math.hypot(dx,dz);if(d<pd&&(dx*fx+dz*fz)/Math.max(d,.01)>.15){pd=d;bp=p;pch=ch;}});
 if(bp){
  bp.hp-=it.pow||1;(bp.type==='tree'||bp.type==='deadtree'||bp.type==='bush'||bp.type==='cactus')?sfx('wood'):sfx('stone');particles(bp.x,bp.y+1,bp.z,bp.type==='tree'?0x8a5a2b:0xaaaaaa,5);
  if(bp.hp<=0){
   bp.dead=true;deadSet.add(pch.cx+','+pch.cz+','+bp.id);rebuildProps(pch);if(bp.type==='tree'||bp.type==='deadtree')sfx('crack');else sfx('break');
   if(bp.type==='crystal'){const c=2+Math.floor(Math.random()*3);if(!creative){addCoins(c);questEv('crystal',1);if(Math.random()<.4)giveInv('diamond',1);}toast('+'+c+' عملة');}
  else if(bp.type==='tree'||bp.type==='deadtree'){const n=3+Math.floor(Math.random()*2);if(!creative){giveInv('wood',n);questEv('wood',n);}toast('+'+n+' خشب');}
   else if(bp.type==='cactus'||bp.type==='deadbush'){if(!creative)giveInv('berry',1);toast('+1 توت');}
   else if(bp.type==='bush'){if(!creative)giveInv('berry',2);toast('+2 توت');}
   else{const n=2+Math.floor(Math.random()*2);if(!creative)giveInv('stone',n);if(!creative){if(Math.random()<.22)giveInv('coal',1);if(Math.random()<.08)giveInv('gold',1);if(Math.random()<.04)giveInv('diamond',1);}let t='+'+n+' حجر';if(bp.type==='ore'){const k=2;if(!creative)giveInv('iron',k);t+=' و+'+k+' حديد';}else if(Math.random()<.25){if(!creative)giveInv('iron',1);t+=' و+1 حديد';}toast(t);}
   refreshHud();
  }
  return;
 }
 let bb=null,bdist=3.6;
 for(const b of built){const dx=b.x-P.x,dz=b.z-P.z,d=Math.hypot(dx,dz);if(d<bdist&&(dx*fx+dz*fz)/Math.max(d,.01)>.2){bdist=d;bb=b;}}
 if(bb){if(!creative)giveInv('wood',1);removePiece(bb.id);Net.send({t:'unbuild',id:bb.id});beep(200,.1,'square');refreshHud();}
}
function aimDir(){
 const cp=Math.cos(camPitch),sp=Math.sin(camPitch);
 const cf=new T.Vector3(Math.sin(camYaw)*cp*-1*-1,-sp,Math.cos(camYaw)*cp);// camera look direction
 const target=new T.Vector3(P.x,P.y+1.6,P.z).add(cf.clone().multiplyScalar(30));
 const o=new T.Vector3(P.x+Math.sin(camYaw)*.6,P.y+1.5,P.z+Math.cos(camYaw)*.6);
 return {o,d:target.sub(o).normalize()};
}
const bombs=[],puddles=[],volcM=new Map(),volcT=new Map();
function volcReset(){for(const b of bombs)scene.remove(b.m);bombs.length=0;for(const p of puddles)scene.remove(p.m);puddles.length=0;for(const m of volcM.values())scene.remove(m);volcM.clear();volcT.clear();}
function updateVolcanoes(dt){
 if(!WT.volc||Cave.on)return;
 const i0=Math.floor(P.x/170),j0=Math.floor(P.z/170);
 for(let i=i0-1;i<=i0+1;i++)for(let j=j0-1;j<=j0+1;j++){
  const s=volcSite(i,j);if(!s)continue;const k=i+','+j,dd=Math.hypot(P.x-s.x,P.z-s.z);
  if(dd>150){const m=volcM.get(k);if(m){scene.remove(m);volcM.delete(k);}continue;}
  const cy=heightAt(s.x,s.z);
  if(!volcM.has(k)){const m=new T.Mesh(new T.CircleGeometry(s.R*.17,16),lavaMat);m.rotation.x=-Math.PI/2;m.position.set(s.x,cy+.15,s.z);scene.add(m);volcM.set(k,m);volcT.set(k,{n:3+Math.random()*6,smoke:0});}
  const st=volcT.get(k);st.smoke-=dt;if(st.smoke<=0&&dd<110){st.smoke=.25;particles(s.x+(Math.random()-.5)*4,cy+1,s.z+(Math.random()-.5)*4,Math.random()<.5?0x555555:0x888888,2);}
  st.n-=dt;
  if(st.n<=0&&dd<130){
   st.n=7+Math.random()*9;sfx('rumble');if(dd<70)camShake=Math.max(camShake,.5*(1-dd/70)+.15);
   const cnt=5+Math.floor(Math.random()*5);
   for(let q=0;q<cnt&&bombs.length<26;q++){const a=Math.random()*6.283,hs=5+Math.random()*13,m=new T.Mesh(GM.ico,new T.MeshBasicMaterial({color:Math.random()<.5?0xff6a1a:0xffb03a}));m.scale.setScalar(.45+Math.random()*.6);m.position.set(s.x,cy+1.5,s.z);scene.add(m);
    bombs.push({m,x:s.x,y:cy+1.5,z:s.z,vx:Math.cos(a)*hs,vy:20+Math.random()*12,vz:Math.sin(a)*hs,tr:0});}
   particles(s.x,cy+2,s.z,0xff7a1a,14);particles(s.x,cy+3,s.z,0x444444,10);
  }
 }
 for(let i=bombs.length-1;i>=0;i--){const b=bombs[i];b.vy-=15*dt;b.x+=b.vx*dt;b.y+=b.vy*dt;b.z+=b.vz*dt;b.m.position.set(b.x,b.y,b.z);b.m.rotation.x+=dt*4;b.tr-=dt;if(b.tr<=0){b.tr=.07;particles(b.x,b.y,b.z,0x555555,1);}
  const g=hAt(b.x,b.z);
  if(b.y<=g||b.y<-.3){
   scene.remove(b.m);bombs.splice(i,1);particles(b.x,Math.max(g,b.y),b.z,0xff7a1a,10);particles(b.x,Math.max(g,b.y),b.z,0xffe27a,5);sfx('boom');
   const dp=Math.hypot(P.x-b.x,P.z-b.z);
   if(dp<3.6&&Math.abs(P.y-g)<3){hurt(16);const l=Math.max(.1,dp);P.x+=(P.x-b.x)/l*1.6;P.z+=(P.z-b.z)/l*1.6;P.vy=Math.max(P.vy,6);camShake=.6;}
   else if(dp<22)camShake=Math.max(camShake,.25*(1-dp/22));
   for(const e of ents.slice())if(Math.hypot(e.x-b.x,e.z-b.z)<3.6)dmgEnt(e,12,(e.x-b.x)*.4,(e.z-b.z)*.4);
   if(puddles.length<22){const m=new T.Mesh(new T.CircleGeometry(1.5,10),lavaMat);m.rotation.x=-Math.PI/2;m.position.set(b.x,Math.max(g,0)+.08,b.z);scene.add(m);puddles.push({m,x:b.x,z:b.z,life:7});}
  }}
 for(let i=puddles.length-1;i>=0;i--){const p=puddles[i];p.life-=dt;if(Math.hypot(P.x-p.x,P.z-p.z)<1.5&&P.y<hAt(p.x,p.z)+.7){hurt(dt*24,true);if(Math.random()<dt*4)sfx('sizzle');}
  if(p.life<=0){scene.remove(p.m);puddles.splice(i,1);}}
}
const shells=[];
function ejectShell(o,d){
 const m=new T.Mesh(GM.cyl,new T.MeshLambertMaterial({color:0xe0b43a,emissive:0x2a1c00}));m.scale.set(.025,.07,.025);
 const side=new T.Vector3(d.z,0,-d.x).normalize();m.position.copy(o).addScaledVector(side,.25);m.position.y-=.1;scene.add(m);
 shells.push({m,v:side.multiplyScalar(2.2+Math.random()).add(new T.Vector3((Math.random()-.5)*.8,2.4+Math.random()*1.2,(Math.random()-.5)*.8)),life:2.2,rx:(Math.random()-.5)*20,rz:(Math.random()-.5)*20,n:0});
}
function updateShells(dt){
 for(let i=shells.length-1;i>=0;i--){const s=shells[i];s.life-=dt;s.v.y-=22*dt;s.m.position.addScaledVector(s.v,dt);s.m.rotation.x+=s.rx*dt;s.m.rotation.z+=s.rz*dt;
  const g=Math.max(hAt(s.m.position.x,s.m.position.z),topBlockUnder(s.m.position.x,s.m.position.z,s.m.position.y+.5))+.03;
  if(s.m.position.y<g){s.m.position.y=g;if(s.n<2&&Math.abs(s.v.y)>1){s.v.y*=-.35;s.v.x*=.6;s.v.z*=.6;s.n++;beep(2400,.03,'triangle',.02);}else{s.v.set(0,0,0);s.rx=s.rz=0;}}
  if(s.life<=0){scene.remove(s.m);s.m.geometry!==GM.cyl&&s.m.geometry.dispose();shells.splice(i,1);}}
}
function shoot(it,id){
 const {o,d}=aimDir();const gun=id==='gun';
 const m=gun?new T.Mesh(GM.sph,new T.MeshBasicMaterial({color:0xffe27a})):new T.Mesh(GM.cyl,new T.MeshLambertMaterial({color:0xd9c79a}));
 if(gun)m.scale.setScalar(.09);else{m.scale.set(.03,.9,.03);m.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),d);}
 m.position.copy(o);scene.add(m);
 projs.push({m,p:o.clone(),v:d.clone().multiplyScalar(gun?75:40),g:gun?0:9,dmg:(gun?8:5)*dmgMul(),life:2.2,gun,ex:!!it.explosive});
 sfx(gun?'shot':'bow');
 if(gun)ejectShell(o,d);
}
/*BLOCKS*/
