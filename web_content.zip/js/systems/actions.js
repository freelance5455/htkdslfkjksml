'use strict';
/* ================= actions ================= */
let toastT=0;function toast(t){const e=$('toast');e.textContent=t;e.classList.add('on');clearTimeout(toastT);toastT=setTimeout(()=>e.classList.remove('on'),1700);}
function fwd(){return [Math.sin(camYaw),Math.cos(camYaw)];}
function giveInv(k,n){INV[k]=(INV[k]||0)+n;}
function dmgEnt(e,d,dx,dz){
 e.hp-=d;e.flash=.18;e.x+=dx*.6;e.z+=dz*.6;e.flee=3;beep(e.kind==='zombie'?140:220,.08,'sawtooth');
 particles(e.x,e.y+1,e.z,e.kind==='zombie'?0x66cc44:0xcc3344,6);
 if(e.hp<=0){
  if(e.kind==='zombie'||e.kind==='skeleton'){const c=Math.max(1,Math.round((1+Math.floor(Math.random()*3))*(e.cm||1)));let cc=c;if(!creative){cc=addCoins(c);if(e.kind==='zombie')questEv('zombie',1);if(Math.random()<.3)giveInv('bone',1);}toast(creative?'تم القضاء على زومبي':'+'+cc+' عملة');if(!creative&&Math.random()<.35)giveInv('iron',1);if(!creative&&Math.random()<.3)giveInv('arrow',3);}
  else if(e.kind==='villager'){toast('يا للأسف...');}
  else{const m=e.meat;if(!creative){if(e.type==='cow'||e.type==='deer')giveInv('leather',1);if(e.type==='sheep')giveInv('wool',2);if(e.type==='bear')giveInv('leather',2);if(e.drop)giveInv(e.drop,1);giveInv('meat',m);addCoins(e.coin);questEv('hunt',1);}toast(creative?'تم':'+'+m+' لحم  +'+e.coin);}
  particles(e.x,e.y+1,e.z,0xffe27a,10);removeEnt(e);refreshHud();
 }
}
function meleeHit(it,id){
 const [fx,fz]=fwd();let best=null,bd=3.2;
 for(const e of ents){const dx=e.x-P.x,dz=e.z-P.z,d=Math.hypot(dx,dz);if(d<bd&&(dx*fx+dz*fz)/Math.max(d,.01)>.3){bd=d;best=e;}}
 if(best){dmgEnt(best,it.dmg*dmgMul(),fx,fz);if(it.burn)best.burn=3.5;return;}
 if(hitBlockUnderAim(it))return;
 let bp=null,pd=3.6,pch=null;
 nearProps(P.x,P.z,(p,ch)=>{const dx=p.x-P.x,dz=p.z-P.z,d=Math.hypot(dx,dz);if(d<pd&&(dx*fx+dz*fz)/Math.max(d,.01)>.15){pd=d;bp=p;pch=ch;}});
 if(bp){
  bp.hp-=it.pow||1;beep(bp.type==='tree'?300:520,.07,'triangle');particles(bp.x,bp.y+1,bp.z,bp.type==='tree'?0x8a5a2b:0xaaaaaa,5);
  if(bp.hp<=0){
   bp.dead=true;deadSet.add(pch.cx+','+pch.cz+','+bp.id);rebuildProps(pch);
   if(bp.type==='crystal'){const c=2+Math.floor(Math.random()*3);if(!creative){addCoins(c);questEv('crystal',1);if(Math.random()<.4)giveInv('diamond',1);}toast('+'+c+' عملة');}
  else if(bp.type==='tree'||bp.type==='deadtree'){const n=3+Math.floor(Math.random()*2);if(!creative){giveInv('wood',n);questEv('wood',n);}toast('+'+n+' خشب');}
   else if(bp.type==='cactus'||bp.type==='deadbush'){if(!creative)giveInv('berry',1);toast('+1 توت');}
   else if(bp.type==='bush'){if(!creative)giveInv('berry',2);toast('+2 توت');}
   else{const n=2+Math.floor(Math.random()*2);if(!creative)giveInv('stone',n);if(!creative){if(Math.random()<.22)giveInv('coal',1);if(Math.random()<.08)giveInv('gold',1);if(Math.random()<.04)giveInv('diamond',1);}let t='+'+n+' حجر';if(bp.type==='ore'){const k=2;if(!creative)giveInv('iron',k);t+=' و+'+k+' حديد';}else if(Math.random()<.25){if(!creative)giveInv('iron',1);t+=' و+1 حديد';}toast(t);}
   refreshHud();
  }
  return;
 }
 let bb=null,bdist=3.6;
 for(const b of built){const dx=b.x-P.x,dz=b.z-P.z,d=Math.hypot(dx,dz);if(d<bdist&&(dx*fx+dz*fz)/Math.max(d,.01)>.2){bdist=d;bb=b;}}
 if(bb){if(!creative)giveInv('wood',1);removePiece(bb.id);Net.send({t:'unbuild',id:bb.id});beep(200,.1,'square');refreshHud();}
}
function aimDir(){
 const cp=Math.cos(camPitch),sp=Math.sin(camPitch);
 const cf=new T.Vector3(Math.sin(camYaw)*cp*-1*-1,-sp,Math.cos(camYaw)*cp);// camera look direction
 const target=new T.Vector3(P.x,P.y+1.6,P.z).add(cf.clone().multiplyScalar(30));
 const o=new T.Vector3(P.x+Math.sin(camYaw)*.6,P.y+1.5,P.z+Math.cos(camYaw)*.6);
 return {o,d:target.sub(o).normalize()};
}
const shells=[];
function ejectShell(o,d){
 const m=new T.Mesh(GM.cyl,new T.MeshLambertMaterial({color:0xe0b43a,emissive:0x2a1c00}));m.scale.set(.025,.07,.025);
 const side=new T.Vector3(d.z,0,-d.x).normalize();m.position.copy(o).addScaledVector(side,.25);m.position.y-=.1;scene.add(m);
 shells.push({m,v:side.multiplyScalar(2.2+Math.random()).add(new T.Vector3((Math.random()-.5)*.8,2.4+Math.random()*1.2,(Math.random()-.5)*.8)),life:2.2,rx:(Math.random()-.5)*20,rz:(Math.random()-.5)*20,n:0});
}
function updateShells(dt){
 for(let i=shells.length-1;i>=0;i--){const s=shells[i];s.life-=dt;s.v.y-=22*dt;s.m.position.addScaledVector(s.v,dt);s.m.rotation.x+=s.rx*dt;s.m.rotation.z+=s.rz*dt;
  const g=Math.max(hAt(s.m.position.x,s.m.position.z),topBlockUnder(s.m.position.x,s.m.position.z,s.m.position.y+.5))+.03;
  if(s.m.position.y<g){s.m.position.y=g;if(s.n<2&&Math.abs(s.v.y)>1){s.v.y*=-.35;s.v.x*=.6;s.v.z*=.6;s.n++;beep(2400,.03,'triangle',.02);}else{s.v.set(0,0,0);s.rx=s.rz=0;}}
  if(s.life<=0){scene.remove(s.m);s.m.geometry!==GM.cyl&&s.m.geometry.dispose();shells.splice(i,1);}}
}
function shoot(it,id){
 const {o,d}=aimDir();const gun=id==='gun';
 const m=gun?new T.Mesh(GM.sph,new T.MeshBasicMaterial({color:0xffe27a})):new T.Mesh(GM.cyl,new T.MeshLambertMaterial({color:0xd9c79a}));
 if(gun)m.scale.setScalar(.09);else{m.scale.set(.03,.9,.03);m.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),d);}
 m.position.copy(o);scene.add(m);
 projs.push({m,p:o.clone(),v:d.clone().multiplyScalar(gun?75:40),g:gun?0:9,dmg:(gun?8:5)*dmgMul(),life:2.2,gun,ex:!!it.explosive});
 beep(gun?90:380,.12,gun?'sawtooth':'triangle',.05);
 if(gun)ejectShell(o,d);
}
/*BLOCKS*/
