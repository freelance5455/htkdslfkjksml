/* Levely – ověření, převod starého formátu, kód pro sdílení (BD2:…) a prázdný level
   Formát levelu (v2):
     w, h      rozměr pole v „věžových“ jednotkách (4–32); hra ho dělí na buňky 2×2 na věž
     spawns    1–8 bran vstupu  { side:'L'|'R'|'T'|'B', pos, len }  – mezery v okraji pole (pos/len v buňkách)
     exit      cíl: buď brána v okraji (stejný tvar), nebo „koule“ uvnitř pole { orb:[[x,y],…] } (buňky)
     rocks     skály  [[x,y],…] nebo [[x,y,g],…] v buňkách (kulatý tvar); buňky vedle sebe se stejným g se spojí do jedné skály
     walls     zdi    [[x,y],…]  v buňkách (přesný čtverec)
   Pravidla (všechno volitelné):
     lives     životy (1–999), gold  startovní zlato (0–99999)
     waves     počet vln do výhry (editor: 10–999); 0 nebo nic = nekonečno
     allowed   povolené kategorie věží, např. ['normal','burst']; nic = všechny
     towers    předpostavené věže [{type,x,y}] (levý horní roh, buňky)
     hp        násobek zdraví bublin (0,25–5)
     gap       odstup vln v sekundách (5–120), výchozí 20
   Brány (vstupy i cíl) se nesmí dotýkat – mezi nimi musí být aspoň jedna buňka mezery.
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  var G = BD.systems.grid;
  var MAX_SPAWNS = 8, MIN_SIZE = 4, MAX_SIZE = 32, MIN_WAVES = 10, MAX_WAVES = 999, MAX_ORB = 256;
  var LIMITS = { lives: [1, 999], gold: [0, 99999], waves: [0, MAX_WAVES], hp: [0.25, 5], gap: [5, 120] };

  function isInt(v) { return Number.isInteger(v); }

  function validGate(g, W, H) {
    if (!g || typeof g !== 'object' || !G.SIDES[g.side] || !isInt(g.pos) || !isInt(g.len) || g.len < 1) return false;
    var n = G.sideLen(g.side, W, H);
    return g.pos >= 0 && g.pos + g.len <= n;
  }
  function inField(p, W, H) { return Array.isArray(p) && isInt(p[0]) && isInt(p[1]) && p[0] >= 0 && p[1] >= 0 && p[0] < W && p[1] < H; }
  function rockOk(p, W, H) { return inField(p, W, H) && (p.length === 2 || (p.length === 3 && isInt(p[2]) && p[2] >= 0)); }

  /* starý formát (v1: vstupy/cíl jako políčka uvnitř pole, skály po celých políčkách) → v2; koule smaže skály a zdi pod sebou */
  function normalize(L) {
    if (!L || typeof L !== 'object') return L;
    var o = BD.util.clone(L);
    if (Array.isArray(o.exit)) {
      var S = BD.SUB, rocks = [];
      (o.rocks || []).forEach(function (r) {
        if (Array.isArray(r)) for (var a = 0; a < S; a++) for (var b = 0; b < S; b++) rocks.push([r[0] * S + a, r[1] * S + b]);
      });
      o.spawns = (o.spawns || []).map(function (s) { return { side: 'T', pos: (s[0] | 0) * S, len: S }; });
      o.exit = { side: 'B', pos: (o.exit[0] | 0) * S, len: S };
      o.rocks = rocks; o.walls = [];
    }
    if (!Array.isArray(o.walls)) o.walls = [];
    if (!Array.isArray(o.rocks)) o.rocks = [];
    if (G.isOrb(o.exit)) {
      var under = {}; o.exit.orb.forEach(function (c) { if (Array.isArray(c)) under[c[0] + ',' + c[1]] = 1; });
      var free = function (r) { return !Array.isArray(r) || !under[r[0] + ',' + r[1]]; };
      o.rocks = o.rocks.filter(free); o.walls = o.walls.filter(free);
    }
    return o;
  }

  /* tvar levelu (rozměry, brány, souřadnice, pravidla) – bez kontroly průchodnosti; stačí pro uložení rozdělaného levelu v editoru */
  function validateShape(L) {
    if (!L || typeof L !== 'object') return { ok: false, error: 'Neplatný level.' };
    if (!isInt(L.w) || !isInt(L.h) || L.w < MIN_SIZE || L.w > MAX_SIZE || L.h < MIN_SIZE || L.h > MAX_SIZE)
      return { ok: false, error: 'Rozměry: ' + MIN_SIZE + '–' + MAX_SIZE + ' věží na šířku i výšku.' };
    var W = L.w * BD.SUB, H = L.h * BD.SUB;
    if (!Array.isArray(L.spawns) || L.spawns.length < 1 || L.spawns.length > MAX_SPAWNS)
      return { ok: false, error: 'Level musí mít 1 až ' + MAX_SPAWNS + ' vstupů.' };
    if (!L.spawns.every(function (g) { return validGate(g, W, H); })) return { ok: false, error: 'Brána je mimo okraj pole.' };
    if (G.isOrb(L.exit)) {
      if (!L.exit.orb.length || L.exit.orb.length > MAX_ORB || !L.exit.orb.every(function (c) { return inField(c, W, H); })) return { ok: false, error: 'Cíl (koule) musí být uvnitř pole.' };
    } else if (!validGate(L.exit, W, H)) return { ok: false, error: 'Brána je mimo okraj pole.' };
    if (!Array.isArray(L.rocks) || L.rocks.length > W * H || !L.rocks.every(function (p) { return rockOk(p, W, H); })) return { ok: false, error: 'Skála je mimo plochu.' };
    if (!Array.isArray(L.walls) || L.walls.length > W * H || !L.walls.every(function (p) { return inField(p, W, H); })) return { ok: false, error: 'Zeď je mimo plochu.' };
    var used = {}, all = L.spawns.concat([L.exit]);
    for (var i = 0; i < all.length; i++) {
      var cells = G.exitCellsOf(all[i], W, H);
      for (var j = 0; j < cells.length; j++) {
        var k = cells[j][0] + ',' + cells[j][1];
        if (used[k]) return { ok: false, error: 'Dvě brány se překrývají.' };
        used[k] = 1;
      }
    }
    for (var f in LIMITS) {
      if (L[f] === undefined) continue;
      if (f === 'hp' ? (typeof L[f] !== 'number' || !isFinite(L[f])) : !isInt(L[f])) return { ok: false, error: 'Neplatné nastavení levelu (' + f + ').' };
      if (L[f] < LIMITS[f][0] || L[f] > LIMITS[f][1]) return { ok: false, error: 'Nastavení „' + f + '“ je mimo rozsah.' };
    }
    if (L.allowed !== undefined && (!Array.isArray(L.allowed) || L.allowed.length > 12 || !L.allowed.every(function (a) { return typeof a === 'string' && a.length < 20; })))
      return { ok: false, error: 'Neplatný seznam povolených věží.' };
    if (L.towers !== undefined) {
      var n = BD.SUB;
      if (!Array.isArray(L.towers) || L.towers.length > 300 || !L.towers.every(function (t) {
        return t && typeof t.type === 'string' && isInt(t.x) && isInt(t.y) && t.x >= 0 && t.y >= 0 && t.x + n <= W && t.y + n <= H; }))
        return { ok: false, error: 'Předpostavená věž je mimo plochu.' };
    }
    return { ok: true };
  }

  /* brány (vstupy i cíl) se nesmí dotýkat: mezi nimi aspoň 1 buňka mezery */
  function gapError(L) {
    var W = L.w * BD.SUB, H = L.h * BD.SUB, owner = {}, all = L.spawns.concat([L.exit]), i, j;
    for (i = 0; i < all.length; i++) G.exitCellsOf(all[i], W, H).forEach(function (c) { owner[c[0] + ',' + c[1]] = i; });
    for (i = 0; i < all.length; i++) {
      var cs = G.exitCellsOf(all[i], W, H);
      for (j = 0; j < cs.length; j++) for (var d = 0; d < 4; d++) {
        var o = owner[(cs[j][0] + G.DIRS[d][0]) + ',' + (cs[j][1] + G.DIRS[d][1])];
        if (o !== undefined && o !== i) {
          var a = Math.min(i, o), b = Math.max(i, o), name = function (n) { return n === all.length - 1 ? 'cíl' : 'vstup ' + (n + 1); };
          return 'Brány se dotýkají (' + name(a) + ' a ' + name(b) + ') – nech mezi nimi aspoň jednu buňku mezery.';
        }
      }
    }
    return null;
  }

  /* plná kontrola: tvar + mezery mezi branami + předpostavené věže + ze všech bran vstupu se dá dojít do cíle */
  function validate(L) {
    var sh = validateShape(L); if (!sh.ok) return sh;
    var W = L.w * BD.SUB, H = L.h * BD.SUB, n = BD.SUB;
    var ge = gapError(L); if (ge) return { ok: false, error: ge };
    var m = G.baseMaps(L), blocked = m.blocked, k, x, y;
    var d = G.bfs(m.EW, m.EH, blocked, m.exitIdx);
    var lens = [];
    for (var s = 0; s < m.spawnCells.length; s++) {
      var cs = m.spawnCells[s];
      for (var c = 0; c < cs.length; c++) if (d[G.idx(cs[c][0], cs[c][1], W)] < 0) return { ok: false, error: 'Z brány vstupu ' + (s + 1) + ' se nedá dojít do cíle.' };
      var ctr = G.gateCenter(L.spawns[s], W, H);
      lens.push(d[G.idx(ctr[0], ctr[1], W)]);
    }
    if (L.towers && L.towers.length) {
      var b2 = new Uint8Array(blocked), seen = {};
      for (var t = 0; t < L.towers.length; t++) {
        for (y = 0; y < n; y++) for (x = 0; x < n; x++) {
          k = G.idx(L.towers[t].x + x, L.towers[t].y + y, W);
          if (m.rock[k] || m.wall[k] || m.orb[k] || seen[k]) return { ok: false, error: 'Předpostavená věž leží na překážce nebo na jiné věži.' };
          seen[k] = 1; b2[k] = 1;
        }
      }
      var d2 = G.bfs(m.EW, m.EH, b2, m.exitIdx);
      for (s = 0; s < m.spawnCells.length; s++) for (c = 0; c < m.spawnCells[s].length; c++)
        if (d2[G.idx(m.spawnCells[s][c][0], m.spawnCells[s][c][1], W)] < 0) return { ok: false, error: 'Předpostavené věže zavírají cestu ke cíli.' };
    }
    return { ok: true, lens: lens };
  }

  function encode(L) {
    var o = { n: L.name || '', w: L.w, h: L.h, s: L.spawns, e: L.exit, r: L.rocks, k: L.walls || [] };
    if (L.lives !== undefined) o.l = L.lives;
    if (L.gold !== undefined) o.g = L.gold;
    if (L.waves !== undefined) o.v = L.waves;
    if (L.allowed) o.a = L.allowed;
    if (L.towers && L.towers.length) o.t = L.towers;
    if (L.hp !== undefined && L.hp !== 1) o.p = L.hp;
    if (L.gap !== undefined) o.q = L.gap;
    return 'BD2:' + btoa(unescape(encodeURIComponent(JSON.stringify(o))));
  }
  function decode(str) {
    try {
      str = String(str || '').trim();
      var v1 = str.indexOf('BD1:') === 0;
      if (!v1 && str.indexOf('BD2:') !== 0) return { ok: false, error: 'Kód musí začínat BD2: (nebo starším BD1:).' };
      var o = JSON.parse(decodeURIComponent(escape(atob(str.slice(4)))));
      var raw = { name: String(o.n || 'Importovaný level').slice(0, 40), w: o.w, h: o.h, spawns: o.s, exit: o.e, rocks: o.r, walls: o.k };
      if (o.l !== undefined) raw.lives = o.l;
      if (o.g !== undefined) raw.gold = o.g;
      if (o.v !== undefined) raw.waves = o.v;
      if (o.a !== undefined) raw.allowed = o.a;
      if (o.t !== undefined) raw.towers = o.t;
      if (o.p !== undefined) raw.hp = o.p;
      if (o.q !== undefined) raw.gap = o.q;
      var L = normalize(raw);
      var v = validate(L);
      return v.ok ? { ok: true, level: L } : v;
    } catch (e) { return { ok: false, error: 'Kód se nepodařilo přečíst.' }; }
  }

  /* prázdný level: nepřátelé jdou zleva doprava */
  function blank(name) {
    var h = 10, W = 12 * BD.SUB, H = h * BD.SUB, len = 4, pos = (H - len) / 2;
    return { name: name || 'Nový level', w: 12, h: h, spawns: [{ side: 'L', pos: pos, len: len }], exit: { side: 'R', pos: pos, len: len }, rocks: [], walls: [],
      waves: 20, lives: 20, gold: 100 };
  }

  BD.systems.levels = { validate: validate, validateShape: validateShape, validGate: validGate, gapError: gapError, normalize: normalize, encode: encode, decode: decode, blank: blank,
    MAX_SPAWNS: MAX_SPAWNS, MIN_SIZE: MIN_SIZE, MAX_SIZE: MAX_SIZE, MIN_WAVES: MIN_WAVES, MAX_WAVES: MAX_WAVES, MAX_ORB: MAX_ORB, LIMITS: LIMITS };
})(window.BD);
