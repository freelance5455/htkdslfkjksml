/* Mřížka, brány a hledání cesty (BFS od cíle – pole vzdáleností)
   Buňka = 1/SUB věže. Kolem hracího pole je 1 buňka silná zeď („okraj“); vstupy a cíl jsou
   BRÁNY = mezery v této zdi (buňky mimo pole: x=-1 / x=W / y=-1 / y=H).
   Pole vzdáleností má rozměr (W+2)×(H+2); index buňky = (y+1)*(W+2) + (x+1).
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  var DIRS = [[0, -1], [1, 0], [0, 1], [-1, 0]];
  var DIRS8 = [[0, -1], [1, 0], [0, 1], [-1, 0], [1, -1], [1, 1], [-1, 1], [-1, -1]];   // prvních 4 = DIRS, pak úhlopříčky
  var SIDES = { L: [1, 0], R: [-1, 0], T: [0, 1], B: [0, -1] };     // směr dovnitř pole

  function idx(x, y, W) { return (y + 1) * (W + 2) + (x + 1); }
  function sideLen(side, W, H) { return side === 'L' || side === 'R' ? H : W; }

  /* buňky brány (mimo pole) jako [x,y] */
  function gateCells(g, W, H) {
    var out = [];
    for (var i = 0; i < g.len; i++) {
      var p = g.pos + i;
      out.push(g.side === 'L' ? [-1, p] : g.side === 'R' ? [W, p] : g.side === 'T' ? [p, -1] : [p, H]);
    }
    return out;
  }
  function gateCenter(g, W, H) { return gateCells(g, W, H)[Math.floor((g.len - 1) / 2)]; }

  /* cíl může být brána v okraji {side,pos,len}, nebo „koule“ uvnitř pole {orb:[[x,y],…]} */
  function isOrb(ex) { return !!(ex && Array.isArray(ex.orb)); }
  function exitCellsOf(ex, W, H) { return isOrb(ex) ? ex.orb.map(function (c) { return [c[0], c[1]]; }) : gateCells(ex, W, H); }
  /* střed cíle (pro texty a efekty): u brány prostřední buňka, u koule těžiště */
  function exitCenter(ex, W, H) {
    var cs = exitCellsOf(ex, W, H);
    if (!isOrb(ex)) return cs[Math.floor((cs.length - 1) / 2)];
    var sx = 0, sy = 0; cs.forEach(function (c) { sx += c[0]; sy += c[1]; });
    return [Math.round(sx / cs.length), Math.round(sy / cs.length)];
  }
  /* souvislé skupiny buněk koule (4-sousedství) → [{cells, cx, cy, r}] ; cx,cy = střed v buňkách (desetinný), r = poloměr koule v buňkách */
  function orbBlobs(orb) {
    var key = {}, seen = {}, out = [];
    orb.forEach(function (c) { key[c[0] + ',' + c[1]] = c; });
    orb.forEach(function (c) {
      var k0 = c[0] + ',' + c[1]; if (seen[k0]) return;
      var st = [c], cells = [], sx = 0, sy = 0; seen[k0] = 1;
      while (st.length) {
        var a = st.pop(); cells.push(a); sx += a[0] + 0.5; sy += a[1] + 0.5;
        for (var i = 0; i < 4; i++) { var k = (a[0] + DIRS[i][0]) + ',' + (a[1] + DIRS[i][1]); if (key[k] && !seen[k]) { seen[k] = 1; st.push(key[k]); } }
      }
      out.push({ cells: cells, cx: sx / cells.length, cy: sy / cells.length, r: Math.max(0.62, Math.sqrt(cells.length / Math.PI) * 1.02 + 0.12) });
    });
    return out;
  }

  /* vrátí Int16Array vzdáleností buněk k cíli (-1 = nedosažitelné); sources = indexy cílových buněk */
  function bfs(ew, eh, blocked, sources, diag) {
    var d = new Int16Array(ew * eh).fill(-1);
    var q = new Int32Array(ew * eh);
    var qh = 0, qt = 0, i;
    for (i = 0; i < sources.length; i++) if (!blocked[sources[i]] && d[sources[i]] < 0) { d[sources[i]] = 0; q[qt++] = sources[i]; }
    while (qh < qt) {
      var c = q[qh++], x = c % ew, y = (c / ew) | 0;
      for (i = 0; i < (diag ? 8 : 4); i++) {
        var nx = x + DIRS8[i][0], ny = y + DIRS8[i][1];
        if (nx < 0 || ny < 0 || nx >= ew || ny >= eh) continue;
        if (i >= 4 && (blocked[y * ew + nx] || blocked[ny * ew + x])) continue;     // úhlopříčka nesmí „řezat“ roh zdi
        var ni = ny * ew + nx;
        if (blocked[ni] || d[ni] >= 0) continue;
        d[ni] = d[c] + 1; q[qt++] = ni;
      }
    }
    return d;
  }

  /* základní mapa překážek levelu: okraj + skály + zdi; brány jsou průchozí */
  function baseMaps(L) {
    var W = L.w * BD.SUB, H = L.h * BD.SUB, EW = W + 2, EH = H + 2, i;
    var blocked = new Uint8Array(EW * EH), rock = new Uint8Array(EW * EH), wall = new Uint8Array(EW * EH), gate = new Uint8Array(EW * EH), orb = new Uint8Array(EW * EH);
    for (i = 0; i < EW * EH; i++) { var x = i % EW - 1, y = ((i / EW) | 0) - 1; if (x < 0 || y < 0 || x >= W || y >= H) blocked[i] = 1; }
    (L.rocks || []).forEach(function (r) { var k = idx(r[0], r[1], W); rock[k] = 1; blocked[k] = 1; });
    (L.walls || []).forEach(function (r) { var k = idx(r[0], r[1], W); wall[k] = 1; blocked[k] = 1; });
    var spawnCells = L.spawns.map(function (g) { return gateCells(g, W, H); });
    var exitCells = exitCellsOf(L.exit, W, H), exitIsOrb = isOrb(L.exit);
    spawnCells.concat(exitIsOrb ? [] : [exitCells]).forEach(function (cs) { cs.forEach(function (c) { var k = idx(c[0], c[1], W); gate[k] = 1; blocked[k] = 0; }); });
    if (exitIsOrb) exitCells.forEach(function (c) { var k = idx(c[0], c[1], W); orb[k] = 1; rock[k] = 0; wall[k] = 0; blocked[k] = 0; });   // koule je pro bubliny průchozí, věž na ni postavit nejde
    return { W: W, H: H, EW: EW, EH: EH, blocked: blocked, rock: rock, wall: wall, gate: gate, orb: orb, spawnCells: spawnCells, exitCells: exitCells, exitIsOrb: exitIsOrb,
             exitIdx: exitCells.map(function (c) { return idx(c[0], c[1], W); }) };
  }

  BD.systems.grid = { DIRS: DIRS, DIRS8: DIRS8, SIDES: SIDES, idx: idx, sideLen: sideLen, gateCells: gateCells, gateCenter: gateCenter, isOrb: isOrb, exitCellsOf: exitCellsOf, exitCenter: exitCenter, orbBlobs: orbBlobs, bfs: bfs, baseMaps: baseMaps };
})(window.BD);
