/* Game – hlavní třída hry: skládá mřížku, věže, nepřátele, vlny a střely dohromady.
   Žádný DOM, takže jde testovat i v Node.
   Události (game.on): waveCleared, lifeLost, won, lost, spawn, card (padla karta), cardUsed
   Vlny jedou na „pásu“: po startu přijíždí každých gap sekund další vlna sama (nic se nečeká na hráče), vlny se můžou překrývat;
   hráč může vlnu z pásu přivolat dřív (callWaves) – přivolají se i všechny vlny před ní.
   Volitelné vlastnosti levelu: waves (počet vln do výhry, 0/nic = nekonečno), gold, lives, hp (násobek zdraví bublin),
   allowed (povolené kategorie věží), towers (předpostavené věže), gap (odstup vln v sekundách)
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  var S = BD.systems, grid = S.grid, T = S.towers, E = S.enemies, W = S.waves;
  var LIVES_START = 20, GOLD_START = 100, REFUND_FREE_SEC = 5;
  var WAVE_GAP = 20, START_DELAY = 8, SKIP_STAGGER = 1.5;      // sekundy: odstup vln, čekání na první vlnu po startu, odstup přivolaných vln

  function Game(level) { this.handlers = {}; this.setLevel(level); }
  var P = Game.prototype;

  P.on = function (name, fn) { this.handlers[name] = fn; return this; };
  P.emit = function (name, arg) { var f = this.handlers[name]; if (f) f(arg); };

  P.setLevel = function (level) { this.level = BD.util.clone(S.levels.normalize(level)); this.reset(); };

  /* skipInitial = nestavět předpostavené věže (obnova uložené hry je přidá ze snapshotu) */
  P.reset = function (skipInitial) {
    var L = this.level, m = grid.baseMaps(L);
    this.sub = BD.SUB;
    this.w = m.W; this.h = m.H; this.ew = m.EW; this.eh = m.EH;           // v buňkách (1 věž = sub×sub buněk)
    this.base = m.blocked; this.rock = m.rock; this.wall = m.wall; this.gate = m.gate; this.orb = m.orb;
    this.spawnCells = m.spawnCells; this.exitCells = m.exitCells; this.exitIdx = m.exitIdx; this.exitIsOrb = m.exitIsOrb;
    this.hpMul = Number.isFinite(L.hp) && L.hp > 0 ? L.hp : 1;
    this.allowed = Array.isArray(L.allowed) ? L.allowed : null;
    this.tgrid = new Int32Array(this.ew * this.eh);
    this.towers = []; this.enemies = []; this.shots = []; this.fx = [];
    this.nextId = 1; this.enemyId = 1;
    this.gold = Number.isFinite(L.gold) ? L.gold : GOLD_START;
    this.lives = Number.isFinite(L.lives) ? L.lives : LIVES_START;
    this.maxWaves = L.waves | 0;
    this.wave = 0; this.streams = []; this.waveLeft = {}; this.spawnIdx = 0;          // streams = proudy vypouštěných vln, waveLeft[n] = kolik bublin vlny n ještě žije / čeká
    this.gap = Number.isFinite(L.gap) && L.gap > 0 ? L.gap : WAVE_GAP; this.running = false; this.nextIn = START_DELAY;
    this.time = 0; this.kills = 0;
    this.gameOver = false; this.won = false;
    this.cards = []; this.cardFx = []; this.leaked = {};                              // karty (odměny): inventář, probíhající efekty, vlny, kterými prošla bublina
    if (this.rewards === undefined) this.rewards = true;
    if (!this.rnd) this.rnd = Math.random;
    if (!skipInitial && Array.isArray(L.towers)) {
      for (var i = 0; i < L.towers.length; i++) {
        var d = L.towers[i];
        if (!T.TYPES[d.type] || !this.spotFree(d.x, d.y, this.sub)) continue;
        this.addTower(d.type, d.x, d.y, 0, -999);
      }
    }
    /* duchové: letí skrz skály i věže, zastaví je jen zdi a okraj – vlastní pole vzdáleností (osm směrů), počítá se jednou */
    var gb = new Uint8Array(this.base);
    for (var gi = 0; gi < gb.length; gi++) if (this.rock[gi] && !this.wall[gi]) gb[gi] = 0;
    this.distG = grid.bfs(this.ew, this.eh, gb, this.exitIdx, true);
    this.recompute(); T.updateBoosts(this);
  };

  /* je čtverec size×size s levým horním rohem (x,y) celý v poli a bez skály, zdi, koule a věže? */
  P.spotFree = function (x, y, size) {
    for (var yy = 0; yy < size; yy++) for (var xx = 0; xx < size; xx++) {
      if (!this.inb(x + xx, y + yy)) return false;
      var i = this.idx(x + xx, y + yy);
      if (this.rock[i] || this.wall[i] || this.orb[i] || this.tgrid[i]) return false;
    }
    return true;
  };

  /* vytvoří věž základní velikosti bez placení; invested = kolik do ní bylo vloženo (pro prodej) */
  P.addTower = function (type, x, y, invested, placedAt) {
    var n = this.sub;
    var t = { id: this.nextId++, type: type, boost: 1, x: x, y: y, size: n, level: type === 'base' ? 0 : 1, tier: 0, cool: 0, angle: 0,
              invested: invested, placedAt: placedAt };
    t.s = T.stats(t); t.hp = t.s.hp;
    this.towers.push(t);
    var fp = this.footprint(x, y, n); for (var i = 0; i < fp.length; i++) this.tgrid[fp[i]] = t.id;
    return t;
  };

  /* buňka (x,y): pole je 0..w-1 × 0..h-1, brány leží o 1 mimo (x=-1 / x=w / y=-1 / y=h) */
  P.idx = function (x, y) { return (y + 1) * this.ew + (x + 1); };
  P.inb = function (x, y) { return x >= 0 && y >= 0 && x < this.w && y < this.h; };
  P.inExt = function (x, y) { return x >= -1 && y >= -1 && x <= this.w && y <= this.h; };

  /* indexy buněk čtverce size×size s levým horním rohem (x,y) */
  P.footprint = function (x, y, size) {
    var out = [];
    for (var yy = 0; yy < size; yy++) for (var xx = 0; xx < size; xx++) out.push(this.idx(x + xx, y + yy));
    return out;
  };

  P.blockedMap = function (extra) {
    var b = new Uint8Array(this.base);
    for (var i = 0; i < b.length; i++) if (this.tgrid[i]) b[i] = 1;
    if (extra) for (var j = 0; j < extra.length; j++) b[extra[j]] = 1;
    return b;
  };
  P.recompute = function () { this.dist = grid.bfs(this.ew, this.eh, this.blockedMap(), this.exitIdx); };

  P.byId = function (id) { for (var i = 0; i < this.towers.length; i++) if (this.towers[i].id === id) return this.towers[i]; return null; };
  P.towerAt = function (x, y) { return this.inb(x, y) && this.tgrid[this.idx(x, y)] ? this.byId(this.tgrid[this.idx(x, y)]) : null; };
  P.spawnCenter = function (i) { return this.spawnCells[i][Math.floor((this.spawnCells[i].length - 1) / 2)]; };
  /* délka cesty od brány vstupu i k cíli (v buňkách; ve věžích = / sub) */
  P.pathLen = function (i) { var c = this.spawnCenter(i); return this.dist[this.idx(c[0], c[1])]; };
  P.previewPath = function (i) { return E.previewPath(this, i); };

  /* délky cest od vstupů, kdyby byl čtverec věže (x,y,size) zablokovaný (náhled stavby) */
  P.pathLensIfBlocked = function (x, y, size) {
    var self = this, d = grid.bfs(this.ew, this.eh, this.blockedMap(this.footprint(x, y, size || this.sub)), this.exitIdx);
    return this.spawnCells.map(function (cs, i) { var c = self.spawnCenter(i); return d[self.idx(c[0], c[1])]; });
  };

  /* lze postavit věž (základní velikost sub×sub buněk) s levým horním rohem v buňce (x,y)? */
  P.canPlace = function (type, x, y) {
    if (this.gameOver || this.won) return { ok: false, reason: 'Hra skončila' };
    var TT = T.TYPES[type];
    if (!TT) return { ok: false, reason: 'Neznámá věž' };
    var n = this.sub, k, xx, yy;
    for (yy = 0; yy < n; yy++) for (xx = 0; xx < n; xx++) if (!this.inb(x + xx, y + yy)) return { ok: false, reason: 'Mimo plochu' };
    if (!this.spotFree(x, y, n)) return { ok: false, reason: 'Obsazeno' };
    if (this.gold < TT.cost) return { ok: false, reason: 'Málo zlata' };
    for (k = 0; k < this.enemies.length; k++) {
      var e = this.enemies[k];
      var ex = Math.floor(e.x), ey = Math.floor(e.y);
      if ((ex >= x && ex < x + n && ey >= y && ey < y + n) || (e.tx >= x && e.tx < x + n && e.ty >= y && e.ty < y + n)) return { ok: false, reason: 'Překáží bublina' };
    }
    var d = grid.bfs(this.ew, this.eh, this.blockedMap(this.footprint(x, y, n)), this.exitIdx);
    for (k = 0; k < this.spawnCells.length; k++) {
      var cs = this.spawnCells[k];
      for (var c = 0; c < cs.length; c++) if (d[this.idx(cs[c][0], cs[c][1])] < 0) return { ok: false, reason: 'Zablokuje cestu' };
    }
    for (k = 0; k < this.enemies.length; k++) if (d[this.idx(this.enemies[k].tx, this.enemies[k].ty)] < 0) return { ok: false, reason: 'Uzavře bublinu' };
    return { ok: true };
  };

  P.place = function (type, x, y) {
    if (!this.canPlace(type, x, y).ok) return null;
    var TT = T.TYPES[type], n = this.sub;
    var t = this.addTower(type, x, y, TT.cost, this.time);
    this.gold -= TT.cost;
    this.recompute(); T.updateBoosts(this);
    this.fx.push({ kind: 'pop', x: x + n / 2, y: y + n / 2, t: 0, life: 0.35, color: TT.color });
    return t;
  };

  /* vylepšení na věž „to“ (dítě aktuální věže ve stromě): zaplatí se cena dítěte, věž se přemění */
  P.upgrade = function (t, to) {
    if (typeof to !== 'string') return false;
    var c = T.upgradeCost(t, to);
    if (c === null || this.gold < c || this.gameOver || this.won) return false;
    if (this.allowed && this.allowed.indexOf(T.rootKind(to)) < 0) return false;
    this.gold -= c; t.invested += c; t.type = to; t.level = 1; t.upgraded = true;
    t.s = T.stats(t); t.hp = t.s.hp; T.updateBoosts(this);
    this.fx.push({ kind: 'pop', x: t.x + t.size / 2, y: t.y + t.size / 2, t: 0, life: 0.4, color: T.TYPES[to].color });
    return true;
  };

  P.sellValue = function (t) {
    var free = (this.time - t.placedAt) < REFUND_FREE_SEC && t.tier === 0 && !t.upgraded;
    return free ? t.invested : Math.floor(t.invested * 0.7);
  };
  P.sell = function (t) {
    if (this.gameOver || this.won) return 0;
    var v = this.sellValue(t);
    this.removeTower(t);
    this.gold += v;
    this.recompute(); T.updateBoosts(this);
    return v;
  };
  P.removeTower = function (t) {
    for (var yy = 0; yy < t.size; yy++) for (var xx = 0; xx < t.size; xx++) this.tgrid[this.idx(t.x + xx, t.y + yy)] = 0;
    this.towers = this.towers.filter(function (u) { return u !== t; });
  };

  /* sloučení: 4 stejné věže na max. úrovni ve čtverci 2×2 (násobek jejich velikosti) */
  P.findMerge = function (t) {
    if (!T.MERGE || t.type === 'base' || t.tier >= T.MAX_TIER) return null;            // sloučení je zatím vypnuté (kapitola Kombinace)
    var s = t.size, offs = [0, -s];
    for (var a = 0; a < 2; a++) for (var b = 0; b < 2; b++) {
      var ox = t.x + offs[a], oy = t.y + offs[b];
      var group = [], ok = true, cells = [[0, 0], [s, 0], [0, s], [s, s]];
      for (var c = 0; c < 4; c++) {
        var u = this.towerAt(ox + cells[c][0], oy + cells[c][1]);
        if (!u || u.x !== ox + cells[c][0] || u.y !== oy + cells[c][1] || u.size !== s || u.type !== t.type) { ok = false; break; }
        group.push(u);
      }
      if (ok) return { towers: group, x: ox, y: oy, size: s * 2 };
    }
    return null;
  };
  P.merge = function (t) {
    var m = this.findMerge(t);
    if (!m || this.gameOver || this.won) return null;
    var invested = 0;
    for (var i = 0; i < m.towers.length; i++) { invested += m.towers[i].invested; this.removeTower(m.towers[i]); }
    var n = { id: this.nextId++, type: t.type, boost: 1, x: m.x, y: m.y, size: m.size, level: 1, tier: t.tier + 1,
              cool: 0, angle: 0, invested: invested, placedAt: this.time };
    n.s = T.stats(n); n.hp = n.s.hp;
    this.towers.push(n);
    for (var yy = 0; yy < n.size; yy++) for (var xx = 0; xx < n.size; xx++) this.tgrid[this.idx(n.x + xx, n.y + yy)] = n.id;
    this.recompute(); T.updateBoosts(this);
    this.fx.push({ kind: 'pop', x: n.x + n.size / 2, y: n.y + n.size / 2, t: 0, life: 0.6, color: T.TYPES[n.type].color, big: true });
    return n;
  };

  /* ---------- vlny na pásu ---------- */
  P.allLaunched = function () { return !!(this.maxWaves && this.wave >= this.maxWaves); };
  /* vypustí další vlnu (delay = za kolik sekund začne) */
  P.launchWave = function (delay) {
    if (this.gameOver || this.won || this.allLaunched()) return 0;
    var n = ++this.wave, items = W.def(n);
    this.streams.push({ wave: n, queue: items.slice(), t: delay || 0, started: false });
    if (items.length) this.waveLeft[n] = items.length;        // prázdná vlna (Studio vyřadilo všechny typy) se hned počítá jako hotová
    return n;
  };
  P.startWave = function () { return !!this.launchWave(0); };            // jedna vlna hned, bez automatického pásu
  P.run = function () { if (!this.gameOver && !this.won) this.running = true; };
  /* přivolá k vlny z pásu najednou (s malým odstupem) a spustí pás; další vlna přijede za gap sekund */
  P.callWaves = function (k) {
    if (this.gameOver || this.won) return 0;
    var done = 0;
    var after = 0;                                   // další přivolané vlny vyrazí až po těch, co už čekají na vyjetí
    this.streams.forEach(function (s) { if (!s.started) after = Math.max(after, s.t + SKIP_STAGGER); });
    for (var i = 0; i < k; i++) if (this.launchWave(after + i * SKIP_STAGGER)) done++;
    this.running = true; this.nextIn = this.gap;
    return done;
  };
  /* příštích n vln pro zobrazení; eta = za kolik sekund přijede */
  P.belt = function (n) {
    var out = [], self = this, base = this.running ? this.nextIn : this.gap;     // před startem stojí první blok o slot pod rámečkem
    /* přivolané vlny, které ještě nevyjely: letí nahoru do rámečku a tam vyrazí (eta = za jak dlouho) */
    var pend = this.streams.filter(function (s) { return !s.started; }).sort(function (a, b) { return a.wave - b.wave; });
    pend.forEach(function (s, j) {
      var b = W.info(s.wave, self.hpMul); b.eta = Math.max(0, s.t); b.launching = true; b.k = 0; b.slot = j; out.push(b);   // fronta čekajících: slot 0 = rámeček
    });
    var P = pend.length, off = Math.max(P, (P > 0 ? P - 1 : 0) + base / this.gap);
    for (var i = 0; i < n; i++) {
      var w = this.wave + 1 + i; if (this.maxWaves && w > this.maxWaves) break;
      var b = W.info(w, this.hpMul); b.eta = base + i * this.gap; b.launching = false; b.k = i + 1; b.slot = (P > 0 ? off : base / this.gap) + i; out.push(b);
    }
    return out;
  };
  /* kolik vln je vyřízených popořadě (podle toho se ukládá postup) */
  P.clearedWave = function () { var m = this.wave + 1; for (var k in this.waveLeft) if (+k < m) m = +k; return m - 1; };
  /* bublina vlny n zmizela (zabita / doběhla); když je celá vlna pryč, přijde bonus */
  P.waveDone = function (n) {
    if (!(n in this.waveLeft)) return;
    if (--this.waveLeft[n] > 0) return;
    delete this.waveLeft[n];
    var b = 10 + n * 2; this.gold += b;
    var xc = grid.exitCenter(this.level.exit, this.w, this.h);
    this.fx.push({ kind: 'text', x: Math.max(1, Math.min(this.w - 1, xc[0] + 0.5)), y: Math.max(1, Math.min(this.h - 1, xc[1] + 0.5)), t: 0, life: 1.4, text: '+' + b, color: '#f0bf4c' });
    if (!this.leaked[n]) S.cards.drop(this, 'perfect');                        // bezchybná vlna: šance na kartu
    this.emit('waveCleared', n);
  };

  /* karty */
  P.useCard = function (i) { return S.cards.use(this, i); };
  P.giveCard = function (id) { if (!BD.data.cards.list[id]) return false; this.cards.push(id); this.emit('card', id); return true; };

  P.step = function (dt) {
    if (this.gameOver || this.won) return;
    this.time += dt;
    if (this.running && !this.allLaunched()) {
      this.nextIn -= dt;
      if (this.nextIn <= 0) { this.launchWave(0); this.nextIn += this.gap; }
    }
    W.update(this, dt);
    E.update(this, dt);
    T.update(this, dt);
    S.projectiles.update(this, dt);
    S.cards.tick(this, dt);

    for (var i = 0; i < this.fx.length; i++) this.fx[i].t += dt;
    this.fx = this.fx.filter(function (f) { return f.t < f.life; });
    this.enemies = this.enemies.filter(function (e) { return e.alive; });

    /* výhra: všechny vlny levelu vypuštěné a pryč */
    if (!this.gameOver && !this.won && this.allLaunched() && !this.streams.length && !this.enemies.length) { this.won = true; this.emit('won', this.wave); }
  };

  /* věž zničená nepřítelem */
  P.destroyTower = function (t) {
    this.fx.push({ kind: 'pop', x: t.x + t.size / 2, y: t.y + t.size / 2, t: 0, life: 0.5, color: '#e56b61', big: true });
    this.removeTower(t); this.recompute(); T.updateBoosts(this);
    this.emit('towerLost', t);
  };

  P.kill = function (e, opt) {
    e.alive = false; if (opt && opt.noSplit) e.noSplit = true;
    this.gold += e.reward; this.kills++;
    var B = E.TYPES[e.type];
    this.fx.push({ kind: 'pop', x: e.x, y: e.y, t: 0, life: 0.3, color: B.color });
    this.fx.push({ kind: 'text', x: e.x, y: e.y - 0.4, t: 0, life: 0.8, text: '+' + e.reward, color: '#f0bf4c' });
    if (e.type === 'boss') S.cards.drop(this, 'boss');                         // šéf: karta vždy (podle data/cards.js)
    E.onDeath(this, e);                                                        // rozpad na menší (mechanika ze Studia)
    this.waveDone(e.wave);
  };

  P.leak = function (e) {
    e.alive = false;
    var dmg = E.TYPES[e.type].life;
    this.lives -= dmg; this.leaked[e.wave] = true;
    this.fx.push({ kind: 'ring', x: e.x, y: e.y, t: 0, life: 0.5, r: 0.9 * this.sub, color: '#e56b61' });
    this.emit('lifeLost', dmg);
    if (this.lives <= 0) { this.lives = 0; this.gameOver = true; this.emit('lost', this.wave); } else this.waveDone(e.wave);
  };

  /* ---------- uložení a obnova (pro „Pokračovat“) ---------- */
  P.isIdle = function () { return !this.streams.length && !this.enemies.length && !this.gameOver && !this.won; };

  P.serialize = function () {
    return {
      v: 2, cards: this.cards.slice(), wave: this.clearedWave(), gold: this.gold, lives: this.lives, kills: this.kills, time: Math.floor(this.time),
      towers: this.towers.map(function (t) { return { type: t.type, x: t.x, y: t.y, level: t.level, tier: t.tier, invested: t.invested }; }),
    };
  };

  P.restore = function (s) {
    this.reset(true);
    if (!s || typeof s !== 'object' || !Array.isArray(s.towers) || s.v === 1) return false;   // v1 = stará hrubá mřížka
    var num = function (v, def) { return Number.isFinite(v) ? v : def; };
    this.wave = Math.max(0, num(s.wave, 0) | 0);
    this.gold = Math.max(0, num(s.gold, this.gold));
    this.lives = Math.max(1, num(s.lives, this.lives));
    this.kills = Math.max(0, num(s.kills, 0) | 0);
    this.time = Math.max(0, num(s.time, 0));
    if (Array.isArray(s.cards)) this.cards = s.cards.filter(function (c) { return typeof c === 'string' && BD.data.cards.list[c]; }).slice(0, 100);
    for (var i = 0; i < s.towers.length; i++) {
      var d = s.towers[i];
      if (d && d.branch && T.TYPES[String(d.type) + '_' + d.branch]) d = Object.assign({}, d, { type: d.type + '_' + d.branch });     // starý postup: kategorie + větev → samostatná věž
      if (!d || !T.TYPES[d.type]) continue;
      var tier = BD.util.clamp(d.tier | 0, 0, T.MAX_TIER), size = this.sub << tier;
      var x = d.x | 0, y = d.y | 0;
      if (!this.spotFree(x, y, size)) continue;
      var t = { id: this.nextId++, type: d.type, boost: 1, x: x, y: y, size: size, level: BD.util.clamp(d.level | 0, d.type === 'base' ? 0 : 1, T.MAX_LEVEL),
                tier: tier, cool: 0, angle: 0, invested: Math.max(0, num(d.invested, T.TYPES[d.type].cost)), placedAt: -999 };
      t.s = T.stats(t); t.hp = t.s.hp;
      for (var y2 = 0; y2 < size; y2++) for (var x2 = 0; x2 < size; x2++) this.tgrid[this.idx(x + x2, y + y2)] = t.id;
      this.towers.push(t);
    }
    this.recompute(); T.updateBoosts(this);
    return true;
  };

  S.GAME = { LIVES_START: LIVES_START, GOLD_START: GOLD_START, WAVE_GAP: WAVE_GAP, REFUND_FREE_SEC: REFUND_FREE_SEC };
  S.Game = Game;
})(window.BD);
