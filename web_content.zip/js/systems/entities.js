'use strict';
/* ================= entities ================= */
const ents=[],projs=[],built=[],parts=[];
const ANIMALS={
 deer:{c:0xb9824b,w:.5,l:.9,h:.5,lg:.8,hp:6,meat:2,coin:1,sp:2.4,ears:1,ant:1},
 pig:{c:0xf0a3b4,w:.5,l:.75,h:.5,lg:.4,hp:5,meat:2,coin:1,sp:1.7,snout:1},
 rabbit:{c:0xece6da,w:.2,l:.32,h:.2,lg:.15,hp:2,meat:1,coin:1,sp:3.4,ears:2},
 cow:{c:0xece4d6,w:.55,l:1,h:.65,lg:.55,hp:10,meat:3,coin:1,sp:1.5,ears:1},
 sheep:{c:0xf6f6f2,w:.5,l:.8,h:.55,lg:.4,hp:7,meat:2,coin:1,sp:1.6,snout:1},
 bear:{c:0x5b3a24,w:.7,l:1.1,h:.8,lg:.5,hp:32,meat:4,coin:6,sp:3.6,ears:1},
 camel:{c:0xc9a165,w:.55,l:1.1,h:.75,lg:.9,hp:14,meat:3,coin:1,sp:2,ears:1,hump:1},
 fox:{c:0xe0782a,w:.25,l:.5,h:.3,lg:.3,hp:5,meat:1,coin:1,sp:3,ears:1},
 fish:{c:0x6fb7e0,w:.14,l:.42,h:.16,lg:0,hp:2,meat:1,coin:1,sp:1.5},
 bird:{c:0x5a7ad6,w:.12,l:.22,h:.12,lg:0,hp:2,meat:1,coin:1,sp:4}
};
const VSKINS=[{body:0x8a5a3a,pants:0x4a3a2a,skin:0xe0b48a,hat:'none',robe:1},{body:0x5a7a3a,pants:0x3a3a2a,skin:0xd8a878,hat:'none',robe:1},{body:0x7a3a6a,pants:0x3a2a3a,skin:0xe8c098,hat:'none',robe:1}];
function makeAnimal(type){
 const c=ANIMALS[type],g=new T.Group(),mats=[];const M=col=>{const m=mat(col);mats.push(m);return m;};
 const body=new T.Mesh(GM.sph,M(c.c));body.scale.set(c.w,c.h,c.l);body.position.y=c.lg+c.h*.7;g.add(body);
 const head=new T.Mesh(GM.sph,M(c.c));const hs=c.h*.62;head.scale.set(hs,hs,hs*1.1);head.position.set(0,c.lg+c.h*1.25,c.l*.85);g.add(head);
 const eM=new T.MeshBasicMaterial({color:0x111111});for(const sx of[-1,1]){const e=new T.Mesh(GM.sph,eM);e.scale.set(.04,.04,.03);e.position.set(hs*.55*sx,c.lg+c.h*1.35,c.l*.85+hs*.9);g.add(e);}
 if(c.snout){const s=new T.Mesh(GM.sph,M(0xe48a9c));s.scale.set(.1,.08,.07);s.position.set(0,c.lg+c.h*1.2,c.l*.85+hs*1.05);g.add(s);}
 if(c.ears){for(const sx of[-1,1]){const e=new T.Mesh(GM.cone,M(c.c));const L=c.ears===2?.38:.16;e.scale.set(.06,L,.04);e.position.set(.11*sx,c.lg+c.h*1.25+hs+L*.4,c.l*.8);g.add(e);}}
 if(c.ant){for(const sx of[-1,1]){const a=new T.Mesh(GM.cyl,M(0xe8d9b0));a.scale.set(.025,.35,.025);a.position.set(.1*sx,c.lg+c.h*1.25+hs+.2,c.l*.8);a.rotation.z=-.4*sx;g.add(a);}}
 if(c.hump){const hp=new T.Mesh(GM.sph,M(c.c));hp.scale.set(.3,.34,.34);hp.position.set(0,c.lg+c.h*1.5,-.05);g.add(hp);}
 const tail=new T.Mesh(GM.sph,M(c.ears===2?0xffffff:c.c));tail.scale.set(.08,.08,.08);tail.position.set(0,c.lg+c.h*.9,-c.l*.95);g.add(tail);
 const legs=[];for(const sx of[-1,1])for(const sz of[-1,1]){const p=new T.Group();p.position.set(c.w*.55*sx,c.lg+.08,c.l*.5*sz);const l=new T.Mesh(GM.cyl,M(c.c));const len=c.lg+.08;l.scale.set(.06+c.w*.1,len,.06+c.w*.1);l.position.y=-len/2;p.add(l);g.add(p);legs.push(p);}
 g.traverse(o=>{if(o.isMesh)o.castShadow=true;});
 return {g,legs,mats};
}
let P=null,world={ready:false,started:false};
function spawnEnt(kind,x,z){
 const y=Cave.on?Cave.y:Math.max(heightAt(x,z),-.45);
 let e;
 if(kind==='zombie'){const ch=makeChar(ZSKIN);ch.armL.rotation.x=-1.4;ch.armR.rotation.x=-1.4;
  e={kind:'zombie',g:ch.g,ch,mats:ch.mats,hp:14,max:14,sp:2.7,coin:6,r:.7,hit:1.1,dm:1,cm:1};
  const rr=Math.random();let v=rr<.5?'normal':rr<.72?'runner':rr<.88?'brute':'toxic';
  if(WTK==='snow'&&rr<.6)v='frozen';else if(WTK==='desert'&&rr<.6)v='husk';else if(WTK==='nether'&&rr<.6)v='magma';
  const V={runner:{tint:0xb0c040,hp:9,sp:1.55,dm:.7,cm:1.2},brute:{tint:0x2f4a2f,hp:30,sp:.85,dm:1.7,cm:2,sc:1.22},toxic:{tint:0x6fe03a,hp:14,sp:1,dm:1.1,cm:1.4,tox:1},frozen:{tint:0x8fd6f0,hp:16,sp:.9,dm:1,cm:1.3},husk:{tint:0xc9a55a,hp:12,sp:1.1,dm:1,cm:1.1},magma:{tint:0xe0501a,hp:22,sp:1.1,dm:1.3,cm:1.6,fire:1}}[v];
  e.variant=v;if(V){for(const m of ch.mats)m.color.lerp(new T.Color(V.tint),.6);e.hp=e.max=V.hp;e.sp*=V.sp;e.dm=V.dm;e.cm=V.cm;e.tox=V.tox;e.fireHit=V.fire;if(V.sc){ch.g.scale.setScalar(V.sc);e.r=.85;}}}
 else if(kind==='skeleton'){const ch=makeChar({body:0xe4e2d4,pants:0xc9c7b8,skin:0xece9dc,hat:'none'});ch.armL.rotation.x=-1.5;ch.armR.rotation.x=-1.5;
  e={kind:'skeleton',g:ch.g,ch,mats:ch.mats,hp:10,max:10,sp:2.1,coin:5,r:.6,hit:1.1,cm:1.5,shotT:2};}
 else if(kind==='villager'){const ch=makeChar(VSKINS[Math.floor(Math.random()*3)]);{const sk=ch.mats[0].color.clone();const nose=new T.Mesh(GM.sph,mat(0xd8a070));nose.scale.set(.07,.13,.1);nose.position.set(0,1.95,.4);ch.g.add(nose);const brow=new T.Mesh(GM.sph,mat(0x4a3a2a));brow.scale.set(.3,.05,.08);brow.position.set(0,2.12,.3);ch.g.add(brow);ch.g.scale.setScalar(.94+Math.random()*.12);}
  e={kind:'villager',g:ch.g,ch,mats:ch.mats,hp:20,max:20,sp:1.3,r:.6,hit:1,hx:x,hz:z};}
 else{const a=makeAnimal(kind),c=ANIMALS[kind];e={kind,type:kind,g:a.g,legs:a.legs,mats:a.mats,hp:c.hp,max:c.hp,sp:c.sp,meat:c.meat,coin:c.coin,r:kind==='bear'?1:.8,hit:kind==='bear'?.9:.5};
  if(kind==='fish'){e.aqua=1;e.ya=Math.random()*6.28;e.drop='fish';e.g.scale.setScalar(1.7);a.legs.forEach(l=>l.visible=false);}
  if(kind==='bird'){e.fly=1;e.ya=Math.random()*6.28;e.alt=5+Math.random()*6;e.drop='feather';e.ph0=Math.random()*6;a.legs.forEach(l=>{l.scale.y=.4;});const wm=mat(0x3a58b0);e.wings=[];for(const sx of[-1,1]){const w=new T.Mesh(GM.sph,wm);w.scale.set(.32,.02,.14);w.position.set(.16*sx,.2,0);a.g.add(w);e.wings.push(w);}e.g.scale.setScalar(1.5);}
 }
 e.x=x;e.z=z;e.y=y;e.yaw=Math.random()*6.28;e.t=0;e.flee=0;e.flash=0;e.ph=0;e.cool=0;e.mv=0;
 e.g.position.set(x,y,z);scene.add(e.g);ents.push(e);return e;
}
function removeEnt(e){scene.remove(e.g);e.g.traverse(o=>{if(o.geometry&&o.geometry.type!=='SphereGeometry'&&o.geometry.type!=='CylinderGeometry'&&o.geometry.type!=='ConeGeometry'&&o.geometry.type!=='IcosahedronGeometry')o.geometry.dispose();});const i=ents.indexOf(e);if(i>=0)ents.splice(i,1);}
function particles(x,y,z,col,n){for(let i=0;i<(n||7);i++){const m=new T.Mesh(GM.ico,new T.MeshBasicMaterial({color:col}));m.scale.setScalar(.07+Math.random()*.08);m.position.set(x,y,z);scene.add(m);parts.push({m,vx:(Math.random()-.5)*4,vy:2+Math.random()*3,vz:(Math.random()-.5)*4,life:.7});}}

