/* Nepřátelé (bubliny) – data, vznik a pohyb po cestě
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  var DIRS = BD.systems.grid.DIRS;

  /* rychlost je ve věžích/s, poloměr r v buňkách (buňka = 1/2 věže, ulička je široká 1 buňku, proto r < 0,5) */
  var TYPES = {
    bub:   { name: 'Bublina', color: '#e077c0', hp: 20,  speed: 1.0,  reward: 3,  r: 0.27, life: 1 },
    fast:  { name: 'Rychlá',  color: '#e0cf54', hp: 14,  speed: 1.8,  reward: 3,  r: 0.21, life: 1 },
    tank:  { name: 'Těžká',   color: '#a06ae0', hp: 90,  speed: 0.65, reward: 8,  r: 0.34, life: 2 },
    swarm: { name: 'Roj',     color: '#e0625a', hp: 7,   speed: 1.4,  reward: 1,  r: 0.16, life: 1 },
    ghost: { name: 'Duch',    color: '#b9d6ea', hp: 30,  speed: 1.1,  reward: 5,  r: 0.27, life: 1, ghost: true },
    boss:  { name: 'Šéf',     color: '#ff8a5c', hp: 800, speed: 0.5,  reward: 60, r: 0.46, life: 5 },
  };

  /* volitelné mechaniky nepřítele (nastavují se ve Studiu):
     resist 0–0.9 (snížení poškození), regen (zdraví/s), slowImmune, splitCount + splitInto (po smrti se rozpadne na menší),
     atkDmg + atkRange + atkCd (útočí na věže; atkRange v „věžích“), atkStop (při útoku stojí) */
  function hurt(e, dmg) { var r = TYPES[e.type].resist || 0; return dmg * (1 - r); }

  function hpScale(n) { return Math.pow(1.13, n - 1); }

  function spawn(game, type, wave) {
    wave = wave || game.wave;
    var B = TYPES[type];
    var n = game.spawnCells.length, k = game.spawnIdx++;
    var gi = k % n, cells = game.spawnCells[gi], sp = cells[Math.floor(k / n) % cells.length];    // střídá brány i dráhy v bráně
    var dir = BD.systems.grid.SIDES[game.level.spawns[gi].side];
    var hp = B.hp * hpScale(wave) * (game.hpMul || 1);
    game.enemies.push({ id: game.enemyId++, type: type, x: sp[0] + 0.5, y: sp[1] + 0.5, tx: sp[0], ty: sp[1],
      dx: dir[0], dy: dir[1], hp: hp, maxhp: hp, speed: B.speed * game.sub, slow: 0, slowT: 0, reward: B.reward, alive: true, wave: wave });
    if (game.emit) game.emit('spawn', type);
  }

  /* potomek rozpadlého nepřítele: stejné místo a směr, mírně rozptýlený, vlastní zdraví podle svého typu */
  var MAX_GEN = 3;
  function spawnChild(game, parent, type, i, n) {
    var B = TYPES[type]; if (!B) return null;
    var hp = B.hp * hpScale(parent.wave) * (game.hpMul || 1), a = (i / n) * Math.PI * 2 + 0.7, j = 0.12;
    var c = { id: game.enemyId++, type: type, x: parent.x + Math.cos(a) * j, y: parent.y + Math.sin(a) * j, tx: parent.tx, ty: parent.ty,
      dx: parent.dx, dy: parent.dy, hp: hp, maxhp: hp, speed: B.speed * game.sub, slow: 0, slowT: 0, reward: B.reward, alive: true, wave: parent.wave, gen: (parent.gen || 0) + 1 };
    game.enemies.push(c);
    if (game.emit) game.emit('spawn', type);
    return c;
  }
  function onDeath(game, e) {
    var B = TYPES[e.type], n = B.splitCount | 0;
    if (!n || !B.splitInto || !TYPES[B.splitInto] || (e.gen || 0) >= MAX_GEN || e.noSplit) return 0;
    game.waveLeft[e.wave] = (game.waveLeft[e.wave] || 0) + n;           // potomci se počítají do vlny
    for (var i = 0; i < n; i++) spawnChild(game, e, B.splitInto, i, n);
    game.fx.push({ kind: 'ring', x: e.x, y: e.y, t: 0, life: 0.4, r: 0.8 * game.sub, color: B.color });
    return n;
  }

  /* útok na věže: nejbližší věž v dosahu dostane poškození; atkStop = během útoku nepřítel stojí */
  function attackTowers(game, e, B, dt) {
    e.atk = (e.atk || 0) - dt;
    var R = B.atkRange * game.sub, best = null, bd = 1e9;
    for (var i = 0; i < game.towers.length; i++) {
      var t = game.towers[i], cx = t.x + t.size / 2, cy = t.y + t.size / 2, d = Math.hypot(cx - e.x, cy - e.y) - t.size / 2;
      if (d <= R && d < bd) { bd = d; best = t; }
    }
    e.busy = !!(best && B.atkStop);
    if (!best || e.atk > 0) return;
    e.atk = B.atkCd || 1;
    best.hp -= B.atkDmg;
    game.fx.push({ kind: 'zap', x: e.x, y: e.y, x2: best.x + best.size / 2, y2: best.y + best.size / 2, t: 0, life: 0.25, color: B.color });
    if (best.hp <= 0) game.destroyTower(best);
  }

  /* další políčko na cestě (preferuje stejný směr, aby bubliny nekličkovaly zbytečně) */
  function nextCell(game, x, y, pdx, pdy, ghost) {
    var F = ghost ? game.distG : game.dist, D = ghost ? BD.systems.grid.DIRS8 : DIRS;     // duch: pole vzdáleností jen se zdmi, i úhlopříčky
    var d = F[game.idx(x, y)];
    if (d <= 0) return null;
    var best = null;
    for (var i = 0; i < D.length; i++) {
      var dx = D[i][0], dy = D[i][1];
      var nx = x + dx, ny = y + dy;
      if (!game.inExt(nx, ny)) continue;
      if (i >= 4 && (F[game.idx(x + dx, y)] < 0 || F[game.idx(x, y + dy)] < 0)) continue;
      var nd = F[game.idx(nx, ny)];
      if (nd < 0 || nd >= d) continue;
      if (dx === pdx && dy === pdy) return [nx, ny, dx, dy];
      if (!best) best = [nx, ny, dx, dy];
    }
    return best;
  }

  /* náhled cesty od vstupu – stejná logika, jakou chodí bubliny */
  function previewPath(game, si) {
    var s = game.spawnCenter(si), dir = BD.systems.grid.SIDES[game.level.spawns[si].side];
    var out = [[s[0], s[1]]];
    var x = s[0], y = s[1], dx = dir[0], dy = dir[1], guard = 0;
    while (guard++ < game.ew * game.eh) {
      var n = nextCell(game, x, y, dx, dy);
      if (!n) break;
      x = n[0]; y = n[1]; dx = n[2]; dy = n[3];
      out.push([x, y]);
    }
    return out;
  }

  function update(game, dt) {
    for (var i = 0; i < game.enemies.length; i++) {
      var e = game.enemies[i];
      if (!e.alive) continue;
      var BT = TYPES[e.type];
      if (e.slowT > 0) { e.slowT -= dt; if (e.slowT <= 0) e.slow = 0; }
      if (BT.regen && e.hp < e.maxhp) e.hp = Math.min(e.maxhp, e.hp + BT.regen * dt);
      if (BT.atkDmg > 0 && BT.atkRange > 0) attackTowers(game, e, BT, dt);
      var move = e.busy ? 0 : e.speed * (1 - e.slow) * dt;
      var guard = 0;
      while (move > 1e-6 && guard++ < 5 && e.alive) {
        var cx = e.tx + 0.5, cy = e.ty + 0.5;
        var dx = cx - e.x, dy = cy - e.y, d = Math.hypot(dx, dy);
        if (d <= move) {
          e.x = cx; e.y = cy; move -= d;
          var gh = !!TYPES[e.type].ghost;
          if ((gh ? game.distG : game.dist)[game.idx(e.tx, e.ty)] === 0) { game.leak(e); break; }
          var n = nextCell(game, e.tx, e.ty, e.dx, e.dy, gh);
          if (!n) break;
          e.tx = n[0]; e.ty = n[1]; e.dx = n[2]; e.dy = n[3];
        } else { e.x += dx / d * move; e.y += dy / d * move; move = 0; }
      }
    }
  }

  BD.systems.enemies = { TYPES: TYPES, hpScale: hpScale, spawn: spawn, nextCell: nextCell,
    previewPath: previewPath, update: update, hurt: hurt, onDeath: onDeath, MAX_GEN: MAX_GEN };
})(window.BD);
