'use strict';
/* ================= accounts (saved on this device) ================= */
let DB={last:'',accounts:{}};
try{DB=Object.assign(DB,JSON.parse(localStorage.getItem('ardkhayal2')||'{}'));}catch(e){}
const S={name:'',coins:0,owned:['explorer'],skin:'explorer',friends:[],reqIn:[],reqOut:[],recent:[],token:'',stock:[],armors:[],armor:'',gift:null,quests:null,playSec:0,prog:{},consent:false,bonusSeen:''};
function saveDB(){try{localStorage.setItem('ardkhayal2',JSON.stringify(DB));}catch(e){}}
function save(){if(S.name)DB.accounts[S.name]={coins:S.coins,owned:S.owned,skin:S.skin,friends:S.friends,reqIn:S.reqIn,reqOut:S.reqOut,recent:S.recent,token:S.token,stock:S.stock,armors:S.armors,armor:S.armor,gift:S.gift,quests:S.quests,playSec:S.playSec,prog:S.prog,consent:S.consent,bonusSeen:S.bonusSeen,big:S.big?1:0,week:S.week||null,ck:fnv(S.coins+'|'+S.token+'|k9')};saveDB();}
function loadAcc(n){
 const a=DB.accounts[n]||{};
 S.name=n;S.coins=a.coins|0;S.owned=a.owned||['explorer'];S.skin=a.skin||'explorer';
 S.friends=a.friends||[];S.reqIn=a.reqIn||[];S.reqOut=a.reqOut||[];S.recent=a.recent||[];
 S.token=a.token||newToken();S.stock=a.stock||[];S.armors=a.armors||[];S.armor=a.armor||'';S.gift=a.gift||null;S.week=a.week||null;S.quests=a.quests||null;S.playSec=a.playSec||0;S.prog=a.prog||{};S.consent=!!a.consent;S.bonusSeen=a.bonusSeen||'';S.big=a.big?1:0;
 S.tamper=!!(a.ck&&a.ck!==fnv(S.coins+'|'+S.token+'|k9'));
 DB.last=n;save();
}
if(DB.last)loadAcc(DB.last);

