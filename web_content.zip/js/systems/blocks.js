'use strict';
/* ================= blocks (Minecraft-style grid, 1 m cubes) ================= */
const BT={
 planks:{n:'ألواح خشب',c:[.78,.6,.35],h:2,tool:'axe'},
 log:{n:'جذع',c:[.46,.32,.18],h:2,tool:'axe'},
 cobble:{n:'حجارة مرصوصة',c:[.56,.57,.6],h:5,tool:'pick'},
 dirt:{n:'تراب',c:[.47,.33,.2],h:1},
 sand:{n:'رمل',c:[.9,.83,.56],h:1},
 glass:{n:'زجاج',c:[.72,.9,.97],h:1,glass:1},
 brick:{n:'طوب',c:[.7,.33,.28],h:5,tool:'pick'},
 wool:{n:'صوف',c:[.94,.94,.92],h:1},
 lamp:{n:'مصباح',c:[1,.86,.42],h:1,glow:1},
 table:{n:'طاولة صناعة',c:[.62,.43,.23],h:2,table:1,tool:'axe'},
 door:{n:'باب',c:[.6,.4,.2],h:2,door:1,tool:'axe'},
 slab:{n:'بلاطة سقف',c:[.72,.3,.26],h:3,half:1,tool:'pick'}
};
const BLOCK_IDS=Object.keys(BT);
for(const k of BLOCK_IDS){ITEMS[k]={n:BT[k].n,type:'block'};ICONS[k]='<path d="M12 3l8 4v10l-8 4-8-4V7z"/><path d="M4 7l8 4 8-4M12 11v10"/>';}
const BLK=new Map(),BCK=new Map(),BDIRTY=new Set(),BMESH=new Map(),TBL=new Set();
const bk=(x,y,z)=>x+','+y+','+z;
const blkMat=new T.MeshLambertMaterial({vertexColors:true}),
 glassMat=new T.MeshLambertMaterial({vertexColors:true,transparent:true,opacity:.42,depthWrite:false}),
 glowBMat=new T.MeshBasicMaterial({vertexColors:true});
const STEPC=.6;
const solidBlock=b=>!(BT[b.t].door&&b.open);
function ckOf(x,z){return (x>>4)+','+(z>>4);}
function markDirty(x,z){BDIRTY.add(ckOf(x,z));if((x&15)===0)BDIRTY.add(ckOf(x-1,z));if((x&15)===15)BDIRTY.add(ckOf(x+1,z));if((z&15)===0)BDIRTY.add(ckOf(x,z-1));if((z&15)===15)BDIRTY.add(ckOf(x,z+1));}
function setBlock(x,y,z,t,o,open,top){
 if(!BT[t])return;const k=bk(x,y,z);
 BLK.set(k,{t,x,y,z,o:o||0,open:!!open,top:!!top,hp:BT[t].h});
 const ck=ckOf(x,z);let s=BCK.get(ck);if(!s){s=new Set();BCK.set(ck,s);}s.add(k);
 if(t==='table')TBL.add(k);markDirty(x,z);
}
function delBlock(x,y,z){
 const k=bk(x,y,z),b=BLK.get(k);if(!b)return;
 BLK.delete(k);TBL.delete(k);const s=BCK.get(ckOf(x,z));if(s)s.delete(k);markDirty(x,z);
}
function clearBlocks(){
 for(const m of BMESH.values())for(const o of m){scene.remove(o);o.geometry.dispose();}
 BMESH.clear();BLK.clear();BCK.clear();BDIRTY.clear();TBL.clear();
}
const bHash=(x,y,z)=>{let h=(x*73856093)^(y*19349663)^(z*83492791);h=(h^(h>>>13))*1274126177;return ((h^(h>>>16))>>>0)/4294967296;};
const FACES=[
 [1,0,0,.82,(a,b,c,d,e,f)=>[[d,b,f],[d,b,c],[d,e,c],[d,e,f]]],
 [-1,0,0,.8,(a,b,c,d,e,f)=>[[a,b,c],[a,b,f],[a,e,f],[a,e,c]]],
 [0,1,0,1,(a,b,c,d,e,f)=>[[a,e,f],[d,e,f],[d,e,c],[a,e,c]]],
 [0,-1,0,.5,(a,b,c,d,e,f)=>[[a,b,c],[d,b,c],[d,b,f],[a,b,f]]],
 [0,0,1,.7,(a,b,c,d,e,f)=>[[a,b,f],[d,b,f],[d,e,f],[a,e,f]]],
 [0,0,-1,.66,(a,b,c,d,e,f)=>[[d,b,c],[a,b,c],[a,e,c],[d,e,c]]]
];
function emitBox(o,x0,y0,z0,x1,y1,z1,col,cull,nz){
 for(let i=0;i<6;i++){
  if(cull&(1<<i))continue;const F=FACES[i],q=F[4](x0,y0,z0,x1,y1,z1),sh=F[3]*nz;
  const r=col[0]*sh,g=col[1]*sh,b=col[2]*sh;
  for(const k of [0,1,2,0,2,3]){o.p.push(q[k][0],q[k][1],q[k][2]);o.n.push(F[0],F[1],F[2]);o.c.push(r,g,b);}
 }
}
function occl(x,y,z,self){const n=BLK.get(bk(x,y,z));if(!n)return false;const d=BT[n.t];if(d.door||d.half)return false;if(d.glass)return self.glass&&n.t===self.t;return true;}
function rebuildBlockChunk(ck){
 const old=BMESH.get(ck);if(old){for(const m of old){scene.remove(m);m.geometry.dispose();}BMESH.delete(ck);}
 const set=BCK.get(ck);if(!set||!set.size){BCK.delete(ck);return;}
 const S1={p:[],n:[],c:[]},G1={p:[],n:[],c:[]},L1={p:[],n:[],c:[]};
 for(const k of set){
  const b=BLK.get(k);if(!b)continue;const d=BT[b.t],x=b.x,y=b.y,z=b.z,nz=.93+bHash(x,y,z)*.1;
  const o=d.glass?G1:d.glow?L1:S1;let col=d.c;
  if(d.door){const th=.07;let x0=x,x1=x+1,z0=z,z1=z+1;
   if(b.o%2===0){if(b.open){x1=x+.14;}else{z0=z+.5-th;z1=z+.5+th;}}else{if(b.open){z1=z+.14;}else{x0=x+.5-th;x1=x+.5+th;}}
   emitBox(o,x0,y,z0,x1,y+1,z1,col,0,nz);continue;}
  if(d.half){emitBox(o,x,y,z,x+1,y+.5,z+1,col,0,nz);continue;}
  let cull=0;
  if(occl(x+1,y,z,d))cull|=1;if(occl(x-1,y,z,d))cull|=2;if(occl(x,y+1,z,d))cull|=4;if(occl(x,y-1,z,d))cull|=8;if(occl(x,y,z+1,d))cull|=16;if(occl(x,y,z-1,d))cull|=32;
  if(b.t==='table'){emitBox(o,x,y,z,x+1,y+1,z+1,[.4,.27,.14],cull&~4,nz);if(!(cull&4))emitBox(o,x+.04,y+.999,z+.04,x+.96,y+1.001,z+.96,[.86,.7,.45],0,nz);continue;}
  emitBox(o,x,y,z,x+1,y+1,z+1,col,cull,nz);
 }
 const arr=[];
 for(const [o,m,sh] of [[S1,blkMat,true],[G1,glassMat,false],[L1,glowBMat,false]]){
  if(!o.p.length)continue;const g=new T.BufferGeometry();
  g.setAttribute('position',new T.Float32BufferAttribute(o.p,3));g.setAttribute('normal',new T.Float32BufferAttribute(o.n,3));g.setAttribute('color',new T.Float32BufferAttribute(o.c,3));
  const me=new T.Mesh(g,m);me.castShadow=sh;me.receiveShadow=sh;me.frustumCulled=false;scene.add(me);arr.push(me);
 }
 BMESH.set(ck,arr);
}
function flushBlocks(budget){let n=0;for(const ck of BDIRTY){rebuildBlockChunk(ck);BDIRTY.delete(ck);if(++n>=(budget||3))break;}}
/* ---- physics helpers ---- */
function topBlockUnder(x,z,yRef){
 if(!BLK.size)return -1e9;let best=-1e9;
 const lim=yRef+STEPC,y0=Math.floor(lim);
 for(const [ox,oz] of [[0,0],[.3,.3],[-.3,.3],[.3,-.3],[-.3,-.3]]){
  const ix=Math.floor(x+ox),iz=Math.floor(z+oz);
  for(let k=y0;k>=y0-5;k--){const b=BLK.get(ix+','+k+','+iz);if(b&&solidBlock(b)){const top=k+(BT[b.t].half?.5:1);if(top<=lim){if(top>best)best=top;break;}}}
 }
 return best;
}
function pushOutBlocks(P,r){
 if(!BLK.size)return;
 for(let k=Math.floor(P.y);k<=Math.floor(P.y+1.75);k++)for(let i=Math.floor(P.x-r);i<=Math.floor(P.x+r);i++)for(let j=Math.floor(P.z-r);j<=Math.floor(P.z+r);j++){
  const b=BLK.get(i+','+k+','+j);if(!b||!solidBlock(b))continue;
  const top=k+(BT[b.t].half?.5:1);if(top<=P.y+STEPC)continue;
  const cx=clamp(P.x,i,i+1),cz=clamp(P.z,j,j+1),dx=P.x-cx,dz=P.z-cz,d=Math.hypot(dx,dz);
  if(d<r){if(d>.001){P.x=cx+dx/d*r;P.z=cz+dz/d*r;}else{const l=P.x-i,rr=i+1-P.x,t=P.z-j,bb=j+1-P.z,m=Math.min(l,rr,t,bb);if(m===l)P.x=i-r;else if(m===rr)P.x=i+1+r;else if(m===t)P.z=j-r;else P.z=j+1+r;}}
 }
}
function headBump(P){
 if(!BLK.size||P.vy<=0)return;const hy=P.y+1.8;
 for(const [ox,oz] of [[0,0],[.3,.3],[-.3,.3],[.3,-.3],[-.3,-.3]]){
  const k=Math.floor(hy),b=BLK.get(Math.floor(P.x+ox)+','+k+','+Math.floor(P.z+oz));
  if(b&&solidBlock(b)&&hy>k-.01&&(!BT[b.t].half||hy<k+.5)){P.vy=0;P.y=k-1.8-.01;return;}
 }
}
function blockSolidAt(x,y,z){const b=BLK.get(Math.floor(x)+','+Math.floor(y)+','+Math.floor(z));return !!b&&solidBlock(b);}
function entBlockedByBlocks(x,z,y){if(!BLK.size)return false;for(const dy of [.2,1.1]){const b=BLK.get(Math.floor(x)+','+Math.floor(y+dy)+','+Math.floor(z));if(b&&solidBlock(b))return true;}return false;}
/* ---- aiming ---- */
const _rd=new T.Vector3();
let aim={hit:null,place:null,terr:false};
function aimBlock(){
 aim={hit:null,place:null,terr:false};
 camera.getWorldDirection(_rd);
 const ox=camera.position.x,oy=camera.position.y,oz=camera.position.z,ex=P.x,ey=P.y+1.5,ez=P.z;
 let pcx=null,pcy=0,pcz=0;
 for(let t=.4;t<18;t+=.1){
  const x=ox+_rd.x*t,y=oy+_rd.y*t,z=oz+_rd.z*t;
  const dx=x-ex,dy=y-ey,dz=z-ez;if(dx*dx+dy*dy+dz*dz>42)break;
  const cx=Math.floor(x),cy=Math.floor(y),cz=Math.floor(z);
  if(pcx!==null&&cx===pcx&&cy===pcy&&cz===pcz)continue;
  const b=BLK.get(cx+','+cy+','+cz);
  if(b&&(solidBlock(b)||BT[b.t].door)){aim.hit={x:cx,y:cy,z:cz,b};if(pcx!==null)aim.place={x:pcx,y:pcy,z:pcz};return aim;}
  if(!Cave.on&&y<P.y+4&&y<hAt(x,z)){aim.terr=true;aim.hit={x:cx,y:cy,z:cz,b:null};if(pcx!==null)aim.place={x:pcx,y:pcy,z:pcz};return aim;}
  if(Cave.on&&y<Cave.y){aim.terr=true;aim.hit={x:cx,y:cy,z:cz,b:null};if(pcx!==null)aim.place={x:pcx,y:pcy,z:pcz};return aim;}
  pcx=cx;pcy=cy;pcz=cz;
 }
 return aim;
}
const ghost=new T.LineSegments(new T.EdgesGeometry(new T.BoxGeometry(1.01,1.01,1.01)),new T.LineBasicMaterial({color:0xffffff}));ghost.visible=false;scene.add(ghost);
function updateGhost(){
 const id=curId(),it=ITEMS[id];
 if(!playing||!P||P.dead||P.swim||$('bag').classList.contains('on')){ghost.visible=false;return;}
 aimBlock();
 const blk=it&&it.type==='block';
 const c=blk?aim.place:(aim.hit&&aim.hit.b?aim.hit:null);
 if(!c){ghost.visible=false;return;}
 ghost.visible=true;ghost.position.set(c.x+.5,c.y+.5,c.z+.5);ghost.material.color.setHex(blk?0xffffff:0xffd54a);
}
/* ---- place / break ---- */
function cellOverlapsPlayer(x,y,z){return P.x+.35>x&&P.x-.35<x+1&&P.z+.35>z&&P.z-.35<z+1&&P.y+1.8>y&&P.y<y+1;}
function netBlock(x,y,z,b){Net.send({t:'build',p:{id:'b'+bk(x,y,z),b:1,x,y,z,k:b.t,o:b.o,open:b.open?1:0,top:b.top?1:0}});}
function placeBlock(id){
 const bt=BT[id];if(!bt)return;
 if(!has(id,1)){toast('ينقصك '+NAMES[id]);return;}
 aimBlock();const c=aim.place;
 if(!c){toast('وجّه المؤشر إلى مكان قريب');return;}
 if(BLK.has(bk(c.x,c.y,c.z))){return;}
 if(!Cave.on&&c.y<-2&&heightAt(c.x+.5,c.z+.5)<-1.5&&WT.liquid==='water'&&false){return;}
 const need=bt.door?2:1;
 if(cellOverlapsPlayer(c.x,c.y,c.z)||(bt.door&&(BLK.has(bk(c.x,c.y+1,c.z))||cellOverlapsPlayer(c.x,c.y+1,c.z)))){toast('لا يمكن الوضع هنا');return;}
 const o=Math.round(camYaw/(Math.PI/2))&3;
 setBlock(c.x,c.y,c.z,id,o,false,false);netBlock(c.x,c.y,c.z,BLK.get(bk(c.x,c.y,c.z)));
 if(bt.door){setBlock(c.x,c.y+1,c.z,id,o,false,true);netBlock(c.x,c.y+1,c.z,BLK.get(bk(c.x,c.y+1,c.z)));}
 take(id,1);beep(240,.07,'square',.05);P.swing=.5;refreshHud();
}
function breakBlockCell(c){
 const b=c.b;if(!b)return;
 const x=b.x,y=b.y,z=b.z,d=BT[b.t];
 if(d.door){const y0=b.top?y-1:y;for(const yy of[y0,y0+1]){delBlock(x,yy,z);Net.send({t:'unbuild',id:'b'+bk(x,yy,z)});}}
 else{delBlock(x,y,z);Net.send({t:'unbuild',id:'b'+bk(x,y,z)});}
 if(!creative)INV[b.t]=(INV[b.t]||0)+1;
 particles(x+.5,y+.5,z+.5,rgbHex(d.c),7);beep(180,.09,'square',.05);refreshHud();
}
const rgbHex=c=>(Math.round(c[0]*255)<<16)|(Math.round(c[1]*255)<<8)|Math.round(c[2]*255);
let digCnt=0;
function hitBlockUnderAim(it){
 aimBlock();const h=aim.hit;if(!h)return false;
 const dx=h.x+.5-P.x,dz=h.z+.5-P.z,dy=h.y+.5-(P.y+1);if(dx*dx+dy*dy+dz*dz>25)return false;
 if(h.b){
  const d=BT[h.b.t],kind=d.tool,tool=it.pick?'pick':(it.axe?'axe':'');
  let pw=(it.pow||1);if(kind&&tool===kind)pw*=2.2;else if(kind==='pick'&&!it.pick)pw*=.5;
  h.b.hp-=pw;P.swing=1;beep(300,.06,'triangle',.04);particles(h.x+.5,h.y+.5,h.z+.5,rgbHex(d.c),3);
  if(h.b.hp<=0)breakBlockCell(h);return true;
 }
 if(h.b===null&&aim.terr){
  P.swing=1;beep(160,.05,'triangle',.04);particles(h.x+.5,h.y+.5,h.z+.5,WTK==='desert'?0xe6d79c:0x6d4a2b,4);
  if(++digCnt>=3){digCnt=0;if(!creative){const k=WTK==='desert'?'sand':'dirt';INV[k]=(INV[k]||0)+1;toast('+1 '+NAMES[k]);refreshHud();}}
  return true;
 }
 return false;
}
function nearTable(){if(creative)return true;for(const k of TBL){const b=BLK.get(k);if(b&&Math.hypot(b.x+.5-P.x,b.z+.5-P.z)<4.6&&Math.abs(b.y-P.y)<3)return true;}return false;}
function toggleDoorBlock(b){
 const y0=b.top?b.y-1:b.y;const lo=BLK.get(bk(b.x,y0,b.z)),hi=BLK.get(bk(b.x,y0+1,b.z));if(!lo||!hi)return;
 const nv=!lo.open;lo.open=nv;hi.open=nv;markDirty(b.x,b.z);netBlock(b.x,y0,b.z,lo);netBlock(b.x,y0+1,b.z,hi);beep(nv?220:160,.1,'square',.05);
}
function nearBlockInteract(){
 let best=null,bd=3.4;
 if(aim.hit&&aim.hit.b&&(BT[aim.hit.b.t].door||BT[aim.hit.b.t].table)){const h=aim.hit;if(Math.hypot(h.x+.5-P.x,h.z+.5-P.z)<4.2)return h.b;}
 for(let i=Math.floor(P.x-3);i<=Math.floor(P.x+3);i++)for(let j=Math.floor(P.z-3);j<=Math.floor(P.z+3);j++)for(let k=Math.floor(P.y-1);k<=Math.floor(P.y+2);k++){
  const b=BLK.get(i+','+k+','+j);if(!b)continue;const d=BT[b.t];if(!d.door&&!d.table)continue;
  const dd=Math.hypot(i+.5-P.x,j+.5-P.z);if(dd<bd){bd=dd;best=b;}
 }
 return best;
}

function placeItem(id,it){
 if(it.type==='build'){
  for(const k in it.cost)if(!has(k,it.cost[k])){toast('ينقصك '+NAMES[k]);return;}
  const [fx,fz]=fwd();const px=P.x+fx*3.4,pz=P.z+fz*3.4;
  let x=Math.round(px/2)*2,z=Math.round(pz/2)*2;if(id==='fire'){x=px;z=pz;}
  let ry=Math.round(camYaw/(Math.PI/2))*(Math.PI/2);
  const h=hAt(x,z);if(h<0){toast('لا يمكن البناء في الماء');return;}
  const y=id==='wall'?h-.45:id==='floor'?h+.12:h;
  for(const k in it.cost)take(k,it.cost[k]);
  const d={id:Date.now()%1e9+pieceId++,type:id,x,y,z,ry};addPiece(d);Net.send({t:'build',p:d});beep(260,.08,'square');refreshHud();
 }else if(it.type==='spawn'){
  const [fx,fz]=fwd();spawnEnt(it.kind,P.x+fx*5,P.z+fz*5);toast('تمت الإضافة');
 }
}
function useItem(){
 if(!playing||P.dead||P.cool>0||P.swim)return;
 const id=curId(),it=ITEMS[id];
 if(!owns(id)){toast('اصنعه أولاً من قائمة الصناعة');return;}
 if(it.type==='melee'){P.cool=.42;P.swing=1;P.yaw=camYaw;meleeHit(it,id);}
 else if(it.type==='block'){P.cool=.25;placeBlock(id);}
 else if(it.type==='ranged'){if(!has(it.ammo,1)){toast('لا توجد ذخيرة، اصنعها');return;}take(it.ammo,1);P.cool=id==='gun'?.3:.65;P.swing=.6;P.yaw=camYaw;shoot(it,id);refreshHud();}
 else{P.cool=.3;placeItem(id,it);}
}
function eatItem(k){
 if(!playing||P.dead)return;
 const f0={meat:[35,8,'أكلت لحماً'],berry:[15,0,'أكلت توتاً']}[k];if(!f0)return;const f=[f0[0]*(1+pk('food')),f0[1],f0[2]];
 if(INV[k]>0){INV[k]--;P.food=Math.min(100,P.food+f[0]);P.hp=Math.min(100,P.hp+f[1]);toast(f[2]);beep(420,.08,'triangle');refreshHud();}
}
function eat(){
 if(!playing||P.dead)return;
 if(creative){toast('أنت في وضع الإبداع');return;}
 if(INV.meat>0)eatItem('meat');else if(INV.berry>0)eatItem('berry');else toast('لا يوجد طعام، اصطد حيواناً');
}
function craft(r){
 for(const k in r.cost)if(!has(k,r.cost[k]))return;
 for(const k in r.cost)take(k,r.cost[k]);
 if(r.tool)TOOLS[r.tool]=1;if(r.give)for(const k in r.give)INV[k]=(INV[k]||0)+r.give[k];
 toast('تم الصنع: '+r.n);beep(520,.12,'triangle');renderCraft();refreshHud();
}
function renderCraft(){
 const box=$('recs');box.innerHTML='';
 for(const r of RECIPES){
  const row=document.createElement('div');row.className='rec';
  const cost=Object.keys(r.cost).map(k=>r.cost[k]+' '+NAMES[k]+' ('+(creative?'∞':INV[k])+')').join('، ');
  const already=r.tool&&(TOOLS[r.tool]||creative);
  row.innerHTML='<div class="n"><b>'+r.n+'</b><div>'+cost+'</div></div>';
  const b=document.createElement('button');b.textContent=already?'تم':'صنع';
  b.disabled=!!already||!Object.keys(r.cost).every(k=>has(k,r.cost[k]))||(r.t&&!nearTable());if(r.t&&!nearTable())b.textContent='تحتاج طاولة';
  b.addEventListener('click',()=>craft(r));row.appendChild(b);box.appendChild(row);
 }
}

