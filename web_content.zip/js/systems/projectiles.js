/* Střely – letí za cílem a při zásahu udělují poškození
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';

  function hit(game, sh) {
    var A = BD.data.ammo, am = A && A[sh.am], vis = !!(am && am.impact && am.impact.sprite);       // vlastní tvar dopadu nahrazuje původní kruh
    function apply(e) {
      e.hp -= BD.systems.enemies.hurt(e, sh.dmg);
      if (sh.slow && !BD.systems.enemies.TYPES[e.type].slowImmune) { e.slow = Math.max(e.slow, sh.slow); e.slowT = 1.5; }
      if (e.hp <= 0 && e.alive) game.kill(e);
    }
    if (vis) game.fx.push({ kind: 'ammo', ph: 'impact', am: sh.am, x: sh.lx, y: sh.ly, aim: sh.ang || 0, t: 0, life: Math.max(0.05, am.impact.dur || 0.3) });
    if (sh.splash > 0) {
      if (!vis) game.fx.push({ kind: 'ring', x: sh.lx, y: sh.ly, t: 0, life: 0.3, r: sh.splash, color: sh.color });
      for (var i = 0; i < game.enemies.length; i++) {
        var e = game.enemies[i];
        if (e.alive && Math.hypot(e.x - sh.lx, e.y - sh.ly) <= sh.splash) apply(e);
      }
    } else if (sh.target.alive && (sh.flight !== 'straight' || Math.hypot(sh.target.x - sh.lx, sh.target.y - sh.ly) <= 0.8)) apply(sh.target);       // rovná střela může minout
  }

  function update(game, dt) {
    for (var i = 0; i < game.shots.length; i++) {
      var sh = game.shots[i];
      if (sh.target.alive && sh.flight !== 'straight') { sh.lx = sh.target.x; sh.ly = sh.target.y; }
      var dx = sh.lx - sh.x, dy = sh.ly - sh.y, d = Math.hypot(dx, dy), mv = sh.speed * dt;
      sh.age = (sh.age || 0) + dt;
      if (d <= mv + 0.05) { sh.done = true; hit(game, sh); }
      else {
        if (sh.trail) { var am = BD.data.ammo && BD.data.ammo[sh.am], tn = am && am.shot ? Math.ceil((am.shot.trail || 0) * 10) : 0;
          if (tn) { sh.trail.push({ x: sh.x, y: sh.y, a: sh.ang, l: sh.lift || 0 }); while (sh.trail.length > tn) sh.trail.shift(); } }
        sh.ang = Math.atan2(dy, dx); sh.x += dx / d * mv; sh.y += dy / d * mv;
        if (sh.flight === 'arc' && sh.d0 > 0) sh.lift = Math.sin(Math.PI * Math.min(1, Math.max(0, 1 - d / sh.d0))) * 0.3 * sh.d0;         // oblouk: jen vizuální výška
      }
    }
    game.shots = game.shots.filter(function (s) { return !s.done; });
  }

  BD.systems.projectiles = { update: update };
})(window.BD);
