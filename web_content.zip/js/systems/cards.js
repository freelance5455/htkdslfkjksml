/* Karty – efekty a padání. Čistá logika bez DOMu (jde testovat v Node).
   Hra drží game.cards (pole id, pořadí = pořadí v liště), game.rewards (smí padat karty), game.rnd (náhoda, pro testy jde nahradit).
   Použití: game.useCard(index)  →  efekt podle id; odměny: game.dropCard('boss' | 'perfect')
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  var METEOR_RADIUS = 1.25;          // v „věžích“ (× sub = buňky)
  var METEOR_FALL = 0.45;            // sekund letu

  function pathCells(game) {                          // buňky, kudy bubliny mohou jít (dosažitelné z cíle, uvnitř pole)
    var out = [];
    for (var y = 0; y < game.h; y++) for (var x = 0; x < game.w; x++) if (game.dist[game.idx(x, y)] > 0) out.push([x, y]);
    return out;
  }

  var EFFECTS = {
    /* všichni nepřátelé na mapě pryč (s odměnou jako při zabití); čekající vlny dál přijdou */
    atomic: function (game) {
      var cx = game.w / 2, cy = game.h / 2, R = Math.max(game.w, game.h);
      game.enemies.slice().forEach(function (e) { if (e.alive) game.kill(e, { noSplit: true }); });
      game.fx.push({ kind: 'flash', t: 0, life: 1.1, color: '#fff6dc' });
      for (var i = 0; i < 3; i++) game.fx.push({ kind: 'ring', x: cx, y: cy, t: -i * 0.12, life: 0.9, r: R * (0.8 + i * 0.25), color: '#ffcf6b' });
    },
    /* několik meteoritů na náhodná místa cesty; každý zničí nepřátele v dosahu (šéfa jen poškodí) */
    meteor: function (game) {
      var n = 8 + Math.floor(game.rnd() * 7), cells = pathCells(game), i;
      if (!cells.length) return;
      for (i = 0; i < n; i++) {
        var c = cells[Math.floor(game.rnd() * cells.length)];
        game.cardFx.push({ kind: 'meteor', x: c[0] + 0.5, y: c[1] + 0.5, delay: i * 0.22 + game.rnd() * 0.1, fall: METEOR_FALL, t: 0, hit: false });
      }
    },
  };

  /* pohyb efektů, které trvají (meteority) – volá se z game.step */
  function tick(game, dt) {
    var fx = game.cardFx; if (!fx.length) return;
    fx.forEach(function (m) {
      if (m.kind !== 'meteor') return;
      m.t += dt;
      if (!m.shown && m.t >= m.delay) { m.shown = true; game.fx.push({ kind: 'meteor', x: m.x, y: m.y, t: 0, life: m.fall }); }
      if (!m.hit && m.t >= m.delay + m.fall) {
        m.hit = true;
        var R = METEOR_RADIUS * game.sub;
        game.fx.push({ kind: 'ring', x: m.x, y: m.y, t: 0, life: 0.6, r: R, color: '#ff8a5c' });
        game.fx.push({ kind: 'pop', x: m.x, y: m.y, t: 0, life: 0.5, color: '#ffd08a', big: true });
        game.enemies.slice().forEach(function (e) {
          if (!e.alive || Math.hypot(e.x - m.x, e.y - m.y) > R) return;
          if (e.type === 'boss') { e.hp -= e.maxhp * 0.2; if (e.hp <= 0) game.kill(e); } else game.kill(e);
        });
      }
    });
    game.cardFx = fx.filter(function (m) { return !m.hit; });
  }

  /* odměna: vrátí id padlé karty, nebo null (nepadla / vypnuto) */
  function drop(game, source) {
    var D = BD.data.cards;
    if (!game.rewards) return null;
    var chance = D.drop[source] || 0;
    if (game.rnd() >= chance) return null;
    var id = D.order[Math.floor(game.rnd() * D.order.length)];
    game.cards.push(id); game.emit('card', id);
    return id;
  }
  function use(game, index) {
    if (game.gameOver || game.won) return null;
    var id = game.cards[index]; if (!id || !EFFECTS[id]) return null;
    game.cards.splice(index, 1);
    EFFECTS[id](game);
    game.emit('cardUsed', id);
    return id;
  }

  BD.systems.cards = { EFFECTS: EFFECTS, tick: tick, drop: drop, use: use, METEOR_RADIUS: METEOR_RADIUS };
})(window.BD);
