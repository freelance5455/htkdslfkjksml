'use strict';
/* ================= player ================= */
let playerChar=null,tod=.25,day=1,playing=false,spawn={x:0,z:0},camYaw=0,camPitch=.35,camUnder=false;
function newPlayer(){return {x:spawn.x,y:heightAt(spawn.x,spawn.z),z:spawn.z,vy:0,yaw:0,hp:100,food:100,air:100,swim:false,ground:true,fly:false,cool:0,swing:0,ph:0,mv:0,dead:false,last:0};}
function setPlayerSkin(){
 if(playerChar)scene.remove(playerChar.g);
 playerChar=makeChar(skinById(S.skin));decorChar(playerChar,S.skin,S.armor);scene.add(playerChar.g);refreshHeld();
}
function refreshHeld(){
 if(!playerChar)return;const h=playerChar.hold;while(h.children.length)h.remove(h.children[0]);
 const id=curId(),it=ITEMS[id];if(it&&(it.type==='melee'||it.type==='ranged')&&id!=='fist')h.add(heldMesh(id));
}
function findSpawn(){
 for(let r=0;r<400;r+=6)for(let a=0;a<12;a++){const x=Math.cos(a*.52)*r,z=Math.sin(a*.52)*r,h=heightAt(x,z);
  if(h>2&&h<9&&Math.abs(heightAt(x+4,z)-h)<2.5&&Math.abs(heightAt(x,z+4)-h)<2.5){return{x,z};}}
 return{x:0,z:0};
}
function initWorld(room,mode,wt){
 if(Cave.on){scene.remove(Cave.cur.shell);if(Cave.cur.pm)scene.remove(Cave.cur.pm);if(Cave.cur.lm)scene.remove(Cave.cur.lm);Cave.on=false;caveEnv(false);caveLight.intensity=0;}
 setWorldType(wt||'forest');
 SEED=(hashStr(room||'')%90000)+7;
 clearWorld();
 for(const e of ents.slice())removeEnt(e);for(const p of projs)scene.remove(p.m);projs.length=0;for(const b of built)scene.remove(b.mesh);built.length=0;clearBlocks();
 spawn=findSpawn();P=newPlayer();P.caveCd=0;resetInv();slotIdx=0;
 creative=mode==='creative';document.body.classList.toggle('creative',creative);HOT=(creative?HOT_C:HOT_S).slice();
 tod=.25;day=1;
 updateChunks(P.x,P.z,99);setPlayerSkin();world.ready=true;buildHot();refreshHud();
}

