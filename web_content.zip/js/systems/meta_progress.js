'use strict';
/* ================= gems_meta: season daily streak achievements tutorial events ================= */
const monthKey=()=>dayKey().slice(0,7);
const XPT={zombie:4,hunt:3,crystal:5,trade:3,wood:1,play:1,boss:25,build:.3,spin:5,daily:10};
const CHPOOL=[{id:'zombie',need:10,n:'اقتل 10 زومبي'},{id:'hunt',need:8,n:'اصطد 8 حيوانات'},{id:'crystal',need:6,n:'اجمع 6 بلورات'},{id:'wood',need:40,n:'اقطع 40 خشبة'},{id:'trade',need:4,n:'أتمّ 4 صفقات مع القرويين'},{id:'build',need:25,n:'ضع 25 كتلة'}];
const SEASON_SK=['s_frost','s_ember','s_jungle','s_neon'],WK_SK=['w_sniper','w_pharaoh','w_giant','w_ghost','w_diver','w_viking'];
const seasonSkin=()=>SEASON_SK[(+monthKey().slice(5,7)-1)%4];
const wkSkinId=()=>WK_SK[(parseInt(weekKey().split('W')[1])||0)%6];
function mkChallenge(d){const c=CHPOOL[hashStr(d)%CHPOOL.length];return {d,id:c.id,need:c.need,n:c.n,prog:0,done:0,cl:0};}
function M(){
 const m=S.meta=S.meta||{};m.cnt=m.cnt||{};m.ach=m.ach||[];m.evt=m.evt||[];
 const mk=monthKey();if(!m.season||m.season.k!==mk)m.season={k:mk,xp:0,cl:[]};
 const d=dayKey();if(!m.ch||m.ch.d!==d)m.ch=mkChallenge(d);
 if(!m.streak)m.streak={n:0,last:'',cl:'',best:0};
 return m;
}
let metaDirty=0;setInterval(()=>{if(metaDirty){metaDirty=0;try{save();}catch(e){}}},5000);
const sLvl=()=>Math.min(20,Math.floor(M().season.xp/100));
function addXP(n){if(!S.name||!(n>0))return;{const bb=BOOST();if(bb&&bb.xpX>1)n=Math.round(n*bb.xpX);if(isVip())n=Math.round(n*1.25);}const m=M(),a=sLvl();m.season.xp+=n;const b=sLvl();metaDirty=1;if(b>a){toast('ارتفع مستوى الموسم إلى '+b+'!');cloud.event('season','L'+b);sfx('coin');}}
function metaEv(id,n){
 if(!S.name||typeof creative!=='undefined'&&creative)return;n=n||1;const m=M();
 m.cnt[id]=(m.cnt[id]||0)+n;const x=XPT[id];if(x)addXP(x*n);
 const c=m.ch;if(c.id===id&&!c.done){c.prog=Math.min(c.need,c.prog+n);if(c.prog>=c.need){c.done=1;toast('اكتمل التحدي اليومي! استلم جائزته من «الأنشطة»');sfx('coin');}}
 metaDirty=1;
}
function ensureStreak(){
 if(!S.name)return;const m=M(),st=m.streak,t=dayKey();if(st.last===t)return;
 const y=dayKey(new Date(Date.now()-864e5));st.n=(st.last===y)?st.n+1:1;st.last=t;st.best=Math.max(st.best||0,st.n);m.cnt.days=(m.cnt.days||0)+1;save();
}
function claimStreak(){const st=M().streak,t=dayKey();if(st.cl===t){say('استلمت جائزة اليوم');return;}st.cl=t;const c=10*Math.min(st.n,10);S.coins+=c;let tx='+'+c+' عملة';if(st.n%7===0){addGems(1);tx+=' و جوهرة';}save();cloud.push();sfx('coin');say(tx);cloud.event('streak','d'+st.n);refreshHud();renderHub();}
function claimChallenge(){const c=M().ch;if(!c.done||c.cl)return;c.cl=1;S.coins+=40;addGems(1);addXP(25);save();cloud.push();sfx('coin');say('+40 عملة و جوهرة');cloud.event('challenge',c.id);refreshHud();renderHub();}
const SLV=L=>({c:40+L*20,g:L===5?2:L===10?3:L===15?4:L===20?8:0,sk:L===20});
function claimLevel(L){const m=M();if(sLvl()<L||m.season.cl.includes(L))return;const r=SLV(L);m.season.cl.push(L);S.coins+=r.c;if(r.g)addGems(r.g);if(r.sk){const id=seasonSkin();if(!S.owned.includes(id))S.owned.push(id);}save();cloud.push();sfx('coin');say('+'+r.c+' عملة'+(r.g?' و'+r.g+' جواهر':'')+(r.sk?' وشخصية الموسم!':''));cloud.event('seasonclaim','L'+L);refreshHud();renderHub();}
const ACH=[
 {id:'z10',n:'قاتل مبتدئ',k:'zombie',need:10,c:50,g:0},{id:'z100',n:'صائد الزومبي',k:'zombie',need:100,c:200,g:1},{id:'z500',n:'سيد المعارك',k:'zombie',need:500,c:800,g:3},
 {id:'h30',n:'صيّاد ماهر',k:'hunt',need:30,c:80,g:0},{id:'w300',n:'حطّاب',k:'wood',need:300,c:60,g:0},{id:'c25',n:'منقّب البلورات',k:'crystal',need:25,c:100,g:1},
 {id:'b1',n:'قاهر الزعماء',k:'boss',need:1,c:150,g:2},{id:'b5',n:'ملك الزعماء',k:'boss',need:5,c:500,g:5},
 {id:'bd150',n:'بنّاء',k:'build',need:150,c:80,g:0},{id:'sp10',n:'محظوظ',k:'spin',need:10,c:100,g:1},
 {id:'st7',n:'مواظب 7 أيام',k:'streakBest',need:7,c:150,g:2},{id:'dy10',n:'لاعب وفيّ',k:'days',need:10,c:150,g:1},{id:'sk5',n:'جامع الشخصيات',k:'skins',need:5,c:200,g:2}
];
const achVal=k=>k==='streakBest'?(M().streak.best||0):k==='skins'?S.owned.length:k==='petsN'?W().pets.own.length:k==='legN'?W().leg.length:(M().cnt[k]||0);
const achClaimed=()=>S.meta&&S.meta.ach?S.meta.ach.length:0;
function claimAch(id){const a=ACH.find(x=>x.id===id),m=M();if(!a||m.ach.includes(id)||achVal(a.k)<a.need)return;m.ach.push(id);S.coins+=a.c;if(a.g)addGems(a.g);save();cloud.push();sfx('coin');say('إنجاز: '+a.n);cloud.event('ach',a.id);refreshHud();renderHub();}
/* events broadcast by the owner */
function curEvt(){try{const d=JSON.parse(localStorage.getItem('ard_evt')||'null');if(d&&d.until>Date.now())return d;}catch(e){}return null;}
function gotEvt(d){if(!d||!d.id||!(d.until>Date.now()))return;try{localStorage.setItem('ard_evt',JSON.stringify(d));}catch(e){}if(S.name){toast('إعلان جديد: '+String(d.title||'').slice(0,40));}renderEvtBox();}
function renderEvtBox(){
 const b=$('evtBox');if(!b)return;const d=curEvt();if(!d){b.innerHTML='';return;}
 const rw=(+d.coins>0||+d.gems>0),done=S.name&&M().evt.includes(d.id);
 b.innerHTML='<div class="warn" style="background:rgba(255,200,60,.14);border-color:var(--gold)"><b>'+esc2(d.title)+'</b><div style="margin:4px 0">'+esc2(d.msg)+'</div>'+(rw&&!done?'<button class="big alt3" id="evtGo" style="margin:4px 0 0;padding:7px;font-size:14px">استلم: '+(d.coins?d.coins+' عملة':'')+(d.coins&&d.gems?' و':'')+(d.gems?d.gems+' جوهرة':'')+'</button>':'')+(rw&&done?'<div class="note">تم الاستلام ✓</div>':'')+'</div>';
 const g=$('evtGo');if(g)g.onclick=()=>{const m=M();if(m.evt.includes(d.id))return;m.evt.push(d.id);if(m.evt.length>20)m.evt.shift();S.coins+=Math.min(1e5,Math.floor(+d.coins||0));addGems(Math.min(1e3,Math.floor(+d.gems||0)));save();cloud.push();sfx('coin');cloud.event('evtclaim',String(d.title||'').slice(0,30));refreshHud();renderEvtBox();$('homeCoins').textContent=S.coins;};
}
const esc2=t=>String(t==null?'':t).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
/* hub UI */
let hubTab='season';
function barHtml(p){return '<div style="height:12px;border-radius:8px;background:rgba(255,255,255,.1);overflow:hidden"><div style="height:100%;width:'+Math.round(Math.max(0,Math.min(1,p))*100)+'%;background:linear-gradient(90deg,#63f0b8,#2f7dff)"></div></div>';}
function renderHub(){
 const body=$('hubBody');if(!body)return;const m=M();for(const x of document.querySelectorAll('.hubT'))x.classList.toggle('on',x.dataset.h===hubTab);
 let h='';
 if(hubTab==='season'){
  const xp=Math.floor(m.season.xp),L=sLvl(),sk=SKINS.find(k=>k.id===seasonSkin());
  h+='<div class="hd"><span>موسم '+m.season.k+'</span><span class="coinTag">المستوى '+L+'/20</span></div>'+barHtml((xp%100)/100)+'<div class="note">'+(L>=20?'اكتمل الموسم':(xp%100)+' / 100 نقطة للمستوى التالي')+' — تكسب النقاط من القتال والمهام والتحدي واللعب. جائزة المستوى 20: شخصية «'+(sk?sk.n:'')+'» الحصرية.</div>';
  for(let i=1;i<=20;i++){const r=SLV(i),done=m.season.cl.includes(i),ok=L>=i;h+='<div class="frow"><b>مستوى '+i+'</b><small>'+r.c+' عملة'+(r.g?' + '+r.g+' جوهرة':'')+(r.sk?' + شخصية':'')+'</small><button class="'+(ok&&!done?'ok':'')+'" data-lv="'+i+'" '+(ok&&!done?'':'disabled')+'>'+(done?'✓':ok?'استلم':'🔒')+'</button></div>';}
 }else if(hubTab==='daily'){
  const c=m.ch,st=m.streak,t=dayKey();
  h+='<div class="hd"><span>التحدي اليومي (نفسه لكل اللاعبين)</span></div><div class="frow"><b>'+c.n+'</b><small>'+c.prog+'/'+c.need+'</small><button class="'+(c.done&&!c.cl?'ok':'')+'" id="chGo" '+(c.done&&!c.cl?'':'disabled')+'>'+(c.cl?'✓':c.done?'استلم':'جارٍ')+'</button></div><div class="note">الجائزة: 40 عملة + جوهرة + نقاط موسم.</div>'+barHtml(c.prog/c.need);
  h+='<div class="hd"><span>سلسلة الأيام المتتالية</span><span class="coinTag">'+st.n+' يوم (الأفضل '+(st.best||0)+')</span></div><div class="frow"><b>جائزة اليوم</b><small>'+10*Math.min(st.n,10)+' عملة'+(st.n%7===0?' + جوهرة':'')+'</small><button class="'+(st.cl!==t?'ok':'')+'" id="stGo" '+(st.cl!==t?'':'disabled')+'>'+(st.cl===t?'✓':'استلم')+'</button></div><div class="note">إن فاتك يوم تنقطع السلسلة وتبدأ من 1. كل 7 أيام متتالية: جوهرة.</div>';
 }else if(hubTab==='ach'){
  h+='<div class="hd"><span>الإنجازات</span><span class="coinTag">★ '+m.ach.length+'/'+ACH.length+'</span></div>';
  for(const a of ACH){const v=Math.min(a.need,achVal(a.k)),done=m.ach.includes(a.id),ok=v>=a.need;h+='<div class="frow"><b>'+a.n+'</b><small>'+v+'/'+a.need+' · '+a.c+' عملة'+(a.g?' + '+a.g+' جوهرة':'')+'</small><button class="'+(ok&&!done?'ok':'')+'" data-ac="'+a.id+'" '+(ok&&!done?'':'disabled')+'>'+(done?'★':ok?'استلم':'…')+'</button></div>';}
 }else{
  const sent=m.starterSent,wk=SKINS.find(k=>k.id===wkSkinId());
  h+='<div class="hd"><span>عروض خاصة</span></div>';
  {const vl=isVip()?Math.ceil((m.vip-Date.now())/864e5):0,vd=m.vipDay===dayKey();
   h+='<div class="frow" style="border-color:var(--gold)"><b>👑 VIP</b><small>'+(vl?'فعّال: باقي '+vl+' يوم':'عملات +25% · خبرة +25% · جوهرة يومية')+' · 12 DT/شهر</small><button class="'+(vl?'':'ok')+'" id="ofVip">'+(vl?'تمديد':'اطلب')+'</button></div>';
   if(vl)h+='<div class="frow"><b>جوهرة VIP اليومية</b><small>'+(vd?'استلمتها اليوم':'جاهزة')+'</small><button class="'+(vd?'':'ok')+'" id="vipDay" '+(vd?'disabled':'')+'>'+(vd?'✓':'استلم')+'</button></div>';}
  h+='<div class="frow"><b>حزمة المبتدئ</b><small>3000 عملة + 30 جوهرة بـ 3 DT'+(sent?' (تم الطلب)':'')+'</small><button class="'+(sent?'':'ok')+'" id="ofStarter" '+(sent?'disabled':'')+'>'+(sent?'✓':'اطلب')+'</button></div>';
  h+='<div class="frow"><b>عرض الجمعة</b><small>'+(isFri()?'اليوم! جواهر مضاعفة في الشحن':'كل جمعة: جواهر مضاعفة عند شحن الجواهر')+'</small><button id="ofFri">الشحن</button></div>';
  h+='<div class="frow"><b>شخصية الأسبوع: '+(wk?wk.n:'')+'</b><small>'+(S.owned.includes(wkSkinId())?'تملكها':'45 جوهرة — تختفي نهاية الأسبوع')+'</small><button id="ofSkin">المتجر</button></div>';
  const e=curEvt();h+='<div class="note" style="margin-top:8px">'+(e?'إعلان نشط: '+esc2(e.title):'لا إعلانات نشطة الآن. يعلن المالك عن أحداث وهدايا عامة هنا وفي الصفحة الرئيسية.')+'</div>';
 }
 body.innerHTML=h;
 for(const b of body.querySelectorAll('[data-lv]'))b.onclick=()=>claimLevel(+b.dataset.lv);
 for(const b of body.querySelectorAll('[data-ac]'))b.onclick=()=>claimAch(b.dataset.ac);
 const q=id=>document.getElementById(id);
 if(q('chGo'))q('chGo').onclick=claimChallenge;if(q('stGo'))q('stGo').onclick=claimStreak;
if(q('ofVip'))q('ofVip').onclick=()=>{packKind='offer';packSel=1;view('vRecharge');};
 if(q('vipDay'))q('vipDay').onclick=()=>{const mm=M();if(!isVip()||mm.vipDay===dayKey())return;mm.vipDay=dayKey();addGems(1);save();cloud.push();sfx('coin');toast('+1 جوهرة VIP');refreshHud();renderHub();};
 if(q('ofStarter'))q('ofStarter').onclick=()=>{packKind='offer';packSel=0;view('vRecharge');};
 if(q('ofFri'))q('ofFri').onclick=()=>{packKind='gems';view('vRecharge');};
 if(q('ofSkin'))q('ofSkin').onclick=()=>{shTab='chars';view('vShop');};
}
/* tutorial */
const TUT=[['الحركة','اسحب بإصبعك على الجهة اليسرى للحركة، وعلى اليمنى للنظر. زر السهم للقفز، وزر «جري» للسرعة.'],['القتال والجمع','اضغط زر الهجوم لضرب الأعداء وقطع الأشجار وكسر الكتل وجمع الموارد.'],['الصناعة والبناء','زر «صنع» لصناعة الأدوات، والحقيبة لنقل الكتل إلى الشريط السفلي ثم تضعها بالضغط على الهجوم.'],['العملات والجواهر','العملات من القتال والمهام والتجارة. الجواهر نادرة: المسار الأسبوعي (الأحد) والصناديق والعجلة.'],['الأنشطة','من القائمة الرئيسية افتح «الأنشطة»: موسم شهري، تحدٍّ يومي، إنجازات وعروض. بالتوفيق!']];
let tutI=0;
function showTut(){tutI=0;$('tut').style.display='flex';drawTut();}
function drawTut(){const t=TUT[tutI];$('tutT').textContent=t[0];$('tutB').textContent=t[1];$('tutD').textContent=(tutI+1)+' / '+TUT.length;$('tutNext').textContent=tutI===TUT.length-1?'ابدأ':'التالي';}
function endTut(){$('tut').style.display='none';M().tut=1;save();}
$('tutNext').addEventListener('click',()=>{if(tutI>=TUT.length-1){endTut();return;}tutI++;drawTut();});
$('tutSkip').addEventListener('click',endTut);
function renderHome(){
 const g=giftState();$('chest').textContent=g.can?('افتح صندوق اليوم (اليوم '+((g.n%28)+1)+' من 28)'):'تم استلام صندوق اليوم. عد غداً';
 $('chest').style.opacity=g.can?1:.6;renderQuests();renderWk7();$('hubSmall').textContent='موسم · تحدٍّ · إنجازات';$('homeGems').textContent='جواهرك: '+(S.gems|0);$('wheelPrice').textContent='اللفة: '+wheelPrice()+' عملة';$('tokBox').textContent=S.token||'';
}
/* ---- 3D preview ---- */
const pv={on:false,r:null,s:null,c:null,ch:null,t:0,id:null};
function initPreview(){
 if(pv.r)return;
 try{
  pv.r=new T.WebGLRenderer({canvas:$('pvCanvas'),antialias:true,alpha:true});pv.r.setSize(360,360,false);
  pv.s=new T.Scene();pv.c=new T.PerspectiveCamera(35,1,.1,50);pv.c.position.set(0,1.5,6.2);pv.c.lookAt(0,1.3,0);
  pv.s.add(new T.HemisphereLight(0xffffff,0x556677,.95));const d=new T.DirectionalLight(0xffffff,.8);d.position.set(3,5,4);pv.s.add(d);
 }catch(e){pv.r=null;}
}
function setPreview(skinId,armor){
 if(!pv.r)return;if(pv.ch)pv.s.remove(pv.ch.g);
 pv.ch=makeChar(skinById(skinId));decorChar(pv.ch,skinId,armor||'');pv.s.add(pv.ch.g);
}
function renderPreview(dt){if(!pv.r||!pv.on||!pv.ch)return;pv.t+=dt;pv.ch.g.rotation.y=pv.t*.9;animAura(pv.ch,pv.t);pv.r.render(pv.s,pv.c);}
/* ---- shop ---- */
const hex=n=>'#'+('000000'+n.toString(16)).slice(-6);
function shopItems(){const k=saleK();const a=shopItems0();if(k>=1)return a;return a.map(i=>i.own?i:Object.assign({},i,{p:i.p?Math.max(1,Math.round(i.p*k)):0,g:i.g?Math.max(1,Math.ceil(i.g*k)):0,was:1}));}
function shopItems0(){
 if(shTab==='chars')return SKINS.filter(k=>{const o=S.owned.includes(k.id);return (!k.secret||o)&&(!k.sea||o)&&(!k.wk||o||wkSkinId()===k.id);}).map(k=>({id:k.id,n:k.n,p:k.p,own:S.owned.includes(k.id),on:S.skin===k.id,ab:k.ab,g:k.g||0,cols:[k.body,k.pants,k.hatC||k.skin]}));
 if(shTab==='weap')return Object.keys(WEAPS).filter(id=>!WEAPS[id].leg).map(id=>({id,n:WEAPS[id].n,p:WEAPS[id].p,own:(S.stock||[]).includes(id),on:false,ab:WEAPS[id].ranged?'سهام تنفجر وتؤذي من حولها':'ضرر '+WEAPS[id].dmg+(WEAPS[id].burn?' + حرق':''),cols:[WEAPS[id].col||0xaa7733]}));
 return Object.keys(ARMORS).map(id=>({id,n:ARMORS[id].n,p:ARMORS[id].p,own:(S.armors||[]).includes(id),on:S.armor===id,ab:'يقلل الضرر '+Math.round(ARMORS[id].red*100)+'%',cols:[ARMORS[id].c]}));
}
function renderShop(){
 const box=$('skins');box.innerHTML='';const items=shopItems();
 if(!shSel||!items.some(i=>i.id===shSel))shSel=(items.find(i=>i.on)||items[0]).id;
 for(const it of items){
  const b=document.createElement('button');b.className='skin'+(shSel===it.id?' sel':'');
  b.innerHTML='<div class="sw">'+it.cols.map(c=>'<i style="background:'+hex(c)+'"></i>').join('')+'</div><b>'+it.n+'</b><span>'+(it.on?'مختارة':it.own?'ملكك':it.g?'شراء '+it.g+' جوهرة':'شراء '+it.p)+'</span>';
  b.addEventListener('click',()=>{shSel=it.id;renderShop();});box.appendChild(b);
 }
 const cur=items.find(i=>i.id===shSel);
 $('menuCoins').textContent='العملات: '+S.coins+' · الجواهر: '+(S.gems|0);
 $('pvName').textContent=cur.n;$('pvAb').textContent=cur.ab||'';
 const a=shTab==='armor'?shSel:S.armor||'',sk=shTab==='chars'?shSel:S.skin;
 if(pv.id!==sk+'|'+a){pv.id=sk+'|'+a;setPreview(sk,a);}
 $('shopAct').textContent=cur.on?(shTab==='armor'?'إزالة الدرع':'مختارة'):cur.own?(shTab==='weap'?'مملوك':'اختيار'):(cur.g?'شراء '+cur.g+' جوهرة':'شراء '+cur.p);
 $('secretRow').style.display=shTab==='chars'?'flex':'none';
 for(const x of document.querySelectorAll('.shTab'))x.classList.toggle('on',x.dataset.sh===shTab);
}
$('shopAct').addEventListener('click',()=>{
 const cur=shopItems().find(i=>i.id===shSel);if(!cur)return;
 if(!cur.own){
  if(cur.g){if((S.gems|0)<cur.g){say('تحتاج '+(cur.g-(S.gems|0))+' جوهرة إضافية.');return;}S.gems-=cur.g;}
  else{if(S.coins<cur.p){say('تحتاج '+(cur.p-S.coins)+' عملة إضافية. اجمعها بالقتال والمهام أو اشحن رصيدك.');return;}S.coins-=cur.p;}
  beep(660,.15,'triangle');cloud.event('buy',cur.id);
  if(shTab==='chars'){S.owned.push(cur.id);S.skin=cur.id;}
  else if(shTab==='weap'){S.stock=(S.stock||[]).concat(cur.id);}
  else{S.armors=(S.armors||[]).concat(cur.id);S.armor=cur.id;}
 }else if(shTab==='chars')S.skin=cur.id;
 else if(shTab==='armor')S.armor=cur.on?'':cur.id;
 save();cloud.push();pv.id=null;renderShop();setPlayerSkin();
});
for(const b of document.querySelectorAll('.shTab'))b.addEventListener('click',()=>{shTab=b.dataset.sh;shSel=null;pv.id=null;renderShop();});
$('secretGo').addEventListener('click',async()=>{
 const ok=await checkSecret($('secret').value);
 if(ok){if(!S.owned.includes('phoenix'))S.owned.push('phoenix');S.skin='phoenix';save();cloud.push();cloud.event('secret','phoenix');cloud.status('online');shTab='chars';shSel='phoenix';pv.id=null;renderShop();setPlayerSkin();say('تم فتح الشخصية السرية: العنقاء!');beep(900,.3,'triangle',.07);}
 else{say('الرمز غير صحيح');cloud.event('secret_fail','');}
 $('secret').value='';
});
$('chest').addEventListener('click',()=>{
 const r=claimGift();if(!r){say('استلمت صندوق اليوم. عد غداً!');return;}
 say('صندوق اليوم: +'+r.n+' عملة (سلسلة '+r.streak+' يوم)'+r.extra);renderHome();$('homeCoins').textContent=S.coins;
});
function renderRecent(){
 const box=$('recent');box.innerHTML='';
 if(!S.recent.length){box.style.display='none';return;}
 box.style.display='flex';
 for(const r of S.recent){
  const b=document.createElement('button');b.className='chip';b.textContent=r.name+' · '+r.code;
  b.addEventListener('click',()=>{$('rname').value=r.name;$('rcode').value=r.code;setTab(r.kind||'j');});
  box.appendChild(b);
 }
}
function pushRecent(name,code,kind){
 S.recent=S.recent.filter(r=>!(r.name===name&&r.code===code));S.recent.unshift({name,code,kind});S.recent=S.recent.slice(0,5);save();
}
function showMenu(on,vw){
 $('menu').style.display=on?'flex':'none';
 playing=!on&&world.started;
 $('hud').classList.toggle('on',!on);
 if(on){$('craft').classList.remove('on');$('bag').classList.remove('on');$('trade').classList.remove('on');try{snapshot();save();}catch(e){}}
 for(const id of['bAtk','bJump','bEat','bCraft','bRun'])$(id).style.display=on?'none':'grid';
 if(on){$('bTalk').style.display='none';$('bUse').style.display='none';for(const id of['bFly','bDown','bTime'])$(id).style.display='none';setSwimUI(false);view(vw||(S.name?'vHome':(world.started?'vLogin':'vTitle')));}
 else{$('bEat').style.display=creative?'none':'grid';for(const id of['bFly','bDown','bTime'])$(id).style.display=creative?'grid':'none';setSwimUI(!!(P&&P.swim));}
}
function launch(o){
 world.room=o.room;world.wt=o.wt||'forest';world.mode=o.mode;
 initWorld(o.room,o.mode,o.wt||'forest');
 if(o.joined){for(const b of o.joined.builds||[])addPiece(b);setOthers(o.joined.players||[]);tod=o.joined.tod||tod;day=o.joined.day||day;}
 else if(!o.online)restoreSnapshot();
 grantStock();buildHot();
 document.body.classList.toggle('big',!!WT.big);if(WT.big)cloud.event('mode_big',WTK);world.started=true;ensureQuests();cloud.status('online');cloud.event('start',(o.online?'online ':'offline ')+world.wt+' '+o.mode);
 $('bChat').style.display=o.online?'grid':'none';$('chat').classList.toggle('on',!!o.online);
 $('onlineV').textContent=o.online?(Net.others.size+1)+' لاعب':'أنت';
 const rt=$('roomTag');if(o.online){rt.textContent='الغرفة: '+Net.room+'  |  الرمز: '+Net.code;rt.style.display='block';}else rt.style.display='none';
 showMenu(false);
 try{if(document.documentElement.requestFullscreen&&!document.fullscreenElement)document.documentElement.requestFullscreen().then(()=>{try{screen.orientation.lock('landscape').catch(()=>{});}catch(e){}}).catch(()=>{});}catch(e){}
 toast(creative?'وضع الإبداع: اضغط "طيران" لتحلّق':'احمِ نفسك قبل حلول الليل!');
}
let busy=false;
async function enterRoom(kind,name,code,mode,wt){
 if(busy)return;busy=true;say(kind==='c'?'جارٍ إنشاء الغرفة…':'جارٍ البحث عن الغرفة…');
 try{
  if(kind==='c'){await hostRoom(name,code,mode||'survival',wt||'forest');pushRecent(name,code,'c');launch({room:name,mode:mode||'survival',wt:wt||'forest',online:true});}
  else{const m=await joinRoom(name,code);pushRecent(name,code,'j');launch({room:m.seed,mode:m.mode,wt:m.wt||'forest',online:true,joined:m});}
  say('');
 }catch(e){const t=e&&e.message||NONET;say(t);toast(t);}
 busy=false;
}
function setTab(k){
 tab=k;for(const x of document.querySelectorAll('.tabBtn'))x.classList.toggle('on',x.dataset.tab===k);
 $('createOpts').style.display=k==='c'?'flex':'none';$('goOn').textContent=k==='c'?'أنشئ الغرفة':'ادخل الغرفة';
 $('onNote').textContent=k==='c'?'شارك اسم الغرفة والرمز مع أصدقائك ليدخلوا معك. صاحب الغرفة يجب أن يبقى داخل اللعبة.':'اكتب اسم الغرفة والرمز اللذين أعطاك إياهما صاحب الغرفة.';
 say('');
}
function renderAccList(){
 const names=Object.keys(DB.accounts||{}),box=$('accBox'),l=$('accList');l.innerHTML='';box.style.display=names.length?'block':'none';
 for(const n of names){const b=document.createElement('button');b.className='mode alt1';b.innerHTML='<b></b><small>'+(DB.accounts[n].coins|0)+' عملة</small>';b.firstChild.textContent=n;b.addEventListener('click',()=>{loadAcc(n);afterLogin();});l.appendChild(b);}
}
function afterLogin(){Pres.start();cloud.listen();cloud.status('online');cloud.event('login','');if(S.tamper){cloud.event('coin_tamper','checksum mismatch');S.tamper=false;}ensureStreak();view('vHome');setTimeout(()=>{if(!M().tut)showTut();},500);}
$('goLogin').addEventListener('click',()=>{const n=$('uname').value.trim().slice(0,14);if(!n){say('اكتب اسمك أولاً');return;}if(DB.accounts[n]){say('هذا الاسم موجود على الجهاز. اختر حسابك من القائمة أو اكتب اسماً آخر');return;}loadAcc(n);S.consent=$('consent').checked;save();afterLogin();cloud.event('register',n);});
$('uname').addEventListener('keydown',e=>{if(e.key==='Enter')$('goLogin').click();});
$('goRestore').addEventListener('click',async()=>{say('جارٍ البحث…');const r=await restoreByToken($('rtok').value);if(r.ok){afterLogin();toast('تم استرجاع حسابك');}else say(r.err);});
$('copyTok').addEventListener('click',()=>{try{navigator.clipboard.writeText(S.token).then(()=>toast('تم نسخ الرمز'),()=>toast(S.token));}catch(e){toast(S.token);}});
$('logout').addEventListener('click',()=>{cloud.status('offline');cloud.unlisten();Pres.stop();Net.close();S.name='';DB.last='';saveDB();world.started=false;initWorld('عالمي','survival','forest');view('vLogin');});
$('startBtn').addEventListener('click',()=>{sfx('coin');cloud.status('offline');cloud.unlisten();Pres.stop();Net.close();S.name='';const last=DB.last&&DB.accounts&&DB.accounts[DB.last]?DB.last:'';if(last){loadAcc(last);afterLogin();return;}renderAccList();view('vLogin');});
$('toOff').addEventListener('click',()=>{view('vOff');$('world').value=$('world').value||'عالمي';});
$('toOn').addEventListener('click',()=>{view('vOn');if(!$('rcode').value)$('rcode').value=String(Math.floor(1000+Math.random()*9000));});
$('toFr').addEventListener('click',()=>view('vFriends'));
$('toShop').addEventListener('click',()=>view('vShop'));
$('toRecharge').addEventListener('click',()=>view('vRecharge'));
for(const b of document.querySelectorAll('.hpT'))b.addEventListener('click',()=>{for(const x of document.querySelectorAll('.hpT'))x.classList.toggle('on',x===b);for(const x of document.querySelectorAll('.hp'))x.classList.toggle('on',x.dataset.p===b.dataset.p);});
$('toHub').addEventListener('click',()=>{hubTab='season';view('vHub');});for(const b of document.querySelectorAll('.hubT'))b.addEventListener('click',()=>{hubTab=b.dataset.h;renderHub();});
$('toWheel').addEventListener('click',()=>view('vWheel'));$('toChests').addEventListener('click',()=>view('vChests'));$('spinBtn').addEventListener('click',spinWheel);
for(const b of document.querySelectorAll('.pkTab'))b.addEventListener('click',()=>{packKind=b.dataset.pk;packSel=Math.min(packSel,curPacks().length-1);renderPacks();});
$('banOk').addEventListener('click',()=>{S.banned=0;view('vTitle');});
$('oSend').addEventListener('click',sendOrder);
$('resume').addEventListener('click',()=>showMenu(false));
$('leave').addEventListener('click',()=>{Net.close();world.started=false;initWorld('عالمي','survival','forest');$('roomTag').style.display='none';view('vHome');toast('غادرت الغرفة');});
for(const b of document.querySelectorAll('.back'))b.addEventListener('click',()=>view('vHome'));
for(const b of document.querySelectorAll('.modeBtn'))b.addEventListener('click',()=>{wantMode=b.dataset.m;for(const x of document.querySelectorAll('.modeBtn'))x.classList.toggle('on',x.dataset.m===wantMode);});
for(const b of document.querySelectorAll('.wtBtn'))b.addEventListener('click',()=>{wantWT=b.dataset.w;for(const x of document.querySelectorAll('.wtBtn'))x.classList.toggle('on',x.dataset.w===wantWT);});
for(const b of document.querySelectorAll('.tabBtn'))b.addEventListener('click',()=>setTab(b.dataset.tab));
$('goOff').addEventListener('click',()=>{Net.close();launch({room:($('world').value.trim()||'عالمي'),mode:wantMode,wt:wantWT,online:false});});
$('goOn').addEventListener('click',()=>{
 const name=$('rname').value.trim(),code=$('rcode').value.trim();
 if(!name){say('اكتب اسم الغرفة');return;}
 if(code.length<3){say('الرمز يجب أن يكون 3 خانات على الأقل');return;}
 enterRoom(tab,name,code,wantMode,wantWT);
});
$('bFriends').addEventListener('click',()=>showMenu(true,'vFriends'));

