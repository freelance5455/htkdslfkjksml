'use strict';
/* ================= skins ================= */
const SKINS=[
 {id:'explorer',n:'المستكشف',p:0,body:0x2f6fd6,pants:0x2b3a67,skin:0xf0c29a,hat:'cap',hatC:0xd64545,ab:'شخصية البداية'},
 {id:'farmer',n:'المزارع',p:400,body:0xb07a3c,pants:0x4a5a8a,skin:0xf0c29a,hat:'cap',hatC:0xe8c85a,ab:'الطعام يشبع أكثر 30% وغنائم أكثر'},
 {id:'knight',n:'الفارس',p:600,body:0x9aa4b2,pants:0x5c6572,skin:0xf0c29a,hat:'helm',hatC:0xc3cbd6,ab:'ضرر أقل 10% وسقوط أخف'},
 {id:'ninja',n:'النينجا',p:900,body:0x1d1f27,pants:0x23252e,skin:0xf0c29a,hat:'band',hatC:0xd62f3a,ab:'سرعة +12% وتخفّي جزئي'},
 {id:'wizard',n:'الساحر',p:1300,body:0x6a3fb5,pants:0x3d2a73,skin:0xf0c29a,hat:'cone',hatC:0x7b4fd0,robe:1,ab:'شفاء أسرع'},
 {id:'pirate',n:'القرصان',p:1800,body:0xa83a2c,pants:0x2b2118,skin:0xe2b080,hat:'pirate',hatC:0x1b1b22,ab:'عملات +20% وتنفّس أطول'},
 {id:'alien',n:'الفضائي',p:2300,body:0x3ec97c,pants:0x1f8f57,skin:0x7ae6a0,hat:'antenna',hatC:0xffd54a,big:1,ab:'قفز أعلى وسقوط آمن'},
 {id:'robot',n:'الروبوت',p:3000,body:0xb7c0cc,pants:0x6b7482,skin:0xcfd6df,hat:'antenna',hatC:0xff5252,ab:'جوع أبطأ ودرع خفيف'},
 {id:'astronaut',n:'رائد الفضاء',p:3600,body:0xf2f4f8,pants:0xd0d6e0,skin:0xf0c29a,hat:'helm',hatC:0xdfe9f5,ab:'قفز عالٍ، بلا ضرر سقوط، هواء أطول'},
 {id:'vampire',n:'مصاص الدماء',p:4300,body:0x3a0f1f,pants:0x1b0a12,skin:0xe8dcd8,hat:'band',hatC:0x8a1a2a,ab:'قوة القتال'},
 {id:'king',n:'الملك',p:5200,body:0xb3202f,pants:0x4a1018,skin:0xf0c29a,hat:'crown',hatC:0xffc93c,robe:1,ab:'عملات +15% وخصم عند القرويين'},
 {id:'samurai',n:'الساموراي',p:6200,body:0x7a1f2a,pants:0x2a2a33,skin:0xf0c29a,hat:'helm',hatC:0x2a2a33,ab:'ضرر السلاح +25%'},
 {id:'cyber',n:'السايبورغ',p:7500,body:0x20324a,pants:0x101826,skin:0xb8c8d8,hat:'antenna',hatC:0x39f0ff,ab:'سرعة +18% وضرر +15%'},
 {id:'s_frost',n:'فارس الجليد',p:0,sea:1,body:0x9fd8ff,pants:0x3d6fa8,skin:0xeaf6ff,hat:'cone',hatC:0xffffff,robe:1,ab:'شخصية موسمية حصرية'},
 {id:'s_ember',n:'سيد الجمر',p:0,sea:1,body:0x3a1010,pants:0x240808,skin:0xffb27a,hat:'crown',hatC:0xff5a1a,robe:1,ab:'شخصية موسمية حصرية'},
 {id:'s_jungle',n:'صائد الأدغال',p:0,sea:1,body:0x2f8f3a,pants:0x1f4f26,skin:0xc89a6a,hat:'band',hatC:0x7ad04a,ab:'شخصية موسمية حصرية'},
 {id:'s_neon',n:'نيون',p:0,sea:1,body:0xff2fd6,pants:0x2a0f5a,skin:0xe6d0ff,hat:'antenna',hatC:0x39f0ff,ab:'شخصية موسمية حصرية'},
 {id:'w_sniper',n:'القناص',p:0,g:45,wk:1,body:0x4a5a3a,pants:0x2b3322,skin:0xf0c29a,hat:'band',hatC:0x222222,ab:'شخصية الأسبوع (بالجواهر)'},
 {id:'w_pharaoh',n:'الفرعون',p:0,g:45,wk:1,body:0xe8c04a,pants:0x2b6fd6,skin:0xd9a066,hat:'crown',hatC:0xffd54a,robe:1,ab:'شخصية الأسبوع (بالجواهر)'},
 {id:'w_giant',n:'العملاق',p:0,g:45,wk:1,big:1,body:0x8a6a4a,pants:0x4a3a2a,skin:0xe2b080,hat:'none',hatC:0,ab:'شخصية الأسبوع (بالجواهر)'},
 {id:'w_ghost',n:'الشبح',p:0,g:45,wk:1,body:0xe6ecf5,pants:0xc8d2e6,skin:0xf4f7ff,hat:'cone',hatC:0xdfe6f5,robe:1,ab:'شخصية الأسبوع (بالجواهر)'},
 {id:'w_diver',n:'الغواص',p:0,g:45,wk:1,body:0x1f6fa8,pants:0x123a5c,skin:0xf0c29a,hat:'helm',hatC:0x8fd8ff,ab:'شخصية الأسبوع (بالجواهر)'},
 {id:'w_viking',n:'الفايكنغ',p:0,g:45,wk:1,body:0x8a4a2a,pants:0x3a2a1a,skin:0xf0c29a,hat:'helm',hatC:0xb8b8c8,ab:'شخصية الأسبوع (بالجواهر)'},
 {id:'crystal',n:'الكريستال',p:0,g:60,body:0x2fd8ff,pants:0x1a62c8,skin:0xd9f7ff,hat:'crown',hatC:0x9af3ff,robe:1,ab:'سرعة +15% وقفز أعلى وعملات +25% (بالجواهر فقط)'},
 {id:'phoenix',n:'العنقاء',p:0,secret:1,body:0xe8501a,pants:0x6a1a0a,skin:0xffd8a0,hat:'crown',hatC:0xffa020,robe:1,ab:'هالة نار، سرعة مضاعفة وضرر مضاعف'}
];
const ZSKIN={body:0x4a6b3a,pants:0x2b3a47,skin:0x7fae5e,hat:'none',zombie:1};
const skinById=id=>SKINS.find(s=>s.id===id)||SKINS[0];

