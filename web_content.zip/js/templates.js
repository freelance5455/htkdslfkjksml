/**
 * Panchal Business Manager - Readymade Professional Document Template Gallery & Visual Editor
 * Original mobile-first GST Invoice, Quotation, Receipt & Business Document Studio
 * with Indian Rupee Amount-in-Words, HSN Tax Summary Table, Visual Gallery & Editable T&C Packs.
 */
(function (global) {
  "use strict";

  const INVOICE_PRESETS = [
    { id: "inv_classic_gst", name: "1. Standard GST Classic", category: "INVOICE", layout: "classic", accent: "#0f4c81", headerBg: "#f1f5f9", font: "sans", fontSize: 13, paper: "A4" },
    { id: "inv_modern_minimal", name: "2. Minimalist Clean", category: "INVOICE", layout: "minimal", accent: "#0f172a", headerBg: "#ffffff", font: "sans", fontSize: 13, paper: "A4" },
    { id: "inv_premium_corp", name: "3. Corporate Dark Banner", category: "INVOICE", layout: "banner", accent: "#1d4ed8", headerBg: "#1e3a8a", font: "sans", fontSize: 13, paper: "A4" },
    { id: "inv_executive_split", name: "4. Executive Continental", category: "INVOICE", layout: "executive", accent: "#0f4c81", headerBg: "#0f172a", font: "sans", fontSize: 13, paper: "A4" },
    { id: "inv_furniture", name: "5. Furniture & Woodcraft", category: "INVOICE", layout: "craft", accent: "#78350f", headerBg: "#fef3c7", font: "serif", fontSize: 13, paper: "A4" },
    { id: "inv_emerald_pro", name: "6. Emerald Studio Pro", category: "INVOICE", layout: "emerald", accent: "#047857", headerBg: "#ecfdf5", font: "sans", fontSize: 13, paper: "A4" },
    { id: "inv_hsn_tax", name: "7. Spreadsheet GST Grid", category: "INVOICE", layout: "taxgrid", accent: "#0f766e", headerBg: "#f0fdfa", font: "sans", fontSize: 12, paper: "A4" },
    { id: "inv_arch_stripe", name: "8. Architectural Dual-Box", category: "INVOICE", layout: "split", accent: "#334155", headerBg: "#f8fafc", font: "sans", fontSize: 13, paper: "A4" },
    { id: "inv_retail", name: "9. Showroom Retail Bill", category: "INVOICE", layout: "retail", accent: "#0369a1", headerBg: "#e0f2fe", font: "sans", fontSize: 13, paper: "A4" },
    { id: "inv_service", name: "10. Service & AMC Bill", category: "INVOICE", layout: "service", accent: "#4338ca", headerBg: "#eef2ff", font: "sans", fontSize: 13, paper: "A4" },
    { id: "inv_detailed", name: "11. Detailed Mono Ledger", category: "INVOICE", layout: "detailed", accent: "#334155", headerBg: "#f8fafc", font: "mono", fontSize: 12, paper: "A4" },
    { id: "inv_thermal", name: "12. Compact Thermal (80mm)", category: "INVOICE", layout: "thermal", accent: "#0f172a", headerBg: "#ffffff", font: "mono", fontSize: 11, paper: "THERMAL" },
    { id: "inv_zoho_standard", name: "13. Classic Blue Ledger", category: "INVOICE", layout: "classic", accent: "#1d4ed8", headerBg: "#eff6ff", font: "sans", fontSize: 13, paper: "A4" },
    { id: "inv_zoho_spreadsheet", name: "14. Spreadsheet Pro Grid", category: "INVOICE", layout: "taxgrid", accent: "#0f4c81", headerBg: "#f8fafc", font: "sans", fontSize: 12, paper: "A4" },
    { id: "inv_zoho_modern", name: "15. Modern Executive Slate", category: "INVOICE", layout: "executive", accent: "#0f766e", headerBg: "#0f172a", font: "sans", fontSize: 13, paper: "A4" }
  ];

  const QUOTATION_PRESETS = [
    { id: "qtn_executive", name: "1. Executive Proposal", category: "QUOTATION", layout: "banner", accent: "#0f4c81", headerBg: "#0f4c81", font: "sans", fontSize: 13, paper: "A4" },
    { id: "qtn_furniture_spec", name: "2. Furniture & Interior Spec", category: "QUOTATION", layout: "craft", accent: "#78350f", headerBg: "#fef3c7", font: "serif", fontSize: 13, paper: "A4" },
    { id: "qtn_minimal", name: "3. Minimalist Quote", category: "QUOTATION", layout: "minimal", accent: "#0f172a", headerBg: "#ffffff", font: "sans", fontSize: 13, paper: "A4" },
    { id: "qtn_exec_split", name: "4. Continental Proposal", category: "QUOTATION", layout: "executive", accent: "#1d4ed8", headerBg: "#0f172a", font: "sans", fontSize: 13, paper: "A4" },
    { id: "qtn_emerald_pro", name: "5. Emerald Studio Quote", category: "QUOTATION", layout: "emerald", accent: "#047857", headerBg: "#ecfdf5", font: "sans", fontSize: 13, paper: "A4" },
    { id: "qtn_gst_detailed", name: "6. Spreadsheet GST Estimate", category: "QUOTATION", layout: "taxgrid", accent: "#0f766e", headerBg: "#f0fdfa", font: "sans", fontSize: 12, paper: "A4" },
    { id: "qtn_classic_box", name: "7. Classic Bordered Quote", category: "QUOTATION", layout: "classic", accent: "#334155", headerBg: "#f1f5f9", font: "sans", fontSize: 13, paper: "A4" },
    { id: "qtn_arch_split", name: "8. Architectural Dual-Box", category: "QUOTATION", layout: "split", accent: "#334155", headerBg: "#f8fafc", font: "sans", fontSize: 13, paper: "A4" },
    { id: "qtn_turnkey", name: "9. Turnkey Project Estimate", category: "QUOTATION", layout: "detailed", accent: "#1d4ed8", headerBg: "#eff6ff", font: "sans", fontSize: 13, paper: "A4" },
    { id: "qtn_retail_quote", name: "10. Showroom Price Quote", category: "QUOTATION", layout: "retail", accent: "#0369a1", headerBg: "#e0f2fe", font: "sans", fontSize: 13, paper: "A4" },
    { id: "qtn_service_scope", name: "11. Carpentry & Service Quote", category: "QUOTATION", layout: "service", accent: "#4338ca", headerBg: "#eef2ff", font: "sans", fontSize: 13, paper: "A4" },
    { id: "qtn_compact", name: "12. Compact Slip Quote", category: "QUOTATION", layout: "thermal", accent: "#0f172a", headerBg: "#f8fafc", font: "sans", fontSize: 12, paper: "A4" }
  ];

  const EXTRA_PRESETS = [
    { id: "inv_compact_receipt", name: "Standard Payment Receipt", category: "RECEIPT", layout: "minimal", accent: "#15803d", headerBg: "#f0fdf4", font: "sans", fontSize: 13, paper: "A4" },
    { id: "rec_corporate_voucher", name: "Corporate Receipt Voucher", category: "RECEIPT", layout: "executive", accent: "#15803d", headerBg: "#064e3b", font: "sans", fontSize: 13, paper: "A4" },
    { id: "rec_thermal_slip", name: "Thermal Receipt Slip (80mm)", category: "RECEIPT", layout: "thermal", accent: "#0f172a", headerBg: "#ffffff", font: "mono", fontSize: 11, paper: "THERMAL" },
    { id: "oth_standard_doc", name: "Standard Business Document", category: "OTHER", layout: "classic", accent: "#0f4c81", headerBg: "#f1f5f9", font: "sans", fontSize: 13, paper: "A4" },
    { id: "oth_challan_pro", name: "Delivery Challan / Work Order Pro", category: "OTHER", layout: "taxgrid", accent: "#0f766e", headerBg: "#f0fdfa", font: "sans", fontSize: 13, paper: "A4" }
  ];

  const READYMADE_TC_PACKS = [
    {
      id: "tc_furniture",
      label: "Furniture & Custom Order T&C",
      lines: [
        "1. 50% advance payment is required to confirm custom furniture orders.",
        "2. Balance 50% must be cleared prior to dispatch / final installation.",
        "3. Natural wood grain & veneer shade variations are inherent and not defects.",
        "4. Goods once delivered or custom-built will not be taken back.",
        "5. Subject to local jurisdiction only."
      ]
    },
    {
      id: "tc_gst_invoice",
      label: "Standard GST Tax Invoice T&C",
      lines: [
        "1. Payment is due within the agreed credit period; overdue bills attract 18% p.a. interest.",
        "2. Please verify quantity & condition at the time of delivery.",
        "3. Goods once sold will not be returned without prior written approval.",
        "4. All disputes are subject to local city jurisdiction only."
      ]
    },
    {
      id: "tc_quotation",
      label: "Quotation / Estimate T&C",
      lines: [
        "1. This quotation is valid for 15 days from the date of issue.",
        "2. GST and transport/unloading charges are applicable as mentioned above.",
        "3. Site readiness, power & water supply to be arranged by client before work starts.",
        "4. Any extra work beyond approved scope will be billed separately."
      ]
    },
    {
      id: "tc_service",
      label: "Service & Maintenance T&C",
      lines: [
        "1. Service warranty covers workmanship only for 90 days from completion date.",
        "2. Consumables and damaged hardware replacements are chargeable extra.",
        "3. Payment due immediately upon completion sign-off."
      ]
    }
  ];

  const DEFAULT_FIELDS = {
    showLogo: true,
    showGst: true,
    showHsn: true,
    showDiscount: true,
    showShipping: true,
    showAmountWords: true,
    showTaxSummary: true,
    showTerms: true,
    showBank: true,
    showStamp: true,
    showSignature: true
  };

  const DEFAULT_SECTIONS = ["header", "party", "items", "totals", "bankTerms", "signature"];

  const SECTION_LABELS = {
    header: "Header & Business Info",
    party: "Bill To / Ship To & Supply Details",
    items: "Items Table & Tax Summary",
    totals: "Totals, Balance Due & Words",
    bankTerms: "Bank Details & Terms (T&C)",
    signature: "Authorized Signatory & Stamp"
  };

  function getDocCategory(voucherType) {
    if (voucherType === "QUOTATION" || voucherType === "ESTIMATE" || voucherType === "PROFORMA") {
      return "QUOTATION";
    }
    if (voucherType === "RECEIPT" || voucherType === "PAYMENT" || voucherType === "EXPENSE_VOUCHER") {
      return "RECEIPT";
    }
    if (voucherType === "SALE_INVOICE" || voucherType === "BILL_OF_SUPPLY" || voucherType === "CREDIT_NOTE") {
      return "INVOICE";
    }
    return "OTHER";
  }

  function getAllBuiltinPresets() {
    return INVOICE_PRESETS.concat(QUOTATION_PRESETS).concat(EXTRA_PRESETS).map(function (p) {
      return Object.assign(
        {
          isBuiltin: true,
          fields: Object.assign({}, DEFAULT_FIELDS),
          sections: DEFAULT_SECTIONS.slice(),
          footerText: "Thank you for your business!"
        },
        p
      );
    });
  }

  function getTemplatesForBusiness(businessId) {
    return global.PBM_DB.getByBusiness("templates", businessId).then(function (customList) {
      const builtins = getAllBuiltinPresets();
      const map = {};
      builtins.forEach(function (b) { map[b.id] = b; });
      customList.forEach(function (c) { map[c.id] = c; });
      return Object.keys(map).map(function (k) { return map[k]; });
    });
  }

  function resolveTemplateForVoucher(voucher, templates, docSettings) {
    const cat = getDocCategory(voucher.voucherType);
    const defaultId =
      (docSettings && docSettings.defaultTemplateByCategory && docSettings.defaultTemplateByCategory[cat]) ||
      (cat === "QUOTATION" ? "qtn_furniture_spec" : cat === "RECEIPT" ? "inv_compact_receipt" : "inv_classic_gst");
    const chosenId = voucher.templateId || defaultId;
    return (
      templates.find(function (t) { return t.id === chosenId; }) ||
      templates.find(function (t) { return t.id === defaultId; }) ||
      getAllBuiltinPresets()[0]
    );
  }

  function getFontFamilyCss(fontKey) {
    if (fontKey === "serif") return 'Georgia, "Times New Roman", serif';
    if (fontKey === "mono") return '"Courier New", monospace';
    return '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif';
  }

  function numberToIndianWords(amount) {
    const num = Math.round((Number(amount) || 0) * 100) / 100;
    const rupees = Math.floor(num);
    const paise = Math.round((num - rupees) * 100);

    const ones = [
      "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine",
      "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"
    ];
    const tens = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];

    function twoDigitWords(n) {
      if (n < 20) return ones[n];
      return tens[Math.floor(n / 10)] + (n % 10 ? " " + ones[n % 10] : "");
    }

    function integerToWords(n) {
      if (n === 0) return "Zero";
      let out = "";
      const crore = Math.floor(n / 10000000);
      n %= 10000000;
      const lakh = Math.floor(n / 100000);
      n %= 100000;
      const thousand = Math.floor(n / 1000);
      n %= 1000;
      const hundred = Math.floor(n / 100);
      const rest = n % 100;

      if (crore) out += integerToWords(crore) + " Crore ";
      if (lakh) out += twoDigitWords(lakh) + " Lakh ";
      if (thousand) out += twoDigitWords(thousand) + " Thousand ";
      if (hundred) out += ones[hundred] + " Hundred ";
      if (rest) out += twoDigitWords(rest) + " ";
      return out.trim();
    }

    let result = "Indian Rupee " + integerToWords(rupees);
    if (paise > 0) {
      result += " and " + twoDigitWords(paise) + " Paise";
    }
    return result + " Only";
  }

  function buildHsnTaxSummary(items, voucher) {
    const groups = {};
    const isNonGst = voucher.gstMode === "NON_GST";
    const isIncl = voucher.taxInclusive === "INCLUSIVE";
    if (isNonGst || !Array.isArray(items) || items.length === 0) return [];

    items.forEach(function (line) {
      const qty = Math.max(0, Number(line.qty) || 0);
      const rate = Math.max(0, Number(line.rate) || 0);
      const disc = Math.min(100, Math.max(0, Number(line.discountPct) || 0));
      const gst = Math.max(0, Number(line.gstRate) || 0);
      const cess = Math.max(0, Number(line.cessRate) || 0);
      if (gst <= 0 && cess <= 0) return;

      const netAmt = qty * rate * (1 - disc / 100);
      const taxable = isIncl && gst + cess > 0 ? netAmt / (1 + (gst + cess) / 100) : netAmt;
      const gstAmt = taxable * (gst / 100);
      const cessAmt = taxable * (cess / 100);
      const key = (line.hsn || "-") + "|" + gst + "|" + cess;

      if (!groups[key]) {
        groups[key] = { hsn: line.hsn || "-", gstRate: gst, cessRate: cess, taxable: 0, taxAmt: 0, cessAmt: 0 };
      }
      groups[key].taxable += taxable;
      groups[key].taxAmt += gstAmt;
      groups[key].cessAmt += cessAmt;
    });

    return Object.keys(groups).map(function (k) {
      return groups[k];
    });
  }

  function renderTemplateMiniThumb(tpl) {
    const isDarkBanner = tpl.layout === "banner" || tpl.layout === "executive";
    const isMinimal = tpl.layout === "minimal";
    const isThermal = tpl.paper === "THERMAL" || tpl.layout === "thermal";
    const isCraft = tpl.layout === "craft";

    return `
      <div style="width:100%;height:56px;border-radius:6px;background:#ffffff;border:${isCraft ? "2px double " + tpl.accent : isThermal ? "1px dashed #94a3b8" : "1px solid #cbd5e1"};overflow:hidden;padding:4px;display:flex;flex-direction:column;gap:3px;">
        <div style="height:14px;border-radius:3px;background:${isMinimal ? "#ffffff" : tpl.headerBg};border-bottom:2px solid ${tpl.accent};display:flex;align-items:center;justify-content:space-between;padding:0 4px;">
          <span style="width:26px;height:4px;border-radius:2px;background:${isDarkBanner ? "#ffffff" : tpl.accent};"></span>
          <span style="width:14px;height:4px;border-radius:2px;background:${isDarkBanner ? "rgba(255,255,255,0.8)" : "#64748b"};"></span>
        </div>
        <div style="display:flex;justify-content:space-between;gap:4px;">
          <span style="width:45%;height:5px;background:#e2e8f0;border-radius:2px;"></span>
          <span style="width:30%;height:5px;background:#f1f5f9;border-radius:2px;"></span>
        </div>
        <div style="height:10px;border-radius:2px;background:${tpl.accent};opacity:0.85;"></div>
        <div style="display:flex;flex-direction:column;gap:2px;">
          <span style="width:100%;height:3px;background:#e2e8f0;"></span>
          <span style="width:72%;height:3px;background:#e2e8f0;margin-left:auto;"></span>
        </div>
      </div>
    `;
  }

  function renderDocumentHtml(voucher, business, party, template) {
    const app = global.PBM_APP;
    const tpl = template || getAllBuiltinPresets()[0];
    const f = Object.assign({}, DEFAULT_FIELDS, tpl.fields || {});
    const sections = Array.isArray(tpl.sections) && tpl.sections.length ? tpl.sections : DEFAULT_SECTIONS;
    const cur = voucher.currencySymbol || "₹";
    const fmt = function (val) {
      const num = Number(val) || 0;
      return cur + num.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    };

    const docTitles = {
      SALE_INVOICE: voucher.gstMode === "NON_GST" ? "BILL OF SUPPLY" : "TAX INVOICE",
      BILL_OF_SUPPLY: "BILL OF SUPPLY",
      ESTIMATE: "ESTIMATE",
      QUOTATION: "QUOTATION",
      PROFORMA: "PROFORMA INVOICE",
      CREDIT_NOTE: "CREDIT NOTE",
      DEBIT_NOTE: "DEBIT NOTE",
      PURCHASE_ORDER: "PURCHASE ORDER",
      SALES_ORDER: "SALES ORDER",
      CHALLAN: "DELIVERY CHALLAN",
      RECEIPT: "PAYMENT RECEIPT",
      WORK_ORDER: "WORK ORDER",
      COMPLETION_CERT: "COMPLETION CERTIFICATE",
      PURCHASE_BILL: "PURCHASE BILL",
      EXPENSE_VOUCHER: "EXPENSE VOUCHER",
      PAYMENT: "PAYMENT VOUCHER"
    };
    const title = docTitles[voucher.voucherType] || voucher.voucherType;
    const isBannerDark = tpl.layout === "banner" || tpl.layout === "executive";
    const isCraft = tpl.layout === "craft";
    const isService = tpl.layout === "service";
    const isMinimal = tpl.layout === "minimal";
    const isSplit = tpl.layout === "split";
    const isEmerald = tpl.layout === "emerald";
    const isExecutive = tpl.layout === "executive";
    const isTaxGrid = tpl.layout === "taxgrid";
    const headerTextColor = isBannerDark ? "#ffffff" : "#0f172a";
    const items = Array.isArray(voucher.items) ? voucher.items : [];
    const isThermal = tpl.paper === "THERMAL" || tpl.layout === "thermal";
    const isVoid = voucher.status === "VOID";

    const totalAmt = Number(voucher.grandTotal != null ? voucher.grandTotal : voucher.amount) || 0;
    const paidAmt = Number(voucher.paidAmount || 0);
    const balanceDue = Math.max(0, Math.round((totalAmt - paidAmt) * 100) / 100);
    const isQuoteLike = voucher.voucherType === "QUOTATION" || voucher.voucherType === "ESTIMATE";

    const outerBorder = isCraft
      ? "3px double " + tpl.accent
      : isService
      ? "1px solid #cbd5e1;border-top:6px solid " + tpl.accent
      : isSplit || isTaxGrid
      ? "2px solid " + tpl.accent
      : isEmerald
      ? "1px solid #a7f3d0;border-top:5px solid " + tpl.accent
      : isMinimal
      ? "1px solid #e2e8f0"
      : "1px solid #cbd5e1";

    const sectionBlocks = {};

    const docBadgeBox = isExecutive
      ? `background:#ffffff;color:#0f172a;padding:8px 12px;border-radius:6px;text-align:right;min-width:180px;`
      : isSplit
      ? `border:1.5px solid ${tpl.accent};padding:8px 12px;border-radius:4px;background:#ffffff;text-align:right;`
      : `text-align:right;`;

    const balanceBadgeHtml =
      !isThermal && !isQuoteLike && balanceDue > 0
        ? `<div style="margin-top:4px;display:inline-block;padding:3px 8px;border-radius:4px;background:${isBannerDark && !isExecutive ? "rgba(255,255,255,0.18)" : "#fef2f2"};color:${isBannerDark && !isExecutive ? "#ffffff" : "#b91c1c"};font-size:0.8em;font-weight:700;">Balance Due: ${fmt(balanceDue)}</div>`
        : !isThermal && !isQuoteLike && paidAmt >= totalAmt && totalAmt > 0
        ? `<div style="margin-top:4px;display:inline-block;padding:3px 8px;border-radius:4px;background:#ecfdf5;color:#047857;font-size:0.8em;font-weight:700;">PAID</div>`
        : "";

    sectionBlocks.header = `
      <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px;padding:${isMinimal ? "10px 0 14px" : "14px"};background:${tpl.headerBg};color:${headerTextColor};border-bottom:${isMinimal ? "3px solid " + tpl.accent : "2px solid " + tpl.accent};border-radius:${isMinimal ? "0" : "6px 6px 0 0"};margin-bottom:12px;">
        <div style="display:flex;align-items:center;gap:10px;">
          ${f.showLogo && business && business.logoDataUrl ? `<img src="${business.logoDataUrl}" alt="Logo" style="max-height:56px;max-width:96px;object-fit:contain;background:#fff;padding:3px;border-radius:4px;" />` : ""}
          <div>
            <div style="font-size:1.3em;font-weight:800;letter-spacing:-0.01em;">${app.escapeHtml(business ? business.name : "Panchal Furnitures")}</div>
            <div style="font-size:0.83em;opacity:0.92;line-height:1.4;">
              ${business && business.address ? app.escapeHtml(business.address) + "<br/>" : ""}
              ${business && business.phone ? "Ph: " + app.escapeHtml(business.phone) + " " : ""}
              ${business && business.email ? "· " + app.escapeHtml(business.email) + " " : ""}
              ${f.showGst && business && business.gstin ? "<br/>GSTIN: <strong>" + app.escapeHtml(business.gstin) + "</strong>" : ""}
              ${business && business.stateName ? " · State: " + app.escapeHtml(business.stateName) : ""}
            </div>
          </div>
        </div>
        <div style="${docBadgeBox}">
          <div style="font-size:1.18em;font-weight:800;color:${isExecutive ? tpl.accent : isBannerDark ? "#ffffff" : tpl.accent};">${title}</div>
          ${isVoid ? `<div style="color:#dc2626;font-weight:800;border:1px solid #dc2626;padding:1px 6px;border-radius:4px;display:inline-block;margin:2px 0;">CANCELLED / VOID</div>` : ""}
          <div style="font-size:0.88em;"># <strong>${app.escapeHtml(voucher.voucherNo)}</strong></div>
          <div style="font-size:0.86em;">Date: ${app.escapeHtml(voucher.date)}</div>
          ${voucher.dueDate ? `<div style="font-size:0.83em;">${isQuoteLike ? "Valid Until" : "Due Date"}: ${app.escapeHtml(voucher.dueDate)}</div>` : ""}
          ${balanceBadgeHtml}
        </div>
      </div>
    `;

    sectionBlocks.party = `
      <div style="display:grid;grid-template-columns:${isThermal ? "1fr" : "1fr 1fr"};gap:10px;padding:10px 12px;border:${isSplit ? "1px dashed " + tpl.accent : "1px solid #cbd5e1"};border-radius:6px;margin-bottom:12px;font-size:0.88em;background:${tpl.layout === "retail" || isEmerald || isExecutive ? "#f8fafc" : "transparent"};">
        <div>
          <div style="font-weight:700;color:${tpl.accent};margin-bottom:2px;">${isQuoteLike ? "Prepared For (Client)" : "Bill To"}:</div>
          <div style="font-size:1.05em;"><strong>${app.escapeHtml(voucher.partyName || (party && party.name) || "-")}</strong></div>
          ${party && party.phone ? `<div>Ph: ${app.escapeHtml(party.phone)}</div>` : ""}
          ${f.showGst && party && party.gstin ? `<div>GSTIN: <strong>${app.escapeHtml(party.gstin)}</strong></div>` : ""}
          ${party && party.address ? `<div>Billing: ${app.escapeHtml(party.address)}</div>` : ""}
          ${party && party.shippingAddress ? `<div>Ship To: ${app.escapeHtml(party.shippingAddress)}</div>` : ""}
        </div>
        <div style="text-align:${isThermal ? "left" : "right"};border-left:${isThermal ? "none" : "1px solid #e2e8f0"};padding-left:${isThermal ? "0" : "10px"};">
          ${voucher.placeOfSupply ? `<div>Place of Supply: <strong>${app.escapeHtml(voucher.placeOfSupply)}</strong></div>` : ""}
          ${voucher.paymentTerms ? `<div>Payment Terms: <strong>${app.escapeHtml(voucher.paymentTerms)}</strong></div>` : ""}
          ${voucher.taxInclusive === "INCLUSIVE" ? `<div>Rate Pricing: Tax Inclusive</div>` : ""}
          ${voucher.reverseCharge ? `<div>Reverse Charge: <strong>Applicable</strong></div>` : ""}
          ${voucher.convertedFrom ? `<div>Reference Doc: ${app.escapeHtml(voucher.convertedFrom)}</div>` : ""}
          ${voucher.customFieldLabel && voucher.customFieldValue ? `<div>${app.escapeHtml(voucher.customFieldLabel)}: <strong>${app.escapeHtml(voucher.customFieldValue)}</strong></div>` : ""}
        </div>
      </div>
    `;

    if (items.length > 0) {
      const thBorder = isMinimal ? "border-bottom:2px solid " + tpl.accent + ";border-top:none;border-left:none;border-right:none;" : "border:1px solid #cbd5e1;";
      const thStyle = `background:${isMinimal ? "#ffffff" : tpl.accent};color:${isMinimal ? "#0f172a" : "#ffffff"};padding:7px 6px;${thBorder}font-weight:700;`;
      const tdBorder = isMinimal ? "border-bottom:1px solid #e2e8f0;border-top:none;border-left:none;border-right:none;" : "border:1px solid #cbd5e1;";
      const rowsHtml = items
        .map(function (line, i) {
          const rowBg = (tpl.layout === "detailed" || isTaxGrid || isExecutive) && i % 2 === 1 ? "#f8fafc" : "#ffffff";
          return `
            <tr style="background:${rowBg};">
              <td style="${tdBorder}padding:6px;">${i + 1}</td>
              <td style="${tdBorder}padding:6px;">
                <strong>${app.escapeHtml(line.name)}</strong>
                ${line.desc ? `<br/><small style="color:#475569;">${app.escapeHtml(line.desc)}</small>` : ""}
              </td>
              ${f.showHsn && !isThermal ? `<td style="${tdBorder}padding:6px;">${app.escapeHtml(line.hsn || "-")}</td>` : ""}
              <td style="${tdBorder}padding:6px;text-align:right;white-space:nowrap;">${line.qty} ${app.escapeHtml(line.unit || "")}</td>
              <td style="${tdBorder}padding:6px;text-align:right;white-space:nowrap;">${fmt(line.rate)}</td>
              ${f.showDiscount && !isThermal ? `<td style="${tdBorder}padding:6px;text-align:right;">${Number(line.discountPct || 0)}%</td>` : ""}
              ${f.showGst && voucher.gstMode !== "NON_GST" && !isThermal ? `<td style="${tdBorder}padding:6px;text-align:right;white-space:nowrap;">${Number(line.gstRate || 0)}%${Number(line.cessRate || 0) > 0 ? "+" + line.cessRate + "%" : ""}</td>` : ""}
              <td style="${tdBorder}padding:6px;text-align:right;white-space:nowrap;"><strong>${fmt(line.lineTotal)}</strong></td>
            </tr>
          `;
        })
        .join("");

      const taxSummaryGroups = f.showTaxSummary && f.showGst && !isThermal ? buildHsnTaxSummary(items, voucher) : [];
      const taxSummaryHtml =
        taxSummaryGroups.length > 0
          ? `
            <div style="margin-bottom:12px;">
              <div style="font-size:0.78em;font-weight:700;color:${tpl.accent};margin-bottom:4px;">Tax Summary Breakdown (HSN / SAC)</div>
              <table style="width:100%;border-collapse:collapse;font-size:0.78em;">
                <thead>
                  <tr style="background:#f8fafc;">
                    <th style="border:1px solid #cbd5e1;padding:4px 6px;text-align:left;">HSN/SAC</th>
                    <th style="border:1px solid #cbd5e1;padding:4px 6px;text-align:right;">Taxable Value</th>
                    ${
                      voucher.supplyType === "INTER"
                        ? `<th style="border:1px solid #cbd5e1;padding:4px 6px;text-align:right;">IGST Rate</th>
                           <th style="border:1px solid #cbd5e1;padding:4px 6px;text-align:right;">IGST Amt</th>`
                        : `<th style="border:1px solid #cbd5e1;padding:4px 6px;text-align:right;">CGST</th>
                           <th style="border:1px solid #cbd5e1;padding:4px 6px;text-align:right;">SGST</th>`
                    }
                    <th style="border:1px solid #cbd5e1;padding:4px 6px;text-align:right;">Total Tax</th>
                  </tr>
                </thead>
                <tbody>
                  ${taxSummaryGroups
                    .map(function (g) {
                      const halfTax = g.taxAmt / 2;
                      return `
                        <tr>
                          <td style="border:1px solid #cbd5e1;padding:4px 6px;">${app.escapeHtml(g.hsn)}</td>
                          <td style="border:1px solid #cbd5e1;padding:4px 6px;text-align:right;">${fmt(g.taxable)}</td>
                          ${
                            voucher.supplyType === "INTER"
                              ? `<td style="border:1px solid #cbd5e1;padding:4px 6px;text-align:right;">${g.gstRate}%</td>
                                 <td style="border:1px solid #cbd5e1;padding:4px 6px;text-align:right;">${fmt(g.taxAmt)}</td>`
                              : `<td style="border:1px solid #cbd5e1;padding:4px 6px;text-align:right;">${g.gstRate / 2}% (${fmt(halfTax)})</td>
                                 <td style="border:1px solid #cbd5e1;padding:4px 6px;text-align:right;">${g.gstRate / 2}% (${fmt(halfTax)})</td>`
                          }
                          <td style="border:1px solid #cbd5e1;padding:4px 6px;text-align:right;"><strong>${fmt(g.taxAmt + g.cessAmt)}</strong></td>
                        </tr>
                      `;
                    })
                    .join("")}
                </tbody>
              </table>
            </div>
          `
          : "";

      sectionBlocks.items = `
        <table style="width:100%;border-collapse:collapse;margin-bottom:10px;font-size:0.88em;">
          <thead>
            <tr>
              <th style="${thStyle}text-align:left;">#</th>
              <th style="${thStyle}text-align:left;">Item &amp; Description</th>
              ${f.showHsn && !isThermal ? `<th style="${thStyle}text-align:left;">HSN/SAC</th>` : ""}
              <th style="${thStyle}text-align:right;">Qty</th>
              <th style="${thStyle}text-align:right;">Rate</th>
              ${f.showDiscount && !isThermal ? `<th style="${thStyle}text-align:right;">Disc</th>` : ""}
              ${f.showGst && voucher.gstMode !== "NON_GST" && !isThermal ? `<th style="${thStyle}text-align:right;">Tax</th>` : ""}
              <th style="${thStyle}text-align:right;">Amount</th>
            </tr>
          </thead>
          <tbody>${rowsHtml}</tbody>
        </table>
        ${taxSummaryHtml}
      `;
    } else {
      sectionBlocks.items = `
        <div style="padding:10px;border:1px solid #cbd5e1;border-radius:6px;margin-bottom:12px;">
          <strong>Particulars:</strong> ${app.escapeHtml(voucher.notes || title)} — <strong>${fmt(voucher.grandTotal || voucher.amount)}</strong>
        </div>
      `;
    }

    const wordsHtml =
      f.showAmountWords && !isThermal
        ? `<div style="flex:1;min-width:220px;padding:8px 10px;border:1px solid #e2e8f0;border-radius:6px;background:#f8fafc;font-size:0.83em;align-self:flex-start;">
             <div style="color:#475569;font-size:0.9em;">Total In Words</div>
             <div style="font-weight:700;color:#0f172a;margin-top:2px;">${app.escapeHtml(numberToIndianWords(totalAmt))}</div>
           </div>`
        : "";

    sectionBlocks.totals = `
      <div style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:flex-start;gap:12px;margin-bottom:12px;">
        ${wordsHtml}
        <div style="margin-left:auto;min-width:${isThermal ? "100%" : "290px"};max-width:${isThermal ? "100%" : "320px"};border:1px solid #cbd5e1;border-radius:6px;padding:10px;font-size:0.88em;background:${isExecutive || isEmerald ? "#f8fafc" : "#ffffff"};">
          ${voucher.subtotal != null ? `<div style="display:flex;justify-content:space-between;padding:2px 0;"><span>Sub Total (Taxable):</span><strong>${fmt(voucher.subtotal)}</strong></div>` : ""}
          ${
            f.showGst && voucher.gstMode !== "NON_GST" && Number(voucher.taxTotal || 0) > 0
              ? voucher.supplyType === "INTER"
                ? `<div style="display:flex;justify-content:space-between;padding:2px 0;"><span>IGST:</span><strong>${fmt(voucher.taxTotal)}</strong></div>`
                : `<div style="display:flex;justify-content:space-between;padding:2px 0;"><span>CGST:</span><strong>${fmt((voucher.taxTotal || 0) / 2)}</strong></div>
                   <div style="display:flex;justify-content:space-between;padding:2px 0;"><span>SGST:</span><strong>${fmt((voucher.taxTotal || 0) / 2)}</strong></div>`
              : ""
          }
          ${Number(voucher.cessTotal || 0) > 0 ? `<div style="display:flex;justify-content:space-between;padding:2px 0;"><span>Cess:</span><strong>${fmt(voucher.cessTotal)}</strong></div>` : ""}
          ${f.showShipping && Number(voucher.shippingCharge || 0) > 0 ? `<div style="display:flex;justify-content:space-between;padding:2px 0;"><span>Shipping / Extra:</span><strong>${fmt(voucher.shippingCharge)}</strong></div>` : ""}
          ${Number(voucher.roundOff || 0) !== 0 ? `<div style="display:flex;justify-content:space-between;padding:2px 0;"><span>Round Off:</span><strong>${fmt(voucher.roundOff)}</strong></div>` : ""}
          <div style="display:flex;justify-content:space-between;border-top:2px solid ${tpl.accent};margin-top:6px;padding:6px 6px 4px;border-radius:4px;background:${isBannerDark || isRetailBg(tpl) ? tpl.headerBg : "#f1f5f9"};font-size:1.08em;color:${isBannerDark ? "#ffffff" : tpl.accent};">
            <strong>${isQuoteLike ? "Estimated Total" : "Total"}:</strong><strong>${fmt(totalAmt)}</strong>
          </div>
          ${paidAmt > 0 ? `<div style="display:flex;justify-content:space-between;margin-top:5px;"><span>Payment Made:</span><strong>(-) ${fmt(paidAmt)}</strong></div>` : ""}
          ${paidAmt > 0 && balanceDue > 0 ? `<div style="display:flex;justify-content:space-between;color:#b91c1c;margin-top:2px;"><strong>Balance Due:</strong><strong>${fmt(balanceDue)}</strong></div>` : ""}
        </div>
      </div>
    `;

    sectionBlocks.bankTerms = `
      <div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:12px;font-size:0.82em;color:#334155;margin-bottom:14px;">
        ${
          f.showBank && business && (business.bankName || business.bankAccountNo || business.upiId)
            ? `<div style="flex:1;min-width:200px;padding:8px 10px;border:1px solid #e2e8f0;border-radius:6px;">
                 <strong style="color:${tpl.accent};">Bank &amp; Payment Details</strong><br/>
                 ${business.bankName ? "Bank: " + app.escapeHtml(business.bankName) + "<br/>" : ""}
                 ${business.bankAccountNo ? "A/C No: <strong>" + app.escapeHtml(business.bankAccountNo) + "</strong> " : ""}
                 ${business.bankIfsc ? "· IFSC: <strong>" + app.escapeHtml(business.bankIfsc) + "</strong><br/>" : ""}
                 ${business.upiId ? "UPI ID: <strong>" + app.escapeHtml(business.upiId) + "</strong>" : ""}
               </div>`
            : ""
        }
        ${
          f.showTerms && (voucher.notes || tpl.footerText)
            ? `<div style="flex:1;min-width:220px;padding:8px 10px;border:1px solid #e2e8f0;border-radius:6px;">
                 <strong style="color:${tpl.accent};">Terms &amp; Conditions</strong><br/>
                 ${voucher.notes ? app.escapeHtml(voucher.notes).replace(/\n/g, "<br/>") + "<br/>" : ""}
                 ${tpl.footerText ? `<em style="color:#475569;">${app.escapeHtml(tpl.footerText)}</em>` : ""}
               </div>`
            : ""
        }
      </div>
    `;

    const sigImg = voucher.signatureDataUrl || (business && business.signatureDataUrl) || "";
    const stampImg = business && business.stampDataUrl ? business.stampDataUrl : "";

    sectionBlocks.signature = `
      <div style="display:flex;justify-content:space-between;align-items:flex-end;margin-top:14px;padding-top:10px;border-top:1px solid #e2e8f0;font-size:0.82em;">
        <div>
          ${voucher.customerSignatureDataUrl ? `<img src="${voucher.customerSignatureDataUrl}" alt="Customer Sign" style="max-height:46px;display:block;" />` : `<div style="height:34px;"></div>`}
          <div style="border-top:1px solid #94a3b8;padding-top:3px;">Customer Acceptance / Sign</div>
        </div>
        <div style="text-align:right;display:flex;align-items:flex-end;gap:12px;">
          ${f.showStamp && stampImg ? `<img src="${stampImg}" alt="Stamp" style="max-height:56px;opacity:0.85;" />` : ""}
          <div>
            ${f.showSignature && sigImg ? `<img src="${sigImg}" alt="Signature" style="max-height:52px;display:block;margin-left:auto;" />` : `<div style="height:38px;"></div>`}
            <div style="border-top:1px solid #94a3b8;padding-top:3px;">
              ${business && business.authorizedPerson ? app.escapeHtml(business.authorizedPerson) + " · " : ""}Authorized Signatory
            </div>
          </div>
        </div>
      </div>
    `;

    const orderedBody = sections
      .map(function (secKey) {
        return sectionBlocks[secKey] || "";
      })
      .join("");

    return `
      <div class="print-sheet" style="position:relative;max-width:${isThermal ? "330px" : "820px"};margin:0 auto;font-family:${getFontFamilyCss(tpl.font)};font-size:${tpl.fontSize || 13}px;color:#0f172a;background:#ffffff;padding:${isThermal ? "10px" : "18px"};border:${outerBorder};border-radius:6px;">
        ${isVoid ? `<div style="position:absolute;top:40%;left:50%;transform:translate(-50%,-50%) rotate(-24deg);font-size:3rem;font-weight:900;color:rgba(220,38,38,0.18);pointer-events:none;border:4px solid rgba(220,38,38,0.18);padding:8px 20px;border-radius:10px;">VOID</div>` : ""}
        ${orderedBody}
      </div>
    `;
  }

  function isRetailBg(tpl) {
    return tpl.layout === "retail";
  }

  function openTemplateDesignerModal(initialCategory) {
    const app = global.PBM_APP;
    const businessId = app.getActiveBusinessId();
    const business = app.getActiveBusiness();
    let activeCategory = initialCategory || "INVOICE";

    Promise.all([
      getTemplatesForBusiness(businessId),
      global.PBM_DB.getByBusiness("docSettings", businessId)
    ]).then(function (results) {
      const templates = results[0];
      const docSettings = results[1][0] || global.PBM_DB.getDefaultDocSettings(businessId);

      function showEditor(selectedTplId) {
        const catTemplates = templates.filter(function (t) {
          if (activeCategory === "QUOTATION") return t.category === "QUOTATION";
          if (activeCategory === "RECEIPT") return t.category === "RECEIPT" || t.category === "INVOICE";
          if (activeCategory === "OTHER") return t.category === "OTHER" || t.category === "INVOICE" || t.category === "QUOTATION";
          return t.category === "INVOICE";
        });
        const tpl = JSON.parse(
          JSON.stringify(
            templates.find(function (t) { return t.id === selectedTplId; }) ||
              catTemplates[0] ||
              templates[0]
          )
        );
        if (!tpl.fields) tpl.fields = Object.assign({}, DEFAULT_FIELDS);
        if (!Array.isArray(tpl.sections) || tpl.sections.length === 0) tpl.sections = DEFAULT_SECTIONS.slice();

        const sampleVoucherType =
          activeCategory === "QUOTATION"
            ? "QUOTATION"
            : activeCategory === "RECEIPT"
            ? "RECEIPT"
            : activeCategory === "OTHER"
            ? "CHALLAN"
            : "SALE_INVOICE";

        const sampleVoucher = {
          voucherType: sampleVoucherType,
          voucherNo: activeCategory === "QUOTATION" ? "PF/QTN/26-27/014" : activeCategory === "RECEIPT" ? "PF/REC/26-27/018" : "PF/INV/26-27/042",
          date: new Date().toISOString().slice(0, 10),
          dueDate: new Date().toISOString().slice(0, 10),
          partyName: "Mehta Residency & Studio",
          gstMode: "GST",
          supplyType: "INTRA",
          placeOfSupply: (business && business.stateName) || "Gujarat",
          paymentTerms: "Net 15 Days",
          items:
            sampleVoucherType === "RECEIPT"
              ? []
              : [
                  { name: "Teakwood Modular Wardrobe (3-Door)", desc: "19mm BWR Marine Ply · Soft-Close", hsn: "9403", qty: 2, unit: "Nos", rate: 28500, discountPct: 5, gstRate: 18, lineTotal: 63897 },
                  { name: "Site Delivery & Precision Installation", desc: "Calibration & polish finishing", hsn: "9954", qty: 1, unit: "Job", rate: 3500, discountPct: 0, gstRate: 18, lineTotal: 4130 }
                ],
          subtotal: 57650,
          taxTotal: 10377,
          shippingCharge: 800,
          roundOff: 0,
          grandTotal: 68827,
          amount: 68827,
          paidAmount: sampleVoucherType === "RECEIPT" ? 68827 : 25000,
          notes: (docSettings.termsLibrary || []).join("\n") || "Payment due within 15 days."
        };

        const galleryHtml = catTemplates
          .map(function (t) {
            const isDef = docSettings.defaultTemplateByCategory && docSettings.defaultTemplateByCategory[activeCategory] === t.id;
            const isSel = t.id === tpl.id;
            return `
              <button
                type="button"
                data-td-card="${app.escapeHtml(t.id)}"
                style="text-align:left;padding:8px;border-radius:10px;border:${isSel ? "2px solid " + (t.accent || "#0f4c81") : "1px solid var(--border-hairline)"};background:${isSel ? "var(--bg-canvas)" : "var(--bg-surface)"};cursor:pointer;display:flex;flex-direction:column;gap:6px;"
              >
                ${renderTemplateMiniThumb(t)}
                <div style="font-size:0.78rem;font-weight:700;color:var(--text-primary);line-height:1.25;">${app.escapeHtml(t.name)}</div>
                <div style="font-size:0.7rem;color:var(--text-secondary);">
                  ${app.escapeHtml(t.paper || "A4")}${isDef ? " · Default" : ""}
                </div>
              </button>
            `;
          })
          .join("");

        const tcPackChips = READYMADE_TC_PACKS.map(function (pk) {
          return `<button type="button" class="secondary-btn" data-tc-pack="${app.escapeHtml(pk.id)}" style="min-height:32px;padding:4px 8px;font-size:0.75rem;">${app.escapeHtml(pk.label)}</button>`;
        }).join("");

        const html = `
          <div class="form-grid">
            <div class="segmented-bar" style="margin-top:0;">
              <button class="seg-btn ${activeCategory === "INVOICE" ? "active" : ""}" data-td-cat="INVOICE" type="button">Invoice (${INVOICE_PRESETS.length})</button>
              <button class="seg-btn ${activeCategory === "QUOTATION" ? "active" : ""}" data-td-cat="QUOTATION" type="button">Quotation (${QUOTATION_PRESETS.length})</button>
              <button class="seg-btn ${activeCategory === "RECEIPT" ? "active" : ""}" data-td-cat="RECEIPT" type="button">Receipts</button>
              <button class="seg-btn ${activeCategory === "OTHER" ? "active" : ""}" data-td-cat="OTHER" type="button">Other Docs</button>
            </div>

            <div class="form-group">
              <label class="form-label">Readymade Template Gallery (Tap to Preview &amp; Customize)</label>
              <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(145px,1fr));gap:8px;max-height:230px;overflow-y:auto;padding:2px;">
                ${galleryHtml}
              </div>
            </div>

            <div class="form-row-2">
              <div class="form-group">
                <label class="form-label" for="tdAccent">Accent Color</label>
                <input id="tdAccent" class="form-input" type="color" value="${tpl.accent || "#0f4c81"}" />
              </div>
              <div class="form-group">
                <label class="form-label" for="tdHeaderBg">Header BG Color</label>
                <input id="tdHeaderBg" class="form-input" type="color" value="${tpl.headerBg || "#f1f5f9"}" />
              </div>
            </div>

            <div class="form-row-2">
              <div class="form-group">
                <label class="form-label" for="tdFont">Font Style</label>
                <select id="tdFont" class="form-select">
                  <option value="sans" ${tpl.font === "sans" ? "selected" : ""}>Modern Sans</option>
                  <option value="serif" ${tpl.font === "serif" ? "selected" : ""}>Classic Serif</option>
                  <option value="mono" ${tpl.font === "mono" ? "selected" : ""}>Technical Mono</option>
                </select>
              </div>
              <div class="form-group">
                <label class="form-label" for="tdSize">Font Size (px)</label>
                <input id="tdSize" class="form-input" type="number" min="10" max="16" value="${tpl.fontSize || 13}" />
              </div>
            </div>

            <div class="form-group">
              <label class="form-label">Visible Fields &amp; GST Sections</label>
              <div class="btn-row">
                <label class="check-chip"><input type="checkbox" id="fLogo" ${tpl.fields.showLogo ? "checked" : ""}/> Logo</label>
                <label class="check-chip"><input type="checkbox" id="fGst" ${tpl.fields.showGst ? "checked" : ""}/> GST</label>
                <label class="check-chip"><input type="checkbox" id="fHsn" ${tpl.fields.showHsn ? "checked" : ""}/> HSN</label>
                <label class="check-chip"><input type="checkbox" id="fDisc" ${tpl.fields.showDiscount ? "checked" : ""}/> Discount</label>
                <label class="check-chip"><input type="checkbox" id="fShip" ${tpl.fields.showShipping ? "checked" : ""}/> Shipping</label>
                <label class="check-chip"><input type="checkbox" id="fWords" ${tpl.fields.showAmountWords !== false ? "checked" : ""}/> In Words</label>
                <label class="check-chip"><input type="checkbox" id="fTaxSum" ${tpl.fields.showTaxSummary !== false ? "checked" : ""}/> Tax Table</label>
                <label class="check-chip"><input type="checkbox" id="fBank" ${tpl.fields.showBank ? "checked" : ""}/> Bank</label>
                <label class="check-chip"><input type="checkbox" id="fTerms" ${tpl.fields.showTerms ? "checked" : ""}/> Terms (T&amp;C)</label>
                <label class="check-chip"><input type="checkbox" id="fStamp" ${tpl.fields.showStamp ? "checked" : ""}/> Stamp</label>
                <label class="check-chip"><input type="checkbox" id="fSig" ${tpl.fields.showSignature ? "checked" : ""}/> Sign</label>
              </div>
            </div>

            <div class="form-group">
              <label class="form-label">Reorder Document Sections</label>
              <div id="tdSectionsWrap" class="section-order-list"></div>
            </div>

            <div class="form-group">
              <label class="form-label" for="tdTermsLibrary">Readymade T&amp;C Packs &amp; Editable Default Terms (T&amp;C)</label>
              <div class="btn-row" style="margin-bottom:6px;">${tcPackChips}</div>
              <textarea id="tdTermsLibrary" class="form-textarea" rows="4">${app.escapeHtml((docSettings.termsLibrary || []).join("\n"))}</textarea>
            </div>

            <div class="form-group">
              <label class="form-label" for="tdFooter">Custom Footer Line</label>
              <input id="tdFooter" class="form-input" type="text" value="${app.escapeHtml(tpl.footerText || "")}" />
            </div>

            <div class="btn-row">
              <button id="tdSaveTermsBtn" class="secondary-btn" type="button">Save T&amp;C Library</button>
              <button id="tdSaveCustomBtn" class="secondary-btn" type="button">Save as Custom Template</button>
              <button id="tdSetDefaultBtn" class="primary-btn" type="button">Set Default for ${activeCategory}</button>
            </div>

            <div class="pbm-preview-paper">
              <div id="tdPreviewBox" style="transform-origin:top left;"></div>
            </div>
          </div>
        `;

        app.openModal("Readymade Template Gallery & Studio", html);

        function renderSectionOrder() {
          const wrap = document.getElementById("tdSectionsWrap");
          if (!wrap) return;
          wrap.innerHTML = tpl.sections
            .map(function (secKey, idx) {
              return `
                <div class="section-order-row">
                  <span>${idx + 1}. ${app.escapeHtml(SECTION_LABELS[secKey] || secKey)}</span>
                  <div class="btn-row">
                    <button class="secondary-btn" style="min-height:32px;padding:4px 10px;" type="button" data-sec-up="${idx}" ${idx === 0 ? "disabled" : ""}>▲</button>
                    <button class="secondary-btn" style="min-height:32px;padding:4px 10px;" type="button" data-sec-dn="${idx}" ${idx === tpl.sections.length - 1 ? "disabled" : ""}>▼</button>
                  </div>
                </div>
              `;
            })
            .join("");

          wrap.querySelectorAll("[data-sec-up]").forEach(function (btn) {
            btn.addEventListener("click", function () {
              const i = parseInt(btn.getAttribute("data-sec-up"), 10);
              if (i > 0) {
                const tmp = tpl.sections[i - 1];
                tpl.sections[i - 1] = tpl.sections[i];
                tpl.sections[i] = tmp;
                renderSectionOrder();
                readLiveTpl();
              }
            });
          });

          wrap.querySelectorAll("[data-sec-dn]").forEach(function (btn) {
            btn.addEventListener("click", function () {
              const i = parseInt(btn.getAttribute("data-sec-dn"), 10);
              if (i < tpl.sections.length - 1) {
                const tmp = tpl.sections[i + 1];
                tpl.sections[i + 1] = tpl.sections[i];
                tpl.sections[i] = tmp;
                renderSectionOrder();
                readLiveTpl();
              }
            });
          });
        }

        function readLiveTpl() {
          tpl.accent = document.getElementById("tdAccent").value;
          tpl.headerBg = document.getElementById("tdHeaderBg").value;
          tpl.font = document.getElementById("tdFont").value;
          tpl.fontSize = parseInt(document.getElementById("tdSize").value, 10) || 13;
          tpl.footerText = document.getElementById("tdFooter").value;
          const termsEl = document.getElementById("tdTermsLibrary");
          if (termsEl) {
            sampleVoucher.notes = termsEl.value.trim();
          }
          tpl.fields = {
            showLogo: document.getElementById("fLogo").checked,
            showGst: document.getElementById("fGst").checked,
            showHsn: document.getElementById("fHsn").checked,
            showDiscount: document.getElementById("fDisc").checked,
            showShipping: document.getElementById("fShip").checked,
            showAmountWords: document.getElementById("fWords").checked,
            showTaxSummary: document.getElementById("fTaxSum").checked,
            showBank: document.getElementById("fBank").checked,
            showTerms: document.getElementById("fTerms").checked,
            showStamp: document.getElementById("fStamp").checked,
            showSignature: document.getElementById("fSig").checked
          };
          document.getElementById("tdPreviewBox").innerHTML = renderDocumentHtml(
            sampleVoucher,
            business,
            { name: "Mehta Residency & Studio", phone: "9876543210", gstin: "24ABCDE1234F1Z5", address: "C.G. Road, Ahmedabad", shippingAddress: "Showroom Site, Surat" },
            tpl
          );
        }

        renderSectionOrder();
        readLiveTpl();

        ["tdAccent", "tdHeaderBg", "tdFont", "tdSize", "tdFooter", "tdTermsLibrary", "fLogo", "fGst", "fHsn", "fDisc", "fShip", "fWords", "fTaxSum", "fBank", "fTerms", "fStamp", "fSig"].forEach(function (id) {
          const el = document.getElementById(id);
          if (el) el.addEventListener("input", readLiveTpl);
          if (el) el.addEventListener("change", readLiveTpl);
        });

        document.querySelectorAll("[data-td-cat]").forEach(function (btn) {
          btn.addEventListener("click", function () {
            activeCategory = btn.getAttribute("data-td-cat");
            const defId = docSettings.defaultTemplateByCategory && docSettings.defaultTemplateByCategory[activeCategory];
            showEditor(defId);
          });
        });

        document.querySelectorAll("[data-td-card]").forEach(function (cardBtn) {
          cardBtn.addEventListener("click", function () {
            showEditor(cardBtn.getAttribute("data-td-card"));
          });
        });

        document.querySelectorAll("[data-tc-pack]").forEach(function (pkBtn) {
          pkBtn.addEventListener("click", function () {
            const pk = READYMADE_TC_PACKS.find(function (p) { return p.id === pkBtn.getAttribute("data-tc-pack"); });
            const el = document.getElementById("tdTermsLibrary");
            if (pk && el) {
              el.value = pk.lines.join("\n");
              readLiveTpl();
            }
          });
        });

        const saveTermsBtn = document.getElementById("tdSaveTermsBtn");
        if (saveTermsBtn) {
          saveTermsBtn.addEventListener("click", function () {
            const raw = (document.getElementById("tdTermsLibrary").value || "")
              .split(/\r?\n/)
              .map(function (s) { return s.trim(); })
              .filter(Boolean);
            docSettings.termsLibrary = raw;
            docSettings.updatedAt = new Date().toISOString();
            global.PBM_DB.put("docSettings", docSettings).then(function () {
              app.showToast("Default Terms & Conditions updated!", false);
            });
          });
        }

        document.getElementById("tdSetDefaultBtn").addEventListener("click", function () {
          readLiveTpl();
          const now = new Date().toISOString();
          tpl.businessId = businessId;
          tpl.updatedAt = now;
          if (!docSettings.defaultTemplateByCategory) docSettings.defaultTemplateByCategory = {};
          docSettings.defaultTemplateByCategory[activeCategory] = tpl.id;
          docSettings.updatedAt = now;

          Promise.all([
            global.PBM_DB.put("templates", tpl),
            global.PBM_DB.put("docSettings", docSettings)
          ]).then(function () {
            app.showToast("Default template saved for " + activeCategory, false);
          });
        });

        document.getElementById("tdSaveCustomBtn").addEventListener("click", function () {
          readLiveTpl();
          const now = new Date().toISOString();
          const customId = global.PBM_DB.generateId("tpl");
          const customTpl = Object.assign({}, tpl, {
            id: customId,
            businessId: businessId,
            category: activeCategory,
            name: "Custom: " + tpl.name.replace(/^Custom:\s*/, ""),
            isBuiltin: false,
            createdAt: now,
            updatedAt: now
          });
          global.PBM_DB.put("templates", customTpl).then(function () {
            templates.push(customTpl);
            app.showToast("Custom template saved!", false);
            showEditor(customId);
          });
        });
      }

      const startId = docSettings.defaultTemplateByCategory && docSettings.defaultTemplateByCategory[activeCategory];
      showEditor(startId);
    });
  }

  function render(viewContainer, contextStripHtml, initialCategory) {
    const app = global.PBM_APP;
    const businessId = app.getActiveBusinessId();
    const business = app.getActiveBusiness();
    const state = global.__pbmTplViewState || {
      category: initialCategory || "INVOICE",
      selectedId: ""
    };
    if (initialCategory) state.category = initialCategory;
    global.__pbmTplViewState = state;

    return Promise.all([
      getTemplatesForBusiness(businessId),
      global.PBM_DB.getByBusiness("docSettings", businessId)
    ]).then(function (results) {
      const templates = results[0];
      const docSettings = results[1][0] || global.PBM_DB.getDefaultDocSettings(businessId);

      function renderPage() {
        const activeCategory = state.category || "INVOICE";
        const catTemplates = templates.filter(function (t) {
          if (activeCategory === "QUOTATION") return t.category === "QUOTATION";
          if (activeCategory === "RECEIPT") return t.category === "RECEIPT" || t.category === "INVOICE";
          if (activeCategory === "OTHER") return t.category === "OTHER" || t.category === "INVOICE" || t.category === "QUOTATION";
          return t.category === "INVOICE";
        });

        const defCatId = docSettings.defaultTemplateByCategory && docSettings.defaultTemplateByCategory[activeCategory];
        const tpl = JSON.parse(
          JSON.stringify(
            catTemplates.find(function (t) { return t.id === state.selectedId; }) ||
              catTemplates.find(function (t) { return t.id === defCatId; }) ||
              catTemplates[0] ||
              templates[0]
          )
        );
        state.selectedId = tpl.id;
        if (!tpl.fields) tpl.fields = Object.assign({}, DEFAULT_FIELDS);
        if (!Array.isArray(tpl.sections) || tpl.sections.length === 0) tpl.sections = DEFAULT_SECTIONS.slice();

        const sampleVoucherType =
          activeCategory === "QUOTATION"
            ? "QUOTATION"
            : activeCategory === "RECEIPT"
            ? "RECEIPT"
            : activeCategory === "OTHER"
            ? "CHALLAN"
            : "SALE_INVOICE";

        const sampleVoucher = {
          voucherType: sampleVoucherType,
          voucherNo: activeCategory === "QUOTATION" ? "PF/QTN/26-27/014" : activeCategory === "RECEIPT" ? "PF/REC/26-27/018" : "PF/INV/26-27/042",
          date: new Date().toISOString().slice(0, 10),
          dueDate: new Date().toISOString().slice(0, 10),
          partyName: "Mehta Residency & Studio",
          gstMode: "GST",
          supplyType: "INTRA",
          placeOfSupply: (business && business.stateName) || "Gujarat",
          paymentTerms: "Net 15 Days",
          items:
            sampleVoucherType === "RECEIPT"
              ? []
              : [
                  { name: "Teakwood Modular Wardrobe (3-Door)", desc: "19mm BWR Marine Ply · Soft-Close", hsn: "9403", qty: 2, unit: "Nos", rate: 28500, discountPct: 5, gstRate: 18, lineTotal: 63897 },
                  { name: "Site Delivery & Precision Installation", desc: "Calibration & polish finishing", hsn: "9954", qty: 1, unit: "Job", rate: 3500, discountPct: 0, gstRate: 18, lineTotal: 4130 }
                ],
          subtotal: 57650,
          taxTotal: 10377,
          shippingCharge: 800,
          roundOff: 0,
          grandTotal: 68827,
          amount: 68827,
          paidAmount: sampleVoucherType === "RECEIPT" ? 68827 : 25000,
          notes: (docSettings.termsLibrary || []).join("\n") || "Payment due within 15 days."
        };

        const galleryHtml = catTemplates
          .map(function (t) {
            const isDef = docSettings.defaultTemplateByCategory && docSettings.defaultTemplateByCategory[activeCategory] === t.id;
            const isSel = t.id === tpl.id;
            return `
              <button type="button" class="tpl-card ${isSel ? "is-selected" : ""}" data-pv-card="${app.escapeHtml(t.id)}">
                ${renderTemplateMiniThumb(t)}
                <div style="font-size:0.8rem;font-weight:700;color:var(--text-primary);line-height:1.25;word-break:break-word;">${app.escapeHtml(t.name)}</div>
                <div style="font-size:0.72rem;color:var(--text-muted);">
                  ${app.escapeHtml(t.paper || "A4")}${isDef ? " · Active Default" : ""}
                </div>
              </button>
            `;
          })
          .join("");

        const tcPackChips = READYMADE_TC_PACKS.map(function (pk) {
          return `<button type="button" class="secondary-btn" data-pv-tcpack="${app.escapeHtml(pk.id)}" style="min-height:32px;padding:4px 8px;font-size:0.75rem;">${app.escapeHtml(pk.label)}</button>`;
        }).join("");

        viewContainer.innerHTML = `
          ${contextStripHtml}
          <div class="card">
            <div class="card-header-row">
              <div>
                <h2 class="card-title">Invoice &amp; Document Templates Studio</h2>
                <p class="card-subtitle">Choose from ${templates.length} readymade layouts, customize colors, fields &amp; T&amp;C, and apply directly to invoices.</p>
              </div>
              <div class="btn-row">
                <button id="pvUseTemplateBtn" class="primary-btn" type="button">+ Create ${activeCategory === "QUOTATION" ? "Quotation" : activeCategory === "RECEIPT" ? "Receipt" : "Invoice"} with Template</button>
                <button id="pvSamplePdfBtn" class="secondary-btn" type="button">Download Sample PDF</button>
              </div>
            </div>

            <div class="segmented-bar" style="margin-top:4px;">
              <button class="seg-btn ${activeCategory === "INVOICE" ? "active" : ""}" data-pv-cat="INVOICE" type="button">Invoice Templates (${templates.filter(function (x) { return x.category === "INVOICE"; }).length})</button>
              <button class="seg-btn ${activeCategory === "QUOTATION" ? "active" : ""}" data-pv-cat="QUOTATION" type="button">Quotation Templates (${templates.filter(function (x) { return x.category === "QUOTATION"; }).length})</button>
              <button class="seg-btn ${activeCategory === "RECEIPT" ? "active" : ""}" data-pv-cat="RECEIPT" type="button">Receipts (${EXTRA_PRESETS.filter(function (x) { return x.category === "RECEIPT"; }).length})</button>
              <button class="seg-btn ${activeCategory === "OTHER" ? "active" : ""}" data-pv-cat="OTHER" type="button">Challans &amp; Others</button>
            </div>
          </div>

          <div class="card">
            <h3 class="card-title" style="margin-bottom:10px;">Readymade Designs — Tap to Preview</h3>
            <div class="tpl-gallery-grid">${galleryHtml}</div>
          </div>

          <div class="tpl-studio-grid">
            <div class="card">
              <h3 class="card-title">Customize Selected Template: ${app.escapeHtml(tpl.name)}</h3>
              <div class="form-grid" style="margin-top:10px;">
                <div class="form-row-2">
                  <div class="form-group">
                    <label class="form-label" for="pvAccent">Accent Color</label>
                    <input id="pvAccent" class="form-input" type="color" value="${tpl.accent || "#0f4c81"}" />
                  </div>
                  <div class="form-group">
                    <label class="form-label" for="pvHeaderBg">Header BG Color</label>
                    <input id="pvHeaderBg" class="form-input" type="color" value="${tpl.headerBg || "#f1f5f9"}" />
                  </div>
                </div>
                <div class="form-row-2">
                  <div class="form-group">
                    <label class="form-label" for="pvFont">Font Style</label>
                    <select id="pvFont" class="form-select">
                      <option value="sans" ${tpl.font === "sans" ? "selected" : ""}>Modern Sans</option>
                      <option value="serif" ${tpl.font === "serif" ? "selected" : ""}>Classic Serif</option>
                      <option value="mono" ${tpl.font === "mono" ? "selected" : ""}>Technical Mono</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label class="form-label" for="pvSize">Font Size (px)</label>
                    <input id="pvSize" class="form-input" type="number" min="10" max="16" value="${tpl.fontSize || 13}" />
                  </div>
                </div>

                <div class="form-group">
                  <label class="form-label">Visible Fields &amp; GST Sections</label>
                  <div class="btn-row">
                    <label class="check-chip"><input type="checkbox" id="pvLogo" ${tpl.fields.showLogo ? "checked" : ""}/> Logo</label>
                    <label class="check-chip"><input type="checkbox" id="pvGst" ${tpl.fields.showGst ? "checked" : ""}/> GST</label>
                    <label class="check-chip"><input type="checkbox" id="pvHsn" ${tpl.fields.showHsn ? "checked" : ""}/> HSN</label>
                    <label class="check-chip"><input type="checkbox" id="pvDisc" ${tpl.fields.showDiscount ? "checked" : ""}/> Discount</label>
                    <label class="check-chip"><input type="checkbox" id="pvShip" ${tpl.fields.showShipping ? "checked" : ""}/> Shipping</label>
                    <label class="check-chip"><input type="checkbox" id="pvWords" ${tpl.fields.showAmountWords !== false ? "checked" : ""}/> In Words</label>
                    <label class="check-chip"><input type="checkbox" id="pvTaxSum" ${tpl.fields.showTaxSummary !== false ? "checked" : ""}/> Tax Table</label>
                    <label class="check-chip"><input type="checkbox" id="pvBank" ${tpl.fields.showBank ? "checked" : ""}/> Bank</label>
                    <label class="check-chip"><input type="checkbox" id="pvTerms" ${tpl.fields.showTerms ? "checked" : ""}/> Terms (T&amp;C)</label>
                    <label class="check-chip"><input type="checkbox" id="pvStamp" ${tpl.fields.showStamp ? "checked" : ""}/> Stamp</label>
                    <label class="check-chip"><input type="checkbox" id="pvSig" ${tpl.fields.showSignature ? "checked" : ""}/> Sign</label>
                  </div>
                </div>

                <div class="form-group">
                  <label class="form-label">Section Order</label>
                  <div id="pvSectionsWrap" class="section-order-list"></div>
                </div>

                <div class="form-group">
                  <label class="form-label" for="pvTermsLib">Editable T&amp;C Packs &amp; Default Terms</label>
                  <div class="btn-row" style="margin-bottom:6px;">${tcPackChips}</div>
                  <textarea id="pvTermsLib" class="form-textarea" rows="3">${app.escapeHtml((docSettings.termsLibrary || []).join("\n"))}</textarea>
                </div>

                <div class="form-group">
                  <label class="form-label" for="pvFooter">Custom Footer Line</label>
                  <input id="pvFooter" class="form-input" type="text" value="${app.escapeHtml(tpl.footerText || "")}" />
                </div>

                <div class="btn-row">
                  <button id="pvSetDefBtn" class="primary-btn" type="button">Set Default for ${activeCategory}</button>
                  <button id="pvSaveCustomBtn" class="secondary-btn" type="button">Save as Custom</button>
                  <button id="pvSaveTermsBtn" class="secondary-btn" type="button">Save T&amp;C</button>
                </div>
              </div>
            </div>

            <div class="card">
              <div class="card-header-row">
                <h3 class="card-title">Live Document Preview (${app.escapeHtml(tpl.paper || "A4")})</h3>
                <span class="list-item-meta">${app.escapeHtml(tpl.name)}</span>
              </div>
              <div class="pbm-preview-paper" style="max-height:680px;">
                <div id="pvLiveBox"></div>
              </div>
            </div>
          </div>
        `;

        function renderPvSections() {
          const wrap = document.getElementById("pvSectionsWrap");
          if (!wrap) return;
          wrap.innerHTML = tpl.sections
            .map(function (secKey, idx) {
              return `
                <div class="section-order-row">
                  <span>${idx + 1}. ${app.escapeHtml(SECTION_LABELS[secKey] || secKey)}</span>
                  <div class="btn-row">
                    <button class="secondary-btn" style="min-height:30px;padding:3px 9px;" type="button" data-pvs-up="${idx}" ${idx === 0 ? "disabled" : ""}>▲</button>
                    <button class="secondary-btn" style="min-height:30px;padding:3px 9px;" type="button" data-pvs-dn="${idx}" ${idx === tpl.sections.length - 1 ? "disabled" : ""}>▼</button>
                  </div>
                </div>
              `;
            })
            .join("");

          wrap.querySelectorAll("[data-pvs-up]").forEach(function (btn) {
            btn.addEventListener("click", function () {
              const i = parseInt(btn.getAttribute("data-pvs-up"), 10);
              if (i > 0) {
                const tmp = tpl.sections[i - 1];
                tpl.sections[i - 1] = tpl.sections[i];
                tpl.sections[i] = tmp;
                renderPvSections();
                syncLivePreview();
              }
            });
          });

          wrap.querySelectorAll("[data-pvs-dn]").forEach(function (btn) {
            btn.addEventListener("click", function () {
              const i = parseInt(btn.getAttribute("data-pvs-dn"), 10);
              if (i < tpl.sections.length - 1) {
                const tmp = tpl.sections[i + 1];
                tpl.sections[i + 1] = tpl.sections[i];
                tpl.sections[i] = tmp;
                renderPvSections();
                syncLivePreview();
              }
            });
          });
        }

        function syncLivePreview() {
          tpl.accent = document.getElementById("pvAccent").value;
          tpl.headerBg = document.getElementById("pvHeaderBg").value;
          tpl.font = document.getElementById("pvFont").value;
          tpl.fontSize = parseInt(document.getElementById("pvSize").value, 10) || 13;
          tpl.footerText = document.getElementById("pvFooter").value;
          const termsEl = document.getElementById("pvTermsLib");
          if (termsEl) sampleVoucher.notes = termsEl.value.trim();
          tpl.fields = {
            showLogo: document.getElementById("pvLogo").checked,
            showGst: document.getElementById("pvGst").checked,
            showHsn: document.getElementById("pvHsn").checked,
            showDiscount: document.getElementById("pvDisc").checked,
            showShipping: document.getElementById("pvShip").checked,
            showAmountWords: document.getElementById("pvWords").checked,
            showTaxSummary: document.getElementById("pvTaxSum").checked,
            showBank: document.getElementById("pvBank").checked,
            showTerms: document.getElementById("pvTerms").checked,
            showStamp: document.getElementById("pvStamp").checked,
            showSignature: document.getElementById("pvSig").checked
          };
          const liveBox = document.getElementById("pvLiveBox");
          if (liveBox) {
            liveBox.innerHTML = renderDocumentHtml(
              sampleVoucher,
              business,
              { name: "Mehta Residency & Studio", phone: "9876543210", gstin: "24ABCDE1234F1Z5", address: "C.G. Road, Ahmedabad", shippingAddress: "Showroom Site, Surat" },
              tpl
            );
          }
        }

        renderPvSections();
        syncLivePreview();

        ["pvAccent", "pvHeaderBg", "pvFont", "pvSize", "pvFooter", "pvTermsLib", "pvLogo", "pvGst", "pvHsn", "pvDisc", "pvShip", "pvWords", "pvTaxSum", "pvBank", "pvTerms", "pvStamp", "pvSig"].forEach(function (id) {
          const el = document.getElementById(id);
          if (el) {
            el.addEventListener("input", syncLivePreview);
            el.addEventListener("change", syncLivePreview);
          }
        });

        viewContainer.querySelectorAll("[data-pv-cat]").forEach(function (btn) {
          btn.addEventListener("click", function () {
            state.category = btn.getAttribute("data-pv-cat");
            state.selectedId = "";
            renderPage();
          });
        });

        viewContainer.querySelectorAll("[data-pv-card]").forEach(function (btn) {
          btn.addEventListener("click", function () {
            state.selectedId = btn.getAttribute("data-pv-card");
            renderPage();
          });
        });

        viewContainer.querySelectorAll("[data-pv-tcpack]").forEach(function (btn) {
          btn.addEventListener("click", function () {
            const pk = READYMADE_TC_PACKS.find(function (p) { return p.id === btn.getAttribute("data-pv-tcpack"); });
            const el = document.getElementById("pvTermsLib");
            if (pk && el) {
              el.value = pk.lines.join("\n");
              syncLivePreview();
            }
          });
        });

        document.getElementById("pvSaveTermsBtn").addEventListener("click", function () {
          const raw = (document.getElementById("pvTermsLib").value || "")
            .split(/\r?\n/)
            .map(function (s) { return s.trim(); })
            .filter(Boolean);
          docSettings.termsLibrary = raw;
          docSettings.updatedAt = new Date().toISOString();
          global.PBM_DB.put("docSettings", docSettings).then(function () {
            app.showToast("Default Terms & Conditions updated!", false);
          });
        });

        document.getElementById("pvSetDefBtn").addEventListener("click", function () {
          syncLivePreview();
          const now = new Date().toISOString();
          tpl.businessId = businessId;
          tpl.updatedAt = now;
          if (!docSettings.defaultTemplateByCategory) docSettings.defaultTemplateByCategory = {};
          docSettings.defaultTemplateByCategory[activeCategory] = tpl.id;
          docSettings.updatedAt = now;

          Promise.all([
            global.PBM_DB.put("templates", tpl),
            global.PBM_DB.put("docSettings", docSettings)
          ]).then(function () {
            const idx = templates.findIndex(function (x) { return x.id === tpl.id; });
            if (idx !== -1) templates[idx] = JSON.parse(JSON.stringify(tpl));
            app.showToast("Default template saved for " + activeCategory, false);
            renderPage();
          });
        });

        document.getElementById("pvSaveCustomBtn").addEventListener("click", function () {
          syncLivePreview();
          const now = new Date().toISOString();
          const customId = global.PBM_DB.generateId("tpl");
          const customTpl = Object.assign({}, tpl, {
            id: customId,
            businessId: businessId,
            category: activeCategory,
            name: "Custom: " + tpl.name.replace(/^Custom:\s*/, ""),
            isBuiltin: false,
            createdAt: now,
            updatedAt: now
          });
          global.PBM_DB.put("templates", customTpl).then(function () {
            templates.push(customTpl);
            state.selectedId = customId;
            app.showToast("Custom template saved!", false);
            renderPage();
          });
        });

        document.getElementById("pvUseTemplateBtn").addEventListener("click", function () {
          const targetDocType = activeCategory === "QUOTATION" ? "QUOTATION" : activeCategory === "RECEIPT" ? "RECEIPT" : "SALE_INVOICE";
          if (global.PBM_BILLING && typeof global.PBM_BILLING.openDocumentModal === "function") {
            global.PBM_BILLING.openDocumentModal(null, targetDocType, tpl.id);
          } else {
            app.navigateTo("billing");
          }
        });

        document.getElementById("pvSamplePdfBtn").addEventListener("click", function () {
          syncLivePreview();
          if (global.PBM_PRINT && typeof global.PBM_PRINT.downloadPdfFromHtml === "function") {
            const docHtml = document.getElementById("pvLiveBox").innerHTML;
            global.PBM_PRINT.downloadPdfFromHtml(docHtml, "Sample_" + tpl.name, { isThermal: tpl.paper === "THERMAL" });
          }
        });
      }

      renderPage();
    });
  }

  global.PBM_TEMPLATES = {
    INVOICE_PRESETS: INVOICE_PRESETS,
    QUOTATION_PRESETS: QUOTATION_PRESETS,
    READYMADE_TC_PACKS: READYMADE_TC_PACKS,
    getDocCategory: getDocCategory,
    getTemplatesForBusiness: getTemplatesForBusiness,
    resolveTemplateForVoucher: resolveTemplateForVoucher,
    renderTemplateMiniThumb: renderTemplateMiniThumb,
    renderDocumentHtml: renderDocumentHtml,
    openTemplateDesignerModal: openTemplateDesignerModal,
    render: render
  };
})(window);
