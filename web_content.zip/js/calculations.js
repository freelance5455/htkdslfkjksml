const fmt=n=>new Intl.NumberFormat("fa-IR",{maximumFractionDigits:2}).format(Number(n)||0);
const money=n=>fmt(Math.round(Number(n)||0))+" ریال";
const num=v=>Math.max(0,Number(v)||0);
function calcInvoice(inv){const subtotal=(inv.rows||[]).reduce((s,r)=>s+num(r.weight)*num(r.unitPrice),0),previous=num(inv.previous),discount=num(inv.discount),taxRate=Math.min(100,num(inv.taxRate)),tax=Math.max(0,(subtotal+previous)*taxRate/100),total=Math.max(0,subtotal+previous+tax-discount);return{subtotal,previous,discount,tax,total}}
function toPersianDate(d=new Date()){try{return new Intl.DateTimeFormat("fa-IR-u-ca-persian",{year:"numeric",month:"2-digit",day:"2-digit"}).format(d)}catch{return d.toLocaleDateString("fa-IR")}}
