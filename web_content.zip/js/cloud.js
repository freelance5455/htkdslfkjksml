/* نسخ احتياطي إضافي: مشاركة من الموبايل + Dropbox (PKCE) + تشفير اختياري للملف بكلمة مرور */
(function(){
 var $=function(id){return document.getElementById(id)},TE=new TextEncoder(),TD=new TextDecoder();
 var K_ENC='ayman_meta_enc_backups',K_APP='ayman_dbx_appkey',K_RT='ayman_dbx_refresh',at=null,atExp=0;
 function b64(u){u=new Uint8Array(u);var s='';for(var i=0;i<u.length;i+=32768)s+=String.fromCharCode.apply(null,u.subarray(i,i+32768));return btoa(s)}
 function unb64(s){var b=atob(s),u=new Uint8Array(b.length);for(var i=0;i<b.length;i++)u[i]=b.charCodeAt(i);return u}
 function b64u(u){return b64(u).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'')}
 /* ---- تشفير ملف النسخة ---- */
 async function key(pass,salt,iter){var km=await crypto.subtle.importKey('raw',TE.encode(pass),'PBKDF2',false,['deriveKey']);return crypto.subtle.deriveKey({name:'PBKDF2',salt:salt,iterations:iter,hash:'SHA-256'},km,{name:'AES-GCM',length:256},false,['encrypt','decrypt'])}
 async function encrypt(text,pass){var salt=crypto.getRandomValues(new Uint8Array(16)),iv=crypto.getRandomValues(new Uint8Array(12)),iter=250000;var ct=await crypto.subtle.encrypt({name:'AES-GCM',iv:iv},await key(pass,salt,iter),TE.encode(text));return JSON.stringify({format:'AYMAN-ENC-1',iter:iter,salt:b64(salt),iv:b64(iv),data:b64(ct)})}
 function parseEnc(t){try{var m=JSON.parse(t);return m&&m.format==='AYMAN-ENC-1'?m:null}catch(e){return null}}
 async function decrypt(m,pass){return TD.decode(await crypto.subtle.decrypt({name:'AES-GCM',iv:unb64(m.iv)},await key(pass,unb64(m.salt),m.iter),unb64(m.data)))}
 function ask(title,labels){return new Promise(function(res){var o=document.createElement('div');o.style.cssText='position:fixed;inset:0;z-index:9999;background:#000a;display:flex;align-items:center;justify-content:center;padding:20px;direction:rtl';var b=document.createElement('div');b.className='card';b.style.cssText='width:100%;max-width:380px;padding:18px;background:#14142a;color:#f6f5ff;border-radius:20px';b.innerHTML='<h3 style="margin:0 0 12px">'+title+'</h3>'+labels.map(function(l,i){return '<label style="display:block;margin:8px 0 4px">'+l+'</label><input type="password" style="width:100%;box-sizing:border-box">'}).join('')+'<div class="actions" style="margin-top:14px"><button type="button" class="primary" data-ok>موافق</button><button type="button" data-no>إلغاء</button></div>';o.appendChild(b);document.body.appendChild(o);var ins=b.querySelectorAll('input');ins[0].focus();b.querySelector('[data-ok]').onclick=function(){var v=[].map.call(ins,function(x){return x.value});o.remove();res(v)};b.querySelector('[data-no]').onclick=function(){o.remove();res(null)}})}
 var day=function(){return new Date().toISOString().slice(0,10)};
 /* يبني نص النسخة (مشفّراً إن طُلب). يعيد null عند الإلغاء */
 async function build(){var text=JSON.stringify(currentBackupObject(),null,2),enc=$('cbEnc')&&$('cbEnc').checked;if(!enc)return {text:text,name:'ayman-cashflow-backup-'+day()+'.json'};
  var v=await ask('تشفير النسخة',['كلمة مرور للملف (6 أحرف على الأقل)','تأكيد كلمة المرور']);if(!v)return null;
  if(v[0].length<6||v[0]!==v[1]){alert('كلمة المرور قصيرة أو التأكيد لا يطابقها.');return null}
  return {text:await encrypt(text,v[0]),name:'ayman-cashflow-backup-'+day()+'.enc.json'}}
 /* ---- مشاركة من الموبايل ---- */
 async function share(){try{var b=await build();if(!b)return;
  var f=new File([b.text],b.name,{type:'application/json'});if(!(navigator.canShare&&navigator.canShare({files:[f]})))f=new File([b.text],b.name,{type:'text/plain'});
  if(navigator.canShare&&navigator.canShare({files:[f]})){await navigator.share({files:[f],title:'نسخة AYMAN CASHFLOW'});say('تمت المشاركة. اختر Drive أو Dropbox أو أي تطبيق لحفظ الملف.')}
  else{var a=document.createElement('a');a.href=URL.createObjectURL(new Blob([b.text],{type:'application/json'}));a.download=b.name;a.click();setTimeout(function(){URL.revokeObjectURL(a.href)},1000);say('المتصفح لا يدعم المشاركة هنا، فنُزّل الملف بدلاً منها.')}}
  catch(e){if(e&&e.name!=='AbortError')say('تعذّرت المشاركة: '+e.message)}}
 /* ---- Dropbox ---- */
 function redirectUri(){return location.origin+location.pathname.replace(/index\.html$/,'')}
 async function authUrl(appKey){var ver=b64u(crypto.getRandomValues(new Uint8Array(48))),st=b64u(crypto.getRandomValues(new Uint8Array(16)));
  var ch=b64u(await crypto.subtle.digest('SHA-256',TE.encode(ver)));localStorage.setItem('ayman_dbx_pkce',JSON.stringify({v:ver,s:st,t:Date.now()}));
  return 'https://www.dropbox.com/oauth2/authorize?'+new URLSearchParams({client_id:appKey,response_type:'code',token_access_type:'offline',code_challenge:ch,code_challenge_method:'S256',redirect_uri:redirectUri(),state:st})}
 async function connect(){var k=$('cbAppKey').value.trim();if(!k){say('أدخل App key من لوحة Dropbox أولاً.');return}AStore.setItem(K_APP,k);
  var u=await authUrl(k);await new Promise(function(r){setTimeout(r,400)});location.href=u}
 async function finishAuth(){var q=new URLSearchParams(location.search);if(!q.get('state')||!(q.get('code')||q.get('error')))return;
  var p;try{p=JSON.parse(localStorage.getItem('ayman_dbx_pkce')||'null')}catch(e){}history.replaceState(null,'',location.pathname);
  if(!p||p.s!==q.get('state')||Date.now()-p.t>9e5){say('تعذّر إكمال الربط: جلسة غير صالحة. أعد المحاولة.');return}localStorage.removeItem('ayman_dbx_pkce');
  if(q.get('error')){say('أُلغي الربط: '+(q.get('error_description')||q.get('error')));return}
  try{var r=await fetch('https://api.dropboxapi.com/oauth2/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({code:q.get('code'),grant_type:'authorization_code',code_verifier:p.v,client_id:AStore.getItem(K_APP)||'',redirect_uri:redirectUri()})});var j=await r.json();
   if(!r.ok||!j.refresh_token)throw new Error(j.error_description||j.error||r.status);AStore.setItem(K_RT,j.refresh_token);at=j.access_token;atExp=Date.now()+j.expires_in*1000;say('تم ربط Dropbox بنجاح ✅');refreshUi()}catch(e){say('فشل ربط Dropbox: '+e.message)}}
 async function token(){if(at&&Date.now()<atExp-60000)return at;var rt=AStore.getItem(K_RT),k=AStore.getItem(K_APP);if(!rt||!k)throw new Error('اربط Dropbox أولاً');
  var r=await fetch('https://api.dropboxapi.com/oauth2/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({grant_type:'refresh_token',refresh_token:rt,client_id:k})}),j=await r.json();
  if(!r.ok)throw new Error('تعذّر تجديد الاتصال بـ Dropbox ('+(j.error_description||j.error||r.status)+'). أعد الربط.');at=j.access_token;atExp=Date.now()+j.expires_in*1000;return at}
 var asc=function(o){return JSON.stringify(o).replace(/[\u007f-\uffff]/g,function(c){return '\\u'+('0000'+c.charCodeAt(0).toString(16)).slice(-4)})};
 async function up(path,text){var r=await fetch('https://content.dropboxapi.com/2/files/upload',{method:'POST',headers:{Authorization:'Bearer '+await token(),'Content-Type':'application/octet-stream','Dropbox-API-Arg':asc({path:path,mode:'overwrite',mute:true})},body:new Blob([text])});if(!r.ok)throw new Error('Dropbox رفض الرفع ('+r.status+'): '+(await r.text()).slice(0,120))}
 async function dbxSave(){try{var b=await build();if(!b)return;say('جارٍ الرفع إلى Dropbox...');var ext=b.name.indexOf('.enc.')>0?'.enc.json':'.json';
  await up('/ayman-cashflow-latest'+ext,b.text);await up('/archive/ayman-cashflow-'+day()+ext,b.text);var m=JSON.parse(AStore.getItem('ayman_meta_dbx_last')||'null');AStore.setItem('ayman_meta_dbx_last',JSON.stringify(new Date().toISOString()));say('تم الحفظ في Dropbox ✅ ('+(ext==='.json'?'غير مشفّر':'مشفّر')+')')}catch(e){say('فشل الحفظ في Dropbox: '+e.message)}}
 async function dl(path){var r=await fetch('https://content.dropboxapi.com/2/files/download',{method:'POST',headers:{Authorization:'Bearer '+await token(),'Dropbox-API-Arg':asc({path:path})}});return r.ok?await r.text():null}
 async function dbxRestore(){try{say('جارٍ التنزيل من Dropbox...');var t=await dl('/ayman-cashflow-latest.enc.json');if(t===null)t=await dl('/ayman-cashflow-latest.json');if(t===null){say('لا توجد نسخة في Dropbox بعد.');return}
  var dt=new DataTransfer();dt.items.add(new File([t],parseEnc(t)?'dropbox-latest.enc.json':'dropbox-latest.json',{type:'application/json'}));$('restoreFile').files=dt.files;await previewRestore();say('نُزّلت النسخة. راجع المعاينة أعلاه ثم اضغط "استعادة النسخة الكاملة".')}catch(e){say('فشلت الاستعادة من Dropbox: '+e.message)}}
 /* ---- استعادة ملفات مشفّرة من الملف المحلي ---- */
 var opr=window.previewRestore;
 window.previewRestore=async function(){var f=$('restoreFile').files[0];
  if(f&&/\.json$/i.test(f.name)){var m=parseEnc(await f.text());
   if(m){var v=await ask('ملف النسخة مشفّر',['كلمة المرور']);if(!v){$('restorePreview').textContent='أُلغيت الاستعادة.';return}
    try{var plain=await decrypt(m,v[0])}catch(e){$('restorePreview').textContent='كلمة المرور غير صحيحة أو الملف تالف.';return}
    var dt=new DataTransfer();dt.items.add(new File([plain],f.name.replace(/\.enc\.json$/i,'.json'),{type:'application/json'}));$('restoreFile').files=dt.files}}
  return opr.apply(this,arguments)};
 /* ---- الواجهة ---- */
 function say(t){var e=$('cbStatus');if(e)e.textContent=t}
 function refreshUi(){var on=!!AStore.getItem(K_RT);var c=$('cbConn');if(!c)return;c.textContent=on?'فصل Dropbox':'ربط Dropbox';c.className=on?'danger':'primary';$('cbSave').disabled=$('cbRest').disabled=!on}
 var anchor=$('storageCard');
 if(anchor){var c=document.createElement('div');c.className='section card';c.style.marginTop='16px';
  c.innerHTML='<h2>نسخ احتياطي إضافي</h2><p class="muted">احفظ نسخة خارج Drive: عبر قائمة المشاركة في الموبايل أو في Dropbox.</p>'+
  '<p><label><input type="checkbox" id="cbEnc"> تشفير الملف بكلمة مرور (موصى به؛ تُطلب كل مرة ولا تُخزَّن)</label></p>'+
  '<div class="actions"><button type="button" class="primary" id="cbShare">📤 مشاركة النسخة من الموبايل</button></div>'+
  '<h3 style="margin:18px 0 6px">Dropbox</h3><input id="cbAppKey" placeholder="App key من Dropbox" style="width:100%;box-sizing:border-box;margin-bottom:8px">'+
  '<div class="actions"><button type="button" id="cbConn">ربط Dropbox</button><button type="button" id="cbSave">حفظ في Dropbox</button><button type="button" id="cbRest">استعادة من Dropbox</button></div>'+
  '<p class="muted" style="font-size:12px;margin:10px 0 4px">عنوان إعادة التوجيه الذي تضيفه في إعدادات تطبيق Dropbox:</p><div class="note" id="cbUri" style="direction:ltr;word-break:break-all;user-select:all"></div><div class="muted" id="cbStatus" style="margin-top:8px"></div>'+
  '<p class="muted" style="font-size:12px">رمز الاتصال يُحفظ على هذا الجهاز. يُنصح بتشفير الملفات المرسلة خارج جهازك.</p>';
  anchor.parentNode.insertBefore(c,anchor);$('cbUri').textContent=redirectUri();$('cbAppKey').value=AStore.getItem(K_APP)||'';
  $('cbEnc').checked=AStore.getItem(K_ENC)!=='0';$('cbEnc').onchange=function(){AStore.setItem(K_ENC,this.checked?'1':'0')};
  $('cbShare').onclick=share;$('cbSave').onclick=dbxSave;$('cbRest').onclick=dbxRestore;
  $('cbConn').onclick=function(){if(AStore.getItem(K_RT)){if(confirm('فصل Dropbox عن هذا الجهاز؟')){AStore.removeItem(K_RT);at=null;refreshUi();say('تم الفصل.')}}else connect()};
  refreshUi();finishAuth().then(function(){if(new URLSearchParams(location.search).toString()===''&&localStorage.getItem('ayman_dbx_pkce')===null){}})}
 window.AymanCloud={encrypt:encrypt,decrypt:decrypt,parseEnc:parseEnc,authUrl:authUrl,redirectUri:redirectUri};
})();
