/* مشاور: کلیدهای سرویس‌ها (localStorage: study_ai_keys = {profileId: key})، پروفایل‌های سرویس در S بدون کلید، پروفایل فعال، و درخواست به سرویس فعال از راه App.providers. */
(function () {
  'use strict';
  var App = (window.App = window.App || {});
  var u = App.u;
  var store = App.store;
  var ai = (App.ai = App.ai || {});
  var KEYS_STORE = 'study_ai_keys';
  var OLD_KEY_STORE = 'study_ai_key'; // نسخه‌ی تک‌کلیدی؛ فقط برای انتقال یک‌باره
  var MAX_PROFILES = 12;
  ai.MAX_TOKENS = 4096;
  ai.MAX_STEPS = 8;
  ai.TIMEOUT_MS = 100000;
  ai.busy = false;

  // ---- کلیدها: یک شیء در localStorage، فقط از راه App.keys؛ هرگز در S یا پشتیبان ----
  function readMap() {
    try {
      var o = JSON.parse(localStorage.getItem(KEYS_STORE) || '{}');
      return o && typeof o === 'object' && !Array.isArray(o) ? o : {};
    } catch (e) { return {}; }
  }
  function writeMap(m) {
    try {
      if (Object.keys(m).length) localStorage.setItem(KEYS_STORE, JSON.stringify(m));
      else localStorage.removeItem(KEYS_STORE);
      return true;
    } catch (e) { return false; }
  }
  var keys = (App.keys = {
    get: function (id) { var v = readMap()[String(id)]; return typeof v === 'string' ? v.trim() : ''; },
    has: function (id) { return !!keys.get(id); },
    // کلید خالی یعنی پاک‌کردن؛ false اگر مرورگر نپذیرفت
    set: function (id, v) {
      var m = readMap(), k = String(id);
      v = String(v == null ? '' : v).trim();
      if (v) m[k] = v; else delete m[k];
      return writeMap(m);
    },
    any: function () {
      var m = readMap();
      return Object.keys(m).some(function (k) { return typeof m[k] === 'string' && !!m[k].trim(); });
    }
  });
  // سازگاری: App.apiKey کلید پروفایل Claude (فعال، یا اولینِ Claude) را می‌خواند و می‌نویسد
  Object.defineProperty(App, 'apiKey', {
    enumerable: true,
    configurable: true,
    get: function () { var p = ai.claudeProfile(); return p ? keys.get(p.id) : ''; },
    set: function (v) {
      var p = ai.claudeProfile();
      if (!p) {
        if (!String(v == null ? '' : v).trim()) return;
        p = ai.addProfile('claude', { name: 'Claude' });
        if (!p) return;
      }
      keys.set(p.id, v);
    }
  });

  // ---- پروفایل‌ها (در S؛ بدون کلید) ----
  function list() { return (App.S && App.S.prs) || []; }
  ai.profiles = list;
  ai.profileById = function (id) {
    return list().filter(function (p) { return String(p.id) === String(id); })[0] || null;
  };
  ai.active = function () {
    return ai.profileById(App.S && App.S.prsActive) || list()[0] || null;
  };
  ai.claudeProfile = function () {
    var a = ai.active();
    if (a && a.type === 'claude') return a;
    return list().filter(function (p) { return p.type === 'claude'; })[0] || null;
  };
  // پروفایل تازه؛ اگر پروفایل فعال بی‌کلید است، این یکی فعال می‌شود
  ai.addProfile = function (type, o) {
    o = o || {};
    var S = App.S;
    if (!S || S.prs.length >= MAX_PROFILES) return null;
    var p = store.cleanProfile({ id: u.uid(), type: type, name: o.name, base: o.base, model: o.model });
    if (!p) return null;
    var act = ai.active();
    S.prs = S.prs.concat([p]);
    if (!act || !keys.has(act.id)) S.prsActive = p.id;
    store.fixActive(S);
    App.save();
    return p;
  };
  // نام، نشانی و مدل را عوض می‌کند؛ نوع ثابت است و کلید جداست
  ai.updateProfile = function (id, o) {
    var S = App.S, idx = -1;
    S.prs.forEach(function (p, i) { if (String(p.id) === String(id)) idx = i; });
    if (idx < 0) return null;
    var old = S.prs[idx];
    var p = store.cleanProfile({
      id: old.id, type: old.type,
      name: 'name' in o ? o.name : old.name,
      base: 'base' in o ? o.base : old.base,
      model: 'model' in o ? o.model : old.model
    });
    if (!p) return null;
    S.prs = S.prs.slice(0, idx).concat([p], S.prs.slice(idx + 1));
    App.save();
    return p;
  };
  // حذف پروفایل و کلیدش؛ آخرین پروفایل نمی‌رود
  ai.removeProfile = function (id) {
    var S = App.S;
    if (S.prs.length <= 1) return false;
    S.prs = S.prs.filter(function (p) { return String(p.id) !== String(id); });
    keys.set(id, '');
    store.fixActive(S);
    App.save();
    return true;
  };
  ai.activate = function (id) {
    var p = ai.profileById(id);
    if (!p) return false;
    App.S.prsActive = p.id;
    App.save();
    return true;
  };
  ai.setModel = function (id, model) {
    var m = store.cleanModel(model);
    if (!m || !ai.profileById(id)) return false;
    ai.updateProfile(id, { model: m });
    return true;
  };
  ai.isModelId = function (m) {
    var s = String(m == null ? '' : m).trim();
    return !!s && store.cleanModel(s) === s;
  };

  // انتقال یک‌باره: کلید تک‌تایی قدیمی به پروفایل Claude می‌رود و آن کلید حذف می‌شود؛ همیشه حداقل یک پروفایل می‌ماند.
  ai.migrate = function (S, legacyModel) {
    var old = '';
    try { old = String(localStorage.getItem(OLD_KEY_STORE) || '').trim(); } catch (e) { old = ''; }
    if (old) {
      var c = ai.claudeProfile() || ai.addProfile('claude', { name: 'Claude', model: legacyModel });
      if (c && !keys.has(c.id)) keys.set(c.id, old);
      try { localStorage.removeItem(OLD_KEY_STORE); } catch (e) { /* حافظه در دسترس نیست */ }
    }
    if (!list().length) ai.addProfile('claude', { name: 'Claude', model: legacyModel });
    store.fixActive(S);
  };

  // ---- پیکربندی فعال و درخواست ----
  // پروفایل فعال با کلید، نشانی و مدل (مدل پیش‌فرض اگر خالی بود)
  ai.config = function () {
    var p = ai.active() || {};
    var type = p.type || 'claude';
    return {
      id: p.id == null ? '' : p.id,
      name: p.name || 'Claude',
      type: type,
      base: p.base || '',
      model: p.model || App.providers.defaultModel(type, p.base),
      key: p.id == null ? '' : keys.get(p.id)
    };
  };
  ai.configured = function () { return !!ai.config().key; };

  // درخواست با پروفایل فعال، یا با پروفایل داده‌شده (برای تست)؛ پاسخ همیشه به شکل Anthropic است
  ai.request = function (body, o) {
    var p = (o && o.profile) || ai.config();
    if (!p.key) return Promise.resolve({ ok: false, error: 'کلید «' + (p.name || 'سرویس') + '» روی این دستگاه نیست. آن را در بخش مشاور، بالای همین صفحه، وارد کن.' });
    if (p.type === 'openai' && !p.base) return Promise.resolve({ ok: false, error: 'آدرس این سرویس تنظیم نشده است. آن را در ویرایش همین سرویس وارد کن.' });
    if (!p.model) return Promise.resolve({ ok: false, error: 'مدل این سرویس انتخاب نشده است. از «دریافت لیست مدل‌ها» یکی را انتخاب کن.' });
    try { return App.providers.call(p, body); } catch (e) { return Promise.resolve({ ok: false, error: 'داده‌ی درخواست ساخته نشد.' }); }
  };

  // متن بلوک‌های text پاسخ
  ai.textOf = function (data) {
    return (data && data.content || []).filter(function (b) { return b && b.type === 'text'; })
      .map(function (b) { return b.text || ''; }).join('\n').trim();
  };

  // یک پرسش بدون ابزار (برای تجزیه‌ی متن، توضیح سؤال و مانند آن)
  ai.oneShot = function (system, userText, o) {
    o = o || {};
    var content = o.content || [{ type: 'text', text: String(userText || '') }];
    return ai.request({
      max_tokens: o.max || 2048,
      system: system,
      messages: [{ role: 'user', content: content }]
    }).then(function (r) {
      if (!r.ok) return r;
      return { ok: true, text: ai.textOf(r.data), stop: r.data.stop_reason };
    });
  };

  // تست اتصال: پیام کوتاه «سلام» با سرویس داده‌شده؛ اتصال موفق یعنی کلید و مدل پذیرفته شده‌اند، حتی اگر پاسخ خالی باشد
  ai.test = function (p) {
    return ai.request({ max_tokens: 30, messages: [{ role: 'user', content: [{ type: 'text', text: 'سلام' }] }] }, { profile: p }).then(function (r) {
      if (!r.ok) return { ok: false, error: r.error };
      var t = ai.textOf(r.data).slice(0, 80);
      return { ok: true, text: t || 'اتصال برقرار شد (پاسخ خالی بود).' };
    });
  };

  // فهرست مدل‌های یک سرویس: p = {type, base, key}
  ai.listModels = function (p) { return App.providers.models(p); };
})();
