// =======================================
// NetEarn Pro
// Typing Work System V3
// Firebase Auth + Task Validation
// Timer + Statistics + Submit
// =======================================

import { auth, db } from "./firebase.js";
import { getBusinessSettings, getConfiguredTaskReward } from "./business-settings.js";

import {
    onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";

import {
    doc,
    getDoc,
    addDoc,
    collection,
    serverTimestamp,
    increment,
    updateDoc
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";


// =======================================
// CURRENT TASK ID
// =======================================

const taskId =
    new URLSearchParams(
        window.location.search
    ).get("taskId");


// =======================================
// ELEMENTS
// =======================================

const timerBox =
    document.getElementById("timer");

const typingInput =
    document.getElementById("typingInput");

const sourceText =
    document.getElementById("sourceText");

const charCount =
    document.getElementById("charCount");

const wordCount =
    document.getElementById("wordCount");

const progress =
    document.getElementById("progress");

const submitBtn =
    document.getElementById("submitTaskBtn");


// =======================================
// APP STATE
// =======================================

let currentUser = null;

let userData = null;

let currentTask = null;

let remainingSeconds = 30 * 60;

let timerInterval = null;

let taskSubmitting = false;

let taskExpired = false;


// =======================================
// TASK CONFIG
// =======================================

const TASK_CONFIG = {

    taskType: "typing",

    reward: null,

    time: 30 * 60

};


// =======================================
// LOAD USER
// =======================================

onAuthStateChanged(
    auth,
    async(user) => {

        if(!user){

            window.location.href =
                "index.html";

            return;

        }


        currentUser = user;


        try{

            const userRef =
                doc(
                    db,
                    "users",
                    user.uid
                );


            const snap =
                await getDoc(userRef);


            if(!snap.exists()){

                await showError(
                    "User Data Not Found"
                );

                disableTask();

                return;

            }


            userData =
                snap.data();


            // ===================================
            // VERIFY CHECK
            // ===================================

            const verified =
                userData.verified === true ||
                userData.verified === "true";


            if(!verified){

                await showError(
                    "🔒 আপনার Account এখনো Verify করা হয়নি।"
                );

                disableTask();

                setTimeout(()=>{

                    window.location.href =
                        "dashboard.html";

                },1500);

                return;

            }


            // ===================================
            // TASK CHANCE CHECK
            // ===================================

            const chance =
                Number(
                    userData.taskChance || 0
                );


            if(chance < 1){

                await showError(
                    "👥 আপনার কোনো Task Chance নেই।"
                );

                disableTask();

                setTimeout(()=>{

                    window.location.href =
                        "dashboard.html";

                },1500);

                return;

            }


// ===================================
// TASK READY
// ===================================

await loadCurrentTask();

if (!currentTask) {

    showError(
        "❌ Task data পাওয়া যায়নি।"
    );

    disableTask();

    return;

}

startTask();

}

catch(error){

    console.error(
        "Typing Task Error:",
        error
    );

    showError(
        "⚠️ Task Load করা যায়নি। আবার চেষ্টা করুন।"
    );

    disableTask();

}

});

// =======================================
// LOAD CURRENT TASK
// =======================================

async function loadCurrentTask() {

    if (!taskId) {

        console.error(
            "❌ Task ID পাওয়া যায়নি।"
        );

        return;

    }

    try {

        const taskRef =
            doc(
                db,
                "tasks",
                taskId
            );

        const taskSnap =
            await getDoc(taskRef);


        if (!taskSnap.exists()) {

            console.error(
                "❌ Task পাওয়া যায়নি।"
            );

            return;

        }


        const task =
            taskSnap.data();


currentTask = { ...task };

        // Central Admin-controlled reward: no code edit required.
        const businessSettings = await getBusinessSettings({ force: true });
        currentTask.reward = getConfiguredTaskReward(currentTask, businessSettings);

console.log("✅ Loaded Task:", currentTask);

// ===================================
// UPDATE TASK CONFIG
// ===================================

if (task.title || task.name) {

    const titleElement =
        document.querySelector(".active-card h2");

    if (titleElement) {

        titleElement.textContent =
            task.title ||
            task.name ||
            "Typing Task";

    }

}

if (task.description) {

    const instructionBox =
        document.querySelector(
            ".instruction-box p"
        );

    if (instructionBox) {

        instructionBox.textContent =
            task.description;

    }

}

// ===================================
// TEXT TO TYPE
// ===================================

if (task.textToType) {

    const sourceTextElement =
        document.getElementById("sourceText");

    if (sourceTextElement) {

        sourceTextElement.textContent =
            task.textToType;

    }

}

// ===================================
// APPLY CURRENT TASK CONFIG
// ===================================

TASK_CONFIG.taskType =
    task.taskType ||
    task.category ||
    "typing";

TASK_CONFIG.reward =
    getConfiguredTaskReward(task);

TASK_CONFIG.time = 5 * 60;


// ===================================
// TEXT TO TYPE
// ===================================

if (task.textToType) {

    const sourceTextElement =
        document.getElementById("sourceText");

    if (sourceTextElement) {

        sourceTextElement.textContent =
            task.textToType;

    }

}

if (currentTask && currentTask.reward !== undefined) {

    document.querySelector(
        ".reward-card strong"
    ).textContent =
        "৳" + Number(currentTask.reward);

}

if (
    task.timeLimit !== undefined ||
    task.time !== undefined
) {

    const taskMinutes =
        Number(
            task.timeLimit ||
            task.time ||
            30
        );

    document.querySelector(
        ".time-card strong"
    ).textContent =
        taskMinutes + " Min";

}


// ===================================
// LOAD TASK CONTENT
// ===================================

const taskNameElement =
    document.getElementById("taskName");

const taskRewardElement =
    document.getElementById("taskReward");

const taskDescriptionElement =
    document.getElementById("sourceText");


// TASK NAME

if (taskNameElement) {

    taskNameElement.textContent =
        task.title ||
        task.name ||
        "Typing Task";

}


// TASK REWARD

if (taskRewardElement) {

    taskRewardElement.textContent =
        "৳" +
        Number(currentTask?.reward || 0);

}


// TASK TEXT TO TYPE

if (taskDescriptionElement) {

    taskDescriptionElement.textContent =
        task.textToType ||
        "No typing text available.";

}

        console.log(
            "✅ Current Task Loaded:",
            task
        );


    }

    catch (error) {

        console.error(
            "❌ Current Task Load Error:",
            error
        );

    }

}


// =======================================
// START TASK
// =======================================

function startTask(){

    taskExpired = false;

    taskSubmitting = false;

    const taskMinutes =
    Number(
        currentTask?.timeLimit ||
        currentTask?.time ||
        30
    );

remainingSeconds =
    TASK_CONFIG.time;


    if(typingInput){

        typingInput.disabled = false;

        typingInput.focus();

    }


    if(submitBtn){

        submitBtn.disabled = false;

        submitBtn.textContent =
            "🚀 Submit Task";

    }


    updateTimer();

    startTimer();

    updateStats();

}


// =======================================
// TIMER
// =======================================

function startTimer(){

    if(timerInterval){

        clearInterval(
            timerInterval
        );

    }


    timerInterval =
        setInterval(()=>{

            updateTimer();

        },1000);

}


// =======================================
// UPDATE TIMER
// =======================================

function updateTimer(){

    if(!timerBox)
        return;


    const minutes =
        Math.floor(
            remainingSeconds / 60
        );


    const seconds =
        remainingSeconds % 60;


    timerBox.textContent =

        String(minutes)
        .padStart(2,"0")

        +

        ":"

        +

        String(seconds)
        .padStart(2,"0");


    if(remainingSeconds <= 0){

        finishTimer();

        return;

    }


    remainingSeconds--;

}


// =======================================
// TIMER FINISHED
// =======================================

function finishTimer(){

    if(timerInterval){

        clearInterval(
            timerInterval
        );

        timerInterval = null;

    }


    taskExpired = true;


    if(typingInput){

        typingInput.disabled = true;

    }


    if(submitBtn){

        submitBtn.disabled = true;

        submitBtn.textContent =
            "⏳ Time Finished";

    }


    alert(
        "⏳ Task Time Finished!\n\nআপনি ৩০ মিনিটের সময় শেষ করেছেন।"
    );

}


// =======================================
// TYPING STATISTICS
// =======================================

function updateStats(){

    if(!typingInput || !sourceText)
        return;


    const text =
        typingInput.value;


    // Characters

    if(charCount){

        charCount.textContent =
            text.length;

    }


    // Words

    const words =
        text.trim()
        ? text.trim().split(/\s+/).length
        : 0;


    if(wordCount){

        wordCount.textContent =
            words;

    }


    // Progress

    const target =
        sourceText.textContent.trim();


    const targetLength =
        target.length;


    let percent = 0;


    if(targetLength > 0){

        percent =
            Math.min(
                100,
                Math.round(
                    (
                        text.length /
                        targetLength
                    ) * 100
                )
            );

    }


    if(progress){

        progress.textContent =
            percent + "%";

    }

}


// =======================================
// INPUT LISTENER
// =======================================

typingInput?.addEventListener(
    "input",
    updateStats
);


// =======================================
// CALCULATE ACCURACY
// =======================================

function calculateAccuracy(){

    if(!typingInput || !sourceText)
        return 0;


    const typed =
        typingInput.value;


    const target =
        sourceText.textContent.trim();


    if(!typed.length)
        return 0;


    const maxLength =
        Math.min(
            typed.length,
            target.length
        );


    let correct = 0;


    for(
        let i = 0;
        i < maxLength;
        i++
    ){

        if(
            typed[i] ===
            target[i]
        ){

            correct++;

        }

    }


    if (!target.length) {

    return 0;

}

return Math.round(
    (
        correct /
        target.length
    ) * 100
);

}


// =======================================
// SUBMIT TASK
// =======================================

submitBtn?.addEventListener(
    "click",
    submitTask
);


// =======================================
// SUBMIT FUNCTION
// =======================================

async function submitTask(){

    if(taskSubmitting)
        return;


    if(taskExpired){

        await NetEarnDialog.alert(
            "⏳ Task-এর সময় শেষ হয়ে গেছে।"
        );

        return;

    }


    if(!currentUser){

        await NetEarnDialog.alert(
            "⚠️ User authentication পাওয়া যায়নি।"
        );

        return;

    }


    if(!typingInput){

        return;

    }


    const typedText =
        typingInput.value.trim();


    const targetText =
    currentTask?.textToType?.trim() ||
    sourceText?.textContent.trim() ||
    "";


    // ===================================
    // EMPTY CHECK
    // ===================================

    if(!typedText){

        await NetEarnDialog.alert(
            "⌨️ আগে Task-এর উত্তর টাইপ করুন।"
        );

        typingInput.focus();

        return;

    }


    // ===================================
    // MINIMUM CHECK
    // ===================================

    if(
        typedText.length <
        Math.max(
            5,
            Math.floor(
                targetText.length * 0.5
            )
        )
    ){

        await NetEarnDialog.alert(
            "⚠️ আপনার typing এখনো সম্পূর্ণ হয়নি।\n\nদয়া করে পুরো লেখাটি টাইপ করুন।"
        );

        return;

    }


    // ===================================
    // CONFIRM
    // ===================================

    const confirmSubmit =
        await NetEarnDialog.confirm(
            "আপনি কি Task Submit করতে চান?\n\nSubmit করার পর আর পরিবর্তন করা যাবে না।"
        );


    if(!confirmSubmit)
        return;


    taskSubmitting = true;


    if(submitBtn){

        submitBtn.disabled = true;

        submitBtn.textContent =
            "⏳ Submitting...";

    }


    try{

        // ===================================
        // FRESH USER DATA
        // ===================================

        const userRef =
            doc(
                db,
                "users",
                currentUser.uid
            );


        const freshSnap =
            await getDoc(userRef);


        if(!freshSnap.exists()){

            throw new Error(
                "User not found"
            );

        }


        const freshUser =
            freshSnap.data();


        const freshChance =
            Number(
                freshUser.taskChance || 0
            );


        // ===================================
        // VERIFY AGAIN
        // ===================================

        const verified =
            freshUser.verified === true ||
            freshUser.verified === "true";


        if(!verified){

            throw new Error(
                "Account is not verified"
            );

        }


        // ===================================
        // CHANCE CHECK AGAIN
        // ===================================

        if(freshChance < 1){

            throw new Error(
                "No task chance"
            );

        }


        // ===================================
        // CALCULATE RESULT
        // ===================================

        const accuracy =
            calculateAccuracy();


        const typedCharacters =
            typingInput.value.length;


        const typedWords =
            typingInput.value
            .trim()
            ? typingInput.value
                .trim()
                .split(/\s+/)
                .length
            : 0;


        // ===================================
        // CREATE SUBMISSION
        // ===================================

        await addDoc(

    collection(
        db,
        "taskSubmissions"
    ),

    {

        userUid:
            currentUser.uid,

        userId:
            freshUser.userId ||
            null,

        username:
            freshUser.username ||
            null,

        taskId:
            taskId,

        taskType:
    currentTask?.taskType ||
    currentTask?.category ||
    "Typing",

taskName:
    currentTask?.title ||
    currentTask?.name ||
    currentTask?.taskName ||
    "Typing Task",

reward:
    Number(
        currentTask?.reward ||
        0
    ),

        typedCharacters:
            typedCharacters,

        typedWords:
            typedWords,

        accuracy:
            accuracy,

        sourceText:
            targetText,

        submittedText:
            typingInput.value,

        status:
            "pending",

        submittedAt:
            serverTimestamp()

    }

);
        // ===================================
        // REMOVE ONE TASK CHANCE
        // ===================================

        await updateDoc(

            userRef,

            {

                taskChance:
                    increment(-1),

                selectedTask:
                    null

            }

        );


        // ===================================
        // STOP TIMER
        // ===================================

        if(timerInterval){

            clearInterval(
                timerInterval
            );

            timerInterval = null;

        }


        // ===================================
        // DISABLE INPUT
        // ===================================

        typingInput.disabled = true;


        if(submitBtn){

            submitBtn.textContent =
                "✅ Task Submitted";

        }


        // ===================================
        // SUCCESS
        // ===================================

        await NetEarnDialog.alert(
    "🎉 Task Successfully Submitted!\n\n" +
    "Reward: ৳" +
    Number(currentTask?.reward || 0) +
    "\n" +
    "Status: Pending Admin Approval\n\n" +
    "Approval হলে Reward আপনার Balance-এ যোগ হবে।"
);


        window.location.href =
            "dashboard.html";


    }

        catch (error) {

        console.error(
            "❌ Task Submit Error:",
            error
        );

        // ===================================
        // DEBUG ERROR
        // ===================================

        await NetEarnDialog.alert(
            "ERROR CODE: " +
            (error.code || "NO_CODE") +
            "\n\n" +
            "ERROR MESSAGE:\n" +
            (error.message || error)
        );

        taskSubmitting = false;

        if (submitBtn) {

            submitBtn.disabled = false;

            submitBtn.textContent =
                "🚀 Submit Task";

        }

    }

}


// =======================================
// DISABLE TASK
// =======================================

function disableTask() {

    if (typingInput) {

        typingInput.disabled = true;

    }

    if (submitBtn) {

        submitBtn.disabled = true;

    }

    if (timerInterval) {

        clearInterval(
            timerInterval
        );

        timerInterval = null;

    }

}


// =======================================
// SHOW ERROR
// =======================================

async function showError(message) {

    if (!timerBox) {

        return;

    }

    timerBox.textContent =
        "LOCKED";

    timerBox.style.fontSize =
        "18px";

    timerBox.style.color =
        "#fecaca";

    return await NetEarnDialog.alert(message);

}


// =======================================
// INITIAL STATS
// =======================================

updateStats();


// =======================================
// READY
// =======================================

console.log(
    "✅ NetEarn Pro Typing Work V3 Loaded"
);