/* Central asset service.
   Screens ask for stable asset keys/slots; physical files can be replaced later
   without teaching every screen where the new file lives. */
window.WorkspaceAssets=(()=>{
  const fallback={
    schema:1,
    assets:{
      'branding.workspace.home-logo':{path:'/assets/branding/modding-workspace-home-logo.png'},'branding.fallout.logo':{path:'/assets/branding/fallout-logo.png'},
      'branding.fallout-new-vegas.logo':{path:'/assets/branding/fallout-new-vegas-logo.png'},
      'background.fallout.home':{path:'/assets/backgrounds/fallout-home.jpg'},
      'background.fallout.franchise':{path:'/assets/backgrounds/fallout-world.jpg'},
      'background.elder-scrolls.franchise':{path:'https://cdn.wallpapersafari.com/6/74/shnlU9.jpg'},
      'card.fallout-3':{path:'/assets/cards/fallout-3-card.jpg'},
      'card.fallout-new-vegas':{path:'/assets/cards/fallout-new-vegas-card.jpg'},
      'card.fallout-4':{path:'/assets/cards/fallout-4-card.jpg'},
      'card.fallout-76':{path:'/assets/cards/fallout-76-card.jpg'},
      'game-card.fallout-3.background':{path:'/assets/game-cards/fallout-3/background.jpg'},'game-card.fallout-3.icon':{path:'/assets/game-cards/fallout-3/icon.png'},'game-card.fallout-3.overlay':{path:'/assets/game-cards/fallout-3/overlay.png'},'game-card.fallout-3.hover':{path:'/assets/game-cards/fallout-3/hover.png'},'game-card.fallout-3.selected':{path:'/assets/game-cards/fallout-3/selected.png'},
      'game-card.fallout-new-vegas.background':{path:'/assets/game-cards/fallout-new-vegas/background.jpg'},'game-card.fallout-new-vegas.icon':{path:'/assets/game-cards/fallout-new-vegas/icon.png'},'game-card.fallout-new-vegas.overlay':{path:'/assets/game-cards/fallout-new-vegas/overlay.png'},'game-card.fallout-new-vegas.hover':{path:'/assets/game-cards/fallout-new-vegas/hover.png'},'game-card.fallout-new-vegas.selected':{path:'/assets/game-cards/fallout-new-vegas/selected.png'},
      'game-card.fallout-4.background':{path:'/assets/game-cards/fallout-4/background.jpg'},'game-card.fallout-4.icon':{path:'/assets/game-cards/fallout-4/icon.png'},'game-card.fallout-4.overlay':{path:'/assets/game-cards/fallout-4/overlay.png'},'game-card.fallout-4.hover':{path:'/assets/game-cards/fallout-4/hover.png'},'game-card.fallout-4.selected':{path:'/assets/game-cards/fallout-4/selected.png'},
      'game-card.fallout-76.background':{path:'/assets/game-cards/fallout-76/background.jpg'},'game-card.fallout-76.icon':{path:'/assets/game-cards/fallout-76/icon.png'},'game-card.fallout-76.overlay':{path:'/assets/game-cards/fallout-76/overlay.png'},'game-card.fallout-76.hover':{path:'/assets/game-cards/fallout-76/hover.png'},'game-card.fallout-76.selected':{path:'/assets/game-cards/fallout-76/selected.png'}
    },
    slots:{
      'home-selected-world':'background.fallout.home','fallout-home':'background.fallout.home','elder-scrolls-home':'background.elder-scrolls.franchise','fallout-franchise':'background.fallout.franchise','elder-scrolls-franchise':'background.elder-scrolls.franchise',
      'fallout-3-card':'game-card.fallout-3.background','fallout-new-vegas-card':'game-card.fallout-new-vegas.background','fallout-4-card':'game-card.fallout-4.background','fallout-76-card':'game-card.fallout-76.background',
      'oblivion-card':'','elder-scrolls-online-card':'','skyrim-card':'','fallout-3-hub':'','fallout-new-vegas-hub':'background.fallout.franchise','fallout-4-hub':'','fallout-76-hub':'','oblivion-hub':'','elder-scrolls-online-hub':'','skyrim-hub':''
    }
  };
  let registry=fallback,ready=false;
  const api={slots:{}};
  function localPath(value){const path=String(value||'');return location.protocol==='file:'&&path.startsWith('/')?path.slice(1):path}
  function assetPath(key){return localPath(registry?.assets?.[key]?.path||'')}
  function rebuildSlots(){api.slots={};for(const [slot,key] of Object.entries(registry?.slots||{}))api.slots[slot]=key?assetPath(key):''}
  function apply(root=document){
    root.querySelectorAll('[data-art-slot]').forEach(element=>{const url=api.slots[element.dataset.artSlot];if(url)element.style.setProperty('--backdrop-image',`url("${url}")`);else element.style.removeProperty('--backdrop-image')});
    root.querySelectorAll('[data-asset-key]').forEach(element=>{const url=assetPath(element.dataset.assetKey);if(!url)return;if(element.tagName==='IMG'){if(element.getAttribute('src')!==url)element.setAttribute('src',url)}else element.style.setProperty('--asset-image',`url("${url}")`)})
  }
  async function load(){
    try{const response=await fetch('/assets/asset-registry.json',{cache:'no-store'});if(response.ok){const value=await response.json();if(value?.assets&&value?.slots)registry=value}}catch{}
    ready=true;rebuildSlots();apply();return registry
  }
  function get(key){return assetPath(key)}
  function info(key){const value=registry?.assets?.[key];return value?{key,...value}:null}
  function slotKey(slot){return registry?.slots?.[slot]||''}
  rebuildSlots();
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',load,{once:true});else load();
  return Object.assign(api,{load,apply,get,info,slotKey,isReady:()=>ready,registry:()=>registry});
})();
