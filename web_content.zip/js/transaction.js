// =====================================================
// NetEarn Pro Transaction System
// Transaction + Income History
// =====================================================

import { db } from "./firebase.js";

import {
    collection,
    addDoc,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";


// =====================================================
// ADD TRANSACTION
// =====================================================

export async function addTransaction({

    uid,

    userId = null,

    userName = "User",

    title = "Transaction",

    reason = "Transaction",

    amount = 0,

    type = "credit",

    source = "other"

}) {

    try {

        const numericAmount =
            Number(amount || 0);


        if (
            !uid ||
            !Number.isFinite(numericAmount) ||
            numericAmount <= 0
        ) {

            console.error(
                "❌ Invalid Transaction Data"
            );

            return;

        }


        // =================================================
        // CREATE WALLET TRANSACTION
        // =================================================

        await addDoc(

            collection(
                db,
                "transactions"
            ),

            {

                uid:
                    uid,

                userId:
                    userId || null,

                username:
                    userName || "User",

                userName:
                    userName || "User",

                title:
                    title || "Transaction",

                reason:
                    reason || "Transaction",

                amount:
                    numericAmount,

                type:
                    type || "credit",

                source:
                    source || "other",

                status:
                    "completed",
                    
                    income: true,
                    
                createdAt:
                    serverTimestamp()

            }

        );


        // =================================================
        // CREATE INCOME HISTORY
        //
        // ONLY CREDIT IS INCOME
        // =================================================

        if (
            String(type)
                .toLowerCase()
            ===
            "credit"
        ) {

            await addDoc(

                collection(
                    db,
                    "incomeHistory"
                ),

                {

                    userUid:
                        uid,

                    userId:
                        userId || null,

                    username:
                        userName || "User",

                    amount:
                        numericAmount,

                    type:
                        "credit",

                    source:
                        source || "other",

                    title:
                        title || "Income",

                    reason:
                        reason || "Income",

                    status:
                        "approved",

                    createdAt:
                        serverTimestamp()

                }

            );

        }


        console.log(
            "✅ Transaction + Income History Created",
            {

                uid,
                amount:
                    numericAmount,

                type,
                source

            }
        );


    }

    catch (error) {

        console.error(
            "❌ Transaction Error:",
            error
        );

        // Transaction error should not
        // crash the main earning process.

    }

}