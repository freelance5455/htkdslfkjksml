/* يمكن هدف؟ — short synthesized UI sounds (no files, no network) */
(function () {
  let ctx = null, master = null; const S = { on: true };
  function ac() {
    if (!ctx) { const C = window.AudioContext || window.webkitAudioContext; if (!C) return null; ctx = new C(); master = ctx.createGain(); master.gain.value = 0.35; master.connect(ctx.destination); }
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    return ctx;
  }
  function tone(f0, f1, dur, type = 'sine', vol = 0.5, delay = 0) {
    const c = ac(); if (!c || !S.on) return; const t = c.currentTime + delay;
    const o = c.createOscillator(), g = c.createGain(); o.type = type;
    o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.012); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(master); o.start(t); o.stop(t + dur + 0.02);
  }
  function noise(dur, f0, f1, vol = 0.4, delay = 0, q = 1.2) {
    const c = ac(); if (!c || !S.on) return; const t = c.currentTime + delay;
    const n = Math.floor(c.sampleRate * dur), b = c.createBuffer(1, n, c.sampleRate), d = b.getChannelData(0);
    for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
    const s = c.createBufferSource(); s.buffer = b; const f = c.createBiquadFilter(); f.type = 'bandpass'; f.Q.value = q;
    f.frequency.setValueAtTime(f0, t); f.frequency.exponentialRampToValueAtTime(f1, t + dur);
    const g = c.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + dur * 0.3); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f); f.connect(g); g.connect(master); s.start(t);
  }
  const fx = {
    tap() { tone(880, 660, 0.07, 'triangle', 0.18); },
    whoosh() { noise(0.42, 500, 3800, 0.32); },
    pop() { tone(420, 980, 0.12, 'sine', 0.35); tone(980, 1300, 0.08, 'triangle', 0.15, 0.08); },
    reveal() { [523, 659, 784].forEach((f, i) => tone(f, f * 1.01, 0.22, 'triangle', 0.16, i * 0.07)); },
    arrow() { tone(300, 1200, 0.22, 'sawtooth', 0.08); },
    goal() { noise(1.4, 700, 1500, 0.35, 0, 0.6); [392, 523, 659, 784, 1046].forEach((f, i) => tone(f, f, 0.32, 'square', 0.07, i * 0.09)); },
    whistle() { tone(2400, 2350, 0.18, 'sine', 0.2); tone(2400, 2300, 0.32, 'sine', 0.2, 0.24); },
  };
  YH.sfx = { ...fx, set on(v) { S.on = !!v; }, get on() { return S.on; } };
  // gentle tap on every main navigation / tab press
  document.addEventListener('click', e => { if (e.target.closest('[data-nav],[data-tab],.chip,[data-day],.row')) fx.tap(); }, true);
})();
