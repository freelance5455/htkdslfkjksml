/* UrbaAlerte — stockage local (IndexedDB) : utilisateurs, signalements, médias, alertes */
(function(w){
'use strict';
const NAME='urbaalerte-v1',STORES=['users','reports','media','alerts','kv'];
let _db=null;
function open(){if(_db)return Promise.resolve(_db);return new Promise((res,rej)=>{const r=indexedDB.open(NAME,1);r.onupgradeneeded=()=>{const d=r.result;STORES.forEach(s=>{if(!d.objectStoreNames.contains(s))d.createObjectStore(s,{keyPath:s==='kv'?'key':'id'})})};r.onsuccess=()=>{_db=r.result;res(_db)};r.onerror=()=>rej(r.error)})}
function tx(store,mode,fn){return open().then(db=>new Promise((res,rej)=>{const t=db.transaction(store,mode);const s=t.objectStore(store);let out;const q=fn(s);if(q){q.onsuccess=()=>{out=q.result}}t.oncomplete=()=>res(out);t.onerror=()=>rej(t.error);t.onabort=()=>rej(t.error)}))}
w.DB={
 put:(s,o)=>tx(s,'readwrite',st=>st.put(o)),
 get:(s,k)=>tx(s,'readonly',st=>st.get(k)),
 all:s=>tx(s,'readonly',st=>st.getAll()),
 del:(s,k)=>tx(s,'readwrite',st=>st.delete(k)),
 clear:s=>tx(s,'readwrite',st=>st.clear()),
 async kvGet(k,d){const r=await DB.get('kv',k);return r?r.value:d},
 kvSet:(k,v)=>DB.put('kv',{key:k,value:v}),
 async wipe(){for(const s of STORES)await DB.clear(s)}
};
})(window);
