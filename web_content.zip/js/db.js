/* =============================================================
   LAMPION POS · js/db.js
   Pengganti includes/db.php + config/config.php
   -------------------------------------------------------------
   Sebelumnya  : PDO SQLite3  (data/lampion_pos.sqlite)
   Sekarang    : IndexedDB via Dexie.js (lib/dexie.min.js)

   Semua tabel dari sql/schema.sqlite.sql dipetakan 1:1 supaya
   logika (nomor nota, stok, laporan) tidak berubah hasilnya.
   Index & auto-increment dipertahankan (++id).
   ============================================================= */
(function (global) {
  'use strict';

  /* ---------- Konstanta (dulu di config/config.php) ---------- */
  var CFG = {
    DB_NAME: 'lampion_pos',
    DB_VERSION: 1,
    /* dulu SESSION_IDLE_SECONDS / SESSION_ABSOLUTE_SECONDS */
    SESSION_IDLE_SECONDS: 4 * 3600,      // 4 jam tanpa aktivitas
    SESSION_ABSOLUTE_SECONDS: 16 * 3600, // batas keras 16 jam
    SESSION_KEY: 'lpos_sid'
  };

  /* ---------- Label enum (dulu const di includes/functions.php) ---------- */
  var ORDER_TYPE_LABEL = { dine_in: 'Dine-in', takeaway: 'Take-away', online: 'Online' };
  var ORDER_TYPE_PREFIX = { dine_in: 'DI', takeaway: 'TA', online: 'OL' };
  var PAYMENT_LABEL = { cash: 'Tunai', qris: 'QRIS', debit: 'Debit', online: 'Online' };

  /* ---------- Schema Dexie (padanan CREATE TABLE) ---------- */
  var db = new Dexie(CFG.DB_NAME);

  db.version(CFG.DB_VERSION).stores({
    /* roles(id, name UNIQUE, is_system, is_active, created_at) */
    roles: '++id,&name,is_system,is_active,created_at',

    /* permissions(id, pkey UNIQUE, name, group_label, sort) */
    permissions: '++id,&pkey,name,group_label,sort',

    /* role_permissions PRIMARY KEY (role_id, permission_id) */
    role_permissions: '[role_id+permission_id],role_id,permission_id',

    /* users(id, username UNIQUE, role_id FK) */
    users: '++id,&username,role_id,is_active,created_at',

    /* auth_tokens(id, token UNIQUE, user_id FK, expires_at) */
    auth_tokens: '++id,&token,user_id,expires_at,created_at',

    /* settings(id, setting_key UNIQUE) */
    settings: '++id,&setting_key',

    /* categories(id, is_active) */
    categories: '++id,name,sort_order,is_active',

    /* menu_items(id, category_id FK) */
    menu_items: '++id,category_id,name,is_active,sort_order',

    /* inventory_items(id) */
    inventory_items: '++id,name,is_active',

    /* inventory_movements(id, inventory_id FK) */
    inventory_movements: '++id,inventory_id,type,created_at',

    /* menu_inventory UNIQUE (menu_id, inventory_id) */
    menu_inventory: '++id,[menu_id+inventory_id],menu_id,inventory_id',

    /* orders(id, order_number UNIQUE, created_at) */
    orders: '++id,&order_number,order_type,status,cashier_id,created_at',

    /* order_items(id, order_id FK) */
    order_items: '++id,order_id,menu_id',

    /* activity_log(id, created_at) */
    activity_log: '++id,user_id,action,created_at',

    /* customer_display(id, dkey UNIQUE) */
    customer_display: '++id,&dkey,status'
  });

  /* ============================================================
     Helper tanggal — padanan date()/datetime('now','localtime')
     PHP memakai zona Asia/Jakarta; JS memakai zona device.
     Format WAJIB sama supaya laporan (date(created_at)) tetap benar.
     ============================================================ */
  function pad2(n) { return (n < 10 ? '0' : '') + n; }

  /** 'YYYY-MM-DD' */
  function today(d) {
    d = d || new Date();
    return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate());
  }

  /** 'YYYYMMDD' (dipakai generate_order_number) */
  function todayCompact(d) {
    d = d || new Date();
    return '' + d.getFullYear() + pad2(d.getMonth() + 1) + pad2(d.getDate());
  }

  /** 'YYYY-MM-DD HH:MM:SS' — identik datetime('now','localtime') */
  function now(d) {
    d = d || new Date();
    return today(d) + ' ' + nowTime(d);
  }

  /** 'HH:MM:SS' */
  function nowTime(d) {
    d = d || new Date();
    return pad2(d.getHours()) + ':' + pad2(d.getMinutes()) + ':' + pad2(d.getSeconds());
  }

  /** Bagian tanggal dari string timestamp -> 'YYYY-MM-DD' */
  function dateOf(ts) {
    if (!ts) { return ''; }
    return String(ts).slice(0, 10);
  }

  /** Tambah/kurang hari, kembalikan 'YYYY-MM-DD' */
  function shiftDays(days, from) {
    var d = from ? new Date(from + 'T00:00:00') : new Date();
    d.setDate(d.getDate() + days);
    return today(d);
  }

  /** Label hari Indonesia: Mon->Sen (dulu $idDays di dashboard.php) */
  var ID_DAYS = { Mon: 'Sen', Tue: 'Sel', Wed: 'Rab', Thu: 'Kam', Fri: 'Jum', Sat: 'Sab', Sun: 'Min' };
  var EN_DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  function dayShortLabel(ymd) {
    var d = new Date(ymd + 'T00:00:00');
    var en = EN_DAYS[d.getDay()];
    return ID_DAYS[en] || en;
  }

  /** Format 'd/m/Y H:i' (dipakai created_label di struk) */
  function dmyHi(ts) {
    var s = String(ts || '').replace('T', ' ');
    var datePart = s.slice(0, 10);
    var timePart = s.slice(11, 16);
    var p = datePart.split('-');
    if (p.length !== 3) { return ''; }
    return p[2] + '/' + p[1] + '/' + p[0] + ' ' + timePart;
  }

  /** Format tanggal panjang Indonesia: 'Senin, 22 Sep 2026' */
  var ID_MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
  var ID_DAYS_FULL = { Mon: 'Senin', Tue: 'Selasa', Wed: 'Rabu', Thu: 'Kamis', Fri: 'Jumat', Sat: 'Sabtu', Sun: 'Minggu' };

  function longDate(d) {
    d = d || new Date();
    return (ID_DAYS_FULL[EN_DAYS[d.getDay()]] || '') + ', '
      + pad2(d.getDate()) + ' ' + ID_MONTHS[d.getMonth()] + ' ' + d.getFullYear();
  }

  /* ============================================================
     Settings (padanan get_setting / set_setting)
     ============================================================ */
  function getSetting(key, dflt) {
    return db.settings.where('setting_key').equals(key).first().then(function (row) {
      if (!row || row.setting_value === null || row.setting_value === undefined) {
        return (dflt === undefined ? null : dflt);
      }
      return row.setting_value;
    }).catch(function () {
      return (dflt === undefined ? null : dflt);
    });
  }

  function setSetting(key, value) {
    return db.settings.where('setting_key').equals(key).first().then(function (row) {
      if (row) {
        return db.settings.update(row.id, { setting_value: String(value) });
      }
      return db.settings.add({ setting_key: key, setting_value: String(value) });
    });
  }

  /** Ambil banyak setting sekaligus -> object */
  function getSettings(keys) {
    return db.settings.toArray().then(function (rows) {
      var map = {};
      rows.forEach(function (r) { map[r.setting_key] = r.setting_value; });
      var out = {};
      var wanted = keys || Object.keys(map);
      wanted.forEach(function (k) {
        out[k] = (map[k] === undefined || map[k] === null) ? '' : map[k];
      });
      return out;
    });
  }


  /* ============================================================
     Utilitas umum
     ============================================================ */

  /** Password acak (padanan generate_password) — tanpa 0/O/1/l */
  function generatePassword(len) {
    len = len || 12;
    var alphabet = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789';
    var out = '';
    var rnd = new Uint32Array(len);
    (global.crypto || global.msCrypto).getRandomValues(rnd);
    for (var i = 0; i < len; i++) {
      out += alphabet[rnd[i] % alphabet.length];
    }
    return out;
  }

  /** Token acak hex (padanan bin2hex(random_bytes(n))) */
  function randomHex(bytes) {
    var arr = new Uint8Array(bytes);
    (global.crypto || global.msCrypto).getRandomValues(arr);
    var s = '';
    for (var i = 0; i < arr.length; i++) {
      s += ('0' + arr[i].toString(16)).slice(-2);
    }
    return s;
  }

  /** Padanan user_count() — 0 = instalasi belum punya akun */
  function userCount() {
    return db.users.count().catch(function () { return 0; });
  }

  /* ---------- pembulatan 2 desimal ----------
     Dipakai oleh api/sales.js & api/dashboard.js sebagai DB.round2().
     (LPHP.round2 juga tersedia untuk pemakaian di sisi halaman.) */
  function round2(n) {
    return Math.round((Number(n) || 0) * 100) / 100;
  }

  /* ---------- Bukti tabel sudah dibangun (padanan db_table_exists) ---------- */
  function isBuilt() {
    return db.roles.count().then(function (c) {
      if (c === 0) { return false; }
      return db.menu_items.count().then(function () { return true; });
    }).catch(function () { return false; });
  }

  /* ---------- Drop semua baris (padanan bootstrap_database(force)) ----------
     Catatan: clear() mengosongkan baris tetapi penghitung auto-increment
     IndexedDB tetap maju. Karena seed mencari baris berdasarkan nama /
     kunci unik (bukan id), hal itu tidak menimbulkan masalah. */
  function wipeTables() {
    var tables = [
      'activity_log', 'auth_tokens', 'customer_display', 'role_permissions', 'permissions',
      'menu_inventory', 'inventory_items', 'inventory_movements', 'order_items', 'orders',
      'menu_items', 'categories', 'users', 'roles', 'settings'
    ];
    return db.transaction('rw', db.tables, function () {
      return Promise.all(tables.map(function (t) { return db.table(t).clear(); }));
    });
  }

  global.LPDB = {
    CFG: CFG,
    db: db,
    ORDER_TYPE_LABEL: ORDER_TYPE_LABEL,
    ORDER_TYPE_PREFIX: ORDER_TYPE_PREFIX,
    PAYMENT_LABEL: PAYMENT_LABEL,
    ID_DAYS: ID_DAYS,
    /* tanggal */
    today: today,
    todayCompact: todayCompact,
    now: now,
    nowTime: nowTime,
    dateOf: dateOf,
    shiftDays: shiftDays,
    dayShortLabel: dayShortLabel,
    dmyHi: dmyHi,
    longDate: longDate,
    /* settings */
    getSetting: getSetting,
    setSetting: setSetting,
    getSettings: getSettings,
    /* util */
    generatePassword: generatePassword,
    randomHex: randomHex,
    userCount: userCount,
    isBuilt: isBuilt,
    wipeTables: wipeTables,
    round2: round2
  };
})(window);

