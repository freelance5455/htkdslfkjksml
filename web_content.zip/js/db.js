/**
 * EthioEvents Pro - IndexedDB Local Database Engine with Guest Seating Permissions
 */
const DB_NAME = 'EthioEventsDB';
const DB_VERSION = 1;

class EventDatabase {
    constructor() {
        this.db = null;
    }

    async init() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(DB_NAME, DB_VERSION);

            request.onerror = (event) => {
                console.error("IndexedDB Error:", event.target.errorCode);
                reject("Database error");
            };

            request.onsuccess = (event) => {
                this.db = event.target.result;
                console.log("IndexedDB Initialized Successfully");
                resolve(this.db);
            };

            request.onupgradeneeded = (event) => {
                const db = event.target.result;

                if (!db.objectStoreNames.contains('events')) {
                    db.createObjectStore('events', { keyPath: 'id', autoIncrement: true });
                }
                if (!db.objectStoreNames.contains('clients')) {
                    db.createObjectStore('clients', { keyPath: 'id', autoIncrement: true });
                }
                if (!db.objectStoreNames.contains('suppliers')) {
                    db.createObjectStore('suppliers', { keyPath: 'id', autoIncrement: true });
                }
                if (!db.objectStoreNames.contains('equipment')) {
                    db.createObjectStore('equipment', { keyPath: 'id', autoIncrement: true });
                }
                if (!db.objectStoreNames.contains('finances')) {
                    db.createObjectStore('finances', { keyPath: 'id', autoIncrement: true });
                }
                if (!db.objectStoreNames.contains('guests')) {
                    db.createObjectStore('guests', { keyPath: 'id', autoIncrement: true });
                }
                if (!db.objectStoreNames.contains('staff')) {
                    db.createObjectStore('staff', { keyPath: 'id', autoIncrement: true });
                }
            };
        });
    }

    // Generic CRUD Helper Methods
    async getAll(storeName) {
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction(storeName, 'readonly');
            const store = tx.objectStore(storeName);
            const req = store.getAll();
            req.onsuccess = () => resolve(req.result);
            req.onerror = () => reject(req.error);
        });
    }

    async add(storeName, item) {
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction(storeName, 'readwrite');
            const store = tx.objectStore(storeName);
            const req = store.add(item);
            req.onsuccess = () => resolve(req.result);
            req.onerror = () => reject(req.error);
        });
    }

    async update(storeName, item) {
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction(storeName, 'readwrite');
            const store = tx.objectStore(storeName);
            const req = store.put(item);
            req.onsuccess = () => resolve(req.result);
            req.onerror = () => reject(req.error);
        });
    }

    async delete(storeName, id) {
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction(storeName, 'readwrite');
            const store = tx.objectStore(storeName);
            const req = store.delete(id);
            req.onsuccess = () => resolve();
            req.onerror = () => reject(req.error);
        });
    }
}

const dbEngine = new EventDatabase();