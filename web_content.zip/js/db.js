'use strict';

const DB = (() => {
  const PALETTE = [
    { id: 'blue',   hex: '#38bdf8', fill: 'rgba(56,189,248,.22)' },
    { id: 'rose',   hex: '#fb7185', fill: 'rgba(251,113,133,.22)' },
    { id: 'green',  hex: '#34d399', fill: 'rgba(52,211,153,.22)' },
    { id: 'amber',  hex: '#fbbf24', fill: 'rgba(251,191,36,.22)' }
  ];
  const SVG = 'http://www.w3.org/2000/svg';
  const DOT_R = 5, LW = 7;
  const SIZES = [3, 4, 5];

  let players = 2;
  let size = 4;
  let state = null;
  let layout = null;
  let drag = null;
  let started = false;
  let lastWinner = '';

  function ensureStarted() {
    if (!started) { started = true; newGame(); }
  }

  function newGame() {
    const n = size;
    state = {
      n,
      h: Array.from({ length: n + 1 }, () => Array(n).fill(0)),
      v: Array.from({ length: n }, () => Array(n + 1).fill(0)),
      boxes: Array.from({ length: n }, () => Array(n).fill(0)),
      scores: Array(players + 1).fill(0),
      current: 1,
      claimed: 0,
      over: false
    };
    buildScoreboard();
    buildBoard();
    render();
    updateSizeBtn();
  }

  function updateSizeBtn() {
    const b = document.getElementById('db-size-btn');
    if (b) b.textContent = size + '×' + size;
  }

  function cycleSize() {
    const idx = SIZES.indexOf(size);
    size = SIZES[(idx + 1) % SIZES.length];
    newGame();
  }

  function color(p) { return PALETTE[(p - 1) % PALETTE.length]; }

  function buildScoreboard() {
    const el = document.getElementById('db-scoreboard');
    el.innerHTML = '';
    for (let p = 1; p <= players; p++) {
      const c = color(p);
      const card = document.createElement('div');
      card.className = 'score-card';
      card.id = 'db-card-' + p;
      card.style.borderColor = c.hex;
      card.style.background = c.fill.replace('.22', '.10');
      card.innerHTML = '<div class="text-[10px] font-bold uppercase tracking-wide" style="color:' + c.hex + '">P' + p + '</div>' +
                       '<div class="score-num" style="color:' + c.hex + '" id="db-score-' + p + '">0</div>';
      el.appendChild(card);
    }
  }

  function getLayout() {
    const avail = Math.min(window.innerWidth - 48, 480);
    const padding = 22;
    const cell = Math.max(38, Math.min(96, Math.floor((avail - padding * 2) / size)));
    return { padding, cell, width: padding * 2 + cell * size };
  }
  function dx(c) { return layout.padding + c * layout.cell; }
  function dy(r) { return layout.padding + r * layout.cell; }

  function el(tag, attrs) {
    const e = document.createElementNS(SVG, tag);
    for (const k in attrs) e.setAttribute(k, attrs[k]);
    return e;
  }

  function buildBoard() {
    layout = getLayout();
    const svg = document.getElementById('db-board');
    svg.innerHTML = '';
    svg.setAttribute('viewBox', '0 0 ' + layout.width + ' ' + layout.width);
    svg.setAttribute('width', layout.width);
    svg.setAttribute('height', layout.width);
    svg.style.width = layout.width + 'px';

    const fills = [], hLines = [], vLines = [];
    const n = size;

    for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) {
      const rect = el('rect', {
        x: dx(c) + 4, y: dy(r) + 4, width: layout.cell - 8, height: layout.cell - 8,
        rx: 7, fill: '#0b1220'
      });
      svg.appendChild(rect); fills.push(rect);
    }
    for (let r = 0; r <= n; r++) { hLines[r] = [];
      for (let c = 0; c < n; c++) {
        const ln = el('line', {
          x1: dx(c), y1: dy(r), x2: dx(c + 1), y2: dy(r),
          stroke: '#334155', 'stroke-width': LW, 'stroke-linecap': 'round'
        });
        svg.appendChild(ln); hLines[r][c] = ln;
      }
    }
    for (let r = 0; r < n; r++) { vLines[r] = [];
      for (let c = 0; c <= n; c++) {
        const ln = el('line', {
          x1: dx(c), y1: dy(r), x2: dx(c), y2: dy(r + 1),
          stroke: '#334155', 'stroke-width': LW, 'stroke-linecap': 'round'
        });
        svg.appendChild(ln); vLines[r][c] = ln;
      }
    }
    const preview = el('line', {
      stroke: '#94a3b8', 'stroke-width': LW, 'stroke-linecap': 'round',
      'stroke-dasharray': '6 6', visibility: 'hidden', 'pointer-events': 'none'
    });
    const halo = el('circle', {
      r: DOT_R + 7, fill: 'none', stroke: '#e2e8f0', 'stroke-width': 2,
      visibility: 'hidden', 'pointer-events': 'none'
    });
    svg.append(preview, halo);

    for (let r = 0; r <= n; r++) for (let c = 0; c <= n; c++) {
      svg.appendChild(el('circle', { cx: dx(c), cy: dy(r), r: DOT_R, fill: '#64748b', 'pointer-events': 'none' }));
    }

    state.svg = { fills, hLines, vLines, preview, halo };
    svg.onpointerdown = onDown;
    svg.onpointermove = onMove;
    svg.onpointerup = onUp;
    svg.onpointercancel = cancel;
  }

  function pt(evt) {
    const svg = document.getElementById('db-board');
    const p = svg.createSVGPoint(); p.x = evt.clientX; p.y = evt.clientY;
    const m = svg.getScreenCTM();
    return m ? p.matrixTransform(m.inverse()) : { x: 0, y: 0 };
  }
  function nearest(px, py) {
    let best = null, dist = 26;
    for (let r = 0; r <= size; r++) for (let c = 0; c <= size; c++) {
      const d = Math.hypot(px - dx(c), py - dy(r));
      if (d < dist) { dist = d; best = { r, c }; }
    }
    return best;
  }

  function onDown(evt) {
    if (state.over || (evt.pointerType === 'mouse' && evt.button !== 0)) return;
    const p = pt(evt); const dot = nearest(p.x, p.y); if (!dot) return;
    drag = { id: evt.pointerId, start: dot };
    const svg = document.getElementById('db-board');
    try { svg.setPointerCapture(evt.pointerId); } catch (e) {}
    const col = color(state.current).hex;
    state.svg.halo.setAttribute('cx', dx(dot.c));
    state.svg.halo.setAttribute('cy', dy(dot.r));
    state.svg.halo.setAttribute('stroke', col);
    state.svg.halo.setAttribute('visibility', 'visible');
    state.svg.preview.setAttribute('x1', dx(dot.c));
    state.svg.preview.setAttribute('y1', dy(dot.r));
    state.svg.preview.setAttribute('x2', dx(dot.c));
    state.svg.preview.setAttribute('y2', dy(dot.r));
    state.svg.preview.setAttribute('stroke', col);
    state.svg.preview.setAttribute('visibility', 'visible');
  }
  function onMove(evt) {
    if (!drag || evt.pointerId !== drag.id) return;
    const p = pt(evt); const s = drag.start;
    const ddx = p.x - dx(s.c), ddy = p.y - dy(s.r);
    let ex, ey;
    if (Math.abs(ddx) >= Math.abs(ddy)) {
      ex = Math.max(dx(s.c) - layout.cell, Math.min(dx(s.c) + layout.cell, p.x));
      ey = dy(s.r);
    } else {
      ex = dx(s.c);
      ey = Math.max(dy(s.r) - layout.cell, Math.min(dy(s.r) + layout.cell, p.y));
    }
    state.svg.preview.setAttribute('x2', ex);
    state.svg.preview.setAttribute('y2', ey);
  }
  function cancel(evt) {
    if (!drag || (evt && evt.pointerId !== drag.id)) return;
    drag = null;
    state.svg.preview.setAttribute('visibility', 'hidden');
    state.svg.halo.setAttribute('visibility', 'hidden');
  }
  function onUp(evt) {
    if (!drag || evt.pointerId !== drag.id) return;
    const s = drag.start;
    const p = pt(evt); const end = nearest(p.x, p.y);
    cancel(evt);
    if (!end) return;
    const dr = end.r - s.r, dc = end.c - s.c;
    if (dr === 0 && Math.abs(dc) === 1) {
      const c = Math.min(s.c, end.c);
      if (!state.h[s.r][c]) makeMove('h', s.r, c);
    } else if (dc === 0 && Math.abs(dr) === 1) {
      const r = Math.min(s.r, end.r);
      if (!state.v[r][s.c]) makeMove('v', r, s.c);
    }
  }

  function isComplete(r, c) {
    return state.h[r][c] && state.h[r + 1][c] && state.v[r][c] && state.v[r][c + 1];
  }

  function makeMove(dir, r, c) {
    const p = state.current;
    if (dir === 'h') state.h[r][c] = p; else state.v[r][c] = p;
    const check = dir === 'h' ? [[r - 1, c], [r, c]] : [[r, c - 1], [r, c]];
    let earned = 0;
    check.forEach(([br, bc]) => {
      if (br < 0 || bc < 0 || br >= size || bc >= size) return;
      if (!state.boxes[br][bc] && isComplete(br, bc)) {
        state.boxes[br][bc] = p; state.scores[p]++; state.claimed++; earned++;
      }
    });
    if (!earned) state.current = state.current % players + 1;
    state.over = state.claimed === size * size;
    render();
    if (state.over) {
      const high = Math.max(...state.scores.slice(1));
      const winners = [];
      for (let i = 1; i <= players; i++) if (state.scores[i] === high) winners.push(i);
      lastWinner = winners.length === 1 ? 'P' + winners[0] : 'Draw';
      const emoji = winners.length === 1 ? '🏆' : '🤝';
      const title = winners.length === 1 ? 'Player ' + winners[0] + ' wins!' : "It's a tie!";
      const msg = state.scores.slice(1).map((s, i) => 'P' + (i + 1) + ': ' + s).join('  ·  ');
      setTimeout(() => App.showModal(emoji, title, msg, newGame), 240);
    }
  }

  function render() {
    const { fills, hLines, vLines } = state.svg;
    for (let r = 0; r <= size; r++) for (let c = 0; c < size; c++) {
      const o = state.h[r][c];
      hLines[r][c].setAttribute('stroke', o ? color(o).hex : '#334155');
    }
    for (let r = 0; r < size; r++) for (let c = 0; c <= size; c++) {
      const o = state.v[r][c];
      vLines[r][c].setAttribute('stroke', o ? color(o).hex : '#334155');
    }
    for (let r = 0; r < size; r++) for (let c = 0; c < size; c++) {
      const o = state.boxes[r][c];
      fills[r * size + c].setAttribute('fill', o ? color(o).fill : '#0b1220');
    }
    for (let p = 1; p <= players; p++) {
      const s = document.getElementById('db-score-' + p);
      if (s) s.textContent = state.scores[p];
      const card = document.getElementById('db-card-' + p);
      if (card) card.style.boxShadow = (!state.over && state.current === p) ? '0 0 0 2px ' + color(p).hex : '';
    }
    const t = document.getElementById('db-turn');
    if (state.over) { t.textContent = 'Round finished'; t.style.color = '#94a3b8'; }
    else { t.textContent = 'Player ' + state.current + "'s turn"; t.style.color = color(state.current).hex; }
  }

  function reset() { newGame(); }

  function statText() {
    if (!started) return '—';
    if (!lastWinner) return size + '×' + size;
    return size + '×' + size + ' · ' + lastWinner;
  }

  return { ensureStarted, reset, cycleSize, statText };
})();