/**
 * Panchal Business Manager - IndexedDB Engine & Data Portability (v3)
 * Provides structured offline storage, multi-business isolation, default masters,
 * pre-upgrade safety snapshots, audit logging, and JSON Backup/Restore.
 */
(function (global) {
  "use strict";

  const DB_NAME = "PanchalBusinessManagerDB";
  const DB_VERSION = 3;

  const BUSINESS_SCOPED_STORES = [
    "parties",
    "items",
    "warehouses",
    "stockMovements",
    "vouchers",
    "accounts",
    "journalEntries",
    "projects",
    "projectEntries",
    "staff",
    "attendance",
    "payroll",
    "templates",
    "docSettings",
    "auditLogs"
  ];

  const ALL_STORES = ["businesses", "meta"].concat(BUSINESS_SCOPED_STORES);

  let dbInstance = null;

  function generateId(prefix) {
    const rand = Math.random().toString(36).slice(2, 8);
    return (prefix || "rec") + "_" + Date.now().toString(36) + "_" + rand;
  }

  function openDatabase() {
    if (dbInstance) {
      return Promise.resolve(dbInstance);
    }

    return new Promise(function (resolve, reject) {
      if (!("indexedDB" in global)) {
        reject(new Error("IndexedDB is not supported in this browser."));
        return;
      }

      const request = global.indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = function (event) {
        const db = event.target.result;
        const oldVer = event.oldVersion || 0;

        if (!db.objectStoreNames.contains("businesses")) {
          db.createObjectStore("businesses", { keyPath: "id" });
        }

        if (!db.objectStoreNames.contains("meta")) {
          db.createObjectStore("meta", { keyPath: "key" });
        }

        BUSINESS_SCOPED_STORES.forEach(function (storeName) {
          if (!db.objectStoreNames.contains(storeName)) {
            const store = db.createObjectStore(storeName, { keyPath: "id" });
            store.createIndex("businessId", "businessId", { unique: false });
            store.createIndex("updatedAt", "updatedAt", { unique: false });
          }
        });

        try {
          localStorage.setItem(
            "pbm_last_schema_upgrade",
            JSON.stringify({ from: oldVer, to: DB_VERSION, at: new Date().toISOString() })
          );
        } catch (e) {
          // Ignore storage quota issues
        }
      };

      request.onsuccess = function (event) {
        dbInstance = event.target.result;
        dbInstance.onversionchange = function () {
          dbInstance.close();
          dbInstance = null;
        };
        resolve(dbInstance);
      };

      request.onerror = function (event) {
        reject(event.target.error || new Error("Failed to open IndexedDB."));
      };
    });
  }

  function getAll(storeName) {
    return openDatabase().then(function (db) {
      return new Promise(function (resolve, reject) {
        const tx = db.transaction(storeName, "readonly");
        const store = tx.objectStore(storeName);
        const req = store.getAll();
        req.onsuccess = function () {
          resolve(req.result || []);
        };
        req.onerror = function () {
          reject(req.error);
        };
      });
    });
  }

  function getByBusiness(storeName, businessId) {
    return openDatabase().then(function (db) {
      return new Promise(function (resolve, reject) {
        const tx = db.transaction(storeName, "readonly");
        const store = tx.objectStore(storeName);
        const index = store.index("businessId");
        const req = index.getAll(businessId);
        req.onsuccess = function () {
          resolve(req.result || []);
        };
        req.onerror = function () {
          reject(req.error);
        };
      });
    });
  }

  function getOne(storeName, key) {
    return openDatabase().then(function (db) {
      return new Promise(function (resolve, reject) {
        const tx = db.transaction(storeName, "readonly");
        const store = tx.objectStore(storeName);
        const req = store.get(key);
        req.onsuccess = function () {
          resolve(req.result || null);
        };
        req.onerror = function () {
          reject(req.error);
        };
      });
    });
  }

  function put(storeName, record) {
    return openDatabase().then(function (db) {
      return new Promise(function (resolve, reject) {
        const tx = db.transaction(storeName, "readwrite");
        const store = tx.objectStore(storeName);
        const req = store.put(record);
        req.onsuccess = function () {
          resolve(record);
        };
        req.onerror = function () {
          reject(req.error);
        };
      });
    });
  }

  function remove(storeName, key) {
    return openDatabase().then(function (db) {
      return new Promise(function (resolve, reject) {
        const tx = db.transaction(storeName, "readwrite");
        const store = tx.objectStore(storeName);
        const req = store.delete(key);
        req.onsuccess = function () {
          resolve(true);
        };
        req.onerror = function () {
          reject(req.error);
        };
      });
    });
  }

  function deleteRecordsByBusiness(businessId) {
    return openDatabase().then(function (db) {
      return new Promise(function (resolve, reject) {
        const tx = db.transaction(BUSINESS_SCOPED_STORES, "readwrite");
        tx.oncomplete = function () {
          resolve(true);
        };
        tx.onerror = function () {
          reject(tx.error);
        };

        BUSINESS_SCOPED_STORES.forEach(function (storeName) {
          const store = tx.objectStore(storeName);
          const index = store.index("businessId");
          const cursorReq = index.openKeyCursor(IDBKeyRange.only(businessId));
          cursorReq.onsuccess = function (event) {
            const cursor = event.target.result;
            if (cursor) {
              store.delete(cursor.primaryKey);
              cursor.continue();
            }
          };
        });
      });
    });
  }

  function logAudit(businessId, action, entity, details) {
    const entry = {
      id: generateId("log"),
      businessId: businessId || "system",
      action: action,
      entity: entity,
      details: details || "",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    return put("auditLogs", entry).catch(function () {
      return null;
    });
  }

  function getActiveBusinessId() {
    return getOne("meta", "activeBusinessId").then(function (rec) {
      return rec ? rec.value : null;
    });
  }

  function setActiveBusinessId(businessId) {
    return put("meta", {
      key: "activeBusinessId",
      value: businessId,
      updatedAt: new Date().toISOString()
    });
  }

  function getLastBackupDate() {
    return getOne("meta", "lastBackupAt").then(function (rec) {
      return rec ? rec.value : null;
    });
  }

  function getDefaultDocSettings(businessId) {
    const now = new Date().toISOString();
    return {
      id: "docset_" + businessId,
      businessId: businessId,
      currencySymbol: "₹",
      currencyCode: "INR",
      useFyPrefix: true,
      defaultPaymentTerms: "Net 15 Days",
      defaultTaxRates: [0, 5, 12, 18, 28],
      enableRoundOff: true,
      series: {
        SALE_INVOICE: { prefix: "PF/INV/", suffix: "", nextNo: 1 },
        BILL_OF_SUPPLY: { prefix: "PF/BOS/", suffix: "", nextNo: 1 },
        ESTIMATE: { prefix: "PF/EST/", suffix: "", nextNo: 1 },
        QUOTATION: { prefix: "PF/QTN/", suffix: "", nextNo: 1 },
        PROFORMA: { prefix: "PF/PRO/", suffix: "", nextNo: 1 },
        CREDIT_NOTE: { prefix: "PF/CRN/", suffix: "", nextNo: 1 },
        DEBIT_NOTE: { prefix: "PF/DBN/", suffix: "", nextNo: 1 },
        PURCHASE_ORDER: { prefix: "PF/PO/", suffix: "", nextNo: 1 },
        SALES_ORDER: { prefix: "PF/SO/", suffix: "", nextNo: 1 },
        CHALLAN: { prefix: "PF/CHL/", suffix: "", nextNo: 1 },
        RECEIPT: { prefix: "PF/REC/", suffix: "", nextNo: 1 },
        WORK_ORDER: { prefix: "PF/WO/", suffix: "", nextNo: 1 },
        COMPLETION_CERT: { prefix: "PF/CC/", suffix: "", nextNo: 1 },
        PURCHASE_BILL: { prefix: "PF/PUR/", suffix: "", nextNo: 1 },
        EXPENSE_VOUCHER: { prefix: "PF/EXP/", suffix: "", nextNo: 1 },
        PAYMENT: { prefix: "PF/PAY/", suffix: "", nextNo: 1 }
      },
      termsLibrary: [
        "1. Goods once sold will not be taken back without prior approval.",
        "2. Custom furniture orders require 50% advance; balance before dispatch.",
        "3. All disputes subject to local jurisdiction only.",
        "4. Quotation valid for 15 days from date of issue."
      ],
      defaultTemplateByCategory: {
        INVOICE: "inv_furniture",
        QUOTATION: "qtn_furniture_spec",
        RECEIPT: "inv_compact_receipt",
        OTHER: "inv_classic_gst"
      },
      createdAt: now,
      updatedAt: now
    };
  }

  function ensureBusinessMasters(businessId) {
    const now = new Date().toISOString();
    return Promise.all([
      getByBusiness("warehouses", businessId),
      getByBusiness("accounts", businessId),
      getByBusiness("docSettings", businessId)
    ]).then(function (results) {
      const warehouses = results[0];
      const accounts = results[1];
      const settingsList = results[2];
      const tasks = [];

      if (warehouses.length === 0) {
        tasks.push(
          put("warehouses", {
            id: generateId("wh"),
            businessId: businessId,
            name: "Main Showroom & Godown",
            location: "Primary Store",
            isDefault: true,
            createdAt: now,
            updatedAt: now
          })
        );
      }

      if (accounts.length === 0) {
        const defaultAccounts = [
          { code: "1001", name: "Cash in Hand", group: "ASSET", systemKey: "CASH" },
          { code: "1002", name: "Bank Account", group: "ASSET", systemKey: "BANK" },
          { code: "1100", name: "Accounts Receivable", group: "ASSET", systemKey: "RECEIVABLE" },
          { code: "1200", name: "GST Input Credit", group: "ASSET", systemKey: "GST_INPUT" },
          { code: "2001", name: "Accounts Payable", group: "LIABILITY", systemKey: "PAYABLE" },
          { code: "2100", name: "GST Output Tax", group: "LIABILITY", systemKey: "GST_OUTPUT" },
          { code: "3001", name: "Owner Capital", group: "EQUITY", systemKey: "CAPITAL" },
          { code: "4001", name: "Sales Revenue", group: "INCOME", systemKey: "SALES" },
          { code: "4100", name: "Other / Shipping Income", group: "INCOME", systemKey: "OTHER_INCOME" },
          { code: "5001", name: "Purchase Cost", group: "EXPENSE", systemKey: "PURCHASE" },
          { code: "5100", name: "Site & Labour Expenses", group: "EXPENSE", systemKey: "SITE_EXPENSE" },
          { code: "5200", name: "Salary & Wages", group: "EXPENSE", systemKey: "PAYROLL" },
          { code: "5300", name: "Operating & Misc Expenses", group: "EXPENSE", systemKey: "OPERATING_EXP" }
        ];
        defaultAccounts.forEach(function (acc) {
          tasks.push(
            put("accounts", {
              id: generateId("acc"),
              businessId: businessId,
              code: acc.code,
              name: acc.name,
              group: acc.group,
              systemKey: acc.systemKey,
              openingBalance: 0,
              createdAt: now,
              updatedAt: now
            })
          );
        });
      }

      if (settingsList.length === 0) {
        tasks.push(put("docSettings", getDefaultDocSettings(businessId)));
      }

      return Promise.all(tasks);
    });
  }

  function ensureDefaultBusiness() {
    return getAll("businesses").then(function (businesses) {
      if (businesses.length > 0) {
        return getActiveBusinessId().then(function (activeId) {
          const exists = businesses.some(function (b) {
            return b.id === activeId;
          });
          const resolvedId = exists ? activeId : businesses[0].id;
          return setActiveBusinessId(resolvedId)
            .then(function () {
              return ensureBusinessMasters(resolvedId);
            })
            .then(function () {
              return resolvedId;
            });
        });
      }

      const now = new Date().toISOString();
      const defaultBiz = {
        id: generateId("biz"),
        name: "Panchal Furnitures",
        gstin: "",
        phone: "",
        email: "",
        stateName: "Gujarat",
        address: "",
        financialYear: "2026-27",
        authorizedPerson: "",
        bankName: "",
        bankAccountNo: "",
        bankIfsc: "",
        upiId: "",
        logoDataUrl: "",
        stampDataUrl: "",
        signatureDataUrl: "",
        createdAt: now,
        updatedAt: now
      };

      return put("businesses", defaultBiz)
        .then(function () {
          return setActiveBusinessId(defaultBiz.id);
        })
        .then(function () {
          return ensureBusinessMasters(defaultBiz.id);
        })
        .then(function () {
          return logAudit(defaultBiz.id, "CREATE", "business", "Default business initialized");
        })
        .then(function () {
          return defaultBiz.id;
        });
    });
  }

  function init() {
    return openDatabase().then(function () {
      return ensureDefaultBusiness();
    });
  }

  function exportAllData() {
    return openDatabase().then(function () {
      const now = new Date().toISOString();
      return put("meta", { key: "lastBackupAt", value: now, updatedAt: now }).then(function () {
        const promises = ALL_STORES.map(function (storeName) {
          return getAll(storeName).then(function (rows) {
            return { storeName: storeName, rows: rows };
          });
        });

        return Promise.all(promises).then(function (results) {
          const stores = {};
          results.forEach(function (item) {
            stores[item.storeName] = item.rows;
          });

          return {
            app: "PanchalBusinessManager",
            schemaVersion: DB_VERSION,
            exportedAt: now,
            stores: stores
          };
        });
      });
    });
  }

  function importAllData(payload) {
    if (
      !payload ||
      payload.app !== "PanchalBusinessManager" ||
      !payload.stores ||
      typeof payload.stores !== "object"
    ) {
      return Promise.reject(new Error("Invalid backup file format."));
    }

    if (!Array.isArray(payload.stores.businesses) || payload.stores.businesses.length === 0) {
      return Promise.reject(new Error("Backup file has no business profiles."));
    }

    return openDatabase().then(function (db) {
      return new Promise(function (resolve, reject) {
        const validStores = ALL_STORES.filter(function (name) {
          return db.objectStoreNames.contains(name);
        });

        const tx = db.transaction(validStores, "readwrite");

        tx.oncomplete = function () {
          ensureDefaultBusiness().then(resolve).catch(reject);
        };

        tx.onerror = function () {
          reject(tx.error || new Error("Failed to restore backup into database."));
        };

        validStores.forEach(function (storeName) {
          const store = tx.objectStore(storeName);
          store.clear();
          const rows = Array.isArray(payload.stores[storeName])
            ? payload.stores[storeName]
            : [];
          rows.forEach(function (row) {
            if (row && typeof row === "object") {
              store.put(row);
            }
          });
        });
      });
    });
  }

  global.PBM_DB = {
    ALL_STORES: ALL_STORES,
    BUSINESS_SCOPED_STORES: BUSINESS_SCOPED_STORES,
    init: init,
    generateId: generateId,
    getAll: getAll,
    getByBusiness: getByBusiness,
    getOne: getOne,
    put: put,
    remove: remove,
    deleteRecordsByBusiness: deleteRecordsByBusiness,
    ensureBusinessMasters: ensureBusinessMasters,
    getDefaultDocSettings: getDefaultDocSettings,
    logAudit: logAudit,
    getActiveBusinessId: getActiveBusinessId,
    setActiveBusinessId: setActiveBusinessId,
    getLastBackupDate: getLastBackupDate,
    exportAllData: exportAllData,
    importAllData: importAllData
  };
})(window);
