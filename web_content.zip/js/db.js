/**
 * StockPro - Capa de datos (localStorage)
 * Estructura simple y robusta para uso offline.
 */

const DB = {
  // ---------- PRODUCTOS ----------
  getProductos() {
    return JSON.parse(localStorage.getItem("sp_productos") || "[]");
  },

  saveProductos(lista) {
    localStorage.setItem("sp_productos", JSON.stringify(lista));
  },

  getProducto(id) {
    return this.getProductos().find(p => p.id === id);
  },

  getProductoByCodigo(codigo) {
    if (!codigo) return null;
    return this.getProductos().find(p => p.codigo && p.codigo === codigo);
  },

  addProducto(prod) {
    const lista = this.getProductos();
    prod.id = Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
    lista.push(prod);
    this.saveProductos(lista);
    return prod;
  },

  updateProducto(id, data) {
    const lista = this.getProductos();
    const idx = lista.findIndex(p => p.id === id);
    if (idx === -1) return false;
    lista[idx] = { ...lista[idx], ...data };
    this.saveProductos(lista);
    return true;
  },

  deleteProducto(id) {
    const lista = this.getProductos().filter(p => p.id !== id);
    this.saveProductos(lista);
  },

  ajustarStock(id, cantidad) {
    const lista = this.getProductos();
    const idx = lista.findIndex(p => p.id === id);
    if (idx === -1) return false;
    lista[idx].stock = Math.max(0, (lista[idx].stock || 0) + cantidad);
    this.saveProductos(lista);
    return true;
  },

  // ---------- VENTAS ----------
  getVentas() {
    return JSON.parse(localStorage.getItem("sp_ventas") || "[]");
  },

  saveVentas(lista) {
    localStorage.setItem("sp_ventas", JSON.stringify(lista));
  },

  addVenta(venta) {
    const lista = this.getVentas();
    venta.id = Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
    lista.unshift(venta); // más reciente primero
    this.saveVentas(lista);
    return venta;
  },

  getVentasHoy() {
    const hoy = new Date().toISOString().slice(0, 10);
    return this.getVentas().filter(v => v.fecha === hoy);
  },

  getVentasRango(desde, hasta) {
    return this.getVentas().filter(v => {
      if (desde && v.fecha < desde) return false;
      if (hasta && v.fecha > hasta) return false;
      return true;
    });
  },

  // ---------- CONFIG ----------
  getConfig() {
    return JSON.parse(localStorage.getItem("sp_config") || '{"nombre":"Mi Tienda","moneda":"CUP"}');
  },

  saveConfig(cfg) {
    localStorage.setItem("sp_config", JSON.stringify(cfg));
  },

  // ---------- BACKUP ----------
  exportarTodo() {
    return {
      version: 1,
      fecha: new Date().toISOString(),
      productos: this.getProductos(),
      ventas: this.getVentas(),
      config: this.getConfig(),
      logo: localStorage.getItem("sp_logo") || null
    };
  },

  importarTodo(data) {
    if (!data || !data.version) throw new Error("Archivo de backup inválido");
    if (data.productos) this.saveProductos(data.productos);
    if (data.ventas) this.saveVentas(data.ventas);
    if (data.config) this.saveConfig(data.config);
    if (data.logo) localStorage.setItem("sp_logo", data.logo);
    else localStorage.removeItem("sp_logo");
  },

  borrarTodo() {
    localStorage.removeItem("sp_productos");
    localStorage.removeItem("sp_ventas");
    localStorage.removeItem("sp_config");
    localStorage.removeItem("sp_logo");
    // No borramos la licencia a propósito
  }
};
