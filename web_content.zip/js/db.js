/**
 * db.js
 * Camada de acesso a dados — simula um banco de dados relacional usando
 * localStorage, mas com uma API de tabelas (list/find/insert/update) que
 * pode ser trocada por chamadas HTTP a uma API real no futuro SEM precisar
 * reescrever as camadas de cima (services/*.js, páginas).
 *
 * LIMITAÇÃO HONESTA: isto roda inteiramente no navegador do usuário. Não é
 * um banco de dados de verdade, não é compartilhado entre dispositivos/usuários
 * e não tem nenhuma garantia de segurança real. Serve como fundação de
 * ARQUITETURA (tabelas, modelos, serviços separados) para uma migração futura
 * a um backend real (Node/Express, Supabase, Firebase, etc.) — a migração
 * exigiria reescrever apenas este arquivo, não o resto do app.
 */
const DB = (function(){

  function _ler(tabela){
    const raw = localStorage.getItem(storageKey(tabela));
    return raw ? JSON.parse(raw) : [];
  }
  /** Detecta o erro de cota do localStorage entre navegadores (nome/código variam). */
  function _erroDeCota(e){
    return e && (e.name === 'QuotaExceededError' || e.name === 'NS_ERROR_DOM_QUOTA_REACHED' || e.code === 22 || e.code === 1014);
  }
  function _salvar(tabela, linhas){
    try{
      localStorage.setItem(storageKey(tabela), JSON.stringify(linhas));
    }catch(e){
      if(_erroDeCota(e)){
        // Ambiente DEV usa localStorage como "banco" — fotos/vídeos em base64
        // ocupam muito espaço e o navegador tem uma cota pequena (poucos MB).
        // Uma mensagem clara aqui evita que o erro pareça um travamento sem motivo.
        throw new Error('Armazenamento local cheio para este ambiente de testes: o arquivo (foto/vídeo) anexado é grande demais. Tente um vídeo mais curto ou uma foto de menor resolução/tamanho.');
      }
      throw e;
    }
  }
  function _gerarId(tabela){
    const seqKey = storageKey('_seq_' + tabela);
    const atual = parseInt(localStorage.getItem(seqKey) || '0', 10) + 1;
    localStorage.setItem(seqKey, String(atual));
    return atual;
  }

  return {
    /** Lista todas as linhas de uma tabela (opcionalmente filtradas). */
    list(tabela, filtro){
      const linhas = _ler(tabela);
      if(!filtro) return linhas;
      return linhas.filter(filtro);
    },

    /** Busca uma linha por id. */
    find(tabela, id){
      return _ler(tabela).find(r => r.id === id) || null;
    },

    /** Busca a primeira linha que satisfaça o filtro. */
    findOne(tabela, filtro){
      return _ler(tabela).find(filtro) || null;
    },

    /** Insere uma nova linha (gera id e timestamps automaticamente). */
    insert(tabela, dados){
      const linhas = _ler(tabela);
      const agora = new Date().toISOString();
      const linha = Object.assign({}, dados, {
        id: dados.id || _gerarId(tabela),
        created_at: dados.created_at || agora,
        updated_at: agora,
      });
      linhas.push(linha);
      _salvar(tabela, linhas);
      return linha;
    },

    /** Atualiza campos de uma linha por id (merge parcial). */
    update(tabela, id, patch){
      const linhas = _ler(tabela);
      const idx = linhas.findIndex(r => r.id === id);
      if(idx === -1) return null;
      linhas[idx] = Object.assign({}, linhas[idx], patch, { updated_at: new Date().toISOString() });
      _salvar(tabela, linhas);
      return linhas[idx];
    },

    /**
     * "Exclusão" lógica — nunca remove fisicamente. Usado por ex. para
     * imóveis (status: 'ativo' | 'inativo') e usuários (status: 'ativo' | 'suspenso').
     */
    setStatus(tabela, id, status){
      return this.update(tabela, id, { status });
    },

    /** Remove fisicamente — só deve ser usado por rotinas de teste/seed. */
    _deleteHard(tabela, id){
      const linhas = _ler(tabela).filter(r => r.id !== id);
      _salvar(tabela, linhas);
    },

    /** Limpa uma tabela inteira — só para reset de ambiente de desenvolvimento. */
    _clear(tabela){
      _salvar(tabela, []);
    },

    /** Grava um array inteiro de uma vez (usado pelos seeds). */
    _seed(tabela, linhas){
      if(_ler(tabela).length === 0){
        _salvar(tabela, linhas);
      }
    },

    _tabelaVazia(tabela){
      return _ler(tabela).length === 0;
    }
  };
})();
