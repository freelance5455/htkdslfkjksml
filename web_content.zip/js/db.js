const DB_NAME='wonder_shift_prod',DB_VERSION=4;
const STORES={users:'id',operations:'id',services:'id',tasks:'id',stock:'id',stockMovements:'id',stockRules:'id',cashSessions:'id',cashMovements:'id',notifications:'id',syncQueue:'id',settings:'id',audit:'id',changeRequests:'id'};
let dbp;
function openDB(){if(dbp)return dbp;dbp=new Promise((resolve,reject)=>{const r=indexedDB.open(DB_NAME,DB_VERSION);r.onupgradeneeded=()=>{const d=r.result;Object.entries(STORES).forEach(([s,key])=>{if(!d.objectStoreNames.contains(s)){const st=d.createObjectStore(s,{keyPath:key});if(['operations','stockMovements','cashMovements','audit','notifications','changeRequests'].includes(s))st.createIndex('createdAt','createdAt')}})};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)});return dbp}
async function dbAll(store){const d=await openDB();return new Promise((res,rej)=>{const q=d.transaction(store,'readonly').objectStore(store).getAll();q.onsuccess=()=>res(q.result||[]);q.onerror=()=>rej(q.error)})}
async function dbGet(store,id){const d=await openDB();return new Promise((res,rej)=>{const q=d.transaction(store,'readonly').objectStore(store).get(id);q.onsuccess=()=>res(q.result);q.onerror=()=>rej(q.error)})}
async function dbPut(store,obj){const d=await openDB();return new Promise((res,rej)=>{const q=d.transaction(store,'readwrite').objectStore(store).put(obj);q.onsuccess=()=>res(obj);q.onerror=()=>rej(q.error)})}
async function dbDelete(store,id){const d=await openDB();return new Promise((res,rej)=>{const q=d.transaction(store,'readwrite').objectStore(store).delete(id);q.onsuccess=()=>res();q.onerror=()=>rej(q.error)})}
const DEFAULT_SERVICES=['Photocopie','Impression simple (noir)','Impression couleur','Impression sur papier autocollant','Impression sur papier photo','Huilage / contrecollage','Impression Lacoste / T-shirt','Scannage','Saisie','Épitoge','Autres tâches particulières'];
const DEFAULT_TASKS=[['Photocopie A4',100],['Photocopie A3',200],['Impression A4 noir',200],['Impression A4 couleur',500],['Impression A3 couleur',1000],['Papier photo',1000],['Papier autocollant',1500],['Contrecollage',2000],['T-shirt / Lacoste',10000],['Scan document',500],['Saisie document',1000],['Épitoge',2000]];
const DEFAULT_STOCK=[['Papier A4 (80g)',100,20,'ramettes'],['Papier A4 (120g)',50,10,'ramettes'],['Papier A3',40,8,'ramettes'],['Papier photo (glossy)',50,10,'feuilles'],['Papier autocollant',50,10,'feuilles'],['T-shirt Lacoste blanc',20,5,'unités'],['T-shirt Lacoste noir',20,5,'unités'],['T-shirt Lacoste couleur',20,5,'unités'],['Encre noir',10,2,'unités'],['Encre couleur',10,2,'unités'],['Toner noir',5,1,'unités'],['Toner couleur',5,1,'unités'],['Film de contrecollage',20,4,'mètres'],['Huile / vernis',10,2,'unités']];
const DEMO_USERS=[
{id:'FLORY',username:'flory',email:'flory@wonder-shift.local',name:'Flory',role:'Agent',passwordHash:'ea95cc24a0a47eb1e92aba347dd19bae8e057109283a27972864a5c27f038903'},
{id:'AUGUSTIN',username:'augustin',email:'augustin@wonder-shift.local',name:'Augustin',role:'Agent',passwordHash:'bef694f2d3644ece57fe46c210e551686aa2339ef692dd867fe043945ac51bfd'},
{id:'ADMINISTRATEUR',username:'administrateur',email:'administrateur@wonder-shift.local',name:'Administrateur',role:'Administrateur',passwordHash:'982d23dd484e2be07ea736ce10fb48197e06df4b40b461e00ca43703a4836a7c'},
{id:'SUPERVISEUR',username:'superviseur',email:'superviseur@wonder-shift.local',name:'Superviseur',role:'Superviseur',passwordHash:'beda9ebb1958060f54fda1bfd40f3d63a5889784b19375caba262e2583e6207d'},
{id:'DEVELOPPEUR',username:'developpeur',email:'developpeur@wonder-shift.local',name:'Développeur',role:'Développeur',passwordHash:'f237a9444183a0a2bfa38677507e6f530067efa700adfcfab67881faccfbb3f4'}];
async function seedCatalog(){if(!(await dbAll('services')).length)for(const name of DEFAULT_SERVICES)await dbPut('services',{id:WS.uid('SRV'),name,active:true,builtin:true,createdAt:Date.now()});if(!(await dbAll('tasks')).length)for(const [name,price] of DEFAULT_TASKS)await dbPut('tasks',{id:WS.uid('TSK'),name,price,active:true,builtin:true,createdAt:Date.now()});if(!(await dbAll('stock')).length)for(const [name,initial,alert,unit] of DEFAULT_STOCK)await dbPut('stock',{id:WS.uid('STK'),name,initial,entries:0,exits:0,alert,unit,active:true,createdAt:Date.now()})}
async function seedUsers(){const existing=await dbAll('users');if(!existing.length){for(const u of DEMO_USERS)await dbPut('users',{...u,active:true,photo:'',createdAt:Date.now(),updatedAt:Date.now()});return}for(const demo of DEMO_USERS){const old=existing.find(x=>x.id===demo.id||x.username===demo.username||x.email===demo.email);if(!old){await dbPut('users',{...demo,active:true,photo:'',createdAt:Date.now(),updatedAt:Date.now()});continue}if(old.id==='ADMINISTRATEUR'&&old.passwordHash==='beda9ebb1958060f54fda1bfd40f3d63a5889784b19375caba262e2583e6207d'){old.passwordHash=demo.passwordHash;old.updatedAt=Date.now();await dbPut('users',old)}}}
function activeOperations(ops){return ops.filter(o=>!o.deleted&&o.status!=='deleted')}
async function recalcDerived(){
 const stocks=await dbAll('stock'),moves=await dbAll('stockMovements');
 for(const s of stocks){let entries=0,exits=0;for(const m of moves.filter(x=>x.stockId===s.id&&mActive(x))){const q=Number(m.quantity||0);if(q>=0)entries+=q;else exits+=Math.abs(q)}s.entries=entries;s.exits=exits;s.updatedAt=Date.now();await dbPut('stock',s)}
 const cms=await dbAll('cashMovements');for(const m of cms){if(m.operationId){const op=await dbGet('operations',m.operationId);const should=!!op&&!op.deleted;m.active=should;await dbPut('cashMovements',m)}}
}
function mActive(m){return m.active!==false&&!m.reversed}
async function applyApprovedDeletion(operation,reviewer,requestId){
 if(!operation||operation.deleted)return false;
 operation.deleted=true;operation.status='deleted';operation.deletedAt=Date.now();operation.deletedBy=reviewer.id;operation.updatedAt=Date.now();await dbPut('operations',operation);
 const cms=await dbAll('cashMovements');for(const m of cms.filter(x=>x.operationId===operation.id)){m.active=false;m.reversed=true;m.reversedAt=Date.now();m.reversedBy=reviewer.id;await dbPut('cashMovements',m)}
 const sms=await dbAll('stockMovements');for(const m of sms.filter(x=>x.operationId===operation.id)){m.active=false;m.reversed=true;m.reversedAt=Date.now();m.reversedBy=reviewer.id;await dbPut('stockMovements',m)}
 await dbPut('syncQueue',{id:WS.uid('SQ'),entity:'operations',entityId:operation.id,action:'upsert',createdAt:Date.now()});
 if(requestId){const r=await dbGet('changeRequests',requestId);if(r){r.status='approved';r.reviewedAt=Date.now();r.reviewerId=reviewer.id;await dbPut('changeRequests',r)}}
 await recalcDerived();return true
}
