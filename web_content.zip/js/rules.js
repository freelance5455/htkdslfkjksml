/* OPERATION: DISCIPLINE — regras de negócio (missões, XP, encerramento, descanso, sequências, conquistas).
   Sem DOM e sem armazenamento: opera sobre um objeto de estado S. O relógio é injetável (testes). */
(function(){'use strict';
var OD=globalThis.OD,U=OD.U,G=OD.G,E=U.E;
var ST=['P','A','C','F','X','R'],PR=['L','M','H'],SORTS=['time','priority','xp','title'],DAYR=['PERFECT','PARTIAL','REST','EXCUSED'];
var LOGMAX=100,LIMITS={title:120,desc:500,reason:200,cat:40,name:30};
var open=function(m){return m.s==='P'||m.s==='A'};           // aberta: pode ser concluída/cancelada/reagendada
var active=function(m){return m.s!=='X'&&m.s!=='R'};        // ocupa a data (conta para "principal única")
/* Regra de contagem (única e transparente): R nunca conta; X com justificativa não conta; X sem justificativa conta como falha;
   missões de dias de descanso não contam. */
var cnt=function(S,l){return l.filter(function(m){return m.s!=='R'&&!(m.s==='X'&&m.reason)&&!S.r[m.date]})};
var empty=function(){return{v:3,rev:0,m:[],l:[],d:{},r:{},n:1,c:['Saúde','Estudos','Trabalho','Finanças','Pessoal'].map(function(name,i){return{id:i+1,name:name}}),cn:6,ua:{},cfg:{name:'',sort:'time'}}};

function mk(S,clock){
clock=clock||function(){return U.iso(new Date())};
var today=function(){return clock()},nowTs=function(){return Date.now()};
var on=function(d){return S.m.filter(function(m){return m.date===d}).sort(function(a,b){return (b.main-a.main)||(a.time||'99').localeCompare(b.time||'99')||a.id-b.id})};
var get=function(id){return S.m.find(function(m){return m.id===id})||E('Missão não encontrada')};
var guard=function(d){if(S.d[d])E('O dia '+d+' está encerrado: reabra-o para alterar.')};
var noRest=function(d){if(S.r[d])E('O dia '+d+' é de descanso: remova o descanso para planejar missões.')};
var total=function(){return G.total(S)};
var lg=function(m,e,d){m.log.push({t:nowTs(),e:e,d:String(d).slice(0,200)});if(m.log.length>LOGMAX)m.log.splice(1,1)};
var grant=function(r,a,d){if(S.l.some(function(x){return x.r===r}))return false;S.l.push({r:r,a:a,d:d,t:nowTs()});return true};
/* Sincroniza lançamentos de um prefixo para que a soma seja `want` (bônus de dia perfeito, desafio de disciplina). Sempre por novo lançamento: o extrato nunca é reescrito. */
var sync=function(p,want,pos,neg){var l=S.l.filter(function(x){return x.r.indexOf(p)===0}),dl=want-l.reduce(function(a,x){return a+x.a},0);if(dl)grant(p+(l.length+1),dl,dl>0?pos:neg)};
var mainCheck=function(d,id){if(S.m.some(function(m){return m.date===d&&m.main&&m.id!==id&&active(m)}))E('Já existe uma missão principal neste dia.')};
var chk=function(o){
 if(!U.isO(o))E('Dados da missão inválidos');
 if(typeof o.title!=='string'||!o.title.trim())E('Título obrigatório');
 if(o.title.trim().length>LIMITS.title)E('Título muito longo (máx. 120)');
 if(o.desc!=null&&!U.str(o.desc,LIMITS.desc))E('Descrição muito longa (máx. 500)');
 if(!U.has(G.B,o.df))E('Dificuldade inválida');
 if(o.pr!=null&&PR.indexOf(o.pr)<0)E('Prioridade inválida');
 if(!U.validDate(o.date))E('Data inválida (use uma data real entre 2000 e 2100)');
 if(o.time&&!U.validTime(o.time))E('Horário inválido (use HH:mm)');
 if(o.due&&(!U.validDate(o.due)||o.due<o.date))E('Prazo inválido: use uma data real igual ou posterior à data da missão');
 if(o.cat&&!S.c.some(function(c){return c.id===o.cat}))E('Categoria inexistente')};
var fields=function(o){return{date:o.date,time:o.time||'',title:o.title.trim(),desc:(o.desc||'').trim(),df:o.df,pr:o.pr||'M',cat:o.cat||null,main:!!o.main,due:o.due||''}};
var LBL={date:'data',time:'horário',title:'título',desc:'descrição',df:'dificuldade',pr:'prioridade',cat:'categoria',main:'principal',due:'prazo'};
var evalDay=function(d){if(S.r[d])return 'REST';var ms=on(d);if(!ms.length)return 'UNPLANNED';var c=cnt(S,ms);return !c.length?'EXCUSED':c.every(function(m){return m.s==='C'})?'PERFECT':'PARTIAL'};
/* Estado do dia: encerrado → resultado; senão descanso marcado, planejado ou sem planejamento. */
var dayState=function(d){return S.d[d]||(S.r[d]?'REST':on(d).length?'PLANNED':'UNPLANNED')};
var streak=function(t){var k=Object.keys(S.d).sort();if(!k.length)return[0,0];var c=0,b=0,d=k[0];while(d<=t){var r=S.d[d];if(r==='PERFECT')c++;else if(r==='REST'||r==='EXCUSED'){}else if(r||d!==t)c=0;b=Math.max(b,c);d=U.add(d,1)}return[c,b]};
var evalAch=function(t){var paid={};S.l.forEach(function(x){var q=/^(W|WD|WE):(\d{4}-\d\d-\d\d)/.exec(x.r);if(q)paid[q[1]+q[2]]=(paid[q[1]+q[2]]||0)+x.a});
 var f={mis:S.m.filter(function(m){return m.s==='C'}).length,xp:total(),lv:G.lvl(total()),st:streak(t)[1],pf:Object.keys(S.d).filter(function(d){return S.d[d]==='PERFECT'}).length,wk:Object.keys(paid).filter(function(k){return paid[k]>0}).length},n=[];
 G.ACH.forEach(function(a){if(!S.ua[a[0]]&&f[a[3]]>=a[4]){S.ua[a[0]]=nowTs();n.push(a[0])}});return n};
var syncChallenges=function(t){var cur=U.wkStart(t),weeks={};weeks[cur]=1;
 S.m.forEach(function(m){if(m.s==='C'&&m.date<=t)weeks[U.wkStart(m.date)]=1});Object.keys(S.d).forEach(function(d){weeks[U.wkStart(d)]=1});
 Object.keys(weeks).filter(function(w){return w<=cur}).sort().forEach(function(ws){G.CH.forEach(function(c){var ok=G.chValue(S,c.k,ws)>=c.target,lbl='Desafio semanal '+c.cat+' '+ws;
  if(c.rev)sync(c.pfx+':'+ws+':',ok?G.CH_XP:0,lbl,'Estorno do '+lbl);else if(ok)grant(G.chRef(c,ws),G.CH_XP,lbl)})})};
var C={S:S,on:on,get:get,total:total,grant:grant,evalDay:evalDay,dayState:dayState,streak:streak,evalAch:evalAch,today:today,
 cnt:function(l){return cnt(S,l)},
 challenges:function(t){return G.challenges(S,U.wkStart(t))},
 post:function(t){syncChallenges(t);return evalAch(t)},
 bonusSync:function(d){sync('B:'+d+':',S.d[d]==='PERFECT'?G.PERF_XP:0,'Dia perfeito '+d,'Estorno de dia perfeito '+d)},
 addM:function(o){chk(o);guard(o.date);noRest(o.date);if(o.main)mainCheck(o.date,0);var f=fields(o);
  var m=Object.assign({id:S.n++},f,{s:'P',reason:'',xp:G.xpOf(f.df,f.main),created:nowTs(),log:[]});lg(m,'criada','Criada para '+f.date);S.m.push(m);return m.id},
 editM:function(id,o){var m=get(id);if(!open(m))E('Só missões abertas podem ser editadas');chk(o);guard(m.date);guard(o.date);noRest(o.date);if(o.main)mainCheck(o.date,id);var f=fields(o),ch=[];
  Object.keys(LBL).forEach(function(k){if(m[k]!==f[k])ch.push(LBL[k])});Object.assign(m,f,{xp:G.xpOf(f.df,f.main)});lg(m,'editada',ch.length?'Alterado: '+ch.join(', '):'Salvo sem alterações')},
 start:function(id){var m=get(id);guard(m.date);if(m.s==='A')return;if(m.s!=='P')E('Esta missão não pode ser iniciada');if(m.date>today())E('Esta missão é de '+m.date+': ainda não pode ser iniciada.');m.s='A';lg(m,'iniciada','Marcada como em andamento')},
 /* Conclusão antecipada NÃO é permitida: só a partir da data da missão (dias passados ainda abertos aceitam conclusão tardia). */
 complete:function(id){var m=get(id);guard(m.date);if(m.s==='C')return;if(!open(m))E('Esta missão não pode ser concluída');if(m.date>today())E('Conclusão antecipada não permitida: esta missão é de '+m.date+'.');m.s='C';grant('MC:'+id,m.xp,'Missão: '+m.title);lg(m,'concluida','+'+m.xp+' XP')},
 cancel:function(id,r){var m=get(id);guard(m.date);if(!open(m))E('Esta missão não pode ser cancelada');r=(r||'').trim();if(r.length>LIMITS.reason)E('Justificativa muito longa (máx. 200)');m.s='X';m.reason=r;lg(m,'cancelada',r?'Justificativa: '+r:'Sem justificativa (conta como falha)')},
 /* tm: undefined/null = mantém o horário da original. */
 resch:function(id,t,tm){var m=get(id),td=today();if(!U.validDate(t))E('Data inválida (use uma data real entre 2000 e 2100)');if(tm!=null&&tm!==''&&!U.validTime(tm))E('Horário inválido (use HH:mm)');
  if(!open(m))E('Esta missão não pode ser reagendada');if(t===m.date)E('Escolha outra data');if(t<td)E('Não é possível reagendar para o passado');if(m.due&&t>m.due)E('A nova data ultrapassa o prazo da missão ('+m.due+')');guard(m.date);guard(t);noRest(t);
  var keep=m.main&&!S.m.some(function(x){return x.date===t&&x.main&&active(x)}),n=S.n++;m.s='R';m.reason='Reagendada para '+t;m.to=n;lg(m,'reagendada','Reagendada para '+t+' (nova missão #'+n+')');
  var nm={id:n,date:t,time:tm==null?m.time:tm,title:m.title,desc:m.desc,df:m.df,pr:m.pr,cat:m.cat,main:keep,s:'P',reason:'',xp:G.xpOf(m.df,keep),due:m.due||'',created:nowTs(),log:[],from:m.id};
  lg(nm,'criada','Reagendada a partir da missão #'+m.id+' ('+m.date+')');S.m.push(nm);return{id:n,mainKept:keep}},
 toggleMain:function(id){var m=get(id);guard(m.date);if(!open(m))E('Só missões abertas');if(!m.main)mainCheck(m.date,id);m.main=!m.main;m.xp=G.xpOf(m.df,m.main);lg(m,'editada',m.main?'Marcada como principal':'Removida de principal')},
 setRest:function(d,v){if(!U.validDate(d))E('Data inválida');guard(d);if(v&&S.m.some(function(m){return m.date===d&&active(m)}))E('O dia tem missões pendentes ou concluídas: cancele ou reagende antes de marcar descanso.');if(v)S.r[d]=1;else delete S.r[d]},
 /* Encerrar é sempre explícito. Pendências só viram "não concluídas" com opt.fail===true (decisão do usuário). */
 close:function(d,t,opt){opt=opt||{};if(!U.validDate(d))E('Data inválida');if(d>t)E('Não é possível encerrar um dia futuro');if(S.d[d])return S.d[d];var ms=on(d);if(!ms.length&&!S.r[d])E('Dia sem planejamento não pode ser encerrado');var p=ms.filter(open);
  if(p.length&&!opt.fail)E(p.length+' missão(ões) pendente(s): conclua, reagende, cancele ou confirme marcá-las como não concluídas.');
  p.forEach(function(m){m.s='F';m.auto=1;lg(m,'falhou','Dia encerrado sem conclusão')});var r=evalDay(d);S.d[d]=r;C.bonusSync(d);return r},
 reopen:function(d){if(!S.d[d])E('Dia não está encerrado');on(d).filter(function(m){return m.auto}).forEach(function(m){m.s='P';delete m.auto;lg(m,'reaberta','Dia reaberto: voltou a pendente')});delete S.d[d];C.bonusSync(d)},
 pendingDays:function(t){var ds={};S.m.forEach(function(m){ds[m.date]=1});Object.keys(S.r).forEach(function(d){ds[d]=1});
  return Object.keys(ds).filter(function(d){return d<t&&!S.d[d]}).sort().map(function(d){var l=on(d);return{d:d,n:l.length,pend:l.filter(open).length,rest:!!S.r[d]}})},
 addCat:function(n){n=(n||'').trim();if(!n)E('Nome obrigatório');if(n.length>LIMITS.cat)E('Nome muito longo (máx. 40)');if(S.c.some(function(c){return c.name.toLowerCase()===n.toLowerCase()}))E('Categoria já existe');if(S.c.length>=200)E('Limite de categorias atingido');S.c.push({id:S.cn++,name:n})},
 renCat:function(id,n){n=(n||'').trim();if(!n)E('Nome obrigatório');if(n.length>LIMITS.cat)E('Nome muito longo (máx. 40)');if(S.c.some(function(c){return c.id!==id&&c.name.toLowerCase()===n.toLowerCase()}))E('Categoria já existe');(S.c.find(function(c){return c.id===id})||E('Categoria inexistente')).name=n},
 delCat:function(id){if(S.m.some(function(m){return m.cat===id}))E('Categoria em uso por missões');S.c=S.c.filter(function(c){return c.id!==id})},
 setCfg:function(o){if(!U.isO(o))E('Configuração inválida');var n=o.name==null?S.cfg.name:String(o.name).trim(),s=o.sort==null?S.cfg.sort:o.sort;if(n.length>LIMITS.name)E('Nome muito longo (máx. 30)');if(SORTS.indexOf(s)<0)E('Ordenação inválida');S.cfg={name:n,sort:s}},
 exportJson:function(){return OD.Backup.exportJson(S)}};
return C}

OD.Rules={mk:mk,empty:empty,cnt:cnt,open:open,active:active,ST:ST,PR:PR,SORTS:SORTS,DAYR:DAYR,LIMITS:LIMITS};
})();
