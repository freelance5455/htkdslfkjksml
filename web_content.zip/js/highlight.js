(function () {
  "use strict";

  function esc(s) {
    return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }
  function span(cls, text) { return '<span class="tk-' + cls + '">' + esc(text) + "</span>"; }

  function highlightHTML(code) {
    let out = "", i = 0;
    const n = code.length;
    while (i < n) {
      if (code.startsWith("<!--", i)) {
        const end = code.indexOf("-->", i + 4);
        const stop = end === -1 ? n : end + 3;
        out += span("com", code.slice(i, stop)); i = stop;
      } else if (code[i] === "<") {
        const end = code.indexOf(">", i);
        const stop = end === -1 ? n : end + 1;
        out += highlightTag(code.slice(i, stop)); i = stop;
      } else {
        let j = i;
        while (j < n && code[j] !== "<") j++;
        out += esc(code.slice(i, j)); i = j;
      }
    }
    return out;
  }

  function highlightTag(tag) {
    let out = "", i = 0;
    const n = tag.length;
    if (tag[i] === "<") { out += span("punct", "<"); i++; }
    if (tag[i] === "/") { out += span("punct", "/"); i++; }
    let name = "";
    while (i < n && /[a-zA-Z0-9!\-]/.test(tag[i])) name += tag[i++];
    if (name) out += span("tag", name);
    while (i < n) {
      const c = tag[i];
      if (c === ">") { out += span("punct", ">"); i++; }
      else if (c === "/") { out += span("punct", "/"); i++; }
      else if (/\s/.test(c)) { out += esc(c); i++; }
      else if (c === '"' || c === "'") {
        let j = i + 1;
        while (j < n && tag[j] !== c) j++;
        out += span("str", tag.slice(i, Math.min(j + 1, n)));
        i = j + 1;
      } else if (c === "=") { out += span("punct", "="); i++; }
      else {
        let attr = "";
        while (i < n && !/[\s=>/]/.test(tag[i])) attr += tag[i++];
        out += span("attr", attr);
      }
    }
    return out;
  }

  function highlightCSS(code) {
    let out = "", i = 0;
    const n = code.length;
    while (i < n) {
      if (code.startsWith("/*", i)) {
        const end = code.indexOf("*/", i + 2);
        const stop = end === -1 ? n : end + 2;
        out += span("com", code.slice(i, stop)); i = stop;
      } else if (code[i] === "{") {
        out += span("punct", "{"); i++;
        while (i < n && code[i] !== "}") {
          if (code.startsWith("/*", i)) {
            const end = code.indexOf("*/", i + 2);
            const stop = end === -1 ? n : end + 2;
            out += span("com", code.slice(i, stop)); i = stop;
          } else if (code[i] === ":") { out += span("punct", ":"); i++; }
          else if (code[i] === ";") { out += span("punct", ";"); i++; }
          else if (/\s/.test(code[i])) { out += esc(code[i]); i++; }
          else {
            let tok = "";
            while (i < n && !/[\s:;{}]/.test(code[i])) tok += code[i++];
            out += span("prop", tok);
          }
        }
        if (i < n) { out += span("punct", "}"); i++; }
      } else {
        let sel = "";
        while (i < n && code[i] !== "{" && code[i] !== "}") sel += code[i++];
        out += span("sel", sel);
      }
    }
    return out;
  }

  const KW = /\b(var|let|const|function|return|if|else|for|while|do|switch|case|break|continue|new|this|class|extends|super|import|export|from|default|try|catch|finally|throw|typeof|instanceof|in|of|async|await|yield|delete|void|null|undefined|true|false)\b/;

  function highlightJS(code) {
    let out = "", i = 0;
    const n = code.length;
    while (i < n) {
      if (code.startsWith("//", i)) {
        let j = code.indexOf("\n", i);
        if (j === -1) j = n;
        out += span("com", code.slice(i, j)); i = j;
      } else if (code.startsWith("/*", i)) {
        const end = code.indexOf("*/", i + 2);
        const stop = end === -1 ? n : end + 2;
        out += span("com", code.slice(i, stop)); i = stop;
      } else if (code[i] === '"' || code[i] === "'" || code[i] === "`") {
        const q = code[i];
        let j = i + 1;
        while (j < n && code[j] !== q) { if (code[j] === "\\") j++; j++; }
        out += span("str", code.slice(i, Math.min(j + 1, n)));
        i = j + 1;
      } else if (/[0-9]/.test(code[i]) && !/[a-zA-Z_]/.test(code[i - 1] || "")) {
        let num = "";
        while (i < n && /[0-9.xXa-fA-F]/.test(code[i])) num += code[i++];
        out += span("num", num);
      } else if (/[a-zA-Z_$]/.test(code[i])) {
        let word = "";
        while (i < n && /[a-zA-Z0-9_$]/.test(code[i])) word += code[i++];
        if (KW.test(word)) out += span("kw", word);
        else if (code[i] === "(") out += span("fn", word);
        else out += esc(word);
      } else { out += esc(code[i]); i++; }
    }
    return out;
  }

  function highlight(code, lang) {
    switch (lang) {
      case "html": case "xml": return highlightHTML(code);
      case "css": return highlightCSS(code);
      case "js": case "json": return highlightJS(code);
      default: return esc(code);
    }
  }

  window.Highlighter = { highlight, esc };
})();