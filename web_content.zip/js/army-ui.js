/* army-ui.js — Phase 2 interface: army panel, army management (Armies / Recruit / Queue / Generals). */
(function (G) {
  'use strict';
  const $ = id => document.getElementById(id);
  const fmt = n => Math.round(n).toLocaleString('en-US');
  const pct = x => Math.round(x * 100) + '%';
  let tab = 'recruit', recruitProv = null;

  function bar(frac, cls) {
    return '<div class="bar ' + (cls || '') + '"><i style="width:' + Math.max(0, Math.min(100, frac * 100)).toFixed(0) + '%"></i></div>';
  }
  function cell(l, v) { return '<div class="cell"><span>' + l + '</span>' + v + '</div>'; }
  function traitText(g) { const t = G.GEN_TRAITS[g.trait] || { icon: '', desc: '' }; return t.icon + ' ' + g.trait + ': ' + t.desc; }
  const GEN_HELP = '<div class="help" style="margin-bottom:8px"><b>How generals work</b><br>A general commands <b>one army</b>. Each ★ of skill gives that army <b>+5% attack, defense and firepower</b>. The trait adds a special bonus. A general with no army is idle and gives nothing. New armies get the best free general automatically; you can change it any time.</div>';
  G.showGeneralPicker = function (a) {
    const list = G.state.generals[a.owner].filter(g => !g.army || g.army === a.id).sort((x, y) => y.skill - x.skill);
    let h = '<h3>🎖 General for ' + a.name + '</h3>' + GEN_HELP;
    h += list.map(g => '<div class="slot"><div class="info"><b>' + g.name + '</b> <small style="color:var(--gold)">' + stars(g.skill) + ' (+' + g.skill * 5 + '%)</small><br><small>' + traitText(g) + '</small></div>' +
      (g.army === a.id ? '<button disabled>Current</button>' : '<button class="primary" data-g="' + g.id + '">Assign</button>') + '</div>').join('') || '<p class="dim">No free generals.</p>';
    h += '<div class="row">' + (a.general ? '<button id="g-none" class="danger">Remove general</button>' : '') + '<button id="g-back">Close</button></div>';
    $('modal-box').innerHTML = h; $('modal').classList.remove('hidden');
    document.querySelectorAll('#modal-box button[data-g]').forEach(b => b.onclick = () => { G.assignGeneral(a, +b.dataset.g); G.closeModal(); G.renderArmyPanel(); G.toast('General assigned'); });
    const n = $('g-none'); if (n) n.onclick = () => { G.assignGeneral(a, null); G.closeModal(); G.renderArmyPanel(); };
    $('g-back').onclick = G.closeModal;
  };
  function stars(n) { return '★'.repeat(n) + '☆'.repeat(Math.max(0, 5 - n)); }
  function me() { return G.state.player; }

  /* =============== army panel (bottom sheet / side panel) =============== */
  G.showArmyPanel = function () {
    $('panel').classList.remove('hidden');
    G.renderArmyPanel();
    requestAnimationFrame(() => { const a = G.armyById(G.selArmy); if (a) G.ensureVisible(a.prov); });
  };

  G.renderArmyPanel = function () {
    const a = G.armyById(G.selArmy);
    if (!a) { $('panel').classList.add('hidden'); G.selArmy = null; return; }
    const st = G.state, c = G.COUNTRIES[a.owner], mine = a.owner === me(), s = G.armySummary(a), prov = G.provinces[a.prov];
    const g = s.general;
    let status = 'Stationed';
    if (G.inBattle(a)) status = '⚔ IN BATTLE';
    else if (st.occ && st.occ[a.prov] && st.occ[a.prov].by === a.owner) status = '🚩 Occupying (' + st.occ[a.prov].days + '/' + G.occupationNeed(a.prov) + ')';
    if (a.path.length) status = 'Marching to ' + G.provinces[a.path[a.path.length - 1]].name + ' — ETA ' + G.etaDays(a) + 'd';
    let h = '<div class="ph"><img src="' + G.flagURL(a.owner) + '"><div><h2>' + a.name + '</h2><div class="sub">' + c.name +
      ' · at ' + prov.name + (mine ? ' (you)' : '') + '</div></div><button class="x" id="p-close">✕</button></div>';
    h += '<div class="grid">' +
      cell('Units', s.n + ' / ' + G.ARMY_MAX_UNITS) + cell('Men', fmt(s.men) + ' / ' + fmt(s.maxMen)) +
      cell('Strength', pct(s.strength) + bar(s.strength, 'g')) + cell('Organization', pct(s.org) + bar(s.org, 'b')) +
      cell('Morale', Math.round(s.morale) + bar(s.morale / 100, 'y')) + cell('Speed', s.speed + ' u/day') +
      cell('Attack', s.atk.toFixed(1)) + cell('Defense', s.def.toFixed(1)) +
      cell('General', g ? g.name + '<br><small style="color:var(--gold)">' + stars(g.skill) + '</small><br><small>' + traitText(g) + '</small>' : '<i>None — army fights without a commander</i>') +
      cell('Supply', Math.round(G.supply(a) * 100) + '%') + cell('Status', status) + '</div>';
    h += '<div class="units">' + a.units.map((u, i) => {
      const d = G.UNITS[u.type], us = G.unitStats(u);
      return '<div class="urow"><span class="utag">' + d.icon + '</span><div class="uinfo"><b>' + d.name + '</b>' +
        '<div class="ubars">' + bar(us.strength, 'g') + bar(us.orgPct, 'b') + '</div>' +
        '<small>' + fmt(u.men) + '/' + d.men + ' men · org ' + Math.round(u.org) + '/' + d.org + ' · morale ' + Math.round(u.morale) + '</small></div>' +
        (mine && s.n > 1 && !a.path.length ? '<button class="mini" data-d="' + i + '" title="Split into new army">Detach</button>' : '') + '</div>';
    }).join('') + '</div>';
    if (mine) {
      const others = G.armiesAt(a.prov).filter(o => o !== a && o.owner === a.owner && !o.path.length);
      h += '<div class="chips">' +
        '<button class="primary" id="a-move">' + (G.moveMode ? 'Cancel move' : '➜ Move') + '</button>' +
        (a.path.length ? '<button id="a-stop">⏹ Stop</button>' : '') +
        (G.armySailHtml ? G.armySailHtml(a) : '') +
        '<button id="a-gen">🎖 General…</button>' +
        (others.length && !a.path.length ? '<button id="a-merge">⛓ Merge (' + others.length + ')</button>' : '') +
        '<button id="a-rec">＋ Recruit here</button>' +
        '<button id="a-disb" class="danger">Disband</button></div>';
    }
    $('panel-body').innerHTML = h;
    $('p-close').onclick = () => { G.selArmy = null; G.moveMode = false; G.requestDraw(); $('panel').classList.add('hidden'); };
    if (!mine) return;
    $('a-move').onclick = () => {
      if (a.path.length === 0 && !a.units.length) return;
      G.sailMode = false; G.moveMode = !G.moveMode; G.requestDraw(); G.renderArmyPanel();
      if (G.moveMode) G.toast('Tap a destination province (your territory)');
    };
    G.bindArmySail && G.bindArmySail(a, () => G.renderArmyPanel());
    const stop = $('a-stop'); if (stop) stop.onclick = () => { G.stopArmy(a); G.toast('Army halted'); G.renderArmyPanel(); G.requestDraw(); };
    $('a-gen').onclick = () => G.showGeneralPicker(a);
    const mg = $('a-merge');
    if (mg) mg.onclick = () => {
      let n = 0; others.forEach(o => { if (G.mergeArmies(a, o)) n++; });
      G.toast(n ? 'Merged ' + n + ' armies' : 'Army would exceed ' + G.ARMY_MAX_UNITS + ' units');
      G.renderArmyPanel(); G.requestDraw();
    };
    $('a-rec').onclick = () => { recruitProv = a.prov; tab = 'recruit'; G.showArmyMgmt(); };
    $('a-disb').onclick = () => G.confirmBox('Disband ' + a.name + '? Men return to your manpower pool; equipment is lost.', 'Disband', () => {
      G.disbandArmy(a); G.selArmy = null; G.moveMode = false; $('panel').classList.add('hidden'); G.updateTopBar(); G.requestDraw();
      G.toast('Army disbanded');
    });
    document.querySelectorAll('#panel-body button[data-d]').forEach(b => b.onclick = () => {
      const n = G.detachUnit(a, +b.dataset.d);
      if (n) { G.selArmy = n.id; G.toast('Detached into ' + n.name); G.renderArmyPanel(); G.requestDraw(); }
    });
  };

  G.onArmySelect = function (id) { G.moveMode = false; G.showArmyPanel(); };
  G.onMoveTarget = function (pid) {
    const a = G.armyById(G.selArmy);
    const sail = G.sailMode; G.moveMode = false; G.sailMode = false;
    if (a && pid != null && sail) {
      const r = G.orderAmphibious(a, pid);
      G.toast(r.ok ? (r.msg || 'Embarking — sailing to ' + G.provinces[pid].name) : r.msg);
    } else if (a && pid != null && !G.provinces[pid].sea) {
      const r = G.orderMove(a, pid);
      G.toast(r.ok ? 'Moving to ' + G.provinces[pid].name + ' — ETA ' + r.eta + ' days' : r.msg);
      if (r.ok && G.state.paused) G.toast('Moving to ' + G.provinces[pid].name + ' — press ▶ to advance time');
    } else if (pid != null) G.toast('Choose a land province');
    G.renderArmyPanel(); G.requestDraw();
  };
  G.onDeploy = function (a, item) { G.toast(G.UNITS[item.type].name + ' deployed at ' + G.provinces[item.prov].name); };
  G.onArrive = function (a) { if (a.owner === me()) G.toast(a.name + ' arrived at ' + G.provinces[a.prov].name); };

  /* =============== army management modal =============== */
  G.showArmyMgmt = function () {
    const st = G.state, pid = me(), c = st.countries[pid];
    if (recruitProv == null || st.owners[recruitProv] !== pid) {
      recruitProv = (G.selected != null && st.owners[G.selected] === pid) ? G.selected : G.COUNTRIES[pid].capitalId;
    }
    let h = '<h3>⚔ Army Command — ' + G.COUNTRIES[pid].name + '</h3>' +
      '<div class="eqline">💰 ' + fmt(c.treasury) + ' · 👥 ' + fmt(c.manpower) + ' · 🔫 ' + fmt(c.equip.rifles) + ' · 🐎 ' + fmt(c.equip.horses) +
      ' · 💣 ' + fmt(c.equip.guns) + ' · 🚚 ' + fmt(c.equip.vehicles) + '</div>' +
      '<div class="tabs">' + ['recruit', 'queue', 'armies', 'generals', 'log'].map(t =>
        '<button data-t="' + t + '" class="' + (tab === t ? 'on' : '') + '">' + ({ recruit: 'Recruit', queue: 'Queue (' + st.queues[pid].length + ')', armies: 'Armies (' + st.armies.filter(a => a.owner === pid).length + ')', generals: 'Generals', log: 'Log' })[t] + '</button>').join('') + '</div>';
    if (tab === 'recruit') h += recruitTab(pid);
    else if (tab === 'queue') h += queueTab(pid);
    else if (tab === 'armies') h += armiesTab(pid);
    else if (tab === 'log') h += logTab();
    else h += generalsTab(pid);
    h += '<div class="row"><button id="am-close">Close</button></div>';
    $('modal-box').innerHTML = h; $('modal').classList.remove('hidden');
    $('am-close').onclick = G.closeModal;
    document.querySelectorAll('#modal-box .tabs button[data-t]').forEach(b => b.onclick = () => { tab = b.dataset.t; G.showArmyMgmt(); });
    bindTab(pid);
  };

  function recruitTab(pid) {
    const st = G.state;
    const own = G.provinces.filter(p => !p.sea && st.owners[p.id] === pid);
    let h = '<div style="margin:6px 0">Recruit in: <select id="rc-prov">' +
      own.map(p => '<option value="' + p.id + '"' + (p.id === recruitProv ? ' selected' : '') + '>' + p.name + (p.capital ? ' ★' : '') + '</option>').join('') + '</select></div>';
    h += '<div class="ucards">' + Object.keys(G.UNITS).map(k => {
      const d = G.UNITS[k], chk = G.canRecruit(pid, k, recruitProv);
      const eq = Object.keys(d.equip).map(e => d.equip[e] + ' ' + G.EQUIP_NAMES[e].toLowerCase()).join(', ');
      return '<div class="ucard"><div class="uh"><span class="utag">' + d.icon + '</span><b>' + d.name + '</b></div><small>' + d.desc + '</small>' +
        '<div class="ucost">💰 ' + d.gold + ' · 👥 ' + d.men + ' · ⏱ ' + d.train + 'd<br>' + eq + '</div>' +
        '<div class="ustats">ATK ' + d.atk + ' · DEF ' + d.def + ' · ORG ' + d.org + ' · SPD ' + d.speed + '</div>' +
        '<button class="' + (chk.ok ? 'primary' : '') + '" data-r="' + k + '"' + (chk.ok ? '' : ' disabled') + '>' + (chk.ok ? 'Recruit' : chk.msg) + '</button></div>';
    }).join('') + '</div>';
    return h;
  }
  function queueTab(pid) {
    const q = G.state.queues[pid];
    if (!q.length) return '<p class="dim">Nothing in training. Recruit units from the Recruit tab.</p>';
    return q.map(it => {
      const d = G.UNITS[it.type];
      return '<div class="slot"><span class="utag">' + d.icon + '</span><div class="info"><b>' + d.name + '</b> <small>at ' + G.provinces[it.prov].name + ' · ' + it.left + ' days left</small>' +
        bar(1 - it.left / it.total, 'g') + '</div><button class="danger" data-c="' + it.id + '">Cancel</button></div>';
    }).join('');
  }
  function armiesTab(pid) {
    const list = G.state.armies.filter(a => a.owner === pid);
    if (!list.length) return '<p class="dim">You have no armies.</p>';
    return list.map(a => {
      const s = G.armySummary(a);
      return '<div class="slot"><div class="info"><b>' + a.name + '</b> <small>' + s.n + ' units · ' + fmt(s.men) + ' men · at ' + G.provinces[a.prov].name +
        (a.path.length ? ' → ' + G.provinces[a.path[a.path.length - 1]].name : '') + '</small><br><small>' + (s.general ? '🎖 ' + s.general.name : 'No general') +
        ' · strength ' + pct(s.strength) + ' · org ' + pct(s.org) + '</small></div><button data-a="' + a.id + '">Select</button></div>';
    }).join('');
  }
  function logTab() {
    const l = G.state.log;
    return l.length ? '<div class="logbox">' + l.map(x => '<div>' + x + '</div>').join('') + '</div>' : '<p class="dim">No events yet.</p>';
  }
  function generalsTab(pid) {
    const gl = G.state.generals[pid].slice().sort((x, y) => y.skill - x.skill);
    return GEN_HELP + gl.map(g => {
      const a = g.army ? G.armyById(g.army) : null;
      return '<div class="slot"><div class="info"><b>' + g.name + '</b> <small style="color:var(--gold)">' + stars(g.skill) + ' (+' + g.skill * 5 + '%)</small><br><small>' + traitText(g) + '</small><br><small>' + (a ? '➜ commands ' + a.name + ' at ' + G.provinces[a.prov].name : '💤 idle — assign from an army panel (🎖 General…)') + '</small></div>' +
        (a ? '<button class="mini" data-gf="' + a.id + '">Show</button>' : '') + '</div>';
    }).join('');
  }

  function bindTab(pid) {
    const sel = $('rc-prov'); if (sel) sel.onchange = () => { recruitProv = +sel.value; G.showArmyMgmt(); };
    document.querySelectorAll('#modal-box button[data-r]').forEach(b => b.onclick = () => {
      const r = G.recruit(pid, b.dataset.r, recruitProv);
      G.toast(r.ok ? G.UNITS[b.dataset.r].name + ' queued (' + G.UNITS[b.dataset.r].train + ' days)' : r.msg);
      G.updateTopBar(); G.showArmyMgmt();
    });
    document.querySelectorAll('#modal-box button[data-c]').forEach(b => b.onclick = () => { G.cancelRecruit(pid, +b.dataset.c); G.toast('Cancelled — resources refunded'); G.updateTopBar(); G.showArmyMgmt(); });
    document.querySelectorAll('#modal-box button[data-gf]').forEach(b => b.onclick = () => { const a = G.armyById(+b.dataset.gf); if (!a) return; G.closeModal(); G.selArmy = a.id; G.selected = null; G.focusProvince(a.prov); G.showArmyPanel(); G.requestDraw(); });
    document.querySelectorAll('#modal-box button[data-a]').forEach(b => b.onclick = () => {
      const a = G.armyById(+b.dataset.a); if (!a) return;
      G.closeModal(); G.selArmy = a.id; G.selected = null; G.focusProvince(a.prov); G.showArmyPanel(); G.requestDraw();
    });
  }

  /* province panel hook: recruit button + armies present (called from ui.js) */
  G.provinceArmyHtml = function (provId) {
    const st = G.state, here = G.armiesAt(provId).filter(a => G.canSee(a));
    let h = '';
    if (here.length) h += '<div class="chips"><span style="font-size:12px;color:var(--dim);align-self:center">Armies here:</span>' +
      here.map(a => '<span class="chip" data-army="' + a.id + '">' + G.COUNTRIES[a.owner].adj + ' ' + a.name + ' (' + a.units.length + ')</span>').join('') + '</div>';
    if (st.owners[provId] === st.player) h += '<div class="chips"><button id="pv-rec" class="primary">＋ Recruit here</button></div>';
    return h;
  };
  G.bindProvinceArmy = function (provId) {
    const b = $('pv-rec'); if (b) b.onclick = () => { recruitProv = provId; tab = 'recruit'; G.showArmyMgmt(); };
    document.querySelectorAll('#panel-body .chip[data-army]').forEach(ch => ch.onclick = () => { G.selArmy = +ch.dataset.army; G.selected = null; G.showArmyPanel(); G.requestDraw(); });
  };

  G.bindArmyUI = function () {
    $('btn-army').onclick = () => { G.showArmyMgmt(); };
  };
})(window.EMP = window.EMP || {});
