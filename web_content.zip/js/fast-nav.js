/*
 * NetEarn Pro — Fast Navigation
 *
 * Warm internal pages without starting a competing network fetch at tap time.
 * Existing navigation, Firebase logic and page behavior remain unchanged.
 */
(function () {
  'use strict';

  if (window.__NetEarnFastNav) return;
  window.__NetEarnFastNav = true;

  const warmed = new Set();
  const MAX_WARM = 12;

  function shouldSkip() {
    try {
      const c = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
      if (c && c.saveData) return true;
    } catch (_) {}
    return false;
  }

  function isWarmable(link) {
    if (!link || !link.href) return false;
    if (link.target && link.target !== '_self') return false;
    if (link.hasAttribute('download')) return false;
    if (link.getAttribute('rel') === 'external') return false;

    let url;
    try { url = new URL(link.href, location.href); }
    catch (_) { return false; }

    if (url.origin !== location.origin) return false;
    if (url.hash && url.pathname === location.pathname) return false;
    if (!/^https?:$/.test(url.protocol)) return false;

    const path = url.pathname.toLowerCase();
    return path.endsWith('.html') || path === '/' || path.endsWith('/');
  }

  function warmPage(link) {
    if (shouldSkip() || !isWarmable(link)) return;

    let href;
    try { href = new URL(link.href, location.href).href; }
    catch (_) { return; }

    if (warmed.has(href) || warmed.size >= MAX_WARM) return;
    warmed.add(href);

    // Let the browser manage prioritization/cache behavior. This avoids the
    // previous tap-time fetch competing with the actual page navigation.
    const prefetch = document.createElement('link');
    prefetch.rel = 'prefetch';
    prefetch.href = href;
    document.head.appendChild(prefetch);
  }

  document.addEventListener('pointerover', function (event) {
    const link = event.target.closest && event.target.closest('a[href]');
    if (link) warmPage(link);
  }, { passive: true });

  // Desktop/compatible pointer devices can warm on press. On touch devices
  // we deliberately do not start a competing fetch at touchstart.
  document.addEventListener('pointerdown', function (event) {
    if (event.pointerType === 'touch') return;
    const link = event.target.closest && event.target.closest('a[href]');
    if (link) warmPage(link);
  }, { passive: true });
})();
