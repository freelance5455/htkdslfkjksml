// =======================================
// NetEarn Pro
// Login System - FINAL SAFE VERSION
// Firebase Authentication + Firestore
// Block Check + Remember Me + Password Reset
// =======================================


import {
    auth,
    db
} from "./firebase.js";


import {
    signInWithEmailAndPassword,
    sendPasswordResetEmail,
    signOut
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";


import {
    doc,
    getDoc
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";



// =======================================
// ELEMENTS
// =======================================

const emailInput =
    document.getElementById("email");


const passwordInput =
    document.getElementById("password");


const togglePassword =
    document.getElementById("togglePassword");


const rememberMe =
    document.getElementById("rememberMe");


const loginBtn =
    document.getElementById("loginBtn");


const forgotPassword =
    document.getElementById("forgotPassword");



// =======================================
// PASSWORD SHOW / HIDE
// =======================================

if (togglePassword && passwordInput) {

    togglePassword.addEventListener(
        "click",
        () => {

            if (
                passwordInput.type ===
                "password"
            ) {

                passwordInput.type =
                    "text";

                togglePassword.textContent =
                    "🙈";

            }

            else {

                passwordInput.type =
                    "password";

                togglePassword.textContent =
                    "👁️";

            }

        }
    );


    // Keyboard support
    togglePassword.addEventListener(
        "keydown",
        (event) => {

            if (
                event.key === "Enter" ||
                event.key === " "
            ) {

                event.preventDefault();

                togglePassword.click();

            }

        }
    );

}



// =======================================
// LOGIN SYSTEM
// =======================================

if (loginBtn) {

    loginBtn.addEventListener(
        "click",
        async () => {


            // ===================================
            // GET VALUES
            // ===================================

            const email =
                emailInput
                    ?.value
                    ?.trim()
                    ?.toLowerCase() || "";


            const password =
                passwordInput
                    ?.value || "";


            const remember =
                rememberMe
                    ?.checked || false;



            // ===================================
            // BASIC VALIDATION
            // ===================================

            if (!email || !password) {

                alert(
                    "❌ Please enter your Email and Password."
                );

                return;

            }



            // ===================================
            // DISABLE BUTTON
            // ===================================

            loginBtn.disabled =
                true;


            const oldButtonText =
                loginBtn.innerText;


            loginBtn.innerText =
                "⏳ Signing In...";



            try {


                // ===================================
                // FIREBASE LOGIN
                // ===================================

                await signInWithEmailAndPassword(
                    auth,
                    email,
                    password
                );



                // ===================================
                // CURRENT USER
                // ===================================

                const currentUser =
                    auth.currentUser;


                if (!currentUser) {

                    throw new Error(
                        "LOGIN_USER_NOT_FOUND"
                    );

                }


                const uid =
                    currentUser.uid;



                // ===================================
                // GET USER DOCUMENT
                // ===================================

                const userRef =
                    doc(
                        db,
                        "users",
                        uid
                    );


                const userSnap =
                    await getDoc(
                        userRef
                    );



                // ===================================
                // USER DOCUMENT CHECK
                // ===================================

                if (!userSnap.exists()) {

                    /*
                     * Firebase Auth account exists,
                     * but NetEarn users document
                     * does not exist.
                     *
                     * Sign out for safety.
                     */

                    await signOut(auth);


                    throw new Error(
                        "USER_DOCUMENT_NOT_FOUND"
                    );

                }



                const userData =
                    userSnap.data();



                // ===================================
                // BLOCK CHECK
                // ===================================

                if (
                    userData.blocked === true
                ) {


                    const blockReason =
                        userData.blockReason ||
                        "No reason provided.";


                    localStorage.setItem(
                        "blockReason",
                        blockReason
                    );


                    // -------------------------------
                    // Sign out blocked user
                    // -------------------------------

                    await signOut(auth);


                    // -------------------------------
                    // Redirect
                    // -------------------------------

                    window.location.href =
                        "blocked.html";


                    return;

                }



                // ===================================
                // ACCOUNT STATUS CHECK
                // ===================================

                /*
                 * Existing system uses:
                 *
                 * status: "active"
                 *
                 * We do NOT block other statuses
                 * here because the existing project
                 * may use them elsewhere.
                 *
                 * Only explicit blocked === true
                 * blocks login.
                 */



                // ===================================
                // REMEMBER ME
                // ===================================

                if (remember) {

                    localStorage.setItem(
                        "rememberLogin",
                        "true"
                    );

                }

                else {

                    localStorage.removeItem(
                        "rememberLogin"
                    );

                }



                // ===================================
                // SUCCESS MESSAGE
                // ===================================

                await alert(
                    "🎉 Login Successful!"
                );



                // ===================================
                // REDIRECT TO DASHBOARD
                // ===================================

                window.location.href =
                    "dashboard.html";


            }

            catch (error) {


                console.error(
                    "❌ Login Error:",
                    error
                );



                // ===================================
                // FIREBASE AUTH ERRORS
                // ===================================

                if (
                    error.code ===
                    "auth/invalid-credential"
                    ||
                    error.code ===
                    "auth/wrong-password"
                ) {

                    alert(
                        "❌ Email অথবা Password সঠিক নয়।"
                    );

                }



                else if (
                    error.code ===
                    "auth/user-not-found"
                ) {

                    alert(
                        "❌ এই Email দিয়ে কোনো Account পাওয়া যায়নি।"
                    );

                }



                else if (
                    error.code ===
                    "auth/invalid-email"
                ) {

                    alert(
                        "❌ Email Address সঠিক নয়।"
                    );

                }



                else if (
                    error.code ===
                    "auth/user-disabled"
                ) {

                    alert(
                        "❌ এই Account বর্তমানে Disabled করা হয়েছে।"
                    );

                }



                else if (
                    error.code ===
                    "auth/too-many-requests"
                ) {

                    alert(
                        "⚠️ অনেকবার Login চেষ্টা করা হয়েছে। কিছুক্ষণ পরে আবার চেষ্টা করুন।"
                    );

                }



                else if (
                    error.code ===
                    "auth/network-request-failed"
                ) {

                    alert(
                        "❌ Network connection সমস্যা হয়েছে। Internet connection check করে আবার চেষ্টা করুন।"
                    );

                }



                // ===================================
                // USER DOCUMENT ERROR
                // ===================================

                else if (
                    error.message ===
                    "USER_DOCUMENT_NOT_FOUND"
                ) {

                    alert(
                        "❌ আপনার Account তথ্য পাওয়া যায়নি। অনুগ্রহ করে Support-এর সাথে যোগাযোগ করুন।"
                    );

                }



                // ===================================
                // LOGIN USER ERROR
                // ===================================

                else if (
                    error.message ===
                    "LOGIN_USER_NOT_FOUND"
                ) {

                    alert(
                        "❌ Login Account পাওয়া যায়নি। আবার চেষ্টা করুন।"
                    );

                }



                // ===================================
                // FIRESTORE PERMISSION
                // ===================================

                else if (
                    error.code ===
                    "permission-denied"
                ) {

                    alert(
                        "❌ Account তথ্য যাচাই করা যাচ্ছে না। কিছুক্ষণ পরে আবার চেষ্টা করুন।"
                    );

                }



                // ===================================
                // UNKNOWN ERROR
                // ===================================

                else {

                    alert(
                        "❌ Login করতে সমস্যা হয়েছে। আবার চেষ্টা করুন।"
                    );

                }


            }


            finally {

                // ===================================
                // RESTORE BUTTON
                // ===================================

                loginBtn.disabled =
                    false;


                loginBtn.innerText =
                    oldButtonText;

            }

        }
    );

}



// =======================================
// FORGOT PASSWORD
// =======================================

if (forgotPassword) {

    forgotPassword.addEventListener(
        "click",
        async () => {


            const email =
                emailInput
                    ?.value
                    ?.trim()
                    ?.toLowerCase() || "";



            // ===================================
            // EMAIL REQUIRED
            // ===================================

            if (!email) {

                alert(
                    "📧 প্রথমে আপনার Email Address লিখুন।"
                );

                if (emailInput) {

                    emailInput.focus();

                }

                return;

            }



            // ===================================
            // SEND RESET EMAIL
            // ===================================

            try {


                forgotPassword.style.pointerEvents =
                    "none";


                await sendPasswordResetEmail(
                    auth,
                    email
                );


                alert(
                    "✅ Password Reset Email পাঠানো হয়েছে। আপনার Email Inbox এবং Spam/Junk folder check করুন।"
                );


            }


            catch (error) {


                console.error(
                    "❌ Password Reset Error:",
                    error
                );



                // ===================================
                // RESET EMAIL ERRORS
                // ===================================

                if (
                    error.code ===
                    "auth/invalid-email"
                ) {

                    alert(
                        "❌ Email Address সঠিক নয়।"
                    );

                }



                else if (
                    error.code ===
                    "auth/user-not-found"
                ) {

                    alert(
                        "❌ এই Email দিয়ে কোনো Account পাওয়া যায়নি।"
                    );

                }



                else if (
                    error.code ===
                    "auth/too-many-requests"
                ) {

                    alert(
                        "⚠️ অনেকবার Password Reset চেষ্টা করা হয়েছে। কিছুক্ষণ পরে আবার চেষ্টা করুন।"
                    );

                }



                else if (
                    error.code ===
                    "auth/network-request-failed"
                ) {

                    alert(
                        "❌ Network connection সমস্যা হয়েছে। আবার চেষ্টা করুন।"
                    );

                }



                else {

                    alert(
                        "❌ Password Reset Email পাঠানো যায়নি। আবার চেষ্টা করুন।"
                    );

                }

            }


            finally {

                forgotPassword.style.pointerEvents =
                    "";

            }

        }
    );

}