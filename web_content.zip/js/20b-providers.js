/* سرویس‌های مدل: Claude (Messages)، Gemini (generateContent) و OpenAI-سازگار (chat/completions). موتور برنامه همان شکل Anthropic را دارد؛ اینجا به شکل هر سرویس تبدیل و پاسخ به شکل Anthropic برگردانده می‌شود. کلید فقط در هدر درخواست است. */
(function () {
  'use strict';
  var App = (window.App = window.App || {});
  var TIMEOUT_MS = 100000;
  var LIST_MS = 15000;
  var CLAUDE_HOST = 'https://api.anthropic.com';
  var GEMINI_HOST = 'https://generativelanguage.googleapis.com';
  var ANTHROPIC_VERSION = '2023-06-01';
  var MODEL_RE = /^[A-Za-z0-9][A-Za-z0-9._:\/-]{1,120}$/;
  var MAX_LIST = 300;
  var seq = 0;
  // پیش‌تنظیم‌های OpenAI-سازگار: [کلید، نام، نشانی، مدل پیش‌فرض]؛ «سفارشی» نشانی را کاربر می‌دهد
  var PRESETS = [
    ['openai', 'OpenAI', 'https://api.openai.com/v1', 'gpt-4o-mini'],
    ['openrouter', 'OpenRouter', 'https://openrouter.ai/api/v1', 'openai/gpt-4o-mini'],
    ['deepseek', 'DeepSeek', 'https://api.deepseek.com/v1', 'deepseek-chat'],
    ['custom', 'سرویس سفارشی', '', '']
  ];
  // مدل‌های شناخته‌شده که در فهرست اول می‌آیند (Claude از App.MODELS می‌آید)
  var BEST = {
    gemini: ['gemini-2.5-flash', 'gemini-2.5-pro', 'gemini-2.0-flash'],
    openai: ['gpt-4o-mini', 'gpt-4o', 'gpt-4.1-mini', 'gpt-4.1', 'deepseek-chat', 'openai/gpt-4o-mini', 'openai/gpt-4o']
  };
  var MSG_TIME = 'پاسخ خیلی طول کشید. دوباره امتحان کن.';
  var MSG_PARSE = 'پاسخ مدل خوانده نشد. دوباره امتحان کن.';
  var MSG_BAD = 'درخواست نامعتبر بود. مدل یا تنظیمات این سرویس را بررسی کن.';
  var MSG_404 = 'مدل یا آدرس پیدا نشد (پاسخ ۴۰۴). مدل را از فهرست انتخاب کن یا آدرس سرویس را بررسی کن.';
  var MSG_413 = 'درخواست خیلی حجیم است (احتمالاً عکس‌ها). تعداد یا اندازه‌ی عکس‌ها را کم کن.';
  var MSG_429 = 'تعداد درخواست‌ها زیاد شده یا سهمیه‌ی حساب تمام شده است. چند دقیقه دیگر دوباره امتحان کن.';

  // ---- نام و پیام‌ها ----
  function svc(p) { return p.type === 'claude' ? 'Anthropic' : p.type === 'gemini' ? 'Gemini' : (p.name || 'سرویس'); }
  function fa(n) { return String(n).replace(/\d/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'.charAt(+d); }); }
  function authMsg(p) { return 'کلید ' + svc(p) + ' پذیرفته نشد. کلید را دوباره از سایت همین سرویس بگیر و ذخیره کن.'; }
  // پیام فارسی کوتاه برای کد HTTP؛ متن خام سرویس هرگز نشان داده نمی‌شود
  function apiErr(p, status, txt) {
    var data = null;
    try { data = JSON.parse(txt); } catch (e) { data = null; }
    var err = data && data.error;
    if (err && typeof err === 'object' && err.type === 'upstream_auth') return authMsg(p);
    if (status === 401 || status === 403) return authMsg(p);
    if (status === 400 && /API[ _-]?KEY/i.test(txt || '')) return authMsg(p);
    if (status === 400) return MSG_BAD;
    if (status === 404) return MSG_404;
    if (status === 413) return MSG_413;
    if (status === 429) return MSG_429;
    if (status >= 500) return 'سرویس ' + svc(p) + ' خطا داد. کمی بعد دوباره امتحان کن.';
    return 'پاسخ غیرمنتظره از ' + svc(p) + ' (کد ' + fa(status) + ').';
  }

  // ---- نشانی‌ها: بدون اسلش پایانی و بدون مسیر اضافه ----
  function clean(base) { return String(base || '').trim().replace(/\/+$/, ''); }
  function claudeRoot(base) { return clean(base).replace(/\/v1\/messages$/, '').replace(/\/v1$/, '') || CLAUDE_HOST; }
  function geminiRoot(base) { return clean(base).replace(/\/v1beta$/, '').replace(/\/v1$/, '') || GEMINI_HOST; }
  function openaiRoot(base) { return clean(base).replace(/\/chat\/completions$/, ''); }
  function presetOf(base) {
    var b = clean(base);
    var hit = PRESETS.filter(function (x) { return x[2] && x[2] === b; })[0];
    return hit ? hit[0] : 'custom';
  }
  // مدل پیش‌فرض هر نوع؛ برای OpenAI-سازگار بسته به پیش‌تنظیم
  function defaultModel(type, base) {
    if (type === 'claude') return (App.MODELS && App.MODELS[0]) || 'claude-sonnet-5-5';
    if (type === 'gemini') return BEST.gemini[0];
    var pr = PRESETS.filter(function (x) { return x[0] === presetOf(base); })[0];
    return pr ? pr[3] : '';
  }

  // ---- HTTP با مهلت زمانی؛ همیشه {status, txt} یا {error} ----
  function request(url, o) {
    var ctrl = typeof AbortController === 'function' ? new AbortController() : null;
    var tm = setTimeout(function () { if (ctrl) ctrl.abort(); }, o.ms);
    var init = { method: o.body == null ? 'GET' : 'POST', headers: o.headers, cache: 'no-store', credentials: 'omit', referrerPolicy: 'no-referrer' };
    if (ctrl) init.signal = ctrl.signal;
    if (o.body != null) init.body = o.body;
    return fetch(url, init).then(function (res) {
      return res.text().then(function (txt) { clearTimeout(tm); return { status: res.status, txt: txt }; });
    }).catch(function (err) {
      clearTimeout(tm);
      return { status: 0, error: err && err.name === 'AbortError' ? 'timeout' : 'network' };
    });
  }
  // نتیجه‌ی HTTP را به {ok, data} یا {ok:false, error} تبدیل می‌کند
  function finish(p, r, onOk) {
    if (r.error) {
      if (r.error === 'timeout') return { ok: false, error: MSG_TIME };
      return { ok: false, error: p.type === 'openai' ? 'اتصال برقرار نشد (ممکن است این سرویس از مرورگر مستقیم پشتیبانی نکند).' : 'اتصال به ' + svc(p) + ' برقرار نشد. اینترنت و آدرس سرویس را بررسی کن.' };
    }
    if (r.status < 200 || r.status > 299) return { ok: false, status: r.status, error: apiErr(p, r.status, r.txt) };
    var data = null;
    try { data = JSON.parse(r.txt); } catch (e) { data = null; }
    if (!data || typeof data !== 'object') return { ok: false, error: MSG_PARSE };
    return onOk(data);
  }

  // ---- کمک‌های شکل پیام ----
  function isObj(x) { return !!x && typeof x === 'object' && !Array.isArray(x); }
  function parseObj(x) {
    if (isObj(x)) return x;
    if (typeof x === 'string') {
      try { var o = JSON.parse(x); if (isObj(o)) return o; } catch (e) { /* ignore */ }
    }
    return {};
  }
  function blocksOf(content) {
    if (typeof content === 'string') return [{ type: 'text', text: content }];
    return Array.isArray(content) ? content : [];
  }
  function resultText(c) {
    if (typeof c === 'string') return c;
    if (Array.isArray(c)) return c.filter(function (b) { return b && b.type === 'text'; }).map(function (b) { return b.text || ''; }).join('\n');
    return JSON.stringify(c == null ? '' : c);
  }
  function withSig(block, part) { if (part.thoughtSignature) block.sig = part.thoughtSignature; return block; }

  // ---- Claude: بدنه و پاسخ بدون تغییر ----
  function callClaude(p, body) {
    var headers = { 'Content-Type': 'application/json', 'x-api-key': p.key, 'anthropic-version': ANTHROPIC_VERSION, 'anthropic-dangerous-direct-browser-access': 'true' };
    var payload = Object.assign({}, body, { model: p.model });
    return request(claudeRoot(p.base) + '/v1/messages', { headers: headers, body: JSON.stringify(payload), ms: TIMEOUT_MS }).then(function (r) {
      return finish(p, r, function (data) { return Array.isArray(data.content) ? { ok: true, data: data } : { ok: false, error: MSG_PARSE }; });
    });
  }

  // ---- Gemini ----
  // شکل ساده‌ی OpenAPI که Gemini می‌پذیرد: $schema و additionalProperties حذف؛ enum غیر رشته‌ای رشته؛ شیء بی‌ویژگی متن JSON
  function geminiSchema(s) {
    if (Array.isArray(s)) return s.map(geminiSchema);
    if (!s || typeof s !== 'object') return s;
    var o = {};
    Object.keys(s).forEach(function (k) {
      if (k === '$schema' || k === 'additionalProperties') return;
      o[k] = geminiSchema(s[k]);
    });
    if (o.enum && o.type !== 'string') { o.enum = o.enum.map(String); o.type = 'string'; }
    if (o.type === 'object' && !(o.properties && Object.keys(o.properties).length)) {
      return { type: 'string', description: String(o.description || '') + ' (متن JSON)' };
    }
    if (o.required) {
      o.required = o.required.filter(function (k) { return !!(o.properties && o.properties[k]); });
      if (!o.required.length) delete o.required;
    }
    return o;
  }
  function geminiTools(tools) {
    return [{ functionDeclarations: tools.map(function (t) {
      var d = { name: String(t.name), description: String(t.description || '') };
      var sch = t.input_schema;
      if (sch && sch.properties && Object.keys(sch.properties).length) d.parameters = geminiSchema(sch);
      return d;
    }) }];
  }
  function toGemini(body) {
    var names = {}, contents = [];
    (body.messages || []).forEach(function (m) {
      var parts = [];
      blocksOf(m.content).forEach(function (b) {
        if (!b) return;
        var part = null;
        if (b.type === 'text' && b.text) part = { text: String(b.text) };
        else if (b.type === 'image' && b.source) part = { inlineData: { mimeType: b.source.media_type || 'image/jpeg', data: b.source.data } };
        else if (b.type === 'tool_use') { names[b.id] = b.name; part = { functionCall: { name: String(b.name), args: isObj(b.input) ? b.input : {} } }; }
        else if (b.type === 'tool_result') part = { functionResponse: { name: names[b.tool_use_id] || 'tool', response: { result: resultText(b.content) } } };
        if (part) { if (b.sig) part.thoughtSignature = b.sig; parts.push(part); }
      });
      if (parts.length) contents.push({ role: m.role === 'assistant' ? 'model' : 'user', parts: parts });
    });
    var out = { contents: contents };
    if (body.system) out.systemInstruction = { parts: [{ text: String(body.system) }] };
    if (body.tools && body.tools.length) out.tools = geminiTools(body.tools);
    if (body.max_tokens) out.generationConfig = { maxOutputTokens: body.max_tokens };
    return out;
  }
  function callGemini(p, body) {
    var headers = { 'Content-Type': 'application/json', 'x-goog-api-key': p.key };
    var url = geminiRoot(p.base) + '/v1beta/models/' + encodeURIComponent(p.model) + ':generateContent';
    return request(url, { headers: headers, body: JSON.stringify(toGemini(body)), ms: TIMEOUT_MS }).then(function (r) {
      return finish(p, r, function (data) { return fromGemini(data, body.tools); });
    });
  }
  function fromGemini(data, tools) {
    var fb = data.promptFeedback;
    if (fb && fb.blockReason) return { ok: false, error: 'پیام توسط فیلتر ایمنی Gemini مسدود شد. متن را کمی تغییر بده.' };
    var c = Array.isArray(data.candidates) ? data.candidates[0] : null;
    if (!c) return { ok: false, error: 'Gemini پاسخی نداد. دوباره امتحان کن.' };
    var content = [];
    var parts = c.content && Array.isArray(c.content.parts) ? c.content.parts : [];
    parts.forEach(function (x) {
      if (!x || x.thought) return;
      if (x.functionCall && x.functionCall.name) {
        content.push(withSig({ type: 'tool_use', id: 'gem_' + (++seq) + '_' + x.functionCall.name, name: String(x.functionCall.name), input: isObj(x.functionCall.args) ? x.functionCall.args : {} }, x));
      } else if (typeof x.text === 'string' && x.text) {
        content.push(withSig({ type: 'text', text: x.text }, x));
      }
    });
    if (!content.length) return { ok: false, error: c.finishReason === 'SAFETY' ? 'پاسخ به‌خاطر فیلتر ایمنی Gemini کامل نشد.' : 'Gemini پاسخ خالی داد. سؤال را کوتاه‌تر یا روشن‌تر بپرس.' };
    var use = content.some(function (b) { return b.type === 'tool_use'; });
    if (use && tools) content = content.map(function (b) { return b.type === 'tool_use' ? coerceUse(b, tools) : b; });
    return { ok: true, data: { content: content, stop_reason: use ? 'tool_use' : 'end_turn' } };
  }

  // ---- OpenAI-سازگار ----
  function toOpenAI(body) {
    var out = [];
    if (body.system) out.push({ role: 'system', content: String(body.system) });
    (body.messages || []).forEach(function (m) {
      var blocks = blocksOf(m.content);
      if (m.role === 'assistant') {
        var text = blocks.filter(function (b) { return b && b.type === 'text' && b.text; }).map(function (b) { return b.text; }).join('\n');
        var calls = blocks.filter(function (b) { return b && b.type === 'tool_use'; }).map(function (b) {
          return { id: String(b.id), type: 'function', function: { name: String(b.name), arguments: JSON.stringify(isObj(b.input) ? b.input : {}) } };
        });
        if (!text && !calls.length) return;
        var msg = { role: 'assistant', content: text };
        if (calls.length) msg.tool_calls = calls;
        out.push(msg);
        return;
      }
      blocks.forEach(function (b) {
        if (b && b.type === 'tool_result') out.push({ role: 'tool', tool_call_id: String(b.tool_use_id), content: resultText(b.content) });
      });
      var parts = [];
      blocks.forEach(function (b) {
        if (!b) return;
        if (b.type === 'text' && b.text) parts.push({ type: 'text', text: String(b.text) });
        else if (b.type === 'image' && b.source) parts.push({ type: 'image_url', image_url: { url: 'data:' + (b.source.media_type || 'image/jpeg') + ';base64,' + b.source.data } });
      });
      if (!parts.length) return;
      var onlyText = parts.every(function (p) { return p.type === 'text'; });
      out.push({ role: 'user', content: onlyText ? parts.map(function (p) { return p.text; }).join('\n') : parts });
    });
    return out;
  }
  function toOpenAITools(tools) {
    return tools.map(function (t) {
      return { type: 'function', function: { name: String(t.name), description: String(t.description || ''), parameters: t.input_schema || { type: 'object', properties: {} } } };
    });
  }
  function callOpenAI(p, body, retry) {
    if (!p.base) return Promise.resolve({ ok: false, error: 'آدرس این سرویس تنظیم نشده است. آن را در ویرایش همین سرویس وارد کن.' });
    var payload = { model: p.model, messages: toOpenAI(body) };
    // برخی مدل‌های OpenAI به جای max_tokens، max_completion_tokens می‌خواهند
    payload[retry ? 'max_completion_tokens' : 'max_tokens'] = body.max_tokens;
    if (body.tools && body.tools.length) payload.tools = toOpenAITools(body.tools);
    var headers = { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + p.key };
    return request(openaiRoot(p.base) + '/chat/completions', { headers: headers, body: JSON.stringify(payload), ms: TIMEOUT_MS }).then(function (r) {
      if (!retry && r.status === 400 && /max_completion_tokens/.test(r.txt || '')) return callOpenAI(p, body, true);
      return finish(p, r, function (data) { return fromOpenAI(data, body.tools); });
    });
  }
  function fromOpenAI(data, tools) {
    var ch = Array.isArray(data.choices) ? data.choices[0] : null;
    var msg = ch && ch.message;
    if (!msg) return { ok: false, error: 'پاسخی از سرویس نیامد. دوباره امتحان کن.' };
    var content = [];
    var text = typeof msg.content === 'string' ? msg.content : (Array.isArray(msg.content) ? msg.content.map(function (x) { return (x && x.text) || ''; }).join('') : '');
    if (!text && typeof msg.refusal === 'string') text = msg.refusal;
    if (text) content.push({ type: 'text', text: text });
    (Array.isArray(msg.tool_calls) ? msg.tool_calls : []).forEach(function (tc) {
      var fn = tc && tc.function;
      if (!fn || !fn.name) return;
      content.push({ type: 'tool_use', id: String(tc.id || ('oai_' + (++seq))), name: String(fn.name), input: parseObj(fn.arguments) });
    });
    var use = content.some(function (b) { return b.type === 'tool_use'; });
    if (use && tools) content = content.map(function (b) { return b.type === 'tool_use' ? coerceUse(b, tools) : b; });
    return { ok: true, data: { content: content, stop_reason: use ? 'tool_use' : 'end_turn' } };
  }

  // ---- تبدیل نوع ورودی‌ها به شکل اصلی (برای Gemini و OpenAI که شیء بی‌ویژگی یا عدد را رشته می‌کنند) ----
  function coerce(v, s) {
    if (!s || typeof s !== 'object') return v;
    if (s.type === 'object') {
      if (typeof v === 'string') v = parseObj(v);
      if (isObj(v) && s.properties) {
        var o = {};
        Object.keys(v).forEach(function (k) { o[k] = coerce(v[k], s.properties[k]); });
        return o;
      }
      return v;
    }
    if (s.type === 'array' && Array.isArray(v) && s.items) return v.map(function (x) { return coerce(x, s.items); });
    if ((s.type === 'integer' || s.type === 'number') && typeof v === 'string' && v.trim() !== '' && isFinite(+v)) return +v;
    if (s.type === 'boolean' && (v === 'true' || v === 'false')) return v === 'true';
    return v;
  }
  function coerceUse(b, tools) {
    var t = tools.filter(function (x) { return x && x.name === b.name; })[0];
    if (t && t.input_schema) b.input = coerce(b.input, t.input_schema);
    return b;
  }

  // ---- فهرست مدل‌ها ----
  function parseModels(type, data) {
    var raw = type === 'gemini' ? (Array.isArray(data.models) ? data.models : []) : (Array.isArray(data.data) ? data.data : []);
    var ids = raw.filter(function (x) {
      if (!x) return false;
      return type !== 'gemini' || (Array.isArray(x.supportedGenerationMethods) && x.supportedGenerationMethods.indexOf('generateContent') >= 0);
    }).map(function (x) {
      var id = typeof x === 'string' ? x : (type === 'gemini' ? String(x.name || '') : String(x.id || ''));
      return id.replace(/^models\//, '');
    }).filter(function (id) { return MODEL_RE.test(id); });
    ids = ids.filter(function (x, i, a) { return a.indexOf(x) === i; });
    var best = type === 'claude' ? (App.MODELS || []) : (BEST[type] || []);
    var first = best.filter(function (m) { return ids.indexOf(m) >= 0; });
    var rest = ids.filter(function (m) { return best.indexOf(m) < 0; }).sort();
    return first.concat(rest).slice(0, MAX_LIST);
  }
  function models(p) {
    var key = String(p.key || '').trim();
    if (!key) return Promise.resolve({ ok: false, error: 'اول کلید را وارد کن.' });
    var url, headers;
    if (p.type === 'gemini') {
      url = geminiRoot(p.base) + '/v1beta/models?pageSize=200';
      headers = { 'x-goog-api-key': key };
    } else if (p.type === 'openai') {
      if (!p.base) return Promise.resolve({ ok: false, error: 'آدرس سرویس را وارد کن.' });
      url = openaiRoot(p.base) + '/models';
      headers = { 'Authorization': 'Bearer ' + key };
    } else {
      url = claudeRoot(p.base) + '/v1/models?limit=100';
      headers = { 'x-api-key': key, 'anthropic-version': ANTHROPIC_VERSION, 'anthropic-dangerous-direct-browser-access': 'true' };
    }
    return request(url, { headers: headers, ms: LIST_MS }).then(function (r) {
      return finish(p, r, function (data) { return { ok: true, models: parseModels(p.type, data) }; });
    });
  }

  // ورودی یکسان برای همه‌ی سرویس‌ها: p = {type, name, base, key, model}، body به شکل Anthropic
  function call(p, body) {
    if (p.type === 'gemini') return callGemini(p, body);
    if (p.type === 'openai') return callOpenAI(p, body, false);
    return callClaude(p, body);
  }

  App.providers = {
    presets: PRESETS.map(function (x) { return { key: x[0], name: x[1], base: x[2], model: x[3] }; }),
    presetOf: presetOf,
    defaultModel: defaultModel,
    call: call,
    models: models,
    parseModels: parseModels,
    claudeRoot: claudeRoot,
    geminiRoot: geminiRoot,
    openaiRoot: openaiRoot,
    geminiSchema: geminiSchema,
    toGemini: toGemini,
    fromGemini: fromGemini,
    toOpenAI: toOpenAI,
    fromOpenAI: fromOpenAI
  };
})();
