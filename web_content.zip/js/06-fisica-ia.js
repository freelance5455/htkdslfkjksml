/* Movimento, IA e disparos */
/* ======================================================================
   Churchill Crocodile (Reino Unido, 1944): Churchill VII lanca-chamas com reboque blindado de combustivel
   PzH 2000 (Alemanha): obuseiro autopropulsado de 155 mm com cano L/52, pa de ancoragem e carregador automatico
   ====================================================================== */
const crT=camT(['#f4f4e8','#cfd2b4','#a7ab8a']),crW=tw(.34),crS=tw(.5,1),crI=tw(.55),crWG=mkWheel(.62,.42,14,8),crN=numTx('CROC'),
  alStar=canvasTex(64,64,x=>{x.strokeStyle='#e9e6d8';x.lineWidth=4;x.beginPath();x.arc(32,32,29,0,7);x.stroke();x.fillStyle='#e9e6d8';x.beginPath();for(let k=0;k<10;k++){const a=-Math.PI/2+k*Math.PI/5,r=k%2?11:24;x.lineTo(32+Math.cos(a)*r,32+Math.sin(a)*r)}x.closePath();x.fill()}),
  crFlG=new THREE.IcosahedronGeometry(.5,0),FLR=36;
function makeCrocodile(color,fc){
  const{dark,lamp,brkM,flagM,flashM,cm,hm,sk,gl}=mm(fc),mat=mat0(color||0x5f6740,crT),g=new THREE.Group(),wheels=[],GX=1.45,
    DK=0x2b2d28,MT=0x4a4b42,RB=0x1b1b1a,GL=0x1d2f3a,CB=0x56503f,TN=0x6b5d3c,
    pilotM=new THREE.MeshBasicMaterial({color:0xffc24a}),gaugeM=new THREE.MeshBasicMaterial({color:0xe9e6d8}),needleM=new THREE.MeshBasicMaterial({color:0xd6232c});
  g.rotation.order='YXZ';
  /* esteiras que contornam o casco todo, com ponta alta na frente, e 11 rodas pequenas de apoio por lado */
  const trk=trackLoop([[-3.3,.1],[3,.1],[3.9,.7],[3.9,1.25],[3.5,1.55],[-3,1.55],[-3.9,1],[-3.9,.4]],96,.74,[-GX,GX]);g.add(trk);
  [[0,-GX],[1,GX]].forEach(([s,sx])=>{
    wl(g,crS,sx,.7,-3.4,.5,s,wheels);wl(g,crI,sx,.82,3.3,.55,s,wheels);
    for(let i=0;i<11;i++)wl(g,crW,sx,.4,-2.75+i*.55,.34,s,wheels).userData.b=1;
    for(const z of[-2.3,-.8,.7,2.2])wl(g,gRL,sx,1.4,z,.16,s,wheels)});
  const hull=new THREE.Group(),H=mb();
  /* casco alto e comprido, convés largo, proa com placa vertical e glacis inclinado */
  H.b(2.3,.8,7.2,'M',0,.95,-.1);H.b(2.1,.22,7,DK,0,.5,-.1);H.b(2.74,.1,6.5,'M',0,1.4,-.25);
  H.g(facet([[-1.15,.55,3.65],[1.15,.55,3.65],[1.15,1.2,3.65],[-1.15,1.2,3.65],[-1.15,1.62,2.6],[1.15,1.62,2.6],[-1.15,.55,2.6],[1.15,.55,2.6]],[[0,1,2,3],[3,2,5,4],[0,1,7,6],[0,3,4,6],[1,2,5,7],[4,5,7,6]]),'M',0,0,0);
  H.b(.62,.1,.1,GL,-.6,1.02,3.69);
  /* posto do motorista a esquerda e suporte do lanca-chamas a direita */
  H.b(.9,.4,.8,'M',-.6,1.7,2.95);H.c(.3,.3,.06,MT,-.6,1.92,2.95,'y');for(let k=0;k<3;k++)H.b(.16,.08,.05,GL,-.6+(k-1)*.24,1.78,3.36);
  H.b(.6,.6,.3,'M',.65,1.0,3.62);H.c(.2,.2,.08,MT,.65,1.0,3.8,'z');
  /* deck do motor com venezianas, placa traseira, dois escapamentos e olhal de reboque */
  H.b(1.9,.12,2.4,DK,0,1.47,-2.3);for(let k=0;k<8;k++)H.b(1.8,.03,.08,MT,0,1.55,-1.3-k*.27);H.b(.05,.03,2.1,MT,0,1.56,-2.2);
  H.b(2.34,.9,.1,'M',0,1.0,-3.72);
  for(const s of[-1,1]){H.c(.1,.1,.8,DK,s*.85,1.2,-3.95,'z');H.c(.14,.11,.14,MT,s*.85,1.2,-4.38,'z')}
  H.c(.09,.09,.5,MT,0,.9,-3.95,'z');H.b(.3,.18,.14,MT,0,.78,-4.2);
  for(const s of[-1,1]){
    /* placa lateral alta, porta de escape em relevo com escotilha e venezianas, caixa de equipamento e cabo de reboque */
    H.b(.16,.95,7,'M',s*1.2,1.02,-.1);
    H.b(.08,.8,1.2,'M',s*1.3,1.02,-.4);H.c(.12,.12,.05,MT,s*1.35,1.2,-.4,'x');
    for(let k=0;k<3;k++)H.b(.05,.06,.85,MT,s*1.35,.8+k*.09,-.4);
    H.b(.06,.06,.3,MT,s*1.36,1.02,.05);
    H.b(.5,.35,1.1,'M',s*1.47,1.78,-1.7);H.b(.52,.05,1.14,MT,s*1.47,1.97,-1.7);
    H.c(.05,.05,3.2,CB,s*1.7,1.62,.3,'z');
    H.b(.28,.4,.14,TN,s*1.55,1.7,-3.0);H.b(.28,.4,.14,TN,s*1.55,1.7,-3.25);
    H.b(1,.06,1.8,'M',s*1.6,1.88,3,.28);
    hull.add(bx(.22,.18,.1,lamp,s*.95,1.72,3.2),bx(.3,.2,.08,brkM,s*.85,1.1,-3.78));
  }
  H.out(hull,mat);g.add(hull);
  for(const s of[-1,1]){stk(hull,alStar,s*1.38,1.15,.85,s,.6,.6);stk(hull,crN,s*1.38,.8,1.9,s,.6,.3)}
  const ant=mkAnt(hull,-1.55,1.7,-2.6,flagM),dl=mkLid(hull,mat,-.6,1.95,2.95,.27),drv=mkCrew(hull,cm,hm,sk,-.6,1.55,2.95);
  /* lanca-chamas da proa: bico articulado que gira sozinho, chama piloto e jato de fogo feito de esferas que sobem e escurecem */
  const fjp=new THREE.Group(),FP=mb();fjp.position.set(.65,1,3.82);
  FP.c(.1,.1,1,DK,0,0,.5,'z');FP.c(.17,.12,.2,MT,0,0,1.02,'z');FP.c(.2,.2,.14,DK,0,0,.08,'z');FP.c(.13,.13,.06,MT,0,0,.55,'z');
  FP.out(fjp,mat);fjp.add(new THREE.Mesh(new THREE.SphereGeometry(.22,10,8),dark));
  const pilot=new THREE.Mesh(new THREE.SphereGeometry(.06,6,5),pilotM);pilot.position.set(0,.04,1.16);fjp.add(pilot);
  const jet=new THREE.Group(),jp=[];jet.position.set(0,0,1.1);fjp.add(jet);
  for(let i=0;i<16;i++){const m=new THREE.Mesh(crFlG,new THREE.MeshBasicMaterial({color:0xffc24a,transparent:true,opacity:0,depthWrite:false}));m.visible=false;jet.add(m);jp.push(m)}
  jet.visible=false;hull.add(fjp);
  /* torre soldada com cesto traseiro, lancadores de fumaca e cupula do comandante a esquerda */
  const tg=new THREE.Group(),T=mb();tg.position.set(0,1.6,.3);
  T.c(1.15,1.22,.74,'M',0,.37,0,'y');T.c(1,1.12,.3,'M',0,.89,0,'y');
  T.b(2,.78,1.1,'M',0,.42,-1.25);T.b(1.8,.08,1,'M',0,.84,-1.25);T.b(.9,.06,.3,DK,0,.88,-1.7);
  for(const s of[-1,1]){for(let k=0;k<3;k++)T.c(.05,.05,.3,DK,s*1.02,.85,.3+k*.12,'y',0,0,-s*.5);T.b(.2,.16,.2,'M',s*.3,1.12,.4);T.b(.14,.14,.05,GL,s*.3,1.14,.52)}
  T.c(.3,.32,.06,MT,.6,1.05,-.45,'y');
  T.out(tg,mat);
  const st1=new THREE.Mesh(new THREE.PlaneGeometry(.7,.7),new THREE.MeshBasicMaterial({map:alStar,transparent:true}));st1.rotation.x=-Math.PI/2;st1.position.set(0,.895,-1.25);tg.add(st1);
  const cup=new THREE.Group(),C=mb();cup.position.set(-.6,1.04,-.3);
  C.c(.36,.4,.3,'M',0,.15,0,'y');C.c(.38,.38,.05,MT,0,.3,0,'y');for(let k=0;k<8;k++){const a=k/8*6.2832;C.b(.1,.07,.04,GL,Math.sin(a)*.4,.2,Math.cos(a)*.4,0,a)}
  C.out(cup,mat);tg.add(cup);
  const cl=mkLid(cup,mat,0,.33,0,.26),ll=mkLid(tg,mat,.6,1.08,-.45,.26),crew=mkCrew(cup,cm,hm,sk,0,-.1,0),crew2=mkCrew(tg,cm,hm,sk,.6,.55,-.45),cmg=mkMG(tg,-.6,1.5,.25);
  /* canhao de 75 mm: mascara larga, Besa coaxial e cano com anel no focinho */
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb(),K=mb();bp.position.set(0,.55,1.2);
  B.b(1.05,.74,.5,'M',0,0,.2);B.c(.42,.42,.5,'M',0,0,.3,'z');B.b(.2,.16,.2,DK,.55,.1,.35);B.c(.035,.035,.8,DK,.3,-.1,.75,'z');
  B.out(bp,mat);
  K.c(.14,.14,.9,DK,0,0,.9,'z');K.c(.085,.085,3.4,DK,0,0,2.8,'z');K.c(.11,.11,.14,MT,0,0,4.58,'z');for(const z of[1.4,1.9])K.c(.15,.15,.06,MT,0,0,z,'z');
  K.out(bar,mat);
  const fl=mkFl(bar,4.7,.4,flashM);bp.add(bar);tg.add(bp);hull.add(tg);
  /* reboque blindado de combustivel: barra em A, mangueira blindada, tanque inclinado, duas rodas grandes e marcadores */
  const trp=new THREE.Group(),R=mb(),twh=[],gn=[];trp.position.set(0,.8,-3.92);
  for(const s of[-1,1]){R.b(.13,.14,1.46,DK,s*.275,-.05,-.675,0,-s*.387);R.b(.62,.06,1.6,'M',s*1.31,.5,-3.1);R.b(.05,.2,1.6,'M',s*1.62,.4,-3.1)}
  R.c(.08,.08,2.7,DK,0,-.18,-3.1,'x');
  R.g(facet([[-1.05,-.3,-1.35],[1.05,-.3,-1.35],[1.05,.2,-1.35],[-1.05,.2,-1.35],[-1.05,.85,-2.2],[1.05,.85,-2.2],[-1.05,-.3,-2.2],[1.05,-.3,-2.2]],[[0,1,2,3],[3,2,5,4],[0,1,7,6],[0,3,4,6],[1,2,5,7],[4,5,7,6]]),'M',0,0,0);
  R.b(2.1,1.15,1.7,'M',0,.275,-3.05);
  R.g(facet([[-1.05,-.3,-3.9],[1.05,-.3,-3.9],[1.05,.85,-3.9],[-1.05,.85,-3.9],[-1.05,.45,-4.55],[1.05,.45,-4.55],[-1.05,-.3,-4.55],[1.05,-.3,-4.55]],[[0,1,2,3],[3,2,5,4],[0,1,7,6],[0,3,4,6],[1,2,5,7],[4,5,7,6]]),'M',0,0,0);
  for(const z of[-2.55,-3.05,-3.55])R.b(2.14,.04,.08,MT,0,.865,z);
  R.c(.3,.3,.1,MT,.5,.9,-3.1,'y');R.c(.2,.2,.08,DK,.5,.96,-3.1,'y');R.b(.5,.05,.5,MT,-.5,.88,-3.4);
  R.c(.09,.09,.95,DK,0,.1,-.85,'z');R.c(.13,.13,.1,MT,0,.1,-1.3,'z');R.c(.13,.13,.1,MT,0,.1,-.25,'z');R.c(.16,.16,.16,MT,0,.1,0,'y');
  for(const s of[-1,1]){
    const w=new THREE.Mesh(crWG,vcM);w.position.set(s*1.31,-.18,-3.1);trp.add(w);twh.push(w);
    const gg=new THREE.Group();gg.position.set(s*1.08,.4,-2.4);gg.add(new THREE.Mesh(new THREE.CylinderGeometry(.17,.17,.04,14).rotateZ(Math.PI/2),gaugeM));
    const nd=new THREE.Group();nd.add(bx(.02,.14,.02,needleM,s*.03,.07,0));gg.add(nd);gn.push(nd);trp.add(gg);
    trp.add(bx(.2,.12,.06,brkM,s*.8,.15,-4.57));
  }
  R.out(trp,mat);g.add(trp);
  const ct=fin(base({g,tg,bp,bar,hull,ant,cup,fjp,jet,jp,pilot,trp,twh,gn,dl,drv,crew,crew2,lid:[cl,ll],cmg,fl,brkM,wheels,trk,mat,dark,cro:true,cannon:true,spd:1,trn:.8,L:4.3,W:1.95,mz:4.8,fk:1.1,rld:3,wd:1.6,armor:.55,hp:160,TY:1.6}));
  jp.forEach(m=>m.castShadow=false);pilot.castShadow=false;return ct;
}
function animCro(t,dt){
  const now=performance.now()/1000;t.clk+=dt;
  if(t.dead){
    t.jet.visible=false;t.pilot.visible=false;t.drv.visible=false;t.crew2.visible=false;
    t.dl.rotation.x=-1.5;t.lid[0].rotation.x=-1.5;t.lid[1].rotation.x=-1.4;t.trp.rotation.x=.1;
    if(t.ck===undefined)t.ck=7;
    if(t.ck>0){t.ck-=dt;t.ckt=(t.ckt||0)-dt;
      if(t.ckt<=0){t.ckt=.07+Math.random()*.08;t.trp.localToWorld(v2.set((Math.random()-.5)*1.8,.5+Math.random()*.8,-2.4-Math.random()*1.8)); /* o reboque de combustivel pega fogo e explode */
        puff(v2,Math.random()<.5?0xff7a1c:0xffd36b,1.8,5,.9,9);puff(v2,0x1f1e1c,2.4,3,2.2,5);if(Math.random()<.22){puff(v2,0xff6a20,3.4,9,.5,10);sfx(.3*near(v2),.2)}}}
    return blowOff(t,dt,t.TY);
  }
  if(t.fuel===undefined){t.fuel=1;t.fa=0;t.bl=[];t.fo=null;t.pHd=t.hd}
  const th=clamp(Math.abs(t.v)/10,0,1),d=trkStep(t,dt,1.45),ac=clamp((t.v-t.pv)/Math.max(dt,.001),-9,9);
  for(const w of t.wheels){w.rotation.x+=d[w.userData.s]/w.userData.r;if(w.userData.b)w.position.y=.4+Math.sin(now*9+w.position.z*2.3)*.02*th}
  t.hull.position.y=Math.sin(now*34+t.x)*(.008+.014*th)-t.recoil*.03;t.hull.rotation.x=-ac*.0035-t.recoil*.02;t.hull.rotation.z=-(t.st||0)*th*.025;
  t.ant.rotation.x=-t.v*.012+Math.sin(now*3+t.z)*.03;
  /* reboque: balanca para o lado de fora nas curvas, as rodas giram e os marcadores mostram o combustivel */
  const rate=angDiff(t.hd,t.pHd)/Math.max(dt,.001);t.pHd=t.hd;
  t.trp.rotation.y+=(-clamp(rate*.3,-.45,.45)*clamp(Math.abs(t.v)/4,0,1)-t.trp.rotation.y)*Math.min(1,dt*3);
  t.trp.rotation.x=Math.sin(now*8+t.z)*.012*th-ac*.004;t.trp.position.y=.8+Math.sin(now*21+t.x)*.012*th;
  for(const w of t.twh)w.rotation.x+=t.v*dt/.62;
  for(const n of t.gn)n.rotation.x+=((-1.1+2.2*t.fuel)-n.rotation.x)*Math.min(1,dt*4);
  /* lanca-chamas: acha o inimigo mais proximo na frente do casco, gira o bico e jorra fogo; o inimigo continua queimando uns segundos */
  t.fs=(t.fs||0)-dt;
  if(t.fs<=0){t.fs=.2;let best=FLR,bo=null;for(const o of tanks)if(!o.dead&&!o.air&&!o.corv&&hostile(t,o)){const dx=o.x-t.x,dz=o.z-t.z,dd=Math.hypot(dx,dz);if(dd<best&&Math.abs(angDiff(Math.atan2(dx,dz),t.hd))<.95){best=dd;bo=o}}t.fo=bo}
  let o=t.fo;if(o&&(o.dead||o.air))o=null;
  let tgY=0,tgP=.05,dist=FLR,on=false;
  if(o){const dx=o.x-t.x,dz=o.z-t.z;dist=Math.hypot(dx,dz);tgY=clamp(angDiff(Math.atan2(dx,dz),t.hd),-.85,.85);tgP=Math.atan2((o.y||0)+1.2-(t.y||0)-1.05,Math.max(dist,4))+.03;on=t.fuel>.03}
  else if(inGarage)tgY=Math.sin(now*1.2)*.32;
  const kk=Math.min(1,dt*5);t.fjp.rotation.y+=(tgY-t.fjp.rotation.y)*kk;t.fjp.rotation.x+=(-tgP-t.fjp.rotation.x)*kk;
  const al=Math.abs(tgY-t.fjp.rotation.y)<.18,demo=!!inGarage&&(now%8)<2.6,spray=(on&&dist<FLR+2&&al)||demo;
  t.fa+=((spray?1:0)-t.fa)*Math.min(1,dt*(spray?7:5));
  if(spray&&!demo)t.fuel=Math.max(0,t.fuel-dt/16);else t.fuel=Math.min(1,t.fuel+dt/40);
  if(spray&&o&&!inGarage){
    t.fdT=(t.fdT||0)-dt;
    if(t.fdT<=0){t.fdT=.2;damage(o,4.5,t);const q=t.bl.find(e=>e.o===o);if(q)q.t=4;else t.bl.push({o,t:4,k:0})}
    t.sn=(t.sn||0)-dt;if(t.sn<=0){t.sn=.18;sfx(.16*near(t),.22)}
  }
  for(let i=t.bl.length-1;i>=0;i--){
    const q=t.bl[i];q.t-=dt;if(q.o.dead||q.t<=0){t.bl.splice(i,1);continue}
    q.k-=dt;if(q.k<=0){q.k=.3;damage(q.o,.9,t);v2.set(q.o.x+(Math.random()-.5)*1.6,q.o.y+1.5+Math.random()*.8,q.o.z+(Math.random()-.5)*1.6);puff(v2,Math.random()<.5?0xff7a1c:0x1f1e1c,1.1,1.5,1.1,2.5)}
  }
  const fa=t.fa,jl=(Math.min(FLR,dist)+2)*Math.min(1,fa*1.4);
  t.jet.visible=fa>.02;t.pilot.visible=fa<.3;t.pilot.scale.set(1,.7+Math.random()*.9,1);
  if(fa>.02){
    for(let i=0;i<16;i++){
      const m=t.jp[i],u=(now*2.1+i/16)%1,w=1-Math.max(0,u-.7)*2.2;
      m.visible=true;m.position.set(Math.sin(now*17+i*2.1)*.12*u*3,-u*u*.9+Math.cos(now*13+i*1.7)*.1*u*3,u*jl);
      m.scale.setScalar(.22+u*1.5);m.material.opacity=Math.pow(1-u,.8)*.95*fa;
      m.material.color.setRGB(w,Math.max(.05,(u<.5?1-u*1.1:.45-(u-.5)*.6)*w),u<.3?.7-u*2.2:.05);
    }
    t.fx=(t.fx||0)-dt;
    if(t.fx<=0){t.fx=.07;t.jet.localToWorld(v2.set(0,-.4,jl));puff(v2,0xff8a1c,1.4,3,.5,2);puff(v2,0x2b2a28,1.6,2,1.1,3)}
  }
  tankFx(t,dt,now,th,{ex:[[.85,1.2,-4.38],[-.85,1.2,-4.38]],dk:[[1.5,.2,-3.3],[-1.5,.2,-3.3],[1.5,.2,3],[-1.5,.2,3]],mz:4.8,rr:1.6,rc:.55});
  if(inGarage&&(now%9)<.05&&t.clk-t.lf>2){t.recoil=1;t.fT=.09;t.ev=.5;t.lf=t.clk}
  t.dl.rotation.x=-t.open*1.4;t.drv.visible=t.open>.4;t.drv.position.y=t.drv.userData.by+Math.min(1,t.open)*.5;t.drv.rotation.y=Math.sin(now*.7+t.z)*.5;
  t.crew2.visible=t.open>.6;t.crew2.position.y=t.crew2.userData.by+(t.open-.3)*.45;t.crew2.rotation.y=Math.sin(now*.9+t.x)*.7;
  t.cup.rotation.y=t.mgt?t.cup.rotation.y:Math.sin(now*.7+t.x)*1.4;
  mgScan(t,dt,50);mgAim(t,dt,t.cmg,t.yaw,.7,[0,.1,1.45],now);smokeQ(t,dt,1.05,.85,.3);
}
const pzT=camT(['#f4f4e8','#cfd1b6','#9fa385']),pzW=tw(.4),pzS=tw(.5,1),pzI=tw(.45),pzN=numTx('PzH');
function makePzH(color,fc){
  const{dark,lamp,brkM,flagM,flashM,cm,hm,sk,gl}=mm(fc),mat=mat0(color||0x56603f,pzT),g=new THREE.Group(),wheels=[],GX=1.5,
    DK=0x2b2d28,MT=0x4a4b42,RB=0x1b1b1a,GL=0x1d2f3a,CB=0x56503f,
    glow=new THREE.MeshBasicMaterial({color:0xff7a20}),bcM=new THREE.MeshBasicMaterial({color:0x2a1a05});
  g.rotation.order='YXZ';
  /* roda motriz na frente (motor a frente), roda guia atras, 7 rodas de apoio e 3 roletes por lado */
  const trk=trackLoop([[-3.1,.1],[2.9,.1],[3.55,.5],[3.6,1],[3.2,1.28],[-2.9,1.2],[-3.6,.85],[-3.5,.3]],90,.66,[-GX,GX]);g.add(trk);
  [[0,-GX],[1,GX]].forEach(([s,sx])=>{
    wl(g,pzS,sx,.86,3.2,.5,s,wheels);wl(g,pzI,sx,.55,-3.2,.45,s,wheels);
    for(let i=0;i<7;i++)wl(g,pzW,sx,.45,-2.35+i*.78,.4,s,wheels).userData.b=1;
    for(const z of[-1.6,0,1.6])wl(g,gRL,sx,1.12,z,.16,s,wheels)});
  const hull=new THREE.Group(),H=mb();
  H.b(2.5,.64,6.8,'M',0,.86,-.1);H.b(2.2,.12,6.8,DK,0,.5,-.1);H.b(3.5,.1,6.5,'M',0,1.3,-.25);
  H.g(facet([[-1.7,.5,3.75],[1.7,.5,3.75],[1.7,1.05,3.75],[-1.7,1.05,3.75],[-1.7,1.35,2.6],[1.7,1.35,2.6],[-1.7,.5,2.6],[1.7,.5,2.6]],[[0,1,2,3],[3,2,5,4],[0,1,7,6],[0,3,4,6],[1,2,5,7],[4,5,7,6]]),'M',0,0,0);
  /* posto do motorista a esquerda e capo do motor a direita com grade, brilho e ventoinha */
  H.b(.95,.34,.95,'M',-1,1.52,2.85);H.c(.3,.32,.06,MT,-1,1.71,2.85,'y');for(let k=0;k<3;k++)H.b(.2,.09,.05,GL,-1+(k-1)*.28,1.55,3.34);
  H.b(1.5,.2,1.9,'M',.95,1.46,2.6);for(let k=0;k<7;k++)H.b(1.38,.03,.07,MT,.95,1.57,1.85+k*.25);H.b(.05,.03,1.7,MT,.95,1.58,2.6);
  hull.add(bx(1.4,.02,1.7,glow,.95,1.565,2.6));
  H.b(3,.55,.3,'M',0,.95,-3.55);
  for(const s of[-1,1]){
    for(let k=0;k<4;k++)H.b(.07,.55,1.32,'M',s*1.87,1.02,2.2-k*1.4);
    H.b(.05,.4,.9,RB,s*1.87,.45,3.45);
    H.c(.05,.05,2.8,CB,s*1.45,1.4,.9,'z');H.b(.5,.28,1,'M',s*1.35,1.5,-2.4);H.b(.52,.04,1.04,MT,s*1.35,1.65,-2.4);
    H.b(.3,.12,.5,DK,s*1.4,1.38,-3.3);
    hull.add(bx(.22,.18,.1,lamp,s*1.55,1.42,3.7),bx(.3,.2,.08,brkM,s*1.2,1,-3.72));
  }
  H.out(hull,mat);g.add(hull);
  for(const s of[-1,1]){stk(hull,pzN,s*1.92,1.02,-.6,s,.55,.28);stk(hull,crossT,s*1.92,1.02,.9,s,.5,.5)}
  const fan=mkFan(hull,.95,1.595,2.6,4,.32),dl=mkLid(hull,mat,-1,1.74,2.85,.27),drv=mkCrew(hull,cm,hm,sk,-1,1.35,2.85);
  /* pa de ancoragem traseira: fica dobrada sobre o convés e desce quando o obuseiro para */
  const spade=new THREE.Group(),S=mb();spade.position.set(0,1.15,-3.7);
  S.b(3.1,1.1,.1,'M',0,-.55,0);for(const x of[-1.1,-.37,.37,1.1])S.b(.12,1,.16,DK,x,-.55,.1);S.b(3.1,.16,.28,DK,0,-1.1,.08,.5);
  for(const s of[-1,1]){S.b(.14,.14,.7,'M',s*1.35,-.1,.3);S.c(.06,.06,1,MT,s*1.45,-.35,.45,'z')}
  S.out(spade,mat);hull.add(spade);
  /* torre grande e larga com a traseira reta: recesso escuro onde abre a escotilha de municao, caixas laterais, lancadores de fumaca */
  const tg=new THREE.Group(),T=mb();tg.position.set(0,1.35,-.55);
  T.g(facet([[-1.5,0,-2],[1.5,0,-2],[1.5,0,1.8],[-1.5,0,1.8],[-1.35,1.5,-2],[1.35,1.5,-2],[1.35,1.5,1.2],[-1.35,1.5,1.2]],[[0,1,2,3],[4,5,6,7],[0,1,5,4],[3,2,6,7],[0,3,7,4],[1,2,6,5]]),'M',0,0,0);
  T.b(2.6,.06,3.2,'M',0,1.53,-.4);T.b(2.9,.18,.12,'M',0,.9,-2.04);T.b(1.7,1,.06,DK,0,.85,-2.02);T.b(1.4,.05,.5,DK,0,.35,-2.3);
  for(const s of[-1,1]){T.b(.3,.45,1,'M',s*1.6,.6,-1.2);T.b(.32,.04,1.04,MT,s*1.6,.84,-1.2);for(let k=0;k<4;k++)T.c(.06,.06,.42,DK,s*1.46,1,.8+k*.14,'y',0,0,-s*.5)}
  T.b(.42,.32,.5,'M',.8,1.7,.35);T.b(.34,.2,.04,GL,.8,1.72,.62);T.b(.5,.08,.3,DK,.8,1.88,.3);T.c(.3,.32,.08,MT,.9,1.55,-1,'y');
  T.out(tg,mat);
  const cup=new THREE.Group(),C=mb();cup.position.set(-.85,1.53,-1.1);
  C.c(.4,.44,.36,'M',0,.18,0,'y');C.c(.42,.42,.05,MT,0,.36,0,'y');for(let k=0;k<8;k++){const a=k/8*6.2832;C.b(.1,.07,.04,GL,Math.sin(a)*.44,.24,Math.cos(a)*.44,0,a)}
  C.out(cup,mat);tg.add(cup);
  const cl=mkLid(cup,mat,0,.4,0,.28),ll=mkLid(tg,mat,.9,1.57,-1,.27),crew=mkCrew(cup,cm,hm,sk,0,-.1,0),crew2=mkCrew(tg,cm,hm,sk,.9,1.1,-1),cmg=mkMG(tg,-.85,2.05,-.95);
  /* escotilha traseira de municao, bandeja com projetil que desliza e luz giratoria de rajada */
  const rh=new THREE.Group(),RH=mb();rh.position.set(0,.35,-2.1);
  RH.b(1.7,1,.07,'M',0,.5,0);RH.b(1.5,.06,.1,MT,0,.9,0);RH.b(.08,.8,.1,MT,0,.5,-.07);RH.out(rh,mat);tg.add(rh);
  const shl=new THREE.Group();shl.position.set(0,.8,-2.3);shl.visible=false;
  shl.add(new THREE.Mesh(new THREE.CylinderGeometry(.09,.09,.7,8).rotateX(Math.PI/2),dark),new THREE.Mesh(new THREE.CylinderGeometry(.08,.08,.35,8).rotateX(Math.PI/2),brM).translateZ(-.5));tg.add(shl);
  const bcn=new THREE.Mesh(new THREE.CylinderGeometry(.1,.1,.14,10),bcM);bcn.position.set(1.1,1.6,-1.7);tg.add(bcn);
  const ant=mkAnt(tg,1.3,1.5,-1.9,flagM),ant2=mkAnt(tg,-1.3,1.5,-1.9,dark);
  /* canhao de 155 mm L/52: berco largo, cilindros de recuo, extrator de gases e freio de boca de varias aberturas */
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb(),K=mb();bp.position.set(0,.9,1.1);
  B.b(1.5,1,.7,'M',0,0,.3);B.b(1.3,.8,.35,'M',0,0,.78);B.c(.4,.45,.35,DK,0,0,.95,'z');B.b(.4,.3,.35,DK,.62,.45,.55);
  for(const s of[-1,1])B.c(.08,.08,1,MT,s*.3,.62,.95,'z');
  B.out(bp,mat);
  K.c(.22,.2,.5,DK,0,0,.95,'z');K.c(.17,.17,1.3,DK,0,0,1.7,'z');K.c(.1,.1,5.6,DK,0,0,5.15,'z');K.c(.06,.06,1.4,MT,0,.28,1.5,'z');
  K.c(.175,.175,1.1,DK,0,0,4.5,'z');for(const z of[4,4.25,4.5,4.75,5])K.c(.19,.19,.05,MT,0,0,z,'z');
  K.c(.2,.2,.8,DK,0,0,8.05,'z');for(let k=0;k<5;k++)K.c(.235,.235,.05,MT,0,0,7.75+k*.14,'z');K.b(.46,.04,.55,RB,0,.13,8.05);K.b(.46,.04,.55,RB,0,-.13,8.05);
  K.out(bar,mat);
  const fl=mkFl(bar,8.5,.6,flashM);bp.add(bar);tg.add(bp);hull.add(tg);
  return fin(base({g,tg,bp,bar,hull,ant,ant2,fan,glow,spade,rh,shl,bcn,bcM,dl,drv,crew,crew2,lid:[cl,ll],cup,cmg,fl,brkM,wheels,trk,mat,dark,pzh:true,cannon:true,spd:1.2,trn:.85,L:3.9,W:2,mz:8.6,fk:1.6,rld:3.8,wd:2,armor:.85,hp:95,TY:1.35}));
}
function animPzh(t,dt){
  const now=performance.now()/1000;t.clk+=dt;
  if(t.dead){
    t.glow.color.set(0x220000);t.drv.visible=false;t.crew2.visible=false;t.bcM.color.set(0x220000);t.shl.visible=false;
    t.dl.rotation.x=-1.5;t.lid[0].rotation.x=-1.5;t.lid[1].rotation.x=-1.4;t.rh.rotation.x=-1.6;t.spade.rotation.x=.3;
    if(t.ck===undefined)t.ck=7;
    if(t.ck>0){t.ck-=dt;t.ckt=(t.ckt||0)-dt;
      if(t.ckt<=0){t.ckt=.08+Math.random()*.1;t.tg.localToWorld(v2.set((Math.random()-.5)*2,.9,-1.2-Math.random()*.8)); /* os projeteis do carregador explodem */
        puff(v2,Math.random()<.5?0xffa030:0xffe08a,1.2,5,.55,9);puff(v2,0x1f1e1c,1.6,3,1.6,5);if(Math.random()<.25){puff(v2,0xff6a20,2.6,8,.4,10);sfx(.3*near(v2),.2)}}}
    return blowOff(t,dt,t.TY);
  }
  const th=clamp(Math.abs(t.v)/15,0,1),d=trkStep(t,dt,1.5),ac=clamp((t.v-t.pv)/Math.max(dt,.001),-9,9);
  /* parado por cerca de 1 s a pa desce e crava no chao: a recarga cai bastante e o recuo some */
  const still=Math.abs(t.v)<.6&&Math.abs(t.st||0)<.15;
  t.stead=clamp((t.stead||0)+(still?dt/1.3:-dt*1.8),0,1);t.rld=3.8-1.4*t.stead;
  t.spU=(t.spU||0)+((t.stead>.45?1:0)-(t.spU||0))*Math.min(1,dt*3);t.spade.rotation.x=-1.3+t.spU*1.6;
  if(t.spU>.9){if(!t.spL){t.spL=1;t.g.localToWorld(v2.set(0,.3,-3.9));for(let i=0;i<6;i++)puff(v2,0xa89a78,1.3,2.5,.8,1.2)}}else if(t.spU<.6)t.spL=0;
  for(const w of t.wheels){w.rotation.x+=d[w.userData.s]/w.userData.r;if(w.userData.b)w.position.y=.45+Math.sin(now*11+w.position.z*2.1)*.025*th}
  const ank=1-.6*t.stead;
  t.hull.position.y=Math.sin(now*36+t.x)*(.006+.012*th)-t.recoil*.03*ank;t.hull.rotation.x=-ac*.004-t.recoil*.025*ank;t.hull.rotation.z=-(t.st||0)*th*.03;
  t.ant.rotation.x=-t.v*.012+Math.sin(now*3+t.z)*.03;t.ant2.rotation.x=-t.v*.012+Math.sin(now*2.6+t.x)*.03;
  t.fan.rotation.y+=dt*(10+th*30);t.glow.color.setHSL(.07,1,.3+.25*th+.08*Math.sin(now*22));
  t.cup.rotation.y=t.mgt?t.cup.rotation.y:Math.sin(now*.6+t.x)*1.4;
  /* rajada: cada disparo puxa dois tiros em sequencia (tres no total) */
  if(t.bn>0){t.bt-=dt;if(t.bt<=0){t.bn--;t.bt=.8;t.bfi=1;fire(t);t.bfi=0}}
  if(inGarage&&(now%8)<.05&&t.clk-t.lf>2){t.recoil=1;t.fT=.09;t.ev=.6;t.lf=t.clk}
  /* cada tiro: freio de boca sopra poeira dos dois lados e comeca o ciclo do carregador (escotilha abre, projetil desliza) */
  if(t.pLf===undefined){t.pLf=t.lf;t.pRt=-1}
  if(t.lf!==t.pLf){t.pLf=t.lf;t.pRt=0;
    for(const s of[-1,1]){t.bar.localToWorld(v2.set(s*.4,0,7.7));puff(v2,0xe6dcc8,1.4,4,.7,1.2)}
    t.g.localToWorld(v2.set(0,.3,2.4));for(let i=0;i<4;i++)puff(v2,0xb5a584,2.2,6,1,.5)}
  if(t.pRt>=0){
    t.pRt+=dt;const u=t.pRt,op=u<.25?u/.25:u<1.6?1:Math.max(0,1-(u-1.6)/.3);
    t.rh.rotation.x=-1.45*op;t.shl.visible=u>.3&&u<1.5;t.shl.position.z=-2.3+clamp((u-.3)/.9,0,1)*1.1;
    if(u>1.95){t.pRt=-1;t.rh.rotation.x=0;t.shl.visible=false}
  }
  const act=t.bn>0||t.pRt>=0;t.bcM.color.setHex(act&&Math.sin(now*14)>0?0xffa020:0x2a1a05);
  tankFx(t,dt,now,th,{ex:[[1.25,1.62,2.6]],dk:[[1.7,.2,-3.1],[-1.7,.2,-3.1],[1.7,.2,3.1],[-1.7,.2,3.1]],mz:8.6,rr:.7,rc:1.2});
  t.dl.rotation.x=-t.open*1.4;t.drv.visible=t.open>.4;t.drv.position.y=t.drv.userData.by+Math.min(1,t.open)*.5;t.drv.rotation.y=Math.sin(now*.7+t.z)*.5;
  t.crew2.visible=t.open>.6;t.crew2.position.y=t.crew2.userData.by+(t.open-.3)*.45;t.crew2.rotation.y=Math.sin(now*.9+t.x)*.7;
  mgScan(t,dt,50);mgAim(t,dt,t.cmg,t.yaw,.7,[0,.1,1.45],now);smokeQ(t,dt,1.46,1,.8);
}
const VEH={m2:()=>makeM2(),t27:()=>makeT27(),l3:()=>makeL3(),pz1:()=>makePz1(),zsu:()=>makeZSU(),m109:()=>makeM109(),cro:()=>makeCrocodile(),pzh:()=>makePzH(),tank:()=>makeTank(0x5b6b3a),gep:()=>makeGepard(),arm:()=>makeArmata(),abrams:()=>makeAbrams(),tiger:()=>makeTiger(),astros:()=>makeAstros(),abv:()=>makeAbv(),m270:()=>makeM270(),gua:()=>makeGuarani(),stuart:()=>makeStuart(),mk1:()=>makeMarkI(),casc:()=>makeCascavel(),t34:()=>makeT34(),t35:()=>makeT35(),leo:()=>makeLeo(),pl:()=>makePL(),stk:()=>makeStrv(),jp:()=>makeJag(),hz:()=>makeHetzer(),ch2:()=>makeCh2(),sher:()=>makeSherman(),maus:()=>makeMaus(),su:()=>makeSU100(),amx:()=>makeAMX13(),ku:()=>makeKu(),amr:()=>makeAMR(),roo:()=>makeRoo(),t72:()=>makeT72(),t90:()=>makeT90(),t80:()=>makeT80(),mk4:()=>makeMerk(),bxr:()=>makeBoxer(),ap:()=>makeApache(),ch47:()=>makeCh47(),cv90:()=>makeCV90(),agmv:()=>makeAGMV(),stry:()=>makeStryker(),h225:()=>makeH225(),corv:()=>makeCorvette(),pant:()=>makePantsir(),aven:()=>makeAvenger()};
const VID={m2:'vm2',t27:'vt27',l3:'vl3',pz1:'vp1',zsu:'vzs',m109:'vm9',cro:'vcr',pzh:'vpz',tank:'vt',gep:'vgp',arm:'var',abrams:'vm',tiger:'vg',astros:'va',abv:'vb',m270:'vn',gua:'vu',stuart:'vs',mk1:'vk',casc:'vc',t34:'vq',t35:'vr',leo:'vl',pl:'vp',stk:'vx',jp:'vj',hz:'vh',ch2:'vy',sher:'vz',maus:'vw',su:'ve',amx:'vf',ku:'vi',amr:'vag',roo:'vro',t72:'v72',t90:'v90',t80:'v80',mk4:'vmk',bxr:'vbx',ap:'vap',ch47:'vch',cv90:'vc9',agmv:'vgm',stry:'vsg',h225:'vh2',corv:'vcv',pant:'vps',aven:'vav'};
function setVehicle(k){
  curV=k;const o=player;scene.remove(o.g);tanks.splice(tanks.indexOf(o),1);
  try{player=VEH[k]()}catch(e){showErr('modelo '+k,e);player=makeTank(0x5b6b3a)}player.isPlayer=true;player.x=o.x;player.z=o.z;player.hd=o.hd;player.yaw=o.yaw;if(player.corv)toSea(player);else if(o.corv)toLand(player);place(player);camUpdate();
  for(const q in VID)document.getElementById(VID[q]).classList.toggle('sel',q===k);
  document.body.classList.toggle('air',!!player.air);
  {const AB=document.getElementById('abtns'),H=document.getElementById('aph'),c=k==='ch47',hh=k==='h225';if(AB&&AB.children[3]){AB.children[2].textContent=c?'Carga':'Foguetes';AB.children[3].style.display=(c||hh)?'none':''}
   if(H)H.innerHTML=hh?'W S A D voar na direção da mira<br>Mouse mirar · Clique miniguns das portas<br>G foguetes<br>R F ou roda do mouse: altitude':c?'W S A D voar na direção da mira<br>Mouse mirar · Clique miniguns das portas<br>G soltar carga explosiva<br>R F ou roda do mouse: altitude':'W S A D voar na direção da mira<br>Mouse mirar · Clique canhão<br>G foguetes · H míssil Hellfire<br>R F ou roda do mouse: altitude'}
}
for(const q in VID)document.getElementById(VID[q]).onclick=()=>{if(unlocked(q))setVehicle(q)};
let sb=0,curV='tank';
function spawnWave(){spawnShips();sb=Math.random()*6.28;const n=5*(1+Math.ceil(wave/2));for(let i=0;i<n;i++)spawnEnemy(1+i%5)}
/* lugar de nascer valido: terra firme, terreno plano, longe de predios, arvores e outros veiculos */
function spawnOK(x,z,gap){
  if(Math.hypot(x,z)>HALF-30||getH(x,z)<1)return false;
  if(Math.abs(getH(x+3,z)-getH(x-3,z))>2.2||Math.abs(getH(x,z+3)-getH(x,z-3))>2.2)return false;
  for(const b of buildings)if(Math.hypot(b.x-x,b.z-z)<Math.max(b.w,b.d)/2+6)return false;
  for(const q of trees)if(Math.hypot(q.x-x,q.z-z)<4)return false;
  for(const q of props)if(Math.hypot(q.x-x,q.z-z)<3)return false;
  for(const q of tanks)if(!q.dead&&Math.hypot(q.x-x,q.z-z)<gap)return false;
  return true;
}
/* cada time tem sua base em um canto da ilha, bem afastada das outras (120 graus entre elas) */
const ZA=Math.random()*6.28,zones={};
function zoneOf(team){
  if(zones[team])return zones[team];
  for(let k=0;k<300;k++){
    const a=ZA+(team-1)*1.2566+(Math.random()-.5)*.4,r=HALF*(.45+Math.random()*.2),x=Math.cos(a)*r,z=Math.sin(a)*r;
    if(spawnOK(x,z,0))return zones[team]={x,z};
  }
  return zones[team]={x:Math.cos(ZA+(team-1)*1.2566)*HALF*.4,z:Math.sin(ZA+(team-1)*1.2566)*HALF*.4};
}
function spawnEnemy(team){
  for(let k=0;k<150;k++){
    const zc=zoneOf(team||1),a=Math.random()*6.28,r=8+Math.random()*50,x=zc.x+Math.cos(a)*r,z=zc.z+Math.sin(a)*r;
    if(!spawnOK(x,z,14)||Math.hypot(x-player.x,z-player.z)<60)continue;
    const T=team===5?{c:0xa8456f,f:0xff7ac8}:team===4?{c:0x5b3a86,f:0xb06cff}:team===2?{c:0x3d5f86,f:0x4aa3ff}:team===3?{c:0x2f7d3a,f:0xffd400}:{c:0x8a5a3a,f:0xd6452f},w=wave,mk=(f,hp)=>{let q;try{q=f(T.c,T.f)}catch(e){showErr('modelo',e);q=makeTank(T.c,T.f);hp=60}q.hp=hp;return q},
      t=Math.random()<Math.min(.05,.02*w)?mk(makeCrocodile,160):Math.random()<Math.min(.04,.015*w)?mk(makePzH,95):Math.random()<Math.min(.05,.018*w)?mk(makeStryker,115):Math.random()<Math.min(.06,.02*w)?mk(makeCV90,110):Math.random()<Math.min(.1,.035*w)?mk(makeAGMV,55):Math.random()<Math.min(.04,.015*w)?mk(makeH225,105):Math.random()<Math.min(.03,.012*w)?mk(makeCh47,150):Math.random()<Math.min(.06,.02*w)?mk(makeGepard,95):Math.random()<Math.min(.05,.02*w)?mk(makeApache,90):Math.random()<Math.min(.04,.015*w)?mk(makeArmata,125):Math.random()<Math.min(.04,.015*w)?mk(makeMerk,120):Math.random()<Math.min(.06,.02*w)?mk(makeBoxer,95):Math.random()<Math.min(.05,.02*w)?mk(makeT80,115):Math.random()<Math.min(.05,.02*w)?mk(makeT90,120):Math.random()<Math.min(.08,.03*w)?mk(makeT72,105):Math.random()<Math.min(.05,.02*w)?mk(makeRoo,105):Math.random()<Math.min(.07,.025*w)?mk(makeAMR,85):Math.random()<Math.min(.07,.025*w)?mk(makeKu,85):Math.random()<Math.min(.08,.03*w)?mk(makeSU100,115):Math.random()<Math.min(.1,.04*w)?mk(makeAMX13,75):Math.random()<Math.min(.08,.03*w)?mk(makeCh2,130):Math.random()<Math.min(.08,.03*w)?mk(makeStrv,100):Math.random()<Math.min(.08,.03*w)?mk(makeJag,110):Math.random()<Math.min(.12,.05*w)?mk(makeHetzer,70):Math.random()<Math.min(.1,.04*w)?mk(makeLeo,115):Math.random()<Math.min(.1,.04*w)?mk(makePL,95):Math.random()<Math.min(.12,.04*w)?mk(makeT35,140):Math.random()<Math.min(.25,.08*w)?mk(makeT34,85):Math.random()<Math.min(.5,.12*w)?(Math.random()<.5?mk(makeM270,110):mk(makeAstros,90)):Math.random()<Math.min(.3,.08*w)?mk(makeAbv,120):Math.random()<Math.min(.25,.06*w)?mk(makeAbrams,100):Math.random()<Math.min(.2,.05*w)?mk(makeTiger,110):
      Math.random()<Math.min(.2,.06*w)?mk(makeCascavel,80):Math.random()<Math.min(.2,.06*w)?mk(makeGuarani,100):Math.random()<Math.min(.14,.04*w)?mk(makeMarkI,130):Math.random()<Math.min(.06,.02*w)?mk(makeMaus,220):Math.random()<.22?mk(makeSherman,105):Math.random()<.07?mk(makeM109,100):Math.random()<.08?mk(makeZSU,75):Math.random()<.1?mk(makeM2,70):Math.random()<.1?mk(makePz1,50):Math.random()<.08?mk(makeT27,45):Math.random()<.08?mk(makeL3,42):Math.random()<.3?mk(makeStuart,70):mk(makeTank,60);
    t.team=team||1;t.x=x;t.z=z;t.hd=t.yaw=Math.random()*6.28;t.ai=true;t.cd=2+Math.random()*3+(t.astros?3:0);
    if(team===5)for(let i=0;i<12;i++)puff(new THREE.Vector3(x,getH(x,z)+2,z),i%2?0xff7ac8:0xd9549e,2.2,5,1.8,4);
    if(team===4)for(let i=0;i<12;i++)puff(new THREE.Vector3(x,getH(x,z)+2,z),i%2?0xb06cff:0x7a3fd0,2.2,5,1.8,4);
    if(team===3)for(let i=0;i<12;i++)puff(new THREE.Vector3(x,getH(x,z)+2,z),i%2?0xffd400:0x3fd25a,2.2,5,1.8,4);
    return;
  }
}
function spawnAlly(){
  for(let k=0;k<150;k++){
    const a=Math.random()*6.28,r=22+Math.random()*28,x=player.x+Math.cos(a)*r,z=player.z+Math.sin(a)*r;
    if(!spawnOK(x,z,10))continue;
    const L=[[makeM2,70],[makeT27,45],[makeL3,42],[makePz1,50],[makeZSU,75],[makeM109,100],[makeCrocodile,160],[makePzH,95],[makeCV90,110],[makeStryker,115],[makeAGMV,55],[makeGepard,95],[makePantsir,85],[makeAvenger,80],[makeCh47,150],[makeH225,105],[makeApache,90],[makeT34,85],[makeStrv,100],[makeCh2,130],[makeJag,110],[makeHetzer,70],[makeLeo,115],[makeArmata,125],[makePL,95],[makeT35,140],[makeTank,60],[makeStuart,70],[makeAbrams,100],[makeCascavel,80],[makeGuarani,100],[makeM270,110],[makeAstros,90],[makeTiger,110],[makeSherman,105],[makeMaus,220],[makeSU100,115],[makeAMX13,75],[makeKu,85],[makeAMR,85],[makeRoo,105],[makeT72,105],[makeT90,120],[makeT80,115],[makeMerk,120],[makeBoxer,95]],[f,hp]=L[Math.floor(Math.random()*L.length)],q=(()=>{try{return f(0x5b6b3a,0xffb000)}catch(e){showErr('modelo',e);return makeTank(0x5b6b3a,0xffb000)}})();
    q.hp=hp;q.team=0;q.ally=true;q.x=x;q.z=z;q.hd=q.yaw=player.hd;q.ai=true;q.cd=2+Math.random()*3+(q.astros?3:0);
    for(let i=0;i<10;i++)puff(new THREE.Vector3(x,getH(x,z)+2,z),i%2?0xffb000:0xf3ecd8,2,5,1.6,4);
    return;
  }
}
const hostile=(a,b)=>(a.team||0)!==(b.team||0);
function ai(t,dt){
  if(t.corv)return aiShip(t,dt);
  t.rt=(t.rt||0)-dt;
  /* foco de fogo: prefere alvos feridos e o mesmo alvo que os colegas de time */
  if(t.rt<=0||!t.tar||t.tar.dead){t.rt=.6+Math.random()*.4;let best=1e9,bt=null;
    for(const q of tanks){if(q.dead||q.idle||!hostile(t,q))continue;let sc=Math.hypot(q.x-t.x,q.z-t.z)*(.6+.4*q.hp/mhpOf(q));
      for(const m of tanks)if(m!==t&&!m.dead&&m.tar===q&&(m.team||0)===(t.team||0)){sc*=.8;break}
      if(sc<best){best=sc;bt=q}}
    t.tar=bt}
  let o=t.tar;const ally=!!t.ally,dpl=Math.hypot(player.x-t.x,player.z-t.z);
  if(o&&ally&&cmd!=='attack'&&Math.hypot(o.x-t.x,o.z-t.z)>230)o=null;
  const dx=o?o.x-t.x:0,dz=o?o.z-t.z:0,d=o?Math.hypot(dx,dz):0,want=o?Math.atan2(dx,dz):t.hd;
  let mvw=want,th=o&&d>((t.ap||t.ch47||t.h225)?90:t.astros?120:t.abv?6:t.stry?420:t.pzh?170:t.cro?12:t.ku?150:55)?.8:0,still=false;
  /* circula o alvo em vez de avancar reto */
  if(o&&!t.astros&&!t.abv&&d>0&&d<=(t.ku||t.pzh?60:t.cro?22:130)){t.sd=t.sd||(Math.random()<.5?1:-1);t.sw=(t.sw||0)-dt;if(t.sw<=0){t.sw=4+Math.random()*5;t.sd=-t.sd}mvw=want+t.sd*(d<45?1.4:1.1);th=.6}
  /* cobertura: enquanto recarrega, esconde-se atras de morro ou predio e depois sai para atirar */
  if(o&&!t.astros&&!t.abv&&!t.air&&!t.cro&&d>35&&d<(t.ku?260:t.pzh?320:170)&&(!ally||cmd==='attack')){
    t.cvT=(t.cvT||0)-dt;
    if(t.cd>1.3){if(t.cvT<=0){t.cvT=1.2+Math.random()*.6;pickCover(t,o)}}
    else if(t.cd<=1)t.cvx=undefined;
    if(t.cvx!==undefined){if(Math.hypot(t.cvx-t.x,t.cvz-t.z)>3.5){mvw=Math.atan2(t.cvx-t.x,t.cvz-t.z);th=.85}else{th=0;still=true}}
  }else t.cvx=undefined;
  if(t.cp&&t.cp.tor<8&&o)mvw=want; /* torre emperrada: gira o casco para mirar */
  /* comandos do time do jogador */
  if(ally&&cmd==='hold'){th=0;still=true}
  else if(ally&&cmd==='follow'){if(dpl>38){mvw=Math.atan2(player.x-t.x,player.z-t.z);th=Math.min(.9,.3+dpl/80)}else{th=0;still=true}}
  /* ferido: corre para a caixa de reparo mais proxima ou foge do alvo */
  if((!ally&&t.hp<.3*mhpOf(t))||(ally&&t.hp<.25*mhpOf(t))){let cr=null,c2=1e9;for(const c of crates)if(c.kind==='rep'){const dd=Math.hypot(c.x-t.x,c.z-t.z);if(dd<c2){c2=dd;cr=c}}
    if(cr&&c2<350){mvw=Math.atan2(cr.x-t.x,cr.z-t.z);th=.9;still=false}else if(o){mvw=want+Math.PI;th=.8;still=false}}
  if(!o&&th===0)return;
  const wd=wadeOf(t);
  let tn=still?0:clamp(angDiff(mvw,t.hd)*2,-1,1)*.9;
  if(t.wet>wd-.2||(th>0&&WATER-getHV(t.x+Math.sin(t.hd)*12,t.z+Math.cos(t.hd)*12)>wd-.5)){t.av=t.av||(Math.random()<.5?1:-1);t.avt=1}
  if(t.avt>0){t.avt-=dt;tn=t.av;th=t.fld?-.7:.25}else t.av=0;
  drive(t,dt,th,tn);
  if(!o)return;
  const dy=angDiff(want,t.yaw);t.yaw+=clamp(dy,-1.2*dt,1.2*dt);
  t.pitch=.5*Math.asin(Math.min(1,G*d/(SPEED*SPEED)))+(o.y-t.y)/Math.max(d,20)*.6+.02;
  if(t.stry)t.pitch=Math.atan2(o.y+1-t.y-2.6,Math.max(d,20))*.9;
  t.cd-=dt;
  if(t.cd<=0&&d<((t.ap||t.ch47||t.h225)?200:t.astros?230:t.abv?90:t.stry?720:t.ku?250:t.pzh?310:t.roo?200:(t.boxer||t.gep||t.zsu)?190:t.m109?300:150)&&Math.abs(dy)<.06){t.cd=t.abv?8+Math.random()*3:t.astros?6+Math.random()*2:(t.rld?t.rld+1.4:3.2)+Math.random()*1.8;t.yaw+=(Math.random()-.5)*.05;t.pitch+=(Math.random()-.5)*.03;fire(t)}
}

/* ---------- rastros no chao ---------- */
const MAXT=900,trkX=new Float32Array(MAXT),trkZ=new Float32Array(MAXT),trkMesh=new THREE.InstancedMesh(new THREE.PlaneGeometry(.75,1.25).rotateX(-Math.PI/2),
  new THREE.MeshBasicMaterial({color:0x2e2a20,transparent:true,opacity:.42,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-2}),MAXT);
trkMesh.frustumCulled=false;trkMesh.count=0;scene.add(trkMesh);
let trkN=0;const mT=new THREE.Matrix4(),pT=new THREE.Vector3(),sT=new THREE.Vector3(),zM=new THREE.Matrix4().makeScale(0,0,0);
function stamp(t,dt){
  t.dust=(t.dust||0)+Math.abs(t.v)*dt;if(t.dust<1.1)return;t.dust-=1.1;
  const off=t.m2lt?1.12:t.t27?.82:t.l3?.72:t.pz1?.85:t.zsu?1.5:t.m109?1.48:t.cro?1.45:t.pzh?1.5:t.cv90?1.5:t.stry?1.5:t.agmv?1:t.gep?1.5:t.t80?1.45:t.merk?1.6:t.boxer?1.42:t.t90||t.t72?1.42:t.arm14?1.62:t.amr?1.5:t.roo?1.55:t.su?1.4:t.amx?1.2:t.ku?1.3:t.ch2?1.65:t.sher?1.5:t.maus?1.95:t.stk?1.6:t.jp?1.55:t.hz?1.2:t.t34?1.28:t.t35?1.42:t.leo?1.62:t.pl01?1.55:t.stuart?1.55:t.mk1?1.7:(t.casc||t.gua)?1.5:t.tiger?1.4:t.abrams?1.6:t.abv?1.6:t.m270?1.5:t.astros?1.35:1.95,w=(t.astros||t.casc||t.gua||t.amr||t.roo||t.boxer||t.agmv||t.stry)?.55:1,c=Math.cos(t.hd),sn=Math.sin(t.hd);
  for(const sd of[-1,1]){
    const x=t.x+c*sd*off,z=t.z-sn*sd*off,y=getH(x,z);if(y<WATER+.4)continue;
    const k=trkN%MAXT;trkN++;trkX[k]=x;trkZ[k]=z;pT.set(x,y+.08,z);sT.set(w,1,1);
    trkMesh.setMatrixAt(k,mT.compose(pT,t.g.quaternion,sT));
  }
  trkMesh.count=Math.min(trkN,MAXT);trkMesh.instanceMatrix.needsUpdate=true;
}
function hideTracks(x,z,R){
  let ch=false;for(let k=0;k<Math.min(trkN,MAXT);k++)if(Math.hypot(trkX[k]-x,trkZ[k]-z)<R+1){trkMesh.setMatrixAt(k,zM);ch=true}
  if(ch)trkMesh.instanceMatrix.needsUpdate=true;
}
/* ---------- efeitos ---------- */
const parts=[],debris=[],shells=[],pg=new THREE.SphereGeometry(1,6,5),sg=new THREE.SphereGeometry(.4,8,8),dg=new THREE.BoxGeometry(1,1,1);
const shellP=new THREE.MeshBasicMaterial({color:0xffe08a}),shellE=new THREE.MeshBasicMaterial({color:0xff6a3a});
const pPool=[];
function puff(p,color,size,speed,life,up){if(inGarage||parts.length>700)return;
  let m=pPool.pop();if(m){m.material.color.set(color);m.material.opacity=.9}else m=new THREE.Mesh(pg,new THREE.MeshBasicMaterial({color,transparent:true,opacity:.9,depthWrite:false}));
  m.position.copy(p);m.scale.setScalar(size);scene.add(m);
  parts.push({m,v:new THREE.Vector3((Math.random()-.5)*speed,Math.random()*speed*.8+up,(Math.random()-.5)*speed),life,max:life,size});
}
let ac;
function sfx(vol,len){
  try{ac=ac||new AudioContext();const b=ac.createBuffer(1,ac.sampleRate*len,ac.sampleRate),d=b.getChannelData(0);
    for(let i=0;i<d.length;i++)d[i]=(Math.random()*2-1)*Math.pow(1-i/d.length,3);
    const s=ac.createBufferSource(),g=ac.createGain(),f=ac.createBiquadFilter();f.type='lowpass';f.frequency.value=len>.4?420:900;g.gain.value=vol;
    s.buffer=b;s.connect(f);f.connect(g);g.connect(ac.destination);s.start();}catch(e){}
}
const near=p=>Math.min(1,45/(Math.hypot(p.x-player.x,p.z-player.z)+15));
let shake=0,hurt=0;
