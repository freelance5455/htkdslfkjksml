// Thin wrapper around the Socket.IO client. All real-time client<->server
// traffic goes through here so game.js/main.js never touch socket internals
// directly.
const NET = {
  socket: io(window.BZ_CONFIG.SERVER_URL || undefined, { transports: ['websocket', 'polling'] }),

  login(username) {
    this.socket.emit('login', { username });
  },
  joinMatchmaking(mode) {
    this.socket.emit('joinMatchmaking', { mode });
  },
  devForceStart() {
    this.socket.emit('devForceStart');
  },
  sendUpdate(position, rotationY) {
    this.socket.emit('playerUpdate', { position, rotationY });
  },
  shoot(origin, direction) {
    this.socket.emit('shoot', { origin, direction });
  },
};
