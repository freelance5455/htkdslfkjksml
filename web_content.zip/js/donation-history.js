/**
 * BD BLOOD DONATION - Verified Donation History & Badge View
 * Fetches verified donations completed through the platform
 */

import { 
  db, 
  collection, 
  query, 
  where, 
  orderBy, 
  limit, 
  getDocs 
} from './firebase-config.js';
import { getCurrentUser, getCurrentUserProfile } from './auth.js';
import { toBengaliDigits, escapeHtml, formatDate, getLanguage } from './utils.js';

export async function fetchDonorDonationHistory(donorId) {
  if (!donorId) return [];
  try {
    const q = query(
      collection(db, 'donation_history'),
      where('donorId', '==', donorId),
      orderBy('donatedAt', 'desc'),
      limit(50)
    );
    const snap = await getDocs(q);
    const history = [];
    snap.forEach(docSnap => {
      history.push({ id: docSnap.id, ...docSnap.data() });
    });
    return history;
  } catch (error) {
    console.warn('[Donation History Fallback]', error.message);
    try {
      const snap = await getDocs(query(collection(db, 'donation_history'), where('donorId', '==', donorId)));
      const history = [];
      snap.forEach(docSnap => history.push({ id: docSnap.id, ...docSnap.data() }));
      return history;
    } catch (e) {
      return [];
    }
  }
}

export async function renderDonationHistoryPage(container) {
  const user = getCurrentUser();
  const profile = getCurrentUserProfile();
  const isBn = getLanguage() === 'bn';

  if (!user) {
    container.innerHTML = `
      <div class="page-container animate-slide-in">
        <div class="empty-state card">
          <div class="empty-state-icon">🩸</div>
          <div class="empty-state-title">${isBn ? 'লগইন প্রয়োজন' : 'Login Required'}</div>
          <div class="empty-state-desc">${isBn ? 'আপনার রক্তদানের ইতিহাস ও সম্মাননা সনদ দেখতে অনুগ্রহ করে লগইন করুন।' : 'Please login to view your donation history.'}</div>
          <a href="#/login" class="btn btn-primary btn-sm" style="margin-top: 10px;">${isBn ? 'লগইন করুন' : 'Login'}</a>
        </div>
      </div>
    `;
    return;
  }

  const donationCount = profile?.donationCount || 0;

  container.innerHTML = `
    <div class="page-container animate-slide-in">
      <div class="page-header-title">
        <span>🩸 ${isBn ? 'রক্তদানের ইতিহাস ও অর্জন' : 'Donation History & Badges'}</span>
      </div>

      <!-- Lifetime Honor Badge Card -->
      <div class="card" style="background: linear-gradient(135deg, #1E293B 0%, #0F172A 100%); color: #fff; padding: 20px; text-align: center; border-radius: var(--radius-lg);">
        <div style="font-size: 40px; margin-bottom: 6px;">🎖️</div>
        <div style="font-size: 16px; font-weight: 800; color: #F87171;">
          ${isBn ? 'জীবন রক্ষাকারী রক্তদাতা সম্মাননা' : 'Life Saver Donor'}
        </div>
        <p style="font-size: 12px; color: #94A3B8; margin-top: 4px;">
          ${escapeHtml(profile?.fullName || user.displayName || 'সম্মানিত রক্তদাতা')}
        </p>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-top: 16px; padding-top: 14px; border-top: 1px solid rgba(255,255,255,0.1);">
          <div>
            <div style="font-size: 22px; font-weight: 800; color: #fff;">${toBengaliDigits(donationCount)}</div>
            <div style="font-size: 11px; color: #94A3B8;">${isBn ? 'মোট সফল রক্তদান' : 'Total Donations'}</div>
          </div>
          <div>
            <div style="font-size: 22px; font-weight: 800; color: #34D399;">${toBengaliDigits(donationCount)}</div>
            <div style="font-size: 11px; color: #94A3B8;">${isBn ? 'বাঁচানো জীবন' : 'Lives Impacted'}</div>
          </div>
        </div>
      </div>

      <!-- Next Safe Donation Notice -->
      <div class="card" style="border-left: 4px solid var(--info-color); background: var(--info-bg);">
        <div style="display: flex; gap: 10px; align-items: center;">
          <div style="font-size: 24px;">ℹ️</div>
          <div>
            <div style="font-size: 13px; font-weight: 700; color: var(--text-main);">
              ${isBn ? 'রক্তদানের স্বাস্থ্যবিধি' : 'Donation Health Guideline'}
            </div>
            <div style="font-size: 11px; color: var(--text-muted); line-height: 1.35;">
              ${isBn 
                ? 'একজন সুস্থ পূর্ণবয়স্ক পুরুষ প্রতি ৩ মাস এবং নারী প্রতি ৪ মাস পর পর নিরাপদে রক্তদান করতে পারেন।' 
                : 'Healthy adults can safely donate blood every 90-120 days.'}
            </div>
          </div>
        </div>
      </div>

      <!-- Verified Donation Records List -->
      <div class="section-title-row" style="margin-top: 16px;">
        <div class="section-title">
          <span>📜</span>
          <span>${isBn ? 'যাচাইকৃত রক্তদানের তালিকা' : 'Verified Donation Records'}</span>
        </div>
      </div>

      <div id="donation-history-list">
        <div class="spinner"></div>
      </div>
    </div>
  `;

  const listContainer = document.getElementById('donation-history-list');
  const records = await fetchDonorDonationHistory(user.uid);

  if (records.length === 0) {
    listContainer.innerHTML = `
      <div class="empty-state card">
        <div class="empty-state-icon">📋</div>
        <div class="empty-state-title">${isBn ? 'এখনো কোনো রেকর্ড নেই' : 'No Donation Records Yet'}</div>
        <div class="empty-state-desc">
          ${isBn 
            ? 'আবেদনে রক্তদানের পর সেবাগ্রহীতা সম্পন্ন নিশ্চিত করলে আপনার ইতিহাস স্বয়ংক্রিয়ভাবে এখানে যুক্ত হবে।' 
            : 'Completed donations will appear here once verified by the recipient.'}
        </div>
      </div>
    `;
    return;
  }

  let html = '';
  records.forEach((rec, idx) => {
    html += `
      <div class="card" style="display: flex; align-items: center; justify-content: space-between; padding: 14px;">
        <div style="display: flex; align-items: center; gap: 12px;">
          <div style="width: 36px; height: 36px; border-radius: 50%; background: var(--primary-light); color: var(--primary-color); display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 13px;">
            ${toBengaliDigits(records.length - idx)}
          </div>
          <div>
            <div style="font-size: 14px; font-weight: 700; color: var(--text-main);">
              ${escapeHtml(rec.patientName ? `রোগী: ${rec.patientName}` : (isBn ? 'রক্তদান সম্পন্ন' : 'Blood Donated'))}
            </div>
            <div style="font-size: 11px; color: var(--text-muted); margin-top: 2px;">
              🏥 ${escapeHtml(rec.hospitalName || 'হাসপাতাল')} • 🩸 ${rec.bloodGroup || profile?.bloodGroup || ''}
            </div>
          </div>
        </div>
        <div style="text-align: right;">
          <span class="badge badge-success">যাচাইকৃত</span>
          <div style="font-size: 10px; color: var(--text-light); margin-top: 4px;">
            ${formatDate(rec.donatedAt)}
          </div>
        </div>
      </div>
    `;
  });

  listContainer.innerHTML = html;
}
