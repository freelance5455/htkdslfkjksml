/* naval.js — Phase 9: sea zones, ports, ships, fleets, naval combat, blockades, transports and amphibious landings.
   Graph: sea zones ('z3') connect to neighbouring zones (plus straits) and to the ports (coastal land provinces) on their shores.
   A fleet is at a node (a zone, or a port province when docked). Armies carried by transports are removed from st.armies and
   stored in fleet.cargo until they land. */
(function (G) {
  'use strict';

  G.SHIPS = {
    destroyer:  { name: 'Destroyer',  icon: 'DD', gold: 80,  steel: 18,  oil: 8,  days: 28, atk: 6,  def: 5,  speed: 46, cargo: 0, bomb: 0.10, desc: 'Fast escort. Hunts submarines and screens transports.' },
    submarine:  { name: 'Submarine',  icon: 'SS', gold: 70,  steel: 14,  oil: 6,  days: 26, atk: 7,  def: 2,  speed: 30, cargo: 0, bomb: 0,    desc: 'Cheap raider. Deadly if the enemy has no destroyers; counts as half a ship in blockades.' },
    cruiser:    { name: 'Cruiser',    icon: 'CL', gold: 150, steel: 40,  oil: 18, days: 45, atk: 10, def: 9,  speed: 40, cargo: 0, bomb: 0.30, desc: 'Balanced warship; supports landings with gunfire.' },
    battleship: { name: 'Battleship', icon: 'BB', gold: 320, steel: 100, oil: 45, days: 90, atk: 18, def: 20, speed: 30, cargo: 0, bomb: 0.55, desc: 'Decides fleet battles and shells coastal defences.' },
    transport:  { name: 'Transport',  icon: 'TR', gold: 55,  steel: 12,  oil: 5,  days: 18, atk: 0,  def: 1,  speed: 34, cargo: 3, bomb: 0,    desc: 'Carries 3 army units overseas. Vulnerable — escort it.' }
  };
  G.SHIP_ORDER = ['destroyer', 'submarine', 'cruiser', 'battleship', 'transport'];
  G.CARGO_PER_TRANSPORT = 3;
  G.NAVAL_QUEUE_MAX = 8;
  G.FLEET_MAX_SHIPS = 12;
  const BREAK_HP = 0.35;

  const isZone = n => typeof n === 'string';
  G.isZone = isZone;
  const cname = id => G.COUNTRIES[id].name;
  function ord(n) { const s = ['th', 'st', 'nd', 'rd'], v = n % 100; return n + (s[(v - 20) % 10] || s[v] || s[0]); }
  G.navalSpeedMult = function () { return Math.max(1, 70 / (G.AVGCELL || 100)); };

  /* ---------- state ---------- */
  G.initNaval = function (st, fresh) {
    st.fleets = st.fleets || [];
    st.shipQ = st.shipQ || {};
    st.nextFid = st.nextFid || 1;
    st.fleetCount = st.fleetCount || {};
    st.navalRec = st.navalRec || {};
    for (const id in G.COUNTRIES) st.shipQ[id] = st.shipQ[id] || [];
    st.fleets.forEach(f => { f.path = f.path || []; f.cargo = f.cargo || []; f.progress = f.progress || 0; });
    if (fresh) startingFleets(st);
    G.recomputeBlockades();
  };

  function startingFleets(st) {
    for (const id in G.COUNTRIES) {
      const c = G.COUNTRIES[id];
      const ports = G.provinces.filter(p => !p.sea && st.owners[p.id] === id && p.seaZones && p.seaZones.length);
      if (!ports.length) continue;
      ports.sort((a, b) => (b.capital ? 1e6 : 0) + b.pop - ((a.capital ? 1e6 : 0) + a.pop));
      const pow = c.pow || (c.manpower > 70000 ? 4 : c.manpower > 50000 ? 3 : 2);
      const mix = pow >= 5 ? { destroyer: 5, cruiser: 2, battleship: 2, submarine: 3, transport: 4 }
        : pow === 4 ? { destroyer: 4, cruiser: 2, battleship: 1, submarine: 2, transport: 3 }
        : pow === 3 ? { destroyer: 3, cruiser: 1, submarine: 1, transport: 3 }
        : pow === 2 ? { destroyer: 2, submarine: 1, transport: 2 } : { destroyer: 1, transport: 1 };
      const n = ports.length > 1 && pow >= 4 ? 2 : 1;      // great powers split their strength over two ports
      for (let k = 0; k < n; k++) {
        const port = ports[k % ports.length];
        const war = [], tr = [];
        for (const t in mix) { const cnt = Math.ceil(mix[t] / n); for (let i = 0; i < cnt; i++) (t === 'transport' ? tr : war).push({ type: t, hp: 1 }); }
        if (war.length) G.createFleet(id, port.id, war);
        if (tr.length) G.createFleet(id, port.id, tr);
      }
    }
  }

  G.createFleet = function (owner, loc, ships) {
    const st = G.state;
    st.fleetCount[owner] = (st.fleetCount[owner] || 0) + 1;
    const f = { id: st.nextFid++, owner: owner, name: ord(st.fleetCount[owner]) + ' Fleet', loc: loc, ships: ships || [], path: [], progress: 0, legDays: 1, mission: null, cargo: [] };
    st.fleets.push(f);
    return f;
  };
  G.fleetById = function (id) { return G.state.fleets.find(f => f.id === id) || null; };
  G.removeFleet = function (f, why) {
    const st = G.state, i = st.fleets.indexOf(f);
    if (f.cargo && f.cargo.length) f.cargo.slice().forEach(a => G.loseCargoArmy(f, a, why));
    if (i >= 0) st.fleets.splice(i, 1);
    if (G.selFleet === f.id) { G.selFleet = null; G.fleetMoveMode = false; }
  };
  G.stationary = function (node) { return G.state.fleets.filter(f => f.loc === node && !(f.progress > 0)); };
  G.fleetsDockedAt = function (prov) { return G.state.fleets.filter(f => f.loc === prov && !(f.path && f.path.length)); };

  /* ---------- fleet numbers ---------- */
  const navAtk = o => 1 + G.techEff(o, 'naval_atk');
  const navDef = o => 1 + G.techEff(o, 'naval_def');
  const dur = (s, o) => Math.max(5, G.SHIPS[s.type].def * 10 * navDef(o));
  G.fleetFire = function (f, blockade) {
    let fire = 0; const m = navAtk(f.owner);
    for (const s of f.ships) { const d = G.SHIPS[s.type]; fire += d.atk * s.hp * m * (blockade && s.type === 'submarine' ? 0.5 : 1); }
    return fire;
  };
  G.fleetSummary = function (f) {
    let n = f.ships.length, hp = 0, speed = Infinity, tr = 0, war = 0;
    f.ships.forEach(s => { hp += s.hp; speed = Math.min(speed, G.SHIPS[s.type].speed); if (G.SHIPS[s.type].cargo) tr++; if (G.SHIPS[s.type].atk > 0) war++; });
    const cargoUnits = f.cargo.reduce((x, a) => x + a.units.length, 0);
    return { n: n, hp: n ? hp / n : 0, speed: n ? speed : 0, transports: tr, warships: war, fire: G.fleetFire(f), cap: tr * G.CARGO_PER_TRANSPORT, cargoUnits: cargoUnits, free: tr * G.CARGO_PER_TRANSPORT - cargoUnits };
  };
  function warHp(ships) { const w = ships.filter(s => G.SHIPS[s.type].atk > 0); return w.length ? w.reduce((a, s) => a + s.hp, 0) / w.length : 0; }

  /* ---------- graph and movement ---------- */
  G.canDock = function (owner, prov) {
    const o = G.state.owners[prov];
    return !!o && (o === owner || G.allied(o, owner) || !!G.hasTreaty('access', o, owner));
  };
  G.straitOpen = function (owner, za, zb) {
    const s = (G.straits || []).find(x => (x.a === za && x.b === zb) || (x.a === zb && x.b === za));
    if (!s || s.ctrl == null) return true;
    const o = G.state.owners[s.ctrl];
    return !(o && o !== owner && !G.allied(o, owner) && G.atWar(owner, o));
  };
  function neighbors(owner, node) {
    const out = [];
    if (isZone(node)) {
      const z = G.zoneById[node];
      z.adj.forEach(n => { if (G.straitOpen(owner, node, n)) out.push(n); });
      z.ports.forEach(p => { if (G.canDock(owner, p)) out.push(p); });
    } else G.provinces[node].seaZones.forEach(z => out.push(z));
    return out;
  }
  function fleetSpeed(f) { return Math.max(1, G.fleetSummary(f).speed * G.navalSpeedMult() * (1 + G.techEff(f.owner, 'naval_speed')) * (1 + 0.5 * G.techEff(f.owner, 'speed'))); }
  G.navalLegDays = function (f, a, b) {
    const pa = G.nodePos(a), pb = G.nodePos(b);
    return Math.max(1, Math.hypot(pa.x - pb.x, pa.y - pb.y) / fleetSpeed(f));
  };
  // Dijkstra from `start` to the first node satisfying goal(); returns array of nodes after start, or null.
  G.navalPath = function (f, start, goal) {
    if (goal(start)) return [];
    const dist = { [start]: 0 }, prev = {}, done = {}, open = [start];
    while (open.length) {
      let bi = 0; for (let i = 1; i < open.length; i++) if (dist[open[i]] < dist[open[bi]]) bi = i;
      const cur = open.splice(bi, 1)[0];
      if (done[cur]) continue; done[cur] = true;
      if (goal(cur)) { const path = []; let c = cur; while (c !== start) { path.unshift(c); c = prev[c]; } return path; }
      for (const n of neighbors(f.owner, cur)) {
        const nd = dist[cur] + G.navalLegDays(f, cur, n);
        if (dist[n] === undefined || nd < dist[n]) { dist[n] = nd; prev[n] = cur; open.push(n); }
      }
    }
    return null;
  };
  G.fleetInBattle = function (f) { return !!G.navalBattleOf(f); };
  G.orderSail = function (f, dest) {
    if (!f.ships.length) return { ok: false, msg: 'Fleet has no ships' };
    if (G.fleetInBattle(f)) return { ok: false, msg: 'Fleet is engaged in battle' };
    if (!isZone(dest)) {
      if (G.provinces[dest].sea || !G.provinces[dest].seaZones.length) return { ok: false, msg: 'Not a port' };
      if (!G.canDock(f.owner, dest)) return { ok: false, msg: 'You cannot dock in ' + G.provinces[dest].name };
    }
    const mid = f.path.length > 0 && f.progress > 0, base = mid ? f.path[0] : f.loc;
    if (dest === base && !mid) return { ok: false, msg: 'Already there' };
    const path = G.navalPath(f, base, n => n === dest);
    if (path === null) return { ok: false, msg: 'No sea route (closed strait or hostile port?)' };
    if (mid) path.unshift(base);
    f.path = path; f.goal = dest; f.mission = null;
    if (!mid) { f.progress = 0; f.legDays = G.navalLegDays(f, f.loc, path[0]); }
    return { ok: true, eta: G.fleetEta(f) };
  };
  G.stopFleet = function (f) { f.goal = null; f.mission = null; if (f.path.length) { f.path = f.progress > 0 ? [f.path[0]] : []; if (!f.path.length) f.progress = 0; } };
  G.fleetEta = function (f) {
    if (!f.path.length) return 0;
    let d = f.legDays * (1 - f.progress), from = f.path[0];
    for (let i = 1; i < f.path.length; i++) { d += G.navalLegDays(f, from, f.path[i]); from = f.path[i]; }
    return Math.ceil(d);
  };
  G.fleetPos = function (f) {
    const a = G.nodePos(f.loc);
    if (!f.path.length || !(f.progress > 0)) return { x: a.x, y: a.y, moving: f.path.length > 0 };
    const b = G.nodePos(f.path[0]), t = f.progress;
    return { x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t, moving: true };
  };
  G.fleetLocName = function (f) {
    if (isZone(f.loc)) return G.zoneById[f.loc].name;
    return G.provinces[f.loc].name + ' (port)';
  };
  G.nodeName = function (n) { return isZone(n) ? G.zoneById[n].name : G.provinces[n].name; };

  function moveFleets() {
    const st = G.state;
    for (const f of st.fleets.slice()) {
      if (!f.path.length || G.fleetInBattle(f)) continue;
      f.progress += 1 / f.legDays;
      if (f.progress < 1) continue;
      const next = f.path[0];
      // entering a port that may no longer be open to us, or a closed strait: stop where we are
      if (!isZone(next) && !G.canDock(f.owner, next)) { f.path = []; f.progress = 0; continue; }
      f.loc = f.path.shift(); f.progress = 0;
      if (f.path.length) f.legDays = G.navalLegDays(f, f.loc, f.path[0]);
      else { f.goal = null; arrive(f); }
      // a fleet that runs into enemies stops and fights
      if (f.path.length && isZone(f.loc) && G.stationary(f.loc).some(o => o !== f && G.atWar(o.owner, f.owner))) { f.path = []; f.progress = 0; if (f.mission) f.mission.interrupted = true; }
    }
  }

  /* ---------- transports and landings ---------- */
  G.loseCargoArmy = function (f, a, why) {
    const old = G.generalOf && G.generalOf(a); if (old) old.army = null;
    const i = f.cargo.indexOf(a); if (i >= 0) f.cargo.splice(i, 1);
    if (f.owner === G.state.player) G.logMsg(a.name + ' was lost at sea' + (why ? ' (' + why + ')' : ''));
  };
  G.armyById = (function (orig) {
    return function (id) {
      const a = orig(id); if (a) return a;
      for (const f of G.state.fleets || []) { const c = f.cargo.find(x => x.id === id); if (c) return c; }
      return null;
    };
  })(G.armyById);
  G.loadArmy = function (f, a) {
    const st = G.state, sm = G.fleetSummary(f);
    if (typeof f.loc !== 'number' || a.prov !== f.loc || a.owner !== f.owner) return { ok: false, msg: 'Army and fleet must be in the same port' };
    if (a.path.length || G.inBattle(a)) return { ok: false, msg: 'Army must be stationary' };
    if (a.units.length > sm.free) return { ok: false, msg: 'Not enough transport room (' + sm.free + ' free, army has ' + a.units.length + ' units)' };
    const i = st.armies.indexOf(a); if (i >= 0) st.armies.splice(i, 1);
    f.cargo.push(a); a.aboard = f.id; a.path = []; a.goal = null; a.progress = 0;
    if (G.selArmy === a.id) { G.selArmy = null; G.moveMode = false; }
    return { ok: true };
  };
  function disembark(f, a, prov) {
    a.aboard = null; a.prov = prov; a.path = []; a.progress = 0;
    const i = f.cargo.indexOf(a); if (i >= 0) f.cargo.splice(i, 1);
    G.state.armies.push(a);
  }
  G.unloadAll = function (f) {
    if (typeof f.loc !== 'number' || !G.canDock(f.owner, f.loc)) return { ok: false, msg: 'Armies can only unload in a friendly port (or land on a coast)' };
    const n = f.cargo.length; f.cargo.slice().forEach(a => disembark(f, a, f.loc));
    return { ok: true, n: n };
  };
  // Where may an army of `owner` land? returns {ok, invade, msg}
  G.landingCheck = function (owner, prov) {
    const st = G.state, p = G.provinces[prov];
    if (!p || p.sea || !p.seaZones.length) return { ok: false, msg: 'Not a coastal province' };
    const o = st.owners[prov];
    if (o === owner || G.allied(o, owner) || G.hasTreaty('access', o, owner)) return { ok: true, invade: false };
    if (G.atWar(owner, o)) return { ok: true, invade: true };
    return { ok: false, msg: 'Declare war on ' + cname(o) + ' first' };
  };
  // Land every army on board at a coastal province next to the fleet's zone.
  G.landFleet = function (f, prov) {
    const p = G.provinces[prov];
    if (!isZone(f.loc) || !p || !p.seaZones || !p.seaZones.includes(f.loc)) return { ok: false, msg: 'The fleet must be in a sea zone touching that coast' };
    if (!f.cargo.length) return { ok: false, msg: 'No armies on board' };
    const chk = G.landingCheck(f.owner, prov); if (!chk.ok) return chk;
    const day = G.state.day;
    f.cargo.slice().forEach(a => {
      disembark(f, a, prov);
      if (chk.invade) {
        a.landing = { until: day + 8 };
        a.units.forEach(u => { u.org = Math.max(G.UNITS[u.type].org * 0.3, u.org * 0.75); u.morale = Math.max(10, u.morale - 5); });
      }
    });
    if (f.owner === G.state.player) G.logMsg('Landing at ' + p.name + (chk.invade ? ' — amphibious assault' : ''));
    G.onLanding && G.onLanding(f, prov, chk.invade);
    return { ok: true, invade: chk.invade };
  };
  // One-click: an army in a port boards a docked transport fleet and sails to a coastal destination.
  G.orderAmphibious = function (a, dest) {
    const st = G.state;
    if (!a.units.length) return { ok: false, msg: 'Army has no units' };
    if (G.inBattle(a)) return { ok: false, msg: 'Army is engaged in battle' };
    if (a.path.length) return { ok: false, msg: 'Stop the army first' };
    const P = G.provinces[a.prov];
    if (!P.seaZones.length) return { ok: false, msg: 'The army is not in a port province' };
    if (!G.canDock(a.owner, a.prov)) return { ok: false, msg: 'The army must stand in a friendly port province' };
    if (dest === a.prov) return { ok: false, msg: 'Already there' };
    const chk = G.landingCheck(a.owner, dest); if (!chk.ok) return chk;
    const cands = G.fleetsDockedAt(a.prov).filter(f => f.owner === a.owner && G.fleetSummary(f).free >= a.units.length).sort((x, y) => G.fleetSummary(y).free - G.fleetSummary(x).free);
    if (!cands.length) return { ok: false, msg: 'No transport fleet docked here with room for ' + a.units.length + ' units (each Transport carries ' + G.CARGO_PER_TRANSPORT + ')' };
    const f = cands[0];
    const D = G.provinces[dest];
    const goal = chk.invade || !G.canDock(a.owner, dest) ? (n => isZone(n) && D.seaZones.includes(n)) : (n => n === dest);
    const path = G.navalPath(f, f.loc, goal);
    if (!path) return { ok: false, msg: 'No sea route to ' + D.name };
    const r = G.loadArmy(f, a); if (!r.ok) return r;
    f.mission = { type: 'land', dest: dest, invade: chk.invade };
    f.path = path; f.goal = path[path.length - 1]; f.progress = 0; f.legDays = G.navalLegDays(f, f.loc, path[0]);
    return { ok: true, eta: G.fleetEta(f), fleet: f };
  };
  function arrive(f) {
    const st = G.state, m = f.mission; f.mission = null;
    if (m && m.type === 'land' && f.cargo.length) {
      if (typeof f.loc === 'number') { G.unloadAll(f); }
      else {
        const r = G.landFleet(f, m.dest);
        if (!r.ok) { G.returnHome(f); if (f.owner === st.player) G.toast && G.toast(f.name + ': landing aborted — ' + r.msg); }
      }
    } else if (typeof f.loc === 'number' && f.cargo.length && G.canDock(f.owner, f.loc)) {
      /* cargo stays aboard until the player unloads */
    }
    if (f.owner === st.player) G.onFleetArrive && G.onFleetArrive(f);
  }
  G.nearestPort = function (f) {
    let best = null, bl = 1e9;
    const start = f.path.length && f.progress > 0 ? f.path[0] : f.loc;
    const path = G.navalPath(f, start, n => !isZone(n) && n !== start && G.canDock(f.owner, n) && !G.provinces[n].sea);
    return path;
  };
  G.returnHome = function (f) {
    const path = G.nearestPort(f);
    if (!path || !path.length) return false;
    f.path = path; f.progress = 0; f.legDays = G.navalLegDays(f, f.loc, path[0]); f.goal = path[path.length - 1]; f.mission = { type: 'unload' };
    return true;
  };

  /* ---------- naval combat ---------- */
  function sidesAt(zone) {
    const here = G.stationary(zone);
    if (here.length < 2) return null;
    const A = [here[0]], B = [];
    const hostileToA = f => A.some(x => G.atWar(x.owner, f.owner));
    const friendA = f => A.some(x => x.owner === f.owner || G.allied(x.owner, f.owner));
    for (const f of here.slice(1)) { if (friendA(f)) A.push(f); else if (hostileToA(f)) B.push(f); }
    // fleets allied with B but not at war with A's first element also fight when A hostile to them
    if (!B.length) return null;
    const armed = A.concat(B).some(f => f.ships.some(s => G.SHIPS[s.type].atk > 0));
    return armed ? { zone: zone, A: A, B: B } : null;
  }
  G.navalBattleOf = function (f) { return isZone(f.loc) && !(f.progress > 0) ? (() => { const b = sidesAt(f.loc); return b && (b.A.includes(f) || b.B.includes(f)) ? b : null; })() : null; };
  G.activeNavalBattles = function () {
    const out = [], seen = {};
    for (const f of G.state.fleets) if (isZone(f.loc) && !seen[f.loc]) { seen[f.loc] = true; const b = sidesAt(f.loc); if (b) out.push(b); }
    return out;
  };
  function sideShips(side) { const a = []; side.forEach(f => f.ships.forEach(s => a.push({ f: f, s: s }))); return a; }
  function sideFire(side, enemy) {
    const enemyHasDD = enemy.some(f => f.ships.some(s => s.type === 'destroyer'));
    let fire = 0;
    for (const f of side) {
      const m = navAtk(f.owner);
      for (const s of f.ships) { const d = G.SHIPS[s.type]; fire += d.atk * s.hp * m * (s.type === 'submarine' && !enemyHasDD ? 1.5 : 1); }
    }
    return fire;
  }
  function applyDamage(side, enemy, dmg) {
    const ships = sideShips(side); if (!ships.length) return 0;
    const enemyASW = enemy.reduce((x, f) => x + G.techEff(f.owner, 'asw'), 0) / Math.max(1, enemy.length);
    const enemyHasDD = enemy.some(f => f.ships.some(s => s.type === 'destroyer'));
    const w = ships.map(x => x.s.type === 'submarine' ? (enemyHasDD ? 1.0 + enemyASW : 0.35) : x.s.type === 'transport' ? 1.4 : 1);
    const tot = w.reduce((a, b) => a + b, 0);
    let sunk = 0;
    ships.forEach((x, i) => { x.s.hp -= (dmg * w[i] / tot) / dur(x.s, x.f.owner); });
    for (const f of side) {
      const before = f.ships.length;
      f.ships = f.ships.filter(s => s.hp > 0.03);
      sunk += before - f.ships.length;
      const cap = f.ships.filter(s => G.SHIPS[s.type].cargo).length * G.CARGO_PER_TRANSPORT;
      let used = f.cargo.reduce((x, a) => x + a.units.length, 0);
      while (used > cap && f.cargo.length) { const a = f.cargo[f.cargo.length - 1]; used -= a.units.length; G.loseCargoArmy(f, a, 'transport sunk'); }
    }
    return sunk;
  }
  function retreatFleet(f) {
    const path = G.nearestPort(f);
    if (!path || !path.length) { G.removeFleet(f, 'no port to retreat to'); return false; }
    f.loc = path.shift(); f.path = path; f.progress = 0; f.mission = null; f.goal = path.length ? path[path.length - 1] : null;
    if (path.length) f.legDays = G.navalLegDays(f, f.loc, path[0]); else if (typeof f.loc === 'number') arrive(f);
    return true;
  }
  function navalCombatDay() {
    const st = G.state;
    for (const b of G.activeNavalBattles()) {
      const jit = () => 0.9 + G.rand() * 0.2;
      const fa = sideFire(b.A, b.B) * jit(), fb = sideFire(b.B, b.A) * jit();
      const sb = applyDamage(b.B, b.A, fa * 1.2), sa = applyDamage(b.A, b.B, fb * 1.2);
      const rec = st.navalRec[b.zone] = st.navalRec[b.zone] || { days: 0, sa: 0, sb: 0 };
      rec.days++; rec.sa += sa; rec.sb += sb;
      const A = b.A.filter(f => st.fleets.includes(f)), B = b.B.filter(f => st.fleets.includes(f));
      b.A.concat(b.B).forEach(f => { if (!f.ships.length && st.fleets.includes(f)) G.removeFleet(f, 'fleet destroyed'); });
      const shA = A.reduce((n, f) => n + f.ships.length, 0), shB = B.reduce((n, f) => n + f.ships.length, 0);
      const hpA = warHp(sideShips(A).map(x => x.s)), hpB = warHp(sideShips(B).map(x => x.s));
      const aBroken = !shA || hpA < BREAK_HP, bBroken = !shB || hpB < BREAK_HP;
      if (!aBroken && !bBroken) continue;
      const aLoses = aBroken && (!bBroken || hpA <= hpB);
      const loserFleets = aLoses ? A : B, winnerFleets = aLoses ? B : A;
      const lo = (loserFleets[0] || (aLoses ? b.A[0] : b.B[0])).owner, wo = (winnerFleets[0] || (aLoses ? b.B[0] : b.A[0])).owner;
      loserFleets.forEach(f => { if (st.fleets.includes(f)) retreatFleet(f); });
      const msg = 'Naval battle in ' + G.zoneById[b.zone].name + ': ' + cname(wo) + ' defeated ' + cname(lo) + ' (ships lost ' + (aLoses ? rec.sb : rec.sa) + ' vs ' + (aLoses ? rec.sa : rec.sb) + ')';
      delete st.navalRec[b.zone];
      G.logMsg(msg);
      if (wo === st.player || lo === st.player) G.onNavalBattleEnd && G.onNavalBattleEnd(b.zone, wo, lo, msg);
    }
  }

  /* ---------- zone control, blockades, naval gunfire ---------- */
  G.recomputeBlockades = function () {
    const st = G.state; if (!st || !st.fleets || !G.provinces) return;
    const zf = {}, dock = {};
    for (const f of st.fleets) {
      if (f.progress > 0) continue;
      const fire = G.fleetFire(f, true); if (fire <= 0) continue;
      if (isZone(f.loc)) { const m = zf[f.loc] = zf[f.loc] || {}; m[f.owner] = (m[f.owner] || 0) + fire; }
      else { const m = dock[f.loc] = dock[f.loc] || {}; m[f.owner] = (m[f.owner] || 0) + fire; }
    }
    const bl = {};
    for (const p of G.provinces) {
      if (p.sea || !p.seaZones || !p.seaZones.length) continue;
      const o = st.owners[p.id]; if (!o) continue;
      let sum = 0;
      for (const z of p.seaZones) {
        const m = zf[z] || {}; let enemy = 0, friend = 0;
        for (const ow in m) { if (ow === o || G.allied(ow, o)) friend += m[ow]; else if (G.atWar(ow, o)) enemy += m[ow]; }
        const d = dock[p.id]; if (d) for (const ow in d) if (ow === o || G.allied(ow, o)) friend += 0.5 * d[ow];
        if (enemy >= 5) sum += enemy / (enemy + friend);
      }
      const lvl = sum / p.seaZones.length;
      if (lvl > 0.05) bl[p.id] = lvl;
    }
    G._bl = bl; G._zf = zf;
  };
  G.blockadeLevel = function (prov) { return (G._bl && G._bl[prov]) || 0; };
  G.blockadeShare = function (id) {
    if (!G._bl) return 0;
    let n = 0, sum = 0;
    for (const p of G.provinces) {
      if (p.sea || !p.seaZones || !p.seaZones.length || G.state.owners[p.id] !== id) continue;
      n++; sum += G._bl[p.id] || 0;
    }
    return n ? Math.min(1, (sum / n) * (1 - Math.min(0.8, G.techEff(id, 'convoy')))) : 0;
  };
  G.zoneDominant = function (zid) {
    const m = G._zf && G._zf[zid]; if (!m) return null;
    let best = null, bf = 0, second = 0;
    for (const o in m) { if (m[o] > bf) { second = bf; bf = m[o]; best = o; } else if (m[o] > second) second = m[o]; }
    return best && bf >= 5 && bf >= 1.4 * second ? best : null;
  };
  G.zoneFireOf = function (zid, owner, withAllies) {
    const m = G._zf && G._zf[zid]; if (!m) return 0;
    let s = 0; for (const o in m) if (o === owner || (withAllies && G.allied(o, owner))) s += m[o];
    return s;
  };
  G.seaSupply = function (a) {
    const p = G.provinces[a.prov]; if (!p || !p.seaZones || !p.seaZones.length) return false;
    return p.seaZones.some(z => { const own = G.zoneFireOf(z, a.owner, true); let foe = 0; const m = G._zf && G._zf[z]; if (m) for (const o in m) if (G.atWar(o, a.owner)) foe += m[o]; return own >= 5 && own > foe; });
  };
  G.navalSupportFire = function (owner, prov) {
    const p = G.provinces[prov]; if (!p || !p.seaZones) return 0;
    let s = 0;
    for (const z of p.seaZones) for (const f of G.stationary(z)) {
      if (!(f.owner === owner || G.allied(f.owner, owner))) continue;
      for (const sh of f.ships) s += G.SHIPS[sh.type].atk * sh.hp * G.SHIPS[sh.type].bomb;
    }
    return s * 0.6;
  };

  /* ---------- visibility ---------- */
  G.canSeeFleet = function (f) {
    const st = G.state, me = st.player;
    if (!me || f.owner === me || G.allied(f.owner, me)) return true;
    if (G.intelLevel && G.intelLevel(me, f.owner) >= 50) return true;
    const near = isZone(f.loc) ? [f.loc].concat(G.zoneById[f.loc].adj) : G.provinces[f.loc].seaZones;
    if (isZone(f.loc)) {
      const z = G.zoneById[f.loc];
      if (z.ports.some(p => { const o = st.owners[p]; return o === me || G.allied(o, me); })) return true;
    } else if (G.canSee && G.canSee({ owner: f.owner, prov: f.loc, path: [] })) return true;
    return st.fleets.some(x => (x.owner === me || G.allied(x.owner, me)) && near.includes(x.loc));
  };

  /* ---------- shipbuilding ---------- */
  G.shipCost = function (type) { return G.SHIPS[type]; };
  G.canBuildShip = function (owner, type, prov) {
    const st = G.state, d = G.SHIPS[type], c = st.countries[owner];
    if (!d) return { ok: false, msg: 'Unknown ship' };
    const p = G.provinces[prov];
    if (prov == null || !p || p.sea || st.owners[prov] !== owner) return { ok: false, msg: 'Choose one of your ports' };
    if (!p.seaZones.length) return { ok: false, msg: 'Not a port' };
    const b = st.pb[prov];
    if (!b.dock) return { ok: false, msg: 'Needs a Shipyard (build one in 🏭 Industry)' };
    if (!b.port) return { ok: false, msg: 'Needs a Port' };
    if (G.blockadeLevel(prov) > 0.6) return { ok: false, msg: 'Port is blockaded' };
    if (st.shipQ[owner].length >= G.NAVAL_QUEUE_MAX) return { ok: false, msg: 'Shipbuilding queue is full' };
    if (c.treasury < d.gold) return { ok: false, msg: 'Not enough gold' };
    if (c.res.steel < d.steel) return { ok: false, msg: 'Not enough steel' };
    if (c.res.oil < d.oil) return { ok: false, msg: 'Not enough oil' };
    return { ok: true };
  };
  G.buildShip = function (owner, type, prov) {
    const chk = G.canBuildShip(owner, type, prov); if (!chk.ok) return chk;
    const st = G.state, d = G.SHIPS[type], c = st.countries[owner];
    c.treasury -= d.gold; c.res.steel -= d.steel; c.res.oil -= d.oil;
    const it = { id: st.nextFid++, type: type, prov: prov, left: d.days, total: d.days };
    st.shipQ[owner].push(it);
    return { ok: true, item: it };
  };
  function refundShip(owner, it) { const d = G.SHIPS[it.type], c = G.state.countries[owner]; c.treasury += d.gold; c.res.steel += d.steel; c.res.oil += d.oil; }
  G.cancelShip = function (owner, id) {
    const q = G.state.shipQ[owner], i = q.findIndex(x => x.id === id); if (i < 0) return false;
    refundShip(owner, q[i]); q.splice(i, 1); return true;
  };
  G.shipyardSlots = function (prov) { const b = G.state.pb[prov]; return b ? b.dock : 0; };
  function commission(owner, it) {
    const st = G.state, d = G.SHIPS[it.type], war = d.cargo === 0;
    let f = st.fleets.find(x => x.owner === owner && x.loc === it.prov && !x.path.length && x.ships.length < G.FLEET_MAX_SHIPS && (war ? x.ships.some(s => G.SHIPS[s.type].atk > 0) || !x.ships.length : x.ships.every(s => G.SHIPS[s.type].cargo)));
    if (!f) f = G.createFleet(owner, it.prov, []);
    f.ships.push({ type: it.type, hp: 1 });
    if (owner === st.player) { G.logMsg(d.name + ' commissioned at ' + G.provinces[it.prov].name + ' (' + f.name + ')'); G.onShipBuilt && G.onShipBuilt(f, it); }
  }
  function shipyardDay() {
    const st = G.state;
    for (const id in st.shipQ) {
      const q = st.shipQ[id], used = {};
      for (let i = 0; i < q.length;) {
        const it = q[i];
        if (st.owners[it.prov] !== id) { refundShip(id, it); q.splice(i, 1); continue; }
        const b = st.pb[it.prov], slots = b.dock;
        used[it.prov] = used[it.prov] || 0;
        if (used[it.prov] < slots && G.blockadeLevel(it.prov) < 0.6) {
          used[it.prov]++;
          it.left -= 1 + 0.25 * Math.max(0, b.port - 1) + G.techEff(id, 'construction') * 0.5;
          if (it.left <= 0) { q.splice(i, 1); commission(id, it); continue; }
        }
        i++;
      }
    }
  }

  /* ---------- upkeep, repairs, housekeeping ---------- */
  const SHIP_UPKEEP = 0.01;
  G.navalCensus = function (men, upkeep) {
    for (const f of (G.state.fleets || [])) {
      for (const s of f.ships) upkeep[f.owner] = (upkeep[f.owner] || 0) + G.SHIPS[s.type].gold * SHIP_UPKEEP;
      for (const a of f.cargo) for (const u of a.units) { men[f.owner] = (men[f.owner] || 0) + u.men; upkeep[f.owner] = (upkeep[f.owner] || 0) + G.UNITS[u.type].gold * 0.01; }
    }
  };
  function repairDay() {
    const st = G.state;
    for (const f of st.fleets) {
      if (typeof f.loc !== 'number' || f.path.length || !G.canDock(f.owner, f.loc)) continue;
      if (G.blockadeLevel(f.loc) > 0.6) continue;
      const lvl = Math.max(1, (st.pb[f.loc] && st.pb[f.loc].port) || 1), c = st.countries[f.owner];
      for (const s of f.ships) if (s.hp < 1) { s.hp = Math.min(1, s.hp + 0.03 * (1 + 0.25 * (lvl - 1))); c.treasury -= 0.3; }
      // armies on board keep their organisation up in port
    }
    for (const f of st.fleets) for (const a of f.cargo) a.units.forEach(u => { const d = G.UNITS[u.type]; u.org = Math.min(d.org, u.org + 0.5); });
  }
  function housekeeping() {
    const st = G.state;
    for (const f of st.fleets.slice()) {
      if (typeof f.loc === 'number' && !f.path.length && !G.canDock(f.owner, f.loc)) {      // no longer welcome in this port
        const z = G.provinces[f.loc].seaZones[0];
        if (z) { f.loc = z; f.mission = null; if (f.owner === st.player) G.toast && G.toast(f.name + ' put to sea — no longer welcome in port'); }
      }
      if (f.cargo.length) f.cargo.forEach(a => { if (a.landing && a.landing.until < st.day) a.landing = null; });
    }
    for (const a of st.armies) if (a.landing && a.landing.until < st.day) a.landing = null;
  }
  G.navalDay = function () {
    shipyardDay();
    moveFleets();
    navalCombatDay();
    repairDay();
    housekeeping();
    G.recomputeBlockades();
    G.navalAIDay && G.navalAIDay();
  };

  /* ---------- hooks used by war.js / combat.js ---------- */
  G.navalEliminate = function (id) {
    const st = G.state;
    st.fleets.filter(f => f.owner === id).forEach(f => G.removeFleet(f, 'nation eliminated'));
    st.shipQ[id] = [];
    G.recomputeBlockades();
  };
  G.navalPortLost = function (prov, old) {
    const st = G.state;
    (st.shipQ[old] || []).filter(it => it.prov === prov).forEach(it => G.cancelShip(old, it.id));
    st.fleets.filter(f => f.loc === prov && f.owner === old).forEach(f => {
      const z = G.provinces[prov].seaZones[0];
      if (z) { f.loc = z; f.path = []; f.progress = 0; f.mission = null; } else G.removeFleet(f, 'port captured');
    });
    G.recomputeBlockades();
  };
  G.navalPower = function (id) {
    let p = 0; for (const f of G.state.fleets) if (f.owner === id) p += G.fleetFire(f);
    return p;
  };
  G.navalShips = function (id) { let n = 0; for (const f of G.state.fleets) if (f.owner === id) n += f.ships.length; return n; };
})(window.EMP = window.EMP || {});
