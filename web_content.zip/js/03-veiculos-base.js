/* Veiculos: tanque base e primeiros modelos */
/* ---------- tanques ---------- */
const tanks=[];
function bx(w,h,d,m,x,y,z){const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);o.position.set(x,y,z);return o}
function treadTex(vert){
  const c=document.createElement('canvas');c.width=c.height=16;const x=c.getContext('2d');
  x.fillStyle='#1d1e1b';x.fillRect(0,0,16,16);x.fillStyle='#4b4c46';if(vert)x.fillRect(0,0,3,16);else x.fillRect(0,0,16,3);
  const t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;return t;
}
const wheelG=new THREE.CylinderGeometry(.4,.4,.15,10).rotateZ(Math.PI/2),v2=new THREE.Vector3();
const tkT=canvasTex(128,128,(x,w,h)=>{x.fillStyle='#fff';x.fillRect(0,0,w,h);const cs=['#e2e6d2','#c4cba8','#aab38c'];for(let i=0;i<30;i++){x.fillStyle=cs[i%3];x.beginPath();x.ellipse(Math.random()*w,Math.random()*h,8+Math.random()*20,4+Math.random()*9,Math.random()*3,0,7);x.fill()}});
function makeTank(color,fc){
  const{dark,lamp,brkM,flagM,flashM,cm,hm,sk,gl}=mm(fc||(color===0x5b6b3a?0xffb000:0xd6452f)),mat=mat0(color,tkT),g=new THREE.Group(),wheels=[],DK=0x2b2d28,MT=0x4a4b42,RB=0x1b1b1a,GL=0x2a4a5c,OD=0x4f5a34;
  g.rotation.order='YXZ';
  /* esteiras animadas, rodas de apoio, roda motriz (frente) e guia (traseira) */
  const sideT=treadTex(true),topT=treadTex(false);sideT.repeat.set(8,1);topT.repeat.set(1,8);
  const sM=new THREE.MeshLambertMaterial({map:sideT}),tM=new THREE.MeshLambertMaterial({map:topT}),trk=[sM,sM,tM,dark,dark,dark];
  for(const s of[-1,1]){
    g.add(new THREE.Mesh(new THREE.BoxGeometry(.9,1,6.8),trk).translateX(s*1.95).translateY(.55));
    for(let i=0;i<5;i++){const w=new THREE.Mesh(abG.w,vcM);w.position.set(s*2.42,.55,-2+i);w.userData={r:.44,b:1};g.add(w);wheels.push(w)}
    const sp=new THREE.Mesh(abG.s,vcM),id=new THREE.Mesh(abG.i,vcM);sp.position.set(s*2.42,.58,3.05);id.position.set(s*2.42,.58,-3.05);sp.userData={r:.5};id.userData={r:.46};g.add(sp,id);wheels.push(sp,id);
  }
  /* casco: glacis inclinado, para-lamas, grade do motor, escapamentos, estivagem */
  const hull=new THREE.Group(),H=mb();
  H.b(3,.7,5.8,'M',0,.95,0);H.b(2.8,.18,6,DK,0,.58,0);H.b(3.2,.34,3.4,'M',0,1.42,-.7);H.b(3,.16,1.6,'M',0,1.3,2.25,.52);H.b(3,.55,.12,'M',0,.7,2.95,-.4);H.b(3.1,.8,.14,'M',0,1.05,-2.95);
  H.b(2.6,.1,2,'M',0,1.62,-1.75);for(let k=0;k<6;k++)H.b(2,.03,.07,DK,0,1.68,-2.7+k*.17);
  H.b(.5,.24,.5,'M',-.8,1.56,2.1,.35);H.b(.3,.05,.05,GL,-.8,1.6,2.34);H.c(.07,.07,.04,DK,.8,1.28,2.5,'z');H.b(.05,.05,.5,DK,.8,1.2,2.72,.52);H.c(.12,.14,.15,DK,-1.2,1.65,-2.7,'y');
  H.b(.28,.4,.2,OD,-1.15,1.82,-2.55);H.b(.28,.4,.2,OD,-.8,1.82,-2.55);H.c(.25,.25,.7,MT,1.05,1.85,-2.55,'z');
  for(const s of[-1,1]){
    H.b(1.15,.07,6,'M',s*1.95,1.22,0);H.b(1.15,.06,.9,'M',s*1.95,1.3,3.25,-.2);H.b(1,.35,.05,RB,s*1.95,1.2,3.7);H.b(1,.3,.05,RB,s*1.95,1.05,-3.03);
    for(let k=0;k<3;k++)H.c(.1,.1,.2,MT,s*2.4,1.12,-1.6+k*1.6,'x');
    H.b(.5,.28,.9,DK,s*1.95,1.4,-1.8);H.b(.9,.12,.5,MT,s*1.95,1.31,.7);H.b(.06,.06,2.6,MT,s*1.4,1.62,-.5);H.c(.14,.16,.7,DK,s*.9,1.1,-3.15,'z');H.b(.36,.3,.5,MT,s*.9,1.1,-2.95);
    hull.add(bx(.3,.2,.1,lamp,s*1.2,.85,3.04),bx(.3,.2,.08,brkM,s*1.1,1.1,-3.05));
  }
  H.out(hull,mat);g.add(hull);const ant=mkAnt(hull,-1.2,1.65,-2.7,flagM);
  /* torre fundida: cheeks, bustle com cesto, cupula com periscopios, lancadores de fumaca */
  const tg=new THREE.Group(),T=mb();tg.position.set(0,1.58,-.3);
  T.c(1.32,1.32,.14,'M',0,.07,0,'y');T.c(1.15,1.4,.5,'M',0,.4,0,'y');T.c(.9,1.15,.2,'M',0,.75,0,'y');T.b(2,.08,1.7,'M',0,.84,.1);
  T.b(2.2,.55,1.3,'M',0,.42,-1.45);T.b(2,.1,1.1,'M',0,.72,-1.45,-.1);T.b(2.3,.3,.4,DK,0,.33,-2.2);T.b(2.3,.05,.05,MT,0,.55,-2.2);T.b(.5,.35,.3,OD,-.7,.5,-2.3);T.b(.5,.3,.3,0x6f6a4c,.6,.48,-2.3);
  for(const s of[-1,1]){T.b(.5,.55,1,'M',s*.75,.42,1,0,s*.45);for(let k=0;k<3;k++)T.c(.05,.05,.3,MT,s*1.3,.62,.1+k*.15,'y',0,0,-s*.6)}
  T.c(.42,.46,.2,MT,.6,.88,-.35,'y');for(let k=0;k<6;k++){const a=k/6*6.283;T.b(.12,.08,.06,GL,.6+Math.sin(a)*.43,.97,-.35+Math.cos(a)*.43,0,a)}
  T.c(.4,.42,.1,MT,-.6,.9,-.5,'y');T.b(.4,.25,.35,DK,-.45,.95,.8);T.b(.25,.1,.04,GL,-.45,.97,.98);
  T.out(tg,mat);
  const cl=mkLid(tg,mat,.6,.99,-.35,.36),ll=mkLid(tg,mat,-.6,.96,-.5,.34),crew=mkCrew(tg,cm,hm,sk,.6,.65,-.35),cmg=mkMG(tg,-.1,.88,-.95);
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb(),K=mb();bp.position.set(0,.5,1.7);
  B.b(1.3,.7,.35,'M',0,0,.2);B.c(.26,.3,.3,RB,0,0,.45,'z');B.c(.04,.04,.9,DK,.36,-.02,.7,'z');B.b(.25,.2,.06,GL,-.5,.12,.4);B.out(bp,mat);
  K.c(.13,.13,4.7,DK,0,0,2.55,'z');K.c(.19,.19,1.6,'M',0,0,1.3,'z');K.c(.22,.22,.5,'M',0,0,3.1,'z');for(const z of[.8,1.4,2])K.c(.21,.21,.07,DK,0,0,z,'z');
  K.c(.19,.19,.55,DK,0,0,4.75,'z');K.b(.5,.1,.3,DK,0,0,4.75);K.out(bar,mat);
  const fl=mkFl(bar,5.3,.45,flashM);bp.add(bar);tg.add(bp);g.add(tg);
  return fin(base({g,tg,bp,bar,hull,ant,lid:[cl,ll],crew,cmg,fl,brkM,wheels,sideT,topT,mat,dark,tnk:true,cannon:true,fk:1,rld:1.8,L:3,W:2,mz:5,TY:1.58}));
}
function animTK(t,dt){
  const now=performance.now()/1000;t.clk+=dt;if(t.dead)return blowOff(t,dt,t.TY);
  const th=clamp(Math.abs(t.v)/11,0,1),ph=t.v*dt,ac=(t.v-t.pv)/Math.max(dt,.001);t.phase+=ph;t.sideT.offset.x=t.phase/.75;t.topT.offset.y=t.phase/.75;
  t.wheels.forEach((w,i)=>{w.rotation.x+=ph/w.userData.r;if(w.userData.b)w.position.y=.55+Math.sin(now*11+i*1.7)*.02*th});
  /* casco "suspenso": empina ao acelerar, mergulha ao frear, inclina nas curvas e no recuo */
  t.pt=(t.pt||0)+(clamp(-ac*.0035,-.05,.05)-(t.pt||0))*Math.min(1,dt*5);t.rl=(t.rl||0)+(clamp((t.st||0)*t.v*.0016,-.04,.04)-(t.rl||0))*Math.min(1,dt*4);
  t.hull.position.y=Math.sin(now*30+t.x)*.01*(.4+th)-t.recoil*.03;t.hull.rotation.x=t.pt-t.recoil*.025;t.hull.rotation.z=t.rl;
  t.ant.rotation.x=-t.v*.012+Math.sin(now*3+t.z)*.03;t.ant.rotation.z=Math.sin(now*2.2+t.x)*.03;
  tankFx(t,dt,now,th*.4,{ex:[[.9,1.1,-3.3],[-.9,1.1,-3.3]],dk:[[1.95,.2,-3.5],[-1.95,.2,-3.5]],mz:5,rr:1.3,rc:.85});
  mgScan(t,dt,55);mgAim(t,dt,t.cmg,t.yaw,.5,[0,.1,1.45],now);smokeQ(t,dt,1.3,.62,.3);
}
/* ---------- ASTROS II (Avibras, 6x6) ---------- */
function canvasTex(w,h,fn){const c=document.createElement('canvas');c.width=w;c.height=h;fn(c.getContext('2d'),w,h);return new THREE.CanvasTexture(c)}
const flagT=canvasTex(128,88,(x,w,h)=>{x.fillStyle='#1b8f3a';x.fillRect(0,0,w,h);x.fillStyle='#f5d400';x.beginPath();x.moveTo(w/2,8);x.lineTo(w-10,h/2);x.lineTo(w/2,h-8);x.lineTo(10,h/2);x.closePath();x.fill();x.fillStyle='#1a3f9c';x.beginPath();x.arc(w/2,h/2,19,0,7);x.fill()});
const nameT=canvasTex(256,64,(x,w,h)=>{x.fillStyle='#f3ecd8';x.font='700 46px Arial,sans-serif';x.textAlign='center';x.textBaseline='middle';x.fillText('ASTROS II',w/2,h/2+2)});
const tireG=new THREE.CylinderGeometry(.62,.62,.5,16).rotateZ(Math.PI/2),hubG=new THREE.CylinderGeometry(.34,.34,.54,10).rotateZ(Math.PI/2),
  noseG=new THREE.ConeGeometry(.12,.38,10).rotateX(Math.PI/2),ringG=new THREE.TorusGeometry(.15,.028,6,14),
  rkBody=new THREE.CylinderGeometry(.1,.1,1.6,8).rotateX(Math.PI/2),rkNose=new THREE.ConeGeometry(.1,.4,8).rotateX(Math.PI/2),
  rkMat=new THREE.MeshLambertMaterial({color:0xd9d2b8}),rkTip=new THREE.MeshLambertMaterial({color:0xd9552a}),rkFlame=new THREE.MeshBasicMaterial({color:0xffa83a}),rkFlameG=new THREE.SphereGeometry(.22,6,5);
function makeAstros(color,fc){
  const g=new THREE.Group(),mat=new THREE.MeshLambertMaterial({color:color||0x56613a}),dark=new THREE.MeshLambertMaterial({color:0x2b2d28}),metal=new THREE.MeshLambertMaterial({color:0x3f423a}),
    glass=new THREE.MeshLambertMaterial({color:0x2a4a5c,emissive:0x0a1a24}),lamp=new THREE.MeshBasicMaterial({color:0xfff2b0}),tire=new THREE.MeshLambertMaterial({color:0x1b1b1a}),
    flagM=new THREE.MeshBasicMaterial({color:fc||0xffb000,side:THREE.DoubleSide}),decal=new THREE.MeshBasicMaterial({map:flagT}),nameM=new THREE.MeshBasicMaterial({map:nameT,transparent:true}),
    wheels=[],steers=[],jacks=[],tubes=[];
  g.rotation.order='YXZ';
  const hull=new THREE.Group(),ws=bx(2,.6,.06,glass,0,2.62,3.62);ws.rotation.x=-.25;
  hull.add(bx(2.5,.25,6.2,mat,0,1.4,-.95),bx(.3,.3,8,dark,-.6,1.15,-.2),bx(.3,.3,8,dark,.6,1.15,-.2),
    bx(2.4,1,1.8,mat,0,1.8,3.1),bx(2.2,.7,1.5,mat,0,2.65,2.85),ws,bx(2.6,.3,.3,dark,0,1.1,4.1),bx(1.6,.5,.05,dark,0,1.65,4.02),
    bx(.35,.25,.08,lamp,-.9,1.7,4.03),bx(.35,.25,.08,lamp,.9,1.7,4.03),bx(.9,.12,.9,metal,0,3.05,2.8),
    new THREE.Mesh(new THREE.CylinderGeometry(1.15,1.25,.3,16),metal).translateY(1.6).translateZ(-1.4));
  const beacon=new THREE.Mesh(new THREE.CylinderGeometry(.12,.12,.2,8),new THREE.MeshBasicMaterial({color:0xffa020}));beacon.position.set(-.6,3.18,2.6);hull.add(beacon);
  for(const s of[-1,1]){
    hull.add(bx(.05,.5,1,glass,s*1.12,2.65,2.85),bx(.08,.3,.2,dark,s*1.4,2.5,3.5),bx(.3,.06,.5,metal,s*1.3,.95,3),bx(.8,.1,1.7,mat,s*1.4,1.45,2.9),bx(.8,.1,1.7,mat,s*1.4,1.45,-1.9),bx(.8,.1,1.7,mat,s*1.4,1.45,-3.3),
      bx(.5,.45,.8,metal,s*1.15,1.0,-.8),bx(.35,.4,.35,dark,s*1.4,1.4,-3.95));
    const ft=new THREE.Mesh(new THREE.CylinderGeometry(.35,.35,1.6,12).rotateX(Math.PI/2),metal);ft.position.set(s*1.1,1.0,.5);hull.add(ft);
    const fl=new THREE.Mesh(new THREE.PlaneGeometry(.7,.48),decal);fl.position.set(s*1.21,1.85,3.0);fl.rotation.y=s*Math.PI/2;hull.add(fl);
    const jg=new THREE.Group();jg.position.set(s*1.4,.45,-3.95);
    const rod=new THREE.Mesh(new THREE.CylinderGeometry(.11,.11,1.1,8),metal);rod.position.y=.7;jg.add(rod,bx(.55,.1,.55,dark,0,.05,0));g.add(jg);jacks.push(jg);
  }
  const stack=new THREE.Mesh(new THREE.CylinderGeometry(.12,.12,1.4,8),dark);stack.position.set(1.15,2.6,1.9);hull.add(stack);
  const ant=new THREE.Group();ant.position.set(.9,3.1,2.3);
  const rd=new THREE.Mesh(new THREE.CylinderGeometry(.015,.03,3,5),dark);rd.position.y=1.5;
  const fg=new THREE.Mesh(new THREE.PlaneGeometry(.55,.32),flagM);fg.position.set(0,2.85,.28);fg.rotation.y=Math.PI/2;ant.add(rd,fg);hull.add(ant);
  /* seis rodas: eixo dianteiro esterça */
  for(const [z,front] of [[2.9,1],[-1.9,0],[-3.3,0]])for(const s of[-1,1]){
    const sg=new THREE.Group();sg.position.set(s*1.35,.62,z);
    const w=new THREE.Mesh(tireG,tire);w.add(new THREE.Mesh(hubG,metal),bx(.56,.7,.1,dark,0,0,0),bx(.56,.1,.7,dark,0,0,0));
    for(let k=0;k<8;k++){const a=k/8*Math.PI*2,b=bx(.5,.1,.18,dark,0,Math.sin(a)*.63,Math.cos(a)*.63);b.rotation.x=Math.PI/2-a;w.add(b)}
    sg.add(w);g.add(sg);wheels.push(w);if(front)steers.push(sg);
  }
  /* lançador de foguetes */
  const tg=new THREE.Group();tg.position.set(0,1.75,-1.4);tg.add(bx(1.4,.55,1.4,metal,0,.25,0));
  const bp=new THREE.Group();bp.position.set(0,.95,0);
  bp.add(bx(2.3,1.5,3.6,mat,0,0,1.7),bx(2.3,1.5,.12,dark,0,0,3.52),bx(2.4,.12,.2,dark,0,.8,.4),bx(2.4,.12,.2,dark,0,.8,1.7),bx(2.4,.12,.2,dark,0,.8,3));
  for(const s of[-1,1]){
    bp.add(bx(.2,.9,.9,metal,s*1.25,-.2,.3));
    const lb=new THREE.Mesh(new THREE.PlaneGeometry(1.8,.45),nameM);lb.position.set(s*1.16,.15,1.7);lb.rotation.y=s*Math.PI/2;bp.add(lb);
  }
  for(let r=0;r<4;r++)for(let c=0;c<4;c++){
    const x=-.75+c*.5,y=-.48+r*.32,rg=new THREE.Mesh(ringG,metal);rg.position.set(x,y,3.58);
    const nm=new THREE.Mesh(noseG,rkMat);nm.position.set(x,y,3.72);bp.add(rg,nm);tubes.push({mesh:nm,x,y});
  }
  tg.add(bp);g.add(hull,tg);g.traverse(o=>o.castShadow=true);scene.add(g);
  const t={g,tg,bp,hull,ant,mat,dark,wheels,steers,jacks,tubes,rl:[],astros:true,spd:.85,trn:.7,L:4,W:1.5,x:0,z:0,y:0,hd:0,v:0,yaw:0,pitch:.08,cd:0,hp:100,dead:false,recoil:0,salvo:0,sT:0,clk:0,dep:0,jt:0,st:0};
  tanks.push(t);return t;
}
function salvo(t){if(t.salvo>0)return;t.salvo=Math.min(6,t.tubes.filter(q=>q.mesh.visible).length);t.sT=0}
function launchOne(t){
  const u=t.tubes.find(q=>q.mesh.visible);if(!u)return;u.mesh.visible=false;t.rl.push({u,at:t.clk+3+t.rl.length*.35});
  v1.set(u.x,u.y,3.8);t.bp.localToWorld(v1);
  const d=dirOf(t.yaw+(Math.random()-.5)*.03,t.pitch+(Math.random()-.5)*.02);
  const m=new THREE.Group(),fl=new THREE.Mesh(rkFlameG,rkFlame),nz=new THREE.Mesh(rkNose,rkTip);nz.position.z=1;fl.position.z=-.9;fl.scale.z=2.5;
  m.add(new THREE.Mesh(rkBody,rkMat),nz,fl,bx(.5,.04,.3,dark0,0,0,-.7),bx(.04,.5,.3,dark0,0,0,-.7));
  m.position.copy(v1);scene.add(m);
  shells.push({m,v:d.multiplyScalar(SPEED*1.05),owner:t,age:0,k:.62,rk:true,tt:0});
  puff(v1,0xffe9a0,1,3,.3,.5);t.bp.localToWorld(v2.set(u.x,u.y,-.3));puff(v2,0xffd36b,1.4,5,.35,.5);puff(v2,0xcfc8b8,2,7,1.4,1);
  t.recoil=1;snd('rocket',.6*near(v1));
}
const dark0=new THREE.MeshLambertMaterial({color:0x2b2d28});
function animAstros(t,dt){
  t.clk+=dt;const now=performance.now()/1000;
  if(!t.dead){
    const ph=t.v*dt;for(const w of t.wheels)w.rotation.x+=ph/.62;
    for(const s of t.steers)s.rotation.y+=((t.st||0)*.45-s.rotation.y)*Math.min(1,dt*6);
    t.hull.position.y=Math.sin(now*26+t.x)*.01*(.4+Math.abs(t.v)/9)-t.recoil*.05;
    t.ant.rotation.x=-t.v*.012+Math.sin(now*3+t.z)*.03;
    t.ex=(t.ex||0)-dt;if(t.ex<=0){t.ex=.14+Math.random()*.1;t.g.localToWorld(v2.set(1.15,3.4,1.9));puff(v2,0x6e6a64,.5,1,.9,1.2)}
    if(t.salvo>0){t.sT-=dt;if(t.sT<=0){launchOne(t);t.sT=.14;t.salvo--;t.jt=3.2}}
    t.jt=Math.max(0,t.jt-dt);
    t.dep+=clamp(((t.salvo>0||t.jt>0)?1:0)-t.dep,-dt*1.2,dt*1.2);
    for(const j of t.jacks)j.position.y=(1-t.dep)*.45;
    for(let i=t.rl.length-1;i>=0;i--)if(t.clk>=t.rl[i].at){t.rl[i].u.mesh.visible=true;t.rl.splice(i,1)}
  }else{
    t.burn=(t.burn===undefined?25:t.burn)-dt;
    if(t.burn>0){t.bt=(t.bt||0)-dt;if(t.bt<=0){t.bt=.15;t.g.localToWorld(v2.set(0,3,0));puff(v2,Math.random()<.35?0xff8a2e:0x1f1e1c,1.4,1.5,2,3)}}
  }
  if(t.recoil>0){t.recoil=Math.max(0,t.recoil-dt*3);t.bp.position.z=-t.recoil*.35}
}
/* ---------- M270 MLRS (EUA): chassi lagarteado com cabine blindada e duas caixas de 6 foguetes ---------- */
function makeM270(color,fc){
  const g=new THREE.Group(),mat=new THREE.MeshLambertMaterial({color:color||0x6b6f4a}),dark=new THREE.MeshLambertMaterial({color:0x2b2d28}),metal=new THREE.MeshLambertMaterial({color:0x4a4b42}),
    glass=new THREE.MeshLambertMaterial({color:0x2a4a5c,emissive:0x0a1a24}),lamp=new THREE.MeshBasicMaterial({color:0xfff2b0}),rubber=new THREE.MeshLambertMaterial({color:0x1b1b1a}),
    flagM=new THREE.MeshBasicMaterial({color:fc||0xffb000,side:THREE.DoubleSide}),warn=new THREE.MeshBasicMaterial({color:0xffc400}),wheels=[];
  g.rotation.order='YXZ';const GX=1.5,hull=new THREE.Group();
  g.add(g.trk=trackLoop([[-3.2,.35],[2.6,.35],[3.5,.9],[3.6,1.35],[2.9,1.75],[-3.0,1.75],[-3.6,1.3],[-3.5,.7]],80,.7,[-GX,GX]));
  const wg=new THREE.CylinderGeometry(.34,.34,.32,14).rotateZ(Math.PI/2),hg=new THREE.CylinderGeometry(.16,.16,.36,8).rotateZ(Math.PI/2);
  for(const s of[-1,1]){
    [[2.9,.62,.34],[1.7,.58,.34],[.5,.58,.34],[-.7,.58,.34],[-1.9,.58,.34],[-3.0,.72,.38]].forEach(([z,y,r],i)=>{
      const w=new THREE.Mesh(wg,rubber);w.scale.set(1,r/.34,r/.34);w.add(new THREE.Mesh(hg,metal),bx(.38,.5,.06,dark,0,0,0));w.position.set(s*GX,y,z);w.userData={s:s<0?0:1,r};g.add(w);wheels.push(w)});
    for(const z of[1.1,-1.3])g.add(bx(.18,.2,.2,dark,s*GX,1.62,z));
    hull.add(bx(.12,.6,6.4,mat,s*1.85,1.05,-.2),bx(.2,.18,6.6,dark,s*1.85,1.45,-.2),bx(.06,.1,1.2,warn,s*1.92,1.1,-2.6),
      bx(.3,.3,.6,metal,s*1.1,1.15,-3.55),bx(.2,.2,.2,lamp,s*.9,1.35,4.02));
    hull.add(bx(.4,.5,.9,mat,s*1.45,2.9,2.9));
  }
  hull.add(bx(3.0,.9,7.2,mat,0,1.2,-.2),bx(2.8,.2,6.6,mat,0,1.75,-.3));
  const gl=bx(2.8,.7,.9,mat,0,1.2,3.9);gl.rotation.x=-.5;hull.add(gl,bx(2.9,.12,.2,dark,0,.7,4.15));
  /* cabine: blindagem soldada, vidro em cunha, escotilhas */
  hull.add(bx(2.6,1.3,2.2,mat,0,2.4,2.5),bx(2.5,.2,2.1,metal,0,3.1,2.5),bx(2.2,.5,.1,glass,.2,2.75,3.62),bx(.7,.5,.1,glass,-1.0,2.75,3.5),
    bx(.5,.5,.5,metal,.7,3.3,2.5),bx(.5,.08,.5,dark,.7,3.58,2.5),bx(1.2,.12,.12,dark,-.4,3.25,3.7));
  for(const s of[-1,1])hull.add(bx(.08,.55,.9,glass,s*1.32,2.75,3.0),bx(.1,.8,.1,dark,s*1.35,2.4,1.5));
  const lamps=new THREE.Mesh(new THREE.SphereGeometry(.09,8,6),new THREE.MeshBasicMaterial({color:0xffa020}));lamps.position.set(-.9,3.25,2.1);hull.add(lamps);
  /* compartimento do motor, grades e escapamento */
  hull.add(bx(2.6,.5,2.2,dark,0,2.0,-2.9),bx(2.2,.06,1.5,metal,0,2.28,-2.9));
  for(let i=0;i<6;i++)hull.add(bx(2.0,.04,.1,dark,0,2.32,-3.4+i*.28));
  const stack=new THREE.Mesh(new THREE.CylinderGeometry(.13,.13,.9,8),dark);stack.position.set(1.0,2.6,-3.4);hull.add(stack);
  const ant=new THREE.Group();ant.position.set(-1.0,3.2,1.8);
  const rd=new THREE.Mesh(new THREE.CylinderGeometry(.015,.03,3.4,5),dark);rd.position.y=1.7;
  const fg=new THREE.Mesh(new THREE.PlaneGeometry(.55,.32),flagM);fg.position.set(0,3.1,.28);fg.rotation.y=Math.PI/2;ant.add(rd,fg);hull.add(ant);
  /* torre giratoria + caixa de lançamento (LPC) com dois pods de 6 foguetes */
  const tg=new THREE.Group();tg.position.set(0,1.85,-1.0);tg.add(bx(2.4,.3,2.4,metal,0,.15,0),bx(2.6,.5,2.6,dark,0,.45,0));
  const ram=new THREE.Group();ram.position.set(0,.6,-1.0);ram.add(bx(.2,.2,1.6,metal,0,0,.8));tg.add(ram);
  const bp=new THREE.Group();bp.position.set(0,1.3,.2);
  bp.add(bx(3.1,.2,4.6,metal,0,-1.0,1.5),bx(3.1,.2,4.6,metal,0,1.0,1.5),bx(.2,2.2,4.6,metal,-1.55,0,1.5),bx(.2,2.2,4.6,metal,1.55,0,1.5),bx(.2,2.2,4.6,metal,0,0,1.5),
    bx(3.1,2.2,.2,dark,0,0,-.8),bx(.5,.35,.7,warn,-1.55,1.1,3.7),bx(.5,.35,.7,warn,1.55,1.1,3.7));
  const tubes=[];
  for(const p of[-1,1])for(let r=0;r<3;r++)for(let c=0;c<2;c++){
    const x=p*.78+(c?.32:-.32),y=-.6+r*.6,rg=new THREE.Mesh(ringG,metal);rg.scale.set(1.5,1.5,1.5);rg.position.set(x,y,3.78);
    const nm=new THREE.Mesh(noseG,rkMat);nm.position.set(x,y,3.9);bp.add(rg,nm,bx(.5,.5,3.7,mat,x,y,1.9));tubes.push({mesh:nm,x,y});
  }
  tg.add(bp);g.add(hull,tg);g.traverse(o=>o.castShadow=true);scene.add(g);
  const t={g,tg,bp,hull,ant,ram,lamps,mat,dark,wheels,tubes,rl:[],astros:true,m270:true,wd:1.8,spd:.9,trn:.8,L:4,W:1.6,x:0,z:0,y:0,hd:0,v:0,yaw:0,pitch:.08,cd:0,hp:110,dead:false,recoil:0,salvo:0,sT:0,clk:0,phase:0,p0:0,p1:0,st:0,trk:g.trk};
  tanks.push(t);return t;
}
function animM270(t,dt){
  t.clk+=dt;const now=performance.now()/1000;
  if(!t.dead){
    const d=trkStep(t,dt,1.5),th=clamp(Math.abs(t.v)/9,0,1);
    for(const w of t.wheels)w.rotation.x+=d[w.userData.s]/w.userData.r;
    t.hull.position.y=Math.sin(now*30+t.x)*(.008+.012*th)-t.recoil*.06;t.hull.rotation.x=-t.recoil*.025;
    t.ant.rotation.x=-t.v*.012+Math.sin(now*3+t.z)*.03;t.lamps.visible=Math.sin(now*5)>0;
    t.ram.rotation.x=-t.pitch*.55;
    t.ex=(t.ex||0)-dt;if(t.ex<=0){t.ex=.12+Math.random()*.1;t.g.localToWorld(v2.set(1.0,3.1,-3.4));puff(v2,th>.3?0x3a3835:0x6e6a64,.5+th*.4,1,.9,1.2)}
    if(t.salvo>0){t.sT-=dt;if(t.sT<=0){launchOne(t);t.sT=.18;t.salvo--}}
    for(let i=t.rl.length-1;i>=0;i--)if(t.clk>=t.rl[i].at){t.rl[i].u.mesh.visible=true;t.rl.splice(i,1)}
  }else{
    t.burn=(t.burn===undefined?25:t.burn)-dt;
    if(t.burn>0){t.bt=(t.bt||0)-dt;if(t.bt<=0){t.bt=.15;t.g.localToWorld(v2.set(0,3,0));puff(v2,Math.random()<.35?0xff8a2e:0x1f1e1c,1.4,1.5,2,3)}}
  }
  if(t.recoil>0){t.recoil=Math.max(0,t.recoil-dt*3);t.bp.position.z=.2-t.recoil*.4}
}
/* ---------- VBTP-MR Guarani (Brasil): blindado anfibio 6x6, helice traseira, quebra-ondas, rampa e tropa, RWS de 12,7 mm ---------- */
function makeGuarani(color,fc){
  const mat=new THREE.MeshLambertMaterial({color:color||0x4f5d34}),dark=new THREE.MeshLambertMaterial({color:0x2b2d28}),lamp=new THREE.MeshBasicMaterial({color:0xfff2b0}),brkM=new THREE.MeshBasicMaterial({color:0x5a1410}),
    flagM=new THREE.MeshBasicMaterial({color:fc||0xffb000,side:THREE.DoubleSide}),flashM=new THREE.MeshBasicMaterial({color:0xffc060,transparent:true,opacity:.95,depthWrite:false}),
    cm=new THREE.MeshLambertMaterial({color:0x55563a}),hm=new THREE.MeshLambertMaterial({color:0x3d4a2a}),sk=new THREE.MeshLambertMaterial({color:0xc9a27e}),metal=new THREE.MeshLambertMaterial({color:0x4a4b42}),
    DK=0x2b2d28,MT=0x4a4b42,RB=0x1b1b1a,GL=0x2a4a5c,g=new THREE.Group(),wheels=[],steers=[],props=[];
  g.rotation.order='YXZ';
  const mw=(par,x,y,z)=>{const w=new THREE.Mesh(cwG,vcM);w.position.set(x,y,z);w.userData={r:.62};par.add(w);wheels.push(w)};
  for(const s of[-1,1]){
    const sg=new THREE.Group();sg.position.set(s*1.55,.62,2.4);mw(sg,0,0,0);sg.add(bx(.14,.14,.5,dark,-s*.3,.1,0));g.add(sg);steers.push(sg);
    mw(g,s*1.55,.62,-.9);mw(g,s*1.55,.62,-2.3);
  }
  const hull=new THREE.Group(),H=mb();
  H.b(2.5,.7,6.6,'M',0,.95,0);H.b(2.2,.1,6.2,DK,0,.6,0);H.b(2.4,1.05,3.8,'M',0,1.85,-1.3);H.b(2.4,.9,2.3,'M',0,1.75,2.2);H.b(2.3,.12,3.5,'M',0,2.42,-1.3);
  H.b(2.4,.14,1.3,'M',0,1.55,3.25,.55);H.b(2.6,.22,.35,DK,0,.78,3.42);H.b(2.6,.22,.35,DK,0,.78,-3.42);
  H.b(1.2,.55,1.3,'M',-.65,2.3,2.1);H.b(1.05,.38,.06,GL,-.65,2.35,2.78,-.45);H.b(.06,.3,.8,GL,-1.3,2.35,2.05);H.b(1.0,.35,1.3,'M',.7,2.1,2.4);
  for(let k=0;k<5;k++)H.b(.8,.03,.06,DK,.7,2.29,1.95+k*.14);
  H.b(.5,.2,.7,DK,-.8,2.55,-2.4);H.b(.3,.3,.5,MT,.9,2.55,-2.3);H.b(2.2,.04,.3,MT,0,2.47,-2.9);
  H.c(.1,.1,.6,DK,1.15,2.3,-3.15,'y');H.c(.14,.14,.25,MT,1.15,2.55,-3.15,'y');
  for(const s of[-1,1]){
    H.b(.12,1.15,5.9,'M',s*1.32,1.8,-.35,0,0,s*.16);H.b(.1,.25,5.9,MT,s*1.4,1.3,-.35);
    H.b(.05,.9,.8,DK,s*1.42,1.85,.1);H.b(.06,.2,.3,GL,s*1.45,2.1,.1);H.b(.05,.5,.04,MT,s*1.45,1.8,.45);H.b(.05,.2,.25,GL,s*1.45,2.1,-1.3);H.b(.05,.2,.25,GL,s*1.45,2.1,-2.0);
    for(const z of[2.4,-.9,-2.3]){H.b(.55,.1,1.5,'M',s*1.6,1.32,z);H.b(.14,.12,1.5,'M',s*1.9,1.28,z);H.b(.5,.4,.05,RB,s*1.55,.55,z-.85)}
    H.b(.5,.12,.2,DK,s*.95,.9,3.5);H.c(.05,.05,.3,MT,s*.7,.9,3.55,'z');
  }
  H.out(hull,mat);g.add(hull);
  hull.add(bx(.35,.22,.1,lamp,-1,1.35,3.5),bx(.35,.22,.1,lamp,1,1.35,3.5),bx(.3,.2,.08,brkM,1.1,1.2,-3.45),bx(.3,.2,.08,brkM,-1.1,1.2,-3.45));
  const ant=new THREE.Group();ant.position.set(-1.0,2.5,-2.9);const rd=new THREE.Mesh(new THREE.CylinderGeometry(.015,.03,3.3,5),dark);rd.position.y=1.65;
  const fg=new THREE.Mesh(new THREE.PlaneGeometry(.55,.32),flagM);fg.position.set(0,3.1,.28);fg.rotation.y=Math.PI/2;ant.add(rd,fg);hull.add(ant);
  const a2=new THREE.Mesh(new THREE.CylinderGeometry(.01,.02,2,5),dark);a2.position.set(.3,3.5,-2.9);hull.add(a2);
  /* rampa traseira articulada, com estepe */
  const ramp=new THREE.Group(),R=mb();ramp.position.set(0,.85,-3.32);
  R.b(2.1,1.1,.1,'M',0,.55,0);R.b(.5,.3,.04,GL,.5,.85,-.07);R.b(.08,.5,.06,MT,-.8,.5,-.08);R.c(.5,.5,.25,RB,-.45,.5,-.17,'z');R.out(ramp,mat);hull.add(ramp);
  /* tropa desembarcando */
  const troops=new THREE.Group();troops.visible=false;
  for(let k=0;k<3;k++){const f=new THREE.Group();f.position.set(-.8+k*.8,0,-4.6-(k%2)*.6);
    f.add(bx(.3,.7,.22,hm,-.1,.45,0),bx(.3,.7,.22,hm,.1,.45,0),bx(.5,.65,.28,cm,0,1.15,0),new THREE.Mesh(new THREE.SphereGeometry(.17,8,6),sk).translateY(1.65),new THREE.Mesh(new THREE.SphereGeometry(.2,8,6,0,6.283,0,1.6),hm).translateY(1.7),bx(.08,.08,.9,dark,.3,1.15,.4));
    f.userData.p=k*1.7;troops.add(f)}
  hull.add(troops);
  /* quebra-ondas dianteiro (sobe ao nadar) */
  const vane=new THREE.Group();vane.position.set(0,1.0,3.55);vane.add(new THREE.Mesh(new THREE.BoxGeometry(2.3,.9,.08),mat).translateY(.45),new THREE.Mesh(new THREE.BoxGeometry(2.1,.08,.1),dark).translateY(.9));hull.add(vane);
  /* helices traseiras com grade */
  for(const s of[-1,1]){const p=new THREE.Group();p.position.set(s*.8,.75,-3.65);
    p.add(new THREE.Mesh(new THREE.TorusGeometry(.36,.03,6,16),dark),new THREE.Mesh(new THREE.CylinderGeometry(.07,.07,.2,8).rotateX(Math.PI/2),metal));
    for(let k=0;k<4;k++){const b=bx(.07,.3,.03,metal,0,.17,0);const bg=new THREE.Group();bg.rotation.z=k*Math.PI/2;bg.add(b);p.add(bg)}
    hull.add(p);props.push(p)}
  /* escotilhas de teto com tripulante */
  const cl=mkLid(hull,mat,-.8,2.5,-.9,.3),ll=mkLid(hull,mat,-.8,2.5,-2.0,.3),crew=mkCrew(hull,cm,hm,sk,-.8,1.95,-.9);
  /* RWS: estacao de armas remota de 12,7 mm */
  const tg=new THREE.Group(),T=mb();tg.position.set(.55,2.48,-.8);
  T.c(.55,.6,.2,'M',0,.1,0,'y');T.b(.9,.5,.9,'M',0,.45,0);T.b(.45,.35,.45,DK,-.1,.9,.1);T.b(.4,.25,.06,GL,-.1,.92,.35);T.b(.4,.4,.5,MT,.6,.4,-.3);
  for(const s of[-1,1])for(let k=0;k<2;k++)T.c(.05,.05,.25,DK,s*.55,.7,.2+k*.1,'y',0,0,-s*.4);
  T.out(tg,mat);
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb(),K=mb();bp.position.set(0,.5,.6);
  B.b(.3,.3,.4,'M',0,0,0);B.c(.12,.12,.3,RB,0,0,.25,'z');B.out(bp,mat);
  K.c(.08,.08,1.3,DK,0,0,.9,'z');K.c(.12,.12,.6,'M',0,0,.45,'z');K.c(.11,.11,.2,DK,0,0,1.6,'z');K.out(bar,mat);
  const fl=new THREE.Group();fl.add(new THREE.Mesh(new THREE.ConeGeometry(.3,1.1,8).rotateX(-Math.PI/2),flashM).translateZ(2.2));fl.visible=false;bar.add(fl);
  bp.add(bar);tg.add(bp);g.add(tg);g.traverse(o=>o.castShadow=true);fl.traverse(o=>o.castShadow=false);scene.add(g);
  const t={g,tg,bp,bar,hull,ant,lid:[cl,ll],crew,fl,brkM,wheels,steers,props,ramp,troops,vane,mat,dark,gua:true,cannon:true,spd:1.35,trn:.9,L:3.4,W:1.6,mz:2.1,fk:.4,rld:.9,armor:.8,wd:1.9,TY:2.4,
    x:0,z:0,y:0,hd:0,v:0,pv:0,yaw:0,pitch:.06,cd:0,hp:100,dead:false,phase:0,recoil:0,clk:0,lf:-9,ev:0,fT:0,open:0,vn:0};
  tanks.push(t);return t;
}
function animGua(t,dt){
  const now=performance.now()/1000;t.clk+=dt;if(t.dead)return blowOff(t,dt,t.TY);
  const th=clamp(Math.abs(t.v)/14,0,1),ph=t.v*dt,inW=getHV(t.x,t.z)<WATER+.5;t.phase+=ph;
  for(const w of t.wheels)w.rotation.x+=ph/.62;
  for(const s of t.steers)s.rotation.y+=((t.st||0)*.45-s.rotation.y)*Math.min(1,dt*6);
  t.vn+=((inW?1:0)-t.vn)*Math.min(1,dt*2.5);t.vane.rotation.x=-1.45+t.vn*1.7;
  const sp=1.5+th*5+(inW?18:0);t.props.forEach((p,i)=>p.children.forEach(c=>{if(c.rotation&&c.children.length)c.rotation.z+=(i?1:-1)*sp*dt}));
  t.hull.position.y=(inW?Math.sin(now*2.2+t.x)*.07-.25*t.vn:Math.sin(now*28+t.x)*(.01+.014*th))-t.recoil*.03;
  t.hull.rotation.z=-(t.st||0)*th*.03+(inW?Math.sin(now*1.7+t.z)*.025:0);t.hull.rotation.x=-t.recoil*.015+clamp((t.v-t.pv)*.004,-.04,.04);
  t.ant.rotation.x=-t.v*.012+Math.sin(now*3+t.z)*.03;
  t.ramp.rotation.x=-t.open*1.4;t.troops.visible=t.open>.85;
  if(t.troops.visible)t.troops.children.forEach(f=>{f.position.y=Math.abs(Math.sin(now*4+f.userData.p))*.05;f.rotation.y=Math.sin(now*.9+f.userData.p)*.5});
  if(inW&&Math.abs(t.v)>1){t.wk=(t.wk||0)-dt;if(t.wk<=0){t.wk=.07;t.g.localToWorld(v2.set((Math.random()-.5)*1.6,.2,-3.9));puff(v2,0xe8f2f6,.9,1.6,.9,.3);t.g.localToWorld(v2.set((Math.random()<.5?-1:1)*1.5,.2,3.4));puff(v2,0xe8f2f6,.7,1.5,.7,.3)}}
  tankFx(t,dt,now,th,{ex:[[1.15,2.7,-3.15]],dk:[[1.6,.2,-2.5],[-1.6,.2,-2.5],[1.6,.2,-1.0]],mz:2.1,rr:1.8,rc:.3});
}
/* ---------- M1150 ABV (EUA) ---------- */
const lineA=new THREE.MeshLambertMaterial({color:0xe9e2cf}),lineB=new THREE.MeshLambertMaterial({color:0xd9552a}),abvW=new THREE.CylinderGeometry(.42,.42,.16,12).rotateZ(Math.PI/2),v3=new THREE.Vector3();
function makeAbv(color,fc){
  const g=new THREE.Group(),mat=new THREE.MeshLambertMaterial({color:color||0x9b8a5f}),dark=new THREE.MeshLambertMaterial({color:0x2b2d28}),metal=new THREE.MeshLambertMaterial({color:0x4a4b42}),
    glass=new THREE.MeshLambertMaterial({color:0x2a4a5c,emissive:0x0a1a24}),lamp=new THREE.MeshBasicMaterial({color:0xfff2b0}),bcM=new THREE.MeshBasicMaterial({color:0xffa000}),
    flagM=new THREE.MeshBasicMaterial({color:fc||0xffb000,side:THREE.DoubleSide}),wheels=[],pods=[],DK=0x2b2d28,MT=0x4a4b42,RB=0x1b1b1a,GL=0x2a4a5c;
  g.rotation.order='YXZ';
  /* esteiras animadas, 7 rodas de apoio, roda motriz (tras.) e guia (frente) */
  const sideT=treadTex(true),topT=treadTex(false);sideT.repeat.set(9,1);topT.repeat.set(1,9);
  const sideM=new THREE.MeshLambertMaterial({map:sideT}),topM=new THREE.MeshLambertMaterial({map:topT}),trk=[sideM,sideM,topM,dark,dark,dark];
  for(const s of[-1,1]){
    g.add(new THREE.Mesh(new THREE.BoxGeometry(.8,1,7.8),trk).translateX(s*1.6).translateY(.52));
    for(let i=0;i<7;i++){const w=new THREE.Mesh(abG.w,vcM);w.position.set(s*2.04,.5,-2.7+i*.9);w.userData={r:.44,b:1};g.add(w);wheels.push(w)}
    const sp=new THREE.Mesh(abG.s,vcM),id=new THREE.Mesh(abG.i,vcM);sp.position.set(s*2.04,.52,-3.5);id.position.set(s*2.04,.52,3.45);sp.userData={r:.5};id.userData={r:.46};g.add(sp,id);wheels.push(sp,id);
  }
  /* casco: glacis, saias laterais, para-lamas, grade do motor, cabine blindada */
  const hull=new THREE.Group(),H=mb();
  H.b(2.5,.62,7.2,'M',0,.78,0);H.b(2.4,.2,7,DK,0,.38,0);H.b(3.5,.3,6.1,'M',0,1.34,-.55);H.b(3,.18,1.7,'M',0,1.22,2.75,.32);H.b(2.6,.7,.2,'M',0,.72,3.52,.5);H.b(3.3,.95,.14,'M',0,.95,-3.65);
  H.b(1.8,.5,.05,DK,0,1,-3.74);H.b(2.2,.06,1.3,DK,0,1.5,-3);for(let k=0;k<5;k++)H.b(2,.04,.07,MT,0,1.54,-3.5+k*.25);
  H.b(1.3,.7,1.5,'M',.85,1.85,1.45);H.b(1.4,.1,1.6,'M',.85,2.25,1.45);H.b(.9,.14,.04,GL,.85,2,2.21);H.b(.04,.14,.9,GL,1.51,2.05,1.45);H.c(.4,.42,.1,MT,.85,2.33,1,'y');H.b(.05,.5,.05,MT,1.55,1.75,.9);
  H.b(.7,.35,1.2,DK,-1.2,1.67,-1.3);H.b(.5,.3,.5,MT,-1.1,1.65,-.2);
  for(const s of[-1,1]){
    H.b(1,.08,1.5,'M',s*1.62,1.5,3,.06);H.b(.5,.06,6,'M',s*1.95,1.42,-.5);H.b(.18,.18,.2,MT,s*1.05,.65,3.65);
    for(let k=0;k<6;k++){const z=-2.8+k*.96;H.b(.12,.62,.9,'M',s*2.12,1.1,z);H.b(.14,.05,.9,RB,s*2.12,.78,z)}
    hull.add(bx(.3,.18,.1,lamp,s*1.5,1.58,3.74));
  }
  H.out(hull,mat);g.add(hull);
  const bc=new THREE.Group();bc.position.set(1.3,2.34,1.7);bc.add(bx(.22,.12,.22,dark,0,.06,0),bx(.34,.1,.1,bcM,0,.17,0));hull.add(bc);
  /* estacao de armas remota no teto */
  const rws=new THREE.Group();rws.position.set(-.8,1.62,1.3);
  rws.add(new THREE.Mesh(new THREE.CylinderGeometry(.3,.34,.3,10),metal),bx(.38,.3,.7,dark,0,.35,0),new THREE.Mesh(new THREE.SphereGeometry(.15,8,6),glass).translateY(.62).translateZ(.1));
  const mgb=new THREE.Mesh(new THREE.CylinderGeometry(.045,.045,1.1,8).rotateX(Math.PI/2),dark);mgb.position.set(0,.35,.9);rws.add(mgb);hull.add(rws);
  const ant=new THREE.Group();ant.position.set(1.3,1.5,-3.2);
  const rd=new THREE.Mesh(new THREE.CylinderGeometry(.015,.03,3,5),dark);rd.position.y=1.5;
  const fg=new THREE.Mesh(new THREE.PlaneGeometry(.55,.32),flagM);fg.position.set(0,2.85,.28);fg.rotation.y=Math.PI/2;ant.add(rd,fg,bx(.2,.15,.2,dark,0,.07,0));hull.add(ant);
  /* arado de minas: bracos hidraulicos, lamina nervurada, asas e dentes */
  const plow=new THREE.Group(),P=mb();plow.position.set(0,.85,3.7);
  for(const s of[-1,1]){P.b(.25,.3,2,MT,s*1.1,0,1);P.b(.4,.4,.3,DK,s*1.1,0,.05);P.c(.09,.09,1.7,DK,s*.7,.45,.9,'z');P.b(.12,.9,.8,'M',s*2.05,-.1,1.8,0,s*.35)}
  P.b(4.1,.9,.22,'M',0,-.1,2.05,-.12);P.b(4.1,.12,.35,MT,0,-.58,2.15);P.b(4.1,.1,.3,MT,0,.38,2.02);
  for(let k=0;k<5;k++)P.b(.1,.8,.1,MT,-1.6+k*.8,-.1,1.92,-.12);
  for(let k=0;k<7;k++)P.b(.16,.12,1.1,DK,-1.8+k*.6,-.55,2.65,.5);
  P.out(plow,mat);plow.rotation.x=-.35;hull.add(plow);
  /* lancador de cargas de linha (MICLIC) na traseira */
  const tg=new THREE.Group();tg.position.set(0,1.5,-2.5);tg.add(new THREE.Mesh(new THREE.CylinderGeometry(1,1.1,.3,14),metal).translateY(.15),new THREE.Mesh(new THREE.CylinderGeometry(1.15,1.15,.07,14),dark).translateY(.02));
  const bp=new THREE.Group(),B=mb();bp.position.set(0,.7,0);
  for(const s of[-1,1]){
    const rk=new THREE.Group(),rb=new THREE.Mesh(rkBody,rkMat),rn=new THREE.Mesh(rkNose,rkTip);
    rb.scale.set(1.6,1.6,1.8);rn.scale.set(1.6,1.6,1.8);rn.position.z=1.8;
    rk.add(rb,rn,bx(.9,.06,.5,dark,0,0,-1.25),bx(.06,.9,.5,dark,0,0,-1.25));rk.position.set(s*.62,.7,1);
    const dr=new THREE.Group();dr.position.set(s*.62,.45,3);dr.add(bx(.95,.85,.08,dark,0,-.43,0));
    B.b(1,.9,3.4,'M',s*.62,0,1.3);B.b(.14,.14,3.4,MT,s*.62,.52,1.3);B.b(.9,.5,.1,DK,s*.62,0,-.45);
    for(let k=0;k<5;k++)B.b(1.06,.06,.08,DK,s*.62,.47,-.2+k*.75);for(const z of[.1,1.2,2.3])B.b(.5,.2,.1,DK,s*.62,.56,z);B.b(.1,.5,.12,MT,s*.3,-.7,-.2);
    bp.add(rk,dr);pods.push({rk,door:dr,x:s*.62,at:0});
  }
  B.out(bp,mat);tg.add(bp);g.add(hull,tg);g.traverse(o=>o.castShadow=true);scene.add(g);
  const t={g,tg,bp,hull,plow,rws,ant,bc,bcM,wheels,pods,sideT,topT,mat,dark,lines:[],abv:true,spd:.9,trn:.8,L:3.6,W:1.9,x:0,z:0,y:0,hd:0,v:0,yaw:0,pitch:.1,cd:0,hp:140,dead:false,phase:0,recoil:0,clk:0};
  tanks.push(t);return t;
}
function miclic(t){
  const pod=t.pods.find(p=>!p.at);if(!pod)return;
  pod.rk.visible=false;pod.at=t.clk+5.5;
  v1.set(pod.x,.75,3.1);t.bp.localToWorld(v1);
  const d=dirOf(t.yaw,t.pitch),m=new THREE.Group(),fl=new THREE.Mesh(rkFlameG,rkFlame),nz=new THREE.Mesh(rkNose,rkTip);
  nz.position.z=1;fl.position.z=-.9;fl.scale.z=2.5;m.add(new THREE.Mesh(rkBody,rkMat),nz,fl);m.scale.setScalar(1.5);m.position.copy(v1);scene.add(m);
  shells.push({m,v:d.multiplyScalar(SPEED),owner:t,age:0,k:.45,rk:true,tt:0,line:[Math.sin(t.yaw),Math.cos(t.yaw)]});
  puff(v1,0xffe9a0,1.4,3,.35,.5);t.bp.localToWorld(v2.set(pod.x,.6,-.6));puff(v2,0xffd36b,2,6,.4,.5);
  for(let i=0;i<4;i++)puff(v2,0xcfc8b8,2.4,8,1.6,1);
  t.recoil=1;snd('rocket',.8*near(v1));
}
function lineCharge(p,s){
  const dx=s.line[0],dz=s.line[1],pts=[],segs=[];
  for(let i=0;i<12;i++){
    const x=p.x+dx*i*5,z=p.z+dz*i*5;if(Math.hypot(x,z)>HALF-2)break;
    const y=getH(x,z),m=bx(.7,.35,.7,i%2?lineA:lineB,x,y+.2,z);scene.add(m);segs.push(m);pts.push(new THREE.Vector3(x,y,z));
  }
  s.owner.lines.push({pts,segs,i:0,tm:.7});
}
function animAbv(t,dt){
  t.clk+=dt;const now=performance.now()/1000;
  if(!t.dead){
    const ph=t.v*dt;t.phase+=ph;t.sideT.offset.x=t.phase/.85;t.topT.offset.y=t.phase/.85;
    for(const w of t.wheels)w.rotation.x+=ph/(w.userData.r||.42);t.bc.rotation.y+=dt*7;t.bcM.color.setHex(Math.sin(now*7)>0?0xffa000:0x4a2a00);
    {const ac=(t.v-(t.pa||0))/Math.max(dt,.001);t.pa=t.v;t.pt=(t.pt||0)+(clamp(-ac*.003,-.045,.045)-(t.pt||0))*Math.min(1,dt*5);t.rl=(t.rl||0)+(clamp((t.st||0)*t.v*.0014,-.035,.035)-(t.rl||0))*Math.min(1,dt*4);t.hull.rotation.x=t.pt;t.hull.rotation.z=t.rl;t.wheels.forEach((w,i)=>w.position.y=.5+Math.sin(now*11+i*1.7)*.018*Math.min(1,Math.abs(t.v)/10))}
    t.hull.position.y=Math.sin(now*30+t.x)*.012*(.4+Math.abs(t.v)/10)-t.recoil*.04;
    t.ant.rotation.x=-t.v*.012+Math.sin(now*3+t.z)*.03;
    t.plow.rotation.x+=((t.v>1.5?.12:-.35)-t.plow.rotation.x)*Math.min(1,dt*2.5);
    t.dg=(t.dg||0)-dt;
    if(t.v>2&&t.plow.rotation.x>.05&&t.dg<=0){t.dg=.1;t.g.localToWorld(v2.set((Math.random()-.5)*3.6,.1,5.3));puff(v2,0x6b5a3a,1,3,.8,1.5)}
    if(t.v>4)for(const o of tanks){
      if(o.dead||!hostile(t,o))continue;
      const dx=o.x-t.x,dz=o.z-t.z,f=dx*Math.sin(t.hd)+dz*Math.cos(t.hd),sd=Math.abs(dx*Math.cos(t.hd)-dz*Math.sin(t.hd));
      if(f>0&&f<6.5&&sd<3)damage(o,45*dt,t);
    }
    t.ex=(t.ex||0)-dt;if(t.ex<=0){t.ex=.12+Math.random()*.1;t.g.localToWorld(v2.set(0,1.9,-3.7));puff(v2,0x7d7a74,.7,1.5,.9,1.5)}
    t.rs=(t.rs||0)-dt;
    if(t.rs<=0){t.rs=.5;t.mgt=null;let best=70;for(const o of tanks)if(!o.dead&&hostile(t,o)){const d=Math.hypot(o.x-t.x,o.z-t.z);if(d<best){best=d;t.mgt=o}}}
    const o=t.mgt;
    if(o&&!o.dead){
      const df=angDiff(Math.atan2(o.x-t.x,o.z-t.z)-t.hd,t.rws.rotation.y);t.rws.rotation.y+=clamp(df,-3*dt,3*dt);
      t.mt=(t.mt||0)-dt;
      if(Math.abs(df)<.12&&t.mt<=0){
        t.mt=.13;damage(o,1.1,t);t.rws.localToWorld(v2.set(0,.35,1.45));puff(v2,0xffe08a,.45,0,.1,0);
        v3.set(o.x,o.y+1.5,o.z).lerp(v2,Math.random()*.85);puff(v3,0xffe08a,.3,0,.12,0);
      }
    }else t.rws.rotation.y+=(Math.sin(now*.7)*.9-t.rws.rotation.y)*Math.min(1,dt*2);
    for(const p of t.pods){
      if(p.at&&t.clk>=p.at){p.at=0;p.rk.visible=true}
      p.door.rotation.x+=((p.at?-1.5:0)-p.door.rotation.x)*Math.min(1,dt*5);
    }
  }else{
    t.burn=(t.burn===undefined?25:t.burn)-dt;
    if(t.burn>0){t.bt=(t.bt||0)-dt;if(t.bt<=0){t.bt=.15;t.g.localToWorld(v2.set(0,2.4,0));puff(v2,Math.random()<.35?0xff8a2e:0x1f1e1c,1.4,1.5,2,3)}}
  }
  for(let i=t.lines.length-1;i>=0;i--){
    const L=t.lines[i];L.tm-=dt;
    if(L.tm<=0){
      if(L.i<L.pts.length){const p=L.pts[L.i];boom(new THREE.Vector3(p.x,p.y+1,p.z),t,.45);scene.remove(L.segs[L.i]);L.i++;L.tm=.07}
      else t.lines.splice(i,1);
    }
  }
  if(t.recoil>0){t.recoil=Math.max(0,t.recoil-dt*3);t.bp.position.z=-t.recoil*.3}
}
/* ---------- M1 Abrams (EUA) ---------- */
function vcol(g,c){const k=new THREE.Color(c),n=g.attributes.position.count,a=new Float32Array(n*3);for(let i=0;i<n;i++){a[i*3]=k.r;a[i*3+1]=k.g;a[i*3+2]=k.b}g.setAttribute('color',new THREE.BufferAttribute(a,3));return g}
function mergeG(l){
  let nv=0,ni=0;const hc=!!l[0].attributes.color;
  for(const g of l){nv+=g.attributes.position.count;ni+=g.index.count}
  const P=new Float32Array(nv*3),Nm=new Float32Array(nv*3),U=new Float32Array(nv*2),C=hc?new Float32Array(nv*3):null,I=new(nv>65535?Uint32Array:Uint16Array)(ni);let a=0,b=0;
  for(const g of l){const n=g.attributes.position.count;P.set(g.attributes.position.array,a*3);Nm.set(g.attributes.normal.array,a*3);U.set(g.attributes.uv.array,a*2);if(hc)C.set(g.attributes.color.array,a*3);
    for(let i=0;i<g.index.count;i++)I[b+i]=g.index.array[i]+a;a+=n;b+=g.index.count;g.dispose()}
  const o=new THREE.BufferGeometry();o.setAttribute('position',new THREE.BufferAttribute(P,3));o.setAttribute('normal',new THREE.BufferAttribute(Nm,3));o.setAttribute('uv',new THREE.BufferAttribute(U,2));
  if(hc)o.setAttribute('color',new THREE.BufferAttribute(C,3));o.setIndex(new THREE.BufferAttribute(I,1));return o;
}
const vcM=new THREE.MeshLambertMaterial({vertexColors:true});
function mb(){ /* junta dezenas de pecas em poucas malhas: 'M' = cor do casco, outro valor = cor fixa */
  const M=[],D=[];
  const add=(g,c,x,y,z,rx,ry,rz)=>{if(rx)g.rotateX(rx);if(ry)g.rotateY(ry);if(rz)g.rotateZ(rz);g.translate(x,y,z);if(c==='M')M.push(g);else D.push(vcol(g,c))};
  return{
    g:add,b:(w,h,d,c,x,y,z,rx,ry,rz)=>add(new THREE.BoxGeometry(w,h,d),c,x,y,z,rx,ry,rz),
    c:(r1,r2,h,c,x,y,z,ax,rx,ry,rz)=>{const g=new THREE.CylinderGeometry(r1,r2,h,12);if(ax==='z')g.rotateX(Math.PI/2);else if(ax==='x')g.rotateZ(Math.PI/2);add(g,c,x,y,z,rx,ry,rz)},
    out:(p,mat)=>{if(M.length)p.add(new THREE.Mesh(mergeG(M),mat));if(D.length)p.add(new THREE.Mesh(mergeG(D),vcM))}
  };
}
const abG=(()=>{
  const mk=(r,teeth)=>{const l=[vcol(new THREE.CylinderGeometry(r,r,.2,16).rotateZ(Math.PI/2),0x1b1b1a),vcol(new THREE.CylinderGeometry(r*.6,r*.6,.26,12).rotateZ(Math.PI/2),0x5b5c52)];
    for(let k=0;k<6;k++){const a=k/6*6.283,g=new THREE.CylinderGeometry(.05,.05,.3,6).rotateZ(Math.PI/2);g.translate(0,Math.sin(a)*r*.38,Math.cos(a)*r*.38);l.push(vcol(g,0x2b2d28))}
    if(teeth)for(let k=0;k<12;k++){const a=k/12*6.283,g=new THREE.BoxGeometry(.24,.16,.14);g.translate(0,Math.sin(a)*(r+.02),Math.cos(a)*(r+.02));l.push(vcol(g,0x3a3b34))}
    return mergeG(l)};
  return{w:mk(.44),s:mk(.5,1),i:mk(.46)};
})();
const camoT=canvasTex(128,128,(x,w,h)=>{x.fillStyle='#fff';x.fillRect(0,0,w,h);const cs=['#c9c2a0','#a9a98a','#8f8a74'];for(let i=0;i<26;i++){x.fillStyle=cs[i%3];x.beginPath();x.ellipse(Math.random()*w,Math.random()*h,8+Math.random()*20,5+Math.random()*10,Math.random()*3,0,7);x.fill()}});
const dartG=new THREE.CylinderGeometry(.07,.07,2.2,6).rotateX(Math.PI/2);
function makeAbrams(color,fc){
  const mat=new THREE.MeshLambertMaterial({color:color||0xb4a070,map:camoT}),dark=new THREE.MeshLambertMaterial({color:0x2b2d28}),lamp=new THREE.MeshBasicMaterial({color:0xfff2b0}),
    brkM=new THREE.MeshBasicMaterial({color:0x5a1410}),glowM=new THREE.MeshBasicMaterial({color:0x1f0d05}),flagM=new THREE.MeshBasicMaterial({color:fc||0xffb000,side:THREE.DoubleSide}),
    flashM=new THREE.MeshBasicMaterial({color:0xffc060,transparent:true,opacity:.95,depthWrite:false}),cm=new THREE.MeshLambertMaterial({color:0x55563a}),hm=new THREE.MeshLambertMaterial({color:0x3d4a2a}),sk=new THREE.MeshLambertMaterial({color:0xc9a27e}),
    DK=0x2b2d28,MT=0x4a4b42,RB=0x1b1b1a,GL=0x2a4a5c,TW=0x3a3a35,g=new THREE.Group(),wheels=[];
  g.rotation.order='YXZ';
  /* esteiras animadas, rodas de apoio, roda motriz e guia */
  const sideT=treadTex(true),topT=treadTex(false);sideT.repeat.set(9,1);topT.repeat.set(1,9);
  const sideM=new THREE.MeshLambertMaterial({map:sideT}),topM=new THREE.MeshLambertMaterial({map:topT}),trk=[sideM,sideM,topM,dark,dark,dark];
  for(const s of[-1,1]){
    const tr=new THREE.Mesh(new THREE.BoxGeometry(.8,1,7.8),trk);tr.position.set(s*1.6,.52,0);g.add(tr);
    for(let i=0;i<7;i++){const w=new THREE.Mesh(abG.w,vcM);w.position.set(s*2.04,.5,-2.7+i*.9);w.userData={r:.44,b:1};g.add(w);wheels.push(w)}
    const sp=new THREE.Mesh(abG.s,vcM),id=new THREE.Mesh(abG.i,vcM);sp.position.set(s*2.04,.52,-3.5);id.position.set(s*2.04,.52,3.45);sp.userData={r:.5};id.userData={r:.46};g.add(sp,id);wheels.push(sp,id);
  }
  /* casco: glacis, saias laterais, grades da turbina */
  const hull=new THREE.Group(),H=mb();
  H.b(2.5,.62,7.2,'M',0,.78,0);H.b(2.4,.2,7,DK,0,.38,0);H.b(3.5,.3,5.6,'M',0,1.34,-.8);H.b(3,.18,1.9,'M',0,1.22,2.65,.32);H.b(2.6,.7,.2,'M',0,.72,3.52,.5);H.b(3.3,.95,.14,'M',0,.95,-3.65);
  H.c(.4,.42,.1,MT,0,1.53,2.25,'y');H.c(.38,.38,.06,'M',0,1.6,2.25,'y');H.b(.3,.3,.35,MT,0,.65,-3.82);
  for(let k=0;k<3;k++)H.b(.2,.08,.1,GL,-.28+k*.28,1.64,2.6);
  for(let k=0;k<5;k++)H.b(.9,.04,.07,MT,0,1.54,-3.5+k*.19);
  for(const s of[-1,1]){
    H.b(1,.08,1.5,'M',s*1.62,1.5,3,.06);H.b(1,.5,.05,RB,s*1.62,1.2,3.78);H.b(.06,.06,1.7,TW,s*.9,1.27,2.7,.32);H.b(.18,.18,.2,MT,s*1.05,.62,3.62);H.b(.9,.05,.9,DK,s*1.15,1.5,-3.1);
    for(let k=0;k<6;k++){const z=-2.8+k*.96;H.b(.12,.62,.9,'M',s*2.12,1.1,z);H.b(.14,.05,.9,RB,s*2.12,.78,z);H.b(.05,.5,.05,MT,s*2.2,1.1,z-.35)}
    for(let k=0;k<5;k++)H.b(.9,.04,.07,MT,s*1.15,1.55,-3.5+k*.19);
    hull.add(bx(.3,.18,.1,lamp,s*1.5,1.58,3.74),bx(.3,.2,.08,brkM,s*1.4,1.1,-3.74));
  }
  const glow=new THREE.Mesh(new THREE.PlaneGeometry(.8,.9).rotateX(-Math.PI/2),glowM);glow.position.set(0,1.5,-3.1);hull.add(glow);
  H.out(hull,mat);g.add(hull);
  /* torre: cunhas blindadas, bustle com paineis de alivio, lancadores de fumaca */
  const tg=new THREE.Group(),T=mb();tg.position.set(0,1.5,.5);
  T.c(1.3,1.3,.2,'M',0,.1,0,'y');T.b(2.5,.58,3,'M',0,.45,0);T.b(2.3,.14,2.5,'M',0,.8,-.1);T.b(2.1,.12,1.2,'M',0,.72,1.35,.3);T.b(.9,.62,.35,'M',0,.45,1.9);
  T.b(2.7,.66,1.2,'M',0,.5,-2);T.b(2.6,.4,.2,'M',0,.45,-2.65,-.3);T.b(2.2,.04,.9,DK,0,.85,-2);
  T.b(2.5,.05,.05,MT,0,.25,-2.95);T.b(2.5,.05,.05,MT,0,.6,-2.95);T.c(.2,.2,1.6,0x6f6a4c,0,.42,-2.85,'x');T.b(.7,.4,.35,0x55563a,-.7,.52,-2.9);T.b(.5,.35,.35,0x4f5a34,.7,.5,-2.9);
  T.b(.55,.38,.5,DK,.55,.92,1.15);T.b(.35,.18,.04,GL,.55,.94,1.42);T.c(.46,.5,.18,MT,.65,.93,-.45,'y');T.c(.4,.44,.14,MT,-.65,.9,-.7,'y');T.c(.015,.015,.5,MT,-.3,1.1,-1.3,'y');
  for(let k=0;k<8;k++){const a=k/8*6.283;T.b(.16,.1,.08,GL,.65+Math.sin(a)*.46,1.04,-.45+Math.cos(a)*.46,0,a)}
  for(const s of[-1,1]){
    T.b(1.1,.62,.4,'M',s*.85,.45,1.6,0,s*.6);T.b(.2,.45,1,'M',s*1.4,.45,-2);T.b(.35,.28,.8,DK,s*1.38,.62,.95);T.b(.05,.55,.05,MT,s*1.2,.35,-2.95);T.c(.12,.14,.2,MT,s*1.1,.78,-2.4,'y');
    for(let k=0;k<6;k++)T.c(.05,.05,.32,MT,s*1.5,.82,.62+k*.13,'y',0,0,-s*.7);
  }
  T.out(tg,mat);
  const lid=(x,y,z,r)=>{const h=new THREE.Group();h.position.set(x,y,z-r);const m=new THREE.Mesh(new THREE.CylinderGeometry(r,r,.05,12),mat);m.position.z=r;h.add(m);tg.add(h);return h};
  const cl=lid(.65,1.03,-.45,.45),ll=lid(-.65,.98,-.7,.42);
  const crew=new THREE.Group();crew.position.set(.65,.5,-.45);const hd=new THREE.Mesh(new THREE.SphereGeometry(.13,8,6),hm);hd.scale.y=.75;hd.position.y=.78;
  crew.add(bx(.34,.5,.22,cm,0,.3,0),new THREE.Mesh(new THREE.SphereGeometry(.11,8,6),sk).translateY(.68).translateZ(.04),hd);tg.add(crew);
  const cmg=new THREE.Group();cmg.position.set(.65,1.05,0);cmg.add(bx(.1,.14,.7,dark,0,.1,.3),bx(.05,.05,1,dark,0,.1,.95),bx(.4,.3,.04,dark,0,.14,.6),bx(.08,.2,.08,dark,0,0,0));tg.add(cmg);
  const lmg=new THREE.Group();lmg.position.set(-.65,1.0,-.4);lmg.add(bx(.08,.1,.55,dark,0,.1,.1),bx(.04,.04,.7,dark,0,.1,.6),bx(.06,.2,.06,dark,0,0,0));tg.add(lmg);
  const citv=new THREE.Group();citv.position.set(-.2,.87,.5);citv.add(bx(.24,.25,.24,dark,0,.12,0),bx(.5,.32,.5,dark,0,.42,0),bx(.3,.14,.04,new THREE.MeshLambertMaterial({color:GL,emissive:0x0a2a3a}),0,.42,.27));tg.add(citv);
  const mkAnt=(x,flag)=>{const a=new THREE.Group();a.position.set(x,.88,-2.4);const r=new THREE.Mesh(new THREE.CylinderGeometry(.015,.03,4,5),dark);r.position.y=2;a.add(r);
    if(flag){const f=new THREE.Mesh(new THREE.PlaneGeometry(.55,.32),flagM);f.position.set(0,3.8,.28);f.rotation.y=Math.PI/2;a.add(f)}tg.add(a);return a};
  const ant=mkAnt(-1.1,1),ant2=mkAnt(1.1,0);
  /* mantelete, canhao de 120 mm com camisa termica e ejetor de gases */
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb(),K=mb();bp.position.set(0,.5,2.05);
  B.b(1.25,.62,.5,'M',0,0,.1);B.c(.24,.32,.3,RB,0,0,.4,'z');B.c(.03,.03,.5,DK,.42,-.12,.55,'z');B.b(.3,.2,.06,GL,-.42,.1,.36);B.out(bp,mat);
  K.c(.13,.13,4,DK,0,0,2.3,'z');K.c(.2,.19,2.5,'M',0,0,1.75,'z');K.c(.27,.27,.5,'M',0,0,2.75,'z');for(const z of[.9,1.5,2.1])K.c(.22,.22,.07,DK,0,0,z,'z');
  K.c(.23,.23,.1,DK,0,0,3.02,'z');K.c(.145,.145,.3,DK,0,0,4.15,'z');K.b(.1,.1,.16,MT,0,.17,3.95);K.out(bar,mat);
  const fl=new THREE.Group();fl.add(new THREE.Mesh(new THREE.ConeGeometry(.5,1.8,10).rotateX(-Math.PI/2),flashM).translateZ(5.3),new THREE.Mesh(new THREE.SphereGeometry(.45,8,6),flashM).translateZ(4.6));fl.visible=false;bar.add(fl);
  bp.add(bar);tg.add(bp);g.add(tg);g.traverse(o=>o.castShadow=true);fl.traverse(o=>o.castShadow=false);scene.add(g);
  const t={g,tg,bp,bar,hull,ant,ant2,lid:[cl,ll],crew,cmg,lmg,citv,fl,glowM,brkM,wheels,sideT,topT,mat,dark,abrams:true,spd:1.25,trn:.95,L:3.8,W:1.9,mz:4.45,fk:1.35,rld:2.4,armor:.72,
    x:0,z:0,y:0,hd:0,v:0,pv:0,yaw:0,pitch:.06,cd:0,hp:100,lhp:100,dead:false,phase:0,recoil:0,clk:0,lf:-9,sm:0,sq:[],ev:0,fT:0,open:0};
  tanks.push(t);return t;
}
function abramsFire(t,d){
  const m=new THREE.Mesh(dartG,t===player?shellP:shellE);m.position.copy(v1);scene.add(m);
  shells.push({m,v:d.multiplyScalar(SPEED),owner:t,age:0,k:t.fk,tr:true,tt:0});
  t.recoil=1;t.fT=.09;t.ev=.7;t.lf=t.clk;t.fl.visible=true;
  for(let i=0;i<8;i++)puff(v1,0xe6dcc8,1.7,5,.8,.6);for(let i=0;i<4;i++)puff(v1,0xffb347,1.5,4,.22,.4);
  v3.set(v1.x,getH(v1.x,v1.z)+.4,v1.z);for(let i=0;i<6;i++)puff(v3,0xb5a584,2,7,1,.5);
  (t.gua||t.gep||t.agmv||t.zsu||t.t27||t.l3||t.pz1)?snd('mg',.8*near(v1)):snd(t.t80||t.merk||t.t90||t.t72||t.arm14||t.tiger||t.abrams||t.leo||t.pl01||t.stk||t.jp||t.ch2||t.maus||t.su||t.ku||t.amr||t.pzh||t.m109?'heavy':t.t35||t.amx||t.boxer||t.cv90?'light':t.stuart||t.casc||t.m2lt?'light':'cannon',.9*near(v1));if(t===player)shake=Math.max(shake,.9);
}
function smokeL(t){for(const s of[-1,1])for(let k=0;k<6;k++){t.tg.localToWorld(v2.set(s*1.5,.9,.62+k*.13));puff(v2,0xf4f2ec,.5,1,.4,1.5);t.sq.push({d:k*.07+(s>0?.03:0),a:t.yaw+s*(.25+k*.12),r:7+k*1.4})}}
function animAbrams(t,dt){
  const now=performance.now()/1000;if(!t.mw){t.g.updateMatrixWorld(true);t.mw=1}
  t.clk+=dt;
  if(!t.dead){
    const ph=t.v*dt,th=clamp(Math.abs(t.v)/12,0,1);t.phase+=ph;t.sideT.offset.x=t.phase/.75;t.topT.offset.y=t.phase/.75;
    t.wheels.forEach((w,i)=>{w.rotation.x+=ph/w.userData.r;if(w.userData.b)w.position.y=.5+Math.sin(now*11+i*1.7)*.018*th});
    t.hull.position.y=Math.sin(now*32+t.x)*.011*(.4+th)-t.recoil*.03;t.hull.rotation.x=-t.recoil*.02;
    t.ant.rotation.x=-t.v*.012+Math.sin(now*3+t.z)*.03;t.ant2.rotation.x=-t.v*.012+Math.sin(now*2.4+t.x)*.035;t.ant2.rotation.z=Math.sin(now*2+t.z)*.02;
    /* turbina: grade incandescente, ar quente e poeira das esteiras */
    t.glowM.color.setRGB(.12+.88*th,.05+.35*th,.02+.03*th);
    t.ex=(t.ex||0)-dt;if(t.ex<=0){t.ex=.16-.1*th;t.g.localToWorld(v2.set((Math.random()-.5)*.7,1.75,-3.1));puff(v2,0xe6eef4,.5+.5*th,1,.6,1.6);if(th>.5)puff(v2,0xffa24a,.3,.8,.25,1)}
    t.dk=(t.dk||0)-dt;if(t.v>3.5&&t.dk<=0){t.dk=.07;t.g.localToWorld(v2.set((Math.random()<.5?-1:1)*1.6,.2,-3.9));puff(v2,0xa89a78,.7,2.2,.5,1)}
    t.brkM.color.setHex(t.v<-.3||(t.v-t.pv)/Math.max(dt,.001)<-2?0xff2a1a:0x5a1410);t.pv=t.v;
    /* escotilhas, comandante, vigia termica */
    t.open+=clamp((Math.abs(t.v)<.6&&t.clk-t.lf>1.5&&!t.mgt?1:0)-t.open,-dt*1.6,dt*1.6);
    t.lid[0].rotation.x=-t.open*1.6;t.lid[1].rotation.x=-t.open*1.5;t.crew.visible=t.open>.05;t.crew.position.y=.5+t.open*.5;t.crew.rotation.y=Math.sin(now*.8+t.x)*.6;
    t.citv.rotation.y=Math.sin(now*.9)*1.1;t.lmg.rotation.y=Math.sin(now*.6+t.x)*1.4;
    /* metralhadora .50 do comandante mira sozinha */
    t.rs=(t.rs||0)-dt;if(t.rs<=0){t.rs=.5;t.mgt=null;let best=55;for(const o of tanks)if(!o.dead&&hostile(t,o)){const d=Math.hypot(o.x-t.x,o.z-t.z);if(d<best){best=d;t.mgt=o}}}
    const o=t.mgt;
    if(o&&!o.dead){
      const df=angDiff(Math.atan2(o.x-t.x,o.z-t.z)-t.yaw,t.cmg.rotation.y);t.cmg.rotation.y+=clamp(df,-3.5*dt,3.5*dt);t.mt=(t.mt||0)-dt;
      if(Math.abs(df)<.12&&t.mt<=0){t.mt=.11;damage(o,.8,t);t.cmg.localToWorld(v2.set(0,.05,1.45));puff(v2,0xffe08a,.4,0,.1,0);v3.set(o.x,o.y+1.5,o.z).lerp(v2,Math.random()*.85);puff(v3,0xffe08a,.3,0,.12,0)}
    }else t.cmg.rotation.y+=(Math.sin(now*.7)*.8-t.cmg.rotation.y)*Math.min(1,dt*2);
    /* fumaca ao ser atingido */
    t.sm=Math.max(0,t.sm-dt);if(t.lhp-t.hp>6&&t.sm<=0){t.sm=14;smokeL(t)}t.lhp=t.hp;
    for(let i=t.sq.length-1;i>=0;i--){const q=t.sq[i];q.d-=dt;if(q.d<=0){const x=t.x+Math.sin(q.a)*q.r,z=t.z+Math.cos(q.a)*q.r;v2.set(x,getH(x,z)+1.8,z);for(let j=0;j<2;j++)puff(v2,0xf4f2ec,2.8,3,6.5,.8);t.sq.splice(i,1)}}
    /* canhao: clarao, ejetor de gases, recuo */
    if(t.fT>0){t.fT-=dt;t.fl.visible=t.fT>0;t.fl.scale.setScalar(.7+Math.random()*.6)}
    if(t.ev>0){t.ev-=dt;t.ek=(t.ek||0)-dt;if(t.ek<=0){t.ek=.04;t.bar.localToWorld(v2.set(0,0,2.75));puff(v2,0xcfc8b8,.45,1.2,.9,.5)}}
    if(t.recoil>0){t.recoil=Math.max(0,t.recoil-dt*1.5);t.bar.position.z=-t.recoil*.9}
  }else{
    if(t.tv===undefined){t.tv=8+Math.random()*3;t.ty=0;t.tz=(Math.random()-.5)*.7;t.tzc=0;t.fl.visible=false;t.glowM.color.set(0);t.brkM.color.set(0x220000)}
    if(t.tv!==0||t.ty>0){t.tv-=G*dt;t.ty+=t.tv*dt;t.tzc+=(t.tz-t.tzc)*Math.min(1,dt*3);t.tg.rotation.z=t.tzc;if(t.ty<=0){t.ty=0;t.tv=t.tv<-2?-t.tv*.3:0}t.tg.position.y=1.5+t.ty}
    t.burn=(t.burn===undefined?25:t.burn)-dt;
    if(t.burn>0){t.bt=(t.bt||0)-dt;if(t.bt<=0){t.bt=.15;t.g.localToWorld(v2.set(0,2.2,0));puff(v2,Math.random()<.35?0xff8a2e:0x1f1e1c,1.4,1.5,2,3)}}
  }
}
/* ---------- Panzerkampfwagen VI Tiger (Ausf. E) ---------- */
function tw(r,teeth){
  const l=[vcol(new THREE.CylinderGeometry(r,r,.16,16).rotateZ(Math.PI/2),0x1b1b1a),vcol(new THREE.CylinderGeometry(r*.78,r*.78,.2,14).rotateZ(Math.PI/2),0x55564d),vcol(new THREE.CylinderGeometry(r*.3,r*.3,.26,10).rotateZ(Math.PI/2),0x3a3b34)];
  for(let k=0;k<6;k++){const a=k/6*6.283,g=new THREE.CylinderGeometry(.05,.05,.24,6).rotateZ(Math.PI/2);g.translate(0,Math.sin(a)*r*.55,Math.cos(a)*r*.55);l.push(vcol(g,0x2b2d28))}
  if(teeth)for(let k=0;k<10;k++){const a=k/10*6.283,g=new THREE.BoxGeometry(.22,.18,.14);g.translate(0,Math.sin(a)*(r+.03),Math.cos(a)*(r+.03));l.push(vcol(g,0x3a3b34))}
  return mergeG(l);
}
const tgG={w:tw(.5),s:tw(.55,1),i:tw(.5)};
const numT=canvasTex(128,64,(x,w,h)=>{x.font='700 52px Arial,sans-serif';x.textAlign='center';x.textBaseline='middle';x.lineWidth=7;x.strokeStyle='#111';x.strokeText('212',w/2,h/2);x.fillStyle='#f3ecd8';x.fillText('212',w/2,h/2)});
const crossT=canvasTex(64,64,(x,w,h)=>{x.fillStyle='#f3ecd8';x.fillRect(18,2,28,60);x.fillRect(2,18,60,28);x.fillStyle='#111';x.fillRect(23,7,18,50);x.fillRect(7,23,50,18)});
function makeTiger(color,fc){
  const mat=new THREE.MeshLambertMaterial({color:color||0x7b7863}),dark=new THREE.MeshLambertMaterial({color:0x2b2d28}),lamp=new THREE.MeshBasicMaterial({color:0xfff2b0}),brkM=new THREE.MeshBasicMaterial({color:0x5a1410}),
    flagM=new THREE.MeshBasicMaterial({color:fc||0xffb000,side:THREE.DoubleSide}),flashM=new THREE.MeshBasicMaterial({color:0xffc060,transparent:true,opacity:.95,depthWrite:false}),
    cm=new THREE.MeshLambertMaterial({color:0x4a4f45}),hm=new THREE.MeshLambertMaterial({color:0x1f2226}),sk=new THREE.MeshLambertMaterial({color:0xc9a27e}),
    DK=0x2b2d28,MT=0x4a4b42,RB=0x1b1b1a,GL=0x1d2f3a,WD=0x6a5232,TW=0x3a3a35,g=new THREE.Group(),wheels=[];
  g.rotation.order='YXZ';
  /* esteiras largas e rodas de apoio intercaladas (duas profundidades) */
  const sideT=treadTex(true),topT=treadTex(false);sideT.repeat.set(8,1);topT.repeat.set(1,8);
  const sideM=new THREE.MeshLambertMaterial({map:sideT}),topM=new THREE.MeshLambertMaterial({map:topT}),trk=[sideM,sideM,topM,dark,dark,dark];
  for(const s of[-1,1]){
    const tr=new THREE.Mesh(new THREE.BoxGeometry(.85,.95,6.6),trk);tr.position.set(s*1.4,.5,0);g.add(tr);
    for(let i=0;i<8;i++){const w=new THREE.Mesh(tgG.w,vcM);w.position.set(s*(i%2?1.9:2.08),.52,-2.73+i*.78);w.userData={r:.5,b:1};g.add(w);wheels.push(w)}
    const sp=new THREE.Mesh(tgG.s,vcM),id=new THREE.Mesh(tgG.i,vcM);sp.position.set(s*2,.55,-3.3);id.position.set(s*2,.5,3.2);sp.userData={r:.55};id.userData={r:.5};g.add(sp,id);wheels.push(sp,id);
  }
  /* casco: placas retas, paralamas, grades do Maybach, escapamentos, ferramentas */
  const hull=new THREE.Group(),H=mb();
  H.b(2.2,.7,5.6,'M',0,.72,0);H.b(2.1,.2,5.6,DK,0,.38,0);H.b(3.2,.8,3.6,'M',0,1.45,.8);H.b(3.2,.55,2.2,'M',0,1.32,-2.1);H.b(2.2,.8,.2,'M',0,.7,2.85,.3);H.b(2.8,.9,.15,'M',0,1,-3.15);
  H.c(.3,.3,.1,MT,-.8,1.9,1.9,'y');H.c(.3,.3,.1,MT,.8,1.9,1.9,'y');H.b(.5,.16,.08,DK,-.8,1.55,2.62);H.b(.4,.05,.04,GL,-.8,1.55,2.67);
  H.c(.12,.12,.15,DK,.8,1.5,2.7,'z');H.c(.025,.025,.7,MT,.8,1.5,3,'z');H.b(.7,.05,1.2,MT,0,1.6,-2.1);H.b(.08,.05,1.4,WD,-1.75,1.1,-.4);H.b(.3,.04,.35,MT,-1.75,1.1,-1.15);
  for(const s of[-1,1]){
    H.b(.5,.05,6.4,'M',s*1.85,1.05,0);H.b(.5,.05,.8,'M',s*1.85,1.2,3.4,-.35);H.b(.5,.4,.04,RB,s*1.85,.9,3.62);H.b(.07,.07,3.2,TW,s*2.05,1.12,.2);
    H.c(.17,.17,.9,MT,s*1.55,1.25,-3,'z');H.c(.2,.2,.1,DK,s*1.55,1.25,-3.5,'z');H.b(.9,.05,1,DK,s*.95,1.6,-2.2);H.b(.1,.12,.12,DK,s*1.6,1.6,1.4);H.b(.2,.2,.2,MT,s*.9,.6,3);
    for(let k=0;k<5;k++)H.b(.9,.04,.07,MT,s*.95,1.64,-2.6+k*.2);
    for(let k=0;k<3;k++)H.b(.4,.1,.08,0x3a3b34,s*(.5+k*.5),1.25,2.64);
    hull.add(bx(.3,.2,.08,brkM,s*1.2,1.1,-3.25));
  }
  hull.add(bx(.3,.2,.2,lamp,-1.55,1.18,3.1),bx(.25,.15,.15,lamp,1.55,1.18,3.1));
  for(const s of[-1,1]){const cr=new THREE.Mesh(new THREE.PlaneGeometry(.6,.6),new THREE.MeshBasicMaterial({map:crossT,transparent:true}));cr.position.set(s*1.615,1.45,.8);cr.rotation.y=s*Math.PI/2;hull.add(cr)}
  H.out(hull,mat);g.add(hull);
  const ant=new THREE.Group();ant.position.set(1.4,1.62,-2.8);const rd=new THREE.Mesh(new THREE.CylinderGeometry(.015,.03,3.4,5),dark);rd.position.y=1.7;
  const fg=new THREE.Mesh(new THREE.PlaneGeometry(.55,.32),flagM);fg.position.set(0,3.2,.28);fg.rotation.y=Math.PI/2;ant.add(rd,fg);hull.add(ant);
  /* torre: cupula, lancadores de fumaca, bustle, numero tatico */
  const tg=new THREE.Group(),T=mb();tg.position.set(0,1.85,.1);
  T.c(1.4,1.4,.9,'M',0,.45,0,'y');T.c(1.2,1.25,.1,'M',0,.93,0,'y');T.b(2.2,.9,.3,'M',0,.45,1.5);T.b(2.3,.75,.45,'M',0,.45,-1.55);T.b(2.1,.05,.35,DK,0,.84,-1.55);
  T.c(.45,.5,.4,'M',-.6,1.15,-.4,'y');T.c(.35,.38,.1,MT,.6,.97,-.4,'y');T.c(.28,.28,.05,MT,0,.5,-1.8,'z');T.b(.2,.15,.25,DK,-.2,1,.8);T.c(.15,.15,1.6,0x6f6a4c,0,.98,-1.55,'x');T.b(.3,.4,.2,0x4f5a34,.8,.6,-1.9);
  for(let k=0;k<6;k++){const a=k/6*6.283;T.b(.12,.08,.05,GL,-.6+Math.sin(a)*.48,1.18,-.4+Math.cos(a)*.48,0,a)}
  for(const s of[-1,1]){
    T.c(.08,.08,.08,DK,s*1.35,.5,-.9,'x');for(let k=0;k<3;k++)T.c(.07,.07,.3,DK,s*1.38,.8,.5+k*.2,'y',0,0,-s*.5);T.b(.12,.1,.12,MT,s*.9,.98,.9);T.b(.12,.1,.12,MT,s*.9,.98,-.9);
  }
  T.out(tg,mat);
  for(const s of[-1,1]){const nm=new THREE.Mesh(new THREE.PlaneGeometry(.8,.4),new THREE.MeshBasicMaterial({map:numT,transparent:true}));nm.position.set(s*1.43,.45,-.1);nm.rotation.y=s*Math.PI/2;tg.add(nm)}
  const lid=(x,y,z,r)=>{const h=new THREE.Group();h.position.set(x,y,z-r);const m=new THREE.Mesh(new THREE.CylinderGeometry(r,r,.05,12),mat);m.position.z=r;h.add(m);tg.add(h);return h};
  const cl=lid(-.6,1.36,-.4,.45),ll=lid(.6,1.02,-.4,.38);
  const crew=new THREE.Group();crew.position.set(-.6,.8,-.4);const hd=new THREE.Mesh(new THREE.SphereGeometry(.13,8,6),hm);hd.scale.y=.75;hd.position.y=.78;
  crew.add(bx(.34,.5,.22,cm,0,.3,0),new THREE.Mesh(new THREE.SphereGeometry(.11,8,6),sk).translateY(.68).translateZ(.04),hd,bx(.16,.08,.1,dark,0,.7,.14));tg.add(crew);
  /* mantelete e canhao 8,8 cm KwK 36 com freio de boca de dois defletores */
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb(),K=mb();bp.position.set(0,.5,1.75);
  B.c(.42,.42,1,'M',0,0,.15,'x');B.b(.8,.6,.3,'M',0,0,.1);B.c(.04,.04,.4,DK,.35,.05,.45,'z');B.b(.15,.12,.05,GL,-.35,.12,.38);B.out(bp,mat);
  K.c(.15,.12,1.6,MT,0,0,.9,'z');K.c(.1,.1,4,DK,0,0,2.1,'z');K.c(.17,.17,.32,DK,0,0,4.2,'z');K.c(.12,.12,.12,MT,0,0,4.42,'z');K.c(.17,.17,.28,DK,0,0,4.62,'z');K.out(bar,mat);
  const fl=new THREE.Group();fl.add(new THREE.Mesh(new THREE.ConeGeometry(.5,1.8,10).rotateX(-Math.PI/2),flashM).translateZ(5.6),new THREE.Mesh(new THREE.SphereGeometry(.3,8,6),flashM).translateX(.38).translateZ(4.45),new THREE.Mesh(new THREE.SphereGeometry(.3,8,6),flashM).translateX(-.38).translateZ(4.45));
  fl.visible=false;bar.add(fl);bp.add(bar);tg.add(bp);g.add(tg);g.traverse(o=>o.castShadow=true);fl.traverse(o=>o.castShadow=false);scene.add(g);
  const t={g,tg,bp,bar,hull,ant,lid:[cl,ll],crew,fl,brkM,wheels,sideT,topT,mat,dark,tiger:true,spd:.8,trn:.6,L:3.2,W:1.95,mz:4.95,fk:1.2,rld:3.2,armor:.6,
    x:0,z:0,y:0,hd:0,v:0,pv:0,yaw:0,pitch:.06,cd:0,hp:100,dead:false,phase:0,recoil:0,clk:0,lf:-9,ev:0,fT:0,open:0};
  tanks.push(t);return t;
}
function blowOff(t,dt,TY){
  if(t.tv===undefined){t.tv=8+Math.random()*3;t.ty=0;t.tz=(Math.random()-.5)*.7;t.tzc=0;t.fl.visible=false;t.brkM.color.set(0x220000)}
  if(t.tv!==0||t.ty>0){t.tv-=G*dt;t.ty+=t.tv*dt;t.tzc+=(t.tz-t.tzc)*Math.min(1,dt*3);t.tg.rotation.z=t.tzc;if(t.ty<=0){t.ty=0;t.tv=t.tv<-2?-t.tv*.3:0}t.tg.position.y=TY+t.ty}
  t.burn=(t.burn===undefined?25:t.burn)-dt;
  if(t.burn>0){t.bt=(t.bt||0)-dt;if(t.bt<=0){t.bt=.15;t.g.localToWorld(v2.set(0,2.4,0));puff(v2,Math.random()<.35?0xff8a2e:0x1f1e1c,1.4,1.5,2,3)}}
}
function animTiger(t,dt){
  const now=performance.now()/1000;if(!t.mw){t.g.updateMatrixWorld(true);t.mw=1}
  t.clk+=dt;
  if(t.dead)return blowOff(t,dt,1.85);
  const ph=t.v*dt,th=clamp(Math.abs(t.v)/9,0,1);t.phase+=ph;t.sideT.offset.x=t.phase/.75;t.topT.offset.y=t.phase/.75;
  t.wheels.forEach((w,i)=>{w.rotation.x+=ph/w.userData.r;if(w.userData.b)w.position.y=.52+Math.sin(now*9+i*1.3)*.02*th});
  t.hull.position.y=Math.sin(now*40+t.x)*(.008+.012*th)-t.recoil*.03;t.hull.rotation.x=-t.recoil*.02;t.ant.rotation.x=-t.v*.012+Math.sin(now*3+t.z)*.03;
  /* motor Maybach: fumaca preta ao acelerar, poeira das esteiras, luzes de freio */
  t.ex=(t.ex||0)-dt;if(t.ex<=0){t.ex=.12-.07*th;for(const s of[-1,1]){t.g.localToWorld(v2.set(s*1.55,1.3,-3.7));puff(v2,th>.4?0x1f1e1c:0x7d7a74,.4+.5*th,1,.8,1.4)}}
  t.dk=(t.dk||0)-dt;if(t.v>3&&t.dk<=0){t.dk=.08;t.g.localToWorld(v2.set((Math.random()<.5?-1:1)*1.5,.2,-3.8));puff(v2,0xa89a78,.7,2.2,.5,1)}
  t.brkM.color.setHex(t.v<-.3||(t.v-t.pv)/Math.max(dt,.001)<-2?0xff2a1a:0x5a1410);t.pv=t.v;
  /* comandante sai da cupula quando parado */
  t.open+=clamp((Math.abs(t.v)<.6&&t.clk-t.lf>1.5?1:0)-t.open,-dt*1.6,dt*1.6);
  t.lid[0].rotation.x=-t.open*1.6;t.lid[1].rotation.x=-t.open*1.5;t.crew.visible=t.open>.05;t.crew.position.y=.8+t.open*.45;t.crew.rotation.y=Math.sin(now*.7+t.x)*.8;
  /* canhao: clarao pelos defletores, fumaca na boca, recuo longo */
  if(t.fT>0){t.fT-=dt;t.fl.visible=t.fT>0;t.fl.scale.setScalar(.7+Math.random()*.6)}
  if(t.ev>0){t.ev-=dt;t.ek=(t.ek||0)-dt;if(t.ek<=0){t.ek=.05;t.bar.localToWorld(v2.set(0,0,4.5));puff(v2,0xcfc8b8,.5,1.4,.9,.5)}}
  if(t.recoil>0){t.recoil=Math.max(0,t.recoil-dt*1.1);t.bar.position.z=-t.recoil*.7}
}
/* ======================================================================
   NOVOS VEICULOS: M3 Stuart, Mark I e Engesa EE-9 Cascavel
   ====================================================================== */
/* esteira em laco: elos individuais que percorrem o contorno do veiculo (cada lado gira em ritmo proprio) */
function trackLoop(pts,n,wid,xs){
  const seg=[],ax=new THREE.Vector3(1,0,0);let L=0;
  for(let i=0;i<pts.length;i++){const a=pts[i],b=pts[(i+1)%pts.length],dz=b[0]-a[0],dy=b[1]-a[1],l=Math.hypot(dz,dy);
    seg.push({a,dz,dy,l,s:L,q:new THREE.Quaternion().setFromAxisAngle(ax,-Math.atan2(dy,dz))});L+=l}
  const geo=mergeG([new THREE.BoxGeometry(wid,.07,L/n*.92),new THREE.BoxGeometry(wid*.45,.1,L/n*.4).translate(0,-.07,0)]);
  const mesh=new THREE.InstancedMesh(geo,new THREE.MeshLambertMaterial({color:0xffffff}),n*xs.length),c1=new THREE.Color(0x2b2c28),c2=new THREE.Color(0x44453f),m=new THREE.Matrix4(),p=new THREE.Vector3(),sc=new THREE.Vector3(1,1,1);
  for(let i=0;i<mesh.count;i++)mesh.setColorAt(i,i%2?c1:c2);
  mesh.frustumCulled=false;
  mesh.upd=(...ph)=>{
    for(let k=0;k<xs.length;k++)for(let i=0;i<n;i++){
      const s0=((i/n*L+ph[k])%L+L)%L;let j=0;while(j<seg.length-1&&seg[j+1].s<=s0)j++;
      const sg=seg[j],u=(s0-sg.s)/sg.l;p.set(xs[k],sg.a[1]+sg.dy*u,sg.a[0]+sg.dz*u);m.compose(p,sg.q,sc);mesh.setMatrixAt(k*n+i,m);
    }
    mesh.instanceMatrix.needsUpdate=true;
  };
  mesh.upd(0,0);return mesh;
}
/* distancia percorrida por cada esteira (curvas giram os lados em sentidos opostos) */
function trkStep(t,dt,gx){
  const om=(t.st||0)*(t.trn||1),a=(t.v+om*gx)*dt,b=(t.v-om*gx)*dt;t.p0+=a;t.p1+=b;
  if(a||b)t.trk.upd(-t.p0,-t.p1);
  return[a,b];
}
function mkLid(par,mat,x,y,z,r){const h=new THREE.Group();h.position.set(x,y,z-r);const m=new THREE.Mesh(new THREE.CylinderGeometry(r,r,.05,12),mat);m.position.z=r;h.add(m);par.add(h);return h}
function mkCrew(par,cm,hm,sk,x,y,z){
  const c=new THREE.Group();c.position.set(x,y,z);c.userData.by=y;
  const hd=new THREE.Mesh(new THREE.SphereGeometry(.13,8,6),hm);hd.scale.y=.75;hd.position.y=.78;
  c.add(bx(.34,.5,.22,cm,0,.3,0),new THREE.Mesh(new THREE.SphereGeometry(.11,8,6),sk).translateY(.68).translateZ(.04),hd);c.visible=false;par.add(c);return c;
}
function mkMG(par,x,y,z){const m=new THREE.Group();m.position.set(x,y,z);m.add(bx(.1,.14,.7,dark0,0,.1,.3),bx(.05,.05,1,dark0,0,.1,.95),bx(.08,.2,.08,dark0,0,0,0));par.add(m);return m}
function mgScan(t,dt,rng){t.rs=(t.rs||0)-dt;if(t.rs<=0){t.rs=.5;t.mgt=null;let best=rng;for(const o of tanks)if(!o.dead&&hostile(t,o)){const d=Math.hypot(o.x-t.x,o.z-t.z);if(d<best){best=d;t.mgt=o}}}}
function mgAim(t,dt,mg,base,dmg,tip,now){
  const o=t.mgt;
  if(o&&!o.dead){
    const df=angDiff(Math.atan2(o.x-t.x,o.z-t.z)-base,mg.rotation.y);mg.rotation.y+=clamp(df,-3.5*dt,3.5*dt);
    mg.userData.tm=(mg.userData.tm||0)-dt;
    if(Math.abs(df)<.12&&mg.userData.tm<=0){mg.userData.tm=.12+Math.random()*.04;damage(o,dmg,t);mg.localToWorld(v2.set(tip[0],tip[1],tip[2]));puff(v2,0xffe08a,.4,0,.1,0);v3.set(o.x,o.y+1.5,o.z).lerp(v2,Math.random()*.85);puff(v3,0xffe08a,.3,0,.12,0)}
  }else mg.rotation.y+=(Math.sin(now*.7+mg.position.x)*.8-mg.rotation.y)*Math.min(1,dt*2);
}
/* efeitos comuns: luz de freio, escapamento, poeira, escotilhas, clarao, ejetor, recuo */
function tankFx(t,dt,now,th,o){
  t.brkM.color.setHex(t.v<-.3||(t.v-t.pv)/Math.max(dt,.001)<-2?0xff2a1a:0x5a1410);t.pv=t.v;
  t.ex=(t.ex||0)-dt;if(t.ex<=0){t.ex=.14-.08*th;for(const e of o.ex){t.g.localToWorld(v2.set(e[0],e[1],e[2]));puff(v2,th>.5?0x2a2926:0x7d7a74,.4+.5*th,1,.8,1.4)}}
  t.dk=(t.dk||0)-dt;if(Math.abs(t.v)>3&&t.dk<=0){t.dk=.08;const e=o.dk[(Math.random()*o.dk.length)|0];t.g.localToWorld(v2.set(e[0],e[1],e[2]));puff(v2,0xa89a78,.7,2.2,.5,1)}
  t.open+=clamp((Math.abs(t.v)<.6&&t.clk-t.lf>1.5&&!t.mgt?1:0)-t.open,-dt*1.6,dt*1.6);
  t.lid[0].rotation.x=-t.open*1.6;t.lid[1].rotation.x=-t.open*1.5;t.crew.visible=t.open>.05;t.crew.position.y=t.crew.userData.by+t.open*.5;t.crew.rotation.y=Math.sin(now*.8+t.x)*.6;
  if(t.fT>0){t.fT-=dt;t.fl.visible=t.fT>0;t.fl.scale.setScalar(.7+Math.random()*.6)}
  if(t.ev>0){t.ev-=dt;t.ek=(t.ek||0)-dt;if(t.ek<=0){t.ek=.05;t.bar.localToWorld(v2.set(0,0,o.mz));puff(v2,0xcfc8b8,.45,1.2,.9,.5)}}
  if(t.recoil>0){t.recoil=Math.max(0,t.recoil-dt*o.rr);t.bar.position.z=-t.recoil*o.rc}
}

/* ---------- M3 Stuart (EUA): "Honey", suspensao VVSS, casco rebitado, canhao de 37 mm ---------- */
const stW=tw(.36),stS=tw(.5,1),stI=tw(.48),stR=tw(.18);
function makeStuart(color,fc){
  const mat=new THREE.MeshLambertMaterial({color:color||0x5d6540}),dark=new THREE.MeshLambertMaterial({color:0x2b2d28}),lamp=new THREE.MeshBasicMaterial({color:0xfff2b0}),brkM=new THREE.MeshBasicMaterial({color:0x5a1410}),
    flagM=new THREE.MeshBasicMaterial({color:fc||0xffb000,side:THREE.DoubleSide}),flashM=new THREE.MeshBasicMaterial({color:0xffc060,transparent:true,opacity:.95,depthWrite:false}),
    cm=new THREE.MeshLambertMaterial({color:0x55563a}),hm=new THREE.MeshLambertMaterial({color:0x3d4a2a}),sk=new THREE.MeshLambertMaterial({color:0xc9a27e}),
    DK=0x2b2d28,MT=0x4a4b42,RB=0x1b1b1a,GL=0x2a4a5c,g=new THREE.Group(),wheels=[],bogs=[],GX=1.55;
  g.rotation.order='YXZ';
  const trk=trackLoop([[-2,.1],[1.7,.1],[2.35,.5],[2.6,.95],[2.3,1.35],[1.4,1.5],[-1.2,1.5],[-2.4,1.35],[-2.8,.8],[-2.6,.3]],70,.62,[-GX,GX]);g.add(trk);
  const rw=(par,geo,x,y,z,r,s)=>{const w=new THREE.Mesh(geo,vcM);w.position.set(x,y,z);w.userData={r,s};par.add(w);wheels.push(w)};
  [[0,-GX],[1,GX]].forEach(([s,sx])=>{
    rw(g,stS,sx,.95,2.05,.5,s);rw(g,stI,sx,.8,-2.25,.48,s);
    for(const z of[-.95,0,.95])rw(g,stR,sx,1.28,z,.18,s);
    for(const z of[-1,.75]){ /* bogie VVSS: duas rodas, braco e mola vertical */
      const bg=new THREE.Group();bg.position.set(sx,.5,z);rw(bg,stW,0,0,-.4,.36,s);rw(bg,stW,0,0,.4,.36,s);
      bg.add(bx(.14,.12,1,dark,0,.05,0),bx(.2,.16,.2,dark,0,.2,0),new THREE.Mesh(new THREE.CylinderGeometry(.15,.15,.7,10),dark).translateY(.6),bx(.34,.1,.34,dark,0,.98,0));
      g.add(bg);bogs.push(bg);
    }
  });
  /* casco rebitado */
  const hull=new THREE.Group(),H=mb();
  H.b(2.7,.8,5.2,'M',0,1,-.1);H.b(2.4,.2,5,DK,0,.55,-.1);H.b(3.7,.45,3.6,'M',0,1.62,-.15);H.b(2.9,.8,.2,'M',0,.9,3);
  H.b(2.9,.14,1.9,'M',0,1.85,2.25,.63);H.b(2.7,.55,3.2,'M',0,2.12,-.1);H.b(3,.5,1,'M',0,1.6,-2.3);
  H.g(new THREE.SphereGeometry(.7,12,8).scale(1.1,.75,.8),'M',0,1.05,3.2);
  for(const s of[-1,1]){
    H.b(.6,.08,.5,MT,s*.65,2.2,1.9,.63);H.b(.8,.3,.4,'M',s*1.55,2,-.3);H.c(.17,.17,1,0x6f6a4c,s*1.55,2.08,.8,'z');
    H.c(.16,.16,.8,MT,s*.8,1.2,-3.1,'z');H.b(.15,.15,.2,MT,s*1,.75,-2.75);H.b(.4,.3,.08,DK,s*1.55,1.95,1.7);
    for(let k=0;k<12;k++){const z=-1.5+k*.27;H.b(.06,.06,.06,MT,s*1.37,2.3,z);H.b(.06,.06,.06,MT,s*1.37,1.96,z);H.b(.06,.06,.06,MT,s*1.86,1.7,-1.7+k*.28)}
    hull.add(bx(.3,.2,.08,lamp,s*1.55,1.95,1.75),bx(.3,.2,.08,brkM,s*1.3,1.1,-2.78));
  }
  H.c(.13,.13,.3,MT,.9,1.55,2.95,'z');H.c(.04,.04,.5,DK,.9,1.55,3.25,'z');H.g(new THREE.SphereGeometry(.16,8,6),MT,.9,1.55,2.88);
  for(let k=0;k<5;k++)H.b(1.8,.04,.08,MT,0,1.88,-2-k*.18);
  H.out(hull,mat);g.add(hull);
  const ant=new THREE.Group();ant.position.set(-1.5,1.9,-1.9);const rd=new THREE.Mesh(new THREE.CylinderGeometry(.015,.03,3.4,5),dark);rd.position.y=1.7;
  const fg=new THREE.Mesh(new THREE.PlaneGeometry(.55,.32),flagM);fg.position.set(0,3.2,.28);fg.rotation.y=Math.PI/2;ant.add(rd,fg);hull.add(ant);
  /* torre facetada com laterais inclinadas e mantelete */
  const tg=new THREE.Group(),T=mb();tg.position.set(0,2.4,-.15);
  T.c(1.25,1.3,.22,'M',0,.11,0,'y');T.b(2.2,.62,2,'M',0,.55,.05);T.b(.16,.6,1.9,'M',1.18,.56,.05,0,0,.2);T.b(.16,.6,1.9,'M',-1.18,.56,.05,0,0,-.2);
  T.b(2,.1,1.9,'M',0,.9,.05);T.b(1.9,.65,.25,'M',0,.55,1.12,-.3);T.b(2,.55,.55,'M',0,.5,-1.2);T.c(.12,.12,.2,MT,.1,.98,-.8,'y');
  T.c(.46,.5,.1,MT,.55,.97,-.35,'y');T.c(.4,.44,.1,MT,-.55,.94,-.45,'y');T.b(.3,.07,.04,GL,.5,.75,1.2);T.b(.3,.07,.04,GL,-.5,.75,1.2);
  for(const s of[-1,1])for(let k=0;k<7;k++)T.b(.07,.07,.07,MT,s*1.26,.72,-.8+k*.28);
  T.out(tg,mat);
  const cl=mkLid(tg,mat,.55,.99,-.35,.38),ll=mkLid(tg,mat,-.55,.95,-.45,.34),crew=mkCrew(tg,cm,hm,sk,.55,.55,-.35),cmg=mkMG(tg,0,.98,-.8);
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb(),K=mb();bp.position.set(0,.5,1.25);
  B.b(1.3,.55,.35,'M',0,0,.15);B.c(.28,.3,.3,RB,0,0,.4,'z');B.b(.3,.3,.3,'M',0,.28,-.05);B.c(.04,.04,.5,DK,.32,-.05,.55,'z');B.b(.18,.22,.1,GL,-.35,.2,.3);B.out(bp,mat);
  K.c(.14,.14,.9,'M',0,0,.85,'z');K.c(.1,.1,3,DK,0,0,1.6,'z');K.c(.13,.13,.14,DK,0,0,3.1,'z');K.out(bar,mat);
  const fl=new THREE.Group();fl.add(new THREE.Mesh(new THREE.ConeGeometry(.4,1.5,10).rotateX(-Math.PI/2),flashM).translateZ(3.8),new THREE.Mesh(new THREE.SphereGeometry(.35,8,6),flashM).translateZ(3.3));fl.visible=false;bar.add(fl);
  bp.add(bar);tg.add(bp);g.add(tg);g.traverse(o=>o.castShadow=true);fl.traverse(o=>o.castShadow=false);scene.add(g);
  const t={g,tg,bp,bar,hull,ant,lid:[cl,ll],crew,cmg,fl,brkM,wheels,bogs,trk,mat,dark,stuart:true,cannon:true,spd:1.2,trn:1.05,L:3,W:1.8,mz:3.4,fk:.7,rld:1.3,wd:1.4,TY:2.4,
    x:0,z:0,y:0,hd:0,v:0,pv:0,yaw:0,pitch:.06,cd:0,hp:80,dead:false,phase:0,p0:0,p1:0,recoil:0,clk:0,lf:-9,ev:0,fT:0,open:0};
  tanks.push(t);return t;
}
function animStuart(t,dt){
  const now=performance.now()/1000;t.clk+=dt;if(t.dead)return blowOff(t,dt,t.TY);
  const th=clamp(Math.abs(t.v)/13,0,1),d=trkStep(t,dt,1.55);
  for(const w of t.wheels)w.rotation.x+=d[w.userData.s]/w.userData.r;
  t.bogs.forEach((b,i)=>b.rotation.x=Math.sin(now*9+i*1.9)*.04*th);
  t.hull.position.y=Math.sin(now*34+t.x)*(.008+.012*th)-t.recoil*.03;t.hull.rotation.x=-t.recoil*.02;t.ant.rotation.x=-t.v*.012+Math.sin(now*3+t.z)*.03;
  tankFx(t,dt,now,th,{ex:[[.8,1.3,-3.5]],dk:[[1.55,.2,-2.9],[-1.55,.2,-2.9]],mz:3.1,rr:1.6,rc:.55});
  mgScan(t,dt,50);mgAim(t,dt,t.cmg,t.yaw,.7,[0,.1,1.45],now);
}

/* ---------- Mark I (Reino Unido, 1916): casco rombóide, esteiras em volta de tudo, sponsons e cauda de direção ---------- */
const mkT=canvasTex(128,128,(x,w,h)=>{x.fillStyle='#fff';x.fillRect(0,0,w,h);const cs=['#d8d1ad','#b9ae82','#9a8a60'];for(let i=0;i<22;i++){x.fillStyle=cs[i%3];x.beginPath();x.ellipse(Math.random()*w,Math.random()*h,8+Math.random()*22,5+Math.random()*12,Math.random()*3,0,7);x.fill()}});
const mkWh=tw(.3),mkSp=tw(.6,1),mkTail=tw(.9),mkRl=tw(.2);
function makeMarkI(color,fc){
  const mat=new THREE.MeshLambertMaterial({color:color||0xa39a6c,map:mkT}),dark=new THREE.MeshLambertMaterial({color:0x2b2d28}),wood=new THREE.MeshLambertMaterial({color:0x6a5232}),
    redM=new THREE.MeshLambertMaterial({color:0xb02a24}),whiteM=new THREE.MeshLambertMaterial({color:0xe8e2d0}),brkM=new THREE.MeshBasicMaterial({color:0x5a1410}),
    flagM=new THREE.MeshBasicMaterial({color:fc||0xffb000,side:THREE.DoubleSide}),flashM=new THREE.MeshBasicMaterial({color:0xffc060,transparent:true,opacity:.95,depthWrite:false}),
    cm=new THREE.MeshLambertMaterial({color:0x6a6a4a}),hm=new THREE.MeshLambertMaterial({color:0x4a4a40}),sk=new THREE.MeshLambertMaterial({color:0xc9a27e}),
    DK=0x2b2d28,MT=0x4a4b42,GL=0x1d2f3a,g=new THREE.Group(),wheels=[],tailW=[],GX=1.7;
  g.rotation.order='YXZ';
  const trk=trackLoop([[-2.9,.4],[2.2,.4],[3.4,.95],[4,1.9],[3.3,2.7],[-2.7,2.7],[-3.7,1.9],[-3.5,.9]],76,.72,[-GX,GX]);g.add(trk);
  const rw=(par,geo,x,y,z,r,s)=>{const w=new THREE.Mesh(geo,vcM);w.position.set(x,y,z);w.userData={r,s};par.add(w);wheels.push(w)};
  [[0,-GX],[1,GX]].forEach(([s,sx])=>{
    rw(g,mkSp,sx,1.55,-3,.6,s);rw(g,mkSp,sx,1.85,3.2,.55,s);
    for(let k=0;k<5;k++)rw(g,mkWh,sx,.75,-2.2+k,.3,s);
    for(const z of[-1.5,0,1.5])rw(g,mkRl,sx,2.35,z,.2,s);
  });
  const hull=new THREE.Group(),H=mb();
  H.b(2.8,1.8,5.8,'M',0,1.7,-.2);H.b(2.8,1.4,.8,'M',0,1.5,3.2);H.b(2.8,1.6,.2,'M',0,1.6,-3.05);H.b(2.2,.6,1.6,'M',0,3,1.6);H.b(2.2,.12,.7,'M',0,3.3,2.55,.5);
  H.b(1.6,.5,1.4,MT,0,2.85,-2.15);H.c(.12,.12,1,MT,.45,3.4,-2.1,'y');H.c(.2,.2,.1,DK,.45,3.95,-2.1,'y');
  for(const s of[-1,1]){
    H.b(1.3,1.35,2.3,'M',s*2.35,1.35,.5);H.b(1.3,1,.2,'M',s*2.4,1.35,1.75,0,s*.5);H.b(.05,.9,.5,DK,s*3.02,1.3,-.2);
    H.c(.13,.13,1.6,DK,s*2.5,1.45,2.55,'z');H.b(.5,.5,.3,MT,s*2.5,1.45,1.85);H.c(.06,.06,.7,DK,s*2.1,1.95,1.9,'z');
    H.b(.1,.18,5.4,MT,s*.9,2.7,-.2);H.b(.1,.3,.3,MT,s*1,2.85,-3);H.b(.7,.2,.4,'M',s*.6,3.4,1.3);H.b(.3,.07,.04,GL,s*.5,3.1,2.43);
    for(let k=0;k<20;k++){H.b(.07,.07,.07,MT,s*1.3,2.64,-3+k*.3);if(k<8)H.b(.07,.07,.07,MT,s*3.02,k%2?.9:1.8,-.5+Math.floor(k/2)*.5)}
  }
  for(let k=0;k<6;k++)H.b(.07,.07,.07,MT,-1.05+k*.42,3.62,1.75);
  H.out(hull,mat);g.add(hull);
  hull.add(bx(.4,.5,.05,redM,-.4,3.05,2.43),bx(.4,.5,.05,whiteM,0,3.05,2.43),bx(.4,.5,.05,redM,.4,3.05,2.43),bx(4.2,.35,.35,wood,0,3.05,-3.05),bx(.3,.2,.08,brkM,1.2,1.2,-3.18),bx(.3,.2,.08,brkM,-1.2,1.2,-3.18));
  const mgs=[mkMG(hull,-2.15,1.95,1.5),mkMG(hull,2.15,1.95,1.5)];
  const cl=mkLid(hull,mat,-.5,3.34,1.4,.3),ll=mkLid(hull,mat,.5,3.34,1.4,.3),crew=mkCrew(hull,cm,hm,sk,.5,2.85,1.4);
  const ant=new THREE.Group();ant.position.set(-1.1,2.75,-3);const rd=new THREE.Mesh(new THREE.CylinderGeometry(.015,.03,3,5),dark);rd.position.y=1.5;
  const fg=new THREE.Mesh(new THREE.PlaneGeometry(.55,.32),flagM);fg.position.set(0,2.85,.28);fg.rotation.y=Math.PI/2;ant.add(rd,fg);hull.add(ant);
  /* cauda de direcao com duas rodas grandes */
  const tail=new THREE.Group();tail.position.set(0,.9,-3.4);
  tail.add(bx(2,.15,.15,dark,0,0,-1.7),bx(.12,.14,1.7,dark,.85,.25,-.85),bx(.12,.14,1.7,dark,-.85,.25,-.85),bx(.4,.3,.4,dark,0,.35,-.1));
  for(const s of[-1,1]){const w=new THREE.Mesh(mkTail,vcM);w.position.set(s*.95,0,-1.7);tail.add(w);tailW.push(w)}
  g.add(tail);
  /* torre-canhao giratoria sobre o teto */
  const tg=new THREE.Group(),T=mb();tg.position.set(0,2.7,-.4);
  T.c(1.05,1.1,.7,'M',0,.35,0,'y');T.c(.95,.95,.08,DK,0,.72,0,'y');T.b(1.4,.8,.4,'M',0,.45,.95);T.c(.1,.1,.4,MT,.5,.95,-.4,'y');
  for(let k=0;k<10;k++){const a=k/10*6.283;T.b(.07,.07,.07,MT,Math.sin(a)*1.08,.5,Math.cos(a)*1.08)}
  T.out(tg,mat);
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb(),K=mb();bp.position.set(0,.45,1.15);
  B.b(.8,.6,.3,'M',0,0,.05);B.c(.22,.22,.5,DK,0,0,.35,'z');B.out(bp,mat);
  K.c(.2,.2,.8,'M',0,0,.7,'z');K.c(.12,.12,3,DK,0,0,1.7,'z');K.c(.15,.15,.12,DK,0,0,3.2,'z');K.out(bar,mat);
  const fl=new THREE.Group();fl.add(new THREE.Mesh(new THREE.ConeGeometry(.45,1.6,10).rotateX(-Math.PI/2),flashM).translateZ(4),new THREE.Mesh(new THREE.SphereGeometry(.4,8,6),flashM).translateZ(3.4));fl.visible=false;bar.add(fl);
  bp.add(bar);tg.add(bp);g.add(tg);g.traverse(o=>o.castShadow=true);fl.traverse(o=>o.castShadow=false);scene.add(g);
  const t={g,tg,bp,bar,hull,ant,lid:[cl,ll],crew,mgs,tail,tailW,fl,brkM,wheels,trk,mat,dark,mk1:true,cannon:true,spd:.5,trn:.55,L:3.6,W:2.2,mz:3.4,fk:1,rld:2.6,armor:.85,wd:1.7,TY:2.7,
    x:0,z:0,y:0,hd:0,v:0,pv:0,yaw:0,pitch:.06,cd:0,hp:130,dead:false,phase:0,p0:0,p1:0,recoil:0,clk:0,lf:-9,ev:0,fT:0,open:0};
  tanks.push(t);return t;
}
function animMarkI(t,dt){
  const now=performance.now()/1000;t.clk+=dt;if(t.dead)return blowOff(t,dt,t.TY);
  const th=clamp(Math.abs(t.v)/7,0,1),d=trkStep(t,dt,1.7);
  for(const w of t.wheels)w.rotation.x+=d[w.userData.s]/w.userData.r;
  for(const w of t.tailW)w.rotation.x+=(d[0]+d[1])/2/.9;
  t.tail.rotation.y+=((t.st||0)*.45-t.tail.rotation.y)*Math.min(1,dt*3);
  t.hull.position.y=Math.sin(now*22+t.x)*(.015+.02*th)-t.recoil*.03;t.hull.rotation.x=-t.recoil*.015;t.ant.rotation.x=-t.v*.012+Math.sin(now*3+t.z)*.03;
  tankFx(t,dt,now,th,{ex:[[.45,4,-2.1],[.45,3.9,-2.1]],dk:[[1.7,.3,-3.9],[-1.7,.3,-3.9],[0,.3,-5.1]],mz:3.2,rr:1.4,rc:.6});
  mgScan(t,dt,45);for(const m of t.mgs)mgAim(t,dt,m,t.hd,.6,[0,.1,1.45],now);
}

/* ---------- Engesa EE-9 Cascavel (Brasil): 6x6, canhao Cockerill de 90 mm, suspensao Boomerang ---------- */
const cwG=(()=>{
  const R=.62,l=[vcol(new THREE.CylinderGeometry(R,R,.5,18).rotateZ(Math.PI/2),0x1b1b1a),vcol(new THREE.CylinderGeometry(.34,.34,.56,12).rotateZ(Math.PI/2),0x4a4b42),vcol(new THREE.CylinderGeometry(.18,.18,.62,10).rotateZ(Math.PI/2),0x2b2d28)];
  for(let k=0;k<16;k++){const a=k/16*6.283,b=new THREE.BoxGeometry(.52,.12,.2);b.rotateX(Math.PI/2-a);b.translate(0,Math.sin(a)*(R+.03),Math.cos(a)*(R+.03));l.push(vcol(b,0x151514))}
  for(let k=0;k<6;k++){const a=k/6*6.283,b=new THREE.CylinderGeometry(.04,.04,.6,6).rotateZ(Math.PI/2);b.translate(0,Math.sin(a)*.26,Math.cos(a)*.26);l.push(vcol(b,0x2b2d28))}
  return mergeG(l);
})();
function makeCascavel(color,fc){
  const mat=new THREE.MeshLambertMaterial({color:color||0x6a7048}),dark=new THREE.MeshLambertMaterial({color:0x2b2d28}),lamp=new THREE.MeshBasicMaterial({color:0xfff2b0}),brkM=new THREE.MeshBasicMaterial({color:0x5a1410}),
    flagM=new THREE.MeshBasicMaterial({color:fc||0xffb000,side:THREE.DoubleSide}),flashM=new THREE.MeshBasicMaterial({color:0xffc060,transparent:true,opacity:.95,depthWrite:false}),
    cm=new THREE.MeshLambertMaterial({color:0x55563a}),hm=new THREE.MeshLambertMaterial({color:0x3d4a2a}),sk=new THREE.MeshLambertMaterial({color:0xc9a27e}),metal=new THREE.MeshLambertMaterial({color:0x4a4b42}),
    DK=0x2b2d28,MT=0x4a4b42,RB=0x1b1b1a,GL=0x2a4a5c,g=new THREE.Group(),wheels=[],steers=[],booms=[];
  g.rotation.order='YXZ';
  const mw=(par,x,y,z)=>{const w=new THREE.Mesh(cwG,vcM);w.position.set(x,y,z);w.userData={r:.62};par.add(w);wheels.push(w)};
  for(const s of[-1,1]){
    const sg=new THREE.Group();sg.position.set(s*1.5,.62,2.6);mw(sg,0,0,0);sg.add(bx(.2,.2,.5,dark,-s*.3,.15,0));g.add(sg);steers.push(sg);
    const bm=new THREE.Group();bm.position.set(s*1.5,.75,-2.15);mw(bm,0,-.13,.75);mw(bm,0,-.13,-.75);
    const a1=bx(.2,.22,.95,dark,-s*.28,-.02,.4),a2=bx(.2,.22,.95,dark,-s*.28,-.02,-.4);a1.rotation.x=-.28;a2.rotation.x=.28;
    bm.add(a1,a2,new THREE.Mesh(new THREE.CylinderGeometry(.15,.15,.5,10).rotateZ(Math.PI/2),metal).translateX(-s*.3));g.add(bm);booms.push(bm);
  }
  const hull=new THREE.Group(),H=mb(),fp=[];
  H.b(2.7,.75,6,'M',0,1,0);H.b(2.2,.5,5.2,'M',0,1.65,-.2);H.b(2.5,.12,1.05,'M',0,1.6,2.7,.64);H.b(2.7,.75,.15,'M',0,1,3.05);H.b(2.2,.18,1.8,'M',0,1.95,-2.2);
  H.b(.8,.28,.8,'M',-.65,2.02,1.8);H.b(.5,.07,.04,GL,-.65,2.05,2.22);H.b(2.8,.2,.2,DK,0,.75,3.15);
  for(let k=0;k<5;k++)H.b(1.6,.04,.08,MT,0,2.06,-1.8-k*.2);
  for(const s of[-1,1]){
    H.b(.95,.1,1.6,'M',s*1.5,1.42,2.6);H.b(.95,.1,3.4,'M',s*1.5,1.42,-2.15);H.b(.9,.5,.05,RB,s*1.5,.7,-3.65);H.b(.9,.4,.05,RB,s*1.5,.7,3.25);
    H.b(.6,.2,.3,'M',s*1.5,1.58,-2);H.b(.3,.4,.2,0x55563a,s*1.5,1.7,-2.9);H.b(.4,.1,.2,MT,s*1.5,1.55,3.1);H.b(.3,.3,.15,MT,s*.8,.7,3.2);
    H.b(.4,.12,5,'M',s*1.2,1.55,-.2,0,0,s*.5);
  }
  H.c(.13,.13,1.2,MT,-1,1.7,-3,'z');H.c(.2,.2,.5,DK,-1,1.7,-3.45,'z');H.c(.04,.04,1.5,MT,1.2,1.6,-3,'y');
  H.out(hull,mat);g.add(hull);
  hull.add(bx(.35,.25,.1,lamp,-1.3,1.55,3.3),bx(.35,.25,.1,lamp,1.3,1.55,3.3),bx(.3,.2,.08,brkM,1.2,1.1,-3.05),bx(.3,.2,.08,brkM,-1.2,1.1,-3.05));
  const ant=new THREE.Group();ant.position.set(-1.5,1.55,-2.9);const rd=new THREE.Mesh(new THREE.CylinderGeometry(.015,.03,3.4,5),dark);rd.position.y=1.7;
  const fg=new THREE.Mesh(new THREE.PlaneGeometry(.55,.32),flagM);fg.position.set(0,3.2,.28);fg.rotation.y=Math.PI/2;ant.add(rd,fg);hull.add(ant);
  /* torre fundida em cupula, cesto traseiro, lancadores de fumaca */
  const tg=new THREE.Group(),T=mb();tg.position.set(0,1.9,.2);
  T.c(1.2,1.3,.2,'M',0,.1,0,'y');T.c(1.25,1.35,.5,'M',0,.35,0,'y');T.g(new THREE.SphereGeometry(1,18,12).scale(1.3,.6,1.45),'M',0,.5,0);
  T.b(1.9,.5,.8,'M',0,.45,-1.3);T.b(1.9,.06,.6,MT,0,.75,-1.75);T.c(.42,.46,.3,MT,.65,.98,-.4,'y');T.c(.4,.42,.1,MT,-.6,.9,-.3,'y');
  T.b(.4,.3,.5,DK,.75,.8,.9);T.b(.2,.15,.05,GL,.75,.82,1.18);
  for(const s of[-1,1])for(let k=0;k<3;k++)T.c(.05,.05,.3,DK,s*1.2,.7,.2+k*.13,'y',0,0,-s*.4);
  T.out(tg,mat);
  const cl=mkLid(tg,mat,.65,1.04,-.4,.36),ll=mkLid(tg,mat,-.6,.96,-.3,.34),crew=mkCrew(tg,cm,hm,sk,.65,.55,-.4),cmg=mkMG(tg,.65,1.2,-.4);
  const bp=new THREE.Group(),bar=new THREE.Group(),B=mb(),K=mb();bp.position.set(0,.5,1.35);
  B.b(1.3,.7,.5,'M',0,0,.15);B.c(.3,.34,.4,RB,0,0,.45,'z');B.c(.04,.04,.5,DK,.35,-.05,.6,'z');B.out(bp,mat);
  K.c(.16,.14,1.2,'M',0,0,.9,'z');K.c(.12,.12,4.4,DK,0,0,2.7,'z');K.c(.2,.2,.9,'M',0,0,2.5,'z');K.c(.2,.2,.55,DK,0,0,4.7,'z');K.b(.5,.06,.12,MT,0,0,4.7);K.b(.06,.5,.12,MT,0,0,4.7);K.out(bar,mat);
  const fl=new THREE.Group();fl.add(new THREE.Mesh(new THREE.ConeGeometry(.5,1.8,10).rotateX(-Math.PI/2),flashM).translateZ(5.6),new THREE.Mesh(new THREE.SphereGeometry(.32,8,6),flashM).translateX(.45).translateZ(4.7),new THREE.Mesh(new THREE.SphereGeometry(.32,8,6),flashM).translateX(-.45).translateZ(4.7));fl.visible=false;bar.add(fl);
  bp.add(bar);tg.add(bp);g.add(tg);g.traverse(o=>o.castShadow=true);fl.traverse(o=>o.castShadow=false);scene.add(g);
  const t={g,tg,bp,bar,hull,ant,lid:[cl,ll],crew,cmg,fl,brkM,wheels,steers,booms,mat,dark,casc:true,cannon:true,spd:1.3,trn:.9,L:3.2,W:1.5,mz:5.1,fk:.95,rld:2.1,wd:1.2,TY:1.9,
    x:0,z:0,y:0,hd:0,v:0,pv:0,yaw:0,pitch:.06,cd:0,hp:90,dead:false,phase:0,recoil:0,clk:0,lf:-9,ev:0,fT:0,open:0};
  /* detalhes extras: estepe, galoes, ganchos de reboque, holofote, periscopio giratorio, abas de lama e fumaca */
  const sp=new THREE.Mesh(cwG,vcM);sp.rotation.y=Math.PI/2;sp.scale.setScalar(.8);sp.position.set(.2,1.55,-3.35);hull.add(sp);
  hull.add(bx(.12,.5,.12,metal,-.2,1.5,-3.2),bx(.12,.5,.12,metal,.6,1.5,-3.2));
  for(const s of[-1,1]){hull.add(bx(.22,.45,.36,cm,s*1.5,1.72,-2.6),bx(.22,.45,.36,cm,s*1.5,1.72,-2.2),bx(.18,.2,.35,metal,s*.5,.75,3.35),bx(.06,.06,1.4,dark,s*1.1,1.55,3.1));
    const f=new THREE.Group();f.position.set(s*1.5,.95,3.28);f.add(bx(.9,.4,.05,dark,0,-.2,0));hull.add(f);fp.push(f)}
  tg.add(bx(.3,.3,.4,lamp,-.9,.95,.7));
  const peri=new THREE.Group();peri.position.set(.1,1.0,-.9);peri.add(bx(.22,.22,.3,dark,0,.12,0),bx(.16,.1,.04,new THREE.MeshLambertMaterial({color:GL}),0,.14,.17));tg.add(peri);
  Object.assign(t,{peri,fp,sp,lhp:90,sm:0,sq:[]});
  tanks.push(t);return t;
}
function animCasc(t,dt){
  const now=performance.now()/1000;t.clk+=dt;if(t.dead)return blowOff(t,dt,t.TY);
  const th=clamp(Math.abs(t.v)/14,0,1),ph=t.v*dt;t.phase+=ph;
  for(const w of t.wheels)w.rotation.x+=ph/.62;
  for(const s of t.steers)s.rotation.y+=((t.st||0)*.45-s.rotation.y)*Math.min(1,dt*6);
  t.booms.forEach((b,i)=>b.rotation.x=Math.sin(now*6+i*2.4)*.1*th+clamp((t.v-t.pv)*.01,-.1,.1));
  t.hull.position.y=Math.sin(now*28+t.x)*(.01+.014*th)-t.recoil*.04;t.hull.rotation.z=-(t.st||0)*th*.025;t.hull.rotation.x=-t.recoil*.02;
  t.ant.rotation.x=-t.v*.012+Math.sin(now*3+t.z)*.03;
  tankFx(t,dt,now,th,{ex:[[-1,1.7,-3.9]],dk:[[1.5,.2,-3.4],[-1.5,.2,-3.4],[1.5,.2,-3.4]],mz:4.9,rr:1.2,rc:.8});
  mgScan(t,dt,55);mgAim(t,dt,t.cmg,t.yaw,.8,[0,.1,1.45],now);smokeQ(t,dt,1.2,.8,.5);t.peri.rotation.y=Math.sin(now*.9+t.x)*1.6;for(const f of t.fp)f.rotation.x=clamp(-t.v*.03,-.5,.5)+Math.sin(now*14+f.position.x)*.05*th;
}
/* ======================================================================
   T-34/85 e T-35 (URSS), Leopard 2A6 (Alemanha) e PL-01 (Polonia)
   ====================================================================== */
const mm=fc=>({dark:new THREE.MeshLambertMaterial({color:0x2b2d28}),lamp:new THREE.MeshBasicMaterial({color:0xfff2b0}),brkM:new THREE.MeshBasicMaterial({color:0x5a1410}),flagM:new THREE.MeshBasicMaterial({color:fc||0xffb000,side:THREE.DoubleSide}),flashM:new THREE.MeshBasicMaterial({color:0xffc060,transparent:true,opacity:.95,depthWrite:false}),cm:new THREE.MeshLambertMaterial({color:0x55563a}),hm:new THREE.MeshLambertMaterial({color:0x3d4a2a}),sk:new THREE.MeshLambertMaterial({color:0xc9a27e}),gl:new THREE.MeshLambertMaterial({color:0x2a4a5c,emissive:0x0a2a3a})});
const mat0=(c,m)=>new THREE.MeshLambertMaterial(m?{color:c,map:m}:{color:c});
const gW=tw(.42),gS=tw(.38,1),gW5=tw(.38),gS5=tw(.5,1),gWL=tw(.46),gSL=tw(.52,1),gRL=tw(.16);
const wl=(p,G,x,y,z,r,s,W)=>{const w=new THREE.Mesh(G,vcM);w.position.set(x,y,z);w.userData={r,s};p.add(w);W.push(w);return w};
const mkFl=(bar,z,r,fm)=>{const f=new THREE.Group();f.add(new THREE.Mesh(new THREE.ConeGeometry(r,r*3.6,10).rotateX(-Math.PI/2),fm).translateZ(z+r*1.8),new THREE.Mesh(new THREE.SphereGeometry(r*.8,8,6),fm).translateZ(z));f.visible=false;bar.add(f);return f};
const mkAnt=(p,x,y,z,fm)=>{const a=new THREE.Group();a.position.set(x,y,z);const r=new THREE.Mesh(new THREE.CylinderGeometry(.015,.03,3.4,5),dark0);r.position.y=1.7;const f=new THREE.Mesh(new THREE.PlaneGeometry(.55,.32),fm);f.position.set(0,3.2,.28);f.rotation.y=Math.PI/2;a.add(r,f);p.add(a);return a};
const numTx=s=>canvasTex(128,64,(x,w,h)=>{x.font='700 40px Arial,sans-serif';x.textAlign='center';x.textBaseline='middle';x.lineWidth=6;x.strokeStyle='#111';x.strokeText(s,w/2,h/2);x.fillStyle='#f3ecd8';x.fillText(s,w/2,h/2)});
const stk=(p,tex,x,y,z,s,w,h)=>{const m=new THREE.Mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshBasicMaterial({map:tex,transparent:true}));m.position.set(x,y,z);m.rotation.y=s*Math.PI/2;p.add(m)};
const lpT=canvasTex(128,128,(x,w,h)=>{x.fillStyle='#fff';x.fillRect(0,0,w,h);const cs=['#8a6c4c','#4a4a40','#a08a5a'];for(let i=0;i<24;i++){x.fillStyle=cs[i%3];x.beginPath();x.ellipse(Math.random()*w,Math.random()*h,8+Math.random()*22,5+Math.random()*10,Math.random()*3,0,7);x.fill()}});
const plT=canvasTex(128,128,(x,w,h)=>{x.fillStyle='#fff';x.fillRect(0,0,w,h);const cs=['#cfd4cc','#aab2a8','#8d968c'];for(let i=0;i<70;i++){x.fillStyle=cs[i%3];x.fillRect((Math.random()*w/8|0)*8,(Math.random()*h/8|0)*8,8*(1+(Math.random()*3|0)),8)}});
plT.wrapS=plT.wrapT=THREE.RepeatWrapping;
const t34N=numTx('T-34'),t35N=numTx('T-35');
const base=o=>Object.assign({x:0,z:0,y:0,hd:0,v:0,pv:0,yaw:0,pitch:.06,cd:0,hp:100,lhp:100,dead:false,phase:0,p0:0,p1:0,recoil:0,clk:0,lf:-9,ev:0,fT:0,open:0,sm:0,sq:[]},o);
const fin=t=>{t.g.traverse(o=>o.castShadow=true);t.fl.traverse(o=>o.castShadow=false);scene.add(t.g);tanks.push(t);return t};
/* torreta secundaria (T-35): corpo, canhao e recuo proprios */
const subT=(p,mat,x,y,z,r,L,gr,dmg,per,rng,sz,ph)=>{const g=new THREE.Group();g.position.set(x,y,z);
  g.add(new THREE.Mesh(new THREE.CylinderGeometry(r,r*1.12,.4,10),mat).translateY(.2),new THREE.Mesh(new THREE.CylinderGeometry(r*.8,r,.12,10),mat).translateY(.46),new THREE.Mesh(new THREE.SphereGeometry(r*.35,8,5),dark0).translateY(.58));
  const br=new THREE.Group();br.position.set(0,.28,r*.9);const b=new THREE.Mesh(new THREE.CylinderGeometry(gr,gr*1.1,L,6).rotateX(Math.PI/2),dark0);b.position.z=L/2;br.add(b);g.add(br);p.add(g);
  return{g,br,dmg,per,rng,sz,ph,tm:0,rc:0,z0:r*.9,tip:[0,.28,r*.9+L]}};
function subAim(t,dt,u,base,now){
  const o=t.mgt;
  if(o&&!o.dead&&Math.hypot(o.x-t.x,o.z-t.z)<u.rng){
    const df=angDiff(Math.atan2(o.x-t.x,o.z-t.z)-base,u.g.rotation.y);u.g.rotation.y+=clamp(df,-2.5*dt,2.5*dt);u.tm-=dt;
    if(Math.abs(df)<.12&&u.tm<=0){u.tm=u.per*(.9+Math.random()*.2);damage(o,u.dmg,t);u.g.localToWorld(v2.set(u.tip[0],u.tip[1],u.tip[2]));puff(v2,0xffe08a,u.sz,0,.1,0);v3.set(o.x,o.y+1.5,o.z).lerp(v2,Math.random()*.85);puff(v3,0xffe08a,.3,0,.12,0);u.rc=1}
  }else u.g.rotation.y+=(Math.sin(now*.7+u.ph)*.9-u.g.rotation.y)*Math.min(1,dt*2);
  if(u.rc>0){u.rc=Math.max(0,u.rc-dt*6);u.br.position.z=u.z0-u.rc*.18}
}
/* granadas de fumaca quando o blindado leva dano forte */
function smokeQ(t,dt,x,y,z){
  t.sm=Math.max(0,t.sm-dt);
  if(t.lhp-t.hp>6&&t.sm<=0){t.sm=14;for(const s of[-1,1])for(let k=0;k<8;k++){t.tg.localToWorld(v2.set(s*x,y,z+k*.12));puff(v2,0xf4f2ec,.5,1,.4,1.5);t.sq.push({d:k*.07+(s>0?.03:0),a:t.yaw+s*(.25+k*.1),r:8+k*1.4})}}
  t.lhp=t.hp;
  for(let i=t.sq.length-1;i>=0;i--){const q=t.sq[i];q.d-=dt;if(q.d<=0){const X=t.x+Math.sin(q.a)*q.r,Z=t.z+Math.cos(q.a)*q.r;v2.set(X,getH(X,Z)+1.8,Z);for(let j=0;j<2;j++)puff(v2,0xf4f2ec,2.8,3,6.5,.8);t.sq.splice(i,1)}}
}

