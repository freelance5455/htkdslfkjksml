/* UrbaAlerte — données de démonstration (FICTIVES, marquées DÉMO), générées autour d'une position centrale */
(function(w){
'use strict';
function rng(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
const D={
 DESC:{voirie:['Gros nid-de-poule au milieu de la chaussée, les motos se déportent dangereusement.','Route coupée après les pluies, les véhicules ne passent plus.'],
 erosion:['Ravin qui avance vers les maisons après la dernière pluie, plusieurs parcelles menacées.','Glissement de terrain sur la pente, la route est fissurée.'],
 inondation:['Caniveau bouché, l’eau envahit la chaussée et entre dans les parcelles.','Eau stagnante au carrefour depuis la pluie de cette nuit.'],
 eau:['Fuite importante sur la conduite principale, eau gaspillée depuis hier.','Plus d’eau au robinet dans tout le quartier depuis deux jours.'],
 electricite:['Câble électrique tombé près de l’école, danger pour les enfants.','Transformateur en panne, le quartier est dans le noir.'],
 salubrite:['Dépôt d’ordures qui bloque le caniveau et dégage une forte odeur.','Décharge sauvage qui grandit au bord de la route.'],
 accident:['Collision entre un minibus et une moto, blessés sur place.','Camion en panne en travers de la route, circulation bloquée.'],
 incendie:['Début d’incendie dans un dépôt de charbon de bois, de la fumée épaisse.','Feu de broussailles qui approche des habitations.']},
 pick(r,a){return a[Math.floor(r()*a.length)]},
 mk(r,i,lat,lng,type,ageDays,mine){const st=ageDays>12?(r()<.55?'RESOLU':r()<.5?'EN_COURS':'CLOS'):ageDays>4?(['VALIDE','AFFECTE','EN_COURS','RESOLU'])[Math.floor(r()*4)]:(r()<.5?'EN_ATTENTE':'VALIDE');
  const t=Date.now()-ageDays*864e5;return {id:'demo-'+i,ref:'UA-D'+String(1000+i),userId:'demo',type,desc:D.pick(r,D.DESC[type]),lat,lng,acc:null,status:st,created:t,mediaIds:[],sync:'synced',demo:true,history:[{s:'EN_ATTENTE',t}]}},
 off(lat,lng,eastKm,northKm){return{lat:lat+northKm/111.32,lng:lng+eastKm/(111.32*Math.cos(lat*Math.PI/180))}},
 seed(c){const r=rng(20261006),out=[];let i=1;const T=TYPES.map(t=>t.id);
  const clusters=[[1.4,1.1,'erosion'],[-2.0,.6,'inondation'],[2.6,-1.5,'voirie'],[-.9,-2.2,'inondation'],[.2,2.8,'erosion'],[-3.1,-.9,'voirie']];
  clusters.forEach(cl=>{const n=6+Math.floor(r()*4),bt=cl[2];for(let k=0;k<n;k++){const p=D.off(c.lat,c.lng,cl[0]+(r()-.5)*.35,cl[1]+(r()-.5)*.35);const ty=r()<.65?bt:D.pick(r,T);out.push(D.mk(r,i++,p.lat,p.lng,ty,r()*18))}});
  for(let k=0;k<14;k++){const a=r()*Math.PI*2,d=.5+r()*4.2;const p=D.off(c.lat,c.lng,Math.cos(a)*d,Math.sin(a)*d);out.push(D.mk(r,i++,p.lat,p.lng,D.pick(r,T),r()*25))}
  /* quelques signalements très récents près de l'utilisateur */
  for(let k=0;k<3;k++){const a=r()*Math.PI*2,d=.3+r()*1.2;const p=D.off(c.lat,c.lng,Math.cos(a)*d,Math.sin(a)*d);const x=D.mk(r,i++,p.lat,p.lng,D.pick(r,T),r()*.5);x.status='EN_ATTENTE';out.push(x)}
  return out},
 spawn(c,n){const a=Math.random()*Math.PI*2,inside=Math.random()<.7,d=inside?.5+Math.random()*4.2:5.6+Math.random()*3;const p=D.off(c.lat,c.lng,Math.cos(a)*d,Math.sin(a)*d);
  const ty=TYPES[Math.floor(Math.random()*TYPES.length)].id,t=Date.now();return{id:'demo-live-'+t,ref:'UA-L'+String(t).slice(-5),userId:'demo',type:ty,desc:D.pick(Math.random,D.DESC[ty]),lat:p.lat,lng:p.lng,acc:null,status:'EN_ATTENTE',created:t,mediaIds:[],sync:'synced',demo:true,live:true,history:[{s:'EN_ATTENTE',t}]}}
};
w.DEMO=D;
})(window);
