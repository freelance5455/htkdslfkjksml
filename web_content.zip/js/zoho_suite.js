/**
 * Panchal Business Manager - Zoho Books-Inspired Extended Suite
 * Quick Create (Select Any 4 Modules), Live Project Timer & Time Entries,
 * Income & Expense Accrual/Cash Analytics, Top Expenses, Announcements/Help,
 * Documents Hub (Inbox / All Files / Folders), Notifications & Complete Settings.
 */
(function (global) {
  "use strict";

  const LS_KEYS = {
    QUICK_MODULES: "pbm_quick_create_modules_v1",
    TIMER: "pbm_active_timer_v1",
    TIME_ENTRIES: "pbm_time_entries_v1",
    ANNOUNCEMENTS: "pbm_announcements_v1",
    DOC_FILES: "pbm_document_files_v1",
    PREFS: "pbm_extended_prefs_v1",
    FEEDBACK: "pbm_app_feedback_v1"
  };

  const QUICK_MODULE_CATALOG = [
    { id: "new_customer", label: "New Customer", icon: "user", desc: "Add client or supplier ledger" },
    { id: "new_invoice", label: "New Invoice", icon: "file", desc: "Create GST Tax Invoice" },
    { id: "new_quote", label: "New Quote", icon: "quote", desc: "Create customer Quotation" },
    { id: "new_bill", label: "New Bill", icon: "bill", desc: "Record Supplier Purchase Bill" },
    { id: "new_expense", label: "New Expense", icon: "wallet", desc: "Record business expense" },
    { id: "record_mileage", label: "Record Mileage", icon: "car", desc: "Log travel distance & cost" },
    { id: "purchase_order", label: "Purchase Order", icon: "bag", desc: "Issue PO to supplier" },
    { id: "payments_made", label: "Payments Made", icon: "arrowUp", desc: "Record payment to vendor" },
    { id: "payments_received", label: "Payments Received", icon: "arrowDown", desc: "Record payment from client" },
    { id: "new_project", label: "Project", icon: "layers", desc: "Open contractor/interior site" },
    { id: "log_time", label: "Log Time", icon: "clock", desc: "Add billable project hours" },
    { id: "credit_note", label: "Credit Note", icon: "note", desc: "Issue sales return / credit" }
  ];

  const DEFAULT_QUICK_MODULES = ["new_invoice", "new_customer", "new_expense", "log_time"];

  const DEFAULT_PREFS = {
    openingScreen: "dashboard",
    mileageRatePerKm: 12,
    senderName: "Panchal Furnitures",
    replyToEmail: "",
    emailSignature: "Thank you for your business!\nRegards,\nPanchal Furnitures",
    paymentGatewayLabel: "UPI / Bank Transfer",
    enablePaymentLinks: true,
    imageResolution: "1024",
    scanReceiptEnhancement: true,
    appRating: 5
  };

  function readJson(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      if (!raw) return fallback;
      const parsed = JSON.parse(raw);
      return parsed == null ? fallback : parsed;
    } catch (e) {
      return fallback;
    }
  }

  function writeJson(key, val) {
    try {
      localStorage.setItem(key, JSON.stringify(val));
    } catch (e) {
      // Storage quota fallback
    }
  }

  function getPrefs() {
    return Object.assign({}, DEFAULT_PREFS, readJson(LS_KEYS.PREFS, {}));
  }

  function savePrefs(patch) {
    const next = Object.assign(getPrefs(), patch || {});
    writeJson(LS_KEYS.PREFS, next);
    return next;
  }

  function getSelectedQuickModules() {
    const saved = readJson(LS_KEYS.QUICK_MODULES, DEFAULT_QUICK_MODULES);
    if (!Array.isArray(saved) || saved.length === 0) return DEFAULT_QUICK_MODULES.slice();
    return saved
      .filter(function (id) {
        return QUICK_MODULE_CATALOG.some(function (m) { return m.id === id; });
      })
      .slice(0, 4);
  }

  function getModuleIconSvg(iconKey) {
    const icons = {
      user: '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle>',
      file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line>',
      quote: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>',
      bill: '<rect x="3" y="4" width="18" height="16" rx="2"></rect><line x1="7" y1="8" x2="17" y2="8"></line><line x1="7" y1="12" x2="13" y2="12"></line>',
      wallet: '<rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect><line x1="1" y1="10" x2="23" y2="10"></line>',
      car: '<path d="M14 16H9m10 0h3v-3.15a1 1 0 0 0-.84-.99L16 11l-2.7-3.6a1 1 0 0 0-.8-.4H5.24a2 2 0 0 0-1.8 1.1l-.8 1.63A6 6 0 0 0 2 12.42V16h2"></path><circle cx="6.5" cy="16.5" r="2.5"></circle><circle cx="16.5" cy="16.5" r="2.5"></circle>',
      bag: '<path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path><line x1="3" y1="6" x2="21" y2="6"></line>',
      arrowUp: '<line x1="12" y1="19" x2="12" y2="5"></line><polyline points="5 12 12 5 19 12"></polyline>',
      arrowDown: '<line x1="12" y1="5" x2="12" y2="19"></line><polyline points="19 12 12 19 5 12"></polyline>',
      layers: '<polygon points="12 2 2 7 12 12 22 7 12 2"></polygon><polyline points="2 17 12 22 22 17"></polyline><polyline points="2 12 12 17 22 12"></polyline>',
      clock: '<circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline>',
      note: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><line x1="9" y1="15" x2="15" y2="15"></line>'
    };
    const path = icons[iconKey] || icons.file;
    return `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${path}</svg>`;
  }

  function launchQuickModule(moduleId) {
    const app = global.PBM_APP;
    if (!app) return;

    if (moduleId === "new_invoice" && global.PBM_BILLING) {
      global.PBM_BILLING.openDocumentModal(null, "SALE_INVOICE");
    } else if (moduleId === "new_quote" && global.PBM_BILLING) {
      global.PBM_BILLING.openDocumentModal(null, "QUOTATION");
    } else if (moduleId === "new_bill" && global.PBM_BILLING) {
      global.PBM_BILLING.openDocumentModal(null, "PURCHASE_BILL");
    } else if (moduleId === "new_expense" && global.PBM_BILLING) {
      global.PBM_BILLING.openDocumentModal(null, "EXPENSE_VOUCHER");
    } else if (moduleId === "purchase_order" && global.PBM_BILLING) {
      global.PBM_BILLING.openDocumentModal(null, "PURCHASE_ORDER");
    } else if (moduleId === "payments_made" && global.PBM_BILLING) {
      global.PBM_BILLING.openDocumentModal(null, "PAYMENT");
    } else if (moduleId === "payments_received" && global.PBM_BILLING) {
      global.PBM_BILLING.openDocumentModal(null, "RECEIPT");
    } else if (moduleId === "credit_note" && global.PBM_BILLING) {
      global.PBM_BILLING.openDocumentModal(null, "CREDIT_NOTE");
    } else if (moduleId === "new_customer") {
      app.navigateTo("parties");
    } else if (moduleId === "new_project") {
      app.navigateTo("projects");
    } else if (moduleId === "log_time") {
      openLogTimeModal();
    } else if (moduleId === "record_mileage") {
      openMileageModal();
    } else {
      app.navigateTo("billing");
    }
  }

  function openQuickCreateModal(onUpdated) {
    const app = global.PBM_APP;
    let selected = getSelectedQuickModules();

    function renderModalBody() {
      const topCardsHtml = selected
        .map(function (id) {
          const mod = QUICK_MODULE_CATALOG.find(function (m) { return m.id === id; });
          if (!mod) return "";
          return `
            <button type="button" class="qc-shortcut-tile" data-qc-launch="${mod.id}">
              <span class="qc-tile-icon">${getModuleIconSvg(mod.icon)}</span>
              <span class="qc-tile-lbl">${app.escapeHtml(mod.label)}</span>
            </button>
          `;
        })
        .join("");

      const checklistHtml = QUICK_MODULE_CATALOG.map(function (mod) {
        const isChecked = selected.indexOf(mod.id) !== -1;
        return `
          <label class="qc-check-row ${isChecked ? "is-selected" : ""}">
            <div style="display:flex;align-items:center;gap:10px;min-width:0;">
              <span class="qc-row-icon">${getModuleIconSvg(mod.icon)}</span>
              <div>
                <div style="font-size:0.86rem;font-weight:600;color:var(--text-primary);">${app.escapeHtml(mod.label)}</div>
                <div style="font-size:0.74rem;color:var(--text-muted);">${app.escapeHtml(mod.desc)}</div>
              </div>
            </div>
            <input type="checkbox" data-qc-toggle="${mod.id}" ${isChecked ? "checked" : ""} />
          </label>
        `;
      }).join("");

      const html = `
        <div class="form-grid">
          <div>
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
              <strong style="font-size:0.86rem;">Your Top 4 Shortcuts (Tap to Launch)</strong>
              <span class="badge-pill" id="qcCountBadge">${selected.length} / 4 selected</span>
            </div>
            <div class="qc-top-grid" id="qcTopGrid">${topCardsHtml || '<div class="list-item-meta">Select up to 4 modules below</div>'}</div>
          </div>

          <div>
            <label class="form-label">Select Any 4 Modules</label>
            <div class="qc-checklist" id="qcChecklist">${checklistHtml}</div>
          </div>

          <div class="modal-actions">
            <button type="button" id="qcCancelBtn" class="secondary-btn">Close</button>
            <button type="button" id="qcSaveBtn" class="primary-btn">Save Shortcuts</button>
          </div>
        </div>
      `;

      app.openModal("Quick Create Modules", html);

      document.querySelectorAll("[data-qc-launch]").forEach(function (btn) {
        btn.addEventListener("click", function () {
          const mid = btn.getAttribute("data-qc-launch");
          app.closeModal();
          launchQuickModule(mid);
        });
      });

      document.querySelectorAll("[data-qc-toggle]").forEach(function (chk) {
        chk.addEventListener("change", function () {
          const mid = chk.getAttribute("data-qc-toggle");
          if (chk.checked) {
            if (selected.length >= 4) {
              chk.checked = false;
              app.showToast("You can select up to 4 Quick Create modules. Uncheck one first.", true);
              return;
            }
            if (selected.indexOf(mid) === -1) selected.push(mid);
          } else {
            selected = selected.filter(function (x) { return x !== mid; });
          }
          renderModalBody();
        });
      });

      document.getElementById("qcCancelBtn").addEventListener("click", app.closeModal);
      document.getElementById("qcSaveBtn").addEventListener("click", function () {
        if (selected.length === 0) {
          app.showToast("Select at least 1 module shortcut.", true);
          return;
        }
        writeJson(LS_KEYS.QUICK_MODULES, selected.slice(0, 4));
        app.closeModal();
        app.showToast("Quick Create shortcuts updated!", false);
        if (typeof onUpdated === "function") onUpdated();
        else if (app.renderCurrentRoute) app.renderCurrentRoute();
      });
    }

    renderModalBody();
  }

  /* --------------------------------------------------------------------------
   * Project Timer & Time Tracking Entries (100% Offline in localStorage)
   * ------------------------------------------------------------------------ */
  function getTimeEntries(businessId) {
    const all = readJson(LS_KEYS.TIME_ENTRIES, []);
    return all.filter(function (e) { return !businessId || e.businessId === businessId; });
  }

  function saveTimeEntry(entry) {
    const all = readJson(LS_KEYS.TIME_ENTRIES, []);
    all.unshift(entry);
    writeJson(LS_KEYS.TIME_ENTRIES, all);
  }

  function getTimerState() {
    return readJson(LS_KEYS.TIMER, {
      running: false,
      startedAtMs: 0,
      accumulatedSec: 0,
      projectId: "",
      projectName: "General Furniture Work",
      taskNote: "",
      hourlyRate: 450
    });
  }

  function formatDuration(totalSec) {
    const sec = Math.max(0, Math.floor(totalSec || 0));
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = sec % 60;
    return (
      String(h).padStart(2, "0") +
      ":" +
      String(m).padStart(2, "0") +
      ":" +
      String(s).padStart(2, "0")
    );
  }

  function getElapsedTimerSeconds(st) {
    const state = st || getTimerState();
    let total = Number(state.accumulatedSec) || 0;
    if (state.running && state.startedAtMs) {
      total += Math.max(0, Math.floor((Date.now() - state.startedAtMs) / 1000));
    }
    return total;
  }

  function startOrPauseTimer(projectId, projectName, taskNote, hourlyRate) {
    const st = getTimerState();
    if (st.running) {
      st.accumulatedSec = getElapsedTimerSeconds(st);
      st.startedAtMs = 0;
      st.running = false;
    } else {
      st.startedAtMs = Date.now();
      st.running = true;
    }
    if (projectId !== undefined) st.projectId = projectId;
    if (projectName !== undefined) st.projectName = projectName;
    if (taskNote !== undefined) st.taskNote = taskNote;
    if (hourlyRate !== undefined) st.hourlyRate = Number(hourlyRate) || 0;
    writeJson(LS_KEYS.TIMER, st);
    return st;
  }

  function stopAndSaveTimer(businessId) {
    const st = getTimerState();
    const totalSec = getElapsedTimerSeconds(st);
    const hours = Math.max(0.1, Math.round((totalSec / 3600) * 100) / 100);
    const rate = Number(st.hourlyRate) || 0;
    const entry = {
      id: "tm_" + Date.now().toString(36),
      businessId: businessId,
      projectId: st.projectId || "",
      projectName: st.projectName || "General Workshop / Site",
      taskNote: st.taskNote || "Craftsmanship & Site Installation",
      date: new Date().toISOString().slice(0, 10),
      hours: hours,
      rate: rate,
      amount: Math.round(hours * rate * 100) / 100,
      billed: false,
      createdAt: new Date().toISOString()
    };

    if (totalSec > 0) {
      saveTimeEntry(entry);
    }

    writeJson(LS_KEYS.TIMER, {
      running: false,
      startedAtMs: 0,
      accumulatedSec: 0,
      projectId: st.projectId || "",
      projectName: st.projectName || "General Furniture Work",
      taskNote: "",
      hourlyRate: rate
    });
    return entry;
  }

  function openLogTimeModal(onSaved) {
    const app = global.PBM_APP;
    const businessId = app.getActiveBusinessId();
    global.PBM_DB.getByBusiness("projects", businessId).then(function (projects) {
      const projOptions = ['<option value="">General Workshop / Site</option>']
        .concat(
          (projects || []).map(function (p) {
            return `<option value="${app.escapeHtml(p.id)}">${app.escapeHtml(p.name)}</option>`;
          })
        )
        .join("");

      const html = `
        <form id="logTimeForm" class="form-grid">
          <div class="form-group">
            <label class="form-label" for="ltProj">Project / Site</label>
            <select id="ltProj" class="form-select">${projOptions}</select>
          </div>
          <div class="form-group">
            <label class="form-label" for="ltTask">Work Description *</label>
            <input id="ltTask" class="form-input" type="text" required placeholder="e.g., Wardrobe assembly & polishing" />
          </div>
          <div class="form-row-3">
            <div class="form-group">
              <label class="form-label" for="ltDate">Date</label>
              <input id="ltDate" class="form-input" type="date" value="${new Date().toISOString().slice(0, 10)}" />
            </div>
            <div class="form-group">
              <label class="form-label" for="ltHours">Hours *</label>
              <input id="ltHours" class="form-input" type="number" step="0.25" min="0.25" value="2" required />
            </div>
            <div class="form-group">
              <label class="form-label" for="ltRate">Rate (₹/hr)</label>
              <input id="ltRate" class="form-input" type="number" min="0" value="450" />
            </div>
          </div>
          <div class="modal-actions">
            <button type="button" id="ltCancelBtn" class="secondary-btn">Cancel</button>
            <button type="submit" class="primary-btn">Save Time Log</button>
          </div>
        </form>
      `;

      app.openModal("Log Project Time", html);
      document.getElementById("ltCancelBtn").addEventListener("click", app.closeModal);
      document.getElementById("logTimeForm").addEventListener("submit", function (e) {
        e.preventDefault();
        const projSel = document.getElementById("ltProj");
        const projName = projSel.options[projSel.selectedIndex].text;
        const hours = Math.max(0.1, parseFloat(document.getElementById("ltHours").value) || 0);
        const rate = Math.max(0, parseFloat(document.getElementById("ltRate").value) || 0);

        saveTimeEntry({
          id: "tm_" + Date.now().toString(36),
          businessId: businessId,
          projectId: projSel.value,
          projectName: projName,
          taskNote: document.getElementById("ltTask").value.trim() || "Site Work",
          date: document.getElementById("ltDate").value || new Date().toISOString().slice(0, 10),
          hours: hours,
          rate: rate,
          amount: Math.round(hours * rate * 100) / 100,
          billed: false,
          createdAt: new Date().toISOString()
        });

        app.closeModal();
        app.showToast("Time entry logged offline!", false);
        if (typeof onSaved === "function") onSaved();
        else app.renderCurrentRoute();
      });
    });
  }

  function openTimeEntriesModal() {
    const app = global.PBM_APP;
    const businessId = app.getActiveBusinessId();
    const entries = getTimeEntries(businessId);

    const rowsHtml = entries.length
      ? entries
          .map(function (e) {
            return `
              <div class="tx-row">
                <div>
                  <div class="tx-row-title">${app.escapeHtml(e.projectName)} — ${app.escapeHtml(e.taskNote)}</div>
                  <div class="tx-row-meta">${app.escapeHtml(e.date)} · ${e.hours} hrs @ ${app.formatCurrency(e.rate)}/hr · ${e.billed ? "Billed" : "Unbilled"}</div>
                </div>
                <div class="tx-row-right">
                  <strong class="tabular-nums">${app.formatCurrency(e.amount)}</strong>
                  <div style="margin-top:4px;display:flex;gap:4px;justify-content:flex-end;">
                    ${
                      !e.billed
                        ? `<button type="button" class="secondary-btn" data-te-bill="${e.id}" style="min-height:26px;padding:2px 8px;font-size:0.72rem;">Mark Billed</button>`
                        : ""
                    }
                    <button type="button" class="danger-btn" data-te-del="${e.id}" style="min-height:26px;padding:2px 8px;font-size:0.72rem;">Del</button>
                  </div>
                </div>
              </div>
            `;
          })
          .join("")
      : '<div class="list-item-meta">No time entries recorded yet. Use Start Timer or Log Time!</div>';

    const html = `
      <div class="form-grid">
        <div class="btn-row">
          <button type="button" id="teNewBtn" class="primary-btn">+ Log Time Entry</button>
        </div>
        <div class="tx-feed" style="max-height:360px;overflow:auto;">${rowsHtml}</div>
      </div>
    `;

    app.openModal("Time Entries & Unbilled Hours", html);
    document.getElementById("teNewBtn").addEventListener("click", function () {
      openLogTimeModal(openTimeEntriesModal);
    });
    document.querySelectorAll("[data-te-bill]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        const id = btn.getAttribute("data-te-bill");
        const all = readJson(LS_KEYS.TIME_ENTRIES, []);
        const found = all.find(function (x) { return x.id === id; });
        if (found) found.billed = true;
        writeJson(LS_KEYS.TIME_ENTRIES, all);
        openTimeEntriesModal();
        app.renderCurrentRoute();
      });
    });
    document.querySelectorAll("[data-te-del]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        const id = btn.getAttribute("data-te-del");
        const filtered = readJson(LS_KEYS.TIME_ENTRIES, []).filter(function (x) { return x.id !== id; });
        writeJson(LS_KEYS.TIME_ENTRIES, filtered);
        openTimeEntriesModal();
        app.renderCurrentRoute();
      });
    });
  }

  function openMileageModal() {
    const app = global.PBM_APP;
    const prefs = getPrefs();
    const html = `
      <form id="mileageForm" class="form-grid">
        <div class="form-group">
          <label class="form-label" for="milDesc">Trip Route / Site Visit *</label>
          <input id="milDesc" class="form-input" type="text" required placeholder="e.g., Showroom to Client Site Delivery" />
        </div>
        <div class="form-row-2">
          <div class="form-group">
            <label class="form-label" for="milKm">Distance (km) *</label>
            <input id="milKm" class="form-input" type="number" min="1" step="0.5" value="25" required />
          </div>
          <div class="form-group">
            <label class="form-label" for="milRate">Rate (₹/km)</label>
            <input id="milRate" class="form-input" type="number" min="1" step="0.5" value="${prefs.mileageRatePerKm || 12}" />
          </div>
        </div>
        <div class="info-note" id="milTotalPreview">Estimated Expense: ₹300.00</div>
        <div class="modal-actions">
          <button type="button" id="milCancelBtn" class="secondary-btn">Cancel</button>
          <button type="submit" class="primary-btn">Save as Expense Voucher</button>
        </div>
      </form>
    `;

    app.openModal("Record Mileage Expense", html);
    const kmEl = document.getElementById("milKm");
    const rtEl = document.getElementById("milRate");
    const prevEl = document.getElementById("milTotalPreview");
    function updatePrev() {
      const amt = (parseFloat(kmEl.value) || 0) * (parseFloat(rtEl.value) || 0);
      prevEl.textContent = "Estimated Expense: " + app.formatCurrency(amt);
    }
    kmEl.addEventListener("input", updatePrev);
    rtEl.addEventListener("input", updatePrev);
    updatePrev();

    document.getElementById("milCancelBtn").addEventListener("click", app.closeModal);
    document.getElementById("mileageForm").addEventListener("submit", function (e) {
      e.preventDefault();
      const desc = document.getElementById("milDesc").value.trim() || "Site Travel Mileage";
      const km = Math.max(0, parseFloat(kmEl.value) || 0);
      const rate = Math.max(0, parseFloat(rtEl.value) || 0);
      const total = Math.round(km * rate * 100) / 100;
      const businessId = app.getActiveBusinessId();
      const now = new Date().toISOString();

      const voucher = {
        id: global.PBM_DB.generateId("vch"),
        businessId: businessId,
        voucherType: "EXPENSE_VOUCHER",
        voucherNo: "MIL/" + Date.now().toString().slice(-4),
        partyId: "",
        partyName: "Travel & Mileage",
        date: now.slice(0, 10),
        gstMode: "NON_GST",
        taxInclusive: "EXCLUSIVE",
        supplyType: "INTRA",
        items: [{ name: `${desc} (${km} km @ ₹${rate}/km)`, unit: "km", qty: km, rate: rate, gstRate: 0, lineTotal: total }],
        subtotal: total,
        taxTotal: 0,
        grandTotal: total,
        amount: total,
        paidAmount: total,
        mode: "Cash",
        status: "PAID",
        notes: "Recorded via Mileage Tracker",
        createdAt: now,
        updatedAt: now
      };

      global.PBM_DB.put("vouchers", voucher).then(function () {
        if (global.PBM_BILLING && global.PBM_BILLING.syncAccountingForVoucher) {
          return global.PBM_BILLING.syncAccountingForVoucher(businessId, voucher);
        }
      }).then(function () {
        app.closeModal();
        app.showToast("Mileage saved as Expense Voucher!", false);
        app.renderCurrentRoute();
      });
    });
  }

  /* --------------------------------------------------------------------------
   * Income & Expense Accrual/Cash Analytics + Top Expenses + Notifications
   * ------------------------------------------------------------------------ */
  function buildIncomeExpenseAnalytics(vouchers, basis, period) {
    const now = new Date();
    const monthBuckets = [];
    const count = period === "quarter" ? 3 : period === "half" ? 6 : 6;
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

    for (let i = count - 1; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const key = d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0");
      monthBuckets.push({
        key: key,
        label: months[d.getMonth()],
        income: 0,
        expense: 0
      });
    }

    let totalIncome = 0;
    let totalExpense = 0;

    (vouchers || []).forEach(function (v) {
      if (v.status === "VOID") return;
      const monthKey = (v.date || "").slice(0, 7);
      const amt =
        basis === "CASH"
          ? v.voucherType === "RECEIPT" || v.voucherType === "PAYMENT"
            ? Number(v.grandTotal || v.amount) || 0
            : Number(v.paidAmount) || 0
          : Number(v.grandTotal || v.amount) || 0;

      const isIncome =
        v.voucherType === "SALE_INVOICE" ||
        v.voucherType === "BILL_OF_SUPPLY" ||
        (basis === "CASH" && v.voucherType === "RECEIPT");
      const isExpense =
        v.voucherType === "PURCHASE_BILL" ||
        v.voucherType === "EXPENSE_VOUCHER" ||
        (basis === "CASH" && v.voucherType === "PAYMENT");

      if (isIncome) {
        totalIncome += amt;
        const b = monthBuckets.find(function (m) { return m.key === monthKey; });
        if (b) b.income += amt;
      } else if (isExpense) {
        totalExpense += amt;
        const b = monthBuckets.find(function (m) { return m.key === monthKey; });
        if (b) b.expense += amt;
      }
    });

    return {
      totalIncome: totalIncome,
      totalExpense: totalExpense,
      netValue: totalIncome - totalExpense,
      monthBuckets: monthBuckets
    };
  }

  function buildTopExpensesList(vouchers) {
    const map = {};
    (vouchers || []).forEach(function (v) {
      if (v.status === "VOID") return;
      if (v.voucherType !== "EXPENSE_VOUCHER" && v.voucherType !== "PURCHASE_BILL") return;
      const key =
        (v.items && v.items[0] && v.items[0].name) ||
        v.partyName ||
        "General Business Expense";
      map[key] = (map[key] || 0) + (Number(v.grandTotal || v.amount) || 0);
    });

    return Object.keys(map)
      .map(function (name) { return { name: name, amount: map[name] }; })
      .sort(function (a, b) { return b.amount - a.amount; })
      .slice(0, 5);
  }

  function openNotificationsModal() {
    const app = global.PBM_APP;
    const businessId = app.getActiveBusinessId();
    Promise.all([
      global.PBM_DB.getByBusiness("vouchers", businessId),
      global.PBM_DB.getByBusiness("items", businessId)
    ]).then(function (res) {
      const vouchers = res[0] || [];
      const items = res[1] || [];
      const today = new Date().toISOString().slice(0, 10);

      const overdue = vouchers.filter(function (v) {
        if (v.status === "VOID") return false;
        if (v.voucherType !== "SALE_INVOICE" && v.voucherType !== "BILL_OF_SUPPLY") return false;
        const due = (Number(v.grandTotal || v.amount) || 0) - (Number(v.paidAmount) || 0);
        return due > 0.01 && (v.dueDate || v.date || today) < today;
      });

      const lowStock = items.filter(function (it) {
        if (it.type === "SERVICE") return false;
        const map = it.stockByWarehouse || {};
        const total = Object.keys(map).reduce(function (s, k) { return s + (Number(map[k]) || 0); }, 0);
        return total <= (Number(it.lowStockThreshold) || 0);
      });

      const unbilled = getTimeEntries(businessId).filter(function (t) { return !t.billed; });

      const cards = [];
      overdue.slice(0, 5).forEach(function (v) {
        cards.push(`<div class="tx-row"><div><div class="tx-row-title">Overdue: ${app.escapeHtml(v.voucherNo)} (${app.escapeHtml(v.partyName)})</div><div class="tx-row-meta">Due date: ${app.escapeHtml(v.dueDate || v.date)}</div></div><strong class="text-payable tabular-nums">${app.formatCurrency((v.grandTotal || 0) - (v.paidAmount || 0))}</strong></div>`);
      });
      lowStock.slice(0, 5).forEach(function (it) {
        cards.push(`<div class="tx-row"><div><div class="tx-row-title">Low Stock Alert: ${app.escapeHtml(it.name)}</div><div class="tx-row-meta">HSN: ${app.escapeHtml(it.hsn || "-")}</div></div><span class="badge-pill">Restock</span></div>`);
      });
      if (unbilled.length) {
        const hrs = unbilled.reduce(function (s, x) { return s + (Number(x.hours) || 0); }, 0);
        cards.push(`<div class="tx-row"><div><div class="tx-row-title">Unbilled Time Entries (${unbilled.length})</div><div class="tx-row-meta">${hrs.toFixed(1)} hours ready to invoice</div></div><button type="button" class="secondary-btn" id="notifViewTimeBtn" style="min-height:28px;padding:3px 8px;font-size:0.74rem;">View</button></div>`);
      }

      const html = cards.length
        ? `<div class="tx-feed">${cards.join("")}</div>`
        : '<div class="empty-state"><strong>All caught up!</strong><p>No overdue invoices or low stock alerts right now.</p></div>';

      app.openModal("Notifications & Alerts", html);
      const tBtn = document.getElementById("notifViewTimeBtn");
      if (tBtn) tBtn.addEventListener("click", openTimeEntriesModal);
    });
  }

  /* --------------------------------------------------------------------------
   * Announcements & Help Views + Documents Hub (Inbox / All Files / Folders)
   * ------------------------------------------------------------------------ */
  function getAnnouncements() {
    const saved = readJson(LS_KEYS.ANNOUNCEMENTS, null);
    if (Array.isArray(saved)) return saved;
    return [
      {
        id: "ann_1",
        title: "Offline GST & 29 Readymade Templates Active",
        body: "Use Template Gallery & Studio to switch between Invoice, Quotation & Receipt designs anytime without internet.",
        date: new Date().toISOString().slice(0, 10)
      },
      {
        id: "ann_2",
        title: "Take Regular JSON Backups",
        body: "All data is stored privately on this device (IndexedDB + localStorage). Export a JSON backup weekly from Settings.",
        date: new Date().toISOString().slice(0, 10)
      }
    ];
  }

  function addAnnouncement(title, body) {
    const list = getAnnouncements();
    list.unshift({
      id: "ann_" + Date.now().toString(36),
      title: title,
      body: body,
      date: new Date().toISOString().slice(0, 10)
    });
    writeJson(LS_KEYS.ANNOUNCEMENTS, list);
  }

  function renderDocumentsView(container, contextStripHtml) {
    const app = global.PBM_APP;
    const businessId = app.getActiveBusinessId();
    const docState = global.__pbmDocTabState || { tab: "all", folder: "ALL" };
    global.__pbmDocTabState = docState;

    const FOLDERS = ["Inbox", "Invoices & Bills", "Quotations", "Site Photos & Receipts", "Agreements"];

    return global.PBM_DB.getByBusiness("parties", businessId).then(function (parties) {
      const localFiles = readJson(LS_KEYS.DOC_FILES, []).filter(function (f) {
        return !f.businessId || f.businessId === businessId;
      });

      // Collect attachments from Parties too
      const partyFiles = [];
      (parties || []).forEach(function (p) {
        (p.attachments || []).forEach(function (att, idx) {
          partyFiles.push({
            id: "pty_" + p.id + "_" + idx,
            name: att.name || p.name + " Attachment",
            folder: "Agreements",
            sizeLabel: "Party Doc",
            dataUrl: att.dataUrl || "",
            date: (p.updatedAt || "").slice(0, 10),
            readonly: true
          });
        });
      });

      const allFiles = localFiles.concat(partyFiles);
      const visible = allFiles.filter(function (f) {
        if (docState.tab === "inbox") return f.folder === "Inbox";
        if (docState.tab === "folders" && docState.folder !== "ALL") return f.folder === docState.folder;
        return true;
      });

      const filesHtml = visible.length
        ? visible
            .map(function (f) {
              return `
                <div class="tx-row">
                  <div style="min-width:0;">
                    <div class="tx-row-title">${app.escapeHtml(f.name)}</div>
                    <div class="tx-row-meta">Folder: ${app.escapeHtml(f.folder || "Inbox")} · ${app.escapeHtml(f.sizeLabel || "")} · ${app.escapeHtml(f.date || "")}</div>
                  </div>
                  <div class="btn-row" style="flex-shrink:0;">
                    ${f.dataUrl ? `<a class="secondary-btn" href="${f.dataUrl}" download="${app.escapeHtml(f.name)}" style="min-height:30px;padding:4px 10px;font-size:0.76rem;text-decoration:none;">Download</a>` : ""}
                    ${!f.readonly ? `<button type="button" class="danger-btn" data-docfile-del="${app.escapeHtml(f.id)}" style="min-height:30px;padding:4px 10px;font-size:0.76rem;">Del</button>` : ""}
                  </div>
                </div>
              `;
            })
            .join("")
        : '<div class="empty-state"><strong>No files in this view</strong><p>Upload bills, site photos, designs or agreements to keep them organized offline.</p></div>';

      const folderChips = ['<button type="button" class="seg-btn ' + (docState.folder === "ALL" ? "active" : "") + '" data-doc-folder="ALL">All Folders</button>']
        .concat(
          FOLDERS.map(function (fl) {
            return `<button type="button" class="seg-btn ${docState.folder === fl ? "active" : ""}" data-doc-folder="${app.escapeHtml(fl)}">${app.escapeHtml(fl)}</button>`;
          })
        )
        .join("");

      container.innerHTML = `
        ${contextStripHtml}
        <div class="card">
          <div class="card-header-row">
            <div>
              <h2 class="card-title">Digital Documents Vault</h2>
              <p class="card-subtitle">Inbox, All Files &amp; Folders stored privately offline</p>
            </div>
            <div class="btn-row">
              <select id="docUploadFolder" class="form-select" style="width:auto;min-height:40px;">
                ${FOLDERS.map(function (fl) { return `<option value="${app.escapeHtml(fl)}">${app.escapeHtml(fl)}</option>`; }).join("")}
              </select>
              <button id="docUploadBtn" class="primary-btn" type="button">+ Upload File</button>
              <input id="docUploadInput" class="hidden-file-input" type="file" />
            </div>
          </div>

          <div class="segmented-bar">
            <button type="button" class="seg-btn ${docState.tab === "inbox" ? "active" : ""}" data-doc-tab="inbox">Inbox</button>
            <button type="button" class="seg-btn ${docState.tab === "all" ? "active" : ""}" data-doc-tab="all">All Files (${allFiles.length})</button>
            <button type="button" class="seg-btn ${docState.tab === "folders" ? "active" : ""}" data-doc-tab="folders">Folders</button>
          </div>

          ${docState.tab === "folders" ? `<div class="segmented-bar" style="margin-top:8px;">${folderChips}</div>` : ""}
        </div>

        <div class="card">
          <div class="tx-feed">${filesHtml}</div>
        </div>
      `;

      container.querySelectorAll("[data-doc-tab]").forEach(function (btn) {
        btn.addEventListener("click", function () {
          docState.tab = btn.getAttribute("data-doc-tab");
          renderDocumentsView(container, contextStripHtml);
        });
      });

      container.querySelectorAll("[data-doc-folder]").forEach(function (btn) {
        btn.addEventListener("click", function () {
          docState.folder = btn.getAttribute("data-doc-folder");
          renderDocumentsView(container, contextStripHtml);
        });
      });

      const upBtn = document.getElementById("docUploadBtn");
      const upInput = document.getElementById("docUploadInput");
      upBtn.addEventListener("click", function () { upInput.value = ""; upInput.click(); });
      upInput.addEventListener("change", function (e) {
        const file = e.target.files && e.target.files[0];
        if (!file) return;
        if (file.size > 1500000) {
          app.showToast("Please pick a file under 1.5 MB for offline local storage.", true);
          return;
        }
        const reader = new FileReader();
        reader.onload = function (ev) {
          const all = readJson(LS_KEYS.DOC_FILES, []);
          all.unshift({
            id: "df_" + Date.now().toString(36),
            businessId: businessId,
            name: file.name,
            folder: document.getElementById("docUploadFolder").value || "Inbox",
            sizeLabel: Math.max(1, Math.round(file.size / 1024)) + " KB",
            dataUrl: ev.target.result,
            date: new Date().toISOString().slice(0, 10)
          });
          writeJson(LS_KEYS.DOC_FILES, all);
          app.showToast("File saved to Documents Vault!", false);
          renderDocumentsView(container, contextStripHtml);
        };
        reader.readAsDataURL(file);
      });

      container.querySelectorAll("[data-docfile-del]").forEach(function (btn) {
        btn.addEventListener("click", function () {
          const id = btn.getAttribute("data-docfile-del");
          const filtered = readJson(LS_KEYS.DOC_FILES, []).filter(function (f) { return f.id !== id; });
          writeJson(LS_KEYS.DOC_FILES, filtered);
          renderDocumentsView(container, contextStripHtml);
        });
      });
    });
  }

  /* --------------------------------------------------------------------------
   * Extended Zoho-Books-Inspired Settings Cards
   * ------------------------------------------------------------------------ */
  function renderExtendedSettingsCards(hostEl) {
    if (!hostEl) return;
    const app = global.PBM_APP;
    const prefs = getPrefs();

    hostEl.innerHTML = `
      <div class="card">
        <h2 class="card-title">Preferences, Opening Screen &amp; Mileage</h2>
        <p class="card-subtitle">Control startup screen, mileage reimbursement rate &amp; receipt scan settings.</p>
        <div class="form-grid" style="margin-top:12px;">
          <div class="form-row-2">
            <div class="form-group">
              <label class="form-label" for="prefOpenScreen">Opening Screen</label>
              <select id="prefOpenScreen" class="form-select">
                <option value="dashboard" ${prefs.openingScreen === "dashboard" ? "selected" : ""}>Home / Dashboard</option>
                <option value="billing" ${prefs.openingScreen === "billing" ? "selected" : ""}>Sales &amp; Invoices</option>
                <option value="parties" ${prefs.openingScreen === "parties" ? "selected" : ""}>Customers &amp; Vendors</option>
                <option value="inventory" ${prefs.openingScreen === "inventory" ? "selected" : ""}>Items &amp; Inventory</option>
                <option value="documents" ${prefs.openingScreen === "documents" ? "selected" : ""}>Documents Vault</option>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label" for="prefMileage">Default Mileage Rate (₹/km)</label>
              <input id="prefMileage" class="form-input" type="number" min="1" step="0.5" value="${prefs.mileageRatePerKm}" />
            </div>
          </div>

          <div class="form-row-2">
            <div class="form-group">
              <label class="form-label" for="prefImgRes">Image Upload Resolution</label>
              <select id="prefImgRes" class="form-select">
                <option value="600" ${prefs.imageResolution === "600" ? "selected" : ""}>Compact (600px — Fast Offline)</option>
                <option value="1024" ${prefs.imageResolution === "1024" ? "selected" : ""}>Balanced HD (1024px)</option>
                <option value="2048" ${prefs.imageResolution === "2048" ? "selected" : ""}>High Print Quality (2048px)</option>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label" for="prefGateway">Online Payment Gateway / UPI</label>
              <input id="prefGateway" class="form-input" type="text" value="${app.escapeHtml(prefs.paymentGatewayLabel)}" />
            </div>
          </div>

          <div class="btn-row">
            <label class="check-chip"><input id="prefPayLinks" type="checkbox" ${prefs.enablePaymentLinks ? "checked" : ""}/> Enable UPI Payment Link Notes</label>
            <label class="check-chip"><input id="prefScanEnhance" type="checkbox" ${prefs.scanReceiptEnhancement ? "checked" : ""}/> Receipt Scan Auto-Contrast</label>
          </div>
        </div>
      </div>

      <div class="card">
        <h2 class="card-title">Sender Email &amp; Share Preferences</h2>
        <p class="card-subtitle">Default sender name, reply-to email and message signature for shared documents.</p>
        <div class="form-grid" style="margin-top:12px;">
          <div class="form-row-2">
            <div class="form-group">
              <label class="form-label" for="prefSenderName">Sender Name</label>
              <input id="prefSenderName" class="form-input" type="text" value="${app.escapeHtml(prefs.senderName)}" />
            </div>
            <div class="form-group">
              <label class="form-label" for="prefReplyEmail">Reply-To Email</label>
              <input id="prefReplyEmail" class="form-input" type="email" value="${app.escapeHtml(prefs.replyToEmail)}" placeholder="billing@panchalfurnitures.in" />
            </div>
          </div>
          <div class="form-group">
            <label class="form-label" for="prefEmailSig">Share / Email Signature</label>
            <textarea id="prefEmailSig" class="form-textarea" rows="2">${app.escapeHtml(prefs.emailSignature)}</textarea>
          </div>
          <div>
            <button id="saveExtPrefsBtn" class="primary-btn" type="button">Save Preferences</button>
          </div>
        </div>
      </div>

      <div class="card">
        <h2 class="card-title">Subscription, Feedback, Share &amp; About</h2>
        <p class="card-subtitle">Panchal Business Manager — Free 100% Offline Edition (No Cloud Fees)</p>
        <div class="info-note" style="margin-top:10px;">
          <strong>Plan Status:</strong> Unlimited Offline Business Plan (Active Forever · Zero Subscription Fee)<br />
          <strong>Privacy Guarantee:</strong> 100% of invoices, ledgers, inventory, and client records stay privately inside your device.
        </div>
        <div class="btn-row" style="margin-top:12px;">
          <button id="setRateAppBtn" class="secondary-btn" type="button">Rate App (${prefs.appRating || 5}★)</button>
          <button id="setFeedbackBtn" class="secondary-btn" type="button">Send Feedback</button>
          <button id="setShareAppBtn" class="secondary-btn" type="button">Share App</button>
          <button id="setAboutAppBtn" class="secondary-btn" type="button">About</button>
        </div>
      </div>
    `;

    document.getElementById("saveExtPrefsBtn").addEventListener("click", function () {
      savePrefs({
        openingScreen: document.getElementById("prefOpenScreen").value,
        mileageRatePerKm: parseFloat(document.getElementById("prefMileage").value) || 12,
        imageResolution: document.getElementById("prefImgRes").value,
        paymentGatewayLabel: document.getElementById("prefGateway").value.trim() || "UPI / Bank Transfer",
        enablePaymentLinks: document.getElementById("prefPayLinks").checked,
        scanReceiptEnhancement: document.getElementById("prefScanEnhance").checked,
        senderName: document.getElementById("prefSenderName").value.trim(),
        replyToEmail: document.getElementById("prefReplyEmail").value.trim(),
        emailSignature: document.getElementById("prefEmailSig").value.trim()
      });
      app.showToast("Preferences saved offline!", false);
    });

    document.getElementById("setRateAppBtn").addEventListener("click", function () {
      const next = ((getPrefs().appRating || 5) % 5) + 1;
      savePrefs({ appRating: next });
      app.showToast(`Rated ${next} / 5 stars!`, false);
      renderExtendedSettingsCards(hostEl);
    });

    document.getElementById("setFeedbackBtn").addEventListener("click", function () {
      const fbHtml = `
        <form id="fbForm" class="form-grid">
          <div class="form-group">
            <label class="form-label" for="fbText">Your Feedback or Feature Note</label>
            <textarea id="fbText" class="form-textarea" rows="3" required placeholder="Write feedback or improvement ideas..."></textarea>
          </div>
          <div class="modal-actions">
            <button type="button" id="fbCancel" class="secondary-btn">Cancel</button>
            <button type="submit" class="primary-btn">Save Feedback</button>
          </div>
        </form>
      `;
      app.openModal("App Feedback", fbHtml);
      document.getElementById("fbCancel").addEventListener("click", app.closeModal);
      document.getElementById("fbForm").addEventListener("submit", function (e) {
        e.preventDefault();
        const logs = readJson(LS_KEYS.FEEDBACK, []);
        logs.unshift({ text: document.getElementById("fbText").value.trim(), date: new Date().toISOString() });
        writeJson(LS_KEYS.FEEDBACK, logs);
        app.closeModal();
        app.showToast("Feedback saved locally. Thank you!", false);
      });
    });

    document.getElementById("setShareAppBtn").addEventListener("click", function () {
      if (global.PBM_PRINT) {
        global.PBM_PRINT.shareText(
          "Panchal Business Manager",
          "Panchal Business Manager — Offline GST Billing, Quotations, Inventory & Accounting ERP."
        );
      }
    });

    document.getElementById("setAboutAppBtn").addEventListener("click", function () {
      app.openModal(
        "About Panchal Business Manager",
        `<div class="form-grid">
          <p class="card-subtitle"><strong>Version:</strong> 3.0 Offline PWA</p>
          <p class="card-subtitle"><strong>Built For:</strong> Panchal Furnitures &amp; Indian SMEs</p>
          <p class="card-subtitle"><strong>Storage Engine:</strong> IndexedDB + localStorage + Offline Service Worker</p>
          <p class="card-subtitle">Includes 15 Document Types, 29 Readymade Templates, Indian GST/HSN Summaries, Vector PDF Export &amp; Double-Entry Accounting.</p>
        </div>`
      );
    });
  }

  global.PBM_ZOHO = {
    QUICK_MODULE_CATALOG: QUICK_MODULE_CATALOG,
    getPrefs: getPrefs,
    getSelectedQuickModules: getSelectedQuickModules,
    getModuleIconSvg: getModuleIconSvg,
    launchQuickModule: launchQuickModule,
    openQuickCreateModal: openQuickCreateModal,
    getTimeEntries: getTimeEntries,
    getTimerState: getTimerState,
    formatDuration: formatDuration,
    getElapsedTimerSeconds: getElapsedTimerSeconds,
    startOrPauseTimer: startOrPauseTimer,
    stopAndSaveTimer: stopAndSaveTimer,
    openLogTimeModal: openLogTimeModal,
    openTimeEntriesModal: openTimeEntriesModal,
    openMileageModal: openMileageModal,
    buildIncomeExpenseAnalytics: buildIncomeExpenseAnalytics,
    buildTopExpensesList: buildTopExpensesList,
    openNotificationsModal: openNotificationsModal,
    getAnnouncements: getAnnouncements,
    addAnnouncement: addAnnouncement,
    renderDocumentsView: renderDocumentsView,
    renderExtendedSettingsCards: renderExtendedSettingsCards
  };
})(window);
