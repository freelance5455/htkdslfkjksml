/* war.js — Phase 3: war declarations, ceasefire, elimination.
   (The enemy logic here is deliberately simple: it only runs for countries at war. Full AI arrives in Phase 8.) */
(function (G) {
  'use strict';

  const key = (a, b) => a < b ? a + '|' + b : b + '|' + a;

  G.initWar = function (st) {
    st.wars = st.wars || {};      // 'A|B' -> { a, b, start, provs:{A:n,B:n} }
    st.truce = st.truce || {};    // 'A|B' -> day when truce ends
    st.occ = st.occ || {};
    st.fortQ = st.fortQ || [];
    st.battleRec = st.battleRec || {};
    if (st.rs == null) st.rs = 20261015;
  };

  G.atWar = function (a, b) { return a !== b && !!G.state.wars[key(a, b)]; };
  G.warsOf = function (id) {
    const st = G.state, out = [];
    for (const k in st.wars) { const w = st.wars[k]; if (w.a === id) out.push(w.b); else if (w.b === id) out.push(w.a); }
    return out;
  };
  G.isDead = function (id) { return !!G.state.countries[id].dead; };

  G.canEnter = function (a, prov) {
    const o = G.state.owners[prov];
    return !!o && (o === a.owner || G.atWar(a.owner, o) || !!(G.hasAccess && G.hasAccess(o, a.owner)));
  };

  G.declareWar = function (a, b, opts) {
    const st = G.state;
    if (a === b) return { ok: false, msg: 'Cannot declare war on yourself' };
    if (G.isDead(a) || G.isDead(b)) return { ok: false, msg: 'That nation no longer exists' };
    if (G.atWar(a, b)) return { ok: false, msg: 'Already at war' };
    const dchk = G.diplomacyWarCheck && G.diplomacyWarCheck(a, b, opts); if (dchk && !dchk.ok) return dchk;
    if (!(opts && opts.call) && (st.truce[key(a, b)] || 0) > st.day) return { ok: false, msg: 'Truce in force for ' + (st.truce[key(a, b)] - st.day) + ' more days' };
    st.wars[key(a, b)] = { a: a, b: b, start: st.day, provs: { [a]: st.countries[a].provCount, [b]: st.countries[b].provCount } };
    G.logMsg(G.COUNTRIES[a].name + ' declared war on ' + G.COUNTRIES[b].name);
    G.afterWarDeclared && G.afterWarDeclared(a, b, opts);
    G.onWarChange && G.onWarChange(a, b, true);
    return { ok: true };
  };

  function totalMen(id) { return G.state.armies.filter(a => a.owner === id).reduce((s, a) => s + G.armySummary(a).men, 0); }

  // The other side accepts a ceasefire if it is losing, has had enough, or the war has dragged on.
  G.ceasefireOdds = function (proposer, other) {
    const st = G.state, w = st.wars[key(proposer, other)];
    if (!w) return { ok: false, msg: 'Not at war' };
    const lost = st.countries[other].provCount < w.provs[other];
    const weaker = totalMen(other) < 0.85 * totalMen(proposer);
    const long = st.day - w.start >= 90;
    const capLost = st.owners[G.COUNTRIES[other].capitalId] !== other;
    const ok = lost || weaker || long || capLost;
    return { ok: ok, msg: ok ? '' : G.COUNTRIES[other].name + ' refuses — they are not yet beaten' };
  };

  // Phase 5: a ceasefire is now a white-peace negotiation (see diplomacy.js for terms).
  G.proposeCeasefire = function (proposer, other) {
    if (!G.atWar(proposer, other)) return { ok: false, msg: 'Not at war' };
    return G.makePeace(proposer, other, {}, 60);
  };

  G.endWar = function (a, b, truceDays) {
    const st = G.state;
    delete st.wars[key(a, b)];
    st.truce[key(a, b)] = st.day + (truceDays || 30);
    G.logMsg('Ceasefire between ' + G.COUNTRIES[a].name + ' and ' + G.COUNTRIES[b].name);
    G.expelForeignArmies();
    for (const k in st.occ) { const o = st.occ[k]; if (!G.atWar(o.by, st.owners[k])) delete st.occ[k]; }
    G.onWarChange && G.onWarChange(a, b, false);
  };

  // Armies standing in territory they may no longer occupy withdraw to the nearest own province.
  G.expelForeignArmies = function () {
    const st = G.state, P = G.provinces;
    for (const a of st.armies) {
      if (!G.canEnter(a, a.prov)) {
        let frontier = [a.prov], seen = { [a.prov]: true }, dest = null;
        while (frontier.length && dest == null) {
          const next = [];
          for (const p of frontier) for (const n of P[p].adj) {
            if (seen[n]) continue; seen[n] = true;
            if (st.owners[n] === a.owner) { dest = n; break; }
            next.push(n);
          }
          frontier = next;
        }
        if (dest != null) { a.prov = dest; a.path = []; a.progress = 0; a.goal = null; }
      }
      if (a.path.length && a.path.some(p => !G.canEnter(a, p))) { a.path = []; a.progress = 0; a.goal = null; }
    }
  };

  G.eliminate = function (id, by) {
    const st = G.state, c = st.countries[id];
    c.dead = true;
    st.armies.filter(a => a.owner === id).forEach(a => G.removeArmy(a));
    st.queues[id] = [];
    st.fortQ = st.fortQ.filter(f => f.owner !== id);
    for (const k in st.wars) if (st.wars[k].a === id || st.wars[k].b === id) delete st.wars[k];
    G.diplomacyPurge && G.diplomacyPurge(id);
    G.navalEliminate && G.navalEliminate(id);
    G.logMsg(G.COUNTRIES[id].name + ' has been eliminated by ' + G.COUNTRIES[by].name);
    if (id === st.player) G.onPlayerDefeated && G.onPlayerDefeated(by);
  };
  // Enemy and strategic AI live in ai.js (Phase 8).
})(window.EMP = window.EMP || {});
