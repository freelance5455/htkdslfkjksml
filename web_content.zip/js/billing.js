/**
 * Panchal Business Manager - Complete 15-Document Billing, Quotation & Work Order Engine
 * Supports Tax Invoice, Bill of Supply, Estimate, Quotation, Proforma, Credit/Debit Notes,
 * Purchase/Sales Orders, Delivery Challan, Payment Receipt, Work Order, Completion Certificate,
 * Purchase Bill & Expense Voucher with Tax-Inclusive/Exclusive, Cess, Place of Supply, RCM,
 * Round-Off, Template Selection, Duplicate, Void, Conversions & Balanced Accounting.
 */
(function (global) {
  "use strict";

  const I18N = {
    en: {
      newDocBtn: "+ New Document",
      designersBtn: "Invoice Templates",
      searchPlaceholder: "Search doc no, party name...",
      filterAll: "All",
      typeSALE_INVOICE: "Tax Invoice",
      typeBILL_OF_SUPPLY: "Bill of Supply",
      typeESTIMATE: "Estimate",
      typeQUOTATION: "Quotation",
      typePROFORMA: "Proforma Invoice",
      typeCREDIT_NOTE: "Credit Note",
      typeDEBIT_NOTE: "Debit Note",
      typePURCHASE_ORDER: "Purchase Order",
      typeSALES_ORDER: "Sales Order",
      typeCHALLAN: "Delivery Challan",
      typeRECEIPT: "Payment Receipt",
      typeWORK_ORDER: "Work Order",
      typeCOMPLETION_CERT: "Completion Cert",
      typePURCHASE_BILL: "Purchase Bill",
      typeEXPENSE_VOUCHER: "Expense Voucher",
      emptyTitle: "No billing documents yet",
      emptyDesc: "Create a Tax Invoice, Quotation, Estimate, Work Order, Challan, or Expense Voucher.",
      kpiSales: "Total Sales",
      kpiPurchases: "Purchases & Exp",
      kpiQuotations: "Quotes & Orders",
      btnPreview: "Preview / Print",
      btnPdf: "Save PDF",
      btnShare: "Share PDF",
      btnDuplicate: "Duplicate",
      btnVoid: "Void",
      btnConvertInv: "-> Invoice",
      btnConvertWo: "-> Work Order",
      btnConvertBill: "-> Purchase Bill",
      btnConvertCert: "-> Completion Cert",
      btnPay: "Record Payment",
      btnDelete: "Delete",
      btnEdit: "Edit",
      modalTitleCreate: "Create Document",
      modalTitleEdit: "Edit Document",
      fieldDocType: "Document Type",
      fieldDocNo: "Document No *",
      fieldParty: "Party (Customer / Supplier) *",
      fieldDate: "Date *",
      fieldDueDate: "Due / Valid Until",
      fieldPayTerms: "Payment Terms",
      fieldGstMode: "Tax Mode",
      modeGst: "GST Bill",
      modeNonGst: "Non-GST / Exempt",
      fieldTaxPricing: "Rate Pricing",
      pricingExcl: "Tax Exclusive (+GST)",
      pricingIncl: "Tax Inclusive (MRP)",
      fieldSupplyType: "GST Supply Type",
      supplyIntra: "Intra-State (CGST + SGST)",
      supplyInter: "Inter-State (IGST)",
      fieldPos: "Place of Supply (State)",
      fieldRcm: "Reverse Charge (RCM)",
      fieldWarehouse: "Stock Warehouse",
      fieldTemplate: "Document Design Template",
      itemsSectionTitle: "Line Items",
      addLineItemBtn: "+ Add Line",
      pickInventoryLabel: "Select from Inventory (or type custom)",
      customItemOpt: "-- Custom Item / Service --",
      fieldItemName: "Item / Description *",
      fieldHsn: "HSN/SAC",
      fieldQty: "Qty",
      fieldRate: "Rate",
      fieldDisc: "Disc %",
      fieldGstPct: "GST %",
      fieldCessPct: "Cess %",
      fieldShipping: "Shipping / Extra Charges",
      fieldRoundOff: "Auto Round-Off",
      fieldCustomLbl: "Custom Field Label (e.g. Site/PO)",
      fieldCustomVal: "Custom Field Value",
      subtotalLabel: "Taxable Subtotal",
      taxLabel: "GST Tax",
      cessLabel: "Cess",
      roundOffLabel: "Round Off",
      grandTotalLabel: "Grand Total",
      fieldPaidNow: "Paid / Received Now",
      fieldPayMode: "Payment Mode",
      fieldTermsPick: "Pick from Terms Library",
      fieldNotes: "Terms & Conditions / Notes",
      signBtn: "Authorized Sign",
      custSignBtn: "Customer Accept Sign",
      signedLabel: "Sign attached",
      errNoParty: "Please select a Party first (or create one in Parties tab).",
      errNoItems: "Add at least one line item with quantity.",
      confirmDelTitle: "Delete Document?",
      confirmDelMsg: "This will permanently delete this document and reverse its stock/accounting entries.",
      confirmVoidTitle: "Cancel / Void Document?",
      confirmVoidMsg: "Voiding marks this document CANCELLED and reverses its stock & ledger entries while keeping the record for audit.",
      toastSaved: "Document saved.",
      toastDeleted: "Document deleted.",
      toastVoided: "Document marked VOID.",
      toastConverted: "Converted successfully.",
      statusPaid: "Paid",
      statusPartial: "Partial",
      statusUnpaid: "Unpaid",
      statusVoid: "VOID",
      statusDoc: "Open",
      saveBtn: "Save Document",
      cancelBtn: "Cancel",
      deleteBtn: "Delete"
    },
    hi: {
      newDocBtn: "+ नया बिल / दस्तावेज़",
      designersBtn: "बिल टेम्पलेट्स",
      searchPlaceholder: "नंबर या पार्टी का नाम खोजें...",
      filterAll: "सभी",
      typeSALE_INVOICE: "टैक्स इनवॉइस (Invoice)",
      typeBILL_OF_SUPPLY: "बिल ऑफ़ सप्लाई",
      typeESTIMATE: "एस्टिमेट (Estimate)",
      typeQUOTATION: "कोटेशन (Quotation)",
      typePROFORMA: "प्रोफ़ॉर्मा बिल",
      typeCREDIT_NOTE: "क्रेडिट नोट",
      typeDEBIT_NOTE: "डेबिट नोट",
      typePURCHASE_ORDER: "परचेज़ ऑर्डर (PO)",
      typeSALES_ORDER: "सेल्स ऑर्डर (SO)",
      typeCHALLAN: "डिलीवरी चालान",
      typeRECEIPT: "पेमेंट रसीद (Receipt)",
      typeWORK_ORDER: "वर्क ऑर्डर (Work Order)",
      typeCOMPLETION_CERT: "कार्य पूर्णता प्रमाणपत्र",
      typePURCHASE_BILL: "खरीद बिल (Purchase)",
      typeEXPENSE_VOUCHER: "खर्च वाउचर (Expense)",
      emptyTitle: "अभी कोई दस्तावेज़ नहीं है",
      emptyDesc: "Tax Invoice, Quotation, Estimate, Work Order, Challan या Expense Voucher बनाएँ।",
      kpiSales: "कुल बिक्री",
      kpiPurchases: "खरीद व खर्च",
      kpiQuotations: "कोटेशन व ऑर्डर",
      btnPreview: "प्रीव्यू / प्रिंट",
      btnPdf: "PDF डाउनलोड",
      btnShare: "PDF शेयर",
      btnDuplicate: "कॉपी बनाएँ",
      btnVoid: "रद्द (Void)",
      btnConvertInv: "-> Invoice",
      btnConvertWo: "-> Work Order",
      btnConvertBill: "-> Purchase Bill",
      btnConvertCert: "-> Completion Cert",
      btnPay: "पेमेंट जोड़ें",
      btnDelete: "हटाएँ",
      btnEdit: "बदलें",
      modalTitleCreate: "नया दस्तावेज़ बनाएँ",
      modalTitleEdit: "दस्तावेज़ बदलें",
      fieldDocType: "दस्तावेज़ का प्रकार",
      fieldDocNo: "दस्तावेज़ नंबर *",
      fieldParty: "पार्टी चुनें (ग्राहक / सप्लायर) *",
      fieldDate: "तारीख़ *",
      fieldDueDate: "अंतिम तारीख़ (Due/Valid)",
      fieldPayTerms: "पेमेंट शर्तें",
      fieldGstMode: "GST प्रकार",
      modeGst: "GST बिल",
      modeNonGst: "बिना GST (Non-GST)",
      fieldTaxPricing: "रेट में टैक्स नियम",
      pricingExcl: "टैक्स अलग से (+GST)",
      pricingIncl: "टैक्स सहित (Inclusive)",
      fieldSupplyType: "GST सप्लाई नियम",
      supplyIntra: "राज्य के अंदर (CGST + SGST)",
      supplyInter: "अन्य राज्य (IGST)",
      fieldPos: "सप्लाई का राज्य (Place of Supply)",
      fieldRcm: "रिवर्स चार्ज (RCM)",
      fieldWarehouse: "स्टॉक गोदाम",
      fieldTemplate: "दस्तावेज़ डिज़ाइन चुनें",
      itemsSectionTitle: "सामान / सेवा सूची (Items)",
      addLineItemBtn: "+ आइटम जोड़ें",
      pickInventoryLabel: "इन्वेंटरी से चुनें",
      customItemOpt: "-- कस्टम आइटम / सर्विस --",
      fieldItemName: "आइटम / कार्य विवरण *",
      fieldHsn: "HSN/SAC",
      fieldQty: "मात्रा",
      fieldRate: "दर",
      fieldDisc: "छूट %",
      fieldGstPct: "GST %",
      fieldCessPct: "सेस %",
      fieldShipping: "शिपिंग / अतिरिक्त शुल्क",
      fieldRoundOff: "ऑटो राउंड-ऑफ़ (Round Off)",
      fieldCustomLbl: "कस्टम फ़ील्ड नाम",
      fieldCustomVal: "कस्टम फ़ील्ड मान",
      subtotalLabel: "टैक्स योग्य राशि",
      taxLabel: "कुल GST टैक्स",
      cessLabel: "सेस (Cess)",
      roundOffLabel: "राउंड ऑफ़",
      grandTotalLabel: "कुल बिल राशि",
      fieldPaidNow: "अभी मिला / दिया पेमेंट",
      fieldPayMode: "पेमेंट माध्यम",
      fieldTermsPick: "नियम सूची से चुनें",
      fieldNotes: "शर्तें / नोट्स",
      signBtn: "अधिकृत हस्ताक्षर",
      custSignBtn: "ग्राहक स्वीकृति साइन",
      signedLabel: "साइन जुड़ा है",
      errNoParty: "कृपया पहले पार्टी चुनें (Parties टैब में नई पार्टी बनाएँ)।",
      errNoItems: "कम से कम एक आइटम व सही मात्रा डालें।",
      confirmDelTitle: "दस्तावेज़ हटाएँ?",
      confirmDelMsg: "यह दस्तावेज़ और इसका स्टॉक व खाता असर हमेशा के लिए हट जाएगा।",
      confirmVoidTitle: "दस्तावेज़ रद्द (Void) करें?",
      confirmVoidMsg: "Void करने पर दस्तावेज़ रिकॉर्ड में रहेगा लेकिन इसका स्टॉक और खाता असर वापस हट जाएगा।",
      toastSaved: "दस्तावेज़ सेव हो गया।",
      toastDeleted: "दस्तावेज़ हटा दिया गया।",
      toastVoided: "दस्तावेज़ VOID कर दिया गया।",
      toastConverted: "सफलतापूर्वक बदल दिया गया।",
      statusPaid: "पूरा भुगतान (Paid)",
      statusPartial: "आंशिक (Partial)",
      statusUnpaid: "बाकी (Unpaid)",
      statusVoid: "रद्द (VOID)",
      statusDoc: "चालू",
      saveBtn: "सेव करें",
      cancelBtn: "रद्द करें",
      deleteBtn: "हटाएँ"
    }
  };

  const BILLING_TYPES = [
    "SALE_INVOICE",
    "QUOTATION",
    "ESTIMATE",
    "PROFORMA",
    "BILL_OF_SUPPLY",
    "SALES_ORDER",
    "CHALLAN",
    "WORK_ORDER",
    "COMPLETION_CERT",
    "CREDIT_NOTE",
    "RECEIPT",
    "PURCHASE_BILL",
    "PURCHASE_ORDER",
    "DEBIT_NOTE",
    "EXPENSE_VOUCHER"
  ];

  const DEFAULT_PREFIX = {
    SALE_INVOICE: "PF/INV/",
    BILL_OF_SUPPLY: "PF/BOS/",
    ESTIMATE: "PF/EST/",
    QUOTATION: "PF/QTN/",
    PROFORMA: "PF/PRO/",
    CREDIT_NOTE: "PF/CRN/",
    DEBIT_NOTE: "PF/DBN/",
    PURCHASE_ORDER: "PF/PO/",
    SALES_ORDER: "PF/SO/",
    CHALLAN: "PF/CHL/",
    RECEIPT: "PF/REC/",
    WORK_ORDER: "PF/WO/",
    COMPLETION_CERT: "PF/CC/",
    PURCHASE_BILL: "PF/PUR/",
    EXPENSE_VOUCHER: "PF/EXP/"
  };

  const viewState = {
    search: "",
    filterType: "ALL",
    vouchers: [],
    parties: [],
    items: [],
    warehouses: [],
    templates: [],
    docSettings: null
  };

  function tr(key) {
    const lang = global.PBM_APP.getLang();
    return (I18N[lang] && I18N[lang][key]) || I18N.en[key] || key;
  }

  function getDocTypeLabel(type) {
    return tr("type" + type) || type;
  }

  function getStockDirection(voucherType) {
    if (voucherType === "SALE_INVOICE" || voucherType === "BILL_OF_SUPPLY" || voucherType === "CHALLAN" || voucherType === "DEBIT_NOTE") {
      return -1;
    }
    if (voucherType === "PURCHASE_BILL" || voucherType === "CREDIT_NOTE") {
      return 1;
    }
    return 0;
  }

  function applyStockEffect(businessId, voucher, multiplier) {
    if (!voucher || voucher.status === "VOID") {
      return Promise.resolve();
    }
    const dir = getStockDirection(voucher.voucherType) * multiplier;
    if (dir === 0 || !global.PBM_INVENTORY) {
      return Promise.resolve();
    }
    const tasks = (voucher.items || [])
      .filter(function (line) {
        return Boolean(line.itemId) && Number(line.qty) > 0;
      })
      .map(function (line) {
        return global.PBM_INVENTORY.adjustStock(
          businessId,
          line.itemId,
          voucher.warehouseId,
          dir * Number(line.qty),
          voucher.voucherType + " " + voucher.voucherNo,
          voucher.id
        );
      });
    return Promise.all(tasks);
  }

  function getCashOrBankKey(mode) {
    return mode === "Cash" ? "CASH" : "BANK";
  }

  function syncAccountingForVoucher(businessId, voucher) {
    return global.PBM_DB.getByBusiness("journalEntries", businessId).then(function (entries) {
      const existing = entries.filter(function (j) {
        return j.refVoucherId === voucher.id;
      });
      const removeTasks = existing.map(function (j) {
        return global.PBM_DB.remove("journalEntries", j.id);
      });

      return Promise.all(removeTasks).then(function () {
        if (!voucher || voucher.status === "VOID") return null;

        const type = voucher.voucherType;
        if (
          type === "QUOTATION" ||
          type === "ESTIMATE" ||
          type === "PROFORMA" ||
          type === "CHALLAN" ||
          type === "PURCHASE_ORDER" ||
          type === "SALES_ORDER" ||
          type === "WORK_ORDER" ||
          type === "COMPLETION_CERT"
        ) {
          return null;
        }

        const total = Number(voucher.grandTotal != null ? voucher.grandTotal : voucher.amount) || 0;
        const sub = Number(voucher.subtotal) || 0;
        const gstTax = Number(voucher.taxTotal) || 0;
        const cessTax = Number(voucher.cessTotal) || 0;
        const totalTax = Math.round((gstTax + cessTax) * 100) / 100;
        const ship = Number(voucher.shippingCharge) || 0;
        const roundOff = Number(voucher.roundOff) || 0;
        if (total <= 0) return null;

        let lines = [];
        if (type === "SALE_INVOICE" || type === "BILL_OF_SUPPLY") {
          lines.push({ accountKey: "RECEIVABLE", debit: total, credit: 0 });
          if (sub > 0) lines.push({ accountKey: "SALES", debit: 0, credit: sub });
          if (totalTax > 0) lines.push({ accountKey: "GST_OUTPUT", debit: 0, credit: totalTax });
          if (ship > 0) lines.push({ accountKey: "OTHER_INCOME", debit: 0, credit: ship });
          if (roundOff > 0) lines.push({ accountKey: "OTHER_INCOME", debit: 0, credit: roundOff });
          if (roundOff < 0) lines.push({ accountKey: "OPERATING_EXP", debit: Math.abs(roundOff), credit: 0 });
        } else if (type === "CREDIT_NOTE") {
          if (sub > 0) lines.push({ accountKey: "SALES", debit: sub, credit: 0 });
          if (totalTax > 0) lines.push({ accountKey: "GST_OUTPUT", debit: totalTax, credit: 0 });
          if (ship > 0) lines.push({ accountKey: "OTHER_INCOME", debit: ship, credit: 0 });
          if (roundOff > 0) lines.push({ accountKey: "OTHER_INCOME", debit: roundOff, credit: 0 });
          if (roundOff < 0) lines.push({ accountKey: "OPERATING_EXP", debit: 0, credit: Math.abs(roundOff) });
          lines.push({ accountKey: "RECEIVABLE", debit: 0, credit: total });
        } else if (type === "PURCHASE_BILL") {
          const purCost = Math.round((sub + ship) * 100) / 100;
          if (purCost > 0) lines.push({ accountKey: "PURCHASE", debit: purCost, credit: 0 });
          if (totalTax > 0) lines.push({ accountKey: "GST_INPUT", debit: totalTax, credit: 0 });
          if (roundOff > 0) lines.push({ accountKey: "OPERATING_EXP", debit: roundOff, credit: 0 });
          if (roundOff < 0) lines.push({ accountKey: "OTHER_INCOME", debit: 0, credit: Math.abs(roundOff) });
          lines.push({ accountKey: "PAYABLE", debit: 0, credit: total });
        } else if (type === "DEBIT_NOTE") {
          const purRev = Math.round((sub + ship) * 100) / 100;
          lines.push({ accountKey: "PAYABLE", debit: total, credit: 0 });
          if (purRev > 0) lines.push({ accountKey: "PURCHASE", debit: 0, credit: purRev });
          if (totalTax > 0) lines.push({ accountKey: "GST_INPUT", debit: 0, credit: totalTax });
          if (roundOff > 0) lines.push({ accountKey: "OPERATING_EXP", debit: 0, credit: roundOff });
          if (roundOff < 0) lines.push({ accountKey: "OTHER_INCOME", debit: Math.abs(roundOff), credit: 0 });
        } else if (type === "RECEIPT") {
          lines = [
            { accountKey: getCashOrBankKey(voucher.mode), debit: total, credit: 0 },
            { accountKey: "RECEIVABLE", debit: 0, credit: total }
          ];
        } else if (type === "PAYMENT") {
          lines = [
            { accountKey: "PAYABLE", debit: total, credit: 0 },
            { accountKey: getCashOrBankKey(voucher.mode), debit: 0, credit: total }
          ];
        } else if (type === "EXPENSE_VOUCHER") {
          const expBase = Math.round((sub + ship + (roundOff > 0 ? roundOff : 0)) * 100) / 100 || total;
          lines.push({ accountKey: "OPERATING_EXP", debit: expBase, credit: 0 });
          if (totalTax > 0) lines.push({ accountKey: "GST_INPUT", debit: totalTax, credit: 0 });
          if (roundOff < 0) lines.push({ accountKey: "OTHER_INCOME", debit: 0, credit: Math.abs(roundOff) });
          const paidAmt = Math.min(total, Math.max(0, Number(voucher.paidAmount) || 0));
          const unpaidAmt = Math.round((total - paidAmt) * 100) / 100;
          if (paidAmt > 0) lines.push({ accountKey: getCashOrBankKey(voucher.mode), debit: 0, credit: paidAmt });
          if (unpaidAmt > 0) lines.push({ accountKey: "PAYABLE", debit: 0, credit: unpaidAmt });
        }

        if (lines.length === 0) return null;

        const now = new Date().toISOString();
        return global.PBM_DB.put("journalEntries", {
          id: global.PBM_DB.generateId("jrn"),
          businessId: businessId,
          refVoucherId: voucher.id,
          date: voucher.date,
          narration: (voucher.voucherNo || type) + " · " + (voucher.partyName || ""),
          lines: lines,
          isAuto: true,
          reconciled: Boolean(voucher.reconciled),
          createdAt: now,
          updatedAt: now
        });
      });
    });
  }

  function formatDocNumberFromSettings(type, settings) {
    const biz = global.PBM_APP.getActiveBusiness();
    const s = settings && settings.series && settings.series[type]
      ? settings.series[type]
      : { prefix: DEFAULT_PREFIX[type] || "PF/DOC/", suffix: "", nextNo: 1 };
    const fyPart = settings && settings.useFyPrefix && biz && biz.financialYear
      ? biz.financialYear.replace(/^20/, "") + "/"
      : "";
    const numStr = String(s.nextNo || 1).padStart(3, "0");
    return (s.prefix || "") + fyPart + numStr + (s.suffix || "");
  }

  function incrementSeriesCounter(type) {
    const s = viewState.docSettings;
    if (!s) return Promise.resolve();
    if (!s.series) s.series = {};
    if (!s.series[type]) {
      s.series[type] = { prefix: DEFAULT_PREFIX[type] || "PF/DOC/", suffix: "", nextNo: 1 };
    }
    s.series[type].nextNo = (Number(s.series[type].nextNo) || 1) + 1;
    s.updatedAt = new Date().toISOString();
    return global.PBM_DB.put("docSettings", s);
  }

  function addDaysToIso(dateStr, days) {
    if (!dateStr) return "";
    const dt = new Date(dateStr + "T00:00:00");
    if (isNaN(dt.getTime())) return "";
    dt.setDate(dt.getDate() + days);
    return dt.toISOString().slice(0, 10);
  }

  function getTermsDays(terms) {
    if (terms === "Due on Receipt") return 0;
    if (terms === "Net 7 Days") return 7;
    if (terms === "Net 15 Days") return 15;
    if (terms === "Net 30 Days") return 30;
    return null;
  }

  function ensureBillingListsLoaded() {
    const app = global.PBM_APP;
    const businessId = app.getActiveBusinessId();
    return global.PBM_DB.ensureBusinessMasters(businessId)
      .then(function () {
        return Promise.all([
          global.PBM_DB.getByBusiness("parties", businessId),
          global.PBM_DB.getByBusiness("items", businessId),
          global.PBM_DB.getByBusiness("warehouses", businessId),
          global.PBM_DB.getByBusiness("docSettings", businessId),
          global.PBM_TEMPLATES ? global.PBM_TEMPLATES.getTemplatesForBusiness(businessId) : Promise.resolve([])
        ]);
      })
      .then(function (results) {
        viewState.parties = results[0] || [];
        viewState.items = results[1] || [];
        viewState.warehouses = results[2] || [];
        viewState.docSettings = (results[3] && results[3][0]) || global.PBM_DB.getDefaultDocSettings(businessId);
        viewState.templates = results[4] || [];
      });
  }

  function openDocumentModal(existingVoucher, forcedType, forcedTemplateId) {
    if (viewState.templates.length === 0 || !viewState.docSettings || viewState.warehouses.length === 0) {
      ensureBillingListsLoaded().then(function () {
        openDocumentModal(existingVoucher, forcedType, forcedTemplateId);
      });
      return;
    }
    const app = global.PBM_APP;
    const biz = app.getActiveBusiness();
    const docSet = viewState.docSettings || global.PBM_DB.getDefaultDocSettings(app.getActiveBusinessId());
    const isEdit = Boolean(existingVoucher && existingVoucher.id);
    const today = new Date().toISOString().slice(0, 10);
    const defaultType = existingVoucher ? existingVoucher.voucherType : forcedType || "SALE_INVOICE";
    const defTerms = docSet.defaultPaymentTerms || "Net 15 Days";
    const defDays = getTermsDays(defTerms);

    const doc = existingVoucher
      ? JSON.parse(JSON.stringify(existingVoucher))
      : {
          voucherType: defaultType,
          voucherNo: formatDocNumberFromSettings(defaultType, docSet),
          partyId: viewState.parties[0] ? viewState.parties[0].id : "",
          date: today,
          paymentTerms: defTerms,
          dueDate: defDays != null ? addDaysToIso(today, defDays) : "",
          gstMode: defaultType === "BILL_OF_SUPPLY" ? "NON_GST" : "GST",
          taxInclusive: "EXCLUSIVE",
          supplyType: "INTRA",
          placeOfSupply: (biz && biz.stateName) || "Gujarat",
          reverseCharge: false,
          warehouseId: viewState.warehouses[0] ? viewState.warehouses[0].id : "",
          templateId: forcedTemplateId || "",
          currencySymbol: docSet.currencySymbol || "₹",
          shippingCharge: 0,
          applyRoundOff: docSet.enableRoundOff !== false,
          customFieldLabel: "",
          customFieldValue: "",
          items: [
            {
              itemId: "",
              name: "",
              hsn: "",
              unit: "Pcs",
              qty: 1,
              rate: 0,
              discountPct: 0,
              gstRate: 18,
              cessRate: 0,
              lineTotal: 0
            }
          ],
          paidAmount: 0,
          mode: "Cash",
          notes: (docSet.termsLibrary && docSet.termsLibrary.length ? docSet.termsLibrary.join("\n") : ""),
          signatureDataUrl: "",
          customerSignatureDataUrl: ""
        };

    const typeOpts = BILLING_TYPES.map(function (tp) {
      return `<option value="${tp}" ${doc.voucherType === tp ? "selected" : ""}>${getDocTypeLabel(tp)}</option>`;
    }).join("");

    const partyOpts =
      viewState.parties.length === 0
        ? `<option value="">-- No Parties (Create in Parties tab) --</option>`
        : viewState.parties
            .map(function (p) {
              return `<option value="${app.escapeHtml(p.id)}" ${p.id === doc.partyId ? "selected" : ""}>${app.escapeHtml(p.name)}</option>`;
            })
            .join("");

    const whOpts = viewState.warehouses
      .map(function (w) {
        return `<option value="${app.escapeHtml(w.id)}" ${w.id === doc.warehouseId ? "selected" : ""}>${app.escapeHtml(w.name)}</option>`;
      })
      .join("");

    const tplOpts =
      `<option value="">-- Category Default Design --</option>` +
      viewState.templates
        .map(function (t) {
          return `<option value="${app.escapeHtml(t.id)}" ${t.id === doc.templateId ? "selected" : ""}>${app.escapeHtml(t.name)}</option>`;
        })
        .join("");

    const termsLibOpts =
      `<option value="">-- ${tr("fieldTermsPick")} --</option>` +
      (docSet.termsLibrary || [])
        .map(function (tStr, idx) {
          return `<option value="${idx}">${app.escapeHtml(tStr.slice(0, 55))}</option>`;
        })
        .join("");

    const html = `
      <form id="docForm" class="form-grid" novalidate>
        <div id="docFormErr" class="form-error hidden"></div>

        <div class="form-row-2">
          <div class="form-group">
            <label class="form-label" for="docTypeSelect">${tr("fieldDocType")}</label>
            <select id="docTypeSelect" class="form-select" ${isEdit ? "disabled" : ""}>${typeOpts}</select>
          </div>
          <div class="form-group">
            <label class="form-label" for="docNoInput">${tr("fieldDocNo")}</label>
            <input id="docNoInput" class="form-input" type="text" value="${app.escapeHtml(doc.voucherNo)}" required />
          </div>
        </div>

        <div class="form-row-2">
          <div class="form-group">
            <label class="form-label" for="docPartySelect">${tr("fieldParty")}</label>
            <select id="docPartySelect" class="form-select">${partyOpts}</select>
          </div>
          <div class="form-group">
            <div class="card-header-row" style="margin-bottom:0;">
              <label class="form-label" for="docTplSelect">${tr("fieldTemplate")}</label>
              <button id="docBrowseTplBtn" class="secondary-btn" type="button" style="min-height:26px;padding:2px 8px;font-size:0.72rem;">Browse Gallery</button>
            </div>
            <select id="docTplSelect" class="form-select">${tplOpts}</select>
          </div>
        </div>

        <div class="form-row-2">
          <div class="form-group">
            <label class="form-label" for="docDateInput">${tr("fieldDate")}</label>
            <input id="docDateInput" class="form-input" type="date" value="${app.escapeHtml(doc.date)}" required />
          </div>
          <div class="form-group">
            <label class="form-label" for="docPayTerms">${tr("fieldPayTerms")}</label>
            <select id="docPayTerms" class="form-select">
              <option value="Due on Receipt" ${doc.paymentTerms === "Due on Receipt" ? "selected" : ""}>Due on Receipt</option>
              <option value="Net 7 Days" ${doc.paymentTerms === "Net 7 Days" ? "selected" : ""}>Net 7 Days</option>
              <option value="Net 15 Days" ${doc.paymentTerms === "Net 15 Days" ? "selected" : ""}>Net 15 Days</option>
              <option value="Net 30 Days" ${doc.paymentTerms === "Net 30 Days" ? "selected" : ""}>Net 30 Days</option>
              <option value="Custom" ${doc.paymentTerms === "Custom" ? "selected" : ""}>Custom</option>
            </select>
          </div>
        </div>

        <div class="form-row-2">
          <div class="form-group">
            <label class="form-label" for="docDueInput">${tr("fieldDueDate")}</label>
            <input id="docDueInput" class="form-input" type="date" value="${app.escapeHtml(doc.dueDate || "")}" />
          </div>
          <div class="form-group">
            <label class="form-label" for="docPosInput">${tr("fieldPos")}</label>
            <input id="docPosInput" class="form-input" type="text" value="${app.escapeHtml(doc.placeOfSupply || (biz && biz.stateName) || "Gujarat")}" />
          </div>
        </div>

        <div class="form-row-2">
          <div class="form-group">
            <label class="form-label" for="docGstMode">${tr("fieldGstMode")}</label>
            <select id="docGstMode" class="form-select">
              <option value="GST" ${doc.gstMode !== "NON_GST" ? "selected" : ""}>${tr("modeGst")}</option>
              <option value="NON_GST" ${doc.gstMode === "NON_GST" ? "selected" : ""}>${tr("modeNonGst")}</option>
            </select>
          </div>
          <div class="form-group" id="docPricingWrap">
            <label class="form-label" for="docTaxPricing">${tr("fieldTaxPricing")}</label>
            <select id="docTaxPricing" class="form-select">
              <option value="EXCLUSIVE" ${doc.taxInclusive !== "INCLUSIVE" ? "selected" : ""}>${tr("pricingExcl")}</option>
              <option value="INCLUSIVE" ${doc.taxInclusive === "INCLUSIVE" ? "selected" : ""}>${tr("pricingIncl")}</option>
            </select>
          </div>
        </div>

        <div class="form-row-2">
          <div class="form-group" id="docSupplyWrap">
            <label class="form-label" for="docSupplyType">${tr("fieldSupplyType")}</label>
            <select id="docSupplyType" class="form-select">
              <option value="INTRA" ${doc.supplyType !== "INTER" ? "selected" : ""}>${tr("supplyIntra")}</option>
              <option value="INTER" ${doc.supplyType === "INTER" ? "selected" : ""}>${tr("supplyInter")}</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label" for="docWhSelect">${tr("fieldWarehouse")}</label>
            <select id="docWhSelect" class="form-select">${whOpts}</select>
          </div>
        </div>

        <div class="btn-row">
          <label class="check-chip"><input type="checkbox" id="docRcmChk" ${doc.reverseCharge ? "checked" : ""}/> ${tr("fieldRcm")}</label>
          <label class="check-chip"><input type="checkbox" id="docRoundChk" ${doc.applyRoundOff !== false ? "checked" : ""}/> ${tr("fieldRoundOff")}</label>
        </div>

        <div class="card-header-row" style="margin:6px 0 0;">
          <strong style="font-size:0.9rem;">${tr("itemsSectionTitle")}</strong>
          <button id="addLineBtn" class="secondary-btn" type="button">${tr("addLineItemBtn")}</button>
        </div>

        <div id="lineItemsWrap" class="list-stack"></div>

        <div class="form-row-2">
          <div class="form-group">
            <label class="form-label" for="docShipInput">${tr("fieldShipping")}</label>
            <input id="docShipInput" class="form-input" type="number" min="0" step="0.01" value="${Number(doc.shippingCharge || 0)}" />
          </div>
          <div class="form-group">
            <label class="form-label" for="docCustVal">${tr("fieldCustomVal")}</label>
            <input id="docCustVal" class="form-input" type="text" placeholder="${tr("fieldCustomLbl")}" value="${app.escapeHtml(doc.customFieldValue || "")}" />
          </div>
        </div>

        <div class="ledger-summary-box" style="flex-direction:column;align-items:stretch;gap:4px;">
          <div class="list-item-top"><span>${tr("subtotalLabel")}</span><strong id="docSubtotalTxt" class="tabular-nums">₹0.00</strong></div>
          <div class="list-item-top"><span>${tr("taxLabel")}</span><strong id="docTaxTxt" class="tabular-nums">₹0.00</strong></div>
          <div class="list-item-top"><span>${tr("cessLabel")}</span><strong id="docCessTxt" class="tabular-nums">₹0.00</strong></div>
          <div class="list-item-top"><span>${tr("roundOffLabel")}</span><strong id="docRoundTxt" class="tabular-nums">₹0.00</strong></div>
          <div class="list-item-top" style="font-size:1.05rem;"><strong>${tr("grandTotalLabel")}</strong><strong id="docGrandTxt" class="tabular-nums">₹0.00</strong></div>
        </div>

        ${
          !isEdit
            ? `
          <div class="form-row-2" id="docPaidNowWrap">
            <div class="form-group">
              <label class="form-label" for="docPaidNowInput">${tr("fieldPaidNow")}</label>
              <input id="docPaidNowInput" class="form-input" type="number" min="0" step="0.01" value="0" />
            </div>
            <div class="form-group">
              <label class="form-label" for="docPayModeSelect">${tr("fieldPayMode")}</label>
              <select id="docPayModeSelect" class="form-select">
                <option value="Cash">Cash</option>
                <option value="UPI">UPI</option>
                <option value="Bank">Bank</option>
                <option value="Cheque">Cheque</option>
              </select>
            </div>
          </div>
        `
            : ""
        }

        <div class="form-group">
          <label class="form-label" for="docTermsPicker">${tr("fieldTermsPick")}</label>
          <select id="docTermsPicker" class="form-select">${termsLibOpts}</select>
        </div>

        <div class="form-group">
          <div class="card-header-row" style="margin-bottom:4px;">
            <label class="form-label" for="docNotesInput">${tr("fieldNotes")}</label>
            <button id="docSaveTermsDefaultBtn" class="secondary-btn" type="button" style="min-height:30px;padding:4px 8px;font-size:0.75rem;">${app.getLang() === "hi" ? "डिफ़ॉल्ट T&C सेव करें" : "Save T&C as Default"}</button>
          </div>
          <textarea id="docNotesInput" class="form-textarea" rows="3">${app.escapeHtml(doc.notes || "")}</textarea>
          <div class="btn-row" style="margin-top:6px;">
            ${(docSet.termsLibrary || [])
              .map(function (tLine, idx) {
                const lbl = tLine.length > 34 ? tLine.slice(0, 34) + "..." : tLine;
                return `<button type="button" class="secondary-btn" data-quick-tc="${idx}" style="min-height:30px;padding:4px 8px;font-size:0.74rem;">+ ${app.escapeHtml(lbl)}</button>`;
              })
              .join("")}
          </div>
        </div>

        <div class="btn-row">
          <button id="docSignBtn" class="secondary-btn" type="button">${tr("signBtn")}</button>
          <button id="docCustSignBtn" class="secondary-btn" type="button">${tr("custSignBtn")}</button>
          <span id="docSigBadge" class="list-item-meta ${doc.signatureDataUrl || doc.customerSignatureDataUrl ? "" : "hidden"}">${tr("signedLabel")}</span>
        </div>

        <div class="modal-actions">
          <button id="docCancelBtn" class="secondary-btn" type="button">${tr("cancelBtn")}</button>
          <button class="primary-btn" type="submit">${tr("saveBtn")}</button>
        </div>
      </form>
    `;

    app.openModal(isEdit ? tr("modalTitleEdit") : tr("modalTitleCreate"), html);
    document.getElementById("docCancelBtn").addEventListener("click", app.closeModal);
    const browseTplBtn = document.getElementById("docBrowseTplBtn");
    if (browseTplBtn) {
      browseTplBtn.addEventListener("click", function () {
        app.closeModal();
        app.navigateTo("templates");
      });
    }

    const typeSel = document.getElementById("docTypeSelect");
    const gstModeSel = document.getElementById("docGstMode");
    const pricingSel = document.getElementById("docTaxPricing");
    const shipInput = document.getElementById("docShipInput");
    const roundChk = document.getElementById("docRoundChk");
    const lineItemsWrap = document.getElementById("lineItemsWrap");
    const dateInput = document.getElementById("docDateInput");
    const termsSel = document.getElementById("docPayTerms");
    const dueInput = document.getElementById("docDueInput");

    function updateDueFromTerms() {
      const days = getTermsDays(termsSel.value);
      if (days != null && dateInput.value) {
        dueInput.value = addDaysToIso(dateInput.value, days);
      }
    }
    termsSel.addEventListener("change", updateDueFromTerms);
    dateInput.addEventListener("change", updateDueFromTerms);

    document.getElementById("docTermsPicker").addEventListener("change", function (e) {
      const idx = parseInt(e.target.value, 10);
      if (!isNaN(idx) && docSet.termsLibrary && docSet.termsLibrary[idx]) {
        const notesEl = document.getElementById("docNotesInput");
        notesEl.value = (notesEl.value ? notesEl.value + "\n" : "") + docSet.termsLibrary[idx];
      }
    });

    document.querySelectorAll("[data-quick-tc]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        const idx = parseInt(btn.getAttribute("data-quick-tc"), 10);
        const clause = docSet.termsLibrary && docSet.termsLibrary[idx];
        const notesEl = document.getElementById("docNotesInput");
        if (clause && notesEl && notesEl.value.indexOf(clause) === -1) {
          notesEl.value = notesEl.value.trim() ? notesEl.value.trim() + "\n" + clause : clause;
        }
      });
    });

    const saveTermsDefaultBtn = document.getElementById("docSaveTermsDefaultBtn");
    if (saveTermsDefaultBtn) {
      saveTermsDefaultBtn.addEventListener("click", function () {
        const notesEl = document.getElementById("docNotesInput");
        const lines = (notesEl ? notesEl.value : "")
          .split(/\r?\n/)
          .map(function (s) { return s.trim(); })
          .filter(Boolean);
        docSet.termsLibrary = lines;
        docSet.updatedAt = new Date().toISOString();
        global.PBM_DB.put("docSettings", docSet).then(function () {
          app.showToast(app.getLang() === "hi" ? "डिफ़ॉल्ट T&C सेव हो गए।" : "Default T&C library saved.", false);
        });
      });
    }

    function recalcTotals() {
      const isNonGst = gstModeSel.value === "NON_GST";
      const isIncl = pricingSel.value === "INCLUSIVE";
      document.getElementById("docSupplyWrap").classList.toggle("hidden", isNonGst);
      document.getElementById("docPricingWrap").classList.toggle("hidden", isNonGst);

      let subtotal = 0;
      let taxTotal = 0;
      let cessTotal = 0;

      doc.items.forEach(function (line, idx) {
        const qty = Math.max(0, Number(line.qty) || 0);
        const rate = Math.max(0, Number(line.rate) || 0);
        const disc = Math.min(100, Math.max(0, Number(line.discountPct) || 0));
        const gst = isNonGst ? 0 : Math.max(0, Number(line.gstRate) || 0);
        const cess = isNonGst ? 0 : Math.max(0, Number(line.cessRate) || 0);

        const netLineAmount = qty * rate * (1 - disc / 100);
        let taxable = netLineAmount;
        let gstAmt = 0;
        let cessAmt = 0;

        if (!isNonGst && isIncl && (gst + cess) > 0) {
          taxable = netLineAmount / (1 + (gst + cess) / 100);
          gstAmt = taxable * (gst / 100);
          cessAmt = taxable * (cess / 100);
        } else {
          gstAmt = taxable * (gst / 100);
          cessAmt = taxable * (cess / 100);
        }

        line.lineTotal = Math.round((taxable + gstAmt + cessAmt) * 100) / 100;
        subtotal += taxable;
        taxTotal += gstAmt;
        cessTotal += cessAmt;

        const lineTotalEl = document.getElementById("lineTotal_" + idx);
        if (lineTotalEl) lineTotalEl.textContent = app.formatCurrency(line.lineTotal);
      });

      subtotal = Math.round(subtotal * 100) / 100;
      taxTotal = Math.round(taxTotal * 100) / 100;
      cessTotal = Math.round(cessTotal * 100) / 100;
      const ship = Math.max(0, parseFloat(shipInput.value) || 0);
      const rawGrand = subtotal + taxTotal + cessTotal + ship;
      const grand = roundChk.checked ? Math.round(rawGrand) : Math.round(rawGrand * 100) / 100;
      const roundOff = Math.round((grand - rawGrand) * 100) / 100;

      document.getElementById("docSubtotalTxt").textContent = app.formatCurrency(subtotal);
      document.getElementById("docTaxTxt").textContent = app.formatCurrency(taxTotal);
      document.getElementById("docCessTxt").textContent = app.formatCurrency(cessTotal);
      document.getElementById("docRoundTxt").textContent = app.formatCurrency(roundOff);
      document.getElementById("docGrandTxt").textContent = app.formatCurrency(grand);

      return {
        subtotal: subtotal,
        taxTotal: taxTotal,
        cessTotal: cessTotal,
        shippingCharge: ship,
        roundOff: roundOff,
        grandTotal: grand
      };
    }

    function renderLines() {
      const invOpts =
        `<option value="">${tr("customItemOpt")}</option>` +
        viewState.items
          .map(function (i) {
            return `<option value="${app.escapeHtml(i.id)}">${app.escapeHtml(i.name)} (${app.formatCurrency(i.salePrice)})</option>`;
          })
          .join("");

      lineItemsWrap.innerHTML = doc.items
        .map(function (line, idx) {
          return `
            <div class="list-item-card" style="padding:10px;background:var(--bg-canvas);">
              <div class="form-row-2">
                <div class="form-group">
                  <select class="form-select" data-line-pick="${idx}" aria-label="${tr("pickInventoryLabel")}">${invOpts}</select>
                </div>
                <div class="form-group">
                  <input class="form-input" type="text" placeholder="${tr("fieldHsn")}" data-line-hsn="${idx}" value="${app.escapeHtml(line.hsn || "")}" />
                </div>
              </div>
              <div class="form-group">
                <input class="form-input" type="text" placeholder="${tr("fieldItemName")}" data-line-name="${idx}" value="${app.escapeHtml(line.name)}" />
              </div>
              <div class="form-row-4">
                <div class="form-group">
                  <label class="form-label">${tr("fieldQty")}</label>
                  <input class="form-input" type="number" min="0.01" step="0.01" data-line-qty="${idx}" value="${line.qty}" />
                </div>
                <div class="form-group">
                  <label class="form-label">${tr("fieldRate")}</label>
                  <input class="form-input" type="number" min="0" step="0.01" data-line-rate="${idx}" value="${line.rate}" />
                </div>
                <div class="form-group">
                  <label class="form-label">${tr("fieldDisc")}</label>
                  <input class="form-input" type="number" min="0" max="100" step="0.5" data-line-disc="${idx}" value="${line.discountPct || 0}" />
                </div>
                <div class="form-group">
                  <label class="form-label">${tr("fieldGstPct")}</label>
                  <input class="form-input" type="number" min="0" max="28" step="1" data-line-gst="${idx}" value="${line.gstRate || 0}" />
                </div>
              </div>
              <div class="list-item-top" style="align-items:center;">
                <div class="btn-row">
                  <label class="list-item-meta">${tr("fieldCessPct")}: <input type="number" min="0" max="25" step="0.5" data-line-cess="${idx}" value="${line.cessRate || 0}" style="width:56px;padding:4px;border:1px solid var(--border-hairline);border-radius:6px;background:var(--bg-surface);color:var(--text-primary);" /></label>
                </div>
                <div class="btn-row">
                  <strong id="lineTotal_${idx}" class="tabular-nums">${app.formatCurrency(line.lineTotal)}</strong>
                  ${doc.items.length > 1 ? `<button class="mini-danger-btn" type="button" data-line-rem="${idx}">${tr("btnDelete")}</button>` : ""}
                </div>
              </div>
            </div>
          `;
        })
        .join("");

      doc.items.forEach(function (line, idx) {
        const pickEl = lineItemsWrap.querySelector('[data-line-pick="' + idx + '"]');
        if (pickEl && line.itemId) pickEl.value = line.itemId;
        if (pickEl) {
          pickEl.addEventListener("change", function () {
            const found = viewState.items.find(function (i) { return i.id === pickEl.value; });
            if (found) {
              const isPurch = typeSel.value === "PURCHASE_BILL" || typeSel.value === "PURCHASE_ORDER" || typeSel.value === "DEBIT_NOTE";
              line.itemId = found.id;
              line.name = found.name;
              line.hsn = found.hsn || "";
              line.unit = found.unit || "Pcs";
              line.rate = isPurch ? Number(found.purchasePrice || found.salePrice || 0) : Number(found.salePrice || 0);
              line.gstRate = Number(found.gstRate || 0);
              renderLines();
            } else {
              line.itemId = "";
            }
          });
        }

        lineItemsWrap.querySelector('[data-line-hsn="' + idx + '"]').addEventListener("input", function (e) { line.hsn = e.target.value; });
        lineItemsWrap.querySelector('[data-line-name="' + idx + '"]').addEventListener("input", function (e) { line.name = e.target.value; });
        lineItemsWrap.querySelector('[data-line-qty="' + idx + '"]').addEventListener("input", function (e) { line.qty = parseFloat(e.target.value) || 0; recalcTotals(); });
        lineItemsWrap.querySelector('[data-line-rate="' + idx + '"]').addEventListener("input", function (e) { line.rate = parseFloat(e.target.value) || 0; recalcTotals(); });
        lineItemsWrap.querySelector('[data-line-disc="' + idx + '"]').addEventListener("input", function (e) { line.discountPct = parseFloat(e.target.value) || 0; recalcTotals(); });
        lineItemsWrap.querySelector('[data-line-gst="' + idx + '"]').addEventListener("input", function (e) { line.gstRate = parseFloat(e.target.value) || 0; recalcTotals(); });
        lineItemsWrap.querySelector('[data-line-cess="' + idx + '"]').addEventListener("input", function (e) { line.cessRate = parseFloat(e.target.value) || 0; recalcTotals(); });
        const remBtn = lineItemsWrap.querySelector('[data-line-rem="' + idx + '"]');
        if (remBtn) {
          remBtn.addEventListener("click", function () {
            doc.items.splice(idx, 1);
            renderLines();
          });
        }
      });

      recalcTotals();
    }

    function snapshotFormState() {
      return Object.assign({}, doc, {
        id: isEdit ? existingVoucher.id : null,
        voucherType: typeSel.value,
        voucherNo: document.getElementById("docNoInput").value,
        partyId: document.getElementById("docPartySelect").value,
        templateId: document.getElementById("docTplSelect").value,
        date: dateInput.value,
        paymentTerms: termsSel.value,
        dueDate: dueInput.value,
        placeOfSupply: document.getElementById("docPosInput").value,
        gstMode: gstModeSel.value,
        taxInclusive: pricingSel.value,
        supplyType: document.getElementById("docSupplyType").value,
        warehouseId: document.getElementById("docWhSelect").value,
        reverseCharge: document.getElementById("docRcmChk").checked,
        applyRoundOff: roundChk.checked,
        shippingCharge: parseFloat(shipInput.value) || 0,
        customFieldLabel: "Ref / Site",
        customFieldValue: document.getElementById("docCustVal").value,
        notes: document.getElementById("docNotesInput").value
      });
    }

    typeSel.addEventListener("change", function () {
      if (!isEdit) {
        document.getElementById("docNoInput").value = formatDocNumberFromSettings(typeSel.value, docSet);
      }
      if (typeSel.value === "BILL_OF_SUPPLY") {
        gstModeSel.value = "NON_GST";
        recalcTotals();
      }
      const paidWrap = document.getElementById("docPaidNowWrap");
      if (paidWrap) {
        const allowPay =
          typeSel.value === "SALE_INVOICE" ||
          typeSel.value === "BILL_OF_SUPPLY" ||
          typeSel.value === "PURCHASE_BILL" ||
          typeSel.value === "EXPENSE_VOUCHER";
        paidWrap.classList.toggle("hidden", !allowPay);
      }
    });

    [gstModeSel, pricingSel, shipInput, roundChk].forEach(function (el) {
      el.addEventListener("change", recalcTotals);
      el.addEventListener("input", recalcTotals);
    });

    document.getElementById("addLineBtn").addEventListener("click", function () {
      doc.items.push({
        itemId: "",
        name: "",
        hsn: "",
        unit: "Pcs",
        qty: 1,
        rate: 0,
        discountPct: 0,
        gstRate: 18,
        cessRate: 0,
        lineTotal: 0
      });
      renderLines();
    });

    document.getElementById("docSignBtn").addEventListener("click", function () {
      const snap = snapshotFormState();
      global.PBM_PRINT.openSignaturePadModal(tr("signBtn"), doc.signatureDataUrl, function (sigDataUrl) {
        snap.signatureDataUrl = sigDataUrl;
        openDocumentModal(snap, snap.voucherType);
      });
    });

    document.getElementById("docCustSignBtn").addEventListener("click", function () {
      const snap = snapshotFormState();
      global.PBM_PRINT.openSignaturePadModal(tr("custSignBtn"), doc.customerSignatureDataUrl, function (sigDataUrl) {
        snap.customerSignatureDataUrl = sigDataUrl;
        openDocumentModal(snap, snap.voucherType);
      });
    });

    renderLines();

    document.getElementById("docForm").addEventListener("submit", function (event) {
      event.preventDefault();
      const errBox = document.getElementById("docFormErr");
      const voucherType = typeSel.value;
      const voucherNo = document.getElementById("docNoInput").value.trim() || formatDocNumberFromSettings(voucherType, docSet);
      const partyId = document.getElementById("docPartySelect").value;
      const party = viewState.parties.find(function (p) { return p.id === partyId; });

      if (!party && voucherType !== "EXPENSE_VOUCHER") {
        errBox.textContent = tr("errNoParty");
        errBox.classList.remove("hidden");
        return;
      }

      const validItems = doc.items.filter(function (l) {
        return l.name && l.name.trim().length > 0 && Number(l.qty) > 0;
      });
      if (validItems.length === 0) {
        errBox.textContent = tr("errNoItems");
        errBox.classList.remove("hidden");
        return;
      }

      doc.items = validItems;
      const totals = recalcTotals();
      const businessId = app.getActiveBusinessId();
      const now = new Date().toISOString();

      const paidNowInput = document.getElementById("docPaidNowInput");
      const defaultPaid = voucherType === "RECEIPT" || voucherType === "EXPENSE_VOUCHER" ? totals.grandTotal : 0;
      const paidNow = !isEdit && paidNowInput
        ? Math.min(totals.grandTotal, Math.max(0, parseFloat(paidNowInput.value) || (voucherType === "EXPENSE_VOUCHER" ? totals.grandTotal : 0)))
        : Number(doc.paidAmount || defaultPaid);
      const payMode = document.getElementById("docPayModeSelect") ? document.getElementById("docPayModeSelect").value : doc.mode || "Cash";

      const record = {
        id: isEdit ? existingVoucher.id : global.PBM_DB.generateId("vch"),
        businessId: businessId,
        voucherType: voucherType,
        voucherNo: voucherNo,
        partyId: party ? party.id : "",
        partyName: party ? party.name : "Cash Expense",
        templateId: document.getElementById("docTplSelect").value,
        currencySymbol: docSet.currencySymbol || "₹",
        date: dateInput.value || today,
        paymentTerms: termsSel.value,
        dueDate: dueInput.value || "",
        placeOfSupply: document.getElementById("docPosInput").value.trim(),
        gstMode: gstModeSel.value,
        taxInclusive: pricingSel.value,
        supplyType: document.getElementById("docSupplyType").value,
        reverseCharge: document.getElementById("docRcmChk").checked,
        applyRoundOff: roundChk.checked,
        warehouseId: document.getElementById("docWhSelect").value,
        items: validItems,
        subtotal: totals.subtotal,
        taxTotal: totals.taxTotal,
        cessTotal: totals.cessTotal,
        shippingCharge: totals.shippingCharge,
        roundOff: totals.roundOff,
        grandTotal: totals.grandTotal,
        amount: totals.grandTotal,
        paidAmount: paidNow,
        mode: payMode,
        customFieldLabel: document.getElementById("docCustVal").value.trim() ? "Ref / Site" : "",
        customFieldValue: document.getElementById("docCustVal").value.trim(),
        notes: document.getElementById("docNotesInput").value.trim(),
        signatureDataUrl: doc.signatureDataUrl || "",
        customerSignatureDataUrl: doc.customerSignatureDataUrl || "",
        status: existingVoucher && existingVoucher.status ? existingVoucher.status : "OPEN",
        createdAt: isEdit ? existingVoucher.createdAt : now,
        updatedAt: now
      };

      const reverseOldStock = isEdit
        ? applyStockEffect(businessId, existingVoucher, -1)
        : Promise.resolve();

      reverseOldStock
        .then(function () {
          return global.PBM_DB.put("vouchers", record);
        })
        .then(function () {
          return !isEdit ? incrementSeriesCounter(voucherType) : null;
        })
        .then(function () {
          return applyStockEffect(businessId, record, 1);
        })
        .then(function () {
          return syncAccountingForVoucher(businessId, record);
        })
        .then(function () {
          if (!isEdit && paidNow > 0 && (voucherType === "SALE_INVOICE" || voucherType === "BILL_OF_SUPPLY" || voucherType === "PURCHASE_BILL")) {
            const pType = voucherType === "PURCHASE_BILL" ? "PAYMENT" : "RECEIPT";
            const payVch = {
              id: global.PBM_DB.generateId("vch"),
              businessId: businessId,
              partyId: record.partyId,
              partyName: record.partyName,
              voucherType: pType,
              voucherNo: formatDocNumberFromSettings(pType, docSet),
              date: record.date,
              amount: paidNow,
              grandTotal: paidNow,
              mode: payMode,
              linkedVoucherId: record.id,
              notes: "Against " + record.voucherNo,
              createdAt: now,
              updatedAt: now
            };
            return global.PBM_DB.put("vouchers", payVch).then(function () {
              return syncAccountingForVoucher(businessId, payVch);
            });
          }
          return null;
        })
        .then(function () {
          return global.PBM_DB.logAudit(businessId, isEdit ? "UPDATE" : "CREATE", "billing", record.voucherNo + " (" + record.voucherType + ")");
        })
        .then(function () {
          app.closeModal();
          app.showToast(tr("toastSaved"), false);
          app.renderCurrentRoute();
        });
    });
  }

  function openInvoicePaymentModal(voucher) {
    const app = global.PBM_APP;
    const total = Number(voucher.grandTotal) || 0;
    const alreadyPaid = Number(voucher.paidAmount) || 0;
    const due = Math.max(0, Math.round((total - alreadyPaid) * 100) / 100);
    const today = new Date().toISOString().slice(0, 10);

    const html = `
      <form id="invPayForm" class="form-grid" novalidate>
        <div class="list-item-meta"><strong>${app.escapeHtml(voucher.voucherNo)} · ${app.escapeHtml(voucher.partyName)}</strong><br/>Due: ${app.formatCurrency(due)}</div>
        <div class="form-row-2">
          <div class="form-group">
            <label class="form-label" for="ipAmt">Amount *</label>
            <input id="ipAmt" class="form-input" type="number" min="0.01" max="${due}" step="0.01" value="${due}" required />
          </div>
          <div class="form-group">
            <label class="form-label" for="ipDate">Date *</label>
            <input id="ipDate" class="form-input" type="date" value="${today}" required />
          </div>
        </div>
        <div class="form-group">
          <label class="form-label" for="ipMode">Mode</label>
          <select id="ipMode" class="form-select">
            <option value="Cash">Cash</option>
            <option value="UPI">UPI</option>
            <option value="Bank">Bank</option>
            <option value="Cheque">Cheque</option>
          </select>
        </div>
        <div class="modal-actions">
          <button id="ipCancelBtn" class="secondary-btn" type="button">${tr("cancelBtn")}</button>
          <button class="primary-btn" type="submit">${tr("saveBtn")}</button>
        </div>
      </form>
    `;

    app.openModal(tr("btnPay"), html);
    document.getElementById("ipCancelBtn").addEventListener("click", app.closeModal);

    document.getElementById("invPayForm").addEventListener("submit", function (e) {
      e.preventDefault();
      const amt = Math.min(due, Math.max(0, parseFloat(document.getElementById("ipAmt").value) || 0));
      if (amt <= 0) return;
      const businessId = app.getActiveBusinessId();
      const now = new Date().toISOString();
      const pType = voucher.voucherType === "PURCHASE_BILL" ? "PAYMENT" : "RECEIPT";
      const payVch = {
        id: global.PBM_DB.generateId("vch"),
        businessId: businessId,
        partyId: voucher.partyId,
        partyName: voucher.partyName,
        voucherType: pType,
        voucherNo: formatDocNumberFromSettings(pType, viewState.docSettings),
        date: document.getElementById("ipDate").value || today,
        amount: amt,
        grandTotal: amt,
        mode: document.getElementById("ipMode").value,
        linkedVoucherId: voucher.id,
        notes: "Against " + voucher.voucherNo,
        createdAt: now,
        updatedAt: now
      };

      voucher.paidAmount = Math.round((alreadyPaid + amt) * 100) / 100;
      voucher.updatedAt = now;

      Promise.all([
        global.PBM_DB.put("vouchers", voucher),
        global.PBM_DB.put("vouchers", payVch),
        incrementSeriesCounter(pType)
      ])
        .then(function () {
          return syncAccountingForVoucher(businessId, payVch);
        })
        .then(function () {
          app.closeModal();
          app.showToast("Payment recorded!", false);
          app.renderCurrentRoute();
        });
    });
  }

  function convertDocument(sourceVoucher, targetType) {
    const app = global.PBM_APP;
    const businessId = app.getActiveBusinessId();
    const now = new Date().toISOString();
    const converted = JSON.parse(JSON.stringify(sourceVoucher));
    converted.id = global.PBM_DB.generateId("vch");
    converted.voucherType = targetType;
    converted.voucherNo = formatDocNumberFromSettings(targetType, viewState.docSettings);
    converted.date = now.slice(0, 10);
    converted.paidAmount = 0;
    converted.status = "OPEN";
    converted.convertedFrom = sourceVoucher.voucherNo;
    converted.createdAt = now;
    converted.updatedAt = now;

    global.PBM_DB.put("vouchers", converted)
      .then(function () {
        return incrementSeriesCounter(targetType);
      })
      .then(function () {
        return applyStockEffect(businessId, converted, 1);
      })
      .then(function () {
        return syncAccountingForVoucher(businessId, converted);
      })
      .then(function () {
        return global.PBM_DB.logAudit(businessId, "CONVERT", "billing", sourceVoucher.voucherNo + " -> " + converted.voucherNo);
      })
      .then(function () {
        app.showToast(tr("toastConverted"), false);
        app.renderCurrentRoute();
      });
  }

  function duplicateDocument(sourceVoucher) {
    const draft = JSON.parse(JSON.stringify(sourceVoucher));
    delete draft.id;
    draft.voucherNo = formatDocNumberFromSettings(draft.voucherType, viewState.docSettings);
    draft.date = new Date().toISOString().slice(0, 10);
    draft.paidAmount = 0;
    draft.status = "OPEN";
    openDocumentModal(draft, draft.voucherType);
  }

  function handleVoidDocument(voucher) {
    const app = global.PBM_APP;
    app.confirmDialog({
      title: tr("confirmVoidTitle"),
      message: tr("confirmVoidMsg"),
      confirmText: tr("btnVoid"),
      isDanger: true
    }).then(function (ok) {
      if (!ok) return;
      const businessId = app.getActiveBusinessId();
      applyStockEffect(businessId, voucher, -1)
        .then(function () {
          voucher.status = "VOID";
          voucher.updatedAt = new Date().toISOString();
          return global.PBM_DB.put("vouchers", voucher);
        })
        .then(function () {
          return syncAccountingForVoucher(businessId, voucher);
        })
        .then(function () {
          return global.PBM_DB.logAudit(businessId, "VOID", "billing", voucher.voucherNo);
        })
        .then(function () {
          app.showToast(tr("toastVoided"), false);
          app.renderCurrentRoute();
        });
    });
  }

  function handleDeleteDocument(voucher) {
    const app = global.PBM_APP;
    app.confirmDialog({
      title: tr("confirmDelTitle"),
      message: tr("confirmDelMsg"),
      confirmText: tr("deleteBtn"),
      isDanger: true
    }).then(function (ok) {
      if (!ok) return;
      const businessId = app.getActiveBusinessId();
      applyStockEffect(businessId, voucher, -1)
        .then(function () {
          return global.PBM_DB.getByBusiness("journalEntries", businessId);
        })
        .then(function (journals) {
          const dels = journals
            .filter(function (j) { return j.refVoucherId === voucher.id; })
            .map(function (j) { return global.PBM_DB.remove("journalEntries", j.id); });
          return Promise.all(dels);
        })
        .then(function () {
          return global.PBM_DB.remove("vouchers", voucher.id);
        })
        .then(function () {
          return global.PBM_DB.logAudit(businessId, "DELETE", "billing", voucher.voucherNo);
        })
        .then(function () {
          app.showToast(tr("toastDeleted"), false);
          app.renderCurrentRoute();
        });
    });
  }

  function renderDocsList(container) {
    const app = global.PBM_APP;
    const query = viewState.search.trim().toLowerCase();

    const filtered = viewState.vouchers.filter(function (v) {
      if (BILLING_TYPES.indexOf(v.voucherType) === -1) return false;
      if (viewState.filterType !== "ALL" && v.voucherType !== viewState.filterType) return false;
      if (query) {
        const hay = [v.voucherNo, v.partyName, v.voucherType, v.notes].join(" ").toLowerCase();
        return hay.indexOf(query) !== -1;
      }
      return true;
    });

    if (filtered.length === 0) {
      container.innerHTML = `
        <div class="card">
          <h3 class="card-title">${tr("emptyTitle")}</h3>
          <p class="card-subtitle">${tr("emptyDesc")}</p>
        </div>
      `;
      return;
    }

    container.innerHTML = filtered
      .map(function (v) {
        const isVoid = v.status === "VOID";
        const canToInv = !isVoid && ["QUOTATION", "ESTIMATE", "PROFORMA", "CHALLAN", "SALES_ORDER", "WORK_ORDER"].indexOf(v.voucherType) !== -1;
        const canToWo = !isVoid && (v.voucherType === "QUOTATION" || v.voucherType === "ESTIMATE");
        const canToBill = !isVoid && v.voucherType === "PURCHASE_ORDER";
        const canToCert = !isVoid && v.voucherType === "WORK_ORDER";
        const isPayableDoc = !isVoid && ["SALE_INVOICE", "BILL_OF_SUPPLY", "PURCHASE_BILL"].indexOf(v.voucherType) !== -1;

        const paid = Number(v.paidAmount) || 0;
        const total = Number(v.grandTotal != null ? v.grandTotal : v.amount) || 0;
        let statusTxt = tr("statusDoc");
        let statusCls = "text-muted";
        if (isVoid) {
          statusTxt = tr("statusVoid");
          statusCls = "text-payable";
        } else if (isPayableDoc) {
          if (paid >= total - 0.01) {
            statusTxt = tr("statusPaid");
            statusCls = "text-receivable";
          } else if (paid > 0) {
            statusTxt = tr("statusPartial") + " (" + app.formatCurrency(total - paid) + ")";
            statusCls = "text-payable";
          } else {
            statusTxt = tr("statusUnpaid");
            statusCls = "text-payable";
          }
        }

        return `
          <div class="list-item-card" style="${isVoid ? "opacity:0.72;" : ""}">
            <div class="list-item-top">
              <div>
                <h3 class="list-item-title">${app.escapeHtml(v.voucherNo)} · ${app.escapeHtml(v.partyName)}</h3>
                <div class="list-item-meta">${getDocTypeLabel(v.voucherType)} · ${app.escapeHtml(v.date)}${v.dueDate ? " · Due: " + app.escapeHtml(v.dueDate) : ""}${v.convertedFrom ? " · Ref: " + app.escapeHtml(v.convertedFrom) : ""}</div>
              </div>
              <div style="text-align:right;">
                <div class="kpi-value tabular-nums" style="font-size:1.05rem;">${app.formatCurrency(total)}</div>
                <div class="list-item-meta ${statusCls}">${statusTxt}</div>
              </div>
            </div>
            <div class="btn-row">
              <button class="primary-btn" type="button" data-doc-preview="${app.escapeHtml(v.id)}">${tr("btnPreview")}</button>
              <button class="secondary-btn" type="button" data-doc-pdf="${app.escapeHtml(v.id)}">${tr("btnPdf")}</button>
              <button class="secondary-btn" type="button" data-doc-share="${app.escapeHtml(v.id)}">${tr("btnShare")}</button>
              ${isPayableDoc && paid < total - 0.01 ? `<button class="secondary-btn" type="button" data-doc-pay="${app.escapeHtml(v.id)}">${tr("btnPay")}</button>` : ""}
              ${canToInv ? `<button class="secondary-btn" type="button" data-doc-conv-inv="${app.escapeHtml(v.id)}">${tr("btnConvertInv")}</button>` : ""}
              ${canToWo ? `<button class="secondary-btn" type="button" data-doc-conv-wo="${app.escapeHtml(v.id)}">${tr("btnConvertWo")}</button>` : ""}
              ${canToBill ? `<button class="secondary-btn" type="button" data-doc-conv-bill="${app.escapeHtml(v.id)}">${tr("btnConvertBill")}</button>` : ""}
              ${canToCert ? `<button class="secondary-btn" type="button" data-doc-conv-cert="${app.escapeHtml(v.id)}">${tr("btnConvertCert")}</button>` : ""}
              <button class="secondary-btn" type="button" data-doc-dup="${app.escapeHtml(v.id)}">${tr("btnDuplicate")}</button>
              ${!isVoid ? `<button class="secondary-btn" type="button" data-doc-edit="${app.escapeHtml(v.id)}">${tr("btnEdit")}</button>` : ""}
              ${!isVoid ? `<button class="danger-btn" type="button" data-doc-void="${app.escapeHtml(v.id)}">${tr("btnVoid")}</button>` : ""}
              <button class="danger-btn" type="button" data-doc-del="${app.escapeHtml(v.id)}">${tr("btnDelete")}</button>
            </div>
          </div>
        `;
      })
      .join("");

    container.querySelectorAll("[data-doc-preview]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        const doc = viewState.vouchers.find(function (v) { return v.id === btn.getAttribute("data-doc-preview"); });
        if (!doc) return;
        const party = viewState.parties.find(function (p) { return p.id === doc.partyId; });
        global.PBM_PRINT.openDocumentPreviewModal(doc, app.getActiveBusiness(), party, function () {
          app.renderCurrentRoute();
        });
      });
    });

    container.querySelectorAll("[data-doc-pdf]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        const doc = viewState.vouchers.find(function (v) { return v.id === btn.getAttribute("data-doc-pdf"); });
        if (!doc) return;
        const party = viewState.parties.find(function (p) { return p.id === doc.partyId; });
        global.PBM_PRINT.downloadVoucherPdf(doc, app.getActiveBusiness(), party);
      });
    });

    container.querySelectorAll("[data-doc-share]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        const doc = viewState.vouchers.find(function (v) { return v.id === btn.getAttribute("data-doc-share"); });
        if (!doc) return;
        const party = viewState.parties.find(function (p) { return p.id === doc.partyId; });
        global.PBM_PRINT.shareVoucherPdf(doc, app.getActiveBusiness(), party);
      });
    });

    container.querySelectorAll("[data-doc-pay]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        const doc = viewState.vouchers.find(function (v) { return v.id === btn.getAttribute("data-doc-pay"); });
        if (doc) openInvoicePaymentModal(doc);
      });
    });

    container.querySelectorAll("[data-doc-conv-inv]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        const doc = viewState.vouchers.find(function (v) { return v.id === btn.getAttribute("data-doc-conv-inv"); });
        if (doc) convertDocument(doc, "SALE_INVOICE");
      });
    });

    container.querySelectorAll("[data-doc-conv-wo]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        const doc = viewState.vouchers.find(function (v) { return v.id === btn.getAttribute("data-doc-conv-wo"); });
        if (doc) convertDocument(doc, "WORK_ORDER");
      });
    });

    container.querySelectorAll("[data-doc-conv-bill]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        const doc = viewState.vouchers.find(function (v) { return v.id === btn.getAttribute("data-doc-conv-bill"); });
        if (doc) convertDocument(doc, "PURCHASE_BILL");
      });
    });

    container.querySelectorAll("[data-doc-conv-cert]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        const doc = viewState.vouchers.find(function (v) { return v.id === btn.getAttribute("data-doc-conv-cert"); });
        if (doc) convertDocument(doc, "COMPLETION_CERT");
      });
    });

    container.querySelectorAll("[data-doc-dup]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        const doc = viewState.vouchers.find(function (v) { return v.id === btn.getAttribute("data-doc-dup"); });
        if (doc) duplicateDocument(doc);
      });
    });

    container.querySelectorAll("[data-doc-edit]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        const doc = viewState.vouchers.find(function (v) { return v.id === btn.getAttribute("data-doc-edit"); });
        if (doc) openDocumentModal(doc);
      });
    });

    container.querySelectorAll("[data-doc-void]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        const doc = viewState.vouchers.find(function (v) { return v.id === btn.getAttribute("data-doc-void"); });
        if (doc) handleVoidDocument(doc);
      });
    });

    container.querySelectorAll("[data-doc-del]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        const doc = viewState.vouchers.find(function (v) { return v.id === btn.getAttribute("data-doc-del"); });
        if (doc) handleDeleteDocument(doc);
      });
    });
  }

  function render(viewContainer, contextStripHtml) {
    const app = global.PBM_APP;
    const businessId = app.getActiveBusinessId();

    return global.PBM_DB.ensureBusinessMasters(businessId)
      .then(function () {
        return Promise.all([
          global.PBM_DB.getByBusiness("vouchers", businessId),
          global.PBM_DB.getByBusiness("parties", businessId),
          global.PBM_DB.getByBusiness("items", businessId),
          global.PBM_DB.getByBusiness("warehouses", businessId),
          global.PBM_DB.getByBusiness("docSettings", businessId),
          global.PBM_TEMPLATES ? global.PBM_TEMPLATES.getTemplatesForBusiness(businessId) : Promise.resolve([])
        ]);
      })
      .then(function (results) {
        viewState.vouchers = results[0].sort(function (a, b) {
          return (b.date || "").localeCompare(a.date || "") || (b.createdAt || "").localeCompare(a.createdAt || "");
        });
        viewState.parties = results[1];
        viewState.items = results[2];
        viewState.warehouses = results[3];
        viewState.docSettings = results[4][0] || global.PBM_DB.getDefaultDocSettings(businessId);
        viewState.templates = results[5];

        let totalSales = 0;
        let totalPurchases = 0;
        let openQuotes = 0;
        viewState.vouchers.forEach(function (v) {
          if (v.status === "VOID") return;
          if (v.voucherType === "SALE_INVOICE" || v.voucherType === "BILL_OF_SUPPLY") {
            totalSales += Number(v.grandTotal) || 0;
          }
          if (v.voucherType === "PURCHASE_BILL" || v.voucherType === "EXPENSE_VOUCHER") {
            totalPurchases += Number(v.grandTotal) || 0;
          }
          if (["QUOTATION", "ESTIMATE", "PROFORMA", "SALES_ORDER", "WORK_ORDER"].indexOf(v.voucherType) !== -1) {
            openQuotes += 1;
          }
        });

        const filterChips = [
          `<button class="seg-btn ${viewState.filterType === "ALL" ? "active" : ""}" data-doc-filter="ALL" type="button">${tr("filterAll")}</button>`
        ].concat(
          BILLING_TYPES.map(function (tp) {
            return `<button class="seg-btn ${viewState.filterType === tp ? "active" : ""}" data-doc-filter="${tp}" type="button">${getDocTypeLabel(tp)}</button>`;
          })
        );

        viewContainer.innerHTML = `
          ${contextStripHtml}
          <div class="kpi-grid">
            <div class="kpi-card">
              <div class="kpi-label">${tr("kpiSales")}</div>
              <div class="kpi-value tabular-nums text-receivable">${app.formatCurrency(totalSales)}</div>
            </div>
            <div class="kpi-card">
              <div class="kpi-label">${tr("kpiPurchases")}</div>
              <div class="kpi-value tabular-nums text-payable">${app.formatCurrency(totalPurchases)}</div>
            </div>
            <div class="kpi-card">
              <div class="kpi-label">${tr("kpiQuotations")}</div>
              <div class="kpi-value tabular-nums">${openQuotes}</div>
            </div>
          </div>

          <div class="card">
            <div class="toolbar-row">
              <input id="docSearchInput" class="form-input" type="search" placeholder="${tr("searchPlaceholder")}" value="${app.escapeHtml(viewState.search)}" />
              <button id="newDocBtn" class="primary-btn" type="button">${tr("newDocBtn")}</button>
            </div>
            <div class="btn-row" style="margin-top:10px;">
              <button id="quickQuoteBtn" class="secondary-btn" type="button">+ ${tr("typeQUOTATION")}</button>
              <button id="quickEstBtn" class="secondary-btn" type="button">+ ${tr("typeESTIMATE")}</button>
              <button id="quickWoBtn" class="secondary-btn" type="button">+ ${tr("typeWORK_ORDER")}</button>
              <button id="quickExpBtn" class="secondary-btn" type="button">+ ${tr("typeEXPENSE_VOUCHER")}</button>
              <button id="openDesignersBtn" class="secondary-btn" type="button">${tr("designersBtn")}</button>
            </div>
            <div class="segmented-bar is-scrollable">${filterChips.join("")}</div>
          </div>

          <div id="billingListWrap" class="list-stack"></div>
        `;

        const listWrap = document.getElementById("billingListWrap");
        renderDocsList(listWrap);

        document.getElementById("newDocBtn").addEventListener("click", function () { openDocumentModal(null, "SALE_INVOICE"); });
        document.getElementById("quickQuoteBtn").addEventListener("click", function () { openDocumentModal(null, "QUOTATION"); });
        document.getElementById("quickEstBtn").addEventListener("click", function () { openDocumentModal(null, "ESTIMATE"); });
        document.getElementById("quickWoBtn").addEventListener("click", function () { openDocumentModal(null, "WORK_ORDER"); });
        document.getElementById("quickExpBtn").addEventListener("click", function () { openDocumentModal(null, "EXPENSE_VOUCHER"); });
        document.getElementById("openDesignersBtn").addEventListener("click", function () {
          app.navigateTo("templates");
        });

        document.getElementById("docSearchInput").addEventListener("input", function (event) {
          viewState.search = event.target.value;
          renderDocsList(listWrap);
        });

        viewContainer.querySelectorAll("[data-doc-filter]").forEach(function (btn) {
          btn.addEventListener("click", function () {
            viewState.filterType = btn.getAttribute("data-doc-filter");
            viewContainer.querySelectorAll("[data-doc-filter]").forEach(function (b) {
              b.classList.toggle("active", b === btn);
            });
            renderDocsList(listWrap);
          });
        });
      });
  }

  global.PBM_BILLING = {
    render: render,
    setFilter: function (filterType) {
      viewState.filterType = filterType || "ALL";
    },
    syncAccountingForVoucher: syncAccountingForVoucher,
    openDocumentModal: openDocumentModal
  };
})(window);
