'use strict';
/* ============ قسم المعمل ============ */
let ldQ = '';
const labTitle = d => () => S.labReq ? 'إدخال النتائج' : d;

PAGES.lb_wait = {
  title: labTitle('العينات الواردة'), live: false,
  onData() { if (!S.labReq) renderPage(); },
  render() {
    if (S.labReq) return labResult(S.labReq);
    const W = D.labRequests.filter(r => r.status === 'waiting').sort((a, b) => a.ts - b.ts);
    const dn = D.labRequests.filter(r => r.status === 'done' && r.doneDate === today()).length;
    $('page').innerHTML =
      '<div class="stats">' + stat('clock', 'عينات بالانتظار', W.length) + stat('check', 'اكتملت اليوم', dn, 'g') + stat('flask', 'إجمالي طلبات اليوم', D.labRequests.filter(r => r.date === today()).length, 'n') + '</div>' +
      (W.map(r => '<div class="row click" onclick="openLabReq(' + r.id + ')"><div class="av num">' + r.patientNo + '</div><div class="grow"><div class="t">' + esc(r.patientName) + '</div><div>' + r.tests.map(t => '<span class="chip">' + esc(t.name) + '</span>').join('') + '</div><div class="mut">الباركود <span class="ltr num">' + esc(r.barcode) + '</span> · <span class="num">' + r.date + ' ' + hm(r.ts) + '</span>' + (r.doctorName ? ' · د. ' + esc(r.doctorName) : '') + '</div></div><button class="btn sm">' + ic('edit', 'sm') + 'إدخال النتائج</button></div>').join('') || '<div class="card">' + empty('flask', 'لا توجد عينات بالانتظار') + '</div>');
  }
};
PAGES.lb_done = {
  title: labTitle('النتائج المكتملة'), live: false,
  onData() { if (!S.labReq) ldDraw(); },
  render() {
    if (S.labReq) return labResult(S.labReq);
    $('page').innerHTML = '<div class="card"><input class="input" placeholder="ابحث باسم المريض أو رقمه…" value="' + esc(ldQ) + '" oninput="ldQ=this.value;ldDraw()" autocomplete="off"></div><div id="ldlist"></div>'; ldDraw();
  }
};
function ldDraw() {
  const e = $('ldlist'); if (!e) return; const q = ldQ.trim().toLowerCase();
  let D2 = D.labRequests.filter(r => r.status === 'done').sort((a, b) => b.doneTs - a.doneTs);
  if (q) D2 = D2.filter(r => String(r.patientNo) === q || r.patientName.toLowerCase().includes(q)); else D2 = D2.slice(0, 60);
  e.innerHTML = D2.map(r => '<div class="row click" onclick="openLabReq(' + r.id + ')"><div class="av lt num">' + r.patientNo + '</div><div class="grow"><div class="t">' + esc(r.patientName) + '</div><div>' + r.tests.map(t => '<span class="chip">' + esc(t.name) + '</span>').join('') + '</div><div class="mut num">اكتمل ' + r.doneDate + ' · ' + hm(r.doneTs) + (r.doneBy ? ' · ' + esc(r.doneBy) : '') + '</div></div><button class="btn ghost sm icon" onclick="event.stopPropagation();printLab(' + r.id + ')" aria-label="طباعة">' + ic('printer', 'sm') + '</button></div>').join('') || '<div class="card">' + empty('check', 'لا توجد نتائج مكتملة') + '</div>';
}
function openLabReq(id) { S.labReq = id; renderPage().then(() => window.scrollTo(0, 0)); }
function closeLabReq() { S.labReq = null; renderPage(); }

/* ---------- المعدلات الطبيعية والتنبيه ---------- */
function rangeFor(t, age, gender) {
  const rs = (t && t.ranges) || [], a = +age || 0;
  const ok = rs.filter(r => a >= (r.ageMin ?? 0) && a <= (r.ageMax ?? 200) && (r.gender === 'any' || r.gender === gender));
  return ok.find(r => r.gender !== 'any') || ok[0] || null;
}
function rangeText(r) { if (!r) return ''; const l = r.low !== null && r.low !== '' && r.low !== undefined, h = r.high !== null && r.high !== '' && r.high !== undefined; return l && h ? r.low + ' – ' + r.high : l ? '> ' + r.low : h ? '< ' + r.high : ''; }
function calcFlag(v, r) {
  const n = parseFloat(String(v).replace(/[<>]/g, '')); if (isNaN(n) || !r) return '';
  if (r.low !== null && r.low !== '' && r.low !== undefined && n < +r.low) return 'L';
  if (r.high !== null && r.high !== '' && r.high !== undefined && n > +r.high) return 'H'; return 'N';
}
const flagTxt = f => f === 'H' ? '▲ مرتفع' : f === 'L' ? '▼ منخفض' : f === 'N' ? 'طبيعي' : '';

function labResult(id) {
  const r = get('labRequests', id); if (!r) { S.labReq = null; return PAGES[S.page].render(); }
  const ro = r.status === 'done';
  S.lr = { id, ranges: r.tests.map(t => rangeFor(get('labTests', t.testId) || t, r.age, r.gender)) };
  $('page').innerHTML =
    '<div class="card"><div class="ptop"><button class="btn ghost icon" onclick="closeLabReq()" aria-label="رجوع">' + ic('chevr') + '</button><div class="av big num">' + r.patientNo + '</div><div class="grow"><h2 style="font-size:1.2rem">' + esc(r.patientName) + '</h2><div class="mut">' + esc(r.age) + ' سنة · ' + GEN[r.gender || ''] + ' · الباركود <span class="ltr num">' + esc(r.barcode) + '</span>' + (r.doctorName ? ' · الطبيب: ' + esc(r.doctorName) : '') + '</div></div>' + (ro ? badge('مكتمل', 'ok') + '<button class="btn ghost" onclick="printLab(' + r.id + ')">' + ic('printer', 'sm') + 'طباعة التقرير</button>' : badge('بانتظار النتائج', 'warn')) + '</div></div>' +
    '<div class="card"><div class="card-h"><h3>' + ic('flask') + 'النتائج</h3></div>' +
    r.tests.map((t, i) => {
      const x = r.results[t.testId] || {}, rg = S.lr.ranges[i], fl = x.value !== undefined && x.value !== '' ? calcFlag(x.value, rg) : '';
      return '<div class="lrow"><div><b>' + esc(t.name) + '</b> ' + (x.source === 'device' ? '<span class="chip">من الجهاز</span>' : '') + '<div class="mut">' + (rg ? 'الطبيعي: <span class="num">' + rangeText(rg) + '</span>' : 'لا يوجد نطاق محدد') + ' ' + esc(t.unit) + '</div></div>' +
        '<input id="rv' + i + '" class="input num ' + (fl === 'H' || fl === 'L' ? 'f' + fl : '') + '" value="' + esc(x.value) + '"' + (ro ? ' readonly' : '') + ' oninput="liveFlag(' + i + ')" inputmode="decimal" autocomplete="off"><span class="flag ' + (fl === 'H' || fl === 'L' ? 'f' + fl : '') + '" id="rf' + i + '">' + flagTxt(fl) + '</span></div>';
    }).join('') +
    '<div class="field" style="margin-top:1rem"><label>ملاحظات</label><textarea id="lnotes"' + (ro ? ' readonly' : '') + '>' + esc(r.notes) + '</textarea></div>' +
    (ro ? '' : '<div class="btns"><button class="btn ok" onclick="finishLab(' + r.id + ',true)">' + ic('check', 'sm') + 'إكمال وإرسال للطبيب</button><button class="btn ghost" onclick="finishLab(' + r.id + ',false)">حفظ كمسودة</button></div>') + '</div>';
}
function liveFlag(i) {
  const v = $('rv' + i).value, fl = v === '' ? '' : calcFlag(v, S.lr.ranges[i]);
  $('rv' + i).className = 'input num ' + (fl === 'H' || fl === 'L' ? 'f' + fl : ''); const lb = $('rf' + i);
  lb.className = 'flag ' + (fl === 'H' || fl === 'L' ? 'f' + fl : ''); lb.textContent = flagTxt(fl);
}
async function finishLab(id, final) {
  const r = get('labRequests', id), results = {}; let n = 0;
  r.tests.forEach((t, i) => {
    const v = $('rv' + i).value.trim(), old = r.results[t.testId] || {}; if (v === '') return; n++;
    const rg = S.lr.ranges[i]; results[t.testId] = Object.assign({}, old, { value: v, flag: calcFlag(v, rg), range: rangeText(rg), ts: old.value === v && old.ts ? old.ts : nowTs() });
  });
  const upd = { id, results, notes: $('lnotes').value };
  if (final) {
    if (!n) return toast('أدخل نتيجة واحدة على الأقل', 'err');
    Object.assign(upd, { status: 'done', doneTs: nowTs(), doneDate: today(), doneBy: S.me.name, seen: false });
  }
  if (!await safe(() => put('labRequests', upd))) return;
  if (final) { log('labdone', 'اكتملت نتائج المريض ' + r.patientName + ' — نتيجة جاهزة', r.patientNo); toast('تم إرسال النتيجة إلى الطبيب'); S.labReq = null; go('lb_done'); }
  else toast('تم حفظ المسودة');
}

/* ---------- كتالوج الفحوصات ---------- */
PAGES.lb_cat = {
  title: 'كتالوج الفحوصات', live: true,
  render() {
    const T = [...D.labTests].sort((a, b) => a.name.localeCompare(b.name));
    $('page').innerHTML = pagehead('كتالوج الفحوصات', '<button class="btn accent" onclick="testForm()">' + ic('plus', 'sm') + 'فحص جديد</button>') +
      '<div class="tbl-wrap"><table class="tbl"><tr><th>الفحص</th><th>الوحدة</th><th>السعر</th><th>رمز الجهاز</th><th>نطاقات</th><th></th></tr>' +
      (T.map(t => '<tr><td><b>' + esc(t.name) + '</b></td><td>' + esc(t.unit) + '</td><td class="num">' + num(t.price) + '</td><td><span class="ltr num">' + esc(t.deviceCode) + '</span></td><td class="num">' + (t.ranges || []).length + '</td><td style="text-align:end;white-space:nowrap"><button class="btn ghost sm icon" onclick="testForm(' + t.id + ')" aria-label="تعديل">' + ic('edit', 'sm') + '</button> <button class="btn ghost sm icon" onclick="delTest(' + t.id + ')" aria-label="حذف">' + ic('trash', 'sm') + '</button></td></tr>').join('') || '<tr><td colspan="6">' + empty('flask', 'لا توجد فحوصات') + '</td></tr>') + '</table></div>';
  }
};
function testForm(id) {
  const t = id ? get('labTests', id) : { ranges: [] };
  openModal(mhead(id ? 'تعديل فحص' : 'فحص جديد') +
    '<div class="grid g2"><div class="field"><label>اسم الفحص *</label><input id="t_name" value="' + esc(t.name) + '"></div><div class="field"><label>الوحدة</label><input id="t_unit" class="ltr" style="direction:ltr;text-align:left" value="' + esc(t.unit) + '"></div>' +
    '<div class="field"><label>السعر</label><input id="t_price" type="number" min="0" value="' + esc(t.price) + '"></div><div class="field"><label>رمز الجهاز (للربط الآلي)</label><input id="t_code" class="ltr" style="direction:ltr;text-align:left" value="' + esc(t.deviceCode) + '" placeholder="GLU"></div></div>' +
    '<div class="lbl">المعدلات الطبيعية حسب العمر والجنس</div><div id="rg"></div><button class="btn ghost sm" onclick="addRange()">' + ic('plus', 'sm') + 'إضافة نطاق</button>' +
    '<div class="btns" style="margin-top:1.2rem"><button class="btn" onclick="saveTest(' + (id || 0) + ')">حفظ</button><button class="btn ghost" onclick="closeModal()">إلغاء</button></div>', true);
  (t.ranges || []).forEach(r => addRange(r));
}
function addRange(r) {
  r = (r && r.gender) ? r : { gender: 'any', ageMin: 0, ageMax: 120, low: '', high: '' };
  const d = document.createElement('div'); d.className = 'rrow';
  d.innerHTML = '<select class="input rg_g"><option value="any"' + (r.gender === 'any' ? ' selected' : '') + '>الكل</option><option value="male"' + (r.gender === 'male' ? ' selected' : '') + '>ذكر</option><option value="female"' + (r.gender === 'female' ? ' selected' : '') + '>أنثى</option></select>' +
    '<input class="input rg_a num" type="number" placeholder="من عمر" value="' + esc(r.ageMin) + '"><input class="input rg_b num" type="number" placeholder="إلى عمر" value="' + esc(r.ageMax) + '"><input class="input rg_l num" type="number" step="any" placeholder="الأدنى" value="' + esc(r.low) + '"><input class="input rg_h num" type="number" step="any" placeholder="الأعلى" value="' + esc(r.high) + '"><button class="btn ghost icon sm" onclick="this.parentNode.remove()" aria-label="حذف">' + ic('x', 'sm') + '</button>';
  $('rg').appendChild(d);
}
async function saveTest(id) {
  const name = $('t_name').value.trim(); if (!name) return toast('اسم الفحص مطلوب', 'err');
  const nv = v => v === '' ? null : +v;
  const ranges = [...document.querySelectorAll('#rg .rrow')].map(d => ({ gender: d.querySelector('.rg_g').value, ageMin: +d.querySelector('.rg_a').value || 0, ageMax: d.querySelector('.rg_b').value === '' ? 120 : +d.querySelector('.rg_b').value, low: nv(d.querySelector('.rg_l').value), high: nv(d.querySelector('.rg_h').value) })).filter(r => r.low !== null || r.high !== null);
  const t = { name, unit: $('t_unit').value.trim(), price: +$('t_price').value || 0, deviceCode: $('t_code').value.trim(), ranges }; if (id) t.id = id;
  if (!await safe(() => put('labTests', t))) return; closeModal(); toast('تم الحفظ'); renderPage();
}
async function delTest(id) {
  if (!await ask('حذف الفحص من الكتالوج؟ (الطلبات السابقة لا تتأثر)', { danger: true, ok: 'حذف' })) return;
  await safe(() => del('labTests', id)); renderPage();
}

/* ---------- ربط الجهاز (وسيط ASTM / HL7 / نص) ---------- */
const DEV = { conn: null, buf: '', timer: null, log: [] };
PAGES.lb_dev = {
  title: 'ربط جهاز المعمل', live: false,
  render() {
    $('page').innerHTML =
      (!window.isSecureContext ? '<div class="alertbox">' + ic('alert') + '<div>ربط الجهاز عبر USB أو Bluetooth يعمل فقط عند فتح النظام من الحاسوب الرئيسي بالعنوان <span class="ltr">http://localhost:3000</span> (متصفح Chrome أو Edge). الفتح عبر عنوان الشبكة يمنع المتصفح من الوصول إلى الأجهزة.</div></div>' : '') +
      '<div class="grid g2" style="align-items:start"><div class="card"><div class="card-h"><h3>' + ic('plug') + 'اتصال الجهاز</h3></div>' +
      '<p class="mut" style="margin-bottom:1rem">يستمع النظام للبيانات الواردة بصيغ ASTM وHL7 والنص العادي ويملأ النتائج تلقائياً حسب الباركود أو رقم المريض. عند عدم وجود جهاز يبقى الإدخال اليدوي متاحاً.</p>' +
      '<div class="field"><label>نوع الاتصال</label><select id="dtype" onchange="devOpts()"><option value="serial">Serial (USB / RS-232)</option><option value="bluetooth">Bluetooth (BLE)</option><option value="wifi">WiFi (TCP/IP عبر جسر WebSocket)</option></select></div><div id="dopts"></div>' +
      '<div class="btns"><button class="btn" onclick="devConnect()"' + (DEV.conn ? ' disabled' : '') + '>' + ic('link', 'sm') + 'اتصال / اقتران</button><button class="btn danger" onclick="devDisc()"' + (DEV.conn ? '' : ' disabled') + '>قطع الاتصال</button></div>' +
      '<p style="margin-top:.9rem">الحالة: ' + (DEV.conn ? '<span class="okx">● متصل (' + DEV.conn.type + ')</span>' : '<span class="mut">○ غير متصل</span>') + '</p>' +
      '<div class="lbl" style="margin-top:1rem">سجل الجهاز</div><div id="devlog">' + DEV.log.map(esc).join('<br>') + '</div></div>' +
      '<div class="card"><div class="card-h"><h3>' + ic('flask') + 'اختبار المعالج</h3></div><div class="field"><textarea id="dsim" class="input" style="direction:ltr;text-align:left;min-height:130px" placeholder="12-20261104,GLU,95&#10;أو بيانات ASTM / HL7"></textarea></div>' +
      '<div class="btns"><button class="btn ghost" onclick="ingest($(\'dsim\').value)">معالجة البيانات</button></div>' +
      '<p class="mut" style="margin-top:.8rem">الصيغ النصية: <code>ID,CODE,VALUE</code> في كل سطر، أو <code>ID=12-20261104</code> يليه <code>GLU=95</code>. تُطابق الفحوصات عبر «رمز الجهاز» في الكتالوج.</p></div></div>';
    devOpts();
  }
};
function devLog(m) { DEV.log.unshift(hm(nowTs()) + ' — ' + m); DEV.log = DEV.log.slice(0, 80); const e = $('devlog'); if (e) e.innerHTML = DEV.log.map(esc).join('<br>'); }
function devOpts() {
  const t = $('dtype'); if (!t) return;
  $('dopts').innerHTML = t.value === 'serial' ? '<div class="field"><label>Baud Rate</label><input id="dbaud" type="number" value="9600"></div>' : t.value === 'bluetooth' ? '<div class="field"><label>Service UUID (اختياري)</label><input id="dsvc" class="ltr" style="direction:ltr;text-align:left" placeholder="ffe0"></div>' : '<div class="field"><label>عنوان الجسر WebSocket</label><input id="dws" class="ltr" style="direction:ltr;text-align:left" value="ws://192.168.1.50:8080"></div>';
}
function devFeed(c) { DEV.buf += c; clearTimeout(DEV.timer); DEV.timer = setTimeout(() => { const t = DEV.buf; DEV.buf = ''; devLog('بيانات واردة (' + t.length + ' حرف)'); ingest(t); }, 700); }
async function devConnect() {
  const type = $('dtype').value;
  try {
    if (type === 'serial') {
      if (!navigator.serial) throw new Error('المتصفح لا يدعم Web Serial (استخدم Chrome أو Edge)');
      const port = await navigator.serial.requestPort(); await port.open({ baudRate: +$('dbaud').value || 9600 }); const reader = port.readable.getReader();
      DEV.conn = { type, close: async () => { try { await reader.cancel(); } catch (e) { } try { await port.close(); } catch (e) { } } };
      (async () => { const dec = new TextDecoder(); try { for (; ;) { const { value, done } = await reader.read(); if (done) break; devFeed(dec.decode(value, { stream: true })); } } catch (e) { devLog('انقطع الاتصال: ' + e.message); } })();
    } else if (type === 'bluetooth') {
      if (!navigator.bluetooth) throw new Error('المتصفح لا يدعم Web Bluetooth');
      const su = ($('dsvc').value || '').trim().toLowerCase();
      const svcs = su ? [su.length <= 4 ? parseInt(su, 16) : su] : ['0000ffe0-0000-1000-8000-00805f9b34fb', '0000fff0-0000-1000-8000-00805f9b34fb', '6e400001-b5a8-f393-e0a9-e50e24dcca9e'];
      const dev = await navigator.bluetooth.requestDevice({ acceptAllDevices: true, optionalServices: svcs }); const srv = await dev.gatt.connect(); const dec = new TextDecoder(); let n = 0;
      for (const s of await srv.getPrimaryServices()) for (const c of await s.getCharacteristics()) if (c.properties.notify || c.properties.indicate) { await c.startNotifications(); c.addEventListener('characteristicvaluechanged', e => devFeed(dec.decode(e.target.value))); n++; }
      if (!n) throw new Error('لم يُعثر على قناة بيانات في الجهاز'); DEV.conn = { type, close: async () => dev.gatt.disconnect() };
    } else {
      const ws = new WebSocket($('dws').value.trim());
      await new Promise((res, rej) => { ws.onopen = res; ws.onerror = () => rej(new Error('تعذر الاتصال بالجسر')); });
      ws.onmessage = async e => devFeed(typeof e.data === 'string' ? e.data : await e.data.text()); ws.onclose = () => { devLog('أُغلق الاتصال'); DEV.conn = null; };
      DEV.conn = { type, close: async () => ws.close() };
    }
    devLog('تم الاتصال'); toast('تم الاتصال بالجهاز'); renderPage();
  } catch (e) { devLog('خطأ: ' + e.message); toast(e.message, 'err'); }
}
async function devDisc() { if (DEV.conn) { await DEV.conn.close(); DEV.conn = null; devLog('تم قطع الاتصال'); renderPage(); } }

function parseIncoming(raw) {
  const t = raw.replace(/[\x0b\x1c]/g, '\n'); const lines = t.split(/[\r\n\x02\x03\x04\x05\x06\x15\x17]+/).map(s => s.trim()).filter(Boolean); const out = [];
  if (/MSH\|/.test(t)) {
    let pid = '', obr = ''; const res = [];
    for (const l of lines) {
      const f = l.split('|');
      if (f[0] === 'PID') pid = (f[3] || '').split('^')[0];
      else if (f[0] === 'OBR') obr = (f[3] || f[2] || '').split('^')[0];
      else if (f[0] === 'OBX') { const c = (f[3] || '').split('^'); res.push({ code: c[0] || c[1] || '', value: (f[5] || '').trim() }); }
    }
    out.push({ id: obr || pid, results: res });
  } else if (lines.some(l => /^\d?[HPORCQL]\|/.test(l))) {
    let cur = null, pid = '';
    for (const l of lines) {
      const m = l.match(/^\d?([HPORCQL])\|(.*)$/); if (!m) continue; const f = m[2].split('|');
      if (m[1] === 'P') pid = (f[2] || f[1] || '').split('^')[0];
      else if (m[1] === 'O') { cur = { id: (f[1] || '').split('^')[0] || pid, results: [] }; out.push(cur); }
      else if (m[1] === 'R' && cur) { const c = (f[1] || '').split('^').filter(Boolean); cur.results.push({ code: c[c.length - 1] || '', value: (f[2] || '').trim() }); }
    }
  } else {
    let cur = null;
    for (const l of lines) {
      let m;
      if ((m = l.match(/^(?:id|barcode|patient)\s*[:=]\s*(.+)$/i))) { cur = { id: m[1].trim(), results: [] }; out.push(cur); continue; }
      const p = l.split(/[,;|\t]/).map(s => s.trim());
      if (p.length >= 3) { let e = out.find(o => o.id === p[0]); if (!e) { e = { id: p[0], results: [] }; out.push(e); } e.results.push({ code: p[1], value: p[2] }); }
      else if (cur && (m = l.match(/^([^=:]+)[=:]\s*(.+)$/))) cur.results.push({ code: m[1].trim(), value: m[2].trim() });
    }
  }
  return out.filter(e => e.results.length);
}
async function ingest(text) {
  const E = parseIncoming(text || ''); if (!E.length) { devLog('تعذّر التعرف على البيانات'); return toast('تعذّر التعرف على البيانات', 'err'); }
  const reqs = D.labRequests.filter(r => r.status === 'waiting'); let filled = 0;
  for (const e of E) {
    const id = String(e.id || '').trim();
    const r = reqs.find(x => x.barcode === id) || (/^\d+$/.test(id) ? reqs.filter(x => x.patientNo === +id).sort((a, b) => b.ts - a.ts)[0] : null) || reqs.filter(x => id.startsWith(x.patientNo + '-')).sort((a, b) => b.ts - a.ts)[0];
    if (!r) { devLog('لا يوجد طلب مطابق للمعرّف: ' + id); continue; }
    const results = Object.assign({}, r.results);
    for (const x of e.results) {
      const c = x.code.toLowerCase();
      const t = r.tests.find(t => (t.deviceCode && t.deviceCode.toLowerCase() === c) || t.name.toLowerCase() === c || t.name.toLowerCase().includes('(' + c + ')'));
      if (t) { results[t.testId] = Object.assign({}, results[t.testId] || {}, { value: x.value, source: 'device', ts: nowTs() }); filled++; } else devLog('فحص غير معروف: ' + x.code);
    }
    const saved = await safe(() => put('labRequests', { id: r.id, results })); if (!saved) continue;
    devLog('مريض ' + r.patientNo + ' (' + r.patientName + '): تعبئة تلقائية');
    if (S.labReq === r.id && $('rv0')) saved.tests.forEach((t, i) => { const x = saved.results[t.testId]; const inp = $('rv' + i); if (x && inp && x.source === 'device') { inp.value = x.value; liveFlag(i); } });
  }
  if (filled) toast('تمت تعبئة ' + filled + ' نتيجة تلقائياً');
}
