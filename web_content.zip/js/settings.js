// ===== settings.js: look sensitivity, presets, gyroscope =====
const SET_DEF = { preset: 'norm', tx: 100, ty: 100, ads: 55, mouse: 100, gs: 100, gyro: false, gx: false, gy: false, cine: true };
const PRESETS = { low: 60, norm: 100, high: 150, ultra: 210 };
const SET = Object.assign({}, SET_DEF);
try { Object.assign(SET, JSON.parse(localStorage.getItem('celikCephe.set') || '{}')); } catch (e) { }
function saveSet() { try { localStorage.setItem('celikCephe.set', JSON.stringify(SET)); } catch (e) { } }
const gyroInfo = { seen: false, ok: false, asked: false };
function setUI() {
  const f = (id, k, div) => { $(id).value = SET[k]; $(id + 'v').textContent = (SET[k] / (div || 100)).toFixed(2) + 'x'; };
  f('sTx', 'tx'); f('sTy', 'ty'); f('sAds', 'ads'); f('sMouse', 'mouse'); f('sGs', 'gs');
  $('sGyro').checked = SET.gyro; $('sGx').checked = SET.gx; $('sGy').checked = SET.gy; $('sCine').checked = SET.cine;
  for (const b of $('setPresets').children) b.classList.toggle('on', b.dataset.p === SET.preset);
  let st = '';
  if (!('DeviceMotionEvent' in window)) st = 'Bu cihazda jiroskop desteği yok.';
  else if (SET.gyro) st = gyroInfo.ok ? 'Jiroskop çalışıyor: telefonu çevirerek nişan al.' : (gyroInfo.seen ? 'Jiroskop verisi gelmiyor (sensör yok/izin verilmedi).' : 'Jiroskop bekleniyor… telefonu hafifçe oynat.');
  else st = 'Jiroskop kapalı. Telefonlarda açabilirsin.';
  $('gyroStat').textContent = st;
}
function applyPreset(k) {
  SET.preset = k; if (PRESETS[k]) { const v = PRESETS[k]; SET.tx = v; SET.ty = v; SET.mouse = v; SET.gs = v; } saveSet(); setUI();
}
function customize(k, v) { SET[k] = v; SET.preset = 'custom'; saveSet(); setUI(); }
for (const b of $('setPresets').children) b.onclick = () => applyPreset(b.dataset.p);
for (const [id, k] of [['sTx', 'tx'], ['sTy', 'ty'], ['sAds', 'ads'], ['sMouse', 'mouse'], ['sGs', 'gs']]) $(id).oninput = () => customize(k, +$(id).value);
$('sGx').onchange = () => customize('gx', $('sGx').checked); $('sGy').onchange = () => customize('gy', $('sGy').checked);
$('sCine').onchange = () => { SET.cine = $('sCine').checked; saveSet(); setUI(); };
$('sGyro').onchange = async () => {
  const on = $('sGyro').checked;
  if (on && typeof DeviceMotionEvent !== 'undefined' && typeof DeviceMotionEvent.requestPermission === 'function') { try { const r = await DeviceMotionEvent.requestPermission(); if (r !== 'granted') { $('sGyro').checked = false; SET.gyro = false; saveSet(); setUI(); return; } } catch (e) { } }
  SET.gyro = on; saveSet(); setUI();
};
$('setOk').onclick = () => { $('settings').hidden = true; };
function openSettings() { setUI(); $('settings').hidden = false; }
$('btnSettings').onclick = openSettings; $('btnSettingsMenu').onclick = openSettings; $('editSettings').onclick = openSettings;
// gyroscope -> same look accumulators as touch/mouse
function lookScale(base) { return base * lerp(1, SET.ads / 100, P.ads || 0); }
window.addEventListener('devicemotion', e => {
  const r = e.rotationRate; if (!r || (r.alpha === null && r.beta === null && r.gamma === null)) { gyroInfo.seen = true; return; }
  gyroInfo.seen = true; if (!gyroInfo.ok) { gyroInfo.ok = true; if (!$('settings').hidden) setUI(); }
  if (!SET.gyro || G.state !== 'playing' || !isTouch) return;
  const dt = Math.min(.05, (e.interval || 16) / (e.interval > 1 ? 1000 : 1)), k = Math.PI / 180 * dt * SET.gs / 100;
  const ang = (screen.orientation && screen.orientation.angle !== undefined) ? screen.orientation.angle : (window.orientation || 90), sg = (ang === 270 || ang === -90) ? -1 : 1;
  let yx = -(r.beta || 0) * sg, yy = (r.gamma || 0) * sg; if (SET.gx) yx = -yx; if (SET.gy) yy = -yy;
  lookDX += yx * k * lerp(1, SET.ads / 100, P.ads || 0) * -1; lookDY += yy * k * lerp(1, SET.ads / 100, P.ads || 0);
});
