/**
 * Snake Escape — Settings & Localization (English & Hindi)
 */
(function() {
  'use strict';

  const TRANSLATIONS = {
    en: {
      gameTitle: "SNAKE ESCAPE",
      tagline: "Think • Tap • Escape",
      play: "Play",
      levelSelect: "Level Select",
      howToPlay: "How to Play",
      settings: "Settings",
      selectLevel: "Select Level",
      easy: "Easy",
      normal: "Normal",
      hard: "Hard",
      expert: "Expert",
      snakesLeft: "Snakes Left: ",
      hint: "Hint",
      reset: "Reset",
      undo: "Undo",
      paused: "Paused",
      resume: "Resume",
      restart: "Restart",
      home: "Home",
      levelComplete: "Level Complete!",
      nextLevel: "Next Level",
      retry: "Retry",
      levelFailed: "Level Failed",
      blockedMessage: "The snake got blocked! Try again and find a better path.",
      boardCleared: "Board Cleared!",
      allEscaped: "All snakes escaped!",
      sound: "Sound",
      music: "Music",
      vibration: "Vibration",
      darkMode: "Dark Mode",
      language: "Language",
      privacyPolicy: "Privacy Policy",
      aboutUs: "About Us",
      resetProgress: "Reset Progress",
      resetConfirmTitle: "Reset All Progress?",
      resetConfirmDesc: "This will clear all unlocked levels, stars, and records. Are you sure?",
      confirmYes: "Yes, Reset",
      confirmCancel: "Cancel",
      hintTitle: "Hint",
      hintDesc: "This snake can escape. Follow the illuminated path!",
      hintNoMore: "No hints remaining for this level!",
      gotIt: "Got It",
      step1: "Tap adjacent cell, swipe, or use WASD/Arrows to move the snake.",
      step2: "Guide each snake carefully to its matching glowing exit.",
      step3: "Avoid hitting stone walls, maze borders, and other snakes.",
      step4: "Multi-snake levels require coordinating which snake leaves first!"
    },
    hi: {
      gameTitle: "स्नेक एस्केप",
      tagline: "सोचें • टैप करें • बच निकलें",
      play: "खेलें",
      levelSelect: "स्तर चुनें",
      howToPlay: "कैसे खेलें",
      settings: "सेटिंग्स",
      selectLevel: "स्तर चुनें",
      easy: "आसान",
      normal: "सामान्य",
      hard: "कठिन",
      expert: "विशेषज्ञ",
      snakesLeft: "शेष सांप: ",
      hint: "संकेत",
      reset: "रीसेट",
      undo: "पूर्ववत",
      paused: "रोक दिया गया",
      resume: "जारी रखें",
      restart: "पुनः प्रारंभ",
      home: "होम",
      levelComplete: "स्तर पूरा हुआ!",
      nextLevel: "अगला स्तर",
      retry: "पुनः प्रयास",
      levelFailed: "स्तर विफल",
      blockedMessage: "सांप फंस गया है! पुनः प्रयास करें और एक बेहतर रास्ता खोजें।",
      boardCleared: "बोर्ड साफ़ हो गया!",
      allEscaped: "सभी सांप बच निकले!",
      sound: "ध्वनि",
      music: "संगीत",
      vibration: "कंपन",
      darkMode: "डार्क मोड",
      language: "भाषा",
      privacyPolicy: "गोपनीयता नीति",
      aboutUs: "हमारे बारे में",
      resetProgress: "प्रगति रीसेट करें",
      resetConfirmTitle: "सारी प्रगति रीसेट करें?",
      resetConfirmDesc: "यह सभी खुले स्तरों और सितारों को मिटा देगा। क्या आप सुनिश्चित हैं?",
      confirmYes: "हाँ, रीसेट करें",
      confirmCancel: "रद्द करें",
      hintTitle: "संकेत",
      hintDesc: "यह सांप बच सकता है। रोशनी वाले रास्ते का अनुसरण करें!",
      hintNoMore: "इस स्तर के लिए कोई और संकेत नहीं बचा!",
      gotIt: "समझ गया",
      step1: "सांप को हिलाने के लिए स्क्रीन पर स्वाइप या टैप करें।",
      step2: "प्रत्येक सांप को उसके मेल खाने वाले निकास द्वार तक ले जाएं।",
      step3: "पत्थर की दीवारों और अन्य सांपों से टकराने से बचें।",
      step4: "बहु-सांप स्तरों में सही क्रम में सांपों को बाहर निकालना आवश्यक है!"
    }
  };

  class SettingsController {
    constructor(storage, audio) {
      this.storage = storage;
      this.audio = audio;
      this.lang = this.storage.getSetting('language') || 'en';
    }

    init() {
      // Sync sound and music states
      const soundOn = this.storage.getSetting('soundEnabled');
      const musicOn = this.storage.getSetting('musicEnabled');
      const darkOn = this.storage.getSetting('darkMode');

      this.audio.setSoundEnabled(soundOn);
      this.audio.setMusicEnabled(musicOn);
      this.applyTheme(darkOn);
      this.applyLanguage(this.lang);
    }

    setSound(enabled) {
      this.storage.setSetting('soundEnabled', enabled);
      this.audio.setSoundEnabled(enabled);
    }

    setMusic(enabled) {
      this.storage.setSetting('musicEnabled', enabled);
      this.audio.setMusicEnabled(enabled);
    }

    setVibration(enabled) {
      this.storage.setSetting('vibrationEnabled', enabled);
    }

    setDarkMode(enabled) {
      this.storage.setSetting('darkMode', enabled);
      this.applyTheme(enabled);
    }

    applyTheme(isDark) {
      if (isDark) {
        document.documentElement.setAttribute('data-theme', 'dark');
      } else {
        document.documentElement.removeAttribute('data-theme');
      }
    }

    toggleLanguage() {
      this.lang = this.lang === 'en' ? 'hi' : 'en';
      this.storage.setSetting('language', this.lang);
      this.applyLanguage(this.lang);
      return this.lang;
    }

    t(key) {
      const dict = TRANSLATIONS[this.lang] || TRANSLATIONS.en;
      return dict[key] || TRANSLATIONS.en[key] || key;
    }

    applyLanguage(lang) {
      this.lang = lang;
      const dict = TRANSLATIONS[lang] || TRANSLATIONS.en;

      // Update all elements with data-i18n attribute
      document.querySelectorAll('[data-i18n]').forEach(el => {
        const k = el.getAttribute('data-i18n');
        if (dict[k]) {
          el.textContent = dict[k];
        }
      });

      const langLabel = document.getElementById('setting-lang-val');
      if (langLabel) {
        langLabel.textContent = lang === 'hi' ? 'हिंदी' : 'English';
      }
    }
  }

  window.SnakeEscape = window.SnakeEscape || {};
  window.SnakeEscape.settings = new SettingsController(window.SnakeEscape.storage, window.SnakeEscape.audio);
  window.SnakeEscape.TRANSLATIONS = TRANSLATIONS;
})();
