// =====================================================
// NetEarn Pro
// SETTINGS PAGE
// FINAL CLEAN VERSION
// =====================================================
//
// Features:
// ✅ Firebase Authentication
// ✅ Current User Detection
// ✅ Profile Data Load
// ✅ NetEarn ID
// ✅ Profile Photo
// ✅ Logout
// 🔐 Change Password
// 📧 Change Email
// 🎨 Appearance Coming Soon
// 🌐 Language Coming Soon
// =====================================================


import {
    auth,
    db
}
from "./firebase.js";


import {
    onAuthStateChanged,
    signOut,
    updatePassword,
    updateEmail,
    reauthenticateWithCredential,
    EmailAuthProvider
}
from
"https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";


import {
    doc,
    getDoc
}
from
"https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";


// =====================================================
// CONFIG
// =====================================================

const CONFIG = {

    loginPage:
        "login.html",

    profilePage:
        "profile.html"

};


// =====================================================
// APP STATE
// =====================================================

const App = {

    user: null,

    data: null,

    ready: false

};


// =====================================================
// ELEMENTS
// =====================================================

const profileImage =
    document.getElementById(
        "settingsProfileImage"
    );


const userName =
    document.getElementById(
        "settingsUserName"
    );


const userId =
    document.getElementById(
        "settingsUserId"
    );


const changePasswordBtn =
    document.getElementById(
        "changePasswordBtn"
    );


const changeEmailBtn =
    document.getElementById(
        "changeEmailBtn"
    );


const appearanceBtn =
    document.getElementById(
        "appearanceBtn"
    );


const languageBtn =
    document.getElementById(
        "languageBtn"
    );


const logoutBtn =
    document.getElementById(
        "settingsLogoutBtn"
    );


// =====================================================
// LOAD USER DATA
// =====================================================

async function loadUserData(uid) {

    try {

        const userRef =
            doc(
                db,
                "users",
                uid
            );


        const snap =
            await getDoc(
                userRef
            );


        if (!snap.exists()) {

            console.error(
                "❌ User document not found."
            );

            return null;

        }


        return snap.data();

    }

    catch (error) {

        console.error(
            "❌ Firestore User Load Error:",
            error
        );

        return null;

    }

}


// =====================================================
// LOAD PROFILE
// =====================================================

// Prevent the default avatar from flashing while the
// user-specific profile photo is being resolved.
function setSettingsProfilePhotoNoFlash(src) {

    if (!profileImage) {
        return;
    }

    const target =
        src ||
        "images/default-user.png";

    // Keep the default avatar visible immediately.
    // Only swap to a user photo after it loads successfully.
    if (target === "images/default-user.png") {
        profileImage.src = target;
        return;
    }

    const preload = new Image();

    preload.onload = () => {
        profileImage.src = target;
    };

    preload.onerror = () => {
        // Keep the already-visible default avatar.
        profileImage.src = "images/default-user.png";
    };

    preload.src = target;
}

function renderProfile() {

    const data =
        App.data;


    const user =
        App.user;


    if (!data || !user) {

        return;

    }


    // =================================================
    // USERNAME
    // =================================================

    if (userName) {

        userName.textContent =
            data.username ||
            data.name ||
            user.displayName ||
            "User";

    }


    // =================================================
    // NETEARN ID
    // =================================================

    if (userId) {

        /*
         * IMPORTANT:
         *
         * Firebase UID is NEVER used
         * as NetEarn ID.
         */

        userId.textContent =
            data.userId ||
            "NE00000";

    }


    // =================================================
    // PROFILE PHOTO
    // =================================================

    if (profileImage) {

        const localPhoto =
            localStorage.getItem(
                `profilePhoto_${user.uid}`
            );


        // Use the exact same photo source as Profile.
        // Do not fall back to Firestore photoURL/photo,
        // which can display a different legacy avatar.
        setSettingsProfilePhotoNoFlash(
            localPhoto ||
            "images/default-user.png"
        );

    }

}


// =====================================================
// COMING SOON TOAST
// =====================================================

function showComingSoonToast(
    title
) {

    const oldToast =
        document.getElementById(
            "settingsComingSoonToast"
        );


    if (oldToast) {

        oldToast.remove();

    }


    const toast =
        document.createElement(
            "div"
        );


    toast.id =
        "settingsComingSoonToast";


    toast.innerHTML = `

        <div
            style="
                width:38px;
                height:38px;
                display:flex;
                align-items:center;
                justify-content:center;
                border-radius:12px;
                background:rgba(255,255,255,.12);
                font-size:19px;
            "
        >
            ✨
        </div>

        <div
            style="
                display:flex;
                flex-direction:column;
                gap:2px;
            "
        >

            <strong
                style="
                    font-size:14px;
                    color:#fff;
                "
            >
                ${escapeHTML(title)}
            </strong>

            <span
                style="
                    font-size:12px;
                    color:rgba(255,255,255,.72);
                "
            >
                Coming Soon
            </span>

        </div>

    `;


    Object.assign(
        toast.style,
        {

            position:
                "fixed",

            left:
                "50%",

            bottom:
                "95px",

            transform:
                "translateX(-50%) translateY(15px)",

            display:
                "flex",

            alignItems:
                "center",

            gap:
                "10px",

            minWidth:
                "220px",

            maxWidth:
                "calc(100vw - 30px)",

            padding:
                "12px 15px",

            background:
                "rgba(20,28,45,.97)",

            color:
                "#fff",

            borderRadius:
                "16px",

            boxShadow:
                "0 12px 35px rgba(0,0,0,.25)",

            zIndex:
                "99999",

            opacity:
                "0",

            transition:
                "opacity .22s ease, transform .22s ease",

            fontFamily:
                "inherit",

            pointerEvents:
                "none"

        }
    );


    document.body.appendChild(
        toast
    );


    requestAnimationFrame(
        () => {

            toast.style.opacity =
                "1";

            toast.style.transform =
                "translateX(-50%) translateY(0)";

        }
    );


    setTimeout(
        () => {

            toast.style.opacity =
                "0";

            toast.style.transform =
                "translateX(-50%) translateY(15px)";


            setTimeout(
                () => {

                    toast.remove();

                },
                230
            );

        },
        2000
    );

}


// =====================================================
// CHANGE PASSWORD
// =====================================================

changePasswordBtn?.addEventListener(
    "click",
    async () => {

        const user =
            auth.currentUser;


        if (!user) {

            location.replace(
                CONFIG.loginPage
            );

            return;

        }


        if (!user.email) {

            await alert(
                "❌ এই Account-এর সাথে কোনো Email পাওয়া যায়নি।"
            );

            return;

        }


        const currentPassword =
            await NetEarnDialog.prompt(
                "Current Password"
            );


        if (currentPassword === null) {

            return;

        }


        if (!currentPassword.trim()) {

            await alert(
                "⚠️ Current Password দিতে হবে।"
            );

            return;

        }


        const newPassword =
            await NetEarnDialog.prompt(
                "🔑 নতুন Password লিখুন:"
            );


        if (newPassword === null) {

            return;

        }


        if (
            newPassword.length < 6
        ) {

            await alert(
                "⚠️ Password কমপক্ষে 6 characters হতে হবে।"
            );

            return;

        }


        try {

            changePasswordBtn.disabled =
                true;


            const credential =
                EmailAuthProvider.credential(
                    user.email,
                    currentPassword
                );


            // =========================================
            // RE-AUTHENTICATION
            // =========================================

            await reauthenticateWithCredential(
                user,
                credential
            );


            // =========================================
            // UPDATE PASSWORD
            // =========================================

            await updatePassword(
                user,
                newPassword
            );


            await alert(
                "✅ Password সফলভাবে পরিবর্তন হয়েছে।"
            );

        }

        catch (error) {

            console.error(
                "❌ Password Change Error:",
                error
            );


            if (
                error.code ===
                "auth/wrong-password" ||
                error.code ===
                "auth/invalid-credential"
            ) {

                await alert(
                    "❌ বর্তমান Password সঠিক নয়।"
                );

            }

            else if (
                error.code ===
                "auth/too-many-requests"
            ) {

                await alert(
                    "⚠️ অনেকবার চেষ্টা করা হয়েছে। কিছুক্ষণ পরে আবার চেষ্টা করুন।"
                );

            }

            else {

                await alert(
                    "❌ Password পরিবর্তন করা যায়নি।\n\n" +
                    "দয়া করে আবার চেষ্টা করুন।"
                );

            }

        }

        finally {

            changePasswordBtn.disabled =
                false;

        }

    }
);


// =====================================================
// CHANGE EMAIL
// =====================================================

changeEmailBtn?.addEventListener(
    "click",
    async () => {

        const user =
            auth.currentUser;


        if (!user) {

            location.replace(
                CONFIG.loginPage
            );

            return;

        }


        if (!user.email) {

            await alert(
                "❌ Current Email পাওয়া যায়নি।"
            );

            return;

        }


        const currentPassword =
            await NetEarnDialog.prompt(
                "Current Password"
            );


        if (currentPassword === null) {

            return;

        }


        if (!currentPassword.trim()) {

            await alert(
                "⚠️ Current Password দিতে হবে।"
            );

            return;

        }


        const newEmail =
            await NetEarnDialog.prompt(
                "📧 নতুন Email Address লিখুন:"
            );


        if (newEmail === null) {

            return;

        }


        const email =
            newEmail.trim();


        if (!email) {

            await alert(
                "⚠️ নতুন Email দিতে হবে।"
            );

            return;

        }


        // Basic email validation

        const emailPattern =
            /^[^\s@]+@[^\s@]+\.[^\s@]+$/;


        if (
            !emailPattern.test(email)
        ) {

            await alert(
                "❌ সঠিক Email Address দিন।"
            );

            return;

        }


        if (
            email.toLowerCase() ===
            user.email.toLowerCase()
        ) {

            await alert(
                "⚠️ এটি আপনার বর্তমান Email।"
            );

            return;

        }


        try {

            changeEmailBtn.disabled =
                true;


            // =========================================
            // RE-AUTHENTICATION
            // =========================================

            const credential =
                EmailAuthProvider.credential(
                    user.email,
                    currentPassword
                );


            await reauthenticateWithCredential(
                user,
                credential
            );


            // =========================================
            // UPDATE EMAIL
            // =========================================

            await updateEmail(
                user,
                email
            );


            await alert(
                "✅ Email সফলভাবে পরিবর্তন হয়েছে।"
            );

        }

        catch (error) {

            console.error(
                "❌ Email Change Error:",
                error
            );


            if (
                error.code ===
                "auth/wrong-password" ||
                error.code ===
                "auth/invalid-credential"
            ) {

                await alert(
                    "❌ Current Password সঠিক নয়।"
                );

            }

            else if (
                error.code ===
                "auth/email-already-in-use"
            ) {

                await alert(
                    "❌ এই Email ইতিমধ্যে অন্য একটি Account-এ ব্যবহার হচ্ছে।"
                );

            }

            else if (
                error.code ===
                "auth/invalid-email"
            ) {

                await alert(
                    "❌ Email Address সঠিক নয়।"
                );

            }

            else if (
                error.code ===
                "auth/requires-recent-login"
            ) {

                await alert(
                    "🔐 Security verification প্রয়োজন। আবার Login করে চেষ্টা করুন।"
                );

            }

            else {

                await alert(
                    "❌ Email পরিবর্তন করা যায়নি।\n\n" +
                    "দয়া করে আবার চেষ্টা করুন।"
                );

            }

        }

        finally {

            changeEmailBtn.disabled =
                false;

        }

    }
);


// =====================================================
// APPEARANCE — COMING SOON
// =====================================================

appearanceBtn?.addEventListener(
    "click",
    () => {

        showComingSoonToast(
            "🎨 Appearance"
        );

    }
);


// =====================================================
// LANGUAGE — COMING SOON
// =====================================================

languageBtn?.addEventListener(
    "click",
    () => {

        showComingSoonToast(
            "🌐 Language"
        );

    }
);


// =====================================================
// LOGOUT
// =====================================================

logoutBtn?.addEventListener(
    "click",
    async () => {

        const confirmed =
            await NetEarnDialog.confirm(
                "🚪 আপনি কি আপনার Account থেকে Logout করতে চান?"
            );


        if (!confirmed) {

            return;

        }


        try {

            logoutBtn.disabled =
                true;


            await signOut(
                auth
            );


            // =========================================
            // CLEAR USER-SPECIFIC CACHE
            // =========================================

            sessionStorage.removeItem(
                "netearnProfileCache"
            );


            sessionStorage.removeItem(
                "dashboardLoaded"
            );


            location.replace(
                CONFIG.loginPage
            );

        }

        catch (error) {

            console.error(
                "❌ Logout Error:",
                error
            );


            await alert(
                "❌ Logout করা যায়নি। আবার চেষ্টা করুন।"
            );


            logoutBtn.disabled =
                false;

        }

    }
);


// =====================================================
// AUTH
// =====================================================

let authToken =
    0;


onAuthStateChanged(
    auth,
    async user => {

        const token =
            ++authToken;


        // =============================================
        // SIGNED OUT
        // =============================================

        if (!user) {

            App.user =
                null;

            App.data =
                null;

            App.ready =
                false;


            location.replace(
                CONFIG.loginPage
            );

            return;

        }


        // =============================================
        // CURRENT USER
        // =============================================

        App.user =
            user;


        App.data =
            null;

        App.ready =
            false;


        console.log(
            "🔐 Settings User:",
            user.uid
        );


        // =============================================
        // FIRESTORE
        // =============================================

        const data =
            await loadUserData(
                user.uid
            );


        // =============================================
        // STALE REQUEST PROTECTION
        // =============================================

        if (
            token !== authToken
        ) {

            return;

        }


        if (
            !auth.currentUser ||
            auth.currentUser.uid !==
                user.uid
        ) {

            return;

        }


        // =============================================
        // USER DATA
        // =============================================

        App.data =
            data || {};


        App.ready =
            true;


        renderProfile();


        console.log(
            "✅ Settings Ready"
        );

    }
);


// =====================================================
// ESCAPE HTML
// =====================================================

function escapeHTML(
    value
) {

    return String(
        value ?? ""
    )

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}


// =====================================================
// FINAL READY
// =====================================================

console.log(
    "======================================"
);

console.log(
    "⚙️ NetEarn Pro Settings"
);

console.log(
    "🔐 Account Settings Ready"
);

console.log(
    "👤 Profile Ready"
);

console.log(
    "🔑 Password System Ready"
);

console.log(
    "📧 Email System Ready"
);

console.log(
    "🔔 Notifications Ready"
);

console.log(
    "🎨 Appearance Coming Soon"
);

console.log(
    "🌐 Language Coming Soon"
);

console.log(
    "🚪 Logout Ready"
);

console.log(
    "======================================"
);