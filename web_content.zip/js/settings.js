(function () {
  'use strict';
  const P = (window.Pith = window.Pith || {});
  const U = P.util;
  const h = U.h;
  const icon = U.icon;
  const S = P.state;
  const UI = P.ui;
  const T = P.theme;
  const G = P.gemini;
  const V = P.views;

  const labelOf = (list, id) => (list.find((m) => m.id === id) || { label: id }).label;

  function group(title, rows) {
    return h('section', { class: 'group' }, title ? h('h3', { class: 'group-title' }, title) : null, h('div', { class: 'card' }, rows.filter(Boolean)));
  }

  function item(o) {
    const el = h(o.onClick ? 'button' : 'div', { class: 'ri' + (o.danger ? ' danger' : ''), onclick: o.onClick },
      o.left || null,
      h('span', { class: 'ri-main' }, h('span', { class: 'ri-title' }, o.title), o.sub ? h('span', { class: 'ri-sub' }, o.sub) : null),
      o.right || null);
    return el;
  }

  function toggle(on, onChange) {
    const el = h('span', { class: 'switch' + (on ? ' on' : ''), role: 'switch', 'aria-checked': String(!!on) }, h('span', { class: 'knob' }));
    el.set = (v) => { el.classList.toggle('on', v); el.setAttribute('aria-checked', String(v)); };
    return el;
  }

  // ================================================================ settings
  V.openSettings = function () {
    UI.view({
      title: 'Settings',
      build(body) {
        const draw = () => {
          body.textContent = '';
          const mode = T.state.mode;
          body.append(
            h('button', { class: 'profile-card', onclick: V.openProfile },
              V.avatar(52),
              h('span', { class: 'pc-text' }, h('span', { class: 'pc-name' }, (S.profile && S.profile.name) || 'You'), h('span', { class: 'muted small' }, 'Local profile')),
              icon('chevron-right')),
            group('Appearance', [
              h('div', { class: 'seg-wrap' }, h('div', { class: 'seg', role: 'tablist' }, [['system', 'System'], ['light', 'Light'], ['dark', 'Dark']].map(([id, label]) =>
                h('button', { class: id === mode ? 'on' : '', role: 'tab', 'aria-selected': String(id === mode), onclick: () => { T.setMode(id); draw(); } }, label)))),
              item({ title: 'Themes and colors', sub: `Light: ${(T.find(T.state.lightId) || {}).name}. Dark: ${(T.find(T.state.darkId) || {}).name}.`, left: icon('droplet'), right: icon('chevron-right'), onClick: V.openThemes }),
            ]),
            group('Chat', [
              item({ title: 'Model', sub: labelOf(G.TEXT_MODELS, S.prefs.textModel), left: icon('bolt'), onClick: () => UI.choose('Chat model', G.TEXT_MODELS, S.prefs.textModel, (id) => { S.prefs.textModel = id; S.savePrefs(); draw(); }) }),
              item({ title: 'Image model', sub: labelOf(G.IMAGE_MODELS, S.prefs.imageModel), left: icon('brush'), onClick: () => UI.choose('Image model', G.IMAGE_MODELS, S.prefs.imageModel, (id) => { S.prefs.imageModel = id; S.savePrefs(); draw(); }) }),
              item({ title: 'Default instructions', sub: S.prefs.instructions || 'Applied to every chat', left: icon('sliders'), onClick: () => UI.textSheet({ title: 'Default instructions', description: 'Pith follows these in every chat. A chat can add its own on top.', value: S.prefs.instructions, placeholder: 'For example: Keep answers short.', onSave: (t) => { S.prefs.instructions = t; S.savePrefs(); draw(); } }) }),
              (() => { const sw = toggle(S.prefs.haptics); return item({ title: 'Haptic feedback', left: icon('vibrate'), right: sw, onClick: () => { S.prefs.haptics = !S.prefs.haptics; S.savePrefs(); sw.set(S.prefs.haptics); U.haptic(15); } }); })(),
            ]),
            group('Data', [
              item({ title: 'Delete all chats', sub: 'Removes every conversation and attachment from this device.', left: icon('trash'), danger: true, onClick: async () => {
                const ok = await UI.confirm({ title: 'Delete all chats?', message: 'This cannot be undone.', confirm: 'Delete all' });
                if (ok) { await P.chat.deleteAll(); U.toast('All chats deleted.'); }
              } }),
            ]),
            h('p', { class: 'muted small center about' }, 'Pith 1.0, powered by Gemini'));
        };
        draw();
        const off = S.on('profile', draw);
        body._off = off;
      },
      onClose() {},
    });
  };

  // ================================================================ profile
  async function setPhoto(file) {
    try {
      S.profile.photo = await U.squareThumb(file, 256);
      S.saveProfile();
      S.emit('profile');
    } catch (e) { U.toast('Could not read that image.'); }
  }

  V.pickAvatar = function (source) {
    const input = document.getElementById(source === 'camera' ? 'in-avatar-camera' : 'in-avatar');
    input.value = '';
    input.onchange = () => { if (input.files && input.files[0]) setPhoto(input.files[0]); };
    input.click();
  };

  V.openProfile = function () {
    UI.view({
      title: 'Profile',
      build(body) {
        const draw = () => {
          body.textContent = '';
          const avatar = h('button', { class: 'avatar-big', 'aria-label': 'Change photo', onclick: () => UI.actionSheet('Profile photo', [
            { icon: 'camera', label: 'Take a photo', onClick: () => V.pickAvatar('camera') },
            { icon: 'image', label: 'Choose from gallery', onClick: () => V.pickAvatar('gallery') },
            S.profile.photo ? { icon: 'trash', label: 'Remove photo', danger: true, onClick: () => { S.profile.photo = null; S.saveProfile(); S.emit('profile'); } } : null,
          ]) }, V.avatar(112), h('span', { class: 'avatar-edit' }, icon('edit')));
          const name = h('input', { class: 'input', type: 'text', value: S.profile.name, placeholder: 'Your name', autocomplete: 'name', maxlength: '60' });
          const save = () => { const v = name.value.trim(); if (v && v !== S.profile.name) { S.profile.name = v; S.saveProfile(); S.emit('profile'); U.toast('Name saved.'); } };
          name.addEventListener('change', save);
          name.addEventListener('keydown', (e) => { if (e.key === 'Enter') name.blur(); });
          body.append(
            h('div', { class: 'center' }, avatar),
            h('label', { class: 'field-label' }, 'Name'), name,
            group('Account', [
              item({ title: 'Local profile', sub: 'Your name and photo are stored on this device only.', left: icon('user') }),
            ]));
        };
        draw();
        const off = S.on('profile', draw);
        body._off = off;
      },
    });
  };

  // ================================================================ onboarding
  V.showOnboarding = function () {
    const overlay = h('div', { class: 'onboard' });
    let photo = null;
    const avatarBtn = h('button', { class: 'avatar-big', 'aria-label': 'Add a photo' });
    const name = h('input', { class: 'input', type: 'text', placeholder: 'Your name', autocomplete: 'name', maxlength: '60' });
    const err = h('p', { class: 'err-text' });
    const drawAvatar = () => {
      avatarBtn.textContent = '';
      const el = h('span', { class: 'avatar', style: { width: '84px', height: '84px', fontSize: '34px' } });
      if (photo) el.append(h('img', { src: photo, alt: '' })); else el.textContent = (name.value.trim().charAt(0) || '?').toUpperCase();
      avatarBtn.append(el, h('span', { class: 'avatar-edit' }, icon('camera')));
    };
    name.addEventListener('input', () => { err.textContent = ''; if (!photo) drawAvatar(); });
    avatarBtn.addEventListener('click', () => {
      const input = document.getElementById('in-avatar');
      input.value = '';
      input.onchange = async () => {
        if (!input.files || !input.files[0]) return;
        try { photo = await U.squareThumb(input.files[0], 256); drawAvatar(); } catch (e) { U.toast('Could not read that image.'); }
      };
      input.click();
    });
    const go = () => {
      const n = name.value.trim();
      if (!n) { err.textContent = 'Enter a name to continue.'; name.focus(); return; }
      S.profile = { name: n, photo, createdAt: Date.now() };
      S.saveProfile();
      overlay.classList.remove('open');
      setTimeout(() => overlay.remove(), 260);
      S.emit('profile');
      V.renderMessages({ scroll: 'bottom' });
    };
    name.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
    overlay.append(h('div', { class: 'onboard-inner' },
      V.mark(40),
      h('h1', null, 'Welcome to Pith'),
      h('p', { class: 'muted' }, 'Set up a profile. It stays on this device.'),
      h('div', { class: 'ob-row' }, avatarBtn, name),
      err,
      h('button', { class: 'btn primary wide', onclick: go }, 'Continue')));
    drawAvatar();
    document.body.append(overlay);
    requestAnimationFrame(() => overlay.classList.add('open'));
  };

  // ================================================================ themes
  V.openThemes = function () {
    UI.view({
      title: 'Themes',
      build(body) {
        const draw = () => {
          body.textContent = '';
          T.all().forEach((spec) => {
            const active = T.isActive(spec);
            const dots = [spec.bg, spec.sidebar, spec.userBubble, spec.text, spec.accent].map((c) => h('span', { class: 'sw', style: { background: c } }));
            const card = h('div', { class: 'theme-card' + (active ? ' active' : ''), role: 'button', tabindex: '0',
              onclick: () => { U.haptic(8); T.select(spec); draw(); },
              onkeydown: (e) => { if (e.key === 'Enter') card.click(); } },
              h('div', { class: 'tc-main' },
                h('div', { class: 'tc-name' }, spec.name, active ? icon('check') : null),
                h('div', { class: 'muted small' }, (spec.dark ? 'Dark' : 'Light') + (spec.builtIn ? '' : ', custom')),
                h('div', { class: 'swatches' }, dots)),
              h('button', { class: 'icon-btn', 'aria-label': 'Theme options', onclick: (e) => { e.stopPropagation(); themeMenu(spec, draw); } }, icon('more')));
            body.append(card);
          });
          body.append(h('button', { class: 'btn primary wide', onclick: () => V.openThemeEditor(T.duplicate(T.current(), 'My theme'), true) }, icon('plus'), 'New theme'));
        };
        draw();
        body._off = () => {};
        body._redraw = draw;
        const off = S.on('themes', draw);
        body._off = off;
      },
    });
  };

  function themeMenu(spec, redraw) {
    UI.actionSheet(spec.name, [
      { icon: 'edit', label: spec.builtIn ? 'Customize' : 'Edit', onClick: () => (spec.builtIn ? V.openThemeEditor(T.duplicate(spec, spec.name + ' custom'), true) : V.openThemeEditor(Object.assign({}, spec), false)) },
      { icon: 'copy', label: 'Duplicate', onClick: () => V.openThemeEditor(T.duplicate(spec), true) },
      spec.builtIn ? null : { icon: 'trash', label: 'Delete', danger: true, onClick: async () => { if (await UI.confirm({ title: `Delete "${spec.name}"?` })) { T.remove(spec); redraw(); } } },
    ]);
  }

  // ================================================================ theme editor
  V.openThemeEditor = function (initial, isNew) {
    let draft = Object.assign({}, initial);
    let dirty = false;
    let wholeApp = false;
    let ctlRef;

    UI.view({
      title: isNew ? 'New theme' : 'Edit theme',
      onBack(ctl) {
        if (!dirty) { ctl.close(); return; }
        UI.confirm({ title: 'Discard your changes?', confirm: 'Discard' }).then((ok) => { if (ok) ctl.close(); });
      },
      onClose() { if (wholeApp) T.applyCurrent(); },
      build(body, ctl) {
        ctlRef = ctl;
        const preview = h('div', { class: 'tp' },
          h('div', { class: 'tp-side' }, h('div', { class: 'tp-brand' }), h('i'), h('i'), h('i'), h('div', { class: 'tp-dot' })),
          h('div', { class: 'tp-main' },
            h('div', { class: 'tp-bg' }),
            h('div', { class: 'tp-chat' },
              h('div', { class: 'tp-user' }, 'Plan a quiet weekend'),
              h('div', { class: 'tp-reply' }, 'Start with a slow morning and a short walk. ', h('u', null, 'See the full plan')),
              h('div', { class: 'tp-code' }, 'print("hello")'),
              h('div', { class: 'tp-input' }, h('span', null, 'Message'), h('b', { class: 'tp-send' })))));
        const name = h('input', { class: 'input', type: 'text', value: draft.name, placeholder: 'Theme name', maxlength: '40' });
        name.addEventListener('input', () => { draft.name = name.value; dirty = true; });

        const refresh = () => {
          T.apply(draft, preview);
          if (wholeApp) T.apply(draft);
          rows.forEach((r) => r());
        };
        const change = (patch) => { Object.assign(draft, patch); dirty = true; refresh(); };

        const rows = [];
        const colorRow = ([key, label, alpha]) => {
          const swatch = h('span', { class: 'sw big' });
          const paint = () => { swatch.style.background = draft[key]; };
          rows.push(paint);
          paint();
          return h('button', { class: 'ri', onclick: () => {
            const picker = T.picker(draft[key], { alpha: !!alpha, onChange: (hex) => change({ [key]: hex }) });
            UI.sheet({ title: label, content: h('div', { class: 'sheet-pad' }, picker, h('div', { class: 'modal-actions' }, h('button', { class: 'btn primary', onclick: (e) => e.target.closest('.sheet-wrap').click() }, 'Done'))) });
          } }, h('span', { class: 'ri-main' }, h('span', { class: 'ri-title' }, label)), swatch);
        };

        const range = (label, min, max, step, get, set, fmt) => {
          const val = h('span', { class: 'muted' });
          const input = h('input', { type: 'range', min, max, step, value: get() });
          const paint = () => { val.textContent = fmt(get()); };
          input.addEventListener('input', () => { set(parseFloat(input.value)); paint(); });
          paint();
          return h('div', { class: 'range-row' }, h('div', { class: 'range-head' }, h('span', null, label), val), input);
        };

        const bgWrap = h('div');
        const drawBg = async () => {
          bgWrap.textContent = '';
          const has = !!draft.bgImage;
          const pick = h('button', { class: 'ri', onclick: () => {
            const input = document.getElementById('in-bg');
            input.value = '';
            input.onchange = async () => {
              if (!input.files || !input.files[0]) return;
              try {
                const blob = await U.prepareImage(input.files[0], 1600, 0.85);
                const id = await P.media.put(blob, { name: 'background' });
                change({ bgImage: id });
                drawBg();
              } catch (e) { U.toast('Could not use that image.'); }
            };
            input.click();
          } }, has ? mediaThumb(draft.bgImage) : icon('image'), h('span', { class: 'ri-main' }, h('span', { class: 'ri-title' }, has ? 'Change image' : 'Choose an image'), has ? null : h('span', { class: 'ri-sub' }, 'Shows behind your messages.')));
          bgWrap.append(pick);
          if (has) {
            bgWrap.append(
              h('button', { class: 'ri danger', onclick: () => { change({ bgImage: null }); drawBg(); } }, icon('trash'), h('span', { class: 'ri-main' }, h('span', { class: 'ri-title' }, 'Remove image'))),
              range('Dimming', 0, 0.95, 0.01, () => draft.bgDim, (v) => change({ bgDim: v }), (v) => Math.round(v * 100) + '%'));
          }
        };
        const mediaThumb = (id) => { const i = h('img', { class: 'thumb' }); P.media.url(id).then((u) => { if (u) i.src = u; }); return i; };

        const wholeSw = toggleEl(false);
        const save = h('button', { class: 'btn primary small', onclick: () => {
          draft.name = (name.value || '').trim() || 'My theme';
          T.upsert(draft);
          T.select(draft);
          dirty = false;
          S.emit('themes');
          ctl.close();
        } }, 'Save');
        ctl.actions.append(save);

        body.classList.add('editor');
        body.append(
          h('div', { class: 'preview-wrap' }, preview),
          h('div', { class: 'editor-scroll' },
            name,
            h('section', { class: 'group' }, h('h3', { class: 'group-title' }, 'Preview'), h('div', { class: 'card' },
              h('button', { class: 'ri', onclick: () => { wholeApp = !wholeApp; wholeSw.set(wholeApp); if (wholeApp) T.apply(draft); else T.applyCurrent(); } },
                h('span', { class: 'ri-main' }, h('span', { class: 'ri-title' }, 'Preview across the app'), h('span', { class: 'ri-sub' }, 'Applies your changes to every screen while you edit.')), wholeSw))),
            h('section', { class: 'group' }, h('h3', { class: 'group-title' }, 'Colors'), h('div', { class: 'card' },
              (() => { const sw = toggleEl(draft.dark); return h('button', { class: 'ri', onclick: () => { change({ dark: !draft.dark }); sw.set(draft.dark); } }, h('span', { class: 'ri-main' }, h('span', { class: 'ri-title' }, 'Dark theme'), h('span', { class: 'ri-sub' }, 'Sets default contrast and system bar colors.')), sw); })(),
              T.FIELDS.map(colorRow))),
            h('section', { class: 'group' }, h('h3', { class: 'group-title' }, 'Shape and text'), h('div', { class: 'card' },
              range('Bubble corners', 6, 30, 1, () => draft.bubbleRadius, (v) => change({ bubbleRadius: v }), (v) => Math.round(v) + ' px'),
              range('Chat text size', 0.85, 1.3, 0.01, () => draft.fontScale, (v) => change({ fontScale: v }), (v) => Math.round(v * 100) + '%'))),
            h('section', { class: 'group' }, h('h3', { class: 'group-title' }, 'Chat background'), h('div', { class: 'card' }, bgWrap))));
        drawBg();
        refresh();
      },
    });

    function toggleEl(on) {
      const el = h('span', { class: 'switch' + (on ? ' on' : ''), role: 'switch' }, h('span', { class: 'knob' }));
      el.set = (v) => el.classList.toggle('on', v);
      return el;
    }
  };
})();
