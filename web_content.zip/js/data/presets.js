/* Předpřipravené mapy (používá je Free mód i story levely)
   Rozměr w×h je ve věžích, skály/zdi/brány v buňkách (1 věž = 2×2 buňky). Nepřátelé jdou standardně zleva doprava,
   ale brána může být na kterékoli straně (L, R, T, B).
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  var S = BD.SUB;

  /* pomocné funkce pro zápis v jednotkách věží */
  function gate(side, posTowers, lenTowers) { return { side: side, pos: Math.round(posTowers * S), len: Math.round(lenTowers * S) }; }
  function block(list, x, y, w, h) { for (var i = 0; i < (w || 1) * S; i++) for (var j = 0; j < (h || 1) * S; j++) list.push([x * S + i, y * S + j]); }
  /* skála: buňky bloku dostanou společné číslo skupiny, takže se vykreslí jako jeden kámen */
  function rockBlock(list, x, y, w, h) {
    var g = 1; list.forEach(function (r) { if (r[2] >= g) g = r[2] + 1; });
    for (var i = 0; i < (w || 1) * S; i++) for (var j = 0; j < (h || 1) * S; j++) list.push([x * S + i, y * S + j, g]);
  }

  var open = { id: 'open', name: 'Otevřené pole', w: 14, h: 10, spawns: [gate('L', 4, 2)], exit: gate('R', 4, 2), rocks: [], walls: [] };
  rockBlock(open.rocks, 3, 2); rockBlock(open.rocks, 3, 7); rockBlock(open.rocks, 9, 3); rockBlock(open.rocks, 9, 6); rockBlock(open.rocks, 6, 4, 2, 2);

  var two = { id: 'two', name: 'Dva vchody', w: 14, h: 12, spawns: [gate('L', 1, 2), gate('L', 9, 2)], exit: gate('R', 5, 2), rocks: [], walls: [] };
  block(two.walls, 6, 3, 1, 6); rockBlock(two.rocks, 3, 5); rockBlock(two.rocks, 10, 2); rockBlock(two.rocks, 10, 9); rockBlock(two.rocks, 3, 1); rockBlock(two.rocks, 3, 10);

  var corridor = { id: 'corridor', name: 'Úzká chodba', w: 16, h: 8, spawns: [gate('L', 3, 2)], exit: gate('R', 3, 2), rocks: [], walls: [] };
  block(corridor.walls, 4, 0, 1, 3); block(corridor.walls, 4, 5, 1, 3); block(corridor.walls, 8, 0, 1, 2); block(corridor.walls, 8, 4, 1, 4);
  block(corridor.walls, 12, 0, 1, 4); block(corridor.walls, 12, 6, 1, 2);

  BD.data.presets = [open, two, corridor];
  BD.data.presetTools = { gate: gate, block: block, rockBlock: rockBlock };
})(window.BD);
