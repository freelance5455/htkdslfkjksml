/* ===================================================================
 * VFL.Data.Leagues
 * تعریف لیگ‌ها. لیگ‌های "کامل" جدول و برنامه مسابقات دارند.
 * گروه‌های "ناقص" فقط برای پر کردن لیگ قهرمانان اروپا نگه‌داری می‌شوند
 * و فعلاً جدول یا فصل مستقل ندارند.
 * =================================================================== */
(function (VFL) {
  "use strict";

  VFL.Data = VFL.Data || {};

  VFL.Data.Leagues = [
    { id: "epl", name: "Premier League", displayName: "لیگ برتر انگلیس", country: "انگلیس", full: true, teamCount: 20 },
    { id: "laliga", name: "La Liga", displayName: "لالیگا اسپانیا", country: "اسپانیا", full: true, teamCount: 20 },
    { id: "seriea", name: "Serie A", displayName: "سری آ ایتالیا", country: "ایتالیا", full: true, teamCount: 20 },
    { id: "bundesliga", name: "Bundesliga", displayName: "بوندس‌لیگا آلمان", country: "آلمان", full: true, teamCount: 18 },
    { id: "ligue1", name: "Ligue 1", displayName: "لیگ ۱ فرانسه", country: "فرانسه", full: true, teamCount: 18 },
    { id: "ipl", name: "Persian Gulf Pro League", displayName: "لیگ برتر خلیج فارس", country: "ایران", full: true, teamCount: 18 },

    // گروه‌های ناقص — فقط برای سهمیه لیگ قهرمانان اروپا
    { id: "pt", name: "Portugal (selected)", displayName: "پرتغال (منتخب)", country: "پرتغال", full: false, teamCount: 3 },
    { id: "nl", name: "Netherlands (selected)", displayName: "هلند (منتخب)", country: "هلند", full: false, teamCount: 2 },
    { id: "tr", name: "Turkey (selected)", displayName: "ترکیه (منتخب)", country: "ترکیه", full: false, teamCount: 2 },
    { id: "be", name: "Belgium (selected)", displayName: "بلژیک (منتخب)", country: "بلژیک", full: false, teamCount: 1 },
    { id: "intl", name: "International (selected)", displayName: "تیم‌های بین‌المللی منتخب", country: null, full: false, teamCount: 12 }
  ];

  VFL.Data.getLeagueById = function (id) {
    return VFL.Data.Leagues.find(function (l) { return l.id === id; }) || null;
  };
})(window.VFL || (window.VFL = {}));
