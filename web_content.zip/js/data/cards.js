/* Karty (odměny) – data. Karta se použije kliknutím ve spodní liště; efekt je v js/systems/cards.js (podle id).
   Nová karta = jeden objekt tady + jedna funkce v systems/cards.js (EFFECTS) + záznam v data/bestiary.js.
   drop: šance, že karta padne za šéfa / za bezchybnou vlnu (žádný život neprošel).
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  BD.data.cards = {
    drop: { boss: 1, perfect: 0.25 },
    list: {
      atomic: { id: 'atomic', name: 'Atomovka', color: '#e0a23a', short: 'Zničí všechny nepřátele na mapě.' },
      meteor: { id: 'meteor', name: 'Meteorický roj', color: '#e0625a', short: 'Na mapu začnou padat meteority a zničí část nepřátel.' },
    },
    order: ['atomic', 'meteor'],
  };
})(window.BD);
