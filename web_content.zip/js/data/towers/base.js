/* Základní věž (úroveň 0, bez čtverečků) – nic nestřílí. Po kliknutí se vylepší na jednu z kategorií (normal, burst, ghost, boost).
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  BD.data.towers.base = {
    id: 'base', parent: '', order: 0, name: 'Základna', color: '#f0c419', cost: 10, role: 'shot',
    desc: 'Slabá střílející věž a zeď. Klikni na ni a vyber kategorii.',
    base: { dmg: 6, range: 2, cd: 0.9, speed: 10 }
  };
})(window.BD);
