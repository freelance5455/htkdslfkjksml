/* Věž: Plošný výbuch – vylepšení Základny a jeho další vylepšení (každé vylepšení je samostatná věž, strom se řídí polem parent).
   Hodnoty vylepšení vznikly přepočtem ze starých větví (úroveň 2). Upravuj ve Studiu.
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  BD.data.towers.burst = {
    id: 'burst', parent: 'base', order: 2, name: 'Plošný výbuch', color: '#ff9a1f', cost: 35, role: 'burst',
    desc: 'Opakované rázové vlny zasáhnou všechny blízké bubliny.', 
    base: { dmg: 10, range: 1.7, cd: 0.67 },
  };
  BD.data.towers.burst_a = {
    id: 'burst_a', parent: 'burst', order: 21, name: 'Častý', color: '#ff9a1f', cost: 28, role: 'burst', hp: 125,
    desc: 'Výbuchy jsou častější.', 
    base: { dmg: 16, range: 1.85, cd: 0.44 },
  };
  BD.data.towers.burst_b = {
    id: 'burst_b', parent: 'burst', order: 22, name: 'Silný', color: '#ff9a1f', cost: 28, role: 'burst', hp: 125,
    desc: 'Větší poškození.', 
    base: { dmg: 26, range: 1.85, cd: 0.63 },
  };
  BD.data.towers.burst_c = {
    id: 'burst_c', parent: 'burst', order: 23, name: 'Široký', color: '#ff9a1f', cost: 28, role: 'burst', hp: 125,
    desc: 'Větší dosah vlny.', 
    base: { dmg: 16, range: 2.53, cd: 0.63 },
  };
})(window.BD);
