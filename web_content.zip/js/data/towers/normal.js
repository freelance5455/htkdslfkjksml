/* Věž: Základní – vylepšení Základny a jeho další vylepšení (každé vylepšení je samostatná věž, strom se řídí polem parent).
   Hodnoty vylepšení vznikly přepočtem ze starých větví (úroveň 2). Upravuj ve Studiu.
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  BD.data.towers.normal = {
    id: 'normal', parent: 'base', order: 1, name: 'Základní', color: '#f0c419', cost: 18, role: 'shot',
    desc: 'Univerzální věž. Zasáhne i duchy.', hitsGhost: true,
    base: { dmg: 15, range: 2.3, cd: 0.5, speed: 10 },
  };
  BD.data.towers.normal_a = {
    id: 'normal_a', parent: 'normal', order: 11, name: 'Rychlá', color: '#f0c419', cost: 14, role: 'shot', hp: 125,
    desc: 'Střílí rychleji.', hitsGhost: true,
    base: { dmg: 24, range: 2.45, cd: 0.33, speed: 10 },
  };
  BD.data.towers.normal_b = {
    id: 'normal_b', parent: 'normal', order: 12, name: 'Silná', color: '#f0c419', cost: 14, role: 'shot', hp: 125,
    desc: 'Větší poškození.', hitsGhost: true,
    base: { dmg: 38, range: 2.45, cd: 0.47, speed: 10 },
  };
  BD.data.towers.normal_c = {
    id: 'normal_c', parent: 'normal', order: 13, name: 'Dalekonosná', color: '#f0c419', cost: 14, role: 'shot', hp: 125,
    desc: 'Větší dosah.', hitsGhost: true,
    base: { dmg: 24, range: 3.37, cd: 0.47, speed: 10 },
  };
})(window.BD);
