/* Věž: Proti duchům – vylepšení Základny a jeho další vylepšení (každé vylepšení je samostatná věž, strom se řídí polem parent).
   Hodnoty vylepšení vznikly přepočtem ze starých větví (úroveň 2). Upravuj ve Studiu.
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  BD.data.towers.ghost = {
    id: 'ghost', parent: 'base', order: 3, name: 'Proti duchům', color: '#9ccc2a', cost: 20, role: 'shot',
    desc: 'Skvělá na duchy, na ostatní bubliny je k ničemu.', hitsGhost: true, onlyGhost: true,
    base: { dmg: 20, range: 3.0, cd: 0.5, speed: 11 },
  };
  BD.data.towers.ghost_a = {
    id: 'ghost_a', parent: 'ghost', order: 31, name: 'Rychlá', color: '#9ccc2a', cost: 16, role: 'shot', hp: 125,
    desc: 'Střílí rychleji.', hitsGhost: true, onlyGhost: true,
    base: { dmg: 32, range: 3.15, cd: 0.33, speed: 11 },
  };
  BD.data.towers.ghost_b = {
    id: 'ghost_b', parent: 'ghost', order: 32, name: 'Silná', color: '#9ccc2a', cost: 16, role: 'shot', hp: 125,
    desc: 'Větší poškození.', hitsGhost: true, onlyGhost: true,
    base: { dmg: 51, range: 3.15, cd: 0.47, speed: 11 },
  };
  BD.data.towers.ghost_c = {
    id: 'ghost_c', parent: 'ghost', order: 33, name: 'Dalekonosná', color: '#9ccc2a', cost: 16, role: 'shot', hp: 125,
    desc: 'Větší dosah.', hitsGhost: true, onlyGhost: true,
    base: { dmg: 32, range: 4.35, cd: 0.47, speed: 11 },
  };
})(window.BD);
