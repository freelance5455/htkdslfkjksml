/* Věž: Zesilovač – vylepšení Základny a jeho další vylepšení (každé vylepšení je samostatná věž, strom se řídí polem parent).
   Hodnoty vylepšení vznikly přepočtem ze starých větví (úroveň 2). Upravuj ve Studiu.
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  BD.data.towers.boost = {
    id: 'boost', parent: 'base', order: 4, name: 'Zesilovač', color: '#e5483a', cost: 40, role: 'boost',
    desc: 'Zesiluje poškození všech věží, kterých se dotýká.', 
    base: { boost: 1.25 },
  };
  BD.data.towers.boost_a = {
    id: 'boost_a', parent: 'boost', order: 41, name: 'Silnější', color: '#e5483a', cost: 32, role: 'boost', hp: 125,
    desc: 'Větší zesílení.', 
    base: { boost: 1.51 },
  };
  BD.data.towers.boost_b = {
    id: 'boost_b', parent: 'boost', order: 42, name: 'Mírný', color: '#e5483a', cost: 32, role: 'boost', hp: 125,
    desc: 'Menší zesílení.', 
    base: { boost: 1.41 },
  };
  BD.data.towers.boost_c = {
    id: 'boost_c', parent: 'boost', order: 43, name: 'Extra', color: '#e5483a', cost: 32, role: 'boost', hp: 125,
    desc: 'Největší zesílení.', 
    base: { boost: 1.61 },
  };
})(window.BD);
