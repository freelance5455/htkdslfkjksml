/* Tutoriál – kroky. Každý krok má text a buď podmínku done(ctx), nebo manual:true
   (pak se potvrzuje tlačítkem „Rozumím“). ctx = { game, shop, sel, startPath }
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  BD.data.tutorial = [
    { text: 'Bubliny přijdou otvorem v levé zdi a poputují k otvoru vpravo. Vyber věž <b>Základna</b> v panelu (nebo stiskni klávesu 1).',
      done: function (c) { return c.shop === 'base' || c.game.towers.length > 0; } },
    { text: 'Klepni na mapu a <b>postav věž</b>. Věž je zároveň <b>zeď</b> – bubliny ji musí obejít.',
      done: function (c) { return c.game.towers.length >= 1; } },
    { text: 'Postav další věže tak, aby bubliny musely jít <b>delší cestou</b>. Čísla nad kurzorem ukazují délku trasy před a po stavbě.',
      done: function (c) { return c.game.towers.length >= 3 && c.game.pathLen(0) >= c.startPath + 4 * BD.SUB; } },
    { text: 'Spusť hru tlačítkem <b>Start</b> (nebo mezerníkem). Vlny pak přijíždějí samy po <b>pásu</b> vedle hrací plochy a nečekají na tebe.',
      done: function (c) { return c.game.wave >= 1; } },
    { text: 'Klikni na svoji věž a <b>vyber vylepšení</b> (Základní, Plošný výbuch…). Věž se přemění a dál se dá vylepšovat podle stromu, který je u ní nabídnutý. Volba je nevratná.',
      done: function (c) { return c.game.towers.some(function (t) { return t.type !== 'base'; }); } },
    { text: 'Tohle je vše. Přežij zbylé vlny a odemkneš první pravý level.', manual: true },
  ];
})(window.BD);
