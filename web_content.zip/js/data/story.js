/* Story mapa – uzly (levely), jejich závislosti a pomocné funkce.
   Levely označené placeholder:true jsou zatím vygenerované (symetrické skály) –
   ručně navržené přijdou později.
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  var P = BD.data.presets;

  /* deterministický generátor, ať je placeholder level pokaždé stejný */
  function rng(seed) { var s = seed >>> 0; return function () { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }; }

  /* placeholder level: brány vlevo/vpravo, skály souměrně nahoře/dole, případně zdi; vždy se ověří průchodnost */
  function gen(name, w, h, spawnN, rockPairs, seed, waves, wallN) {
    var R = rng(seed), Sb = BD.SUB, spawns = [], i, tools = BD.data.presetTools;
    var gl = 2 * Sb;                                                         // délka brány: 2 věže
    for (i = 0; i < spawnN; i++) spawns.push({ side: 'L', pos: Math.max(0, Math.min(h * Sb - gl, Math.round(((i + 1) * h / (spawnN + 1)) * Sb - gl / 2))), len: gl });
    var L = { name: name, w: w, h: h, spawns: spawns, exit: { side: 'R', pos: Math.round(h * Sb / 2 - gl / 2), len: gl }, rocks: [], walls: [], waves: waves, placeholder: true };
    var taken = {}, tries = 0, pairs = 0, k;
    while (pairs < rockPairs && tries++ < 600) {
      var x = 2 + Math.floor(R() * (w - 4)), y = Math.floor(R() * Math.ceil(h / 2)), my = h - 1 - y;
      k = x + ',' + y; var k2 = x + ',' + my;
      if (taken[k] || taken[k2]) continue;
      var before = L.rocks.length;
      tools.rockBlock(L.rocks, x, y); if (my !== y) tools.rockBlock(L.rocks, x, my);
      if (!BD.systems.levels.validate(L).ok) { L.rocks.length = before; continue; }
      taken[k] = 1; taken[k2] = 1; pairs++;
    }
    for (i = 0, tries = 0; i < (wallN || 0) && tries++ < 200;) {                // svislé zdi s mezerou
      var wx = 3 + Math.floor(R() * (w - 6)), wy = Math.floor(R() * (h - 3)), len = 2 + Math.floor(R() * 2), b2 = L.walls.length;
      tools.block(L.walls, wx, wy, 1, len);
      if (!BD.systems.levels.validate(L).ok) { L.walls.length = b2; continue; }
      i++;
    }
    return L;
  }
  function fromPreset(p, name, waves) {
    var L = BD.util.clone(p); delete L.id; L.name = name; L.waves = waves; return L;
  }

  var tutorial = { name: 'Tutoriál', w: 10, h: 8, spawns: [BD.data.presetTools.gate('L', 3, 2)], exit: BD.data.presetTools.gate('R', 3, 2),
    rocks: [], walls: [], waves: 3, gold: 200, lives: 10 };
  [[2, 1], [2, 6], [7, 2], [7, 5]].forEach(function (p) { BD.data.presetTools.rockBlock(tutorial.rocks, p[0], p[1]); });

  /* x,y = souřadnice v SVG mapě 1000×540 */
  var nodes = [
    { id: 't1', title: 'Tutoriál', x: 70,  y: 270, requires: [],                    level: tutorial, tutorial: true, noCards: true },
    { id: 'l2', title: 'Základy',  x: 190, y: 270, requires: ['t1'],                level: fromPreset(P[0], 'Základy', 8), noCards: true },

    { id: 'a1', title: 'Dva vchody', x: 340, y: 105, requires: ['l2'],              level: fromPreset(P[1], 'Dva vchody', 10) },
    { id: 'a2', title: 'Chodba',     x: 480, y: 105, requires: ['a1'],              level: fromPreset(P[2], 'Chodba', 12) },
    { id: 'a3', title: 'Křižovatka', x: 620, y: 105, requires: ['a2'],              level: gen('Křižovatka', 16, 12, 2, 6, 11, 14, 2) },

    { id: 'b1', title: 'Pole II',    x: 340, y: 270, requires: ['l2'],              level: gen('Pole II', 16, 12, 1, 7, 21, 12) },
    { id: 'b2', title: 'Zkratky',    x: 480, y: 270, requires: ['b1'],              level: gen('Zkratky', 16, 12, 2, 8, 33, 14, 2) },
    { id: 'b3', title: 'Bludiště',   x: 620, y: 270, requires: ['b2'],              level: gen('Bludiště', 20, 14, 2, 12, 47, 16, 4) },

    { id: 'c1', title: 'Roh',        x: 340, y: 435, requires: ['l2'],              level: gen('Roh', 14, 10, 1, 6, 58, 12) },
    { id: 'c2', title: 'Tři brány',  x: 480, y: 435, requires: ['c1'],              level: gen('Tři brány', 18, 14, 3, 8, 64, 15, 2) },
    { id: 'c3', title: 'Sítě',       x: 620, y: 435, requires: ['c2'],              level: gen('Sítě', 20, 16, 2, 14, 77, 18, 3) },

    { id: 'f1', title: 'Finále',     x: 830, y: 270, requires: ['a3', 'b3', 'c3'],  level: gen('Finále', 24, 18, 3, 16, 91, 25, 6) },
  ];

  var byId = {};
  nodes.forEach(function (n) { byId[n.id] = n; });

  function isOpen(n, done) { return n.requires.every(function (r) { return done[r]; }); }

  /* done = splněno, open = jde hrát, locked = vidět, ale zamčeno, hidden = zatím neviditelné */
  function state(n, done, natural) {
    if (done[n.id]) return 'done';
    if (!natural && BD.dev && BD.dev.allLevels) return 'open';       // příkaz AllLevels z terminálu: všechny levely jsou odemčené (postup se tím nemění)
    if (isOpen(n, done)) return 'open';
    var near = n.requires.some(function (r) { return done[r] || isOpen(byId[r], done); });
    return near ? 'locked' : 'hidden';
  }

  function doneMap(completed) { var m = {}; (completed || []).forEach(function (id) { m[id] = true; }); return m; }

  BD.data.story = { nodes: nodes, byId: byId, state: state, doneMap: doneMap, total: nodes.length,
    /* další level po výhře: po cestě mapy; je-li rozcestí (víc otevřených nástupců), vybere se náhodný.
       Když po tomto levelu nic nenavazuje (např. finále čeká na další větve), vezme se náhodný jiný otevřený level. */
    pickNext: function (id, completed, rnd) {
      var d = doneMap(completed), r = rnd || Math.random;
      var open = nodes.filter(function (n) { return state(n, d, true) === 'open'; });
      var succ = open.filter(function (n) { return n.requires.indexOf(id) >= 0; });
      var pool = succ.length ? succ : open;
      return pool.length ? pool[Math.floor(r() * pool.length) % pool.length] : null;
    },
    /* první nesplněný hratelný uzel – „co je další“ */
    nextNode: function (completed) {
      var d = doneMap(completed);
      for (var i = 0; i < nodes.length; i++) if (state(nodes[i], d, true) === 'open') return nodes[i];
      return null;
    } };
})(window.BD);
