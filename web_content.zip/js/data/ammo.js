/* Střelivo – jak vypadá a jak se chová střela věže: tři fáze (výstřel u věže → let → dopad).
   Poškození, dosah a prodleva zůstávají na věži; střelivo určuje vzhled, způsob letu a násobek poškození.
   „default“ = výchozí střela (věž bez vlastního střeliva). Bez nakresleného tvaru se fáze kreslí původním způsobem hry.
   Fáze: muzzle (výstřel), shot (let), impact (dopad). Tvar fáze = phase.sprite (viz render/sprite.js, +x = směr střelby).
   dur = délka v s, size = průměr v buňkách, s0→s1 velikost, a0→a1 průhlednost, r0→r1 natočení (°) od začátku do konce fáze.
   Copyright (c) 2026 vancode.io – MIT License */
(function (BD) {
  'use strict';
  BD.data = BD.data || {};
  BD.data.ammo = {
    default: {
      name: 'Výchozí střela', color: '#9fb3ad', dmgMul: 1, flight: 'homing', speedMul: 1,
      muzzle: { dur: 0.18, size: 0.9, dist: 0.7, s0: 0.5, s1: 1.2, a0: 1, a1: 0, r0: 0, r1: 0 },
      shot: { size: 0.3, spin: 0, trail: 0 },
      impact: { dur: 0.3, size: 1.2, s0: 0.4, s1: 1, a0: 1, a1: 0, r0: 0, r1: 0 },
    },
  };
})(window.BD);
