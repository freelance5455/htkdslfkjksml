/* ===================================================================
 * VFL.Data.Teams
 * دیتابیس تیم‌ها — فقط شناسه، نام، کشور، لیگ و Overall
 * هیچ اطلاعات بازیکنی در این نسخه وجود ندارد.
 * =================================================================== */
(function (VFL) {
  "use strict";

  VFL.Data = VFL.Data || {};

  function t(id, name, country, league, overall, leagueGroup) {
    return {
      id: id,
      name: name,
      country: country,
      league: league,          // شناسه لیگ کامل، یا null اگر بخشی از لیگ کامل نیست
      leagueGroup: leagueGroup || null, // برچسب نمایشی برای گروه‌های ناقص
      overall: overall
    };
  }

  VFL.Data.Teams = [
    // ---------- Premier League (انگلیس) ----------
    t("epl-arsenal", "Arsenal", "انگلیس", "epl", 89),
    t("epl-aston-villa", "Aston Villa", "انگلیس", "epl", 83),
    t("epl-bournemouth", "Bournemouth", "انگلیس", "epl", 78),
    t("epl-brentford", "Brentford", "انگلیس", "epl", 78),
    t("epl-brighton", "Brighton & Hove Albion", "انگلیس", "epl", 81),
    t("epl-chelsea", "Chelsea", "انگلیس", "epl", 87),
    t("epl-coventry", "Coventry City", "انگلیس", "epl", 73),
    t("epl-crystal-palace", "Crystal Palace", "انگلیس", "epl", 79),
    t("epl-everton", "Everton", "انگلیس", "epl", 77),
    t("epl-fulham", "Fulham", "انگلیس", "epl", 77),
    t("epl-hull-city", "Hull City", "انگلیس", "epl", 71),
    t("epl-ipswich", "Ipswich Town", "انگلیس", "epl", 72),
    t("epl-leeds", "Leeds United", "انگلیس", "epl", 76),
    t("epl-liverpool", "Liverpool", "انگلیس", "epl", 86),
    t("epl-man-city", "Manchester City", "انگلیس", "epl", 89),
    t("epl-man-united", "Manchester United", "انگلیس", "epl", 85),
    t("epl-newcastle", "Newcastle United", "انگلیس", "epl", 84),
    t("epl-nottm-forest", "Nottingham Forest", "انگلیس", "epl", 80),
    t("epl-sunderland", "Sunderland", "انگلیس", "epl", 74),
    t("epl-tottenham", "Tottenham Hotspur", "انگلیس", "epl", 83),

    // ---------- La Liga (اسپانیا) ----------
    t("laliga-athletic-club", "Athletic Club", "اسپانیا", "laliga", 82),
    t("laliga-atletico", "Atlético Madrid", "اسپانیا", "laliga", 87),
    t("laliga-osasuna", "Osasuna", "اسپانیا", "laliga", 74),
    t("laliga-celta-vigo", "Celta Vigo", "اسپانیا", "laliga", 77),
    t("laliga-alaves", "Deportivo Alavés", "اسپانیا", "laliga", 72),
    t("laliga-elche", "Elche", "اسپانیا", "laliga", 70),
    t("laliga-barcelona", "Barcelona", "اسپانیا", "laliga", 90),
    t("laliga-getafe", "Getafe", "اسپانیا", "laliga", 75),
    t("laliga-levante", "Levante", "اسپانیا", "laliga", 71),
    t("laliga-malaga", "Málaga", "اسپانیا", "laliga", 69),
    t("laliga-racing-santander", "Racing Santander", "اسپانیا", "laliga", 72),
    t("laliga-rayo-vallecano", "Rayo Vallecano", "اسپانیا", "laliga", 75),
    t("laliga-deportivo-coruna", "Deportivo La Coruña", "اسپانیا", "laliga", 71),
    t("laliga-espanyol", "Espanyol", "اسپانیا", "laliga", 74),
    t("laliga-real-betis", "Real Betis", "اسپانیا", "laliga", 81),
    t("laliga-real-madrid", "Real Madrid", "اسپانیا", "laliga", 90),
    t("laliga-real-sociedad", "Real Sociedad", "اسپانیا", "laliga", 80),
    t("laliga-sevilla", "Sevilla", "اسپانیا", "laliga", 79),
    t("laliga-valencia", "Valencia", "اسپانیا", "laliga", 78),
    t("laliga-villarreal", "Villarreal", "اسپانیا", "laliga", 82),

    // ---------- Serie A (ایتالیا) ----------
    t("seriea-atalanta", "Atalanta", "ایتالیا", "seriea", 81),
    t("seriea-bologna", "Bologna", "ایتالیا", "seriea", 79),
    t("seriea-cagliari", "Cagliari", "ایتالیا", "seriea", 72),
    t("seriea-como", "Como", "ایتالیا", "seriea", 76),
    t("seriea-fiorentina", "Fiorentina", "ایتالیا", "seriea", 80),
    t("seriea-frosinone", "Frosinone", "ایتالیا", "seriea", 68),
    t("seriea-genoa", "Genoa", "ایتالیا", "seriea", 74),
    t("seriea-inter", "Inter", "ایتالیا", "seriea", 87),
    t("seriea-juventus", "Juventus", "ایتالیا", "seriea", 85),
    t("seriea-lazio", "Lazio", "ایتالیا", "seriea", 79),
    t("seriea-lecce", "Lecce", "ایتالیا", "seriea", 71),
    t("seriea-ac-milan", "AC Milan", "ایتالیا", "seriea", 85),
    t("seriea-monza", "Monza", "ایتالیا", "seriea", 70),
    t("seriea-napoli", "Napoli", "ایتالیا", "seriea", 83),
    t("seriea-parma", "Parma", "ایتالیا", "seriea", 73),
    t("seriea-roma", "Roma", "ایتالیا", "seriea", 82),
    t("seriea-sassuolo", "Sassuolo", "ایتالیا", "seriea", 75),
    t("seriea-torino", "Torino", "ایتالیا", "seriea", 76),
    t("seriea-udinese", "Udinese", "ایتالیا", "seriea", 73),
    t("seriea-venezia", "Venezia", "ایتالیا", "seriea", 69),

    // ---------- Bundesliga (آلمان) ----------
    t("bundesliga-bayern", "Bayern Munich", "آلمان", "bundesliga", 90),
    t("bundesliga-dortmund", "Borussia Dortmund", "آلمان", "bundesliga", 86),
    t("bundesliga-leipzig", "RB Leipzig", "آلمان", "bundesliga", 82),
    t("bundesliga-stuttgart", "VfB Stuttgart", "آلمان", "bundesliga", 81),
    t("bundesliga-hoffenheim", "TSG Hoffenheim", "آلمان", "bundesliga", 77),
    t("bundesliga-leverkusen", "Bayer Leverkusen", "آلمان", "bundesliga", 83),
    t("bundesliga-freiburg", "SC Freiburg", "آلمان", "bundesliga", 78),
    t("bundesliga-frankfurt", "Eintracht Frankfurt", "آلمان", "bundesliga", 80),
    t("bundesliga-augsburg", "FC Augsburg", "آلمان", "bundesliga", 73),
    t("bundesliga-mainz", "1. FSV Mainz 05", "آلمان", "bundesliga", 76),
    t("bundesliga-union-berlin", "1. FC Union Berlin", "آلمان", "bundesliga", 73),
    t("bundesliga-gladbach", "Borussia Mönchengladbach", "آلمان", "bundesliga", 76),
    t("bundesliga-hamburger-sv", "Hamburger SV", "آلمان", "bundesliga", 72),
    t("bundesliga-werder-bremen", "SV Werder Bremen", "آلمان", "bundesliga", 75),
    t("bundesliga-koln", "1. FC Köln", "آلمان", "bundesliga", 71),
    t("bundesliga-schalke", "FC Schalke 04", "آلمان", "bundesliga", 70),
    t("bundesliga-elversberg", "SV Elversberg", "آلمان", "bundesliga", 66),
    t("bundesliga-paderborn", "SC Paderborn 07", "آلمان", "bundesliga", 68),

    // ---------- Ligue 1 (فرانسه) ----------
    t("ligue1-angers", "Angers SCO", "فرانسه", "ligue1", 68),
    t("ligue1-auxerre", "AJ Auxerre", "فرانسه", "ligue1", 69),
    t("ligue1-brestois", "Stade Brestois 29", "فرانسه", "ligue1", 74),
    t("ligue1-le-havre", "Le Havre AC", "فرانسه", "ligue1", 70),
    t("ligue1-lens", "RC Lens", "فرانسه", "ligue1", 79),
    t("ligue1-lille", "LOSC Lille", "فرانسه", "ligue1", 81),
    t("ligue1-lorient", "FC Lorient", "فرانسه", "ligue1", 71),
    t("ligue1-lyon", "Olympique Lyonnais", "فرانسه", "ligue1", 80),
    t("ligue1-le-mans", "Le Mans FC", "فرانسه", "ligue1", 66),
    t("ligue1-marseille", "Olympique de Marseille", "فرانسه", "ligue1", 83),
    t("ligue1-monaco", "AS Monaco", "فرانسه", "ligue1", 82),
    t("ligue1-nice", "OGC Nice", "فرانسه", "ligue1", 78),
    t("ligue1-paris-fc", "Paris FC", "فرانسه", "ligue1", 72),
    t("ligue1-psg", "Paris Saint-Germain", "فرانسه", "ligue1", 90),
    t("ligue1-rennais", "Stade Rennais FC", "فرانسه", "ligue1", 77),
    t("ligue1-strasbourg", "RC Strasbourg Alsace", "فرانسه", "ligue1", 76),
    t("ligue1-toulouse", "Toulouse FC", "فرانسه", "ligue1", 74),
    t("ligue1-troyes", "ESTAC Troyes", "فرانسه", "ligue1", 67),

    // ---------- Persian Gulf Pro League (ایران) ----------
    t("ipl-tractor", "Tractor", "ایران", "ipl", 78),
    t("ipl-persepolis", "Persepolis", "ایران", "ipl", 78),
    t("ipl-sepahan", "Sepahan", "ایران", "ipl", 78),
    t("ipl-esteghlal", "Esteghlal", "ایران", "ipl", 78),
    t("ipl-foolad", "Foolad Khuzestan", "ایران", "ipl", 71),
    t("ipl-gol-gohar", "Gol Gohar Sirjan", "ایران", "ipl", 72),
    t("ipl-zob-ahan", "Zob Ahan", "ایران", "ipl", 68),
    t("ipl-aluminium-arak", "Aluminium Arak", "ایران", "ipl", 66),
    t("ipl-malavan", "Malavan", "ایران", "ipl", 67),
    t("ipl-kheybar", "Kheybar Khorramabad", "ایران", "ipl", 70),
    t("ipl-chadormalou", "Chadormalou", "ایران", "ipl", 65),
    t("ipl-shams-azar", "Shams Azar Qazvin", "ایران", "ipl", 64),
    t("ipl-esteghlal-khuzestan", "Esteghlal Khuzestan", "ایران", "ipl", 63),
    t("ipl-nassaji", "Nassaji Mazandaran", "ایران", "ipl", 62),
    t("ipl-paykan", "Paykan", "ایران", "ipl", 61),
    t("ipl-fajr-sepasi", "Fajr Sepasi", "ایران", "ipl", 60),
    t("ipl-sanat-naft", "Sanat Naft Abadan", "ایران", "ipl", 59),
    t("ipl-mes-shahre-babak", "Mes Shahr-e Babak", "ایران", "ipl", 58),

    // ---------- پرتغال (منتخب — فقط برای سهمیه لیگ قهرمانان) ----------
    t("pt-benfica", "Benfica", "پرتغال", null, 82, "pt"),
    t("pt-porto", "Porto", "پرتغال", null, 82, "pt"),
    t("pt-sporting-cp", "Sporting CP", "پرتغال", null, 81, "pt"),

    // ---------- هلند (منتخب) ----------
    t("nl-ajax", "Ajax", "هلند", null, 79, "nl"),
    t("nl-psv", "PSV Eindhoven", "هلند", null, 78, "nl"),

    // ---------- ترکیه (منتخب) ----------
    t("tr-galatasaray", "Galatasaray", "ترکیه", null, 84, "tr"),
    t("tr-fenerbahce", "Fenerbahçe", "ترکیه", null, 80, "tr"),

    // ---------- بلژیک (منتخب) ----------
    t("be-club-brugge", "Club Brugge", "بلژیک", null, 77, "be"),

    // ---------- تیم‌های بین‌المللی منتخب (بدون لیگ کامل) ----------
    t("intl-inter-miami", "Inter Miami", "آمریکا", null, 82, "intl"),
    t("intl-al-hilal", "Al Hilal", "عربستان سعودی", null, 83, "intl"),
    t("intl-al-ittihad", "Al Ittihad", "عربستان سعودی", null, 80, "intl"),
    t("intl-al-ahli", "Al Ahli", "عربستان سعودی", null, 79, "intl"),
    t("intl-al-nassr", "Al Nassr", "عربستان سعودی", null, 81, "intl"),
    t("intl-santos", "Santos", "برزیل", null, 74, "intl"),

    // ---------- اضافه‌شده بعداً — Overall این ۶ تیم عددی نبود که کاربر داده باشد؛
    // چون هیچ‌کدام قبلاً در دیتابیس نبودند، Overall را از میانگین Overall
    // ۱۱ بازیکن برتری که خود کاربر برای هر تیم فرستاده محاسبه کردیم
    // (همان روشی که موتور مسابقه خودش برای تیم‌های دارای دیتابیس بازیکن استفاده می‌کند) ----------
    t("intl-flamengo", "Flamengo", "برزیل", null, 84, "intl"),
    t("intl-palmeiras", "Palmeiras", "برزیل", null, 82, "intl"),
    t("intl-fluminense", "Fluminense", "برزیل", null, 81, "intl"),
    t("intl-botafogo", "Botafogo", "برزیل", null, 78, "intl"),
    t("intl-sao-paulo", "São Paulo", "برزیل", null, 79, "intl"),
    t("intl-boca-juniors", "Boca Juniors", "آرژانتین", null, 79, "intl")
  ];

  VFL.Data.getTeamById = function (id) {
    return VFL.Data.Teams.find(function (tm) { return tm.id === id; }) || null;
  };

  VFL.Data.getTeamsByLeague = function (leagueId) {
    return VFL.Data.Teams.filter(function (tm) { return tm.league === leagueId; });
  };

  VFL.Data.getTeamsByLeagueGroup = function (groupId) {
    return VFL.Data.Teams.filter(function (tm) { return tm.leagueGroup === groupId; });
  };
})(window.VFL || (window.VFL = {}));
