/* campaign.js — Phase 10: game modes, national goals with rewards, victory / defeat, score and ranking.
   State lives in st.camp (saved). Modes: 'campaign' (ends on victory, defeat or the end date) and 'sandbox' (never ends). */
(function (G) {
  'use strict';
  const GOAL_COUNT = 3;

  G.victoryRules = function () {
    const w = G.scenarioId === 'world';
    return w ? { dom: 0.30, ally: 0.45, years: 5 } : { dom: 0.5, ally: 0.65, years: 4 };
  };

  G.initCampaign = function (st, fresh, mode) {
    if (!st.camp || fresh) st.camp = { mode: mode || 'campaign', ended: false, result: null, goals: [], seq: 1, done: 0, cd: {}, hist: true, peak: 0 };
    const c = st.camp;
    c.goals = c.goals || []; c.cd = c.cd || {}; c.seq = c.seq || 1; c.done = c.done || 0; c.peak = c.peak || 0;
    if (c.hist == null) c.hist = true;
    const y0 = (G.scenario && G.scenario.startYear) || 1936;
    c.endY = y0 + G.victoryRules().years;
    if (st.player && !c.goals.length) fillGoals();
  };

  /* ---------- measures ---------- */
  G.landProvinceCount = function () { let n = 0; for (const p of G.provinces) if (!p.sea) n++; return n; };
  G.provCount = function (id) { let n = 0; const o = G.state.owners; for (const p of G.provinces) if (!p.sea && o[p.id] === id) n++; return n; };
  G.armyUnits = function (id) { return G.state.armies.reduce((n, a) => n + (a.owner === id ? a.units.length : 0), 0); };
  G.techCount = function (id) { return Object.keys(G.state.tech[id].done).length; };
  G.landShare = function (id) { return G.provCount(id) / Math.max(1, G.landProvinceCount()); };
  G.alliedShare = function (id) { let n = G.provCount(id); G.alliesOf(id).forEach(a => { if (!G.state.countries[a].dead) n += G.provCount(a); }); return n / Math.max(1, G.landProvinceCount()); };
  G.score = function (id) {
    const st = G.state, c = st.countries[id]; if (c.dead) return 0;
    const t = G.totals(id);
    return Math.round(10 * t.provs + 3 * (t.civ + t.mil) + 5 * G.techCount(id) + 2 * G.armyUnits(id) + 0.1 * (G.navalPower ? G.navalPower(id) : 0) + Math.min(6000, Math.max(0, c.treasury)) / 100 + t.pop / 40000);
  };
  G.ranking = function () {
    const st = G.state;
    return Object.keys(st.countries).filter(id => !st.countries[id].dead).map(id => ({ id: id, score: G.score(id) })).sort((a, b) => b.score - a.score);
  };
  G.rankOf = function (id) { const r = G.ranking(); const i = r.findIndex(x => x.id === id); return i < 0 ? r.length + 1 : i + 1; };

  /* ---------- goals ---------- */
  const KINDS = {
    provs:    { cur: id => G.provCount(id), make: (id, v, pw) => v + Math.max(2, Math.round(v * 0.18)), text: t => 'Control ' + t + ' provinces', ok: id => true },
    techs:    { cur: id => G.techCount(id), make: (id, v) => v + 3, text: t => 'Research ' + t + ' technologies in total', ok: id => true },
    factories:{ cur: id => { const t = G.totals(id); return t.civ + t.mil; }, make: (id, v) => v + 3, text: t => 'Own ' + t + ' factories (civilian + military)', ok: id => true },
    ships:    { cur: id => G.navalShips(id), make: (id, v) => v + 3, text: t => 'Command a navy of ' + t + ' ships', ok: id => G.totals(id).dock > 0 },
    army:     { cur: id => G.armyUnits(id), make: (id, v) => v + 4, text: t => 'Field ' + t + ' army units', ok: id => true },
    treasury: { cur: id => Math.round(G.state.countries[id].treasury), make: (id, v) => Math.max(1200, Math.round(v * 1.5 / 100) * 100), text: t => 'Hold ' + t + ' gold in the treasury', ok: id => true },
    alliance: { cur: id => G.alliesOf(id).length, make: (id, v) => v + 1, text: t => 'Have ' + t + ' alliance' + (t > 1 ? 's' : ''), ok: id => G.alliesOf(id).length < 3 },
    trade:    { cur: id => G.tradePartners(id), make: (id, v) => v + 1, text: t => 'Sign trade agreements with ' + t + ' nation' + (t > 1 ? 's' : ''), ok: id => G.tradePartners(id) < 4 }
  };
  G.GOAL_KINDS = KINDS;
  G.goalProgress = function (id, g) { return KINDS[g.kind].cur(id); };

  function fillGoals() {
    const st = G.state, c = st.camp, pid = st.player; if (!pid) return;
    let guard = 0;
    while (c.goals.length < GOAL_COUNT && guard++ < 30) {
      const keys = Object.keys(KINDS).filter(k => !c.goals.some(g => g.kind === k) && (c.cd[k] || 0) <= st.day && KINDS[k].ok(pid));
      if (!keys.length) break;
      const k = keys[Math.floor(G.rand() * keys.length)], K = KINDS[k], cur = K.cur(pid), pw = G.COUNTRIES[pid].pow || 2;
      const target = K.make(pid, cur, pw), days = 240 + Math.floor(G.rand() * 160);
      const scale = 0.7 + 0.15 * pw;
      c.goals.push({ id: c.seq++, kind: k, target: target, start: cur, text: K.text(target), due: st.day + days, reward: { gold: Math.round((180 + G.rand() * 220) * scale / 10) * 10, manpower: Math.round((1500 + G.rand() * 2500) * scale / 100) * 100 } });
    }
  }
  G.refillGoals = fillGoals;

  function goalsMonth() {
    const st = G.state, c = st.camp, pid = st.player; if (!pid || st.countries[pid].dead) return;
    for (const g of c.goals.slice()) {
      if (G.goalProgress(pid, g) >= g.target) {
        c.goals.splice(c.goals.indexOf(g), 1); c.done++; c.cd[g.kind] = st.day + 60;
        const pc = st.countries[pid]; pc.treasury += g.reward.gold; pc.manpower += g.reward.manpower;
        G.logMsg('Goal achieved: ' + g.text + ' (+' + g.reward.gold + ' gold, +' + g.reward.manpower + ' manpower)');
        G.onGoalDone && G.onGoalDone(g);
      } else if (st.day > g.due) {
        c.goals.splice(c.goals.indexOf(g), 1); c.cd[g.kind] = st.day + 30;
        G.logMsg('Goal expired: ' + g.text);
        G.onGoalFailed && G.onGoalFailed(g);
      }
    }
    fillGoals();
  }

  /* ---------- victory / end ---------- */
  function finish(kind, extra) {
    const st = G.state, c = st.camp; if (c.ended) return;
    c.ended = true;
    const pid = st.player, r = G.victoryRules();
    c.result = Object.assign({ kind: kind, day: st.day, date: G.dateString(), score: G.score(pid), rank: G.rankOf(pid), share: G.landShare(pid), provs: G.provCount(pid), goals: c.done }, extra || {});
    G.setPaused(true);
    G.logMsg('CAMPAIGN END — ' + kind);
    G.onCampaignEnd && G.onCampaignEnd(c.result);
  }
  G.campaignDefeat = function (by) { const c = G.state.camp; if (c && !c.ended && c.mode === 'campaign') finish('defeat', { by: by }); };

  function checkVictory() {
    const st = G.state, c = st.camp, pid = st.player; if (!pid || c.ended || c.mode !== 'campaign' || st.countries[pid].dead) return;
    const r = G.victoryRules();
    c.peak = Math.max(c.peak || 0, G.landShare(pid));
    if (G.landShare(pid) >= r.dom) return finish('domination');
    if (G.alliedShare(pid) >= r.ally) return finish('alliance');
    if (st.date.y >= c.endY) {
      const rank = G.rankOf(pid), n = G.ranking().length;
      finish(rank === 1 ? 'supreme' : rank <= 3 ? 'great' : rank <= Math.ceil(n / 2) ? 'survivor' : 'minor');
    }
  }

  G.campaignMonth = function () {
    const st = G.state; if (!st || !st.camp || !st.player) return;
    goalsMonth();
    checkVictory();
  };

  G.campaignSummary = function () {
    const st = G.state, c = st.camp, pid = st.player, r = G.victoryRules();
    return { mode: c.mode, endY: c.endY, share: G.landShare(pid), allied: G.alliedShare(pid), dom: r.dom, ally: r.ally, rank: G.rankOf(pid), score: G.score(pid), total: G.ranking().length, goals: c.done };
  };
})(window.EMP = window.EMP || {});
