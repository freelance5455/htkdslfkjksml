window.AustralWeather = (() => {
const BASE="https://api.open-meteo.com/v1/forecast";
const currentFields="temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,cloud_cover,pressure_msl,surface_pressure,wind_speed_10m,wind_direction_10m,wind_gusts_10m";
const hourlyFields="temperature_2m,relative_humidity_2m,dew_point_2m,apparent_temperature,precipitation_probability,precipitation,weather_code,pressure_msl,cloud_cover,visibility,wind_speed_10m,wind_direction_10m,wind_gusts_10m,uv_index,is_day";
const dailyFields="weather_code,temperature_2m_max,temperature_2m_min,apparent_temperature_max,apparent_temperature_min,sunrise,sunset,daylight_duration,sunshine_duration,uv_index_max,precipitation_sum,precipitation_probability_max,wind_speed_10m_max,wind_direction_10m_dominant";
async function fetchWeather(place){
 const params=new URLSearchParams({latitude:place.lat,longitude:place.lon,current:currentFields,hourly:hourlyFields,daily:dailyFields,forecast_days:7,timezone:place.timezone,temperature_unit:"celsius",wind_speed_unit:"kmh",precipitation_unit:"mm"});
 const response=await fetch(`${BASE}?${params}`,{headers:{Accept:"application/json"}});
 if(!response.ok)throw new Error(`A API respondeu com o código ${response.status}.`);
 const data=await response.json();if(!data.current||!data.hourly||!data.daily)throw new Error("Resposta meteorológica incompleta.");return data;
}
function description(code,isDay=1){const n=Number(code),night=Number(isDay)===0;const map={0:["Céu limpo",night?"🌙":"☀️"],1:["Predominantemente limpo",night?"🌙":"🌤️"],2:["Parcialmente nublado","🌤️"],3:["Nublado","☁️"],45:["Nevoeiro","🌫️"],48:["Nevoeiro com geada","🌫️"],51:["Chuvisco ligeiro","🌦️"],53:["Chuvisco moderado","🌦️"],55:["Chuvisco intenso","🌧️"],56:["Chuvisco gelado ligeiro","🌧️"],57:["Chuvisco gelado intenso","🌧️"],61:["Chuva ligeira","🌦️"],63:["Chuva moderada","🌧️"],65:["Chuva intensa","🌧️"],66:["Chuva gelada ligeira","🌧️"],67:["Chuva gelada intensa","🌧️"],71:["Queda de neve ligeira","🌨️"],73:["Queda de neve moderada","🌨️"],75:["Queda de neve intensa","❄️"],77:["Grãos de neve","🌨️"],80:["Aguaceiros ligeiros","🌦️"],81:["Aguaceiros moderados","🌧️"],82:["Aguaceiros fortes","⛈️"],85:["Aguaceiros de neve","🌨️"],86:["Aguaceiros de neve intensos","❄️"],95:["Trovoada","⛈️"],96:["Trovoada com granizo ligeiro","⛈️"],99:["Trovoada com granizo forte","⛈️"]};return map[n]||["Condições variáveis","🌤️"];}
function windDirection(deg){if(!Number.isFinite(Number(deg)))return "—";return ["N","NE","E","SE","S","SO","O","NO"][Math.round(Number(deg)/45)%8];}
function formatTime(value){return value?value.slice(11,16):"--:--";}
function dateLabel(value,options={weekday:"short",day:"numeric",month:"short"}){return new Date(`${value}T12:00:00`).toLocaleDateString("pt-PT",options);}
function safeNumber(value,digits=0){const n=Number(value);return Number.isFinite(n)?n.toFixed(digits):"--";}
return {fetchWeather,description,windDirection,formatTime,dateLabel,safeNumber};
})();