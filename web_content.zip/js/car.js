/* ============================================================
   car.js — player car: procedural 3D model + realistic physics
   15 body styles, paint, suspension, drift, nitro, fuel, damage
   ============================================================ */
'use strict';

const CAR_TRIM = 0x15171d;
const CAR_CHROME = 0xd7dde6;
const CAR_GLASS = 0x0a141c;
const CAR_TIRE = 0x08090b;
const CAR_RIM = 0xb9c1cc;

class PlayerCar {
  constructor(scene, envMap) {
    this.scene = scene;
    this.envMap = envMap;
    this.group = new THREE.Group();
    this.group.position.set(0, 0, 0);
    scene.add(this.group);

    this.pos = new THREE.Vector3(0, 0, 0);
    this.vel = new THREE.Vector3();
    this.heading = 0;
    this.speed = 0;
    this.rpm = 900;
    this.gear = 0;
    this.clutch = 0;
    this.steerAngle = 0;
    this.damage = 0;
    this.fuel = 1;
    this.nitro = 1;
    this.nitroActive = false;
    this.drifting = false;
    this.slip = 0;
    this.driftScore = 0;
    this.driftCombo = 1;
    this.topSpeedKmh = 0;
    this.overtakes = 0;
    this.wheelSpin = 0;
    this.distance = 0;
    this.longG = 0;
    this.latG = 0;
    this.autoTransmission = true;
    this.speedLimitMul = 1;
    this.spec = CARS[0];
    this.paintIndex = 0;
    this._brakeHold = 0;
    this._roll = 0; this._pitch = 0; this._bounce = 0;
    this._lastScrape = 0;
    this._smokeT = 0;
    this._buildModel();
    this.setSpec(CARS[0]);
  }

  /* ================================================================
     MODEL
     ================================================================ */
  setSpec(spec) {
    this.spec = spec;
    this.mass = spec.mass;
    this.maxSteer = 0.40 + spec.handling * 0.022;
    this.gripBase = 4.4 + spec.grip * 0.32;
    this.peakTorque = 200 + (9.5 - spec.accel) * 42;
    this.redline = spec.cyl === 0 ? 14000 : 6400 + spec.top * 2.2;
    this.idle = spec.cyl === 0 ? 0 : 820;
    this.topSpeed = spec.top / 3.6;
    this.finalDrive = spec.gears === 1 ? 4.7 : 3.55;
    this.wheelbase = spec.L * 0.58;
    this.gearCount = spec.gears;
    this.gearRatios = this._makeRatios(spec.gears);
    this.wheelRadius = spec.wheelR;
    this.brakeForce = spec.mass * 13.5;
    this._buildModel();
    this.setPaint(this.paintIndex);
    this.rpm = this.idle || 1000;
    this.gear = 0;
  }

  _makeRatios(n) {
    const base = [3.95, 2.42, 1.72, 1.32, 1.06, 0.88, 0.76];
    return base.slice(0, Math.max(1, Math.min(n, 7)));
  }

  ratio(g) {
    if (g === -1) return -3.3;
    if (g <= 0) return 0;
    return this.gearRatios[g - 1] || 0;
  }

  _buildModel() {
    while (this.group.children.length) {
      const c = this.group.children[0];
      this.group.remove(c);
      AD.disposeObject(c);
    }

    const spec = this.spec;
    const L = spec.L, W = spec.W, wr = spec.wheelR, cl = spec.clearance;
    const kind = spec.kind;
    const tall = (kind === 'suv' || kind === 'offroad');
    const bodyH = tall ? 0.78 : (kind === 'hyper' || kind === 'super') ? 0.48 : 0.56;
    const bodyBottom = cl + 0.06;
    const bodyTop = bodyBottom + bodyH;
    const bodyY = bodyBottom + bodyH / 2;

    const paint = [], trim = [], glass = [], head = [], tail = [];

    // ---- main body ----
    paint.push(AD.P(AD.taperBox(W * 0.97, bodyH, L * 0.95, 0.99, 0.92), 0xffffff, 0, bodyY, 0));
    // nose + tail tapers
    paint.push(AD.P(AD.taperBox(W * 0.9, bodyH * 0.72, L * 0.2, 0.82, 0.62), 0xffffff,
      0, bodyBottom + bodyH * 0.36, -L * 0.44));
    paint.push(AD.P(AD.taperBox(W * 0.94, bodyH * 0.8, L * 0.16, 0.86, 0.7), 0xffffff,
      0, bodyBottom + bodyH * 0.4, L * 0.44));
    // hood
    const hoodLen = L * 0.26;
    paint.push(AD.P(AD.taperBox(W * 0.9, bodyH * 0.34, hoodLen, 0.88, 0.8), 0xffffff,
      0, bodyTop - bodyH * 0.1, -L * 0.28, -0.045, 0, 0));
    // rear deck
    paint.push(AD.P(AD.taperBox(W * 0.92, bodyH * 0.3, L * 0.18, 0.92, 0.86), 0xffffff,
      0, bodyTop - bodyH * 0.09, L * 0.37, 0.03, 0, 0));

    // ---- cabin ----
    const cabinH = spec.cabinH;
    const cabinLen = spec.cabinLen;
    const cabinZ = spec.cabinZ;
    const roofTop = bodyTop + cabinH;
    paint.push(AD.P(AD.taperBox(W * 0.84, cabinH, cabinLen, spec.roofTaper, 0.6), 0xffffff,
      0, bodyTop + cabinH / 2 - 0.02, cabinZ));

    // glass
    glass.push(AD.P(new THREE.BoxGeometry(W * 0.74, cabinH * 0.92, 0.045), CAR_GLASS,
      0, bodyTop + cabinH * 0.5, cabinZ - cabinLen * 0.47, -0.52, 0, 0));
    glass.push(AD.P(new THREE.BoxGeometry(W * 0.72, cabinH * 0.86, 0.045), CAR_GLASS,
      0, bodyTop + cabinH * 0.5, cabinZ + cabinLen * 0.47, 0.55, 0, 0));
    for (const sx of [-1, 1]) {
      glass.push(AD.P(new THREE.BoxGeometry(0.04, cabinH * 0.66, cabinLen * 0.72), CAR_GLASS,
        sx * W * 0.405, bodyTop + cabinH * 0.54, cabinZ));
    }

    // ---- wheel arches / widebody ----
    if (spec.widebody) {
      for (const sx of [-1, 1]) {
        paint.push(AD.P(new THREE.BoxGeometry(0.12, bodyH * 0.6, L * 0.2), 0xffffff,
          sx * (W * 0.49), bodyY + bodyH * 0.08, -L * 0.31));
        paint.push(AD.P(new THREE.BoxGeometry(0.12, bodyH * 0.6, L * 0.2), 0xffffff,
          sx * (W * 0.49), bodyY + bodyH * 0.08, L * 0.31));
      }
    }

    // ---- trim: splitter / skirts / diffuser ----
    trim.push(AD.P(new THREE.BoxGeometry(W * 1.01, 0.09, 0.5), CAR_TRIM,
      0, cl + 0.08, -L * 0.47));
    trim.push(AD.P(new THREE.BoxGeometry(W * 0.96, 0.14, 0.42), CAR_TRIM,
      0, cl + 0.12, L * 0.47));
    for (const sx of [-1, 1]) {
      trim.push(AD.P(new THREE.BoxGeometry(0.1, 0.16, L * 0.5), CAR_TRIM,
        sx * W * 0.5, cl + 0.18, 0));
    }

    // ---- grille ----
    if (spec.grille === 'kidney') {
      for (const sx of [-1, 1]) {
        trim.push(AD.P(new THREE.BoxGeometry(W * 0.17, bodyH * 0.34, 0.06), 0x0a0b0e,
          sx * W * 0.15, bodyY - 0.02, -L * 0.485));
        trim.push(AD.P(new THREE.BoxGeometry(W * 0.14, bodyH * 0.28, 0.07), CAR_CHROME,
          sx * W * 0.15, bodyY - 0.02, -L * 0.487));
      }
    } else if (spec.grille !== 'none') {
      trim.push(AD.P(new THREE.BoxGeometry(W * 0.56, bodyH * 0.3, 0.07), 0x0a0b0e,
        0, bodyY - 0.03, -L * 0.49));
      if (spec.grille === 'chrome') {
        trim.push(AD.P(new THREE.BoxGeometry(W * 0.6, bodyH * 0.34, 0.04), CAR_CHROME,
          0, bodyY - 0.03, -L * 0.492));
      }
    }

    // ---- mirrors ----
    for (const sx of [-1, 1]) {
      trim.push(AD.P(new THREE.BoxGeometry(0.24, 0.1, 0.09), CAR_TRIM,
        sx * (W * 0.54), bodyTop + cabinH * 0.3, cabinZ - cabinLen * 0.4));
    }

    // ---- spoiler ----
    if (spec.spoiler === 1) {
      trim.push(AD.P(new THREE.BoxGeometry(W * 0.82, 0.06, 0.28), CAR_TRIM,
        0, bodyTop + 0.1, L * 0.47, -0.12, 0, 0));
    } else if (spec.spoiler === 2) {
      for (const sx of [-1, 1]) {
        trim.push(AD.P(new THREE.BoxGeometry(0.07, 0.3, 0.12), CAR_TRIM,
          sx * W * 0.32, bodyTop + 0.16, L * 0.44));
      }
      trim.push(AD.P(new THREE.BoxGeometry(W * 0.94, 0.055, 0.42), CAR_TRIM,
        0, bodyTop + 0.32, L * 0.45, -0.1, 0, 0));
    }

    // ---- exhausts ----
    for (const sx of [-1, 1]) {
      const ex = new THREE.CylinderGeometry(0.055, 0.055, 0.16, 10);
      ex.rotateX(Math.PI / 2);
      trim.push(AD.P(ex, CAR_CHROME, sx * W * 0.3, cl + 0.2, L * 0.5));
    }

    // ---- roof rails / bull bar / snorkel / bed ----
    if (spec.rails) {
      for (const sx of [-1, 1]) {
        trim.push(AD.P(new THREE.BoxGeometry(0.06, 0.08, cabinLen * 0.8), CAR_TRIM,
          sx * W * 0.34, roofTop + 0.05, cabinZ));
      }
    }
    if (spec.bullbar) {
      trim.push(AD.P(new THREE.BoxGeometry(W * 0.92, 0.08, 0.08), CAR_CHROME,
        0, bodyBottom + bodyH * 0.28, -L * 0.53));
      for (const sx of [-1, 1]) {
        trim.push(AD.P(new THREE.BoxGeometry(0.07, bodyH * 0.55, 0.07), CAR_CHROME,
          sx * W * 0.34, bodyY, -L * 0.52));
      }
    }
    if (spec.snorkel) {
      trim.push(AD.P(new THREE.BoxGeometry(0.09, cabinH * 1.1, 0.1), CAR_TRIM,
        W * 0.43, bodyTop + cabinH * 0.55, cabinZ - cabinLen * 0.44));
    }
    if (spec.bed) {
      trim.push(AD.P(new THREE.BoxGeometry(W * 0.82, 0.16, L * 0.22), CAR_TRIM,
        0, bodyTop + 0.02, L * 0.35));
      for (const sx of [-1, 1]) {
        trim.push(AD.P(new THREE.BoxGeometry(0.07, 0.22, L * 0.24), CAR_TRIM,
          sx * W * 0.42, bodyTop + 0.12, L * 0.35));
      }
    }
    if (spec.hoodScoop) {
      trim.push(AD.P(new THREE.BoxGeometry(W * 0.28, 0.12, 0.5), CAR_TRIM,
        0, bodyTop + 0.06, -L * 0.27));
    }

    // ---- lights ----
    if (spec.lightBar) {
      head.push(AD.P(new THREE.BoxGeometry(W * 0.8, 0.07, 0.05), 0xffffff,
        0, bodyTop - bodyH * 0.15, -L * 0.492));
    } else {
      for (const sx of [-1, 1]) {
        head.push(AD.P(new THREE.BoxGeometry(W * 0.26, bodyH * 0.16, 0.06), 0xffffff,
          sx * W * 0.31, bodyTop - bodyH * 0.2, -L * 0.492));
      }
    }
    tail.push(AD.P(new THREE.BoxGeometry(W * 0.72, bodyH * 0.13, 0.06), 0xff2200,
      0, bodyTop - bodyH * 0.18, L * 0.487));
    if (spec.spoiler === 2) {
      for (const sx of [-1, 1]) {
        tail.push(AD.P(new THREE.BoxGeometry(W * 0.18, 0.05, 0.05), 0xff2200,
          sx * W * 0.3, bodyTop + 0.2, L * 0.47));
      }
    }

    // ---- materials ----
    this.paintMat = new THREE.MeshStandardMaterial({
      color: 0xd4180f, metalness: 0.82, roughness: 0.26,
      envMap: this.envMap, envMapIntensity: 1.25,
    });
    const trimMat = new THREE.MeshStandardMaterial({
      vertexColors: true, metalness: 0.62, roughness: 0.42,
      envMap: this.envMap, envMapIntensity: 0.8,
    });
    const glassMat = new THREE.MeshStandardMaterial({
      vertexColors: true, metalness: 0.92, roughness: 0.06,
      transparent: true, opacity: 0.78, envMap: this.envMap, envMapIntensity: 1.5,
      depthWrite: false,
    });
    this.headMat = new THREE.MeshStandardMaterial({
      color: 0xfff6dc, emissive: 0xffefc0, emissiveIntensity: 1.6,
      roughness: 0.2, metalness: 0.2,
    });
    this.tailMat = new THREE.MeshStandardMaterial({
      color: 0x2a0000, emissive: 0xff1a08, emissiveIntensity: 1.2,
      roughness: 0.35, metalness: 0.1,
    });

    this.chassis = new THREE.Group();
    this.group.add(this.chassis);

    const addMesh = (parts, mat) => {
      if (!parts.length) return null;
      const m = new THREE.Mesh(AD.merge(parts), mat);
      m.castShadow = true;
      this.chassis.add(m);
      return m;
    };
    this.paintMesh = addMesh(paint, this.paintMat);
    addMesh(trim, trimMat);
    addMesh(glass, glassMat);
    this.headMesh = addMesh(head, this.headMat);
    this.tailMesh = addMesh(tail, this.tailMat);
    this.paintMesh.receiveShadow = true;

    // ---- wheels ----
    this.wheels = [];
    const tireW = tall ? 0.34 : 0.3;
    const tireGeo = new THREE.CylinderGeometry(wr, wr, tireW, 18);
    tireGeo.rotateZ(Math.PI / 2);
    const rimGeo = new THREE.CylinderGeometry(wr * 0.62, wr * 0.62, tireW + 0.02, 12);
    rimGeo.rotateZ(Math.PI / 2);
    const discGeo = new THREE.CylinderGeometry(wr * 0.5, wr * 0.5, 0.04, 14);
    discGeo.rotateZ(Math.PI / 2);
    const tireMat = new THREE.MeshStandardMaterial({ color: CAR_TIRE, roughness: 0.95, metalness: 0.05 });
    const rimMat = new THREE.MeshStandardMaterial({ color: CAR_RIM, metalness: 0.95, roughness: 0.25, envMap: this.envMap, envMapIntensity: 1.1 });
    const discMat = new THREE.MeshStandardMaterial({ color: 0x2a2c30, metalness: 0.7, roughness: 0.5 });
    const spokeGeo = new THREE.BoxGeometry(tireW + 0.03, 0.045, wr * 1.05);
    const positions = [
      [-W * 0.5 + 0.06, wr, -L * 0.31, true],
      [W * 0.5 - 0.06, wr, -L * 0.31, true],
      [-W * 0.5 + 0.06, wr, L * 0.31, false],
      [W * 0.5 - 0.06, wr, L * 0.31, false],
    ];
    for (const [x, y, z, front] of positions) {
      const w = new THREE.Group();
      w.position.set(x, y, z);
      const spin = new THREE.Group();
      const tire = new THREE.Mesh(tireGeo, tireMat); tire.castShadow = true;
      const rim = new THREE.Mesh(rimGeo, rimMat);
      const disc = new THREE.Mesh(discGeo, discMat);
      spin.add(tire); spin.add(rim); spin.add(disc);
      for (let s = 0; s < 5; s++) {
        const sp = new THREE.Mesh(spokeGeo, rimMat);
        sp.rotation.x = (s / 5) * Math.PI;
        rim.add(sp);
      }
      w.add(spin);
      w.userData = { front, spin };
      this.group.add(w);
      this.wheels.push(w);
    }

    // ---- shadow ----
    const shadowTex = AD.softShadowTexture();
    this.shadow = new THREE.Mesh(
      new THREE.PlaneGeometry(W + 1.1, L + 1.2),
      new THREE.MeshBasicMaterial({ map: shadowTex, transparent: true, opacity: 0.5, depthWrite: false })
    );
    this.shadow.rotation.x = -Math.PI / 2;
    this.shadow.position.y = 0.02;
    this.group.add(this.shadow);

    // ---- headlight beams + spot ----
    const beamMat = new THREE.MeshBasicMaterial({
      color: 0xfff2c0, transparent: true, opacity: 0.0, depthWrite: false,
      blending: THREE.AdditiveBlending, side: THREE.DoubleSide,
    });
    this.beamMat = beamMat;
    for (const sx of [-1, 1]) {
      const beam = new THREE.Mesh(new THREE.ConeGeometry(1.0, 11, 10, true), beamMat);
      beam.rotation.x = -Math.PI / 2;
      beam.position.set(sx * W * 0.3, bodyBottom + bodyH * 0.4, -L * 0.5 - 5.2);
      this.chassis.add(beam);
    }
    this.headSpot = new THREE.SpotLight(0xfff0c8, 0, 55, 0.62, 0.45, 1.4);
    this.headSpot.position.set(0, bodyTop * 0.9, -L * 0.4);
    this.headSpot.target.position.set(0, 0, -L * 0.4 - 22);
    this.chassis.add(this.headSpot);
    this.chassis.add(this.headSpot.target);

    this.brakeLight = new THREE.PointLight(0xff2211, 0, 8, 2);
    this.brakeLight.position.set(0, bodyTop - 0.1, L * 0.5);
    this.chassis.add(this.brakeLight);

    // ---- nitro flames ----
    const flameMat = new THREE.MeshBasicMaterial({
      color: 0x66ccff, transparent: true, opacity: 0, depthWrite: false,
      blending: THREE.AdditiveBlending,
    });
    this.flameMat = flameMat;
    this.flames = [];
    for (const sx of [-1, 1]) {
      const f = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.9, 8), flameMat);
      f.rotation.x = Math.PI / 2;
      f.position.set(sx * W * 0.3, cl + 0.2, L * 0.53);
      this.chassis.add(f);
      this.flames.push(f);
    }

    // ---- smoke particles ----
    this._initSmoke();

    this._allPaint = [this.paintMesh];
    this._headlightMeshes = [this.headMesh];
    this._bodyTop = bodyTop;
  }

  _initSmoke() {
    const N = 46;
    this._smokeN = N;
    const geo = new THREE.BufferGeometry();
    const pos = new Float32Array(N * 3);
    const col = new Float32Array(N * 3);
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    geo.setAttribute('color', new THREE.BufferAttribute(col, 3));
    const mat = new THREE.PointsMaterial({
      size: 0.9, map: AD.glowTexture('rgba(255,255,255,0.8)'),
      transparent: true, opacity: 0.5, depthWrite: false,
      vertexColors: true, blending: THREE.AdditiveBlending,
    });
    this.smoke = new THREE.Points(geo, mat);
    this.smoke.frustumCulled = false;
    this.group.add(this.smoke);
    this._smokeLife = new Float32Array(N);
    this._smokeVel = new Float32Array(N * 3);
  }

  setPaint(index) {
    this.paintIndex = index | 0;
    const c = PAINTS[this.paintIndex] || PAINTS[0];
    if (this.paintMat) this.paintMat.color.setHex(c.hex);
  }

  /* ================================================================
     PHYSICS
     ================================================================ */
  torqueAt(rpm) {
    const spec = this.spec;
    const red = this.redline;
    const f = AD.clamp(rpm / red, 0, 1.1);
    let curve;
    if (spec.cyl === 0) curve = 0.55 + 0.45 * Math.sin(Math.PI * Math.min(1, f * 0.9));
    else curve = 0.5 + 0.55 * Math.sin(Math.PI * Math.min(1, f * 0.92)) - (f > 0.9 ? (f - 0.9) * 1.6 : 0);
    return this.peakTorque * Math.max(0.2, curve);
  }

  shiftUp() {
    /* from reverse, gear-up returns to neutral (then neutral -> 1st) */
    if (this.gear === -1) {
      if (Math.abs(this.speed) < 1.2) { this.gear = 0; this.clutch = 0.15; return true; }
      return false;
    }
    if (this.gear >= 0 && this.gear < this.gearCount) {
      this.gear++;
      this.clutch = this.spec.cyl === 0 ? 0.05 : 0.24;
      return true;
    }
    return false;
  }

  shiftDown() {
    if (this.gear > 1) { this.gear--; this.clutch = 0.2; return true; }
    if (this.gear === 1 && Math.abs(this.speed) < 1.2) { this.gear = 0; this.clutch = 0.15; return true; }
    if (this.gear === 0 && Math.abs(this.speed) < 1.2) { this.gear = -1; this.clutch = 0.15; return true; }
    if (this.gear === -1 && Math.abs(this.speed) < 1.2) { this.gear = 0; this.clutch = 0.15; return true; }
    return false;
  }

  update(dt, input, env) {
    const s = this;
    env = env || {};
    const gripMul = env.gripMul === undefined ? 1 : env.gripMul;

    // ---------- transmission ----------
    if (input.consumeGearUp()) {
      if (s.gear === 0 && Math.abs(s.speed) < 1) { s.gear = 1; s.clutch = 0.2; }
      else if (s.shiftUp()) audio.shiftBlip(true);
    }
    if (input.consumeGearDown()) {
      if (s.shiftDown()) audio.shiftBlip(false);
    }
    if (s.clutch > 0) s.clutch -= dt;

    if (s.autoTransmission && s.gear > 0 && s.clutch <= 0 && s.gearCount > 1) {
      const rr = s.rpm / s.redline;
      if (rr > 0.94 && s.gear < s.gearCount) { s.gear++; s.clutch = 0.22; audio.shiftBlip(true); }
      else if (rr < 0.34 && s.gear > 1 && s.speed < s.topSpeed * 0.55) { s.gear--; s.clutch = 0.16; }
    }
    if (s.gear === 0 && Math.abs(s.speed) < 0.6 && input.throttle > 0.35) {
      s.gear = 1; s.clutch = 0.18;
    }

    // ---------- steering ----------
    const vAbs = Math.abs(s.speed);
    const speedFactor = 1 / (1 + Math.pow(vAbs / 23, 1.65));
    const targetSteer = input.steer * s.maxSteer * (0.3 + 0.7 * speedFactor);
    s.steerAngle = AD.damp(s.steerAngle, targetSteer, 9, dt);

    // ---------- rpm ----------
    const ratio = s.ratio(s.gear);
    const totalRatio = Math.abs(ratio) * s.finalDrive;
    let targetRpm;
    if (s.gear === 0 || totalRatio === 0) {
      targetRpm = s.idle + input.throttle * (s.redline - s.idle) * 0.95;
    } else {
      targetRpm = (vAbs / (2 * Math.PI * s.wheelRadius)) * totalRatio * 60;
      targetRpm = Math.max(s.idle, targetRpm);
      if (s.clutch > 0) targetRpm = Math.max(targetRpm, s.idle + input.throttle * s.redline * 0.35);
    }
    s.rpm = AD.damp(s.rpm, Math.min(targetRpm, s.redline * 1.02), s.gear === 0 ? 3.4 : 11, dt);
    const limiter = s.rpm > s.redline ? 0.25 : 1;
    const rpmFrac = AD.clamp(s.rpm / s.redline, 0, 1);

    // ---------- nitro ----------
    const wantsNitro = input.nitro && s.nitro > 0.01 && s.fuel > 0.01;
    s.nitroActive = wantsNitro;
    if (wantsNitro) s.nitro = Math.max(0, s.nitro - dt * 0.3);
    else s.nitro = Math.min(1, s.nitro + dt * 0.028);
    if (s.drifting) s.nitro = Math.min(1, s.nitro + dt * 0.055);

    // ---------- drive / brake ----------
    const health = 1 - s.damage * 0.55;
    const fuelCut = s.fuel <= 0.005 ? 0.12 : 1;
    let driveForce = 0;
    if (ratio !== 0 && s.clutch <= 0) {
      const torque = s.torqueAt(s.rpm) * limiter * health * fuelCut;
      driveForce = (torque * Math.abs(ratio) * s.finalDrive / s.wheelRadius) * input.throttle;
      if (s.gear === -1) driveForce = -Math.abs(driveForce) * 0.5;
      const traction = s.gripBase * gripMul * 9.81 * s.mass * 0.56;
      driveForce = AD.clamp(driveForce, -traction, traction);
      if (s.rpm > s.redline * 0.985) driveForce *= 0.3;
    }
    if (s.nitroActive) {
      driveForce += s.mass * 5.8 * s.spec.nitro * (s.gear === -1 ? -0.25 : 1);
    }

    let brakeF = 0;
    if (input.brake > 0.02) {
      if (s.speed > 0.25) brakeF = -s.brakeForce * input.brake;
      else if (s.speed < -0.25) brakeF = s.brakeForce * input.brake;
      else s.speed = 0;
    }
    if (input.handbrake) {
      brakeF += -Math.sign(s.speed || 1) * s.mass * 4.2;
      s.brakeHold = 0;
    }
    // engine braking
    if (ratio !== 0 && input.throttle < 0.05 && s.clutch <= 0 && vAbs > 0.6) {
      brakeF += -Math.sign(s.speed) * (s.rpm / s.redline) * 1300;
    }

    // ---------- resistances ----------
    const drag = -Math.sign(s.speed) * (0.5 * 1.225 * 0.72) * s.speed * s.speed;
    const roll = -Math.sign(s.speed) * s.mass * 9.81 * 0.014;
    const accel = (driveForce + brakeF + drag + roll) / s.mass;
    s.speed += accel * dt;
    s.longG = accel / 9.81;

    // speed cap
    const cap = s.topSpeed * (s.nitroActive ? 1.17 : 1) * s.speedLimitMul;
    if (s.speed > cap) s.speed = AD.damp(s.speed, cap, 4, dt);
    if (s.speed < -11) s.speed = -11;
    if (Math.abs(s.speed) < 0.05 && input.throttle < 0.05 && input.brake > 0.05) s.speed = 0;

    // ---------- yaw / lateral slip ----------
    const yawRate = (s.speed / s.wheelbase) * Math.tan(s.steerAngle) * Math.min(1, vAbs / 3);
    s.heading += yawRate * dt * (input.handbrake ? 1.35 : 1);

    const fwd = new THREE.Vector3(Math.sin(s.heading), 0, -Math.cos(s.heading));
    const right = new THREE.Vector3(Math.cos(s.heading), 0, Math.sin(s.heading));
    const vLat = s.vel.dot(right);
    let gripK = s.gripBase * gripMul - Math.min(3.0, vAbs / 23);
    if (input.handbrake) gripK *= 0.32;
    if (env.wet) gripK *= 1 - env.wet * 0.22;
    const newVLat = vLat * Math.exp(-gripK * dt) - yawRate * s.speed * dt * 0.46;
    s.vel.copy(fwd).multiplyScalar(s.speed).addScaledVector(right, newVLat);
    s.pos.addScaledVector(s.vel, dt);
    s.latG = (newVLat - vLat) / (dt * 9.81 || 1);

    // drift scoring
    s.slip = Math.atan2(newVLat, Math.abs(s.speed) + 0.6);
    const wasDrifting = s.drifting;
    s.drifting = Math.abs(s.slip) > 0.11 && vAbs > 7 && (input.throttle > 0.15 || input.handbrake);
    if (s.drifting) {
      s.driftCombo = Math.min(5, s.driftCombo + dt * 0.5);
      s.driftScore += Math.abs(s.slip) * vAbs * dt * 26 * s.driftCombo;
    } else if (wasDrifting) {
      s.driftCombo = 1;
    }

    // ---------- fuel ----------
    const fuelUse = 0.0007 + input.throttle * 0.0021 + rpmFrac * 0.0008;
    s.fuel = Math.max(0, s.fuel - dt * fuelUse * (s.spec.cyl === 0 ? 0.55 : 1));

    // ---------- bounds ----------
    if (env.bounds) {
      const halfW = s.spec.W * 0.5;
      const left = env.bounds.left + halfW;
      const right = env.bounds.right - halfW;
      if (s.pos.x < left) { s.pos.x = left; s._scrape(1); }
      if (s.pos.x > right) { s.pos.x = right; s._scrape(-1); }
    }

    s.topSpeedKmh = Math.max(s.topSpeedKmh, Math.abs(s.getSpeedKmh()));
    s.distance = Math.max(s.distance, Math.max(0, -s.pos.z));

    s._updateVisuals(dt, input, env);
  }

  _scrape(dir) {
    const now = performance.now() / 1000;
    if (!this._lastScrape || now - this._lastScrape > 0.24) {
      this._lastScrape = now;
      this.damage = Math.min(1, this.damage + 0.009);
      if (typeof audio !== 'undefined') audio.crash(0.08);
    }
    this.speed *= 0.988;
    this.heading += dir * 0.045;
  }

  applyCrash(impact, pushX = 0, pushZ = 0) {
    const dmg = Math.min(0.5, 0.06 + impact / 130);
    this.damage = Math.min(1, this.damage + dmg);
    this.pos.x += pushX;
    this.pos.z += pushZ;
    this.speed *= 0.45;
    this.vel.multiplyScalar(0.4);
    this.heading += (Math.random() - 0.5) * 0.05 * Math.min(2, impact / 18);
    this._shakeT = 0.5;
  }

  addNitro(amount) { this.nitro = Math.min(1, this.nitro + amount); }
  addFuel(amount) { this.fuel = Math.min(1, this.fuel + amount); }
  repair(amount) { this.damage = Math.max(0, this.damage - amount); }

  _updateVisuals(dt, input, env) {
    const s = this;
    s.group.position.copy(s.pos);
    s.group.rotation.y = s.heading;

    // suspension body motion
    const targetRoll = -s.latG * 0.026;
    const targetPitch = -s.longG * 0.022;
    s._roll = AD.damp(s._roll, targetRoll, 7, dt);
    s._pitch = AD.damp(s._pitch, targetPitch, 7, dt);
    s._bounce = AD.damp(s._bounce, 0, 10, dt);
    if (Math.abs(s.speed) > 0.2) {
      const road = Math.sin(s.wheelSpin * 0.7) * 0.004 * Math.min(1, Math.abs(s.speed) / 20);
      s._bounce += road;
    }
    s.chassis.rotation.z = s._roll;
    s.chassis.rotation.x = s._pitch;
    s.chassis.position.y = s._bounce;

    // wheels
    s.wheelSpin += (s.speed / s.wheelRadius) * dt;
    for (const w of s.wheels) {
      w.userData.spin.rotation.x = -s.wheelSpin;
      if (w.userData.front) w.rotation.y = s.steerAngle;
    }

    // lights
    const braking = input.brake > 0.05 || input.handbrake;
    if (s.tailMat) s.tailMat.emissiveIntensity = braking ? 3.2 : 1.1;
    if (s.brakeLight) s.brakeLight.intensity = braking ? 2.2 : 0;
    const night = env && env.night ? env.night : 0;
    const lightsOn = night > 0.25;
    if (s.headMat) s.headMat.emissiveIntensity = lightsOn ? 2.6 : 1.4;
    if (s.beamMat) s.beamMat.opacity = lightsOn ? 0.075 : 0;
    if (s.headSpot) s.headSpot.intensity = lightsOn ? 2.2 : 0;

    // nitro flames
    if (s.flameMat) {
      const on = s.nitroActive;
      s.flameMat.opacity = on ? 0.75 : 0;
      for (const f of s.flames) {
        f.scale.y = on ? 0.8 + Math.random() * 0.5 : 0.2;
      }
    }

    // smoke
    s._updateSmoke(dt);
  }

  _updateSmoke(dt) {
    const N = this._smokeN;
    const pos = this.smoke.geometry.attributes.position.array;
    const col = this.smoke.geometry.attributes.color.array;
    const life = this._smokeLife, vel = this._smokeVel;
    const emitting = this.damage > 0.5 || this.drifting;
    this._smokeT -= dt;

    for (let i = 0; i < N; i++) {
      if (life[i] > 0) {
        life[i] -= dt;
        pos[i * 3] += vel[i * 3] * dt;
        pos[i * 3 + 1] += vel[i * 3 + 1] * dt;
        pos[i * 3 + 2] += vel[i * 3 + 2] * dt;
        vel[i * 3 + 1] += dt * 0.6;
        const t = Math.max(0, life[i] / 1.1);
        col[i * 3] = 0.5 * t + 0.2;
        col[i * 3 + 1] = 0.5 * t + 0.2;
        col[i * 3 + 2] = 0.5 * t + 0.2;
      } else {
        pos[i * 3 + 1] = -100;
      }
    }

    if (emitting && this._smokeT <= 0) {
      this._smokeT = 0.035;
      for (let k = 0; k < 2; k++) {
        let idx = -1;
        for (let i = 0; i < N; i++) if (life[i] <= 0) { idx = i; break; }
        if (idx < 0) break;
        const side = Math.random() < 0.5 ? -1 : 1;
        life[idx] = 1.1;
        pos[idx * 3] = side * this.spec.W * 0.45 + AD.rand(-0.15, 0.15);
        pos[idx * 3 + 1] = 0.15 + Math.random() * 0.2;
        pos[idx * 3 + 2] = this.spec.L * 0.32 + AD.rand(-0.3, 0.3);
        vel[idx * 3] = AD.rand(-0.5, 0.5);
        vel[idx * 3 + 1] = AD.rand(0.3, 1.0);
        vel[idx * 3 + 2] = AD.rand(-0.4, 0.4);
        const dark = this.damage > 0.5;
        col[idx * 3] = dark ? 0.25 : 0.8;
        col[idx * 3 + 1] = dark ? 0.25 : 0.8;
        col[idx * 3 + 2] = dark ? 0.28 : 0.8;
      }
      this.smoke.geometry.attributes.position.needsUpdate = true;
      this.smoke.geometry.attributes.color.needsUpdate = true;
    } else if (emitting) {
      this.smoke.geometry.attributes.position.needsUpdate = true;
      this.smoke.geometry.attributes.color.needsUpdate = true;
    }
  }

  getSpeedKmh() { return this.speed * 3.6; }

  reset(z = 0, x = 0) {
    this.pos.set(x, 0, z);
    this.vel.set(0, 0, 0);
    this.heading = 0;
    this.speed = 0;
    this.gear = 0;
    this.clutch = 0;
    this.rpm = this.idle || 1000;
    this.damage = 0;
    this.fuel = 1;
    this.nitro = 1;
    this.drifting = false;
    this.slip = 0;
    this.driftScore = 0;
    this.driftCombo = 1;
    this.topSpeedKmh = 0;
    this.overtakes = 0;
    this.distance = 0;
    this.steerAngle = 0;
    this._roll = 0; this._pitch = 0; this._bounce = 0;
    this.speedLimitMul = 1;
    this._smokeLife.fill(0);
    for (let i = 0; i < this._smokeN; i++) {
      this.smoke.geometry.attributes.position.array[i * 3 + 1] = -100;
    }
    this.smoke.geometry.attributes.position.needsUpdate = true;
  }
}
