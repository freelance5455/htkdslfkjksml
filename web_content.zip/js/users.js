window.pageInit=async function(u){
  if(!isDev(u)){ location.href='dashboard.html'; return; }
  const c=document.querySelector('#content');
  let users=[],services=[],tasks=[],stock=[];
  const roles=['Agent','Superviseur','Développeur'];
  c.innerHTML=`
  <div class="hero"><div><h2>⚙️ Administration Développeur</h2><div>Centre de contrôle de WONDER SHIFT : utilisateurs, identifiants, rôles, services, tâches, tarifs, stock et configuration.</div></div></div>
  <div class="tabs admin-tabs">
    <button class="tab active" data-tab="usersTab">👥 Agents & accès</button>
    <button class="tab" data-tab="servicesTab">🧩 Services</button>
    <button class="tab" data-tab="tasksTab">💰 Tâches & tarifs</button>
    <button class="tab" data-tab="stockTab">📦 Stock</button>
    <button class="tab" data-tab="securityTab">🔐 Sécurité & audit</button>
  </div>
  <section id="usersTab" class="admin-tab active">
    <div class="section-head"><div><h2>Agents et utilisateurs</h2><p class="muted">Le Développeur peut créer, modifier, désactiver et réinitialiser les accès.</p></div><button class="primary" id="addUser">＋ Nouvel utilisateur</button></div>
    <div id="userList" class="admin-list"></div>
  </section>
  <section id="servicesTab" class="admin-tab">
    <div class="section-head"><div><h2>Services</h2><p class="muted">Ajoute les services de ta bureautique et active/désactive ceux qui sont proposés.</p></div><button class="primary" id="addService">＋ Ajouter un service</button></div><div id="serviceList" class="admin-list"></div>
  </section>
  <section id="tasksTab" class="admin-tab">
    <div class="section-head"><div><h2>Tâches et tarifs</h2><p class="muted">Chaque tâche peut avoir son prix par défaut en FC et être activée ou désactivée.</p></div><button class="primary" id="addTask">＋ Ajouter une tâche</button></div><div id="taskList" class="admin-list"></div>
  </section>
  <section id="stockTab" class="admin-tab">
    <div class="section-head"><div><h2>Catalogue stock</h2><p class="muted">Création, modification, seuil d'alerte et unité des consommables.</p></div><button class="primary" id="addStock">＋ Ajouter un consommable</button></div><div id="stockList" class="admin-list"></div>
  </section>
  <section id="securityTab" class="admin-tab">
    <div class="grid-3"><div class="card"><h3>Protection du compte</h3><p>Le compte Développeur principal ne peut pas être désactivé depuis cette page.</p><button class="secondary" id="changeMyPassword">Changer mon mot de passe</button></div><div class="card"><h3>Journal d'audit</h3><p class="muted">Historique des connexions et actions d'administration.</p><button class="secondary" id="auditExport">Exporter le journal</button></div><div class="card"><h3>Configuration</h3><p class="muted">Les réglages globaux sont accessibles depuis Paramètres.</p><button class="secondary" onclick="location.href='settings.html#developer'">Ouvrir les paramètres développeur</button></div></div>
    <div class="card section"><div class="section-head"><h3>Dernières actions</h3><button class="secondary" id="refreshAudit">Actualiser</button></div><div id="auditList"></div></div>
  </section>`;

  c.querySelectorAll('[data-tab]').forEach(btn=>btn.onclick=()=>{c.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));c.querySelectorAll('.admin-tab').forEach(x=>x.classList.remove('active'));btn.classList.add('active');document.getElementById(btn.dataset.tab).classList.add('active');history.replaceState(null,'','#'+btn.dataset.tab)});
  if(location.hash){const b=c.querySelector(`[data-tab="${location.hash.slice(1)}"]`);if(b)b.click()}

  const audit=async(action,meta={})=>dbPut('audit',{id:WS.uid('AUD'),action,userId:u.id,createdAt:Date.now(),device:navigator.userAgent.slice(0,100),meta});
  const esc=WS.esc;

  async function draw(){
    users=await dbAll('users');services=await dbAll('services');tasks=await dbAll('tasks');stock=await dbAll('stock');
    userList.innerHTML=users.map(x=>`<div class="admin-row"><div class="avatar">${x.photo?`<img src="${esc(x.photo)}" alt="">`:esc(WS.initials(x.name))}</div><div class="admin-main"><b>${esc(x.name)}</b><div class="muted">Identifiant : <strong>${esc(x.id)}</strong> · ${esc(x.role)} · ${x.active?'Actif':'Désactivé'}</div></div><div class="row-actions"><button class="secondary" data-edit-user="${esc(x.id)}">Modifier</button><button class="secondary" data-photo-user="${esc(x.id)}">Photo</button><button class="secondary" data-pass-user="${esc(x.id)}">Mot de passe</button><button class="${x.active?'warn':'secondary'}" data-toggle-user="${esc(x.id)}">${x.active?'Désactiver':'Activer'}</button>${x.id!=='DEVELOPPEUR'?`<button class="danger" data-delete-user="${esc(x.id)}">Supprimer</button>`:''}</div></div>`).join('') || '<div class="empty">Aucun utilisateur.</div>';
    serviceList.innerHTML=services.map(x=>`<div class="admin-row"><div class="icon-bubble">🧩</div><div class="admin-main"><b>${esc(x.name)}</b><div class="muted">${x.builtin?'Service initial':'Ajouté par le Développeur'} · ${x.active?'Actif':'Désactivé'}</div></div><div class="row-actions"><button class="secondary" data-edit-service="${esc(x.id)}">Modifier</button><button class="${x.active?'warn':'secondary'}" data-toggle-service="${esc(x.id)}">${x.active?'Désactiver':'Activer'}</button><button class="danger" data-delete-service="${esc(x.id)}">Supprimer</button></div></div>`).join('') || '<div class="empty">Aucun service.</div>';
    taskList.innerHTML=tasks.map(x=>`<div class="admin-row"><div class="icon-bubble">💰</div><div class="admin-main"><b>${esc(x.name)}</b><div class="muted">Prix par défaut : <strong>${WS.money(x.price)}</strong> · ${x.active?'Actif':'Désactivé'}</div></div><div class="row-actions"><button class="secondary" data-edit-task="${esc(x.id)}">Modifier</button><button class="${x.active?'warn':'secondary'}" data-toggle-task="${esc(x.id)}">${x.active?'Désactiver':'Activer'}</button><button class="danger" data-delete-task="${esc(x.id)}">Supprimer</button></div></div>`).join('') || '<div class="empty">Aucune tâche.</div>';
    stockList.innerHTML=stock.map(x=>`<div class="admin-row"><div class="icon-bubble">📦</div><div class="admin-main"><b>${esc(x.name)}</b><div class="muted">Stock initial ${x.initial} · seuil ${x.alert} · unité ${esc(x.unit||'unités')}</div></div><div class="row-actions"><button class="secondary" data-edit-stock="${esc(x.id)}">Modifier</button><button class="danger" data-delete-stock="${esc(x.id)}">Supprimer</button></div></div>`).join('') || '<div class="empty">Aucun consommable.</div>';
    bind(); await drawAudit();
  }
  function bind(){
    c.querySelectorAll('[data-edit-user]').forEach(b=>b.onclick=()=>editUser(b.dataset.editUser));
    c.querySelectorAll('[data-pass-user]').forEach(b=>b.onclick=()=>changePassword(b.dataset.passUser));
    c.querySelectorAll('[data-photo-user]').forEach(b=>b.onclick=()=>changePhoto(b.dataset.photoUser));
    c.querySelectorAll('[data-toggle-user]').forEach(b=>b.onclick=async()=>{const x=users.find(z=>z.id===b.dataset.toggleUser);if(!x)return;if(x.id==='DEVELOPPEUR')return WS.toast('Le compte Développeur principal est protégé.');x.active=!x.active;await dbPut('users',x);await audit('user_status',{target:x.id,active:x.active});WS.toast(x.active?'Compte activé':'Compte désactivé');draw()});
    c.querySelectorAll('[data-delete-user]').forEach(b=>b.onclick=async()=>{const x=users.find(z=>z.id===b.dataset.deleteUser);if(!x||!confirm(`Supprimer définitivement l'utilisateur ${x.name} ?`))return;await dbDelete('users',x.id);await audit('user_deleted',{target:x.id});draw()});
    c.querySelectorAll('[data-edit-service]').forEach(b=>b.onclick=()=>editService(b.dataset.editService));
    c.querySelectorAll('[data-toggle-service]').forEach(b=>b.onclick=async()=>{const x=services.find(z=>z.id===b.dataset.toggleService);x.active=!x.active;await dbPut('services',x);await audit('service_status',{target:x.id,active:x.active});draw()});
    c.querySelectorAll('[data-delete-service]').forEach(b=>b.onclick=async()=>{const x=services.find(z=>z.id===b.dataset.deleteService);if(!x||!confirm(`Supprimer le service « ${x.name} » ?`))return;await dbDelete('services',x.id);await audit('service_deleted',{target:x.id});draw()});
    c.querySelectorAll('[data-edit-task]').forEach(b=>b.onclick=()=>editTask(b.dataset.editTask));
    c.querySelectorAll('[data-toggle-task]').forEach(b=>b.onclick=async()=>{const x=tasks.find(z=>z.id===b.dataset.toggleTask);x.active=!x.active;await dbPut('tasks',x);await audit('task_status',{target:x.id,active:x.active});draw()});
    c.querySelectorAll('[data-delete-task]').forEach(b=>b.onclick=async()=>{const x=tasks.find(z=>z.id===b.dataset.deleteTask);if(!x||!confirm(`Supprimer la tâche « ${x.name} » ?`))return;await dbDelete('tasks',x.id);await audit('task_deleted',{target:x.id});draw()});
    c.querySelectorAll('[data-edit-stock]').forEach(b=>b.onclick=()=>editStock(b.dataset.editStock));
    c.querySelectorAll('[data-delete-stock]').forEach(b=>b.onclick=async()=>{const x=stock.find(z=>z.id===b.dataset.deleteStock);if(!x||!confirm(`Supprimer « ${x.name} » du catalogue ?`))return;await dbDelete('stock',x.id);await audit('stock_deleted',{target:x.id});draw()});
  }
  async function editUser(id){const x=users.find(z=>z.id===id);if(!x)return;const name=prompt('Nom complet',x.name);if(name===null)return;const newId=prompt('Identifiant de connexion',x.id)?.trim().toUpperCase();if(!newId)return;if(newId!==x.id&&users.some(z=>z.id===newId))return WS.toast('Cet identifiant est déjà utilisé.');const role=prompt('Rôle : Agent / Superviseur / Développeur',x.role);if(!roles.includes(role))return WS.toast('Rôle invalide.');if(x.id==='DEVELOPPEUR'&&newId!=='DEVELOPPEUR')return WS.toast('L’identifiant principal DEVELOPPEUR est protégé.');x.name=name.trim();x.id=newId;x.role=role;await dbPut('users',x);if(id!==newId)await dbDelete('users',id);await audit('user_updated',{target:newId});WS.toast('Utilisateur modifié');draw()}
  async function changePhoto(id){const x=users.find(z=>z.id===id);if(!x)return;const input=document.createElement('input');input.type='file';input.accept='image/*';input.onchange=async()=>{const f=input.files?.[0];if(!f)return;if(f.size>2*1024*1024)return WS.toast('Photo trop volumineuse (2 Mo maximum).');const r=new FileReader();r.onload=async()=>{x.photo=r.result;await dbPut('users',x);await audit('user_photo_updated',{target:id});WS.toast('Photo mise à jour');draw()};r.readAsDataURL(f)};input.click()}
  async function changePassword(id){const x=users.find(z=>z.id===id);if(!x)return;const p=prompt(`Nouveau mot de passe pour ${x.name}`);if(!p||p.length<6)return WS.toast('Mot de passe trop court (6 caractères minimum).');const p2=prompt('Confirmer le mot de passe');if(p!==p2)return WS.toast('Les mots de passe ne correspondent pas.');x.passwordHash=await sha256(p);await dbPut('users',x);await audit('password_changed',{target:id});WS.toast('Mot de passe modifié')}
  async function editService(id){const x=services.find(z=>z.id===id);const name=prompt('Nom du service',x.name);if(name===null||!name.trim())return;x.name=name.trim();await dbPut('services',x);await audit('service_updated',{target:id});draw()}
  async function editTask(id){const x=tasks.find(z=>z.id===id);const name=prompt('Nom de la tâche',x.name);if(name===null||!name.trim())return;const price=Number(prompt('Prix par défaut en FC',String(x.price)));if(!Number.isFinite(price)||price<0)return WS.toast('Prix invalide.');x.name=name.trim();x.price=price;await dbPut('tasks',x);await audit('task_updated',{target:id,price});draw()}
  async function editStock(id){const x=stock.find(z=>z.id===id);const name=prompt('Nom du consommable',x.name);if(name===null||!name.trim())return;const alert=Number(prompt('Seuil d’alerte',String(x.alert)));const unit=prompt('Unité',x.unit||'unités');if(!Number.isFinite(alert)||alert<0)return WS.toast('Seuil invalide.');x.name=name.trim();x.alert=alert;x.unit=unit||'unités';await dbPut('stock',x);await audit('stock_updated',{target:id});draw()}
  addUser.onclick=async()=>{const name=prompt('Nom complet');const id=prompt('Identifiant de connexion')?.trim().toUpperCase();const password=prompt('Mot de passe (6 caractères minimum)');const role=prompt('Rôle : Agent / Superviseur / Développeur','Agent');if(!name||!id||!password||password.length<6||!roles.includes(role))return WS.toast('Informations invalides.');if(users.some(x=>x.id===id))return WS.toast('Identifiant déjà utilisé.');await dbPut('users',{id,name,role,passwordHash:await sha256(password),active:true,photo:'',createdAt:Date.now(),updatedAt:Date.now()});await audit('user_created',{target:id,role});draw()};
  addService.onclick=async()=>{const name=prompt('Nom du nouveau service');if(!name?.trim())return;const id=WS.uid('SRV');await dbPut('services',{id,name:name.trim(),active:true,builtin:false,createdAt:Date.now()});await audit('service_created',{target:id});draw()};
  addTask.onclick=async()=>{const name=prompt('Nom de la nouvelle tâche');const price=Number(prompt('Prix par défaut en FC','0'));if(!name?.trim()||!Number.isFinite(price)||price<0)return;const id=WS.uid('TSK');await dbPut('tasks',{id,name:name.trim(),price,active:true,builtin:false,createdAt:Date.now()});await audit('task_created',{target:id,price});draw()};
  addStock.onclick=async()=>{const name=prompt('Nom du consommable');const initial=Number(prompt('Stock initial','0'));const alert=Number(prompt('Seuil d’alerte','1'));const unit=prompt('Unité','unités');if(!name?.trim()||!Number.isFinite(initial)||!Number.isFinite(alert))return;const id=WS.uid('STK');await dbPut('stock',{id,name:name.trim(),initial,entries:0,exits:0,alert,unit:unit||'unités',active:true,createdAt:Date.now()});await audit('stock_created',{target:id});draw()};
  changeMyPassword.onclick=()=>changePassword(u.id);
  auditExport.onclick=async()=>{const rows=await dbAll('audit');WS.json('wonder-shift-audit.json',rows);WS.toast('Journal exporté')};
  refreshAudit.onclick=drawAudit;
  async function drawAudit(){const rows=(await dbAll('audit')).sort((a,b)=>(b.createdAt||0)-(a.createdAt||0)).slice(0,30);const names=Object.fromEntries((await dbAll('users')).map(x=>[x.id,x.name]));const list=document.getElementById('auditList');if(!list)return;list.innerHTML=rows.map(x=>`<div class="setting"><div><b>${esc(x.action)}</b><div class="muted">${new Date(x.createdAt).toLocaleString('fr-FR')} · ${esc(names[x.userId]||x.userId||'Système')}</div></div><span class="badge">${esc(x.meta?.target||'')}</span></div>`).join('')||'<div class="empty">Aucune action enregistrée.</div>'}
  draw();
}
