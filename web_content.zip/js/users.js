window.pageInit=async function(u){
  if(!isDev(u)){ location.href='dashboard.html'; return; }
  const c=document.querySelector('#content');
  let users=[],services=[],tasks=[],stock=[];
  const roles=['Agent','Superviseur','Développeur'];
  c.innerHTML=`
  <div class="hero"><div><h2>⚙️ Administration Développeur</h2><div>Centre de contrôle de WONDER SHIFT : utilisateurs, identifiants, rôles, services, tâches, tarifs, stock et configuration.</div></div></div>
  <div class="tabs admin-tabs">
    <button class="tab active" data-tab="usersTab">👥 Agents & accès</button>
    <button class="tab" data-tab="servicesTab">🧩 Services</button>
    <button class="tab" data-tab="tasksTab">💰 Tâches & tarifs</button>
    <button class="tab" data-tab="stockTab">📦 Stock</button>
    <button class="tab" data-tab="securityTab">🔐 Sécurité & audit</button>
  </div>
  <section id="usersTab" class="admin-tab active">
    <div class="section-head"><div><h2>Agents et utilisateurs</h2><p class="muted">Les comptes de connexion sont gérés par Supabase Auth. Ici, le Développeur gère les profils et les rôles ; aucun mot de passe n’est stocké localement.</p></div><button class="secondary" id="refreshUsers">↻ Synchroniser les profils</button></div>
    <div class="actions" style="margin:12px 0"><button class="primary" id="addUser">＋ Ajouter un utilisateur</button></div><div id="userList" class="admin-list"></div>
  </section>
  <section id="servicesTab" class="admin-tab">
    <div class="section-head"><div><h2>Services</h2><p class="muted">Ajoute les services de ta bureautique et active/désactive ceux qui sont proposés.</p></div><button class="primary" id="addService">＋ Ajouter un service</button></div><div id="serviceList" class="admin-list"></div>
  </section>
  <section id="tasksTab" class="admin-tab">
    <div class="section-head"><div><h2>Tâches et tarifs</h2><p class="muted">Chaque tâche peut avoir son prix par défaut en FC et être activée ou désactivée.</p></div><button class="primary" id="addTask">＋ Ajouter une tâche</button></div><div id="taskList" class="admin-list"></div>
  </section>
  <section id="stockTab" class="admin-tab">
    <div class="section-head"><div><h2>Catalogue stock</h2><p class="muted">Création, modification, seuil d'alerte et unité des consommables.</p></div><button class="primary" id="addStock">＋ Ajouter un consommable</button></div><div id="stockList" class="admin-list"></div>
  </section>
  <section id="securityTab" class="admin-tab">
    <div class="grid-3"><div class="card"><h3>Protection du compte</h3><p>Le compte Développeur principal ne peut pas être désactivé depuis cette page.</p><button class="secondary" id="changeMyPassword">Changer mon mot de passe</button></div><div class="card"><h3>Journal d'audit</h3><p class="muted">Historique des connexions et actions d'administration.</p><button class="secondary" id="auditExport">Exporter le journal</button></div><div class="card"><h3>Configuration</h3><p class="muted">Les réglages globaux sont accessibles depuis Paramètres.</p><button class="secondary" onclick="location.href='settings.html#developer'">Ouvrir les paramètres développeur</button></div></div>
    <div class="card section"><div class="section-head"><h3>Dernières actions</h3><button class="secondary" id="refreshAudit">Actualiser</button></div><div id="auditList"></div></div>
  </section>`;

  c.querySelectorAll('[data-tab]').forEach(btn=>btn.onclick=()=>{c.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));c.querySelectorAll('.admin-tab').forEach(x=>x.classList.remove('active'));btn.classList.add('active');document.getElementById(btn.dataset.tab).classList.add('active');history.replaceState(null,'','#'+btn.dataset.tab)});
  if(location.hash){const b=c.querySelector(`[data-tab="${location.hash.slice(1)}"]`);if(b)b.click()}

  const audit=async(action,meta={})=>dbPut('audit',{id:WS.uid('AUD'),action,userId:u.id,createdAt:Date.now(),device:navigator.userAgent.slice(0,100),meta});
  const esc=WS.esc;

  async function draw(){
    users=await dbAll('profiles');services=await dbAll('services');tasks=await dbAll('tasks');stock=await dbAll('stock');
    userList.innerHTML=users.map(x=>{const active=(x.is_active??x.active)!==false;const name=x.full_name||x.name||'Utilisateur';return `<div class="admin-row"><div class="avatar">${esc(WS.initials(name))}</div><div class="admin-main"><b>${esc(name)}</b><div class="muted">UID : <strong>${esc(x.id)}</strong> · ${esc(x.role||'Agent')} · ${active?'Actif':'Désactivé'}</div></div></div>`}).join('') || '<div class="empty">Aucun profil synchronisé.</div>';
    serviceList.innerHTML=services.map(x=>`<div class="admin-row"><div class="icon-bubble">🧩</div><div class="admin-main"><b>${esc(x.name)}</b><div class="muted">${x.builtin?'Service initial':'Ajouté par le Développeur'} · ${x.active?'Actif':'Désactivé'}</div></div><div class="row-actions"><button class="secondary" data-edit-service="${esc(x.id)}">Modifier</button><button class="${x.active?'warn':'secondary'}" data-toggle-service="${esc(x.id)}">${x.active?'Désactiver':'Activer'}</button><button class="danger" data-delete-service="${esc(x.id)}">Supprimer</button></div></div>`).join('') || '<div class="empty">Aucun service.</div>';
    taskList.innerHTML=tasks.map(x=>`<div class="admin-row"><div class="icon-bubble">💰</div><div class="admin-main"><b>${esc(x.name)}</b><div class="muted">Prix par défaut : <strong>${WS.money(x.price)}</strong> · ${x.active?'Actif':'Désactivé'}</div></div><div class="row-actions"><button class="secondary" data-edit-task="${esc(x.id)}">Modifier</button><button class="${x.active?'warn':'secondary'}" data-toggle-task="${esc(x.id)}">${x.active?'Désactiver':'Activer'}</button><button class="danger" data-delete-task="${esc(x.id)}">Supprimer</button></div></div>`).join('') || '<div class="empty">Aucune tâche.</div>';
    stockList.innerHTML=stock.map(x=>`<div class="admin-row"><div class="icon-bubble">📦</div><div class="admin-main"><b>${esc(x.name)}</b><div class="muted">Stock initial ${x.initial} · seuil ${x.alert} · unité ${esc(x.unit||'unités')}</div></div><div class="row-actions"><button class="secondary" data-edit-stock="${esc(x.id)}">Modifier</button><button class="danger" data-delete-stock="${esc(x.id)}">Supprimer</button></div></div>`).join('') || '<div class="empty">Aucun consommable.</div>';
    bind(); await drawAudit();
  }
  function bind(){
    

    c.querySelectorAll('[data-edit-service]').forEach(b=>b.onclick=()=>editService(b.dataset.editService));
    c.querySelectorAll('[data-toggle-service]').forEach(b=>b.onclick=async()=>{const x=services.find(z=>z.id===b.dataset.toggleService);x.active=!x.active;x.updatedAt=Date.now();await dbPut('services',x);await queueSync('services',x.id);await audit('service_status',{target:x.id,active:x.active});draw()});
    c.querySelectorAll('[data-delete-service]').forEach(b=>b.onclick=async()=>{const x=services.find(z=>z.id===b.dataset.deleteService);if(!x||!confirm(`Supprimer le service « ${x.name} » ?`))return;x.active=false;x.updatedAt=Date.now();await dbPut('services',x);await queueSync('services',x.id);await audit('service_deactivated',{target:x.id});draw()});
    c.querySelectorAll('[data-edit-task]').forEach(b=>b.onclick=()=>editTask(b.dataset.editTask));
    c.querySelectorAll('[data-toggle-task]').forEach(b=>b.onclick=async()=>{const x=tasks.find(z=>z.id===b.dataset.toggleTask);x.active=!x.active;x.updatedAt=Date.now();await dbPut('tasks',x);await queueSync('tasks',x.id);await audit('task_status',{target:x.id,active:x.active});draw()});
    c.querySelectorAll('[data-delete-task]').forEach(b=>b.onclick=async()=>{const x=tasks.find(z=>z.id===b.dataset.deleteTask);if(!x||!confirm(`Supprimer la tâche « ${x.name} » ?`))return;x.active=false;x.updatedAt=Date.now();await dbPut('tasks',x);await queueSync('tasks',x.id);await audit('task_deactivated',{target:x.id});draw()});
    c.querySelectorAll('[data-edit-stock]').forEach(b=>b.onclick=()=>editStock(b.dataset.editStock));
    c.querySelectorAll('[data-delete-stock]').forEach(b=>b.onclick=async()=>{const x=stock.find(z=>z.id===b.dataset.deleteStock);if(!x||!confirm(`Supprimer « ${x.name} » du catalogue ?`))return;x.active=false;x.updatedAt=Date.now();await dbPut('stock',x);await queueSync('stock',x.id);await audit('stock_deactivated',{target:x.id});draw()});
  }


  async function editService(id){const x=services.find(z=>z.id===id);const name=prompt('Nom du service',x.name);if(name===null||!name.trim())return;x.name=name.trim();x.updatedAt=Date.now();await dbPut('services',x);await queueSync('services',x.id);await audit('service_updated',{target:id});draw()}
  async function editTask(id){const x=tasks.find(z=>z.id===id);const name=prompt('Nom de la tâche',x.name);if(name===null||!name.trim())return;const price=Number(prompt('Prix par défaut en FC',String(x.price)));if(!Number.isFinite(price)||price<0)return WS.toast('Prix invalide.');x.name=name.trim();x.price=price;x.updatedAt=Date.now();await dbPut('tasks',x);await queueSync('tasks',x.id);await audit('task_updated',{target:id,price});draw()}
  async function editStock(id){const x=stock.find(z=>z.id===id);const name=prompt('Nom du consommable',x.name);if(name===null||!name.trim())return;const alert=Number(prompt('Seuil d’alerte',String(x.alert)));const unit=prompt('Unité',x.unit||'unités');if(!Number.isFinite(alert)||alert<0)return WS.toast('Seuil invalide.');x.name=name.trim();x.alert=alert;x.unit=unit||'unités';x.updatedAt=Date.now();await dbPut('stock',x);await queueSync('stock',x.id);await audit('stock_updated',{target:id});draw()}
  document.getElementById('addUser').onclick=async()=>{
    if(!navigator.onLine)return WS.toast('Une connexion Internet est nécessaire pour créer un compte.');
    const name=prompt('Nom complet du nouvel utilisateur'); if(!name?.trim())return;
    const email=prompt('Adresse e-mail de connexion'); if(!email?.trim())return;
    const role=prompt('Rôle : Agent, Superviseur ou Développeur','Agent');
    if(!roles.includes(role))return WS.toast('Rôle invalide.');
    const c2=await sb(); if(!c2)return WS.toast('Supabase indisponible.');
    const {data,error}=await c2.functions.invoke('manage-user',{body:{action:'invite',name:name.trim(),email:email.trim(),role}});
    if(error||data?.error)return WS.toast(data?.error||error?.message||'Création impossible.');
    await syncNow(true); await draw(); WS.toast('Invitation envoyée. L’utilisateur pourra définir son mot de passe depuis son e-mail.');
  };
  refreshUsers.onclick=()=>syncNow();
  addService.onclick=async()=>{const name=prompt('Nom du nouveau service');if(!name?.trim())return;const id=WS.uid('SRV');await dbPut('services',{id,name:name.trim(),active:true,builtin:false,createdAt:Date.now(),updatedAt:Date.now()});await queueSync('services',id);await audit('service_created',{target:id});draw()};
  addTask.onclick=async()=>{const name=prompt('Nom de la nouvelle tâche');const price=Number(prompt('Prix par défaut en FC','0'));if(!name?.trim()||!Number.isFinite(price)||price<0)return;const id=WS.uid('TSK');await dbPut('tasks',{id,name:name.trim(),price,active:true,builtin:false,createdAt:Date.now(),updatedAt:Date.now()});await queueSync('tasks',id);await audit('task_created',{target:id,price});draw()};
  addStock.onclick=async()=>{const name=prompt('Nom du consommable');const initial=Number(prompt('Stock initial','0'));const alert=Number(prompt('Seuil d’alerte','1'));const unit=prompt('Unité','unités');if(!name?.trim()||!Number.isFinite(initial)||!Number.isFinite(alert))return;const id=WS.uid('STK');await dbPut('stock',{id,name:name.trim(),initial,entries:0,exits:0,alert,unit:unit||'unités',active:true,createdAt:Date.now(),updatedAt:Date.now()});await queueSync('stock',id);await audit('stock_created',{target:id});draw()};
  changeMyPassword.onclick=async()=>{const c2=await sb();if(!c2||!navigator.onLine)return WS.toast('Une connexion Internet est nécessaire pour modifier le mot de passe.');const {error}=await c2.auth.resetPasswordForEmail(u.email,{redirectTo:location.origin+'/index.html'});WS.toast(error?'Impossible d’envoyer le lien.':'Lien de modification envoyé par e-mail.');};
  auditExport.onclick=async()=>{const rows=await dbAll('audit');WS.json('wonder-shift-audit.json',rows);WS.toast('Journal exporté')};
  refreshAudit.onclick=drawAudit;
  async function drawAudit(){const rows=(await dbAll('audit')).sort((a,b)=>(b.createdAt||0)-(a.createdAt||0)).slice(0,30);const names=Object.fromEntries((await dbAll('profiles')).map(x=>[x.id,x.full_name||x.name]));const list=document.getElementById('auditList');if(!list)return;list.innerHTML=rows.map(x=>`<div class="setting"><div><b>${esc(x.action)}</b><div class="muted">${new Date(x.createdAt).toLocaleString('fr-FR')} · ${esc(names[x.userId]||x.userId||'Système')}</div></div><span class="badge">${esc(x.meta?.target||'')}</span></div>`).join('')||'<div class="empty">Aucune action enregistrée.</div>'}
  draw();
}