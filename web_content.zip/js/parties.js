/**
 * Panchal Business Manager - Party Management Module
 * Customers, Suppliers, Billing & Shipping Addresses, Notes, Local Attachments,
 * GSTIN, Credit Limits & Date-Filtered Party Statement (Print PDF / CSV).
 */
(function (global) {
  "use strict";

  const I18N = {
    en: {
      addPartyBtn: "+ Add Party",
      searchPlaceholder: "Search name, phone or GSTIN...",
      filterAll: "All",
      filterCustomer: "Customers",
      filterSupplier: "Suppliers",
      filterReceivable: "Receivable",
      filterPayable: "Payable",
      emptyTitle: "No parties found",
      emptyDesc: "Add your first customer or supplier to start tracking balances and ledgers.",
      typeCustomer: "Customer",
      typeSupplier: "Supplier",
      typeBoth: "Customer & Supplier",
      balReceivable: "Receivable (Dr)",
      balPayable: "Payable (Cr)",
      balSettled: "Settled",
      creditExceeded: "Credit Limit Exceeded",
      creditLimitLabel: "Limit",
      btnLedger: "Statement / Ledger",
      btnPayment: "+ Payment",
      btnEdit: "Edit",
      btnDelete: "Delete",
      modalAddParty: "Add New Party",
      modalEditParty: "Edit Party",
      fieldName: "Party / Firm Name *",
      fieldType: "Party Type",
      fieldPhone: "Phone Number (10 digits, optional)",
      fieldGstin: "GSTIN (15 characters, optional)",
      fieldAddress: "Billing Address (optional)",
      fieldShippingAddress: "Shipping / Site Address (optional)",
      fieldPartyNotes: "Party Notes (optional)",
      fieldAttachments: "Attachments (ID / Visiting Card / Agreement)",
      addAttachBtn: "+ Attach File / Photo",
      fieldOpeningBal: "Opening Balance (₹)",
      fieldOpeningType: "Opening Balance Type",
      optOpeningDr: "To Receive (Receivable / Dr)",
      optOpeningCr: "To Pay (Payable / Cr)",
      fieldCreditLimit: "Credit Limit (₹, 0 = No Limit)",
      errNameReq: "Party name must be at least 2 characters.",
      errPhoneInvalid: "Phone number must be 10 digits.",
      errGstinInvalid: "Enter a valid 15-character GSTIN.",
      errAmountInvalid: "Enter a valid amount greater than 0.",
      confirmDeleteTitle: "Delete Party?",
      confirmDeleteMsg: "This will delete this party and its payment entries from this business.",
      toastSaved: "Party saved.",
      toastDeleted: "Party deleted.",
      modalPaymentTitle: "Record Payment",
      fieldPayType: "Transaction Type",
      optReceipt: "Payment Received (In)",
      optPayment: "Payment Paid (Out)",
      fieldAmount: "Amount (₹) *",
      fieldDate: "Date *",
      fieldMode: "Payment Mode",
      modeCash: "Cash",
      modeUpi: "UPI",
      modeBank: "Bank Transfer",
      modeCheque: "Cheque",
      fieldNotes: "Notes / Reference (optional)",
      toastPaySaved: "Payment recorded in ledger.",
      ledgerTitle: "Party Statement & Ledger",
      openingEntry: "Opening Balance",
      broughtForwardEntry: "Brought Forward Balance",
      closingBalance: "Closing Balance",
      fromDateLabel: "From",
      toDateLabel: "To",
      printStmtBtn: "Print / PDF",
      exportCsvBtn: "Export CSV",
      noEntriesMsg: "No transactions in this period.",
      confirmDelEntryTitle: "Delete Entry?",
      confirmDelEntryMsg: "Remove this payment entry from the party ledger?",
      toastEntryDeleted: "Entry removed.",
      saveBtn: "Save",
      cancelBtn: "Cancel",
      deleteBtn: "Delete"
    },
    hi: {
      addPartyBtn: "+ नई पार्टी जोड़ें",
      searchPlaceholder: "नाम, फ़ोन या GSTIN से खोजें...",
      filterAll: "सभी",
      filterCustomer: "ग्राहक",
      filterSupplier: "सप्लायर",
      filterReceivable: "लेना बाकी",
      filterPayable: "देना बाकी",
      emptyTitle: "कोई पार्टी नहीं मिली",
      emptyDesc: "हिसाब और खाता शुरू करने के लिए पहला ग्राहक या सप्लायर जोड़ें।",
      typeCustomer: "ग्राहक (Customer)",
      typeSupplier: "सप्लायर (Supplier)",
      typeBoth: "ग्राहक व सप्लायर दोनों",
      balReceivable: "लेना है (Dr)",
      balPayable: "देना है (Cr)",
      balSettled: "हिसाब बराबर",
      creditExceeded: "क्रेडिट लिमिट पार हो गई",
      creditLimitLabel: "लिमिट",
      btnLedger: "स्टेटमेंट / खाता",
      btnPayment: "+ पेमेंट",
      btnEdit: "बदलें",
      btnDelete: "हटाएँ",
      modalAddParty: "नई पार्टी जोड़ें",
      modalEditParty: "पार्टी जानकारी बदलें",
      fieldName: "पार्टी / फ़र्म का नाम *",
      fieldType: "पार्टी का प्रकार",
      fieldPhone: "फ़ोन नंबर (10 अंक, वैकल्पिक)",
      fieldGstin: "GSTIN (15 अंक, वैकल्पिक)",
      fieldAddress: "बिलिंग पता (वैकल्पिक)",
      fieldShippingAddress: "शिपिंग / साइट का पता (वैकल्पिक)",
      fieldPartyNotes: "पार्टी नोट्स (वैकल्पिक)",
      fieldAttachments: "दस्तावेज़ / फ़ोटो अटैचमेंट",
      addAttachBtn: "+ फ़ाइल / फ़ोटो जोड़ें",
      fieldOpeningBal: "शुरुआती बकाया / Opening Balance (₹)",
      fieldOpeningType: "बकाया का प्रकार",
      optOpeningDr: "लेना है (Receivable / Dr)",
      optOpeningCr: "देना है (Payable / Cr)",
      fieldCreditLimit: "क्रेडिट लिमिट (₹, 0 = कोई सीमा नहीं)",
      errNameReq: "पार्टी का नाम कम से कम 2 अक्षर का होना चाहिए।",
      errPhoneInvalid: "फ़ोन नंबर 10 अंकों का होना चाहिए।",
      errGstinInvalid: "सही 15-अंकीय GSTIN डालें।",
      errAmountInvalid: "0 से बड़ी सही राशि डालें।",
      confirmDeleteTitle: "पार्टी हटाएँ?",
      confirmDeleteMsg: "इस पार्टी और इसके पेमेंट रिकॉर्ड इस बिज़नेस से हट जाएँगे।",
      toastSaved: "पार्टी सेव हो गई।",
      toastDeleted: "पार्टी हटा दी गई।",
      modalPaymentTitle: "पेमेंट दर्ज करें",
      fieldPayType: "लेन-देन का प्रकार",
      optReceipt: "पेमेंट मिला (Payment In)",
      optPayment: "पेमेंट दिया (Payment Out)",
      fieldAmount: "राशि (₹) *",
      fieldDate: "तारीख़ *",
      fieldMode: "पेमेंट का माध्यम",
      modeCash: "नकद (Cash)",
      modeUpi: "UPI",
      modeBank: "बैंक ट्रांसफ़र",
      modeCheque: "चेक",
      fieldNotes: "विवरण / रेफ़रेंस (वैकल्पिक)",
      toastPaySaved: "पेमेंट खाते में जुड़ गया।",
      ledgerTitle: "पार्टी स्टेटमेंट व खाता",
      openingEntry: "शुरुआती बकाया (Opening)",
      broughtForwardEntry: "पिछला बकाया (B/F)",
      closingBalance: "अंतिम बकाया (Closing)",
      fromDateLabel: "तारीख़ से",
      toDateLabel: "तारीख़ तक",
      printStmtBtn: "प्रिंट / PDF",
      exportCsvBtn: "CSV डाउनलोड",
      noEntriesMsg: "इस अवधि में कोई लेन-देन नहीं मिला।",
      confirmDelEntryTitle: "एंट्री हटाएँ?",
      confirmDelEntryMsg: "क्या आप इस पेमेंट एंट्री को खाते से हटाना चाहते हैं?",
      toastEntryDeleted: "एंट्री हटा दी गई।",
      saveBtn: "सेव करें",
      cancelBtn: "रद्द करें",
      deleteBtn: "हटाएँ"
    }
  };

  const viewState = {
    search: "",
    filter: "all",
    parties: [],
    vouchers: []
  };

  function tr(key) {
    const lang = global.PBM_APP.getLang();
    return (I18N[lang] && I18N[lang][key]) || I18N.en[key] || key;
  }

  function getSignedVoucherDelta(voucher) {
    if (!voucher || voucher.status === "VOID") return 0;
    const amt = Number(voucher.grandTotal != null ? voucher.grandTotal : voucher.amount) || 0;
    switch (voucher.voucherType) {
      case "SALE_INVOICE":
      case "BILL_OF_SUPPLY":
      case "DEBIT_NOTE":
      case "PAYMENT":
        return amt;
      case "PURCHASE_BILL":
      case "CREDIT_NOTE":
      case "RECEIPT":
        return -amt;
      case "EXPENSE_VOUCHER": {
        const unpaid = Math.max(0, amt - (Number(voucher.paidAmount) || 0));
        return unpaid > 0 ? -unpaid : 0;
      }
      default:
        return 0;
    }
  }

  function computePartyBalance(party, partyVouchers) {
    const opening = Number(party.openingBalance) || 0;
    let balance = party.openingType === "PAYABLE" ? -opening : opening;

    partyVouchers.forEach(function (v) {
      balance += getSignedVoucherDelta(v);
    });

    return Math.round(balance * 100) / 100;
  }

  function calculateTotalsForBusiness(parties, vouchers) {
    const voucherMap = {};
    vouchers.forEach(function (v) {
      if (!v.partyId || v.status === "VOID") return;
      if (!voucherMap[v.partyId]) voucherMap[v.partyId] = [];
      voucherMap[v.partyId].push(v);
    });

    let totalReceivable = 0;
    let totalPayable = 0;
    const balanceByPartyId = {};

    parties.forEach(function (party) {
      const bal = computePartyBalance(party, voucherMap[party.id] || []);
      balanceByPartyId[party.id] = bal;
      if (bal > 0) {
        totalReceivable += bal;
      } else if (bal < 0) {
        totalPayable += Math.abs(bal);
      }
    });

    return {
      totalReceivable: Math.round(totalReceivable * 100) / 100,
      totalPayable: Math.round(totalPayable * 100) / 100,
      balanceByPartyId: balanceByPartyId,
      voucherMap: voucherMap
    };
  }

  function getBusinessTotals(businessId) {
    return Promise.all([
      global.PBM_DB.getByBusiness("parties", businessId),
      global.PBM_DB.getByBusiness("vouchers", businessId)
    ]).then(function (results) {
      return calculateTotalsForBusiness(results[0], results[1]);
    });
  }

  function formatSignedBalanceText(bal) {
    if (bal > 0.009) {
      return {
        amountText: global.PBM_APP.formatCurrency(bal),
        label: tr("balReceivable"),
        cls: "text-receivable"
      };
    }
    if (bal < -0.009) {
      return {
        amountText: global.PBM_APP.formatCurrency(Math.abs(bal)),
        label: tr("balPayable"),
        cls: "text-payable"
      };
    }
    return {
      amountText: global.PBM_APP.formatCurrency(0),
      label: tr("balSettled"),
      cls: "text-muted"
    };
  }

  function getPartyTypeLabel(type) {
    if (type === "SUPPLIER") return tr("typeSupplier");
    if (type === "BOTH") return tr("typeBoth");
    return tr("typeCustomer");
  }

  function readAttachmentFile(file) {
    return new Promise(function (resolve, reject) {
      if (file.type && file.type.indexOf("image/") === 0) {
        const reader = new FileReader();
        reader.onload = function (ev) {
          const img = new Image();
          img.onload = function () {
            const maxDim = 900;
            let w = img.width;
            let h = img.height;
            if (w > maxDim || h > maxDim) {
              const scale = Math.min(maxDim / w, maxDim / h);
              w = Math.round(w * scale);
              h = Math.round(h * scale);
            }
            const canvas = document.createElement("canvas");
            canvas.width = w;
            canvas.height = h;
            canvas.getContext("2d").drawImage(img, 0, 0, w, h);
            resolve({ name: file.name, type: "image/jpeg", dataUrl: canvas.toDataURL("image/jpeg", 0.72) });
          };
          img.onerror = function () {
            resolve({ name: file.name, type: file.type, dataUrl: ev.target.result });
          };
          img.src = ev.target.result;
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
      } else {
        if (file.size > 512 * 1024) {
          reject(new Error("File too large (max 500KB for non-image attachments)."));
          return;
        }
        const reader = new FileReader();
        reader.onload = function (ev) {
          resolve({ name: file.name, type: file.type || "application/octet-stream", dataUrl: ev.target.result });
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
      }
    });
  }

  function openPartyFormModal(existingParty) {
    const app = global.PBM_APP;
    const isEdit = Boolean(existingParty);
    const p = existingParty
      ? JSON.parse(JSON.stringify(existingParty))
      : {
          name: "",
          type: "CUSTOMER",
          phone: "",
          gstin: "",
          address: "",
          shippingAddress: "",
          notes: "",
          attachments: [],
          openingBalance: 0,
          openingType: "RECEIVABLE",
          creditLimit: 0
        };
    if (!Array.isArray(p.attachments)) p.attachments = [];

    const html = `
      <form id="partyForm" class="form-grid" novalidate>
        <div id="partyFormError" class="form-error hidden"></div>
        <div class="form-group">
          <label class="form-label" for="partyNameInput">${tr("fieldName")}</label>
          <input id="partyNameInput" class="form-input" type="text" required value="${app.escapeHtml(p.name)}" />
        </div>
        <div class="form-group">
          <label class="form-label" for="partyTypeSelect">${tr("fieldType")}</label>
          <select id="partyTypeSelect" class="form-select">
            <option value="CUSTOMER" ${p.type === "CUSTOMER" ? "selected" : ""}>${tr("typeCustomer")}</option>
            <option value="SUPPLIER" ${p.type === "SUPPLIER" ? "selected" : ""}>${tr("typeSupplier")}</option>
            <option value="BOTH" ${p.type === "BOTH" ? "selected" : ""}>${tr("typeBoth")}</option>
          </select>
        </div>
        <div class="form-row-2">
          <div class="form-group">
            <label class="form-label" for="partyPhoneInput">${tr("fieldPhone")}</label>
            <input id="partyPhoneInput" class="form-input" type="tel" maxlength="10" value="${app.escapeHtml(p.phone)}" />
          </div>
          <div class="form-group">
            <label class="form-label" for="partyGstinInput">${tr("fieldGstin")}</label>
            <input id="partyGstinInput" class="form-input" type="text" maxlength="15" value="${app.escapeHtml(p.gstin)}" />
          </div>
        </div>
        <div class="form-row-2">
          <div class="form-group">
            <label class="form-label" for="partyOpeningBalInput">${tr("fieldOpeningBal")}</label>
            <input id="partyOpeningBalInput" class="form-input" type="number" min="0" step="0.01" value="${Number(p.openingBalance) || 0}" />
          </div>
          <div class="form-group">
            <label class="form-label" for="partyOpeningTypeSelect">${tr("fieldOpeningType")}</label>
            <select id="partyOpeningTypeSelect" class="form-select">
              <option value="RECEIVABLE" ${p.openingType !== "PAYABLE" ? "selected" : ""}>${tr("optOpeningDr")}</option>
              <option value="PAYABLE" ${p.openingType === "PAYABLE" ? "selected" : ""}>${tr("optOpeningCr")}</option>
            </select>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label" for="partyCreditLimitInput">${tr("fieldCreditLimit")}</label>
          <input id="partyCreditLimitInput" class="form-input" type="number" min="0" step="0.01" value="${Number(p.creditLimit) || 0}" />
        </div>
        <div class="form-row-2">
          <div class="form-group">
            <label class="form-label" for="partyAddressInput">${tr("fieldAddress")}</label>
            <textarea id="partyAddressInput" class="form-textarea">${app.escapeHtml(p.address)}</textarea>
          </div>
          <div class="form-group">
            <label class="form-label" for="partyShippingInput">${tr("fieldShippingAddress")}</label>
            <textarea id="partyShippingInput" class="form-textarea">${app.escapeHtml(p.shippingAddress || "")}</textarea>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label" for="partyNotesInput">${tr("fieldPartyNotes")}</label>
          <input id="partyNotesInput" class="form-input" type="text" value="${app.escapeHtml(p.notes || "")}" />
        </div>
        <div class="form-group">
          <label class="form-label">${tr("fieldAttachments")}</label>
          <div class="btn-row">
            <button id="partyAttachBtn" class="secondary-btn" type="button">${tr("addAttachBtn")}</button>
            <input id="partyAttachInput" class="hidden-file-input" type="file" accept="image/*,.pdf,.txt" />
          </div>
          <div id="partyAttachList" class="btn-row" style="margin-top:6px;"></div>
        </div>
        <div class="modal-actions">
          <button id="partyCancelBtn" class="secondary-btn" type="button">${tr("cancelBtn")}</button>
          <button class="primary-btn" type="submit">${tr("saveBtn")}</button>
        </div>
      </form>
    `;

    app.openModal(isEdit ? tr("modalEditParty") : tr("modalAddParty"), html);
    document.getElementById("partyCancelBtn").addEventListener("click", app.closeModal);

    function renderAttachList() {
      const wrap = document.getElementById("partyAttachList");
      if (!wrap) return;
      wrap.innerHTML = p.attachments
        .map(function (att, idx) {
          return `
            <span class="check-chip">
              <a href="${att.dataUrl}" download="${app.escapeHtml(att.name)}" style="color:inherit;text-decoration:underline;">${app.escapeHtml(att.name)}</a>
              <button type="button" data-rem-att="${idx}" style="border:none;background:none;color:var(--danger-text);font-weight:700;cursor:pointer;">✕</button>
            </span>
          `;
        })
        .join("");
      wrap.querySelectorAll("[data-rem-att]").forEach(function (btn) {
        btn.addEventListener("click", function () {
          p.attachments.splice(parseInt(btn.getAttribute("data-rem-att"), 10), 1);
          renderAttachList();
        });
      });
    }
    renderAttachList();

    const attachInput = document.getElementById("partyAttachInput");
    document.getElementById("partyAttachBtn").addEventListener("click", function () {
      attachInput.value = "";
      attachInput.click();
    });
    attachInput.addEventListener("change", function (e) {
      if (!e.target.files || !e.target.files[0]) return;
      readAttachmentFile(e.target.files[0])
        .then(function (att) {
          p.attachments.push(att);
          renderAttachList();
        })
        .catch(function (err) {
          app.showToast(err.message || "Attachment error", true);
        });
    });

    document.getElementById("partyForm").addEventListener("submit", function (event) {
      event.preventDefault();
      const errBox = document.getElementById("partyFormError");
      const name = document.getElementById("partyNameInput").value.trim();
      const type = document.getElementById("partyTypeSelect").value;
      const phone = document.getElementById("partyPhoneInput").value.trim();
      const gstin = document.getElementById("partyGstinInput").value.trim().toUpperCase();
      const openingBalance = Math.max(0, parseFloat(document.getElementById("partyOpeningBalInput").value) || 0);
      const openingType = document.getElementById("partyOpeningTypeSelect").value;
      const creditLimit = Math.max(0, parseFloat(document.getElementById("partyCreditLimitInput").value) || 0);
      const address = document.getElementById("partyAddressInput").value.trim();
      const shippingAddress = document.getElementById("partyShippingInput").value.trim();
      const notes = document.getElementById("partyNotesInput").value.trim();

      if (name.length < 2) {
        errBox.textContent = tr("errNameReq");
        errBox.classList.remove("hidden");
        return;
      }

      if (phone && !/^[0-9]{10}$/.test(phone)) {
        errBox.textContent = tr("errPhoneInvalid");
        errBox.classList.remove("hidden");
        return;
      }

      if (gstin && !/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/.test(gstin)) {
        errBox.textContent = tr("errGstinInvalid");
        errBox.classList.remove("hidden");
        return;
      }

      const businessId = app.getActiveBusinessId();
      const now = new Date().toISOString();
      const record = {
        id: isEdit ? p.id : global.PBM_DB.generateId("pty"),
        businessId: businessId,
        name: name,
        type: type,
        phone: phone,
        gstin: gstin,
        openingBalance: openingBalance,
        openingType: openingType,
        creditLimit: creditLimit,
        address: address,
        shippingAddress: shippingAddress,
        notes: notes,
        attachments: p.attachments,
        createdAt: isEdit ? p.createdAt : now,
        updatedAt: now
      };

      global.PBM_DB.put("parties", record)
        .then(function () {
          return global.PBM_DB.logAudit(businessId, isEdit ? "UPDATE" : "CREATE", "party", record.name);
        })
        .then(function () {
          app.closeModal();
          app.showToast(tr("toastSaved"), false);
          app.renderCurrentRoute();
        });
    });
  }

  function openPaymentModal(party, currentBalance, onComplete) {
    const app = global.PBM_APP;
    const defaultType = party.type === "SUPPLIER" || currentBalance < 0 ? "PAYMENT" : "RECEIPT";
    const today = new Date().toISOString().slice(0, 10);

    const html = `
      <form id="partyPaymentForm" class="form-grid" novalidate>
        <div id="payFormError" class="form-error hidden"></div>
        <div class="list-item-meta"><strong>${app.escapeHtml(party.name)}</strong></div>
        <div class="form-group">
          <label class="form-label" for="payTypeSelect">${tr("fieldPayType")}</label>
          <select id="payTypeSelect" class="form-select">
            <option value="RECEIPT" ${defaultType === "RECEIPT" ? "selected" : ""}>${tr("optReceipt")}</option>
            <option value="PAYMENT" ${defaultType === "PAYMENT" ? "selected" : ""}>${tr("optPayment")}</option>
          </select>
        </div>
        <div class="form-row-2">
          <div class="form-group">
            <label class="form-label" for="payAmountInput">${tr("fieldAmount")}</label>
            <input id="payAmountInput" class="form-input" type="number" min="0.01" step="0.01" required />
          </div>
          <div class="form-group">
            <label class="form-label" for="payDateInput">${tr("fieldDate")}</label>
            <input id="payDateInput" class="form-input" type="date" value="${today}" required />
          </div>
        </div>
        <div class="form-group">
          <label class="form-label" for="payModeSelect">${tr("fieldMode")}</label>
          <select id="payModeSelect" class="form-select">
            <option value="Cash">${tr("modeCash")}</option>
            <option value="UPI">${tr("modeUpi")}</option>
            <option value="Bank">${tr("modeBank")}</option>
            <option value="Cheque">${tr("modeCheque")}</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label" for="payNotesInput">${tr("fieldNotes")}</label>
          <input id="payNotesInput" class="form-input" type="text" />
        </div>
        <div class="modal-actions">
          <button id="payCancelBtn" class="secondary-btn" type="button">${tr("cancelBtn")}</button>
          <button class="primary-btn" type="submit">${tr("saveBtn")}</button>
        </div>
      </form>
    `;

    app.openModal(tr("modalPaymentTitle"), html);
    document.getElementById("payCancelBtn").addEventListener("click", app.closeModal);

    document.getElementById("partyPaymentForm").addEventListener("submit", function (event) {
      event.preventDefault();
      const errBox = document.getElementById("payFormError");
      const voucherType = document.getElementById("payTypeSelect").value;
      const amount = parseFloat(document.getElementById("payAmountInput").value);
      const date = document.getElementById("payDateInput").value || today;
      const mode = document.getElementById("payModeSelect").value;
      const notes = document.getElementById("payNotesInput").value.trim();

      if (!amount || amount <= 0) {
        errBox.textContent = tr("errAmountInvalid");
        errBox.classList.remove("hidden");
        return;
      }

      const businessId = app.getActiveBusinessId();
      const now = new Date().toISOString();
      const prefix = voucherType === "RECEIPT" ? "REC" : "PAY";
      const amtRounded = Math.round(amount * 100) / 100;
      const record = {
        id: global.PBM_DB.generateId("vch"),
        businessId: businessId,
        partyId: party.id,
        partyName: party.name,
        voucherType: voucherType,
        voucherNo: prefix + "-" + Date.now().toString().slice(-5),
        date: date,
        amount: amtRounded,
        grandTotal: amtRounded,
        mode: mode,
        notes: notes,
        createdAt: now,
        updatedAt: now
      };

      global.PBM_DB.put("vouchers", record)
        .then(function () {
          if (global.PBM_BILLING && typeof global.PBM_BILLING.syncAccountingForVoucher === "function") {
            return global.PBM_BILLING.syncAccountingForVoucher(businessId, record);
          }
          return null;
        })
        .then(function () {
          return global.PBM_DB.logAudit(
            businessId,
            "CREATE",
            "voucher",
            record.voucherType + " " + record.amount + " for " + party.name
          );
        })
        .then(function () {
          app.closeModal();
          app.showToast(tr("toastPaySaved"), false);
          if (typeof onComplete === "function") {
            onComplete();
          } else {
            app.renderCurrentRoute();
          }
        });
    });
  }

  function exportLedgerCsv(party, rows, closingBal) {
    const csvLines = [["Date", "Particulars", "Type", "Debit (+)", "Credit (-)", "Running Balance"]];
    rows.forEach(function (r) {
      csvLines.push([
        r.date || "",
        '"' + String(r.title || "").replace(/"/g, '""') + '"',
        r.typeLabel || "",
        r.delta > 0 ? r.delta.toFixed(2) : "0.00",
        r.delta < 0 ? Math.abs(r.delta).toFixed(2) : "0.00",
        r.runningBalance.toFixed(2)
      ]);
    });
    csvLines.push(["", "Closing Balance", "", "", "", closingBal.toFixed(2)]);

    const csvContent = csvLines.map(function (line) { return line.join(","); }).join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "statement-" + party.name.toLowerCase().replace(/[^a-z0-9]+/g, "-") + ".csv";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
  }

  function openLedgerModal(partyId, filterFrom, filterTo) {
    const app = global.PBM_APP;
    const businessId = app.getActiveBusinessId();

    Promise.all([
      global.PBM_DB.getOne("parties", partyId),
      global.PBM_DB.getByBusiness("vouchers", businessId)
    ]).then(function (results) {
      const party = results[0];
      if (!party) return;

      const fromDate = filterFrom || "";
      const toDate = filterTo || "";

      const partyVouchers = results[1]
        .filter(function (v) {
          return v.partyId === partyId && v.status !== "VOID";
        })
        .sort(function (a, b) {
          const dateCmp = (a.date || "").localeCompare(b.date || "");
          return dateCmp !== 0 ? dateCmp : (a.createdAt || "").localeCompare(b.createdAt || "");
        });

      const opening = Number(party.openingBalance) || 0;
      let running = party.openingType === "PAYABLE" ? -opening : opening;

      const rows = [];
      let bfInserted = false;

      if (!fromDate && opening > 0) {
        rows.push({
          id: null,
          date: "-",
          title: tr("openingEntry"),
          typeLabel: party.openingType === "PAYABLE" ? "Cr" : "Dr",
          delta: running,
          runningBalance: running,
          deletable: false
        });
        bfInserted = true;
      }

      partyVouchers.forEach(function (v) {
        const delta = getSignedVoucherDelta(v);
        if (delta === 0 && v.voucherType !== "QUOTATION" && v.voucherType !== "PROFORMA") {
          // Include zero-delta only if needed? No, statement focuses on financial entries.
        }
        if (delta === 0) return;

        const d = v.date || "";
        if (fromDate && d < fromDate) {
          running = Math.round((running + delta) * 100) / 100;
          return;
        }
        if (fromDate && !bfInserted) {
          rows.push({
            id: null,
            date: fromDate,
            title: tr("broughtForwardEntry"),
            typeLabel: running >= 0 ? "Dr" : "Cr",
            delta: running,
            runningBalance: running,
            deletable: false
          });
          bfInserted = true;
        }
        if (toDate && d > toDate) {
          return;
        }

        running = Math.round((running + delta) * 100) / 100;
        const label =
          v.voucherType === "RECEIPT"
            ? tr("optReceipt")
            : v.voucherType === "PAYMENT"
            ? tr("optPayment")
            : v.voucherType;
        rows.push({
          id: v.id,
          date: d,
          title: (v.voucherNo ? v.voucherNo + " · " : "") + label + (v.mode ? " (" + v.mode + ")" : "") + (v.notes ? " — " + v.notes : ""),
          typeLabel: v.voucherType,
          delta: delta,
          runningBalance: running,
          deletable: v.voucherType === "RECEIPT" || v.voucherType === "PAYMENT"
        });
      });

      if (fromDate && !bfInserted && running !== 0) {
        rows.unshift({
          id: null,
          date: fromDate,
          title: tr("broughtForwardEntry"),
          typeLabel: running >= 0 ? "Dr" : "Cr",
          delta: running,
          runningBalance: running,
          deletable: false
        });
      }

      const closingInfo = formatSignedBalanceText(running);
      const rowsHtml =
        rows.length === 0
          ? `<div class="info-note">${tr("noEntriesMsg")}</div>`
          : rows
              .map(function (r) {
                const balFmt = formatSignedBalanceText(r.runningBalance);
                const amtDisplay =
                  r.delta >= 0 ? "+ " + app.formatCurrency(r.delta) : "- " + app.formatCurrency(Math.abs(r.delta));
                return `
                  <div class="ledger-row">
                    <div class="ledger-row-main">
                      <div class="ledger-row-title">${app.escapeHtml(r.title)}</div>
                      <div class="list-item-meta">${app.escapeHtml(r.date)} · ${balFmt.amountText} (${balFmt.label})</div>
                    </div>
                    <div class="ledger-row-right">
                      <span class="tabular-nums ${r.delta >= 0 ? "text-receivable" : "text-payable"}">${amtDisplay}</span>
                      ${
                        r.deletable
                          ? `<button class="mini-danger-btn" type="button" data-del-vch="${app.escapeHtml(r.id)}">${tr("btnDelete")}</button>`
                          : ""
                      }
                    </div>
                  </div>
                `;
              })
              .join("");

      const html = `
        <div class="ledger-summary-box">
          <div>
            <div class="list-item-title">${app.escapeHtml(party.name)}</div>
            <div class="list-item-meta">${getPartyTypeLabel(party.type)}${party.phone ? " · " + app.escapeHtml(party.phone) : ""}${party.gstin ? " · " + app.escapeHtml(party.gstin) : ""}</div>
            ${party.address ? `<div class="list-item-meta">${app.escapeHtml(party.address)}</div>` : ""}
          </div>
          <div style="text-align:right;">
            <div class="list-item-meta">${tr("closingBalance")}</div>
            <div class="kpi-value tabular-nums ${closingInfo.cls}">${closingInfo.amountText}</div>
            <div class="list-item-meta ${closingInfo.cls}">${closingInfo.label}</div>
          </div>
        </div>

        <div class="form-row-2" style="margin-top:10px;">
          <div class="form-group">
            <label class="form-label" for="stmtFrom">${tr("fromDateLabel")}</label>
            <input id="stmtFrom" class="form-input" type="date" value="${app.escapeHtml(fromDate)}" />
          </div>
          <div class="form-group">
            <label class="form-label" for="stmtTo">${tr("toDateLabel")}</label>
            <input id="stmtTo" class="form-input" type="date" value="${app.escapeHtml(toDate)}" />
          </div>
        </div>

        <div class="btn-row" style="margin: 12px 0;">
          <button id="ledgerAddPayBtn" class="primary-btn" type="button">${tr("btnPayment")}</button>
          <button id="ledgerPrintStmtBtn" class="secondary-btn" type="button">${tr("printStmtBtn")}</button>
          <button id="ledgerExportCsvBtn" class="secondary-btn" type="button">${tr("exportCsvBtn")}</button>
        </div>

        <div class="ledger-list">${rowsHtml}</div>
      `;

      app.openModal(tr("ledgerTitle"), html);

      document.getElementById("stmtFrom").addEventListener("change", function (e) {
        openLedgerModal(partyId, e.target.value, document.getElementById("stmtTo").value);
      });
      document.getElementById("stmtTo").addEventListener("change", function (e) {
        openLedgerModal(partyId, document.getElementById("stmtFrom").value, e.target.value);
      });

      document.getElementById("ledgerAddPayBtn").addEventListener("click", function () {
        openPaymentModal(party, running, function () {
          app.renderCurrentRoute();
          openLedgerModal(party.id, fromDate, toDate);
        });
      });

      document.getElementById("ledgerPrintStmtBtn").addEventListener("click", function () {
        const biz = app.getActiveBusiness();
        const tblRows = rows
          .map(function (r) {
            return `
              <tr>
                <td>${app.escapeHtml(r.date)}</td>
                <td>${app.escapeHtml(r.title)}</td>
                <td style="text-align:right;">${r.delta > 0 ? app.formatCurrency(r.delta) : "-"}</td>
                <td style="text-align:right;">${r.delta < 0 ? app.formatCurrency(Math.abs(r.delta)) : "-"}</td>
                <td style="text-align:right;">${app.formatCurrency(Math.abs(r.runningBalance))} ${r.runningBalance >= 0 ? "Dr" : "Cr"}</td>
              </tr>
            `;
          })
          .join("");
        const printHtml = `
          <div class="print-sheet">
            <div class="print-head">
              <div>
                <h2 style="margin:0;">${app.escapeHtml(biz ? biz.name : "Business")}</h2>
                <div style="font-size:12px;">${app.escapeHtml(biz && biz.address ? biz.address : "")}</div>
              </div>
              <div style="text-align:right;">
                <strong>ACCOUNT STATEMENT</strong><br/>
                <small>${fromDate || "Start"} to ${toDate || new Date().toISOString().slice(0, 10)}</small>
              </div>
            </div>
            <div class="print-party">
              <strong>${app.escapeHtml(party.name)}</strong> ${party.phone ? "· " + app.escapeHtml(party.phone) : ""} ${party.gstin ? "· GSTIN: " + app.escapeHtml(party.gstin) : ""}<br/>
              ${app.escapeHtml(party.address || "")}
            </div>
            <table class="print-table">
              <thead><tr><th>Date</th><th>Particulars</th><th style="text-align:right;">Debit (+)</th><th style="text-align:right;">Credit (-)</th><th style="text-align:right;">Balance</th></tr></thead>
              <tbody>${tblRows}</tbody>
            </table>
            <div class="print-totals">
              <div><strong>Closing Balance:</strong><strong>${closingInfo.amountText} (${closingInfo.label})</strong></div>
            </div>
          </div>
        `;
        global.PBM_PRINT.printHtmlDocument(printHtml);
      });

      document.getElementById("ledgerExportCsvBtn").addEventListener("click", function () {
        exportLedgerCsv(party, rows, running);
      });

      document.querySelectorAll("[data-del-vch]").forEach(function (btn) {
        btn.addEventListener("click", function () {
          const vchId = btn.getAttribute("data-del-vch");
          app
            .confirmDialog({
              title: tr("confirmDelEntryTitle"),
              message: tr("confirmDelEntryMsg"),
              confirmText: tr("deleteBtn"),
              isDanger: true
            })
            .then(function (confirmed) {
              if (!confirmed) {
                openLedgerModal(party.id, fromDate, toDate);
                return;
              }
              global.PBM_DB.getByBusiness("journalEntries", businessId)
                .then(function (journals) {
                  const dels = journals
                    .filter(function (j) { return j.refVoucherId === vchId; })
                    .map(function (j) { return global.PBM_DB.remove("journalEntries", j.id); });
                  return Promise.all(dels);
                })
                .then(function () {
                  return global.PBM_DB.remove("vouchers", vchId);
                })
                .then(function () {
                  app.showToast(tr("toastEntryDeleted"), false);
                  app.renderCurrentRoute();
                  openLedgerModal(party.id, fromDate, toDate);
                });
            });
        });
      });
    });
  }

  function handleDeleteParty(party) {
    const app = global.PBM_APP;
    app
      .confirmDialog({
        title: tr("confirmDeleteTitle"),
        message: tr("confirmDeleteMsg"),
        confirmText: tr("deleteBtn"),
        isDanger: true
      })
      .then(function (confirmed) {
        if (!confirmed) return;
        const businessId = app.getActiveBusinessId();
        global.PBM_DB.getByBusiness("vouchers", businessId)
          .then(function (vouchers) {
            const deletions = vouchers
              .filter(function (v) { return v.partyId === party.id; })
              .map(function (v) { return global.PBM_DB.remove("vouchers", v.id); });
            return Promise.all(deletions);
          })
          .then(function () {
            return global.PBM_DB.remove("parties", party.id);
          })
          .then(function () {
            return global.PBM_DB.logAudit(businessId, "DELETE", "party", party.name);
          })
          .then(function () {
            app.showToast(tr("toastDeleted"), false);
            app.renderCurrentRoute();
          });
      });
  }

  function renderPartiesList(container, totals) {
    const app = global.PBM_APP;
    const query = viewState.search.trim().toLowerCase();

    const filtered = viewState.parties.filter(function (party) {
      const bal = totals.balanceByPartyId[party.id] || 0;
      if (viewState.filter === "customer" && party.type !== "CUSTOMER" && party.type !== "BOTH") return false;
      if (viewState.filter === "supplier" && party.type !== "SUPPLIER" && party.type !== "BOTH") return false;
      if (viewState.filter === "receivable" && bal <= 0.009) return false;
      if (viewState.filter === "payable" && bal >= -0.009) return false;
      if (query) {
        const haystack = [party.name, party.phone, party.gstin, party.address, party.shippingAddress, party.notes]
          .join(" ")
          .toLowerCase();
        return haystack.indexOf(query) !== -1;
      }
      return true;
    });

    if (filtered.length === 0) {
      container.innerHTML = `
        <div class="card">
          <h3 class="card-title">${tr("emptyTitle")}</h3>
          <p class="card-subtitle">${tr("emptyDesc")}</p>
        </div>
      `;
      return;
    }

    container.innerHTML = filtered
      .map(function (party) {
        const bal = totals.balanceByPartyId[party.id] || 0;
        const balInfo = formatSignedBalanceText(bal);
        const creditLimit = Number(party.creditLimit) || 0;
        const isOverLimit = creditLimit > 0 && bal > creditLimit;
        const attCount = Array.isArray(party.attachments) ? party.attachments.length : 0;

        return `
          <div class="list-item-card">
            <div class="list-item-top">
              <div>
                <h3 class="list-item-title">${app.escapeHtml(party.name)}</h3>
                <div class="list-item-meta">
                  ${getPartyTypeLabel(party.type)}${party.phone ? " · " + app.escapeHtml(party.phone) : ""}${party.gstin ? " · " + app.escapeHtml(party.gstin) : ""}${attCount > 0 ? " · 📎 " + attCount : ""}
                </div>
                ${party.shippingAddress ? `<div class="list-item-meta">Ship: ${app.escapeHtml(party.shippingAddress)}</div>` : ""}
                ${party.notes ? `<div class="list-item-meta">${app.escapeHtml(party.notes)}</div>` : ""}
                ${
                  creditLimit > 0
                    ? `<div class="list-item-meta ${isOverLimit ? "text-payable" : ""}">${tr("creditLimitLabel")}: ${app.formatCurrency(creditLimit)}${isOverLimit ? " · " + tr("creditExceeded") : ""}</div>`
                    : ""
                }
              </div>
              <div style="text-align:right;">
                <div class="kpi-value tabular-nums ${balInfo.cls}" style="font-size:1.05rem;">${balInfo.amountText}</div>
                <div class="list-item-meta ${balInfo.cls}">${balInfo.label}</div>
              </div>
            </div>
            <div class="btn-row">
              <button class="primary-btn" type="button" data-pty-ledger="${app.escapeHtml(party.id)}">${tr("btnLedger")}</button>
              <button class="secondary-btn" type="button" data-pty-pay="${app.escapeHtml(party.id)}">${tr("btnPayment")}</button>
              <button class="secondary-btn" type="button" data-pty-edit="${app.escapeHtml(party.id)}">${tr("btnEdit")}</button>
              <button class="danger-btn" type="button" data-pty-del="${app.escapeHtml(party.id)}">${tr("btnDelete")}</button>
            </div>
          </div>
        `;
      })
      .join("");

    container.querySelectorAll("[data-pty-ledger]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        openLedgerModal(btn.getAttribute("data-pty-ledger"));
      });
    });

    container.querySelectorAll("[data-pty-pay]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        const id = btn.getAttribute("data-pty-pay");
        const found = viewState.parties.find(function (p) { return p.id === id; });
        if (found) openPaymentModal(found, totals.balanceByPartyId[id] || 0);
      });
    });

    container.querySelectorAll("[data-pty-edit]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        const id = btn.getAttribute("data-pty-edit");
        const found = viewState.parties.find(function (p) { return p.id === id; });
        if (found) openPartyFormModal(found);
      });
    });

    container.querySelectorAll("[data-pty-del]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        const id = btn.getAttribute("data-pty-del");
        const found = viewState.parties.find(function (p) { return p.id === id; });
        if (found) handleDeleteParty(found);
      });
    });
  }

  function render(viewContainer, contextStripHtml) {
    const app = global.PBM_APP;
    const businessId = app.getActiveBusinessId();

    return Promise.all([
      global.PBM_DB.getByBusiness("parties", businessId),
      global.PBM_DB.getByBusiness("vouchers", businessId)
    ]).then(function (results) {
      viewState.parties = results[0].sort(function (a, b) {
        return (a.name || "").localeCompare(b.name || "");
      });
      viewState.vouchers = results[1];

      const totals = calculateTotalsForBusiness(viewState.parties, viewState.vouchers);

      viewContainer.innerHTML = `
        ${contextStripHtml}

        <div class="kpi-grid">
          <div class="kpi-card">
            <div class="kpi-label">${tr("filterReceivable")}</div>
            <div class="kpi-value tabular-nums text-receivable">${app.formatCurrency(totals.totalReceivable)}</div>
          </div>
          <div class="kpi-card">
            <div class="kpi-label">${tr("filterPayable")}</div>
            <div class="kpi-value tabular-nums text-payable">${app.formatCurrency(totals.totalPayable)}</div>
          </div>
        </div>

        <div class="card">
          <div class="toolbar-row">
            <input id="partySearchInput" class="form-input" type="search" placeholder="${tr("searchPlaceholder")}" value="${app.escapeHtml(viewState.search)}" />
            <button id="addPartyBtn" class="primary-btn" type="button">${tr("addPartyBtn")}</button>
          </div>

          <div class="segmented-bar" role="tablist" aria-label="Party Filters">
            <button class="seg-btn ${viewState.filter === "all" ? "active" : ""}" data-filter="all" type="button">${tr("filterAll")} (${viewState.parties.length})</button>
            <button class="seg-btn ${viewState.filter === "customer" ? "active" : ""}" data-filter="customer" type="button">${tr("filterCustomer")}</button>
            <button class="seg-btn ${viewState.filter === "supplier" ? "active" : ""}" data-filter="supplier" type="button">${tr("filterSupplier")}</button>
            <button class="seg-btn ${viewState.filter === "receivable" ? "active" : ""}" data-filter="receivable" type="button">${tr("filterReceivable")}</button>
            <button class="seg-btn ${viewState.filter === "payable" ? "active" : ""}" data-filter="payable" type="button">${tr("filterPayable")}</button>
          </div>
        </div>

        <div id="partiesListWrap" class="list-stack"></div>
      `;

      const listWrap = document.getElementById("partiesListWrap");
      renderPartiesList(listWrap, totals);

      document.getElementById("addPartyBtn").addEventListener("click", function () {
        openPartyFormModal(null);
      });

      document.getElementById("partySearchInput").addEventListener("input", function (event) {
        viewState.search = event.target.value;
        renderPartiesList(listWrap, totals);
      });

      viewContainer.querySelectorAll("[data-filter]").forEach(function (btn) {
        btn.addEventListener("click", function () {
          viewState.filter = btn.getAttribute("data-filter");
          viewContainer.querySelectorAll("[data-filter]").forEach(function (b) {
            b.classList.toggle("active", b === btn);
          });
          renderPartiesList(listWrap, totals);
        });
      });
    });
  }

  global.PBM_PARTIES = {
    render: render,
    getBusinessTotals: getBusinessTotals,
    computePartyBalance: computePartyBalance,
    getSignedVoucherDelta: getSignedVoucherDelta
  };
})(window);
