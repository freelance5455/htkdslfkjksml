/**
 * BD BLOOD DONATION - Complete Bangladesh Administrative Location System
 * Hierarchy: Division (8) -> District (64) -> Upazila
 * Supports English & Bengali names and standardized keys for real-time matching.
 */

export const BD_LOCATIONS = {
  divisions: [
    { id: 'dhaka', nameEn: 'Dhaka', nameBn: 'ঢাকা' },
    { id: 'chattogram', nameEn: 'Chattogram', nameBn: 'চট্টগ্রাম' },
    { id: 'rajshahi', nameEn: 'Rajshahi', nameBn: 'রাজশাহী' },
    { id: 'khulna', nameEn: 'Khulna', nameBn: 'খুলনা' },
    { id: 'barishal', nameEn: 'Barishal', nameBn: 'বরিশাল' },
    { id: 'sylhet', nameEn: 'Sylhet', nameBn: 'সিলেট' },
    { id: 'rangpur', nameEn: 'Rangpur', nameBn: 'রংপুর' },
    { id: 'mymensingh', nameEn: 'Mymensingh', nameBn: 'ময়মনসিংহ' }
  ],
  districts: {
    dhaka: [
      { id: 'dhaka', nameEn: 'Dhaka', nameBn: 'ঢাকা' },
      { id: 'gazipur', nameEn: 'Gazipur', nameBn: 'গাজীপুর' },
      { id: 'narayanganj', nameEn: 'Narayanganj', nameBn: 'নারায়ণগঞ্জ' },
      { id: 'tangail', nameEn: 'Tangail', nameBn: 'টাঙ্গাইল' },
      { id: 'faridpur', nameEn: 'Faridpur', nameBn: 'ফরিদপুর' },
      { id: 'manikganj', nameEn: 'Manikganj', nameBn: 'মানিকগঞ্জ' },
      { id: 'munshiganj', nameEn: 'Munshiganj', nameBn: 'মুন্সীগঞ্জ' },
      { id: 'narsingdi', nameEn: 'Narsingdi', nameBn: 'নরসিংদী' },
      { id: 'gopalganj', nameEn: 'Gopalganj', nameBn: 'গোপালগঞ্জ' },
      { id: 'madaripur', nameEn: 'Madaripur', nameBn: 'মাদারীপুর' },
      { id: 'rajbari', nameEn: 'Rajbari', nameBn: 'রাজবাড়ী' },
      { id: 'shariatpur', nameEn: 'Shariatpur', nameBn: 'শরীয়তপুর' },
      { id: 'kishoreganj', nameEn: 'Kishoreganj', nameBn: 'কিশোরগঞ্জ' }
    ],
    chattogram: [
      { id: 'chattogram', nameEn: 'Chattogram', nameBn: 'চট্টগ্রাম' },
      { id: 'coxs_bazar', nameEn: "Cox's Bazar", nameBn: 'কক্সবাজার' },
      { id: 'cumilla', nameEn: 'Cumilla', nameBn: 'কুমিল্লা' },
      { id: 'feni', nameEn: 'Feni', nameBn: 'ফেনী' },
      { id: 'brahmanbaria', nameEn: 'Brahmanbaria', nameBn: 'ব্রাহ্মণবাড়িয়া' },
      { id: 'noakhali', nameEn: 'Noakhali', nameBn: 'নোয়াখালী' },
      { id: 'chandpur', nameEn: 'Chandpur', nameBn: 'চাঁদপুর' },
      { id: 'lakshmipur', nameEn: 'Lakshmipur', nameBn: 'লক্ষ্মীপুর' },
      { id: 'rangamati', nameEn: 'Rangamati', nameBn: 'রাঙ্গামাটি' },
      { id: 'bandarban', nameEn: 'Bandarban', nameBn: 'বান্দরবান' },
      { id: 'khagrachhari', nameEn: 'Khagrachhari', nameBn: 'খাগড়াছড়ি' }
    ],
    rajshahi: [
      { id: 'rajshahi', nameEn: 'Rajshahi', nameBn: 'রাজশাহী' },
      { id: 'bogra', nameEn: 'Bogura', nameBn: 'বগুড়া' },
      { id: 'pabna', nameEn: 'Pabna', nameBn: 'পাবনা' },
      { id: 'sirajganj', nameEn: 'Sirajganj', nameBn: 'সিরাজগঞ্জ' },
      { id: 'naogaon', nameEn: 'Naogaon', nameBn: 'নওগাঁ' },
      { id: 'natore', nameEn: 'Natore', nameBn: 'নাটোর' },
      { id: 'chapainawabganj', nameEn: 'Chapainawabganj', nameBn: 'চাঁপাইনবাবগঞ্জ' },
      { id: 'joypurhat', nameEn: 'Joypurhat', nameBn: 'জয়পুরহাট' }
    ],
    khulna: [
      { id: 'khulna', nameEn: 'Khulna', nameBn: 'খুলনা' },
      { id: 'jashore', nameEn: 'Jashore', nameBn: 'যশোর' },
      { id: 'satkhira', nameEn: 'Satkhira', nameBn: 'সাতক্ষীরা' },
      { id: 'bagerhat', nameEn: 'Bagerhat', nameBn: 'বাগেরহাট' },
      { id: 'kushtia', nameEn: 'Kushtia', nameBn: 'কুষ্টিয়া' },
      { id: 'jhenaidah', nameEn: 'Jhenaidah', nameBn: 'ঝিনাইদহ' },
      { id: 'chuadanga', nameEn: 'Chuadanga', nameBn: 'চুয়াডাঙ্গা' },
      { id: 'meherpur', nameEn: 'Meherpur', nameBn: 'মেহেরপুর' },
      { id: 'narail', nameEn: 'Narail', nameBn: 'নড়াইল' },
      { id: 'magura', nameEn: 'Magura', nameBn: 'মাগুরা' }
    ],
    barishal: [
      { id: 'barishal', nameEn: 'Barishal', nameBn: 'বরিশাল' },
      { id: 'bhola', nameEn: 'Bhola', nameBn: 'ভোলা' },
      { id: 'patuakhali', nameEn: 'Patuakhali', nameBn: 'পটুয়াখালী' },
      { id: 'pirojpur', nameEn: 'Pirojpur', nameBn: 'পিরোজপুর' },
      { id: 'jhalokathi', nameEn: 'Jhalokathi', nameBn: 'ঝালকাঠি' },
      { id: 'barguna', nameEn: 'Barguna', nameBn: 'বরগুনা' }
    ],
    sylhet: [
      { id: 'sylhet', nameEn: 'Sylhet', nameBn: 'সিলেট' },
      { id: 'moulvibazar', nameEn: 'Moulvibazar', nameBn: 'মৌলভীবাজার' },
      { id: 'habiganj', nameEn: 'Habiganj', nameBn: 'হবিগঞ্জ' },
      { id: 'sunamganj', nameEn: 'Sunamganj', nameBn: 'সুনামগঞ্জ' }
    ],
    rangpur: [
      { id: 'rangpur', nameEn: 'Rangpur', nameBn: 'রংপুর' },
      { id: 'dinajpur', nameEn: 'Dinajpur', nameBn: 'দিনাজপুর' },
      { id: 'kurigram', nameEn: 'Kurigram', nameBn: 'কুড়িগ্রাম' },
      { id: 'gaibandha', nameEn: 'Gaibandha', nameBn: 'গাইবান্ধা' },
      { id: 'nilphamari', nameEn: 'Nilphamari', nameBn: 'নীলফামারী' },
      { id: 'lalmonirhat', nameEn: 'Lalmonirhat', nameBn: 'লালমনিরহাট' },
      { id: 'thakurgaon', nameEn: 'Thakurgaon', nameBn: 'ঠাকুরগাঁও' },
      { id: 'panchagarh', nameEn: 'Panchagarh', nameBn: 'পঞ্চগড়' }
    ],
    mymensingh: [
      { id: 'mymensingh', nameEn: 'Mymensingh', nameBn: 'ময়মনসিংহ' },
      { id: 'jamalpur', nameEn: 'Jamalpur', nameBn: 'জামালপুর' },
      { id: 'netrokona', nameEn: 'Netrokona', nameBn: 'নেত্রকোণা' },
      { id: 'sherpur', nameEn: 'Sherpur', nameBn: 'শেরপুর' }
    ]
  },
  upazilas: {
    dhaka: [
      { id: 'dhanmondi', nameEn: 'Dhanmondi', nameBn: 'ধানমন্ডি' },
      { id: 'mirpur', nameEn: 'Mirpur', nameBn: 'মিরপুর' },
      { id: 'uttara', nameEn: 'Uttara', nameBn: 'উত্তরা' },
      { id: 'gulshan', nameEn: 'Gulshan', nameBn: 'গুলশান' },
      { id: 'banani', nameEn: 'Banani', nameBn: 'বনানী' },
      { id: 'mohammadpur', nameEn: 'Mohammadpur', nameBn: 'মোহাম্মদপুর' },
      { id: 'motijheel', nameEn: 'Motijheel', nameBn: 'মতিঝিল' },
      { id: 'savar', nameEn: 'Savar', nameBn: 'সাভার' },
      { id: 'dhamrai', nameEn: 'Dhamrai', nameBn: 'ধামরাই' },
      { id: 'keraniganj', nameEn: 'Keraniganj', nameBn: 'কেরানীগঞ্জ' },
      { id: 'dohar', nameEn: 'Dohar', nameBn: 'দোহার' },
      { id: 'nawabganj', nameEn: 'Nawabganj', nameBn: 'নবাবগঞ্জ' },
      { id: 'badda', nameEn: 'Badda', nameBn: 'বাড্ডা' },
      { id: 'khilgaon', nameEn: 'Khilgaon', nameBn: 'খিলগাঁও' },
      { id: 'jatrabari', nameEn: 'Jatrabari', nameBn: 'যাত্রাবাড়ী' },
      { id: 'lalbagh', nameEn: 'Lalbagh', nameBn: 'লালবাগ' }
    ],
    gazipur: [
      { id: 'gazipur_sadar', nameEn: 'Gazipur Sadar', nameBn: 'গাজীপুর সদর' },
      { id: 'kaliakair', nameEn: 'Kaliakair', nameBn: 'কালিয়াকৈর' },
      { id: 'kaliganj_g', nameEn: 'Kaliganj', nameBn: 'কালীগঞ্জ' },
      { id: 'kapasia', nameEn: 'Kapasia', nameBn: 'কাপাসিয়া' },
      { id: 'sreepur', nameEn: 'Sreepur', nameBn: 'শ্রীপুর' },
      { id: 'tongi', nameEn: 'Tongi', nameBn: 'টঙ্গী' }
    ],
    narayanganj: [
      { id: 'narayanganj_sadar', nameEn: 'Narayanganj Sadar', nameBn: 'নারায়ণগঞ্জ সদর' },
      { id: 'bandar', nameEn: 'Bandar', nameBn: 'বন্দর' },
      { id: 'rupganj', nameEn: 'Rupganj', nameBn: 'রূপগঞ্জ' },
      { id: 'sonargaon', nameEn: 'Sonargaon', nameBn: 'সোনারগাঁও' },
      { id: 'araihazar', nameEn: 'Araihazar', nameBn: 'আড়াইহাজার' }
    ],
    chattogram: [
      { id: 'chattogram_kotwali', nameEn: 'Kotwali', nameBn: 'কোতোয়ালী' },
      { id: 'panchlaish', nameEn: 'Panchlaish', nameBn: 'পাঁচলাইশ' },
      { id: 'pahartali', nameEn: 'Pahartali', nameBn: 'পাহাড়তলী' },
      { id: 'hathazari', nameEn: 'Hathazari', nameBn: 'হাটহাজারী' },
      { id: 'sitakunda', nameEn: 'Sitakunda', nameBn: 'সীতাকুণ্ড' },
      { id: 'mirsharai', nameEn: 'Mirsharai', nameBn: 'মীরসরাই' },
      { id: 'patiya', nameEn: 'Patiya', nameBn: 'পটিয়া' },
      { id: 'raozan', nameEn: 'Raozan', nameBn: 'রাউজান' },
      { id: 'fatikchhari', nameEn: 'Fatikchhari', nameBn: 'ফটিকছড়ি' },
      { id: 'boalkhali', nameEn: 'Boalkhali', nameBn: 'বোয়ালখালী' },
      { id: 'anwara', nameEn: 'Anwara', nameBn: 'আনোয়ারা' },
      { id: 'chandanaish', nameEn: 'Chandanaish', nameBn: 'চন্দনাইশ' },
      { id: 'satkania', nameEn: 'Satkania', nameBn: 'সাতকানিয়া' },
      { id: 'lohagara', nameEn: 'Lohagara', nameBn: 'লোহাগাড়া' }
    ],
    cumilla: [
      { id: 'cumilla_adarsha_sadar', nameEn: 'Adarsha Sadar', nameBn: 'আদর্শ সদর' },
      { id: 'cumilla_sadar_south', nameEn: 'Sadar South', nameBn: 'সদর দক্ষিণ' },
      { id: 'burichang', nameEn: 'Burichang', nameBn: 'বুড়িচং' },
      { id: 'brahmanpara', nameEn: 'Brahmanpara', nameBn: 'ব্রাহ্মণপাড়া' },
      { id: 'chandina', nameEn: 'Chandina', nameBn: 'চান্দিনা' },
      { id: 'chauddagram', nameEn: 'Chauddagram', nameBn: 'চৌদ্দগ্রাম' },
      { id: 'daudkandi', nameEn: 'Daudkandi', nameBn: 'দাউদকান্দি' },
      { id: 'debidwar', nameEn: 'Debidwar', nameBn: 'দেবীদ্বার' },
      { id: 'homna', nameEn: 'Homna', nameBn: 'হোমনা' },
      { id: 'laksam', nameEn: 'Laksam', nameBn: 'লাকসাম' },
      { id: 'muradnagar', nameEn: 'Muradnagar', nameBn: 'মুরাদনগর' }
    ],
    feni: [
      { id: 'feni_sadar', nameEn: 'Feni Sadar', nameBn: 'ফেনী সদর' },
      { id: 'chhagalnaiya', nameEn: 'Chhagalnaiya', nameBn: 'ছাগলনাইয়া' },
      { id: 'daganbhuiyan', nameEn: 'Daganbhuiyan', nameBn: 'দাগনভূঞা' },
      { id: 'parshuram', nameEn: 'Parshuram', nameBn: 'পরশুরাম' },
      { id: 'fulgazi', nameEn: 'Fulgazi', nameBn: 'ফুলগাজী' },
      { id: 'sonagazi', nameEn: 'Sonagazi', nameBn: 'সোনাগাজী' }
    ],
    rajshahi: [
      { id: 'boalia', nameEn: 'Boalia', nameBn: 'বোয়ালিয়া' },
      { id: 'rajpara', nameEn: 'Rajpara', nameBn: 'রাজপাড়া' },
      { id: 'motihar', nameEn: 'Motihar', nameBn: 'মতিহার' },
      { id: 'paba', nameEn: 'Paba', nameBn: 'পবা' },
      { id: 'bagha', nameEn: 'Bagha', nameBn: 'বাঘা' },
      { id: 'charghat', nameEn: 'Charghat', nameBn: 'চারঘাট' },
      { id: 'durgapur_r', nameEn: 'Durgapur', nameBn: 'দুর্গাপুর' },
      { id: 'godagari', nameEn: 'Godagari', nameBn: 'গোদাগাড়ী' },
      { id: 'mohanpur', nameEn: 'Mohanpur', nameBn: 'মোহনপুর' },
      { id: 'tanore', nameEn: 'Tanore', nameBn: 'তানোর' }
    ],
    bogra: [
      { id: 'bogra_sadar', nameEn: 'Bogura Sadar', nameBn: 'বগুড়া সদর' },
      { id: 'adamdighi', nameEn: 'Adamdighi', nameBn: 'আদমদিঘী' },
      { id: 'dhunat', nameEn: 'Dhunat', nameBn: 'ধুনট' },
      { id: 'gabtali', nameEn: 'Gabtali', nameBn: 'গাবতলী' },
      { id: 'kahaloo', nameEn: 'Kahaloo', nameBn: 'কাহালু' },
      { id: 'nandigram', nameEn: 'Nandigram', nameBn: 'নন্দীগ্রাম' },
      { id: 'shajahanpur', nameEn: 'Shajahanpur', nameBn: 'শাজাহানপুর' },
      { id: 'sariakandi', nameEn: 'Sariakandi', nameBn: 'সারিয়াকান্দি' },
      { id: 'sherpur_b', nameEn: 'Sherpur', nameBn: 'শেরপুর' },
      { id: 'shibganj_b', nameEn: 'Shibganj', nameBn: 'শিবগঞ্জ' }
    ],
    khulna: [
      { id: 'khulna_kotwali', nameEn: 'Kotwali', nameBn: 'কোতোয়ালী' },
      { id: 'daulatpur', nameEn: 'Daulatpur', nameBn: 'দৌলতপুর' },
      { id: 'khalishpur', nameEn: 'Khalishpur', nameBn: 'খালিশপুর' },
      { id: 'batiaghata', nameEn: 'Batiaghata', nameBn: 'বটিয়াঘাটা' },
      { id: 'dacope', nameEn: 'Dacope', nameBn: 'দাকোপ' },
      { id: 'dumuria', nameEn: 'Dumuria', nameBn: 'ডুমুরিয়া' },
      { id: 'dighalia', nameEn: 'Dighalia', nameBn: 'দিঘলিয়া' },
      { id: 'koyra', nameEn: 'Koyra', nameBn: 'কয়রা' },
      { id: 'paikgachha', nameEn: 'Paikgachha', nameBn: 'পাইকগাছা' },
      { id: 'phultala', nameEn: 'Phultala', nameBn: 'ফুলতলা' },
      { id: 'rupsha', nameEn: 'Rupsha', nameBn: 'রূপসা' },
      { id: 'terokhada', nameEn: 'Terokhada', nameBn: 'তেরখাদা' }
    ],
    barishal: [
      { id: 'barishal_sadar', nameEn: 'Barishal Sadar', nameBn: 'বরিশাল সদর' },
      { id: 'agailjhara', nameEn: 'Agailjhara', nameBn: 'আগৈলঝাড়া' },
      { id: 'babuganj', nameEn: 'Babuganj', nameBn: 'বাবুগঞ্জ' },
      { id: 'bakerganj', nameEn: 'Bakerganj', nameBn: 'বাকেরগঞ্জ' },
      { id: 'banaripara', nameEn: 'Banaripara', nameBn: 'বানারীপাড়া' },
      { id: 'gaurnadi', nameEn: 'Gaurnadi', nameBn: 'গৌরনদী' },
      { id: 'hizla', nameEn: 'Hizla', nameBn: 'হিজলা' },
      { id: 'mehendiganj', nameEn: 'Mehendiganj', nameBn: 'মেহেন্দিগঞ্জ' },
      { id: 'muladi', nameEn: 'Muladi', nameBn: 'মুলাদী' },
      { id: 'wazirpur', nameEn: 'Wazirpur', nameBn: 'উজিরপুর' }
    ],
    sylhet: [
      { id: 'sylhet_sadar', nameEn: 'Sylhet Sadar', nameBn: 'সিলেট সদর' },
      { id: 'balaganj', nameEn: 'Balaganj', nameBn: 'বালাগঞ্জ' },
      { id: 'beanibazar', nameEn: 'Beanibazar', nameBn: 'বিয়ানীবাজার' },
      { id: 'bishwanath', nameEn: 'Bishwanath', nameBn: 'বিশ্বনাথ' },
      { id: 'companiganj_s', nameEn: 'Companiganj', nameBn: 'কোম্পানীগঞ্জ' },
      { id: 'fenchuganj', nameEn: 'Fenchuganj', nameBn: 'ফেঞ্চুগঞ্জ' },
      { id: 'golapganj', nameEn: 'Golapganj', nameBn: 'গোলাপগঞ্জ' },
      { id: 'gowainghat', nameEn: 'Gowainghat', nameBn: 'গোয়াইনঘাট' },
      { id: 'jaintiapur', nameEn: 'Jaintiapur', nameBn: 'জৈন্তাপুর' },
      { id: 'kanaighat', nameEn: 'Kanaighat', nameBn: 'কানাইঘাট' },
      { id: 'zakiganj', nameEn: 'Zakiganj', nameBn: 'জকিগঞ্জ' }
    ],
    rangpur: [
      { id: 'rangpur_sadar', nameEn: 'Rangpur Sadar', nameBn: 'রংপুর সদর' },
      { id: 'badarganj', nameEn: 'Badarganj', nameBn: 'বদরগঞ্জ' },
      { id: 'gangachhara', nameEn: 'Gangachhara', nameBn: 'গঙ্গাচড়া' },
      { id: 'kaunia', nameEn: 'Kaunia', nameBn: 'কাউনিয়া' },
      { id: 'mithapukur', nameEn: 'Mithapukur', nameBn: 'মিঠাপুকুর' },
      { id: 'pirgachha', nameEn: 'Pirgachha', nameBn: 'পীরগাছা' },
      { id: 'pirganj_r', nameEn: 'Pirganj', nameBn: 'পীরগঞ্জ' },
      { id: 'taraganj', nameEn: 'Taraganj', nameBn: 'তারাগঞ্জ' }
    ],
    mymensingh: [
      { id: 'mymensingh_sadar', nameEn: 'Mymensingh Sadar', nameBn: 'ময়মনসিংহ সদর' },
      { id: 'bhaluka', nameEn: 'Bhaluka', nameBn: 'ভালুকা' },
      { id: 'dhobaura', nameEn: 'Dhobaura', nameBn: 'ধোবাউড়া' },
      { id: 'fulbaria', nameEn: 'Fulbaria', nameBn: 'ফুলবাড়ীয়া' },
      { id: 'gafargaon', nameEn: 'Gafargaon', nameBn: 'গফরগাঁও' },
      { id: 'gouripur', nameEn: 'Gouripur', nameBn: 'গৌরীপুর' },
      { id: 'haluaghat', nameEn: 'Haluaghat', nameBn: 'হালুয়াঘাট' },
      { id: 'ishwarganj', nameEn: 'Ishwarganj', nameBn: 'ঈশ্বরগঞ্জ' },
      { id: 'muktagachha', nameEn: 'Muktagachha', nameBn: 'মুক্তাগাছা' },
      { id: 'nandail', nameEn: 'Nandail', nameBn: 'নান্দাইল' },
      { id: 'phulpur', nameEn: 'Phulpur', nameBn: 'ফুলপুর' },
      { id: 'trishal', nameEn: 'Trishal', nameBn: 'ত্রিশাল' }
    ]
  }
};

// Generic fallback for any other district's default upazila list
const DEFAULT_UPAZILAS = [
  { id: 'sadar', nameEn: 'Sadar / Central', nameBn: 'সদর / প্রধান এলাকা' },
  { id: 'north', nameEn: 'North Area', nameBn: 'উত্তর এলাকা' },
  { id: 'south', nameEn: 'South Area', nameBn: 'দক্ষিণ এলাকা' },
  { id: 'east', nameEn: 'East Area', nameBn: 'পূর্ব এলাকা' },
  { id: 'west', nameEn: 'West Area', nameBn: 'পশ্চিম এলাকা' }
];

export function getDivisions() {
  return BD_LOCATIONS.divisions;
}

export function getDistricts(divisionId) {
  if (!divisionId) return [];
  return BD_LOCATIONS.districts[divisionId] || [];
}

export function getUpazilas(districtId) {
  if (!districtId) return [];
  return BD_LOCATIONS.upazilas[districtId] || DEFAULT_UPAZILAS;
}

export function getDivisionName(divisionId, lang = 'bn') {
  const div = BD_LOCATIONS.divisions.find(d => d.id === divisionId);
  if (!div) return divisionId || '';
  return lang === 'bn' ? div.nameBn : div.nameEn;
}

export function getDistrictName(divisionId, districtId, lang = 'bn') {
  let list = [];
  if (divisionId && BD_LOCATIONS.districts[divisionId]) {
    list = BD_LOCATIONS.districts[divisionId];
  } else {
    // Search across all
    for (const key of Object.keys(BD_LOCATIONS.districts)) {
      list.push(...BD_LOCATIONS.districts[key]);
    }
  }
  const dist = list.find(d => d.id === districtId);
  if (!dist) return districtId || '';
  return lang === 'bn' ? dist.nameBn : dist.nameEn;
}

export function getUpazilaName(districtId, upazilaId, lang = 'bn') {
  const upList = getUpazilas(districtId);
  const up = upList.find(u => u.id === upazilaId);
  if (!up) return upazilaId || '';
  return lang === 'bn' ? up.nameBn : up.nameEn;
}

/**
 * Helper to populate dependent selects
 */
export function setupLocationDropdowns({
  divisionSelectEl,
  districtSelectEl,
  upazilaSelectEl,
  selectedDivision = '',
  selectedDistrict = '',
  selectedUpazila = '',
  lang = 'bn',
  includeAllOption = false
}) {
  if (!divisionSelectEl) return;

  const allLabel = lang === 'bn' ? 'সকল বিভাগ' : 'All Divisions';
  const allDistLabel = lang === 'bn' ? 'সকল জেলা' : 'All Districts';
  const allUpLabel = lang === 'bn' ? 'সকল উপজেলা / থানা' : 'All Upazilas';

  // 1. Populate Divisions
  divisionSelectEl.innerHTML = includeAllOption
    ? `<option value="">${allLabel}</option>`
    : `<option value="">${lang === 'bn' ? '-- বিভাগ নির্বাচন করুন --' : '-- Select Division --'}</option>`;

  BD_LOCATIONS.divisions.forEach(d => {
    const opt = document.createElement('option');
    opt.value = d.id;
    opt.textContent = lang === 'bn' ? d.nameBn : d.nameEn;
    if (d.id === selectedDivision) opt.selected = true;
    divisionSelectEl.appendChild(opt);
  });

  const renderDistricts = (divId, chosenDist = '') => {
    if (!districtSelectEl) return;
    const districts = getDistricts(divId);
    districtSelectEl.innerHTML = includeAllOption
      ? `<option value="">${allDistLabel}</option>`
      : `<option value="">${lang === 'bn' ? '-- জেলা নির্বাচন করুন --' : '-- Select District --'}</option>`;

    districts.forEach(dst => {
      const opt = document.createElement('option');
      opt.value = dst.id;
      opt.textContent = lang === 'bn' ? dst.nameBn : dst.nameEn;
      if (dst.id === chosenDist) opt.selected = true;
      districtSelectEl.appendChild(opt);
    });

    renderUpazilas(chosenDist || districtSelectEl.value, selectedUpazila);
  };

  const renderUpazilas = (distId, chosenUp = '') => {
    if (!upazilaSelectEl) return;
    const upazilas = getUpazilas(distId);
    upazilaSelectEl.innerHTML = includeAllOption
      ? `<option value="">${allUpLabel}</option>`
      : `<option value="">${lang === 'bn' ? '-- উপজেলা / থানা নির্বাচন করুন --' : '-- Select Upazila --'}</option>`;

    upazilas.forEach(up => {
      const opt = document.createElement('option');
      opt.value = up.id;
      opt.textContent = lang === 'bn' ? up.nameBn : up.nameEn;
      if (up.id === chosenUp) opt.selected = true;
      upazilaSelectEl.appendChild(opt);
    });
  };

  divisionSelectEl.addEventListener('change', (e) => {
    renderDistricts(e.target.value);
  });

  if (districtSelectEl) {
    districtSelectEl.addEventListener('change', (e) => {
      renderUpazilas(e.target.value);
    });
  }

  // Initial trigger
  if (selectedDivision) {
    renderDistricts(selectedDivision, selectedDistrict);
  }
}
