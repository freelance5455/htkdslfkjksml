'use strict';
let pname='',ptab={};
const pb=()=>$('pbody');
function openPanel(n){pname=n;$('panel').hidden=false;render()}
function closePanel(){$('panel').hidden=true;pname='';refreshBars()}
function render(){
  const b=pb();b.innerHTML='';
  const T={store:['दुकान',pStore],luck:['लक रॉयल',pLuck],char:['किरदार',pChar],vault:['वॉल्ट',pVault],pet:['पेट',pPet],col:['कलेक्शन',pCol],weap:['हथियार',pWeap],pass:['रॉयल पास',pPass],set:['सेटिंग्स',pSet],mode:['मोड और मैप',pMode]}[pname];
  if(!T)return;$('ptitle').textContent=T[0];b.append(T[1]());
  const g=$('pCur');g.textContent=prof.gold+' गोल्ड · '+prof.gems+' डायमंड';
}
function tabs(key,list,def){
  const cur=ptab[key]||def;
  return h('div',{class:'tabs'},list.map(([id,l])=>h('button',{class:'tab'+(id===cur?' on':''),onclick:()=>{ptab[key]=id;render()}},l)));
}
function pv(it,w,hh){
  const c=document.createElement('canvas'),d=2;c.width=w*d;c.height=hh*d;c.style.width=w+'px';c.style.height=hh+'px';
  const g=c.getContext('2d');g.scale(d,d);
  if(it.cat==='o')drawChar(g,it,w/2,hh-10,(hh-22)/54,.6,0,{front:true,glow:true});
  else if(it.cat==='w')drawGunIcon(g,'ranger',w/2,hh/2,w/150,it.col||WP.ranger.col);
  else if(it.cat==='g'){g.fillStyle='rgba(0,0,0,.25)';g.fillRect(w*.2+6,hh*.5+8,w*.6,16);for(let i=0;i<=30;i+=3){g.globalAlpha=.9;g.fillStyle=it.col;g.fillRect(w*.2,hh*.55-i+8,w*.6,16)}g.fillStyle='rgba(255,255,255,.5)';g.fillRect(w*.24,hh*.55-28,w*.3,3);g.globalAlpha=1}
  else if(it.cat==='p')drawPet(g,it.kind,w/2,hh-18,Math.min(w,hh)/20,0);
  return c;
}
const owned=id=>!!prof.owned[id];
function seededFeatured(){
  const d=new Date().toDateString();let s=0;for(const ch of d)s=(s*31+ch.charCodeAt(0))>>>0;
  const pool=Object.values(ITEMS).filter(i=>i.p>0&&!owned(i.id));const out=[];
  const r=()=>{s=(s*1664525+1013904223)>>>0;return s/4294967296};
  while(out.length<6&&pool.length){out.push(pool.splice(Math.floor(r()*pool.length),1)[0].id)}
  return out;
}
function priceOf(it,feat){return feat?Math.floor(it.p*.7):it.p}
function buy(it,feat){
  if(owned(it.id))return;
  const p=priceOf(it,feat),k=it.c==='g'?'gold':'gems';
  if(prof[k]<p){toast(it.c==='g'?'गोल्ड कम है':'डायमंड कम हैं');return}
  prof[k]-=p;prof.owned[it.id]=1;prof.eq[it.cat]=prof.eq[it.cat]||it.id;save();snd('pick');toast(it.n+' मिल गया');render();
}
function equip(it){prof.eq[it.cat]=it.id;save();snd('click');render()}
function card(it,feat){
  const ow=owned(it.id),eq=prof.eq[it.cat]===it.id;
  const price=priceOf(it,feat);
  return h('div',{class:'it'+(ow?'':' lock')+(eq?' eq':''),style:'--rc:'+RAR[it.r][1]},
    pv(it,112,128),h('b',null,it.n),h('small',null,RAR[it.r][0]+(it.extra?' · '+it.extra:'')),
    ow?h('button',{class:'sm'+(eq?' on':''),onclick:()=>equip(it)},eq?'लगा हुआ':'लगाओ')
      :h('button',{class:'sm pri',onclick:()=>buy(it,feat)},(feat?'-30% ':'')+price+(it.c==='g'?' गोल्ड':' डायमंड')));
}
function igrid(items,feat){return h('div',{class:'grid'},items.map(i=>card(i,feat)))}

/* ---- store ---- */
const CRATES={bronze:{n:'ब्रॉन्ज़ क्रेट',c:'g',p:150,w:[.65,.28,.07,0,0],col:'#c98a5a'},silver:{n:'सिल्वर क्रेट',c:'g',p:400,w:[.3,.4,.22,.08,0],col:'#cfd6c8'},gold:{n:'गोल्ड क्रेट',c:'d',p:30,w:[.05,.2,.35,.28,.12],col:'#ffb347'}};
function pStore(){
  const tab=ptab.store||'feat',w=h('div');
  w.append(h('div',{class:'row2'},h('span',{class:'dim'},'आज के ऑफ़र रोज़ बदलते हैं'),h('button',{class:'sm pri',onclick:claimDaily},'डेली बोनस लो')));
  w.append(tabs('store',[['feat','फ़ीचर्ड'],['o','आउटफ़िट'],['w','हथियार स्किन'],['g','ग्लू वॉल'],['p','पेट'],['crate','क्रेट'],['ex','एक्सचेंज']],'feat'));
  if(tab==='feat'){const f=seededFeatured();w.append(f.length?igrid(f.map(i=>ITEMS[i]),true):h('p',{class:'dim'},'सब कुछ तुम्हारे पास है!'))}
  else if(tab==='crate')w.append(h('div',{class:'grid'},Object.entries(CRATES).map(([k,c])=>h('div',{class:'it',style:'--rc:'+c.col},h('div',{class:'crate',style:'--cc:'+c.col}),h('b',null,c.n),h('small',null,'तुम्हारे पास: '+(prof.crates[k]||0)),h('button',{class:'sm pri',onclick:()=>{const kk=c.c==='g'?'gold':'gems';if(prof[kk]<c.p){toast('बैलेंस कम है');return}prof[kk]-=c.p;prof.crates[k]=(prof.crates[k]||0)+1;save();snd('pick');toast(c.n+' मिल गया — वॉल्ट में खोलो');render()}},c.p+(c.c==='g'?' गोल्ड':' डायमंड'))))));
  else if(tab==='ex')w.append(h('div',{class:'grid'},[[500,5],[1200,15],[3000,40]].map(([g,d])=>h('div',{class:'it',style:'--rc:#6fb7ff'},h('div',{class:'big'},d+' ◆'),h('small',null,g+' गोल्ड देकर'),h('button',{class:'sm pri',onclick:()=>{if(prof.gold<g){toast('गोल्ड कम है');return}prof.gold-=g;prof.gems+=d;save();snd('pick');render()}},'बदलो')))));
  else w.append(igrid(Object.values(ITEMS).filter(i=>i.cat===tab)));
  return w;
}

/* ---- vault ---- */
function rollItem(rarW){
  let r=Math.random(),rar=0;for(let i=0;i<5;i++){r-=rarW[i];if(r<=0){rar=i;break}}
  let pool=Object.values(ITEMS).filter(i=>i.r===rar&&!owned(i.id));
  if(!pool.length)pool=Object.values(ITEMS).filter(i=>i.r<=rar&&!owned(i.id));
  return pool.length?pick(pool):null;
}
function grant(it){prof.owned[it.id]=1;save()}
function openCrate(k){
  if(!(prof.crates[k]>0))return;
  prof.crates[k]--;const it=rollItem(CRATES[k].w);
  const b=pb();b.innerHTML='';
  if(!it){prof.gold+=150;save();b.append(h('div',{class:'reveal'},h('div',{class:'big'},'सब कुछ मिल चुका!'),h('p',null,'बदले में +150 गोल्ड मिले'),h('button',{class:'sm pri',onclick:render},'ठीक है')));return}
  grant(it);snd('win');
  b.append(h('div',{class:'reveal',style:'--rc:'+RAR[it.r][1]},h('small',{class:'dim'},CRATES[k].n+' से निकला'),pv(it,150,170),h('b',{class:'big'},it.n),h('small',null,RAR[it.r][0]+' · '+CATN[it.cat]),h('button',{class:'sm pri',onclick:()=>{equip(it)}},'अभी लगाओ'),h('button',{class:'sm',onclick:render},'वापस')));
}
function pVault(){
  const w=h('div');
  w.append(h('h3',null,'मेरे क्रेट'));
  w.append(h('div',{class:'grid'},Object.entries(CRATES).map(([k,c])=>h('div',{class:'it',style:'--rc:'+c.col},h('div',{class:'crate',style:'--cc:'+c.col}),h('b',null,c.n),h('small',null,'×'+(prof.crates[k]||0)),h('button',{class:'sm pri'+((prof.crates[k]||0)?'':' off'),onclick:()=>openCrate(k)},'खोलो')))));
  w.append(h('h3',null,'मेरा सामान'));
  w.append(igrid(Object.values(ITEMS).filter(i=>owned(i.id))));
  return w;
}

/* ---- luck royale ---- */
const WHEEL=[{l:'100 गोल्ड',t:'gold',v:100,w:30},{l:'5 ◆',t:'gems',v:5,w:20},{l:'ब्रॉन्ज़ क्रेट',t:'crate',v:'bronze',w:15},{l:'500 गोल्ड',t:'gold',v:500,w:12},{l:'रेयर आइटम',t:'item',v:[0,0,1,0,0],w:8},{l:'20 ◆',t:'gems',v:20,w:6},{l:'सिल्वर क्रेट',t:'crate',v:'silver',w:6},{l:'एपिक आइटम',t:'item',v:[0,0,0,1,0],w:3}];
let spinning=false,wheelDeg=0;
function pLuck(){
  const w=h('div',{class:'luck'});
  const cols=['#3a2f8f','#2a5fa0','#7a3fa0','#a06a1a','#1f7a6a','#a03a5a','#4a6a2a','#8a5a2a'];
  const wh=h('div',{class:'wheel',style:`transform:rotate(${wheelDeg}deg);background:conic-gradient(${WHEEL.map((_,i)=>cols[i]+' '+i*45+'deg '+(i+1)*45+'deg').join(',')})`},
    WHEEL.map((s,i)=>h('span',{style:`transform:rotate(${i*45+22.5}deg) translateY(-92px) rotate(-${i*45+22.5}deg)`},s.l)));
  const free=prof.spin!==new Date().toDateString();
  w.append(h('div',{class:'wheelbox'},h('div',{class:'ptr'}),wh));
  w.append(h('button',{class:'pri big2',onclick:()=>spin(wh,free)},free?'आज का फ्री स्पिन':'स्पिन · 10 डायमंड'));
  w.append(h('p',{class:'dim'},'हर दिन एक फ्री स्पिन। इनाम: गोल्ड, डायमंड, क्रेट और रेयर/एपिक आइटम।'));
  return w;
}
function spin(wh,free){
  if(spinning)return;
  if(!free&&prof.gems<10){toast('डायमंड कम हैं');return}
  if(free)prof.spin=new Date().toDateString();else prof.gems-=10;
  let tw=WHEEL.reduce((a,s)=>a+s.w,0),r=Math.random()*tw,idx=0;for(let i=0;i<WHEEL.length;i++){r-=WHEEL[i].w;if(r<=0){idx=i;break}}
  spinning=true;wheelDeg=Math.ceil(wheelDeg/360)*360+360*5+(360-(idx*45+22.5));
  wh.style.transition='transform 4s cubic-bezier(.12,.7,.1,1)';wh.style.transform=`rotate(${wheelDeg}deg)`;
  for(let i=0;i<8;i++)setTimeout(()=>snd('click'),i*420);
  setTimeout(()=>{
    spinning=false;const s=WHEEL[idx];let msg='';
    if(s.t==='gold'){prof.gold+=s.v;msg='+'+s.v+' गोल्ड'}
    else if(s.t==='gems'){prof.gems+=s.v;msg='+'+s.v+' डायमंड'}
    else if(s.t==='crate'){prof.crates[s.v]=(prof.crates[s.v]||0)+1;msg=CRATES[s.v].n+' मिला'}
    else{const it=rollItem(s.v);if(it){grant(it);msg=it.n+' मिला!'}else{prof.gold+=300;msg='+300 गोल्ड'}}
    save();snd('win');toast(msg);ptab.luckMsg=msg;render();
  },4200);
}

/* ---- character ---- */
function pOut(){
  const o=ITEMS[prof.eq.o]||OUT[0],w=h('div',{class:'split'});
  w.append(h('div',{class:'bigpv',style:'--rc:'+RAR[o.r][1]},pv(o,200,280),h('b',null,o.n),h('small',null,RAR[o.r][0])));
  w.append(h('div',null,h('p',{class:'dim'},'किसी भी आउटफ़िट को खरीदकर लगाओ। असली मैच में तुम्हारा किरदार यही दिखेगा।'),igrid(OUT)));
  return w;
}
/* ---- pets ---- */
function pPet(){
  const w=h('div');
  w.append(h('p',{class:'dim'},'पेट मैच में तुम्हारे साथ चलता है और छोटा-सा फ़ायदा देता है।'));
  w.append(h('div',{class:'grid'},[h('div',{class:'it'+(prof.eq.p?'':' eq'),style:'--rc:#888'},h('div',{class:'big'},'—'),h('b',null,'कोई पेट नहीं'),h('button',{class:'sm',onclick:()=>{prof.eq.p='';save();render()}},'चुनो')),...PETS.map(card)]));
  return w;
}
/* ---- weapons ---- */
function pWeap(){
  const w=h('div');
  w.append(h('h3',null,'स्किन'));w.append(igrid(WSK));
  w.append(h('h3',null,'सभी हथियार'));
  const bar=(v,m)=>h('i',{class:'sb'},h('u',{style:'width:'+clamp(v/m*100,4,100)+'%'}));
  w.append(h('div',{class:'wlist'},WKEYS.map(k=>{
    const x=WP[k],c=document.createElement('canvas');c.width=240;c.height=100;c.style.width='120px';c.style.height='50px';
    const g=c.getContext('2d');g.scale(2,2);const sk=ITEMS[prof.eq.w];drawGunIcon(g,k,60,25,.62,sk&&sk.col||null);
    return h('div',{class:'wi',style:'--rc:'+RAR[x.tier][1]},c,h('div',null,h('b',null,x.n),h('small',null,RAR[x.tier][0]+' · मैगज़ीन '+x.mag),
      h('div',{class:'stats'},h('span',null,'डैमेज'),bar(x.dmg*x.pel,100),h('span',null,'रेट'),bar(1/x.rate,12),h('span',null,'रेंज'),bar(x.range,1200))));
  })));
  return w;
}
/* ---- collection ---- */
function pCol(){
  const all=Object.values(ITEMS),have=all.filter(i=>owned(i.id)).length,pct=Math.floor(have/all.length*100);
  const w=h('div');
  w.append(h('div',{class:'row2'},h('b',{class:'big2'},have+' / '+all.length+' आइटम'),h('span',{class:'dim'},pct+'% पूरा')));
  w.append(h('div',{class:'bar'},h('i',{style:'width:'+pct+'%;background:var(--accent)'})));
  const ms=[[25,'g',500],[50,'d',20],[75,'d',40],[100,'d',100]];
  w.append(h('div',{class:'row2 wrap'},ms.map(([p,c,v])=>{const cl=prof.col[p],ok=pct>=p;return h('button',{class:'sm'+(ok&&!cl?' pri':'')+(!ok||cl?' off':''),onclick:()=>{if(!ok||cl)return;prof.col[p]=1;if(c==='g')prof.gold+=v;else prof.gems+=v;save();snd('heal');render()}},p+'%: '+v+(c==='g'?' गोल्ड':' ◆')+(cl?' ✓':''))})));
  for(const [cat,n] of Object.entries(CATN)){w.append(h('h3',null,n));w.append(igrid(all.filter(i=>i.cat===cat)))}
  return w;
}
/* ---- pass ---- */
function giveReward(r){
  if(r.t==='gold')prof.gold+=r.v;else if(r.t==='gems')prof.gems+=r.v;
  else{const it=ITEMS[r.v];if(owned(it.id))prof.gold+=50*(it.r+1);else prof.owned[it.id]=1}
}
const rtext=r=>r.t==='gold'?r.v+' गोल्ड':r.t==='gems'?r.v+' ◆':ITEMS[r.v].n;
function pPass(){
  const lv=Math.min(30,Math.floor(prof.xp/100)),w=h('div');
  w.append(h('div',{class:'row2'},h('b',{class:'big2'},'पास लेवल '+lv+' / 30'),prof.pass.prem?h('span',{class:'tag'},'प्रीमियम चालू'):h('button',{class:'sm pri',onclick:()=>{if(prof.gems<150){toast('150 डायमंड चाहिए');return}prof.gems-=150;prof.pass.prem=true;save();snd('win');render()}},'प्रीमियम · 150 ◆')));
  w.append(h('p',{class:'dim'},'हर मैच से XP मिलता है। हर 100 XP पर एक लेवल।'));
  w.append(h('div',{class:'plist'},PASS.map(r=>{
    const up=lv>=r.l;
    const cell=(k,rw,prem)=>{const key=k+r.l,cl=prof.pass.cl[key],lock=prem&&!prof.pass.prem;return h('button',{class:'pc'+(up&&!lock&&!cl?' go':'')+(cl?' done':'')+(!up||lock?' off':''),onclick:()=>{if(!up||lock||cl)return;prof.pass.cl[key]=1;giveReward(rw);save();snd('pick');render()}},rtext(rw),cl?' ✓':'')};
    return h('div',{class:'pr'},h('span',{class:'pl'},r.l),cell('f',r.free,false),cell('p',r.prem,true));
  })));
  return w;
}
/* ---- mode & map ---- */
function pMode(){
  const w=h('div');
  w.append(h('h3',null,'मोड'));
  w.append(h('div',{class:'grid wide'},MODES.map(m=>h('button',{class:'mc'+(prof.mode===m.id?' on':''),onclick:()=>{prof.mode=m.id;save();render()}},h('b',null,m.n),h('small',null,m.d)))));
  w.append(h('h3',null,'मैप ('+MAPS.length+' असली जगहें)'));
  w.append(h('div',{class:'grid wide'},MAPS.map((m,i)=>h('button',{class:'mc map'+(prof.map===i?' on':''),style:`--a:${m.g[0]};--b:${m.g[1]};--w:${m.wat}`,onclick:()=>{prof.map=i;save();render()}},
    h('div',{class:'sw'}),h('b',null,m.n),h('small',null,m.loc+' · '+(m.size/1000).toFixed(1)+' किमी'),h('small',null,({clear:'साफ़ मौसम',rain:'बारिश',snow:'बर्फ़बारी',blizzard:'बर्फ़ीला तूफ़ान',sand:'रेतीली आँधी',ash:'राख',mist:'धुंध'}[m.wx])+(m.night?' · रात':'')+(m.urb?' · शहर':''))))));
  return w;
}
/* ---- settings ---- */
function pSet(){
  const w=h('div',{class:'sets'});
  const row=(l,c)=>h('div',{class:'srow'},h('label',null,l),c);
  const sl=(k,min,max,step,after)=>{const v=h('b',null,String(set[k]));return h('div',{class:'sl'},h('input',{type:'range',min,max,step,value:set[k],oninput:e=>{set[k]=+e.target.value;v.textContent=set[k];save();if(after)after()}}),v)};
  const seg=(k,opts,after)=>h('div',{class:'seg'},opts.map(([id,l])=>h('button',{class:set[k]===id?'on':'',onclick:()=>{set[k]=id;save();if(after)after();render()}},l)));
  const tg=(k,after)=>h('div',{class:'seg'},[[true,'चालू'],[false,'बंद']].map(([id,l])=>h('button',{class:set[k]===id?'on':'',onclick:()=>{set[k]=id;save();if(after)after();render()}},l)));
  w.append(h('h3',null,'प्रोफ़ाइल'));
  w.append(row('नाम',h('input',{type:'text',maxlength:'14',value:prof.name,class:'txt',oninput:e=>{prof.name=e.target.value||'Player';save()}})));
  w.append(h('h3',null,'ग्राफ़िक्स'));
  w.append(row('क्वालिटी',seg('gfx',[['low','लो'],['med','मीडियम'],['high','हाई'],['ultra','अल्ट्रा']],resize)));
  w.append(h('p',{class:'dim'},'मैप की क्वालिटी अगले मैच से बदलेगी। अल्ट्रा में पानी की लहरें, रोशनी और चमक सबसे ज़्यादा है।'));
  w.append(row('कैमरा ज़ूम',sl('zoom',.7,1.4,.05,resize)));
  w.append(h('h3',null,'कंट्रोल और सेंसिटिविटी'));
  w.append(row('एम सेंसिटिविटी (स्वाइप)',sl('aim',.3,2.5,.1)));
  w.append(row('फायर बटन सेंसिटिविटी',sl('fsens',.3,2.5,.1)));
  w.append(row('जॉयस्टिक साइज़',sl('joy',.7,1.5,.05)));
  w.append(row('बटन साइज़',sl('btn',.7,1.4,.05,applyTouchUI)));
  w.append(row('ऑटो-एम असिस्ट (फायर बटन दबाने पर नज़दीकी दुश्मन पर लॉक)',tg('assist')));
  w.append(row('ऑटो-एम रेडियस',sl('aimRadius',200,700,25)));
  w.append(row('ऑटो-फायर (दुश्मन रेडियस में आते ही)',tg('autoFire')));
  w.append(row('फायर बटन ड्रैग',seg('dragFire',[['release','छोड़ने पर फायर'],['hold','ड्रैग में फायर']])));
  w.append(row('ड्रैग छोड़ने के बाद फायर जारी रहे',tg('contFire')));
  w.append(h('p',{class:'dim'},'सिर्फ़ टैप = ऑटो-एम से फायर। फायर बटन ड्रैग करो = अपना निशाना (ऑटो-एम बंद), छोड़ने के 0.5 सेकंड बाद ऑटो-एम वापस।'));
  w.append(row('फ्लोटिंग जॉयस्टिक',tg('float')));
  w.append(row('ऑन-स्क्रीन बटन',seg('show',[['auto','ऑटो'],['on','हमेशा'],['off','बंद']],applyTouchUI)));
  w.append(row('टच कंट्रोल लेआउट',h('button',{class:'sm',onclick:openLayoutEditor},'बटन खिसकाओ / एडजस्ट करो')));
  w.append(row('लूट ऑटो-पिकअप (बंद = उठाने का बटन दिखेगा)',tg('autopick')));
  w.append(row('फुलस्क्रीन + लैंडस्केप लॉक',h('button',{class:'sm',onclick:goLandscape},'चालू करो')));
  w.append(h('h3',null,'आवाज़'));
  w.append(row('वॉल्यूम',sl('vol',0,1,.05)));
  w.append(h('div',{class:'keys'},h('b',null,'कीबोर्ड: '),'WASD चलो · माउस निशाना/फायर · R रीलोड · Q हथियार बदलो · G ग्रेनेड · T स्मोक · C ग्लू वॉल · H बैंडेज · J मेडकिट · Esc पॉज़'));
  w.append(h('div',{class:'row2'},h('button',{class:'sm',onclick:()=>{Object.assign(set,DEF.set,{gfx:set.gfx});set.layout={};save();render();applyTouchUI()}},'कंट्रोल रीसेट करो')));
  return w;
}
