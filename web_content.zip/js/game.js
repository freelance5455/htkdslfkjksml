class Game {
  constructor() {
    this.scene = null;
    this.camera = null;
    this.renderer = null;
    this.player = null;
    this.bots = [];
    this.map = null;
    this.zone = null;
    this.ui = null;
    this.running = false;
    this.clock = new THREE.Clock();
    this.bullets = [];
    this.aliveCount = 30;
    this.selectedChar = 0;
    this.totalPlayers = 13;
  }

  init() {
    // Renderer - optimized for Android WebView
    this.renderer = new THREE.WebGLRenderer({
      antialias: false,
      alpha: false,
      powerPreference: 'high-performance',
      failIfMajorPerformanceCaveat: false
    });
    this.renderer.setClearColor(0x87ceeb, 1);
    this.renderer.setSize(window.innerWidth, window.innerHeight, true);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.domElement.style.position = 'absolute';
    this.renderer.domElement.style.top = '0';
    this.renderer.domElement.style.left = '0';
    this.renderer.domElement.style.zIndex = '1';
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';
    document.body.insertBefore(this.renderer.domElement, document.body.firstChild);

    // Scene & Camera
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(65, window.innerWidth / window.innerHeight, 0.1, 250);
    this.camera.position.set(0, 8, 12);

    // Map
    this.map = new GameMap(this.scene);

    // UI
    this.ui = new UIManager(this);

    // Resize + orientation
    const onResize = () => {
      const w = window.innerWidth;
      const h = window.innerHeight;
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(w, h, true);
    };
    window.addEventListener('resize', onResize);
    window.addEventListener('orientationchange', () => setTimeout(onResize, 200));

    // Prevent default touch behaviors
    document.addEventListener('touchmove', e => e.preventDefault(), { passive: false });
    document.addEventListener('gesturestart', e => e.preventDefault());

    this.applyQuality(window.gameSettings?.quality || 'medium');

    // Continuous render even on menu (so canvas is not black when starting)
    this._menuRender = true;
    const menuLoop = () => {
      if (this._menuRender && !this.running) {
        this.renderer.render(this.scene, this.camera);
        requestAnimationFrame(menuLoop);
      }
    };
    menuLoop();
  }

  applyQuality(q) {
    if (!this.renderer) return;
    if (q === 'low') {
      this.renderer.setPixelRatio(1);
      this.renderer.shadowMap.enabled = false;
      this.scene.fog.far = 100;
    } else if (q === 'high') {
      this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      this.renderer.shadowMap.enabled = true;
      this.scene.fog.far = 180;
    } else {
      this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
      this.renderer.shadowMap.enabled = true;
      this.scene.fog.far = 140;
    }
  }

  startGame() {
    // Clear previous
    this.cleanupEntities();

    this._menuRender = false;
    this.ui.showScreen(null);
    this.ui.showHUD(true);
    this.running = true;
    this.aliveCount = this.totalPlayers;
    this.bullets = [];

    // Player
    this.player = new Player(this.scene, this.camera, true);
    this.player.position.set(
      Utils.randomRange(-15, 15),
      1.0,
      Utils.randomRange(-15, 15)
    );
    this.player.mesh.position.copy(this.player.position);
    this.player.spawnProtectUntil = performance.now() / 1000 + 8; // 8s invencível

    // Apply character color
    const colors = [0x2a6fdb, 0x1a1a2e, 0xe74c3c, 0x9b59b6];
    if (this.player.bodyMesh) {
      this.player.bodyMesh.material.color.setHex(colors[this.selectedChar] || colors[0]);
    }

    // Zone
    this.zone = new SafeZone(this.scene);

    // Bots (menos bots = melhor performance no celular)
    const diff = window.gameSettings?.difficulty || 'normal';
    const botCount = this.totalPlayers - 1;
    this.bots = [];
    for (let i = 0; i < botCount; i++) {
      const bot = new Bot(this.scene, i, diff);
      // Spawn longe do jogador
      let bx, bz, tries = 0;
      do {
        bx = Utils.randomRange(-75, 75);
        bz = Utils.randomRange(-75, 75);
        tries++;
      } while (tries < 20 && Math.hypot(bx - this.player.position.x, bz - this.player.position.z) < 35);
      bot.position.set(bx, 1.0, bz);
      bot.mesh.position.copy(bot.position);
      this.bots.push(bot);
    }

    // Qualidade baixa por padrão no mobile
    this.applyQuality(window.gameSettings?.quality || 'low');

    this.clock.start();
    this.animate();
  }

  cleanupEntities() {
    if (this.player && this.player.mesh) {
      this.scene.remove(this.player.mesh);
    }
    this.bots.forEach(b => {
      if (b.mesh) this.scene.remove(b.mesh);
    });
    this.bots = [];
    this.bullets.forEach(b => {
      if (b.mesh) this.scene.remove(b.mesh);
    });
    this.bullets = [];
    if (this.zone) {
      if (this.zone.ring) this.scene.remove(this.zone.ring);
      if (this.zone.dangerRing) this.scene.remove(this.zone.dangerRing);
    }
  }

  returnToMenu() {
    this.running = false;
    this.cleanupEntities();
    this.ui.showHUD(false);
    this.ui.showScreen('main-menu');
    this._menuRender = true;
    const menuLoop = () => {
      if (this._menuRender && !this.running) {
        this.renderer.render(this.scene, this.camera);
        requestAnimationFrame(menuLoop);
      }
    };
    menuLoop();
  }

  tryPickup() {
    if (!this.player || !this.player.alive) return;
    const idx = this.map.getLootNear(this.player.position, 3);
    if (idx >= 0) {
      const weapons = ['pistol', 'assault', 'smg', 'shotgun', 'sniper'];
      const r = Math.random();
      if (r < 0.5) {
        this.player.pickupWeapon(weapons[Utils.randomInt(0, weapons.length - 1)]);
      } else if (r < 0.75) {
        this.player.addAmmo(Utils.randomInt(15, 40));
      } else if (r < 0.9) {
        this.player.heal(Utils.randomInt(25, 50));
        AudioManager.pickup();
      } else {
        this.player.addArmor(Utils.randomInt(20, 40));
        AudioManager.pickup();
      }
      this.map.removeLoot(idx);
    }
  }

  processShooting(dt) {
    if (!this.player || !this.player.alive) return;
    const shooting = this.ui.buttons.shoot;
    if (!shooting) return;

    const now = performance.now() / 1000;
    const shot = this.player.tryShoot(now);
    if (!shot) return;

    // Create bullet visual + ray
    const origin = shot.origin;
    const dir = shot.direction.clone();

    // Spread
    dir.x += (Math.random() - 0.5) * shot.spread;
    dir.y += (Math.random() - 0.5) * shot.spread * 0.5;
    dir.z += (Math.random() - 0.5) * shot.spread;
    dir.normalize();

    // Hit detection against bots
    let hit = false;
    let closest = shot.range;
    let hitBot = null;

    for (const bot of this.bots) {
      if (!bot.alive) continue;
      const toBot = bot.position.clone().sub(origin);
      const dist = toBot.length();
      if (dist > shot.range) continue;
      toBot.normalize();
      const dot = dir.dot(toBot);
      if (dot > 0.97 - (dist / shot.range) * 0.05) {
        if (dist < closest) {
          closest = dist;
          hitBot = bot;
          hit = true;
        }
      }
    }

    if (hit && hitBot) {
      const killed = hitBot.takeDamage(shot.damage);
      AudioManager.hit();
      if (killed) {
        this.player.kills++;
        this.aliveCount--;
        this.checkWin();
      }
    }

    // Tracer
    this.spawnTracer(origin, dir, Math.min(closest, shot.range));
  }

  spawnTracer(origin, dir, length) {
    const end = origin.clone().add(dir.clone().multiplyScalar(length));
    const geo = new THREE.BufferGeometry().setFromPoints([origin, end]);
    const mat = new THREE.LineBasicMaterial({
      color: 0xffee88,
      transparent: true,
      opacity: 0.85
    });
    const line = new THREE.Line(geo, mat);
    this.scene.add(line);
    this.bullets.push({ mesh: line, life: 0.08 });
  }

  checkWin() {
    if (this.aliveCount <= 1 && this.player.alive) {
      this.running = false;
      setTimeout(() => this.ui.showVictory(this.player.kills), 800);
    }
  }

  update(dt) {
    if (!this.running) return;

    // Player
    this.player.update(dt, null, null, 95);
    this.processShooting(dt);

    // Zone damage
    if (this.zone && this.player.alive && !this.zone.isInside(this.player.position)) {
      this.player.takeDamage(this.zone.damagePerSecond * dt);
      if (!this.player.alive) {
        this.aliveCount--;
        this.running = false;
        const pos = this.aliveCount + 1;
        setTimeout(() => this.ui.showDefeat(pos, this.player.kills), 600);
      }
    }

    // Bots
    this.bots.forEach(bot => {
      bot.update(dt, this.player, this.bots, this.zone, this.map.lootSpots);
    });

    // Zone
    if (this.zone) this.zone.update(dt);

    // Bullets lifetime
    for (let i = this.bullets.length - 1; i >= 0; i--) {
      this.bullets[i].life -= dt;
      if (this.bullets[i].life <= 0) {
        this.scene.remove(this.bullets[i].mesh);
        this.bullets.splice(i, 1);
      }
    }

    // Count alive
    let alive = this.player.alive ? 1 : 0;
    this.bots.forEach(b => { if (b.alive) alive++; });
    this.aliveCount = alive;

    // Reset look input decay
    if (this.player) {
      this.player.lookInput.x *= 0.5;
      this.player.lookInput.y *= 0.5;
    }

    this.ui.updateHUD();
  }

  animate() {
    if (!this.running && !this.player) return;
    requestAnimationFrame(() => this.animate());

    const dt = Math.min(this.clock.getDelta(), 0.05);
    this.update(dt);
    this.renderer.render(this.scene, this.camera);
  }
}
