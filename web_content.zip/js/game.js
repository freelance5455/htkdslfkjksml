const WIDTH = 1280;
const HEIGHT = 720;
const GROUND = 555;

const TROOPS = {
  swordsman: { cost: 55, hp: 92, damage: 18, speed: 47, range: 35, cooldown: .9, size: 1, ranged: false },
  archer: { cost: 90, hp: 64, damage: 14, speed: 31, range: 205, cooldown: 1.65, size: .94, ranged: true },
  giant: { cost: 160, hp: 290, damage: 55, speed: 22, range: 46, cooldown: 1.5, size: 1.72, ranged: false },
};

const clamp = (n, min, max) => Math.max(min, Math.min(max, n));
const rand = (min, max) => Math.random() * (max - min) + min;

export class BattleGame {
  constructor(canvas, hooks = {}) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d");
    this.hooks = hooks;
    this.running = false;
    this.mode = "campaign";
    this.level = 1;
    this.gold = 280;
    this.blueHp = 100;
    this.redHp = 100;
    this.units = [];
    this.projectiles = [];
    this.particles = [];
    this.elapsed = 0;
    this.economyTimer = 0;
    this.spawnTimer = 2.8;
    this.wave = 1;
    this.spawnedThisWave = 0;
    this.waveCounts = [5, 7, 9];
    this.wavePause = 0;
    this.enemyDefeated = 0;
    this.isPaused = false;
    this.ended = false;
    this.lastFrame = 0;
    this.fpsFrames = 0;
    this.fpsTimer = 0;
    this.net = null;
    this.netPlayers = [];
    this.playerId = null;
    this.selfX = 175;
    this.selfHp = 100;
    this.remoteAttack = 0;
    this.abilityCooldown = 0;
    this.shake = 0;
    this._frame = this._frame.bind(this);
    this.setLevel(1);
  }

  setLevel(level, startingGold = null) {
    this.level = clamp(Math.floor(level), 1, 12);
    this.blueHp = 100;
    this.redHp = 100;
    this.gold = Number.isFinite(startingGold) ? clamp(Math.floor(startingGold), 0, 999999) : this.level === 1 ? 280 : Math.min(580, 170 + this.level * 28);
    this.units = [];
    this.projectiles = [];
    this.particles = [];
    this.elapsed = 0;
    this.economyTimer = 0;
    this.spawnTimer = 2.7;
    this.wave = 1;
    this.spawnedThisWave = 0;
    this.waveCounts = [4 + Math.floor(this.level / 2), 5 + this.level, 7 + this.level];
    this.wavePause = 0;
    this.enemyDefeated = 0;
    this.ended = false;
    this.isPaused = false;
    this._hud();
  }

  startCampaign(level = 1, startingGold = null) {
    if (this.raf) cancelAnimationFrame(this.raf);
    this.mode = "campaign";
    this.net = null;
    this.setLevel(level, startingGold);
    this.running = true;
    this.lastFrame = performance.now();
    this.raf = requestAnimationFrame(this._frame);
  }

  startOnline(net) {
    if (this.raf) cancelAnimationFrame(this.raf);
    this.mode = "online";
    this.net = net;
    this.playerId = net.playerId;
    this.netPlayers = net.players ?? [];
    this.running = true;
    this.isPaused = false;
    this.ended = false;
    this.blueHp = 100;
    this.redHp = 100;
    this.elapsed = 0;
    this.selfX = net.player?.x ?? (net.player?.team === "blue" ? 160 : 1120);
    this.selfHp = net.player?.hp ?? 100;
    this.lastFrame = performance.now();
    this.raf = requestAnimationFrame(this._frame);
  }

  setOnlineState(players, meta = {}) {
    if (this.mode !== "online") return;
    const previous = new Map(this.netPlayers.map((player) => [player.id, player]));
    this.netPlayers = (players ?? []).map((player) => ({
      ...player,
      renderX: previous.get(player.id)?.renderX ?? player.x,
    }));
    if (meta.winner) {
      this.ended = true;
      this.winner = meta.winner;
      this.hooks.onEnd?.(meta.winner === this.playerTeam() ? "win" : "loss");
    }
  }

  playerTeam() {
    return this.netPlayers.find((player) => player.id === this.playerId)?.team ?? this.net?.player?.team ?? "blue";
  }

  recruit(type) {
    if (!this.running || this.isPaused || this.ended || this.mode !== "campaign") return false;
    const stats = TROOPS[type];
    if (!stats || this.gold < stats.cost) {
      this.hooks.onToast?.("Bu birlik için altının yetmiyor.");
      return false;
    }
    this.gold -= stats.cost;
    this.units.push({
      id: crypto.randomUUID(), type, team: "blue", x: 170 + rand(-5, 8), hp: stats.hp,
      maxHp: stats.hp, speed: stats.speed, damage: stats.damage, range: stats.range, ranged: stats.ranged,
      cooldown: rand(.1, .65), facing: 1, animation: rand(0, 20), hurt: 0,
    });
    this.hooks.onSound?.("sword");
    this._hud();
    return true;
  }

  lightning() {
    if (!this.running || this.isPaused || this.ended) return;
    if (this.gold < 70) {
      this.hooks.onToast?.("Yıldırım için 70 altın gerekiyor.");
      return;
    }
    this.gold -= 70;
    this.abilityCooldown = 1.2;
    const targets = this.units.filter((unit) => unit.team === "red" && unit.x < 920).slice(0, 5);
    targets.forEach((unit, index) => {
      this._burst(unit.x, GROUND - 23, "#f9da88", 13);
      unit.hp -= 57;
      unit.hurt = .2;
      if (index === 0) this.hooks.onSound?.("hit");
    });
    if (!targets.length) {
      this._burst(835, GROUND - 120, "#f9da88", 18);
      this.redHp = Math.max(0, this.redHp - 5);
    }
    this.shake = .2;
    this._hud();
  }

  pause() {
    if (this.mode !== "campaign" || this.ended) return;
    this.isPaused = !this.isPaused;
    this.hooks.onPause?.(this.isPaused);
  }

  onlineMove(direction) {
    if (!this.net || this.ended) return;
    const speed = 92;
    const next = clamp(this.selfX + direction * speed, 90, 1190);
    this.selfX = next;
    this.net.send?.({ type: "move", x: Math.round(next), y: GROUND - 42 });
  }

  onlineAttack() {
    if (!this.net || this.ended) return;
    const enemy = this.netPlayers.find((player) => player.team !== this.playerTeam() && player.hp > 0);
    if (!enemy) return;
    this.remoteAttack = .24;
    this.hooks.onSound?.("sword");
    this._burst(this.selfX + (this.playerTeam() === "blue" ? 40 : -40), GROUND - 36, "#f2d187", 5);
    this.net.send?.({ type: "attack", target: enemy.id });
  }

  _frame(now) {
    if (!this.running) return;
    const dt = Math.min(.04, Math.max(0, (now - (this.lastFrame || now)) / 1000));
    this.lastFrame = now;
    if (!this.isPaused && !this.ended) {
      this.elapsed += dt;
      if (this.mode === "campaign") this._updateCampaign(dt);
      else this._updateOnline(dt);
      this._updateParticles(dt);
      this._updateProjectiles(dt);
    }
    this._draw();
    this._fps(dt);
    this.raf = requestAnimationFrame(this._frame);
  }

  _fps(dt) {
    this.fpsFrames++;
    this.fpsTimer += dt;
    if (this.fpsTimer >= .5) {
      this.hooks.onFps?.(Math.round(this.fpsFrames / this.fpsTimer));
      this.fpsFrames = 0;
      this.fpsTimer = 0;
    }
  }

  _updateCampaign(dt) {
    this.economyTimer += dt;
    if (this.economyTimer >= 3.2) {
      this.economyTimer -= 3.2;
      this.gold = Math.min(999, this.gold + 22);
      this._hud();
    }
    if (this.wave <= 3) {
      this.spawnTimer -= dt;
      if (this.spawnTimer <= 0 && this.spawnedThisWave < this.waveCounts[this.wave - 1]) {
        this._spawnEnemy();
        this.spawnedThisWave++;
        this.spawnTimer = rand(2.1, 3.25) * Math.max(.72, 1 - this.level * .018);
      } else if (this.spawnedThisWave >= this.waveCounts[this.wave - 1] && !this.units.some((unit) => unit.team === "red")) {
        this.wavePause += dt;
        if (this.wavePause > 2.7) {
          this.wave++;
          this.spawnedThisWave = 0;
          this.wavePause = 0;
          this.spawnTimer = 1.6;
          this.hooks.onToast?.(this.wave <= 3 ? `DALGA ${this.wave} YAKLAŞIYOR` : "SON DÜŞMANLAR");
        }
      }
    }
    for (const unit of [...this.units]) {
      if (!this.units.includes(unit)) continue;
      unit.animation += dt * (unit.moving ? 9 : 2);
      unit.cooldown -= dt;
      unit.hurt = Math.max(0, unit.hurt - dt);
      const enemy = this._nearestEnemy(unit);
      const baseX = unit.team === "blue" ? 1160 : 120;
      const targetX = enemy ? enemy.x : baseX;
      const direction = Math.sign(targetX - unit.x) || (unit.team === "blue" ? 1 : -1);
      unit.facing = direction;
      const reach = enemy ? (unit.type === "giant" ? 51 : 39) : 40;
      const distance = Math.abs(targetX - unit.x);
      unit.moving = distance > (enemy ? (unit.ranged ? unit.range * .72 : reach) : reach);
      if (unit.moving) unit.x += direction * unit.speed * dt;
      else if (unit.cooldown <= 0) {
        if (enemy) this._attack(unit, enemy);
        else if (unit.team === "blue") {
          this.redHp = Math.max(0, this.redHp - (unit.type === "giant" ? 4 : 1.4));
          unit.cooldown = unit.type === "giant" ? 1.15 : .85;
          if (Math.random() < .32) this.hooks.onSound?.("hit");
          if (this.redHp <= 0) this._finish("win");
        } else {
          this.blueHp = Math.max(0, this.blueHp - (unit.type === "giant" ? 5 : 2));
          unit.cooldown = unit.type === "giant" ? 1.2 : 1;
          this._hud();
          if (this.blueHp <= 0) this._finish("loss");
        }
      }
      if (unit.hp <= 0) {
        this._burst(unit.x, GROUND - 20, unit.team === "blue" ? "#a9c5fa" : "#f09579", 6);
        this.units.splice(this.units.indexOf(unit), 1);
        if (unit.team === "red") {
          this.enemyDefeated++;
          this.gold = Math.min(999, this.gold + 12 + this.level);
          this._hud();
          this.hooks.onSound?.("coin");
        }
      }
    }
    this._updateHUDClock();
  }

  _spawnEnemy() {
    const roll = Math.random();
    const type = this.level > 1 && roll > .82 ? "giant" : roll > .57 ? "archer" : "swordsman";
    const data = TROOPS[type];
    const scale = 1 + this.level * .095;
    this.units.push({
      id: crypto.randomUUID(), type, team: "red", x: 1100 + rand(-14, 20), hp: data.hp * scale,
      maxHp: data.hp * scale, damage: data.damage * scale, speed: data.speed * (1 + this.level * .012),
      range: data.range, ranged: data.ranged, cooldown: rand(.25, 1), facing: -1, animation: rand(0, 20), hurt: 0,
    });
  }

  _nearestEnemy(unit) {
    let nearest = null;
    let distance = Infinity;
    for (const other of this.units) {
      if (other.team === unit.team || other.hp <= 0) continue;
      const current = Math.abs(unit.x - other.x);
      const sight = unit.type === "archer" ? 260 : 95;
      if (current < distance && current < sight) {
        nearest = other;
        distance = current;
      }
    }
    if (!nearest) {
      for (const other of this.units) {
        if (other.team === unit.team || other.hp <= 0) continue;
        if (unit.team === "blue" && other.x < unit.x && unit.x - other.x < 145) {
          nearest = other;
          break;
        }
        if (unit.team === "red" && other.x > unit.x && other.x - unit.x < 145) {
          nearest = other;
          break;
        }
      }
    }
    return nearest;
  }

  _attack(unit, target) {
    const damage = unit.damage ?? TROOPS[unit.type].damage * (unit.team === "red" ? 1 + this.level * .055 : 1);
    unit.cooldown = TROOPS[unit.type].cooldown * rand(.87, 1.13);
    if (unit.ranged) {
      this.projectiles.push({ x: unit.x + unit.facing * 13, y: GROUND - 44 * TROOPS[unit.type].size, target: target.id, team: unit.team, vx: unit.facing * 330, damage, age: 0 });
    } else {
      target.hp -= damage;
      target.hurt = .2;
      if (Math.random() < .3) this.hooks.onSound?.("hit");
      this._burst((unit.x + target.x) / 2, GROUND - 37, unit.team === "blue" ? "#d5d5ce" : "#e9a089", 2);
    }
  }

  _updateProjectiles(dt) {
    for (const projectile of [...this.projectiles]) {
      projectile.x += projectile.vx * dt;
      projectile.age += dt;
      const target = this.units.find((unit) => unit.id === projectile.target);
      if (!target || Math.abs(target.x - projectile.x) < 17 || projectile.age > 1.1) {
        if (target && projectile.age <= 1.1) {
          target.hp -= projectile.damage;
          target.hurt = .18;
          this._burst(projectile.x, projectile.y, "#eed18b", 3);
        }
        this.projectiles.splice(this.projectiles.indexOf(projectile), 1);
      }
    }
  }

  _updateOnline(dt) {
    this.remoteAttack = Math.max(0, this.remoteAttack - dt);
    const self = this.netPlayers.find((p) => p.id === this.playerId);
    for (const player of this.netPlayers) {
      if (player.id !== this.playerId) player.renderX += (player.x - player.renderX) * Math.min(1, dt * 11);
    }
    const blue = this.netPlayers.filter((player) => player.team === "blue");
    const red = this.netPlayers.filter((player) => player.team === "red");
    this.blueHp = blue.length ? Math.round(blue.reduce((sum, player) => sum + player.hp, 0) / blue.length) : 0;
    this.redHp = red.length ? Math.round(red.reduce((sum, player) => sum + player.hp, 0) / red.length) : 0;
    if (self) {
      this.selfHp = self.hp;
      if (Math.abs(self.x - this.selfX) > 85) this.selfX += (self.x - this.selfX) * Math.min(1, dt * 5);
    }
    this._updateHUDClock();
  }

  _updateHUDClock() {
    const total = Math.floor(this.elapsed);
    const min = String(Math.floor(total / 60)).padStart(2, "0");
    const sec = String(total % 60).padStart(2, "0");
    this.hooks.onClock?.(`${min}:${sec}`);
    this._hud();
  }

  _hud() {
    this.hooks.onHud?.({
      gold: this.gold, blue: Math.round(this.blueHp), red: Math.round(this.redHp),
      level: this.level, wave: this.wave, maxWaves: 3, mode: this.mode, selfHp: this.selfHp,
      elapsed: Math.floor(this.elapsed),
    });
  }

  _finish(result) {
    if (this.ended) return;
    this.ended = true;
    this.hooks.onEnd?.(result);
  }

  _burst(x, y, color, count) {
    for (let i = 0; i < count; i++) this.particles.push({
      x, y, vx: rand(-95, 95), vy: rand(-120, 30), life: rand(.22, .65), maxLife: .65,
      color, radius: rand(1.5, 4.5),
    });
  }

  _updateParticles(dt) {
    for (const particle of [...this.particles]) {
      particle.x += particle.vx * dt;
      particle.y += particle.vy * dt;
      particle.vy += 175 * dt;
      particle.life -= dt;
      if (particle.life <= 0) this.particles.splice(this.particles.indexOf(particle), 1);
    }
    this.shake = Math.max(0, this.shake - dt);
  }

  _draw() {
    const ctx = this.ctx;
    const W = WIDTH;
    const H = HEIGHT;
    ctx.save();
    if (this.shake > 0) ctx.translate(rand(-5, 5), rand(-3, 3));
    const sky = ctx.createLinearGradient(0, 0, 0, H);
    sky.addColorStop(0, "#36394f");
    sky.addColorStop(.4, "#676079");
    sky.addColorStop(.66, "#d07b4c");
    sky.addColorStop(1, "#ad693c");
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, W, H);
    this._drawLandscape(ctx, W, H);
    if (this.mode === "campaign") this._drawCampaign(ctx);
    else this._drawOnline(ctx);
    this._drawParticles(ctx);
    ctx.restore();
  }

  _drawLandscape(ctx, W, H) {
    const sunX = W * .53;
    const sunY = H * .34;
    const sun = ctx.createRadialGradient(sunX, sunY, 8, sunX, sunY, 220);
    sun.addColorStop(0, "#ffe4a1");
    sun.addColorStop(.72, "#edbd6d");
    sun.addColorStop(1, "#e8a75400");
    ctx.fillStyle = sun;
    ctx.beginPath();
    ctx.arc(sunX, sunY, 220, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#f8d990";
    ctx.beginPath();
    ctx.arc(sunX, sunY, 105, 0, Math.PI * 2);
    ctx.fill();
    this._dune(ctx, [0, 388, 125, 328, 265, 365, 430, 300, 590, 354, 775, 312, 948, 372, 1120, 317, 1280, 360], "#9b5d3e");
    this._dune(ctx, [0, 459, 156, 392, 342, 439, 511, 365, 704, 428, 914, 376, 1073, 438, 1190, 394, 1280, 420], "#b36b40");
    const ground = ctx.createLinearGradient(0, 440, 0, H);
    ground.addColorStop(0, "#b56d3f");
    ground.addColorStop(1, "#523c33");
    ctx.fillStyle = ground;
    ctx.fillRect(0, GROUND + 9, W, H - GROUND);
    this._dune(ctx, [0, 597, 184, 564, 363, 605, 586, 564, 768, 596, 980, 555, 1122, 586, 1280, 558], "#9a5f3d");
    for (let i = 0; i < 52; i++) {
      const x = (i * 167 + 29) % W;
      const y = 469 + ((i * 61) % 205);
      ctx.fillStyle = i % 2 ? "#e6ac6970" : "#553a2f66";
      ctx.fillRect(x, y, 12 + (i % 6) * 5, 1);
    }
    this._cactus(ctx, 310, GROUND + 10, .67);
    this._cactus(ctx, 967, GROUND + 3, .47);
    this._cactus(ctx, 1175, GROUND + 13, .75);
    this._castle(ctx, 64, "blue");
    this._castle(ctx, 1216, "red");
    const haze = ctx.createLinearGradient(0, 395, 0, 480);
    haze.addColorStop(0, "#e8b77900");
    haze.addColorStop(1, "#f0b77524");
    ctx.fillStyle = haze;
    ctx.fillRect(0, 395, W, 85);
  }

  _dune(ctx, points, color) {
    ctx.beginPath();
    ctx.moveTo(points[0], points[1]);
    for (let i = 2; i < points.length; i += 2) ctx.lineTo(points[i], points[i + 1]);
    ctx.lineTo(WIDTH, HEIGHT);
    ctx.lineTo(0, HEIGHT);
    ctx.closePath();
    ctx.fillStyle = color;
    ctx.fill();
  }

  _cactus(ctx, x, y, scale) {
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(scale, scale);
    ctx.fillStyle = "#49362b";
    ctx.fillRect(-4, -40, 8, 41);
    ctx.fillRect(-4, -29, -13, 6);
    ctx.fillRect(-17, -29, 6, -14);
    ctx.fillRect(3, -22, 13, 6);
    ctx.fillRect(10, -22, 6, -13);
    ctx.restore();
  }

  _castle(ctx, x, team) {
    const color = team === "blue" ? "#2b3040" : "#452c2b";
    const flag = team === "blue" ? "#85a4e0" : "#d87964";
    ctx.fillStyle = "#493930";
    ctx.fillRect(x - 33, GROUND - 84, 66, 87);
    ctx.fillStyle = color;
    ctx.fillRect(x - 39, GROUND - 92, 77, 75);
    ctx.fillRect(x - 48, GROUND - 105, 21, 88);
    ctx.fillRect(x + 24, GROUND - 105, 21, 88);
    for (let i = 0; i < 3; i++) {
      ctx.fillRect(x - 48 + i * 25, GROUND - 113, 13, 12);
      ctx.fillRect(x - 48 + i * 25, GROUND - 26, 10, 10);
    }
    ctx.fillStyle = "#1e1e23";
    ctx.fillRect(x - 8, GROUND - 51, 17, 34);
    ctx.strokeStyle = "#262127";
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(x, GROUND - 112);
    ctx.lineTo(x, GROUND - 147);
    ctx.stroke();
    ctx.fillStyle = flag;
    ctx.beginPath();
    ctx.moveTo(x, GROUND - 146);
    ctx.lineTo(x + (team === "blue" ? 30 : -30), GROUND - 137);
    ctx.lineTo(x, GROUND - 126);
    ctx.fill();
  }

  _drawCampaign(ctx) {
    for (const unit of this.units) this._stickman(ctx, unit);
    for (const bolt of this.projectiles) {
      ctx.save();
      ctx.strokeStyle = bolt.team === "blue" ? "#f3e1ac" : "#f6d1ab";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(bolt.x - Math.sign(bolt.vx) * 7, bolt.y);
      ctx.lineTo(bolt.x, bolt.y - 1);
      ctx.stroke();
      ctx.restore();
    }
    for (let i = 0; i < 9; i++) {
      const x = (this.elapsed * 22 + i * 174) % (WIDTH + 80) - 40;
      const y = GROUND - 5 + Math.sin(this.elapsed * .7 + i) * 5;
      ctx.fillStyle = "#f1d1a015";
      ctx.beginPath();
      ctx.ellipse(x, y, 24 + (i % 3) * 8, 2 + (i % 2), 0, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  _stickman(ctx, unit) {
    const x = unit.x;
    const y = GROUND;
    const base = TROOPS[unit.type];
    const scale = (base?.size ?? 1) * (unit.team === "red" ? 1.04 : 1);
    const color = unit.team === "blue" ? "#172337" : "#382321";
    const trim = unit.team === "blue" ? "#8ca8df" : "#d97b64";
    const face = unit.team === "blue" ? "#34445f" : "#613632";
    const moving = unit.moving ? Math.sin(unit.animation) : 0;
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(scale * (unit.facing || 1), scale);
    ctx.globalAlpha = unit.hp <= 0 ? .35 : 1;
    const hitFlash = unit.hurt > 0;
    ctx.strokeStyle = hitFlash ? "#fff0cc" : color;
    ctx.lineWidth = unit.type === "giant" ? 14 : 8;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    const headY = -68;
    ctx.fillStyle = hitFlash ? "#fff0cc" : face;
    ctx.beginPath();
    ctx.arc(0, headY, unit.type === "giant" ? 17 : 12, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = trim;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(0, headY, unit.type === "giant" ? 19 : 14, -.4, 2.8);
    ctx.stroke();
    ctx.strokeStyle = hitFlash ? "#fff0cc" : color;
    ctx.lineWidth = unit.type === "giant" ? 13 : 7;
    ctx.beginPath();
    ctx.moveTo(0, -54);
    ctx.lineTo(0, -30);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(-2, -47);
    ctx.lineTo(-13, -37 + moving * 4);
    ctx.lineTo(-19, -51 + moving * 6);
    ctx.moveTo(2, -47);
    if (unit.type === "archer") {
      ctx.lineTo(14, -46);
      ctx.lineTo(20, -61);
      ctx.stroke();
      ctx.strokeStyle = trim;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(18, -56, 13, -1.2, 1.1);
      ctx.stroke();
    } else {
      ctx.lineTo(14, -42 + moving * 4);
      ctx.lineTo(24, -50 + moving * 8);
      ctx.stroke();
      ctx.strokeStyle = "#d4c69e";
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(24, -50 + moving * 8);
      ctx.lineTo(39, -70 + moving * 8);
      ctx.stroke();
    }
    ctx.strokeStyle = hitFlash ? "#fff0cc" : color;
    ctx.lineWidth = unit.type === "giant" ? 14 : 7;
    ctx.beginPath();
    ctx.moveTo(0, -30);
    ctx.lineTo(-9 + moving * 10, -13);
    ctx.lineTo(-16 - moving * 13, -2);
    ctx.moveTo(0, -30);
    ctx.lineTo(8 - moving * 10, -13);
    ctx.lineTo(14 + moving * 13, -2);
    ctx.stroke();
    if (unit.type === "giant") {
      ctx.fillStyle = "#cbb489";
      ctx.fillRect(17, -82, 4, 40);
      ctx.fillRect(11, -85, 16, 4);
    }
    const barWidth = unit.type === "giant" ? 48 : 29;
    const ratio = clamp(unit.hp / unit.maxHp, 0, 1);
    ctx.fillStyle = "#241f21aa";
    ctx.fillRect(-barWidth / 2, -98 * scale, barWidth, 3);
    ctx.fillStyle = unit.team === "blue" ? "#85aae7" : "#e88168";
    ctx.fillRect(-barWidth / 2, -98 * scale, barWidth * ratio, 3);
    ctx.restore();
  }

  _drawOnline(ctx) {
    const team = this.playerTeam();
    const players = this.netPlayers;
    for (const player of players) {
      const me = player.id === this.playerId;
      const unit = {
        x: me ? this.selfX : player.renderX ?? player.x,
        team: player.team,
        hp: me ? this.selfHp : player.hp,
        maxHp: 100,
        type: "swordsman",
        facing: me ? (team === "blue" ? 1 : -1) : (player.team === "blue" ? 1 : -1),
        animation: this.elapsed * 10 + player.x * .01,
        moving: false,
        hurt: me && this.remoteAttack > 0 ? .2 : 0,
      };
      this._stickman(ctx, unit);
      ctx.fillStyle = "#fff5e2";
      ctx.font = "600 13px DM Sans, sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(player.username ?? (me ? "Sen" : "Savaşçı"), unit.x, GROUND - 105);
      ctx.textAlign = "start";
    }
    for (let i = 0; i < 12; i++) {
      const x = (i * 127 + 50) % WIDTH;
      const y = 280 + Math.sin(i * 3 + this.elapsed) * 140;
      ctx.fillStyle = "#fff3d7";
      ctx.globalAlpha = .1;
      ctx.fillRect(x, y, 2, 2);
      ctx.globalAlpha = 1;
    }
  }

  _drawParticles(ctx) {
    for (const particle of this.particles) {
      ctx.globalAlpha = clamp(particle.life / particle.maxLife, 0, 1);
      ctx.fillStyle = particle.color;
      ctx.beginPath();
      ctx.arc(particle.x, particle.y, particle.radius, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  dispose() {
    this.running = false;
    if (this.raf) cancelAnimationFrame(this.raf);
  }
}
