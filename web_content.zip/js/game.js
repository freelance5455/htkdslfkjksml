/* Zombie Night - game code (three.js r128). Assets are loaded from the assets/ folder, see assets-config.js */

(function(){
const $=id=>document.getElementById(id);
const renderer=new THREE.WebGLRenderer({antialias:!(navigator.maxTouchPoints>0)&&devicePixelRatio<2,powerPreference:'high-performance'});
renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));
renderer.outputEncoding=THREE.sRGBEncoding;
renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFShadowMap;
document.body.prepend(renderer.domElement);
const scene=new THREE.Scene();
// sky
const sc=document.createElement('canvas');sc.width=2;sc.height=256;const sx=sc.getContext('2d');
const g=sx.createLinearGradient(0,0,0,256);g.addColorStop(0,'#020412');g.addColorStop(.6,'#0a1330');g.addColorStop(1,'#16264d');sx.fillStyle=g;sx.fillRect(0,0,2,256);
const sky=new THREE.CanvasTexture(sc);sky.encoding=THREE.sRGBEncoding;scene.background=sky;
scene.fog=new THREE.Fog(0x0e1a35,14,82);
const cam=new THREE.PerspectiveCamera(48,1,.1,260);
scene.add(new THREE.HemisphereLight(0x7f95d6,0x1f3020,.7));
const lamp=new THREE.PointLight(0xffc070,1.6,20,2);scene.add(lamp);
const skyG=new THREE.Group();scene.add(skyG);
{const n=700,p=new Float32Array(n*3);for(let i=0;i<n;i++){const a=Math.random()*6.28,y=.05+Math.random()*.95,r=Math.sqrt(1-y*y)*200;p[i*3]=Math.cos(a)*r;p[i*3+1]=y*200;p[i*3+2]=Math.sin(a)*r}
 const gg=new THREE.BufferGeometry();gg.setAttribute('position',new THREE.BufferAttribute(p,3));skyG.add(new THREE.Points(gg,new THREE.PointsMaterial({color:0xffffff,size:1.8,sizeAttenuation:false,fog:false})));
 const mo=new THREE.Mesh(new THREE.SphereGeometry(9,24,16),new THREE.MeshBasicMaterial({color:0xf6f1d4,fog:false}));mo.position.set(-90,100,-130);skyG.add(mo);
 const gl=new THREE.Mesh(new THREE.SphereGeometry(15,24,16),new THREE.MeshBasicMaterial({color:0x8fa8ff,transparent:true,opacity:.18,fog:false,depthWrite:false}));gl.position.copy(mo.position);skyG.add(gl)}
const sun=new THREE.DirectionalLight(0x9db4ff,.95);sun.castShadow=true;sun.shadow.mapSize.set(512,512);
const sh=sun.shadow.camera;sh.left=-20;sh.right=20;sh.top=20;sh.bottom=-20;sh.near=1;sh.far=90;sun.shadow.bias=-.0006;
scene.add(sun,sun.target);
function resize(){const w=innerWidth,h=innerHeight;renderer.setSize(w,h);cam.aspect=w/h;cam.updateProjectionMatrix()}
addEventListener('resize',resize);resize();
let WR=2,ZCAP=16;

// ================= WORLD (endless, chunked) =================
const CS=32,HC=120,GC=8;
const WD=ASSETS.world,WT={},MODELS=[],MIDX={},opened=new Set();
function ldTex(u){return new Promise(r=>new THREE.TextureLoader().load(u,x=>{x.flipY=false;x.encoding=THREE.sRGBEncoding;x.anisotropy=4;r(x)},undefined,()=>r(null)))}
function hash2(a,b){let h=(Math.imul(a|0,374761393)+Math.imul(b|0,668265263))|0;h=Math.imul(h^(h>>>13),1274126177);return(h^(h>>>16))>>>0}
function rng(s){s=s>>>0;return()=>{s=(s+0x6D2B79F5)>>>0;let t=s;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296}}
// ground follows the player (tile-snapped => seamless, no edge)
const gc=document.createElement('canvas');gc.width=gc.height=256;const gx=gc.getContext('2d');
gx.fillStyle='#5a9238';gx.fillRect(0,0,256,256);
for(let i=0;i<2800;i++){gx.fillStyle=`hsla(${80+Math.random()*35},${35+Math.random()*25}%,${26+Math.random()*22}%,.5)`;gx.fillRect(Math.random()*256,Math.random()*256,2+Math.random()*5,2+Math.random()*5)}
const gt=new THREE.CanvasTexture(gc);gt.wrapS=gt.wrapT=THREE.RepeatWrapping;gt.repeat.set(120,120);gt.encoding=THREE.sRGBEncoding;gt.anisotropy=2;
const ground=new THREE.Mesh(new THREE.PlaneGeometry(600,600),new THREE.MeshLambertMaterial({map:gt}));
ground.rotation.x=-Math.PI/2;ground.receiveShadow=true;scene.add(ground);
const loader=new THREE.GLTFLoader();
const parse=(d)=>new Promise((res,rej)=>loader.parse(d,'',res,rej));
const rnd=(a,b)=>a+Math.random()*(b-a);

// ---- houses (deterministic, one per ~120m cell) ----
const hcache=new Map();
function houseSpec(i,j){return null;const k=i+','+j;if(hcache.has(k))return hcache.get(k);const r=rng(hash2(i+500,j+700));let h=null;
  if(i===0&&j===-1)h={x:20,z:-46};else if(r()<.8)h={x:i*HC+16+r()*(HC-32),z:j*HC+16+r()*(HC-32)};
  if(h){h.id=k;h.w=9+Math.floor(r()*4);h.d=8+Math.floor(r()*3);h.t=r()}
  hcache.set(k,h);return h}
function nearHouses(x,z,n){const o=[],ci=Math.floor(x/HC),cj=Math.floor(z/HC);for(let i=ci-n;i<=ci+n;i++)for(let j=cj-n;j<=cj+n;j++){const h=houseSpec(i,j);if(h)o.push(h)}return o}
function inHouseZone(x,z,m){for(const h of nearHouses(x,z,1)){if(x>h.x-h.w/2-m&&x<h.x+h.w/2+m&&z>h.z-h.d/2-m&&z<h.z+h.d/2+m+8)return true}return false}
const HM={floor:new THREE.MeshStandardMaterial({color:0x6b4a2e,roughness:.9}),roof:new THREE.MeshStandardMaterial({color:0x7a2f22,roughness:.9}),
 trim:new THREE.MeshStandardMaterial({color:0x3b2a1c,roughness:.9}),wood:new THREE.MeshStandardMaterial({color:0x8a5a34,roughness:.85}),dark:new THREE.MeshStandardMaterial({color:0x4a2f1c,roughness:.85}),
 cloth:new THREE.MeshStandardMaterial({color:0x3d5a8c,roughness:1}),red:new THREE.MeshStandardMaterial({color:0x8c2f2f,roughness:1}),stone:new THREE.MeshStandardMaterial({color:0x7d7d84,roughness:1}),
 glow:new THREE.MeshBasicMaterial({color:0xffd27a}),gold:new THREE.MeshBasicMaterial({color:0xffcf3a})};
function mergeStatic(g,keep){
  const by=new Map(),list=g.children.filter(o=>o.isMesh&&!keep.includes(o));
  for(const m of list){m.updateMatrix();const geo=m.geometry.clone().applyMatrix4(m.matrix);let a=by.get(m.material);if(!a)by.set(m.material,a=[]);a.push(geo.index?geo.toNonIndexed():geo);g.remove(m);m.geometry.dispose()}
  for(const [mat,geos] of by){let total=0;geos.forEach(x=>total+=x.attributes.position.count);
    const pos=new Float32Array(total*3),nor=new Float32Array(total*3),uv=new Float32Array(total*2);let o3=0,o2=0;
    for(const x of geos){pos.set(x.attributes.position.array,o3);nor.set(x.attributes.normal.array,o3);if(x.attributes.uv)uv.set(x.attributes.uv.array,o2);o3+=x.attributes.position.count*3;o2+=x.attributes.position.count*2}
    const mg=new THREE.BufferGeometry();mg.setAttribute('position',new THREE.BufferAttribute(pos,3));mg.setAttribute('normal',new THREE.BufferAttribute(nor,3));mg.setAttribute('uv',new THREE.BufferAttribute(uv,2));
    g.add(new THREE.Mesh(mg,mat))}
}
const doorMem=new Map();
HM.bush=new THREE.MeshStandardMaterial({color:0x3f8a3a,roughness:1});HM.fire=new THREE.MeshBasicMaterial({color:0xff7a2a});
HM.fl=[0xe0405a,0xffd23a,0xff8fc8,0xffffff].map(c=>new THREE.MeshBasicMaterial({color:c}));
function roofGeo(xe,ye,yr,ze){const L0=[-xe,ye,-ze],L1=[-xe,ye,ze],R0=[xe,ye,-ze],R1=[xe,ye,ze],T0=[0,yr,-ze],T1=[0,yr,ze];
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(new Float32Array([...L0,...L1,...T1,...L0,...T1,...T0,...R1,...R0,...T0,...R1,...T0,...T1]),3));g.computeVertexNormals();return g}
function gableGeo(w,H,yr,z,dir){const a=[-w/2,H,z],b=[w/2,H,z],c=[0,yr,z],g=new THREE.BufferGeometry();
  g.setAttribute('position',new THREE.BufferAttribute(new Float32Array(dir>0?[...a,...b,...c]:[...b,...a,...c]),3));g.computeVertexNormals();return g}
function buildHouse(h){
  const g=new THREE.Group();g.position.set(h.x,0,h.z);
  const w=h.w,d=h.d,H=3.4,t=.35,dw=2.1,sw=(w-dw)/2,rects=[],fade=[];
  const pal=[[0xe8dcc0,0x6e2c22,0x5a3a22],[0xc9d3dc,0x3f4f66,0x4a3a2c],[0xf0e2a8,0x7a3b24,0x5a3a22]][Math.floor(h.t*3)%3];
  const FM=(c,r,basic)=>{const m=basic?new THREE.MeshBasicMaterial({color:c,transparent:true}):new THREE.MeshStandardMaterial({color:c,roughness:r||.9,transparent:true});fade.push(m);return m};
  const wall=FM(pal[0],.95),wood=FM(pal[2],.85),white=FM(0xf4f1e8,.8),stn=FM(0x8b8c92,1),porchM=FM(0x7c5430,.85),glass=FM(0xffd98a,0,true),
        roofM=new THREE.MeshStandardMaterial({color:pal[1],roughness:.85,side:THREE.DoubleSide});
  const B=(sx,sy,sz,m,x,y,z,p,rx)=>{const o=new THREE.Mesh(new THREE.BoxGeometry(sx,sy,sz),m);o.position.set(x,y,z);if(rx)o.rotation.x=rx;(p||g).add(o);return o};
  const Rr=(x0,x1,z0,z1)=>rects.push({x0:h.x+x0,x1:h.x+x1,z0:h.z+z0,z1:h.z+z1});
  // walls (the doorway is left open for the door)
  B(w,H,t,wall,0,H/2,-d/2+t/2);Rr(-w/2,w/2,-d/2,-d/2+t);
  B(t,H,d,wall,-w/2+t/2,H/2,0);Rr(-w/2,-w/2+t,-d/2,d/2);
  B(t,H,d,wall,w/2-t/2,H/2,0);Rr(w/2-t,w/2,-d/2,d/2);
  B(sw,H,t,wall,-(dw/2+sw/2),H/2,d/2-t/2);Rr(-w/2,-dw/2,d/2-t,d/2);
  B(sw,H,t,wall,dw/2+sw/2,H/2,d/2-t/2);Rr(dw/2,w/2,d/2-t,d/2);
  B(dw,H-2.6,t,wall,0,2.6+(H-2.6)/2,d/2-t/2);
  // stone base, corner posts and timber beams
  B(w+.5,.3,.28,stn,0,.15,-d/2-.12);B(.28,.3,d+.5,stn,-(w/2+.12),.15,0);B(.28,.3,d+.5,stn,w/2+.12,.15,0);B(sw+.3,.3,.28,stn,-(dw/2+sw/2),.15,d/2+.12);B(sw+.3,.3,.28,stn,dw/2+sw/2,.15,d/2+.12);
  for(const sx of[-1,1])for(const sz of[-1,1])B(.32,H,.32,wood,sx*(w/2+.02),H/2,sz*(d/2+.02));
  B(w+.4,.22,.34,wood,0,H-.11,d/2+.02);B(w+.4,.22,.34,wood,0,H-.11,-d/2-.02);B(.34,.22,d+.4,wood,-(w/2+.02),H-.11,0);B(.34,.22,d+.4,wood,w/2+.02,H-.11,0);
  for(const s of[-1,1]){B(.16,H-.4,.28,wood,s*(w/2-.9),H/2,d/2+.02);B(.16,H-.4,.28,wood,s*(w/2-.9),H/2,-d/2-.02)}
  // windows with frames, glowing glass and flower boxes
  const win=(x,z,ax,o)=>{const fz=ax==='z',ox=fz?0:o,oz=fz?o:0;
    B(fz?1.3:.14,1.1,fz?.14:1.3,white,x,1.9,z);B(fz?1.05:.06,.85,fz?.06:1.05,glass,x+ox*.05,1.9,z+oz*.05);
    B(fz?1.3:.1,.07,fz?.1:1.3,white,x+ox*.07,1.9,z+oz*.07);B(fz?.07:.1,1.1,fz?.1:.07,white,x+ox*.07,1.9,z+oz*.07);
    const bx=x+ox*.22,bz=z+oz*.22;B(fz?1.45:.3,.22,fz?.3:1.45,wood,bx,1.2,bz);
    for(let i=-2;i<=2;i++)B(.15,.17,.15,HM.fl[(i+3)%4],bx+(fz?i*.26:0),1.38,bz+(fz?0:i*.26))};
  win(-(dw/2+sw/2),d/2+.04,'z',1);win(dw/2+sw/2,d/2+.04,'z',1);win(0,-d/2-.04,'z',-1);
  for(const sx of[-1,1])for(const zz of[-d/4,d/4])win(sx*(w/2+.04),zz,'x',sx);
  // door frame, porch, steps, lanterns, bushes
  B(.2,2.6,.5,wood,-dw/2,1.3,d/2-t/2);B(.2,2.6,.5,wood,dw/2,1.3,d/2-t/2);B(dw+.45,.26,.5,wood,0,2.72,d/2-t/2);
  B(dw+2.4,.14,2.0,porchM,0,.07,d/2+1.0);B(dw+1.4,.12,.55,stn,0,.06,d/2+2.15);B(dw+.9,.1,.4,stn,0,.05,d/2+2.55);
  for(const s of[-1,1])B(.22,2.7,.22,wood,s*(dw/2+1.05),1.35,d/2+1.85);
  B(dw+3.0,.16,2.6,roofM,0,2.95,d/2+1.1,null,.1);
  for(const s of[-1,1]){const lm=new THREE.Mesh(new THREE.SphereGeometry(.13,10,10),HM.glow);lm.position.set(s*(dw/2+.55),2.35,d/2+.35);g.add(lm);
    const bs=new THREE.Mesh(new THREE.SphereGeometry(.55,9,7),HM.bush);bs.position.set(s*(w/2+.6),.45,d/2+.9);bs.scale.set(1.1,.9,1);g.add(bs)}
  // the door: hinged on the left, swings inward
  const dpiv=new THREE.Group();dpiv.position.set(-dw/2+.06,0,d/2-t/2);g.add(dpiv);
  const doorM=new THREE.MeshStandardMaterial({color:0x5b3a22,roughness:.85}),dm=new THREE.Mesh(new THREE.BoxGeometry(dw-.12,2.5,.09),doorM);dm.position.set((dw-.12)/2,1.25,0);dpiv.add(dm);
  for(let i=1;i<4;i++){const pl=new THREE.Mesh(new THREE.BoxGeometry(.04,2.4,.1),HM.dark);pl.position.set(i*(dw-.12)/4,1.25,0);dpiv.add(pl)}
  const hd=new THREE.Mesh(new THREE.SphereGeometry(.07,8,6),HM.gold);hd.position.set(dw-.28,1.2,.08);dpiv.add(hd);
  const door={id:h.id,pivot:dpiv,open:true,broken:false,hp:300,max:300,ang:1.6,x:h.x,z:h.z+d/2,rect:{x0:h.x-dw/2,x1:h.x+dw/2,z0:h.z+d/2-t-.05,z1:h.z+d/2+.08}};
  const mem=doorMem.get(h.id);if(mem){door.open=mem.open;door.broken=mem.broken;door.hp=mem.hp;door.ang=door.open?1.6:0}
  dpiv.rotation.y=door.ang;if(door.broken)dpiv.visible=false;
  // interior
  const fl=new THREE.Mesh(new THREE.PlaneGeometry(w-t*2,d-t*2),HM.floor);fl.rotation.x=-Math.PI/2;fl.position.y=.03;fl.receiveShadow=true;g.add(fl);
  const lp=new THREE.Mesh(new THREE.SphereGeometry(.17,10,10),HM.glow);lp.position.set(0,H-.5,0);g.add(lp);B(.03,.5,.03,HM.trim,0,H-.25,0);
  const rug=new THREE.Mesh(new THREE.PlaneGeometry(3.2,2.2),HM.red);rug.rotation.x=-Math.PI/2;rug.position.set(0,.045,-.2);g.add(rug);
  B(1.7,1.4,.5,HM.stone,0,.7,-d/2+.45);B(.8,.55,.06,HM.fire,0,.4,-d/2+.72);B(1.9,.1,.6,HM.dark,0,1.45,-d/2+.45);Rr(-.85,.85,-d/2+.2,-d/2+.72);
  const tx=-w/4;B(1.8,.12,1.0,HM.wood,tx,.82,0);for(const a of[-.75,.75])for(const b of[-.38,.38])B(.1,.8,.1,HM.dark,tx+a,.4,b);Rr(tx-.9,tx+.9,-.5,.5);
  const bx=w/2-1.5;B(2.0,.4,1.5,HM.dark,bx,.2,-d/2+1.1);B(1.9,.2,1.4,HM.cloth,bx,.5,-d/2+1.1);B(.5,.15,.9,HM.stone,bx+.65,.68,-d/2+1.1);Rr(bx-1,bx+1,-d/2+.35,-d/2+1.85);
  const sx0=-w/2+1.5;B(2.2,2.1,.4,HM.wood,sx0,1.05,-d/2+.55);for(let i=0;i<5;i++)B(.12,.4,.25,i%2?HM.red:HM.cloth,sx0-.8+i*.4,1.5,-d/2+.6);Rr(sx0-1.1,sx0+1.1,-d/2+.35,-d/2+.75);
  const cx0=w/4+.8;B(2.2,.5,.9,HM.cloth,cx0,.25,d/2-1.5);B(2.2,.55,.2,HM.cloth,cx0,.7,d/2-1.9);Rr(cx0-1.1,cx0+1.1,d/2-2,d/2-1.05);
  const ccx=-w/2+1.2,ccz=d/2-1.3;B(.95,.5,.6,HM.dark,ccx,.25,ccz);B(1,.1,.65,HM.gold,ccx,.55,ccz);Rr(ccx-.5,ccx+.5,ccz-.35,ccz+.35);
  const mk=new THREE.Mesh(new THREE.OctahedronGeometry(.25),HM.gold);mk.position.set(ccx,1.35,ccz);g.add(mk);
  // gable roof with a ridge cap and a chimney (hidden while you are inside)
  const roof=new THREE.Group();g.add(roof);
  const xe=w/2+.8,ze=d/2+.8,ye=H-.1,rh=Math.max(1.9,w*.3),yr=H+rh;
  roof.add(new THREE.Mesh(roofGeo(xe,ye,yr,ze),roofM));
  B(.25,.14,2*ze+.1,HM.dark,0,yr+.05,0,roof);B(.9,3,.9,HM.stone,w/4,H+1.8,-d/4,roof);
  roof.add(new THREE.Mesh(gableGeo(w,H,yr-.12,d/2,1),wall));roof.add(new THREE.Mesh(gableGeo(w,H,yr-.12,-d/2,-1),wall));
  mergeStatic(g,[mk]);
  return{h,g,roof,wall,fade,door,rects,marker:mk,cx:h.x+ccx,cz:h.z+ccz,inside:false}
}
// ---- doors: close one to keep zombies out — they smash it after a while ----
function removeCol(c){for(let i=Math.floor(c.x0/GC);i<=Math.floor(c.x1/GC);i++)for(let j=Math.floor(c.z0/GC);j<=Math.floor(c.z1/GC);j++){const a=colGrid.get(i+','+j);if(a){const k=a.indexOf(c);if(k>=0)a.splice(k,1)}}}
function nearestDoor(){let b=null,bd=3.6;for(const o of houses.values()){const D=o.door;if(!D||D.broken)continue;const dd=Math.hypot(player.x-D.x,player.z-D.z);if(dd<bd){bd=dd;b=o}}return b}
function doorOf(H){const o=H&&houses.get(H.id);return o&&o.door}
function doorNear(z,H){const D=doorOf(H);return !!D&&!D.open&&!D.broken&&!(Math.abs(z.x-H.x)<H.w/2&&Math.abs(z.z-H.z)<H.d/2)&&Math.hypot(z.x-D.x,z.z-(D.z+1.1))<2.4}
function breakDoor(D){D.broken=true;D.open=true;D.pivot.visible=false;removeCol(D.rect);burst(D.x,1.2,D.z,0x8a5a2c,22,7);snd(90,.35,'sawtooth',.18,-40);banner('💥 The door was smashed!');shake=Math.max(shake,.5);doorMem.set(D.id,{open:true,broken:true,hp:0})}
function hitDoor(D,z){D.hp-=z.dmg*1.6;burst(D.x,1.3,D.z+.4,0x8a5a2c,3,3);snd(120,.08,'square',.06,-50);if(D.hp<=0)breakDoor(D);else doorMem.set(D.id,{open:false,broken:false,hp:D.hp})}
function toggleDoor(){if(!running||player.dead||player.car)return;const o=nearestDoor();if(!o)return;const D=o.door;
  if(D.open){if(Math.abs(player.x-D.x)<1.4&&Math.abs(player.z-D.z)<1.3){banner("You're standing in the doorway");return}
    for(const z of zombies){if(!z.dead&&Math.hypot(z.x-D.x,z.z-D.z)<1.9){banner('A zombie is in the way!');return}}
    D.open=false;addCol(D.rect);snd(200,.15,'square',.07,-80)}
  else{D.open=true;removeCol(D.rect);snd(260,.15,'square',.07,100)}
  doorMem.set(o.h.id,{open:D.open,broken:D.broken,hp:D.hp})}
function doorUI(){}

// ---- chunks ----
const chunkCache=new Map();
function genChunk(cx,cz){const k=cx+','+cz;let c=chunkCache.get(k);if(c)return c;
  const r=rng(hash2(cx+9000,cz+9000));c=[];
  const mead=1;
  MODELS.forEach((M,mi)=>{const dn=M.dens*(M.fl?mead:1),n=Math.floor(dn)+(r()<dn%1?1:0);for(let i=0;i<n;i++){const x=cx*CS+r()*CS,z=cz*CS+r()*CS,rot=r()*6.28,s=M.lo+r()*(M.hi-M.lo);
    if(M.r>0&&x*x+z*z<40)continue;if(inHouseZone(x,z,M.r>0?4:2))continue;c.push({mi,x,z,rot,s,q:(hash2(Math.floor(x*13),Math.floor(z*13))%1000)/1000})}});
  chunkCache.set(k,c);return c}
async function buildWorld(){
  for(const k in WD.tex)WT[k]=await ldTex(WD.tex[k]);
  let ok=0,tot=Object.keys(WD.defs).length;
  for(const [name,d] of Object.entries(WD.defs)){
   try{
    $('go').textContent='Loading '+(++ok)+'/'+tot;
    const gl=await parse(await fbuf(WD.glb[name]));gl.scene.updateMatrixWorld(true);
    const M={name,r:d[0],dens:d[1]*(d[2]<2?.7:1)*(/^Rock_Medium/.test(name)?.5:/^Pebble/.test(name)?.4:/^DeadTree/.test(name)?.5:/^Bush_Common_Flowers/.test(name)?.65:/^Flower_4/.test(name)?.75:1),lr:d[2],lo:d[3],hi:d[4],parts:[],fl:/^(Flower|Petal)/.test(name)};
    M.cap=Math.ceil(d[1]*Math.pow(2*d[2]+1,2)*(M.fl?3.2:1.8))+10+(d[1]===0?60:0);
    gl.scene.traverse(o=>{if(!o.isMesh)return;const geo=o.geometry.clone().applyMatrix4(o.matrixWorld),mat=o.material,mn=mat.userData&&mat.userData.map;
      if(mn&&WT[mn]){mat.map=WT[mn];mat.color.set(0xffffff)}mat.side=THREE.DoubleSide;mat.needsUpdate=true;
      const lm=new THREE.MeshLambertMaterial({map:mat.map,color:0xffffff,side:THREE.DoubleSide,alphaTest:mat.alphaTest||0});const im=new THREE.InstancedMesh(geo,lm,M.cap);im.frustumCulled=false;im.count=0;im.castShadow=false;scene.add(im);M.parts.push(im)});
    MIDX[name]=MODELS.length;MODELS.push(M)
   }catch(e){$('errmsg').textContent+=' ['+name+': '+(e&&e.message||e)+']'}}
}
const houseQ=[],houses=new Map(),colGrid=new Map(),hl=[];
for(let i=0;i<1;i++){const L=new THREE.PointLight(0xffc880,0,18,2);scene.add(L);hl.push(L)}
function addCol(c){if(c.r!==undefined){const k=Math.floor(c.x/GC)+','+Math.floor(c.z/GC);let a=colGrid.get(k);if(!a)colGrid.set(k,a=[]);a.push(c)}
  else for(let i=Math.floor(c.x0/GC);i<=Math.floor(c.x1/GC);i++)for(let j=Math.floor(c.z0/GC);j<=Math.floor(c.z1/GC);j++){const k=i+','+j;let a=colGrid.get(k);if(!a)colGrid.set(k,a=[]);a.push(c)}}
const _m=new THREE.Matrix4(),_q=new THREE.Quaternion(),_p=new THREE.Vector3(),_s=new THREE.Vector3(),_up=new THREE.Vector3(0,1,0);
function putI(M,idx,x,z,rot,s){if(idx>=M.cap)return false;_q.setFromAxisAngle(_up,rot);_p.set(x,0,z);_s.set(s,s,s);_m.compose(_p,_q,_s);for(const im of M.parts)im.setMatrixAt(idx,_m);return true}
let pcx=1e9,pcz=1e9,lrx=0,lrz=0;
function refreshWorld(){
  const cx=Math.floor(player.x/CS),cz=Math.floor(player.z/CS);pcx=cx;pcz=cz;lrx=player.x;lrz=player.z;const CULL2=Math.pow(scene.fog.far+14,2);
  for(const h of nearHouses(player.x,player.z,2)){if(!houses.has(h.id)&&!houseQ.includes(h)&&Math.hypot(h.x-player.x,h.z-player.z)<135)houseQ.push(h)}
  for(const [id,o] of houses){if(Math.hypot(o.h.x-player.x,o.h.z-player.z)>175){scene.remove(o.g);o.g.traverse(m=>{if(m.geometry)m.geometry.dispose()});(o.fade||[o.wall]).forEach(m=>m.dispose());houses.delete(id)}}
  colGrid.clear();const cnt=new Array(MODELS.length).fill(0);
  for(let a=cx-WR;a<=cx+WR;a++)for(let b=cz-WR;b<=cz+WR;b++){const dist=Math.max(Math.abs(a-cx),Math.abs(b-cz));
    for(const it of genChunk(a,b)){const M=MODELS[it.mi];if(dist>Math.min(M.lr,WR)||it.q>QS[qLevel].qd||(it.x-player.x)*(it.x-player.x)+(it.z-player.z)*(it.z-player.z)>CULL2)continue;if(putI(M,cnt[it.mi],it.x,it.z,it.rot,it.s)){cnt[it.mi]++;if(M.r>0)addCol({x:it.x,z:it.z,r:M.r*it.s})}}}
  const P1=MODELS[MIDX.RockPath_Square_Small_2],P2=MODELS[MIDX.RockPath_Round_Small_1];
  for(const o of houses.values()){o.rects.forEach(addCol);if(o.door&&!o.door.open&&!o.door.broken)addCol(o.door.rect);const h=o.h;
    for(let k=0;k<9&&P1&&P2;k++){const M=k%2?P2:P1,i=MODELS.indexOf(M);if(putI(M,cnt[i],h.x+Math.sin(k*2.1)*.35,h.z+h.d/2+1.6+k*1.3,k*1.7,1.25))cnt[i]++}}
  MODELS.forEach((M,i)=>M.parts.forEach(im=>{im.count=cnt[i];im.instanceMatrix.needsUpdate=true}));
  syncAmmo(cx,cz);syncGuns(cx,cz);syncSwords(cx,cz);syncCars();
  if(chunkCache.size>260){for(const k of chunkCache.keys()){const p=k.split(',');if(Math.abs(+p[0]-cx)>WR+5||Math.abs(+p[1]-cz)>WR+5)chunkCache.delete(k)}}
}
function pushOut(o,rad){
  const ix=Math.floor(o.x/GC),iz=Math.floor(o.z/GC);
  for(let a=-1;a<=1;a++)for(let b=-1;b<=1;b++){const L=colGrid.get((ix+a)+','+(iz+b));if(!L)continue;
    for(const c of L){
      if(c.r!==undefined){const dx=o.x-c.x,dz=o.z-c.z,mn=c.r+rad;if(dx*dx+dz*dz>=mn*mn)continue;const d=Math.hypot(dx,dz);if(d>1e-4){o.x=c.x+dx/d*mn;o.z=c.z+dz/d*mn}}
      else{const px=Math.max(c.x0,Math.min(c.x1,o.x)),pz=Math.max(c.z0,Math.min(c.z1,o.z)),dx=o.x-px,dz=o.z-pz,d2=dx*dx+dz*dz;if(d2>=rad*rad)continue;
        if(d2>1e-8){const d=Math.sqrt(d2);o.x=px+dx/d*rad;o.z=pz+dz/d*rad}
        else{const l=o.x-c.x0,r=c.x1-o.x,t=o.z-c.z0,bt=c.z1-o.z,m=Math.min(l,r,t,bt);if(m===l)o.x=c.x0-rad;else if(m===r)o.x=c.x1+rad;else if(m===t)o.z=c.z0-rad;else o.z=c.z1+rad}}}}
}
let camDist=7.5;
const ammoMeshes=new Map(),AM_G=new THREE.BoxGeometry(.6,.4,.42),AM_M=new THREE.MeshBasicMaterial({color:0x62ff7a}),AM_R=new THREE.RingGeometry(.7,.9,24),AM_RM=new THREE.MeshBasicMaterial({color:0x62ff7a,side:THREE.DoubleSide,transparent:true,opacity:.65});
function blockedAt(x,z){const L=colGrid.get(Math.floor(x/GC)+','+Math.floor(z/GC));if(!L)return false;for(const c of L){if(c.r!==undefined){const dx=x-c.x,dz=z-c.z;if(dx*dx+dz*dz<c.r*c.r)return true}else if(x>c.x0&&x<c.x1&&z>c.z0&&z<c.z1)return true}return false}
function syncAmmo(cx,cz){
  const need=new Set();
  for(let a=cx-WR;a<=cx+WR;a++)for(let b=cz-WR;b<=cz+WR;b++){const ar=rng(hash2(a+777,b+777));if(ar()>=.08)continue;const key=a+','+b;if(ammoTaken.has(key))continue;
    const x=a*CS+4+ar()*(CS-8),z=b*CS+4+ar()*(CS-8);if(x*x+z*z<100)continue;need.add(key);
    if(!ammoMeshes.has(key)){const g=new THREE.Group(),m=new THREE.Mesh(AM_G,AM_M),r=new THREE.Mesh(AM_R,AM_RM);
      r.rotation.x=-Math.PI/2;r.position.y=-.55;g.add(m,r);g.position.set(x,.9,z);scene.add(g);ammoMeshes.set(key,{g,x,z})}}
  for(const [k,o] of ammoMeshes)if(!need.has(k)){scene.remove(o.g);ammoMeshes.delete(k)}
}
function tickAmmo(dt,now){
  for(const [k,o] of ammoMeshes){o.g.rotation.y+=dt*2;o.g.position.y=.9+Math.sin(now/280+o.x)*.12;
    if(Math.hypot(player.x-o.x,player.z-o.z)<1.5){ammoTaken.add(k);ammo=Math.min(60,ammo+12+(Math.random()*9|0));pop('+AMMO',player.x,2.4,player.z,'#62ff7a',true);snd(560,.15,'sine',.18,400);scene.remove(o.g);ammoMeshes.delete(k)}}
}

// ---- drivable car (only ONE car in the world) ----
const carState=new Map();
function mkCarObj(){
  const root=CAR.scene.clone(true);root.scale.setScalar(.85);
  const g=new THREE.Group(),pv=new THREE.Group();pv.position.y=1;root.position.y=-1;pv.add(root);g.add(pv);const find=n=>{let r=null;root.traverse(o=>{if(!r&&o.name===n)r=o});return r};
  const wheel=m=>{if(!m||!m.geometry)return null;m.geometry.computeBoundingBox();const c=m.geometry.boundingBox.getCenter(new THREE.Vector3()),st=new THREE.Group(),ro=new THREE.Group();
    st.position.copy(c);st.add(ro);ro.add(m);m.position.set(-c.x,-c.y,-c.z);root.add(st);return{st,ro}};
  g.userData={pv,bw:wheel(find('BackWheels')),fr:wheel(find('FrontWheel_R')),fl:wheel(find('FrontWheel_L'))};return g}
function placeCar(c){c.g.position.set(c.x,c.air||0,c.z);c.g.rotation.y=c.h;const pv=c.g.userData.pv;if(pv)pv.rotation.x=c.pitch||0}

// ---- random start / random car / random AK-47 ----
const gunMeshes=new Map();
let firstGame=true;try{firstGame=!localStorage.getItem('zn_played')}catch(e){}
function findSpot(rmin,rmax,a0,sp){let x=0,z=0;for(let i=0;i<30;i++){const a=a0===undefined?Math.random()*6.28:a0+rnd(-sp,sp),r=rmin+Math.random()*(rmax-rmin);x=player.x+Math.sin(a)*r;z=player.z+Math.cos(a)*r;
  if(!blockedAt(x,z)&&!blockedAt(x+1.6,z)&&!blockedAt(x-1.6,z)&&!blockedAt(x,z+1.6)&&!blockedAt(x,z-1.6)&&!inHouseZone(x,z,4))break}return{x,z}}
function placeStart(){hintJoy=firstGame;{const hn=$('joyhint');if(hn){hn.style.display=hintJoy?'block':'none';if(hintJoy)setTimeout(()=>{if(hintJoy)hideHint()},14000)}}

  const a0=Math.random()*6.28,r0=150+Math.random()*850,bx=Math.sin(a0)*r0,bz=Math.cos(a0)*r0;
  for(let i=0;i<16;i++){player.x=bx+(i?rnd(-8,8):0);player.z=bz+(i?rnd(-8,8):0);refreshWorld();if(!blockedAt(player.x,player.z)&&!inHouseZone(player.x,player.z,4))break}
  const c=firstGame?findSpot(13,22,Math.PI,.7):findSpot(55,85);carSpawn={x:c.x,z:c.z,h:Math.random()*6.28};try{localStorage.setItem('zn_played','1')}catch(e){}firstGame=false;gunStart=findSpot(30,75);swordStart=findSpot(22,60);
  camYaw=0;camPos.set(player.x,5.2,player.z+7);hbest=undefined;
  refreshWorld();
}

// ---- random sword pickups ----
const swordMeshes=new Map(),swordTaken=new Set();let swordStart=null;
function buildSword(){const g=new THREE.Group(),M=(c,e)=>new THREE.MeshStandardMaterial({color:c,metalness:.7,roughness:.35,emissive:e||0,emissiveIntensity:.5}),
  B=(w,h,d,m,x,y,z)=>{const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);o.position.set(x,y,z);g.add(o)};
  B(.8,.075,.02,M(0xe6eeff,0x5577cc),-.58,0,0);B(.04,.06,.3,M(0xffc040,0x553300),-.17,0,0);B(.26,.045,.045,M(0x5a3418),0,0,0);B(.06,.07,.07,M(0xffc040),.14,0,0);return g}
function mkSwordPickup(x,z){const g=new THREE.Group(),sw=buildSword();sw.rotation.x=Math.PI/2;sw.position.set(.25,.6,0);g.add(sw);
  const ring=new THREE.Mesh(new THREE.RingGeometry(.9,1.15,28),new THREE.MeshBasicMaterial({color:0x7be7ff,side:THREE.DoubleSide,transparent:true,opacity:.7,depthWrite:false}));ring.rotation.x=-Math.PI/2;ring.position.y=.06;g.add(ring);
  const beam=new THREE.Mesh(new THREE.CylinderGeometry(.12,.12,7,8,1,true),new THREE.MeshBasicMaterial({color:0x7be7ff,transparent:true,opacity:.22,depthWrite:false,side:THREE.DoubleSide}));beam.position.y=3.5;g.add(beam);
  g.position.set(x,0,z);return{g,mesh:sw,x,z}}
function syncSwords(cx,cz){
  const need=new Set(),add=(k,x,z)=>{need.add(k);if(!swordMeshes.has(k)){const o=mkSwordPickup(x,z);scene.add(o.g);swordMeshes.set(k,o)}};
  if(!WL.includes('sword')){
    if(swordStart&&!swordTaken.has('start'))add('start',swordStart.x,swordStart.z);
    for(let a=cx-WR;a<=cx+WR;a++)for(let b=cz-WR;b<=cz+WR;b++){const r=rng(hash2(a+7777,b+3333));if(r()>=.012)continue;const k=a+','+b;if(swordTaken.has(k))continue;
      const x=a*CS+4+r()*(CS-8),z=b*CS+4+r()*(CS-8);if(inHouseZone(x,z,3))continue;add(k,x,z)}}
  for(const [k,o] of swordMeshes)if(!need.has(k)){scene.remove(o.g);swordMeshes.delete(k)}
}
function giveSword(){if(!WL.includes('sword')){WL.push('sword');setWpn('sword');banner('🗡️ Sword found!')}snd(620,.2,'sine',.15,500)}
function tickSwords(dt,now){for(const [k,o] of swordMeshes){o.g.rotation.y+=dt*1.4;o.mesh.position.y=.6+Math.sin(now/300+o.x)*.08;
  if(Math.hypot(player.x-o.x,player.z-o.z)<2.4&&running&&!player.dead&&!player.car){swordTaken.add(k);scene.remove(o.g);swordMeshes.delete(k);giveSword();break}}}
function syncGuns(cx,cz){
  const need=new Set(),add=(k,x,z)=>{need.add(k);if(!gunMeshes.has(k)){const o=mkGunPickup(x,z);scene.add(o.g);gunMeshes.set(k,o)}};
  if(gunStart&&!gunTaken.has('start'))add('start',gunStart.x,gunStart.z);
  for(let a=cx-WR;a<=cx+WR;a++)for(let b=cz-WR;b<=cz+WR;b++){const r=rng(hash2(a+5151,b+9191));if(r()>=.014)continue;const k=a+','+b;if(gunTaken.has(k))continue;
    const x=a*CS+4+r()*(CS-8),z=b*CS+4+r()*(CS-8);if(inHouseZone(x,z,3))continue;add(k,x,z)}
  for(const [k,o] of gunMeshes)if(!need.has(k)){scene.remove(o.g);gunMeshes.delete(k)}
}
function giveGun(){if(!hasGun){hasGun=true;WL.push('gun');document.body.classList.remove('nogun');ammo+=30;setWpn('gun');banner('🔫 AK-47 found! (+30 ammo)')}else{ammo=Math.min(90,ammo+20);banner('+20 AMMO')}snd(620,.2,'sine',.15,500)}
function tickGuns(dt,now){for(const [k,o] of gunMeshes){o.g.rotation.y+=dt*1.4;o.ak.position.y=.6+Math.sin(now/300+o.x)*.08;
  if(Math.hypot(player.x-o.x,player.z-o.z)<2.4&&running&&!player.dead&&!player.car){gunTaken.add(k);scene.remove(o.g);gunMeshes.delete(k);giveGun();break}}}
function pointTo(arrow,dist,x,z){const dx=x-player.x,dz=z-player.z,fx=-Math.sin(camYaw),fz=-Math.cos(camYaw),rx=Math.cos(camYaw),rz=-Math.sin(camYaw);
  $(arrow).style.transform='rotate('+Math.atan2(dx*rx+dz*rz,dx*fx+dz*fz)+'rad)';$(dist).textContent=Math.round(Math.hypot(dx,dz))+'m'}
function compass2(){const c=carState.get('start'),cp=$('carc'),gp=$('gunc');
  if(c&&!player.car&&running&&!player.dead){cp.style.display='block';pointTo('carr','card',c.x,c.z)}else cp.style.display='none';
  if(!hasGun&&gunStart&&!gunTaken.has('start')&&running&&!player.dead&&!player.car){gp.style.display='block';pointTo('gunr','gund',gunStart.x,gunStart.z)}else gp.style.display='none';
  const sp=$('swc');if(!WL.includes('sword')&&swordStart&&!swordTaken.has('start')&&running&&!player.dead&&!player.car){sp.style.display='block';pointTo('swr','swd',swordStart.x,swordStart.z)}else sp.style.display='none'}
function syncCars(){
  if(carSpawn&&!carState.has('start'))carState.set('start',{id:'start',x:carSpawn.x,z:carSpawn.z,h:carSpawn.h,v:0,roll:0,steer:0,sin:0,boostT:0,boostCd:0,g:null,driven:false});
  const c=carState.get('start');if(!c)return;const d=Math.hypot(c.x-player.x,c.z-player.z);
  if(!c.g&&d<140){c.g=mkCarObj();scene.add(c.g);placeCar(c)}else if(c.g&&!c.driven&&d>210){scene.remove(c.g);c.g=null}
  if(c.g&&!c.driven)for(const o of[-1.4,0,1.4])addCol({x:c.x+Math.sin(c.h)*o,z:c.z+Math.cos(c.h)*o,r:1.25});
}
function resetCars(){for(const c of carState.values())if(c&&c.g){scene.remove(c.g);c.g=null}carState.clear();engineOff();musStop(true);document.body.classList.remove('driving');if(typeof cin!=='undefined'){cin.l=cin.r=cin.gas=cin.brake=0}if(player){player.car=null;player.ch.holder.visible=true}}
function nearestCar(){const c=carState.get('start');if(!c||!c.g||c.driven)return null;return Math.hypot(c.x-player.x,c.z-player.z)<5?c:null}
function toggleCar(){if(!running||player.dead)return;if(player.car)exitCar();else{const c=nearestCar();if(c)enterCar(c)}}
function enterCar(c){player.car=c;c.driven=true;c.v=0;c.auto=false;autoUI();runOn=false;holding=false;player.ch.holder.visible=false;player.x=c.x;player.z=c.z;document.body.classList.add('driving');engineOn();musStart();musUI();refreshWorld();snd(300,.2,'square',.07,-100)}
function exitCar(){const c=player.car;if(!c)return;const ch=Math.cos(c.h),sh=Math.sin(c.h);
  const opts=[[ch*2.8,-sh*2.8],[-ch*2.8,sh*2.8],[-sh*3.6,-ch*3.6],[sh*3.6,ch*3.6]];let p=opts[0];
  for(const o of opts){const x=c.x+o[0],z=c.z+o[1];if(!blockedAt(x,z)&&!inHouseZone(x,z,.8)){p=o;break}}
  player.x=c.x+p[0];player.z=c.z+p[1];player.car=null;c.driven=false;c.v=0;c.auto=false;c.sin=0;player.ch.holder.visible=true;player.spd=0;document.body.classList.remove('driving');engineOff();musStop();cin.l=cin.r=cin.gas=cin.brake=0;refreshWorld();snd(260,.15,'square',.07,100)}

// ---- car radio (synth music, only while driving) ----
const TRACKS=[{n:'Chase',bpm:150},{n:'Zombie Siege',bpm:140},{n:'Boss Fight',bpm:162},{n:'Last Escape',bpm:132},{n:'Hip-Hop Action',bpm:94},{n:'Trap Chase',bpm:140},{n:'Drill Siege',bpm:142}];
let musicOn=true,trk=0,musTimer=null,musStep=0,musNext=0,musBus=null,noiseBuf=null;
const mf=m=>440*Math.pow(2,(m-69)/12);
function mOsc(type,f,t,d,v,lp){const o=AC.createOscillator(),g=AC.createGain();o.type=type;o.frequency.setValueAtTime(f,t);g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(v,t+.01);g.gain.exponentialRampToValueAtTime(.0001,t+d);
  if(lp){const fl=AC.createBiquadFilter();fl.type='lowpass';fl.frequency.setValueAtTime(lp,t);fl.frequency.exponentialRampToValueAtTime(Math.max(120,lp*.3),t+d);o.connect(fl);fl.connect(g)}else o.connect(g);g.connect(musBus);o.start(t);o.stop(t+d+.03)}
function mKick(t,v){const o=AC.createOscillator(),g=AC.createGain();o.frequency.setValueAtTime(150,t);o.frequency.exponentialRampToValueAtTime(48,t+.12);g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.001,t+.22);o.connect(g);g.connect(musBus);o.start(t);o.stop(t+.24)}
function mNoise(t,d,v,hp){if(!noiseBuf){noiseBuf=AC.createBuffer(1,AC.sampleRate*.5,AC.sampleRate);const a=noiseBuf.getChannelData(0);for(let i=0;i<a.length;i++)a[i]=Math.random()*2-1}
  const s=AC.createBufferSource(),f=AC.createBiquadFilter(),g=AC.createGain();s.buffer=noiseBuf;f.type='highpass';f.frequency.value=hp;g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.001,t+d);s.connect(f);f.connect(g);g.connect(musBus);s.start(t);s.stop(t+d+.02)}
function mTom(t,f,v){const o=AC.createOscillator(),g=AC.createGain();o.frequency.setValueAtTime(f,t);o.frequency.exponentialRampToValueAtTime(f*.5,t+.2);g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.001,t+.24);o.connect(g);g.connect(musBus);o.start(t);o.stop(t+.26)}
function mCrash(t,v){mNoise(t,1.1,v,4200);mNoise(t,.3,v*1.2,9000)}
function mSnare(t,v){mNoise(t,.15,v,1600);mOsc('triangle',200,t,.09,v*.6)}
function mPow(r,t,d,v,lp){mOsc('sawtooth',mf(r),t,d,v,lp);mOsc('sawtooth',mf(r)*1.006,t,d,v*.8,lp);mOsc('sawtooth',mf(r+7),t,d,v*.8,lp);mOsc('sawtooth',mf(r+12),t,d,v*.6,lp)}
function mBass(r,t,d,v){mOsc('sawtooth',mf(r),t,d,v,520);mOsc('square',mf(r-12),t,d,v*.7,300)}
function m808(n,t,d,v,to){const o=AC.createOscillator(),h=AC.createOscillator(),f=AC.createBiquadFilter(),g=AC.createGain(),hg=AC.createGain();o.type='sine';h.type='sawtooth';f.type='lowpass';f.frequency.value=480;hg.gain.value=.3;
  const f0=mf(n);o.frequency.setValueAtTime(f0,t);h.frequency.setValueAtTime(f0*2,t);if(to!==undefined){const f1=mf(to);o.frequency.exponentialRampToValueAtTime(f1,t+d*.8);h.frequency.exponentialRampToValueAtTime(f1*2,t+d*.8)}
  g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(v,t+.006);g.gain.exponentialRampToValueAtTime(.0001,t+d);
  o.connect(g);h.connect(f);f.connect(hg);hg.connect(g);g.connect(musBus);o.start(t);h.start(t);o.stop(t+d+.03);h.stop(t+d+.03)}
function mClap(t,v){mNoise(t,.1,v,1100);mNoise(t+.011,.09,v*.8,1300);mNoise(t+.022,.14,v*.7,1500)}
function mHat(t,v,open){mNoise(t,open?.16:.03,v,open?6500:8500)}
function musNote(k,st,t,sec){
  const b=st%16,bar=(st>>4)%4,h=((st*7919)%13);
  if(k===0){          // CHASE — fast driving rock/electro, E minor
    const r=[40,40,36,38][bar];
    if(b%4===0||b===10||(bar===3&&b===14))mKick(t,.95);if(b===4||b===12)mSnare(t,.5);
    if(b%2===0)mNoise(t,.035,.13,8000);if(b===14)mNoise(t,.2,.12,7000);if(b===0&&bar===0)mCrash(t,.22);
    if(b%2===0||b===3||b===11)mBass(r+(b===6||b===14?12:0),t,sec*1.6,.2);
    if([0,3,6,10].includes(b))mPow(r+24,t,sec*1.8,.07,2200);
    mOsc('square',mf(r+36+[0,3,7,10,12,10,7,3][b%8]+(bar===3?2:0)),t,sec*.9,bar>1?.05:.03,2600);
  }else if(k===1){    // ZOMBIE SIEGE — heavy industrial, D minor
    const r=[38,38,41,36][bar];
    if([0,3,6,8,11].includes(b))mKick(t,1);if(b===4||b===12)mSnare(t,.55);
    if(bar===3&&b>=12)mTom(t,170-(b-12)*22,.5);if(b%2===0)mNoise(t,.05,.12,6500);if(b===0&&bar===0)mCrash(t,.25);
    if([0,1,3,6,8,9,11,14].includes(b))mBass(r,t,sec*1.1,.26);
    if(b===0||b===8)for(const iv of[0,3,7])mOsc('sawtooth',mf(r+24+iv),t,sec*6,.06,1800);
    if(b===6&&bar%2===1)mOsc('sine',mf(r+48),t,sec*3,.05);
  }else if(k===2){    // BOSS FIGHT — very fast, galloping double kick, G minor
    const r=[43,43,39,41][bar];
    if(b%4===0||b===6||b===7||b===14||b===15)mKick(t,.95);if(b===4||b===12)mSnare(t,.6);
    mNoise(t,.03,.1,8500);if(b===0&&bar===0)mCrash(t,.28);if(bar===3&&b>=12)mSnare(t,.35);
    mBass(r+(b%8===6?12:0),t,sec*.9,.2);
    if(b===0||b===8)mPow(r+24,t,sec*7,.08,2600);
    if(b%2===0)mOsc('square',mf(r+36+[0,3,5,7,10,12,10,7][(b>>1)%8]),t,sec*1.6,.045,3200);
  }else if(k===3){              // LAST ESCAPE — tense chase, strings and arps, A minor
    const r=[45,41,43,40][bar];
    if(b===0||b===6||b===8||b===10)mKick(t,.9);if(b===4||b===12)mSnare(t,.45);if(b===15)mSnare(t,.15);
    mNoise(t,.03,b%4===2?.16:.08,8200);if(b===0&&bar===0)mCrash(t,.2);
    if(b%4===2)mBass(r,t,sec*2,.22);
    if(b===0){for(const iv of[0,7,12,15]){mOsc('sawtooth',mf(r+12+iv),t,sec*15,.035,1500);mOsc('sawtooth',mf(r+12+iv)*1.008,t,sec*15,.03,1500)}}
    const sc=[0,3,7,10,12,15,19,22];mOsc('square',mf(r+24+sc[(b*3+bar)%8]),t,sec*.8,.04,2400);
    if(bar===3&&b>=8)mNoise(t,.1,.05+(b-8)*.012,2500+(b-8)*500);
  }else if(k===4){    // HIP-HOP ACTION — boom-bap swing, brass stabs, funky bass (94 BPM)
    const r=[34,34,31,36][bar],sw=b%2?sec*.16:0;
    if(b===0||b===10||(bar%2&&b===6)||(bar===3&&b===14))mKick(t,.95);
    if(b===4||b===12){mSnare(t,.6);mClap(t,.15)}if(b===15)mSnare(t,.12);
    if(b%2===0)mHat(t+sw,.09);if(b===14)mHat(t,.1,true);
    if([0,3,6,10,12].includes(b))mOsc('sawtooth',mf(r+[0,0,7,0,5][[0,3,6,10,12].indexOf(b)]),t,sec*2.2,.24,420);
    if((b===0&&bar%2===0)||b===8)for(const iv of[0,3,7,10])mOsc('sawtooth',mf(r+36+iv),t,sec*1.6,.045,2400);
    if(b===0)for(const iv of[0,3,7])mOsc('triangle',mf(r+24+iv),t,sec*14,.04,1800);
    if(bar===3&&b===14){mNoise(t,.08,.14,2500);mNoise(t+sec*.5,.08,.14,4200)}
  }else if(k===5){    // TRAP CHASE — 808 sub-bass, rolling hats, clap on 3 (140 BPM)
    const r=[34,34,32,31][bar],sc=[0,3,5,7,10];
    if(b===0)m808(r,t,sec*6,.62);if(b===6)m808(r+(bar%2?3:0),t,sec*3,.5);if(b===10)m808(r,t,sec*5,.55,r-5);if(bar===3&&b===14)m808(r+7,t,sec*2,.45);
    if(b===0||b===10)mKick(t,.35);
    if(b===8){mClap(t,.55);mOsc('triangle',210,t,.08,.15)}if(bar===3&&b>=13)mSnare(t,.18+(b-13)*.06);
    if(b%2===0)mHat(t,.1);if(b===6||b===14){mHat(t,.1);mHat(t+sec/3,.09);mHat(t+sec*2/3,.1)}if(b===12)mHat(t,.1,true);if(b===3&&bar%2)mHat(t,.07);
    if([0,3,8,11].includes(b)){mOsc('triangle',mf(r+36+sc[(b+bar*2)%5]),t,sec*3,.07,3200);mOsc('sine',mf(r+48+sc[(b+bar*2)%5]),t,sec*2,.03)}
    if(b===0)for(const iv of[0,3,7])mOsc('triangle',mf(r+24+iv),t,sec*15,.035,1200);
  }else{              // DRILL SIEGE — sliding 808s, snare on 3, stuttering hats (142 BPM)
    const r=[33,33,31,29][bar];
    if(b===0)m808(r,t,sec*7,.62,r-2);if(b===3)m808(r+3,t,sec*2,.45);if(b===10)m808(r,t,sec*5,.55,r+3);
    if(b===0||b===3||b===10||(bar===3&&b===14))mKick(t,.55);
    if(b===8){mSnare(t,.62);mClap(t,.25)}if(b===11)mSnare(t,.15);
    if(b%2===0)mHat(t,.08);if(b===1||b===13){mHat(t,.1);mHat(t+sec/3,.09);mHat(t+sec*2/3,.1)}if(b===5){mHat(t,.1);mHat(t+sec/2,.09)}if(b===14)mHat(t,.1,true);
    if(b%4===0||b===6)mOsc('triangle',mf(r+36+[0,3,7,3,0,-2,0,3][(b>>1)%8]),t,sec*2.6,.06,2200);
    if(b===0&&bar%2===0)for(const iv of[0,3,7,10]){mOsc('sawtooth',mf(r+24+iv),t,sec*15,.028,1100)}
  }
}
function musSched(){if(!musBus||!AC)return;const T=TRACKS[trk],sec=60/T.bpm/4;while(musNext<AC.currentTime+.25){musNote(trk,musStep,musNext,sec);musStep++;musNext+=sec}}
function musStop(quick){if(musTimer){clearInterval(musTimer);musTimer=null}if(musBus&&AC){const b=musBus;musBus=null;try{b.gain.setTargetAtTime(0,AC.currentTime,quick?.02:.15)}catch(e){}setTimeout(()=>{try{b.disconnect()}catch(e){}},700)}}
function musStart(){if(!musicOn||!(menu||(player&&player.car)))return;try{AC=AC||new(window.AudioContext||window.webkitAudioContext)();if(AC.state==='suspended')AC.resume();
  musStop(true);musBus=AC.createGain();musBus.gain.value=trk>=4?.25:.18;musBus.connect(AC.destination);musStep=0;musNext=AC.currentTime+.1;musTimer=setInterval(musSched,90)}catch(e){}}
function musUI(){const m1=$('mMus'),m2=$('mTrk');if(m1){m1.textContent=musicOn?'🎵 Music: ON':'🔇 Music: OFF';m1.classList.toggle('on',musicOn)}if(m2)m2.textContent='⏭ '+TRACKS[trk].n;const lb=$('mlabel'),bt=$('musOn');if(lb)lb.textContent=musicOn?'♪ '+TRACKS[trk].n:'♪ music off';if(bt)bt.textContent=musicOn?'🔊':'🔇'}
function musToggle(){musicOn=!musicOn;try{layout.mus=musicOn;saveLayout()}catch(e){}if(musicOn)musStart();else musStop();musUI()}
function musChange(){trk=(trk+1)%TRACKS.length;if(!musicOn)musicOn=true;musStart();musUI()}
let eng=null;
let noiseBuf2=null,engBufs=null;const ENG_RPMS=[900,1800,3000,4500,6200];
function genEngBuf(rpm){
  const SR=22050,fire=rpm/60*2,N=Math.max(3,Math.round(fire)),len=Math.round(N/fire*SR),per=len/N,buf=AC.createBuffer(1,len,SR),d=buf.getChannelData(0);
  const fr=[[88+rpm*.012,.9,70],[176+rpm*.02,.75,95],[330+rpm*.03,.5,130],[640,.3,190],[1100,.16,260]];   // exhaust pipe / body resonances: [Hz, level, decay]
  for(let p=0;p<N;p++){const st=Math.round(p*per+(Math.random()-.5)*per*.02),amp=(.85+Math.random()*.3)*(p%2?.92:1),L=Math.round(SR*.05);
    for(let i=0;i<L;i++){const tt=i/SR;let s=0;for(const q of fr)s+=q[1]*Math.sin(6.2832*q[0]*tt+.6)*Math.exp(-tt*q[2]);
      s+=Math.sin(6.2832*(52+rpm*.01)*tt)*Math.exp(-tt*110)*.65;d[((st+i)%len+len)%len]+=s*amp*(i>L*.7?(L-i)/(L*.3):1)}}
  const al=Math.exp(-6.2832*(520+rpm*.22)/SR);let y1=0,y2=0;
  for(let pass=0;pass<2;pass++)for(let i=0;i<len;i++){y1=(1-al)*d[i]+al*y1;y2=(1-al)*y1+al*y2;if(pass===1)d[i]=y2}
  let mean=0;for(let i=0;i<len;i++)mean+=d[i];mean/=len;let pk=1e-6;for(let i=0;i<len;i++){d[i]-=mean;pk=Math.max(pk,Math.abs(d[i]))}for(let i=0;i<len;i++)d[i]*=.9/pk;
  return buf}
function engineOn(){try{AC=AC||new(window.AudioContext||window.webkitAudioContext)();
  if(!engBufs)engBufs=ENG_RPMS.map(genEngBuf);
  if(!noiseBuf2){noiseBuf2=AC.createBuffer(1,AC.sampleRate,AC.sampleRate);const d=noiseBuf2.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1}
  const lp=AC.createBiquadFilter(),g=AC.createGain();lp.type='lowpass';lp.frequency.value=1500;lp.Q.value=.5;g.gain.value=.03;lp.connect(g);g.connect(AC.destination);
  const srcs=engBufs.map((bf,i)=>{const s=AC.createBufferSource();s.buffer=bf;s.loop=true;const gi=AC.createGain();gi.gain.value=0;s.connect(gi);gi.connect(lp);s.start();return{s,g:gi,rpm:ENG_RPMS[i]}});
  eng={srcs,lp,g,lastThr:false}}catch(e){}}
function enginePop(){try{for(let k=0;k<2;k++){const tm=AC.currentTime+k*(.08+Math.random()*.06),o=AC.createOscillator(),g=AC.createGain();o.type='sine';o.frequency.setValueAtTime(130+Math.random()*50,tm);o.frequency.exponentialRampToValueAtTime(60,tm+.08);g.gain.setValueAtTime(.05,tm);g.gain.exponentialRampToValueAtTime(.001,tm+.09);o.connect(g);g.connect(AC.destination);o.start(tm);o.stop(tm+.1)}}catch(e){}}
function engineOff(){if(eng){try{eng.srcs.forEach(o=>o.s.stop())}catch(e){}eng=null}}
function carFlip(dir){const c=player.car;if(!c||!c.g||c.fl)return;c.fl={t:0,dir,dur:.35,h0:c.h,v0:c.v};if(c.auto){c.course=c.h+dir*Math.PI;c.stuck=0;c.back=0}}
function carJump(){const c=player.car;if(!c||!c.g||c.fl||c.air>.02)return;c.vy=8.8;c.air=.01;snd(300,.15,'triangle',.07,200)}

// ---- autodrive: the car drives by itself and steers around trees / rocks / houses ----
function carSensors(c){const L=7+Math.abs(c.v)*.55,out=[];
  for(const a of[-.9,-.55,-.25,0,.25,.55,.9]){let d=L;const th=c.h+a,sx=Math.sin(th),sz=Math.cos(th),px=Math.cos(th)*1.3,pz=-Math.sin(th)*1.3;
    for(let s=1.5;s<=L;s+=1.5){const x=c.x+sx*s,z=c.z+sz*s;if(blockedAt(x,z)||blockedAt(x+px,z+pz)||blockedAt(x-px,z-pz)){d=s;break}}out.push([a,d])}
  return{L,out}}
function autoPilot(c,dt){
  const S=carSensors(c),front=S.out[3][1],diff=((c.course-c.h+Math.PI)%(Math.PI*2)+Math.PI*2)%(Math.PI*2)-Math.PI,want=Math.max(-.9,Math.min(.9,diff));
  let best=0,bs=-1e9;for(const [a,d] of S.out){const sc=d-Math.abs(a-want)*3;if(sc>bs){bs=sc;best=a}}
  let st=-Math.max(-1,Math.min(1,best/.55)),gas=false,brake=false;
  if(front<5+c.v*.35){brake=c.v>6}else gas=c.v<15;
  if(c.v<1.2&&front<3.5)c.stuck=(c.stuck||0)+dt;else c.stuck=Math.max(0,(c.stuck||0)-dt*2);
  if(c.stuck>1.2){c.back=1.1;c.stuck=0;const l=S.out[4][1]+S.out[5][1]+S.out[6][1],r=S.out[0][1]+S.out[1][1]+S.out[2][1];c.backSt=l>r?1:-1}
  if(c.back>0){c.back-=dt;brake=true;gas=false;st=c.backSt}
  return{gas,brake,st}}
function autoUI(){const c=player&&player.car,b=$('autoB');if(!b)return;b.style.background=c&&c.auto?'#1f9a3a':'#1d2b4acc';b.style.borderColor=c&&c.auto?'#7dff7d':'#fff'}
function carAuto(){const c=player.car;if(!c||!c.g)return;c.auto=!c.auto;if(c.auto){c.course=c.h;c.stuck=0;c.back=0}autoUI();snd(520,.1,'triangle',.07,100)}
function carBoost(){const c=player.car;if(c&&c.boostCd<=0&&c.boostT<=0){c.boostT=2.2;c.boostCd=7;snd(180,.4,'sawtooth',.085,300);shake=Math.max(shake,.3)}}
// zombies are thrown far (not killed outright)
function carLaunch(z,c,dx,dz,d){const sp=Math.abs(c.v),dd=d||1;
  hitZ(z,14+sp*1.5,0,dx,dz,dd,sp>12);
  const w=z.type==='boss'?.15:z.type==='brute'?.35:z.type==='tank'?.5:1,s=Math.sign(c.v||1);
  let ox=Math.sin(c.h)*s*.8+dx/dd*.6,oz=Math.cos(c.h)*s*.8+dz/dd*.6;const ol=Math.hypot(ox,oz)||1,v0=(30+sp*2.4)*w;
  z.knx=ox/ol*v0;z.knz=oz/ol*v0;z.kd=.93;
  if(w>.4)z.fly={y:.01,vy:(6+sp*.3)*Math.min(1,w+.2),spin:(Math.random()<.5?-1:1)*(5+Math.random()*4)}}
function driveStep(dt){
  const c=player.car;if(!c||!c.g)return;
  let gas=cin.gas||keys.w||keys.arrowup,brake=cin.brake||keys.s||keys.arrowdown,st=((cin.r||keys.d||keys.arrowright)?1:0)-((cin.l||keys.a||keys.arrowleft)?1:0);
  if(c.auto){if(brake&&!(c.back>0)){c.auto=false;autoUI()}else{const ap=autoPilot(c,dt);if(st!==0){if(!c.fl)c.course=c.h}else st=c.fl?0:ap.st;gas=gas||ap.gas;brake=ap.brake}}
  if(c.boostCd>0)c.boostCd-=dt;if(c.boostT>0)c.boostT-=dt;
  const boost=c.boostT>0,vmax=boost?31:21;let acc=0;
  if(gas&&!brake)acc=(boost?18:10)*(1-Math.max(0,c.v)/vmax*.6);
  else if(brake)acc=c.v>.6?-20:-7;
  else acc=-Math.sign(c.v)*(Math.abs(c.v)>.3?3.5:0);
  const prev=c.v;c.v+=acc*dt;if(!gas&&!brake&&prev*c.v<0)c.v=0;
  if(c.v>vmax)c.v-=(c.v-vmax)*Math.min(1,dt*2);c.v=Math.max(-7,Math.min(vmax+4,c.v));
  c.sin+=((c.fl?c.sin:st)-c.sin)*Math.min(1,dt*7);
  const sf=Math.min(1,Math.abs(c.v)/3.5)*(1-.5*Math.min(1,Math.abs(c.v)/vmax));
  c.h-=c.sin*2.5*sf*Math.sign(c.v)*dt;c.steer=-c.sin*.5;
  c.x+=Math.sin(c.h)*c.v*dt;c.z+=Math.cos(c.h)*c.v*dt;
  const o={x:c.x,z:c.z};pushOut(o,1.5);if(Math.abs(o.x-c.x)+Math.abs(o.z-c.z)>.004){c.x=o.x;c.z=o.z;if(Math.abs(c.v)>6)shake=Math.max(shake,.3);c.v*=.6}
  let hits=0;for(const z of zombies){if(z.carCd>0)z.carCd-=dt;if(hits>=2||z.dead||z.rise>0||z.carCd>0||c.air>.5)continue;const dx=z.x-c.x,dz=z.z-c.z,d=Math.hypot(dx,dz);
    if(d<2.4+z.h*.12&&Math.abs(c.v)>4){hits++;z.carCd=.6;carLaunch(z,c,dx,dz,d)}}
  c.roll+=c.v*dt/.37;const u=c.g.userData;if(u.bw)u.bw.ro.rotation.x=c.roll;for(const w of[u.fr,u.fl])if(w){w.ro.rotation.x=c.roll;w.st.rotation.y=c.steer}
  if(c.vy||c.air>0){c.vy=(c.vy||0)-22*dt;c.air=(c.air||0)+c.vy*dt;c.pitch=-c.vy*.022;if(c.air<=0){c.air=0;c.vy=0;c.pitch=0;shake=Math.max(shake,.35);snd(120,.15,'square',.08,-60)}}
  if(c.fl){const f=c.fl;f.t+=dt;const u=Math.min(1,f.t/f.dur),e=u*u*(3-2*u),nh=f.h0+f.dir*Math.PI*e;camYaw+=nh-c.h;c.h=nh;c.air=0;c.v=f.v0*(1-.1*Math.sin(Math.PI*u));
    if(f.t>=f.dur){c.h=f.h0+f.dir*Math.PI;c.v=f.v0*.95;c.fl=null;c.sin=0;if(c.auto)c.course=c.h}}
  placeCar(c);player.x=c.x;player.z=c.z;player.rot=c.h;
  if(!c.fl&&performance.now()-camDragT>1800){const diff=((c.h+Math.PI-camYaw+Math.PI)%(Math.PI*2)+Math.PI*2)%(Math.PI*2)-Math.PI;camYaw+=diff*Math.min(1,dt*2.5)}
  player.mdx=Math.sin(c.h)*Math.sign(c.v||1);player.mdz=Math.cos(c.h)*Math.sign(c.v||1);
  if(eng&&fc%3===0){const sp=Math.abs(c.v),tm=AC.currentTime,thr=!!(cin.gas||keys.w||keys.arrowup||c.auto),bo=c.boostT>0,GR=[0,5,9.5,14,19,25,32];
    let gi=0;for(let i=1;i<GR.length;i++)if(sp>=GR[i])gi=i;const nx=GR[Math.min(gi+1,GR.length-1)],fr=Math.min(1,(sp-GR[gi])/Math.max(2,nx-GR[gi]));
    let rpm=gi===0?900+fr*1700:1700+fr*3700;                // every gear starts lower and revs up, then shifts
    if(thr&&sp<2)rpm=Math.max(rpm,2600);                     // revving while standing
    if(!thr&&sp>6)rpm=Math.max(950,rpm*.82);                 // engine braking when you lift off
    rpm=Math.min(6400,rpm);
    let sw=0;const w=eng.srcs.map(o=>{const x=Math.log(rpm/o.rpm)/.55,v=Math.max(0,1-Math.abs(x));sw+=v;return v});
    eng.srcs.forEach((o,i)=>{o.s.playbackRate.setTargetAtTime(Math.min(1.5,Math.max(.7,rpm/o.rpm)),tm,.05);o.g.gain.setTargetAtTime(w[i]/(sw||1),tm,.05)});
    eng.g.gain.setTargetAtTime(.04*(thr?1:.6)*(bo?1.25:1),tm,.08);eng.lp.frequency.setTargetAtTime(900+rpm*.18+(thr?400:0),tm,.08);
    if(eng.lastThr&&!thr&&rpm>3800&&sp>10)enginePop();eng.lastThr=thr}
  if(fc%3===0){$('spd').textContent=Math.round(Math.abs(c.v)*3.6);const nf=c.boostT>0?c.boostT/2.2:1-Math.max(0,c.boostCd)/7;$('nfill').style.width=(nf*100)+'%';$('nfill').style.background=c.boostT>0?'#ff9a2e':(c.boostCd>0?'#7a8cff':'#46ff7a');$('boost').style.opacity=(c.boostCd>0&&c.boostT<=0)?.45:1}
}
const blob=new THREE.Mesh(new THREE.CircleGeometry(.65,16),new THREE.MeshBasicMaterial({color:0x000000,transparent:true,opacity:.38,depthWrite:false}));blob.rotation.x=-Math.PI/2;blob.position.y=.04;blob.visible=false;scene.add(blob);
const QS=[{n:'Low',qd:.4,pr:.8,sh:false,wr:1,zc:7,ff:25,fog:[10,50]},{n:'Medium',qd:.7,pr:1,sh:false,wr:2,zc:10,ff:50,fog:[14,70]},{n:'High',qd:.9,pr:1.25,sh:true,wr:2,zc:14,ff:70,fog:[14,76]}];
let qMode='auto',qLevel=2,saver=false,qAcc=0,qN=0,qWarm=1,qMax=2,qGood=0;
function updateQBtn(){const e=$('qual');if(e)e.textContent='⚙ '+(qMode==='auto'?'Auto ('+QS[qLevel].n+')':qMode==='saver'?'Saver 30fps':QS[qLevel].n)}
function applyQuality(l){qLevel=l;const q=QS[l];renderer.setPixelRatio(Math.min(devicePixelRatio,q.pr));resize();sun.castShadow=q.sh;blob.visible=false;WR=q.wr;ZCAP=q.zc;scene.fog.near=q.fog[0];scene.fog.far=q.fog[1];pcx=1e9;if(player)refreshWorld();updateQBtn()}
function setQMode(m){qMode=m;saver=(m==='saver');if(m==='high')applyQuality(2);else if(m==='medium')applyQuality(1);else if(m==='low'||m==='saver')applyQuality(0);else updateQBtn()}
function worldTick(dt,now){
  const cx=Math.floor(player.x/CS),cz=Math.floor(player.z/CS);if(cx!==pcx||cz!==pcz||(player.x-lrx)*(player.x-lrx)+(player.z-lrz)*(player.z-lrz)>196)refreshWorld();tickAmmo(dt,now);tickGuns(dt,now);tickSwords(dt,now);blob.position.x=player.x;blob.position.z=player.z;if(houseQ.length){const h=houseQ.shift();if(!houses.has(h.id)&&Math.hypot(h.x-player.x,h.z-player.z)<150){const o=buildHouse(h);scene.add(o.g);houses.set(h.id,o);o.rects.forEach(addCol);if(!o.door.open&&!o.door.broken)addCol(o.door.rect)}}
  if(pcx<1e8){let n=0;const ux=player.mdx||0,uz=player.mdz||-1;
    for(let k=WR+1;k<=WR+3&&n<2;k++)for(let s=-2;s<=2&&n<2;s++){const a=pcx+Math.round(ux*k-uz*s),b=pcz+Math.round(uz*k+ux*s);if(!chunkCache.has(a+','+b)){genChunk(a,b);n++}}}
  ground.position.set(Math.round(player.x/5)*5,0,Math.round(player.z/5)*5);
  let inH=null;const arr=[];
  for(const o of houses.values()){const h=o.h,ins=Math.abs(player.x-h.x)<h.w/2-.1&&Math.abs(player.z-h.z)<h.d/2-.1;if(ins)inH=h;o.roof.visible=!ins;
    {const op=o.wall.opacity+((ins?.28:1)-o.wall.opacity)*Math.min(1,dt*8);for(const m of o.fade)m.opacity=op;const D=o.door;if(D&&!D.broken){const tg=D.open?1.6:0;D.ang+=(tg-D.ang)*Math.min(1,dt*9);D.pivot.rotation.y=D.ang}}
    if(!opened.has(h.id)){o.marker.rotation.y+=dt*2;o.marker.position.y=1.35+Math.sin(now/300)*.1;
      if(Math.hypot(player.x-o.cx,player.z-o.cz)<1.7){opened.add(h.id);o.marker.visible=false;dropPU(o.cx+1,o.cz,true);dropPU(o.cx+1,o.cz-1,true,'ammo');score+=50;ui();banner('📦 Treasure found!');snd(700,.3,'sine',.2,600)}}
    arr.push([Math.hypot(player.x-h.x,player.z-h.z),h])}
  player.house=inH;arr.sort((a,b)=>a[0]-b[0]);
  hl.forEach((L,i)=>{if(arr[i]&&arr[i][0]<60){L.position.set(arr[i][1].x,2.6,arr[i][1].z);L.intensity=1.5}else L.intensity=0});
  camDist+=(((player.car?11:(inH?5:7.5)))-camDist)*Math.min(1,dt*4);
  {const nc=nearestCar(),cbn=$('carbtn');if(player.car){cbn.style.display='flex';cbn.textContent='🚗 EXIT'}else if(nc&&running&&!player.dead){cbn.style.display='flex';cbn.textContent='🚗 ENTER'}else cbn.style.display='none'}
  compass2();doorUI();
  // compass to nearest house
  if(fc%10===0||hbest===undefined){hbest=null;let m=1e9;for(const h of nearHouses(player.x,player.z,3)){const d=Math.hypot(h.x-player.x,h.z-player.z);if(d<m){m=d;hbest=h}}}
  const best=hbest,bd=best?Math.hypot(best.x-player.x,best.z-player.z):0;
  const hm=$('home')||{style:{}};
  if(best){const dx=best.x-player.x,dz=best.z-player.z,fx=-Math.sin(camYaw),fz=-Math.cos(camYaw),rx=Math.cos(camYaw),rz=-Math.sin(camYaw);
    $('arr').style.transform=`rotate(${Math.atan2(dx*rx+dz*rz,dx*fx+dz*fz)}rad)`;$('dist').textContent=inH?'inside':Math.round(bd)+'m';hm.style.display='block'}else hm.style.display='none';
}


// ---- radar (minimap) ----
const mm=$('mm'),mc=mm.getContext('2d');mm.width=mm.height=140;
function drawMap(){
  const S=140,c=S/2,range=45,sc=(c-6)/range,cyw=Math.cos(camYaw),syw=Math.sin(camYaw);
  mc.clearRect(0,0,S,S);mc.save();mc.beginPath();mc.arc(c,c,c-1,0,6.2832);mc.fillStyle='rgba(8,18,34,.65)';mc.fill();mc.clip();
  mc.strokeStyle='rgba(255,255,255,.16)';mc.lineWidth=1;for(const r of[.33,.66]){mc.beginPath();mc.arc(c,c,(c-1)*r,0,6.2832);mc.stroke()}
  mc.beginPath();mc.moveTo(c,2);mc.lineTo(c,S-2);mc.moveTo(2,c);mc.lineTo(S-2,c);mc.stroke();
  const dot=(x,z,col,r)=>{const dx=x-player.x,dz=z-player.z;let u=(dx*cyw-dz*syw)*sc,v=-(dx*syw+dz*cyw)*sc;const d=Math.hypot(u,v),m=c-6;if(d>m){u*=m/d;v*=m/d;r*=.7}mc.fillStyle=col;mc.beginPath();mc.arc(c+u,c-v,r,0,6.2832);mc.fill()};
  for(const c of carState.values())if(c)dot(c.x,c.z,'#4aa8ff',3.8);
  for(const o of gunMeshes.values())dot(o.x,o.z,'#ff7bff',3.8);
  for(const o of swordMeshes.values())dot(o.x,o.z,'#7be7ff',3.8);
  for(const p of pups)dot(p.m.position.x,p.m.position.z,'#ffe14a',2.5);
  let n=0;for(const z of zombies){if(z.dead)continue;n++;
    if(z.type==='boss'){dot(z.x,z.z,'#ff1f1f',6)}else dot(z.x,z.z,z.type==='tank'?'#9fb0ff':z.type==='runner'?'#ff9a3c':z.type==='spitter'?'#7dff5a':z.type==='dog'?'#ffd23a':z.type==='brute'?'#c77dff':'#ff4545',3.2)}
  const Fx=Math.sin(player.rot),Fz=Math.cos(player.rot),ang0=Math.atan2(Fx*cyw-Fz*syw,-(Fx*syw+Fz*cyw));
  mc.translate(c,c);mc.rotate(ang0);mc.fillStyle='#fff';mc.beginPath();mc.moveTo(0,-8);mc.lineTo(5.5,6);mc.lineTo(0,3);mc.lineTo(-5.5,6);mc.closePath();mc.fill();
  mc.restore();mc.fillStyle='#fff';mc.font='bold 13px system-ui';mc.textAlign='center';mc.fillText('🧟 '+n,c,S-8);
}

// characters
let ZGLB=null,FTEX=null,FARM=null,AXE=null,DOG=null,CAR=null,BRU=null;const FACE=0;
const fbuf=u=>fetch(u).then(r=>{if(!r.ok)throw new Error('Could not load '+u+' (HTTP '+r.status+')');return r.arrayBuffer()}).catch(e=>{throw new Error(String(e&&e.message||e)+' - upload the WHOLE folder to a web host (or run a local web server). Double-clicking index.html will not work.')})
function makeChar(tint,height){
  const obj=THREE.SkeletonUtils.clone(ZGLB.scene);
  obj.traverse(o=>{if(o.isMesh){o.castShadow=false;if(tint){o.material=o.material.clone();o.material.color.setHex(tint)}}});
  const holder=new THREE.Group();holder.add(obj);
  const bb=new THREE.Box3().setFromObject(obj);const k=height/Math.max(.01,bb.max.y-bb.min.y);obj.scale.multiplyScalar(k);
  const mixer=new THREE.AnimationMixer(obj),acts={};
  ZGLB.animations.forEach(c=>{acts[c.name]=mixer.clipAction(c)});
  const ch={holder,obj,mixer,acts,cur:null,
    play(n,fade=.15,once=false,speed=1){
      const a=acts[n];if(!a)return;
      if(ch.cur===a&&!once)return;
      a.reset();a.timeScale=speed;a.setLoop(once?THREE.LoopOnce:THREE.LoopRepeat,Infinity);a.clampWhenFinished=once;
      if(ch.cur&&ch.cur!==a)ch.cur.fadeOut(fade);a.fadeIn(fade).play();ch.cur=a;ch.name=n;
    }};
  return ch;
}
const ang=(a,b,t)=>{let d=((b-a+Math.PI)%(Math.PI*2)+Math.PI*2)%(Math.PI*2)-Math.PI;return a+d*t};

// ---------- fx ----------
let AC;
let sndLast=0;
function snd(f,d,type='square',v=.15,slide=0){const nt=performance.now();if(nt-sndLast<28)return;sndLast=nt;try{AC=AC||new(window.AudioContext||window.webkitAudioContext)();const t=AC.currentTime,o=AC.createOscillator(),g=AC.createGain();o.type=type;o.frequency.setValueAtTime(f,t);if(slide)o.frequency.exponentialRampToValueAtTime(Math.max(20,f+slide),t+d);g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.001,t+d);o.connect(g);g.connect(AC.destination);o.start();o.stop(t+d)}catch(e){}}
const parts=[],pg=new THREE.BoxGeometry(.14,.14,.14);
for(let i=0;i<40;i++){const m=new THREE.Mesh(pg,new THREE.MeshBasicMaterial());m.visible=false;scene.add(m);parts.push({m,v:new THREE.Vector3(),l:0})}
function burst(x,y,z,col,n,sp){let c=0;for(const p of parts){if(p.l>0)continue;p.l=.5+Math.random()*.3;p.m.visible=true;p.m.material.color.setHex(col);p.m.position.set(x,y,z);p.v.set(rnd(-1,1)*sp,rnd(2,sp),rnd(-1,1)*sp);if(++c>=n)break}}
let popN=0;
function pop(txt,x,y,z,col,big){if(popN>12)return;popN++;const e=document.createElement('div');e.className='pop';e.textContent=txt;e.style.color=col;if(big)e.style.fontSize='30px';const v=new THREE.Vector3(x,y,z).project(cam);e.style.left=((v.x+1)/2*innerWidth)+'px';e.style.top=((1-v.y)/2*innerHeight)+'px';$('hud').appendChild(e);setTimeout(()=>{e.remove();popN--},800)}
function banner(t){const e=document.createElement('div');e.className='pop ban';e.textContent=t;$('hud').appendChild(e);setTimeout(()=>e.remove(),1800)}
function flash(){const e=$('flash');e.style.transition='none';e.style.opacity=.55;setTimeout(()=>{e.style.transition='opacity .45s';e.style.opacity=0},30)}
const pups=[],rings=[];
const acid=[],agm=new THREE.SphereGeometry(.24,8,8),amat=new THREE.MeshBasicMaterial({color:0x8dff3a});
for(let i=0;i<24;i++){const m=new THREE.Mesh(agm,amat);m.visible=false;scene.add(m);acid.push({m,l:0,vx:0,vz:0})}
function spit(z){const a=acid.find(p=>p.l<=0);if(!a)return;const dx=player.x-z.x,dz=player.z-z.z,d=Math.hypot(dx,dz)||1;a.l=2.6;a.vx=dx/d*10;a.vz=dz/d*10;a.m.visible=true;a.m.position.set(z.x,1.3,z.z);snd(260,.12,'sawtooth',.1,-120)}
const WL=['fist'],WE={fist:'👊',sword:'🗡️',gun:'🔫'};
const W={fist:{cd:.38,dmg:35,rng:2.7,arc:1.4,spd:2,kb:8,hit:.17,end:.42},sword:{cd:.6,dmg:65,rng:3.8,arc:1.8,spd:1.5,kb:11,hit:.28,end:.66},gun:{cd:.12}};
const laser=new THREE.Mesh(new THREE.BoxGeometry(.05,.05,1),new THREE.MeshBasicMaterial({color:0xff2a2a,transparent:true,opacity:.8,depthWrite:false}));laser.visible=false;scene.add(laser);
const ret=new THREE.Mesh(new THREE.RingGeometry(.7,.9,32),new THREE.MeshBasicMaterial({color:0xff2a2a,side:THREE.DoubleSide,transparent:true,opacity:.9,depthWrite:false}));ret.rotation.x=-Math.PI/2;ret.position.y=.12;ret.visible=false;scene.add(ret);
for(const[x,y,r]of[[1.15,0,0],[-1.15,0,0],[0,1.15,1.5708],[0,-1.15,1.5708]]){const k=new THREE.Mesh(new THREE.PlaneGeometry(.42,.1),ret.material);k.position.set(x,y,0);k.rotation.z=r;ret.add(k)}
ret.add(new THREE.Mesh(new THREE.CircleGeometry(.1,12),ret.material));
const bullets=[],bgeo=new THREE.BoxGeometry(.08,.08,.8),bmat=new THREE.MeshBasicMaterial({color:0xffe9a0});
for(let i=0;i<40;i++){const m=new THREE.Mesh(bgeo,bmat);m.visible=false;scene.add(m);bullets.push({m,l:0,vx:0,vz:0})}
// ---- Farmer character (rigged GLB with real animations) ----
function makeFarmer(height){
  const obj=THREE.SkeletonUtils.clone(FARM.scene);
  obj.traverse(o=>{if(o.isMesh){o.castShadow=true;o.frustumCulled=false}});
  const holder=new THREE.Group();holder.add(obj);
  const bb=new THREE.Box3().setFromObject(obj);const k=height/Math.max(.01,bb.max.y-bb.min.y);obj.scale.multiplyScalar(k);
  const mixer=new THREE.AnimationMixer(obj),acts={};
  FARM.animations.forEach(c=>{acts[c.name]=mixer.clipAction(c)});
  const A=(a,b)=>{if(acts[b])acts[a]=acts[b]};
  A('Run_Arms','Run_Shoot');A('Idle_Attack','Idle_Gun_Pointing');A('HitReact','HitRecieve');A('Slam','Kick_Right');A('Punch','Punch_Right');
  const ch={holder,obj,mixer,acts,cur:null,k,
    play(n,fade=.15,once=false,speed=1){const a=acts[n];if(!a)return;if(ch.cur===a&&!once)return;
      a.reset();a.timeScale=speed;a.setLoop(once?THREE.LoopOnce:THREE.LoopRepeat,Infinity);a.clampWhenFinished=once;
      if(ch.cur&&ch.cur!==a)ch.cur.fadeOut(fade);a.fadeIn(fade).play();ch.cur=a;ch.name=n}};
  return ch;
}
const QA=new THREE.Quaternion(),QB=new THREE.Quaternion();
function makeBrute(height){
  const obj=THREE.SkeletonUtils.clone(BRU.scene);
  obj.traverse(o=>{if(o.isMesh){o.castShadow=false}});
  const holder=new THREE.Group();holder.add(obj);
  const bb=new THREE.Box3().setFromObject(obj);obj.scale.multiplyScalar(height/Math.max(.01,bb.max.y-bb.min.y));
  const mixer=new THREE.AnimationMixer(obj),acts={};
  BRU.animations.forEach(c=>{acts[c.name]=mixer.clipAction(c)});
  const ch={holder,obj,mixer,acts,cur:null,
    play(n,fade=.15,once=false,speed=1){const a=acts[n];if(!a)return;if(ch.cur===a&&!once)return;
      a.reset();a.timeScale=speed;a.setLoop(once?THREE.LoopOnce:THREE.LoopRepeat,Infinity);a.clampWhenFinished=once;
      if(ch.cur&&ch.cur!==a)ch.cur.fadeOut(fade);a.fadeIn(fade).play();ch.cur=a;ch.name=n}};
  return ch;
}
function mkZ(T){return T.model==='dog'?makeDog(T.mh):T.model==='brute'?makeBrute(T.mh):makeChar(T.tint,T.h)}
function makeDog(height){
  const obj=THREE.SkeletonUtils.clone(DOG.scene);
  obj.traverse(o=>{if(o.isMesh){o.castShadow=false}});
  const holder=new THREE.Group();holder.add(obj);
  const bb=new THREE.Box3().setFromObject(obj);obj.scale.multiplyScalar(height/Math.max(.01,bb.max.y-bb.min.y));
  const mixer=new THREE.AnimationMixer(obj),acts={};
  DOG.animations.forEach(c=>{acts[c.name]=mixer.clipAction(c)});
  acts.Punch=acts.Attack;acts.HitReact=acts.Idle_HitReact_Left;
  const ch={holder,obj,mixer,acts,cur:null,
    play(n,fade=.15,once=false,speed=1){const a=acts[n];if(!a)return;if(ch.cur===a&&!once)return;
      a.reset();a.timeScale=speed;a.setLoop(once?THREE.LoopOnce:THREE.LoopRepeat,Infinity);a.clampWhenFinished=once;
      if(ch.cur&&ch.cur!==a)ch.cur.fadeOut(fade);a.fadeIn(fade).play();ch.cur=a;ch.name=n}};
  return ch;
}
function buildAK(){
  const g=new THREE.Group(),M=(c,m,r)=>new THREE.MeshStandardMaterial({color:c,metalness:m,roughness:r}),
   mt=M(0x2c2f34,.7,.4),dk=M(0x1b1d21,.6,.5),wd=M(0x8a4a1c,.05,.7),bk=M(0x3a2416,.1,.6);
  const B=(w,h,d,m,x,y,z,rz)=>{const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);o.position.set(x,y,z||0);if(rz)o.rotation.z=rz;g.add(o)};
  const C=(r,len,m,x,y)=>{const o=new THREE.Mesh(new THREE.CylinderGeometry(r,r,len,10),m);o.position.set(x,y,0);g.add(o)};
  // barrel runs along +Y, the top of the gun is -X, the grip hangs toward +X
  B(.055,.30,.040,mt,0,.12);B(.02,.28,.036,mt,-.035,.12);B(.018,.04,.03,dk,-.052,.2);B(.01,.03,.02,dk,-.045,.1,.03);
  C(.0095,.38,dk,-.022,.45);C(.0085,.2,mt,-.045,.42);C(.014,.05,dk,-.022,.66);
  B(.05,.20,.042,wd,-.004,.35);B(.02,.17,.04,wd,-.04,.36);B(.03,.012,.006,dk,-.058,.61);B(.02,.03,.03,dk,-.04,.6);
  B(.085,.045,.032,dk,.07,.11,0,.10);B(.085,.045,.032,dk,.14,.13,0,.28);B(.085,.045,.032,dk,.208,.165,0,.46);
  B(.095,.03,.032,bk,.07,.035,0,-.22);B(.004,.07,.03,dk,.035,.085);B(.022,.008,.006,dk,.03,.085);
  B(.065,.26,.036,wd,.008,-.17,0,.06);B(.08,.012,.04,dk,.012,-.30);
  return g}
function mkGunPickup(x,z){const g=new THREE.Group(),ak=buildAK();ak.rotation.z=-Math.PI/2;ak.position.set(-.18,.6,0);g.add(ak);
  const ring=new THREE.Mesh(new THREE.RingGeometry(.9,1.15,28),new THREE.MeshBasicMaterial({color:0xff7bff,side:THREE.DoubleSide,transparent:true,opacity:.7,depthWrite:false}));ring.rotation.x=-Math.PI/2;ring.position.y=.06;g.add(ring);
  const beam=new THREE.Mesh(new THREE.CylinderGeometry(.12,.12,7,8,1,true),new THREE.MeshBasicMaterial({color:0xff7bff,transparent:true,opacity:.22,depthWrite:false,side:THREE.DoubleSide}));beam.position.y=3.5;g.add(beam);
  g.position.set(x,0,z);return{g,ak,x,z}}
function addWeapons(ch){
  let bone=null;ch.obj.traverse(o=>{if(!bone&&/^wrist[._]?r$/i.test(o.name))bone=o});if(!bone)ch.obj.traverse(o=>{if(!bone&&/(hand|fist|palm).*r$/i.test(o.name))bone=o});if(!bone)bone=ch.obj;ch.holder.updateMatrixWorld(true);
  const ws=new THREE.Vector3();bone.getWorldScale(ws);const sc=1/(ws.x||1);
  const mk=(c,e)=>new THREE.MeshStandardMaterial({color:c,metalness:.6,roughness:.35,emissive:e||0,emissiveIntensity:.6});
  const bx=(w,h,d,mat,x,y,z)=>{const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat);m.position.set(x,y,z);m.castShadow=true;return m};
  const sw=new THREE.Group();
  sw.add(bx(.8,.075,.02,mk(0xe6eeff,0x5577cc),-.58,0,0));sw.add(bx(.04,.06,.3,mk(0xffc040,0x553300),-.17,0,0));
  sw.add(bx(.26,.045,.045,mk(0x5a3418),0,0,0));sw.add(bx(.06,.07,.07,mk(0xffc040),.14,0,0));
  const gn=buildAK();sw.scale.setScalar(sc);gn.scale.setScalar(sc*.9);
  for(const g of[sw,gn]){g.position.set(0,.06,0);g.visible=false;bone.add(g)}
  sw.quaternion.copy(QB);
  return{sw,gn};
}
function setWpn(w){if(!player)return;player.wpn=w;player.sw.visible=w==='sword';player.gn.visible=w==='gun';$('wpn').textContent=WE[w];$('punch').textContent=WE[w];if(w!=='gun'){laser.visible=ret.visible=false}snd(380,.07,'triangle',.12,200)}
function findAim(moving){let b=null,bd=34;for(const z of zombies){if(z.dead)continue;const dx=z.x-player.x,dz=z.z-player.z,d=Math.hypot(dx,dz);if(d>bd)continue;if(moving&&Math.abs(ang(player.rot,Math.atan2(dx,dz),1)-player.rot)>.8)continue;bd=d;b=z}return b}
function assistTarget(){let b=null,bs=1e9;for(const z of zombies){if(z.dead)continue;const dx=z.x-player.x,dz=z.z-player.z,d=Math.hypot(dx,dz);if(d>26)continue;
  const da=Math.abs(ang(player.rot,Math.atan2(dx,dz),1)-player.rot);if(da>.95)continue;const s=da*8+d*.25;if(s<bs){bs=s;b=z}}return b}
function toggleAuto(){autoAim=!autoAim;const e=$('auto');e.style.opacity=autoAim?1:.45;e.style.borderColor=autoAim?'#7dff7d':'#fff';snd(autoAim?600:300,.08,'triangle',.12,0)}
function shoot(){
  if(player.cd>0)return;if(ammo<=0){player.cd=.35;snd(140,.06,'square',.1,-40);pop('NO AMMO',player.x,2.3,player.z,'#ff8a8a',false);return}player.cd=W.gun.cd;
    const a=player.rot,sx=Math.sin(a),cz=Math.cos(a),b=bullets.find(b=>b.l<=0);if(!b)return;
  ammo--;b.l=.7;b.vx=sx*55;b.vz=cz*55;b.m.visible=true;b.m.position.set(player.x+sx*.9,1.37,player.z+cz*.9);b.m.rotation.y=a;
  burst(player.x+sx*1,1.37,player.z+cz*1,0xffd070,5,2);snd(480,.07,'square',.1,-300);shake=Math.max(shake,.08);
}
const PU={ammo:[0x62ff7a,()=>new THREE.BoxGeometry(.55,.36,.4)],heart:[0xff3355,()=>new THREE.SphereGeometry(.35,12,12)],speed:[0xffe14a,()=>new THREE.OctahedronGeometry(.42)],power:[0xff8a2e,()=>new THREE.IcosahedronGeometry(.42)]};
const puGeo={},puMat={},ringG=new THREE.RingGeometry(.55,.72,24),RING_S=new THREE.RingGeometry(.8,1.2,48);
function puAssets(k){if(!puGeo[k]){puGeo[k]=PU[k][1]();puMat[k]=new THREE.MeshBasicMaterial({color:PU[k][0]});puMat['r'+k]=new THREE.MeshBasicMaterial({color:PU[k][0],side:THREE.DoubleSide,transparent:true,opacity:.7})}}
function dropPU(x,z,force,kind){let k=kind;
  if(!k){if(healthPending&&(force||Math.random()<.35)){k='heart';healthPending=false}
    else{if(!force&&Math.random()>.2)return;const r=Math.random();k=r<.45?'ammo':r<.75?'speed':'power'}}
  const c=PU[k][0];
  puAssets(k);const m=new THREE.Mesh(puGeo[k],puMat[k]);m.position.set(x,.9,z);
  const r=new THREE.Mesh(ringG,puMat['r'+k]);r.rotation.x=-Math.PI/2;r.position.y=-.85;m.add(r);scene.add(m);pups.push({m,k,t:14})}
function ring(x,z){const m=new THREE.Mesh(RING_S,new THREE.MeshBasicMaterial({color:0xffd23a,side:THREE.DoubleSide,transparent:true,opacity:.9,depthWrite:false}));m.rotation.x=-Math.PI/2;m.position.set(x,.1,z);scene.add(m);rings.push({m,t:0})}

// ---------- state ----------
let paused=false,hintJoy=false,menu=false,menuAng=.6,menuDrag=0;
let camYaw=0,camH=5.2,holding=false,zk=1,zT=1,camDragT=0;const _cv=new THREE.Vector3();let hbest;
let hasGun=false,gunStart=null,carSpawn=null;const gunTaken=new Set();
let ammo=0,healthPending=false,runOn=false;const healthWaves=new Set(),ammoTaken=new Set();const ZP=[1,.62,.4];const aim={on:false,a:0,id:null,sx:0,sy:0},mouse={x:0,y:0,has:false,t:0};let autoAim=true;
let player,zombies=[],kills=0,score=0,wave=0,running=false,over=false,toSpawn=0,spawnT=0,waveDelay=0,streak=0,streakT=0,shake=0,lastStreak=0;
const keys={},joy={x:0,y:0};
const camPos=new THREE.Vector3(0,5.2,7);
const PTS={normal:10,runner:15,tank:40,boss:200,spitter:25,dog:20,brute:60};
function ui(){$('hp').style.width=Math.max(0,player.hp)+'%';$('wave').textContent='Wave '+wave;$('kills').textContent='💀 '+kills+'  ⭐ '+score}
function disposeChar(ch){scene.remove(ch.holder);ch.obj.traverse(o=>{if(o.isSkinnedMesh&&o.skeleton&&o.skeleton.dispose)o.skeleton.dispose()})}
function startGame(){
  menu=false;document.body.classList.remove('inmenu');musStop(true);
  zombies.forEach(z=>freeChar(z.ch));zombies=[];
  pups.forEach(p=>scene.remove(p.m));pups.length=0;
  if(!player){const ch=makeFarmer(1.8);scene.add(ch.holder);player=Object.assign({ch,lean:0},addWeapons(ch))}
  resetCars();Object.assign(player,{x:0,z:0,rot:Math.PI,hp:100,cd:0,pt:-1,hit:false,inv:0,dead:false,cstep:0,ct:0,lv:0,slam:0,spdT:0,powT:0,moving:false,stam:100,tired:false,spd:0,mdx:0,mdz:-1,y:0,vy:0,sq:0});setWpn('fist');
  player.ch.acts.Death&&player.ch.acts.Death.stop();player.ch.cur=null;player.ch.play('Idle');
  runOn=false;qAcc=0;qN=0;qWarm=1;opened.clear();ammoTaken.clear();ammo=0;hasGun=false;WL.length=0;WL.push('fist');gunTaken.clear();swordTaken.clear();doorMem.clear();carSpawn=null;gunStart=null;swordStart=null;document.body.classList.add('nogun');healthWaves.clear();{const n=2+(Math.random()<.5?1:0);while(healthWaves.size<n)healthWaves.add(2+Math.floor(Math.random()*9))}healthPending=false;acid.forEach(a=>{a.l=0;a.m.visible=false});refreshWorld();placeStart();kills=0;score=0;streak=0;wave=0;over=false;running=true;toSpawn=0;waveDelay=.5;
  $('start').style.display='none';$('over').style.display='none';ui();
}
function pickType(){const r=Math.random();if(wave>=4&&r>.93&&zombies.filter(z=>!z.dead&&z.type==='brute').length<2)return'brute';if(wave>=3&&r>.88&&zombies.filter(z=>!z.dead&&z.type==='dog').length<2)return'dog';if(wave>=4&&r>.8)return'spitter';if(wave>=3&&r<.15)return'tank';if(wave>=2&&r<.4)return'runner';return'normal'}
function zType(type){return {normal:{h:1.8,hp:60+wave*9,sp:rnd(1.4,2)+wave*.12,dmg:5,tint:0},runner:{h:1.55,hp:35+wave*3,sp:3.3+wave*.08,dmg:3,tint:0},tank:{h:2.5,hp:160+wave*12,sp:1.05,dmg:9,tint:0},boss:{h:3.8,hp:500+wave*50,sp:1.5,dmg:14,tint:0},spitter:{h:1.7,hp:45+wave*5,sp:1.9,dmg:0,tint:0},dog:{h:1.5,mh:1.3,reach:1.5,hp:45+wave*4,sp:4.6,dmg:7,tint:0,model:'dog',per:.9,hitT:.4,ats:1.33},brute:{h:2.6,mh:2.5,reach:2.1,hp:240+wave*22,sp:1.6,dmg:16,tint:0,model:'brute',per:.9,hitT:.45,ats:1.1}}[type]}
const zpool={};
function getChar(type,T){const L=zpool[type]||(zpool[type]=[]);let ch=L.pop();if(!ch)ch=mkZ(T);
  ch.mixer.stopAllAction();ch.cur=null;ch.name=null;ch.holder.position.set(0,0,0);ch.holder.rotation.set(0,0,0);ch.holder.visible=true;ch.type=type;return ch}
function freeChar(ch){scene.remove(ch.holder);(zpool[ch.type]||(zpool[ch.type]=[])).push(ch)}
function prewarmPool(){for(const [type,n] of [['normal',10],['runner',3],['tank',2],['boss',1],['spitter',3],['dog',2],['brute',1]]){const T=zType(type),L=zpool[type]||(zpool[type]=[]);
  for(let k=0;k<n;k++){const ch=mkZ(T);ch.type=type;L.push(ch)}}}
function spawnPos(){let x=0,z=0;
  for(let i=0;i<8;i++){const r=rnd(20,36),a=Math.random()<.5?Math.atan2(player.mdx,player.mdz)+rnd(-1.4,1.4):Math.random()*6.28;x=player.x+Math.sin(a)*r;z=player.z+Math.cos(a)*r;if(!blockedAt(x,z)&&!inHouseZone(x,z,1.5))break}
  return{x,z}}
function startRise(z,quiet){z.rise=1.2;z.ch.holder.position.set(z.x,-z.h*1.05,z.z);z.ch.play('Idle',.05);if(!quiet){burst(z.x,.2,z.z,0x6b4a2e,10,4);snd(80,.35,'sawtooth',.06,-30)}}
function spawnNear(n){for(let i=0;i<n;i++)spawn(undefined,spawnPos())}
function spawn(type,pos){
  type=type||pickType();
  const T=zType(type);
  const ch=getChar(type,T);scene.add(ch.holder);
  const sp0=pos||spawnPos();
  const z={ch,type,h:T.h,reach:T.reach||1.4*T.h/1.8,per:T.per||.64,hitT:T.hitT||.26,ats:T.ats||1.2,dmg:T.dmg,x:sp0.x,z:sp0.z,rot:0,hp:T.hp,max:T.hp,sp:T.sp,st:'chase',t:0,cd:rnd(.3,1),dead:false,hitDone:false,knx:0,knz:0};
  startRise(z);zombies.push(z);
}
function attack(){
  if(!running||player.dead||player.cd>0||player.car)return;
  if(player.wpn==='gun'){shoot();return}
  const w=W[player.wpn];player.cd=w.cd;player.cstep=player.ct>0?player.cstep%3+1:1;player.ct=.9;player.pt=0;player.hit=false;
  let best=null,bd=4;for(const z of zombies){if(z.dead)continue;const d=Math.hypot(z.x-player.x,z.z-player.z);if(d<bd){bd=d;best=z}}
  if(best)player.rot=Math.atan2(best.x-player.x,best.z-player.z);
  player.lv=4;player.ch.play(player.wpn==='sword'?'Sword_Slash':(player.cstep%2?'Punch_Right':'Punch_Left'),.06,true,player.cstep===3?w.spd*.85:w.spd);snd(player.wpn==='sword'?330:260,.1,player.wpn==='sword'?'sawtooth':'triangle',.1,-150);
}
function slam(){
  if(!running||player.dead||player.slam>0||player.car)return;
  player.slam=7;player.inv=.7;player.pt=0;player.hit=true;player.ch.play('Slam',.05,true,1.1);
  ring(player.x,player.z);shake=1;flash();snd(110,.5,'sawtooth',.28,-60);burst(player.x,.3,player.z,0xffd23a,24,9);
  for(const z of zombies){if(z.dead)continue;const dx=z.x-player.x,dz=z.z-player.z,d=Math.hypot(dx,dz)||.01;if(d<8)hitZ(z,70,16,dx,dz,d,true)}
}
function hitZ(z,dmg,kb,dx,dz,d,crit){
  z.hp-=dmg;const f=kb/(z.type==='tank'?2:z.type==='brute'?3:z.type==='boss'?5:1);z.knx=dx/d*f;z.knz=dz/d*f;
  const k=z.h/1.8;burst(z.x,1.2*k,z.z,0x7bd34a,crit?16:9,crit?7:5);
  pop(Math.round(dmg),z.x,2.2*k,z.z,crit?'#ffd23a':'#fff',crit);
  snd(crit?140:210,.12,'square',.2,-100);shake=Math.max(shake,crit?.55:.2);
  streak++;streakT=2.2;
  if(z.hp<=0){z.dead=true;z.t=0;z.ch.play('Death',.08,true);kills++;score+=PTS[z.type]*(1+Math.floor(streak/5));
    player.slam=Math.max(0,player.slam-1);dropPU(z.x,z.z,z.type==='boss');snd(90,.3,'sawtooth',.22,-40);z.knx*=1.7;z.knz*=1.7;
    if(z.type==='boss')banner('BOSS DOWN! 🎉')}
  else{z.st='hit';z.t=z.type==='boss'?.12:.45;z.ch.play('HitReact',.05,true,1.3)}
  ui();
}
function doJump(){if(!running||player.dead||player.car||player.y>.02)return;player.vy=8.2;player.y=.001;player.sq=0;snd(330,.12,'triangle',.07,250)}
function hurtPlayer(d){
  if(player.car)d*=.35;
  if(player.y>.6)return;
  if(player.inv>0||player.dead)return;
  player.hp-=d;player.inv=.4;streak=0;shake=.5;flash();snd(120,.25,'sawtooth',.25,-60);ui();
  if(player.hp<=0){player.dead=true;player.ch.play('Death',.1,true);running=false;
    let nb='';try{const b=+localStorage.getItem('zpbest')||0;if(score>b){localStorage.setItem('zpbest',score);nb=' 🏆 New record!'}else nb=' • Best '+b}catch(e){}
    setTimeout(()=>{over=true;$('res').textContent=`Score ${score} • ${kills} zombies • Wave ${wave}`+nb;$('over').style.display='flex'},1500)}
}

let last=performance.now(),fc=0;
function loop(now){
  requestAnimationFrame(loop);
  const rdt=Math.min(.25,(now-last)/1000);
  if(rdt<.0095&&!paused)return;
  if(menu&&!editing){last=now;menuTick(Math.min(.05,rdt),now);renderer.render(scene,cam);return}
  if(paused){last=now;renderer.render(scene,cam);return}
  const dt=Math.min(.05,rdt);last=now;fc++;
  if(running){qAcc+=rdt;qN++;if(qAcc>=3){const fps=qN/qAcc;qAcc=0;qN=0;if(qWarm>0)qWarm--;else if(fps<42&&qLevel>0){qMax=qLevel-1;qGood=0;applyQuality(qLevel-1)}else if(fps>=57&&qLevel<qMax){if(++qGood>=4){qGood=0;applyQuality(qLevel+1)}}else qGood=0}}
  for(const p of parts){if(p.l>0){p.l-=dt;p.v.y-=14*dt;p.m.position.addScaledVector(p.v,dt);if(p.m.position.y<.05){p.m.position.y=.05;p.v.multiplyScalar(.5)}if(p.l<=0)p.m.visible=false}}
  for(let i=rings.length-1;i>=0;i--){const r=rings[i];r.t+=dt;r.m.scale.setScalar(1+r.t*16);r.m.material.opacity=Math.max(0,.9-r.t*2);if(r.t>.45){scene.remove(r.m);r.m.material.dispose();rings.splice(i,1)}}
  if(player){
    let ix=joy.x+(keys.d||keys.arrowright?1:0)-(keys.a||keys.arrowleft?1:0);
    let iy=joy.y+(keys.s||keys.arrowdown?1:0)-(keys.w||keys.arrowup?1:0);
    if(runOn&&!player.tired&&running&&!player.dead){ix=0;iy=-1}
    if(player.car){ix=0;iy=0;runOn=false}
    const il=Math.hypot(ix,iy);if(il>1){ix/=il;iy/=il}
    const cy=Math.cos(camYaw),sy=Math.sin(camYaw),wx=ix*cy+iy*sy,wz=-ix*sy+iy*cy;
    if(keys.q)camYaw-=dt*2;if(keys.r)camYaw+=dt*2;
    const aimT=(player.wpn==='gun'&&autoAim&&running&&!player.dead&&holding&&!aim.on&&!(mouse.has&&now-mouse.t<1500))?assistTarget():null;
    if(running&&!player.dead){
      player.cd-=dt;if(holding)attack();player.inv-=dt;player.ct-=dt;player.slam=Math.max(0,player.slam-dt);player.spdT-=dt;player.powT-=dt;
      streakT-=dt;if(streakT<=0)streak=0;
      let ran=false;const moving=il>.12,busy=player.pt>=0,pw=player.powT>0;player.moving=moving;const w=W[player.wpn]||W.fist;
      if(moving){
        if(player.tired&&player.stam>30)player.tired=false;const wantRun=(runOn||keys.shift)&&!player.tired,walk=!wantRun,tgt=(busy?2.2:(walk?3.6:5.6))*(player.spdT>0?1.4:1);player.spd+=(tgt-player.spd)*Math.min(1,dt*8);const sp=player.spd;player.walk=walk;if(!walk&&!busy){ran=true;player.stam=Math.max(0,player.stam-22*dt);if(player.stam<=0){player.tired=true;runOn=false}}player.x+=wx*sp*dt;player.z+=wz*sp*dt;{const ml=Math.hypot(wx,wz)||1;player.mdx=wx/ml;player.mdz=wz/ml}
        if((!busy||!player.hit)&&!(player.wpn==='gun'&&aim.on))player.rot=ang(player.rot,Math.atan2(wx,wz),Math.min(1,dt*14));
      }else player.spd*=Math.max(0,1-dt*12);
      if(player.wpn==='gun'&&aim.on)player.rot=ang(player.rot,aim.a,Math.min(1,dt*22));
      if(aimT&&(!moving||holding))player.rot=ang(player.rot,Math.atan2(aimT.x-player.x,aimT.z-player.z),Math.min(1,dt*18));
      if(player.lv>.1){player.x+=Math.sin(player.rot)*player.lv*dt;player.z+=Math.cos(player.rot)*player.lv*dt;player.lv-=player.lv*dt*9}
      if(busy){
        player.pt+=dt;
        if(!player.hit&&player.pt>w.hit){player.hit=true;
          const crit=player.cstep===3,dmg=w.dmg*(pw?2:1)*(crit?1.7:1),rng=w.rng*(pw?1.3:1);let any=false;
          for(const z of zombies){if(z.dead)continue;
            const dx=z.x-player.x,dz=z.z-player.z,d=Math.hypot(dx,dz)||.01;
            if(d<rng+z.h*.2){const da=Math.abs(ang(player.rot,Math.atan2(dx,dz),1)-player.rot);
              if(da<w.arc||d<1.3){any=true;hitZ(z,dmg,(crit?1.7:1)*w.kb,dx,dz,d,crit)}}}
          if(!any)snd(120,.08,'sine',.06,-40)}
        if(player.pt>(w.end||.6))player.pt=-1;
      }
      if(!busy){const g=player.wpn==='gun';const s=player.spd,slow=s<2.4;player.ch.play(player.y>.02?(g?'Run_Arms':'Run'):moving?(g?'Run_Arms':(slow?'Walk':'Run')):(g?(holding?'Idle_Attack':'Idle_Gun'):(player.wpn==='sword'?'Idle_Sword':'Idle')),.2);if(player.ch.cur)player.ch.cur.timeScale=player.y>.02?.9:moving?Math.min(2.2,Math.max(.5,s/((g||!slow)?3.02:1.3))):1}
      const lt=moving&&!busy?Math.min(.18,player.spd*.03):0;player.lean+=(lt-player.lean)*Math.min(1,dt*8);player.ch.obj.rotation.x=player.lean;
      if(!ran)player.stam=Math.min(100,player.stam+18*dt);
      pushOut(player,.45);
      // pickups
      for(let i=pups.length-1;i>=0;i--){const p=pups[i];p.t-=dt;p.m.rotation.y+=dt*3;p.m.position.y=.9+Math.sin(now/220+i)*.15;p.m.visible=p.t>3||Math.floor(p.t*6)%2===0;
        if(Math.hypot(p.m.position.x-player.x,p.m.position.z-player.z)<1.5){
          if(p.k==='heart'){player.hp=Math.min(100,player.hp+35);pop('+HP',player.x,2.4,player.z,'#ff5577',true)}
          else if(p.k==='ammo'){ammo=Math.min(60,ammo+10+(Math.random()*8|0));pop('+AMMO',player.x,2.4,player.z,'#62ff7a',true)}
          else if(p.k==='speed'){player.spdT=8;pop('⚡ SPEED',player.x,2.4,player.z,'#ffe14a',true)}
          else{player.powT=8;pop('👊 POWER x2',player.x,2.4,player.z,'#ff8a2e',true)}
          snd(520,.2,'sine',.2,500);ui();scene.remove(p.m);pups.splice(i,1)}
        else if(p.t<=0){scene.remove(p.m);pups.splice(i,1)}}
      // waves
      if(toSpawn<=0&&zombies.every(z=>z.dead)){waveDelay-=dt;if(waveDelay<=0){wave++;toSpawn=4+wave*3;spawnT=0;waveDelay=2;ui();banner('WAVE '+wave);if(healthWaves.has(wave))healthPending=true;{const nn=Math.min(toSpawn,4+(Math.random()<.5?1:0));spawnNear(nn);toSpawn-=nn}if(wave%5===0){spawn('boss');banner('⚠ BOSS! ⚠')}}}
      if(toSpawn>0){spawnT-=dt;if(spawnT<=0){const alive=zombies.filter(z=>!z.dead);if(alive.length<ZCAP){spawn();toSpawn--;spawnT=.5}}}
    }
    if(player.y>0||player.vy>0){player.vy-=24*dt;player.y+=player.vy*dt;if(player.y<=0){player.y=0;player.vy=0;player.sq=.12;snd(110,.08,'square',.05,-40)}}
    if(player.sq>0)player.sq=Math.max(0,player.sq-dt*.9);
    {const st=player.y>0?Math.min(.08,Math.abs(player.vy)*.008):0,sq=player.sq;player.ch.holder.scale.set(1-st*.4+sq*.6,1+st-sq,1-st*.4+sq*.6)}
    player.ch.holder.position.set(player.x,player.y,player.z);player.ch.holder.rotation.y=player.rot+FACE;
    player.ch.mixer.update(dt);
    if(player.sw){player.sw.quaternion.slerp(player.pt>=0&&player.wpn==='sword'?QA:QB,Math.min(1,dt*16))}
    for(const b of bullets){if(b.l<=0)continue;b.l-=dt;b.m.position.x+=b.vx*dt;b.m.position.z+=b.vz*dt;
      for(const z of zombies){if(z.dead)continue;const dx=z.x-b.m.position.x,dz=z.z-b.m.position.z,r=.55*z.h/1.8+.25;
        if(dx*dx+dz*dz<r*r){hitZ(z,28*(player.powT>0?2:1),3,b.vx,b.vz,55,false);b.l=0;break}}
      if(b.l<=0)b.m.visible=false}
    const gunOn=player.wpn==='gun'&&running&&!player.dead&&!player.car;laser.visible=ret.visible=gunOn;
    if(gunOn){const a=player.rot,sx=Math.sin(a),cz2=Math.cos(a);let L=22,hit=false;
      for(const z of zombies){if(z.dead)continue;const dx=z.x-player.x,dz=z.z-player.z,tt=dx*sx+dz*cz2;if(tt<.8||tt>=L)continue;
        if(Math.abs(dx*cz2-dz*sx)<.55*z.h/1.8+.25){L=tt;hit=true}}
      const len=Math.max(.2,L-.9);laser.position.set(player.x+sx*(.9+len/2),1.37,player.z+cz2*(.9+len/2));laser.rotation.y=a;laser.scale.z=len;
      ret.position.x=player.x+sx*L;ret.position.z=player.z+cz2*L;ret.scale.setScalar((hit?1.25:1)*(1+Math.sin(now/110)*.06));
      ret.material.color.setHex(hit?0xff2a2a:0x7dff7d);laser.material.color.setHex(hit?0xff2a2a:0x7dff7d)}
    for(const a of acid){if(a.l<=0)continue;a.l-=dt;let hit=false;
      for(let s=0;s<2&&!hit;s++){a.m.position.x+=a.vx*dt/2;a.m.position.z+=a.vz*dt/2;if(blockedAt(a.m.position.x,a.m.position.z)){hit=true}}
      if(!hit&&!player.dead&&Math.hypot(a.m.position.x-player.x,a.m.position.z-player.z)<.8){hurtPlayer(8);hit=true;burst(player.x,1.2,player.z,0x8dff3a,8,4)}
      if(hit||a.l<=0){a.l=0;a.m.visible=false}}
    if(fc%3===0){
    $('ammo').style.display=player.wpn==='gun'?'block':'none';$('ammo').textContent='🔫 '+ammo+(ammo<=0?' EMPTY':'');
    const rb=$('run');rb.style.borderColor=runOn?'#ffb02e':'#fff';rb.style.background=runOn?'#c4601acc':'#1d2b4acc';rb.style.opacity=player.tired?.4:1;$('stfill').style.width=player.stam+'%';$('stfill').style.background=player.tired?'#ff5a3c':'#46c7ff';
    // HUD bits
    const bt=[];if(player.spdT>0)bt.push('⚡'+Math.ceil(player.spdT));if(player.powT>0)bt.push('👊x2 '+Math.ceil(player.powT));
    $('buff').style.display=bt.length?'block':'none';$('buff').textContent=bt.join('  ');
    const sl=$('slam');sl.textContent=player.slam>0?Math.ceil(player.slam):'💥';sl.style.opacity=player.slam>0?.55:1;
    const cb=$('combo');if(streak!==lastStreak){lastStreak=streak;if(streak>=3){cb.textContent=streak+' COMBO!';cb.style.opacity=1;cb.style.transform='translateX(-50%) scale(1.25)';setTimeout(()=>cb.style.transform='translateX(-50%)',90)}else cb.style.opacity=0}
    const bs=zombies.find(z=>z.type==='boss'&&!z.dead);$('boss').style.display=bs?'block':'none';if(bs)$('bhp').style.width=Math.max(0,bs.hp/bs.max*100)+'%';
    }
    // zombies
    for(const z of zombies){
      {const ddz=(z.x-player.x)*(z.x-player.x)+(z.z-player.z)*(z.z-player.z);if(ddz<225)z.ch.mixer.update(dt);else if(ddz<1600){if(fc%2===0)z.ch.mixer.update(dt*2)}else if(ddz<6400&&fc%4===0)z.ch.mixer.update(dt*4)}
      if(Math.abs(z.knx)+Math.abs(z.knz)>.2){z.x+=z.knx*dt;z.z+=z.knz*dt;const kf=Math.pow(z.kd||.86,dt*60);z.knx*=kf;z.knz*=kf}else z.kd=0;
      if(z.fly){const f=z.fly;f.vy-=22*dt;f.y+=f.vy*dt;if(f.y<=0){z.fly=null;z.ch.obj.rotation.x=0}else z.ch.obj.rotation.x+=f.spin*dt}
      if(z.dead){z.t+=dt;if(z.t>.9)z.ch.holder.position.y-=dt*.9;if(z.t>1.9){freeChar(z.ch);z.gone=true}z.ch.holder.position.x=z.x;z.ch.holder.position.z=z.z;if(z.fly)z.ch.holder.position.y=z.fly.y;continue}
      if(z.fly){z.ch.holder.position.set(z.x,z.fly.y,z.z);z.ch.holder.rotation.y=z.rot;continue}
      if(z.rise>0){z.rise-=dt;const u=1-Math.max(0,z.rise)/1.2;z.ch.holder.position.set(z.x,-z.h*1.05*(1-u),z.z);z.ch.holder.rotation.y=z.rot;if(fc%4===0)burst(z.x,.15,z.z,0x6b4a2e,2,2.5);continue}
      const dx=player.x-z.x,dz=player.z-z.z,d=Math.hypot(dx,dz)||1e-3;
      if(d>60){const p=spawnPos();z.x=p.x;z.z=p.z;z.st='chase';z.t=0;startRise(z,true)}
      let mx=dx,mz=dz,dEff=d;const HH=player.house;
      if(HH&&!(Math.abs(z.x-HH.x)<HH.w/2&&Math.abs(z.z-HH.z)<HH.d/2)){dEff=Math.max(d,z.reach+1);const ex=HH.x-z.x,ez=HH.z+HH.d/2+1.3-z.z;if(ex*ex+ez*ez>5){mx=ex;mz=ez}}
      const md=Math.hypot(mx,mz)||1e-3,boost=d>scene.fog.far*.8?2.1:1;
      z.cd-=dt;
      if(z.st==='hit'){z.t-=dt;if(z.t<=0){z.st='chase';z.ch.play('Walk',.1)}}
      else if(z.type!=='spitter'&&!player.dead&&doorNear(z,HH)){
        const D=doorOf(HH);z.rot=ang(z.rot,Math.atan2(D.x-z.x,D.z-z.z),Math.min(1,dt*8));
        if(z.st!=='door'){z.st='door';z.t=0;z.hitDone=false;z.ch.play('Punch',.08,true,z.ats)}
        z.t+=dt;if(!z.hitDone&&z.t>z.hitT){z.hitDone=true;hitDoor(D,z)}
        if(z.t>z.per){z.t=0;z.hitDone=false;z.ch.play('Punch',.04,true,z.ats)}
      }
      else if(z.type==='spitter'){
        if(player.dead){z.ch.play('Idle')}
        else{
          z.rot=ang(z.rot,Math.atan2(dx,dz),Math.min(1,dt*6));
          if(z.t>0)z.t-=dt;
          else if(dEff>12){z.x+=mx/md*z.sp*boost*dt;z.z+=mz/md*z.sp*boost*dt;z.ch.play('Walk',.15)}
          else if(dEff<7){z.x-=dx/d*z.sp*.9*dt;z.z-=dz/d*z.sp*.9*dt;z.ch.play('Walk',.15)}
          else z.ch.play('Idle',.15);
          if(z.cd<=0&&dEff<15&&z.t<=0){spit(z);z.cd=2.2+Math.random()*.8;z.t=.5;z.ch.play('Punch',.08,true,1.3)}
        }
      }
      else if(z.st==='attack'){
        z.t+=dt;z.rot=ang(z.rot,Math.atan2(dx,dz),Math.min(1,dt*8));
        if(!z.hitDone&&z.t>z.hitT){z.hitDone=true;if(dEff<z.reach+.7)hurtPlayer(z.dmg)}
        if(z.t>z.per){if(dEff<=z.reach+.5&&!player.dead){z.t=0;z.hitDone=false;z.ch.play('Punch',.04,true,z.ats)}else{z.st='chase';z.cd=0;z.ch.play('Walk',.1)}}
      }else{
        if(player.dead){z.ch.play('Idle')}
        else{
          z.rot=ang(z.rot,Math.atan2(mx,mz),Math.min(1,dt*6));
          if(dEff>z.reach){z.x+=mx/md*z.sp*boost*dt;z.z+=mz/md*z.sp*boost*dt;z.ch.play(z.sp>2.4?'Run':'Walk',.15,false,z.sp>2.4?.9:1)}
          else if(z.cd<=0){z.st='attack';z.t=0;z.hitDone=false;z.ch.play('Punch',.08,true,z.ats)}else{z.ch.play('Idle',.15)}
        }
      }
      for(const o of zombies){if(o===z||o.dead)continue;const ox=z.x-o.x,oz=z.z-o.z,od=Math.hypot(ox,oz);if(od<.9&&od>1e-3){z.x+=ox/od*dt*2.7;z.z+=oz/od*dt*2.7}}
      pushOut(z,.4);
      z.ch.holder.position.set(z.x,0,z.z);z.ch.holder.rotation.y=z.rot+FACE;
    }
    {let w=0;for(let i=0;i<zombies.length;i++){const z=zombies[i];if(!z.gone)zombies[w++]=z}zombies.length=w}
    if(player.wpn==='gun'&&mouse.has&&!aim.on&&now-mouse.t<1500){const v=new THREE.Vector3(player.x,1,player.z).project(cam),dx=mouse.x-(v.x+1)/2*innerWidth,dy=mouse.y-(1-v.y)/2*innerHeight,m=Math.hypot(dx,dy);
      if(m>20&&running&&!player.dead){const ix=dx/m,iy=dy/m,c=Math.cos(camYaw),s=Math.sin(camYaw);player.rot=ang(player.rot,Math.atan2(ix*c+iy*s,-ix*s+iy*c),Math.min(1,dt*22))}}
    if(player.car&&running&&!player.dead)driveStep(dt);
    worldTick(dt,now);if(fc%4===0)drawMap();
    zk+=(zT-zk)*Math.min(1,dt*6);const cdist=camDist*zk;
    _cv.set(player.x+Math.sin(camYaw)*cdist,Math.max(1.7,camH*zk),player.z+Math.cos(camYaw)*cdist);camPos.lerp(_cv,Math.min(1,dt*10));
    cam.position.copy(camPos);cam.lookAt(player.x,1.2,player.z);
    if(shake>.01){cam.position.x+=rnd(-1,1)*shake*.35;cam.position.y+=rnd(-1,1)*shake*.35;shake*=Math.pow(.015,dt)}else shake=0;
    sun.position.set(player.x+22,40,player.z+14);lamp.position.set(player.x,2.6,player.z);skyG.position.copy(cam.position);sun.target.position.set(player.x,0,player.z);
  }
  renderer.render(scene,cam);
}

// input
addEventListener('keydown',e=>{const k=e.key.toLowerCase();keys[k]=1;if(k===' '||k==='j'){holding=true;e.preventDefault()}if(k==='e'||k==='k')slam();if(k==='t')toggleAuto();if(k==='f')toggleCar();if(k==='p'&&player&&player.car)carAuto();if(k==='g'&&player&&!player.car)toggleDoor();if(k==='x'&&player){if(player.car)carJump();else doJump()}if(k===' '&&player&&player.car)carBoost();if(player&&player.car){if(k==='c')carFlip(-1);if(k==='v')carFlip(1)}if(k==='m'&&player&&player.car)musToggle();if(k==='n'&&player&&player.car)musChange();if(k==='z')zoomNext();if(k>='1'&&k<='3'&&WL[+k-1])setWpn(WL[+k-1])});
addEventListener('keyup',e=>{const k=e.key.toLowerCase();keys[k]=0;if(k===' '||k==='j')holding=false});
const jz=$('joy'),base=$('base'),knob=$('knob');let jid=null,jo=null;
const GS=()=>layout.gs||1;
function idleC(){const w=jz.offsetWidth,h=jz.offsetHeight;return{x:Math.min(150,w*.4),y:h-Math.min(60,h*.2)}}
function placeIdle(){const c=idleC(),r=41*GS();base.style.left=(c.x-r)+'px';base.style.top=(c.y-r)+'px';const hn=$('joyhint');if(hn){hn.style.left=c.x+'px';hn.style.top=(c.y-r-24)+'px'}}
function hideHint(){const hn=$('joyhint');if(hn)hn.style.display='none';hintJoy=false}
jz.addEventListener('pointerdown',e=>{if(jid!==null)return;jid=e.pointerId;jz.setPointerCapture(jid);const jr=jz.getBoundingClientRect();
  if(layout.jfloat){jo={x:e.clientX,y:e.clientY};base.style.left=(e.clientX-jr.left-41*GS())+'px';base.style.top=(e.clientY-jr.top-41*GS())+'px'}
  else{const c=idleC();jo={x:jr.left+c.x,y:jr.top+c.y}}
  base.classList.add('act');hideHint()});
jz.addEventListener('pointermove',e=>{if(e.pointerId!==jid)return;let dx=e.clientX-jo.x,dy=e.clientY-jo.y;const d=Math.hypot(dx,dy),m=38*GS();if(d>m){dx*=m/d;dy*=m/d}
  joy.x=dx/m;joy.y=dy/m;knob.style.transform=`translate(${dx}px,${dy}px)`});
const jend=e=>{if(e.pointerId!==jid)return;jid=null;joy.x=joy.y=0;knob.style.transform='';base.classList.remove('act');placeIdle()};
jz.addEventListener('pointerup',jend);jz.addEventListener('pointercancel',jend);
const pb=$('punch');
pb.addEventListener('pointerdown',e=>{e.preventDefault();holding=true;mouse.has=false;aim.id=e.pointerId;aim.sx=e.clientX;aim.sy=e.clientY;try{pb.setPointerCapture(e.pointerId)}catch(_){}});
pb.addEventListener('pointermove',e=>{if(e.pointerId!==aim.id)return;const dx=e.clientX-aim.sx,dy=e.clientY-aim.sy,m=Math.hypot(dx,dy);
  if(m>14){const ix=dx/m,iy=dy/m,c=Math.cos(camYaw),s=Math.sin(camYaw);aim.a=Math.atan2(ix*c+iy*s,-ix*s+iy*c);aim.on=true}});
['pointerup','pointercancel'].forEach(n=>pb.addEventListener(n,e=>{if(e.pointerId!==aim.id)return;aim.id=null;aim.on=false;holding=false}));
addEventListener('pointermove',e=>{if(e.pointerType==='mouse'){mouse.x=e.clientX;mouse.y=e.clientY;mouse.has=true;mouse.t=performance.now()}});
$('wpn').addEventListener('pointerdown',e=>{e.preventDefault();setWpn(WL[(WL.indexOf(player.wpn)+1)%WL.length])});
$('auto').addEventListener('pointerdown',e=>{e.preventDefault();toggleAuto()});
function zoomNext(){let i=0,b=9;ZP.forEach((v,k)=>{if(Math.abs(v-zT)<b){b=Math.abs(v-zT);i=k}});zT=ZP[(i+1)%ZP.length];snd(500,.06,'triangle',.1,100)}
$('zoom').addEventListener('pointerdown',e=>{e.preventDefault();zoomNext()});
$('carbtn').addEventListener('pointerdown',e=>{e.preventDefault();toggleCar()});

// ---- settings: move / resize every button, map, health ... (saved on this phone) ----
const LK='zn_layout';let layout={};try{layout=JSON.parse(localStorage.getItem(LK)||'{}')}catch(e){layout={}}
const EDS=[['punch','Punch'],['jumpb','Jump'],['slam','Special 💥'],['wpn','Weapon'],['auto','Auto-aim'],['run','Run'],['carbtn','Car enter/exit'],['zoom','Zoom'],['ammo','Ammo'],['buff','Boosts'],['stbar','Stamina'],['mm','Map (radar)'],['carc','Car compass'],['gunc','Gun compass'],['swc','Sword compass'],['gear','Settings ⚙'],['hpw','Health bar'],['wave','Wave'],['kills','Score'],['joy','Joystick area'],
 ['steerL','Steer ◀'],['steerR','Steer ▶'],['gas','GAS'],['brake','BRAKE'],['boost','Boost 🚀'],['cjump','Car jump'],['autoB','Autodrive'],['flipB','BACK'],['flipF','FRONT'],['mus','Music change'],['musOn','Music on/off'],['speedo','Speedometer']];
const GCAR=new Set(['steerL','steerR','gas','brake','boost','cjump','autoB','flipB','flipF','mus','musOn','speedo']),GBOTH=new Set(['mm','hpw','wave','kills','home','carbtn','gear']);
EDS.forEach(([id,n])=>{const el=$(id);if(el){el.setAttribute('data-ed',n);el.setAttribute('data-g',GCAR.has(id)?'car':GBOTH.has(id)?'both':'foot')}});
let editing=false,selEl=null,drag=null,startWas=false;
function saveLayout(){try{localStorage.setItem(LK,JSON.stringify(layout))}catch(e){}}
function applyOne(id){const L=layout[id],el=$(id);if(!el||!L)return;el.style.position='fixed';el.style.left=(L.x*innerWidth)+'px';el.style.top=(L.y*innerHeight)+'px';el.style.right='auto';el.style.bottom='auto';
  if(id==='joy'){el.style.width=(L.w*innerWidth)+'px';el.style.height=(L.h*innerHeight)+'px'}else{el.style.transform='scale(calc('+(L.s||1)+' * var(--gs,1)))';el.style.transformOrigin='0 0'}if(id==='joy')placeIdle()}
function applyOpacity(){$('hud').style.opacity=layout.op||1;$('opSl').value=Math.round((layout.op||1)*100)}
function applyGS(){document.documentElement.style.setProperty('--gs',GS());$('gsSl').value=Math.round(GS()*100);$('gsVal').textContent=Math.round(GS()*100)+'%';placeIdle()}
function applyJoyBtn(){$('setJoy').textContent='Joystick: '+(layout.jfloat?'Floating (appears where you touch)':'Fixed (always visible)')}
function applyLayout(){applyGS();applyJoyBtn();EDS.forEach(([id])=>applyOne(id));applyOpacity();placeIdle()}
function resetOne(id){delete layout[id];const el=$(id);if(el)['position','left','top','right','bottom','transform','transformOrigin','width','height'].forEach(k=>el.style[k]='')}
function selectEd(el){if(selEl)selEl.classList.remove('sel');selEl=el;if(el){el.classList.add('sel');$('edName').textContent='✋ '+el.getAttribute('data-ed')}else $('edName').textContent='Drag a button to move it'}
function openSet(){paused=true;$('setp').style.display='flex'}
function closeSet(){$('setp').style.display='none';if(!editing&&player&&running)paused=false;else if(!editing)paused=false}
function setEdit(on){editing=on;document.body.classList.toggle('editing',on);$('edbar').style.display=on?'flex':'none';
  if(on){edGroup(false);startWas=$('start').style.display!=='none';$('start').style.display='none';$('setp').style.display='none';paused=true;selectEd(null)}
  else{if(startWas)$('start').style.display='flex';selectEd(null);paused=false;saveLayout()}}
function edGroup(car){document.body.classList.toggle('ed-car',car);$('edFoot').style.background=car?'#ffb02e':'#46c7ff';$('edCar').style.background=car?'#46c7ff':'#ffb02e';selectEd(null)}
function sizeSel(f){if(!selEl)return;const id=selEl.id,L=layout[id]||(layout[id]=initL(selEl));if(id==='joy'){L.w=Math.max(.15,Math.min(.95,L.w*f));L.h=Math.max(.15,Math.min(.95,L.h*f))}else L.s=Math.max(.5,Math.min(2.2,(L.s||1)*f));applyOne(id);saveLayout()}
function initL(el){const r=el.getBoundingClientRect();return{x:r.left/innerWidth,y:r.top/innerHeight,s:1,w:r.width/innerWidth,h:r.height/innerHeight}}
document.addEventListener('pointerdown',e=>{if(!editing)return;if(e.target.closest('#edbar')||e.target.closest('#setp'))return;e.preventDefault();e.stopPropagation();
  const el=e.target.closest('[data-ed]');if(!el)return;selectEd(el);if(!layout[el.id])layout[el.id]=initL(el);const r=el.getBoundingClientRect();drag={el,id:el.id,dx:e.clientX-r.left,dy:e.clientY-r.top,pid:e.pointerId}},true);
document.addEventListener('pointermove',e=>{if(!drag||e.pointerId!==drag.pid)return;e.preventDefault();e.stopPropagation();const L=layout[drag.id];
  L.x=Math.max(0,Math.min(.97,(e.clientX-drag.dx)/innerWidth));L.y=Math.max(0,Math.min(.95,(e.clientY-drag.dy)/innerHeight));applyOne(drag.id)},true);
const edEnd=e=>{if(drag&&e.pointerId===drag.pid){drag=null;saveLayout()}};
document.addEventListener('pointerup',edEnd,true);document.addEventListener('pointercancel',edEnd,true);
$('gear').addEventListener('pointerdown',e=>{e.preventDefault();openSet()});

$('setClose').addEventListener('click',closeSet);
$('setEdit').addEventListener('click',()=>setEdit(true));
$('setReset').addEventListener('click',()=>{EDS.forEach(([id])=>resetOne(id));layout.op=1;layout.gs=1;layout.jfloat=false;applyLayout();saveLayout()});
$('edDone').addEventListener('click',()=>setEdit(false));
$('edFoot').addEventListener('click',()=>edGroup(false));$('edCar').addEventListener('click',()=>edGroup(true));
$('edMinus').addEventListener('click',()=>sizeSel(.9));$('edPlus').addEventListener('click',()=>sizeSel(1.1));
$('edRes').addEventListener('click',()=>{if(selEl){resetOne(selEl.id);saveLayout()}});
$('gsSl').addEventListener('input',e=>{layout.gs=e.target.value/100;applyGS();saveLayout()});
$('setJoy').addEventListener('click',()=>{layout.jfloat=!layout.jfloat;applyJoyBtn();placeIdle();saveLayout()});
$('opSl').addEventListener('input',e=>{layout.op=e.target.value/100;applyOpacity();saveLayout()});
applyLayout();if(layout.mus===false)musicOn=false;

// ---- main menu scene ----
function enterMenu(){
  if(!player){const ch=makeFarmer(1.8);scene.add(ch.holder);player=Object.assign({ch,lean:0},addWeapons(ch))}
  zombies.forEach(z=>freeChar(z.ch));zombies.length=0;pups.forEach(p=>scene.remove(p.m));pups.length=0;acid.forEach(a=>{a.l=0;a.m.visible=false});bullets.forEach(b=>{b.l=0;b.m.visible=false});
  resetCars();
  Object.assign(player,{x:0,z:0,y:0,vy:0,sq:0,rot:Math.PI*.9,hp:100,dead:false,car:null,spd:0,pt:-1,cd:0,inv:0,slam:0,spdT:0,powT:0,wpn:'fist'});
  player.ch.mixer.stopAllAction();player.ch.cur=null;player.lean=0;player.ch.obj.rotation.set(0,0,0);if(player.sw)player.sw.visible=false;if(player.gn)player.gn.visible=false;player.ch.holder.visible=true;player.ch.holder.position.set(0,0,0);player.ch.holder.scale.set(1,1,1);player.ch.holder.rotation.set(0,player.rot,0);player.ch.play('Idle',.05);
  running=false;over=false;paused=false;menu=true;document.body.classList.add('inmenu');
  $('start').style.display='flex';$('over').style.display='none';
  pcx=1e9;refreshWorld();musUI();
}
function menuTick(dt,now){
  player.ch.mixer.update(dt);
  if(menuDrag>0)menuDrag-=dt;else menuAng+=dt*.2;
  const cx=player.x,cz=player.z,a=menuAng,d=4.4;
  cam.position.set(cx+Math.sin(a)*d,1.45,cz+Math.cos(a)*d);
  const rx=Math.cos(a),rz=-Math.sin(a);               // camera's right vector -> the character appears on the right side of the screen
  cam.lookAt(cx-rx*1.15,1.05,cz-rz*1.15);
  sun.position.set(cx+22,40,cz+14);sun.target.position.set(cx,0,cz);lamp.position.set(cx,2.6,cz);
  worldTick(dt,now);
}
const INFO={
 how:"Survive the night! Zombies come in waves — punch them with 👊. You start with bare fists only. Explore the endless jungle, find weapons and the car, and keep moving. Every 5th wave a BOSS arrives. Health is rare, so use it wisely.",
 ctl:"Move: joystick / WASD • Punch: 👊 / Space • Special: 💥 / E • Jump: JUMP / X • Run: 🏃 / Shift • Weapon: 🔄 / 1-2-3 • Camera: drag the screen / Q-R • Zoom: 🔍 / Z / mouse wheel • Gun aim: hold 👊 and drag, or use the mouse • Auto-aim: 🎯 / T • Open the ⚙ settings button to move or resize any button.",
 car:"Walk up to the 🚗 (blue dot on the radar) and tap ENTER / F to drive. Steer ◀ ▶, GAS, BRAKE, 🚀 boost, JUMP (X), AUTO = autodrive (P), ⟲ ⟳ flips, 🎵 change music, 🔊 music on/off. Zombies get thrown far away when you hit them. Tap EXIT to get out.",
 wpn:"You start with bare fists. Find the 🗡️ sword (light-blue dot on the radar) and the 🔫 AK-47 (pink dot) — each one unlocks that weapon. Ammo is limited — look for green crates. Pickups: ❤️ health (rare), ⚡ speed, 🟠 double power. Green spitters shoot acid. Huge purple-dot brutes (wave 4+) have enormous arms and hit very hard — keep away or run them over.",
 tip:"Walking is free, running drains the blue stamina bar. Keep moving — spitters shoot acid. Jump over zombie attacks. The car runs zombies over. Graphics quality adjusts automatically to your phone."
};
let infoOpen=null;
function closeInfo(){infoOpen=null;$('minfo').style.display='none';document.querySelectorAll('.info').forEach(x=>x.classList.remove('on'))}
document.querySelectorAll('.info').forEach(b=>b.addEventListener('click',()=>{const k=b.getAttribute('data-i');
  if(infoOpen===k){closeInfo();return}
  infoOpen=k;document.querySelectorAll('.info').forEach(x=>x.classList.toggle('on',x===b));$('mititle').textContent=b.textContent;$('mibody').textContent=INFO[k];$('minfo').style.display='block'}));
$('miclose').addEventListener('click',closeInfo);
$('mSet').addEventListener('click',()=>{closeInfo();openSet()});
$('mMus').addEventListener('click',()=>musToggle());
$('mTrk').addEventListener('click',()=>musChange());
$('toMenu').addEventListener('click',()=>enterMenu());
document.addEventListener('pointerdown',()=>{if(menu&&musicOn&&!musBus)musStart()},true);
$('start').addEventListener('pointermove',e=>{if(e.buttons&&e.target.id==='start'){menuAng-=(e.movementX||0)*.012;menuDrag=2.5}});
const cin={l:0,r:0,gas:0,brake:0};
for(const [id,k] of [['steerL','l'],['steerR','r'],['gas','gas'],['brake','brake']]){const el=$(id);el.addEventListener('pointerdown',e=>{e.preventDefault();cin[k]=1;try{el.setPointerCapture(e.pointerId)}catch(_){}});['pointerup','pointercancel'].forEach(n=>el.addEventListener(n,()=>{cin[k]=0}))}
$('boost').addEventListener('pointerdown',e=>{e.preventDefault();carBoost()});
$('cjump').addEventListener('pointerdown',e=>{e.preventDefault();carJump()});
$('autoB').addEventListener('pointerdown',e=>{e.preventDefault();carAuto()});

$('jumpb').addEventListener('pointerdown',e=>{e.preventDefault();doJump()});
$('flipB').addEventListener('pointerdown',e=>{e.preventDefault();carFlip(-1)});
$('flipF').addEventListener('pointerdown',e=>{e.preventDefault();carFlip(1)});
$('mus').addEventListener('pointerdown',e=>{e.preventDefault();musChange()});
$('musOn').addEventListener('pointerdown',e=>{e.preventDefault();musToggle()});
$('run').addEventListener('pointerdown',e=>{e.preventDefault();if(player&&!player.tired){runOn=!runOn;snd(runOn?640:360,.07,'triangle',.1,0)}});
addEventListener('wheel',e=>{zT=Math.min(1.2,Math.max(.3,zT+(e.deltaY>0?.08:-.08)))},{passive:true});
const cz=$('camz');let cid=null,cx=0,cyy=0;
cz.addEventListener('pointerdown',e=>{if(e.pointerType==='mouse'&&player&&player.wpn==='gun'){holding=true;return}if(cid!==null)return;cid=e.pointerId;cz.setPointerCapture(cid);cx=e.clientX;cyy=e.clientY});
cz.addEventListener('pointermove',e=>{if(e.pointerId!==cid)return;camDragT=performance.now();camYaw-=(e.clientX-cx)*.007;camH=Math.min(11,Math.max(2.6,camH+(e.clientY-cyy)*.02));cx=e.clientX;cyy=e.clientY});
const cend=e=>{if(e.pointerId===cid)cid=null;if(e.pointerType==='mouse'&&player&&player.wpn==='gun')holding=false};cz.addEventListener('pointerup',cend);cz.addEventListener('pointercancel',cend);$('slam').addEventListener('pointerdown',e=>{e.preventDefault();slam()});
function begin(){snd(1,.01,'sine',.001);const el=document.documentElement;try{el.requestFullscreen&&el.requestFullscreen().then(()=>screen.orientation&&screen.orientation.lock&&screen.orientation.lock('landscape').catch(()=>{})).catch(()=>{})}catch(_){}startGame()}
$('go').addEventListener('click',begin);$('again').addEventListener('click',startGame);

(async()=>{
  try{
    const ld=u=>new Promise((r,j)=>new THREE.TextureLoader().load(u,x=>{x.flipY=false;x.encoding=THREE.sRGBEncoding;x.anisotropy=4;r(x)},undefined,()=>r(null)));
    FARM=await parse(await fbuf(ASSETS.farmer));DOG=await parse(await fbuf(ASSETS.dog));BRU=await parse(await fbuf(ASSETS.brute));{const BT=await ld(ASSETS.brtex);BRU.scene.traverse(o=>{if(o.isMesh&&BT){o.material.map=BT;o.material.color.set(0xffffff);o.material.needsUpdate=true}})}CAR=await parse(await fbuf(ASSETS.car));{const CT=await ld(ASSETS.cartex);CAR.scene.traverse(o=>{if(o.isMesh){const m=o.material;if(m.name==='Headlights'){m.color.set(0xffffff);m.emissive=new THREE.Color(0xfff2b0);m.emissiveIntensity=1.6}else if(CT){m.map=CT;m.color.set(0xffffff)}m.needsUpdate=true}})}{const DT=await ld(ASSETS.dogtex);DOG.scene.traverse(o=>{if(o.isMesh&&DT){o.material.map=DT;o.material.color.set(0xffffff);o.material.needsUpdate=true}})}const ZT=await ld(ASSETS.ztex);
    ZGLB=await parse(await fbuf(ASSETS.zombie));
    ZGLB.scene.traverse(o=>{if(o.isMesh&&ZT){o.material.map=ZT;o.material.color.set(0xffffff);o.material.needsUpdate=true}});
    await buildWorld();prewarmPool();{const mem=navigator.deviceMemory||4,cores=navigator.hardwareConcurrency||4;const touch=navigator.maxTouchPoints>0;applyQuality(touch?(mem>=6&&cores>=8?2:1):(mem<=3||cores<=4?1:2))}
    $('go').disabled=false;$('go').textContent='Play ▶';
    enterMenu();requestAnimationFrame(loop);
  }catch(err){$('errmsg').textContent+=' '+(err&&(err.stack||err.message)||err);$('go').textContent='Error';$('go').disabled=true}
})();
})();
