const Game = {
  scene: null, camera: null, renderer: null, clock: null,

  localPlayer: { position: { x: 0, y: 1, z: 0 }, rotationY: 0, health: 100, alive: true },
  remotePlayers: new Map(), // socketId -> { mesh, targetPos, targetRot }

  keys: {},
  pointerLocked: false,
  yaw: 0,
  pitch: 0,
  lastSendTime: 0,

  mobile: /Android|iPhone|iPad/i.test(navigator.userAgent),
  joystick: { dx: 0, dy: 0 },

  currentRoomId: '',

  init() {
    const canvas = document.getElementById('game-canvas');
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
    this.renderer.setSize(window.innerWidth, window.innerHeight);

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x87ceeb);
    this.scene.fog = new THREE.Fog(0x87ceeb, 60, 180);

    this.camera = new THREE.PerspectiveCamera(
      75, window.innerWidth / window.innerHeight, 0.1, 1000
    );

    World.build(this.scene);

    window.addEventListener('resize', () => this.onResize());
    this.setupDesktopControls();
    this.setupNetworkHandlers();

    if (this.mobile) {
      document.getElementById('mobile-controls').classList.add('active');
      this.setupMobileControls();
    }

    this.clock = new THREE.Clock();
    this.loop();
  },

  onResize() {
    this.camera.aspect = window.innerWidth / window.innerHeight;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(window.innerWidth, window.innerHeight);
  },

  setupDesktopControls() {
    window.addEventListener('keydown', e => { this.keys[e.code] = true; });
    window.addEventListener('keyup', e => { this.keys[e.code] = false; });

    const canvas = this.renderer.domElement;
    canvas.addEventListener('click', () => {
      if (!this.mobile) canvas.requestPointerLock();
      this.tryShoot();
    });
    document.addEventListener('pointerlockchange', () => {
      this.pointerLocked = document.pointerLockElement === canvas;
    });
    document.addEventListener('mousemove', e => {
      if (!this.pointerLocked) return;
      this.yaw -= e.movementX * 0.0025;
      this.pitch -= e.movementY * 0.0025;
      this.pitch = Math.max(-1.2, Math.min(1.2, this.pitch));
    });
  },

  setupMobileControls() {
    const stick = document.getElementById('joystick');
    const knob = document.getElementById('joystick-knob');
    let origin = null;

    stick.addEventListener('touchstart', e => {
      origin = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    }, { passive: true });

    stick.addEventListener('touchmove', e => {
      if (!origin) return;
      const t = e.touches[0];
      let dx = t.clientX - origin.x;
      let dy = t.clientY - origin.y;
      const max = 40;
      const len = Math.sqrt(dx * dx + dy * dy) || 1;
      if (len > max) { dx = (dx / len) * max; dy = (dy / len) * max; }
      knob.style.transform = `translate(${dx}px, ${dy}px)`;
      this.joystick.dx = dx / max;
      this.joystick.dy = dy / max;
    }, { passive: true });

    const endStick = () => {
      origin = null;
      this.joystick.dx = 0; this.joystick.dy = 0;
      knob.style.transform = 'translate(0,0)';
    };
    stick.addEventListener('touchend', endStick);
    stick.addEventListener('touchcancel', endStick);

    const look = document.getElementById('look-area');
    let lastTouch = null;
    look.addEventListener('touchstart', e => {
      lastTouch = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    }, { passive: true });
    look.addEventListener('touchmove', e => {
      const t = e.touches[0];
      if (lastTouch) {
        this.yaw -= (t.clientX - lastTouch.x) * 0.004;
        this.pitch -= (t.clientY - lastTouch.y) * 0.004;
        this.pitch = Math.max(-1.2, Math.min(1.2, this.pitch));
      }
      lastTouch = { x: t.clientX, y: t.clientY };
    }, { passive: true });
    look.addEventListener('touchend', () => { lastTouch = null; });

    document.getElementById('btn-fire').addEventListener('touchstart', e => {
      e.preventDefault();
      this.tryShoot();
    });
  },

  tryShoot() {
    if (!this.localPlayer.alive) return;
    const dir = new THREE.Vector3();
    this.camera.getWorldDirection(dir);
    NET.shoot(
      { x: this.camera.position.x, y: this.camera.position.y, z: this.camera.position.z },
      { x: dir.x, y: dir.y, z: dir.z }
    );
  },

  setupNetworkHandlers() {
    NET.socket.on('matchStart', data => {
      this.currentRoomId = data.roomId;
      UI.setRoomTag(`ROOM: ${data.roomId}`);
      UI.showScreen('screen-game');
      UI.hideVictory();
      UI.hideEliminated();

      this.remotePlayers.forEach(rp => this.scene.remove(rp.mesh));
      this.remotePlayers.clear();

      this.localPlayer.health = 100;
      this.localPlayer.alive = true;

      const me = data.players.find(p => p.id === NET.socket.id);
      if (me) this.localPlayer.position = { ...me.position };
      this.yaw = 0; this.pitch = 0;

      UI.setHealth(100);
    });

    NET.socket.on('stateUpdate', data => {
      data.players.forEach(p => {
        if (p.id === NET.socket.id) {
          this.localPlayer.health = p.health;
          this.localPlayer.alive = p.alive;
          UI.setHealth(p.health);
          return;
        }
        let rp = this.remotePlayers.get(p.id);
        if (!rp) {
          const mesh = PlayerMesh.create(0xff6b4a);
          this.scene.add(mesh);
          rp = { mesh, targetPos: { ...p.position }, targetRot: p.rotationY };
          this.remotePlayers.set(p.id, rp);
        }
        rp.targetPos = p.position;
        rp.targetRot = p.rotationY;
        rp.mesh.visible = p.alive;
      });

      UI.setDebug(
        `SERVER: CONNECTED\nROOM: ${this.currentRoomId}\nPLAYERS: ${data.players.length}`
      );
    });

    NET.socket.on('playerLeft', data => {
      const rp = this.remotePlayers.get(data.id);
      if (rp) {
        this.scene.remove(rp.mesh);
        this.remotePlayers.delete(data.id);
      }
    });

    NET.socket.on('playerHit', data => {
      if (data.targetId === NET.socket.id) UI.setHealth(data.health);
    });

    NET.socket.on('playerDied', data => {
      if (data.targetId === NET.socket.id) {
        this.localPlayer.alive = false;
        UI.showEliminated();
      }
    });

    NET.socket.on('victory', data => {
      UI.showVictory(data);
    });
  },

  updateLocalMovement(dt) {
    if (!this.localPlayer.alive) return;
    const speed = 6;
    let mx = 0, mz = 0;

    if (this.mobile) {
      mx = this.joystick.dx;
      mz = this.joystick.dy;
    } else {
      if (this.keys['KeyW']) mz -= 1;
      if (this.keys['KeyS']) mz += 1;
      if (this.keys['KeyA']) mx -= 1;
      if (this.keys['KeyD']) mx += 1;
    }

    const len = Math.sqrt(mx * mx + mz * mz);
    if (len > 0.001) {
      mx /= len; mz /= len;
      const cos = Math.cos(this.yaw), sin = Math.sin(this.yaw);
      const worldX = mx * cos - mz * sin;
      const worldZ = mx * sin + mz * cos;
      this.localPlayer.position.x += worldX * speed * dt;
      this.localPlayer.position.z += worldZ * speed * dt;
    }
    this.localPlayer.rotationY = this.yaw;

    this.camera.position.set(this.localPlayer.position.x, 1.6, this.localPlayer.position.z);
    this.camera.rotation.order = 'YXZ';
    this.camera.rotation.y = this.yaw;
    this.camera.rotation.x = this.pitch;
  },

  sendUpdates() {
    const now = Date.now();
    if (now - this.lastSendTime > 50) { // ~20 updates/sec
      NET.sendUpdate(this.localPlayer.position, this.localPlayer.rotationY);
      this.lastSendTime = now;
    }
  },

  interpolateRemotes() {
    this.remotePlayers.forEach(rp => {
      rp.mesh.position.x += (rp.targetPos.x - rp.mesh.position.x) * 0.25;
      rp.mesh.position.z += (rp.targetPos.z - rp.mesh.position.z) * 0.25;
      rp.mesh.rotation.y += (rp.targetRot - rp.mesh.rotation.y) * 0.25;
    });
  },

  loop() {
    requestAnimationFrame(() => this.loop());
    const dt = Math.min(this.clock.getDelta(), 0.1);
    this.updateLocalMovement(dt);
    this.sendUpdates();
    this.interpolateRemotes();
    this.renderer.render(this.scene, this.camera);
  },
};
