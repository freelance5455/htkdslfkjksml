/* ============================================================================
   STRIKE MOBILE — 3D шутер (Three.js r128)
   ----------------------------------------------------------------------------
   СТРУКТУРА КОДА:
   1.  ДАННЫЕ      — оружие, ножи, скины, кейсы, редкости
   2.  СОХРАНЕНИЯ  — localStorage (инвентарь, экипировка, настройки, статистика)
   3.  АУДИО      — синтез звуков через WebAudio (без внешних файлов)
   4.  МАТЕМАТИКА — лучи, AABB-коллизии, LOS (line of sight)
   5.  ТЕКСТУРЫ  — процедурные (кирпич, бетон, ящик, металл)
   6.  МИР        — карта с архитектурой, точки интереса, ящики укрытий
   7.  ПЕРСОНАЖИ  — модели игрока и ботов
   8.  VIEWMODEL — оружие в руках + анимации (выстрел, перезарядка, ножи)
   9.  ИИ БОТОВ   — поведение, закладка/обезвреживание бомбы
   10. БОМБА      — закладка, таймер, взрыв
   11. РАУНДЫ     — фазы, экономика, счёт, смена сторон
   12. ИГРОК     — управление (тач + клавиатура), стрельба
   13. HUD       — радар, килфид, хитмаркеры
   14. UI        — меню, магазин, инвентарь, настройки
   15. ЦИКЛ      — главный игровой цикл
   ========================================================================== */
'use strict';

/* ============================== 1. ДАННЫЕ ================================= */
const WEAPONS = {
  ak47:   { name:'АК-47',        type:'rifle',  dmg:33, rpm:600, mag:30, reserve:90,  price:2700, auto:true,  spread:1.0, recoil:1.7, reload:2.4, color:0x4a3b28, desc:'Автомат Калашникова' },
  m4a4:   { name:'M4A4',         type:'rifle',  dmg:31, rpm:666, mag:30, reserve:90,  price:3100, auto:true,  spread:0.75,recoil:1.4, reload:2.3, color:0x23272c, desc:'Штурмовая винтовка' },
  m4a1s:  { name:'M4A1-S',       type:'rifle',  dmg:32, rpm:600, mag:25, reserve:75,  price:2900, auto:true,  spread:0.5, recoil:1.1, reload:2.2, color:0x1a1d20, silenced:true, desc:'С глушителем' },
  galil:  { name:'Galil AR',     type:'rifle',  dmg:27, rpm:666, mag:35, reserve:105, price:1800, auto:true,  spread:1.15,recoil:1.5, reload:2.5, color:0x4c463a, desc:'Бюджетный автомат' },
  glock:  { name:'Glock-18',     type:'pistol', dmg:25, rpm:400, mag:20, reserve:120, price:200,  auto:false, spread:1.3, recoil:1.0, reload:1.8, color:0x2e3236, desc:'Пистолет террористов' },
  usp:    { name:'USP-S',        type:'pistol', dmg:32, rpm:352, mag:12, reserve:24,  price:200,  auto:false, spread:0.6, recoil:0.9, reload:2.0, color:0x24282c, silenced:true, desc:'Пистолет спецназа' },
  deagle: { name:'Desert Eagle', type:'pistol', dmg:54, rpm:267, mag:7,  reserve:35,  price:700,  auto:false, spread:0.5, recoil:2.8, reload:1.9, color:0x777d84, desc:'Мощный пистолет' },
};
const KNIVES = {
  default:  { name:'Нож (стандартный)', dmg:40, rpm:110, range:2.3 },
  tanto:    { name:'Нож Танто',         dmg:40, rpm:110, range:2.3 },
  karambit: { name:'Керамбит',          dmg:40, rpm:120, range:2.3 },
  butterfly:{ name:'Нож-бабочка',       dmg:40, rpm:130, range:2.3 },
};
const RARITY = [
  { n:'Обычный',            c:'#b0c3d9', w:32 },
  { n:'Промышленное',       c:'#5e98d9', w:24 },
  { n:'Армейское качество', c:'#4b69ff', w:18 },
  { n:'Запрещённое',        c:'#8847ff', w:12 },
  { n:'Засекреченное',      c:'#d32ce6', w:8 },
  { n:'Тайное',             c:'#eb4b4b', w:4.5 },
  { n:'★ Легендарное',      c:'#ffd700', w:1.5 },
];
const WEAPON_SKIN_NAMES = {
  ak47:['Красная линия','Вулкан','Флот','Закат','Джунгли','Неон-реактор'],
  m4a4:['Гроза','Азимов','Звёздный путь','Ядерный сад','Шторм','Магма'],
  m4a1s:['Призрак','Хищник','Мороз','Гипноз','Кибер-пчела','Туман'],
  galil:['Песчаная буря','Сигнал','Хаки','Оранжевый гнев','Небеса','Токсин'],
  glock:['Водная стихия','Факел','Гадюка','Фронт','Арктика','Пламя'],
  usp:['Темная вода','Кайман','Орбита','Лёд','Проводник','Яд'],
  deagle:['Золотой код','Засуха','Кобра','Гроза','Мрамор','Красный барон'],
};
const SKIN_COLORS = [0xc0392b,0x2980b9,0x27ae60,0x8e44ad,0xf39c12,0xe74c3c,0x16a085,0xd35400,0x2ecc71,0xe91e63,0xffd700,0x00bcd4,0x9b59b6,0xecf0f1];
const GLOVE_SETS = [
  { name:'Спецназовские', color:0x2c3e50 }, { name:'Кровавый спорт', color:0x8e1b1b },
  { name:'Пустынные', color:0xb7950b },     { name:'Изумрудные', color:0x1e8449 },
  { name:'Фиолетовый туман', color:0x6c3483 }, { name:'Белоснежные', color:0xdfe6ee },
  { name:'Оранжевые гонки', color:0xd35400 }, { name:'Графит', color:0x424949 },
];
const KNIFE_ICONS = { default:'🔪', tanto:'🗡️', karambit:'🪝', butterfly:'🦋' };
const CASES = {
  weapon:{ name:'Оружейный кейс', icon:'🔫', desc:'Скины на АК, М4, пистолеты' },
  knife: { name:'Ножевой кейс',   icon:'🔪', desc:'Бабочка, керамбит, танто' },
  glove: { name:'Перчаточный кейс', icon:'🧤', desc:'Стильные перчатки' },
  mixed: { name:'Микс-кейс',      icon:'🎁', desc:'Всё сразу!' },
};
const BOT_NAMES = ['Волк','Сокол','Медведь','Ястреб','Гадюка','Барс','Тайфун','Кобра','Шторм','Омега','Призрак','Тень'];

/* ============================ 2. СОХРАНЕНИЯ =============================== */
const SAVE_KEY = 'strike_mobile_save_v1';
let save = loadSave();
function defaultSave(){ return {
  inv:[ { uid:1, kind:'knife', model:'default', color:null, name:'Нож (стандартный)', rarity:0 } ],
  nextUid:2,
  equipped:{ primary:'ak47', secondary:'usp', knifeUid:1 },
  skins:{},            // weaponKey -> color (авто-подстановка скинов)
  glovesColor:null,
  settings:{ sens:1.2, vol:0.7, fov:80, invert:false },
  stats:{ matches:0, wins:0, kills:0 },
};}
function loadSave(){ try{ const s = JSON.parse(localStorage.getItem(SAVE_KEY)); if(s && s.inv) return s; }catch(e){} return defaultSave(); }
function persist(){ try{ localStorage.setItem(SAVE_KEY, JSON.stringify(save)); }catch(e){} }

/* ============================== 3. АУДИО ================================== */
let AC = null, masterGain = null;
function audioInit(){
  if(AC) { if(AC.state==='suspended') AC.resume(); return; }
  AC = new (window.AudioContext || window.webkitAudioContext)();
  masterGain = AC.createGain(); masterGain.gain.value = save.settings.vol; masterGain.connect(AC.destination);
}
function setVolume(v){ if(masterGain) masterGain.gain.value = v; }
function noiseBuf(dur){
  const b = AC.createBuffer(1, AC.sampleRate*dur, AC.sampleRate);
  const d = b.getChannelData(0);
  for(let i=0;i<d.length;i++) d[i] = Math.random()*2-1;
  return b;
}
function burst(dur, freq, gain, type){
  if(!AC) return;
  const t = AC.currentTime;
  const src = AC.createBufferSource(); src.buffer = noiseBuf(dur);
  const f = AC.createBiquadFilter(); f.type = type||'lowpass'; f.frequency.value = freq;
  const g = AC.createGain(); g.gain.setValueAtTime(gain, t); g.gain.exponentialRampToValueAtTime(0.001, t+dur);
  src.connect(f); f.connect(g); g.connect(masterGain); src.start(t);
}
function tone(freq, dur, gain, type, slide){
  if(!AC) return;
  const t = AC.currentTime;
  const o = AC.createOscillator(); o.type = type||'square'; o.frequency.setValueAtTime(freq, t);
  if(slide) o.frequency.exponentialRampToValueAtTime(Math.max(20,slide), t+dur);
  const g = AC.createGain(); g.gain.setValueAtTime(gain, t); g.gain.exponentialRampToValueAtTime(0.001, t+dur);
  o.connect(g); g.connect(masterGain); o.start(t); o.stop(t+dur);
}
const SFX = {
  shoot(key){ const w = WEAPONS[key]; if(!AC) return;
    if(w.silenced){ burst(0.09, 900, 0.18); return; }
    if(key==='deagle'){ burst(0.22, 500, 0.55); tone(90, 0.18, 0.35, 'square', 40); }
    else if(w.type==='pistol'){ burst(0.13, 1100, 0.4); tone(150, 0.1, 0.22, 'square', 60); }
    else { burst(0.14, 800, 0.48); tone(110, 0.12, 0.3, 'sawtooth', 45); } },
  dry(){ tone(1200, 0.05, 0.15, 'square'); },
  knife(){ burst(0.15, 2500, 0.22, 'bandpass'); },
  knifeHit(){ tone(300, 0.1, 0.3, 'square', 80); burst(0.08, 700, 0.2); },
  hit(head){ tone(head?1800:1200, 0.06, 0.25, 'square'); },
  hurt(){ burst(0.15, 400, 0.3); },
  death(){ tone(220, 0.4, 0.3, 'sawtooth', 60); },
  reload(){ tone(500, 0.06, 0.15, 'square'); setTimeout(()=>tone(700,0.06,0.15,'square'), 160); },
  plant(){ tone(880, 0.09, 0.25, 'square'); },
  beep(hi){ tone(hi?1560:1040, 0.07, 0.3, 'square'); },
  explode(){ burst(1.4, 300, 0.9); tone(60, 1.1, 0.6, 'sine', 25); },
  defuse(){ tone(600, 0.08, 0.2, 'square'); },
  buy(){ tone(1000, 0.07, 0.2, 'square'); tone(1400, 0.09, 0.18, 'square'); },
  click(){ tone(800, 0.04, 0.12, 'square'); },
  win(){ [523,659,784,1046].forEach((f,i)=>setTimeout(()=>tone(f,0.18,0.22,'square'), i*130)); },
  lose(){ [400,340,280,200].forEach((f,i)=>setTimeout(()=>tone(f,0.2,0.2,'sawtooth'), i*150)); },
};

/* ======================= 4. МАТЕМАТИКА: ЛУЧИ И КОЛЛИЗИИ ==================== */
const CELL = 4, GW = 15, GH = 18;
function cellToWorld(cx, cy){ return { x:(cx-(GW-1)/2)*CELL, z:(cy-(GH-1)/2)*CELL }; }
// стены: список AABB {x0,x1,y0,y1,z0,z1}
let walls = [];
function addWall(cx, cy, h){
  const p = cellToWorld(cx, cy);
  walls.push({ x0:p.x-2, x1:p.x+2, y0:0, y1:h, z0:p.z-2, z1:p.z+2 });
}
// луч против одного AABB (slab-метод), возвращает t или Infinity
function rayAABB(ox,oy,oz, dx,dy,dz, b, maxT){
  let t0 = 0, t1 = maxT;
  // X
  if(Math.abs(dx) < 1e-9){ if(ox < b.x0 || ox > b.x1) return Infinity; }
  else { let ta=(b.x0-ox)/dx, tb=(b.x1-ox)/dx; if(ta>tb){const s=ta;ta=tb;tb=s;}
    t0=Math.max(t0,ta); t1=Math.min(t1,tb); if(t0>t1) return Infinity; }
  // Y
  if(Math.abs(dy) < 1e-9){ if(oy < b.y0 || oy > b.y1) return Infinity; }
  else { let ta=(b.y0-oy)/dy, tb=(b.y1-oy)/dy; if(ta>tb){const s=ta;ta=tb;tb=s;}
    t0=Math.max(t0,ta); t1=Math.min(t1,tb); if(t0>t1) return Infinity; }
  // Z
  if(Math.abs(dz) < 1e-9){ if(oz < b.z0 || oz > b.z1) return Infinity; }
  else { let ta=(b.z0-oz)/dz, tb=(b.z1-oz)/dz; if(ta>tb){const s=ta;ta=tb;tb=s;}
    t0=Math.max(t0,ta); t1=Math.min(t1,tb); if(t0>t1) return Infinity; }
  return t0;
}
// ближайшее пересечение луча со стенами/ящиками
function rayWallsT(ox,oy,oz, dx,dy,dz, maxT){
  let best = maxT;
  for(let i=0;i<walls.length;i++){
    const t = rayAABB(ox,oy,oz, dx,dy,dz, walls[i], best);
    if(t < best) best = t;
  }
  return best;
}
// есть ли прямая видимость между двумя точками
function losClear(x0,y0,z0, x1,y1,z1){
  const dx=x1-x0, dy=y1-y0, dz=z1-z0;
  const d = Math.sqrt(dx*dx+dy*dy+dz*dz);
  if(d < 0.001) return true;
  return rayWallsT(x0,y0,z0, dx/d,dy/d,dz/d, d) >= d - 0.05;
}
// луч против сферы, возвращает t или -1
function raySphere(ox,oy,oz, dx,dy,dz, cx,cy,cz, r, maxT){
  const lx=cx-ox, ly=cy-oy, lz=cz-oz;
  const tca = lx*dx+ly*dy+lz*dz;
  if(tca < 0 || tca - r > maxT) return -1;
  const d2 = lx*lx+ly*ly+lz*lz - tca*tca;
  const r2 = r*r;
  if(d2 > r2) return -1;
  const thc = Math.sqrt(r2 - d2);
  const t = tca - thc;
  return (t >= 0 && t <= maxT) ? t : -1;
}
// круглый коллайдер (игрок/бот радиус r) против стен
function collideMove(x, z, r, nx, nz){
  let x2 = nx, z2 = nz;
  for(let i=0;i<walls.length;i++){
    const w = walls[i];
    if(x2 > w.x0 - r && x2 < w.x1 + r && z2 > w.z0 - r && z2 < w.z1 + r){
      const pushLeft = (w.x0 - r) - x2, pushRight = (w.x1 + r) - x2;
      const pushUp = (w.z0 - r) - z2, pushDown = (w.z1 + r) - z2;
      const px = Math.abs(pushLeft) < Math.abs(pushRight) ? pushLeft : pushRight;
      const pz = Math.abs(pushUp) < Math.abs(pushDown) ? pushUp : pushDown;
      if(Math.abs(px) < Math.abs(pz)) x2 += px; else z2 += pz;
    }
  }
  return { x:x2, z:z2 };
}
function rand(a,b){ return a + Math.random()*(b-a); }
function pick(arr){ return arr[Math.floor(Math.random()*arr.length)]; }

/* ======================= 5. ПРОЦЕДУРНЫЕ ТЕКСТУРЫ =========================== */
function makeCanvasTex(size, drawFn, repeat){
  const c = document.createElement('canvas'); c.width = c.height = size;
  const g = c.getContext('2d'); drawFn(g, size);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  if(repeat) t.repeat.set(repeat, repeat);
  return t;
}
function brickTex(){
  return makeCanvasTex(256, (g,s)=>{
    g.fillStyle = '#6e4a38'; g.fillRect(0,0,s,s);
    const bh = 32, bw = 64;
    for(let row=0; row<s/bh; row++){
      const off = (row%2)*bw/2;
      for(let col=-1; col<s/bw+1; col++){
        const x = col*bw + off, y = row*bh;
        const shade = 0.85 + Math.random()*0.3;
        g.fillStyle = `rgb(${Math.floor(120*shade)},${Math.floor(78*shade)},${Math.floor(58*shade)})`;
        g.fillRect(x+2, y+2, bw-4, bh-4);
        g.fillStyle = 'rgba(0,0,0,0.12)';
        g.fillRect(x+2, y+bh-8, bw-4, 6);
      }
    }
    for(let i=0;i<800;i++){ g.fillStyle = `rgba(0,0,0,${Math.random()*0.08})`; g.fillRect(Math.random()*s, Math.random()*s, 2, 2); }
  }, 1);
}
function concreteTex(){
  return makeCanvasTex(256, (g,s)=>{
    g.fillStyle = '#7d8288'; g.fillRect(0,0,s,s);
    for(let i=0;i<2600;i++){
      const v = Math.floor(Math.random()*40-20);
      g.fillStyle = `rgba(${128+v},${132+v},${136+v},0.35)`;
      g.fillRect(Math.random()*s, Math.random()*s, 3, 3);
    }
    g.strokeStyle = 'rgba(0,0,0,0.25)'; g.lineWidth = 2;
    g.strokeRect(1,1,s-2,s-2);
  }, 1);
}
function crateTex(){
  return makeCanvasTex(128, (g,s)=>{
    g.fillStyle = '#8a6b3d'; g.fillRect(0,0,s,s);
    g.strokeStyle = '#5d4526'; g.lineWidth = 8; g.strokeRect(4,4,s-8,s-8);
    g.beginPath(); g.moveTo(4,4); g.lineTo(s-4,s-4); g.moveTo(s-4,4); g.lineTo(4,s-4); g.stroke();
    for(let i=0;i<200;i++){ g.fillStyle = `rgba(0,0,0,${Math.random()*0.1})`; g.fillRect(Math.random()*s, Math.random()*s, 3, 3); }
  });
}
function metalTex(){
  return makeCanvasTex(128, (g,s)=>{
    g.fillStyle = '#3a4048'; g.fillRect(0,0,s,s);
    for(let i=0;i<s;i+=4){ g.fillStyle = `rgba(255,255,255,${Math.random()*0.05})`; g.fillRect(0,i,s,1); }
    g.fillStyle = '#f5c542'; g.fillRect(0, s/2-4, s, 8);
  });
}

/* ================================ 6. МИР ================================== */
// Архитектура карты: T-сверху, CT-снизу, пленты A (лево) и B (право) сверху,
// центральный коридор + боковые проходы. '#' стена, '.' пол, буквы — зоны.
const GRID = [
  '###############',
  '#......T......#',
  '#.............#',
  '#..A.......B..#',
  '#.............#',
  '#.###.....###.#',
  '#.#.........#.#',
  '#.#..##.##..#.#',
  '#.....#.#.....#',
  '##....#.#....##',
  '#.....#.#.....#',
  '#.##..#.#..##.#',
  '#.#.........#.#',
  '#.###.....###.#',
  '#.............#',
  '#.......S.....#',
  '#.............#',
  '###############',
];
let scene, camera, renderer;
let siteA, siteB, ctSpawn, tSpawn;   // {x,z}
const CRATES = [];                    // мировые позиции ящиков

function buildWorld(){
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x0d1117);
  scene.fog = new THREE.Fog(0x0d1117, 18, 78);
  camera = new THREE.PerspectiveCamera(save.settings.fov, innerWidth/innerHeight, 0.05, 200);
  renderer = new THREE.WebGLRenderer({ canvas: document.getElementById('game-canvas'), antialias:true, powerPreference:'high-performance' });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.setSize(innerWidth, innerHeight);

  scene.add(new THREE.HemisphereLight(0x9db4d4, 0x1c2a1a, 0.95));
  const dir = new THREE.DirectionalLight(0xfff2dd, 0.35); dir.position.set(20, 40, 10); scene.add(dir);
  const lampPos = [ [-18,-22], [10,-22], [0,0], [0,24], [0,-30] ];
  lampPos.forEach(p=>{
    const L = new THREE.PointLight(0xffe6b3, 0.7, 26); L.position.set(p[0], 3.8, p[1]); scene.add(L);
  });

  // --- парсинг сетки карты ---
  walls = [];
  const brick = brickTex(), conc = concreteTex(), crate = crateTex(), metal = metalTex();
  const matWall  = new THREE.MeshLambertMaterial({ map: brick });
  const matFloor = new THREE.MeshLambertMaterial({ map: conc });
  matFloor.map.repeat.set(15, 18); matFloor.map.needsUpdate = true;
  const matCeil  = new THREE.MeshLambertMaterial({ color: 0x2a313b });
  const matCrate = new THREE.MeshLambertMaterial({ map: crate });
  const wallGeo = new THREE.BoxGeometry(CELL, 4.6, CELL);

  for(let cy=0; cy<GH; cy++){
    for(let cx=0; cx<GW; cx++){
      const ch = GRID[cy][cx];
      const p = cellToWorld(cx, cy);
      if(ch === '#'){ addWall(cx, cy, 4.6); const m = new THREE.Mesh(wallGeo, matWall); m.position.set(p.x, 2.3, p.z); scene.add(m); }
      if(ch === 'A') siteA = p;
      if(ch === 'B') siteB = p;
      if(ch === 'S') ctSpawn = p;
      if(ch === 'T') tSpawn = p;
    }
  }
  // пол и потолок
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(GW*CELL, GH*CELL), matFloor);
  floor.rotation.x = -Math.PI/2; scene.add(floor);
  const ceil = new THREE.Mesh(new THREE.PlaneGeometry(GW*CELL, GH*CELL), matCeil);
  ceil.rotation.x = Math.PI/2; ceil.position.y = 4.6; scene.add(ceil);

  // --- ящики-укрытия на плент и в центре ---
  const crateCells = [ [2,2],[4,4],[3,4], [10,2],[12,4],[11,4], [5,8],[9,8], [5,10],[9,10], [7,4],[7,12], [2,12],[12,12], [4,14],[10,14] ];
  const crateGeo = new THREE.BoxGeometry(1.7, 1.7, 1.7);
  crateCells.forEach(c=>{
    const p = cellToWorld(c[0], c[1]);
    const m = new THREE.Mesh(crateGeo, matCrate); m.position.set(p.x, 0.85, p.z); scene.add(m);
    walls.push({ x0:p.x-0.85, x1:p.x+0.85, y0:0, y1:1.7, z0:p.z-0.85, z1:p.z+0.85 });
    if(Math.random() < 0.35){ const m2 = new THREE.Mesh(crateGeo, matCrate); m2.position.set(p.x+rand(-0.2,0.2), 2.55, p.z+rand(-0.2,0.2)); m2.rotation.y = rand(0,1); scene.add(m2); }
  });

  // --- металлические колонны в центре (архитектурный акцент) ---
  const colGeo = new THREE.CylinderGeometry(0.35, 0.35, 4.6, 10);
  const matCol = new THREE.MeshLambertMaterial({ map: metal });
  [[-6,-2],[6,2],[-6,10],[6,-10]].forEach(p=>{
    const m = new THREE.Mesh(colGeo, matCol); m.position.set(p[0], 2.3, p[1]); scene.add(m);
    walls.push({ x0:p[0]-0.35, x1:p[0]+0.35, y0:0, y1:4.6, z0:p[1]-0.35, z1:p[1]+0.35 });
  });

  // маркеры плент-зон (светящиеся полосы на полу)
  [siteA, siteB].forEach(s=>{
    const ring = new THREE.Mesh(new THREE.RingGeometry(3.4, 3.8, 32),
      new THREE.MeshBasicMaterial({ color: 0xf5c542, side: THREE.DoubleSide }));
    ring.rotation.x = -Math.PI/2; ring.position.set(s.x, 0.02, s.z); scene.add(ring);
  });

  buildRadarMap();
  addEventListener('resize', ()=>{
    camera.aspect = innerWidth/innerHeight; camera.updateProjectionMatrix();
    renderer.setSize(innerWidth, innerHeight);
  });
}

/* ============================ 7. ПЕРСОНАЖИ (модели) ======================= */
function lam(color){ return new THREE.MeshLambertMaterial({ color }); }
function bx(w,h,d, mat, x,y,z){
  const m = new THREE.Mesh(new THREE.BoxGeometry(w,h,d), mat);
  m.position.set(x,y,z); return m;
}
function cyl(r0,r1,len, mat, x,y,z){
  const m = new THREE.Mesh(new THREE.CylinderGeometry(r0,r1,len,10), mat);
  m.position.set(x,y,z); m.rotation.x = Math.PI/2; return m;
}
function makeCharacterMesh(team){
  const g = new THREE.Group();
  const colBody = team==='CT' ? 0x2f5fb5 : 0xb08a2e;
  const colVest = team==='CT' ? 0x1c2f4d : 0x4d3d14;
  const colHead = 0xc9a07a;
  const matB = lam(colBody), matV = lam(colVest), matH = lam(colHead);
  const torso = bx(0.62, 0.72, 0.34, matB, 0, 1.08, 0);
  const vest  = bx(0.66, 0.5, 0.4, matV, 0, 1.1, 0);
  const head  = bx(0.32, 0.32, 0.32, matH, 0, 1.62, 0);
  const helm  = bx(0.36, 0.14, 0.36, matV, 0, 1.78, 0);
  const legL = bx(0.22, 0.72, 0.24, matB, -0.16, 0.36, 0); legL.geometry.translate(0, -0.36, 0); legL.position.y = 0.72;
  const legR = bx(0.22, 0.72, 0.24, matB,  0.16, 0.36, 0); legR.geometry.translate(0, -0.36, 0); legR.position.y = 0.72;
  const armL = bx(0.16, 0.55, 0.2, matB, -0.42, 1.32, 0); armL.geometry.translate(0, -0.27, 0);
  const armR = bx(0.16, 0.55, 0.2, matB,  0.42, 1.32, 0); armR.geometry.translate(0, -0.27, 0);
  const gun  = bx(0.08, 0.14, 0.55, lam(0x1a1d20), 0.42, 1.05, -0.35);
  g.add(torso, vest, head, helm, legL, legR, armL, armR, gun);
  g.userData = { legL, legR, head };
  return g;
}

/* ===================== 8. VIEWMODEL: ОРУЖИЕ В РУКАХ ======================== */
const VM = {
  group:null, weaponKey:null, knifeModel:null,
  anim:{ name:'idle', t:0, dur:0 },
  bloom:0, bobT:0, swayX:0, swayY:0,
  parts:{}, flipT:-1,
};
const GLOVE_COLOR = ()=> (save.glovesColor != null ? save.glovesColor : 0x6b4a2f);

function vmMat(color){ return lam(color); }
function handBox(x,y,z){
  return bx(0.09, 0.09, 0.11, vmMat(GLOVE_COLOR()), x, y, z);
}
function accentOf(key){ // цвет скина, если есть
  return (save.skins && save.skins[key] != null) ? save.skins[key] : null;
}
function buildRifleVM(key){
  const w = WEAPONS[key], base = vmMat(w.color), dark = vmMat(0x111417);
  const acc = accentOf(key); const matAcc = vmMat(acc != null ? acc : w.color);
  const g = new THREE.Group(); const parts = {};
  g.add(bx(0.07, 0.1, 0.34, base, 0, 0, -0.1));                 // ствольная коробка
  g.add(bx(0.06, 0.075, 0.24, matAcc, 0, -0.005, -0.36));       // цевьё
  g.add(cyl(0.018, 0.018, 0.2, dark, 0, 0.01, -0.56));          // ствол
  if(w.silenced) g.add(cyl(0.038, 0.038, 0.22, dark, 0, 0.01, -0.62)); // глушитель
  g.add(bx(0.02, 0.05, 0.03, dark, 0, 0.075, -0.6));            // мушка
  if(key==='m4a4' || key==='m4a1s'){                            // рукоятка переноса M4
    g.add(bx(0.05, 0.06, 0.16, base, 0, 0.085, -0.16));
    parts.handle = g.children[g.children.length-1];
  }
  if(key==='ak47' || key==='galil'){
    g.add(bx(0.02, 0.06, 0.04, dark, 0, 0.08, -0.52));          // газовая трубка
    g.add(bx(0.02, 0.05, 0.03, dark, 0, 0.09, -0.46));
  }
  // магазин: у АК — изогнутый
  if(key==='ak47'){
    const m1 = bx(0.05, 0.14, 0.08, matAcc, 0, -0.11, -0.16); m1.rotation.x = 0.25;
    const m2 = bx(0.05, 0.1, 0.08, matAcc, 0, -0.2, -0.11);  m2.rotation.x = 0.55;
    parts.mag = m1; g.add(m1, m2);
  } else if(key==='galil'){
    const m1 = bx(0.05, 0.18, 0.07, matAcc, 0, -0.13, -0.15); m1.rotation.x = 0.18;
    parts.mag = m1; g.add(m1);
  } else {
    const m1 = bx(0.045, 0.12, 0.06, matAcc, 0, -0.1, -0.14); m1.rotation.x = 0.12;
    parts.mag = m1; g.add(m1);
  }
  const stock = bx(0.055, 0.09, 0.2, matAcc, 0, -0.01, 0.16);   // приклад
  g.add(stock); parts.stock = stock;
  const grip = bx(0.05, 0.12, 0.06, dark, 0, -0.1, 0.02); grip.rotation.x = 0.3; g.add(grip);
  g.add(bx(0.05, 0.04, 0.08, dark, 0, -0.085, -0.06));          // спусковая скоба
  // руки: правая на рукояти, левая на цевье
  g.add(handBox(0, -0.13, 0.02));
  g.add(handBox(-0.01, -0.06, -0.34));
  // дульный огонь (спрайт)
  const flash = new THREE.Mesh(new THREE.PlaneGeometry(0.22, 0.22),
    new THREE.MeshBasicMaterial({ color: 0xffcc55, transparent:true, opacity:0 }));
  flash.position.set(0, 0.01, -0.72); g.add(flash); parts.flash = flash;
  return { group:g, parts, len:0.72 };
}
function buildPistolVM(key){
  const w = WEAPONS[key], base = vmMat(w.color), dark = vmMat(0x101316);
  const acc = accentOf(key); const matAcc = vmMat(acc != null ? acc : w.color);
  const g = new THREE.Group(); const parts = {};
  const slideLen = key==='deagle' ? 0.3 : 0.24;
  g.add(bx(0.05, 0.07, slideLen, key==='deagle'?base:matAcc, 0, 0.03, -0.1)); // затвор
  g.add(bx(0.045, 0.05, 0.2, dark, 0, -0.03, -0.06));          // рамка
  g.add(cyl(0.014, 0.014, 0.06, dark, 0, 0.03, -0.1 - slideLen/2)); // дуло
  if(w.silenced) g.add(cyl(0.032, 0.032, 0.18, dark, 0, 0.03, -0.32));
  const grip = bx(0.045, 0.13, 0.07, matAcc, 0, -0.11, 0.03); grip.rotation.x = 0.22; g.add(grip);
  if(key==='deagle'){ g.add(bx(0.055, 0.02, 0.1, dark, 0, 0.075, -0.12)); } // характерный выступ
  g.add(handBox(0, -0.13, 0.04));
  const flash = new THREE.Mesh(new THREE.PlaneGeometry(0.16, 0.16),
    new THREE.MeshBasicMaterial({ color: 0xffcc55, transparent:true, opacity:0 }));
  flash.position.set(0, 0.03, w.silenced ? -0.44 : -0.3); g.add(flash); parts.flash = flash;
  return { group:g, parts, len:w.silenced ? 0.44 : 0.3 };
}
function buildKnifeVM(model){
  const g = new THREE.Group(); const parts = {};
  const steel = vmMat(0xb8c0c8), dark = vmMat(0x1a1d20);
  if(model==='butterfly'){
    // клинок
    const blade = new THREE.Group();
    blade.add(bx(0.012, 0.075, 0.14, steel, 0, 0.02, -0.12));
    blade.add(bx(0.012, 0.03, 0.05, steel, 0, 0.055, -0.07));
    g.add(blade); parts.blade = blade;
    // две половинки рукояти (раскрываются при трюке)
    const hL = new THREE.Group(), hR = new THREE.Group();
    hL.add(bx(0.02, 0.045, 0.14, vmMat(0x8a6b3d), -0.018, 0, 0.06));
    hR.add(bx(0.02, 0.045, 0.14, vmMat(0x8a6b3d),  0.018, 0, 0.06));
    hL.position.set(0, -0.02, 0); hR.position.set(0, -0.02, 0);
    g.add(hL, hR); parts.hL = hL; parts.hR = hR;
    g.add(handBox(0, -0.05, 0.06));
    g.rotation.x = -0.3;
  } else if(model==='karambit'){
    const blade = new THREE.Group();               // изогнутый коготь из сегментов
    const s1 = bx(0.012, 0.05, 0.1, steel, 0, 0.01, -0.1);
    const s2 = bx(0.012, 0.045, 0.07, steel, 0, 0.035, -0.17); s2.rotation.x = -0.7;
    const s3 = bx(0.012, 0.04, 0.05, steel, 0, 0.055, -0.21);  s3.rotation.x = -1.3;
    const tip = new THREE.Mesh(new THREE.ConeGeometry(0.012, 0.04, 6), steel);
    tip.position.set(0, 0.045, -0.235); tip.rotation.x = -2.2;
    blade.add(s1, s2, s3, tip);
    g.add(blade); parts.blade = blade;
    g.add(bx(0.035, 0.045, 0.13, vmMat(0x6e2f2f), 0, 0, 0.03));
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.028, 0.009, 8, 14), dark);
    ring.position.set(0, 0, 0.115); g.add(ring);
    g.add(handBox(0, -0.045, 0.03));
    g.rotation.x = -0.35;
  } else if(model==='tanto'){
    const blade = new THREE.Group();               // прямое танто с углом
    blade.add(bx(0.014, 0.06, 0.1, steel, 0, 0.015, -0.11));
    const tip = bx(0.014, 0.06, 0.05, steel, 0, 0.015, -0.185); tip.rotation.x = -0.5;
    blade.add(tip);
    g.add(blade); parts.blade = blade;
    g.add(bx(0.035, 0.05, 0.14, vmMat(0x3d3d3d), 0, 0, 0.04));
    g.add(bx(0.04, 0.055, 0.02, vmMat(0x777d84), 0, 0, -0.03));
    g.add(handBox(0, -0.05, 0.04));
    g.rotation.x = -0.35;
  } else { // стандартный нож
    const blade = new THREE.Group();
    blade.add(bx(0.014, 0.055, 0.13, steel, 0, 0.012, -0.12));
    const tip = new THREE.Mesh(new THREE.ConeGeometry(0.013, 0.05, 4), steel);
    tip.rotation.x = -Math.PI/2; tip.scale.set(1, 1, 0.5); tip.position.set(0, 0.012, -0.21);
    blade.add(tip);
    g.add(blade); parts.blade = blade;
    g.add(bx(0.035, 0.045, 0.13, vmMat(0x5d4526), 0, 0, 0.03));
    g.add(handBox(0, -0.05, 0.03));
    g.rotation.x = -0.35;
  }
  return { group:g, parts, len:0.25 };
}
function setVM(kind, key){
  if(VM.group){ camera.remove(VM.group); }
  VM.kind = kind; VM.weaponKey = key;
  let built;
  if(kind==='knife'){
    const item = save.inv.find(i=>i.uid===save.equipped.knifeUid);
    VM.knifeModel = item && item.model ? item.model : 'default';
    built = buildKnifeVM(VM.knifeModel);
  } else built = (WEAPONS[key].type==='rifle') ? buildRifleVM(key) : buildPistolVM(key);
  VM.group = built.group; VM.parts = built.parts;
  VM.group.position.set(0.26, -0.24, -0.45);
  camera.add(VM.group);
  VM.anim = { name:'draw', t:0, dur:0.3 };
  if(kind==='knife' && VM.knifeModel==='butterfly') VM.flipT = 0; // трюк бабочки при доставании
}
function vmPlay(name, dur){ VM.anim = { name, t:0, dur }; }
function updateVM(dt, moveSpeed, lookDX, lookDY){
  if(!VM.group) return;
  const g = VM.group, a = VM.anim;
  VM.bobT += dt * (2 + moveSpeed*1.6);
  VM.swayX += (THREE.MathUtils.clamp(-lookDX*0.0012, -0.05, 0.05) - VM.swayX) * Math.min(1, dt*10);
  VM.swayY += (THREE.MathUtils.clamp(lookDY*0.0012, -0.05, 0.05) - VM.swayY) * Math.min(1, dt*10);
  const bob = Math.min(1, moveSpeed/5);
  const baseX = 0.26 + Math.cos(VM.bobT*4)*0.006*bob + VM.swayX;
  const baseY = -0.24 + Math.abs(Math.sin(VM.bobT*4))*0.01*bob + VM.swayY;
  const baseZ = -0.45;
  g.position.set(baseX, baseY, baseZ);
  g.rotation.set(0, 0, 0);
  VM.bloom = Math.max(0, VM.bloom - dt*6);

  if(a.t < a.dur) a.t += dt;
  const k = a.dur > 0 ? Math.min(1, a.t/a.dur) : 1;

  if(a.name==='draw'){                       // доставание
    g.position.z = baseZ + (1-k)*0.4;
    g.rotation.y = (1-k)*0.5;
  } else if(a.name==='fire'){                // отдача выстрела
    const r = (1-k);
    g.position.z = baseZ + r*0.07*(WEAPONS[VM.weaponKey]?WEAPONS[VM.weaponKey].recoil:1);
    g.rotation.x = r*0.16;
  } else if(a.name==='swing'){               // взмах ножа
    const r = Math.sin(k*Math.PI);
    g.rotation.z = r*0.9; g.rotation.x = r*0.3;
    g.position.x = baseX - r*0.15;
  } else if(a.name==='reload'){              // перезарядка
    const down = Math.sin(Math.min(1, k*1.15)*Math.PI);
    g.position.y = baseY - down*0.14;
    g.rotation.x = down*0.55;
    g.rotation.z = down*0.15;
    if(VM.parts.mag) VM.parts.mag.position.y = -0.12 - down*0.1;
  }
  // трюк бабочки после доставания
  if(VM.flipT >= 0){
    VM.flipT += dt;
    const ft = VM.flipT, total = 1.5;
    if(ft < total && VM.parts.hL){
      const open = Math.min(1, ft/0.25);
      VM.parts.hL.rotation.z =  open*1.9; VM.parts.hR.rotation.z = -open*1.9;
      VM.parts.hL.rotation.y =  open*0.6; VM.parts.hR.rotation.y = -open*0.6;
      if(ft > 0.3){
        const spin = Math.min(1, (ft-0.3)/(total-0.5));
        const e = spin<0.5 ? 2*spin*spin : 1-Math.pow(-2*spin+2,2)/2;
        VM.parts.blade.rotation.x = e*Math.PI*2;
      }
      if(ft >= total){ VM.parts.blade.rotation.x = 0; VM.parts.hL.rotation.set(0,0,0); VM.parts.hR.rotation.set(0,0,0); VM.flipT = -1; }
    } else VM.flipT = -1;
  }
}

/* ============================ 9. ИИ БОТОВ ================================= */
let bots = [];
function makeBot(team, name){
  const b = {
    team, name, hp:100, alive:true,
    x:0, z:0, yaw:0, speed:3.4,
    target:null, thinkT:Math.random()*0.15, fireCd:rand(0.4,1),
    reactT:0, strafeDir:1, strafeT:0,
    objective:null, plantT:0, defuseT:0, carryBomb:false,
    stuckT:0, lastX:0, lastZ:0, walkT:0,
    mesh:makeCharacterMesh(team), kills:0,
  };
  scene.add(b.mesh);
  return b;
}
function botAliveCount(team){
  let n = 0; for(const b of bots) if(b.alive && b.team===team) n++;
  return n;
}
function botSense(b){
  // найти ближайшего видимого врага
  let best = null, bestD = 30;
  const eyeY = 1.55;
  const consider = (x, z, ref, isPlayer)=>{
    const d = Math.hypot(x-b.x, z-b.z);
    if(d < bestD && losClear(b.x, eyeY, b.z, x, isPlayer?1.55:1.5, z)){ bestD = d; best = { x, z, ref, isPlayer, d }; }
  };
  if(player.alive && player.team !== b.team) consider(player.x, player.z, null, true);
  for(const o of bots) if(o.alive && o.team !== b.team) consider(o.x, o.z, o, false);
  b.target = best;
  if(best && b.reactT <= 0) b.reactT = rand(0.25, 0.65);
}
function botShoot(b, dt, target){
  b.fireCd -= dt;
  if(b.fireCd > 0) return;
  b.fireCd = rand(0.45, 0.8);
  const acc = Math.max(0.06, 0.42 - target.d*0.011);
  const hit = Math.random() < acc;
  burst(0.06, 1400, 0.1); // глухой выстрел рядом
  if(!hit) return;
  const head = Math.random() < 0.1;
  const dmg = (head?3:1) * rand(8, 15);
  if(target.isPlayer) hurtPlayer(dmg, b.name);
  else damageBot(target.ref, dmg, null, head, b.name);
}
function botUpdate(b, dt){
  if(!b.alive) return;
  b.thinkT -= dt; if(b.thinkT <= 0){ b.thinkT = 0.14; botSense(b); }
  if(b.target){
    b.reactT -= dt;
    const t = b.target;
    b.yaw = Math.atan2(t.x-b.x, t.z-b.z) + Math.PI; // взгляд на цель
    b.strafeT -= dt;
    if(b.strafeT <= 0){ b.strafeT = rand(0.7, 1.4); b.strafeDir = Math.random()<0.5?-1:1; }
    let mx = 0, mz = 0;
    const dx = t.x-b.x, dz = t.z-b.z, d = Math.hypot(dx,dz)||1;
    if(d > 16){ mx += dx/d; mz += dz/d; } else if(d < 7){ mx -= dx/d; mz -= dz/d; }
    mx += -dz/d*b.strafeDir*0.8; mz += dx/d*b.strafeDir*0.8;
    const l = Math.hypot(mx,mz)||1;
    botMove(b, mx/l*b.speed*dt, mz/l*b.speed*dt);
    if(b.reactT <= 0) botShoot(b, dt, t);
  } else {
    botObjective(b, dt);
  }
  // анимация модели
  b.mesh.position.set(b.x, 0, b.z);
  b.mesh.rotation.y = b.yaw;
  b.walkT += dt * (b.target || b.moving ? 9 : 0);
  const sw = Math.sin(b.walkT)*0.5;
  b.mesh.userData.legL.rotation.x = sw; b.mesh.userData.legR.rotation.x = -sw;
  b.moving = false;
}
function botObjective(b, dt){
  const planted = bomb.state==='planted';
  const site = bomb.plantSite === 'A' ? siteA : siteB;
  if(b.team==='T'){
    if(planted){ // охранять бомбу
      if(!b.guardPt || Math.hypot(b.guardPt.x-b.x, b.guardPt.z-b.z) < 1){
        if(Math.random()<0.01) b.guardPt = { x: bomb.x+rand(-5,5), z: bomb.z+rand(-5,5) };
      }
      botGoto(b, b.guardPt || {x:bomb.x, z:bomb.z}, dt);
      return;
    }
    if(b.carryBomb){
      const d = Math.hypot(site.x-b.x, site.z-b.z);
      if(d < 2.6){
        b.plantT += dt;
        if(b.plantT > 3){ plantBomb(b.x, b.z, bomb.plantSite); b.carryBomb = false; }
        return;
      }
      b.plantT = 0;
      botGoto(b, site, dt);
    } else if(bomb.state==='dropped'){
      botGoto(b, bomb, dt);
      if(Math.hypot(bomb.x-b.x, bomb.z-b.z) < 1.5){ bomb.state='carried'; b.carryBomb = true; }
    } else {
      // следовать за носителем или бродить
      const carrier = bots.find(o=>o.alive && o.carryBomb);
      if(carrier && Math.random()<0.7) botGoto(b, { x:carrier.x+rand(-3,3), z:carrier.z+rand(-3,3) }, dt);
      else botWander(b, dt);
    }
  } else { // CT
    if(planted){
      const d = Math.hypot(bomb.x-b.x, bomb.z-b.z);
      if(d < 2){
        b.defuseT += dt;
        SFX.defuse();
        if(b.defuseT > 5){ defuseBomb(); }
        return;
      }
      b.defuseT = 0;
      botGoto(b, bomb, dt);
      return;
    }
    botWander(b, dt); // патруль между плентами
  }
}
function botWander(b, dt){
  if(!b.wanderPt || Math.hypot(b.wanderPt.x-b.x, b.wanderPt.z-b.z) < 1.2){
    if(Math.random()<0.4) b.wanderPt = Math.random()<0.5 ? {x:siteA.x, z:siteA.z} : {x:siteB.x, z:siteB.z};
    else b.wanderPt = { x:rand(-22,22), z:rand(-16,20) };
  }
  botGoto(b, b.wanderPt, dt);
}
function botGoto(b, pt, dt){
  if(!pt) return;
  const dx = pt.x-b.x, dz = pt.z-b.z, d = Math.hypot(dx,dz);
  if(d < 0.3) return;
  b.yaw = Math.atan2(dx, dz) + Math.PI;
  botMove(b, dx/d*b.speed*dt, dz/d*b.speed*dt);
  // застрял? — сменить цель
  b.stuckT += dt;
  if(b.stuckT > 0.8){
    if(Math.hypot(b.x-b.lastX, b.z-b.lastZ) < 0.25){ b.wanderPt = null; b.objectivePt = null; }
    b.lastX = b.x; b.lastZ = b.z; b.stuckT = 0;
  }
}
function botMove(b, dx, dz){
  const r = collideMove(b.x, b.z, 0.35, b.x+dx, b.z+dz);
  b.x = r.x; b.z = r.z; b.moving = true;
}
function damageBot(b, dmg, byPlayer, head, killerName){
  if(!b.alive) return;
  b.hp -= dmg;
  if(b.hp <= 0){
    b.alive = false;
    b.deadT = 0;
    if(byPlayer){
      player.kills++; save.stats.kills++;
      addMoney(300); player.roundKills++;
      SFX.hit(true);
    }
    if(killerName) killfeed(killerName, b.name, head);
    else if(byPlayer) killfeed('Вы', b.name, head);
    if(b.carryBomb){ b.carryBomb = false; bomb.state='dropped'; bomb.x=b.x; bomb.z=b.z; }
    checkRoundEnd();
  } else if(byPlayer){ SFX.hit(head); showHitmarker(head); }
}
function updateDeadBots(dt){
  for(const b of bots){
    if(b.alive || b.deadT > 3) continue;
    b.deadT += dt;
    b.mesh.rotation.z = Math.min(Math.PI/2, b.deadT*4);
    b.mesh.position.y = -Math.max(0, b.deadT-1.6)*0.8;
  }
}

/* ================================ 10. БОМБА =============================== */
const bomb = { state:'none', x:0, z:0, timer:40, plantSite:'A', mesh:null, blinkT:0, beepT:0 };
function buildBombMesh(){
  if(bomb.mesh) scene.remove(bomb.mesh);
  const g = new THREE.Group();
  g.add(bx(0.4, 0.25, 0.28, lam(0x2a2d31), 0, 0.13, 0));
  g.add(bx(0.1, 0.06, 0.1, lam(0xd42b2b), 0, 0.28, 0));
  g.add(bx(0.36, 0.05, 0.05, lam(0xf5c542), 0, 0.2, 0.12));
  g.visible = false;
  scene.add(g);
  bomb.mesh = g;
}
function plantBomb(x, z, site){
  bomb.state = 'planted'; bomb.x = x; bomb.z = z; bomb.timer = 40;
  bomb.mesh.visible = true; bomb.mesh.position.set(x, 0, z);
  roundMsg(site==='A' ? 'БОМБА ЗАЛОЖЕНА: ПЛЕНТ А' : 'БОМБА ЗАЛОЖЕНА: ПЛЕНТ Б', '');
  SFX.plant();
  for(const b of bots) if(b.team==='CT') b.wanderPt = null;
}
function defuseBomb(){
  if(bomb.state!=='planted') return;
  bomb.state='none'; bomb.mesh.visible = false;
  endRound('CT', 'Бомба обезврежена');
}
function explodeBomb(){
  bomb.state='none'; bomb.mesh.visible=false;
  SFX.explode();
  flashScreen(0.9);
  const d = Math.hypot(player.x-bomb.x, player.z-bomb.z);
  shakeCam = Math.min(1.2, 30/(d+4));
  if(d < 16 && player.alive) hurtPlayer(200, 'Бомба');
  for(const b of bots) if(b.alive && Math.hypot(b.x-bomb.x, b.z-bomb.z) < 16) damageBot(b, 200, false, false, null);
  endRound('T', 'Бомба взорвалась');
}
function updateBomb(dt){
  if(bomb.state==='planted'){
    bomb.timer -= dt;
    bomb.blinkT += dt; bomb.beepT -= dt;
    if(bomb.beepT <= 0){
      const urgency = bomb.timer < 10 ? 0.25 : 1;
      bomb.beepT = urgency; SFX.beep(bomb.timer < 10);
      bomb.mesh.children[1].material = lam(0xffffff);
      setTimeout(()=>{ if(bomb.mesh) bomb.mesh.children[1].material = lam(0xd42b2b); }, 90);
    }
    if(bomb.timer <= 0) explodeBomb();
  }
}

/* ============================ 11. РАУНДЫ / МАТЧ =========================== */
const MATCH = { firstTo:8, swapAt:8 };
let match = null;
function startMatch(){
  match = {
    round:0, swapped:false, phase:'freeze', freezeT:4, roundT:115, endT:0,
    scoreYou:0, scoreEnemy:0,
  };
  player.team = chosenTeam;
  player.money = 800;
  player.matchKills = 0;
  startRound();
}
function clearBots(){
  for(const b of bots) scene.remove(b.mesh);
  bots = [];
}
function startRound(){
  match.round++;
  match.phase = 'freeze'; match.freezeT = 4; match.roundT = 115;
  bomb.state='none'; bomb.mesh.visible=false;
  player.roundKills = 0;
  // спавн игрока
  const sp = player.team==='CT' ? ctSpawn : tSpawn;
  player.x = sp.x + rand(-2,2); player.z = sp.z + rand(-1,1);
  player.hp = 100; player.alive = true; player.velY = 0;
  player.yaw = player.team==='CT' ? Math.PI : 0;
  player.pitch = 0;
  player.weapons = { primary:null, secondary: player.team==='CT' ? 'usp' : 'glock' };
  player.slot = 'secondary';
  player.hasBomb = player.team==='T';
  // боты
  clearBots();
  const myBots = [], enBots = [];
  for(let i=0;i<4;i++) myBots.push(makeBot(player.team, pick(BOT_NAMES)));
  for(let i=0;i<5;i++) enBots.push(makeBot(player.team==='CT'?'T':'CT', pick(BOT_NAMES)));
  bots = myBots.concat(enBots);
  const mySp = player.team==='CT' ? ctSpawn : tSpawn;
  const enSp = player.team==='CT' ? tSpawn : ctSpawn;
  myBots.forEach(b=>{ b.x = mySp.x+rand(-4,4); b.z = mySp.z+rand(-3,3); });
  enBots.forEach(b=>{ b.x = enSp.x+rand(-4,4); b.z = enSp.z+rand(-3,3); });
  // носитель бомбы — бот террорист (если игрок не Т)
  if(player.team!=='T'){
    const carriers = enBots;
    pick(carriers).carryBomb = true;
  }
  bomb.plantSite = Math.random()<0.5 ? 'A' : 'B';
  player.plantT = 0; player.defuseT = 0;
  setVM('gun', player.weapons.secondary);
  magReset();
  document.getElementById('death-overlay').classList.remove('active');
  roundMsg('РАУНД ' + match.round, match.round===MATCH.swapAt && !match.swapped ? '⚠ После раунда — смена сторон' : '');
  updateScoreboard();
  if(player.team==='CT') showBuyMenu(); else showBuyMenu();
}
function beginLive(){
  match.phase = 'live';
  roundMsg('', '');
  hideBuyMenu();
}
function endRound(winner, reason){
  if(match.phase==='end') return;
  match.phase='end'; match.endT = 5;
  const youWin = winner === player.team;
  if(youWin){ match.scoreYou++; player.money += 3500; SFX.win(); }
  else { match.scoreEnemy++; player.money += 1400; SFX.lose(); }
  // MVP
  let mvp = null, mk = -1;
  if(player.roundKills > mk){ mk = player.roundKills; mvp = 'Вы'; }
  for(const b of bots) if(b.alive || true) if(b.roundKills > mk){ mk = b.roundKills; mvp = b.name; }
  roundMsg(youWin ? 'РАУНД ВАШ' : 'РАУНД ПРОИГРАН', reason + (mk>0 ? ' • MVP: ' + mvp + ' (' + mk + ')' : ''));
  updateScoreboard();
}
function nextRoundOrEnd(){
  const s = match.scoreYou, e = match.scoreEnemy;
  if(s >= MATCH.firstTo || e >= MATCH.firstTo || match.round >= 15){
    finishMatch();
    return;
  }
  if(match.round === MATCH.swapAt && !match.swapped){
    match.swapped = true;
    player.team = player.team==='CT' ? 'T' : 'CT';
    player.money = 800;
    roundMsg('СМЕНА СТОРОН', 'Теперь вы играете за ' + (player.team==='CT'?'КТ (спецназ)':'Т (террористов)'));
    setTimeout(()=>{ if(match) startRound(); }, 2500);
  } else {
    startRound();
  }
}
function finishMatch(){
  const s = match.scoreYou, e = match.scoreEnemy;
  save.stats.matches++;
  const win = s > e;
  if(win) save.stats.wins++;
  persist();
  document.getElementById('end-title').textContent = win ? '🏆 ПОБЕДА!' : (s===e ? '🤝 НИЧЬЯ' : 'ПОРАЖЕНИЕ');
  document.getElementById('end-score').textContent = 'ВЫ ' + s + ' : ' + e + ' ВРАГ';
  document.getElementById('end-stats').innerHTML =
    'Убийств за матч: <b>' + player.matchKills + '</b><br>' +
    'Матчей всего: <b>' + save.stats.matches + '</b> • Побед: <b>' + save.stats.wins + '</b><br>' +
    'Убийств всего: <b>' + save.stats.kills + '</b>';
  match = null;
  showScreen('scr-end');
  document.getElementById('hud').classList.remove('active');
}
function checkRoundEnd(){
  if(!match || match.phase!=='live') return;
  const planted = bomb.state==='planted';
  const myAlive = botAliveCount(player.team) + (player.alive?1:0);
  const enAlive = botAliveCount(player.team==='CT'?'T':'CT');
  if(myAlive===0){
    if(planted) return; // ждём бомбу
    endRound(player.team==='CT'?'T':'CT', 'Ваша команда уничтожена');
  } else if(enAlive===0){
    if(planted) return;
    endRound(player.team, 'Враги уничтожены');
  }
}
function addMoney(n){ player.money = Math.min(16000, player.money + n); }
function magReset(){
  const key = player.weapons[player.slot];
  if(key && WEAPONS[key]){
    player.mag = WEAPONS[key].mag;
    player.reserve = WEAPONS[key].reserve;
  } else { player.mag = 0; player.reserve = 0; }
}

/* ============================ 12. ИГРОК =================================== */
const EYE = 1.6;
const player = {
  x:0, z:0, feetY:0, yaw:0, pitch:0, velY:0,
  hp:100, alive:true, team:'CT', money:800,
  kills:0, matchKills:0, roundKills:0,
  weapons:{ primary:null, secondary:'usp' }, slot:'secondary',
  magData:{ primary:{mag:0,res:0}, secondary:{mag:12,res:24} },
  mag:12, reserve:24, reloading:false, reloadEnd:0, fireCd:0,
  hasBomb:false, plantT:0, defuseT:0, meleeT:-1, deadT:0,
};
let chosenTeam = 'CT';
let shakeCam = 0, speedMul = 1, paused = false;
let lookDX = 0, lookDY = 0, moveSpeed = 0;

function camForward(){
  const cp = Math.cos(player.pitch);
  return { x: Math.sin(player.yaw)*cp, y: Math.sin(player.pitch), z: Math.cos(player.yaw)*cp };
}
function camRight(){ return { x: -Math.cos(player.yaw), y: 0, z: Math.sin(player.yaw) }; }

function hurtPlayer(dmg, fromName){
  if(!player.alive || !match) return;
  player.hp -= dmg;
  SFX.hurt();
  const v = document.getElementById('vignette');
  v.style.opacity = Math.min(0.95, 0.35 + (100-player.hp)/120);
  shakeCam = Math.min(0.6, shakeCam + 0.12);
  if(player.hp <= 0){
    player.alive = false; player.hp = 0;
    SFX.death();
    const kb = bots.find(o=>o.name===fromName);
    if(kb){ kb.kills++; kb.roundKills++; }
    killfeed(fromName || 'Враг', 'Вы', false);
    if(player.hasBomb){ player.hasBomb = false; bomb.state='dropped'; bomb.x=player.x; bomb.z=player.z; }
    document.getElementById('death-by').textContent = 'Вас устранил: ' + (fromName || 'Враг');
    document.getElementById('death-overlay').classList.add('active');
    speedMul = 1;
    checkRoundEnd();
  }
}
function startReload(){
  if(player.slot==='knife' || player.reloading) return;
  const key = player.weapons[player.slot];
  if(!key) return;
  if(player.mag >= WEAPONS[key].mag || player.reserve <= 0) return;
  player.reloading = true;
  player.reloadEnd = performance.now()/1000 + WEAPONS[key].reload;
  vmPlay('reload', WEAPONS[key].reload);
  SFX.reload();
}
function finishReload(){
  const key = player.weapons[player.slot];
  if(!key) return;
  const need = WEAPONS[key].mag - player.mag;
  const take = Math.min(need, player.reserve);
  player.mag += take; player.reserve -= take;
  player.reloading = false;
}
function switchSlot(slot){
  if(!player.alive || slot===player.slot) return;
  if(slot==='primary' && !player.weapons.primary) return;
  player.magData[player.slot] = { mag: player.mag, res: player.reserve };
  player.slot = slot;
  const key = player.weapons[slot];
  player.mag = player.magData[slot].mag;
  player.reserve = player.magData[slot].res;
  player.reloading = false;
  setVM(slot==='knife' ? 'knife' : 'gun', key);
  SFX.click();
  updateHUD();
}
function cycleWeapon(){
  const order = ['knife','secondary','primary'];
  let i = order.indexOf(player.slot);
  for(let k=1;k<=3;k++){
    const s = order[(i+k)%3];
    if(s==='knife' || (s==='secondary' && player.weapons.secondary) || (s==='primary' && player.weapons.primary)){ switchSlot(s); return; }
  }
}
function buyWeapon(key){
  const w = WEAPONS[key];
  if(!w || match.phase!=='freeze') return;
  const isPistol = w.type==='pistol';
  if((isPistol && player.weapons.secondary===key) || (!isPistol && player.weapons.primary===key)) return;
  if(player.money < w.price) return;
  player.money -= w.price;
  SFX.buy();
  if(isPistol){
    player.weapons.secondary = key;
    player.magData.secondary = { mag: w.mag, res: w.reserve };
  } else {
    player.weapons.primary = key;
    player.magData.primary = { mag: w.mag, res: w.reserve };
  }
  renderBuyList();
  updateHUD();
}
/* ------------------------------ стрельба --------------------------------- */
const tracers = [], casings = [], sparks = [];
let vmLight = null;
function muzzleFlash(){
  if(VM.parts.flash) VM.parts.flash.material.opacity = 1;
  if(vmLight) vmLight.intensity = 1.4;
}
function spawnCasing(){
  if(!VM.group) return;
  const m = new THREE.Mesh(new THREE.BoxGeometry(0.015,0.015,0.03), lam(0xd4af37));
  const r = camRight(), f = camForward();
  m.position.set(camera.position.x + f.x*0.5 + r.x*0.2, camera.position.y-0.15, camera.position.z + f.z*0.5 + r.z*0.2);
  casings.push({ m, vx:r.x*rand(1,2)+rand(-0.3,0.3), vy:rand(1.5,2.5), vz:r.z*rand(1,2)+rand(-0.3,0.3), life:1.2 });
  scene.add(m);
}
function spawnSpark(x,y,z, color){
  const m = new THREE.Mesh(new THREE.BoxGeometry(0.05,0.05,0.05), new THREE.MeshBasicMaterial({ color: color||0xffcc66 }));
  m.position.set(x,y,z);
  sparks.push({ m, vx:rand(-1.5,1.5), vy:rand(0.5,2.5), vz:rand(-1.5,1.5), life:0.35 });
  scene.add(m);
}
function addTracer(x0,y0,z0, x1,y1,z1){
  const g = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(x0,y0,z0), new THREE.Vector3(x1,y1,z1)]);
  const l = new THREE.Line(g, new THREE.LineBasicMaterial({ color: 0xffe08a, transparent:true, opacity:0.9 }));
  tracers.push({ l, life:0.07 });
  scene.add(l);
}
function shootRay(w){
  const spread = (w.spread + VM.bloom) * Math.PI/180;
  const f = camForward(), r = camRight();
  const up = { x: r.y*f.z - r.z*f.y, y: r.z*f.x - r.x*f.z, z: r.x*f.y - r.y*f.x };
  const a = Math.random()*Math.PI*2, rad = Math.random()*spread;
  const dx = f.x + (r.x*Math.cos(a)+up.x*Math.sin(a))*rad;
  const dy = f.y + (r.y*Math.cos(a)+up.y*Math.sin(a))*rad;
  const dz = f.z + (r.z*Math.cos(a)+up.z*Math.sin(a))*rad;
  const dl = Math.hypot(dx,dy,dz);
  const ox = camera.position.x, oy = camera.position.y, oz = camera.position.z;
  const ux = dx/dl, uy = dy/dl, uz = dz/dl;
  const MAXD = 90;
  let tWall = rayWallsT(ox,oy,oz, ux,uy,uz, MAXD);
  let hitBot = null, hitT = tWall, hitHead = false;
  for(const b of bots){
    if(!b.alive || b.team===player.team) continue;
    const th = raySphere(ox,oy,oz, ux,uy,uz, b.x, 1.62, b.z, 0.27, hitT);
    const tb = raySphere(ox,oy,oz, ux,uy,uz, b.x, 0.95, b.z, 0.52, hitT);
    if(th >= 0 && th <= hitT){ hitT = th; hitBot = b; hitHead = true; }
    else if(tb >= 0 && tb <= hitT){ hitT = tb; hitBot = b; hitHead = false; }
  }
  const mr = camRight(), mf = camForward();
  const mx = ox + mf.x*0.55 + mr.x*0.18, my = oy - 0.12, mz = oz + mf.z*0.55 + mr.z*0.18;
  addTracer(mx,my,mz, ox+ux*hitT, oy+uy*hitT, oz+uz*hitT);
  if(hitBot){
    const dmg = w.dmg * (hitHead ? 4 : 1);
    spawnSpark(ox+ux*hitT, oy+uy*hitT, oz+uz*hitT, 0xaa2222);
    damageBot(hitBot, dmg, true, hitHead);
  } else if(tWall < MAXD){
    spawnSpark(ox+ux*tWall, oy+uy*tWall, oz+uz*tWall, 0xffcc66);
  }
}
let fireHeld = false, firePressed = false;
function tryFire(){
  if(!match || match.phase!=='live' || !player.alive || paused) return;
  const key = player.weapons[player.slot];
  if(player.fireCd > 0 || player.reloading) return;
  if(player.slot === 'knife'){ knifeAttack(); return; }
  if(!key) return;
  const w = WEAPONS[key];
  if(player.mag <= 0){ SFX.dry(); player.fireCd = 0.25; startReload(); return; }
  player.fireCd = 60 / w.rpm;
  player.mag--;
  SFX.shoot(key);
  vmPlay('fire', 0.09);
  muzzleFlash();
  const rc = w.recoil * 0.011;
  player.pitch = Math.min(1.4, player.pitch + rc);
  player.yaw += rand(-1,1)*rc*0.3;
  VM.bloom = Math.min(3, VM.bloom + 0.45);
  shootRay(w);
  spawnCasing();
  shakeCam = Math.min(0.3, shakeCam + w.recoil*0.02);
  if(player.mag === 0) startReload();
  updateHUD();
}
function knifeAttack(){
  const k = KNIVES[VM.knifeModel || 'default'];
  player.fireCd = 60 / k.rpm;
  vmPlay('swing', 0.35);
  player.meleeT = 0.14;
  SFX.knife();
}
function resolveMelee(){
  const k = KNIVES[VM.knifeModel || 'default'];
  const f = camForward();
  const ox = camera.position.x, oy = camera.position.y, oz = camera.position.z;
  let hit = null, hd = false;
  for(const b of bots){
    if(!b.alive || b.team===player.team) continue;
    const th = raySphere(ox,oy,oz, f.x,f.y,f.z, b.x, 1.62, b.z, 0.3, k.range);
    const tb = raySphere(ox,oy,oz, f.x,f.y,f.z, b.x, 0.95, b.z, 0.55, k.range);
    if(th>=0){ hit = b; hd = true; break; }
    if(tb>=0 && !hit){ hit = b; hd = false; }
  }
  if(hit){ SFX.knifeHit(); damageBot(hit, k.dmg*(hd?2:1), true, hd); }
}

/* ============================ 13. HUD / РАДАР ============================= */
let radarBg = null;
function buildRadarMap(){
  radarBg = document.createElement('canvas');
  radarBg.width = 140; radarBg.height = 168;
  const g = radarBg.getContext('2d');
  g.fillStyle = 'rgba(10,14,20,0.9)'; g.fillRect(0,0,140,168);
  const sx = 140/60, sz = 168/72;
  g.fillStyle = '#3d5878';
  for(let cy=0; cy<GH; cy++) for(let cx=0; cx<GW; cx++){
    if(GRID[cy][cx] !== '#') continue;
    const p = cellToWorld(cx,cy);
    g.fillRect((p.x-2+30)*sx, (p.z-2+36)*sz, 4*sx, 4*sz);
  }
  g.font = 'bold 13px Arial'; g.textAlign = 'center'; g.textBaseline = 'middle';
  g.fillStyle = '#f5c542';
  g.fillText('A', (siteA.x+30)*sx, (siteA.z+36)*sz);
  g.fillText('B', (siteB.x+30)*sx, (siteB.z+36)*sz);
}
function radarXY(x, z){ return [ (x+30)*140/60, (z+36)*168/72 ]; }
function drawRadar(){
  const cv = document.getElementById('radar');
  const g = cv.getContext('2d');
  g.clearRect(0,0,140,168);
  g.drawImage(radarBg, 0, 0);
  const now = performance.now()/1000;
  if(bomb.state==='planted' || bomb.state==='dropped'){
    const bxy = radarXY(bomb.x, bomb.z);
    g.font = '11px Arial'; g.textAlign='center';
    g.fillText('💣', bxy[0], bxy[1]);
  }
  for(const b of bots){
    if(!b.alive) continue;
    const mine = b.team === player.team;
    if(!mine){
      const d = Math.hypot(b.x-player.x, b.z-player.z);
      if(d < 26 && losClear(player.x, 1.6, player.z, b.x, 1.5, b.z)){ b.seenT = now; b.seenX = b.x; b.seenZ = b.z; }
      if(now - (b.seenT||0) > 2.5) continue;
      const xy = radarXY(b.seenX != null ? b.seenX : b.x, b.seenZ != null ? b.seenZ : b.z);
      g.fillStyle = '#ff5252';
      g.beginPath(); g.arc(xy[0], xy[1], 3, 0, 7); g.fill();
    } else {
      const xy = radarXY(b.x, b.z);
      g.fillStyle = '#4dff7c';
      g.beginPath(); g.arc(xy[0], xy[1], 3, 0, 7); g.fill();
    }
  }
  const pxy = radarXY(player.x, player.z);
  g.save(); g.translate(pxy[0],pxy[1]); g.rotate(-Math.atan2(Math.sin(player.yaw), Math.cos(player.yaw)) + Math.PI);
  g.fillStyle = '#fff';
  g.beginPath(); g.moveTo(0,-5.5); g.lineTo(3.6,4); g.lineTo(-3.6,4); g.closePath(); g.fill();
  g.restore();
}
function updateHUD(){
  document.getElementById('hp-fill').style.width = Math.max(0, player.hp) + '%';
  document.getElementById('money').textContent = '$' + player.money;
  if(player.slot==='knife'){
    document.getElementById('ammo').innerHTML = '—';
    document.getElementById('weapon-name').textContent = KNIVES[VM.knifeModel||'default'].name;
  } else {
    document.getElementById('ammo').innerHTML = player.mag + ' <span>/ ' + player.reserve + '</span>';
    document.getElementById('weapon-name').textContent = WEAPONS[player.weapons[player.slot]].name;
  }
  document.getElementById('score-line').textContent = 'ВЫ ' + (match?match.scoreYou:0) + ' : ' + (match?match.scoreEnemy:0) + ' ВРАГ';
}
function updateTimerHUD(){
  if(!match) return;
  const t = Math.max(0, match.phase==='freeze' ? match.freezeT : (bomb.state==='planted' ? bomb.timer : match.roundT));
  const mm = Math.floor(t/60), ss = Math.floor(t%60);
  const el = document.getElementById('timer');
  el.textContent = mm + ':' + (ss<10?'0':'') + ss;
  el.classList.toggle('danger', bomb.state==='planted' || t < 20);
  const bs = document.getElementById('bomb-status');
  if(bomb.state==='planted') bs.textContent = '💣 БОМБА: ' + bomb.plantSite;
  else if(player.hasBomb) bs.textContent = '💣 У вас бомба — идите на плент';
  else bs.textContent = '';
}
function roundMsg(main, sub){
  const el = document.getElementById('round-msg');
  if(!main){ el.style.display = 'none'; return; }
  el.innerHTML = main + '<div id="sub-msg">' + (sub||'') + '</div>';
  el.style.display = 'block';
}
function killfeed(a, b, head){
  const kf = document.getElementById('killfeed');
  const row = document.createElement('div');
  row.className = 'kf-row';
  row.innerHTML = '<span class="' + (a==='Вы'?'kf-you':'kf-enemy') + '">' + a + '</span> ' +
    (head?'🎯 ':'') + '⚔️ ' + '<span class="' + (b==='Вы'?'kf-you':'kf-enemy') + '">' + b + '</span>';
  kf.appendChild(row);
  while(kf.children.length > 5) kf.removeChild(kf.firstChild);
  setTimeout(()=>{ if(row.parentNode) row.parentNode.removeChild(row); }, 4500);
}
function showHitmarker(head){
  const hm = document.getElementById('hitmarker');
  hm.className = head ? 'head' : '';
  hm.style.opacity = 1;
  clearTimeout(hm._t);
  hm._t = setTimeout(()=> hm.style.opacity = 0, 140);
}
function flashScreen(op){
  document.getElementById('flash').style.opacity = op;
}
/* ------------------------------ покупки ---------------------------------- */
function renderBuyList(){
  const list = document.getElementById('buy-list');
  list.innerHTML = '';
  const mk = (key)=>{
    const w = WEAPONS[key];
    const owned = (w.type==='pistol' && player.weapons.secondary===key) || (w.type==='rifle' && player.weapons.primary===key);
    const cant = player.money < w.price;
    const div = document.createElement('div');
    div.className = 'buy-item' + (owned?' owned':'') + (cant&&!owned?' cant':'');
    div.innerHTML = '<div><div class="bi-name">' + w.name + (save.skins[key]!=null?' 🎨':'') + '</div>' +
      '<div class="bi-type">' + w.desc + ' • Урон ' + w.dmg + ' • ' + w.mag + ' патр.</div></div>' +
      '<div class="bi-price">' + (owned ? 'КУПЛЕНО' : '$'+w.price) + '</div>';
    if(!owned) div.addEventListener('click', ()=> buyWeapon(key));
    list.appendChild(div);
  };
  ['ak47','m4a4','m4a1s','galil','deagle'].forEach(mk);
  const note = document.createElement('div');
  note.style.cssText = 'color:#8fa3ba;font-size:12px;text-align:center;margin-top:4px;';
  note.textContent = 'Пистолет команды (' + (player.team==='CT'?'USP-S':'Glock-18') + ') — бесплатно. Нож всегда с собой.';
  list.appendChild(note);
}
function showBuyMenu(){ renderBuyList(); document.getElementById('buy-menu').classList.add('active'); }
function hideBuyMenu(){ document.getElementById('buy-menu').classList.remove('active'); }
/* ----------------------------- таблица счёта ------------------------------ */
function updateScoreboard(){
  const list = document.getElementById('sb-list');
  list.innerHTML = '';
  const rows = [{ name:'Вы (ваша команда)', kills:player.matchKills, you:true }];
  for(const b of bots) rows.push({ name:b.name + ' [' + b.team + ']', kills:b.kills, you:b.team===player.team });
  rows.sort((a,b)=> b.kills - a.kills);
  for(const r of rows){
    const div = document.createElement('div');
    div.className = 'sb-row ' + (r.you?'sb-you':'sb-enemy');
    div.innerHTML = '<span>' + r.name + '</span><span>' + r.kills + '</span>';
    list.appendChild(div);
  }
}

/* ============================ 14. UI ЭКРАНЫ =============================== */
function showScreen(id){
  document.querySelectorAll('.screen').forEach(s=>s.classList.remove('active'));
  if(id) document.getElementById(id).classList.add('active');
  if(id === 'scr-menu'){
    document.getElementById('menu-stats').textContent =
      'Матчей: ' + save.stats.matches + ' • Побед: ' + save.stats.wins + ' • Убийств: ' + save.stats.kills;
  }
}
function rollRarity(){
  let r = Math.random()*100;
  for(let i=0;i<RARITY.length;i++){ r -= RARITY[i].w; if(r <= 0) return i; }
  return 0;
}
function genCaseItem(caseId){
  const rar = rollRarity();
  if(caseId==='knife' || (caseId==='mixed' && Math.random()<0.25)){
    const model = pick(Object.keys(KNIVES));
    const color = pick(SKIN_COLORS);
    return { uid:0, kind:'knife', model, color,
      name: KNIVES[model].name + ' | ' + pick(['Градиент','Ультрафиолет','Допплер','Тигр','Кровавый','Неон']),
      rarity: Math.max(4, rar) };
  }
  if(caseId==='glove' || (caseId==='mixed' && Math.random()<0.35)){
    const gs = pick(GLOVE_SETS);
    return { uid:0, kind:'gloves', color: gs.color,
      name:'Перчатки | ' + gs.name, rarity: Math.max(1, rar-1) };
  }
  const wk = pick(Object.keys(WEAPON_SKIN_NAMES));
  return { uid:0, kind:'skin', weapon: wk, color: pick(SKIN_COLORS),
    name: WEAPONS[wk].name + ' | ' + pick(WEAPON_SKIN_NAMES[wk]), rarity: rar };
}
let lastCaseId = null, lastItem = null;
function openCase(caseId){
  audioInit(); SFX.buy();
  lastCaseId = caseId;
  lastItem = genCaseItem(caseId);
  const ov = document.getElementById('case-overlay');
  ov.classList.add('active');
  const card = document.getElementById('case-result-card');
  card.style.animation = 'none'; void card.offsetWidth; card.style.animation = '';
  const icon = document.getElementById('case-result-icon');
  icon.textContent = lastItem.kind==='knife' ? KNIFE_ICONS[lastItem.model] : lastItem.kind==='gloves' ? '🧤' : '🔫';
  document.getElementById('case-result-name').textContent = lastItem.name;
  const rEl = document.getElementById('case-result-rarity');
  rEl.textContent = RARITY[lastItem.rarity].n;
  rEl.style.color = RARITY[lastItem.rarity].c;
  card.style.borderColor = RARITY[lastItem.rarity].c;
  const hex = '#' + lastItem.color.toString(16).padStart(6,'0');
  icon.style.color = hex;
  icon.style.textShadow = '0 0 24px ' + hex;
}
function takeItem(){
  if(lastItem){
    lastItem.uid = save.nextUid++;
    save.inv.push(lastItem);
    persist();
    lastItem = null;
  }
  document.getElementById('case-overlay').classList.remove('active');
  SFX.click();
}
const KIND_ICON = (it)=> it.kind==='knife' ? KNIFE_ICONS[it.model] : it.kind==='gloves' ? '🧤' : '🔫';
function renderInventory(){
  const grid = document.getElementById('inv-grid');
  grid.innerHTML = '';
  for(const it of save.inv){
    const div = document.createElement('div');
    div.className = 'inv-item';
    const eq = (it.kind==='knife' && save.equipped.knifeUid===it.uid) ||
               (it.kind==='gloves' && save.glovesColor===it.color) ||
               (it.kind==='skin' && save.skins[it.weapon]===it.color);
    if(eq) div.classList.add('equipped');
    div.innerHTML = '<div class="inv-icon">' + KIND_ICON(it) + '</div>' +
      '<div>' + it.name + '</div>' +
      '<div class="rarity" style="color:' + RARITY[it.rarity].c + '">' + RARITY[it.rarity].n + '</div>' +
      (eq ? '<div style="color:#f5c542;font-size:10px;margin-top:3px;">✔ ЭКИПИРОВАНО</div>' : '');
    div.addEventListener('click', ()=>{
      if(it.kind==='knife') save.equipped.knifeUid = it.uid;
      else if(it.kind==='gloves') save.glovesColor = it.color;
      else save.skins[it.weapon] = it.color;
      persist(); renderInventory(); SFX.click();
      refreshLoadoutSelects();
    });
    grid.appendChild(div);
  }
  if(save.inv.length===0) grid.innerHTML = '<div style="color:#8fa3ba;grid-column:1/4;text-align:center;">Пусто — откройте кейсы!</div>';
}
function refreshLoadoutSelects(){
  const prim = document.getElementById('sel-primary');
  prim.innerHTML = '';
  ['ak47','m4a4','m4a1s','galil'].forEach(k=>{
    const o = document.createElement('option'); o.value = k; o.textContent = WEAPONS[k].name + (save.skins[k]!=null?' 🎨':''); prim.appendChild(o);
  });
  prim.value = save.equipped.primary;
  const sec = document.getElementById('sel-secondary');
  sec.innerHTML = '';
  ['usp','glock','deagle'].forEach(k=>{
    const o = document.createElement('option'); o.value = k; o.textContent = WEAPONS[k].name + (save.skins[k]!=null?' 🎨':''); sec.appendChild(o);
  });
  sec.value = save.equipped.secondary;
  const kn = document.getElementById('sel-knife');
  kn.innerHTML = '';
  save.inv.filter(i=>i.kind==='knife').forEach(it=>{
    const o = document.createElement('option'); o.value = it.uid; o.textContent = it.name; kn.appendChild(o);
  });
  kn.value = save.equipped.knifeUid;
}

/* ======================= ВВОД: КЛАВИАТУРА / МЫШЬ / ТАЧ ==================== */
const keys = {};
let joyActive = false, joyId = -1, joyOX = 0, joyOY = 0, joyVX = 0, joyVY = 0;
let lookId = -1, lookLX = 0, lookLY = 0;
window.isTouch = false;
let channel = null;
function bindHold(id, down, up){
  const el = document.getElementById(id);
  el.addEventListener('touchstart', e=>{ e.stopPropagation(); audioInit(); down(); }, {passive:true});
  el.addEventListener('touchend', e=>{ e.stopPropagation(); up(); }, {passive:true});
}
function setupInput(){
  addEventListener('keydown', e=>{
    keys[e.code] = true;
    if(!match) return;
    if(e.code==='KeyR') startReload();
    if(e.code==='KeyQ') cycleWeapon();
    if(e.code==='Digit1') switchSlot('knife');
    if(e.code==='Digit2') switchSlot('secondary');
    if(e.code==='Digit3') switchSlot('primary');
    if(e.code==='KeyB' && match.phase==='freeze'){
      document.getElementById('buy-menu').classList.toggle('active');
    }
  });
  addEventListener('keyup', e=>{ keys[e.code] = false; });
  const canvas = document.getElementById('game-canvas');
  canvas.addEventListener('click', ()=>{
    audioInit();
    if(match && !paused && document.pointerLockElement !== canvas && !window.isTouch) canvas.requestPointerLock();
  });
  document.addEventListener('mousemove', e=>{
    if(document.pointerLockElement === canvas && match && player.alive && !paused){
      const s = save.settings.sens * 0.0021;
      player.yaw -= e.movementX * s;
      player.pitch -= e.movementY * s * (save.settings.invert ? -1 : 1);
      player.pitch = THREE.MathUtils.clamp(player.pitch, -1.45, 1.45);
      lookDX += e.movementX; lookDY += e.movementY;
    }
  });
  document.addEventListener('mousedown', ()=>{
    if(document.pointerLockElement === canvas){ fireHeld = true; firePressed = true; audioInit(); }
  });
  document.addEventListener('mouseup', ()=>{ fireHeld = false; });

  window.isTouch = matchMedia('(pointer:coarse)').matches;
  const hud = document.getElementById('hud');
  hud.addEventListener('touchstart', onTouchStart, { passive:false });
  hud.addEventListener('touchmove', onTouchMove, { passive:false });
  hud.addEventListener('touchend', onTouchEnd, { passive:false });
  hud.addEventListener('touchcancel', onTouchEnd, { passive:false });
  bindHold('btn-fire', ()=>{ fireHeld = true; firePressed = true; }, ()=>{ fireHeld = false; });
  bindHold('btn-plant', ()=>{ channel = 'plant'; }, ()=>{ channel = null; player.plantT = 0; });
  bindHold('btn-defuse', ()=>{ channel = 'defuse'; }, ()=>{ channel = null; player.defuseT = 0; });
  document.getElementById('btn-reload').addEventListener('touchstart', e=>{ e.stopPropagation(); startReload(); }, {passive:true});
  document.getElementById('btn-jump').addEventListener('touchstart', e=>{ e.stopPropagation(); doJump(); }, {passive:true});
  document.getElementById('btn-swap').addEventListener('touchstart', e=>{ e.stopPropagation(); cycleWeapon(); }, {passive:true});
  document.getElementById('btn-knife').addEventListener('touchstart', e=>{ e.stopPropagation(); switchSlot('knife'); }, {passive:true});
}
function onTouchStart(e){
  e.preventDefault(); audioInit();
  if(!match) return;
  for(const t of e.changedTouches){
    if(t.target.closest && t.target.closest('.tbtn')) continue;
    if(t.clientX < innerWidth*0.45 && joyId === -1){
      joyId = t.identifier; joyActive = true; joyOX = t.clientX; joyOY = t.clientY; joyVX = 0; joyVY = 0;
      const jb = document.getElementById('joy-base');
      jb.style.display = 'block';
      jb.style.left = (joyOX-60)+'px'; jb.style.top = (joyOY-60)+'px';
    } else if(lookId === -1){
      lookId = t.identifier; lookLX = t.clientX; lookLY = t.clientY;
    }
  }
}
function onTouchMove(e){
  e.preventDefault();
  for(const t of e.changedTouches){
    if(t.identifier === joyId){
      let dx = t.clientX - joyOX, dy = t.clientY - joyOY;
      const len = Math.hypot(dx,dy);
      if(len > 48){ dx = dx/len*48; dy = dy/len*48; }
      joyVX = dx/48; joyVY = dy/48;
      document.getElementById('joy-knob').style.left = (34+dx)+'px';
      document.getElementById('joy-knob').style.top = (34+dy)+'px';
    } else if(t.identifier === lookId){
      const s = save.settings.sens * 0.006;
      const dx = t.clientX - lookLX, dy = t.clientY - lookLY;
      lookLX = t.clientX; lookLY = t.clientY;
      player.yaw -= dx * s;
      player.pitch -= dy * s * (save.settings.invert ? -1 : 1);
      player.pitch = THREE.MathUtils.clamp(player.pitch, -1.45, 1.45);
      lookDX += dx; lookDY += dy;
    }
  }
}
function onTouchEnd(e){
  e.preventDefault();
  for(const t of e.changedTouches){
    if(t.identifier === joyId){
      joyId = -1; joyActive = false; joyVX = 0; joyVY = 0;
      document.getElementById('joy-base').style.display = 'none';
      document.getElementById('joy-knob').style.left = '34px';
      document.getElementById('joy-knob').style.top = '34px';
    }
    if(t.identifier === lookId) lookId = -1;
  }
}
function doJump(){
  if(player.alive && player.feetY <= 0.01 && match && match.phase==='live'){
    player.velY = 7.5;
  }
}
function readMoveInput(){
  let mx = 0, mz = 0;
  if(keys['KeyW'] || keys['ArrowUp']) mz -= 1;
  if(keys['KeyS'] || keys['ArrowDown']) mz += 1;
  if(keys['KeyA'] || keys['ArrowLeft']) mx -= 1;
  if(keys['KeyD'] || keys['ArrowRight']) mx += 1;
  if(joyActive){ mx += joyVX; mz += joyVY; }
  const l = Math.hypot(mx, mz);
  if(l > 1){ mx/=l; mz/=l; }
  const s = Math.sin(player.yaw), c = Math.cos(player.yaw);
  const wx = mx*c - mz*s;
  const wz = -mx*s - mz*c;
  return { x: wx, z: wz, active: l > 0.12 };
}

/* ============================ 15. ИГРОВОЙ ЦИКЛ =========================== */
let lastT = performance.now();
function updateGame(dt){
  if(paused) return;
  const now = performance.now()/1000;
  if(match.phase==='freeze'){
    match.freezeT -= dt;
    if(match.freezeT <= 0) beginLive();
  } else if(match.phase==='live'){
    match.roundT -= dt;
    if(match.roundT <= 0 && bomb.state!=='planted') endRound('CT', 'Время вышло');
  } else if(match.phase==='end'){
    match.endT -= dt;
    if(match.endT <= 0){ nextRoundOrEnd(); return; }
  }
  updateBomb(dt);
  if(player.alive){
    const mv = readMoveInput();
    const knifeOut = player.slot==='knife';
    const spd = (knifeOut ? 6 : 5.2) * (mv.active ? 1 : 0);
    moveSpeed = spd;
    if(mv.active){
      const r = collideMove(player.x, player.z, 0.35, player.x + mv.x*spd*dt, player.z + mv.z*spd*dt);
      player.x = r.x; player.z = r.z;
    }
    player.velY -= 22*dt;
    player.feetY += player.velY*dt;
    if(player.feetY <= 0){ player.feetY = 0; player.velY = 0; }
    updateChannel(dt);
    if(player.reloading && now >= player.reloadEnd) finishReload();
    if(player.meleeT >= 0){ player.meleeT -= dt; if(player.meleeT < 0) resolveMelee(); }
    player.fireCd -= dt;
    const key = player.weapons[player.slot];
    if(fireHeld && (player.slot==='knife' || (key && WEAPONS[key].auto) || firePressed)) tryFire();
    firePressed = false;
  } else {
    moveSpeed = 0;
  }
  const bdt = dt * speedMul;
  for(const b of bots) botUpdate(b, bdt);
  updateDeadBots(dt);
  if(player.alive){
    camera.position.set(player.x, player.feetY + EYE, player.z);
    camera.rotation.order = 'YXZ';
    camera.rotation.y = player.yaw + Math.PI;
    camera.rotation.x = player.pitch;
  } else {
    const mate = bots.find(b=>b.alive && b.team===player.team);
    if(mate){
      camera.position.lerp(new THREE.Vector3(mate.x, 2.4, mate.z), Math.min(1, dt*3));
      camera.rotation.y = mate.yaw + Math.PI; camera.rotation.x = -0.3;
    }
  }
  if(shakeCam > 0){
    shakeCam = Math.max(0, shakeCam - dt*2.5);
    camera.rotation.x += rand(-1,1)*shakeCam*0.02;
    camera.rotation.y += rand(-1,1)*shakeCam*0.02;
  }
  updateEffects(dt);
  updateTimerHUD();
  updateHUD();
  drawRadar();
  updateContextButtons();
  lookDX = 0; lookDY = 0;
}
function updateChannel(dt){
  const el = document.getElementById('progress-wrap');
  const fill = document.getElementById('progress-fill');
  let show = false;
  if(channel==='plant' && player.hasBomb && bomb.state!=='planted'){
    const dA = Math.hypot(player.x-siteA.x, player.z-siteA.z);
    const dB = Math.hypot(player.x-siteB.x, player.z-siteB.z);
    const site = dA < dB ? 'A' : 'B';
    if(Math.min(dA,dB) < 3.8){
      player.plantT += dt;
      show = true;
      fill.style.width = Math.min(100, player.plantT/3*100) + '%';
      if(player.plantT >= 3){
        player.hasBomb = false;
        plantBomb(player.x, player.z, site);
        player.plantT = 0; channel = null;
      }
    } else player.plantT = 0;
  } else if(channel==='defuse' && bomb.state==='planted'){
    if(Math.hypot(player.x-bomb.x, player.z-bomb.z) < 2.2){
      player.defuseT += dt;
      show = true;
      fill.style.width = Math.min(100, player.defuseT/5*100) + '%';
      if(player.defuseT >= 5){ player.defuseT = 0; channel = null; defuseBomb(); }
    } else player.defuseT = 0;
  } else { player.plantT = 0; player.defuseT = 0; }
  el.style.display = show ? 'block' : 'none';
}
function updateContextButtons(){
  const plantBtn = document.getElementById('btn-plant');
  const defBtn = document.getElementById('btn-defuse');
  const prompt = document.getElementById('prompt');
  let pText = '';
  if(match && match.phase==='live' && player.alive){
    if(player.hasBomb && bomb.state!=='planted'){
      const d = Math.min(Math.hypot(player.x-siteA.x,player.z-siteA.z), Math.hypot(player.x-siteB.x,player.z-siteB.z));
      plantBtn.style.display = d < 3.8 ? 'flex' : 'none';
      if(d < 3.8) pText = '💣 Удерживайте «ЗАЛОЖИТЬ», чтобы установить бомбу';
    } else plantBtn.style.display = 'none';
    if(player.team==='CT' && bomb.state==='planted'){
      const d = Math.hypot(player.x-bomb.x, player.z-bomb.z);
      defBtn.style.display = d < 2.2 ? 'flex' : 'none';
      if(d < 2.2) pText = '🛠 Удерживайте «ОБЕЗВРЕДИТЬ» (5 сек)';
    } else defBtn.style.display = 'none';
  } else { plantBtn.style.display = 'none'; defBtn.style.display = 'none'; }
  prompt.style.display = pText ? 'block' : 'none';
  prompt.textContent = pText;
}
function updateEffects(dt){
  for(let i=tracers.length-1;i>=0;i--){
    const t = tracers[i];
    t.life -= dt;
    t.l.material.opacity = Math.max(0, t.life/0.07);
    if(t.life <= 0){ scene.remove(t.l); tracers.splice(i,1); }
  }
  for(let i=casings.length-1;i>=0;i--){
    const c = casings[i];
    c.life -= dt;
    c.vy -= 12*dt;
    c.m.position.x += c.vx*dt; c.m.position.y += c.vy*dt; c.m.position.z += c.vz*dt;
    c.m.rotation.x += dt*8; c.m.rotation.z += dt*6;
    if(c.m.position.y < 0.02){ c.m.position.y = 0.02; c.vy = 0; c.vx *= 0.8; c.vz *= 0.8; }
    if(c.life <= 0){ scene.remove(c.m); casings.splice(i,1); }
  }
  for(let i=sparks.length-1;i>=0;i--){
    const s = sparks[i];
    s.life -= dt;
    s.vy -= 9*dt;
    s.m.position.x += s.vx*dt; s.m.position.y += s.vy*dt; s.m.position.z += s.vz*dt;
    if(s.life <= 0 || s.m.position.y < 0){ scene.remove(s.m); sparks.splice(i,1); }
  }
  if(VM.parts.flash && VM.parts.flash.material.opacity > 0){
    VM.parts.flash.material.opacity = Math.max(0, VM.parts.flash.material.opacity - dt*14);
    VM.parts.flash.rotation.z = Math.random()*Math.PI;
  }
  if(vmLight && vmLight.intensity > 0) vmLight.intensity = Math.max(0, vmLight.intensity - dt*18);
  const fl = document.getElementById('flash');
  if(parseFloat(fl.style.opacity || 0) > 0) fl.style.opacity = Math.max(0, parseFloat(fl.style.opacity) - dt*2.2);
}
function loop(now){
  requestAnimationFrame(loop);
  const dt = Math.min(0.05, (now - lastT)/1000);
  lastT = now;
  if(match){
    updateGame(dt);
    updateVM(dt, moveSpeed, lookDX, lookDY);
  } else {
    const t = now/1000;
    camera.position.set(Math.sin(t*0.08)*18, 14, Math.cos(t*0.08)*18);
    camera.lookAt(0, 0, 0);
    updateEffects(dt);
  }
  renderer.render(scene, camera);
}

/* ============================== ИНИЦИАЛИЗАЦИЯ ============================= */
function wireUI(){
  const on = (id, fn)=> document.getElementById(id).addEventListener('click', ()=>{ audioInit(); SFX.click(); fn(); });
  on('btn-play', ()=>{ refreshLoadoutSelects(); showScreen('scr-play'); });
  on('btn-shop', ()=> showScreen('scr-shop'));
  on('btn-inv', ()=>{ renderInventory(); showScreen('scr-inv'); });
  on('btn-set', ()=> showScreen('scr-set'));
  on('btn-back-play', ()=> showScreen('scr-menu'));
  on('btn-back-shop', ()=> showScreen('scr-menu'));
  on('btn-back-inv', ()=> showScreen('scr-menu'));
  on('btn-back-set', ()=> showScreen('scr-menu'));
  document.querySelectorAll('.team-btn').forEach(b=>{
    b.addEventListener('click', ()=>{
      audioInit(); SFX.click();
      chosenTeam = b.dataset.team;
      document.querySelectorAll('.team-btn').forEach(x=>x.style.outline='');
      b.style.outline = '3px solid #f5c542';
    });
  });
  on('btn-start', ()=>{
    save.equipped.primary = document.getElementById('sel-primary').value;
    save.equipped.secondary = document.getElementById('sel-secondary').value;
    save.equipped.knifeUid = parseInt(document.getElementById('sel-knife').value) || 1;
    persist();
    showScreen(null);
    document.getElementById('hud').classList.add('active');
    buildBombMesh();
    startMatch();
  });
  const shop = document.getElementById('shop-cases');
  Object.keys(CASES).forEach(id=>{
    const c = CASES[id];
    const div = document.createElement('div');
    div.className = 'case-card';
    div.innerHTML = '<div class="case-icon">' + c.icon + '</div><div class="case-name">' + c.name +
      '</div><div class="case-desc">' + c.desc + '</div><span class="case-free">БЕСПЛАТНО • ∞</span>';
    div.addEventListener('click', ()=> openCase(id));
    shop.appendChild(div);
  });
  on('btn-take', takeItem);
  on('btn-again', ()=>{ takeItem(); openCase(lastCaseId); });
  const sens = document.getElementById('rng-sens'), vol = document.getElementById('rng-vol'),
        fov = document.getElementById('rng-fov'), inv = document.getElementById('chk-invert');
  sens.value = save.settings.sens; vol.value = save.settings.vol;
  fov.value = save.settings.fov; inv.checked = save.settings.invert;
  const updLabels = ()=>{
    document.getElementById('val-sens').textContent = (+sens.value).toFixed(1);
    document.getElementById('val-vol').textContent = Math.round(vol.value*100) + '%';
    document.getElementById('val-fov').textContent = fov.value;
  };
  updLabels();
  sens.addEventListener('input', ()=>{ save.settings.sens = +sens.value; updLabels(); persist(); });
  vol.addEventListener('input', ()=>{ save.settings.vol = +vol.value; setVolume(+vol.value); updLabels(); persist(); });
  fov.addEventListener('input', ()=>{ save.settings.fov = +fov.value; camera.fov = +fov.value; camera.updateProjectionMatrix(); updLabels(); persist(); });
  inv.addEventListener('change', ()=>{ save.settings.invert = inv.checked; persist(); });
  on('btn-reset-save', ()=>{ if(confirm('Сбросить весь прогресс?')){ save = defaultSave(); persist(); location.reload(); } });
  on('btn-pause', ()=>{ paused = true; document.getElementById('pause-menu').style.display = 'flex'; });
  on('btn-resume', ()=>{ paused = false; document.getElementById('pause-menu').style.display = 'none'; });
  on('btn-quit', ()=>{
    paused = false; match = null; speedMul = 1;
    document.getElementById('pause-menu').style.display = 'none';
    document.getElementById('hud').classList.remove('active');
    hideBuyMenu();
    showScreen('scr-menu');
  });
  on('btn-skip', ()=>{ speedMul = 8; });
  on('btn-score-t', ()=>{
    const sb = document.getElementById('scoreboard');
    updateScoreboard();
    sb.classList.add('active');
    setTimeout(()=> sb.classList.remove('active'), 3500);
  });
  on('btn-close-buy', hideBuyMenu);
  on('btn-again-match', ()=>{
    document.getElementById('hud').classList.add('active');
    showScreen(null);
    startMatch();
  });
  on('btn-to-menu', ()=>{
    document.getElementById('hud').classList.remove('active');
    showScreen('scr-menu');
  });
  addEventListener('contextmenu', e=> e.preventDefault());
  document.addEventListener('visibilitychange', ()=>{
    if(document.hidden && match){ paused = true; document.getElementById('pause-menu').style.display = 'flex'; }
  });
}
function init(){
  buildWorld();
  vmLight = new THREE.PointLight(0xffcc88, 0, 2.5);
  vmLight.position.set(0.3, -0.2, -0.6);
  camera.add(vmLight);
  scene.add(camera);
  wireUI();
  setupInput();
  showScreen('scr-menu');
  requestAnimationFrame(loop);
}
init();
