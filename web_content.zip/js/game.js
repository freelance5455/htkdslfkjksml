"use strict";

const Game = (() => {
  const MIN_PLAYERS = 5;
  const MAX_PLAYERS = 20;
  const MAX_NAME_LENGTH = 14;
  const ALLOWED_DISCUSSION = [60, 120, 180, 300];
  const ALLOWED_VOTING = [30, 60, 90];
  const ALLOWED_COMPLEXITY = ["basic", "medium", "advanced"];
  const ALLOWED_REVEAL = ["reveal", "hide"];
  const ALLOWED_TIE = ["revote", "none"];
  const CORE_ROLES = ["mafia", "citizen"];
  const NEUTRAL_ROLES = ["lone_killer", "clown"];
  const PRIORITY_TOWN_ROLES = ["detective", "doctor"];
  const OTHER_TOWN_ROLES = ["guard", "informant", "mayor", "witch"];

  const state = { settings: null, match: null };

  /* ---------- أدوات عشوائية ---------- */
  function randomInt(max) {
    const cryptoObj = globalThis.crypto;
    if (cryptoObj && cryptoObj.getRandomValues) {
      const buffer = new Uint32Array(1);
      const limit = Math.floor(4294967296 / max) * max;
      do {
        cryptoObj.getRandomValues(buffer);
      } while (buffer[0] >= limit);
      return buffer[0] % max;
    }
    return Math.floor(Math.random() * max);
  }

  function shuffle(array) {
    const copy = array.slice();
    for (let i = copy.length - 1; i > 0; i--) {
      const j = randomInt(i + 1);
      [copy[i], copy[j]] = [copy[j], copy[i]];
    }
    return copy;
  }

  /* ---------- قواعد التوازن ---------- */
  function maxMafia(playerCount) {
    return Math.max(1, Math.floor(playerCount / 3));
  }

  function recommendedMafia(playerCount) {
    return Math.max(1, Math.min(maxMafia(playerCount), Math.round(playerCount / 4)));
  }

  function neutralCap(playerCount) {
    if (playerCount >= 10) return 2;
    if (playerCount >= 7) return 1;
    return 0;
  }

  /* ---------- الإعدادات ---------- */
  function createDefaultSettings() {
    const playerCount = 6;
    return {
      playerCount,
      names: Array.from({ length: playerCount }, (_, i) => `لاعب ${i + 1}`),
      mafiaCount: recommendedMafia(playerCount),
      enabledRoles: Roles.presetFor("basic"),
      timerEnabled: true,
      discussionSeconds: 180,
      votingSeconds: 60,
      complexity: "basic",
      revealRoleOnElimination: "reveal",
      tieRule: "revote",
    };
  }

  function validateSettings(settings) {
    const errors = [];
    const invalidNameIndexes = [];

    if (!settings || typeof settings !== "object") {
      return { valid: false, errors: ["إعدادات غير صالحة"], invalidNameIndexes };
    }

    const n = settings.playerCount;
    if (!Number.isInteger(n) || n < MIN_PLAYERS || n > MAX_PLAYERS) {
      errors.push(`عدد اللاعبين يجب أن يكون بين ${MIN_PLAYERS} و ${MAX_PLAYERS}`);
    }

    if (!Array.isArray(settings.names) || settings.names.length !== n) {
      errors.push("عدد الأسماء لا يطابق عدد اللاعبين");
    } else {
      const seen = new Map();
      settings.names.forEach((raw, index) => {
        const name = String(raw).trim();
        if (name === "") {
          errors.push(`اسم اللاعب ${index + 1} فارغ`);
          invalidNameIndexes.push(index);
          return;
        }
        if (name.length > MAX_NAME_LENGTH) {
          errors.push(`اسم اللاعب ${index + 1} أطول من ${MAX_NAME_LENGTH} حرفًا`);
          invalidNameIndexes.push(index);
        }
        const key = name.toLowerCase();
        if (seen.has(key)) {
          errors.push(`الاسم "${name}" مكرر`);
          invalidNameIndexes.push(index, seen.get(key));
        } else {
          seen.set(key, index);
        }
      });
    }

    if (Number.isInteger(n)) {
      const max = maxMafia(n);
      if (!Number.isInteger(settings.mafiaCount) || settings.mafiaCount < 1) {
        errors.push("يجب وجود فرد مافيا واحد على الأقل");
      } else if (settings.mafiaCount > max) {
        errors.push(`فريق غير متوازن: الحد الأقصى للمافيا ${max} لـ ${n} لاعبين`);
      }
    }

    if (!Array.isArray(settings.enabledRoles) || settings.enabledRoles.some((id) => !Roles.get(id))) {
      errors.push("قائمة الأدوار غير صالحة");
    }

    if (!ALLOWED_DISCUSSION.includes(settings.discussionSeconds)) errors.push("مدة النقاش غير صالحة");
    if (!ALLOWED_VOTING.includes(settings.votingSeconds)) errors.push("مدة التصويت غير صالحة");
    if (!ALLOWED_COMPLEXITY.includes(settings.complexity)) errors.push("مستوى التعقيد غير صالح");
    if (!ALLOWED_REVEAL.includes(settings.revealRoleOnElimination)) errors.push("قاعدة كشف الدور غير صالحة");
    if (!ALLOWED_TIE.includes(settings.tieRule)) errors.push("قاعدة التعادل غير صالحة");

    return {
      valid: errors.length === 0,
      errors,
      invalidNameIndexes: [...new Set(invalidNameIndexes)],
    };
  }

  function setSettings(settings) {
    const check = validateSettings(settings);
    if (!check.valid) return check;
    const copy = JSON.parse(JSON.stringify(settings));
    copy.names = copy.names.map((name) => String(name).trim());
    copy.enabledRoles = [...new Set([...CORE_ROLES, ...copy.enabledRoles])];
    state.settings = copy;
    return check;
  }

  function getSettings() {
    return state.settings ? JSON.parse(JSON.stringify(state.settings)) : null;
  }

  /* ---------- توزيع الأدوار ---------- */
  function assignRoles(settings) {
    const n = settings.playerCount;
    const enabled = new Set([...CORE_ROLES, ...settings.enabledRoles]);
    const skipped = [];
    const pool = [];

    // فريق المافيا
    let mafiaSlots = settings.mafiaCount;
    if (enabled.has("lawyer")) {
      if (mafiaSlots >= 2) {
        pool.push("lawyer");
        mafiaSlots -= 1;
      } else {
        skipped.push({ id: "lawyer", reason: "يحتاج مافيا اثنين على الأقل" });
      }
    }
    for (let i = 0; i < mafiaSlots; i++) pool.push("mafia");

    // فريق المواطنين والمستقلين
    const townSlots = n - settings.mafiaCount;
    const capacity = townSlots - 1; // نترك مكانًا لمواطن عادي على الأقل
    let specials = 0;

    let neutralsPicked = 0;
    shuffle(NEUTRAL_ROLES.filter((id) => enabled.has(id))).forEach((id) => {
      if (neutralsPicked < neutralCap(n) && specials < capacity) {
        pool.push(id);
        neutralsPicked++;
        specials++;
      } else {
        skipped.push({ id, reason: "لا يناسب عدد اللاعبين" });
      }
    });

    const townOrder = [
      ...PRIORITY_TOWN_ROLES.filter((id) => enabled.has(id)),
      ...shuffle(OTHER_TOWN_ROLES.filter((id) => enabled.has(id))),
    ];
    townOrder.forEach((id) => {
      if (specials < capacity) {
        pool.push(id);
        specials++;
      } else {
        skipped.push({ id, reason: "لا يتسع له الفريق" });
      }
    });

    while (pool.length < n) pool.push("citizen");

    if (pool.length !== n) {
      throw new Error("خطأ داخلي: عدد الأدوار لا يطابق عدد اللاعبين");
    }

    const shuffled = shuffle(pool);
    const players = settings.names.map((name, index) => ({
      id: index + 1,
      name: String(name).trim(),
      roleId: shuffled[index],
      alive: true,
    }));

    return { players, skipped };
  }

  /* ---------- بدء اللعبة ---------- */
  function startNewGame() {
    if (!state.settings) {
      return { ok: false, error: "لا توجد إعدادات معتمدة" };
    }
    const { players, skipped } = assignRoles(state.settings);
    state.match = {
      players,
      skipped,
      round: 0,
      phase: "reveal",
      revealIndex: 0,
    };
    return { ok: true, skipped: skipped.map((item) => ({ ...item })) };
  }
  
    // حالة كشف الأدوار: من دور اللاعب الآن؟
  function getRevealState() {
    if (!state.match) return null;
    const { players, revealIndex } = state.match;
    const done = revealIndex >= players.length;
    const current = done ? null : players[revealIndex];
    return {
      index: revealIndex,
      total: players.length,
      done,
      player: current ? { id: current.id, name: current.name } : null,
    };
  }

  // الانتقال للاعب التالي في الكشف
  function advanceReveal() {
    if (!state.match) return null;
    if (state.match.revealIndex < state.match.players.length) {
      state.match.revealIndex += 1;
    }
    if (state.match.revealIndex >= state.match.players.length) {
      state.match.phase = "night";
    }
    return getRevealState();
  }

  // أسماء شركاء فريق المافيا (تُعرض لأعضاء المافيا فقط)
  function getMafiaPartnersOf(playerId) {
    if (!state.match) return [];
    const me = state.match.players.find((p) => p.id === playerId);
    if (!me || Roles.get(me.roleId).team !== "mafia") return [];
    return state.match.players
      .filter((p) => p.id !== playerId && Roles.get(p.roleId).team === "mafia")
      .map((p) => p.name);
  }
    /* ---------- الليل ---------- */
  function ensureMemory(match) {
    if (!match.memory) {
      match.memory = {
        doctorSelfUsed: false,
        informantUsed: false,
        witchUsed: false,
        guardLastTarget: null,
        silenced: [],
        jammedNext: [],
      };
    }
    if (!match.log) match.log = [];
    return match.memory;
  }

  function aliveWithTeams(match) {
    return match.players
      .filter((p) => p.alive)
      .map((p) => ({ id: p.id, name: p.name, team: Roles.get(p.roleId).team }));
  }

  function buildNightPrompt(match) {
    const night = match.night;
    const actor = match.players.find((p) => p.id === night.order[night.index]);
    const role = Roles.get(actor.roleId);
    const turn = Night.describeTurn(role, {
      player: actor,
      alive: aliveWithTeams(match),
      memory: match.memory,
      jammed: night.jammed.includes(actor.id),
    });
    return { actor, role, turn };
  }

  function startNight() {
    const match = state.match;
    if (!match) return { ok: false, error: "لا توجد لعبة" };
    if (match.phase !== "night") return { ok: false, error: "ليس وقت الليل" };
    if (match.night && match.night.phase !== "done") {
      return { ok: false, error: "الليل قيد التنفيذ" };
    }
    const memory = ensureMemory(match);
    match.round += 1;
    const alive = match.players.filter((p) => p.alive);
    match.night = Night.create(alive.map((p) => p.id), match.round, shuffle);
    match.night.jammed = memory.jammedNext.slice();
    memory.jammedNext = [];
    return { ok: true, number: match.round, aliveCount: alive.length };
  }

  // من دوره الآن؟ (معلومة عامة: الاسم فقط)
  function getNightTurn() {
    const match = state.match;
    if (!match || !match.night) return null;
    const night = match.night;
    const total = night.order.length;
    const done = night.index >= total;
    const player = done ? null : match.players.find((p) => p.id === night.order[night.index]);
    return {
      number: night.number,
      index: night.index,
      total,
      phase: night.phase,
      done,
      player: player ? { id: player.id, name: player.name } : null,
    };
  }

  // اللاعب ضغط "جاهز": نعرض له دوره
  function beginNightTurn() {
    const match = state.match;
    if (!match || !match.night) return { ok: false, error: "لا يوجد ليل نشط" };
    const night = match.night;
    if (night.index >= night.order.length) return { ok: false, error: "انتهت الأدوار" };
    if (!Night.canTransition(night.phase, "action")) {
      return { ok: false, error: "حالة الليل غير صحيحة" };
    }
    night.phase = "action";
    const { role, turn } = buildNightPrompt(match);
    return {
      ok: true,
      role: { id: role.id, name: role.name, icon: role.icon, color: role.color },
      turn,
    };
  }

  // تسجيل اختيار اللاعب (targetId أو null للتخطي)
  function submitNightAction(targetId) {
    const match = state.match;
    if (!match || !match.night) return { ok: false, error: "لا يوجد ليل نشط" };
    const night = match.night;
    if (night.phase !== "action") return { ok: false, error: "حالة الليل غير صحيحة" };

    const { actor, turn } = buildNightPrompt(match);
    const skip = targetId === null || targetId === undefined;

    if (turn.kind !== "jammed") {
      if (skip && !turn.allowSkip) return { ok: false, error: "اختر هدفًا أولًا" };
      if (!skip && !turn.targets.some((t) => t.id === targetId)) {
        return { ok: false, error: "هدف غير صالح" };
      }
    }

    const memory = match.memory;
    const target = turn.kind === "jammed" || skip ? null : targetId;
    let info = null;

    if (target !== null) {
      const targetPlayer = match.players.find((p) => p.id === target);
      const targetRole = Roles.get(targetPlayer.roleId);
      if (turn.kind === "investigate") {
        info = {
          title: targetPlayer.name,
          text: Night.isSuspicious(targetRole)
            ? "🔴 مشبوه — تصرفاته تدل على المافيا"
            : "🟢 بريء — لا شيء يدعو للشك",
        };
      } else if (turn.kind === "inform") {
        memory.informantUsed = true;
        info = { title: targetPlayer.name, text: `دوره: ${targetRole.icon} ${targetRole.name}` };
      } else if (turn.kind === "silence") {
        memory.witchUsed = true;
      } else if (turn.kind === "protect" && target === actor.id) {
        memory.doctorSelfUsed = true;
      }
    }

    night.actions[actor.id] = { actorId: actor.id, roleId: actor.roleId, kind: turn.kind, target };
    night.phase = info ? "result" : "transition";
    return { ok: true, info };
  }

  function finishNightResult() {
    const match = state.match;
    if (!match || !match.night) return { ok: false, error: "لا يوجد ليل نشط" };
    if (!Night.canTransition(match.night.phase, "transition")) {
      return { ok: false, error: "حالة الليل غير صحيحة" };
    }
    match.night.phase = "transition";
    return { ok: true };
  }

  // الانتقال للاعب التالي أو لحسم الليل
  function advanceNightTurn() {
    const match = state.match;
    if (!match || !match.night) return { ok: false, error: "لا يوجد ليل نشط" };
    const night = match.night;
    const nextIndex = night.index + 1;
    const finished = nextIndex >= night.order.length;
    const to = finished ? "resolving" : "handover";
    if (!Night.canTransition(night.phase, to)) {
      return { ok: false, error: "حالة الليل غير صحيحة" };
    }
    night.index = nextIndex;
    night.phase = to;
    return { ok: true, finished };
  }

  // حسم الليل وتطبيق النتائج
  function resolveNight() {
    const match = state.match;
    if (!match || !match.night) return { ok: false, error: "لا يوجد ليل نشط" };
    const night = match.night;
    if (night.phase !== "resolving") return { ok: false, error: "الليل لم ينتهِ بعد" };

    const memory = match.memory;
    const raw = Night.resolve(night, randomInt);

    raw.deaths.forEach((id) => {
      const player = match.players.find((p) => p.id === id);
      if (player) player.alive = false;
    });

    memory.guardLastTarget = raw.guardTarget;
    memory.silenced = raw.silencedId !== null ? [raw.silencedId] : [];
    memory.jammedNext = raw.silencedId !== null ? [raw.silencedId] : [];

    const deaths = raw.deaths.map((id) => {
      const player = match.players.find((p) => p.id === id);
      return { id: player.id, name: player.name, roleId: player.roleId };
    });

    if (deaths.length === 0) {
      match.log.push({ round: night.number, text: `مرّت الليلة ${night.number} بسلام` });
    } else {
      deaths.forEach((d) => {
        match.log.push({ round: night.number, text: `قُتل ${d.name} في الليلة ${night.number}` });
      });
    }

    night.outcome = { number: night.number, deaths };
    night.phase = "done";
    match.phase = "dawn";
     checkWin(match);
    return { ok: true, number: night.number, deaths: deaths.map((d) => ({ ...d })) };
  }

  // سجل الأحداث العام (بلا أي معلومة سرية)
  function getPublicLog() {
    return state.match && state.match.log ? state.match.log.map((e) => ({ ...e })) : [];
  }
  
    /* ---------- النهار والتصويت ---------- */
  function playerById(match, id) {
    return match.players.find((p) => p.id === id);
  }

  function buildVotePrompt(match) {
    const voting = match.day.voting;
    const voter = playerById(match, voting.order[voting.index]);
    const candidates = voting.candidates.map((id) => {
      const p = playerById(match, id);
      return { id: p.id, name: p.name };
    });
    const turn = Voting.describeVote({
      voter,
      candidates,
      silenced: match.memory.silenced.includes(voter.id),
    });
    return { voter, turn };
  }

  function startDay() {
    const match = state.match;
    if (!match) return { ok: false, error: "لا توجد لعبة" };
    if (match.phase !== "dawn") return { ok: false, error: "ليس وقت النهار" };
    ensureMemory(match);
    match.phase = "day";
    match.day = {
      number: match.round,
      phase: "discussion",
      voting: null,
      nominees: [],
      revoteDone: false,
      outcome: null,
    };
    const alive = match.players.filter((p) => p.alive).map((p) => ({ id: p.id, name: p.name }));
    return { ok: true, number: match.round, alive };
  }

  function getDayInfo() {
    const match = state.match;
    if (!match || !match.day) return null;
    return {
      number: match.day.number,
      phase: match.day.phase,
      alive: match.players.filter((p) => p.alive).map((p) => ({ id: p.id, name: p.name })),
    };
  }

  function endDiscussion() {
    const match = state.match;
    if (!match || !match.day) return { ok: false, error: "لا يوجد نهار نشط" };
    if (!Voting.canTransition(match.day.phase, "nomination")) {
      return { ok: false, error: "حالة النهار غير صحيحة" };
    }
    match.day.phase = "nomination";
    return { ok: true };
  }

  function setNominees(ids) {
    const match = state.match;
    if (!match || !match.day) return { ok: false, error: "لا يوجد نهار نشط" };
    const day = match.day;
    if (!Voting.canTransition(day.phase, "handover")) {
      return { ok: false, error: "حالة النهار غير صحيحة" };
    }
    if (!Array.isArray(ids)) return { ok: false, error: "قائمة المرشحين غير صالحة" };
    const unique = [...new Set(ids)];
    const aliveIds = match.players.filter((p) => p.alive).map((p) => p.id);
    if (unique.length < 2) return { ok: false, error: "رشّح لاعبين اثنين على الأقل" };
    if (unique.some((id) => !aliveIds.includes(id))) {
      return { ok: false, error: "مرشح غير صالح" };
    }
    day.nominees = unique;
    day.voting = Voting.create(aliveIds, unique, 1, shuffle);
    day.phase = "handover";
    return { ok: true, voters: aliveIds.length };
  }

  function getVoteTurn() {
    const match = state.match;
    if (!match || !match.day || !match.day.voting) return null;
    const voting = match.day.voting;
    const total = voting.order.length;
    const done = voting.index >= total;
    const player = done ? null : playerById(match, voting.order[voting.index]);
    return {
      number: match.day.number,
      round: voting.round,
      index: voting.index,
      total,
      phase: match.day.phase,
      done,
      player: player ? { id: player.id, name: player.name } : null,
    };
  }

  function beginVoteTurn() {
    const match = state.match;
    if (!match || !match.day || !match.day.voting) return { ok: false, error: "لا يوجد تصويت نشط" };
    const day = match.day;
    if (day.voting.index >= day.voting.order.length) return { ok: false, error: "انتهى التصويت" };
    if (!Voting.canTransition(day.phase, "action")) {
      return { ok: false, error: "حالة التصويت غير صحيحة" };
    }
    day.phase = "action";
    const { turn } = buildVotePrompt(match);
    return { ok: true, round: day.voting.round, turn };
  }

  function submitVote(targetId) {
    const match = state.match;
    if (!match || !match.day || !match.day.voting) return { ok: false, error: "لا يوجد تصويت نشط" };
    const day = match.day;
    if (day.phase !== "action") return { ok: false, error: "حالة التصويت غير صحيحة" };

    const { voter, turn } = buildVotePrompt(match);
    const abstain = targetId === null || targetId === undefined;

    if (turn.kind === "vote" && !abstain && !turn.targets.some((t) => t.id === targetId)) {
      return { ok: false, error: "هدف غير صالح" };
    }

    const silenced = turn.kind === "silenced";
    const weight = silenced ? 0 : voter.roleId === "mayor" ? 2 : 1;
    day.voting.votes.push({
      voterId: voter.id,
      target: silenced || abstain ? null : targetId,
      weight,
    });
    day.phase = "transition";
    return { ok: true };
  }

  function advanceVoteTurn() {
    const match = state.match;
    if (!match || !match.day || !match.day.voting) return { ok: false, error: "لا يوجد تصويت نشط" };
    const day = match.day;
    const nextIndex = day.voting.index + 1;
    const finished = nextIndex >= day.voting.order.length;
    const to = finished ? "tally" : "handover";
    if (!Voting.canTransition(day.phase, to)) {
      return { ok: false, error: "حالة التصويت غير صحيحة" };
    }
    day.voting.index = nextIndex;
    day.phase = to;
    return { ok: true, finished };
  }

  function tallyVotes() {
    const match = state.match;
    if (!match || !match.day || !match.day.voting) return { ok: false, error: "لا يوجد تصويت نشط" };
    const day = match.day;
    if (day.phase !== "tally") return { ok: false, error: "التصويت لم ينتهِ بعد" };

    const voting = day.voting;
    const memory = match.memory;
    const tieRule = (state.settings && state.settings.tieRule) || "revote";
    const t = Voting.tally(voting.votes, voting.candidates);
    const action = Voting.decide(t, { tieRule, revoteDone: day.revoteDone });

    const counts = voting.candidates
      .map((id) => ({ id, name: playerById(match, id).name, votes: t.counts[id] }))
      .sort((a, b) => b.votes - a.votes);

    if (action === "revote") {
      day.revoteDone = true;
      day.voting = Voting.create(voting.order, t.top, 2, shuffle);
      day.phase = "handover";
      return {
        ok: true,
        status: "revote",
        counts,
        tied: t.top.map((id) => playerById(match, id).name),
      };
    }

    let outcome = {
      status: "none",
      reason: t.top.length === 0 ? "no_votes" : "tie",
      eliminated: null,
    };

    if (action === "eliminate") {
      const player = playerById(match, t.top[0]);
      const lawyerAlive = match.players.some((p) => p.alive && p.roleId === "lawyer");
      if (player.roleId === "mafia" && lawyerAlive && !memory.lawyerUsed) {
        memory.lawyerUsed = true;
        outcome = { status: "none", reason: "protected", eliminated: null };
        match.log.push({ round: day.number, text: `لم يُستبعد أحد في نهار اليوم ${day.number}` });
      } else {
        player.alive = false;
        outcome = {
          status: "eliminated",
          reason: null,
          eliminated: { id: player.id, name: player.name, roleId: player.roleId },
        };
        if (player.roleId === "clown") {
          match.flags = match.flags || {};
          match.flags.clownVotedOut = player.id;
        }
        match.log.push({ round: day.number, text: `استُبعد ${player.name} بالتصويت في اليوم ${day.number}` });
      }
    } else {
      match.log.push({ round: day.number, text: `انتهى تصويت اليوم ${day.number} دون استبعاد` });
    }
    checkWin(match);
    day.outcome = outcome;
    day.phase = "result";
    return {
      ok: true,
      status: outcome.status,
      reason: outcome.reason,
      counts,
      eliminated: outcome.eliminated ? { ...outcome.eliminated } : null,
    };
  }

  // إنهاء النهار والعودة إلى الليل
  function finishDay() {
    const match = state.match;
    if (!match || !match.day) return { ok: false, error: "لا يوجد نهار نشط" };
    if (!Voting.canTransition(match.day.phase, "done")) {
      return { ok: false, error: "حالة النهار غير صحيحة" };
    }
    if (match.result) return { ok: false, error: "انتهت اللعبة" };
    match.day.phase = "done";
    match.phase = "night";
    if (match.memory) match.memory.silenced = [];
    return { ok: true };
  }

  /* ---------- الفوز ولوحة الإدارة ---------- */
  function checkWin(match) {
    if (match.result) return match.result;
    const res = Win.check(match.players, match.flags || {});
    if (!res.over) return null;
    match.result = {
      winner: res.winner,
      winnerIds: res.winnerIds,
      title: res.title,
      text: res.text,
      forced: false,
    };
    match.phase = "over";
    if (!match.log) match.log = [];
    match.log.push({ round: match.round, text: `انتهت اللعبة: ${res.title}` });
    return match.result;
  }

  // النتيجة النهائية مع كشف كل الأدوار (تُعاد فقط بعد انتهاء اللعبة)
  function getResult() {
    const match = state.match;
    if (!match || !match.result) return null;
    return {
      winner: match.result.winner,
      title: match.result.title,
      text: match.result.text,
      forced: match.result.forced,
      roster: match.players.map((p) => ({
        id: p.id,
        name: p.name,
        roleId: p.roleId,
        alive: p.alive,
        winner: match.result.winnerIds.includes(p.id),
      })),
    };
  }

  function forceEnd() {
    const match = state.match;
    if (!match) return { ok: false, error: "لا توجد لعبة" };
    ensureMemory(match);
    if (!match.result) {
      match.result = {
        winner: "none",
        winnerIds: [],
        title: "🏁 أُنهيت اللعبة",
        text: "أنهى المضيف اللعبة يدويًا.",
        forced: true,
      };
      match.phase = "over";
      match.log.push({ round: match.round, text: "أُنهيت اللعبة يدويًا" });
    }
    return { ok: true };
  }

  function abandonMatch() {
    state.match = null;
  }

  // إعادة اللعب بنفس الإعدادات (توزيع أدوار جديد)
  function replay() {
    return startNewGame();
  }

  // معلومات اللوحة: لا أدوار إلا للمستبعدين وحسب إعداد الكشف
  function getPanelInfo() {
    const match = state.match;
    if (!match) return null;
    const reveal = Boolean(state.settings && state.settings.revealRoleOnElimination === "reveal");
    return {
      round: match.round,
      phase: match.phase,
      alive: match.players.filter((p) => p.alive).map((p) => p.name),
      dead: match.players
        .filter((p) => !p.alive)
        .map((p) => (reveal ? { name: p.name, roleId: p.roleId } : { name: p.name })),
      log: match.log ? match.log.map((entry) => ({ ...entry })) : [],
    };
  }
    /* ---------- الحفظ والاستعادة والإحصائيات ---------- */
  function exportState() {
    if (!state.match || !state.settings) return null;
    return JSON.parse(JSON.stringify({ settings: state.settings, match: state.match }));
  }

  // استعادة آمنة: تتحقق من البيانات ثم تعيد اللعبة لآخر نقطة عامة
  function importState(data) {
    const fail = (error) => ({ ok: false, error });
    try {
      if (!data || typeof data !== "object" || !data.settings || !data.match) {
        return fail("بيانات الحفظ غير صالحة");
      }
      if (!validateSettings(data.settings).valid) return fail("إعدادات الحفظ غير صالحة");

      const match = data.match;
      const players = match.players;
      if (!Array.isArray(players) || players.length !== data.settings.playerCount) {
        return fail("لاعبون غير صالحين");
      }
      const valid = players.every(
        (p) => p && Number.isInteger(p.id) && typeof p.name === "string" &&
          Roles.get(p.roleId) && typeof p.alive === "boolean"
      );
      if (!valid || new Set(players.map((p) => p.id)).size !== players.length) {
        return fail("لاعبون غير صالحين");
      }
      if (!Number.isInteger(match.round) || match.round < 0) return fail("رقم الجولة غير صالح");
      if (!["reveal", "night", "dawn", "day", "over"].includes(match.phase)) {
        return fail("مرحلة غير صالحة");
      }
      if (match.phase === "reveal") {
        const index = match.revealIndex;
        if (!Number.isInteger(index) || index < 0 || index >= players.length) {
          return fail("تقدم الكشف غير صالح");
        }
      }

      ensureMemory(match);
      if (!Array.isArray(match.memory.silenced)) match.memory.silenced = [];
      if (!Array.isArray(match.memory.jammedNext)) match.memory.jammedNext = [];
      if (!Array.isArray(match.log)) match.log = [];

      if (match.result) {
        match.phase = "over";
      } else {
        // ليل لم يكتمل: نتراجع إلى ما قبل بدايته
        if (match.night && match.night.phase !== "done") {
          match.round = Math.max(0, match.round - 1);
          match.memory.jammedNext = Array.isArray(match.night.jammed) ? match.night.jammed.slice() : [];
          match.night = null;
          match.phase = "night";
        }
        if (match.day) {
          if (match.day.phase === "result") {
            // نهار انتهى تصويته: ننتقل لليل التالي
            match.day.phase = "done";
            match.phase = "night";
            match.memory.silenced = [];
          } else if (match.day.phase !== "done") {
            // نهار لم يكتمل: نعيده من بدايته
            match.day = null;
            match.phase = "dawn";
          }
        }
        if (match.phase === "day") match.phase = "dawn";
      }

      state.settings = JSON.parse(JSON.stringify(data.settings));
      state.match = match;
      return { ok: true, target: match.phase };
    } catch (error) {
      return fail("تعذرت قراءة الحفظ");
    }
  }

  // ملخص للإحصائيات (يتوفر بعد انتهاء اللعبة فقط)
  function getMatchSummary() {
    const match = state.match;
    if (!match || !match.result) return null;
    return {
      rounds: match.round,
      playerCount: match.players.length,
      roles: match.players.map((p) => p.roleId),
    };
  }

  // يرجع true مرة واحدة فقط لكل لعبة (لمنع التسجيل المكرر)
  function markRecorded() {
    const match = state.match;
    if (!match || match.recorded) return false;
    match.recorded = true;
    return true;
  }
  function hasActiveMatch() {
    return state.match !== null;
  }

  // معلومات عامة فقط: بلا أي دور سري
  function getPublicPlayers() {
    if (!state.match) return [];
    return state.match.players.map((p) => ({ id: p.id, name: p.name, alive: p.alive }));
  }

  // تُستخدم فقط من شاشة كشف الدور (المرحلة 4)
  function getRoleIdOf(playerId) {
    if (!state.match) return null;
    const player = state.match.players.find((p) => p.id === playerId);
    return player ? player.roleId : null;
  }

  return {
    MIN_PLAYERS,
    MAX_PLAYERS,
    MAX_NAME_LENGTH,
    maxMafia,
    recommendedMafia,
    neutralCap,
    createDefaultSettings,
    validateSettings,
    setSettings,
    getSettings,
    assignRoles,
    startNewGame,
    hasActiveMatch,
    getPublicPlayers,
        getRoleIdOf,
    getRevealState,
    advanceReveal,
        getMafiaPartnersOf,
    startNight,
    getNightTurn,
    beginNightTurn,
    submitNightAction,
    finishNightResult,
    advanceNightTurn,
    resolveNight,
    getPublicLog,
    startDay,
    getDayInfo,
    endDiscussion,
    setNominees,
    getVoteTurn,
    beginVoteTurn,
    submitVote,
    advanceVoteTurn,
    tallyVotes,
    finishDay,
    getResult,
    forceEnd,
    abandonMatch,
    replay,
    getPanelInfo,
    exportState,
    importState,
    getMatchSummary,
    markRecorded,
  };
})();